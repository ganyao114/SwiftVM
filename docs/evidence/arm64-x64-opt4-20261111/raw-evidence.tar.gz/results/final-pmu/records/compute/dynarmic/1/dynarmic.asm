00007dd052fce69b  nop [rax+rax*1], eax
00007dd052fce6a0  mov rax, [r15+0xF8]
00007dd052fce6a7  lea r14, [rax-0x1E0]
00007dd052fce6ae  mov [r15+0xF8], r14
00007dd052fce6b5  lea rax, [r14+0x1D0]
00007dd052fce6bc  mov r12, [r15+0xA0]
00007dd052fce6c3  mov r11, [r15+0x98]
00007dd052fce6ca  mov [r13+rax*1], r12
00007dd052fce6cf  lea rax, [r14+0x1D8]
00007dd052fce6d6  mov [r13+rax*1], r11
00007dd052fce6db  mov eax, 0x420AA0
00007dd052fce6e0  movups xmm1, [r13+rax*1]
00007dd052fce6e6  mov eax, 0x420A30
00007dd052fce6eb  movups xmm15, [r13+rax*1]
00007dd052fce6f1  mov eax, 0x420AC0
00007dd052fce6f6  movups xmm14, [r13+rax*1]
00007dd052fce6fc  mov eax, 0x420A60
00007dd052fce701  movups xmm13, [r13+rax*1]
00007dd052fce707  mov qword ptr [r15+0x98], 0x430CD0
00007dd052fce712  mov eax, 0x420AD0
00007dd052fce717  movups xmm12, [r13+rax*1]
00007dd052fce71d  mov eax, 0x430CD0
00007dd052fce722  movups [r13+rax*1], xmm1
00007dd052fce728  mov eax, 0x430CE0
00007dd052fce72d  movups [r13+rax*1], xmm15
00007dd052fce733  mov eax, 0x430CF0
00007dd052fce738  movups [r13+rax*1], xmm14
00007dd052fce73e  mov eax, 0x430D00
00007dd052fce743  movups [r13+rax*1], xmm13
00007dd052fce749  mov eax, 0x420A20
00007dd052fce74e  movups xmm14, [r13+rax*1]
00007dd052fce754  mov eax, 0x420A10
00007dd052fce759  movups xmm13, [r13+rax*1]
00007dd052fce75f  mov eax, 0x430DD0
00007dd052fce764  movups [r13+rax*1], xmm1
00007dd052fce76a  mov eax, 0x430DE0
00007dd052fce76f  movups [r13+rax*1], xmm15
00007dd052fce775  mov eax, 0x430D10
00007dd052fce77a  movups [r13+rax*1], xmm12
00007dd052fce780  mov eax, 0x430D20
00007dd052fce785  movups [r13+rax*1], xmm14
00007dd052fce78b  mov eax, 0x420A00
00007dd052fce790  movups xmm1, [r13+rax*1]
00007dd052fce796  mov eax, 0x420A70
00007dd052fce79b  movups xmm15, [r13+rax*1]
00007dd052fce7a1  mov eax, 0x430D30
00007dd052fce7a6  movups [r13+rax*1], xmm13
00007dd052fce7ac  mov eax, 0x430D40
00007dd052fce7b1  movups [r13+rax*1], xmm1
00007dd052fce7b7  mov eax, 0x420A80
00007dd052fce7bc  movups xmm1, [r13+rax*1]
00007dd052fce7c2  mov eax, 0x420A50
00007dd052fce7c7  movups xmm14, [r13+rax*1]
00007dd052fce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
00007dd052fce7d5  mov eax, 0x430D50
00007dd052fce7da  movups [r13+rax*1], xmm15
00007dd052fce7e0  mov eax, 0x430D60
00007dd052fce7e5  movups [r13+rax*1], xmm1
00007dd052fce7eb  mov eax, 0x420AF0
00007dd052fce7f0  movups xmm1, [r13+rax*1]
00007dd052fce7f6  mov eax, 0x420B00
00007dd052fce7fb  movups xmm15, [r13+rax*1]
00007dd052fce801  movaps [r15+0x150], xmm15
00007dd052fce809  mov qword ptr [r15+0xA0], 0x3E8
00007dd052fce814  mov eax, 0x430D70
00007dd052fce819  movups [r13+rax*1], xmm14
00007dd052fce81f  mov eax, 0x430D80
00007dd052fce824  movups [r13+rax*1], xmm1
00007dd052fce82a  mov eax, 0x420AE0
00007dd052fce82f  movups xmm1, [r13+rax*1]
00007dd052fce835  mov eax, 0x420A90
00007dd052fce83a  movups xmm14, [r13+rax*1]
00007dd052fce840  movaps [r15+0x140], xmm14
00007dd052fce848  lea rax, [r14+0x180]
00007dd052fce84f  movq xmm13, qword ptr [r15+0x200]
00007dd052fce858  movq xmm12, qword ptr [r15+0x1F0]
00007dd052fce861  movq r12, xmm13
00007dd052fce866  movq r11, xmm12
00007dd052fce86b  mov [r13+rax*1], r12
00007dd052fce870  lea rax, [r14+0x188]
00007dd052fce877  mov [r13+rax*1], r11
00007dd052fce87c  mov eax, 0x430D90
00007dd052fce881  movups [r13+rax*1], xmm15
00007dd052fce887  mov eax, 0x430DA0
00007dd052fce88c  movups [r13+rax*1], xmm1
00007dd052fce892  mov eax, 0x420AB0
00007dd052fce897  movups xmm1, [r13+rax*1]
00007dd052fce89d  mov eax, 0x420B18
00007dd052fce8a2  mov r12, [r13+rax*1]
00007dd052fce8a7  movq xmm15, r12
00007dd052fce8ac  mov qword ptr [r15+0x40], 0x420B20
00007dd052fce8b4  mov eax, 0x430DB0
00007dd052fce8b9  movups [r13+rax*1], xmm14
00007dd052fce8bf  mov eax, 0x430DC0
00007dd052fce8c4  movups [r13+rax*1], xmm1
00007dd052fce8ca  mov eax, 0x420B80
00007dd052fce8cf  movups xmm1, [r13+rax*1]
00007dd052fce8d5  movq rax, xmm15
00007dd052fce8da  mov r12d, 0x430DF0
00007dd052fce8e0  mov [r13+r12*1], rax
00007dd052fce8e5  mov eax, 0x420B60
00007dd052fce8ea  movups xmm15, [r13+rax*1]
00007dd052fce8f0  mov eax, 0x420B70
00007dd052fce8f5  movups xmm14, [r13+rax*1]
00007dd052fce8fb  lea rax, [r14+0x160]
00007dd052fce902  movups [r13+rax*1], xmm1
00007dd052fce908  lea rax, [r14+0x190]
00007dd052fce90f  movq xmm1, qword ptr [r15+0x1E0]
00007dd052fce918  movq xmm13, qword ptr [r15+0x1D0]
00007dd052fce921  movq r12, xmm1
00007dd052fce926  movq r11, xmm13
00007dd052fce92b  mov [r13+rax*1], r12
00007dd052fce930  lea rax, [r14+0x198]
00007dd052fce937  mov [r13+rax*1], r11
00007dd052fce93c  lea rax, [r14+0x140]
00007dd052fce943  movups [r13+rax*1], xmm15
00007dd052fce949  lea rax, [r14+0x150]
00007dd052fce950  movups [r13+rax*1], xmm14
00007dd052fce956  mov eax, 0x420B20
00007dd052fce95b  movups xmm1, [r13+rax*1]
00007dd052fce961  mov eax, 0x420B30
00007dd052fce966  movups xmm15, [r13+rax*1]
00007dd052fce96c  movaps [r15+0x120], xmm15
00007dd052fce974  lea rax, [r14+0x1A0]
00007dd052fce97b  movq xmm14, qword ptr [r15+0x1C0]
00007dd052fce984  movq xmm13, qword ptr [r15+0x1B0]
00007dd052fce98d  movq r12, xmm14
00007dd052fce992  movq r11, xmm13
00007dd052fce997  mov [r13+rax*1], r12
00007dd052fce99c  lea rax, [r14+0x1A8]
00007dd052fce9a3  mov [r13+rax*1], r11
00007dd052fce9a8  lea rax, [r14+0x1B0]
00007dd052fce9af  movq xmm14, qword ptr [r15+0x1A0]
00007dd052fce9b8  movq xmm13, qword ptr [r15+0x190]
00007dd052fce9c1  movq r12, xmm14
00007dd052fce9c6  movq r11, xmm13
00007dd052fce9cb  mov [r13+rax*1], r12
00007dd052fce9d0  lea rax, [r14+0x1B8]
00007dd052fce9d7  mov [r13+rax*1], r11
00007dd052fce9dc  lea rax, [r14+0x100]
00007dd052fce9e3  movups [r13+rax*1], xmm1
00007dd052fce9e9  lea rax, [r14+0x110]
00007dd052fce9f0  movups [r13+rax*1], xmm15
00007dd052fce9f6  mov eax, 0x420B40
00007dd052fce9fb  movups xmm1, [r13+rax*1]
00007dd052fcea01  mov eax, 0x420B50
00007dd052fcea06  movups xmm15, [r13+rax*1]
00007dd052fcea0c  movaps [r15+0x110], xmm1
00007dd052fcea14  movaps [r15+0x130], xmm15
00007dd052fcea1c  lea rax, [r14+0x1C0]
00007dd052fcea23  mov r12, [r15+0xE8]
00007dd052fcea2a  mov r11, [r15+0xF0]
00007dd052fcea31  mov [r13+rax*1], r12
00007dd052fcea36  lea rax, [r14+0x1C8]
00007dd052fcea3d  mov [r13+rax*1], r11
00007dd052fcea42  mov eax, 0x430DF8
00007dd052fcea47  mov r12d, 0x421DF8D3
00007dd052fcea4d  mov [r13+rax*1], r12d
00007dd052fcea52  lea rax, [r14+0x120]
00007dd052fcea59  movups [r13+rax*1], xmm1
00007dd052fcea5f  lea rax, [r14+0x130]
00007dd052fcea66  movups [r13+rax*1], xmm15
00007dd052fcea6c  lea rax, [r14+0x100]
00007dd052fcea73  mov [r15], rax
00007dd052fcea76  mov qword ptr [r15+0x08], 0x430CD0
00007dd052fcea7e  mov qword ptr [r15+0x10], 0x12C
00007dd052fcea86  mov qword ptr [r15+0xF0], 0x410284
00007dd052fcea91  mov r14d, [r15+0x320]
00007dd052fcea98  mov eax, 0x410284
00007dd052fcea9d  mov rcx, 0x7DD052FD07C0
00007dd052fceaa7  mov [r15+r14*8+0x328], rax
00007dd052fceaaf  mov [r15+r14*8+0x368], rcx
00007dd052fceab7  add r14d, 0x01
00007dd052fceabb  and r14d, 0x07
00007dd052fceabf  mov [r15+0x320], r14d
00007dd052fceac6  cmp dword ptr [r15+0x318], 0x00
00007dd052fceace  jz 0x00007DD052FCED70
00007dd052fcead4  nop [rax+rax*1], ax
00007dd052fceadd  nop [rax+rax*1], eax
00007dd052fceae5  mov eax, 0x410728
00007dd052fceaea  mov [r15+0x100], rax
00007dd052fceaf1  jmp 0x00007DD052DFE110
00007dd052fceaf6  int3
00007dd052fceaf7  call 0x00007DD052E0BC20
00007dd052fceafc  jmp 0x00007DD052FCE6CF
00007dd052fceb01  call 0x00007DD052E0A9A0
00007dd052fceb06  jmp 0x00007DD052FCE6DB
00007dd052fceb0b  call 0x00007DD052DFF430
00007dd052fceb10  jmp 0x00007DD052FCE6E6
00007dd052fceb15  call 0x00007DD052E0E760
00007dd052fceb1a  jmp 0x00007DD052FCE6F1
00007dd052fceb1f  call 0x00007DD052E0D4E0
00007dd052fceb24  jmp 0x00007DD052FCE6FC
00007dd052fceb29  call 0x00007DD052E0C260
00007dd052fceb2e  jmp 0x00007DD052FCE707
00007dd052fceb33  call 0x00007DD052E0AFE0
00007dd052fceb38  jmp 0x00007DD052FCE71D
00007dd052fceb3d  call 0x00007DD052DFF540
00007dd052fceb42  jmp 0x00007DD052FCE728
00007dd052fceb47  call 0x00007DD052E0E880
00007dd052fceb4c  jmp 0x00007DD052FCE733
00007dd052fceb51  call 0x00007DD052E0D600
00007dd052fceb56  jmp 0x00007DD052FCE73E
00007dd052fceb5b  call 0x00007DD052E0C380
00007dd052fceb60  jmp 0x00007DD052FCE749
00007dd052fceb65  call 0x00007DD052E0D4E0
00007dd052fceb6a  jmp 0x00007DD052FCE754
00007dd052fceb6f  call 0x00007DD052E0C260
00007dd052fceb74  jmp 0x00007DD052FCE75F
00007dd052fceb79  call 0x00007DD052DFF540
00007dd052fceb7e  jmp 0x00007DD052FCE76A
00007dd052fceb83  call 0x00007DD052E0E880
00007dd052fceb88  jmp 0x00007DD052FCE775
00007dd052fceb8d  call 0x00007DD052E0B100
00007dd052fceb92  jmp 0x00007DD052FCE780
00007dd052fceb97  call 0x00007DD052E0D600
00007dd052fceb9c  jmp 0x00007DD052FCE78B
00007dd052fceba1  call 0x00007DD052DFF430
00007dd052fceba6  jmp 0x00007DD052FCE796
00007dd052fcebab  call 0x00007DD052E0E760
00007dd052fcebb0  jmp 0x00007DD052FCE7A1
00007dd052fcebb5  call 0x00007DD052E0C380
00007dd052fcebba  jmp 0x00007DD052FCE7AC
00007dd052fcebbf  call 0x00007DD052DFF540
00007dd052fcebc4  jmp 0x00007DD052FCE7B7
00007dd052fcebc9  call 0x00007DD052DFF430
00007dd052fcebce  jmp 0x00007DD052FCE7C2
00007dd052fcebd3  call 0x00007DD052E0D4E0
00007dd052fcebd8  jmp 0x00007DD052FCE7CD
00007dd052fcebdd  call 0x00007DD052E0E880
00007dd052fcebe2  jmp 0x00007DD052FCE7E0
00007dd052fcebe7  call 0x00007DD052DFF540
00007dd052fcebec  jmp 0x00007DD052FCE7EB
00007dd052fcebf1  call 0x00007DD052DFF430
00007dd052fcebf6  jmp 0x00007DD052FCE7F6
00007dd052fcebfb  call 0x00007DD052E0E760
00007dd052fcec00  jmp 0x00007DD052FCE801
00007dd052fcec05  call 0x00007DD052E0D600
00007dd052fcec0a  jmp 0x00007DD052FCE81F
00007dd052fcec0f  call 0x00007DD052DFF540
00007dd052fcec14  jmp 0x00007DD052FCE82A
00007dd052fcec19  call 0x00007DD052DFF430
00007dd052fcec1e  jmp 0x00007DD052FCE835
00007dd052fcec23  call 0x00007DD052E0D4E0
00007dd052fcec28  jmp 0x00007DD052FCE840
00007dd052fcec2d  call 0x00007DD052E0BC20
00007dd052fcec32  jmp 0x00007DD052FCE870
00007dd052fcec37  call 0x00007DD052E0A9A0
00007dd052fcec3c  jmp 0x00007DD052FCE87C
00007dd052fcec41  call 0x00007DD052E0E880
00007dd052fcec46  jmp 0x00007DD052FCE887
00007dd052fcec4b  call 0x00007DD052DFF540
00007dd052fcec50  jmp 0x00007DD052FCE892
00007dd052fcec55  call 0x00007DD052DFF430
00007dd052fcec5a  jmp 0x00007DD052FCE89D
00007dd052fcec5f  call 0x00007DD052E0B720
00007dd052fcec64  jmp 0x00007DD052FCE8A7
00007dd052fcec69  call 0x00007DD052E0D600
00007dd052fcec6e  jmp 0x00007DD052FCE8BF
00007dd052fcec73  call 0x00007DD052DFF540
00007dd052fcec78  jmp 0x00007DD052FCE8CA
00007dd052fcec7d  call 0x00007DD052DFF430
00007dd052fcec82  jmp 0x00007DD052FCE8D5
00007dd052fcec87  call 0x00007DD052EB4CB0
00007dd052fcec8c  jmp 0x00007DD052FCE8E5
00007dd052fcec91  call 0x00007DD052E0E760
00007dd052fcec96  jmp 0x00007DD052FCE8F0
00007dd052fcec9b  call 0x00007DD052E0D4E0
00007dd052fceca0  jmp 0x00007DD052FCE8FB
00007dd052fceca5  call 0x00007DD052DFF540
00007dd052fcecaa  jmp 0x00007DD052FCE908
00007dd052fcecaf  call 0x00007DD052E0BC20
00007dd052fcecb4  jmp 0x00007DD052FCE930
00007dd052fcecb9  call 0x00007DD052E0A9A0
00007dd052fcecbe  jmp 0x00007DD052FCE93C
00007dd052fcecc3  call 0x00007DD052E0E880
00007dd052fcecc8  jmp 0x00007DD052FCE949
00007dd052fceccd  call 0x00007DD052E0D600
00007dd052fcecd2  jmp 0x00007DD052FCE956
00007dd052fcecd7  call 0x00007DD052DFF430
00007dd052fcecdc  jmp 0x00007DD052FCE961
00007dd052fcece1  call 0x00007DD052E0E760
00007dd052fcece6  jmp 0x00007DD052FCE96C
00007dd052fceceb  call 0x00007DD052E0BC20
00007dd052fcecf0  jmp 0x00007DD052FCE99C
00007dd052fcecf5  call 0x00007DD052E0A9A0
00007dd052fcecfa  jmp 0x00007DD052FCE9A8
00007dd052fcecff  call 0x00007DD052E0BC20
00007dd052fced04  jmp 0x00007DD052FCE9D0
00007dd052fced09  call 0x00007DD052E0A9A0
00007dd052fced0e  jmp 0x00007DD052FCE9DC
00007dd052fced13  call 0x00007DD052DFF540
00007dd052fced18  jmp 0x00007DD052FCE9E9
00007dd052fced1d  call 0x00007DD052E0E880
00007dd052fced22  jmp 0x00007DD052FCE9F6
00007dd052fced27  call 0x00007DD052DFF430
00007dd052fced2c  jmp 0x00007DD052FCEA01
00007dd052fced31  call 0x00007DD052E0E760
00007dd052fced36  jmp 0x00007DD052FCEA0C
00007dd052fced3b  call 0x00007DD052E0BC20
00007dd052fced40  jmp 0x00007DD052FCEA36
00007dd052fced45  call 0x00007DD052E0A9A0
00007dd052fced4a  jmp 0x00007DD052FCEA42
00007dd052fced4f  call 0x00007DD052E0BAE0
00007dd052fced54  jmp 0x00007DD052FCEA52
00007dd052fced59  call 0x00007DD052DFF540
00007dd052fced5e  jmp 0x00007DD052FCEA5F
00007dd052fced63  call 0x00007DD052E0E880
00007dd052fced68  jmp 0x00007DD052FCEA6C
00007dd052fced6d  int3
00007dd052fced6e  nop
00007dd052fced70  mov rax, [r15]
00007dd052fced73  lea r14, [rax+0x20]
00007dd052fced77  mov r12, [r13+r14*1]
00007dd052fced7c  mov r14, [r15+0x10]
00007dd052fced80  lea r11, [r12+r14*1]
00007dd052fced84  mov [r15+0x40], r11
00007dd052fced88  lea r12, [rax+0x20]
00007dd052fced8c  mov [r13+r12*1], r11
00007dd052fced91  test r14, r14
00007dd052fced94  setz r14b
00007dd052fced98  movzx r14, r14b
00007dd052fced9c  mov [rsp+0x414], r14b
00007dd052fceda4  cmp byte ptr [rsp+0x414], 0x00
00007dd052fcedac  jz 0x00007DD052FCEDDE
00007dd052fcedae  cmp dword ptr [r15+0x318], 0x00
00007dd052fcedb6  mov eax, 0x4109A0
00007dd052fcedbb  mov [r15+0x100], rax
00007dd052fcedc2  jz 0x00007DD052DFE0A0
00007dd052fcedc8  nop [rax+rax*1], eax
00007dd052fcedcd  mov eax, 0x4109A0
00007dd052fcedd2  mov [r15+0x100], rax
00007dd052fcedd9  jmp 0x00007DD052DFE110
00007dd052fcedde  cmp dword ptr [r15+0x318], 0x00
00007dd052fcede6  jz 0x00007DD052FCEE30
00007dd052fcedec  nop [rax+rax*1], ax
00007dd052fcedf5  nop [rax+rax*1], eax
00007dd052fcedfd  mov eax, 0x410738
00007dd052fcee02  mov [r15+0x100], rax
00007dd052fcee09  jmp 0x00007DD052DFE110
00007dd052fcee0e  int3
00007dd052fcee0f  call 0x00007DD052EE27E0
00007dd052fcee14  jmp 0x00007DD052FCED7C
00007dd052fcee19  call 0x00007DD052EC0860
00007dd052fcee1e  jmp 0x00007DD052FCED91
00007dd052fcee23  int3
00007dd052fcee24  nop [rax+rax*1], ax
00007dd052fcee2d  nop [rax], eax
00007dd052fcee30  mov rax, [r15+0xF8]
00007dd052fcee37  lea r14, [rax-0x150]
00007dd052fcee3e  mov [r15+0xF8], r14
00007dd052fcee45  mov rax, [r15]
00007dd052fcee48  lea r12, [rax+0x68]
00007dd052fcee4c  mov r11, [r13+r12*1]
00007dd052fcee51  mov [r15+0x88], r11
00007dd052fcee58  lea r12, [rax+0x28]
00007dd052fcee5c  mov [r15+0x40], r12
00007dd052fcee60  mov [r15+0x48], r14
00007dd052fcee64  mov qword ptr [r15+0x50], 0x420B90
00007dd052fcee6c  lea rax, [r14+0x100]
00007dd052fcee73  mov r12, [r15+0xE8]
00007dd052fcee7a  mov r11, [r15+0xD8]
00007dd052fcee81  mov [r13+rax*1], r12
00007dd052fcee86  lea rax, [r14+0x108]
00007dd052fcee8d  mov [r13+rax*1], r11
00007dd052fcee92  lea rax, [r14+0x110]
00007dd052fcee99  mov r12, [r15+0xD0]
00007dd052fceea0  mov r11, [r15+0xC8]
00007dd052fceea7  mov [r13+rax*1], r12
00007dd052fceeac  lea rax, [r14+0x118]
00007dd052fceeb3  mov [r13+rax*1], r11
00007dd052fceeb8  lea rax, [r14+0x120]
00007dd052fceebf  mov r12, [r15+0xC0]
00007dd052fceec6  mov r11, [r15+0xB8]
00007dd052fceecd  mov [r13+rax*1], r12
00007dd052fceed2  lea rax, [r14+0x128]
00007dd052fceed9  mov [r13+rax*1], r11
00007dd052fceede  lea rax, [r14+0x130]
00007dd052fceee5  mov r12, [r15+0xB0]
00007dd052fceeec  mov r11, [r15+0xA8]
00007dd052fceef3  mov [r13+rax*1], r12
00007dd052fceef8  lea rax, [r14+0x138]
00007dd052fceeff  mov [r13+rax*1], r11
00007dd052fcef04  lea rax, [r14+0x140]
00007dd052fcef0b  mov r12, [r15+0xA0]
00007dd052fcef12  mov r11, [r15+0x98]
00007dd052fcef19  mov [r13+rax*1], r12
00007dd052fcef1e  lea rax, [r14+0x148]
00007dd052fcef25  mov [r13+rax*1], r11
00007dd052fcef2a  cmp dword ptr [r15+0x318], 0x00
00007dd052fcef32  jz 0x00007DD052FCEFD0
00007dd052fcef38  nop [rax+rax*1], ax
00007dd052fcef41  nop [rax+rax*1], eax
00007dd052fcef49  mov eax, 0x410770
00007dd052fcef4e  mov [r15+0x100], rax
00007dd052fcef55  jmp 0x00007DD052DFE110
00007dd052fcef5a  int3
00007dd052fcef5b  call 0x00007DD052EC0370
00007dd052fcef60  jmp 0x00007DD052FCEE51
00007dd052fcef65  call 0x00007DD052E0BC20
00007dd052fcef6a  jmp 0x00007DD052FCEE86
00007dd052fcef6f  call 0x00007DD052E0A9A0
00007dd052fcef74  jmp 0x00007DD052FCEE92
00007dd052fcef79  call 0x00007DD052E0BC20
00007dd052fcef7e  jmp 0x00007DD052FCEEAC
00007dd052fcef83  call 0x00007DD052E0A9A0
00007dd052fcef88  jmp 0x00007DD052FCEEB8
00007dd052fcef8d  call 0x00007DD052E0BC20
00007dd052fcef92  jmp 0x00007DD052FCEED2
00007dd052fcef97  call 0x00007DD052E0A9A0
00007dd052fcef9c  jmp 0x00007DD052FCEEDE
00007dd052fcefa1  call 0x00007DD052E0BC20
00007dd052fcefa6  jmp 0x00007DD052FCEEF8
00007dd052fcefab  call 0x00007DD052E0A9A0
00007dd052fcefb0  jmp 0x00007DD052FCEF04
00007dd052fcefb5  call 0x00007DD052E0BC20
00007dd052fcefba  jmp 0x00007DD052FCEF1E
00007dd052fcefbf  call 0x00007DD052E0A9A0
00007dd052fcefc4  jmp 0x00007DD052FCEF2A
00007dd052fcefc9  int3
00007dd052fcefca  nop [rax+rax*1], ax
00007dd052fcefd0  mov rax, [r15+0x08]
00007dd052fcefd4  movzx r14d, byte ptr [r13+rax*1]
00007dd052fcefda  movzx r14d, r14b
00007dd052fcefde  mov [rsp+0x10], r14d
00007dd052fcefe3  mov r14d, r14d
00007dd052fcefe6  mov [r15+0x58], r14
00007dd052fcefea  lea r14, [rax+0x01]
00007dd052fcefee  mov [r15+0x08], r14
00007dd052fceff2  mov rax, [r15+0x88]
00007dd052fceff9  lea r14, [rax+0x01]
00007dd052fceffd  mov r12, [r15]
00007dd052fcf000  lea r11, [r12+0x68]
00007dd052fcf005  mov [r13+r11*1], r14
00007dd052fcf00a  lea r14, [r12+rax*1]
00007dd052fcf00e  mov [r15+0x60], r14
00007dd052fcf012  lea rax, [r14+0x28]
00007dd052fcf016  mov r11d, [rsp+0x10]
00007dd052fcf01b  movzx r14d, r11b
00007dd052fcf01f  mov [r13+rax*1], r14b
00007dd052fcf024  lea rax, [r12+0x68]
00007dd052fcf029  mov r14, [r13+rax*1]
00007dd052fcf02e  mov [r15+0x88], r14
00007dd052fcf035  xor eax, eax
00007dd052fcf037  mov r12d, 0x40
00007dd052fcf03d  cmp r14, r12
00007dd052fcf040  cmc
00007dd052fcf041  lahf
00007dd052fcf042  seto al
00007dd052fcf045  mov [r15+0x108], eax
00007dd052fcf04c  mov eax, [r15+0x108]
00007dd052fcf053  sahf
00007dd052fcf054  jnz 0x00007DD052FCF086
00007dd052fcf056  cmp dword ptr [r15+0x318], 0x00
00007dd052fcf05e  jz 0x00007DD052FCF170
00007dd052fcf064  nop [rax+rax*1], ax
00007dd052fcf06d  nop [rax+rax*1], eax
00007dd052fcf075  mov eax, 0x410790
00007dd052fcf07a  mov [r15+0x100], rax
00007dd052fcf081  jmp 0x00007DD052DFE110
00007dd052fcf086  cmp dword ptr [r15+0x318], 0x00
00007dd052fcf08e  jz 0x00007DD052FCF0E0
00007dd052fcf094  nop [rax+rax*1], ax
00007dd052fcf09d  nop [rax+rax*1], eax
00007dd052fcf0a5  mov eax, 0x410768
00007dd052fcf0aa  mov [r15+0x100], rax
00007dd052fcf0b1  jmp 0x00007DD052DFE110
00007dd052fcf0b6  int3
00007dd052fcf0b7  call 0x00007DD052E0D860
00007dd052fcf0bc  jmp 0x00007DD052FCEFDA
00007dd052fcf0c1  call 0x00007DD052EB36E0
00007dd052fcf0c6  jmp 0x00007DD052FCF00A
00007dd052fcf0cb  call 0x00007DD052E0DD60
00007dd052fcf0d0  jmp 0x00007DD052FCF024
00007dd052fcf0d5  call 0x00007DD052E0DC20
00007dd052fcf0da  jmp 0x00007DD052FCF02E
00007dd052fcf0df  int3
00007dd052fcf0e0  mov rax, [r15+0x10]
00007dd052fcf0e4  lea r14, [rax-0x01]
00007dd052fcf0e8  mov [r15+0x10], r14
00007dd052fcf0ec  test r14, r14
00007dd052fcf0ef  setz r14b
00007dd052fcf0f3  movzx r14, r14b
00007dd052fcf0f7  mov [rsp+0x414], r14b
00007dd052fcf0ff  cmp byte ptr [rsp+0x414], 0x00
00007dd052fcf107  jz 0x00007DD052FCF139
00007dd052fcf109  cmp dword ptr [r15+0x318], 0x00
00007dd052fcf111  jz 0x00007DD052FD0670
00007dd052fcf117  nop [rax+rax*1], ax
00007dd052fcf120  nop [rax+rax*1], eax
00007dd052fcf128  mov eax, 0x410988
00007dd052fcf12d  mov [r15+0x100], rax
00007dd052fcf134  jmp 0x00007DD052DFE110
00007dd052fcf139  cmp dword ptr [r15+0x318], 0x00
00007dd052fcf141  jz 0x00007DD052FCEFD0
00007dd052fcf147  nop [rax+rax*1], ax
00007dd052fcf150  nop [rax+rax*1], eax
00007dd052fcf158  mov eax, 0x410770
00007dd052fcf15d  mov [r15+0x100], rax
00007dd052fcf164  jmp 0x00007DD052DFE110
00007dd052fcf169  int3
00007dd052fcf16a  int3
00007dd052fcf16b  nop [rax+rax*1], eax
00007dd052fcf170  mov rax, [r15+0x40]
00007dd052fcf174  movzx r14d, byte ptr [r13+rax*1]
00007dd052fcf17a  movaps xmm1, [r15+0x110]
00007dd052fcf182  pinsrb xmm1, r14d, 0x00
00007dd052fcf189  lea r14, [rax+0x01]
00007dd052fcf18d  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf193  movaps xmm15, [r15+0x120]
00007dd052fcf19b  pinsrb xmm15, r12d, 0x00
00007dd052fcf1a2  lea r14, [rax+0x02]
00007dd052fcf1a6  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf1ac  movaps xmm14, [r15+0x130]
00007dd052fcf1b4  pinsrb xmm14, r12d, 0x00
00007dd052fcf1bb  lea r14, [rax+0x03]
00007dd052fcf1bf  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf1c5  movaps xmm13, [r15+0x140]
00007dd052fcf1cd  pinsrb xmm13, r12d, 0x00
00007dd052fcf1d4  lea r14, [rax+0x04]
00007dd052fcf1d8  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf1de  pinsrb xmm1, r12d, 0x01
00007dd052fcf1e5  lea r14, [rax+0x05]
00007dd052fcf1e9  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf1ef  pinsrb xmm15, r12d, 0x01
00007dd052fcf1f6  lea r14, [rax+0x06]
00007dd052fcf1fa  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf200  pinsrb xmm14, r12d, 0x01
00007dd052fcf207  lea r14, [rax+0x07]
00007dd052fcf20b  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf211  pinsrb xmm13, r12d, 0x01
00007dd052fcf218  lea r14, [rax+0x08]
00007dd052fcf21c  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf222  pinsrb xmm1, r12d, 0x02
00007dd052fcf229  lea r14, [rax+0x09]
00007dd052fcf22d  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf233  pinsrb xmm15, r12d, 0x02
00007dd052fcf23a  lea r14, [rax+0x0A]
00007dd052fcf23e  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf244  pinsrb xmm14, r12d, 0x02
00007dd052fcf24b  lea r14, [rax+0x0B]
00007dd052fcf24f  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf255  pinsrb xmm13, r12d, 0x02
00007dd052fcf25c  lea r14, [rax+0x0C]
00007dd052fcf260  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf266  pinsrb xmm1, r12d, 0x03
00007dd052fcf26d  lea r14, [rax+0x0D]
00007dd052fcf271  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf277  pinsrb xmm15, r12d, 0x03
00007dd052fcf27e  lea r14, [rax+0x0E]
00007dd052fcf282  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf288  pinsrb xmm14, r12d, 0x03
00007dd052fcf28f  lea r14, [rax+0x0F]
00007dd052fcf293  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf299  pinsrb xmm13, r12d, 0x03
00007dd052fcf2a0  lea r14, [rax+0x10]
00007dd052fcf2a4  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf2aa  pinsrb xmm1, r12d, 0x04
00007dd052fcf2b1  lea r14, [rax+0x11]
00007dd052fcf2b5  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf2bb  pinsrb xmm15, r12d, 0x04
00007dd052fcf2c2  lea r14, [rax+0x12]
00007dd052fcf2c6  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf2cc  pinsrb xmm14, r12d, 0x04
00007dd052fcf2d3  lea r14, [rax+0x13]
00007dd052fcf2d7  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf2dd  pinsrb xmm13, r12d, 0x04
00007dd052fcf2e4  lea r14, [rax+0x14]
00007dd052fcf2e8  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf2ee  pinsrb xmm1, r12d, 0x05
00007dd052fcf2f5  lea r14, [rax+0x15]
00007dd052fcf2f9  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf2ff  pinsrb xmm15, r12d, 0x05
00007dd052fcf306  lea r14, [rax+0x16]
00007dd052fcf30a  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf310  pinsrb xmm14, r12d, 0x05
00007dd052fcf317  lea r14, [rax+0x17]
00007dd052fcf31b  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf321  pinsrb xmm13, r12d, 0x05
00007dd052fcf328  lea r14, [rax+0x18]
00007dd052fcf32c  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf332  pinsrb xmm1, r12d, 0x06
00007dd052fcf339  lea r14, [rax+0x19]
00007dd052fcf33d  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf343  pinsrb xmm15, r12d, 0x06
00007dd052fcf34a  lea r14, [rax+0x1A]
00007dd052fcf34e  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf354  pinsrb xmm14, r12d, 0x06
00007dd052fcf35b  lea r14, [rax+0x1B]
00007dd052fcf35f  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf365  pinsrb xmm13, r12d, 0x06
00007dd052fcf36c  lea r14, [rax+0x1C]
00007dd052fcf370  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf376  pinsrb xmm1, r12d, 0x07
00007dd052fcf37d  lea r14, [rax+0x1D]
00007dd052fcf381  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf387  pinsrb xmm15, r12d, 0x07
00007dd052fcf38e  lea r14, [rax+0x1E]
00007dd052fcf392  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf398  pinsrb xmm14, r12d, 0x07
00007dd052fcf39f  lea r14, [rax+0x1F]
00007dd052fcf3a3  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf3a9  pinsrb xmm13, r12d, 0x07
00007dd052fcf3b0  lea r14, [rax+0x20]
00007dd052fcf3b4  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf3ba  pinsrb xmm1, r12d, 0x08
00007dd052fcf3c1  lea r14, [rax+0x21]
00007dd052fcf3c5  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf3cb  pinsrb xmm15, r12d, 0x08
00007dd052fcf3d2  lea r14, [rax+0x22]
00007dd052fcf3d6  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf3dc  pinsrb xmm14, r12d, 0x08
00007dd052fcf3e3  lea r14, [rax+0x23]
00007dd052fcf3e7  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf3ed  pinsrb xmm13, r12d, 0x08
00007dd052fcf3f4  lea r14, [rax+0x24]
00007dd052fcf3f8  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf3fe  pinsrb xmm1, r12d, 0x09
00007dd052fcf405  lea r14, [rax+0x25]
00007dd052fcf409  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf40f  pinsrb xmm15, r12d, 0x09
00007dd052fcf416  lea r14, [rax+0x26]
00007dd052fcf41a  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf420  pinsrb xmm14, r12d, 0x09
00007dd052fcf427  lea r14, [rax+0x27]
00007dd052fcf42b  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf431  pinsrb xmm13, r12d, 0x09
00007dd052fcf438  lea r14, [rax+0x28]
00007dd052fcf43c  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf442  pinsrb xmm1, r12d, 0x0A
00007dd052fcf449  lea r14, [rax+0x29]
00007dd052fcf44d  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf453  pinsrb xmm15, r12d, 0x0A
00007dd052fcf45a  lea r14, [rax+0x2A]
00007dd052fcf45e  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf464  pinsrb xmm14, r12d, 0x0A
00007dd052fcf46b  lea r14, [rax+0x2B]
00007dd052fcf46f  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf475  pinsrb xmm13, r12d, 0x0A
00007dd052fcf47c  lea r14, [rax+0x2C]
00007dd052fcf480  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf486  pinsrb xmm1, r12d, 0x0B
00007dd052fcf48d  lea r14, [rax+0x2D]
00007dd052fcf491  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf497  pinsrb xmm15, r12d, 0x0B
00007dd052fcf49e  lea r14, [rax+0x2E]
00007dd052fcf4a2  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf4a8  pinsrb xmm14, r12d, 0x0B
00007dd052fcf4af  lea r14, [rax+0x2F]
00007dd052fcf4b3  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf4b9  pinsrb xmm13, r12d, 0x0B
00007dd052fcf4c0  lea r14, [rax+0x30]
00007dd052fcf4c4  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf4ca  pinsrb xmm1, r12d, 0x0C
00007dd052fcf4d1  lea r14, [rax+0x31]
00007dd052fcf4d5  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf4db  pinsrb xmm15, r12d, 0x0C
00007dd052fcf4e2  lea r14, [rax+0x32]
00007dd052fcf4e6  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf4ec  pinsrb xmm14, r12d, 0x0C
00007dd052fcf4f3  lea r14, [rax+0x33]
00007dd052fcf4f7  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf4fd  pinsrb xmm13, r12d, 0x0C
00007dd052fcf504  lea r14, [rax+0x34]
00007dd052fcf508  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf50e  pinsrb xmm1, r12d, 0x0D
00007dd052fcf515  lea r14, [rax+0x35]
00007dd052fcf519  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf51f  pinsrb xmm15, r12d, 0x0D
00007dd052fcf526  lea r14, [rax+0x36]
00007dd052fcf52a  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf530  pinsrb xmm14, r12d, 0x0D
00007dd052fcf537  lea r14, [rax+0x37]
00007dd052fcf53b  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf541  pinsrb xmm13, r12d, 0x0D
00007dd052fcf548  lea r14, [rax+0x38]
00007dd052fcf54c  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf552  pinsrb xmm1, r12d, 0x0E
00007dd052fcf559  lea r14, [rax+0x39]
00007dd052fcf55d  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf563  pinsrb xmm15, r12d, 0x0E
00007dd052fcf56a  lea r14, [rax+0x3A]
00007dd052fcf56e  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf574  pinsrb xmm14, r12d, 0x0E
00007dd052fcf57b  lea r14, [rax+0x3B]
00007dd052fcf57f  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf585  pinsrb xmm13, r12d, 0x0E
00007dd052fcf58c  lea r14, [rax+0x3C]
00007dd052fcf590  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf596  pinsrb xmm1, r12d, 0x0F
00007dd052fcf59d  movaps [r15+0x110], xmm1
00007dd052fcf5a5  lea r14, [rax+0x3D]
00007dd052fcf5a9  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf5af  pinsrb xmm15, r12d, 0x0F
00007dd052fcf5b6  movaps [r15+0x120], xmm15
00007dd052fcf5be  lea r14, [rax+0x3E]
00007dd052fcf5c2  movzx r12d, byte ptr [r13+r14*1]
00007dd052fcf5c8  pinsrb xmm14, r12d, 0x0F
00007dd052fcf5cf  movaps [r15+0x130], xmm14
00007dd052fcf5d7  lea r14, [rax+0x3F]
00007dd052fcf5db  movzx eax, byte ptr [r13+r14*1]
00007dd052fcf5e1  pinsrb xmm13, eax, 0x0F
00007dd052fcf5e8  movaps [r15+0x140], xmm13
00007dd052fcf5f0  movq xmm1, qword ptr [r15+0x120]
00007dd052fcf5f9  pmovzxbw xmm1, xmm1
00007dd052fcf5fe  psllw xmm1, 0x00
00007dd052fcf603  movaps [r15+0x150], xmm1
00007dd052fcf60b  movq xmm1, qword ptr [r15+0x130]
00007dd052fcf614  pmovzxbw xmm1, xmm1
00007dd052fcf619  psllw xmm1, 0x00
00007dd052fcf61e  movaps [r15+0x160], xmm1
00007dd052fcf626  movq xmm1, qword ptr [r15+0x110]
00007dd052fcf62f  pmovzxbw xmm1, xmm1
00007dd052fcf634  psllw xmm1, 0x00
00007dd052fcf639  movaps [r15+0x170], xmm1
00007dd052fcf641  movaps xmm15, [r15+0x110]
00007dd052fcf649  pextrq rax, xmm15, 0x01
00007dd052fcf650  movq xmm15, rax
00007dd052fcf655  pmovzxbw xmm15, xmm15
00007dd052fcf65b  psllw xmm15, 0x00
00007dd052fcf661  movaps [r15+0x180], xmm15
00007dd052fcf669  movaps xmm14, [r15+0x120]
00007dd052fcf671  pextrq rax, xmm14, 0x01
00007dd052fcf678  movq xmm14, rax
00007dd052fcf67d  pmovzxbw xmm14, xmm14
00007dd052fcf683  psllw xmm14, 0x00
00007dd052fcf689  movaps [r15+0x210], xmm14
00007dd052fcf691  movaps xmm13, [r15+0x130]
00007dd052fcf699  pextrq rax, xmm13, 0x01
00007dd052fcf6a0  movq xmm13, rax
00007dd052fcf6a5  pmovzxbw xmm13, xmm13
00007dd052fcf6ab  psllw xmm13, 0x00
00007dd052fcf6b1  movaps [r15+0x220], xmm13
00007dd052fcf6b9  movq xmm12, qword ptr [r15+0x140]
00007dd052fcf6c2  pmovzxbw xmm12, xmm12
00007dd052fcf6c8  psllw xmm12, 0x00
00007dd052fcf6ce  movaps [r15+0x250], xmm12
00007dd052fcf6d6  movaps xmm12, [r15+0x140]
00007dd052fcf6de  pextrq rax, xmm12, 0x01
00007dd052fcf6e5  movq xmm12, rax
00007dd052fcf6ea  pmovzxbw xmm12, xmm12
00007dd052fcf6f0  psllw xmm12, 0x00
00007dd052fcf6f6  movaps [r15+0x110], xmm12
00007dd052fcf6fe  movq xmm11, qword ptr [r15+0x150]
00007dd052fcf707  pmovzxwd xmm11, xmm11
00007dd052fcf70d  pslld xmm11, 0x10
00007dd052fcf713  movq xmm10, qword ptr [r15+0x160]
00007dd052fcf71c  pmovzxwd xmm10, xmm10
00007dd052fcf722  pslld xmm10, 0x08
00007dd052fcf728  pextrq rax, xmm1, 0x01
00007dd052fcf72f  movq xmm1, rax
00007dd052fcf734  pmovzxwd xmm1, xmm1
00007dd052fcf739  pslld xmm1, 0x00
00007dd052fcf73e  movaps [r15+0x260], xmm1
00007dd052fcf746  pextrq rax, xmm15, 0x01
00007dd052fcf74d  movq xmm15, rax
00007dd052fcf752  pmovzxwd xmm15, xmm15
00007dd052fcf758  pslld xmm15, 0x00
00007dd052fcf75e  movaps [r15+0x270], xmm15
00007dd052fcf766  movq xmm9, qword ptr [r15+0x170]
00007dd052fcf76f  pmovzxwd xmm9, xmm9
00007dd052fcf775  pslld xmm9, 0x00
00007dd052fcf77b  pextrq rax, xmm14, 0x01
00007dd052fcf782  movq xmm14, rax
00007dd052fcf787  pmovzxwd xmm14, xmm14
00007dd052fcf78d  pslld xmm14, 0x10
00007dd052fcf793  movaps [r15+0x280], xmm14
00007dd052fcf79b  movq xmm8, qword ptr [r15+0x180]
00007dd052fcf7a4  pmovzxwd xmm8, xmm8
00007dd052fcf7aa  pslld xmm8, 0x00
00007dd052fcf7b0  movq xmm7, qword ptr [r15+0x210]
00007dd052fcf7b9  pmovzxwd xmm7, xmm7
00007dd052fcf7be  pslld xmm7, 0x10
00007dd052fcf7c3  movaps xmm6, [r15+0x150]
00007dd052fcf7cb  pextrq rax, xmm6, 0x01
00007dd052fcf7d2  movq xmm6, rax
00007dd052fcf7d7  pmovzxwd xmm6, xmm6
00007dd052fcf7dc  pslld xmm6, 0x10
00007dd052fcf7e1  por xmm11, xmm10
00007dd052fcf7e6  movaps [r15+0x230], xmm11
00007dd052fcf7ee  pextrq rax, xmm13, 0x01
00007dd052fcf7f5  movq xmm13, rax
00007dd052fcf7fa  pmovzxwd xmm13, xmm13
00007dd052fcf800  pslld xmm13, 0x08
00007dd052fcf806  movaps [r15+0x240], xmm13
00007dd052fcf80e  movq xmm10, qword ptr [r15+0x220]
00007dd052fcf817  pmovzxwd xmm10, xmm10
00007dd052fcf81d  pslld xmm10, 0x08
00007dd052fcf823  movaps xmm5, [r15+0x160]
00007dd052fcf82b  pextrq rax, xmm5, 0x01
00007dd052fcf832  movq xmm5, rax
00007dd052fcf837  pmovzxwd xmm5, xmm5
00007dd052fcf83c  pslld xmm5, 0x08
00007dd052fcf841  pslld xmm9, 0x18
00007dd052fcf847  pslld xmm15, 0x18
00007dd052fcf84d  pslld xmm8, 0x18
00007dd052fcf853  movq xmm4, qword ptr [r15+0x250]
00007dd052fcf85c  pmovzxwd xmm4, xmm4
00007dd052fcf861  pslld xmm4, 0x00
00007dd052fcf866  por xmm14, xmm13
00007dd052fcf86b  por xmm7, xmm10
00007dd052fcf870  movaps [r15+0x210], xmm7
00007dd052fcf878  pslld xmm1, 0x18
00007dd052fcf87d  movaps [r15+0x220], xmm1
00007dd052fcf885  por xmm6, xmm5
00007dd052fcf889  por xmm11, xmm9
00007dd052fcf88e  movaps [r15+0x160], xmm11
00007dd052fcf896  pextrq rax, xmm12, 0x01
00007dd052fcf89d  movq xmm13, rax
00007dd052fcf8a2  pmovzxwd xmm13, xmm13
00007dd052fcf8a8  pslld xmm13, 0x00
00007dd052fcf8ae  movaps [r15+0x170], xmm13
00007dd052fcf8b6  movq xmm12, qword ptr [r15+0x110]
00007dd052fcf8bf  pmovzxwd xmm12, xmm12
00007dd052fcf8c5  pslld xmm12, 0x00
00007dd052fcf8cb  por xmm14, xmm15
00007dd052fcf8d0  por xmm7, xmm8
00007dd052fcf8d5  movaps xmm15, [r15+0x250]
00007dd052fcf8dd  pextrq rax, xmm15, 0x01
00007dd052fcf8e4  movq xmm15, rax
00007dd052fcf8e9  pmovzxwd xmm15, xmm15
00007dd052fcf8ef  pslld xmm15, 0x00
00007dd052fcf8f5  movaps [r15+0x180], xmm15
00007dd052fcf8fd  por xmm6, xmm1
00007dd052fcf901  movaps [r15+0x150], xmm6
00007dd052fcf909  por xmm11, xmm4
00007dd052fcf90e  movaps [r15+0x140], xmm11
00007dd052fcf916  por xmm7, xmm12
00007dd052fcf91b  movaps [r15+0x110], xmm7
00007dd052fcf923  por xmm14, xmm13
00007dd052fcf928  movaps [r15+0x120], xmm14
00007dd052fcf930  por xmm6, xmm15
00007dd052fcf935  movaps [r15+0x130], xmm6
00007dd052fcf93d  mov rax, [r15+0xF8]
00007dd052fcf944  lea r14, [rax+0x20]
00007dd052fcf948  movups [r13+r14*1], xmm7
00007dd052fcf94e  lea r14, [rax+0x30]
00007dd052fcf952  movups [r13+r14*1], xmm14
00007dd052fcf958  movups [r13+rax*1], xmm11
00007dd052fcf95e  lea r14, [rax+0x10]
00007dd052fcf962  movups [r13+r14*1], xmm6
00007dd052fcf968  mov r14d, [r13+rax*1]
00007dd052fcf96d  mov rax, [r15+0x48]
00007dd052fcf971  mov [r15+0x68], rax
00007dd052fcf975  mov qword ptr [r15+0x58], 0x04
00007dd052fcf97d  lea r12, [rax+0x04]
00007dd052fcf981  mov r11d, [r13+r12*1]
00007dd052fcf986  mov [rsp+0x10], r11d
00007dd052fcf98b  mov r11d, r11d
00007dd052fcf98e  mov [r15+0x70], r11
00007dd052fcf992  lea r12, [rax+0x38]
00007dd052fcf996  mov r11d, [r13+r12*1]
00007dd052fcf99b  lea r12, [rax+0x24]
00007dd052fcf99f  mov r10d, [r13+r12*1]
00007dd052fcf9a4  mov [rsp+0x20], r10d
00007dd052fcf9a9  mov r10d, r10d
00007dd052fcf9ac  mov [r15+0x90], r10
00007dd052fcf9b3  mov [rsp+0x30], rax
00007dd052fcf9b8  xor eax, eax
00007dd052fcf9ba  mov r12d, 0x04
00007dd052fcf9c0  mov r10d, 0xC0
00007dd052fcf9c6  cmp r12, r10
00007dd052fcf9c9  cmc
00007dd052fcf9ca  lahf
00007dd052fcf9cb  seto al
00007dd052fcf9ce  mov [r15+0x108], eax
00007dd052fcf9d5  mov eax, [rsp+0x10]
00007dd052fcf9d9  mov r12d, [rsp+0x10]
00007dd052fcf9de  shrd eax, r12d, 0x07
00007dd052fcf9e3  mov [rsp+0x10], r11d
00007dd052fcf9e8  mov r10d, [rsp+0x10]
00007dd052fcf9ed  shrd r11d, r10d, 0x11
00007dd052fcf9f2  mov r9d, [rsp+0x20]
00007dd052fcf9f7  lea r8d, [r9d+r14d*1]
00007dd052fcf9fc  rorx r14d, r12d, 0x12
00007dd052fcfa02  xor eax, r14d
00007dd052fcfa05  rorx r14d, r10d, 0x13
00007dd052fcfa0b  xor r11d, r14d
00007dd052fcfa0e  mov [rsp+0x10], r11d
00007dd052fcfa13  mov r11d, r11d
00007dd052fcfa16  mov [r15+0x88], r11
00007dd052fcfa1d  mov [rsp+0x20], r12d
00007dd052fcfa22  shr r12d, 0x03
00007dd052fcfa26  xor eax, r12d
00007dd052fcfa29  mov [rsp+0x40], eax
00007dd052fcfa2d  mov eax, eax
00007dd052fcfa2f  mov [r15+0x80], rax
00007dd052fcfa36  shr r10d, 0x0A
00007dd052fcfa3a  mov eax, [rsp+0x10]
00007dd052fcfa3e  xor eax, r10d
00007dd052fcfa41  mov [rsp+0x10], eax
00007dd052fcfa45  mov eax, eax
00007dd052fcfa47  mov [r15+0x78], rax
00007dd052fcfa4b  mov eax, [rsp+0x40]
00007dd052fcfa4f  lea r14d, [r8d+eax*1]
00007dd052fcfa54  mov eax, [rsp+0x10]
00007dd052fcfa58  lea r12d, [r14d+eax*1]
00007dd052fcfa5d  mov rax, [rsp+0x30]
00007dd052fcfa62  lea r14, [rax+0x40]
00007dd052fcfa66  mov [r13+r14*1], r12d
00007dd052fcfa6b  mov eax, [rsp+0x20]
00007dd052fcfa6f  mov eax, eax
00007dd052fcfa71  mov [r15+0x60], rax
00007dd052fcfa75  mov eax, [r15+0x108]
00007dd052fcfa7c  sahf
00007dd052fcfa7d  jnz 0x00007DD052FCFAAF
00007dd052fcfa7f  cmp dword ptr [r15+0x318], 0x00
00007dd052fcfa87  jz 0x00007DD052FCFF70
00007dd052fcfa8d  nop [rax+rax*1], ax
00007dd052fcfa96  nop [rax+rax*1], eax
00007dd052fcfa9e  mov eax, 0x41088C
00007dd052fcfaa3  mov [r15+0x100], rax
00007dd052fcfaaa  jmp 0x00007DD052DFE110
00007dd052fcfaaf  cmp dword ptr [r15+0x318], 0x00
00007dd052fcfab7  jz 0x00007DD052FCFDC0
00007dd052fcfabd  nop [rax+rax*1], ax
00007dd052fcfac6  nop [rax+rax*1], eax
00007dd052fcface  mov eax, 0x410844
00007dd052fcfad3  mov [r15+0x100], rax
00007dd052fcfada  jmp 0x00007DD052DFE110
00007dd052fcfadf  int3
00007dd052fcfae0  call 0x00007DD052E0D860
00007dd052fcfae5  jmp 0x00007DD052FCF17A
00007dd052fcfaea  call 0x00007DD052EE2420
00007dd052fcfaef  jmp 0x00007DD052FCF193
00007dd052fcfaf4  call 0x00007DD052EE2420
00007dd052fcfaf9  jmp 0x00007DD052FCF1AC
00007dd052fcfafe  call 0x00007DD052EE2420
00007dd052fcfb03  jmp 0x00007DD052FCF1C5
00007dd052fcfb08  call 0x00007DD052EE2420
00007dd052fcfb0d  jmp 0x00007DD052FCF1DE
00007dd052fcfb12  call 0x00007DD052EE2420
00007dd052fcfb17  jmp 0x00007DD052FCF1EF
00007dd052fcfb1c  call 0x00007DD052EE2420
00007dd052fcfb21  jmp 0x00007DD052FCF200
00007dd052fcfb26  call 0x00007DD052EE2420
00007dd052fcfb2b  jmp 0x00007DD052FCF211
00007dd052fcfb30  call 0x00007DD052EE2420
00007dd052fcfb35  jmp 0x00007DD052FCF222
00007dd052fcfb3a  call 0x00007DD052EE2420
00007dd052fcfb3f  jmp 0x00007DD052FCF233
00007dd052fcfb44  call 0x00007DD052EE2420
00007dd052fcfb49  jmp 0x00007DD052FCF244
00007dd052fcfb4e  call 0x00007DD052EE2420
00007dd052fcfb53  jmp 0x00007DD052FCF255
00007dd052fcfb58  call 0x00007DD052EE2420
00007dd052fcfb5d  jmp 0x00007DD052FCF266
00007dd052fcfb62  call 0x00007DD052EE2420
00007dd052fcfb67  jmp 0x00007DD052FCF277
00007dd052fcfb6c  call 0x00007DD052EE2420
00007dd052fcfb71  jmp 0x00007DD052FCF288
00007dd052fcfb76  call 0x00007DD052EE2420
00007dd052fcfb7b  jmp 0x00007DD052FCF299
00007dd052fcfb80  call 0x00007DD052EE2420
00007dd052fcfb85  jmp 0x00007DD052FCF2AA
00007dd052fcfb8a  call 0x00007DD052EE2420
00007dd052fcfb8f  jmp 0x00007DD052FCF2BB
00007dd052fcfb94  call 0x00007DD052EE2420
00007dd052fcfb99  jmp 0x00007DD052FCF2CC
00007dd052fcfb9e  call 0x00007DD052EE2420
00007dd052fcfba3  jmp 0x00007DD052FCF2DD
00007dd052fcfba8  call 0x00007DD052EE2420
00007dd052fcfbad  jmp 0x00007DD052FCF2EE
00007dd052fcfbb2  call 0x00007DD052EE2420
00007dd052fcfbb7  jmp 0x00007DD052FCF2FF
00007dd052fcfbbc  call 0x00007DD052EE2420
00007dd052fcfbc1  jmp 0x00007DD052FCF310
00007dd052fcfbc6  call 0x00007DD052EE2420
00007dd052fcfbcb  jmp 0x00007DD052FCF321
00007dd052fcfbd0  call 0x00007DD052EE2420
00007dd052fcfbd5  jmp 0x00007DD052FCF332
00007dd052fcfbda  call 0x00007DD052EE2420
00007dd052fcfbdf  jmp 0x00007DD052FCF343
00007dd052fcfbe4  call 0x00007DD052EE2420
00007dd052fcfbe9  jmp 0x00007DD052FCF354
00007dd052fcfbee  call 0x00007DD052EE2420
00007dd052fcfbf3  jmp 0x00007DD052FCF365
00007dd052fcfbf8  call 0x00007DD052EE2420
00007dd052fcfbfd  jmp 0x00007DD052FCF376
00007dd052fcfc02  call 0x00007DD052EE2420
00007dd052fcfc07  jmp 0x00007DD052FCF387
00007dd052fcfc0c  call 0x00007DD052EE2420
00007dd052fcfc11  jmp 0x00007DD052FCF398
00007dd052fcfc16  call 0x00007DD052EE2420
00007dd052fcfc1b  jmp 0x00007DD052FCF3A9
00007dd052fcfc20  call 0x00007DD052EE2420
00007dd052fcfc25  jmp 0x00007DD052FCF3BA
00007dd052fcfc2a  call 0x00007DD052EE2420
00007dd052fcfc2f  jmp 0x00007DD052FCF3CB
00007dd052fcfc34  call 0x00007DD052EE2420
00007dd052fcfc39  jmp 0x00007DD052FCF3DC
00007dd052fcfc3e  call 0x00007DD052EE2420
00007dd052fcfc43  jmp 0x00007DD052FCF3ED
00007dd052fcfc48  call 0x00007DD052EE2420
00007dd052fcfc4d  jmp 0x00007DD052FCF3FE
00007dd052fcfc52  call 0x00007DD052EE2420
00007dd052fcfc57  jmp 0x00007DD052FCF40F
00007dd052fcfc5c  call 0x00007DD052EE2420
00007dd052fcfc61  jmp 0x00007DD052FCF420
00007dd052fcfc66  call 0x00007DD052EE2420
00007dd052fcfc6b  jmp 0x00007DD052FCF431
00007dd052fcfc70  call 0x00007DD052EE2420
00007dd052fcfc75  jmp 0x00007DD052FCF442
00007dd052fcfc7a  call 0x00007DD052EE2420
00007dd052fcfc7f  jmp 0x00007DD052FCF453
00007dd052fcfc84  call 0x00007DD052EE2420
00007dd052fcfc89  jmp 0x00007DD052FCF464
00007dd052fcfc8e  call 0x00007DD052EE2420
00007dd052fcfc93  jmp 0x00007DD052FCF475
00007dd052fcfc98  call 0x00007DD052EE2420
00007dd052fcfc9d  jmp 0x00007DD052FCF486
00007dd052fcfca2  call 0x00007DD052EE2420
00007dd052fcfca7  jmp 0x00007DD052FCF497
00007dd052fcfcac  call 0x00007DD052EE2420
00007dd052fcfcb1  jmp 0x00007DD052FCF4A8
00007dd052fcfcb6  call 0x00007DD052EE2420
00007dd052fcfcbb  jmp 0x00007DD052FCF4B9
00007dd052fcfcc0  call 0x00007DD052EE2420
00007dd052fcfcc5  jmp 0x00007DD052FCF4CA
00007dd052fcfcca  call 0x00007DD052EE2420
00007dd052fcfccf  jmp 0x00007DD052FCF4DB
00007dd052fcfcd4  call 0x00007DD052EE2420
00007dd052fcfcd9  jmp 0x00007DD052FCF4EC
00007dd052fcfcde  call 0x00007DD052EE2420
00007dd052fcfce3  jmp 0x00007DD052FCF4FD
00007dd052fcfce8  call 0x00007DD052EE2420
00007dd052fcfced  jmp 0x00007DD052FCF50E
00007dd052fcfcf2  call 0x00007DD052EE2420
00007dd052fcfcf7  jmp 0x00007DD052FCF51F
00007dd052fcfcfc  call 0x00007DD052EE2420
00007dd052fcfd01  jmp 0x00007DD052FCF530
00007dd052fcfd06  call 0x00007DD052EE2420
00007dd052fcfd0b  jmp 0x00007DD052FCF541
00007dd052fcfd10  call 0x00007DD052EE2420
00007dd052fcfd15  jmp 0x00007DD052FCF552
00007dd052fcfd1a  call 0x00007DD052EE2420
00007dd052fcfd1f  jmp 0x00007DD052FCF563
00007dd052fcfd24  call 0x00007DD052EE2420
00007dd052fcfd29  jmp 0x00007DD052FCF574
00007dd052fcfd2e  call 0x00007DD052EE2420
00007dd052fcfd33  jmp 0x00007DD052FCF585
00007dd052fcfd38  call 0x00007DD052EE2420
00007dd052fcfd3d  jmp 0x00007DD052FCF596
00007dd052fcfd42  call 0x00007DD052EE2420
00007dd052fcfd47  jmp 0x00007DD052FCF5AF
00007dd052fcfd4c  call 0x00007DD052EE2420
00007dd052fcfd51  jmp 0x00007DD052FCF5C8
00007dd052fcfd56  call 0x00007DD052ED5610
00007dd052fcfd5b  jmp 0x00007DD052FCF5E1
00007dd052fcfd60  call 0x00007DD052EDC580
00007dd052fcfd65  jmp 0x00007DD052FCF94E
00007dd052fcfd6a  call 0x00007DD052EE46C0
00007dd052fcfd6f  jmp 0x00007DD052FCF958
00007dd052fcfd74  call 0x00007DD052E09E90
00007dd052fcfd79  jmp 0x00007DD052FCF95E
00007dd052fcfd7e  call 0x00007DD052EDB310
00007dd052fcfd83  jmp 0x00007DD052FCF968
00007dd052fcfd88  call 0x00007DD052E0DAE0
00007dd052fcfd8d  jmp 0x00007DD052FCF96D
00007dd052fcfd92  call 0x00007DD052EC0230
00007dd052fcfd97  jmp 0x00007DD052FCF986
00007dd052fcfd9c  call 0x00007DD052EC0230
00007dd052fcfda1  jmp 0x00007DD052FCF99B
00007dd052fcfda6  call 0x00007DD052EBEFC0
00007dd052fcfdab  jmp 0x00007DD052FCF9A4
00007dd052fcfdb0  call 0x00007DD052EE2BA0
00007dd052fcfdb5  jmp 0x00007DD052FCFA6B
00007dd052fcfdba  int3
00007dd052fcfdbb  nop [rax+rax*1], eax
00007dd052fcfdc0  mov rax, [r15+0x48]
00007dd052fcfdc4  mov r14, [r15+0x58]
00007dd052fcfdc8  lea r12, [rax+r14*1]
00007dd052fcfdcc  mov [r15+0x68], r12
00007dd052fcfdd0  lea rax, [r14+0x04]
00007dd052fcfdd4  mov [r15+0x58], rax
00007dd052fcfdd8  lea r14, [r12+0x04]
00007dd052fcfddd  mov r11d, [r13+r14*1]
00007dd052fcfde2  mov [rsp+0x10], r11d
00007dd052fcfde7  mov r11d, r11d
00007dd052fcfdea  mov [r15+0x70], r11
00007dd052fcfdee  lea r14, [r12+0x38]
00007dd052fcfdf3  mov r11d, [r13+r14*1]
00007dd052fcfdf8  lea r14, [r12+0x24]
00007dd052fcfdfd  mov r10d, [r13+r14*1]
00007dd052fcfe02  mov [rsp+0x20], r10d
00007dd052fcfe07  mov r10d, r10d
00007dd052fcfe0a  mov [r15+0x90], r10
00007dd052fcfe11  mov [rsp+0x30], rax
00007dd052fcfe16  xor eax, eax
00007dd052fcfe18  mov r14, [rsp+0x30]
00007dd052fcfe1d  mov r10d, 0xC0
00007dd052fcfe23  cmp r14, r10
00007dd052fcfe26  cmc
00007dd052fcfe27  lahf
00007dd052fcfe28  seto al
00007dd052fcfe2b  mov [r15+0x108], eax
00007dd052fcfe32  mov eax, [rsp+0x10]
00007dd052fcfe36  mov r14d, [rsp+0x10]
00007dd052fcfe3b  shrd eax, r14d, 0x07
00007dd052fcfe40  mov [rsp+0x10], r11d
00007dd052fcfe45  mov r10d, [rsp+0x10]
00007dd052fcfe4a  shrd r11d, r10d, 0x11
00007dd052fcfe4f  mov r9d, [r15+0x60]
00007dd052fcfe53  mov r8d, [rsp+0x20]
00007dd052fcfe58  lea ebp, [r8d+r9d*1]
00007dd052fcfe5d  rorx r9d, r14d, 0x12
00007dd052fcfe63  xor eax, r9d
00007dd052fcfe66  rorx r9d, r10d, 0x13
00007dd052fcfe6c  xor r11d, r9d
00007dd052fcfe6f  mov [rsp+0x10], r11d
00007dd052fcfe74  mov r11d, r11d
00007dd052fcfe77  mov [r15+0x88], r11
00007dd052fcfe7e  mov [rsp+0x20], r14d
00007dd052fcfe83  shr r14d, 0x03
00007dd052fcfe87  xor eax, r14d
00007dd052fcfe8a  mov [rsp+0x30], eax
00007dd052fcfe8e  mov eax, eax
00007dd052fcfe90  mov [r15+0x80], rax
00007dd052fcfe97  shr r10d, 0x0A
00007dd052fcfe9b  mov eax, [rsp+0x10]
00007dd052fcfe9f  xor eax, r10d
00007dd052fcfea2  mov [rsp+0x10], eax
00007dd052fcfea6  mov eax, eax
00007dd052fcfea8  mov [r15+0x78], rax
00007dd052fcfeac  mov eax, [rsp+0x30]
00007dd052fcfeb0  lea r14d, [ebp+eax*1]
00007dd052fcfeb6  mov eax, [rsp+0x10]
00007dd052fcfeba  lea r11d, [r14d+eax*1]
00007dd052fcfebf  lea rax, [r12+0x40]
00007dd052fcfec4  mov [r13+rax*1], r11d
00007dd052fcfec9  mov eax, [rsp+0x20]
00007dd052fcfecd  mov eax, eax
00007dd052fcfecf  mov [r15+0x60], rax
00007dd052fcfed3  mov eax, [r15+0x108]
00007dd052fcfeda  sahf
00007dd052fcfedb  jnz 0x00007DD052FCFF0D
00007dd052fcfedd  cmp dword ptr [r15+0x318], 0x00
00007dd052fcfee5  jz 0x00007DD052FCFF70
00007dd052fcfeeb  nop [rax+rax*1], ax
00007dd052fcfef4  nop [rax+rax*1], eax
00007dd052fcfefc  mov eax, 0x41088C
00007dd052fcff01  mov [r15+0x100], rax
00007dd052fcff08  jmp 0x00007DD052DFE110
00007dd052fcff0d  cmp dword ptr [r15+0x318], 0x00
00007dd052fcff15  jz 0x00007DD052FCFDC0
00007dd052fcff1b  nop [rax+rax*1], ax
00007dd052fcff24  nop [rax+rax*1], eax
00007dd052fcff2c  mov eax, 0x410844
00007dd052fcff31  mov [r15+0x100], rax
00007dd052fcff38  jmp 0x00007DD052DFE110
00007dd052fcff3d  int3
00007dd052fcff3e  call 0x00007DD052EE1430
00007dd052fcff43  jmp 0x00007DD052FCFDE2
00007dd052fcff48  call 0x00007DD052EE1430
00007dd052fcff4d  jmp 0x00007DD052FCFDF8
00007dd052fcff52  call 0x00007DD052EE01C0
00007dd052fcff57  jmp 0x00007DD052FCFE02
00007dd052fcff5c  call 0x00007DD052E0A860
00007dd052fcff61  jmp 0x00007DD052FCFEC9
00007dd052fcff66  int3
00007dd052fcff67  nop [rax+rax*1], ax
00007dd052fcff70  mov rax, [r15]
00007dd052fcff73  mov r14d, [r13+rax*1]
00007dd052fcff78  lea r12, [rax+0x04]
00007dd052fcff7c  mov r11d, [r13+r12*1]
00007dd052fcff81  mov [rsp+0x10], r14d
00007dd052fcff86  mov r14d, r14d
00007dd052fcff89  mov [r15+0x78], r14
00007dd052fcff8d  mov [rsp+0x20], r11d
00007dd052fcff92  mov r11d, r11d
00007dd052fcff95  mov [r15+0x80], r11
00007dd052fcff9c  lea r14, [rax+0x08]
00007dd052fcffa0  mov r12d, [r13+r14*1]
00007dd052fcffa5  lea r14, [rax+0x0C]
00007dd052fcffa9  mov r11d, [r13+r14*1]
00007dd052fcffae  mov [rsp+0x30], r12d
00007dd052fcffb3  mov r12d, r12d
00007dd052fcffb6  mov [r15+0x70], r12
00007dd052fcffba  mov [rsp+0x40], r11d
00007dd052fcffbf  mov r11d, r11d
00007dd052fcffc2  mov [r15+0x68], r11
00007dd052fcffc6  lea r14, [rax+0x18]
00007dd052fcffca  mov r12d, [r13+r14*1]
00007dd052fcffcf  lea r14, [rax+0x1C]
00007dd052fcffd3  mov r11d, [r13+r14*1]
00007dd052fcffd8  mov [rsp+0x50], r12d
00007dd052fcffdd  mov r12d, r12d
00007dd052fcffe0  mov [r15+0x58], r12
00007dd052fcffe4  mov [rsp+0x60], r11d
00007dd052fcffe9  mov r11d, r11d
00007dd052fcffec  mov [r15+0x60], r11
00007dd052fcfff0  lea r14, [rax+0x10]
00007dd052fcfff4  mov r12d, [r13+r14*1]
00007dd052fcfff9  lea r14, [rax+0x14]
00007dd052fcfffd  mov eax, [r13+r14*1]
00007dd052fd0002  mov [rsp+0x70], r12d
00007dd052fd0007  mov r12d, r12d
00007dd052fd000a  mov [r15+0x18], r12
00007dd052fd000e  mov [rsp+0x80], eax
00007dd052fd0015  mov eax, eax
00007dd052fd0017  mov [r15+0x90], rax
00007dd052fd001e  mov eax, [rsp+0x70]
00007dd052fd0022  mov eax, eax
00007dd052fd0024  mov [r15+0x30], rax
00007dd052fd0028  mov eax, [rsp+0x50]
00007dd052fd002c  mov eax, eax
00007dd052fd002e  mov [r15+0xA0], rax
00007dd052fd0035  mov eax, [rsp+0x30]
00007dd052fd0039  mov eax, eax
00007dd052fd003b  mov [r15+0x28], rax
00007dd052fd003f  mov eax, [rsp+0x20]
00007dd052fd0043  mov eax, eax
00007dd052fd0045  mov [r15+0x98], rax
00007dd052fd004c  mov eax, [rsp+0x10]
00007dd052fd0050  mov eax, eax
00007dd052fd0052  mov [r15+0x38], rax
00007dd052fd0056  mov eax, [rsp+0x70]
00007dd052fd005a  mov r14d, [rsp+0x70]
00007dd052fd005f  shrd eax, r14d, 0x06
00007dd052fd0064  mov [rsp+0x70], r14d
00007dd052fd0069  mov r12d, [rsp+0x80]
00007dd052fd0071  and r14d, r12d
00007dd052fd0074  mov r11d, [rsp+0x10]
00007dd052fd0079  mov r10d, [rsp+0x10]
00007dd052fd007e  shrd r11d, r10d, 0x02
00007dd052fd0083  mov [rsp+0x10], r12d
00007dd052fd0088  mov r12d, r12d
00007dd052fd008b  mov [r15+0x20], r12
00007dd052fd008f  mov r12, [r15+0x50]
00007dd052fd0093  mov r9d, [r13+r12*1]
00007dd052fd0098  mov r12d, [rsp+0x50]
00007dd052fd009d  mov r8d, [rsp+0x70]
00007dd052fd00a2  andn ebp, r8d, r12d
00007dd052fd00a7  mov edi, [rsp+0x60]
00007dd052fd00ab  lea esi, [r14d+edi*1]
00007dd052fd00b0  rorx r14d, r8d, 0x0B
00007dd052fd00b6  xor eax, r14d
00007dd052fd00b9  rorx r14d, r10d, 0x0D
00007dd052fd00bf  xor r11d, r14d
00007dd052fd00c2  lea edi, [esi+ebp*1]
00007dd052fd00c6  mov r14, [r15+0x48]
00007dd052fd00ca  mov ebp, [r13+r14*1]
00007dd052fd00cf  mov r14d, [rsp+0x30]
00007dd052fd00d4  mov esi, [rsp+0x20]
00007dd052fd00d8  and r14d, esi
00007dd052fd00db  mov [rsp+0x20], r14d
00007dd052fd00e0  mov r14d, r14d
00007dd052fd00e3  mov [r15+0xD8], r14
00007dd052fd00ea  lea r14d, [edi+r9d*1]
00007dd052fd00ef  mov r9d, [rsp+0x30]
00007dd052fd00f4  xor r9d, esi
00007dd052fd00f7  rorx edi, r8d, 0x19
00007dd052fd00fd  xor eax, edi
00007dd052fd00ff  and r9d, r10d
00007dd052fd0102  rorx edi, r10d, 0x16
00007dd052fd0108  xor r11d, edi
00007dd052fd010b  mov [rsp+0x30], r11d
00007dd052fd0110  mov r11d, r11d
00007dd052fd0113  mov [r15+0xD0], r11
00007dd052fd011a  lea r11d, [r14d+ebp*1]
00007dd052fd011f  mov r10d, [rsp+0x20]
00007dd052fd0124  xor r9d, r10d
00007dd052fd0127  lea r14d, [r11d+eax*1]
00007dd052fd012c  mov qword ptr [r15+0x88], 0x04
00007dd052fd0137  mov eax, [rsp+0x30]
00007dd052fd013b  lea r11d, [r9d+eax*1]
00007dd052fd0140  mov eax, [rsp+0x40]
00007dd052fd0144  lea r10d, [r14d+eax*1]
00007dd052fd0149  mov r10d, r10d
00007dd052fd014c  mov [r15+0xB8], r10
00007dd052fd0153  xor eax, eax
00007dd052fd0155  mov r10d, 0x04
00007dd052fd015b  mov r9d, 0x100
00007dd052fd0161  cmp r10, r9
00007dd052fd0164  cmc
00007dd052fd0165  lahf
00007dd052fd0166  seto al
00007dd052fd0169  mov [r15+0x108], eax
00007dd052fd0170  lea eax, [r11d+r14d*1]
00007dd052fd0175  mov eax, eax
00007dd052fd0177  mov [r15+0xA8], rax
00007dd052fd017e  mov r12d, r12d
00007dd052fd0181  mov [r15+0xB0], r12
00007dd052fd0188  mov eax, [rsp+0x10]
00007dd052fd018c  mov eax, eax
00007dd052fd018e  mov [r15+0xC0], rax
00007dd052fd0195  mov r8d, r8d
00007dd052fd0198  mov [r15+0xC8], r8
00007dd052fd019f  mov eax, [r15+0x108]
00007dd052fd01a6  sahf
00007dd052fd01a7  jnz 0x00007DD052FD01D9
00007dd052fd01a9  cmp dword ptr [r15+0x318], 0x00
00007dd052fd01b1  jz 0x00007DD052FD04A0
00007dd052fd01b7  nop [rax+rax*1], ax
00007dd052fd01c0  nop [rax+rax*1], eax
00007dd052fd01c8  mov eax, 0x41094C
00007dd052fd01cd  mov [r15+0x100], rax
00007dd052fd01d4  jmp 0x00007DD052DFE110
00007dd052fd01d9  cmp dword ptr [r15+0x318], 0x00
00007dd052fd01e1  jz 0x00007DD052FD0270
00007dd052fd01e7  nop [rax+rax*1], ax
00007dd052fd01f0  nop [rax+rax*1], eax
00007dd052fd01f8  mov eax, 0x4108C0
00007dd052fd01fd  mov [r15+0x100], rax
00007dd052fd0204  jmp 0x00007DD052DFE110
00007dd052fd0209  int3
00007dd052fd020a  call 0x00007DD052E0DAE0
00007dd052fd020f  jmp 0x00007DD052FCFF78
00007dd052fd0214  call 0x00007DD052EC0230
00007dd052fd0219  jmp 0x00007DD052FCFF81
00007dd052fd021e  call 0x00007DD052EE26A0
00007dd052fd0223  jmp 0x00007DD052FCFFA5
00007dd052fd0228  call 0x00007DD052EE1430
00007dd052fd022d  jmp 0x00007DD052FCFFAE
00007dd052fd0232  call 0x00007DD052EE26A0
00007dd052fd0237  jmp 0x00007DD052FCFFCF
00007dd052fd023c  call 0x00007DD052EE1430
00007dd052fd0241  jmp 0x00007DD052FCFFD8
00007dd052fd0246  call 0x00007DD052EE26A0
00007dd052fd024b  jmp 0x00007DD052FCFFF9
00007dd052fd0250  call 0x00007DD052ED5890
00007dd052fd0255  jmp 0x00007DD052FD0002
00007dd052fd025a  call 0x00007DD052EBDD50
00007dd052fd025f  jmp 0x00007DD052FD0098
00007dd052fd0264  call 0x00007DD052EDA580
00007dd052fd0269  jmp 0x00007DD052FD00CF
00007dd052fd026e  int3
00007dd052fd026f  nop
00007dd052fd0270  mov eax, [r15+0xB8]
00007dd052fd0277  mov [rsp+0x10], eax
00007dd052fd027b  mov eax, eax
00007dd052fd027d  mov [r15+0x30], rax
00007dd052fd0281  mov eax, [r15+0xC0]
00007dd052fd0288  mov [rsp+0x20], eax
00007dd052fd028c  mov eax, eax
00007dd052fd028e  mov [r15+0xA0], rax
00007dd052fd0295  mov eax, [r15+0x28]
00007dd052fd0299  mov r14d, [r15+0x98]
00007dd052fd02a0  mov [rsp+0x30], r14d
00007dd052fd02a5  mov r14d, r14d
00007dd052fd02a8  mov [r15+0x28], r14
00007dd052fd02ac  mov r14d, [r15+0x38]
00007dd052fd02b0  mov [rsp+0x40], r14d
00007dd052fd02b5  mov r14d, r14d
00007dd052fd02b8  mov [r15+0x98], r14
00007dd052fd02bf  mov r14d, [r15+0xA8]
00007dd052fd02c6  mov [rsp+0x50], r14d
00007dd052fd02cb  mov r14d, r14d
00007dd052fd02ce  mov [r15+0x38], r14
00007dd052fd02d2  mov r14d, [rsp+0x10]
00007dd052fd02d7  mov r12d, [rsp+0x10]
00007dd052fd02dc  shrd r14d, r12d, 0x06
00007dd052fd02e1  mov r11d, [r15+0xC8]
00007dd052fd02e8  mov [rsp+0x10], r12d
00007dd052fd02ed  and r12d, r11d
00007dd052fd02f0  mov r10d, [rsp+0x50]
00007dd052fd02f5  mov r9d, [rsp+0x50]
00007dd052fd02fa  shrd r10d, r9d, 0x02
00007dd052fd02ff  mov [rsp+0x50], r11d
00007dd052fd0304  mov r11d, r11d
00007dd052fd0307  mov [r15+0x20], r11
00007dd052fd030b  mov r11, [r15+0x88]
00007dd052fd0312  mov r8, [r15+0x50]
00007dd052fd0316  lea rbp, [r8+r11*1]
00007dd052fd031a  mov r8d, [r13+rbp*1]
00007dd052fd031f  mov ebp, [rsp+0x20]
00007dd052fd0323  mov edi, [rsp+0x10]
00007dd052fd0327  andn esi, edi, ebp
00007dd052fd032c  mov edx, [r15+0xB0]
00007dd052fd0333  lea ecx, [r12d+edx*1]
00007dd052fd0338  rorx r12d, edi, 0x0B
00007dd052fd033e  xor r14d, r12d
00007dd052fd0341  rorx r12d, r9d, 0x0D
00007dd052fd0347  xor r10d, r12d
00007dd052fd034a  lea r12d, [ecx+esi*1]
00007dd052fd034f  mov rsi, [r15+0x48]
00007dd052fd0353  lea rdx, [rsi+r11*1]
00007dd052fd0357  mov esi, [r13+rdx*1]
00007dd052fd035c  mov edx, [rsp+0x30]
00007dd052fd0360  mov ecx, [rsp+0x40]
00007dd052fd0364  and edx, ecx
00007dd052fd0366  mov [rsp+0x10], edx
00007dd052fd036a  mov edx, edx
00007dd052fd036c  mov [r15+0xD8], rdx
00007dd052fd0373  lea edx, [r12d+r8d*1]
00007dd052fd0378  mov r12d, [rsp+0x30]
00007dd052fd037d  xor r12d, ecx
00007dd052fd0380  rorx r8d, edi, 0x19
00007dd052fd0386  xor r14d, r8d
00007dd052fd0389  and r12d, r9d
00007dd052fd038c  rorx r8d, r9d, 0x16
00007dd052fd0392  xor r10d, r8d
00007dd052fd0395  mov [rsp+0x20], r10d
00007dd052fd039a  mov r10d, r10d
00007dd052fd039d  mov [r15+0xD0], r10
00007dd052fd03a4  lea r10d, [edx+esi*1]
00007dd052fd03a9  mov r9d, [rsp+0x10]
00007dd052fd03ae  xor r12d, r9d
00007dd052fd03b1  lea r9d, [r10d+r14d*1]
00007dd052fd03b6  lea r14, [r11+0x04]
00007dd052fd03ba  mov [r15+0x88], r14
00007dd052fd03c1  mov r11d, [rsp+0x20]
00007dd052fd03c6  lea r10d, [r12d+r11d*1]
00007dd052fd03cb  lea r11d, [r9d+eax*1]
00007dd052fd03d0  mov r11d, r11d
00007dd052fd03d3  mov [r15+0xB8], r11
00007dd052fd03da  xor eax, eax
00007dd052fd03dc  mov r12d, 0x100
00007dd052fd03e2  cmp r14, r12
00007dd052fd03e5  cmc
00007dd052fd03e6  lahf
00007dd052fd03e7  seto al
00007dd052fd03ea  mov [r15+0x108], eax
00007dd052fd03f1  lea eax, [r10d+r9d*1]
00007dd052fd03f6  mov eax, eax
00007dd052fd03f8  mov [r15+0xA8], rax
00007dd052fd03ff  mov ebp, ebp
00007dd052fd0401  mov [r15+0xB0], rbp
00007dd052fd0408  mov eax, [rsp+0x50]
00007dd052fd040c  mov eax, eax
00007dd052fd040e  mov [r15+0xC0], rax
00007dd052fd0415  mov edi, edi
00007dd052fd0417  mov [r15+0xC8], rdi
00007dd052fd041e  mov eax, [r15+0x108]
00007dd052fd0425  sahf
00007dd052fd0426  jnz 0x00007DD052FD0458
00007dd052fd0428  cmp dword ptr [r15+0x318], 0x00
00007dd052fd0430  jz 0x00007DD052FD04A0
00007dd052fd0436  nop [rax+rax*1], ax
00007dd052fd043f  nop [rax+rax*1], eax
00007dd052fd0447  mov eax, 0x41094C
00007dd052fd044c  mov [r15+0x100], rax
00007dd052fd0453  jmp 0x00007DD052DFE110
00007dd052fd0458  cmp dword ptr [r15+0x318], 0x00
00007dd052fd0460  jz 0x00007DD052FD0270
00007dd052fd0466  nop [rax+rax*1], ax
00007dd052fd046f  nop [rax+rax*1], eax
00007dd052fd0477  mov eax, 0x4108C0
00007dd052fd047c  mov [r15+0x100], rax
00007dd052fd0483  jmp 0x00007DD052DFE110
00007dd052fd0488  int3
00007dd052fd0489  call 0x00007DD052E49010
00007dd052fd048e  jmp 0x00007DD052FD031F
00007dd052fd0493  call 0x00007DD052E25930
00007dd052fd0498  jmp 0x00007DD052FD035C
00007dd052fd049d  int3
00007dd052fd049e  nop
00007dd052fd04a0  mov eax, [r15+0x98]
00007dd052fd04a7  mov r14d, [r15+0x70]
00007dd052fd04ab  lea r12d, [eax+r14d*1]
00007dd052fd04b0  mov eax, [r15+0x28]
00007dd052fd04b4  mov r14d, [r15+0x68]
00007dd052fd04b8  lea r11d, [eax+r14d*1]
00007dd052fd04bd  mov qword ptr [r15+0x88], 0x00
00007dd052fd04c8  mov eax, [r15+0xA8]
00007dd052fd04cf  mov r14d, [r15+0x78]
00007dd052fd04d3  lea r10d, [eax+r14d*1]
00007dd052fd04d8  mov [rsp+0x10], r10d
00007dd052fd04dd  mov r10d, r10d
00007dd052fd04e0  mov [r15+0x78], r10
00007dd052fd04e4  mov eax, [r15+0x38]
00007dd052fd04e8  mov r14d, [r15+0x80]
00007dd052fd04ef  lea r10d, [eax+r14d*1]
00007dd052fd04f4  mov [rsp+0x20], r10d
00007dd052fd04f9  mov r10d, r10d
00007dd052fd04fc  mov [r15+0x80], r10
00007dd052fd0503  mov rax, [r15]
00007dd052fd0506  lea r14, [rax+0x08]
00007dd052fd050a  mov [r13+r14*1], r12d
00007dd052fd050f  lea r14, [rax+0x0C]
00007dd052fd0513  mov [r13+r14*1], r11d
00007dd052fd0518  mov r14d, [r15+0xB8]
00007dd052fd051f  mov r12d, [r15+0x18]
00007dd052fd0523  lea r11d, [r14d+r12d*1]
00007dd052fd0528  mov [rsp+0x30], r11d
00007dd052fd052d  mov r11d, r11d
00007dd052fd0530  mov [r15+0x68], r11
00007dd052fd0534  mov r14d, [r15+0x30]
00007dd052fd0538  mov r12d, [r15+0x90]
00007dd052fd053f  lea r11d, [r14d+r12d*1]
00007dd052fd0544  mov [rsp+0x40], r11d
00007dd052fd0549  mov r11d, r11d
00007dd052fd054c  mov [r15+0x70], r11
00007dd052fd0550  mov r14d, [r15+0x20]
00007dd052fd0554  mov r12d, [r15+0x58]
00007dd052fd0558  lea r11d, [r14d+r12d*1]
00007dd052fd055d  mov [rsp+0x50], r11d
00007dd052fd0562  mov r11d, r11d
00007dd052fd0565  mov [r15+0x58], r11
00007dd052fd0569  mov r14d, [r15+0xA0]
00007dd052fd0570  mov r12d, [r15+0x60]
00007dd052fd0574  lea r11d, [r14d+r12d*1]
00007dd052fd0579  mov [rsp+0x60], r11d
00007dd052fd057e  mov r11d, r11d
00007dd052fd0581  mov [r15+0x60], r11
00007dd052fd0585  mov r14d, [rsp+0x10]
00007dd052fd058a  mov [r13+rax*1], r14d
00007dd052fd058f  lea r14, [rax+0x04]
00007dd052fd0593  mov r12d, [rsp+0x20]
00007dd052fd0598  mov [r13+r14*1], r12d
00007dd052fd059d  lea r14, [rax+0x10]
00007dd052fd05a1  mov r12d, [rsp+0x30]
00007dd052fd05a6  mov [r13+r14*1], r12d
00007dd052fd05ab  lea r14, [rax+0x14]
00007dd052fd05af  mov r12d, [rsp+0x40]
00007dd052fd05b4  mov [r13+r14*1], r12d
00007dd052fd05b9  lea r14, [rax+0x18]
00007dd052fd05bd  mov r12d, [rsp+0x50]
00007dd052fd05c2  mov [r13+r14*1], r12d
00007dd052fd05c7  lea r14, [rax+0x1C]
00007dd052fd05cb  mov r12d, [rsp+0x60]
00007dd052fd05d0  mov [r13+r14*1], r12d
00007dd052fd05d5  lea r14, [rax+0x68]
00007dd052fd05d9  xor eax, eax
00007dd052fd05db  mov [r13+r14*1], rax
00007dd052fd05e0  cmp dword ptr [r15+0x318], 0x00
00007dd052fd05e8  jz 0x00007DD052FCF0E0
00007dd052fd05ee  nop [rax+rax*1], ax
00007dd052fd05f7  nop [rax+rax*1], eax
00007dd052fd05ff  mov eax, 0x410768
00007dd052fd0604  mov [r15+0x100], rax
00007dd052fd060b  jmp 0x00007DD052DFE110
00007dd052fd0610  int3
00007dd052fd0611  call 0x00007DD052EE2BA0
00007dd052fd0616  jmp 0x00007DD052FD050F
00007dd052fd061b  call 0x00007DD052EE1920
00007dd052fd0620  jmp 0x00007DD052FD0518
00007dd052fd0625  call 0x00007DD052E0DFE0
00007dd052fd062a  jmp 0x00007DD052FD058F
00007dd052fd062f  call 0x00007DD052EE2BA0
00007dd052fd0634  jmp 0x00007DD052FD059D
00007dd052fd0639  call 0x00007DD052EE2BA0
00007dd052fd063e  jmp 0x00007DD052FD05AB
00007dd052fd0643  call 0x00007DD052EE2BA0
00007dd052fd0648  jmp 0x00007DD052FD05B9
00007dd052fd064d  call 0x00007DD052EE2BA0
00007dd052fd0652  jmp 0x00007DD052FD05C7
00007dd052fd0657  call 0x00007DD052EE2BA0
00007dd052fd065c  jmp 0x00007DD052FD05D5
00007dd052fd0661  call 0x00007DD052ED5EB0
00007dd052fd0666  jmp 0x00007DD052FD05E0
00007dd052fd066b  int3
00007dd052fd066c  nop [rax], eax
00007dd052fd0670  mov rax, [r15+0xF8]
00007dd052fd0677  lea r14, [rax+0x140]
00007dd052fd067e  mov r12, [r13+r14*1]
00007dd052fd0683  lea r14, [rax+0x148]
00007dd052fd068a  mov r11, [r13+r14*1]
00007dd052fd068f  mov [r15+0xA0], r12
00007dd052fd0696  mov [r15+0x98], r11
00007dd052fd069d  lea r14, [rax+0x130]
00007dd052fd06a4  mov r12, [r13+r14*1]
00007dd052fd06a9  lea r14, [rax+0x138]
00007dd052fd06b0  mov r11, [r13+r14*1]
00007dd052fd06b5  mov [r15+0xB0], r12
00007dd052fd06bc  mov [r15+0xA8], r11
00007dd052fd06c3  lea r14, [rax+0x120]
00007dd052fd06ca  mov r12, [r13+r14*1]
00007dd052fd06cf  lea r14, [rax+0x128]
00007dd052fd06d6  mov r11, [r13+r14*1]
00007dd052fd06db  mov [r15+0xC0], r12
00007dd052fd06e2  mov [r15+0xB8], r11
00007dd052fd06e9  lea r14, [rax+0x110]
00007dd052fd06f0  mov r12, [r13+r14*1]
00007dd052fd06f5  lea r14, [rax+0x118]
00007dd052fd06fc  mov r11, [r13+r14*1]
00007dd052fd0701  mov [r15+0xD0], r12
00007dd052fd0708  mov [r15+0xC8], r11
00007dd052fd070f  lea r14, [rax+0x100]
00007dd052fd0716  mov r12, [r13+r14*1]
00007dd052fd071b  lea r14, [rax+0x108]
00007dd052fd0722  mov r11, [r13+r14*1]
00007dd052fd0727  mov [r15+0xE8], r12
00007dd052fd072e  mov [r15+0xD8], r11
00007dd052fd0735  lea r14, [rax+0x150]
00007dd052fd073c  mov [r15+0xF8], r14
00007dd052fd0743  mov rax, [r15+0xF0]
00007dd052fd074a  mov [r15+0x100], rax
00007dd052fd0751  jmp 0x00007DD052FCE5C0
00007dd052fd0756  int3
00007dd052fd0757  call 0x00007DD052EE27E0
00007dd052fd075c  jmp 0x00007DD052FD0683
00007dd052fd0761  call 0x00007DD052EE1570
00007dd052fd0766  jmp 0x00007DD052FD068F
00007dd052fd076b  call 0x00007DD052EE27E0
00007dd052fd0770  jmp 0x00007DD052FD06A9
00007dd052fd0775  call 0x00007DD052EE1570
00007dd052fd077a  jmp 0x00007DD052FD06B5
00007dd052fd077f  call 0x00007DD052EE27E0
00007dd052fd0784  jmp 0x00007DD052FD06CF
00007dd052fd0789  call 0x00007DD052EE1570
00007dd052fd078e  jmp 0x00007DD052FD06DB
00007dd052fd0793  call 0x00007DD052EE27E0
00007dd052fd0798  jmp 0x00007DD052FD06F5
00007dd052fd079d  call 0x00007DD052EE1570
00007dd052fd07a2  jmp 0x00007DD052FD0701
00007dd052fd07a7  call 0x00007DD052EE27E0
00007dd052fd07ac  jmp 0x00007DD052FD071B
00007dd052fd07b1  call 0x00007DD052EE1570
00007dd052fd07b6  jmp 0x00007DD052FD0727
00007dd052fd07bb  int3
00007dd052fd07bc  nop [rax], eax
00007dd052fd07c0  mov eax, [r15+0xA0]
00007dd052fd07c7  mov [rsp+0x10], eax
00007dd052fd07cb  xor eax, eax
00007dd052fd07cd  mov r14d, [rsp+0x10]
00007dd052fd07d2  sub r14d, 0x01
00007dd052fd07d6  cmc
00007dd052fd07d7  lahf
00007dd052fd07d8  seto al
00007dd052fd07db  mov [r15+0x108], eax
00007dd052fd07e2  mov r14d, r14d
00007dd052fd07e5  mov [r15+0xA0], r14
00007dd052fd07ec  mov eax, [r15+0x108]
00007dd052fd07f3  sahf
00007dd052fd07f4  jnz 0x00007DD052FD0826
00007dd052fd07f6  cmp dword ptr [r15+0x318], 0x00
00007dd052fd07fe  jz 0x00007DD052FD0900
00007dd052fd0804  nop [rax+rax*1], ax
00007dd052fd080d  nop [rax+rax*1], eax
00007dd052fd0815  mov eax, 0x41028C
00007dd052fd081a  mov [r15+0x100], rax
00007dd052fd0821  jmp 0x00007DD052DFE110
00007dd052fd0826  cmp dword ptr [r15+0x318], 0x00
00007dd052fd082e  jz 0x00007DD052FD0860
00007dd052fd0834  nop [rax+rax*1], ax
00007dd052fd083d  nop [rax+rax*1], eax
00007dd052fd0845  mov eax, 0x410274
00007dd052fd084a  mov [r15+0x100], rax
00007dd052fd0851  jmp 0x00007DD052DFE110
00007dd052fd0856  int3
00007dd052fd0857  int3
00007dd052fd0858  nop [rax+rax*1], eax
00007dd052fd0860  mov rax, [r15+0xF8]
00007dd052fd0867  lea r14, [rax+0x100]
00007dd052fd086e  mov [r15], r14
00007dd052fd0871  mov rax, [r15+0x98]
00007dd052fd0878  mov [r15+0x08], rax
00007dd052fd087c  mov qword ptr [r15+0x10], 0x12C
00007dd052fd0884  mov qword ptr [r15+0xF0], 0x410284
00007dd052fd088f  mov r14d, [r15+0x320]
00007dd052fd0896  mov eax, 0x410284
00007dd052fd089b  mov rcx, 0x7DD052FD07C0
00007dd052fd08a5  mov [r15+r14*8+0x328], rax
00007dd052fd08ad  mov [r15+r14*8+0x368], rcx
00007dd052fd08b5  add r14d, 0x01
00007dd052fd08b9  and r14d, 0x07
00007dd052fd08bd  mov [r15+0x320], r14d
00007dd052fd08c4  cmp dword ptr [r15+0x318], 0x00
00007dd052fd08cc  jz 0x00007DD052FCED70
00007dd052fd08d2  nop [rax+rax*1], ax
00007dd052fd08db  nop [rax+rax*1], eax
00007dd052fd08e3  mov eax, 0x410728
00007dd052fd08e8  mov [r15+0x100], rax
00007dd052fd08ef  jmp 0x00007DD052DFE110
00007dd052fd08f4  int3
00007dd052fd08f5  int3
00007dd052fd08f6  nop [rax+rax*1], ax
00007dd052fd08ff  nop
00007dd052fd0900  mov rax, [r15+0xF8]
00007dd052fd0907  lea r14, [rax+0x120]
00007dd052fd090e  mov r12, [r13+r14*1]
00007dd052fd0913  mov [r15+0x98], r12
00007dd052fd091a  mov qword ptr [r15+0x40], 0x80
00007dd052fd0922  lea r14, [rax+0x100]
00007dd052fd0929  mov [r15], r14
00007dd052fd092c  lea r14, [rax+0x17C]
00007dd052fd0933  mov [r15+0x08], r14
00007dd052fd0937  mov qword ptr [r15+0x10], 0x01
00007dd052fd093f  lea r14, [rax+0x17C]
00007dd052fd0946  mov eax, 0x80
00007dd052fd094b  mov [r13+r14*1], al
00007dd052fd0950  mov qword ptr [r15+0xF0], 0x4102A8
00007dd052fd095b  mov r14d, [r15+0x320]
00007dd052fd0962  mov eax, 0x4102A8
00007dd052fd0967  mov rcx, 0x7DD052FD09E0
00007dd052fd0971  mov [r15+r14*8+0x328], rax
00007dd052fd0979  mov [r15+r14*8+0x368], rcx
00007dd052fd0981  add r14d, 0x01
00007dd052fd0985  and r14d, 0x07
00007dd052fd0989  mov [r15+0x320], r14d
00007dd052fd0990  cmp dword ptr [r15+0x318], 0x00
00007dd052fd0998  jz 0x00007DD052FCED70
00007dd052fd099e  nop [rax+rax*1], ax
00007dd052fd09a7  nop [rax+rax*1], eax
00007dd052fd09af  mov eax, 0x410728
00007dd052fd09b4  mov [r15+0x100], rax
00007dd052fd09bb  jmp 0x00007DD052DFE110
00007dd052fd09c0  int3
00007dd052fd09c1  call 0x00007DD052EE27E0
00007dd052fd09c6  jmp 0x00007DD052FD0913
00007dd052fd09cb  call 0x00007DD052ED5AF0
00007dd052fd09d0  jmp 0x00007DD052FD0950
00007dd052fd09d5  int3
00007dd052fd09d6  nop [rax+rax*1], ax
00007dd052fd09df  nop
00007dd052fd09e0  mov rax, [r15+0xF8]
00007dd052fd09e7  lea r14, [rax+0x168]
00007dd052fd09ee  mov r12, [r13+r14*1]
00007dd052fd09f3  mov [r15+0x40], r12
00007dd052fd09f7  lea r14, [rax+0x178]
00007dd052fd09fe  xor eax, eax
00007dd052fd0a00  mov [r13+r14*1], al
00007dd052fd0a05  xor eax, eax
00007dd052fd0a07  mov r14d, 0x38
00007dd052fd0a0d  cmp r12, r14
00007dd052fd0a10  cmc
00007dd052fd0a11  lahf
00007dd052fd0a12  seto al
00007dd052fd0a15  mov [r15+0x108], eax
00007dd052fd0a1c  mov eax, [r15+0x108]
00007dd052fd0a23  sahf
00007dd052fd0a24  jz 0x00007DD052FD0A56
00007dd052fd0a26  cmp dword ptr [r15+0x318], 0x00
00007dd052fd0a2e  jz 0x00007DD052FD0AA0
00007dd052fd0a34  nop [rax+rax*1], ax
00007dd052fd0a3d  nop [rax+rax*1], eax
00007dd052fd0a45  mov eax, 0x4102B8
00007dd052fd0a4a  mov [r15+0x100], rax
00007dd052fd0a51  jmp 0x00007DD052DFE110
00007dd052fd0a56  cmp dword ptr [r15+0x318], 0x00
00007dd052fd0a5e  jz 0x00007DD052FD0BF0
00007dd052fd0a64  nop [rax+rax*1], ax
00007dd052fd0a6d  nop [rax+rax*1], eax
00007dd052fd0a75  mov eax, 0x4102D4
00007dd052fd0a7a  mov [r15+0x100], rax
00007dd052fd0a81  jmp 0x00007DD052DFE110
00007dd052fd0a86  int3
00007dd052fd0a87  call 0x00007DD052EE27E0
00007dd052fd0a8c  jmp 0x00007DD052FD09F3
00007dd052fd0a91  call 0x00007DD052ED5AF0
00007dd052fd0a96  jmp 0x00007DD052FD0A05
00007dd052fd0a9b  int3
00007dd052fd0a9c  nop [rax], eax
00007dd052fd0aa0  mov rax, [r15+0xF8]
00007dd052fd0aa7  lea r14, [rax+0x100]
00007dd052fd0aae  mov [r15], r14
00007dd052fd0ab1  lea r14, [rax+0x178]
00007dd052fd0ab8  mov [r15+0x08], r14
00007dd052fd0abc  mov qword ptr [r15+0x10], 0x01
00007dd052fd0ac4  mov qword ptr [r15+0xF0], 0x4102C8
00007dd052fd0acf  mov r14d, [r15+0x320]
00007dd052fd0ad6  mov eax, 0x4102C8
00007dd052fd0adb  mov rcx, 0x7DD052FD0B40
00007dd052fd0ae5  mov [r15+r14*8+0x328], rax
00007dd052fd0aed  mov [r15+r14*8+0x368], rcx
00007dd052fd0af5  add r14d, 0x01
00007dd052fd0af9  and r14d, 0x07
00007dd052fd0afd  mov [r15+0x320], r14d
00007dd052fd0b04  cmp dword ptr [r15+0x318], 0x00
00007dd052fd0b0c  jz 0x00007DD052FCED70
00007dd052fd0b12  nop [rax+rax*1], ax
00007dd052fd0b1b  nop [rax+rax*1], eax
00007dd052fd0b23  mov eax, 0x410728
00007dd052fd0b28  mov [r15+0x100], rax
00007dd052fd0b2f  jmp 0x00007DD052DFE110
00007dd052fd0b34  int3
00007dd052fd0b35  int3
00007dd052fd0b36  nop [rax+rax*1], ax
00007dd052fd0b3f  nop
00007dd052fd0b40  mov rax, [r15+0xF8]
00007dd052fd0b47  lea r14, [rax+0x168]
00007dd052fd0b4e  mov rax, [r13+r14*1]
00007dd052fd0b53  mov [r15+0x40], rax
00007dd052fd0b57  mov [rsp+0x10], rax
00007dd052fd0b5c  xor eax, eax
00007dd052fd0b5e  mov r14, [rsp+0x10]
00007dd052fd0b63  mov r12d, 0x38
00007dd052fd0b69  cmp r14, r12
00007dd052fd0b6c  cmc
00007dd052fd0b6d  lahf
00007dd052fd0b6e  seto al
00007dd052fd0b71  mov [r15+0x108], eax
00007dd052fd0b78  mov eax, [r15+0x108]
00007dd052fd0b7f  sahf
00007dd052fd0b80  jnz 0x00007DD052FD0BB2
00007dd052fd0b82  cmp dword ptr [r15+0x318], 0x00
00007dd052fd0b8a  jz 0x00007DD052FD0BF0
00007dd052fd0b90  nop [rax+rax*1], ax
00007dd052fd0b99  nop [rax+rax*1], eax
00007dd052fd0ba1  mov eax, 0x4102D4
00007dd052fd0ba6  mov [r15+0x100], rax
00007dd052fd0bad  jmp 0x00007DD052DFE110
00007dd052fd0bb2  cmp dword ptr [r15+0x318], 0x00
00007dd052fd0bba  jz 0x00007DD052FD0AA0
00007dd052fd0bc0  nop [rax+rax*1], ax
00007dd052fd0bc9  nop [rax+rax*1], eax
00007dd052fd0bd1  mov eax, 0x4102B8
00007dd052fd0bd6  mov [r15+0x100], rax
00007dd052fd0bdd  jmp 0x00007DD052DFE110
00007dd052fd0be2  int3
00007dd052fd0be3  call 0x00007DD052ED59C0
00007dd052fd0be8  jmp 0x00007DD052FD0B53
00007dd052fd0bed  int3
00007dd052fd0bee  nop
00007dd052fd0bf0  mov rax, [r15+0x98]
00007dd052fd0bf7  rorx r14, rax, 0x3D
00007dd052fd0bfd  and r14, 0xFFFFFFFFFFFFFFF8
00007dd052fd0c01  mov rax, [r15+0xF8]
00007dd052fd0c08  lea r12, [rax+0x100]
00007dd052fd0c0f  mov [r15], r12
00007dd052fd0c12  lea r12, [rax+0x170]
00007dd052fd0c19  mov [r15+0x08], r12
00007dd052fd0c1d  mov qword ptr [r15+0x10], 0x08
00007dd052fd0c25  bswap r14
00007dd052fd0c28  mov [r15+0x40], r14
00007dd052fd0c2c  lea r12, [rax+0x170]
00007dd052fd0c33  mov [r13+r12*1], r14
00007dd052fd0c38  mov qword ptr [r15+0xF0], 0x4102F0
00007dd052fd0c43  mov r14d, [r15+0x320]
00007dd052fd0c4a  mov eax, 0x4102F0
00007dd052fd0c4f  mov rcx, 0x7DD052FD0CC0
00007dd052fd0c59  mov [r15+r14*8+0x328], rax
00007dd052fd0c61  mov [r15+r14*8+0x368], rcx
00007dd052fd0c69  add r14d, 0x01
00007dd052fd0c6d  and r14d, 0x07
00007dd052fd0c71  mov [r15+0x320], r14d
00007dd052fd0c78  cmp dword ptr [r15+0x318], 0x00
00007dd052fd0c80  jz 0x00007DD052FCED70
00007dd052fd0c86  nop [rax+rax*1], ax
00007dd052fd0c8f  nop [rax+rax*1], eax
00007dd052fd0c97  mov eax, 0x410728
00007dd052fd0c9c  mov [r15+0x100], rax
00007dd052fd0ca3  jmp 0x00007DD052DFE110
00007dd052fd0ca8  int3
00007dd052fd0ca9  call 0x00007DD052EC3FE0
00007dd052fd0cae  jmp 0x00007DD052FD0C38
00007dd052fd0cb3  int3
00007dd052fd0cb4  nop [rax+rax*1], ax
00007dd052fd0cbd  nop [rax], eax
00007dd052fd0cc0  mov rax, [r15+0xF8]
00007dd052fd0cc7  lea r14, [rax+0x100]
00007dd052fd0cce  mov r12d, [r13+r14*1]
00007dd052fd0cd3  lea r14, [rax+0x104]
00007dd052fd0cda  mov r11d, [r13+r14*1]
00007dd052fd0cdf  mov qword ptr [r15+0x48], 0x430C90
00007dd052fd0ce7  lea r14, [rax+0x108]
00007dd052fd0cee  mov r10d, [r13+r14*1]
00007dd052fd0cf3  lea r14, [rax+0x10C]
00007dd052fd0cfa  mov r9d, [r13+r14*1]
00007dd052fd0cff  bswap r12d
00007dd052fd0d02  bswap r11d
00007dd052fd0d05  mov qword ptr [r15+0xA0], 0x00
00007dd052fd0d10  mov r14d, 0x430C90
00007dd052fd0d16  mov [r13+r14*1], r12d
00007dd052fd0d1b  mov r14d, 0x430C94
00007dd052fd0d21  mov [r13+r14*1], r11d
00007dd052fd0d26  bswap r10d
00007dd052fd0d29  lea r14, [rax+0x110]
00007dd052fd0d30  mov r12d, [r13+r14*1]
00007dd052fd0d35  bswap r9d
00007dd052fd0d38  lea r14, [rax+0x114]
00007dd052fd0d3f  mov r11d, [r13+r14*1]
00007dd052fd0d44  mov qword ptr [r15+0x98], 0x430DFC
00007dd052fd0d4f  mov r14d, 0x430C98
00007dd052fd0d55  mov [r13+r14*1], r10d
00007dd052fd0d5a  mov r14d, 0x430C9C
00007dd052fd0d60  mov [r13+r14*1], r9d
00007dd052fd0d65  bswap r12d
00007dd052fd0d68  lea r14, [rax+0x118]
00007dd052fd0d6f  mov r10d, [r13+r14*1]
00007dd052fd0d74  bswap r11d
00007dd052fd0d77  mov [rsp+0x10], r11d
00007dd052fd0d7c  mov r11d, r11d
00007dd052fd0d7f  mov [r15+0x58], r11
00007dd052fd0d83  lea r14, [rax+0x11C]
00007dd052fd0d8a  mov eax, [r13+r14*1]
00007dd052fd0d8f  mov [rsp+0x20], eax
00007dd052fd0d93  mov eax, eax
00007dd052fd0d95  mov [r15+0x60], rax
00007dd052fd0d99  mov eax, 0x430CA0
00007dd052fd0d9e  mov [r13+rax*1], r12d
00007dd052fd0da3  mov eax, 0x430CA4
00007dd052fd0da8  mov r14d, [rsp+0x10]
00007dd052fd0dad  mov [r13+rax*1], r14d
00007dd052fd0db2  bswap r10d
00007dd052fd0db5  mov [rsp+0x10], r10d
00007dd052fd0dba  mov r10d, r10d
00007dd052fd0dbd  mov [r15+0x40], r10
00007dd052fd0dc1  mov eax, [rsp+0x20]
00007dd052fd0dc5  bswap eax
00007dd052fd0dc7  mov [rsp+0x20], eax
00007dd052fd0dcb  mov eax, eax
00007dd052fd0dcd  mov [r15+0x50], rax
00007dd052fd0dd1  mov eax, 0x430CA8
00007dd052fd0dd6  mov r14d, [rsp+0x10]
00007dd052fd0ddb  mov [r13+rax*1], r14d
00007dd052fd0de0  mov eax, 0x430CAC
00007dd052fd0de5  mov r14d, [rsp+0x20]
00007dd052fd0dea  mov [r13+rax*1], r14d
00007dd052fd0def  mov eax, [r15+0xA0]
00007dd052fd0df6  lea r14d, [eax+0x11]
00007dd052fd0dfb  mov r14d, r14d
00007dd052fd0dfe  mov [r15], r14
00007dd052fd0e01  mov qword ptr [r15+0xF0], 0x41035C
00007dd052fd0e0c  mov r14d, [r15+0x320]
00007dd052fd0e13  mov eax, 0x41035C
00007dd052fd0e18  mov rcx, 0x7DD052FD0F90
00007dd052fd0e22  mov [r15+r14*8+0x328], rax
00007dd052fd0e2a  mov [r15+r14*8+0x368], rcx
00007dd052fd0e32  add r14d, 0x01
00007dd052fd0e36  and r14d, 0x07
00007dd052fd0e3a  mov [r15+0x320], r14d
00007dd052fd0e41  cmp dword ptr [r15+0x318], 0x00
00007dd052fd0e49  jz 0x00007DD052FD0F20
00007dd052fd0e4f  nop [rax+rax*1], ax
00007dd052fd0e58  nop [rax+rax*1], eax
00007dd052fd0e60  mov eax, 0x4109A4
00007dd052fd0e65  mov [r15+0x100], rax
00007dd052fd0e6c  jmp 0x00007DD052DFE110
00007dd052fd0e71  int3
00007dd052fd0e72  call 0x00007DD052EE26A0
00007dd052fd0e77  jmp 0x00007DD052FD0CD3
00007dd052fd0e7c  call 0x00007DD052EE1430
00007dd052fd0e81  jmp 0x00007DD052FD0CDF
00007dd052fd0e86  call 0x00007DD052EE01C0
00007dd052fd0e8b  jmp 0x00007DD052FD0CF3
00007dd052fd0e90  call 0x00007DD052EDEF50
00007dd052fd0e95  jmp 0x00007DD052FD0CFF
00007dd052fd0e9a  call 0x00007DD052EE2BA0
00007dd052fd0e9f  jmp 0x00007DD052FD0D1B
00007dd052fd0ea4  call 0x00007DD052EE1920
00007dd052fd0ea9  jmp 0x00007DD052FD0D26
00007dd052fd0eae  call 0x00007DD052EE26A0
00007dd052fd0eb3  jmp 0x00007DD052FD0D35
00007dd052fd0eb8  call 0x00007DD052EE1430
00007dd052fd0ebd  jmp 0x00007DD052FD0D44
00007dd052fd0ec2  call 0x00007DD052EE06B0
00007dd052fd0ec7  jmp 0x00007DD052FD0D5A
00007dd052fd0ecc  call 0x00007DD052EDF440
00007dd052fd0ed1  jmp 0x00007DD052FD0D65
00007dd052fd0ed6  call 0x00007DD052EE01C0
00007dd052fd0edb  jmp 0x00007DD052FD0D74
00007dd052fd0ee0  call 0x00007DD052ED5890
00007dd052fd0ee5  jmp 0x00007DD052FD0D8F
00007dd052fd0eea  call 0x00007DD052E0BAE0
00007dd052fd0eef  jmp 0x00007DD052FD0DA3
00007dd052fd0ef4  call 0x00007DD052E0DFE0
00007dd052fd0ef9  jmp 0x00007DD052FD0DB2
00007dd052fd0efe  call 0x00007DD052E0DFE0
00007dd052fd0f03  jmp 0x00007DD052FD0DE0
00007dd052fd0f08  call 0x00007DD052E0DFE0
00007dd052fd0f0d  jmp 0x00007DD052FD0DEF
00007dd052fd0f12  int3
00007dd052fd0f13  nop [rax+rax*1], ax
00007dd052fd0f1c  nop [rax], eax
00007dd052fd0f20  mov eax, [r15]
00007dd052fd0f23  mov [rsp+0x10], eax
00007dd052fd0f27  shr eax, 0x10
00007dd052fd0f2a  mov r14d, [rsp+0x10]
00007dd052fd0f2f  xor r14d, eax
00007dd052fd0f32  imul r14d, r14d, 0x7FEB352D
00007dd052fd0f39  mov eax, 0x846CA68B
00007dd052fd0f3e  mov eax, eax
00007dd052fd0f40  mov [r15+0x48], rax
00007dd052fd0f44  mov [rsp+0x10], r14d
00007dd052fd0f49  shr r14d, 0x0F
00007dd052fd0f4d  mov eax, [rsp+0x10]
00007dd052fd0f51  xor eax, r14d
00007dd052fd0f54  imul eax, eax, 0x846CA68B
00007dd052fd0f5a  mov [rsp+0x10], eax
00007dd052fd0f5e  mov eax, eax
00007dd052fd0f60  mov [r15+0x40], rax
00007dd052fd0f64  mov eax, [rsp+0x10]
00007dd052fd0f68  shr eax, 0x10
00007dd052fd0f6b  mov r14d, [rsp+0x10]
00007dd052fd0f70  xor r14d, eax
00007dd052fd0f73  mov r14d, r14d
00007dd052fd0f76  mov [r15], r14
00007dd052fd0f79  mov rax, [r15+0xF0]
00007dd052fd0f80  mov [r15+0x100], rax
00007dd052fd0f87  jmp 0x00007DD052FCE5C0
00007dd052fd0f8c  int3
00007dd052fd0f8d  int3
00007dd052fd0f8e  nop
00007dd052fd0f90  mov rax, [r15+0xA0]
00007dd052fd0f97  mov [rsp+0x10], rax
00007dd052fd0f9c  shl rax, 0x02
00007dd052fd0fa0  mov r14, [r15+0x98]
00007dd052fd0fa7  lea r12, [r14+rax*1]
00007dd052fd0fab  mov eax, [r15]
00007dd052fd0fae  mov [r13+r12*1], eax
00007dd052fd0fb3  mov rax, [rsp+0x10]
00007dd052fd0fb8  lea r14, [rax+0x01]
00007dd052fd0fbc  mov [r15+0xA0], r14
00007dd052fd0fc3  xor eax, eax
00007dd052fd0fc5  mov r12d, 0x400
00007dd052fd0fcb  cmp r14, r12
00007dd052fd0fce  cmc
00007dd052fd0fcf  lahf
00007dd052fd0fd0  seto al
00007dd052fd0fd3  mov [r15+0x108], eax
00007dd052fd0fda  mov eax, [r15+0x108]
00007dd052fd0fe1  sahf
00007dd052fd0fe2  jnz 0x00007DD052FD1014
00007dd052fd0fe4  cmp dword ptr [r15+0x318], 0x00
00007dd052fd0fec  jz 0x00007DD052FD10E0
00007dd052fd0ff2  nop [rax+rax*1], ax
00007dd052fd0ffb  nop [rax+rax*1], eax
00007dd052fd1003  mov eax, 0x41036C
00007dd052fd1008  mov [r15+0x100], rax
00007dd052fd100f  jmp 0x00007DD052DFE110
00007dd052fd1014  cmp dword ptr [r15+0x318], 0x00
00007dd052fd101c  jz 0x00007DD052FD1050
00007dd052fd1022  nop [rax+rax*1], ax
00007dd052fd102b  nop [rax+rax*1], eax
00007dd052fd1033  mov eax, 0x410354
00007dd052fd1038  mov [r15+0x100], rax
00007dd052fd103f  jmp 0x00007DD052DFE110
00007dd052fd1044  int3
00007dd052fd1045  call 0x00007DD052EB4B70
00007dd052fd104a  jmp 0x00007DD052FD0FB3
00007dd052fd104f  int3
00007dd052fd1050  mov eax, [r15+0xA0]
00007dd052fd1057  lea r14d, [eax+0x11]
00007dd052fd105c  mov r14d, r14d
00007dd052fd105f  mov [r15], r14
00007dd052fd1062  mov qword ptr [r15+0xF0], 0x41035C
00007dd052fd106d  mov r14d, [r15+0x320]
00007dd052fd1074  mov eax, 0x41035C
00007dd052fd1079  mov rcx, 0x7DD052FD0F90
00007dd052fd1083  mov [r15+r14*8+0x328], rax
00007dd052fd108b  mov [r15+r14*8+0x368], rcx
00007dd052fd1093  add r14d, 0x01
00007dd052fd1097  and r14d, 0x07
00007dd052fd109b  mov [r15+0x320], r14d
00007dd052fd10a2  cmp dword ptr [r15+0x318], 0x00
00007dd052fd10aa  jz 0x00007DD052FD0F20
00007dd052fd10b0  nop [rax+rax*1], ax
00007dd052fd10b9  nop [rax+rax*1], eax
00007dd052fd10c1  mov eax, 0x4109A4
00007dd052fd10c6  mov [r15+0x100], rax
00007dd052fd10cd  jmp 0x00007DD052DFE110
00007dd052fd10d2  int3
00007dd052fd10d3  int3
00007dd052fd10d4  nop [rax+rax*1], ax
00007dd052fd10dd  nop [rax], eax
00007dd052fd10e0  mov qword ptr [r15+0x40], 0x01
00007dd052fd10e8  cmp dword ptr [r15+0x318], 0x00
00007dd052fd10f0  jz 0x00007DD052FD1120
00007dd052fd10f6  nop [rax+rax*1], ax
00007dd052fd10ff  nop [rax+rax*1], eax
00007dd052fd1107  mov eax, 0x410388
00007dd052fd110c  mov [r15+0x100], rax
00007dd052fd1113  jmp 0x00007DD052DFE110
00007dd052fd1118  int3
00007dd052fd1119  int3
00007dd052fd111a  nop [rax+rax*1], ax
00007dd052fd1120  mov rax, [r15+0x40]
00007dd052fd1124  mov [rsp+0x10], rax
00007dd052fd1129  shl rax, 0x02
00007dd052fd112d  mov r14, [r15+0x98]
00007dd052fd1134  lea r12, [r14+rax*1]
00007dd052fd1138  mov eax, [r13+r12*1]
00007dd052fd113d  mov [rsp+0x20], eax
00007dd052fd1141  mov eax, eax
00007dd052fd1143  mov [r15+0x48], rax
00007dd052fd1147  mov rax, [rsp+0x10]
00007dd052fd114c  mov [r15+0x50], rax
00007dd052fd1150  mov eax, [r15+0x50]
00007dd052fd1154  lea r12d, [eax-0x01]
00007dd052fd1159  mov r12d, r12d
00007dd052fd115c  mov [r15+0x58], r12
00007dd052fd1160  mov rax, [r15+0x58]
00007dd052fd1164  mov r12d, eax
00007dd052fd1167  mov r12d, r12d
00007dd052fd116a  shl r12, 0x02
00007dd052fd116e  lea rax, [r14+r12*1]
00007dd052fd1172  mov r14d, [r13+rax*1]
00007dd052fd1177  mov [rsp+0x10], r14d
00007dd052fd117c  mov r14d, r14d
00007dd052fd117f  mov [r15+0x60], r14
00007dd052fd1183  xor eax, eax
00007dd052fd1185  mov r14d, [rsp+0x10]
00007dd052fd118a  mov r12d, [rsp+0x20]
00007dd052fd118f  cmp r14d, r12d
00007dd052fd1192  cmc
00007dd052fd1193  lahf
00007dd052fd1194  seto al
00007dd052fd1197  mov [r15+0x108], eax
00007dd052fd119e  mov eax, [r15+0x108]
00007dd052fd11a5  sahf
00007dd052fd11a6  cmc
00007dd052fd11a7  jbe 0x00007DD052FD11D9
00007dd052fd11a9  cmp dword ptr [r15+0x318], 0x00
00007dd052fd11b1  jz 0x00007DD052FD1220
00007dd052fd11b7  nop [rax+rax*1], ax
00007dd052fd11c0  nop [rax+rax*1], eax
00007dd052fd11c8  mov eax, 0x4103A0
00007dd052fd11cd  mov [r15+0x100], rax
00007dd052fd11d4  jmp 0x00007DD052DFE110
00007dd052fd11d9  cmp dword ptr [r15+0x318], 0x00
00007dd052fd11e1  jz 0x00007DD052FD14C0
00007dd052fd11e7  nop [rax+rax*1], ax
00007dd052fd11f0  nop [rax+rax*1], eax
00007dd052fd11f8  mov eax, 0x410378
00007dd052fd11fd  mov [r15+0x100], rax
00007dd052fd1204  jmp 0x00007DD052DFE110
00007dd052fd1209  int3
00007dd052fd120a  call 0x00007DD052EB4690
00007dd052fd120f  jmp 0x00007DD052FD113D
00007dd052fd1214  call 0x00007DD052E0DAE0
00007dd052fd1219  jmp 0x00007DD052FD1177
00007dd052fd121e  int3
00007dd052fd121f  nop
00007dd052fd1220  mov rax, [r15+0x50]
00007dd052fd1224  mov [rsp+0x10], rax
00007dd052fd1229  shl rax, 0x02
00007dd052fd122d  mov r14, [r15+0x98]
00007dd052fd1234  lea r12, [r14+rax*1]
00007dd052fd1238  mov eax, [r15+0x60]
00007dd052fd123c  mov [r13+r12*1], eax
00007dd052fd1241  mov rax, [rsp+0x10]
00007dd052fd1246  lea r14, [rax-0x01]
00007dd052fd124a  mov [r15+0x50], r14
00007dd052fd124e  mov rax, [r15+0x58]
00007dd052fd1252  test rax, rax
00007dd052fd1255  setz al
00007dd052fd1258  movzx rax, al
00007dd052fd125c  mov [rsp+0x414], al
00007dd052fd1263  cmp byte ptr [rsp+0x414], 0x00
00007dd052fd126b  jz 0x00007DD052FD129D
00007dd052fd126d  cmp dword ptr [r15+0x318], 0x00
00007dd052fd1275  jz 0x00007DD052FD12E0
00007dd052fd127b  nop [rax+rax*1], ax
00007dd052fd1284  nop [rax+rax*1], eax
00007dd052fd128c  mov eax, 0x4103AC
00007dd052fd1291  mov [r15+0x100], rax
00007dd052fd1298  jmp 0x00007DD052DFE110
00007dd052fd129d  cmp dword ptr [r15+0x318], 0x00
00007dd052fd12a5  jz 0x00007DD052FD13E0
00007dd052fd12ab  nop [rax+rax*1], ax
00007dd052fd12b4  nop [rax+rax*1], eax
00007dd052fd12bc  mov eax, 0x410390
00007dd052fd12c1  mov [r15+0x100], rax
00007dd052fd12c8  jmp 0x00007DD052DFE110
00007dd052fd12cd  int3
00007dd052fd12ce  call 0x00007DD052EB4B70
00007dd052fd12d3  jmp 0x00007DD052FD1241
00007dd052fd12d8  int3
00007dd052fd12d9  nop [rax], eax
00007dd052fd12e0  cmp dword ptr [r15+0x318], 0x00
00007dd052fd12e8  jz 0x00007DD052FD1320
00007dd052fd12ee  nop [rax+rax*1], ax
00007dd052fd12f7  nop [rax+rax*1], eax
00007dd052fd12ff  mov eax, 0x410374
00007dd052fd1304  mov [r15+0x100], rax
00007dd052fd130b  jmp 0x00007DD052DFE110
00007dd052fd1310  int3
00007dd052fd1311  int3
00007dd052fd1312  nop [rax+rax*1], ax
00007dd052fd131b  nop [rax+rax*1], eax
00007dd052fd1320  mov qword ptr [r15+0x50], 0x00
00007dd052fd1328  mov rax, [r15+0x40]
00007dd052fd132c  lea r14, [rax+0x01]
00007dd052fd1330  mov [r15+0x40], r14
00007dd052fd1334  mov rax, [r15+0x98]
00007dd052fd133b  mov r12d, [r15+0x48]
00007dd052fd133f  mov [r13+rax*1], r12d
00007dd052fd1344  xor eax, eax
00007dd052fd1346  mov r12d, 0x400
00007dd052fd134c  cmp r14, r12
00007dd052fd134f  cmc
00007dd052fd1350  lahf
00007dd052fd1351  seto al
00007dd052fd1354  mov [r15+0x108], eax
00007dd052fd135b  mov eax, [r15+0x108]
00007dd052fd1362  sahf
00007dd052fd1363  jz 0x00007DD052FD1395
00007dd052fd1365  cmp dword ptr [r15+0x318], 0x00
00007dd052fd136d  jz 0x00007DD052FD1120
00007dd052fd1373  nop [rax+rax*1], ax
00007dd052fd137c  nop [rax+rax*1], eax
00007dd052fd1384  mov eax, 0x410388
00007dd052fd1389  mov [r15+0x100], rax
00007dd052fd1390  jmp 0x00007DD052DFE110
00007dd052fd1395  cmp dword ptr [r15+0x318], 0x00
00007dd052fd139d  jz 0x00007DD052FD1580
00007dd052fd13a3  nop [rax+rax*1], ax
00007dd052fd13ac  nop [rax+rax*1], eax
00007dd052fd13b4  mov eax, 0x4103B0
00007dd052fd13b9  mov [r15+0x100], rax
00007dd052fd13c0  jmp 0x00007DD052DFE110
00007dd052fd13c5  int3
00007dd052fd13c6  call 0x00007DD052E0BAE0
00007dd052fd13cb  jmp 0x00007DD052FD1344
00007dd052fd13d0  int3
00007dd052fd13d1  nop [rax+rax*1], ax
00007dd052fd13da  nop [rax+rax*1], ax
00007dd052fd13e0  mov eax, [r15+0x50]
00007dd052fd13e4  lea r14d, [eax-0x01]
00007dd052fd13e9  mov r14d, r14d
00007dd052fd13ec  mov [r15+0x58], r14
00007dd052fd13f0  mov rax, [r15+0x58]
00007dd052fd13f4  mov r14d, eax
00007dd052fd13f7  mov r14d, r14d
00007dd052fd13fa  shl r14, 0x02
00007dd052fd13fe  mov rax, [r15+0x98]
00007dd052fd1405  lea r12, [rax+r14*1]
00007dd052fd1409  mov eax, [r13+r12*1]
00007dd052fd140e  mov [rsp+0x10], eax
00007dd052fd1412  mov eax, eax
00007dd052fd1414  mov [r15+0x60], rax
00007dd052fd1418  mov eax, [r15+0x48]
00007dd052fd141c  mov [rsp+0x20], eax
00007dd052fd1420  xor eax, eax
00007dd052fd1422  mov r14d, [rsp+0x10]
00007dd052fd1427  mov r12d, [rsp+0x20]
00007dd052fd142c  cmp r14d, r12d
00007dd052fd142f  cmc
00007dd052fd1430  lahf
00007dd052fd1431  seto al
00007dd052fd1434  mov [r15+0x108], eax
00007dd052fd143b  mov eax, [r15+0x108]
00007dd052fd1442  sahf
00007dd052fd1443  cmc
00007dd052fd1444  jbe 0x00007DD052FD1476
00007dd052fd1446  cmp dword ptr [r15+0x318], 0x00
00007dd052fd144e  jz 0x00007DD052FD1220
00007dd052fd1454  nop [rax+rax*1], ax
00007dd052fd145d  nop [rax+rax*1], eax
00007dd052fd1465  mov eax, 0x4103A0
00007dd052fd146a  mov [r15+0x100], rax
00007dd052fd1471  jmp 0x00007DD052DFE110
00007dd052fd1476  cmp dword ptr [r15+0x318], 0x00
00007dd052fd147e  jz 0x00007DD052FD14C0
00007dd052fd1484  nop [rax+rax*1], ax
00007dd052fd148d  nop [rax+rax*1], eax
00007dd052fd1495  mov eax, 0x410378
00007dd052fd149a  mov [r15+0x100], rax
00007dd052fd14a1  jmp 0x00007DD052DFE110
00007dd052fd14a6  int3
00007dd052fd14a7  call 0x00007DD052EB4690
00007dd052fd14ac  jmp 0x00007DD052FD140E
00007dd052fd14b1  int3
00007dd052fd14b2  nop [rax+rax*1], ax
00007dd052fd14bb  nop [rax+rax*1], eax
00007dd052fd14c0  mov rax, [r15+0x40]
00007dd052fd14c4  lea r14, [rax+0x01]
00007dd052fd14c8  mov [r15+0x40], r14
00007dd052fd14cc  mov rax, [r15+0x50]
00007dd052fd14d0  mov r12d, eax
00007dd052fd14d3  mov r12d, r12d
00007dd052fd14d6  shl r12, 0x02
00007dd052fd14da  mov rax, [r15+0x98]
00007dd052fd14e1  lea r11, [rax+r12*1]
00007dd052fd14e5  mov eax, [r15+0x48]
00007dd052fd14e9  mov [r13+r11*1], eax
00007dd052fd14ee  xor eax, eax
00007dd052fd14f0  mov r12d, 0x400
00007dd052fd14f6  cmp r14, r12
00007dd052fd14f9  cmc
00007dd052fd14fa  lahf
00007dd052fd14fb  seto al
00007dd052fd14fe  mov [r15+0x108], eax
00007dd052fd1505  mov eax, [r15+0x108]
00007dd052fd150c  sahf
00007dd052fd150d  jz 0x00007DD052FD153F
00007dd052fd150f  cmp dword ptr [r15+0x318], 0x00
00007dd052fd1517  jz 0x00007DD052FD1120
00007dd052fd151d  nop [rax+rax*1], ax
00007dd052fd1526  nop [rax+rax*1], eax
00007dd052fd152e  mov eax, 0x410388
00007dd052fd1533  mov [r15+0x100], rax
00007dd052fd153a  jmp 0x00007DD052DFE110
00007dd052fd153f  cmp dword ptr [r15+0x318], 0x00
00007dd052fd1547  jz 0x00007DD052FD1580
00007dd052fd154d  nop [rax+rax*1], ax
00007dd052fd1556  nop [rax+rax*1], eax
00007dd052fd155e  mov eax, 0x4103B0
00007dd052fd1563  mov [r15+0x100], rax
00007dd052fd156a  jmp 0x00007DD052DFE110
00007dd052fd156f  int3
00007dd052fd1570  call 0x00007DD052EA4270
00007dd052fd1575  jmp 0x00007DD052FD14EE
00007dd052fd157a  int3
00007dd052fd157b  nop [rax+rax*1], eax
00007dd052fd1580  mov qword ptr [r15+0x40], 0x430000
00007dd052fd1588  mov eax, 0x430CB0
00007dd052fd158d  mov r14, [r13+rax*1]
00007dd052fd1592  mov rax, [r15+0x98]
00007dd052fd1599  mov r12d, [r13+rax*1]
00007dd052fd159e  lea r11, [rax+0x04]
00007dd052fd15a2  mov eax, [r13+r11*1]
00007dd052fd15a7  mov r12d, r12d
00007dd052fd15aa  mov [r15+0x68], r12
00007dd052fd15ae  mov eax, eax
00007dd052fd15b0  mov [r15+0x60], rax
00007dd052fd15b4  mov rax, [r15+0x68]
00007dd052fd15b8  mov [r15+0x68], rax
00007dd052fd15bc  mov qword ptr [r15+0x58], 0x02
00007dd052fd15c4  mov [rsp+0x10], rax
00007dd052fd15c9  xor eax, eax
00007dd052fd15cb  mov r12d, 0x02
00007dd052fd15d1  mov r11d, 0x400
00007dd052fd15d7  cmp r12, r11
00007dd052fd15da  cmc
00007dd052fd15db  lahf
00007dd052fd15dc  seto al
00007dd052fd15df  mov [r15+0x108], eax
00007dd052fd15e6  mov rax, [r15+0x60]
00007dd052fd15ea  mov r12d, 0x02
00007dd052fd15f0  imul rax, r12
00007dd052fd15f4  mov [r15+0x50], rax
00007dd052fd15f8  mov rax, [rsp+0x10]
00007dd052fd15fd  lea r12, [rax+r14*1]
00007dd052fd1601  mov [r15+0x48], r12
00007dd052fd1605  mov eax, [r15+0x108]
00007dd052fd160c  sahf
00007dd052fd160d  jnz 0x00007DD052FD163F
00007dd052fd160f  cmp dword ptr [r15+0x318], 0x00
00007dd052fd1617  jz 0x00007DD052FD17B0
00007dd052fd161d  nop [rax+rax*1], ax
00007dd052fd1626  nop [rax+rax*1], eax
00007dd052fd162e  mov eax, 0x4103E0
00007dd052fd1633  mov [r15+0x100], rax
00007dd052fd163a  jmp 0x00007DD052DFE110
00007dd052fd163f  cmp dword ptr [r15+0x318], 0x00
00007dd052fd1647  jz 0x00007DD052FD1690
00007dd052fd164d  nop [rax+rax*1], ax
00007dd052fd1656  nop [rax+rax*1], eax
00007dd052fd165e  mov eax, 0x4103C0
00007dd052fd1663  mov [r15+0x100], rax
00007dd052fd166a  jmp 0x00007DD052DFE110
00007dd052fd166f  int3
00007dd052fd1670  call 0x00007DD052E0DC20
00007dd052fd1675  jmp 0x00007DD052FD1592
00007dd052fd167a  call 0x00007DD052E0B5E0
00007dd052fd167f  jmp 0x00007DD052FD159E
00007dd052fd1684  call 0x00007DD052EA3D90
00007dd052fd1689  jmp 0x00007DD052FD15A7
00007dd052fd168e  int3
00007dd052fd168f  nop
00007dd052fd1690  mov rax, [r15+0x98]
00007dd052fd1697  mov r14, [r15+0x58]
00007dd052fd169b  mov [rsp+0x10], r14
00007dd052fd16a0  shl r14, 0x02
00007dd052fd16a4  lea r12, [rax+r14*1]
00007dd052fd16a8  mov eax, [r13+r12*1]
00007dd052fd16ad  lea r14, [r12+0x04]
00007dd052fd16b2  mov r12d, [r13+r14*1]
00007dd052fd16b7  mov eax, eax
00007dd052fd16b9  mov [r15+0x68], rax
00007dd052fd16bd  mov r12d, r12d
00007dd052fd16c0  mov [r15+0x60], r12
00007dd052fd16c4  mov rax, [r15+0x68]
00007dd052fd16c8  mov [rsp+0x20], rax
00007dd052fd16cd  mov r14, [rsp+0x10]
00007dd052fd16d2  imul rax, r14
00007dd052fd16d6  mov r12, [rsp+0x20]
00007dd052fd16db  lea r11, [r12+rax*1]
00007dd052fd16df  mov [r15+0x68], r11
00007dd052fd16e3  lea rax, [r14+0x02]
00007dd052fd16e7  mov [r15+0x58], rax
00007dd052fd16eb  mov [rsp+0x10], rax
00007dd052fd16f0  xor eax, eax
00007dd052fd16f2  mov r14, [rsp+0x10]
00007dd052fd16f7  mov r12d, 0x400
00007dd052fd16fd  cmp r14, r12
00007dd052fd1700  cmc
00007dd052fd1701  lahf
00007dd052fd1702  seto al
00007dd052fd1705  mov [r15+0x108], eax
00007dd052fd170c  mov rax, [r15+0x50]
00007dd052fd1710  mov r12, [r15+0x60]
00007dd052fd1714  imul r14, r12
00007dd052fd1718  lea r12, [rax+r14*1]
00007dd052fd171c  mov [r15+0x50], r12
00007dd052fd1720  mov rax, [r15+0x48]
00007dd052fd1724  lea r14, [r11+rax*1]
00007dd052fd1728  mov [r15+0x48], r14
00007dd052fd172c  mov eax, [r15+0x108]
00007dd052fd1733  sahf
00007dd052fd1734  jnz 0x00007DD052FD1766
00007dd052fd1736  cmp dword ptr [r15+0x318], 0x00
00007dd052fd173e  jz 0x00007DD052FD17B0
00007dd052fd1744  nop [rax+rax*1], ax
00007dd052fd174d  nop [rax+rax*1], eax
00007dd052fd1755  mov eax, 0x4103E0
00007dd052fd175a  mov [r15+0x100], rax
00007dd052fd1761  jmp 0x00007DD052DFE110
00007dd052fd1766  cmp dword ptr [r15+0x318], 0x00
00007dd052fd176e  jz 0x00007DD052FD1690
00007dd052fd1774  nop [rax+rax*1], ax
00007dd052fd177d  nop [rax+rax*1], eax
00007dd052fd1785  mov eax, 0x4103C0
00007dd052fd178a  mov [r15+0x100], rax
00007dd052fd1791  jmp 0x00007DD052DFE110
00007dd052fd1796  int3
00007dd052fd1797  call 0x00007DD052EB4690
00007dd052fd179c  jmp 0x00007DD052FD16AD
00007dd052fd17a1  call 0x00007DD052EE26A0
00007dd052fd17a6  jmp 0x00007DD052FD16B7
00007dd052fd17ab  int3
00007dd052fd17ac  nop [rax], eax
00007dd052fd17b0  mov qword ptr [r15+0x98], 0x00
00007dd052fd17bb  mov rax, [r15+0x50]
00007dd052fd17bf  mov r14, [r15+0x48]
00007dd052fd17c3  lea r12, [rax+r14*1]
00007dd052fd17c7  mov [r15+0x48], r12
00007dd052fd17cb  mov rax, [r15+0x40]
00007dd052fd17cf  lea r14, [rax+0xCB0]
00007dd052fd17d6  mov [r13+r14*1], r12
00007dd052fd17db  mov qword ptr [r15], 0x01
00007dd052fd17e2  mov qword ptr [r15+0xF0], 0x4103F8
00007dd052fd17ed  mov r14d, [r15+0x320]
00007dd052fd17f4  mov eax, 0x4103F8
00007dd052fd17f9  mov rcx, 0x7DD052FD1860
00007dd052fd1803  mov [r15+r14*8+0x328], rax
00007dd052fd180b  mov [r15+r14*8+0x368], rcx
00007dd052fd1813  add r14d, 0x01
00007dd052fd1817  and r14d, 0x07
00007dd052fd181b  mov [r15+0x320], r14d
00007dd052fd1822  cmp dword ptr [r15+0x318], 0x00
00007dd052fd182a  jz 0x00007DD052FD0F20
00007dd052fd1830  nop [rax+rax*1], ax
00007dd052fd1839  nop [rax+rax*1], eax
00007dd052fd1841  mov eax, 0x4109A4
00007dd052fd1846  mov [r15+0x100], rax
00007dd052fd184d  jmp 0x00007DD052DFE110
00007dd052fd1852  int3
00007dd052fd1853  call 0x00007DD052EE2CE0
00007dd052fd1858  jmp 0x00007DD052FD17DB
00007dd052fd185d  int3
00007dd052fd185e  nop
00007dd052fd1860  mov eax, [r15+0x98]
00007dd052fd1867  lea r14d, [eax+0x01]
00007dd052fd186c  mov [rsp+0x10], r14d
00007dd052fd1871  mov r14d, r14d
00007dd052fd1874  mov [r15+0x98], r14
00007dd052fd187b  xor eax, eax
00007dd052fd187d  mov r14d, [rsp+0x10]
00007dd052fd1882  cmp r14d, 0x10000
00007dd052fd1889  cmc
00007dd052fd188a  lahf
00007dd052fd188b  seto al
00007dd052fd188e  mov [r15+0x108], eax
00007dd052fd1895  mov eax, [r15+0x108]
00007dd052fd189c  sahf
00007dd052fd189d  jnz 0x00007DD052FD18CF
00007dd052fd189f  cmp dword ptr [r15+0x318], 0x00
00007dd052fd18a7  jz 0x00007DD052FD19A0
00007dd052fd18ad  nop [rax+rax*1], ax
00007dd052fd18b6  nop [rax+rax*1], eax
00007dd052fd18be  mov eax, 0x410404
00007dd052fd18c3  mov [r15+0x100], rax
00007dd052fd18ca  jmp 0x00007DD052DFE110
00007dd052fd18cf  cmp dword ptr [r15+0x318], 0x00
00007dd052fd18d7  jz 0x00007DD052FD1910
00007dd052fd18dd  nop [rax+rax*1], ax
00007dd052fd18e6  nop [rax+rax*1], eax
00007dd052fd18ee  mov eax, 0x4103F0
00007dd052fd18f3  mov [r15+0x100], rax
00007dd052fd18fa  jmp 0x00007DD052DFE110
00007dd052fd18ff  int3
00007dd052fd1900  int3
00007dd052fd1901  nop [rax+rax*1], ax
00007dd052fd190a  nop [rax+rax*1], ax
00007dd052fd1910  mov eax, [r15]
00007dd052fd1913  mov r14d, [r15+0x98]
00007dd052fd191a  lea r12d, [eax+r14d*1]
00007dd052fd191f  mov r12d, r12d
00007dd052fd1922  mov [r15], r12
00007dd052fd1925  mov qword ptr [r15+0xF0], 0x4103F8
00007dd052fd1930  mov r14d, [r15+0x320]
00007dd052fd1937  mov eax, 0x4103F8
00007dd052fd193c  mov rcx, 0x7DD052FD1860
00007dd052fd1946  mov [r15+r14*8+0x328], rax
00007dd052fd194e  mov [r15+r14*8+0x368], rcx
00007dd052fd1956  add r14d, 0x01
00007dd052fd195a  and r14d, 0x07
00007dd052fd195e  mov [r15+0x320], r14d
00007dd052fd1965  cmp dword ptr [r15+0x318], 0x00
00007dd052fd196d  jz 0x00007DD052FD0F20
00007dd052fd1973  nop [rax+rax*1], ax
00007dd052fd197c  nop [rax+rax*1], eax
00007dd052fd1984  mov eax, 0x4109A4
00007dd052fd1989  mov [r15+0x100], rax
00007dd052fd1990  jmp 0x00007DD052DFE110
00007dd052fd1995  int3
00007dd052fd1996  int3
00007dd052fd1997  nop [rax+rax*1], ax
00007dd052fd19a0  vmovaps xmm1, [0x00007DD052BFE010]
00007dd052fd19a8  movq xmm1, xmm1
00007dd052fd19ac  movaps [r15+0x110], xmm1
00007dd052fd19b4  mov eax, 0x420B10
00007dd052fd19b9  mov r14, [r13+rax*1]
00007dd052fd19be  movq xmm1, r14
00007dd052fd19c3  movaps [r15+0x120], xmm1
00007dd052fd19cb  vmovaps xmm1, [0x00007DD052BFE020]
00007dd052fd19d3  movq xmm1, xmm1
00007dd052fd19d7  movaps [r15+0x140], xmm1
00007dd052fd19df  vmovaps xmm1, [0x00007DD052BFE030]
00007dd052fd19e7  vpbroadcastq xmm1, xmm1
00007dd052fd19ec  movaps [r15+0x150], xmm1
00007dd052fd19f4  mov qword ptr [r15+0x40], 0x02
00007dd052fd19fc  vmovaps xmm15, [0x00007DD052BFE040]
00007dd052fd1a04  movq xmm15, xmm15
00007dd052fd1a09  movaps [r15+0x160], xmm15
00007dd052fd1a11  vmovaps xmm15, [0x00007DD052BFE050]
00007dd052fd1a19  vpbroadcastq xmm15, xmm15
00007dd052fd1a1e  movaps [r15+0x130], xmm15
00007dd052fd1a26  mov rax, [r15+0x40]
00007dd052fd1a2a  vmovq xmm14, rax
00007dd052fd1a2f  vpbroadcastq xmm14, xmm14
00007dd052fd1a34  movaps [r15+0x170], xmm14
00007dd052fd1a3c  mov eax, 0x420A40
00007dd052fd1a41  movups xmm13, [r13+rax*1]
00007dd052fd1a47  mov qword ptr [r15+0x40], 0x431E00
00007dd052fd1a4f  mov eax, [r15]
00007dd052fd1a52  mov r14d, 0x430CB8
00007dd052fd1a58  mov [r13+r14*1], eax
00007dd052fd1a5d  mov qword ptr [r15+0x50], 0x432000
00007dd052fd1a65  vpmovqd xmm12, xmm13
00007dd052fd1a6b  pxor xmm11, xmm11
00007dd052fd1a70  punpcklqdq xmm12, xmm11
00007dd052fd1a75  movaps [r15+0x210], xmm12
00007dd052fd1a7d  movq xmm12, qword ptr [r15+0x140]
00007dd052fd1a86  movq xmm11, qword ptr [r15+0x120]
00007dd052fd1a8f  psubd xmm12, xmm11
00007dd052fd1a94  movq xmm12, xmm12
00007dd052fd1a99  paddq xmm13, xmm14
00007dd052fd1a9e  movaps [r15+0x180], xmm13
00007dd052fd1aa6  movq xmm14, qword ptr [r15+0x160]
00007dd052fd1aaf  paddd xmm11, xmm14
00007dd052fd1ab4  movq xmm11, xmm11
00007dd052fd1ab9  movq xmm11, xmm11
00007dd052fd1abe  movaps [r15+0x120], xmm11
00007dd052fd1ac6  pmovzxdq xmm12, xmm12
00007dd052fd1acc  psllq xmm12, 0x00
00007dd052fd1ad2  movq xmm14, qword ptr [r15+0x210]
00007dd052fd1adb  movq xmm13, qword ptr [r15+0x110]
00007dd052fd1ae4  paddd xmm14, xmm13
00007dd052fd1ae9  movq xmm14, xmm14
00007dd052fd1aee  vcvtuqq2pd xmm12, xmm12
00007dd052fd1af4  pmovzxdq xmm14, xmm14
00007dd052fd1afa  psllq xmm14, 0x00
00007dd052fd1b00  vcvtuqq2pd xmm14, xmm14
00007dd052fd1b06  movaps xmm13, xmm12
00007dd052fd1b0a  mulpd xmm13, xmm1
00007dd052fd1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
00007dd052fd1b15  ptest xmm11, xmm11
00007dd052fd1b1b  jnz 0x00007DD052FD1C0F
00007dd052fd1b21  movaps [r15+0x220], xmm13
00007dd052fd1b29  mov eax, 0x432000
00007dd052fd1b2e  movups [r13+rax*1], xmm13
00007dd052fd1b34  movaps xmm1, xmm14
00007dd052fd1b38  mulpd xmm1, xmm15
00007dd052fd1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
00007dd052fd1b42  ptest xmm13, xmm13
00007dd052fd1b48  jnz 0x00007DD052FD1D5C
00007dd052fd1b4e  movaps [r15+0x210], xmm1
00007dd052fd1b56  mov eax, 0x431E00
00007dd052fd1b5b  movups [r13+rax*1], xmm1
00007dd052fd1b61  mov qword ptr [r15+0x48], 0x10
00007dd052fd1b69  xor eax, eax
00007dd052fd1b6b  mov r14d, 0x10
00007dd052fd1b71  mov r12d, 0x200
00007dd052fd1b77  cmp r14, r12
00007dd052fd1b7a  cmc
00007dd052fd1b7b  lahf
00007dd052fd1b7c  seto al
00007dd052fd1b7f  mov [r15+0x108], eax
00007dd052fd1b86  mov eax, [r15+0x108]
00007dd052fd1b8d  sahf
00007dd052fd1b8e  jnz 0x00007DD052FD1BC0
00007dd052fd1b90  cmp dword ptr [r15+0x318], 0x00
00007dd052fd1b98  jz 0x00007DD052FD2300
00007dd052fd1b9e  nop [rax+rax*1], ax
00007dd052fd1ba7  nop [rax+rax*1], eax
00007dd052fd1baf  mov eax, 0x410490
00007dd052fd1bb4  mov [r15+0x100], rax
00007dd052fd1bbb  jmp 0x00007DD052DFE110
00007dd052fd1bc0  cmp dword ptr [r15+0x318], 0x00
00007dd052fd1bc8  jz 0x00007DD052FD1EB0
00007dd052fd1bce  nop [rax+rax*1], ax
00007dd052fd1bd7  nop [rax+rax*1], eax
00007dd052fd1bdf  mov eax, 0x410450
00007dd052fd1be4  mov [r15+0x100], rax
00007dd052fd1beb  jmp 0x00007DD052DFE110
00007dd052fd1bf0  int3
00007dd052fd1bf1  call 0x00007DD052E0DC20
00007dd052fd1bf6  jmp 0x00007DD052FD19BE
00007dd052fd1bfb  call 0x00007DD052E0C260
00007dd052fd1c00  jmp 0x00007DD052FD1A47
00007dd052fd1c05  call 0x00007DD052ED5D70
00007dd052fd1c0a  jmp 0x00007DD052FD1A5D
00007dd052fd1c0f  sub rsp, 0x08
00007dd052fd1c13  push rax
00007dd052fd1c14  push rcx
00007dd052fd1c15  push rdx
00007dd052fd1c16  push rdi
00007dd052fd1c17  push rsi
00007dd052fd1c18  push r8
00007dd052fd1c1a  push r9
00007dd052fd1c1c  push r10
00007dd052fd1c1e  push r11
00007dd052fd1c20  sub rsp, 0xF0
00007dd052fd1c27  vmovaps [rsp], xmm0
00007dd052fd1c2c  vmovaps [rsp+0x10], xmm1
00007dd052fd1c32  vmovaps [rsp+0x20], xmm2
00007dd052fd1c38  vmovaps [rsp+0x30], xmm3
00007dd052fd1c3e  vmovaps [rsp+0x40], xmm4
00007dd052fd1c44  vmovaps [rsp+0x50], xmm5
00007dd052fd1c4a  vmovaps [rsp+0x60], xmm6
00007dd052fd1c50  vmovaps [rsp+0x70], xmm7
00007dd052fd1c56  vmovaps [rsp+0x80], xmm8
00007dd052fd1c5f  vmovaps [rsp+0x90], xmm9
00007dd052fd1c68  vmovaps [rsp+0xA0], xmm10
00007dd052fd1c71  vmovaps [rsp+0xB0], xmm11
00007dd052fd1c7a  vmovaps [rsp+0xC0], xmm12
00007dd052fd1c83  vmovaps [rsp+0xD0], xmm14
00007dd052fd1c8c  vmovaps [rsp+0xE0], xmm15
00007dd052fd1c95  sub rsp, 0x30
00007dd052fd1c99  movaps [rsp], xmm13
00007dd052fd1c9e  movaps [rsp+0x10], xmm12
00007dd052fd1ca4  movaps [rsp+0x20], xmm1
00007dd052fd1ca9  lea rdi, [rsp]
00007dd052fd1cad  mov esi, 0x00
00007dd052fd1cb2  mov rax, 0x61D0404B9530
00007dd052fd1cbc  call rax
00007dd052fd1cbe  movaps xmm13, [rsp]
00007dd052fd1cc3  add rsp, 0x30
00007dd052fd1cc7  vmovaps xmm0, [rsp]
00007dd052fd1ccc  vmovaps xmm1, [rsp+0x10]
00007dd052fd1cd2  vmovaps xmm2, [rsp+0x20]
00007dd052fd1cd8  vmovaps xmm3, [rsp+0x30]
00007dd052fd1cde  vmovaps xmm4, [rsp+0x40]
00007dd052fd1ce4  vmovaps xmm5, [rsp+0x50]
00007dd052fd1cea  vmovaps xmm6, [rsp+0x60]
00007dd052fd1cf0  vmovaps xmm7, [rsp+0x70]
00007dd052fd1cf6  vmovaps xmm8, [rsp+0x80]
00007dd052fd1cff  vmovaps xmm9, [rsp+0x90]
00007dd052fd1d08  vmovaps xmm10, [rsp+0xA0]
00007dd052fd1d11  vmovaps xmm11, [rsp+0xB0]
00007dd052fd1d1a  vmovaps xmm12, [rsp+0xC0]
00007dd052fd1d23  vmovaps xmm14, [rsp+0xD0]
00007dd052fd1d2c  vmovaps xmm15, [rsp+0xE0]
00007dd052fd1d35  add rsp, 0xF0
00007dd052fd1d3c  pop r11
00007dd052fd1d3e  pop r10
00007dd052fd1d40  pop r9
00007dd052fd1d42  pop r8
00007dd052fd1d44  pop rsi
00007dd052fd1d45  pop rdi
00007dd052fd1d46  pop rdx
00007dd052fd1d47  pop rcx
00007dd052fd1d48  pop rax
00007dd052fd1d49  add rsp, 0x08
00007dd052fd1d4d  jmp 0x00007DD052FD1B21
00007dd052fd1d52  call 0x00007DD052E0C380
00007dd052fd1d57  jmp 0x00007DD052FD1B34
00007dd052fd1d5c  sub rsp, 0x08
00007dd052fd1d60  push rax
00007dd052fd1d61  push rcx
00007dd052fd1d62  push rdx
00007dd052fd1d63  push rdi
00007dd052fd1d64  push rsi
00007dd052fd1d65  push r8
00007dd052fd1d67  push r9
00007dd052fd1d69  push r10
00007dd052fd1d6b  push r11
00007dd052fd1d6d  sub rsp, 0xF0
00007dd052fd1d74  vmovaps [rsp], xmm0
00007dd052fd1d79  vmovaps [rsp+0x10], xmm2
00007dd052fd1d7f  vmovaps [rsp+0x20], xmm3
00007dd052fd1d85  vmovaps [rsp+0x30], xmm4
00007dd052fd1d8b  vmovaps [rsp+0x40], xmm5
00007dd052fd1d91  vmovaps [rsp+0x50], xmm6
00007dd052fd1d97  vmovaps [rsp+0x60], xmm7
00007dd052fd1d9d  vmovaps [rsp+0x70], xmm8
00007dd052fd1da3  vmovaps [rsp+0x80], xmm9
00007dd052fd1dac  vmovaps [rsp+0x90], xmm10
00007dd052fd1db5  vmovaps [rsp+0xA0], xmm11
00007dd052fd1dbe  vmovaps [rsp+0xB0], xmm12
00007dd052fd1dc7  vmovaps [rsp+0xC0], xmm13
00007dd052fd1dd0  vmovaps [rsp+0xD0], xmm14
00007dd052fd1dd9  vmovaps [rsp+0xE0], xmm15
00007dd052fd1de2  sub rsp, 0x30
00007dd052fd1de6  movaps [rsp], xmm1
00007dd052fd1dea  movaps [rsp+0x10], xmm14
00007dd052fd1df0  movaps [rsp+0x20], xmm15
00007dd052fd1df6  lea rdi, [rsp]
00007dd052fd1dfa  mov esi, 0x00
00007dd052fd1dff  mov rax, 0x61D0404B9530
00007dd052fd1e09  call rax
00007dd052fd1e0b  movaps xmm1, [rsp]
00007dd052fd1e0f  add rsp, 0x30
00007dd052fd1e13  vmovaps xmm0, [rsp]
00007dd052fd1e18  vmovaps xmm2, [rsp+0x10]
00007dd052fd1e1e  vmovaps xmm3, [rsp+0x20]
00007dd052fd1e24  vmovaps xmm4, [rsp+0x30]
00007dd052fd1e2a  vmovaps xmm5, [rsp+0x40]
00007dd052fd1e30  vmovaps xmm6, [rsp+0x50]
00007dd052fd1e36  vmovaps xmm7, [rsp+0x60]
00007dd052fd1e3c  vmovaps xmm8, [rsp+0x70]
00007dd052fd1e42  vmovaps xmm9, [rsp+0x80]
00007dd052fd1e4b  vmovaps xmm10, [rsp+0x90]
00007dd052fd1e54  vmovaps xmm11, [rsp+0xA0]
00007dd052fd1e5d  vmovaps xmm12, [rsp+0xB0]
00007dd052fd1e66  vmovaps xmm13, [rsp+0xC0]
00007dd052fd1e6f  vmovaps xmm14, [rsp+0xD0]
00007dd052fd1e78  vmovaps xmm15, [rsp+0xE0]
00007dd052fd1e81  add rsp, 0xF0
00007dd052fd1e88  pop r11
00007dd052fd1e8a  pop r10
00007dd052fd1e8c  pop r9
00007dd052fd1e8e  pop r8
00007dd052fd1e90  pop rsi
00007dd052fd1e91  pop rdi
00007dd052fd1e92  pop rdx
00007dd052fd1e93  pop rcx
00007dd052fd1e94  pop rax
00007dd052fd1e95  add rsp, 0x08
00007dd052fd1e99  jmp 0x00007DD052FD1B4E
00007dd052fd1e9e  call 0x00007DD052DFF540
00007dd052fd1ea3  jmp 0x00007DD052FD1B61
00007dd052fd1ea8  int3
00007dd052fd1ea9  nop [rax], eax
00007dd052fd1eb0  movaps xmm1, [r15+0x180]
00007dd052fd1eb8  vpmovqd xmm15, xmm1
00007dd052fd1ebe  pxor xmm14, xmm14
00007dd052fd1ec3  punpcklqdq xmm15, xmm14
00007dd052fd1ec8  movaps [r15+0x210], xmm15
00007dd052fd1ed0  movq xmm15, qword ptr [r15+0x140]
00007dd052fd1ed9  movq xmm14, qword ptr [r15+0x120]
00007dd052fd1ee2  psubd xmm15, xmm14
00007dd052fd1ee7  movq xmm15, xmm15
00007dd052fd1eec  movaps xmm13, [r15+0x170]
00007dd052fd1ef4  paddq xmm1, xmm13
00007dd052fd1ef9  movaps [r15+0x180], xmm1
00007dd052fd1f01  movq xmm1, qword ptr [r15+0x160]
00007dd052fd1f0a  paddd xmm14, xmm1
00007dd052fd1f0f  movq xmm14, xmm14
00007dd052fd1f14  movq xmm14, xmm14
00007dd052fd1f19  movaps [r15+0x120], xmm14
00007dd052fd1f21  pmovzxdq xmm15, xmm15
00007dd052fd1f27  psllq xmm15, 0x00
00007dd052fd1f2d  movq xmm1, qword ptr [r15+0x210]
00007dd052fd1f36  movq xmm14, qword ptr [r15+0x110]
00007dd052fd1f3f  paddd xmm1, xmm14
00007dd052fd1f44  movq xmm1, xmm1
00007dd052fd1f48  vcvtuqq2pd xmm15, xmm15
00007dd052fd1f4e  pmovzxdq xmm1, xmm1
00007dd052fd1f53  psllq xmm1, 0x00
00007dd052fd1f58  vcvtuqq2pd xmm1, xmm1
00007dd052fd1f5e  movaps xmm14, [r15+0x150]
00007dd052fd1f66  movaps xmm13, xmm15
00007dd052fd1f6a  mulpd xmm13, xmm14
00007dd052fd1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
00007dd052fd1f75  ptest xmm12, xmm12
00007dd052fd1f7b  jnz 0x00007DD052FD205E
00007dd052fd1f81  movaps [r15+0x220], xmm13
00007dd052fd1f89  mov rax, [r15+0x48]
00007dd052fd1f8d  mov r14, [r15+0x50]
00007dd052fd1f91  lea r12, [r14+rax*1]
00007dd052fd1f95  movups [r13+r12*1], xmm13
00007dd052fd1f9b  movaps xmm15, [r15+0x130]
00007dd052fd1fa3  movaps xmm14, xmm1
00007dd052fd1fa7  mulpd xmm14, xmm15
00007dd052fd1fac  vcmppd xmm13, xmm14, xmm14, 0x03
00007dd052fd1fb2  ptest xmm13, xmm13
00007dd052fd1fb8  jnz 0x00007DD052FD21AC
00007dd052fd1fbe  movaps [r15+0x210], xmm14
00007dd052fd1fc6  mov r14, [r15+0x40]
00007dd052fd1fca  lea r12, [r14+rax*1]
00007dd052fd1fce  movups [r13+r12*1], xmm14
00007dd052fd1fd4  lea r14, [rax+0x10]
00007dd052fd1fd8  mov [r15+0x48], r14
00007dd052fd1fdc  xor eax, eax
00007dd052fd1fde  mov r12d, 0x200
00007dd052fd1fe4  cmp r14, r12
00007dd052fd1fe7  cmc
00007dd052fd1fe8  lahf
00007dd052fd1fe9  seto al
00007dd052fd1fec  mov [r15+0x108], eax
00007dd052fd1ff3  mov eax, [r15+0x108]
00007dd052fd1ffa  sahf
00007dd052fd1ffb  jnz 0x00007DD052FD202D
00007dd052fd1ffd  cmp dword ptr [r15+0x318], 0x00
00007dd052fd2005  jz 0x00007DD052FD2300
00007dd052fd200b  nop [rax+rax*1], ax
00007dd052fd2014  nop [rax+rax*1], eax
00007dd052fd201c  mov eax, 0x410490
00007dd052fd2021  mov [r15+0x100], rax
00007dd052fd2028  jmp 0x00007DD052DFE110
00007dd052fd202d  cmp dword ptr [r15+0x318], 0x00
00007dd052fd2035  jz 0x00007DD052FD1EB0
00007dd052fd203b  nop [rax+rax*1], ax
00007dd052fd2044  nop [rax+rax*1], eax
00007dd052fd204c  mov eax, 0x410450
00007dd052fd2051  mov [r15+0x100], rax
00007dd052fd2058  jmp 0x00007DD052DFE110
00007dd052fd205d  int3
00007dd052fd205e  sub rsp, 0x08
00007dd052fd2062  push rax
00007dd052fd2063  push rcx
00007dd052fd2064  push rdx
00007dd052fd2065  push rdi
00007dd052fd2066  push rsi
00007dd052fd2067  push r8
00007dd052fd2069  push r9
00007dd052fd206b  push r10
00007dd052fd206d  push r11
00007dd052fd206f  sub rsp, 0xF0
00007dd052fd2076  vmovaps [rsp], xmm0
00007dd052fd207b  vmovaps [rsp+0x10], xmm1
00007dd052fd2081  vmovaps [rsp+0x20], xmm2
00007dd052fd2087  vmovaps [rsp+0x30], xmm3
00007dd052fd208d  vmovaps [rsp+0x40], xmm4
00007dd052fd2093  vmovaps [rsp+0x50], xmm5
00007dd052fd2099  vmovaps [rsp+0x60], xmm6
00007dd052fd209f  vmovaps [rsp+0x70], xmm7
00007dd052fd20a5  vmovaps [rsp+0x80], xmm8
00007dd052fd20ae  vmovaps [rsp+0x90], xmm9
00007dd052fd20b7  vmovaps [rsp+0xA0], xmm10
00007dd052fd20c0  vmovaps [rsp+0xB0], xmm11
00007dd052fd20c9  vmovaps [rsp+0xC0], xmm12
00007dd052fd20d2  vmovaps [rsp+0xD0], xmm14
00007dd052fd20db  vmovaps [rsp+0xE0], xmm15
00007dd052fd20e4  sub rsp, 0x30
00007dd052fd20e8  movaps [rsp], xmm13
00007dd052fd20ed  movaps [rsp+0x10], xmm15
00007dd052fd20f3  movaps [rsp+0x20], xmm14
00007dd052fd20f9  lea rdi, [rsp]
00007dd052fd20fd  mov esi, 0x00
00007dd052fd2102  mov rax, 0x61D0404B9530
00007dd052fd210c  call rax
00007dd052fd210e  movaps xmm13, [rsp]
00007dd052fd2113  add rsp, 0x30
00007dd052fd2117  vmovaps xmm0, [rsp]
00007dd052fd211c  vmovaps xmm1, [rsp+0x10]
00007dd052fd2122  vmovaps xmm2, [rsp+0x20]
00007dd052fd2128  vmovaps xmm3, [rsp+0x30]
00007dd052fd212e  vmovaps xmm4, [rsp+0x40]
00007dd052fd2134  vmovaps xmm5, [rsp+0x50]
00007dd052fd213a  vmovaps xmm6, [rsp+0x60]
00007dd052fd2140  vmovaps xmm7, [rsp+0x70]
00007dd052fd2146  vmovaps xmm8, [rsp+0x80]
00007dd052fd214f  vmovaps xmm9, [rsp+0x90]
00007dd052fd2158  vmovaps xmm10, [rsp+0xA0]
00007dd052fd2161  vmovaps xmm11, [rsp+0xB0]
00007dd052fd216a  vmovaps xmm12, [rsp+0xC0]
00007dd052fd2173  vmovaps xmm14, [rsp+0xD0]
00007dd052fd217c  vmovaps xmm15, [rsp+0xE0]
00007dd052fd2185  add rsp, 0xF0
00007dd052fd218c  pop r11
00007dd052fd218e  pop r10
00007dd052fd2190  pop r9
00007dd052fd2192  pop r8
00007dd052fd2194  pop rsi
00007dd052fd2195  pop rdi
00007dd052fd2196  pop rdx
00007dd052fd2197  pop rcx
00007dd052fd2198  pop rax
00007dd052fd2199  add rsp, 0x08
00007dd052fd219d  jmp 0x00007DD052FD1F81
00007dd052fd21a2  call 0x00007DD052EC2240
00007dd052fd21a7  jmp 0x00007DD052FD1F9B
00007dd052fd21ac  sub rsp, 0x08
00007dd052fd21b0  push rax
00007dd052fd21b1  push rcx
00007dd052fd21b2  push rdx
00007dd052fd21b3  push rdi
00007dd052fd21b4  push rsi
00007dd052fd21b5  push r8
00007dd052fd21b7  push r9
00007dd052fd21b9  push r10
00007dd052fd21bb  push r11
00007dd052fd21bd  sub rsp, 0xF0
00007dd052fd21c4  vmovaps [rsp], xmm0
00007dd052fd21c9  vmovaps [rsp+0x10], xmm1
00007dd052fd21cf  vmovaps [rsp+0x20], xmm2
00007dd052fd21d5  vmovaps [rsp+0x30], xmm3
00007dd052fd21db  vmovaps [rsp+0x40], xmm4
00007dd052fd21e1  vmovaps [rsp+0x50], xmm5
00007dd052fd21e7  vmovaps [rsp+0x60], xmm6
00007dd052fd21ed  vmovaps [rsp+0x70], xmm7
00007dd052fd21f3  vmovaps [rsp+0x80], xmm8
00007dd052fd21fc  vmovaps [rsp+0x90], xmm9
00007dd052fd2205  vmovaps [rsp+0xA0], xmm10
00007dd052fd220e  vmovaps [rsp+0xB0], xmm11
00007dd052fd2217  vmovaps [rsp+0xC0], xmm12
00007dd052fd2220  vmovaps [rsp+0xD0], xmm13
00007dd052fd2229  vmovaps [rsp+0xE0], xmm15
00007dd052fd2232  sub rsp, 0x30
00007dd052fd2236  movaps [rsp], xmm14
00007dd052fd223b  movaps [rsp+0x10], xmm1
00007dd052fd2240  movaps [rsp+0x20], xmm15
00007dd052fd2246  lea rdi, [rsp]
00007dd052fd224a  mov esi, 0x00
00007dd052fd224f  mov rax, 0x61D0404B9530
00007dd052fd2259  call rax
00007dd052fd225b  movaps xmm14, [rsp]
00007dd052fd2260  add rsp, 0x30
00007dd052fd2264  vmovaps xmm0, [rsp]
00007dd052fd2269  vmovaps xmm1, [rsp+0x10]
00007dd052fd226f  vmovaps xmm2, [rsp+0x20]
00007dd052fd2275  vmovaps xmm3, [rsp+0x30]
00007dd052fd227b  vmovaps xmm4, [rsp+0x40]
00007dd052fd2281  vmovaps xmm5, [rsp+0x50]
00007dd052fd2287  vmovaps xmm6, [rsp+0x60]
00007dd052fd228d  vmovaps xmm7, [rsp+0x70]
00007dd052fd2293  vmovaps xmm8, [rsp+0x80]
00007dd052fd229c  vmovaps xmm9, [rsp+0x90]
00007dd052fd22a5  vmovaps xmm10, [rsp+0xA0]
00007dd052fd22ae  vmovaps xmm11, [rsp+0xB0]
00007dd052fd22b7  vmovaps xmm12, [rsp+0xC0]
00007dd052fd22c0  vmovaps xmm13, [rsp+0xD0]
00007dd052fd22c9  vmovaps xmm15, [rsp+0xE0]
00007dd052fd22d2  add rsp, 0xF0
00007dd052fd22d9  pop r11
00007dd052fd22db  pop r10
00007dd052fd22dd  pop r9
00007dd052fd22df  pop r8
00007dd052fd22e1  pop rsi
00007dd052fd22e2  pop rdi
00007dd052fd22e3  pop rdx
00007dd052fd22e4  pop rcx
00007dd052fd22e5  pop rax
00007dd052fd22e6  add rsp, 0x08
00007dd052fd22ea  jmp 0x00007DD052FD1FBE
00007dd052fd22ef  call 0x00007DD052EC34C0
00007dd052fd22f4  jmp 0x00007DD052FD1FD4
00007dd052fd22f9  int3
00007dd052fd22fa  nop [rax+rax*1], ax
00007dd052fd2300  mov rax, [r15+0x50]
00007dd052fd2304  lea r14, [rax+0x80]
00007dd052fd230b  movups xmm1, [r13+r14*1]
00007dd052fd2311  lea r14, [rax+0x90]
00007dd052fd2318  movups xmm15, [r13+r14*1]
00007dd052fd231e  vxorps xmm14, xmm14, xmm14
00007dd052fd2323  vpbroadcastq xmm14, xmm14
00007dd052fd2328  lea r14, [rax+0x40]
00007dd052fd232c  movups xmm13, [r13+r14*1]
00007dd052fd2332  lea r14, [rax+0x50]
00007dd052fd2336  movups xmm12, [r13+r14*1]
00007dd052fd233c  mov qword ptr [r15+0x48], 0x00
00007dd052fd2344  movups xmm11, [r13+rax*1]
00007dd052fd234a  lea r14, [rax+0x10]
00007dd052fd234e  movups xmm10, [r13+r14*1]
00007dd052fd2354  mov r14, [r15+0xF8]
00007dd052fd235b  lea r12, [r14+0xE0]
00007dd052fd2362  movups [r13+r12*1], xmm15
00007dd052fd2368  lea r12, [r14+0xF0]
00007dd052fd236f  movups [r13+r12*1], xmm1
00007dd052fd2375  lea r12, [rax+0xC0]
00007dd052fd237c  movups xmm1, [r13+r12*1]
00007dd052fd2382  lea r12, [rax+0xD0]
00007dd052fd2389  movups xmm15, [r13+r12*1]
00007dd052fd238f  lea r12, [rax+0x140]
00007dd052fd2396  movups xmm9, [r13+r12*1]
00007dd052fd239c  lea r12, [rax+0x150]
00007dd052fd23a3  movups xmm8, [r13+r12*1]
00007dd052fd23a9  lea r12, [rax+0x180]
00007dd052fd23b0  movups xmm7, [r13+r12*1]
00007dd052fd23b6  lea r12, [rax+0x190]
00007dd052fd23bd  movups xmm6, [r13+r12*1]
00007dd052fd23c3  lea r12, [r14+0xC0]
00007dd052fd23ca  movups [r13+r12*1], xmm15
00007dd052fd23d0  lea r12, [r14+0xD0]
00007dd052fd23d7  movups [r13+r12*1], xmm1
00007dd052fd23dd  lea r12, [rax+0x100]
00007dd052fd23e4  movups xmm1, [r13+r12*1]
00007dd052fd23ea  lea r12, [rax+0x110]
00007dd052fd23f1  movups xmm15, [r13+r12*1]
00007dd052fd23f7  lea r12, [rax+0x1C0]
00007dd052fd23fe  movups xmm5, [r13+r12*1]
00007dd052fd2404  lea r12, [rax+0x1D0]
00007dd052fd240b  movups xmm4, [r13+r12*1]
00007dd052fd2411  lea r12, [rax+0x20]
00007dd052fd2415  movups xmm3, [r13+r12*1]
00007dd052fd241b  lea r12, [rax+0x30]
00007dd052fd241f  movups xmm2, [r13+r12*1]
00007dd052fd2425  movaps [r15+0x1F0], xmm2
00007dd052fd242d  lea r12, [r14+0x20]
00007dd052fd2431  movups [r13+r12*1], xmm1
00007dd052fd2437  lea r12, [r14+0x30]
00007dd052fd243b  movups [r13+r12*1], xmm12
00007dd052fd2441  lea r12, [rax+0x60]
00007dd052fd2445  movups xmm1, [r13+r12*1]
00007dd052fd244b  lea r12, [rax+0x70]
00007dd052fd244f  movups xmm12, [r13+r12*1]
00007dd052fd2455  lea r12, [r14+0x60]
00007dd052fd2459  movups [r13+r12*1], xmm11
00007dd052fd245f  lea r12, [r14+0x70]
00007dd052fd2463  movups [r13+r12*1], xmm5
00007dd052fd2469  lea r12, [rax+0xE0]
00007dd052fd2470  movups xmm11, [r13+r12*1]
00007dd052fd2476  lea r12, [rax+0xF0]
00007dd052fd247d  movups xmm5, [r13+r12*1]
00007dd052fd2483  lea r12, [rax+0x120]
00007dd052fd248a  vmovaps [rsp+0x10], xmm1
00007dd052fd2490  movups xmm1, [r13+r12*1]
00007dd052fd2496  lea r12, [rax+0x130]
00007dd052fd249d  vmovaps [rsp+0x20], xmm1
00007dd052fd24a3  movups xmm1, [r13+r12*1]
00007dd052fd24a9  lea r12, [r14+0xA0]
00007dd052fd24b0  movups [r13+r12*1], xmm12
00007dd052fd24b6  lea r12, [r14+0xB0]
00007dd052fd24bd  vmovaps xmm12, [rsp+0x10]
00007dd052fd24c3  movups [r13+r12*1], xmm12
00007dd052fd24c9  lea r12, [rax+0xA0]
00007dd052fd24d0  movups xmm12, [r13+r12*1]
00007dd052fd24d6  lea r12, [rax+0xB0]
00007dd052fd24dd  vmovaps [rsp+0x10], xmm1
00007dd052fd24e3  movups xmm1, [r13+r12*1]
00007dd052fd24e9  lea r12, [rax+0x160]
00007dd052fd24f0  vmovaps [rsp+0x30], xmm1
00007dd052fd24f6  movups xmm1, [r13+r12*1]
00007dd052fd24fc  lea r12, [rax+0x170]
00007dd052fd2503  vmovaps [rsp+0x40], xmm1
00007dd052fd2509  movups xmm1, [r13+r12*1]
00007dd052fd250f  movaps [r15+0x2B0], xmm1
00007dd052fd2517  lea r12, [rax+0x1A0]
00007dd052fd251e  vmovaps [rsp+0x50], xmm1
00007dd052fd2524  movups xmm1, [r13+r12*1]
00007dd052fd252a  lea r12, [rax+0x1B0]
00007dd052fd2531  vmovaps [rsp+0x60], xmm1
00007dd052fd2537  movups xmm1, [r13+r12*1]
00007dd052fd253d  vmovaps [rsp+0x70], xmm1
00007dd052fd2543  vmovaps xmm1, [rsp+0x60]
00007dd052fd2549  movaps [r15+0x290], xmm1
00007dd052fd2551  vmovaps [rsp+0x60], xmm1
00007dd052fd2557  vmovaps xmm1, [rsp+0x70]
00007dd052fd255d  movaps [r15+0x1E0], xmm1
00007dd052fd2565  lea r12, [r14+0x80]
00007dd052fd256c  vmovaps [rsp+0x70], xmm1
00007dd052fd2572  vmovaps xmm1, [rsp+0x30]
00007dd052fd2578  movups [r13+r12*1], xmm1
00007dd052fd257e  lea r12, [r14+0x90]
00007dd052fd2585  movups [r13+r12*1], xmm12
00007dd052fd258b  lea r12, [rax+0x1E0]
00007dd052fd2592  movups xmm1, [r13+r12*1]
00007dd052fd2598  lea r12, [rax+0x1F0]
00007dd052fd259f  movups xmm12, [r13+r12*1]
00007dd052fd25a5  mov qword ptr [r15+0x50], 0x432200
00007dd052fd25ad  lea rax, [r14+0x40]
00007dd052fd25b1  vmovaps [rsp+0x30], xmm1
00007dd052fd25b7  vmovaps xmm1, [rsp+0x40]
00007dd052fd25bd  movups [r13+rax*1], xmm1
00007dd052fd25c3  lea rax, [r14+0x50]
00007dd052fd25c7  movups [r13+rax*1], xmm10
00007dd052fd25cd  movups [r13+r14*1], xmm12
00007dd052fd25d3  lea rax, [r14+0x10]
00007dd052fd25d7  vmovaps xmm1, [rsp+0x30]
00007dd052fd25dd  movups [r13+rax*1], xmm1
00007dd052fd25e3  mov rax, [r15+0x40]
00007dd052fd25e7  vmovaps [rsp+0x30], xmm3
00007dd052fd25ed  vmovaps xmm1, [rsp+0x30]
00007dd052fd25f3  por xmm3, xmm1
00007dd052fd25f7  vmovaps [rsp+0x30], xmm6
00007dd052fd25fd  vmovaps xmm12, [rsp+0x30]
00007dd052fd2603  por xmm6, xmm12
00007dd052fd2608  lea r12, [rax+0x30]
00007dd052fd260c  mov r11, [r13+r12*1]
00007dd052fd2611  lea r12, [rax+0x38]
00007dd052fd2615  mov r10, [r13+r12*1]
00007dd052fd261a  movq xmm12, r11
00007dd052fd261f  movq xmm10, r10
00007dd052fd2624  movq xmm12, xmm12
00007dd052fd2629  vmovaps [rsp+0x30], xmm12
00007dd052fd262f  movq xmm12, xmm12
00007dd052fd2634  movaps [r15+0x130], xmm12
00007dd052fd263c  movq xmm10, xmm10
00007dd052fd2641  vmovaps [rsp+0x40], xmm10
00007dd052fd2647  movq xmm10, xmm10
00007dd052fd264c  movaps [r15+0x280], xmm10
00007dd052fd2654  vmovaps [rsp+0x80], xmm9
00007dd052fd265d  vmovaps xmm12, [rsp+0x80]
00007dd052fd2666  por xmm9, xmm12
00007dd052fd266b  lea r12, [rax+0x20]
00007dd052fd266f  mov r11, [r13+r12*1]
00007dd052fd2674  lea r12, [rax+0x28]
00007dd052fd2678  mov r10, [r13+r12*1]
00007dd052fd267d  movq xmm12, r11
00007dd052fd2682  movq xmm10, r10
00007dd052fd2687  movq xmm12, xmm12
00007dd052fd268c  vmovaps [rsp+0x80], xmm12
00007dd052fd2695  movq xmm12, xmm12
00007dd052fd269a  movaps [r15+0x150], xmm12
00007dd052fd26a2  movq xmm10, xmm10
00007dd052fd26a7  vmovaps [rsp+0x90], xmm10
00007dd052fd26b0  movq xmm10, xmm10
00007dd052fd26b5  movaps [r15+0x140], xmm10
00007dd052fd26bd  lea r12, [rax+0x10]
00007dd052fd26c1  mov r11, [r13+r12*1]
00007dd052fd26c6  lea r12, [rax+0x18]
00007dd052fd26ca  mov r10, [r13+r12*1]
00007dd052fd26cf  movq xmm12, r11
00007dd052fd26d4  movq xmm10, r10
00007dd052fd26d9  movq xmm12, xmm12
00007dd052fd26de  vmovaps [rsp+0xA0], xmm12
00007dd052fd26e7  movq xmm12, xmm12
00007dd052fd26ec  movaps [r15+0x170], xmm12
00007dd052fd26f4  movq xmm10, xmm10
00007dd052fd26f9  vmovaps [rsp+0xB0], xmm10
00007dd052fd2702  movq xmm10, xmm10
00007dd052fd2707  movaps [r15+0x160], xmm10
00007dd052fd270f  mov r12, [r13+rax*1]
00007dd052fd2714  vmovq xmm12, r12
00007dd052fd2719  vpbroadcastq xmm12, xmm12
00007dd052fd271e  lea r12, [rax+0x08]
00007dd052fd2722  mov rax, [r13+r12*1]
00007dd052fd2727  movq xmm10, rax
00007dd052fd272c  movaps [r15+0x230], xmm10
00007dd052fd2734  lea rax, [r14+0x50]
00007dd052fd2738  movups xmm10, [r13+rax*1]
00007dd052fd273e  lea rax, [r14+0x60]
00007dd052fd2742  vmovaps [rsp+0xC0], xmm1
00007dd052fd274b  movups xmm1, [r13+rax*1]
00007dd052fd2751  lea rax, [r14+0x30]
00007dd052fd2755  vmovaps [rsp+0xD0], xmm1
00007dd052fd275e  movups xmm1, [r13+rax*1]
00007dd052fd2764  mov qword ptr [r15+0x60], 0x432200
00007dd052fd276c  mov qword ptr [r15+0x58], 0x40
00007dd052fd2774  vmovaps [rsp+0xE0], xmm1
00007dd052fd277d  vmovaps [rsp+0xF0], xmm15
00007dd052fd2786  vmovaps xmm15, [rsp+0xC0]
00007dd052fd278f  vmovaps [rsp+0xC0], xmm14
00007dd052fd2798  movaps xmm1, xmm12
00007dd052fd279c  mulpd xmm1, xmm15
00007dd052fd27a1  vcmppd xmm14, xmm1, xmm1, 0x03
00007dd052fd27a6  ptest xmm14, xmm14
00007dd052fd27ac  jnz 0x00007DD052FD3863
00007dd052fd27b2  movq xmm15, qword ptr [r15+0x230]
00007dd052fd27bb  vmovaps [rsp+0x100], xmm15
00007dd052fd27c4  vpermilpd xmm15, xmm15, 0x00
00007dd052fd27ca  vmovaps [rsp+0x110], xmm1
00007dd052fd27d3  vmovaps xmm1, [rsp+0xE0]
00007dd052fd27dc  vmovaps [rsp+0xE0], xmm13
00007dd052fd27e5  movaps xmm14, xmm1
00007dd052fd27e9  mulpd xmm14, xmm15
00007dd052fd27ee  vcmppd xmm13, xmm14, xmm14, 0x03
00007dd052fd27f4  ptest xmm13, xmm13
00007dd052fd27fa  jnz 0x00007DD052FD39A5
00007dd052fd2800  vxorps xmm1, xmm1, xmm1
00007dd052fd2804  vpbroadcastq xmm1, xmm1
00007dd052fd2809  vmovaps xmm13, [rsp+0xD0]
00007dd052fd2812  vmovaps [rsp+0xD0], xmm1
00007dd052fd281b  movaps xmm15, xmm12
00007dd052fd281f  mulpd xmm15, xmm13
00007dd052fd2824  vcmppd xmm1, xmm15, xmm15, 0x03
00007dd052fd282a  ptest xmm1, xmm1
00007dd052fd282f  jnz 0x00007DD052FD3AE8
00007dd052fd2835  movaps xmm1, xmm12
00007dd052fd2839  mulpd xmm1, xmm10
00007dd052fd283e  vcmppd xmm13, xmm1, xmm1, 0x03
00007dd052fd2843  ptest xmm13, xmm13
00007dd052fd2849  jnz 0x00007DD052FD3C2C
00007dd052fd284f  movaps xmm13, xmm12
00007dd052fd2853  mulpd xmm13, xmm2
00007dd052fd2858  vcmppd xmm10, xmm13, xmm13, 0x03
00007dd052fd285e  ptest xmm10, xmm10
00007dd052fd2864  jnz 0x00007DD052FD3D6E
00007dd052fd286a  vmovaps [rsp+0x120], xmm7
00007dd052fd2873  vmovaps xmm12, [rsp+0x120]
00007dd052fd287c  por xmm7, xmm12
00007dd052fd2881  vmovaps xmm12, [rsp+0xE0]
00007dd052fd288a  vmovaps xmm10, [rsp+0xE0]
00007dd052fd2893  por xmm12, xmm10
00007dd052fd2898  vmovaps xmm2, [rsp+0x100]
00007dd052fd28a1  vpermilpd xmm2, xmm2, 0x00
00007dd052fd28a7  vmovaps [rsp+0xE0], xmm1
00007dd052fd28b0  vmovaps [rsp+0x120], xmm15
00007dd052fd28b9  movaps xmm1, xmm10
00007dd052fd28bd  mulpd xmm1, xmm2
00007dd052fd28c1  vcmppd xmm15, xmm1, xmm1, 0x03
00007dd052fd28c6  ptest xmm15, xmm15
00007dd052fd28cc  jnz 0x00007DD052FD3EB1
00007dd052fd28d2  xor eax, eax
00007dd052fd28d4  mov r12d, 0x40
00007dd052fd28da  mov r11d, 0x200
00007dd052fd28e0  cmp r12, r11
00007dd052fd28e3  cmc
00007dd052fd28e4  lahf
00007dd052fd28e5  seto al
00007dd052fd28e8  mov [r15+0x108], eax
00007dd052fd28ef  vmovaps xmm10, [rsp+0x110]
00007dd052fd28f8  vmovaps xmm2, [rsp+0xD0]
00007dd052fd2901  vmovaps [rsp+0xD0], xmm1
00007dd052fd290a  movaps xmm15, xmm10
00007dd052fd290e  addpd xmm15, xmm2
00007dd052fd2913  vcmppd xmm1, xmm15, xmm15, 0x03
00007dd052fd2919  ptest xmm1, xmm1
00007dd052fd291e  jnz 0x00007DD052FD3FF2
00007dd052fd2924  vmovaps xmm10, [rsp+0x120]
00007dd052fd292d  vmovaps [rsp+0x110], xmm15
00007dd052fd2936  vmovaps xmm15, [rsp+0xC0]
00007dd052fd293f  vmovaps [rsp+0xC0], xmm14
00007dd052fd2948  movaps xmm1, xmm10
00007dd052fd294c  addpd xmm1, xmm15
00007dd052fd2951  vcmppd xmm14, xmm1, xmm1, 0x03
00007dd052fd2956  ptest xmm14, xmm14
00007dd052fd295c  jnz 0x00007DD052FD4135
00007dd052fd2962  vmovaps xmm10, [rsp+0xE0]
00007dd052fd296b  vmovaps [rsp+0xE0], xmm1
00007dd052fd2974  movaps xmm14, xmm10
00007dd052fd2978  addpd xmm14, xmm15
00007dd052fd297d  vcmppd xmm1, xmm14, xmm14, 0x03
00007dd052fd2983  ptest xmm1, xmm1
00007dd052fd2988  jnz 0x00007DD052FD4277
00007dd052fd298e  vmovaps xmm1, [rsp+0x10]
00007dd052fd2994  vmovaps xmm15, [rsp+0x10]
00007dd052fd299a  por xmm1, xmm15
00007dd052fd299f  vmovaps xmm15, [rsp+0x20]
00007dd052fd29a5  vmovaps xmm10, [rsp+0x20]
00007dd052fd29ab  por xmm15, xmm10
00007dd052fd29b0  vmovaps [rsp+0x10], xmm5
00007dd052fd29b6  vmovaps xmm10, [rsp+0x10]
00007dd052fd29bc  por xmm5, xmm10
00007dd052fd29c1  vmovaps [rsp+0x10], xmm11
00007dd052fd29c7  vmovaps xmm10, [rsp+0x10]
00007dd052fd29cd  por xmm11, xmm10
00007dd052fd29d2  vmovaps [rsp+0x10], xmm4
00007dd052fd29d8  vmovaps xmm10, [rsp+0x10]
00007dd052fd29de  por xmm4, xmm10
00007dd052fd29e3  vmovaps [rsp+0x10], xmm8
00007dd052fd29e9  vmovaps xmm10, [rsp+0x10]
00007dd052fd29ef  por xmm8, xmm10
00007dd052fd29f4  vmovaps xmm10, [rsp+0xF0]
00007dd052fd29fd  vmovaps [rsp+0x10], xmm1
00007dd052fd2a03  vmovaps xmm1, [rsp+0xF0]
00007dd052fd2a0c  por xmm10, xmm1
00007dd052fd2a11  lea rax, [r14+0xA0]
00007dd052fd2a18  movups xmm1, [r13+rax*1]
00007dd052fd2a1e  lea rax, [r14+0xB0]
00007dd052fd2a25  vmovaps [rsp+0x20], xmm1
00007dd052fd2a2b  movups xmm1, [r13+rax*1]
00007dd052fd2a31  vmovaps [rsp+0xF0], xmm1
00007dd052fd2a3a  vmovaps [rsp+0x120], xmm15
00007dd052fd2a43  movaps xmm1, xmm13
00007dd052fd2a47  addpd xmm1, xmm2
00007dd052fd2a4b  vcmppd xmm15, xmm1, xmm1, 0x03
00007dd052fd2a50  ptest xmm15, xmm15
00007dd052fd2a56  jnz 0x00007DD052FD43CF
00007dd052fd2a5c  lea rax, [r14+0xF0]
00007dd052fd2a63  movups xmm15, [r13+rax*1]
00007dd052fd2a69  vmovaps xmm2, [rsp+0xE0]
00007dd052fd2a72  vmovaps [rsp+0xE0], xmm1
00007dd052fd2a7b  vmovaps xmm1, [rsp+0xD0]
00007dd052fd2a84  vmovaps [rsp+0xD0], xmm15
00007dd052fd2a8d  movaps xmm13, xmm2
00007dd052fd2a91  addpd xmm13, xmm1
00007dd052fd2a96  vcmppd xmm15, xmm13, xmm13, 0x03
00007dd052fd2a9c  ptest xmm15, xmm15
00007dd052fd2aa2  jnz 0x00007DD052FD451A
00007dd052fd2aa8  vmovaps xmm15, [rsp+0xC0]
00007dd052fd2ab1  movaps xmm1, xmm14
00007dd052fd2ab5  addpd xmm1, xmm15
00007dd052fd2aba  vcmppd xmm2, xmm1, xmm1, 0x03
00007dd052fd2abf  ptest xmm2, xmm2
00007dd052fd2ac4  jnz 0x00007DD052FD465C
00007dd052fd2aca  vmovaps xmm15, [rsp+0x100]
00007dd052fd2ad3  vpermilpd xmm15, xmm15, 0x00
00007dd052fd2ad9  vmovaps xmm2, [rsp+0xF0]
00007dd052fd2ae2  vmovaps [rsp+0xC0], xmm1
00007dd052fd2aeb  movaps xmm14, xmm2
00007dd052fd2aef  mulpd xmm14, xmm15
00007dd052fd2af4  vcmppd xmm1, xmm14, xmm14, 0x03
00007dd052fd2afa  ptest xmm1, xmm1
00007dd052fd2aff  jnz 0x00007DD052FD479E
00007dd052fd2b05  vmovaps xmm1, [rsp+0xA0]
00007dd052fd2b0e  vpermilpd xmm1, xmm1, 0x00
00007dd052fd2b14  vmovaps xmm2, [rsp+0xD0]
00007dd052fd2b1d  vmovaps [rsp+0xD0], xmm14
00007dd052fd2b26  movaps xmm15, xmm2
00007dd052fd2b2a  mulpd xmm15, xmm1
00007dd052fd2b2f  vcmppd xmm14, xmm15, xmm15, 0x03
00007dd052fd2b35  ptest xmm14, xmm14
00007dd052fd2b3b  jnz 0x00007DD052FD48E1
00007dd052fd2b41  lea rax, [r14+0xE0]
00007dd052fd2b48  movups xmm1, [r13+rax*1]
00007dd052fd2b4e  vmovaps xmm14, [rsp+0x100]
00007dd052fd2b57  vpermilpd xmm14, xmm14, 0x00
00007dd052fd2b5d  vmovaps [rsp+0xF0], xmm1
00007dd052fd2b66  vmovaps xmm1, [rsp+0x20]
00007dd052fd2b6c  vmovaps [rsp+0x20], xmm15
00007dd052fd2b72  movaps xmm2, xmm1
00007dd052fd2b75  mulpd xmm2, xmm14
00007dd052fd2b7a  vcmppd xmm15, xmm2, xmm2, 0x03
00007dd052fd2b7f  ptest xmm15, xmm15
00007dd052fd2b85  jnz 0x00007DD052FD4A2D
00007dd052fd2b8b  vmovaps [rsp+0x100], xmm10
00007dd052fd2b94  vmovaps xmm1, [rsp+0x100]
00007dd052fd2b9d  por xmm10, xmm1
00007dd052fd2ba2  movaps [r15+0x300], xmm10
00007dd052fd2baa  vmovaps [rsp+0x100], xmm8
00007dd052fd2bb3  vmovaps xmm1, [rsp+0x100]
00007dd052fd2bbc  por xmm8, xmm1
00007dd052fd2bc1  movaps [r15+0x190], xmm8
00007dd052fd2bc9  vmovaps xmm1, [rsp+0xA0]
00007dd052fd2bd2  vpermilpd xmm1, xmm1, 0x00
00007dd052fd2bd8  vmovaps xmm14, [rsp+0xF0]
00007dd052fd2be1  vmovaps [rsp+0xF0], xmm13
00007dd052fd2bea  movaps xmm15, xmm14
00007dd052fd2bee  mulpd xmm15, xmm1
00007dd052fd2bf3  vcmppd xmm13, xmm15, xmm15, 0x03
00007dd052fd2bf9  ptest xmm13, xmm13
00007dd052fd2bff  jnz 0x00007DD052FD4B6E
00007dd052fd2c05  lea rax, [r14+0x90]
00007dd052fd2c0c  movups xmm1, [r13+rax*1]
00007dd052fd2c12  vmovaps [rsp+0x100], xmm4
00007dd052fd2c1b  vmovaps xmm14, [rsp+0x100]
00007dd052fd2c24  por xmm4, xmm14
00007dd052fd2c29  movaps [r15+0x1C0], xmm4
00007dd052fd2c31  vmovaps [rsp+0x100], xmm11
00007dd052fd2c3a  vmovaps xmm14, [rsp+0x100]
00007dd052fd2c43  por xmm11, xmm14
00007dd052fd2c48  movaps [r15+0x200], xmm11
00007dd052fd2c50  vmovaps [rsp+0x100], xmm5
00007dd052fd2c59  vmovaps xmm14, [rsp+0x100]
00007dd052fd2c62  por xmm5, xmm14
00007dd052fd2c67  movaps [r15+0x2D0], xmm5
00007dd052fd2c6f  vmovaps xmm14, [rsp+0x120]
00007dd052fd2c78  vmovaps xmm13, [rsp+0x120]
00007dd052fd2c81  por xmm14, xmm13
00007dd052fd2c86  movaps [r15+0x2E0], xmm14
00007dd052fd2c8e  vmovaps [rsp+0x100], xmm1
00007dd052fd2c97  vmovaps xmm1, [rsp+0x110]
00007dd052fd2ca0  vmovaps [rsp+0x110], xmm15
00007dd052fd2ca9  vmovaps xmm15, [rsp+0xD0]
00007dd052fd2cb2  vmovaps [rsp+0xD0], xmm14
00007dd052fd2cbb  movaps xmm13, xmm1
00007dd052fd2cbf  addpd xmm13, xmm15
00007dd052fd2cc4  vcmppd xmm14, xmm13, xmm13, 0x03
00007dd052fd2cca  ptest xmm14, xmm14
00007dd052fd2cd0  jnz 0x00007DD052FD4CBB
00007dd052fd2cd6  vmovaps xmm1, [rsp+0xA0]
00007dd052fd2cdf  vpermilpd xmm1, xmm1, 0x00
00007dd052fd2ce5  vmovaps xmm14, [rsp+0x100]
00007dd052fd2cee  vmovaps [rsp+0x100], xmm13
00007dd052fd2cf7  movaps xmm15, xmm14
00007dd052fd2cfb  mulpd xmm15, xmm1
00007dd052fd2d00  vcmppd xmm13, xmm15, xmm15, 0x03
00007dd052fd2d06  ptest xmm13, xmm13
00007dd052fd2d0c  jnz 0x00007DD052FD4DFE
00007dd052fd2d12  lea rax, [r14+0x80]
00007dd052fd2d19  movups xmm1, [r13+rax*1]
00007dd052fd2d1f  vmovaps xmm13, [rsp+0xE0]
00007dd052fd2d28  vmovaps [rsp+0xE0], xmm1
00007dd052fd2d31  movaps xmm14, xmm13
00007dd052fd2d35  addpd xmm14, xmm2
00007dd052fd2d3a  vcmppd xmm1, xmm14, xmm14, 0x03
00007dd052fd2d40  ptest xmm1, xmm1
00007dd052fd2d45  jnz 0x00007DD052FD4F4B
00007dd052fd2d4b  vmovaps xmm13, [rsp+0xF0]
00007dd052fd2d54  vmovaps xmm2, [rsp+0x20]
00007dd052fd2d5a  vmovaps [rsp+0x20], xmm15
00007dd052fd2d60  movaps xmm1, xmm13
00007dd052fd2d64  addpd xmm1, xmm2
00007dd052fd2d68  vcmppd xmm15, xmm1, xmm1, 0x03
00007dd052fd2d6d  ptest xmm15, xmm15
00007dd052fd2d73  jnz 0x00007DD052FD508E
00007dd052fd2d79  vmovaps xmm15, [rsp+0x10]
00007dd052fd2d7f  vmovaps xmm13, [rsp+0x10]
00007dd052fd2d85  por xmm15, xmm13
00007dd052fd2d8a  movaps [r15+0x2F0], xmm15
00007dd052fd2d92  vmovaps xmm13, [rsp+0xA0]
00007dd052fd2d9b  vpermilpd xmm13, xmm13, 0x00
00007dd052fd2da1  vmovaps [rsp+0x10], xmm1
00007dd052fd2da7  vmovaps xmm1, [rsp+0xE0]
00007dd052fd2db0  vmovaps [rsp+0xA0], xmm15
00007dd052fd2db9  movaps xmm2, xmm1
00007dd052fd2dbc  mulpd xmm2, xmm13
00007dd052fd2dc1  vcmppd xmm15, xmm2, xmm2, 0x03
00007dd052fd2dc6  ptest xmm15, xmm15
00007dd052fd2dcc  jnz 0x00007DD052FD51CF
00007dd052fd2dd2  lea rax, [r14+0xD0]
00007dd052fd2dd9  movups xmm1, [r13+rax*1]
00007dd052fd2ddf  vmovaps xmm13, [rsp+0xC0]
00007dd052fd2de8  vmovaps [rsp+0xC0], xmm1
00007dd052fd2df1  vmovaps xmm1, [rsp+0x110]
00007dd052fd2dfa  vmovaps [rsp+0xE0], xmm14
00007dd052fd2e03  movaps xmm15, xmm13
00007dd052fd2e07  addpd xmm15, xmm1
00007dd052fd2e0c  vcmppd xmm14, xmm15, xmm15, 0x03
00007dd052fd2e12  ptest xmm14, xmm14
00007dd052fd2e18  jnz 0x00007DD052FD531A
00007dd052fd2e1e  vmovaps xmm1, [rsp+0xB0]
00007dd052fd2e27  vpermilpd xmm1, xmm1, 0x00
00007dd052fd2e2d  movaps xmm14, xmm11
00007dd052fd2e31  mulpd xmm14, xmm1
00007dd052fd2e36  vcmppd xmm13, xmm14, xmm14, 0x03
00007dd052fd2e3c  ptest xmm13, xmm13
00007dd052fd2e42  jnz 0x00007DD052FD545D
00007dd052fd2e48  movaps [r15+0x260], xmm14
00007dd052fd2e50  vxorps xmm1, xmm1, xmm1
00007dd052fd2e54  vpbroadcastq xmm1, xmm1
00007dd052fd2e59  movaps [r15+0x1B0], xmm1
00007dd052fd2e61  vmovaps xmm1, [rsp+0xB0]
00007dd052fd2e6a  vpermilpd xmm1, xmm1, 0x00
00007dd052fd2e70  vmovaps xmm11, [rsp+0xC0]
00007dd052fd2e79  vmovaps [rsp+0xC0], xmm15
00007dd052fd2e82  movaps xmm13, xmm11
00007dd052fd2e86  mulpd xmm13, xmm1
00007dd052fd2e8b  vcmppd xmm15, xmm13, xmm13, 0x03
00007dd052fd2e91  ptest xmm15, xmm15
00007dd052fd2e97  jnz 0x00007DD052FD55A0
00007dd052fd2e9d  lea rax, [r14+0xC0]
00007dd052fd2ea4  movups xmm1, [r13+rax*1]
00007dd052fd2eaa  vmovaps xmm11, [rsp+0x100]
00007dd052fd2eb3  vmovaps [rsp+0xF0], xmm1
00007dd052fd2ebc  vmovaps xmm1, [rsp+0x20]
00007dd052fd2ec2  vmovaps [rsp+0x20], xmm14
00007dd052fd2ec8  movaps xmm15, xmm11
00007dd052fd2ecc  addpd xmm15, xmm1
00007dd052fd2ed1  vcmppd xmm14, xmm15, xmm15, 0x03
00007dd052fd2ed7  ptest xmm14, xmm14
00007dd052fd2edd  jnz 0x00007DD052FD56ED
00007dd052fd2ee3  vmovaps [rsp+0x100], xmm9
00007dd052fd2eec  vmovaps xmm1, [rsp+0x100]
00007dd052fd2ef5  por xmm9, xmm1
00007dd052fd2efa  movaps [r15+0x270], xmm9
00007dd052fd2f02  vmovaps [rsp+0x100], xmm6
00007dd052fd2f0b  vmovaps xmm1, [rsp+0x100]
00007dd052fd2f14  por xmm6, xmm1
00007dd052fd2f18  movaps [r15+0x1A0], xmm6
00007dd052fd2f20  vmovaps xmm14, [rsp+0xB0]
00007dd052fd2f29  vpermilpd xmm14, xmm14, 0x00
00007dd052fd2f2f  vmovaps xmm6, [rsp+0xF0]
00007dd052fd2f38  vmovaps [rsp+0xF0], xmm1
00007dd052fd2f41  movaps xmm11, xmm6
00007dd052fd2f45  mulpd xmm11, xmm14
00007dd052fd2f4a  vcmppd xmm1, xmm11, xmm11, 0x03
00007dd052fd2f50  ptest xmm1, xmm1
00007dd052fd2f55  jnz 0x00007DD052FD5830
00007dd052fd2f5b  lea rax, [r14+0x20]
00007dd052fd2f5f  movups xmm1, [r13+rax*1]
00007dd052fd2f65  movaps [r15+0x110], xmm1
00007dd052fd2f6d  vmovaps xmm6, [rsp+0xE0]
00007dd052fd2f76  vmovaps [rsp+0xE0], xmm1
00007dd052fd2f7f  movaps xmm14, xmm6
00007dd052fd2f83  addpd xmm14, xmm2
00007dd052fd2f88  vcmppd xmm1, xmm14, xmm14, 0x03
00007dd052fd2f8e  ptest xmm1, xmm1
00007dd052fd2f93  jnz 0x00007DD052FD597D
00007dd052fd2f99  vmovaps xmm1, [rsp+0xB0]
00007dd052fd2fa2  vpermilpd xmm1, xmm1, 0x00
00007dd052fd2fa8  movaps xmm6, xmm5
00007dd052fd2fab  mulpd xmm6, xmm1
00007dd052fd2faf  vcmppd xmm2, xmm6, xmm6, 0x03
00007dd052fd2fb4  ptest xmm2, xmm2
00007dd052fd2fb9  jnz 0x00007DD052FD5ABF
00007dd052fd2fbf  vmovaps xmm5, [rsp+0x10]
00007dd052fd2fc5  movaps xmm1, xmm5
00007dd052fd2fc8  addpd xmm1, xmm13
00007dd052fd2fcd  vcmppd xmm2, xmm1, xmm1, 0x03
00007dd052fd2fd2  ptest xmm2, xmm2
00007dd052fd2fd7  jnz 0x00007DD052FD5BFF
00007dd052fd2fdd  vmovaps xmm13, [rsp+0x80]
00007dd052fd2fe6  vpermilpd xmm13, xmm13, 0x00
00007dd052fd2fec  vmovaps xmm2, [rsp+0xE0]
00007dd052fd2ff5  vmovaps [rsp+0x10], xmm1
00007dd052fd2ffb  movaps xmm5, xmm2
00007dd052fd2ffe  mulpd xmm5, xmm13
00007dd052fd3003  vcmppd xmm1, xmm5, xmm5, 0x03
00007dd052fd3008  ptest xmm1, xmm1
00007dd052fd300d  jnz 0x00007DD052FD5D40
00007dd052fd3013  vmovaps xmm1, [rsp+0x80]
00007dd052fd301c  vpermilpd xmm1, xmm1, 0x00
00007dd052fd3022  movaps xmm13, xmm10
00007dd052fd3026  mulpd xmm13, xmm1
00007dd052fd302b  vcmppd xmm2, xmm13, xmm13, 0x03
00007dd052fd3031  ptest xmm2, xmm2
00007dd052fd3036  jnz 0x00007DD052FD5E81
00007dd052fd303c  vmovaps xmm10, [rsp+0x20]
00007dd052fd3042  movaps xmm1, xmm15
00007dd052fd3046  addpd xmm1, xmm10
00007dd052fd304b  vcmppd xmm2, xmm1, xmm1, 0x03
00007dd052fd3050  ptest xmm2, xmm2
00007dd052fd3055  jnz 0x00007DD052FD5FC4
00007dd052fd305b  vmovaps xmm10, [rsp+0xC0]
00007dd052fd3064  movaps xmm15, xmm10
00007dd052fd3068  addpd xmm15, xmm11
00007dd052fd306d  vcmppd xmm2, xmm15, xmm15, 0x03
00007dd052fd3073  ptest xmm2, xmm2
00007dd052fd3078  jnz 0x00007DD052FD6106
00007dd052fd307e  vmovaps xmm11, [rsp+0x80]
00007dd052fd3087  vpermilpd xmm11, xmm11, 0x00
00007dd052fd308d  vmovaps xmm2, [rsp+0xD0]
00007dd052fd3096  vmovaps [rsp+0x20], xmm1
00007dd052fd309c  movaps xmm10, xmm2
00007dd052fd30a0  mulpd xmm10, xmm11
00007dd052fd30a5  vcmppd xmm1, xmm10, xmm10, 0x03
00007dd052fd30ab  ptest xmm1, xmm1
00007dd052fd30b0  jnz 0x00007DD052FD624A
00007dd052fd30b6  vmovaps xmm1, [rsp+0x80]
00007dd052fd30bf  vpermilpd xmm1, xmm1, 0x00
00007dd052fd30c5  vmovaps xmm2, [rsp+0xA0]
00007dd052fd30ce  vmovaps [rsp+0x80], xmm15
00007dd052fd30d7  movaps xmm11, xmm2
00007dd052fd30db  mulpd xmm11, xmm1
00007dd052fd30e0  vcmppd xmm15, xmm11, xmm11, 0x03
00007dd052fd30e6  ptest xmm15, xmm15
00007dd052fd30ec  jnz 0x00007DD052FD638D
00007dd052fd30f2  movaps xmm1, xmm14
00007dd052fd30f6  addpd xmm1, xmm6
00007dd052fd30fa  vcmppd xmm15, xmm1, xmm1, 0x03
00007dd052fd30ff  ptest xmm15, xmm15
00007dd052fd3105  jnz 0x00007DD052FD64CF
00007dd052fd310b  vmovaps xmm14, [rsp+0x10]
00007dd052fd3111  movaps xmm15, xmm14
00007dd052fd3115  addpd xmm15, xmm5
00007dd052fd311a  vcmppd xmm6, xmm15, xmm15, 0x03
00007dd052fd3120  ptest xmm6, xmm6
00007dd052fd3125  jnz 0x00007DD052FD6610
00007dd052fd312b  vmovaps xmm14, [rsp+0x90]
00007dd052fd3134  vpermilpd xmm14, xmm14, 0x00
00007dd052fd313a  movaps xmm6, xmm9
00007dd052fd313e  mulpd xmm6, xmm14
00007dd052fd3143  vcmppd xmm5, xmm6, xmm6, 0x03
00007dd052fd3148  ptest xmm5, xmm5
00007dd052fd314d  jnz 0x00007DD052FD6753
00007dd052fd3153  vmovaps xmm9, [rsp+0x80]
00007dd052fd315c  movaps xmm14, xmm9
00007dd052fd3160  addpd xmm14, xmm13
00007dd052fd3165  vcmppd xmm5, xmm14, xmm14, 0x03
00007dd052fd316b  ptest xmm5, xmm5
00007dd052fd3170  jnz 0x00007DD052FD6895
00007dd052fd3176  vmovaps xmm9, [rsp+0x20]
00007dd052fd317c  movaps xmm13, xmm9
00007dd052fd3180  addpd xmm13, xmm10
00007dd052fd3185  vcmppd xmm5, xmm13, xmm13, 0x03
00007dd052fd318b  ptest xmm5, xmm5
00007dd052fd3190  jnz 0x00007DD052FD69D9
00007dd052fd3196  vmovaps [rsp+0x10], xmm12
00007dd052fd319c  vmovaps xmm10, [rsp+0x10]
00007dd052fd31a2  por xmm12, xmm10
00007dd052fd31a7  movaps [r15+0x250], xmm12
00007dd052fd31af  vmovaps [rsp+0x10], xmm7
00007dd052fd31b5  vmovaps xmm12, [rsp+0x10]
00007dd052fd31bb  por xmm7, xmm12
00007dd052fd31c0  movaps [r15+0x2A0], xmm7
00007dd052fd31c8  vmovaps [rsp+0x10], xmm3
00007dd052fd31ce  vmovaps xmm12, [rsp+0x10]
00007dd052fd31d4  por xmm3, xmm12
00007dd052fd31d9  movaps [r15+0x1D0], xmm3
00007dd052fd31e1  lea rax, [r14+0x40]
00007dd052fd31e5  movups xmm12, [r13+rax*1]
00007dd052fd31eb  movaps [r15+0x2C0], xmm12
00007dd052fd31f3  vmovaps xmm10, [rsp+0x90]
00007dd052fd31fc  vpermilpd xmm10, xmm10, 0x00
00007dd052fd3202  movaps xmm9, xmm8
00007dd052fd3206  mulpd xmm9, xmm10
00007dd052fd320b  vcmppd xmm5, xmm9, xmm9, 0x03
00007dd052fd3211  ptest xmm5, xmm5
00007dd052fd3216  jnz 0x00007DD052FD6B27
00007dd052fd321c  movaps xmm10, xmm1
00007dd052fd3220  addpd xmm10, xmm11
00007dd052fd3225  vcmppd xmm8, xmm10, xmm10, 0x03
00007dd052fd322b  ptest xmm8, xmm8
00007dd052fd3231  jnz 0x00007DD052FD6C6B
00007dd052fd3237  movaps xmm1, xmm15
00007dd052fd323b  addpd xmm1, xmm6
00007dd052fd323f  vcmppd xmm11, xmm1, xmm1, 0x03
00007dd052fd3244  ptest xmm11, xmm11
00007dd052fd324a  jnz 0x00007DD052FD6DAE
00007dd052fd3250  vmovaps xmm15, [rsp+0x90]
00007dd052fd3259  vpermilpd xmm15, xmm15, 0x00
00007dd052fd325f  movaps xmm11, xmm12
00007dd052fd3263  mulpd xmm11, xmm15
00007dd052fd3268  vcmppd xmm8, xmm11, xmm11, 0x03
00007dd052fd326e  ptest xmm8, xmm8
00007dd052fd3274  jnz 0x00007DD052FD6EEF
00007dd052fd327a  vmovaps xmm15, [rsp+0x90]
00007dd052fd3283  vpermilpd xmm15, xmm15, 0x00
00007dd052fd3289  vmovaps xmm8, [rsp+0x50]
00007dd052fd328f  movaps xmm12, xmm8
00007dd052fd3293  mulpd xmm12, xmm15
00007dd052fd3298  vcmppd xmm6, xmm12, xmm12, 0x03
00007dd052fd329e  ptest xmm6, xmm6
00007dd052fd32a3  jnz 0x00007DD052FD7033
00007dd052fd32a9  vmovaps xmm15, [rsp+0x30]
00007dd052fd32af  vpermilpd xmm15, xmm15, 0x00
00007dd052fd32b5  movaps xmm8, xmm7
00007dd052fd32b9  mulpd xmm8, xmm15
00007dd052fd32be  vcmppd xmm6, xmm8, xmm8, 0x03
00007dd052fd32c4  ptest xmm6, xmm6
00007dd052fd32c9  jnz 0x00007DD052FD7177
00007dd052fd32cf  movaps xmm15, xmm14
00007dd052fd32d3  addpd xmm15, xmm9
00007dd052fd32d8  vcmppd xmm7, xmm15, xmm15, 0x03
00007dd052fd32de  ptest xmm7, xmm7
00007dd052fd32e3  jnz 0x00007DD052FD72BA
00007dd052fd32e9  vmovaps xmm14, [rsp+0x30]
00007dd052fd32ef  vpermilpd xmm14, xmm14, 0x00
00007dd052fd32f5  vmovaps xmm7, [rsp+0xF0]
00007dd052fd32fe  movaps xmm9, xmm7
00007dd052fd3302  mulpd xmm9, xmm14
00007dd052fd3307  vcmppd xmm6, xmm9, xmm9, 0x03
00007dd052fd330d  ptest xmm6, xmm6
00007dd052fd3312  jnz 0x00007DD052FD73FE
00007dd052fd3318  movaps xmm14, xmm13
00007dd052fd331c  addpd xmm14, xmm11
00007dd052fd3321  vcmppd xmm7, xmm14, xmm14, 0x03
00007dd052fd3327  ptest xmm7, xmm7
00007dd052fd332c  jnz 0x00007DD052FD7541
00007dd052fd3332  vmovaps xmm13, [rsp+0x30]
00007dd052fd3338  vpermilpd xmm13, xmm13, 0x00
00007dd052fd333e  vmovaps xmm7, [rsp+0x60]
00007dd052fd3344  movaps xmm11, xmm7
00007dd052fd3348  mulpd xmm11, xmm13
00007dd052fd334d  vcmppd xmm6, xmm11, xmm11, 0x03
00007dd052fd3353  ptest xmm6, xmm6
00007dd052fd3358  jnz 0x00007DD052FD7685
00007dd052fd335e  movaps xmm13, xmm10
00007dd052fd3362  addpd xmm13, xmm12
00007dd052fd3367  vcmppd xmm7, xmm13, xmm13, 0x03
00007dd052fd336d  ptest xmm7, xmm7
00007dd052fd3372  jnz 0x00007DD052FD77C8
00007dd052fd3378  vmovaps xmm12, [rsp+0x30]
00007dd052fd337e  vpermilpd xmm12, xmm12, 0x00
00007dd052fd3384  vmovaps xmm7, [rsp+0x70]
00007dd052fd338a  movaps xmm10, xmm7
00007dd052fd338e  mulpd xmm10, xmm12
00007dd052fd3393  vcmppd xmm6, xmm10, xmm10, 0x03
00007dd052fd3399  ptest xmm6, xmm6
00007dd052fd339e  jnz 0x00007DD052FD790C
00007dd052fd33a4  movaps xmm12, xmm1
00007dd052fd33a8  addpd xmm12, xmm8
00007dd052fd33ad  vcmppd xmm7, xmm12, xmm12, 0x03
00007dd052fd33b3  ptest xmm7, xmm7
00007dd052fd33b8  jnz 0x00007DD052FD7A4F
00007dd052fd33be  lea rax, [r14+0x70]
00007dd052fd33c2  movups xmm1, [r13+rax*1]
00007dd052fd33c8  movaps [r15+0x240], xmm1
00007dd052fd33d0  movaps xmm8, xmm15
00007dd052fd33d4  addpd xmm8, xmm9
00007dd052fd33d9  vcmppd xmm7, xmm8, xmm8, 0x03
00007dd052fd33df  ptest xmm7, xmm7
00007dd052fd33e4  jnz 0x00007DD052FD7B9C
00007dd052fd33ea  movaps [r15+0x170], xmm8
00007dd052fd33f2  vmovaps xmm15, [rsp+0x40]
00007dd052fd33f8  vpermilpd xmm15, xmm15, 0x00
00007dd052fd33fe  movaps xmm9, xmm1
00007dd052fd3402  mulpd xmm9, xmm15
00007dd052fd3407  vcmppd xmm7, xmm9, xmm9, 0x03
00007dd052fd340d  ptest xmm7, xmm7
00007dd052fd3412  jnz 0x00007DD052FD7CE0
00007dd052fd3418  vmovaps xmm1, [rsp+0x40]
00007dd052fd341e  vpermilpd xmm1, xmm1, 0x00
00007dd052fd3424  movaps xmm15, xmm4
00007dd052fd3428  mulpd xmm15, xmm1
00007dd052fd342d  vcmppd xmm7, xmm15, xmm15, 0x03
00007dd052fd3433  ptest xmm7, xmm7
00007dd052fd3438  jnz 0x00007DD052FD7E23
00007dd052fd343e  movaps [r15+0x180], xmm15
00007dd052fd3446  movaps xmm1, xmm14
00007dd052fd344a  addpd xmm1, xmm11
00007dd052fd344f  vcmppd xmm7, xmm1, xmm1, 0x03
00007dd052fd3454  ptest xmm7, xmm7
00007dd052fd3459  jnz 0x00007DD052FD7F65
00007dd052fd345f  movaps [r15+0x210], xmm1
00007dd052fd3467  movups xmm14, [r13+r14*1]
00007dd052fd346d  lea rax, [r14+0x10]
00007dd052fd3471  movups xmm11, [r13+rax*1]
00007dd052fd3477  movaps [r15+0x230], xmm11
00007dd052fd347f  movaps xmm7, xmm13
00007dd052fd3483  addpd xmm7, xmm10
00007dd052fd3488  vcmppd xmm6, xmm7, xmm7, 0x03
00007dd052fd348d  ptest xmm6, xmm6
00007dd052fd3492  jnz 0x00007DD052FD80BB
00007dd052fd3498  movaps [r15+0x130], xmm7
00007dd052fd34a0  vmovaps xmm13, [rsp+0x40]
00007dd052fd34a6  vpermilpd xmm13, xmm13, 0x00
00007dd052fd34ac  movaps xmm10, xmm11
00007dd052fd34b0  mulpd xmm10, xmm13
00007dd052fd34b5  vcmppd xmm6, xmm10, xmm10, 0x03
00007dd052fd34bb  ptest xmm6, xmm6
00007dd052fd34c0  jnz 0x00007DD052FD81FD
00007dd052fd34c6  movaps [r15+0x220], xmm10
00007dd052fd34ce  vmovaps xmm13, [rsp+0x40]
00007dd052fd34d4  vpermilpd xmm13, xmm13, 0x00
00007dd052fd34da  movaps xmm11, xmm14
00007dd052fd34de  mulpd xmm11, xmm13
00007dd052fd34e3  vcmppd xmm6, xmm11, xmm11, 0x03
00007dd052fd34e9  ptest xmm6, xmm6
00007dd052fd34ee  jnz 0x00007DD052FD8341
00007dd052fd34f4  movaps xmm14, xmm12
00007dd052fd34f8  addpd xmm14, xmm9
00007dd052fd34fd  vcmppd xmm13, xmm14, xmm14, 0x03
00007dd052fd3503  ptest xmm13, xmm13
00007dd052fd3509  jnz 0x00007DD052FD8485
00007dd052fd350f  movaps [r15+0x140], xmm14
00007dd052fd3517  movaps xmm13, xmm8
00007dd052fd351b  addpd xmm13, xmm15
00007dd052fd3520  vcmppd xmm12, xmm13, xmm13, 0x03
00007dd052fd3526  ptest xmm12, xmm12
00007dd052fd352c  jnz 0x00007DD052FD85C9
00007dd052fd3532  movaps [r15+0x150], xmm13
00007dd052fd353a  movaps xmm15, xmm1
00007dd052fd353e  addpd xmm15, xmm10
00007dd052fd3543  vcmppd xmm12, xmm15, xmm15, 0x03
00007dd052fd3549  ptest xmm12, xmm12
00007dd052fd354f  jnz 0x00007DD052FD870D
00007dd052fd3555  movaps [r15+0x160], xmm15
00007dd052fd355d  movaps xmm1, xmm7
00007dd052fd3560  addpd xmm1, xmm11
00007dd052fd3565  vcmppd xmm12, xmm1, xmm1, 0x03
00007dd052fd356a  ptest xmm12, xmm12
00007dd052fd3570  jnz 0x00007DD052FD8850
00007dd052fd3576  movaps [r15+0x120], xmm1
00007dd052fd357e  mov eax, 0x432200
00007dd052fd3583  movups [r13+rax*1], xmm14
00007dd052fd3589  mov eax, 0x432210
00007dd052fd358e  movups [r13+rax*1], xmm13
00007dd052fd3594  mov eax, 0x432220
00007dd052fd3599  movups [r13+rax*1], xmm15
00007dd052fd359f  mov eax, 0x432230
00007dd052fd35a4  movups [r13+rax*1], xmm1
00007dd052fd35aa  mov eax, [r15+0x108]
00007dd052fd35b1  sahf
00007dd052fd35b2  jnz 0x00007DD052FD35E4
00007dd052fd35b4  cmp dword ptr [r15+0x318], 0x00
00007dd052fd35bc  jz 0x00007DD052FDEAE0
00007dd052fd35c2  nop [rax+rax*1], ax
00007dd052fd35cb  nop [rax+rax*1], eax
00007dd052fd35d3  mov eax, 0x4106D0
00007dd052fd35d8  mov [r15+0x100], rax
00007dd052fd35df  jmp 0x00007DD052DFE110
00007dd052fd35e4  cmp dword ptr [r15+0x318], 0x00
00007dd052fd35ec  jz 0x00007DD052FD89C0
00007dd052fd35f2  nop [rax+rax*1], ax
00007dd052fd35fb  nop [rax+rax*1], eax
00007dd052fd3603  mov eax, 0x410504
00007dd052fd3608  mov [r15+0x100], rax
00007dd052fd360f  jmp 0x00007DD052DFE110
00007dd052fd3614  int3
00007dd052fd3615  call 0x00007DD052ED64F0
00007dd052fd361a  jmp 0x00007DD052FD2311
00007dd052fd361f  call 0x00007DD052EE5820
00007dd052fd3624  jmp 0x00007DD052FD231E
00007dd052fd3629  call 0x00007DD052EE3320
00007dd052fd362e  jmp 0x00007DD052FD2332
00007dd052fd3633  call 0x00007DD052EE20A0
00007dd052fd3638  jmp 0x00007DD052FD233C
00007dd052fd363d  call 0x00007DD052E09D70
00007dd052fd3642  jmp 0x00007DD052FD234A
00007dd052fd3647  call 0x00007DD052EDFBC0
00007dd052fd364c  jmp 0x00007DD052FD2354
00007dd052fd3651  call 0x00007DD052EC4740
00007dd052fd3656  jmp 0x00007DD052FD2368
00007dd052fd365b  call 0x00007DD052EB5400
00007dd052fd3660  jmp 0x00007DD052FD2375
00007dd052fd3665  call 0x00007DD052EB52F0
00007dd052fd366a  jmp 0x00007DD052FD2382
00007dd052fd366f  call 0x00007DD052EC4620
00007dd052fd3674  jmp 0x00007DD052FD238F
00007dd052fd3679  call 0x00007DD052EBD750
00007dd052fd367e  jmp 0x00007DD052FD239C
00007dd052fd3683  call 0x00007DD052EBC4E0
00007dd052fd3688  jmp 0x00007DD052FD23A9
00007dd052fd368d  call 0x00007DD052EBB270
00007dd052fd3692  jmp 0x00007DD052FD23B6
00007dd052fd3697  call 0x00007DD052EBA000
00007dd052fd369c  jmp 0x00007DD052FD23C3
00007dd052fd36a1  call 0x00007DD052EC4740
00007dd052fd36a6  jmp 0x00007DD052FD23D0
00007dd052fd36ab  call 0x00007DD052EB5400
00007dd052fd36b0  jmp 0x00007DD052FD23DD
00007dd052fd36b5  call 0x00007DD052EB52F0
00007dd052fd36ba  jmp 0x00007DD052FD23EA
00007dd052fd36bf  call 0x00007DD052EC4620
00007dd052fd36c4  jmp 0x00007DD052FD23F7
00007dd052fd36c9  call 0x00007DD052EB8D90
00007dd052fd36ce  jmp 0x00007DD052FD2404
00007dd052fd36d3  call 0x00007DD052EB8A20
00007dd052fd36d8  jmp 0x00007DD052FD2411
00007dd052fd36dd  call 0x00007DD052EB77B0
00007dd052fd36e2  jmp 0x00007DD052FD241B
00007dd052fd36e7  call 0x00007DD052EB6550
00007dd052fd36ec  jmp 0x00007DD052FD2425
00007dd052fd36f1  call 0x00007DD052EB5400
00007dd052fd36f6  jmp 0x00007DD052FD2437
00007dd052fd36fb  call 0x00007DD052EC0FC0
00007dd052fd3700  jmp 0x00007DD052FD2441
00007dd052fd3705  call 0x00007DD052EB52F0
00007dd052fd370a  jmp 0x00007DD052FD244B
00007dd052fd370f  call 0x00007DD052EC0EA0
00007dd052fd3714  jmp 0x00007DD052FD2455
00007dd052fd3719  call 0x00007DD052EBFD50
00007dd052fd371e  jmp 0x00007DD052FD245F
00007dd052fd3723  call 0x00007DD052EB8EA0
00007dd052fd3728  jmp 0x00007DD052FD2469
00007dd052fd372d  call 0x00007DD052EBFC30
00007dd052fd3732  jmp 0x00007DD052FD2476
00007dd052fd3737  call 0x00007DD052EB8D90
00007dd052fd373c  jmp 0x00007DD052FD2483
00007dd052fd3741  call 0x00007DD052EB52F0
00007dd052fd3746  jmp 0x00007DD052FD2496
00007dd052fd374b  call 0x00007DD052EB52F0
00007dd052fd3750  jmp 0x00007DD052FD24A9
00007dd052fd3755  call 0x00007DD052EC0FC0
00007dd052fd375a  jmp 0x00007DD052FD24B6
00007dd052fd375f  call 0x00007DD052EC0FC0
00007dd052fd3764  jmp 0x00007DD052FD24C9
00007dd052fd3769  call 0x00007DD052EC0EA0
00007dd052fd376e  jmp 0x00007DD052FD24D6
00007dd052fd3773  call 0x00007DD052EB52F0
00007dd052fd3778  jmp 0x00007DD052FD24E9
00007dd052fd377d  call 0x00007DD052EB52F0
00007dd052fd3782  jmp 0x00007DD052FD24FC
00007dd052fd3787  call 0x00007DD052EB52F0
00007dd052fd378c  jmp 0x00007DD052FD250F
00007dd052fd3791  call 0x00007DD052EB52F0
00007dd052fd3796  jmp 0x00007DD052FD252A
00007dd052fd379b  call 0x00007DD052EB52F0
00007dd052fd37a0  jmp 0x00007DD052FD253D
00007dd052fd37a5  call 0x00007DD052EB5400
00007dd052fd37aa  jmp 0x00007DD052FD257E
00007dd052fd37af  call 0x00007DD052EC0FC0
00007dd052fd37b4  jmp 0x00007DD052FD258B
00007dd052fd37b9  call 0x00007DD052EB52F0
00007dd052fd37be  jmp 0x00007DD052FD2598
00007dd052fd37c3  call 0x00007DD052EC0EA0
00007dd052fd37c8  jmp 0x00007DD052FD25A5
00007dd052fd37cd  call 0x00007DD052DFF540
00007dd052fd37d2  jmp 0x00007DD052FD25C3
00007dd052fd37d7  call 0x00007DD052E08C20
00007dd052fd37dc  jmp 0x00007DD052FD25CD
00007dd052fd37e1  call 0x00007DD052EE21C0
00007dd052fd37e6  jmp 0x00007DD052FD25D3
00007dd052fd37eb  call 0x00007DD052DFF540
00007dd052fd37f0  jmp 0x00007DD052FD25E3
00007dd052fd37f5  call 0x00007DD052EC0370
00007dd052fd37fa  jmp 0x00007DD052FD2611
00007dd052fd37ff  call 0x00007DD052EBF100
00007dd052fd3804  jmp 0x00007DD052FD261A
00007dd052fd3809  call 0x00007DD052EC0370
00007dd052fd380e  jmp 0x00007DD052FD2674
00007dd052fd3813  call 0x00007DD052EBF100
00007dd052fd3818  jmp 0x00007DD052FD267D
00007dd052fd381d  call 0x00007DD052EC0370
00007dd052fd3822  jmp 0x00007DD052FD26C6
00007dd052fd3827  call 0x00007DD052EBF100
00007dd052fd382c  jmp 0x00007DD052FD26CF
00007dd052fd3831  call 0x00007DD052E0B720
00007dd052fd3836  jmp 0x00007DD052FD2714
00007dd052fd383b  call 0x00007DD052EB47C0
00007dd052fd3840  jmp 0x00007DD052FD2727
00007dd052fd3845  call 0x00007DD052E08B00
00007dd052fd384a  jmp 0x00007DD052FD273E
00007dd052fd384f  call 0x00007DD052DFF430
00007dd052fd3854  jmp 0x00007DD052FD2751
00007dd052fd3859  call 0x00007DD052DFF430
00007dd052fd385e  jmp 0x00007DD052FD2764
00007dd052fd3863  sub rsp, 0x08
00007dd052fd3867  push rax
00007dd052fd3868  push rcx
00007dd052fd3869  push rdx
00007dd052fd386a  push rdi
00007dd052fd386b  push rsi
00007dd052fd386c  push r8
00007dd052fd386e  push r9
00007dd052fd3870  push r10
00007dd052fd3872  push r11
00007dd052fd3874  sub rsp, 0xF0
00007dd052fd387b  vmovaps [rsp], xmm0
00007dd052fd3880  vmovaps [rsp+0x10], xmm2
00007dd052fd3886  vmovaps [rsp+0x20], xmm3
00007dd052fd388c  vmovaps [rsp+0x30], xmm4
00007dd052fd3892  vmovaps [rsp+0x40], xmm5
00007dd052fd3898  vmovaps [rsp+0x50], xmm6
00007dd052fd389e  vmovaps [rsp+0x60], xmm7
00007dd052fd38a4  vmovaps [rsp+0x70], xmm8
00007dd052fd38aa  vmovaps [rsp+0x80], xmm9
00007dd052fd38b3  vmovaps [rsp+0x90], xmm10
00007dd052fd38bc  vmovaps [rsp+0xA0], xmm11
00007dd052fd38c5  vmovaps [rsp+0xB0], xmm12
00007dd052fd38ce  vmovaps [rsp+0xC0], xmm13
00007dd052fd38d7  vmovaps [rsp+0xD0], xmm14
00007dd052fd38e0  vmovaps [rsp+0xE0], xmm15
00007dd052fd38e9  sub rsp, 0x30
00007dd052fd38ed  movaps [rsp], xmm1
00007dd052fd38f1  movaps [rsp+0x10], xmm12
00007dd052fd38f7  movaps [rsp+0x20], xmm15
00007dd052fd38fd  lea rdi, [rsp]
00007dd052fd3901  mov esi, 0x00
00007dd052fd3906  mov rax, 0x61D0404B9530
00007dd052fd3910  call rax
00007dd052fd3912  movaps xmm1, [rsp]
00007dd052fd3916  add rsp, 0x30
00007dd052fd391a  vmovaps xmm0, [rsp]
00007dd052fd391f  vmovaps xmm2, [rsp+0x10]
00007dd052fd3925  vmovaps xmm3, [rsp+0x20]
00007dd052fd392b  vmovaps xmm4, [rsp+0x30]
00007dd052fd3931  vmovaps xmm5, [rsp+0x40]
00007dd052fd3937  vmovaps xmm6, [rsp+0x50]
00007dd052fd393d  vmovaps xmm7, [rsp+0x60]
00007dd052fd3943  vmovaps xmm8, [rsp+0x70]
00007dd052fd3949  vmovaps xmm9, [rsp+0x80]
00007dd052fd3952  vmovaps xmm10, [rsp+0x90]
00007dd052fd395b  vmovaps xmm11, [rsp+0xA0]
00007dd052fd3964  vmovaps xmm12, [rsp+0xB0]
00007dd052fd396d  vmovaps xmm13, [rsp+0xC0]
00007dd052fd3976  vmovaps xmm14, [rsp+0xD0]
00007dd052fd397f  vmovaps xmm15, [rsp+0xE0]
00007dd052fd3988  add rsp, 0xF0
00007dd052fd398f  pop r11
00007dd052fd3991  pop r10
00007dd052fd3993  pop r9
00007dd052fd3995  pop r8
00007dd052fd3997  pop rsi
00007dd052fd3998  pop rdi
00007dd052fd3999  pop rdx
00007dd052fd399a  pop rcx
00007dd052fd399b  pop rax
00007dd052fd399c  add rsp, 0x08
00007dd052fd39a0  jmp 0x00007DD052FD27B2
00007dd052fd39a5  sub rsp, 0x08
00007dd052fd39a9  push rax
00007dd052fd39aa  push rcx
00007dd052fd39ab  push rdx
00007dd052fd39ac  push rdi
00007dd052fd39ad  push rsi
00007dd052fd39ae  push r8
00007dd052fd39b0  push r9
00007dd052fd39b2  push r10
00007dd052fd39b4  push r11
00007dd052fd39b6  sub rsp, 0xF0
00007dd052fd39bd  vmovaps [rsp], xmm0
00007dd052fd39c2  vmovaps [rsp+0x10], xmm1
00007dd052fd39c8  vmovaps [rsp+0x20], xmm2
00007dd052fd39ce  vmovaps [rsp+0x30], xmm3
00007dd052fd39d4  vmovaps [rsp+0x40], xmm4
00007dd052fd39da  vmovaps [rsp+0x50], xmm5
00007dd052fd39e0  vmovaps [rsp+0x60], xmm6
00007dd052fd39e6  vmovaps [rsp+0x70], xmm7
00007dd052fd39ec  vmovaps [rsp+0x80], xmm8
00007dd052fd39f5  vmovaps [rsp+0x90], xmm9
00007dd052fd39fe  vmovaps [rsp+0xA0], xmm10
00007dd052fd3a07  vmovaps [rsp+0xB0], xmm11
00007dd052fd3a10  vmovaps [rsp+0xC0], xmm12
00007dd052fd3a19  vmovaps [rsp+0xD0], xmm13
00007dd052fd3a22  vmovaps [rsp+0xE0], xmm15
00007dd052fd3a2b  sub rsp, 0x30
00007dd052fd3a2f  movaps [rsp], xmm14
00007dd052fd3a34  movaps [rsp+0x10], xmm1
00007dd052fd3a39  movaps [rsp+0x20], xmm15
00007dd052fd3a3f  lea rdi, [rsp]
00007dd052fd3a43  mov esi, 0x00
00007dd052fd3a48  mov rax, 0x61D0404B9530
00007dd052fd3a52  call rax
00007dd052fd3a54  movaps xmm14, [rsp]
00007dd052fd3a59  add rsp, 0x30
00007dd052fd3a5d  vmovaps xmm0, [rsp]
00007dd052fd3a62  vmovaps xmm1, [rsp+0x10]
00007dd052fd3a68  vmovaps xmm2, [rsp+0x20]
00007dd052fd3a6e  vmovaps xmm3, [rsp+0x30]
00007dd052fd3a74  vmovaps xmm4, [rsp+0x40]
00007dd052fd3a7a  vmovaps xmm5, [rsp+0x50]
00007dd052fd3a80  vmovaps xmm6, [rsp+0x60]
00007dd052fd3a86  vmovaps xmm7, [rsp+0x70]
00007dd052fd3a8c  vmovaps xmm8, [rsp+0x80]
00007dd052fd3a95  vmovaps xmm9, [rsp+0x90]
00007dd052fd3a9e  vmovaps xmm10, [rsp+0xA0]
00007dd052fd3aa7  vmovaps xmm11, [rsp+0xB0]
00007dd052fd3ab0  vmovaps xmm12, [rsp+0xC0]
00007dd052fd3ab9  vmovaps xmm13, [rsp+0xD0]
00007dd052fd3ac2  vmovaps xmm15, [rsp+0xE0]
00007dd052fd3acb  add rsp, 0xF0
00007dd052fd3ad2  pop r11
00007dd052fd3ad4  pop r10
00007dd052fd3ad6  pop r9
00007dd052fd3ad8  pop r8
00007dd052fd3ada  pop rsi
00007dd052fd3adb  pop rdi
00007dd052fd3adc  pop rdx
00007dd052fd3add  pop rcx
00007dd052fd3ade  pop rax
00007dd052fd3adf  add rsp, 0x08
00007dd052fd3ae3  jmp 0x00007DD052FD2800
00007dd052fd3ae8  sub rsp, 0x08
00007dd052fd3aec  push rax
00007dd052fd3aed  push rcx
00007dd052fd3aee  push rdx
00007dd052fd3aef  push rdi
00007dd052fd3af0  push rsi
00007dd052fd3af1  push r8
00007dd052fd3af3  push r9
00007dd052fd3af5  push r10
00007dd052fd3af7  push r11
00007dd052fd3af9  sub rsp, 0xF0
00007dd052fd3b00  vmovaps [rsp], xmm0
00007dd052fd3b05  vmovaps [rsp+0x10], xmm1
00007dd052fd3b0b  vmovaps [rsp+0x20], xmm2
00007dd052fd3b11  vmovaps [rsp+0x30], xmm3
00007dd052fd3b17  vmovaps [rsp+0x40], xmm4
00007dd052fd3b1d  vmovaps [rsp+0x50], xmm5
00007dd052fd3b23  vmovaps [rsp+0x60], xmm6
00007dd052fd3b29  vmovaps [rsp+0x70], xmm7
00007dd052fd3b2f  vmovaps [rsp+0x80], xmm8
00007dd052fd3b38  vmovaps [rsp+0x90], xmm9
00007dd052fd3b41  vmovaps [rsp+0xA0], xmm10
00007dd052fd3b4a  vmovaps [rsp+0xB0], xmm11
00007dd052fd3b53  vmovaps [rsp+0xC0], xmm12
00007dd052fd3b5c  vmovaps [rsp+0xD0], xmm13
00007dd052fd3b65  vmovaps [rsp+0xE0], xmm14
00007dd052fd3b6e  sub rsp, 0x30
00007dd052fd3b72  movaps [rsp], xmm15
00007dd052fd3b77  movaps [rsp+0x10], xmm12
00007dd052fd3b7d  movaps [rsp+0x20], xmm13
00007dd052fd3b83  lea rdi, [rsp]
00007dd052fd3b87  mov esi, 0x00
00007dd052fd3b8c  mov rax, 0x61D0404B9530
00007dd052fd3b96  call rax
00007dd052fd3b98  movaps xmm15, [rsp]
00007dd052fd3b9d  add rsp, 0x30
00007dd052fd3ba1  vmovaps xmm0, [rsp]
00007dd052fd3ba6  vmovaps xmm1, [rsp+0x10]
00007dd052fd3bac  vmovaps xmm2, [rsp+0x20]
00007dd052fd3bb2  vmovaps xmm3, [rsp+0x30]
00007dd052fd3bb8  vmovaps xmm4, [rsp+0x40]
00007dd052fd3bbe  vmovaps xmm5, [rsp+0x50]
00007dd052fd3bc4  vmovaps xmm6, [rsp+0x60]
00007dd052fd3bca  vmovaps xmm7, [rsp+0x70]
00007dd052fd3bd0  vmovaps xmm8, [rsp+0x80]
00007dd052fd3bd9  vmovaps xmm9, [rsp+0x90]
00007dd052fd3be2  vmovaps xmm10, [rsp+0xA0]
00007dd052fd3beb  vmovaps xmm11, [rsp+0xB0]
00007dd052fd3bf4  vmovaps xmm12, [rsp+0xC0]
00007dd052fd3bfd  vmovaps xmm13, [rsp+0xD0]
00007dd052fd3c06  vmovaps xmm14, [rsp+0xE0]
00007dd052fd3c0f  add rsp, 0xF0
00007dd052fd3c16  pop r11
00007dd052fd3c18  pop r10
00007dd052fd3c1a  pop r9
00007dd052fd3c1c  pop r8
00007dd052fd3c1e  pop rsi
00007dd052fd3c1f  pop rdi
00007dd052fd3c20  pop rdx
00007dd052fd3c21  pop rcx
00007dd052fd3c22  pop rax
00007dd052fd3c23  add rsp, 0x08
00007dd052fd3c27  jmp 0x00007DD052FD2835
00007dd052fd3c2c  sub rsp, 0x08
00007dd052fd3c30  push rax
00007dd052fd3c31  push rcx
00007dd052fd3c32  push rdx
00007dd052fd3c33  push rdi
00007dd052fd3c34  push rsi
00007dd052fd3c35  push r8
00007dd052fd3c37  push r9
00007dd052fd3c39  push r10
00007dd052fd3c3b  push r11
00007dd052fd3c3d  sub rsp, 0xF0
00007dd052fd3c44  vmovaps [rsp], xmm0
00007dd052fd3c49  vmovaps [rsp+0x10], xmm2
00007dd052fd3c4f  vmovaps [rsp+0x20], xmm3
00007dd052fd3c55  vmovaps [rsp+0x30], xmm4
00007dd052fd3c5b  vmovaps [rsp+0x40], xmm5
00007dd052fd3c61  vmovaps [rsp+0x50], xmm6
00007dd052fd3c67  vmovaps [rsp+0x60], xmm7
00007dd052fd3c6d  vmovaps [rsp+0x70], xmm8
00007dd052fd3c73  vmovaps [rsp+0x80], xmm9
00007dd052fd3c7c  vmovaps [rsp+0x90], xmm10
00007dd052fd3c85  vmovaps [rsp+0xA0], xmm11
00007dd052fd3c8e  vmovaps [rsp+0xB0], xmm12
00007dd052fd3c97  vmovaps [rsp+0xC0], xmm13
00007dd052fd3ca0  vmovaps [rsp+0xD0], xmm14
00007dd052fd3ca9  vmovaps [rsp+0xE0], xmm15
00007dd052fd3cb2  sub rsp, 0x30
00007dd052fd3cb6  movaps [rsp], xmm1
00007dd052fd3cba  movaps [rsp+0x10], xmm12
00007dd052fd3cc0  movaps [rsp+0x20], xmm10
00007dd052fd3cc6  lea rdi, [rsp]
00007dd052fd3cca  mov esi, 0x00
00007dd052fd3ccf  mov rax, 0x61D0404B9530
00007dd052fd3cd9  call rax
00007dd052fd3cdb  movaps xmm1, [rsp]
00007dd052fd3cdf  add rsp, 0x30
00007dd052fd3ce3  vmovaps xmm0, [rsp]
00007dd052fd3ce8  vmovaps xmm2, [rsp+0x10]
00007dd052fd3cee  vmovaps xmm3, [rsp+0x20]
00007dd052fd3cf4  vmovaps xmm4, [rsp+0x30]
00007dd052fd3cfa  vmovaps xmm5, [rsp+0x40]
00007dd052fd3d00  vmovaps xmm6, [rsp+0x50]
00007dd052fd3d06  vmovaps xmm7, [rsp+0x60]
00007dd052fd3d0c  vmovaps xmm8, [rsp+0x70]
00007dd052fd3d12  vmovaps xmm9, [rsp+0x80]
00007dd052fd3d1b  vmovaps xmm10, [rsp+0x90]
00007dd052fd3d24  vmovaps xmm11, [rsp+0xA0]
00007dd052fd3d2d  vmovaps xmm12, [rsp+0xB0]
00007dd052fd3d36  vmovaps xmm13, [rsp+0xC0]
00007dd052fd3d3f  vmovaps xmm14, [rsp+0xD0]
00007dd052fd3d48  vmovaps xmm15, [rsp+0xE0]
00007dd052fd3d51  add rsp, 0xF0
00007dd052fd3d58  pop r11
00007dd052fd3d5a  pop r10
00007dd052fd3d5c  pop r9
00007dd052fd3d5e  pop r8
00007dd052fd3d60  pop rsi
00007dd052fd3d61  pop rdi
00007dd052fd3d62  pop rdx
00007dd052fd3d63  pop rcx
00007dd052fd3d64  pop rax
00007dd052fd3d65  add rsp, 0x08
00007dd052fd3d69  jmp 0x00007DD052FD284F
00007dd052fd3d6e  sub rsp, 0x08
00007dd052fd3d72  push rax
00007dd052fd3d73  push rcx
00007dd052fd3d74  push rdx
00007dd052fd3d75  push rdi
00007dd052fd3d76  push rsi
00007dd052fd3d77  push r8
00007dd052fd3d79  push r9
00007dd052fd3d7b  push r10
00007dd052fd3d7d  push r11
00007dd052fd3d7f  sub rsp, 0xF0
00007dd052fd3d86  vmovaps [rsp], xmm0
00007dd052fd3d8b  vmovaps [rsp+0x10], xmm1
00007dd052fd3d91  vmovaps [rsp+0x20], xmm2
00007dd052fd3d97  vmovaps [rsp+0x30], xmm3
00007dd052fd3d9d  vmovaps [rsp+0x40], xmm4
00007dd052fd3da3  vmovaps [rsp+0x50], xmm5
00007dd052fd3da9  vmovaps [rsp+0x60], xmm6
00007dd052fd3daf  vmovaps [rsp+0x70], xmm7
00007dd052fd3db5  vmovaps [rsp+0x80], xmm8
00007dd052fd3dbe  vmovaps [rsp+0x90], xmm9
00007dd052fd3dc7  vmovaps [rsp+0xA0], xmm10
00007dd052fd3dd0  vmovaps [rsp+0xB0], xmm11
00007dd052fd3dd9  vmovaps [rsp+0xC0], xmm12
00007dd052fd3de2  vmovaps [rsp+0xD0], xmm14
00007dd052fd3deb  vmovaps [rsp+0xE0], xmm15
00007dd052fd3df4  sub rsp, 0x30
00007dd052fd3df8  movaps [rsp], xmm13
00007dd052fd3dfd  movaps [rsp+0x10], xmm12
00007dd052fd3e03  movaps [rsp+0x20], xmm2
00007dd052fd3e08  lea rdi, [rsp]
00007dd052fd3e0c  mov esi, 0x00
00007dd052fd3e11  mov rax, 0x61D0404B9530
00007dd052fd3e1b  call rax
00007dd052fd3e1d  movaps xmm13, [rsp]
00007dd052fd3e22  add rsp, 0x30
00007dd052fd3e26  vmovaps xmm0, [rsp]
00007dd052fd3e2b  vmovaps xmm1, [rsp+0x10]
00007dd052fd3e31  vmovaps xmm2, [rsp+0x20]
00007dd052fd3e37  vmovaps xmm3, [rsp+0x30]
00007dd052fd3e3d  vmovaps xmm4, [rsp+0x40]
00007dd052fd3e43  vmovaps xmm5, [rsp+0x50]
00007dd052fd3e49  vmovaps xmm6, [rsp+0x60]
00007dd052fd3e4f  vmovaps xmm7, [rsp+0x70]
00007dd052fd3e55  vmovaps xmm8, [rsp+0x80]
00007dd052fd3e5e  vmovaps xmm9, [rsp+0x90]
00007dd052fd3e67  vmovaps xmm10, [rsp+0xA0]
00007dd052fd3e70  vmovaps xmm11, [rsp+0xB0]
00007dd052fd3e79  vmovaps xmm12, [rsp+0xC0]
00007dd052fd3e82  vmovaps xmm14, [rsp+0xD0]
00007dd052fd3e8b  vmovaps xmm15, [rsp+0xE0]
00007dd052fd3e94  add rsp, 0xF0
00007dd052fd3e9b  pop r11
00007dd052fd3e9d  pop r10
00007dd052fd3e9f  pop r9
00007dd052fd3ea1  pop r8
00007dd052fd3ea3  pop rsi
00007dd052fd3ea4  pop rdi
00007dd052fd3ea5  pop rdx
00007dd052fd3ea6  pop rcx
00007dd052fd3ea7  pop rax
00007dd052fd3ea8  add rsp, 0x08
00007dd052fd3eac  jmp 0x00007DD052FD286A
00007dd052fd3eb1  sub rsp, 0x08
00007dd052fd3eb5  push rax
00007dd052fd3eb6  push rcx
00007dd052fd3eb7  push rdx
00007dd052fd3eb8  push rdi
00007dd052fd3eb9  push rsi
00007dd052fd3eba  push r8
00007dd052fd3ebc  push r9
00007dd052fd3ebe  push r10
00007dd052fd3ec0  push r11
00007dd052fd3ec2  sub rsp, 0xF0
00007dd052fd3ec9  vmovaps [rsp], xmm0
00007dd052fd3ece  vmovaps [rsp+0x10], xmm2
00007dd052fd3ed4  vmovaps [rsp+0x20], xmm3
00007dd052fd3eda  vmovaps [rsp+0x30], xmm4
00007dd052fd3ee0  vmovaps [rsp+0x40], xmm5
00007dd052fd3ee6  vmovaps [rsp+0x50], xmm6
00007dd052fd3eec  vmovaps [rsp+0x60], xmm7
00007dd052fd3ef2  vmovaps [rsp+0x70], xmm8
00007dd052fd3ef8  vmovaps [rsp+0x80], xmm9
00007dd052fd3f01  vmovaps [rsp+0x90], xmm10
00007dd052fd3f0a  vmovaps [rsp+0xA0], xmm11
00007dd052fd3f13  vmovaps [rsp+0xB0], xmm12
00007dd052fd3f1c  vmovaps [rsp+0xC0], xmm13
00007dd052fd3f25  vmovaps [rsp+0xD0], xmm14
00007dd052fd3f2e  vmovaps [rsp+0xE0], xmm15
00007dd052fd3f37  sub rsp, 0x30
00007dd052fd3f3b  movaps [rsp], xmm1
00007dd052fd3f3f  movaps [rsp+0x10], xmm10
00007dd052fd3f45  movaps [rsp+0x20], xmm2
00007dd052fd3f4a  lea rdi, [rsp]
00007dd052fd3f4e  mov esi, 0x00
00007dd052fd3f53  mov rax, 0x61D0404B9530
00007dd052fd3f5d  call rax
00007dd052fd3f5f  movaps xmm1, [rsp]
00007dd052fd3f63  add rsp, 0x30
00007dd052fd3f67  vmovaps xmm0, [rsp]
00007dd052fd3f6c  vmovaps xmm2, [rsp+0x10]
00007dd052fd3f72  vmovaps xmm3, [rsp+0x20]
00007dd052fd3f78  vmovaps xmm4, [rsp+0x30]
00007dd052fd3f7e  vmovaps xmm5, [rsp+0x40]
00007dd052fd3f84  vmovaps xmm6, [rsp+0x50]
00007dd052fd3f8a  vmovaps xmm7, [rsp+0x60]
00007dd052fd3f90  vmovaps xmm8, [rsp+0x70]
00007dd052fd3f96  vmovaps xmm9, [rsp+0x80]
00007dd052fd3f9f  vmovaps xmm10, [rsp+0x90]
00007dd052fd3fa8  vmovaps xmm11, [rsp+0xA0]
00007dd052fd3fb1  vmovaps xmm12, [rsp+0xB0]
00007dd052fd3fba  vmovaps xmm13, [rsp+0xC0]
00007dd052fd3fc3  vmovaps xmm14, [rsp+0xD0]
00007dd052fd3fcc  vmovaps xmm15, [rsp+0xE0]
00007dd052fd3fd5  add rsp, 0xF0
00007dd052fd3fdc  pop r11
00007dd052fd3fde  pop r10
00007dd052fd3fe0  pop r9
00007dd052fd3fe2  pop r8
00007dd052fd3fe4  pop rsi
00007dd052fd3fe5  pop rdi
00007dd052fd3fe6  pop rdx
00007dd052fd3fe7  pop rcx
00007dd052fd3fe8  pop rax
00007dd052fd3fe9  add rsp, 0x08
00007dd052fd3fed  jmp 0x00007DD052FD28D2
00007dd052fd3ff2  sub rsp, 0x08
00007dd052fd3ff6  push rax
00007dd052fd3ff7  push rcx
00007dd052fd3ff8  push rdx
00007dd052fd3ff9  push rdi
00007dd052fd3ffa  push rsi
00007dd052fd3ffb  push r8
00007dd052fd3ffd  push r9
00007dd052fd3fff  push r10
00007dd052fd4001  push r11
00007dd052fd4003  sub rsp, 0xF0
00007dd052fd400a  vmovaps [rsp], xmm0
00007dd052fd400f  vmovaps [rsp+0x10], xmm1
00007dd052fd4015  vmovaps [rsp+0x20], xmm2
00007dd052fd401b  vmovaps [rsp+0x30], xmm3
00007dd052fd4021  vmovaps [rsp+0x40], xmm4
00007dd052fd4027  vmovaps [rsp+0x50], xmm5
00007dd052fd402d  vmovaps [rsp+0x60], xmm6
00007dd052fd4033  vmovaps [rsp+0x70], xmm7
00007dd052fd4039  vmovaps [rsp+0x80], xmm8
00007dd052fd4042  vmovaps [rsp+0x90], xmm9
00007dd052fd404b  vmovaps [rsp+0xA0], xmm10
00007dd052fd4054  vmovaps [rsp+0xB0], xmm11
00007dd052fd405d  vmovaps [rsp+0xC0], xmm12
00007dd052fd4066  vmovaps [rsp+0xD0], xmm13
00007dd052fd406f  vmovaps [rsp+0xE0], xmm14
00007dd052fd4078  sub rsp, 0x30
00007dd052fd407c  movaps [rsp], xmm15
00007dd052fd4081  movaps [rsp+0x10], xmm10
00007dd052fd4087  movaps [rsp+0x20], xmm2
00007dd052fd408c  lea rdi, [rsp]
00007dd052fd4090  mov esi, 0x00
00007dd052fd4095  mov rax, 0x61D0404B9530
00007dd052fd409f  call rax
00007dd052fd40a1  movaps xmm15, [rsp]
00007dd052fd40a6  add rsp, 0x30
00007dd052fd40aa  vmovaps xmm0, [rsp]
00007dd052fd40af  vmovaps xmm1, [rsp+0x10]
00007dd052fd40b5  vmovaps xmm2, [rsp+0x20]
00007dd052fd40bb  vmovaps xmm3, [rsp+0x30]
00007dd052fd40c1  vmovaps xmm4, [rsp+0x40]
00007dd052fd40c7  vmovaps xmm5, [rsp+0x50]
00007dd052fd40cd  vmovaps xmm6, [rsp+0x60]
00007dd052fd40d3  vmovaps xmm7, [rsp+0x70]
00007dd052fd40d9  vmovaps xmm8, [rsp+0x80]
00007dd052fd40e2  vmovaps xmm9, [rsp+0x90]
00007dd052fd40eb  vmovaps xmm10, [rsp+0xA0]
00007dd052fd40f4  vmovaps xmm11, [rsp+0xB0]
00007dd052fd40fd  vmovaps xmm12, [rsp+0xC0]
00007dd052fd4106  vmovaps xmm13, [rsp+0xD0]
00007dd052fd410f  vmovaps xmm14, [rsp+0xE0]
00007dd052fd4118  add rsp, 0xF0
00007dd052fd411f  pop r11
00007dd052fd4121  pop r10
00007dd052fd4123  pop r9
00007dd052fd4125  pop r8
00007dd052fd4127  pop rsi
00007dd052fd4128  pop rdi
00007dd052fd4129  pop rdx
00007dd052fd412a  pop rcx
00007dd052fd412b  pop rax
00007dd052fd412c  add rsp, 0x08
00007dd052fd4130  jmp 0x00007DD052FD2924
00007dd052fd4135  sub rsp, 0x08
00007dd052fd4139  push rax
00007dd052fd413a  push rcx
00007dd052fd413b  push rdx
00007dd052fd413c  push rdi
00007dd052fd413d  push rsi
00007dd052fd413e  push r8
00007dd052fd4140  push r9
00007dd052fd4142  push r10
00007dd052fd4144  push r11
00007dd052fd4146  sub rsp, 0xF0
00007dd052fd414d  vmovaps [rsp], xmm0
00007dd052fd4152  vmovaps [rsp+0x10], xmm2
00007dd052fd4158  vmovaps [rsp+0x20], xmm3
00007dd052fd415e  vmovaps [rsp+0x30], xmm4
00007dd052fd4164  vmovaps [rsp+0x40], xmm5
00007dd052fd416a  vmovaps [rsp+0x50], xmm6
00007dd052fd4170  vmovaps [rsp+0x60], xmm7
00007dd052fd4176  vmovaps [rsp+0x70], xmm8
00007dd052fd417c  vmovaps [rsp+0x80], xmm9
00007dd052fd4185  vmovaps [rsp+0x90], xmm10
00007dd052fd418e  vmovaps [rsp+0xA0], xmm11
00007dd052fd4197  vmovaps [rsp+0xB0], xmm12
00007dd052fd41a0  vmovaps [rsp+0xC0], xmm13
00007dd052fd41a9  vmovaps [rsp+0xD0], xmm14
00007dd052fd41b2  vmovaps [rsp+0xE0], xmm15
00007dd052fd41bb  sub rsp, 0x30
00007dd052fd41bf  movaps [rsp], xmm1
00007dd052fd41c3  movaps [rsp+0x10], xmm10
00007dd052fd41c9  movaps [rsp+0x20], xmm15
00007dd052fd41cf  lea rdi, [rsp]
00007dd052fd41d3  mov esi, 0x00
00007dd052fd41d8  mov rax, 0x61D0404B9530
00007dd052fd41e2  call rax
00007dd052fd41e4  movaps xmm1, [rsp]
00007dd052fd41e8  add rsp, 0x30
00007dd052fd41ec  vmovaps xmm0, [rsp]
00007dd052fd41f1  vmovaps xmm2, [rsp+0x10]
00007dd052fd41f7  vmovaps xmm3, [rsp+0x20]
00007dd052fd41fd  vmovaps xmm4, [rsp+0x30]
00007dd052fd4203  vmovaps xmm5, [rsp+0x40]
00007dd052fd4209  vmovaps xmm6, [rsp+0x50]
00007dd052fd420f  vmovaps xmm7, [rsp+0x60]
00007dd052fd4215  vmovaps xmm8, [rsp+0x70]
00007dd052fd421b  vmovaps xmm9, [rsp+0x80]
00007dd052fd4224  vmovaps xmm10, [rsp+0x90]
00007dd052fd422d  vmovaps xmm11, [rsp+0xA0]
00007dd052fd4236  vmovaps xmm12, [rsp+0xB0]
00007dd052fd423f  vmovaps xmm13, [rsp+0xC0]
00007dd052fd4248  vmovaps xmm14, [rsp+0xD0]
00007dd052fd4251  vmovaps xmm15, [rsp+0xE0]
00007dd052fd425a  add rsp, 0xF0
00007dd052fd4261  pop r11
00007dd052fd4263  pop r10
00007dd052fd4265  pop r9
00007dd052fd4267  pop r8
00007dd052fd4269  pop rsi
00007dd052fd426a  pop rdi
00007dd052fd426b  pop rdx
00007dd052fd426c  pop rcx
00007dd052fd426d  pop rax
00007dd052fd426e  add rsp, 0x08
00007dd052fd4272  jmp 0x00007DD052FD2962
00007dd052fd4277  sub rsp, 0x08
00007dd052fd427b  push rax
00007dd052fd427c  push rcx
00007dd052fd427d  push rdx
00007dd052fd427e  push rdi
00007dd052fd427f  push rsi
00007dd052fd4280  push r8
00007dd052fd4282  push r9
00007dd052fd4284  push r10
00007dd052fd4286  push r11
00007dd052fd4288  sub rsp, 0xF0
00007dd052fd428f  vmovaps [rsp], xmm0
00007dd052fd4294  vmovaps [rsp+0x10], xmm1
00007dd052fd429a  vmovaps [rsp+0x20], xmm2
00007dd052fd42a0  vmovaps [rsp+0x30], xmm3
00007dd052fd42a6  vmovaps [rsp+0x40], xmm4
00007dd052fd42ac  vmovaps [rsp+0x50], xmm5
00007dd052fd42b2  vmovaps [rsp+0x60], xmm6
00007dd052fd42b8  vmovaps [rsp+0x70], xmm7
00007dd052fd42be  vmovaps [rsp+0x80], xmm8
00007dd052fd42c7  vmovaps [rsp+0x90], xmm9
00007dd052fd42d0  vmovaps [rsp+0xA0], xmm10
00007dd052fd42d9  vmovaps [rsp+0xB0], xmm11
00007dd052fd42e2  vmovaps [rsp+0xC0], xmm12
00007dd052fd42eb  vmovaps [rsp+0xD0], xmm13
00007dd052fd42f4  vmovaps [rsp+0xE0], xmm15
00007dd052fd42fd  sub rsp, 0x30
00007dd052fd4301  movaps [rsp], xmm14
00007dd052fd4306  movaps [rsp+0x10], xmm10
00007dd052fd430c  movaps [rsp+0x20], xmm15
00007dd052fd4312  lea rdi, [rsp]
00007dd052fd4316  mov esi, 0x00
00007dd052fd431b  mov rax, 0x61D0404B9530
00007dd052fd4325  call rax
00007dd052fd4327  movaps xmm14, [rsp]
00007dd052fd432c  add rsp, 0x30
00007dd052fd4330  vmovaps xmm0, [rsp]
00007dd052fd4335  vmovaps xmm1, [rsp+0x10]
00007dd052fd433b  vmovaps xmm2, [rsp+0x20]
00007dd052fd4341  vmovaps xmm3, [rsp+0x30]
00007dd052fd4347  vmovaps xmm4, [rsp+0x40]
00007dd052fd434d  vmovaps xmm5, [rsp+0x50]
00007dd052fd4353  vmovaps xmm6, [rsp+0x60]
00007dd052fd4359  vmovaps xmm7, [rsp+0x70]
00007dd052fd435f  vmovaps xmm8, [rsp+0x80]
00007dd052fd4368  vmovaps xmm9, [rsp+0x90]
00007dd052fd4371  vmovaps xmm10, [rsp+0xA0]
00007dd052fd437a  vmovaps xmm11, [rsp+0xB0]
00007dd052fd4383  vmovaps xmm12, [rsp+0xC0]
00007dd052fd438c  vmovaps xmm13, [rsp+0xD0]
00007dd052fd4395  vmovaps xmm15, [rsp+0xE0]
00007dd052fd439e  add rsp, 0xF0
00007dd052fd43a5  pop r11
00007dd052fd43a7  pop r10
00007dd052fd43a9  pop r9
00007dd052fd43ab  pop r8
00007dd052fd43ad  pop rsi
00007dd052fd43ae  pop rdi
00007dd052fd43af  pop rdx
00007dd052fd43b0  pop rcx
00007dd052fd43b1  pop rax
00007dd052fd43b2  add rsp, 0x08
00007dd052fd43b6  jmp 0x00007DD052FD298E
00007dd052fd43bb  call 0x00007DD052DFF430
00007dd052fd43c0  jmp 0x00007DD052FD2A1E
00007dd052fd43c5  call 0x00007DD052DFF430
00007dd052fd43ca  jmp 0x00007DD052FD2A31
00007dd052fd43cf  sub rsp, 0x08
00007dd052fd43d3  push rax
00007dd052fd43d4  push rcx
00007dd052fd43d5  push rdx
00007dd052fd43d6  push rdi
00007dd052fd43d7  push rsi
00007dd052fd43d8  push r8
00007dd052fd43da  push r9
00007dd052fd43dc  push r10
00007dd052fd43de  push r11
00007dd052fd43e0  sub rsp, 0xF0
00007dd052fd43e7  vmovaps [rsp], xmm0
00007dd052fd43ec  vmovaps [rsp+0x10], xmm2
00007dd052fd43f2  vmovaps [rsp+0x20], xmm3
00007dd052fd43f8  vmovaps [rsp+0x30], xmm4
00007dd052fd43fe  vmovaps [rsp+0x40], xmm5
00007dd052fd4404  vmovaps [rsp+0x50], xmm6
00007dd052fd440a  vmovaps [rsp+0x60], xmm7
00007dd052fd4410  vmovaps [rsp+0x70], xmm8
00007dd052fd4416  vmovaps [rsp+0x80], xmm9
00007dd052fd441f  vmovaps [rsp+0x90], xmm10
00007dd052fd4428  vmovaps [rsp+0xA0], xmm11
00007dd052fd4431  vmovaps [rsp+0xB0], xmm12
00007dd052fd443a  vmovaps [rsp+0xC0], xmm13
00007dd052fd4443  vmovaps [rsp+0xD0], xmm14
00007dd052fd444c  vmovaps [rsp+0xE0], xmm15
00007dd052fd4455  sub rsp, 0x30
00007dd052fd4459  movaps [rsp], xmm1
00007dd052fd445d  movaps [rsp+0x10], xmm13
00007dd052fd4463  movaps [rsp+0x20], xmm2
00007dd052fd4468  lea rdi, [rsp]
00007dd052fd446c  mov esi, 0x00
00007dd052fd4471  mov rax, 0x61D0404B9530
00007dd052fd447b  call rax
00007dd052fd447d  movaps xmm1, [rsp]
00007dd052fd4481  add rsp, 0x30
00007dd052fd4485  vmovaps xmm0, [rsp]
00007dd052fd448a  vmovaps xmm2, [rsp+0x10]
00007dd052fd4490  vmovaps xmm3, [rsp+0x20]
00007dd052fd4496  vmovaps xmm4, [rsp+0x30]
00007dd052fd449c  vmovaps xmm5, [rsp+0x40]
00007dd052fd44a2  vmovaps xmm6, [rsp+0x50]
00007dd052fd44a8  vmovaps xmm7, [rsp+0x60]
00007dd052fd44ae  vmovaps xmm8, [rsp+0x70]
00007dd052fd44b4  vmovaps xmm9, [rsp+0x80]
00007dd052fd44bd  vmovaps xmm10, [rsp+0x90]
00007dd052fd44c6  vmovaps xmm11, [rsp+0xA0]
00007dd052fd44cf  vmovaps xmm12, [rsp+0xB0]
00007dd052fd44d8  vmovaps xmm13, [rsp+0xC0]
00007dd052fd44e1  vmovaps xmm14, [rsp+0xD0]
00007dd052fd44ea  vmovaps xmm15, [rsp+0xE0]
00007dd052fd44f3  add rsp, 0xF0
00007dd052fd44fa  pop r11
00007dd052fd44fc  pop r10
00007dd052fd44fe  pop r9
00007dd052fd4500  pop r8
00007dd052fd4502  pop rsi
00007dd052fd4503  pop rdi
00007dd052fd4504  pop rdx
00007dd052fd4505  pop rcx
00007dd052fd4506  pop rax
00007dd052fd4507  add rsp, 0x08
00007dd052fd450b  jmp 0x00007DD052FD2A5C
00007dd052fd4510  call 0x00007DD052E0E760
00007dd052fd4515  jmp 0x00007DD052FD2A69
00007dd052fd451a  sub rsp, 0x08
00007dd052fd451e  push rax
00007dd052fd451f  push rcx
00007dd052fd4520  push rdx
00007dd052fd4521  push rdi
00007dd052fd4522  push rsi
00007dd052fd4523  push r8
00007dd052fd4525  push r9
00007dd052fd4527  push r10
00007dd052fd4529  push r11
00007dd052fd452b  sub rsp, 0xF0
00007dd052fd4532  vmovaps [rsp], xmm0
00007dd052fd4537  vmovaps [rsp+0x10], xmm1
00007dd052fd453d  vmovaps [rsp+0x20], xmm2
00007dd052fd4543  vmovaps [rsp+0x30], xmm3
00007dd052fd4549  vmovaps [rsp+0x40], xmm4
00007dd052fd454f  vmovaps [rsp+0x50], xmm5
00007dd052fd4555  vmovaps [rsp+0x60], xmm6
00007dd052fd455b  vmovaps [rsp+0x70], xmm7
00007dd052fd4561  vmovaps [rsp+0x80], xmm8
00007dd052fd456a  vmovaps [rsp+0x90], xmm9
00007dd052fd4573  vmovaps [rsp+0xA0], xmm10
00007dd052fd457c  vmovaps [rsp+0xB0], xmm11
00007dd052fd4585  vmovaps [rsp+0xC0], xmm12
00007dd052fd458e  vmovaps [rsp+0xD0], xmm14
00007dd052fd4597  vmovaps [rsp+0xE0], xmm15
00007dd052fd45a0  sub rsp, 0x30
00007dd052fd45a4  movaps [rsp], xmm13
00007dd052fd45a9  movaps [rsp+0x10], xmm2
00007dd052fd45ae  movaps [rsp+0x20], xmm1
00007dd052fd45b3  lea rdi, [rsp]
00007dd052fd45b7  mov esi, 0x00
00007dd052fd45bc  mov rax, 0x61D0404B9530
00007dd052fd45c6  call rax
00007dd052fd45c8  movaps xmm13, [rsp]
00007dd052fd45cd  add rsp, 0x30
00007dd052fd45d1  vmovaps xmm0, [rsp]
00007dd052fd45d6  vmovaps xmm1, [rsp+0x10]
00007dd052fd45dc  vmovaps xmm2, [rsp+0x20]
00007dd052fd45e2  vmovaps xmm3, [rsp+0x30]
00007dd052fd45e8  vmovaps xmm4, [rsp+0x40]
00007dd052fd45ee  vmovaps xmm5, [rsp+0x50]
00007dd052fd45f4  vmovaps xmm6, [rsp+0x60]
00007dd052fd45fa  vmovaps xmm7, [rsp+0x70]
00007dd052fd4600  vmovaps xmm8, [rsp+0x80]
00007dd052fd4609  vmovaps xmm9, [rsp+0x90]
00007dd052fd4612  vmovaps xmm10, [rsp+0xA0]
00007dd052fd461b  vmovaps xmm11, [rsp+0xB0]
00007dd052fd4624  vmovaps xmm12, [rsp+0xC0]
00007dd052fd462d  vmovaps xmm14, [rsp+0xD0]
00007dd052fd4636  vmovaps xmm15, [rsp+0xE0]
00007dd052fd463f  add rsp, 0xF0
00007dd052fd4646  pop r11
00007dd052fd4648  pop r10
00007dd052fd464a  pop r9
00007dd052fd464c  pop r8
00007dd052fd464e  pop rsi
00007dd052fd464f  pop rdi
00007dd052fd4650  pop rdx
00007dd052fd4651  pop rcx
00007dd052fd4652  pop rax
00007dd052fd4653  add rsp, 0x08
00007dd052fd4657  jmp 0x00007DD052FD2AA8
00007dd052fd465c  sub rsp, 0x08
00007dd052fd4660  push rax
00007dd052fd4661  push rcx
00007dd052fd4662  push rdx
00007dd052fd4663  push rdi
00007dd052fd4664  push rsi
00007dd052fd4665  push r8
00007dd052fd4667  push r9
00007dd052fd4669  push r10
00007dd052fd466b  push r11
00007dd052fd466d  sub rsp, 0xF0
00007dd052fd4674  vmovaps [rsp], xmm0
00007dd052fd4679  vmovaps [rsp+0x10], xmm2
00007dd052fd467f  vmovaps [rsp+0x20], xmm3
00007dd052fd4685  vmovaps [rsp+0x30], xmm4
00007dd052fd468b  vmovaps [rsp+0x40], xmm5
00007dd052fd4691  vmovaps [rsp+0x50], xmm6
00007dd052fd4697  vmovaps [rsp+0x60], xmm7
00007dd052fd469d  vmovaps [rsp+0x70], xmm8
00007dd052fd46a3  vmovaps [rsp+0x80], xmm9
00007dd052fd46ac  vmovaps [rsp+0x90], xmm10
00007dd052fd46b5  vmovaps [rsp+0xA0], xmm11
00007dd052fd46be  vmovaps [rsp+0xB0], xmm12
00007dd052fd46c7  vmovaps [rsp+0xC0], xmm13
00007dd052fd46d0  vmovaps [rsp+0xD0], xmm14
00007dd052fd46d9  vmovaps [rsp+0xE0], xmm15
00007dd052fd46e2  sub rsp, 0x30
00007dd052fd46e6  movaps [rsp], xmm1
00007dd052fd46ea  movaps [rsp+0x10], xmm14
00007dd052fd46f0  movaps [rsp+0x20], xmm15
00007dd052fd46f6  lea rdi, [rsp]
00007dd052fd46fa  mov esi, 0x00
00007dd052fd46ff  mov rax, 0x61D0404B9530
00007dd052fd4709  call rax
00007dd052fd470b  movaps xmm1, [rsp]
00007dd052fd470f  add rsp, 0x30
00007dd052fd4713  vmovaps xmm0, [rsp]
00007dd052fd4718  vmovaps xmm2, [rsp+0x10]
00007dd052fd471e  vmovaps xmm3, [rsp+0x20]
00007dd052fd4724  vmovaps xmm4, [rsp+0x30]
00007dd052fd472a  vmovaps xmm5, [rsp+0x40]
00007dd052fd4730  vmovaps xmm6, [rsp+0x50]
00007dd052fd4736  vmovaps xmm7, [rsp+0x60]
00007dd052fd473c  vmovaps xmm8, [rsp+0x70]
00007dd052fd4742  vmovaps xmm9, [rsp+0x80]
00007dd052fd474b  vmovaps xmm10, [rsp+0x90]
00007dd052fd4754  vmovaps xmm11, [rsp+0xA0]
00007dd052fd475d  vmovaps xmm12, [rsp+0xB0]
00007dd052fd4766  vmovaps xmm13, [rsp+0xC0]
00007dd052fd476f  vmovaps xmm14, [rsp+0xD0]
00007dd052fd4778  vmovaps xmm15, [rsp+0xE0]
00007dd052fd4781  add rsp, 0xF0
00007dd052fd4788  pop r11
00007dd052fd478a  pop r10
00007dd052fd478c  pop r9
00007dd052fd478e  pop r8
00007dd052fd4790  pop rsi
00007dd052fd4791  pop rdi
00007dd052fd4792  pop rdx
00007dd052fd4793  pop rcx
00007dd052fd4794  pop rax
00007dd052fd4795  add rsp, 0x08
00007dd052fd4799  jmp 0x00007DD052FD2ACA
00007dd052fd479e  sub rsp, 0x08
00007dd052fd47a2  push rax
00007dd052fd47a3  push rcx
00007dd052fd47a4  push rdx
00007dd052fd47a5  push rdi
00007dd052fd47a6  push rsi
00007dd052fd47a7  push r8
00007dd052fd47a9  push r9
00007dd052fd47ab  push r10
00007dd052fd47ad  push r11
00007dd052fd47af  sub rsp, 0xF0
00007dd052fd47b6  vmovaps [rsp], xmm0
00007dd052fd47bb  vmovaps [rsp+0x10], xmm1
00007dd052fd47c1  vmovaps [rsp+0x20], xmm2
00007dd052fd47c7  vmovaps [rsp+0x30], xmm3
00007dd052fd47cd  vmovaps [rsp+0x40], xmm4
00007dd052fd47d3  vmovaps [rsp+0x50], xmm5
00007dd052fd47d9  vmovaps [rsp+0x60], xmm6
00007dd052fd47df  vmovaps [rsp+0x70], xmm7
00007dd052fd47e5  vmovaps [rsp+0x80], xmm8
00007dd052fd47ee  vmovaps [rsp+0x90], xmm9
00007dd052fd47f7  vmovaps [rsp+0xA0], xmm10
00007dd052fd4800  vmovaps [rsp+0xB0], xmm11
00007dd052fd4809  vmovaps [rsp+0xC0], xmm12
00007dd052fd4812  vmovaps [rsp+0xD0], xmm13
00007dd052fd481b  vmovaps [rsp+0xE0], xmm15
00007dd052fd4824  sub rsp, 0x30
00007dd052fd4828  movaps [rsp], xmm14
00007dd052fd482d  movaps [rsp+0x10], xmm2
00007dd052fd4832  movaps [rsp+0x20], xmm15
00007dd052fd4838  lea rdi, [rsp]
00007dd052fd483c  mov esi, 0x00
00007dd052fd4841  mov rax, 0x61D0404B9530
00007dd052fd484b  call rax
00007dd052fd484d  movaps xmm14, [rsp]
00007dd052fd4852  add rsp, 0x30
00007dd052fd4856  vmovaps xmm0, [rsp]
00007dd052fd485b  vmovaps xmm1, [rsp+0x10]
00007dd052fd4861  vmovaps xmm2, [rsp+0x20]
00007dd052fd4867  vmovaps xmm3, [rsp+0x30]
00007dd052fd486d  vmovaps xmm4, [rsp+0x40]
00007dd052fd4873  vmovaps xmm5, [rsp+0x50]
00007dd052fd4879  vmovaps xmm6, [rsp+0x60]
00007dd052fd487f  vmovaps xmm7, [rsp+0x70]
00007dd052fd4885  vmovaps xmm8, [rsp+0x80]
00007dd052fd488e  vmovaps xmm9, [rsp+0x90]
00007dd052fd4897  vmovaps xmm10, [rsp+0xA0]
00007dd052fd48a0  vmovaps xmm11, [rsp+0xB0]
00007dd052fd48a9  vmovaps xmm12, [rsp+0xC0]
00007dd052fd48b2  vmovaps xmm13, [rsp+0xD0]
00007dd052fd48bb  vmovaps xmm15, [rsp+0xE0]
00007dd052fd48c4  add rsp, 0xF0
00007dd052fd48cb  pop r11
00007dd052fd48cd  pop r10
00007dd052fd48cf  pop r9
00007dd052fd48d1  pop r8
00007dd052fd48d3  pop rsi
00007dd052fd48d4  pop rdi
00007dd052fd48d5  pop rdx
00007dd052fd48d6  pop rcx
00007dd052fd48d7  pop rax
00007dd052fd48d8  add rsp, 0x08
00007dd052fd48dc  jmp 0x00007DD052FD2B05
00007dd052fd48e1  sub rsp, 0x08
00007dd052fd48e5  push rax
00007dd052fd48e6  push rcx
00007dd052fd48e7  push rdx
00007dd052fd48e8  push rdi
00007dd052fd48e9  push rsi
00007dd052fd48ea  push r8
00007dd052fd48ec  push r9
00007dd052fd48ee  push r10
00007dd052fd48f0  push r11
00007dd052fd48f2  sub rsp, 0xF0
00007dd052fd48f9  vmovaps [rsp], xmm0
00007dd052fd48fe  vmovaps [rsp+0x10], xmm1
00007dd052fd4904  vmovaps [rsp+0x20], xmm2
00007dd052fd490a  vmovaps [rsp+0x30], xmm3
00007dd052fd4910  vmovaps [rsp+0x40], xmm4
00007dd052fd4916  vmovaps [rsp+0x50], xmm5
00007dd052fd491c  vmovaps [rsp+0x60], xmm6
00007dd052fd4922  vmovaps [rsp+0x70], xmm7
00007dd052fd4928  vmovaps [rsp+0x80], xmm8
00007dd052fd4931  vmovaps [rsp+0x90], xmm9
00007dd052fd493a  vmovaps [rsp+0xA0], xmm10
00007dd052fd4943  vmovaps [rsp+0xB0], xmm11
00007dd052fd494c  vmovaps [rsp+0xC0], xmm12
00007dd052fd4955  vmovaps [rsp+0xD0], xmm13
00007dd052fd495e  vmovaps [rsp+0xE0], xmm14
00007dd052fd4967  sub rsp, 0x30
00007dd052fd496b  movaps [rsp], xmm15
00007dd052fd4970  movaps [rsp+0x10], xmm2
00007dd052fd4975  movaps [rsp+0x20], xmm1
00007dd052fd497a  lea rdi, [rsp]
00007dd052fd497e  mov esi, 0x00
00007dd052fd4983  mov rax, 0x61D0404B9530
00007dd052fd498d  call rax
00007dd052fd498f  movaps xmm15, [rsp]
00007dd052fd4994  add rsp, 0x30
00007dd052fd4998  vmovaps xmm0, [rsp]
00007dd052fd499d  vmovaps xmm1, [rsp+0x10]
00007dd052fd49a3  vmovaps xmm2, [rsp+0x20]
00007dd052fd49a9  vmovaps xmm3, [rsp+0x30]
00007dd052fd49af  vmovaps xmm4, [rsp+0x40]
00007dd052fd49b5  vmovaps xmm5, [rsp+0x50]
00007dd052fd49bb  vmovaps xmm6, [rsp+0x60]
00007dd052fd49c1  vmovaps xmm7, [rsp+0x70]
00007dd052fd49c7  vmovaps xmm8, [rsp+0x80]
00007dd052fd49d0  vmovaps xmm9, [rsp+0x90]
00007dd052fd49d9  vmovaps xmm10, [rsp+0xA0]
00007dd052fd49e2  vmovaps xmm11, [rsp+0xB0]
00007dd052fd49eb  vmovaps xmm12, [rsp+0xC0]
00007dd052fd49f4  vmovaps xmm13, [rsp+0xD0]
00007dd052fd49fd  vmovaps xmm14, [rsp+0xE0]
00007dd052fd4a06  add rsp, 0xF0
00007dd052fd4a0d  pop r11
00007dd052fd4a0f  pop r10
00007dd052fd4a11  pop r9
00007dd052fd4a13  pop r8
00007dd052fd4a15  pop rsi
00007dd052fd4a16  pop rdi
00007dd052fd4a17  pop rdx
00007dd052fd4a18  pop rcx
00007dd052fd4a19  pop rax
00007dd052fd4a1a  add rsp, 0x08
00007dd052fd4a1e  jmp 0x00007DD052FD2B41
00007dd052fd4a23  call 0x00007DD052DFF430
00007dd052fd4a28  jmp 0x00007DD052FD2B4E
00007dd052fd4a2d  sub rsp, 0x08
00007dd052fd4a31  push rax
00007dd052fd4a32  push rcx
00007dd052fd4a33  push rdx
00007dd052fd4a34  push rdi
00007dd052fd4a35  push rsi
00007dd052fd4a36  push r8
00007dd052fd4a38  push r9
00007dd052fd4a3a  push r10
00007dd052fd4a3c  push r11
00007dd052fd4a3e  sub rsp, 0xF0
00007dd052fd4a45  vmovaps [rsp], xmm0
00007dd052fd4a4a  vmovaps [rsp+0x10], xmm1
00007dd052fd4a50  vmovaps [rsp+0x20], xmm3
00007dd052fd4a56  vmovaps [rsp+0x30], xmm4
00007dd052fd4a5c  vmovaps [rsp+0x40], xmm5
00007dd052fd4a62  vmovaps [rsp+0x50], xmm6
00007dd052fd4a68  vmovaps [rsp+0x60], xmm7
00007dd052fd4a6e  vmovaps [rsp+0x70], xmm8
00007dd052fd4a74  vmovaps [rsp+0x80], xmm9
00007dd052fd4a7d  vmovaps [rsp+0x90], xmm10
00007dd052fd4a86  vmovaps [rsp+0xA0], xmm11
00007dd052fd4a8f  vmovaps [rsp+0xB0], xmm12
00007dd052fd4a98  vmovaps [rsp+0xC0], xmm13
00007dd052fd4aa1  vmovaps [rsp+0xD0], xmm14
00007dd052fd4aaa  vmovaps [rsp+0xE0], xmm15
00007dd052fd4ab3  sub rsp, 0x30
00007dd052fd4ab7  movaps [rsp], xmm2
00007dd052fd4abb  movaps [rsp+0x10], xmm1
00007dd052fd4ac0  movaps [rsp+0x20], xmm14
00007dd052fd4ac6  lea rdi, [rsp]
00007dd052fd4aca  mov esi, 0x00
00007dd052fd4acf  mov rax, 0x61D0404B9530
00007dd052fd4ad9  call rax
00007dd052fd4adb  movaps xmm2, [rsp]
00007dd052fd4adf  add rsp, 0x30
00007dd052fd4ae3  vmovaps xmm0, [rsp]
00007dd052fd4ae8  vmovaps xmm1, [rsp+0x10]
00007dd052fd4aee  vmovaps xmm3, [rsp+0x20]
00007dd052fd4af4  vmovaps xmm4, [rsp+0x30]
00007dd052fd4afa  vmovaps xmm5, [rsp+0x40]
00007dd052fd4b00  vmovaps xmm6, [rsp+0x50]
00007dd052fd4b06  vmovaps xmm7, [rsp+0x60]
00007dd052fd4b0c  vmovaps xmm8, [rsp+0x70]
00007dd052fd4b12  vmovaps xmm9, [rsp+0x80]
00007dd052fd4b1b  vmovaps xmm10, [rsp+0x90]
00007dd052fd4b24  vmovaps xmm11, [rsp+0xA0]
00007dd052fd4b2d  vmovaps xmm12, [rsp+0xB0]
00007dd052fd4b36  vmovaps xmm13, [rsp+0xC0]
00007dd052fd4b3f  vmovaps xmm14, [rsp+0xD0]
00007dd052fd4b48  vmovaps xmm15, [rsp+0xE0]
00007dd052fd4b51  add rsp, 0xF0
00007dd052fd4b58  pop r11
00007dd052fd4b5a  pop r10
00007dd052fd4b5c  pop r9
00007dd052fd4b5e  pop r8
00007dd052fd4b60  pop rsi
00007dd052fd4b61  pop rdi
00007dd052fd4b62  pop rdx
00007dd052fd4b63  pop rcx
00007dd052fd4b64  pop rax
00007dd052fd4b65  add rsp, 0x08
00007dd052fd4b69  jmp 0x00007DD052FD2B8B
00007dd052fd4b6e  sub rsp, 0x08
00007dd052fd4b72  push rax
00007dd052fd4b73  push rcx
00007dd052fd4b74  push rdx
00007dd052fd4b75  push rdi
00007dd052fd4b76  push rsi
00007dd052fd4b77  push r8
00007dd052fd4b79  push r9
00007dd052fd4b7b  push r10
00007dd052fd4b7d  push r11
00007dd052fd4b7f  sub rsp, 0xF0
00007dd052fd4b86  vmovaps [rsp], xmm0
00007dd052fd4b8b  vmovaps [rsp+0x10], xmm1
00007dd052fd4b91  vmovaps [rsp+0x20], xmm2
00007dd052fd4b97  vmovaps [rsp+0x30], xmm3
00007dd052fd4b9d  vmovaps [rsp+0x40], xmm4
00007dd052fd4ba3  vmovaps [rsp+0x50], xmm5
00007dd052fd4ba9  vmovaps [rsp+0x60], xmm6
00007dd052fd4baf  vmovaps [rsp+0x70], xmm7
00007dd052fd4bb5  vmovaps [rsp+0x80], xmm8
00007dd052fd4bbe  vmovaps [rsp+0x90], xmm9
00007dd052fd4bc7  vmovaps [rsp+0xA0], xmm10
00007dd052fd4bd0  vmovaps [rsp+0xB0], xmm11
00007dd052fd4bd9  vmovaps [rsp+0xC0], xmm12
00007dd052fd4be2  vmovaps [rsp+0xD0], xmm13
00007dd052fd4beb  vmovaps [rsp+0xE0], xmm14
00007dd052fd4bf4  sub rsp, 0x30
00007dd052fd4bf8  movaps [rsp], xmm15
00007dd052fd4bfd  movaps [rsp+0x10], xmm14
00007dd052fd4c03  movaps [rsp+0x20], xmm1
00007dd052fd4c08  lea rdi, [rsp]
00007dd052fd4c0c  mov esi, 0x00
00007dd052fd4c11  mov rax, 0x61D0404B9530
00007dd052fd4c1b  call rax
00007dd052fd4c1d  movaps xmm15, [rsp]
00007dd052fd4c22  add rsp, 0x30
00007dd052fd4c26  vmovaps xmm0, [rsp]
00007dd052fd4c2b  vmovaps xmm1, [rsp+0x10]
00007dd052fd4c31  vmovaps xmm2, [rsp+0x20]
00007dd052fd4c37  vmovaps xmm3, [rsp+0x30]
00007dd052fd4c3d  vmovaps xmm4, [rsp+0x40]
00007dd052fd4c43  vmovaps xmm5, [rsp+0x50]
00007dd052fd4c49  vmovaps xmm6, [rsp+0x60]
00007dd052fd4c4f  vmovaps xmm7, [rsp+0x70]
00007dd052fd4c55  vmovaps xmm8, [rsp+0x80]
00007dd052fd4c5e  vmovaps xmm9, [rsp+0x90]
00007dd052fd4c67  vmovaps xmm10, [rsp+0xA0]
00007dd052fd4c70  vmovaps xmm11, [rsp+0xB0]
00007dd052fd4c79  vmovaps xmm12, [rsp+0xC0]
00007dd052fd4c82  vmovaps xmm13, [rsp+0xD0]
00007dd052fd4c8b  vmovaps xmm14, [rsp+0xE0]
00007dd052fd4c94  add rsp, 0xF0
00007dd052fd4c9b  pop r11
00007dd052fd4c9d  pop r10
00007dd052fd4c9f  pop r9
00007dd052fd4ca1  pop r8
00007dd052fd4ca3  pop rsi
00007dd052fd4ca4  pop rdi
00007dd052fd4ca5  pop rdx
00007dd052fd4ca6  pop rcx
00007dd052fd4ca7  pop rax
00007dd052fd4ca8  add rsp, 0x08
00007dd052fd4cac  jmp 0x00007DD052FD2C05
00007dd052fd4cb1  call 0x00007DD052DFF430
00007dd052fd4cb6  jmp 0x00007DD052FD2C12
00007dd052fd4cbb  sub rsp, 0x08
00007dd052fd4cbf  push rax
00007dd052fd4cc0  push rcx
00007dd052fd4cc1  push rdx
00007dd052fd4cc2  push rdi
00007dd052fd4cc3  push rsi
00007dd052fd4cc4  push r8
00007dd052fd4cc6  push r9
00007dd052fd4cc8  push r10
00007dd052fd4cca  push r11
00007dd052fd4ccc  sub rsp, 0xF0
00007dd052fd4cd3  vmovaps [rsp], xmm0
00007dd052fd4cd8  vmovaps [rsp+0x10], xmm1
00007dd052fd4cde  vmovaps [rsp+0x20], xmm2
00007dd052fd4ce4  vmovaps [rsp+0x30], xmm3
00007dd052fd4cea  vmovaps [rsp+0x40], xmm4
00007dd052fd4cf0  vmovaps [rsp+0x50], xmm5
00007dd052fd4cf6  vmovaps [rsp+0x60], xmm6
00007dd052fd4cfc  vmovaps [rsp+0x70], xmm7
00007dd052fd4d02  vmovaps [rsp+0x80], xmm8
00007dd052fd4d0b  vmovaps [rsp+0x90], xmm9
00007dd052fd4d14  vmovaps [rsp+0xA0], xmm10
00007dd052fd4d1d  vmovaps [rsp+0xB0], xmm11
00007dd052fd4d26  vmovaps [rsp+0xC0], xmm12
00007dd052fd4d2f  vmovaps [rsp+0xD0], xmm14
00007dd052fd4d38  vmovaps [rsp+0xE0], xmm15
00007dd052fd4d41  sub rsp, 0x30
00007dd052fd4d45  movaps [rsp], xmm13
00007dd052fd4d4a  movaps [rsp+0x10], xmm1
00007dd052fd4d4f  movaps [rsp+0x20], xmm15
00007dd052fd4d55  lea rdi, [rsp]
00007dd052fd4d59  mov esi, 0x00
00007dd052fd4d5e  mov rax, 0x61D0404B9530
00007dd052fd4d68  call rax
00007dd052fd4d6a  movaps xmm13, [rsp]
00007dd052fd4d6f  add rsp, 0x30
00007dd052fd4d73  vmovaps xmm0, [rsp]
00007dd052fd4d78  vmovaps xmm1, [rsp+0x10]
00007dd052fd4d7e  vmovaps xmm2, [rsp+0x20]
00007dd052fd4d84  vmovaps xmm3, [rsp+0x30]
00007dd052fd4d8a  vmovaps xmm4, [rsp+0x40]
00007dd052fd4d90  vmovaps xmm5, [rsp+0x50]
00007dd052fd4d96  vmovaps xmm6, [rsp+0x60]
00007dd052fd4d9c  vmovaps xmm7, [rsp+0x70]
00007dd052fd4da2  vmovaps xmm8, [rsp+0x80]
00007dd052fd4dab  vmovaps xmm9, [rsp+0x90]
00007dd052fd4db4  vmovaps xmm10, [rsp+0xA0]
00007dd052fd4dbd  vmovaps xmm11, [rsp+0xB0]
00007dd052fd4dc6  vmovaps xmm12, [rsp+0xC0]
00007dd052fd4dcf  vmovaps xmm14, [rsp+0xD0]
00007dd052fd4dd8  vmovaps xmm15, [rsp+0xE0]
00007dd052fd4de1  add rsp, 0xF0
00007dd052fd4de8  pop r11
00007dd052fd4dea  pop r10
00007dd052fd4dec  pop r9
00007dd052fd4dee  pop r8
00007dd052fd4df0  pop rsi
00007dd052fd4df1  pop rdi
00007dd052fd4df2  pop rdx
00007dd052fd4df3  pop rcx
00007dd052fd4df4  pop rax
00007dd052fd4df5  add rsp, 0x08
00007dd052fd4df9  jmp 0x00007DD052FD2CD6
00007dd052fd4dfe  sub rsp, 0x08
00007dd052fd4e02  push rax
00007dd052fd4e03  push rcx
00007dd052fd4e04  push rdx
00007dd052fd4e05  push rdi
00007dd052fd4e06  push rsi
00007dd052fd4e07  push r8
00007dd052fd4e09  push r9
00007dd052fd4e0b  push r10
00007dd052fd4e0d  push r11
00007dd052fd4e0f  sub rsp, 0xF0
00007dd052fd4e16  vmovaps [rsp], xmm0
00007dd052fd4e1b  vmovaps [rsp+0x10], xmm1
00007dd052fd4e21  vmovaps [rsp+0x20], xmm2
00007dd052fd4e27  vmovaps [rsp+0x30], xmm3
00007dd052fd4e2d  vmovaps [rsp+0x40], xmm4
00007dd052fd4e33  vmovaps [rsp+0x50], xmm5
00007dd052fd4e39  vmovaps [rsp+0x60], xmm6
00007dd052fd4e3f  vmovaps [rsp+0x70], xmm7
00007dd052fd4e45  vmovaps [rsp+0x80], xmm8
00007dd052fd4e4e  vmovaps [rsp+0x90], xmm9
00007dd052fd4e57  vmovaps [rsp+0xA0], xmm10
00007dd052fd4e60  vmovaps [rsp+0xB0], xmm11
00007dd052fd4e69  vmovaps [rsp+0xC0], xmm12
00007dd052fd4e72  vmovaps [rsp+0xD0], xmm13
00007dd052fd4e7b  vmovaps [rsp+0xE0], xmm14
00007dd052fd4e84  sub rsp, 0x30
00007dd052fd4e88  movaps [rsp], xmm15
00007dd052fd4e8d  movaps [rsp+0x10], xmm14
00007dd052fd4e93  movaps [rsp+0x20], xmm1
00007dd052fd4e98  lea rdi, [rsp]
00007dd052fd4e9c  mov esi, 0x00
00007dd052fd4ea1  mov rax, 0x61D0404B9530
00007dd052fd4eab  call rax
00007dd052fd4ead  movaps xmm15, [rsp]
00007dd052fd4eb2  add rsp, 0x30
00007dd052fd4eb6  vmovaps xmm0, [rsp]
00007dd052fd4ebb  vmovaps xmm1, [rsp+0x10]
00007dd052fd4ec1  vmovaps xmm2, [rsp+0x20]
00007dd052fd4ec7  vmovaps xmm3, [rsp+0x30]
00007dd052fd4ecd  vmovaps xmm4, [rsp+0x40]
00007dd052fd4ed3  vmovaps xmm5, [rsp+0x50]
00007dd052fd4ed9  vmovaps xmm6, [rsp+0x60]
00007dd052fd4edf  vmovaps xmm7, [rsp+0x70]
00007dd052fd4ee5  vmovaps xmm8, [rsp+0x80]
00007dd052fd4eee  vmovaps xmm9, [rsp+0x90]
00007dd052fd4ef7  vmovaps xmm10, [rsp+0xA0]
00007dd052fd4f00  vmovaps xmm11, [rsp+0xB0]
00007dd052fd4f09  vmovaps xmm12, [rsp+0xC0]
00007dd052fd4f12  vmovaps xmm13, [rsp+0xD0]
00007dd052fd4f1b  vmovaps xmm14, [rsp+0xE0]
00007dd052fd4f24  add rsp, 0xF0
00007dd052fd4f2b  pop r11
00007dd052fd4f2d  pop r10
00007dd052fd4f2f  pop r9
00007dd052fd4f31  pop r8
00007dd052fd4f33  pop rsi
00007dd052fd4f34  pop rdi
00007dd052fd4f35  pop rdx
00007dd052fd4f36  pop rcx
00007dd052fd4f37  pop rax
00007dd052fd4f38  add rsp, 0x08
00007dd052fd4f3c  jmp 0x00007DD052FD2D12
00007dd052fd4f41  call 0x00007DD052DFF430
00007dd052fd4f46  jmp 0x00007DD052FD2D1F
00007dd052fd4f4b  sub rsp, 0x08
00007dd052fd4f4f  push rax
00007dd052fd4f50  push rcx
00007dd052fd4f51  push rdx
00007dd052fd4f52  push rdi
00007dd052fd4f53  push rsi
00007dd052fd4f54  push r8
00007dd052fd4f56  push r9
00007dd052fd4f58  push r10
00007dd052fd4f5a  push r11
00007dd052fd4f5c  sub rsp, 0xF0
00007dd052fd4f63  vmovaps [rsp], xmm0
00007dd052fd4f68  vmovaps [rsp+0x10], xmm1
00007dd052fd4f6e  vmovaps [rsp+0x20], xmm2
00007dd052fd4f74  vmovaps [rsp+0x30], xmm3
00007dd052fd4f7a  vmovaps [rsp+0x40], xmm4
00007dd052fd4f80  vmovaps [rsp+0x50], xmm5
00007dd052fd4f86  vmovaps [rsp+0x60], xmm6
00007dd052fd4f8c  vmovaps [rsp+0x70], xmm7
00007dd052fd4f92  vmovaps [rsp+0x80], xmm8
00007dd052fd4f9b  vmovaps [rsp+0x90], xmm9
00007dd052fd4fa4  vmovaps [rsp+0xA0], xmm10
00007dd052fd4fad  vmovaps [rsp+0xB0], xmm11
00007dd052fd4fb6  vmovaps [rsp+0xC0], xmm12
00007dd052fd4fbf  vmovaps [rsp+0xD0], xmm13
00007dd052fd4fc8  vmovaps [rsp+0xE0], xmm15
00007dd052fd4fd1  sub rsp, 0x30
00007dd052fd4fd5  movaps [rsp], xmm14
00007dd052fd4fda  movaps [rsp+0x10], xmm13
00007dd052fd4fe0  movaps [rsp+0x20], xmm2
00007dd052fd4fe5  lea rdi, [rsp]
00007dd052fd4fe9  mov esi, 0x00
00007dd052fd4fee  mov rax, 0x61D0404B9530
00007dd052fd4ff8  call rax
00007dd052fd4ffa  movaps xmm14, [rsp]
00007dd052fd4fff  add rsp, 0x30
00007dd052fd5003  vmovaps xmm0, [rsp]
00007dd052fd5008  vmovaps xmm1, [rsp+0x10]
00007dd052fd500e  vmovaps xmm2, [rsp+0x20]
00007dd052fd5014  vmovaps xmm3, [rsp+0x30]
00007dd052fd501a  vmovaps xmm4, [rsp+0x40]
00007dd052fd5020  vmovaps xmm5, [rsp+0x50]
00007dd052fd5026  vmovaps xmm6, [rsp+0x60]
00007dd052fd502c  vmovaps xmm7, [rsp+0x70]
00007dd052fd5032  vmovaps xmm8, [rsp+0x80]
00007dd052fd503b  vmovaps xmm9, [rsp+0x90]
00007dd052fd5044  vmovaps xmm10, [rsp+0xA0]
00007dd052fd504d  vmovaps xmm11, [rsp+0xB0]
00007dd052fd5056  vmovaps xmm12, [rsp+0xC0]
00007dd052fd505f  vmovaps xmm13, [rsp+0xD0]
00007dd052fd5068  vmovaps xmm15, [rsp+0xE0]
00007dd052fd5071  add rsp, 0xF0
00007dd052fd5078  pop r11
00007dd052fd507a  pop r10
00007dd052fd507c  pop r9
00007dd052fd507e  pop r8
00007dd052fd5080  pop rsi
00007dd052fd5081  pop rdi
00007dd052fd5082  pop rdx
00007dd052fd5083  pop rcx
00007dd052fd5084  pop rax
00007dd052fd5085  add rsp, 0x08
00007dd052fd5089  jmp 0x00007DD052FD2D4B
00007dd052fd508e  sub rsp, 0x08
00007dd052fd5092  push rax
00007dd052fd5093  push rcx
00007dd052fd5094  push rdx
00007dd052fd5095  push rdi
00007dd052fd5096  push rsi
00007dd052fd5097  push r8
00007dd052fd5099  push r9
00007dd052fd509b  push r10
00007dd052fd509d  push r11
00007dd052fd509f  sub rsp, 0xF0
00007dd052fd50a6  vmovaps [rsp], xmm0
00007dd052fd50ab  vmovaps [rsp+0x10], xmm2
00007dd052fd50b1  vmovaps [rsp+0x20], xmm3
00007dd052fd50b7  vmovaps [rsp+0x30], xmm4
00007dd052fd50bd  vmovaps [rsp+0x40], xmm5
00007dd052fd50c3  vmovaps [rsp+0x50], xmm6
00007dd052fd50c9  vmovaps [rsp+0x60], xmm7
00007dd052fd50cf  vmovaps [rsp+0x70], xmm8
00007dd052fd50d5  vmovaps [rsp+0x80], xmm9
00007dd052fd50de  vmovaps [rsp+0x90], xmm10
00007dd052fd50e7  vmovaps [rsp+0xA0], xmm11
00007dd052fd50f0  vmovaps [rsp+0xB0], xmm12
00007dd052fd50f9  vmovaps [rsp+0xC0], xmm13
00007dd052fd5102  vmovaps [rsp+0xD0], xmm14
00007dd052fd510b  vmovaps [rsp+0xE0], xmm15
00007dd052fd5114  sub rsp, 0x30
00007dd052fd5118  movaps [rsp], xmm1
00007dd052fd511c  movaps [rsp+0x10], xmm13
00007dd052fd5122  movaps [rsp+0x20], xmm2
00007dd052fd5127  lea rdi, [rsp]
00007dd052fd512b  mov esi, 0x00
00007dd052fd5130  mov rax, 0x61D0404B9530
00007dd052fd513a  call rax
00007dd052fd513c  movaps xmm1, [rsp]
00007dd052fd5140  add rsp, 0x30
00007dd052fd5144  vmovaps xmm0, [rsp]
00007dd052fd5149  vmovaps xmm2, [rsp+0x10]
00007dd052fd514f  vmovaps xmm3, [rsp+0x20]
00007dd052fd5155  vmovaps xmm4, [rsp+0x30]
00007dd052fd515b  vmovaps xmm5, [rsp+0x40]
00007dd052fd5161  vmovaps xmm6, [rsp+0x50]
00007dd052fd5167  vmovaps xmm7, [rsp+0x60]
00007dd052fd516d  vmovaps xmm8, [rsp+0x70]
00007dd052fd5173  vmovaps xmm9, [rsp+0x80]
00007dd052fd517c  vmovaps xmm10, [rsp+0x90]
00007dd052fd5185  vmovaps xmm11, [rsp+0xA0]
00007dd052fd518e  vmovaps xmm12, [rsp+0xB0]
00007dd052fd5197  vmovaps xmm13, [rsp+0xC0]
00007dd052fd51a0  vmovaps xmm14, [rsp+0xD0]
00007dd052fd51a9  vmovaps xmm15, [rsp+0xE0]
00007dd052fd51b2  add rsp, 0xF0
00007dd052fd51b9  pop r11
00007dd052fd51bb  pop r10
00007dd052fd51bd  pop r9
00007dd052fd51bf  pop r8
00007dd052fd51c1  pop rsi
00007dd052fd51c2  pop rdi
00007dd052fd51c3  pop rdx
00007dd052fd51c4  pop rcx
00007dd052fd51c5  pop rax
00007dd052fd51c6  add rsp, 0x08
00007dd052fd51ca  jmp 0x00007DD052FD2D79
00007dd052fd51cf  sub rsp, 0x08
00007dd052fd51d3  push rax
00007dd052fd51d4  push rcx
00007dd052fd51d5  push rdx
00007dd052fd51d6  push rdi
00007dd052fd51d7  push rsi
00007dd052fd51d8  push r8
00007dd052fd51da  push r9
00007dd052fd51dc  push r10
00007dd052fd51de  push r11
00007dd052fd51e0  sub rsp, 0xF0
00007dd052fd51e7  vmovaps [rsp], xmm0
00007dd052fd51ec  vmovaps [rsp+0x10], xmm1
00007dd052fd51f2  vmovaps [rsp+0x20], xmm3
00007dd052fd51f8  vmovaps [rsp+0x30], xmm4
00007dd052fd51fe  vmovaps [rsp+0x40], xmm5
00007dd052fd5204  vmovaps [rsp+0x50], xmm6
00007dd052fd520a  vmovaps [rsp+0x60], xmm7
00007dd052fd5210  vmovaps [rsp+0x70], xmm8
00007dd052fd5216  vmovaps [rsp+0x80], xmm9
00007dd052fd521f  vmovaps [rsp+0x90], xmm10
00007dd052fd5228  vmovaps [rsp+0xA0], xmm11
00007dd052fd5231  vmovaps [rsp+0xB0], xmm12
00007dd052fd523a  vmovaps [rsp+0xC0], xmm13
00007dd052fd5243  vmovaps [rsp+0xD0], xmm14
00007dd052fd524c  vmovaps [rsp+0xE0], xmm15
00007dd052fd5255  sub rsp, 0x30
00007dd052fd5259  movaps [rsp], xmm2
00007dd052fd525d  movaps [rsp+0x10], xmm1
00007dd052fd5262  movaps [rsp+0x20], xmm13
00007dd052fd5268  lea rdi, [rsp]
00007dd052fd526c  mov esi, 0x00
00007dd052fd5271  mov rax, 0x61D0404B9530
00007dd052fd527b  call rax
00007dd052fd527d  movaps xmm2, [rsp]
00007dd052fd5281  add rsp, 0x30
00007dd052fd5285  vmovaps xmm0, [rsp]
00007dd052fd528a  vmovaps xmm1, [rsp+0x10]
00007dd052fd5290  vmovaps xmm3, [rsp+0x20]
00007dd052fd5296  vmovaps xmm4, [rsp+0x30]
00007dd052fd529c  vmovaps xmm5, [rsp+0x40]
00007dd052fd52a2  vmovaps xmm6, [rsp+0x50]
00007dd052fd52a8  vmovaps xmm7, [rsp+0x60]
00007dd052fd52ae  vmovaps xmm8, [rsp+0x70]
00007dd052fd52b4  vmovaps xmm9, [rsp+0x80]
00007dd052fd52bd  vmovaps xmm10, [rsp+0x90]
00007dd052fd52c6  vmovaps xmm11, [rsp+0xA0]
00007dd052fd52cf  vmovaps xmm12, [rsp+0xB0]
00007dd052fd52d8  vmovaps xmm13, [rsp+0xC0]
00007dd052fd52e1  vmovaps xmm14, [rsp+0xD0]
00007dd052fd52ea  vmovaps xmm15, [rsp+0xE0]
00007dd052fd52f3  add rsp, 0xF0
00007dd052fd52fa  pop r11
00007dd052fd52fc  pop r10
00007dd052fd52fe  pop r9
00007dd052fd5300  pop r8
00007dd052fd5302  pop rsi
00007dd052fd5303  pop rdi
00007dd052fd5304  pop rdx
00007dd052fd5305  pop rcx
00007dd052fd5306  pop rax
00007dd052fd5307  add rsp, 0x08
00007dd052fd530b  jmp 0x00007DD052FD2DD2
00007dd052fd5310  call 0x00007DD052DFF430
00007dd052fd5315  jmp 0x00007DD052FD2DDF
00007dd052fd531a  sub rsp, 0x08
00007dd052fd531e  push rax
00007dd052fd531f  push rcx
00007dd052fd5320  push rdx
00007dd052fd5321  push rdi
00007dd052fd5322  push rsi
00007dd052fd5323  push r8
00007dd052fd5325  push r9
00007dd052fd5327  push r10
00007dd052fd5329  push r11
00007dd052fd532b  sub rsp, 0xF0
00007dd052fd5332  vmovaps [rsp], xmm0
00007dd052fd5337  vmovaps [rsp+0x10], xmm1
00007dd052fd533d  vmovaps [rsp+0x20], xmm2
00007dd052fd5343  vmovaps [rsp+0x30], xmm3
00007dd052fd5349  vmovaps [rsp+0x40], xmm4
00007dd052fd534f  vmovaps [rsp+0x50], xmm5
00007dd052fd5355  vmovaps [rsp+0x60], xmm6
00007dd052fd535b  vmovaps [rsp+0x70], xmm7
00007dd052fd5361  vmovaps [rsp+0x80], xmm8
00007dd052fd536a  vmovaps [rsp+0x90], xmm9
00007dd052fd5373  vmovaps [rsp+0xA0], xmm10
00007dd052fd537c  vmovaps [rsp+0xB0], xmm11
00007dd052fd5385  vmovaps [rsp+0xC0], xmm12
00007dd052fd538e  vmovaps [rsp+0xD0], xmm13
00007dd052fd5397  vmovaps [rsp+0xE0], xmm14
00007dd052fd53a0  sub rsp, 0x30
00007dd052fd53a4  movaps [rsp], xmm15
00007dd052fd53a9  movaps [rsp+0x10], xmm13
00007dd052fd53af  movaps [rsp+0x20], xmm1
00007dd052fd53b4  lea rdi, [rsp]
00007dd052fd53b8  mov esi, 0x00
00007dd052fd53bd  mov rax, 0x61D0404B9530
00007dd052fd53c7  call rax
00007dd052fd53c9  movaps xmm15, [rsp]
00007dd052fd53ce  add rsp, 0x30
00007dd052fd53d2  vmovaps xmm0, [rsp]
00007dd052fd53d7  vmovaps xmm1, [rsp+0x10]
00007dd052fd53dd  vmovaps xmm2, [rsp+0x20]
00007dd052fd53e3  vmovaps xmm3, [rsp+0x30]
00007dd052fd53e9  vmovaps xmm4, [rsp+0x40]
00007dd052fd53ef  vmovaps xmm5, [rsp+0x50]
00007dd052fd53f5  vmovaps xmm6, [rsp+0x60]
00007dd052fd53fb  vmovaps xmm7, [rsp+0x70]
00007dd052fd5401  vmovaps xmm8, [rsp+0x80]
00007dd052fd540a  vmovaps xmm9, [rsp+0x90]
00007dd052fd5413  vmovaps xmm10, [rsp+0xA0]
00007dd052fd541c  vmovaps xmm11, [rsp+0xB0]
00007dd052fd5425  vmovaps xmm12, [rsp+0xC0]
00007dd052fd542e  vmovaps xmm13, [rsp+0xD0]
00007dd052fd5437  vmovaps xmm14, [rsp+0xE0]
00007dd052fd5440  add rsp, 0xF0
00007dd052fd5447  pop r11
00007dd052fd5449  pop r10
00007dd052fd544b  pop r9
00007dd052fd544d  pop r8
00007dd052fd544f  pop rsi
00007dd052fd5450  pop rdi
00007dd052fd5451  pop rdx
00007dd052fd5452  pop rcx
00007dd052fd5453  pop rax
00007dd052fd5454  add rsp, 0x08
00007dd052fd5458  jmp 0x00007DD052FD2E1E
00007dd052fd545d  sub rsp, 0x08
00007dd052fd5461  push rax
00007dd052fd5462  push rcx
00007dd052fd5463  push rdx
00007dd052fd5464  push rdi
00007dd052fd5465  push rsi
00007dd052fd5466  push r8
00007dd052fd5468  push r9
00007dd052fd546a  push r10
00007dd052fd546c  push r11
00007dd052fd546e  sub rsp, 0xF0
00007dd052fd5475  vmovaps [rsp], xmm0
00007dd052fd547a  vmovaps [rsp+0x10], xmm1
00007dd052fd5480  vmovaps [rsp+0x20], xmm2
00007dd052fd5486  vmovaps [rsp+0x30], xmm3
00007dd052fd548c  vmovaps [rsp+0x40], xmm4
00007dd052fd5492  vmovaps [rsp+0x50], xmm5
00007dd052fd5498  vmovaps [rsp+0x60], xmm6
00007dd052fd549e  vmovaps [rsp+0x70], xmm7
00007dd052fd54a4  vmovaps [rsp+0x80], xmm8
00007dd052fd54ad  vmovaps [rsp+0x90], xmm9
00007dd052fd54b6  vmovaps [rsp+0xA0], xmm10
00007dd052fd54bf  vmovaps [rsp+0xB0], xmm11
00007dd052fd54c8  vmovaps [rsp+0xC0], xmm12
00007dd052fd54d1  vmovaps [rsp+0xD0], xmm13
00007dd052fd54da  vmovaps [rsp+0xE0], xmm15
00007dd052fd54e3  sub rsp, 0x30
00007dd052fd54e7  movaps [rsp], xmm14
00007dd052fd54ec  movaps [rsp+0x10], xmm11
00007dd052fd54f2  movaps [rsp+0x20], xmm1
00007dd052fd54f7  lea rdi, [rsp]
00007dd052fd54fb  mov esi, 0x00
00007dd052fd5500  mov rax, 0x61D0404B9530
00007dd052fd550a  call rax
00007dd052fd550c  movaps xmm14, [rsp]
00007dd052fd5511  add rsp, 0x30
00007dd052fd5515  vmovaps xmm0, [rsp]
00007dd052fd551a  vmovaps xmm1, [rsp+0x10]
00007dd052fd5520  vmovaps xmm2, [rsp+0x20]
00007dd052fd5526  vmovaps xmm3, [rsp+0x30]
00007dd052fd552c  vmovaps xmm4, [rsp+0x40]
00007dd052fd5532  vmovaps xmm5, [rsp+0x50]
00007dd052fd5538  vmovaps xmm6, [rsp+0x60]
00007dd052fd553e  vmovaps xmm7, [rsp+0x70]
00007dd052fd5544  vmovaps xmm8, [rsp+0x80]
00007dd052fd554d  vmovaps xmm9, [rsp+0x90]
00007dd052fd5556  vmovaps xmm10, [rsp+0xA0]
00007dd052fd555f  vmovaps xmm11, [rsp+0xB0]
00007dd052fd5568  vmovaps xmm12, [rsp+0xC0]
00007dd052fd5571  vmovaps xmm13, [rsp+0xD0]
00007dd052fd557a  vmovaps xmm15, [rsp+0xE0]
00007dd052fd5583  add rsp, 0xF0
00007dd052fd558a  pop r11
00007dd052fd558c  pop r10
00007dd052fd558e  pop r9
00007dd052fd5590  pop r8
00007dd052fd5592  pop rsi
00007dd052fd5593  pop rdi
00007dd052fd5594  pop rdx
00007dd052fd5595  pop rcx
00007dd052fd5596  pop rax
00007dd052fd5597  add rsp, 0x08
00007dd052fd559b  jmp 0x00007DD052FD2E48
00007dd052fd55a0  sub rsp, 0x08
00007dd052fd55a4  push rax
00007dd052fd55a5  push rcx
00007dd052fd55a6  push rdx
00007dd052fd55a7  push rdi
00007dd052fd55a8  push rsi
00007dd052fd55a9  push r8
00007dd052fd55ab  push r9
00007dd052fd55ad  push r10
00007dd052fd55af  push r11
00007dd052fd55b1  sub rsp, 0xF0
00007dd052fd55b8  vmovaps [rsp], xmm0
00007dd052fd55bd  vmovaps [rsp+0x10], xmm1
00007dd052fd55c3  vmovaps [rsp+0x20], xmm2
00007dd052fd55c9  vmovaps [rsp+0x30], xmm3
00007dd052fd55cf  vmovaps [rsp+0x40], xmm4
00007dd052fd55d5  vmovaps [rsp+0x50], xmm5
00007dd052fd55db  vmovaps [rsp+0x60], xmm6
00007dd052fd55e1  vmovaps [rsp+0x70], xmm7
00007dd052fd55e7  vmovaps [rsp+0x80], xmm8
00007dd052fd55f0  vmovaps [rsp+0x90], xmm9
00007dd052fd55f9  vmovaps [rsp+0xA0], xmm10
00007dd052fd5602  vmovaps [rsp+0xB0], xmm11
00007dd052fd560b  vmovaps [rsp+0xC0], xmm12
00007dd052fd5614  vmovaps [rsp+0xD0], xmm14
00007dd052fd561d  vmovaps [rsp+0xE0], xmm15
00007dd052fd5626  sub rsp, 0x30
00007dd052fd562a  movaps [rsp], xmm13
00007dd052fd562f  movaps [rsp+0x10], xmm11
00007dd052fd5635  movaps [rsp+0x20], xmm1
00007dd052fd563a  lea rdi, [rsp]
00007dd052fd563e  mov esi, 0x00
00007dd052fd5643  mov rax, 0x61D0404B9530
00007dd052fd564d  call rax
00007dd052fd564f  movaps xmm13, [rsp]
00007dd052fd5654  add rsp, 0x30
00007dd052fd5658  vmovaps xmm0, [rsp]
00007dd052fd565d  vmovaps xmm1, [rsp+0x10]
00007dd052fd5663  vmovaps xmm2, [rsp+0x20]
00007dd052fd5669  vmovaps xmm3, [rsp+0x30]
00007dd052fd566f  vmovaps xmm4, [rsp+0x40]
00007dd052fd5675  vmovaps xmm5, [rsp+0x50]
00007dd052fd567b  vmovaps xmm6, [rsp+0x60]
00007dd052fd5681  vmovaps xmm7, [rsp+0x70]
00007dd052fd5687  vmovaps xmm8, [rsp+0x80]
00007dd052fd5690  vmovaps xmm9, [rsp+0x90]
00007dd052fd5699  vmovaps xmm10, [rsp+0xA0]
00007dd052fd56a2  vmovaps xmm11, [rsp+0xB0]
00007dd052fd56ab  vmovaps xmm12, [rsp+0xC0]
00007dd052fd56b4  vmovaps xmm14, [rsp+0xD0]
00007dd052fd56bd  vmovaps xmm15, [rsp+0xE0]
00007dd052fd56c6  add rsp, 0xF0
00007dd052fd56cd  pop r11
00007dd052fd56cf  pop r10
00007dd052fd56d1  pop r9
00007dd052fd56d3  pop r8
00007dd052fd56d5  pop rsi
00007dd052fd56d6  pop rdi
00007dd052fd56d7  pop rdx
00007dd052fd56d8  pop rcx
00007dd052fd56d9  pop rax
00007dd052fd56da  add rsp, 0x08
00007dd052fd56de  jmp 0x00007DD052FD2E9D
00007dd052fd56e3  call 0x00007DD052DFF430
00007dd052fd56e8  jmp 0x00007DD052FD2EAA
00007dd052fd56ed  sub rsp, 0x08
00007dd052fd56f1  push rax
00007dd052fd56f2  push rcx
00007dd052fd56f3  push rdx
00007dd052fd56f4  push rdi
00007dd052fd56f5  push rsi
00007dd052fd56f6  push r8
00007dd052fd56f8  push r9
00007dd052fd56fa  push r10
00007dd052fd56fc  push r11
00007dd052fd56fe  sub rsp, 0xF0
00007dd052fd5705  vmovaps [rsp], xmm0
00007dd052fd570a  vmovaps [rsp+0x10], xmm1
00007dd052fd5710  vmovaps [rsp+0x20], xmm2
00007dd052fd5716  vmovaps [rsp+0x30], xmm3
00007dd052fd571c  vmovaps [rsp+0x40], xmm4
00007dd052fd5722  vmovaps [rsp+0x50], xmm5
00007dd052fd5728  vmovaps [rsp+0x60], xmm6
00007dd052fd572e  vmovaps [rsp+0x70], xmm7
00007dd052fd5734  vmovaps [rsp+0x80], xmm8
00007dd052fd573d  vmovaps [rsp+0x90], xmm9
00007dd052fd5746  vmovaps [rsp+0xA0], xmm10
00007dd052fd574f  vmovaps [rsp+0xB0], xmm11
00007dd052fd5758  vmovaps [rsp+0xC0], xmm12
00007dd052fd5761  vmovaps [rsp+0xD0], xmm13
00007dd052fd576a  vmovaps [rsp+0xE0], xmm14
00007dd052fd5773  sub rsp, 0x30
00007dd052fd5777  movaps [rsp], xmm15
00007dd052fd577c  movaps [rsp+0x10], xmm11
00007dd052fd5782  movaps [rsp+0x20], xmm1
00007dd052fd5787  lea rdi, [rsp]
00007dd052fd578b  mov esi, 0x00
00007dd052fd5790  mov rax, 0x61D0404B9530
00007dd052fd579a  call rax
00007dd052fd579c  movaps xmm15, [rsp]
00007dd052fd57a1  add rsp, 0x30
00007dd052fd57a5  vmovaps xmm0, [rsp]
00007dd052fd57aa  vmovaps xmm1, [rsp+0x10]
00007dd052fd57b0  vmovaps xmm2, [rsp+0x20]
00007dd052fd57b6  vmovaps xmm3, [rsp+0x30]
00007dd052fd57bc  vmovaps xmm4, [rsp+0x40]
00007dd052fd57c2  vmovaps xmm5, [rsp+0x50]
00007dd052fd57c8  vmovaps xmm6, [rsp+0x60]
00007dd052fd57ce  vmovaps xmm7, [rsp+0x70]
00007dd052fd57d4  vmovaps xmm8, [rsp+0x80]
00007dd052fd57dd  vmovaps xmm9, [rsp+0x90]
00007dd052fd57e6  vmovaps xmm10, [rsp+0xA0]
00007dd052fd57ef  vmovaps xmm11, [rsp+0xB0]
00007dd052fd57f8  vmovaps xmm12, [rsp+0xC0]
00007dd052fd5801  vmovaps xmm13, [rsp+0xD0]
00007dd052fd580a  vmovaps xmm14, [rsp+0xE0]
00007dd052fd5813  add rsp, 0xF0
00007dd052fd581a  pop r11
00007dd052fd581c  pop r10
00007dd052fd581e  pop r9
00007dd052fd5820  pop r8
00007dd052fd5822  pop rsi
00007dd052fd5823  pop rdi
00007dd052fd5824  pop rdx
00007dd052fd5825  pop rcx
00007dd052fd5826  pop rax
00007dd052fd5827  add rsp, 0x08
00007dd052fd582b  jmp 0x00007DD052FD2EE3
00007dd052fd5830  sub rsp, 0x08
00007dd052fd5834  push rax
00007dd052fd5835  push rcx
00007dd052fd5836  push rdx
00007dd052fd5837  push rdi
00007dd052fd5838  push rsi
00007dd052fd5839  push r8
00007dd052fd583b  push r9
00007dd052fd583d  push r10
00007dd052fd583f  push r11
00007dd052fd5841  sub rsp, 0xF0
00007dd052fd5848  vmovaps [rsp], xmm0
00007dd052fd584d  vmovaps [rsp+0x10], xmm1
00007dd052fd5853  vmovaps [rsp+0x20], xmm2
00007dd052fd5859  vmovaps [rsp+0x30], xmm3
00007dd052fd585f  vmovaps [rsp+0x40], xmm4
00007dd052fd5865  vmovaps [rsp+0x50], xmm5
00007dd052fd586b  vmovaps [rsp+0x60], xmm6
00007dd052fd5871  vmovaps [rsp+0x70], xmm7
00007dd052fd5877  vmovaps [rsp+0x80], xmm8
00007dd052fd5880  vmovaps [rsp+0x90], xmm9
00007dd052fd5889  vmovaps [rsp+0xA0], xmm10
00007dd052fd5892  vmovaps [rsp+0xB0], xmm12
00007dd052fd589b  vmovaps [rsp+0xC0], xmm13
00007dd052fd58a4  vmovaps [rsp+0xD0], xmm14
00007dd052fd58ad  vmovaps [rsp+0xE0], xmm15
00007dd052fd58b6  sub rsp, 0x30
00007dd052fd58ba  movaps [rsp], xmm11
00007dd052fd58bf  movaps [rsp+0x10], xmm6
00007dd052fd58c4  movaps [rsp+0x20], xmm14
00007dd052fd58ca  lea rdi, [rsp]
00007dd052fd58ce  mov esi, 0x00
00007dd052fd58d3  mov rax, 0x61D0404B9530
00007dd052fd58dd  call rax
00007dd052fd58df  movaps xmm11, [rsp]
00007dd052fd58e4  add rsp, 0x30
00007dd052fd58e8  vmovaps xmm0, [rsp]
00007dd052fd58ed  vmovaps xmm1, [rsp+0x10]
00007dd052fd58f3  vmovaps xmm2, [rsp+0x20]
00007dd052fd58f9  vmovaps xmm3, [rsp+0x30]
00007dd052fd58ff  vmovaps xmm4, [rsp+0x40]
00007dd052fd5905  vmovaps xmm5, [rsp+0x50]
00007dd052fd590b  vmovaps xmm6, [rsp+0x60]
00007dd052fd5911  vmovaps xmm7, [rsp+0x70]
00007dd052fd5917  vmovaps xmm8, [rsp+0x80]
00007dd052fd5920  vmovaps xmm9, [rsp+0x90]
00007dd052fd5929  vmovaps xmm10, [rsp+0xA0]
00007dd052fd5932  vmovaps xmm12, [rsp+0xB0]
00007dd052fd593b  vmovaps xmm13, [rsp+0xC0]
00007dd052fd5944  vmovaps xmm14, [rsp+0xD0]
00007dd052fd594d  vmovaps xmm15, [rsp+0xE0]
00007dd052fd5956  add rsp, 0xF0
00007dd052fd595d  pop r11
00007dd052fd595f  pop r10
00007dd052fd5961  pop r9
00007dd052fd5963  pop r8
00007dd052fd5965  pop rsi
00007dd052fd5966  pop rdi
00007dd052fd5967  pop rdx
00007dd052fd5968  pop rcx
00007dd052fd5969  pop rax
00007dd052fd596a  add rsp, 0x08
00007dd052fd596e  jmp 0x00007DD052FD2F5B
00007dd052fd5973  call 0x00007DD052DFF430
00007dd052fd5978  jmp 0x00007DD052FD2F65
00007dd052fd597d  sub rsp, 0x08
00007dd052fd5981  push rax
00007dd052fd5982  push rcx
00007dd052fd5983  push rdx
00007dd052fd5984  push rdi
00007dd052fd5985  push rsi
00007dd052fd5986  push r8
00007dd052fd5988  push r9
00007dd052fd598a  push r10
00007dd052fd598c  push r11
00007dd052fd598e  sub rsp, 0xF0
00007dd052fd5995  vmovaps [rsp], xmm0
00007dd052fd599a  vmovaps [rsp+0x10], xmm1
00007dd052fd59a0  vmovaps [rsp+0x20], xmm2
00007dd052fd59a6  vmovaps [rsp+0x30], xmm3
00007dd052fd59ac  vmovaps [rsp+0x40], xmm4
00007dd052fd59b2  vmovaps [rsp+0x50], xmm5
00007dd052fd59b8  vmovaps [rsp+0x60], xmm6
00007dd052fd59be  vmovaps [rsp+0x70], xmm7
00007dd052fd59c4  vmovaps [rsp+0x80], xmm8
00007dd052fd59cd  vmovaps [rsp+0x90], xmm9
00007dd052fd59d6  vmovaps [rsp+0xA0], xmm10
00007dd052fd59df  vmovaps [rsp+0xB0], xmm11
00007dd052fd59e8  vmovaps [rsp+0xC0], xmm12
00007dd052fd59f1  vmovaps [rsp+0xD0], xmm13
00007dd052fd59fa  vmovaps [rsp+0xE0], xmm15
00007dd052fd5a03  sub rsp, 0x30
00007dd052fd5a07  movaps [rsp], xmm14
00007dd052fd5a0c  movaps [rsp+0x10], xmm6
00007dd052fd5a11  movaps [rsp+0x20], xmm2
00007dd052fd5a16  lea rdi, [rsp]
00007dd052fd5a1a  mov esi, 0x00
00007dd052fd5a1f  mov rax, 0x61D0404B9530
00007dd052fd5a29  call rax
00007dd052fd5a2b  movaps xmm14, [rsp]
00007dd052fd5a30  add rsp, 0x30
00007dd052fd5a34  vmovaps xmm0, [rsp]
00007dd052fd5a39  vmovaps xmm1, [rsp+0x10]
00007dd052fd5a3f  vmovaps xmm2, [rsp+0x20]
00007dd052fd5a45  vmovaps xmm3, [rsp+0x30]
00007dd052fd5a4b  vmovaps xmm4, [rsp+0x40]
00007dd052fd5a51  vmovaps xmm5, [rsp+0x50]
00007dd052fd5a57  vmovaps xmm6, [rsp+0x60]
00007dd052fd5a5d  vmovaps xmm7, [rsp+0x70]
00007dd052fd5a63  vmovaps xmm8, [rsp+0x80]
00007dd052fd5a6c  vmovaps xmm9, [rsp+0x90]
00007dd052fd5a75  vmovaps xmm10, [rsp+0xA0]
00007dd052fd5a7e  vmovaps xmm11, [rsp+0xB0]
00007dd052fd5a87  vmovaps xmm12, [rsp+0xC0]
00007dd052fd5a90  vmovaps xmm13, [rsp+0xD0]
00007dd052fd5a99  vmovaps xmm15, [rsp+0xE0]
00007dd052fd5aa2  add rsp, 0xF0
00007dd052fd5aa9  pop r11
00007dd052fd5aab  pop r10
00007dd052fd5aad  pop r9
00007dd052fd5aaf  pop r8
00007dd052fd5ab1  pop rsi
00007dd052fd5ab2  pop rdi
00007dd052fd5ab3  pop rdx
00007dd052fd5ab4  pop rcx
00007dd052fd5ab5  pop rax
00007dd052fd5ab6  add rsp, 0x08
00007dd052fd5aba  jmp 0x00007DD052FD2F99
00007dd052fd5abf  sub rsp, 0x08
00007dd052fd5ac3  push rax
00007dd052fd5ac4  push rcx
00007dd052fd5ac5  push rdx
00007dd052fd5ac6  push rdi
00007dd052fd5ac7  push rsi
00007dd052fd5ac8  push r8
00007dd052fd5aca  push r9
00007dd052fd5acc  push r10
00007dd052fd5ace  push r11
00007dd052fd5ad0  sub rsp, 0xF0
00007dd052fd5ad7  vmovaps [rsp], xmm0
00007dd052fd5adc  vmovaps [rsp+0x10], xmm1
00007dd052fd5ae2  vmovaps [rsp+0x20], xmm2
00007dd052fd5ae8  vmovaps [rsp+0x30], xmm3
00007dd052fd5aee  vmovaps [rsp+0x40], xmm4
00007dd052fd5af4  vmovaps [rsp+0x50], xmm5
00007dd052fd5afa  vmovaps [rsp+0x60], xmm7
00007dd052fd5b00  vmovaps [rsp+0x70], xmm8
00007dd052fd5b06  vmovaps [rsp+0x80], xmm9
00007dd052fd5b0f  vmovaps [rsp+0x90], xmm10
00007dd052fd5b18  vmovaps [rsp+0xA0], xmm11
00007dd052fd5b21  vmovaps [rsp+0xB0], xmm12
00007dd052fd5b2a  vmovaps [rsp+0xC0], xmm13
00007dd052fd5b33  vmovaps [rsp+0xD0], xmm14
00007dd052fd5b3c  vmovaps [rsp+0xE0], xmm15
00007dd052fd5b45  sub rsp, 0x30
00007dd052fd5b49  movaps [rsp], xmm6
00007dd052fd5b4d  movaps [rsp+0x10], xmm5
00007dd052fd5b52  movaps [rsp+0x20], xmm1
00007dd052fd5b57  lea rdi, [rsp]
00007dd052fd5b5b  mov esi, 0x00
00007dd052fd5b60  mov rax, 0x61D0404B9530
00007dd052fd5b6a  call rax
00007dd052fd5b6c  movaps xmm6, [rsp]
00007dd052fd5b70  add rsp, 0x30
00007dd052fd5b74  vmovaps xmm0, [rsp]
00007dd052fd5b79  vmovaps xmm1, [rsp+0x10]
00007dd052fd5b7f  vmovaps xmm2, [rsp+0x20]
00007dd052fd5b85  vmovaps xmm3, [rsp+0x30]
00007dd052fd5b8b  vmovaps xmm4, [rsp+0x40]
00007dd052fd5b91  vmovaps xmm5, [rsp+0x50]
00007dd052fd5b97  vmovaps xmm7, [rsp+0x60]
00007dd052fd5b9d  vmovaps xmm8, [rsp+0x70]
00007dd052fd5ba3  vmovaps xmm9, [rsp+0x80]
00007dd052fd5bac  vmovaps xmm10, [rsp+0x90]
00007dd052fd5bb5  vmovaps xmm11, [rsp+0xA0]
00007dd052fd5bbe  vmovaps xmm12, [rsp+0xB0]
00007dd052fd5bc7  vmovaps xmm13, [rsp+0xC0]
00007dd052fd5bd0  vmovaps xmm14, [rsp+0xD0]
00007dd052fd5bd9  vmovaps xmm15, [rsp+0xE0]
00007dd052fd5be2  add rsp, 0xF0
00007dd052fd5be9  pop r11
00007dd052fd5beb  pop r10
00007dd052fd5bed  pop r9
00007dd052fd5bef  pop r8
00007dd052fd5bf1  pop rsi
00007dd052fd5bf2  pop rdi
00007dd052fd5bf3  pop rdx
00007dd052fd5bf4  pop rcx
00007dd052fd5bf5  pop rax
00007dd052fd5bf6  add rsp, 0x08
00007dd052fd5bfa  jmp 0x00007DD052FD2FBF
00007dd052fd5bff  sub rsp, 0x08
00007dd052fd5c03  push rax
00007dd052fd5c04  push rcx
00007dd052fd5c05  push rdx
00007dd052fd5c06  push rdi
00007dd052fd5c07  push rsi
00007dd052fd5c08  push r8
00007dd052fd5c0a  push r9
00007dd052fd5c0c  push r10
00007dd052fd5c0e  push r11
00007dd052fd5c10  sub rsp, 0xF0
00007dd052fd5c17  vmovaps [rsp], xmm0
00007dd052fd5c1c  vmovaps [rsp+0x10], xmm2
00007dd052fd5c22  vmovaps [rsp+0x20], xmm3
00007dd052fd5c28  vmovaps [rsp+0x30], xmm4
00007dd052fd5c2e  vmovaps [rsp+0x40], xmm5
00007dd052fd5c34  vmovaps [rsp+0x50], xmm6
00007dd052fd5c3a  vmovaps [rsp+0x60], xmm7
00007dd052fd5c40  vmovaps [rsp+0x70], xmm8
00007dd052fd5c46  vmovaps [rsp+0x80], xmm9
00007dd052fd5c4f  vmovaps [rsp+0x90], xmm10
00007dd052fd5c58  vmovaps [rsp+0xA0], xmm11
00007dd052fd5c61  vmovaps [rsp+0xB0], xmm12
00007dd052fd5c6a  vmovaps [rsp+0xC0], xmm13
00007dd052fd5c73  vmovaps [rsp+0xD0], xmm14
00007dd052fd5c7c  vmovaps [rsp+0xE0], xmm15
00007dd052fd5c85  sub rsp, 0x30
00007dd052fd5c89  movaps [rsp], xmm1
00007dd052fd5c8d  movaps [rsp+0x10], xmm5
00007dd052fd5c92  movaps [rsp+0x20], xmm13
00007dd052fd5c98  lea rdi, [rsp]
00007dd052fd5c9c  mov esi, 0x00
00007dd052fd5ca1  mov rax, 0x61D0404B9530
00007dd052fd5cab  call rax
00007dd052fd5cad  movaps xmm1, [rsp]
00007dd052fd5cb1  add rsp, 0x30
00007dd052fd5cb5  vmovaps xmm0, [rsp]
00007dd052fd5cba  vmovaps xmm2, [rsp+0x10]
00007dd052fd5cc0  vmovaps xmm3, [rsp+0x20]
00007dd052fd5cc6  vmovaps xmm4, [rsp+0x30]
00007dd052fd5ccc  vmovaps xmm5, [rsp+0x40]
00007dd052fd5cd2  vmovaps xmm6, [rsp+0x50]
00007dd052fd5cd8  vmovaps xmm7, [rsp+0x60]
00007dd052fd5cde  vmovaps xmm8, [rsp+0x70]
00007dd052fd5ce4  vmovaps xmm9, [rsp+0x80]
00007dd052fd5ced  vmovaps xmm10, [rsp+0x90]
00007dd052fd5cf6  vmovaps xmm11, [rsp+0xA0]
00007dd052fd5cff  vmovaps xmm12, [rsp+0xB0]
00007dd052fd5d08  vmovaps xmm13, [rsp+0xC0]
00007dd052fd5d11  vmovaps xmm14, [rsp+0xD0]
00007dd052fd5d1a  vmovaps xmm15, [rsp+0xE0]
00007dd052fd5d23  add rsp, 0xF0
00007dd052fd5d2a  pop r11
00007dd052fd5d2c  pop r10
00007dd052fd5d2e  pop r9
00007dd052fd5d30  pop r8
00007dd052fd5d32  pop rsi
00007dd052fd5d33  pop rdi
00007dd052fd5d34  pop rdx
00007dd052fd5d35  pop rcx
00007dd052fd5d36  pop rax
00007dd052fd5d37  add rsp, 0x08
00007dd052fd5d3b  jmp 0x00007DD052FD2FDD
00007dd052fd5d40  sub rsp, 0x08
00007dd052fd5d44  push rax
00007dd052fd5d45  push rcx
00007dd052fd5d46  push rdx
00007dd052fd5d47  push rdi
00007dd052fd5d48  push rsi
00007dd052fd5d49  push r8
00007dd052fd5d4b  push r9
00007dd052fd5d4d  push r10
00007dd052fd5d4f  push r11
00007dd052fd5d51  sub rsp, 0xF0
00007dd052fd5d58  vmovaps [rsp], xmm0
00007dd052fd5d5d  vmovaps [rsp+0x10], xmm1
00007dd052fd5d63  vmovaps [rsp+0x20], xmm2
00007dd052fd5d69  vmovaps [rsp+0x30], xmm3
00007dd052fd5d6f  vmovaps [rsp+0x40], xmm4
00007dd052fd5d75  vmovaps [rsp+0x50], xmm6
00007dd052fd5d7b  vmovaps [rsp+0x60], xmm7
00007dd052fd5d81  vmovaps [rsp+0x70], xmm8
00007dd052fd5d87  vmovaps [rsp+0x80], xmm9
00007dd052fd5d90  vmovaps [rsp+0x90], xmm10
00007dd052fd5d99  vmovaps [rsp+0xA0], xmm11
00007dd052fd5da2  vmovaps [rsp+0xB0], xmm12
00007dd052fd5dab  vmovaps [rsp+0xC0], xmm13
00007dd052fd5db4  vmovaps [rsp+0xD0], xmm14
00007dd052fd5dbd  vmovaps [rsp+0xE0], xmm15
00007dd052fd5dc6  sub rsp, 0x30
00007dd052fd5dca  movaps [rsp], xmm5
00007dd052fd5dce  movaps [rsp+0x10], xmm2
00007dd052fd5dd3  movaps [rsp+0x20], xmm13
00007dd052fd5dd9  lea rdi, [rsp]
00007dd052fd5ddd  mov esi, 0x00
00007dd052fd5de2  mov rax, 0x61D0404B9530
00007dd052fd5dec  call rax
00007dd052fd5dee  movaps xmm5, [rsp]
00007dd052fd5df2  add rsp, 0x30
00007dd052fd5df6  vmovaps xmm0, [rsp]
00007dd052fd5dfb  vmovaps xmm1, [rsp+0x10]
00007dd052fd5e01  vmovaps xmm2, [rsp+0x20]
00007dd052fd5e07  vmovaps xmm3, [rsp+0x30]
00007dd052fd5e0d  vmovaps xmm4, [rsp+0x40]
00007dd052fd5e13  vmovaps xmm6, [rsp+0x50]
00007dd052fd5e19  vmovaps xmm7, [rsp+0x60]
00007dd052fd5e1f  vmovaps xmm8, [rsp+0x70]
00007dd052fd5e25  vmovaps xmm9, [rsp+0x80]
00007dd052fd5e2e  vmovaps xmm10, [rsp+0x90]
00007dd052fd5e37  vmovaps xmm11, [rsp+0xA0]
00007dd052fd5e40  vmovaps xmm12, [rsp+0xB0]
00007dd052fd5e49  vmovaps xmm13, [rsp+0xC0]
00007dd052fd5e52  vmovaps xmm14, [rsp+0xD0]
00007dd052fd5e5b  vmovaps xmm15, [rsp+0xE0]
00007dd052fd5e64  add rsp, 0xF0
00007dd052fd5e6b  pop r11
00007dd052fd5e6d  pop r10
00007dd052fd5e6f  pop r9
00007dd052fd5e71  pop r8
00007dd052fd5e73  pop rsi
00007dd052fd5e74  pop rdi
00007dd052fd5e75  pop rdx
00007dd052fd5e76  pop rcx
00007dd052fd5e77  pop rax
00007dd052fd5e78  add rsp, 0x08
00007dd052fd5e7c  jmp 0x00007DD052FD3013
00007dd052fd5e81  sub rsp, 0x08
00007dd052fd5e85  push rax
00007dd052fd5e86  push rcx
00007dd052fd5e87  push rdx
00007dd052fd5e88  push rdi
00007dd052fd5e89  push rsi
00007dd052fd5e8a  push r8
00007dd052fd5e8c  push r9
00007dd052fd5e8e  push r10
00007dd052fd5e90  push r11
00007dd052fd5e92  sub rsp, 0xF0
00007dd052fd5e99  vmovaps [rsp], xmm0
00007dd052fd5e9e  vmovaps [rsp+0x10], xmm1
00007dd052fd5ea4  vmovaps [rsp+0x20], xmm2
00007dd052fd5eaa  vmovaps [rsp+0x30], xmm3
00007dd052fd5eb0  vmovaps [rsp+0x40], xmm4
00007dd052fd5eb6  vmovaps [rsp+0x50], xmm5
00007dd052fd5ebc  vmovaps [rsp+0x60], xmm6
00007dd052fd5ec2  vmovaps [rsp+0x70], xmm7
00007dd052fd5ec8  vmovaps [rsp+0x80], xmm8
00007dd052fd5ed1  vmovaps [rsp+0x90], xmm9
00007dd052fd5eda  vmovaps [rsp+0xA0], xmm10
00007dd052fd5ee3  vmovaps [rsp+0xB0], xmm11
00007dd052fd5eec  vmovaps [rsp+0xC0], xmm12
00007dd052fd5ef5  vmovaps [rsp+0xD0], xmm14
00007dd052fd5efe  vmovaps [rsp+0xE0], xmm15
00007dd052fd5f07  sub rsp, 0x30
00007dd052fd5f0b  movaps [rsp], xmm13
00007dd052fd5f10  movaps [rsp+0x10], xmm10
00007dd052fd5f16  movaps [rsp+0x20], xmm1
00007dd052fd5f1b  lea rdi, [rsp]
00007dd052fd5f1f  mov esi, 0x00
00007dd052fd5f24  mov rax, 0x61D0404B9530
00007dd052fd5f2e  call rax
00007dd052fd5f30  movaps xmm13, [rsp]
00007dd052fd5f35  add rsp, 0x30
00007dd052fd5f39  vmovaps xmm0, [rsp]
00007dd052fd5f3e  vmovaps xmm1, [rsp+0x10]
00007dd052fd5f44  vmovaps xmm2, [rsp+0x20]
00007dd052fd5f4a  vmovaps xmm3, [rsp+0x30]
00007dd052fd5f50  vmovaps xmm4, [rsp+0x40]
00007dd052fd5f56  vmovaps xmm5, [rsp+0x50]
00007dd052fd5f5c  vmovaps xmm6, [rsp+0x60]
00007dd052fd5f62  vmovaps xmm7, [rsp+0x70]
00007dd052fd5f68  vmovaps xmm8, [rsp+0x80]
00007dd052fd5f71  vmovaps xmm9, [rsp+0x90]
00007dd052fd5f7a  vmovaps xmm10, [rsp+0xA0]
00007dd052fd5f83  vmovaps xmm11, [rsp+0xB0]
00007dd052fd5f8c  vmovaps xmm12, [rsp+0xC0]
00007dd052fd5f95  vmovaps xmm14, [rsp+0xD0]
00007dd052fd5f9e  vmovaps xmm15, [rsp+0xE0]
00007dd052fd5fa7  add rsp, 0xF0
00007dd052fd5fae  pop r11
00007dd052fd5fb0  pop r10
00007dd052fd5fb2  pop r9
00007dd052fd5fb4  pop r8
00007dd052fd5fb6  pop rsi
00007dd052fd5fb7  pop rdi
00007dd052fd5fb8  pop rdx
00007dd052fd5fb9  pop rcx
00007dd052fd5fba  pop rax
00007dd052fd5fbb  add rsp, 0x08
00007dd052fd5fbf  jmp 0x00007DD052FD303C
00007dd052fd5fc4  sub rsp, 0x08
00007dd052fd5fc8  push rax
00007dd052fd5fc9  push rcx
00007dd052fd5fca  push rdx
00007dd052fd5fcb  push rdi
00007dd052fd5fcc  push rsi
00007dd052fd5fcd  push r8
00007dd052fd5fcf  push r9
00007dd052fd5fd1  push r10
00007dd052fd5fd3  push r11
00007dd052fd5fd5  sub rsp, 0xF0
00007dd052fd5fdc  vmovaps [rsp], xmm0
00007dd052fd5fe1  vmovaps [rsp+0x10], xmm2
00007dd052fd5fe7  vmovaps [rsp+0x20], xmm3
00007dd052fd5fed  vmovaps [rsp+0x30], xmm4
00007dd052fd5ff3  vmovaps [rsp+0x40], xmm5
00007dd052fd5ff9  vmovaps [rsp+0x50], xmm6
00007dd052fd5fff  vmovaps [rsp+0x60], xmm7
00007dd052fd6005  vmovaps [rsp+0x70], xmm8
00007dd052fd600b  vmovaps [rsp+0x80], xmm9
00007dd052fd6014  vmovaps [rsp+0x90], xmm10
00007dd052fd601d  vmovaps [rsp+0xA0], xmm11
00007dd052fd6026  vmovaps [rsp+0xB0], xmm12
00007dd052fd602f  vmovaps [rsp+0xC0], xmm13
00007dd052fd6038  vmovaps [rsp+0xD0], xmm14
00007dd052fd6041  vmovaps [rsp+0xE0], xmm15
00007dd052fd604a  sub rsp, 0x30
00007dd052fd604e  movaps [rsp], xmm1
00007dd052fd6052  movaps [rsp+0x10], xmm15
00007dd052fd6058  movaps [rsp+0x20], xmm10
00007dd052fd605e  lea rdi, [rsp]
00007dd052fd6062  mov esi, 0x00
00007dd052fd6067  mov rax, 0x61D0404B9530
00007dd052fd6071  call rax
00007dd052fd6073  movaps xmm1, [rsp]
00007dd052fd6077  add rsp, 0x30
00007dd052fd607b  vmovaps xmm0, [rsp]
00007dd052fd6080  vmovaps xmm2, [rsp+0x10]
00007dd052fd6086  vmovaps xmm3, [rsp+0x20]
00007dd052fd608c  vmovaps xmm4, [rsp+0x30]
00007dd052fd6092  vmovaps xmm5, [rsp+0x40]
00007dd052fd6098  vmovaps xmm6, [rsp+0x50]
00007dd052fd609e  vmovaps xmm7, [rsp+0x60]
00007dd052fd60a4  vmovaps xmm8, [rsp+0x70]
00007dd052fd60aa  vmovaps xmm9, [rsp+0x80]
00007dd052fd60b3  vmovaps xmm10, [rsp+0x90]
00007dd052fd60bc  vmovaps xmm11, [rsp+0xA0]
00007dd052fd60c5  vmovaps xmm12, [rsp+0xB0]
00007dd052fd60ce  vmovaps xmm13, [rsp+0xC0]
00007dd052fd60d7  vmovaps xmm14, [rsp+0xD0]
00007dd052fd60e0  vmovaps xmm15, [rsp+0xE0]
00007dd052fd60e9  add rsp, 0xF0
00007dd052fd60f0  pop r11
00007dd052fd60f2  pop r10
00007dd052fd60f4  pop r9
00007dd052fd60f6  pop r8
00007dd052fd60f8  pop rsi
00007dd052fd60f9  pop rdi
00007dd052fd60fa  pop rdx
00007dd052fd60fb  pop rcx
00007dd052fd60fc  pop rax
00007dd052fd60fd  add rsp, 0x08
00007dd052fd6101  jmp 0x00007DD052FD305B
00007dd052fd6106  sub rsp, 0x08
00007dd052fd610a  push rax
00007dd052fd610b  push rcx
00007dd052fd610c  push rdx
00007dd052fd610d  push rdi
00007dd052fd610e  push rsi
00007dd052fd610f  push r8
00007dd052fd6111  push r9
00007dd052fd6113  push r10
00007dd052fd6115  push r11
00007dd052fd6117  sub rsp, 0xF0
00007dd052fd611e  vmovaps [rsp], xmm0
00007dd052fd6123  vmovaps [rsp+0x10], xmm1
00007dd052fd6129  vmovaps [rsp+0x20], xmm2
00007dd052fd612f  vmovaps [rsp+0x30], xmm3
00007dd052fd6135  vmovaps [rsp+0x40], xmm4
00007dd052fd613b  vmovaps [rsp+0x50], xmm5
00007dd052fd6141  vmovaps [rsp+0x60], xmm6
00007dd052fd6147  vmovaps [rsp+0x70], xmm7
00007dd052fd614d  vmovaps [rsp+0x80], xmm8
00007dd052fd6156  vmovaps [rsp+0x90], xmm9
00007dd052fd615f  vmovaps [rsp+0xA0], xmm10
00007dd052fd6168  vmovaps [rsp+0xB0], xmm11
00007dd052fd6171  vmovaps [rsp+0xC0], xmm12
00007dd052fd617a  vmovaps [rsp+0xD0], xmm13
00007dd052fd6183  vmovaps [rsp+0xE0], xmm14
00007dd052fd618c  sub rsp, 0x30
00007dd052fd6190  movaps [rsp], xmm15
00007dd052fd6195  movaps [rsp+0x10], xmm10
00007dd052fd619b  movaps [rsp+0x20], xmm11
00007dd052fd61a1  lea rdi, [rsp]
00007dd052fd61a5  mov esi, 0x00
00007dd052fd61aa  mov rax, 0x61D0404B9530
00007dd052fd61b4  call rax
00007dd052fd61b6  movaps xmm15, [rsp]
00007dd052fd61bb  add rsp, 0x30
00007dd052fd61bf  vmovaps xmm0, [rsp]
00007dd052fd61c4  vmovaps xmm1, [rsp+0x10]
00007dd052fd61ca  vmovaps xmm2, [rsp+0x20]
00007dd052fd61d0  vmovaps xmm3, [rsp+0x30]
00007dd052fd61d6  vmovaps xmm4, [rsp+0x40]
00007dd052fd61dc  vmovaps xmm5, [rsp+0x50]
00007dd052fd61e2  vmovaps xmm6, [rsp+0x60]
00007dd052fd61e8  vmovaps xmm7, [rsp+0x70]
00007dd052fd61ee  vmovaps xmm8, [rsp+0x80]
00007dd052fd61f7  vmovaps xmm9, [rsp+0x90]
00007dd052fd6200  vmovaps xmm10, [rsp+0xA0]
00007dd052fd6209  vmovaps xmm11, [rsp+0xB0]
00007dd052fd6212  vmovaps xmm12, [rsp+0xC0]
00007dd052fd621b  vmovaps xmm13, [rsp+0xD0]
00007dd052fd6224  vmovaps xmm14, [rsp+0xE0]
00007dd052fd622d  add rsp, 0xF0
00007dd052fd6234  pop r11
00007dd052fd6236  pop r10
00007dd052fd6238  pop r9
00007dd052fd623a  pop r8
00007dd052fd623c  pop rsi
00007dd052fd623d  pop rdi
00007dd052fd623e  pop rdx
00007dd052fd623f  pop rcx
00007dd052fd6240  pop rax
00007dd052fd6241  add rsp, 0x08
00007dd052fd6245  jmp 0x00007DD052FD307E
00007dd052fd624a  sub rsp, 0x08
00007dd052fd624e  push rax
00007dd052fd624f  push rcx
00007dd052fd6250  push rdx
00007dd052fd6251  push rdi
00007dd052fd6252  push rsi
00007dd052fd6253  push r8
00007dd052fd6255  push r9
00007dd052fd6257  push r10
00007dd052fd6259  push r11
00007dd052fd625b  sub rsp, 0xF0
00007dd052fd6262  vmovaps [rsp], xmm0
00007dd052fd6267  vmovaps [rsp+0x10], xmm1
00007dd052fd626d  vmovaps [rsp+0x20], xmm2
00007dd052fd6273  vmovaps [rsp+0x30], xmm3
00007dd052fd6279  vmovaps [rsp+0x40], xmm4
00007dd052fd627f  vmovaps [rsp+0x50], xmm5
00007dd052fd6285  vmovaps [rsp+0x60], xmm6
00007dd052fd628b  vmovaps [rsp+0x70], xmm7
00007dd052fd6291  vmovaps [rsp+0x80], xmm8
00007dd052fd629a  vmovaps [rsp+0x90], xmm9
00007dd052fd62a3  vmovaps [rsp+0xA0], xmm11
00007dd052fd62ac  vmovaps [rsp+0xB0], xmm12
00007dd052fd62b5  vmovaps [rsp+0xC0], xmm13
00007dd052fd62be  vmovaps [rsp+0xD0], xmm14
00007dd052fd62c7  vmovaps [rsp+0xE0], xmm15
00007dd052fd62d0  sub rsp, 0x30
00007dd052fd62d4  movaps [rsp], xmm10
00007dd052fd62d9  movaps [rsp+0x10], xmm2
00007dd052fd62de  movaps [rsp+0x20], xmm11
00007dd052fd62e4  lea rdi, [rsp]
00007dd052fd62e8  mov esi, 0x00
00007dd052fd62ed  mov rax, 0x61D0404B9530
00007dd052fd62f7  call rax
00007dd052fd62f9  movaps xmm10, [rsp]
00007dd052fd62fe  add rsp, 0x30
00007dd052fd6302  vmovaps xmm0, [rsp]
00007dd052fd6307  vmovaps xmm1, [rsp+0x10]
00007dd052fd630d  vmovaps xmm2, [rsp+0x20]
00007dd052fd6313  vmovaps xmm3, [rsp+0x30]
00007dd052fd6319  vmovaps xmm4, [rsp+0x40]
00007dd052fd631f  vmovaps xmm5, [rsp+0x50]
00007dd052fd6325  vmovaps xmm6, [rsp+0x60]
00007dd052fd632b  vmovaps xmm7, [rsp+0x70]
00007dd052fd6331  vmovaps xmm8, [rsp+0x80]
00007dd052fd633a  vmovaps xmm9, [rsp+0x90]
00007dd052fd6343  vmovaps xmm11, [rsp+0xA0]
00007dd052fd634c  vmovaps xmm12, [rsp+0xB0]
00007dd052fd6355  vmovaps xmm13, [rsp+0xC0]
00007dd052fd635e  vmovaps xmm14, [rsp+0xD0]
00007dd052fd6367  vmovaps xmm15, [rsp+0xE0]
00007dd052fd6370  add rsp, 0xF0
00007dd052fd6377  pop r11
00007dd052fd6379  pop r10
00007dd052fd637b  pop r9
00007dd052fd637d  pop r8
00007dd052fd637f  pop rsi
00007dd052fd6380  pop rdi
00007dd052fd6381  pop rdx
00007dd052fd6382  pop rcx
00007dd052fd6383  pop rax
00007dd052fd6384  add rsp, 0x08
00007dd052fd6388  jmp 0x00007DD052FD30B6
00007dd052fd638d  sub rsp, 0x08
00007dd052fd6391  push rax
00007dd052fd6392  push rcx
00007dd052fd6393  push rdx
00007dd052fd6394  push rdi
00007dd052fd6395  push rsi
00007dd052fd6396  push r8
00007dd052fd6398  push r9
00007dd052fd639a  push r10
00007dd052fd639c  push r11
00007dd052fd639e  sub rsp, 0xF0
00007dd052fd63a5  vmovaps [rsp], xmm0
00007dd052fd63aa  vmovaps [rsp+0x10], xmm1
00007dd052fd63b0  vmovaps [rsp+0x20], xmm2
00007dd052fd63b6  vmovaps [rsp+0x30], xmm3
00007dd052fd63bc  vmovaps [rsp+0x40], xmm4
00007dd052fd63c2  vmovaps [rsp+0x50], xmm5
00007dd052fd63c8  vmovaps [rsp+0x60], xmm6
00007dd052fd63ce  vmovaps [rsp+0x70], xmm7
00007dd052fd63d4  vmovaps [rsp+0x80], xmm8
00007dd052fd63dd  vmovaps [rsp+0x90], xmm9
00007dd052fd63e6  vmovaps [rsp+0xA0], xmm10
00007dd052fd63ef  vmovaps [rsp+0xB0], xmm12
00007dd052fd63f8  vmovaps [rsp+0xC0], xmm13
00007dd052fd6401  vmovaps [rsp+0xD0], xmm14
00007dd052fd640a  vmovaps [rsp+0xE0], xmm15
00007dd052fd6413  sub rsp, 0x30
00007dd052fd6417  movaps [rsp], xmm11
00007dd052fd641c  movaps [rsp+0x10], xmm2
00007dd052fd6421  movaps [rsp+0x20], xmm1
00007dd052fd6426  lea rdi, [rsp]
00007dd052fd642a  mov esi, 0x00
00007dd052fd642f  mov rax, 0x61D0404B9530
00007dd052fd6439  call rax
00007dd052fd643b  movaps xmm11, [rsp]
00007dd052fd6440  add rsp, 0x30
00007dd052fd6444  vmovaps xmm0, [rsp]
00007dd052fd6449  vmovaps xmm1, [rsp+0x10]
00007dd052fd644f  vmovaps xmm2, [rsp+0x20]
00007dd052fd6455  vmovaps xmm3, [rsp+0x30]
00007dd052fd645b  vmovaps xmm4, [rsp+0x40]
00007dd052fd6461  vmovaps xmm5, [rsp+0x50]
00007dd052fd6467  vmovaps xmm6, [rsp+0x60]
00007dd052fd646d  vmovaps xmm7, [rsp+0x70]
00007dd052fd6473  vmovaps xmm8, [rsp+0x80]
00007dd052fd647c  vmovaps xmm9, [rsp+0x90]
00007dd052fd6485  vmovaps xmm10, [rsp+0xA0]
00007dd052fd648e  vmovaps xmm12, [rsp+0xB0]
00007dd052fd6497  vmovaps xmm13, [rsp+0xC0]
00007dd052fd64a0  vmovaps xmm14, [rsp+0xD0]
00007dd052fd64a9  vmovaps xmm15, [rsp+0xE0]
00007dd052fd64b2  add rsp, 0xF0
00007dd052fd64b9  pop r11
00007dd052fd64bb  pop r10
00007dd052fd64bd  pop r9
00007dd052fd64bf  pop r8
00007dd052fd64c1  pop rsi
00007dd052fd64c2  pop rdi
00007dd052fd64c3  pop rdx
00007dd052fd64c4  pop rcx
00007dd052fd64c5  pop rax
00007dd052fd64c6  add rsp, 0x08
00007dd052fd64ca  jmp 0x00007DD052FD30F2
00007dd052fd64cf  sub rsp, 0x08
00007dd052fd64d3  push rax
00007dd052fd64d4  push rcx
00007dd052fd64d5  push rdx
00007dd052fd64d6  push rdi
00007dd052fd64d7  push rsi
00007dd052fd64d8  push r8
00007dd052fd64da  push r9
00007dd052fd64dc  push r10
00007dd052fd64de  push r11
00007dd052fd64e0  sub rsp, 0xF0
00007dd052fd64e7  vmovaps [rsp], xmm0
00007dd052fd64ec  vmovaps [rsp+0x10], xmm2
00007dd052fd64f2  vmovaps [rsp+0x20], xmm3
00007dd052fd64f8  vmovaps [rsp+0x30], xmm4
00007dd052fd64fe  vmovaps [rsp+0x40], xmm5
00007dd052fd6504  vmovaps [rsp+0x50], xmm6
00007dd052fd650a  vmovaps [rsp+0x60], xmm7
00007dd052fd6510  vmovaps [rsp+0x70], xmm8
00007dd052fd6516  vmovaps [rsp+0x80], xmm9
00007dd052fd651f  vmovaps [rsp+0x90], xmm10
00007dd052fd6528  vmovaps [rsp+0xA0], xmm11
00007dd052fd6531  vmovaps [rsp+0xB0], xmm12
00007dd052fd653a  vmovaps [rsp+0xC0], xmm13
00007dd052fd6543  vmovaps [rsp+0xD0], xmm14
00007dd052fd654c  vmovaps [rsp+0xE0], xmm15
00007dd052fd6555  sub rsp, 0x30
00007dd052fd6559  movaps [rsp], xmm1
00007dd052fd655d  movaps [rsp+0x10], xmm14
00007dd052fd6563  movaps [rsp+0x20], xmm6
00007dd052fd6568  lea rdi, [rsp]
00007dd052fd656c  mov esi, 0x00
00007dd052fd6571  mov rax, 0x61D0404B9530
00007dd052fd657b  call rax
00007dd052fd657d  movaps xmm1, [rsp]
00007dd052fd6581  add rsp, 0x30
00007dd052fd6585  vmovaps xmm0, [rsp]
00007dd052fd658a  vmovaps xmm2, [rsp+0x10]
00007dd052fd6590  vmovaps xmm3, [rsp+0x20]
00007dd052fd6596  vmovaps xmm4, [rsp+0x30]
00007dd052fd659c  vmovaps xmm5, [rsp+0x40]
00007dd052fd65a2  vmovaps xmm6, [rsp+0x50]
00007dd052fd65a8  vmovaps xmm7, [rsp+0x60]
00007dd052fd65ae  vmovaps xmm8, [rsp+0x70]
00007dd052fd65b4  vmovaps xmm9, [rsp+0x80]
00007dd052fd65bd  vmovaps xmm10, [rsp+0x90]
00007dd052fd65c6  vmovaps xmm11, [rsp+0xA0]
00007dd052fd65cf  vmovaps xmm12, [rsp+0xB0]
00007dd052fd65d8  vmovaps xmm13, [rsp+0xC0]
00007dd052fd65e1  vmovaps xmm14, [rsp+0xD0]
00007dd052fd65ea  vmovaps xmm15, [rsp+0xE0]
00007dd052fd65f3  add rsp, 0xF0
00007dd052fd65fa  pop r11
00007dd052fd65fc  pop r10
00007dd052fd65fe  pop r9
00007dd052fd6600  pop r8
00007dd052fd6602  pop rsi
00007dd052fd6603  pop rdi
00007dd052fd6604  pop rdx
00007dd052fd6605  pop rcx
00007dd052fd6606  pop rax
00007dd052fd6607  add rsp, 0x08
00007dd052fd660b  jmp 0x00007DD052FD310B
00007dd052fd6610  sub rsp, 0x08
00007dd052fd6614  push rax
00007dd052fd6615  push rcx
00007dd052fd6616  push rdx
00007dd052fd6617  push rdi
00007dd052fd6618  push rsi
00007dd052fd6619  push r8
00007dd052fd661b  push r9
00007dd052fd661d  push r10
00007dd052fd661f  push r11
00007dd052fd6621  sub rsp, 0xF0
00007dd052fd6628  vmovaps [rsp], xmm0
00007dd052fd662d  vmovaps [rsp+0x10], xmm1
00007dd052fd6633  vmovaps [rsp+0x20], xmm2
00007dd052fd6639  vmovaps [rsp+0x30], xmm3
00007dd052fd663f  vmovaps [rsp+0x40], xmm4
00007dd052fd6645  vmovaps [rsp+0x50], xmm5
00007dd052fd664b  vmovaps [rsp+0x60], xmm6
00007dd052fd6651  vmovaps [rsp+0x70], xmm7
00007dd052fd6657  vmovaps [rsp+0x80], xmm8
00007dd052fd6660  vmovaps [rsp+0x90], xmm9
00007dd052fd6669  vmovaps [rsp+0xA0], xmm10
00007dd052fd6672  vmovaps [rsp+0xB0], xmm11
00007dd052fd667b  vmovaps [rsp+0xC0], xmm12
00007dd052fd6684  vmovaps [rsp+0xD0], xmm13
00007dd052fd668d  vmovaps [rsp+0xE0], xmm14
00007dd052fd6696  sub rsp, 0x30
00007dd052fd669a  movaps [rsp], xmm15
00007dd052fd669f  movaps [rsp+0x10], xmm14
00007dd052fd66a5  movaps [rsp+0x20], xmm5
00007dd052fd66aa  lea rdi, [rsp]
00007dd052fd66ae  mov esi, 0x00
00007dd052fd66b3  mov rax, 0x61D0404B9530
00007dd052fd66bd  call rax
00007dd052fd66bf  movaps xmm15, [rsp]
00007dd052fd66c4  add rsp, 0x30
00007dd052fd66c8  vmovaps xmm0, [rsp]
00007dd052fd66cd  vmovaps xmm1, [rsp+0x10]
00007dd052fd66d3  vmovaps xmm2, [rsp+0x20]
00007dd052fd66d9  vmovaps xmm3, [rsp+0x30]
00007dd052fd66df  vmovaps xmm4, [rsp+0x40]
00007dd052fd66e5  vmovaps xmm5, [rsp+0x50]
00007dd052fd66eb  vmovaps xmm6, [rsp+0x60]
00007dd052fd66f1  vmovaps xmm7, [rsp+0x70]
00007dd052fd66f7  vmovaps xmm8, [rsp+0x80]
00007dd052fd6700  vmovaps xmm9, [rsp+0x90]
00007dd052fd6709  vmovaps xmm10, [rsp+0xA0]
00007dd052fd6712  vmovaps xmm11, [rsp+0xB0]
00007dd052fd671b  vmovaps xmm12, [rsp+0xC0]
00007dd052fd6724  vmovaps xmm13, [rsp+0xD0]
00007dd052fd672d  vmovaps xmm14, [rsp+0xE0]
00007dd052fd6736  add rsp, 0xF0
00007dd052fd673d  pop r11
00007dd052fd673f  pop r10
00007dd052fd6741  pop r9
00007dd052fd6743  pop r8
00007dd052fd6745  pop rsi
00007dd052fd6746  pop rdi
00007dd052fd6747  pop rdx
00007dd052fd6748  pop rcx
00007dd052fd6749  pop rax
00007dd052fd674a  add rsp, 0x08
00007dd052fd674e  jmp 0x00007DD052FD312B
00007dd052fd6753  sub rsp, 0x08
00007dd052fd6757  push rax
00007dd052fd6758  push rcx
00007dd052fd6759  push rdx
00007dd052fd675a  push rdi
00007dd052fd675b  push rsi
00007dd052fd675c  push r8
00007dd052fd675e  push r9
00007dd052fd6760  push r10
00007dd052fd6762  push r11
00007dd052fd6764  sub rsp, 0xF0
00007dd052fd676b  vmovaps [rsp], xmm0
00007dd052fd6770  vmovaps [rsp+0x10], xmm1
00007dd052fd6776  vmovaps [rsp+0x20], xmm2
00007dd052fd677c  vmovaps [rsp+0x30], xmm3
00007dd052fd6782  vmovaps [rsp+0x40], xmm4
00007dd052fd6788  vmovaps [rsp+0x50], xmm5
00007dd052fd678e  vmovaps [rsp+0x60], xmm7
00007dd052fd6794  vmovaps [rsp+0x70], xmm8
00007dd052fd679a  vmovaps [rsp+0x80], xmm9
00007dd052fd67a3  vmovaps [rsp+0x90], xmm10
00007dd052fd67ac  vmovaps [rsp+0xA0], xmm11
00007dd052fd67b5  vmovaps [rsp+0xB0], xmm12
00007dd052fd67be  vmovaps [rsp+0xC0], xmm13
00007dd052fd67c7  vmovaps [rsp+0xD0], xmm14
00007dd052fd67d0  vmovaps [rsp+0xE0], xmm15
00007dd052fd67d9  sub rsp, 0x30
00007dd052fd67dd  movaps [rsp], xmm6
00007dd052fd67e1  movaps [rsp+0x10], xmm9
00007dd052fd67e7  movaps [rsp+0x20], xmm14
00007dd052fd67ed  lea rdi, [rsp]
00007dd052fd67f1  mov esi, 0x00
00007dd052fd67f6  mov rax, 0x61D0404B9530
00007dd052fd6800  call rax
00007dd052fd6802  movaps xmm6, [rsp]
00007dd052fd6806  add rsp, 0x30
00007dd052fd680a  vmovaps xmm0, [rsp]
00007dd052fd680f  vmovaps xmm1, [rsp+0x10]
00007dd052fd6815  vmovaps xmm2, [rsp+0x20]
00007dd052fd681b  vmovaps xmm3, [rsp+0x30]
00007dd052fd6821  vmovaps xmm4, [rsp+0x40]
00007dd052fd6827  vmovaps xmm5, [rsp+0x50]
00007dd052fd682d  vmovaps xmm7, [rsp+0x60]
00007dd052fd6833  vmovaps xmm8, [rsp+0x70]
00007dd052fd6839  vmovaps xmm9, [rsp+0x80]
00007dd052fd6842  vmovaps xmm10, [rsp+0x90]
00007dd052fd684b  vmovaps xmm11, [rsp+0xA0]
00007dd052fd6854  vmovaps xmm12, [rsp+0xB0]
00007dd052fd685d  vmovaps xmm13, [rsp+0xC0]
00007dd052fd6866  vmovaps xmm14, [rsp+0xD0]
00007dd052fd686f  vmovaps xmm15, [rsp+0xE0]
00007dd052fd6878  add rsp, 0xF0
00007dd052fd687f  pop r11
00007dd052fd6881  pop r10
00007dd052fd6883  pop r9
00007dd052fd6885  pop r8
00007dd052fd6887  pop rsi
00007dd052fd6888  pop rdi
00007dd052fd6889  pop rdx
00007dd052fd688a  pop rcx
00007dd052fd688b  pop rax
00007dd052fd688c  add rsp, 0x08
00007dd052fd6890  jmp 0x00007DD052FD3153
00007dd052fd6895  sub rsp, 0x08
00007dd052fd6899  push rax
00007dd052fd689a  push rcx
00007dd052fd689b  push rdx
00007dd052fd689c  push rdi
00007dd052fd689d  push rsi
00007dd052fd689e  push r8
00007dd052fd68a0  push r9
00007dd052fd68a2  push r10
00007dd052fd68a4  push r11
00007dd052fd68a6  sub rsp, 0xF0
00007dd052fd68ad  vmovaps [rsp], xmm0
00007dd052fd68b2  vmovaps [rsp+0x10], xmm1
00007dd052fd68b8  vmovaps [rsp+0x20], xmm2
00007dd052fd68be  vmovaps [rsp+0x30], xmm3
00007dd052fd68c4  vmovaps [rsp+0x40], xmm4
00007dd052fd68ca  vmovaps [rsp+0x50], xmm5
00007dd052fd68d0  vmovaps [rsp+0x60], xmm6
00007dd052fd68d6  vmovaps [rsp+0x70], xmm7
00007dd052fd68dc  vmovaps [rsp+0x80], xmm8
00007dd052fd68e5  vmovaps [rsp+0x90], xmm9
00007dd052fd68ee  vmovaps [rsp+0xA0], xmm10
00007dd052fd68f7  vmovaps [rsp+0xB0], xmm11
00007dd052fd6900  vmovaps [rsp+0xC0], xmm12
00007dd052fd6909  vmovaps [rsp+0xD0], xmm13
00007dd052fd6912  vmovaps [rsp+0xE0], xmm15
00007dd052fd691b  sub rsp, 0x30
00007dd052fd691f  movaps [rsp], xmm14
00007dd052fd6924  movaps [rsp+0x10], xmm9
00007dd052fd692a  movaps [rsp+0x20], xmm13
00007dd052fd6930  lea rdi, [rsp]
00007dd052fd6934  mov esi, 0x00
00007dd052fd6939  mov rax, 0x61D0404B9530
00007dd052fd6943  call rax
00007dd052fd6945  movaps xmm14, [rsp]
00007dd052fd694a  add rsp, 0x30
00007dd052fd694e  vmovaps xmm0, [rsp]
00007dd052fd6953  vmovaps xmm1, [rsp+0x10]
00007dd052fd6959  vmovaps xmm2, [rsp+0x20]
00007dd052fd695f  vmovaps xmm3, [rsp+0x30]
00007dd052fd6965  vmovaps xmm4, [rsp+0x40]
00007dd052fd696b  vmovaps xmm5, [rsp+0x50]
00007dd052fd6971  vmovaps xmm6, [rsp+0x60]
00007dd052fd6977  vmovaps xmm7, [rsp+0x70]
00007dd052fd697d  vmovaps xmm8, [rsp+0x80]
00007dd052fd6986  vmovaps xmm9, [rsp+0x90]
00007dd052fd698f  vmovaps xmm10, [rsp+0xA0]
00007dd052fd6998  vmovaps xmm11, [rsp+0xB0]
00007dd052fd69a1  vmovaps xmm12, [rsp+0xC0]
00007dd052fd69aa  vmovaps xmm13, [rsp+0xD0]
00007dd052fd69b3  vmovaps xmm15, [rsp+0xE0]
00007dd052fd69bc  add rsp, 0xF0
00007dd052fd69c3  pop r11
00007dd052fd69c5  pop r10
00007dd052fd69c7  pop r9
00007dd052fd69c9  pop r8
00007dd052fd69cb  pop rsi
00007dd052fd69cc  pop rdi
00007dd052fd69cd  pop rdx
00007dd052fd69ce  pop rcx
00007dd052fd69cf  pop rax
00007dd052fd69d0  add rsp, 0x08
00007dd052fd69d4  jmp 0x00007DD052FD3176
00007dd052fd69d9  sub rsp, 0x08
00007dd052fd69dd  push rax
00007dd052fd69de  push rcx
00007dd052fd69df  push rdx
00007dd052fd69e0  push rdi
00007dd052fd69e1  push rsi
00007dd052fd69e2  push r8
00007dd052fd69e4  push r9
00007dd052fd69e6  push r10
00007dd052fd69e8  push r11
00007dd052fd69ea  sub rsp, 0xF0
00007dd052fd69f1  vmovaps [rsp], xmm0
00007dd052fd69f6  vmovaps [rsp+0x10], xmm1
00007dd052fd69fc  vmovaps [rsp+0x20], xmm2
00007dd052fd6a02  vmovaps [rsp+0x30], xmm3
00007dd052fd6a08  vmovaps [rsp+0x40], xmm4
00007dd052fd6a0e  vmovaps [rsp+0x50], xmm5
00007dd052fd6a14  vmovaps [rsp+0x60], xmm6
00007dd052fd6a1a  vmovaps [rsp+0x70], xmm7
00007dd052fd6a20  vmovaps [rsp+0x80], xmm8
00007dd052fd6a29  vmovaps [rsp+0x90], xmm9
00007dd052fd6a32  vmovaps [rsp+0xA0], xmm10
00007dd052fd6a3b  vmovaps [rsp+0xB0], xmm11
00007dd052fd6a44  vmovaps [rsp+0xC0], xmm12
00007dd052fd6a4d  vmovaps [rsp+0xD0], xmm14
00007dd052fd6a56  vmovaps [rsp+0xE0], xmm15
00007dd052fd6a5f  sub rsp, 0x30
00007dd052fd6a63  movaps [rsp], xmm13
00007dd052fd6a68  movaps [rsp+0x10], xmm9
00007dd052fd6a6e  movaps [rsp+0x20], xmm10
00007dd052fd6a74  lea rdi, [rsp]
00007dd052fd6a78  mov esi, 0x00
00007dd052fd6a7d  mov rax, 0x61D0404B9530
00007dd052fd6a87  call rax
00007dd052fd6a89  movaps xmm13, [rsp]
00007dd052fd6a8e  add rsp, 0x30
00007dd052fd6a92  vmovaps xmm0, [rsp]
00007dd052fd6a97  vmovaps xmm1, [rsp+0x10]
00007dd052fd6a9d  vmovaps xmm2, [rsp+0x20]
00007dd052fd6aa3  vmovaps xmm3, [rsp+0x30]
00007dd052fd6aa9  vmovaps xmm4, [rsp+0x40]
00007dd052fd6aaf  vmovaps xmm5, [rsp+0x50]
00007dd052fd6ab5  vmovaps xmm6, [rsp+0x60]
00007dd052fd6abb  vmovaps xmm7, [rsp+0x70]
00007dd052fd6ac1  vmovaps xmm8, [rsp+0x80]
00007dd052fd6aca  vmovaps xmm9, [rsp+0x90]
00007dd052fd6ad3  vmovaps xmm10, [rsp+0xA0]
00007dd052fd6adc  vmovaps xmm11, [rsp+0xB0]
00007dd052fd6ae5  vmovaps xmm12, [rsp+0xC0]
00007dd052fd6aee  vmovaps xmm14, [rsp+0xD0]
00007dd052fd6af7  vmovaps xmm15, [rsp+0xE0]
00007dd052fd6b00  add rsp, 0xF0
00007dd052fd6b07  pop r11
00007dd052fd6b09  pop r10
00007dd052fd6b0b  pop r9
00007dd052fd6b0d  pop r8
00007dd052fd6b0f  pop rsi
00007dd052fd6b10  pop rdi
00007dd052fd6b11  pop rdx
00007dd052fd6b12  pop rcx
00007dd052fd6b13  pop rax
00007dd052fd6b14  add rsp, 0x08
00007dd052fd6b18  jmp 0x00007DD052FD3196
00007dd052fd6b1d  call 0x00007DD052E0AFE0
00007dd052fd6b22  jmp 0x00007DD052FD31EB
00007dd052fd6b27  sub rsp, 0x08
00007dd052fd6b2b  push rax
00007dd052fd6b2c  push rcx
00007dd052fd6b2d  push rdx
00007dd052fd6b2e  push rdi
00007dd052fd6b2f  push rsi
00007dd052fd6b30  push r8
00007dd052fd6b32  push r9
00007dd052fd6b34  push r10
00007dd052fd6b36  push r11
00007dd052fd6b38  sub rsp, 0xF0
00007dd052fd6b3f  vmovaps [rsp], xmm0
00007dd052fd6b44  vmovaps [rsp+0x10], xmm1
00007dd052fd6b4a  vmovaps [rsp+0x20], xmm2
00007dd052fd6b50  vmovaps [rsp+0x30], xmm3
00007dd052fd6b56  vmovaps [rsp+0x40], xmm4
00007dd052fd6b5c  vmovaps [rsp+0x50], xmm5
00007dd052fd6b62  vmovaps [rsp+0x60], xmm6
00007dd052fd6b68  vmovaps [rsp+0x70], xmm7
00007dd052fd6b6e  vmovaps [rsp+0x80], xmm8
00007dd052fd6b77  vmovaps [rsp+0x90], xmm10
00007dd052fd6b80  vmovaps [rsp+0xA0], xmm11
00007dd052fd6b89  vmovaps [rsp+0xB0], xmm12
00007dd052fd6b92  vmovaps [rsp+0xC0], xmm13
00007dd052fd6b9b  vmovaps [rsp+0xD0], xmm14
00007dd052fd6ba4  vmovaps [rsp+0xE0], xmm15
00007dd052fd6bad  sub rsp, 0x30
00007dd052fd6bb1  movaps [rsp], xmm9
00007dd052fd6bb6  movaps [rsp+0x10], xmm8
00007dd052fd6bbc  movaps [rsp+0x20], xmm10
00007dd052fd6bc2  lea rdi, [rsp]
00007dd052fd6bc6  mov esi, 0x00
00007dd052fd6bcb  mov rax, 0x61D0404B9530
00007dd052fd6bd5  call rax
00007dd052fd6bd7  movaps xmm9, [rsp]
00007dd052fd6bdc  add rsp, 0x30
00007dd052fd6be0  vmovaps xmm0, [rsp]
00007dd052fd6be5  vmovaps xmm1, [rsp+0x10]
00007dd052fd6beb  vmovaps xmm2, [rsp+0x20]
00007dd052fd6bf1  vmovaps xmm3, [rsp+0x30]
00007dd052fd6bf7  vmovaps xmm4, [rsp+0x40]
00007dd052fd6bfd  vmovaps xmm5, [rsp+0x50]
00007dd052fd6c03  vmovaps xmm6, [rsp+0x60]
00007dd052fd6c09  vmovaps xmm7, [rsp+0x70]
00007dd052fd6c0f  vmovaps xmm8, [rsp+0x80]
00007dd052fd6c18  vmovaps xmm10, [rsp+0x90]
00007dd052fd6c21  vmovaps xmm11, [rsp+0xA0]
00007dd052fd6c2a  vmovaps xmm12, [rsp+0xB0]
00007dd052fd6c33  vmovaps xmm13, [rsp+0xC0]
00007dd052fd6c3c  vmovaps xmm14, [rsp+0xD0]
00007dd052fd6c45  vmovaps xmm15, [rsp+0xE0]
00007dd052fd6c4e  add rsp, 0xF0
00007dd052fd6c55  pop r11
00007dd052fd6c57  pop r10
00007dd052fd6c59  pop r9
00007dd052fd6c5b  pop r8
00007dd052fd6c5d  pop rsi
00007dd052fd6c5e  pop rdi
00007dd052fd6c5f  pop rdx
00007dd052fd6c60  pop rcx
00007dd052fd6c61  pop rax
00007dd052fd6c62  add rsp, 0x08
00007dd052fd6c66  jmp 0x00007DD052FD321C
00007dd052fd6c6b  sub rsp, 0x08
00007dd052fd6c6f  push rax
00007dd052fd6c70  push rcx
00007dd052fd6c71  push rdx
00007dd052fd6c72  push rdi
00007dd052fd6c73  push rsi
00007dd052fd6c74  push r8
00007dd052fd6c76  push r9
00007dd052fd6c78  push r10
00007dd052fd6c7a  push r11
00007dd052fd6c7c  sub rsp, 0xF0
00007dd052fd6c83  vmovaps [rsp], xmm0
00007dd052fd6c88  vmovaps [rsp+0x10], xmm1
00007dd052fd6c8e  vmovaps [rsp+0x20], xmm2
00007dd052fd6c94  vmovaps [rsp+0x30], xmm3
00007dd052fd6c9a  vmovaps [rsp+0x40], xmm4
00007dd052fd6ca0  vmovaps [rsp+0x50], xmm5
00007dd052fd6ca6  vmovaps [rsp+0x60], xmm6
00007dd052fd6cac  vmovaps [rsp+0x70], xmm7
00007dd052fd6cb2  vmovaps [rsp+0x80], xmm8
00007dd052fd6cbb  vmovaps [rsp+0x90], xmm9
00007dd052fd6cc4  vmovaps [rsp+0xA0], xmm11
00007dd052fd6ccd  vmovaps [rsp+0xB0], xmm12
00007dd052fd6cd6  vmovaps [rsp+0xC0], xmm13
00007dd052fd6cdf  vmovaps [rsp+0xD0], xmm14
00007dd052fd6ce8  vmovaps [rsp+0xE0], xmm15
00007dd052fd6cf1  sub rsp, 0x30
00007dd052fd6cf5  movaps [rsp], xmm10
00007dd052fd6cfa  movaps [rsp+0x10], xmm1
00007dd052fd6cff  movaps [rsp+0x20], xmm11
00007dd052fd6d05  lea rdi, [rsp]
00007dd052fd6d09  mov esi, 0x00
00007dd052fd6d0e  mov rax, 0x61D0404B9530
00007dd052fd6d18  call rax
00007dd052fd6d1a  movaps xmm10, [rsp]
00007dd052fd6d1f  add rsp, 0x30
00007dd052fd6d23  vmovaps xmm0, [rsp]
00007dd052fd6d28  vmovaps xmm1, [rsp+0x10]
00007dd052fd6d2e  vmovaps xmm2, [rsp+0x20]
00007dd052fd6d34  vmovaps xmm3, [rsp+0x30]
00007dd052fd6d3a  vmovaps xmm4, [rsp+0x40]
00007dd052fd6d40  vmovaps xmm5, [rsp+0x50]
00007dd052fd6d46  vmovaps xmm6, [rsp+0x60]
00007dd052fd6d4c  vmovaps xmm7, [rsp+0x70]
00007dd052fd6d52  vmovaps xmm8, [rsp+0x80]
00007dd052fd6d5b  vmovaps xmm9, [rsp+0x90]
00007dd052fd6d64  vmovaps xmm11, [rsp+0xA0]
00007dd052fd6d6d  vmovaps xmm12, [rsp+0xB0]
00007dd052fd6d76  vmovaps xmm13, [rsp+0xC0]
00007dd052fd6d7f  vmovaps xmm14, [rsp+0xD0]
00007dd052fd6d88  vmovaps xmm15, [rsp+0xE0]
00007dd052fd6d91  add rsp, 0xF0
00007dd052fd6d98  pop r11
00007dd052fd6d9a  pop r10
00007dd052fd6d9c  pop r9
00007dd052fd6d9e  pop r8
00007dd052fd6da0  pop rsi
00007dd052fd6da1  pop rdi
00007dd052fd6da2  pop rdx
00007dd052fd6da3  pop rcx
00007dd052fd6da4  pop rax
00007dd052fd6da5  add rsp, 0x08
00007dd052fd6da9  jmp 0x00007DD052FD3237
00007dd052fd6dae  sub rsp, 0x08
00007dd052fd6db2  push rax
00007dd052fd6db3  push rcx
00007dd052fd6db4  push rdx
00007dd052fd6db5  push rdi
00007dd052fd6db6  push rsi
00007dd052fd6db7  push r8
00007dd052fd6db9  push r9
00007dd052fd6dbb  push r10
00007dd052fd6dbd  push r11
00007dd052fd6dbf  sub rsp, 0xF0
00007dd052fd6dc6  vmovaps [rsp], xmm0
00007dd052fd6dcb  vmovaps [rsp+0x10], xmm2
00007dd052fd6dd1  vmovaps [rsp+0x20], xmm3
00007dd052fd6dd7  vmovaps [rsp+0x30], xmm4
00007dd052fd6ddd  vmovaps [rsp+0x40], xmm5
00007dd052fd6de3  vmovaps [rsp+0x50], xmm6
00007dd052fd6de9  vmovaps [rsp+0x60], xmm7
00007dd052fd6def  vmovaps [rsp+0x70], xmm8
00007dd052fd6df5  vmovaps [rsp+0x80], xmm9
00007dd052fd6dfe  vmovaps [rsp+0x90], xmm10
00007dd052fd6e07  vmovaps [rsp+0xA0], xmm11
00007dd052fd6e10  vmovaps [rsp+0xB0], xmm12
00007dd052fd6e19  vmovaps [rsp+0xC0], xmm13
00007dd052fd6e22  vmovaps [rsp+0xD0], xmm14
00007dd052fd6e2b  vmovaps [rsp+0xE0], xmm15
00007dd052fd6e34  sub rsp, 0x30
00007dd052fd6e38  movaps [rsp], xmm1
00007dd052fd6e3c  movaps [rsp+0x10], xmm15
00007dd052fd6e42  movaps [rsp+0x20], xmm6
00007dd052fd6e47  lea rdi, [rsp]
00007dd052fd6e4b  mov esi, 0x00
00007dd052fd6e50  mov rax, 0x61D0404B9530
00007dd052fd6e5a  call rax
00007dd052fd6e5c  movaps xmm1, [rsp]
00007dd052fd6e60  add rsp, 0x30
00007dd052fd6e64  vmovaps xmm0, [rsp]
00007dd052fd6e69  vmovaps xmm2, [rsp+0x10]
00007dd052fd6e6f  vmovaps xmm3, [rsp+0x20]
00007dd052fd6e75  vmovaps xmm4, [rsp+0x30]
00007dd052fd6e7b  vmovaps xmm5, [rsp+0x40]
00007dd052fd6e81  vmovaps xmm6, [rsp+0x50]
00007dd052fd6e87  vmovaps xmm7, [rsp+0x60]
00007dd052fd6e8d  vmovaps xmm8, [rsp+0x70]
00007dd052fd6e93  vmovaps xmm9, [rsp+0x80]
00007dd052fd6e9c  vmovaps xmm10, [rsp+0x90]
00007dd052fd6ea5  vmovaps xmm11, [rsp+0xA0]
00007dd052fd6eae  vmovaps xmm12, [rsp+0xB0]
00007dd052fd6eb7  vmovaps xmm13, [rsp+0xC0]
00007dd052fd6ec0  vmovaps xmm14, [rsp+0xD0]
00007dd052fd6ec9  vmovaps xmm15, [rsp+0xE0]
00007dd052fd6ed2  add rsp, 0xF0
00007dd052fd6ed9  pop r11
00007dd052fd6edb  pop r10
00007dd052fd6edd  pop r9
00007dd052fd6edf  pop r8
00007dd052fd6ee1  pop rsi
00007dd052fd6ee2  pop rdi
00007dd052fd6ee3  pop rdx
00007dd052fd6ee4  pop rcx
00007dd052fd6ee5  pop rax
00007dd052fd6ee6  add rsp, 0x08
00007dd052fd6eea  jmp 0x00007DD052FD3250
00007dd052fd6eef  sub rsp, 0x08
00007dd052fd6ef3  push rax
00007dd052fd6ef4  push rcx
00007dd052fd6ef5  push rdx
00007dd052fd6ef6  push rdi
00007dd052fd6ef7  push rsi
00007dd052fd6ef8  push r8
00007dd052fd6efa  push r9
00007dd052fd6efc  push r10
00007dd052fd6efe  push r11
00007dd052fd6f00  sub rsp, 0xF0
00007dd052fd6f07  vmovaps [rsp], xmm0
00007dd052fd6f0c  vmovaps [rsp+0x10], xmm1
00007dd052fd6f12  vmovaps [rsp+0x20], xmm2
00007dd052fd6f18  vmovaps [rsp+0x30], xmm3
00007dd052fd6f1e  vmovaps [rsp+0x40], xmm4
00007dd052fd6f24  vmovaps [rsp+0x50], xmm5
00007dd052fd6f2a  vmovaps [rsp+0x60], xmm6
00007dd052fd6f30  vmovaps [rsp+0x70], xmm7
00007dd052fd6f36  vmovaps [rsp+0x80], xmm8
00007dd052fd6f3f  vmovaps [rsp+0x90], xmm9
00007dd052fd6f48  vmovaps [rsp+0xA0], xmm10
00007dd052fd6f51  vmovaps [rsp+0xB0], xmm12
00007dd052fd6f5a  vmovaps [rsp+0xC0], xmm13
00007dd052fd6f63  vmovaps [rsp+0xD0], xmm14
00007dd052fd6f6c  vmovaps [rsp+0xE0], xmm15
00007dd052fd6f75  sub rsp, 0x30
00007dd052fd6f79  movaps [rsp], xmm11
00007dd052fd6f7e  movaps [rsp+0x10], xmm12
00007dd052fd6f84  movaps [rsp+0x20], xmm15
00007dd052fd6f8a  lea rdi, [rsp]
00007dd052fd6f8e  mov esi, 0x00
00007dd052fd6f93  mov rax, 0x61D0404B9530
00007dd052fd6f9d  call rax
00007dd052fd6f9f  movaps xmm11, [rsp]
00007dd052fd6fa4  add rsp, 0x30
00007dd052fd6fa8  vmovaps xmm0, [rsp]
00007dd052fd6fad  vmovaps xmm1, [rsp+0x10]
00007dd052fd6fb3  vmovaps xmm2, [rsp+0x20]
00007dd052fd6fb9  vmovaps xmm3, [rsp+0x30]
00007dd052fd6fbf  vmovaps xmm4, [rsp+0x40]
00007dd052fd6fc5  vmovaps xmm5, [rsp+0x50]
00007dd052fd6fcb  vmovaps xmm6, [rsp+0x60]
00007dd052fd6fd1  vmovaps xmm7, [rsp+0x70]
00007dd052fd6fd7  vmovaps xmm8, [rsp+0x80]
00007dd052fd6fe0  vmovaps xmm9, [rsp+0x90]
00007dd052fd6fe9  vmovaps xmm10, [rsp+0xA0]
00007dd052fd6ff2  vmovaps xmm12, [rsp+0xB0]
00007dd052fd6ffb  vmovaps xmm13, [rsp+0xC0]
00007dd052fd7004  vmovaps xmm14, [rsp+0xD0]
00007dd052fd700d  vmovaps xmm15, [rsp+0xE0]
00007dd052fd7016  add rsp, 0xF0
00007dd052fd701d  pop r11
00007dd052fd701f  pop r10
00007dd052fd7021  pop r9
00007dd052fd7023  pop r8
00007dd052fd7025  pop rsi
00007dd052fd7026  pop rdi
00007dd052fd7027  pop rdx
00007dd052fd7028  pop rcx
00007dd052fd7029  pop rax
00007dd052fd702a  add rsp, 0x08
00007dd052fd702e  jmp 0x00007DD052FD327A
00007dd052fd7033  sub rsp, 0x08
00007dd052fd7037  push rax
00007dd052fd7038  push rcx
00007dd052fd7039  push rdx
00007dd052fd703a  push rdi
00007dd052fd703b  push rsi
00007dd052fd703c  push r8
00007dd052fd703e  push r9
00007dd052fd7040  push r10
00007dd052fd7042  push r11
00007dd052fd7044  sub rsp, 0xF0
00007dd052fd704b  vmovaps [rsp], xmm0
00007dd052fd7050  vmovaps [rsp+0x10], xmm1
00007dd052fd7056  vmovaps [rsp+0x20], xmm2
00007dd052fd705c  vmovaps [rsp+0x30], xmm3
00007dd052fd7062  vmovaps [rsp+0x40], xmm4
00007dd052fd7068  vmovaps [rsp+0x50], xmm5
00007dd052fd706e  vmovaps [rsp+0x60], xmm6
00007dd052fd7074  vmovaps [rsp+0x70], xmm7
00007dd052fd707a  vmovaps [rsp+0x80], xmm8
00007dd052fd7083  vmovaps [rsp+0x90], xmm9
00007dd052fd708c  vmovaps [rsp+0xA0], xmm10
00007dd052fd7095  vmovaps [rsp+0xB0], xmm11
00007dd052fd709e  vmovaps [rsp+0xC0], xmm13
00007dd052fd70a7  vmovaps [rsp+0xD0], xmm14
00007dd052fd70b0  vmovaps [rsp+0xE0], xmm15
00007dd052fd70b9  sub rsp, 0x30
00007dd052fd70bd  movaps [rsp], xmm12
00007dd052fd70c2  movaps [rsp+0x10], xmm8
00007dd052fd70c8  movaps [rsp+0x20], xmm15
00007dd052fd70ce  lea rdi, [rsp]
00007dd052fd70d2  mov esi, 0x00
00007dd052fd70d7  mov rax, 0x61D0404B9530
00007dd052fd70e1  call rax
00007dd052fd70e3  movaps xmm12, [rsp]
00007dd052fd70e8  add rsp, 0x30
00007dd052fd70ec  vmovaps xmm0, [rsp]
00007dd052fd70f1  vmovaps xmm1, [rsp+0x10]
00007dd052fd70f7  vmovaps xmm2, [rsp+0x20]
00007dd052fd70fd  vmovaps xmm3, [rsp+0x30]
00007dd052fd7103  vmovaps xmm4, [rsp+0x40]
00007dd052fd7109  vmovaps xmm5, [rsp+0x50]
00007dd052fd710f  vmovaps xmm6, [rsp+0x60]
00007dd052fd7115  vmovaps xmm7, [rsp+0x70]
00007dd052fd711b  vmovaps xmm8, [rsp+0x80]
00007dd052fd7124  vmovaps xmm9, [rsp+0x90]
00007dd052fd712d  vmovaps xmm10, [rsp+0xA0]
00007dd052fd7136  vmovaps xmm11, [rsp+0xB0]
00007dd052fd713f  vmovaps xmm13, [rsp+0xC0]
00007dd052fd7148  vmovaps xmm14, [rsp+0xD0]
00007dd052fd7151  vmovaps xmm15, [rsp+0xE0]
00007dd052fd715a  add rsp, 0xF0
00007dd052fd7161  pop r11
00007dd052fd7163  pop r10
00007dd052fd7165  pop r9
00007dd052fd7167  pop r8
00007dd052fd7169  pop rsi
00007dd052fd716a  pop rdi
00007dd052fd716b  pop rdx
00007dd052fd716c  pop rcx
00007dd052fd716d  pop rax
00007dd052fd716e  add rsp, 0x08
00007dd052fd7172  jmp 0x00007DD052FD32A9
00007dd052fd7177  sub rsp, 0x08
00007dd052fd717b  push rax
00007dd052fd717c  push rcx
00007dd052fd717d  push rdx
00007dd052fd717e  push rdi
00007dd052fd717f  push rsi
00007dd052fd7180  push r8
00007dd052fd7182  push r9
00007dd052fd7184  push r10
00007dd052fd7186  push r11
00007dd052fd7188  sub rsp, 0xF0
00007dd052fd718f  vmovaps [rsp], xmm0
00007dd052fd7194  vmovaps [rsp+0x10], xmm1
00007dd052fd719a  vmovaps [rsp+0x20], xmm2
00007dd052fd71a0  vmovaps [rsp+0x30], xmm3
00007dd052fd71a6  vmovaps [rsp+0x40], xmm4
00007dd052fd71ac  vmovaps [rsp+0x50], xmm5
00007dd052fd71b2  vmovaps [rsp+0x60], xmm6
00007dd052fd71b8  vmovaps [rsp+0x70], xmm7
00007dd052fd71be  vmovaps [rsp+0x80], xmm9
00007dd052fd71c7  vmovaps [rsp+0x90], xmm10
00007dd052fd71d0  vmovaps [rsp+0xA0], xmm11
00007dd052fd71d9  vmovaps [rsp+0xB0], xmm12
00007dd052fd71e2  vmovaps [rsp+0xC0], xmm13
00007dd052fd71eb  vmovaps [rsp+0xD0], xmm14
00007dd052fd71f4  vmovaps [rsp+0xE0], xmm15
00007dd052fd71fd  sub rsp, 0x30
00007dd052fd7201  movaps [rsp], xmm8
00007dd052fd7206  movaps [rsp+0x10], xmm7
00007dd052fd720b  movaps [rsp+0x20], xmm15
00007dd052fd7211  lea rdi, [rsp]
00007dd052fd7215  mov esi, 0x00
00007dd052fd721a  mov rax, 0x61D0404B9530
00007dd052fd7224  call rax
00007dd052fd7226  movaps xmm8, [rsp]
00007dd052fd722b  add rsp, 0x30
00007dd052fd722f  vmovaps xmm0, [rsp]
00007dd052fd7234  vmovaps xmm1, [rsp+0x10]
00007dd052fd723a  vmovaps xmm2, [rsp+0x20]
00007dd052fd7240  vmovaps xmm3, [rsp+0x30]
00007dd052fd7246  vmovaps xmm4, [rsp+0x40]
00007dd052fd724c  vmovaps xmm5, [rsp+0x50]
00007dd052fd7252  vmovaps xmm6, [rsp+0x60]
00007dd052fd7258  vmovaps xmm7, [rsp+0x70]
00007dd052fd725e  vmovaps xmm9, [rsp+0x80]
00007dd052fd7267  vmovaps xmm10, [rsp+0x90]
00007dd052fd7270  vmovaps xmm11, [rsp+0xA0]
00007dd052fd7279  vmovaps xmm12, [rsp+0xB0]
00007dd052fd7282  vmovaps xmm13, [rsp+0xC0]
00007dd052fd728b  vmovaps xmm14, [rsp+0xD0]
00007dd052fd7294  vmovaps xmm15, [rsp+0xE0]
00007dd052fd729d  add rsp, 0xF0
00007dd052fd72a4  pop r11
00007dd052fd72a6  pop r10
00007dd052fd72a8  pop r9
00007dd052fd72aa  pop r8
00007dd052fd72ac  pop rsi
00007dd052fd72ad  pop rdi
00007dd052fd72ae  pop rdx
00007dd052fd72af  pop rcx
00007dd052fd72b0  pop rax
00007dd052fd72b1  add rsp, 0x08
00007dd052fd72b5  jmp 0x00007DD052FD32CF
00007dd052fd72ba  sub rsp, 0x08
00007dd052fd72be  push rax
00007dd052fd72bf  push rcx
00007dd052fd72c0  push rdx
00007dd052fd72c1  push rdi
00007dd052fd72c2  push rsi
00007dd052fd72c3  push r8
00007dd052fd72c5  push r9
00007dd052fd72c7  push r10
00007dd052fd72c9  push r11
00007dd052fd72cb  sub rsp, 0xF0
00007dd052fd72d2  vmovaps [rsp], xmm0
00007dd052fd72d7  vmovaps [rsp+0x10], xmm1
00007dd052fd72dd  vmovaps [rsp+0x20], xmm2
00007dd052fd72e3  vmovaps [rsp+0x30], xmm3
00007dd052fd72e9  vmovaps [rsp+0x40], xmm4
00007dd052fd72ef  vmovaps [rsp+0x50], xmm5
00007dd052fd72f5  vmovaps [rsp+0x60], xmm6
00007dd052fd72fb  vmovaps [rsp+0x70], xmm7
00007dd052fd7301  vmovaps [rsp+0x80], xmm8
00007dd052fd730a  vmovaps [rsp+0x90], xmm9
00007dd052fd7313  vmovaps [rsp+0xA0], xmm10
00007dd052fd731c  vmovaps [rsp+0xB0], xmm11
00007dd052fd7325  vmovaps [rsp+0xC0], xmm12
00007dd052fd732e  vmovaps [rsp+0xD0], xmm13
00007dd052fd7337  vmovaps [rsp+0xE0], xmm14
00007dd052fd7340  sub rsp, 0x30
00007dd052fd7344  movaps [rsp], xmm15
00007dd052fd7349  movaps [rsp+0x10], xmm14
00007dd052fd734f  movaps [rsp+0x20], xmm9
00007dd052fd7355  lea rdi, [rsp]
00007dd052fd7359  mov esi, 0x00
00007dd052fd735e  mov rax, 0x61D0404B9530
00007dd052fd7368  call rax
00007dd052fd736a  movaps xmm15, [rsp]
00007dd052fd736f  add rsp, 0x30
00007dd052fd7373  vmovaps xmm0, [rsp]
00007dd052fd7378  vmovaps xmm1, [rsp+0x10]
00007dd052fd737e  vmovaps xmm2, [rsp+0x20]
00007dd052fd7384  vmovaps xmm3, [rsp+0x30]
00007dd052fd738a  vmovaps xmm4, [rsp+0x40]
00007dd052fd7390  vmovaps xmm5, [rsp+0x50]
00007dd052fd7396  vmovaps xmm6, [rsp+0x60]
00007dd052fd739c  vmovaps xmm7, [rsp+0x70]
00007dd052fd73a2  vmovaps xmm8, [rsp+0x80]
00007dd052fd73ab  vmovaps xmm9, [rsp+0x90]
00007dd052fd73b4  vmovaps xmm10, [rsp+0xA0]
00007dd052fd73bd  vmovaps xmm11, [rsp+0xB0]
00007dd052fd73c6  vmovaps xmm12, [rsp+0xC0]
00007dd052fd73cf  vmovaps xmm13, [rsp+0xD0]
00007dd052fd73d8  vmovaps xmm14, [rsp+0xE0]
00007dd052fd73e1  add rsp, 0xF0
00007dd052fd73e8  pop r11
00007dd052fd73ea  pop r10
00007dd052fd73ec  pop r9
00007dd052fd73ee  pop r8
00007dd052fd73f0  pop rsi
00007dd052fd73f1  pop rdi
00007dd052fd73f2  pop rdx
00007dd052fd73f3  pop rcx
00007dd052fd73f4  pop rax
00007dd052fd73f5  add rsp, 0x08
00007dd052fd73f9  jmp 0x00007DD052FD32E9
00007dd052fd73fe  sub rsp, 0x08
00007dd052fd7402  push rax
00007dd052fd7403  push rcx
00007dd052fd7404  push rdx
00007dd052fd7405  push rdi
00007dd052fd7406  push rsi
00007dd052fd7407  push r8
00007dd052fd7409  push r9
00007dd052fd740b  push r10
00007dd052fd740d  push r11
00007dd052fd740f  sub rsp, 0xF0
00007dd052fd7416  vmovaps [rsp], xmm0
00007dd052fd741b  vmovaps [rsp+0x10], xmm1
00007dd052fd7421  vmovaps [rsp+0x20], xmm2
00007dd052fd7427  vmovaps [rsp+0x30], xmm3
00007dd052fd742d  vmovaps [rsp+0x40], xmm4
00007dd052fd7433  vmovaps [rsp+0x50], xmm5
00007dd052fd7439  vmovaps [rsp+0x60], xmm6
00007dd052fd743f  vmovaps [rsp+0x70], xmm7
00007dd052fd7445  vmovaps [rsp+0x80], xmm8
00007dd052fd744e  vmovaps [rsp+0x90], xmm10
00007dd052fd7457  vmovaps [rsp+0xA0], xmm11
00007dd052fd7460  vmovaps [rsp+0xB0], xmm12
00007dd052fd7469  vmovaps [rsp+0xC0], xmm13
00007dd052fd7472  vmovaps [rsp+0xD0], xmm14
00007dd052fd747b  vmovaps [rsp+0xE0], xmm15
00007dd052fd7484  sub rsp, 0x30
00007dd052fd7488  movaps [rsp], xmm9
00007dd052fd748d  movaps [rsp+0x10], xmm7
00007dd052fd7492  movaps [rsp+0x20], xmm14
00007dd052fd7498  lea rdi, [rsp]
00007dd052fd749c  mov esi, 0x00
00007dd052fd74a1  mov rax, 0x61D0404B9530
00007dd052fd74ab  call rax
00007dd052fd74ad  movaps xmm9, [rsp]
00007dd052fd74b2  add rsp, 0x30
00007dd052fd74b6  vmovaps xmm0, [rsp]
00007dd052fd74bb  vmovaps xmm1, [rsp+0x10]
00007dd052fd74c1  vmovaps xmm2, [rsp+0x20]
00007dd052fd74c7  vmovaps xmm3, [rsp+0x30]
00007dd052fd74cd  vmovaps xmm4, [rsp+0x40]
00007dd052fd74d3  vmovaps xmm5, [rsp+0x50]
00007dd052fd74d9  vmovaps xmm6, [rsp+0x60]
00007dd052fd74df  vmovaps xmm7, [rsp+0x70]
00007dd052fd74e5  vmovaps xmm8, [rsp+0x80]
00007dd052fd74ee  vmovaps xmm10, [rsp+0x90]
00007dd052fd74f7  vmovaps xmm11, [rsp+0xA0]
00007dd052fd7500  vmovaps xmm12, [rsp+0xB0]
00007dd052fd7509  vmovaps xmm13, [rsp+0xC0]
00007dd052fd7512  vmovaps xmm14, [rsp+0xD0]
00007dd052fd751b  vmovaps xmm15, [rsp+0xE0]
00007dd052fd7524  add rsp, 0xF0
00007dd052fd752b  pop r11
00007dd052fd752d  pop r10
00007dd052fd752f  pop r9
00007dd052fd7531  pop r8
00007dd052fd7533  pop rsi
00007dd052fd7534  pop rdi
00007dd052fd7535  pop rdx
00007dd052fd7536  pop rcx
00007dd052fd7537  pop rax
00007dd052fd7538  add rsp, 0x08
00007dd052fd753c  jmp 0x00007DD052FD3318
00007dd052fd7541  sub rsp, 0x08
00007dd052fd7545  push rax
00007dd052fd7546  push rcx
00007dd052fd7547  push rdx
00007dd052fd7548  push rdi
00007dd052fd7549  push rsi
00007dd052fd754a  push r8
00007dd052fd754c  push r9
00007dd052fd754e  push r10
00007dd052fd7550  push r11
00007dd052fd7552  sub rsp, 0xF0
00007dd052fd7559  vmovaps [rsp], xmm0
00007dd052fd755e  vmovaps [rsp+0x10], xmm1
00007dd052fd7564  vmovaps [rsp+0x20], xmm2
00007dd052fd756a  vmovaps [rsp+0x30], xmm3
00007dd052fd7570  vmovaps [rsp+0x40], xmm4
00007dd052fd7576  vmovaps [rsp+0x50], xmm5
00007dd052fd757c  vmovaps [rsp+0x60], xmm6
00007dd052fd7582  vmovaps [rsp+0x70], xmm7
00007dd052fd7588  vmovaps [rsp+0x80], xmm8
00007dd052fd7591  vmovaps [rsp+0x90], xmm9
00007dd052fd759a  vmovaps [rsp+0xA0], xmm10
00007dd052fd75a3  vmovaps [rsp+0xB0], xmm11
00007dd052fd75ac  vmovaps [rsp+0xC0], xmm12
00007dd052fd75b5  vmovaps [rsp+0xD0], xmm13
00007dd052fd75be  vmovaps [rsp+0xE0], xmm15
00007dd052fd75c7  sub rsp, 0x30
00007dd052fd75cb  movaps [rsp], xmm14
00007dd052fd75d0  movaps [rsp+0x10], xmm13
00007dd052fd75d6  movaps [rsp+0x20], xmm11
00007dd052fd75dc  lea rdi, [rsp]
00007dd052fd75e0  mov esi, 0x00
00007dd052fd75e5  mov rax, 0x61D0404B9530
00007dd052fd75ef  call rax
00007dd052fd75f1  movaps xmm14, [rsp]
00007dd052fd75f6  add rsp, 0x30
00007dd052fd75fa  vmovaps xmm0, [rsp]
00007dd052fd75ff  vmovaps xmm1, [rsp+0x10]
00007dd052fd7605  vmovaps xmm2, [rsp+0x20]
00007dd052fd760b  vmovaps xmm3, [rsp+0x30]
00007dd052fd7611  vmovaps xmm4, [rsp+0x40]
00007dd052fd7617  vmovaps xmm5, [rsp+0x50]
00007dd052fd761d  vmovaps xmm6, [rsp+0x60]
00007dd052fd7623  vmovaps xmm7, [rsp+0x70]
00007dd052fd7629  vmovaps xmm8, [rsp+0x80]
00007dd052fd7632  vmovaps xmm9, [rsp+0x90]
00007dd052fd763b  vmovaps xmm10, [rsp+0xA0]
00007dd052fd7644  vmovaps xmm11, [rsp+0xB0]
00007dd052fd764d  vmovaps xmm12, [rsp+0xC0]
00007dd052fd7656  vmovaps xmm13, [rsp+0xD0]
00007dd052fd765f  vmovaps xmm15, [rsp+0xE0]
00007dd052fd7668  add rsp, 0xF0
00007dd052fd766f  pop r11
00007dd052fd7671  pop r10
00007dd052fd7673  pop r9
00007dd052fd7675  pop r8
00007dd052fd7677  pop rsi
00007dd052fd7678  pop rdi
00007dd052fd7679  pop rdx
00007dd052fd767a  pop rcx
00007dd052fd767b  pop rax
00007dd052fd767c  add rsp, 0x08
00007dd052fd7680  jmp 0x00007DD052FD3332
00007dd052fd7685  sub rsp, 0x08
00007dd052fd7689  push rax
00007dd052fd768a  push rcx
00007dd052fd768b  push rdx
00007dd052fd768c  push rdi
00007dd052fd768d  push rsi
00007dd052fd768e  push r8
00007dd052fd7690  push r9
00007dd052fd7692  push r10
00007dd052fd7694  push r11
00007dd052fd7696  sub rsp, 0xF0
00007dd052fd769d  vmovaps [rsp], xmm0
00007dd052fd76a2  vmovaps [rsp+0x10], xmm1
00007dd052fd76a8  vmovaps [rsp+0x20], xmm2
00007dd052fd76ae  vmovaps [rsp+0x30], xmm3
00007dd052fd76b4  vmovaps [rsp+0x40], xmm4
00007dd052fd76ba  vmovaps [rsp+0x50], xmm5
00007dd052fd76c0  vmovaps [rsp+0x60], xmm6
00007dd052fd76c6  vmovaps [rsp+0x70], xmm7
00007dd052fd76cc  vmovaps [rsp+0x80], xmm8
00007dd052fd76d5  vmovaps [rsp+0x90], xmm9
00007dd052fd76de  vmovaps [rsp+0xA0], xmm10
00007dd052fd76e7  vmovaps [rsp+0xB0], xmm12
00007dd052fd76f0  vmovaps [rsp+0xC0], xmm13
00007dd052fd76f9  vmovaps [rsp+0xD0], xmm14
00007dd052fd7702  vmovaps [rsp+0xE0], xmm15
00007dd052fd770b  sub rsp, 0x30
00007dd052fd770f  movaps [rsp], xmm11
00007dd052fd7714  movaps [rsp+0x10], xmm7
00007dd052fd7719  movaps [rsp+0x20], xmm13
00007dd052fd771f  lea rdi, [rsp]
00007dd052fd7723  mov esi, 0x00
00007dd052fd7728  mov rax, 0x61D0404B9530
00007dd052fd7732  call rax
00007dd052fd7734  movaps xmm11, [rsp]
00007dd052fd7739  add rsp, 0x30
00007dd052fd773d  vmovaps xmm0, [rsp]
00007dd052fd7742  vmovaps xmm1, [rsp+0x10]
00007dd052fd7748  vmovaps xmm2, [rsp+0x20]
00007dd052fd774e  vmovaps xmm3, [rsp+0x30]
00007dd052fd7754  vmovaps xmm4, [rsp+0x40]
00007dd052fd775a  vmovaps xmm5, [rsp+0x50]
00007dd052fd7760  vmovaps xmm6, [rsp+0x60]
00007dd052fd7766  vmovaps xmm7, [rsp+0x70]
00007dd052fd776c  vmovaps xmm8, [rsp+0x80]
00007dd052fd7775  vmovaps xmm9, [rsp+0x90]
00007dd052fd777e  vmovaps xmm10, [rsp+0xA0]
00007dd052fd7787  vmovaps xmm12, [rsp+0xB0]
00007dd052fd7790  vmovaps xmm13, [rsp+0xC0]
00007dd052fd7799  vmovaps xmm14, [rsp+0xD0]
00007dd052fd77a2  vmovaps xmm15, [rsp+0xE0]
00007dd052fd77ab  add rsp, 0xF0
00007dd052fd77b2  pop r11
00007dd052fd77b4  pop r10
00007dd052fd77b6  pop r9
00007dd052fd77b8  pop r8
00007dd052fd77ba  pop rsi
00007dd052fd77bb  pop rdi
00007dd052fd77bc  pop rdx
00007dd052fd77bd  pop rcx
00007dd052fd77be  pop rax
00007dd052fd77bf  add rsp, 0x08
00007dd052fd77c3  jmp 0x00007DD052FD335E
00007dd052fd77c8  sub rsp, 0x08
00007dd052fd77cc  push rax
00007dd052fd77cd  push rcx
00007dd052fd77ce  push rdx
00007dd052fd77cf  push rdi
00007dd052fd77d0  push rsi
00007dd052fd77d1  push r8
00007dd052fd77d3  push r9
00007dd052fd77d5  push r10
00007dd052fd77d7  push r11
00007dd052fd77d9  sub rsp, 0xF0
00007dd052fd77e0  vmovaps [rsp], xmm0
00007dd052fd77e5  vmovaps [rsp+0x10], xmm1
00007dd052fd77eb  vmovaps [rsp+0x20], xmm2
00007dd052fd77f1  vmovaps [rsp+0x30], xmm3
00007dd052fd77f7  vmovaps [rsp+0x40], xmm4
00007dd052fd77fd  vmovaps [rsp+0x50], xmm5
00007dd052fd7803  vmovaps [rsp+0x60], xmm6
00007dd052fd7809  vmovaps [rsp+0x70], xmm7
00007dd052fd780f  vmovaps [rsp+0x80], xmm8
00007dd052fd7818  vmovaps [rsp+0x90], xmm9
00007dd052fd7821  vmovaps [rsp+0xA0], xmm10
00007dd052fd782a  vmovaps [rsp+0xB0], xmm11
00007dd052fd7833  vmovaps [rsp+0xC0], xmm12
00007dd052fd783c  vmovaps [rsp+0xD0], xmm14
00007dd052fd7845  vmovaps [rsp+0xE0], xmm15
00007dd052fd784e  sub rsp, 0x30
00007dd052fd7852  movaps [rsp], xmm13
00007dd052fd7857  movaps [rsp+0x10], xmm10
00007dd052fd785d  movaps [rsp+0x20], xmm12
00007dd052fd7863  lea rdi, [rsp]
00007dd052fd7867  mov esi, 0x00
00007dd052fd786c  mov rax, 0x61D0404B9530
00007dd052fd7876  call rax
00007dd052fd7878  movaps xmm13, [rsp]
00007dd052fd787d  add rsp, 0x30
00007dd052fd7881  vmovaps xmm0, [rsp]
00007dd052fd7886  vmovaps xmm1, [rsp+0x10]
00007dd052fd788c  vmovaps xmm2, [rsp+0x20]
00007dd052fd7892  vmovaps xmm3, [rsp+0x30]
00007dd052fd7898  vmovaps xmm4, [rsp+0x40]
00007dd052fd789e  vmovaps xmm5, [rsp+0x50]
00007dd052fd78a4  vmovaps xmm6, [rsp+0x60]
00007dd052fd78aa  vmovaps xmm7, [rsp+0x70]
00007dd052fd78b0  vmovaps xmm8, [rsp+0x80]
00007dd052fd78b9  vmovaps xmm9, [rsp+0x90]
00007dd052fd78c2  vmovaps xmm10, [rsp+0xA0]
00007dd052fd78cb  vmovaps xmm11, [rsp+0xB0]
00007dd052fd78d4  vmovaps xmm12, [rsp+0xC0]
00007dd052fd78dd  vmovaps xmm14, [rsp+0xD0]
00007dd052fd78e6  vmovaps xmm15, [rsp+0xE0]
00007dd052fd78ef  add rsp, 0xF0
00007dd052fd78f6  pop r11
00007dd052fd78f8  pop r10
00007dd052fd78fa  pop r9
00007dd052fd78fc  pop r8
00007dd052fd78fe  pop rsi
00007dd052fd78ff  pop rdi
00007dd052fd7900  pop rdx
00007dd052fd7901  pop rcx
00007dd052fd7902  pop rax
00007dd052fd7903  add rsp, 0x08
00007dd052fd7907  jmp 0x00007DD052FD3378
00007dd052fd790c  sub rsp, 0x08
00007dd052fd7910  push rax
00007dd052fd7911  push rcx
00007dd052fd7912  push rdx
00007dd052fd7913  push rdi
00007dd052fd7914  push rsi
00007dd052fd7915  push r8
00007dd052fd7917  push r9
00007dd052fd7919  push r10
00007dd052fd791b  push r11
00007dd052fd791d  sub rsp, 0xF0
00007dd052fd7924  vmovaps [rsp], xmm0
00007dd052fd7929  vmovaps [rsp+0x10], xmm1
00007dd052fd792f  vmovaps [rsp+0x20], xmm2
00007dd052fd7935  vmovaps [rsp+0x30], xmm3
00007dd052fd793b  vmovaps [rsp+0x40], xmm4
00007dd052fd7941  vmovaps [rsp+0x50], xmm5
00007dd052fd7947  vmovaps [rsp+0x60], xmm6
00007dd052fd794d  vmovaps [rsp+0x70], xmm7
00007dd052fd7953  vmovaps [rsp+0x80], xmm8
00007dd052fd795c  vmovaps [rsp+0x90], xmm9
00007dd052fd7965  vmovaps [rsp+0xA0], xmm11
00007dd052fd796e  vmovaps [rsp+0xB0], xmm12
00007dd052fd7977  vmovaps [rsp+0xC0], xmm13
00007dd052fd7980  vmovaps [rsp+0xD0], xmm14
00007dd052fd7989  vmovaps [rsp+0xE0], xmm15
00007dd052fd7992  sub rsp, 0x30
00007dd052fd7996  movaps [rsp], xmm10
00007dd052fd799b  movaps [rsp+0x10], xmm7
00007dd052fd79a0  movaps [rsp+0x20], xmm12
00007dd052fd79a6  lea rdi, [rsp]
00007dd052fd79aa  mov esi, 0x00
00007dd052fd79af  mov rax, 0x61D0404B9530
00007dd052fd79b9  call rax
00007dd052fd79bb  movaps xmm10, [rsp]
00007dd052fd79c0  add rsp, 0x30
00007dd052fd79c4  vmovaps xmm0, [rsp]
00007dd052fd79c9  vmovaps xmm1, [rsp+0x10]
00007dd052fd79cf  vmovaps xmm2, [rsp+0x20]
00007dd052fd79d5  vmovaps xmm3, [rsp+0x30]
00007dd052fd79db  vmovaps xmm4, [rsp+0x40]
00007dd052fd79e1  vmovaps xmm5, [rsp+0x50]
00007dd052fd79e7  vmovaps xmm6, [rsp+0x60]
00007dd052fd79ed  vmovaps xmm7, [rsp+0x70]
00007dd052fd79f3  vmovaps xmm8, [rsp+0x80]
00007dd052fd79fc  vmovaps xmm9, [rsp+0x90]
00007dd052fd7a05  vmovaps xmm11, [rsp+0xA0]
00007dd052fd7a0e  vmovaps xmm12, [rsp+0xB0]
00007dd052fd7a17  vmovaps xmm13, [rsp+0xC0]
00007dd052fd7a20  vmovaps xmm14, [rsp+0xD0]
00007dd052fd7a29  vmovaps xmm15, [rsp+0xE0]
00007dd052fd7a32  add rsp, 0xF0
00007dd052fd7a39  pop r11
00007dd052fd7a3b  pop r10
00007dd052fd7a3d  pop r9
00007dd052fd7a3f  pop r8
00007dd052fd7a41  pop rsi
00007dd052fd7a42  pop rdi
00007dd052fd7a43  pop rdx
00007dd052fd7a44  pop rcx
00007dd052fd7a45  pop rax
00007dd052fd7a46  add rsp, 0x08
00007dd052fd7a4a  jmp 0x00007DD052FD33A4
00007dd052fd7a4f  sub rsp, 0x08
00007dd052fd7a53  push rax
00007dd052fd7a54  push rcx
00007dd052fd7a55  push rdx
00007dd052fd7a56  push rdi
00007dd052fd7a57  push rsi
00007dd052fd7a58  push r8
00007dd052fd7a5a  push r9
00007dd052fd7a5c  push r10
00007dd052fd7a5e  push r11
00007dd052fd7a60  sub rsp, 0xF0
00007dd052fd7a67  vmovaps [rsp], xmm0
00007dd052fd7a6c  vmovaps [rsp+0x10], xmm1
00007dd052fd7a72  vmovaps [rsp+0x20], xmm2
00007dd052fd7a78  vmovaps [rsp+0x30], xmm3
00007dd052fd7a7e  vmovaps [rsp+0x40], xmm4
00007dd052fd7a84  vmovaps [rsp+0x50], xmm5
00007dd052fd7a8a  vmovaps [rsp+0x60], xmm6
00007dd052fd7a90  vmovaps [rsp+0x70], xmm7
00007dd052fd7a96  vmovaps [rsp+0x80], xmm8
00007dd052fd7a9f  vmovaps [rsp+0x90], xmm9
00007dd052fd7aa8  vmovaps [rsp+0xA0], xmm10
00007dd052fd7ab1  vmovaps [rsp+0xB0], xmm11
00007dd052fd7aba  vmovaps [rsp+0xC0], xmm13
00007dd052fd7ac3  vmovaps [rsp+0xD0], xmm14
00007dd052fd7acc  vmovaps [rsp+0xE0], xmm15
00007dd052fd7ad5  sub rsp, 0x30
00007dd052fd7ad9  movaps [rsp], xmm12
00007dd052fd7ade  movaps [rsp+0x10], xmm1
00007dd052fd7ae3  movaps [rsp+0x20], xmm8
00007dd052fd7ae9  lea rdi, [rsp]
00007dd052fd7aed  mov esi, 0x00
00007dd052fd7af2  mov rax, 0x61D0404B9530
00007dd052fd7afc  call rax
00007dd052fd7afe  movaps xmm12, [rsp]
00007dd052fd7b03  add rsp, 0x30
00007dd052fd7b07  vmovaps xmm0, [rsp]
00007dd052fd7b0c  vmovaps xmm1, [rsp+0x10]
00007dd052fd7b12  vmovaps xmm2, [rsp+0x20]
00007dd052fd7b18  vmovaps xmm3, [rsp+0x30]
00007dd052fd7b1e  vmovaps xmm4, [rsp+0x40]
00007dd052fd7b24  vmovaps xmm5, [rsp+0x50]
00007dd052fd7b2a  vmovaps xmm6, [rsp+0x60]
00007dd052fd7b30  vmovaps xmm7, [rsp+0x70]
00007dd052fd7b36  vmovaps xmm8, [rsp+0x80]
00007dd052fd7b3f  vmovaps xmm9, [rsp+0x90]
00007dd052fd7b48  vmovaps xmm10, [rsp+0xA0]
00007dd052fd7b51  vmovaps xmm11, [rsp+0xB0]
00007dd052fd7b5a  vmovaps xmm13, [rsp+0xC0]
00007dd052fd7b63  vmovaps xmm14, [rsp+0xD0]
00007dd052fd7b6c  vmovaps xmm15, [rsp+0xE0]
00007dd052fd7b75  add rsp, 0xF0
00007dd052fd7b7c  pop r11
00007dd052fd7b7e  pop r10
00007dd052fd7b80  pop r9
00007dd052fd7b82  pop r8
00007dd052fd7b84  pop rsi
00007dd052fd7b85  pop rdi
00007dd052fd7b86  pop rdx
00007dd052fd7b87  pop rcx
00007dd052fd7b88  pop rax
00007dd052fd7b89  add rsp, 0x08
00007dd052fd7b8d  jmp 0x00007DD052FD33BE
00007dd052fd7b92  call 0x00007DD052DFF430
00007dd052fd7b97  jmp 0x00007DD052FD33C8
00007dd052fd7b9c  sub rsp, 0x08
00007dd052fd7ba0  push rax
00007dd052fd7ba1  push rcx
00007dd052fd7ba2  push rdx
00007dd052fd7ba3  push rdi
00007dd052fd7ba4  push rsi
00007dd052fd7ba5  push r8
00007dd052fd7ba7  push r9
00007dd052fd7ba9  push r10
00007dd052fd7bab  push r11
00007dd052fd7bad  sub rsp, 0xF0
00007dd052fd7bb4  vmovaps [rsp], xmm0
00007dd052fd7bb9  vmovaps [rsp+0x10], xmm1
00007dd052fd7bbf  vmovaps [rsp+0x20], xmm2
00007dd052fd7bc5  vmovaps [rsp+0x30], xmm3
00007dd052fd7bcb  vmovaps [rsp+0x40], xmm4
00007dd052fd7bd1  vmovaps [rsp+0x50], xmm5
00007dd052fd7bd7  vmovaps [rsp+0x60], xmm6
00007dd052fd7bdd  vmovaps [rsp+0x70], xmm7
00007dd052fd7be3  vmovaps [rsp+0x80], xmm9
00007dd052fd7bec  vmovaps [rsp+0x90], xmm10
00007dd052fd7bf5  vmovaps [rsp+0xA0], xmm11
00007dd052fd7bfe  vmovaps [rsp+0xB0], xmm12
00007dd052fd7c07  vmovaps [rsp+0xC0], xmm13
00007dd052fd7c10  vmovaps [rsp+0xD0], xmm14
00007dd052fd7c19  vmovaps [rsp+0xE0], xmm15
00007dd052fd7c22  sub rsp, 0x30
00007dd052fd7c26  movaps [rsp], xmm8
00007dd052fd7c2b  movaps [rsp+0x10], xmm15
00007dd052fd7c31  movaps [rsp+0x20], xmm9
00007dd052fd7c37  lea rdi, [rsp]
00007dd052fd7c3b  mov esi, 0x00
00007dd052fd7c40  mov rax, 0x61D0404B9530
00007dd052fd7c4a  call rax
00007dd052fd7c4c  movaps xmm8, [rsp]
00007dd052fd7c51  add rsp, 0x30
00007dd052fd7c55  vmovaps xmm0, [rsp]
00007dd052fd7c5a  vmovaps xmm1, [rsp+0x10]
00007dd052fd7c60  vmovaps xmm2, [rsp+0x20]
00007dd052fd7c66  vmovaps xmm3, [rsp+0x30]
00007dd052fd7c6c  vmovaps xmm4, [rsp+0x40]
00007dd052fd7c72  vmovaps xmm5, [rsp+0x50]
00007dd052fd7c78  vmovaps xmm6, [rsp+0x60]
00007dd052fd7c7e  vmovaps xmm7, [rsp+0x70]
00007dd052fd7c84  vmovaps xmm9, [rsp+0x80]
00007dd052fd7c8d  vmovaps xmm10, [rsp+0x90]
00007dd052fd7c96  vmovaps xmm11, [rsp+0xA0]
00007dd052fd7c9f  vmovaps xmm12, [rsp+0xB0]
00007dd052fd7ca8  vmovaps xmm13, [rsp+0xC0]
00007dd052fd7cb1  vmovaps xmm14, [rsp+0xD0]
00007dd052fd7cba  vmovaps xmm15, [rsp+0xE0]
00007dd052fd7cc3  add rsp, 0xF0
00007dd052fd7cca  pop r11
00007dd052fd7ccc  pop r10
00007dd052fd7cce  pop r9
00007dd052fd7cd0  pop r8
00007dd052fd7cd2  pop rsi
00007dd052fd7cd3  pop rdi
00007dd052fd7cd4  pop rdx
00007dd052fd7cd5  pop rcx
00007dd052fd7cd6  pop rax
00007dd052fd7cd7  add rsp, 0x08
00007dd052fd7cdb  jmp 0x00007DD052FD33EA
00007dd052fd7ce0  sub rsp, 0x08
00007dd052fd7ce4  push rax
00007dd052fd7ce5  push rcx
00007dd052fd7ce6  push rdx
00007dd052fd7ce7  push rdi
00007dd052fd7ce8  push rsi
00007dd052fd7ce9  push r8
00007dd052fd7ceb  push r9
00007dd052fd7ced  push r10
00007dd052fd7cef  push r11
00007dd052fd7cf1  sub rsp, 0xF0
00007dd052fd7cf8  vmovaps [rsp], xmm0
00007dd052fd7cfd  vmovaps [rsp+0x10], xmm1
00007dd052fd7d03  vmovaps [rsp+0x20], xmm2
00007dd052fd7d09  vmovaps [rsp+0x30], xmm3
00007dd052fd7d0f  vmovaps [rsp+0x40], xmm4
00007dd052fd7d15  vmovaps [rsp+0x50], xmm5
00007dd052fd7d1b  vmovaps [rsp+0x60], xmm6
00007dd052fd7d21  vmovaps [rsp+0x70], xmm7
00007dd052fd7d27  vmovaps [rsp+0x80], xmm8
00007dd052fd7d30  vmovaps [rsp+0x90], xmm10
00007dd052fd7d39  vmovaps [rsp+0xA0], xmm11
00007dd052fd7d42  vmovaps [rsp+0xB0], xmm12
00007dd052fd7d4b  vmovaps [rsp+0xC0], xmm13
00007dd052fd7d54  vmovaps [rsp+0xD0], xmm14
00007dd052fd7d5d  vmovaps [rsp+0xE0], xmm15
00007dd052fd7d66  sub rsp, 0x30
00007dd052fd7d6a  movaps [rsp], xmm9
00007dd052fd7d6f  movaps [rsp+0x10], xmm1
00007dd052fd7d74  movaps [rsp+0x20], xmm15
00007dd052fd7d7a  lea rdi, [rsp]
00007dd052fd7d7e  mov esi, 0x00
00007dd052fd7d83  mov rax, 0x61D0404B9530
00007dd052fd7d8d  call rax
00007dd052fd7d8f  movaps xmm9, [rsp]
00007dd052fd7d94  add rsp, 0x30
00007dd052fd7d98  vmovaps xmm0, [rsp]
00007dd052fd7d9d  vmovaps xmm1, [rsp+0x10]
00007dd052fd7da3  vmovaps xmm2, [rsp+0x20]
00007dd052fd7da9  vmovaps xmm3, [rsp+0x30]
00007dd052fd7daf  vmovaps xmm4, [rsp+0x40]
00007dd052fd7db5  vmovaps xmm5, [rsp+0x50]
00007dd052fd7dbb  vmovaps xmm6, [rsp+0x60]
00007dd052fd7dc1  vmovaps xmm7, [rsp+0x70]
00007dd052fd7dc7  vmovaps xmm8, [rsp+0x80]
00007dd052fd7dd0  vmovaps xmm10, [rsp+0x90]
00007dd052fd7dd9  vmovaps xmm11, [rsp+0xA0]
00007dd052fd7de2  vmovaps xmm12, [rsp+0xB0]
00007dd052fd7deb  vmovaps xmm13, [rsp+0xC0]
00007dd052fd7df4  vmovaps xmm14, [rsp+0xD0]
00007dd052fd7dfd  vmovaps xmm15, [rsp+0xE0]
00007dd052fd7e06  add rsp, 0xF0
00007dd052fd7e0d  pop r11
00007dd052fd7e0f  pop r10
00007dd052fd7e11  pop r9
00007dd052fd7e13  pop r8
00007dd052fd7e15  pop rsi
00007dd052fd7e16  pop rdi
00007dd052fd7e17  pop rdx
00007dd052fd7e18  pop rcx
00007dd052fd7e19  pop rax
00007dd052fd7e1a  add rsp, 0x08
00007dd052fd7e1e  jmp 0x00007DD052FD3418
00007dd052fd7e23  sub rsp, 0x08
00007dd052fd7e27  push rax
00007dd052fd7e28  push rcx
00007dd052fd7e29  push rdx
00007dd052fd7e2a  push rdi
00007dd052fd7e2b  push rsi
00007dd052fd7e2c  push r8
00007dd052fd7e2e  push r9
00007dd052fd7e30  push r10
00007dd052fd7e32  push r11
00007dd052fd7e34  sub rsp, 0xF0
00007dd052fd7e3b  vmovaps [rsp], xmm0
00007dd052fd7e40  vmovaps [rsp+0x10], xmm1
00007dd052fd7e46  vmovaps [rsp+0x20], xmm2
00007dd052fd7e4c  vmovaps [rsp+0x30], xmm3
00007dd052fd7e52  vmovaps [rsp+0x40], xmm4
00007dd052fd7e58  vmovaps [rsp+0x50], xmm5
00007dd052fd7e5e  vmovaps [rsp+0x60], xmm6
00007dd052fd7e64  vmovaps [rsp+0x70], xmm7
00007dd052fd7e6a  vmovaps [rsp+0x80], xmm8
00007dd052fd7e73  vmovaps [rsp+0x90], xmm9
00007dd052fd7e7c  vmovaps [rsp+0xA0], xmm10
00007dd052fd7e85  vmovaps [rsp+0xB0], xmm11
00007dd052fd7e8e  vmovaps [rsp+0xC0], xmm12
00007dd052fd7e97  vmovaps [rsp+0xD0], xmm13
00007dd052fd7ea0  vmovaps [rsp+0xE0], xmm14
00007dd052fd7ea9  sub rsp, 0x30
00007dd052fd7ead  movaps [rsp], xmm15
00007dd052fd7eb2  movaps [rsp+0x10], xmm4
00007dd052fd7eb7  movaps [rsp+0x20], xmm1
00007dd052fd7ebc  lea rdi, [rsp]
00007dd052fd7ec0  mov esi, 0x00
00007dd052fd7ec5  mov rax, 0x61D0404B9530
00007dd052fd7ecf  call rax
00007dd052fd7ed1  movaps xmm15, [rsp]
00007dd052fd7ed6  add rsp, 0x30
00007dd052fd7eda  vmovaps xmm0, [rsp]
00007dd052fd7edf  vmovaps xmm1, [rsp+0x10]
00007dd052fd7ee5  vmovaps xmm2, [rsp+0x20]
00007dd052fd7eeb  vmovaps xmm3, [rsp+0x30]
00007dd052fd7ef1  vmovaps xmm4, [rsp+0x40]
00007dd052fd7ef7  vmovaps xmm5, [rsp+0x50]
00007dd052fd7efd  vmovaps xmm6, [rsp+0x60]
00007dd052fd7f03  vmovaps xmm7, [rsp+0x70]
00007dd052fd7f09  vmovaps xmm8, [rsp+0x80]
00007dd052fd7f12  vmovaps xmm9, [rsp+0x90]
00007dd052fd7f1b  vmovaps xmm10, [rsp+0xA0]
00007dd052fd7f24  vmovaps xmm11, [rsp+0xB0]
00007dd052fd7f2d  vmovaps xmm12, [rsp+0xC0]
00007dd052fd7f36  vmovaps xmm13, [rsp+0xD0]
00007dd052fd7f3f  vmovaps xmm14, [rsp+0xE0]
00007dd052fd7f48  add rsp, 0xF0
00007dd052fd7f4f  pop r11
00007dd052fd7f51  pop r10
00007dd052fd7f53  pop r9
00007dd052fd7f55  pop r8
00007dd052fd7f57  pop rsi
00007dd052fd7f58  pop rdi
00007dd052fd7f59  pop rdx
00007dd052fd7f5a  pop rcx
00007dd052fd7f5b  pop rax
00007dd052fd7f5c  add rsp, 0x08
00007dd052fd7f60  jmp 0x00007DD052FD343E
00007dd052fd7f65  sub rsp, 0x08
00007dd052fd7f69  push rax
00007dd052fd7f6a  push rcx
00007dd052fd7f6b  push rdx
00007dd052fd7f6c  push rdi
00007dd052fd7f6d  push rsi
00007dd052fd7f6e  push r8
00007dd052fd7f70  push r9
00007dd052fd7f72  push r10
00007dd052fd7f74  push r11
00007dd052fd7f76  sub rsp, 0xF0
00007dd052fd7f7d  vmovaps [rsp], xmm0
00007dd052fd7f82  vmovaps [rsp+0x10], xmm2
00007dd052fd7f88  vmovaps [rsp+0x20], xmm3
00007dd052fd7f8e  vmovaps [rsp+0x30], xmm4
00007dd052fd7f94  vmovaps [rsp+0x40], xmm5
00007dd052fd7f9a  vmovaps [rsp+0x50], xmm6
00007dd052fd7fa0  vmovaps [rsp+0x60], xmm7
00007dd052fd7fa6  vmovaps [rsp+0x70], xmm8
00007dd052fd7fac  vmovaps [rsp+0x80], xmm9
00007dd052fd7fb5  vmovaps [rsp+0x90], xmm10
00007dd052fd7fbe  vmovaps [rsp+0xA0], xmm11
00007dd052fd7fc7  vmovaps [rsp+0xB0], xmm12
00007dd052fd7fd0  vmovaps [rsp+0xC0], xmm13
00007dd052fd7fd9  vmovaps [rsp+0xD0], xmm14
00007dd052fd7fe2  vmovaps [rsp+0xE0], xmm15
00007dd052fd7feb  sub rsp, 0x30
00007dd052fd7fef  movaps [rsp], xmm1
00007dd052fd7ff3  movaps [rsp+0x10], xmm14
00007dd052fd7ff9  movaps [rsp+0x20], xmm11
00007dd052fd7fff  lea rdi, [rsp]
00007dd052fd8003  mov esi, 0x00
00007dd052fd8008  mov rax, 0x61D0404B9530
00007dd052fd8012  call rax
00007dd052fd8014  movaps xmm1, [rsp]
00007dd052fd8018  add rsp, 0x30
00007dd052fd801c  vmovaps xmm0, [rsp]
00007dd052fd8021  vmovaps xmm2, [rsp+0x10]
00007dd052fd8027  vmovaps xmm3, [rsp+0x20]
00007dd052fd802d  vmovaps xmm4, [rsp+0x30]
00007dd052fd8033  vmovaps xmm5, [rsp+0x40]
00007dd052fd8039  vmovaps xmm6, [rsp+0x50]
00007dd052fd803f  vmovaps xmm7, [rsp+0x60]
00007dd052fd8045  vmovaps xmm8, [rsp+0x70]
00007dd052fd804b  vmovaps xmm9, [rsp+0x80]
00007dd052fd8054  vmovaps xmm10, [rsp+0x90]
00007dd052fd805d  vmovaps xmm11, [rsp+0xA0]
00007dd052fd8066  vmovaps xmm12, [rsp+0xB0]
00007dd052fd806f  vmovaps xmm13, [rsp+0xC0]
00007dd052fd8078  vmovaps xmm14, [rsp+0xD0]
00007dd052fd8081  vmovaps xmm15, [rsp+0xE0]
00007dd052fd808a  add rsp, 0xF0
00007dd052fd8091  pop r11
00007dd052fd8093  pop r10
00007dd052fd8095  pop r9
00007dd052fd8097  pop r8
00007dd052fd8099  pop rsi
00007dd052fd809a  pop rdi
00007dd052fd809b  pop rdx
00007dd052fd809c  pop rcx
00007dd052fd809d  pop rax
00007dd052fd809e  add rsp, 0x08
00007dd052fd80a2  jmp 0x00007DD052FD345F
00007dd052fd80a7  call 0x00007DD052EE45A0
00007dd052fd80ac  jmp 0x00007DD052FD346D
00007dd052fd80b1  call 0x00007DD052E09D70
00007dd052fd80b6  jmp 0x00007DD052FD3477
00007dd052fd80bb  sub rsp, 0x08
00007dd052fd80bf  push rax
00007dd052fd80c0  push rcx
00007dd052fd80c1  push rdx
00007dd052fd80c2  push rdi
00007dd052fd80c3  push rsi
00007dd052fd80c4  push r8
00007dd052fd80c6  push r9
00007dd052fd80c8  push r10
00007dd052fd80ca  push r11
00007dd052fd80cc  sub rsp, 0xF0
00007dd052fd80d3  vmovaps [rsp], xmm0
00007dd052fd80d8  vmovaps [rsp+0x10], xmm1
00007dd052fd80de  vmovaps [rsp+0x20], xmm2
00007dd052fd80e4  vmovaps [rsp+0x30], xmm3
00007dd052fd80ea  vmovaps [rsp+0x40], xmm4
00007dd052fd80f0  vmovaps [rsp+0x50], xmm5
00007dd052fd80f6  vmovaps [rsp+0x60], xmm6
00007dd052fd80fc  vmovaps [rsp+0x70], xmm8
00007dd052fd8102  vmovaps [rsp+0x80], xmm9
00007dd052fd810b  vmovaps [rsp+0x90], xmm10
00007dd052fd8114  vmovaps [rsp+0xA0], xmm11
00007dd052fd811d  vmovaps [rsp+0xB0], xmm12
00007dd052fd8126  vmovaps [rsp+0xC0], xmm13
00007dd052fd812f  vmovaps [rsp+0xD0], xmm14
00007dd052fd8138  vmovaps [rsp+0xE0], xmm15
00007dd052fd8141  sub rsp, 0x30
00007dd052fd8145  movaps [rsp], xmm7
00007dd052fd8149  movaps [rsp+0x10], xmm13
00007dd052fd814f  movaps [rsp+0x20], xmm10
00007dd052fd8155  lea rdi, [rsp]
00007dd052fd8159  mov esi, 0x00
00007dd052fd815e  mov rax, 0x61D0404B9530
00007dd052fd8168  call rax
00007dd052fd816a  movaps xmm7, [rsp]
00007dd052fd816e  add rsp, 0x30
00007dd052fd8172  vmovaps xmm0, [rsp]
00007dd052fd8177  vmovaps xmm1, [rsp+0x10]
00007dd052fd817d  vmovaps xmm2, [rsp+0x20]
00007dd052fd8183  vmovaps xmm3, [rsp+0x30]
00007dd052fd8189  vmovaps xmm4, [rsp+0x40]
00007dd052fd818f  vmovaps xmm5, [rsp+0x50]
00007dd052fd8195  vmovaps xmm6, [rsp+0x60]
00007dd052fd819b  vmovaps xmm8, [rsp+0x70]
00007dd052fd81a1  vmovaps xmm9, [rsp+0x80]
00007dd052fd81aa  vmovaps xmm10, [rsp+0x90]
00007dd052fd81b3  vmovaps xmm11, [rsp+0xA0]
00007dd052fd81bc  vmovaps xmm12, [rsp+0xB0]
00007dd052fd81c5  vmovaps xmm13, [rsp+0xC0]
00007dd052fd81ce  vmovaps xmm14, [rsp+0xD0]
00007dd052fd81d7  vmovaps xmm15, [rsp+0xE0]
00007dd052fd81e0  add rsp, 0xF0
00007dd052fd81e7  pop r11
00007dd052fd81e9  pop r10
00007dd052fd81eb  pop r9
00007dd052fd81ed  pop r8
00007dd052fd81ef  pop rsi
00007dd052fd81f0  pop rdi
00007dd052fd81f1  pop rdx
00007dd052fd81f2  pop rcx
00007dd052fd81f3  pop rax
00007dd052fd81f4  add rsp, 0x08
00007dd052fd81f8  jmp 0x00007DD052FD3498
00007dd052fd81fd  sub rsp, 0x08
00007dd052fd8201  push rax
00007dd052fd8202  push rcx
00007dd052fd8203  push rdx
00007dd052fd8204  push rdi
00007dd052fd8205  push rsi
00007dd052fd8206  push r8
00007dd052fd8208  push r9
00007dd052fd820a  push r10
00007dd052fd820c  push r11
00007dd052fd820e  sub rsp, 0xF0
00007dd052fd8215  vmovaps [rsp], xmm0
00007dd052fd821a  vmovaps [rsp+0x10], xmm1
00007dd052fd8220  vmovaps [rsp+0x20], xmm2
00007dd052fd8226  vmovaps [rsp+0x30], xmm3
00007dd052fd822c  vmovaps [rsp+0x40], xmm4
00007dd052fd8232  vmovaps [rsp+0x50], xmm5
00007dd052fd8238  vmovaps [rsp+0x60], xmm6
00007dd052fd823e  vmovaps [rsp+0x70], xmm7
00007dd052fd8244  vmovaps [rsp+0x80], xmm8
00007dd052fd824d  vmovaps [rsp+0x90], xmm9
00007dd052fd8256  vmovaps [rsp+0xA0], xmm11
00007dd052fd825f  vmovaps [rsp+0xB0], xmm12
00007dd052fd8268  vmovaps [rsp+0xC0], xmm13
00007dd052fd8271  vmovaps [rsp+0xD0], xmm14
00007dd052fd827a  vmovaps [rsp+0xE0], xmm15
00007dd052fd8283  sub rsp, 0x30
00007dd052fd8287  movaps [rsp], xmm10
00007dd052fd828c  movaps [rsp+0x10], xmm11
00007dd052fd8292  movaps [rsp+0x20], xmm13
00007dd052fd8298  lea rdi, [rsp]
00007dd052fd829c  mov esi, 0x00
00007dd052fd82a1  mov rax, 0x61D0404B9530
00007dd052fd82ab  call rax
00007dd052fd82ad  movaps xmm10, [rsp]
00007dd052fd82b2  add rsp, 0x30
00007dd052fd82b6  vmovaps xmm0, [rsp]
00007dd052fd82bb  vmovaps xmm1, [rsp+0x10]
00007dd052fd82c1  vmovaps xmm2, [rsp+0x20]
00007dd052fd82c7  vmovaps xmm3, [rsp+0x30]
00007dd052fd82cd  vmovaps xmm4, [rsp+0x40]
00007dd052fd82d3  vmovaps xmm5, [rsp+0x50]
00007dd052fd82d9  vmovaps xmm6, [rsp+0x60]
00007dd052fd82df  vmovaps xmm7, [rsp+0x70]
00007dd052fd82e5  vmovaps xmm8, [rsp+0x80]
00007dd052fd82ee  vmovaps xmm9, [rsp+0x90]
00007dd052fd82f7  vmovaps xmm11, [rsp+0xA0]
00007dd052fd8300  vmovaps xmm12, [rsp+0xB0]
00007dd052fd8309  vmovaps xmm13, [rsp+0xC0]
00007dd052fd8312  vmovaps xmm14, [rsp+0xD0]
00007dd052fd831b  vmovaps xmm15, [rsp+0xE0]
00007dd052fd8324  add rsp, 0xF0
00007dd052fd832b  pop r11
00007dd052fd832d  pop r10
00007dd052fd832f  pop r9
00007dd052fd8331  pop r8
00007dd052fd8333  pop rsi
00007dd052fd8334  pop rdi
00007dd052fd8335  pop rdx
00007dd052fd8336  pop rcx
00007dd052fd8337  pop rax
00007dd052fd8338  add rsp, 0x08
00007dd052fd833c  jmp 0x00007DD052FD34C6
00007dd052fd8341  sub rsp, 0x08
00007dd052fd8345  push rax
00007dd052fd8346  push rcx
00007dd052fd8347  push rdx
00007dd052fd8348  push rdi
00007dd052fd8349  push rsi
00007dd052fd834a  push r8
00007dd052fd834c  push r9
00007dd052fd834e  push r10
00007dd052fd8350  push r11
00007dd052fd8352  sub rsp, 0xF0
00007dd052fd8359  vmovaps [rsp], xmm0
00007dd052fd835e  vmovaps [rsp+0x10], xmm1
00007dd052fd8364  vmovaps [rsp+0x20], xmm2
00007dd052fd836a  vmovaps [rsp+0x30], xmm3
00007dd052fd8370  vmovaps [rsp+0x40], xmm4
00007dd052fd8376  vmovaps [rsp+0x50], xmm5
00007dd052fd837c  vmovaps [rsp+0x60], xmm6
00007dd052fd8382  vmovaps [rsp+0x70], xmm7
00007dd052fd8388  vmovaps [rsp+0x80], xmm8
00007dd052fd8391  vmovaps [rsp+0x90], xmm9
00007dd052fd839a  vmovaps [rsp+0xA0], xmm10
00007dd052fd83a3  vmovaps [rsp+0xB0], xmm12
00007dd052fd83ac  vmovaps [rsp+0xC0], xmm13
00007dd052fd83b5  vmovaps [rsp+0xD0], xmm14
00007dd052fd83be  vmovaps [rsp+0xE0], xmm15
00007dd052fd83c7  sub rsp, 0x30
00007dd052fd83cb  movaps [rsp], xmm11
00007dd052fd83d0  movaps [rsp+0x10], xmm14
00007dd052fd83d6  movaps [rsp+0x20], xmm13
00007dd052fd83dc  lea rdi, [rsp]
00007dd052fd83e0  mov esi, 0x00
00007dd052fd83e5  mov rax, 0x61D0404B9530
00007dd052fd83ef  call rax
00007dd052fd83f1  movaps xmm11, [rsp]
00007dd052fd83f6  add rsp, 0x30
00007dd052fd83fa  vmovaps xmm0, [rsp]
00007dd052fd83ff  vmovaps xmm1, [rsp+0x10]
00007dd052fd8405  vmovaps xmm2, [rsp+0x20]
00007dd052fd840b  vmovaps xmm3, [rsp+0x30]
00007dd052fd8411  vmovaps xmm4, [rsp+0x40]
00007dd052fd8417  vmovaps xmm5, [rsp+0x50]
00007dd052fd841d  vmovaps xmm6, [rsp+0x60]
00007dd052fd8423  vmovaps xmm7, [rsp+0x70]
00007dd052fd8429  vmovaps xmm8, [rsp+0x80]
00007dd052fd8432  vmovaps xmm9, [rsp+0x90]
00007dd052fd843b  vmovaps xmm10, [rsp+0xA0]
00007dd052fd8444  vmovaps xmm12, [rsp+0xB0]
00007dd052fd844d  vmovaps xmm13, [rsp+0xC0]
00007dd052fd8456  vmovaps xmm14, [rsp+0xD0]
00007dd052fd845f  vmovaps xmm15, [rsp+0xE0]
00007dd052fd8468  add rsp, 0xF0
00007dd052fd846f  pop r11
00007dd052fd8471  pop r10
00007dd052fd8473  pop r9
00007dd052fd8475  pop r8
00007dd052fd8477  pop rsi
00007dd052fd8478  pop rdi
00007dd052fd8479  pop rdx
00007dd052fd847a  pop rcx
00007dd052fd847b  pop rax
00007dd052fd847c  add rsp, 0x08
00007dd052fd8480  jmp 0x00007DD052FD34F4
00007dd052fd8485  sub rsp, 0x08
00007dd052fd8489  push rax
00007dd052fd848a  push rcx
00007dd052fd848b  push rdx
00007dd052fd848c  push rdi
00007dd052fd848d  push rsi
00007dd052fd848e  push r8
00007dd052fd8490  push r9
00007dd052fd8492  push r10
00007dd052fd8494  push r11
00007dd052fd8496  sub rsp, 0xF0
00007dd052fd849d  vmovaps [rsp], xmm0
00007dd052fd84a2  vmovaps [rsp+0x10], xmm1
00007dd052fd84a8  vmovaps [rsp+0x20], xmm2
00007dd052fd84ae  vmovaps [rsp+0x30], xmm3
00007dd052fd84b4  vmovaps [rsp+0x40], xmm4
00007dd052fd84ba  vmovaps [rsp+0x50], xmm5
00007dd052fd84c0  vmovaps [rsp+0x60], xmm6
00007dd052fd84c6  vmovaps [rsp+0x70], xmm7
00007dd052fd84cc  vmovaps [rsp+0x80], xmm8
00007dd052fd84d5  vmovaps [rsp+0x90], xmm9
00007dd052fd84de  vmovaps [rsp+0xA0], xmm10
00007dd052fd84e7  vmovaps [rsp+0xB0], xmm11
00007dd052fd84f0  vmovaps [rsp+0xC0], xmm12
00007dd052fd84f9  vmovaps [rsp+0xD0], xmm13
00007dd052fd8502  vmovaps [rsp+0xE0], xmm15
00007dd052fd850b  sub rsp, 0x30
00007dd052fd850f  movaps [rsp], xmm14
00007dd052fd8514  movaps [rsp+0x10], xmm12
00007dd052fd851a  movaps [rsp+0x20], xmm9
00007dd052fd8520  lea rdi, [rsp]
00007dd052fd8524  mov esi, 0x00
00007dd052fd8529  mov rax, 0x61D0404B9530
00007dd052fd8533  call rax
00007dd052fd8535  movaps xmm14, [rsp]
00007dd052fd853a  add rsp, 0x30
00007dd052fd853e  vmovaps xmm0, [rsp]
00007dd052fd8543  vmovaps xmm1, [rsp+0x10]
00007dd052fd8549  vmovaps xmm2, [rsp+0x20]
00007dd052fd854f  vmovaps xmm3, [rsp+0x30]
00007dd052fd8555  vmovaps xmm4, [rsp+0x40]
00007dd052fd855b  vmovaps xmm5, [rsp+0x50]
00007dd052fd8561  vmovaps xmm6, [rsp+0x60]
00007dd052fd8567  vmovaps xmm7, [rsp+0x70]
00007dd052fd856d  vmovaps xmm8, [rsp+0x80]
00007dd052fd8576  vmovaps xmm9, [rsp+0x90]
00007dd052fd857f  vmovaps xmm10, [rsp+0xA0]
00007dd052fd8588  vmovaps xmm11, [rsp+0xB0]
00007dd052fd8591  vmovaps xmm12, [rsp+0xC0]
00007dd052fd859a  vmovaps xmm13, [rsp+0xD0]
00007dd052fd85a3  vmovaps xmm15, [rsp+0xE0]
00007dd052fd85ac  add rsp, 0xF0
00007dd052fd85b3  pop r11
00007dd052fd85b5  pop r10
00007dd052fd85b7  pop r9
00007dd052fd85b9  pop r8
00007dd052fd85bb  pop rsi
00007dd052fd85bc  pop rdi
00007dd052fd85bd  pop rdx
00007dd052fd85be  pop rcx
00007dd052fd85bf  pop rax
00007dd052fd85c0  add rsp, 0x08
00007dd052fd85c4  jmp 0x00007DD052FD350F
00007dd052fd85c9  sub rsp, 0x08
00007dd052fd85cd  push rax
00007dd052fd85ce  push rcx
00007dd052fd85cf  push rdx
00007dd052fd85d0  push rdi
00007dd052fd85d1  push rsi
00007dd052fd85d2  push r8
00007dd052fd85d4  push r9
00007dd052fd85d6  push r10
00007dd052fd85d8  push r11
00007dd052fd85da  sub rsp, 0xF0
00007dd052fd85e1  vmovaps [rsp], xmm0
00007dd052fd85e6  vmovaps [rsp+0x10], xmm1
00007dd052fd85ec  vmovaps [rsp+0x20], xmm2
00007dd052fd85f2  vmovaps [rsp+0x30], xmm3
00007dd052fd85f8  vmovaps [rsp+0x40], xmm4
00007dd052fd85fe  vmovaps [rsp+0x50], xmm5
00007dd052fd8604  vmovaps [rsp+0x60], xmm6
00007dd052fd860a  vmovaps [rsp+0x70], xmm7
00007dd052fd8610  vmovaps [rsp+0x80], xmm8
00007dd052fd8619  vmovaps [rsp+0x90], xmm9
00007dd052fd8622  vmovaps [rsp+0xA0], xmm10
00007dd052fd862b  vmovaps [rsp+0xB0], xmm11
00007dd052fd8634  vmovaps [rsp+0xC0], xmm12
00007dd052fd863d  vmovaps [rsp+0xD0], xmm14
00007dd052fd8646  vmovaps [rsp+0xE0], xmm15
00007dd052fd864f  sub rsp, 0x30
00007dd052fd8653  movaps [rsp], xmm13
00007dd052fd8658  movaps [rsp+0x10], xmm8
00007dd052fd865e  movaps [rsp+0x20], xmm15
00007dd052fd8664  lea rdi, [rsp]
00007dd052fd8668  mov esi, 0x00
00007dd052fd866d  mov rax, 0x61D0404B9530
00007dd052fd8677  call rax
00007dd052fd8679  movaps xmm13, [rsp]
00007dd052fd867e  add rsp, 0x30
00007dd052fd8682  vmovaps xmm0, [rsp]
00007dd052fd8687  vmovaps xmm1, [rsp+0x10]
00007dd052fd868d  vmovaps xmm2, [rsp+0x20]
00007dd052fd8693  vmovaps xmm3, [rsp+0x30]
00007dd052fd8699  vmovaps xmm4, [rsp+0x40]
00007dd052fd869f  vmovaps xmm5, [rsp+0x50]
00007dd052fd86a5  vmovaps xmm6, [rsp+0x60]
00007dd052fd86ab  vmovaps xmm7, [rsp+0x70]
00007dd052fd86b1  vmovaps xmm8, [rsp+0x80]
00007dd052fd86ba  vmovaps xmm9, [rsp+0x90]
00007dd052fd86c3  vmovaps xmm10, [rsp+0xA0]
00007dd052fd86cc  vmovaps xmm11, [rsp+0xB0]
00007dd052fd86d5  vmovaps xmm12, [rsp+0xC0]
00007dd052fd86de  vmovaps xmm14, [rsp+0xD0]
00007dd052fd86e7  vmovaps xmm15, [rsp+0xE0]
00007dd052fd86f0  add rsp, 0xF0
00007dd052fd86f7  pop r11
00007dd052fd86f9  pop r10
00007dd052fd86fb  pop r9
00007dd052fd86fd  pop r8
00007dd052fd86ff  pop rsi
00007dd052fd8700  pop rdi
00007dd052fd8701  pop rdx
00007dd052fd8702  pop rcx
00007dd052fd8703  pop rax
00007dd052fd8704  add rsp, 0x08
00007dd052fd8708  jmp 0x00007DD052FD3532
00007dd052fd870d  sub rsp, 0x08
00007dd052fd8711  push rax
00007dd052fd8712  push rcx
00007dd052fd8713  push rdx
00007dd052fd8714  push rdi
00007dd052fd8715  push rsi
00007dd052fd8716  push r8
00007dd052fd8718  push r9
00007dd052fd871a  push r10
00007dd052fd871c  push r11
00007dd052fd871e  sub rsp, 0xF0
00007dd052fd8725  vmovaps [rsp], xmm0
00007dd052fd872a  vmovaps [rsp+0x10], xmm1
00007dd052fd8730  vmovaps [rsp+0x20], xmm2
00007dd052fd8736  vmovaps [rsp+0x30], xmm3
00007dd052fd873c  vmovaps [rsp+0x40], xmm4
00007dd052fd8742  vmovaps [rsp+0x50], xmm5
00007dd052fd8748  vmovaps [rsp+0x60], xmm6
00007dd052fd874e  vmovaps [rsp+0x70], xmm7
00007dd052fd8754  vmovaps [rsp+0x80], xmm8
00007dd052fd875d  vmovaps [rsp+0x90], xmm9
00007dd052fd8766  vmovaps [rsp+0xA0], xmm10
00007dd052fd876f  vmovaps [rsp+0xB0], xmm11
00007dd052fd8778  vmovaps [rsp+0xC0], xmm12
00007dd052fd8781  vmovaps [rsp+0xD0], xmm13
00007dd052fd878a  vmovaps [rsp+0xE0], xmm14
00007dd052fd8793  sub rsp, 0x30
00007dd052fd8797  movaps [rsp], xmm15
00007dd052fd879c  movaps [rsp+0x10], xmm1
00007dd052fd87a1  movaps [rsp+0x20], xmm10
00007dd052fd87a7  lea rdi, [rsp]
00007dd052fd87ab  mov esi, 0x00
00007dd052fd87b0  mov rax, 0x61D0404B9530
00007dd052fd87ba  call rax
00007dd052fd87bc  movaps xmm15, [rsp]
00007dd052fd87c1  add rsp, 0x30
00007dd052fd87c5  vmovaps xmm0, [rsp]
00007dd052fd87ca  vmovaps xmm1, [rsp+0x10]
00007dd052fd87d0  vmovaps xmm2, [rsp+0x20]
00007dd052fd87d6  vmovaps xmm3, [rsp+0x30]
00007dd052fd87dc  vmovaps xmm4, [rsp+0x40]
00007dd052fd87e2  vmovaps xmm5, [rsp+0x50]
00007dd052fd87e8  vmovaps xmm6, [rsp+0x60]
00007dd052fd87ee  vmovaps xmm7, [rsp+0x70]
00007dd052fd87f4  vmovaps xmm8, [rsp+0x80]
00007dd052fd87fd  vmovaps xmm9, [rsp+0x90]
00007dd052fd8806  vmovaps xmm10, [rsp+0xA0]
00007dd052fd880f  vmovaps xmm11, [rsp+0xB0]
00007dd052fd8818  vmovaps xmm12, [rsp+0xC0]
00007dd052fd8821  vmovaps xmm13, [rsp+0xD0]
00007dd052fd882a  vmovaps xmm14, [rsp+0xE0]
00007dd052fd8833  add rsp, 0xF0
00007dd052fd883a  pop r11
00007dd052fd883c  pop r10
00007dd052fd883e  pop r9
00007dd052fd8840  pop r8
00007dd052fd8842  pop rsi
00007dd052fd8843  pop rdi
00007dd052fd8844  pop rdx
00007dd052fd8845  pop rcx
00007dd052fd8846  pop rax
00007dd052fd8847  add rsp, 0x08
00007dd052fd884b  jmp 0x00007DD052FD3555
00007dd052fd8850  sub rsp, 0x08
00007dd052fd8854  push rax
00007dd052fd8855  push rcx
00007dd052fd8856  push rdx
00007dd052fd8857  push rdi
00007dd052fd8858  push rsi
00007dd052fd8859  push r8
00007dd052fd885b  push r9
00007dd052fd885d  push r10
00007dd052fd885f  push r11
00007dd052fd8861  sub rsp, 0xF0
00007dd052fd8868  vmovaps [rsp], xmm0
00007dd052fd886d  vmovaps [rsp+0x10], xmm2
00007dd052fd8873  vmovaps [rsp+0x20], xmm3
00007dd052fd8879  vmovaps [rsp+0x30], xmm4
00007dd052fd887f  vmovaps [rsp+0x40], xmm5
00007dd052fd8885  vmovaps [rsp+0x50], xmm6
00007dd052fd888b  vmovaps [rsp+0x60], xmm7
00007dd052fd8891  vmovaps [rsp+0x70], xmm8
00007dd052fd8897  vmovaps [rsp+0x80], xmm9
00007dd052fd88a0  vmovaps [rsp+0x90], xmm10
00007dd052fd88a9  vmovaps [rsp+0xA0], xmm11
00007dd052fd88b2  vmovaps [rsp+0xB0], xmm12
00007dd052fd88bb  vmovaps [rsp+0xC0], xmm13
00007dd052fd88c4  vmovaps [rsp+0xD0], xmm14
00007dd052fd88cd  vmovaps [rsp+0xE0], xmm15
00007dd052fd88d6  sub rsp, 0x30
00007dd052fd88da  movaps [rsp], xmm1
00007dd052fd88de  movaps [rsp+0x10], xmm7
00007dd052fd88e3  movaps [rsp+0x20], xmm11
00007dd052fd88e9  lea rdi, [rsp]
00007dd052fd88ed  mov esi, 0x00
00007dd052fd88f2  mov rax, 0x61D0404B9530
00007dd052fd88fc  call rax
00007dd052fd88fe  movaps xmm1, [rsp]
00007dd052fd8902  add rsp, 0x30
00007dd052fd8906  vmovaps xmm0, [rsp]
00007dd052fd890b  vmovaps xmm2, [rsp+0x10]
00007dd052fd8911  vmovaps xmm3, [rsp+0x20]
00007dd052fd8917  vmovaps xmm4, [rsp+0x30]
00007dd052fd891d  vmovaps xmm5, [rsp+0x40]
00007dd052fd8923  vmovaps xmm6, [rsp+0x50]
00007dd052fd8929  vmovaps xmm7, [rsp+0x60]
00007dd052fd892f  vmovaps xmm8, [rsp+0x70]
00007dd052fd8935  vmovaps xmm9, [rsp+0x80]
00007dd052fd893e  vmovaps xmm10, [rsp+0x90]
00007dd052fd8947  vmovaps xmm11, [rsp+0xA0]
00007dd052fd8950  vmovaps xmm12, [rsp+0xB0]
00007dd052fd8959  vmovaps xmm13, [rsp+0xC0]
00007dd052fd8962  vmovaps xmm14, [rsp+0xD0]
00007dd052fd896b  vmovaps xmm15, [rsp+0xE0]
00007dd052fd8974  add rsp, 0xF0
00007dd052fd897b  pop r11
00007dd052fd897d  pop r10
00007dd052fd897f  pop r9
00007dd052fd8981  pop r8
00007dd052fd8983  pop rsi
00007dd052fd8984  pop rdi
00007dd052fd8985  pop rdx
00007dd052fd8986  pop rcx
00007dd052fd8987  pop rax
00007dd052fd8988  add rsp, 0x08
00007dd052fd898c  jmp 0x00007DD052FD3576
00007dd052fd8991  call 0x00007DD052E0D600
00007dd052fd8996  jmp 0x00007DD052FD3589
00007dd052fd899b  call 0x00007DD052E0C380
00007dd052fd89a0  jmp 0x00007DD052FD3594
00007dd052fd89a5  call 0x00007DD052E0E880
00007dd052fd89aa  jmp 0x00007DD052FD359F
00007dd052fd89af  call 0x00007DD052DFF540
00007dd052fd89b4  jmp 0x00007DD052FD35AA
00007dd052fd89b9  int3
00007dd052fd89ba  nop [rax+rax*1], ax
00007dd052fd89c0  mov rax, [r15+0x40]
00007dd052fd89c4  mov r14, [r15+0x58]
00007dd052fd89c8  lea r12, [rax+r14*1]
00007dd052fd89cc  movaps xmm1, [r15+0x1D0]
00007dd052fd89d4  vmovaps [rsp+0x10], xmm1
00007dd052fd89da  vmovaps xmm15, [rsp+0x10]
00007dd052fd89e0  por xmm1, xmm15
00007dd052fd89e5  movaps xmm14, [r15+0x1A0]
00007dd052fd89ed  vmovaps [rsp+0x10], xmm14
00007dd052fd89f3  vmovaps xmm13, [rsp+0x10]
00007dd052fd89f9  por xmm14, xmm13
00007dd052fd89fe  lea rax, [r12+0x30]
00007dd052fd8a03  mov r11, [r13+rax*1]
00007dd052fd8a08  lea rax, [r12+0x38]
00007dd052fd8a0d  mov r10, [r13+rax*1]
00007dd052fd8a12  movq xmm13, r11
00007dd052fd8a17  movq xmm12, r10
00007dd052fd8a1c  movq xmm13, xmm13
00007dd052fd8a21  vmovaps [rsp+0x10], xmm13
00007dd052fd8a27  movq xmm13, xmm13
00007dd052fd8a2c  movaps [r15+0x130], xmm13
00007dd052fd8a34  movq xmm12, xmm12
00007dd052fd8a39  vmovaps [rsp+0x20], xmm12
00007dd052fd8a3f  movq xmm12, xmm12
00007dd052fd8a44  movaps [r15+0x280], xmm12
00007dd052fd8a4c  movaps xmm13, [r15+0x270]
00007dd052fd8a54  vmovaps [rsp+0x30], xmm13
00007dd052fd8a5a  vmovaps xmm12, [rsp+0x30]
00007dd052fd8a60  por xmm13, xmm12
00007dd052fd8a65  lea rax, [r12+0x20]
00007dd052fd8a6a  mov r11, [r13+rax*1]
00007dd052fd8a6f  lea rax, [r12+0x28]
00007dd052fd8a74  mov r10, [r13+rax*1]
00007dd052fd8a79  movq xmm12, r11
00007dd052fd8a7e  movq xmm11, r10
00007dd052fd8a83  movq xmm12, xmm12
00007dd052fd8a88  vmovaps [rsp+0x30], xmm12
00007dd052fd8a8e  movq xmm12, xmm12
00007dd052fd8a93  movaps [r15+0x150], xmm12
00007dd052fd8a9b  movq xmm11, xmm11
00007dd052fd8aa0  vmovaps [rsp+0x40], xmm11
00007dd052fd8aa6  movq xmm11, xmm11
00007dd052fd8aab  movaps [r15+0x140], xmm11
00007dd052fd8ab3  lea rax, [r12+0x10]
00007dd052fd8ab8  mov r11, [r13+rax*1]
00007dd052fd8abd  lea rax, [r12+0x18]
00007dd052fd8ac2  mov r10, [r13+rax*1]
00007dd052fd8ac7  movq xmm12, r11
00007dd052fd8acc  movq xmm11, r10
00007dd052fd8ad1  movq xmm12, xmm12
00007dd052fd8ad6  vmovaps [rsp+0x50], xmm12
00007dd052fd8adc  movq xmm12, xmm12
00007dd052fd8ae1  movaps [r15+0x170], xmm12
00007dd052fd8ae9  movq xmm11, xmm11
00007dd052fd8aee  vmovaps [rsp+0x60], xmm11
00007dd052fd8af4  movq xmm11, xmm11
00007dd052fd8af9  movaps [r15+0x160], xmm11
00007dd052fd8b01  mov rax, [r13+r12*1]
00007dd052fd8b06  vmovq xmm12, rax
00007dd052fd8b0b  vpbroadcastq xmm12, xmm12
00007dd052fd8b10  lea rax, [r12+0x08]
00007dd052fd8b15  mov r12, [r13+rax*1]
00007dd052fd8b1a  movq xmm11, r12
00007dd052fd8b1f  movaps [r15+0x230], xmm11
00007dd052fd8b27  mov rax, [r15+0xF8]
00007dd052fd8b2e  lea r12, [rax+0x50]
00007dd052fd8b32  movups xmm11, [r13+r12*1]
00007dd052fd8b38  lea r12, [rax+0x60]
00007dd052fd8b3c  movups xmm10, [r13+r12*1]
00007dd052fd8b42  lea r12, [rax+0x30]
00007dd052fd8b46  movups xmm9, [r13+r12*1]
00007dd052fd8b4c  mov r12, [r15+0x50]
00007dd052fd8b50  lea r11, [r12+r14*1]
00007dd052fd8b54  mov [r15+0x60], r11
00007dd052fd8b58  lea r12, [r14+0x40]
00007dd052fd8b5c  mov [r15+0x58], r12
00007dd052fd8b60  movaps xmm8, xmm12
00007dd052fd8b64  mulpd xmm8, xmm15
00007dd052fd8b69  vcmppd xmm7, xmm8, xmm8, 0x03
00007dd052fd8b6f  ptest xmm7, xmm7
00007dd052fd8b74  jnz 0x00007DD052FD9997
00007dd052fd8b7a  movq xmm15, qword ptr [r15+0x230]
00007dd052fd8b83  vmovaps [rsp+0x70], xmm15
00007dd052fd8b89  vpermilpd xmm15, xmm15, 0x00
00007dd052fd8b8f  movaps xmm7, xmm9
00007dd052fd8b93  mulpd xmm7, xmm15
00007dd052fd8b98  vcmppd xmm6, xmm7, xmm7, 0x03
00007dd052fd8b9d  ptest xmm6, xmm6
00007dd052fd8ba2  jnz 0x00007DD052FD9ADB
00007dd052fd8ba8  vxorps xmm15, xmm15, xmm15
00007dd052fd8bad  vpbroadcastq xmm15, xmm15
00007dd052fd8bb2  movaps xmm9, xmm12
00007dd052fd8bb6  mulpd xmm9, xmm10
00007dd052fd8bbb  vcmppd xmm6, xmm9, xmm9, 0x03
00007dd052fd8bc1  ptest xmm6, xmm6
00007dd052fd8bc6  jnz 0x00007DD052FD9C1D
00007dd052fd8bcc  movaps xmm10, xmm12
00007dd052fd8bd0  mulpd xmm10, xmm11
00007dd052fd8bd5  vcmppd xmm6, xmm10, xmm10, 0x03
00007dd052fd8bdb  ptest xmm6, xmm6
00007dd052fd8be0  jnz 0x00007DD052FD9D61
00007dd052fd8be6  movaps xmm11, [r15+0x1F0]
00007dd052fd8bee  movaps xmm6, xmm12
00007dd052fd8bf2  mulpd xmm6, xmm11
00007dd052fd8bf7  vcmppd xmm5, xmm6, xmm6, 0x03
00007dd052fd8bfc  ptest xmm5, xmm5
00007dd052fd8c01  jnz 0x00007DD052FD9EA5
00007dd052fd8c07  movaps xmm12, [r15+0x2A0]
00007dd052fd8c0f  vmovaps [rsp+0x80], xmm12
00007dd052fd8c18  vmovaps xmm11, [rsp+0x80]
00007dd052fd8c21  por xmm12, xmm11
00007dd052fd8c26  movaps xmm11, [r15+0x250]
00007dd052fd8c2e  vmovaps [rsp+0x80], xmm11
00007dd052fd8c37  vmovaps xmm5, [rsp+0x80]
00007dd052fd8c40  por xmm11, xmm5
00007dd052fd8c45  vmovaps xmm4, [rsp+0x70]
00007dd052fd8c4b  vpermilpd xmm4, xmm4, 0x00
00007dd052fd8c51  movaps xmm3, xmm5
00007dd052fd8c54  mulpd xmm3, xmm4
00007dd052fd8c58  vcmppd xmm2, xmm3, xmm3, 0x03
00007dd052fd8c5d  ptest xmm2, xmm2
00007dd052fd8c62  jnz 0x00007DD052FD9FE7
00007dd052fd8c68  mov [rsp+0x80], rax
00007dd052fd8c70  xor eax, eax
00007dd052fd8c72  mov r14d, 0x200
00007dd052fd8c78  cmp r12, r14
00007dd052fd8c7b  cmc
00007dd052fd8c7c  lahf
00007dd052fd8c7d  seto al
00007dd052fd8c80  mov [r15+0x108], eax
00007dd052fd8c87  movaps xmm5, xmm8
00007dd052fd8c8b  addpd xmm5, xmm15
00007dd052fd8c90  vcmppd xmm4, xmm5, xmm5, 0x03
00007dd052fd8c95  ptest xmm4, xmm4
00007dd052fd8c9a  jnz 0x00007DD052FDA127
00007dd052fd8ca0  movaps xmm8, [r15+0x1B0]
00007dd052fd8ca8  movaps xmm4, xmm9
00007dd052fd8cac  addpd xmm4, xmm8
00007dd052fd8cb1  vcmppd xmm2, xmm4, xmm4, 0x03
00007dd052fd8cb6  ptest xmm2, xmm2
00007dd052fd8cbb  jnz 0x00007DD052FDA269
00007dd052fd8cc1  movaps xmm9, xmm10
00007dd052fd8cc5  addpd xmm9, xmm8
00007dd052fd8cca  vcmppd xmm2, xmm9, xmm9, 0x03
00007dd052fd8cd0  ptest xmm2, xmm2
00007dd052fd8cd5  jnz 0x00007DD052FDA3AB
00007dd052fd8cdb  movaps xmm10, [r15+0x2F0]
00007dd052fd8ce3  vmovaps [rsp+0x90], xmm10
00007dd052fd8cec  vmovaps xmm8, [rsp+0x90]
00007dd052fd8cf5  por xmm10, xmm8
00007dd052fd8cfa  movaps xmm8, [r15+0x2E0]
00007dd052fd8d02  vmovaps [rsp+0x90], xmm8
00007dd052fd8d0b  vmovaps xmm2, [rsp+0x90]
00007dd052fd8d14  por xmm8, xmm2
00007dd052fd8d19  movaps xmm2, [r15+0x2D0]
00007dd052fd8d21  vmovaps [rsp+0x90], xmm2
00007dd052fd8d2a  vmovaps [rsp+0xA0], xmm1
00007dd052fd8d33  vmovaps xmm1, [rsp+0x90]
00007dd052fd8d3c  por xmm2, xmm1
00007dd052fd8d40  movaps xmm1, [r15+0x200]
00007dd052fd8d48  vmovaps [rsp+0x90], xmm1
00007dd052fd8d51  vmovaps [rsp+0xB0], xmm15
00007dd052fd8d5a  vmovaps xmm15, [rsp+0x90]
00007dd052fd8d63  por xmm1, xmm15
00007dd052fd8d68  movaps xmm15, [r15+0x1C0]
00007dd052fd8d70  vmovaps [rsp+0x90], xmm15
00007dd052fd8d79  vmovaps [rsp+0xC0], xmm1
00007dd052fd8d82  vmovaps xmm1, [rsp+0x90]
00007dd052fd8d8b  por xmm15, xmm1
00007dd052fd8d90  movaps xmm1, [r15+0x190]
00007dd052fd8d98  vmovaps [rsp+0x90], xmm1
00007dd052fd8da1  vmovaps [rsp+0xD0], xmm15
00007dd052fd8daa  vmovaps xmm15, [rsp+0x90]
00007dd052fd8db3  por xmm1, xmm15
00007dd052fd8db8  movaps xmm15, [r15+0x300]
00007dd052fd8dc0  vmovaps [rsp+0x90], xmm15
00007dd052fd8dc9  vmovaps [rsp+0xE0], xmm1
00007dd052fd8dd2  vmovaps xmm1, [rsp+0x90]
00007dd052fd8ddb  por xmm15, xmm1
00007dd052fd8de0  mov rax, [rsp+0x80]
00007dd052fd8de8  lea r14, [rax+0xA0]
00007dd052fd8def  movups xmm1, [r13+r14*1]
00007dd052fd8df5  lea r14, [rax+0xB0]
00007dd052fd8dfc  vmovaps [rsp+0x80], xmm1
00007dd052fd8e05  movups xmm1, [r13+r14*1]
00007dd052fd8e0b  vmovaps [rsp+0x90], xmm1
00007dd052fd8e14  vmovaps [rsp+0xF0], xmm15
00007dd052fd8e1d  vmovaps xmm15, [rsp+0xB0]
00007dd052fd8e26  vmovaps [rsp+0xB0], xmm14
00007dd052fd8e2f  movaps xmm1, xmm6
00007dd052fd8e32  addpd xmm1, xmm15
00007dd052fd8e37  vcmppd xmm14, xmm1, xmm1, 0x03
00007dd052fd8e3c  ptest xmm14, xmm14
00007dd052fd8e42  jnz 0x00007DD052FDA503
00007dd052fd8e48  lea r14, [rax+0xF0]
00007dd052fd8e4f  movups xmm15, [r13+r14*1]
00007dd052fd8e55  movaps xmm14, xmm4
00007dd052fd8e59  addpd xmm14, xmm3
00007dd052fd8e5e  vcmppd xmm6, xmm14, xmm14, 0x03
00007dd052fd8e64  ptest xmm6, xmm6
00007dd052fd8e69  jnz 0x00007DD052FDA64E
00007dd052fd8e6f  movaps xmm6, xmm9
00007dd052fd8e73  addpd xmm6, xmm7
00007dd052fd8e77  vcmppd xmm4, xmm6, xmm6, 0x03
00007dd052fd8e7c  ptest xmm4, xmm4
00007dd052fd8e81  jnz 0x00007DD052FDA790
00007dd052fd8e87  vmovaps xmm9, [rsp+0x70]
00007dd052fd8e8d  vpermilpd xmm9, xmm9, 0x00
00007dd052fd8e93  vmovaps xmm4, [rsp+0x90]
00007dd052fd8e9c  movaps xmm7, xmm4
00007dd052fd8e9f  mulpd xmm7, xmm9
00007dd052fd8ea4  vcmppd xmm3, xmm7, xmm7, 0x03
00007dd052fd8ea9  ptest xmm3, xmm3
00007dd052fd8eae  jnz 0x00007DD052FDA8D1
00007dd052fd8eb4  vmovaps xmm9, [rsp+0x50]
00007dd052fd8eba  vpermilpd xmm9, xmm9, 0x00
00007dd052fd8ec0  movaps xmm4, xmm15
00007dd052fd8ec4  mulpd xmm4, xmm9
00007dd052fd8ec9  vcmppd xmm3, xmm4, xmm4, 0x03
00007dd052fd8ece  ptest xmm3, xmm3
00007dd052fd8ed3  jnz 0x00007DD052FDAA12
00007dd052fd8ed9  lea r14, [rax+0xE0]
00007dd052fd8ee0  movups xmm15, [r13+r14*1]
00007dd052fd8ee6  vmovaps xmm9, [rsp+0x70]
00007dd052fd8eec  vpermilpd xmm9, xmm9, 0x00
00007dd052fd8ef2  vmovaps [rsp+0x70], xmm1
00007dd052fd8ef8  vmovaps xmm1, [rsp+0x80]
00007dd052fd8f01  vmovaps [rsp+0x80], xmm15
00007dd052fd8f0a  movaps xmm3, xmm1
00007dd052fd8f0d  mulpd xmm3, xmm9
00007dd052fd8f12  vcmppd xmm15, xmm3, xmm3, 0x03
00007dd052fd8f17  ptest xmm15, xmm15
00007dd052fd8f1d  jnz 0x00007DD052FDAB5E
00007dd052fd8f23  vmovaps xmm1, [rsp+0xF0]
00007dd052fd8f2c  vmovaps xmm15, [rsp+0xF0]
00007dd052fd8f35  por xmm1, xmm15
00007dd052fd8f3a  movaps [r15+0x300], xmm1
00007dd052fd8f42  vmovaps xmm15, [rsp+0xE0]
00007dd052fd8f4b  vmovaps xmm9, [rsp+0xE0]
00007dd052fd8f54  por xmm15, xmm9
00007dd052fd8f59  movaps [r15+0x190], xmm15
00007dd052fd8f61  vmovaps xmm9, [rsp+0x50]
00007dd052fd8f67  vpermilpd xmm9, xmm9, 0x00
00007dd052fd8f6d  vmovaps [rsp+0x90], xmm1
00007dd052fd8f76  vmovaps [rsp+0xE0], xmm15
00007dd052fd8f7f  vmovaps xmm15, [rsp+0x80]
00007dd052fd8f88  vmovaps [rsp+0x80], xmm14
00007dd052fd8f91  movaps xmm1, xmm15
00007dd052fd8f95  mulpd xmm1, xmm9
00007dd052fd8f9a  vcmppd xmm14, xmm1, xmm1, 0x03
00007dd052fd8f9f  ptest xmm14, xmm14
00007dd052fd8fa5  jnz 0x00007DD052FDAC9F
00007dd052fd8fab  lea r14, [rax+0x90]
00007dd052fd8fb2  movups xmm15, [r13+r14*1]
00007dd052fd8fb8  vmovaps xmm14, [rsp+0xD0]
00007dd052fd8fc1  vmovaps xmm9, [rsp+0xD0]
00007dd052fd8fca  por xmm14, xmm9
00007dd052fd8fcf  movaps [r15+0x1C0], xmm14
00007dd052fd8fd7  vmovaps xmm9, [rsp+0xC0]
00007dd052fd8fe0  vmovaps [rsp+0xD0], xmm1
00007dd052fd8fe9  vmovaps xmm1, [rsp+0xC0]
00007dd052fd8ff2  por xmm9, xmm1
00007dd052fd8ff7  movaps [r15+0x200], xmm9
00007dd052fd8fff  vmovaps [rsp+0xC0], xmm2
00007dd052fd9008  vmovaps xmm1, [rsp+0xC0]
00007dd052fd9011  por xmm2, xmm1
00007dd052fd9015  movaps [r15+0x2D0], xmm2
00007dd052fd901d  vmovaps [rsp+0xC0], xmm8
00007dd052fd9026  vmovaps xmm1, [rsp+0xC0]
00007dd052fd902f  por xmm8, xmm1
00007dd052fd9034  movaps [r15+0x2E0], xmm8
00007dd052fd903c  vmovaps [rsp+0xC0], xmm15
00007dd052fd9045  movaps xmm1, xmm5
00007dd052fd9048  addpd xmm1, xmm7
00007dd052fd904c  vcmppd xmm15, xmm1, xmm1, 0x03
00007dd052fd9051  ptest xmm15, xmm15
00007dd052fd9057  jnz 0x00007DD052FDADEB
00007dd052fd905d  vmovaps xmm15, [rsp+0x50]
00007dd052fd9063  vpermilpd xmm15, xmm15, 0x00
00007dd052fd9069  vmovaps xmm5, [rsp+0xC0]
00007dd052fd9072  vmovaps [rsp+0xC0], xmm1
00007dd052fd907b  movaps xmm7, xmm5
00007dd052fd907e  mulpd xmm7, xmm15
00007dd052fd9083  vcmppd xmm1, xmm7, xmm7, 0x03
00007dd052fd9088  ptest xmm1, xmm1
00007dd052fd908d  jnz 0x00007DD052FDAF2B
00007dd052fd9093  lea r14, [rax+0x80]
00007dd052fd909a  movups xmm1, [r13+r14*1]
00007dd052fd90a0  vmovaps xmm5, [rsp+0x70]
00007dd052fd90a6  vmovaps [rsp+0x70], xmm1
00007dd052fd90ac  movaps xmm15, xmm5
00007dd052fd90b0  addpd xmm15, xmm3
00007dd052fd90b5  vcmppd xmm1, xmm15, xmm15, 0x03
00007dd052fd90bb  ptest xmm1, xmm1
00007dd052fd90c0  jnz 0x00007DD052FDB076
00007dd052fd90c6  vmovaps xmm5, [rsp+0x80]
00007dd052fd90cf  movaps xmm1, xmm5
00007dd052fd90d2  addpd xmm1, xmm4
00007dd052fd90d6  vcmppd xmm3, xmm1, xmm1, 0x03
00007dd052fd90db  ptest xmm3, xmm3
00007dd052fd90e0  jnz 0x00007DD052FDB1B8
00007dd052fd90e6  vmovaps [rsp+0x80], xmm10
00007dd052fd90ef  vmovaps xmm5, [rsp+0x80]
00007dd052fd90f8  por xmm10, xmm5
00007dd052fd90fd  movaps [r15+0x2F0], xmm10
00007dd052fd9105  vmovaps xmm5, [rsp+0x50]
00007dd052fd910b  vpermilpd xmm5, xmm5, 0x00
00007dd052fd9111  vmovaps xmm3, [rsp+0x70]
00007dd052fd9117  vmovaps [rsp+0x50], xmm1
00007dd052fd911d  movaps xmm4, xmm3
00007dd052fd9120  mulpd xmm4, xmm5
00007dd052fd9124  vcmppd xmm1, xmm4, xmm4, 0x03
00007dd052fd9129  ptest xmm1, xmm1
00007dd052fd912e  jnz 0x00007DD052FDB2F8
00007dd052fd9134  lea r14, [rax+0xD0]
00007dd052fd913b  movups xmm1, [r13+r14*1]
00007dd052fd9141  vmovaps xmm3, [rsp+0xD0]
00007dd052fd914a  vmovaps [rsp+0x70], xmm1
00007dd052fd9150  movaps xmm5, xmm6
00007dd052fd9153  addpd xmm5, xmm3
00007dd052fd9157  vcmppd xmm1, xmm5, xmm5, 0x03
00007dd052fd915c  ptest xmm1, xmm1
00007dd052fd9161  jnz 0x00007DD052FDB442
00007dd052fd9167  vmovaps xmm1, [rsp+0x60]
00007dd052fd916d  vpermilpd xmm1, xmm1, 0x00
00007dd052fd9173  movaps xmm6, xmm9
00007dd052fd9177  mulpd xmm6, xmm1
00007dd052fd917b  vcmppd xmm3, xmm6, xmm6, 0x03
00007dd052fd9180  ptest xmm3, xmm3
00007dd052fd9185  jnz 0x00007DD052FDB582
00007dd052fd918b  movaps [r15+0x260], xmm6
00007dd052fd9193  vxorps xmm1, xmm1, xmm1
00007dd052fd9197  vpbroadcastq xmm1, xmm1
00007dd052fd919c  movaps [r15+0x1B0], xmm1
00007dd052fd91a4  vmovaps xmm1, [rsp+0x60]
00007dd052fd91aa  vpermilpd xmm1, xmm1, 0x00
00007dd052fd91b0  vmovaps xmm3, [rsp+0x70]
00007dd052fd91b6  vmovaps [rsp+0x70], xmm15
00007dd052fd91bc  movaps xmm9, xmm3
00007dd052fd91c0  mulpd xmm9, xmm1
00007dd052fd91c5  vcmppd xmm15, xmm9, xmm9, 0x03
00007dd052fd91cb  ptest xmm15, xmm15
00007dd052fd91d1  jnz 0x00007DD052FDB6C3
00007dd052fd91d7  lea r14, [rax+0xC0]
00007dd052fd91de  movups xmm1, [r13+r14*1]
00007dd052fd91e4  vmovaps xmm3, [rsp+0xC0]
00007dd052fd91ed  vmovaps [rsp+0x80], xmm1
00007dd052fd91f6  movaps xmm15, xmm3
00007dd052fd91fa  addpd xmm15, xmm7
00007dd052fd91ff  vcmppd xmm1, xmm15, xmm15, 0x03
00007dd052fd9205  ptest xmm1, xmm1
00007dd052fd920a  jnz 0x00007DD052FDB80F
00007dd052fd9210  vmovaps [rsp+0xC0], xmm13
00007dd052fd9219  vmovaps xmm1, [rsp+0xC0]
00007dd052fd9222  por xmm13, xmm1
00007dd052fd9227  movaps [r15+0x270], xmm13
00007dd052fd922f  vmovaps xmm1, [rsp+0xB0]
00007dd052fd9238  vmovaps xmm7, [rsp+0xB0]
00007dd052fd9241  por xmm1, xmm7
00007dd052fd9245  movaps [r15+0x1A0], xmm1
00007dd052fd924d  vmovaps xmm1, [rsp+0x60]
00007dd052fd9253  vpermilpd xmm1, xmm1, 0x00
00007dd052fd9259  vmovaps [rsp+0xB0], xmm1
00007dd052fd9262  vmovaps xmm1, [rsp+0x80]
00007dd052fd926b  vmovaps [rsp+0x80], xmm15
00007dd052fd9274  vmovaps xmm15, [rsp+0xB0]
00007dd052fd927d  vmovaps [rsp+0xB0], xmm14
00007dd052fd9286  movaps xmm3, xmm1
00007dd052fd9289  mulpd xmm3, xmm15
00007dd052fd928e  vcmppd xmm14, xmm3, xmm3, 0x03
00007dd052fd9293  ptest xmm14, xmm14
00007dd052fd9299  jnz 0x00007DD052FDB951
00007dd052fd929f  lea r14, [rax+0x20]
00007dd052fd92a3  movups xmm1, [r13+r14*1]
00007dd052fd92a9  movaps [r15+0x110], xmm1
00007dd052fd92b1  vmovaps xmm14, [rsp+0x70]
00007dd052fd92b7  vmovaps [rsp+0x70], xmm1
00007dd052fd92bd  movaps xmm15, xmm14
00007dd052fd92c1  addpd xmm15, xmm4
00007dd052fd92c6  vcmppd xmm1, xmm15, xmm15, 0x03
00007dd052fd92cc  ptest xmm1, xmm1
00007dd052fd92d1  jnz 0x00007DD052FDBA9C
00007dd052fd92d7  vmovaps xmm1, [rsp+0x60]
00007dd052fd92dd  vpermilpd xmm1, xmm1, 0x00
00007dd052fd92e3  movaps xmm14, xmm2
00007dd052fd92e7  mulpd xmm14, xmm1
00007dd052fd92ec  vcmppd xmm4, xmm14, xmm14, 0x03
00007dd052fd92f2  ptest xmm4, xmm4
00007dd052fd92f7  jnz 0x00007DD052FDBBDF
00007dd052fd92fd  vmovaps xmm4, [rsp+0x50]
00007dd052fd9303  movaps xmm1, xmm4
00007dd052fd9306  addpd xmm1, xmm9
00007dd052fd930b  vcmppd xmm2, xmm1, xmm1, 0x03
00007dd052fd9310  ptest xmm2, xmm2
00007dd052fd9315  jnz 0x00007DD052FDBD21
00007dd052fd931b  vmovaps xmm9, [rsp+0x30]
00007dd052fd9321  vpermilpd xmm9, xmm9, 0x00
00007dd052fd9327  vmovaps xmm2, [rsp+0x70]
00007dd052fd932d  vmovaps [rsp+0x50], xmm1
00007dd052fd9333  movaps xmm4, xmm2
00007dd052fd9336  mulpd xmm4, xmm9
00007dd052fd933b  vcmppd xmm1, xmm4, xmm4, 0x03
00007dd052fd9340  ptest xmm1, xmm1
00007dd052fd9345  jnz 0x00007DD052FDBE62
00007dd052fd934b  vmovaps xmm1, [rsp+0x30]
00007dd052fd9351  vpermilpd xmm1, xmm1, 0x00
00007dd052fd9357  vmovaps xmm2, [rsp+0x90]
00007dd052fd9360  vmovaps [rsp+0x60], xmm15
00007dd052fd9366  movaps xmm9, xmm2
00007dd052fd936a  mulpd xmm9, xmm1
00007dd052fd936f  vcmppd xmm15, xmm9, xmm9, 0x03
00007dd052fd9375  ptest xmm15, xmm15
00007dd052fd937b  jnz 0x00007DD052FDBFA3
00007dd052fd9381  vmovaps xmm15, [rsp+0x80]
00007dd052fd938a  movaps xmm1, xmm15
00007dd052fd938e  addpd xmm1, xmm6
00007dd052fd9392  vcmppd xmm2, xmm1, xmm1, 0x03
00007dd052fd9397  ptest xmm2, xmm2
00007dd052fd939c  jnz 0x00007DD052FDC0E5
00007dd052fd93a2  movaps xmm15, xmm5
00007dd052fd93a6  addpd xmm15, xmm3
00007dd052fd93ab  vcmppd xmm6, xmm15, xmm15, 0x03
00007dd052fd93b1  ptest xmm6, xmm6
00007dd052fd93b6  jnz 0x00007DD052FDC226
00007dd052fd93bc  vmovaps xmm6, [rsp+0x30]
00007dd052fd93c2  vpermilpd xmm6, xmm6, 0x00
00007dd052fd93c8  movaps xmm5, xmm8
00007dd052fd93cc  mulpd xmm5, xmm6
00007dd052fd93d0  vcmppd xmm3, xmm5, xmm5, 0x03
00007dd052fd93d5  ptest xmm3, xmm3
00007dd052fd93da  jnz 0x00007DD052FDC368
00007dd052fd93e0  vmovaps xmm8, [rsp+0x30]
00007dd052fd93e6  vpermilpd xmm8, xmm8, 0x00
00007dd052fd93ec  movaps xmm6, xmm10
00007dd052fd93f0  mulpd xmm6, xmm8
00007dd052fd93f5  vcmppd xmm3, xmm6, xmm6, 0x03
00007dd052fd93fa  ptest xmm3, xmm3
00007dd052fd93ff  jnz 0x00007DD052FDC4A9
00007dd052fd9405  vmovaps xmm8, [rsp+0x60]
00007dd052fd940b  movaps xmm10, xmm8
00007dd052fd940f  addpd xmm10, xmm14
00007dd052fd9414  vcmppd xmm3, xmm10, xmm10, 0x03
00007dd052fd941a  ptest xmm3, xmm3
00007dd052fd941f  jnz 0x00007DD052FDC5EB
00007dd052fd9425  vmovaps xmm8, [rsp+0x50]
00007dd052fd942b  movaps xmm14, xmm8
00007dd052fd942f  addpd xmm14, xmm4
00007dd052fd9434  vcmppd xmm3, xmm14, xmm14, 0x03
00007dd052fd943a  ptest xmm3, xmm3
00007dd052fd943f  jnz 0x00007DD052FDC72F
00007dd052fd9445  vmovaps xmm8, [rsp+0x40]
00007dd052fd944b  vpermilpd xmm8, xmm8, 0x00
00007dd052fd9451  movaps xmm4, xmm13
00007dd052fd9455  mulpd xmm4, xmm8
00007dd052fd945a  vcmppd xmm3, xmm4, xmm4, 0x03
00007dd052fd945f  ptest xmm3, xmm3
00007dd052fd9464  jnz 0x00007DD052FDC872
00007dd052fd946a  movaps xmm13, xmm15
00007dd052fd946e  addpd xmm13, xmm9
00007dd052fd9473  vcmppd xmm8, xmm13, xmm13, 0x03
00007dd052fd9479  ptest xmm8, xmm8
00007dd052fd947f  jnz 0x00007DD052FDC9B4
00007dd052fd9485  movaps xmm15, xmm1
00007dd052fd9489  addpd xmm15, xmm5
00007dd052fd948e  vcmppd xmm9, xmm15, xmm15, 0x03
00007dd052fd9494  ptest xmm9, xmm9
00007dd052fd949a  jnz 0x00007DD052FDCAF8
00007dd052fd94a0  vmovaps [rsp+0x30], xmm11
00007dd052fd94a6  vmovaps xmm1, [rsp+0x30]
00007dd052fd94ac  por xmm11, xmm1
00007dd052fd94b1  movaps [r15+0x250], xmm11
00007dd052fd94b9  vmovaps [rsp+0x30], xmm12
00007dd052fd94bf  vmovaps xmm1, [rsp+0x30]
00007dd052fd94c5  por xmm12, xmm1
00007dd052fd94ca  movaps [r15+0x2A0], xmm12
00007dd052fd94d2  vmovaps xmm1, [rsp+0xA0]
00007dd052fd94db  vmovaps xmm11, [rsp+0xA0]
00007dd052fd94e4  por xmm1, xmm11
00007dd052fd94e9  movaps [r15+0x1D0], xmm1
00007dd052fd94f1  lea r14, [rax+0x40]
00007dd052fd94f5  movups xmm1, [r13+r14*1]
00007dd052fd94fb  movaps [r15+0x2C0], xmm1
00007dd052fd9503  vmovaps xmm11, [rsp+0x40]
00007dd052fd9509  vpermilpd xmm11, xmm11, 0x00
00007dd052fd950f  vmovaps xmm8, [rsp+0xE0]
00007dd052fd9518  movaps xmm9, xmm8
00007dd052fd951c  mulpd xmm9, xmm11
00007dd052fd9521  vcmppd xmm5, xmm9, xmm9, 0x03
00007dd052fd9527  ptest xmm5, xmm5
00007dd052fd952c  jnz 0x00007DD052FDCC44
00007dd052fd9532  movaps xmm11, xmm10
00007dd052fd9536  addpd xmm11, xmm6
00007dd052fd953b  vcmppd xmm8, xmm11, xmm11, 0x03
00007dd052fd9541  ptest xmm8, xmm8
00007dd052fd9547  jnz 0x00007DD052FDCD88
00007dd052fd954d  movaps xmm10, xmm14
00007dd052fd9551  addpd xmm10, xmm4
00007dd052fd9556  vcmppd xmm8, xmm10, xmm10, 0x03
00007dd052fd955c  ptest xmm8, xmm8
00007dd052fd9562  jnz 0x00007DD052FDCECB
00007dd052fd9568  vmovaps xmm14, [rsp+0x40]
00007dd052fd956e  vpermilpd xmm14, xmm14, 0x00
00007dd052fd9574  movaps xmm8, xmm1
00007dd052fd9578  mulpd xmm8, xmm14
00007dd052fd957d  vcmppd xmm6, xmm8, xmm8, 0x03
00007dd052fd9583  ptest xmm6, xmm6
00007dd052fd9588  jnz 0x00007DD052FDD00E
00007dd052fd958e  movaps xmm1, [r15+0x2B0]
00007dd052fd9596  vmovaps xmm14, [rsp+0x40]
00007dd052fd959c  vpermilpd xmm14, xmm14, 0x00
00007dd052fd95a2  movaps xmm6, xmm1
00007dd052fd95a5  mulpd xmm6, xmm14
00007dd052fd95aa  vcmppd xmm5, xmm6, xmm6, 0x03
00007dd052fd95af  ptest xmm5, xmm5
00007dd052fd95b4  jnz 0x00007DD052FDD151
00007dd052fd95ba  vmovaps xmm1, [rsp+0x10]
00007dd052fd95c0  vpermilpd xmm1, xmm1, 0x00
00007dd052fd95c6  movaps xmm14, xmm12
00007dd052fd95ca  mulpd xmm14, xmm1
00007dd052fd95cf  vcmppd xmm5, xmm14, xmm14, 0x03
00007dd052fd95d5  ptest xmm5, xmm5
00007dd052fd95da  jnz 0x00007DD052FDD292
00007dd052fd95e0  movaps xmm1, xmm13
00007dd052fd95e4  addpd xmm1, xmm9
00007dd052fd95e9  vcmppd xmm12, xmm1, xmm1, 0x03
00007dd052fd95ee  ptest xmm12, xmm12
00007dd052fd95f4  jnz 0x00007DD052FDD3D5
00007dd052fd95fa  vmovaps xmm13, [rsp+0x10]
00007dd052fd9600  vpermilpd xmm13, xmm13, 0x00
00007dd052fd9606  movaps xmm12, xmm7
00007dd052fd960a  mulpd xmm12, xmm13
00007dd052fd960f  vcmppd xmm9, xmm12, xmm12, 0x03
00007dd052fd9615  ptest xmm9, xmm9
00007dd052fd961b  jnz 0x00007DD052FDD517
00007dd052fd9621  movaps xmm13, xmm15
00007dd052fd9625  addpd xmm13, xmm8
00007dd052fd962a  vcmppd xmm9, xmm13, xmm13, 0x03
00007dd052fd9630  ptest xmm9, xmm9
00007dd052fd9636  jnz 0x00007DD052FDD65A
00007dd052fd963c  movaps xmm15, [r15+0x290]
00007dd052fd9644  vmovaps xmm9, [rsp+0x10]
00007dd052fd964a  vpermilpd xmm9, xmm9, 0x00
00007dd052fd9650  movaps xmm8, xmm15
00007dd052fd9654  mulpd xmm8, xmm9
00007dd052fd9659  vcmppd xmm7, xmm8, xmm8, 0x03
00007dd052fd965f  ptest xmm7, xmm7
00007dd052fd9664  jnz 0x00007DD052FDD79E
00007dd052fd966a  movaps xmm15, xmm11
00007dd052fd966e  addpd xmm15, xmm6
00007dd052fd9673  vcmppd xmm9, xmm15, xmm15, 0x03
00007dd052fd9679  ptest xmm9, xmm9
00007dd052fd967f  jnz 0x00007DD052FDD8E2
00007dd052fd9685  movaps xmm11, [r15+0x1E0]
00007dd052fd968d  vmovaps xmm9, [rsp+0x10]
00007dd052fd9693  vpermilpd xmm9, xmm9, 0x00
00007dd052fd9699  movaps xmm7, xmm11
00007dd052fd969d  mulpd xmm7, xmm9
00007dd052fd96a2  vcmppd xmm6, xmm7, xmm7, 0x03
00007dd052fd96a7  ptest xmm6, xmm6
00007dd052fd96ac  jnz 0x00007DD052FDDA25
00007dd052fd96b2  movaps xmm11, xmm10
00007dd052fd96b6  addpd xmm11, xmm14
00007dd052fd96bb  vcmppd xmm9, xmm11, xmm11, 0x03
00007dd052fd96c1  ptest xmm9, xmm9
00007dd052fd96c7  jnz 0x00007DD052FDDB67
00007dd052fd96cd  lea r14, [rax+0x70]
00007dd052fd96d1  movups xmm14, [r13+r14*1]
00007dd052fd96d7  movaps [r15+0x240], xmm14
00007dd052fd96df  movaps xmm10, xmm1
00007dd052fd96e3  addpd xmm10, xmm12
00007dd052fd96e8  vcmppd xmm9, xmm10, xmm10, 0x03
00007dd052fd96ee  ptest xmm9, xmm9
00007dd052fd96f4  jnz 0x00007DD052FDDCB5
00007dd052fd96fa  movaps [r15+0x170], xmm10
00007dd052fd9702  vmovaps xmm1, [rsp+0x20]
00007dd052fd9708  vpermilpd xmm1, xmm1, 0x00
00007dd052fd970e  movaps xmm12, xmm14
00007dd052fd9712  mulpd xmm12, xmm1
00007dd052fd9717  vcmppd xmm9, xmm12, xmm12, 0x03
00007dd052fd971d  ptest xmm9, xmm9
00007dd052fd9723  jnz 0x00007DD052FDDDF8
00007dd052fd9729  vmovaps xmm1, [rsp+0x20]
00007dd052fd972f  vpermilpd xmm1, xmm1, 0x00
00007dd052fd9735  vmovaps xmm9, [rsp+0xB0]
00007dd052fd973e  movaps xmm14, xmm9
00007dd052fd9742  mulpd xmm14, xmm1
00007dd052fd9747  vcmppd xmm6, xmm14, xmm14, 0x03
00007dd052fd974d  ptest xmm6, xmm6
00007dd052fd9752  jnz 0x00007DD052FDDF3B
00007dd052fd9758  movaps [r15+0x180], xmm14
00007dd052fd9760  movaps xmm1, xmm13
00007dd052fd9764  addpd xmm1, xmm8
00007dd052fd9769  vcmppd xmm9, xmm1, xmm1, 0x03
00007dd052fd976e  ptest xmm9, xmm9
00007dd052fd9774  jnz 0x00007DD052FDE07E
00007dd052fd977a  movaps [r15+0x210], xmm1
00007dd052fd9782  movups xmm13, [r13+rax*1]
00007dd052fd9788  lea r14, [rax+0x10]
00007dd052fd978c  movups xmm9, [r13+r14*1]
00007dd052fd9792  movaps [r15+0x230], xmm9
00007dd052fd979a  movaps xmm8, xmm15
00007dd052fd979e  addpd xmm8, xmm7
00007dd052fd97a3  vcmppd xmm6, xmm8, xmm8, 0x03
00007dd052fd97a9  ptest xmm6, xmm6
00007dd052fd97ae  jnz 0x00007DD052FDE1D4
00007dd052fd97b4  movaps [r15+0x130], xmm8
00007dd052fd97bc  vmovaps xmm15, [rsp+0x20]
00007dd052fd97c2  vpermilpd xmm15, xmm15, 0x00
00007dd052fd97c8  movaps xmm7, xmm9
00007dd052fd97cc  mulpd xmm7, xmm15
00007dd052fd97d1  vcmppd xmm6, xmm7, xmm7, 0x03
00007dd052fd97d6  ptest xmm6, xmm6
00007dd052fd97db  jnz 0x00007DD052FDE317
00007dd052fd97e1  movaps [r15+0x220], xmm7
00007dd052fd97e9  vmovaps xmm15, [rsp+0x20]
00007dd052fd97ef  vpermilpd xmm15, xmm15, 0x00
00007dd052fd97f5  movaps xmm9, xmm13
00007dd052fd97f9  mulpd xmm9, xmm15
00007dd052fd97fe  vcmppd xmm6, xmm9, xmm9, 0x03
00007dd052fd9804  ptest xmm6, xmm6
00007dd052fd9809  jnz 0x00007DD052FDE459
00007dd052fd980f  movaps xmm15, xmm11
00007dd052fd9813  addpd xmm15, xmm12
00007dd052fd9818  vcmppd xmm13, xmm15, xmm15, 0x03
00007dd052fd981e  ptest xmm13, xmm13
00007dd052fd9824  jnz 0x00007DD052FDE59D
00007dd052fd982a  movaps [r15+0x140], xmm15
00007dd052fd9832  movaps xmm13, xmm10
00007dd052fd9836  addpd xmm13, xmm14
00007dd052fd983b  vcmppd xmm12, xmm13, xmm13, 0x03
00007dd052fd9841  ptest xmm12, xmm12
00007dd052fd9847  jnz 0x00007DD052FDE6E1
00007dd052fd984d  movaps [r15+0x150], xmm13
00007dd052fd9855  movaps xmm14, xmm1
00007dd052fd9859  addpd xmm14, xmm7
00007dd052fd985e  vcmppd xmm12, xmm14, xmm14, 0x03
00007dd052fd9864  ptest xmm12, xmm12
00007dd052fd986a  jnz 0x00007DD052FDE825
00007dd052fd9870  movaps [r15+0x160], xmm14
00007dd052fd9878  movaps xmm1, xmm8
00007dd052fd987c  addpd xmm1, xmm9
00007dd052fd9881  vcmppd xmm12, xmm1, xmm1, 0x03
00007dd052fd9886  ptest xmm12, xmm12
00007dd052fd988c  jnz 0x00007DD052FDE967
00007dd052fd9892  movaps [r15+0x120], xmm1
00007dd052fd989a  movups [r13+r11*1], xmm15
00007dd052fd98a0  lea rax, [r11+0x10]
00007dd052fd98a4  movups [r13+rax*1], xmm13
00007dd052fd98aa  lea rax, [r11+0x20]
00007dd052fd98ae  movups [r13+rax*1], xmm14
00007dd052fd98b4  lea rax, [r11+0x30]
00007dd052fd98b8  movups [r13+rax*1], xmm1
00007dd052fd98be  mov eax, [r15+0x108]
00007dd052fd98c5  sahf
00007dd052fd98c6  jnz 0x00007DD052FD98F8
00007dd052fd98c8  cmp dword ptr [r15+0x318], 0x00
00007dd052fd98d0  jz 0x00007DD052FDEAE0
00007dd052fd98d6  nop [rax+rax*1], ax
00007dd052fd98df  nop [rax+rax*1], eax
00007dd052fd98e7  mov eax, 0x4106D0
00007dd052fd98ec  mov [r15+0x100], rax
00007dd052fd98f3  jmp 0x00007DD052DFE110
00007dd052fd98f8  cmp dword ptr [r15+0x318], 0x00
00007dd052fd9900  jz 0x00007DD052FD89C0
00007dd052fd9906  nop [rax+rax*1], ax
00007dd052fd990f  nop [rax+rax*1], eax
00007dd052fd9917  mov eax, 0x410504
00007dd052fd991c  mov [r15+0x100], rax
00007dd052fd9923  jmp 0x00007DD052DFE110
00007dd052fd9928  int3
00007dd052fd9929  call 0x00007DD052E0A4B0
00007dd052fd992e  jmp 0x00007DD052FD8A08
00007dd052fd9933  call 0x00007DD052E09240
00007dd052fd9938  jmp 0x00007DD052FD8A12
00007dd052fd993d  call 0x00007DD052E0A4B0
00007dd052fd9942  jmp 0x00007DD052FD8A6F
00007dd052fd9947  call 0x00007DD052E09240
00007dd052fd994c  jmp 0x00007DD052FD8A79
00007dd052fd9951  call 0x00007DD052E0A4B0
00007dd052fd9956  jmp 0x00007DD052FD8ABD
00007dd052fd995b  call 0x00007DD052E09240
00007dd052fd9960  jmp 0x00007DD052FD8AC7
00007dd052fd9965  call 0x00007DD052EB47C0
00007dd052fd996a  jmp 0x00007DD052FD8B06
00007dd052fd996f  call 0x00007DD052E0B720
00007dd052fd9974  jmp 0x00007DD052FD8B1A
00007dd052fd9979  call 0x00007DD052EBFC30
00007dd052fd997e  jmp 0x00007DD052FD8B38
00007dd052fd9983  call 0x00007DD052EBE9C0
00007dd052fd9988  jmp 0x00007DD052FD8B42
00007dd052fd998d  call 0x00007DD052EBD750
00007dd052fd9992  jmp 0x00007DD052FD8B4C
00007dd052fd9997  sub rsp, 0x08
00007dd052fd999b  push rax
00007dd052fd999c  push rcx
00007dd052fd999d  push rdx
00007dd052fd999e  push rdi
00007dd052fd999f  push rsi
00007dd052fd99a0  push r8
00007dd052fd99a2  push r9
00007dd052fd99a4  push r10
00007dd052fd99a6  push r11
00007dd052fd99a8  sub rsp, 0xF0
00007dd052fd99af  vmovaps [rsp], xmm0
00007dd052fd99b4  vmovaps [rsp+0x10], xmm1
00007dd052fd99ba  vmovaps [rsp+0x20], xmm2
00007dd052fd99c0  vmovaps [rsp+0x30], xmm3
00007dd052fd99c6  vmovaps [rsp+0x40], xmm4
00007dd052fd99cc  vmovaps [rsp+0x50], xmm5
00007dd052fd99d2  vmovaps [rsp+0x60], xmm6
00007dd052fd99d8  vmovaps [rsp+0x70], xmm7
00007dd052fd99de  vmovaps [rsp+0x80], xmm9
00007dd052fd99e7  vmovaps [rsp+0x90], xmm10
00007dd052fd99f0  vmovaps [rsp+0xA0], xmm11
00007dd052fd99f9  vmovaps [rsp+0xB0], xmm12
00007dd052fd9a02  vmovaps [rsp+0xC0], xmm13
00007dd052fd9a0b  vmovaps [rsp+0xD0], xmm14
00007dd052fd9a14  vmovaps [rsp+0xE0], xmm15
00007dd052fd9a1d  sub rsp, 0x30
00007dd052fd9a21  movaps [rsp], xmm8
00007dd052fd9a26  movaps [rsp+0x10], xmm12
00007dd052fd9a2c  movaps [rsp+0x20], xmm15
00007dd052fd9a32  lea rdi, [rsp]
00007dd052fd9a36  mov esi, 0x00
00007dd052fd9a3b  mov rax, 0x61D0404B9530
00007dd052fd9a45  call rax
00007dd052fd9a47  movaps xmm8, [rsp]
00007dd052fd9a4c  add rsp, 0x30
00007dd052fd9a50  vmovaps xmm0, [rsp]
00007dd052fd9a55  vmovaps xmm1, [rsp+0x10]
00007dd052fd9a5b  vmovaps xmm2, [rsp+0x20]
00007dd052fd9a61  vmovaps xmm3, [rsp+0x30]
00007dd052fd9a67  vmovaps xmm4, [rsp+0x40]
00007dd052fd9a6d  vmovaps xmm5, [rsp+0x50]
00007dd052fd9a73  vmovaps xmm6, [rsp+0x60]
00007dd052fd9a79  vmovaps xmm7, [rsp+0x70]
00007dd052fd9a7f  vmovaps xmm9, [rsp+0x80]
00007dd052fd9a88  vmovaps xmm10, [rsp+0x90]
00007dd052fd9a91  vmovaps xmm11, [rsp+0xA0]
00007dd052fd9a9a  vmovaps xmm12, [rsp+0xB0]
00007dd052fd9aa3  vmovaps xmm13, [rsp+0xC0]
00007dd052fd9aac  vmovaps xmm14, [rsp+0xD0]
00007dd052fd9ab5  vmovaps xmm15, [rsp+0xE0]
00007dd052fd9abe  add rsp, 0xF0
00007dd052fd9ac5  pop r11
00007dd052fd9ac7  pop r10
00007dd052fd9ac9  pop r9
00007dd052fd9acb  pop r8
00007dd052fd9acd  pop rsi
00007dd052fd9ace  pop rdi
00007dd052fd9acf  pop rdx
00007dd052fd9ad0  pop rcx
00007dd052fd9ad1  pop rax
00007dd052fd9ad2  add rsp, 0x08
00007dd052fd9ad6  jmp 0x00007DD052FD8B7A
00007dd052fd9adb  sub rsp, 0x08
00007dd052fd9adf  push rax
00007dd052fd9ae0  push rcx
00007dd052fd9ae1  push rdx
00007dd052fd9ae2  push rdi
00007dd052fd9ae3  push rsi
00007dd052fd9ae4  push r8
00007dd052fd9ae6  push r9
00007dd052fd9ae8  push r10
00007dd052fd9aea  push r11
00007dd052fd9aec  sub rsp, 0xF0
00007dd052fd9af3  vmovaps [rsp], xmm0
00007dd052fd9af8  vmovaps [rsp+0x10], xmm1
00007dd052fd9afe  vmovaps [rsp+0x20], xmm2
00007dd052fd9b04  vmovaps [rsp+0x30], xmm3
00007dd052fd9b0a  vmovaps [rsp+0x40], xmm4
00007dd052fd9b10  vmovaps [rsp+0x50], xmm5
00007dd052fd9b16  vmovaps [rsp+0x60], xmm6
00007dd052fd9b1c  vmovaps [rsp+0x70], xmm8
00007dd052fd9b22  vmovaps [rsp+0x80], xmm9
00007dd052fd9b2b  vmovaps [rsp+0x90], xmm10
00007dd052fd9b34  vmovaps [rsp+0xA0], xmm11
00007dd052fd9b3d  vmovaps [rsp+0xB0], xmm12
00007dd052fd9b46  vmovaps [rsp+0xC0], xmm13
00007dd052fd9b4f  vmovaps [rsp+0xD0], xmm14
00007dd052fd9b58  vmovaps [rsp+0xE0], xmm15
00007dd052fd9b61  sub rsp, 0x30
00007dd052fd9b65  movaps [rsp], xmm7
00007dd052fd9b69  movaps [rsp+0x10], xmm9
00007dd052fd9b6f  movaps [rsp+0x20], xmm15
00007dd052fd9b75  lea rdi, [rsp]
00007dd052fd9b79  mov esi, 0x00
00007dd052fd9b7e  mov rax, 0x61D0404B9530
00007dd052fd9b88  call rax
00007dd052fd9b8a  movaps xmm7, [rsp]
00007dd052fd9b8e  add rsp, 0x30
00007dd052fd9b92  vmovaps xmm0, [rsp]
00007dd052fd9b97  vmovaps xmm1, [rsp+0x10]
00007dd052fd9b9d  vmovaps xmm2, [rsp+0x20]
00007dd052fd9ba3  vmovaps xmm3, [rsp+0x30]
00007dd052fd9ba9  vmovaps xmm4, [rsp+0x40]
00007dd052fd9baf  vmovaps xmm5, [rsp+0x50]
00007dd052fd9bb5  vmovaps xmm6, [rsp+0x60]
00007dd052fd9bbb  vmovaps xmm8, [rsp+0x70]
00007dd052fd9bc1  vmovaps xmm9, [rsp+0x80]
00007dd052fd9bca  vmovaps xmm10, [rsp+0x90]
00007dd052fd9bd3  vmovaps xmm11, [rsp+0xA0]
00007dd052fd9bdc  vmovaps xmm12, [rsp+0xB0]
00007dd052fd9be5  vmovaps xmm13, [rsp+0xC0]
00007dd052fd9bee  vmovaps xmm14, [rsp+0xD0]
00007dd052fd9bf7  vmovaps xmm15, [rsp+0xE0]
00007dd052fd9c00  add rsp, 0xF0
00007dd052fd9c07  pop r11
00007dd052fd9c09  pop r10
00007dd052fd9c0b  pop r9
00007dd052fd9c0d  pop r8
00007dd052fd9c0f  pop rsi
00007dd052fd9c10  pop rdi
00007dd052fd9c11  pop rdx
00007dd052fd9c12  pop rcx
00007dd052fd9c13  pop rax
00007dd052fd9c14  add rsp, 0x08
00007dd052fd9c18  jmp 0x00007DD052FD8BA8
00007dd052fd9c1d  sub rsp, 0x08
00007dd052fd9c21  push rax
00007dd052fd9c22  push rcx
00007dd052fd9c23  push rdx
00007dd052fd9c24  push rdi
00007dd052fd9c25  push rsi
00007dd052fd9c26  push r8
00007dd052fd9c28  push r9
00007dd052fd9c2a  push r10
00007dd052fd9c2c  push r11
00007dd052fd9c2e  sub rsp, 0xF0
00007dd052fd9c35  vmovaps [rsp], xmm0
00007dd052fd9c3a  vmovaps [rsp+0x10], xmm1
00007dd052fd9c40  vmovaps [rsp+0x20], xmm2
00007dd052fd9c46  vmovaps [rsp+0x30], xmm3
00007dd052fd9c4c  vmovaps [rsp+0x40], xmm4
00007dd052fd9c52  vmovaps [rsp+0x50], xmm5
00007dd052fd9c58  vmovaps [rsp+0x60], xmm6
00007dd052fd9c5e  vmovaps [rsp+0x70], xmm7
00007dd052fd9c64  vmovaps [rsp+0x80], xmm8
00007dd052fd9c6d  vmovaps [rsp+0x90], xmm10
00007dd052fd9c76  vmovaps [rsp+0xA0], xmm11
00007dd052fd9c7f  vmovaps [rsp+0xB0], xmm12
00007dd052fd9c88  vmovaps [rsp+0xC0], xmm13
00007dd052fd9c91  vmovaps [rsp+0xD0], xmm14
00007dd052fd9c9a  vmovaps [rsp+0xE0], xmm15
00007dd052fd9ca3  sub rsp, 0x30
00007dd052fd9ca7  movaps [rsp], xmm9
00007dd052fd9cac  movaps [rsp+0x10], xmm12
00007dd052fd9cb2  movaps [rsp+0x20], xmm10
00007dd052fd9cb8  lea rdi, [rsp]
00007dd052fd9cbc  mov esi, 0x00
00007dd052fd9cc1  mov rax, 0x61D0404B9530
00007dd052fd9ccb  call rax
00007dd052fd9ccd  movaps xmm9, [rsp]
00007dd052fd9cd2  add rsp, 0x30
00007dd052fd9cd6  vmovaps xmm0, [rsp]
00007dd052fd9cdb  vmovaps xmm1, [rsp+0x10]
00007dd052fd9ce1  vmovaps xmm2, [rsp+0x20]
00007dd052fd9ce7  vmovaps xmm3, [rsp+0x30]
00007dd052fd9ced  vmovaps xmm4, [rsp+0x40]
00007dd052fd9cf3  vmovaps xmm5, [rsp+0x50]
00007dd052fd9cf9  vmovaps xmm6, [rsp+0x60]
00007dd052fd9cff  vmovaps xmm7, [rsp+0x70]
00007dd052fd9d05  vmovaps xmm8, [rsp+0x80]
00007dd052fd9d0e  vmovaps xmm10, [rsp+0x90]
00007dd052fd9d17  vmovaps xmm11, [rsp+0xA0]
00007dd052fd9d20  vmovaps xmm12, [rsp+0xB0]
00007dd052fd9d29  vmovaps xmm13, [rsp+0xC0]
00007dd052fd9d32  vmovaps xmm14, [rsp+0xD0]
00007dd052fd9d3b  vmovaps xmm15, [rsp+0xE0]
00007dd052fd9d44  add rsp, 0xF0
00007dd052fd9d4b  pop r11
00007dd052fd9d4d  pop r10
00007dd052fd9d4f  pop r9
00007dd052fd9d51  pop r8
00007dd052fd9d53  pop rsi
00007dd052fd9d54  pop rdi
00007dd052fd9d55  pop rdx
00007dd052fd9d56  pop rcx
00007dd052fd9d57  pop rax
00007dd052fd9d58  add rsp, 0x08
00007dd052fd9d5c  jmp 0x00007DD052FD8BCC
00007dd052fd9d61  sub rsp, 0x08
00007dd052fd9d65  push rax
00007dd052fd9d66  push rcx
00007dd052fd9d67  push rdx
00007dd052fd9d68  push rdi
00007dd052fd9d69  push rsi
00007dd052fd9d6a  push r8
00007dd052fd9d6c  push r9
00007dd052fd9d6e  push r10
00007dd052fd9d70  push r11
00007dd052fd9d72  sub rsp, 0xF0
00007dd052fd9d79  vmovaps [rsp], xmm0
00007dd052fd9d7e  vmovaps [rsp+0x10], xmm1
00007dd052fd9d84  vmovaps [rsp+0x20], xmm2
00007dd052fd9d8a  vmovaps [rsp+0x30], xmm3
00007dd052fd9d90  vmovaps [rsp+0x40], xmm4
00007dd052fd9d96  vmovaps [rsp+0x50], xmm5
00007dd052fd9d9c  vmovaps [rsp+0x60], xmm6
00007dd052fd9da2  vmovaps [rsp+0x70], xmm7
00007dd052fd9da8  vmovaps [rsp+0x80], xmm8
00007dd052fd9db1  vmovaps [rsp+0x90], xmm9
00007dd052fd9dba  vmovaps [rsp+0xA0], xmm11
00007dd052fd9dc3  vmovaps [rsp+0xB0], xmm12
00007dd052fd9dcc  vmovaps [rsp+0xC0], xmm13
00007dd052fd9dd5  vmovaps [rsp+0xD0], xmm14
00007dd052fd9dde  vmovaps [rsp+0xE0], xmm15
00007dd052fd9de7  sub rsp, 0x30
00007dd052fd9deb  movaps [rsp], xmm10
00007dd052fd9df0  movaps [rsp+0x10], xmm12
00007dd052fd9df6  movaps [rsp+0x20], xmm11
00007dd052fd9dfc  lea rdi, [rsp]
00007dd052fd9e00  mov esi, 0x00
00007dd052fd9e05  mov rax, 0x61D0404B9530
00007dd052fd9e0f  call rax
00007dd052fd9e11  movaps xmm10, [rsp]
00007dd052fd9e16  add rsp, 0x30
00007dd052fd9e1a  vmovaps xmm0, [rsp]
00007dd052fd9e1f  vmovaps xmm1, [rsp+0x10]
00007dd052fd9e25  vmovaps xmm2, [rsp+0x20]
00007dd052fd9e2b  vmovaps xmm3, [rsp+0x30]
00007dd052fd9e31  vmovaps xmm4, [rsp+0x40]
00007dd052fd9e37  vmovaps xmm5, [rsp+0x50]
00007dd052fd9e3d  vmovaps xmm6, [rsp+0x60]
00007dd052fd9e43  vmovaps xmm7, [rsp+0x70]
00007dd052fd9e49  vmovaps xmm8, [rsp+0x80]
00007dd052fd9e52  vmovaps xmm9, [rsp+0x90]
00007dd052fd9e5b  vmovaps xmm11, [rsp+0xA0]
00007dd052fd9e64  vmovaps xmm12, [rsp+0xB0]
00007dd052fd9e6d  vmovaps xmm13, [rsp+0xC0]
00007dd052fd9e76  vmovaps xmm14, [rsp+0xD0]
00007dd052fd9e7f  vmovaps xmm15, [rsp+0xE0]
00007dd052fd9e88  add rsp, 0xF0
00007dd052fd9e8f  pop r11
00007dd052fd9e91  pop r10
00007dd052fd9e93  pop r9
00007dd052fd9e95  pop r8
00007dd052fd9e97  pop rsi
00007dd052fd9e98  pop rdi
00007dd052fd9e99  pop rdx
00007dd052fd9e9a  pop rcx
00007dd052fd9e9b  pop rax
00007dd052fd9e9c  add rsp, 0x08
00007dd052fd9ea0  jmp 0x00007DD052FD8BE6
00007dd052fd9ea5  sub rsp, 0x08
00007dd052fd9ea9  push rax
00007dd052fd9eaa  push rcx
00007dd052fd9eab  push rdx
00007dd052fd9eac  push rdi
00007dd052fd9ead  push rsi
00007dd052fd9eae  push r8
00007dd052fd9eb0  push r9
00007dd052fd9eb2  push r10
00007dd052fd9eb4  push r11
00007dd052fd9eb6  sub rsp, 0xF0
00007dd052fd9ebd  vmovaps [rsp], xmm0
00007dd052fd9ec2  vmovaps [rsp+0x10], xmm1
00007dd052fd9ec8  vmovaps [rsp+0x20], xmm2
00007dd052fd9ece  vmovaps [rsp+0x30], xmm3
00007dd052fd9ed4  vmovaps [rsp+0x40], xmm4
00007dd052fd9eda  vmovaps [rsp+0x50], xmm5
00007dd052fd9ee0  vmovaps [rsp+0x60], xmm7
00007dd052fd9ee6  vmovaps [rsp+0x70], xmm8
00007dd052fd9eec  vmovaps [rsp+0x80], xmm9
00007dd052fd9ef5  vmovaps [rsp+0x90], xmm10
00007dd052fd9efe  vmovaps [rsp+0xA0], xmm11
00007dd052fd9f07  vmovaps [rsp+0xB0], xmm12
00007dd052fd9f10  vmovaps [rsp+0xC0], xmm13
00007dd052fd9f19  vmovaps [rsp+0xD0], xmm14
00007dd052fd9f22  vmovaps [rsp+0xE0], xmm15
00007dd052fd9f2b  sub rsp, 0x30
00007dd052fd9f2f  movaps [rsp], xmm6
00007dd052fd9f33  movaps [rsp+0x10], xmm12
00007dd052fd9f39  movaps [rsp+0x20], xmm11
00007dd052fd9f3f  lea rdi, [rsp]
00007dd052fd9f43  mov esi, 0x00
00007dd052fd9f48  mov rax, 0x61D0404B9530
00007dd052fd9f52  call rax
00007dd052fd9f54  movaps xmm6, [rsp]
00007dd052fd9f58  add rsp, 0x30
00007dd052fd9f5c  vmovaps xmm0, [rsp]
00007dd052fd9f61  vmovaps xmm1, [rsp+0x10]
00007dd052fd9f67  vmovaps xmm2, [rsp+0x20]
00007dd052fd9f6d  vmovaps xmm3, [rsp+0x30]
00007dd052fd9f73  vmovaps xmm4, [rsp+0x40]
00007dd052fd9f79  vmovaps xmm5, [rsp+0x50]
00007dd052fd9f7f  vmovaps xmm7, [rsp+0x60]
00007dd052fd9f85  vmovaps xmm8, [rsp+0x70]
00007dd052fd9f8b  vmovaps xmm9, [rsp+0x80]
00007dd052fd9f94  vmovaps xmm10, [rsp+0x90]
00007dd052fd9f9d  vmovaps xmm11, [rsp+0xA0]
00007dd052fd9fa6  vmovaps xmm12, [rsp+0xB0]
00007dd052fd9faf  vmovaps xmm13, [rsp+0xC0]
00007dd052fd9fb8  vmovaps xmm14, [rsp+0xD0]
00007dd052fd9fc1  vmovaps xmm15, [rsp+0xE0]
00007dd052fd9fca  add rsp, 0xF0
00007dd052fd9fd1  pop r11
00007dd052fd9fd3  pop r10
00007dd052fd9fd5  pop r9
00007dd052fd9fd7  pop r8
00007dd052fd9fd9  pop rsi
00007dd052fd9fda  pop rdi
00007dd052fd9fdb  pop rdx
00007dd052fd9fdc  pop rcx
00007dd052fd9fdd  pop rax
00007dd052fd9fde  add rsp, 0x08
00007dd052fd9fe2  jmp 0x00007DD052FD8C07
00007dd052fd9fe7  sub rsp, 0x08
00007dd052fd9feb  push rax
00007dd052fd9fec  push rcx
00007dd052fd9fed  push rdx
00007dd052fd9fee  push rdi
00007dd052fd9fef  push rsi
00007dd052fd9ff0  push r8
00007dd052fd9ff2  push r9
00007dd052fd9ff4  push r10
00007dd052fd9ff6  push r11
00007dd052fd9ff8  sub rsp, 0xF0
00007dd052fd9fff  vmovaps [rsp], xmm0
00007dd052fda004  vmovaps [rsp+0x10], xmm1
00007dd052fda00a  vmovaps [rsp+0x20], xmm2
00007dd052fda010  vmovaps [rsp+0x30], xmm4
00007dd052fda016  vmovaps [rsp+0x40], xmm5
00007dd052fda01c  vmovaps [rsp+0x50], xmm6
00007dd052fda022  vmovaps [rsp+0x60], xmm7
00007dd052fda028  vmovaps [rsp+0x70], xmm8
00007dd052fda02e  vmovaps [rsp+0x80], xmm9
00007dd052fda037  vmovaps [rsp+0x90], xmm10
00007dd052fda040  vmovaps [rsp+0xA0], xmm11
00007dd052fda049  vmovaps [rsp+0xB0], xmm12
00007dd052fda052  vmovaps [rsp+0xC0], xmm13
00007dd052fda05b  vmovaps [rsp+0xD0], xmm14
00007dd052fda064  vmovaps [rsp+0xE0], xmm15
00007dd052fda06d  sub rsp, 0x30
00007dd052fda071  movaps [rsp], xmm3
00007dd052fda075  movaps [rsp+0x10], xmm5
00007dd052fda07a  movaps [rsp+0x20], xmm4
00007dd052fda07f  lea rdi, [rsp]
00007dd052fda083  mov esi, 0x00
00007dd052fda088  mov rax, 0x61D0404B9530
00007dd052fda092  call rax
00007dd052fda094  movaps xmm3, [rsp]
00007dd052fda098  add rsp, 0x30
00007dd052fda09c  vmovaps xmm0, [rsp]
00007dd052fda0a1  vmovaps xmm1, [rsp+0x10]
00007dd052fda0a7  vmovaps xmm2, [rsp+0x20]
00007dd052fda0ad  vmovaps xmm4, [rsp+0x30]
00007dd052fda0b3  vmovaps xmm5, [rsp+0x40]
00007dd052fda0b9  vmovaps xmm6, [rsp+0x50]
00007dd052fda0bf  vmovaps xmm7, [rsp+0x60]
00007dd052fda0c5  vmovaps xmm8, [rsp+0x70]
00007dd052fda0cb  vmovaps xmm9, [rsp+0x80]
00007dd052fda0d4  vmovaps xmm10, [rsp+0x90]
00007dd052fda0dd  vmovaps xmm11, [rsp+0xA0]
00007dd052fda0e6  vmovaps xmm12, [rsp+0xB0]
00007dd052fda0ef  vmovaps xmm13, [rsp+0xC0]
00007dd052fda0f8  vmovaps xmm14, [rsp+0xD0]
00007dd052fda101  vmovaps xmm15, [rsp+0xE0]
00007dd052fda10a  add rsp, 0xF0
00007dd052fda111  pop r11
00007dd052fda113  pop r10
00007dd052fda115  pop r9
00007dd052fda117  pop r8
00007dd052fda119  pop rsi
00007dd052fda11a  pop rdi
00007dd052fda11b  pop rdx
00007dd052fda11c  pop rcx
00007dd052fda11d  pop rax
00007dd052fda11e  add rsp, 0x08
00007dd052fda122  jmp 0x00007DD052FD8C68
00007dd052fda127  sub rsp, 0x08
00007dd052fda12b  push rax
00007dd052fda12c  push rcx
00007dd052fda12d  push rdx
00007dd052fda12e  push rdi
00007dd052fda12f  push rsi
00007dd052fda130  push r8
00007dd052fda132  push r9
00007dd052fda134  push r10
00007dd052fda136  push r11
00007dd052fda138  sub rsp, 0xF0
00007dd052fda13f  vmovaps [rsp], xmm0
00007dd052fda144  vmovaps [rsp+0x10], xmm1
00007dd052fda14a  vmovaps [rsp+0x20], xmm2
00007dd052fda150  vmovaps [rsp+0x30], xmm3
00007dd052fda156  vmovaps [rsp+0x40], xmm4
00007dd052fda15c  vmovaps [rsp+0x50], xmm6
00007dd052fda162  vmovaps [rsp+0x60], xmm7
00007dd052fda168  vmovaps [rsp+0x70], xmm8
00007dd052fda16e  vmovaps [rsp+0x80], xmm9
00007dd052fda177  vmovaps [rsp+0x90], xmm10
00007dd052fda180  vmovaps [rsp+0xA0], xmm11
00007dd052fda189  vmovaps [rsp+0xB0], xmm12
00007dd052fda192  vmovaps [rsp+0xC0], xmm13
00007dd052fda19b  vmovaps [rsp+0xD0], xmm14
00007dd052fda1a4  vmovaps [rsp+0xE0], xmm15
00007dd052fda1ad  sub rsp, 0x30
00007dd052fda1b1  movaps [rsp], xmm5
00007dd052fda1b5  movaps [rsp+0x10], xmm8
00007dd052fda1bb  movaps [rsp+0x20], xmm15
00007dd052fda1c1  lea rdi, [rsp]
00007dd052fda1c5  mov esi, 0x00
00007dd052fda1ca  mov rax, 0x61D0404B9530
00007dd052fda1d4  call rax
00007dd052fda1d6  movaps xmm5, [rsp]
00007dd052fda1da  add rsp, 0x30
00007dd052fda1de  vmovaps xmm0, [rsp]
00007dd052fda1e3  vmovaps xmm1, [rsp+0x10]
00007dd052fda1e9  vmovaps xmm2, [rsp+0x20]
00007dd052fda1ef  vmovaps xmm3, [rsp+0x30]
00007dd052fda1f5  vmovaps xmm4, [rsp+0x40]
00007dd052fda1fb  vmovaps xmm6, [rsp+0x50]
00007dd052fda201  vmovaps xmm7, [rsp+0x60]
00007dd052fda207  vmovaps xmm8, [rsp+0x70]
00007dd052fda20d  vmovaps xmm9, [rsp+0x80]
00007dd052fda216  vmovaps xmm10, [rsp+0x90]
00007dd052fda21f  vmovaps xmm11, [rsp+0xA0]
00007dd052fda228  vmovaps xmm12, [rsp+0xB0]
00007dd052fda231  vmovaps xmm13, [rsp+0xC0]
00007dd052fda23a  vmovaps xmm14, [rsp+0xD0]
00007dd052fda243  vmovaps xmm15, [rsp+0xE0]
00007dd052fda24c  add rsp, 0xF0
00007dd052fda253  pop r11
00007dd052fda255  pop r10
00007dd052fda257  pop r9
00007dd052fda259  pop r8
00007dd052fda25b  pop rsi
00007dd052fda25c  pop rdi
00007dd052fda25d  pop rdx
00007dd052fda25e  pop rcx
00007dd052fda25f  pop rax
00007dd052fda260  add rsp, 0x08
00007dd052fda264  jmp 0x00007DD052FD8CA0
00007dd052fda269  sub rsp, 0x08
00007dd052fda26d  push rax
00007dd052fda26e  push rcx
00007dd052fda26f  push rdx
00007dd052fda270  push rdi
00007dd052fda271  push rsi
00007dd052fda272  push r8
00007dd052fda274  push r9
00007dd052fda276  push r10
00007dd052fda278  push r11
00007dd052fda27a  sub rsp, 0xF0
00007dd052fda281  vmovaps [rsp], xmm0
00007dd052fda286  vmovaps [rsp+0x10], xmm1
00007dd052fda28c  vmovaps [rsp+0x20], xmm2
00007dd052fda292  vmovaps [rsp+0x30], xmm3
00007dd052fda298  vmovaps [rsp+0x40], xmm5
00007dd052fda29e  vmovaps [rsp+0x50], xmm6
00007dd052fda2a4  vmovaps [rsp+0x60], xmm7
00007dd052fda2aa  vmovaps [rsp+0x70], xmm8
00007dd052fda2b0  vmovaps [rsp+0x80], xmm9
00007dd052fda2b9  vmovaps [rsp+0x90], xmm10
00007dd052fda2c2  vmovaps [rsp+0xA0], xmm11
00007dd052fda2cb  vmovaps [rsp+0xB0], xmm12
00007dd052fda2d4  vmovaps [rsp+0xC0], xmm13
00007dd052fda2dd  vmovaps [rsp+0xD0], xmm14
00007dd052fda2e6  vmovaps [rsp+0xE0], xmm15
00007dd052fda2ef  sub rsp, 0x30
00007dd052fda2f3  movaps [rsp], xmm4
00007dd052fda2f7  movaps [rsp+0x10], xmm9
00007dd052fda2fd  movaps [rsp+0x20], xmm8
00007dd052fda303  lea rdi, [rsp]
00007dd052fda307  mov esi, 0x00
00007dd052fda30c  mov rax, 0x61D0404B9530
00007dd052fda316  call rax
00007dd052fda318  movaps xmm4, [rsp]
00007dd052fda31c  add rsp, 0x30
00007dd052fda320  vmovaps xmm0, [rsp]
00007dd052fda325  vmovaps xmm1, [rsp+0x10]
00007dd052fda32b  vmovaps xmm2, [rsp+0x20]
00007dd052fda331  vmovaps xmm3, [rsp+0x30]
00007dd052fda337  vmovaps xmm5, [rsp+0x40]
00007dd052fda33d  vmovaps xmm6, [rsp+0x50]
00007dd052fda343  vmovaps xmm7, [rsp+0x60]
00007dd052fda349  vmovaps xmm8, [rsp+0x70]
00007dd052fda34f  vmovaps xmm9, [rsp+0x80]
00007dd052fda358  vmovaps xmm10, [rsp+0x90]
00007dd052fda361  vmovaps xmm11, [rsp+0xA0]
00007dd052fda36a  vmovaps xmm12, [rsp+0xB0]
00007dd052fda373  vmovaps xmm13, [rsp+0xC0]
00007dd052fda37c  vmovaps xmm14, [rsp+0xD0]
00007dd052fda385  vmovaps xmm15, [rsp+0xE0]
00007dd052fda38e  add rsp, 0xF0
00007dd052fda395  pop r11
00007dd052fda397  pop r10
00007dd052fda399  pop r9
00007dd052fda39b  pop r8
00007dd052fda39d  pop rsi
00007dd052fda39e  pop rdi
00007dd052fda39f  pop rdx
00007dd052fda3a0  pop rcx
00007dd052fda3a1  pop rax
00007dd052fda3a2  add rsp, 0x08
00007dd052fda3a6  jmp 0x00007DD052FD8CC1
00007dd052fda3ab  sub rsp, 0x08
00007dd052fda3af  push rax
00007dd052fda3b0  push rcx
00007dd052fda3b1  push rdx
00007dd052fda3b2  push rdi
00007dd052fda3b3  push rsi
00007dd052fda3b4  push r8
00007dd052fda3b6  push r9
00007dd052fda3b8  push r10
00007dd052fda3ba  push r11
00007dd052fda3bc  sub rsp, 0xF0
00007dd052fda3c3  vmovaps [rsp], xmm0
00007dd052fda3c8  vmovaps [rsp+0x10], xmm1
00007dd052fda3ce  vmovaps [rsp+0x20], xmm2
00007dd052fda3d4  vmovaps [rsp+0x30], xmm3
00007dd052fda3da  vmovaps [rsp+0x40], xmm4
00007dd052fda3e0  vmovaps [rsp+0x50], xmm5
00007dd052fda3e6  vmovaps [rsp+0x60], xmm6
00007dd052fda3ec  vmovaps [rsp+0x70], xmm7
00007dd052fda3f2  vmovaps [rsp+0x80], xmm8
00007dd052fda3fb  vmovaps [rsp+0x90], xmm10
00007dd052fda404  vmovaps [rsp+0xA0], xmm11
00007dd052fda40d  vmovaps [rsp+0xB0], xmm12
00007dd052fda416  vmovaps [rsp+0xC0], xmm13
00007dd052fda41f  vmovaps [rsp+0xD0], xmm14
00007dd052fda428  vmovaps [rsp+0xE0], xmm15
00007dd052fda431  sub rsp, 0x30
00007dd052fda435  movaps [rsp], xmm9
00007dd052fda43a  movaps [rsp+0x10], xmm10
00007dd052fda440  movaps [rsp+0x20], xmm8
00007dd052fda446  lea rdi, [rsp]
00007dd052fda44a  mov esi, 0x00
00007dd052fda44f  mov rax, 0x61D0404B9530
00007dd052fda459  call rax
00007dd052fda45b  movaps xmm9, [rsp]
00007dd052fda460  add rsp, 0x30
00007dd052fda464  vmovaps xmm0, [rsp]
00007dd052fda469  vmovaps xmm1, [rsp+0x10]
00007dd052fda46f  vmovaps xmm2, [rsp+0x20]
00007dd052fda475  vmovaps xmm3, [rsp+0x30]
00007dd052fda47b  vmovaps xmm4, [rsp+0x40]
00007dd052fda481  vmovaps xmm5, [rsp+0x50]
00007dd052fda487  vmovaps xmm6, [rsp+0x60]
00007dd052fda48d  vmovaps xmm7, [rsp+0x70]
00007dd052fda493  vmovaps xmm8, [rsp+0x80]
00007dd052fda49c  vmovaps xmm10, [rsp+0x90]
00007dd052fda4a5  vmovaps xmm11, [rsp+0xA0]
00007dd052fda4ae  vmovaps xmm12, [rsp+0xB0]
00007dd052fda4b7  vmovaps xmm13, [rsp+0xC0]
00007dd052fda4c0  vmovaps xmm14, [rsp+0xD0]
00007dd052fda4c9  vmovaps xmm15, [rsp+0xE0]
00007dd052fda4d2  add rsp, 0xF0
00007dd052fda4d9  pop r11
00007dd052fda4db  pop r10
00007dd052fda4dd  pop r9
00007dd052fda4df  pop r8
00007dd052fda4e1  pop rsi
00007dd052fda4e2  pop rdi
00007dd052fda4e3  pop rdx
00007dd052fda4e4  pop rcx
00007dd052fda4e5  pop rax
00007dd052fda4e6  add rsp, 0x08
00007dd052fda4ea  jmp 0x00007DD052FD8CDB
00007dd052fda4ef  call 0x00007DD052ED64F0
00007dd052fda4f4  jmp 0x00007DD052FD8DF5
00007dd052fda4f9  call 0x00007DD052ED64F0
00007dd052fda4fe  jmp 0x00007DD052FD8E0B
00007dd052fda503  sub rsp, 0x08
00007dd052fda507  push rax
00007dd052fda508  push rcx
00007dd052fda509  push rdx
00007dd052fda50a  push rdi
00007dd052fda50b  push rsi
00007dd052fda50c  push r8
00007dd052fda50e  push r9
00007dd052fda510  push r10
00007dd052fda512  push r11
00007dd052fda514  sub rsp, 0xF0
00007dd052fda51b  vmovaps [rsp], xmm0
00007dd052fda520  vmovaps [rsp+0x10], xmm2
00007dd052fda526  vmovaps [rsp+0x20], xmm3
00007dd052fda52c  vmovaps [rsp+0x30], xmm4
00007dd052fda532  vmovaps [rsp+0x40], xmm5
00007dd052fda538  vmovaps [rsp+0x50], xmm6
00007dd052fda53e  vmovaps [rsp+0x60], xmm7
00007dd052fda544  vmovaps [rsp+0x70], xmm8
00007dd052fda54a  vmovaps [rsp+0x80], xmm9
00007dd052fda553  vmovaps [rsp+0x90], xmm10
00007dd052fda55c  vmovaps [rsp+0xA0], xmm11
00007dd052fda565  vmovaps [rsp+0xB0], xmm12
00007dd052fda56e  vmovaps [rsp+0xC0], xmm13
00007dd052fda577  vmovaps [rsp+0xD0], xmm14
00007dd052fda580  vmovaps [rsp+0xE0], xmm15
00007dd052fda589  sub rsp, 0x30
00007dd052fda58d  movaps [rsp], xmm1
00007dd052fda591  movaps [rsp+0x10], xmm6
00007dd052fda596  movaps [rsp+0x20], xmm15
00007dd052fda59c  lea rdi, [rsp]
00007dd052fda5a0  mov esi, 0x00
00007dd052fda5a5  mov rax, 0x61D0404B9530
00007dd052fda5af  call rax
00007dd052fda5b1  movaps xmm1, [rsp]
00007dd052fda5b5  add rsp, 0x30
00007dd052fda5b9  vmovaps xmm0, [rsp]
00007dd052fda5be  vmovaps xmm2, [rsp+0x10]
00007dd052fda5c4  vmovaps xmm3, [rsp+0x20]
00007dd052fda5ca  vmovaps xmm4, [rsp+0x30]
00007dd052fda5d0  vmovaps xmm5, [rsp+0x40]
00007dd052fda5d6  vmovaps xmm6, [rsp+0x50]
00007dd052fda5dc  vmovaps xmm7, [rsp+0x60]
00007dd052fda5e2  vmovaps xmm8, [rsp+0x70]
00007dd052fda5e8  vmovaps xmm9, [rsp+0x80]
00007dd052fda5f1  vmovaps xmm10, [rsp+0x90]
00007dd052fda5fa  vmovaps xmm11, [rsp+0xA0]
00007dd052fda603  vmovaps xmm12, [rsp+0xB0]
00007dd052fda60c  vmovaps xmm13, [rsp+0xC0]
00007dd052fda615  vmovaps xmm14, [rsp+0xD0]
00007dd052fda61e  vmovaps xmm15, [rsp+0xE0]
00007dd052fda627  add rsp, 0xF0
00007dd052fda62e  pop r11
00007dd052fda630  pop r10
00007dd052fda632  pop r9
00007dd052fda634  pop r8
00007dd052fda636  pop rsi
00007dd052fda637  pop rdi
00007dd052fda638  pop rdx
00007dd052fda639  pop rcx
00007dd052fda63a  pop rax
00007dd052fda63b  add rsp, 0x08
00007dd052fda63f  jmp 0x00007DD052FD8E48
00007dd052fda644  call 0x00007DD052EE5820
00007dd052fda649  jmp 0x00007DD052FD8E55
00007dd052fda64e  sub rsp, 0x08
00007dd052fda652  push rax
00007dd052fda653  push rcx
00007dd052fda654  push rdx
00007dd052fda655  push rdi
00007dd052fda656  push rsi
00007dd052fda657  push r8
00007dd052fda659  push r9
00007dd052fda65b  push r10
00007dd052fda65d  push r11
00007dd052fda65f  sub rsp, 0xF0
00007dd052fda666  vmovaps [rsp], xmm0
00007dd052fda66b  vmovaps [rsp+0x10], xmm1
00007dd052fda671  vmovaps [rsp+0x20], xmm2
00007dd052fda677  vmovaps [rsp+0x30], xmm3
00007dd052fda67d  vmovaps [rsp+0x40], xmm4
00007dd052fda683  vmovaps [rsp+0x50], xmm5
00007dd052fda689  vmovaps [rsp+0x60], xmm6
00007dd052fda68f  vmovaps [rsp+0x70], xmm7
00007dd052fda695  vmovaps [rsp+0x80], xmm8
00007dd052fda69e  vmovaps [rsp+0x90], xmm9
00007dd052fda6a7  vmovaps [rsp+0xA0], xmm10
00007dd052fda6b0  vmovaps [rsp+0xB0], xmm11
00007dd052fda6b9  vmovaps [rsp+0xC0], xmm12
00007dd052fda6c2  vmovaps [rsp+0xD0], xmm13
00007dd052fda6cb  vmovaps [rsp+0xE0], xmm15
00007dd052fda6d4  sub rsp, 0x30
00007dd052fda6d8  movaps [rsp], xmm14
00007dd052fda6dd  movaps [rsp+0x10], xmm4
00007dd052fda6e2  movaps [rsp+0x20], xmm3
00007dd052fda6e7  lea rdi, [rsp]
00007dd052fda6eb  mov esi, 0x00
00007dd052fda6f0  mov rax, 0x61D0404B9530
00007dd052fda6fa  call rax
00007dd052fda6fc  movaps xmm14, [rsp]
00007dd052fda701  add rsp, 0x30
00007dd052fda705  vmovaps xmm0, [rsp]
00007dd052fda70a  vmovaps xmm1, [rsp+0x10]
00007dd052fda710  vmovaps xmm2, [rsp+0x20]
00007dd052fda716  vmovaps xmm3, [rsp+0x30]
00007dd052fda71c  vmovaps xmm4, [rsp+0x40]
00007dd052fda722  vmovaps xmm5, [rsp+0x50]
00007dd052fda728  vmovaps xmm6, [rsp+0x60]
00007dd052fda72e  vmovaps xmm7, [rsp+0x70]
00007dd052fda734  vmovaps xmm8, [rsp+0x80]
00007dd052fda73d  vmovaps xmm9, [rsp+0x90]
00007dd052fda746  vmovaps xmm10, [rsp+0xA0]
00007dd052fda74f  vmovaps xmm11, [rsp+0xB0]
00007dd052fda758  vmovaps xmm12, [rsp+0xC0]
00007dd052fda761  vmovaps xmm13, [rsp+0xD0]
00007dd052fda76a  vmovaps xmm15, [rsp+0xE0]
00007dd052fda773  add rsp, 0xF0
00007dd052fda77a  pop r11
00007dd052fda77c  pop r10
00007dd052fda77e  pop r9
00007dd052fda780  pop r8
00007dd052fda782  pop rsi
00007dd052fda783  pop rdi
00007dd052fda784  pop rdx
00007dd052fda785  pop rcx
00007dd052fda786  pop rax
00007dd052fda787  add rsp, 0x08
00007dd052fda78b  jmp 0x00007DD052FD8E6F
00007dd052fda790  sub rsp, 0x08
00007dd052fda794  push rax
00007dd052fda795  push rcx
00007dd052fda796  push rdx
00007dd052fda797  push rdi
00007dd052fda798  push rsi
00007dd052fda799  push r8
00007dd052fda79b  push r9
00007dd052fda79d  push r10
00007dd052fda79f  push r11
00007dd052fda7a1  sub rsp, 0xF0
00007dd052fda7a8  vmovaps [rsp], xmm0
00007dd052fda7ad  vmovaps [rsp+0x10], xmm1
00007dd052fda7b3  vmovaps [rsp+0x20], xmm2
00007dd052fda7b9  vmovaps [rsp+0x30], xmm3
00007dd052fda7bf  vmovaps [rsp+0x40], xmm4
00007dd052fda7c5  vmovaps [rsp+0x50], xmm5
00007dd052fda7cb  vmovaps [rsp+0x60], xmm7
00007dd052fda7d1  vmovaps [rsp+0x70], xmm8
00007dd052fda7d7  vmovaps [rsp+0x80], xmm9
00007dd052fda7e0  vmovaps [rsp+0x90], xmm10
00007dd052fda7e9  vmovaps [rsp+0xA0], xmm11
00007dd052fda7f2  vmovaps [rsp+0xB0], xmm12
00007dd052fda7fb  vmovaps [rsp+0xC0], xmm13
00007dd052fda804  vmovaps [rsp+0xD0], xmm14
00007dd052fda80d  vmovaps [rsp+0xE0], xmm15
00007dd052fda816  sub rsp, 0x30
00007dd052fda81a  movaps [rsp], xmm6
00007dd052fda81e  movaps [rsp+0x10], xmm9
00007dd052fda824  movaps [rsp+0x20], xmm7
00007dd052fda829  lea rdi, [rsp]
00007dd052fda82d  mov esi, 0x00
00007dd052fda832  mov rax, 0x61D0404B9530
00007dd052fda83c  call rax
00007dd052fda83e  movaps xmm6, [rsp]
00007dd052fda842  add rsp, 0x30
00007dd052fda846  vmovaps xmm0, [rsp]
00007dd052fda84b  vmovaps xmm1, [rsp+0x10]
00007dd052fda851  vmovaps xmm2, [rsp+0x20]
00007dd052fda857  vmovaps xmm3, [rsp+0x30]
00007dd052fda85d  vmovaps xmm4, [rsp+0x40]
00007dd052fda863  vmovaps xmm5, [rsp+0x50]
00007dd052fda869  vmovaps xmm7, [rsp+0x60]
00007dd052fda86f  vmovaps xmm8, [rsp+0x70]
00007dd052fda875  vmovaps xmm9, [rsp+0x80]
00007dd052fda87e  vmovaps xmm10, [rsp+0x90]
00007dd052fda887  vmovaps xmm11, [rsp+0xA0]
00007dd052fda890  vmovaps xmm12, [rsp+0xB0]
00007dd052fda899  vmovaps xmm13, [rsp+0xC0]
00007dd052fda8a2  vmovaps xmm14, [rsp+0xD0]
00007dd052fda8ab  vmovaps xmm15, [rsp+0xE0]
00007dd052fda8b4  add rsp, 0xF0
00007dd052fda8bb  pop r11
00007dd052fda8bd  pop r10
00007dd052fda8bf  pop r9
00007dd052fda8c1  pop r8
00007dd052fda8c3  pop rsi
00007dd052fda8c4  pop rdi
00007dd052fda8c5  pop rdx
00007dd052fda8c6  pop rcx
00007dd052fda8c7  pop rax
00007dd052fda8c8  add rsp, 0x08
00007dd052fda8cc  jmp 0x00007DD052FD8E87
00007dd052fda8d1  sub rsp, 0x08
00007dd052fda8d5  push rax
00007dd052fda8d6  push rcx
00007dd052fda8d7  push rdx
00007dd052fda8d8  push rdi
00007dd052fda8d9  push rsi
00007dd052fda8da  push r8
00007dd052fda8dc  push r9
00007dd052fda8de  push r10
00007dd052fda8e0  push r11
00007dd052fda8e2  sub rsp, 0xF0
00007dd052fda8e9  vmovaps [rsp], xmm0
00007dd052fda8ee  vmovaps [rsp+0x10], xmm1
00007dd052fda8f4  vmovaps [rsp+0x20], xmm2
00007dd052fda8fa  vmovaps [rsp+0x30], xmm3
00007dd052fda900  vmovaps [rsp+0x40], xmm4
00007dd052fda906  vmovaps [rsp+0x50], xmm5
00007dd052fda90c  vmovaps [rsp+0x60], xmm6
00007dd052fda912  vmovaps [rsp+0x70], xmm8
00007dd052fda918  vmovaps [rsp+0x80], xmm9
00007dd052fda921  vmovaps [rsp+0x90], xmm10
00007dd052fda92a  vmovaps [rsp+0xA0], xmm11
00007dd052fda933  vmovaps [rsp+0xB0], xmm12
00007dd052fda93c  vmovaps [rsp+0xC0], xmm13
00007dd052fda945  vmovaps [rsp+0xD0], xmm14
00007dd052fda94e  vmovaps [rsp+0xE0], xmm15
00007dd052fda957  sub rsp, 0x30
00007dd052fda95b  movaps [rsp], xmm7
00007dd052fda95f  movaps [rsp+0x10], xmm4
00007dd052fda964  movaps [rsp+0x20], xmm9
00007dd052fda96a  lea rdi, [rsp]
00007dd052fda96e  mov esi, 0x00
00007dd052fda973  mov rax, 0x61D0404B9530
00007dd052fda97d  call rax
00007dd052fda97f  movaps xmm7, [rsp]
00007dd052fda983  add rsp, 0x30
00007dd052fda987  vmovaps xmm0, [rsp]
00007dd052fda98c  vmovaps xmm1, [rsp+0x10]
00007dd052fda992  vmovaps xmm2, [rsp+0x20]
00007dd052fda998  vmovaps xmm3, [rsp+0x30]
00007dd052fda99e  vmovaps xmm4, [rsp+0x40]
00007dd052fda9a4  vmovaps xmm5, [rsp+0x50]
00007dd052fda9aa  vmovaps xmm6, [rsp+0x60]
00007dd052fda9b0  vmovaps xmm8, [rsp+0x70]
00007dd052fda9b6  vmovaps xmm9, [rsp+0x80]
00007dd052fda9bf  vmovaps xmm10, [rsp+0x90]
00007dd052fda9c8  vmovaps xmm11, [rsp+0xA0]
00007dd052fda9d1  vmovaps xmm12, [rsp+0xB0]
00007dd052fda9da  vmovaps xmm13, [rsp+0xC0]
00007dd052fda9e3  vmovaps xmm14, [rsp+0xD0]
00007dd052fda9ec  vmovaps xmm15, [rsp+0xE0]
00007dd052fda9f5  add rsp, 0xF0
00007dd052fda9fc  pop r11
00007dd052fda9fe  pop r10
00007dd052fdaa00  pop r9
00007dd052fdaa02  pop r8
00007dd052fdaa04  pop rsi
00007dd052fdaa05  pop rdi
00007dd052fdaa06  pop rdx
00007dd052fdaa07  pop rcx
00007dd052fdaa08  pop rax
00007dd052fdaa09  add rsp, 0x08
00007dd052fdaa0d  jmp 0x00007DD052FD8EB4
00007dd052fdaa12  sub rsp, 0x08
00007dd052fdaa16  push rax
00007dd052fdaa17  push rcx
00007dd052fdaa18  push rdx
00007dd052fdaa19  push rdi
00007dd052fdaa1a  push rsi
00007dd052fdaa1b  push r8
00007dd052fdaa1d  push r9
00007dd052fdaa1f  push r10
00007dd052fdaa21  push r11
00007dd052fdaa23  sub rsp, 0xF0
00007dd052fdaa2a  vmovaps [rsp], xmm0
00007dd052fdaa2f  vmovaps [rsp+0x10], xmm1
00007dd052fdaa35  vmovaps [rsp+0x20], xmm2
00007dd052fdaa3b  vmovaps [rsp+0x30], xmm3
00007dd052fdaa41  vmovaps [rsp+0x40], xmm5
00007dd052fdaa47  vmovaps [rsp+0x50], xmm6
00007dd052fdaa4d  vmovaps [rsp+0x60], xmm7
00007dd052fdaa53  vmovaps [rsp+0x70], xmm8
00007dd052fdaa59  vmovaps [rsp+0x80], xmm9
00007dd052fdaa62  vmovaps [rsp+0x90], xmm10
00007dd052fdaa6b  vmovaps [rsp+0xA0], xmm11
00007dd052fdaa74  vmovaps [rsp+0xB0], xmm12
00007dd052fdaa7d  vmovaps [rsp+0xC0], xmm13
00007dd052fdaa86  vmovaps [rsp+0xD0], xmm14
00007dd052fdaa8f  vmovaps [rsp+0xE0], xmm15
00007dd052fdaa98  sub rsp, 0x30
00007dd052fdaa9c  movaps [rsp], xmm4
00007dd052fdaaa0  movaps [rsp+0x10], xmm15
00007dd052fdaaa6  movaps [rsp+0x20], xmm9
00007dd052fdaaac  lea rdi, [rsp]
00007dd052fdaab0  mov esi, 0x00
00007dd052fdaab5  mov rax, 0x61D0404B9530
00007dd052fdaabf  call rax
00007dd052fdaac1  movaps xmm4, [rsp]
00007dd052fdaac5  add rsp, 0x30
00007dd052fdaac9  vmovaps xmm0, [rsp]
00007dd052fdaace  vmovaps xmm1, [rsp+0x10]
00007dd052fdaad4  vmovaps xmm2, [rsp+0x20]
00007dd052fdaada  vmovaps xmm3, [rsp+0x30]
00007dd052fdaae0  vmovaps xmm5, [rsp+0x40]
00007dd052fdaae6  vmovaps xmm6, [rsp+0x50]
00007dd052fdaaec  vmovaps xmm7, [rsp+0x60]
00007dd052fdaaf2  vmovaps xmm8, [rsp+0x70]
00007dd052fdaaf8  vmovaps xmm9, [rsp+0x80]
00007dd052fdab01  vmovaps xmm10, [rsp+0x90]
00007dd052fdab0a  vmovaps xmm11, [rsp+0xA0]
00007dd052fdab13  vmovaps xmm12, [rsp+0xB0]
00007dd052fdab1c  vmovaps xmm13, [rsp+0xC0]
00007dd052fdab25  vmovaps xmm14, [rsp+0xD0]
00007dd052fdab2e  vmovaps xmm15, [rsp+0xE0]
00007dd052fdab37  add rsp, 0xF0
00007dd052fdab3e  pop r11
00007dd052fdab40  pop r10
00007dd052fdab42  pop r9
00007dd052fdab44  pop r8
00007dd052fdab46  pop rsi
00007dd052fdab47  pop rdi
00007dd052fdab48  pop rdx
00007dd052fdab49  pop rcx
00007dd052fdab4a  pop rax
00007dd052fdab4b  add rsp, 0x08
00007dd052fdab4f  jmp 0x00007DD052FD8ED9
00007dd052fdab54  call 0x00007DD052EE5820
00007dd052fdab59  jmp 0x00007DD052FD8EE6
00007dd052fdab5e  sub rsp, 0x08
00007dd052fdab62  push rax
00007dd052fdab63  push rcx
00007dd052fdab64  push rdx
00007dd052fdab65  push rdi
00007dd052fdab66  push rsi
00007dd052fdab67  push r8
00007dd052fdab69  push r9
00007dd052fdab6b  push r10
00007dd052fdab6d  push r11
00007dd052fdab6f  sub rsp, 0xF0
00007dd052fdab76  vmovaps [rsp], xmm0
00007dd052fdab7b  vmovaps [rsp+0x10], xmm1
00007dd052fdab81  vmovaps [rsp+0x20], xmm2
00007dd052fdab87  vmovaps [rsp+0x30], xmm4
00007dd052fdab8d  vmovaps [rsp+0x40], xmm5
00007dd052fdab93  vmovaps [rsp+0x50], xmm6
00007dd052fdab99  vmovaps [rsp+0x60], xmm7
00007dd052fdab9f  vmovaps [rsp+0x70], xmm8
00007dd052fdaba5  vmovaps [rsp+0x80], xmm9
00007dd052fdabae  vmovaps [rsp+0x90], xmm10
00007dd052fdabb7  vmovaps [rsp+0xA0], xmm11
00007dd052fdabc0  vmovaps [rsp+0xB0], xmm12
00007dd052fdabc9  vmovaps [rsp+0xC0], xmm13
00007dd052fdabd2  vmovaps [rsp+0xD0], xmm14
00007dd052fdabdb  vmovaps [rsp+0xE0], xmm15
00007dd052fdabe4  sub rsp, 0x30
00007dd052fdabe8  movaps [rsp], xmm3
00007dd052fdabec  movaps [rsp+0x10], xmm1
00007dd052fdabf1  movaps [rsp+0x20], xmm9
00007dd052fdabf7  lea rdi, [rsp]
00007dd052fdabfb  mov esi, 0x00
00007dd052fdac00  mov rax, 0x61D0404B9530
00007dd052fdac0a  call rax
00007dd052fdac0c  movaps xmm3, [rsp]
00007dd052fdac10  add rsp, 0x30
00007dd052fdac14  vmovaps xmm0, [rsp]
00007dd052fdac19  vmovaps xmm1, [rsp+0x10]
00007dd052fdac1f  vmovaps xmm2, [rsp+0x20]
00007dd052fdac25  vmovaps xmm4, [rsp+0x30]
00007dd052fdac2b  vmovaps xmm5, [rsp+0x40]
00007dd052fdac31  vmovaps xmm6, [rsp+0x50]
00007dd052fdac37  vmovaps xmm7, [rsp+0x60]
00007dd052fdac3d  vmovaps xmm8, [rsp+0x70]
00007dd052fdac43  vmovaps xmm9, [rsp+0x80]
00007dd052fdac4c  vmovaps xmm10, [rsp+0x90]
00007dd052fdac55  vmovaps xmm11, [rsp+0xA0]
00007dd052fdac5e  vmovaps xmm12, [rsp+0xB0]
00007dd052fdac67  vmovaps xmm13, [rsp+0xC0]
00007dd052fdac70  vmovaps xmm14, [rsp+0xD0]
00007dd052fdac79  vmovaps xmm15, [rsp+0xE0]
00007dd052fdac82  add rsp, 0xF0
00007dd052fdac89  pop r11
00007dd052fdac8b  pop r10
00007dd052fdac8d  pop r9
00007dd052fdac8f  pop r8
00007dd052fdac91  pop rsi
00007dd052fdac92  pop rdi
00007dd052fdac93  pop rdx
00007dd052fdac94  pop rcx
00007dd052fdac95  pop rax
00007dd052fdac96  add rsp, 0x08
00007dd052fdac9a  jmp 0x00007DD052FD8F23
00007dd052fdac9f  sub rsp, 0x08
00007dd052fdaca3  push rax
00007dd052fdaca4  push rcx
00007dd052fdaca5  push rdx
00007dd052fdaca6  push rdi
00007dd052fdaca7  push rsi
00007dd052fdaca8  push r8
00007dd052fdacaa  push r9
00007dd052fdacac  push r10
00007dd052fdacae  push r11
00007dd052fdacb0  sub rsp, 0xF0
00007dd052fdacb7  vmovaps [rsp], xmm0
00007dd052fdacbc  vmovaps [rsp+0x10], xmm2
00007dd052fdacc2  vmovaps [rsp+0x20], xmm3
00007dd052fdacc8  vmovaps [rsp+0x30], xmm4
00007dd052fdacce  vmovaps [rsp+0x40], xmm5
00007dd052fdacd4  vmovaps [rsp+0x50], xmm6
00007dd052fdacda  vmovaps [rsp+0x60], xmm7
00007dd052fdace0  vmovaps [rsp+0x70], xmm8
00007dd052fdace6  vmovaps [rsp+0x80], xmm9
00007dd052fdacef  vmovaps [rsp+0x90], xmm10
00007dd052fdacf8  vmovaps [rsp+0xA0], xmm11
00007dd052fdad01  vmovaps [rsp+0xB0], xmm12
00007dd052fdad0a  vmovaps [rsp+0xC0], xmm13
00007dd052fdad13  vmovaps [rsp+0xD0], xmm14
00007dd052fdad1c  vmovaps [rsp+0xE0], xmm15
00007dd052fdad25  sub rsp, 0x30
00007dd052fdad29  movaps [rsp], xmm1
00007dd052fdad2d  movaps [rsp+0x10], xmm15
00007dd052fdad33  movaps [rsp+0x20], xmm9
00007dd052fdad39  lea rdi, [rsp]
00007dd052fdad3d  mov esi, 0x00
00007dd052fdad42  mov rax, 0x61D0404B9530
00007dd052fdad4c  call rax
00007dd052fdad4e  movaps xmm1, [rsp]
00007dd052fdad52  add rsp, 0x30
00007dd052fdad56  vmovaps xmm0, [rsp]
00007dd052fdad5b  vmovaps xmm2, [rsp+0x10]
00007dd052fdad61  vmovaps xmm3, [rsp+0x20]
00007dd052fdad67  vmovaps xmm4, [rsp+0x30]
00007dd052fdad6d  vmovaps xmm5, [rsp+0x40]
00007dd052fdad73  vmovaps xmm6, [rsp+0x50]
00007dd052fdad79  vmovaps xmm7, [rsp+0x60]
00007dd052fdad7f  vmovaps xmm8, [rsp+0x70]
00007dd052fdad85  vmovaps xmm9, [rsp+0x80]
00007dd052fdad8e  vmovaps xmm10, [rsp+0x90]
00007dd052fdad97  vmovaps xmm11, [rsp+0xA0]
00007dd052fdada0  vmovaps xmm12, [rsp+0xB0]
00007dd052fdada9  vmovaps xmm13, [rsp+0xC0]
00007dd052fdadb2  vmovaps xmm14, [rsp+0xD0]
00007dd052fdadbb  vmovaps xmm15, [rsp+0xE0]
00007dd052fdadc4  add rsp, 0xF0
00007dd052fdadcb  pop r11
00007dd052fdadcd  pop r10
00007dd052fdadcf  pop r9
00007dd052fdadd1  pop r8
00007dd052fdadd3  pop rsi
00007dd052fdadd4  pop rdi
00007dd052fdadd5  pop rdx
00007dd052fdadd6  pop rcx
00007dd052fdadd7  pop rax
00007dd052fdadd8  add rsp, 0x08
00007dd052fdaddc  jmp 0x00007DD052FD8FAB
00007dd052fdade1  call 0x00007DD052EE5820
00007dd052fdade6  jmp 0x00007DD052FD8FB8
00007dd052fdadeb  sub rsp, 0x08
00007dd052fdadef  push rax
00007dd052fdadf0  push rcx
00007dd052fdadf1  push rdx
00007dd052fdadf2  push rdi
00007dd052fdadf3  push rsi
00007dd052fdadf4  push r8
00007dd052fdadf6  push r9
00007dd052fdadf8  push r10
00007dd052fdadfa  push r11
00007dd052fdadfc  sub rsp, 0xF0
00007dd052fdae03  vmovaps [rsp], xmm0
00007dd052fdae08  vmovaps [rsp+0x10], xmm2
00007dd052fdae0e  vmovaps [rsp+0x20], xmm3
00007dd052fdae14  vmovaps [rsp+0x30], xmm4
00007dd052fdae1a  vmovaps [rsp+0x40], xmm5
00007dd052fdae20  vmovaps [rsp+0x50], xmm6
00007dd052fdae26  vmovaps [rsp+0x60], xmm7
00007dd052fdae2c  vmovaps [rsp+0x70], xmm8
00007dd052fdae32  vmovaps [rsp+0x80], xmm9
00007dd052fdae3b  vmovaps [rsp+0x90], xmm10
00007dd052fdae44  vmovaps [rsp+0xA0], xmm11
00007dd052fdae4d  vmovaps [rsp+0xB0], xmm12
00007dd052fdae56  vmovaps [rsp+0xC0], xmm13
00007dd052fdae5f  vmovaps [rsp+0xD0], xmm14
00007dd052fdae68  vmovaps [rsp+0xE0], xmm15
00007dd052fdae71  sub rsp, 0x30
00007dd052fdae75  movaps [rsp], xmm1
00007dd052fdae79  movaps [rsp+0x10], xmm5
00007dd052fdae7e  movaps [rsp+0x20], xmm7
00007dd052fdae83  lea rdi, [rsp]
00007dd052fdae87  mov esi, 0x00
00007dd052fdae8c  mov rax, 0x61D0404B9530
00007dd052fdae96  call rax
00007dd052fdae98  movaps xmm1, [rsp]
00007dd052fdae9c  add rsp, 0x30
00007dd052fdaea0  vmovaps xmm0, [rsp]
00007dd052fdaea5  vmovaps xmm2, [rsp+0x10]
00007dd052fdaeab  vmovaps xmm3, [rsp+0x20]
00007dd052fdaeb1  vmovaps xmm4, [rsp+0x30]
00007dd052fdaeb7  vmovaps xmm5, [rsp+0x40]
00007dd052fdaebd  vmovaps xmm6, [rsp+0x50]
00007dd052fdaec3  vmovaps xmm7, [rsp+0x60]
00007dd052fdaec9  vmovaps xmm8, [rsp+0x70]
00007dd052fdaecf  vmovaps xmm9, [rsp+0x80]
00007dd052fdaed8  vmovaps xmm10, [rsp+0x90]
00007dd052fdaee1  vmovaps xmm11, [rsp+0xA0]
00007dd052fdaeea  vmovaps xmm12, [rsp+0xB0]
00007dd052fdaef3  vmovaps xmm13, [rsp+0xC0]
00007dd052fdaefc  vmovaps xmm14, [rsp+0xD0]
00007dd052fdaf05  vmovaps xmm15, [rsp+0xE0]
00007dd052fdaf0e  add rsp, 0xF0
00007dd052fdaf15  pop r11
00007dd052fdaf17  pop r10
00007dd052fdaf19  pop r9
00007dd052fdaf1b  pop r8
00007dd052fdaf1d  pop rsi
00007dd052fdaf1e  pop rdi
00007dd052fdaf1f  pop rdx
00007dd052fdaf20  pop rcx
00007dd052fdaf21  pop rax
00007dd052fdaf22  add rsp, 0x08
00007dd052fdaf26  jmp 0x00007DD052FD905D
00007dd052fdaf2b  sub rsp, 0x08
00007dd052fdaf2f  push rax
00007dd052fdaf30  push rcx
00007dd052fdaf31  push rdx
00007dd052fdaf32  push rdi
00007dd052fdaf33  push rsi
00007dd052fdaf34  push r8
00007dd052fdaf36  push r9
00007dd052fdaf38  push r10
00007dd052fdaf3a  push r11
00007dd052fdaf3c  sub rsp, 0xF0
00007dd052fdaf43  vmovaps [rsp], xmm0
00007dd052fdaf48  vmovaps [rsp+0x10], xmm1
00007dd052fdaf4e  vmovaps [rsp+0x20], xmm2
00007dd052fdaf54  vmovaps [rsp+0x30], xmm3
00007dd052fdaf5a  vmovaps [rsp+0x40], xmm4
00007dd052fdaf60  vmovaps [rsp+0x50], xmm5
00007dd052fdaf66  vmovaps [rsp+0x60], xmm6
00007dd052fdaf6c  vmovaps [rsp+0x70], xmm8
00007dd052fdaf72  vmovaps [rsp+0x80], xmm9
00007dd052fdaf7b  vmovaps [rsp+0x90], xmm10
00007dd052fdaf84  vmovaps [rsp+0xA0], xmm11
00007dd052fdaf8d  vmovaps [rsp+0xB0], xmm12
00007dd052fdaf96  vmovaps [rsp+0xC0], xmm13
00007dd052fdaf9f  vmovaps [rsp+0xD0], xmm14
00007dd052fdafa8  vmovaps [rsp+0xE0], xmm15
00007dd052fdafb1  sub rsp, 0x30
00007dd052fdafb5  movaps [rsp], xmm7
00007dd052fdafb9  movaps [rsp+0x10], xmm5
00007dd052fdafbe  movaps [rsp+0x20], xmm15
00007dd052fdafc4  lea rdi, [rsp]
00007dd052fdafc8  mov esi, 0x00
00007dd052fdafcd  mov rax, 0x61D0404B9530
00007dd052fdafd7  call rax
00007dd052fdafd9  movaps xmm7, [rsp]
00007dd052fdafdd  add rsp, 0x30
00007dd052fdafe1  vmovaps xmm0, [rsp]
00007dd052fdafe6  vmovaps xmm1, [rsp+0x10]
00007dd052fdafec  vmovaps xmm2, [rsp+0x20]
00007dd052fdaff2  vmovaps xmm3, [rsp+0x30]
00007dd052fdaff8  vmovaps xmm4, [rsp+0x40]
00007dd052fdaffe  vmovaps xmm5, [rsp+0x50]
00007dd052fdb004  vmovaps xmm6, [rsp+0x60]
00007dd052fdb00a  vmovaps xmm8, [rsp+0x70]
00007dd052fdb010  vmovaps xmm9, [rsp+0x80]
00007dd052fdb019  vmovaps xmm10, [rsp+0x90]
00007dd052fdb022  vmovaps xmm11, [rsp+0xA0]
00007dd052fdb02b  vmovaps xmm12, [rsp+0xB0]
00007dd052fdb034  vmovaps xmm13, [rsp+0xC0]
00007dd052fdb03d  vmovaps xmm14, [rsp+0xD0]
00007dd052fdb046  vmovaps xmm15, [rsp+0xE0]
00007dd052fdb04f  add rsp, 0xF0
00007dd052fdb056  pop r11
00007dd052fdb058  pop r10
00007dd052fdb05a  pop r9
00007dd052fdb05c  pop r8
00007dd052fdb05e  pop rsi
00007dd052fdb05f  pop rdi
00007dd052fdb060  pop rdx
00007dd052fdb061  pop rcx
00007dd052fdb062  pop rax
00007dd052fdb063  add rsp, 0x08
00007dd052fdb067  jmp 0x00007DD052FD9093
00007dd052fdb06c  call 0x00007DD052ED64F0
00007dd052fdb071  jmp 0x00007DD052FD90A0
00007dd052fdb076  sub rsp, 0x08
00007dd052fdb07a  push rax
00007dd052fdb07b  push rcx
00007dd052fdb07c  push rdx
00007dd052fdb07d  push rdi
00007dd052fdb07e  push rsi
00007dd052fdb07f  push r8
00007dd052fdb081  push r9
00007dd052fdb083  push r10
00007dd052fdb085  push r11
00007dd052fdb087  sub rsp, 0xF0
00007dd052fdb08e  vmovaps [rsp], xmm0
00007dd052fdb093  vmovaps [rsp+0x10], xmm1
00007dd052fdb099  vmovaps [rsp+0x20], xmm2
00007dd052fdb09f  vmovaps [rsp+0x30], xmm3
00007dd052fdb0a5  vmovaps [rsp+0x40], xmm4
00007dd052fdb0ab  vmovaps [rsp+0x50], xmm5
00007dd052fdb0b1  vmovaps [rsp+0x60], xmm6
00007dd052fdb0b7  vmovaps [rsp+0x70], xmm7
00007dd052fdb0bd  vmovaps [rsp+0x80], xmm8
00007dd052fdb0c6  vmovaps [rsp+0x90], xmm9
00007dd052fdb0cf  vmovaps [rsp+0xA0], xmm10
00007dd052fdb0d8  vmovaps [rsp+0xB0], xmm11
00007dd052fdb0e1  vmovaps [rsp+0xC0], xmm12
00007dd052fdb0ea  vmovaps [rsp+0xD0], xmm13
00007dd052fdb0f3  vmovaps [rsp+0xE0], xmm14
00007dd052fdb0fc  sub rsp, 0x30
00007dd052fdb100  movaps [rsp], xmm15
00007dd052fdb105  movaps [rsp+0x10], xmm5
00007dd052fdb10a  movaps [rsp+0x20], xmm3
00007dd052fdb10f  lea rdi, [rsp]
00007dd052fdb113  mov esi, 0x00
00007dd052fdb118  mov rax, 0x61D0404B9530
00007dd052fdb122  call rax
00007dd052fdb124  movaps xmm15, [rsp]
00007dd052fdb129  add rsp, 0x30
00007dd052fdb12d  vmovaps xmm0, [rsp]
00007dd052fdb132  vmovaps xmm1, [rsp+0x10]
00007dd052fdb138  vmovaps xmm2, [rsp+0x20]
00007dd052fdb13e  vmovaps xmm3, [rsp+0x30]
00007dd052fdb144  vmovaps xmm4, [rsp+0x40]
00007dd052fdb14a  vmovaps xmm5, [rsp+0x50]
00007dd052fdb150  vmovaps xmm6, [rsp+0x60]
00007dd052fdb156  vmovaps xmm7, [rsp+0x70]
00007dd052fdb15c  vmovaps xmm8, [rsp+0x80]
00007dd052fdb165  vmovaps xmm9, [rsp+0x90]
00007dd052fdb16e  vmovaps xmm10, [rsp+0xA0]
00007dd052fdb177  vmovaps xmm11, [rsp+0xB0]
00007dd052fdb180  vmovaps xmm12, [rsp+0xC0]
00007dd052fdb189  vmovaps xmm13, [rsp+0xD0]
00007dd052fdb192  vmovaps xmm14, [rsp+0xE0]
00007dd052fdb19b  add rsp, 0xF0
00007dd052fdb1a2  pop r11
00007dd052fdb1a4  pop r10
00007dd052fdb1a6  pop r9
00007dd052fdb1a8  pop r8
00007dd052fdb1aa  pop rsi
00007dd052fdb1ab  pop rdi
00007dd052fdb1ac  pop rdx
00007dd052fdb1ad  pop rcx
00007dd052fdb1ae  pop rax
00007dd052fdb1af  add rsp, 0x08
00007dd052fdb1b3  jmp 0x00007DD052FD90C6
00007dd052fdb1b8  sub rsp, 0x08
00007dd052fdb1bc  push rax
00007dd052fdb1bd  push rcx
00007dd052fdb1be  push rdx
00007dd052fdb1bf  push rdi
00007dd052fdb1c0  push rsi
00007dd052fdb1c1  push r8
00007dd052fdb1c3  push r9
00007dd052fdb1c5  push r10
00007dd052fdb1c7  push r11
00007dd052fdb1c9  sub rsp, 0xF0
00007dd052fdb1d0  vmovaps [rsp], xmm0
00007dd052fdb1d5  vmovaps [rsp+0x10], xmm2
00007dd052fdb1db  vmovaps [rsp+0x20], xmm3
00007dd052fdb1e1  vmovaps [rsp+0x30], xmm4
00007dd052fdb1e7  vmovaps [rsp+0x40], xmm5
00007dd052fdb1ed  vmovaps [rsp+0x50], xmm6
00007dd052fdb1f3  vmovaps [rsp+0x60], xmm7
00007dd052fdb1f9  vmovaps [rsp+0x70], xmm8
00007dd052fdb1ff  vmovaps [rsp+0x80], xmm9
00007dd052fdb208  vmovaps [rsp+0x90], xmm10
00007dd052fdb211  vmovaps [rsp+0xA0], xmm11
00007dd052fdb21a  vmovaps [rsp+0xB0], xmm12
00007dd052fdb223  vmovaps [rsp+0xC0], xmm13
00007dd052fdb22c  vmovaps [rsp+0xD0], xmm14
00007dd052fdb235  vmovaps [rsp+0xE0], xmm15
00007dd052fdb23e  sub rsp, 0x30
00007dd052fdb242  movaps [rsp], xmm1
00007dd052fdb246  movaps [rsp+0x10], xmm5
00007dd052fdb24b  movaps [rsp+0x20], xmm4
00007dd052fdb250  lea rdi, [rsp]
00007dd052fdb254  mov esi, 0x00
00007dd052fdb259  mov rax, 0x61D0404B9530
00007dd052fdb263  call rax
00007dd052fdb265  movaps xmm1, [rsp]
00007dd052fdb269  add rsp, 0x30
00007dd052fdb26d  vmovaps xmm0, [rsp]
00007dd052fdb272  vmovaps xmm2, [rsp+0x10]
00007dd052fdb278  vmovaps xmm3, [rsp+0x20]
00007dd052fdb27e  vmovaps xmm4, [rsp+0x30]
00007dd052fdb284  vmovaps xmm5, [rsp+0x40]
00007dd052fdb28a  vmovaps xmm6, [rsp+0x50]
00007dd052fdb290  vmovaps xmm7, [rsp+0x60]
00007dd052fdb296  vmovaps xmm8, [rsp+0x70]
00007dd052fdb29c  vmovaps xmm9, [rsp+0x80]
00007dd052fdb2a5  vmovaps xmm10, [rsp+0x90]
00007dd052fdb2ae  vmovaps xmm11, [rsp+0xA0]
00007dd052fdb2b7  vmovaps xmm12, [rsp+0xB0]
00007dd052fdb2c0  vmovaps xmm13, [rsp+0xC0]
00007dd052fdb2c9  vmovaps xmm14, [rsp+0xD0]
00007dd052fdb2d2  vmovaps xmm15, [rsp+0xE0]
00007dd052fdb2db  add rsp, 0xF0
00007dd052fdb2e2  pop r11
00007dd052fdb2e4  pop r10
00007dd052fdb2e6  pop r9
00007dd052fdb2e8  pop r8
00007dd052fdb2ea  pop rsi
00007dd052fdb2eb  pop rdi
00007dd052fdb2ec  pop rdx
00007dd052fdb2ed  pop rcx
00007dd052fdb2ee  pop rax
00007dd052fdb2ef  add rsp, 0x08
00007dd052fdb2f3  jmp 0x00007DD052FD90E6
00007dd052fdb2f8  sub rsp, 0x08
00007dd052fdb2fc  push rax
00007dd052fdb2fd  push rcx
00007dd052fdb2fe  push rdx
00007dd052fdb2ff  push rdi
00007dd052fdb300  push rsi
00007dd052fdb301  push r8
00007dd052fdb303  push r9
00007dd052fdb305  push r10
00007dd052fdb307  push r11
00007dd052fdb309  sub rsp, 0xF0
00007dd052fdb310  vmovaps [rsp], xmm0
00007dd052fdb315  vmovaps [rsp+0x10], xmm1
00007dd052fdb31b  vmovaps [rsp+0x20], xmm2
00007dd052fdb321  vmovaps [rsp+0x30], xmm3
00007dd052fdb327  vmovaps [rsp+0x40], xmm5
00007dd052fdb32d  vmovaps [rsp+0x50], xmm6
00007dd052fdb333  vmovaps [rsp+0x60], xmm7
00007dd052fdb339  vmovaps [rsp+0x70], xmm8
00007dd052fdb33f  vmovaps [rsp+0x80], xmm9
00007dd052fdb348  vmovaps [rsp+0x90], xmm10
00007dd052fdb351  vmovaps [rsp+0xA0], xmm11
00007dd052fdb35a  vmovaps [rsp+0xB0], xmm12
00007dd052fdb363  vmovaps [rsp+0xC0], xmm13
00007dd052fdb36c  vmovaps [rsp+0xD0], xmm14
00007dd052fdb375  vmovaps [rsp+0xE0], xmm15
00007dd052fdb37e  sub rsp, 0x30
00007dd052fdb382  movaps [rsp], xmm4
00007dd052fdb386  movaps [rsp+0x10], xmm3
00007dd052fdb38b  movaps [rsp+0x20], xmm5
00007dd052fdb390  lea rdi, [rsp]
00007dd052fdb394  mov esi, 0x00
00007dd052fdb399  mov rax, 0x61D0404B9530
00007dd052fdb3a3  call rax
00007dd052fdb3a5  movaps xmm4, [rsp]
00007dd052fdb3a9  add rsp, 0x30
00007dd052fdb3ad  vmovaps xmm0, [rsp]
00007dd052fdb3b2  vmovaps xmm1, [rsp+0x10]
00007dd052fdb3b8  vmovaps xmm2, [rsp+0x20]
00007dd052fdb3be  vmovaps xmm3, [rsp+0x30]
00007dd052fdb3c4  vmovaps xmm5, [rsp+0x40]
00007dd052fdb3ca  vmovaps xmm6, [rsp+0x50]
00007dd052fdb3d0  vmovaps xmm7, [rsp+0x60]
00007dd052fdb3d6  vmovaps xmm8, [rsp+0x70]
00007dd052fdb3dc  vmovaps xmm9, [rsp+0x80]
00007dd052fdb3e5  vmovaps xmm10, [rsp+0x90]
00007dd052fdb3ee  vmovaps xmm11, [rsp+0xA0]
00007dd052fdb3f7  vmovaps xmm12, [rsp+0xB0]
00007dd052fdb400  vmovaps xmm13, [rsp+0xC0]
00007dd052fdb409  vmovaps xmm14, [rsp+0xD0]
00007dd052fdb412  vmovaps xmm15, [rsp+0xE0]
00007dd052fdb41b  add rsp, 0xF0
00007dd052fdb422  pop r11
00007dd052fdb424  pop r10
00007dd052fdb426  pop r9
00007dd052fdb428  pop r8
00007dd052fdb42a  pop rsi
00007dd052fdb42b  pop rdi
00007dd052fdb42c  pop rdx
00007dd052fdb42d  pop rcx
00007dd052fdb42e  pop rax
00007dd052fdb42f  add rsp, 0x08
00007dd052fdb433  jmp 0x00007DD052FD9134
00007dd052fdb438  call 0x00007DD052ED64F0
00007dd052fdb43d  jmp 0x00007DD052FD9141
00007dd052fdb442  sub rsp, 0x08
00007dd052fdb446  push rax
00007dd052fdb447  push rcx
00007dd052fdb448  push rdx
00007dd052fdb449  push rdi
00007dd052fdb44a  push rsi
00007dd052fdb44b  push r8
00007dd052fdb44d  push r9
00007dd052fdb44f  push r10
00007dd052fdb451  push r11
00007dd052fdb453  sub rsp, 0xF0
00007dd052fdb45a  vmovaps [rsp], xmm0
00007dd052fdb45f  vmovaps [rsp+0x10], xmm1
00007dd052fdb465  vmovaps [rsp+0x20], xmm2
00007dd052fdb46b  vmovaps [rsp+0x30], xmm3
00007dd052fdb471  vmovaps [rsp+0x40], xmm4
00007dd052fdb477  vmovaps [rsp+0x50], xmm6
00007dd052fdb47d  vmovaps [rsp+0x60], xmm7
00007dd052fdb483  vmovaps [rsp+0x70], xmm8
00007dd052fdb489  vmovaps [rsp+0x80], xmm9
00007dd052fdb492  vmovaps [rsp+0x90], xmm10
00007dd052fdb49b  vmovaps [rsp+0xA0], xmm11
00007dd052fdb4a4  vmovaps [rsp+0xB0], xmm12
00007dd052fdb4ad  vmovaps [rsp+0xC0], xmm13
00007dd052fdb4b6  vmovaps [rsp+0xD0], xmm14
00007dd052fdb4bf  vmovaps [rsp+0xE0], xmm15
00007dd052fdb4c8  sub rsp, 0x30
00007dd052fdb4cc  movaps [rsp], xmm5
00007dd052fdb4d0  movaps [rsp+0x10], xmm6
00007dd052fdb4d5  movaps [rsp+0x20], xmm3
00007dd052fdb4da  lea rdi, [rsp]
00007dd052fdb4de  mov esi, 0x00
00007dd052fdb4e3  mov rax, 0x61D0404B9530
00007dd052fdb4ed  call rax
00007dd052fdb4ef  movaps xmm5, [rsp]
00007dd052fdb4f3  add rsp, 0x30
00007dd052fdb4f7  vmovaps xmm0, [rsp]
00007dd052fdb4fc  vmovaps xmm1, [rsp+0x10]
00007dd052fdb502  vmovaps xmm2, [rsp+0x20]
00007dd052fdb508  vmovaps xmm3, [rsp+0x30]
00007dd052fdb50e  vmovaps xmm4, [rsp+0x40]
00007dd052fdb514  vmovaps xmm6, [rsp+0x50]
00007dd052fdb51a  vmovaps xmm7, [rsp+0x60]
00007dd052fdb520  vmovaps xmm8, [rsp+0x70]
00007dd052fdb526  vmovaps xmm9, [rsp+0x80]
00007dd052fdb52f  vmovaps xmm10, [rsp+0x90]
00007dd052fdb538  vmovaps xmm11, [rsp+0xA0]
00007dd052fdb541  vmovaps xmm12, [rsp+0xB0]
00007dd052fdb54a  vmovaps xmm13, [rsp+0xC0]
00007dd052fdb553  vmovaps xmm14, [rsp+0xD0]
00007dd052fdb55c  vmovaps xmm15, [rsp+0xE0]
00007dd052fdb565  add rsp, 0xF0
00007dd052fdb56c  pop r11
00007dd052fdb56e  pop r10
00007dd052fdb570  pop r9
00007dd052fdb572  pop r8
00007dd052fdb574  pop rsi
00007dd052fdb575  pop rdi
00007dd052fdb576  pop rdx
00007dd052fdb577  pop rcx
00007dd052fdb578  pop rax
00007dd052fdb579  add rsp, 0x08
00007dd052fdb57d  jmp 0x00007DD052FD9167
00007dd052fdb582  sub rsp, 0x08
00007dd052fdb586  push rax
00007dd052fdb587  push rcx
00007dd052fdb588  push rdx
00007dd052fdb589  push rdi
00007dd052fdb58a  push rsi
00007dd052fdb58b  push r8
00007dd052fdb58d  push r9
00007dd052fdb58f  push r10
00007dd052fdb591  push r11
00007dd052fdb593  sub rsp, 0xF0
00007dd052fdb59a  vmovaps [rsp], xmm0
00007dd052fdb59f  vmovaps [rsp+0x10], xmm1
00007dd052fdb5a5  vmovaps [rsp+0x20], xmm2
00007dd052fdb5ab  vmovaps [rsp+0x30], xmm3
00007dd052fdb5b1  vmovaps [rsp+0x40], xmm4
00007dd052fdb5b7  vmovaps [rsp+0x50], xmm5
00007dd052fdb5bd  vmovaps [rsp+0x60], xmm7
00007dd052fdb5c3  vmovaps [rsp+0x70], xmm8
00007dd052fdb5c9  vmovaps [rsp+0x80], xmm9
00007dd052fdb5d2  vmovaps [rsp+0x90], xmm10
00007dd052fdb5db  vmovaps [rsp+0xA0], xmm11
00007dd052fdb5e4  vmovaps [rsp+0xB0], xmm12
00007dd052fdb5ed  vmovaps [rsp+0xC0], xmm13
00007dd052fdb5f6  vmovaps [rsp+0xD0], xmm14
00007dd052fdb5ff  vmovaps [rsp+0xE0], xmm15
00007dd052fdb608  sub rsp, 0x30
00007dd052fdb60c  movaps [rsp], xmm6
00007dd052fdb610  movaps [rsp+0x10], xmm9
00007dd052fdb616  movaps [rsp+0x20], xmm1
00007dd052fdb61b  lea rdi, [rsp]
00007dd052fdb61f  mov esi, 0x00
00007dd052fdb624  mov rax, 0x61D0404B9530
00007dd052fdb62e  call rax
00007dd052fdb630  movaps xmm6, [rsp]
00007dd052fdb634  add rsp, 0x30
00007dd052fdb638  vmovaps xmm0, [rsp]
00007dd052fdb63d  vmovaps xmm1, [rsp+0x10]
00007dd052fdb643  vmovaps xmm2, [rsp+0x20]
00007dd052fdb649  vmovaps xmm3, [rsp+0x30]
00007dd052fdb64f  vmovaps xmm4, [rsp+0x40]
00007dd052fdb655  vmovaps xmm5, [rsp+0x50]
00007dd052fdb65b  vmovaps xmm7, [rsp+0x60]
00007dd052fdb661  vmovaps xmm8, [rsp+0x70]
00007dd052fdb667  vmovaps xmm9, [rsp+0x80]
00007dd052fdb670  vmovaps xmm10, [rsp+0x90]
00007dd052fdb679  vmovaps xmm11, [rsp+0xA0]
00007dd052fdb682  vmovaps xmm12, [rsp+0xB0]
00007dd052fdb68b  vmovaps xmm13, [rsp+0xC0]
00007dd052fdb694  vmovaps xmm14, [rsp+0xD0]
00007dd052fdb69d  vmovaps xmm15, [rsp+0xE0]
00007dd052fdb6a6  add rsp, 0xF0
00007dd052fdb6ad  pop r11
00007dd052fdb6af  pop r10
00007dd052fdb6b1  pop r9
00007dd052fdb6b3  pop r8
00007dd052fdb6b5  pop rsi
00007dd052fdb6b6  pop rdi
00007dd052fdb6b7  pop rdx
00007dd052fdb6b8  pop rcx
00007dd052fdb6b9  pop rax
00007dd052fdb6ba  add rsp, 0x08
00007dd052fdb6be  jmp 0x00007DD052FD918B
00007dd052fdb6c3  sub rsp, 0x08
00007dd052fdb6c7  push rax
00007dd052fdb6c8  push rcx
00007dd052fdb6c9  push rdx
00007dd052fdb6ca  push rdi
00007dd052fdb6cb  push rsi
00007dd052fdb6cc  push r8
00007dd052fdb6ce  push r9
00007dd052fdb6d0  push r10
00007dd052fdb6d2  push r11
00007dd052fdb6d4  sub rsp, 0xF0
00007dd052fdb6db  vmovaps [rsp], xmm0
00007dd052fdb6e0  vmovaps [rsp+0x10], xmm1
00007dd052fdb6e6  vmovaps [rsp+0x20], xmm2
00007dd052fdb6ec  vmovaps [rsp+0x30], xmm3
00007dd052fdb6f2  vmovaps [rsp+0x40], xmm4
00007dd052fdb6f8  vmovaps [rsp+0x50], xmm5
00007dd052fdb6fe  vmovaps [rsp+0x60], xmm6
00007dd052fdb704  vmovaps [rsp+0x70], xmm7
00007dd052fdb70a  vmovaps [rsp+0x80], xmm8
00007dd052fdb713  vmovaps [rsp+0x90], xmm10
00007dd052fdb71c  vmovaps [rsp+0xA0], xmm11
00007dd052fdb725  vmovaps [rsp+0xB0], xmm12
00007dd052fdb72e  vmovaps [rsp+0xC0], xmm13
00007dd052fdb737  vmovaps [rsp+0xD0], xmm14
00007dd052fdb740  vmovaps [rsp+0xE0], xmm15
00007dd052fdb749  sub rsp, 0x30
00007dd052fdb74d  movaps [rsp], xmm9
00007dd052fdb752  movaps [rsp+0x10], xmm3
00007dd052fdb757  movaps [rsp+0x20], xmm1
00007dd052fdb75c  lea rdi, [rsp]
00007dd052fdb760  mov esi, 0x00
00007dd052fdb765  mov rax, 0x61D0404B9530
00007dd052fdb76f  call rax
00007dd052fdb771  movaps xmm9, [rsp]
00007dd052fdb776  add rsp, 0x30
00007dd052fdb77a  vmovaps xmm0, [rsp]
00007dd052fdb77f  vmovaps xmm1, [rsp+0x10]
00007dd052fdb785  vmovaps xmm2, [rsp+0x20]
00007dd052fdb78b  vmovaps xmm3, [rsp+0x30]
00007dd052fdb791  vmovaps xmm4, [rsp+0x40]
00007dd052fdb797  vmovaps xmm5, [rsp+0x50]
00007dd052fdb79d  vmovaps xmm6, [rsp+0x60]
00007dd052fdb7a3  vmovaps xmm7, [rsp+0x70]
00007dd052fdb7a9  vmovaps xmm8, [rsp+0x80]
00007dd052fdb7b2  vmovaps xmm10, [rsp+0x90]
00007dd052fdb7bb  vmovaps xmm11, [rsp+0xA0]
00007dd052fdb7c4  vmovaps xmm12, [rsp+0xB0]
00007dd052fdb7cd  vmovaps xmm13, [rsp+0xC0]
00007dd052fdb7d6  vmovaps xmm14, [rsp+0xD0]
00007dd052fdb7df  vmovaps xmm15, [rsp+0xE0]
00007dd052fdb7e8  add rsp, 0xF0
00007dd052fdb7ef  pop r11
00007dd052fdb7f1  pop r10
00007dd052fdb7f3  pop r9
00007dd052fdb7f5  pop r8
00007dd052fdb7f7  pop rsi
00007dd052fdb7f8  pop rdi
00007dd052fdb7f9  pop rdx
00007dd052fdb7fa  pop rcx
00007dd052fdb7fb  pop rax
00007dd052fdb7fc  add rsp, 0x08
00007dd052fdb800  jmp 0x00007DD052FD91D7
00007dd052fdb805  call 0x00007DD052ED64F0
00007dd052fdb80a  jmp 0x00007DD052FD91E4
00007dd052fdb80f  sub rsp, 0x08
00007dd052fdb813  push rax
00007dd052fdb814  push rcx
00007dd052fdb815  push rdx
00007dd052fdb816  push rdi
00007dd052fdb817  push rsi
00007dd052fdb818  push r8
00007dd052fdb81a  push r9
00007dd052fdb81c  push r10
00007dd052fdb81e  push r11
00007dd052fdb820  sub rsp, 0xF0
00007dd052fdb827  vmovaps [rsp], xmm0
00007dd052fdb82c  vmovaps [rsp+0x10], xmm1
00007dd052fdb832  vmovaps [rsp+0x20], xmm2
00007dd052fdb838  vmovaps [rsp+0x30], xmm3
00007dd052fdb83e  vmovaps [rsp+0x40], xmm4
00007dd052fdb844  vmovaps [rsp+0x50], xmm5
00007dd052fdb84a  vmovaps [rsp+0x60], xmm6
00007dd052fdb850  vmovaps [rsp+0x70], xmm7
00007dd052fdb856  vmovaps [rsp+0x80], xmm8
00007dd052fdb85f  vmovaps [rsp+0x90], xmm9
00007dd052fdb868  vmovaps [rsp+0xA0], xmm10
00007dd052fdb871  vmovaps [rsp+0xB0], xmm11
00007dd052fdb87a  vmovaps [rsp+0xC0], xmm12
00007dd052fdb883  vmovaps [rsp+0xD0], xmm13
00007dd052fdb88c  vmovaps [rsp+0xE0], xmm14
00007dd052fdb895  sub rsp, 0x30
00007dd052fdb899  movaps [rsp], xmm15
00007dd052fdb89e  movaps [rsp+0x10], xmm3
00007dd052fdb8a3  movaps [rsp+0x20], xmm7
00007dd052fdb8a8  lea rdi, [rsp]
00007dd052fdb8ac  mov esi, 0x00
00007dd052fdb8b1  mov rax, 0x61D0404B9530
00007dd052fdb8bb  call rax
00007dd052fdb8bd  movaps xmm15, [rsp]
00007dd052fdb8c2  add rsp, 0x30
00007dd052fdb8c6  vmovaps xmm0, [rsp]
00007dd052fdb8cb  vmovaps xmm1, [rsp+0x10]
00007dd052fdb8d1  vmovaps xmm2, [rsp+0x20]
00007dd052fdb8d7  vmovaps xmm3, [rsp+0x30]
00007dd052fdb8dd  vmovaps xmm4, [rsp+0x40]
00007dd052fdb8e3  vmovaps xmm5, [rsp+0x50]
00007dd052fdb8e9  vmovaps xmm6, [rsp+0x60]
00007dd052fdb8ef  vmovaps xmm7, [rsp+0x70]
00007dd052fdb8f5  vmovaps xmm8, [rsp+0x80]
00007dd052fdb8fe  vmovaps xmm9, [rsp+0x90]
00007dd052fdb907  vmovaps xmm10, [rsp+0xA0]
00007dd052fdb910  vmovaps xmm11, [rsp+0xB0]
00007dd052fdb919  vmovaps xmm12, [rsp+0xC0]
00007dd052fdb922  vmovaps xmm13, [rsp+0xD0]
00007dd052fdb92b  vmovaps xmm14, [rsp+0xE0]
00007dd052fdb934  add rsp, 0xF0
00007dd052fdb93b  pop r11
00007dd052fdb93d  pop r10
00007dd052fdb93f  pop r9
00007dd052fdb941  pop r8
00007dd052fdb943  pop rsi
00007dd052fdb944  pop rdi
00007dd052fdb945  pop rdx
00007dd052fdb946  pop rcx
00007dd052fdb947  pop rax
00007dd052fdb948  add rsp, 0x08
00007dd052fdb94c  jmp 0x00007DD052FD9210
00007dd052fdb951  sub rsp, 0x08
00007dd052fdb955  push rax
00007dd052fdb956  push rcx
00007dd052fdb957  push rdx
00007dd052fdb958  push rdi
00007dd052fdb959  push rsi
00007dd052fdb95a  push r8
00007dd052fdb95c  push r9
00007dd052fdb95e  push r10
00007dd052fdb960  push r11
00007dd052fdb962  sub rsp, 0xF0
00007dd052fdb969  vmovaps [rsp], xmm0
00007dd052fdb96e  vmovaps [rsp+0x10], xmm1
00007dd052fdb974  vmovaps [rsp+0x20], xmm2
00007dd052fdb97a  vmovaps [rsp+0x30], xmm4
00007dd052fdb980  vmovaps [rsp+0x40], xmm5
00007dd052fdb986  vmovaps [rsp+0x50], xmm6
00007dd052fdb98c  vmovaps [rsp+0x60], xmm7
00007dd052fdb992  vmovaps [rsp+0x70], xmm8
00007dd052fdb998  vmovaps [rsp+0x80], xmm9
00007dd052fdb9a1  vmovaps [rsp+0x90], xmm10
00007dd052fdb9aa  vmovaps [rsp+0xA0], xmm11
00007dd052fdb9b3  vmovaps [rsp+0xB0], xmm12
00007dd052fdb9bc  vmovaps [rsp+0xC0], xmm13
00007dd052fdb9c5  vmovaps [rsp+0xD0], xmm14
00007dd052fdb9ce  vmovaps [rsp+0xE0], xmm15
00007dd052fdb9d7  sub rsp, 0x30
00007dd052fdb9db  movaps [rsp], xmm3
00007dd052fdb9df  movaps [rsp+0x10], xmm1
00007dd052fdb9e4  movaps [rsp+0x20], xmm15
00007dd052fdb9ea  lea rdi, [rsp]
00007dd052fdb9ee  mov esi, 0x00
00007dd052fdb9f3  mov rax, 0x61D0404B9530
00007dd052fdb9fd  call rax
00007dd052fdb9ff  movaps xmm3, [rsp]
00007dd052fdba03  add rsp, 0x30
00007dd052fdba07  vmovaps xmm0, [rsp]
00007dd052fdba0c  vmovaps xmm1, [rsp+0x10]
00007dd052fdba12  vmovaps xmm2, [rsp+0x20]
00007dd052fdba18  vmovaps xmm4, [rsp+0x30]
00007dd052fdba1e  vmovaps xmm5, [rsp+0x40]
00007dd052fdba24  vmovaps xmm6, [rsp+0x50]
00007dd052fdba2a  vmovaps xmm7, [rsp+0x60]
00007dd052fdba30  vmovaps xmm8, [rsp+0x70]
00007dd052fdba36  vmovaps xmm9, [rsp+0x80]
00007dd052fdba3f  vmovaps xmm10, [rsp+0x90]
00007dd052fdba48  vmovaps xmm11, [rsp+0xA0]
00007dd052fdba51  vmovaps xmm12, [rsp+0xB0]
00007dd052fdba5a  vmovaps xmm13, [rsp+0xC0]
00007dd052fdba63  vmovaps xmm14, [rsp+0xD0]
00007dd052fdba6c  vmovaps xmm15, [rsp+0xE0]
00007dd052fdba75  add rsp, 0xF0
00007dd052fdba7c  pop r11
00007dd052fdba7e  pop r10
00007dd052fdba80  pop r9
00007dd052fdba82  pop r8
00007dd052fdba84  pop rsi
00007dd052fdba85  pop rdi
00007dd052fdba86  pop rdx
00007dd052fdba87  pop rcx
00007dd052fdba88  pop rax
00007dd052fdba89  add rsp, 0x08
00007dd052fdba8d  jmp 0x00007DD052FD929F
00007dd052fdba92  call 0x00007DD052ED64F0
00007dd052fdba97  jmp 0x00007DD052FD92A9
00007dd052fdba9c  sub rsp, 0x08
00007dd052fdbaa0  push rax
00007dd052fdbaa1  push rcx
00007dd052fdbaa2  push rdx
00007dd052fdbaa3  push rdi
00007dd052fdbaa4  push rsi
00007dd052fdbaa5  push r8
00007dd052fdbaa7  push r9
00007dd052fdbaa9  push r10
00007dd052fdbaab  push r11
00007dd052fdbaad  sub rsp, 0xF0
00007dd052fdbab4  vmovaps [rsp], xmm0
00007dd052fdbab9  vmovaps [rsp+0x10], xmm1
00007dd052fdbabf  vmovaps [rsp+0x20], xmm2
00007dd052fdbac5  vmovaps [rsp+0x30], xmm3
00007dd052fdbacb  vmovaps [rsp+0x40], xmm4
00007dd052fdbad1  vmovaps [rsp+0x50], xmm5
00007dd052fdbad7  vmovaps [rsp+0x60], xmm6
00007dd052fdbadd  vmovaps [rsp+0x70], xmm7
00007dd052fdbae3  vmovaps [rsp+0x80], xmm8
00007dd052fdbaec  vmovaps [rsp+0x90], xmm9
00007dd052fdbaf5  vmovaps [rsp+0xA0], xmm10
00007dd052fdbafe  vmovaps [rsp+0xB0], xmm11
00007dd052fdbb07  vmovaps [rsp+0xC0], xmm12
00007dd052fdbb10  vmovaps [rsp+0xD0], xmm13
00007dd052fdbb19  vmovaps [rsp+0xE0], xmm14
00007dd052fdbb22  sub rsp, 0x30
00007dd052fdbb26  movaps [rsp], xmm15
00007dd052fdbb2b  movaps [rsp+0x10], xmm14
00007dd052fdbb31  movaps [rsp+0x20], xmm4
00007dd052fdbb36  lea rdi, [rsp]
00007dd052fdbb3a  mov esi, 0x00
00007dd052fdbb3f  mov rax, 0x61D0404B9530
00007dd052fdbb49  call rax
00007dd052fdbb4b  movaps xmm15, [rsp]
00007dd052fdbb50  add rsp, 0x30
00007dd052fdbb54  vmovaps xmm0, [rsp]
00007dd052fdbb59  vmovaps xmm1, [rsp+0x10]
00007dd052fdbb5f  vmovaps xmm2, [rsp+0x20]
00007dd052fdbb65  vmovaps xmm3, [rsp+0x30]
00007dd052fdbb6b  vmovaps xmm4, [rsp+0x40]
00007dd052fdbb71  vmovaps xmm5, [rsp+0x50]
00007dd052fdbb77  vmovaps xmm6, [rsp+0x60]
00007dd052fdbb7d  vmovaps xmm7, [rsp+0x70]
00007dd052fdbb83  vmovaps xmm8, [rsp+0x80]
00007dd052fdbb8c  vmovaps xmm9, [rsp+0x90]
00007dd052fdbb95  vmovaps xmm10, [rsp+0xA0]
00007dd052fdbb9e  vmovaps xmm11, [rsp+0xB0]
00007dd052fdbba7  vmovaps xmm12, [rsp+0xC0]
00007dd052fdbbb0  vmovaps xmm13, [rsp+0xD0]
00007dd052fdbbb9  vmovaps xmm14, [rsp+0xE0]
00007dd052fdbbc2  add rsp, 0xF0
00007dd052fdbbc9  pop r11
00007dd052fdbbcb  pop r10
00007dd052fdbbcd  pop r9
00007dd052fdbbcf  pop r8
00007dd052fdbbd1  pop rsi
00007dd052fdbbd2  pop rdi
00007dd052fdbbd3  pop rdx
00007dd052fdbbd4  pop rcx
00007dd052fdbbd5  pop rax
00007dd052fdbbd6  add rsp, 0x08
00007dd052fdbbda  jmp 0x00007DD052FD92D7
00007dd052fdbbdf  sub rsp, 0x08
00007dd052fdbbe3  push rax
00007dd052fdbbe4  push rcx
00007dd052fdbbe5  push rdx
00007dd052fdbbe6  push rdi
00007dd052fdbbe7  push rsi
00007dd052fdbbe8  push r8
00007dd052fdbbea  push r9
00007dd052fdbbec  push r10
00007dd052fdbbee  push r11
00007dd052fdbbf0  sub rsp, 0xF0
00007dd052fdbbf7  vmovaps [rsp], xmm0
00007dd052fdbbfc  vmovaps [rsp+0x10], xmm1
00007dd052fdbc02  vmovaps [rsp+0x20], xmm2
00007dd052fdbc08  vmovaps [rsp+0x30], xmm3
00007dd052fdbc0e  vmovaps [rsp+0x40], xmm4
00007dd052fdbc14  vmovaps [rsp+0x50], xmm5
00007dd052fdbc1a  vmovaps [rsp+0x60], xmm6
00007dd052fdbc20  vmovaps [rsp+0x70], xmm7
00007dd052fdbc26  vmovaps [rsp+0x80], xmm8
00007dd052fdbc2f  vmovaps [rsp+0x90], xmm9
00007dd052fdbc38  vmovaps [rsp+0xA0], xmm10
00007dd052fdbc41  vmovaps [rsp+0xB0], xmm11
00007dd052fdbc4a  vmovaps [rsp+0xC0], xmm12
00007dd052fdbc53  vmovaps [rsp+0xD0], xmm13
00007dd052fdbc5c  vmovaps [rsp+0xE0], xmm15
00007dd052fdbc65  sub rsp, 0x30
00007dd052fdbc69  movaps [rsp], xmm14
00007dd052fdbc6e  movaps [rsp+0x10], xmm2
00007dd052fdbc73  movaps [rsp+0x20], xmm1
00007dd052fdbc78  lea rdi, [rsp]
00007dd052fdbc7c  mov esi, 0x00
00007dd052fdbc81  mov rax, 0x61D0404B9530
00007dd052fdbc8b  call rax
00007dd052fdbc8d  movaps xmm14, [rsp]
00007dd052fdbc92  add rsp, 0x30
00007dd052fdbc96  vmovaps xmm0, [rsp]
00007dd052fdbc9b  vmovaps xmm1, [rsp+0x10]
00007dd052fdbca1  vmovaps xmm2, [rsp+0x20]
00007dd052fdbca7  vmovaps xmm3, [rsp+0x30]
00007dd052fdbcad  vmovaps xmm4, [rsp+0x40]
00007dd052fdbcb3  vmovaps xmm5, [rsp+0x50]
00007dd052fdbcb9  vmovaps xmm6, [rsp+0x60]
00007dd052fdbcbf  vmovaps xmm7, [rsp+0x70]
00007dd052fdbcc5  vmovaps xmm8, [rsp+0x80]
00007dd052fdbcce  vmovaps xmm9, [rsp+0x90]
00007dd052fdbcd7  vmovaps xmm10, [rsp+0xA0]
00007dd052fdbce0  vmovaps xmm11, [rsp+0xB0]
00007dd052fdbce9  vmovaps xmm12, [rsp+0xC0]
00007dd052fdbcf2  vmovaps xmm13, [rsp+0xD0]
00007dd052fdbcfb  vmovaps xmm15, [rsp+0xE0]
00007dd052fdbd04  add rsp, 0xF0
00007dd052fdbd0b  pop r11
00007dd052fdbd0d  pop r10
00007dd052fdbd0f  pop r9
00007dd052fdbd11  pop r8
00007dd052fdbd13  pop rsi
00007dd052fdbd14  pop rdi
00007dd052fdbd15  pop rdx
00007dd052fdbd16  pop rcx
00007dd052fdbd17  pop rax
00007dd052fdbd18  add rsp, 0x08
00007dd052fdbd1c  jmp 0x00007DD052FD92FD
00007dd052fdbd21  sub rsp, 0x08
00007dd052fdbd25  push rax
00007dd052fdbd26  push rcx
00007dd052fdbd27  push rdx
00007dd052fdbd28  push rdi
00007dd052fdbd29  push rsi
00007dd052fdbd2a  push r8
00007dd052fdbd2c  push r9
00007dd052fdbd2e  push r10
00007dd052fdbd30  push r11
00007dd052fdbd32  sub rsp, 0xF0
00007dd052fdbd39  vmovaps [rsp], xmm0
00007dd052fdbd3e  vmovaps [rsp+0x10], xmm2
00007dd052fdbd44  vmovaps [rsp+0x20], xmm3
00007dd052fdbd4a  vmovaps [rsp+0x30], xmm4
00007dd052fdbd50  vmovaps [rsp+0x40], xmm5
00007dd052fdbd56  vmovaps [rsp+0x50], xmm6
00007dd052fdbd5c  vmovaps [rsp+0x60], xmm7
00007dd052fdbd62  vmovaps [rsp+0x70], xmm8
00007dd052fdbd68  vmovaps [rsp+0x80], xmm9
00007dd052fdbd71  vmovaps [rsp+0x90], xmm10
00007dd052fdbd7a  vmovaps [rsp+0xA0], xmm11
00007dd052fdbd83  vmovaps [rsp+0xB0], xmm12
00007dd052fdbd8c  vmovaps [rsp+0xC0], xmm13
00007dd052fdbd95  vmovaps [rsp+0xD0], xmm14
00007dd052fdbd9e  vmovaps [rsp+0xE0], xmm15
00007dd052fdbda7  sub rsp, 0x30
00007dd052fdbdab  movaps [rsp], xmm1
00007dd052fdbdaf  movaps [rsp+0x10], xmm4
00007dd052fdbdb4  movaps [rsp+0x20], xmm9
00007dd052fdbdba  lea rdi, [rsp]
00007dd052fdbdbe  mov esi, 0x00
00007dd052fdbdc3  mov rax, 0x61D0404B9530
00007dd052fdbdcd  call rax
00007dd052fdbdcf  movaps xmm1, [rsp]
00007dd052fdbdd3  add rsp, 0x30
00007dd052fdbdd7  vmovaps xmm0, [rsp]
00007dd052fdbddc  vmovaps xmm2, [rsp+0x10]
00007dd052fdbde2  vmovaps xmm3, [rsp+0x20]
00007dd052fdbde8  vmovaps xmm4, [rsp+0x30]
00007dd052fdbdee  vmovaps xmm5, [rsp+0x40]
00007dd052fdbdf4  vmovaps xmm6, [rsp+0x50]
00007dd052fdbdfa  vmovaps xmm7, [rsp+0x60]
00007dd052fdbe00  vmovaps xmm8, [rsp+0x70]
00007dd052fdbe06  vmovaps xmm9, [rsp+0x80]
00007dd052fdbe0f  vmovaps xmm10, [rsp+0x90]
00007dd052fdbe18  vmovaps xmm11, [rsp+0xA0]
00007dd052fdbe21  vmovaps xmm12, [rsp+0xB0]
00007dd052fdbe2a  vmovaps xmm13, [rsp+0xC0]
00007dd052fdbe33  vmovaps xmm14, [rsp+0xD0]
00007dd052fdbe3c  vmovaps xmm15, [rsp+0xE0]
00007dd052fdbe45  add rsp, 0xF0
00007dd052fdbe4c  pop r11
00007dd052fdbe4e  pop r10
00007dd052fdbe50  pop r9
00007dd052fdbe52  pop r8
00007dd052fdbe54  pop rsi
00007dd052fdbe55  pop rdi
00007dd052fdbe56  pop rdx
00007dd052fdbe57  pop rcx
00007dd052fdbe58  pop rax
00007dd052fdbe59  add rsp, 0x08
00007dd052fdbe5d  jmp 0x00007DD052FD931B
00007dd052fdbe62  sub rsp, 0x08
00007dd052fdbe66  push rax
00007dd052fdbe67  push rcx
00007dd052fdbe68  push rdx
00007dd052fdbe69  push rdi
00007dd052fdbe6a  push rsi
00007dd052fdbe6b  push r8
00007dd052fdbe6d  push r9
00007dd052fdbe6f  push r10
00007dd052fdbe71  push r11
00007dd052fdbe73  sub rsp, 0xF0
00007dd052fdbe7a  vmovaps [rsp], xmm0
00007dd052fdbe7f  vmovaps [rsp+0x10], xmm1
00007dd052fdbe85  vmovaps [rsp+0x20], xmm2
00007dd052fdbe8b  vmovaps [rsp+0x30], xmm3
00007dd052fdbe91  vmovaps [rsp+0x40], xmm5
00007dd052fdbe97  vmovaps [rsp+0x50], xmm6
00007dd052fdbe9d  vmovaps [rsp+0x60], xmm7
00007dd052fdbea3  vmovaps [rsp+0x70], xmm8
00007dd052fdbea9  vmovaps [rsp+0x80], xmm9
00007dd052fdbeb2  vmovaps [rsp+0x90], xmm10
00007dd052fdbebb  vmovaps [rsp+0xA0], xmm11
00007dd052fdbec4  vmovaps [rsp+0xB0], xmm12
00007dd052fdbecd  vmovaps [rsp+0xC0], xmm13
00007dd052fdbed6  vmovaps [rsp+0xD0], xmm14
00007dd052fdbedf  vmovaps [rsp+0xE0], xmm15
00007dd052fdbee8  sub rsp, 0x30
00007dd052fdbeec  movaps [rsp], xmm4
00007dd052fdbef0  movaps [rsp+0x10], xmm2
00007dd052fdbef5  movaps [rsp+0x20], xmm9
00007dd052fdbefb  lea rdi, [rsp]
00007dd052fdbeff  mov esi, 0x00
00007dd052fdbf04  mov rax, 0x61D0404B9530
00007dd052fdbf0e  call rax
00007dd052fdbf10  movaps xmm4, [rsp]
00007dd052fdbf14  add rsp, 0x30
00007dd052fdbf18  vmovaps xmm0, [rsp]
00007dd052fdbf1d  vmovaps xmm1, [rsp+0x10]
00007dd052fdbf23  vmovaps xmm2, [rsp+0x20]
00007dd052fdbf29  vmovaps xmm3, [rsp+0x30]
00007dd052fdbf2f  vmovaps xmm5, [rsp+0x40]
00007dd052fdbf35  vmovaps xmm6, [rsp+0x50]
00007dd052fdbf3b  vmovaps xmm7, [rsp+0x60]
00007dd052fdbf41  vmovaps xmm8, [rsp+0x70]
00007dd052fdbf47  vmovaps xmm9, [rsp+0x80]
00007dd052fdbf50  vmovaps xmm10, [rsp+0x90]
00007dd052fdbf59  vmovaps xmm11, [rsp+0xA0]
00007dd052fdbf62  vmovaps xmm12, [rsp+0xB0]
00007dd052fdbf6b  vmovaps xmm13, [rsp+0xC0]
00007dd052fdbf74  vmovaps xmm14, [rsp+0xD0]
00007dd052fdbf7d  vmovaps xmm15, [rsp+0xE0]
00007dd052fdbf86  add rsp, 0xF0
00007dd052fdbf8d  pop r11
00007dd052fdbf8f  pop r10
00007dd052fdbf91  pop r9
00007dd052fdbf93  pop r8
00007dd052fdbf95  pop rsi
00007dd052fdbf96  pop rdi
00007dd052fdbf97  pop rdx
00007dd052fdbf98  pop rcx
00007dd052fdbf99  pop rax
00007dd052fdbf9a  add rsp, 0x08
00007dd052fdbf9e  jmp 0x00007DD052FD934B
00007dd052fdbfa3  sub rsp, 0x08
00007dd052fdbfa7  push rax
00007dd052fdbfa8  push rcx
00007dd052fdbfa9  push rdx
00007dd052fdbfaa  push rdi
00007dd052fdbfab  push rsi
00007dd052fdbfac  push r8
00007dd052fdbfae  push r9
00007dd052fdbfb0  push r10
00007dd052fdbfb2  push r11
00007dd052fdbfb4  sub rsp, 0xF0
00007dd052fdbfbb  vmovaps [rsp], xmm0
00007dd052fdbfc0  vmovaps [rsp+0x10], xmm1
00007dd052fdbfc6  vmovaps [rsp+0x20], xmm2
00007dd052fdbfcc  vmovaps [rsp+0x30], xmm3
00007dd052fdbfd2  vmovaps [rsp+0x40], xmm4
00007dd052fdbfd8  vmovaps [rsp+0x50], xmm5
00007dd052fdbfde  vmovaps [rsp+0x60], xmm6
00007dd052fdbfe4  vmovaps [rsp+0x70], xmm7
00007dd052fdbfea  vmovaps [rsp+0x80], xmm8
00007dd052fdbff3  vmovaps [rsp+0x90], xmm10
00007dd052fdbffc  vmovaps [rsp+0xA0], xmm11
00007dd052fdc005  vmovaps [rsp+0xB0], xmm12
00007dd052fdc00e  vmovaps [rsp+0xC0], xmm13
00007dd052fdc017  vmovaps [rsp+0xD0], xmm14
00007dd052fdc020  vmovaps [rsp+0xE0], xmm15
00007dd052fdc029  sub rsp, 0x30
00007dd052fdc02d  movaps [rsp], xmm9
00007dd052fdc032  movaps [rsp+0x10], xmm2
00007dd052fdc037  movaps [rsp+0x20], xmm1
00007dd052fdc03c  lea rdi, [rsp]
00007dd052fdc040  mov esi, 0x00
00007dd052fdc045  mov rax, 0x61D0404B9530
00007dd052fdc04f  call rax
00007dd052fdc051  movaps xmm9, [rsp]
00007dd052fdc056  add rsp, 0x30
00007dd052fdc05a  vmovaps xmm0, [rsp]
00007dd052fdc05f  vmovaps xmm1, [rsp+0x10]
00007dd052fdc065  vmovaps xmm2, [rsp+0x20]
00007dd052fdc06b  vmovaps xmm3, [rsp+0x30]
00007dd052fdc071  vmovaps xmm4, [rsp+0x40]
00007dd052fdc077  vmovaps xmm5, [rsp+0x50]
00007dd052fdc07d  vmovaps xmm6, [rsp+0x60]
00007dd052fdc083  vmovaps xmm7, [rsp+0x70]
00007dd052fdc089  vmovaps xmm8, [rsp+0x80]
00007dd052fdc092  vmovaps xmm10, [rsp+0x90]
00007dd052fdc09b  vmovaps xmm11, [rsp+0xA0]
00007dd052fdc0a4  vmovaps xmm12, [rsp+0xB0]
00007dd052fdc0ad  vmovaps xmm13, [rsp+0xC0]
00007dd052fdc0b6  vmovaps xmm14, [rsp+0xD0]
00007dd052fdc0bf  vmovaps xmm15, [rsp+0xE0]
00007dd052fdc0c8  add rsp, 0xF0
00007dd052fdc0cf  pop r11
00007dd052fdc0d1  pop r10
00007dd052fdc0d3  pop r9
00007dd052fdc0d5  pop r8
00007dd052fdc0d7  pop rsi
00007dd052fdc0d8  pop rdi
00007dd052fdc0d9  pop rdx
00007dd052fdc0da  pop rcx
00007dd052fdc0db  pop rax
00007dd052fdc0dc  add rsp, 0x08
00007dd052fdc0e0  jmp 0x00007DD052FD9381
00007dd052fdc0e5  sub rsp, 0x08
00007dd052fdc0e9  push rax
00007dd052fdc0ea  push rcx
00007dd052fdc0eb  push rdx
00007dd052fdc0ec  push rdi
00007dd052fdc0ed  push rsi
00007dd052fdc0ee  push r8
00007dd052fdc0f0  push r9
00007dd052fdc0f2  push r10
00007dd052fdc0f4  push r11
00007dd052fdc0f6  sub rsp, 0xF0
00007dd052fdc0fd  vmovaps [rsp], xmm0
00007dd052fdc102  vmovaps [rsp+0x10], xmm2
00007dd052fdc108  vmovaps [rsp+0x20], xmm3
00007dd052fdc10e  vmovaps [rsp+0x30], xmm4
00007dd052fdc114  vmovaps [rsp+0x40], xmm5
00007dd052fdc11a  vmovaps [rsp+0x50], xmm6
00007dd052fdc120  vmovaps [rsp+0x60], xmm7
00007dd052fdc126  vmovaps [rsp+0x70], xmm8
00007dd052fdc12c  vmovaps [rsp+0x80], xmm9
00007dd052fdc135  vmovaps [rsp+0x90], xmm10
00007dd052fdc13e  vmovaps [rsp+0xA0], xmm11
00007dd052fdc147  vmovaps [rsp+0xB0], xmm12
00007dd052fdc150  vmovaps [rsp+0xC0], xmm13
00007dd052fdc159  vmovaps [rsp+0xD0], xmm14
00007dd052fdc162  vmovaps [rsp+0xE0], xmm15
00007dd052fdc16b  sub rsp, 0x30
00007dd052fdc16f  movaps [rsp], xmm1
00007dd052fdc173  movaps [rsp+0x10], xmm15
00007dd052fdc179  movaps [rsp+0x20], xmm6
00007dd052fdc17e  lea rdi, [rsp]
00007dd052fdc182  mov esi, 0x00
00007dd052fdc187  mov rax, 0x61D0404B9530
00007dd052fdc191  call rax
00007dd052fdc193  movaps xmm1, [rsp]
00007dd052fdc197  add rsp, 0x30
00007dd052fdc19b  vmovaps xmm0, [rsp]
00007dd052fdc1a0  vmovaps xmm2, [rsp+0x10]
00007dd052fdc1a6  vmovaps xmm3, [rsp+0x20]
00007dd052fdc1ac  vmovaps xmm4, [rsp+0x30]
00007dd052fdc1b2  vmovaps xmm5, [rsp+0x40]
00007dd052fdc1b8  vmovaps xmm6, [rsp+0x50]
00007dd052fdc1be  vmovaps xmm7, [rsp+0x60]
00007dd052fdc1c4  vmovaps xmm8, [rsp+0x70]
00007dd052fdc1ca  vmovaps xmm9, [rsp+0x80]
00007dd052fdc1d3  vmovaps xmm10, [rsp+0x90]
00007dd052fdc1dc  vmovaps xmm11, [rsp+0xA0]
00007dd052fdc1e5  vmovaps xmm12, [rsp+0xB0]
00007dd052fdc1ee  vmovaps xmm13, [rsp+0xC0]
00007dd052fdc1f7  vmovaps xmm14, [rsp+0xD0]
00007dd052fdc200  vmovaps xmm15, [rsp+0xE0]
00007dd052fdc209  add rsp, 0xF0
00007dd052fdc210  pop r11
00007dd052fdc212  pop r10
00007dd052fdc214  pop r9
00007dd052fdc216  pop r8
00007dd052fdc218  pop rsi
00007dd052fdc219  pop rdi
00007dd052fdc21a  pop rdx
00007dd052fdc21b  pop rcx
00007dd052fdc21c  pop rax
00007dd052fdc21d  add rsp, 0x08
00007dd052fdc221  jmp 0x00007DD052FD93A2
00007dd052fdc226  sub rsp, 0x08
00007dd052fdc22a  push rax
00007dd052fdc22b  push rcx
00007dd052fdc22c  push rdx
00007dd052fdc22d  push rdi
00007dd052fdc22e  push rsi
00007dd052fdc22f  push r8
00007dd052fdc231  push r9
00007dd052fdc233  push r10
00007dd052fdc235  push r11
00007dd052fdc237  sub rsp, 0xF0
00007dd052fdc23e  vmovaps [rsp], xmm0
00007dd052fdc243  vmovaps [rsp+0x10], xmm1
00007dd052fdc249  vmovaps [rsp+0x20], xmm2
00007dd052fdc24f  vmovaps [rsp+0x30], xmm3
00007dd052fdc255  vmovaps [rsp+0x40], xmm4
00007dd052fdc25b  vmovaps [rsp+0x50], xmm5
00007dd052fdc261  vmovaps [rsp+0x60], xmm6
00007dd052fdc267  vmovaps [rsp+0x70], xmm7
00007dd052fdc26d  vmovaps [rsp+0x80], xmm8
00007dd052fdc276  vmovaps [rsp+0x90], xmm9
00007dd052fdc27f  vmovaps [rsp+0xA0], xmm10
00007dd052fdc288  vmovaps [rsp+0xB0], xmm11
00007dd052fdc291  vmovaps [rsp+0xC0], xmm12
00007dd052fdc29a  vmovaps [rsp+0xD0], xmm13
00007dd052fdc2a3  vmovaps [rsp+0xE0], xmm14
00007dd052fdc2ac  sub rsp, 0x30
00007dd052fdc2b0  movaps [rsp], xmm15
00007dd052fdc2b5  movaps [rsp+0x10], xmm5
00007dd052fdc2ba  movaps [rsp+0x20], xmm3
00007dd052fdc2bf  lea rdi, [rsp]
00007dd052fdc2c3  mov esi, 0x00
00007dd052fdc2c8  mov rax, 0x61D0404B9530
00007dd052fdc2d2  call rax
00007dd052fdc2d4  movaps xmm15, [rsp]
00007dd052fdc2d9  add rsp, 0x30
00007dd052fdc2dd  vmovaps xmm0, [rsp]
00007dd052fdc2e2  vmovaps xmm1, [rsp+0x10]
00007dd052fdc2e8  vmovaps xmm2, [rsp+0x20]
00007dd052fdc2ee  vmovaps xmm3, [rsp+0x30]
00007dd052fdc2f4  vmovaps xmm4, [rsp+0x40]
00007dd052fdc2fa  vmovaps xmm5, [rsp+0x50]
00007dd052fdc300  vmovaps xmm6, [rsp+0x60]
00007dd052fdc306  vmovaps xmm7, [rsp+0x70]
00007dd052fdc30c  vmovaps xmm8, [rsp+0x80]
00007dd052fdc315  vmovaps xmm9, [rsp+0x90]
00007dd052fdc31e  vmovaps xmm10, [rsp+0xA0]
00007dd052fdc327  vmovaps xmm11, [rsp+0xB0]
00007dd052fdc330  vmovaps xmm12, [rsp+0xC0]
00007dd052fdc339  vmovaps xmm13, [rsp+0xD0]
00007dd052fdc342  vmovaps xmm14, [rsp+0xE0]
00007dd052fdc34b  add rsp, 0xF0
00007dd052fdc352  pop r11
00007dd052fdc354  pop r10
00007dd052fdc356  pop r9
00007dd052fdc358  pop r8
00007dd052fdc35a  pop rsi
00007dd052fdc35b  pop rdi
00007dd052fdc35c  pop rdx
00007dd052fdc35d  pop rcx
00007dd052fdc35e  pop rax
00007dd052fdc35f  add rsp, 0x08
00007dd052fdc363  jmp 0x00007DD052FD93BC
00007dd052fdc368  sub rsp, 0x08
00007dd052fdc36c  push rax
00007dd052fdc36d  push rcx
00007dd052fdc36e  push rdx
00007dd052fdc36f  push rdi
00007dd052fdc370  push rsi
00007dd052fdc371  push r8
00007dd052fdc373  push r9
00007dd052fdc375  push r10
00007dd052fdc377  push r11
00007dd052fdc379  sub rsp, 0xF0
00007dd052fdc380  vmovaps [rsp], xmm0
00007dd052fdc385  vmovaps [rsp+0x10], xmm1
00007dd052fdc38b  vmovaps [rsp+0x20], xmm2
00007dd052fdc391  vmovaps [rsp+0x30], xmm3
00007dd052fdc397  vmovaps [rsp+0x40], xmm4
00007dd052fdc39d  vmovaps [rsp+0x50], xmm6
00007dd052fdc3a3  vmovaps [rsp+0x60], xmm7
00007dd052fdc3a9  vmovaps [rsp+0x70], xmm8
00007dd052fdc3af  vmovaps [rsp+0x80], xmm9
00007dd052fdc3b8  vmovaps [rsp+0x90], xmm10
00007dd052fdc3c1  vmovaps [rsp+0xA0], xmm11
00007dd052fdc3ca  vmovaps [rsp+0xB0], xmm12
00007dd052fdc3d3  vmovaps [rsp+0xC0], xmm13
00007dd052fdc3dc  vmovaps [rsp+0xD0], xmm14
00007dd052fdc3e5  vmovaps [rsp+0xE0], xmm15
00007dd052fdc3ee  sub rsp, 0x30
00007dd052fdc3f2  movaps [rsp], xmm5
00007dd052fdc3f6  movaps [rsp+0x10], xmm8
00007dd052fdc3fc  movaps [rsp+0x20], xmm6
00007dd052fdc401  lea rdi, [rsp]
00007dd052fdc405  mov esi, 0x00
00007dd052fdc40a  mov rax, 0x61D0404B9530
00007dd052fdc414  call rax
00007dd052fdc416  movaps xmm5, [rsp]
00007dd052fdc41a  add rsp, 0x30
00007dd052fdc41e  vmovaps xmm0, [rsp]
00007dd052fdc423  vmovaps xmm1, [rsp+0x10]
00007dd052fdc429  vmovaps xmm2, [rsp+0x20]
00007dd052fdc42f  vmovaps xmm3, [rsp+0x30]
00007dd052fdc435  vmovaps xmm4, [rsp+0x40]
00007dd052fdc43b  vmovaps xmm6, [rsp+0x50]
00007dd052fdc441  vmovaps xmm7, [rsp+0x60]
00007dd052fdc447  vmovaps xmm8, [rsp+0x70]
00007dd052fdc44d  vmovaps xmm9, [rsp+0x80]
00007dd052fdc456  vmovaps xmm10, [rsp+0x90]
00007dd052fdc45f  vmovaps xmm11, [rsp+0xA0]
00007dd052fdc468  vmovaps xmm12, [rsp+0xB0]
00007dd052fdc471  vmovaps xmm13, [rsp+0xC0]
00007dd052fdc47a  vmovaps xmm14, [rsp+0xD0]
00007dd052fdc483  vmovaps xmm15, [rsp+0xE0]
00007dd052fdc48c  add rsp, 0xF0
00007dd052fdc493  pop r11
00007dd052fdc495  pop r10
00007dd052fdc497  pop r9
00007dd052fdc499  pop r8
00007dd052fdc49b  pop rsi
00007dd052fdc49c  pop rdi
00007dd052fdc49d  pop rdx
00007dd052fdc49e  pop rcx
00007dd052fdc49f  pop rax
00007dd052fdc4a0  add rsp, 0x08
00007dd052fdc4a4  jmp 0x00007DD052FD93E0
00007dd052fdc4a9  sub rsp, 0x08
00007dd052fdc4ad  push rax
00007dd052fdc4ae  push rcx
00007dd052fdc4af  push rdx
00007dd052fdc4b0  push rdi
00007dd052fdc4b1  push rsi
00007dd052fdc4b2  push r8
00007dd052fdc4b4  push r9
00007dd052fdc4b6  push r10
00007dd052fdc4b8  push r11
00007dd052fdc4ba  sub rsp, 0xF0
00007dd052fdc4c1  vmovaps [rsp], xmm0
00007dd052fdc4c6  vmovaps [rsp+0x10], xmm1
00007dd052fdc4cc  vmovaps [rsp+0x20], xmm2
00007dd052fdc4d2  vmovaps [rsp+0x30], xmm3
00007dd052fdc4d8  vmovaps [rsp+0x40], xmm4
00007dd052fdc4de  vmovaps [rsp+0x50], xmm5
00007dd052fdc4e4  vmovaps [rsp+0x60], xmm7
00007dd052fdc4ea  vmovaps [rsp+0x70], xmm8
00007dd052fdc4f0  vmovaps [rsp+0x80], xmm9
00007dd052fdc4f9  vmovaps [rsp+0x90], xmm10
00007dd052fdc502  vmovaps [rsp+0xA0], xmm11
00007dd052fdc50b  vmovaps [rsp+0xB0], xmm12
00007dd052fdc514  vmovaps [rsp+0xC0], xmm13
00007dd052fdc51d  vmovaps [rsp+0xD0], xmm14
00007dd052fdc526  vmovaps [rsp+0xE0], xmm15
00007dd052fdc52f  sub rsp, 0x30
00007dd052fdc533  movaps [rsp], xmm6
00007dd052fdc537  movaps [rsp+0x10], xmm10
00007dd052fdc53d  movaps [rsp+0x20], xmm8
00007dd052fdc543  lea rdi, [rsp]
00007dd052fdc547  mov esi, 0x00
00007dd052fdc54c  mov rax, 0x61D0404B9530
00007dd052fdc556  call rax
00007dd052fdc558  movaps xmm6, [rsp]
00007dd052fdc55c  add rsp, 0x30
00007dd052fdc560  vmovaps xmm0, [rsp]
00007dd052fdc565  vmovaps xmm1, [rsp+0x10]
00007dd052fdc56b  vmovaps xmm2, [rsp+0x20]
00007dd052fdc571  vmovaps xmm3, [rsp+0x30]
00007dd052fdc577  vmovaps xmm4, [rsp+0x40]
00007dd052fdc57d  vmovaps xmm5, [rsp+0x50]
00007dd052fdc583  vmovaps xmm7, [rsp+0x60]
00007dd052fdc589  vmovaps xmm8, [rsp+0x70]
00007dd052fdc58f  vmovaps xmm9, [rsp+0x80]
00007dd052fdc598  vmovaps xmm10, [rsp+0x90]
00007dd052fdc5a1  vmovaps xmm11, [rsp+0xA0]
00007dd052fdc5aa  vmovaps xmm12, [rsp+0xB0]
00007dd052fdc5b3  vmovaps xmm13, [rsp+0xC0]
00007dd052fdc5bc  vmovaps xmm14, [rsp+0xD0]
00007dd052fdc5c5  vmovaps xmm15, [rsp+0xE0]
00007dd052fdc5ce  add rsp, 0xF0
00007dd052fdc5d5  pop r11
00007dd052fdc5d7  pop r10
00007dd052fdc5d9  pop r9
00007dd052fdc5db  pop r8
00007dd052fdc5dd  pop rsi
00007dd052fdc5de  pop rdi
00007dd052fdc5df  pop rdx
00007dd052fdc5e0  pop rcx
00007dd052fdc5e1  pop rax
00007dd052fdc5e2  add rsp, 0x08
00007dd052fdc5e6  jmp 0x00007DD052FD9405
00007dd052fdc5eb  sub rsp, 0x08
00007dd052fdc5ef  push rax
00007dd052fdc5f0  push rcx
00007dd052fdc5f1  push rdx
00007dd052fdc5f2  push rdi
00007dd052fdc5f3  push rsi
00007dd052fdc5f4  push r8
00007dd052fdc5f6  push r9
00007dd052fdc5f8  push r10
00007dd052fdc5fa  push r11
00007dd052fdc5fc  sub rsp, 0xF0
00007dd052fdc603  vmovaps [rsp], xmm0
00007dd052fdc608  vmovaps [rsp+0x10], xmm1
00007dd052fdc60e  vmovaps [rsp+0x20], xmm2
00007dd052fdc614  vmovaps [rsp+0x30], xmm3
00007dd052fdc61a  vmovaps [rsp+0x40], xmm4
00007dd052fdc620  vmovaps [rsp+0x50], xmm5
00007dd052fdc626  vmovaps [rsp+0x60], xmm6
00007dd052fdc62c  vmovaps [rsp+0x70], xmm7
00007dd052fdc632  vmovaps [rsp+0x80], xmm8
00007dd052fdc63b  vmovaps [rsp+0x90], xmm9
00007dd052fdc644  vmovaps [rsp+0xA0], xmm11
00007dd052fdc64d  vmovaps [rsp+0xB0], xmm12
00007dd052fdc656  vmovaps [rsp+0xC0], xmm13
00007dd052fdc65f  vmovaps [rsp+0xD0], xmm14
00007dd052fdc668  vmovaps [rsp+0xE0], xmm15
00007dd052fdc671  sub rsp, 0x30
00007dd052fdc675  movaps [rsp], xmm10
00007dd052fdc67a  movaps [rsp+0x10], xmm8
00007dd052fdc680  movaps [rsp+0x20], xmm14
00007dd052fdc686  lea rdi, [rsp]
00007dd052fdc68a  mov esi, 0x00
00007dd052fdc68f  mov rax, 0x61D0404B9530
00007dd052fdc699  call rax
00007dd052fdc69b  movaps xmm10, [rsp]
00007dd052fdc6a0  add rsp, 0x30
00007dd052fdc6a4  vmovaps xmm0, [rsp]
00007dd052fdc6a9  vmovaps xmm1, [rsp+0x10]
00007dd052fdc6af  vmovaps xmm2, [rsp+0x20]
00007dd052fdc6b5  vmovaps xmm3, [rsp+0x30]
00007dd052fdc6bb  vmovaps xmm4, [rsp+0x40]
00007dd052fdc6c1  vmovaps xmm5, [rsp+0x50]
00007dd052fdc6c7  vmovaps xmm6, [rsp+0x60]
00007dd052fdc6cd  vmovaps xmm7, [rsp+0x70]
00007dd052fdc6d3  vmovaps xmm8, [rsp+0x80]
00007dd052fdc6dc  vmovaps xmm9, [rsp+0x90]
00007dd052fdc6e5  vmovaps xmm11, [rsp+0xA0]
00007dd052fdc6ee  vmovaps xmm12, [rsp+0xB0]
00007dd052fdc6f7  vmovaps xmm13, [rsp+0xC0]
00007dd052fdc700  vmovaps xmm14, [rsp+0xD0]
00007dd052fdc709  vmovaps xmm15, [rsp+0xE0]
00007dd052fdc712  add rsp, 0xF0
00007dd052fdc719  pop r11
00007dd052fdc71b  pop r10
00007dd052fdc71d  pop r9
00007dd052fdc71f  pop r8
00007dd052fdc721  pop rsi
00007dd052fdc722  pop rdi
00007dd052fdc723  pop rdx
00007dd052fdc724  pop rcx
00007dd052fdc725  pop rax
00007dd052fdc726  add rsp, 0x08
00007dd052fdc72a  jmp 0x00007DD052FD9425
00007dd052fdc72f  sub rsp, 0x08
00007dd052fdc733  push rax
00007dd052fdc734  push rcx
00007dd052fdc735  push rdx
00007dd052fdc736  push rdi
00007dd052fdc737  push rsi
00007dd052fdc738  push r8
00007dd052fdc73a  push r9
00007dd052fdc73c  push r10
00007dd052fdc73e  push r11
00007dd052fdc740  sub rsp, 0xF0
00007dd052fdc747  vmovaps [rsp], xmm0
00007dd052fdc74c  vmovaps [rsp+0x10], xmm1
00007dd052fdc752  vmovaps [rsp+0x20], xmm2
00007dd052fdc758  vmovaps [rsp+0x30], xmm3
00007dd052fdc75e  vmovaps [rsp+0x40], xmm4
00007dd052fdc764  vmovaps [rsp+0x50], xmm5
00007dd052fdc76a  vmovaps [rsp+0x60], xmm6
00007dd052fdc770  vmovaps [rsp+0x70], xmm7
00007dd052fdc776  vmovaps [rsp+0x80], xmm8
00007dd052fdc77f  vmovaps [rsp+0x90], xmm9
00007dd052fdc788  vmovaps [rsp+0xA0], xmm10
00007dd052fdc791  vmovaps [rsp+0xB0], xmm11
00007dd052fdc79a  vmovaps [rsp+0xC0], xmm12
00007dd052fdc7a3  vmovaps [rsp+0xD0], xmm13
00007dd052fdc7ac  vmovaps [rsp+0xE0], xmm15
00007dd052fdc7b5  sub rsp, 0x30
00007dd052fdc7b9  movaps [rsp], xmm14
00007dd052fdc7be  movaps [rsp+0x10], xmm8
00007dd052fdc7c4  movaps [rsp+0x20], xmm4
00007dd052fdc7c9  lea rdi, [rsp]
00007dd052fdc7cd  mov esi, 0x00
00007dd052fdc7d2  mov rax, 0x61D0404B9530
00007dd052fdc7dc  call rax
00007dd052fdc7de  movaps xmm14, [rsp]
00007dd052fdc7e3  add rsp, 0x30
00007dd052fdc7e7  vmovaps xmm0, [rsp]
00007dd052fdc7ec  vmovaps xmm1, [rsp+0x10]
00007dd052fdc7f2  vmovaps xmm2, [rsp+0x20]
00007dd052fdc7f8  vmovaps xmm3, [rsp+0x30]
00007dd052fdc7fe  vmovaps xmm4, [rsp+0x40]
00007dd052fdc804  vmovaps xmm5, [rsp+0x50]
00007dd052fdc80a  vmovaps xmm6, [rsp+0x60]
00007dd052fdc810  vmovaps xmm7, [rsp+0x70]
00007dd052fdc816  vmovaps xmm8, [rsp+0x80]
00007dd052fdc81f  vmovaps xmm9, [rsp+0x90]
00007dd052fdc828  vmovaps xmm10, [rsp+0xA0]
00007dd052fdc831  vmovaps xmm11, [rsp+0xB0]
00007dd052fdc83a  vmovaps xmm12, [rsp+0xC0]
00007dd052fdc843  vmovaps xmm13, [rsp+0xD0]
00007dd052fdc84c  vmovaps xmm15, [rsp+0xE0]
00007dd052fdc855  add rsp, 0xF0
00007dd052fdc85c  pop r11
00007dd052fdc85e  pop r10
00007dd052fdc860  pop r9
00007dd052fdc862  pop r8
00007dd052fdc864  pop rsi
00007dd052fdc865  pop rdi
00007dd052fdc866  pop rdx
00007dd052fdc867  pop rcx
00007dd052fdc868  pop rax
00007dd052fdc869  add rsp, 0x08
00007dd052fdc86d  jmp 0x00007DD052FD9445
00007dd052fdc872  sub rsp, 0x08
00007dd052fdc876  push rax
00007dd052fdc877  push rcx
00007dd052fdc878  push rdx
00007dd052fdc879  push rdi
00007dd052fdc87a  push rsi
00007dd052fdc87b  push r8
00007dd052fdc87d  push r9
00007dd052fdc87f  push r10
00007dd052fdc881  push r11
00007dd052fdc883  sub rsp, 0xF0
00007dd052fdc88a  vmovaps [rsp], xmm0
00007dd052fdc88f  vmovaps [rsp+0x10], xmm1
00007dd052fdc895  vmovaps [rsp+0x20], xmm2
00007dd052fdc89b  vmovaps [rsp+0x30], xmm3
00007dd052fdc8a1  vmovaps [rsp+0x40], xmm5
00007dd052fdc8a7  vmovaps [rsp+0x50], xmm6
00007dd052fdc8ad  vmovaps [rsp+0x60], xmm7
00007dd052fdc8b3  vmovaps [rsp+0x70], xmm8
00007dd052fdc8b9  vmovaps [rsp+0x80], xmm9
00007dd052fdc8c2  vmovaps [rsp+0x90], xmm10
00007dd052fdc8cb  vmovaps [rsp+0xA0], xmm11
00007dd052fdc8d4  vmovaps [rsp+0xB0], xmm12
00007dd052fdc8dd  vmovaps [rsp+0xC0], xmm13
00007dd052fdc8e6  vmovaps [rsp+0xD0], xmm14
00007dd052fdc8ef  vmovaps [rsp+0xE0], xmm15
00007dd052fdc8f8  sub rsp, 0x30
00007dd052fdc8fc  movaps [rsp], xmm4
00007dd052fdc900  movaps [rsp+0x10], xmm13
00007dd052fdc906  movaps [rsp+0x20], xmm8
00007dd052fdc90c  lea rdi, [rsp]
00007dd052fdc910  mov esi, 0x00
00007dd052fdc915  mov rax, 0x61D0404B9530
00007dd052fdc91f  call rax
00007dd052fdc921  movaps xmm4, [rsp]
00007dd052fdc925  add rsp, 0x30
00007dd052fdc929  vmovaps xmm0, [rsp]
00007dd052fdc92e  vmovaps xmm1, [rsp+0x10]
00007dd052fdc934  vmovaps xmm2, [rsp+0x20]
00007dd052fdc93a  vmovaps xmm3, [rsp+0x30]
00007dd052fdc940  vmovaps xmm5, [rsp+0x40]
00007dd052fdc946  vmovaps xmm6, [rsp+0x50]
00007dd052fdc94c  vmovaps xmm7, [rsp+0x60]
00007dd052fdc952  vmovaps xmm8, [rsp+0x70]
00007dd052fdc958  vmovaps xmm9, [rsp+0x80]
00007dd052fdc961  vmovaps xmm10, [rsp+0x90]
00007dd052fdc96a  vmovaps xmm11, [rsp+0xA0]
00007dd052fdc973  vmovaps xmm12, [rsp+0xB0]
00007dd052fdc97c  vmovaps xmm13, [rsp+0xC0]
00007dd052fdc985  vmovaps xmm14, [rsp+0xD0]
00007dd052fdc98e  vmovaps xmm15, [rsp+0xE0]
00007dd052fdc997  add rsp, 0xF0
00007dd052fdc99e  pop r11
00007dd052fdc9a0  pop r10
00007dd052fdc9a2  pop r9
00007dd052fdc9a4  pop r8
00007dd052fdc9a6  pop rsi
00007dd052fdc9a7  pop rdi
00007dd052fdc9a8  pop rdx
00007dd052fdc9a9  pop rcx
00007dd052fdc9aa  pop rax
00007dd052fdc9ab  add rsp, 0x08
00007dd052fdc9af  jmp 0x00007DD052FD946A
00007dd052fdc9b4  sub rsp, 0x08
00007dd052fdc9b8  push rax
00007dd052fdc9b9  push rcx
00007dd052fdc9ba  push rdx
00007dd052fdc9bb  push rdi
00007dd052fdc9bc  push rsi
00007dd052fdc9bd  push r8
00007dd052fdc9bf  push r9
00007dd052fdc9c1  push r10
00007dd052fdc9c3  push r11
00007dd052fdc9c5  sub rsp, 0xF0
00007dd052fdc9cc  vmovaps [rsp], xmm0
00007dd052fdc9d1  vmovaps [rsp+0x10], xmm1
00007dd052fdc9d7  vmovaps [rsp+0x20], xmm2
00007dd052fdc9dd  vmovaps [rsp+0x30], xmm3
00007dd052fdc9e3  vmovaps [rsp+0x40], xmm4
00007dd052fdc9e9  vmovaps [rsp+0x50], xmm5
00007dd052fdc9ef  vmovaps [rsp+0x60], xmm6
00007dd052fdc9f5  vmovaps [rsp+0x70], xmm7
00007dd052fdc9fb  vmovaps [rsp+0x80], xmm8
00007dd052fdca04  vmovaps [rsp+0x90], xmm9
00007dd052fdca0d  vmovaps [rsp+0xA0], xmm10
00007dd052fdca16  vmovaps [rsp+0xB0], xmm11
00007dd052fdca1f  vmovaps [rsp+0xC0], xmm12
00007dd052fdca28  vmovaps [rsp+0xD0], xmm14
00007dd052fdca31  vmovaps [rsp+0xE0], xmm15
00007dd052fdca3a  sub rsp, 0x30
00007dd052fdca3e  movaps [rsp], xmm13
00007dd052fdca43  movaps [rsp+0x10], xmm15
00007dd052fdca49  movaps [rsp+0x20], xmm9
00007dd052fdca4f  lea rdi, [rsp]
00007dd052fdca53  mov esi, 0x00
00007dd052fdca58  mov rax, 0x61D0404B9530
00007dd052fdca62  call rax
00007dd052fdca64  movaps xmm13, [rsp]
00007dd052fdca69  add rsp, 0x30
00007dd052fdca6d  vmovaps xmm0, [rsp]
00007dd052fdca72  vmovaps xmm1, [rsp+0x10]
00007dd052fdca78  vmovaps xmm2, [rsp+0x20]
00007dd052fdca7e  vmovaps xmm3, [rsp+0x30]
00007dd052fdca84  vmovaps xmm4, [rsp+0x40]
00007dd052fdca8a  vmovaps xmm5, [rsp+0x50]
00007dd052fdca90  vmovaps xmm6, [rsp+0x60]
00007dd052fdca96  vmovaps xmm7, [rsp+0x70]
00007dd052fdca9c  vmovaps xmm8, [rsp+0x80]
00007dd052fdcaa5  vmovaps xmm9, [rsp+0x90]
00007dd052fdcaae  vmovaps xmm10, [rsp+0xA0]
00007dd052fdcab7  vmovaps xmm11, [rsp+0xB0]
00007dd052fdcac0  vmovaps xmm12, [rsp+0xC0]
00007dd052fdcac9  vmovaps xmm14, [rsp+0xD0]
00007dd052fdcad2  vmovaps xmm15, [rsp+0xE0]
00007dd052fdcadb  add rsp, 0xF0
00007dd052fdcae2  pop r11
00007dd052fdcae4  pop r10
00007dd052fdcae6  pop r9
00007dd052fdcae8  pop r8
00007dd052fdcaea  pop rsi
00007dd052fdcaeb  pop rdi
00007dd052fdcaec  pop rdx
00007dd052fdcaed  pop rcx
00007dd052fdcaee  pop rax
00007dd052fdcaef  add rsp, 0x08
00007dd052fdcaf3  jmp 0x00007DD052FD9485
00007dd052fdcaf8  sub rsp, 0x08
00007dd052fdcafc  push rax
00007dd052fdcafd  push rcx
00007dd052fdcafe  push rdx
00007dd052fdcaff  push rdi
00007dd052fdcb00  push rsi
00007dd052fdcb01  push r8
00007dd052fdcb03  push r9
00007dd052fdcb05  push r10
00007dd052fdcb07  push r11
00007dd052fdcb09  sub rsp, 0xF0
00007dd052fdcb10  vmovaps [rsp], xmm0
00007dd052fdcb15  vmovaps [rsp+0x10], xmm1
00007dd052fdcb1b  vmovaps [rsp+0x20], xmm2
00007dd052fdcb21  vmovaps [rsp+0x30], xmm3
00007dd052fdcb27  vmovaps [rsp+0x40], xmm4
00007dd052fdcb2d  vmovaps [rsp+0x50], xmm5
00007dd052fdcb33  vmovaps [rsp+0x60], xmm6
00007dd052fdcb39  vmovaps [rsp+0x70], xmm7
00007dd052fdcb3f  vmovaps [rsp+0x80], xmm8
00007dd052fdcb48  vmovaps [rsp+0x90], xmm9
00007dd052fdcb51  vmovaps [rsp+0xA0], xmm10
00007dd052fdcb5a  vmovaps [rsp+0xB0], xmm11
00007dd052fdcb63  vmovaps [rsp+0xC0], xmm12
00007dd052fdcb6c  vmovaps [rsp+0xD0], xmm13
00007dd052fdcb75  vmovaps [rsp+0xE0], xmm14
00007dd052fdcb7e  sub rsp, 0x30
00007dd052fdcb82  movaps [rsp], xmm15
00007dd052fdcb87  movaps [rsp+0x10], xmm1
00007dd052fdcb8c  movaps [rsp+0x20], xmm5
00007dd052fdcb91  lea rdi, [rsp]
00007dd052fdcb95  mov esi, 0x00
00007dd052fdcb9a  mov rax, 0x61D0404B9530
00007dd052fdcba4  call rax
00007dd052fdcba6  movaps xmm15, [rsp]
00007dd052fdcbab  add rsp, 0x30
00007dd052fdcbaf  vmovaps xmm0, [rsp]
00007dd052fdcbb4  vmovaps xmm1, [rsp+0x10]
00007dd052fdcbba  vmovaps xmm2, [rsp+0x20]
00007dd052fdcbc0  vmovaps xmm3, [rsp+0x30]
00007dd052fdcbc6  vmovaps xmm4, [rsp+0x40]
00007dd052fdcbcc  vmovaps xmm5, [rsp+0x50]
00007dd052fdcbd2  vmovaps xmm6, [rsp+0x60]
00007dd052fdcbd8  vmovaps xmm7, [rsp+0x70]
00007dd052fdcbde  vmovaps xmm8, [rsp+0x80]
00007dd052fdcbe7  vmovaps xmm9, [rsp+0x90]
00007dd052fdcbf0  vmovaps xmm10, [rsp+0xA0]
00007dd052fdcbf9  vmovaps xmm11, [rsp+0xB0]
00007dd052fdcc02  vmovaps xmm12, [rsp+0xC0]
00007dd052fdcc0b  vmovaps xmm13, [rsp+0xD0]
00007dd052fdcc14  vmovaps xmm14, [rsp+0xE0]
00007dd052fdcc1d  add rsp, 0xF0
00007dd052fdcc24  pop r11
00007dd052fdcc26  pop r10
00007dd052fdcc28  pop r9
00007dd052fdcc2a  pop r8
00007dd052fdcc2c  pop rsi
00007dd052fdcc2d  pop rdi
00007dd052fdcc2e  pop rdx
00007dd052fdcc2f  pop rcx
00007dd052fdcc30  pop rax
00007dd052fdcc31  add rsp, 0x08
00007dd052fdcc35  jmp 0x00007DD052FD94A0
00007dd052fdcc3a  call 0x00007DD052ED64F0
00007dd052fdcc3f  jmp 0x00007DD052FD94FB
00007dd052fdcc44  sub rsp, 0x08
00007dd052fdcc48  push rax
00007dd052fdcc49  push rcx
00007dd052fdcc4a  push rdx
00007dd052fdcc4b  push rdi
00007dd052fdcc4c  push rsi
00007dd052fdcc4d  push r8
00007dd052fdcc4f  push r9
00007dd052fdcc51  push r10
00007dd052fdcc53  push r11
00007dd052fdcc55  sub rsp, 0xF0
00007dd052fdcc5c  vmovaps [rsp], xmm0
00007dd052fdcc61  vmovaps [rsp+0x10], xmm1
00007dd052fdcc67  vmovaps [rsp+0x20], xmm2
00007dd052fdcc6d  vmovaps [rsp+0x30], xmm3
00007dd052fdcc73  vmovaps [rsp+0x40], xmm4
00007dd052fdcc79  vmovaps [rsp+0x50], xmm5
00007dd052fdcc7f  vmovaps [rsp+0x60], xmm6
00007dd052fdcc85  vmovaps [rsp+0x70], xmm7
00007dd052fdcc8b  vmovaps [rsp+0x80], xmm8
00007dd052fdcc94  vmovaps [rsp+0x90], xmm10
00007dd052fdcc9d  vmovaps [rsp+0xA0], xmm11
00007dd052fdcca6  vmovaps [rsp+0xB0], xmm12
00007dd052fdccaf  vmovaps [rsp+0xC0], xmm13
00007dd052fdccb8  vmovaps [rsp+0xD0], xmm14
00007dd052fdccc1  vmovaps [rsp+0xE0], xmm15
00007dd052fdccca  sub rsp, 0x30
00007dd052fdccce  movaps [rsp], xmm9
00007dd052fdccd3  movaps [rsp+0x10], xmm8
00007dd052fdccd9  movaps [rsp+0x20], xmm11
00007dd052fdccdf  lea rdi, [rsp]
00007dd052fdcce3  mov esi, 0x00
00007dd052fdcce8  mov rax, 0x61D0404B9530
00007dd052fdccf2  call rax
00007dd052fdccf4  movaps xmm9, [rsp]
00007dd052fdccf9  add rsp, 0x30
00007dd052fdccfd  vmovaps xmm0, [rsp]
00007dd052fdcd02  vmovaps xmm1, [rsp+0x10]
00007dd052fdcd08  vmovaps xmm2, [rsp+0x20]
00007dd052fdcd0e  vmovaps xmm3, [rsp+0x30]
00007dd052fdcd14  vmovaps xmm4, [rsp+0x40]
00007dd052fdcd1a  vmovaps xmm5, [rsp+0x50]
00007dd052fdcd20  vmovaps xmm6, [rsp+0x60]
00007dd052fdcd26  vmovaps xmm7, [rsp+0x70]
00007dd052fdcd2c  vmovaps xmm8, [rsp+0x80]
00007dd052fdcd35  vmovaps xmm10, [rsp+0x90]
00007dd052fdcd3e  vmovaps xmm11, [rsp+0xA0]
00007dd052fdcd47  vmovaps xmm12, [rsp+0xB0]
00007dd052fdcd50  vmovaps xmm13, [rsp+0xC0]
00007dd052fdcd59  vmovaps xmm14, [rsp+0xD0]
00007dd052fdcd62  vmovaps xmm15, [rsp+0xE0]
00007dd052fdcd6b  add rsp, 0xF0
00007dd052fdcd72  pop r11
00007dd052fdcd74  pop r10
00007dd052fdcd76  pop r9
00007dd052fdcd78  pop r8
00007dd052fdcd7a  pop rsi
00007dd052fdcd7b  pop rdi
00007dd052fdcd7c  pop rdx
00007dd052fdcd7d  pop rcx
00007dd052fdcd7e  pop rax
00007dd052fdcd7f  add rsp, 0x08
00007dd052fdcd83  jmp 0x00007DD052FD9532
00007dd052fdcd88  sub rsp, 0x08
00007dd052fdcd8c  push rax
00007dd052fdcd8d  push rcx
00007dd052fdcd8e  push rdx
00007dd052fdcd8f  push rdi
00007dd052fdcd90  push rsi
00007dd052fdcd91  push r8
00007dd052fdcd93  push r9
00007dd052fdcd95  push r10
00007dd052fdcd97  push r11
00007dd052fdcd99  sub rsp, 0xF0
00007dd052fdcda0  vmovaps [rsp], xmm0
00007dd052fdcda5  vmovaps [rsp+0x10], xmm1
00007dd052fdcdab  vmovaps [rsp+0x20], xmm2
00007dd052fdcdb1  vmovaps [rsp+0x30], xmm3
00007dd052fdcdb7  vmovaps [rsp+0x40], xmm4
00007dd052fdcdbd  vmovaps [rsp+0x50], xmm5
00007dd052fdcdc3  vmovaps [rsp+0x60], xmm6
00007dd052fdcdc9  vmovaps [rsp+0x70], xmm7
00007dd052fdcdcf  vmovaps [rsp+0x80], xmm8
00007dd052fdcdd8  vmovaps [rsp+0x90], xmm9
00007dd052fdcde1  vmovaps [rsp+0xA0], xmm10
00007dd052fdcdea  vmovaps [rsp+0xB0], xmm12
00007dd052fdcdf3  vmovaps [rsp+0xC0], xmm13
00007dd052fdcdfc  vmovaps [rsp+0xD0], xmm14
00007dd052fdce05  vmovaps [rsp+0xE0], xmm15
00007dd052fdce0e  sub rsp, 0x30
00007dd052fdce12  movaps [rsp], xmm11
00007dd052fdce17  movaps [rsp+0x10], xmm10
00007dd052fdce1d  movaps [rsp+0x20], xmm6
00007dd052fdce22  lea rdi, [rsp]
00007dd052fdce26  mov esi, 0x00
00007dd052fdce2b  mov rax, 0x61D0404B9530
00007dd052fdce35  call rax
00007dd052fdce37  movaps xmm11, [rsp]
00007dd052fdce3c  add rsp, 0x30
00007dd052fdce40  vmovaps xmm0, [rsp]
00007dd052fdce45  vmovaps xmm1, [rsp+0x10]
00007dd052fdce4b  vmovaps xmm2, [rsp+0x20]
00007dd052fdce51  vmovaps xmm3, [rsp+0x30]
00007dd052fdce57  vmovaps xmm4, [rsp+0x40]
00007dd052fdce5d  vmovaps xmm5, [rsp+0x50]
00007dd052fdce63  vmovaps xmm6, [rsp+0x60]
00007dd052fdce69  vmovaps xmm7, [rsp+0x70]
00007dd052fdce6f  vmovaps xmm8, [rsp+0x80]
00007dd052fdce78  vmovaps xmm9, [rsp+0x90]
00007dd052fdce81  vmovaps xmm10, [rsp+0xA0]
00007dd052fdce8a  vmovaps xmm12, [rsp+0xB0]
00007dd052fdce93  vmovaps xmm13, [rsp+0xC0]
00007dd052fdce9c  vmovaps xmm14, [rsp+0xD0]
00007dd052fdcea5  vmovaps xmm15, [rsp+0xE0]
00007dd052fdceae  add rsp, 0xF0
00007dd052fdceb5  pop r11
00007dd052fdceb7  pop r10
00007dd052fdceb9  pop r9
00007dd052fdcebb  pop r8
00007dd052fdcebd  pop rsi
00007dd052fdcebe  pop rdi
00007dd052fdcebf  pop rdx
00007dd052fdcec0  pop rcx
00007dd052fdcec1  pop rax
00007dd052fdcec2  add rsp, 0x08
00007dd052fdcec6  jmp 0x00007DD052FD954D
00007dd052fdcecb  sub rsp, 0x08
00007dd052fdcecf  push rax
00007dd052fdced0  push rcx
00007dd052fdced1  push rdx
00007dd052fdced2  push rdi
00007dd052fdced3  push rsi
00007dd052fdced4  push r8
00007dd052fdced6  push r9
00007dd052fdced8  push r10
00007dd052fdceda  push r11
00007dd052fdcedc  sub rsp, 0xF0
00007dd052fdcee3  vmovaps [rsp], xmm0
00007dd052fdcee8  vmovaps [rsp+0x10], xmm1
00007dd052fdceee  vmovaps [rsp+0x20], xmm2
00007dd052fdcef4  vmovaps [rsp+0x30], xmm3
00007dd052fdcefa  vmovaps [rsp+0x40], xmm4
00007dd052fdcf00  vmovaps [rsp+0x50], xmm5
00007dd052fdcf06  vmovaps [rsp+0x60], xmm6
00007dd052fdcf0c  vmovaps [rsp+0x70], xmm7
00007dd052fdcf12  vmovaps [rsp+0x80], xmm8
00007dd052fdcf1b  vmovaps [rsp+0x90], xmm9
00007dd052fdcf24  vmovaps [rsp+0xA0], xmm11
00007dd052fdcf2d  vmovaps [rsp+0xB0], xmm12
00007dd052fdcf36  vmovaps [rsp+0xC0], xmm13
00007dd052fdcf3f  vmovaps [rsp+0xD0], xmm14
00007dd052fdcf48  vmovaps [rsp+0xE0], xmm15
00007dd052fdcf51  sub rsp, 0x30
00007dd052fdcf55  movaps [rsp], xmm10
00007dd052fdcf5a  movaps [rsp+0x10], xmm14
00007dd052fdcf60  movaps [rsp+0x20], xmm4
00007dd052fdcf65  lea rdi, [rsp]
00007dd052fdcf69  mov esi, 0x00
00007dd052fdcf6e  mov rax, 0x61D0404B9530
00007dd052fdcf78  call rax
00007dd052fdcf7a  movaps xmm10, [rsp]
00007dd052fdcf7f  add rsp, 0x30
00007dd052fdcf83  vmovaps xmm0, [rsp]
00007dd052fdcf88  vmovaps xmm1, [rsp+0x10]
00007dd052fdcf8e  vmovaps xmm2, [rsp+0x20]
00007dd052fdcf94  vmovaps xmm3, [rsp+0x30]
00007dd052fdcf9a  vmovaps xmm4, [rsp+0x40]
00007dd052fdcfa0  vmovaps xmm5, [rsp+0x50]
00007dd052fdcfa6  vmovaps xmm6, [rsp+0x60]
00007dd052fdcfac  vmovaps xmm7, [rsp+0x70]
00007dd052fdcfb2  vmovaps xmm8, [rsp+0x80]
00007dd052fdcfbb  vmovaps xmm9, [rsp+0x90]
00007dd052fdcfc4  vmovaps xmm11, [rsp+0xA0]
00007dd052fdcfcd  vmovaps xmm12, [rsp+0xB0]
00007dd052fdcfd6  vmovaps xmm13, [rsp+0xC0]
00007dd052fdcfdf  vmovaps xmm14, [rsp+0xD0]
00007dd052fdcfe8  vmovaps xmm15, [rsp+0xE0]
00007dd052fdcff1  add rsp, 0xF0
00007dd052fdcff8  pop r11
00007dd052fdcffa  pop r10
00007dd052fdcffc  pop r9
00007dd052fdcffe  pop r8
00007dd052fdd000  pop rsi
00007dd052fdd001  pop rdi
00007dd052fdd002  pop rdx
00007dd052fdd003  pop rcx
00007dd052fdd004  pop rax
00007dd052fdd005  add rsp, 0x08
00007dd052fdd009  jmp 0x00007DD052FD9568
00007dd052fdd00e  sub rsp, 0x08
00007dd052fdd012  push rax
00007dd052fdd013  push rcx
00007dd052fdd014  push rdx
00007dd052fdd015  push rdi
00007dd052fdd016  push rsi
00007dd052fdd017  push r8
00007dd052fdd019  push r9
00007dd052fdd01b  push r10
00007dd052fdd01d  push r11
00007dd052fdd01f  sub rsp, 0xF0
00007dd052fdd026  vmovaps [rsp], xmm0
00007dd052fdd02b  vmovaps [rsp+0x10], xmm1
00007dd052fdd031  vmovaps [rsp+0x20], xmm2
00007dd052fdd037  vmovaps [rsp+0x30], xmm3
00007dd052fdd03d  vmovaps [rsp+0x40], xmm4
00007dd052fdd043  vmovaps [rsp+0x50], xmm5
00007dd052fdd049  vmovaps [rsp+0x60], xmm6
00007dd052fdd04f  vmovaps [rsp+0x70], xmm7
00007dd052fdd055  vmovaps [rsp+0x80], xmm9
00007dd052fdd05e  vmovaps [rsp+0x90], xmm10
00007dd052fdd067  vmovaps [rsp+0xA0], xmm11
00007dd052fdd070  vmovaps [rsp+0xB0], xmm12
00007dd052fdd079  vmovaps [rsp+0xC0], xmm13
00007dd052fdd082  vmovaps [rsp+0xD0], xmm14
00007dd052fdd08b  vmovaps [rsp+0xE0], xmm15
00007dd052fdd094  sub rsp, 0x30
00007dd052fdd098  movaps [rsp], xmm8
00007dd052fdd09d  movaps [rsp+0x10], xmm1
00007dd052fdd0a2  movaps [rsp+0x20], xmm14
00007dd052fdd0a8  lea rdi, [rsp]
00007dd052fdd0ac  mov esi, 0x00
00007dd052fdd0b1  mov rax, 0x61D0404B9530
00007dd052fdd0bb  call rax
00007dd052fdd0bd  movaps xmm8, [rsp]
00007dd052fdd0c2  add rsp, 0x30
00007dd052fdd0c6  vmovaps xmm0, [rsp]
00007dd052fdd0cb  vmovaps xmm1, [rsp+0x10]
00007dd052fdd0d1  vmovaps xmm2, [rsp+0x20]
00007dd052fdd0d7  vmovaps xmm3, [rsp+0x30]
00007dd052fdd0dd  vmovaps xmm4, [rsp+0x40]
00007dd052fdd0e3  vmovaps xmm5, [rsp+0x50]
00007dd052fdd0e9  vmovaps xmm6, [rsp+0x60]
00007dd052fdd0ef  vmovaps xmm7, [rsp+0x70]
00007dd052fdd0f5  vmovaps xmm9, [rsp+0x80]
00007dd052fdd0fe  vmovaps xmm10, [rsp+0x90]
00007dd052fdd107  vmovaps xmm11, [rsp+0xA0]
00007dd052fdd110  vmovaps xmm12, [rsp+0xB0]
00007dd052fdd119  vmovaps xmm13, [rsp+0xC0]
00007dd052fdd122  vmovaps xmm14, [rsp+0xD0]
00007dd052fdd12b  vmovaps xmm15, [rsp+0xE0]
00007dd052fdd134  add rsp, 0xF0
00007dd052fdd13b  pop r11
00007dd052fdd13d  pop r10
00007dd052fdd13f  pop r9
00007dd052fdd141  pop r8
00007dd052fdd143  pop rsi
00007dd052fdd144  pop rdi
00007dd052fdd145  pop rdx
00007dd052fdd146  pop rcx
00007dd052fdd147  pop rax
00007dd052fdd148  add rsp, 0x08
00007dd052fdd14c  jmp 0x00007DD052FD958E
00007dd052fdd151  sub rsp, 0x08
00007dd052fdd155  push rax
00007dd052fdd156  push rcx
00007dd052fdd157  push rdx
00007dd052fdd158  push rdi
00007dd052fdd159  push rsi
00007dd052fdd15a  push r8
00007dd052fdd15c  push r9
00007dd052fdd15e  push r10
00007dd052fdd160  push r11
00007dd052fdd162  sub rsp, 0xF0
00007dd052fdd169  vmovaps [rsp], xmm0
00007dd052fdd16e  vmovaps [rsp+0x10], xmm1
00007dd052fdd174  vmovaps [rsp+0x20], xmm2
00007dd052fdd17a  vmovaps [rsp+0x30], xmm3
00007dd052fdd180  vmovaps [rsp+0x40], xmm4
00007dd052fdd186  vmovaps [rsp+0x50], xmm5
00007dd052fdd18c  vmovaps [rsp+0x60], xmm7
00007dd052fdd192  vmovaps [rsp+0x70], xmm8
00007dd052fdd198  vmovaps [rsp+0x80], xmm9
00007dd052fdd1a1  vmovaps [rsp+0x90], xmm10
00007dd052fdd1aa  vmovaps [rsp+0xA0], xmm11
00007dd052fdd1b3  vmovaps [rsp+0xB0], xmm12
00007dd052fdd1bc  vmovaps [rsp+0xC0], xmm13
00007dd052fdd1c5  vmovaps [rsp+0xD0], xmm14
00007dd052fdd1ce  vmovaps [rsp+0xE0], xmm15
00007dd052fdd1d7  sub rsp, 0x30
00007dd052fdd1db  movaps [rsp], xmm6
00007dd052fdd1df  movaps [rsp+0x10], xmm1
00007dd052fdd1e4  movaps [rsp+0x20], xmm14
00007dd052fdd1ea  lea rdi, [rsp]
00007dd052fdd1ee  mov esi, 0x00
00007dd052fdd1f3  mov rax, 0x61D0404B9530
00007dd052fdd1fd  call rax
00007dd052fdd1ff  movaps xmm6, [rsp]
00007dd052fdd203  add rsp, 0x30
00007dd052fdd207  vmovaps xmm0, [rsp]
00007dd052fdd20c  vmovaps xmm1, [rsp+0x10]
00007dd052fdd212  vmovaps xmm2, [rsp+0x20]
00007dd052fdd218  vmovaps xmm3, [rsp+0x30]
00007dd052fdd21e  vmovaps xmm4, [rsp+0x40]
00007dd052fdd224  vmovaps xmm5, [rsp+0x50]
00007dd052fdd22a  vmovaps xmm7, [rsp+0x60]
00007dd052fdd230  vmovaps xmm8, [rsp+0x70]
00007dd052fdd236  vmovaps xmm9, [rsp+0x80]
00007dd052fdd23f  vmovaps xmm10, [rsp+0x90]
00007dd052fdd248  vmovaps xmm11, [rsp+0xA0]
00007dd052fdd251  vmovaps xmm12, [rsp+0xB0]
00007dd052fdd25a  vmovaps xmm13, [rsp+0xC0]
00007dd052fdd263  vmovaps xmm14, [rsp+0xD0]
00007dd052fdd26c  vmovaps xmm15, [rsp+0xE0]
00007dd052fdd275  add rsp, 0xF0
00007dd052fdd27c  pop r11
00007dd052fdd27e  pop r10
00007dd052fdd280  pop r9
00007dd052fdd282  pop r8
00007dd052fdd284  pop rsi
00007dd052fdd285  pop rdi
00007dd052fdd286  pop rdx
00007dd052fdd287  pop rcx
00007dd052fdd288  pop rax
00007dd052fdd289  add rsp, 0x08
00007dd052fdd28d  jmp 0x00007DD052FD95BA
00007dd052fdd292  sub rsp, 0x08
00007dd052fdd296  push rax
00007dd052fdd297  push rcx
00007dd052fdd298  push rdx
00007dd052fdd299  push rdi
00007dd052fdd29a  push rsi
00007dd052fdd29b  push r8
00007dd052fdd29d  push r9
00007dd052fdd29f  push r10
00007dd052fdd2a1  push r11
00007dd052fdd2a3  sub rsp, 0xF0
00007dd052fdd2aa  vmovaps [rsp], xmm0
00007dd052fdd2af  vmovaps [rsp+0x10], xmm1
00007dd052fdd2b5  vmovaps [rsp+0x20], xmm2
00007dd052fdd2bb  vmovaps [rsp+0x30], xmm3
00007dd052fdd2c1  vmovaps [rsp+0x40], xmm4
00007dd052fdd2c7  vmovaps [rsp+0x50], xmm5
00007dd052fdd2cd  vmovaps [rsp+0x60], xmm6
00007dd052fdd2d3  vmovaps [rsp+0x70], xmm7
00007dd052fdd2d9  vmovaps [rsp+0x80], xmm8
00007dd052fdd2e2  vmovaps [rsp+0x90], xmm9
00007dd052fdd2eb  vmovaps [rsp+0xA0], xmm10
00007dd052fdd2f4  vmovaps [rsp+0xB0], xmm11
00007dd052fdd2fd  vmovaps [rsp+0xC0], xmm12
00007dd052fdd306  vmovaps [rsp+0xD0], xmm13
00007dd052fdd30f  vmovaps [rsp+0xE0], xmm15
00007dd052fdd318  sub rsp, 0x30
00007dd052fdd31c  movaps [rsp], xmm14
00007dd052fdd321  movaps [rsp+0x10], xmm12
00007dd052fdd327  movaps [rsp+0x20], xmm1
00007dd052fdd32c  lea rdi, [rsp]
00007dd052fdd330  mov esi, 0x00
00007dd052fdd335  mov rax, 0x61D0404B9530
00007dd052fdd33f  call rax
00007dd052fdd341  movaps xmm14, [rsp]
00007dd052fdd346  add rsp, 0x30
00007dd052fdd34a  vmovaps xmm0, [rsp]
00007dd052fdd34f  vmovaps xmm1, [rsp+0x10]
00007dd052fdd355  vmovaps xmm2, [rsp+0x20]
00007dd052fdd35b  vmovaps xmm3, [rsp+0x30]
00007dd052fdd361  vmovaps xmm4, [rsp+0x40]
00007dd052fdd367  vmovaps xmm5, [rsp+0x50]
00007dd052fdd36d  vmovaps xmm6, [rsp+0x60]
00007dd052fdd373  vmovaps xmm7, [rsp+0x70]
00007dd052fdd379  vmovaps xmm8, [rsp+0x80]
00007dd052fdd382  vmovaps xmm9, [rsp+0x90]
00007dd052fdd38b  vmovaps xmm10, [rsp+0xA0]
00007dd052fdd394  vmovaps xmm11, [rsp+0xB0]
00007dd052fdd39d  vmovaps xmm12, [rsp+0xC0]
00007dd052fdd3a6  vmovaps xmm13, [rsp+0xD0]
00007dd052fdd3af  vmovaps xmm15, [rsp+0xE0]
00007dd052fdd3b8  add rsp, 0xF0
00007dd052fdd3bf  pop r11
00007dd052fdd3c1  pop r10
00007dd052fdd3c3  pop r9
00007dd052fdd3c5  pop r8
00007dd052fdd3c7  pop rsi
00007dd052fdd3c8  pop rdi
00007dd052fdd3c9  pop rdx
00007dd052fdd3ca  pop rcx
00007dd052fdd3cb  pop rax
00007dd052fdd3cc  add rsp, 0x08
00007dd052fdd3d0  jmp 0x00007DD052FD95E0
00007dd052fdd3d5  sub rsp, 0x08
00007dd052fdd3d9  push rax
00007dd052fdd3da  push rcx
00007dd052fdd3db  push rdx
00007dd052fdd3dc  push rdi
00007dd052fdd3dd  push rsi
00007dd052fdd3de  push r8
00007dd052fdd3e0  push r9
00007dd052fdd3e2  push r10
00007dd052fdd3e4  push r11
00007dd052fdd3e6  sub rsp, 0xF0
00007dd052fdd3ed  vmovaps [rsp], xmm0
00007dd052fdd3f2  vmovaps [rsp+0x10], xmm2
00007dd052fdd3f8  vmovaps [rsp+0x20], xmm3
00007dd052fdd3fe  vmovaps [rsp+0x30], xmm4
00007dd052fdd404  vmovaps [rsp+0x40], xmm5
00007dd052fdd40a  vmovaps [rsp+0x50], xmm6
00007dd052fdd410  vmovaps [rsp+0x60], xmm7
00007dd052fdd416  vmovaps [rsp+0x70], xmm8
00007dd052fdd41c  vmovaps [rsp+0x80], xmm9
00007dd052fdd425  vmovaps [rsp+0x90], xmm10
00007dd052fdd42e  vmovaps [rsp+0xA0], xmm11
00007dd052fdd437  vmovaps [rsp+0xB0], xmm12
00007dd052fdd440  vmovaps [rsp+0xC0], xmm13
00007dd052fdd449  vmovaps [rsp+0xD0], xmm14
00007dd052fdd452  vmovaps [rsp+0xE0], xmm15
00007dd052fdd45b  sub rsp, 0x30
00007dd052fdd45f  movaps [rsp], xmm1
00007dd052fdd463  movaps [rsp+0x10], xmm13
00007dd052fdd469  movaps [rsp+0x20], xmm9
00007dd052fdd46f  lea rdi, [rsp]
00007dd052fdd473  mov esi, 0x00
00007dd052fdd478  mov rax, 0x61D0404B9530
00007dd052fdd482  call rax
00007dd052fdd484  movaps xmm1, [rsp]
00007dd052fdd488  add rsp, 0x30
00007dd052fdd48c  vmovaps xmm0, [rsp]
00007dd052fdd491  vmovaps xmm2, [rsp+0x10]
00007dd052fdd497  vmovaps xmm3, [rsp+0x20]
00007dd052fdd49d  vmovaps xmm4, [rsp+0x30]
00007dd052fdd4a3  vmovaps xmm5, [rsp+0x40]
00007dd052fdd4a9  vmovaps xmm6, [rsp+0x50]
00007dd052fdd4af  vmovaps xmm7, [rsp+0x60]
00007dd052fdd4b5  vmovaps xmm8, [rsp+0x70]
00007dd052fdd4bb  vmovaps xmm9, [rsp+0x80]
00007dd052fdd4c4  vmovaps xmm10, [rsp+0x90]
00007dd052fdd4cd  vmovaps xmm11, [rsp+0xA0]
00007dd052fdd4d6  vmovaps xmm12, [rsp+0xB0]
00007dd052fdd4df  vmovaps xmm13, [rsp+0xC0]
00007dd052fdd4e8  vmovaps xmm14, [rsp+0xD0]
00007dd052fdd4f1  vmovaps xmm15, [rsp+0xE0]
00007dd052fdd4fa  add rsp, 0xF0
00007dd052fdd501  pop r11
00007dd052fdd503  pop r10
00007dd052fdd505  pop r9
00007dd052fdd507  pop r8
00007dd052fdd509  pop rsi
00007dd052fdd50a  pop rdi
00007dd052fdd50b  pop rdx
00007dd052fdd50c  pop rcx
00007dd052fdd50d  pop rax
00007dd052fdd50e  add rsp, 0x08
00007dd052fdd512  jmp 0x00007DD052FD95FA
00007dd052fdd517  sub rsp, 0x08
00007dd052fdd51b  push rax
00007dd052fdd51c  push rcx
00007dd052fdd51d  push rdx
00007dd052fdd51e  push rdi
00007dd052fdd51f  push rsi
00007dd052fdd520  push r8
00007dd052fdd522  push r9
00007dd052fdd524  push r10
00007dd052fdd526  push r11
00007dd052fdd528  sub rsp, 0xF0
00007dd052fdd52f  vmovaps [rsp], xmm0
00007dd052fdd534  vmovaps [rsp+0x10], xmm1
00007dd052fdd53a  vmovaps [rsp+0x20], xmm2
00007dd052fdd540  vmovaps [rsp+0x30], xmm3
00007dd052fdd546  vmovaps [rsp+0x40], xmm4
00007dd052fdd54c  vmovaps [rsp+0x50], xmm5
00007dd052fdd552  vmovaps [rsp+0x60], xmm6
00007dd052fdd558  vmovaps [rsp+0x70], xmm7
00007dd052fdd55e  vmovaps [rsp+0x80], xmm8
00007dd052fdd567  vmovaps [rsp+0x90], xmm9
00007dd052fdd570  vmovaps [rsp+0xA0], xmm10
00007dd052fdd579  vmovaps [rsp+0xB0], xmm11
00007dd052fdd582  vmovaps [rsp+0xC0], xmm13
00007dd052fdd58b  vmovaps [rsp+0xD0], xmm14
00007dd052fdd594  vmovaps [rsp+0xE0], xmm15
00007dd052fdd59d  sub rsp, 0x30
00007dd052fdd5a1  movaps [rsp], xmm12
00007dd052fdd5a6  movaps [rsp+0x10], xmm7
00007dd052fdd5ab  movaps [rsp+0x20], xmm13
00007dd052fdd5b1  lea rdi, [rsp]
00007dd052fdd5b5  mov esi, 0x00
00007dd052fdd5ba  mov rax, 0x61D0404B9530
00007dd052fdd5c4  call rax
00007dd052fdd5c6  movaps xmm12, [rsp]
00007dd052fdd5cb  add rsp, 0x30
00007dd052fdd5cf  vmovaps xmm0, [rsp]
00007dd052fdd5d4  vmovaps xmm1, [rsp+0x10]
00007dd052fdd5da  vmovaps xmm2, [rsp+0x20]
00007dd052fdd5e0  vmovaps xmm3, [rsp+0x30]
00007dd052fdd5e6  vmovaps xmm4, [rsp+0x40]
00007dd052fdd5ec  vmovaps xmm5, [rsp+0x50]
00007dd052fdd5f2  vmovaps xmm6, [rsp+0x60]
00007dd052fdd5f8  vmovaps xmm7, [rsp+0x70]
00007dd052fdd5fe  vmovaps xmm8, [rsp+0x80]
00007dd052fdd607  vmovaps xmm9, [rsp+0x90]
00007dd052fdd610  vmovaps xmm10, [rsp+0xA0]
00007dd052fdd619  vmovaps xmm11, [rsp+0xB0]
00007dd052fdd622  vmovaps xmm13, [rsp+0xC0]
00007dd052fdd62b  vmovaps xmm14, [rsp+0xD0]
00007dd052fdd634  vmovaps xmm15, [rsp+0xE0]
00007dd052fdd63d  add rsp, 0xF0
00007dd052fdd644  pop r11
00007dd052fdd646  pop r10
00007dd052fdd648  pop r9
00007dd052fdd64a  pop r8
00007dd052fdd64c  pop rsi
00007dd052fdd64d  pop rdi
00007dd052fdd64e  pop rdx
00007dd052fdd64f  pop rcx
00007dd052fdd650  pop rax
00007dd052fdd651  add rsp, 0x08
00007dd052fdd655  jmp 0x00007DD052FD9621
00007dd052fdd65a  sub rsp, 0x08
00007dd052fdd65e  push rax
00007dd052fdd65f  push rcx
00007dd052fdd660  push rdx
00007dd052fdd661  push rdi
00007dd052fdd662  push rsi
00007dd052fdd663  push r8
00007dd052fdd665  push r9
00007dd052fdd667  push r10
00007dd052fdd669  push r11
00007dd052fdd66b  sub rsp, 0xF0
00007dd052fdd672  vmovaps [rsp], xmm0
00007dd052fdd677  vmovaps [rsp+0x10], xmm1
00007dd052fdd67d  vmovaps [rsp+0x20], xmm2
00007dd052fdd683  vmovaps [rsp+0x30], xmm3
00007dd052fdd689  vmovaps [rsp+0x40], xmm4
00007dd052fdd68f  vmovaps [rsp+0x50], xmm5
00007dd052fdd695  vmovaps [rsp+0x60], xmm6
00007dd052fdd69b  vmovaps [rsp+0x70], xmm7
00007dd052fdd6a1  vmovaps [rsp+0x80], xmm8
00007dd052fdd6aa  vmovaps [rsp+0x90], xmm9
00007dd052fdd6b3  vmovaps [rsp+0xA0], xmm10
00007dd052fdd6bc  vmovaps [rsp+0xB0], xmm11
00007dd052fdd6c5  vmovaps [rsp+0xC0], xmm12
00007dd052fdd6ce  vmovaps [rsp+0xD0], xmm14
00007dd052fdd6d7  vmovaps [rsp+0xE0], xmm15
00007dd052fdd6e0  sub rsp, 0x30
00007dd052fdd6e4  movaps [rsp], xmm13
00007dd052fdd6e9  movaps [rsp+0x10], xmm15
00007dd052fdd6ef  movaps [rsp+0x20], xmm8
00007dd052fdd6f5  lea rdi, [rsp]
00007dd052fdd6f9  mov esi, 0x00
00007dd052fdd6fe  mov rax, 0x61D0404B9530
00007dd052fdd708  call rax
00007dd052fdd70a  movaps xmm13, [rsp]
00007dd052fdd70f  add rsp, 0x30
00007dd052fdd713  vmovaps xmm0, [rsp]
00007dd052fdd718  vmovaps xmm1, [rsp+0x10]
00007dd052fdd71e  vmovaps xmm2, [rsp+0x20]
00007dd052fdd724  vmovaps xmm3, [rsp+0x30]
00007dd052fdd72a  vmovaps xmm4, [rsp+0x40]
00007dd052fdd730  vmovaps xmm5, [rsp+0x50]
00007dd052fdd736  vmovaps xmm6, [rsp+0x60]
00007dd052fdd73c  vmovaps xmm7, [rsp+0x70]
00007dd052fdd742  vmovaps xmm8, [rsp+0x80]
00007dd052fdd74b  vmovaps xmm9, [rsp+0x90]
00007dd052fdd754  vmovaps xmm10, [rsp+0xA0]
00007dd052fdd75d  vmovaps xmm11, [rsp+0xB0]
00007dd052fdd766  vmovaps xmm12, [rsp+0xC0]
00007dd052fdd76f  vmovaps xmm14, [rsp+0xD0]
00007dd052fdd778  vmovaps xmm15, [rsp+0xE0]
00007dd052fdd781  add rsp, 0xF0
00007dd052fdd788  pop r11
00007dd052fdd78a  pop r10
00007dd052fdd78c  pop r9
00007dd052fdd78e  pop r8
00007dd052fdd790  pop rsi
00007dd052fdd791  pop rdi
00007dd052fdd792  pop rdx
00007dd052fdd793  pop rcx
00007dd052fdd794  pop rax
00007dd052fdd795  add rsp, 0x08
00007dd052fdd799  jmp 0x00007DD052FD963C
00007dd052fdd79e  sub rsp, 0x08
00007dd052fdd7a2  push rax
00007dd052fdd7a3  push rcx
00007dd052fdd7a4  push rdx
00007dd052fdd7a5  push rdi
00007dd052fdd7a6  push rsi
00007dd052fdd7a7  push r8
00007dd052fdd7a9  push r9
00007dd052fdd7ab  push r10
00007dd052fdd7ad  push r11
00007dd052fdd7af  sub rsp, 0xF0
00007dd052fdd7b6  vmovaps [rsp], xmm0
00007dd052fdd7bb  vmovaps [rsp+0x10], xmm1
00007dd052fdd7c1  vmovaps [rsp+0x20], xmm2
00007dd052fdd7c7  vmovaps [rsp+0x30], xmm3
00007dd052fdd7cd  vmovaps [rsp+0x40], xmm4
00007dd052fdd7d3  vmovaps [rsp+0x50], xmm5
00007dd052fdd7d9  vmovaps [rsp+0x60], xmm6
00007dd052fdd7df  vmovaps [rsp+0x70], xmm7
00007dd052fdd7e5  vmovaps [rsp+0x80], xmm9
00007dd052fdd7ee  vmovaps [rsp+0x90], xmm10
00007dd052fdd7f7  vmovaps [rsp+0xA0], xmm11
00007dd052fdd800  vmovaps [rsp+0xB0], xmm12
00007dd052fdd809  vmovaps [rsp+0xC0], xmm13
00007dd052fdd812  vmovaps [rsp+0xD0], xmm14
00007dd052fdd81b  vmovaps [rsp+0xE0], xmm15
00007dd052fdd824  sub rsp, 0x30
00007dd052fdd828  movaps [rsp], xmm8
00007dd052fdd82d  movaps [rsp+0x10], xmm15
00007dd052fdd833  movaps [rsp+0x20], xmm9
00007dd052fdd839  lea rdi, [rsp]
00007dd052fdd83d  mov esi, 0x00
00007dd052fdd842  mov rax, 0x61D0404B9530
00007dd052fdd84c  call rax
00007dd052fdd84e  movaps xmm8, [rsp]
00007dd052fdd853  add rsp, 0x30
00007dd052fdd857  vmovaps xmm0, [rsp]
00007dd052fdd85c  vmovaps xmm1, [rsp+0x10]
00007dd052fdd862  vmovaps xmm2, [rsp+0x20]
00007dd052fdd868  vmovaps xmm3, [rsp+0x30]
00007dd052fdd86e  vmovaps xmm4, [rsp+0x40]
00007dd052fdd874  vmovaps xmm5, [rsp+0x50]
00007dd052fdd87a  vmovaps xmm6, [rsp+0x60]
00007dd052fdd880  vmovaps xmm7, [rsp+0x70]
00007dd052fdd886  vmovaps xmm9, [rsp+0x80]
00007dd052fdd88f  vmovaps xmm10, [rsp+0x90]
00007dd052fdd898  vmovaps xmm11, [rsp+0xA0]
00007dd052fdd8a1  vmovaps xmm12, [rsp+0xB0]
00007dd052fdd8aa  vmovaps xmm13, [rsp+0xC0]
00007dd052fdd8b3  vmovaps xmm14, [rsp+0xD0]
00007dd052fdd8bc  vmovaps xmm15, [rsp+0xE0]
00007dd052fdd8c5  add rsp, 0xF0
00007dd052fdd8cc  pop r11
00007dd052fdd8ce  pop r10
00007dd052fdd8d0  pop r9
00007dd052fdd8d2  pop r8
00007dd052fdd8d4  pop rsi
00007dd052fdd8d5  pop rdi
00007dd052fdd8d6  pop rdx
00007dd052fdd8d7  pop rcx
00007dd052fdd8d8  pop rax
00007dd052fdd8d9  add rsp, 0x08
00007dd052fdd8dd  jmp 0x00007DD052FD966A
00007dd052fdd8e2  sub rsp, 0x08
00007dd052fdd8e6  push rax
00007dd052fdd8e7  push rcx
00007dd052fdd8e8  push rdx
00007dd052fdd8e9  push rdi
00007dd052fdd8ea  push rsi
00007dd052fdd8eb  push r8
00007dd052fdd8ed  push r9
00007dd052fdd8ef  push r10
00007dd052fdd8f1  push r11
00007dd052fdd8f3  sub rsp, 0xF0
00007dd052fdd8fa  vmovaps [rsp], xmm0
00007dd052fdd8ff  vmovaps [rsp+0x10], xmm1
00007dd052fdd905  vmovaps [rsp+0x20], xmm2
00007dd052fdd90b  vmovaps [rsp+0x30], xmm3
00007dd052fdd911  vmovaps [rsp+0x40], xmm4
00007dd052fdd917  vmovaps [rsp+0x50], xmm5
00007dd052fdd91d  vmovaps [rsp+0x60], xmm6
00007dd052fdd923  vmovaps [rsp+0x70], xmm7
00007dd052fdd929  vmovaps [rsp+0x80], xmm8
00007dd052fdd932  vmovaps [rsp+0x90], xmm9
00007dd052fdd93b  vmovaps [rsp+0xA0], xmm10
00007dd052fdd944  vmovaps [rsp+0xB0], xmm11
00007dd052fdd94d  vmovaps [rsp+0xC0], xmm12
00007dd052fdd956  vmovaps [rsp+0xD0], xmm13
00007dd052fdd95f  vmovaps [rsp+0xE0], xmm14
00007dd052fdd968  sub rsp, 0x30
00007dd052fdd96c  movaps [rsp], xmm15
00007dd052fdd971  movaps [rsp+0x10], xmm11
00007dd052fdd977  movaps [rsp+0x20], xmm6
00007dd052fdd97c  lea rdi, [rsp]
00007dd052fdd980  mov esi, 0x00
00007dd052fdd985  mov rax, 0x61D0404B9530
00007dd052fdd98f  call rax
00007dd052fdd991  movaps xmm15, [rsp]
00007dd052fdd996  add rsp, 0x30
00007dd052fdd99a  vmovaps xmm0, [rsp]
00007dd052fdd99f  vmovaps xmm1, [rsp+0x10]
00007dd052fdd9a5  vmovaps xmm2, [rsp+0x20]
00007dd052fdd9ab  vmovaps xmm3, [rsp+0x30]
00007dd052fdd9b1  vmovaps xmm4, [rsp+0x40]
00007dd052fdd9b7  vmovaps xmm5, [rsp+0x50]
00007dd052fdd9bd  vmovaps xmm6, [rsp+0x60]
00007dd052fdd9c3  vmovaps xmm7, [rsp+0x70]
00007dd052fdd9c9  vmovaps xmm8, [rsp+0x80]
00007dd052fdd9d2  vmovaps xmm9, [rsp+0x90]
00007dd052fdd9db  vmovaps xmm10, [rsp+0xA0]
00007dd052fdd9e4  vmovaps xmm11, [rsp+0xB0]
00007dd052fdd9ed  vmovaps xmm12, [rsp+0xC0]
00007dd052fdd9f6  vmovaps xmm13, [rsp+0xD0]
00007dd052fdd9ff  vmovaps xmm14, [rsp+0xE0]
00007dd052fdda08  add rsp, 0xF0
00007dd052fdda0f  pop r11
00007dd052fdda11  pop r10
00007dd052fdda13  pop r9
00007dd052fdda15  pop r8
00007dd052fdda17  pop rsi
00007dd052fdda18  pop rdi
00007dd052fdda19  pop rdx
00007dd052fdda1a  pop rcx
00007dd052fdda1b  pop rax
00007dd052fdda1c  add rsp, 0x08
00007dd052fdda20  jmp 0x00007DD052FD9685
00007dd052fdda25  sub rsp, 0x08
00007dd052fdda29  push rax
00007dd052fdda2a  push rcx
00007dd052fdda2b  push rdx
00007dd052fdda2c  push rdi
00007dd052fdda2d  push rsi
00007dd052fdda2e  push r8
00007dd052fdda30  push r9
00007dd052fdda32  push r10
00007dd052fdda34  push r11
00007dd052fdda36  sub rsp, 0xF0
00007dd052fdda3d  vmovaps [rsp], xmm0
00007dd052fdda42  vmovaps [rsp+0x10], xmm1
00007dd052fdda48  vmovaps [rsp+0x20], xmm2
00007dd052fdda4e  vmovaps [rsp+0x30], xmm3
00007dd052fdda54  vmovaps [rsp+0x40], xmm4
00007dd052fdda5a  vmovaps [rsp+0x50], xmm5
00007dd052fdda60  vmovaps [rsp+0x60], xmm6
00007dd052fdda66  vmovaps [rsp+0x70], xmm8
00007dd052fdda6c  vmovaps [rsp+0x80], xmm9
00007dd052fdda75  vmovaps [rsp+0x90], xmm10
00007dd052fdda7e  vmovaps [rsp+0xA0], xmm11
00007dd052fdda87  vmovaps [rsp+0xB0], xmm12
00007dd052fdda90  vmovaps [rsp+0xC0], xmm13
00007dd052fdda99  vmovaps [rsp+0xD0], xmm14
00007dd052fddaa2  vmovaps [rsp+0xE0], xmm15
00007dd052fddaab  sub rsp, 0x30
00007dd052fddaaf  movaps [rsp], xmm7
00007dd052fddab3  movaps [rsp+0x10], xmm11
00007dd052fddab9  movaps [rsp+0x20], xmm9
00007dd052fddabf  lea rdi, [rsp]
00007dd052fddac3  mov esi, 0x00
00007dd052fddac8  mov rax, 0x61D0404B9530
00007dd052fddad2  call rax
00007dd052fddad4  movaps xmm7, [rsp]
00007dd052fddad8  add rsp, 0x30
00007dd052fddadc  vmovaps xmm0, [rsp]
00007dd052fddae1  vmovaps xmm1, [rsp+0x10]
00007dd052fddae7  vmovaps xmm2, [rsp+0x20]
00007dd052fddaed  vmovaps xmm3, [rsp+0x30]
00007dd052fddaf3  vmovaps xmm4, [rsp+0x40]
00007dd052fddaf9  vmovaps xmm5, [rsp+0x50]
00007dd052fddaff  vmovaps xmm6, [rsp+0x60]
00007dd052fddb05  vmovaps xmm8, [rsp+0x70]
00007dd052fddb0b  vmovaps xmm9, [rsp+0x80]
00007dd052fddb14  vmovaps xmm10, [rsp+0x90]
00007dd052fddb1d  vmovaps xmm11, [rsp+0xA0]
00007dd052fddb26  vmovaps xmm12, [rsp+0xB0]
00007dd052fddb2f  vmovaps xmm13, [rsp+0xC0]
00007dd052fddb38  vmovaps xmm14, [rsp+0xD0]
00007dd052fddb41  vmovaps xmm15, [rsp+0xE0]
00007dd052fddb4a  add rsp, 0xF0
00007dd052fddb51  pop r11
00007dd052fddb53  pop r10
00007dd052fddb55  pop r9
00007dd052fddb57  pop r8
00007dd052fddb59  pop rsi
00007dd052fddb5a  pop rdi
00007dd052fddb5b  pop rdx
00007dd052fddb5c  pop rcx
00007dd052fddb5d  pop rax
00007dd052fddb5e  add rsp, 0x08
00007dd052fddb62  jmp 0x00007DD052FD96B2
00007dd052fddb67  sub rsp, 0x08
00007dd052fddb6b  push rax
00007dd052fddb6c  push rcx
00007dd052fddb6d  push rdx
00007dd052fddb6e  push rdi
00007dd052fddb6f  push rsi
00007dd052fddb70  push r8
00007dd052fddb72  push r9
00007dd052fddb74  push r10
00007dd052fddb76  push r11
00007dd052fddb78  sub rsp, 0xF0
00007dd052fddb7f  vmovaps [rsp], xmm0
00007dd052fddb84  vmovaps [rsp+0x10], xmm1
00007dd052fddb8a  vmovaps [rsp+0x20], xmm2
00007dd052fddb90  vmovaps [rsp+0x30], xmm3
00007dd052fddb96  vmovaps [rsp+0x40], xmm4
00007dd052fddb9c  vmovaps [rsp+0x50], xmm5
00007dd052fddba2  vmovaps [rsp+0x60], xmm6
00007dd052fddba8  vmovaps [rsp+0x70], xmm7
00007dd052fddbae  vmovaps [rsp+0x80], xmm8
00007dd052fddbb7  vmovaps [rsp+0x90], xmm9
00007dd052fddbc0  vmovaps [rsp+0xA0], xmm10
00007dd052fddbc9  vmovaps [rsp+0xB0], xmm12
00007dd052fddbd2  vmovaps [rsp+0xC0], xmm13
00007dd052fddbdb  vmovaps [rsp+0xD0], xmm14
00007dd052fddbe4  vmovaps [rsp+0xE0], xmm15
00007dd052fddbed  sub rsp, 0x30
00007dd052fddbf1  movaps [rsp], xmm11
00007dd052fddbf6  movaps [rsp+0x10], xmm10
00007dd052fddbfc  movaps [rsp+0x20], xmm14
00007dd052fddc02  lea rdi, [rsp]
00007dd052fddc06  mov esi, 0x00
00007dd052fddc0b  mov rax, 0x61D0404B9530
00007dd052fddc15  call rax
00007dd052fddc17  movaps xmm11, [rsp]
00007dd052fddc1c  add rsp, 0x30
00007dd052fddc20  vmovaps xmm0, [rsp]
00007dd052fddc25  vmovaps xmm1, [rsp+0x10]
00007dd052fddc2b  vmovaps xmm2, [rsp+0x20]
00007dd052fddc31  vmovaps xmm3, [rsp+0x30]
00007dd052fddc37  vmovaps xmm4, [rsp+0x40]
00007dd052fddc3d  vmovaps xmm5, [rsp+0x50]
00007dd052fddc43  vmovaps xmm6, [rsp+0x60]
00007dd052fddc49  vmovaps xmm7, [rsp+0x70]
00007dd052fddc4f  vmovaps xmm8, [rsp+0x80]
00007dd052fddc58  vmovaps xmm9, [rsp+0x90]
00007dd052fddc61  vmovaps xmm10, [rsp+0xA0]
00007dd052fddc6a  vmovaps xmm12, [rsp+0xB0]
00007dd052fddc73  vmovaps xmm13, [rsp+0xC0]
00007dd052fddc7c  vmovaps xmm14, [rsp+0xD0]
00007dd052fddc85  vmovaps xmm15, [rsp+0xE0]
00007dd052fddc8e  add rsp, 0xF0
00007dd052fddc95  pop r11
00007dd052fddc97  pop r10
00007dd052fddc99  pop r9
00007dd052fddc9b  pop r8
00007dd052fddc9d  pop rsi
00007dd052fddc9e  pop rdi
00007dd052fddc9f  pop rdx
00007dd052fddca0  pop rcx
00007dd052fddca1  pop rax
00007dd052fddca2  add rsp, 0x08
00007dd052fddca6  jmp 0x00007DD052FD96CD
00007dd052fddcab  call 0x00007DD052EE45A0
00007dd052fddcb0  jmp 0x00007DD052FD96D7
00007dd052fddcb5  sub rsp, 0x08
00007dd052fddcb9  push rax
00007dd052fddcba  push rcx
00007dd052fddcbb  push rdx
00007dd052fddcbc  push rdi
00007dd052fddcbd  push rsi
00007dd052fddcbe  push r8
00007dd052fddcc0  push r9
00007dd052fddcc2  push r10
00007dd052fddcc4  push r11
00007dd052fddcc6  sub rsp, 0xF0
00007dd052fddccd  vmovaps [rsp], xmm0
00007dd052fddcd2  vmovaps [rsp+0x10], xmm1
00007dd052fddcd8  vmovaps [rsp+0x20], xmm2
00007dd052fddcde  vmovaps [rsp+0x30], xmm3
00007dd052fddce4  vmovaps [rsp+0x40], xmm4
00007dd052fddcea  vmovaps [rsp+0x50], xmm5
00007dd052fddcf0  vmovaps [rsp+0x60], xmm6
00007dd052fddcf6  vmovaps [rsp+0x70], xmm7
00007dd052fddcfc  vmovaps [rsp+0x80], xmm8
00007dd052fddd05  vmovaps [rsp+0x90], xmm9
00007dd052fddd0e  vmovaps [rsp+0xA0], xmm11
00007dd052fddd17  vmovaps [rsp+0xB0], xmm12
00007dd052fddd20  vmovaps [rsp+0xC0], xmm13
00007dd052fddd29  vmovaps [rsp+0xD0], xmm14
00007dd052fddd32  vmovaps [rsp+0xE0], xmm15
00007dd052fddd3b  sub rsp, 0x30
00007dd052fddd3f  movaps [rsp], xmm10
00007dd052fddd44  movaps [rsp+0x10], xmm1
00007dd052fddd49  movaps [rsp+0x20], xmm12
00007dd052fddd4f  lea rdi, [rsp]
00007dd052fddd53  mov esi, 0x00
00007dd052fddd58  mov rax, 0x61D0404B9530
00007dd052fddd62  call rax
00007dd052fddd64  movaps xmm10, [rsp]
00007dd052fddd69  add rsp, 0x30
00007dd052fddd6d  vmovaps xmm0, [rsp]
00007dd052fddd72  vmovaps xmm1, [rsp+0x10]
00007dd052fddd78  vmovaps xmm2, [rsp+0x20]
00007dd052fddd7e  vmovaps xmm3, [rsp+0x30]
00007dd052fddd84  vmovaps xmm4, [rsp+0x40]
00007dd052fddd8a  vmovaps xmm5, [rsp+0x50]
00007dd052fddd90  vmovaps xmm6, [rsp+0x60]
00007dd052fddd96  vmovaps xmm7, [rsp+0x70]
00007dd052fddd9c  vmovaps xmm8, [rsp+0x80]
00007dd052fddda5  vmovaps xmm9, [rsp+0x90]
00007dd052fdddae  vmovaps xmm11, [rsp+0xA0]
00007dd052fdddb7  vmovaps xmm12, [rsp+0xB0]
00007dd052fdddc0  vmovaps xmm13, [rsp+0xC0]
00007dd052fdddc9  vmovaps xmm14, [rsp+0xD0]
00007dd052fdddd2  vmovaps xmm15, [rsp+0xE0]
00007dd052fddddb  add rsp, 0xF0
00007dd052fddde2  pop r11
00007dd052fddde4  pop r10
00007dd052fddde6  pop r9
00007dd052fddde8  pop r8
00007dd052fdddea  pop rsi
00007dd052fdddeb  pop rdi
00007dd052fdddec  pop rdx
00007dd052fddded  pop rcx
00007dd052fdddee  pop rax
00007dd052fdddef  add rsp, 0x08
00007dd052fdddf3  jmp 0x00007DD052FD96FA
00007dd052fdddf8  sub rsp, 0x08
00007dd052fdddfc  push rax
00007dd052fdddfd  push rcx
00007dd052fdddfe  push rdx
00007dd052fdddff  push rdi
00007dd052fdde00  push rsi
00007dd052fdde01  push r8
00007dd052fdde03  push r9
00007dd052fdde05  push r10
00007dd052fdde07  push r11
00007dd052fdde09  sub rsp, 0xF0
00007dd052fdde10  vmovaps [rsp], xmm0
00007dd052fdde15  vmovaps [rsp+0x10], xmm1
00007dd052fdde1b  vmovaps [rsp+0x20], xmm2
00007dd052fdde21  vmovaps [rsp+0x30], xmm3
00007dd052fdde27  vmovaps [rsp+0x40], xmm4
00007dd052fdde2d  vmovaps [rsp+0x50], xmm5
00007dd052fdde33  vmovaps [rsp+0x60], xmm6
00007dd052fdde39  vmovaps [rsp+0x70], xmm7
00007dd052fdde3f  vmovaps [rsp+0x80], xmm8
00007dd052fdde48  vmovaps [rsp+0x90], xmm9
00007dd052fdde51  vmovaps [rsp+0xA0], xmm10
00007dd052fdde5a  vmovaps [rsp+0xB0], xmm11
00007dd052fdde63  vmovaps [rsp+0xC0], xmm13
00007dd052fdde6c  vmovaps [rsp+0xD0], xmm14
00007dd052fdde75  vmovaps [rsp+0xE0], xmm15
00007dd052fdde7e  sub rsp, 0x30
00007dd052fdde82  movaps [rsp], xmm12
00007dd052fdde87  movaps [rsp+0x10], xmm14
00007dd052fdde8d  movaps [rsp+0x20], xmm1
00007dd052fdde92  lea rdi, [rsp]
00007dd052fdde96  mov esi, 0x00
00007dd052fdde9b  mov rax, 0x61D0404B9530
00007dd052fddea5  call rax
00007dd052fddea7  movaps xmm12, [rsp]
00007dd052fddeac  add rsp, 0x30
00007dd052fddeb0  vmovaps xmm0, [rsp]
00007dd052fddeb5  vmovaps xmm1, [rsp+0x10]
00007dd052fddebb  vmovaps xmm2, [rsp+0x20]
00007dd052fddec1  vmovaps xmm3, [rsp+0x30]
00007dd052fddec7  vmovaps xmm4, [rsp+0x40]
00007dd052fddecd  vmovaps xmm5, [rsp+0x50]
00007dd052fdded3  vmovaps xmm6, [rsp+0x60]
00007dd052fdded9  vmovaps xmm7, [rsp+0x70]
00007dd052fddedf  vmovaps xmm8, [rsp+0x80]
00007dd052fddee8  vmovaps xmm9, [rsp+0x90]
00007dd052fddef1  vmovaps xmm10, [rsp+0xA0]
00007dd052fddefa  vmovaps xmm11, [rsp+0xB0]
00007dd052fddf03  vmovaps xmm13, [rsp+0xC0]
00007dd052fddf0c  vmovaps xmm14, [rsp+0xD0]
00007dd052fddf15  vmovaps xmm15, [rsp+0xE0]
00007dd052fddf1e  add rsp, 0xF0
00007dd052fddf25  pop r11
00007dd052fddf27  pop r10
00007dd052fddf29  pop r9
00007dd052fddf2b  pop r8
00007dd052fddf2d  pop rsi
00007dd052fddf2e  pop rdi
00007dd052fddf2f  pop rdx
00007dd052fddf30  pop rcx
00007dd052fddf31  pop rax
00007dd052fddf32  add rsp, 0x08
00007dd052fddf36  jmp 0x00007DD052FD9729
00007dd052fddf3b  sub rsp, 0x08
00007dd052fddf3f  push rax
00007dd052fddf40  push rcx
00007dd052fddf41  push rdx
00007dd052fddf42  push rdi
00007dd052fddf43  push rsi
00007dd052fddf44  push r8
00007dd052fddf46  push r9
00007dd052fddf48  push r10
00007dd052fddf4a  push r11
00007dd052fddf4c  sub rsp, 0xF0
00007dd052fddf53  vmovaps [rsp], xmm0
00007dd052fddf58  vmovaps [rsp+0x10], xmm1
00007dd052fddf5e  vmovaps [rsp+0x20], xmm2
00007dd052fddf64  vmovaps [rsp+0x30], xmm3
00007dd052fddf6a  vmovaps [rsp+0x40], xmm4
00007dd052fddf70  vmovaps [rsp+0x50], xmm5
00007dd052fddf76  vmovaps [rsp+0x60], xmm6
00007dd052fddf7c  vmovaps [rsp+0x70], xmm7
00007dd052fddf82  vmovaps [rsp+0x80], xmm8
00007dd052fddf8b  vmovaps [rsp+0x90], xmm9
00007dd052fddf94  vmovaps [rsp+0xA0], xmm10
00007dd052fddf9d  vmovaps [rsp+0xB0], xmm11
00007dd052fddfa6  vmovaps [rsp+0xC0], xmm12
00007dd052fddfaf  vmovaps [rsp+0xD0], xmm13
00007dd052fddfb8  vmovaps [rsp+0xE0], xmm15
00007dd052fddfc1  sub rsp, 0x30
00007dd052fddfc5  movaps [rsp], xmm14
00007dd052fddfca  movaps [rsp+0x10], xmm9
00007dd052fddfd0  movaps [rsp+0x20], xmm1
00007dd052fddfd5  lea rdi, [rsp]
00007dd052fddfd9  mov esi, 0x00
00007dd052fddfde  mov rax, 0x61D0404B9530
00007dd052fddfe8  call rax
00007dd052fddfea  movaps xmm14, [rsp]
00007dd052fddfef  add rsp, 0x30
00007dd052fddff3  vmovaps xmm0, [rsp]
00007dd052fddff8  vmovaps xmm1, [rsp+0x10]
00007dd052fddffe  vmovaps xmm2, [rsp+0x20]
00007dd052fde004  vmovaps xmm3, [rsp+0x30]
00007dd052fde00a  vmovaps xmm4, [rsp+0x40]
00007dd052fde010  vmovaps xmm5, [rsp+0x50]
00007dd052fde016  vmovaps xmm6, [rsp+0x60]
00007dd052fde01c  vmovaps xmm7, [rsp+0x70]
00007dd052fde022  vmovaps xmm8, [rsp+0x80]
00007dd052fde02b  vmovaps xmm9, [rsp+0x90]
00007dd052fde034  vmovaps xmm10, [rsp+0xA0]
00007dd052fde03d  vmovaps xmm11, [rsp+0xB0]
00007dd052fde046  vmovaps xmm12, [rsp+0xC0]
00007dd052fde04f  vmovaps xmm13, [rsp+0xD0]
00007dd052fde058  vmovaps xmm15, [rsp+0xE0]
00007dd052fde061  add rsp, 0xF0
00007dd052fde068  pop r11
00007dd052fde06a  pop r10
00007dd052fde06c  pop r9
00007dd052fde06e  pop r8
00007dd052fde070  pop rsi
00007dd052fde071  pop rdi
00007dd052fde072  pop rdx
00007dd052fde073  pop rcx
00007dd052fde074  pop rax
00007dd052fde075  add rsp, 0x08
00007dd052fde079  jmp 0x00007DD052FD9758
00007dd052fde07e  sub rsp, 0x08
00007dd052fde082  push rax
00007dd052fde083  push rcx
00007dd052fde084  push rdx
00007dd052fde085  push rdi
00007dd052fde086  push rsi
00007dd052fde087  push r8
00007dd052fde089  push r9
00007dd052fde08b  push r10
00007dd052fde08d  push r11
00007dd052fde08f  sub rsp, 0xF0
00007dd052fde096  vmovaps [rsp], xmm0
00007dd052fde09b  vmovaps [rsp+0x10], xmm2
00007dd052fde0a1  vmovaps [rsp+0x20], xmm3
00007dd052fde0a7  vmovaps [rsp+0x30], xmm4
00007dd052fde0ad  vmovaps [rsp+0x40], xmm5
00007dd052fde0b3  vmovaps [rsp+0x50], xmm6
00007dd052fde0b9  vmovaps [rsp+0x60], xmm7
00007dd052fde0bf  vmovaps [rsp+0x70], xmm8
00007dd052fde0c5  vmovaps [rsp+0x80], xmm9
00007dd052fde0ce  vmovaps [rsp+0x90], xmm10
00007dd052fde0d7  vmovaps [rsp+0xA0], xmm11
00007dd052fde0e0  vmovaps [rsp+0xB0], xmm12
00007dd052fde0e9  vmovaps [rsp+0xC0], xmm13
00007dd052fde0f2  vmovaps [rsp+0xD0], xmm14
00007dd052fde0fb  vmovaps [rsp+0xE0], xmm15
00007dd052fde104  sub rsp, 0x30
00007dd052fde108  movaps [rsp], xmm1
00007dd052fde10c  movaps [rsp+0x10], xmm13
00007dd052fde112  movaps [rsp+0x20], xmm8
00007dd052fde118  lea rdi, [rsp]
00007dd052fde11c  mov esi, 0x00
00007dd052fde121  mov rax, 0x61D0404B9530
00007dd052fde12b  call rax
00007dd052fde12d  movaps xmm1, [rsp]
00007dd052fde131  add rsp, 0x30
00007dd052fde135  vmovaps xmm0, [rsp]
00007dd052fde13a  vmovaps xmm2, [rsp+0x10]
00007dd052fde140  vmovaps xmm3, [rsp+0x20]
00007dd052fde146  vmovaps xmm4, [rsp+0x30]
00007dd052fde14c  vmovaps xmm5, [rsp+0x40]
00007dd052fde152  vmovaps xmm6, [rsp+0x50]
00007dd052fde158  vmovaps xmm7, [rsp+0x60]
00007dd052fde15e  vmovaps xmm8, [rsp+0x70]
00007dd052fde164  vmovaps xmm9, [rsp+0x80]
00007dd052fde16d  vmovaps xmm10, [rsp+0x90]
00007dd052fde176  vmovaps xmm11, [rsp+0xA0]
00007dd052fde17f  vmovaps xmm12, [rsp+0xB0]
00007dd052fde188  vmovaps xmm13, [rsp+0xC0]
00007dd052fde191  vmovaps xmm14, [rsp+0xD0]
00007dd052fde19a  vmovaps xmm15, [rsp+0xE0]
00007dd052fde1a3  add rsp, 0xF0
00007dd052fde1aa  pop r11
00007dd052fde1ac  pop r10
00007dd052fde1ae  pop r9
00007dd052fde1b0  pop r8
00007dd052fde1b2  pop rsi
00007dd052fde1b3  pop rdi
00007dd052fde1b4  pop rdx
00007dd052fde1b5  pop rcx
00007dd052fde1b6  pop rax
00007dd052fde1b7  add rsp, 0x08
00007dd052fde1bb  jmp 0x00007DD052FD977A
00007dd052fde1c0  call 0x00007DD052E0C260
00007dd052fde1c5  jmp 0x00007DD052FD9788
00007dd052fde1ca  call 0x00007DD052EDE950
00007dd052fde1cf  jmp 0x00007DD052FD9792
00007dd052fde1d4  sub rsp, 0x08
00007dd052fde1d8  push rax
00007dd052fde1d9  push rcx
00007dd052fde1da  push rdx
00007dd052fde1db  push rdi
00007dd052fde1dc  push rsi
00007dd052fde1dd  push r8
00007dd052fde1df  push r9
00007dd052fde1e1  push r10
00007dd052fde1e3  push r11
00007dd052fde1e5  sub rsp, 0xF0
00007dd052fde1ec  vmovaps [rsp], xmm0
00007dd052fde1f1  vmovaps [rsp+0x10], xmm1
00007dd052fde1f7  vmovaps [rsp+0x20], xmm2
00007dd052fde1fd  vmovaps [rsp+0x30], xmm3
00007dd052fde203  vmovaps [rsp+0x40], xmm4
00007dd052fde209  vmovaps [rsp+0x50], xmm5
00007dd052fde20f  vmovaps [rsp+0x60], xmm6
00007dd052fde215  vmovaps [rsp+0x70], xmm7
00007dd052fde21b  vmovaps [rsp+0x80], xmm9
00007dd052fde224  vmovaps [rsp+0x90], xmm10
00007dd052fde22d  vmovaps [rsp+0xA0], xmm11
00007dd052fde236  vmovaps [rsp+0xB0], xmm12
00007dd052fde23f  vmovaps [rsp+0xC0], xmm13
00007dd052fde248  vmovaps [rsp+0xD0], xmm14
00007dd052fde251  vmovaps [rsp+0xE0], xmm15
00007dd052fde25a  sub rsp, 0x30
00007dd052fde25e  movaps [rsp], xmm8
00007dd052fde263  movaps [rsp+0x10], xmm15
00007dd052fde269  movaps [rsp+0x20], xmm7
00007dd052fde26e  lea rdi, [rsp]
00007dd052fde272  mov esi, 0x00
00007dd052fde277  mov rax, 0x61D0404B9530
00007dd052fde281  call rax
00007dd052fde283  movaps xmm8, [rsp]
00007dd052fde288  add rsp, 0x30
00007dd052fde28c  vmovaps xmm0, [rsp]
00007dd052fde291  vmovaps xmm1, [rsp+0x10]
00007dd052fde297  vmovaps xmm2, [rsp+0x20]
00007dd052fde29d  vmovaps xmm3, [rsp+0x30]
00007dd052fde2a3  vmovaps xmm4, [rsp+0x40]
00007dd052fde2a9  vmovaps xmm5, [rsp+0x50]
00007dd052fde2af  vmovaps xmm6, [rsp+0x60]
00007dd052fde2b5  vmovaps xmm7, [rsp+0x70]
00007dd052fde2bb  vmovaps xmm9, [rsp+0x80]
00007dd052fde2c4  vmovaps xmm10, [rsp+0x90]
00007dd052fde2cd  vmovaps xmm11, [rsp+0xA0]
00007dd052fde2d6  vmovaps xmm12, [rsp+0xB0]
00007dd052fde2df  vmovaps xmm13, [rsp+0xC0]
00007dd052fde2e8  vmovaps xmm14, [rsp+0xD0]
00007dd052fde2f1  vmovaps xmm15, [rsp+0xE0]
00007dd052fde2fa  add rsp, 0xF0
00007dd052fde301  pop r11
00007dd052fde303  pop r10
00007dd052fde305  pop r9
00007dd052fde307  pop r8
00007dd052fde309  pop rsi
00007dd052fde30a  pop rdi
00007dd052fde30b  pop rdx
00007dd052fde30c  pop rcx
00007dd052fde30d  pop rax
00007dd052fde30e  add rsp, 0x08
00007dd052fde312  jmp 0x00007DD052FD97B4
00007dd052fde317  sub rsp, 0x08
00007dd052fde31b  push rax
00007dd052fde31c  push rcx
00007dd052fde31d  push rdx
00007dd052fde31e  push rdi
00007dd052fde31f  push rsi
00007dd052fde320  push r8
00007dd052fde322  push r9
00007dd052fde324  push r10
00007dd052fde326  push r11
00007dd052fde328  sub rsp, 0xF0
00007dd052fde32f  vmovaps [rsp], xmm0
00007dd052fde334  vmovaps [rsp+0x10], xmm1
00007dd052fde33a  vmovaps [rsp+0x20], xmm2
00007dd052fde340  vmovaps [rsp+0x30], xmm3
00007dd052fde346  vmovaps [rsp+0x40], xmm4
00007dd052fde34c  vmovaps [rsp+0x50], xmm5
00007dd052fde352  vmovaps [rsp+0x60], xmm6
00007dd052fde358  vmovaps [rsp+0x70], xmm8
00007dd052fde35e  vmovaps [rsp+0x80], xmm9
00007dd052fde367  vmovaps [rsp+0x90], xmm10
00007dd052fde370  vmovaps [rsp+0xA0], xmm11
00007dd052fde379  vmovaps [rsp+0xB0], xmm12
00007dd052fde382  vmovaps [rsp+0xC0], xmm13
00007dd052fde38b  vmovaps [rsp+0xD0], xmm14
00007dd052fde394  vmovaps [rsp+0xE0], xmm15
00007dd052fde39d  sub rsp, 0x30
00007dd052fde3a1  movaps [rsp], xmm7
00007dd052fde3a5  movaps [rsp+0x10], xmm9
00007dd052fde3ab  movaps [rsp+0x20], xmm15
00007dd052fde3b1  lea rdi, [rsp]
00007dd052fde3b5  mov esi, 0x00
00007dd052fde3ba  mov rax, 0x61D0404B9530
00007dd052fde3c4  call rax
00007dd052fde3c6  movaps xmm7, [rsp]
00007dd052fde3ca  add rsp, 0x30
00007dd052fde3ce  vmovaps xmm0, [rsp]
00007dd052fde3d3  vmovaps xmm1, [rsp+0x10]
00007dd052fde3d9  vmovaps xmm2, [rsp+0x20]
00007dd052fde3df  vmovaps xmm3, [rsp+0x30]
00007dd052fde3e5  vmovaps xmm4, [rsp+0x40]
00007dd052fde3eb  vmovaps xmm5, [rsp+0x50]
00007dd052fde3f1  vmovaps xmm6, [rsp+0x60]
00007dd052fde3f7  vmovaps xmm8, [rsp+0x70]
00007dd052fde3fd  vmovaps xmm9, [rsp+0x80]
00007dd052fde406  vmovaps xmm10, [rsp+0x90]
00007dd052fde40f  vmovaps xmm11, [rsp+0xA0]
00007dd052fde418  vmovaps xmm12, [rsp+0xB0]
00007dd052fde421  vmovaps xmm13, [rsp+0xC0]
00007dd052fde42a  vmovaps xmm14, [rsp+0xD0]
00007dd052fde433  vmovaps xmm15, [rsp+0xE0]
00007dd052fde43c  add rsp, 0xF0
00007dd052fde443  pop r11
00007dd052fde445  pop r10
00007dd052fde447  pop r9
00007dd052fde449  pop r8
00007dd052fde44b  pop rsi
00007dd052fde44c  pop rdi
00007dd052fde44d  pop rdx
00007dd052fde44e  pop rcx
00007dd052fde44f  pop rax
00007dd052fde450  add rsp, 0x08
00007dd052fde454  jmp 0x00007DD052FD97E1
00007dd052fde459  sub rsp, 0x08
00007dd052fde45d  push rax
00007dd052fde45e  push rcx
00007dd052fde45f  push rdx
00007dd052fde460  push rdi
00007dd052fde461  push rsi
00007dd052fde462  push r8
00007dd052fde464  push r9
00007dd052fde466  push r10
00007dd052fde468  push r11
00007dd052fde46a  sub rsp, 0xF0
00007dd052fde471  vmovaps [rsp], xmm0
00007dd052fde476  vmovaps [rsp+0x10], xmm1
00007dd052fde47c  vmovaps [rsp+0x20], xmm2
00007dd052fde482  vmovaps [rsp+0x30], xmm3
00007dd052fde488  vmovaps [rsp+0x40], xmm4
00007dd052fde48e  vmovaps [rsp+0x50], xmm5
00007dd052fde494  vmovaps [rsp+0x60], xmm6
00007dd052fde49a  vmovaps [rsp+0x70], xmm7
00007dd052fde4a0  vmovaps [rsp+0x80], xmm8
00007dd052fde4a9  vmovaps [rsp+0x90], xmm10
00007dd052fde4b2  vmovaps [rsp+0xA0], xmm11
00007dd052fde4bb  vmovaps [rsp+0xB0], xmm12
00007dd052fde4c4  vmovaps [rsp+0xC0], xmm13
00007dd052fde4cd  vmovaps [rsp+0xD0], xmm14
00007dd052fde4d6  vmovaps [rsp+0xE0], xmm15
00007dd052fde4df  sub rsp, 0x30
00007dd052fde4e3  movaps [rsp], xmm9
00007dd052fde4e8  movaps [rsp+0x10], xmm13
00007dd052fde4ee  movaps [rsp+0x20], xmm15
00007dd052fde4f4  lea rdi, [rsp]
00007dd052fde4f8  mov esi, 0x00
00007dd052fde4fd  mov rax, 0x61D0404B9530
00007dd052fde507  call rax
00007dd052fde509  movaps xmm9, [rsp]
00007dd052fde50e  add rsp, 0x30
00007dd052fde512  vmovaps xmm0, [rsp]
00007dd052fde517  vmovaps xmm1, [rsp+0x10]
00007dd052fde51d  vmovaps xmm2, [rsp+0x20]
00007dd052fde523  vmovaps xmm3, [rsp+0x30]
00007dd052fde529  vmovaps xmm4, [rsp+0x40]
00007dd052fde52f  vmovaps xmm5, [rsp+0x50]
00007dd052fde535  vmovaps xmm6, [rsp+0x60]
00007dd052fde53b  vmovaps xmm7, [rsp+0x70]
00007dd052fde541  vmovaps xmm8, [rsp+0x80]
00007dd052fde54a  vmovaps xmm10, [rsp+0x90]
00007dd052fde553  vmovaps xmm11, [rsp+0xA0]
00007dd052fde55c  vmovaps xmm12, [rsp+0xB0]
00007dd052fde565  vmovaps xmm13, [rsp+0xC0]
00007dd052fde56e  vmovaps xmm14, [rsp+0xD0]
00007dd052fde577  vmovaps xmm15, [rsp+0xE0]
00007dd052fde580  add rsp, 0xF0
00007dd052fde587  pop r11
00007dd052fde589  pop r10
00007dd052fde58b  pop r9
00007dd052fde58d  pop r8
00007dd052fde58f  pop rsi
00007dd052fde590  pop rdi
00007dd052fde591  pop rdx
00007dd052fde592  pop rcx
00007dd052fde593  pop rax
00007dd052fde594  add rsp, 0x08
00007dd052fde598  jmp 0x00007DD052FD980F
00007dd052fde59d  sub rsp, 0x08
00007dd052fde5a1  push rax
00007dd052fde5a2  push rcx
00007dd052fde5a3  push rdx
00007dd052fde5a4  push rdi
00007dd052fde5a5  push rsi
00007dd052fde5a6  push r8
00007dd052fde5a8  push r9
00007dd052fde5aa  push r10
00007dd052fde5ac  push r11
00007dd052fde5ae  sub rsp, 0xF0
00007dd052fde5b5  vmovaps [rsp], xmm0
00007dd052fde5ba  vmovaps [rsp+0x10], xmm1
00007dd052fde5c0  vmovaps [rsp+0x20], xmm2
00007dd052fde5c6  vmovaps [rsp+0x30], xmm3
00007dd052fde5cc  vmovaps [rsp+0x40], xmm4
00007dd052fde5d2  vmovaps [rsp+0x50], xmm5
00007dd052fde5d8  vmovaps [rsp+0x60], xmm6
00007dd052fde5de  vmovaps [rsp+0x70], xmm7
00007dd052fde5e4  vmovaps [rsp+0x80], xmm8
00007dd052fde5ed  vmovaps [rsp+0x90], xmm9
00007dd052fde5f6  vmovaps [rsp+0xA0], xmm10
00007dd052fde5ff  vmovaps [rsp+0xB0], xmm11
00007dd052fde608  vmovaps [rsp+0xC0], xmm12
00007dd052fde611  vmovaps [rsp+0xD0], xmm13
00007dd052fde61a  vmovaps [rsp+0xE0], xmm14
00007dd052fde623  sub rsp, 0x30
00007dd052fde627  movaps [rsp], xmm15
00007dd052fde62c  movaps [rsp+0x10], xmm11
00007dd052fde632  movaps [rsp+0x20], xmm12
00007dd052fde638  lea rdi, [rsp]
00007dd052fde63c  mov esi, 0x00
00007dd052fde641  mov rax, 0x61D0404B9530
00007dd052fde64b  call rax
00007dd052fde64d  movaps xmm15, [rsp]
00007dd052fde652  add rsp, 0x30
00007dd052fde656  vmovaps xmm0, [rsp]
00007dd052fde65b  vmovaps xmm1, [rsp+0x10]
00007dd052fde661  vmovaps xmm2, [rsp+0x20]
00007dd052fde667  vmovaps xmm3, [rsp+0x30]
00007dd052fde66d  vmovaps xmm4, [rsp+0x40]
00007dd052fde673  vmovaps xmm5, [rsp+0x50]
00007dd052fde679  vmovaps xmm6, [rsp+0x60]
00007dd052fde67f  vmovaps xmm7, [rsp+0x70]
00007dd052fde685  vmovaps xmm8, [rsp+0x80]
00007dd052fde68e  vmovaps xmm9, [rsp+0x90]
00007dd052fde697  vmovaps xmm10, [rsp+0xA0]
00007dd052fde6a0  vmovaps xmm11, [rsp+0xB0]
00007dd052fde6a9  vmovaps xmm12, [rsp+0xC0]
00007dd052fde6b2  vmovaps xmm13, [rsp+0xD0]
00007dd052fde6bb  vmovaps xmm14, [rsp+0xE0]
00007dd052fde6c4  add rsp, 0xF0
00007dd052fde6cb  pop r11
00007dd052fde6cd  pop r10
00007dd052fde6cf  pop r9
00007dd052fde6d1  pop r8
00007dd052fde6d3  pop rsi
00007dd052fde6d4  pop rdi
00007dd052fde6d5  pop rdx
00007dd052fde6d6  pop rcx
00007dd052fde6d7  pop rax
00007dd052fde6d8  add rsp, 0x08
00007dd052fde6dc  jmp 0x00007DD052FD982A
00007dd052fde6e1  sub rsp, 0x08
00007dd052fde6e5  push rax
00007dd052fde6e6  push rcx
00007dd052fde6e7  push rdx
00007dd052fde6e8  push rdi
00007dd052fde6e9  push rsi
00007dd052fde6ea  push r8
00007dd052fde6ec  push r9
00007dd052fde6ee  push r10
00007dd052fde6f0  push r11
00007dd052fde6f2  sub rsp, 0xF0
00007dd052fde6f9  vmovaps [rsp], xmm0
00007dd052fde6fe  vmovaps [rsp+0x10], xmm1
00007dd052fde704  vmovaps [rsp+0x20], xmm2
00007dd052fde70a  vmovaps [rsp+0x30], xmm3
00007dd052fde710  vmovaps [rsp+0x40], xmm4
00007dd052fde716  vmovaps [rsp+0x50], xmm5
00007dd052fde71c  vmovaps [rsp+0x60], xmm6
00007dd052fde722  vmovaps [rsp+0x70], xmm7
00007dd052fde728  vmovaps [rsp+0x80], xmm8
00007dd052fde731  vmovaps [rsp+0x90], xmm9
00007dd052fde73a  vmovaps [rsp+0xA0], xmm10
00007dd052fde743  vmovaps [rsp+0xB0], xmm11
00007dd052fde74c  vmovaps [rsp+0xC0], xmm12
00007dd052fde755  vmovaps [rsp+0xD0], xmm14
00007dd052fde75e  vmovaps [rsp+0xE0], xmm15
00007dd052fde767  sub rsp, 0x30
00007dd052fde76b  movaps [rsp], xmm13
00007dd052fde770  movaps [rsp+0x10], xmm10
00007dd052fde776  movaps [rsp+0x20], xmm14
00007dd052fde77c  lea rdi, [rsp]
00007dd052fde780  mov esi, 0x00
00007dd052fde785  mov rax, 0x61D0404B9530
00007dd052fde78f  call rax
00007dd052fde791  movaps xmm13, [rsp]
00007dd052fde796  add rsp, 0x30
00007dd052fde79a  vmovaps xmm0, [rsp]
00007dd052fde79f  vmovaps xmm1, [rsp+0x10]
00007dd052fde7a5  vmovaps xmm2, [rsp+0x20]
00007dd052fde7ab  vmovaps xmm3, [rsp+0x30]
00007dd052fde7b1  vmovaps xmm4, [rsp+0x40]
00007dd052fde7b7  vmovaps xmm5, [rsp+0x50]
00007dd052fde7bd  vmovaps xmm6, [rsp+0x60]
00007dd052fde7c3  vmovaps xmm7, [rsp+0x70]
00007dd052fde7c9  vmovaps xmm8, [rsp+0x80]
00007dd052fde7d2  vmovaps xmm9, [rsp+0x90]
00007dd052fde7db  vmovaps xmm10, [rsp+0xA0]
00007dd052fde7e4  vmovaps xmm11, [rsp+0xB0]
00007dd052fde7ed  vmovaps xmm12, [rsp+0xC0]
00007dd052fde7f6  vmovaps xmm14, [rsp+0xD0]
00007dd052fde7ff  vmovaps xmm15, [rsp+0xE0]
00007dd052fde808  add rsp, 0xF0
00007dd052fde80f  pop r11
00007dd052fde811  pop r10
00007dd052fde813  pop r9
00007dd052fde815  pop r8
00007dd052fde817  pop rsi
00007dd052fde818  pop rdi
00007dd052fde819  pop rdx
00007dd052fde81a  pop rcx
00007dd052fde81b  pop rax
00007dd052fde81c  add rsp, 0x08
00007dd052fde820  jmp 0x00007DD052FD984D
00007dd052fde825  sub rsp, 0x08
00007dd052fde829  push rax
00007dd052fde82a  push rcx
00007dd052fde82b  push rdx
00007dd052fde82c  push rdi
00007dd052fde82d  push rsi
00007dd052fde82e  push r8
00007dd052fde830  push r9
00007dd052fde832  push r10
00007dd052fde834  push r11
00007dd052fde836  sub rsp, 0xF0
00007dd052fde83d  vmovaps [rsp], xmm0
00007dd052fde842  vmovaps [rsp+0x10], xmm1
00007dd052fde848  vmovaps [rsp+0x20], xmm2
00007dd052fde84e  vmovaps [rsp+0x30], xmm3
00007dd052fde854  vmovaps [rsp+0x40], xmm4
00007dd052fde85a  vmovaps [rsp+0x50], xmm5
00007dd052fde860  vmovaps [rsp+0x60], xmm6
00007dd052fde866  vmovaps [rsp+0x70], xmm7
00007dd052fde86c  vmovaps [rsp+0x80], xmm8
00007dd052fde875  vmovaps [rsp+0x90], xmm9
00007dd052fde87e  vmovaps [rsp+0xA0], xmm10
00007dd052fde887  vmovaps [rsp+0xB0], xmm11
00007dd052fde890  vmovaps [rsp+0xC0], xmm12
00007dd052fde899  vmovaps [rsp+0xD0], xmm13
00007dd052fde8a2  vmovaps [rsp+0xE0], xmm15
00007dd052fde8ab  sub rsp, 0x30
00007dd052fde8af  movaps [rsp], xmm14
00007dd052fde8b4  movaps [rsp+0x10], xmm1
00007dd052fde8b9  movaps [rsp+0x20], xmm7
00007dd052fde8be  lea rdi, [rsp]
00007dd052fde8c2  mov esi, 0x00
00007dd052fde8c7  mov rax, 0x61D0404B9530
00007dd052fde8d1  call rax
00007dd052fde8d3  movaps xmm14, [rsp]
00007dd052fde8d8  add rsp, 0x30
00007dd052fde8dc  vmovaps xmm0, [rsp]
00007dd052fde8e1  vmovaps xmm1, [rsp+0x10]
00007dd052fde8e7  vmovaps xmm2, [rsp+0x20]
00007dd052fde8ed  vmovaps xmm3, [rsp+0x30]
00007dd052fde8f3  vmovaps xmm4, [rsp+0x40]
00007dd052fde8f9  vmovaps xmm5, [rsp+0x50]
00007dd052fde8ff  vmovaps xmm6, [rsp+0x60]
00007dd052fde905  vmovaps xmm7, [rsp+0x70]
00007dd052fde90b  vmovaps xmm8, [rsp+0x80]
00007dd052fde914  vmovaps xmm9, [rsp+0x90]
00007dd052fde91d  vmovaps xmm10, [rsp+0xA0]
00007dd052fde926  vmovaps xmm11, [rsp+0xB0]
00007dd052fde92f  vmovaps xmm12, [rsp+0xC0]
00007dd052fde938  vmovaps xmm13, [rsp+0xD0]
00007dd052fde941  vmovaps xmm15, [rsp+0xE0]
00007dd052fde94a  add rsp, 0xF0
00007dd052fde951  pop r11
00007dd052fde953  pop r10
00007dd052fde955  pop r9
00007dd052fde957  pop r8
00007dd052fde959  pop rsi
00007dd052fde95a  pop rdi
00007dd052fde95b  pop rdx
00007dd052fde95c  pop rcx
00007dd052fde95d  pop rax
00007dd052fde95e  add rsp, 0x08
00007dd052fde962  jmp 0x00007DD052FD9870
00007dd052fde967  sub rsp, 0x08
00007dd052fde96b  push rax
00007dd052fde96c  push rcx
00007dd052fde96d  push rdx
00007dd052fde96e  push rdi
00007dd052fde96f  push rsi
00007dd052fde970  push r8
00007dd052fde972  push r9
00007dd052fde974  push r10
00007dd052fde976  push r11
00007dd052fde978  sub rsp, 0xF0
00007dd052fde97f  vmovaps [rsp], xmm0
00007dd052fde984  vmovaps [rsp+0x10], xmm2
00007dd052fde98a  vmovaps [rsp+0x20], xmm3
00007dd052fde990  vmovaps [rsp+0x30], xmm4
00007dd052fde996  vmovaps [rsp+0x40], xmm5
00007dd052fde99c  vmovaps [rsp+0x50], xmm6
00007dd052fde9a2  vmovaps [rsp+0x60], xmm7
00007dd052fde9a8  vmovaps [rsp+0x70], xmm8
00007dd052fde9ae  vmovaps [rsp+0x80], xmm9
00007dd052fde9b7  vmovaps [rsp+0x90], xmm10
00007dd052fde9c0  vmovaps [rsp+0xA0], xmm11
00007dd052fde9c9  vmovaps [rsp+0xB0], xmm12
00007dd052fde9d2  vmovaps [rsp+0xC0], xmm13
00007dd052fde9db  vmovaps [rsp+0xD0], xmm14
00007dd052fde9e4  vmovaps [rsp+0xE0], xmm15
00007dd052fde9ed  sub rsp, 0x30
00007dd052fde9f1  movaps [rsp], xmm1
00007dd052fde9f5  movaps [rsp+0x10], xmm8
00007dd052fde9fb  movaps [rsp+0x20], xmm9
00007dd052fdea01  lea rdi, [rsp]
00007dd052fdea05  mov esi, 0x00
00007dd052fdea0a  mov rax, 0x61D0404B9530
00007dd052fdea14  call rax
00007dd052fdea16  movaps xmm1, [rsp]
00007dd052fdea1a  add rsp, 0x30
00007dd052fdea1e  vmovaps xmm0, [rsp]
00007dd052fdea23  vmovaps xmm2, [rsp+0x10]
00007dd052fdea29  vmovaps xmm3, [rsp+0x20]
00007dd052fdea2f  vmovaps xmm4, [rsp+0x30]
00007dd052fdea35  vmovaps xmm5, [rsp+0x40]
00007dd052fdea3b  vmovaps xmm6, [rsp+0x50]
00007dd052fdea41  vmovaps xmm7, [rsp+0x60]
00007dd052fdea47  vmovaps xmm8, [rsp+0x70]
00007dd052fdea4d  vmovaps xmm9, [rsp+0x80]
00007dd052fdea56  vmovaps xmm10, [rsp+0x90]
00007dd052fdea5f  vmovaps xmm11, [rsp+0xA0]
00007dd052fdea68  vmovaps xmm12, [rsp+0xB0]
00007dd052fdea71  vmovaps xmm13, [rsp+0xC0]
00007dd052fdea7a  vmovaps xmm14, [rsp+0xD0]
00007dd052fdea83  vmovaps xmm15, [rsp+0xE0]
00007dd052fdea8c  add rsp, 0xF0
00007dd052fdea93  pop r11
00007dd052fdea95  pop r10
00007dd052fdea97  pop r9
00007dd052fdea99  pop r8
00007dd052fdea9b  pop rsi
00007dd052fdea9c  pop rdi
00007dd052fdea9d  pop rdx
00007dd052fdea9e  pop rcx
00007dd052fdea9f  pop rax
00007dd052fdeaa0  add rsp, 0x08
00007dd052fdeaa4  jmp 0x00007DD052FD9892
00007dd052fdeaa9  call 0x00007DD052EB3E40
00007dd052fdeaae  jmp 0x00007DD052FD98A0
00007dd052fdeab3  call 0x00007DD052E0C380
00007dd052fdeab8  jmp 0x00007DD052FD98AA
00007dd052fdeabd  call 0x00007DD052E0D600
00007dd052fdeac2  jmp 0x00007DD052FD98B4
00007dd052fdeac7  call 0x00007DD052DFF540
00007dd052fdeacc  jmp 0x00007DD052FD98BE
00007dd052fdead1  int3
00007dd052fdead2  nop [rax+rax*1], ax
00007dd052fdeadb  nop [rax+rax*1], eax
00007dd052fdeae0  mov eax, [r15+0x48]
00007dd052fdeae4  lea r14d, [eax+0x01]
00007dd052fdeae9  mov [rsp+0x10], r14d
00007dd052fdeaee  mov r14d, r14d
00007dd052fdeaf1  mov [r15+0x48], r14
00007dd052fdeaf5  xor eax, eax
00007dd052fdeaf7  mov r14d, [rsp+0x10]
00007dd052fdeafc  cmp r14d, 0x1F4
00007dd052fdeb03  cmc
00007dd052fdeb04  lahf
00007dd052fdeb05  seto al
00007dd052fdeb08  mov [r15+0x108], eax
00007dd052fdeb0f  mov eax, [r15+0x108]
00007dd052fdeb16  sahf
00007dd052fdeb17  jnz 0x00007DD052FDEB49
00007dd052fdeb19  cmp dword ptr [r15+0x318], 0x00
00007dd052fdeb21  jz 0x00007DD052FE4C90
00007dd052fdeb27  nop [rax+rax*1], ax
00007dd052fdeb30  nop [rax+rax*1], eax
00007dd052fdeb38  mov eax, 0x4106DC
00007dd052fdeb3d  mov [r15+0x100], rax
00007dd052fdeb44  jmp 0x00007DD052DFE110
00007dd052fdeb49  cmp dword ptr [r15+0x318], 0x00
00007dd052fdeb51  jz 0x00007DD052FDEB80
00007dd052fdeb57  nop [rax+rax*1], ax
00007dd052fdeb60  nop [rax+rax*1], eax
00007dd052fdeb68  mov eax, 0x410500
00007dd052fdeb6d  mov [r15+0x100], rax
00007dd052fdeb74  jmp 0x00007DD052DFE110
00007dd052fdeb79  int3
00007dd052fdeb7a  int3
00007dd052fdeb7b  nop [rax+rax*1], eax
00007dd052fdeb80  mov rax, [r15+0x40]
00007dd052fdeb84  movaps xmm1, [r15+0x1D0]
00007dd052fdeb8c  vmovaps [rsp+0x10], xmm1
00007dd052fdeb92  vmovaps xmm15, [rsp+0x10]
00007dd052fdeb98  por xmm1, xmm15
00007dd052fdeb9d  movaps xmm14, [r15+0x1A0]
00007dd052fdeba5  vmovaps [rsp+0x10], xmm14
00007dd052fdebab  vmovaps xmm13, [rsp+0x10]
00007dd052fdebb1  por xmm14, xmm13
00007dd052fdebb6  lea r14, [rax+0x30]
00007dd052fdebba  mov r12, [r13+r14*1]
00007dd052fdebbf  lea r14, [rax+0x38]
00007dd052fdebc3  mov r11, [r13+r14*1]
00007dd052fdebc8  movq xmm13, r12
00007dd052fdebcd  movq xmm12, r11
00007dd052fdebd2  movq xmm13, xmm13
00007dd052fdebd7  vmovaps [rsp+0x10], xmm13
00007dd052fdebdd  movq xmm13, xmm13
00007dd052fdebe2  movaps [r15+0x130], xmm13
00007dd052fdebea  movq xmm12, xmm12
00007dd052fdebef  vmovaps [rsp+0x20], xmm12
00007dd052fdebf5  movq xmm12, xmm12
00007dd052fdebfa  movaps [r15+0x280], xmm12
00007dd052fdec02  movaps xmm13, [r15+0x270]
00007dd052fdec0a  vmovaps [rsp+0x30], xmm13
00007dd052fdec10  vmovaps xmm12, [rsp+0x30]
00007dd052fdec16  por xmm13, xmm12
00007dd052fdec1b  lea r14, [rax+0x20]
00007dd052fdec1f  mov r12, [r13+r14*1]
00007dd052fdec24  lea r14, [rax+0x28]
00007dd052fdec28  mov r11, [r13+r14*1]
00007dd052fdec2d  movq xmm12, r12
00007dd052fdec32  movq xmm11, r11
00007dd052fdec37  movq xmm12, xmm12
00007dd052fdec3c  vmovaps [rsp+0x30], xmm12
00007dd052fdec42  movq xmm12, xmm12
00007dd052fdec47  movaps [r15+0x150], xmm12
00007dd052fdec4f  movq xmm11, xmm11
00007dd052fdec54  vmovaps [rsp+0x40], xmm11
00007dd052fdec5a  movq xmm11, xmm11
00007dd052fdec5f  movaps [r15+0x140], xmm11
00007dd052fdec67  lea r14, [rax+0x10]
00007dd052fdec6b  mov r12, [r13+r14*1]
00007dd052fdec70  lea r14, [rax+0x18]
00007dd052fdec74  mov r11, [r13+r14*1]
00007dd052fdec79  movq xmm12, r12
00007dd052fdec7e  movq xmm11, r11
00007dd052fdec83  movq xmm12, xmm12
00007dd052fdec88  vmovaps [rsp+0x50], xmm12
00007dd052fdec8e  movq xmm12, xmm12
00007dd052fdec93  movaps [r15+0x170], xmm12
00007dd052fdec9b  movq xmm11, xmm11
00007dd052fdeca0  vmovaps [rsp+0x60], xmm11
00007dd052fdeca6  movq xmm11, xmm11
00007dd052fdecab  movaps [r15+0x160], xmm11
00007dd052fdecb3  mov r14, [r13+rax*1]
00007dd052fdecb8  vmovq xmm12, r14
00007dd052fdecbd  vpbroadcastq xmm12, xmm12
00007dd052fdecc2  lea r14, [rax+0x08]
00007dd052fdecc6  mov rax, [r13+r14*1]
00007dd052fdeccb  movq xmm11, rax
00007dd052fdecd0  movaps [r15+0x230], xmm11
00007dd052fdecd8  mov rax, [r15+0xF8]
00007dd052fdecdf  lea r14, [rax+0x50]
00007dd052fdece3  movups xmm11, [r13+r14*1]
00007dd052fdece9  lea r14, [rax+0x60]
00007dd052fdeced  movups xmm10, [r13+r14*1]
00007dd052fdecf3  lea r14, [rax+0x30]
00007dd052fdecf7  movups xmm9, [r13+r14*1]
00007dd052fdecfd  mov r14, [r15+0x50]
00007dd052fded01  mov [r15+0x60], r14
00007dd052fded05  mov qword ptr [r15+0x58], 0x40
00007dd052fded0d  movaps xmm8, xmm12
00007dd052fded11  mulpd xmm8, xmm15
00007dd052fded16  vcmppd xmm7, xmm8, xmm8, 0x03
00007dd052fded1c  ptest xmm7, xmm7
00007dd052fded21  jnz 0x00007DD052FDFB4A
00007dd052fded27  movq xmm15, qword ptr [r15+0x230]
00007dd052fded30  vmovaps [rsp+0x70], xmm15
00007dd052fded36  vpermilpd xmm15, xmm15, 0x00
00007dd052fded3c  movaps xmm7, xmm9
00007dd052fded40  mulpd xmm7, xmm15
00007dd052fded45  vcmppd xmm6, xmm7, xmm7, 0x03
00007dd052fded4a  ptest xmm6, xmm6
00007dd052fded4f  jnz 0x00007DD052FDFC8E
00007dd052fded55  vxorps xmm15, xmm15, xmm15
00007dd052fded5a  vpbroadcastq xmm15, xmm15
00007dd052fded5f  movaps xmm9, xmm12
00007dd052fded63  mulpd xmm9, xmm10
00007dd052fded68  vcmppd xmm6, xmm9, xmm9, 0x03
00007dd052fded6e  ptest xmm6, xmm6
00007dd052fded73  jnz 0x00007DD052FDFDD0
00007dd052fded79  movaps xmm10, xmm12
00007dd052fded7d  mulpd xmm10, xmm11
00007dd052fded82  vcmppd xmm6, xmm10, xmm10, 0x03
00007dd052fded88  ptest xmm6, xmm6
00007dd052fded8d  jnz 0x00007DD052FDFF14
00007dd052fded93  movaps xmm11, [r15+0x1F0]
00007dd052fded9b  movaps xmm6, xmm12
00007dd052fded9f  mulpd xmm6, xmm11
00007dd052fdeda4  vcmppd xmm5, xmm6, xmm6, 0x03
00007dd052fdeda9  ptest xmm5, xmm5
00007dd052fdedae  jnz 0x00007DD052FE0058
00007dd052fdedb4  movaps xmm12, [r15+0x2A0]
00007dd052fdedbc  vmovaps [rsp+0x80], xmm12
00007dd052fdedc5  vmovaps xmm11, [rsp+0x80]
00007dd052fdedce  por xmm12, xmm11
00007dd052fdedd3  movaps xmm11, [r15+0x250]
00007dd052fdeddb  vmovaps [rsp+0x80], xmm11
00007dd052fdede4  vmovaps xmm5, [rsp+0x80]
00007dd052fdeded  por xmm11, xmm5
00007dd052fdedf2  vmovaps xmm4, [rsp+0x70]
00007dd052fdedf8  vpermilpd xmm4, xmm4, 0x00
00007dd052fdedfe  movaps xmm3, xmm5
00007dd052fdee01  mulpd xmm3, xmm4
00007dd052fdee05  vcmppd xmm2, xmm3, xmm3, 0x03
00007dd052fdee0a  ptest xmm2, xmm2
00007dd052fdee0f  jnz 0x00007DD052FE019A
00007dd052fdee15  mov [rsp+0x80], rax
00007dd052fdee1d  xor eax, eax
00007dd052fdee1f  mov r12d, 0x40
00007dd052fdee25  mov r11d, 0x200
00007dd052fdee2b  cmp r12, r11
00007dd052fdee2e  cmc
00007dd052fdee2f  lahf
00007dd052fdee30  seto al
00007dd052fdee33  mov [r15+0x108], eax
00007dd052fdee3a  movaps xmm5, xmm8
00007dd052fdee3e  addpd xmm5, xmm15
00007dd052fdee43  vcmppd xmm4, xmm5, xmm5, 0x03
00007dd052fdee48  ptest xmm4, xmm4
00007dd052fdee4d  jnz 0x00007DD052FE02DA
00007dd052fdee53  movaps xmm8, [r15+0x1B0]
00007dd052fdee5b  movaps xmm4, xmm9
00007dd052fdee5f  addpd xmm4, xmm8
00007dd052fdee64  vcmppd xmm2, xmm4, xmm4, 0x03
00007dd052fdee69  ptest xmm2, xmm2
00007dd052fdee6e  jnz 0x00007DD052FE041C
00007dd052fdee74  movaps xmm9, xmm10
00007dd052fdee78  addpd xmm9, xmm8
00007dd052fdee7d  vcmppd xmm2, xmm9, xmm9, 0x03
00007dd052fdee83  ptest xmm2, xmm2
00007dd052fdee88  jnz 0x00007DD052FE055E
00007dd052fdee8e  movaps xmm10, [r15+0x2F0]
00007dd052fdee96  vmovaps [rsp+0x90], xmm10
00007dd052fdee9f  vmovaps xmm8, [rsp+0x90]
00007dd052fdeea8  por xmm10, xmm8
00007dd052fdeead  movaps xmm8, [r15+0x2E0]
00007dd052fdeeb5  vmovaps [rsp+0x90], xmm8
00007dd052fdeebe  vmovaps xmm2, [rsp+0x90]
00007dd052fdeec7  por xmm8, xmm2
00007dd052fdeecc  movaps xmm2, [r15+0x2D0]
00007dd052fdeed4  vmovaps [rsp+0x90], xmm2
00007dd052fdeedd  vmovaps [rsp+0xA0], xmm1
00007dd052fdeee6  vmovaps xmm1, [rsp+0x90]
00007dd052fdeeef  por xmm2, xmm1
00007dd052fdeef3  movaps xmm1, [r15+0x200]
00007dd052fdeefb  vmovaps [rsp+0x90], xmm1
00007dd052fdef04  vmovaps [rsp+0xB0], xmm15
00007dd052fdef0d  vmovaps xmm15, [rsp+0x90]
00007dd052fdef16  por xmm1, xmm15
00007dd052fdef1b  movaps xmm15, [r15+0x1C0]
00007dd052fdef23  vmovaps [rsp+0x90], xmm15
00007dd052fdef2c  vmovaps [rsp+0xC0], xmm1
00007dd052fdef35  vmovaps xmm1, [rsp+0x90]
00007dd052fdef3e  por xmm15, xmm1
00007dd052fdef43  movaps xmm1, [r15+0x190]
00007dd052fdef4b  vmovaps [rsp+0x90], xmm1
00007dd052fdef54  vmovaps [rsp+0xD0], xmm15
00007dd052fdef5d  vmovaps xmm15, [rsp+0x90]
00007dd052fdef66  por xmm1, xmm15
00007dd052fdef6b  movaps xmm15, [r15+0x300]
00007dd052fdef73  vmovaps [rsp+0x90], xmm15
00007dd052fdef7c  vmovaps [rsp+0xE0], xmm1
00007dd052fdef85  vmovaps xmm1, [rsp+0x90]
00007dd052fdef8e  por xmm15, xmm1
00007dd052fdef93  mov rax, [rsp+0x80]
00007dd052fdef9b  lea r12, [rax+0xA0]
00007dd052fdefa2  movups xmm1, [r13+r12*1]
00007dd052fdefa8  lea r12, [rax+0xB0]
00007dd052fdefaf  vmovaps [rsp+0x80], xmm1
00007dd052fdefb8  movups xmm1, [r13+r12*1]
00007dd052fdefbe  vmovaps [rsp+0x90], xmm1
00007dd052fdefc7  vmovaps [rsp+0xF0], xmm15
00007dd052fdefd0  vmovaps xmm15, [rsp+0xB0]
00007dd052fdefd9  vmovaps [rsp+0xB0], xmm14
00007dd052fdefe2  movaps xmm1, xmm6
00007dd052fdefe5  addpd xmm1, xmm15
00007dd052fdefea  vcmppd xmm14, xmm1, xmm1, 0x03
00007dd052fdefef  ptest xmm14, xmm14
00007dd052fdeff5  jnz 0x00007DD052FE06B6
00007dd052fdeffb  lea r12, [rax+0xF0]
00007dd052fdf002  movups xmm15, [r13+r12*1]
00007dd052fdf008  movaps xmm14, xmm4
00007dd052fdf00c  addpd xmm14, xmm3
00007dd052fdf011  vcmppd xmm6, xmm14, xmm14, 0x03
00007dd052fdf017  ptest xmm6, xmm6
00007dd052fdf01c  jnz 0x00007DD052FE0801
00007dd052fdf022  movaps xmm6, xmm9
00007dd052fdf026  addpd xmm6, xmm7
00007dd052fdf02a  vcmppd xmm4, xmm6, xmm6, 0x03
00007dd052fdf02f  ptest xmm4, xmm4
00007dd052fdf034  jnz 0x00007DD052FE0943
00007dd052fdf03a  vmovaps xmm9, [rsp+0x70]
00007dd052fdf040  vpermilpd xmm9, xmm9, 0x00
00007dd052fdf046  vmovaps xmm4, [rsp+0x90]
00007dd052fdf04f  movaps xmm7, xmm4
00007dd052fdf052  mulpd xmm7, xmm9
00007dd052fdf057  vcmppd xmm3, xmm7, xmm7, 0x03
00007dd052fdf05c  ptest xmm3, xmm3
00007dd052fdf061  jnz 0x00007DD052FE0A84
00007dd052fdf067  vmovaps xmm9, [rsp+0x50]
00007dd052fdf06d  vpermilpd xmm9, xmm9, 0x00
00007dd052fdf073  movaps xmm4, xmm15
00007dd052fdf077  mulpd xmm4, xmm9
00007dd052fdf07c  vcmppd xmm3, xmm4, xmm4, 0x03
00007dd052fdf081  ptest xmm3, xmm3
00007dd052fdf086  jnz 0x00007DD052FE0BC5
00007dd052fdf08c  lea r12, [rax+0xE0]
00007dd052fdf093  movups xmm15, [r13+r12*1]
00007dd052fdf099  vmovaps xmm9, [rsp+0x70]
00007dd052fdf09f  vpermilpd xmm9, xmm9, 0x00
00007dd052fdf0a5  vmovaps [rsp+0x70], xmm1
00007dd052fdf0ab  vmovaps xmm1, [rsp+0x80]
00007dd052fdf0b4  vmovaps [rsp+0x80], xmm15
00007dd052fdf0bd  movaps xmm3, xmm1
00007dd052fdf0c0  mulpd xmm3, xmm9
00007dd052fdf0c5  vcmppd xmm15, xmm3, xmm3, 0x03
00007dd052fdf0ca  ptest xmm15, xmm15
00007dd052fdf0d0  jnz 0x00007DD052FE0D11
00007dd052fdf0d6  vmovaps xmm1, [rsp+0xF0]
00007dd052fdf0df  vmovaps xmm15, [rsp+0xF0]
00007dd052fdf0e8  por xmm1, xmm15
00007dd052fdf0ed  movaps [r15+0x300], xmm1
00007dd052fdf0f5  vmovaps xmm15, [rsp+0xE0]
00007dd052fdf0fe  vmovaps xmm9, [rsp+0xE0]
00007dd052fdf107  por xmm15, xmm9
00007dd052fdf10c  movaps [r15+0x190], xmm15
00007dd052fdf114  vmovaps xmm9, [rsp+0x50]
00007dd052fdf11a  vpermilpd xmm9, xmm9, 0x00
00007dd052fdf120  vmovaps [rsp+0x90], xmm1
00007dd052fdf129  vmovaps [rsp+0xE0], xmm15
00007dd052fdf132  vmovaps xmm15, [rsp+0x80]
00007dd052fdf13b  vmovaps [rsp+0x80], xmm14
00007dd052fdf144  movaps xmm1, xmm15
00007dd052fdf148  mulpd xmm1, xmm9
00007dd052fdf14d  vcmppd xmm14, xmm1, xmm1, 0x03
00007dd052fdf152  ptest xmm14, xmm14
00007dd052fdf158  jnz 0x00007DD052FE0E52
00007dd052fdf15e  lea r12, [rax+0x90]
00007dd052fdf165  movups xmm15, [r13+r12*1]
00007dd052fdf16b  vmovaps xmm14, [rsp+0xD0]
00007dd052fdf174  vmovaps xmm9, [rsp+0xD0]
00007dd052fdf17d  por xmm14, xmm9
00007dd052fdf182  movaps [r15+0x1C0], xmm14
00007dd052fdf18a  vmovaps xmm9, [rsp+0xC0]
00007dd052fdf193  vmovaps [rsp+0xD0], xmm1
00007dd052fdf19c  vmovaps xmm1, [rsp+0xC0]
00007dd052fdf1a5  por xmm9, xmm1
00007dd052fdf1aa  movaps [r15+0x200], xmm9
00007dd052fdf1b2  vmovaps [rsp+0xC0], xmm2
00007dd052fdf1bb  vmovaps xmm1, [rsp+0xC0]
00007dd052fdf1c4  por xmm2, xmm1
00007dd052fdf1c8  movaps [r15+0x2D0], xmm2
00007dd052fdf1d0  vmovaps [rsp+0xC0], xmm8
00007dd052fdf1d9  vmovaps xmm1, [rsp+0xC0]
00007dd052fdf1e2  por xmm8, xmm1
00007dd052fdf1e7  movaps [r15+0x2E0], xmm8
00007dd052fdf1ef  vmovaps [rsp+0xC0], xmm15
00007dd052fdf1f8  movaps xmm1, xmm5
00007dd052fdf1fb  addpd xmm1, xmm7
00007dd052fdf1ff  vcmppd xmm15, xmm1, xmm1, 0x03
00007dd052fdf204  ptest xmm15, xmm15
00007dd052fdf20a  jnz 0x00007DD052FE0F9E
00007dd052fdf210  vmovaps xmm15, [rsp+0x50]
00007dd052fdf216  vpermilpd xmm15, xmm15, 0x00
00007dd052fdf21c  vmovaps xmm5, [rsp+0xC0]
00007dd052fdf225  vmovaps [rsp+0xC0], xmm1
00007dd052fdf22e  movaps xmm7, xmm5
00007dd052fdf231  mulpd xmm7, xmm15
00007dd052fdf236  vcmppd xmm1, xmm7, xmm7, 0x03
00007dd052fdf23b  ptest xmm1, xmm1
00007dd052fdf240  jnz 0x00007DD052FE10DE
00007dd052fdf246  lea r12, [rax+0x80]
00007dd052fdf24d  movups xmm1, [r13+r12*1]
00007dd052fdf253  vmovaps xmm5, [rsp+0x70]
00007dd052fdf259  vmovaps [rsp+0x70], xmm1
00007dd052fdf25f  movaps xmm15, xmm5
00007dd052fdf263  addpd xmm15, xmm3
00007dd052fdf268  vcmppd xmm1, xmm15, xmm15, 0x03
00007dd052fdf26e  ptest xmm1, xmm1
00007dd052fdf273  jnz 0x00007DD052FE1229
00007dd052fdf279  vmovaps xmm5, [rsp+0x80]
00007dd052fdf282  movaps xmm1, xmm5
00007dd052fdf285  addpd xmm1, xmm4
00007dd052fdf289  vcmppd xmm3, xmm1, xmm1, 0x03
00007dd052fdf28e  ptest xmm3, xmm3
00007dd052fdf293  jnz 0x00007DD052FE136B
00007dd052fdf299  vmovaps [rsp+0x80], xmm10
00007dd052fdf2a2  vmovaps xmm5, [rsp+0x80]
00007dd052fdf2ab  por xmm10, xmm5
00007dd052fdf2b0  movaps [r15+0x2F0], xmm10
00007dd052fdf2b8  vmovaps xmm5, [rsp+0x50]
00007dd052fdf2be  vpermilpd xmm5, xmm5, 0x00
00007dd052fdf2c4  vmovaps xmm3, [rsp+0x70]
00007dd052fdf2ca  vmovaps [rsp+0x50], xmm1
00007dd052fdf2d0  movaps xmm4, xmm3
00007dd052fdf2d3  mulpd xmm4, xmm5
00007dd052fdf2d7  vcmppd xmm1, xmm4, xmm4, 0x03
00007dd052fdf2dc  ptest xmm1, xmm1
00007dd052fdf2e1  jnz 0x00007DD052FE14AB
00007dd052fdf2e7  lea r12, [rax+0xD0]
00007dd052fdf2ee  movups xmm1, [r13+r12*1]
00007dd052fdf2f4  vmovaps xmm3, [rsp+0xD0]
00007dd052fdf2fd  vmovaps [rsp+0x70], xmm1
00007dd052fdf303  movaps xmm5, xmm6
00007dd052fdf306  addpd xmm5, xmm3
00007dd052fdf30a  vcmppd xmm1, xmm5, xmm5, 0x03
00007dd052fdf30f  ptest xmm1, xmm1
00007dd052fdf314  jnz 0x00007DD052FE15F5
00007dd052fdf31a  vmovaps xmm1, [rsp+0x60]
00007dd052fdf320  vpermilpd xmm1, xmm1, 0x00
00007dd052fdf326  movaps xmm6, xmm9
00007dd052fdf32a  mulpd xmm6, xmm1
00007dd052fdf32e  vcmppd xmm3, xmm6, xmm6, 0x03
00007dd052fdf333  ptest xmm3, xmm3
00007dd052fdf338  jnz 0x00007DD052FE1735
00007dd052fdf33e  movaps [r15+0x260], xmm6
00007dd052fdf346  vxorps xmm1, xmm1, xmm1
00007dd052fdf34a  vpbroadcastq xmm1, xmm1
00007dd052fdf34f  movaps [r15+0x1B0], xmm1
00007dd052fdf357  vmovaps xmm1, [rsp+0x60]
00007dd052fdf35d  vpermilpd xmm1, xmm1, 0x00
00007dd052fdf363  vmovaps xmm3, [rsp+0x70]
00007dd052fdf369  vmovaps [rsp+0x70], xmm15
00007dd052fdf36f  movaps xmm9, xmm3
00007dd052fdf373  mulpd xmm9, xmm1
00007dd052fdf378  vcmppd xmm15, xmm9, xmm9, 0x03
00007dd052fdf37e  ptest xmm15, xmm15
00007dd052fdf384  jnz 0x00007DD052FE1876
00007dd052fdf38a  lea r12, [rax+0xC0]
00007dd052fdf391  movups xmm1, [r13+r12*1]
00007dd052fdf397  vmovaps xmm3, [rsp+0xC0]
00007dd052fdf3a0  vmovaps [rsp+0x80], xmm1
00007dd052fdf3a9  movaps xmm15, xmm3
00007dd052fdf3ad  addpd xmm15, xmm7
00007dd052fdf3b2  vcmppd xmm1, xmm15, xmm15, 0x03
00007dd052fdf3b8  ptest xmm1, xmm1
00007dd052fdf3bd  jnz 0x00007DD052FE19C2
00007dd052fdf3c3  vmovaps [rsp+0xC0], xmm13
00007dd052fdf3cc  vmovaps xmm1, [rsp+0xC0]
00007dd052fdf3d5  por xmm13, xmm1
00007dd052fdf3da  movaps [r15+0x270], xmm13
00007dd052fdf3e2  vmovaps xmm1, [rsp+0xB0]
00007dd052fdf3eb  vmovaps xmm7, [rsp+0xB0]
00007dd052fdf3f4  por xmm1, xmm7
00007dd052fdf3f8  movaps [r15+0x1A0], xmm1
00007dd052fdf400  vmovaps xmm1, [rsp+0x60]
00007dd052fdf406  vpermilpd xmm1, xmm1, 0x00
00007dd052fdf40c  vmovaps [rsp+0xB0], xmm1
00007dd052fdf415  vmovaps xmm1, [rsp+0x80]
00007dd052fdf41e  vmovaps [rsp+0x80], xmm15
00007dd052fdf427  vmovaps xmm15, [rsp+0xB0]
00007dd052fdf430  vmovaps [rsp+0xB0], xmm14
00007dd052fdf439  movaps xmm3, xmm1
00007dd052fdf43c  mulpd xmm3, xmm15
00007dd052fdf441  vcmppd xmm14, xmm3, xmm3, 0x03
00007dd052fdf446  ptest xmm14, xmm14
00007dd052fdf44c  jnz 0x00007DD052FE1B04
00007dd052fdf452  lea r12, [rax+0x20]
00007dd052fdf456  movups xmm1, [r13+r12*1]
00007dd052fdf45c  movaps [r15+0x110], xmm1
00007dd052fdf464  vmovaps xmm14, [rsp+0x70]
00007dd052fdf46a  vmovaps [rsp+0x70], xmm1
00007dd052fdf470  movaps xmm15, xmm14
00007dd052fdf474  addpd xmm15, xmm4
00007dd052fdf479  vcmppd xmm1, xmm15, xmm15, 0x03
00007dd052fdf47f  ptest xmm1, xmm1
00007dd052fdf484  jnz 0x00007DD052FE1C4F
00007dd052fdf48a  vmovaps xmm1, [rsp+0x60]
00007dd052fdf490  vpermilpd xmm1, xmm1, 0x00
00007dd052fdf496  movaps xmm14, xmm2
00007dd052fdf49a  mulpd xmm14, xmm1
00007dd052fdf49f  vcmppd xmm4, xmm14, xmm14, 0x03
00007dd052fdf4a5  ptest xmm4, xmm4
00007dd052fdf4aa  jnz 0x00007DD052FE1D92
00007dd052fdf4b0  vmovaps xmm4, [rsp+0x50]
00007dd052fdf4b6  movaps xmm1, xmm4
00007dd052fdf4b9  addpd xmm1, xmm9
00007dd052fdf4be  vcmppd xmm2, xmm1, xmm1, 0x03
00007dd052fdf4c3  ptest xmm2, xmm2
00007dd052fdf4c8  jnz 0x00007DD052FE1ED4
00007dd052fdf4ce  vmovaps xmm9, [rsp+0x30]
00007dd052fdf4d4  vpermilpd xmm9, xmm9, 0x00
00007dd052fdf4da  vmovaps xmm2, [rsp+0x70]
00007dd052fdf4e0  vmovaps [rsp+0x50], xmm1
00007dd052fdf4e6  movaps xmm4, xmm2
00007dd052fdf4e9  mulpd xmm4, xmm9
00007dd052fdf4ee  vcmppd xmm1, xmm4, xmm4, 0x03
00007dd052fdf4f3  ptest xmm1, xmm1
00007dd052fdf4f8  jnz 0x00007DD052FE2015
00007dd052fdf4fe  vmovaps xmm1, [rsp+0x30]
00007dd052fdf504  vpermilpd xmm1, xmm1, 0x00
00007dd052fdf50a  vmovaps xmm2, [rsp+0x90]
00007dd052fdf513  vmovaps [rsp+0x60], xmm15
00007dd052fdf519  movaps xmm9, xmm2
00007dd052fdf51d  mulpd xmm9, xmm1
00007dd052fdf522  vcmppd xmm15, xmm9, xmm9, 0x03
00007dd052fdf528  ptest xmm15, xmm15
00007dd052fdf52e  jnz 0x00007DD052FE2156
00007dd052fdf534  vmovaps xmm15, [rsp+0x80]
00007dd052fdf53d  movaps xmm1, xmm15
00007dd052fdf541  addpd xmm1, xmm6
00007dd052fdf545  vcmppd xmm2, xmm1, xmm1, 0x03
00007dd052fdf54a  ptest xmm2, xmm2
00007dd052fdf54f  jnz 0x00007DD052FE2298
00007dd052fdf555  movaps xmm15, xmm5
00007dd052fdf559  addpd xmm15, xmm3
00007dd052fdf55e  vcmppd xmm6, xmm15, xmm15, 0x03
00007dd052fdf564  ptest xmm6, xmm6
00007dd052fdf569  jnz 0x00007DD052FE23D9
00007dd052fdf56f  vmovaps xmm6, [rsp+0x30]
00007dd052fdf575  vpermilpd xmm6, xmm6, 0x00
00007dd052fdf57b  movaps xmm5, xmm8
00007dd052fdf57f  mulpd xmm5, xmm6
00007dd052fdf583  vcmppd xmm3, xmm5, xmm5, 0x03
00007dd052fdf588  ptest xmm3, xmm3
00007dd052fdf58d  jnz 0x00007DD052FE251B
00007dd052fdf593  vmovaps xmm8, [rsp+0x30]
00007dd052fdf599  vpermilpd xmm8, xmm8, 0x00
00007dd052fdf59f  movaps xmm6, xmm10
00007dd052fdf5a3  mulpd xmm6, xmm8
00007dd052fdf5a8  vcmppd xmm3, xmm6, xmm6, 0x03
00007dd052fdf5ad  ptest xmm3, xmm3
00007dd052fdf5b2  jnz 0x00007DD052FE265C
00007dd052fdf5b8  vmovaps xmm8, [rsp+0x60]
00007dd052fdf5be  movaps xmm10, xmm8
00007dd052fdf5c2  addpd xmm10, xmm14
00007dd052fdf5c7  vcmppd xmm3, xmm10, xmm10, 0x03
00007dd052fdf5cd  ptest xmm3, xmm3
00007dd052fdf5d2  jnz 0x00007DD052FE279E
00007dd052fdf5d8  vmovaps xmm8, [rsp+0x50]
00007dd052fdf5de  movaps xmm14, xmm8
00007dd052fdf5e2  addpd xmm14, xmm4
00007dd052fdf5e7  vcmppd xmm3, xmm14, xmm14, 0x03
00007dd052fdf5ed  ptest xmm3, xmm3
00007dd052fdf5f2  jnz 0x00007DD052FE28E2
00007dd052fdf5f8  vmovaps xmm8, [rsp+0x40]
00007dd052fdf5fe  vpermilpd xmm8, xmm8, 0x00
00007dd052fdf604  movaps xmm4, xmm13
00007dd052fdf608  mulpd xmm4, xmm8
00007dd052fdf60d  vcmppd xmm3, xmm4, xmm4, 0x03
00007dd052fdf612  ptest xmm3, xmm3
00007dd052fdf617  jnz 0x00007DD052FE2A25
00007dd052fdf61d  movaps xmm13, xmm15
00007dd052fdf621  addpd xmm13, xmm9
00007dd052fdf626  vcmppd xmm8, xmm13, xmm13, 0x03
00007dd052fdf62c  ptest xmm8, xmm8
00007dd052fdf632  jnz 0x00007DD052FE2B67
00007dd052fdf638  movaps xmm15, xmm1
00007dd052fdf63c  addpd xmm15, xmm5
00007dd052fdf641  vcmppd xmm9, xmm15, xmm15, 0x03
00007dd052fdf647  ptest xmm9, xmm9
00007dd052fdf64d  jnz 0x00007DD052FE2CAB
00007dd052fdf653  vmovaps [rsp+0x30], xmm11
00007dd052fdf659  vmovaps xmm1, [rsp+0x30]
00007dd052fdf65f  por xmm11, xmm1
00007dd052fdf664  movaps [r15+0x250], xmm11
00007dd052fdf66c  vmovaps [rsp+0x30], xmm12
00007dd052fdf672  vmovaps xmm1, [rsp+0x30]
00007dd052fdf678  por xmm12, xmm1
00007dd052fdf67d  movaps [r15+0x2A0], xmm12
00007dd052fdf685  vmovaps xmm1, [rsp+0xA0]
00007dd052fdf68e  vmovaps xmm11, [rsp+0xA0]
00007dd052fdf697  por xmm1, xmm11
00007dd052fdf69c  movaps [r15+0x1D0], xmm1
00007dd052fdf6a4  lea r12, [rax+0x40]
00007dd052fdf6a8  movups xmm1, [r13+r12*1]
00007dd052fdf6ae  movaps [r15+0x2C0], xmm1
00007dd052fdf6b6  vmovaps xmm11, [rsp+0x40]
00007dd052fdf6bc  vpermilpd xmm11, xmm11, 0x00
00007dd052fdf6c2  vmovaps xmm8, [rsp+0xE0]
00007dd052fdf6cb  movaps xmm9, xmm8
00007dd052fdf6cf  mulpd xmm9, xmm11
00007dd052fdf6d4  vcmppd xmm5, xmm9, xmm9, 0x03
00007dd052fdf6da  ptest xmm5, xmm5
00007dd052fdf6df  jnz 0x00007DD052FE2DF7
00007dd052fdf6e5  movaps xmm11, xmm10
00007dd052fdf6e9  addpd xmm11, xmm6
00007dd052fdf6ee  vcmppd xmm8, xmm11, xmm11, 0x03
00007dd052fdf6f4  ptest xmm8, xmm8
00007dd052fdf6fa  jnz 0x00007DD052FE2F3B
00007dd052fdf700  movaps xmm10, xmm14
00007dd052fdf704  addpd xmm10, xmm4
00007dd052fdf709  vcmppd xmm8, xmm10, xmm10, 0x03
00007dd052fdf70f  ptest xmm8, xmm8
00007dd052fdf715  jnz 0x00007DD052FE307E
00007dd052fdf71b  vmovaps xmm14, [rsp+0x40]
00007dd052fdf721  vpermilpd xmm14, xmm14, 0x00
00007dd052fdf727  movaps xmm8, xmm1
00007dd052fdf72b  mulpd xmm8, xmm14
00007dd052fdf730  vcmppd xmm6, xmm8, xmm8, 0x03
00007dd052fdf736  ptest xmm6, xmm6
00007dd052fdf73b  jnz 0x00007DD052FE31C1
00007dd052fdf741  movaps xmm1, [r15+0x2B0]
00007dd052fdf749  vmovaps xmm14, [rsp+0x40]
00007dd052fdf74f  vpermilpd xmm14, xmm14, 0x00
00007dd052fdf755  movaps xmm6, xmm1
00007dd052fdf758  mulpd xmm6, xmm14
00007dd052fdf75d  vcmppd xmm5, xmm6, xmm6, 0x03
00007dd052fdf762  ptest xmm5, xmm5
00007dd052fdf767  jnz 0x00007DD052FE3304
00007dd052fdf76d  vmovaps xmm1, [rsp+0x10]
00007dd052fdf773  vpermilpd xmm1, xmm1, 0x00
00007dd052fdf779  movaps xmm14, xmm12
00007dd052fdf77d  mulpd xmm14, xmm1
00007dd052fdf782  vcmppd xmm5, xmm14, xmm14, 0x03
00007dd052fdf788  ptest xmm5, xmm5
00007dd052fdf78d  jnz 0x00007DD052FE3445
00007dd052fdf793  movaps xmm1, xmm13
00007dd052fdf797  addpd xmm1, xmm9
00007dd052fdf79c  vcmppd xmm12, xmm1, xmm1, 0x03
00007dd052fdf7a1  ptest xmm12, xmm12
00007dd052fdf7a7  jnz 0x00007DD052FE3588
00007dd052fdf7ad  vmovaps xmm13, [rsp+0x10]
00007dd052fdf7b3  vpermilpd xmm13, xmm13, 0x00
00007dd052fdf7b9  movaps xmm12, xmm7
00007dd052fdf7bd  mulpd xmm12, xmm13
00007dd052fdf7c2  vcmppd xmm9, xmm12, xmm12, 0x03
00007dd052fdf7c8  ptest xmm9, xmm9
00007dd052fdf7ce  jnz 0x00007DD052FE36CA
00007dd052fdf7d4  movaps xmm13, xmm15
00007dd052fdf7d8  addpd xmm13, xmm8
00007dd052fdf7dd  vcmppd xmm9, xmm13, xmm13, 0x03
00007dd052fdf7e3  ptest xmm9, xmm9
00007dd052fdf7e9  jnz 0x00007DD052FE380D
00007dd052fdf7ef  movaps xmm15, [r15+0x290]
00007dd052fdf7f7  vmovaps xmm9, [rsp+0x10]
00007dd052fdf7fd  vpermilpd xmm9, xmm9, 0x00
00007dd052fdf803  movaps xmm8, xmm15
00007dd052fdf807  mulpd xmm8, xmm9
00007dd052fdf80c  vcmppd xmm7, xmm8, xmm8, 0x03
00007dd052fdf812  ptest xmm7, xmm7
00007dd052fdf817  jnz 0x00007DD052FE3951
00007dd052fdf81d  movaps xmm15, xmm11
00007dd052fdf821  addpd xmm15, xmm6
00007dd052fdf826  vcmppd xmm9, xmm15, xmm15, 0x03
00007dd052fdf82c  ptest xmm9, xmm9
00007dd052fdf832  jnz 0x00007DD052FE3A95
00007dd052fdf838  movaps xmm11, [r15+0x1E0]
00007dd052fdf840  vmovaps xmm9, [rsp+0x10]
00007dd052fdf846  vpermilpd xmm9, xmm9, 0x00
00007dd052fdf84c  movaps xmm7, xmm11
00007dd052fdf850  mulpd xmm7, xmm9
00007dd052fdf855  vcmppd xmm6, xmm7, xmm7, 0x03
00007dd052fdf85a  ptest xmm6, xmm6
00007dd052fdf85f  jnz 0x00007DD052FE3BD8
00007dd052fdf865  movaps xmm11, xmm10
00007dd052fdf869  addpd xmm11, xmm14
00007dd052fdf86e  vcmppd xmm9, xmm11, xmm11, 0x03
00007dd052fdf874  ptest xmm9, xmm9
00007dd052fdf87a  jnz 0x00007DD052FE3D1A
00007dd052fdf880  lea r12, [rax+0x70]
00007dd052fdf884  movups xmm14, [r13+r12*1]
00007dd052fdf88a  movaps [r15+0x240], xmm14
00007dd052fdf892  movaps xmm10, xmm1
00007dd052fdf896  addpd xmm10, xmm12
00007dd052fdf89b  vcmppd xmm9, xmm10, xmm10, 0x03
00007dd052fdf8a1  ptest xmm9, xmm9
00007dd052fdf8a7  jnz 0x00007DD052FE3E68
00007dd052fdf8ad  movaps [r15+0x170], xmm10
00007dd052fdf8b5  vmovaps xmm1, [rsp+0x20]
00007dd052fdf8bb  vpermilpd xmm1, xmm1, 0x00
00007dd052fdf8c1  movaps xmm12, xmm14
00007dd052fdf8c5  mulpd xmm12, xmm1
00007dd052fdf8ca  vcmppd xmm9, xmm12, xmm12, 0x03
00007dd052fdf8d0  ptest xmm9, xmm9
00007dd052fdf8d6  jnz 0x00007DD052FE3FAB
00007dd052fdf8dc  vmovaps xmm1, [rsp+0x20]
00007dd052fdf8e2  vpermilpd xmm1, xmm1, 0x00
00007dd052fdf8e8  vmovaps xmm9, [rsp+0xB0]
00007dd052fdf8f1  movaps xmm14, xmm9
00007dd052fdf8f5  mulpd xmm14, xmm1
00007dd052fdf8fa  vcmppd xmm6, xmm14, xmm14, 0x03
00007dd052fdf900  ptest xmm6, xmm6
00007dd052fdf905  jnz 0x00007DD052FE40EE
00007dd052fdf90b  movaps [r15+0x180], xmm14
00007dd052fdf913  movaps xmm1, xmm13
00007dd052fdf917  addpd xmm1, xmm8
00007dd052fdf91c  vcmppd xmm9, xmm1, xmm1, 0x03
00007dd052fdf921  ptest xmm9, xmm9
00007dd052fdf927  jnz 0x00007DD052FE4231
00007dd052fdf92d  movaps [r15+0x210], xmm1
00007dd052fdf935  movups xmm13, [r13+rax*1]
00007dd052fdf93b  lea r12, [rax+0x10]
00007dd052fdf93f  movups xmm9, [r13+r12*1]
00007dd052fdf945  movaps [r15+0x230], xmm9
00007dd052fdf94d  movaps xmm8, xmm15
00007dd052fdf951  addpd xmm8, xmm7
00007dd052fdf956  vcmppd xmm6, xmm8, xmm8, 0x03
00007dd052fdf95c  ptest xmm6, xmm6
00007dd052fdf961  jnz 0x00007DD052FE4387
00007dd052fdf967  movaps [r15+0x130], xmm8
00007dd052fdf96f  vmovaps xmm15, [rsp+0x20]
00007dd052fdf975  vpermilpd xmm15, xmm15, 0x00
00007dd052fdf97b  movaps xmm7, xmm9
00007dd052fdf97f  mulpd xmm7, xmm15
00007dd052fdf984  vcmppd xmm6, xmm7, xmm7, 0x03
00007dd052fdf989  ptest xmm6, xmm6
00007dd052fdf98e  jnz 0x00007DD052FE44CA
00007dd052fdf994  movaps [r15+0x220], xmm7
00007dd052fdf99c  vmovaps xmm15, [rsp+0x20]
00007dd052fdf9a2  vpermilpd xmm15, xmm15, 0x00
00007dd052fdf9a8  movaps xmm9, xmm13
00007dd052fdf9ac  mulpd xmm9, xmm15
00007dd052fdf9b1  vcmppd xmm6, xmm9, xmm9, 0x03
00007dd052fdf9b7  ptest xmm6, xmm6
00007dd052fdf9bc  jnz 0x00007DD052FE460C
00007dd052fdf9c2  movaps xmm15, xmm11
00007dd052fdf9c6  addpd xmm15, xmm12
00007dd052fdf9cb  vcmppd xmm13, xmm15, xmm15, 0x03
00007dd052fdf9d1  ptest xmm13, xmm13
00007dd052fdf9d7  jnz 0x00007DD052FE4750
00007dd052fdf9dd  movaps [r15+0x140], xmm15
00007dd052fdf9e5  movaps xmm13, xmm10
00007dd052fdf9e9  addpd xmm13, xmm14
00007dd052fdf9ee  vcmppd xmm12, xmm13, xmm13, 0x03
00007dd052fdf9f4  ptest xmm12, xmm12
00007dd052fdf9fa  jnz 0x00007DD052FE4894
00007dd052fdfa00  movaps [r15+0x150], xmm13
00007dd052fdfa08  movaps xmm14, xmm1
00007dd052fdfa0c  addpd xmm14, xmm7
00007dd052fdfa11  vcmppd xmm12, xmm14, xmm14, 0x03
00007dd052fdfa17  ptest xmm12, xmm12
00007dd052fdfa1d  jnz 0x00007DD052FE49D8
00007dd052fdfa23  movaps [r15+0x160], xmm14
00007dd052fdfa2b  movaps xmm1, xmm8
00007dd052fdfa2f  addpd xmm1, xmm9
00007dd052fdfa34  vcmppd xmm12, xmm1, xmm1, 0x03
00007dd052fdfa39  ptest xmm12, xmm12
00007dd052fdfa3f  jnz 0x00007DD052FE4B1A
00007dd052fdfa45  movaps [r15+0x120], xmm1
00007dd052fdfa4d  movups [r13+r14*1], xmm15
00007dd052fdfa53  lea rax, [r14+0x10]
00007dd052fdfa57  movups [r13+rax*1], xmm13
00007dd052fdfa5d  lea rax, [r14+0x20]
00007dd052fdfa61  movups [r13+rax*1], xmm14
00007dd052fdfa67  lea rax, [r14+0x30]
00007dd052fdfa6b  movups [r13+rax*1], xmm1
00007dd052fdfa71  mov eax, [r15+0x108]
00007dd052fdfa78  sahf
00007dd052fdfa79  jnz 0x00007DD052FDFAAB
00007dd052fdfa7b  cmp dword ptr [r15+0x318], 0x00
00007dd052fdfa83  jz 0x00007DD052FDEAE0
00007dd052fdfa89  nop [rax+rax*1], ax
00007dd052fdfa92  nop [rax+rax*1], eax
00007dd052fdfa9a  mov eax, 0x4106D0
00007dd052fdfa9f  mov [r15+0x100], rax
00007dd052fdfaa6  jmp 0x00007DD052DFE110
00007dd052fdfaab  cmp dword ptr [r15+0x318], 0x00
00007dd052fdfab3  jz 0x00007DD052FD89C0
00007dd052fdfab9  nop [rax+rax*1], ax
00007dd052fdfac2  nop [rax+rax*1], eax
00007dd052fdfaca  mov eax, 0x410504
00007dd052fdfacf  mov [r15+0x100], rax
00007dd052fdfad6  jmp 0x00007DD052DFE110
00007dd052fdfadb  int3
00007dd052fdfadc  call 0x00007DD052EE27E0
00007dd052fdfae1  jmp 0x00007DD052FDEBBF
00007dd052fdfae6  call 0x00007DD052EE1570
00007dd052fdfaeb  jmp 0x00007DD052FDEBC8
00007dd052fdfaf0  call 0x00007DD052EE27E0
00007dd052fdfaf5  jmp 0x00007DD052FDEC24
00007dd052fdfafa  call 0x00007DD052EE1570
00007dd052fdfaff  jmp 0x00007DD052FDEC2D
00007dd052fdfb04  call 0x00007DD052EE27E0
00007dd052fdfb09  jmp 0x00007DD052FDEC70
00007dd052fdfb0e  call 0x00007DD052EE1570
00007dd052fdfb13  jmp 0x00007DD052FDEC79
00007dd052fdfb18  call 0x00007DD052E0DC20
00007dd052fdfb1d  jmp 0x00007DD052FDECB8
00007dd052fdfb22  call 0x00007DD052ED59C0
00007dd052fdfb27  jmp 0x00007DD052FDECCB
00007dd052fdfb2c  call 0x00007DD052EE0E30
00007dd052fdfb31  jmp 0x00007DD052FDECE9
00007dd052fdfb36  call 0x00007DD052EDFBC0
00007dd052fdfb3b  jmp 0x00007DD052FDECF3
00007dd052fdfb40  call 0x00007DD052EDE950
00007dd052fdfb45  jmp 0x00007DD052FDECFD
00007dd052fdfb4a  sub rsp, 0x08
00007dd052fdfb4e  push rax
00007dd052fdfb4f  push rcx
00007dd052fdfb50  push rdx
00007dd052fdfb51  push rdi
00007dd052fdfb52  push rsi
00007dd052fdfb53  push r8
00007dd052fdfb55  push r9
00007dd052fdfb57  push r10
00007dd052fdfb59  push r11
00007dd052fdfb5b  sub rsp, 0xF0
00007dd052fdfb62  vmovaps [rsp], xmm0
00007dd052fdfb67  vmovaps [rsp+0x10], xmm1
00007dd052fdfb6d  vmovaps [rsp+0x20], xmm2
00007dd052fdfb73  vmovaps [rsp+0x30], xmm3
00007dd052fdfb79  vmovaps [rsp+0x40], xmm4
00007dd052fdfb7f  vmovaps [rsp+0x50], xmm5
00007dd052fdfb85  vmovaps [rsp+0x60], xmm6
00007dd052fdfb8b  vmovaps [rsp+0x70], xmm7
00007dd052fdfb91  vmovaps [rsp+0x80], xmm9
00007dd052fdfb9a  vmovaps [rsp+0x90], xmm10
00007dd052fdfba3  vmovaps [rsp+0xA0], xmm11
00007dd052fdfbac  vmovaps [rsp+0xB0], xmm12
00007dd052fdfbb5  vmovaps [rsp+0xC0], xmm13
00007dd052fdfbbe  vmovaps [rsp+0xD0], xmm14
00007dd052fdfbc7  vmovaps [rsp+0xE0], xmm15
00007dd052fdfbd0  sub rsp, 0x30
00007dd052fdfbd4  movaps [rsp], xmm8
00007dd052fdfbd9  movaps [rsp+0x10], xmm12
00007dd052fdfbdf  movaps [rsp+0x20], xmm15
00007dd052fdfbe5  lea rdi, [rsp]
00007dd052fdfbe9  mov esi, 0x00
00007dd052fdfbee  mov rax, 0x61D0404B9530
00007dd052fdfbf8  call rax
00007dd052fdfbfa  movaps xmm8, [rsp]
00007dd052fdfbff  add rsp, 0x30
00007dd052fdfc03  vmovaps xmm0, [rsp]
00007dd052fdfc08  vmovaps xmm1, [rsp+0x10]
00007dd052fdfc0e  vmovaps xmm2, [rsp+0x20]
00007dd052fdfc14  vmovaps xmm3, [rsp+0x30]
00007dd052fdfc1a  vmovaps xmm4, [rsp+0x40]
00007dd052fdfc20  vmovaps xmm5, [rsp+0x50]
00007dd052fdfc26  vmovaps xmm6, [rsp+0x60]
00007dd052fdfc2c  vmovaps xmm7, [rsp+0x70]
00007dd052fdfc32  vmovaps xmm9, [rsp+0x80]
00007dd052fdfc3b  vmovaps xmm10, [rsp+0x90]
00007dd052fdfc44  vmovaps xmm11, [rsp+0xA0]
00007dd052fdfc4d  vmovaps xmm12, [rsp+0xB0]
00007dd052fdfc56  vmovaps xmm13, [rsp+0xC0]
00007dd052fdfc5f  vmovaps xmm14, [rsp+0xD0]
00007dd052fdfc68  vmovaps xmm15, [rsp+0xE0]
00007dd052fdfc71  add rsp, 0xF0
00007dd052fdfc78  pop r11
00007dd052fdfc7a  pop r10
00007dd052fdfc7c  pop r9
00007dd052fdfc7e  pop r8
00007dd052fdfc80  pop rsi
00007dd052fdfc81  pop rdi
00007dd052fdfc82  pop rdx
00007dd052fdfc83  pop rcx
00007dd052fdfc84  pop rax
00007dd052fdfc85  add rsp, 0x08
00007dd052fdfc89  jmp 0x00007DD052FDED27
00007dd052fdfc8e  sub rsp, 0x08
00007dd052fdfc92  push rax
00007dd052fdfc93  push rcx
00007dd052fdfc94  push rdx
00007dd052fdfc95  push rdi
00007dd052fdfc96  push rsi
00007dd052fdfc97  push r8
00007dd052fdfc99  push r9
00007dd052fdfc9b  push r10
00007dd052fdfc9d  push r11
00007dd052fdfc9f  sub rsp, 0xF0
00007dd052fdfca6  vmovaps [rsp], xmm0
00007dd052fdfcab  vmovaps [rsp+0x10], xmm1
00007dd052fdfcb1  vmovaps [rsp+0x20], xmm2
00007dd052fdfcb7  vmovaps [rsp+0x30], xmm3
00007dd052fdfcbd  vmovaps [rsp+0x40], xmm4
00007dd052fdfcc3  vmovaps [rsp+0x50], xmm5
00007dd052fdfcc9  vmovaps [rsp+0x60], xmm6
00007dd052fdfccf  vmovaps [rsp+0x70], xmm8
00007dd052fdfcd5  vmovaps [rsp+0x80], xmm9
00007dd052fdfcde  vmovaps [rsp+0x90], xmm10
00007dd052fdfce7  vmovaps [rsp+0xA0], xmm11
00007dd052fdfcf0  vmovaps [rsp+0xB0], xmm12
00007dd052fdfcf9  vmovaps [rsp+0xC0], xmm13
00007dd052fdfd02  vmovaps [rsp+0xD0], xmm14
00007dd052fdfd0b  vmovaps [rsp+0xE0], xmm15
00007dd052fdfd14  sub rsp, 0x30
00007dd052fdfd18  movaps [rsp], xmm7
00007dd052fdfd1c  movaps [rsp+0x10], xmm9
00007dd052fdfd22  movaps [rsp+0x20], xmm15
00007dd052fdfd28  lea rdi, [rsp]
00007dd052fdfd2c  mov esi, 0x00
00007dd052fdfd31  mov rax, 0x61D0404B9530
00007dd052fdfd3b  call rax
00007dd052fdfd3d  movaps xmm7, [rsp]
00007dd052fdfd41  add rsp, 0x30
00007dd052fdfd45  vmovaps xmm0, [rsp]
00007dd052fdfd4a  vmovaps xmm1, [rsp+0x10]
00007dd052fdfd50  vmovaps xmm2, [rsp+0x20]
00007dd052fdfd56  vmovaps xmm3, [rsp+0x30]
00007dd052fdfd5c  vmovaps xmm4, [rsp+0x40]
00007dd052fdfd62  vmovaps xmm5, [rsp+0x50]
00007dd052fdfd68  vmovaps xmm6, [rsp+0x60]
00007dd052fdfd6e  vmovaps xmm8, [rsp+0x70]
00007dd052fdfd74  vmovaps xmm9, [rsp+0x80]
00007dd052fdfd7d  vmovaps xmm10, [rsp+0x90]
00007dd052fdfd86  vmovaps xmm11, [rsp+0xA0]
00007dd052fdfd8f  vmovaps xmm12, [rsp+0xB0]
00007dd052fdfd98  vmovaps xmm13, [rsp+0xC0]
00007dd052fdfda1  vmovaps xmm14, [rsp+0xD0]
00007dd052fdfdaa  vmovaps xmm15, [rsp+0xE0]
00007dd052fdfdb3  add rsp, 0xF0
00007dd052fdfdba  pop r11
00007dd052fdfdbc  pop r10
00007dd052fdfdbe  pop r9
00007dd052fdfdc0  pop r8
00007dd052fdfdc2  pop rsi
00007dd052fdfdc3  pop rdi
00007dd052fdfdc4  pop rdx
00007dd052fdfdc5  pop rcx
00007dd052fdfdc6  pop rax
00007dd052fdfdc7  add rsp, 0x08
00007dd052fdfdcb  jmp 0x00007DD052FDED55
00007dd052fdfdd0  sub rsp, 0x08
00007dd052fdfdd4  push rax
00007dd052fdfdd5  push rcx
00007dd052fdfdd6  push rdx
00007dd052fdfdd7  push rdi
00007dd052fdfdd8  push rsi
00007dd052fdfdd9  push r8
00007dd052fdfddb  push r9
00007dd052fdfddd  push r10
00007dd052fdfddf  push r11
00007dd052fdfde1  sub rsp, 0xF0
00007dd052fdfde8  vmovaps [rsp], xmm0
00007dd052fdfded  vmovaps [rsp+0x10], xmm1
00007dd052fdfdf3  vmovaps [rsp+0x20], xmm2
00007dd052fdfdf9  vmovaps [rsp+0x30], xmm3
00007dd052fdfdff  vmovaps [rsp+0x40], xmm4
00007dd052fdfe05  vmovaps [rsp+0x50], xmm5
00007dd052fdfe0b  vmovaps [rsp+0x60], xmm6
00007dd052fdfe11  vmovaps [rsp+0x70], xmm7
00007dd052fdfe17  vmovaps [rsp+0x80], xmm8
00007dd052fdfe20  vmovaps [rsp+0x90], xmm10
00007dd052fdfe29  vmovaps [rsp+0xA0], xmm11
00007dd052fdfe32  vmovaps [rsp+0xB0], xmm12
00007dd052fdfe3b  vmovaps [rsp+0xC0], xmm13
00007dd052fdfe44  vmovaps [rsp+0xD0], xmm14
00007dd052fdfe4d  vmovaps [rsp+0xE0], xmm15
00007dd052fdfe56  sub rsp, 0x30
00007dd052fdfe5a  movaps [rsp], xmm9
00007dd052fdfe5f  movaps [rsp+0x10], xmm12
00007dd052fdfe65  movaps [rsp+0x20], xmm10
00007dd052fdfe6b  lea rdi, [rsp]
00007dd052fdfe6f  mov esi, 0x00
00007dd052fdfe74  mov rax, 0x61D0404B9530
00007dd052fdfe7e  call rax
00007dd052fdfe80  movaps xmm9, [rsp]
00007dd052fdfe85  add rsp, 0x30
00007dd052fdfe89  vmovaps xmm0, [rsp]
00007dd052fdfe8e  vmovaps xmm1, [rsp+0x10]
00007dd052fdfe94  vmovaps xmm2, [rsp+0x20]
00007dd052fdfe9a  vmovaps xmm3, [rsp+0x30]
00007dd052fdfea0  vmovaps xmm4, [rsp+0x40]
00007dd052fdfea6  vmovaps xmm5, [rsp+0x50]
00007dd052fdfeac  vmovaps xmm6, [rsp+0x60]
00007dd052fdfeb2  vmovaps xmm7, [rsp+0x70]
00007dd052fdfeb8  vmovaps xmm8, [rsp+0x80]
00007dd052fdfec1  vmovaps xmm10, [rsp+0x90]
00007dd052fdfeca  vmovaps xmm11, [rsp+0xA0]
00007dd052fdfed3  vmovaps xmm12, [rsp+0xB0]
00007dd052fdfedc  vmovaps xmm13, [rsp+0xC0]
00007dd052fdfee5  vmovaps xmm14, [rsp+0xD0]
00007dd052fdfeee  vmovaps xmm15, [rsp+0xE0]
00007dd052fdfef7  add rsp, 0xF0
00007dd052fdfefe  pop r11
00007dd052fdff00  pop r10
00007dd052fdff02  pop r9
00007dd052fdff04  pop r8
00007dd052fdff06  pop rsi
00007dd052fdff07  pop rdi
00007dd052fdff08  pop rdx
00007dd052fdff09  pop rcx
00007dd052fdff0a  pop rax
00007dd052fdff0b  add rsp, 0x08
00007dd052fdff0f  jmp 0x00007DD052FDED79
00007dd052fdff14  sub rsp, 0x08
00007dd052fdff18  push rax
00007dd052fdff19  push rcx
00007dd052fdff1a  push rdx
00007dd052fdff1b  push rdi
00007dd052fdff1c  push rsi
00007dd052fdff1d  push r8
00007dd052fdff1f  push r9
00007dd052fdff21  push r10
00007dd052fdff23  push r11
00007dd052fdff25  sub rsp, 0xF0
00007dd052fdff2c  vmovaps [rsp], xmm0
00007dd052fdff31  vmovaps [rsp+0x10], xmm1
00007dd052fdff37  vmovaps [rsp+0x20], xmm2
00007dd052fdff3d  vmovaps [rsp+0x30], xmm3
00007dd052fdff43  vmovaps [rsp+0x40], xmm4
00007dd052fdff49  vmovaps [rsp+0x50], xmm5
00007dd052fdff4f  vmovaps [rsp+0x60], xmm6
00007dd052fdff55  vmovaps [rsp+0x70], xmm7
00007dd052fdff5b  vmovaps [rsp+0x80], xmm8
00007dd052fdff64  vmovaps [rsp+0x90], xmm9
00007dd052fdff6d  vmovaps [rsp+0xA0], xmm11
00007dd052fdff76  vmovaps [rsp+0xB0], xmm12
00007dd052fdff7f  vmovaps [rsp+0xC0], xmm13
00007dd052fdff88  vmovaps [rsp+0xD0], xmm14
00007dd052fdff91  vmovaps [rsp+0xE0], xmm15
00007dd052fdff9a  sub rsp, 0x30
00007dd052fdff9e  movaps [rsp], xmm10
00007dd052fdffa3  movaps [rsp+0x10], xmm12
00007dd052fdffa9  movaps [rsp+0x20], xmm11
00007dd052fdffaf  lea rdi, [rsp]
00007dd052fdffb3  mov esi, 0x00
00007dd052fdffb8  mov rax, 0x61D0404B9530
00007dd052fdffc2  call rax
00007dd052fdffc4  movaps xmm10, [rsp]
00007dd052fdffc9  add rsp, 0x30
00007dd052fdffcd  vmovaps xmm0, [rsp]
00007dd052fdffd2  vmovaps xmm1, [rsp+0x10]
00007dd052fdffd8  vmovaps xmm2, [rsp+0x20]
00007dd052fdffde  vmovaps xmm3, [rsp+0x30]
00007dd052fdffe4  vmovaps xmm4, [rsp+0x40]
00007dd052fdffea  vmovaps xmm5, [rsp+0x50]
00007dd052fdfff0  vmovaps xmm6, [rsp+0x60]
00007dd052fdfff6  vmovaps xmm7, [rsp+0x70]
00007dd052fdfffc  vmovaps xmm8, [rsp+0x80]
00007dd052fe0005  vmovaps xmm9, [rsp+0x90]
00007dd052fe000e  vmovaps xmm11, [rsp+0xA0]
00007dd052fe0017  vmovaps xmm12, [rsp+0xB0]
00007dd052fe0020  vmovaps xmm13, [rsp+0xC0]
00007dd052fe0029  vmovaps xmm14, [rsp+0xD0]
00007dd052fe0032  vmovaps xmm15, [rsp+0xE0]
00007dd052fe003b  add rsp, 0xF0
00007dd052fe0042  pop r11
00007dd052fe0044  pop r10
00007dd052fe0046  pop r9
00007dd052fe0048  pop r8
00007dd052fe004a  pop rsi
00007dd052fe004b  pop rdi
00007dd052fe004c  pop rdx
00007dd052fe004d  pop rcx
00007dd052fe004e  pop rax
00007dd052fe004f  add rsp, 0x08
00007dd052fe0053  jmp 0x00007DD052FDED93
00007dd052fe0058  sub rsp, 0x08
00007dd052fe005c  push rax
00007dd052fe005d  push rcx
00007dd052fe005e  push rdx
00007dd052fe005f  push rdi
00007dd052fe0060  push rsi
00007dd052fe0061  push r8
00007dd052fe0063  push r9
00007dd052fe0065  push r10
00007dd052fe0067  push r11
00007dd052fe0069  sub rsp, 0xF0
00007dd052fe0070  vmovaps [rsp], xmm0
00007dd052fe0075  vmovaps [rsp+0x10], xmm1
00007dd052fe007b  vmovaps [rsp+0x20], xmm2
00007dd052fe0081  vmovaps [rsp+0x30], xmm3
00007dd052fe0087  vmovaps [rsp+0x40], xmm4
00007dd052fe008d  vmovaps [rsp+0x50], xmm5
00007dd052fe0093  vmovaps [rsp+0x60], xmm7
00007dd052fe0099  vmovaps [rsp+0x70], xmm8
00007dd052fe009f  vmovaps [rsp+0x80], xmm9
00007dd052fe00a8  vmovaps [rsp+0x90], xmm10
00007dd052fe00b1  vmovaps [rsp+0xA0], xmm11
00007dd052fe00ba  vmovaps [rsp+0xB0], xmm12
00007dd052fe00c3  vmovaps [rsp+0xC0], xmm13
00007dd052fe00cc  vmovaps [rsp+0xD0], xmm14
00007dd052fe00d5  vmovaps [rsp+0xE0], xmm15
00007dd052fe00de  sub rsp, 0x30
00007dd052fe00e2  movaps [rsp], xmm6
00007dd052fe00e6  movaps [rsp+0x10], xmm12
00007dd052fe00ec  movaps [rsp+0x20], xmm11
00007dd052fe00f2  lea rdi, [rsp]
00007dd052fe00f6  mov esi, 0x00
00007dd052fe00fb  mov rax, 0x61D0404B9530
00007dd052fe0105  call rax
00007dd052fe0107  movaps xmm6, [rsp]
00007dd052fe010b  add rsp, 0x30
00007dd052fe010f  vmovaps xmm0, [rsp]
00007dd052fe0114  vmovaps xmm1, [rsp+0x10]
00007dd052fe011a  vmovaps xmm2, [rsp+0x20]
00007dd052fe0120  vmovaps xmm3, [rsp+0x30]
00007dd052fe0126  vmovaps xmm4, [rsp+0x40]
00007dd052fe012c  vmovaps xmm5, [rsp+0x50]
00007dd052fe0132  vmovaps xmm7, [rsp+0x60]
00007dd052fe0138  vmovaps xmm8, [rsp+0x70]
00007dd052fe013e  vmovaps xmm9, [rsp+0x80]
00007dd052fe0147  vmovaps xmm10, [rsp+0x90]
00007dd052fe0150  vmovaps xmm11, [rsp+0xA0]
00007dd052fe0159  vmovaps xmm12, [rsp+0xB0]
00007dd052fe0162  vmovaps xmm13, [rsp+0xC0]
00007dd052fe016b  vmovaps xmm14, [rsp+0xD0]
00007dd052fe0174  vmovaps xmm15, [rsp+0xE0]
00007dd052fe017d  add rsp, 0xF0
00007dd052fe0184  pop r11
00007dd052fe0186  pop r10
00007dd052fe0188  pop r9
00007dd052fe018a  pop r8
00007dd052fe018c  pop rsi
00007dd052fe018d  pop rdi
00007dd052fe018e  pop rdx
00007dd052fe018f  pop rcx
00007dd052fe0190  pop rax
00007dd052fe0191  add rsp, 0x08
00007dd052fe0195  jmp 0x00007DD052FDEDB4
00007dd052fe019a  sub rsp, 0x08
00007dd052fe019e  push rax
00007dd052fe019f  push rcx
00007dd052fe01a0  push rdx
00007dd052fe01a1  push rdi
00007dd052fe01a2  push rsi
00007dd052fe01a3  push r8
00007dd052fe01a5  push r9
00007dd052fe01a7  push r10
00007dd052fe01a9  push r11
00007dd052fe01ab  sub rsp, 0xF0
00007dd052fe01b2  vmovaps [rsp], xmm0
00007dd052fe01b7  vmovaps [rsp+0x10], xmm1
00007dd052fe01bd  vmovaps [rsp+0x20], xmm2
00007dd052fe01c3  vmovaps [rsp+0x30], xmm4
00007dd052fe01c9  vmovaps [rsp+0x40], xmm5
00007dd052fe01cf  vmovaps [rsp+0x50], xmm6
00007dd052fe01d5  vmovaps [rsp+0x60], xmm7
00007dd052fe01db  vmovaps [rsp+0x70], xmm8
00007dd052fe01e1  vmovaps [rsp+0x80], xmm9
00007dd052fe01ea  vmovaps [rsp+0x90], xmm10
00007dd052fe01f3  vmovaps [rsp+0xA0], xmm11
00007dd052fe01fc  vmovaps [rsp+0xB0], xmm12
00007dd052fe0205  vmovaps [rsp+0xC0], xmm13
00007dd052fe020e  vmovaps [rsp+0xD0], xmm14
00007dd052fe0217  vmovaps [rsp+0xE0], xmm15
00007dd052fe0220  sub rsp, 0x30
00007dd052fe0224  movaps [rsp], xmm3
00007dd052fe0228  movaps [rsp+0x10], xmm5
00007dd052fe022d  movaps [rsp+0x20], xmm4
00007dd052fe0232  lea rdi, [rsp]
00007dd052fe0236  mov esi, 0x00
00007dd052fe023b  mov rax, 0x61D0404B9530
00007dd052fe0245  call rax
00007dd052fe0247  movaps xmm3, [rsp]
00007dd052fe024b  add rsp, 0x30
00007dd052fe024f  vmovaps xmm0, [rsp]
00007dd052fe0254  vmovaps xmm1, [rsp+0x10]
00007dd052fe025a  vmovaps xmm2, [rsp+0x20]
00007dd052fe0260  vmovaps xmm4, [rsp+0x30]
00007dd052fe0266  vmovaps xmm5, [rsp+0x40]
00007dd052fe026c  vmovaps xmm6, [rsp+0x50]
00007dd052fe0272  vmovaps xmm7, [rsp+0x60]
00007dd052fe0278  vmovaps xmm8, [rsp+0x70]
00007dd052fe027e  vmovaps xmm9, [rsp+0x80]
00007dd052fe0287  vmovaps xmm10, [rsp+0x90]
00007dd052fe0290  vmovaps xmm11, [rsp+0xA0]
00007dd052fe0299  vmovaps xmm12, [rsp+0xB0]
00007dd052fe02a2  vmovaps xmm13, [rsp+0xC0]
00007dd052fe02ab  vmovaps xmm14, [rsp+0xD0]
00007dd052fe02b4  vmovaps xmm15, [rsp+0xE0]
00007dd052fe02bd  add rsp, 0xF0
00007dd052fe02c4  pop r11
00007dd052fe02c6  pop r10
00007dd052fe02c8  pop r9
00007dd052fe02ca  pop r8
00007dd052fe02cc  pop rsi
00007dd052fe02cd  pop rdi
00007dd052fe02ce  pop rdx
00007dd052fe02cf  pop rcx
00007dd052fe02d0  pop rax
00007dd052fe02d1  add rsp, 0x08
00007dd052fe02d5  jmp 0x00007DD052FDEE15
00007dd052fe02da  sub rsp, 0x08
00007dd052fe02de  push rax
00007dd052fe02df  push rcx
00007dd052fe02e0  push rdx
00007dd052fe02e1  push rdi
00007dd052fe02e2  push rsi
00007dd052fe02e3  push r8
00007dd052fe02e5  push r9
00007dd052fe02e7  push r10
00007dd052fe02e9  push r11
00007dd052fe02eb  sub rsp, 0xF0
00007dd052fe02f2  vmovaps [rsp], xmm0
00007dd052fe02f7  vmovaps [rsp+0x10], xmm1
00007dd052fe02fd  vmovaps [rsp+0x20], xmm2
00007dd052fe0303  vmovaps [rsp+0x30], xmm3
00007dd052fe0309  vmovaps [rsp+0x40], xmm4
00007dd052fe030f  vmovaps [rsp+0x50], xmm6
00007dd052fe0315  vmovaps [rsp+0x60], xmm7
00007dd052fe031b  vmovaps [rsp+0x70], xmm8
00007dd052fe0321  vmovaps [rsp+0x80], xmm9
00007dd052fe032a  vmovaps [rsp+0x90], xmm10
00007dd052fe0333  vmovaps [rsp+0xA0], xmm11
00007dd052fe033c  vmovaps [rsp+0xB0], xmm12
00007dd052fe0345  vmovaps [rsp+0xC0], xmm13
00007dd052fe034e  vmovaps [rsp+0xD0], xmm14
00007dd052fe0357  vmovaps [rsp+0xE0], xmm15
00007dd052fe0360  sub rsp, 0x30
00007dd052fe0364  movaps [rsp], xmm5
00007dd052fe0368  movaps [rsp+0x10], xmm8
00007dd052fe036e  movaps [rsp+0x20], xmm15
00007dd052fe0374  lea rdi, [rsp]
00007dd052fe0378  mov esi, 0x00
00007dd052fe037d  mov rax, 0x61D0404B9530
00007dd052fe0387  call rax
00007dd052fe0389  movaps xmm5, [rsp]
00007dd052fe038d  add rsp, 0x30
00007dd052fe0391  vmovaps xmm0, [rsp]
00007dd052fe0396  vmovaps xmm1, [rsp+0x10]
00007dd052fe039c  vmovaps xmm2, [rsp+0x20]
00007dd052fe03a2  vmovaps xmm3, [rsp+0x30]
00007dd052fe03a8  vmovaps xmm4, [rsp+0x40]
00007dd052fe03ae  vmovaps xmm6, [rsp+0x50]
00007dd052fe03b4  vmovaps xmm7, [rsp+0x60]
00007dd052fe03ba  vmovaps xmm8, [rsp+0x70]
00007dd052fe03c0  vmovaps xmm9, [rsp+0x80]
00007dd052fe03c9  vmovaps xmm10, [rsp+0x90]
00007dd052fe03d2  vmovaps xmm11, [rsp+0xA0]
00007dd052fe03db  vmovaps xmm12, [rsp+0xB0]
00007dd052fe03e4  vmovaps xmm13, [rsp+0xC0]
00007dd052fe03ed  vmovaps xmm14, [rsp+0xD0]
00007dd052fe03f6  vmovaps xmm15, [rsp+0xE0]
00007dd052fe03ff  add rsp, 0xF0
00007dd052fe0406  pop r11
00007dd052fe0408  pop r10
00007dd052fe040a  pop r9
00007dd052fe040c  pop r8
00007dd052fe040e  pop rsi
00007dd052fe040f  pop rdi
00007dd052fe0410  pop rdx
00007dd052fe0411  pop rcx
00007dd052fe0412  pop rax
00007dd052fe0413  add rsp, 0x08
00007dd052fe0417  jmp 0x00007DD052FDEE53
00007dd052fe041c  sub rsp, 0x08
00007dd052fe0420  push rax
00007dd052fe0421  push rcx
00007dd052fe0422  push rdx
00007dd052fe0423  push rdi
00007dd052fe0424  push rsi
00007dd052fe0425  push r8
00007dd052fe0427  push r9
00007dd052fe0429  push r10
00007dd052fe042b  push r11
00007dd052fe042d  sub rsp, 0xF0
00007dd052fe0434  vmovaps [rsp], xmm0
00007dd052fe0439  vmovaps [rsp+0x10], xmm1
00007dd052fe043f  vmovaps [rsp+0x20], xmm2
00007dd052fe0445  vmovaps [rsp+0x30], xmm3
00007dd052fe044b  vmovaps [rsp+0x40], xmm5
00007dd052fe0451  vmovaps [rsp+0x50], xmm6
00007dd052fe0457  vmovaps [rsp+0x60], xmm7
00007dd052fe045d  vmovaps [rsp+0x70], xmm8
00007dd052fe0463  vmovaps [rsp+0x80], xmm9
00007dd052fe046c  vmovaps [rsp+0x90], xmm10
00007dd052fe0475  vmovaps [rsp+0xA0], xmm11
00007dd052fe047e  vmovaps [rsp+0xB0], xmm12
00007dd052fe0487  vmovaps [rsp+0xC0], xmm13
00007dd052fe0490  vmovaps [rsp+0xD0], xmm14
00007dd052fe0499  vmovaps [rsp+0xE0], xmm15
00007dd052fe04a2  sub rsp, 0x30
00007dd052fe04a6  movaps [rsp], xmm4
00007dd052fe04aa  movaps [rsp+0x10], xmm9
00007dd052fe04b0  movaps [rsp+0x20], xmm8
00007dd052fe04b6  lea rdi, [rsp]
00007dd052fe04ba  mov esi, 0x00
00007dd052fe04bf  mov rax, 0x61D0404B9530
00007dd052fe04c9  call rax
00007dd052fe04cb  movaps xmm4, [rsp]
00007dd052fe04cf  add rsp, 0x30
00007dd052fe04d3  vmovaps xmm0, [rsp]
00007dd052fe04d8  vmovaps xmm1, [rsp+0x10]
00007dd052fe04de  vmovaps xmm2, [rsp+0x20]
00007dd052fe04e4  vmovaps xmm3, [rsp+0x30]
00007dd052fe04ea  vmovaps xmm5, [rsp+0x40]
00007dd052fe04f0  vmovaps xmm6, [rsp+0x50]
00007dd052fe04f6  vmovaps xmm7, [rsp+0x60]
00007dd052fe04fc  vmovaps xmm8, [rsp+0x70]
00007dd052fe0502  vmovaps xmm9, [rsp+0x80]
00007dd052fe050b  vmovaps xmm10, [rsp+0x90]
00007dd052fe0514  vmovaps xmm11, [rsp+0xA0]
00007dd052fe051d  vmovaps xmm12, [rsp+0xB0]
00007dd052fe0526  vmovaps xmm13, [rsp+0xC0]
00007dd052fe052f  vmovaps xmm14, [rsp+0xD0]
00007dd052fe0538  vmovaps xmm15, [rsp+0xE0]
00007dd052fe0541  add rsp, 0xF0
00007dd052fe0548  pop r11
00007dd052fe054a  pop r10
00007dd052fe054c  pop r9
00007dd052fe054e  pop r8
00007dd052fe0550  pop rsi
00007dd052fe0551  pop rdi
00007dd052fe0552  pop rdx
00007dd052fe0553  pop rcx
00007dd052fe0554  pop rax
00007dd052fe0555  add rsp, 0x08
00007dd052fe0559  jmp 0x00007DD052FDEE74
00007dd052fe055e  sub rsp, 0x08
00007dd052fe0562  push rax
00007dd052fe0563  push rcx
00007dd052fe0564  push rdx
00007dd052fe0565  push rdi
00007dd052fe0566  push rsi
00007dd052fe0567  push r8
00007dd052fe0569  push r9
00007dd052fe056b  push r10
00007dd052fe056d  push r11
00007dd052fe056f  sub rsp, 0xF0
00007dd052fe0576  vmovaps [rsp], xmm0
00007dd052fe057b  vmovaps [rsp+0x10], xmm1
00007dd052fe0581  vmovaps [rsp+0x20], xmm2
00007dd052fe0587  vmovaps [rsp+0x30], xmm3
00007dd052fe058d  vmovaps [rsp+0x40], xmm4
00007dd052fe0593  vmovaps [rsp+0x50], xmm5
00007dd052fe0599  vmovaps [rsp+0x60], xmm6
00007dd052fe059f  vmovaps [rsp+0x70], xmm7
00007dd052fe05a5  vmovaps [rsp+0x80], xmm8
00007dd052fe05ae  vmovaps [rsp+0x90], xmm10
00007dd052fe05b7  vmovaps [rsp+0xA0], xmm11
00007dd052fe05c0  vmovaps [rsp+0xB0], xmm12
00007dd052fe05c9  vmovaps [rsp+0xC0], xmm13
00007dd052fe05d2  vmovaps [rsp+0xD0], xmm14
00007dd052fe05db  vmovaps [rsp+0xE0], xmm15
00007dd052fe05e4  sub rsp, 0x30
00007dd052fe05e8  movaps [rsp], xmm9
00007dd052fe05ed  movaps [rsp+0x10], xmm10
00007dd052fe05f3  movaps [rsp+0x20], xmm8
00007dd052fe05f9  lea rdi, [rsp]
00007dd052fe05fd  mov esi, 0x00
00007dd052fe0602  mov rax, 0x61D0404B9530
00007dd052fe060c  call rax
00007dd052fe060e  movaps xmm9, [rsp]
00007dd052fe0613  add rsp, 0x30
00007dd052fe0617  vmovaps xmm0, [rsp]
00007dd052fe061c  vmovaps xmm1, [rsp+0x10]
00007dd052fe0622  vmovaps xmm2, [rsp+0x20]
00007dd052fe0628  vmovaps xmm3, [rsp+0x30]
00007dd052fe062e  vmovaps xmm4, [rsp+0x40]
00007dd052fe0634  vmovaps xmm5, [rsp+0x50]
00007dd052fe063a  vmovaps xmm6, [rsp+0x60]
00007dd052fe0640  vmovaps xmm7, [rsp+0x70]
00007dd052fe0646  vmovaps xmm8, [rsp+0x80]
00007dd052fe064f  vmovaps xmm10, [rsp+0x90]
00007dd052fe0658  vmovaps xmm11, [rsp+0xA0]
00007dd052fe0661  vmovaps xmm12, [rsp+0xB0]
00007dd052fe066a  vmovaps xmm13, [rsp+0xC0]
00007dd052fe0673  vmovaps xmm14, [rsp+0xD0]
00007dd052fe067c  vmovaps xmm15, [rsp+0xE0]
00007dd052fe0685  add rsp, 0xF0
00007dd052fe068c  pop r11
00007dd052fe068e  pop r10
00007dd052fe0690  pop r9
00007dd052fe0692  pop r8
00007dd052fe0694  pop rsi
00007dd052fe0695  pop rdi
00007dd052fe0696  pop rdx
00007dd052fe0697  pop rcx
00007dd052fe0698  pop rax
00007dd052fe0699  add rsp, 0x08
00007dd052fe069d  jmp 0x00007DD052FDEE8E
00007dd052fe06a2  call 0x00007DD052EB52F0
00007dd052fe06a7  jmp 0x00007DD052FDEFA8
00007dd052fe06ac  call 0x00007DD052EB52F0
00007dd052fe06b1  jmp 0x00007DD052FDEFBE
00007dd052fe06b6  sub rsp, 0x08
00007dd052fe06ba  push rax
00007dd052fe06bb  push rcx
00007dd052fe06bc  push rdx
00007dd052fe06bd  push rdi
00007dd052fe06be  push rsi
00007dd052fe06bf  push r8
00007dd052fe06c1  push r9
00007dd052fe06c3  push r10
00007dd052fe06c5  push r11
00007dd052fe06c7  sub rsp, 0xF0
00007dd052fe06ce  vmovaps [rsp], xmm0
00007dd052fe06d3  vmovaps [rsp+0x10], xmm2
00007dd052fe06d9  vmovaps [rsp+0x20], xmm3
00007dd052fe06df  vmovaps [rsp+0x30], xmm4
00007dd052fe06e5  vmovaps [rsp+0x40], xmm5
00007dd052fe06eb  vmovaps [rsp+0x50], xmm6
00007dd052fe06f1  vmovaps [rsp+0x60], xmm7
00007dd052fe06f7  vmovaps [rsp+0x70], xmm8
00007dd052fe06fd  vmovaps [rsp+0x80], xmm9
00007dd052fe0706  vmovaps [rsp+0x90], xmm10
00007dd052fe070f  vmovaps [rsp+0xA0], xmm11
00007dd052fe0718  vmovaps [rsp+0xB0], xmm12
00007dd052fe0721  vmovaps [rsp+0xC0], xmm13
00007dd052fe072a  vmovaps [rsp+0xD0], xmm14
00007dd052fe0733  vmovaps [rsp+0xE0], xmm15
00007dd052fe073c  sub rsp, 0x30
00007dd052fe0740  movaps [rsp], xmm1
00007dd052fe0744  movaps [rsp+0x10], xmm6
00007dd052fe0749  movaps [rsp+0x20], xmm15
00007dd052fe074f  lea rdi, [rsp]
00007dd052fe0753  mov esi, 0x00
00007dd052fe0758  mov rax, 0x61D0404B9530
00007dd052fe0762  call rax
00007dd052fe0764  movaps xmm1, [rsp]
00007dd052fe0768  add rsp, 0x30
00007dd052fe076c  vmovaps xmm0, [rsp]
00007dd052fe0771  vmovaps xmm2, [rsp+0x10]
00007dd052fe0777  vmovaps xmm3, [rsp+0x20]
00007dd052fe077d  vmovaps xmm4, [rsp+0x30]
00007dd052fe0783  vmovaps xmm5, [rsp+0x40]
00007dd052fe0789  vmovaps xmm6, [rsp+0x50]
00007dd052fe078f  vmovaps xmm7, [rsp+0x60]
00007dd052fe0795  vmovaps xmm8, [rsp+0x70]
00007dd052fe079b  vmovaps xmm9, [rsp+0x80]
00007dd052fe07a4  vmovaps xmm10, [rsp+0x90]
00007dd052fe07ad  vmovaps xmm11, [rsp+0xA0]
00007dd052fe07b6  vmovaps xmm12, [rsp+0xB0]
00007dd052fe07bf  vmovaps xmm13, [rsp+0xC0]
00007dd052fe07c8  vmovaps xmm14, [rsp+0xD0]
00007dd052fe07d1  vmovaps xmm15, [rsp+0xE0]
00007dd052fe07da  add rsp, 0xF0
00007dd052fe07e1  pop r11
00007dd052fe07e3  pop r10
00007dd052fe07e5  pop r9
00007dd052fe07e7  pop r8
00007dd052fe07e9  pop rsi
00007dd052fe07ea  pop rdi
00007dd052fe07eb  pop rdx
00007dd052fe07ec  pop rcx
00007dd052fe07ed  pop rax
00007dd052fe07ee  add rsp, 0x08
00007dd052fe07f2  jmp 0x00007DD052FDEFFB
00007dd052fe07f7  call 0x00007DD052EC4620
00007dd052fe07fc  jmp 0x00007DD052FDF008
00007dd052fe0801  sub rsp, 0x08
00007dd052fe0805  push rax
00007dd052fe0806  push rcx
00007dd052fe0807  push rdx
00007dd052fe0808  push rdi
00007dd052fe0809  push rsi
00007dd052fe080a  push r8
00007dd052fe080c  push r9
00007dd052fe080e  push r10
00007dd052fe0810  push r11
00007dd052fe0812  sub rsp, 0xF0
00007dd052fe0819  vmovaps [rsp], xmm0
00007dd052fe081e  vmovaps [rsp+0x10], xmm1
00007dd052fe0824  vmovaps [rsp+0x20], xmm2
00007dd052fe082a  vmovaps [rsp+0x30], xmm3
00007dd052fe0830  vmovaps [rsp+0x40], xmm4
00007dd052fe0836  vmovaps [rsp+0x50], xmm5
00007dd052fe083c  vmovaps [rsp+0x60], xmm6
00007dd052fe0842  vmovaps [rsp+0x70], xmm7
00007dd052fe0848  vmovaps [rsp+0x80], xmm8
00007dd052fe0851  vmovaps [rsp+0x90], xmm9
00007dd052fe085a  vmovaps [rsp+0xA0], xmm10
00007dd052fe0863  vmovaps [rsp+0xB0], xmm11
00007dd052fe086c  vmovaps [rsp+0xC0], xmm12
00007dd052fe0875  vmovaps [rsp+0xD0], xmm13
00007dd052fe087e  vmovaps [rsp+0xE0], xmm15
00007dd052fe0887  sub rsp, 0x30
00007dd052fe088b  movaps [rsp], xmm14
00007dd052fe0890  movaps [rsp+0x10], xmm4
00007dd052fe0895  movaps [rsp+0x20], xmm3
00007dd052fe089a  lea rdi, [rsp]
00007dd052fe089e  mov esi, 0x00
00007dd052fe08a3  mov rax, 0x61D0404B9530
00007dd052fe08ad  call rax
00007dd052fe08af  movaps xmm14, [rsp]
00007dd052fe08b4  add rsp, 0x30
00007dd052fe08b8  vmovaps xmm0, [rsp]
00007dd052fe08bd  vmovaps xmm1, [rsp+0x10]
00007dd052fe08c3  vmovaps xmm2, [rsp+0x20]
00007dd052fe08c9  vmovaps xmm3, [rsp+0x30]
00007dd052fe08cf  vmovaps xmm4, [rsp+0x40]
00007dd052fe08d5  vmovaps xmm5, [rsp+0x50]
00007dd052fe08db  vmovaps xmm6, [rsp+0x60]
00007dd052fe08e1  vmovaps xmm7, [rsp+0x70]
00007dd052fe08e7  vmovaps xmm8, [rsp+0x80]
00007dd052fe08f0  vmovaps xmm9, [rsp+0x90]
00007dd052fe08f9  vmovaps xmm10, [rsp+0xA0]
00007dd052fe0902  vmovaps xmm11, [rsp+0xB0]
00007dd052fe090b  vmovaps xmm12, [rsp+0xC0]
00007dd052fe0914  vmovaps xmm13, [rsp+0xD0]
00007dd052fe091d  vmovaps xmm15, [rsp+0xE0]
00007dd052fe0926  add rsp, 0xF0
00007dd052fe092d  pop r11
00007dd052fe092f  pop r10
00007dd052fe0931  pop r9
00007dd052fe0933  pop r8
00007dd052fe0935  pop rsi
00007dd052fe0936  pop rdi
00007dd052fe0937  pop rdx
00007dd052fe0938  pop rcx
00007dd052fe0939  pop rax
00007dd052fe093a  add rsp, 0x08
00007dd052fe093e  jmp 0x00007DD052FDF022
00007dd052fe0943  sub rsp, 0x08
00007dd052fe0947  push rax
00007dd052fe0948  push rcx
00007dd052fe0949  push rdx
00007dd052fe094a  push rdi
00007dd052fe094b  push rsi
00007dd052fe094c  push r8
00007dd052fe094e  push r9
00007dd052fe0950  push r10
00007dd052fe0952  push r11
00007dd052fe0954  sub rsp, 0xF0
00007dd052fe095b  vmovaps [rsp], xmm0
00007dd052fe0960  vmovaps [rsp+0x10], xmm1
00007dd052fe0966  vmovaps [rsp+0x20], xmm2
00007dd052fe096c  vmovaps [rsp+0x30], xmm3
00007dd052fe0972  vmovaps [rsp+0x40], xmm4
00007dd052fe0978  vmovaps [rsp+0x50], xmm5
00007dd052fe097e  vmovaps [rsp+0x60], xmm7
00007dd052fe0984  vmovaps [rsp+0x70], xmm8
00007dd052fe098a  vmovaps [rsp+0x80], xmm9
00007dd052fe0993  vmovaps [rsp+0x90], xmm10
00007dd052fe099c  vmovaps [rsp+0xA0], xmm11
00007dd052fe09a5  vmovaps [rsp+0xB0], xmm12
00007dd052fe09ae  vmovaps [rsp+0xC0], xmm13
00007dd052fe09b7  vmovaps [rsp+0xD0], xmm14
00007dd052fe09c0  vmovaps [rsp+0xE0], xmm15
00007dd052fe09c9  sub rsp, 0x30
00007dd052fe09cd  movaps [rsp], xmm6
00007dd052fe09d1  movaps [rsp+0x10], xmm9
00007dd052fe09d7  movaps [rsp+0x20], xmm7
00007dd052fe09dc  lea rdi, [rsp]
00007dd052fe09e0  mov esi, 0x00
00007dd052fe09e5  mov rax, 0x61D0404B9530
00007dd052fe09ef  call rax
00007dd052fe09f1  movaps xmm6, [rsp]
00007dd052fe09f5  add rsp, 0x30
00007dd052fe09f9  vmovaps xmm0, [rsp]
00007dd052fe09fe  vmovaps xmm1, [rsp+0x10]
00007dd052fe0a04  vmovaps xmm2, [rsp+0x20]
00007dd052fe0a0a  vmovaps xmm3, [rsp+0x30]
00007dd052fe0a10  vmovaps xmm4, [rsp+0x40]
00007dd052fe0a16  vmovaps xmm5, [rsp+0x50]
00007dd052fe0a1c  vmovaps xmm7, [rsp+0x60]
00007dd052fe0a22  vmovaps xmm8, [rsp+0x70]
00007dd052fe0a28  vmovaps xmm9, [rsp+0x80]
00007dd052fe0a31  vmovaps xmm10, [rsp+0x90]
00007dd052fe0a3a  vmovaps xmm11, [rsp+0xA0]
00007dd052fe0a43  vmovaps xmm12, [rsp+0xB0]
00007dd052fe0a4c  vmovaps xmm13, [rsp+0xC0]
00007dd052fe0a55  vmovaps xmm14, [rsp+0xD0]
00007dd052fe0a5e  vmovaps xmm15, [rsp+0xE0]
00007dd052fe0a67  add rsp, 0xF0
00007dd052fe0a6e  pop r11
00007dd052fe0a70  pop r10
00007dd052fe0a72  pop r9
00007dd052fe0a74  pop r8
00007dd052fe0a76  pop rsi
00007dd052fe0a77  pop rdi
00007dd052fe0a78  pop rdx
00007dd052fe0a79  pop rcx
00007dd052fe0a7a  pop rax
00007dd052fe0a7b  add rsp, 0x08
00007dd052fe0a7f  jmp 0x00007DD052FDF03A
00007dd052fe0a84  sub rsp, 0x08
00007dd052fe0a88  push rax
00007dd052fe0a89  push rcx
00007dd052fe0a8a  push rdx
00007dd052fe0a8b  push rdi
00007dd052fe0a8c  push rsi
00007dd052fe0a8d  push r8
00007dd052fe0a8f  push r9
00007dd052fe0a91  push r10
00007dd052fe0a93  push r11
00007dd052fe0a95  sub rsp, 0xF0
00007dd052fe0a9c  vmovaps [rsp], xmm0
00007dd052fe0aa1  vmovaps [rsp+0x10], xmm1
00007dd052fe0aa7  vmovaps [rsp+0x20], xmm2
00007dd052fe0aad  vmovaps [rsp+0x30], xmm3
00007dd052fe0ab3  vmovaps [rsp+0x40], xmm4
00007dd052fe0ab9  vmovaps [rsp+0x50], xmm5
00007dd052fe0abf  vmovaps [rsp+0x60], xmm6
00007dd052fe0ac5  vmovaps [rsp+0x70], xmm8
00007dd052fe0acb  vmovaps [rsp+0x80], xmm9
00007dd052fe0ad4  vmovaps [rsp+0x90], xmm10
00007dd052fe0add  vmovaps [rsp+0xA0], xmm11
00007dd052fe0ae6  vmovaps [rsp+0xB0], xmm12
00007dd052fe0aef  vmovaps [rsp+0xC0], xmm13
00007dd052fe0af8  vmovaps [rsp+0xD0], xmm14
00007dd052fe0b01  vmovaps [rsp+0xE0], xmm15
00007dd052fe0b0a  sub rsp, 0x30
00007dd052fe0b0e  movaps [rsp], xmm7
00007dd052fe0b12  movaps [rsp+0x10], xmm4
00007dd052fe0b17  movaps [rsp+0x20], xmm9
00007dd052fe0b1d  lea rdi, [rsp]
00007dd052fe0b21  mov esi, 0x00
00007dd052fe0b26  mov rax, 0x61D0404B9530
00007dd052fe0b30  call rax
00007dd052fe0b32  movaps xmm7, [rsp]
00007dd052fe0b36  add rsp, 0x30
00007dd052fe0b3a  vmovaps xmm0, [rsp]
00007dd052fe0b3f  vmovaps xmm1, [rsp+0x10]
00007dd052fe0b45  vmovaps xmm2, [rsp+0x20]
00007dd052fe0b4b  vmovaps xmm3, [rsp+0x30]
00007dd052fe0b51  vmovaps xmm4, [rsp+0x40]
00007dd052fe0b57  vmovaps xmm5, [rsp+0x50]
00007dd052fe0b5d  vmovaps xmm6, [rsp+0x60]
00007dd052fe0b63  vmovaps xmm8, [rsp+0x70]
00007dd052fe0b69  vmovaps xmm9, [rsp+0x80]
00007dd052fe0b72  vmovaps xmm10, [rsp+0x90]
00007dd052fe0b7b  vmovaps xmm11, [rsp+0xA0]
00007dd052fe0b84  vmovaps xmm12, [rsp+0xB0]
00007dd052fe0b8d  vmovaps xmm13, [rsp+0xC0]
00007dd052fe0b96  vmovaps xmm14, [rsp+0xD0]
00007dd052fe0b9f  vmovaps xmm15, [rsp+0xE0]
00007dd052fe0ba8  add rsp, 0xF0
00007dd052fe0baf  pop r11
00007dd052fe0bb1  pop r10
00007dd052fe0bb3  pop r9
00007dd052fe0bb5  pop r8
00007dd052fe0bb7  pop rsi
00007dd052fe0bb8  pop rdi
00007dd052fe0bb9  pop rdx
00007dd052fe0bba  pop rcx
00007dd052fe0bbb  pop rax
00007dd052fe0bbc  add rsp, 0x08
00007dd052fe0bc0  jmp 0x00007DD052FDF067
00007dd052fe0bc5  sub rsp, 0x08
00007dd052fe0bc9  push rax
00007dd052fe0bca  push rcx
00007dd052fe0bcb  push rdx
00007dd052fe0bcc  push rdi
00007dd052fe0bcd  push rsi
00007dd052fe0bce  push r8
00007dd052fe0bd0  push r9
00007dd052fe0bd2  push r10
00007dd052fe0bd4  push r11
00007dd052fe0bd6  sub rsp, 0xF0
00007dd052fe0bdd  vmovaps [rsp], xmm0
00007dd052fe0be2  vmovaps [rsp+0x10], xmm1
00007dd052fe0be8  vmovaps [rsp+0x20], xmm2
00007dd052fe0bee  vmovaps [rsp+0x30], xmm3
00007dd052fe0bf4  vmovaps [rsp+0x40], xmm5
00007dd052fe0bfa  vmovaps [rsp+0x50], xmm6
00007dd052fe0c00  vmovaps [rsp+0x60], xmm7
00007dd052fe0c06  vmovaps [rsp+0x70], xmm8
00007dd052fe0c0c  vmovaps [rsp+0x80], xmm9
00007dd052fe0c15  vmovaps [rsp+0x90], xmm10
00007dd052fe0c1e  vmovaps [rsp+0xA0], xmm11
00007dd052fe0c27  vmovaps [rsp+0xB0], xmm12
00007dd052fe0c30  vmovaps [rsp+0xC0], xmm13
00007dd052fe0c39  vmovaps [rsp+0xD0], xmm14
00007dd052fe0c42  vmovaps [rsp+0xE0], xmm15
00007dd052fe0c4b  sub rsp, 0x30
00007dd052fe0c4f  movaps [rsp], xmm4
00007dd052fe0c53  movaps [rsp+0x10], xmm15
00007dd052fe0c59  movaps [rsp+0x20], xmm9
00007dd052fe0c5f  lea rdi, [rsp]
00007dd052fe0c63  mov esi, 0x00
00007dd052fe0c68  mov rax, 0x61D0404B9530
00007dd052fe0c72  call rax
00007dd052fe0c74  movaps xmm4, [rsp]
00007dd052fe0c78  add rsp, 0x30
00007dd052fe0c7c  vmovaps xmm0, [rsp]
00007dd052fe0c81  vmovaps xmm1, [rsp+0x10]
00007dd052fe0c87  vmovaps xmm2, [rsp+0x20]
00007dd052fe0c8d  vmovaps xmm3, [rsp+0x30]
00007dd052fe0c93  vmovaps xmm5, [rsp+0x40]
00007dd052fe0c99  vmovaps xmm6, [rsp+0x50]
00007dd052fe0c9f  vmovaps xmm7, [rsp+0x60]
00007dd052fe0ca5  vmovaps xmm8, [rsp+0x70]
00007dd052fe0cab  vmovaps xmm9, [rsp+0x80]
00007dd052fe0cb4  vmovaps xmm10, [rsp+0x90]
00007dd052fe0cbd  vmovaps xmm11, [rsp+0xA0]
00007dd052fe0cc6  vmovaps xmm12, [rsp+0xB0]
00007dd052fe0ccf  vmovaps xmm13, [rsp+0xC0]
00007dd052fe0cd8  vmovaps xmm14, [rsp+0xD0]
00007dd052fe0ce1  vmovaps xmm15, [rsp+0xE0]
00007dd052fe0cea  add rsp, 0xF0
00007dd052fe0cf1  pop r11
00007dd052fe0cf3  pop r10
00007dd052fe0cf5  pop r9
00007dd052fe0cf7  pop r8
00007dd052fe0cf9  pop rsi
00007dd052fe0cfa  pop rdi
00007dd052fe0cfb  pop rdx
00007dd052fe0cfc  pop rcx
00007dd052fe0cfd  pop rax
00007dd052fe0cfe  add rsp, 0x08
00007dd052fe0d02  jmp 0x00007DD052FDF08C
00007dd052fe0d07  call 0x00007DD052EC4620
00007dd052fe0d0c  jmp 0x00007DD052FDF099
00007dd052fe0d11  sub rsp, 0x08
00007dd052fe0d15  push rax
00007dd052fe0d16  push rcx
00007dd052fe0d17  push rdx
00007dd052fe0d18  push rdi
00007dd052fe0d19  push rsi
00007dd052fe0d1a  push r8
00007dd052fe0d1c  push r9
00007dd052fe0d1e  push r10
00007dd052fe0d20  push r11
00007dd052fe0d22  sub rsp, 0xF0
00007dd052fe0d29  vmovaps [rsp], xmm0
00007dd052fe0d2e  vmovaps [rsp+0x10], xmm1
00007dd052fe0d34  vmovaps [rsp+0x20], xmm2
00007dd052fe0d3a  vmovaps [rsp+0x30], xmm4
00007dd052fe0d40  vmovaps [rsp+0x40], xmm5
00007dd052fe0d46  vmovaps [rsp+0x50], xmm6
00007dd052fe0d4c  vmovaps [rsp+0x60], xmm7
00007dd052fe0d52  vmovaps [rsp+0x70], xmm8
00007dd052fe0d58  vmovaps [rsp+0x80], xmm9
00007dd052fe0d61  vmovaps [rsp+0x90], xmm10
00007dd052fe0d6a  vmovaps [rsp+0xA0], xmm11
00007dd052fe0d73  vmovaps [rsp+0xB0], xmm12
00007dd052fe0d7c  vmovaps [rsp+0xC0], xmm13
00007dd052fe0d85  vmovaps [rsp+0xD0], xmm14
00007dd052fe0d8e  vmovaps [rsp+0xE0], xmm15
00007dd052fe0d97  sub rsp, 0x30
00007dd052fe0d9b  movaps [rsp], xmm3
00007dd052fe0d9f  movaps [rsp+0x10], xmm1
00007dd052fe0da4  movaps [rsp+0x20], xmm9
00007dd052fe0daa  lea rdi, [rsp]
00007dd052fe0dae  mov esi, 0x00
00007dd052fe0db3  mov rax, 0x61D0404B9530
00007dd052fe0dbd  call rax
00007dd052fe0dbf  movaps xmm3, [rsp]
00007dd052fe0dc3  add rsp, 0x30
00007dd052fe0dc7  vmovaps xmm0, [rsp]
00007dd052fe0dcc  vmovaps xmm1, [rsp+0x10]
00007dd052fe0dd2  vmovaps xmm2, [rsp+0x20]
00007dd052fe0dd8  vmovaps xmm4, [rsp+0x30]
00007dd052fe0dde  vmovaps xmm5, [rsp+0x40]
00007dd052fe0de4  vmovaps xmm6, [rsp+0x50]
00007dd052fe0dea  vmovaps xmm7, [rsp+0x60]
00007dd052fe0df0  vmovaps xmm8, [rsp+0x70]
00007dd052fe0df6  vmovaps xmm9, [rsp+0x80]
00007dd052fe0dff  vmovaps xmm10, [rsp+0x90]
00007dd052fe0e08  vmovaps xmm11, [rsp+0xA0]
00007dd052fe0e11  vmovaps xmm12, [rsp+0xB0]
00007dd052fe0e1a  vmovaps xmm13, [rsp+0xC0]
00007dd052fe0e23  vmovaps xmm14, [rsp+0xD0]
00007dd052fe0e2c  vmovaps xmm15, [rsp+0xE0]
00007dd052fe0e35  add rsp, 0xF0
00007dd052fe0e3c  pop r11
00007dd052fe0e3e  pop r10
00007dd052fe0e40  pop r9
00007dd052fe0e42  pop r8
00007dd052fe0e44  pop rsi
00007dd052fe0e45  pop rdi
00007dd052fe0e46  pop rdx
00007dd052fe0e47  pop rcx
00007dd052fe0e48  pop rax
00007dd052fe0e49  add rsp, 0x08
00007dd052fe0e4d  jmp 0x00007DD052FDF0D6
00007dd052fe0e52  sub rsp, 0x08
00007dd052fe0e56  push rax
00007dd052fe0e57  push rcx
00007dd052fe0e58  push rdx
00007dd052fe0e59  push rdi
00007dd052fe0e5a  push rsi
00007dd052fe0e5b  push r8
00007dd052fe0e5d  push r9
00007dd052fe0e5f  push r10
00007dd052fe0e61  push r11
00007dd052fe0e63  sub rsp, 0xF0
00007dd052fe0e6a  vmovaps [rsp], xmm0
00007dd052fe0e6f  vmovaps [rsp+0x10], xmm2
00007dd052fe0e75  vmovaps [rsp+0x20], xmm3
00007dd052fe0e7b  vmovaps [rsp+0x30], xmm4
00007dd052fe0e81  vmovaps [rsp+0x40], xmm5
00007dd052fe0e87  vmovaps [rsp+0x50], xmm6
00007dd052fe0e8d  vmovaps [rsp+0x60], xmm7
00007dd052fe0e93  vmovaps [rsp+0x70], xmm8
00007dd052fe0e99  vmovaps [rsp+0x80], xmm9
00007dd052fe0ea2  vmovaps [rsp+0x90], xmm10
00007dd052fe0eab  vmovaps [rsp+0xA0], xmm11
00007dd052fe0eb4  vmovaps [rsp+0xB0], xmm12
00007dd052fe0ebd  vmovaps [rsp+0xC0], xmm13
00007dd052fe0ec6  vmovaps [rsp+0xD0], xmm14
00007dd052fe0ecf  vmovaps [rsp+0xE0], xmm15
00007dd052fe0ed8  sub rsp, 0x30
00007dd052fe0edc  movaps [rsp], xmm1
00007dd052fe0ee0  movaps [rsp+0x10], xmm15
00007dd052fe0ee6  movaps [rsp+0x20], xmm9
00007dd052fe0eec  lea rdi, [rsp]
00007dd052fe0ef0  mov esi, 0x00
00007dd052fe0ef5  mov rax, 0x61D0404B9530
00007dd052fe0eff  call rax
00007dd052fe0f01  movaps xmm1, [rsp]
00007dd052fe0f05  add rsp, 0x30
00007dd052fe0f09  vmovaps xmm0, [rsp]
00007dd052fe0f0e  vmovaps xmm2, [rsp+0x10]
00007dd052fe0f14  vmovaps xmm3, [rsp+0x20]
00007dd052fe0f1a  vmovaps xmm4, [rsp+0x30]
00007dd052fe0f20  vmovaps xmm5, [rsp+0x40]
00007dd052fe0f26  vmovaps xmm6, [rsp+0x50]
00007dd052fe0f2c  vmovaps xmm7, [rsp+0x60]
00007dd052fe0f32  vmovaps xmm8, [rsp+0x70]
00007dd052fe0f38  vmovaps xmm9, [rsp+0x80]
00007dd052fe0f41  vmovaps xmm10, [rsp+0x90]
00007dd052fe0f4a  vmovaps xmm11, [rsp+0xA0]
00007dd052fe0f53  vmovaps xmm12, [rsp+0xB0]
00007dd052fe0f5c  vmovaps xmm13, [rsp+0xC0]
00007dd052fe0f65  vmovaps xmm14, [rsp+0xD0]
00007dd052fe0f6e  vmovaps xmm15, [rsp+0xE0]
00007dd052fe0f77  add rsp, 0xF0
00007dd052fe0f7e  pop r11
00007dd052fe0f80  pop r10
00007dd052fe0f82  pop r9
00007dd052fe0f84  pop r8
00007dd052fe0f86  pop rsi
00007dd052fe0f87  pop rdi
00007dd052fe0f88  pop rdx
00007dd052fe0f89  pop rcx
00007dd052fe0f8a  pop rax
00007dd052fe0f8b  add rsp, 0x08
00007dd052fe0f8f  jmp 0x00007DD052FDF15E
00007dd052fe0f94  call 0x00007DD052EC4620
00007dd052fe0f99  jmp 0x00007DD052FDF16B
00007dd052fe0f9e  sub rsp, 0x08
00007dd052fe0fa2  push rax
00007dd052fe0fa3  push rcx
00007dd052fe0fa4  push rdx
00007dd052fe0fa5  push rdi
00007dd052fe0fa6  push rsi
00007dd052fe0fa7  push r8
00007dd052fe0fa9  push r9
00007dd052fe0fab  push r10
00007dd052fe0fad  push r11
00007dd052fe0faf  sub rsp, 0xF0
00007dd052fe0fb6  vmovaps [rsp], xmm0
00007dd052fe0fbb  vmovaps [rsp+0x10], xmm2
00007dd052fe0fc1  vmovaps [rsp+0x20], xmm3
00007dd052fe0fc7  vmovaps [rsp+0x30], xmm4
00007dd052fe0fcd  vmovaps [rsp+0x40], xmm5
00007dd052fe0fd3  vmovaps [rsp+0x50], xmm6
00007dd052fe0fd9  vmovaps [rsp+0x60], xmm7
00007dd052fe0fdf  vmovaps [rsp+0x70], xmm8
00007dd052fe0fe5  vmovaps [rsp+0x80], xmm9
00007dd052fe0fee  vmovaps [rsp+0x90], xmm10
00007dd052fe0ff7  vmovaps [rsp+0xA0], xmm11
00007dd052fe1000  vmovaps [rsp+0xB0], xmm12
00007dd052fe1009  vmovaps [rsp+0xC0], xmm13
00007dd052fe1012  vmovaps [rsp+0xD0], xmm14
00007dd052fe101b  vmovaps [rsp+0xE0], xmm15
00007dd052fe1024  sub rsp, 0x30
00007dd052fe1028  movaps [rsp], xmm1
00007dd052fe102c  movaps [rsp+0x10], xmm5
00007dd052fe1031  movaps [rsp+0x20], xmm7
00007dd052fe1036  lea rdi, [rsp]
00007dd052fe103a  mov esi, 0x00
00007dd052fe103f  mov rax, 0x61D0404B9530
00007dd052fe1049  call rax
00007dd052fe104b  movaps xmm1, [rsp]
00007dd052fe104f  add rsp, 0x30
00007dd052fe1053  vmovaps xmm0, [rsp]
00007dd052fe1058  vmovaps xmm2, [rsp+0x10]
00007dd052fe105e  vmovaps xmm3, [rsp+0x20]
00007dd052fe1064  vmovaps xmm4, [rsp+0x30]
00007dd052fe106a  vmovaps xmm5, [rsp+0x40]
00007dd052fe1070  vmovaps xmm6, [rsp+0x50]
00007dd052fe1076  vmovaps xmm7, [rsp+0x60]
00007dd052fe107c  vmovaps xmm8, [rsp+0x70]
00007dd052fe1082  vmovaps xmm9, [rsp+0x80]
00007dd052fe108b  vmovaps xmm10, [rsp+0x90]
00007dd052fe1094  vmovaps xmm11, [rsp+0xA0]
00007dd052fe109d  vmovaps xmm12, [rsp+0xB0]
00007dd052fe10a6  vmovaps xmm13, [rsp+0xC0]
00007dd052fe10af  vmovaps xmm14, [rsp+0xD0]
00007dd052fe10b8  vmovaps xmm15, [rsp+0xE0]
00007dd052fe10c1  add rsp, 0xF0
00007dd052fe10c8  pop r11
00007dd052fe10ca  pop r10
00007dd052fe10cc  pop r9
00007dd052fe10ce  pop r8
00007dd052fe10d0  pop rsi
00007dd052fe10d1  pop rdi
00007dd052fe10d2  pop rdx
00007dd052fe10d3  pop rcx
00007dd052fe10d4  pop rax
00007dd052fe10d5  add rsp, 0x08
00007dd052fe10d9  jmp 0x00007DD052FDF210
00007dd052fe10de  sub rsp, 0x08
00007dd052fe10e2  push rax
00007dd052fe10e3  push rcx
00007dd052fe10e4  push rdx
00007dd052fe10e5  push rdi
00007dd052fe10e6  push rsi
00007dd052fe10e7  push r8
00007dd052fe10e9  push r9
00007dd052fe10eb  push r10
00007dd052fe10ed  push r11
00007dd052fe10ef  sub rsp, 0xF0
00007dd052fe10f6  vmovaps [rsp], xmm0
00007dd052fe10fb  vmovaps [rsp+0x10], xmm1
00007dd052fe1101  vmovaps [rsp+0x20], xmm2
00007dd052fe1107  vmovaps [rsp+0x30], xmm3
00007dd052fe110d  vmovaps [rsp+0x40], xmm4
00007dd052fe1113  vmovaps [rsp+0x50], xmm5
00007dd052fe1119  vmovaps [rsp+0x60], xmm6
00007dd052fe111f  vmovaps [rsp+0x70], xmm8
00007dd052fe1125  vmovaps [rsp+0x80], xmm9
00007dd052fe112e  vmovaps [rsp+0x90], xmm10
00007dd052fe1137  vmovaps [rsp+0xA0], xmm11
00007dd052fe1140  vmovaps [rsp+0xB0], xmm12
00007dd052fe1149  vmovaps [rsp+0xC0], xmm13
00007dd052fe1152  vmovaps [rsp+0xD0], xmm14
00007dd052fe115b  vmovaps [rsp+0xE0], xmm15
00007dd052fe1164  sub rsp, 0x30
00007dd052fe1168  movaps [rsp], xmm7
00007dd052fe116c  movaps [rsp+0x10], xmm5
00007dd052fe1171  movaps [rsp+0x20], xmm15
00007dd052fe1177  lea rdi, [rsp]
00007dd052fe117b  mov esi, 0x00
00007dd052fe1180  mov rax, 0x61D0404B9530
00007dd052fe118a  call rax
00007dd052fe118c  movaps xmm7, [rsp]
00007dd052fe1190  add rsp, 0x30
00007dd052fe1194  vmovaps xmm0, [rsp]
00007dd052fe1199  vmovaps xmm1, [rsp+0x10]
00007dd052fe119f  vmovaps xmm2, [rsp+0x20]
00007dd052fe11a5  vmovaps xmm3, [rsp+0x30]
00007dd052fe11ab  vmovaps xmm4, [rsp+0x40]
00007dd052fe11b1  vmovaps xmm5, [rsp+0x50]
00007dd052fe11b7  vmovaps xmm6, [rsp+0x60]
00007dd052fe11bd  vmovaps xmm8, [rsp+0x70]
00007dd052fe11c3  vmovaps xmm9, [rsp+0x80]
00007dd052fe11cc  vmovaps xmm10, [rsp+0x90]
00007dd052fe11d5  vmovaps xmm11, [rsp+0xA0]
00007dd052fe11de  vmovaps xmm12, [rsp+0xB0]
00007dd052fe11e7  vmovaps xmm13, [rsp+0xC0]
00007dd052fe11f0  vmovaps xmm14, [rsp+0xD0]
00007dd052fe11f9  vmovaps xmm15, [rsp+0xE0]
00007dd052fe1202  add rsp, 0xF0
00007dd052fe1209  pop r11
00007dd052fe120b  pop r10
00007dd052fe120d  pop r9
00007dd052fe120f  pop r8
00007dd052fe1211  pop rsi
00007dd052fe1212  pop rdi
00007dd052fe1213  pop rdx
00007dd052fe1214  pop rcx
00007dd052fe1215  pop rax
00007dd052fe1216  add rsp, 0x08
00007dd052fe121a  jmp 0x00007DD052FDF246
00007dd052fe121f  call 0x00007DD052EB52F0
00007dd052fe1224  jmp 0x00007DD052FDF253
00007dd052fe1229  sub rsp, 0x08
00007dd052fe122d  push rax
00007dd052fe122e  push rcx
00007dd052fe122f  push rdx
00007dd052fe1230  push rdi
00007dd052fe1231  push rsi
00007dd052fe1232  push r8
00007dd052fe1234  push r9
00007dd052fe1236  push r10
00007dd052fe1238  push r11
00007dd052fe123a  sub rsp, 0xF0
00007dd052fe1241  vmovaps [rsp], xmm0
00007dd052fe1246  vmovaps [rsp+0x10], xmm1
00007dd052fe124c  vmovaps [rsp+0x20], xmm2
00007dd052fe1252  vmovaps [rsp+0x30], xmm3
00007dd052fe1258  vmovaps [rsp+0x40], xmm4
00007dd052fe125e  vmovaps [rsp+0x50], xmm5
00007dd052fe1264  vmovaps [rsp+0x60], xmm6
00007dd052fe126a  vmovaps [rsp+0x70], xmm7
00007dd052fe1270  vmovaps [rsp+0x80], xmm8
00007dd052fe1279  vmovaps [rsp+0x90], xmm9
00007dd052fe1282  vmovaps [rsp+0xA0], xmm10
00007dd052fe128b  vmovaps [rsp+0xB0], xmm11
00007dd052fe1294  vmovaps [rsp+0xC0], xmm12
00007dd052fe129d  vmovaps [rsp+0xD0], xmm13
00007dd052fe12a6  vmovaps [rsp+0xE0], xmm14
00007dd052fe12af  sub rsp, 0x30
00007dd052fe12b3  movaps [rsp], xmm15
00007dd052fe12b8  movaps [rsp+0x10], xmm5
00007dd052fe12bd  movaps [rsp+0x20], xmm3
00007dd052fe12c2  lea rdi, [rsp]
00007dd052fe12c6  mov esi, 0x00
00007dd052fe12cb  mov rax, 0x61D0404B9530
00007dd052fe12d5  call rax
00007dd052fe12d7  movaps xmm15, [rsp]
00007dd052fe12dc  add rsp, 0x30
00007dd052fe12e0  vmovaps xmm0, [rsp]
00007dd052fe12e5  vmovaps xmm1, [rsp+0x10]
00007dd052fe12eb  vmovaps xmm2, [rsp+0x20]
00007dd052fe12f1  vmovaps xmm3, [rsp+0x30]
00007dd052fe12f7  vmovaps xmm4, [rsp+0x40]
00007dd052fe12fd  vmovaps xmm5, [rsp+0x50]
00007dd052fe1303  vmovaps xmm6, [rsp+0x60]
00007dd052fe1309  vmovaps xmm7, [rsp+0x70]
00007dd052fe130f  vmovaps xmm8, [rsp+0x80]
00007dd052fe1318  vmovaps xmm9, [rsp+0x90]
00007dd052fe1321  vmovaps xmm10, [rsp+0xA0]
00007dd052fe132a  vmovaps xmm11, [rsp+0xB0]
00007dd052fe1333  vmovaps xmm12, [rsp+0xC0]
00007dd052fe133c  vmovaps xmm13, [rsp+0xD0]
00007dd052fe1345  vmovaps xmm14, [rsp+0xE0]
00007dd052fe134e  add rsp, 0xF0
00007dd052fe1355  pop r11
00007dd052fe1357  pop r10
00007dd052fe1359  pop r9
00007dd052fe135b  pop r8
00007dd052fe135d  pop rsi
00007dd052fe135e  pop rdi
00007dd052fe135f  pop rdx
00007dd052fe1360  pop rcx
00007dd052fe1361  pop rax
00007dd052fe1362  add rsp, 0x08
00007dd052fe1366  jmp 0x00007DD052FDF279
00007dd052fe136b  sub rsp, 0x08
00007dd052fe136f  push rax
00007dd052fe1370  push rcx
00007dd052fe1371  push rdx
00007dd052fe1372  push rdi
00007dd052fe1373  push rsi
00007dd052fe1374  push r8
00007dd052fe1376  push r9
00007dd052fe1378  push r10
00007dd052fe137a  push r11
00007dd052fe137c  sub rsp, 0xF0
00007dd052fe1383  vmovaps [rsp], xmm0
00007dd052fe1388  vmovaps [rsp+0x10], xmm2
00007dd052fe138e  vmovaps [rsp+0x20], xmm3
00007dd052fe1394  vmovaps [rsp+0x30], xmm4
00007dd052fe139a  vmovaps [rsp+0x40], xmm5
00007dd052fe13a0  vmovaps [rsp+0x50], xmm6
00007dd052fe13a6  vmovaps [rsp+0x60], xmm7
00007dd052fe13ac  vmovaps [rsp+0x70], xmm8
00007dd052fe13b2  vmovaps [rsp+0x80], xmm9
00007dd052fe13bb  vmovaps [rsp+0x90], xmm10
00007dd052fe13c4  vmovaps [rsp+0xA0], xmm11
00007dd052fe13cd  vmovaps [rsp+0xB0], xmm12
00007dd052fe13d6  vmovaps [rsp+0xC0], xmm13
00007dd052fe13df  vmovaps [rsp+0xD0], xmm14
00007dd052fe13e8  vmovaps [rsp+0xE0], xmm15
00007dd052fe13f1  sub rsp, 0x30
00007dd052fe13f5  movaps [rsp], xmm1
00007dd052fe13f9  movaps [rsp+0x10], xmm5
00007dd052fe13fe  movaps [rsp+0x20], xmm4
00007dd052fe1403  lea rdi, [rsp]
00007dd052fe1407  mov esi, 0x00
00007dd052fe140c  mov rax, 0x61D0404B9530
00007dd052fe1416  call rax
00007dd052fe1418  movaps xmm1, [rsp]
00007dd052fe141c  add rsp, 0x30
00007dd052fe1420  vmovaps xmm0, [rsp]
00007dd052fe1425  vmovaps xmm2, [rsp+0x10]
00007dd052fe142b  vmovaps xmm3, [rsp+0x20]
00007dd052fe1431  vmovaps xmm4, [rsp+0x30]
00007dd052fe1437  vmovaps xmm5, [rsp+0x40]
00007dd052fe143d  vmovaps xmm6, [rsp+0x50]
00007dd052fe1443  vmovaps xmm7, [rsp+0x60]
00007dd052fe1449  vmovaps xmm8, [rsp+0x70]
00007dd052fe144f  vmovaps xmm9, [rsp+0x80]
00007dd052fe1458  vmovaps xmm10, [rsp+0x90]
00007dd052fe1461  vmovaps xmm11, [rsp+0xA0]
00007dd052fe146a  vmovaps xmm12, [rsp+0xB0]
00007dd052fe1473  vmovaps xmm13, [rsp+0xC0]
00007dd052fe147c  vmovaps xmm14, [rsp+0xD0]
00007dd052fe1485  vmovaps xmm15, [rsp+0xE0]
00007dd052fe148e  add rsp, 0xF0
00007dd052fe1495  pop r11
00007dd052fe1497  pop r10
00007dd052fe1499  pop r9
00007dd052fe149b  pop r8
00007dd052fe149d  pop rsi
00007dd052fe149e  pop rdi
00007dd052fe149f  pop rdx
00007dd052fe14a0  pop rcx
00007dd052fe14a1  pop rax
00007dd052fe14a2  add rsp, 0x08
00007dd052fe14a6  jmp 0x00007DD052FDF299
00007dd052fe14ab  sub rsp, 0x08
00007dd052fe14af  push rax
00007dd052fe14b0  push rcx
00007dd052fe14b1  push rdx
00007dd052fe14b2  push rdi
00007dd052fe14b3  push rsi
00007dd052fe14b4  push r8
00007dd052fe14b6  push r9
00007dd052fe14b8  push r10
00007dd052fe14ba  push r11
00007dd052fe14bc  sub rsp, 0xF0
00007dd052fe14c3  vmovaps [rsp], xmm0
00007dd052fe14c8  vmovaps [rsp+0x10], xmm1
00007dd052fe14ce  vmovaps [rsp+0x20], xmm2
00007dd052fe14d4  vmovaps [rsp+0x30], xmm3
00007dd052fe14da  vmovaps [rsp+0x40], xmm5
00007dd052fe14e0  vmovaps [rsp+0x50], xmm6
00007dd052fe14e6  vmovaps [rsp+0x60], xmm7
00007dd052fe14ec  vmovaps [rsp+0x70], xmm8
00007dd052fe14f2  vmovaps [rsp+0x80], xmm9
00007dd052fe14fb  vmovaps [rsp+0x90], xmm10
00007dd052fe1504  vmovaps [rsp+0xA0], xmm11
00007dd052fe150d  vmovaps [rsp+0xB0], xmm12
00007dd052fe1516  vmovaps [rsp+0xC0], xmm13
00007dd052fe151f  vmovaps [rsp+0xD0], xmm14
00007dd052fe1528  vmovaps [rsp+0xE0], xmm15
00007dd052fe1531  sub rsp, 0x30
00007dd052fe1535  movaps [rsp], xmm4
00007dd052fe1539  movaps [rsp+0x10], xmm3
00007dd052fe153e  movaps [rsp+0x20], xmm5
00007dd052fe1543  lea rdi, [rsp]
00007dd052fe1547  mov esi, 0x00
00007dd052fe154c  mov rax, 0x61D0404B9530
00007dd052fe1556  call rax
00007dd052fe1558  movaps xmm4, [rsp]
00007dd052fe155c  add rsp, 0x30
00007dd052fe1560  vmovaps xmm0, [rsp]
00007dd052fe1565  vmovaps xmm1, [rsp+0x10]
00007dd052fe156b  vmovaps xmm2, [rsp+0x20]
00007dd052fe1571  vmovaps xmm3, [rsp+0x30]
00007dd052fe1577  vmovaps xmm5, [rsp+0x40]
00007dd052fe157d  vmovaps xmm6, [rsp+0x50]
00007dd052fe1583  vmovaps xmm7, [rsp+0x60]
00007dd052fe1589  vmovaps xmm8, [rsp+0x70]
00007dd052fe158f  vmovaps xmm9, [rsp+0x80]
00007dd052fe1598  vmovaps xmm10, [rsp+0x90]
00007dd052fe15a1  vmovaps xmm11, [rsp+0xA0]
00007dd052fe15aa  vmovaps xmm12, [rsp+0xB0]
00007dd052fe15b3  vmovaps xmm13, [rsp+0xC0]
00007dd052fe15bc  vmovaps xmm14, [rsp+0xD0]
00007dd052fe15c5  vmovaps xmm15, [rsp+0xE0]
00007dd052fe15ce  add rsp, 0xF0
00007dd052fe15d5  pop r11
00007dd052fe15d7  pop r10
00007dd052fe15d9  pop r9
00007dd052fe15db  pop r8
00007dd052fe15dd  pop rsi
00007dd052fe15de  pop rdi
00007dd052fe15df  pop rdx
00007dd052fe15e0  pop rcx
00007dd052fe15e1  pop rax
00007dd052fe15e2  add rsp, 0x08
00007dd052fe15e6  jmp 0x00007DD052FDF2E7
00007dd052fe15eb  call 0x00007DD052EB52F0
00007dd052fe15f0  jmp 0x00007DD052FDF2F4
00007dd052fe15f5  sub rsp, 0x08
00007dd052fe15f9  push rax
00007dd052fe15fa  push rcx
00007dd052fe15fb  push rdx
00007dd052fe15fc  push rdi
00007dd052fe15fd  push rsi
00007dd052fe15fe  push r8
00007dd052fe1600  push r9
00007dd052fe1602  push r10
00007dd052fe1604  push r11
00007dd052fe1606  sub rsp, 0xF0
00007dd052fe160d  vmovaps [rsp], xmm0
00007dd052fe1612  vmovaps [rsp+0x10], xmm1
00007dd052fe1618  vmovaps [rsp+0x20], xmm2
00007dd052fe161e  vmovaps [rsp+0x30], xmm3
00007dd052fe1624  vmovaps [rsp+0x40], xmm4
00007dd052fe162a  vmovaps [rsp+0x50], xmm6
00007dd052fe1630  vmovaps [rsp+0x60], xmm7
00007dd052fe1636  vmovaps [rsp+0x70], xmm8
00007dd052fe163c  vmovaps [rsp+0x80], xmm9
00007dd052fe1645  vmovaps [rsp+0x90], xmm10
00007dd052fe164e  vmovaps [rsp+0xA0], xmm11
00007dd052fe1657  vmovaps [rsp+0xB0], xmm12
00007dd052fe1660  vmovaps [rsp+0xC0], xmm13
00007dd052fe1669  vmovaps [rsp+0xD0], xmm14
00007dd052fe1672  vmovaps [rsp+0xE0], xmm15
00007dd052fe167b  sub rsp, 0x30
00007dd052fe167f  movaps [rsp], xmm5
00007dd052fe1683  movaps [rsp+0x10], xmm6
00007dd052fe1688  movaps [rsp+0x20], xmm3
00007dd052fe168d  lea rdi, [rsp]
00007dd052fe1691  mov esi, 0x00
00007dd052fe1696  mov rax, 0x61D0404B9530
00007dd052fe16a0  call rax
00007dd052fe16a2  movaps xmm5, [rsp]
00007dd052fe16a6  add rsp, 0x30
00007dd052fe16aa  vmovaps xmm0, [rsp]
00007dd052fe16af  vmovaps xmm1, [rsp+0x10]
00007dd052fe16b5  vmovaps xmm2, [rsp+0x20]
00007dd052fe16bb  vmovaps xmm3, [rsp+0x30]
00007dd052fe16c1  vmovaps xmm4, [rsp+0x40]
00007dd052fe16c7  vmovaps xmm6, [rsp+0x50]
00007dd052fe16cd  vmovaps xmm7, [rsp+0x60]
00007dd052fe16d3  vmovaps xmm8, [rsp+0x70]
00007dd052fe16d9  vmovaps xmm9, [rsp+0x80]
00007dd052fe16e2  vmovaps xmm10, [rsp+0x90]
00007dd052fe16eb  vmovaps xmm11, [rsp+0xA0]
00007dd052fe16f4  vmovaps xmm12, [rsp+0xB0]
00007dd052fe16fd  vmovaps xmm13, [rsp+0xC0]
00007dd052fe1706  vmovaps xmm14, [rsp+0xD0]
00007dd052fe170f  vmovaps xmm15, [rsp+0xE0]
00007dd052fe1718  add rsp, 0xF0
00007dd052fe171f  pop r11
00007dd052fe1721  pop r10
00007dd052fe1723  pop r9
00007dd052fe1725  pop r8
00007dd052fe1727  pop rsi
00007dd052fe1728  pop rdi
00007dd052fe1729  pop rdx
00007dd052fe172a  pop rcx
00007dd052fe172b  pop rax
00007dd052fe172c  add rsp, 0x08
00007dd052fe1730  jmp 0x00007DD052FDF31A
00007dd052fe1735  sub rsp, 0x08
00007dd052fe1739  push rax
00007dd052fe173a  push rcx
00007dd052fe173b  push rdx
00007dd052fe173c  push rdi
00007dd052fe173d  push rsi
00007dd052fe173e  push r8
00007dd052fe1740  push r9
00007dd052fe1742  push r10
00007dd052fe1744  push r11
00007dd052fe1746  sub rsp, 0xF0
00007dd052fe174d  vmovaps [rsp], xmm0
00007dd052fe1752  vmovaps [rsp+0x10], xmm1
00007dd052fe1758  vmovaps [rsp+0x20], xmm2
00007dd052fe175e  vmovaps [rsp+0x30], xmm3
00007dd052fe1764  vmovaps [rsp+0x40], xmm4
00007dd052fe176a  vmovaps [rsp+0x50], xmm5
00007dd052fe1770  vmovaps [rsp+0x60], xmm7
00007dd052fe1776  vmovaps [rsp+0x70], xmm8
00007dd052fe177c  vmovaps [rsp+0x80], xmm9
00007dd052fe1785  vmovaps [rsp+0x90], xmm10
00007dd052fe178e  vmovaps [rsp+0xA0], xmm11
00007dd052fe1797  vmovaps [rsp+0xB0], xmm12
00007dd052fe17a0  vmovaps [rsp+0xC0], xmm13
00007dd052fe17a9  vmovaps [rsp+0xD0], xmm14
00007dd052fe17b2  vmovaps [rsp+0xE0], xmm15
00007dd052fe17bb  sub rsp, 0x30
00007dd052fe17bf  movaps [rsp], xmm6
00007dd052fe17c3  movaps [rsp+0x10], xmm9
00007dd052fe17c9  movaps [rsp+0x20], xmm1
00007dd052fe17ce  lea rdi, [rsp]
00007dd052fe17d2  mov esi, 0x00
00007dd052fe17d7  mov rax, 0x61D0404B9530
00007dd052fe17e1  call rax
00007dd052fe17e3  movaps xmm6, [rsp]
00007dd052fe17e7  add rsp, 0x30
00007dd052fe17eb  vmovaps xmm0, [rsp]
00007dd052fe17f0  vmovaps xmm1, [rsp+0x10]
00007dd052fe17f6  vmovaps xmm2, [rsp+0x20]
00007dd052fe17fc  vmovaps xmm3, [rsp+0x30]
00007dd052fe1802  vmovaps xmm4, [rsp+0x40]
00007dd052fe1808  vmovaps xmm5, [rsp+0x50]
00007dd052fe180e  vmovaps xmm7, [rsp+0x60]
00007dd052fe1814  vmovaps xmm8, [rsp+0x70]
00007dd052fe181a  vmovaps xmm9, [rsp+0x80]
00007dd052fe1823  vmovaps xmm10, [rsp+0x90]
00007dd052fe182c  vmovaps xmm11, [rsp+0xA0]
00007dd052fe1835  vmovaps xmm12, [rsp+0xB0]
00007dd052fe183e  vmovaps xmm13, [rsp+0xC0]
00007dd052fe1847  vmovaps xmm14, [rsp+0xD0]
00007dd052fe1850  vmovaps xmm15, [rsp+0xE0]
00007dd052fe1859  add rsp, 0xF0
00007dd052fe1860  pop r11
00007dd052fe1862  pop r10
00007dd052fe1864  pop r9
00007dd052fe1866  pop r8
00007dd052fe1868  pop rsi
00007dd052fe1869  pop rdi
00007dd052fe186a  pop rdx
00007dd052fe186b  pop rcx
00007dd052fe186c  pop rax
00007dd052fe186d  add rsp, 0x08
00007dd052fe1871  jmp 0x00007DD052FDF33E
00007dd052fe1876  sub rsp, 0x08
00007dd052fe187a  push rax
00007dd052fe187b  push rcx
00007dd052fe187c  push rdx
00007dd052fe187d  push rdi
00007dd052fe187e  push rsi
00007dd052fe187f  push r8
00007dd052fe1881  push r9
00007dd052fe1883  push r10
00007dd052fe1885  push r11
00007dd052fe1887  sub rsp, 0xF0
00007dd052fe188e  vmovaps [rsp], xmm0
00007dd052fe1893  vmovaps [rsp+0x10], xmm1
00007dd052fe1899  vmovaps [rsp+0x20], xmm2
00007dd052fe189f  vmovaps [rsp+0x30], xmm3
00007dd052fe18a5  vmovaps [rsp+0x40], xmm4
00007dd052fe18ab  vmovaps [rsp+0x50], xmm5
00007dd052fe18b1  vmovaps [rsp+0x60], xmm6
00007dd052fe18b7  vmovaps [rsp+0x70], xmm7
00007dd052fe18bd  vmovaps [rsp+0x80], xmm8
00007dd052fe18c6  vmovaps [rsp+0x90], xmm10
00007dd052fe18cf  vmovaps [rsp+0xA0], xmm11
00007dd052fe18d8  vmovaps [rsp+0xB0], xmm12
00007dd052fe18e1  vmovaps [rsp+0xC0], xmm13
00007dd052fe18ea  vmovaps [rsp+0xD0], xmm14
00007dd052fe18f3  vmovaps [rsp+0xE0], xmm15
00007dd052fe18fc  sub rsp, 0x30
00007dd052fe1900  movaps [rsp], xmm9
00007dd052fe1905  movaps [rsp+0x10], xmm3
00007dd052fe190a  movaps [rsp+0x20], xmm1
00007dd052fe190f  lea rdi, [rsp]
00007dd052fe1913  mov esi, 0x00
00007dd052fe1918  mov rax, 0x61D0404B9530
00007dd052fe1922  call rax
00007dd052fe1924  movaps xmm9, [rsp]
00007dd052fe1929  add rsp, 0x30
00007dd052fe192d  vmovaps xmm0, [rsp]
00007dd052fe1932  vmovaps xmm1, [rsp+0x10]
00007dd052fe1938  vmovaps xmm2, [rsp+0x20]
00007dd052fe193e  vmovaps xmm3, [rsp+0x30]
00007dd052fe1944  vmovaps xmm4, [rsp+0x40]
00007dd052fe194a  vmovaps xmm5, [rsp+0x50]
00007dd052fe1950  vmovaps xmm6, [rsp+0x60]
00007dd052fe1956  vmovaps xmm7, [rsp+0x70]
00007dd052fe195c  vmovaps xmm8, [rsp+0x80]
00007dd052fe1965  vmovaps xmm10, [rsp+0x90]
00007dd052fe196e  vmovaps xmm11, [rsp+0xA0]
00007dd052fe1977  vmovaps xmm12, [rsp+0xB0]
00007dd052fe1980  vmovaps xmm13, [rsp+0xC0]
00007dd052fe1989  vmovaps xmm14, [rsp+0xD0]
00007dd052fe1992  vmovaps xmm15, [rsp+0xE0]
00007dd052fe199b  add rsp, 0xF0
00007dd052fe19a2  pop r11
00007dd052fe19a4  pop r10
00007dd052fe19a6  pop r9
00007dd052fe19a8  pop r8
00007dd052fe19aa  pop rsi
00007dd052fe19ab  pop rdi
00007dd052fe19ac  pop rdx
00007dd052fe19ad  pop rcx
00007dd052fe19ae  pop rax
00007dd052fe19af  add rsp, 0x08
00007dd052fe19b3  jmp 0x00007DD052FDF38A
00007dd052fe19b8  call 0x00007DD052EB52F0
00007dd052fe19bd  jmp 0x00007DD052FDF397
00007dd052fe19c2  sub rsp, 0x08
00007dd052fe19c6  push rax
00007dd052fe19c7  push rcx
00007dd052fe19c8  push rdx
00007dd052fe19c9  push rdi
00007dd052fe19ca  push rsi
00007dd052fe19cb  push r8
00007dd052fe19cd  push r9
00007dd052fe19cf  push r10
00007dd052fe19d1  push r11
00007dd052fe19d3  sub rsp, 0xF0
00007dd052fe19da  vmovaps [rsp], xmm0
00007dd052fe19df  vmovaps [rsp+0x10], xmm1
00007dd052fe19e5  vmovaps [rsp+0x20], xmm2
00007dd052fe19eb  vmovaps [rsp+0x30], xmm3
00007dd052fe19f1  vmovaps [rsp+0x40], xmm4
00007dd052fe19f7  vmovaps [rsp+0x50], xmm5
00007dd052fe19fd  vmovaps [rsp+0x60], xmm6
00007dd052fe1a03  vmovaps [rsp+0x70], xmm7
00007dd052fe1a09  vmovaps [rsp+0x80], xmm8
00007dd052fe1a12  vmovaps [rsp+0x90], xmm9
00007dd052fe1a1b  vmovaps [rsp+0xA0], xmm10
00007dd052fe1a24  vmovaps [rsp+0xB0], xmm11
00007dd052fe1a2d  vmovaps [rsp+0xC0], xmm12
00007dd052fe1a36  vmovaps [rsp+0xD0], xmm13
00007dd052fe1a3f  vmovaps [rsp+0xE0], xmm14
00007dd052fe1a48  sub rsp, 0x30
00007dd052fe1a4c  movaps [rsp], xmm15
00007dd052fe1a51  movaps [rsp+0x10], xmm3
00007dd052fe1a56  movaps [rsp+0x20], xmm7
00007dd052fe1a5b  lea rdi, [rsp]
00007dd052fe1a5f  mov esi, 0x00
00007dd052fe1a64  mov rax, 0x61D0404B9530
00007dd052fe1a6e  call rax
00007dd052fe1a70  movaps xmm15, [rsp]
00007dd052fe1a75  add rsp, 0x30
00007dd052fe1a79  vmovaps xmm0, [rsp]
00007dd052fe1a7e  vmovaps xmm1, [rsp+0x10]
00007dd052fe1a84  vmovaps xmm2, [rsp+0x20]
00007dd052fe1a8a  vmovaps xmm3, [rsp+0x30]
00007dd052fe1a90  vmovaps xmm4, [rsp+0x40]
00007dd052fe1a96  vmovaps xmm5, [rsp+0x50]
00007dd052fe1a9c  vmovaps xmm6, [rsp+0x60]
00007dd052fe1aa2  vmovaps xmm7, [rsp+0x70]
00007dd052fe1aa8  vmovaps xmm8, [rsp+0x80]
00007dd052fe1ab1  vmovaps xmm9, [rsp+0x90]
00007dd052fe1aba  vmovaps xmm10, [rsp+0xA0]
00007dd052fe1ac3  vmovaps xmm11, [rsp+0xB0]
00007dd052fe1acc  vmovaps xmm12, [rsp+0xC0]
00007dd052fe1ad5  vmovaps xmm13, [rsp+0xD0]
00007dd052fe1ade  vmovaps xmm14, [rsp+0xE0]
00007dd052fe1ae7  add rsp, 0xF0
00007dd052fe1aee  pop r11
00007dd052fe1af0  pop r10
00007dd052fe1af2  pop r9
00007dd052fe1af4  pop r8
00007dd052fe1af6  pop rsi
00007dd052fe1af7  pop rdi
00007dd052fe1af8  pop rdx
00007dd052fe1af9  pop rcx
00007dd052fe1afa  pop rax
00007dd052fe1afb  add rsp, 0x08
00007dd052fe1aff  jmp 0x00007DD052FDF3C3
00007dd052fe1b04  sub rsp, 0x08
00007dd052fe1b08  push rax
00007dd052fe1b09  push rcx
00007dd052fe1b0a  push rdx
00007dd052fe1b0b  push rdi
00007dd052fe1b0c  push rsi
00007dd052fe1b0d  push r8
00007dd052fe1b0f  push r9
00007dd052fe1b11  push r10
00007dd052fe1b13  push r11
00007dd052fe1b15  sub rsp, 0xF0
00007dd052fe1b1c  vmovaps [rsp], xmm0
00007dd052fe1b21  vmovaps [rsp+0x10], xmm1
00007dd052fe1b27  vmovaps [rsp+0x20], xmm2
00007dd052fe1b2d  vmovaps [rsp+0x30], xmm4
00007dd052fe1b33  vmovaps [rsp+0x40], xmm5
00007dd052fe1b39  vmovaps [rsp+0x50], xmm6
00007dd052fe1b3f  vmovaps [rsp+0x60], xmm7
00007dd052fe1b45  vmovaps [rsp+0x70], xmm8
00007dd052fe1b4b  vmovaps [rsp+0x80], xmm9
00007dd052fe1b54  vmovaps [rsp+0x90], xmm10
00007dd052fe1b5d  vmovaps [rsp+0xA0], xmm11
00007dd052fe1b66  vmovaps [rsp+0xB0], xmm12
00007dd052fe1b6f  vmovaps [rsp+0xC0], xmm13
00007dd052fe1b78  vmovaps [rsp+0xD0], xmm14
00007dd052fe1b81  vmovaps [rsp+0xE0], xmm15
00007dd052fe1b8a  sub rsp, 0x30
00007dd052fe1b8e  movaps [rsp], xmm3
00007dd052fe1b92  movaps [rsp+0x10], xmm1
00007dd052fe1b97  movaps [rsp+0x20], xmm15
00007dd052fe1b9d  lea rdi, [rsp]
00007dd052fe1ba1  mov esi, 0x00
00007dd052fe1ba6  mov rax, 0x61D0404B9530
00007dd052fe1bb0  call rax
00007dd052fe1bb2  movaps xmm3, [rsp]
00007dd052fe1bb6  add rsp, 0x30
00007dd052fe1bba  vmovaps xmm0, [rsp]
00007dd052fe1bbf  vmovaps xmm1, [rsp+0x10]
00007dd052fe1bc5  vmovaps xmm2, [rsp+0x20]
00007dd052fe1bcb  vmovaps xmm4, [rsp+0x30]
00007dd052fe1bd1  vmovaps xmm5, [rsp+0x40]
00007dd052fe1bd7  vmovaps xmm6, [rsp+0x50]
00007dd052fe1bdd  vmovaps xmm7, [rsp+0x60]
00007dd052fe1be3  vmovaps xmm8, [rsp+0x70]
00007dd052fe1be9  vmovaps xmm9, [rsp+0x80]
00007dd052fe1bf2  vmovaps xmm10, [rsp+0x90]
00007dd052fe1bfb  vmovaps xmm11, [rsp+0xA0]
00007dd052fe1c04  vmovaps xmm12, [rsp+0xB0]
00007dd052fe1c0d  vmovaps xmm13, [rsp+0xC0]
00007dd052fe1c16  vmovaps xmm14, [rsp+0xD0]
00007dd052fe1c1f  vmovaps xmm15, [rsp+0xE0]
00007dd052fe1c28  add rsp, 0xF0
00007dd052fe1c2f  pop r11
00007dd052fe1c31  pop r10
00007dd052fe1c33  pop r9
00007dd052fe1c35  pop r8
00007dd052fe1c37  pop rsi
00007dd052fe1c38  pop rdi
00007dd052fe1c39  pop rdx
00007dd052fe1c3a  pop rcx
00007dd052fe1c3b  pop rax
00007dd052fe1c3c  add rsp, 0x08
00007dd052fe1c40  jmp 0x00007DD052FDF452
00007dd052fe1c45  call 0x00007DD052EB52F0
00007dd052fe1c4a  jmp 0x00007DD052FDF45C
00007dd052fe1c4f  sub rsp, 0x08
00007dd052fe1c53  push rax
00007dd052fe1c54  push rcx
00007dd052fe1c55  push rdx
00007dd052fe1c56  push rdi
00007dd052fe1c57  push rsi
00007dd052fe1c58  push r8
00007dd052fe1c5a  push r9
00007dd052fe1c5c  push r10
00007dd052fe1c5e  push r11
00007dd052fe1c60  sub rsp, 0xF0
00007dd052fe1c67  vmovaps [rsp], xmm0
00007dd052fe1c6c  vmovaps [rsp+0x10], xmm1
00007dd052fe1c72  vmovaps [rsp+0x20], xmm2
00007dd052fe1c78  vmovaps [rsp+0x30], xmm3
00007dd052fe1c7e  vmovaps [rsp+0x40], xmm4
00007dd052fe1c84  vmovaps [rsp+0x50], xmm5
00007dd052fe1c8a  vmovaps [rsp+0x60], xmm6
00007dd052fe1c90  vmovaps [rsp+0x70], xmm7
00007dd052fe1c96  vmovaps [rsp+0x80], xmm8
00007dd052fe1c9f  vmovaps [rsp+0x90], xmm9
00007dd052fe1ca8  vmovaps [rsp+0xA0], xmm10
00007dd052fe1cb1  vmovaps [rsp+0xB0], xmm11
00007dd052fe1cba  vmovaps [rsp+0xC0], xmm12
00007dd052fe1cc3  vmovaps [rsp+0xD0], xmm13
00007dd052fe1ccc  vmovaps [rsp+0xE0], xmm14
00007dd052fe1cd5  sub rsp, 0x30
00007dd052fe1cd9  movaps [rsp], xmm15
00007dd052fe1cde  movaps [rsp+0x10], xmm14
00007dd052fe1ce4  movaps [rsp+0x20], xmm4
00007dd052fe1ce9  lea rdi, [rsp]
00007dd052fe1ced  mov esi, 0x00
00007dd052fe1cf2  mov rax, 0x61D0404B9530
00007dd052fe1cfc  call rax
00007dd052fe1cfe  movaps xmm15, [rsp]
00007dd052fe1d03  add rsp, 0x30
00007dd052fe1d07  vmovaps xmm0, [rsp]
00007dd052fe1d0c  vmovaps xmm1, [rsp+0x10]
00007dd052fe1d12  vmovaps xmm2, [rsp+0x20]
00007dd052fe1d18  vmovaps xmm3, [rsp+0x30]
00007dd052fe1d1e  vmovaps xmm4, [rsp+0x40]
00007dd052fe1d24  vmovaps xmm5, [rsp+0x50]
00007dd052fe1d2a  vmovaps xmm6, [rsp+0x60]
00007dd052fe1d30  vmovaps xmm7, [rsp+0x70]
00007dd052fe1d36  vmovaps xmm8, [rsp+0x80]
00007dd052fe1d3f  vmovaps xmm9, [rsp+0x90]
00007dd052fe1d48  vmovaps xmm10, [rsp+0xA0]
00007dd052fe1d51  vmovaps xmm11, [rsp+0xB0]
00007dd052fe1d5a  vmovaps xmm12, [rsp+0xC0]
00007dd052fe1d63  vmovaps xmm13, [rsp+0xD0]
00007dd052fe1d6c  vmovaps xmm14, [rsp+0xE0]
00007dd052fe1d75  add rsp, 0xF0
00007dd052fe1d7c  pop r11
00007dd052fe1d7e  pop r10
00007dd052fe1d80  pop r9
00007dd052fe1d82  pop r8
00007dd052fe1d84  pop rsi
00007dd052fe1d85  pop rdi
00007dd052fe1d86  pop rdx
00007dd052fe1d87  pop rcx
00007dd052fe1d88  pop rax
00007dd052fe1d89  add rsp, 0x08
00007dd052fe1d8d  jmp 0x00007DD052FDF48A
00007dd052fe1d92  sub rsp, 0x08
00007dd052fe1d96  push rax
00007dd052fe1d97  push rcx
00007dd052fe1d98  push rdx
00007dd052fe1d99  push rdi
00007dd052fe1d9a  push rsi
00007dd052fe1d9b  push r8
00007dd052fe1d9d  push r9
00007dd052fe1d9f  push r10
00007dd052fe1da1  push r11
00007dd052fe1da3  sub rsp, 0xF0
00007dd052fe1daa  vmovaps [rsp], xmm0
00007dd052fe1daf  vmovaps [rsp+0x10], xmm1
00007dd052fe1db5  vmovaps [rsp+0x20], xmm2
00007dd052fe1dbb  vmovaps [rsp+0x30], xmm3
00007dd052fe1dc1  vmovaps [rsp+0x40], xmm4
00007dd052fe1dc7  vmovaps [rsp+0x50], xmm5
00007dd052fe1dcd  vmovaps [rsp+0x60], xmm6
00007dd052fe1dd3  vmovaps [rsp+0x70], xmm7
00007dd052fe1dd9  vmovaps [rsp+0x80], xmm8
00007dd052fe1de2  vmovaps [rsp+0x90], xmm9
00007dd052fe1deb  vmovaps [rsp+0xA0], xmm10
00007dd052fe1df4  vmovaps [rsp+0xB0], xmm11
00007dd052fe1dfd  vmovaps [rsp+0xC0], xmm12
00007dd052fe1e06  vmovaps [rsp+0xD0], xmm13
00007dd052fe1e0f  vmovaps [rsp+0xE0], xmm15
00007dd052fe1e18  sub rsp, 0x30
00007dd052fe1e1c  movaps [rsp], xmm14
00007dd052fe1e21  movaps [rsp+0x10], xmm2
00007dd052fe1e26  movaps [rsp+0x20], xmm1
00007dd052fe1e2b  lea rdi, [rsp]
00007dd052fe1e2f  mov esi, 0x00
00007dd052fe1e34  mov rax, 0x61D0404B9530
00007dd052fe1e3e  call rax
00007dd052fe1e40  movaps xmm14, [rsp]
00007dd052fe1e45  add rsp, 0x30
00007dd052fe1e49  vmovaps xmm0, [rsp]
00007dd052fe1e4e  vmovaps xmm1, [rsp+0x10]
00007dd052fe1e54  vmovaps xmm2, [rsp+0x20]
00007dd052fe1e5a  vmovaps xmm3, [rsp+0x30]
00007dd052fe1e60  vmovaps xmm4, [rsp+0x40]
00007dd052fe1e66  vmovaps xmm5, [rsp+0x50]
00007dd052fe1e6c  vmovaps xmm6, [rsp+0x60]
00007dd052fe1e72  vmovaps xmm7, [rsp+0x70]
00007dd052fe1e78  vmovaps xmm8, [rsp+0x80]
00007dd052fe1e81  vmovaps xmm9, [rsp+0x90]
00007dd052fe1e8a  vmovaps xmm10, [rsp+0xA0]
00007dd052fe1e93  vmovaps xmm11, [rsp+0xB0]
00007dd052fe1e9c  vmovaps xmm12, [rsp+0xC0]
00007dd052fe1ea5  vmovaps xmm13, [rsp+0xD0]
00007dd052fe1eae  vmovaps xmm15, [rsp+0xE0]
00007dd052fe1eb7  add rsp, 0xF0
00007dd052fe1ebe  pop r11
00007dd052fe1ec0  pop r10
00007dd052fe1ec2  pop r9
00007dd052fe1ec4  pop r8
00007dd052fe1ec6  pop rsi
00007dd052fe1ec7  pop rdi
00007dd052fe1ec8  pop rdx
00007dd052fe1ec9  pop rcx
00007dd052fe1eca  pop rax
00007dd052fe1ecb  add rsp, 0x08
00007dd052fe1ecf  jmp 0x00007DD052FDF4B0
00007dd052fe1ed4  sub rsp, 0x08
00007dd052fe1ed8  push rax
00007dd052fe1ed9  push rcx
00007dd052fe1eda  push rdx
00007dd052fe1edb  push rdi
00007dd052fe1edc  push rsi
00007dd052fe1edd  push r8
00007dd052fe1edf  push r9
00007dd052fe1ee1  push r10
00007dd052fe1ee3  push r11
00007dd052fe1ee5  sub rsp, 0xF0
00007dd052fe1eec  vmovaps [rsp], xmm0
00007dd052fe1ef1  vmovaps [rsp+0x10], xmm2
00007dd052fe1ef7  vmovaps [rsp+0x20], xmm3
00007dd052fe1efd  vmovaps [rsp+0x30], xmm4
00007dd052fe1f03  vmovaps [rsp+0x40], xmm5
00007dd052fe1f09  vmovaps [rsp+0x50], xmm6
00007dd052fe1f0f  vmovaps [rsp+0x60], xmm7
00007dd052fe1f15  vmovaps [rsp+0x70], xmm8
00007dd052fe1f1b  vmovaps [rsp+0x80], xmm9
00007dd052fe1f24  vmovaps [rsp+0x90], xmm10
00007dd052fe1f2d  vmovaps [rsp+0xA0], xmm11
00007dd052fe1f36  vmovaps [rsp+0xB0], xmm12
00007dd052fe1f3f  vmovaps [rsp+0xC0], xmm13
00007dd052fe1f48  vmovaps [rsp+0xD0], xmm14
00007dd052fe1f51  vmovaps [rsp+0xE0], xmm15
00007dd052fe1f5a  sub rsp, 0x30
00007dd052fe1f5e  movaps [rsp], xmm1
00007dd052fe1f62  movaps [rsp+0x10], xmm4
00007dd052fe1f67  movaps [rsp+0x20], xmm9
00007dd052fe1f6d  lea rdi, [rsp]
00007dd052fe1f71  mov esi, 0x00
00007dd052fe1f76  mov rax, 0x61D0404B9530
00007dd052fe1f80  call rax
00007dd052fe1f82  movaps xmm1, [rsp]
00007dd052fe1f86  add rsp, 0x30
00007dd052fe1f8a  vmovaps xmm0, [rsp]
00007dd052fe1f8f  vmovaps xmm2, [rsp+0x10]
00007dd052fe1f95  vmovaps xmm3, [rsp+0x20]
00007dd052fe1f9b  vmovaps xmm4, [rsp+0x30]
00007dd052fe1fa1  vmovaps xmm5, [rsp+0x40]
00007dd052fe1fa7  vmovaps xmm6, [rsp+0x50]
00007dd052fe1fad  vmovaps xmm7, [rsp+0x60]
00007dd052fe1fb3  vmovaps xmm8, [rsp+0x70]
00007dd052fe1fb9  vmovaps xmm9, [rsp+0x80]
00007dd052fe1fc2  vmovaps xmm10, [rsp+0x90]
00007dd052fe1fcb  vmovaps xmm11, [rsp+0xA0]
00007dd052fe1fd4  vmovaps xmm12, [rsp+0xB0]
00007dd052fe1fdd  vmovaps xmm13, [rsp+0xC0]
00007dd052fe1fe6  vmovaps xmm14, [rsp+0xD0]
00007dd052fe1fef  vmovaps xmm15, [rsp+0xE0]
00007dd052fe1ff8  add rsp, 0xF0
00007dd052fe1fff  pop r11
00007dd052fe2001  pop r10
00007dd052fe2003  pop r9
00007dd052fe2005  pop r8
00007dd052fe2007  pop rsi
00007dd052fe2008  pop rdi
00007dd052fe2009  pop rdx
00007dd052fe200a  pop rcx
00007dd052fe200b  pop rax
00007dd052fe200c  add rsp, 0x08
00007dd052fe2010  jmp 0x00007DD052FDF4CE
00007dd052fe2015  sub rsp, 0x08
00007dd052fe2019  push rax
00007dd052fe201a  push rcx
00007dd052fe201b  push rdx
00007dd052fe201c  push rdi
00007dd052fe201d  push rsi
00007dd052fe201e  push r8
00007dd052fe2020  push r9
00007dd052fe2022  push r10
00007dd052fe2024  push r11
00007dd052fe2026  sub rsp, 0xF0
00007dd052fe202d  vmovaps [rsp], xmm0
00007dd052fe2032  vmovaps [rsp+0x10], xmm1
00007dd052fe2038  vmovaps [rsp+0x20], xmm2
00007dd052fe203e  vmovaps [rsp+0x30], xmm3
00007dd052fe2044  vmovaps [rsp+0x40], xmm5
00007dd052fe204a  vmovaps [rsp+0x50], xmm6
00007dd052fe2050  vmovaps [rsp+0x60], xmm7
00007dd052fe2056  vmovaps [rsp+0x70], xmm8
00007dd052fe205c  vmovaps [rsp+0x80], xmm9
00007dd052fe2065  vmovaps [rsp+0x90], xmm10
00007dd052fe206e  vmovaps [rsp+0xA0], xmm11
00007dd052fe2077  vmovaps [rsp+0xB0], xmm12
00007dd052fe2080  vmovaps [rsp+0xC0], xmm13
00007dd052fe2089  vmovaps [rsp+0xD0], xmm14
00007dd052fe2092  vmovaps [rsp+0xE0], xmm15
00007dd052fe209b  sub rsp, 0x30
00007dd052fe209f  movaps [rsp], xmm4
00007dd052fe20a3  movaps [rsp+0x10], xmm2
00007dd052fe20a8  movaps [rsp+0x20], xmm9
00007dd052fe20ae  lea rdi, [rsp]
00007dd052fe20b2  mov esi, 0x00
00007dd052fe20b7  mov rax, 0x61D0404B9530
00007dd052fe20c1  call rax
00007dd052fe20c3  movaps xmm4, [rsp]
00007dd052fe20c7  add rsp, 0x30
00007dd052fe20cb  vmovaps xmm0, [rsp]
00007dd052fe20d0  vmovaps xmm1, [rsp+0x10]
00007dd052fe20d6  vmovaps xmm2, [rsp+0x20]
00007dd052fe20dc  vmovaps xmm3, [rsp+0x30]
00007dd052fe20e2  vmovaps xmm5, [rsp+0x40]
00007dd052fe20e8  vmovaps xmm6, [rsp+0x50]
00007dd052fe20ee  vmovaps xmm7, [rsp+0x60]
00007dd052fe20f4  vmovaps xmm8, [rsp+0x70]
00007dd052fe20fa  vmovaps xmm9, [rsp+0x80]
00007dd052fe2103  vmovaps xmm10, [rsp+0x90]
00007dd052fe210c  vmovaps xmm11, [rsp+0xA0]
00007dd052fe2115  vmovaps xmm12, [rsp+0xB0]
00007dd052fe211e  vmovaps xmm13, [rsp+0xC0]
00007dd052fe2127  vmovaps xmm14, [rsp+0xD0]
00007dd052fe2130  vmovaps xmm15, [rsp+0xE0]
00007dd052fe2139  add rsp, 0xF0
00007dd052fe2140  pop r11
00007dd052fe2142  pop r10
00007dd052fe2144  pop r9
00007dd052fe2146  pop r8
00007dd052fe2148  pop rsi
00007dd052fe2149  pop rdi
00007dd052fe214a  pop rdx
00007dd052fe214b  pop rcx
00007dd052fe214c  pop rax
00007dd052fe214d  add rsp, 0x08
00007dd052fe2151  jmp 0x00007DD052FDF4FE
00007dd052fe2156  sub rsp, 0x08
00007dd052fe215a  push rax
00007dd052fe215b  push rcx
00007dd052fe215c  push rdx
00007dd052fe215d  push rdi
00007dd052fe215e  push rsi
00007dd052fe215f  push r8
00007dd052fe2161  push r9
00007dd052fe2163  push r10
00007dd052fe2165  push r11
00007dd052fe2167  sub rsp, 0xF0
00007dd052fe216e  vmovaps [rsp], xmm0
00007dd052fe2173  vmovaps [rsp+0x10], xmm1
00007dd052fe2179  vmovaps [rsp+0x20], xmm2
00007dd052fe217f  vmovaps [rsp+0x30], xmm3
00007dd052fe2185  vmovaps [rsp+0x40], xmm4
00007dd052fe218b  vmovaps [rsp+0x50], xmm5
00007dd052fe2191  vmovaps [rsp+0x60], xmm6
00007dd052fe2197  vmovaps [rsp+0x70], xmm7
00007dd052fe219d  vmovaps [rsp+0x80], xmm8
00007dd052fe21a6  vmovaps [rsp+0x90], xmm10
00007dd052fe21af  vmovaps [rsp+0xA0], xmm11
00007dd052fe21b8  vmovaps [rsp+0xB0], xmm12
00007dd052fe21c1  vmovaps [rsp+0xC0], xmm13
00007dd052fe21ca  vmovaps [rsp+0xD0], xmm14
00007dd052fe21d3  vmovaps [rsp+0xE0], xmm15
00007dd052fe21dc  sub rsp, 0x30
00007dd052fe21e0  movaps [rsp], xmm9
00007dd052fe21e5  movaps [rsp+0x10], xmm2
00007dd052fe21ea  movaps [rsp+0x20], xmm1
00007dd052fe21ef  lea rdi, [rsp]
00007dd052fe21f3  mov esi, 0x00
00007dd052fe21f8  mov rax, 0x61D0404B9530
00007dd052fe2202  call rax
00007dd052fe2204  movaps xmm9, [rsp]
00007dd052fe2209  add rsp, 0x30
00007dd052fe220d  vmovaps xmm0, [rsp]
00007dd052fe2212  vmovaps xmm1, [rsp+0x10]
00007dd052fe2218  vmovaps xmm2, [rsp+0x20]
00007dd052fe221e  vmovaps xmm3, [rsp+0x30]
00007dd052fe2224  vmovaps xmm4, [rsp+0x40]
00007dd052fe222a  vmovaps xmm5, [rsp+0x50]
00007dd052fe2230  vmovaps xmm6, [rsp+0x60]
00007dd052fe2236  vmovaps xmm7, [rsp+0x70]
00007dd052fe223c  vmovaps xmm8, [rsp+0x80]
00007dd052fe2245  vmovaps xmm10, [rsp+0x90]
00007dd052fe224e  vmovaps xmm11, [rsp+0xA0]
00007dd052fe2257  vmovaps xmm12, [rsp+0xB0]
00007dd052fe2260  vmovaps xmm13, [rsp+0xC0]
00007dd052fe2269  vmovaps xmm14, [rsp+0xD0]
00007dd052fe2272  vmovaps xmm15, [rsp+0xE0]
00007dd052fe227b  add rsp, 0xF0
00007dd052fe2282  pop r11
00007dd052fe2284  pop r10
00007dd052fe2286  pop r9
00007dd052fe2288  pop r8
00007dd052fe228a  pop rsi
00007dd052fe228b  pop rdi
00007dd052fe228c  pop rdx
00007dd052fe228d  pop rcx
00007dd052fe228e  pop rax
00007dd052fe228f  add rsp, 0x08
00007dd052fe2293  jmp 0x00007DD052FDF534
00007dd052fe2298  sub rsp, 0x08
00007dd052fe229c  push rax
00007dd052fe229d  push rcx
00007dd052fe229e  push rdx
00007dd052fe229f  push rdi
00007dd052fe22a0  push rsi
00007dd052fe22a1  push r8
00007dd052fe22a3  push r9
00007dd052fe22a5  push r10
00007dd052fe22a7  push r11
00007dd052fe22a9  sub rsp, 0xF0
00007dd052fe22b0  vmovaps [rsp], xmm0
00007dd052fe22b5  vmovaps [rsp+0x10], xmm2
00007dd052fe22bb  vmovaps [rsp+0x20], xmm3
00007dd052fe22c1  vmovaps [rsp+0x30], xmm4
00007dd052fe22c7  vmovaps [rsp+0x40], xmm5
00007dd052fe22cd  vmovaps [rsp+0x50], xmm6
00007dd052fe22d3  vmovaps [rsp+0x60], xmm7
00007dd052fe22d9  vmovaps [rsp+0x70], xmm8
00007dd052fe22df  vmovaps [rsp+0x80], xmm9
00007dd052fe22e8  vmovaps [rsp+0x90], xmm10
00007dd052fe22f1  vmovaps [rsp+0xA0], xmm11
00007dd052fe22fa  vmovaps [rsp+0xB0], xmm12
00007dd052fe2303  vmovaps [rsp+0xC0], xmm13
00007dd052fe230c  vmovaps [rsp+0xD0], xmm14
00007dd052fe2315  vmovaps [rsp+0xE0], xmm15
00007dd052fe231e  sub rsp, 0x30
00007dd052fe2322  movaps [rsp], xmm1
00007dd052fe2326  movaps [rsp+0x10], xmm15
00007dd052fe232c  movaps [rsp+0x20], xmm6
00007dd052fe2331  lea rdi, [rsp]
00007dd052fe2335  mov esi, 0x00
00007dd052fe233a  mov rax, 0x61D0404B9530
00007dd052fe2344  call rax
00007dd052fe2346  movaps xmm1, [rsp]
00007dd052fe234a  add rsp, 0x30
00007dd052fe234e  vmovaps xmm0, [rsp]
00007dd052fe2353  vmovaps xmm2, [rsp+0x10]
00007dd052fe2359  vmovaps xmm3, [rsp+0x20]
00007dd052fe235f  vmovaps xmm4, [rsp+0x30]
00007dd052fe2365  vmovaps xmm5, [rsp+0x40]
00007dd052fe236b  vmovaps xmm6, [rsp+0x50]
00007dd052fe2371  vmovaps xmm7, [rsp+0x60]
00007dd052fe2377  vmovaps xmm8, [rsp+0x70]
00007dd052fe237d  vmovaps xmm9, [rsp+0x80]
00007dd052fe2386  vmovaps xmm10, [rsp+0x90]
00007dd052fe238f  vmovaps xmm11, [rsp+0xA0]
00007dd052fe2398  vmovaps xmm12, [rsp+0xB0]
00007dd052fe23a1  vmovaps xmm13, [rsp+0xC0]
00007dd052fe23aa  vmovaps xmm14, [rsp+0xD0]
00007dd052fe23b3  vmovaps xmm15, [rsp+0xE0]
00007dd052fe23bc  add rsp, 0xF0
00007dd052fe23c3  pop r11
00007dd052fe23c5  pop r10
00007dd052fe23c7  pop r9
00007dd052fe23c9  pop r8
00007dd052fe23cb  pop rsi
00007dd052fe23cc  pop rdi
00007dd052fe23cd  pop rdx
00007dd052fe23ce  pop rcx
00007dd052fe23cf  pop rax
00007dd052fe23d0  add rsp, 0x08
00007dd052fe23d4  jmp 0x00007DD052FDF555
00007dd052fe23d9  sub rsp, 0x08
00007dd052fe23dd  push rax
00007dd052fe23de  push rcx
00007dd052fe23df  push rdx
00007dd052fe23e0  push rdi
00007dd052fe23e1  push rsi
00007dd052fe23e2  push r8
00007dd052fe23e4  push r9
00007dd052fe23e6  push r10
00007dd052fe23e8  push r11
00007dd052fe23ea  sub rsp, 0xF0
00007dd052fe23f1  vmovaps [rsp], xmm0
00007dd052fe23f6  vmovaps [rsp+0x10], xmm1
00007dd052fe23fc  vmovaps [rsp+0x20], xmm2
00007dd052fe2402  vmovaps [rsp+0x30], xmm3
00007dd052fe2408  vmovaps [rsp+0x40], xmm4
00007dd052fe240e  vmovaps [rsp+0x50], xmm5
00007dd052fe2414  vmovaps [rsp+0x60], xmm6
00007dd052fe241a  vmovaps [rsp+0x70], xmm7
00007dd052fe2420  vmovaps [rsp+0x80], xmm8
00007dd052fe2429  vmovaps [rsp+0x90], xmm9
00007dd052fe2432  vmovaps [rsp+0xA0], xmm10
00007dd052fe243b  vmovaps [rsp+0xB0], xmm11
00007dd052fe2444  vmovaps [rsp+0xC0], xmm12
00007dd052fe244d  vmovaps [rsp+0xD0], xmm13
00007dd052fe2456  vmovaps [rsp+0xE0], xmm14
00007dd052fe245f  sub rsp, 0x30
00007dd052fe2463  movaps [rsp], xmm15
00007dd052fe2468  movaps [rsp+0x10], xmm5
00007dd052fe246d  movaps [rsp+0x20], xmm3
00007dd052fe2472  lea rdi, [rsp]
00007dd052fe2476  mov esi, 0x00
00007dd052fe247b  mov rax, 0x61D0404B9530
00007dd052fe2485  call rax
00007dd052fe2487  movaps xmm15, [rsp]
00007dd052fe248c  add rsp, 0x30
00007dd052fe2490  vmovaps xmm0, [rsp]
00007dd052fe2495  vmovaps xmm1, [rsp+0x10]
00007dd052fe249b  vmovaps xmm2, [rsp+0x20]
00007dd052fe24a1  vmovaps xmm3, [rsp+0x30]
00007dd052fe24a7  vmovaps xmm4, [rsp+0x40]
00007dd052fe24ad  vmovaps xmm5, [rsp+0x50]
00007dd052fe24b3  vmovaps xmm6, [rsp+0x60]
00007dd052fe24b9  vmovaps xmm7, [rsp+0x70]
00007dd052fe24bf  vmovaps xmm8, [rsp+0x80]
00007dd052fe24c8  vmovaps xmm9, [rsp+0x90]
00007dd052fe24d1  vmovaps xmm10, [rsp+0xA0]
00007dd052fe24da  vmovaps xmm11, [rsp+0xB0]
00007dd052fe24e3  vmovaps xmm12, [rsp+0xC0]
00007dd052fe24ec  vmovaps xmm13, [rsp+0xD0]
00007dd052fe24f5  vmovaps xmm14, [rsp+0xE0]
00007dd052fe24fe  add rsp, 0xF0
00007dd052fe2505  pop r11
00007dd052fe2507  pop r10
00007dd052fe2509  pop r9
00007dd052fe250b  pop r8
00007dd052fe250d  pop rsi
00007dd052fe250e  pop rdi
00007dd052fe250f  pop rdx
00007dd052fe2510  pop rcx
00007dd052fe2511  pop rax
00007dd052fe2512  add rsp, 0x08
00007dd052fe2516  jmp 0x00007DD052FDF56F
00007dd052fe251b  sub rsp, 0x08
00007dd052fe251f  push rax
00007dd052fe2520  push rcx
00007dd052fe2521  push rdx
00007dd052fe2522  push rdi
00007dd052fe2523  push rsi
00007dd052fe2524  push r8
00007dd052fe2526  push r9
00007dd052fe2528  push r10
00007dd052fe252a  push r11
00007dd052fe252c  sub rsp, 0xF0
00007dd052fe2533  vmovaps [rsp], xmm0
00007dd052fe2538  vmovaps [rsp+0x10], xmm1
00007dd052fe253e  vmovaps [rsp+0x20], xmm2
00007dd052fe2544  vmovaps [rsp+0x30], xmm3
00007dd052fe254a  vmovaps [rsp+0x40], xmm4
00007dd052fe2550  vmovaps [rsp+0x50], xmm6
00007dd052fe2556  vmovaps [rsp+0x60], xmm7
00007dd052fe255c  vmovaps [rsp+0x70], xmm8
00007dd052fe2562  vmovaps [rsp+0x80], xmm9
00007dd052fe256b  vmovaps [rsp+0x90], xmm10
00007dd052fe2574  vmovaps [rsp+0xA0], xmm11
00007dd052fe257d  vmovaps [rsp+0xB0], xmm12
00007dd052fe2586  vmovaps [rsp+0xC0], xmm13
00007dd052fe258f  vmovaps [rsp+0xD0], xmm14
00007dd052fe2598  vmovaps [rsp+0xE0], xmm15
00007dd052fe25a1  sub rsp, 0x30
00007dd052fe25a5  movaps [rsp], xmm5
00007dd052fe25a9  movaps [rsp+0x10], xmm8
00007dd052fe25af  movaps [rsp+0x20], xmm6
00007dd052fe25b4  lea rdi, [rsp]
00007dd052fe25b8  mov esi, 0x00
00007dd052fe25bd  mov rax, 0x61D0404B9530
00007dd052fe25c7  call rax
00007dd052fe25c9  movaps xmm5, [rsp]
00007dd052fe25cd  add rsp, 0x30
00007dd052fe25d1  vmovaps xmm0, [rsp]
00007dd052fe25d6  vmovaps xmm1, [rsp+0x10]
00007dd052fe25dc  vmovaps xmm2, [rsp+0x20]
00007dd052fe25e2  vmovaps xmm3, [rsp+0x30]
00007dd052fe25e8  vmovaps xmm4, [rsp+0x40]
00007dd052fe25ee  vmovaps xmm6, [rsp+0x50]
00007dd052fe25f4  vmovaps xmm7, [rsp+0x60]
00007dd052fe25fa  vmovaps xmm8, [rsp+0x70]
00007dd052fe2600  vmovaps xmm9, [rsp+0x80]
00007dd052fe2609  vmovaps xmm10, [rsp+0x90]
00007dd052fe2612  vmovaps xmm11, [rsp+0xA0]
00007dd052fe261b  vmovaps xmm12, [rsp+0xB0]
00007dd052fe2624  vmovaps xmm13, [rsp+0xC0]
00007dd052fe262d  vmovaps xmm14, [rsp+0xD0]
00007dd052fe2636  vmovaps xmm15, [rsp+0xE0]
00007dd052fe263f  add rsp, 0xF0
00007dd052fe2646  pop r11
00007dd052fe2648  pop r10
00007dd052fe264a  pop r9
00007dd052fe264c  pop r8
00007dd052fe264e  pop rsi
00007dd052fe264f  pop rdi
00007dd052fe2650  pop rdx
00007dd052fe2651  pop rcx
00007dd052fe2652  pop rax
00007dd052fe2653  add rsp, 0x08
00007dd052fe2657  jmp 0x00007DD052FDF593
00007dd052fe265c  sub rsp, 0x08
00007dd052fe2660  push rax
00007dd052fe2661  push rcx
00007dd052fe2662  push rdx
00007dd052fe2663  push rdi
00007dd052fe2664  push rsi
00007dd052fe2665  push r8
00007dd052fe2667  push r9
00007dd052fe2669  push r10
00007dd052fe266b  push r11
00007dd052fe266d  sub rsp, 0xF0
00007dd052fe2674  vmovaps [rsp], xmm0
00007dd052fe2679  vmovaps [rsp+0x10], xmm1
00007dd052fe267f  vmovaps [rsp+0x20], xmm2
00007dd052fe2685  vmovaps [rsp+0x30], xmm3
00007dd052fe268b  vmovaps [rsp+0x40], xmm4
00007dd052fe2691  vmovaps [rsp+0x50], xmm5
00007dd052fe2697  vmovaps [rsp+0x60], xmm7
00007dd052fe269d  vmovaps [rsp+0x70], xmm8
00007dd052fe26a3  vmovaps [rsp+0x80], xmm9
00007dd052fe26ac  vmovaps [rsp+0x90], xmm10
00007dd052fe26b5  vmovaps [rsp+0xA0], xmm11
00007dd052fe26be  vmovaps [rsp+0xB0], xmm12
00007dd052fe26c7  vmovaps [rsp+0xC0], xmm13
00007dd052fe26d0  vmovaps [rsp+0xD0], xmm14
00007dd052fe26d9  vmovaps [rsp+0xE0], xmm15
00007dd052fe26e2  sub rsp, 0x30
00007dd052fe26e6  movaps [rsp], xmm6
00007dd052fe26ea  movaps [rsp+0x10], xmm10
00007dd052fe26f0  movaps [rsp+0x20], xmm8
00007dd052fe26f6  lea rdi, [rsp]
00007dd052fe26fa  mov esi, 0x00
00007dd052fe26ff  mov rax, 0x61D0404B9530
00007dd052fe2709  call rax
00007dd052fe270b  movaps xmm6, [rsp]
00007dd052fe270f  add rsp, 0x30
00007dd052fe2713  vmovaps xmm0, [rsp]
00007dd052fe2718  vmovaps xmm1, [rsp+0x10]
00007dd052fe271e  vmovaps xmm2, [rsp+0x20]
00007dd052fe2724  vmovaps xmm3, [rsp+0x30]
00007dd052fe272a  vmovaps xmm4, [rsp+0x40]
00007dd052fe2730  vmovaps xmm5, [rsp+0x50]
00007dd052fe2736  vmovaps xmm7, [rsp+0x60]
00007dd052fe273c  vmovaps xmm8, [rsp+0x70]
00007dd052fe2742  vmovaps xmm9, [rsp+0x80]
00007dd052fe274b  vmovaps xmm10, [rsp+0x90]
00007dd052fe2754  vmovaps xmm11, [rsp+0xA0]
00007dd052fe275d  vmovaps xmm12, [rsp+0xB0]
00007dd052fe2766  vmovaps xmm13, [rsp+0xC0]
00007dd052fe276f  vmovaps xmm14, [rsp+0xD0]
00007dd052fe2778  vmovaps xmm15, [rsp+0xE0]
00007dd052fe2781  add rsp, 0xF0
00007dd052fe2788  pop r11
00007dd052fe278a  pop r10
00007dd052fe278c  pop r9
00007dd052fe278e  pop r8
00007dd052fe2790  pop rsi
00007dd052fe2791  pop rdi
00007dd052fe2792  pop rdx
00007dd052fe2793  pop rcx
00007dd052fe2794  pop rax
00007dd052fe2795  add rsp, 0x08
00007dd052fe2799  jmp 0x00007DD052FDF5B8
00007dd052fe279e  sub rsp, 0x08
00007dd052fe27a2  push rax
00007dd052fe27a3  push rcx
00007dd052fe27a4  push rdx
00007dd052fe27a5  push rdi
00007dd052fe27a6  push rsi
00007dd052fe27a7  push r8
00007dd052fe27a9  push r9
00007dd052fe27ab  push r10
00007dd052fe27ad  push r11
00007dd052fe27af  sub rsp, 0xF0
00007dd052fe27b6  vmovaps [rsp], xmm0
00007dd052fe27bb  vmovaps [rsp+0x10], xmm1
00007dd052fe27c1  vmovaps [rsp+0x20], xmm2
00007dd052fe27c7  vmovaps [rsp+0x30], xmm3
00007dd052fe27cd  vmovaps [rsp+0x40], xmm4
00007dd052fe27d3  vmovaps [rsp+0x50], xmm5
00007dd052fe27d9  vmovaps [rsp+0x60], xmm6
00007dd052fe27df  vmovaps [rsp+0x70], xmm7
00007dd052fe27e5  vmovaps [rsp+0x80], xmm8
00007dd052fe27ee  vmovaps [rsp+0x90], xmm9
00007dd052fe27f7  vmovaps [rsp+0xA0], xmm11
00007dd052fe2800  vmovaps [rsp+0xB0], xmm12
00007dd052fe2809  vmovaps [rsp+0xC0], xmm13
00007dd052fe2812  vmovaps [rsp+0xD0], xmm14
00007dd052fe281b  vmovaps [rsp+0xE0], xmm15
00007dd052fe2824  sub rsp, 0x30
00007dd052fe2828  movaps [rsp], xmm10
00007dd052fe282d  movaps [rsp+0x10], xmm8
00007dd052fe2833  movaps [rsp+0x20], xmm14
00007dd052fe2839  lea rdi, [rsp]
00007dd052fe283d  mov esi, 0x00
00007dd052fe2842  mov rax, 0x61D0404B9530
00007dd052fe284c  call rax
00007dd052fe284e  movaps xmm10, [rsp]
00007dd052fe2853  add rsp, 0x30
00007dd052fe2857  vmovaps xmm0, [rsp]
00007dd052fe285c  vmovaps xmm1, [rsp+0x10]
00007dd052fe2862  vmovaps xmm2, [rsp+0x20]
00007dd052fe2868  vmovaps xmm3, [rsp+0x30]
00007dd052fe286e  vmovaps xmm4, [rsp+0x40]
00007dd052fe2874  vmovaps xmm5, [rsp+0x50]
00007dd052fe287a  vmovaps xmm6, [rsp+0x60]
00007dd052fe2880  vmovaps xmm7, [rsp+0x70]
00007dd052fe2886  vmovaps xmm8, [rsp+0x80]
00007dd052fe288f  vmovaps xmm9, [rsp+0x90]
00007dd052fe2898  vmovaps xmm11, [rsp+0xA0]
00007dd052fe28a1  vmovaps xmm12, [rsp+0xB0]
00007dd052fe28aa  vmovaps xmm13, [rsp+0xC0]
00007dd052fe28b3  vmovaps xmm14, [rsp+0xD0]
00007dd052fe28bc  vmovaps xmm15, [rsp+0xE0]
00007dd052fe28c5  add rsp, 0xF0
00007dd052fe28cc  pop r11
00007dd052fe28ce  pop r10
00007dd052fe28d0  pop r9
00007dd052fe28d2  pop r8
00007dd052fe28d4  pop rsi
00007dd052fe28d5  pop rdi
00007dd052fe28d6  pop rdx
00007dd052fe28d7  pop rcx
00007dd052fe28d8  pop rax
00007dd052fe28d9  add rsp, 0x08
00007dd052fe28dd  jmp 0x00007DD052FDF5D8
00007dd052fe28e2  sub rsp, 0x08
00007dd052fe28e6  push rax
00007dd052fe28e7  push rcx
00007dd052fe28e8  push rdx
00007dd052fe28e9  push rdi
00007dd052fe28ea  push rsi
00007dd052fe28eb  push r8
00007dd052fe28ed  push r9
00007dd052fe28ef  push r10
00007dd052fe28f1  push r11
00007dd052fe28f3  sub rsp, 0xF0
00007dd052fe28fa  vmovaps [rsp], xmm0
00007dd052fe28ff  vmovaps [rsp+0x10], xmm1
00007dd052fe2905  vmovaps [rsp+0x20], xmm2
00007dd052fe290b  vmovaps [rsp+0x30], xmm3
00007dd052fe2911  vmovaps [rsp+0x40], xmm4
00007dd052fe2917  vmovaps [rsp+0x50], xmm5
00007dd052fe291d  vmovaps [rsp+0x60], xmm6
00007dd052fe2923  vmovaps [rsp+0x70], xmm7
00007dd052fe2929  vmovaps [rsp+0x80], xmm8
00007dd052fe2932  vmovaps [rsp+0x90], xmm9
00007dd052fe293b  vmovaps [rsp+0xA0], xmm10
00007dd052fe2944  vmovaps [rsp+0xB0], xmm11
00007dd052fe294d  vmovaps [rsp+0xC0], xmm12
00007dd052fe2956  vmovaps [rsp+0xD0], xmm13
00007dd052fe295f  vmovaps [rsp+0xE0], xmm15
00007dd052fe2968  sub rsp, 0x30
00007dd052fe296c  movaps [rsp], xmm14
00007dd052fe2971  movaps [rsp+0x10], xmm8
00007dd052fe2977  movaps [rsp+0x20], xmm4
00007dd052fe297c  lea rdi, [rsp]
00007dd052fe2980  mov esi, 0x00
00007dd052fe2985  mov rax, 0x61D0404B9530
00007dd052fe298f  call rax
00007dd052fe2991  movaps xmm14, [rsp]
00007dd052fe2996  add rsp, 0x30
00007dd052fe299a  vmovaps xmm0, [rsp]
00007dd052fe299f  vmovaps xmm1, [rsp+0x10]
00007dd052fe29a5  vmovaps xmm2, [rsp+0x20]
00007dd052fe29ab  vmovaps xmm3, [rsp+0x30]
00007dd052fe29b1  vmovaps xmm4, [rsp+0x40]
00007dd052fe29b7  vmovaps xmm5, [rsp+0x50]
00007dd052fe29bd  vmovaps xmm6, [rsp+0x60]
00007dd052fe29c3  vmovaps xmm7, [rsp+0x70]
00007dd052fe29c9  vmovaps xmm8, [rsp+0x80]
00007dd052fe29d2  vmovaps xmm9, [rsp+0x90]
00007dd052fe29db  vmovaps xmm10, [rsp+0xA0]
00007dd052fe29e4  vmovaps xmm11, [rsp+0xB0]
00007dd052fe29ed  vmovaps xmm12, [rsp+0xC0]
00007dd052fe29f6  vmovaps xmm13, [rsp+0xD0]
00007dd052fe29ff  vmovaps xmm15, [rsp+0xE0]
00007dd052fe2a08  add rsp, 0xF0
00007dd052fe2a0f  pop r11
00007dd052fe2a11  pop r10
00007dd052fe2a13  pop r9
00007dd052fe2a15  pop r8
00007dd052fe2a17  pop rsi
00007dd052fe2a18  pop rdi
00007dd052fe2a19  pop rdx
00007dd052fe2a1a  pop rcx
00007dd052fe2a1b  pop rax
00007dd052fe2a1c  add rsp, 0x08
00007dd052fe2a20  jmp 0x00007DD052FDF5F8
00007dd052fe2a25  sub rsp, 0x08
00007dd052fe2a29  push rax
00007dd052fe2a2a  push rcx
00007dd052fe2a2b  push rdx
00007dd052fe2a2c  push rdi
00007dd052fe2a2d  push rsi
00007dd052fe2a2e  push r8
00007dd052fe2a30  push r9
00007dd052fe2a32  push r10
00007dd052fe2a34  push r11
00007dd052fe2a36  sub rsp, 0xF0
00007dd052fe2a3d  vmovaps [rsp], xmm0
00007dd052fe2a42  vmovaps [rsp+0x10], xmm1
00007dd052fe2a48  vmovaps [rsp+0x20], xmm2
00007dd052fe2a4e  vmovaps [rsp+0x30], xmm3
00007dd052fe2a54  vmovaps [rsp+0x40], xmm5
00007dd052fe2a5a  vmovaps [rsp+0x50], xmm6
00007dd052fe2a60  vmovaps [rsp+0x60], xmm7
00007dd052fe2a66  vmovaps [rsp+0x70], xmm8
00007dd052fe2a6c  vmovaps [rsp+0x80], xmm9
00007dd052fe2a75  vmovaps [rsp+0x90], xmm10
00007dd052fe2a7e  vmovaps [rsp+0xA0], xmm11
00007dd052fe2a87  vmovaps [rsp+0xB0], xmm12
00007dd052fe2a90  vmovaps [rsp+0xC0], xmm13
00007dd052fe2a99  vmovaps [rsp+0xD0], xmm14
00007dd052fe2aa2  vmovaps [rsp+0xE0], xmm15
00007dd052fe2aab  sub rsp, 0x30
00007dd052fe2aaf  movaps [rsp], xmm4
00007dd052fe2ab3  movaps [rsp+0x10], xmm13
00007dd052fe2ab9  movaps [rsp+0x20], xmm8
00007dd052fe2abf  lea rdi, [rsp]
00007dd052fe2ac3  mov esi, 0x00
00007dd052fe2ac8  mov rax, 0x61D0404B9530
00007dd052fe2ad2  call rax
00007dd052fe2ad4  movaps xmm4, [rsp]
00007dd052fe2ad8  add rsp, 0x30
00007dd052fe2adc  vmovaps xmm0, [rsp]
00007dd052fe2ae1  vmovaps xmm1, [rsp+0x10]
00007dd052fe2ae7  vmovaps xmm2, [rsp+0x20]
00007dd052fe2aed  vmovaps xmm3, [rsp+0x30]
00007dd052fe2af3  vmovaps xmm5, [rsp+0x40]
00007dd052fe2af9  vmovaps xmm6, [rsp+0x50]
00007dd052fe2aff  vmovaps xmm7, [rsp+0x60]
00007dd052fe2b05  vmovaps xmm8, [rsp+0x70]
00007dd052fe2b0b  vmovaps xmm9, [rsp+0x80]
00007dd052fe2b14  vmovaps xmm10, [rsp+0x90]
00007dd052fe2b1d  vmovaps xmm11, [rsp+0xA0]
00007dd052fe2b26  vmovaps xmm12, [rsp+0xB0]
00007dd052fe2b2f  vmovaps xmm13, [rsp+0xC0]
00007dd052fe2b38  vmovaps xmm14, [rsp+0xD0]
00007dd052fe2b41  vmovaps xmm15, [rsp+0xE0]
00007dd052fe2b4a  add rsp, 0xF0
00007dd052fe2b51  pop r11
00007dd052fe2b53  pop r10
00007dd052fe2b55  pop r9
00007dd052fe2b57  pop r8
00007dd052fe2b59  pop rsi
00007dd052fe2b5a  pop rdi
00007dd052fe2b5b  pop rdx
00007dd052fe2b5c  pop rcx
00007dd052fe2b5d  pop rax
00007dd052fe2b5e  add rsp, 0x08
00007dd052fe2b62  jmp 0x00007DD052FDF61D
00007dd052fe2b67  sub rsp, 0x08
00007dd052fe2b6b  push rax
00007dd052fe2b6c  push rcx
00007dd052fe2b6d  push rdx
00007dd052fe2b6e  push rdi
00007dd052fe2b6f  push rsi
00007dd052fe2b70  push r8
00007dd052fe2b72  push r9
00007dd052fe2b74  push r10
00007dd052fe2b76  push r11
00007dd052fe2b78  sub rsp, 0xF0
00007dd052fe2b7f  vmovaps [rsp], xmm0
00007dd052fe2b84  vmovaps [rsp+0x10], xmm1
00007dd052fe2b8a  vmovaps [rsp+0x20], xmm2
00007dd052fe2b90  vmovaps [rsp+0x30], xmm3
00007dd052fe2b96  vmovaps [rsp+0x40], xmm4
00007dd052fe2b9c  vmovaps [rsp+0x50], xmm5
00007dd052fe2ba2  vmovaps [rsp+0x60], xmm6
00007dd052fe2ba8  vmovaps [rsp+0x70], xmm7
00007dd052fe2bae  vmovaps [rsp+0x80], xmm8
00007dd052fe2bb7  vmovaps [rsp+0x90], xmm9
00007dd052fe2bc0  vmovaps [rsp+0xA0], xmm10
00007dd052fe2bc9  vmovaps [rsp+0xB0], xmm11
00007dd052fe2bd2  vmovaps [rsp+0xC0], xmm12
00007dd052fe2bdb  vmovaps [rsp+0xD0], xmm14
00007dd052fe2be4  vmovaps [rsp+0xE0], xmm15
00007dd052fe2bed  sub rsp, 0x30
00007dd052fe2bf1  movaps [rsp], xmm13
00007dd052fe2bf6  movaps [rsp+0x10], xmm15
00007dd052fe2bfc  movaps [rsp+0x20], xmm9
00007dd052fe2c02  lea rdi, [rsp]
00007dd052fe2c06  mov esi, 0x00
00007dd052fe2c0b  mov rax, 0x61D0404B9530
00007dd052fe2c15  call rax
00007dd052fe2c17  movaps xmm13, [rsp]
00007dd052fe2c1c  add rsp, 0x30
00007dd052fe2c20  vmovaps xmm0, [rsp]
00007dd052fe2c25  vmovaps xmm1, [rsp+0x10]
00007dd052fe2c2b  vmovaps xmm2, [rsp+0x20]
00007dd052fe2c31  vmovaps xmm3, [rsp+0x30]
00007dd052fe2c37  vmovaps xmm4, [rsp+0x40]
00007dd052fe2c3d  vmovaps xmm5, [rsp+0x50]
00007dd052fe2c43  vmovaps xmm6, [rsp+0x60]
00007dd052fe2c49  vmovaps xmm7, [rsp+0x70]
00007dd052fe2c4f  vmovaps xmm8, [rsp+0x80]
00007dd052fe2c58  vmovaps xmm9, [rsp+0x90]
00007dd052fe2c61  vmovaps xmm10, [rsp+0xA0]
00007dd052fe2c6a  vmovaps xmm11, [rsp+0xB0]
00007dd052fe2c73  vmovaps xmm12, [rsp+0xC0]
00007dd052fe2c7c  vmovaps xmm14, [rsp+0xD0]
00007dd052fe2c85  vmovaps xmm15, [rsp+0xE0]
00007dd052fe2c8e  add rsp, 0xF0
00007dd052fe2c95  pop r11
00007dd052fe2c97  pop r10
00007dd052fe2c99  pop r9
00007dd052fe2c9b  pop r8
00007dd052fe2c9d  pop rsi
00007dd052fe2c9e  pop rdi
00007dd052fe2c9f  pop rdx
00007dd052fe2ca0  pop rcx
00007dd052fe2ca1  pop rax
00007dd052fe2ca2  add rsp, 0x08
00007dd052fe2ca6  jmp 0x00007DD052FDF638
00007dd052fe2cab  sub rsp, 0x08
00007dd052fe2caf  push rax
00007dd052fe2cb0  push rcx
00007dd052fe2cb1  push rdx
00007dd052fe2cb2  push rdi
00007dd052fe2cb3  push rsi
00007dd052fe2cb4  push r8
00007dd052fe2cb6  push r9
00007dd052fe2cb8  push r10
00007dd052fe2cba  push r11
00007dd052fe2cbc  sub rsp, 0xF0
00007dd052fe2cc3  vmovaps [rsp], xmm0
00007dd052fe2cc8  vmovaps [rsp+0x10], xmm1
00007dd052fe2cce  vmovaps [rsp+0x20], xmm2
00007dd052fe2cd4  vmovaps [rsp+0x30], xmm3
00007dd052fe2cda  vmovaps [rsp+0x40], xmm4
00007dd052fe2ce0  vmovaps [rsp+0x50], xmm5
00007dd052fe2ce6  vmovaps [rsp+0x60], xmm6
00007dd052fe2cec  vmovaps [rsp+0x70], xmm7
00007dd052fe2cf2  vmovaps [rsp+0x80], xmm8
00007dd052fe2cfb  vmovaps [rsp+0x90], xmm9
00007dd052fe2d04  vmovaps [rsp+0xA0], xmm10
00007dd052fe2d0d  vmovaps [rsp+0xB0], xmm11
00007dd052fe2d16  vmovaps [rsp+0xC0], xmm12
00007dd052fe2d1f  vmovaps [rsp+0xD0], xmm13
00007dd052fe2d28  vmovaps [rsp+0xE0], xmm14
00007dd052fe2d31  sub rsp, 0x30
00007dd052fe2d35  movaps [rsp], xmm15
00007dd052fe2d3a  movaps [rsp+0x10], xmm1
00007dd052fe2d3f  movaps [rsp+0x20], xmm5
00007dd052fe2d44  lea rdi, [rsp]
00007dd052fe2d48  mov esi, 0x00
00007dd052fe2d4d  mov rax, 0x61D0404B9530
00007dd052fe2d57  call rax
00007dd052fe2d59  movaps xmm15, [rsp]
00007dd052fe2d5e  add rsp, 0x30
00007dd052fe2d62  vmovaps xmm0, [rsp]
00007dd052fe2d67  vmovaps xmm1, [rsp+0x10]
00007dd052fe2d6d  vmovaps xmm2, [rsp+0x20]
00007dd052fe2d73  vmovaps xmm3, [rsp+0x30]
00007dd052fe2d79  vmovaps xmm4, [rsp+0x40]
00007dd052fe2d7f  vmovaps xmm5, [rsp+0x50]
00007dd052fe2d85  vmovaps xmm6, [rsp+0x60]
00007dd052fe2d8b  vmovaps xmm7, [rsp+0x70]
00007dd052fe2d91  vmovaps xmm8, [rsp+0x80]
00007dd052fe2d9a  vmovaps xmm9, [rsp+0x90]
00007dd052fe2da3  vmovaps xmm10, [rsp+0xA0]
00007dd052fe2dac  vmovaps xmm11, [rsp+0xB0]
00007dd052fe2db5  vmovaps xmm12, [rsp+0xC0]
00007dd052fe2dbe  vmovaps xmm13, [rsp+0xD0]
00007dd052fe2dc7  vmovaps xmm14, [rsp+0xE0]
00007dd052fe2dd0  add rsp, 0xF0
00007dd052fe2dd7  pop r11
00007dd052fe2dd9  pop r10
00007dd052fe2ddb  pop r9
00007dd052fe2ddd  pop r8
00007dd052fe2ddf  pop rsi
00007dd052fe2de0  pop rdi
00007dd052fe2de1  pop rdx
00007dd052fe2de2  pop rcx
00007dd052fe2de3  pop rax
00007dd052fe2de4  add rsp, 0x08
00007dd052fe2de8  jmp 0x00007DD052FDF653
00007dd052fe2ded  call 0x00007DD052EB52F0
00007dd052fe2df2  jmp 0x00007DD052FDF6AE
00007dd052fe2df7  sub rsp, 0x08
00007dd052fe2dfb  push rax
00007dd052fe2dfc  push rcx
00007dd052fe2dfd  push rdx
00007dd052fe2dfe  push rdi
00007dd052fe2dff  push rsi
00007dd052fe2e00  push r8
00007dd052fe2e02  push r9
00007dd052fe2e04  push r10
00007dd052fe2e06  push r11
00007dd052fe2e08  sub rsp, 0xF0
00007dd052fe2e0f  vmovaps [rsp], xmm0
00007dd052fe2e14  vmovaps [rsp+0x10], xmm1
00007dd052fe2e1a  vmovaps [rsp+0x20], xmm2
00007dd052fe2e20  vmovaps [rsp+0x30], xmm3
00007dd052fe2e26  vmovaps [rsp+0x40], xmm4
00007dd052fe2e2c  vmovaps [rsp+0x50], xmm5
00007dd052fe2e32  vmovaps [rsp+0x60], xmm6
00007dd052fe2e38  vmovaps [rsp+0x70], xmm7
00007dd052fe2e3e  vmovaps [rsp+0x80], xmm8
00007dd052fe2e47  vmovaps [rsp+0x90], xmm10
00007dd052fe2e50  vmovaps [rsp+0xA0], xmm11
00007dd052fe2e59  vmovaps [rsp+0xB0], xmm12
00007dd052fe2e62  vmovaps [rsp+0xC0], xmm13
00007dd052fe2e6b  vmovaps [rsp+0xD0], xmm14
00007dd052fe2e74  vmovaps [rsp+0xE0], xmm15
00007dd052fe2e7d  sub rsp, 0x30
00007dd052fe2e81  movaps [rsp], xmm9
00007dd052fe2e86  movaps [rsp+0x10], xmm8
00007dd052fe2e8c  movaps [rsp+0x20], xmm11
00007dd052fe2e92  lea rdi, [rsp]
00007dd052fe2e96  mov esi, 0x00
00007dd052fe2e9b  mov rax, 0x61D0404B9530
00007dd052fe2ea5  call rax
00007dd052fe2ea7  movaps xmm9, [rsp]
00007dd052fe2eac  add rsp, 0x30
00007dd052fe2eb0  vmovaps xmm0, [rsp]
00007dd052fe2eb5  vmovaps xmm1, [rsp+0x10]
00007dd052fe2ebb  vmovaps xmm2, [rsp+0x20]
00007dd052fe2ec1  vmovaps xmm3, [rsp+0x30]
00007dd052fe2ec7  vmovaps xmm4, [rsp+0x40]
00007dd052fe2ecd  vmovaps xmm5, [rsp+0x50]
00007dd052fe2ed3  vmovaps xmm6, [rsp+0x60]
00007dd052fe2ed9  vmovaps xmm7, [rsp+0x70]
00007dd052fe2edf  vmovaps xmm8, [rsp+0x80]
00007dd052fe2ee8  vmovaps xmm10, [rsp+0x90]
00007dd052fe2ef1  vmovaps xmm11, [rsp+0xA0]
00007dd052fe2efa  vmovaps xmm12, [rsp+0xB0]
00007dd052fe2f03  vmovaps xmm13, [rsp+0xC0]
00007dd052fe2f0c  vmovaps xmm14, [rsp+0xD0]
00007dd052fe2f15  vmovaps xmm15, [rsp+0xE0]
00007dd052fe2f1e  add rsp, 0xF0
00007dd052fe2f25  pop r11
00007dd052fe2f27  pop r10
00007dd052fe2f29  pop r9
00007dd052fe2f2b  pop r8
00007dd052fe2f2d  pop rsi
00007dd052fe2f2e  pop rdi
00007dd052fe2f2f  pop rdx
00007dd052fe2f30  pop rcx
00007dd052fe2f31  pop rax
00007dd052fe2f32  add rsp, 0x08
00007dd052fe2f36  jmp 0x00007DD052FDF6E5
00007dd052fe2f3b  sub rsp, 0x08
00007dd052fe2f3f  push rax
00007dd052fe2f40  push rcx
00007dd052fe2f41  push rdx
00007dd052fe2f42  push rdi
00007dd052fe2f43  push rsi
00007dd052fe2f44  push r8
00007dd052fe2f46  push r9
00007dd052fe2f48  push r10
00007dd052fe2f4a  push r11
00007dd052fe2f4c  sub rsp, 0xF0
00007dd052fe2f53  vmovaps [rsp], xmm0
00007dd052fe2f58  vmovaps [rsp+0x10], xmm1
00007dd052fe2f5e  vmovaps [rsp+0x20], xmm2
00007dd052fe2f64  vmovaps [rsp+0x30], xmm3
00007dd052fe2f6a  vmovaps [rsp+0x40], xmm4
00007dd052fe2f70  vmovaps [rsp+0x50], xmm5
00007dd052fe2f76  vmovaps [rsp+0x60], xmm6
00007dd052fe2f7c  vmovaps [rsp+0x70], xmm7
00007dd052fe2f82  vmovaps [rsp+0x80], xmm8
00007dd052fe2f8b  vmovaps [rsp+0x90], xmm9
00007dd052fe2f94  vmovaps [rsp+0xA0], xmm10
00007dd052fe2f9d  vmovaps [rsp+0xB0], xmm12
00007dd052fe2fa6  vmovaps [rsp+0xC0], xmm13
00007dd052fe2faf  vmovaps [rsp+0xD0], xmm14
00007dd052fe2fb8  vmovaps [rsp+0xE0], xmm15
00007dd052fe2fc1  sub rsp, 0x30
00007dd052fe2fc5  movaps [rsp], xmm11
00007dd052fe2fca  movaps [rsp+0x10], xmm10
00007dd052fe2fd0  movaps [rsp+0x20], xmm6
00007dd052fe2fd5  lea rdi, [rsp]
00007dd052fe2fd9  mov esi, 0x00
00007dd052fe2fde  mov rax, 0x61D0404B9530
00007dd052fe2fe8  call rax
00007dd052fe2fea  movaps xmm11, [rsp]
00007dd052fe2fef  add rsp, 0x30
00007dd052fe2ff3  vmovaps xmm0, [rsp]
00007dd052fe2ff8  vmovaps xmm1, [rsp+0x10]
00007dd052fe2ffe  vmovaps xmm2, [rsp+0x20]
00007dd052fe3004  vmovaps xmm3, [rsp+0x30]
00007dd052fe300a  vmovaps xmm4, [rsp+0x40]
00007dd052fe3010  vmovaps xmm5, [rsp+0x50]
00007dd052fe3016  vmovaps xmm6, [rsp+0x60]
00007dd052fe301c  vmovaps xmm7, [rsp+0x70]
00007dd052fe3022  vmovaps xmm8, [rsp+0x80]
00007dd052fe302b  vmovaps xmm9, [rsp+0x90]
00007dd052fe3034  vmovaps xmm10, [rsp+0xA0]
00007dd052fe303d  vmovaps xmm12, [rsp+0xB0]
00007dd052fe3046  vmovaps xmm13, [rsp+0xC0]
00007dd052fe304f  vmovaps xmm14, [rsp+0xD0]
00007dd052fe3058  vmovaps xmm15, [rsp+0xE0]
00007dd052fe3061  add rsp, 0xF0
00007dd052fe3068  pop r11
00007dd052fe306a  pop r10
00007dd052fe306c  pop r9
00007dd052fe306e  pop r8
00007dd052fe3070  pop rsi
00007dd052fe3071  pop rdi
00007dd052fe3072  pop rdx
00007dd052fe3073  pop rcx
00007dd052fe3074  pop rax
00007dd052fe3075  add rsp, 0x08
00007dd052fe3079  jmp 0x00007DD052FDF700
00007dd052fe307e  sub rsp, 0x08
00007dd052fe3082  push rax
00007dd052fe3083  push rcx
00007dd052fe3084  push rdx
00007dd052fe3085  push rdi
00007dd052fe3086  push rsi
00007dd052fe3087  push r8
00007dd052fe3089  push r9
00007dd052fe308b  push r10
00007dd052fe308d  push r11
00007dd052fe308f  sub rsp, 0xF0
00007dd052fe3096  vmovaps [rsp], xmm0
00007dd052fe309b  vmovaps [rsp+0x10], xmm1
00007dd052fe30a1  vmovaps [rsp+0x20], xmm2
00007dd052fe30a7  vmovaps [rsp+0x30], xmm3
00007dd052fe30ad  vmovaps [rsp+0x40], xmm4
00007dd052fe30b3  vmovaps [rsp+0x50], xmm5
00007dd052fe30b9  vmovaps [rsp+0x60], xmm6
00007dd052fe30bf  vmovaps [rsp+0x70], xmm7
00007dd052fe30c5  vmovaps [rsp+0x80], xmm8
00007dd052fe30ce  vmovaps [rsp+0x90], xmm9
00007dd052fe30d7  vmovaps [rsp+0xA0], xmm11
00007dd052fe30e0  vmovaps [rsp+0xB0], xmm12
00007dd052fe30e9  vmovaps [rsp+0xC0], xmm13
00007dd052fe30f2  vmovaps [rsp+0xD0], xmm14
00007dd052fe30fb  vmovaps [rsp+0xE0], xmm15
00007dd052fe3104  sub rsp, 0x30
00007dd052fe3108  movaps [rsp], xmm10
00007dd052fe310d  movaps [rsp+0x10], xmm14
00007dd052fe3113  movaps [rsp+0x20], xmm4
00007dd052fe3118  lea rdi, [rsp]
00007dd052fe311c  mov esi, 0x00
00007dd052fe3121  mov rax, 0x61D0404B9530
00007dd052fe312b  call rax
00007dd052fe312d  movaps xmm10, [rsp]
00007dd052fe3132  add rsp, 0x30
00007dd052fe3136  vmovaps xmm0, [rsp]
00007dd052fe313b  vmovaps xmm1, [rsp+0x10]
00007dd052fe3141  vmovaps xmm2, [rsp+0x20]
00007dd052fe3147  vmovaps xmm3, [rsp+0x30]
00007dd052fe314d  vmovaps xmm4, [rsp+0x40]
00007dd052fe3153  vmovaps xmm5, [rsp+0x50]
00007dd052fe3159  vmovaps xmm6, [rsp+0x60]
00007dd052fe315f  vmovaps xmm7, [rsp+0x70]
00007dd052fe3165  vmovaps xmm8, [rsp+0x80]
00007dd052fe316e  vmovaps xmm9, [rsp+0x90]
00007dd052fe3177  vmovaps xmm11, [rsp+0xA0]
00007dd052fe3180  vmovaps xmm12, [rsp+0xB0]
00007dd052fe3189  vmovaps xmm13, [rsp+0xC0]
00007dd052fe3192  vmovaps xmm14, [rsp+0xD0]
00007dd052fe319b  vmovaps xmm15, [rsp+0xE0]
00007dd052fe31a4  add rsp, 0xF0
00007dd052fe31ab  pop r11
00007dd052fe31ad  pop r10
00007dd052fe31af  pop r9
00007dd052fe31b1  pop r8
00007dd052fe31b3  pop rsi
00007dd052fe31b4  pop rdi
00007dd052fe31b5  pop rdx
00007dd052fe31b6  pop rcx
00007dd052fe31b7  pop rax
00007dd052fe31b8  add rsp, 0x08
00007dd052fe31bc  jmp 0x00007DD052FDF71B
00007dd052fe31c1  sub rsp, 0x08
00007dd052fe31c5  push rax
00007dd052fe31c6  push rcx
00007dd052fe31c7  push rdx
00007dd052fe31c8  push rdi
00007dd052fe31c9  push rsi
00007dd052fe31ca  push r8
00007dd052fe31cc  push r9
00007dd052fe31ce  push r10
00007dd052fe31d0  push r11
00007dd052fe31d2  sub rsp, 0xF0
00007dd052fe31d9  vmovaps [rsp], xmm0
00007dd052fe31de  vmovaps [rsp+0x10], xmm1
00007dd052fe31e4  vmovaps [rsp+0x20], xmm2
00007dd052fe31ea  vmovaps [rsp+0x30], xmm3
00007dd052fe31f0  vmovaps [rsp+0x40], xmm4
00007dd052fe31f6  vmovaps [rsp+0x50], xmm5
00007dd052fe31fc  vmovaps [rsp+0x60], xmm6
00007dd052fe3202  vmovaps [rsp+0x70], xmm7
00007dd052fe3208  vmovaps [rsp+0x80], xmm9
00007dd052fe3211  vmovaps [rsp+0x90], xmm10
00007dd052fe321a  vmovaps [rsp+0xA0], xmm11
00007dd052fe3223  vmovaps [rsp+0xB0], xmm12
00007dd052fe322c  vmovaps [rsp+0xC0], xmm13
00007dd052fe3235  vmovaps [rsp+0xD0], xmm14
00007dd052fe323e  vmovaps [rsp+0xE0], xmm15
00007dd052fe3247  sub rsp, 0x30
00007dd052fe324b  movaps [rsp], xmm8
00007dd052fe3250  movaps [rsp+0x10], xmm1
00007dd052fe3255  movaps [rsp+0x20], xmm14
00007dd052fe325b  lea rdi, [rsp]
00007dd052fe325f  mov esi, 0x00
00007dd052fe3264  mov rax, 0x61D0404B9530
00007dd052fe326e  call rax
00007dd052fe3270  movaps xmm8, [rsp]
00007dd052fe3275  add rsp, 0x30
00007dd052fe3279  vmovaps xmm0, [rsp]
00007dd052fe327e  vmovaps xmm1, [rsp+0x10]
00007dd052fe3284  vmovaps xmm2, [rsp+0x20]
00007dd052fe328a  vmovaps xmm3, [rsp+0x30]
00007dd052fe3290  vmovaps xmm4, [rsp+0x40]
00007dd052fe3296  vmovaps xmm5, [rsp+0x50]
00007dd052fe329c  vmovaps xmm6, [rsp+0x60]
00007dd052fe32a2  vmovaps xmm7, [rsp+0x70]
00007dd052fe32a8  vmovaps xmm9, [rsp+0x80]
00007dd052fe32b1  vmovaps xmm10, [rsp+0x90]
00007dd052fe32ba  vmovaps xmm11, [rsp+0xA0]
00007dd052fe32c3  vmovaps xmm12, [rsp+0xB0]
00007dd052fe32cc  vmovaps xmm13, [rsp+0xC0]
00007dd052fe32d5  vmovaps xmm14, [rsp+0xD0]
00007dd052fe32de  vmovaps xmm15, [rsp+0xE0]
00007dd052fe32e7  add rsp, 0xF0
00007dd052fe32ee  pop r11
00007dd052fe32f0  pop r10
00007dd052fe32f2  pop r9
00007dd052fe32f4  pop r8
00007dd052fe32f6  pop rsi
00007dd052fe32f7  pop rdi
00007dd052fe32f8  pop rdx
00007dd052fe32f9  pop rcx
00007dd052fe32fa  pop rax
00007dd052fe32fb  add rsp, 0x08
00007dd052fe32ff  jmp 0x00007DD052FDF741
00007dd052fe3304  sub rsp, 0x08
00007dd052fe3308  push rax
00007dd052fe3309  push rcx
00007dd052fe330a  push rdx
00007dd052fe330b  push rdi
00007dd052fe330c  push rsi
00007dd052fe330d  push r8
00007dd052fe330f  push r9
00007dd052fe3311  push r10
00007dd052fe3313  push r11
00007dd052fe3315  sub rsp, 0xF0
00007dd052fe331c  vmovaps [rsp], xmm0
00007dd052fe3321  vmovaps [rsp+0x10], xmm1
00007dd052fe3327  vmovaps [rsp+0x20], xmm2
00007dd052fe332d  vmovaps [rsp+0x30], xmm3
00007dd052fe3333  vmovaps [rsp+0x40], xmm4
00007dd052fe3339  vmovaps [rsp+0x50], xmm5
00007dd052fe333f  vmovaps [rsp+0x60], xmm7
00007dd052fe3345  vmovaps [rsp+0x70], xmm8
00007dd052fe334b  vmovaps [rsp+0x80], xmm9
00007dd052fe3354  vmovaps [rsp+0x90], xmm10
00007dd052fe335d  vmovaps [rsp+0xA0], xmm11
00007dd052fe3366  vmovaps [rsp+0xB0], xmm12
00007dd052fe336f  vmovaps [rsp+0xC0], xmm13
00007dd052fe3378  vmovaps [rsp+0xD0], xmm14
00007dd052fe3381  vmovaps [rsp+0xE0], xmm15
00007dd052fe338a  sub rsp, 0x30
00007dd052fe338e  movaps [rsp], xmm6
00007dd052fe3392  movaps [rsp+0x10], xmm1
00007dd052fe3397  movaps [rsp+0x20], xmm14
00007dd052fe339d  lea rdi, [rsp]
00007dd052fe33a1  mov esi, 0x00
00007dd052fe33a6  mov rax, 0x61D0404B9530
00007dd052fe33b0  call rax
00007dd052fe33b2  movaps xmm6, [rsp]
00007dd052fe33b6  add rsp, 0x30
00007dd052fe33ba  vmovaps xmm0, [rsp]
00007dd052fe33bf  vmovaps xmm1, [rsp+0x10]
00007dd052fe33c5  vmovaps xmm2, [rsp+0x20]
00007dd052fe33cb  vmovaps xmm3, [rsp+0x30]
00007dd052fe33d1  vmovaps xmm4, [rsp+0x40]
00007dd052fe33d7  vmovaps xmm5, [rsp+0x50]
00007dd052fe33dd  vmovaps xmm7, [rsp+0x60]
00007dd052fe33e3  vmovaps xmm8, [rsp+0x70]
00007dd052fe33e9  vmovaps xmm9, [rsp+0x80]
00007dd052fe33f2  vmovaps xmm10, [rsp+0x90]
00007dd052fe33fb  vmovaps xmm11, [rsp+0xA0]
00007dd052fe3404  vmovaps xmm12, [rsp+0xB0]
00007dd052fe340d  vmovaps xmm13, [rsp+0xC0]
00007dd052fe3416  vmovaps xmm14, [rsp+0xD0]
00007dd052fe341f  vmovaps xmm15, [rsp+0xE0]
00007dd052fe3428  add rsp, 0xF0
00007dd052fe342f  pop r11
00007dd052fe3431  pop r10
00007dd052fe3433  pop r9
00007dd052fe3435  pop r8
00007dd052fe3437  pop rsi
00007dd052fe3438  pop rdi
00007dd052fe3439  pop rdx
00007dd052fe343a  pop rcx
00007dd052fe343b  pop rax
00007dd052fe343c  add rsp, 0x08
00007dd052fe3440  jmp 0x00007DD052FDF76D
00007dd052fe3445  sub rsp, 0x08
00007dd052fe3449  push rax
00007dd052fe344a  push rcx
00007dd052fe344b  push rdx
00007dd052fe344c  push rdi
00007dd052fe344d  push rsi
00007dd052fe344e  push r8
00007dd052fe3450  push r9
00007dd052fe3452  push r10
00007dd052fe3454  push r11
00007dd052fe3456  sub rsp, 0xF0
00007dd052fe345d  vmovaps [rsp], xmm0
00007dd052fe3462  vmovaps [rsp+0x10], xmm1
00007dd052fe3468  vmovaps [rsp+0x20], xmm2
00007dd052fe346e  vmovaps [rsp+0x30], xmm3
00007dd052fe3474  vmovaps [rsp+0x40], xmm4
00007dd052fe347a  vmovaps [rsp+0x50], xmm5
00007dd052fe3480  vmovaps [rsp+0x60], xmm6
00007dd052fe3486  vmovaps [rsp+0x70], xmm7
00007dd052fe348c  vmovaps [rsp+0x80], xmm8
00007dd052fe3495  vmovaps [rsp+0x90], xmm9
00007dd052fe349e  vmovaps [rsp+0xA0], xmm10
00007dd052fe34a7  vmovaps [rsp+0xB0], xmm11
00007dd052fe34b0  vmovaps [rsp+0xC0], xmm12
00007dd052fe34b9  vmovaps [rsp+0xD0], xmm13
00007dd052fe34c2  vmovaps [rsp+0xE0], xmm15
00007dd052fe34cb  sub rsp, 0x30
00007dd052fe34cf  movaps [rsp], xmm14
00007dd052fe34d4  movaps [rsp+0x10], xmm12
00007dd052fe34da  movaps [rsp+0x20], xmm1
00007dd052fe34df  lea rdi, [rsp]
00007dd052fe34e3  mov esi, 0x00
00007dd052fe34e8  mov rax, 0x61D0404B9530
00007dd052fe34f2  call rax
00007dd052fe34f4  movaps xmm14, [rsp]
00007dd052fe34f9  add rsp, 0x30
00007dd052fe34fd  vmovaps xmm0, [rsp]
00007dd052fe3502  vmovaps xmm1, [rsp+0x10]
00007dd052fe3508  vmovaps xmm2, [rsp+0x20]
00007dd052fe350e  vmovaps xmm3, [rsp+0x30]
00007dd052fe3514  vmovaps xmm4, [rsp+0x40]
00007dd052fe351a  vmovaps xmm5, [rsp+0x50]
00007dd052fe3520  vmovaps xmm6, [rsp+0x60]
00007dd052fe3526  vmovaps xmm7, [rsp+0x70]
00007dd052fe352c  vmovaps xmm8, [rsp+0x80]
00007dd052fe3535  vmovaps xmm9, [rsp+0x90]
00007dd052fe353e  vmovaps xmm10, [rsp+0xA0]
00007dd052fe3547  vmovaps xmm11, [rsp+0xB0]
00007dd052fe3550  vmovaps xmm12, [rsp+0xC0]
00007dd052fe3559  vmovaps xmm13, [rsp+0xD0]
00007dd052fe3562  vmovaps xmm15, [rsp+0xE0]
00007dd052fe356b  add rsp, 0xF0
00007dd052fe3572  pop r11
00007dd052fe3574  pop r10
00007dd052fe3576  pop r9
00007dd052fe3578  pop r8
00007dd052fe357a  pop rsi
00007dd052fe357b  pop rdi
00007dd052fe357c  pop rdx
00007dd052fe357d  pop rcx
00007dd052fe357e  pop rax
00007dd052fe357f  add rsp, 0x08
00007dd052fe3583  jmp 0x00007DD052FDF793
00007dd052fe3588  sub rsp, 0x08
00007dd052fe358c  push rax
00007dd052fe358d  push rcx
00007dd052fe358e  push rdx
00007dd052fe358f  push rdi
00007dd052fe3590  push rsi
00007dd052fe3591  push r8
00007dd052fe3593  push r9
00007dd052fe3595  push r10
00007dd052fe3597  push r11
00007dd052fe3599  sub rsp, 0xF0
00007dd052fe35a0  vmovaps [rsp], xmm0
00007dd052fe35a5  vmovaps [rsp+0x10], xmm2
00007dd052fe35ab  vmovaps [rsp+0x20], xmm3
00007dd052fe35b1  vmovaps [rsp+0x30], xmm4
00007dd052fe35b7  vmovaps [rsp+0x40], xmm5
00007dd052fe35bd  vmovaps [rsp+0x50], xmm6
00007dd052fe35c3  vmovaps [rsp+0x60], xmm7
00007dd052fe35c9  vmovaps [rsp+0x70], xmm8
00007dd052fe35cf  vmovaps [rsp+0x80], xmm9
00007dd052fe35d8  vmovaps [rsp+0x90], xmm10
00007dd052fe35e1  vmovaps [rsp+0xA0], xmm11
00007dd052fe35ea  vmovaps [rsp+0xB0], xmm12
00007dd052fe35f3  vmovaps [rsp+0xC0], xmm13
00007dd052fe35fc  vmovaps [rsp+0xD0], xmm14
00007dd052fe3605  vmovaps [rsp+0xE0], xmm15
00007dd052fe360e  sub rsp, 0x30
00007dd052fe3612  movaps [rsp], xmm1
00007dd052fe3616  movaps [rsp+0x10], xmm13
00007dd052fe361c  movaps [rsp+0x20], xmm9
00007dd052fe3622  lea rdi, [rsp]
00007dd052fe3626  mov esi, 0x00
00007dd052fe362b  mov rax, 0x61D0404B9530
00007dd052fe3635  call rax
00007dd052fe3637  movaps xmm1, [rsp]
00007dd052fe363b  add rsp, 0x30
00007dd052fe363f  vmovaps xmm0, [rsp]
00007dd052fe3644  vmovaps xmm2, [rsp+0x10]
00007dd052fe364a  vmovaps xmm3, [rsp+0x20]
00007dd052fe3650  vmovaps xmm4, [rsp+0x30]
00007dd052fe3656  vmovaps xmm5, [rsp+0x40]
00007dd052fe365c  vmovaps xmm6, [rsp+0x50]
00007dd052fe3662  vmovaps xmm7, [rsp+0x60]
00007dd052fe3668  vmovaps xmm8, [rsp+0x70]
00007dd052fe366e  vmovaps xmm9, [rsp+0x80]
00007dd052fe3677  vmovaps xmm10, [rsp+0x90]
00007dd052fe3680  vmovaps xmm11, [rsp+0xA0]
00007dd052fe3689  vmovaps xmm12, [rsp+0xB0]
00007dd052fe3692  vmovaps xmm13, [rsp+0xC0]
00007dd052fe369b  vmovaps xmm14, [rsp+0xD0]
00007dd052fe36a4  vmovaps xmm15, [rsp+0xE0]
00007dd052fe36ad  add rsp, 0xF0
00007dd052fe36b4  pop r11
00007dd052fe36b6  pop r10
00007dd052fe36b8  pop r9
00007dd052fe36ba  pop r8
00007dd052fe36bc  pop rsi
00007dd052fe36bd  pop rdi
00007dd052fe36be  pop rdx
00007dd052fe36bf  pop rcx
00007dd052fe36c0  pop rax
00007dd052fe36c1  add rsp, 0x08
00007dd052fe36c5  jmp 0x00007DD052FDF7AD
00007dd052fe36ca  sub rsp, 0x08
00007dd052fe36ce  push rax
00007dd052fe36cf  push rcx
00007dd052fe36d0  push rdx
00007dd052fe36d1  push rdi
00007dd052fe36d2  push rsi
00007dd052fe36d3  push r8
00007dd052fe36d5  push r9
00007dd052fe36d7  push r10
00007dd052fe36d9  push r11
00007dd052fe36db  sub rsp, 0xF0
00007dd052fe36e2  vmovaps [rsp], xmm0
00007dd052fe36e7  vmovaps [rsp+0x10], xmm1
00007dd052fe36ed  vmovaps [rsp+0x20], xmm2
00007dd052fe36f3  vmovaps [rsp+0x30], xmm3
00007dd052fe36f9  vmovaps [rsp+0x40], xmm4
00007dd052fe36ff  vmovaps [rsp+0x50], xmm5
00007dd052fe3705  vmovaps [rsp+0x60], xmm6
00007dd052fe370b  vmovaps [rsp+0x70], xmm7
00007dd052fe3711  vmovaps [rsp+0x80], xmm8
00007dd052fe371a  vmovaps [rsp+0x90], xmm9
00007dd052fe3723  vmovaps [rsp+0xA0], xmm10
00007dd052fe372c  vmovaps [rsp+0xB0], xmm11
00007dd052fe3735  vmovaps [rsp+0xC0], xmm13
00007dd052fe373e  vmovaps [rsp+0xD0], xmm14
00007dd052fe3747  vmovaps [rsp+0xE0], xmm15
00007dd052fe3750  sub rsp, 0x30
00007dd052fe3754  movaps [rsp], xmm12
00007dd052fe3759  movaps [rsp+0x10], xmm7
00007dd052fe375e  movaps [rsp+0x20], xmm13
00007dd052fe3764  lea rdi, [rsp]
00007dd052fe3768  mov esi, 0x00
00007dd052fe376d  mov rax, 0x61D0404B9530
00007dd052fe3777  call rax
00007dd052fe3779  movaps xmm12, [rsp]
00007dd052fe377e  add rsp, 0x30
00007dd052fe3782  vmovaps xmm0, [rsp]
00007dd052fe3787  vmovaps xmm1, [rsp+0x10]
00007dd052fe378d  vmovaps xmm2, [rsp+0x20]
00007dd052fe3793  vmovaps xmm3, [rsp+0x30]
00007dd052fe3799  vmovaps xmm4, [rsp+0x40]
00007dd052fe379f  vmovaps xmm5, [rsp+0x50]
00007dd052fe37a5  vmovaps xmm6, [rsp+0x60]
00007dd052fe37ab  vmovaps xmm7, [rsp+0x70]
00007dd052fe37b1  vmovaps xmm8, [rsp+0x80]
00007dd052fe37ba  vmovaps xmm9, [rsp+0x90]
00007dd052fe37c3  vmovaps xmm10, [rsp+0xA0]
00007dd052fe37cc  vmovaps xmm11, [rsp+0xB0]
00007dd052fe37d5  vmovaps xmm13, [rsp+0xC0]
00007dd052fe37de  vmovaps xmm14, [rsp+0xD0]
00007dd052fe37e7  vmovaps xmm15, [rsp+0xE0]
00007dd052fe37f0  add rsp, 0xF0
00007dd052fe37f7  pop r11
00007dd052fe37f9  pop r10
00007dd052fe37fb  pop r9
00007dd052fe37fd  pop r8
00007dd052fe37ff  pop rsi
00007dd052fe3800  pop rdi
00007dd052fe3801  pop rdx
00007dd052fe3802  pop rcx
00007dd052fe3803  pop rax
00007dd052fe3804  add rsp, 0x08
00007dd052fe3808  jmp 0x00007DD052FDF7D4
00007dd052fe380d  sub rsp, 0x08
00007dd052fe3811  push rax
00007dd052fe3812  push rcx
00007dd052fe3813  push rdx
00007dd052fe3814  push rdi
00007dd052fe3815  push rsi
00007dd052fe3816  push r8
00007dd052fe3818  push r9
00007dd052fe381a  push r10
00007dd052fe381c  push r11
00007dd052fe381e  sub rsp, 0xF0
00007dd052fe3825  vmovaps [rsp], xmm0
00007dd052fe382a  vmovaps [rsp+0x10], xmm1
00007dd052fe3830  vmovaps [rsp+0x20], xmm2
00007dd052fe3836  vmovaps [rsp+0x30], xmm3
00007dd052fe383c  vmovaps [rsp+0x40], xmm4
00007dd052fe3842  vmovaps [rsp+0x50], xmm5
00007dd052fe3848  vmovaps [rsp+0x60], xmm6
00007dd052fe384e  vmovaps [rsp+0x70], xmm7
00007dd052fe3854  vmovaps [rsp+0x80], xmm8
00007dd052fe385d  vmovaps [rsp+0x90], xmm9
00007dd052fe3866  vmovaps [rsp+0xA0], xmm10
00007dd052fe386f  vmovaps [rsp+0xB0], xmm11
00007dd052fe3878  vmovaps [rsp+0xC0], xmm12
00007dd052fe3881  vmovaps [rsp+0xD0], xmm14
00007dd052fe388a  vmovaps [rsp+0xE0], xmm15
00007dd052fe3893  sub rsp, 0x30
00007dd052fe3897  movaps [rsp], xmm13
00007dd052fe389c  movaps [rsp+0x10], xmm15
00007dd052fe38a2  movaps [rsp+0x20], xmm8
00007dd052fe38a8  lea rdi, [rsp]
00007dd052fe38ac  mov esi, 0x00
00007dd052fe38b1  mov rax, 0x61D0404B9530
00007dd052fe38bb  call rax
00007dd052fe38bd  movaps xmm13, [rsp]
00007dd052fe38c2  add rsp, 0x30
00007dd052fe38c6  vmovaps xmm0, [rsp]
00007dd052fe38cb  vmovaps xmm1, [rsp+0x10]
00007dd052fe38d1  vmovaps xmm2, [rsp+0x20]
00007dd052fe38d7  vmovaps xmm3, [rsp+0x30]
00007dd052fe38dd  vmovaps xmm4, [rsp+0x40]
00007dd052fe38e3  vmovaps xmm5, [rsp+0x50]
00007dd052fe38e9  vmovaps xmm6, [rsp+0x60]
00007dd052fe38ef  vmovaps xmm7, [rsp+0x70]
00007dd052fe38f5  vmovaps xmm8, [rsp+0x80]
00007dd052fe38fe  vmovaps xmm9, [rsp+0x90]
00007dd052fe3907  vmovaps xmm10, [rsp+0xA0]
00007dd052fe3910  vmovaps xmm11, [rsp+0xB0]
00007dd052fe3919  vmovaps xmm12, [rsp+0xC0]
00007dd052fe3922  vmovaps xmm14, [rsp+0xD0]
00007dd052fe392b  vmovaps xmm15, [rsp+0xE0]
00007dd052fe3934  add rsp, 0xF0
00007dd052fe393b  pop r11
00007dd052fe393d  pop r10
00007dd052fe393f  pop r9
00007dd052fe3941  pop r8
00007dd052fe3943  pop rsi
00007dd052fe3944  pop rdi
00007dd052fe3945  pop rdx
00007dd052fe3946  pop rcx
00007dd052fe3947  pop rax
00007dd052fe3948  add rsp, 0x08
00007dd052fe394c  jmp 0x00007DD052FDF7EF
00007dd052fe3951  sub rsp, 0x08
00007dd052fe3955  push rax
00007dd052fe3956  push rcx
00007dd052fe3957  push rdx
00007dd052fe3958  push rdi
00007dd052fe3959  push rsi
00007dd052fe395a  push r8
00007dd052fe395c  push r9
00007dd052fe395e  push r10
00007dd052fe3960  push r11
00007dd052fe3962  sub rsp, 0xF0
00007dd052fe3969  vmovaps [rsp], xmm0
00007dd052fe396e  vmovaps [rsp+0x10], xmm1
00007dd052fe3974  vmovaps [rsp+0x20], xmm2
00007dd052fe397a  vmovaps [rsp+0x30], xmm3
00007dd052fe3980  vmovaps [rsp+0x40], xmm4
00007dd052fe3986  vmovaps [rsp+0x50], xmm5
00007dd052fe398c  vmovaps [rsp+0x60], xmm6
00007dd052fe3992  vmovaps [rsp+0x70], xmm7
00007dd052fe3998  vmovaps [rsp+0x80], xmm9
00007dd052fe39a1  vmovaps [rsp+0x90], xmm10
00007dd052fe39aa  vmovaps [rsp+0xA0], xmm11
00007dd052fe39b3  vmovaps [rsp+0xB0], xmm12
00007dd052fe39bc  vmovaps [rsp+0xC0], xmm13
00007dd052fe39c5  vmovaps [rsp+0xD0], xmm14
00007dd052fe39ce  vmovaps [rsp+0xE0], xmm15
00007dd052fe39d7  sub rsp, 0x30
00007dd052fe39db  movaps [rsp], xmm8
00007dd052fe39e0  movaps [rsp+0x10], xmm15
00007dd052fe39e6  movaps [rsp+0x20], xmm9
00007dd052fe39ec  lea rdi, [rsp]
00007dd052fe39f0  mov esi, 0x00
00007dd052fe39f5  mov rax, 0x61D0404B9530
00007dd052fe39ff  call rax
00007dd052fe3a01  movaps xmm8, [rsp]
00007dd052fe3a06  add rsp, 0x30
00007dd052fe3a0a  vmovaps xmm0, [rsp]
00007dd052fe3a0f  vmovaps xmm1, [rsp+0x10]
00007dd052fe3a15  vmovaps xmm2, [rsp+0x20]
00007dd052fe3a1b  vmovaps xmm3, [rsp+0x30]
00007dd052fe3a21  vmovaps xmm4, [rsp+0x40]
00007dd052fe3a27  vmovaps xmm5, [rsp+0x50]
00007dd052fe3a2d  vmovaps xmm6, [rsp+0x60]
00007dd052fe3a33  vmovaps xmm7, [rsp+0x70]
00007dd052fe3a39  vmovaps xmm9, [rsp+0x80]
00007dd052fe3a42  vmovaps xmm10, [rsp+0x90]
00007dd052fe3a4b  vmovaps xmm11, [rsp+0xA0]
00007dd052fe3a54  vmovaps xmm12, [rsp+0xB0]
00007dd052fe3a5d  vmovaps xmm13, [rsp+0xC0]
00007dd052fe3a66  vmovaps xmm14, [rsp+0xD0]
00007dd052fe3a6f  vmovaps xmm15, [rsp+0xE0]
00007dd052fe3a78  add rsp, 0xF0
00007dd052fe3a7f  pop r11
00007dd052fe3a81  pop r10
00007dd052fe3a83  pop r9
00007dd052fe3a85  pop r8
00007dd052fe3a87  pop rsi
00007dd052fe3a88  pop rdi
00007dd052fe3a89  pop rdx
00007dd052fe3a8a  pop rcx
00007dd052fe3a8b  pop rax
00007dd052fe3a8c  add rsp, 0x08
00007dd052fe3a90  jmp 0x00007DD052FDF81D
00007dd052fe3a95  sub rsp, 0x08
00007dd052fe3a99  push rax
00007dd052fe3a9a  push rcx
00007dd052fe3a9b  push rdx
00007dd052fe3a9c  push rdi
00007dd052fe3a9d  push rsi
00007dd052fe3a9e  push r8
00007dd052fe3aa0  push r9
00007dd052fe3aa2  push r10
00007dd052fe3aa4  push r11
00007dd052fe3aa6  sub rsp, 0xF0
00007dd052fe3aad  vmovaps [rsp], xmm0
00007dd052fe3ab2  vmovaps [rsp+0x10], xmm1
00007dd052fe3ab8  vmovaps [rsp+0x20], xmm2
00007dd052fe3abe  vmovaps [rsp+0x30], xmm3
00007dd052fe3ac4  vmovaps [rsp+0x40], xmm4
00007dd052fe3aca  vmovaps [rsp+0x50], xmm5
00007dd052fe3ad0  vmovaps [rsp+0x60], xmm6
00007dd052fe3ad6  vmovaps [rsp+0x70], xmm7
00007dd052fe3adc  vmovaps [rsp+0x80], xmm8
00007dd052fe3ae5  vmovaps [rsp+0x90], xmm9
00007dd052fe3aee  vmovaps [rsp+0xA0], xmm10
00007dd052fe3af7  vmovaps [rsp+0xB0], xmm11
00007dd052fe3b00  vmovaps [rsp+0xC0], xmm12
00007dd052fe3b09  vmovaps [rsp+0xD0], xmm13
00007dd052fe3b12  vmovaps [rsp+0xE0], xmm14
00007dd052fe3b1b  sub rsp, 0x30
00007dd052fe3b1f  movaps [rsp], xmm15
00007dd052fe3b24  movaps [rsp+0x10], xmm11
00007dd052fe3b2a  movaps [rsp+0x20], xmm6
00007dd052fe3b2f  lea rdi, [rsp]
00007dd052fe3b33  mov esi, 0x00
00007dd052fe3b38  mov rax, 0x61D0404B9530
00007dd052fe3b42  call rax
00007dd052fe3b44  movaps xmm15, [rsp]
00007dd052fe3b49  add rsp, 0x30
00007dd052fe3b4d  vmovaps xmm0, [rsp]
00007dd052fe3b52  vmovaps xmm1, [rsp+0x10]
00007dd052fe3b58  vmovaps xmm2, [rsp+0x20]
00007dd052fe3b5e  vmovaps xmm3, [rsp+0x30]
00007dd052fe3b64  vmovaps xmm4, [rsp+0x40]
00007dd052fe3b6a  vmovaps xmm5, [rsp+0x50]
00007dd052fe3b70  vmovaps xmm6, [rsp+0x60]
00007dd052fe3b76  vmovaps xmm7, [rsp+0x70]
00007dd052fe3b7c  vmovaps xmm8, [rsp+0x80]
00007dd052fe3b85  vmovaps xmm9, [rsp+0x90]
00007dd052fe3b8e  vmovaps xmm10, [rsp+0xA0]
00007dd052fe3b97  vmovaps xmm11, [rsp+0xB0]
00007dd052fe3ba0  vmovaps xmm12, [rsp+0xC0]
00007dd052fe3ba9  vmovaps xmm13, [rsp+0xD0]
00007dd052fe3bb2  vmovaps xmm14, [rsp+0xE0]
00007dd052fe3bbb  add rsp, 0xF0
00007dd052fe3bc2  pop r11
00007dd052fe3bc4  pop r10
00007dd052fe3bc6  pop r9
00007dd052fe3bc8  pop r8
00007dd052fe3bca  pop rsi
00007dd052fe3bcb  pop rdi
00007dd052fe3bcc  pop rdx
00007dd052fe3bcd  pop rcx
00007dd052fe3bce  pop rax
00007dd052fe3bcf  add rsp, 0x08
00007dd052fe3bd3  jmp 0x00007DD052FDF838
00007dd052fe3bd8  sub rsp, 0x08
00007dd052fe3bdc  push rax
00007dd052fe3bdd  push rcx
00007dd052fe3bde  push rdx
00007dd052fe3bdf  push rdi
00007dd052fe3be0  push rsi
00007dd052fe3be1  push r8
00007dd052fe3be3  push r9
00007dd052fe3be5  push r10
00007dd052fe3be7  push r11
00007dd052fe3be9  sub rsp, 0xF0
00007dd052fe3bf0  vmovaps [rsp], xmm0
00007dd052fe3bf5  vmovaps [rsp+0x10], xmm1
00007dd052fe3bfb  vmovaps [rsp+0x20], xmm2
00007dd052fe3c01  vmovaps [rsp+0x30], xmm3
00007dd052fe3c07  vmovaps [rsp+0x40], xmm4
00007dd052fe3c0d  vmovaps [rsp+0x50], xmm5
00007dd052fe3c13  vmovaps [rsp+0x60], xmm6
00007dd052fe3c19  vmovaps [rsp+0x70], xmm8
00007dd052fe3c1f  vmovaps [rsp+0x80], xmm9
00007dd052fe3c28  vmovaps [rsp+0x90], xmm10
00007dd052fe3c31  vmovaps [rsp+0xA0], xmm11
00007dd052fe3c3a  vmovaps [rsp+0xB0], xmm12
00007dd052fe3c43  vmovaps [rsp+0xC0], xmm13
00007dd052fe3c4c  vmovaps [rsp+0xD0], xmm14
00007dd052fe3c55  vmovaps [rsp+0xE0], xmm15
00007dd052fe3c5e  sub rsp, 0x30
00007dd052fe3c62  movaps [rsp], xmm7
00007dd052fe3c66  movaps [rsp+0x10], xmm11
00007dd052fe3c6c  movaps [rsp+0x20], xmm9
00007dd052fe3c72  lea rdi, [rsp]
00007dd052fe3c76  mov esi, 0x00
00007dd052fe3c7b  mov rax, 0x61D0404B9530
00007dd052fe3c85  call rax
00007dd052fe3c87  movaps xmm7, [rsp]
00007dd052fe3c8b  add rsp, 0x30
00007dd052fe3c8f  vmovaps xmm0, [rsp]
00007dd052fe3c94  vmovaps xmm1, [rsp+0x10]
00007dd052fe3c9a  vmovaps xmm2, [rsp+0x20]
00007dd052fe3ca0  vmovaps xmm3, [rsp+0x30]
00007dd052fe3ca6  vmovaps xmm4, [rsp+0x40]
00007dd052fe3cac  vmovaps xmm5, [rsp+0x50]
00007dd052fe3cb2  vmovaps xmm6, [rsp+0x60]
00007dd052fe3cb8  vmovaps xmm8, [rsp+0x70]
00007dd052fe3cbe  vmovaps xmm9, [rsp+0x80]
00007dd052fe3cc7  vmovaps xmm10, [rsp+0x90]
00007dd052fe3cd0  vmovaps xmm11, [rsp+0xA0]
00007dd052fe3cd9  vmovaps xmm12, [rsp+0xB0]
00007dd052fe3ce2  vmovaps xmm13, [rsp+0xC0]
00007dd052fe3ceb  vmovaps xmm14, [rsp+0xD0]
00007dd052fe3cf4  vmovaps xmm15, [rsp+0xE0]
00007dd052fe3cfd  add rsp, 0xF0
00007dd052fe3d04  pop r11
00007dd052fe3d06  pop r10
00007dd052fe3d08  pop r9
00007dd052fe3d0a  pop r8
00007dd052fe3d0c  pop rsi
00007dd052fe3d0d  pop rdi
00007dd052fe3d0e  pop rdx
00007dd052fe3d0f  pop rcx
00007dd052fe3d10  pop rax
00007dd052fe3d11  add rsp, 0x08
00007dd052fe3d15  jmp 0x00007DD052FDF865
00007dd052fe3d1a  sub rsp, 0x08
00007dd052fe3d1e  push rax
00007dd052fe3d1f  push rcx
00007dd052fe3d20  push rdx
00007dd052fe3d21  push rdi
00007dd052fe3d22  push rsi
00007dd052fe3d23  push r8
00007dd052fe3d25  push r9
00007dd052fe3d27  push r10
00007dd052fe3d29  push r11
00007dd052fe3d2b  sub rsp, 0xF0
00007dd052fe3d32  vmovaps [rsp], xmm0
00007dd052fe3d37  vmovaps [rsp+0x10], xmm1
00007dd052fe3d3d  vmovaps [rsp+0x20], xmm2
00007dd052fe3d43  vmovaps [rsp+0x30], xmm3
00007dd052fe3d49  vmovaps [rsp+0x40], xmm4
00007dd052fe3d4f  vmovaps [rsp+0x50], xmm5
00007dd052fe3d55  vmovaps [rsp+0x60], xmm6
00007dd052fe3d5b  vmovaps [rsp+0x70], xmm7
00007dd052fe3d61  vmovaps [rsp+0x80], xmm8
00007dd052fe3d6a  vmovaps [rsp+0x90], xmm9
00007dd052fe3d73  vmovaps [rsp+0xA0], xmm10
00007dd052fe3d7c  vmovaps [rsp+0xB0], xmm12
00007dd052fe3d85  vmovaps [rsp+0xC0], xmm13
00007dd052fe3d8e  vmovaps [rsp+0xD0], xmm14
00007dd052fe3d97  vmovaps [rsp+0xE0], xmm15
00007dd052fe3da0  sub rsp, 0x30
00007dd052fe3da4  movaps [rsp], xmm11
00007dd052fe3da9  movaps [rsp+0x10], xmm10
00007dd052fe3daf  movaps [rsp+0x20], xmm14
00007dd052fe3db5  lea rdi, [rsp]
00007dd052fe3db9  mov esi, 0x00
00007dd052fe3dbe  mov rax, 0x61D0404B9530
00007dd052fe3dc8  call rax
00007dd052fe3dca  movaps xmm11, [rsp]
00007dd052fe3dcf  add rsp, 0x30
00007dd052fe3dd3  vmovaps xmm0, [rsp]
00007dd052fe3dd8  vmovaps xmm1, [rsp+0x10]
00007dd052fe3dde  vmovaps xmm2, [rsp+0x20]
00007dd052fe3de4  vmovaps xmm3, [rsp+0x30]
00007dd052fe3dea  vmovaps xmm4, [rsp+0x40]
00007dd052fe3df0  vmovaps xmm5, [rsp+0x50]
00007dd052fe3df6  vmovaps xmm6, [rsp+0x60]
00007dd052fe3dfc  vmovaps xmm7, [rsp+0x70]
00007dd052fe3e02  vmovaps xmm8, [rsp+0x80]
00007dd052fe3e0b  vmovaps xmm9, [rsp+0x90]
00007dd052fe3e14  vmovaps xmm10, [rsp+0xA0]
00007dd052fe3e1d  vmovaps xmm12, [rsp+0xB0]
00007dd052fe3e26  vmovaps xmm13, [rsp+0xC0]
00007dd052fe3e2f  vmovaps xmm14, [rsp+0xD0]
00007dd052fe3e38  vmovaps xmm15, [rsp+0xE0]
00007dd052fe3e41  add rsp, 0xF0
00007dd052fe3e48  pop r11
00007dd052fe3e4a  pop r10
00007dd052fe3e4c  pop r9
00007dd052fe3e4e  pop r8
00007dd052fe3e50  pop rsi
00007dd052fe3e51  pop rdi
00007dd052fe3e52  pop rdx
00007dd052fe3e53  pop rcx
00007dd052fe3e54  pop rax
00007dd052fe3e55  add rsp, 0x08
00007dd052fe3e59  jmp 0x00007DD052FDF880
00007dd052fe3e5e  call 0x00007DD052EC33A0
00007dd052fe3e63  jmp 0x00007DD052FDF88A
00007dd052fe3e68  sub rsp, 0x08
00007dd052fe3e6c  push rax
00007dd052fe3e6d  push rcx
00007dd052fe3e6e  push rdx
00007dd052fe3e6f  push rdi
00007dd052fe3e70  push rsi
00007dd052fe3e71  push r8
00007dd052fe3e73  push r9
00007dd052fe3e75  push r10
00007dd052fe3e77  push r11
00007dd052fe3e79  sub rsp, 0xF0
00007dd052fe3e80  vmovaps [rsp], xmm0
00007dd052fe3e85  vmovaps [rsp+0x10], xmm1
00007dd052fe3e8b  vmovaps [rsp+0x20], xmm2
00007dd052fe3e91  vmovaps [rsp+0x30], xmm3
00007dd052fe3e97  vmovaps [rsp+0x40], xmm4
00007dd052fe3e9d  vmovaps [rsp+0x50], xmm5
00007dd052fe3ea3  vmovaps [rsp+0x60], xmm6
00007dd052fe3ea9  vmovaps [rsp+0x70], xmm7
00007dd052fe3eaf  vmovaps [rsp+0x80], xmm8
00007dd052fe3eb8  vmovaps [rsp+0x90], xmm9
00007dd052fe3ec1  vmovaps [rsp+0xA0], xmm11
00007dd052fe3eca  vmovaps [rsp+0xB0], xmm12
00007dd052fe3ed3  vmovaps [rsp+0xC0], xmm13
00007dd052fe3edc  vmovaps [rsp+0xD0], xmm14
00007dd052fe3ee5  vmovaps [rsp+0xE0], xmm15
00007dd052fe3eee  sub rsp, 0x30
00007dd052fe3ef2  movaps [rsp], xmm10
00007dd052fe3ef7  movaps [rsp+0x10], xmm1
00007dd052fe3efc  movaps [rsp+0x20], xmm12
00007dd052fe3f02  lea rdi, [rsp]
00007dd052fe3f06  mov esi, 0x00
00007dd052fe3f0b  mov rax, 0x61D0404B9530
00007dd052fe3f15  call rax
00007dd052fe3f17  movaps xmm10, [rsp]
00007dd052fe3f1c  add rsp, 0x30
00007dd052fe3f20  vmovaps xmm0, [rsp]
00007dd052fe3f25  vmovaps xmm1, [rsp+0x10]
00007dd052fe3f2b  vmovaps xmm2, [rsp+0x20]
00007dd052fe3f31  vmovaps xmm3, [rsp+0x30]
00007dd052fe3f37  vmovaps xmm4, [rsp+0x40]
00007dd052fe3f3d  vmovaps xmm5, [rsp+0x50]
00007dd052fe3f43  vmovaps xmm6, [rsp+0x60]
00007dd052fe3f49  vmovaps xmm7, [rsp+0x70]
00007dd052fe3f4f  vmovaps xmm8, [rsp+0x80]
00007dd052fe3f58  vmovaps xmm9, [rsp+0x90]
00007dd052fe3f61  vmovaps xmm11, [rsp+0xA0]
00007dd052fe3f6a  vmovaps xmm12, [rsp+0xB0]
00007dd052fe3f73  vmovaps xmm13, [rsp+0xC0]
00007dd052fe3f7c  vmovaps xmm14, [rsp+0xD0]
00007dd052fe3f85  vmovaps xmm15, [rsp+0xE0]
00007dd052fe3f8e  add rsp, 0xF0
00007dd052fe3f95  pop r11
00007dd052fe3f97  pop r10
00007dd052fe3f99  pop r9
00007dd052fe3f9b  pop r8
00007dd052fe3f9d  pop rsi
00007dd052fe3f9e  pop rdi
00007dd052fe3f9f  pop rdx
00007dd052fe3fa0  pop rcx
00007dd052fe3fa1  pop rax
00007dd052fe3fa2  add rsp, 0x08
00007dd052fe3fa6  jmp 0x00007DD052FDF8AD
00007dd052fe3fab  sub rsp, 0x08
00007dd052fe3faf  push rax
00007dd052fe3fb0  push rcx
00007dd052fe3fb1  push rdx
00007dd052fe3fb2  push rdi
00007dd052fe3fb3  push rsi
00007dd052fe3fb4  push r8
00007dd052fe3fb6  push r9
00007dd052fe3fb8  push r10
00007dd052fe3fba  push r11
00007dd052fe3fbc  sub rsp, 0xF0
00007dd052fe3fc3  vmovaps [rsp], xmm0
00007dd052fe3fc8  vmovaps [rsp+0x10], xmm1
00007dd052fe3fce  vmovaps [rsp+0x20], xmm2
00007dd052fe3fd4  vmovaps [rsp+0x30], xmm3
00007dd052fe3fda  vmovaps [rsp+0x40], xmm4
00007dd052fe3fe0  vmovaps [rsp+0x50], xmm5
00007dd052fe3fe6  vmovaps [rsp+0x60], xmm6
00007dd052fe3fec  vmovaps [rsp+0x70], xmm7
00007dd052fe3ff2  vmovaps [rsp+0x80], xmm8
00007dd052fe3ffb  vmovaps [rsp+0x90], xmm9
00007dd052fe4004  vmovaps [rsp+0xA0], xmm10
00007dd052fe400d  vmovaps [rsp+0xB0], xmm11
00007dd052fe4016  vmovaps [rsp+0xC0], xmm13
00007dd052fe401f  vmovaps [rsp+0xD0], xmm14
00007dd052fe4028  vmovaps [rsp+0xE0], xmm15
00007dd052fe4031  sub rsp, 0x30
00007dd052fe4035  movaps [rsp], xmm12
00007dd052fe403a  movaps [rsp+0x10], xmm14
00007dd052fe4040  movaps [rsp+0x20], xmm1
00007dd052fe4045  lea rdi, [rsp]
00007dd052fe4049  mov esi, 0x00
00007dd052fe404e  mov rax, 0x61D0404B9530
00007dd052fe4058  call rax
00007dd052fe405a  movaps xmm12, [rsp]
00007dd052fe405f  add rsp, 0x30
00007dd052fe4063  vmovaps xmm0, [rsp]
00007dd052fe4068  vmovaps xmm1, [rsp+0x10]
00007dd052fe406e  vmovaps xmm2, [rsp+0x20]
00007dd052fe4074  vmovaps xmm3, [rsp+0x30]
00007dd052fe407a  vmovaps xmm4, [rsp+0x40]
00007dd052fe4080  vmovaps xmm5, [rsp+0x50]
00007dd052fe4086  vmovaps xmm6, [rsp+0x60]
00007dd052fe408c  vmovaps xmm7, [rsp+0x70]
00007dd052fe4092  vmovaps xmm8, [rsp+0x80]
00007dd052fe409b  vmovaps xmm9, [rsp+0x90]
00007dd052fe40a4  vmovaps xmm10, [rsp+0xA0]
00007dd052fe40ad  vmovaps xmm11, [rsp+0xB0]
00007dd052fe40b6  vmovaps xmm13, [rsp+0xC0]
00007dd052fe40bf  vmovaps xmm14, [rsp+0xD0]
00007dd052fe40c8  vmovaps xmm15, [rsp+0xE0]
00007dd052fe40d1  add rsp, 0xF0
00007dd052fe40d8  pop r11
00007dd052fe40da  pop r10
00007dd052fe40dc  pop r9
00007dd052fe40de  pop r8
00007dd052fe40e0  pop rsi
00007dd052fe40e1  pop rdi
00007dd052fe40e2  pop rdx
00007dd052fe40e3  pop rcx
00007dd052fe40e4  pop rax
00007dd052fe40e5  add rsp, 0x08
00007dd052fe40e9  jmp 0x00007DD052FDF8DC
00007dd052fe40ee  sub rsp, 0x08
00007dd052fe40f2  push rax
00007dd052fe40f3  push rcx
00007dd052fe40f4  push rdx
00007dd052fe40f5  push rdi
00007dd052fe40f6  push rsi
00007dd052fe40f7  push r8
00007dd052fe40f9  push r9
00007dd052fe40fb  push r10
00007dd052fe40fd  push r11
00007dd052fe40ff  sub rsp, 0xF0
00007dd052fe4106  vmovaps [rsp], xmm0
00007dd052fe410b  vmovaps [rsp+0x10], xmm1
00007dd052fe4111  vmovaps [rsp+0x20], xmm2
00007dd052fe4117  vmovaps [rsp+0x30], xmm3
00007dd052fe411d  vmovaps [rsp+0x40], xmm4
00007dd052fe4123  vmovaps [rsp+0x50], xmm5
00007dd052fe4129  vmovaps [rsp+0x60], xmm6
00007dd052fe412f  vmovaps [rsp+0x70], xmm7
00007dd052fe4135  vmovaps [rsp+0x80], xmm8
00007dd052fe413e  vmovaps [rsp+0x90], xmm9
00007dd052fe4147  vmovaps [rsp+0xA0], xmm10
00007dd052fe4150  vmovaps [rsp+0xB0], xmm11
00007dd052fe4159  vmovaps [rsp+0xC0], xmm12
00007dd052fe4162  vmovaps [rsp+0xD0], xmm13
00007dd052fe416b  vmovaps [rsp+0xE0], xmm15
00007dd052fe4174  sub rsp, 0x30
00007dd052fe4178  movaps [rsp], xmm14
00007dd052fe417d  movaps [rsp+0x10], xmm9
00007dd052fe4183  movaps [rsp+0x20], xmm1
00007dd052fe4188  lea rdi, [rsp]
00007dd052fe418c  mov esi, 0x00
00007dd052fe4191  mov rax, 0x61D0404B9530
00007dd052fe419b  call rax
00007dd052fe419d  movaps xmm14, [rsp]
00007dd052fe41a2  add rsp, 0x30
00007dd052fe41a6  vmovaps xmm0, [rsp]
00007dd052fe41ab  vmovaps xmm1, [rsp+0x10]
00007dd052fe41b1  vmovaps xmm2, [rsp+0x20]
00007dd052fe41b7  vmovaps xmm3, [rsp+0x30]
00007dd052fe41bd  vmovaps xmm4, [rsp+0x40]
00007dd052fe41c3  vmovaps xmm5, [rsp+0x50]
00007dd052fe41c9  vmovaps xmm6, [rsp+0x60]
00007dd052fe41cf  vmovaps xmm7, [rsp+0x70]
00007dd052fe41d5  vmovaps xmm8, [rsp+0x80]
00007dd052fe41de  vmovaps xmm9, [rsp+0x90]
00007dd052fe41e7  vmovaps xmm10, [rsp+0xA0]
00007dd052fe41f0  vmovaps xmm11, [rsp+0xB0]
00007dd052fe41f9  vmovaps xmm12, [rsp+0xC0]
00007dd052fe4202  vmovaps xmm13, [rsp+0xD0]
00007dd052fe420b  vmovaps xmm15, [rsp+0xE0]
00007dd052fe4214  add rsp, 0xF0
00007dd052fe421b  pop r11
00007dd052fe421d  pop r10
00007dd052fe421f  pop r9
00007dd052fe4221  pop r8
00007dd052fe4223  pop rsi
00007dd052fe4224  pop rdi
00007dd052fe4225  pop rdx
00007dd052fe4226  pop rcx
00007dd052fe4227  pop rax
00007dd052fe4228  add rsp, 0x08
00007dd052fe422c  jmp 0x00007DD052FDF90B
00007dd052fe4231  sub rsp, 0x08
00007dd052fe4235  push rax
00007dd052fe4236  push rcx
00007dd052fe4237  push rdx
00007dd052fe4238  push rdi
00007dd052fe4239  push rsi
00007dd052fe423a  push r8
00007dd052fe423c  push r9
00007dd052fe423e  push r10
00007dd052fe4240  push r11
00007dd052fe4242  sub rsp, 0xF0
00007dd052fe4249  vmovaps [rsp], xmm0
00007dd052fe424e  vmovaps [rsp+0x10], xmm2
00007dd052fe4254  vmovaps [rsp+0x20], xmm3
00007dd052fe425a  vmovaps [rsp+0x30], xmm4
00007dd052fe4260  vmovaps [rsp+0x40], xmm5
00007dd052fe4266  vmovaps [rsp+0x50], xmm6
00007dd052fe426c  vmovaps [rsp+0x60], xmm7
00007dd052fe4272  vmovaps [rsp+0x70], xmm8
00007dd052fe4278  vmovaps [rsp+0x80], xmm9
00007dd052fe4281  vmovaps [rsp+0x90], xmm10
00007dd052fe428a  vmovaps [rsp+0xA0], xmm11
00007dd052fe4293  vmovaps [rsp+0xB0], xmm12
00007dd052fe429c  vmovaps [rsp+0xC0], xmm13
00007dd052fe42a5  vmovaps [rsp+0xD0], xmm14
00007dd052fe42ae  vmovaps [rsp+0xE0], xmm15
00007dd052fe42b7  sub rsp, 0x30
00007dd052fe42bb  movaps [rsp], xmm1
00007dd052fe42bf  movaps [rsp+0x10], xmm13
00007dd052fe42c5  movaps [rsp+0x20], xmm8
00007dd052fe42cb  lea rdi, [rsp]
00007dd052fe42cf  mov esi, 0x00
00007dd052fe42d4  mov rax, 0x61D0404B9530
00007dd052fe42de  call rax
00007dd052fe42e0  movaps xmm1, [rsp]
00007dd052fe42e4  add rsp, 0x30
00007dd052fe42e8  vmovaps xmm0, [rsp]
00007dd052fe42ed  vmovaps xmm2, [rsp+0x10]
00007dd052fe42f3  vmovaps xmm3, [rsp+0x20]
00007dd052fe42f9  vmovaps xmm4, [rsp+0x30]
00007dd052fe42ff  vmovaps xmm5, [rsp+0x40]
00007dd052fe4305  vmovaps xmm6, [rsp+0x50]
00007dd052fe430b  vmovaps xmm7, [rsp+0x60]
00007dd052fe4311  vmovaps xmm8, [rsp+0x70]
00007dd052fe4317  vmovaps xmm9, [rsp+0x80]
00007dd052fe4320  vmovaps xmm10, [rsp+0x90]
00007dd052fe4329  vmovaps xmm11, [rsp+0xA0]
00007dd052fe4332  vmovaps xmm12, [rsp+0xB0]
00007dd052fe433b  vmovaps xmm13, [rsp+0xC0]
00007dd052fe4344  vmovaps xmm14, [rsp+0xD0]
00007dd052fe434d  vmovaps xmm15, [rsp+0xE0]
00007dd052fe4356  add rsp, 0xF0
00007dd052fe435d  pop r11
00007dd052fe435f  pop r10
00007dd052fe4361  pop r9
00007dd052fe4363  pop r8
00007dd052fe4365  pop rsi
00007dd052fe4366  pop rdi
00007dd052fe4367  pop rdx
00007dd052fe4368  pop rcx
00007dd052fe4369  pop rax
00007dd052fe436a  add rsp, 0x08
00007dd052fe436e  jmp 0x00007DD052FDF92D
00007dd052fe4373  call 0x00007DD052E0C260
00007dd052fe4378  jmp 0x00007DD052FDF93B
00007dd052fe437d  call 0x00007DD052EBD750
00007dd052fe4382  jmp 0x00007DD052FDF945
00007dd052fe4387  sub rsp, 0x08
00007dd052fe438b  push rax
00007dd052fe438c  push rcx
00007dd052fe438d  push rdx
00007dd052fe438e  push rdi
00007dd052fe438f  push rsi
00007dd052fe4390  push r8
00007dd052fe4392  push r9
00007dd052fe4394  push r10
00007dd052fe4396  push r11
00007dd052fe4398  sub rsp, 0xF0
00007dd052fe439f  vmovaps [rsp], xmm0
00007dd052fe43a4  vmovaps [rsp+0x10], xmm1
00007dd052fe43aa  vmovaps [rsp+0x20], xmm2
00007dd052fe43b0  vmovaps [rsp+0x30], xmm3
00007dd052fe43b6  vmovaps [rsp+0x40], xmm4
00007dd052fe43bc  vmovaps [rsp+0x50], xmm5
00007dd052fe43c2  vmovaps [rsp+0x60], xmm6
00007dd052fe43c8  vmovaps [rsp+0x70], xmm7
00007dd052fe43ce  vmovaps [rsp+0x80], xmm9
00007dd052fe43d7  vmovaps [rsp+0x90], xmm10
00007dd052fe43e0  vmovaps [rsp+0xA0], xmm11
00007dd052fe43e9  vmovaps [rsp+0xB0], xmm12
00007dd052fe43f2  vmovaps [rsp+0xC0], xmm13
00007dd052fe43fb  vmovaps [rsp+0xD0], xmm14
00007dd052fe4404  vmovaps [rsp+0xE0], xmm15
00007dd052fe440d  sub rsp, 0x30
00007dd052fe4411  movaps [rsp], xmm8
00007dd052fe4416  movaps [rsp+0x10], xmm15
00007dd052fe441c  movaps [rsp+0x20], xmm7
00007dd052fe4421  lea rdi, [rsp]
00007dd052fe4425  mov esi, 0x00
00007dd052fe442a  mov rax, 0x61D0404B9530
00007dd052fe4434  call rax
00007dd052fe4436  movaps xmm8, [rsp]
00007dd052fe443b  add rsp, 0x30
00007dd052fe443f  vmovaps xmm0, [rsp]
00007dd052fe4444  vmovaps xmm1, [rsp+0x10]
00007dd052fe444a  vmovaps xmm2, [rsp+0x20]
00007dd052fe4450  vmovaps xmm3, [rsp+0x30]
00007dd052fe4456  vmovaps xmm4, [rsp+0x40]
00007dd052fe445c  vmovaps xmm5, [rsp+0x50]
00007dd052fe4462  vmovaps xmm6, [rsp+0x60]
00007dd052fe4468  vmovaps xmm7, [rsp+0x70]
00007dd052fe446e  vmovaps xmm9, [rsp+0x80]
00007dd052fe4477  vmovaps xmm10, [rsp+0x90]
00007dd052fe4480  vmovaps xmm11, [rsp+0xA0]
00007dd052fe4489  vmovaps xmm12, [rsp+0xB0]
00007dd052fe4492  vmovaps xmm13, [rsp+0xC0]
00007dd052fe449b  vmovaps xmm14, [rsp+0xD0]
00007dd052fe44a4  vmovaps xmm15, [rsp+0xE0]
00007dd052fe44ad  add rsp, 0xF0
00007dd052fe44b4  pop r11
00007dd052fe44b6  pop r10
00007dd052fe44b8  pop r9
00007dd052fe44ba  pop r8
00007dd052fe44bc  pop rsi
00007dd052fe44bd  pop rdi
00007dd052fe44be  pop rdx
00007dd052fe44bf  pop rcx
00007dd052fe44c0  pop rax
00007dd052fe44c1  add rsp, 0x08
00007dd052fe44c5  jmp 0x00007DD052FDF967
00007dd052fe44ca  sub rsp, 0x08
00007dd052fe44ce  push rax
00007dd052fe44cf  push rcx
00007dd052fe44d0  push rdx
00007dd052fe44d1  push rdi
00007dd052fe44d2  push rsi
00007dd052fe44d3  push r8
00007dd052fe44d5  push r9
00007dd052fe44d7  push r10
00007dd052fe44d9  push r11
00007dd052fe44db  sub rsp, 0xF0
00007dd052fe44e2  vmovaps [rsp], xmm0
00007dd052fe44e7  vmovaps [rsp+0x10], xmm1
00007dd052fe44ed  vmovaps [rsp+0x20], xmm2
00007dd052fe44f3  vmovaps [rsp+0x30], xmm3
00007dd052fe44f9  vmovaps [rsp+0x40], xmm4
00007dd052fe44ff  vmovaps [rsp+0x50], xmm5
00007dd052fe4505  vmovaps [rsp+0x60], xmm6
00007dd052fe450b  vmovaps [rsp+0x70], xmm8
00007dd052fe4511  vmovaps [rsp+0x80], xmm9
00007dd052fe451a  vmovaps [rsp+0x90], xmm10
00007dd052fe4523  vmovaps [rsp+0xA0], xmm11
00007dd052fe452c  vmovaps [rsp+0xB0], xmm12
00007dd052fe4535  vmovaps [rsp+0xC0], xmm13
00007dd052fe453e  vmovaps [rsp+0xD0], xmm14
00007dd052fe4547  vmovaps [rsp+0xE0], xmm15
00007dd052fe4550  sub rsp, 0x30
00007dd052fe4554  movaps [rsp], xmm7
00007dd052fe4558  movaps [rsp+0x10], xmm9
00007dd052fe455e  movaps [rsp+0x20], xmm15
00007dd052fe4564  lea rdi, [rsp]
00007dd052fe4568  mov esi, 0x00
00007dd052fe456d  mov rax, 0x61D0404B9530
00007dd052fe4577  call rax
00007dd052fe4579  movaps xmm7, [rsp]
00007dd052fe457d  add rsp, 0x30
00007dd052fe4581  vmovaps xmm0, [rsp]
00007dd052fe4586  vmovaps xmm1, [rsp+0x10]
00007dd052fe458c  vmovaps xmm2, [rsp+0x20]
00007dd052fe4592  vmovaps xmm3, [rsp+0x30]
00007dd052fe4598  vmovaps xmm4, [rsp+0x40]
00007dd052fe459e  vmovaps xmm5, [rsp+0x50]
00007dd052fe45a4  vmovaps xmm6, [rsp+0x60]
00007dd052fe45aa  vmovaps xmm8, [rsp+0x70]
00007dd052fe45b0  vmovaps xmm9, [rsp+0x80]
00007dd052fe45b9  vmovaps xmm10, [rsp+0x90]
00007dd052fe45c2  vmovaps xmm11, [rsp+0xA0]
00007dd052fe45cb  vmovaps xmm12, [rsp+0xB0]
00007dd052fe45d4  vmovaps xmm13, [rsp+0xC0]
00007dd052fe45dd  vmovaps xmm14, [rsp+0xD0]
00007dd052fe45e6  vmovaps xmm15, [rsp+0xE0]
00007dd052fe45ef  add rsp, 0xF0
00007dd052fe45f6  pop r11
00007dd052fe45f8  pop r10
00007dd052fe45fa  pop r9
00007dd052fe45fc  pop r8
00007dd052fe45fe  pop rsi
00007dd052fe45ff  pop rdi
00007dd052fe4600  pop rdx
00007dd052fe4601  pop rcx
00007dd052fe4602  pop rax
00007dd052fe4603  add rsp, 0x08
00007dd052fe4607  jmp 0x00007DD052FDF994
00007dd052fe460c  sub rsp, 0x08
00007dd052fe4610  push rax
00007dd052fe4611  push rcx
00007dd052fe4612  push rdx
00007dd052fe4613  push rdi
00007dd052fe4614  push rsi
00007dd052fe4615  push r8
00007dd052fe4617  push r9
00007dd052fe4619  push r10
00007dd052fe461b  push r11
00007dd052fe461d  sub rsp, 0xF0
00007dd052fe4624  vmovaps [rsp], xmm0
00007dd052fe4629  vmovaps [rsp+0x10], xmm1
00007dd052fe462f  vmovaps [rsp+0x20], xmm2
00007dd052fe4635  vmovaps [rsp+0x30], xmm3
00007dd052fe463b  vmovaps [rsp+0x40], xmm4
00007dd052fe4641  vmovaps [rsp+0x50], xmm5
00007dd052fe4647  vmovaps [rsp+0x60], xmm6
00007dd052fe464d  vmovaps [rsp+0x70], xmm7
00007dd052fe4653  vmovaps [rsp+0x80], xmm8
00007dd052fe465c  vmovaps [rsp+0x90], xmm10
00007dd052fe4665  vmovaps [rsp+0xA0], xmm11
00007dd052fe466e  vmovaps [rsp+0xB0], xmm12
00007dd052fe4677  vmovaps [rsp+0xC0], xmm13
00007dd052fe4680  vmovaps [rsp+0xD0], xmm14
00007dd052fe4689  vmovaps [rsp+0xE0], xmm15
00007dd052fe4692  sub rsp, 0x30
00007dd052fe4696  movaps [rsp], xmm9
00007dd052fe469b  movaps [rsp+0x10], xmm13
00007dd052fe46a1  movaps [rsp+0x20], xmm15
00007dd052fe46a7  lea rdi, [rsp]
00007dd052fe46ab  mov esi, 0x00
00007dd052fe46b0  mov rax, 0x61D0404B9530
00007dd052fe46ba  call rax
00007dd052fe46bc  movaps xmm9, [rsp]
00007dd052fe46c1  add rsp, 0x30
00007dd052fe46c5  vmovaps xmm0, [rsp]
00007dd052fe46ca  vmovaps xmm1, [rsp+0x10]
00007dd052fe46d0  vmovaps xmm2, [rsp+0x20]
00007dd052fe46d6  vmovaps xmm3, [rsp+0x30]
00007dd052fe46dc  vmovaps xmm4, [rsp+0x40]
00007dd052fe46e2  vmovaps xmm5, [rsp+0x50]
00007dd052fe46e8  vmovaps xmm6, [rsp+0x60]
00007dd052fe46ee  vmovaps xmm7, [rsp+0x70]
00007dd052fe46f4  vmovaps xmm8, [rsp+0x80]
00007dd052fe46fd  vmovaps xmm10, [rsp+0x90]
00007dd052fe4706  vmovaps xmm11, [rsp+0xA0]
00007dd052fe470f  vmovaps xmm12, [rsp+0xB0]
00007dd052fe4718  vmovaps xmm13, [rsp+0xC0]
00007dd052fe4721  vmovaps xmm14, [rsp+0xD0]
00007dd052fe472a  vmovaps xmm15, [rsp+0xE0]
00007dd052fe4733  add rsp, 0xF0
00007dd052fe473a  pop r11
00007dd052fe473c  pop r10
00007dd052fe473e  pop r9
00007dd052fe4740  pop r8
00007dd052fe4742  pop rsi
00007dd052fe4743  pop rdi
00007dd052fe4744  pop rdx
00007dd052fe4745  pop rcx
00007dd052fe4746  pop rax
00007dd052fe4747  add rsp, 0x08
00007dd052fe474b  jmp 0x00007DD052FDF9C2
00007dd052fe4750  sub rsp, 0x08
00007dd052fe4754  push rax
00007dd052fe4755  push rcx
00007dd052fe4756  push rdx
00007dd052fe4757  push rdi
00007dd052fe4758  push rsi
00007dd052fe4759  push r8
00007dd052fe475b  push r9
00007dd052fe475d  push r10
00007dd052fe475f  push r11
00007dd052fe4761  sub rsp, 0xF0
00007dd052fe4768  vmovaps [rsp], xmm0
00007dd052fe476d  vmovaps [rsp+0x10], xmm1
00007dd052fe4773  vmovaps [rsp+0x20], xmm2
00007dd052fe4779  vmovaps [rsp+0x30], xmm3
00007dd052fe477f  vmovaps [rsp+0x40], xmm4
00007dd052fe4785  vmovaps [rsp+0x50], xmm5
00007dd052fe478b  vmovaps [rsp+0x60], xmm6
00007dd052fe4791  vmovaps [rsp+0x70], xmm7
00007dd052fe4797  vmovaps [rsp+0x80], xmm8
00007dd052fe47a0  vmovaps [rsp+0x90], xmm9
00007dd052fe47a9  vmovaps [rsp+0xA0], xmm10
00007dd052fe47b2  vmovaps [rsp+0xB0], xmm11
00007dd052fe47bb  vmovaps [rsp+0xC0], xmm12
00007dd052fe47c4  vmovaps [rsp+0xD0], xmm13
00007dd052fe47cd  vmovaps [rsp+0xE0], xmm14
00007dd052fe47d6  sub rsp, 0x30
00007dd052fe47da  movaps [rsp], xmm15
00007dd052fe47df  movaps [rsp+0x10], xmm11
00007dd052fe47e5  movaps [rsp+0x20], xmm12
00007dd052fe47eb  lea rdi, [rsp]
00007dd052fe47ef  mov esi, 0x00
00007dd052fe47f4  mov rax, 0x61D0404B9530
00007dd052fe47fe  call rax
00007dd052fe4800  movaps xmm15, [rsp]
00007dd052fe4805  add rsp, 0x30
00007dd052fe4809  vmovaps xmm0, [rsp]
00007dd052fe480e  vmovaps xmm1, [rsp+0x10]
00007dd052fe4814  vmovaps xmm2, [rsp+0x20]
00007dd052fe481a  vmovaps xmm3, [rsp+0x30]
00007dd052fe4820  vmovaps xmm4, [rsp+0x40]
00007dd052fe4826  vmovaps xmm5, [rsp+0x50]
00007dd052fe482c  vmovaps xmm6, [rsp+0x60]
00007dd052fe4832  vmovaps xmm7, [rsp+0x70]
00007dd052fe4838  vmovaps xmm8, [rsp+0x80]
00007dd052fe4841  vmovaps xmm9, [rsp+0x90]
00007dd052fe484a  vmovaps xmm10, [rsp+0xA0]
00007dd052fe4853  vmovaps xmm11, [rsp+0xB0]
00007dd052fe485c  vmovaps xmm12, [rsp+0xC0]
00007dd052fe4865  vmovaps xmm13, [rsp+0xD0]
00007dd052fe486e  vmovaps xmm14, [rsp+0xE0]
00007dd052fe4877  add rsp, 0xF0
00007dd052fe487e  pop r11
00007dd052fe4880  pop r10
00007dd052fe4882  pop r9
00007dd052fe4884  pop r8
00007dd052fe4886  pop rsi
00007dd052fe4887  pop rdi
00007dd052fe4888  pop rdx
00007dd052fe4889  pop rcx
00007dd052fe488a  pop rax
00007dd052fe488b  add rsp, 0x08
00007dd052fe488f  jmp 0x00007DD052FDF9DD
00007dd052fe4894  sub rsp, 0x08
00007dd052fe4898  push rax
00007dd052fe4899  push rcx
00007dd052fe489a  push rdx
00007dd052fe489b  push rdi
00007dd052fe489c  push rsi
00007dd052fe489d  push r8
00007dd052fe489f  push r9
00007dd052fe48a1  push r10
00007dd052fe48a3  push r11
00007dd052fe48a5  sub rsp, 0xF0
00007dd052fe48ac  vmovaps [rsp], xmm0
00007dd052fe48b1  vmovaps [rsp+0x10], xmm1
00007dd052fe48b7  vmovaps [rsp+0x20], xmm2
00007dd052fe48bd  vmovaps [rsp+0x30], xmm3
00007dd052fe48c3  vmovaps [rsp+0x40], xmm4
00007dd052fe48c9  vmovaps [rsp+0x50], xmm5
00007dd052fe48cf  vmovaps [rsp+0x60], xmm6
00007dd052fe48d5  vmovaps [rsp+0x70], xmm7
00007dd052fe48db  vmovaps [rsp+0x80], xmm8
00007dd052fe48e4  vmovaps [rsp+0x90], xmm9
00007dd052fe48ed  vmovaps [rsp+0xA0], xmm10
00007dd052fe48f6  vmovaps [rsp+0xB0], xmm11
00007dd052fe48ff  vmovaps [rsp+0xC0], xmm12
00007dd052fe4908  vmovaps [rsp+0xD0], xmm14
00007dd052fe4911  vmovaps [rsp+0xE0], xmm15
00007dd052fe491a  sub rsp, 0x30
00007dd052fe491e  movaps [rsp], xmm13
00007dd052fe4923  movaps [rsp+0x10], xmm10
00007dd052fe4929  movaps [rsp+0x20], xmm14
00007dd052fe492f  lea rdi, [rsp]
00007dd052fe4933  mov esi, 0x00
00007dd052fe4938  mov rax, 0x61D0404B9530
00007dd052fe4942  call rax
00007dd052fe4944  movaps xmm13, [rsp]
00007dd052fe4949  add rsp, 0x30
00007dd052fe494d  vmovaps xmm0, [rsp]
00007dd052fe4952  vmovaps xmm1, [rsp+0x10]
00007dd052fe4958  vmovaps xmm2, [rsp+0x20]
00007dd052fe495e  vmovaps xmm3, [rsp+0x30]
00007dd052fe4964  vmovaps xmm4, [rsp+0x40]
00007dd052fe496a  vmovaps xmm5, [rsp+0x50]
00007dd052fe4970  vmovaps xmm6, [rsp+0x60]
00007dd052fe4976  vmovaps xmm7, [rsp+0x70]
00007dd052fe497c  vmovaps xmm8, [rsp+0x80]
00007dd052fe4985  vmovaps xmm9, [rsp+0x90]
00007dd052fe498e  vmovaps xmm10, [rsp+0xA0]
00007dd052fe4997  vmovaps xmm11, [rsp+0xB0]
00007dd052fe49a0  vmovaps xmm12, [rsp+0xC0]
00007dd052fe49a9  vmovaps xmm14, [rsp+0xD0]
00007dd052fe49b2  vmovaps xmm15, [rsp+0xE0]
00007dd052fe49bb  add rsp, 0xF0
00007dd052fe49c2  pop r11
00007dd052fe49c4  pop r10
00007dd052fe49c6  pop r9
00007dd052fe49c8  pop r8
00007dd052fe49ca  pop rsi
00007dd052fe49cb  pop rdi
00007dd052fe49cc  pop rdx
00007dd052fe49cd  pop rcx
00007dd052fe49ce  pop rax
00007dd052fe49cf  add rsp, 0x08
00007dd052fe49d3  jmp 0x00007DD052FDFA00
00007dd052fe49d8  sub rsp, 0x08
00007dd052fe49dc  push rax
00007dd052fe49dd  push rcx
00007dd052fe49de  push rdx
00007dd052fe49df  push rdi
00007dd052fe49e0  push rsi
00007dd052fe49e1  push r8
00007dd052fe49e3  push r9
00007dd052fe49e5  push r10
00007dd052fe49e7  push r11
00007dd052fe49e9  sub rsp, 0xF0
00007dd052fe49f0  vmovaps [rsp], xmm0
00007dd052fe49f5  vmovaps [rsp+0x10], xmm1
00007dd052fe49fb  vmovaps [rsp+0x20], xmm2
00007dd052fe4a01  vmovaps [rsp+0x30], xmm3
00007dd052fe4a07  vmovaps [rsp+0x40], xmm4
00007dd052fe4a0d  vmovaps [rsp+0x50], xmm5
00007dd052fe4a13  vmovaps [rsp+0x60], xmm6
00007dd052fe4a19  vmovaps [rsp+0x70], xmm7
00007dd052fe4a1f  vmovaps [rsp+0x80], xmm8
00007dd052fe4a28  vmovaps [rsp+0x90], xmm9
00007dd052fe4a31  vmovaps [rsp+0xA0], xmm10
00007dd052fe4a3a  vmovaps [rsp+0xB0], xmm11
00007dd052fe4a43  vmovaps [rsp+0xC0], xmm12
00007dd052fe4a4c  vmovaps [rsp+0xD0], xmm13
00007dd052fe4a55  vmovaps [rsp+0xE0], xmm15
00007dd052fe4a5e  sub rsp, 0x30
00007dd052fe4a62  movaps [rsp], xmm14
00007dd052fe4a67  movaps [rsp+0x10], xmm1
00007dd052fe4a6c  movaps [rsp+0x20], xmm7
00007dd052fe4a71  lea rdi, [rsp]
00007dd052fe4a75  mov esi, 0x00
00007dd052fe4a7a  mov rax, 0x61D0404B9530
00007dd052fe4a84  call rax
00007dd052fe4a86  movaps xmm14, [rsp]
00007dd052fe4a8b  add rsp, 0x30
00007dd052fe4a8f  vmovaps xmm0, [rsp]
00007dd052fe4a94  vmovaps xmm1, [rsp+0x10]
00007dd052fe4a9a  vmovaps xmm2, [rsp+0x20]
00007dd052fe4aa0  vmovaps xmm3, [rsp+0x30]
00007dd052fe4aa6  vmovaps xmm4, [rsp+0x40]
00007dd052fe4aac  vmovaps xmm5, [rsp+0x50]
00007dd052fe4ab2  vmovaps xmm6, [rsp+0x60]
00007dd052fe4ab8  vmovaps xmm7, [rsp+0x70]
00007dd052fe4abe  vmovaps xmm8, [rsp+0x80]
00007dd052fe4ac7  vmovaps xmm9, [rsp+0x90]
00007dd052fe4ad0  vmovaps xmm10, [rsp+0xA0]
00007dd052fe4ad9  vmovaps xmm11, [rsp+0xB0]
00007dd052fe4ae2  vmovaps xmm12, [rsp+0xC0]
00007dd052fe4aeb  vmovaps xmm13, [rsp+0xD0]
00007dd052fe4af4  vmovaps xmm15, [rsp+0xE0]
00007dd052fe4afd  add rsp, 0xF0
00007dd052fe4b04  pop r11
00007dd052fe4b06  pop r10
00007dd052fe4b08  pop r9
00007dd052fe4b0a  pop r8
00007dd052fe4b0c  pop rsi
00007dd052fe4b0d  pop rdi
00007dd052fe4b0e  pop rdx
00007dd052fe4b0f  pop rcx
00007dd052fe4b10  pop rax
00007dd052fe4b11  add rsp, 0x08
00007dd052fe4b15  jmp 0x00007DD052FDFA23
00007dd052fe4b1a  sub rsp, 0x08
00007dd052fe4b1e  push rax
00007dd052fe4b1f  push rcx
00007dd052fe4b20  push rdx
00007dd052fe4b21  push rdi
00007dd052fe4b22  push rsi
00007dd052fe4b23  push r8
00007dd052fe4b25  push r9
00007dd052fe4b27  push r10
00007dd052fe4b29  push r11
00007dd052fe4b2b  sub rsp, 0xF0
00007dd052fe4b32  vmovaps [rsp], xmm0
00007dd052fe4b37  vmovaps [rsp+0x10], xmm2
00007dd052fe4b3d  vmovaps [rsp+0x20], xmm3
00007dd052fe4b43  vmovaps [rsp+0x30], xmm4
00007dd052fe4b49  vmovaps [rsp+0x40], xmm5
00007dd052fe4b4f  vmovaps [rsp+0x50], xmm6
00007dd052fe4b55  vmovaps [rsp+0x60], xmm7
00007dd052fe4b5b  vmovaps [rsp+0x70], xmm8
00007dd052fe4b61  vmovaps [rsp+0x80], xmm9
00007dd052fe4b6a  vmovaps [rsp+0x90], xmm10
00007dd052fe4b73  vmovaps [rsp+0xA0], xmm11
00007dd052fe4b7c  vmovaps [rsp+0xB0], xmm12
00007dd052fe4b85  vmovaps [rsp+0xC0], xmm13
00007dd052fe4b8e  vmovaps [rsp+0xD0], xmm14
00007dd052fe4b97  vmovaps [rsp+0xE0], xmm15
00007dd052fe4ba0  sub rsp, 0x30
00007dd052fe4ba4  movaps [rsp], xmm1
00007dd052fe4ba8  movaps [rsp+0x10], xmm8
00007dd052fe4bae  movaps [rsp+0x20], xmm9
00007dd052fe4bb4  lea rdi, [rsp]
00007dd052fe4bb8  mov esi, 0x00
00007dd052fe4bbd  mov rax, 0x61D0404B9530
00007dd052fe4bc7  call rax
00007dd052fe4bc9  movaps xmm1, [rsp]
00007dd052fe4bcd  add rsp, 0x30
00007dd052fe4bd1  vmovaps xmm0, [rsp]
00007dd052fe4bd6  vmovaps xmm2, [rsp+0x10]
00007dd052fe4bdc  vmovaps xmm3, [rsp+0x20]
00007dd052fe4be2  vmovaps xmm4, [rsp+0x30]
00007dd052fe4be8  vmovaps xmm5, [rsp+0x40]
00007dd052fe4bee  vmovaps xmm6, [rsp+0x50]
00007dd052fe4bf4  vmovaps xmm7, [rsp+0x60]
00007dd052fe4bfa  vmovaps xmm8, [rsp+0x70]
00007dd052fe4c00  vmovaps xmm9, [rsp+0x80]
00007dd052fe4c09  vmovaps xmm10, [rsp+0x90]
00007dd052fe4c12  vmovaps xmm11, [rsp+0xA0]
00007dd052fe4c1b  vmovaps xmm12, [rsp+0xB0]
00007dd052fe4c24  vmovaps xmm13, [rsp+0xC0]
00007dd052fe4c2d  vmovaps xmm14, [rsp+0xD0]
00007dd052fe4c36  vmovaps xmm15, [rsp+0xE0]
00007dd052fe4c3f  add rsp, 0xF0
00007dd052fe4c46  pop r11
00007dd052fe4c48  pop r10
00007dd052fe4c4a  pop r9
00007dd052fe4c4c  pop r8
00007dd052fe4c4e  pop rsi
00007dd052fe4c4f  pop rdi
00007dd052fe4c50  pop rdx
00007dd052fe4c51  pop rcx
00007dd052fe4c52  pop rax
00007dd052fe4c53  add rsp, 0x08
00007dd052fe4c57  jmp 0x00007DD052FDFA45
00007dd052fe4c5c  call 0x00007DD052EE5940
00007dd052fe4c61  jmp 0x00007DD052FDFA53
00007dd052fe4c66  call 0x00007DD052E0C380
00007dd052fe4c6b  jmp 0x00007DD052FDFA5D
00007dd052fe4c70  call 0x00007DD052E0D600
00007dd052fe4c75  jmp 0x00007DD052FDFA67
00007dd052fe4c7a  call 0x00007DD052DFF540
00007dd052fe4c7f  jmp 0x00007DD052FDFA71
00007dd052fe4c84  int3
00007dd052fe4c85  nop [rax+rax*1], ax
00007dd052fe4c8e  nop
00007dd052fe4c90  mov qword ptr [r15+0x40], 0x430000
00007dd052fe4c98  mov eax, 0x430CC0
00007dd052fe4c9d  mov r14, [r13+rax*1]
00007dd052fe4ca2  movq xmm1, r14
00007dd052fe4ca7  mov rax, [r15+0x50]
00007dd052fe4cab  movups xmm15, [r13+rax*1]
00007dd052fe4cb1  movaps [r15+0x120], xmm15
00007dd052fe4cb9  mov qword ptr [r15+0x48], 0x10
00007dd052fe4cc1  xor eax, eax
00007dd052fe4cc3  mov r14d, 0x10
00007dd052fe4cc9  mov r12d, 0x200
00007dd052fe4ccf  cmp r14, r12
00007dd052fe4cd2  cmc
00007dd052fe4cd3  lahf
00007dd052fe4cd4  seto al
00007dd052fe4cd7  mov [r15+0x108], eax
00007dd052fe4cde  pextrq rax, xmm15, 0x01
00007dd052fe4ce5  movq xmm14, rax
00007dd052fe4cea  movaps [r15+0x130], xmm14
00007dd052fe4cf2  movq rax, xmm1
00007dd052fe4cf7  movq r14, xmm15
00007dd052fe4cfc  vmovq xmm1, rax
00007dd052fe4d01  vmovq xmm15, r14
00007dd052fe4d06  movaps xmm13, xmm1
00007dd052fe4d0a  addsd xmm13, xmm15
00007dd052fe4d0f  ucomisd xmm13, xmm13
00007dd052fe4d14  jp 0x00007DD052FE4DD3
00007dd052fe4d1a  movq xmm13, xmm13
00007dd052fe4d1f  movq rax, xmm13
00007dd052fe4d24  movq r14, xmm14
00007dd052fe4d29  vmovq xmm1, rax
00007dd052fe4d2e  vmovq xmm15, r14
00007dd052fe4d33  movaps xmm14, xmm1
00007dd052fe4d37  addsd xmm14, xmm15
00007dd052fe4d3c  ucomisd xmm14, xmm14
00007dd052fe4d41  jp 0x00007DD052FE4E1B
00007dd052fe4d47  movq xmm14, xmm14
00007dd052fe4d4c  movaps [r15+0x110], xmm14
00007dd052fe4d54  mov eax, [r15+0x108]
00007dd052fe4d5b  sahf
00007dd052fe4d5c  jnz 0x00007DD052FE4D8E
00007dd052fe4d5e  cmp dword ptr [r15+0x318], 0x00
00007dd052fe4d66  jz 0x00007DD052FE5030
00007dd052fe4d6c  nop [rax+rax*1], ax
00007dd052fe4d75  nop [rax+rax*1], eax
00007dd052fe4d7d  mov eax, 0x410704
00007dd052fe4d82  mov [r15+0x100], rax
00007dd052fe4d89  jmp 0x00007DD052DFE110
00007dd052fe4d8e  cmp dword ptr [r15+0x318], 0x00
00007dd052fe4d96  jz 0x00007DD052FE4E70
00007dd052fe4d9c  nop [rax+rax*1], ax
00007dd052fe4da5  nop [rax+rax*1], eax
00007dd052fe4dad  mov eax, 0x4106E8
00007dd052fe4db2  mov [r15+0x100], rax
00007dd052fe4db9  jmp 0x00007DD052DFE110
00007dd052fe4dbe  int3
00007dd052fe4dbf  call 0x00007DD052E0DC20
00007dd052fe4dc4  jmp 0x00007DD052FE4CA2
00007dd052fe4dc9  call 0x00007DD052E0E760
00007dd052fe4dce  jmp 0x00007DD052FE4CB1
00007dd052fe4dd3  ucomisd xmm1, xmm15
00007dd052fe4dd8  jp 0x00007DD052FE4DE7
00007dd052fe4dda  movaps xmm13, [0x00007DD052BFE060]
00007dd052fe4de2  jmp 0x00007DD052FE4D1A
00007dd052fe4de7  vxorps xmm0, xmm1, xmm15
00007dd052fe4dec  pextrw eax, xmm0, 0x03
00007dd052fe4df1  and eax, 0x7FF8
00007dd052fe4df6  cmp eax, 0x08
00007dd052fe4df9  jnz 0x00007DD052FE4D1A
00007dd052fe4dff  movq rax, xmm15
00007dd052fe4e04  shl rax, 0x0D
00007dd052fe4e08  jbe 0x00007DD052FE4D1A
00007dd052fe4e0e  vorps xmm13, xmm15, [0x00007DD052BFE070]
00007dd052fe4e16  jmp 0x00007DD052FE4D1A
00007dd052fe4e1b  ucomisd xmm1, xmm15
00007dd052fe4e20  jp 0x00007DD052FE4E2F
00007dd052fe4e22  movaps xmm14, [0x00007DD052BFE060]
00007dd052fe4e2a  jmp 0x00007DD052FE4D47
00007dd052fe4e2f  vxorps xmm0, xmm1, xmm15
00007dd052fe4e34  pextrw eax, xmm0, 0x03
00007dd052fe4e39  and eax, 0x7FF8
00007dd052fe4e3e  cmp eax, 0x08
00007dd052fe4e41  jnz 0x00007DD052FE4D47
00007dd052fe4e47  movq rax, xmm15
00007dd052fe4e4c  shl rax, 0x0D
00007dd052fe4e50  jbe 0x00007DD052FE4D47
00007dd052fe4e56  vorps xmm14, xmm15, [0x00007DD052BFE070]
00007dd052fe4e5e  jmp 0x00007DD052FE4D47
00007dd052fe4e63  int3
00007dd052fe4e64  nop [rax+rax*1], ax
00007dd052fe4e6d  nop [rax], eax
00007dd052fe4e70  mov rax, [r15+0x48]
00007dd052fe4e74  mov r14, [r15+0x50]
00007dd052fe4e78  lea r12, [r14+rax*1]
00007dd052fe4e7c  movups xmm1, [r13+r12*1]
00007dd052fe4e82  movaps [r15+0x120], xmm1
00007dd052fe4e8a  lea r14, [rax+0x10]
00007dd052fe4e8e  mov [r15+0x48], r14
00007dd052fe4e92  xor eax, eax
00007dd052fe4e94  mov r12d, 0x200
00007dd052fe4e9a  cmp r14, r12
00007dd052fe4e9d  cmc
00007dd052fe4e9e  lahf
00007dd052fe4e9f  seto al
00007dd052fe4ea2  mov [r15+0x108], eax
00007dd052fe4ea9  pextrq rax, xmm1, 0x01
00007dd052fe4eb0  movq xmm15, rax
00007dd052fe4eb5  movaps [r15+0x130], xmm15
00007dd052fe4ebd  movaps xmm14, [r15+0x110]
00007dd052fe4ec5  movq rax, xmm14
00007dd052fe4eca  movq r14, xmm1
00007dd052fe4ecf  vmovq xmm1, rax
00007dd052fe4ed4  vmovq xmm14, r14
00007dd052fe4ed9  movaps xmm13, xmm1
00007dd052fe4edd  addsd xmm13, xmm14
00007dd052fe4ee2  ucomisd xmm13, xmm13
00007dd052fe4ee7  jp 0x00007DD052FE4F9C
00007dd052fe4eed  movq xmm13, xmm13
00007dd052fe4ef2  movq rax, xmm13
00007dd052fe4ef7  movq r14, xmm15
00007dd052fe4efc  vmovq xmm1, rax
00007dd052fe4f01  vmovq xmm15, r14
00007dd052fe4f06  movaps xmm14, xmm1
00007dd052fe4f0a  addsd xmm14, xmm15
00007dd052fe4f0f  ucomisd xmm14, xmm14
00007dd052fe4f14  jp 0x00007DD052FE4FE4
00007dd052fe4f1a  movq xmm14, xmm14
00007dd052fe4f1f  movaps [r15+0x110], xmm14
00007dd052fe4f27  mov eax, [r15+0x108]
00007dd052fe4f2e  sahf
00007dd052fe4f2f  jnz 0x00007DD052FE4F61
00007dd052fe4f31  cmp dword ptr [r15+0x318], 0x00
00007dd052fe4f39  jz 0x00007DD052FE5030
00007dd052fe4f3f  nop [rax+rax*1], ax
00007dd052fe4f48  nop [rax+rax*1], eax
00007dd052fe4f50  mov eax, 0x410704
00007dd052fe4f55  mov [r15+0x100], rax
00007dd052fe4f5c  jmp 0x00007DD052DFE110
00007dd052fe4f61  cmp dword ptr [r15+0x318], 0x00
00007dd052fe4f69  jz 0x00007DD052FE4E70
00007dd052fe4f6f  nop [rax+rax*1], ax
00007dd052fe4f78  nop [rax+rax*1], eax
00007dd052fe4f80  mov eax, 0x4106E8
00007dd052fe4f85  mov [r15+0x100], rax
00007dd052fe4f8c  jmp 0x00007DD052DFE110
00007dd052fe4f91  int3
00007dd052fe4f92  call 0x00007DD052EB52F0
00007dd052fe4f97  jmp 0x00007DD052FE4E82
00007dd052fe4f9c  ucomisd xmm1, xmm14
00007dd052fe4fa1  jp 0x00007DD052FE4FB0
00007dd052fe4fa3  movaps xmm13, [0x00007DD052BFE060]
00007dd052fe4fab  jmp 0x00007DD052FE4EED
00007dd052fe4fb0  vxorps xmm0, xmm1, xmm14
00007dd052fe4fb5  pextrw eax, xmm0, 0x03
00007dd052fe4fba  and eax, 0x7FF8
00007dd052fe4fbf  cmp eax, 0x08
00007dd052fe4fc2  jnz 0x00007DD052FE4EED
00007dd052fe4fc8  movq rax, xmm14
00007dd052fe4fcd  shl rax, 0x0D
00007dd052fe4fd1  jbe 0x00007DD052FE4EED
00007dd052fe4fd7  vorps xmm13, xmm14, [0x00007DD052BFE070]
00007dd052fe4fdf  jmp 0x00007DD052FE4EED
00007dd052fe4fe4  ucomisd xmm1, xmm15
00007dd052fe4fe9  jp 0x00007DD052FE4FF8
00007dd052fe4feb  movaps xmm14, [0x00007DD052BFE060]
00007dd052fe4ff3  jmp 0x00007DD052FE4F1A
00007dd052fe4ff8  vxorps xmm0, xmm1, xmm15
00007dd052fe4ffd  pextrw eax, xmm0, 0x03
00007dd052fe5002  and eax, 0x7FF8
00007dd052fe5007  cmp eax, 0x08
00007dd052fe500a  jnz 0x00007DD052FE4F1A
00007dd052fe5010  movq rax, xmm15
00007dd052fe5015  shl rax, 0x0D
00007dd052fe5019  jbe 0x00007DD052FE4F1A
00007dd052fe501f  vorps xmm14, xmm15, [0x00007DD052BFE070]
00007dd052fe5027  jmp 0x00007DD052FE4F1A
00007dd052fe502c  int3
00007dd052fe502d  nop [rax], eax
00007dd052fe5030  mov rax, [r15+0xF8]
00007dd052fe5037  lea r14, [rax+0x1D0]
00007dd052fe503e  mov r12, [r13+r14*1]
00007dd052fe5043  lea r14, [rax+0x1D8]
00007dd052fe504a  mov r11, [r13+r14*1]
00007dd052fe504f  mov [r15+0xA0], r12
00007dd052fe5056  mov [r15+0x98], r11
00007dd052fe505d  mov r14, [r15+0x40]
00007dd052fe5061  lea r12, [r14+0xCC0]
00007dd052fe5068  movaps xmm1, [r15+0x110]
00007dd052fe5070  movq r14, xmm1
00007dd052fe5075  mov [r13+r12*1], r14
00007dd052fe507a  lea r14, [rax+0x1C0]
00007dd052fe5081  mov r12, [r13+r14*1]
00007dd052fe5086  lea r14, [rax+0x1C8]
00007dd052fe508d  mov r11, [r13+r14*1]
00007dd052fe5092  mov [r15+0xE8], r12
00007dd052fe5099  mov [r15+0xF0], r11
00007dd052fe50a0  lea r14, [rax+0x1B0]
00007dd052fe50a7  mov r12, [r13+r14*1]
00007dd052fe50ac  lea r14, [rax+0x1B8]
00007dd052fe50b3  mov r10, [r13+r14*1]
00007dd052fe50b8  movq xmm1, r12
00007dd052fe50bd  movq xmm15, r10
00007dd052fe50c2  movq xmm1, xmm1
00007dd052fe50c6  movq xmm1, xmm1
00007dd052fe50ca  movaps [r15+0x1A0], xmm1
00007dd052fe50d2  movq xmm15, xmm15
00007dd052fe50d7  movq xmm15, xmm15
00007dd052fe50dc  movaps [r15+0x190], xmm15
00007dd052fe50e4  lea r14, [rax+0x1A0]
00007dd052fe50eb  mov r12, [r13+r14*1]
00007dd052fe50f0  lea r14, [rax+0x1A8]
00007dd052fe50f7  mov r10, [r13+r14*1]
00007dd052fe50fc  movq xmm1, r12
00007dd052fe5101  movq xmm15, r10
00007dd052fe5106  movq xmm1, xmm1
00007dd052fe510a  movq xmm1, xmm1
00007dd052fe510e  movaps [r15+0x1C0], xmm1
00007dd052fe5116  movq xmm15, xmm15
00007dd052fe511b  movq xmm15, xmm15
00007dd052fe5120  movaps [r15+0x1B0], xmm15
00007dd052fe5128  lea r14, [rax+0x190]
00007dd052fe512f  mov r12, [r13+r14*1]
00007dd052fe5134  lea r14, [rax+0x198]
00007dd052fe513b  mov r10, [r13+r14*1]
00007dd052fe5140  movq xmm1, r12
00007dd052fe5145  movq xmm15, r10
00007dd052fe514a  movq xmm1, xmm1
00007dd052fe514e  movq xmm1, xmm1
00007dd052fe5152  movaps [r15+0x1E0], xmm1
00007dd052fe515a  movq xmm15, xmm15
00007dd052fe515f  movq xmm15, xmm15
00007dd052fe5164  movaps [r15+0x1D0], xmm15
00007dd052fe516c  lea r14, [rax+0x180]
00007dd052fe5173  mov r12, [r13+r14*1]
00007dd052fe5178  lea r14, [rax+0x188]
00007dd052fe517f  mov r10, [r13+r14*1]
00007dd052fe5184  movq xmm1, r12
00007dd052fe5189  movq xmm15, r10
00007dd052fe518e  movq xmm1, xmm1
00007dd052fe5192  movq xmm1, xmm1
00007dd052fe5196  movaps [r15+0x200], xmm1
00007dd052fe519e  movq xmm15, xmm15
00007dd052fe51a3  movq xmm15, xmm15
00007dd052fe51a8  movaps [r15+0x1F0], xmm15
00007dd052fe51b0  lea r14, [rax+0x1E0]
00007dd052fe51b7  mov [r15+0xF8], r14
00007dd052fe51be  mov [r15+0x100], r11
00007dd052fe51c5  jmp 0x00007DD052FCE5C0
00007dd052fe51ca  int3
00007dd052fe51cb  call 0x00007DD052EE27E0
00007dd052fe51d0  jmp 0x00007DD052FE5043
00007dd052fe51d5  call 0x00007DD052EE1570
00007dd052fe51da  jmp 0x00007DD052FE504F
00007dd052fe51df  call 0x00007DD052EC3FE0
00007dd052fe51e4  jmp 0x00007DD052FE507A
00007dd052fe51e9  call 0x00007DD052EE27E0
00007dd052fe51ee  jmp 0x00007DD052FE5086
00007dd052fe51f3  call 0x00007DD052EE1570
00007dd052fe51f8  jmp 0x00007DD052FE5092
00007dd052fe51fd  call 0x00007DD052EE27E0
00007dd052fe5202  jmp 0x00007DD052FE50AC
00007dd052fe5207  call 0x00007DD052EE0300
00007dd052fe520c  jmp 0x00007DD052FE50B8
00007dd052fe5211  call 0x00007DD052EE27E0
00007dd052fe5216  jmp 0x00007DD052FE50F0
00007dd052fe521b  call 0x00007DD052EE0300
00007dd052fe5220  jmp 0x00007DD052FE50FC
00007dd052fe5225  call 0x00007DD052EE27E0
00007dd052fe522a  jmp 0x00007DD052FE5134
00007dd052fe522f  call 0x00007DD052EE0300
00007dd052fe5234  jmp 0x00007DD052FE5140
00007dd052fe5239  call 0x00007DD052EE27E0
00007dd052fe523e  jmp 0x00007DD052FE5178
00007dd052fe5243  call 0x00007DD052EE0300
00007dd052fe5248  jmp 0x00007DD052FE5184
00007dd052fe524d  int3
00007dd052fe524e  nop
00007dd052fe5250  mov qword ptr [r15+0x100], 0x04
00007dd052fe525b  mov esi, 0x00
00007dd052fe5260  mov edx, 0x09
00007dd052fe5265  mov rdi, 0x7FFD719F2A10
00007dd052fe526f  mov rax, 0x61D04034C970
00007dd052fe5279  call rax
00007dd052fe527b  cmp dword ptr [r15+0x318], 0x00
00007dd052fe5283  jnz 0x00007DD052DFE110
00007dd052fe5289  jmp 0x00007DD052DFE0A0
00007dd052fe528e  int3
00007dd052fe528f  int3
