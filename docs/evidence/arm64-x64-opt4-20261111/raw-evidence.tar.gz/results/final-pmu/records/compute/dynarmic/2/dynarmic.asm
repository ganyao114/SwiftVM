00007f30a29ce69b  nop [rax+rax*1], eax
00007f30a29ce6a0  mov rax, [r15+0xF8]
00007f30a29ce6a7  lea r14, [rax-0x1E0]
00007f30a29ce6ae  mov [r15+0xF8], r14
00007f30a29ce6b5  lea rax, [r14+0x1D0]
00007f30a29ce6bc  mov r12, [r15+0xA0]
00007f30a29ce6c3  mov r11, [r15+0x98]
00007f30a29ce6ca  mov [r13+rax*1], r12
00007f30a29ce6cf  lea rax, [r14+0x1D8]
00007f30a29ce6d6  mov [r13+rax*1], r11
00007f30a29ce6db  mov eax, 0x420AA0
00007f30a29ce6e0  movups xmm1, [r13+rax*1]
00007f30a29ce6e6  mov eax, 0x420A30
00007f30a29ce6eb  movups xmm15, [r13+rax*1]
00007f30a29ce6f1  mov eax, 0x420AC0
00007f30a29ce6f6  movups xmm14, [r13+rax*1]
00007f30a29ce6fc  mov eax, 0x420A60
00007f30a29ce701  movups xmm13, [r13+rax*1]
00007f30a29ce707  mov qword ptr [r15+0x98], 0x430CD0
00007f30a29ce712  mov eax, 0x420AD0
00007f30a29ce717  movups xmm12, [r13+rax*1]
00007f30a29ce71d  mov eax, 0x430CD0
00007f30a29ce722  movups [r13+rax*1], xmm1
00007f30a29ce728  mov eax, 0x430CE0
00007f30a29ce72d  movups [r13+rax*1], xmm15
00007f30a29ce733  mov eax, 0x430CF0
00007f30a29ce738  movups [r13+rax*1], xmm14
00007f30a29ce73e  mov eax, 0x430D00
00007f30a29ce743  movups [r13+rax*1], xmm13
00007f30a29ce749  mov eax, 0x420A20
00007f30a29ce74e  movups xmm14, [r13+rax*1]
00007f30a29ce754  mov eax, 0x420A10
00007f30a29ce759  movups xmm13, [r13+rax*1]
00007f30a29ce75f  mov eax, 0x430DD0
00007f30a29ce764  movups [r13+rax*1], xmm1
00007f30a29ce76a  mov eax, 0x430DE0
00007f30a29ce76f  movups [r13+rax*1], xmm15
00007f30a29ce775  mov eax, 0x430D10
00007f30a29ce77a  movups [r13+rax*1], xmm12
00007f30a29ce780  mov eax, 0x430D20
00007f30a29ce785  movups [r13+rax*1], xmm14
00007f30a29ce78b  mov eax, 0x420A00
00007f30a29ce790  movups xmm1, [r13+rax*1]
00007f30a29ce796  mov eax, 0x420A70
00007f30a29ce79b  movups xmm15, [r13+rax*1]
00007f30a29ce7a1  mov eax, 0x430D30
00007f30a29ce7a6  movups [r13+rax*1], xmm13
00007f30a29ce7ac  mov eax, 0x430D40
00007f30a29ce7b1  movups [r13+rax*1], xmm1
00007f30a29ce7b7  mov eax, 0x420A80
00007f30a29ce7bc  movups xmm1, [r13+rax*1]
00007f30a29ce7c2  mov eax, 0x420A50
00007f30a29ce7c7  movups xmm14, [r13+rax*1]
00007f30a29ce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
00007f30a29ce7d5  mov eax, 0x430D50
00007f30a29ce7da  movups [r13+rax*1], xmm15
00007f30a29ce7e0  mov eax, 0x430D60
00007f30a29ce7e5  movups [r13+rax*1], xmm1
00007f30a29ce7eb  mov eax, 0x420AF0
00007f30a29ce7f0  movups xmm1, [r13+rax*1]
00007f30a29ce7f6  mov eax, 0x420B00
00007f30a29ce7fb  movups xmm15, [r13+rax*1]
00007f30a29ce801  movaps [r15+0x150], xmm15
00007f30a29ce809  mov qword ptr [r15+0xA0], 0x3E8
00007f30a29ce814  mov eax, 0x430D70
00007f30a29ce819  movups [r13+rax*1], xmm14
00007f30a29ce81f  mov eax, 0x430D80
00007f30a29ce824  movups [r13+rax*1], xmm1
00007f30a29ce82a  mov eax, 0x420AE0
00007f30a29ce82f  movups xmm1, [r13+rax*1]
00007f30a29ce835  mov eax, 0x420A90
00007f30a29ce83a  movups xmm14, [r13+rax*1]
00007f30a29ce840  movaps [r15+0x140], xmm14
00007f30a29ce848  lea rax, [r14+0x180]
00007f30a29ce84f  movq xmm13, qword ptr [r15+0x200]
00007f30a29ce858  movq xmm12, qword ptr [r15+0x1F0]
00007f30a29ce861  movq r12, xmm13
00007f30a29ce866  movq r11, xmm12
00007f30a29ce86b  mov [r13+rax*1], r12
00007f30a29ce870  lea rax, [r14+0x188]
00007f30a29ce877  mov [r13+rax*1], r11
00007f30a29ce87c  mov eax, 0x430D90
00007f30a29ce881  movups [r13+rax*1], xmm15
00007f30a29ce887  mov eax, 0x430DA0
00007f30a29ce88c  movups [r13+rax*1], xmm1
00007f30a29ce892  mov eax, 0x420AB0
00007f30a29ce897  movups xmm1, [r13+rax*1]
00007f30a29ce89d  mov eax, 0x420B18
00007f30a29ce8a2  mov r12, [r13+rax*1]
00007f30a29ce8a7  movq xmm15, r12
00007f30a29ce8ac  mov qword ptr [r15+0x40], 0x420B20
00007f30a29ce8b4  mov eax, 0x430DB0
00007f30a29ce8b9  movups [r13+rax*1], xmm14
00007f30a29ce8bf  mov eax, 0x430DC0
00007f30a29ce8c4  movups [r13+rax*1], xmm1
00007f30a29ce8ca  mov eax, 0x420B80
00007f30a29ce8cf  movups xmm1, [r13+rax*1]
00007f30a29ce8d5  movq rax, xmm15
00007f30a29ce8da  mov r12d, 0x430DF0
00007f30a29ce8e0  mov [r13+r12*1], rax
00007f30a29ce8e5  mov eax, 0x420B60
00007f30a29ce8ea  movups xmm15, [r13+rax*1]
00007f30a29ce8f0  mov eax, 0x420B70
00007f30a29ce8f5  movups xmm14, [r13+rax*1]
00007f30a29ce8fb  lea rax, [r14+0x160]
00007f30a29ce902  movups [r13+rax*1], xmm1
00007f30a29ce908  lea rax, [r14+0x190]
00007f30a29ce90f  movq xmm1, qword ptr [r15+0x1E0]
00007f30a29ce918  movq xmm13, qword ptr [r15+0x1D0]
00007f30a29ce921  movq r12, xmm1
00007f30a29ce926  movq r11, xmm13
00007f30a29ce92b  mov [r13+rax*1], r12
00007f30a29ce930  lea rax, [r14+0x198]
00007f30a29ce937  mov [r13+rax*1], r11
00007f30a29ce93c  lea rax, [r14+0x140]
00007f30a29ce943  movups [r13+rax*1], xmm15
00007f30a29ce949  lea rax, [r14+0x150]
00007f30a29ce950  movups [r13+rax*1], xmm14
00007f30a29ce956  mov eax, 0x420B20
00007f30a29ce95b  movups xmm1, [r13+rax*1]
00007f30a29ce961  mov eax, 0x420B30
00007f30a29ce966  movups xmm15, [r13+rax*1]
00007f30a29ce96c  movaps [r15+0x120], xmm15
00007f30a29ce974  lea rax, [r14+0x1A0]
00007f30a29ce97b  movq xmm14, qword ptr [r15+0x1C0]
00007f30a29ce984  movq xmm13, qword ptr [r15+0x1B0]
00007f30a29ce98d  movq r12, xmm14
00007f30a29ce992  movq r11, xmm13
00007f30a29ce997  mov [r13+rax*1], r12
00007f30a29ce99c  lea rax, [r14+0x1A8]
00007f30a29ce9a3  mov [r13+rax*1], r11
00007f30a29ce9a8  lea rax, [r14+0x1B0]
00007f30a29ce9af  movq xmm14, qword ptr [r15+0x1A0]
00007f30a29ce9b8  movq xmm13, qword ptr [r15+0x190]
00007f30a29ce9c1  movq r12, xmm14
00007f30a29ce9c6  movq r11, xmm13
00007f30a29ce9cb  mov [r13+rax*1], r12
00007f30a29ce9d0  lea rax, [r14+0x1B8]
00007f30a29ce9d7  mov [r13+rax*1], r11
00007f30a29ce9dc  lea rax, [r14+0x100]
00007f30a29ce9e3  movups [r13+rax*1], xmm1
00007f30a29ce9e9  lea rax, [r14+0x110]
00007f30a29ce9f0  movups [r13+rax*1], xmm15
00007f30a29ce9f6  mov eax, 0x420B40
00007f30a29ce9fb  movups xmm1, [r13+rax*1]
00007f30a29cea01  mov eax, 0x420B50
00007f30a29cea06  movups xmm15, [r13+rax*1]
00007f30a29cea0c  movaps [r15+0x110], xmm1
00007f30a29cea14  movaps [r15+0x130], xmm15
00007f30a29cea1c  lea rax, [r14+0x1C0]
00007f30a29cea23  mov r12, [r15+0xE8]
00007f30a29cea2a  mov r11, [r15+0xF0]
00007f30a29cea31  mov [r13+rax*1], r12
00007f30a29cea36  lea rax, [r14+0x1C8]
00007f30a29cea3d  mov [r13+rax*1], r11
00007f30a29cea42  mov eax, 0x430DF8
00007f30a29cea47  mov r12d, 0x421DF8D3
00007f30a29cea4d  mov [r13+rax*1], r12d
00007f30a29cea52  lea rax, [r14+0x120]
00007f30a29cea59  movups [r13+rax*1], xmm1
00007f30a29cea5f  lea rax, [r14+0x130]
00007f30a29cea66  movups [r13+rax*1], xmm15
00007f30a29cea6c  lea rax, [r14+0x100]
00007f30a29cea73  mov [r15], rax
00007f30a29cea76  mov qword ptr [r15+0x08], 0x430CD0
00007f30a29cea7e  mov qword ptr [r15+0x10], 0x12C
00007f30a29cea86  mov qword ptr [r15+0xF0], 0x410284
00007f30a29cea91  mov r14d, [r15+0x320]
00007f30a29cea98  mov eax, 0x410284
00007f30a29cea9d  mov rcx, 0x7F30A29D07C0
00007f30a29ceaa7  mov [r15+r14*8+0x328], rax
00007f30a29ceaaf  mov [r15+r14*8+0x368], rcx
00007f30a29ceab7  add r14d, 0x01
00007f30a29ceabb  and r14d, 0x07
00007f30a29ceabf  mov [r15+0x320], r14d
00007f30a29ceac6  cmp dword ptr [r15+0x318], 0x00
00007f30a29ceace  jz 0x00007F30A29CED70
00007f30a29cead4  nop [rax+rax*1], ax
00007f30a29ceadd  nop [rax+rax*1], eax
00007f30a29ceae5  mov eax, 0x410728
00007f30a29ceaea  mov [r15+0x100], rax
00007f30a29ceaf1  jmp 0x00007F30A27FE110
00007f30a29ceaf6  int3
00007f30a29ceaf7  call 0x00007F30A280BC20
00007f30a29ceafc  jmp 0x00007F30A29CE6CF
00007f30a29ceb01  call 0x00007F30A280A9A0
00007f30a29ceb06  jmp 0x00007F30A29CE6DB
00007f30a29ceb0b  call 0x00007F30A27FF430
00007f30a29ceb10  jmp 0x00007F30A29CE6E6
00007f30a29ceb15  call 0x00007F30A280E760
00007f30a29ceb1a  jmp 0x00007F30A29CE6F1
00007f30a29ceb1f  call 0x00007F30A280D4E0
00007f30a29ceb24  jmp 0x00007F30A29CE6FC
00007f30a29ceb29  call 0x00007F30A280C260
00007f30a29ceb2e  jmp 0x00007F30A29CE707
00007f30a29ceb33  call 0x00007F30A280AFE0
00007f30a29ceb38  jmp 0x00007F30A29CE71D
00007f30a29ceb3d  call 0x00007F30A27FF540
00007f30a29ceb42  jmp 0x00007F30A29CE728
00007f30a29ceb47  call 0x00007F30A280E880
00007f30a29ceb4c  jmp 0x00007F30A29CE733
00007f30a29ceb51  call 0x00007F30A280D600
00007f30a29ceb56  jmp 0x00007F30A29CE73E
00007f30a29ceb5b  call 0x00007F30A280C380
00007f30a29ceb60  jmp 0x00007F30A29CE749
00007f30a29ceb65  call 0x00007F30A280D4E0
00007f30a29ceb6a  jmp 0x00007F30A29CE754
00007f30a29ceb6f  call 0x00007F30A280C260
00007f30a29ceb74  jmp 0x00007F30A29CE75F
00007f30a29ceb79  call 0x00007F30A27FF540
00007f30a29ceb7e  jmp 0x00007F30A29CE76A
00007f30a29ceb83  call 0x00007F30A280E880
00007f30a29ceb88  jmp 0x00007F30A29CE775
00007f30a29ceb8d  call 0x00007F30A280B100
00007f30a29ceb92  jmp 0x00007F30A29CE780
00007f30a29ceb97  call 0x00007F30A280D600
00007f30a29ceb9c  jmp 0x00007F30A29CE78B
00007f30a29ceba1  call 0x00007F30A27FF430
00007f30a29ceba6  jmp 0x00007F30A29CE796
00007f30a29cebab  call 0x00007F30A280E760
00007f30a29cebb0  jmp 0x00007F30A29CE7A1
00007f30a29cebb5  call 0x00007F30A280C380
00007f30a29cebba  jmp 0x00007F30A29CE7AC
00007f30a29cebbf  call 0x00007F30A27FF540
00007f30a29cebc4  jmp 0x00007F30A29CE7B7
00007f30a29cebc9  call 0x00007F30A27FF430
00007f30a29cebce  jmp 0x00007F30A29CE7C2
00007f30a29cebd3  call 0x00007F30A280D4E0
00007f30a29cebd8  jmp 0x00007F30A29CE7CD
00007f30a29cebdd  call 0x00007F30A280E880
00007f30a29cebe2  jmp 0x00007F30A29CE7E0
00007f30a29cebe7  call 0x00007F30A27FF540
00007f30a29cebec  jmp 0x00007F30A29CE7EB
00007f30a29cebf1  call 0x00007F30A27FF430
00007f30a29cebf6  jmp 0x00007F30A29CE7F6
00007f30a29cebfb  call 0x00007F30A280E760
00007f30a29cec00  jmp 0x00007F30A29CE801
00007f30a29cec05  call 0x00007F30A280D600
00007f30a29cec0a  jmp 0x00007F30A29CE81F
00007f30a29cec0f  call 0x00007F30A27FF540
00007f30a29cec14  jmp 0x00007F30A29CE82A
00007f30a29cec19  call 0x00007F30A27FF430
00007f30a29cec1e  jmp 0x00007F30A29CE835
00007f30a29cec23  call 0x00007F30A280D4E0
00007f30a29cec28  jmp 0x00007F30A29CE840
00007f30a29cec2d  call 0x00007F30A280BC20
00007f30a29cec32  jmp 0x00007F30A29CE870
00007f30a29cec37  call 0x00007F30A280A9A0
00007f30a29cec3c  jmp 0x00007F30A29CE87C
00007f30a29cec41  call 0x00007F30A280E880
00007f30a29cec46  jmp 0x00007F30A29CE887
00007f30a29cec4b  call 0x00007F30A27FF540
00007f30a29cec50  jmp 0x00007F30A29CE892
00007f30a29cec55  call 0x00007F30A27FF430
00007f30a29cec5a  jmp 0x00007F30A29CE89D
00007f30a29cec5f  call 0x00007F30A280B720
00007f30a29cec64  jmp 0x00007F30A29CE8A7
00007f30a29cec69  call 0x00007F30A280D600
00007f30a29cec6e  jmp 0x00007F30A29CE8BF
00007f30a29cec73  call 0x00007F30A27FF540
00007f30a29cec78  jmp 0x00007F30A29CE8CA
00007f30a29cec7d  call 0x00007F30A27FF430
00007f30a29cec82  jmp 0x00007F30A29CE8D5
00007f30a29cec87  call 0x00007F30A28B4CB0
00007f30a29cec8c  jmp 0x00007F30A29CE8E5
00007f30a29cec91  call 0x00007F30A280E760
00007f30a29cec96  jmp 0x00007F30A29CE8F0
00007f30a29cec9b  call 0x00007F30A280D4E0
00007f30a29ceca0  jmp 0x00007F30A29CE8FB
00007f30a29ceca5  call 0x00007F30A27FF540
00007f30a29cecaa  jmp 0x00007F30A29CE908
00007f30a29cecaf  call 0x00007F30A280BC20
00007f30a29cecb4  jmp 0x00007F30A29CE930
00007f30a29cecb9  call 0x00007F30A280A9A0
00007f30a29cecbe  jmp 0x00007F30A29CE93C
00007f30a29cecc3  call 0x00007F30A280E880
00007f30a29cecc8  jmp 0x00007F30A29CE949
00007f30a29ceccd  call 0x00007F30A280D600
00007f30a29cecd2  jmp 0x00007F30A29CE956
00007f30a29cecd7  call 0x00007F30A27FF430
00007f30a29cecdc  jmp 0x00007F30A29CE961
00007f30a29cece1  call 0x00007F30A280E760
00007f30a29cece6  jmp 0x00007F30A29CE96C
00007f30a29ceceb  call 0x00007F30A280BC20
00007f30a29cecf0  jmp 0x00007F30A29CE99C
00007f30a29cecf5  call 0x00007F30A280A9A0
00007f30a29cecfa  jmp 0x00007F30A29CE9A8
00007f30a29cecff  call 0x00007F30A280BC20
00007f30a29ced04  jmp 0x00007F30A29CE9D0
00007f30a29ced09  call 0x00007F30A280A9A0
00007f30a29ced0e  jmp 0x00007F30A29CE9DC
00007f30a29ced13  call 0x00007F30A27FF540
00007f30a29ced18  jmp 0x00007F30A29CE9E9
00007f30a29ced1d  call 0x00007F30A280E880
00007f30a29ced22  jmp 0x00007F30A29CE9F6
00007f30a29ced27  call 0x00007F30A27FF430
00007f30a29ced2c  jmp 0x00007F30A29CEA01
00007f30a29ced31  call 0x00007F30A280E760
00007f30a29ced36  jmp 0x00007F30A29CEA0C
00007f30a29ced3b  call 0x00007F30A280BC20
00007f30a29ced40  jmp 0x00007F30A29CEA36
00007f30a29ced45  call 0x00007F30A280A9A0
00007f30a29ced4a  jmp 0x00007F30A29CEA42
00007f30a29ced4f  call 0x00007F30A280BAE0
00007f30a29ced54  jmp 0x00007F30A29CEA52
00007f30a29ced59  call 0x00007F30A27FF540
00007f30a29ced5e  jmp 0x00007F30A29CEA5F
00007f30a29ced63  call 0x00007F30A280E880
00007f30a29ced68  jmp 0x00007F30A29CEA6C
00007f30a29ced6d  int3
00007f30a29ced6e  nop
00007f30a29ced70  mov rax, [r15]
00007f30a29ced73  lea r14, [rax+0x20]
00007f30a29ced77  mov r12, [r13+r14*1]
00007f30a29ced7c  mov r14, [r15+0x10]
00007f30a29ced80  lea r11, [r12+r14*1]
00007f30a29ced84  mov [r15+0x40], r11
00007f30a29ced88  lea r12, [rax+0x20]
00007f30a29ced8c  mov [r13+r12*1], r11
00007f30a29ced91  test r14, r14
00007f30a29ced94  setz r14b
00007f30a29ced98  movzx r14, r14b
00007f30a29ced9c  mov [rsp+0x414], r14b
00007f30a29ceda4  cmp byte ptr [rsp+0x414], 0x00
00007f30a29cedac  jz 0x00007F30A29CEDDE
00007f30a29cedae  cmp dword ptr [r15+0x318], 0x00
00007f30a29cedb6  mov eax, 0x4109A0
00007f30a29cedbb  mov [r15+0x100], rax
00007f30a29cedc2  jz 0x00007F30A27FE0A0
00007f30a29cedc8  nop [rax+rax*1], eax
00007f30a29cedcd  mov eax, 0x4109A0
00007f30a29cedd2  mov [r15+0x100], rax
00007f30a29cedd9  jmp 0x00007F30A27FE110
00007f30a29cedde  cmp dword ptr [r15+0x318], 0x00
00007f30a29cede6  jz 0x00007F30A29CEE30
00007f30a29cedec  nop [rax+rax*1], ax
00007f30a29cedf5  nop [rax+rax*1], eax
00007f30a29cedfd  mov eax, 0x410738
00007f30a29cee02  mov [r15+0x100], rax
00007f30a29cee09  jmp 0x00007F30A27FE110
00007f30a29cee0e  int3
00007f30a29cee0f  call 0x00007F30A28E27E0
00007f30a29cee14  jmp 0x00007F30A29CED7C
00007f30a29cee19  call 0x00007F30A28C0860
00007f30a29cee1e  jmp 0x00007F30A29CED91
00007f30a29cee23  int3
00007f30a29cee24  nop [rax+rax*1], ax
00007f30a29cee2d  nop [rax], eax
00007f30a29cee30  mov rax, [r15+0xF8]
00007f30a29cee37  lea r14, [rax-0x150]
00007f30a29cee3e  mov [r15+0xF8], r14
00007f30a29cee45  mov rax, [r15]
00007f30a29cee48  lea r12, [rax+0x68]
00007f30a29cee4c  mov r11, [r13+r12*1]
00007f30a29cee51  mov [r15+0x88], r11
00007f30a29cee58  lea r12, [rax+0x28]
00007f30a29cee5c  mov [r15+0x40], r12
00007f30a29cee60  mov [r15+0x48], r14
00007f30a29cee64  mov qword ptr [r15+0x50], 0x420B90
00007f30a29cee6c  lea rax, [r14+0x100]
00007f30a29cee73  mov r12, [r15+0xE8]
00007f30a29cee7a  mov r11, [r15+0xD8]
00007f30a29cee81  mov [r13+rax*1], r12
00007f30a29cee86  lea rax, [r14+0x108]
00007f30a29cee8d  mov [r13+rax*1], r11
00007f30a29cee92  lea rax, [r14+0x110]
00007f30a29cee99  mov r12, [r15+0xD0]
00007f30a29ceea0  mov r11, [r15+0xC8]
00007f30a29ceea7  mov [r13+rax*1], r12
00007f30a29ceeac  lea rax, [r14+0x118]
00007f30a29ceeb3  mov [r13+rax*1], r11
00007f30a29ceeb8  lea rax, [r14+0x120]
00007f30a29ceebf  mov r12, [r15+0xC0]
00007f30a29ceec6  mov r11, [r15+0xB8]
00007f30a29ceecd  mov [r13+rax*1], r12
00007f30a29ceed2  lea rax, [r14+0x128]
00007f30a29ceed9  mov [r13+rax*1], r11
00007f30a29ceede  lea rax, [r14+0x130]
00007f30a29ceee5  mov r12, [r15+0xB0]
00007f30a29ceeec  mov r11, [r15+0xA8]
00007f30a29ceef3  mov [r13+rax*1], r12
00007f30a29ceef8  lea rax, [r14+0x138]
00007f30a29ceeff  mov [r13+rax*1], r11
00007f30a29cef04  lea rax, [r14+0x140]
00007f30a29cef0b  mov r12, [r15+0xA0]
00007f30a29cef12  mov r11, [r15+0x98]
00007f30a29cef19  mov [r13+rax*1], r12
00007f30a29cef1e  lea rax, [r14+0x148]
00007f30a29cef25  mov [r13+rax*1], r11
00007f30a29cef2a  cmp dword ptr [r15+0x318], 0x00
00007f30a29cef32  jz 0x00007F30A29CEFD0
00007f30a29cef38  nop [rax+rax*1], ax
00007f30a29cef41  nop [rax+rax*1], eax
00007f30a29cef49  mov eax, 0x410770
00007f30a29cef4e  mov [r15+0x100], rax
00007f30a29cef55  jmp 0x00007F30A27FE110
00007f30a29cef5a  int3
00007f30a29cef5b  call 0x00007F30A28C0370
00007f30a29cef60  jmp 0x00007F30A29CEE51
00007f30a29cef65  call 0x00007F30A280BC20
00007f30a29cef6a  jmp 0x00007F30A29CEE86
00007f30a29cef6f  call 0x00007F30A280A9A0
00007f30a29cef74  jmp 0x00007F30A29CEE92
00007f30a29cef79  call 0x00007F30A280BC20
00007f30a29cef7e  jmp 0x00007F30A29CEEAC
00007f30a29cef83  call 0x00007F30A280A9A0
00007f30a29cef88  jmp 0x00007F30A29CEEB8
00007f30a29cef8d  call 0x00007F30A280BC20
00007f30a29cef92  jmp 0x00007F30A29CEED2
00007f30a29cef97  call 0x00007F30A280A9A0
00007f30a29cef9c  jmp 0x00007F30A29CEEDE
00007f30a29cefa1  call 0x00007F30A280BC20
00007f30a29cefa6  jmp 0x00007F30A29CEEF8
00007f30a29cefab  call 0x00007F30A280A9A0
00007f30a29cefb0  jmp 0x00007F30A29CEF04
00007f30a29cefb5  call 0x00007F30A280BC20
00007f30a29cefba  jmp 0x00007F30A29CEF1E
00007f30a29cefbf  call 0x00007F30A280A9A0
00007f30a29cefc4  jmp 0x00007F30A29CEF2A
00007f30a29cefc9  int3
00007f30a29cefca  nop [rax+rax*1], ax
00007f30a29cefd0  mov rax, [r15+0x08]
00007f30a29cefd4  movzx r14d, byte ptr [r13+rax*1]
00007f30a29cefda  movzx r14d, r14b
00007f30a29cefde  mov [rsp+0x10], r14d
00007f30a29cefe3  mov r14d, r14d
00007f30a29cefe6  mov [r15+0x58], r14
00007f30a29cefea  lea r14, [rax+0x01]
00007f30a29cefee  mov [r15+0x08], r14
00007f30a29ceff2  mov rax, [r15+0x88]
00007f30a29ceff9  lea r14, [rax+0x01]
00007f30a29ceffd  mov r12, [r15]
00007f30a29cf000  lea r11, [r12+0x68]
00007f30a29cf005  mov [r13+r11*1], r14
00007f30a29cf00a  lea r14, [r12+rax*1]
00007f30a29cf00e  mov [r15+0x60], r14
00007f30a29cf012  lea rax, [r14+0x28]
00007f30a29cf016  mov r11d, [rsp+0x10]
00007f30a29cf01b  movzx r14d, r11b
00007f30a29cf01f  mov [r13+rax*1], r14b
00007f30a29cf024  lea rax, [r12+0x68]
00007f30a29cf029  mov r14, [r13+rax*1]
00007f30a29cf02e  mov [r15+0x88], r14
00007f30a29cf035  xor eax, eax
00007f30a29cf037  mov r12d, 0x40
00007f30a29cf03d  cmp r14, r12
00007f30a29cf040  cmc
00007f30a29cf041  lahf
00007f30a29cf042  seto al
00007f30a29cf045  mov [r15+0x108], eax
00007f30a29cf04c  mov eax, [r15+0x108]
00007f30a29cf053  sahf
00007f30a29cf054  jnz 0x00007F30A29CF086
00007f30a29cf056  cmp dword ptr [r15+0x318], 0x00
00007f30a29cf05e  jz 0x00007F30A29CF170
00007f30a29cf064  nop [rax+rax*1], ax
00007f30a29cf06d  nop [rax+rax*1], eax
00007f30a29cf075  mov eax, 0x410790
00007f30a29cf07a  mov [r15+0x100], rax
00007f30a29cf081  jmp 0x00007F30A27FE110
00007f30a29cf086  cmp dword ptr [r15+0x318], 0x00
00007f30a29cf08e  jz 0x00007F30A29CF0E0
00007f30a29cf094  nop [rax+rax*1], ax
00007f30a29cf09d  nop [rax+rax*1], eax
00007f30a29cf0a5  mov eax, 0x410768
00007f30a29cf0aa  mov [r15+0x100], rax
00007f30a29cf0b1  jmp 0x00007F30A27FE110
00007f30a29cf0b6  int3
00007f30a29cf0b7  call 0x00007F30A280D860
00007f30a29cf0bc  jmp 0x00007F30A29CEFDA
00007f30a29cf0c1  call 0x00007F30A28B36E0
00007f30a29cf0c6  jmp 0x00007F30A29CF00A
00007f30a29cf0cb  call 0x00007F30A280DD60
00007f30a29cf0d0  jmp 0x00007F30A29CF024
00007f30a29cf0d5  call 0x00007F30A280DC20
00007f30a29cf0da  jmp 0x00007F30A29CF02E
00007f30a29cf0df  int3
00007f30a29cf0e0  mov rax, [r15+0x10]
00007f30a29cf0e4  lea r14, [rax-0x01]
00007f30a29cf0e8  mov [r15+0x10], r14
00007f30a29cf0ec  test r14, r14
00007f30a29cf0ef  setz r14b
00007f30a29cf0f3  movzx r14, r14b
00007f30a29cf0f7  mov [rsp+0x414], r14b
00007f30a29cf0ff  cmp byte ptr [rsp+0x414], 0x00
00007f30a29cf107  jz 0x00007F30A29CF139
00007f30a29cf109  cmp dword ptr [r15+0x318], 0x00
00007f30a29cf111  jz 0x00007F30A29D0670
00007f30a29cf117  nop [rax+rax*1], ax
00007f30a29cf120  nop [rax+rax*1], eax
00007f30a29cf128  mov eax, 0x410988
00007f30a29cf12d  mov [r15+0x100], rax
00007f30a29cf134  jmp 0x00007F30A27FE110
00007f30a29cf139  cmp dword ptr [r15+0x318], 0x00
00007f30a29cf141  jz 0x00007F30A29CEFD0
00007f30a29cf147  nop [rax+rax*1], ax
00007f30a29cf150  nop [rax+rax*1], eax
00007f30a29cf158  mov eax, 0x410770
00007f30a29cf15d  mov [r15+0x100], rax
00007f30a29cf164  jmp 0x00007F30A27FE110
00007f30a29cf169  int3
00007f30a29cf16a  int3
00007f30a29cf16b  nop [rax+rax*1], eax
00007f30a29cf170  mov rax, [r15+0x40]
00007f30a29cf174  movzx r14d, byte ptr [r13+rax*1]
00007f30a29cf17a  movaps xmm1, [r15+0x110]
00007f30a29cf182  pinsrb xmm1, r14d, 0x00
00007f30a29cf189  lea r14, [rax+0x01]
00007f30a29cf18d  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf193  movaps xmm15, [r15+0x120]
00007f30a29cf19b  pinsrb xmm15, r12d, 0x00
00007f30a29cf1a2  lea r14, [rax+0x02]
00007f30a29cf1a6  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf1ac  movaps xmm14, [r15+0x130]
00007f30a29cf1b4  pinsrb xmm14, r12d, 0x00
00007f30a29cf1bb  lea r14, [rax+0x03]
00007f30a29cf1bf  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf1c5  movaps xmm13, [r15+0x140]
00007f30a29cf1cd  pinsrb xmm13, r12d, 0x00
00007f30a29cf1d4  lea r14, [rax+0x04]
00007f30a29cf1d8  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf1de  pinsrb xmm1, r12d, 0x01
00007f30a29cf1e5  lea r14, [rax+0x05]
00007f30a29cf1e9  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf1ef  pinsrb xmm15, r12d, 0x01
00007f30a29cf1f6  lea r14, [rax+0x06]
00007f30a29cf1fa  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf200  pinsrb xmm14, r12d, 0x01
00007f30a29cf207  lea r14, [rax+0x07]
00007f30a29cf20b  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf211  pinsrb xmm13, r12d, 0x01
00007f30a29cf218  lea r14, [rax+0x08]
00007f30a29cf21c  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf222  pinsrb xmm1, r12d, 0x02
00007f30a29cf229  lea r14, [rax+0x09]
00007f30a29cf22d  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf233  pinsrb xmm15, r12d, 0x02
00007f30a29cf23a  lea r14, [rax+0x0A]
00007f30a29cf23e  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf244  pinsrb xmm14, r12d, 0x02
00007f30a29cf24b  lea r14, [rax+0x0B]
00007f30a29cf24f  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf255  pinsrb xmm13, r12d, 0x02
00007f30a29cf25c  lea r14, [rax+0x0C]
00007f30a29cf260  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf266  pinsrb xmm1, r12d, 0x03
00007f30a29cf26d  lea r14, [rax+0x0D]
00007f30a29cf271  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf277  pinsrb xmm15, r12d, 0x03
00007f30a29cf27e  lea r14, [rax+0x0E]
00007f30a29cf282  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf288  pinsrb xmm14, r12d, 0x03
00007f30a29cf28f  lea r14, [rax+0x0F]
00007f30a29cf293  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf299  pinsrb xmm13, r12d, 0x03
00007f30a29cf2a0  lea r14, [rax+0x10]
00007f30a29cf2a4  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf2aa  pinsrb xmm1, r12d, 0x04
00007f30a29cf2b1  lea r14, [rax+0x11]
00007f30a29cf2b5  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf2bb  pinsrb xmm15, r12d, 0x04
00007f30a29cf2c2  lea r14, [rax+0x12]
00007f30a29cf2c6  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf2cc  pinsrb xmm14, r12d, 0x04
00007f30a29cf2d3  lea r14, [rax+0x13]
00007f30a29cf2d7  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf2dd  pinsrb xmm13, r12d, 0x04
00007f30a29cf2e4  lea r14, [rax+0x14]
00007f30a29cf2e8  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf2ee  pinsrb xmm1, r12d, 0x05
00007f30a29cf2f5  lea r14, [rax+0x15]
00007f30a29cf2f9  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf2ff  pinsrb xmm15, r12d, 0x05
00007f30a29cf306  lea r14, [rax+0x16]
00007f30a29cf30a  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf310  pinsrb xmm14, r12d, 0x05
00007f30a29cf317  lea r14, [rax+0x17]
00007f30a29cf31b  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf321  pinsrb xmm13, r12d, 0x05
00007f30a29cf328  lea r14, [rax+0x18]
00007f30a29cf32c  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf332  pinsrb xmm1, r12d, 0x06
00007f30a29cf339  lea r14, [rax+0x19]
00007f30a29cf33d  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf343  pinsrb xmm15, r12d, 0x06
00007f30a29cf34a  lea r14, [rax+0x1A]
00007f30a29cf34e  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf354  pinsrb xmm14, r12d, 0x06
00007f30a29cf35b  lea r14, [rax+0x1B]
00007f30a29cf35f  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf365  pinsrb xmm13, r12d, 0x06
00007f30a29cf36c  lea r14, [rax+0x1C]
00007f30a29cf370  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf376  pinsrb xmm1, r12d, 0x07
00007f30a29cf37d  lea r14, [rax+0x1D]
00007f30a29cf381  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf387  pinsrb xmm15, r12d, 0x07
00007f30a29cf38e  lea r14, [rax+0x1E]
00007f30a29cf392  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf398  pinsrb xmm14, r12d, 0x07
00007f30a29cf39f  lea r14, [rax+0x1F]
00007f30a29cf3a3  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf3a9  pinsrb xmm13, r12d, 0x07
00007f30a29cf3b0  lea r14, [rax+0x20]
00007f30a29cf3b4  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf3ba  pinsrb xmm1, r12d, 0x08
00007f30a29cf3c1  lea r14, [rax+0x21]
00007f30a29cf3c5  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf3cb  pinsrb xmm15, r12d, 0x08
00007f30a29cf3d2  lea r14, [rax+0x22]
00007f30a29cf3d6  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf3dc  pinsrb xmm14, r12d, 0x08
00007f30a29cf3e3  lea r14, [rax+0x23]
00007f30a29cf3e7  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf3ed  pinsrb xmm13, r12d, 0x08
00007f30a29cf3f4  lea r14, [rax+0x24]
00007f30a29cf3f8  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf3fe  pinsrb xmm1, r12d, 0x09
00007f30a29cf405  lea r14, [rax+0x25]
00007f30a29cf409  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf40f  pinsrb xmm15, r12d, 0x09
00007f30a29cf416  lea r14, [rax+0x26]
00007f30a29cf41a  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf420  pinsrb xmm14, r12d, 0x09
00007f30a29cf427  lea r14, [rax+0x27]
00007f30a29cf42b  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf431  pinsrb xmm13, r12d, 0x09
00007f30a29cf438  lea r14, [rax+0x28]
00007f30a29cf43c  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf442  pinsrb xmm1, r12d, 0x0A
00007f30a29cf449  lea r14, [rax+0x29]
00007f30a29cf44d  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf453  pinsrb xmm15, r12d, 0x0A
00007f30a29cf45a  lea r14, [rax+0x2A]
00007f30a29cf45e  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf464  pinsrb xmm14, r12d, 0x0A
00007f30a29cf46b  lea r14, [rax+0x2B]
00007f30a29cf46f  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf475  pinsrb xmm13, r12d, 0x0A
00007f30a29cf47c  lea r14, [rax+0x2C]
00007f30a29cf480  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf486  pinsrb xmm1, r12d, 0x0B
00007f30a29cf48d  lea r14, [rax+0x2D]
00007f30a29cf491  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf497  pinsrb xmm15, r12d, 0x0B
00007f30a29cf49e  lea r14, [rax+0x2E]
00007f30a29cf4a2  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf4a8  pinsrb xmm14, r12d, 0x0B
00007f30a29cf4af  lea r14, [rax+0x2F]
00007f30a29cf4b3  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf4b9  pinsrb xmm13, r12d, 0x0B
00007f30a29cf4c0  lea r14, [rax+0x30]
00007f30a29cf4c4  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf4ca  pinsrb xmm1, r12d, 0x0C
00007f30a29cf4d1  lea r14, [rax+0x31]
00007f30a29cf4d5  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf4db  pinsrb xmm15, r12d, 0x0C
00007f30a29cf4e2  lea r14, [rax+0x32]
00007f30a29cf4e6  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf4ec  pinsrb xmm14, r12d, 0x0C
00007f30a29cf4f3  lea r14, [rax+0x33]
00007f30a29cf4f7  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf4fd  pinsrb xmm13, r12d, 0x0C
00007f30a29cf504  lea r14, [rax+0x34]
00007f30a29cf508  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf50e  pinsrb xmm1, r12d, 0x0D
00007f30a29cf515  lea r14, [rax+0x35]
00007f30a29cf519  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf51f  pinsrb xmm15, r12d, 0x0D
00007f30a29cf526  lea r14, [rax+0x36]
00007f30a29cf52a  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf530  pinsrb xmm14, r12d, 0x0D
00007f30a29cf537  lea r14, [rax+0x37]
00007f30a29cf53b  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf541  pinsrb xmm13, r12d, 0x0D
00007f30a29cf548  lea r14, [rax+0x38]
00007f30a29cf54c  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf552  pinsrb xmm1, r12d, 0x0E
00007f30a29cf559  lea r14, [rax+0x39]
00007f30a29cf55d  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf563  pinsrb xmm15, r12d, 0x0E
00007f30a29cf56a  lea r14, [rax+0x3A]
00007f30a29cf56e  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf574  pinsrb xmm14, r12d, 0x0E
00007f30a29cf57b  lea r14, [rax+0x3B]
00007f30a29cf57f  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf585  pinsrb xmm13, r12d, 0x0E
00007f30a29cf58c  lea r14, [rax+0x3C]
00007f30a29cf590  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf596  pinsrb xmm1, r12d, 0x0F
00007f30a29cf59d  movaps [r15+0x110], xmm1
00007f30a29cf5a5  lea r14, [rax+0x3D]
00007f30a29cf5a9  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf5af  pinsrb xmm15, r12d, 0x0F
00007f30a29cf5b6  movaps [r15+0x120], xmm15
00007f30a29cf5be  lea r14, [rax+0x3E]
00007f30a29cf5c2  movzx r12d, byte ptr [r13+r14*1]
00007f30a29cf5c8  pinsrb xmm14, r12d, 0x0F
00007f30a29cf5cf  movaps [r15+0x130], xmm14
00007f30a29cf5d7  lea r14, [rax+0x3F]
00007f30a29cf5db  movzx eax, byte ptr [r13+r14*1]
00007f30a29cf5e1  pinsrb xmm13, eax, 0x0F
00007f30a29cf5e8  movaps [r15+0x140], xmm13
00007f30a29cf5f0  movq xmm1, qword ptr [r15+0x120]
00007f30a29cf5f9  pmovzxbw xmm1, xmm1
00007f30a29cf5fe  psllw xmm1, 0x00
00007f30a29cf603  movaps [r15+0x150], xmm1
00007f30a29cf60b  movq xmm1, qword ptr [r15+0x130]
00007f30a29cf614  pmovzxbw xmm1, xmm1
00007f30a29cf619  psllw xmm1, 0x00
00007f30a29cf61e  movaps [r15+0x160], xmm1
00007f30a29cf626  movq xmm1, qword ptr [r15+0x110]
00007f30a29cf62f  pmovzxbw xmm1, xmm1
00007f30a29cf634  psllw xmm1, 0x00
00007f30a29cf639  movaps [r15+0x170], xmm1
00007f30a29cf641  movaps xmm15, [r15+0x110]
00007f30a29cf649  pextrq rax, xmm15, 0x01
00007f30a29cf650  movq xmm15, rax
00007f30a29cf655  pmovzxbw xmm15, xmm15
00007f30a29cf65b  psllw xmm15, 0x00
00007f30a29cf661  movaps [r15+0x180], xmm15
00007f30a29cf669  movaps xmm14, [r15+0x120]
00007f30a29cf671  pextrq rax, xmm14, 0x01
00007f30a29cf678  movq xmm14, rax
00007f30a29cf67d  pmovzxbw xmm14, xmm14
00007f30a29cf683  psllw xmm14, 0x00
00007f30a29cf689  movaps [r15+0x210], xmm14
00007f30a29cf691  movaps xmm13, [r15+0x130]
00007f30a29cf699  pextrq rax, xmm13, 0x01
00007f30a29cf6a0  movq xmm13, rax
00007f30a29cf6a5  pmovzxbw xmm13, xmm13
00007f30a29cf6ab  psllw xmm13, 0x00
00007f30a29cf6b1  movaps [r15+0x220], xmm13
00007f30a29cf6b9  movq xmm12, qword ptr [r15+0x140]
00007f30a29cf6c2  pmovzxbw xmm12, xmm12
00007f30a29cf6c8  psllw xmm12, 0x00
00007f30a29cf6ce  movaps [r15+0x250], xmm12
00007f30a29cf6d6  movaps xmm12, [r15+0x140]
00007f30a29cf6de  pextrq rax, xmm12, 0x01
00007f30a29cf6e5  movq xmm12, rax
00007f30a29cf6ea  pmovzxbw xmm12, xmm12
00007f30a29cf6f0  psllw xmm12, 0x00
00007f30a29cf6f6  movaps [r15+0x110], xmm12
00007f30a29cf6fe  movq xmm11, qword ptr [r15+0x150]
00007f30a29cf707  pmovzxwd xmm11, xmm11
00007f30a29cf70d  pslld xmm11, 0x10
00007f30a29cf713  movq xmm10, qword ptr [r15+0x160]
00007f30a29cf71c  pmovzxwd xmm10, xmm10
00007f30a29cf722  pslld xmm10, 0x08
00007f30a29cf728  pextrq rax, xmm1, 0x01
00007f30a29cf72f  movq xmm1, rax
00007f30a29cf734  pmovzxwd xmm1, xmm1
00007f30a29cf739  pslld xmm1, 0x00
00007f30a29cf73e  movaps [r15+0x260], xmm1
00007f30a29cf746  pextrq rax, xmm15, 0x01
00007f30a29cf74d  movq xmm15, rax
00007f30a29cf752  pmovzxwd xmm15, xmm15
00007f30a29cf758  pslld xmm15, 0x00
00007f30a29cf75e  movaps [r15+0x270], xmm15
00007f30a29cf766  movq xmm9, qword ptr [r15+0x170]
00007f30a29cf76f  pmovzxwd xmm9, xmm9
00007f30a29cf775  pslld xmm9, 0x00
00007f30a29cf77b  pextrq rax, xmm14, 0x01
00007f30a29cf782  movq xmm14, rax
00007f30a29cf787  pmovzxwd xmm14, xmm14
00007f30a29cf78d  pslld xmm14, 0x10
00007f30a29cf793  movaps [r15+0x280], xmm14
00007f30a29cf79b  movq xmm8, qword ptr [r15+0x180]
00007f30a29cf7a4  pmovzxwd xmm8, xmm8
00007f30a29cf7aa  pslld xmm8, 0x00
00007f30a29cf7b0  movq xmm7, qword ptr [r15+0x210]
00007f30a29cf7b9  pmovzxwd xmm7, xmm7
00007f30a29cf7be  pslld xmm7, 0x10
00007f30a29cf7c3  movaps xmm6, [r15+0x150]
00007f30a29cf7cb  pextrq rax, xmm6, 0x01
00007f30a29cf7d2  movq xmm6, rax
00007f30a29cf7d7  pmovzxwd xmm6, xmm6
00007f30a29cf7dc  pslld xmm6, 0x10
00007f30a29cf7e1  por xmm11, xmm10
00007f30a29cf7e6  movaps [r15+0x230], xmm11
00007f30a29cf7ee  pextrq rax, xmm13, 0x01
00007f30a29cf7f5  movq xmm13, rax
00007f30a29cf7fa  pmovzxwd xmm13, xmm13
00007f30a29cf800  pslld xmm13, 0x08
00007f30a29cf806  movaps [r15+0x240], xmm13
00007f30a29cf80e  movq xmm10, qword ptr [r15+0x220]
00007f30a29cf817  pmovzxwd xmm10, xmm10
00007f30a29cf81d  pslld xmm10, 0x08
00007f30a29cf823  movaps xmm5, [r15+0x160]
00007f30a29cf82b  pextrq rax, xmm5, 0x01
00007f30a29cf832  movq xmm5, rax
00007f30a29cf837  pmovzxwd xmm5, xmm5
00007f30a29cf83c  pslld xmm5, 0x08
00007f30a29cf841  pslld xmm9, 0x18
00007f30a29cf847  pslld xmm15, 0x18
00007f30a29cf84d  pslld xmm8, 0x18
00007f30a29cf853  movq xmm4, qword ptr [r15+0x250]
00007f30a29cf85c  pmovzxwd xmm4, xmm4
00007f30a29cf861  pslld xmm4, 0x00
00007f30a29cf866  por xmm14, xmm13
00007f30a29cf86b  por xmm7, xmm10
00007f30a29cf870  movaps [r15+0x210], xmm7
00007f30a29cf878  pslld xmm1, 0x18
00007f30a29cf87d  movaps [r15+0x220], xmm1
00007f30a29cf885  por xmm6, xmm5
00007f30a29cf889  por xmm11, xmm9
00007f30a29cf88e  movaps [r15+0x160], xmm11
00007f30a29cf896  pextrq rax, xmm12, 0x01
00007f30a29cf89d  movq xmm13, rax
00007f30a29cf8a2  pmovzxwd xmm13, xmm13
00007f30a29cf8a8  pslld xmm13, 0x00
00007f30a29cf8ae  movaps [r15+0x170], xmm13
00007f30a29cf8b6  movq xmm12, qword ptr [r15+0x110]
00007f30a29cf8bf  pmovzxwd xmm12, xmm12
00007f30a29cf8c5  pslld xmm12, 0x00
00007f30a29cf8cb  por xmm14, xmm15
00007f30a29cf8d0  por xmm7, xmm8
00007f30a29cf8d5  movaps xmm15, [r15+0x250]
00007f30a29cf8dd  pextrq rax, xmm15, 0x01
00007f30a29cf8e4  movq xmm15, rax
00007f30a29cf8e9  pmovzxwd xmm15, xmm15
00007f30a29cf8ef  pslld xmm15, 0x00
00007f30a29cf8f5  movaps [r15+0x180], xmm15
00007f30a29cf8fd  por xmm6, xmm1
00007f30a29cf901  movaps [r15+0x150], xmm6
00007f30a29cf909  por xmm11, xmm4
00007f30a29cf90e  movaps [r15+0x140], xmm11
00007f30a29cf916  por xmm7, xmm12
00007f30a29cf91b  movaps [r15+0x110], xmm7
00007f30a29cf923  por xmm14, xmm13
00007f30a29cf928  movaps [r15+0x120], xmm14
00007f30a29cf930  por xmm6, xmm15
00007f30a29cf935  movaps [r15+0x130], xmm6
00007f30a29cf93d  mov rax, [r15+0xF8]
00007f30a29cf944  lea r14, [rax+0x20]
00007f30a29cf948  movups [r13+r14*1], xmm7
00007f30a29cf94e  lea r14, [rax+0x30]
00007f30a29cf952  movups [r13+r14*1], xmm14
00007f30a29cf958  movups [r13+rax*1], xmm11
00007f30a29cf95e  lea r14, [rax+0x10]
00007f30a29cf962  movups [r13+r14*1], xmm6
00007f30a29cf968  mov r14d, [r13+rax*1]
00007f30a29cf96d  mov rax, [r15+0x48]
00007f30a29cf971  mov [r15+0x68], rax
00007f30a29cf975  mov qword ptr [r15+0x58], 0x04
00007f30a29cf97d  lea r12, [rax+0x04]
00007f30a29cf981  mov r11d, [r13+r12*1]
00007f30a29cf986  mov [rsp+0x10], r11d
00007f30a29cf98b  mov r11d, r11d
00007f30a29cf98e  mov [r15+0x70], r11
00007f30a29cf992  lea r12, [rax+0x38]
00007f30a29cf996  mov r11d, [r13+r12*1]
00007f30a29cf99b  lea r12, [rax+0x24]
00007f30a29cf99f  mov r10d, [r13+r12*1]
00007f30a29cf9a4  mov [rsp+0x20], r10d
00007f30a29cf9a9  mov r10d, r10d
00007f30a29cf9ac  mov [r15+0x90], r10
00007f30a29cf9b3  mov [rsp+0x30], rax
00007f30a29cf9b8  xor eax, eax
00007f30a29cf9ba  mov r12d, 0x04
00007f30a29cf9c0  mov r10d, 0xC0
00007f30a29cf9c6  cmp r12, r10
00007f30a29cf9c9  cmc
00007f30a29cf9ca  lahf
00007f30a29cf9cb  seto al
00007f30a29cf9ce  mov [r15+0x108], eax
00007f30a29cf9d5  mov eax, [rsp+0x10]
00007f30a29cf9d9  mov r12d, [rsp+0x10]
00007f30a29cf9de  shrd eax, r12d, 0x07
00007f30a29cf9e3  mov [rsp+0x10], r11d
00007f30a29cf9e8  mov r10d, [rsp+0x10]
00007f30a29cf9ed  shrd r11d, r10d, 0x11
00007f30a29cf9f2  mov r9d, [rsp+0x20]
00007f30a29cf9f7  lea r8d, [r9d+r14d*1]
00007f30a29cf9fc  rorx r14d, r12d, 0x12
00007f30a29cfa02  xor eax, r14d
00007f30a29cfa05  rorx r14d, r10d, 0x13
00007f30a29cfa0b  xor r11d, r14d
00007f30a29cfa0e  mov [rsp+0x10], r11d
00007f30a29cfa13  mov r11d, r11d
00007f30a29cfa16  mov [r15+0x88], r11
00007f30a29cfa1d  mov [rsp+0x20], r12d
00007f30a29cfa22  shr r12d, 0x03
00007f30a29cfa26  xor eax, r12d
00007f30a29cfa29  mov [rsp+0x40], eax
00007f30a29cfa2d  mov eax, eax
00007f30a29cfa2f  mov [r15+0x80], rax
00007f30a29cfa36  shr r10d, 0x0A
00007f30a29cfa3a  mov eax, [rsp+0x10]
00007f30a29cfa3e  xor eax, r10d
00007f30a29cfa41  mov [rsp+0x10], eax
00007f30a29cfa45  mov eax, eax
00007f30a29cfa47  mov [r15+0x78], rax
00007f30a29cfa4b  mov eax, [rsp+0x40]
00007f30a29cfa4f  lea r14d, [r8d+eax*1]
00007f30a29cfa54  mov eax, [rsp+0x10]
00007f30a29cfa58  lea r12d, [r14d+eax*1]
00007f30a29cfa5d  mov rax, [rsp+0x30]
00007f30a29cfa62  lea r14, [rax+0x40]
00007f30a29cfa66  mov [r13+r14*1], r12d
00007f30a29cfa6b  mov eax, [rsp+0x20]
00007f30a29cfa6f  mov eax, eax
00007f30a29cfa71  mov [r15+0x60], rax
00007f30a29cfa75  mov eax, [r15+0x108]
00007f30a29cfa7c  sahf
00007f30a29cfa7d  jnz 0x00007F30A29CFAAF
00007f30a29cfa7f  cmp dword ptr [r15+0x318], 0x00
00007f30a29cfa87  jz 0x00007F30A29CFF70
00007f30a29cfa8d  nop [rax+rax*1], ax
00007f30a29cfa96  nop [rax+rax*1], eax
00007f30a29cfa9e  mov eax, 0x41088C
00007f30a29cfaa3  mov [r15+0x100], rax
00007f30a29cfaaa  jmp 0x00007F30A27FE110
00007f30a29cfaaf  cmp dword ptr [r15+0x318], 0x00
00007f30a29cfab7  jz 0x00007F30A29CFDC0
00007f30a29cfabd  nop [rax+rax*1], ax
00007f30a29cfac6  nop [rax+rax*1], eax
00007f30a29cface  mov eax, 0x410844
00007f30a29cfad3  mov [r15+0x100], rax
00007f30a29cfada  jmp 0x00007F30A27FE110
00007f30a29cfadf  int3
00007f30a29cfae0  call 0x00007F30A280D860
00007f30a29cfae5  jmp 0x00007F30A29CF17A
00007f30a29cfaea  call 0x00007F30A28E2420
00007f30a29cfaef  jmp 0x00007F30A29CF193
00007f30a29cfaf4  call 0x00007F30A28E2420
00007f30a29cfaf9  jmp 0x00007F30A29CF1AC
00007f30a29cfafe  call 0x00007F30A28E2420
00007f30a29cfb03  jmp 0x00007F30A29CF1C5
00007f30a29cfb08  call 0x00007F30A28E2420
00007f30a29cfb0d  jmp 0x00007F30A29CF1DE
00007f30a29cfb12  call 0x00007F30A28E2420
00007f30a29cfb17  jmp 0x00007F30A29CF1EF
00007f30a29cfb1c  call 0x00007F30A28E2420
00007f30a29cfb21  jmp 0x00007F30A29CF200
00007f30a29cfb26  call 0x00007F30A28E2420
00007f30a29cfb2b  jmp 0x00007F30A29CF211
00007f30a29cfb30  call 0x00007F30A28E2420
00007f30a29cfb35  jmp 0x00007F30A29CF222
00007f30a29cfb3a  call 0x00007F30A28E2420
00007f30a29cfb3f  jmp 0x00007F30A29CF233
00007f30a29cfb44  call 0x00007F30A28E2420
00007f30a29cfb49  jmp 0x00007F30A29CF244
00007f30a29cfb4e  call 0x00007F30A28E2420
00007f30a29cfb53  jmp 0x00007F30A29CF255
00007f30a29cfb58  call 0x00007F30A28E2420
00007f30a29cfb5d  jmp 0x00007F30A29CF266
00007f30a29cfb62  call 0x00007F30A28E2420
00007f30a29cfb67  jmp 0x00007F30A29CF277
00007f30a29cfb6c  call 0x00007F30A28E2420
00007f30a29cfb71  jmp 0x00007F30A29CF288
00007f30a29cfb76  call 0x00007F30A28E2420
00007f30a29cfb7b  jmp 0x00007F30A29CF299
00007f30a29cfb80  call 0x00007F30A28E2420
00007f30a29cfb85  jmp 0x00007F30A29CF2AA
00007f30a29cfb8a  call 0x00007F30A28E2420
00007f30a29cfb8f  jmp 0x00007F30A29CF2BB
00007f30a29cfb94  call 0x00007F30A28E2420
00007f30a29cfb99  jmp 0x00007F30A29CF2CC
00007f30a29cfb9e  call 0x00007F30A28E2420
00007f30a29cfba3  jmp 0x00007F30A29CF2DD
00007f30a29cfba8  call 0x00007F30A28E2420
00007f30a29cfbad  jmp 0x00007F30A29CF2EE
00007f30a29cfbb2  call 0x00007F30A28E2420
00007f30a29cfbb7  jmp 0x00007F30A29CF2FF
00007f30a29cfbbc  call 0x00007F30A28E2420
00007f30a29cfbc1  jmp 0x00007F30A29CF310
00007f30a29cfbc6  call 0x00007F30A28E2420
00007f30a29cfbcb  jmp 0x00007F30A29CF321
00007f30a29cfbd0  call 0x00007F30A28E2420
00007f30a29cfbd5  jmp 0x00007F30A29CF332
00007f30a29cfbda  call 0x00007F30A28E2420
00007f30a29cfbdf  jmp 0x00007F30A29CF343
00007f30a29cfbe4  call 0x00007F30A28E2420
00007f30a29cfbe9  jmp 0x00007F30A29CF354
00007f30a29cfbee  call 0x00007F30A28E2420
00007f30a29cfbf3  jmp 0x00007F30A29CF365
00007f30a29cfbf8  call 0x00007F30A28E2420
00007f30a29cfbfd  jmp 0x00007F30A29CF376
00007f30a29cfc02  call 0x00007F30A28E2420
00007f30a29cfc07  jmp 0x00007F30A29CF387
00007f30a29cfc0c  call 0x00007F30A28E2420
00007f30a29cfc11  jmp 0x00007F30A29CF398
00007f30a29cfc16  call 0x00007F30A28E2420
00007f30a29cfc1b  jmp 0x00007F30A29CF3A9
00007f30a29cfc20  call 0x00007F30A28E2420
00007f30a29cfc25  jmp 0x00007F30A29CF3BA
00007f30a29cfc2a  call 0x00007F30A28E2420
00007f30a29cfc2f  jmp 0x00007F30A29CF3CB
00007f30a29cfc34  call 0x00007F30A28E2420
00007f30a29cfc39  jmp 0x00007F30A29CF3DC
00007f30a29cfc3e  call 0x00007F30A28E2420
00007f30a29cfc43  jmp 0x00007F30A29CF3ED
00007f30a29cfc48  call 0x00007F30A28E2420
00007f30a29cfc4d  jmp 0x00007F30A29CF3FE
00007f30a29cfc52  call 0x00007F30A28E2420
00007f30a29cfc57  jmp 0x00007F30A29CF40F
00007f30a29cfc5c  call 0x00007F30A28E2420
00007f30a29cfc61  jmp 0x00007F30A29CF420
00007f30a29cfc66  call 0x00007F30A28E2420
00007f30a29cfc6b  jmp 0x00007F30A29CF431
00007f30a29cfc70  call 0x00007F30A28E2420
00007f30a29cfc75  jmp 0x00007F30A29CF442
00007f30a29cfc7a  call 0x00007F30A28E2420
00007f30a29cfc7f  jmp 0x00007F30A29CF453
00007f30a29cfc84  call 0x00007F30A28E2420
00007f30a29cfc89  jmp 0x00007F30A29CF464
00007f30a29cfc8e  call 0x00007F30A28E2420
00007f30a29cfc93  jmp 0x00007F30A29CF475
00007f30a29cfc98  call 0x00007F30A28E2420
00007f30a29cfc9d  jmp 0x00007F30A29CF486
00007f30a29cfca2  call 0x00007F30A28E2420
00007f30a29cfca7  jmp 0x00007F30A29CF497
00007f30a29cfcac  call 0x00007F30A28E2420
00007f30a29cfcb1  jmp 0x00007F30A29CF4A8
00007f30a29cfcb6  call 0x00007F30A28E2420
00007f30a29cfcbb  jmp 0x00007F30A29CF4B9
00007f30a29cfcc0  call 0x00007F30A28E2420
00007f30a29cfcc5  jmp 0x00007F30A29CF4CA
00007f30a29cfcca  call 0x00007F30A28E2420
00007f30a29cfccf  jmp 0x00007F30A29CF4DB
00007f30a29cfcd4  call 0x00007F30A28E2420
00007f30a29cfcd9  jmp 0x00007F30A29CF4EC
00007f30a29cfcde  call 0x00007F30A28E2420
00007f30a29cfce3  jmp 0x00007F30A29CF4FD
00007f30a29cfce8  call 0x00007F30A28E2420
00007f30a29cfced  jmp 0x00007F30A29CF50E
00007f30a29cfcf2  call 0x00007F30A28E2420
00007f30a29cfcf7  jmp 0x00007F30A29CF51F
00007f30a29cfcfc  call 0x00007F30A28E2420
00007f30a29cfd01  jmp 0x00007F30A29CF530
00007f30a29cfd06  call 0x00007F30A28E2420
00007f30a29cfd0b  jmp 0x00007F30A29CF541
00007f30a29cfd10  call 0x00007F30A28E2420
00007f30a29cfd15  jmp 0x00007F30A29CF552
00007f30a29cfd1a  call 0x00007F30A28E2420
00007f30a29cfd1f  jmp 0x00007F30A29CF563
00007f30a29cfd24  call 0x00007F30A28E2420
00007f30a29cfd29  jmp 0x00007F30A29CF574
00007f30a29cfd2e  call 0x00007F30A28E2420
00007f30a29cfd33  jmp 0x00007F30A29CF585
00007f30a29cfd38  call 0x00007F30A28E2420
00007f30a29cfd3d  jmp 0x00007F30A29CF596
00007f30a29cfd42  call 0x00007F30A28E2420
00007f30a29cfd47  jmp 0x00007F30A29CF5AF
00007f30a29cfd4c  call 0x00007F30A28E2420
00007f30a29cfd51  jmp 0x00007F30A29CF5C8
00007f30a29cfd56  call 0x00007F30A28D5610
00007f30a29cfd5b  jmp 0x00007F30A29CF5E1
00007f30a29cfd60  call 0x00007F30A28DC580
00007f30a29cfd65  jmp 0x00007F30A29CF94E
00007f30a29cfd6a  call 0x00007F30A28E46C0
00007f30a29cfd6f  jmp 0x00007F30A29CF958
00007f30a29cfd74  call 0x00007F30A2809E90
00007f30a29cfd79  jmp 0x00007F30A29CF95E
00007f30a29cfd7e  call 0x00007F30A28DB310
00007f30a29cfd83  jmp 0x00007F30A29CF968
00007f30a29cfd88  call 0x00007F30A280DAE0
00007f30a29cfd8d  jmp 0x00007F30A29CF96D
00007f30a29cfd92  call 0x00007F30A28C0230
00007f30a29cfd97  jmp 0x00007F30A29CF986
00007f30a29cfd9c  call 0x00007F30A28C0230
00007f30a29cfda1  jmp 0x00007F30A29CF99B
00007f30a29cfda6  call 0x00007F30A28BEFC0
00007f30a29cfdab  jmp 0x00007F30A29CF9A4
00007f30a29cfdb0  call 0x00007F30A28E2BA0
00007f30a29cfdb5  jmp 0x00007F30A29CFA6B
00007f30a29cfdba  int3
00007f30a29cfdbb  nop [rax+rax*1], eax
00007f30a29cfdc0  mov rax, [r15+0x48]
00007f30a29cfdc4  mov r14, [r15+0x58]
00007f30a29cfdc8  lea r12, [rax+r14*1]
00007f30a29cfdcc  mov [r15+0x68], r12
00007f30a29cfdd0  lea rax, [r14+0x04]
00007f30a29cfdd4  mov [r15+0x58], rax
00007f30a29cfdd8  lea r14, [r12+0x04]
00007f30a29cfddd  mov r11d, [r13+r14*1]
00007f30a29cfde2  mov [rsp+0x10], r11d
00007f30a29cfde7  mov r11d, r11d
00007f30a29cfdea  mov [r15+0x70], r11
00007f30a29cfdee  lea r14, [r12+0x38]
00007f30a29cfdf3  mov r11d, [r13+r14*1]
00007f30a29cfdf8  lea r14, [r12+0x24]
00007f30a29cfdfd  mov r10d, [r13+r14*1]
00007f30a29cfe02  mov [rsp+0x20], r10d
00007f30a29cfe07  mov r10d, r10d
00007f30a29cfe0a  mov [r15+0x90], r10
00007f30a29cfe11  mov [rsp+0x30], rax
00007f30a29cfe16  xor eax, eax
00007f30a29cfe18  mov r14, [rsp+0x30]
00007f30a29cfe1d  mov r10d, 0xC0
00007f30a29cfe23  cmp r14, r10
00007f30a29cfe26  cmc
00007f30a29cfe27  lahf
00007f30a29cfe28  seto al
00007f30a29cfe2b  mov [r15+0x108], eax
00007f30a29cfe32  mov eax, [rsp+0x10]
00007f30a29cfe36  mov r14d, [rsp+0x10]
00007f30a29cfe3b  shrd eax, r14d, 0x07
00007f30a29cfe40  mov [rsp+0x10], r11d
00007f30a29cfe45  mov r10d, [rsp+0x10]
00007f30a29cfe4a  shrd r11d, r10d, 0x11
00007f30a29cfe4f  mov r9d, [r15+0x60]
00007f30a29cfe53  mov r8d, [rsp+0x20]
00007f30a29cfe58  lea ebp, [r8d+r9d*1]
00007f30a29cfe5d  rorx r9d, r14d, 0x12
00007f30a29cfe63  xor eax, r9d
00007f30a29cfe66  rorx r9d, r10d, 0x13
00007f30a29cfe6c  xor r11d, r9d
00007f30a29cfe6f  mov [rsp+0x10], r11d
00007f30a29cfe74  mov r11d, r11d
00007f30a29cfe77  mov [r15+0x88], r11
00007f30a29cfe7e  mov [rsp+0x20], r14d
00007f30a29cfe83  shr r14d, 0x03
00007f30a29cfe87  xor eax, r14d
00007f30a29cfe8a  mov [rsp+0x30], eax
00007f30a29cfe8e  mov eax, eax
00007f30a29cfe90  mov [r15+0x80], rax
00007f30a29cfe97  shr r10d, 0x0A
00007f30a29cfe9b  mov eax, [rsp+0x10]
00007f30a29cfe9f  xor eax, r10d
00007f30a29cfea2  mov [rsp+0x10], eax
00007f30a29cfea6  mov eax, eax
00007f30a29cfea8  mov [r15+0x78], rax
00007f30a29cfeac  mov eax, [rsp+0x30]
00007f30a29cfeb0  lea r14d, [ebp+eax*1]
00007f30a29cfeb6  mov eax, [rsp+0x10]
00007f30a29cfeba  lea r11d, [r14d+eax*1]
00007f30a29cfebf  lea rax, [r12+0x40]
00007f30a29cfec4  mov [r13+rax*1], r11d
00007f30a29cfec9  mov eax, [rsp+0x20]
00007f30a29cfecd  mov eax, eax
00007f30a29cfecf  mov [r15+0x60], rax
00007f30a29cfed3  mov eax, [r15+0x108]
00007f30a29cfeda  sahf
00007f30a29cfedb  jnz 0x00007F30A29CFF0D
00007f30a29cfedd  cmp dword ptr [r15+0x318], 0x00
00007f30a29cfee5  jz 0x00007F30A29CFF70
00007f30a29cfeeb  nop [rax+rax*1], ax
00007f30a29cfef4  nop [rax+rax*1], eax
00007f30a29cfefc  mov eax, 0x41088C
00007f30a29cff01  mov [r15+0x100], rax
00007f30a29cff08  jmp 0x00007F30A27FE110
00007f30a29cff0d  cmp dword ptr [r15+0x318], 0x00
00007f30a29cff15  jz 0x00007F30A29CFDC0
00007f30a29cff1b  nop [rax+rax*1], ax
00007f30a29cff24  nop [rax+rax*1], eax
00007f30a29cff2c  mov eax, 0x410844
00007f30a29cff31  mov [r15+0x100], rax
00007f30a29cff38  jmp 0x00007F30A27FE110
00007f30a29cff3d  int3
00007f30a29cff3e  call 0x00007F30A28E1430
00007f30a29cff43  jmp 0x00007F30A29CFDE2
00007f30a29cff48  call 0x00007F30A28E1430
00007f30a29cff4d  jmp 0x00007F30A29CFDF8
00007f30a29cff52  call 0x00007F30A28E01C0
00007f30a29cff57  jmp 0x00007F30A29CFE02
00007f30a29cff5c  call 0x00007F30A280A860
00007f30a29cff61  jmp 0x00007F30A29CFEC9
00007f30a29cff66  int3
00007f30a29cff67  nop [rax+rax*1], ax
00007f30a29cff70  mov rax, [r15]
00007f30a29cff73  mov r14d, [r13+rax*1]
00007f30a29cff78  lea r12, [rax+0x04]
00007f30a29cff7c  mov r11d, [r13+r12*1]
00007f30a29cff81  mov [rsp+0x10], r14d
00007f30a29cff86  mov r14d, r14d
00007f30a29cff89  mov [r15+0x78], r14
00007f30a29cff8d  mov [rsp+0x20], r11d
00007f30a29cff92  mov r11d, r11d
00007f30a29cff95  mov [r15+0x80], r11
00007f30a29cff9c  lea r14, [rax+0x08]
00007f30a29cffa0  mov r12d, [r13+r14*1]
00007f30a29cffa5  lea r14, [rax+0x0C]
00007f30a29cffa9  mov r11d, [r13+r14*1]
00007f30a29cffae  mov [rsp+0x30], r12d
00007f30a29cffb3  mov r12d, r12d
00007f30a29cffb6  mov [r15+0x70], r12
00007f30a29cffba  mov [rsp+0x40], r11d
00007f30a29cffbf  mov r11d, r11d
00007f30a29cffc2  mov [r15+0x68], r11
00007f30a29cffc6  lea r14, [rax+0x18]
00007f30a29cffca  mov r12d, [r13+r14*1]
00007f30a29cffcf  lea r14, [rax+0x1C]
00007f30a29cffd3  mov r11d, [r13+r14*1]
00007f30a29cffd8  mov [rsp+0x50], r12d
00007f30a29cffdd  mov r12d, r12d
00007f30a29cffe0  mov [r15+0x58], r12
00007f30a29cffe4  mov [rsp+0x60], r11d
00007f30a29cffe9  mov r11d, r11d
00007f30a29cffec  mov [r15+0x60], r11
00007f30a29cfff0  lea r14, [rax+0x10]
00007f30a29cfff4  mov r12d, [r13+r14*1]
00007f30a29cfff9  lea r14, [rax+0x14]
00007f30a29cfffd  mov eax, [r13+r14*1]
00007f30a29d0002  mov [rsp+0x70], r12d
00007f30a29d0007  mov r12d, r12d
00007f30a29d000a  mov [r15+0x18], r12
00007f30a29d000e  mov [rsp+0x80], eax
00007f30a29d0015  mov eax, eax
00007f30a29d0017  mov [r15+0x90], rax
00007f30a29d001e  mov eax, [rsp+0x70]
00007f30a29d0022  mov eax, eax
00007f30a29d0024  mov [r15+0x30], rax
00007f30a29d0028  mov eax, [rsp+0x50]
00007f30a29d002c  mov eax, eax
00007f30a29d002e  mov [r15+0xA0], rax
00007f30a29d0035  mov eax, [rsp+0x30]
00007f30a29d0039  mov eax, eax
00007f30a29d003b  mov [r15+0x28], rax
00007f30a29d003f  mov eax, [rsp+0x20]
00007f30a29d0043  mov eax, eax
00007f30a29d0045  mov [r15+0x98], rax
00007f30a29d004c  mov eax, [rsp+0x10]
00007f30a29d0050  mov eax, eax
00007f30a29d0052  mov [r15+0x38], rax
00007f30a29d0056  mov eax, [rsp+0x70]
00007f30a29d005a  mov r14d, [rsp+0x70]
00007f30a29d005f  shrd eax, r14d, 0x06
00007f30a29d0064  mov [rsp+0x70], r14d
00007f30a29d0069  mov r12d, [rsp+0x80]
00007f30a29d0071  and r14d, r12d
00007f30a29d0074  mov r11d, [rsp+0x10]
00007f30a29d0079  mov r10d, [rsp+0x10]
00007f30a29d007e  shrd r11d, r10d, 0x02
00007f30a29d0083  mov [rsp+0x10], r12d
00007f30a29d0088  mov r12d, r12d
00007f30a29d008b  mov [r15+0x20], r12
00007f30a29d008f  mov r12, [r15+0x50]
00007f30a29d0093  mov r9d, [r13+r12*1]
00007f30a29d0098  mov r12d, [rsp+0x50]
00007f30a29d009d  mov r8d, [rsp+0x70]
00007f30a29d00a2  andn ebp, r8d, r12d
00007f30a29d00a7  mov edi, [rsp+0x60]
00007f30a29d00ab  lea esi, [r14d+edi*1]
00007f30a29d00b0  rorx r14d, r8d, 0x0B
00007f30a29d00b6  xor eax, r14d
00007f30a29d00b9  rorx r14d, r10d, 0x0D
00007f30a29d00bf  xor r11d, r14d
00007f30a29d00c2  lea edi, [esi+ebp*1]
00007f30a29d00c6  mov r14, [r15+0x48]
00007f30a29d00ca  mov ebp, [r13+r14*1]
00007f30a29d00cf  mov r14d, [rsp+0x30]
00007f30a29d00d4  mov esi, [rsp+0x20]
00007f30a29d00d8  and r14d, esi
00007f30a29d00db  mov [rsp+0x20], r14d
00007f30a29d00e0  mov r14d, r14d
00007f30a29d00e3  mov [r15+0xD8], r14
00007f30a29d00ea  lea r14d, [edi+r9d*1]
00007f30a29d00ef  mov r9d, [rsp+0x30]
00007f30a29d00f4  xor r9d, esi
00007f30a29d00f7  rorx edi, r8d, 0x19
00007f30a29d00fd  xor eax, edi
00007f30a29d00ff  and r9d, r10d
00007f30a29d0102  rorx edi, r10d, 0x16
00007f30a29d0108  xor r11d, edi
00007f30a29d010b  mov [rsp+0x30], r11d
00007f30a29d0110  mov r11d, r11d
00007f30a29d0113  mov [r15+0xD0], r11
00007f30a29d011a  lea r11d, [r14d+ebp*1]
00007f30a29d011f  mov r10d, [rsp+0x20]
00007f30a29d0124  xor r9d, r10d
00007f30a29d0127  lea r14d, [r11d+eax*1]
00007f30a29d012c  mov qword ptr [r15+0x88], 0x04
00007f30a29d0137  mov eax, [rsp+0x30]
00007f30a29d013b  lea r11d, [r9d+eax*1]
00007f30a29d0140  mov eax, [rsp+0x40]
00007f30a29d0144  lea r10d, [r14d+eax*1]
00007f30a29d0149  mov r10d, r10d
00007f30a29d014c  mov [r15+0xB8], r10
00007f30a29d0153  xor eax, eax
00007f30a29d0155  mov r10d, 0x04
00007f30a29d015b  mov r9d, 0x100
00007f30a29d0161  cmp r10, r9
00007f30a29d0164  cmc
00007f30a29d0165  lahf
00007f30a29d0166  seto al
00007f30a29d0169  mov [r15+0x108], eax
00007f30a29d0170  lea eax, [r11d+r14d*1]
00007f30a29d0175  mov eax, eax
00007f30a29d0177  mov [r15+0xA8], rax
00007f30a29d017e  mov r12d, r12d
00007f30a29d0181  mov [r15+0xB0], r12
00007f30a29d0188  mov eax, [rsp+0x10]
00007f30a29d018c  mov eax, eax
00007f30a29d018e  mov [r15+0xC0], rax
00007f30a29d0195  mov r8d, r8d
00007f30a29d0198  mov [r15+0xC8], r8
00007f30a29d019f  mov eax, [r15+0x108]
00007f30a29d01a6  sahf
00007f30a29d01a7  jnz 0x00007F30A29D01D9
00007f30a29d01a9  cmp dword ptr [r15+0x318], 0x00
00007f30a29d01b1  jz 0x00007F30A29D04A0
00007f30a29d01b7  nop [rax+rax*1], ax
00007f30a29d01c0  nop [rax+rax*1], eax
00007f30a29d01c8  mov eax, 0x41094C
00007f30a29d01cd  mov [r15+0x100], rax
00007f30a29d01d4  jmp 0x00007F30A27FE110
00007f30a29d01d9  cmp dword ptr [r15+0x318], 0x00
00007f30a29d01e1  jz 0x00007F30A29D0270
00007f30a29d01e7  nop [rax+rax*1], ax
00007f30a29d01f0  nop [rax+rax*1], eax
00007f30a29d01f8  mov eax, 0x4108C0
00007f30a29d01fd  mov [r15+0x100], rax
00007f30a29d0204  jmp 0x00007F30A27FE110
00007f30a29d0209  int3
00007f30a29d020a  call 0x00007F30A280DAE0
00007f30a29d020f  jmp 0x00007F30A29CFF78
00007f30a29d0214  call 0x00007F30A28C0230
00007f30a29d0219  jmp 0x00007F30A29CFF81
00007f30a29d021e  call 0x00007F30A28E26A0
00007f30a29d0223  jmp 0x00007F30A29CFFA5
00007f30a29d0228  call 0x00007F30A28E1430
00007f30a29d022d  jmp 0x00007F30A29CFFAE
00007f30a29d0232  call 0x00007F30A28E26A0
00007f30a29d0237  jmp 0x00007F30A29CFFCF
00007f30a29d023c  call 0x00007F30A28E1430
00007f30a29d0241  jmp 0x00007F30A29CFFD8
00007f30a29d0246  call 0x00007F30A28E26A0
00007f30a29d024b  jmp 0x00007F30A29CFFF9
00007f30a29d0250  call 0x00007F30A28D5890
00007f30a29d0255  jmp 0x00007F30A29D0002
00007f30a29d025a  call 0x00007F30A28BDD50
00007f30a29d025f  jmp 0x00007F30A29D0098
00007f30a29d0264  call 0x00007F30A28DA580
00007f30a29d0269  jmp 0x00007F30A29D00CF
00007f30a29d026e  int3
00007f30a29d026f  nop
00007f30a29d0270  mov eax, [r15+0xB8]
00007f30a29d0277  mov [rsp+0x10], eax
00007f30a29d027b  mov eax, eax
00007f30a29d027d  mov [r15+0x30], rax
00007f30a29d0281  mov eax, [r15+0xC0]
00007f30a29d0288  mov [rsp+0x20], eax
00007f30a29d028c  mov eax, eax
00007f30a29d028e  mov [r15+0xA0], rax
00007f30a29d0295  mov eax, [r15+0x28]
00007f30a29d0299  mov r14d, [r15+0x98]
00007f30a29d02a0  mov [rsp+0x30], r14d
00007f30a29d02a5  mov r14d, r14d
00007f30a29d02a8  mov [r15+0x28], r14
00007f30a29d02ac  mov r14d, [r15+0x38]
00007f30a29d02b0  mov [rsp+0x40], r14d
00007f30a29d02b5  mov r14d, r14d
00007f30a29d02b8  mov [r15+0x98], r14
00007f30a29d02bf  mov r14d, [r15+0xA8]
00007f30a29d02c6  mov [rsp+0x50], r14d
00007f30a29d02cb  mov r14d, r14d
00007f30a29d02ce  mov [r15+0x38], r14
00007f30a29d02d2  mov r14d, [rsp+0x10]
00007f30a29d02d7  mov r12d, [rsp+0x10]
00007f30a29d02dc  shrd r14d, r12d, 0x06
00007f30a29d02e1  mov r11d, [r15+0xC8]
00007f30a29d02e8  mov [rsp+0x10], r12d
00007f30a29d02ed  and r12d, r11d
00007f30a29d02f0  mov r10d, [rsp+0x50]
00007f30a29d02f5  mov r9d, [rsp+0x50]
00007f30a29d02fa  shrd r10d, r9d, 0x02
00007f30a29d02ff  mov [rsp+0x50], r11d
00007f30a29d0304  mov r11d, r11d
00007f30a29d0307  mov [r15+0x20], r11
00007f30a29d030b  mov r11, [r15+0x88]
00007f30a29d0312  mov r8, [r15+0x50]
00007f30a29d0316  lea rbp, [r8+r11*1]
00007f30a29d031a  mov r8d, [r13+rbp*1]
00007f30a29d031f  mov ebp, [rsp+0x20]
00007f30a29d0323  mov edi, [rsp+0x10]
00007f30a29d0327  andn esi, edi, ebp
00007f30a29d032c  mov edx, [r15+0xB0]
00007f30a29d0333  lea ecx, [r12d+edx*1]
00007f30a29d0338  rorx r12d, edi, 0x0B
00007f30a29d033e  xor r14d, r12d
00007f30a29d0341  rorx r12d, r9d, 0x0D
00007f30a29d0347  xor r10d, r12d
00007f30a29d034a  lea r12d, [ecx+esi*1]
00007f30a29d034f  mov rsi, [r15+0x48]
00007f30a29d0353  lea rdx, [rsi+r11*1]
00007f30a29d0357  mov esi, [r13+rdx*1]
00007f30a29d035c  mov edx, [rsp+0x30]
00007f30a29d0360  mov ecx, [rsp+0x40]
00007f30a29d0364  and edx, ecx
00007f30a29d0366  mov [rsp+0x10], edx
00007f30a29d036a  mov edx, edx
00007f30a29d036c  mov [r15+0xD8], rdx
00007f30a29d0373  lea edx, [r12d+r8d*1]
00007f30a29d0378  mov r12d, [rsp+0x30]
00007f30a29d037d  xor r12d, ecx
00007f30a29d0380  rorx r8d, edi, 0x19
00007f30a29d0386  xor r14d, r8d
00007f30a29d0389  and r12d, r9d
00007f30a29d038c  rorx r8d, r9d, 0x16
00007f30a29d0392  xor r10d, r8d
00007f30a29d0395  mov [rsp+0x20], r10d
00007f30a29d039a  mov r10d, r10d
00007f30a29d039d  mov [r15+0xD0], r10
00007f30a29d03a4  lea r10d, [edx+esi*1]
00007f30a29d03a9  mov r9d, [rsp+0x10]
00007f30a29d03ae  xor r12d, r9d
00007f30a29d03b1  lea r9d, [r10d+r14d*1]
00007f30a29d03b6  lea r14, [r11+0x04]
00007f30a29d03ba  mov [r15+0x88], r14
00007f30a29d03c1  mov r11d, [rsp+0x20]
00007f30a29d03c6  lea r10d, [r12d+r11d*1]
00007f30a29d03cb  lea r11d, [r9d+eax*1]
00007f30a29d03d0  mov r11d, r11d
00007f30a29d03d3  mov [r15+0xB8], r11
00007f30a29d03da  xor eax, eax
00007f30a29d03dc  mov r12d, 0x100
00007f30a29d03e2  cmp r14, r12
00007f30a29d03e5  cmc
00007f30a29d03e6  lahf
00007f30a29d03e7  seto al
00007f30a29d03ea  mov [r15+0x108], eax
00007f30a29d03f1  lea eax, [r10d+r9d*1]
00007f30a29d03f6  mov eax, eax
00007f30a29d03f8  mov [r15+0xA8], rax
00007f30a29d03ff  mov ebp, ebp
00007f30a29d0401  mov [r15+0xB0], rbp
00007f30a29d0408  mov eax, [rsp+0x50]
00007f30a29d040c  mov eax, eax
00007f30a29d040e  mov [r15+0xC0], rax
00007f30a29d0415  mov edi, edi
00007f30a29d0417  mov [r15+0xC8], rdi
00007f30a29d041e  mov eax, [r15+0x108]
00007f30a29d0425  sahf
00007f30a29d0426  jnz 0x00007F30A29D0458
00007f30a29d0428  cmp dword ptr [r15+0x318], 0x00
00007f30a29d0430  jz 0x00007F30A29D04A0
00007f30a29d0436  nop [rax+rax*1], ax
00007f30a29d043f  nop [rax+rax*1], eax
00007f30a29d0447  mov eax, 0x41094C
00007f30a29d044c  mov [r15+0x100], rax
00007f30a29d0453  jmp 0x00007F30A27FE110
00007f30a29d0458  cmp dword ptr [r15+0x318], 0x00
00007f30a29d0460  jz 0x00007F30A29D0270
00007f30a29d0466  nop [rax+rax*1], ax
00007f30a29d046f  nop [rax+rax*1], eax
00007f30a29d0477  mov eax, 0x4108C0
00007f30a29d047c  mov [r15+0x100], rax
00007f30a29d0483  jmp 0x00007F30A27FE110
00007f30a29d0488  int3
00007f30a29d0489  call 0x00007F30A2849010
00007f30a29d048e  jmp 0x00007F30A29D031F
00007f30a29d0493  call 0x00007F30A2825930
00007f30a29d0498  jmp 0x00007F30A29D035C
00007f30a29d049d  int3
00007f30a29d049e  nop
00007f30a29d04a0  mov eax, [r15+0x98]
00007f30a29d04a7  mov r14d, [r15+0x70]
00007f30a29d04ab  lea r12d, [eax+r14d*1]
00007f30a29d04b0  mov eax, [r15+0x28]
00007f30a29d04b4  mov r14d, [r15+0x68]
00007f30a29d04b8  lea r11d, [eax+r14d*1]
00007f30a29d04bd  mov qword ptr [r15+0x88], 0x00
00007f30a29d04c8  mov eax, [r15+0xA8]
00007f30a29d04cf  mov r14d, [r15+0x78]
00007f30a29d04d3  lea r10d, [eax+r14d*1]
00007f30a29d04d8  mov [rsp+0x10], r10d
00007f30a29d04dd  mov r10d, r10d
00007f30a29d04e0  mov [r15+0x78], r10
00007f30a29d04e4  mov eax, [r15+0x38]
00007f30a29d04e8  mov r14d, [r15+0x80]
00007f30a29d04ef  lea r10d, [eax+r14d*1]
00007f30a29d04f4  mov [rsp+0x20], r10d
00007f30a29d04f9  mov r10d, r10d
00007f30a29d04fc  mov [r15+0x80], r10
00007f30a29d0503  mov rax, [r15]
00007f30a29d0506  lea r14, [rax+0x08]
00007f30a29d050a  mov [r13+r14*1], r12d
00007f30a29d050f  lea r14, [rax+0x0C]
00007f30a29d0513  mov [r13+r14*1], r11d
00007f30a29d0518  mov r14d, [r15+0xB8]
00007f30a29d051f  mov r12d, [r15+0x18]
00007f30a29d0523  lea r11d, [r14d+r12d*1]
00007f30a29d0528  mov [rsp+0x30], r11d
00007f30a29d052d  mov r11d, r11d
00007f30a29d0530  mov [r15+0x68], r11
00007f30a29d0534  mov r14d, [r15+0x30]
00007f30a29d0538  mov r12d, [r15+0x90]
00007f30a29d053f  lea r11d, [r14d+r12d*1]
00007f30a29d0544  mov [rsp+0x40], r11d
00007f30a29d0549  mov r11d, r11d
00007f30a29d054c  mov [r15+0x70], r11
00007f30a29d0550  mov r14d, [r15+0x20]
00007f30a29d0554  mov r12d, [r15+0x58]
00007f30a29d0558  lea r11d, [r14d+r12d*1]
00007f30a29d055d  mov [rsp+0x50], r11d
00007f30a29d0562  mov r11d, r11d
00007f30a29d0565  mov [r15+0x58], r11
00007f30a29d0569  mov r14d, [r15+0xA0]
00007f30a29d0570  mov r12d, [r15+0x60]
00007f30a29d0574  lea r11d, [r14d+r12d*1]
00007f30a29d0579  mov [rsp+0x60], r11d
00007f30a29d057e  mov r11d, r11d
00007f30a29d0581  mov [r15+0x60], r11
00007f30a29d0585  mov r14d, [rsp+0x10]
00007f30a29d058a  mov [r13+rax*1], r14d
00007f30a29d058f  lea r14, [rax+0x04]
00007f30a29d0593  mov r12d, [rsp+0x20]
00007f30a29d0598  mov [r13+r14*1], r12d
00007f30a29d059d  lea r14, [rax+0x10]
00007f30a29d05a1  mov r12d, [rsp+0x30]
00007f30a29d05a6  mov [r13+r14*1], r12d
00007f30a29d05ab  lea r14, [rax+0x14]
00007f30a29d05af  mov r12d, [rsp+0x40]
00007f30a29d05b4  mov [r13+r14*1], r12d
00007f30a29d05b9  lea r14, [rax+0x18]
00007f30a29d05bd  mov r12d, [rsp+0x50]
00007f30a29d05c2  mov [r13+r14*1], r12d
00007f30a29d05c7  lea r14, [rax+0x1C]
00007f30a29d05cb  mov r12d, [rsp+0x60]
00007f30a29d05d0  mov [r13+r14*1], r12d
00007f30a29d05d5  lea r14, [rax+0x68]
00007f30a29d05d9  xor eax, eax
00007f30a29d05db  mov [r13+r14*1], rax
00007f30a29d05e0  cmp dword ptr [r15+0x318], 0x00
00007f30a29d05e8  jz 0x00007F30A29CF0E0
00007f30a29d05ee  nop [rax+rax*1], ax
00007f30a29d05f7  nop [rax+rax*1], eax
00007f30a29d05ff  mov eax, 0x410768
00007f30a29d0604  mov [r15+0x100], rax
00007f30a29d060b  jmp 0x00007F30A27FE110
00007f30a29d0610  int3
00007f30a29d0611  call 0x00007F30A28E2BA0
00007f30a29d0616  jmp 0x00007F30A29D050F
00007f30a29d061b  call 0x00007F30A28E1920
00007f30a29d0620  jmp 0x00007F30A29D0518
00007f30a29d0625  call 0x00007F30A280DFE0
00007f30a29d062a  jmp 0x00007F30A29D058F
00007f30a29d062f  call 0x00007F30A28E2BA0
00007f30a29d0634  jmp 0x00007F30A29D059D
00007f30a29d0639  call 0x00007F30A28E2BA0
00007f30a29d063e  jmp 0x00007F30A29D05AB
00007f30a29d0643  call 0x00007F30A28E2BA0
00007f30a29d0648  jmp 0x00007F30A29D05B9
00007f30a29d064d  call 0x00007F30A28E2BA0
00007f30a29d0652  jmp 0x00007F30A29D05C7
00007f30a29d0657  call 0x00007F30A28E2BA0
00007f30a29d065c  jmp 0x00007F30A29D05D5
00007f30a29d0661  call 0x00007F30A28D5EB0
00007f30a29d0666  jmp 0x00007F30A29D05E0
00007f30a29d066b  int3
00007f30a29d066c  nop [rax], eax
00007f30a29d0670  mov rax, [r15+0xF8]
00007f30a29d0677  lea r14, [rax+0x140]
00007f30a29d067e  mov r12, [r13+r14*1]
00007f30a29d0683  lea r14, [rax+0x148]
00007f30a29d068a  mov r11, [r13+r14*1]
00007f30a29d068f  mov [r15+0xA0], r12
00007f30a29d0696  mov [r15+0x98], r11
00007f30a29d069d  lea r14, [rax+0x130]
00007f30a29d06a4  mov r12, [r13+r14*1]
00007f30a29d06a9  lea r14, [rax+0x138]
00007f30a29d06b0  mov r11, [r13+r14*1]
00007f30a29d06b5  mov [r15+0xB0], r12
00007f30a29d06bc  mov [r15+0xA8], r11
00007f30a29d06c3  lea r14, [rax+0x120]
00007f30a29d06ca  mov r12, [r13+r14*1]
00007f30a29d06cf  lea r14, [rax+0x128]
00007f30a29d06d6  mov r11, [r13+r14*1]
00007f30a29d06db  mov [r15+0xC0], r12
00007f30a29d06e2  mov [r15+0xB8], r11
00007f30a29d06e9  lea r14, [rax+0x110]
00007f30a29d06f0  mov r12, [r13+r14*1]
00007f30a29d06f5  lea r14, [rax+0x118]
00007f30a29d06fc  mov r11, [r13+r14*1]
00007f30a29d0701  mov [r15+0xD0], r12
00007f30a29d0708  mov [r15+0xC8], r11
00007f30a29d070f  lea r14, [rax+0x100]
00007f30a29d0716  mov r12, [r13+r14*1]
00007f30a29d071b  lea r14, [rax+0x108]
00007f30a29d0722  mov r11, [r13+r14*1]
00007f30a29d0727  mov [r15+0xE8], r12
00007f30a29d072e  mov [r15+0xD8], r11
00007f30a29d0735  lea r14, [rax+0x150]
00007f30a29d073c  mov [r15+0xF8], r14
00007f30a29d0743  mov rax, [r15+0xF0]
00007f30a29d074a  mov [r15+0x100], rax
00007f30a29d0751  jmp 0x00007F30A29CE5C0
00007f30a29d0756  int3
00007f30a29d0757  call 0x00007F30A28E27E0
00007f30a29d075c  jmp 0x00007F30A29D0683
00007f30a29d0761  call 0x00007F30A28E1570
00007f30a29d0766  jmp 0x00007F30A29D068F
00007f30a29d076b  call 0x00007F30A28E27E0
00007f30a29d0770  jmp 0x00007F30A29D06A9
00007f30a29d0775  call 0x00007F30A28E1570
00007f30a29d077a  jmp 0x00007F30A29D06B5
00007f30a29d077f  call 0x00007F30A28E27E0
00007f30a29d0784  jmp 0x00007F30A29D06CF
00007f30a29d0789  call 0x00007F30A28E1570
00007f30a29d078e  jmp 0x00007F30A29D06DB
00007f30a29d0793  call 0x00007F30A28E27E0
00007f30a29d0798  jmp 0x00007F30A29D06F5
00007f30a29d079d  call 0x00007F30A28E1570
00007f30a29d07a2  jmp 0x00007F30A29D0701
00007f30a29d07a7  call 0x00007F30A28E27E0
00007f30a29d07ac  jmp 0x00007F30A29D071B
00007f30a29d07b1  call 0x00007F30A28E1570
00007f30a29d07b6  jmp 0x00007F30A29D0727
00007f30a29d07bb  int3
00007f30a29d07bc  nop [rax], eax
00007f30a29d07c0  mov eax, [r15+0xA0]
00007f30a29d07c7  mov [rsp+0x10], eax
00007f30a29d07cb  xor eax, eax
00007f30a29d07cd  mov r14d, [rsp+0x10]
00007f30a29d07d2  sub r14d, 0x01
00007f30a29d07d6  cmc
00007f30a29d07d7  lahf
00007f30a29d07d8  seto al
00007f30a29d07db  mov [r15+0x108], eax
00007f30a29d07e2  mov r14d, r14d
00007f30a29d07e5  mov [r15+0xA0], r14
00007f30a29d07ec  mov eax, [r15+0x108]
00007f30a29d07f3  sahf
00007f30a29d07f4  jnz 0x00007F30A29D0826
00007f30a29d07f6  cmp dword ptr [r15+0x318], 0x00
00007f30a29d07fe  jz 0x00007F30A29D0900
00007f30a29d0804  nop [rax+rax*1], ax
00007f30a29d080d  nop [rax+rax*1], eax
00007f30a29d0815  mov eax, 0x41028C
00007f30a29d081a  mov [r15+0x100], rax
00007f30a29d0821  jmp 0x00007F30A27FE110
00007f30a29d0826  cmp dword ptr [r15+0x318], 0x00
00007f30a29d082e  jz 0x00007F30A29D0860
00007f30a29d0834  nop [rax+rax*1], ax
00007f30a29d083d  nop [rax+rax*1], eax
00007f30a29d0845  mov eax, 0x410274
00007f30a29d084a  mov [r15+0x100], rax
00007f30a29d0851  jmp 0x00007F30A27FE110
00007f30a29d0856  int3
00007f30a29d0857  int3
00007f30a29d0858  nop [rax+rax*1], eax
00007f30a29d0860  mov rax, [r15+0xF8]
00007f30a29d0867  lea r14, [rax+0x100]
00007f30a29d086e  mov [r15], r14
00007f30a29d0871  mov rax, [r15+0x98]
00007f30a29d0878  mov [r15+0x08], rax
00007f30a29d087c  mov qword ptr [r15+0x10], 0x12C
00007f30a29d0884  mov qword ptr [r15+0xF0], 0x410284
00007f30a29d088f  mov r14d, [r15+0x320]
00007f30a29d0896  mov eax, 0x410284
00007f30a29d089b  mov rcx, 0x7F30A29D07C0
00007f30a29d08a5  mov [r15+r14*8+0x328], rax
00007f30a29d08ad  mov [r15+r14*8+0x368], rcx
00007f30a29d08b5  add r14d, 0x01
00007f30a29d08b9  and r14d, 0x07
00007f30a29d08bd  mov [r15+0x320], r14d
00007f30a29d08c4  cmp dword ptr [r15+0x318], 0x00
00007f30a29d08cc  jz 0x00007F30A29CED70
00007f30a29d08d2  nop [rax+rax*1], ax
00007f30a29d08db  nop [rax+rax*1], eax
00007f30a29d08e3  mov eax, 0x410728
00007f30a29d08e8  mov [r15+0x100], rax
00007f30a29d08ef  jmp 0x00007F30A27FE110
00007f30a29d08f4  int3
00007f30a29d08f5  int3
00007f30a29d08f6  nop [rax+rax*1], ax
00007f30a29d08ff  nop
00007f30a29d0900  mov rax, [r15+0xF8]
00007f30a29d0907  lea r14, [rax+0x120]
00007f30a29d090e  mov r12, [r13+r14*1]
00007f30a29d0913  mov [r15+0x98], r12
00007f30a29d091a  mov qword ptr [r15+0x40], 0x80
00007f30a29d0922  lea r14, [rax+0x100]
00007f30a29d0929  mov [r15], r14
00007f30a29d092c  lea r14, [rax+0x17C]
00007f30a29d0933  mov [r15+0x08], r14
00007f30a29d0937  mov qword ptr [r15+0x10], 0x01
00007f30a29d093f  lea r14, [rax+0x17C]
00007f30a29d0946  mov eax, 0x80
00007f30a29d094b  mov [r13+r14*1], al
00007f30a29d0950  mov qword ptr [r15+0xF0], 0x4102A8
00007f30a29d095b  mov r14d, [r15+0x320]
00007f30a29d0962  mov eax, 0x4102A8
00007f30a29d0967  mov rcx, 0x7F30A29D09E0
00007f30a29d0971  mov [r15+r14*8+0x328], rax
00007f30a29d0979  mov [r15+r14*8+0x368], rcx
00007f30a29d0981  add r14d, 0x01
00007f30a29d0985  and r14d, 0x07
00007f30a29d0989  mov [r15+0x320], r14d
00007f30a29d0990  cmp dword ptr [r15+0x318], 0x00
00007f30a29d0998  jz 0x00007F30A29CED70
00007f30a29d099e  nop [rax+rax*1], ax
00007f30a29d09a7  nop [rax+rax*1], eax
00007f30a29d09af  mov eax, 0x410728
00007f30a29d09b4  mov [r15+0x100], rax
00007f30a29d09bb  jmp 0x00007F30A27FE110
00007f30a29d09c0  int3
00007f30a29d09c1  call 0x00007F30A28E27E0
00007f30a29d09c6  jmp 0x00007F30A29D0913
00007f30a29d09cb  call 0x00007F30A28D5AF0
00007f30a29d09d0  jmp 0x00007F30A29D0950
00007f30a29d09d5  int3
00007f30a29d09d6  nop [rax+rax*1], ax
00007f30a29d09df  nop
00007f30a29d09e0  mov rax, [r15+0xF8]
00007f30a29d09e7  lea r14, [rax+0x168]
00007f30a29d09ee  mov r12, [r13+r14*1]
00007f30a29d09f3  mov [r15+0x40], r12
00007f30a29d09f7  lea r14, [rax+0x178]
00007f30a29d09fe  xor eax, eax
00007f30a29d0a00  mov [r13+r14*1], al
00007f30a29d0a05  xor eax, eax
00007f30a29d0a07  mov r14d, 0x38
00007f30a29d0a0d  cmp r12, r14
00007f30a29d0a10  cmc
00007f30a29d0a11  lahf
00007f30a29d0a12  seto al
00007f30a29d0a15  mov [r15+0x108], eax
00007f30a29d0a1c  mov eax, [r15+0x108]
00007f30a29d0a23  sahf
00007f30a29d0a24  jz 0x00007F30A29D0A56
00007f30a29d0a26  cmp dword ptr [r15+0x318], 0x00
00007f30a29d0a2e  jz 0x00007F30A29D0AA0
00007f30a29d0a34  nop [rax+rax*1], ax
00007f30a29d0a3d  nop [rax+rax*1], eax
00007f30a29d0a45  mov eax, 0x4102B8
00007f30a29d0a4a  mov [r15+0x100], rax
00007f30a29d0a51  jmp 0x00007F30A27FE110
00007f30a29d0a56  cmp dword ptr [r15+0x318], 0x00
00007f30a29d0a5e  jz 0x00007F30A29D0BF0
00007f30a29d0a64  nop [rax+rax*1], ax
00007f30a29d0a6d  nop [rax+rax*1], eax
00007f30a29d0a75  mov eax, 0x4102D4
00007f30a29d0a7a  mov [r15+0x100], rax
00007f30a29d0a81  jmp 0x00007F30A27FE110
00007f30a29d0a86  int3
00007f30a29d0a87  call 0x00007F30A28E27E0
00007f30a29d0a8c  jmp 0x00007F30A29D09F3
00007f30a29d0a91  call 0x00007F30A28D5AF0
00007f30a29d0a96  jmp 0x00007F30A29D0A05
00007f30a29d0a9b  int3
00007f30a29d0a9c  nop [rax], eax
00007f30a29d0aa0  mov rax, [r15+0xF8]
00007f30a29d0aa7  lea r14, [rax+0x100]
00007f30a29d0aae  mov [r15], r14
00007f30a29d0ab1  lea r14, [rax+0x178]
00007f30a29d0ab8  mov [r15+0x08], r14
00007f30a29d0abc  mov qword ptr [r15+0x10], 0x01
00007f30a29d0ac4  mov qword ptr [r15+0xF0], 0x4102C8
00007f30a29d0acf  mov r14d, [r15+0x320]
00007f30a29d0ad6  mov eax, 0x4102C8
00007f30a29d0adb  mov rcx, 0x7F30A29D0B40
00007f30a29d0ae5  mov [r15+r14*8+0x328], rax
00007f30a29d0aed  mov [r15+r14*8+0x368], rcx
00007f30a29d0af5  add r14d, 0x01
00007f30a29d0af9  and r14d, 0x07
00007f30a29d0afd  mov [r15+0x320], r14d
00007f30a29d0b04  cmp dword ptr [r15+0x318], 0x00
00007f30a29d0b0c  jz 0x00007F30A29CED70
00007f30a29d0b12  nop [rax+rax*1], ax
00007f30a29d0b1b  nop [rax+rax*1], eax
00007f30a29d0b23  mov eax, 0x410728
00007f30a29d0b28  mov [r15+0x100], rax
00007f30a29d0b2f  jmp 0x00007F30A27FE110
00007f30a29d0b34  int3
00007f30a29d0b35  int3
00007f30a29d0b36  nop [rax+rax*1], ax
00007f30a29d0b3f  nop
00007f30a29d0b40  mov rax, [r15+0xF8]
00007f30a29d0b47  lea r14, [rax+0x168]
00007f30a29d0b4e  mov rax, [r13+r14*1]
00007f30a29d0b53  mov [r15+0x40], rax
00007f30a29d0b57  mov [rsp+0x10], rax
00007f30a29d0b5c  xor eax, eax
00007f30a29d0b5e  mov r14, [rsp+0x10]
00007f30a29d0b63  mov r12d, 0x38
00007f30a29d0b69  cmp r14, r12
00007f30a29d0b6c  cmc
00007f30a29d0b6d  lahf
00007f30a29d0b6e  seto al
00007f30a29d0b71  mov [r15+0x108], eax
00007f30a29d0b78  mov eax, [r15+0x108]
00007f30a29d0b7f  sahf
00007f30a29d0b80  jnz 0x00007F30A29D0BB2
00007f30a29d0b82  cmp dword ptr [r15+0x318], 0x00
00007f30a29d0b8a  jz 0x00007F30A29D0BF0
00007f30a29d0b90  nop [rax+rax*1], ax
00007f30a29d0b99  nop [rax+rax*1], eax
00007f30a29d0ba1  mov eax, 0x4102D4
00007f30a29d0ba6  mov [r15+0x100], rax
00007f30a29d0bad  jmp 0x00007F30A27FE110
00007f30a29d0bb2  cmp dword ptr [r15+0x318], 0x00
00007f30a29d0bba  jz 0x00007F30A29D0AA0
00007f30a29d0bc0  nop [rax+rax*1], ax
00007f30a29d0bc9  nop [rax+rax*1], eax
00007f30a29d0bd1  mov eax, 0x4102B8
00007f30a29d0bd6  mov [r15+0x100], rax
00007f30a29d0bdd  jmp 0x00007F30A27FE110
00007f30a29d0be2  int3
00007f30a29d0be3  call 0x00007F30A28D59C0
00007f30a29d0be8  jmp 0x00007F30A29D0B53
00007f30a29d0bed  int3
00007f30a29d0bee  nop
00007f30a29d0bf0  mov rax, [r15+0x98]
00007f30a29d0bf7  rorx r14, rax, 0x3D
00007f30a29d0bfd  and r14, 0xFFFFFFFFFFFFFFF8
00007f30a29d0c01  mov rax, [r15+0xF8]
00007f30a29d0c08  lea r12, [rax+0x100]
00007f30a29d0c0f  mov [r15], r12
00007f30a29d0c12  lea r12, [rax+0x170]
00007f30a29d0c19  mov [r15+0x08], r12
00007f30a29d0c1d  mov qword ptr [r15+0x10], 0x08
00007f30a29d0c25  bswap r14
00007f30a29d0c28  mov [r15+0x40], r14
00007f30a29d0c2c  lea r12, [rax+0x170]
00007f30a29d0c33  mov [r13+r12*1], r14
00007f30a29d0c38  mov qword ptr [r15+0xF0], 0x4102F0
00007f30a29d0c43  mov r14d, [r15+0x320]
00007f30a29d0c4a  mov eax, 0x4102F0
00007f30a29d0c4f  mov rcx, 0x7F30A29D0CC0
00007f30a29d0c59  mov [r15+r14*8+0x328], rax
00007f30a29d0c61  mov [r15+r14*8+0x368], rcx
00007f30a29d0c69  add r14d, 0x01
00007f30a29d0c6d  and r14d, 0x07
00007f30a29d0c71  mov [r15+0x320], r14d
00007f30a29d0c78  cmp dword ptr [r15+0x318], 0x00
00007f30a29d0c80  jz 0x00007F30A29CED70
00007f30a29d0c86  nop [rax+rax*1], ax
00007f30a29d0c8f  nop [rax+rax*1], eax
00007f30a29d0c97  mov eax, 0x410728
00007f30a29d0c9c  mov [r15+0x100], rax
00007f30a29d0ca3  jmp 0x00007F30A27FE110
00007f30a29d0ca8  int3
00007f30a29d0ca9  call 0x00007F30A28C3FE0
00007f30a29d0cae  jmp 0x00007F30A29D0C38
00007f30a29d0cb3  int3
00007f30a29d0cb4  nop [rax+rax*1], ax
00007f30a29d0cbd  nop [rax], eax
00007f30a29d0cc0  mov rax, [r15+0xF8]
00007f30a29d0cc7  lea r14, [rax+0x100]
00007f30a29d0cce  mov r12d, [r13+r14*1]
00007f30a29d0cd3  lea r14, [rax+0x104]
00007f30a29d0cda  mov r11d, [r13+r14*1]
00007f30a29d0cdf  mov qword ptr [r15+0x48], 0x430C90
00007f30a29d0ce7  lea r14, [rax+0x108]
00007f30a29d0cee  mov r10d, [r13+r14*1]
00007f30a29d0cf3  lea r14, [rax+0x10C]
00007f30a29d0cfa  mov r9d, [r13+r14*1]
00007f30a29d0cff  bswap r12d
00007f30a29d0d02  bswap r11d
00007f30a29d0d05  mov qword ptr [r15+0xA0], 0x00
00007f30a29d0d10  mov r14d, 0x430C90
00007f30a29d0d16  mov [r13+r14*1], r12d
00007f30a29d0d1b  mov r14d, 0x430C94
00007f30a29d0d21  mov [r13+r14*1], r11d
00007f30a29d0d26  bswap r10d
00007f30a29d0d29  lea r14, [rax+0x110]
00007f30a29d0d30  mov r12d, [r13+r14*1]
00007f30a29d0d35  bswap r9d
00007f30a29d0d38  lea r14, [rax+0x114]
00007f30a29d0d3f  mov r11d, [r13+r14*1]
00007f30a29d0d44  mov qword ptr [r15+0x98], 0x430DFC
00007f30a29d0d4f  mov r14d, 0x430C98
00007f30a29d0d55  mov [r13+r14*1], r10d
00007f30a29d0d5a  mov r14d, 0x430C9C
00007f30a29d0d60  mov [r13+r14*1], r9d
00007f30a29d0d65  bswap r12d
00007f30a29d0d68  lea r14, [rax+0x118]
00007f30a29d0d6f  mov r10d, [r13+r14*1]
00007f30a29d0d74  bswap r11d
00007f30a29d0d77  mov [rsp+0x10], r11d
00007f30a29d0d7c  mov r11d, r11d
00007f30a29d0d7f  mov [r15+0x58], r11
00007f30a29d0d83  lea r14, [rax+0x11C]
00007f30a29d0d8a  mov eax, [r13+r14*1]
00007f30a29d0d8f  mov [rsp+0x20], eax
00007f30a29d0d93  mov eax, eax
00007f30a29d0d95  mov [r15+0x60], rax
00007f30a29d0d99  mov eax, 0x430CA0
00007f30a29d0d9e  mov [r13+rax*1], r12d
00007f30a29d0da3  mov eax, 0x430CA4
00007f30a29d0da8  mov r14d, [rsp+0x10]
00007f30a29d0dad  mov [r13+rax*1], r14d
00007f30a29d0db2  bswap r10d
00007f30a29d0db5  mov [rsp+0x10], r10d
00007f30a29d0dba  mov r10d, r10d
00007f30a29d0dbd  mov [r15+0x40], r10
00007f30a29d0dc1  mov eax, [rsp+0x20]
00007f30a29d0dc5  bswap eax
00007f30a29d0dc7  mov [rsp+0x20], eax
00007f30a29d0dcb  mov eax, eax
00007f30a29d0dcd  mov [r15+0x50], rax
00007f30a29d0dd1  mov eax, 0x430CA8
00007f30a29d0dd6  mov r14d, [rsp+0x10]
00007f30a29d0ddb  mov [r13+rax*1], r14d
00007f30a29d0de0  mov eax, 0x430CAC
00007f30a29d0de5  mov r14d, [rsp+0x20]
00007f30a29d0dea  mov [r13+rax*1], r14d
00007f30a29d0def  mov eax, [r15+0xA0]
00007f30a29d0df6  lea r14d, [eax+0x11]
00007f30a29d0dfb  mov r14d, r14d
00007f30a29d0dfe  mov [r15], r14
00007f30a29d0e01  mov qword ptr [r15+0xF0], 0x41035C
00007f30a29d0e0c  mov r14d, [r15+0x320]
00007f30a29d0e13  mov eax, 0x41035C
00007f30a29d0e18  mov rcx, 0x7F30A29D0F90
00007f30a29d0e22  mov [r15+r14*8+0x328], rax
00007f30a29d0e2a  mov [r15+r14*8+0x368], rcx
00007f30a29d0e32  add r14d, 0x01
00007f30a29d0e36  and r14d, 0x07
00007f30a29d0e3a  mov [r15+0x320], r14d
00007f30a29d0e41  cmp dword ptr [r15+0x318], 0x00
00007f30a29d0e49  jz 0x00007F30A29D0F20
00007f30a29d0e4f  nop [rax+rax*1], ax
00007f30a29d0e58  nop [rax+rax*1], eax
00007f30a29d0e60  mov eax, 0x4109A4
00007f30a29d0e65  mov [r15+0x100], rax
00007f30a29d0e6c  jmp 0x00007F30A27FE110
00007f30a29d0e71  int3
00007f30a29d0e72  call 0x00007F30A28E26A0
00007f30a29d0e77  jmp 0x00007F30A29D0CD3
00007f30a29d0e7c  call 0x00007F30A28E1430
00007f30a29d0e81  jmp 0x00007F30A29D0CDF
00007f30a29d0e86  call 0x00007F30A28E01C0
00007f30a29d0e8b  jmp 0x00007F30A29D0CF3
00007f30a29d0e90  call 0x00007F30A28DEF50
00007f30a29d0e95  jmp 0x00007F30A29D0CFF
00007f30a29d0e9a  call 0x00007F30A28E2BA0
00007f30a29d0e9f  jmp 0x00007F30A29D0D1B
00007f30a29d0ea4  call 0x00007F30A28E1920
00007f30a29d0ea9  jmp 0x00007F30A29D0D26
00007f30a29d0eae  call 0x00007F30A28E26A0
00007f30a29d0eb3  jmp 0x00007F30A29D0D35
00007f30a29d0eb8  call 0x00007F30A28E1430
00007f30a29d0ebd  jmp 0x00007F30A29D0D44
00007f30a29d0ec2  call 0x00007F30A28E06B0
00007f30a29d0ec7  jmp 0x00007F30A29D0D5A
00007f30a29d0ecc  call 0x00007F30A28DF440
00007f30a29d0ed1  jmp 0x00007F30A29D0D65
00007f30a29d0ed6  call 0x00007F30A28E01C0
00007f30a29d0edb  jmp 0x00007F30A29D0D74
00007f30a29d0ee0  call 0x00007F30A28D5890
00007f30a29d0ee5  jmp 0x00007F30A29D0D8F
00007f30a29d0eea  call 0x00007F30A280BAE0
00007f30a29d0eef  jmp 0x00007F30A29D0DA3
00007f30a29d0ef4  call 0x00007F30A280DFE0
00007f30a29d0ef9  jmp 0x00007F30A29D0DB2
00007f30a29d0efe  call 0x00007F30A280DFE0
00007f30a29d0f03  jmp 0x00007F30A29D0DE0
00007f30a29d0f08  call 0x00007F30A280DFE0
00007f30a29d0f0d  jmp 0x00007F30A29D0DEF
00007f30a29d0f12  int3
00007f30a29d0f13  nop [rax+rax*1], ax
00007f30a29d0f1c  nop [rax], eax
00007f30a29d0f20  mov eax, [r15]
00007f30a29d0f23  mov [rsp+0x10], eax
00007f30a29d0f27  shr eax, 0x10
00007f30a29d0f2a  mov r14d, [rsp+0x10]
00007f30a29d0f2f  xor r14d, eax
00007f30a29d0f32  imul r14d, r14d, 0x7FEB352D
00007f30a29d0f39  mov eax, 0x846CA68B
00007f30a29d0f3e  mov eax, eax
00007f30a29d0f40  mov [r15+0x48], rax
00007f30a29d0f44  mov [rsp+0x10], r14d
00007f30a29d0f49  shr r14d, 0x0F
00007f30a29d0f4d  mov eax, [rsp+0x10]
00007f30a29d0f51  xor eax, r14d
00007f30a29d0f54  imul eax, eax, 0x846CA68B
00007f30a29d0f5a  mov [rsp+0x10], eax
00007f30a29d0f5e  mov eax, eax
00007f30a29d0f60  mov [r15+0x40], rax
00007f30a29d0f64  mov eax, [rsp+0x10]
00007f30a29d0f68  shr eax, 0x10
00007f30a29d0f6b  mov r14d, [rsp+0x10]
00007f30a29d0f70  xor r14d, eax
00007f30a29d0f73  mov r14d, r14d
00007f30a29d0f76  mov [r15], r14
00007f30a29d0f79  mov rax, [r15+0xF0]
00007f30a29d0f80  mov [r15+0x100], rax
00007f30a29d0f87  jmp 0x00007F30A29CE5C0
00007f30a29d0f8c  int3
00007f30a29d0f8d  int3
00007f30a29d0f8e  nop
00007f30a29d0f90  mov rax, [r15+0xA0]
00007f30a29d0f97  mov [rsp+0x10], rax
00007f30a29d0f9c  shl rax, 0x02
00007f30a29d0fa0  mov r14, [r15+0x98]
00007f30a29d0fa7  lea r12, [r14+rax*1]
00007f30a29d0fab  mov eax, [r15]
00007f30a29d0fae  mov [r13+r12*1], eax
00007f30a29d0fb3  mov rax, [rsp+0x10]
00007f30a29d0fb8  lea r14, [rax+0x01]
00007f30a29d0fbc  mov [r15+0xA0], r14
00007f30a29d0fc3  xor eax, eax
00007f30a29d0fc5  mov r12d, 0x400
00007f30a29d0fcb  cmp r14, r12
00007f30a29d0fce  cmc
00007f30a29d0fcf  lahf
00007f30a29d0fd0  seto al
00007f30a29d0fd3  mov [r15+0x108], eax
00007f30a29d0fda  mov eax, [r15+0x108]
00007f30a29d0fe1  sahf
00007f30a29d0fe2  jnz 0x00007F30A29D1014
00007f30a29d0fe4  cmp dword ptr [r15+0x318], 0x00
00007f30a29d0fec  jz 0x00007F30A29D10E0
00007f30a29d0ff2  nop [rax+rax*1], ax
00007f30a29d0ffb  nop [rax+rax*1], eax
00007f30a29d1003  mov eax, 0x41036C
00007f30a29d1008  mov [r15+0x100], rax
00007f30a29d100f  jmp 0x00007F30A27FE110
00007f30a29d1014  cmp dword ptr [r15+0x318], 0x00
00007f30a29d101c  jz 0x00007F30A29D1050
00007f30a29d1022  nop [rax+rax*1], ax
00007f30a29d102b  nop [rax+rax*1], eax
00007f30a29d1033  mov eax, 0x410354
00007f30a29d1038  mov [r15+0x100], rax
00007f30a29d103f  jmp 0x00007F30A27FE110
00007f30a29d1044  int3
00007f30a29d1045  call 0x00007F30A28B4B70
00007f30a29d104a  jmp 0x00007F30A29D0FB3
00007f30a29d104f  int3
00007f30a29d1050  mov eax, [r15+0xA0]
00007f30a29d1057  lea r14d, [eax+0x11]
00007f30a29d105c  mov r14d, r14d
00007f30a29d105f  mov [r15], r14
00007f30a29d1062  mov qword ptr [r15+0xF0], 0x41035C
00007f30a29d106d  mov r14d, [r15+0x320]
00007f30a29d1074  mov eax, 0x41035C
00007f30a29d1079  mov rcx, 0x7F30A29D0F90
00007f30a29d1083  mov [r15+r14*8+0x328], rax
00007f30a29d108b  mov [r15+r14*8+0x368], rcx
00007f30a29d1093  add r14d, 0x01
00007f30a29d1097  and r14d, 0x07
00007f30a29d109b  mov [r15+0x320], r14d
00007f30a29d10a2  cmp dword ptr [r15+0x318], 0x00
00007f30a29d10aa  jz 0x00007F30A29D0F20
00007f30a29d10b0  nop [rax+rax*1], ax
00007f30a29d10b9  nop [rax+rax*1], eax
00007f30a29d10c1  mov eax, 0x4109A4
00007f30a29d10c6  mov [r15+0x100], rax
00007f30a29d10cd  jmp 0x00007F30A27FE110
00007f30a29d10d2  int3
00007f30a29d10d3  int3
00007f30a29d10d4  nop [rax+rax*1], ax
00007f30a29d10dd  nop [rax], eax
00007f30a29d10e0  mov qword ptr [r15+0x40], 0x01
00007f30a29d10e8  cmp dword ptr [r15+0x318], 0x00
00007f30a29d10f0  jz 0x00007F30A29D1120
00007f30a29d10f6  nop [rax+rax*1], ax
00007f30a29d10ff  nop [rax+rax*1], eax
00007f30a29d1107  mov eax, 0x410388
00007f30a29d110c  mov [r15+0x100], rax
00007f30a29d1113  jmp 0x00007F30A27FE110
00007f30a29d1118  int3
00007f30a29d1119  int3
00007f30a29d111a  nop [rax+rax*1], ax
00007f30a29d1120  mov rax, [r15+0x40]
00007f30a29d1124  mov [rsp+0x10], rax
00007f30a29d1129  shl rax, 0x02
00007f30a29d112d  mov r14, [r15+0x98]
00007f30a29d1134  lea r12, [r14+rax*1]
00007f30a29d1138  mov eax, [r13+r12*1]
00007f30a29d113d  mov [rsp+0x20], eax
00007f30a29d1141  mov eax, eax
00007f30a29d1143  mov [r15+0x48], rax
00007f30a29d1147  mov rax, [rsp+0x10]
00007f30a29d114c  mov [r15+0x50], rax
00007f30a29d1150  mov eax, [r15+0x50]
00007f30a29d1154  lea r12d, [eax-0x01]
00007f30a29d1159  mov r12d, r12d
00007f30a29d115c  mov [r15+0x58], r12
00007f30a29d1160  mov rax, [r15+0x58]
00007f30a29d1164  mov r12d, eax
00007f30a29d1167  mov r12d, r12d
00007f30a29d116a  shl r12, 0x02
00007f30a29d116e  lea rax, [r14+r12*1]
00007f30a29d1172  mov r14d, [r13+rax*1]
00007f30a29d1177  mov [rsp+0x10], r14d
00007f30a29d117c  mov r14d, r14d
00007f30a29d117f  mov [r15+0x60], r14
00007f30a29d1183  xor eax, eax
00007f30a29d1185  mov r14d, [rsp+0x10]
00007f30a29d118a  mov r12d, [rsp+0x20]
00007f30a29d118f  cmp r14d, r12d
00007f30a29d1192  cmc
00007f30a29d1193  lahf
00007f30a29d1194  seto al
00007f30a29d1197  mov [r15+0x108], eax
00007f30a29d119e  mov eax, [r15+0x108]
00007f30a29d11a5  sahf
00007f30a29d11a6  cmc
00007f30a29d11a7  jbe 0x00007F30A29D11D9
00007f30a29d11a9  cmp dword ptr [r15+0x318], 0x00
00007f30a29d11b1  jz 0x00007F30A29D1220
00007f30a29d11b7  nop [rax+rax*1], ax
00007f30a29d11c0  nop [rax+rax*1], eax
00007f30a29d11c8  mov eax, 0x4103A0
00007f30a29d11cd  mov [r15+0x100], rax
00007f30a29d11d4  jmp 0x00007F30A27FE110
00007f30a29d11d9  cmp dword ptr [r15+0x318], 0x00
00007f30a29d11e1  jz 0x00007F30A29D14C0
00007f30a29d11e7  nop [rax+rax*1], ax
00007f30a29d11f0  nop [rax+rax*1], eax
00007f30a29d11f8  mov eax, 0x410378
00007f30a29d11fd  mov [r15+0x100], rax
00007f30a29d1204  jmp 0x00007F30A27FE110
00007f30a29d1209  int3
00007f30a29d120a  call 0x00007F30A28B4690
00007f30a29d120f  jmp 0x00007F30A29D113D
00007f30a29d1214  call 0x00007F30A280DAE0
00007f30a29d1219  jmp 0x00007F30A29D1177
00007f30a29d121e  int3
00007f30a29d121f  nop
00007f30a29d1220  mov rax, [r15+0x50]
00007f30a29d1224  mov [rsp+0x10], rax
00007f30a29d1229  shl rax, 0x02
00007f30a29d122d  mov r14, [r15+0x98]
00007f30a29d1234  lea r12, [r14+rax*1]
00007f30a29d1238  mov eax, [r15+0x60]
00007f30a29d123c  mov [r13+r12*1], eax
00007f30a29d1241  mov rax, [rsp+0x10]
00007f30a29d1246  lea r14, [rax-0x01]
00007f30a29d124a  mov [r15+0x50], r14
00007f30a29d124e  mov rax, [r15+0x58]
00007f30a29d1252  test rax, rax
00007f30a29d1255  setz al
00007f30a29d1258  movzx rax, al
00007f30a29d125c  mov [rsp+0x414], al
00007f30a29d1263  cmp byte ptr [rsp+0x414], 0x00
00007f30a29d126b  jz 0x00007F30A29D129D
00007f30a29d126d  cmp dword ptr [r15+0x318], 0x00
00007f30a29d1275  jz 0x00007F30A29D12E0
00007f30a29d127b  nop [rax+rax*1], ax
00007f30a29d1284  nop [rax+rax*1], eax
00007f30a29d128c  mov eax, 0x4103AC
00007f30a29d1291  mov [r15+0x100], rax
00007f30a29d1298  jmp 0x00007F30A27FE110
00007f30a29d129d  cmp dword ptr [r15+0x318], 0x00
00007f30a29d12a5  jz 0x00007F30A29D13E0
00007f30a29d12ab  nop [rax+rax*1], ax
00007f30a29d12b4  nop [rax+rax*1], eax
00007f30a29d12bc  mov eax, 0x410390
00007f30a29d12c1  mov [r15+0x100], rax
00007f30a29d12c8  jmp 0x00007F30A27FE110
00007f30a29d12cd  int3
00007f30a29d12ce  call 0x00007F30A28B4B70
00007f30a29d12d3  jmp 0x00007F30A29D1241
00007f30a29d12d8  int3
00007f30a29d12d9  nop [rax], eax
00007f30a29d12e0  cmp dword ptr [r15+0x318], 0x00
00007f30a29d12e8  jz 0x00007F30A29D1320
00007f30a29d12ee  nop [rax+rax*1], ax
00007f30a29d12f7  nop [rax+rax*1], eax
00007f30a29d12ff  mov eax, 0x410374
00007f30a29d1304  mov [r15+0x100], rax
00007f30a29d130b  jmp 0x00007F30A27FE110
00007f30a29d1310  int3
00007f30a29d1311  int3
00007f30a29d1312  nop [rax+rax*1], ax
00007f30a29d131b  nop [rax+rax*1], eax
00007f30a29d1320  mov qword ptr [r15+0x50], 0x00
00007f30a29d1328  mov rax, [r15+0x40]
00007f30a29d132c  lea r14, [rax+0x01]
00007f30a29d1330  mov [r15+0x40], r14
00007f30a29d1334  mov rax, [r15+0x98]
00007f30a29d133b  mov r12d, [r15+0x48]
00007f30a29d133f  mov [r13+rax*1], r12d
00007f30a29d1344  xor eax, eax
00007f30a29d1346  mov r12d, 0x400
00007f30a29d134c  cmp r14, r12
00007f30a29d134f  cmc
00007f30a29d1350  lahf
00007f30a29d1351  seto al
00007f30a29d1354  mov [r15+0x108], eax
00007f30a29d135b  mov eax, [r15+0x108]
00007f30a29d1362  sahf
00007f30a29d1363  jz 0x00007F30A29D1395
00007f30a29d1365  cmp dword ptr [r15+0x318], 0x00
00007f30a29d136d  jz 0x00007F30A29D1120
00007f30a29d1373  nop [rax+rax*1], ax
00007f30a29d137c  nop [rax+rax*1], eax
00007f30a29d1384  mov eax, 0x410388
00007f30a29d1389  mov [r15+0x100], rax
00007f30a29d1390  jmp 0x00007F30A27FE110
00007f30a29d1395  cmp dword ptr [r15+0x318], 0x00
00007f30a29d139d  jz 0x00007F30A29D1580
00007f30a29d13a3  nop [rax+rax*1], ax
00007f30a29d13ac  nop [rax+rax*1], eax
00007f30a29d13b4  mov eax, 0x4103B0
00007f30a29d13b9  mov [r15+0x100], rax
00007f30a29d13c0  jmp 0x00007F30A27FE110
00007f30a29d13c5  int3
00007f30a29d13c6  call 0x00007F30A280BAE0
00007f30a29d13cb  jmp 0x00007F30A29D1344
00007f30a29d13d0  int3
00007f30a29d13d1  nop [rax+rax*1], ax
00007f30a29d13da  nop [rax+rax*1], ax
00007f30a29d13e0  mov eax, [r15+0x50]
00007f30a29d13e4  lea r14d, [eax-0x01]
00007f30a29d13e9  mov r14d, r14d
00007f30a29d13ec  mov [r15+0x58], r14
00007f30a29d13f0  mov rax, [r15+0x58]
00007f30a29d13f4  mov r14d, eax
00007f30a29d13f7  mov r14d, r14d
00007f30a29d13fa  shl r14, 0x02
00007f30a29d13fe  mov rax, [r15+0x98]
00007f30a29d1405  lea r12, [rax+r14*1]
00007f30a29d1409  mov eax, [r13+r12*1]
00007f30a29d140e  mov [rsp+0x10], eax
00007f30a29d1412  mov eax, eax
00007f30a29d1414  mov [r15+0x60], rax
00007f30a29d1418  mov eax, [r15+0x48]
00007f30a29d141c  mov [rsp+0x20], eax
00007f30a29d1420  xor eax, eax
00007f30a29d1422  mov r14d, [rsp+0x10]
00007f30a29d1427  mov r12d, [rsp+0x20]
00007f30a29d142c  cmp r14d, r12d
00007f30a29d142f  cmc
00007f30a29d1430  lahf
00007f30a29d1431  seto al
00007f30a29d1434  mov [r15+0x108], eax
00007f30a29d143b  mov eax, [r15+0x108]
00007f30a29d1442  sahf
00007f30a29d1443  cmc
00007f30a29d1444  jbe 0x00007F30A29D1476
00007f30a29d1446  cmp dword ptr [r15+0x318], 0x00
00007f30a29d144e  jz 0x00007F30A29D1220
00007f30a29d1454  nop [rax+rax*1], ax
00007f30a29d145d  nop [rax+rax*1], eax
00007f30a29d1465  mov eax, 0x4103A0
00007f30a29d146a  mov [r15+0x100], rax
00007f30a29d1471  jmp 0x00007F30A27FE110
00007f30a29d1476  cmp dword ptr [r15+0x318], 0x00
00007f30a29d147e  jz 0x00007F30A29D14C0
00007f30a29d1484  nop [rax+rax*1], ax
00007f30a29d148d  nop [rax+rax*1], eax
00007f30a29d1495  mov eax, 0x410378
00007f30a29d149a  mov [r15+0x100], rax
00007f30a29d14a1  jmp 0x00007F30A27FE110
00007f30a29d14a6  int3
00007f30a29d14a7  call 0x00007F30A28B4690
00007f30a29d14ac  jmp 0x00007F30A29D140E
00007f30a29d14b1  int3
00007f30a29d14b2  nop [rax+rax*1], ax
00007f30a29d14bb  nop [rax+rax*1], eax
00007f30a29d14c0  mov rax, [r15+0x40]
00007f30a29d14c4  lea r14, [rax+0x01]
00007f30a29d14c8  mov [r15+0x40], r14
00007f30a29d14cc  mov rax, [r15+0x50]
00007f30a29d14d0  mov r12d, eax
00007f30a29d14d3  mov r12d, r12d
00007f30a29d14d6  shl r12, 0x02
00007f30a29d14da  mov rax, [r15+0x98]
00007f30a29d14e1  lea r11, [rax+r12*1]
00007f30a29d14e5  mov eax, [r15+0x48]
00007f30a29d14e9  mov [r13+r11*1], eax
00007f30a29d14ee  xor eax, eax
00007f30a29d14f0  mov r12d, 0x400
00007f30a29d14f6  cmp r14, r12
00007f30a29d14f9  cmc
00007f30a29d14fa  lahf
00007f30a29d14fb  seto al
00007f30a29d14fe  mov [r15+0x108], eax
00007f30a29d1505  mov eax, [r15+0x108]
00007f30a29d150c  sahf
00007f30a29d150d  jz 0x00007F30A29D153F
00007f30a29d150f  cmp dword ptr [r15+0x318], 0x00
00007f30a29d1517  jz 0x00007F30A29D1120
00007f30a29d151d  nop [rax+rax*1], ax
00007f30a29d1526  nop [rax+rax*1], eax
00007f30a29d152e  mov eax, 0x410388
00007f30a29d1533  mov [r15+0x100], rax
00007f30a29d153a  jmp 0x00007F30A27FE110
00007f30a29d153f  cmp dword ptr [r15+0x318], 0x00
00007f30a29d1547  jz 0x00007F30A29D1580
00007f30a29d154d  nop [rax+rax*1], ax
00007f30a29d1556  nop [rax+rax*1], eax
00007f30a29d155e  mov eax, 0x4103B0
00007f30a29d1563  mov [r15+0x100], rax
00007f30a29d156a  jmp 0x00007F30A27FE110
00007f30a29d156f  int3
00007f30a29d1570  call 0x00007F30A28A4270
00007f30a29d1575  jmp 0x00007F30A29D14EE
00007f30a29d157a  int3
00007f30a29d157b  nop [rax+rax*1], eax
00007f30a29d1580  mov qword ptr [r15+0x40], 0x430000
00007f30a29d1588  mov eax, 0x430CB0
00007f30a29d158d  mov r14, [r13+rax*1]
00007f30a29d1592  mov rax, [r15+0x98]
00007f30a29d1599  mov r12d, [r13+rax*1]
00007f30a29d159e  lea r11, [rax+0x04]
00007f30a29d15a2  mov eax, [r13+r11*1]
00007f30a29d15a7  mov r12d, r12d
00007f30a29d15aa  mov [r15+0x68], r12
00007f30a29d15ae  mov eax, eax
00007f30a29d15b0  mov [r15+0x60], rax
00007f30a29d15b4  mov rax, [r15+0x68]
00007f30a29d15b8  mov [r15+0x68], rax
00007f30a29d15bc  mov qword ptr [r15+0x58], 0x02
00007f30a29d15c4  mov [rsp+0x10], rax
00007f30a29d15c9  xor eax, eax
00007f30a29d15cb  mov r12d, 0x02
00007f30a29d15d1  mov r11d, 0x400
00007f30a29d15d7  cmp r12, r11
00007f30a29d15da  cmc
00007f30a29d15db  lahf
00007f30a29d15dc  seto al
00007f30a29d15df  mov [r15+0x108], eax
00007f30a29d15e6  mov rax, [r15+0x60]
00007f30a29d15ea  mov r12d, 0x02
00007f30a29d15f0  imul rax, r12
00007f30a29d15f4  mov [r15+0x50], rax
00007f30a29d15f8  mov rax, [rsp+0x10]
00007f30a29d15fd  lea r12, [rax+r14*1]
00007f30a29d1601  mov [r15+0x48], r12
00007f30a29d1605  mov eax, [r15+0x108]
00007f30a29d160c  sahf
00007f30a29d160d  jnz 0x00007F30A29D163F
00007f30a29d160f  cmp dword ptr [r15+0x318], 0x00
00007f30a29d1617  jz 0x00007F30A29D17B0
00007f30a29d161d  nop [rax+rax*1], ax
00007f30a29d1626  nop [rax+rax*1], eax
00007f30a29d162e  mov eax, 0x4103E0
00007f30a29d1633  mov [r15+0x100], rax
00007f30a29d163a  jmp 0x00007F30A27FE110
00007f30a29d163f  cmp dword ptr [r15+0x318], 0x00
00007f30a29d1647  jz 0x00007F30A29D1690
00007f30a29d164d  nop [rax+rax*1], ax
00007f30a29d1656  nop [rax+rax*1], eax
00007f30a29d165e  mov eax, 0x4103C0
00007f30a29d1663  mov [r15+0x100], rax
00007f30a29d166a  jmp 0x00007F30A27FE110
00007f30a29d166f  int3
00007f30a29d1670  call 0x00007F30A280DC20
00007f30a29d1675  jmp 0x00007F30A29D1592
00007f30a29d167a  call 0x00007F30A280B5E0
00007f30a29d167f  jmp 0x00007F30A29D159E
00007f30a29d1684  call 0x00007F30A28A3D90
00007f30a29d1689  jmp 0x00007F30A29D15A7
00007f30a29d168e  int3
00007f30a29d168f  nop
00007f30a29d1690  mov rax, [r15+0x98]
00007f30a29d1697  mov r14, [r15+0x58]
00007f30a29d169b  mov [rsp+0x10], r14
00007f30a29d16a0  shl r14, 0x02
00007f30a29d16a4  lea r12, [rax+r14*1]
00007f30a29d16a8  mov eax, [r13+r12*1]
00007f30a29d16ad  lea r14, [r12+0x04]
00007f30a29d16b2  mov r12d, [r13+r14*1]
00007f30a29d16b7  mov eax, eax
00007f30a29d16b9  mov [r15+0x68], rax
00007f30a29d16bd  mov r12d, r12d
00007f30a29d16c0  mov [r15+0x60], r12
00007f30a29d16c4  mov rax, [r15+0x68]
00007f30a29d16c8  mov [rsp+0x20], rax
00007f30a29d16cd  mov r14, [rsp+0x10]
00007f30a29d16d2  imul rax, r14
00007f30a29d16d6  mov r12, [rsp+0x20]
00007f30a29d16db  lea r11, [r12+rax*1]
00007f30a29d16df  mov [r15+0x68], r11
00007f30a29d16e3  lea rax, [r14+0x02]
00007f30a29d16e7  mov [r15+0x58], rax
00007f30a29d16eb  mov [rsp+0x10], rax
00007f30a29d16f0  xor eax, eax
00007f30a29d16f2  mov r14, [rsp+0x10]
00007f30a29d16f7  mov r12d, 0x400
00007f30a29d16fd  cmp r14, r12
00007f30a29d1700  cmc
00007f30a29d1701  lahf
00007f30a29d1702  seto al
00007f30a29d1705  mov [r15+0x108], eax
00007f30a29d170c  mov rax, [r15+0x50]
00007f30a29d1710  mov r12, [r15+0x60]
00007f30a29d1714  imul r14, r12
00007f30a29d1718  lea r12, [rax+r14*1]
00007f30a29d171c  mov [r15+0x50], r12
00007f30a29d1720  mov rax, [r15+0x48]
00007f30a29d1724  lea r14, [r11+rax*1]
00007f30a29d1728  mov [r15+0x48], r14
00007f30a29d172c  mov eax, [r15+0x108]
00007f30a29d1733  sahf
00007f30a29d1734  jnz 0x00007F30A29D1766
00007f30a29d1736  cmp dword ptr [r15+0x318], 0x00
00007f30a29d173e  jz 0x00007F30A29D17B0
00007f30a29d1744  nop [rax+rax*1], ax
00007f30a29d174d  nop [rax+rax*1], eax
00007f30a29d1755  mov eax, 0x4103E0
00007f30a29d175a  mov [r15+0x100], rax
00007f30a29d1761  jmp 0x00007F30A27FE110
00007f30a29d1766  cmp dword ptr [r15+0x318], 0x00
00007f30a29d176e  jz 0x00007F30A29D1690
00007f30a29d1774  nop [rax+rax*1], ax
00007f30a29d177d  nop [rax+rax*1], eax
00007f30a29d1785  mov eax, 0x4103C0
00007f30a29d178a  mov [r15+0x100], rax
00007f30a29d1791  jmp 0x00007F30A27FE110
00007f30a29d1796  int3
00007f30a29d1797  call 0x00007F30A28B4690
00007f30a29d179c  jmp 0x00007F30A29D16AD
00007f30a29d17a1  call 0x00007F30A28E26A0
00007f30a29d17a6  jmp 0x00007F30A29D16B7
00007f30a29d17ab  int3
00007f30a29d17ac  nop [rax], eax
00007f30a29d17b0  mov qword ptr [r15+0x98], 0x00
00007f30a29d17bb  mov rax, [r15+0x50]
00007f30a29d17bf  mov r14, [r15+0x48]
00007f30a29d17c3  lea r12, [rax+r14*1]
00007f30a29d17c7  mov [r15+0x48], r12
00007f30a29d17cb  mov rax, [r15+0x40]
00007f30a29d17cf  lea r14, [rax+0xCB0]
00007f30a29d17d6  mov [r13+r14*1], r12
00007f30a29d17db  mov qword ptr [r15], 0x01
00007f30a29d17e2  mov qword ptr [r15+0xF0], 0x4103F8
00007f30a29d17ed  mov r14d, [r15+0x320]
00007f30a29d17f4  mov eax, 0x4103F8
00007f30a29d17f9  mov rcx, 0x7F30A29D1860
00007f30a29d1803  mov [r15+r14*8+0x328], rax
00007f30a29d180b  mov [r15+r14*8+0x368], rcx
00007f30a29d1813  add r14d, 0x01
00007f30a29d1817  and r14d, 0x07
00007f30a29d181b  mov [r15+0x320], r14d
00007f30a29d1822  cmp dword ptr [r15+0x318], 0x00
00007f30a29d182a  jz 0x00007F30A29D0F20
00007f30a29d1830  nop [rax+rax*1], ax
00007f30a29d1839  nop [rax+rax*1], eax
00007f30a29d1841  mov eax, 0x4109A4
00007f30a29d1846  mov [r15+0x100], rax
00007f30a29d184d  jmp 0x00007F30A27FE110
00007f30a29d1852  int3
00007f30a29d1853  call 0x00007F30A28E2CE0
00007f30a29d1858  jmp 0x00007F30A29D17DB
00007f30a29d185d  int3
00007f30a29d185e  nop
00007f30a29d1860  mov eax, [r15+0x98]
00007f30a29d1867  lea r14d, [eax+0x01]
00007f30a29d186c  mov [rsp+0x10], r14d
00007f30a29d1871  mov r14d, r14d
00007f30a29d1874  mov [r15+0x98], r14
00007f30a29d187b  xor eax, eax
00007f30a29d187d  mov r14d, [rsp+0x10]
00007f30a29d1882  cmp r14d, 0x10000
00007f30a29d1889  cmc
00007f30a29d188a  lahf
00007f30a29d188b  seto al
00007f30a29d188e  mov [r15+0x108], eax
00007f30a29d1895  mov eax, [r15+0x108]
00007f30a29d189c  sahf
00007f30a29d189d  jnz 0x00007F30A29D18CF
00007f30a29d189f  cmp dword ptr [r15+0x318], 0x00
00007f30a29d18a7  jz 0x00007F30A29D19A0
00007f30a29d18ad  nop [rax+rax*1], ax
00007f30a29d18b6  nop [rax+rax*1], eax
00007f30a29d18be  mov eax, 0x410404
00007f30a29d18c3  mov [r15+0x100], rax
00007f30a29d18ca  jmp 0x00007F30A27FE110
00007f30a29d18cf  cmp dword ptr [r15+0x318], 0x00
00007f30a29d18d7  jz 0x00007F30A29D1910
00007f30a29d18dd  nop [rax+rax*1], ax
00007f30a29d18e6  nop [rax+rax*1], eax
00007f30a29d18ee  mov eax, 0x4103F0
00007f30a29d18f3  mov [r15+0x100], rax
00007f30a29d18fa  jmp 0x00007F30A27FE110
00007f30a29d18ff  int3
00007f30a29d1900  int3
00007f30a29d1901  nop [rax+rax*1], ax
00007f30a29d190a  nop [rax+rax*1], ax
00007f30a29d1910  mov eax, [r15]
00007f30a29d1913  mov r14d, [r15+0x98]
00007f30a29d191a  lea r12d, [eax+r14d*1]
00007f30a29d191f  mov r12d, r12d
00007f30a29d1922  mov [r15], r12
00007f30a29d1925  mov qword ptr [r15+0xF0], 0x4103F8
00007f30a29d1930  mov r14d, [r15+0x320]
00007f30a29d1937  mov eax, 0x4103F8
00007f30a29d193c  mov rcx, 0x7F30A29D1860
00007f30a29d1946  mov [r15+r14*8+0x328], rax
00007f30a29d194e  mov [r15+r14*8+0x368], rcx
00007f30a29d1956  add r14d, 0x01
00007f30a29d195a  and r14d, 0x07
00007f30a29d195e  mov [r15+0x320], r14d
00007f30a29d1965  cmp dword ptr [r15+0x318], 0x00
00007f30a29d196d  jz 0x00007F30A29D0F20
00007f30a29d1973  nop [rax+rax*1], ax
00007f30a29d197c  nop [rax+rax*1], eax
00007f30a29d1984  mov eax, 0x4109A4
00007f30a29d1989  mov [r15+0x100], rax
00007f30a29d1990  jmp 0x00007F30A27FE110
00007f30a29d1995  int3
00007f30a29d1996  int3
00007f30a29d1997  nop [rax+rax*1], ax
00007f30a29d19a0  vmovaps xmm1, [0x00007F30A25FE010]
00007f30a29d19a8  movq xmm1, xmm1
00007f30a29d19ac  movaps [r15+0x110], xmm1
00007f30a29d19b4  mov eax, 0x420B10
00007f30a29d19b9  mov r14, [r13+rax*1]
00007f30a29d19be  movq xmm1, r14
00007f30a29d19c3  movaps [r15+0x120], xmm1
00007f30a29d19cb  vmovaps xmm1, [0x00007F30A25FE020]
00007f30a29d19d3  movq xmm1, xmm1
00007f30a29d19d7  movaps [r15+0x140], xmm1
00007f30a29d19df  vmovaps xmm1, [0x00007F30A25FE030]
00007f30a29d19e7  vpbroadcastq xmm1, xmm1
00007f30a29d19ec  movaps [r15+0x150], xmm1
00007f30a29d19f4  mov qword ptr [r15+0x40], 0x02
00007f30a29d19fc  vmovaps xmm15, [0x00007F30A25FE040]
00007f30a29d1a04  movq xmm15, xmm15
00007f30a29d1a09  movaps [r15+0x160], xmm15
00007f30a29d1a11  vmovaps xmm15, [0x00007F30A25FE050]
00007f30a29d1a19  vpbroadcastq xmm15, xmm15
00007f30a29d1a1e  movaps [r15+0x130], xmm15
00007f30a29d1a26  mov rax, [r15+0x40]
00007f30a29d1a2a  vmovq xmm14, rax
00007f30a29d1a2f  vpbroadcastq xmm14, xmm14
00007f30a29d1a34  movaps [r15+0x170], xmm14
00007f30a29d1a3c  mov eax, 0x420A40
00007f30a29d1a41  movups xmm13, [r13+rax*1]
00007f30a29d1a47  mov qword ptr [r15+0x40], 0x431E00
00007f30a29d1a4f  mov eax, [r15]
00007f30a29d1a52  mov r14d, 0x430CB8
00007f30a29d1a58  mov [r13+r14*1], eax
00007f30a29d1a5d  mov qword ptr [r15+0x50], 0x432000
00007f30a29d1a65  vpmovqd xmm12, xmm13
00007f30a29d1a6b  pxor xmm11, xmm11
00007f30a29d1a70  punpcklqdq xmm12, xmm11
00007f30a29d1a75  movaps [r15+0x210], xmm12
00007f30a29d1a7d  movq xmm12, qword ptr [r15+0x140]
00007f30a29d1a86  movq xmm11, qword ptr [r15+0x120]
00007f30a29d1a8f  psubd xmm12, xmm11
00007f30a29d1a94  movq xmm12, xmm12
00007f30a29d1a99  paddq xmm13, xmm14
00007f30a29d1a9e  movaps [r15+0x180], xmm13
00007f30a29d1aa6  movq xmm14, qword ptr [r15+0x160]
00007f30a29d1aaf  paddd xmm11, xmm14
00007f30a29d1ab4  movq xmm11, xmm11
00007f30a29d1ab9  movq xmm11, xmm11
00007f30a29d1abe  movaps [r15+0x120], xmm11
00007f30a29d1ac6  pmovzxdq xmm12, xmm12
00007f30a29d1acc  psllq xmm12, 0x00
00007f30a29d1ad2  movq xmm14, qword ptr [r15+0x210]
00007f30a29d1adb  movq xmm13, qword ptr [r15+0x110]
00007f30a29d1ae4  paddd xmm14, xmm13
00007f30a29d1ae9  movq xmm14, xmm14
00007f30a29d1aee  vcvtuqq2pd xmm12, xmm12
00007f30a29d1af4  pmovzxdq xmm14, xmm14
00007f30a29d1afa  psllq xmm14, 0x00
00007f30a29d1b00  vcvtuqq2pd xmm14, xmm14
00007f30a29d1b06  movaps xmm13, xmm12
00007f30a29d1b0a  mulpd xmm13, xmm1
00007f30a29d1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
00007f30a29d1b15  ptest xmm11, xmm11
00007f30a29d1b1b  jnz 0x00007F30A29D1C0F
00007f30a29d1b21  movaps [r15+0x220], xmm13
00007f30a29d1b29  mov eax, 0x432000
00007f30a29d1b2e  movups [r13+rax*1], xmm13
00007f30a29d1b34  movaps xmm1, xmm14
00007f30a29d1b38  mulpd xmm1, xmm15
00007f30a29d1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
00007f30a29d1b42  ptest xmm13, xmm13
00007f30a29d1b48  jnz 0x00007F30A29D1D5C
00007f30a29d1b4e  movaps [r15+0x210], xmm1
00007f30a29d1b56  mov eax, 0x431E00
00007f30a29d1b5b  movups [r13+rax*1], xmm1
00007f30a29d1b61  mov qword ptr [r15+0x48], 0x10
00007f30a29d1b69  xor eax, eax
00007f30a29d1b6b  mov r14d, 0x10
00007f30a29d1b71  mov r12d, 0x200
00007f30a29d1b77  cmp r14, r12
00007f30a29d1b7a  cmc
00007f30a29d1b7b  lahf
00007f30a29d1b7c  seto al
00007f30a29d1b7f  mov [r15+0x108], eax
00007f30a29d1b86  mov eax, [r15+0x108]
00007f30a29d1b8d  sahf
00007f30a29d1b8e  jnz 0x00007F30A29D1BC0
00007f30a29d1b90  cmp dword ptr [r15+0x318], 0x00
00007f30a29d1b98  jz 0x00007F30A29D2300
00007f30a29d1b9e  nop [rax+rax*1], ax
00007f30a29d1ba7  nop [rax+rax*1], eax
00007f30a29d1baf  mov eax, 0x410490
00007f30a29d1bb4  mov [r15+0x100], rax
00007f30a29d1bbb  jmp 0x00007F30A27FE110
00007f30a29d1bc0  cmp dword ptr [r15+0x318], 0x00
00007f30a29d1bc8  jz 0x00007F30A29D1EB0
00007f30a29d1bce  nop [rax+rax*1], ax
00007f30a29d1bd7  nop [rax+rax*1], eax
00007f30a29d1bdf  mov eax, 0x410450
00007f30a29d1be4  mov [r15+0x100], rax
00007f30a29d1beb  jmp 0x00007F30A27FE110
00007f30a29d1bf0  int3
00007f30a29d1bf1  call 0x00007F30A280DC20
00007f30a29d1bf6  jmp 0x00007F30A29D19BE
00007f30a29d1bfb  call 0x00007F30A280C260
00007f30a29d1c00  jmp 0x00007F30A29D1A47
00007f30a29d1c05  call 0x00007F30A28D5D70
00007f30a29d1c0a  jmp 0x00007F30A29D1A5D
00007f30a29d1c0f  sub rsp, 0x08
00007f30a29d1c13  push rax
00007f30a29d1c14  push rcx
00007f30a29d1c15  push rdx
00007f30a29d1c16  push rdi
00007f30a29d1c17  push rsi
00007f30a29d1c18  push r8
00007f30a29d1c1a  push r9
00007f30a29d1c1c  push r10
00007f30a29d1c1e  push r11
00007f30a29d1c20  sub rsp, 0xF0
00007f30a29d1c27  vmovaps [rsp], xmm0
00007f30a29d1c2c  vmovaps [rsp+0x10], xmm1
00007f30a29d1c32  vmovaps [rsp+0x20], xmm2
00007f30a29d1c38  vmovaps [rsp+0x30], xmm3
00007f30a29d1c3e  vmovaps [rsp+0x40], xmm4
00007f30a29d1c44  vmovaps [rsp+0x50], xmm5
00007f30a29d1c4a  vmovaps [rsp+0x60], xmm6
00007f30a29d1c50  vmovaps [rsp+0x70], xmm7
00007f30a29d1c56  vmovaps [rsp+0x80], xmm8
00007f30a29d1c5f  vmovaps [rsp+0x90], xmm9
00007f30a29d1c68  vmovaps [rsp+0xA0], xmm10
00007f30a29d1c71  vmovaps [rsp+0xB0], xmm11
00007f30a29d1c7a  vmovaps [rsp+0xC0], xmm12
00007f30a29d1c83  vmovaps [rsp+0xD0], xmm14
00007f30a29d1c8c  vmovaps [rsp+0xE0], xmm15
00007f30a29d1c95  sub rsp, 0x30
00007f30a29d1c99  movaps [rsp], xmm13
00007f30a29d1c9e  movaps [rsp+0x10], xmm12
00007f30a29d1ca4  movaps [rsp+0x20], xmm1
00007f30a29d1ca9  lea rdi, [rsp]
00007f30a29d1cad  mov esi, 0x00
00007f30a29d1cb2  mov rax, 0x5FE955026530
00007f30a29d1cbc  call rax
00007f30a29d1cbe  movaps xmm13, [rsp]
00007f30a29d1cc3  add rsp, 0x30
00007f30a29d1cc7  vmovaps xmm0, [rsp]
00007f30a29d1ccc  vmovaps xmm1, [rsp+0x10]
00007f30a29d1cd2  vmovaps xmm2, [rsp+0x20]
00007f30a29d1cd8  vmovaps xmm3, [rsp+0x30]
00007f30a29d1cde  vmovaps xmm4, [rsp+0x40]
00007f30a29d1ce4  vmovaps xmm5, [rsp+0x50]
00007f30a29d1cea  vmovaps xmm6, [rsp+0x60]
00007f30a29d1cf0  vmovaps xmm7, [rsp+0x70]
00007f30a29d1cf6  vmovaps xmm8, [rsp+0x80]
00007f30a29d1cff  vmovaps xmm9, [rsp+0x90]
00007f30a29d1d08  vmovaps xmm10, [rsp+0xA0]
00007f30a29d1d11  vmovaps xmm11, [rsp+0xB0]
00007f30a29d1d1a  vmovaps xmm12, [rsp+0xC0]
00007f30a29d1d23  vmovaps xmm14, [rsp+0xD0]
00007f30a29d1d2c  vmovaps xmm15, [rsp+0xE0]
00007f30a29d1d35  add rsp, 0xF0
00007f30a29d1d3c  pop r11
00007f30a29d1d3e  pop r10
00007f30a29d1d40  pop r9
00007f30a29d1d42  pop r8
00007f30a29d1d44  pop rsi
00007f30a29d1d45  pop rdi
00007f30a29d1d46  pop rdx
00007f30a29d1d47  pop rcx
00007f30a29d1d48  pop rax
00007f30a29d1d49  add rsp, 0x08
00007f30a29d1d4d  jmp 0x00007F30A29D1B21
00007f30a29d1d52  call 0x00007F30A280C380
00007f30a29d1d57  jmp 0x00007F30A29D1B34
00007f30a29d1d5c  sub rsp, 0x08
00007f30a29d1d60  push rax
00007f30a29d1d61  push rcx
00007f30a29d1d62  push rdx
00007f30a29d1d63  push rdi
00007f30a29d1d64  push rsi
00007f30a29d1d65  push r8
00007f30a29d1d67  push r9
00007f30a29d1d69  push r10
00007f30a29d1d6b  push r11
00007f30a29d1d6d  sub rsp, 0xF0
00007f30a29d1d74  vmovaps [rsp], xmm0
00007f30a29d1d79  vmovaps [rsp+0x10], xmm2
00007f30a29d1d7f  vmovaps [rsp+0x20], xmm3
00007f30a29d1d85  vmovaps [rsp+0x30], xmm4
00007f30a29d1d8b  vmovaps [rsp+0x40], xmm5
00007f30a29d1d91  vmovaps [rsp+0x50], xmm6
00007f30a29d1d97  vmovaps [rsp+0x60], xmm7
00007f30a29d1d9d  vmovaps [rsp+0x70], xmm8
00007f30a29d1da3  vmovaps [rsp+0x80], xmm9
00007f30a29d1dac  vmovaps [rsp+0x90], xmm10
00007f30a29d1db5  vmovaps [rsp+0xA0], xmm11
00007f30a29d1dbe  vmovaps [rsp+0xB0], xmm12
00007f30a29d1dc7  vmovaps [rsp+0xC0], xmm13
00007f30a29d1dd0  vmovaps [rsp+0xD0], xmm14
00007f30a29d1dd9  vmovaps [rsp+0xE0], xmm15
00007f30a29d1de2  sub rsp, 0x30
00007f30a29d1de6  movaps [rsp], xmm1
00007f30a29d1dea  movaps [rsp+0x10], xmm14
00007f30a29d1df0  movaps [rsp+0x20], xmm15
00007f30a29d1df6  lea rdi, [rsp]
00007f30a29d1dfa  mov esi, 0x00
00007f30a29d1dff  mov rax, 0x5FE955026530
00007f30a29d1e09  call rax
00007f30a29d1e0b  movaps xmm1, [rsp]
00007f30a29d1e0f  add rsp, 0x30
00007f30a29d1e13  vmovaps xmm0, [rsp]
00007f30a29d1e18  vmovaps xmm2, [rsp+0x10]
00007f30a29d1e1e  vmovaps xmm3, [rsp+0x20]
00007f30a29d1e24  vmovaps xmm4, [rsp+0x30]
00007f30a29d1e2a  vmovaps xmm5, [rsp+0x40]
00007f30a29d1e30  vmovaps xmm6, [rsp+0x50]
00007f30a29d1e36  vmovaps xmm7, [rsp+0x60]
00007f30a29d1e3c  vmovaps xmm8, [rsp+0x70]
00007f30a29d1e42  vmovaps xmm9, [rsp+0x80]
00007f30a29d1e4b  vmovaps xmm10, [rsp+0x90]
00007f30a29d1e54  vmovaps xmm11, [rsp+0xA0]
00007f30a29d1e5d  vmovaps xmm12, [rsp+0xB0]
00007f30a29d1e66  vmovaps xmm13, [rsp+0xC0]
00007f30a29d1e6f  vmovaps xmm14, [rsp+0xD0]
00007f30a29d1e78  vmovaps xmm15, [rsp+0xE0]
00007f30a29d1e81  add rsp, 0xF0
00007f30a29d1e88  pop r11
00007f30a29d1e8a  pop r10
00007f30a29d1e8c  pop r9
00007f30a29d1e8e  pop r8
00007f30a29d1e90  pop rsi
00007f30a29d1e91  pop rdi
00007f30a29d1e92  pop rdx
00007f30a29d1e93  pop rcx
00007f30a29d1e94  pop rax
00007f30a29d1e95  add rsp, 0x08
00007f30a29d1e99  jmp 0x00007F30A29D1B4E
00007f30a29d1e9e  call 0x00007F30A27FF540
00007f30a29d1ea3  jmp 0x00007F30A29D1B61
00007f30a29d1ea8  int3
00007f30a29d1ea9  nop [rax], eax
00007f30a29d1eb0  movaps xmm1, [r15+0x180]
00007f30a29d1eb8  vpmovqd xmm15, xmm1
00007f30a29d1ebe  pxor xmm14, xmm14
00007f30a29d1ec3  punpcklqdq xmm15, xmm14
00007f30a29d1ec8  movaps [r15+0x210], xmm15
00007f30a29d1ed0  movq xmm15, qword ptr [r15+0x140]
00007f30a29d1ed9  movq xmm14, qword ptr [r15+0x120]
00007f30a29d1ee2  psubd xmm15, xmm14
00007f30a29d1ee7  movq xmm15, xmm15
00007f30a29d1eec  movaps xmm13, [r15+0x170]
00007f30a29d1ef4  paddq xmm1, xmm13
00007f30a29d1ef9  movaps [r15+0x180], xmm1
00007f30a29d1f01  movq xmm1, qword ptr [r15+0x160]
00007f30a29d1f0a  paddd xmm14, xmm1
00007f30a29d1f0f  movq xmm14, xmm14
00007f30a29d1f14  movq xmm14, xmm14
00007f30a29d1f19  movaps [r15+0x120], xmm14
00007f30a29d1f21  pmovzxdq xmm15, xmm15
00007f30a29d1f27  psllq xmm15, 0x00
00007f30a29d1f2d  movq xmm1, qword ptr [r15+0x210]
00007f30a29d1f36  movq xmm14, qword ptr [r15+0x110]
00007f30a29d1f3f  paddd xmm1, xmm14
00007f30a29d1f44  movq xmm1, xmm1
00007f30a29d1f48  vcvtuqq2pd xmm15, xmm15
00007f30a29d1f4e  pmovzxdq xmm1, xmm1
00007f30a29d1f53  psllq xmm1, 0x00
00007f30a29d1f58  vcvtuqq2pd xmm1, xmm1
00007f30a29d1f5e  movaps xmm14, [r15+0x150]
00007f30a29d1f66  movaps xmm13, xmm15
00007f30a29d1f6a  mulpd xmm13, xmm14
00007f30a29d1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
00007f30a29d1f75  ptest xmm12, xmm12
00007f30a29d1f7b  jnz 0x00007F30A29D205E
00007f30a29d1f81  movaps [r15+0x220], xmm13
00007f30a29d1f89  mov rax, [r15+0x48]
00007f30a29d1f8d  mov r14, [r15+0x50]
00007f30a29d1f91  lea r12, [r14+rax*1]
00007f30a29d1f95  movups [r13+r12*1], xmm13
00007f30a29d1f9b  movaps xmm15, [r15+0x130]
00007f30a29d1fa3  movaps xmm14, xmm1
00007f30a29d1fa7  mulpd xmm14, xmm15
00007f30a29d1fac  vcmppd xmm13, xmm14, xmm14, 0x03
00007f30a29d1fb2  ptest xmm13, xmm13
00007f30a29d1fb8  jnz 0x00007F30A29D21AC
00007f30a29d1fbe  movaps [r15+0x210], xmm14
00007f30a29d1fc6  mov r14, [r15+0x40]
00007f30a29d1fca  lea r12, [r14+rax*1]
00007f30a29d1fce  movups [r13+r12*1], xmm14
00007f30a29d1fd4  lea r14, [rax+0x10]
00007f30a29d1fd8  mov [r15+0x48], r14
00007f30a29d1fdc  xor eax, eax
00007f30a29d1fde  mov r12d, 0x200
00007f30a29d1fe4  cmp r14, r12
00007f30a29d1fe7  cmc
00007f30a29d1fe8  lahf
00007f30a29d1fe9  seto al
00007f30a29d1fec  mov [r15+0x108], eax
00007f30a29d1ff3  mov eax, [r15+0x108]
00007f30a29d1ffa  sahf
00007f30a29d1ffb  jnz 0x00007F30A29D202D
00007f30a29d1ffd  cmp dword ptr [r15+0x318], 0x00
00007f30a29d2005  jz 0x00007F30A29D2300
00007f30a29d200b  nop [rax+rax*1], ax
00007f30a29d2014  nop [rax+rax*1], eax
00007f30a29d201c  mov eax, 0x410490
00007f30a29d2021  mov [r15+0x100], rax
00007f30a29d2028  jmp 0x00007F30A27FE110
00007f30a29d202d  cmp dword ptr [r15+0x318], 0x00
00007f30a29d2035  jz 0x00007F30A29D1EB0
00007f30a29d203b  nop [rax+rax*1], ax
00007f30a29d2044  nop [rax+rax*1], eax
00007f30a29d204c  mov eax, 0x410450
00007f30a29d2051  mov [r15+0x100], rax
00007f30a29d2058  jmp 0x00007F30A27FE110
00007f30a29d205d  int3
00007f30a29d205e  sub rsp, 0x08
00007f30a29d2062  push rax
00007f30a29d2063  push rcx
00007f30a29d2064  push rdx
00007f30a29d2065  push rdi
00007f30a29d2066  push rsi
00007f30a29d2067  push r8
00007f30a29d2069  push r9
00007f30a29d206b  push r10
00007f30a29d206d  push r11
00007f30a29d206f  sub rsp, 0xF0
00007f30a29d2076  vmovaps [rsp], xmm0
00007f30a29d207b  vmovaps [rsp+0x10], xmm1
00007f30a29d2081  vmovaps [rsp+0x20], xmm2
00007f30a29d2087  vmovaps [rsp+0x30], xmm3
00007f30a29d208d  vmovaps [rsp+0x40], xmm4
00007f30a29d2093  vmovaps [rsp+0x50], xmm5
00007f30a29d2099  vmovaps [rsp+0x60], xmm6
00007f30a29d209f  vmovaps [rsp+0x70], xmm7
00007f30a29d20a5  vmovaps [rsp+0x80], xmm8
00007f30a29d20ae  vmovaps [rsp+0x90], xmm9
00007f30a29d20b7  vmovaps [rsp+0xA0], xmm10
00007f30a29d20c0  vmovaps [rsp+0xB0], xmm11
00007f30a29d20c9  vmovaps [rsp+0xC0], xmm12
00007f30a29d20d2  vmovaps [rsp+0xD0], xmm14
00007f30a29d20db  vmovaps [rsp+0xE0], xmm15
00007f30a29d20e4  sub rsp, 0x30
00007f30a29d20e8  movaps [rsp], xmm13
00007f30a29d20ed  movaps [rsp+0x10], xmm15
00007f30a29d20f3  movaps [rsp+0x20], xmm14
00007f30a29d20f9  lea rdi, [rsp]
00007f30a29d20fd  mov esi, 0x00
00007f30a29d2102  mov rax, 0x5FE955026530
00007f30a29d210c  call rax
00007f30a29d210e  movaps xmm13, [rsp]
00007f30a29d2113  add rsp, 0x30
00007f30a29d2117  vmovaps xmm0, [rsp]
00007f30a29d211c  vmovaps xmm1, [rsp+0x10]
00007f30a29d2122  vmovaps xmm2, [rsp+0x20]
00007f30a29d2128  vmovaps xmm3, [rsp+0x30]
00007f30a29d212e  vmovaps xmm4, [rsp+0x40]
00007f30a29d2134  vmovaps xmm5, [rsp+0x50]
00007f30a29d213a  vmovaps xmm6, [rsp+0x60]
00007f30a29d2140  vmovaps xmm7, [rsp+0x70]
00007f30a29d2146  vmovaps xmm8, [rsp+0x80]
00007f30a29d214f  vmovaps xmm9, [rsp+0x90]
00007f30a29d2158  vmovaps xmm10, [rsp+0xA0]
00007f30a29d2161  vmovaps xmm11, [rsp+0xB0]
00007f30a29d216a  vmovaps xmm12, [rsp+0xC0]
00007f30a29d2173  vmovaps xmm14, [rsp+0xD0]
00007f30a29d217c  vmovaps xmm15, [rsp+0xE0]
00007f30a29d2185  add rsp, 0xF0
00007f30a29d218c  pop r11
00007f30a29d218e  pop r10
00007f30a29d2190  pop r9
00007f30a29d2192  pop r8
00007f30a29d2194  pop rsi
00007f30a29d2195  pop rdi
00007f30a29d2196  pop rdx
00007f30a29d2197  pop rcx
00007f30a29d2198  pop rax
00007f30a29d2199  add rsp, 0x08
00007f30a29d219d  jmp 0x00007F30A29D1F81
00007f30a29d21a2  call 0x00007F30A28C2240
00007f30a29d21a7  jmp 0x00007F30A29D1F9B
00007f30a29d21ac  sub rsp, 0x08
00007f30a29d21b0  push rax
00007f30a29d21b1  push rcx
00007f30a29d21b2  push rdx
00007f30a29d21b3  push rdi
00007f30a29d21b4  push rsi
00007f30a29d21b5  push r8
00007f30a29d21b7  push r9
00007f30a29d21b9  push r10
00007f30a29d21bb  push r11
00007f30a29d21bd  sub rsp, 0xF0
00007f30a29d21c4  vmovaps [rsp], xmm0
00007f30a29d21c9  vmovaps [rsp+0x10], xmm1
00007f30a29d21cf  vmovaps [rsp+0x20], xmm2
00007f30a29d21d5  vmovaps [rsp+0x30], xmm3
00007f30a29d21db  vmovaps [rsp+0x40], xmm4
00007f30a29d21e1  vmovaps [rsp+0x50], xmm5
00007f30a29d21e7  vmovaps [rsp+0x60], xmm6
00007f30a29d21ed  vmovaps [rsp+0x70], xmm7
00007f30a29d21f3  vmovaps [rsp+0x80], xmm8
00007f30a29d21fc  vmovaps [rsp+0x90], xmm9
00007f30a29d2205  vmovaps [rsp+0xA0], xmm10
00007f30a29d220e  vmovaps [rsp+0xB0], xmm11
00007f30a29d2217  vmovaps [rsp+0xC0], xmm12
00007f30a29d2220  vmovaps [rsp+0xD0], xmm13
00007f30a29d2229  vmovaps [rsp+0xE0], xmm15
00007f30a29d2232  sub rsp, 0x30
00007f30a29d2236  movaps [rsp], xmm14
00007f30a29d223b  movaps [rsp+0x10], xmm1
00007f30a29d2240  movaps [rsp+0x20], xmm15
00007f30a29d2246  lea rdi, [rsp]
00007f30a29d224a  mov esi, 0x00
00007f30a29d224f  mov rax, 0x5FE955026530
00007f30a29d2259  call rax
00007f30a29d225b  movaps xmm14, [rsp]
00007f30a29d2260  add rsp, 0x30
00007f30a29d2264  vmovaps xmm0, [rsp]
00007f30a29d2269  vmovaps xmm1, [rsp+0x10]
00007f30a29d226f  vmovaps xmm2, [rsp+0x20]
00007f30a29d2275  vmovaps xmm3, [rsp+0x30]
00007f30a29d227b  vmovaps xmm4, [rsp+0x40]
00007f30a29d2281  vmovaps xmm5, [rsp+0x50]
00007f30a29d2287  vmovaps xmm6, [rsp+0x60]
00007f30a29d228d  vmovaps xmm7, [rsp+0x70]
00007f30a29d2293  vmovaps xmm8, [rsp+0x80]
00007f30a29d229c  vmovaps xmm9, [rsp+0x90]
00007f30a29d22a5  vmovaps xmm10, [rsp+0xA0]
00007f30a29d22ae  vmovaps xmm11, [rsp+0xB0]
00007f30a29d22b7  vmovaps xmm12, [rsp+0xC0]
00007f30a29d22c0  vmovaps xmm13, [rsp+0xD0]
00007f30a29d22c9  vmovaps xmm15, [rsp+0xE0]
00007f30a29d22d2  add rsp, 0xF0
00007f30a29d22d9  pop r11
00007f30a29d22db  pop r10
00007f30a29d22dd  pop r9
00007f30a29d22df  pop r8
00007f30a29d22e1  pop rsi
00007f30a29d22e2  pop rdi
00007f30a29d22e3  pop rdx
00007f30a29d22e4  pop rcx
00007f30a29d22e5  pop rax
00007f30a29d22e6  add rsp, 0x08
00007f30a29d22ea  jmp 0x00007F30A29D1FBE
00007f30a29d22ef  call 0x00007F30A28C34C0
00007f30a29d22f4  jmp 0x00007F30A29D1FD4
00007f30a29d22f9  int3
00007f30a29d22fa  nop [rax+rax*1], ax
00007f30a29d2300  mov rax, [r15+0x50]
00007f30a29d2304  lea r14, [rax+0x80]
00007f30a29d230b  movups xmm1, [r13+r14*1]
00007f30a29d2311  lea r14, [rax+0x90]
00007f30a29d2318  movups xmm15, [r13+r14*1]
00007f30a29d231e  vxorps xmm14, xmm14, xmm14
00007f30a29d2323  vpbroadcastq xmm14, xmm14
00007f30a29d2328  lea r14, [rax+0x40]
00007f30a29d232c  movups xmm13, [r13+r14*1]
00007f30a29d2332  lea r14, [rax+0x50]
00007f30a29d2336  movups xmm12, [r13+r14*1]
00007f30a29d233c  mov qword ptr [r15+0x48], 0x00
00007f30a29d2344  movups xmm11, [r13+rax*1]
00007f30a29d234a  lea r14, [rax+0x10]
00007f30a29d234e  movups xmm10, [r13+r14*1]
00007f30a29d2354  mov r14, [r15+0xF8]
00007f30a29d235b  lea r12, [r14+0xE0]
00007f30a29d2362  movups [r13+r12*1], xmm15
00007f30a29d2368  lea r12, [r14+0xF0]
00007f30a29d236f  movups [r13+r12*1], xmm1
00007f30a29d2375  lea r12, [rax+0xC0]
00007f30a29d237c  movups xmm1, [r13+r12*1]
00007f30a29d2382  lea r12, [rax+0xD0]
00007f30a29d2389  movups xmm15, [r13+r12*1]
00007f30a29d238f  lea r12, [rax+0x140]
00007f30a29d2396  movups xmm9, [r13+r12*1]
00007f30a29d239c  lea r12, [rax+0x150]
00007f30a29d23a3  movups xmm8, [r13+r12*1]
00007f30a29d23a9  lea r12, [rax+0x180]
00007f30a29d23b0  movups xmm7, [r13+r12*1]
00007f30a29d23b6  lea r12, [rax+0x190]
00007f30a29d23bd  movups xmm6, [r13+r12*1]
00007f30a29d23c3  lea r12, [r14+0xC0]
00007f30a29d23ca  movups [r13+r12*1], xmm15
00007f30a29d23d0  lea r12, [r14+0xD0]
00007f30a29d23d7  movups [r13+r12*1], xmm1
00007f30a29d23dd  lea r12, [rax+0x100]
00007f30a29d23e4  movups xmm1, [r13+r12*1]
00007f30a29d23ea  lea r12, [rax+0x110]
00007f30a29d23f1  movups xmm15, [r13+r12*1]
00007f30a29d23f7  lea r12, [rax+0x1C0]
00007f30a29d23fe  movups xmm5, [r13+r12*1]
00007f30a29d2404  lea r12, [rax+0x1D0]
00007f30a29d240b  movups xmm4, [r13+r12*1]
00007f30a29d2411  lea r12, [rax+0x20]
00007f30a29d2415  movups xmm3, [r13+r12*1]
00007f30a29d241b  lea r12, [rax+0x30]
00007f30a29d241f  movups xmm2, [r13+r12*1]
00007f30a29d2425  movaps [r15+0x1F0], xmm2
00007f30a29d242d  lea r12, [r14+0x20]
00007f30a29d2431  movups [r13+r12*1], xmm1
00007f30a29d2437  lea r12, [r14+0x30]
00007f30a29d243b  movups [r13+r12*1], xmm12
00007f30a29d2441  lea r12, [rax+0x60]
00007f30a29d2445  movups xmm1, [r13+r12*1]
00007f30a29d244b  lea r12, [rax+0x70]
00007f30a29d244f  movups xmm12, [r13+r12*1]
00007f30a29d2455  lea r12, [r14+0x60]
00007f30a29d2459  movups [r13+r12*1], xmm11
00007f30a29d245f  lea r12, [r14+0x70]
00007f30a29d2463  movups [r13+r12*1], xmm5
00007f30a29d2469  lea r12, [rax+0xE0]
00007f30a29d2470  movups xmm11, [r13+r12*1]
00007f30a29d2476  lea r12, [rax+0xF0]
00007f30a29d247d  movups xmm5, [r13+r12*1]
00007f30a29d2483  lea r12, [rax+0x120]
00007f30a29d248a  vmovaps [rsp+0x10], xmm1
00007f30a29d2490  movups xmm1, [r13+r12*1]
00007f30a29d2496  lea r12, [rax+0x130]
00007f30a29d249d  vmovaps [rsp+0x20], xmm1
00007f30a29d24a3  movups xmm1, [r13+r12*1]
00007f30a29d24a9  lea r12, [r14+0xA0]
00007f30a29d24b0  movups [r13+r12*1], xmm12
00007f30a29d24b6  lea r12, [r14+0xB0]
00007f30a29d24bd  vmovaps xmm12, [rsp+0x10]
00007f30a29d24c3  movups [r13+r12*1], xmm12
00007f30a29d24c9  lea r12, [rax+0xA0]
00007f30a29d24d0  movups xmm12, [r13+r12*1]
00007f30a29d24d6  lea r12, [rax+0xB0]
00007f30a29d24dd  vmovaps [rsp+0x10], xmm1
00007f30a29d24e3  movups xmm1, [r13+r12*1]
00007f30a29d24e9  lea r12, [rax+0x160]
00007f30a29d24f0  vmovaps [rsp+0x30], xmm1
00007f30a29d24f6  movups xmm1, [r13+r12*1]
00007f30a29d24fc  lea r12, [rax+0x170]
00007f30a29d2503  vmovaps [rsp+0x40], xmm1
00007f30a29d2509  movups xmm1, [r13+r12*1]
00007f30a29d250f  movaps [r15+0x2B0], xmm1
00007f30a29d2517  lea r12, [rax+0x1A0]
00007f30a29d251e  vmovaps [rsp+0x50], xmm1
00007f30a29d2524  movups xmm1, [r13+r12*1]
00007f30a29d252a  lea r12, [rax+0x1B0]
00007f30a29d2531  vmovaps [rsp+0x60], xmm1
00007f30a29d2537  movups xmm1, [r13+r12*1]
00007f30a29d253d  vmovaps [rsp+0x70], xmm1
00007f30a29d2543  vmovaps xmm1, [rsp+0x60]
00007f30a29d2549  movaps [r15+0x290], xmm1
00007f30a29d2551  vmovaps [rsp+0x60], xmm1
00007f30a29d2557  vmovaps xmm1, [rsp+0x70]
00007f30a29d255d  movaps [r15+0x1E0], xmm1
00007f30a29d2565  lea r12, [r14+0x80]
00007f30a29d256c  vmovaps [rsp+0x70], xmm1
00007f30a29d2572  vmovaps xmm1, [rsp+0x30]
00007f30a29d2578  movups [r13+r12*1], xmm1
00007f30a29d257e  lea r12, [r14+0x90]
00007f30a29d2585  movups [r13+r12*1], xmm12
00007f30a29d258b  lea r12, [rax+0x1E0]
00007f30a29d2592  movups xmm1, [r13+r12*1]
00007f30a29d2598  lea r12, [rax+0x1F0]
00007f30a29d259f  movups xmm12, [r13+r12*1]
00007f30a29d25a5  mov qword ptr [r15+0x50], 0x432200
00007f30a29d25ad  lea rax, [r14+0x40]
00007f30a29d25b1  vmovaps [rsp+0x30], xmm1
00007f30a29d25b7  vmovaps xmm1, [rsp+0x40]
00007f30a29d25bd  movups [r13+rax*1], xmm1
00007f30a29d25c3  lea rax, [r14+0x50]
00007f30a29d25c7  movups [r13+rax*1], xmm10
00007f30a29d25cd  movups [r13+r14*1], xmm12
00007f30a29d25d3  lea rax, [r14+0x10]
00007f30a29d25d7  vmovaps xmm1, [rsp+0x30]
00007f30a29d25dd  movups [r13+rax*1], xmm1
00007f30a29d25e3  mov rax, [r15+0x40]
00007f30a29d25e7  vmovaps [rsp+0x30], xmm3
00007f30a29d25ed  vmovaps xmm1, [rsp+0x30]
00007f30a29d25f3  por xmm3, xmm1
00007f30a29d25f7  vmovaps [rsp+0x30], xmm6
00007f30a29d25fd  vmovaps xmm12, [rsp+0x30]
00007f30a29d2603  por xmm6, xmm12
00007f30a29d2608  lea r12, [rax+0x30]
00007f30a29d260c  mov r11, [r13+r12*1]
00007f30a29d2611  lea r12, [rax+0x38]
00007f30a29d2615  mov r10, [r13+r12*1]
00007f30a29d261a  movq xmm12, r11
00007f30a29d261f  movq xmm10, r10
00007f30a29d2624  movq xmm12, xmm12
00007f30a29d2629  vmovaps [rsp+0x30], xmm12
00007f30a29d262f  movq xmm12, xmm12
00007f30a29d2634  movaps [r15+0x130], xmm12
00007f30a29d263c  movq xmm10, xmm10
00007f30a29d2641  vmovaps [rsp+0x40], xmm10
00007f30a29d2647  movq xmm10, xmm10
00007f30a29d264c  movaps [r15+0x280], xmm10
00007f30a29d2654  vmovaps [rsp+0x80], xmm9
00007f30a29d265d  vmovaps xmm12, [rsp+0x80]
00007f30a29d2666  por xmm9, xmm12
00007f30a29d266b  lea r12, [rax+0x20]
00007f30a29d266f  mov r11, [r13+r12*1]
00007f30a29d2674  lea r12, [rax+0x28]
00007f30a29d2678  mov r10, [r13+r12*1]
00007f30a29d267d  movq xmm12, r11
00007f30a29d2682  movq xmm10, r10
00007f30a29d2687  movq xmm12, xmm12
00007f30a29d268c  vmovaps [rsp+0x80], xmm12
00007f30a29d2695  movq xmm12, xmm12
00007f30a29d269a  movaps [r15+0x150], xmm12
00007f30a29d26a2  movq xmm10, xmm10
00007f30a29d26a7  vmovaps [rsp+0x90], xmm10
00007f30a29d26b0  movq xmm10, xmm10
00007f30a29d26b5  movaps [r15+0x140], xmm10
00007f30a29d26bd  lea r12, [rax+0x10]
00007f30a29d26c1  mov r11, [r13+r12*1]
00007f30a29d26c6  lea r12, [rax+0x18]
00007f30a29d26ca  mov r10, [r13+r12*1]
00007f30a29d26cf  movq xmm12, r11
00007f30a29d26d4  movq xmm10, r10
00007f30a29d26d9  movq xmm12, xmm12
00007f30a29d26de  vmovaps [rsp+0xA0], xmm12
00007f30a29d26e7  movq xmm12, xmm12
00007f30a29d26ec  movaps [r15+0x170], xmm12
00007f30a29d26f4  movq xmm10, xmm10
00007f30a29d26f9  vmovaps [rsp+0xB0], xmm10
00007f30a29d2702  movq xmm10, xmm10
00007f30a29d2707  movaps [r15+0x160], xmm10
00007f30a29d270f  mov r12, [r13+rax*1]
00007f30a29d2714  vmovq xmm12, r12
00007f30a29d2719  vpbroadcastq xmm12, xmm12
00007f30a29d271e  lea r12, [rax+0x08]
00007f30a29d2722  mov rax, [r13+r12*1]
00007f30a29d2727  movq xmm10, rax
00007f30a29d272c  movaps [r15+0x230], xmm10
00007f30a29d2734  lea rax, [r14+0x50]
00007f30a29d2738  movups xmm10, [r13+rax*1]
00007f30a29d273e  lea rax, [r14+0x60]
00007f30a29d2742  vmovaps [rsp+0xC0], xmm1
00007f30a29d274b  movups xmm1, [r13+rax*1]
00007f30a29d2751  lea rax, [r14+0x30]
00007f30a29d2755  vmovaps [rsp+0xD0], xmm1
00007f30a29d275e  movups xmm1, [r13+rax*1]
00007f30a29d2764  mov qword ptr [r15+0x60], 0x432200
00007f30a29d276c  mov qword ptr [r15+0x58], 0x40
00007f30a29d2774  vmovaps [rsp+0xE0], xmm1
00007f30a29d277d  vmovaps [rsp+0xF0], xmm15
00007f30a29d2786  vmovaps xmm15, [rsp+0xC0]
00007f30a29d278f  vmovaps [rsp+0xC0], xmm14
00007f30a29d2798  movaps xmm1, xmm12
00007f30a29d279c  mulpd xmm1, xmm15
00007f30a29d27a1  vcmppd xmm14, xmm1, xmm1, 0x03
00007f30a29d27a6  ptest xmm14, xmm14
00007f30a29d27ac  jnz 0x00007F30A29D3863
00007f30a29d27b2  movq xmm15, qword ptr [r15+0x230]
00007f30a29d27bb  vmovaps [rsp+0x100], xmm15
00007f30a29d27c4  vpermilpd xmm15, xmm15, 0x00
00007f30a29d27ca  vmovaps [rsp+0x110], xmm1
00007f30a29d27d3  vmovaps xmm1, [rsp+0xE0]
00007f30a29d27dc  vmovaps [rsp+0xE0], xmm13
00007f30a29d27e5  movaps xmm14, xmm1
00007f30a29d27e9  mulpd xmm14, xmm15
00007f30a29d27ee  vcmppd xmm13, xmm14, xmm14, 0x03
00007f30a29d27f4  ptest xmm13, xmm13
00007f30a29d27fa  jnz 0x00007F30A29D39A5
00007f30a29d2800  vxorps xmm1, xmm1, xmm1
00007f30a29d2804  vpbroadcastq xmm1, xmm1
00007f30a29d2809  vmovaps xmm13, [rsp+0xD0]
00007f30a29d2812  vmovaps [rsp+0xD0], xmm1
00007f30a29d281b  movaps xmm15, xmm12
00007f30a29d281f  mulpd xmm15, xmm13
00007f30a29d2824  vcmppd xmm1, xmm15, xmm15, 0x03
00007f30a29d282a  ptest xmm1, xmm1
00007f30a29d282f  jnz 0x00007F30A29D3AE8
00007f30a29d2835  movaps xmm1, xmm12
00007f30a29d2839  mulpd xmm1, xmm10
00007f30a29d283e  vcmppd xmm13, xmm1, xmm1, 0x03
00007f30a29d2843  ptest xmm13, xmm13
00007f30a29d2849  jnz 0x00007F30A29D3C2C
00007f30a29d284f  movaps xmm13, xmm12
00007f30a29d2853  mulpd xmm13, xmm2
00007f30a29d2858  vcmppd xmm10, xmm13, xmm13, 0x03
00007f30a29d285e  ptest xmm10, xmm10
00007f30a29d2864  jnz 0x00007F30A29D3D6E
00007f30a29d286a  vmovaps [rsp+0x120], xmm7
00007f30a29d2873  vmovaps xmm12, [rsp+0x120]
00007f30a29d287c  por xmm7, xmm12
00007f30a29d2881  vmovaps xmm12, [rsp+0xE0]
00007f30a29d288a  vmovaps xmm10, [rsp+0xE0]
00007f30a29d2893  por xmm12, xmm10
00007f30a29d2898  vmovaps xmm2, [rsp+0x100]
00007f30a29d28a1  vpermilpd xmm2, xmm2, 0x00
00007f30a29d28a7  vmovaps [rsp+0xE0], xmm1
00007f30a29d28b0  vmovaps [rsp+0x120], xmm15
00007f30a29d28b9  movaps xmm1, xmm10
00007f30a29d28bd  mulpd xmm1, xmm2
00007f30a29d28c1  vcmppd xmm15, xmm1, xmm1, 0x03
00007f30a29d28c6  ptest xmm15, xmm15
00007f30a29d28cc  jnz 0x00007F30A29D3EB1
00007f30a29d28d2  xor eax, eax
00007f30a29d28d4  mov r12d, 0x40
00007f30a29d28da  mov r11d, 0x200
00007f30a29d28e0  cmp r12, r11
00007f30a29d28e3  cmc
00007f30a29d28e4  lahf
00007f30a29d28e5  seto al
00007f30a29d28e8  mov [r15+0x108], eax
00007f30a29d28ef  vmovaps xmm10, [rsp+0x110]
00007f30a29d28f8  vmovaps xmm2, [rsp+0xD0]
00007f30a29d2901  vmovaps [rsp+0xD0], xmm1
00007f30a29d290a  movaps xmm15, xmm10
00007f30a29d290e  addpd xmm15, xmm2
00007f30a29d2913  vcmppd xmm1, xmm15, xmm15, 0x03
00007f30a29d2919  ptest xmm1, xmm1
00007f30a29d291e  jnz 0x00007F30A29D3FF2
00007f30a29d2924  vmovaps xmm10, [rsp+0x120]
00007f30a29d292d  vmovaps [rsp+0x110], xmm15
00007f30a29d2936  vmovaps xmm15, [rsp+0xC0]
00007f30a29d293f  vmovaps [rsp+0xC0], xmm14
00007f30a29d2948  movaps xmm1, xmm10
00007f30a29d294c  addpd xmm1, xmm15
00007f30a29d2951  vcmppd xmm14, xmm1, xmm1, 0x03
00007f30a29d2956  ptest xmm14, xmm14
00007f30a29d295c  jnz 0x00007F30A29D4135
00007f30a29d2962  vmovaps xmm10, [rsp+0xE0]
00007f30a29d296b  vmovaps [rsp+0xE0], xmm1
00007f30a29d2974  movaps xmm14, xmm10
00007f30a29d2978  addpd xmm14, xmm15
00007f30a29d297d  vcmppd xmm1, xmm14, xmm14, 0x03
00007f30a29d2983  ptest xmm1, xmm1
00007f30a29d2988  jnz 0x00007F30A29D4277
00007f30a29d298e  vmovaps xmm1, [rsp+0x10]
00007f30a29d2994  vmovaps xmm15, [rsp+0x10]
00007f30a29d299a  por xmm1, xmm15
00007f30a29d299f  vmovaps xmm15, [rsp+0x20]
00007f30a29d29a5  vmovaps xmm10, [rsp+0x20]
00007f30a29d29ab  por xmm15, xmm10
00007f30a29d29b0  vmovaps [rsp+0x10], xmm5
00007f30a29d29b6  vmovaps xmm10, [rsp+0x10]
00007f30a29d29bc  por xmm5, xmm10
00007f30a29d29c1  vmovaps [rsp+0x10], xmm11
00007f30a29d29c7  vmovaps xmm10, [rsp+0x10]
00007f30a29d29cd  por xmm11, xmm10
00007f30a29d29d2  vmovaps [rsp+0x10], xmm4
00007f30a29d29d8  vmovaps xmm10, [rsp+0x10]
00007f30a29d29de  por xmm4, xmm10
00007f30a29d29e3  vmovaps [rsp+0x10], xmm8
00007f30a29d29e9  vmovaps xmm10, [rsp+0x10]
00007f30a29d29ef  por xmm8, xmm10
00007f30a29d29f4  vmovaps xmm10, [rsp+0xF0]
00007f30a29d29fd  vmovaps [rsp+0x10], xmm1
00007f30a29d2a03  vmovaps xmm1, [rsp+0xF0]
00007f30a29d2a0c  por xmm10, xmm1
00007f30a29d2a11  lea rax, [r14+0xA0]
00007f30a29d2a18  movups xmm1, [r13+rax*1]
00007f30a29d2a1e  lea rax, [r14+0xB0]
00007f30a29d2a25  vmovaps [rsp+0x20], xmm1
00007f30a29d2a2b  movups xmm1, [r13+rax*1]
00007f30a29d2a31  vmovaps [rsp+0xF0], xmm1
00007f30a29d2a3a  vmovaps [rsp+0x120], xmm15
00007f30a29d2a43  movaps xmm1, xmm13
00007f30a29d2a47  addpd xmm1, xmm2
00007f30a29d2a4b  vcmppd xmm15, xmm1, xmm1, 0x03
00007f30a29d2a50  ptest xmm15, xmm15
00007f30a29d2a56  jnz 0x00007F30A29D43CF
00007f30a29d2a5c  lea rax, [r14+0xF0]
00007f30a29d2a63  movups xmm15, [r13+rax*1]
00007f30a29d2a69  vmovaps xmm2, [rsp+0xE0]
00007f30a29d2a72  vmovaps [rsp+0xE0], xmm1
00007f30a29d2a7b  vmovaps xmm1, [rsp+0xD0]
00007f30a29d2a84  vmovaps [rsp+0xD0], xmm15
00007f30a29d2a8d  movaps xmm13, xmm2
00007f30a29d2a91  addpd xmm13, xmm1
00007f30a29d2a96  vcmppd xmm15, xmm13, xmm13, 0x03
00007f30a29d2a9c  ptest xmm15, xmm15
00007f30a29d2aa2  jnz 0x00007F30A29D451A
00007f30a29d2aa8  vmovaps xmm15, [rsp+0xC0]
00007f30a29d2ab1  movaps xmm1, xmm14
00007f30a29d2ab5  addpd xmm1, xmm15
00007f30a29d2aba  vcmppd xmm2, xmm1, xmm1, 0x03
00007f30a29d2abf  ptest xmm2, xmm2
00007f30a29d2ac4  jnz 0x00007F30A29D465C
00007f30a29d2aca  vmovaps xmm15, [rsp+0x100]
00007f30a29d2ad3  vpermilpd xmm15, xmm15, 0x00
00007f30a29d2ad9  vmovaps xmm2, [rsp+0xF0]
00007f30a29d2ae2  vmovaps [rsp+0xC0], xmm1
00007f30a29d2aeb  movaps xmm14, xmm2
00007f30a29d2aef  mulpd xmm14, xmm15
00007f30a29d2af4  vcmppd xmm1, xmm14, xmm14, 0x03
00007f30a29d2afa  ptest xmm1, xmm1
00007f30a29d2aff  jnz 0x00007F30A29D479E
00007f30a29d2b05  vmovaps xmm1, [rsp+0xA0]
00007f30a29d2b0e  vpermilpd xmm1, xmm1, 0x00
00007f30a29d2b14  vmovaps xmm2, [rsp+0xD0]
00007f30a29d2b1d  vmovaps [rsp+0xD0], xmm14
00007f30a29d2b26  movaps xmm15, xmm2
00007f30a29d2b2a  mulpd xmm15, xmm1
00007f30a29d2b2f  vcmppd xmm14, xmm15, xmm15, 0x03
00007f30a29d2b35  ptest xmm14, xmm14
00007f30a29d2b3b  jnz 0x00007F30A29D48E1
00007f30a29d2b41  lea rax, [r14+0xE0]
00007f30a29d2b48  movups xmm1, [r13+rax*1]
00007f30a29d2b4e  vmovaps xmm14, [rsp+0x100]
00007f30a29d2b57  vpermilpd xmm14, xmm14, 0x00
00007f30a29d2b5d  vmovaps [rsp+0xF0], xmm1
00007f30a29d2b66  vmovaps xmm1, [rsp+0x20]
00007f30a29d2b6c  vmovaps [rsp+0x20], xmm15
00007f30a29d2b72  movaps xmm2, xmm1
00007f30a29d2b75  mulpd xmm2, xmm14
00007f30a29d2b7a  vcmppd xmm15, xmm2, xmm2, 0x03
00007f30a29d2b7f  ptest xmm15, xmm15
00007f30a29d2b85  jnz 0x00007F30A29D4A2D
00007f30a29d2b8b  vmovaps [rsp+0x100], xmm10
00007f30a29d2b94  vmovaps xmm1, [rsp+0x100]
00007f30a29d2b9d  por xmm10, xmm1
00007f30a29d2ba2  movaps [r15+0x300], xmm10
00007f30a29d2baa  vmovaps [rsp+0x100], xmm8
00007f30a29d2bb3  vmovaps xmm1, [rsp+0x100]
00007f30a29d2bbc  por xmm8, xmm1
00007f30a29d2bc1  movaps [r15+0x190], xmm8
00007f30a29d2bc9  vmovaps xmm1, [rsp+0xA0]
00007f30a29d2bd2  vpermilpd xmm1, xmm1, 0x00
00007f30a29d2bd8  vmovaps xmm14, [rsp+0xF0]
00007f30a29d2be1  vmovaps [rsp+0xF0], xmm13
00007f30a29d2bea  movaps xmm15, xmm14
00007f30a29d2bee  mulpd xmm15, xmm1
00007f30a29d2bf3  vcmppd xmm13, xmm15, xmm15, 0x03
00007f30a29d2bf9  ptest xmm13, xmm13
00007f30a29d2bff  jnz 0x00007F30A29D4B6E
00007f30a29d2c05  lea rax, [r14+0x90]
00007f30a29d2c0c  movups xmm1, [r13+rax*1]
00007f30a29d2c12  vmovaps [rsp+0x100], xmm4
00007f30a29d2c1b  vmovaps xmm14, [rsp+0x100]
00007f30a29d2c24  por xmm4, xmm14
00007f30a29d2c29  movaps [r15+0x1C0], xmm4
00007f30a29d2c31  vmovaps [rsp+0x100], xmm11
00007f30a29d2c3a  vmovaps xmm14, [rsp+0x100]
00007f30a29d2c43  por xmm11, xmm14
00007f30a29d2c48  movaps [r15+0x200], xmm11
00007f30a29d2c50  vmovaps [rsp+0x100], xmm5
00007f30a29d2c59  vmovaps xmm14, [rsp+0x100]
00007f30a29d2c62  por xmm5, xmm14
00007f30a29d2c67  movaps [r15+0x2D0], xmm5
00007f30a29d2c6f  vmovaps xmm14, [rsp+0x120]
00007f30a29d2c78  vmovaps xmm13, [rsp+0x120]
00007f30a29d2c81  por xmm14, xmm13
00007f30a29d2c86  movaps [r15+0x2E0], xmm14
00007f30a29d2c8e  vmovaps [rsp+0x100], xmm1
00007f30a29d2c97  vmovaps xmm1, [rsp+0x110]
00007f30a29d2ca0  vmovaps [rsp+0x110], xmm15
00007f30a29d2ca9  vmovaps xmm15, [rsp+0xD0]
00007f30a29d2cb2  vmovaps [rsp+0xD0], xmm14
00007f30a29d2cbb  movaps xmm13, xmm1
00007f30a29d2cbf  addpd xmm13, xmm15
00007f30a29d2cc4  vcmppd xmm14, xmm13, xmm13, 0x03
00007f30a29d2cca  ptest xmm14, xmm14
00007f30a29d2cd0  jnz 0x00007F30A29D4CBB
00007f30a29d2cd6  vmovaps xmm1, [rsp+0xA0]
00007f30a29d2cdf  vpermilpd xmm1, xmm1, 0x00
00007f30a29d2ce5  vmovaps xmm14, [rsp+0x100]
00007f30a29d2cee  vmovaps [rsp+0x100], xmm13
00007f30a29d2cf7  movaps xmm15, xmm14
00007f30a29d2cfb  mulpd xmm15, xmm1
00007f30a29d2d00  vcmppd xmm13, xmm15, xmm15, 0x03
00007f30a29d2d06  ptest xmm13, xmm13
00007f30a29d2d0c  jnz 0x00007F30A29D4DFE
00007f30a29d2d12  lea rax, [r14+0x80]
00007f30a29d2d19  movups xmm1, [r13+rax*1]
00007f30a29d2d1f  vmovaps xmm13, [rsp+0xE0]
00007f30a29d2d28  vmovaps [rsp+0xE0], xmm1
00007f30a29d2d31  movaps xmm14, xmm13
00007f30a29d2d35  addpd xmm14, xmm2
00007f30a29d2d3a  vcmppd xmm1, xmm14, xmm14, 0x03
00007f30a29d2d40  ptest xmm1, xmm1
00007f30a29d2d45  jnz 0x00007F30A29D4F4B
00007f30a29d2d4b  vmovaps xmm13, [rsp+0xF0]
00007f30a29d2d54  vmovaps xmm2, [rsp+0x20]
00007f30a29d2d5a  vmovaps [rsp+0x20], xmm15
00007f30a29d2d60  movaps xmm1, xmm13
00007f30a29d2d64  addpd xmm1, xmm2
00007f30a29d2d68  vcmppd xmm15, xmm1, xmm1, 0x03
00007f30a29d2d6d  ptest xmm15, xmm15
00007f30a29d2d73  jnz 0x00007F30A29D508E
00007f30a29d2d79  vmovaps xmm15, [rsp+0x10]
00007f30a29d2d7f  vmovaps xmm13, [rsp+0x10]
00007f30a29d2d85  por xmm15, xmm13
00007f30a29d2d8a  movaps [r15+0x2F0], xmm15
00007f30a29d2d92  vmovaps xmm13, [rsp+0xA0]
00007f30a29d2d9b  vpermilpd xmm13, xmm13, 0x00
00007f30a29d2da1  vmovaps [rsp+0x10], xmm1
00007f30a29d2da7  vmovaps xmm1, [rsp+0xE0]
00007f30a29d2db0  vmovaps [rsp+0xA0], xmm15
00007f30a29d2db9  movaps xmm2, xmm1
00007f30a29d2dbc  mulpd xmm2, xmm13
00007f30a29d2dc1  vcmppd xmm15, xmm2, xmm2, 0x03
00007f30a29d2dc6  ptest xmm15, xmm15
00007f30a29d2dcc  jnz 0x00007F30A29D51CF
00007f30a29d2dd2  lea rax, [r14+0xD0]
00007f30a29d2dd9  movups xmm1, [r13+rax*1]
00007f30a29d2ddf  vmovaps xmm13, [rsp+0xC0]
00007f30a29d2de8  vmovaps [rsp+0xC0], xmm1
00007f30a29d2df1  vmovaps xmm1, [rsp+0x110]
00007f30a29d2dfa  vmovaps [rsp+0xE0], xmm14
00007f30a29d2e03  movaps xmm15, xmm13
00007f30a29d2e07  addpd xmm15, xmm1
00007f30a29d2e0c  vcmppd xmm14, xmm15, xmm15, 0x03
00007f30a29d2e12  ptest xmm14, xmm14
00007f30a29d2e18  jnz 0x00007F30A29D531A
00007f30a29d2e1e  vmovaps xmm1, [rsp+0xB0]
00007f30a29d2e27  vpermilpd xmm1, xmm1, 0x00
00007f30a29d2e2d  movaps xmm14, xmm11
00007f30a29d2e31  mulpd xmm14, xmm1
00007f30a29d2e36  vcmppd xmm13, xmm14, xmm14, 0x03
00007f30a29d2e3c  ptest xmm13, xmm13
00007f30a29d2e42  jnz 0x00007F30A29D545D
00007f30a29d2e48  movaps [r15+0x260], xmm14
00007f30a29d2e50  vxorps xmm1, xmm1, xmm1
00007f30a29d2e54  vpbroadcastq xmm1, xmm1
00007f30a29d2e59  movaps [r15+0x1B0], xmm1
00007f30a29d2e61  vmovaps xmm1, [rsp+0xB0]
00007f30a29d2e6a  vpermilpd xmm1, xmm1, 0x00
00007f30a29d2e70  vmovaps xmm11, [rsp+0xC0]
00007f30a29d2e79  vmovaps [rsp+0xC0], xmm15
00007f30a29d2e82  movaps xmm13, xmm11
00007f30a29d2e86  mulpd xmm13, xmm1
00007f30a29d2e8b  vcmppd xmm15, xmm13, xmm13, 0x03
00007f30a29d2e91  ptest xmm15, xmm15
00007f30a29d2e97  jnz 0x00007F30A29D55A0
00007f30a29d2e9d  lea rax, [r14+0xC0]
00007f30a29d2ea4  movups xmm1, [r13+rax*1]
00007f30a29d2eaa  vmovaps xmm11, [rsp+0x100]
00007f30a29d2eb3  vmovaps [rsp+0xF0], xmm1
00007f30a29d2ebc  vmovaps xmm1, [rsp+0x20]
00007f30a29d2ec2  vmovaps [rsp+0x20], xmm14
00007f30a29d2ec8  movaps xmm15, xmm11
00007f30a29d2ecc  addpd xmm15, xmm1
00007f30a29d2ed1  vcmppd xmm14, xmm15, xmm15, 0x03
00007f30a29d2ed7  ptest xmm14, xmm14
00007f30a29d2edd  jnz 0x00007F30A29D56ED
00007f30a29d2ee3  vmovaps [rsp+0x100], xmm9
00007f30a29d2eec  vmovaps xmm1, [rsp+0x100]
00007f30a29d2ef5  por xmm9, xmm1
00007f30a29d2efa  movaps [r15+0x270], xmm9
00007f30a29d2f02  vmovaps [rsp+0x100], xmm6
00007f30a29d2f0b  vmovaps xmm1, [rsp+0x100]
00007f30a29d2f14  por xmm6, xmm1
00007f30a29d2f18  movaps [r15+0x1A0], xmm6
00007f30a29d2f20  vmovaps xmm14, [rsp+0xB0]
00007f30a29d2f29  vpermilpd xmm14, xmm14, 0x00
00007f30a29d2f2f  vmovaps xmm6, [rsp+0xF0]
00007f30a29d2f38  vmovaps [rsp+0xF0], xmm1
00007f30a29d2f41  movaps xmm11, xmm6
00007f30a29d2f45  mulpd xmm11, xmm14
00007f30a29d2f4a  vcmppd xmm1, xmm11, xmm11, 0x03
00007f30a29d2f50  ptest xmm1, xmm1
00007f30a29d2f55  jnz 0x00007F30A29D5830
00007f30a29d2f5b  lea rax, [r14+0x20]
00007f30a29d2f5f  movups xmm1, [r13+rax*1]
00007f30a29d2f65  movaps [r15+0x110], xmm1
00007f30a29d2f6d  vmovaps xmm6, [rsp+0xE0]
00007f30a29d2f76  vmovaps [rsp+0xE0], xmm1
00007f30a29d2f7f  movaps xmm14, xmm6
00007f30a29d2f83  addpd xmm14, xmm2
00007f30a29d2f88  vcmppd xmm1, xmm14, xmm14, 0x03
00007f30a29d2f8e  ptest xmm1, xmm1
00007f30a29d2f93  jnz 0x00007F30A29D597D
00007f30a29d2f99  vmovaps xmm1, [rsp+0xB0]
00007f30a29d2fa2  vpermilpd xmm1, xmm1, 0x00
00007f30a29d2fa8  movaps xmm6, xmm5
00007f30a29d2fab  mulpd xmm6, xmm1
00007f30a29d2faf  vcmppd xmm2, xmm6, xmm6, 0x03
00007f30a29d2fb4  ptest xmm2, xmm2
00007f30a29d2fb9  jnz 0x00007F30A29D5ABF
00007f30a29d2fbf  vmovaps xmm5, [rsp+0x10]
00007f30a29d2fc5  movaps xmm1, xmm5
00007f30a29d2fc8  addpd xmm1, xmm13
00007f30a29d2fcd  vcmppd xmm2, xmm1, xmm1, 0x03
00007f30a29d2fd2  ptest xmm2, xmm2
00007f30a29d2fd7  jnz 0x00007F30A29D5BFF
00007f30a29d2fdd  vmovaps xmm13, [rsp+0x80]
00007f30a29d2fe6  vpermilpd xmm13, xmm13, 0x00
00007f30a29d2fec  vmovaps xmm2, [rsp+0xE0]
00007f30a29d2ff5  vmovaps [rsp+0x10], xmm1
00007f30a29d2ffb  movaps xmm5, xmm2
00007f30a29d2ffe  mulpd xmm5, xmm13
00007f30a29d3003  vcmppd xmm1, xmm5, xmm5, 0x03
00007f30a29d3008  ptest xmm1, xmm1
00007f30a29d300d  jnz 0x00007F30A29D5D40
00007f30a29d3013  vmovaps xmm1, [rsp+0x80]
00007f30a29d301c  vpermilpd xmm1, xmm1, 0x00
00007f30a29d3022  movaps xmm13, xmm10
00007f30a29d3026  mulpd xmm13, xmm1
00007f30a29d302b  vcmppd xmm2, xmm13, xmm13, 0x03
00007f30a29d3031  ptest xmm2, xmm2
00007f30a29d3036  jnz 0x00007F30A29D5E81
00007f30a29d303c  vmovaps xmm10, [rsp+0x20]
00007f30a29d3042  movaps xmm1, xmm15
00007f30a29d3046  addpd xmm1, xmm10
00007f30a29d304b  vcmppd xmm2, xmm1, xmm1, 0x03
00007f30a29d3050  ptest xmm2, xmm2
00007f30a29d3055  jnz 0x00007F30A29D5FC4
00007f30a29d305b  vmovaps xmm10, [rsp+0xC0]
00007f30a29d3064  movaps xmm15, xmm10
00007f30a29d3068  addpd xmm15, xmm11
00007f30a29d306d  vcmppd xmm2, xmm15, xmm15, 0x03
00007f30a29d3073  ptest xmm2, xmm2
00007f30a29d3078  jnz 0x00007F30A29D6106
00007f30a29d307e  vmovaps xmm11, [rsp+0x80]
00007f30a29d3087  vpermilpd xmm11, xmm11, 0x00
00007f30a29d308d  vmovaps xmm2, [rsp+0xD0]
00007f30a29d3096  vmovaps [rsp+0x20], xmm1
00007f30a29d309c  movaps xmm10, xmm2
00007f30a29d30a0  mulpd xmm10, xmm11
00007f30a29d30a5  vcmppd xmm1, xmm10, xmm10, 0x03
00007f30a29d30ab  ptest xmm1, xmm1
00007f30a29d30b0  jnz 0x00007F30A29D624A
00007f30a29d30b6  vmovaps xmm1, [rsp+0x80]
00007f30a29d30bf  vpermilpd xmm1, xmm1, 0x00
00007f30a29d30c5  vmovaps xmm2, [rsp+0xA0]
00007f30a29d30ce  vmovaps [rsp+0x80], xmm15
00007f30a29d30d7  movaps xmm11, xmm2
00007f30a29d30db  mulpd xmm11, xmm1
00007f30a29d30e0  vcmppd xmm15, xmm11, xmm11, 0x03
00007f30a29d30e6  ptest xmm15, xmm15
00007f30a29d30ec  jnz 0x00007F30A29D638D
00007f30a29d30f2  movaps xmm1, xmm14
00007f30a29d30f6  addpd xmm1, xmm6
00007f30a29d30fa  vcmppd xmm15, xmm1, xmm1, 0x03
00007f30a29d30ff  ptest xmm15, xmm15
00007f30a29d3105  jnz 0x00007F30A29D64CF
00007f30a29d310b  vmovaps xmm14, [rsp+0x10]
00007f30a29d3111  movaps xmm15, xmm14
00007f30a29d3115  addpd xmm15, xmm5
00007f30a29d311a  vcmppd xmm6, xmm15, xmm15, 0x03
00007f30a29d3120  ptest xmm6, xmm6
00007f30a29d3125  jnz 0x00007F30A29D6610
00007f30a29d312b  vmovaps xmm14, [rsp+0x90]
00007f30a29d3134  vpermilpd xmm14, xmm14, 0x00
00007f30a29d313a  movaps xmm6, xmm9
00007f30a29d313e  mulpd xmm6, xmm14
00007f30a29d3143  vcmppd xmm5, xmm6, xmm6, 0x03
00007f30a29d3148  ptest xmm5, xmm5
00007f30a29d314d  jnz 0x00007F30A29D6753
00007f30a29d3153  vmovaps xmm9, [rsp+0x80]
00007f30a29d315c  movaps xmm14, xmm9
00007f30a29d3160  addpd xmm14, xmm13
00007f30a29d3165  vcmppd xmm5, xmm14, xmm14, 0x03
00007f30a29d316b  ptest xmm5, xmm5
00007f30a29d3170  jnz 0x00007F30A29D6895
00007f30a29d3176  vmovaps xmm9, [rsp+0x20]
00007f30a29d317c  movaps xmm13, xmm9
00007f30a29d3180  addpd xmm13, xmm10
00007f30a29d3185  vcmppd xmm5, xmm13, xmm13, 0x03
00007f30a29d318b  ptest xmm5, xmm5
00007f30a29d3190  jnz 0x00007F30A29D69D9
00007f30a29d3196  vmovaps [rsp+0x10], xmm12
00007f30a29d319c  vmovaps xmm10, [rsp+0x10]
00007f30a29d31a2  por xmm12, xmm10
00007f30a29d31a7  movaps [r15+0x250], xmm12
00007f30a29d31af  vmovaps [rsp+0x10], xmm7
00007f30a29d31b5  vmovaps xmm12, [rsp+0x10]
00007f30a29d31bb  por xmm7, xmm12
00007f30a29d31c0  movaps [r15+0x2A0], xmm7
00007f30a29d31c8  vmovaps [rsp+0x10], xmm3
00007f30a29d31ce  vmovaps xmm12, [rsp+0x10]
00007f30a29d31d4  por xmm3, xmm12
00007f30a29d31d9  movaps [r15+0x1D0], xmm3
00007f30a29d31e1  lea rax, [r14+0x40]
00007f30a29d31e5  movups xmm12, [r13+rax*1]
00007f30a29d31eb  movaps [r15+0x2C0], xmm12
00007f30a29d31f3  vmovaps xmm10, [rsp+0x90]
00007f30a29d31fc  vpermilpd xmm10, xmm10, 0x00
00007f30a29d3202  movaps xmm9, xmm8
00007f30a29d3206  mulpd xmm9, xmm10
00007f30a29d320b  vcmppd xmm5, xmm9, xmm9, 0x03
00007f30a29d3211  ptest xmm5, xmm5
00007f30a29d3216  jnz 0x00007F30A29D6B27
00007f30a29d321c  movaps xmm10, xmm1
00007f30a29d3220  addpd xmm10, xmm11
00007f30a29d3225  vcmppd xmm8, xmm10, xmm10, 0x03
00007f30a29d322b  ptest xmm8, xmm8
00007f30a29d3231  jnz 0x00007F30A29D6C6B
00007f30a29d3237  movaps xmm1, xmm15
00007f30a29d323b  addpd xmm1, xmm6
00007f30a29d323f  vcmppd xmm11, xmm1, xmm1, 0x03
00007f30a29d3244  ptest xmm11, xmm11
00007f30a29d324a  jnz 0x00007F30A29D6DAE
00007f30a29d3250  vmovaps xmm15, [rsp+0x90]
00007f30a29d3259  vpermilpd xmm15, xmm15, 0x00
00007f30a29d325f  movaps xmm11, xmm12
00007f30a29d3263  mulpd xmm11, xmm15
00007f30a29d3268  vcmppd xmm8, xmm11, xmm11, 0x03
00007f30a29d326e  ptest xmm8, xmm8
00007f30a29d3274  jnz 0x00007F30A29D6EEF
00007f30a29d327a  vmovaps xmm15, [rsp+0x90]
00007f30a29d3283  vpermilpd xmm15, xmm15, 0x00
00007f30a29d3289  vmovaps xmm8, [rsp+0x50]
00007f30a29d328f  movaps xmm12, xmm8
00007f30a29d3293  mulpd xmm12, xmm15
00007f30a29d3298  vcmppd xmm6, xmm12, xmm12, 0x03
00007f30a29d329e  ptest xmm6, xmm6
00007f30a29d32a3  jnz 0x00007F30A29D7033
00007f30a29d32a9  vmovaps xmm15, [rsp+0x30]
00007f30a29d32af  vpermilpd xmm15, xmm15, 0x00
00007f30a29d32b5  movaps xmm8, xmm7
00007f30a29d32b9  mulpd xmm8, xmm15
00007f30a29d32be  vcmppd xmm6, xmm8, xmm8, 0x03
00007f30a29d32c4  ptest xmm6, xmm6
00007f30a29d32c9  jnz 0x00007F30A29D7177
00007f30a29d32cf  movaps xmm15, xmm14
00007f30a29d32d3  addpd xmm15, xmm9
00007f30a29d32d8  vcmppd xmm7, xmm15, xmm15, 0x03
00007f30a29d32de  ptest xmm7, xmm7
00007f30a29d32e3  jnz 0x00007F30A29D72BA
00007f30a29d32e9  vmovaps xmm14, [rsp+0x30]
00007f30a29d32ef  vpermilpd xmm14, xmm14, 0x00
00007f30a29d32f5  vmovaps xmm7, [rsp+0xF0]
00007f30a29d32fe  movaps xmm9, xmm7
00007f30a29d3302  mulpd xmm9, xmm14
00007f30a29d3307  vcmppd xmm6, xmm9, xmm9, 0x03
00007f30a29d330d  ptest xmm6, xmm6
00007f30a29d3312  jnz 0x00007F30A29D73FE
00007f30a29d3318  movaps xmm14, xmm13
00007f30a29d331c  addpd xmm14, xmm11
00007f30a29d3321  vcmppd xmm7, xmm14, xmm14, 0x03
00007f30a29d3327  ptest xmm7, xmm7
00007f30a29d332c  jnz 0x00007F30A29D7541
00007f30a29d3332  vmovaps xmm13, [rsp+0x30]
00007f30a29d3338  vpermilpd xmm13, xmm13, 0x00
00007f30a29d333e  vmovaps xmm7, [rsp+0x60]
00007f30a29d3344  movaps xmm11, xmm7
00007f30a29d3348  mulpd xmm11, xmm13
00007f30a29d334d  vcmppd xmm6, xmm11, xmm11, 0x03
00007f30a29d3353  ptest xmm6, xmm6
00007f30a29d3358  jnz 0x00007F30A29D7685
00007f30a29d335e  movaps xmm13, xmm10
00007f30a29d3362  addpd xmm13, xmm12
00007f30a29d3367  vcmppd xmm7, xmm13, xmm13, 0x03
00007f30a29d336d  ptest xmm7, xmm7
00007f30a29d3372  jnz 0x00007F30A29D77C8
00007f30a29d3378  vmovaps xmm12, [rsp+0x30]
00007f30a29d337e  vpermilpd xmm12, xmm12, 0x00
00007f30a29d3384  vmovaps xmm7, [rsp+0x70]
00007f30a29d338a  movaps xmm10, xmm7
00007f30a29d338e  mulpd xmm10, xmm12
00007f30a29d3393  vcmppd xmm6, xmm10, xmm10, 0x03
00007f30a29d3399  ptest xmm6, xmm6
00007f30a29d339e  jnz 0x00007F30A29D790C
00007f30a29d33a4  movaps xmm12, xmm1
00007f30a29d33a8  addpd xmm12, xmm8
00007f30a29d33ad  vcmppd xmm7, xmm12, xmm12, 0x03
00007f30a29d33b3  ptest xmm7, xmm7
00007f30a29d33b8  jnz 0x00007F30A29D7A4F
00007f30a29d33be  lea rax, [r14+0x70]
00007f30a29d33c2  movups xmm1, [r13+rax*1]
00007f30a29d33c8  movaps [r15+0x240], xmm1
00007f30a29d33d0  movaps xmm8, xmm15
00007f30a29d33d4  addpd xmm8, xmm9
00007f30a29d33d9  vcmppd xmm7, xmm8, xmm8, 0x03
00007f30a29d33df  ptest xmm7, xmm7
00007f30a29d33e4  jnz 0x00007F30A29D7B9C
00007f30a29d33ea  movaps [r15+0x170], xmm8
00007f30a29d33f2  vmovaps xmm15, [rsp+0x40]
00007f30a29d33f8  vpermilpd xmm15, xmm15, 0x00
00007f30a29d33fe  movaps xmm9, xmm1
00007f30a29d3402  mulpd xmm9, xmm15
00007f30a29d3407  vcmppd xmm7, xmm9, xmm9, 0x03
00007f30a29d340d  ptest xmm7, xmm7
00007f30a29d3412  jnz 0x00007F30A29D7CE0
00007f30a29d3418  vmovaps xmm1, [rsp+0x40]
00007f30a29d341e  vpermilpd xmm1, xmm1, 0x00
00007f30a29d3424  movaps xmm15, xmm4
00007f30a29d3428  mulpd xmm15, xmm1
00007f30a29d342d  vcmppd xmm7, xmm15, xmm15, 0x03
00007f30a29d3433  ptest xmm7, xmm7
00007f30a29d3438  jnz 0x00007F30A29D7E23
00007f30a29d343e  movaps [r15+0x180], xmm15
00007f30a29d3446  movaps xmm1, xmm14
00007f30a29d344a  addpd xmm1, xmm11
00007f30a29d344f  vcmppd xmm7, xmm1, xmm1, 0x03
00007f30a29d3454  ptest xmm7, xmm7
00007f30a29d3459  jnz 0x00007F30A29D7F65
00007f30a29d345f  movaps [r15+0x210], xmm1
00007f30a29d3467  movups xmm14, [r13+r14*1]
00007f30a29d346d  lea rax, [r14+0x10]
00007f30a29d3471  movups xmm11, [r13+rax*1]
00007f30a29d3477  movaps [r15+0x230], xmm11
00007f30a29d347f  movaps xmm7, xmm13
00007f30a29d3483  addpd xmm7, xmm10
00007f30a29d3488  vcmppd xmm6, xmm7, xmm7, 0x03
00007f30a29d348d  ptest xmm6, xmm6
00007f30a29d3492  jnz 0x00007F30A29D80BB
00007f30a29d3498  movaps [r15+0x130], xmm7
00007f30a29d34a0  vmovaps xmm13, [rsp+0x40]
00007f30a29d34a6  vpermilpd xmm13, xmm13, 0x00
00007f30a29d34ac  movaps xmm10, xmm11
00007f30a29d34b0  mulpd xmm10, xmm13
00007f30a29d34b5  vcmppd xmm6, xmm10, xmm10, 0x03
00007f30a29d34bb  ptest xmm6, xmm6
00007f30a29d34c0  jnz 0x00007F30A29D81FD
00007f30a29d34c6  movaps [r15+0x220], xmm10
00007f30a29d34ce  vmovaps xmm13, [rsp+0x40]
00007f30a29d34d4  vpermilpd xmm13, xmm13, 0x00
00007f30a29d34da  movaps xmm11, xmm14
00007f30a29d34de  mulpd xmm11, xmm13
00007f30a29d34e3  vcmppd xmm6, xmm11, xmm11, 0x03
00007f30a29d34e9  ptest xmm6, xmm6
00007f30a29d34ee  jnz 0x00007F30A29D8341
00007f30a29d34f4  movaps xmm14, xmm12
00007f30a29d34f8  addpd xmm14, xmm9
00007f30a29d34fd  vcmppd xmm13, xmm14, xmm14, 0x03
00007f30a29d3503  ptest xmm13, xmm13
00007f30a29d3509  jnz 0x00007F30A29D8485
00007f30a29d350f  movaps [r15+0x140], xmm14
00007f30a29d3517  movaps xmm13, xmm8
00007f30a29d351b  addpd xmm13, xmm15
00007f30a29d3520  vcmppd xmm12, xmm13, xmm13, 0x03
00007f30a29d3526  ptest xmm12, xmm12
00007f30a29d352c  jnz 0x00007F30A29D85C9
00007f30a29d3532  movaps [r15+0x150], xmm13
00007f30a29d353a  movaps xmm15, xmm1
00007f30a29d353e  addpd xmm15, xmm10
00007f30a29d3543  vcmppd xmm12, xmm15, xmm15, 0x03
00007f30a29d3549  ptest xmm12, xmm12
00007f30a29d354f  jnz 0x00007F30A29D870D
00007f30a29d3555  movaps [r15+0x160], xmm15
00007f30a29d355d  movaps xmm1, xmm7
00007f30a29d3560  addpd xmm1, xmm11
00007f30a29d3565  vcmppd xmm12, xmm1, xmm1, 0x03
00007f30a29d356a  ptest xmm12, xmm12
00007f30a29d3570  jnz 0x00007F30A29D8850
00007f30a29d3576  movaps [r15+0x120], xmm1
00007f30a29d357e  mov eax, 0x432200
00007f30a29d3583  movups [r13+rax*1], xmm14
00007f30a29d3589  mov eax, 0x432210
00007f30a29d358e  movups [r13+rax*1], xmm13
00007f30a29d3594  mov eax, 0x432220
00007f30a29d3599  movups [r13+rax*1], xmm15
00007f30a29d359f  mov eax, 0x432230
00007f30a29d35a4  movups [r13+rax*1], xmm1
00007f30a29d35aa  mov eax, [r15+0x108]
00007f30a29d35b1  sahf
00007f30a29d35b2  jnz 0x00007F30A29D35E4
00007f30a29d35b4  cmp dword ptr [r15+0x318], 0x00
00007f30a29d35bc  jz 0x00007F30A29DEAE0
00007f30a29d35c2  nop [rax+rax*1], ax
00007f30a29d35cb  nop [rax+rax*1], eax
00007f30a29d35d3  mov eax, 0x4106D0
00007f30a29d35d8  mov [r15+0x100], rax
00007f30a29d35df  jmp 0x00007F30A27FE110
00007f30a29d35e4  cmp dword ptr [r15+0x318], 0x00
00007f30a29d35ec  jz 0x00007F30A29D89C0
00007f30a29d35f2  nop [rax+rax*1], ax
00007f30a29d35fb  nop [rax+rax*1], eax
00007f30a29d3603  mov eax, 0x410504
00007f30a29d3608  mov [r15+0x100], rax
00007f30a29d360f  jmp 0x00007F30A27FE110
00007f30a29d3614  int3
00007f30a29d3615  call 0x00007F30A28D64F0
00007f30a29d361a  jmp 0x00007F30A29D2311
00007f30a29d361f  call 0x00007F30A28E5820
00007f30a29d3624  jmp 0x00007F30A29D231E
00007f30a29d3629  call 0x00007F30A28E3320
00007f30a29d362e  jmp 0x00007F30A29D2332
00007f30a29d3633  call 0x00007F30A28E20A0
00007f30a29d3638  jmp 0x00007F30A29D233C
00007f30a29d363d  call 0x00007F30A2809D70
00007f30a29d3642  jmp 0x00007F30A29D234A
00007f30a29d3647  call 0x00007F30A28DFBC0
00007f30a29d364c  jmp 0x00007F30A29D2354
00007f30a29d3651  call 0x00007F30A28C4740
00007f30a29d3656  jmp 0x00007F30A29D2368
00007f30a29d365b  call 0x00007F30A28B5400
00007f30a29d3660  jmp 0x00007F30A29D2375
00007f30a29d3665  call 0x00007F30A28B52F0
00007f30a29d366a  jmp 0x00007F30A29D2382
00007f30a29d366f  call 0x00007F30A28C4620
00007f30a29d3674  jmp 0x00007F30A29D238F
00007f30a29d3679  call 0x00007F30A28BD750
00007f30a29d367e  jmp 0x00007F30A29D239C
00007f30a29d3683  call 0x00007F30A28BC4E0
00007f30a29d3688  jmp 0x00007F30A29D23A9
00007f30a29d368d  call 0x00007F30A28BB270
00007f30a29d3692  jmp 0x00007F30A29D23B6
00007f30a29d3697  call 0x00007F30A28BA000
00007f30a29d369c  jmp 0x00007F30A29D23C3
00007f30a29d36a1  call 0x00007F30A28C4740
00007f30a29d36a6  jmp 0x00007F30A29D23D0
00007f30a29d36ab  call 0x00007F30A28B5400
00007f30a29d36b0  jmp 0x00007F30A29D23DD
00007f30a29d36b5  call 0x00007F30A28B52F0
00007f30a29d36ba  jmp 0x00007F30A29D23EA
00007f30a29d36bf  call 0x00007F30A28C4620
00007f30a29d36c4  jmp 0x00007F30A29D23F7
00007f30a29d36c9  call 0x00007F30A28B8D90
00007f30a29d36ce  jmp 0x00007F30A29D2404
00007f30a29d36d3  call 0x00007F30A28B8A20
00007f30a29d36d8  jmp 0x00007F30A29D2411
00007f30a29d36dd  call 0x00007F30A28B77B0
00007f30a29d36e2  jmp 0x00007F30A29D241B
00007f30a29d36e7  call 0x00007F30A28B6550
00007f30a29d36ec  jmp 0x00007F30A29D2425
00007f30a29d36f1  call 0x00007F30A28B5400
00007f30a29d36f6  jmp 0x00007F30A29D2437
00007f30a29d36fb  call 0x00007F30A28C0FC0
00007f30a29d3700  jmp 0x00007F30A29D2441
00007f30a29d3705  call 0x00007F30A28B52F0
00007f30a29d370a  jmp 0x00007F30A29D244B
00007f30a29d370f  call 0x00007F30A28C0EA0
00007f30a29d3714  jmp 0x00007F30A29D2455
00007f30a29d3719  call 0x00007F30A28BFD50
00007f30a29d371e  jmp 0x00007F30A29D245F
00007f30a29d3723  call 0x00007F30A28B8EA0
00007f30a29d3728  jmp 0x00007F30A29D2469
00007f30a29d372d  call 0x00007F30A28BFC30
00007f30a29d3732  jmp 0x00007F30A29D2476
00007f30a29d3737  call 0x00007F30A28B8D90
00007f30a29d373c  jmp 0x00007F30A29D2483
00007f30a29d3741  call 0x00007F30A28B52F0
00007f30a29d3746  jmp 0x00007F30A29D2496
00007f30a29d374b  call 0x00007F30A28B52F0
00007f30a29d3750  jmp 0x00007F30A29D24A9
00007f30a29d3755  call 0x00007F30A28C0FC0
00007f30a29d375a  jmp 0x00007F30A29D24B6
00007f30a29d375f  call 0x00007F30A28C0FC0
00007f30a29d3764  jmp 0x00007F30A29D24C9
00007f30a29d3769  call 0x00007F30A28C0EA0
00007f30a29d376e  jmp 0x00007F30A29D24D6
00007f30a29d3773  call 0x00007F30A28B52F0
00007f30a29d3778  jmp 0x00007F30A29D24E9
00007f30a29d377d  call 0x00007F30A28B52F0
00007f30a29d3782  jmp 0x00007F30A29D24FC
00007f30a29d3787  call 0x00007F30A28B52F0
00007f30a29d378c  jmp 0x00007F30A29D250F
00007f30a29d3791  call 0x00007F30A28B52F0
00007f30a29d3796  jmp 0x00007F30A29D252A
00007f30a29d379b  call 0x00007F30A28B52F0
00007f30a29d37a0  jmp 0x00007F30A29D253D
00007f30a29d37a5  call 0x00007F30A28B5400
00007f30a29d37aa  jmp 0x00007F30A29D257E
00007f30a29d37af  call 0x00007F30A28C0FC0
00007f30a29d37b4  jmp 0x00007F30A29D258B
00007f30a29d37b9  call 0x00007F30A28B52F0
00007f30a29d37be  jmp 0x00007F30A29D2598
00007f30a29d37c3  call 0x00007F30A28C0EA0
00007f30a29d37c8  jmp 0x00007F30A29D25A5
00007f30a29d37cd  call 0x00007F30A27FF540
00007f30a29d37d2  jmp 0x00007F30A29D25C3
00007f30a29d37d7  call 0x00007F30A2808C20
00007f30a29d37dc  jmp 0x00007F30A29D25CD
00007f30a29d37e1  call 0x00007F30A28E21C0
00007f30a29d37e6  jmp 0x00007F30A29D25D3
00007f30a29d37eb  call 0x00007F30A27FF540
00007f30a29d37f0  jmp 0x00007F30A29D25E3
00007f30a29d37f5  call 0x00007F30A28C0370
00007f30a29d37fa  jmp 0x00007F30A29D2611
00007f30a29d37ff  call 0x00007F30A28BF100
00007f30a29d3804  jmp 0x00007F30A29D261A
00007f30a29d3809  call 0x00007F30A28C0370
00007f30a29d380e  jmp 0x00007F30A29D2674
00007f30a29d3813  call 0x00007F30A28BF100
00007f30a29d3818  jmp 0x00007F30A29D267D
00007f30a29d381d  call 0x00007F30A28C0370
00007f30a29d3822  jmp 0x00007F30A29D26C6
00007f30a29d3827  call 0x00007F30A28BF100
00007f30a29d382c  jmp 0x00007F30A29D26CF
00007f30a29d3831  call 0x00007F30A280B720
00007f30a29d3836  jmp 0x00007F30A29D2714
00007f30a29d383b  call 0x00007F30A28B47C0
00007f30a29d3840  jmp 0x00007F30A29D2727
00007f30a29d3845  call 0x00007F30A2808B00
00007f30a29d384a  jmp 0x00007F30A29D273E
00007f30a29d384f  call 0x00007F30A27FF430
00007f30a29d3854  jmp 0x00007F30A29D2751
00007f30a29d3859  call 0x00007F30A27FF430
00007f30a29d385e  jmp 0x00007F30A29D2764
00007f30a29d3863  sub rsp, 0x08
00007f30a29d3867  push rax
00007f30a29d3868  push rcx
00007f30a29d3869  push rdx
00007f30a29d386a  push rdi
00007f30a29d386b  push rsi
00007f30a29d386c  push r8
00007f30a29d386e  push r9
00007f30a29d3870  push r10
00007f30a29d3872  push r11
00007f30a29d3874  sub rsp, 0xF0
00007f30a29d387b  vmovaps [rsp], xmm0
00007f30a29d3880  vmovaps [rsp+0x10], xmm2
00007f30a29d3886  vmovaps [rsp+0x20], xmm3
00007f30a29d388c  vmovaps [rsp+0x30], xmm4
00007f30a29d3892  vmovaps [rsp+0x40], xmm5
00007f30a29d3898  vmovaps [rsp+0x50], xmm6
00007f30a29d389e  vmovaps [rsp+0x60], xmm7
00007f30a29d38a4  vmovaps [rsp+0x70], xmm8
00007f30a29d38aa  vmovaps [rsp+0x80], xmm9
00007f30a29d38b3  vmovaps [rsp+0x90], xmm10
00007f30a29d38bc  vmovaps [rsp+0xA0], xmm11
00007f30a29d38c5  vmovaps [rsp+0xB0], xmm12
00007f30a29d38ce  vmovaps [rsp+0xC0], xmm13
00007f30a29d38d7  vmovaps [rsp+0xD0], xmm14
00007f30a29d38e0  vmovaps [rsp+0xE0], xmm15
00007f30a29d38e9  sub rsp, 0x30
00007f30a29d38ed  movaps [rsp], xmm1
00007f30a29d38f1  movaps [rsp+0x10], xmm12
00007f30a29d38f7  movaps [rsp+0x20], xmm15
00007f30a29d38fd  lea rdi, [rsp]
00007f30a29d3901  mov esi, 0x00
00007f30a29d3906  mov rax, 0x5FE955026530
00007f30a29d3910  call rax
00007f30a29d3912  movaps xmm1, [rsp]
00007f30a29d3916  add rsp, 0x30
00007f30a29d391a  vmovaps xmm0, [rsp]
00007f30a29d391f  vmovaps xmm2, [rsp+0x10]
00007f30a29d3925  vmovaps xmm3, [rsp+0x20]
00007f30a29d392b  vmovaps xmm4, [rsp+0x30]
00007f30a29d3931  vmovaps xmm5, [rsp+0x40]
00007f30a29d3937  vmovaps xmm6, [rsp+0x50]
00007f30a29d393d  vmovaps xmm7, [rsp+0x60]
00007f30a29d3943  vmovaps xmm8, [rsp+0x70]
00007f30a29d3949  vmovaps xmm9, [rsp+0x80]
00007f30a29d3952  vmovaps xmm10, [rsp+0x90]
00007f30a29d395b  vmovaps xmm11, [rsp+0xA0]
00007f30a29d3964  vmovaps xmm12, [rsp+0xB0]
00007f30a29d396d  vmovaps xmm13, [rsp+0xC0]
00007f30a29d3976  vmovaps xmm14, [rsp+0xD0]
00007f30a29d397f  vmovaps xmm15, [rsp+0xE0]
00007f30a29d3988  add rsp, 0xF0
00007f30a29d398f  pop r11
00007f30a29d3991  pop r10
00007f30a29d3993  pop r9
00007f30a29d3995  pop r8
00007f30a29d3997  pop rsi
00007f30a29d3998  pop rdi
00007f30a29d3999  pop rdx
00007f30a29d399a  pop rcx
00007f30a29d399b  pop rax
00007f30a29d399c  add rsp, 0x08
00007f30a29d39a0  jmp 0x00007F30A29D27B2
00007f30a29d39a5  sub rsp, 0x08
00007f30a29d39a9  push rax
00007f30a29d39aa  push rcx
00007f30a29d39ab  push rdx
00007f30a29d39ac  push rdi
00007f30a29d39ad  push rsi
00007f30a29d39ae  push r8
00007f30a29d39b0  push r9
00007f30a29d39b2  push r10
00007f30a29d39b4  push r11
00007f30a29d39b6  sub rsp, 0xF0
00007f30a29d39bd  vmovaps [rsp], xmm0
00007f30a29d39c2  vmovaps [rsp+0x10], xmm1
00007f30a29d39c8  vmovaps [rsp+0x20], xmm2
00007f30a29d39ce  vmovaps [rsp+0x30], xmm3
00007f30a29d39d4  vmovaps [rsp+0x40], xmm4
00007f30a29d39da  vmovaps [rsp+0x50], xmm5
00007f30a29d39e0  vmovaps [rsp+0x60], xmm6
00007f30a29d39e6  vmovaps [rsp+0x70], xmm7
00007f30a29d39ec  vmovaps [rsp+0x80], xmm8
00007f30a29d39f5  vmovaps [rsp+0x90], xmm9
00007f30a29d39fe  vmovaps [rsp+0xA0], xmm10
00007f30a29d3a07  vmovaps [rsp+0xB0], xmm11
00007f30a29d3a10  vmovaps [rsp+0xC0], xmm12
00007f30a29d3a19  vmovaps [rsp+0xD0], xmm13
00007f30a29d3a22  vmovaps [rsp+0xE0], xmm15
00007f30a29d3a2b  sub rsp, 0x30
00007f30a29d3a2f  movaps [rsp], xmm14
00007f30a29d3a34  movaps [rsp+0x10], xmm1
00007f30a29d3a39  movaps [rsp+0x20], xmm15
00007f30a29d3a3f  lea rdi, [rsp]
00007f30a29d3a43  mov esi, 0x00
00007f30a29d3a48  mov rax, 0x5FE955026530
00007f30a29d3a52  call rax
00007f30a29d3a54  movaps xmm14, [rsp]
00007f30a29d3a59  add rsp, 0x30
00007f30a29d3a5d  vmovaps xmm0, [rsp]
00007f30a29d3a62  vmovaps xmm1, [rsp+0x10]
00007f30a29d3a68  vmovaps xmm2, [rsp+0x20]
00007f30a29d3a6e  vmovaps xmm3, [rsp+0x30]
00007f30a29d3a74  vmovaps xmm4, [rsp+0x40]
00007f30a29d3a7a  vmovaps xmm5, [rsp+0x50]
00007f30a29d3a80  vmovaps xmm6, [rsp+0x60]
00007f30a29d3a86  vmovaps xmm7, [rsp+0x70]
00007f30a29d3a8c  vmovaps xmm8, [rsp+0x80]
00007f30a29d3a95  vmovaps xmm9, [rsp+0x90]
00007f30a29d3a9e  vmovaps xmm10, [rsp+0xA0]
00007f30a29d3aa7  vmovaps xmm11, [rsp+0xB0]
00007f30a29d3ab0  vmovaps xmm12, [rsp+0xC0]
00007f30a29d3ab9  vmovaps xmm13, [rsp+0xD0]
00007f30a29d3ac2  vmovaps xmm15, [rsp+0xE0]
00007f30a29d3acb  add rsp, 0xF0
00007f30a29d3ad2  pop r11
00007f30a29d3ad4  pop r10
00007f30a29d3ad6  pop r9
00007f30a29d3ad8  pop r8
00007f30a29d3ada  pop rsi
00007f30a29d3adb  pop rdi
00007f30a29d3adc  pop rdx
00007f30a29d3add  pop rcx
00007f30a29d3ade  pop rax
00007f30a29d3adf  add rsp, 0x08
00007f30a29d3ae3  jmp 0x00007F30A29D2800
00007f30a29d3ae8  sub rsp, 0x08
00007f30a29d3aec  push rax
00007f30a29d3aed  push rcx
00007f30a29d3aee  push rdx
00007f30a29d3aef  push rdi
00007f30a29d3af0  push rsi
00007f30a29d3af1  push r8
00007f30a29d3af3  push r9
00007f30a29d3af5  push r10
00007f30a29d3af7  push r11
00007f30a29d3af9  sub rsp, 0xF0
00007f30a29d3b00  vmovaps [rsp], xmm0
00007f30a29d3b05  vmovaps [rsp+0x10], xmm1
00007f30a29d3b0b  vmovaps [rsp+0x20], xmm2
00007f30a29d3b11  vmovaps [rsp+0x30], xmm3
00007f30a29d3b17  vmovaps [rsp+0x40], xmm4
00007f30a29d3b1d  vmovaps [rsp+0x50], xmm5
00007f30a29d3b23  vmovaps [rsp+0x60], xmm6
00007f30a29d3b29  vmovaps [rsp+0x70], xmm7
00007f30a29d3b2f  vmovaps [rsp+0x80], xmm8
00007f30a29d3b38  vmovaps [rsp+0x90], xmm9
00007f30a29d3b41  vmovaps [rsp+0xA0], xmm10
00007f30a29d3b4a  vmovaps [rsp+0xB0], xmm11
00007f30a29d3b53  vmovaps [rsp+0xC0], xmm12
00007f30a29d3b5c  vmovaps [rsp+0xD0], xmm13
00007f30a29d3b65  vmovaps [rsp+0xE0], xmm14
00007f30a29d3b6e  sub rsp, 0x30
00007f30a29d3b72  movaps [rsp], xmm15
00007f30a29d3b77  movaps [rsp+0x10], xmm12
00007f30a29d3b7d  movaps [rsp+0x20], xmm13
00007f30a29d3b83  lea rdi, [rsp]
00007f30a29d3b87  mov esi, 0x00
00007f30a29d3b8c  mov rax, 0x5FE955026530
00007f30a29d3b96  call rax
00007f30a29d3b98  movaps xmm15, [rsp]
00007f30a29d3b9d  add rsp, 0x30
00007f30a29d3ba1  vmovaps xmm0, [rsp]
00007f30a29d3ba6  vmovaps xmm1, [rsp+0x10]
00007f30a29d3bac  vmovaps xmm2, [rsp+0x20]
00007f30a29d3bb2  vmovaps xmm3, [rsp+0x30]
00007f30a29d3bb8  vmovaps xmm4, [rsp+0x40]
00007f30a29d3bbe  vmovaps xmm5, [rsp+0x50]
00007f30a29d3bc4  vmovaps xmm6, [rsp+0x60]
00007f30a29d3bca  vmovaps xmm7, [rsp+0x70]
00007f30a29d3bd0  vmovaps xmm8, [rsp+0x80]
00007f30a29d3bd9  vmovaps xmm9, [rsp+0x90]
00007f30a29d3be2  vmovaps xmm10, [rsp+0xA0]
00007f30a29d3beb  vmovaps xmm11, [rsp+0xB0]
00007f30a29d3bf4  vmovaps xmm12, [rsp+0xC0]
00007f30a29d3bfd  vmovaps xmm13, [rsp+0xD0]
00007f30a29d3c06  vmovaps xmm14, [rsp+0xE0]
00007f30a29d3c0f  add rsp, 0xF0
00007f30a29d3c16  pop r11
00007f30a29d3c18  pop r10
00007f30a29d3c1a  pop r9
00007f30a29d3c1c  pop r8
00007f30a29d3c1e  pop rsi
00007f30a29d3c1f  pop rdi
00007f30a29d3c20  pop rdx
00007f30a29d3c21  pop rcx
00007f30a29d3c22  pop rax
00007f30a29d3c23  add rsp, 0x08
00007f30a29d3c27  jmp 0x00007F30A29D2835
00007f30a29d3c2c  sub rsp, 0x08
00007f30a29d3c30  push rax
00007f30a29d3c31  push rcx
00007f30a29d3c32  push rdx
00007f30a29d3c33  push rdi
00007f30a29d3c34  push rsi
00007f30a29d3c35  push r8
00007f30a29d3c37  push r9
00007f30a29d3c39  push r10
00007f30a29d3c3b  push r11
00007f30a29d3c3d  sub rsp, 0xF0
00007f30a29d3c44  vmovaps [rsp], xmm0
00007f30a29d3c49  vmovaps [rsp+0x10], xmm2
00007f30a29d3c4f  vmovaps [rsp+0x20], xmm3
00007f30a29d3c55  vmovaps [rsp+0x30], xmm4
00007f30a29d3c5b  vmovaps [rsp+0x40], xmm5
00007f30a29d3c61  vmovaps [rsp+0x50], xmm6
00007f30a29d3c67  vmovaps [rsp+0x60], xmm7
00007f30a29d3c6d  vmovaps [rsp+0x70], xmm8
00007f30a29d3c73  vmovaps [rsp+0x80], xmm9
00007f30a29d3c7c  vmovaps [rsp+0x90], xmm10
00007f30a29d3c85  vmovaps [rsp+0xA0], xmm11
00007f30a29d3c8e  vmovaps [rsp+0xB0], xmm12
00007f30a29d3c97  vmovaps [rsp+0xC0], xmm13
00007f30a29d3ca0  vmovaps [rsp+0xD0], xmm14
00007f30a29d3ca9  vmovaps [rsp+0xE0], xmm15
00007f30a29d3cb2  sub rsp, 0x30
00007f30a29d3cb6  movaps [rsp], xmm1
00007f30a29d3cba  movaps [rsp+0x10], xmm12
00007f30a29d3cc0  movaps [rsp+0x20], xmm10
00007f30a29d3cc6  lea rdi, [rsp]
00007f30a29d3cca  mov esi, 0x00
00007f30a29d3ccf  mov rax, 0x5FE955026530
00007f30a29d3cd9  call rax
00007f30a29d3cdb  movaps xmm1, [rsp]
00007f30a29d3cdf  add rsp, 0x30
00007f30a29d3ce3  vmovaps xmm0, [rsp]
00007f30a29d3ce8  vmovaps xmm2, [rsp+0x10]
00007f30a29d3cee  vmovaps xmm3, [rsp+0x20]
00007f30a29d3cf4  vmovaps xmm4, [rsp+0x30]
00007f30a29d3cfa  vmovaps xmm5, [rsp+0x40]
00007f30a29d3d00  vmovaps xmm6, [rsp+0x50]
00007f30a29d3d06  vmovaps xmm7, [rsp+0x60]
00007f30a29d3d0c  vmovaps xmm8, [rsp+0x70]
00007f30a29d3d12  vmovaps xmm9, [rsp+0x80]
00007f30a29d3d1b  vmovaps xmm10, [rsp+0x90]
00007f30a29d3d24  vmovaps xmm11, [rsp+0xA0]
00007f30a29d3d2d  vmovaps xmm12, [rsp+0xB0]
00007f30a29d3d36  vmovaps xmm13, [rsp+0xC0]
00007f30a29d3d3f  vmovaps xmm14, [rsp+0xD0]
00007f30a29d3d48  vmovaps xmm15, [rsp+0xE0]
00007f30a29d3d51  add rsp, 0xF0
00007f30a29d3d58  pop r11
00007f30a29d3d5a  pop r10
00007f30a29d3d5c  pop r9
00007f30a29d3d5e  pop r8
00007f30a29d3d60  pop rsi
00007f30a29d3d61  pop rdi
00007f30a29d3d62  pop rdx
00007f30a29d3d63  pop rcx
00007f30a29d3d64  pop rax
00007f30a29d3d65  add rsp, 0x08
00007f30a29d3d69  jmp 0x00007F30A29D284F
00007f30a29d3d6e  sub rsp, 0x08
00007f30a29d3d72  push rax
00007f30a29d3d73  push rcx
00007f30a29d3d74  push rdx
00007f30a29d3d75  push rdi
00007f30a29d3d76  push rsi
00007f30a29d3d77  push r8
00007f30a29d3d79  push r9
00007f30a29d3d7b  push r10
00007f30a29d3d7d  push r11
00007f30a29d3d7f  sub rsp, 0xF0
00007f30a29d3d86  vmovaps [rsp], xmm0
00007f30a29d3d8b  vmovaps [rsp+0x10], xmm1
00007f30a29d3d91  vmovaps [rsp+0x20], xmm2
00007f30a29d3d97  vmovaps [rsp+0x30], xmm3
00007f30a29d3d9d  vmovaps [rsp+0x40], xmm4
00007f30a29d3da3  vmovaps [rsp+0x50], xmm5
00007f30a29d3da9  vmovaps [rsp+0x60], xmm6
00007f30a29d3daf  vmovaps [rsp+0x70], xmm7
00007f30a29d3db5  vmovaps [rsp+0x80], xmm8
00007f30a29d3dbe  vmovaps [rsp+0x90], xmm9
00007f30a29d3dc7  vmovaps [rsp+0xA0], xmm10
00007f30a29d3dd0  vmovaps [rsp+0xB0], xmm11
00007f30a29d3dd9  vmovaps [rsp+0xC0], xmm12
00007f30a29d3de2  vmovaps [rsp+0xD0], xmm14
00007f30a29d3deb  vmovaps [rsp+0xE0], xmm15
00007f30a29d3df4  sub rsp, 0x30
00007f30a29d3df8  movaps [rsp], xmm13
00007f30a29d3dfd  movaps [rsp+0x10], xmm12
00007f30a29d3e03  movaps [rsp+0x20], xmm2
00007f30a29d3e08  lea rdi, [rsp]
00007f30a29d3e0c  mov esi, 0x00
00007f30a29d3e11  mov rax, 0x5FE955026530
00007f30a29d3e1b  call rax
00007f30a29d3e1d  movaps xmm13, [rsp]
00007f30a29d3e22  add rsp, 0x30
00007f30a29d3e26  vmovaps xmm0, [rsp]
00007f30a29d3e2b  vmovaps xmm1, [rsp+0x10]
00007f30a29d3e31  vmovaps xmm2, [rsp+0x20]
00007f30a29d3e37  vmovaps xmm3, [rsp+0x30]
00007f30a29d3e3d  vmovaps xmm4, [rsp+0x40]
00007f30a29d3e43  vmovaps xmm5, [rsp+0x50]
00007f30a29d3e49  vmovaps xmm6, [rsp+0x60]
00007f30a29d3e4f  vmovaps xmm7, [rsp+0x70]
00007f30a29d3e55  vmovaps xmm8, [rsp+0x80]
00007f30a29d3e5e  vmovaps xmm9, [rsp+0x90]
00007f30a29d3e67  vmovaps xmm10, [rsp+0xA0]
00007f30a29d3e70  vmovaps xmm11, [rsp+0xB0]
00007f30a29d3e79  vmovaps xmm12, [rsp+0xC0]
00007f30a29d3e82  vmovaps xmm14, [rsp+0xD0]
00007f30a29d3e8b  vmovaps xmm15, [rsp+0xE0]
00007f30a29d3e94  add rsp, 0xF0
00007f30a29d3e9b  pop r11
00007f30a29d3e9d  pop r10
00007f30a29d3e9f  pop r9
00007f30a29d3ea1  pop r8
00007f30a29d3ea3  pop rsi
00007f30a29d3ea4  pop rdi
00007f30a29d3ea5  pop rdx
00007f30a29d3ea6  pop rcx
00007f30a29d3ea7  pop rax
00007f30a29d3ea8  add rsp, 0x08
00007f30a29d3eac  jmp 0x00007F30A29D286A
00007f30a29d3eb1  sub rsp, 0x08
00007f30a29d3eb5  push rax
00007f30a29d3eb6  push rcx
00007f30a29d3eb7  push rdx
00007f30a29d3eb8  push rdi
00007f30a29d3eb9  push rsi
00007f30a29d3eba  push r8
00007f30a29d3ebc  push r9
00007f30a29d3ebe  push r10
00007f30a29d3ec0  push r11
00007f30a29d3ec2  sub rsp, 0xF0
00007f30a29d3ec9  vmovaps [rsp], xmm0
00007f30a29d3ece  vmovaps [rsp+0x10], xmm2
00007f30a29d3ed4  vmovaps [rsp+0x20], xmm3
00007f30a29d3eda  vmovaps [rsp+0x30], xmm4
00007f30a29d3ee0  vmovaps [rsp+0x40], xmm5
00007f30a29d3ee6  vmovaps [rsp+0x50], xmm6
00007f30a29d3eec  vmovaps [rsp+0x60], xmm7
00007f30a29d3ef2  vmovaps [rsp+0x70], xmm8
00007f30a29d3ef8  vmovaps [rsp+0x80], xmm9
00007f30a29d3f01  vmovaps [rsp+0x90], xmm10
00007f30a29d3f0a  vmovaps [rsp+0xA0], xmm11
00007f30a29d3f13  vmovaps [rsp+0xB0], xmm12
00007f30a29d3f1c  vmovaps [rsp+0xC0], xmm13
00007f30a29d3f25  vmovaps [rsp+0xD0], xmm14
00007f30a29d3f2e  vmovaps [rsp+0xE0], xmm15
00007f30a29d3f37  sub rsp, 0x30
00007f30a29d3f3b  movaps [rsp], xmm1
00007f30a29d3f3f  movaps [rsp+0x10], xmm10
00007f30a29d3f45  movaps [rsp+0x20], xmm2
00007f30a29d3f4a  lea rdi, [rsp]
00007f30a29d3f4e  mov esi, 0x00
00007f30a29d3f53  mov rax, 0x5FE955026530
00007f30a29d3f5d  call rax
00007f30a29d3f5f  movaps xmm1, [rsp]
00007f30a29d3f63  add rsp, 0x30
00007f30a29d3f67  vmovaps xmm0, [rsp]
00007f30a29d3f6c  vmovaps xmm2, [rsp+0x10]
00007f30a29d3f72  vmovaps xmm3, [rsp+0x20]
00007f30a29d3f78  vmovaps xmm4, [rsp+0x30]
00007f30a29d3f7e  vmovaps xmm5, [rsp+0x40]
00007f30a29d3f84  vmovaps xmm6, [rsp+0x50]
00007f30a29d3f8a  vmovaps xmm7, [rsp+0x60]
00007f30a29d3f90  vmovaps xmm8, [rsp+0x70]
00007f30a29d3f96  vmovaps xmm9, [rsp+0x80]
00007f30a29d3f9f  vmovaps xmm10, [rsp+0x90]
00007f30a29d3fa8  vmovaps xmm11, [rsp+0xA0]
00007f30a29d3fb1  vmovaps xmm12, [rsp+0xB0]
00007f30a29d3fba  vmovaps xmm13, [rsp+0xC0]
00007f30a29d3fc3  vmovaps xmm14, [rsp+0xD0]
00007f30a29d3fcc  vmovaps xmm15, [rsp+0xE0]
00007f30a29d3fd5  add rsp, 0xF0
00007f30a29d3fdc  pop r11
00007f30a29d3fde  pop r10
00007f30a29d3fe0  pop r9
00007f30a29d3fe2  pop r8
00007f30a29d3fe4  pop rsi
00007f30a29d3fe5  pop rdi
00007f30a29d3fe6  pop rdx
00007f30a29d3fe7  pop rcx
00007f30a29d3fe8  pop rax
00007f30a29d3fe9  add rsp, 0x08
00007f30a29d3fed  jmp 0x00007F30A29D28D2
00007f30a29d3ff2  sub rsp, 0x08
00007f30a29d3ff6  push rax
00007f30a29d3ff7  push rcx
00007f30a29d3ff8  push rdx
00007f30a29d3ff9  push rdi
00007f30a29d3ffa  push rsi
00007f30a29d3ffb  push r8
00007f30a29d3ffd  push r9
00007f30a29d3fff  push r10
00007f30a29d4001  push r11
00007f30a29d4003  sub rsp, 0xF0
00007f30a29d400a  vmovaps [rsp], xmm0
00007f30a29d400f  vmovaps [rsp+0x10], xmm1
00007f30a29d4015  vmovaps [rsp+0x20], xmm2
00007f30a29d401b  vmovaps [rsp+0x30], xmm3
00007f30a29d4021  vmovaps [rsp+0x40], xmm4
00007f30a29d4027  vmovaps [rsp+0x50], xmm5
00007f30a29d402d  vmovaps [rsp+0x60], xmm6
00007f30a29d4033  vmovaps [rsp+0x70], xmm7
00007f30a29d4039  vmovaps [rsp+0x80], xmm8
00007f30a29d4042  vmovaps [rsp+0x90], xmm9
00007f30a29d404b  vmovaps [rsp+0xA0], xmm10
00007f30a29d4054  vmovaps [rsp+0xB0], xmm11
00007f30a29d405d  vmovaps [rsp+0xC0], xmm12
00007f30a29d4066  vmovaps [rsp+0xD0], xmm13
00007f30a29d406f  vmovaps [rsp+0xE0], xmm14
00007f30a29d4078  sub rsp, 0x30
00007f30a29d407c  movaps [rsp], xmm15
00007f30a29d4081  movaps [rsp+0x10], xmm10
00007f30a29d4087  movaps [rsp+0x20], xmm2
00007f30a29d408c  lea rdi, [rsp]
00007f30a29d4090  mov esi, 0x00
00007f30a29d4095  mov rax, 0x5FE955026530
00007f30a29d409f  call rax
00007f30a29d40a1  movaps xmm15, [rsp]
00007f30a29d40a6  add rsp, 0x30
00007f30a29d40aa  vmovaps xmm0, [rsp]
00007f30a29d40af  vmovaps xmm1, [rsp+0x10]
00007f30a29d40b5  vmovaps xmm2, [rsp+0x20]
00007f30a29d40bb  vmovaps xmm3, [rsp+0x30]
00007f30a29d40c1  vmovaps xmm4, [rsp+0x40]
00007f30a29d40c7  vmovaps xmm5, [rsp+0x50]
00007f30a29d40cd  vmovaps xmm6, [rsp+0x60]
00007f30a29d40d3  vmovaps xmm7, [rsp+0x70]
00007f30a29d40d9  vmovaps xmm8, [rsp+0x80]
00007f30a29d40e2  vmovaps xmm9, [rsp+0x90]
00007f30a29d40eb  vmovaps xmm10, [rsp+0xA0]
00007f30a29d40f4  vmovaps xmm11, [rsp+0xB0]
00007f30a29d40fd  vmovaps xmm12, [rsp+0xC0]
00007f30a29d4106  vmovaps xmm13, [rsp+0xD0]
00007f30a29d410f  vmovaps xmm14, [rsp+0xE0]
00007f30a29d4118  add rsp, 0xF0
00007f30a29d411f  pop r11
00007f30a29d4121  pop r10
00007f30a29d4123  pop r9
00007f30a29d4125  pop r8
00007f30a29d4127  pop rsi
00007f30a29d4128  pop rdi
00007f30a29d4129  pop rdx
00007f30a29d412a  pop rcx
00007f30a29d412b  pop rax
00007f30a29d412c  add rsp, 0x08
00007f30a29d4130  jmp 0x00007F30A29D2924
00007f30a29d4135  sub rsp, 0x08
00007f30a29d4139  push rax
00007f30a29d413a  push rcx
00007f30a29d413b  push rdx
00007f30a29d413c  push rdi
00007f30a29d413d  push rsi
00007f30a29d413e  push r8
00007f30a29d4140  push r9
00007f30a29d4142  push r10
00007f30a29d4144  push r11
00007f30a29d4146  sub rsp, 0xF0
00007f30a29d414d  vmovaps [rsp], xmm0
00007f30a29d4152  vmovaps [rsp+0x10], xmm2
00007f30a29d4158  vmovaps [rsp+0x20], xmm3
00007f30a29d415e  vmovaps [rsp+0x30], xmm4
00007f30a29d4164  vmovaps [rsp+0x40], xmm5
00007f30a29d416a  vmovaps [rsp+0x50], xmm6
00007f30a29d4170  vmovaps [rsp+0x60], xmm7
00007f30a29d4176  vmovaps [rsp+0x70], xmm8
00007f30a29d417c  vmovaps [rsp+0x80], xmm9
00007f30a29d4185  vmovaps [rsp+0x90], xmm10
00007f30a29d418e  vmovaps [rsp+0xA0], xmm11
00007f30a29d4197  vmovaps [rsp+0xB0], xmm12
00007f30a29d41a0  vmovaps [rsp+0xC0], xmm13
00007f30a29d41a9  vmovaps [rsp+0xD0], xmm14
00007f30a29d41b2  vmovaps [rsp+0xE0], xmm15
00007f30a29d41bb  sub rsp, 0x30
00007f30a29d41bf  movaps [rsp], xmm1
00007f30a29d41c3  movaps [rsp+0x10], xmm10
00007f30a29d41c9  movaps [rsp+0x20], xmm15
00007f30a29d41cf  lea rdi, [rsp]
00007f30a29d41d3  mov esi, 0x00
00007f30a29d41d8  mov rax, 0x5FE955026530
00007f30a29d41e2  call rax
00007f30a29d41e4  movaps xmm1, [rsp]
00007f30a29d41e8  add rsp, 0x30
00007f30a29d41ec  vmovaps xmm0, [rsp]
00007f30a29d41f1  vmovaps xmm2, [rsp+0x10]
00007f30a29d41f7  vmovaps xmm3, [rsp+0x20]
00007f30a29d41fd  vmovaps xmm4, [rsp+0x30]
00007f30a29d4203  vmovaps xmm5, [rsp+0x40]
00007f30a29d4209  vmovaps xmm6, [rsp+0x50]
00007f30a29d420f  vmovaps xmm7, [rsp+0x60]
00007f30a29d4215  vmovaps xmm8, [rsp+0x70]
00007f30a29d421b  vmovaps xmm9, [rsp+0x80]
00007f30a29d4224  vmovaps xmm10, [rsp+0x90]
00007f30a29d422d  vmovaps xmm11, [rsp+0xA0]
00007f30a29d4236  vmovaps xmm12, [rsp+0xB0]
00007f30a29d423f  vmovaps xmm13, [rsp+0xC0]
00007f30a29d4248  vmovaps xmm14, [rsp+0xD0]
00007f30a29d4251  vmovaps xmm15, [rsp+0xE0]
00007f30a29d425a  add rsp, 0xF0
00007f30a29d4261  pop r11
00007f30a29d4263  pop r10
00007f30a29d4265  pop r9
00007f30a29d4267  pop r8
00007f30a29d4269  pop rsi
00007f30a29d426a  pop rdi
00007f30a29d426b  pop rdx
00007f30a29d426c  pop rcx
00007f30a29d426d  pop rax
00007f30a29d426e  add rsp, 0x08
00007f30a29d4272  jmp 0x00007F30A29D2962
00007f30a29d4277  sub rsp, 0x08
00007f30a29d427b  push rax
00007f30a29d427c  push rcx
00007f30a29d427d  push rdx
00007f30a29d427e  push rdi
00007f30a29d427f  push rsi
00007f30a29d4280  push r8
00007f30a29d4282  push r9
00007f30a29d4284  push r10
00007f30a29d4286  push r11
00007f30a29d4288  sub rsp, 0xF0
00007f30a29d428f  vmovaps [rsp], xmm0
00007f30a29d4294  vmovaps [rsp+0x10], xmm1
00007f30a29d429a  vmovaps [rsp+0x20], xmm2
00007f30a29d42a0  vmovaps [rsp+0x30], xmm3
00007f30a29d42a6  vmovaps [rsp+0x40], xmm4
00007f30a29d42ac  vmovaps [rsp+0x50], xmm5
00007f30a29d42b2  vmovaps [rsp+0x60], xmm6
00007f30a29d42b8  vmovaps [rsp+0x70], xmm7
00007f30a29d42be  vmovaps [rsp+0x80], xmm8
00007f30a29d42c7  vmovaps [rsp+0x90], xmm9
00007f30a29d42d0  vmovaps [rsp+0xA0], xmm10
00007f30a29d42d9  vmovaps [rsp+0xB0], xmm11
00007f30a29d42e2  vmovaps [rsp+0xC0], xmm12
00007f30a29d42eb  vmovaps [rsp+0xD0], xmm13
00007f30a29d42f4  vmovaps [rsp+0xE0], xmm15
00007f30a29d42fd  sub rsp, 0x30
00007f30a29d4301  movaps [rsp], xmm14
00007f30a29d4306  movaps [rsp+0x10], xmm10
00007f30a29d430c  movaps [rsp+0x20], xmm15
00007f30a29d4312  lea rdi, [rsp]
00007f30a29d4316  mov esi, 0x00
00007f30a29d431b  mov rax, 0x5FE955026530
00007f30a29d4325  call rax
00007f30a29d4327  movaps xmm14, [rsp]
00007f30a29d432c  add rsp, 0x30
00007f30a29d4330  vmovaps xmm0, [rsp]
00007f30a29d4335  vmovaps xmm1, [rsp+0x10]
00007f30a29d433b  vmovaps xmm2, [rsp+0x20]
00007f30a29d4341  vmovaps xmm3, [rsp+0x30]
00007f30a29d4347  vmovaps xmm4, [rsp+0x40]
00007f30a29d434d  vmovaps xmm5, [rsp+0x50]
00007f30a29d4353  vmovaps xmm6, [rsp+0x60]
00007f30a29d4359  vmovaps xmm7, [rsp+0x70]
00007f30a29d435f  vmovaps xmm8, [rsp+0x80]
00007f30a29d4368  vmovaps xmm9, [rsp+0x90]
00007f30a29d4371  vmovaps xmm10, [rsp+0xA0]
00007f30a29d437a  vmovaps xmm11, [rsp+0xB0]
00007f30a29d4383  vmovaps xmm12, [rsp+0xC0]
00007f30a29d438c  vmovaps xmm13, [rsp+0xD0]
00007f30a29d4395  vmovaps xmm15, [rsp+0xE0]
00007f30a29d439e  add rsp, 0xF0
00007f30a29d43a5  pop r11
00007f30a29d43a7  pop r10
00007f30a29d43a9  pop r9
00007f30a29d43ab  pop r8
00007f30a29d43ad  pop rsi
00007f30a29d43ae  pop rdi
00007f30a29d43af  pop rdx
00007f30a29d43b0  pop rcx
00007f30a29d43b1  pop rax
00007f30a29d43b2  add rsp, 0x08
00007f30a29d43b6  jmp 0x00007F30A29D298E
00007f30a29d43bb  call 0x00007F30A27FF430
00007f30a29d43c0  jmp 0x00007F30A29D2A1E
00007f30a29d43c5  call 0x00007F30A27FF430
00007f30a29d43ca  jmp 0x00007F30A29D2A31
00007f30a29d43cf  sub rsp, 0x08
00007f30a29d43d3  push rax
00007f30a29d43d4  push rcx
00007f30a29d43d5  push rdx
00007f30a29d43d6  push rdi
00007f30a29d43d7  push rsi
00007f30a29d43d8  push r8
00007f30a29d43da  push r9
00007f30a29d43dc  push r10
00007f30a29d43de  push r11
00007f30a29d43e0  sub rsp, 0xF0
00007f30a29d43e7  vmovaps [rsp], xmm0
00007f30a29d43ec  vmovaps [rsp+0x10], xmm2
00007f30a29d43f2  vmovaps [rsp+0x20], xmm3
00007f30a29d43f8  vmovaps [rsp+0x30], xmm4
00007f30a29d43fe  vmovaps [rsp+0x40], xmm5
00007f30a29d4404  vmovaps [rsp+0x50], xmm6
00007f30a29d440a  vmovaps [rsp+0x60], xmm7
00007f30a29d4410  vmovaps [rsp+0x70], xmm8
00007f30a29d4416  vmovaps [rsp+0x80], xmm9
00007f30a29d441f  vmovaps [rsp+0x90], xmm10
00007f30a29d4428  vmovaps [rsp+0xA0], xmm11
00007f30a29d4431  vmovaps [rsp+0xB0], xmm12
00007f30a29d443a  vmovaps [rsp+0xC0], xmm13
00007f30a29d4443  vmovaps [rsp+0xD0], xmm14
00007f30a29d444c  vmovaps [rsp+0xE0], xmm15
00007f30a29d4455  sub rsp, 0x30
00007f30a29d4459  movaps [rsp], xmm1
00007f30a29d445d  movaps [rsp+0x10], xmm13
00007f30a29d4463  movaps [rsp+0x20], xmm2
00007f30a29d4468  lea rdi, [rsp]
00007f30a29d446c  mov esi, 0x00
00007f30a29d4471  mov rax, 0x5FE955026530
00007f30a29d447b  call rax
00007f30a29d447d  movaps xmm1, [rsp]
00007f30a29d4481  add rsp, 0x30
00007f30a29d4485  vmovaps xmm0, [rsp]
00007f30a29d448a  vmovaps xmm2, [rsp+0x10]
00007f30a29d4490  vmovaps xmm3, [rsp+0x20]
00007f30a29d4496  vmovaps xmm4, [rsp+0x30]
00007f30a29d449c  vmovaps xmm5, [rsp+0x40]
00007f30a29d44a2  vmovaps xmm6, [rsp+0x50]
00007f30a29d44a8  vmovaps xmm7, [rsp+0x60]
00007f30a29d44ae  vmovaps xmm8, [rsp+0x70]
00007f30a29d44b4  vmovaps xmm9, [rsp+0x80]
00007f30a29d44bd  vmovaps xmm10, [rsp+0x90]
00007f30a29d44c6  vmovaps xmm11, [rsp+0xA0]
00007f30a29d44cf  vmovaps xmm12, [rsp+0xB0]
00007f30a29d44d8  vmovaps xmm13, [rsp+0xC0]
00007f30a29d44e1  vmovaps xmm14, [rsp+0xD0]
00007f30a29d44ea  vmovaps xmm15, [rsp+0xE0]
00007f30a29d44f3  add rsp, 0xF0
00007f30a29d44fa  pop r11
00007f30a29d44fc  pop r10
00007f30a29d44fe  pop r9
00007f30a29d4500  pop r8
00007f30a29d4502  pop rsi
00007f30a29d4503  pop rdi
00007f30a29d4504  pop rdx
00007f30a29d4505  pop rcx
00007f30a29d4506  pop rax
00007f30a29d4507  add rsp, 0x08
00007f30a29d450b  jmp 0x00007F30A29D2A5C
00007f30a29d4510  call 0x00007F30A280E760
00007f30a29d4515  jmp 0x00007F30A29D2A69
00007f30a29d451a  sub rsp, 0x08
00007f30a29d451e  push rax
00007f30a29d451f  push rcx
00007f30a29d4520  push rdx
00007f30a29d4521  push rdi
00007f30a29d4522  push rsi
00007f30a29d4523  push r8
00007f30a29d4525  push r9
00007f30a29d4527  push r10
00007f30a29d4529  push r11
00007f30a29d452b  sub rsp, 0xF0
00007f30a29d4532  vmovaps [rsp], xmm0
00007f30a29d4537  vmovaps [rsp+0x10], xmm1
00007f30a29d453d  vmovaps [rsp+0x20], xmm2
00007f30a29d4543  vmovaps [rsp+0x30], xmm3
00007f30a29d4549  vmovaps [rsp+0x40], xmm4
00007f30a29d454f  vmovaps [rsp+0x50], xmm5
00007f30a29d4555  vmovaps [rsp+0x60], xmm6
00007f30a29d455b  vmovaps [rsp+0x70], xmm7
00007f30a29d4561  vmovaps [rsp+0x80], xmm8
00007f30a29d456a  vmovaps [rsp+0x90], xmm9
00007f30a29d4573  vmovaps [rsp+0xA0], xmm10
00007f30a29d457c  vmovaps [rsp+0xB0], xmm11
00007f30a29d4585  vmovaps [rsp+0xC0], xmm12
00007f30a29d458e  vmovaps [rsp+0xD0], xmm14
00007f30a29d4597  vmovaps [rsp+0xE0], xmm15
00007f30a29d45a0  sub rsp, 0x30
00007f30a29d45a4  movaps [rsp], xmm13
00007f30a29d45a9  movaps [rsp+0x10], xmm2
00007f30a29d45ae  movaps [rsp+0x20], xmm1
00007f30a29d45b3  lea rdi, [rsp]
00007f30a29d45b7  mov esi, 0x00
00007f30a29d45bc  mov rax, 0x5FE955026530
00007f30a29d45c6  call rax
00007f30a29d45c8  movaps xmm13, [rsp]
00007f30a29d45cd  add rsp, 0x30
00007f30a29d45d1  vmovaps xmm0, [rsp]
00007f30a29d45d6  vmovaps xmm1, [rsp+0x10]
00007f30a29d45dc  vmovaps xmm2, [rsp+0x20]
00007f30a29d45e2  vmovaps xmm3, [rsp+0x30]
00007f30a29d45e8  vmovaps xmm4, [rsp+0x40]
00007f30a29d45ee  vmovaps xmm5, [rsp+0x50]
00007f30a29d45f4  vmovaps xmm6, [rsp+0x60]
00007f30a29d45fa  vmovaps xmm7, [rsp+0x70]
00007f30a29d4600  vmovaps xmm8, [rsp+0x80]
00007f30a29d4609  vmovaps xmm9, [rsp+0x90]
00007f30a29d4612  vmovaps xmm10, [rsp+0xA0]
00007f30a29d461b  vmovaps xmm11, [rsp+0xB0]
00007f30a29d4624  vmovaps xmm12, [rsp+0xC0]
00007f30a29d462d  vmovaps xmm14, [rsp+0xD0]
00007f30a29d4636  vmovaps xmm15, [rsp+0xE0]
00007f30a29d463f  add rsp, 0xF0
00007f30a29d4646  pop r11
00007f30a29d4648  pop r10
00007f30a29d464a  pop r9
00007f30a29d464c  pop r8
00007f30a29d464e  pop rsi
00007f30a29d464f  pop rdi
00007f30a29d4650  pop rdx
00007f30a29d4651  pop rcx
00007f30a29d4652  pop rax
00007f30a29d4653  add rsp, 0x08
00007f30a29d4657  jmp 0x00007F30A29D2AA8
00007f30a29d465c  sub rsp, 0x08
00007f30a29d4660  push rax
00007f30a29d4661  push rcx
00007f30a29d4662  push rdx
00007f30a29d4663  push rdi
00007f30a29d4664  push rsi
00007f30a29d4665  push r8
00007f30a29d4667  push r9
00007f30a29d4669  push r10
00007f30a29d466b  push r11
00007f30a29d466d  sub rsp, 0xF0
00007f30a29d4674  vmovaps [rsp], xmm0
00007f30a29d4679  vmovaps [rsp+0x10], xmm2
00007f30a29d467f  vmovaps [rsp+0x20], xmm3
00007f30a29d4685  vmovaps [rsp+0x30], xmm4
00007f30a29d468b  vmovaps [rsp+0x40], xmm5
00007f30a29d4691  vmovaps [rsp+0x50], xmm6
00007f30a29d4697  vmovaps [rsp+0x60], xmm7
00007f30a29d469d  vmovaps [rsp+0x70], xmm8
00007f30a29d46a3  vmovaps [rsp+0x80], xmm9
00007f30a29d46ac  vmovaps [rsp+0x90], xmm10
00007f30a29d46b5  vmovaps [rsp+0xA0], xmm11
00007f30a29d46be  vmovaps [rsp+0xB0], xmm12
00007f30a29d46c7  vmovaps [rsp+0xC0], xmm13
00007f30a29d46d0  vmovaps [rsp+0xD0], xmm14
00007f30a29d46d9  vmovaps [rsp+0xE0], xmm15
00007f30a29d46e2  sub rsp, 0x30
00007f30a29d46e6  movaps [rsp], xmm1
00007f30a29d46ea  movaps [rsp+0x10], xmm14
00007f30a29d46f0  movaps [rsp+0x20], xmm15
00007f30a29d46f6  lea rdi, [rsp]
00007f30a29d46fa  mov esi, 0x00
00007f30a29d46ff  mov rax, 0x5FE955026530
00007f30a29d4709  call rax
00007f30a29d470b  movaps xmm1, [rsp]
00007f30a29d470f  add rsp, 0x30
00007f30a29d4713  vmovaps xmm0, [rsp]
00007f30a29d4718  vmovaps xmm2, [rsp+0x10]
00007f30a29d471e  vmovaps xmm3, [rsp+0x20]
00007f30a29d4724  vmovaps xmm4, [rsp+0x30]
00007f30a29d472a  vmovaps xmm5, [rsp+0x40]
00007f30a29d4730  vmovaps xmm6, [rsp+0x50]
00007f30a29d4736  vmovaps xmm7, [rsp+0x60]
00007f30a29d473c  vmovaps xmm8, [rsp+0x70]
00007f30a29d4742  vmovaps xmm9, [rsp+0x80]
00007f30a29d474b  vmovaps xmm10, [rsp+0x90]
00007f30a29d4754  vmovaps xmm11, [rsp+0xA0]
00007f30a29d475d  vmovaps xmm12, [rsp+0xB0]
00007f30a29d4766  vmovaps xmm13, [rsp+0xC0]
00007f30a29d476f  vmovaps xmm14, [rsp+0xD0]
00007f30a29d4778  vmovaps xmm15, [rsp+0xE0]
00007f30a29d4781  add rsp, 0xF0
00007f30a29d4788  pop r11
00007f30a29d478a  pop r10
00007f30a29d478c  pop r9
00007f30a29d478e  pop r8
00007f30a29d4790  pop rsi
00007f30a29d4791  pop rdi
00007f30a29d4792  pop rdx
00007f30a29d4793  pop rcx
00007f30a29d4794  pop rax
00007f30a29d4795  add rsp, 0x08
00007f30a29d4799  jmp 0x00007F30A29D2ACA
00007f30a29d479e  sub rsp, 0x08
00007f30a29d47a2  push rax
00007f30a29d47a3  push rcx
00007f30a29d47a4  push rdx
00007f30a29d47a5  push rdi
00007f30a29d47a6  push rsi
00007f30a29d47a7  push r8
00007f30a29d47a9  push r9
00007f30a29d47ab  push r10
00007f30a29d47ad  push r11
00007f30a29d47af  sub rsp, 0xF0
00007f30a29d47b6  vmovaps [rsp], xmm0
00007f30a29d47bb  vmovaps [rsp+0x10], xmm1
00007f30a29d47c1  vmovaps [rsp+0x20], xmm2
00007f30a29d47c7  vmovaps [rsp+0x30], xmm3
00007f30a29d47cd  vmovaps [rsp+0x40], xmm4
00007f30a29d47d3  vmovaps [rsp+0x50], xmm5
00007f30a29d47d9  vmovaps [rsp+0x60], xmm6
00007f30a29d47df  vmovaps [rsp+0x70], xmm7
00007f30a29d47e5  vmovaps [rsp+0x80], xmm8
00007f30a29d47ee  vmovaps [rsp+0x90], xmm9
00007f30a29d47f7  vmovaps [rsp+0xA0], xmm10
00007f30a29d4800  vmovaps [rsp+0xB0], xmm11
00007f30a29d4809  vmovaps [rsp+0xC0], xmm12
00007f30a29d4812  vmovaps [rsp+0xD0], xmm13
00007f30a29d481b  vmovaps [rsp+0xE0], xmm15
00007f30a29d4824  sub rsp, 0x30
00007f30a29d4828  movaps [rsp], xmm14
00007f30a29d482d  movaps [rsp+0x10], xmm2
00007f30a29d4832  movaps [rsp+0x20], xmm15
00007f30a29d4838  lea rdi, [rsp]
00007f30a29d483c  mov esi, 0x00
00007f30a29d4841  mov rax, 0x5FE955026530
00007f30a29d484b  call rax
00007f30a29d484d  movaps xmm14, [rsp]
00007f30a29d4852  add rsp, 0x30
00007f30a29d4856  vmovaps xmm0, [rsp]
00007f30a29d485b  vmovaps xmm1, [rsp+0x10]
00007f30a29d4861  vmovaps xmm2, [rsp+0x20]
00007f30a29d4867  vmovaps xmm3, [rsp+0x30]
00007f30a29d486d  vmovaps xmm4, [rsp+0x40]
00007f30a29d4873  vmovaps xmm5, [rsp+0x50]
00007f30a29d4879  vmovaps xmm6, [rsp+0x60]
00007f30a29d487f  vmovaps xmm7, [rsp+0x70]
00007f30a29d4885  vmovaps xmm8, [rsp+0x80]
00007f30a29d488e  vmovaps xmm9, [rsp+0x90]
00007f30a29d4897  vmovaps xmm10, [rsp+0xA0]
00007f30a29d48a0  vmovaps xmm11, [rsp+0xB0]
00007f30a29d48a9  vmovaps xmm12, [rsp+0xC0]
00007f30a29d48b2  vmovaps xmm13, [rsp+0xD0]
00007f30a29d48bb  vmovaps xmm15, [rsp+0xE0]
00007f30a29d48c4  add rsp, 0xF0
00007f30a29d48cb  pop r11
00007f30a29d48cd  pop r10
00007f30a29d48cf  pop r9
00007f30a29d48d1  pop r8
00007f30a29d48d3  pop rsi
00007f30a29d48d4  pop rdi
00007f30a29d48d5  pop rdx
00007f30a29d48d6  pop rcx
00007f30a29d48d7  pop rax
00007f30a29d48d8  add rsp, 0x08
00007f30a29d48dc  jmp 0x00007F30A29D2B05
00007f30a29d48e1  sub rsp, 0x08
00007f30a29d48e5  push rax
00007f30a29d48e6  push rcx
00007f30a29d48e7  push rdx
00007f30a29d48e8  push rdi
00007f30a29d48e9  push rsi
00007f30a29d48ea  push r8
00007f30a29d48ec  push r9
00007f30a29d48ee  push r10
00007f30a29d48f0  push r11
00007f30a29d48f2  sub rsp, 0xF0
00007f30a29d48f9  vmovaps [rsp], xmm0
00007f30a29d48fe  vmovaps [rsp+0x10], xmm1
00007f30a29d4904  vmovaps [rsp+0x20], xmm2
00007f30a29d490a  vmovaps [rsp+0x30], xmm3
00007f30a29d4910  vmovaps [rsp+0x40], xmm4
00007f30a29d4916  vmovaps [rsp+0x50], xmm5
00007f30a29d491c  vmovaps [rsp+0x60], xmm6
00007f30a29d4922  vmovaps [rsp+0x70], xmm7
00007f30a29d4928  vmovaps [rsp+0x80], xmm8
00007f30a29d4931  vmovaps [rsp+0x90], xmm9
00007f30a29d493a  vmovaps [rsp+0xA0], xmm10
00007f30a29d4943  vmovaps [rsp+0xB0], xmm11
00007f30a29d494c  vmovaps [rsp+0xC0], xmm12
00007f30a29d4955  vmovaps [rsp+0xD0], xmm13
00007f30a29d495e  vmovaps [rsp+0xE0], xmm14
00007f30a29d4967  sub rsp, 0x30
00007f30a29d496b  movaps [rsp], xmm15
00007f30a29d4970  movaps [rsp+0x10], xmm2
00007f30a29d4975  movaps [rsp+0x20], xmm1
00007f30a29d497a  lea rdi, [rsp]
00007f30a29d497e  mov esi, 0x00
00007f30a29d4983  mov rax, 0x5FE955026530
00007f30a29d498d  call rax
00007f30a29d498f  movaps xmm15, [rsp]
00007f30a29d4994  add rsp, 0x30
00007f30a29d4998  vmovaps xmm0, [rsp]
00007f30a29d499d  vmovaps xmm1, [rsp+0x10]
00007f30a29d49a3  vmovaps xmm2, [rsp+0x20]
00007f30a29d49a9  vmovaps xmm3, [rsp+0x30]
00007f30a29d49af  vmovaps xmm4, [rsp+0x40]
00007f30a29d49b5  vmovaps xmm5, [rsp+0x50]
00007f30a29d49bb  vmovaps xmm6, [rsp+0x60]
00007f30a29d49c1  vmovaps xmm7, [rsp+0x70]
00007f30a29d49c7  vmovaps xmm8, [rsp+0x80]
00007f30a29d49d0  vmovaps xmm9, [rsp+0x90]
00007f30a29d49d9  vmovaps xmm10, [rsp+0xA0]
00007f30a29d49e2  vmovaps xmm11, [rsp+0xB0]
00007f30a29d49eb  vmovaps xmm12, [rsp+0xC0]
00007f30a29d49f4  vmovaps xmm13, [rsp+0xD0]
00007f30a29d49fd  vmovaps xmm14, [rsp+0xE0]
00007f30a29d4a06  add rsp, 0xF0
00007f30a29d4a0d  pop r11
00007f30a29d4a0f  pop r10
00007f30a29d4a11  pop r9
00007f30a29d4a13  pop r8
00007f30a29d4a15  pop rsi
00007f30a29d4a16  pop rdi
00007f30a29d4a17  pop rdx
00007f30a29d4a18  pop rcx
00007f30a29d4a19  pop rax
00007f30a29d4a1a  add rsp, 0x08
00007f30a29d4a1e  jmp 0x00007F30A29D2B41
00007f30a29d4a23  call 0x00007F30A27FF430
00007f30a29d4a28  jmp 0x00007F30A29D2B4E
00007f30a29d4a2d  sub rsp, 0x08
00007f30a29d4a31  push rax
00007f30a29d4a32  push rcx
00007f30a29d4a33  push rdx
00007f30a29d4a34  push rdi
00007f30a29d4a35  push rsi
00007f30a29d4a36  push r8
00007f30a29d4a38  push r9
00007f30a29d4a3a  push r10
00007f30a29d4a3c  push r11
00007f30a29d4a3e  sub rsp, 0xF0
00007f30a29d4a45  vmovaps [rsp], xmm0
00007f30a29d4a4a  vmovaps [rsp+0x10], xmm1
00007f30a29d4a50  vmovaps [rsp+0x20], xmm3
00007f30a29d4a56  vmovaps [rsp+0x30], xmm4
00007f30a29d4a5c  vmovaps [rsp+0x40], xmm5
00007f30a29d4a62  vmovaps [rsp+0x50], xmm6
00007f30a29d4a68  vmovaps [rsp+0x60], xmm7
00007f30a29d4a6e  vmovaps [rsp+0x70], xmm8
00007f30a29d4a74  vmovaps [rsp+0x80], xmm9
00007f30a29d4a7d  vmovaps [rsp+0x90], xmm10
00007f30a29d4a86  vmovaps [rsp+0xA0], xmm11
00007f30a29d4a8f  vmovaps [rsp+0xB0], xmm12
00007f30a29d4a98  vmovaps [rsp+0xC0], xmm13
00007f30a29d4aa1  vmovaps [rsp+0xD0], xmm14
00007f30a29d4aaa  vmovaps [rsp+0xE0], xmm15
00007f30a29d4ab3  sub rsp, 0x30
00007f30a29d4ab7  movaps [rsp], xmm2
00007f30a29d4abb  movaps [rsp+0x10], xmm1
00007f30a29d4ac0  movaps [rsp+0x20], xmm14
00007f30a29d4ac6  lea rdi, [rsp]
00007f30a29d4aca  mov esi, 0x00
00007f30a29d4acf  mov rax, 0x5FE955026530
00007f30a29d4ad9  call rax
00007f30a29d4adb  movaps xmm2, [rsp]
00007f30a29d4adf  add rsp, 0x30
00007f30a29d4ae3  vmovaps xmm0, [rsp]
00007f30a29d4ae8  vmovaps xmm1, [rsp+0x10]
00007f30a29d4aee  vmovaps xmm3, [rsp+0x20]
00007f30a29d4af4  vmovaps xmm4, [rsp+0x30]
00007f30a29d4afa  vmovaps xmm5, [rsp+0x40]
00007f30a29d4b00  vmovaps xmm6, [rsp+0x50]
00007f30a29d4b06  vmovaps xmm7, [rsp+0x60]
00007f30a29d4b0c  vmovaps xmm8, [rsp+0x70]
00007f30a29d4b12  vmovaps xmm9, [rsp+0x80]
00007f30a29d4b1b  vmovaps xmm10, [rsp+0x90]
00007f30a29d4b24  vmovaps xmm11, [rsp+0xA0]
00007f30a29d4b2d  vmovaps xmm12, [rsp+0xB0]
00007f30a29d4b36  vmovaps xmm13, [rsp+0xC0]
00007f30a29d4b3f  vmovaps xmm14, [rsp+0xD0]
00007f30a29d4b48  vmovaps xmm15, [rsp+0xE0]
00007f30a29d4b51  add rsp, 0xF0
00007f30a29d4b58  pop r11
00007f30a29d4b5a  pop r10
00007f30a29d4b5c  pop r9
00007f30a29d4b5e  pop r8
00007f30a29d4b60  pop rsi
00007f30a29d4b61  pop rdi
00007f30a29d4b62  pop rdx
00007f30a29d4b63  pop rcx
00007f30a29d4b64  pop rax
00007f30a29d4b65  add rsp, 0x08
00007f30a29d4b69  jmp 0x00007F30A29D2B8B
00007f30a29d4b6e  sub rsp, 0x08
00007f30a29d4b72  push rax
00007f30a29d4b73  push rcx
00007f30a29d4b74  push rdx
00007f30a29d4b75  push rdi
00007f30a29d4b76  push rsi
00007f30a29d4b77  push r8
00007f30a29d4b79  push r9
00007f30a29d4b7b  push r10
00007f30a29d4b7d  push r11
00007f30a29d4b7f  sub rsp, 0xF0
00007f30a29d4b86  vmovaps [rsp], xmm0
00007f30a29d4b8b  vmovaps [rsp+0x10], xmm1
00007f30a29d4b91  vmovaps [rsp+0x20], xmm2
00007f30a29d4b97  vmovaps [rsp+0x30], xmm3
00007f30a29d4b9d  vmovaps [rsp+0x40], xmm4
00007f30a29d4ba3  vmovaps [rsp+0x50], xmm5
00007f30a29d4ba9  vmovaps [rsp+0x60], xmm6
00007f30a29d4baf  vmovaps [rsp+0x70], xmm7
00007f30a29d4bb5  vmovaps [rsp+0x80], xmm8
00007f30a29d4bbe  vmovaps [rsp+0x90], xmm9
00007f30a29d4bc7  vmovaps [rsp+0xA0], xmm10
00007f30a29d4bd0  vmovaps [rsp+0xB0], xmm11
00007f30a29d4bd9  vmovaps [rsp+0xC0], xmm12
00007f30a29d4be2  vmovaps [rsp+0xD0], xmm13
00007f30a29d4beb  vmovaps [rsp+0xE0], xmm14
00007f30a29d4bf4  sub rsp, 0x30
00007f30a29d4bf8  movaps [rsp], xmm15
00007f30a29d4bfd  movaps [rsp+0x10], xmm14
00007f30a29d4c03  movaps [rsp+0x20], xmm1
00007f30a29d4c08  lea rdi, [rsp]
00007f30a29d4c0c  mov esi, 0x00
00007f30a29d4c11  mov rax, 0x5FE955026530
00007f30a29d4c1b  call rax
00007f30a29d4c1d  movaps xmm15, [rsp]
00007f30a29d4c22  add rsp, 0x30
00007f30a29d4c26  vmovaps xmm0, [rsp]
00007f30a29d4c2b  vmovaps xmm1, [rsp+0x10]
00007f30a29d4c31  vmovaps xmm2, [rsp+0x20]
00007f30a29d4c37  vmovaps xmm3, [rsp+0x30]
00007f30a29d4c3d  vmovaps xmm4, [rsp+0x40]
00007f30a29d4c43  vmovaps xmm5, [rsp+0x50]
00007f30a29d4c49  vmovaps xmm6, [rsp+0x60]
00007f30a29d4c4f  vmovaps xmm7, [rsp+0x70]
00007f30a29d4c55  vmovaps xmm8, [rsp+0x80]
00007f30a29d4c5e  vmovaps xmm9, [rsp+0x90]
00007f30a29d4c67  vmovaps xmm10, [rsp+0xA0]
00007f30a29d4c70  vmovaps xmm11, [rsp+0xB0]
00007f30a29d4c79  vmovaps xmm12, [rsp+0xC0]
00007f30a29d4c82  vmovaps xmm13, [rsp+0xD0]
00007f30a29d4c8b  vmovaps xmm14, [rsp+0xE0]
00007f30a29d4c94  add rsp, 0xF0
00007f30a29d4c9b  pop r11
00007f30a29d4c9d  pop r10
00007f30a29d4c9f  pop r9
00007f30a29d4ca1  pop r8
00007f30a29d4ca3  pop rsi
00007f30a29d4ca4  pop rdi
00007f30a29d4ca5  pop rdx
00007f30a29d4ca6  pop rcx
00007f30a29d4ca7  pop rax
00007f30a29d4ca8  add rsp, 0x08
00007f30a29d4cac  jmp 0x00007F30A29D2C05
00007f30a29d4cb1  call 0x00007F30A27FF430
00007f30a29d4cb6  jmp 0x00007F30A29D2C12
00007f30a29d4cbb  sub rsp, 0x08
00007f30a29d4cbf  push rax
00007f30a29d4cc0  push rcx
00007f30a29d4cc1  push rdx
00007f30a29d4cc2  push rdi
00007f30a29d4cc3  push rsi
00007f30a29d4cc4  push r8
00007f30a29d4cc6  push r9
00007f30a29d4cc8  push r10
00007f30a29d4cca  push r11
00007f30a29d4ccc  sub rsp, 0xF0
00007f30a29d4cd3  vmovaps [rsp], xmm0
00007f30a29d4cd8  vmovaps [rsp+0x10], xmm1
00007f30a29d4cde  vmovaps [rsp+0x20], xmm2
00007f30a29d4ce4  vmovaps [rsp+0x30], xmm3
00007f30a29d4cea  vmovaps [rsp+0x40], xmm4
00007f30a29d4cf0  vmovaps [rsp+0x50], xmm5
00007f30a29d4cf6  vmovaps [rsp+0x60], xmm6
00007f30a29d4cfc  vmovaps [rsp+0x70], xmm7
00007f30a29d4d02  vmovaps [rsp+0x80], xmm8
00007f30a29d4d0b  vmovaps [rsp+0x90], xmm9
00007f30a29d4d14  vmovaps [rsp+0xA0], xmm10
00007f30a29d4d1d  vmovaps [rsp+0xB0], xmm11
00007f30a29d4d26  vmovaps [rsp+0xC0], xmm12
00007f30a29d4d2f  vmovaps [rsp+0xD0], xmm14
00007f30a29d4d38  vmovaps [rsp+0xE0], xmm15
00007f30a29d4d41  sub rsp, 0x30
00007f30a29d4d45  movaps [rsp], xmm13
00007f30a29d4d4a  movaps [rsp+0x10], xmm1
00007f30a29d4d4f  movaps [rsp+0x20], xmm15
00007f30a29d4d55  lea rdi, [rsp]
00007f30a29d4d59  mov esi, 0x00
00007f30a29d4d5e  mov rax, 0x5FE955026530
00007f30a29d4d68  call rax
00007f30a29d4d6a  movaps xmm13, [rsp]
00007f30a29d4d6f  add rsp, 0x30
00007f30a29d4d73  vmovaps xmm0, [rsp]
00007f30a29d4d78  vmovaps xmm1, [rsp+0x10]
00007f30a29d4d7e  vmovaps xmm2, [rsp+0x20]
00007f30a29d4d84  vmovaps xmm3, [rsp+0x30]
00007f30a29d4d8a  vmovaps xmm4, [rsp+0x40]
00007f30a29d4d90  vmovaps xmm5, [rsp+0x50]
00007f30a29d4d96  vmovaps xmm6, [rsp+0x60]
00007f30a29d4d9c  vmovaps xmm7, [rsp+0x70]
00007f30a29d4da2  vmovaps xmm8, [rsp+0x80]
00007f30a29d4dab  vmovaps xmm9, [rsp+0x90]
00007f30a29d4db4  vmovaps xmm10, [rsp+0xA0]
00007f30a29d4dbd  vmovaps xmm11, [rsp+0xB0]
00007f30a29d4dc6  vmovaps xmm12, [rsp+0xC0]
00007f30a29d4dcf  vmovaps xmm14, [rsp+0xD0]
00007f30a29d4dd8  vmovaps xmm15, [rsp+0xE0]
00007f30a29d4de1  add rsp, 0xF0
00007f30a29d4de8  pop r11
00007f30a29d4dea  pop r10
00007f30a29d4dec  pop r9
00007f30a29d4dee  pop r8
00007f30a29d4df0  pop rsi
00007f30a29d4df1  pop rdi
00007f30a29d4df2  pop rdx
00007f30a29d4df3  pop rcx
00007f30a29d4df4  pop rax
00007f30a29d4df5  add rsp, 0x08
00007f30a29d4df9  jmp 0x00007F30A29D2CD6
00007f30a29d4dfe  sub rsp, 0x08
00007f30a29d4e02  push rax
00007f30a29d4e03  push rcx
00007f30a29d4e04  push rdx
00007f30a29d4e05  push rdi
00007f30a29d4e06  push rsi
00007f30a29d4e07  push r8
00007f30a29d4e09  push r9
00007f30a29d4e0b  push r10
00007f30a29d4e0d  push r11
00007f30a29d4e0f  sub rsp, 0xF0
00007f30a29d4e16  vmovaps [rsp], xmm0
00007f30a29d4e1b  vmovaps [rsp+0x10], xmm1
00007f30a29d4e21  vmovaps [rsp+0x20], xmm2
00007f30a29d4e27  vmovaps [rsp+0x30], xmm3
00007f30a29d4e2d  vmovaps [rsp+0x40], xmm4
00007f30a29d4e33  vmovaps [rsp+0x50], xmm5
00007f30a29d4e39  vmovaps [rsp+0x60], xmm6
00007f30a29d4e3f  vmovaps [rsp+0x70], xmm7
00007f30a29d4e45  vmovaps [rsp+0x80], xmm8
00007f30a29d4e4e  vmovaps [rsp+0x90], xmm9
00007f30a29d4e57  vmovaps [rsp+0xA0], xmm10
00007f30a29d4e60  vmovaps [rsp+0xB0], xmm11
00007f30a29d4e69  vmovaps [rsp+0xC0], xmm12
00007f30a29d4e72  vmovaps [rsp+0xD0], xmm13
00007f30a29d4e7b  vmovaps [rsp+0xE0], xmm14
00007f30a29d4e84  sub rsp, 0x30
00007f30a29d4e88  movaps [rsp], xmm15
00007f30a29d4e8d  movaps [rsp+0x10], xmm14
00007f30a29d4e93  movaps [rsp+0x20], xmm1
00007f30a29d4e98  lea rdi, [rsp]
00007f30a29d4e9c  mov esi, 0x00
00007f30a29d4ea1  mov rax, 0x5FE955026530
00007f30a29d4eab  call rax
00007f30a29d4ead  movaps xmm15, [rsp]
00007f30a29d4eb2  add rsp, 0x30
00007f30a29d4eb6  vmovaps xmm0, [rsp]
00007f30a29d4ebb  vmovaps xmm1, [rsp+0x10]
00007f30a29d4ec1  vmovaps xmm2, [rsp+0x20]
00007f30a29d4ec7  vmovaps xmm3, [rsp+0x30]
00007f30a29d4ecd  vmovaps xmm4, [rsp+0x40]
00007f30a29d4ed3  vmovaps xmm5, [rsp+0x50]
00007f30a29d4ed9  vmovaps xmm6, [rsp+0x60]
00007f30a29d4edf  vmovaps xmm7, [rsp+0x70]
00007f30a29d4ee5  vmovaps xmm8, [rsp+0x80]
00007f30a29d4eee  vmovaps xmm9, [rsp+0x90]
00007f30a29d4ef7  vmovaps xmm10, [rsp+0xA0]
00007f30a29d4f00  vmovaps xmm11, [rsp+0xB0]
00007f30a29d4f09  vmovaps xmm12, [rsp+0xC0]
00007f30a29d4f12  vmovaps xmm13, [rsp+0xD0]
00007f30a29d4f1b  vmovaps xmm14, [rsp+0xE0]
00007f30a29d4f24  add rsp, 0xF0
00007f30a29d4f2b  pop r11
00007f30a29d4f2d  pop r10
00007f30a29d4f2f  pop r9
00007f30a29d4f31  pop r8
00007f30a29d4f33  pop rsi
00007f30a29d4f34  pop rdi
00007f30a29d4f35  pop rdx
00007f30a29d4f36  pop rcx
00007f30a29d4f37  pop rax
00007f30a29d4f38  add rsp, 0x08
00007f30a29d4f3c  jmp 0x00007F30A29D2D12
00007f30a29d4f41  call 0x00007F30A27FF430
00007f30a29d4f46  jmp 0x00007F30A29D2D1F
00007f30a29d4f4b  sub rsp, 0x08
00007f30a29d4f4f  push rax
00007f30a29d4f50  push rcx
00007f30a29d4f51  push rdx
00007f30a29d4f52  push rdi
00007f30a29d4f53  push rsi
00007f30a29d4f54  push r8
00007f30a29d4f56  push r9
00007f30a29d4f58  push r10
00007f30a29d4f5a  push r11
00007f30a29d4f5c  sub rsp, 0xF0
00007f30a29d4f63  vmovaps [rsp], xmm0
00007f30a29d4f68  vmovaps [rsp+0x10], xmm1
00007f30a29d4f6e  vmovaps [rsp+0x20], xmm2
00007f30a29d4f74  vmovaps [rsp+0x30], xmm3
00007f30a29d4f7a  vmovaps [rsp+0x40], xmm4
00007f30a29d4f80  vmovaps [rsp+0x50], xmm5
00007f30a29d4f86  vmovaps [rsp+0x60], xmm6
00007f30a29d4f8c  vmovaps [rsp+0x70], xmm7
00007f30a29d4f92  vmovaps [rsp+0x80], xmm8
00007f30a29d4f9b  vmovaps [rsp+0x90], xmm9
00007f30a29d4fa4  vmovaps [rsp+0xA0], xmm10
00007f30a29d4fad  vmovaps [rsp+0xB0], xmm11
00007f30a29d4fb6  vmovaps [rsp+0xC0], xmm12
00007f30a29d4fbf  vmovaps [rsp+0xD0], xmm13
00007f30a29d4fc8  vmovaps [rsp+0xE0], xmm15
00007f30a29d4fd1  sub rsp, 0x30
00007f30a29d4fd5  movaps [rsp], xmm14
00007f30a29d4fda  movaps [rsp+0x10], xmm13
00007f30a29d4fe0  movaps [rsp+0x20], xmm2
00007f30a29d4fe5  lea rdi, [rsp]
00007f30a29d4fe9  mov esi, 0x00
00007f30a29d4fee  mov rax, 0x5FE955026530
00007f30a29d4ff8  call rax
00007f30a29d4ffa  movaps xmm14, [rsp]
00007f30a29d4fff  add rsp, 0x30
00007f30a29d5003  vmovaps xmm0, [rsp]
00007f30a29d5008  vmovaps xmm1, [rsp+0x10]
00007f30a29d500e  vmovaps xmm2, [rsp+0x20]
00007f30a29d5014  vmovaps xmm3, [rsp+0x30]
00007f30a29d501a  vmovaps xmm4, [rsp+0x40]
00007f30a29d5020  vmovaps xmm5, [rsp+0x50]
00007f30a29d5026  vmovaps xmm6, [rsp+0x60]
00007f30a29d502c  vmovaps xmm7, [rsp+0x70]
00007f30a29d5032  vmovaps xmm8, [rsp+0x80]
00007f30a29d503b  vmovaps xmm9, [rsp+0x90]
00007f30a29d5044  vmovaps xmm10, [rsp+0xA0]
00007f30a29d504d  vmovaps xmm11, [rsp+0xB0]
00007f30a29d5056  vmovaps xmm12, [rsp+0xC0]
00007f30a29d505f  vmovaps xmm13, [rsp+0xD0]
00007f30a29d5068  vmovaps xmm15, [rsp+0xE0]
00007f30a29d5071  add rsp, 0xF0
00007f30a29d5078  pop r11
00007f30a29d507a  pop r10
00007f30a29d507c  pop r9
00007f30a29d507e  pop r8
00007f30a29d5080  pop rsi
00007f30a29d5081  pop rdi
00007f30a29d5082  pop rdx
00007f30a29d5083  pop rcx
00007f30a29d5084  pop rax
00007f30a29d5085  add rsp, 0x08
00007f30a29d5089  jmp 0x00007F30A29D2D4B
00007f30a29d508e  sub rsp, 0x08
00007f30a29d5092  push rax
00007f30a29d5093  push rcx
00007f30a29d5094  push rdx
00007f30a29d5095  push rdi
00007f30a29d5096  push rsi
00007f30a29d5097  push r8
00007f30a29d5099  push r9
00007f30a29d509b  push r10
00007f30a29d509d  push r11
00007f30a29d509f  sub rsp, 0xF0
00007f30a29d50a6  vmovaps [rsp], xmm0
00007f30a29d50ab  vmovaps [rsp+0x10], xmm2
00007f30a29d50b1  vmovaps [rsp+0x20], xmm3
00007f30a29d50b7  vmovaps [rsp+0x30], xmm4
00007f30a29d50bd  vmovaps [rsp+0x40], xmm5
00007f30a29d50c3  vmovaps [rsp+0x50], xmm6
00007f30a29d50c9  vmovaps [rsp+0x60], xmm7
00007f30a29d50cf  vmovaps [rsp+0x70], xmm8
00007f30a29d50d5  vmovaps [rsp+0x80], xmm9
00007f30a29d50de  vmovaps [rsp+0x90], xmm10
00007f30a29d50e7  vmovaps [rsp+0xA0], xmm11
00007f30a29d50f0  vmovaps [rsp+0xB0], xmm12
00007f30a29d50f9  vmovaps [rsp+0xC0], xmm13
00007f30a29d5102  vmovaps [rsp+0xD0], xmm14
00007f30a29d510b  vmovaps [rsp+0xE0], xmm15
00007f30a29d5114  sub rsp, 0x30
00007f30a29d5118  movaps [rsp], xmm1
00007f30a29d511c  movaps [rsp+0x10], xmm13
00007f30a29d5122  movaps [rsp+0x20], xmm2
00007f30a29d5127  lea rdi, [rsp]
00007f30a29d512b  mov esi, 0x00
00007f30a29d5130  mov rax, 0x5FE955026530
00007f30a29d513a  call rax
00007f30a29d513c  movaps xmm1, [rsp]
00007f30a29d5140  add rsp, 0x30
00007f30a29d5144  vmovaps xmm0, [rsp]
00007f30a29d5149  vmovaps xmm2, [rsp+0x10]
00007f30a29d514f  vmovaps xmm3, [rsp+0x20]
00007f30a29d5155  vmovaps xmm4, [rsp+0x30]
00007f30a29d515b  vmovaps xmm5, [rsp+0x40]
00007f30a29d5161  vmovaps xmm6, [rsp+0x50]
00007f30a29d5167  vmovaps xmm7, [rsp+0x60]
00007f30a29d516d  vmovaps xmm8, [rsp+0x70]
00007f30a29d5173  vmovaps xmm9, [rsp+0x80]
00007f30a29d517c  vmovaps xmm10, [rsp+0x90]
00007f30a29d5185  vmovaps xmm11, [rsp+0xA0]
00007f30a29d518e  vmovaps xmm12, [rsp+0xB0]
00007f30a29d5197  vmovaps xmm13, [rsp+0xC0]
00007f30a29d51a0  vmovaps xmm14, [rsp+0xD0]
00007f30a29d51a9  vmovaps xmm15, [rsp+0xE0]
00007f30a29d51b2  add rsp, 0xF0
00007f30a29d51b9  pop r11
00007f30a29d51bb  pop r10
00007f30a29d51bd  pop r9
00007f30a29d51bf  pop r8
00007f30a29d51c1  pop rsi
00007f30a29d51c2  pop rdi
00007f30a29d51c3  pop rdx
00007f30a29d51c4  pop rcx
00007f30a29d51c5  pop rax
00007f30a29d51c6  add rsp, 0x08
00007f30a29d51ca  jmp 0x00007F30A29D2D79
00007f30a29d51cf  sub rsp, 0x08
00007f30a29d51d3  push rax
00007f30a29d51d4  push rcx
00007f30a29d51d5  push rdx
00007f30a29d51d6  push rdi
00007f30a29d51d7  push rsi
00007f30a29d51d8  push r8
00007f30a29d51da  push r9
00007f30a29d51dc  push r10
00007f30a29d51de  push r11
00007f30a29d51e0  sub rsp, 0xF0
00007f30a29d51e7  vmovaps [rsp], xmm0
00007f30a29d51ec  vmovaps [rsp+0x10], xmm1
00007f30a29d51f2  vmovaps [rsp+0x20], xmm3
00007f30a29d51f8  vmovaps [rsp+0x30], xmm4
00007f30a29d51fe  vmovaps [rsp+0x40], xmm5
00007f30a29d5204  vmovaps [rsp+0x50], xmm6
00007f30a29d520a  vmovaps [rsp+0x60], xmm7
00007f30a29d5210  vmovaps [rsp+0x70], xmm8
00007f30a29d5216  vmovaps [rsp+0x80], xmm9
00007f30a29d521f  vmovaps [rsp+0x90], xmm10
00007f30a29d5228  vmovaps [rsp+0xA0], xmm11
00007f30a29d5231  vmovaps [rsp+0xB0], xmm12
00007f30a29d523a  vmovaps [rsp+0xC0], xmm13
00007f30a29d5243  vmovaps [rsp+0xD0], xmm14
00007f30a29d524c  vmovaps [rsp+0xE0], xmm15
00007f30a29d5255  sub rsp, 0x30
00007f30a29d5259  movaps [rsp], xmm2
00007f30a29d525d  movaps [rsp+0x10], xmm1
00007f30a29d5262  movaps [rsp+0x20], xmm13
00007f30a29d5268  lea rdi, [rsp]
00007f30a29d526c  mov esi, 0x00
00007f30a29d5271  mov rax, 0x5FE955026530
00007f30a29d527b  call rax
00007f30a29d527d  movaps xmm2, [rsp]
00007f30a29d5281  add rsp, 0x30
00007f30a29d5285  vmovaps xmm0, [rsp]
00007f30a29d528a  vmovaps xmm1, [rsp+0x10]
00007f30a29d5290  vmovaps xmm3, [rsp+0x20]
00007f30a29d5296  vmovaps xmm4, [rsp+0x30]
00007f30a29d529c  vmovaps xmm5, [rsp+0x40]
00007f30a29d52a2  vmovaps xmm6, [rsp+0x50]
00007f30a29d52a8  vmovaps xmm7, [rsp+0x60]
00007f30a29d52ae  vmovaps xmm8, [rsp+0x70]
00007f30a29d52b4  vmovaps xmm9, [rsp+0x80]
00007f30a29d52bd  vmovaps xmm10, [rsp+0x90]
00007f30a29d52c6  vmovaps xmm11, [rsp+0xA0]
00007f30a29d52cf  vmovaps xmm12, [rsp+0xB0]
00007f30a29d52d8  vmovaps xmm13, [rsp+0xC0]
00007f30a29d52e1  vmovaps xmm14, [rsp+0xD0]
00007f30a29d52ea  vmovaps xmm15, [rsp+0xE0]
00007f30a29d52f3  add rsp, 0xF0
00007f30a29d52fa  pop r11
00007f30a29d52fc  pop r10
00007f30a29d52fe  pop r9
00007f30a29d5300  pop r8
00007f30a29d5302  pop rsi
00007f30a29d5303  pop rdi
00007f30a29d5304  pop rdx
00007f30a29d5305  pop rcx
00007f30a29d5306  pop rax
00007f30a29d5307  add rsp, 0x08
00007f30a29d530b  jmp 0x00007F30A29D2DD2
00007f30a29d5310  call 0x00007F30A27FF430
00007f30a29d5315  jmp 0x00007F30A29D2DDF
00007f30a29d531a  sub rsp, 0x08
00007f30a29d531e  push rax
00007f30a29d531f  push rcx
00007f30a29d5320  push rdx
00007f30a29d5321  push rdi
00007f30a29d5322  push rsi
00007f30a29d5323  push r8
00007f30a29d5325  push r9
00007f30a29d5327  push r10
00007f30a29d5329  push r11
00007f30a29d532b  sub rsp, 0xF0
00007f30a29d5332  vmovaps [rsp], xmm0
00007f30a29d5337  vmovaps [rsp+0x10], xmm1
00007f30a29d533d  vmovaps [rsp+0x20], xmm2
00007f30a29d5343  vmovaps [rsp+0x30], xmm3
00007f30a29d5349  vmovaps [rsp+0x40], xmm4
00007f30a29d534f  vmovaps [rsp+0x50], xmm5
00007f30a29d5355  vmovaps [rsp+0x60], xmm6
00007f30a29d535b  vmovaps [rsp+0x70], xmm7
00007f30a29d5361  vmovaps [rsp+0x80], xmm8
00007f30a29d536a  vmovaps [rsp+0x90], xmm9
00007f30a29d5373  vmovaps [rsp+0xA0], xmm10
00007f30a29d537c  vmovaps [rsp+0xB0], xmm11
00007f30a29d5385  vmovaps [rsp+0xC0], xmm12
00007f30a29d538e  vmovaps [rsp+0xD0], xmm13
00007f30a29d5397  vmovaps [rsp+0xE0], xmm14
00007f30a29d53a0  sub rsp, 0x30
00007f30a29d53a4  movaps [rsp], xmm15
00007f30a29d53a9  movaps [rsp+0x10], xmm13
00007f30a29d53af  movaps [rsp+0x20], xmm1
00007f30a29d53b4  lea rdi, [rsp]
00007f30a29d53b8  mov esi, 0x00
00007f30a29d53bd  mov rax, 0x5FE955026530
00007f30a29d53c7  call rax
00007f30a29d53c9  movaps xmm15, [rsp]
00007f30a29d53ce  add rsp, 0x30
00007f30a29d53d2  vmovaps xmm0, [rsp]
00007f30a29d53d7  vmovaps xmm1, [rsp+0x10]
00007f30a29d53dd  vmovaps xmm2, [rsp+0x20]
00007f30a29d53e3  vmovaps xmm3, [rsp+0x30]
00007f30a29d53e9  vmovaps xmm4, [rsp+0x40]
00007f30a29d53ef  vmovaps xmm5, [rsp+0x50]
00007f30a29d53f5  vmovaps xmm6, [rsp+0x60]
00007f30a29d53fb  vmovaps xmm7, [rsp+0x70]
00007f30a29d5401  vmovaps xmm8, [rsp+0x80]
00007f30a29d540a  vmovaps xmm9, [rsp+0x90]
00007f30a29d5413  vmovaps xmm10, [rsp+0xA0]
00007f30a29d541c  vmovaps xmm11, [rsp+0xB0]
00007f30a29d5425  vmovaps xmm12, [rsp+0xC0]
00007f30a29d542e  vmovaps xmm13, [rsp+0xD0]
00007f30a29d5437  vmovaps xmm14, [rsp+0xE0]
00007f30a29d5440  add rsp, 0xF0
00007f30a29d5447  pop r11
00007f30a29d5449  pop r10
00007f30a29d544b  pop r9
00007f30a29d544d  pop r8
00007f30a29d544f  pop rsi
00007f30a29d5450  pop rdi
00007f30a29d5451  pop rdx
00007f30a29d5452  pop rcx
00007f30a29d5453  pop rax
00007f30a29d5454  add rsp, 0x08
00007f30a29d5458  jmp 0x00007F30A29D2E1E
00007f30a29d545d  sub rsp, 0x08
00007f30a29d5461  push rax
00007f30a29d5462  push rcx
00007f30a29d5463  push rdx
00007f30a29d5464  push rdi
00007f30a29d5465  push rsi
00007f30a29d5466  push r8
00007f30a29d5468  push r9
00007f30a29d546a  push r10
00007f30a29d546c  push r11
00007f30a29d546e  sub rsp, 0xF0
00007f30a29d5475  vmovaps [rsp], xmm0
00007f30a29d547a  vmovaps [rsp+0x10], xmm1
00007f30a29d5480  vmovaps [rsp+0x20], xmm2
00007f30a29d5486  vmovaps [rsp+0x30], xmm3
00007f30a29d548c  vmovaps [rsp+0x40], xmm4
00007f30a29d5492  vmovaps [rsp+0x50], xmm5
00007f30a29d5498  vmovaps [rsp+0x60], xmm6
00007f30a29d549e  vmovaps [rsp+0x70], xmm7
00007f30a29d54a4  vmovaps [rsp+0x80], xmm8
00007f30a29d54ad  vmovaps [rsp+0x90], xmm9
00007f30a29d54b6  vmovaps [rsp+0xA0], xmm10
00007f30a29d54bf  vmovaps [rsp+0xB0], xmm11
00007f30a29d54c8  vmovaps [rsp+0xC0], xmm12
00007f30a29d54d1  vmovaps [rsp+0xD0], xmm13
00007f30a29d54da  vmovaps [rsp+0xE0], xmm15
00007f30a29d54e3  sub rsp, 0x30
00007f30a29d54e7  movaps [rsp], xmm14
00007f30a29d54ec  movaps [rsp+0x10], xmm11
00007f30a29d54f2  movaps [rsp+0x20], xmm1
00007f30a29d54f7  lea rdi, [rsp]
00007f30a29d54fb  mov esi, 0x00
00007f30a29d5500  mov rax, 0x5FE955026530
00007f30a29d550a  call rax
00007f30a29d550c  movaps xmm14, [rsp]
00007f30a29d5511  add rsp, 0x30
00007f30a29d5515  vmovaps xmm0, [rsp]
00007f30a29d551a  vmovaps xmm1, [rsp+0x10]
00007f30a29d5520  vmovaps xmm2, [rsp+0x20]
00007f30a29d5526  vmovaps xmm3, [rsp+0x30]
00007f30a29d552c  vmovaps xmm4, [rsp+0x40]
00007f30a29d5532  vmovaps xmm5, [rsp+0x50]
00007f30a29d5538  vmovaps xmm6, [rsp+0x60]
00007f30a29d553e  vmovaps xmm7, [rsp+0x70]
00007f30a29d5544  vmovaps xmm8, [rsp+0x80]
00007f30a29d554d  vmovaps xmm9, [rsp+0x90]
00007f30a29d5556  vmovaps xmm10, [rsp+0xA0]
00007f30a29d555f  vmovaps xmm11, [rsp+0xB0]
00007f30a29d5568  vmovaps xmm12, [rsp+0xC0]
00007f30a29d5571  vmovaps xmm13, [rsp+0xD0]
00007f30a29d557a  vmovaps xmm15, [rsp+0xE0]
00007f30a29d5583  add rsp, 0xF0
00007f30a29d558a  pop r11
00007f30a29d558c  pop r10
00007f30a29d558e  pop r9
00007f30a29d5590  pop r8
00007f30a29d5592  pop rsi
00007f30a29d5593  pop rdi
00007f30a29d5594  pop rdx
00007f30a29d5595  pop rcx
00007f30a29d5596  pop rax
00007f30a29d5597  add rsp, 0x08
00007f30a29d559b  jmp 0x00007F30A29D2E48
00007f30a29d55a0  sub rsp, 0x08
00007f30a29d55a4  push rax
00007f30a29d55a5  push rcx
00007f30a29d55a6  push rdx
00007f30a29d55a7  push rdi
00007f30a29d55a8  push rsi
00007f30a29d55a9  push r8
00007f30a29d55ab  push r9
00007f30a29d55ad  push r10
00007f30a29d55af  push r11
00007f30a29d55b1  sub rsp, 0xF0
00007f30a29d55b8  vmovaps [rsp], xmm0
00007f30a29d55bd  vmovaps [rsp+0x10], xmm1
00007f30a29d55c3  vmovaps [rsp+0x20], xmm2
00007f30a29d55c9  vmovaps [rsp+0x30], xmm3
00007f30a29d55cf  vmovaps [rsp+0x40], xmm4
00007f30a29d55d5  vmovaps [rsp+0x50], xmm5
00007f30a29d55db  vmovaps [rsp+0x60], xmm6
00007f30a29d55e1  vmovaps [rsp+0x70], xmm7
00007f30a29d55e7  vmovaps [rsp+0x80], xmm8
00007f30a29d55f0  vmovaps [rsp+0x90], xmm9
00007f30a29d55f9  vmovaps [rsp+0xA0], xmm10
00007f30a29d5602  vmovaps [rsp+0xB0], xmm11
00007f30a29d560b  vmovaps [rsp+0xC0], xmm12
00007f30a29d5614  vmovaps [rsp+0xD0], xmm14
00007f30a29d561d  vmovaps [rsp+0xE0], xmm15
00007f30a29d5626  sub rsp, 0x30
00007f30a29d562a  movaps [rsp], xmm13
00007f30a29d562f  movaps [rsp+0x10], xmm11
00007f30a29d5635  movaps [rsp+0x20], xmm1
00007f30a29d563a  lea rdi, [rsp]
00007f30a29d563e  mov esi, 0x00
00007f30a29d5643  mov rax, 0x5FE955026530
00007f30a29d564d  call rax
00007f30a29d564f  movaps xmm13, [rsp]
00007f30a29d5654  add rsp, 0x30
00007f30a29d5658  vmovaps xmm0, [rsp]
00007f30a29d565d  vmovaps xmm1, [rsp+0x10]
00007f30a29d5663  vmovaps xmm2, [rsp+0x20]
00007f30a29d5669  vmovaps xmm3, [rsp+0x30]
00007f30a29d566f  vmovaps xmm4, [rsp+0x40]
00007f30a29d5675  vmovaps xmm5, [rsp+0x50]
00007f30a29d567b  vmovaps xmm6, [rsp+0x60]
00007f30a29d5681  vmovaps xmm7, [rsp+0x70]
00007f30a29d5687  vmovaps xmm8, [rsp+0x80]
00007f30a29d5690  vmovaps xmm9, [rsp+0x90]
00007f30a29d5699  vmovaps xmm10, [rsp+0xA0]
00007f30a29d56a2  vmovaps xmm11, [rsp+0xB0]
00007f30a29d56ab  vmovaps xmm12, [rsp+0xC0]
00007f30a29d56b4  vmovaps xmm14, [rsp+0xD0]
00007f30a29d56bd  vmovaps xmm15, [rsp+0xE0]
00007f30a29d56c6  add rsp, 0xF0
00007f30a29d56cd  pop r11
00007f30a29d56cf  pop r10
00007f30a29d56d1  pop r9
00007f30a29d56d3  pop r8
00007f30a29d56d5  pop rsi
00007f30a29d56d6  pop rdi
00007f30a29d56d7  pop rdx
00007f30a29d56d8  pop rcx
00007f30a29d56d9  pop rax
00007f30a29d56da  add rsp, 0x08
00007f30a29d56de  jmp 0x00007F30A29D2E9D
00007f30a29d56e3  call 0x00007F30A27FF430
00007f30a29d56e8  jmp 0x00007F30A29D2EAA
00007f30a29d56ed  sub rsp, 0x08
00007f30a29d56f1  push rax
00007f30a29d56f2  push rcx
00007f30a29d56f3  push rdx
00007f30a29d56f4  push rdi
00007f30a29d56f5  push rsi
00007f30a29d56f6  push r8
00007f30a29d56f8  push r9
00007f30a29d56fa  push r10
00007f30a29d56fc  push r11
00007f30a29d56fe  sub rsp, 0xF0
00007f30a29d5705  vmovaps [rsp], xmm0
00007f30a29d570a  vmovaps [rsp+0x10], xmm1
00007f30a29d5710  vmovaps [rsp+0x20], xmm2
00007f30a29d5716  vmovaps [rsp+0x30], xmm3
00007f30a29d571c  vmovaps [rsp+0x40], xmm4
00007f30a29d5722  vmovaps [rsp+0x50], xmm5
00007f30a29d5728  vmovaps [rsp+0x60], xmm6
00007f30a29d572e  vmovaps [rsp+0x70], xmm7
00007f30a29d5734  vmovaps [rsp+0x80], xmm8
00007f30a29d573d  vmovaps [rsp+0x90], xmm9
00007f30a29d5746  vmovaps [rsp+0xA0], xmm10
00007f30a29d574f  vmovaps [rsp+0xB0], xmm11
00007f30a29d5758  vmovaps [rsp+0xC0], xmm12
00007f30a29d5761  vmovaps [rsp+0xD0], xmm13
00007f30a29d576a  vmovaps [rsp+0xE0], xmm14
00007f30a29d5773  sub rsp, 0x30
00007f30a29d5777  movaps [rsp], xmm15
00007f30a29d577c  movaps [rsp+0x10], xmm11
00007f30a29d5782  movaps [rsp+0x20], xmm1
00007f30a29d5787  lea rdi, [rsp]
00007f30a29d578b  mov esi, 0x00
00007f30a29d5790  mov rax, 0x5FE955026530
00007f30a29d579a  call rax
00007f30a29d579c  movaps xmm15, [rsp]
00007f30a29d57a1  add rsp, 0x30
00007f30a29d57a5  vmovaps xmm0, [rsp]
00007f30a29d57aa  vmovaps xmm1, [rsp+0x10]
00007f30a29d57b0  vmovaps xmm2, [rsp+0x20]
00007f30a29d57b6  vmovaps xmm3, [rsp+0x30]
00007f30a29d57bc  vmovaps xmm4, [rsp+0x40]
00007f30a29d57c2  vmovaps xmm5, [rsp+0x50]
00007f30a29d57c8  vmovaps xmm6, [rsp+0x60]
00007f30a29d57ce  vmovaps xmm7, [rsp+0x70]
00007f30a29d57d4  vmovaps xmm8, [rsp+0x80]
00007f30a29d57dd  vmovaps xmm9, [rsp+0x90]
00007f30a29d57e6  vmovaps xmm10, [rsp+0xA0]
00007f30a29d57ef  vmovaps xmm11, [rsp+0xB0]
00007f30a29d57f8  vmovaps xmm12, [rsp+0xC0]
00007f30a29d5801  vmovaps xmm13, [rsp+0xD0]
00007f30a29d580a  vmovaps xmm14, [rsp+0xE0]
00007f30a29d5813  add rsp, 0xF0
00007f30a29d581a  pop r11
00007f30a29d581c  pop r10
00007f30a29d581e  pop r9
00007f30a29d5820  pop r8
00007f30a29d5822  pop rsi
00007f30a29d5823  pop rdi
00007f30a29d5824  pop rdx
00007f30a29d5825  pop rcx
00007f30a29d5826  pop rax
00007f30a29d5827  add rsp, 0x08
00007f30a29d582b  jmp 0x00007F30A29D2EE3
00007f30a29d5830  sub rsp, 0x08
00007f30a29d5834  push rax
00007f30a29d5835  push rcx
00007f30a29d5836  push rdx
00007f30a29d5837  push rdi
00007f30a29d5838  push rsi
00007f30a29d5839  push r8
00007f30a29d583b  push r9
00007f30a29d583d  push r10
00007f30a29d583f  push r11
00007f30a29d5841  sub rsp, 0xF0
00007f30a29d5848  vmovaps [rsp], xmm0
00007f30a29d584d  vmovaps [rsp+0x10], xmm1
00007f30a29d5853  vmovaps [rsp+0x20], xmm2
00007f30a29d5859  vmovaps [rsp+0x30], xmm3
00007f30a29d585f  vmovaps [rsp+0x40], xmm4
00007f30a29d5865  vmovaps [rsp+0x50], xmm5
00007f30a29d586b  vmovaps [rsp+0x60], xmm6
00007f30a29d5871  vmovaps [rsp+0x70], xmm7
00007f30a29d5877  vmovaps [rsp+0x80], xmm8
00007f30a29d5880  vmovaps [rsp+0x90], xmm9
00007f30a29d5889  vmovaps [rsp+0xA0], xmm10
00007f30a29d5892  vmovaps [rsp+0xB0], xmm12
00007f30a29d589b  vmovaps [rsp+0xC0], xmm13
00007f30a29d58a4  vmovaps [rsp+0xD0], xmm14
00007f30a29d58ad  vmovaps [rsp+0xE0], xmm15
00007f30a29d58b6  sub rsp, 0x30
00007f30a29d58ba  movaps [rsp], xmm11
00007f30a29d58bf  movaps [rsp+0x10], xmm6
00007f30a29d58c4  movaps [rsp+0x20], xmm14
00007f30a29d58ca  lea rdi, [rsp]
00007f30a29d58ce  mov esi, 0x00
00007f30a29d58d3  mov rax, 0x5FE955026530
00007f30a29d58dd  call rax
00007f30a29d58df  movaps xmm11, [rsp]
00007f30a29d58e4  add rsp, 0x30
00007f30a29d58e8  vmovaps xmm0, [rsp]
00007f30a29d58ed  vmovaps xmm1, [rsp+0x10]
00007f30a29d58f3  vmovaps xmm2, [rsp+0x20]
00007f30a29d58f9  vmovaps xmm3, [rsp+0x30]
00007f30a29d58ff  vmovaps xmm4, [rsp+0x40]
00007f30a29d5905  vmovaps xmm5, [rsp+0x50]
00007f30a29d590b  vmovaps xmm6, [rsp+0x60]
00007f30a29d5911  vmovaps xmm7, [rsp+0x70]
00007f30a29d5917  vmovaps xmm8, [rsp+0x80]
00007f30a29d5920  vmovaps xmm9, [rsp+0x90]
00007f30a29d5929  vmovaps xmm10, [rsp+0xA0]
00007f30a29d5932  vmovaps xmm12, [rsp+0xB0]
00007f30a29d593b  vmovaps xmm13, [rsp+0xC0]
00007f30a29d5944  vmovaps xmm14, [rsp+0xD0]
00007f30a29d594d  vmovaps xmm15, [rsp+0xE0]
00007f30a29d5956  add rsp, 0xF0
00007f30a29d595d  pop r11
00007f30a29d595f  pop r10
00007f30a29d5961  pop r9
00007f30a29d5963  pop r8
00007f30a29d5965  pop rsi
00007f30a29d5966  pop rdi
00007f30a29d5967  pop rdx
00007f30a29d5968  pop rcx
00007f30a29d5969  pop rax
00007f30a29d596a  add rsp, 0x08
00007f30a29d596e  jmp 0x00007F30A29D2F5B
00007f30a29d5973  call 0x00007F30A27FF430
00007f30a29d5978  jmp 0x00007F30A29D2F65
00007f30a29d597d  sub rsp, 0x08
00007f30a29d5981  push rax
00007f30a29d5982  push rcx
00007f30a29d5983  push rdx
00007f30a29d5984  push rdi
00007f30a29d5985  push rsi
00007f30a29d5986  push r8
00007f30a29d5988  push r9
00007f30a29d598a  push r10
00007f30a29d598c  push r11
00007f30a29d598e  sub rsp, 0xF0
00007f30a29d5995  vmovaps [rsp], xmm0
00007f30a29d599a  vmovaps [rsp+0x10], xmm1
00007f30a29d59a0  vmovaps [rsp+0x20], xmm2
00007f30a29d59a6  vmovaps [rsp+0x30], xmm3
00007f30a29d59ac  vmovaps [rsp+0x40], xmm4
00007f30a29d59b2  vmovaps [rsp+0x50], xmm5
00007f30a29d59b8  vmovaps [rsp+0x60], xmm6
00007f30a29d59be  vmovaps [rsp+0x70], xmm7
00007f30a29d59c4  vmovaps [rsp+0x80], xmm8
00007f30a29d59cd  vmovaps [rsp+0x90], xmm9
00007f30a29d59d6  vmovaps [rsp+0xA0], xmm10
00007f30a29d59df  vmovaps [rsp+0xB0], xmm11
00007f30a29d59e8  vmovaps [rsp+0xC0], xmm12
00007f30a29d59f1  vmovaps [rsp+0xD0], xmm13
00007f30a29d59fa  vmovaps [rsp+0xE0], xmm15
00007f30a29d5a03  sub rsp, 0x30
00007f30a29d5a07  movaps [rsp], xmm14
00007f30a29d5a0c  movaps [rsp+0x10], xmm6
00007f30a29d5a11  movaps [rsp+0x20], xmm2
00007f30a29d5a16  lea rdi, [rsp]
00007f30a29d5a1a  mov esi, 0x00
00007f30a29d5a1f  mov rax, 0x5FE955026530
00007f30a29d5a29  call rax
00007f30a29d5a2b  movaps xmm14, [rsp]
00007f30a29d5a30  add rsp, 0x30
00007f30a29d5a34  vmovaps xmm0, [rsp]
00007f30a29d5a39  vmovaps xmm1, [rsp+0x10]
00007f30a29d5a3f  vmovaps xmm2, [rsp+0x20]
00007f30a29d5a45  vmovaps xmm3, [rsp+0x30]
00007f30a29d5a4b  vmovaps xmm4, [rsp+0x40]
00007f30a29d5a51  vmovaps xmm5, [rsp+0x50]
00007f30a29d5a57  vmovaps xmm6, [rsp+0x60]
00007f30a29d5a5d  vmovaps xmm7, [rsp+0x70]
00007f30a29d5a63  vmovaps xmm8, [rsp+0x80]
00007f30a29d5a6c  vmovaps xmm9, [rsp+0x90]
00007f30a29d5a75  vmovaps xmm10, [rsp+0xA0]
00007f30a29d5a7e  vmovaps xmm11, [rsp+0xB0]
00007f30a29d5a87  vmovaps xmm12, [rsp+0xC0]
00007f30a29d5a90  vmovaps xmm13, [rsp+0xD0]
00007f30a29d5a99  vmovaps xmm15, [rsp+0xE0]
00007f30a29d5aa2  add rsp, 0xF0
00007f30a29d5aa9  pop r11
00007f30a29d5aab  pop r10
00007f30a29d5aad  pop r9
00007f30a29d5aaf  pop r8
00007f30a29d5ab1  pop rsi
00007f30a29d5ab2  pop rdi
00007f30a29d5ab3  pop rdx
00007f30a29d5ab4  pop rcx
00007f30a29d5ab5  pop rax
00007f30a29d5ab6  add rsp, 0x08
00007f30a29d5aba  jmp 0x00007F30A29D2F99
00007f30a29d5abf  sub rsp, 0x08
00007f30a29d5ac3  push rax
00007f30a29d5ac4  push rcx
00007f30a29d5ac5  push rdx
00007f30a29d5ac6  push rdi
00007f30a29d5ac7  push rsi
00007f30a29d5ac8  push r8
00007f30a29d5aca  push r9
00007f30a29d5acc  push r10
00007f30a29d5ace  push r11
00007f30a29d5ad0  sub rsp, 0xF0
00007f30a29d5ad7  vmovaps [rsp], xmm0
00007f30a29d5adc  vmovaps [rsp+0x10], xmm1
00007f30a29d5ae2  vmovaps [rsp+0x20], xmm2
00007f30a29d5ae8  vmovaps [rsp+0x30], xmm3
00007f30a29d5aee  vmovaps [rsp+0x40], xmm4
00007f30a29d5af4  vmovaps [rsp+0x50], xmm5
00007f30a29d5afa  vmovaps [rsp+0x60], xmm7
00007f30a29d5b00  vmovaps [rsp+0x70], xmm8
00007f30a29d5b06  vmovaps [rsp+0x80], xmm9
00007f30a29d5b0f  vmovaps [rsp+0x90], xmm10
00007f30a29d5b18  vmovaps [rsp+0xA0], xmm11
00007f30a29d5b21  vmovaps [rsp+0xB0], xmm12
00007f30a29d5b2a  vmovaps [rsp+0xC0], xmm13
00007f30a29d5b33  vmovaps [rsp+0xD0], xmm14
00007f30a29d5b3c  vmovaps [rsp+0xE0], xmm15
00007f30a29d5b45  sub rsp, 0x30
00007f30a29d5b49  movaps [rsp], xmm6
00007f30a29d5b4d  movaps [rsp+0x10], xmm5
00007f30a29d5b52  movaps [rsp+0x20], xmm1
00007f30a29d5b57  lea rdi, [rsp]
00007f30a29d5b5b  mov esi, 0x00
00007f30a29d5b60  mov rax, 0x5FE955026530
00007f30a29d5b6a  call rax
00007f30a29d5b6c  movaps xmm6, [rsp]
00007f30a29d5b70  add rsp, 0x30
00007f30a29d5b74  vmovaps xmm0, [rsp]
00007f30a29d5b79  vmovaps xmm1, [rsp+0x10]
00007f30a29d5b7f  vmovaps xmm2, [rsp+0x20]
00007f30a29d5b85  vmovaps xmm3, [rsp+0x30]
00007f30a29d5b8b  vmovaps xmm4, [rsp+0x40]
00007f30a29d5b91  vmovaps xmm5, [rsp+0x50]
00007f30a29d5b97  vmovaps xmm7, [rsp+0x60]
00007f30a29d5b9d  vmovaps xmm8, [rsp+0x70]
00007f30a29d5ba3  vmovaps xmm9, [rsp+0x80]
00007f30a29d5bac  vmovaps xmm10, [rsp+0x90]
00007f30a29d5bb5  vmovaps xmm11, [rsp+0xA0]
00007f30a29d5bbe  vmovaps xmm12, [rsp+0xB0]
00007f30a29d5bc7  vmovaps xmm13, [rsp+0xC0]
00007f30a29d5bd0  vmovaps xmm14, [rsp+0xD0]
00007f30a29d5bd9  vmovaps xmm15, [rsp+0xE0]
00007f30a29d5be2  add rsp, 0xF0
00007f30a29d5be9  pop r11
00007f30a29d5beb  pop r10
00007f30a29d5bed  pop r9
00007f30a29d5bef  pop r8
00007f30a29d5bf1  pop rsi
00007f30a29d5bf2  pop rdi
00007f30a29d5bf3  pop rdx
00007f30a29d5bf4  pop rcx
00007f30a29d5bf5  pop rax
00007f30a29d5bf6  add rsp, 0x08
00007f30a29d5bfa  jmp 0x00007F30A29D2FBF
00007f30a29d5bff  sub rsp, 0x08
00007f30a29d5c03  push rax
00007f30a29d5c04  push rcx
00007f30a29d5c05  push rdx
00007f30a29d5c06  push rdi
00007f30a29d5c07  push rsi
00007f30a29d5c08  push r8
00007f30a29d5c0a  push r9
00007f30a29d5c0c  push r10
00007f30a29d5c0e  push r11
00007f30a29d5c10  sub rsp, 0xF0
00007f30a29d5c17  vmovaps [rsp], xmm0
00007f30a29d5c1c  vmovaps [rsp+0x10], xmm2
00007f30a29d5c22  vmovaps [rsp+0x20], xmm3
00007f30a29d5c28  vmovaps [rsp+0x30], xmm4
00007f30a29d5c2e  vmovaps [rsp+0x40], xmm5
00007f30a29d5c34  vmovaps [rsp+0x50], xmm6
00007f30a29d5c3a  vmovaps [rsp+0x60], xmm7
00007f30a29d5c40  vmovaps [rsp+0x70], xmm8
00007f30a29d5c46  vmovaps [rsp+0x80], xmm9
00007f30a29d5c4f  vmovaps [rsp+0x90], xmm10
00007f30a29d5c58  vmovaps [rsp+0xA0], xmm11
00007f30a29d5c61  vmovaps [rsp+0xB0], xmm12
00007f30a29d5c6a  vmovaps [rsp+0xC0], xmm13
00007f30a29d5c73  vmovaps [rsp+0xD0], xmm14
00007f30a29d5c7c  vmovaps [rsp+0xE0], xmm15
00007f30a29d5c85  sub rsp, 0x30
00007f30a29d5c89  movaps [rsp], xmm1
00007f30a29d5c8d  movaps [rsp+0x10], xmm5
00007f30a29d5c92  movaps [rsp+0x20], xmm13
00007f30a29d5c98  lea rdi, [rsp]
00007f30a29d5c9c  mov esi, 0x00
00007f30a29d5ca1  mov rax, 0x5FE955026530
00007f30a29d5cab  call rax
00007f30a29d5cad  movaps xmm1, [rsp]
00007f30a29d5cb1  add rsp, 0x30
00007f30a29d5cb5  vmovaps xmm0, [rsp]
00007f30a29d5cba  vmovaps xmm2, [rsp+0x10]
00007f30a29d5cc0  vmovaps xmm3, [rsp+0x20]
00007f30a29d5cc6  vmovaps xmm4, [rsp+0x30]
00007f30a29d5ccc  vmovaps xmm5, [rsp+0x40]
00007f30a29d5cd2  vmovaps xmm6, [rsp+0x50]
00007f30a29d5cd8  vmovaps xmm7, [rsp+0x60]
00007f30a29d5cde  vmovaps xmm8, [rsp+0x70]
00007f30a29d5ce4  vmovaps xmm9, [rsp+0x80]
00007f30a29d5ced  vmovaps xmm10, [rsp+0x90]
00007f30a29d5cf6  vmovaps xmm11, [rsp+0xA0]
00007f30a29d5cff  vmovaps xmm12, [rsp+0xB0]
00007f30a29d5d08  vmovaps xmm13, [rsp+0xC0]
00007f30a29d5d11  vmovaps xmm14, [rsp+0xD0]
00007f30a29d5d1a  vmovaps xmm15, [rsp+0xE0]
00007f30a29d5d23  add rsp, 0xF0
00007f30a29d5d2a  pop r11
00007f30a29d5d2c  pop r10
00007f30a29d5d2e  pop r9
00007f30a29d5d30  pop r8
00007f30a29d5d32  pop rsi
00007f30a29d5d33  pop rdi
00007f30a29d5d34  pop rdx
00007f30a29d5d35  pop rcx
00007f30a29d5d36  pop rax
00007f30a29d5d37  add rsp, 0x08
00007f30a29d5d3b  jmp 0x00007F30A29D2FDD
00007f30a29d5d40  sub rsp, 0x08
00007f30a29d5d44  push rax
00007f30a29d5d45  push rcx
00007f30a29d5d46  push rdx
00007f30a29d5d47  push rdi
00007f30a29d5d48  push rsi
00007f30a29d5d49  push r8
00007f30a29d5d4b  push r9
00007f30a29d5d4d  push r10
00007f30a29d5d4f  push r11
00007f30a29d5d51  sub rsp, 0xF0
00007f30a29d5d58  vmovaps [rsp], xmm0
00007f30a29d5d5d  vmovaps [rsp+0x10], xmm1
00007f30a29d5d63  vmovaps [rsp+0x20], xmm2
00007f30a29d5d69  vmovaps [rsp+0x30], xmm3
00007f30a29d5d6f  vmovaps [rsp+0x40], xmm4
00007f30a29d5d75  vmovaps [rsp+0x50], xmm6
00007f30a29d5d7b  vmovaps [rsp+0x60], xmm7
00007f30a29d5d81  vmovaps [rsp+0x70], xmm8
00007f30a29d5d87  vmovaps [rsp+0x80], xmm9
00007f30a29d5d90  vmovaps [rsp+0x90], xmm10
00007f30a29d5d99  vmovaps [rsp+0xA0], xmm11
00007f30a29d5da2  vmovaps [rsp+0xB0], xmm12
00007f30a29d5dab  vmovaps [rsp+0xC0], xmm13
00007f30a29d5db4  vmovaps [rsp+0xD0], xmm14
00007f30a29d5dbd  vmovaps [rsp+0xE0], xmm15
00007f30a29d5dc6  sub rsp, 0x30
00007f30a29d5dca  movaps [rsp], xmm5
00007f30a29d5dce  movaps [rsp+0x10], xmm2
00007f30a29d5dd3  movaps [rsp+0x20], xmm13
00007f30a29d5dd9  lea rdi, [rsp]
00007f30a29d5ddd  mov esi, 0x00
00007f30a29d5de2  mov rax, 0x5FE955026530
00007f30a29d5dec  call rax
00007f30a29d5dee  movaps xmm5, [rsp]
00007f30a29d5df2  add rsp, 0x30
00007f30a29d5df6  vmovaps xmm0, [rsp]
00007f30a29d5dfb  vmovaps xmm1, [rsp+0x10]
00007f30a29d5e01  vmovaps xmm2, [rsp+0x20]
00007f30a29d5e07  vmovaps xmm3, [rsp+0x30]
00007f30a29d5e0d  vmovaps xmm4, [rsp+0x40]
00007f30a29d5e13  vmovaps xmm6, [rsp+0x50]
00007f30a29d5e19  vmovaps xmm7, [rsp+0x60]
00007f30a29d5e1f  vmovaps xmm8, [rsp+0x70]
00007f30a29d5e25  vmovaps xmm9, [rsp+0x80]
00007f30a29d5e2e  vmovaps xmm10, [rsp+0x90]
00007f30a29d5e37  vmovaps xmm11, [rsp+0xA0]
00007f30a29d5e40  vmovaps xmm12, [rsp+0xB0]
00007f30a29d5e49  vmovaps xmm13, [rsp+0xC0]
00007f30a29d5e52  vmovaps xmm14, [rsp+0xD0]
00007f30a29d5e5b  vmovaps xmm15, [rsp+0xE0]
00007f30a29d5e64  add rsp, 0xF0
00007f30a29d5e6b  pop r11
00007f30a29d5e6d  pop r10
00007f30a29d5e6f  pop r9
00007f30a29d5e71  pop r8
00007f30a29d5e73  pop rsi
00007f30a29d5e74  pop rdi
00007f30a29d5e75  pop rdx
00007f30a29d5e76  pop rcx
00007f30a29d5e77  pop rax
00007f30a29d5e78  add rsp, 0x08
00007f30a29d5e7c  jmp 0x00007F30A29D3013
00007f30a29d5e81  sub rsp, 0x08
00007f30a29d5e85  push rax
00007f30a29d5e86  push rcx
00007f30a29d5e87  push rdx
00007f30a29d5e88  push rdi
00007f30a29d5e89  push rsi
00007f30a29d5e8a  push r8
00007f30a29d5e8c  push r9
00007f30a29d5e8e  push r10
00007f30a29d5e90  push r11
00007f30a29d5e92  sub rsp, 0xF0
00007f30a29d5e99  vmovaps [rsp], xmm0
00007f30a29d5e9e  vmovaps [rsp+0x10], xmm1
00007f30a29d5ea4  vmovaps [rsp+0x20], xmm2
00007f30a29d5eaa  vmovaps [rsp+0x30], xmm3
00007f30a29d5eb0  vmovaps [rsp+0x40], xmm4
00007f30a29d5eb6  vmovaps [rsp+0x50], xmm5
00007f30a29d5ebc  vmovaps [rsp+0x60], xmm6
00007f30a29d5ec2  vmovaps [rsp+0x70], xmm7
00007f30a29d5ec8  vmovaps [rsp+0x80], xmm8
00007f30a29d5ed1  vmovaps [rsp+0x90], xmm9
00007f30a29d5eda  vmovaps [rsp+0xA0], xmm10
00007f30a29d5ee3  vmovaps [rsp+0xB0], xmm11
00007f30a29d5eec  vmovaps [rsp+0xC0], xmm12
00007f30a29d5ef5  vmovaps [rsp+0xD0], xmm14
00007f30a29d5efe  vmovaps [rsp+0xE0], xmm15
00007f30a29d5f07  sub rsp, 0x30
00007f30a29d5f0b  movaps [rsp], xmm13
00007f30a29d5f10  movaps [rsp+0x10], xmm10
00007f30a29d5f16  movaps [rsp+0x20], xmm1
00007f30a29d5f1b  lea rdi, [rsp]
00007f30a29d5f1f  mov esi, 0x00
00007f30a29d5f24  mov rax, 0x5FE955026530
00007f30a29d5f2e  call rax
00007f30a29d5f30  movaps xmm13, [rsp]
00007f30a29d5f35  add rsp, 0x30
00007f30a29d5f39  vmovaps xmm0, [rsp]
00007f30a29d5f3e  vmovaps xmm1, [rsp+0x10]
00007f30a29d5f44  vmovaps xmm2, [rsp+0x20]
00007f30a29d5f4a  vmovaps xmm3, [rsp+0x30]
00007f30a29d5f50  vmovaps xmm4, [rsp+0x40]
00007f30a29d5f56  vmovaps xmm5, [rsp+0x50]
00007f30a29d5f5c  vmovaps xmm6, [rsp+0x60]
00007f30a29d5f62  vmovaps xmm7, [rsp+0x70]
00007f30a29d5f68  vmovaps xmm8, [rsp+0x80]
00007f30a29d5f71  vmovaps xmm9, [rsp+0x90]
00007f30a29d5f7a  vmovaps xmm10, [rsp+0xA0]
00007f30a29d5f83  vmovaps xmm11, [rsp+0xB0]
00007f30a29d5f8c  vmovaps xmm12, [rsp+0xC0]
00007f30a29d5f95  vmovaps xmm14, [rsp+0xD0]
00007f30a29d5f9e  vmovaps xmm15, [rsp+0xE0]
00007f30a29d5fa7  add rsp, 0xF0
00007f30a29d5fae  pop r11
00007f30a29d5fb0  pop r10
00007f30a29d5fb2  pop r9
00007f30a29d5fb4  pop r8
00007f30a29d5fb6  pop rsi
00007f30a29d5fb7  pop rdi
00007f30a29d5fb8  pop rdx
00007f30a29d5fb9  pop rcx
00007f30a29d5fba  pop rax
00007f30a29d5fbb  add rsp, 0x08
00007f30a29d5fbf  jmp 0x00007F30A29D303C
00007f30a29d5fc4  sub rsp, 0x08
00007f30a29d5fc8  push rax
00007f30a29d5fc9  push rcx
00007f30a29d5fca  push rdx
00007f30a29d5fcb  push rdi
00007f30a29d5fcc  push rsi
00007f30a29d5fcd  push r8
00007f30a29d5fcf  push r9
00007f30a29d5fd1  push r10
00007f30a29d5fd3  push r11
00007f30a29d5fd5  sub rsp, 0xF0
00007f30a29d5fdc  vmovaps [rsp], xmm0
00007f30a29d5fe1  vmovaps [rsp+0x10], xmm2
00007f30a29d5fe7  vmovaps [rsp+0x20], xmm3
00007f30a29d5fed  vmovaps [rsp+0x30], xmm4
00007f30a29d5ff3  vmovaps [rsp+0x40], xmm5
00007f30a29d5ff9  vmovaps [rsp+0x50], xmm6
00007f30a29d5fff  vmovaps [rsp+0x60], xmm7
00007f30a29d6005  vmovaps [rsp+0x70], xmm8
00007f30a29d600b  vmovaps [rsp+0x80], xmm9
00007f30a29d6014  vmovaps [rsp+0x90], xmm10
00007f30a29d601d  vmovaps [rsp+0xA0], xmm11
00007f30a29d6026  vmovaps [rsp+0xB0], xmm12
00007f30a29d602f  vmovaps [rsp+0xC0], xmm13
00007f30a29d6038  vmovaps [rsp+0xD0], xmm14
00007f30a29d6041  vmovaps [rsp+0xE0], xmm15
00007f30a29d604a  sub rsp, 0x30
00007f30a29d604e  movaps [rsp], xmm1
00007f30a29d6052  movaps [rsp+0x10], xmm15
00007f30a29d6058  movaps [rsp+0x20], xmm10
00007f30a29d605e  lea rdi, [rsp]
00007f30a29d6062  mov esi, 0x00
00007f30a29d6067  mov rax, 0x5FE955026530
00007f30a29d6071  call rax
00007f30a29d6073  movaps xmm1, [rsp]
00007f30a29d6077  add rsp, 0x30
00007f30a29d607b  vmovaps xmm0, [rsp]
00007f30a29d6080  vmovaps xmm2, [rsp+0x10]
00007f30a29d6086  vmovaps xmm3, [rsp+0x20]
00007f30a29d608c  vmovaps xmm4, [rsp+0x30]
00007f30a29d6092  vmovaps xmm5, [rsp+0x40]
00007f30a29d6098  vmovaps xmm6, [rsp+0x50]
00007f30a29d609e  vmovaps xmm7, [rsp+0x60]
00007f30a29d60a4  vmovaps xmm8, [rsp+0x70]
00007f30a29d60aa  vmovaps xmm9, [rsp+0x80]
00007f30a29d60b3  vmovaps xmm10, [rsp+0x90]
00007f30a29d60bc  vmovaps xmm11, [rsp+0xA0]
00007f30a29d60c5  vmovaps xmm12, [rsp+0xB0]
00007f30a29d60ce  vmovaps xmm13, [rsp+0xC0]
00007f30a29d60d7  vmovaps xmm14, [rsp+0xD0]
00007f30a29d60e0  vmovaps xmm15, [rsp+0xE0]
00007f30a29d60e9  add rsp, 0xF0
00007f30a29d60f0  pop r11
00007f30a29d60f2  pop r10
00007f30a29d60f4  pop r9
00007f30a29d60f6  pop r8
00007f30a29d60f8  pop rsi
00007f30a29d60f9  pop rdi
00007f30a29d60fa  pop rdx
00007f30a29d60fb  pop rcx
00007f30a29d60fc  pop rax
00007f30a29d60fd  add rsp, 0x08
00007f30a29d6101  jmp 0x00007F30A29D305B
00007f30a29d6106  sub rsp, 0x08
00007f30a29d610a  push rax
00007f30a29d610b  push rcx
00007f30a29d610c  push rdx
00007f30a29d610d  push rdi
00007f30a29d610e  push rsi
00007f30a29d610f  push r8
00007f30a29d6111  push r9
00007f30a29d6113  push r10
00007f30a29d6115  push r11
00007f30a29d6117  sub rsp, 0xF0
00007f30a29d611e  vmovaps [rsp], xmm0
00007f30a29d6123  vmovaps [rsp+0x10], xmm1
00007f30a29d6129  vmovaps [rsp+0x20], xmm2
00007f30a29d612f  vmovaps [rsp+0x30], xmm3
00007f30a29d6135  vmovaps [rsp+0x40], xmm4
00007f30a29d613b  vmovaps [rsp+0x50], xmm5
00007f30a29d6141  vmovaps [rsp+0x60], xmm6
00007f30a29d6147  vmovaps [rsp+0x70], xmm7
00007f30a29d614d  vmovaps [rsp+0x80], xmm8
00007f30a29d6156  vmovaps [rsp+0x90], xmm9
00007f30a29d615f  vmovaps [rsp+0xA0], xmm10
00007f30a29d6168  vmovaps [rsp+0xB0], xmm11
00007f30a29d6171  vmovaps [rsp+0xC0], xmm12
00007f30a29d617a  vmovaps [rsp+0xD0], xmm13
00007f30a29d6183  vmovaps [rsp+0xE0], xmm14
00007f30a29d618c  sub rsp, 0x30
00007f30a29d6190  movaps [rsp], xmm15
00007f30a29d6195  movaps [rsp+0x10], xmm10
00007f30a29d619b  movaps [rsp+0x20], xmm11
00007f30a29d61a1  lea rdi, [rsp]
00007f30a29d61a5  mov esi, 0x00
00007f30a29d61aa  mov rax, 0x5FE955026530
00007f30a29d61b4  call rax
00007f30a29d61b6  movaps xmm15, [rsp]
00007f30a29d61bb  add rsp, 0x30
00007f30a29d61bf  vmovaps xmm0, [rsp]
00007f30a29d61c4  vmovaps xmm1, [rsp+0x10]
00007f30a29d61ca  vmovaps xmm2, [rsp+0x20]
00007f30a29d61d0  vmovaps xmm3, [rsp+0x30]
00007f30a29d61d6  vmovaps xmm4, [rsp+0x40]
00007f30a29d61dc  vmovaps xmm5, [rsp+0x50]
00007f30a29d61e2  vmovaps xmm6, [rsp+0x60]
00007f30a29d61e8  vmovaps xmm7, [rsp+0x70]
00007f30a29d61ee  vmovaps xmm8, [rsp+0x80]
00007f30a29d61f7  vmovaps xmm9, [rsp+0x90]
00007f30a29d6200  vmovaps xmm10, [rsp+0xA0]
00007f30a29d6209  vmovaps xmm11, [rsp+0xB0]
00007f30a29d6212  vmovaps xmm12, [rsp+0xC0]
00007f30a29d621b  vmovaps xmm13, [rsp+0xD0]
00007f30a29d6224  vmovaps xmm14, [rsp+0xE0]
00007f30a29d622d  add rsp, 0xF0
00007f30a29d6234  pop r11
00007f30a29d6236  pop r10
00007f30a29d6238  pop r9
00007f30a29d623a  pop r8
00007f30a29d623c  pop rsi
00007f30a29d623d  pop rdi
00007f30a29d623e  pop rdx
00007f30a29d623f  pop rcx
00007f30a29d6240  pop rax
00007f30a29d6241  add rsp, 0x08
00007f30a29d6245  jmp 0x00007F30A29D307E
00007f30a29d624a  sub rsp, 0x08
00007f30a29d624e  push rax
00007f30a29d624f  push rcx
00007f30a29d6250  push rdx
00007f30a29d6251  push rdi
00007f30a29d6252  push rsi
00007f30a29d6253  push r8
00007f30a29d6255  push r9
00007f30a29d6257  push r10
00007f30a29d6259  push r11
00007f30a29d625b  sub rsp, 0xF0
00007f30a29d6262  vmovaps [rsp], xmm0
00007f30a29d6267  vmovaps [rsp+0x10], xmm1
00007f30a29d626d  vmovaps [rsp+0x20], xmm2
00007f30a29d6273  vmovaps [rsp+0x30], xmm3
00007f30a29d6279  vmovaps [rsp+0x40], xmm4
00007f30a29d627f  vmovaps [rsp+0x50], xmm5
00007f30a29d6285  vmovaps [rsp+0x60], xmm6
00007f30a29d628b  vmovaps [rsp+0x70], xmm7
00007f30a29d6291  vmovaps [rsp+0x80], xmm8
00007f30a29d629a  vmovaps [rsp+0x90], xmm9
00007f30a29d62a3  vmovaps [rsp+0xA0], xmm11
00007f30a29d62ac  vmovaps [rsp+0xB0], xmm12
00007f30a29d62b5  vmovaps [rsp+0xC0], xmm13
00007f30a29d62be  vmovaps [rsp+0xD0], xmm14
00007f30a29d62c7  vmovaps [rsp+0xE0], xmm15
00007f30a29d62d0  sub rsp, 0x30
00007f30a29d62d4  movaps [rsp], xmm10
00007f30a29d62d9  movaps [rsp+0x10], xmm2
00007f30a29d62de  movaps [rsp+0x20], xmm11
00007f30a29d62e4  lea rdi, [rsp]
00007f30a29d62e8  mov esi, 0x00
00007f30a29d62ed  mov rax, 0x5FE955026530
00007f30a29d62f7  call rax
00007f30a29d62f9  movaps xmm10, [rsp]
00007f30a29d62fe  add rsp, 0x30
00007f30a29d6302  vmovaps xmm0, [rsp]
00007f30a29d6307  vmovaps xmm1, [rsp+0x10]
00007f30a29d630d  vmovaps xmm2, [rsp+0x20]
00007f30a29d6313  vmovaps xmm3, [rsp+0x30]
00007f30a29d6319  vmovaps xmm4, [rsp+0x40]
00007f30a29d631f  vmovaps xmm5, [rsp+0x50]
00007f30a29d6325  vmovaps xmm6, [rsp+0x60]
00007f30a29d632b  vmovaps xmm7, [rsp+0x70]
00007f30a29d6331  vmovaps xmm8, [rsp+0x80]
00007f30a29d633a  vmovaps xmm9, [rsp+0x90]
00007f30a29d6343  vmovaps xmm11, [rsp+0xA0]
00007f30a29d634c  vmovaps xmm12, [rsp+0xB0]
00007f30a29d6355  vmovaps xmm13, [rsp+0xC0]
00007f30a29d635e  vmovaps xmm14, [rsp+0xD0]
00007f30a29d6367  vmovaps xmm15, [rsp+0xE0]
00007f30a29d6370  add rsp, 0xF0
00007f30a29d6377  pop r11
00007f30a29d6379  pop r10
00007f30a29d637b  pop r9
00007f30a29d637d  pop r8
00007f30a29d637f  pop rsi
00007f30a29d6380  pop rdi
00007f30a29d6381  pop rdx
00007f30a29d6382  pop rcx
00007f30a29d6383  pop rax
00007f30a29d6384  add rsp, 0x08
00007f30a29d6388  jmp 0x00007F30A29D30B6
00007f30a29d638d  sub rsp, 0x08
00007f30a29d6391  push rax
00007f30a29d6392  push rcx
00007f30a29d6393  push rdx
00007f30a29d6394  push rdi
00007f30a29d6395  push rsi
00007f30a29d6396  push r8
00007f30a29d6398  push r9
00007f30a29d639a  push r10
00007f30a29d639c  push r11
00007f30a29d639e  sub rsp, 0xF0
00007f30a29d63a5  vmovaps [rsp], xmm0
00007f30a29d63aa  vmovaps [rsp+0x10], xmm1
00007f30a29d63b0  vmovaps [rsp+0x20], xmm2
00007f30a29d63b6  vmovaps [rsp+0x30], xmm3
00007f30a29d63bc  vmovaps [rsp+0x40], xmm4
00007f30a29d63c2  vmovaps [rsp+0x50], xmm5
00007f30a29d63c8  vmovaps [rsp+0x60], xmm6
00007f30a29d63ce  vmovaps [rsp+0x70], xmm7
00007f30a29d63d4  vmovaps [rsp+0x80], xmm8
00007f30a29d63dd  vmovaps [rsp+0x90], xmm9
00007f30a29d63e6  vmovaps [rsp+0xA0], xmm10
00007f30a29d63ef  vmovaps [rsp+0xB0], xmm12
00007f30a29d63f8  vmovaps [rsp+0xC0], xmm13
00007f30a29d6401  vmovaps [rsp+0xD0], xmm14
00007f30a29d640a  vmovaps [rsp+0xE0], xmm15
00007f30a29d6413  sub rsp, 0x30
00007f30a29d6417  movaps [rsp], xmm11
00007f30a29d641c  movaps [rsp+0x10], xmm2
00007f30a29d6421  movaps [rsp+0x20], xmm1
00007f30a29d6426  lea rdi, [rsp]
00007f30a29d642a  mov esi, 0x00
00007f30a29d642f  mov rax, 0x5FE955026530
00007f30a29d6439  call rax
00007f30a29d643b  movaps xmm11, [rsp]
00007f30a29d6440  add rsp, 0x30
00007f30a29d6444  vmovaps xmm0, [rsp]
00007f30a29d6449  vmovaps xmm1, [rsp+0x10]
00007f30a29d644f  vmovaps xmm2, [rsp+0x20]
00007f30a29d6455  vmovaps xmm3, [rsp+0x30]
00007f30a29d645b  vmovaps xmm4, [rsp+0x40]
00007f30a29d6461  vmovaps xmm5, [rsp+0x50]
00007f30a29d6467  vmovaps xmm6, [rsp+0x60]
00007f30a29d646d  vmovaps xmm7, [rsp+0x70]
00007f30a29d6473  vmovaps xmm8, [rsp+0x80]
00007f30a29d647c  vmovaps xmm9, [rsp+0x90]
00007f30a29d6485  vmovaps xmm10, [rsp+0xA0]
00007f30a29d648e  vmovaps xmm12, [rsp+0xB0]
00007f30a29d6497  vmovaps xmm13, [rsp+0xC0]
00007f30a29d64a0  vmovaps xmm14, [rsp+0xD0]
00007f30a29d64a9  vmovaps xmm15, [rsp+0xE0]
00007f30a29d64b2  add rsp, 0xF0
00007f30a29d64b9  pop r11
00007f30a29d64bb  pop r10
00007f30a29d64bd  pop r9
00007f30a29d64bf  pop r8
00007f30a29d64c1  pop rsi
00007f30a29d64c2  pop rdi
00007f30a29d64c3  pop rdx
00007f30a29d64c4  pop rcx
00007f30a29d64c5  pop rax
00007f30a29d64c6  add rsp, 0x08
00007f30a29d64ca  jmp 0x00007F30A29D30F2
00007f30a29d64cf  sub rsp, 0x08
00007f30a29d64d3  push rax
00007f30a29d64d4  push rcx
00007f30a29d64d5  push rdx
00007f30a29d64d6  push rdi
00007f30a29d64d7  push rsi
00007f30a29d64d8  push r8
00007f30a29d64da  push r9
00007f30a29d64dc  push r10
00007f30a29d64de  push r11
00007f30a29d64e0  sub rsp, 0xF0
00007f30a29d64e7  vmovaps [rsp], xmm0
00007f30a29d64ec  vmovaps [rsp+0x10], xmm2
00007f30a29d64f2  vmovaps [rsp+0x20], xmm3
00007f30a29d64f8  vmovaps [rsp+0x30], xmm4
00007f30a29d64fe  vmovaps [rsp+0x40], xmm5
00007f30a29d6504  vmovaps [rsp+0x50], xmm6
00007f30a29d650a  vmovaps [rsp+0x60], xmm7
00007f30a29d6510  vmovaps [rsp+0x70], xmm8
00007f30a29d6516  vmovaps [rsp+0x80], xmm9
00007f30a29d651f  vmovaps [rsp+0x90], xmm10
00007f30a29d6528  vmovaps [rsp+0xA0], xmm11
00007f30a29d6531  vmovaps [rsp+0xB0], xmm12
00007f30a29d653a  vmovaps [rsp+0xC0], xmm13
00007f30a29d6543  vmovaps [rsp+0xD0], xmm14
00007f30a29d654c  vmovaps [rsp+0xE0], xmm15
00007f30a29d6555  sub rsp, 0x30
00007f30a29d6559  movaps [rsp], xmm1
00007f30a29d655d  movaps [rsp+0x10], xmm14
00007f30a29d6563  movaps [rsp+0x20], xmm6
00007f30a29d6568  lea rdi, [rsp]
00007f30a29d656c  mov esi, 0x00
00007f30a29d6571  mov rax, 0x5FE955026530
00007f30a29d657b  call rax
00007f30a29d657d  movaps xmm1, [rsp]
00007f30a29d6581  add rsp, 0x30
00007f30a29d6585  vmovaps xmm0, [rsp]
00007f30a29d658a  vmovaps xmm2, [rsp+0x10]
00007f30a29d6590  vmovaps xmm3, [rsp+0x20]
00007f30a29d6596  vmovaps xmm4, [rsp+0x30]
00007f30a29d659c  vmovaps xmm5, [rsp+0x40]
00007f30a29d65a2  vmovaps xmm6, [rsp+0x50]
00007f30a29d65a8  vmovaps xmm7, [rsp+0x60]
00007f30a29d65ae  vmovaps xmm8, [rsp+0x70]
00007f30a29d65b4  vmovaps xmm9, [rsp+0x80]
00007f30a29d65bd  vmovaps xmm10, [rsp+0x90]
00007f30a29d65c6  vmovaps xmm11, [rsp+0xA0]
00007f30a29d65cf  vmovaps xmm12, [rsp+0xB0]
00007f30a29d65d8  vmovaps xmm13, [rsp+0xC0]
00007f30a29d65e1  vmovaps xmm14, [rsp+0xD0]
00007f30a29d65ea  vmovaps xmm15, [rsp+0xE0]
00007f30a29d65f3  add rsp, 0xF0
00007f30a29d65fa  pop r11
00007f30a29d65fc  pop r10
00007f30a29d65fe  pop r9
00007f30a29d6600  pop r8
00007f30a29d6602  pop rsi
00007f30a29d6603  pop rdi
00007f30a29d6604  pop rdx
00007f30a29d6605  pop rcx
00007f30a29d6606  pop rax
00007f30a29d6607  add rsp, 0x08
00007f30a29d660b  jmp 0x00007F30A29D310B
00007f30a29d6610  sub rsp, 0x08
00007f30a29d6614  push rax
00007f30a29d6615  push rcx
00007f30a29d6616  push rdx
00007f30a29d6617  push rdi
00007f30a29d6618  push rsi
00007f30a29d6619  push r8
00007f30a29d661b  push r9
00007f30a29d661d  push r10
00007f30a29d661f  push r11
00007f30a29d6621  sub rsp, 0xF0
00007f30a29d6628  vmovaps [rsp], xmm0
00007f30a29d662d  vmovaps [rsp+0x10], xmm1
00007f30a29d6633  vmovaps [rsp+0x20], xmm2
00007f30a29d6639  vmovaps [rsp+0x30], xmm3
00007f30a29d663f  vmovaps [rsp+0x40], xmm4
00007f30a29d6645  vmovaps [rsp+0x50], xmm5
00007f30a29d664b  vmovaps [rsp+0x60], xmm6
00007f30a29d6651  vmovaps [rsp+0x70], xmm7
00007f30a29d6657  vmovaps [rsp+0x80], xmm8
00007f30a29d6660  vmovaps [rsp+0x90], xmm9
00007f30a29d6669  vmovaps [rsp+0xA0], xmm10
00007f30a29d6672  vmovaps [rsp+0xB0], xmm11
00007f30a29d667b  vmovaps [rsp+0xC0], xmm12
00007f30a29d6684  vmovaps [rsp+0xD0], xmm13
00007f30a29d668d  vmovaps [rsp+0xE0], xmm14
00007f30a29d6696  sub rsp, 0x30
00007f30a29d669a  movaps [rsp], xmm15
00007f30a29d669f  movaps [rsp+0x10], xmm14
00007f30a29d66a5  movaps [rsp+0x20], xmm5
00007f30a29d66aa  lea rdi, [rsp]
00007f30a29d66ae  mov esi, 0x00
00007f30a29d66b3  mov rax, 0x5FE955026530
00007f30a29d66bd  call rax
00007f30a29d66bf  movaps xmm15, [rsp]
00007f30a29d66c4  add rsp, 0x30
00007f30a29d66c8  vmovaps xmm0, [rsp]
00007f30a29d66cd  vmovaps xmm1, [rsp+0x10]
00007f30a29d66d3  vmovaps xmm2, [rsp+0x20]
00007f30a29d66d9  vmovaps xmm3, [rsp+0x30]
00007f30a29d66df  vmovaps xmm4, [rsp+0x40]
00007f30a29d66e5  vmovaps xmm5, [rsp+0x50]
00007f30a29d66eb  vmovaps xmm6, [rsp+0x60]
00007f30a29d66f1  vmovaps xmm7, [rsp+0x70]
00007f30a29d66f7  vmovaps xmm8, [rsp+0x80]
00007f30a29d6700  vmovaps xmm9, [rsp+0x90]
00007f30a29d6709  vmovaps xmm10, [rsp+0xA0]
00007f30a29d6712  vmovaps xmm11, [rsp+0xB0]
00007f30a29d671b  vmovaps xmm12, [rsp+0xC0]
00007f30a29d6724  vmovaps xmm13, [rsp+0xD0]
00007f30a29d672d  vmovaps xmm14, [rsp+0xE0]
00007f30a29d6736  add rsp, 0xF0
00007f30a29d673d  pop r11
00007f30a29d673f  pop r10
00007f30a29d6741  pop r9
00007f30a29d6743  pop r8
00007f30a29d6745  pop rsi
00007f30a29d6746  pop rdi
00007f30a29d6747  pop rdx
00007f30a29d6748  pop rcx
00007f30a29d6749  pop rax
00007f30a29d674a  add rsp, 0x08
00007f30a29d674e  jmp 0x00007F30A29D312B
00007f30a29d6753  sub rsp, 0x08
00007f30a29d6757  push rax
00007f30a29d6758  push rcx
00007f30a29d6759  push rdx
00007f30a29d675a  push rdi
00007f30a29d675b  push rsi
00007f30a29d675c  push r8
00007f30a29d675e  push r9
00007f30a29d6760  push r10
00007f30a29d6762  push r11
00007f30a29d6764  sub rsp, 0xF0
00007f30a29d676b  vmovaps [rsp], xmm0
00007f30a29d6770  vmovaps [rsp+0x10], xmm1
00007f30a29d6776  vmovaps [rsp+0x20], xmm2
00007f30a29d677c  vmovaps [rsp+0x30], xmm3
00007f30a29d6782  vmovaps [rsp+0x40], xmm4
00007f30a29d6788  vmovaps [rsp+0x50], xmm5
00007f30a29d678e  vmovaps [rsp+0x60], xmm7
00007f30a29d6794  vmovaps [rsp+0x70], xmm8
00007f30a29d679a  vmovaps [rsp+0x80], xmm9
00007f30a29d67a3  vmovaps [rsp+0x90], xmm10
00007f30a29d67ac  vmovaps [rsp+0xA0], xmm11
00007f30a29d67b5  vmovaps [rsp+0xB0], xmm12
00007f30a29d67be  vmovaps [rsp+0xC0], xmm13
00007f30a29d67c7  vmovaps [rsp+0xD0], xmm14
00007f30a29d67d0  vmovaps [rsp+0xE0], xmm15
00007f30a29d67d9  sub rsp, 0x30
00007f30a29d67dd  movaps [rsp], xmm6
00007f30a29d67e1  movaps [rsp+0x10], xmm9
00007f30a29d67e7  movaps [rsp+0x20], xmm14
00007f30a29d67ed  lea rdi, [rsp]
00007f30a29d67f1  mov esi, 0x00
00007f30a29d67f6  mov rax, 0x5FE955026530
00007f30a29d6800  call rax
00007f30a29d6802  movaps xmm6, [rsp]
00007f30a29d6806  add rsp, 0x30
00007f30a29d680a  vmovaps xmm0, [rsp]
00007f30a29d680f  vmovaps xmm1, [rsp+0x10]
00007f30a29d6815  vmovaps xmm2, [rsp+0x20]
00007f30a29d681b  vmovaps xmm3, [rsp+0x30]
00007f30a29d6821  vmovaps xmm4, [rsp+0x40]
00007f30a29d6827  vmovaps xmm5, [rsp+0x50]
00007f30a29d682d  vmovaps xmm7, [rsp+0x60]
00007f30a29d6833  vmovaps xmm8, [rsp+0x70]
00007f30a29d6839  vmovaps xmm9, [rsp+0x80]
00007f30a29d6842  vmovaps xmm10, [rsp+0x90]
00007f30a29d684b  vmovaps xmm11, [rsp+0xA0]
00007f30a29d6854  vmovaps xmm12, [rsp+0xB0]
00007f30a29d685d  vmovaps xmm13, [rsp+0xC0]
00007f30a29d6866  vmovaps xmm14, [rsp+0xD0]
00007f30a29d686f  vmovaps xmm15, [rsp+0xE0]
00007f30a29d6878  add rsp, 0xF0
00007f30a29d687f  pop r11
00007f30a29d6881  pop r10
00007f30a29d6883  pop r9
00007f30a29d6885  pop r8
00007f30a29d6887  pop rsi
00007f30a29d6888  pop rdi
00007f30a29d6889  pop rdx
00007f30a29d688a  pop rcx
00007f30a29d688b  pop rax
00007f30a29d688c  add rsp, 0x08
00007f30a29d6890  jmp 0x00007F30A29D3153
00007f30a29d6895  sub rsp, 0x08
00007f30a29d6899  push rax
00007f30a29d689a  push rcx
00007f30a29d689b  push rdx
00007f30a29d689c  push rdi
00007f30a29d689d  push rsi
00007f30a29d689e  push r8
00007f30a29d68a0  push r9
00007f30a29d68a2  push r10
00007f30a29d68a4  push r11
00007f30a29d68a6  sub rsp, 0xF0
00007f30a29d68ad  vmovaps [rsp], xmm0
00007f30a29d68b2  vmovaps [rsp+0x10], xmm1
00007f30a29d68b8  vmovaps [rsp+0x20], xmm2
00007f30a29d68be  vmovaps [rsp+0x30], xmm3
00007f30a29d68c4  vmovaps [rsp+0x40], xmm4
00007f30a29d68ca  vmovaps [rsp+0x50], xmm5
00007f30a29d68d0  vmovaps [rsp+0x60], xmm6
00007f30a29d68d6  vmovaps [rsp+0x70], xmm7
00007f30a29d68dc  vmovaps [rsp+0x80], xmm8
00007f30a29d68e5  vmovaps [rsp+0x90], xmm9
00007f30a29d68ee  vmovaps [rsp+0xA0], xmm10
00007f30a29d68f7  vmovaps [rsp+0xB0], xmm11
00007f30a29d6900  vmovaps [rsp+0xC0], xmm12
00007f30a29d6909  vmovaps [rsp+0xD0], xmm13
00007f30a29d6912  vmovaps [rsp+0xE0], xmm15
00007f30a29d691b  sub rsp, 0x30
00007f30a29d691f  movaps [rsp], xmm14
00007f30a29d6924  movaps [rsp+0x10], xmm9
00007f30a29d692a  movaps [rsp+0x20], xmm13
00007f30a29d6930  lea rdi, [rsp]
00007f30a29d6934  mov esi, 0x00
00007f30a29d6939  mov rax, 0x5FE955026530
00007f30a29d6943  call rax
00007f30a29d6945  movaps xmm14, [rsp]
00007f30a29d694a  add rsp, 0x30
00007f30a29d694e  vmovaps xmm0, [rsp]
00007f30a29d6953  vmovaps xmm1, [rsp+0x10]
00007f30a29d6959  vmovaps xmm2, [rsp+0x20]
00007f30a29d695f  vmovaps xmm3, [rsp+0x30]
00007f30a29d6965  vmovaps xmm4, [rsp+0x40]
00007f30a29d696b  vmovaps xmm5, [rsp+0x50]
00007f30a29d6971  vmovaps xmm6, [rsp+0x60]
00007f30a29d6977  vmovaps xmm7, [rsp+0x70]
00007f30a29d697d  vmovaps xmm8, [rsp+0x80]
00007f30a29d6986  vmovaps xmm9, [rsp+0x90]
00007f30a29d698f  vmovaps xmm10, [rsp+0xA0]
00007f30a29d6998  vmovaps xmm11, [rsp+0xB0]
00007f30a29d69a1  vmovaps xmm12, [rsp+0xC0]
00007f30a29d69aa  vmovaps xmm13, [rsp+0xD0]
00007f30a29d69b3  vmovaps xmm15, [rsp+0xE0]
00007f30a29d69bc  add rsp, 0xF0
00007f30a29d69c3  pop r11
00007f30a29d69c5  pop r10
00007f30a29d69c7  pop r9
00007f30a29d69c9  pop r8
00007f30a29d69cb  pop rsi
00007f30a29d69cc  pop rdi
00007f30a29d69cd  pop rdx
00007f30a29d69ce  pop rcx
00007f30a29d69cf  pop rax
00007f30a29d69d0  add rsp, 0x08
00007f30a29d69d4  jmp 0x00007F30A29D3176
00007f30a29d69d9  sub rsp, 0x08
00007f30a29d69dd  push rax
00007f30a29d69de  push rcx
00007f30a29d69df  push rdx
00007f30a29d69e0  push rdi
00007f30a29d69e1  push rsi
00007f30a29d69e2  push r8
00007f30a29d69e4  push r9
00007f30a29d69e6  push r10
00007f30a29d69e8  push r11
00007f30a29d69ea  sub rsp, 0xF0
00007f30a29d69f1  vmovaps [rsp], xmm0
00007f30a29d69f6  vmovaps [rsp+0x10], xmm1
00007f30a29d69fc  vmovaps [rsp+0x20], xmm2
00007f30a29d6a02  vmovaps [rsp+0x30], xmm3
00007f30a29d6a08  vmovaps [rsp+0x40], xmm4
00007f30a29d6a0e  vmovaps [rsp+0x50], xmm5
00007f30a29d6a14  vmovaps [rsp+0x60], xmm6
00007f30a29d6a1a  vmovaps [rsp+0x70], xmm7
00007f30a29d6a20  vmovaps [rsp+0x80], xmm8
00007f30a29d6a29  vmovaps [rsp+0x90], xmm9
00007f30a29d6a32  vmovaps [rsp+0xA0], xmm10
00007f30a29d6a3b  vmovaps [rsp+0xB0], xmm11
00007f30a29d6a44  vmovaps [rsp+0xC0], xmm12
00007f30a29d6a4d  vmovaps [rsp+0xD0], xmm14
00007f30a29d6a56  vmovaps [rsp+0xE0], xmm15
00007f30a29d6a5f  sub rsp, 0x30
00007f30a29d6a63  movaps [rsp], xmm13
00007f30a29d6a68  movaps [rsp+0x10], xmm9
00007f30a29d6a6e  movaps [rsp+0x20], xmm10
00007f30a29d6a74  lea rdi, [rsp]
00007f30a29d6a78  mov esi, 0x00
00007f30a29d6a7d  mov rax, 0x5FE955026530
00007f30a29d6a87  call rax
00007f30a29d6a89  movaps xmm13, [rsp]
00007f30a29d6a8e  add rsp, 0x30
00007f30a29d6a92  vmovaps xmm0, [rsp]
00007f30a29d6a97  vmovaps xmm1, [rsp+0x10]
00007f30a29d6a9d  vmovaps xmm2, [rsp+0x20]
00007f30a29d6aa3  vmovaps xmm3, [rsp+0x30]
00007f30a29d6aa9  vmovaps xmm4, [rsp+0x40]
00007f30a29d6aaf  vmovaps xmm5, [rsp+0x50]
00007f30a29d6ab5  vmovaps xmm6, [rsp+0x60]
00007f30a29d6abb  vmovaps xmm7, [rsp+0x70]
00007f30a29d6ac1  vmovaps xmm8, [rsp+0x80]
00007f30a29d6aca  vmovaps xmm9, [rsp+0x90]
00007f30a29d6ad3  vmovaps xmm10, [rsp+0xA0]
00007f30a29d6adc  vmovaps xmm11, [rsp+0xB0]
00007f30a29d6ae5  vmovaps xmm12, [rsp+0xC0]
00007f30a29d6aee  vmovaps xmm14, [rsp+0xD0]
00007f30a29d6af7  vmovaps xmm15, [rsp+0xE0]
00007f30a29d6b00  add rsp, 0xF0
00007f30a29d6b07  pop r11
00007f30a29d6b09  pop r10
00007f30a29d6b0b  pop r9
00007f30a29d6b0d  pop r8
00007f30a29d6b0f  pop rsi
00007f30a29d6b10  pop rdi
00007f30a29d6b11  pop rdx
00007f30a29d6b12  pop rcx
00007f30a29d6b13  pop rax
00007f30a29d6b14  add rsp, 0x08
00007f30a29d6b18  jmp 0x00007F30A29D3196
00007f30a29d6b1d  call 0x00007F30A280AFE0
00007f30a29d6b22  jmp 0x00007F30A29D31EB
00007f30a29d6b27  sub rsp, 0x08
00007f30a29d6b2b  push rax
00007f30a29d6b2c  push rcx
00007f30a29d6b2d  push rdx
00007f30a29d6b2e  push rdi
00007f30a29d6b2f  push rsi
00007f30a29d6b30  push r8
00007f30a29d6b32  push r9
00007f30a29d6b34  push r10
00007f30a29d6b36  push r11
00007f30a29d6b38  sub rsp, 0xF0
00007f30a29d6b3f  vmovaps [rsp], xmm0
00007f30a29d6b44  vmovaps [rsp+0x10], xmm1
00007f30a29d6b4a  vmovaps [rsp+0x20], xmm2
00007f30a29d6b50  vmovaps [rsp+0x30], xmm3
00007f30a29d6b56  vmovaps [rsp+0x40], xmm4
00007f30a29d6b5c  vmovaps [rsp+0x50], xmm5
00007f30a29d6b62  vmovaps [rsp+0x60], xmm6
00007f30a29d6b68  vmovaps [rsp+0x70], xmm7
00007f30a29d6b6e  vmovaps [rsp+0x80], xmm8
00007f30a29d6b77  vmovaps [rsp+0x90], xmm10
00007f30a29d6b80  vmovaps [rsp+0xA0], xmm11
00007f30a29d6b89  vmovaps [rsp+0xB0], xmm12
00007f30a29d6b92  vmovaps [rsp+0xC0], xmm13
00007f30a29d6b9b  vmovaps [rsp+0xD0], xmm14
00007f30a29d6ba4  vmovaps [rsp+0xE0], xmm15
00007f30a29d6bad  sub rsp, 0x30
00007f30a29d6bb1  movaps [rsp], xmm9
00007f30a29d6bb6  movaps [rsp+0x10], xmm8
00007f30a29d6bbc  movaps [rsp+0x20], xmm10
00007f30a29d6bc2  lea rdi, [rsp]
00007f30a29d6bc6  mov esi, 0x00
00007f30a29d6bcb  mov rax, 0x5FE955026530
00007f30a29d6bd5  call rax
00007f30a29d6bd7  movaps xmm9, [rsp]
00007f30a29d6bdc  add rsp, 0x30
00007f30a29d6be0  vmovaps xmm0, [rsp]
00007f30a29d6be5  vmovaps xmm1, [rsp+0x10]
00007f30a29d6beb  vmovaps xmm2, [rsp+0x20]
00007f30a29d6bf1  vmovaps xmm3, [rsp+0x30]
00007f30a29d6bf7  vmovaps xmm4, [rsp+0x40]
00007f30a29d6bfd  vmovaps xmm5, [rsp+0x50]
00007f30a29d6c03  vmovaps xmm6, [rsp+0x60]
00007f30a29d6c09  vmovaps xmm7, [rsp+0x70]
00007f30a29d6c0f  vmovaps xmm8, [rsp+0x80]
00007f30a29d6c18  vmovaps xmm10, [rsp+0x90]
00007f30a29d6c21  vmovaps xmm11, [rsp+0xA0]
00007f30a29d6c2a  vmovaps xmm12, [rsp+0xB0]
00007f30a29d6c33  vmovaps xmm13, [rsp+0xC0]
00007f30a29d6c3c  vmovaps xmm14, [rsp+0xD0]
00007f30a29d6c45  vmovaps xmm15, [rsp+0xE0]
00007f30a29d6c4e  add rsp, 0xF0
00007f30a29d6c55  pop r11
00007f30a29d6c57  pop r10
00007f30a29d6c59  pop r9
00007f30a29d6c5b  pop r8
00007f30a29d6c5d  pop rsi
00007f30a29d6c5e  pop rdi
00007f30a29d6c5f  pop rdx
00007f30a29d6c60  pop rcx
00007f30a29d6c61  pop rax
00007f30a29d6c62  add rsp, 0x08
00007f30a29d6c66  jmp 0x00007F30A29D321C
00007f30a29d6c6b  sub rsp, 0x08
00007f30a29d6c6f  push rax
00007f30a29d6c70  push rcx
00007f30a29d6c71  push rdx
00007f30a29d6c72  push rdi
00007f30a29d6c73  push rsi
00007f30a29d6c74  push r8
00007f30a29d6c76  push r9
00007f30a29d6c78  push r10
00007f30a29d6c7a  push r11
00007f30a29d6c7c  sub rsp, 0xF0
00007f30a29d6c83  vmovaps [rsp], xmm0
00007f30a29d6c88  vmovaps [rsp+0x10], xmm1
00007f30a29d6c8e  vmovaps [rsp+0x20], xmm2
00007f30a29d6c94  vmovaps [rsp+0x30], xmm3
00007f30a29d6c9a  vmovaps [rsp+0x40], xmm4
00007f30a29d6ca0  vmovaps [rsp+0x50], xmm5
00007f30a29d6ca6  vmovaps [rsp+0x60], xmm6
00007f30a29d6cac  vmovaps [rsp+0x70], xmm7
00007f30a29d6cb2  vmovaps [rsp+0x80], xmm8
00007f30a29d6cbb  vmovaps [rsp+0x90], xmm9
00007f30a29d6cc4  vmovaps [rsp+0xA0], xmm11
00007f30a29d6ccd  vmovaps [rsp+0xB0], xmm12
00007f30a29d6cd6  vmovaps [rsp+0xC0], xmm13
00007f30a29d6cdf  vmovaps [rsp+0xD0], xmm14
00007f30a29d6ce8  vmovaps [rsp+0xE0], xmm15
00007f30a29d6cf1  sub rsp, 0x30
00007f30a29d6cf5  movaps [rsp], xmm10
00007f30a29d6cfa  movaps [rsp+0x10], xmm1
00007f30a29d6cff  movaps [rsp+0x20], xmm11
00007f30a29d6d05  lea rdi, [rsp]
00007f30a29d6d09  mov esi, 0x00
00007f30a29d6d0e  mov rax, 0x5FE955026530
00007f30a29d6d18  call rax
00007f30a29d6d1a  movaps xmm10, [rsp]
00007f30a29d6d1f  add rsp, 0x30
00007f30a29d6d23  vmovaps xmm0, [rsp]
00007f30a29d6d28  vmovaps xmm1, [rsp+0x10]
00007f30a29d6d2e  vmovaps xmm2, [rsp+0x20]
00007f30a29d6d34  vmovaps xmm3, [rsp+0x30]
00007f30a29d6d3a  vmovaps xmm4, [rsp+0x40]
00007f30a29d6d40  vmovaps xmm5, [rsp+0x50]
00007f30a29d6d46  vmovaps xmm6, [rsp+0x60]
00007f30a29d6d4c  vmovaps xmm7, [rsp+0x70]
00007f30a29d6d52  vmovaps xmm8, [rsp+0x80]
00007f30a29d6d5b  vmovaps xmm9, [rsp+0x90]
00007f30a29d6d64  vmovaps xmm11, [rsp+0xA0]
00007f30a29d6d6d  vmovaps xmm12, [rsp+0xB0]
00007f30a29d6d76  vmovaps xmm13, [rsp+0xC0]
00007f30a29d6d7f  vmovaps xmm14, [rsp+0xD0]
00007f30a29d6d88  vmovaps xmm15, [rsp+0xE0]
00007f30a29d6d91  add rsp, 0xF0
00007f30a29d6d98  pop r11
00007f30a29d6d9a  pop r10
00007f30a29d6d9c  pop r9
00007f30a29d6d9e  pop r8
00007f30a29d6da0  pop rsi
00007f30a29d6da1  pop rdi
00007f30a29d6da2  pop rdx
00007f30a29d6da3  pop rcx
00007f30a29d6da4  pop rax
00007f30a29d6da5  add rsp, 0x08
00007f30a29d6da9  jmp 0x00007F30A29D3237
00007f30a29d6dae  sub rsp, 0x08
00007f30a29d6db2  push rax
00007f30a29d6db3  push rcx
00007f30a29d6db4  push rdx
00007f30a29d6db5  push rdi
00007f30a29d6db6  push rsi
00007f30a29d6db7  push r8
00007f30a29d6db9  push r9
00007f30a29d6dbb  push r10
00007f30a29d6dbd  push r11
00007f30a29d6dbf  sub rsp, 0xF0
00007f30a29d6dc6  vmovaps [rsp], xmm0
00007f30a29d6dcb  vmovaps [rsp+0x10], xmm2
00007f30a29d6dd1  vmovaps [rsp+0x20], xmm3
00007f30a29d6dd7  vmovaps [rsp+0x30], xmm4
00007f30a29d6ddd  vmovaps [rsp+0x40], xmm5
00007f30a29d6de3  vmovaps [rsp+0x50], xmm6
00007f30a29d6de9  vmovaps [rsp+0x60], xmm7
00007f30a29d6def  vmovaps [rsp+0x70], xmm8
00007f30a29d6df5  vmovaps [rsp+0x80], xmm9
00007f30a29d6dfe  vmovaps [rsp+0x90], xmm10
00007f30a29d6e07  vmovaps [rsp+0xA0], xmm11
00007f30a29d6e10  vmovaps [rsp+0xB0], xmm12
00007f30a29d6e19  vmovaps [rsp+0xC0], xmm13
00007f30a29d6e22  vmovaps [rsp+0xD0], xmm14
00007f30a29d6e2b  vmovaps [rsp+0xE0], xmm15
00007f30a29d6e34  sub rsp, 0x30
00007f30a29d6e38  movaps [rsp], xmm1
00007f30a29d6e3c  movaps [rsp+0x10], xmm15
00007f30a29d6e42  movaps [rsp+0x20], xmm6
00007f30a29d6e47  lea rdi, [rsp]
00007f30a29d6e4b  mov esi, 0x00
00007f30a29d6e50  mov rax, 0x5FE955026530
00007f30a29d6e5a  call rax
00007f30a29d6e5c  movaps xmm1, [rsp]
00007f30a29d6e60  add rsp, 0x30
00007f30a29d6e64  vmovaps xmm0, [rsp]
00007f30a29d6e69  vmovaps xmm2, [rsp+0x10]
00007f30a29d6e6f  vmovaps xmm3, [rsp+0x20]
00007f30a29d6e75  vmovaps xmm4, [rsp+0x30]
00007f30a29d6e7b  vmovaps xmm5, [rsp+0x40]
00007f30a29d6e81  vmovaps xmm6, [rsp+0x50]
00007f30a29d6e87  vmovaps xmm7, [rsp+0x60]
00007f30a29d6e8d  vmovaps xmm8, [rsp+0x70]
00007f30a29d6e93  vmovaps xmm9, [rsp+0x80]
00007f30a29d6e9c  vmovaps xmm10, [rsp+0x90]
00007f30a29d6ea5  vmovaps xmm11, [rsp+0xA0]
00007f30a29d6eae  vmovaps xmm12, [rsp+0xB0]
00007f30a29d6eb7  vmovaps xmm13, [rsp+0xC0]
00007f30a29d6ec0  vmovaps xmm14, [rsp+0xD0]
00007f30a29d6ec9  vmovaps xmm15, [rsp+0xE0]
00007f30a29d6ed2  add rsp, 0xF0
00007f30a29d6ed9  pop r11
00007f30a29d6edb  pop r10
00007f30a29d6edd  pop r9
00007f30a29d6edf  pop r8
00007f30a29d6ee1  pop rsi
00007f30a29d6ee2  pop rdi
00007f30a29d6ee3  pop rdx
00007f30a29d6ee4  pop rcx
00007f30a29d6ee5  pop rax
00007f30a29d6ee6  add rsp, 0x08
00007f30a29d6eea  jmp 0x00007F30A29D3250
00007f30a29d6eef  sub rsp, 0x08
00007f30a29d6ef3  push rax
00007f30a29d6ef4  push rcx
00007f30a29d6ef5  push rdx
00007f30a29d6ef6  push rdi
00007f30a29d6ef7  push rsi
00007f30a29d6ef8  push r8
00007f30a29d6efa  push r9
00007f30a29d6efc  push r10
00007f30a29d6efe  push r11
00007f30a29d6f00  sub rsp, 0xF0
00007f30a29d6f07  vmovaps [rsp], xmm0
00007f30a29d6f0c  vmovaps [rsp+0x10], xmm1
00007f30a29d6f12  vmovaps [rsp+0x20], xmm2
00007f30a29d6f18  vmovaps [rsp+0x30], xmm3
00007f30a29d6f1e  vmovaps [rsp+0x40], xmm4
00007f30a29d6f24  vmovaps [rsp+0x50], xmm5
00007f30a29d6f2a  vmovaps [rsp+0x60], xmm6
00007f30a29d6f30  vmovaps [rsp+0x70], xmm7
00007f30a29d6f36  vmovaps [rsp+0x80], xmm8
00007f30a29d6f3f  vmovaps [rsp+0x90], xmm9
00007f30a29d6f48  vmovaps [rsp+0xA0], xmm10
00007f30a29d6f51  vmovaps [rsp+0xB0], xmm12
00007f30a29d6f5a  vmovaps [rsp+0xC0], xmm13
00007f30a29d6f63  vmovaps [rsp+0xD0], xmm14
00007f30a29d6f6c  vmovaps [rsp+0xE0], xmm15
00007f30a29d6f75  sub rsp, 0x30
00007f30a29d6f79  movaps [rsp], xmm11
00007f30a29d6f7e  movaps [rsp+0x10], xmm12
00007f30a29d6f84  movaps [rsp+0x20], xmm15
00007f30a29d6f8a  lea rdi, [rsp]
00007f30a29d6f8e  mov esi, 0x00
00007f30a29d6f93  mov rax, 0x5FE955026530
00007f30a29d6f9d  call rax
00007f30a29d6f9f  movaps xmm11, [rsp]
00007f30a29d6fa4  add rsp, 0x30
00007f30a29d6fa8  vmovaps xmm0, [rsp]
00007f30a29d6fad  vmovaps xmm1, [rsp+0x10]
00007f30a29d6fb3  vmovaps xmm2, [rsp+0x20]
00007f30a29d6fb9  vmovaps xmm3, [rsp+0x30]
00007f30a29d6fbf  vmovaps xmm4, [rsp+0x40]
00007f30a29d6fc5  vmovaps xmm5, [rsp+0x50]
00007f30a29d6fcb  vmovaps xmm6, [rsp+0x60]
00007f30a29d6fd1  vmovaps xmm7, [rsp+0x70]
00007f30a29d6fd7  vmovaps xmm8, [rsp+0x80]
00007f30a29d6fe0  vmovaps xmm9, [rsp+0x90]
00007f30a29d6fe9  vmovaps xmm10, [rsp+0xA0]
00007f30a29d6ff2  vmovaps xmm12, [rsp+0xB0]
00007f30a29d6ffb  vmovaps xmm13, [rsp+0xC0]
00007f30a29d7004  vmovaps xmm14, [rsp+0xD0]
00007f30a29d700d  vmovaps xmm15, [rsp+0xE0]
00007f30a29d7016  add rsp, 0xF0
00007f30a29d701d  pop r11
00007f30a29d701f  pop r10
00007f30a29d7021  pop r9
00007f30a29d7023  pop r8
00007f30a29d7025  pop rsi
00007f30a29d7026  pop rdi
00007f30a29d7027  pop rdx
00007f30a29d7028  pop rcx
00007f30a29d7029  pop rax
00007f30a29d702a  add rsp, 0x08
00007f30a29d702e  jmp 0x00007F30A29D327A
00007f30a29d7033  sub rsp, 0x08
00007f30a29d7037  push rax
00007f30a29d7038  push rcx
00007f30a29d7039  push rdx
00007f30a29d703a  push rdi
00007f30a29d703b  push rsi
00007f30a29d703c  push r8
00007f30a29d703e  push r9
00007f30a29d7040  push r10
00007f30a29d7042  push r11
00007f30a29d7044  sub rsp, 0xF0
00007f30a29d704b  vmovaps [rsp], xmm0
00007f30a29d7050  vmovaps [rsp+0x10], xmm1
00007f30a29d7056  vmovaps [rsp+0x20], xmm2
00007f30a29d705c  vmovaps [rsp+0x30], xmm3
00007f30a29d7062  vmovaps [rsp+0x40], xmm4
00007f30a29d7068  vmovaps [rsp+0x50], xmm5
00007f30a29d706e  vmovaps [rsp+0x60], xmm6
00007f30a29d7074  vmovaps [rsp+0x70], xmm7
00007f30a29d707a  vmovaps [rsp+0x80], xmm8
00007f30a29d7083  vmovaps [rsp+0x90], xmm9
00007f30a29d708c  vmovaps [rsp+0xA0], xmm10
00007f30a29d7095  vmovaps [rsp+0xB0], xmm11
00007f30a29d709e  vmovaps [rsp+0xC0], xmm13
00007f30a29d70a7  vmovaps [rsp+0xD0], xmm14
00007f30a29d70b0  vmovaps [rsp+0xE0], xmm15
00007f30a29d70b9  sub rsp, 0x30
00007f30a29d70bd  movaps [rsp], xmm12
00007f30a29d70c2  movaps [rsp+0x10], xmm8
00007f30a29d70c8  movaps [rsp+0x20], xmm15
00007f30a29d70ce  lea rdi, [rsp]
00007f30a29d70d2  mov esi, 0x00
00007f30a29d70d7  mov rax, 0x5FE955026530
00007f30a29d70e1  call rax
00007f30a29d70e3  movaps xmm12, [rsp]
00007f30a29d70e8  add rsp, 0x30
00007f30a29d70ec  vmovaps xmm0, [rsp]
00007f30a29d70f1  vmovaps xmm1, [rsp+0x10]
00007f30a29d70f7  vmovaps xmm2, [rsp+0x20]
00007f30a29d70fd  vmovaps xmm3, [rsp+0x30]
00007f30a29d7103  vmovaps xmm4, [rsp+0x40]
00007f30a29d7109  vmovaps xmm5, [rsp+0x50]
00007f30a29d710f  vmovaps xmm6, [rsp+0x60]
00007f30a29d7115  vmovaps xmm7, [rsp+0x70]
00007f30a29d711b  vmovaps xmm8, [rsp+0x80]
00007f30a29d7124  vmovaps xmm9, [rsp+0x90]
00007f30a29d712d  vmovaps xmm10, [rsp+0xA0]
00007f30a29d7136  vmovaps xmm11, [rsp+0xB0]
00007f30a29d713f  vmovaps xmm13, [rsp+0xC0]
00007f30a29d7148  vmovaps xmm14, [rsp+0xD0]
00007f30a29d7151  vmovaps xmm15, [rsp+0xE0]
00007f30a29d715a  add rsp, 0xF0
00007f30a29d7161  pop r11
00007f30a29d7163  pop r10
00007f30a29d7165  pop r9
00007f30a29d7167  pop r8
00007f30a29d7169  pop rsi
00007f30a29d716a  pop rdi
00007f30a29d716b  pop rdx
00007f30a29d716c  pop rcx
00007f30a29d716d  pop rax
00007f30a29d716e  add rsp, 0x08
00007f30a29d7172  jmp 0x00007F30A29D32A9
00007f30a29d7177  sub rsp, 0x08
00007f30a29d717b  push rax
00007f30a29d717c  push rcx
00007f30a29d717d  push rdx
00007f30a29d717e  push rdi
00007f30a29d717f  push rsi
00007f30a29d7180  push r8
00007f30a29d7182  push r9
00007f30a29d7184  push r10
00007f30a29d7186  push r11
00007f30a29d7188  sub rsp, 0xF0
00007f30a29d718f  vmovaps [rsp], xmm0
00007f30a29d7194  vmovaps [rsp+0x10], xmm1
00007f30a29d719a  vmovaps [rsp+0x20], xmm2
00007f30a29d71a0  vmovaps [rsp+0x30], xmm3
00007f30a29d71a6  vmovaps [rsp+0x40], xmm4
00007f30a29d71ac  vmovaps [rsp+0x50], xmm5
00007f30a29d71b2  vmovaps [rsp+0x60], xmm6
00007f30a29d71b8  vmovaps [rsp+0x70], xmm7
00007f30a29d71be  vmovaps [rsp+0x80], xmm9
00007f30a29d71c7  vmovaps [rsp+0x90], xmm10
00007f30a29d71d0  vmovaps [rsp+0xA0], xmm11
00007f30a29d71d9  vmovaps [rsp+0xB0], xmm12
00007f30a29d71e2  vmovaps [rsp+0xC0], xmm13
00007f30a29d71eb  vmovaps [rsp+0xD0], xmm14
00007f30a29d71f4  vmovaps [rsp+0xE0], xmm15
00007f30a29d71fd  sub rsp, 0x30
00007f30a29d7201  movaps [rsp], xmm8
00007f30a29d7206  movaps [rsp+0x10], xmm7
00007f30a29d720b  movaps [rsp+0x20], xmm15
00007f30a29d7211  lea rdi, [rsp]
00007f30a29d7215  mov esi, 0x00
00007f30a29d721a  mov rax, 0x5FE955026530
00007f30a29d7224  call rax
00007f30a29d7226  movaps xmm8, [rsp]
00007f30a29d722b  add rsp, 0x30
00007f30a29d722f  vmovaps xmm0, [rsp]
00007f30a29d7234  vmovaps xmm1, [rsp+0x10]
00007f30a29d723a  vmovaps xmm2, [rsp+0x20]
00007f30a29d7240  vmovaps xmm3, [rsp+0x30]
00007f30a29d7246  vmovaps xmm4, [rsp+0x40]
00007f30a29d724c  vmovaps xmm5, [rsp+0x50]
00007f30a29d7252  vmovaps xmm6, [rsp+0x60]
00007f30a29d7258  vmovaps xmm7, [rsp+0x70]
00007f30a29d725e  vmovaps xmm9, [rsp+0x80]
00007f30a29d7267  vmovaps xmm10, [rsp+0x90]
00007f30a29d7270  vmovaps xmm11, [rsp+0xA0]
00007f30a29d7279  vmovaps xmm12, [rsp+0xB0]
00007f30a29d7282  vmovaps xmm13, [rsp+0xC0]
00007f30a29d728b  vmovaps xmm14, [rsp+0xD0]
00007f30a29d7294  vmovaps xmm15, [rsp+0xE0]
00007f30a29d729d  add rsp, 0xF0
00007f30a29d72a4  pop r11
00007f30a29d72a6  pop r10
00007f30a29d72a8  pop r9
00007f30a29d72aa  pop r8
00007f30a29d72ac  pop rsi
00007f30a29d72ad  pop rdi
00007f30a29d72ae  pop rdx
00007f30a29d72af  pop rcx
00007f30a29d72b0  pop rax
00007f30a29d72b1  add rsp, 0x08
00007f30a29d72b5  jmp 0x00007F30A29D32CF
00007f30a29d72ba  sub rsp, 0x08
00007f30a29d72be  push rax
00007f30a29d72bf  push rcx
00007f30a29d72c0  push rdx
00007f30a29d72c1  push rdi
00007f30a29d72c2  push rsi
00007f30a29d72c3  push r8
00007f30a29d72c5  push r9
00007f30a29d72c7  push r10
00007f30a29d72c9  push r11
00007f30a29d72cb  sub rsp, 0xF0
00007f30a29d72d2  vmovaps [rsp], xmm0
00007f30a29d72d7  vmovaps [rsp+0x10], xmm1
00007f30a29d72dd  vmovaps [rsp+0x20], xmm2
00007f30a29d72e3  vmovaps [rsp+0x30], xmm3
00007f30a29d72e9  vmovaps [rsp+0x40], xmm4
00007f30a29d72ef  vmovaps [rsp+0x50], xmm5
00007f30a29d72f5  vmovaps [rsp+0x60], xmm6
00007f30a29d72fb  vmovaps [rsp+0x70], xmm7
00007f30a29d7301  vmovaps [rsp+0x80], xmm8
00007f30a29d730a  vmovaps [rsp+0x90], xmm9
00007f30a29d7313  vmovaps [rsp+0xA0], xmm10
00007f30a29d731c  vmovaps [rsp+0xB0], xmm11
00007f30a29d7325  vmovaps [rsp+0xC0], xmm12
00007f30a29d732e  vmovaps [rsp+0xD0], xmm13
00007f30a29d7337  vmovaps [rsp+0xE0], xmm14
00007f30a29d7340  sub rsp, 0x30
00007f30a29d7344  movaps [rsp], xmm15
00007f30a29d7349  movaps [rsp+0x10], xmm14
00007f30a29d734f  movaps [rsp+0x20], xmm9
00007f30a29d7355  lea rdi, [rsp]
00007f30a29d7359  mov esi, 0x00
00007f30a29d735e  mov rax, 0x5FE955026530
00007f30a29d7368  call rax
00007f30a29d736a  movaps xmm15, [rsp]
00007f30a29d736f  add rsp, 0x30
00007f30a29d7373  vmovaps xmm0, [rsp]
00007f30a29d7378  vmovaps xmm1, [rsp+0x10]
00007f30a29d737e  vmovaps xmm2, [rsp+0x20]
00007f30a29d7384  vmovaps xmm3, [rsp+0x30]
00007f30a29d738a  vmovaps xmm4, [rsp+0x40]
00007f30a29d7390  vmovaps xmm5, [rsp+0x50]
00007f30a29d7396  vmovaps xmm6, [rsp+0x60]
00007f30a29d739c  vmovaps xmm7, [rsp+0x70]
00007f30a29d73a2  vmovaps xmm8, [rsp+0x80]
00007f30a29d73ab  vmovaps xmm9, [rsp+0x90]
00007f30a29d73b4  vmovaps xmm10, [rsp+0xA0]
00007f30a29d73bd  vmovaps xmm11, [rsp+0xB0]
00007f30a29d73c6  vmovaps xmm12, [rsp+0xC0]
00007f30a29d73cf  vmovaps xmm13, [rsp+0xD0]
00007f30a29d73d8  vmovaps xmm14, [rsp+0xE0]
00007f30a29d73e1  add rsp, 0xF0
00007f30a29d73e8  pop r11
00007f30a29d73ea  pop r10
00007f30a29d73ec  pop r9
00007f30a29d73ee  pop r8
00007f30a29d73f0  pop rsi
00007f30a29d73f1  pop rdi
00007f30a29d73f2  pop rdx
00007f30a29d73f3  pop rcx
00007f30a29d73f4  pop rax
00007f30a29d73f5  add rsp, 0x08
00007f30a29d73f9  jmp 0x00007F30A29D32E9
00007f30a29d73fe  sub rsp, 0x08
00007f30a29d7402  push rax
00007f30a29d7403  push rcx
00007f30a29d7404  push rdx
00007f30a29d7405  push rdi
00007f30a29d7406  push rsi
00007f30a29d7407  push r8
00007f30a29d7409  push r9
00007f30a29d740b  push r10
00007f30a29d740d  push r11
00007f30a29d740f  sub rsp, 0xF0
00007f30a29d7416  vmovaps [rsp], xmm0
00007f30a29d741b  vmovaps [rsp+0x10], xmm1
00007f30a29d7421  vmovaps [rsp+0x20], xmm2
00007f30a29d7427  vmovaps [rsp+0x30], xmm3
00007f30a29d742d  vmovaps [rsp+0x40], xmm4
00007f30a29d7433  vmovaps [rsp+0x50], xmm5
00007f30a29d7439  vmovaps [rsp+0x60], xmm6
00007f30a29d743f  vmovaps [rsp+0x70], xmm7
00007f30a29d7445  vmovaps [rsp+0x80], xmm8
00007f30a29d744e  vmovaps [rsp+0x90], xmm10
00007f30a29d7457  vmovaps [rsp+0xA0], xmm11
00007f30a29d7460  vmovaps [rsp+0xB0], xmm12
00007f30a29d7469  vmovaps [rsp+0xC0], xmm13
00007f30a29d7472  vmovaps [rsp+0xD0], xmm14
00007f30a29d747b  vmovaps [rsp+0xE0], xmm15
00007f30a29d7484  sub rsp, 0x30
00007f30a29d7488  movaps [rsp], xmm9
00007f30a29d748d  movaps [rsp+0x10], xmm7
00007f30a29d7492  movaps [rsp+0x20], xmm14
00007f30a29d7498  lea rdi, [rsp]
00007f30a29d749c  mov esi, 0x00
00007f30a29d74a1  mov rax, 0x5FE955026530
00007f30a29d74ab  call rax
00007f30a29d74ad  movaps xmm9, [rsp]
00007f30a29d74b2  add rsp, 0x30
00007f30a29d74b6  vmovaps xmm0, [rsp]
00007f30a29d74bb  vmovaps xmm1, [rsp+0x10]
00007f30a29d74c1  vmovaps xmm2, [rsp+0x20]
00007f30a29d74c7  vmovaps xmm3, [rsp+0x30]
00007f30a29d74cd  vmovaps xmm4, [rsp+0x40]
00007f30a29d74d3  vmovaps xmm5, [rsp+0x50]
00007f30a29d74d9  vmovaps xmm6, [rsp+0x60]
00007f30a29d74df  vmovaps xmm7, [rsp+0x70]
00007f30a29d74e5  vmovaps xmm8, [rsp+0x80]
00007f30a29d74ee  vmovaps xmm10, [rsp+0x90]
00007f30a29d74f7  vmovaps xmm11, [rsp+0xA0]
00007f30a29d7500  vmovaps xmm12, [rsp+0xB0]
00007f30a29d7509  vmovaps xmm13, [rsp+0xC0]
00007f30a29d7512  vmovaps xmm14, [rsp+0xD0]
00007f30a29d751b  vmovaps xmm15, [rsp+0xE0]
00007f30a29d7524  add rsp, 0xF0
00007f30a29d752b  pop r11
00007f30a29d752d  pop r10
00007f30a29d752f  pop r9
00007f30a29d7531  pop r8
00007f30a29d7533  pop rsi
00007f30a29d7534  pop rdi
00007f30a29d7535  pop rdx
00007f30a29d7536  pop rcx
00007f30a29d7537  pop rax
00007f30a29d7538  add rsp, 0x08
00007f30a29d753c  jmp 0x00007F30A29D3318
00007f30a29d7541  sub rsp, 0x08
00007f30a29d7545  push rax
00007f30a29d7546  push rcx
00007f30a29d7547  push rdx
00007f30a29d7548  push rdi
00007f30a29d7549  push rsi
00007f30a29d754a  push r8
00007f30a29d754c  push r9
00007f30a29d754e  push r10
00007f30a29d7550  push r11
00007f30a29d7552  sub rsp, 0xF0
00007f30a29d7559  vmovaps [rsp], xmm0
00007f30a29d755e  vmovaps [rsp+0x10], xmm1
00007f30a29d7564  vmovaps [rsp+0x20], xmm2
00007f30a29d756a  vmovaps [rsp+0x30], xmm3
00007f30a29d7570  vmovaps [rsp+0x40], xmm4
00007f30a29d7576  vmovaps [rsp+0x50], xmm5
00007f30a29d757c  vmovaps [rsp+0x60], xmm6
00007f30a29d7582  vmovaps [rsp+0x70], xmm7
00007f30a29d7588  vmovaps [rsp+0x80], xmm8
00007f30a29d7591  vmovaps [rsp+0x90], xmm9
00007f30a29d759a  vmovaps [rsp+0xA0], xmm10
00007f30a29d75a3  vmovaps [rsp+0xB0], xmm11
00007f30a29d75ac  vmovaps [rsp+0xC0], xmm12
00007f30a29d75b5  vmovaps [rsp+0xD0], xmm13
00007f30a29d75be  vmovaps [rsp+0xE0], xmm15
00007f30a29d75c7  sub rsp, 0x30
00007f30a29d75cb  movaps [rsp], xmm14
00007f30a29d75d0  movaps [rsp+0x10], xmm13
00007f30a29d75d6  movaps [rsp+0x20], xmm11
00007f30a29d75dc  lea rdi, [rsp]
00007f30a29d75e0  mov esi, 0x00
00007f30a29d75e5  mov rax, 0x5FE955026530
00007f30a29d75ef  call rax
00007f30a29d75f1  movaps xmm14, [rsp]
00007f30a29d75f6  add rsp, 0x30
00007f30a29d75fa  vmovaps xmm0, [rsp]
00007f30a29d75ff  vmovaps xmm1, [rsp+0x10]
00007f30a29d7605  vmovaps xmm2, [rsp+0x20]
00007f30a29d760b  vmovaps xmm3, [rsp+0x30]
00007f30a29d7611  vmovaps xmm4, [rsp+0x40]
00007f30a29d7617  vmovaps xmm5, [rsp+0x50]
00007f30a29d761d  vmovaps xmm6, [rsp+0x60]
00007f30a29d7623  vmovaps xmm7, [rsp+0x70]
00007f30a29d7629  vmovaps xmm8, [rsp+0x80]
00007f30a29d7632  vmovaps xmm9, [rsp+0x90]
00007f30a29d763b  vmovaps xmm10, [rsp+0xA0]
00007f30a29d7644  vmovaps xmm11, [rsp+0xB0]
00007f30a29d764d  vmovaps xmm12, [rsp+0xC0]
00007f30a29d7656  vmovaps xmm13, [rsp+0xD0]
00007f30a29d765f  vmovaps xmm15, [rsp+0xE0]
00007f30a29d7668  add rsp, 0xF0
00007f30a29d766f  pop r11
00007f30a29d7671  pop r10
00007f30a29d7673  pop r9
00007f30a29d7675  pop r8
00007f30a29d7677  pop rsi
00007f30a29d7678  pop rdi
00007f30a29d7679  pop rdx
00007f30a29d767a  pop rcx
00007f30a29d767b  pop rax
00007f30a29d767c  add rsp, 0x08
00007f30a29d7680  jmp 0x00007F30A29D3332
00007f30a29d7685  sub rsp, 0x08
00007f30a29d7689  push rax
00007f30a29d768a  push rcx
00007f30a29d768b  push rdx
00007f30a29d768c  push rdi
00007f30a29d768d  push rsi
00007f30a29d768e  push r8
00007f30a29d7690  push r9
00007f30a29d7692  push r10
00007f30a29d7694  push r11
00007f30a29d7696  sub rsp, 0xF0
00007f30a29d769d  vmovaps [rsp], xmm0
00007f30a29d76a2  vmovaps [rsp+0x10], xmm1
00007f30a29d76a8  vmovaps [rsp+0x20], xmm2
00007f30a29d76ae  vmovaps [rsp+0x30], xmm3
00007f30a29d76b4  vmovaps [rsp+0x40], xmm4
00007f30a29d76ba  vmovaps [rsp+0x50], xmm5
00007f30a29d76c0  vmovaps [rsp+0x60], xmm6
00007f30a29d76c6  vmovaps [rsp+0x70], xmm7
00007f30a29d76cc  vmovaps [rsp+0x80], xmm8
00007f30a29d76d5  vmovaps [rsp+0x90], xmm9
00007f30a29d76de  vmovaps [rsp+0xA0], xmm10
00007f30a29d76e7  vmovaps [rsp+0xB0], xmm12
00007f30a29d76f0  vmovaps [rsp+0xC0], xmm13
00007f30a29d76f9  vmovaps [rsp+0xD0], xmm14
00007f30a29d7702  vmovaps [rsp+0xE0], xmm15
00007f30a29d770b  sub rsp, 0x30
00007f30a29d770f  movaps [rsp], xmm11
00007f30a29d7714  movaps [rsp+0x10], xmm7
00007f30a29d7719  movaps [rsp+0x20], xmm13
00007f30a29d771f  lea rdi, [rsp]
00007f30a29d7723  mov esi, 0x00
00007f30a29d7728  mov rax, 0x5FE955026530
00007f30a29d7732  call rax
00007f30a29d7734  movaps xmm11, [rsp]
00007f30a29d7739  add rsp, 0x30
00007f30a29d773d  vmovaps xmm0, [rsp]
00007f30a29d7742  vmovaps xmm1, [rsp+0x10]
00007f30a29d7748  vmovaps xmm2, [rsp+0x20]
00007f30a29d774e  vmovaps xmm3, [rsp+0x30]
00007f30a29d7754  vmovaps xmm4, [rsp+0x40]
00007f30a29d775a  vmovaps xmm5, [rsp+0x50]
00007f30a29d7760  vmovaps xmm6, [rsp+0x60]
00007f30a29d7766  vmovaps xmm7, [rsp+0x70]
00007f30a29d776c  vmovaps xmm8, [rsp+0x80]
00007f30a29d7775  vmovaps xmm9, [rsp+0x90]
00007f30a29d777e  vmovaps xmm10, [rsp+0xA0]
00007f30a29d7787  vmovaps xmm12, [rsp+0xB0]
00007f30a29d7790  vmovaps xmm13, [rsp+0xC0]
00007f30a29d7799  vmovaps xmm14, [rsp+0xD0]
00007f30a29d77a2  vmovaps xmm15, [rsp+0xE0]
00007f30a29d77ab  add rsp, 0xF0
00007f30a29d77b2  pop r11
00007f30a29d77b4  pop r10
00007f30a29d77b6  pop r9
00007f30a29d77b8  pop r8
00007f30a29d77ba  pop rsi
00007f30a29d77bb  pop rdi
00007f30a29d77bc  pop rdx
00007f30a29d77bd  pop rcx
00007f30a29d77be  pop rax
00007f30a29d77bf  add rsp, 0x08
00007f30a29d77c3  jmp 0x00007F30A29D335E
00007f30a29d77c8  sub rsp, 0x08
00007f30a29d77cc  push rax
00007f30a29d77cd  push rcx
00007f30a29d77ce  push rdx
00007f30a29d77cf  push rdi
00007f30a29d77d0  push rsi
00007f30a29d77d1  push r8
00007f30a29d77d3  push r9
00007f30a29d77d5  push r10
00007f30a29d77d7  push r11
00007f30a29d77d9  sub rsp, 0xF0
00007f30a29d77e0  vmovaps [rsp], xmm0
00007f30a29d77e5  vmovaps [rsp+0x10], xmm1
00007f30a29d77eb  vmovaps [rsp+0x20], xmm2
00007f30a29d77f1  vmovaps [rsp+0x30], xmm3
00007f30a29d77f7  vmovaps [rsp+0x40], xmm4
00007f30a29d77fd  vmovaps [rsp+0x50], xmm5
00007f30a29d7803  vmovaps [rsp+0x60], xmm6
00007f30a29d7809  vmovaps [rsp+0x70], xmm7
00007f30a29d780f  vmovaps [rsp+0x80], xmm8
00007f30a29d7818  vmovaps [rsp+0x90], xmm9
00007f30a29d7821  vmovaps [rsp+0xA0], xmm10
00007f30a29d782a  vmovaps [rsp+0xB0], xmm11
00007f30a29d7833  vmovaps [rsp+0xC0], xmm12
00007f30a29d783c  vmovaps [rsp+0xD0], xmm14
00007f30a29d7845  vmovaps [rsp+0xE0], xmm15
00007f30a29d784e  sub rsp, 0x30
00007f30a29d7852  movaps [rsp], xmm13
00007f30a29d7857  movaps [rsp+0x10], xmm10
00007f30a29d785d  movaps [rsp+0x20], xmm12
00007f30a29d7863  lea rdi, [rsp]
00007f30a29d7867  mov esi, 0x00
00007f30a29d786c  mov rax, 0x5FE955026530
00007f30a29d7876  call rax
00007f30a29d7878  movaps xmm13, [rsp]
00007f30a29d787d  add rsp, 0x30
00007f30a29d7881  vmovaps xmm0, [rsp]
00007f30a29d7886  vmovaps xmm1, [rsp+0x10]
00007f30a29d788c  vmovaps xmm2, [rsp+0x20]
00007f30a29d7892  vmovaps xmm3, [rsp+0x30]
00007f30a29d7898  vmovaps xmm4, [rsp+0x40]
00007f30a29d789e  vmovaps xmm5, [rsp+0x50]
00007f30a29d78a4  vmovaps xmm6, [rsp+0x60]
00007f30a29d78aa  vmovaps xmm7, [rsp+0x70]
00007f30a29d78b0  vmovaps xmm8, [rsp+0x80]
00007f30a29d78b9  vmovaps xmm9, [rsp+0x90]
00007f30a29d78c2  vmovaps xmm10, [rsp+0xA0]
00007f30a29d78cb  vmovaps xmm11, [rsp+0xB0]
00007f30a29d78d4  vmovaps xmm12, [rsp+0xC0]
00007f30a29d78dd  vmovaps xmm14, [rsp+0xD0]
00007f30a29d78e6  vmovaps xmm15, [rsp+0xE0]
00007f30a29d78ef  add rsp, 0xF0
00007f30a29d78f6  pop r11
00007f30a29d78f8  pop r10
00007f30a29d78fa  pop r9
00007f30a29d78fc  pop r8
00007f30a29d78fe  pop rsi
00007f30a29d78ff  pop rdi
00007f30a29d7900  pop rdx
00007f30a29d7901  pop rcx
00007f30a29d7902  pop rax
00007f30a29d7903  add rsp, 0x08
00007f30a29d7907  jmp 0x00007F30A29D3378
00007f30a29d790c  sub rsp, 0x08
00007f30a29d7910  push rax
00007f30a29d7911  push rcx
00007f30a29d7912  push rdx
00007f30a29d7913  push rdi
00007f30a29d7914  push rsi
00007f30a29d7915  push r8
00007f30a29d7917  push r9
00007f30a29d7919  push r10
00007f30a29d791b  push r11
00007f30a29d791d  sub rsp, 0xF0
00007f30a29d7924  vmovaps [rsp], xmm0
00007f30a29d7929  vmovaps [rsp+0x10], xmm1
00007f30a29d792f  vmovaps [rsp+0x20], xmm2
00007f30a29d7935  vmovaps [rsp+0x30], xmm3
00007f30a29d793b  vmovaps [rsp+0x40], xmm4
00007f30a29d7941  vmovaps [rsp+0x50], xmm5
00007f30a29d7947  vmovaps [rsp+0x60], xmm6
00007f30a29d794d  vmovaps [rsp+0x70], xmm7
00007f30a29d7953  vmovaps [rsp+0x80], xmm8
00007f30a29d795c  vmovaps [rsp+0x90], xmm9
00007f30a29d7965  vmovaps [rsp+0xA0], xmm11
00007f30a29d796e  vmovaps [rsp+0xB0], xmm12
00007f30a29d7977  vmovaps [rsp+0xC0], xmm13
00007f30a29d7980  vmovaps [rsp+0xD0], xmm14
00007f30a29d7989  vmovaps [rsp+0xE0], xmm15
00007f30a29d7992  sub rsp, 0x30
00007f30a29d7996  movaps [rsp], xmm10
00007f30a29d799b  movaps [rsp+0x10], xmm7
00007f30a29d79a0  movaps [rsp+0x20], xmm12
00007f30a29d79a6  lea rdi, [rsp]
00007f30a29d79aa  mov esi, 0x00
00007f30a29d79af  mov rax, 0x5FE955026530
00007f30a29d79b9  call rax
00007f30a29d79bb  movaps xmm10, [rsp]
00007f30a29d79c0  add rsp, 0x30
00007f30a29d79c4  vmovaps xmm0, [rsp]
00007f30a29d79c9  vmovaps xmm1, [rsp+0x10]
00007f30a29d79cf  vmovaps xmm2, [rsp+0x20]
00007f30a29d79d5  vmovaps xmm3, [rsp+0x30]
00007f30a29d79db  vmovaps xmm4, [rsp+0x40]
00007f30a29d79e1  vmovaps xmm5, [rsp+0x50]
00007f30a29d79e7  vmovaps xmm6, [rsp+0x60]
00007f30a29d79ed  vmovaps xmm7, [rsp+0x70]
00007f30a29d79f3  vmovaps xmm8, [rsp+0x80]
00007f30a29d79fc  vmovaps xmm9, [rsp+0x90]
00007f30a29d7a05  vmovaps xmm11, [rsp+0xA0]
00007f30a29d7a0e  vmovaps xmm12, [rsp+0xB0]
00007f30a29d7a17  vmovaps xmm13, [rsp+0xC0]
00007f30a29d7a20  vmovaps xmm14, [rsp+0xD0]
00007f30a29d7a29  vmovaps xmm15, [rsp+0xE0]
00007f30a29d7a32  add rsp, 0xF0
00007f30a29d7a39  pop r11
00007f30a29d7a3b  pop r10
00007f30a29d7a3d  pop r9
00007f30a29d7a3f  pop r8
00007f30a29d7a41  pop rsi
00007f30a29d7a42  pop rdi
00007f30a29d7a43  pop rdx
00007f30a29d7a44  pop rcx
00007f30a29d7a45  pop rax
00007f30a29d7a46  add rsp, 0x08
00007f30a29d7a4a  jmp 0x00007F30A29D33A4
00007f30a29d7a4f  sub rsp, 0x08
00007f30a29d7a53  push rax
00007f30a29d7a54  push rcx
00007f30a29d7a55  push rdx
00007f30a29d7a56  push rdi
00007f30a29d7a57  push rsi
00007f30a29d7a58  push r8
00007f30a29d7a5a  push r9
00007f30a29d7a5c  push r10
00007f30a29d7a5e  push r11
00007f30a29d7a60  sub rsp, 0xF0
00007f30a29d7a67  vmovaps [rsp], xmm0
00007f30a29d7a6c  vmovaps [rsp+0x10], xmm1
00007f30a29d7a72  vmovaps [rsp+0x20], xmm2
00007f30a29d7a78  vmovaps [rsp+0x30], xmm3
00007f30a29d7a7e  vmovaps [rsp+0x40], xmm4
00007f30a29d7a84  vmovaps [rsp+0x50], xmm5
00007f30a29d7a8a  vmovaps [rsp+0x60], xmm6
00007f30a29d7a90  vmovaps [rsp+0x70], xmm7
00007f30a29d7a96  vmovaps [rsp+0x80], xmm8
00007f30a29d7a9f  vmovaps [rsp+0x90], xmm9
00007f30a29d7aa8  vmovaps [rsp+0xA0], xmm10
00007f30a29d7ab1  vmovaps [rsp+0xB0], xmm11
00007f30a29d7aba  vmovaps [rsp+0xC0], xmm13
00007f30a29d7ac3  vmovaps [rsp+0xD0], xmm14
00007f30a29d7acc  vmovaps [rsp+0xE0], xmm15
00007f30a29d7ad5  sub rsp, 0x30
00007f30a29d7ad9  movaps [rsp], xmm12
00007f30a29d7ade  movaps [rsp+0x10], xmm1
00007f30a29d7ae3  movaps [rsp+0x20], xmm8
00007f30a29d7ae9  lea rdi, [rsp]
00007f30a29d7aed  mov esi, 0x00
00007f30a29d7af2  mov rax, 0x5FE955026530
00007f30a29d7afc  call rax
00007f30a29d7afe  movaps xmm12, [rsp]
00007f30a29d7b03  add rsp, 0x30
00007f30a29d7b07  vmovaps xmm0, [rsp]
00007f30a29d7b0c  vmovaps xmm1, [rsp+0x10]
00007f30a29d7b12  vmovaps xmm2, [rsp+0x20]
00007f30a29d7b18  vmovaps xmm3, [rsp+0x30]
00007f30a29d7b1e  vmovaps xmm4, [rsp+0x40]
00007f30a29d7b24  vmovaps xmm5, [rsp+0x50]
00007f30a29d7b2a  vmovaps xmm6, [rsp+0x60]
00007f30a29d7b30  vmovaps xmm7, [rsp+0x70]
00007f30a29d7b36  vmovaps xmm8, [rsp+0x80]
00007f30a29d7b3f  vmovaps xmm9, [rsp+0x90]
00007f30a29d7b48  vmovaps xmm10, [rsp+0xA0]
00007f30a29d7b51  vmovaps xmm11, [rsp+0xB0]
00007f30a29d7b5a  vmovaps xmm13, [rsp+0xC0]
00007f30a29d7b63  vmovaps xmm14, [rsp+0xD0]
00007f30a29d7b6c  vmovaps xmm15, [rsp+0xE0]
00007f30a29d7b75  add rsp, 0xF0
00007f30a29d7b7c  pop r11
00007f30a29d7b7e  pop r10
00007f30a29d7b80  pop r9
00007f30a29d7b82  pop r8
00007f30a29d7b84  pop rsi
00007f30a29d7b85  pop rdi
00007f30a29d7b86  pop rdx
00007f30a29d7b87  pop rcx
00007f30a29d7b88  pop rax
00007f30a29d7b89  add rsp, 0x08
00007f30a29d7b8d  jmp 0x00007F30A29D33BE
00007f30a29d7b92  call 0x00007F30A27FF430
00007f30a29d7b97  jmp 0x00007F30A29D33C8
00007f30a29d7b9c  sub rsp, 0x08
00007f30a29d7ba0  push rax
00007f30a29d7ba1  push rcx
00007f30a29d7ba2  push rdx
00007f30a29d7ba3  push rdi
00007f30a29d7ba4  push rsi
00007f30a29d7ba5  push r8
00007f30a29d7ba7  push r9
00007f30a29d7ba9  push r10
00007f30a29d7bab  push r11
00007f30a29d7bad  sub rsp, 0xF0
00007f30a29d7bb4  vmovaps [rsp], xmm0
00007f30a29d7bb9  vmovaps [rsp+0x10], xmm1
00007f30a29d7bbf  vmovaps [rsp+0x20], xmm2
00007f30a29d7bc5  vmovaps [rsp+0x30], xmm3
00007f30a29d7bcb  vmovaps [rsp+0x40], xmm4
00007f30a29d7bd1  vmovaps [rsp+0x50], xmm5
00007f30a29d7bd7  vmovaps [rsp+0x60], xmm6
00007f30a29d7bdd  vmovaps [rsp+0x70], xmm7
00007f30a29d7be3  vmovaps [rsp+0x80], xmm9
00007f30a29d7bec  vmovaps [rsp+0x90], xmm10
00007f30a29d7bf5  vmovaps [rsp+0xA0], xmm11
00007f30a29d7bfe  vmovaps [rsp+0xB0], xmm12
00007f30a29d7c07  vmovaps [rsp+0xC0], xmm13
00007f30a29d7c10  vmovaps [rsp+0xD0], xmm14
00007f30a29d7c19  vmovaps [rsp+0xE0], xmm15
00007f30a29d7c22  sub rsp, 0x30
00007f30a29d7c26  movaps [rsp], xmm8
00007f30a29d7c2b  movaps [rsp+0x10], xmm15
00007f30a29d7c31  movaps [rsp+0x20], xmm9
00007f30a29d7c37  lea rdi, [rsp]
00007f30a29d7c3b  mov esi, 0x00
00007f30a29d7c40  mov rax, 0x5FE955026530
00007f30a29d7c4a  call rax
00007f30a29d7c4c  movaps xmm8, [rsp]
00007f30a29d7c51  add rsp, 0x30
00007f30a29d7c55  vmovaps xmm0, [rsp]
00007f30a29d7c5a  vmovaps xmm1, [rsp+0x10]
00007f30a29d7c60  vmovaps xmm2, [rsp+0x20]
00007f30a29d7c66  vmovaps xmm3, [rsp+0x30]
00007f30a29d7c6c  vmovaps xmm4, [rsp+0x40]
00007f30a29d7c72  vmovaps xmm5, [rsp+0x50]
00007f30a29d7c78  vmovaps xmm6, [rsp+0x60]
00007f30a29d7c7e  vmovaps xmm7, [rsp+0x70]
00007f30a29d7c84  vmovaps xmm9, [rsp+0x80]
00007f30a29d7c8d  vmovaps xmm10, [rsp+0x90]
00007f30a29d7c96  vmovaps xmm11, [rsp+0xA0]
00007f30a29d7c9f  vmovaps xmm12, [rsp+0xB0]
00007f30a29d7ca8  vmovaps xmm13, [rsp+0xC0]
00007f30a29d7cb1  vmovaps xmm14, [rsp+0xD0]
00007f30a29d7cba  vmovaps xmm15, [rsp+0xE0]
00007f30a29d7cc3  add rsp, 0xF0
00007f30a29d7cca  pop r11
00007f30a29d7ccc  pop r10
00007f30a29d7cce  pop r9
00007f30a29d7cd0  pop r8
00007f30a29d7cd2  pop rsi
00007f30a29d7cd3  pop rdi
00007f30a29d7cd4  pop rdx
00007f30a29d7cd5  pop rcx
00007f30a29d7cd6  pop rax
00007f30a29d7cd7  add rsp, 0x08
00007f30a29d7cdb  jmp 0x00007F30A29D33EA
00007f30a29d7ce0  sub rsp, 0x08
00007f30a29d7ce4  push rax
00007f30a29d7ce5  push rcx
00007f30a29d7ce6  push rdx
00007f30a29d7ce7  push rdi
00007f30a29d7ce8  push rsi
00007f30a29d7ce9  push r8
00007f30a29d7ceb  push r9
00007f30a29d7ced  push r10
00007f30a29d7cef  push r11
00007f30a29d7cf1  sub rsp, 0xF0
00007f30a29d7cf8  vmovaps [rsp], xmm0
00007f30a29d7cfd  vmovaps [rsp+0x10], xmm1
00007f30a29d7d03  vmovaps [rsp+0x20], xmm2
00007f30a29d7d09  vmovaps [rsp+0x30], xmm3
00007f30a29d7d0f  vmovaps [rsp+0x40], xmm4
00007f30a29d7d15  vmovaps [rsp+0x50], xmm5
00007f30a29d7d1b  vmovaps [rsp+0x60], xmm6
00007f30a29d7d21  vmovaps [rsp+0x70], xmm7
00007f30a29d7d27  vmovaps [rsp+0x80], xmm8
00007f30a29d7d30  vmovaps [rsp+0x90], xmm10
00007f30a29d7d39  vmovaps [rsp+0xA0], xmm11
00007f30a29d7d42  vmovaps [rsp+0xB0], xmm12
00007f30a29d7d4b  vmovaps [rsp+0xC0], xmm13
00007f30a29d7d54  vmovaps [rsp+0xD0], xmm14
00007f30a29d7d5d  vmovaps [rsp+0xE0], xmm15
00007f30a29d7d66  sub rsp, 0x30
00007f30a29d7d6a  movaps [rsp], xmm9
00007f30a29d7d6f  movaps [rsp+0x10], xmm1
00007f30a29d7d74  movaps [rsp+0x20], xmm15
00007f30a29d7d7a  lea rdi, [rsp]
00007f30a29d7d7e  mov esi, 0x00
00007f30a29d7d83  mov rax, 0x5FE955026530
00007f30a29d7d8d  call rax
00007f30a29d7d8f  movaps xmm9, [rsp]
00007f30a29d7d94  add rsp, 0x30
00007f30a29d7d98  vmovaps xmm0, [rsp]
00007f30a29d7d9d  vmovaps xmm1, [rsp+0x10]
00007f30a29d7da3  vmovaps xmm2, [rsp+0x20]
00007f30a29d7da9  vmovaps xmm3, [rsp+0x30]
00007f30a29d7daf  vmovaps xmm4, [rsp+0x40]
00007f30a29d7db5  vmovaps xmm5, [rsp+0x50]
00007f30a29d7dbb  vmovaps xmm6, [rsp+0x60]
00007f30a29d7dc1  vmovaps xmm7, [rsp+0x70]
00007f30a29d7dc7  vmovaps xmm8, [rsp+0x80]
00007f30a29d7dd0  vmovaps xmm10, [rsp+0x90]
00007f30a29d7dd9  vmovaps xmm11, [rsp+0xA0]
00007f30a29d7de2  vmovaps xmm12, [rsp+0xB0]
00007f30a29d7deb  vmovaps xmm13, [rsp+0xC0]
00007f30a29d7df4  vmovaps xmm14, [rsp+0xD0]
00007f30a29d7dfd  vmovaps xmm15, [rsp+0xE0]
00007f30a29d7e06  add rsp, 0xF0
00007f30a29d7e0d  pop r11
00007f30a29d7e0f  pop r10
00007f30a29d7e11  pop r9
00007f30a29d7e13  pop r8
00007f30a29d7e15  pop rsi
00007f30a29d7e16  pop rdi
00007f30a29d7e17  pop rdx
00007f30a29d7e18  pop rcx
00007f30a29d7e19  pop rax
00007f30a29d7e1a  add rsp, 0x08
00007f30a29d7e1e  jmp 0x00007F30A29D3418
00007f30a29d7e23  sub rsp, 0x08
00007f30a29d7e27  push rax
00007f30a29d7e28  push rcx
00007f30a29d7e29  push rdx
00007f30a29d7e2a  push rdi
00007f30a29d7e2b  push rsi
00007f30a29d7e2c  push r8
00007f30a29d7e2e  push r9
00007f30a29d7e30  push r10
00007f30a29d7e32  push r11
00007f30a29d7e34  sub rsp, 0xF0
00007f30a29d7e3b  vmovaps [rsp], xmm0
00007f30a29d7e40  vmovaps [rsp+0x10], xmm1
00007f30a29d7e46  vmovaps [rsp+0x20], xmm2
00007f30a29d7e4c  vmovaps [rsp+0x30], xmm3
00007f30a29d7e52  vmovaps [rsp+0x40], xmm4
00007f30a29d7e58  vmovaps [rsp+0x50], xmm5
00007f30a29d7e5e  vmovaps [rsp+0x60], xmm6
00007f30a29d7e64  vmovaps [rsp+0x70], xmm7
00007f30a29d7e6a  vmovaps [rsp+0x80], xmm8
00007f30a29d7e73  vmovaps [rsp+0x90], xmm9
00007f30a29d7e7c  vmovaps [rsp+0xA0], xmm10
00007f30a29d7e85  vmovaps [rsp+0xB0], xmm11
00007f30a29d7e8e  vmovaps [rsp+0xC0], xmm12
00007f30a29d7e97  vmovaps [rsp+0xD0], xmm13
00007f30a29d7ea0  vmovaps [rsp+0xE0], xmm14
00007f30a29d7ea9  sub rsp, 0x30
00007f30a29d7ead  movaps [rsp], xmm15
00007f30a29d7eb2  movaps [rsp+0x10], xmm4
00007f30a29d7eb7  movaps [rsp+0x20], xmm1
00007f30a29d7ebc  lea rdi, [rsp]
00007f30a29d7ec0  mov esi, 0x00
00007f30a29d7ec5  mov rax, 0x5FE955026530
00007f30a29d7ecf  call rax
00007f30a29d7ed1  movaps xmm15, [rsp]
00007f30a29d7ed6  add rsp, 0x30
00007f30a29d7eda  vmovaps xmm0, [rsp]
00007f30a29d7edf  vmovaps xmm1, [rsp+0x10]
00007f30a29d7ee5  vmovaps xmm2, [rsp+0x20]
00007f30a29d7eeb  vmovaps xmm3, [rsp+0x30]
00007f30a29d7ef1  vmovaps xmm4, [rsp+0x40]
00007f30a29d7ef7  vmovaps xmm5, [rsp+0x50]
00007f30a29d7efd  vmovaps xmm6, [rsp+0x60]
00007f30a29d7f03  vmovaps xmm7, [rsp+0x70]
00007f30a29d7f09  vmovaps xmm8, [rsp+0x80]
00007f30a29d7f12  vmovaps xmm9, [rsp+0x90]
00007f30a29d7f1b  vmovaps xmm10, [rsp+0xA0]
00007f30a29d7f24  vmovaps xmm11, [rsp+0xB0]
00007f30a29d7f2d  vmovaps xmm12, [rsp+0xC0]
00007f30a29d7f36  vmovaps xmm13, [rsp+0xD0]
00007f30a29d7f3f  vmovaps xmm14, [rsp+0xE0]
00007f30a29d7f48  add rsp, 0xF0
00007f30a29d7f4f  pop r11
00007f30a29d7f51  pop r10
00007f30a29d7f53  pop r9
00007f30a29d7f55  pop r8
00007f30a29d7f57  pop rsi
00007f30a29d7f58  pop rdi
00007f30a29d7f59  pop rdx
00007f30a29d7f5a  pop rcx
00007f30a29d7f5b  pop rax
00007f30a29d7f5c  add rsp, 0x08
00007f30a29d7f60  jmp 0x00007F30A29D343E
00007f30a29d7f65  sub rsp, 0x08
00007f30a29d7f69  push rax
00007f30a29d7f6a  push rcx
00007f30a29d7f6b  push rdx
00007f30a29d7f6c  push rdi
00007f30a29d7f6d  push rsi
00007f30a29d7f6e  push r8
00007f30a29d7f70  push r9
00007f30a29d7f72  push r10
00007f30a29d7f74  push r11
00007f30a29d7f76  sub rsp, 0xF0
00007f30a29d7f7d  vmovaps [rsp], xmm0
00007f30a29d7f82  vmovaps [rsp+0x10], xmm2
00007f30a29d7f88  vmovaps [rsp+0x20], xmm3
00007f30a29d7f8e  vmovaps [rsp+0x30], xmm4
00007f30a29d7f94  vmovaps [rsp+0x40], xmm5
00007f30a29d7f9a  vmovaps [rsp+0x50], xmm6
00007f30a29d7fa0  vmovaps [rsp+0x60], xmm7
00007f30a29d7fa6  vmovaps [rsp+0x70], xmm8
00007f30a29d7fac  vmovaps [rsp+0x80], xmm9
00007f30a29d7fb5  vmovaps [rsp+0x90], xmm10
00007f30a29d7fbe  vmovaps [rsp+0xA0], xmm11
00007f30a29d7fc7  vmovaps [rsp+0xB0], xmm12
00007f30a29d7fd0  vmovaps [rsp+0xC0], xmm13
00007f30a29d7fd9  vmovaps [rsp+0xD0], xmm14
00007f30a29d7fe2  vmovaps [rsp+0xE0], xmm15
00007f30a29d7feb  sub rsp, 0x30
00007f30a29d7fef  movaps [rsp], xmm1
00007f30a29d7ff3  movaps [rsp+0x10], xmm14
00007f30a29d7ff9  movaps [rsp+0x20], xmm11
00007f30a29d7fff  lea rdi, [rsp]
00007f30a29d8003  mov esi, 0x00
00007f30a29d8008  mov rax, 0x5FE955026530
00007f30a29d8012  call rax
00007f30a29d8014  movaps xmm1, [rsp]
00007f30a29d8018  add rsp, 0x30
00007f30a29d801c  vmovaps xmm0, [rsp]
00007f30a29d8021  vmovaps xmm2, [rsp+0x10]
00007f30a29d8027  vmovaps xmm3, [rsp+0x20]
00007f30a29d802d  vmovaps xmm4, [rsp+0x30]
00007f30a29d8033  vmovaps xmm5, [rsp+0x40]
00007f30a29d8039  vmovaps xmm6, [rsp+0x50]
00007f30a29d803f  vmovaps xmm7, [rsp+0x60]
00007f30a29d8045  vmovaps xmm8, [rsp+0x70]
00007f30a29d804b  vmovaps xmm9, [rsp+0x80]
00007f30a29d8054  vmovaps xmm10, [rsp+0x90]
00007f30a29d805d  vmovaps xmm11, [rsp+0xA0]
00007f30a29d8066  vmovaps xmm12, [rsp+0xB0]
00007f30a29d806f  vmovaps xmm13, [rsp+0xC0]
00007f30a29d8078  vmovaps xmm14, [rsp+0xD0]
00007f30a29d8081  vmovaps xmm15, [rsp+0xE0]
00007f30a29d808a  add rsp, 0xF0
00007f30a29d8091  pop r11
00007f30a29d8093  pop r10
00007f30a29d8095  pop r9
00007f30a29d8097  pop r8
00007f30a29d8099  pop rsi
00007f30a29d809a  pop rdi
00007f30a29d809b  pop rdx
00007f30a29d809c  pop rcx
00007f30a29d809d  pop rax
00007f30a29d809e  add rsp, 0x08
00007f30a29d80a2  jmp 0x00007F30A29D345F
00007f30a29d80a7  call 0x00007F30A28E45A0
00007f30a29d80ac  jmp 0x00007F30A29D346D
00007f30a29d80b1  call 0x00007F30A2809D70
00007f30a29d80b6  jmp 0x00007F30A29D3477
00007f30a29d80bb  sub rsp, 0x08
00007f30a29d80bf  push rax
00007f30a29d80c0  push rcx
00007f30a29d80c1  push rdx
00007f30a29d80c2  push rdi
00007f30a29d80c3  push rsi
00007f30a29d80c4  push r8
00007f30a29d80c6  push r9
00007f30a29d80c8  push r10
00007f30a29d80ca  push r11
00007f30a29d80cc  sub rsp, 0xF0
00007f30a29d80d3  vmovaps [rsp], xmm0
00007f30a29d80d8  vmovaps [rsp+0x10], xmm1
00007f30a29d80de  vmovaps [rsp+0x20], xmm2
00007f30a29d80e4  vmovaps [rsp+0x30], xmm3
00007f30a29d80ea  vmovaps [rsp+0x40], xmm4
00007f30a29d80f0  vmovaps [rsp+0x50], xmm5
00007f30a29d80f6  vmovaps [rsp+0x60], xmm6
00007f30a29d80fc  vmovaps [rsp+0x70], xmm8
00007f30a29d8102  vmovaps [rsp+0x80], xmm9
00007f30a29d810b  vmovaps [rsp+0x90], xmm10
00007f30a29d8114  vmovaps [rsp+0xA0], xmm11
00007f30a29d811d  vmovaps [rsp+0xB0], xmm12
00007f30a29d8126  vmovaps [rsp+0xC0], xmm13
00007f30a29d812f  vmovaps [rsp+0xD0], xmm14
00007f30a29d8138  vmovaps [rsp+0xE0], xmm15
00007f30a29d8141  sub rsp, 0x30
00007f30a29d8145  movaps [rsp], xmm7
00007f30a29d8149  movaps [rsp+0x10], xmm13
00007f30a29d814f  movaps [rsp+0x20], xmm10
00007f30a29d8155  lea rdi, [rsp]
00007f30a29d8159  mov esi, 0x00
00007f30a29d815e  mov rax, 0x5FE955026530
00007f30a29d8168  call rax
00007f30a29d816a  movaps xmm7, [rsp]
00007f30a29d816e  add rsp, 0x30
00007f30a29d8172  vmovaps xmm0, [rsp]
00007f30a29d8177  vmovaps xmm1, [rsp+0x10]
00007f30a29d817d  vmovaps xmm2, [rsp+0x20]
00007f30a29d8183  vmovaps xmm3, [rsp+0x30]
00007f30a29d8189  vmovaps xmm4, [rsp+0x40]
00007f30a29d818f  vmovaps xmm5, [rsp+0x50]
00007f30a29d8195  vmovaps xmm6, [rsp+0x60]
00007f30a29d819b  vmovaps xmm8, [rsp+0x70]
00007f30a29d81a1  vmovaps xmm9, [rsp+0x80]
00007f30a29d81aa  vmovaps xmm10, [rsp+0x90]
00007f30a29d81b3  vmovaps xmm11, [rsp+0xA0]
00007f30a29d81bc  vmovaps xmm12, [rsp+0xB0]
00007f30a29d81c5  vmovaps xmm13, [rsp+0xC0]
00007f30a29d81ce  vmovaps xmm14, [rsp+0xD0]
00007f30a29d81d7  vmovaps xmm15, [rsp+0xE0]
00007f30a29d81e0  add rsp, 0xF0
00007f30a29d81e7  pop r11
00007f30a29d81e9  pop r10
00007f30a29d81eb  pop r9
00007f30a29d81ed  pop r8
00007f30a29d81ef  pop rsi
00007f30a29d81f0  pop rdi
00007f30a29d81f1  pop rdx
00007f30a29d81f2  pop rcx
00007f30a29d81f3  pop rax
00007f30a29d81f4  add rsp, 0x08
00007f30a29d81f8  jmp 0x00007F30A29D3498
00007f30a29d81fd  sub rsp, 0x08
00007f30a29d8201  push rax
00007f30a29d8202  push rcx
00007f30a29d8203  push rdx
00007f30a29d8204  push rdi
00007f30a29d8205  push rsi
00007f30a29d8206  push r8
00007f30a29d8208  push r9
00007f30a29d820a  push r10
00007f30a29d820c  push r11
00007f30a29d820e  sub rsp, 0xF0
00007f30a29d8215  vmovaps [rsp], xmm0
00007f30a29d821a  vmovaps [rsp+0x10], xmm1
00007f30a29d8220  vmovaps [rsp+0x20], xmm2
00007f30a29d8226  vmovaps [rsp+0x30], xmm3
00007f30a29d822c  vmovaps [rsp+0x40], xmm4
00007f30a29d8232  vmovaps [rsp+0x50], xmm5
00007f30a29d8238  vmovaps [rsp+0x60], xmm6
00007f30a29d823e  vmovaps [rsp+0x70], xmm7
00007f30a29d8244  vmovaps [rsp+0x80], xmm8
00007f30a29d824d  vmovaps [rsp+0x90], xmm9
00007f30a29d8256  vmovaps [rsp+0xA0], xmm11
00007f30a29d825f  vmovaps [rsp+0xB0], xmm12
00007f30a29d8268  vmovaps [rsp+0xC0], xmm13
00007f30a29d8271  vmovaps [rsp+0xD0], xmm14
00007f30a29d827a  vmovaps [rsp+0xE0], xmm15
00007f30a29d8283  sub rsp, 0x30
00007f30a29d8287  movaps [rsp], xmm10
00007f30a29d828c  movaps [rsp+0x10], xmm11
00007f30a29d8292  movaps [rsp+0x20], xmm13
00007f30a29d8298  lea rdi, [rsp]
00007f30a29d829c  mov esi, 0x00
00007f30a29d82a1  mov rax, 0x5FE955026530
00007f30a29d82ab  call rax
00007f30a29d82ad  movaps xmm10, [rsp]
00007f30a29d82b2  add rsp, 0x30
00007f30a29d82b6  vmovaps xmm0, [rsp]
00007f30a29d82bb  vmovaps xmm1, [rsp+0x10]
00007f30a29d82c1  vmovaps xmm2, [rsp+0x20]
00007f30a29d82c7  vmovaps xmm3, [rsp+0x30]
00007f30a29d82cd  vmovaps xmm4, [rsp+0x40]
00007f30a29d82d3  vmovaps xmm5, [rsp+0x50]
00007f30a29d82d9  vmovaps xmm6, [rsp+0x60]
00007f30a29d82df  vmovaps xmm7, [rsp+0x70]
00007f30a29d82e5  vmovaps xmm8, [rsp+0x80]
00007f30a29d82ee  vmovaps xmm9, [rsp+0x90]
00007f30a29d82f7  vmovaps xmm11, [rsp+0xA0]
00007f30a29d8300  vmovaps xmm12, [rsp+0xB0]
00007f30a29d8309  vmovaps xmm13, [rsp+0xC0]
00007f30a29d8312  vmovaps xmm14, [rsp+0xD0]
00007f30a29d831b  vmovaps xmm15, [rsp+0xE0]
00007f30a29d8324  add rsp, 0xF0
00007f30a29d832b  pop r11
00007f30a29d832d  pop r10
00007f30a29d832f  pop r9
00007f30a29d8331  pop r8
00007f30a29d8333  pop rsi
00007f30a29d8334  pop rdi
00007f30a29d8335  pop rdx
00007f30a29d8336  pop rcx
00007f30a29d8337  pop rax
00007f30a29d8338  add rsp, 0x08
00007f30a29d833c  jmp 0x00007F30A29D34C6
00007f30a29d8341  sub rsp, 0x08
00007f30a29d8345  push rax
00007f30a29d8346  push rcx
00007f30a29d8347  push rdx
00007f30a29d8348  push rdi
00007f30a29d8349  push rsi
00007f30a29d834a  push r8
00007f30a29d834c  push r9
00007f30a29d834e  push r10
00007f30a29d8350  push r11
00007f30a29d8352  sub rsp, 0xF0
00007f30a29d8359  vmovaps [rsp], xmm0
00007f30a29d835e  vmovaps [rsp+0x10], xmm1
00007f30a29d8364  vmovaps [rsp+0x20], xmm2
00007f30a29d836a  vmovaps [rsp+0x30], xmm3
00007f30a29d8370  vmovaps [rsp+0x40], xmm4
00007f30a29d8376  vmovaps [rsp+0x50], xmm5
00007f30a29d837c  vmovaps [rsp+0x60], xmm6
00007f30a29d8382  vmovaps [rsp+0x70], xmm7
00007f30a29d8388  vmovaps [rsp+0x80], xmm8
00007f30a29d8391  vmovaps [rsp+0x90], xmm9
00007f30a29d839a  vmovaps [rsp+0xA0], xmm10
00007f30a29d83a3  vmovaps [rsp+0xB0], xmm12
00007f30a29d83ac  vmovaps [rsp+0xC0], xmm13
00007f30a29d83b5  vmovaps [rsp+0xD0], xmm14
00007f30a29d83be  vmovaps [rsp+0xE0], xmm15
00007f30a29d83c7  sub rsp, 0x30
00007f30a29d83cb  movaps [rsp], xmm11
00007f30a29d83d0  movaps [rsp+0x10], xmm14
00007f30a29d83d6  movaps [rsp+0x20], xmm13
00007f30a29d83dc  lea rdi, [rsp]
00007f30a29d83e0  mov esi, 0x00
00007f30a29d83e5  mov rax, 0x5FE955026530
00007f30a29d83ef  call rax
00007f30a29d83f1  movaps xmm11, [rsp]
00007f30a29d83f6  add rsp, 0x30
00007f30a29d83fa  vmovaps xmm0, [rsp]
00007f30a29d83ff  vmovaps xmm1, [rsp+0x10]
00007f30a29d8405  vmovaps xmm2, [rsp+0x20]
00007f30a29d840b  vmovaps xmm3, [rsp+0x30]
00007f30a29d8411  vmovaps xmm4, [rsp+0x40]
00007f30a29d8417  vmovaps xmm5, [rsp+0x50]
00007f30a29d841d  vmovaps xmm6, [rsp+0x60]
00007f30a29d8423  vmovaps xmm7, [rsp+0x70]
00007f30a29d8429  vmovaps xmm8, [rsp+0x80]
00007f30a29d8432  vmovaps xmm9, [rsp+0x90]
00007f30a29d843b  vmovaps xmm10, [rsp+0xA0]
00007f30a29d8444  vmovaps xmm12, [rsp+0xB0]
00007f30a29d844d  vmovaps xmm13, [rsp+0xC0]
00007f30a29d8456  vmovaps xmm14, [rsp+0xD0]
00007f30a29d845f  vmovaps xmm15, [rsp+0xE0]
00007f30a29d8468  add rsp, 0xF0
00007f30a29d846f  pop r11
00007f30a29d8471  pop r10
00007f30a29d8473  pop r9
00007f30a29d8475  pop r8
00007f30a29d8477  pop rsi
00007f30a29d8478  pop rdi
00007f30a29d8479  pop rdx
00007f30a29d847a  pop rcx
00007f30a29d847b  pop rax
00007f30a29d847c  add rsp, 0x08
00007f30a29d8480  jmp 0x00007F30A29D34F4
00007f30a29d8485  sub rsp, 0x08
00007f30a29d8489  push rax
00007f30a29d848a  push rcx
00007f30a29d848b  push rdx
00007f30a29d848c  push rdi
00007f30a29d848d  push rsi
00007f30a29d848e  push r8
00007f30a29d8490  push r9
00007f30a29d8492  push r10
00007f30a29d8494  push r11
00007f30a29d8496  sub rsp, 0xF0
00007f30a29d849d  vmovaps [rsp], xmm0
00007f30a29d84a2  vmovaps [rsp+0x10], xmm1
00007f30a29d84a8  vmovaps [rsp+0x20], xmm2
00007f30a29d84ae  vmovaps [rsp+0x30], xmm3
00007f30a29d84b4  vmovaps [rsp+0x40], xmm4
00007f30a29d84ba  vmovaps [rsp+0x50], xmm5
00007f30a29d84c0  vmovaps [rsp+0x60], xmm6
00007f30a29d84c6  vmovaps [rsp+0x70], xmm7
00007f30a29d84cc  vmovaps [rsp+0x80], xmm8
00007f30a29d84d5  vmovaps [rsp+0x90], xmm9
00007f30a29d84de  vmovaps [rsp+0xA0], xmm10
00007f30a29d84e7  vmovaps [rsp+0xB0], xmm11
00007f30a29d84f0  vmovaps [rsp+0xC0], xmm12
00007f30a29d84f9  vmovaps [rsp+0xD0], xmm13
00007f30a29d8502  vmovaps [rsp+0xE0], xmm15
00007f30a29d850b  sub rsp, 0x30
00007f30a29d850f  movaps [rsp], xmm14
00007f30a29d8514  movaps [rsp+0x10], xmm12
00007f30a29d851a  movaps [rsp+0x20], xmm9
00007f30a29d8520  lea rdi, [rsp]
00007f30a29d8524  mov esi, 0x00
00007f30a29d8529  mov rax, 0x5FE955026530
00007f30a29d8533  call rax
00007f30a29d8535  movaps xmm14, [rsp]
00007f30a29d853a  add rsp, 0x30
00007f30a29d853e  vmovaps xmm0, [rsp]
00007f30a29d8543  vmovaps xmm1, [rsp+0x10]
00007f30a29d8549  vmovaps xmm2, [rsp+0x20]
00007f30a29d854f  vmovaps xmm3, [rsp+0x30]
00007f30a29d8555  vmovaps xmm4, [rsp+0x40]
00007f30a29d855b  vmovaps xmm5, [rsp+0x50]
00007f30a29d8561  vmovaps xmm6, [rsp+0x60]
00007f30a29d8567  vmovaps xmm7, [rsp+0x70]
00007f30a29d856d  vmovaps xmm8, [rsp+0x80]
00007f30a29d8576  vmovaps xmm9, [rsp+0x90]
00007f30a29d857f  vmovaps xmm10, [rsp+0xA0]
00007f30a29d8588  vmovaps xmm11, [rsp+0xB0]
00007f30a29d8591  vmovaps xmm12, [rsp+0xC0]
00007f30a29d859a  vmovaps xmm13, [rsp+0xD0]
00007f30a29d85a3  vmovaps xmm15, [rsp+0xE0]
00007f30a29d85ac  add rsp, 0xF0
00007f30a29d85b3  pop r11
00007f30a29d85b5  pop r10
00007f30a29d85b7  pop r9
00007f30a29d85b9  pop r8
00007f30a29d85bb  pop rsi
00007f30a29d85bc  pop rdi
00007f30a29d85bd  pop rdx
00007f30a29d85be  pop rcx
00007f30a29d85bf  pop rax
00007f30a29d85c0  add rsp, 0x08
00007f30a29d85c4  jmp 0x00007F30A29D350F
00007f30a29d85c9  sub rsp, 0x08
00007f30a29d85cd  push rax
00007f30a29d85ce  push rcx
00007f30a29d85cf  push rdx
00007f30a29d85d0  push rdi
00007f30a29d85d1  push rsi
00007f30a29d85d2  push r8
00007f30a29d85d4  push r9
00007f30a29d85d6  push r10
00007f30a29d85d8  push r11
00007f30a29d85da  sub rsp, 0xF0
00007f30a29d85e1  vmovaps [rsp], xmm0
00007f30a29d85e6  vmovaps [rsp+0x10], xmm1
00007f30a29d85ec  vmovaps [rsp+0x20], xmm2
00007f30a29d85f2  vmovaps [rsp+0x30], xmm3
00007f30a29d85f8  vmovaps [rsp+0x40], xmm4
00007f30a29d85fe  vmovaps [rsp+0x50], xmm5
00007f30a29d8604  vmovaps [rsp+0x60], xmm6
00007f30a29d860a  vmovaps [rsp+0x70], xmm7
00007f30a29d8610  vmovaps [rsp+0x80], xmm8
00007f30a29d8619  vmovaps [rsp+0x90], xmm9
00007f30a29d8622  vmovaps [rsp+0xA0], xmm10
00007f30a29d862b  vmovaps [rsp+0xB0], xmm11
00007f30a29d8634  vmovaps [rsp+0xC0], xmm12
00007f30a29d863d  vmovaps [rsp+0xD0], xmm14
00007f30a29d8646  vmovaps [rsp+0xE0], xmm15
00007f30a29d864f  sub rsp, 0x30
00007f30a29d8653  movaps [rsp], xmm13
00007f30a29d8658  movaps [rsp+0x10], xmm8
00007f30a29d865e  movaps [rsp+0x20], xmm15
00007f30a29d8664  lea rdi, [rsp]
00007f30a29d8668  mov esi, 0x00
00007f30a29d866d  mov rax, 0x5FE955026530
00007f30a29d8677  call rax
00007f30a29d8679  movaps xmm13, [rsp]
00007f30a29d867e  add rsp, 0x30
00007f30a29d8682  vmovaps xmm0, [rsp]
00007f30a29d8687  vmovaps xmm1, [rsp+0x10]
00007f30a29d868d  vmovaps xmm2, [rsp+0x20]
00007f30a29d8693  vmovaps xmm3, [rsp+0x30]
00007f30a29d8699  vmovaps xmm4, [rsp+0x40]
00007f30a29d869f  vmovaps xmm5, [rsp+0x50]
00007f30a29d86a5  vmovaps xmm6, [rsp+0x60]
00007f30a29d86ab  vmovaps xmm7, [rsp+0x70]
00007f30a29d86b1  vmovaps xmm8, [rsp+0x80]
00007f30a29d86ba  vmovaps xmm9, [rsp+0x90]
00007f30a29d86c3  vmovaps xmm10, [rsp+0xA0]
00007f30a29d86cc  vmovaps xmm11, [rsp+0xB0]
00007f30a29d86d5  vmovaps xmm12, [rsp+0xC0]
00007f30a29d86de  vmovaps xmm14, [rsp+0xD0]
00007f30a29d86e7  vmovaps xmm15, [rsp+0xE0]
00007f30a29d86f0  add rsp, 0xF0
00007f30a29d86f7  pop r11
00007f30a29d86f9  pop r10
00007f30a29d86fb  pop r9
00007f30a29d86fd  pop r8
00007f30a29d86ff  pop rsi
00007f30a29d8700  pop rdi
00007f30a29d8701  pop rdx
00007f30a29d8702  pop rcx
00007f30a29d8703  pop rax
00007f30a29d8704  add rsp, 0x08
00007f30a29d8708  jmp 0x00007F30A29D3532
00007f30a29d870d  sub rsp, 0x08
00007f30a29d8711  push rax
00007f30a29d8712  push rcx
00007f30a29d8713  push rdx
00007f30a29d8714  push rdi
00007f30a29d8715  push rsi
00007f30a29d8716  push r8
00007f30a29d8718  push r9
00007f30a29d871a  push r10
00007f30a29d871c  push r11
00007f30a29d871e  sub rsp, 0xF0
00007f30a29d8725  vmovaps [rsp], xmm0
00007f30a29d872a  vmovaps [rsp+0x10], xmm1
00007f30a29d8730  vmovaps [rsp+0x20], xmm2
00007f30a29d8736  vmovaps [rsp+0x30], xmm3
00007f30a29d873c  vmovaps [rsp+0x40], xmm4
00007f30a29d8742  vmovaps [rsp+0x50], xmm5
00007f30a29d8748  vmovaps [rsp+0x60], xmm6
00007f30a29d874e  vmovaps [rsp+0x70], xmm7
00007f30a29d8754  vmovaps [rsp+0x80], xmm8
00007f30a29d875d  vmovaps [rsp+0x90], xmm9
00007f30a29d8766  vmovaps [rsp+0xA0], xmm10
00007f30a29d876f  vmovaps [rsp+0xB0], xmm11
00007f30a29d8778  vmovaps [rsp+0xC0], xmm12
00007f30a29d8781  vmovaps [rsp+0xD0], xmm13
00007f30a29d878a  vmovaps [rsp+0xE0], xmm14
00007f30a29d8793  sub rsp, 0x30
00007f30a29d8797  movaps [rsp], xmm15
00007f30a29d879c  movaps [rsp+0x10], xmm1
00007f30a29d87a1  movaps [rsp+0x20], xmm10
00007f30a29d87a7  lea rdi, [rsp]
00007f30a29d87ab  mov esi, 0x00
00007f30a29d87b0  mov rax, 0x5FE955026530
00007f30a29d87ba  call rax
00007f30a29d87bc  movaps xmm15, [rsp]
00007f30a29d87c1  add rsp, 0x30
00007f30a29d87c5  vmovaps xmm0, [rsp]
00007f30a29d87ca  vmovaps xmm1, [rsp+0x10]
00007f30a29d87d0  vmovaps xmm2, [rsp+0x20]
00007f30a29d87d6  vmovaps xmm3, [rsp+0x30]
00007f30a29d87dc  vmovaps xmm4, [rsp+0x40]
00007f30a29d87e2  vmovaps xmm5, [rsp+0x50]
00007f30a29d87e8  vmovaps xmm6, [rsp+0x60]
00007f30a29d87ee  vmovaps xmm7, [rsp+0x70]
00007f30a29d87f4  vmovaps xmm8, [rsp+0x80]
00007f30a29d87fd  vmovaps xmm9, [rsp+0x90]
00007f30a29d8806  vmovaps xmm10, [rsp+0xA0]
00007f30a29d880f  vmovaps xmm11, [rsp+0xB0]
00007f30a29d8818  vmovaps xmm12, [rsp+0xC0]
00007f30a29d8821  vmovaps xmm13, [rsp+0xD0]
00007f30a29d882a  vmovaps xmm14, [rsp+0xE0]
00007f30a29d8833  add rsp, 0xF0
00007f30a29d883a  pop r11
00007f30a29d883c  pop r10
00007f30a29d883e  pop r9
00007f30a29d8840  pop r8
00007f30a29d8842  pop rsi
00007f30a29d8843  pop rdi
00007f30a29d8844  pop rdx
00007f30a29d8845  pop rcx
00007f30a29d8846  pop rax
00007f30a29d8847  add rsp, 0x08
00007f30a29d884b  jmp 0x00007F30A29D3555
00007f30a29d8850  sub rsp, 0x08
00007f30a29d8854  push rax
00007f30a29d8855  push rcx
00007f30a29d8856  push rdx
00007f30a29d8857  push rdi
00007f30a29d8858  push rsi
00007f30a29d8859  push r8
00007f30a29d885b  push r9
00007f30a29d885d  push r10
00007f30a29d885f  push r11
00007f30a29d8861  sub rsp, 0xF0
00007f30a29d8868  vmovaps [rsp], xmm0
00007f30a29d886d  vmovaps [rsp+0x10], xmm2
00007f30a29d8873  vmovaps [rsp+0x20], xmm3
00007f30a29d8879  vmovaps [rsp+0x30], xmm4
00007f30a29d887f  vmovaps [rsp+0x40], xmm5
00007f30a29d8885  vmovaps [rsp+0x50], xmm6
00007f30a29d888b  vmovaps [rsp+0x60], xmm7
00007f30a29d8891  vmovaps [rsp+0x70], xmm8
00007f30a29d8897  vmovaps [rsp+0x80], xmm9
00007f30a29d88a0  vmovaps [rsp+0x90], xmm10
00007f30a29d88a9  vmovaps [rsp+0xA0], xmm11
00007f30a29d88b2  vmovaps [rsp+0xB0], xmm12
00007f30a29d88bb  vmovaps [rsp+0xC0], xmm13
00007f30a29d88c4  vmovaps [rsp+0xD0], xmm14
00007f30a29d88cd  vmovaps [rsp+0xE0], xmm15
00007f30a29d88d6  sub rsp, 0x30
00007f30a29d88da  movaps [rsp], xmm1
00007f30a29d88de  movaps [rsp+0x10], xmm7
00007f30a29d88e3  movaps [rsp+0x20], xmm11
00007f30a29d88e9  lea rdi, [rsp]
00007f30a29d88ed  mov esi, 0x00
00007f30a29d88f2  mov rax, 0x5FE955026530
00007f30a29d88fc  call rax
00007f30a29d88fe  movaps xmm1, [rsp]
00007f30a29d8902  add rsp, 0x30
00007f30a29d8906  vmovaps xmm0, [rsp]
00007f30a29d890b  vmovaps xmm2, [rsp+0x10]
00007f30a29d8911  vmovaps xmm3, [rsp+0x20]
00007f30a29d8917  vmovaps xmm4, [rsp+0x30]
00007f30a29d891d  vmovaps xmm5, [rsp+0x40]
00007f30a29d8923  vmovaps xmm6, [rsp+0x50]
00007f30a29d8929  vmovaps xmm7, [rsp+0x60]
00007f30a29d892f  vmovaps xmm8, [rsp+0x70]
00007f30a29d8935  vmovaps xmm9, [rsp+0x80]
00007f30a29d893e  vmovaps xmm10, [rsp+0x90]
00007f30a29d8947  vmovaps xmm11, [rsp+0xA0]
00007f30a29d8950  vmovaps xmm12, [rsp+0xB0]
00007f30a29d8959  vmovaps xmm13, [rsp+0xC0]
00007f30a29d8962  vmovaps xmm14, [rsp+0xD0]
00007f30a29d896b  vmovaps xmm15, [rsp+0xE0]
00007f30a29d8974  add rsp, 0xF0
00007f30a29d897b  pop r11
00007f30a29d897d  pop r10
00007f30a29d897f  pop r9
00007f30a29d8981  pop r8
00007f30a29d8983  pop rsi
00007f30a29d8984  pop rdi
00007f30a29d8985  pop rdx
00007f30a29d8986  pop rcx
00007f30a29d8987  pop rax
00007f30a29d8988  add rsp, 0x08
00007f30a29d898c  jmp 0x00007F30A29D3576
00007f30a29d8991  call 0x00007F30A280D600
00007f30a29d8996  jmp 0x00007F30A29D3589
00007f30a29d899b  call 0x00007F30A280C380
00007f30a29d89a0  jmp 0x00007F30A29D3594
00007f30a29d89a5  call 0x00007F30A280E880
00007f30a29d89aa  jmp 0x00007F30A29D359F
00007f30a29d89af  call 0x00007F30A27FF540
00007f30a29d89b4  jmp 0x00007F30A29D35AA
00007f30a29d89b9  int3
00007f30a29d89ba  nop [rax+rax*1], ax
00007f30a29d89c0  mov rax, [r15+0x40]
00007f30a29d89c4  mov r14, [r15+0x58]
00007f30a29d89c8  lea r12, [rax+r14*1]
00007f30a29d89cc  movaps xmm1, [r15+0x1D0]
00007f30a29d89d4  vmovaps [rsp+0x10], xmm1
00007f30a29d89da  vmovaps xmm15, [rsp+0x10]
00007f30a29d89e0  por xmm1, xmm15
00007f30a29d89e5  movaps xmm14, [r15+0x1A0]
00007f30a29d89ed  vmovaps [rsp+0x10], xmm14
00007f30a29d89f3  vmovaps xmm13, [rsp+0x10]
00007f30a29d89f9  por xmm14, xmm13
00007f30a29d89fe  lea rax, [r12+0x30]
00007f30a29d8a03  mov r11, [r13+rax*1]
00007f30a29d8a08  lea rax, [r12+0x38]
00007f30a29d8a0d  mov r10, [r13+rax*1]
00007f30a29d8a12  movq xmm13, r11
00007f30a29d8a17  movq xmm12, r10
00007f30a29d8a1c  movq xmm13, xmm13
00007f30a29d8a21  vmovaps [rsp+0x10], xmm13
00007f30a29d8a27  movq xmm13, xmm13
00007f30a29d8a2c  movaps [r15+0x130], xmm13
00007f30a29d8a34  movq xmm12, xmm12
00007f30a29d8a39  vmovaps [rsp+0x20], xmm12
00007f30a29d8a3f  movq xmm12, xmm12
00007f30a29d8a44  movaps [r15+0x280], xmm12
00007f30a29d8a4c  movaps xmm13, [r15+0x270]
00007f30a29d8a54  vmovaps [rsp+0x30], xmm13
00007f30a29d8a5a  vmovaps xmm12, [rsp+0x30]
00007f30a29d8a60  por xmm13, xmm12
00007f30a29d8a65  lea rax, [r12+0x20]
00007f30a29d8a6a  mov r11, [r13+rax*1]
00007f30a29d8a6f  lea rax, [r12+0x28]
00007f30a29d8a74  mov r10, [r13+rax*1]
00007f30a29d8a79  movq xmm12, r11
00007f30a29d8a7e  movq xmm11, r10
00007f30a29d8a83  movq xmm12, xmm12
00007f30a29d8a88  vmovaps [rsp+0x30], xmm12
00007f30a29d8a8e  movq xmm12, xmm12
00007f30a29d8a93  movaps [r15+0x150], xmm12
00007f30a29d8a9b  movq xmm11, xmm11
00007f30a29d8aa0  vmovaps [rsp+0x40], xmm11
00007f30a29d8aa6  movq xmm11, xmm11
00007f30a29d8aab  movaps [r15+0x140], xmm11
00007f30a29d8ab3  lea rax, [r12+0x10]
00007f30a29d8ab8  mov r11, [r13+rax*1]
00007f30a29d8abd  lea rax, [r12+0x18]
00007f30a29d8ac2  mov r10, [r13+rax*1]
00007f30a29d8ac7  movq xmm12, r11
00007f30a29d8acc  movq xmm11, r10
00007f30a29d8ad1  movq xmm12, xmm12
00007f30a29d8ad6  vmovaps [rsp+0x50], xmm12
00007f30a29d8adc  movq xmm12, xmm12
00007f30a29d8ae1  movaps [r15+0x170], xmm12
00007f30a29d8ae9  movq xmm11, xmm11
00007f30a29d8aee  vmovaps [rsp+0x60], xmm11
00007f30a29d8af4  movq xmm11, xmm11
00007f30a29d8af9  movaps [r15+0x160], xmm11
00007f30a29d8b01  mov rax, [r13+r12*1]
00007f30a29d8b06  vmovq xmm12, rax
00007f30a29d8b0b  vpbroadcastq xmm12, xmm12
00007f30a29d8b10  lea rax, [r12+0x08]
00007f30a29d8b15  mov r12, [r13+rax*1]
00007f30a29d8b1a  movq xmm11, r12
00007f30a29d8b1f  movaps [r15+0x230], xmm11
00007f30a29d8b27  mov rax, [r15+0xF8]
00007f30a29d8b2e  lea r12, [rax+0x50]
00007f30a29d8b32  movups xmm11, [r13+r12*1]
00007f30a29d8b38  lea r12, [rax+0x60]
00007f30a29d8b3c  movups xmm10, [r13+r12*1]
00007f30a29d8b42  lea r12, [rax+0x30]
00007f30a29d8b46  movups xmm9, [r13+r12*1]
00007f30a29d8b4c  mov r12, [r15+0x50]
00007f30a29d8b50  lea r11, [r12+r14*1]
00007f30a29d8b54  mov [r15+0x60], r11
00007f30a29d8b58  lea r12, [r14+0x40]
00007f30a29d8b5c  mov [r15+0x58], r12
00007f30a29d8b60  movaps xmm8, xmm12
00007f30a29d8b64  mulpd xmm8, xmm15
00007f30a29d8b69  vcmppd xmm7, xmm8, xmm8, 0x03
00007f30a29d8b6f  ptest xmm7, xmm7
00007f30a29d8b74  jnz 0x00007F30A29D9997
00007f30a29d8b7a  movq xmm15, qword ptr [r15+0x230]
00007f30a29d8b83  vmovaps [rsp+0x70], xmm15
00007f30a29d8b89  vpermilpd xmm15, xmm15, 0x00
00007f30a29d8b8f  movaps xmm7, xmm9
00007f30a29d8b93  mulpd xmm7, xmm15
00007f30a29d8b98  vcmppd xmm6, xmm7, xmm7, 0x03
00007f30a29d8b9d  ptest xmm6, xmm6
00007f30a29d8ba2  jnz 0x00007F30A29D9ADB
00007f30a29d8ba8  vxorps xmm15, xmm15, xmm15
00007f30a29d8bad  vpbroadcastq xmm15, xmm15
00007f30a29d8bb2  movaps xmm9, xmm12
00007f30a29d8bb6  mulpd xmm9, xmm10
00007f30a29d8bbb  vcmppd xmm6, xmm9, xmm9, 0x03
00007f30a29d8bc1  ptest xmm6, xmm6
00007f30a29d8bc6  jnz 0x00007F30A29D9C1D
00007f30a29d8bcc  movaps xmm10, xmm12
00007f30a29d8bd0  mulpd xmm10, xmm11
00007f30a29d8bd5  vcmppd xmm6, xmm10, xmm10, 0x03
00007f30a29d8bdb  ptest xmm6, xmm6
00007f30a29d8be0  jnz 0x00007F30A29D9D61
00007f30a29d8be6  movaps xmm11, [r15+0x1F0]
00007f30a29d8bee  movaps xmm6, xmm12
00007f30a29d8bf2  mulpd xmm6, xmm11
00007f30a29d8bf7  vcmppd xmm5, xmm6, xmm6, 0x03
00007f30a29d8bfc  ptest xmm5, xmm5
00007f30a29d8c01  jnz 0x00007F30A29D9EA5
00007f30a29d8c07  movaps xmm12, [r15+0x2A0]
00007f30a29d8c0f  vmovaps [rsp+0x80], xmm12
00007f30a29d8c18  vmovaps xmm11, [rsp+0x80]
00007f30a29d8c21  por xmm12, xmm11
00007f30a29d8c26  movaps xmm11, [r15+0x250]
00007f30a29d8c2e  vmovaps [rsp+0x80], xmm11
00007f30a29d8c37  vmovaps xmm5, [rsp+0x80]
00007f30a29d8c40  por xmm11, xmm5
00007f30a29d8c45  vmovaps xmm4, [rsp+0x70]
00007f30a29d8c4b  vpermilpd xmm4, xmm4, 0x00
00007f30a29d8c51  movaps xmm3, xmm5
00007f30a29d8c54  mulpd xmm3, xmm4
00007f30a29d8c58  vcmppd xmm2, xmm3, xmm3, 0x03
00007f30a29d8c5d  ptest xmm2, xmm2
00007f30a29d8c62  jnz 0x00007F30A29D9FE7
00007f30a29d8c68  mov [rsp+0x80], rax
00007f30a29d8c70  xor eax, eax
00007f30a29d8c72  mov r14d, 0x200
00007f30a29d8c78  cmp r12, r14
00007f30a29d8c7b  cmc
00007f30a29d8c7c  lahf
00007f30a29d8c7d  seto al
00007f30a29d8c80  mov [r15+0x108], eax
00007f30a29d8c87  movaps xmm5, xmm8
00007f30a29d8c8b  addpd xmm5, xmm15
00007f30a29d8c90  vcmppd xmm4, xmm5, xmm5, 0x03
00007f30a29d8c95  ptest xmm4, xmm4
00007f30a29d8c9a  jnz 0x00007F30A29DA127
00007f30a29d8ca0  movaps xmm8, [r15+0x1B0]
00007f30a29d8ca8  movaps xmm4, xmm9
00007f30a29d8cac  addpd xmm4, xmm8
00007f30a29d8cb1  vcmppd xmm2, xmm4, xmm4, 0x03
00007f30a29d8cb6  ptest xmm2, xmm2
00007f30a29d8cbb  jnz 0x00007F30A29DA269
00007f30a29d8cc1  movaps xmm9, xmm10
00007f30a29d8cc5  addpd xmm9, xmm8
00007f30a29d8cca  vcmppd xmm2, xmm9, xmm9, 0x03
00007f30a29d8cd0  ptest xmm2, xmm2
00007f30a29d8cd5  jnz 0x00007F30A29DA3AB
00007f30a29d8cdb  movaps xmm10, [r15+0x2F0]
00007f30a29d8ce3  vmovaps [rsp+0x90], xmm10
00007f30a29d8cec  vmovaps xmm8, [rsp+0x90]
00007f30a29d8cf5  por xmm10, xmm8
00007f30a29d8cfa  movaps xmm8, [r15+0x2E0]
00007f30a29d8d02  vmovaps [rsp+0x90], xmm8
00007f30a29d8d0b  vmovaps xmm2, [rsp+0x90]
00007f30a29d8d14  por xmm8, xmm2
00007f30a29d8d19  movaps xmm2, [r15+0x2D0]
00007f30a29d8d21  vmovaps [rsp+0x90], xmm2
00007f30a29d8d2a  vmovaps [rsp+0xA0], xmm1
00007f30a29d8d33  vmovaps xmm1, [rsp+0x90]
00007f30a29d8d3c  por xmm2, xmm1
00007f30a29d8d40  movaps xmm1, [r15+0x200]
00007f30a29d8d48  vmovaps [rsp+0x90], xmm1
00007f30a29d8d51  vmovaps [rsp+0xB0], xmm15
00007f30a29d8d5a  vmovaps xmm15, [rsp+0x90]
00007f30a29d8d63  por xmm1, xmm15
00007f30a29d8d68  movaps xmm15, [r15+0x1C0]
00007f30a29d8d70  vmovaps [rsp+0x90], xmm15
00007f30a29d8d79  vmovaps [rsp+0xC0], xmm1
00007f30a29d8d82  vmovaps xmm1, [rsp+0x90]
00007f30a29d8d8b  por xmm15, xmm1
00007f30a29d8d90  movaps xmm1, [r15+0x190]
00007f30a29d8d98  vmovaps [rsp+0x90], xmm1
00007f30a29d8da1  vmovaps [rsp+0xD0], xmm15
00007f30a29d8daa  vmovaps xmm15, [rsp+0x90]
00007f30a29d8db3  por xmm1, xmm15
00007f30a29d8db8  movaps xmm15, [r15+0x300]
00007f30a29d8dc0  vmovaps [rsp+0x90], xmm15
00007f30a29d8dc9  vmovaps [rsp+0xE0], xmm1
00007f30a29d8dd2  vmovaps xmm1, [rsp+0x90]
00007f30a29d8ddb  por xmm15, xmm1
00007f30a29d8de0  mov rax, [rsp+0x80]
00007f30a29d8de8  lea r14, [rax+0xA0]
00007f30a29d8def  movups xmm1, [r13+r14*1]
00007f30a29d8df5  lea r14, [rax+0xB0]
00007f30a29d8dfc  vmovaps [rsp+0x80], xmm1
00007f30a29d8e05  movups xmm1, [r13+r14*1]
00007f30a29d8e0b  vmovaps [rsp+0x90], xmm1
00007f30a29d8e14  vmovaps [rsp+0xF0], xmm15
00007f30a29d8e1d  vmovaps xmm15, [rsp+0xB0]
00007f30a29d8e26  vmovaps [rsp+0xB0], xmm14
00007f30a29d8e2f  movaps xmm1, xmm6
00007f30a29d8e32  addpd xmm1, xmm15
00007f30a29d8e37  vcmppd xmm14, xmm1, xmm1, 0x03
00007f30a29d8e3c  ptest xmm14, xmm14
00007f30a29d8e42  jnz 0x00007F30A29DA503
00007f30a29d8e48  lea r14, [rax+0xF0]
00007f30a29d8e4f  movups xmm15, [r13+r14*1]
00007f30a29d8e55  movaps xmm14, xmm4
00007f30a29d8e59  addpd xmm14, xmm3
00007f30a29d8e5e  vcmppd xmm6, xmm14, xmm14, 0x03
00007f30a29d8e64  ptest xmm6, xmm6
00007f30a29d8e69  jnz 0x00007F30A29DA64E
00007f30a29d8e6f  movaps xmm6, xmm9
00007f30a29d8e73  addpd xmm6, xmm7
00007f30a29d8e77  vcmppd xmm4, xmm6, xmm6, 0x03
00007f30a29d8e7c  ptest xmm4, xmm4
00007f30a29d8e81  jnz 0x00007F30A29DA790
00007f30a29d8e87  vmovaps xmm9, [rsp+0x70]
00007f30a29d8e8d  vpermilpd xmm9, xmm9, 0x00
00007f30a29d8e93  vmovaps xmm4, [rsp+0x90]
00007f30a29d8e9c  movaps xmm7, xmm4
00007f30a29d8e9f  mulpd xmm7, xmm9
00007f30a29d8ea4  vcmppd xmm3, xmm7, xmm7, 0x03
00007f30a29d8ea9  ptest xmm3, xmm3
00007f30a29d8eae  jnz 0x00007F30A29DA8D1
00007f30a29d8eb4  vmovaps xmm9, [rsp+0x50]
00007f30a29d8eba  vpermilpd xmm9, xmm9, 0x00
00007f30a29d8ec0  movaps xmm4, xmm15
00007f30a29d8ec4  mulpd xmm4, xmm9
00007f30a29d8ec9  vcmppd xmm3, xmm4, xmm4, 0x03
00007f30a29d8ece  ptest xmm3, xmm3
00007f30a29d8ed3  jnz 0x00007F30A29DAA12
00007f30a29d8ed9  lea r14, [rax+0xE0]
00007f30a29d8ee0  movups xmm15, [r13+r14*1]
00007f30a29d8ee6  vmovaps xmm9, [rsp+0x70]
00007f30a29d8eec  vpermilpd xmm9, xmm9, 0x00
00007f30a29d8ef2  vmovaps [rsp+0x70], xmm1
00007f30a29d8ef8  vmovaps xmm1, [rsp+0x80]
00007f30a29d8f01  vmovaps [rsp+0x80], xmm15
00007f30a29d8f0a  movaps xmm3, xmm1
00007f30a29d8f0d  mulpd xmm3, xmm9
00007f30a29d8f12  vcmppd xmm15, xmm3, xmm3, 0x03
00007f30a29d8f17  ptest xmm15, xmm15
00007f30a29d8f1d  jnz 0x00007F30A29DAB5E
00007f30a29d8f23  vmovaps xmm1, [rsp+0xF0]
00007f30a29d8f2c  vmovaps xmm15, [rsp+0xF0]
00007f30a29d8f35  por xmm1, xmm15
00007f30a29d8f3a  movaps [r15+0x300], xmm1
00007f30a29d8f42  vmovaps xmm15, [rsp+0xE0]
00007f30a29d8f4b  vmovaps xmm9, [rsp+0xE0]
00007f30a29d8f54  por xmm15, xmm9
00007f30a29d8f59  movaps [r15+0x190], xmm15
00007f30a29d8f61  vmovaps xmm9, [rsp+0x50]
00007f30a29d8f67  vpermilpd xmm9, xmm9, 0x00
00007f30a29d8f6d  vmovaps [rsp+0x90], xmm1
00007f30a29d8f76  vmovaps [rsp+0xE0], xmm15
00007f30a29d8f7f  vmovaps xmm15, [rsp+0x80]
00007f30a29d8f88  vmovaps [rsp+0x80], xmm14
00007f30a29d8f91  movaps xmm1, xmm15
00007f30a29d8f95  mulpd xmm1, xmm9
00007f30a29d8f9a  vcmppd xmm14, xmm1, xmm1, 0x03
00007f30a29d8f9f  ptest xmm14, xmm14
00007f30a29d8fa5  jnz 0x00007F30A29DAC9F
00007f30a29d8fab  lea r14, [rax+0x90]
00007f30a29d8fb2  movups xmm15, [r13+r14*1]
00007f30a29d8fb8  vmovaps xmm14, [rsp+0xD0]
00007f30a29d8fc1  vmovaps xmm9, [rsp+0xD0]
00007f30a29d8fca  por xmm14, xmm9
00007f30a29d8fcf  movaps [r15+0x1C0], xmm14
00007f30a29d8fd7  vmovaps xmm9, [rsp+0xC0]
00007f30a29d8fe0  vmovaps [rsp+0xD0], xmm1
00007f30a29d8fe9  vmovaps xmm1, [rsp+0xC0]
00007f30a29d8ff2  por xmm9, xmm1
00007f30a29d8ff7  movaps [r15+0x200], xmm9
00007f30a29d8fff  vmovaps [rsp+0xC0], xmm2
00007f30a29d9008  vmovaps xmm1, [rsp+0xC0]
00007f30a29d9011  por xmm2, xmm1
00007f30a29d9015  movaps [r15+0x2D0], xmm2
00007f30a29d901d  vmovaps [rsp+0xC0], xmm8
00007f30a29d9026  vmovaps xmm1, [rsp+0xC0]
00007f30a29d902f  por xmm8, xmm1
00007f30a29d9034  movaps [r15+0x2E0], xmm8
00007f30a29d903c  vmovaps [rsp+0xC0], xmm15
00007f30a29d9045  movaps xmm1, xmm5
00007f30a29d9048  addpd xmm1, xmm7
00007f30a29d904c  vcmppd xmm15, xmm1, xmm1, 0x03
00007f30a29d9051  ptest xmm15, xmm15
00007f30a29d9057  jnz 0x00007F30A29DADEB
00007f30a29d905d  vmovaps xmm15, [rsp+0x50]
00007f30a29d9063  vpermilpd xmm15, xmm15, 0x00
00007f30a29d9069  vmovaps xmm5, [rsp+0xC0]
00007f30a29d9072  vmovaps [rsp+0xC0], xmm1
00007f30a29d907b  movaps xmm7, xmm5
00007f30a29d907e  mulpd xmm7, xmm15
00007f30a29d9083  vcmppd xmm1, xmm7, xmm7, 0x03
00007f30a29d9088  ptest xmm1, xmm1
00007f30a29d908d  jnz 0x00007F30A29DAF2B
00007f30a29d9093  lea r14, [rax+0x80]
00007f30a29d909a  movups xmm1, [r13+r14*1]
00007f30a29d90a0  vmovaps xmm5, [rsp+0x70]
00007f30a29d90a6  vmovaps [rsp+0x70], xmm1
00007f30a29d90ac  movaps xmm15, xmm5
00007f30a29d90b0  addpd xmm15, xmm3
00007f30a29d90b5  vcmppd xmm1, xmm15, xmm15, 0x03
00007f30a29d90bb  ptest xmm1, xmm1
00007f30a29d90c0  jnz 0x00007F30A29DB076
00007f30a29d90c6  vmovaps xmm5, [rsp+0x80]
00007f30a29d90cf  movaps xmm1, xmm5
00007f30a29d90d2  addpd xmm1, xmm4
00007f30a29d90d6  vcmppd xmm3, xmm1, xmm1, 0x03
00007f30a29d90db  ptest xmm3, xmm3
00007f30a29d90e0  jnz 0x00007F30A29DB1B8
00007f30a29d90e6  vmovaps [rsp+0x80], xmm10
00007f30a29d90ef  vmovaps xmm5, [rsp+0x80]
00007f30a29d90f8  por xmm10, xmm5
00007f30a29d90fd  movaps [r15+0x2F0], xmm10
00007f30a29d9105  vmovaps xmm5, [rsp+0x50]
00007f30a29d910b  vpermilpd xmm5, xmm5, 0x00
00007f30a29d9111  vmovaps xmm3, [rsp+0x70]
00007f30a29d9117  vmovaps [rsp+0x50], xmm1
00007f30a29d911d  movaps xmm4, xmm3
00007f30a29d9120  mulpd xmm4, xmm5
00007f30a29d9124  vcmppd xmm1, xmm4, xmm4, 0x03
00007f30a29d9129  ptest xmm1, xmm1
00007f30a29d912e  jnz 0x00007F30A29DB2F8
00007f30a29d9134  lea r14, [rax+0xD0]
00007f30a29d913b  movups xmm1, [r13+r14*1]
00007f30a29d9141  vmovaps xmm3, [rsp+0xD0]
00007f30a29d914a  vmovaps [rsp+0x70], xmm1
00007f30a29d9150  movaps xmm5, xmm6
00007f30a29d9153  addpd xmm5, xmm3
00007f30a29d9157  vcmppd xmm1, xmm5, xmm5, 0x03
00007f30a29d915c  ptest xmm1, xmm1
00007f30a29d9161  jnz 0x00007F30A29DB442
00007f30a29d9167  vmovaps xmm1, [rsp+0x60]
00007f30a29d916d  vpermilpd xmm1, xmm1, 0x00
00007f30a29d9173  movaps xmm6, xmm9
00007f30a29d9177  mulpd xmm6, xmm1
00007f30a29d917b  vcmppd xmm3, xmm6, xmm6, 0x03
00007f30a29d9180  ptest xmm3, xmm3
00007f30a29d9185  jnz 0x00007F30A29DB582
00007f30a29d918b  movaps [r15+0x260], xmm6
00007f30a29d9193  vxorps xmm1, xmm1, xmm1
00007f30a29d9197  vpbroadcastq xmm1, xmm1
00007f30a29d919c  movaps [r15+0x1B0], xmm1
00007f30a29d91a4  vmovaps xmm1, [rsp+0x60]
00007f30a29d91aa  vpermilpd xmm1, xmm1, 0x00
00007f30a29d91b0  vmovaps xmm3, [rsp+0x70]
00007f30a29d91b6  vmovaps [rsp+0x70], xmm15
00007f30a29d91bc  movaps xmm9, xmm3
00007f30a29d91c0  mulpd xmm9, xmm1
00007f30a29d91c5  vcmppd xmm15, xmm9, xmm9, 0x03
00007f30a29d91cb  ptest xmm15, xmm15
00007f30a29d91d1  jnz 0x00007F30A29DB6C3
00007f30a29d91d7  lea r14, [rax+0xC0]
00007f30a29d91de  movups xmm1, [r13+r14*1]
00007f30a29d91e4  vmovaps xmm3, [rsp+0xC0]
00007f30a29d91ed  vmovaps [rsp+0x80], xmm1
00007f30a29d91f6  movaps xmm15, xmm3
00007f30a29d91fa  addpd xmm15, xmm7
00007f30a29d91ff  vcmppd xmm1, xmm15, xmm15, 0x03
00007f30a29d9205  ptest xmm1, xmm1
00007f30a29d920a  jnz 0x00007F30A29DB80F
00007f30a29d9210  vmovaps [rsp+0xC0], xmm13
00007f30a29d9219  vmovaps xmm1, [rsp+0xC0]
00007f30a29d9222  por xmm13, xmm1
00007f30a29d9227  movaps [r15+0x270], xmm13
00007f30a29d922f  vmovaps xmm1, [rsp+0xB0]
00007f30a29d9238  vmovaps xmm7, [rsp+0xB0]
00007f30a29d9241  por xmm1, xmm7
00007f30a29d9245  movaps [r15+0x1A0], xmm1
00007f30a29d924d  vmovaps xmm1, [rsp+0x60]
00007f30a29d9253  vpermilpd xmm1, xmm1, 0x00
00007f30a29d9259  vmovaps [rsp+0xB0], xmm1
00007f30a29d9262  vmovaps xmm1, [rsp+0x80]
00007f30a29d926b  vmovaps [rsp+0x80], xmm15
00007f30a29d9274  vmovaps xmm15, [rsp+0xB0]
00007f30a29d927d  vmovaps [rsp+0xB0], xmm14
00007f30a29d9286  movaps xmm3, xmm1
00007f30a29d9289  mulpd xmm3, xmm15
00007f30a29d928e  vcmppd xmm14, xmm3, xmm3, 0x03
00007f30a29d9293  ptest xmm14, xmm14
00007f30a29d9299  jnz 0x00007F30A29DB951
00007f30a29d929f  lea r14, [rax+0x20]
00007f30a29d92a3  movups xmm1, [r13+r14*1]
00007f30a29d92a9  movaps [r15+0x110], xmm1
00007f30a29d92b1  vmovaps xmm14, [rsp+0x70]
00007f30a29d92b7  vmovaps [rsp+0x70], xmm1
00007f30a29d92bd  movaps xmm15, xmm14
00007f30a29d92c1  addpd xmm15, xmm4
00007f30a29d92c6  vcmppd xmm1, xmm15, xmm15, 0x03
00007f30a29d92cc  ptest xmm1, xmm1
00007f30a29d92d1  jnz 0x00007F30A29DBA9C
00007f30a29d92d7  vmovaps xmm1, [rsp+0x60]
00007f30a29d92dd  vpermilpd xmm1, xmm1, 0x00
00007f30a29d92e3  movaps xmm14, xmm2
00007f30a29d92e7  mulpd xmm14, xmm1
00007f30a29d92ec  vcmppd xmm4, xmm14, xmm14, 0x03
00007f30a29d92f2  ptest xmm4, xmm4
00007f30a29d92f7  jnz 0x00007F30A29DBBDF
00007f30a29d92fd  vmovaps xmm4, [rsp+0x50]
00007f30a29d9303  movaps xmm1, xmm4
00007f30a29d9306  addpd xmm1, xmm9
00007f30a29d930b  vcmppd xmm2, xmm1, xmm1, 0x03
00007f30a29d9310  ptest xmm2, xmm2
00007f30a29d9315  jnz 0x00007F30A29DBD21
00007f30a29d931b  vmovaps xmm9, [rsp+0x30]
00007f30a29d9321  vpermilpd xmm9, xmm9, 0x00
00007f30a29d9327  vmovaps xmm2, [rsp+0x70]
00007f30a29d932d  vmovaps [rsp+0x50], xmm1
00007f30a29d9333  movaps xmm4, xmm2
00007f30a29d9336  mulpd xmm4, xmm9
00007f30a29d933b  vcmppd xmm1, xmm4, xmm4, 0x03
00007f30a29d9340  ptest xmm1, xmm1
00007f30a29d9345  jnz 0x00007F30A29DBE62
00007f30a29d934b  vmovaps xmm1, [rsp+0x30]
00007f30a29d9351  vpermilpd xmm1, xmm1, 0x00
00007f30a29d9357  vmovaps xmm2, [rsp+0x90]
00007f30a29d9360  vmovaps [rsp+0x60], xmm15
00007f30a29d9366  movaps xmm9, xmm2
00007f30a29d936a  mulpd xmm9, xmm1
00007f30a29d936f  vcmppd xmm15, xmm9, xmm9, 0x03
00007f30a29d9375  ptest xmm15, xmm15
00007f30a29d937b  jnz 0x00007F30A29DBFA3
00007f30a29d9381  vmovaps xmm15, [rsp+0x80]
00007f30a29d938a  movaps xmm1, xmm15
00007f30a29d938e  addpd xmm1, xmm6
00007f30a29d9392  vcmppd xmm2, xmm1, xmm1, 0x03
00007f30a29d9397  ptest xmm2, xmm2
00007f30a29d939c  jnz 0x00007F30A29DC0E5
00007f30a29d93a2  movaps xmm15, xmm5
00007f30a29d93a6  addpd xmm15, xmm3
00007f30a29d93ab  vcmppd xmm6, xmm15, xmm15, 0x03
00007f30a29d93b1  ptest xmm6, xmm6
00007f30a29d93b6  jnz 0x00007F30A29DC226
00007f30a29d93bc  vmovaps xmm6, [rsp+0x30]
00007f30a29d93c2  vpermilpd xmm6, xmm6, 0x00
00007f30a29d93c8  movaps xmm5, xmm8
00007f30a29d93cc  mulpd xmm5, xmm6
00007f30a29d93d0  vcmppd xmm3, xmm5, xmm5, 0x03
00007f30a29d93d5  ptest xmm3, xmm3
00007f30a29d93da  jnz 0x00007F30A29DC368
00007f30a29d93e0  vmovaps xmm8, [rsp+0x30]
00007f30a29d93e6  vpermilpd xmm8, xmm8, 0x00
00007f30a29d93ec  movaps xmm6, xmm10
00007f30a29d93f0  mulpd xmm6, xmm8
00007f30a29d93f5  vcmppd xmm3, xmm6, xmm6, 0x03
00007f30a29d93fa  ptest xmm3, xmm3
00007f30a29d93ff  jnz 0x00007F30A29DC4A9
00007f30a29d9405  vmovaps xmm8, [rsp+0x60]
00007f30a29d940b  movaps xmm10, xmm8
00007f30a29d940f  addpd xmm10, xmm14
00007f30a29d9414  vcmppd xmm3, xmm10, xmm10, 0x03
00007f30a29d941a  ptest xmm3, xmm3
00007f30a29d941f  jnz 0x00007F30A29DC5EB
00007f30a29d9425  vmovaps xmm8, [rsp+0x50]
00007f30a29d942b  movaps xmm14, xmm8
00007f30a29d942f  addpd xmm14, xmm4
00007f30a29d9434  vcmppd xmm3, xmm14, xmm14, 0x03
00007f30a29d943a  ptest xmm3, xmm3
00007f30a29d943f  jnz 0x00007F30A29DC72F
00007f30a29d9445  vmovaps xmm8, [rsp+0x40]
00007f30a29d944b  vpermilpd xmm8, xmm8, 0x00
00007f30a29d9451  movaps xmm4, xmm13
00007f30a29d9455  mulpd xmm4, xmm8
00007f30a29d945a  vcmppd xmm3, xmm4, xmm4, 0x03
00007f30a29d945f  ptest xmm3, xmm3
00007f30a29d9464  jnz 0x00007F30A29DC872
00007f30a29d946a  movaps xmm13, xmm15
00007f30a29d946e  addpd xmm13, xmm9
00007f30a29d9473  vcmppd xmm8, xmm13, xmm13, 0x03
00007f30a29d9479  ptest xmm8, xmm8
00007f30a29d947f  jnz 0x00007F30A29DC9B4
00007f30a29d9485  movaps xmm15, xmm1
00007f30a29d9489  addpd xmm15, xmm5
00007f30a29d948e  vcmppd xmm9, xmm15, xmm15, 0x03
00007f30a29d9494  ptest xmm9, xmm9
00007f30a29d949a  jnz 0x00007F30A29DCAF8
00007f30a29d94a0  vmovaps [rsp+0x30], xmm11
00007f30a29d94a6  vmovaps xmm1, [rsp+0x30]
00007f30a29d94ac  por xmm11, xmm1
00007f30a29d94b1  movaps [r15+0x250], xmm11
00007f30a29d94b9  vmovaps [rsp+0x30], xmm12
00007f30a29d94bf  vmovaps xmm1, [rsp+0x30]
00007f30a29d94c5  por xmm12, xmm1
00007f30a29d94ca  movaps [r15+0x2A0], xmm12
00007f30a29d94d2  vmovaps xmm1, [rsp+0xA0]
00007f30a29d94db  vmovaps xmm11, [rsp+0xA0]
00007f30a29d94e4  por xmm1, xmm11
00007f30a29d94e9  movaps [r15+0x1D0], xmm1
00007f30a29d94f1  lea r14, [rax+0x40]
00007f30a29d94f5  movups xmm1, [r13+r14*1]
00007f30a29d94fb  movaps [r15+0x2C0], xmm1
00007f30a29d9503  vmovaps xmm11, [rsp+0x40]
00007f30a29d9509  vpermilpd xmm11, xmm11, 0x00
00007f30a29d950f  vmovaps xmm8, [rsp+0xE0]
00007f30a29d9518  movaps xmm9, xmm8
00007f30a29d951c  mulpd xmm9, xmm11
00007f30a29d9521  vcmppd xmm5, xmm9, xmm9, 0x03
00007f30a29d9527  ptest xmm5, xmm5
00007f30a29d952c  jnz 0x00007F30A29DCC44
00007f30a29d9532  movaps xmm11, xmm10
00007f30a29d9536  addpd xmm11, xmm6
00007f30a29d953b  vcmppd xmm8, xmm11, xmm11, 0x03
00007f30a29d9541  ptest xmm8, xmm8
00007f30a29d9547  jnz 0x00007F30A29DCD88
00007f30a29d954d  movaps xmm10, xmm14
00007f30a29d9551  addpd xmm10, xmm4
00007f30a29d9556  vcmppd xmm8, xmm10, xmm10, 0x03
00007f30a29d955c  ptest xmm8, xmm8
00007f30a29d9562  jnz 0x00007F30A29DCECB
00007f30a29d9568  vmovaps xmm14, [rsp+0x40]
00007f30a29d956e  vpermilpd xmm14, xmm14, 0x00
00007f30a29d9574  movaps xmm8, xmm1
00007f30a29d9578  mulpd xmm8, xmm14
00007f30a29d957d  vcmppd xmm6, xmm8, xmm8, 0x03
00007f30a29d9583  ptest xmm6, xmm6
00007f30a29d9588  jnz 0x00007F30A29DD00E
00007f30a29d958e  movaps xmm1, [r15+0x2B0]
00007f30a29d9596  vmovaps xmm14, [rsp+0x40]
00007f30a29d959c  vpermilpd xmm14, xmm14, 0x00
00007f30a29d95a2  movaps xmm6, xmm1
00007f30a29d95a5  mulpd xmm6, xmm14
00007f30a29d95aa  vcmppd xmm5, xmm6, xmm6, 0x03
00007f30a29d95af  ptest xmm5, xmm5
00007f30a29d95b4  jnz 0x00007F30A29DD151
00007f30a29d95ba  vmovaps xmm1, [rsp+0x10]
00007f30a29d95c0  vpermilpd xmm1, xmm1, 0x00
00007f30a29d95c6  movaps xmm14, xmm12
00007f30a29d95ca  mulpd xmm14, xmm1
00007f30a29d95cf  vcmppd xmm5, xmm14, xmm14, 0x03
00007f30a29d95d5  ptest xmm5, xmm5
00007f30a29d95da  jnz 0x00007F30A29DD292
00007f30a29d95e0  movaps xmm1, xmm13
00007f30a29d95e4  addpd xmm1, xmm9
00007f30a29d95e9  vcmppd xmm12, xmm1, xmm1, 0x03
00007f30a29d95ee  ptest xmm12, xmm12
00007f30a29d95f4  jnz 0x00007F30A29DD3D5
00007f30a29d95fa  vmovaps xmm13, [rsp+0x10]
00007f30a29d9600  vpermilpd xmm13, xmm13, 0x00
00007f30a29d9606  movaps xmm12, xmm7
00007f30a29d960a  mulpd xmm12, xmm13
00007f30a29d960f  vcmppd xmm9, xmm12, xmm12, 0x03
00007f30a29d9615  ptest xmm9, xmm9
00007f30a29d961b  jnz 0x00007F30A29DD517
00007f30a29d9621  movaps xmm13, xmm15
00007f30a29d9625  addpd xmm13, xmm8
00007f30a29d962a  vcmppd xmm9, xmm13, xmm13, 0x03
00007f30a29d9630  ptest xmm9, xmm9
00007f30a29d9636  jnz 0x00007F30A29DD65A
00007f30a29d963c  movaps xmm15, [r15+0x290]
00007f30a29d9644  vmovaps xmm9, [rsp+0x10]
00007f30a29d964a  vpermilpd xmm9, xmm9, 0x00
00007f30a29d9650  movaps xmm8, xmm15
00007f30a29d9654  mulpd xmm8, xmm9
00007f30a29d9659  vcmppd xmm7, xmm8, xmm8, 0x03
00007f30a29d965f  ptest xmm7, xmm7
00007f30a29d9664  jnz 0x00007F30A29DD79E
00007f30a29d966a  movaps xmm15, xmm11
00007f30a29d966e  addpd xmm15, xmm6
00007f30a29d9673  vcmppd xmm9, xmm15, xmm15, 0x03
00007f30a29d9679  ptest xmm9, xmm9
00007f30a29d967f  jnz 0x00007F30A29DD8E2
00007f30a29d9685  movaps xmm11, [r15+0x1E0]
00007f30a29d968d  vmovaps xmm9, [rsp+0x10]
00007f30a29d9693  vpermilpd xmm9, xmm9, 0x00
00007f30a29d9699  movaps xmm7, xmm11
00007f30a29d969d  mulpd xmm7, xmm9
00007f30a29d96a2  vcmppd xmm6, xmm7, xmm7, 0x03
00007f30a29d96a7  ptest xmm6, xmm6
00007f30a29d96ac  jnz 0x00007F30A29DDA25
00007f30a29d96b2  movaps xmm11, xmm10
00007f30a29d96b6  addpd xmm11, xmm14
00007f30a29d96bb  vcmppd xmm9, xmm11, xmm11, 0x03
00007f30a29d96c1  ptest xmm9, xmm9
00007f30a29d96c7  jnz 0x00007F30A29DDB67
00007f30a29d96cd  lea r14, [rax+0x70]
00007f30a29d96d1  movups xmm14, [r13+r14*1]
00007f30a29d96d7  movaps [r15+0x240], xmm14
00007f30a29d96df  movaps xmm10, xmm1
00007f30a29d96e3  addpd xmm10, xmm12
00007f30a29d96e8  vcmppd xmm9, xmm10, xmm10, 0x03
00007f30a29d96ee  ptest xmm9, xmm9
00007f30a29d96f4  jnz 0x00007F30A29DDCB5
00007f30a29d96fa  movaps [r15+0x170], xmm10
00007f30a29d9702  vmovaps xmm1, [rsp+0x20]
00007f30a29d9708  vpermilpd xmm1, xmm1, 0x00
00007f30a29d970e  movaps xmm12, xmm14
00007f30a29d9712  mulpd xmm12, xmm1
00007f30a29d9717  vcmppd xmm9, xmm12, xmm12, 0x03
00007f30a29d971d  ptest xmm9, xmm9
00007f30a29d9723  jnz 0x00007F30A29DDDF8
00007f30a29d9729  vmovaps xmm1, [rsp+0x20]
00007f30a29d972f  vpermilpd xmm1, xmm1, 0x00
00007f30a29d9735  vmovaps xmm9, [rsp+0xB0]
00007f30a29d973e  movaps xmm14, xmm9
00007f30a29d9742  mulpd xmm14, xmm1
00007f30a29d9747  vcmppd xmm6, xmm14, xmm14, 0x03
00007f30a29d974d  ptest xmm6, xmm6
00007f30a29d9752  jnz 0x00007F30A29DDF3B
00007f30a29d9758  movaps [r15+0x180], xmm14
00007f30a29d9760  movaps xmm1, xmm13
00007f30a29d9764  addpd xmm1, xmm8
00007f30a29d9769  vcmppd xmm9, xmm1, xmm1, 0x03
00007f30a29d976e  ptest xmm9, xmm9
00007f30a29d9774  jnz 0x00007F30A29DE07E
00007f30a29d977a  movaps [r15+0x210], xmm1
00007f30a29d9782  movups xmm13, [r13+rax*1]
00007f30a29d9788  lea r14, [rax+0x10]
00007f30a29d978c  movups xmm9, [r13+r14*1]
00007f30a29d9792  movaps [r15+0x230], xmm9
00007f30a29d979a  movaps xmm8, xmm15
00007f30a29d979e  addpd xmm8, xmm7
00007f30a29d97a3  vcmppd xmm6, xmm8, xmm8, 0x03
00007f30a29d97a9  ptest xmm6, xmm6
00007f30a29d97ae  jnz 0x00007F30A29DE1D4
00007f30a29d97b4  movaps [r15+0x130], xmm8
00007f30a29d97bc  vmovaps xmm15, [rsp+0x20]
00007f30a29d97c2  vpermilpd xmm15, xmm15, 0x00
00007f30a29d97c8  movaps xmm7, xmm9
00007f30a29d97cc  mulpd xmm7, xmm15
00007f30a29d97d1  vcmppd xmm6, xmm7, xmm7, 0x03
00007f30a29d97d6  ptest xmm6, xmm6
00007f30a29d97db  jnz 0x00007F30A29DE317
00007f30a29d97e1  movaps [r15+0x220], xmm7
00007f30a29d97e9  vmovaps xmm15, [rsp+0x20]
00007f30a29d97ef  vpermilpd xmm15, xmm15, 0x00
00007f30a29d97f5  movaps xmm9, xmm13
00007f30a29d97f9  mulpd xmm9, xmm15
00007f30a29d97fe  vcmppd xmm6, xmm9, xmm9, 0x03
00007f30a29d9804  ptest xmm6, xmm6
00007f30a29d9809  jnz 0x00007F30A29DE459
00007f30a29d980f  movaps xmm15, xmm11
00007f30a29d9813  addpd xmm15, xmm12
00007f30a29d9818  vcmppd xmm13, xmm15, xmm15, 0x03
00007f30a29d981e  ptest xmm13, xmm13
00007f30a29d9824  jnz 0x00007F30A29DE59D
00007f30a29d982a  movaps [r15+0x140], xmm15
00007f30a29d9832  movaps xmm13, xmm10
00007f30a29d9836  addpd xmm13, xmm14
00007f30a29d983b  vcmppd xmm12, xmm13, xmm13, 0x03
00007f30a29d9841  ptest xmm12, xmm12
00007f30a29d9847  jnz 0x00007F30A29DE6E1
00007f30a29d984d  movaps [r15+0x150], xmm13
00007f30a29d9855  movaps xmm14, xmm1
00007f30a29d9859  addpd xmm14, xmm7
00007f30a29d985e  vcmppd xmm12, xmm14, xmm14, 0x03
00007f30a29d9864  ptest xmm12, xmm12
00007f30a29d986a  jnz 0x00007F30A29DE825
00007f30a29d9870  movaps [r15+0x160], xmm14
00007f30a29d9878  movaps xmm1, xmm8
00007f30a29d987c  addpd xmm1, xmm9
00007f30a29d9881  vcmppd xmm12, xmm1, xmm1, 0x03
00007f30a29d9886  ptest xmm12, xmm12
00007f30a29d988c  jnz 0x00007F30A29DE967
00007f30a29d9892  movaps [r15+0x120], xmm1
00007f30a29d989a  movups [r13+r11*1], xmm15
00007f30a29d98a0  lea rax, [r11+0x10]
00007f30a29d98a4  movups [r13+rax*1], xmm13
00007f30a29d98aa  lea rax, [r11+0x20]
00007f30a29d98ae  movups [r13+rax*1], xmm14
00007f30a29d98b4  lea rax, [r11+0x30]
00007f30a29d98b8  movups [r13+rax*1], xmm1
00007f30a29d98be  mov eax, [r15+0x108]
00007f30a29d98c5  sahf
00007f30a29d98c6  jnz 0x00007F30A29D98F8
00007f30a29d98c8  cmp dword ptr [r15+0x318], 0x00
00007f30a29d98d0  jz 0x00007F30A29DEAE0
00007f30a29d98d6  nop [rax+rax*1], ax
00007f30a29d98df  nop [rax+rax*1], eax
00007f30a29d98e7  mov eax, 0x4106D0
00007f30a29d98ec  mov [r15+0x100], rax
00007f30a29d98f3  jmp 0x00007F30A27FE110
00007f30a29d98f8  cmp dword ptr [r15+0x318], 0x00
00007f30a29d9900  jz 0x00007F30A29D89C0
00007f30a29d9906  nop [rax+rax*1], ax
00007f30a29d990f  nop [rax+rax*1], eax
00007f30a29d9917  mov eax, 0x410504
00007f30a29d991c  mov [r15+0x100], rax
00007f30a29d9923  jmp 0x00007F30A27FE110
00007f30a29d9928  int3
00007f30a29d9929  call 0x00007F30A280A4B0
00007f30a29d992e  jmp 0x00007F30A29D8A08
00007f30a29d9933  call 0x00007F30A2809240
00007f30a29d9938  jmp 0x00007F30A29D8A12
00007f30a29d993d  call 0x00007F30A280A4B0
00007f30a29d9942  jmp 0x00007F30A29D8A6F
00007f30a29d9947  call 0x00007F30A2809240
00007f30a29d994c  jmp 0x00007F30A29D8A79
00007f30a29d9951  call 0x00007F30A280A4B0
00007f30a29d9956  jmp 0x00007F30A29D8ABD
00007f30a29d995b  call 0x00007F30A2809240
00007f30a29d9960  jmp 0x00007F30A29D8AC7
00007f30a29d9965  call 0x00007F30A28B47C0
00007f30a29d996a  jmp 0x00007F30A29D8B06
00007f30a29d996f  call 0x00007F30A280B720
00007f30a29d9974  jmp 0x00007F30A29D8B1A
00007f30a29d9979  call 0x00007F30A28BFC30
00007f30a29d997e  jmp 0x00007F30A29D8B38
00007f30a29d9983  call 0x00007F30A28BE9C0
00007f30a29d9988  jmp 0x00007F30A29D8B42
00007f30a29d998d  call 0x00007F30A28BD750
00007f30a29d9992  jmp 0x00007F30A29D8B4C
00007f30a29d9997  sub rsp, 0x08
00007f30a29d999b  push rax
00007f30a29d999c  push rcx
00007f30a29d999d  push rdx
00007f30a29d999e  push rdi
00007f30a29d999f  push rsi
00007f30a29d99a0  push r8
00007f30a29d99a2  push r9
00007f30a29d99a4  push r10
00007f30a29d99a6  push r11
00007f30a29d99a8  sub rsp, 0xF0
00007f30a29d99af  vmovaps [rsp], xmm0
00007f30a29d99b4  vmovaps [rsp+0x10], xmm1
00007f30a29d99ba  vmovaps [rsp+0x20], xmm2
00007f30a29d99c0  vmovaps [rsp+0x30], xmm3
00007f30a29d99c6  vmovaps [rsp+0x40], xmm4
00007f30a29d99cc  vmovaps [rsp+0x50], xmm5
00007f30a29d99d2  vmovaps [rsp+0x60], xmm6
00007f30a29d99d8  vmovaps [rsp+0x70], xmm7
00007f30a29d99de  vmovaps [rsp+0x80], xmm9
00007f30a29d99e7  vmovaps [rsp+0x90], xmm10
00007f30a29d99f0  vmovaps [rsp+0xA0], xmm11
00007f30a29d99f9  vmovaps [rsp+0xB0], xmm12
00007f30a29d9a02  vmovaps [rsp+0xC0], xmm13
00007f30a29d9a0b  vmovaps [rsp+0xD0], xmm14
00007f30a29d9a14  vmovaps [rsp+0xE0], xmm15
00007f30a29d9a1d  sub rsp, 0x30
00007f30a29d9a21  movaps [rsp], xmm8
00007f30a29d9a26  movaps [rsp+0x10], xmm12
00007f30a29d9a2c  movaps [rsp+0x20], xmm15
00007f30a29d9a32  lea rdi, [rsp]
00007f30a29d9a36  mov esi, 0x00
00007f30a29d9a3b  mov rax, 0x5FE955026530
00007f30a29d9a45  call rax
00007f30a29d9a47  movaps xmm8, [rsp]
00007f30a29d9a4c  add rsp, 0x30
00007f30a29d9a50  vmovaps xmm0, [rsp]
00007f30a29d9a55  vmovaps xmm1, [rsp+0x10]
00007f30a29d9a5b  vmovaps xmm2, [rsp+0x20]
00007f30a29d9a61  vmovaps xmm3, [rsp+0x30]
00007f30a29d9a67  vmovaps xmm4, [rsp+0x40]
00007f30a29d9a6d  vmovaps xmm5, [rsp+0x50]
00007f30a29d9a73  vmovaps xmm6, [rsp+0x60]
00007f30a29d9a79  vmovaps xmm7, [rsp+0x70]
00007f30a29d9a7f  vmovaps xmm9, [rsp+0x80]
00007f30a29d9a88  vmovaps xmm10, [rsp+0x90]
00007f30a29d9a91  vmovaps xmm11, [rsp+0xA0]
00007f30a29d9a9a  vmovaps xmm12, [rsp+0xB0]
00007f30a29d9aa3  vmovaps xmm13, [rsp+0xC0]
00007f30a29d9aac  vmovaps xmm14, [rsp+0xD0]
00007f30a29d9ab5  vmovaps xmm15, [rsp+0xE0]
00007f30a29d9abe  add rsp, 0xF0
00007f30a29d9ac5  pop r11
00007f30a29d9ac7  pop r10
00007f30a29d9ac9  pop r9
00007f30a29d9acb  pop r8
00007f30a29d9acd  pop rsi
00007f30a29d9ace  pop rdi
00007f30a29d9acf  pop rdx
00007f30a29d9ad0  pop rcx
00007f30a29d9ad1  pop rax
00007f30a29d9ad2  add rsp, 0x08
00007f30a29d9ad6  jmp 0x00007F30A29D8B7A
00007f30a29d9adb  sub rsp, 0x08
00007f30a29d9adf  push rax
00007f30a29d9ae0  push rcx
00007f30a29d9ae1  push rdx
00007f30a29d9ae2  push rdi
00007f30a29d9ae3  push rsi
00007f30a29d9ae4  push r8
00007f30a29d9ae6  push r9
00007f30a29d9ae8  push r10
00007f30a29d9aea  push r11
00007f30a29d9aec  sub rsp, 0xF0
00007f30a29d9af3  vmovaps [rsp], xmm0
00007f30a29d9af8  vmovaps [rsp+0x10], xmm1
00007f30a29d9afe  vmovaps [rsp+0x20], xmm2
00007f30a29d9b04  vmovaps [rsp+0x30], xmm3
00007f30a29d9b0a  vmovaps [rsp+0x40], xmm4
00007f30a29d9b10  vmovaps [rsp+0x50], xmm5
00007f30a29d9b16  vmovaps [rsp+0x60], xmm6
00007f30a29d9b1c  vmovaps [rsp+0x70], xmm8
00007f30a29d9b22  vmovaps [rsp+0x80], xmm9
00007f30a29d9b2b  vmovaps [rsp+0x90], xmm10
00007f30a29d9b34  vmovaps [rsp+0xA0], xmm11
00007f30a29d9b3d  vmovaps [rsp+0xB0], xmm12
00007f30a29d9b46  vmovaps [rsp+0xC0], xmm13
00007f30a29d9b4f  vmovaps [rsp+0xD0], xmm14
00007f30a29d9b58  vmovaps [rsp+0xE0], xmm15
00007f30a29d9b61  sub rsp, 0x30
00007f30a29d9b65  movaps [rsp], xmm7
00007f30a29d9b69  movaps [rsp+0x10], xmm9
00007f30a29d9b6f  movaps [rsp+0x20], xmm15
00007f30a29d9b75  lea rdi, [rsp]
00007f30a29d9b79  mov esi, 0x00
00007f30a29d9b7e  mov rax, 0x5FE955026530
00007f30a29d9b88  call rax
00007f30a29d9b8a  movaps xmm7, [rsp]
00007f30a29d9b8e  add rsp, 0x30
00007f30a29d9b92  vmovaps xmm0, [rsp]
00007f30a29d9b97  vmovaps xmm1, [rsp+0x10]
00007f30a29d9b9d  vmovaps xmm2, [rsp+0x20]
00007f30a29d9ba3  vmovaps xmm3, [rsp+0x30]
00007f30a29d9ba9  vmovaps xmm4, [rsp+0x40]
00007f30a29d9baf  vmovaps xmm5, [rsp+0x50]
00007f30a29d9bb5  vmovaps xmm6, [rsp+0x60]
00007f30a29d9bbb  vmovaps xmm8, [rsp+0x70]
00007f30a29d9bc1  vmovaps xmm9, [rsp+0x80]
00007f30a29d9bca  vmovaps xmm10, [rsp+0x90]
00007f30a29d9bd3  vmovaps xmm11, [rsp+0xA0]
00007f30a29d9bdc  vmovaps xmm12, [rsp+0xB0]
00007f30a29d9be5  vmovaps xmm13, [rsp+0xC0]
00007f30a29d9bee  vmovaps xmm14, [rsp+0xD0]
00007f30a29d9bf7  vmovaps xmm15, [rsp+0xE0]
00007f30a29d9c00  add rsp, 0xF0
00007f30a29d9c07  pop r11
00007f30a29d9c09  pop r10
00007f30a29d9c0b  pop r9
00007f30a29d9c0d  pop r8
00007f30a29d9c0f  pop rsi
00007f30a29d9c10  pop rdi
00007f30a29d9c11  pop rdx
00007f30a29d9c12  pop rcx
00007f30a29d9c13  pop rax
00007f30a29d9c14  add rsp, 0x08
00007f30a29d9c18  jmp 0x00007F30A29D8BA8
00007f30a29d9c1d  sub rsp, 0x08
00007f30a29d9c21  push rax
00007f30a29d9c22  push rcx
00007f30a29d9c23  push rdx
00007f30a29d9c24  push rdi
00007f30a29d9c25  push rsi
00007f30a29d9c26  push r8
00007f30a29d9c28  push r9
00007f30a29d9c2a  push r10
00007f30a29d9c2c  push r11
00007f30a29d9c2e  sub rsp, 0xF0
00007f30a29d9c35  vmovaps [rsp], xmm0
00007f30a29d9c3a  vmovaps [rsp+0x10], xmm1
00007f30a29d9c40  vmovaps [rsp+0x20], xmm2
00007f30a29d9c46  vmovaps [rsp+0x30], xmm3
00007f30a29d9c4c  vmovaps [rsp+0x40], xmm4
00007f30a29d9c52  vmovaps [rsp+0x50], xmm5
00007f30a29d9c58  vmovaps [rsp+0x60], xmm6
00007f30a29d9c5e  vmovaps [rsp+0x70], xmm7
00007f30a29d9c64  vmovaps [rsp+0x80], xmm8
00007f30a29d9c6d  vmovaps [rsp+0x90], xmm10
00007f30a29d9c76  vmovaps [rsp+0xA0], xmm11
00007f30a29d9c7f  vmovaps [rsp+0xB0], xmm12
00007f30a29d9c88  vmovaps [rsp+0xC0], xmm13
00007f30a29d9c91  vmovaps [rsp+0xD0], xmm14
00007f30a29d9c9a  vmovaps [rsp+0xE0], xmm15
00007f30a29d9ca3  sub rsp, 0x30
00007f30a29d9ca7  movaps [rsp], xmm9
00007f30a29d9cac  movaps [rsp+0x10], xmm12
00007f30a29d9cb2  movaps [rsp+0x20], xmm10
00007f30a29d9cb8  lea rdi, [rsp]
00007f30a29d9cbc  mov esi, 0x00
00007f30a29d9cc1  mov rax, 0x5FE955026530
00007f30a29d9ccb  call rax
00007f30a29d9ccd  movaps xmm9, [rsp]
00007f30a29d9cd2  add rsp, 0x30
00007f30a29d9cd6  vmovaps xmm0, [rsp]
00007f30a29d9cdb  vmovaps xmm1, [rsp+0x10]
00007f30a29d9ce1  vmovaps xmm2, [rsp+0x20]
00007f30a29d9ce7  vmovaps xmm3, [rsp+0x30]
00007f30a29d9ced  vmovaps xmm4, [rsp+0x40]
00007f30a29d9cf3  vmovaps xmm5, [rsp+0x50]
00007f30a29d9cf9  vmovaps xmm6, [rsp+0x60]
00007f30a29d9cff  vmovaps xmm7, [rsp+0x70]
00007f30a29d9d05  vmovaps xmm8, [rsp+0x80]
00007f30a29d9d0e  vmovaps xmm10, [rsp+0x90]
00007f30a29d9d17  vmovaps xmm11, [rsp+0xA0]
00007f30a29d9d20  vmovaps xmm12, [rsp+0xB0]
00007f30a29d9d29  vmovaps xmm13, [rsp+0xC0]
00007f30a29d9d32  vmovaps xmm14, [rsp+0xD0]
00007f30a29d9d3b  vmovaps xmm15, [rsp+0xE0]
00007f30a29d9d44  add rsp, 0xF0
00007f30a29d9d4b  pop r11
00007f30a29d9d4d  pop r10
00007f30a29d9d4f  pop r9
00007f30a29d9d51  pop r8
00007f30a29d9d53  pop rsi
00007f30a29d9d54  pop rdi
00007f30a29d9d55  pop rdx
00007f30a29d9d56  pop rcx
00007f30a29d9d57  pop rax
00007f30a29d9d58  add rsp, 0x08
00007f30a29d9d5c  jmp 0x00007F30A29D8BCC
00007f30a29d9d61  sub rsp, 0x08
00007f30a29d9d65  push rax
00007f30a29d9d66  push rcx
00007f30a29d9d67  push rdx
00007f30a29d9d68  push rdi
00007f30a29d9d69  push rsi
00007f30a29d9d6a  push r8
00007f30a29d9d6c  push r9
00007f30a29d9d6e  push r10
00007f30a29d9d70  push r11
00007f30a29d9d72  sub rsp, 0xF0
00007f30a29d9d79  vmovaps [rsp], xmm0
00007f30a29d9d7e  vmovaps [rsp+0x10], xmm1
00007f30a29d9d84  vmovaps [rsp+0x20], xmm2
00007f30a29d9d8a  vmovaps [rsp+0x30], xmm3
00007f30a29d9d90  vmovaps [rsp+0x40], xmm4
00007f30a29d9d96  vmovaps [rsp+0x50], xmm5
00007f30a29d9d9c  vmovaps [rsp+0x60], xmm6
00007f30a29d9da2  vmovaps [rsp+0x70], xmm7
00007f30a29d9da8  vmovaps [rsp+0x80], xmm8
00007f30a29d9db1  vmovaps [rsp+0x90], xmm9
00007f30a29d9dba  vmovaps [rsp+0xA0], xmm11
00007f30a29d9dc3  vmovaps [rsp+0xB0], xmm12
00007f30a29d9dcc  vmovaps [rsp+0xC0], xmm13
00007f30a29d9dd5  vmovaps [rsp+0xD0], xmm14
00007f30a29d9dde  vmovaps [rsp+0xE0], xmm15
00007f30a29d9de7  sub rsp, 0x30
00007f30a29d9deb  movaps [rsp], xmm10
00007f30a29d9df0  movaps [rsp+0x10], xmm12
00007f30a29d9df6  movaps [rsp+0x20], xmm11
00007f30a29d9dfc  lea rdi, [rsp]
00007f30a29d9e00  mov esi, 0x00
00007f30a29d9e05  mov rax, 0x5FE955026530
00007f30a29d9e0f  call rax
00007f30a29d9e11  movaps xmm10, [rsp]
00007f30a29d9e16  add rsp, 0x30
00007f30a29d9e1a  vmovaps xmm0, [rsp]
00007f30a29d9e1f  vmovaps xmm1, [rsp+0x10]
00007f30a29d9e25  vmovaps xmm2, [rsp+0x20]
00007f30a29d9e2b  vmovaps xmm3, [rsp+0x30]
00007f30a29d9e31  vmovaps xmm4, [rsp+0x40]
00007f30a29d9e37  vmovaps xmm5, [rsp+0x50]
00007f30a29d9e3d  vmovaps xmm6, [rsp+0x60]
00007f30a29d9e43  vmovaps xmm7, [rsp+0x70]
00007f30a29d9e49  vmovaps xmm8, [rsp+0x80]
00007f30a29d9e52  vmovaps xmm9, [rsp+0x90]
00007f30a29d9e5b  vmovaps xmm11, [rsp+0xA0]
00007f30a29d9e64  vmovaps xmm12, [rsp+0xB0]
00007f30a29d9e6d  vmovaps xmm13, [rsp+0xC0]
00007f30a29d9e76  vmovaps xmm14, [rsp+0xD0]
00007f30a29d9e7f  vmovaps xmm15, [rsp+0xE0]
00007f30a29d9e88  add rsp, 0xF0
00007f30a29d9e8f  pop r11
00007f30a29d9e91  pop r10
00007f30a29d9e93  pop r9
00007f30a29d9e95  pop r8
00007f30a29d9e97  pop rsi
00007f30a29d9e98  pop rdi
00007f30a29d9e99  pop rdx
00007f30a29d9e9a  pop rcx
00007f30a29d9e9b  pop rax
00007f30a29d9e9c  add rsp, 0x08
00007f30a29d9ea0  jmp 0x00007F30A29D8BE6
00007f30a29d9ea5  sub rsp, 0x08
00007f30a29d9ea9  push rax
00007f30a29d9eaa  push rcx
00007f30a29d9eab  push rdx
00007f30a29d9eac  push rdi
00007f30a29d9ead  push rsi
00007f30a29d9eae  push r8
00007f30a29d9eb0  push r9
00007f30a29d9eb2  push r10
00007f30a29d9eb4  push r11
00007f30a29d9eb6  sub rsp, 0xF0
00007f30a29d9ebd  vmovaps [rsp], xmm0
00007f30a29d9ec2  vmovaps [rsp+0x10], xmm1
00007f30a29d9ec8  vmovaps [rsp+0x20], xmm2
00007f30a29d9ece  vmovaps [rsp+0x30], xmm3
00007f30a29d9ed4  vmovaps [rsp+0x40], xmm4
00007f30a29d9eda  vmovaps [rsp+0x50], xmm5
00007f30a29d9ee0  vmovaps [rsp+0x60], xmm7
00007f30a29d9ee6  vmovaps [rsp+0x70], xmm8
00007f30a29d9eec  vmovaps [rsp+0x80], xmm9
00007f30a29d9ef5  vmovaps [rsp+0x90], xmm10
00007f30a29d9efe  vmovaps [rsp+0xA0], xmm11
00007f30a29d9f07  vmovaps [rsp+0xB0], xmm12
00007f30a29d9f10  vmovaps [rsp+0xC0], xmm13
00007f30a29d9f19  vmovaps [rsp+0xD0], xmm14
00007f30a29d9f22  vmovaps [rsp+0xE0], xmm15
00007f30a29d9f2b  sub rsp, 0x30
00007f30a29d9f2f  movaps [rsp], xmm6
00007f30a29d9f33  movaps [rsp+0x10], xmm12
00007f30a29d9f39  movaps [rsp+0x20], xmm11
00007f30a29d9f3f  lea rdi, [rsp]
00007f30a29d9f43  mov esi, 0x00
00007f30a29d9f48  mov rax, 0x5FE955026530
00007f30a29d9f52  call rax
00007f30a29d9f54  movaps xmm6, [rsp]
00007f30a29d9f58  add rsp, 0x30
00007f30a29d9f5c  vmovaps xmm0, [rsp]
00007f30a29d9f61  vmovaps xmm1, [rsp+0x10]
00007f30a29d9f67  vmovaps xmm2, [rsp+0x20]
00007f30a29d9f6d  vmovaps xmm3, [rsp+0x30]
00007f30a29d9f73  vmovaps xmm4, [rsp+0x40]
00007f30a29d9f79  vmovaps xmm5, [rsp+0x50]
00007f30a29d9f7f  vmovaps xmm7, [rsp+0x60]
00007f30a29d9f85  vmovaps xmm8, [rsp+0x70]
00007f30a29d9f8b  vmovaps xmm9, [rsp+0x80]
00007f30a29d9f94  vmovaps xmm10, [rsp+0x90]
00007f30a29d9f9d  vmovaps xmm11, [rsp+0xA0]
00007f30a29d9fa6  vmovaps xmm12, [rsp+0xB0]
00007f30a29d9faf  vmovaps xmm13, [rsp+0xC0]
00007f30a29d9fb8  vmovaps xmm14, [rsp+0xD0]
00007f30a29d9fc1  vmovaps xmm15, [rsp+0xE0]
00007f30a29d9fca  add rsp, 0xF0
00007f30a29d9fd1  pop r11
00007f30a29d9fd3  pop r10
00007f30a29d9fd5  pop r9
00007f30a29d9fd7  pop r8
00007f30a29d9fd9  pop rsi
00007f30a29d9fda  pop rdi
00007f30a29d9fdb  pop rdx
00007f30a29d9fdc  pop rcx
00007f30a29d9fdd  pop rax
00007f30a29d9fde  add rsp, 0x08
00007f30a29d9fe2  jmp 0x00007F30A29D8C07
00007f30a29d9fe7  sub rsp, 0x08
00007f30a29d9feb  push rax
00007f30a29d9fec  push rcx
00007f30a29d9fed  push rdx
00007f30a29d9fee  push rdi
00007f30a29d9fef  push rsi
00007f30a29d9ff0  push r8
00007f30a29d9ff2  push r9
00007f30a29d9ff4  push r10
00007f30a29d9ff6  push r11
00007f30a29d9ff8  sub rsp, 0xF0
00007f30a29d9fff  vmovaps [rsp], xmm0
00007f30a29da004  vmovaps [rsp+0x10], xmm1
00007f30a29da00a  vmovaps [rsp+0x20], xmm2
00007f30a29da010  vmovaps [rsp+0x30], xmm4
00007f30a29da016  vmovaps [rsp+0x40], xmm5
00007f30a29da01c  vmovaps [rsp+0x50], xmm6
00007f30a29da022  vmovaps [rsp+0x60], xmm7
00007f30a29da028  vmovaps [rsp+0x70], xmm8
00007f30a29da02e  vmovaps [rsp+0x80], xmm9
00007f30a29da037  vmovaps [rsp+0x90], xmm10
00007f30a29da040  vmovaps [rsp+0xA0], xmm11
00007f30a29da049  vmovaps [rsp+0xB0], xmm12
00007f30a29da052  vmovaps [rsp+0xC0], xmm13
00007f30a29da05b  vmovaps [rsp+0xD0], xmm14
00007f30a29da064  vmovaps [rsp+0xE0], xmm15
00007f30a29da06d  sub rsp, 0x30
00007f30a29da071  movaps [rsp], xmm3
00007f30a29da075  movaps [rsp+0x10], xmm5
00007f30a29da07a  movaps [rsp+0x20], xmm4
00007f30a29da07f  lea rdi, [rsp]
00007f30a29da083  mov esi, 0x00
00007f30a29da088  mov rax, 0x5FE955026530
00007f30a29da092  call rax
00007f30a29da094  movaps xmm3, [rsp]
00007f30a29da098  add rsp, 0x30
00007f30a29da09c  vmovaps xmm0, [rsp]
00007f30a29da0a1  vmovaps xmm1, [rsp+0x10]
00007f30a29da0a7  vmovaps xmm2, [rsp+0x20]
00007f30a29da0ad  vmovaps xmm4, [rsp+0x30]
00007f30a29da0b3  vmovaps xmm5, [rsp+0x40]
00007f30a29da0b9  vmovaps xmm6, [rsp+0x50]
00007f30a29da0bf  vmovaps xmm7, [rsp+0x60]
00007f30a29da0c5  vmovaps xmm8, [rsp+0x70]
00007f30a29da0cb  vmovaps xmm9, [rsp+0x80]
00007f30a29da0d4  vmovaps xmm10, [rsp+0x90]
00007f30a29da0dd  vmovaps xmm11, [rsp+0xA0]
00007f30a29da0e6  vmovaps xmm12, [rsp+0xB0]
00007f30a29da0ef  vmovaps xmm13, [rsp+0xC0]
00007f30a29da0f8  vmovaps xmm14, [rsp+0xD0]
00007f30a29da101  vmovaps xmm15, [rsp+0xE0]
00007f30a29da10a  add rsp, 0xF0
00007f30a29da111  pop r11
00007f30a29da113  pop r10
00007f30a29da115  pop r9
00007f30a29da117  pop r8
00007f30a29da119  pop rsi
00007f30a29da11a  pop rdi
00007f30a29da11b  pop rdx
00007f30a29da11c  pop rcx
00007f30a29da11d  pop rax
00007f30a29da11e  add rsp, 0x08
00007f30a29da122  jmp 0x00007F30A29D8C68
00007f30a29da127  sub rsp, 0x08
00007f30a29da12b  push rax
00007f30a29da12c  push rcx
00007f30a29da12d  push rdx
00007f30a29da12e  push rdi
00007f30a29da12f  push rsi
00007f30a29da130  push r8
00007f30a29da132  push r9
00007f30a29da134  push r10
00007f30a29da136  push r11
00007f30a29da138  sub rsp, 0xF0
00007f30a29da13f  vmovaps [rsp], xmm0
00007f30a29da144  vmovaps [rsp+0x10], xmm1
00007f30a29da14a  vmovaps [rsp+0x20], xmm2
00007f30a29da150  vmovaps [rsp+0x30], xmm3
00007f30a29da156  vmovaps [rsp+0x40], xmm4
00007f30a29da15c  vmovaps [rsp+0x50], xmm6
00007f30a29da162  vmovaps [rsp+0x60], xmm7
00007f30a29da168  vmovaps [rsp+0x70], xmm8
00007f30a29da16e  vmovaps [rsp+0x80], xmm9
00007f30a29da177  vmovaps [rsp+0x90], xmm10
00007f30a29da180  vmovaps [rsp+0xA0], xmm11
00007f30a29da189  vmovaps [rsp+0xB0], xmm12
00007f30a29da192  vmovaps [rsp+0xC0], xmm13
00007f30a29da19b  vmovaps [rsp+0xD0], xmm14
00007f30a29da1a4  vmovaps [rsp+0xE0], xmm15
00007f30a29da1ad  sub rsp, 0x30
00007f30a29da1b1  movaps [rsp], xmm5
00007f30a29da1b5  movaps [rsp+0x10], xmm8
00007f30a29da1bb  movaps [rsp+0x20], xmm15
00007f30a29da1c1  lea rdi, [rsp]
00007f30a29da1c5  mov esi, 0x00
00007f30a29da1ca  mov rax, 0x5FE955026530
00007f30a29da1d4  call rax
00007f30a29da1d6  movaps xmm5, [rsp]
00007f30a29da1da  add rsp, 0x30
00007f30a29da1de  vmovaps xmm0, [rsp]
00007f30a29da1e3  vmovaps xmm1, [rsp+0x10]
00007f30a29da1e9  vmovaps xmm2, [rsp+0x20]
00007f30a29da1ef  vmovaps xmm3, [rsp+0x30]
00007f30a29da1f5  vmovaps xmm4, [rsp+0x40]
00007f30a29da1fb  vmovaps xmm6, [rsp+0x50]
00007f30a29da201  vmovaps xmm7, [rsp+0x60]
00007f30a29da207  vmovaps xmm8, [rsp+0x70]
00007f30a29da20d  vmovaps xmm9, [rsp+0x80]
00007f30a29da216  vmovaps xmm10, [rsp+0x90]
00007f30a29da21f  vmovaps xmm11, [rsp+0xA0]
00007f30a29da228  vmovaps xmm12, [rsp+0xB0]
00007f30a29da231  vmovaps xmm13, [rsp+0xC0]
00007f30a29da23a  vmovaps xmm14, [rsp+0xD0]
00007f30a29da243  vmovaps xmm15, [rsp+0xE0]
00007f30a29da24c  add rsp, 0xF0
00007f30a29da253  pop r11
00007f30a29da255  pop r10
00007f30a29da257  pop r9
00007f30a29da259  pop r8
00007f30a29da25b  pop rsi
00007f30a29da25c  pop rdi
00007f30a29da25d  pop rdx
00007f30a29da25e  pop rcx
00007f30a29da25f  pop rax
00007f30a29da260  add rsp, 0x08
00007f30a29da264  jmp 0x00007F30A29D8CA0
00007f30a29da269  sub rsp, 0x08
00007f30a29da26d  push rax
00007f30a29da26e  push rcx
00007f30a29da26f  push rdx
00007f30a29da270  push rdi
00007f30a29da271  push rsi
00007f30a29da272  push r8
00007f30a29da274  push r9
00007f30a29da276  push r10
00007f30a29da278  push r11
00007f30a29da27a  sub rsp, 0xF0
00007f30a29da281  vmovaps [rsp], xmm0
00007f30a29da286  vmovaps [rsp+0x10], xmm1
00007f30a29da28c  vmovaps [rsp+0x20], xmm2
00007f30a29da292  vmovaps [rsp+0x30], xmm3
00007f30a29da298  vmovaps [rsp+0x40], xmm5
00007f30a29da29e  vmovaps [rsp+0x50], xmm6
00007f30a29da2a4  vmovaps [rsp+0x60], xmm7
00007f30a29da2aa  vmovaps [rsp+0x70], xmm8
00007f30a29da2b0  vmovaps [rsp+0x80], xmm9
00007f30a29da2b9  vmovaps [rsp+0x90], xmm10
00007f30a29da2c2  vmovaps [rsp+0xA0], xmm11
00007f30a29da2cb  vmovaps [rsp+0xB0], xmm12
00007f30a29da2d4  vmovaps [rsp+0xC0], xmm13
00007f30a29da2dd  vmovaps [rsp+0xD0], xmm14
00007f30a29da2e6  vmovaps [rsp+0xE0], xmm15
00007f30a29da2ef  sub rsp, 0x30
00007f30a29da2f3  movaps [rsp], xmm4
00007f30a29da2f7  movaps [rsp+0x10], xmm9
00007f30a29da2fd  movaps [rsp+0x20], xmm8
00007f30a29da303  lea rdi, [rsp]
00007f30a29da307  mov esi, 0x00
00007f30a29da30c  mov rax, 0x5FE955026530
00007f30a29da316  call rax
00007f30a29da318  movaps xmm4, [rsp]
00007f30a29da31c  add rsp, 0x30
00007f30a29da320  vmovaps xmm0, [rsp]
00007f30a29da325  vmovaps xmm1, [rsp+0x10]
00007f30a29da32b  vmovaps xmm2, [rsp+0x20]
00007f30a29da331  vmovaps xmm3, [rsp+0x30]
00007f30a29da337  vmovaps xmm5, [rsp+0x40]
00007f30a29da33d  vmovaps xmm6, [rsp+0x50]
00007f30a29da343  vmovaps xmm7, [rsp+0x60]
00007f30a29da349  vmovaps xmm8, [rsp+0x70]
00007f30a29da34f  vmovaps xmm9, [rsp+0x80]
00007f30a29da358  vmovaps xmm10, [rsp+0x90]
00007f30a29da361  vmovaps xmm11, [rsp+0xA0]
00007f30a29da36a  vmovaps xmm12, [rsp+0xB0]
00007f30a29da373  vmovaps xmm13, [rsp+0xC0]
00007f30a29da37c  vmovaps xmm14, [rsp+0xD0]
00007f30a29da385  vmovaps xmm15, [rsp+0xE0]
00007f30a29da38e  add rsp, 0xF0
00007f30a29da395  pop r11
00007f30a29da397  pop r10
00007f30a29da399  pop r9
00007f30a29da39b  pop r8
00007f30a29da39d  pop rsi
00007f30a29da39e  pop rdi
00007f30a29da39f  pop rdx
00007f30a29da3a0  pop rcx
00007f30a29da3a1  pop rax
00007f30a29da3a2  add rsp, 0x08
00007f30a29da3a6  jmp 0x00007F30A29D8CC1
00007f30a29da3ab  sub rsp, 0x08
00007f30a29da3af  push rax
00007f30a29da3b0  push rcx
00007f30a29da3b1  push rdx
00007f30a29da3b2  push rdi
00007f30a29da3b3  push rsi
00007f30a29da3b4  push r8
00007f30a29da3b6  push r9
00007f30a29da3b8  push r10
00007f30a29da3ba  push r11
00007f30a29da3bc  sub rsp, 0xF0
00007f30a29da3c3  vmovaps [rsp], xmm0
00007f30a29da3c8  vmovaps [rsp+0x10], xmm1
00007f30a29da3ce  vmovaps [rsp+0x20], xmm2
00007f30a29da3d4  vmovaps [rsp+0x30], xmm3
00007f30a29da3da  vmovaps [rsp+0x40], xmm4
00007f30a29da3e0  vmovaps [rsp+0x50], xmm5
00007f30a29da3e6  vmovaps [rsp+0x60], xmm6
00007f30a29da3ec  vmovaps [rsp+0x70], xmm7
00007f30a29da3f2  vmovaps [rsp+0x80], xmm8
00007f30a29da3fb  vmovaps [rsp+0x90], xmm10
00007f30a29da404  vmovaps [rsp+0xA0], xmm11
00007f30a29da40d  vmovaps [rsp+0xB0], xmm12
00007f30a29da416  vmovaps [rsp+0xC0], xmm13
00007f30a29da41f  vmovaps [rsp+0xD0], xmm14
00007f30a29da428  vmovaps [rsp+0xE0], xmm15
00007f30a29da431  sub rsp, 0x30
00007f30a29da435  movaps [rsp], xmm9
00007f30a29da43a  movaps [rsp+0x10], xmm10
00007f30a29da440  movaps [rsp+0x20], xmm8
00007f30a29da446  lea rdi, [rsp]
00007f30a29da44a  mov esi, 0x00
00007f30a29da44f  mov rax, 0x5FE955026530
00007f30a29da459  call rax
00007f30a29da45b  movaps xmm9, [rsp]
00007f30a29da460  add rsp, 0x30
00007f30a29da464  vmovaps xmm0, [rsp]
00007f30a29da469  vmovaps xmm1, [rsp+0x10]
00007f30a29da46f  vmovaps xmm2, [rsp+0x20]
00007f30a29da475  vmovaps xmm3, [rsp+0x30]
00007f30a29da47b  vmovaps xmm4, [rsp+0x40]
00007f30a29da481  vmovaps xmm5, [rsp+0x50]
00007f30a29da487  vmovaps xmm6, [rsp+0x60]
00007f30a29da48d  vmovaps xmm7, [rsp+0x70]
00007f30a29da493  vmovaps xmm8, [rsp+0x80]
00007f30a29da49c  vmovaps xmm10, [rsp+0x90]
00007f30a29da4a5  vmovaps xmm11, [rsp+0xA0]
00007f30a29da4ae  vmovaps xmm12, [rsp+0xB0]
00007f30a29da4b7  vmovaps xmm13, [rsp+0xC0]
00007f30a29da4c0  vmovaps xmm14, [rsp+0xD0]
00007f30a29da4c9  vmovaps xmm15, [rsp+0xE0]
00007f30a29da4d2  add rsp, 0xF0
00007f30a29da4d9  pop r11
00007f30a29da4db  pop r10
00007f30a29da4dd  pop r9
00007f30a29da4df  pop r8
00007f30a29da4e1  pop rsi
00007f30a29da4e2  pop rdi
00007f30a29da4e3  pop rdx
00007f30a29da4e4  pop rcx
00007f30a29da4e5  pop rax
00007f30a29da4e6  add rsp, 0x08
00007f30a29da4ea  jmp 0x00007F30A29D8CDB
00007f30a29da4ef  call 0x00007F30A28D64F0
00007f30a29da4f4  jmp 0x00007F30A29D8DF5
00007f30a29da4f9  call 0x00007F30A28D64F0
00007f30a29da4fe  jmp 0x00007F30A29D8E0B
00007f30a29da503  sub rsp, 0x08
00007f30a29da507  push rax
00007f30a29da508  push rcx
00007f30a29da509  push rdx
00007f30a29da50a  push rdi
00007f30a29da50b  push rsi
00007f30a29da50c  push r8
00007f30a29da50e  push r9
00007f30a29da510  push r10
00007f30a29da512  push r11
00007f30a29da514  sub rsp, 0xF0
00007f30a29da51b  vmovaps [rsp], xmm0
00007f30a29da520  vmovaps [rsp+0x10], xmm2
00007f30a29da526  vmovaps [rsp+0x20], xmm3
00007f30a29da52c  vmovaps [rsp+0x30], xmm4
00007f30a29da532  vmovaps [rsp+0x40], xmm5
00007f30a29da538  vmovaps [rsp+0x50], xmm6
00007f30a29da53e  vmovaps [rsp+0x60], xmm7
00007f30a29da544  vmovaps [rsp+0x70], xmm8
00007f30a29da54a  vmovaps [rsp+0x80], xmm9
00007f30a29da553  vmovaps [rsp+0x90], xmm10
00007f30a29da55c  vmovaps [rsp+0xA0], xmm11
00007f30a29da565  vmovaps [rsp+0xB0], xmm12
00007f30a29da56e  vmovaps [rsp+0xC0], xmm13
00007f30a29da577  vmovaps [rsp+0xD0], xmm14
00007f30a29da580  vmovaps [rsp+0xE0], xmm15
00007f30a29da589  sub rsp, 0x30
00007f30a29da58d  movaps [rsp], xmm1
00007f30a29da591  movaps [rsp+0x10], xmm6
00007f30a29da596  movaps [rsp+0x20], xmm15
00007f30a29da59c  lea rdi, [rsp]
00007f30a29da5a0  mov esi, 0x00
00007f30a29da5a5  mov rax, 0x5FE955026530
00007f30a29da5af  call rax
00007f30a29da5b1  movaps xmm1, [rsp]
00007f30a29da5b5  add rsp, 0x30
00007f30a29da5b9  vmovaps xmm0, [rsp]
00007f30a29da5be  vmovaps xmm2, [rsp+0x10]
00007f30a29da5c4  vmovaps xmm3, [rsp+0x20]
00007f30a29da5ca  vmovaps xmm4, [rsp+0x30]
00007f30a29da5d0  vmovaps xmm5, [rsp+0x40]
00007f30a29da5d6  vmovaps xmm6, [rsp+0x50]
00007f30a29da5dc  vmovaps xmm7, [rsp+0x60]
00007f30a29da5e2  vmovaps xmm8, [rsp+0x70]
00007f30a29da5e8  vmovaps xmm9, [rsp+0x80]
00007f30a29da5f1  vmovaps xmm10, [rsp+0x90]
00007f30a29da5fa  vmovaps xmm11, [rsp+0xA0]
00007f30a29da603  vmovaps xmm12, [rsp+0xB0]
00007f30a29da60c  vmovaps xmm13, [rsp+0xC0]
00007f30a29da615  vmovaps xmm14, [rsp+0xD0]
00007f30a29da61e  vmovaps xmm15, [rsp+0xE0]
00007f30a29da627  add rsp, 0xF0
00007f30a29da62e  pop r11
00007f30a29da630  pop r10
00007f30a29da632  pop r9
00007f30a29da634  pop r8
00007f30a29da636  pop rsi
00007f30a29da637  pop rdi
00007f30a29da638  pop rdx
00007f30a29da639  pop rcx
00007f30a29da63a  pop rax
00007f30a29da63b  add rsp, 0x08
00007f30a29da63f  jmp 0x00007F30A29D8E48
00007f30a29da644  call 0x00007F30A28E5820
00007f30a29da649  jmp 0x00007F30A29D8E55
00007f30a29da64e  sub rsp, 0x08
00007f30a29da652  push rax
00007f30a29da653  push rcx
00007f30a29da654  push rdx
00007f30a29da655  push rdi
00007f30a29da656  push rsi
00007f30a29da657  push r8
00007f30a29da659  push r9
00007f30a29da65b  push r10
00007f30a29da65d  push r11
00007f30a29da65f  sub rsp, 0xF0
00007f30a29da666  vmovaps [rsp], xmm0
00007f30a29da66b  vmovaps [rsp+0x10], xmm1
00007f30a29da671  vmovaps [rsp+0x20], xmm2
00007f30a29da677  vmovaps [rsp+0x30], xmm3
00007f30a29da67d  vmovaps [rsp+0x40], xmm4
00007f30a29da683  vmovaps [rsp+0x50], xmm5
00007f30a29da689  vmovaps [rsp+0x60], xmm6
00007f30a29da68f  vmovaps [rsp+0x70], xmm7
00007f30a29da695  vmovaps [rsp+0x80], xmm8
00007f30a29da69e  vmovaps [rsp+0x90], xmm9
00007f30a29da6a7  vmovaps [rsp+0xA0], xmm10
00007f30a29da6b0  vmovaps [rsp+0xB0], xmm11
00007f30a29da6b9  vmovaps [rsp+0xC0], xmm12
00007f30a29da6c2  vmovaps [rsp+0xD0], xmm13
00007f30a29da6cb  vmovaps [rsp+0xE0], xmm15
00007f30a29da6d4  sub rsp, 0x30
00007f30a29da6d8  movaps [rsp], xmm14
00007f30a29da6dd  movaps [rsp+0x10], xmm4
00007f30a29da6e2  movaps [rsp+0x20], xmm3
00007f30a29da6e7  lea rdi, [rsp]
00007f30a29da6eb  mov esi, 0x00
00007f30a29da6f0  mov rax, 0x5FE955026530
00007f30a29da6fa  call rax
00007f30a29da6fc  movaps xmm14, [rsp]
00007f30a29da701  add rsp, 0x30
00007f30a29da705  vmovaps xmm0, [rsp]
00007f30a29da70a  vmovaps xmm1, [rsp+0x10]
00007f30a29da710  vmovaps xmm2, [rsp+0x20]
00007f30a29da716  vmovaps xmm3, [rsp+0x30]
00007f30a29da71c  vmovaps xmm4, [rsp+0x40]
00007f30a29da722  vmovaps xmm5, [rsp+0x50]
00007f30a29da728  vmovaps xmm6, [rsp+0x60]
00007f30a29da72e  vmovaps xmm7, [rsp+0x70]
00007f30a29da734  vmovaps xmm8, [rsp+0x80]
00007f30a29da73d  vmovaps xmm9, [rsp+0x90]
00007f30a29da746  vmovaps xmm10, [rsp+0xA0]
00007f30a29da74f  vmovaps xmm11, [rsp+0xB0]
00007f30a29da758  vmovaps xmm12, [rsp+0xC0]
00007f30a29da761  vmovaps xmm13, [rsp+0xD0]
00007f30a29da76a  vmovaps xmm15, [rsp+0xE0]
00007f30a29da773  add rsp, 0xF0
00007f30a29da77a  pop r11
00007f30a29da77c  pop r10
00007f30a29da77e  pop r9
00007f30a29da780  pop r8
00007f30a29da782  pop rsi
00007f30a29da783  pop rdi
00007f30a29da784  pop rdx
00007f30a29da785  pop rcx
00007f30a29da786  pop rax
00007f30a29da787  add rsp, 0x08
00007f30a29da78b  jmp 0x00007F30A29D8E6F
00007f30a29da790  sub rsp, 0x08
00007f30a29da794  push rax
00007f30a29da795  push rcx
00007f30a29da796  push rdx
00007f30a29da797  push rdi
00007f30a29da798  push rsi
00007f30a29da799  push r8
00007f30a29da79b  push r9
00007f30a29da79d  push r10
00007f30a29da79f  push r11
00007f30a29da7a1  sub rsp, 0xF0
00007f30a29da7a8  vmovaps [rsp], xmm0
00007f30a29da7ad  vmovaps [rsp+0x10], xmm1
00007f30a29da7b3  vmovaps [rsp+0x20], xmm2
00007f30a29da7b9  vmovaps [rsp+0x30], xmm3
00007f30a29da7bf  vmovaps [rsp+0x40], xmm4
00007f30a29da7c5  vmovaps [rsp+0x50], xmm5
00007f30a29da7cb  vmovaps [rsp+0x60], xmm7
00007f30a29da7d1  vmovaps [rsp+0x70], xmm8
00007f30a29da7d7  vmovaps [rsp+0x80], xmm9
00007f30a29da7e0  vmovaps [rsp+0x90], xmm10
00007f30a29da7e9  vmovaps [rsp+0xA0], xmm11
00007f30a29da7f2  vmovaps [rsp+0xB0], xmm12
00007f30a29da7fb  vmovaps [rsp+0xC0], xmm13
00007f30a29da804  vmovaps [rsp+0xD0], xmm14
00007f30a29da80d  vmovaps [rsp+0xE0], xmm15
00007f30a29da816  sub rsp, 0x30
00007f30a29da81a  movaps [rsp], xmm6
00007f30a29da81e  movaps [rsp+0x10], xmm9
00007f30a29da824  movaps [rsp+0x20], xmm7
00007f30a29da829  lea rdi, [rsp]
00007f30a29da82d  mov esi, 0x00
00007f30a29da832  mov rax, 0x5FE955026530
00007f30a29da83c  call rax
00007f30a29da83e  movaps xmm6, [rsp]
00007f30a29da842  add rsp, 0x30
00007f30a29da846  vmovaps xmm0, [rsp]
00007f30a29da84b  vmovaps xmm1, [rsp+0x10]
00007f30a29da851  vmovaps xmm2, [rsp+0x20]
00007f30a29da857  vmovaps xmm3, [rsp+0x30]
00007f30a29da85d  vmovaps xmm4, [rsp+0x40]
00007f30a29da863  vmovaps xmm5, [rsp+0x50]
00007f30a29da869  vmovaps xmm7, [rsp+0x60]
00007f30a29da86f  vmovaps xmm8, [rsp+0x70]
00007f30a29da875  vmovaps xmm9, [rsp+0x80]
00007f30a29da87e  vmovaps xmm10, [rsp+0x90]
00007f30a29da887  vmovaps xmm11, [rsp+0xA0]
00007f30a29da890  vmovaps xmm12, [rsp+0xB0]
00007f30a29da899  vmovaps xmm13, [rsp+0xC0]
00007f30a29da8a2  vmovaps xmm14, [rsp+0xD0]
00007f30a29da8ab  vmovaps xmm15, [rsp+0xE0]
00007f30a29da8b4  add rsp, 0xF0
00007f30a29da8bb  pop r11
00007f30a29da8bd  pop r10
00007f30a29da8bf  pop r9
00007f30a29da8c1  pop r8
00007f30a29da8c3  pop rsi
00007f30a29da8c4  pop rdi
00007f30a29da8c5  pop rdx
00007f30a29da8c6  pop rcx
00007f30a29da8c7  pop rax
00007f30a29da8c8  add rsp, 0x08
00007f30a29da8cc  jmp 0x00007F30A29D8E87
00007f30a29da8d1  sub rsp, 0x08
00007f30a29da8d5  push rax
00007f30a29da8d6  push rcx
00007f30a29da8d7  push rdx
00007f30a29da8d8  push rdi
00007f30a29da8d9  push rsi
00007f30a29da8da  push r8
00007f30a29da8dc  push r9
00007f30a29da8de  push r10
00007f30a29da8e0  push r11
00007f30a29da8e2  sub rsp, 0xF0
00007f30a29da8e9  vmovaps [rsp], xmm0
00007f30a29da8ee  vmovaps [rsp+0x10], xmm1
00007f30a29da8f4  vmovaps [rsp+0x20], xmm2
00007f30a29da8fa  vmovaps [rsp+0x30], xmm3
00007f30a29da900  vmovaps [rsp+0x40], xmm4
00007f30a29da906  vmovaps [rsp+0x50], xmm5
00007f30a29da90c  vmovaps [rsp+0x60], xmm6
00007f30a29da912  vmovaps [rsp+0x70], xmm8
00007f30a29da918  vmovaps [rsp+0x80], xmm9
00007f30a29da921  vmovaps [rsp+0x90], xmm10
00007f30a29da92a  vmovaps [rsp+0xA0], xmm11
00007f30a29da933  vmovaps [rsp+0xB0], xmm12
00007f30a29da93c  vmovaps [rsp+0xC0], xmm13
00007f30a29da945  vmovaps [rsp+0xD0], xmm14
00007f30a29da94e  vmovaps [rsp+0xE0], xmm15
00007f30a29da957  sub rsp, 0x30
00007f30a29da95b  movaps [rsp], xmm7
00007f30a29da95f  movaps [rsp+0x10], xmm4
00007f30a29da964  movaps [rsp+0x20], xmm9
00007f30a29da96a  lea rdi, [rsp]
00007f30a29da96e  mov esi, 0x00
00007f30a29da973  mov rax, 0x5FE955026530
00007f30a29da97d  call rax
00007f30a29da97f  movaps xmm7, [rsp]
00007f30a29da983  add rsp, 0x30
00007f30a29da987  vmovaps xmm0, [rsp]
00007f30a29da98c  vmovaps xmm1, [rsp+0x10]
00007f30a29da992  vmovaps xmm2, [rsp+0x20]
00007f30a29da998  vmovaps xmm3, [rsp+0x30]
00007f30a29da99e  vmovaps xmm4, [rsp+0x40]
00007f30a29da9a4  vmovaps xmm5, [rsp+0x50]
00007f30a29da9aa  vmovaps xmm6, [rsp+0x60]
00007f30a29da9b0  vmovaps xmm8, [rsp+0x70]
00007f30a29da9b6  vmovaps xmm9, [rsp+0x80]
00007f30a29da9bf  vmovaps xmm10, [rsp+0x90]
00007f30a29da9c8  vmovaps xmm11, [rsp+0xA0]
00007f30a29da9d1  vmovaps xmm12, [rsp+0xB0]
00007f30a29da9da  vmovaps xmm13, [rsp+0xC0]
00007f30a29da9e3  vmovaps xmm14, [rsp+0xD0]
00007f30a29da9ec  vmovaps xmm15, [rsp+0xE0]
00007f30a29da9f5  add rsp, 0xF0
00007f30a29da9fc  pop r11
00007f30a29da9fe  pop r10
00007f30a29daa00  pop r9
00007f30a29daa02  pop r8
00007f30a29daa04  pop rsi
00007f30a29daa05  pop rdi
00007f30a29daa06  pop rdx
00007f30a29daa07  pop rcx
00007f30a29daa08  pop rax
00007f30a29daa09  add rsp, 0x08
00007f30a29daa0d  jmp 0x00007F30A29D8EB4
00007f30a29daa12  sub rsp, 0x08
00007f30a29daa16  push rax
00007f30a29daa17  push rcx
00007f30a29daa18  push rdx
00007f30a29daa19  push rdi
00007f30a29daa1a  push rsi
00007f30a29daa1b  push r8
00007f30a29daa1d  push r9
00007f30a29daa1f  push r10
00007f30a29daa21  push r11
00007f30a29daa23  sub rsp, 0xF0
00007f30a29daa2a  vmovaps [rsp], xmm0
00007f30a29daa2f  vmovaps [rsp+0x10], xmm1
00007f30a29daa35  vmovaps [rsp+0x20], xmm2
00007f30a29daa3b  vmovaps [rsp+0x30], xmm3
00007f30a29daa41  vmovaps [rsp+0x40], xmm5
00007f30a29daa47  vmovaps [rsp+0x50], xmm6
00007f30a29daa4d  vmovaps [rsp+0x60], xmm7
00007f30a29daa53  vmovaps [rsp+0x70], xmm8
00007f30a29daa59  vmovaps [rsp+0x80], xmm9
00007f30a29daa62  vmovaps [rsp+0x90], xmm10
00007f30a29daa6b  vmovaps [rsp+0xA0], xmm11
00007f30a29daa74  vmovaps [rsp+0xB0], xmm12
00007f30a29daa7d  vmovaps [rsp+0xC0], xmm13
00007f30a29daa86  vmovaps [rsp+0xD0], xmm14
00007f30a29daa8f  vmovaps [rsp+0xE0], xmm15
00007f30a29daa98  sub rsp, 0x30
00007f30a29daa9c  movaps [rsp], xmm4
00007f30a29daaa0  movaps [rsp+0x10], xmm15
00007f30a29daaa6  movaps [rsp+0x20], xmm9
00007f30a29daaac  lea rdi, [rsp]
00007f30a29daab0  mov esi, 0x00
00007f30a29daab5  mov rax, 0x5FE955026530
00007f30a29daabf  call rax
00007f30a29daac1  movaps xmm4, [rsp]
00007f30a29daac5  add rsp, 0x30
00007f30a29daac9  vmovaps xmm0, [rsp]
00007f30a29daace  vmovaps xmm1, [rsp+0x10]
00007f30a29daad4  vmovaps xmm2, [rsp+0x20]
00007f30a29daada  vmovaps xmm3, [rsp+0x30]
00007f30a29daae0  vmovaps xmm5, [rsp+0x40]
00007f30a29daae6  vmovaps xmm6, [rsp+0x50]
00007f30a29daaec  vmovaps xmm7, [rsp+0x60]
00007f30a29daaf2  vmovaps xmm8, [rsp+0x70]
00007f30a29daaf8  vmovaps xmm9, [rsp+0x80]
00007f30a29dab01  vmovaps xmm10, [rsp+0x90]
00007f30a29dab0a  vmovaps xmm11, [rsp+0xA0]
00007f30a29dab13  vmovaps xmm12, [rsp+0xB0]
00007f30a29dab1c  vmovaps xmm13, [rsp+0xC0]
00007f30a29dab25  vmovaps xmm14, [rsp+0xD0]
00007f30a29dab2e  vmovaps xmm15, [rsp+0xE0]
00007f30a29dab37  add rsp, 0xF0
00007f30a29dab3e  pop r11
00007f30a29dab40  pop r10
00007f30a29dab42  pop r9
00007f30a29dab44  pop r8
00007f30a29dab46  pop rsi
00007f30a29dab47  pop rdi
00007f30a29dab48  pop rdx
00007f30a29dab49  pop rcx
00007f30a29dab4a  pop rax
00007f30a29dab4b  add rsp, 0x08
00007f30a29dab4f  jmp 0x00007F30A29D8ED9
00007f30a29dab54  call 0x00007F30A28E5820
00007f30a29dab59  jmp 0x00007F30A29D8EE6
00007f30a29dab5e  sub rsp, 0x08
00007f30a29dab62  push rax
00007f30a29dab63  push rcx
00007f30a29dab64  push rdx
00007f30a29dab65  push rdi
00007f30a29dab66  push rsi
00007f30a29dab67  push r8
00007f30a29dab69  push r9
00007f30a29dab6b  push r10
00007f30a29dab6d  push r11
00007f30a29dab6f  sub rsp, 0xF0
00007f30a29dab76  vmovaps [rsp], xmm0
00007f30a29dab7b  vmovaps [rsp+0x10], xmm1
00007f30a29dab81  vmovaps [rsp+0x20], xmm2
00007f30a29dab87  vmovaps [rsp+0x30], xmm4
00007f30a29dab8d  vmovaps [rsp+0x40], xmm5
00007f30a29dab93  vmovaps [rsp+0x50], xmm6
00007f30a29dab99  vmovaps [rsp+0x60], xmm7
00007f30a29dab9f  vmovaps [rsp+0x70], xmm8
00007f30a29daba5  vmovaps [rsp+0x80], xmm9
00007f30a29dabae  vmovaps [rsp+0x90], xmm10
00007f30a29dabb7  vmovaps [rsp+0xA0], xmm11
00007f30a29dabc0  vmovaps [rsp+0xB0], xmm12
00007f30a29dabc9  vmovaps [rsp+0xC0], xmm13
00007f30a29dabd2  vmovaps [rsp+0xD0], xmm14
00007f30a29dabdb  vmovaps [rsp+0xE0], xmm15
00007f30a29dabe4  sub rsp, 0x30
00007f30a29dabe8  movaps [rsp], xmm3
00007f30a29dabec  movaps [rsp+0x10], xmm1
00007f30a29dabf1  movaps [rsp+0x20], xmm9
00007f30a29dabf7  lea rdi, [rsp]
00007f30a29dabfb  mov esi, 0x00
00007f30a29dac00  mov rax, 0x5FE955026530
00007f30a29dac0a  call rax
00007f30a29dac0c  movaps xmm3, [rsp]
00007f30a29dac10  add rsp, 0x30
00007f30a29dac14  vmovaps xmm0, [rsp]
00007f30a29dac19  vmovaps xmm1, [rsp+0x10]
00007f30a29dac1f  vmovaps xmm2, [rsp+0x20]
00007f30a29dac25  vmovaps xmm4, [rsp+0x30]
00007f30a29dac2b  vmovaps xmm5, [rsp+0x40]
00007f30a29dac31  vmovaps xmm6, [rsp+0x50]
00007f30a29dac37  vmovaps xmm7, [rsp+0x60]
00007f30a29dac3d  vmovaps xmm8, [rsp+0x70]
00007f30a29dac43  vmovaps xmm9, [rsp+0x80]
00007f30a29dac4c  vmovaps xmm10, [rsp+0x90]
00007f30a29dac55  vmovaps xmm11, [rsp+0xA0]
00007f30a29dac5e  vmovaps xmm12, [rsp+0xB0]
00007f30a29dac67  vmovaps xmm13, [rsp+0xC0]
00007f30a29dac70  vmovaps xmm14, [rsp+0xD0]
00007f30a29dac79  vmovaps xmm15, [rsp+0xE0]
00007f30a29dac82  add rsp, 0xF0
00007f30a29dac89  pop r11
00007f30a29dac8b  pop r10
00007f30a29dac8d  pop r9
00007f30a29dac8f  pop r8
00007f30a29dac91  pop rsi
00007f30a29dac92  pop rdi
00007f30a29dac93  pop rdx
00007f30a29dac94  pop rcx
00007f30a29dac95  pop rax
00007f30a29dac96  add rsp, 0x08
00007f30a29dac9a  jmp 0x00007F30A29D8F23
00007f30a29dac9f  sub rsp, 0x08
00007f30a29daca3  push rax
00007f30a29daca4  push rcx
00007f30a29daca5  push rdx
00007f30a29daca6  push rdi
00007f30a29daca7  push rsi
00007f30a29daca8  push r8
00007f30a29dacaa  push r9
00007f30a29dacac  push r10
00007f30a29dacae  push r11
00007f30a29dacb0  sub rsp, 0xF0
00007f30a29dacb7  vmovaps [rsp], xmm0
00007f30a29dacbc  vmovaps [rsp+0x10], xmm2
00007f30a29dacc2  vmovaps [rsp+0x20], xmm3
00007f30a29dacc8  vmovaps [rsp+0x30], xmm4
00007f30a29dacce  vmovaps [rsp+0x40], xmm5
00007f30a29dacd4  vmovaps [rsp+0x50], xmm6
00007f30a29dacda  vmovaps [rsp+0x60], xmm7
00007f30a29dace0  vmovaps [rsp+0x70], xmm8
00007f30a29dace6  vmovaps [rsp+0x80], xmm9
00007f30a29dacef  vmovaps [rsp+0x90], xmm10
00007f30a29dacf8  vmovaps [rsp+0xA0], xmm11
00007f30a29dad01  vmovaps [rsp+0xB0], xmm12
00007f30a29dad0a  vmovaps [rsp+0xC0], xmm13
00007f30a29dad13  vmovaps [rsp+0xD0], xmm14
00007f30a29dad1c  vmovaps [rsp+0xE0], xmm15
00007f30a29dad25  sub rsp, 0x30
00007f30a29dad29  movaps [rsp], xmm1
00007f30a29dad2d  movaps [rsp+0x10], xmm15
00007f30a29dad33  movaps [rsp+0x20], xmm9
00007f30a29dad39  lea rdi, [rsp]
00007f30a29dad3d  mov esi, 0x00
00007f30a29dad42  mov rax, 0x5FE955026530
00007f30a29dad4c  call rax
00007f30a29dad4e  movaps xmm1, [rsp]
00007f30a29dad52  add rsp, 0x30
00007f30a29dad56  vmovaps xmm0, [rsp]
00007f30a29dad5b  vmovaps xmm2, [rsp+0x10]
00007f30a29dad61  vmovaps xmm3, [rsp+0x20]
00007f30a29dad67  vmovaps xmm4, [rsp+0x30]
00007f30a29dad6d  vmovaps xmm5, [rsp+0x40]
00007f30a29dad73  vmovaps xmm6, [rsp+0x50]
00007f30a29dad79  vmovaps xmm7, [rsp+0x60]
00007f30a29dad7f  vmovaps xmm8, [rsp+0x70]
00007f30a29dad85  vmovaps xmm9, [rsp+0x80]
00007f30a29dad8e  vmovaps xmm10, [rsp+0x90]
00007f30a29dad97  vmovaps xmm11, [rsp+0xA0]
00007f30a29dada0  vmovaps xmm12, [rsp+0xB0]
00007f30a29dada9  vmovaps xmm13, [rsp+0xC0]
00007f30a29dadb2  vmovaps xmm14, [rsp+0xD0]
00007f30a29dadbb  vmovaps xmm15, [rsp+0xE0]
00007f30a29dadc4  add rsp, 0xF0
00007f30a29dadcb  pop r11
00007f30a29dadcd  pop r10
00007f30a29dadcf  pop r9
00007f30a29dadd1  pop r8
00007f30a29dadd3  pop rsi
00007f30a29dadd4  pop rdi
00007f30a29dadd5  pop rdx
00007f30a29dadd6  pop rcx
00007f30a29dadd7  pop rax
00007f30a29dadd8  add rsp, 0x08
00007f30a29daddc  jmp 0x00007F30A29D8FAB
00007f30a29dade1  call 0x00007F30A28E5820
00007f30a29dade6  jmp 0x00007F30A29D8FB8
00007f30a29dadeb  sub rsp, 0x08
00007f30a29dadef  push rax
00007f30a29dadf0  push rcx
00007f30a29dadf1  push rdx
00007f30a29dadf2  push rdi
00007f30a29dadf3  push rsi
00007f30a29dadf4  push r8
00007f30a29dadf6  push r9
00007f30a29dadf8  push r10
00007f30a29dadfa  push r11
00007f30a29dadfc  sub rsp, 0xF0
00007f30a29dae03  vmovaps [rsp], xmm0
00007f30a29dae08  vmovaps [rsp+0x10], xmm2
00007f30a29dae0e  vmovaps [rsp+0x20], xmm3
00007f30a29dae14  vmovaps [rsp+0x30], xmm4
00007f30a29dae1a  vmovaps [rsp+0x40], xmm5
00007f30a29dae20  vmovaps [rsp+0x50], xmm6
00007f30a29dae26  vmovaps [rsp+0x60], xmm7
00007f30a29dae2c  vmovaps [rsp+0x70], xmm8
00007f30a29dae32  vmovaps [rsp+0x80], xmm9
00007f30a29dae3b  vmovaps [rsp+0x90], xmm10
00007f30a29dae44  vmovaps [rsp+0xA0], xmm11
00007f30a29dae4d  vmovaps [rsp+0xB0], xmm12
00007f30a29dae56  vmovaps [rsp+0xC0], xmm13
00007f30a29dae5f  vmovaps [rsp+0xD0], xmm14
00007f30a29dae68  vmovaps [rsp+0xE0], xmm15
00007f30a29dae71  sub rsp, 0x30
00007f30a29dae75  movaps [rsp], xmm1
00007f30a29dae79  movaps [rsp+0x10], xmm5
00007f30a29dae7e  movaps [rsp+0x20], xmm7
00007f30a29dae83  lea rdi, [rsp]
00007f30a29dae87  mov esi, 0x00
00007f30a29dae8c  mov rax, 0x5FE955026530
00007f30a29dae96  call rax
00007f30a29dae98  movaps xmm1, [rsp]
00007f30a29dae9c  add rsp, 0x30
00007f30a29daea0  vmovaps xmm0, [rsp]
00007f30a29daea5  vmovaps xmm2, [rsp+0x10]
00007f30a29daeab  vmovaps xmm3, [rsp+0x20]
00007f30a29daeb1  vmovaps xmm4, [rsp+0x30]
00007f30a29daeb7  vmovaps xmm5, [rsp+0x40]
00007f30a29daebd  vmovaps xmm6, [rsp+0x50]
00007f30a29daec3  vmovaps xmm7, [rsp+0x60]
00007f30a29daec9  vmovaps xmm8, [rsp+0x70]
00007f30a29daecf  vmovaps xmm9, [rsp+0x80]
00007f30a29daed8  vmovaps xmm10, [rsp+0x90]
00007f30a29daee1  vmovaps xmm11, [rsp+0xA0]
00007f30a29daeea  vmovaps xmm12, [rsp+0xB0]
00007f30a29daef3  vmovaps xmm13, [rsp+0xC0]
00007f30a29daefc  vmovaps xmm14, [rsp+0xD0]
00007f30a29daf05  vmovaps xmm15, [rsp+0xE0]
00007f30a29daf0e  add rsp, 0xF0
00007f30a29daf15  pop r11
00007f30a29daf17  pop r10
00007f30a29daf19  pop r9
00007f30a29daf1b  pop r8
00007f30a29daf1d  pop rsi
00007f30a29daf1e  pop rdi
00007f30a29daf1f  pop rdx
00007f30a29daf20  pop rcx
00007f30a29daf21  pop rax
00007f30a29daf22  add rsp, 0x08
00007f30a29daf26  jmp 0x00007F30A29D905D
00007f30a29daf2b  sub rsp, 0x08
00007f30a29daf2f  push rax
00007f30a29daf30  push rcx
00007f30a29daf31  push rdx
00007f30a29daf32  push rdi
00007f30a29daf33  push rsi
00007f30a29daf34  push r8
00007f30a29daf36  push r9
00007f30a29daf38  push r10
00007f30a29daf3a  push r11
00007f30a29daf3c  sub rsp, 0xF0
00007f30a29daf43  vmovaps [rsp], xmm0
00007f30a29daf48  vmovaps [rsp+0x10], xmm1
00007f30a29daf4e  vmovaps [rsp+0x20], xmm2
00007f30a29daf54  vmovaps [rsp+0x30], xmm3
00007f30a29daf5a  vmovaps [rsp+0x40], xmm4
00007f30a29daf60  vmovaps [rsp+0x50], xmm5
00007f30a29daf66  vmovaps [rsp+0x60], xmm6
00007f30a29daf6c  vmovaps [rsp+0x70], xmm8
00007f30a29daf72  vmovaps [rsp+0x80], xmm9
00007f30a29daf7b  vmovaps [rsp+0x90], xmm10
00007f30a29daf84  vmovaps [rsp+0xA0], xmm11
00007f30a29daf8d  vmovaps [rsp+0xB0], xmm12
00007f30a29daf96  vmovaps [rsp+0xC0], xmm13
00007f30a29daf9f  vmovaps [rsp+0xD0], xmm14
00007f30a29dafa8  vmovaps [rsp+0xE0], xmm15
00007f30a29dafb1  sub rsp, 0x30
00007f30a29dafb5  movaps [rsp], xmm7
00007f30a29dafb9  movaps [rsp+0x10], xmm5
00007f30a29dafbe  movaps [rsp+0x20], xmm15
00007f30a29dafc4  lea rdi, [rsp]
00007f30a29dafc8  mov esi, 0x00
00007f30a29dafcd  mov rax, 0x5FE955026530
00007f30a29dafd7  call rax
00007f30a29dafd9  movaps xmm7, [rsp]
00007f30a29dafdd  add rsp, 0x30
00007f30a29dafe1  vmovaps xmm0, [rsp]
00007f30a29dafe6  vmovaps xmm1, [rsp+0x10]
00007f30a29dafec  vmovaps xmm2, [rsp+0x20]
00007f30a29daff2  vmovaps xmm3, [rsp+0x30]
00007f30a29daff8  vmovaps xmm4, [rsp+0x40]
00007f30a29daffe  vmovaps xmm5, [rsp+0x50]
00007f30a29db004  vmovaps xmm6, [rsp+0x60]
00007f30a29db00a  vmovaps xmm8, [rsp+0x70]
00007f30a29db010  vmovaps xmm9, [rsp+0x80]
00007f30a29db019  vmovaps xmm10, [rsp+0x90]
00007f30a29db022  vmovaps xmm11, [rsp+0xA0]
00007f30a29db02b  vmovaps xmm12, [rsp+0xB0]
00007f30a29db034  vmovaps xmm13, [rsp+0xC0]
00007f30a29db03d  vmovaps xmm14, [rsp+0xD0]
00007f30a29db046  vmovaps xmm15, [rsp+0xE0]
00007f30a29db04f  add rsp, 0xF0
00007f30a29db056  pop r11
00007f30a29db058  pop r10
00007f30a29db05a  pop r9
00007f30a29db05c  pop r8
00007f30a29db05e  pop rsi
00007f30a29db05f  pop rdi
00007f30a29db060  pop rdx
00007f30a29db061  pop rcx
00007f30a29db062  pop rax
00007f30a29db063  add rsp, 0x08
00007f30a29db067  jmp 0x00007F30A29D9093
00007f30a29db06c  call 0x00007F30A28D64F0
00007f30a29db071  jmp 0x00007F30A29D90A0
00007f30a29db076  sub rsp, 0x08
00007f30a29db07a  push rax
00007f30a29db07b  push rcx
00007f30a29db07c  push rdx
00007f30a29db07d  push rdi
00007f30a29db07e  push rsi
00007f30a29db07f  push r8
00007f30a29db081  push r9
00007f30a29db083  push r10
00007f30a29db085  push r11
00007f30a29db087  sub rsp, 0xF0
00007f30a29db08e  vmovaps [rsp], xmm0
00007f30a29db093  vmovaps [rsp+0x10], xmm1
00007f30a29db099  vmovaps [rsp+0x20], xmm2
00007f30a29db09f  vmovaps [rsp+0x30], xmm3
00007f30a29db0a5  vmovaps [rsp+0x40], xmm4
00007f30a29db0ab  vmovaps [rsp+0x50], xmm5
00007f30a29db0b1  vmovaps [rsp+0x60], xmm6
00007f30a29db0b7  vmovaps [rsp+0x70], xmm7
00007f30a29db0bd  vmovaps [rsp+0x80], xmm8
00007f30a29db0c6  vmovaps [rsp+0x90], xmm9
00007f30a29db0cf  vmovaps [rsp+0xA0], xmm10
00007f30a29db0d8  vmovaps [rsp+0xB0], xmm11
00007f30a29db0e1  vmovaps [rsp+0xC0], xmm12
00007f30a29db0ea  vmovaps [rsp+0xD0], xmm13
00007f30a29db0f3  vmovaps [rsp+0xE0], xmm14
00007f30a29db0fc  sub rsp, 0x30
00007f30a29db100  movaps [rsp], xmm15
00007f30a29db105  movaps [rsp+0x10], xmm5
00007f30a29db10a  movaps [rsp+0x20], xmm3
00007f30a29db10f  lea rdi, [rsp]
00007f30a29db113  mov esi, 0x00
00007f30a29db118  mov rax, 0x5FE955026530
00007f30a29db122  call rax
00007f30a29db124  movaps xmm15, [rsp]
00007f30a29db129  add rsp, 0x30
00007f30a29db12d  vmovaps xmm0, [rsp]
00007f30a29db132  vmovaps xmm1, [rsp+0x10]
00007f30a29db138  vmovaps xmm2, [rsp+0x20]
00007f30a29db13e  vmovaps xmm3, [rsp+0x30]
00007f30a29db144  vmovaps xmm4, [rsp+0x40]
00007f30a29db14a  vmovaps xmm5, [rsp+0x50]
00007f30a29db150  vmovaps xmm6, [rsp+0x60]
00007f30a29db156  vmovaps xmm7, [rsp+0x70]
00007f30a29db15c  vmovaps xmm8, [rsp+0x80]
00007f30a29db165  vmovaps xmm9, [rsp+0x90]
00007f30a29db16e  vmovaps xmm10, [rsp+0xA0]
00007f30a29db177  vmovaps xmm11, [rsp+0xB0]
00007f30a29db180  vmovaps xmm12, [rsp+0xC0]
00007f30a29db189  vmovaps xmm13, [rsp+0xD0]
00007f30a29db192  vmovaps xmm14, [rsp+0xE0]
00007f30a29db19b  add rsp, 0xF0
00007f30a29db1a2  pop r11
00007f30a29db1a4  pop r10
00007f30a29db1a6  pop r9
00007f30a29db1a8  pop r8
00007f30a29db1aa  pop rsi
00007f30a29db1ab  pop rdi
00007f30a29db1ac  pop rdx
00007f30a29db1ad  pop rcx
00007f30a29db1ae  pop rax
00007f30a29db1af  add rsp, 0x08
00007f30a29db1b3  jmp 0x00007F30A29D90C6
00007f30a29db1b8  sub rsp, 0x08
00007f30a29db1bc  push rax
00007f30a29db1bd  push rcx
00007f30a29db1be  push rdx
00007f30a29db1bf  push rdi
00007f30a29db1c0  push rsi
00007f30a29db1c1  push r8
00007f30a29db1c3  push r9
00007f30a29db1c5  push r10
00007f30a29db1c7  push r11
00007f30a29db1c9  sub rsp, 0xF0
00007f30a29db1d0  vmovaps [rsp], xmm0
00007f30a29db1d5  vmovaps [rsp+0x10], xmm2
00007f30a29db1db  vmovaps [rsp+0x20], xmm3
00007f30a29db1e1  vmovaps [rsp+0x30], xmm4
00007f30a29db1e7  vmovaps [rsp+0x40], xmm5
00007f30a29db1ed  vmovaps [rsp+0x50], xmm6
00007f30a29db1f3  vmovaps [rsp+0x60], xmm7
00007f30a29db1f9  vmovaps [rsp+0x70], xmm8
00007f30a29db1ff  vmovaps [rsp+0x80], xmm9
00007f30a29db208  vmovaps [rsp+0x90], xmm10
00007f30a29db211  vmovaps [rsp+0xA0], xmm11
00007f30a29db21a  vmovaps [rsp+0xB0], xmm12
00007f30a29db223  vmovaps [rsp+0xC0], xmm13
00007f30a29db22c  vmovaps [rsp+0xD0], xmm14
00007f30a29db235  vmovaps [rsp+0xE0], xmm15
00007f30a29db23e  sub rsp, 0x30
00007f30a29db242  movaps [rsp], xmm1
00007f30a29db246  movaps [rsp+0x10], xmm5
00007f30a29db24b  movaps [rsp+0x20], xmm4
00007f30a29db250  lea rdi, [rsp]
00007f30a29db254  mov esi, 0x00
00007f30a29db259  mov rax, 0x5FE955026530
00007f30a29db263  call rax
00007f30a29db265  movaps xmm1, [rsp]
00007f30a29db269  add rsp, 0x30
00007f30a29db26d  vmovaps xmm0, [rsp]
00007f30a29db272  vmovaps xmm2, [rsp+0x10]
00007f30a29db278  vmovaps xmm3, [rsp+0x20]
00007f30a29db27e  vmovaps xmm4, [rsp+0x30]
00007f30a29db284  vmovaps xmm5, [rsp+0x40]
00007f30a29db28a  vmovaps xmm6, [rsp+0x50]
00007f30a29db290  vmovaps xmm7, [rsp+0x60]
00007f30a29db296  vmovaps xmm8, [rsp+0x70]
00007f30a29db29c  vmovaps xmm9, [rsp+0x80]
00007f30a29db2a5  vmovaps xmm10, [rsp+0x90]
00007f30a29db2ae  vmovaps xmm11, [rsp+0xA0]
00007f30a29db2b7  vmovaps xmm12, [rsp+0xB0]
00007f30a29db2c0  vmovaps xmm13, [rsp+0xC0]
00007f30a29db2c9  vmovaps xmm14, [rsp+0xD0]
00007f30a29db2d2  vmovaps xmm15, [rsp+0xE0]
00007f30a29db2db  add rsp, 0xF0
00007f30a29db2e2  pop r11
00007f30a29db2e4  pop r10
00007f30a29db2e6  pop r9
00007f30a29db2e8  pop r8
00007f30a29db2ea  pop rsi
00007f30a29db2eb  pop rdi
00007f30a29db2ec  pop rdx
00007f30a29db2ed  pop rcx
00007f30a29db2ee  pop rax
00007f30a29db2ef  add rsp, 0x08
00007f30a29db2f3  jmp 0x00007F30A29D90E6
00007f30a29db2f8  sub rsp, 0x08
00007f30a29db2fc  push rax
00007f30a29db2fd  push rcx
00007f30a29db2fe  push rdx
00007f30a29db2ff  push rdi
00007f30a29db300  push rsi
00007f30a29db301  push r8
00007f30a29db303  push r9
00007f30a29db305  push r10
00007f30a29db307  push r11
00007f30a29db309  sub rsp, 0xF0
00007f30a29db310  vmovaps [rsp], xmm0
00007f30a29db315  vmovaps [rsp+0x10], xmm1
00007f30a29db31b  vmovaps [rsp+0x20], xmm2
00007f30a29db321  vmovaps [rsp+0x30], xmm3
00007f30a29db327  vmovaps [rsp+0x40], xmm5
00007f30a29db32d  vmovaps [rsp+0x50], xmm6
00007f30a29db333  vmovaps [rsp+0x60], xmm7
00007f30a29db339  vmovaps [rsp+0x70], xmm8
00007f30a29db33f  vmovaps [rsp+0x80], xmm9
00007f30a29db348  vmovaps [rsp+0x90], xmm10
00007f30a29db351  vmovaps [rsp+0xA0], xmm11
00007f30a29db35a  vmovaps [rsp+0xB0], xmm12
00007f30a29db363  vmovaps [rsp+0xC0], xmm13
00007f30a29db36c  vmovaps [rsp+0xD0], xmm14
00007f30a29db375  vmovaps [rsp+0xE0], xmm15
00007f30a29db37e  sub rsp, 0x30
00007f30a29db382  movaps [rsp], xmm4
00007f30a29db386  movaps [rsp+0x10], xmm3
00007f30a29db38b  movaps [rsp+0x20], xmm5
00007f30a29db390  lea rdi, [rsp]
00007f30a29db394  mov esi, 0x00
00007f30a29db399  mov rax, 0x5FE955026530
00007f30a29db3a3  call rax
00007f30a29db3a5  movaps xmm4, [rsp]
00007f30a29db3a9  add rsp, 0x30
00007f30a29db3ad  vmovaps xmm0, [rsp]
00007f30a29db3b2  vmovaps xmm1, [rsp+0x10]
00007f30a29db3b8  vmovaps xmm2, [rsp+0x20]
00007f30a29db3be  vmovaps xmm3, [rsp+0x30]
00007f30a29db3c4  vmovaps xmm5, [rsp+0x40]
00007f30a29db3ca  vmovaps xmm6, [rsp+0x50]
00007f30a29db3d0  vmovaps xmm7, [rsp+0x60]
00007f30a29db3d6  vmovaps xmm8, [rsp+0x70]
00007f30a29db3dc  vmovaps xmm9, [rsp+0x80]
00007f30a29db3e5  vmovaps xmm10, [rsp+0x90]
00007f30a29db3ee  vmovaps xmm11, [rsp+0xA0]
00007f30a29db3f7  vmovaps xmm12, [rsp+0xB0]
00007f30a29db400  vmovaps xmm13, [rsp+0xC0]
00007f30a29db409  vmovaps xmm14, [rsp+0xD0]
00007f30a29db412  vmovaps xmm15, [rsp+0xE0]
00007f30a29db41b  add rsp, 0xF0
00007f30a29db422  pop r11
00007f30a29db424  pop r10
00007f30a29db426  pop r9
00007f30a29db428  pop r8
00007f30a29db42a  pop rsi
00007f30a29db42b  pop rdi
00007f30a29db42c  pop rdx
00007f30a29db42d  pop rcx
00007f30a29db42e  pop rax
00007f30a29db42f  add rsp, 0x08
00007f30a29db433  jmp 0x00007F30A29D9134
00007f30a29db438  call 0x00007F30A28D64F0
00007f30a29db43d  jmp 0x00007F30A29D9141
00007f30a29db442  sub rsp, 0x08
00007f30a29db446  push rax
00007f30a29db447  push rcx
00007f30a29db448  push rdx
00007f30a29db449  push rdi
00007f30a29db44a  push rsi
00007f30a29db44b  push r8
00007f30a29db44d  push r9
00007f30a29db44f  push r10
00007f30a29db451  push r11
00007f30a29db453  sub rsp, 0xF0
00007f30a29db45a  vmovaps [rsp], xmm0
00007f30a29db45f  vmovaps [rsp+0x10], xmm1
00007f30a29db465  vmovaps [rsp+0x20], xmm2
00007f30a29db46b  vmovaps [rsp+0x30], xmm3
00007f30a29db471  vmovaps [rsp+0x40], xmm4
00007f30a29db477  vmovaps [rsp+0x50], xmm6
00007f30a29db47d  vmovaps [rsp+0x60], xmm7
00007f30a29db483  vmovaps [rsp+0x70], xmm8
00007f30a29db489  vmovaps [rsp+0x80], xmm9
00007f30a29db492  vmovaps [rsp+0x90], xmm10
00007f30a29db49b  vmovaps [rsp+0xA0], xmm11
00007f30a29db4a4  vmovaps [rsp+0xB0], xmm12
00007f30a29db4ad  vmovaps [rsp+0xC0], xmm13
00007f30a29db4b6  vmovaps [rsp+0xD0], xmm14
00007f30a29db4bf  vmovaps [rsp+0xE0], xmm15
00007f30a29db4c8  sub rsp, 0x30
00007f30a29db4cc  movaps [rsp], xmm5
00007f30a29db4d0  movaps [rsp+0x10], xmm6
00007f30a29db4d5  movaps [rsp+0x20], xmm3
00007f30a29db4da  lea rdi, [rsp]
00007f30a29db4de  mov esi, 0x00
00007f30a29db4e3  mov rax, 0x5FE955026530
00007f30a29db4ed  call rax
00007f30a29db4ef  movaps xmm5, [rsp]
00007f30a29db4f3  add rsp, 0x30
00007f30a29db4f7  vmovaps xmm0, [rsp]
00007f30a29db4fc  vmovaps xmm1, [rsp+0x10]
00007f30a29db502  vmovaps xmm2, [rsp+0x20]
00007f30a29db508  vmovaps xmm3, [rsp+0x30]
00007f30a29db50e  vmovaps xmm4, [rsp+0x40]
00007f30a29db514  vmovaps xmm6, [rsp+0x50]
00007f30a29db51a  vmovaps xmm7, [rsp+0x60]
00007f30a29db520  vmovaps xmm8, [rsp+0x70]
00007f30a29db526  vmovaps xmm9, [rsp+0x80]
00007f30a29db52f  vmovaps xmm10, [rsp+0x90]
00007f30a29db538  vmovaps xmm11, [rsp+0xA0]
00007f30a29db541  vmovaps xmm12, [rsp+0xB0]
00007f30a29db54a  vmovaps xmm13, [rsp+0xC0]
00007f30a29db553  vmovaps xmm14, [rsp+0xD0]
00007f30a29db55c  vmovaps xmm15, [rsp+0xE0]
00007f30a29db565  add rsp, 0xF0
00007f30a29db56c  pop r11
00007f30a29db56e  pop r10
00007f30a29db570  pop r9
00007f30a29db572  pop r8
00007f30a29db574  pop rsi
00007f30a29db575  pop rdi
00007f30a29db576  pop rdx
00007f30a29db577  pop rcx
00007f30a29db578  pop rax
00007f30a29db579  add rsp, 0x08
00007f30a29db57d  jmp 0x00007F30A29D9167
00007f30a29db582  sub rsp, 0x08
00007f30a29db586  push rax
00007f30a29db587  push rcx
00007f30a29db588  push rdx
00007f30a29db589  push rdi
00007f30a29db58a  push rsi
00007f30a29db58b  push r8
00007f30a29db58d  push r9
00007f30a29db58f  push r10
00007f30a29db591  push r11
00007f30a29db593  sub rsp, 0xF0
00007f30a29db59a  vmovaps [rsp], xmm0
00007f30a29db59f  vmovaps [rsp+0x10], xmm1
00007f30a29db5a5  vmovaps [rsp+0x20], xmm2
00007f30a29db5ab  vmovaps [rsp+0x30], xmm3
00007f30a29db5b1  vmovaps [rsp+0x40], xmm4
00007f30a29db5b7  vmovaps [rsp+0x50], xmm5
00007f30a29db5bd  vmovaps [rsp+0x60], xmm7
00007f30a29db5c3  vmovaps [rsp+0x70], xmm8
00007f30a29db5c9  vmovaps [rsp+0x80], xmm9
00007f30a29db5d2  vmovaps [rsp+0x90], xmm10
00007f30a29db5db  vmovaps [rsp+0xA0], xmm11
00007f30a29db5e4  vmovaps [rsp+0xB0], xmm12
00007f30a29db5ed  vmovaps [rsp+0xC0], xmm13
00007f30a29db5f6  vmovaps [rsp+0xD0], xmm14
00007f30a29db5ff  vmovaps [rsp+0xE0], xmm15
00007f30a29db608  sub rsp, 0x30
00007f30a29db60c  movaps [rsp], xmm6
00007f30a29db610  movaps [rsp+0x10], xmm9
00007f30a29db616  movaps [rsp+0x20], xmm1
00007f30a29db61b  lea rdi, [rsp]
00007f30a29db61f  mov esi, 0x00
00007f30a29db624  mov rax, 0x5FE955026530
00007f30a29db62e  call rax
00007f30a29db630  movaps xmm6, [rsp]
00007f30a29db634  add rsp, 0x30
00007f30a29db638  vmovaps xmm0, [rsp]
00007f30a29db63d  vmovaps xmm1, [rsp+0x10]
00007f30a29db643  vmovaps xmm2, [rsp+0x20]
00007f30a29db649  vmovaps xmm3, [rsp+0x30]
00007f30a29db64f  vmovaps xmm4, [rsp+0x40]
00007f30a29db655  vmovaps xmm5, [rsp+0x50]
00007f30a29db65b  vmovaps xmm7, [rsp+0x60]
00007f30a29db661  vmovaps xmm8, [rsp+0x70]
00007f30a29db667  vmovaps xmm9, [rsp+0x80]
00007f30a29db670  vmovaps xmm10, [rsp+0x90]
00007f30a29db679  vmovaps xmm11, [rsp+0xA0]
00007f30a29db682  vmovaps xmm12, [rsp+0xB0]
00007f30a29db68b  vmovaps xmm13, [rsp+0xC0]
00007f30a29db694  vmovaps xmm14, [rsp+0xD0]
00007f30a29db69d  vmovaps xmm15, [rsp+0xE0]
00007f30a29db6a6  add rsp, 0xF0
00007f30a29db6ad  pop r11
00007f30a29db6af  pop r10
00007f30a29db6b1  pop r9
00007f30a29db6b3  pop r8
00007f30a29db6b5  pop rsi
00007f30a29db6b6  pop rdi
00007f30a29db6b7  pop rdx
00007f30a29db6b8  pop rcx
00007f30a29db6b9  pop rax
00007f30a29db6ba  add rsp, 0x08
00007f30a29db6be  jmp 0x00007F30A29D918B
00007f30a29db6c3  sub rsp, 0x08
00007f30a29db6c7  push rax
00007f30a29db6c8  push rcx
00007f30a29db6c9  push rdx
00007f30a29db6ca  push rdi
00007f30a29db6cb  push rsi
00007f30a29db6cc  push r8
00007f30a29db6ce  push r9
00007f30a29db6d0  push r10
00007f30a29db6d2  push r11
00007f30a29db6d4  sub rsp, 0xF0
00007f30a29db6db  vmovaps [rsp], xmm0
00007f30a29db6e0  vmovaps [rsp+0x10], xmm1
00007f30a29db6e6  vmovaps [rsp+0x20], xmm2
00007f30a29db6ec  vmovaps [rsp+0x30], xmm3
00007f30a29db6f2  vmovaps [rsp+0x40], xmm4
00007f30a29db6f8  vmovaps [rsp+0x50], xmm5
00007f30a29db6fe  vmovaps [rsp+0x60], xmm6
00007f30a29db704  vmovaps [rsp+0x70], xmm7
00007f30a29db70a  vmovaps [rsp+0x80], xmm8
00007f30a29db713  vmovaps [rsp+0x90], xmm10
00007f30a29db71c  vmovaps [rsp+0xA0], xmm11
00007f30a29db725  vmovaps [rsp+0xB0], xmm12
00007f30a29db72e  vmovaps [rsp+0xC0], xmm13
00007f30a29db737  vmovaps [rsp+0xD0], xmm14
00007f30a29db740  vmovaps [rsp+0xE0], xmm15
00007f30a29db749  sub rsp, 0x30
00007f30a29db74d  movaps [rsp], xmm9
00007f30a29db752  movaps [rsp+0x10], xmm3
00007f30a29db757  movaps [rsp+0x20], xmm1
00007f30a29db75c  lea rdi, [rsp]
00007f30a29db760  mov esi, 0x00
00007f30a29db765  mov rax, 0x5FE955026530
00007f30a29db76f  call rax
00007f30a29db771  movaps xmm9, [rsp]
00007f30a29db776  add rsp, 0x30
00007f30a29db77a  vmovaps xmm0, [rsp]
00007f30a29db77f  vmovaps xmm1, [rsp+0x10]
00007f30a29db785  vmovaps xmm2, [rsp+0x20]
00007f30a29db78b  vmovaps xmm3, [rsp+0x30]
00007f30a29db791  vmovaps xmm4, [rsp+0x40]
00007f30a29db797  vmovaps xmm5, [rsp+0x50]
00007f30a29db79d  vmovaps xmm6, [rsp+0x60]
00007f30a29db7a3  vmovaps xmm7, [rsp+0x70]
00007f30a29db7a9  vmovaps xmm8, [rsp+0x80]
00007f30a29db7b2  vmovaps xmm10, [rsp+0x90]
00007f30a29db7bb  vmovaps xmm11, [rsp+0xA0]
00007f30a29db7c4  vmovaps xmm12, [rsp+0xB0]
00007f30a29db7cd  vmovaps xmm13, [rsp+0xC0]
00007f30a29db7d6  vmovaps xmm14, [rsp+0xD0]
00007f30a29db7df  vmovaps xmm15, [rsp+0xE0]
00007f30a29db7e8  add rsp, 0xF0
00007f30a29db7ef  pop r11
00007f30a29db7f1  pop r10
00007f30a29db7f3  pop r9
00007f30a29db7f5  pop r8
00007f30a29db7f7  pop rsi
00007f30a29db7f8  pop rdi
00007f30a29db7f9  pop rdx
00007f30a29db7fa  pop rcx
00007f30a29db7fb  pop rax
00007f30a29db7fc  add rsp, 0x08
00007f30a29db800  jmp 0x00007F30A29D91D7
00007f30a29db805  call 0x00007F30A28D64F0
00007f30a29db80a  jmp 0x00007F30A29D91E4
00007f30a29db80f  sub rsp, 0x08
00007f30a29db813  push rax
00007f30a29db814  push rcx
00007f30a29db815  push rdx
00007f30a29db816  push rdi
00007f30a29db817  push rsi
00007f30a29db818  push r8
00007f30a29db81a  push r9
00007f30a29db81c  push r10
00007f30a29db81e  push r11
00007f30a29db820  sub rsp, 0xF0
00007f30a29db827  vmovaps [rsp], xmm0
00007f30a29db82c  vmovaps [rsp+0x10], xmm1
00007f30a29db832  vmovaps [rsp+0x20], xmm2
00007f30a29db838  vmovaps [rsp+0x30], xmm3
00007f30a29db83e  vmovaps [rsp+0x40], xmm4
00007f30a29db844  vmovaps [rsp+0x50], xmm5
00007f30a29db84a  vmovaps [rsp+0x60], xmm6
00007f30a29db850  vmovaps [rsp+0x70], xmm7
00007f30a29db856  vmovaps [rsp+0x80], xmm8
00007f30a29db85f  vmovaps [rsp+0x90], xmm9
00007f30a29db868  vmovaps [rsp+0xA0], xmm10
00007f30a29db871  vmovaps [rsp+0xB0], xmm11
00007f30a29db87a  vmovaps [rsp+0xC0], xmm12
00007f30a29db883  vmovaps [rsp+0xD0], xmm13
00007f30a29db88c  vmovaps [rsp+0xE0], xmm14
00007f30a29db895  sub rsp, 0x30
00007f30a29db899  movaps [rsp], xmm15
00007f30a29db89e  movaps [rsp+0x10], xmm3
00007f30a29db8a3  movaps [rsp+0x20], xmm7
00007f30a29db8a8  lea rdi, [rsp]
00007f30a29db8ac  mov esi, 0x00
00007f30a29db8b1  mov rax, 0x5FE955026530
00007f30a29db8bb  call rax
00007f30a29db8bd  movaps xmm15, [rsp]
00007f30a29db8c2  add rsp, 0x30
00007f30a29db8c6  vmovaps xmm0, [rsp]
00007f30a29db8cb  vmovaps xmm1, [rsp+0x10]
00007f30a29db8d1  vmovaps xmm2, [rsp+0x20]
00007f30a29db8d7  vmovaps xmm3, [rsp+0x30]
00007f30a29db8dd  vmovaps xmm4, [rsp+0x40]
00007f30a29db8e3  vmovaps xmm5, [rsp+0x50]
00007f30a29db8e9  vmovaps xmm6, [rsp+0x60]
00007f30a29db8ef  vmovaps xmm7, [rsp+0x70]
00007f30a29db8f5  vmovaps xmm8, [rsp+0x80]
00007f30a29db8fe  vmovaps xmm9, [rsp+0x90]
00007f30a29db907  vmovaps xmm10, [rsp+0xA0]
00007f30a29db910  vmovaps xmm11, [rsp+0xB0]
00007f30a29db919  vmovaps xmm12, [rsp+0xC0]
00007f30a29db922  vmovaps xmm13, [rsp+0xD0]
00007f30a29db92b  vmovaps xmm14, [rsp+0xE0]
00007f30a29db934  add rsp, 0xF0
00007f30a29db93b  pop r11
00007f30a29db93d  pop r10
00007f30a29db93f  pop r9
00007f30a29db941  pop r8
00007f30a29db943  pop rsi
00007f30a29db944  pop rdi
00007f30a29db945  pop rdx
00007f30a29db946  pop rcx
00007f30a29db947  pop rax
00007f30a29db948  add rsp, 0x08
00007f30a29db94c  jmp 0x00007F30A29D9210
00007f30a29db951  sub rsp, 0x08
00007f30a29db955  push rax
00007f30a29db956  push rcx
00007f30a29db957  push rdx
00007f30a29db958  push rdi
00007f30a29db959  push rsi
00007f30a29db95a  push r8
00007f30a29db95c  push r9
00007f30a29db95e  push r10
00007f30a29db960  push r11
00007f30a29db962  sub rsp, 0xF0
00007f30a29db969  vmovaps [rsp], xmm0
00007f30a29db96e  vmovaps [rsp+0x10], xmm1
00007f30a29db974  vmovaps [rsp+0x20], xmm2
00007f30a29db97a  vmovaps [rsp+0x30], xmm4
00007f30a29db980  vmovaps [rsp+0x40], xmm5
00007f30a29db986  vmovaps [rsp+0x50], xmm6
00007f30a29db98c  vmovaps [rsp+0x60], xmm7
00007f30a29db992  vmovaps [rsp+0x70], xmm8
00007f30a29db998  vmovaps [rsp+0x80], xmm9
00007f30a29db9a1  vmovaps [rsp+0x90], xmm10
00007f30a29db9aa  vmovaps [rsp+0xA0], xmm11
00007f30a29db9b3  vmovaps [rsp+0xB0], xmm12
00007f30a29db9bc  vmovaps [rsp+0xC0], xmm13
00007f30a29db9c5  vmovaps [rsp+0xD0], xmm14
00007f30a29db9ce  vmovaps [rsp+0xE0], xmm15
00007f30a29db9d7  sub rsp, 0x30
00007f30a29db9db  movaps [rsp], xmm3
00007f30a29db9df  movaps [rsp+0x10], xmm1
00007f30a29db9e4  movaps [rsp+0x20], xmm15
00007f30a29db9ea  lea rdi, [rsp]
00007f30a29db9ee  mov esi, 0x00
00007f30a29db9f3  mov rax, 0x5FE955026530
00007f30a29db9fd  call rax
00007f30a29db9ff  movaps xmm3, [rsp]
00007f30a29dba03  add rsp, 0x30
00007f30a29dba07  vmovaps xmm0, [rsp]
00007f30a29dba0c  vmovaps xmm1, [rsp+0x10]
00007f30a29dba12  vmovaps xmm2, [rsp+0x20]
00007f30a29dba18  vmovaps xmm4, [rsp+0x30]
00007f30a29dba1e  vmovaps xmm5, [rsp+0x40]
00007f30a29dba24  vmovaps xmm6, [rsp+0x50]
00007f30a29dba2a  vmovaps xmm7, [rsp+0x60]
00007f30a29dba30  vmovaps xmm8, [rsp+0x70]
00007f30a29dba36  vmovaps xmm9, [rsp+0x80]
00007f30a29dba3f  vmovaps xmm10, [rsp+0x90]
00007f30a29dba48  vmovaps xmm11, [rsp+0xA0]
00007f30a29dba51  vmovaps xmm12, [rsp+0xB0]
00007f30a29dba5a  vmovaps xmm13, [rsp+0xC0]
00007f30a29dba63  vmovaps xmm14, [rsp+0xD0]
00007f30a29dba6c  vmovaps xmm15, [rsp+0xE0]
00007f30a29dba75  add rsp, 0xF0
00007f30a29dba7c  pop r11
00007f30a29dba7e  pop r10
00007f30a29dba80  pop r9
00007f30a29dba82  pop r8
00007f30a29dba84  pop rsi
00007f30a29dba85  pop rdi
00007f30a29dba86  pop rdx
00007f30a29dba87  pop rcx
00007f30a29dba88  pop rax
00007f30a29dba89  add rsp, 0x08
00007f30a29dba8d  jmp 0x00007F30A29D929F
00007f30a29dba92  call 0x00007F30A28D64F0
00007f30a29dba97  jmp 0x00007F30A29D92A9
00007f30a29dba9c  sub rsp, 0x08
00007f30a29dbaa0  push rax
00007f30a29dbaa1  push rcx
00007f30a29dbaa2  push rdx
00007f30a29dbaa3  push rdi
00007f30a29dbaa4  push rsi
00007f30a29dbaa5  push r8
00007f30a29dbaa7  push r9
00007f30a29dbaa9  push r10
00007f30a29dbaab  push r11
00007f30a29dbaad  sub rsp, 0xF0
00007f30a29dbab4  vmovaps [rsp], xmm0
00007f30a29dbab9  vmovaps [rsp+0x10], xmm1
00007f30a29dbabf  vmovaps [rsp+0x20], xmm2
00007f30a29dbac5  vmovaps [rsp+0x30], xmm3
00007f30a29dbacb  vmovaps [rsp+0x40], xmm4
00007f30a29dbad1  vmovaps [rsp+0x50], xmm5
00007f30a29dbad7  vmovaps [rsp+0x60], xmm6
00007f30a29dbadd  vmovaps [rsp+0x70], xmm7
00007f30a29dbae3  vmovaps [rsp+0x80], xmm8
00007f30a29dbaec  vmovaps [rsp+0x90], xmm9
00007f30a29dbaf5  vmovaps [rsp+0xA0], xmm10
00007f30a29dbafe  vmovaps [rsp+0xB0], xmm11
00007f30a29dbb07  vmovaps [rsp+0xC0], xmm12
00007f30a29dbb10  vmovaps [rsp+0xD0], xmm13
00007f30a29dbb19  vmovaps [rsp+0xE0], xmm14
00007f30a29dbb22  sub rsp, 0x30
00007f30a29dbb26  movaps [rsp], xmm15
00007f30a29dbb2b  movaps [rsp+0x10], xmm14
00007f30a29dbb31  movaps [rsp+0x20], xmm4
00007f30a29dbb36  lea rdi, [rsp]
00007f30a29dbb3a  mov esi, 0x00
00007f30a29dbb3f  mov rax, 0x5FE955026530
00007f30a29dbb49  call rax
00007f30a29dbb4b  movaps xmm15, [rsp]
00007f30a29dbb50  add rsp, 0x30
00007f30a29dbb54  vmovaps xmm0, [rsp]
00007f30a29dbb59  vmovaps xmm1, [rsp+0x10]
00007f30a29dbb5f  vmovaps xmm2, [rsp+0x20]
00007f30a29dbb65  vmovaps xmm3, [rsp+0x30]
00007f30a29dbb6b  vmovaps xmm4, [rsp+0x40]
00007f30a29dbb71  vmovaps xmm5, [rsp+0x50]
00007f30a29dbb77  vmovaps xmm6, [rsp+0x60]
00007f30a29dbb7d  vmovaps xmm7, [rsp+0x70]
00007f30a29dbb83  vmovaps xmm8, [rsp+0x80]
00007f30a29dbb8c  vmovaps xmm9, [rsp+0x90]
00007f30a29dbb95  vmovaps xmm10, [rsp+0xA0]
00007f30a29dbb9e  vmovaps xmm11, [rsp+0xB0]
00007f30a29dbba7  vmovaps xmm12, [rsp+0xC0]
00007f30a29dbbb0  vmovaps xmm13, [rsp+0xD0]
00007f30a29dbbb9  vmovaps xmm14, [rsp+0xE0]
00007f30a29dbbc2  add rsp, 0xF0
00007f30a29dbbc9  pop r11
00007f30a29dbbcb  pop r10
00007f30a29dbbcd  pop r9
00007f30a29dbbcf  pop r8
00007f30a29dbbd1  pop rsi
00007f30a29dbbd2  pop rdi
00007f30a29dbbd3  pop rdx
00007f30a29dbbd4  pop rcx
00007f30a29dbbd5  pop rax
00007f30a29dbbd6  add rsp, 0x08
00007f30a29dbbda  jmp 0x00007F30A29D92D7
00007f30a29dbbdf  sub rsp, 0x08
00007f30a29dbbe3  push rax
00007f30a29dbbe4  push rcx
00007f30a29dbbe5  push rdx
00007f30a29dbbe6  push rdi
00007f30a29dbbe7  push rsi
00007f30a29dbbe8  push r8
00007f30a29dbbea  push r9
00007f30a29dbbec  push r10
00007f30a29dbbee  push r11
00007f30a29dbbf0  sub rsp, 0xF0
00007f30a29dbbf7  vmovaps [rsp], xmm0
00007f30a29dbbfc  vmovaps [rsp+0x10], xmm1
00007f30a29dbc02  vmovaps [rsp+0x20], xmm2
00007f30a29dbc08  vmovaps [rsp+0x30], xmm3
00007f30a29dbc0e  vmovaps [rsp+0x40], xmm4
00007f30a29dbc14  vmovaps [rsp+0x50], xmm5
00007f30a29dbc1a  vmovaps [rsp+0x60], xmm6
00007f30a29dbc20  vmovaps [rsp+0x70], xmm7
00007f30a29dbc26  vmovaps [rsp+0x80], xmm8
00007f30a29dbc2f  vmovaps [rsp+0x90], xmm9
00007f30a29dbc38  vmovaps [rsp+0xA0], xmm10
00007f30a29dbc41  vmovaps [rsp+0xB0], xmm11
00007f30a29dbc4a  vmovaps [rsp+0xC0], xmm12
00007f30a29dbc53  vmovaps [rsp+0xD0], xmm13
00007f30a29dbc5c  vmovaps [rsp+0xE0], xmm15
00007f30a29dbc65  sub rsp, 0x30
00007f30a29dbc69  movaps [rsp], xmm14
00007f30a29dbc6e  movaps [rsp+0x10], xmm2
00007f30a29dbc73  movaps [rsp+0x20], xmm1
00007f30a29dbc78  lea rdi, [rsp]
00007f30a29dbc7c  mov esi, 0x00
00007f30a29dbc81  mov rax, 0x5FE955026530
00007f30a29dbc8b  call rax
00007f30a29dbc8d  movaps xmm14, [rsp]
00007f30a29dbc92  add rsp, 0x30
00007f30a29dbc96  vmovaps xmm0, [rsp]
00007f30a29dbc9b  vmovaps xmm1, [rsp+0x10]
00007f30a29dbca1  vmovaps xmm2, [rsp+0x20]
00007f30a29dbca7  vmovaps xmm3, [rsp+0x30]
00007f30a29dbcad  vmovaps xmm4, [rsp+0x40]
00007f30a29dbcb3  vmovaps xmm5, [rsp+0x50]
00007f30a29dbcb9  vmovaps xmm6, [rsp+0x60]
00007f30a29dbcbf  vmovaps xmm7, [rsp+0x70]
00007f30a29dbcc5  vmovaps xmm8, [rsp+0x80]
00007f30a29dbcce  vmovaps xmm9, [rsp+0x90]
00007f30a29dbcd7  vmovaps xmm10, [rsp+0xA0]
00007f30a29dbce0  vmovaps xmm11, [rsp+0xB0]
00007f30a29dbce9  vmovaps xmm12, [rsp+0xC0]
00007f30a29dbcf2  vmovaps xmm13, [rsp+0xD0]
00007f30a29dbcfb  vmovaps xmm15, [rsp+0xE0]
00007f30a29dbd04  add rsp, 0xF0
00007f30a29dbd0b  pop r11
00007f30a29dbd0d  pop r10
00007f30a29dbd0f  pop r9
00007f30a29dbd11  pop r8
00007f30a29dbd13  pop rsi
00007f30a29dbd14  pop rdi
00007f30a29dbd15  pop rdx
00007f30a29dbd16  pop rcx
00007f30a29dbd17  pop rax
00007f30a29dbd18  add rsp, 0x08
00007f30a29dbd1c  jmp 0x00007F30A29D92FD
00007f30a29dbd21  sub rsp, 0x08
00007f30a29dbd25  push rax
00007f30a29dbd26  push rcx
00007f30a29dbd27  push rdx
00007f30a29dbd28  push rdi
00007f30a29dbd29  push rsi
00007f30a29dbd2a  push r8
00007f30a29dbd2c  push r9
00007f30a29dbd2e  push r10
00007f30a29dbd30  push r11
00007f30a29dbd32  sub rsp, 0xF0
00007f30a29dbd39  vmovaps [rsp], xmm0
00007f30a29dbd3e  vmovaps [rsp+0x10], xmm2
00007f30a29dbd44  vmovaps [rsp+0x20], xmm3
00007f30a29dbd4a  vmovaps [rsp+0x30], xmm4
00007f30a29dbd50  vmovaps [rsp+0x40], xmm5
00007f30a29dbd56  vmovaps [rsp+0x50], xmm6
00007f30a29dbd5c  vmovaps [rsp+0x60], xmm7
00007f30a29dbd62  vmovaps [rsp+0x70], xmm8
00007f30a29dbd68  vmovaps [rsp+0x80], xmm9
00007f30a29dbd71  vmovaps [rsp+0x90], xmm10
00007f30a29dbd7a  vmovaps [rsp+0xA0], xmm11
00007f30a29dbd83  vmovaps [rsp+0xB0], xmm12
00007f30a29dbd8c  vmovaps [rsp+0xC0], xmm13
00007f30a29dbd95  vmovaps [rsp+0xD0], xmm14
00007f30a29dbd9e  vmovaps [rsp+0xE0], xmm15
00007f30a29dbda7  sub rsp, 0x30
00007f30a29dbdab  movaps [rsp], xmm1
00007f30a29dbdaf  movaps [rsp+0x10], xmm4
00007f30a29dbdb4  movaps [rsp+0x20], xmm9
00007f30a29dbdba  lea rdi, [rsp]
00007f30a29dbdbe  mov esi, 0x00
00007f30a29dbdc3  mov rax, 0x5FE955026530
00007f30a29dbdcd  call rax
00007f30a29dbdcf  movaps xmm1, [rsp]
00007f30a29dbdd3  add rsp, 0x30
00007f30a29dbdd7  vmovaps xmm0, [rsp]
00007f30a29dbddc  vmovaps xmm2, [rsp+0x10]
00007f30a29dbde2  vmovaps xmm3, [rsp+0x20]
00007f30a29dbde8  vmovaps xmm4, [rsp+0x30]
00007f30a29dbdee  vmovaps xmm5, [rsp+0x40]
00007f30a29dbdf4  vmovaps xmm6, [rsp+0x50]
00007f30a29dbdfa  vmovaps xmm7, [rsp+0x60]
00007f30a29dbe00  vmovaps xmm8, [rsp+0x70]
00007f30a29dbe06  vmovaps xmm9, [rsp+0x80]
00007f30a29dbe0f  vmovaps xmm10, [rsp+0x90]
00007f30a29dbe18  vmovaps xmm11, [rsp+0xA0]
00007f30a29dbe21  vmovaps xmm12, [rsp+0xB0]
00007f30a29dbe2a  vmovaps xmm13, [rsp+0xC0]
00007f30a29dbe33  vmovaps xmm14, [rsp+0xD0]
00007f30a29dbe3c  vmovaps xmm15, [rsp+0xE0]
00007f30a29dbe45  add rsp, 0xF0
00007f30a29dbe4c  pop r11
00007f30a29dbe4e  pop r10
00007f30a29dbe50  pop r9
00007f30a29dbe52  pop r8
00007f30a29dbe54  pop rsi
00007f30a29dbe55  pop rdi
00007f30a29dbe56  pop rdx
00007f30a29dbe57  pop rcx
00007f30a29dbe58  pop rax
00007f30a29dbe59  add rsp, 0x08
00007f30a29dbe5d  jmp 0x00007F30A29D931B
00007f30a29dbe62  sub rsp, 0x08
00007f30a29dbe66  push rax
00007f30a29dbe67  push rcx
00007f30a29dbe68  push rdx
00007f30a29dbe69  push rdi
00007f30a29dbe6a  push rsi
00007f30a29dbe6b  push r8
00007f30a29dbe6d  push r9
00007f30a29dbe6f  push r10
00007f30a29dbe71  push r11
00007f30a29dbe73  sub rsp, 0xF0
00007f30a29dbe7a  vmovaps [rsp], xmm0
00007f30a29dbe7f  vmovaps [rsp+0x10], xmm1
00007f30a29dbe85  vmovaps [rsp+0x20], xmm2
00007f30a29dbe8b  vmovaps [rsp+0x30], xmm3
00007f30a29dbe91  vmovaps [rsp+0x40], xmm5
00007f30a29dbe97  vmovaps [rsp+0x50], xmm6
00007f30a29dbe9d  vmovaps [rsp+0x60], xmm7
00007f30a29dbea3  vmovaps [rsp+0x70], xmm8
00007f30a29dbea9  vmovaps [rsp+0x80], xmm9
00007f30a29dbeb2  vmovaps [rsp+0x90], xmm10
00007f30a29dbebb  vmovaps [rsp+0xA0], xmm11
00007f30a29dbec4  vmovaps [rsp+0xB0], xmm12
00007f30a29dbecd  vmovaps [rsp+0xC0], xmm13
00007f30a29dbed6  vmovaps [rsp+0xD0], xmm14
00007f30a29dbedf  vmovaps [rsp+0xE0], xmm15
00007f30a29dbee8  sub rsp, 0x30
00007f30a29dbeec  movaps [rsp], xmm4
00007f30a29dbef0  movaps [rsp+0x10], xmm2
00007f30a29dbef5  movaps [rsp+0x20], xmm9
00007f30a29dbefb  lea rdi, [rsp]
00007f30a29dbeff  mov esi, 0x00
00007f30a29dbf04  mov rax, 0x5FE955026530
00007f30a29dbf0e  call rax
00007f30a29dbf10  movaps xmm4, [rsp]
00007f30a29dbf14  add rsp, 0x30
00007f30a29dbf18  vmovaps xmm0, [rsp]
00007f30a29dbf1d  vmovaps xmm1, [rsp+0x10]
00007f30a29dbf23  vmovaps xmm2, [rsp+0x20]
00007f30a29dbf29  vmovaps xmm3, [rsp+0x30]
00007f30a29dbf2f  vmovaps xmm5, [rsp+0x40]
00007f30a29dbf35  vmovaps xmm6, [rsp+0x50]
00007f30a29dbf3b  vmovaps xmm7, [rsp+0x60]
00007f30a29dbf41  vmovaps xmm8, [rsp+0x70]
00007f30a29dbf47  vmovaps xmm9, [rsp+0x80]
00007f30a29dbf50  vmovaps xmm10, [rsp+0x90]
00007f30a29dbf59  vmovaps xmm11, [rsp+0xA0]
00007f30a29dbf62  vmovaps xmm12, [rsp+0xB0]
00007f30a29dbf6b  vmovaps xmm13, [rsp+0xC0]
00007f30a29dbf74  vmovaps xmm14, [rsp+0xD0]
00007f30a29dbf7d  vmovaps xmm15, [rsp+0xE0]
00007f30a29dbf86  add rsp, 0xF0
00007f30a29dbf8d  pop r11
00007f30a29dbf8f  pop r10
00007f30a29dbf91  pop r9
00007f30a29dbf93  pop r8
00007f30a29dbf95  pop rsi
00007f30a29dbf96  pop rdi
00007f30a29dbf97  pop rdx
00007f30a29dbf98  pop rcx
00007f30a29dbf99  pop rax
00007f30a29dbf9a  add rsp, 0x08
00007f30a29dbf9e  jmp 0x00007F30A29D934B
00007f30a29dbfa3  sub rsp, 0x08
00007f30a29dbfa7  push rax
00007f30a29dbfa8  push rcx
00007f30a29dbfa9  push rdx
00007f30a29dbfaa  push rdi
00007f30a29dbfab  push rsi
00007f30a29dbfac  push r8
00007f30a29dbfae  push r9
00007f30a29dbfb0  push r10
00007f30a29dbfb2  push r11
00007f30a29dbfb4  sub rsp, 0xF0
00007f30a29dbfbb  vmovaps [rsp], xmm0
00007f30a29dbfc0  vmovaps [rsp+0x10], xmm1
00007f30a29dbfc6  vmovaps [rsp+0x20], xmm2
00007f30a29dbfcc  vmovaps [rsp+0x30], xmm3
00007f30a29dbfd2  vmovaps [rsp+0x40], xmm4
00007f30a29dbfd8  vmovaps [rsp+0x50], xmm5
00007f30a29dbfde  vmovaps [rsp+0x60], xmm6
00007f30a29dbfe4  vmovaps [rsp+0x70], xmm7
00007f30a29dbfea  vmovaps [rsp+0x80], xmm8
00007f30a29dbff3  vmovaps [rsp+0x90], xmm10
00007f30a29dbffc  vmovaps [rsp+0xA0], xmm11
00007f30a29dc005  vmovaps [rsp+0xB0], xmm12
00007f30a29dc00e  vmovaps [rsp+0xC0], xmm13
00007f30a29dc017  vmovaps [rsp+0xD0], xmm14
00007f30a29dc020  vmovaps [rsp+0xE0], xmm15
00007f30a29dc029  sub rsp, 0x30
00007f30a29dc02d  movaps [rsp], xmm9
00007f30a29dc032  movaps [rsp+0x10], xmm2
00007f30a29dc037  movaps [rsp+0x20], xmm1
00007f30a29dc03c  lea rdi, [rsp]
00007f30a29dc040  mov esi, 0x00
00007f30a29dc045  mov rax, 0x5FE955026530
00007f30a29dc04f  call rax
00007f30a29dc051  movaps xmm9, [rsp]
00007f30a29dc056  add rsp, 0x30
00007f30a29dc05a  vmovaps xmm0, [rsp]
00007f30a29dc05f  vmovaps xmm1, [rsp+0x10]
00007f30a29dc065  vmovaps xmm2, [rsp+0x20]
00007f30a29dc06b  vmovaps xmm3, [rsp+0x30]
00007f30a29dc071  vmovaps xmm4, [rsp+0x40]
00007f30a29dc077  vmovaps xmm5, [rsp+0x50]
00007f30a29dc07d  vmovaps xmm6, [rsp+0x60]
00007f30a29dc083  vmovaps xmm7, [rsp+0x70]
00007f30a29dc089  vmovaps xmm8, [rsp+0x80]
00007f30a29dc092  vmovaps xmm10, [rsp+0x90]
00007f30a29dc09b  vmovaps xmm11, [rsp+0xA0]
00007f30a29dc0a4  vmovaps xmm12, [rsp+0xB0]
00007f30a29dc0ad  vmovaps xmm13, [rsp+0xC0]
00007f30a29dc0b6  vmovaps xmm14, [rsp+0xD0]
00007f30a29dc0bf  vmovaps xmm15, [rsp+0xE0]
00007f30a29dc0c8  add rsp, 0xF0
00007f30a29dc0cf  pop r11
00007f30a29dc0d1  pop r10
00007f30a29dc0d3  pop r9
00007f30a29dc0d5  pop r8
00007f30a29dc0d7  pop rsi
00007f30a29dc0d8  pop rdi
00007f30a29dc0d9  pop rdx
00007f30a29dc0da  pop rcx
00007f30a29dc0db  pop rax
00007f30a29dc0dc  add rsp, 0x08
00007f30a29dc0e0  jmp 0x00007F30A29D9381
00007f30a29dc0e5  sub rsp, 0x08
00007f30a29dc0e9  push rax
00007f30a29dc0ea  push rcx
00007f30a29dc0eb  push rdx
00007f30a29dc0ec  push rdi
00007f30a29dc0ed  push rsi
00007f30a29dc0ee  push r8
00007f30a29dc0f0  push r9
00007f30a29dc0f2  push r10
00007f30a29dc0f4  push r11
00007f30a29dc0f6  sub rsp, 0xF0
00007f30a29dc0fd  vmovaps [rsp], xmm0
00007f30a29dc102  vmovaps [rsp+0x10], xmm2
00007f30a29dc108  vmovaps [rsp+0x20], xmm3
00007f30a29dc10e  vmovaps [rsp+0x30], xmm4
00007f30a29dc114  vmovaps [rsp+0x40], xmm5
00007f30a29dc11a  vmovaps [rsp+0x50], xmm6
00007f30a29dc120  vmovaps [rsp+0x60], xmm7
00007f30a29dc126  vmovaps [rsp+0x70], xmm8
00007f30a29dc12c  vmovaps [rsp+0x80], xmm9
00007f30a29dc135  vmovaps [rsp+0x90], xmm10
00007f30a29dc13e  vmovaps [rsp+0xA0], xmm11
00007f30a29dc147  vmovaps [rsp+0xB0], xmm12
00007f30a29dc150  vmovaps [rsp+0xC0], xmm13
00007f30a29dc159  vmovaps [rsp+0xD0], xmm14
00007f30a29dc162  vmovaps [rsp+0xE0], xmm15
00007f30a29dc16b  sub rsp, 0x30
00007f30a29dc16f  movaps [rsp], xmm1
00007f30a29dc173  movaps [rsp+0x10], xmm15
00007f30a29dc179  movaps [rsp+0x20], xmm6
00007f30a29dc17e  lea rdi, [rsp]
00007f30a29dc182  mov esi, 0x00
00007f30a29dc187  mov rax, 0x5FE955026530
00007f30a29dc191  call rax
00007f30a29dc193  movaps xmm1, [rsp]
00007f30a29dc197  add rsp, 0x30
00007f30a29dc19b  vmovaps xmm0, [rsp]
00007f30a29dc1a0  vmovaps xmm2, [rsp+0x10]
00007f30a29dc1a6  vmovaps xmm3, [rsp+0x20]
00007f30a29dc1ac  vmovaps xmm4, [rsp+0x30]
00007f30a29dc1b2  vmovaps xmm5, [rsp+0x40]
00007f30a29dc1b8  vmovaps xmm6, [rsp+0x50]
00007f30a29dc1be  vmovaps xmm7, [rsp+0x60]
00007f30a29dc1c4  vmovaps xmm8, [rsp+0x70]
00007f30a29dc1ca  vmovaps xmm9, [rsp+0x80]
00007f30a29dc1d3  vmovaps xmm10, [rsp+0x90]
00007f30a29dc1dc  vmovaps xmm11, [rsp+0xA0]
00007f30a29dc1e5  vmovaps xmm12, [rsp+0xB0]
00007f30a29dc1ee  vmovaps xmm13, [rsp+0xC0]
00007f30a29dc1f7  vmovaps xmm14, [rsp+0xD0]
00007f30a29dc200  vmovaps xmm15, [rsp+0xE0]
00007f30a29dc209  add rsp, 0xF0
00007f30a29dc210  pop r11
00007f30a29dc212  pop r10
00007f30a29dc214  pop r9
00007f30a29dc216  pop r8
00007f30a29dc218  pop rsi
00007f30a29dc219  pop rdi
00007f30a29dc21a  pop rdx
00007f30a29dc21b  pop rcx
00007f30a29dc21c  pop rax
00007f30a29dc21d  add rsp, 0x08
00007f30a29dc221  jmp 0x00007F30A29D93A2
00007f30a29dc226  sub rsp, 0x08
00007f30a29dc22a  push rax
00007f30a29dc22b  push rcx
00007f30a29dc22c  push rdx
00007f30a29dc22d  push rdi
00007f30a29dc22e  push rsi
00007f30a29dc22f  push r8
00007f30a29dc231  push r9
00007f30a29dc233  push r10
00007f30a29dc235  push r11
00007f30a29dc237  sub rsp, 0xF0
00007f30a29dc23e  vmovaps [rsp], xmm0
00007f30a29dc243  vmovaps [rsp+0x10], xmm1
00007f30a29dc249  vmovaps [rsp+0x20], xmm2
00007f30a29dc24f  vmovaps [rsp+0x30], xmm3
00007f30a29dc255  vmovaps [rsp+0x40], xmm4
00007f30a29dc25b  vmovaps [rsp+0x50], xmm5
00007f30a29dc261  vmovaps [rsp+0x60], xmm6
00007f30a29dc267  vmovaps [rsp+0x70], xmm7
00007f30a29dc26d  vmovaps [rsp+0x80], xmm8
00007f30a29dc276  vmovaps [rsp+0x90], xmm9
00007f30a29dc27f  vmovaps [rsp+0xA0], xmm10
00007f30a29dc288  vmovaps [rsp+0xB0], xmm11
00007f30a29dc291  vmovaps [rsp+0xC0], xmm12
00007f30a29dc29a  vmovaps [rsp+0xD0], xmm13
00007f30a29dc2a3  vmovaps [rsp+0xE0], xmm14
00007f30a29dc2ac  sub rsp, 0x30
00007f30a29dc2b0  movaps [rsp], xmm15
00007f30a29dc2b5  movaps [rsp+0x10], xmm5
00007f30a29dc2ba  movaps [rsp+0x20], xmm3
00007f30a29dc2bf  lea rdi, [rsp]
00007f30a29dc2c3  mov esi, 0x00
00007f30a29dc2c8  mov rax, 0x5FE955026530
00007f30a29dc2d2  call rax
00007f30a29dc2d4  movaps xmm15, [rsp]
00007f30a29dc2d9  add rsp, 0x30
00007f30a29dc2dd  vmovaps xmm0, [rsp]
00007f30a29dc2e2  vmovaps xmm1, [rsp+0x10]
00007f30a29dc2e8  vmovaps xmm2, [rsp+0x20]
00007f30a29dc2ee  vmovaps xmm3, [rsp+0x30]
00007f30a29dc2f4  vmovaps xmm4, [rsp+0x40]
00007f30a29dc2fa  vmovaps xmm5, [rsp+0x50]
00007f30a29dc300  vmovaps xmm6, [rsp+0x60]
00007f30a29dc306  vmovaps xmm7, [rsp+0x70]
00007f30a29dc30c  vmovaps xmm8, [rsp+0x80]
00007f30a29dc315  vmovaps xmm9, [rsp+0x90]
00007f30a29dc31e  vmovaps xmm10, [rsp+0xA0]
00007f30a29dc327  vmovaps xmm11, [rsp+0xB0]
00007f30a29dc330  vmovaps xmm12, [rsp+0xC0]
00007f30a29dc339  vmovaps xmm13, [rsp+0xD0]
00007f30a29dc342  vmovaps xmm14, [rsp+0xE0]
00007f30a29dc34b  add rsp, 0xF0
00007f30a29dc352  pop r11
00007f30a29dc354  pop r10
00007f30a29dc356  pop r9
00007f30a29dc358  pop r8
00007f30a29dc35a  pop rsi
00007f30a29dc35b  pop rdi
00007f30a29dc35c  pop rdx
00007f30a29dc35d  pop rcx
00007f30a29dc35e  pop rax
00007f30a29dc35f  add rsp, 0x08
00007f30a29dc363  jmp 0x00007F30A29D93BC
00007f30a29dc368  sub rsp, 0x08
00007f30a29dc36c  push rax
00007f30a29dc36d  push rcx
00007f30a29dc36e  push rdx
00007f30a29dc36f  push rdi
00007f30a29dc370  push rsi
00007f30a29dc371  push r8
00007f30a29dc373  push r9
00007f30a29dc375  push r10
00007f30a29dc377  push r11
00007f30a29dc379  sub rsp, 0xF0
00007f30a29dc380  vmovaps [rsp], xmm0
00007f30a29dc385  vmovaps [rsp+0x10], xmm1
00007f30a29dc38b  vmovaps [rsp+0x20], xmm2
00007f30a29dc391  vmovaps [rsp+0x30], xmm3
00007f30a29dc397  vmovaps [rsp+0x40], xmm4
00007f30a29dc39d  vmovaps [rsp+0x50], xmm6
00007f30a29dc3a3  vmovaps [rsp+0x60], xmm7
00007f30a29dc3a9  vmovaps [rsp+0x70], xmm8
00007f30a29dc3af  vmovaps [rsp+0x80], xmm9
00007f30a29dc3b8  vmovaps [rsp+0x90], xmm10
00007f30a29dc3c1  vmovaps [rsp+0xA0], xmm11
00007f30a29dc3ca  vmovaps [rsp+0xB0], xmm12
00007f30a29dc3d3  vmovaps [rsp+0xC0], xmm13
00007f30a29dc3dc  vmovaps [rsp+0xD0], xmm14
00007f30a29dc3e5  vmovaps [rsp+0xE0], xmm15
00007f30a29dc3ee  sub rsp, 0x30
00007f30a29dc3f2  movaps [rsp], xmm5
00007f30a29dc3f6  movaps [rsp+0x10], xmm8
00007f30a29dc3fc  movaps [rsp+0x20], xmm6
00007f30a29dc401  lea rdi, [rsp]
00007f30a29dc405  mov esi, 0x00
00007f30a29dc40a  mov rax, 0x5FE955026530
00007f30a29dc414  call rax
00007f30a29dc416  movaps xmm5, [rsp]
00007f30a29dc41a  add rsp, 0x30
00007f30a29dc41e  vmovaps xmm0, [rsp]
00007f30a29dc423  vmovaps xmm1, [rsp+0x10]
00007f30a29dc429  vmovaps xmm2, [rsp+0x20]
00007f30a29dc42f  vmovaps xmm3, [rsp+0x30]
00007f30a29dc435  vmovaps xmm4, [rsp+0x40]
00007f30a29dc43b  vmovaps xmm6, [rsp+0x50]
00007f30a29dc441  vmovaps xmm7, [rsp+0x60]
00007f30a29dc447  vmovaps xmm8, [rsp+0x70]
00007f30a29dc44d  vmovaps xmm9, [rsp+0x80]
00007f30a29dc456  vmovaps xmm10, [rsp+0x90]
00007f30a29dc45f  vmovaps xmm11, [rsp+0xA0]
00007f30a29dc468  vmovaps xmm12, [rsp+0xB0]
00007f30a29dc471  vmovaps xmm13, [rsp+0xC0]
00007f30a29dc47a  vmovaps xmm14, [rsp+0xD0]
00007f30a29dc483  vmovaps xmm15, [rsp+0xE0]
00007f30a29dc48c  add rsp, 0xF0
00007f30a29dc493  pop r11
00007f30a29dc495  pop r10
00007f30a29dc497  pop r9
00007f30a29dc499  pop r8
00007f30a29dc49b  pop rsi
00007f30a29dc49c  pop rdi
00007f30a29dc49d  pop rdx
00007f30a29dc49e  pop rcx
00007f30a29dc49f  pop rax
00007f30a29dc4a0  add rsp, 0x08
00007f30a29dc4a4  jmp 0x00007F30A29D93E0
00007f30a29dc4a9  sub rsp, 0x08
00007f30a29dc4ad  push rax
00007f30a29dc4ae  push rcx
00007f30a29dc4af  push rdx
00007f30a29dc4b0  push rdi
00007f30a29dc4b1  push rsi
00007f30a29dc4b2  push r8
00007f30a29dc4b4  push r9
00007f30a29dc4b6  push r10
00007f30a29dc4b8  push r11
00007f30a29dc4ba  sub rsp, 0xF0
00007f30a29dc4c1  vmovaps [rsp], xmm0
00007f30a29dc4c6  vmovaps [rsp+0x10], xmm1
00007f30a29dc4cc  vmovaps [rsp+0x20], xmm2
00007f30a29dc4d2  vmovaps [rsp+0x30], xmm3
00007f30a29dc4d8  vmovaps [rsp+0x40], xmm4
00007f30a29dc4de  vmovaps [rsp+0x50], xmm5
00007f30a29dc4e4  vmovaps [rsp+0x60], xmm7
00007f30a29dc4ea  vmovaps [rsp+0x70], xmm8
00007f30a29dc4f0  vmovaps [rsp+0x80], xmm9
00007f30a29dc4f9  vmovaps [rsp+0x90], xmm10
00007f30a29dc502  vmovaps [rsp+0xA0], xmm11
00007f30a29dc50b  vmovaps [rsp+0xB0], xmm12
00007f30a29dc514  vmovaps [rsp+0xC0], xmm13
00007f30a29dc51d  vmovaps [rsp+0xD0], xmm14
00007f30a29dc526  vmovaps [rsp+0xE0], xmm15
00007f30a29dc52f  sub rsp, 0x30
00007f30a29dc533  movaps [rsp], xmm6
00007f30a29dc537  movaps [rsp+0x10], xmm10
00007f30a29dc53d  movaps [rsp+0x20], xmm8
00007f30a29dc543  lea rdi, [rsp]
00007f30a29dc547  mov esi, 0x00
00007f30a29dc54c  mov rax, 0x5FE955026530
00007f30a29dc556  call rax
00007f30a29dc558  movaps xmm6, [rsp]
00007f30a29dc55c  add rsp, 0x30
00007f30a29dc560  vmovaps xmm0, [rsp]
00007f30a29dc565  vmovaps xmm1, [rsp+0x10]
00007f30a29dc56b  vmovaps xmm2, [rsp+0x20]
00007f30a29dc571  vmovaps xmm3, [rsp+0x30]
00007f30a29dc577  vmovaps xmm4, [rsp+0x40]
00007f30a29dc57d  vmovaps xmm5, [rsp+0x50]
00007f30a29dc583  vmovaps xmm7, [rsp+0x60]
00007f30a29dc589  vmovaps xmm8, [rsp+0x70]
00007f30a29dc58f  vmovaps xmm9, [rsp+0x80]
00007f30a29dc598  vmovaps xmm10, [rsp+0x90]
00007f30a29dc5a1  vmovaps xmm11, [rsp+0xA0]
00007f30a29dc5aa  vmovaps xmm12, [rsp+0xB0]
00007f30a29dc5b3  vmovaps xmm13, [rsp+0xC0]
00007f30a29dc5bc  vmovaps xmm14, [rsp+0xD0]
00007f30a29dc5c5  vmovaps xmm15, [rsp+0xE0]
00007f30a29dc5ce  add rsp, 0xF0
00007f30a29dc5d5  pop r11
00007f30a29dc5d7  pop r10
00007f30a29dc5d9  pop r9
00007f30a29dc5db  pop r8
00007f30a29dc5dd  pop rsi
00007f30a29dc5de  pop rdi
00007f30a29dc5df  pop rdx
00007f30a29dc5e0  pop rcx
00007f30a29dc5e1  pop rax
00007f30a29dc5e2  add rsp, 0x08
00007f30a29dc5e6  jmp 0x00007F30A29D9405
00007f30a29dc5eb  sub rsp, 0x08
00007f30a29dc5ef  push rax
00007f30a29dc5f0  push rcx
00007f30a29dc5f1  push rdx
00007f30a29dc5f2  push rdi
00007f30a29dc5f3  push rsi
00007f30a29dc5f4  push r8
00007f30a29dc5f6  push r9
00007f30a29dc5f8  push r10
00007f30a29dc5fa  push r11
00007f30a29dc5fc  sub rsp, 0xF0
00007f30a29dc603  vmovaps [rsp], xmm0
00007f30a29dc608  vmovaps [rsp+0x10], xmm1
00007f30a29dc60e  vmovaps [rsp+0x20], xmm2
00007f30a29dc614  vmovaps [rsp+0x30], xmm3
00007f30a29dc61a  vmovaps [rsp+0x40], xmm4
00007f30a29dc620  vmovaps [rsp+0x50], xmm5
00007f30a29dc626  vmovaps [rsp+0x60], xmm6
00007f30a29dc62c  vmovaps [rsp+0x70], xmm7
00007f30a29dc632  vmovaps [rsp+0x80], xmm8
00007f30a29dc63b  vmovaps [rsp+0x90], xmm9
00007f30a29dc644  vmovaps [rsp+0xA0], xmm11
00007f30a29dc64d  vmovaps [rsp+0xB0], xmm12
00007f30a29dc656  vmovaps [rsp+0xC0], xmm13
00007f30a29dc65f  vmovaps [rsp+0xD0], xmm14
00007f30a29dc668  vmovaps [rsp+0xE0], xmm15
00007f30a29dc671  sub rsp, 0x30
00007f30a29dc675  movaps [rsp], xmm10
00007f30a29dc67a  movaps [rsp+0x10], xmm8
00007f30a29dc680  movaps [rsp+0x20], xmm14
00007f30a29dc686  lea rdi, [rsp]
00007f30a29dc68a  mov esi, 0x00
00007f30a29dc68f  mov rax, 0x5FE955026530
00007f30a29dc699  call rax
00007f30a29dc69b  movaps xmm10, [rsp]
00007f30a29dc6a0  add rsp, 0x30
00007f30a29dc6a4  vmovaps xmm0, [rsp]
00007f30a29dc6a9  vmovaps xmm1, [rsp+0x10]
00007f30a29dc6af  vmovaps xmm2, [rsp+0x20]
00007f30a29dc6b5  vmovaps xmm3, [rsp+0x30]
00007f30a29dc6bb  vmovaps xmm4, [rsp+0x40]
00007f30a29dc6c1  vmovaps xmm5, [rsp+0x50]
00007f30a29dc6c7  vmovaps xmm6, [rsp+0x60]
00007f30a29dc6cd  vmovaps xmm7, [rsp+0x70]
00007f30a29dc6d3  vmovaps xmm8, [rsp+0x80]
00007f30a29dc6dc  vmovaps xmm9, [rsp+0x90]
00007f30a29dc6e5  vmovaps xmm11, [rsp+0xA0]
00007f30a29dc6ee  vmovaps xmm12, [rsp+0xB0]
00007f30a29dc6f7  vmovaps xmm13, [rsp+0xC0]
00007f30a29dc700  vmovaps xmm14, [rsp+0xD0]
00007f30a29dc709  vmovaps xmm15, [rsp+0xE0]
00007f30a29dc712  add rsp, 0xF0
00007f30a29dc719  pop r11
00007f30a29dc71b  pop r10
00007f30a29dc71d  pop r9
00007f30a29dc71f  pop r8
00007f30a29dc721  pop rsi
00007f30a29dc722  pop rdi
00007f30a29dc723  pop rdx
00007f30a29dc724  pop rcx
00007f30a29dc725  pop rax
00007f30a29dc726  add rsp, 0x08
00007f30a29dc72a  jmp 0x00007F30A29D9425
00007f30a29dc72f  sub rsp, 0x08
00007f30a29dc733  push rax
00007f30a29dc734  push rcx
00007f30a29dc735  push rdx
00007f30a29dc736  push rdi
00007f30a29dc737  push rsi
00007f30a29dc738  push r8
00007f30a29dc73a  push r9
00007f30a29dc73c  push r10
00007f30a29dc73e  push r11
00007f30a29dc740  sub rsp, 0xF0
00007f30a29dc747  vmovaps [rsp], xmm0
00007f30a29dc74c  vmovaps [rsp+0x10], xmm1
00007f30a29dc752  vmovaps [rsp+0x20], xmm2
00007f30a29dc758  vmovaps [rsp+0x30], xmm3
00007f30a29dc75e  vmovaps [rsp+0x40], xmm4
00007f30a29dc764  vmovaps [rsp+0x50], xmm5
00007f30a29dc76a  vmovaps [rsp+0x60], xmm6
00007f30a29dc770  vmovaps [rsp+0x70], xmm7
00007f30a29dc776  vmovaps [rsp+0x80], xmm8
00007f30a29dc77f  vmovaps [rsp+0x90], xmm9
00007f30a29dc788  vmovaps [rsp+0xA0], xmm10
00007f30a29dc791  vmovaps [rsp+0xB0], xmm11
00007f30a29dc79a  vmovaps [rsp+0xC0], xmm12
00007f30a29dc7a3  vmovaps [rsp+0xD0], xmm13
00007f30a29dc7ac  vmovaps [rsp+0xE0], xmm15
00007f30a29dc7b5  sub rsp, 0x30
00007f30a29dc7b9  movaps [rsp], xmm14
00007f30a29dc7be  movaps [rsp+0x10], xmm8
00007f30a29dc7c4  movaps [rsp+0x20], xmm4
00007f30a29dc7c9  lea rdi, [rsp]
00007f30a29dc7cd  mov esi, 0x00
00007f30a29dc7d2  mov rax, 0x5FE955026530
00007f30a29dc7dc  call rax
00007f30a29dc7de  movaps xmm14, [rsp]
00007f30a29dc7e3  add rsp, 0x30
00007f30a29dc7e7  vmovaps xmm0, [rsp]
00007f30a29dc7ec  vmovaps xmm1, [rsp+0x10]
00007f30a29dc7f2  vmovaps xmm2, [rsp+0x20]
00007f30a29dc7f8  vmovaps xmm3, [rsp+0x30]
00007f30a29dc7fe  vmovaps xmm4, [rsp+0x40]
00007f30a29dc804  vmovaps xmm5, [rsp+0x50]
00007f30a29dc80a  vmovaps xmm6, [rsp+0x60]
00007f30a29dc810  vmovaps xmm7, [rsp+0x70]
00007f30a29dc816  vmovaps xmm8, [rsp+0x80]
00007f30a29dc81f  vmovaps xmm9, [rsp+0x90]
00007f30a29dc828  vmovaps xmm10, [rsp+0xA0]
00007f30a29dc831  vmovaps xmm11, [rsp+0xB0]
00007f30a29dc83a  vmovaps xmm12, [rsp+0xC0]
00007f30a29dc843  vmovaps xmm13, [rsp+0xD0]
00007f30a29dc84c  vmovaps xmm15, [rsp+0xE0]
00007f30a29dc855  add rsp, 0xF0
00007f30a29dc85c  pop r11
00007f30a29dc85e  pop r10
00007f30a29dc860  pop r9
00007f30a29dc862  pop r8
00007f30a29dc864  pop rsi
00007f30a29dc865  pop rdi
00007f30a29dc866  pop rdx
00007f30a29dc867  pop rcx
00007f30a29dc868  pop rax
00007f30a29dc869  add rsp, 0x08
00007f30a29dc86d  jmp 0x00007F30A29D9445
00007f30a29dc872  sub rsp, 0x08
00007f30a29dc876  push rax
00007f30a29dc877  push rcx
00007f30a29dc878  push rdx
00007f30a29dc879  push rdi
00007f30a29dc87a  push rsi
00007f30a29dc87b  push r8
00007f30a29dc87d  push r9
00007f30a29dc87f  push r10
00007f30a29dc881  push r11
00007f30a29dc883  sub rsp, 0xF0
00007f30a29dc88a  vmovaps [rsp], xmm0
00007f30a29dc88f  vmovaps [rsp+0x10], xmm1
00007f30a29dc895  vmovaps [rsp+0x20], xmm2
00007f30a29dc89b  vmovaps [rsp+0x30], xmm3
00007f30a29dc8a1  vmovaps [rsp+0x40], xmm5
00007f30a29dc8a7  vmovaps [rsp+0x50], xmm6
00007f30a29dc8ad  vmovaps [rsp+0x60], xmm7
00007f30a29dc8b3  vmovaps [rsp+0x70], xmm8
00007f30a29dc8b9  vmovaps [rsp+0x80], xmm9
00007f30a29dc8c2  vmovaps [rsp+0x90], xmm10
00007f30a29dc8cb  vmovaps [rsp+0xA0], xmm11
00007f30a29dc8d4  vmovaps [rsp+0xB0], xmm12
00007f30a29dc8dd  vmovaps [rsp+0xC0], xmm13
00007f30a29dc8e6  vmovaps [rsp+0xD0], xmm14
00007f30a29dc8ef  vmovaps [rsp+0xE0], xmm15
00007f30a29dc8f8  sub rsp, 0x30
00007f30a29dc8fc  movaps [rsp], xmm4
00007f30a29dc900  movaps [rsp+0x10], xmm13
00007f30a29dc906  movaps [rsp+0x20], xmm8
00007f30a29dc90c  lea rdi, [rsp]
00007f30a29dc910  mov esi, 0x00
00007f30a29dc915  mov rax, 0x5FE955026530
00007f30a29dc91f  call rax
00007f30a29dc921  movaps xmm4, [rsp]
00007f30a29dc925  add rsp, 0x30
00007f30a29dc929  vmovaps xmm0, [rsp]
00007f30a29dc92e  vmovaps xmm1, [rsp+0x10]
00007f30a29dc934  vmovaps xmm2, [rsp+0x20]
00007f30a29dc93a  vmovaps xmm3, [rsp+0x30]
00007f30a29dc940  vmovaps xmm5, [rsp+0x40]
00007f30a29dc946  vmovaps xmm6, [rsp+0x50]
00007f30a29dc94c  vmovaps xmm7, [rsp+0x60]
00007f30a29dc952  vmovaps xmm8, [rsp+0x70]
00007f30a29dc958  vmovaps xmm9, [rsp+0x80]
00007f30a29dc961  vmovaps xmm10, [rsp+0x90]
00007f30a29dc96a  vmovaps xmm11, [rsp+0xA0]
00007f30a29dc973  vmovaps xmm12, [rsp+0xB0]
00007f30a29dc97c  vmovaps xmm13, [rsp+0xC0]
00007f30a29dc985  vmovaps xmm14, [rsp+0xD0]
00007f30a29dc98e  vmovaps xmm15, [rsp+0xE0]
00007f30a29dc997  add rsp, 0xF0
00007f30a29dc99e  pop r11
00007f30a29dc9a0  pop r10
00007f30a29dc9a2  pop r9
00007f30a29dc9a4  pop r8
00007f30a29dc9a6  pop rsi
00007f30a29dc9a7  pop rdi
00007f30a29dc9a8  pop rdx
00007f30a29dc9a9  pop rcx
00007f30a29dc9aa  pop rax
00007f30a29dc9ab  add rsp, 0x08
00007f30a29dc9af  jmp 0x00007F30A29D946A
00007f30a29dc9b4  sub rsp, 0x08
00007f30a29dc9b8  push rax
00007f30a29dc9b9  push rcx
00007f30a29dc9ba  push rdx
00007f30a29dc9bb  push rdi
00007f30a29dc9bc  push rsi
00007f30a29dc9bd  push r8
00007f30a29dc9bf  push r9
00007f30a29dc9c1  push r10
00007f30a29dc9c3  push r11
00007f30a29dc9c5  sub rsp, 0xF0
00007f30a29dc9cc  vmovaps [rsp], xmm0
00007f30a29dc9d1  vmovaps [rsp+0x10], xmm1
00007f30a29dc9d7  vmovaps [rsp+0x20], xmm2
00007f30a29dc9dd  vmovaps [rsp+0x30], xmm3
00007f30a29dc9e3  vmovaps [rsp+0x40], xmm4
00007f30a29dc9e9  vmovaps [rsp+0x50], xmm5
00007f30a29dc9ef  vmovaps [rsp+0x60], xmm6
00007f30a29dc9f5  vmovaps [rsp+0x70], xmm7
00007f30a29dc9fb  vmovaps [rsp+0x80], xmm8
00007f30a29dca04  vmovaps [rsp+0x90], xmm9
00007f30a29dca0d  vmovaps [rsp+0xA0], xmm10
00007f30a29dca16  vmovaps [rsp+0xB0], xmm11
00007f30a29dca1f  vmovaps [rsp+0xC0], xmm12
00007f30a29dca28  vmovaps [rsp+0xD0], xmm14
00007f30a29dca31  vmovaps [rsp+0xE0], xmm15
00007f30a29dca3a  sub rsp, 0x30
00007f30a29dca3e  movaps [rsp], xmm13
00007f30a29dca43  movaps [rsp+0x10], xmm15
00007f30a29dca49  movaps [rsp+0x20], xmm9
00007f30a29dca4f  lea rdi, [rsp]
00007f30a29dca53  mov esi, 0x00
00007f30a29dca58  mov rax, 0x5FE955026530
00007f30a29dca62  call rax
00007f30a29dca64  movaps xmm13, [rsp]
00007f30a29dca69  add rsp, 0x30
00007f30a29dca6d  vmovaps xmm0, [rsp]
00007f30a29dca72  vmovaps xmm1, [rsp+0x10]
00007f30a29dca78  vmovaps xmm2, [rsp+0x20]
00007f30a29dca7e  vmovaps xmm3, [rsp+0x30]
00007f30a29dca84  vmovaps xmm4, [rsp+0x40]
00007f30a29dca8a  vmovaps xmm5, [rsp+0x50]
00007f30a29dca90  vmovaps xmm6, [rsp+0x60]
00007f30a29dca96  vmovaps xmm7, [rsp+0x70]
00007f30a29dca9c  vmovaps xmm8, [rsp+0x80]
00007f30a29dcaa5  vmovaps xmm9, [rsp+0x90]
00007f30a29dcaae  vmovaps xmm10, [rsp+0xA0]
00007f30a29dcab7  vmovaps xmm11, [rsp+0xB0]
00007f30a29dcac0  vmovaps xmm12, [rsp+0xC0]
00007f30a29dcac9  vmovaps xmm14, [rsp+0xD0]
00007f30a29dcad2  vmovaps xmm15, [rsp+0xE0]
00007f30a29dcadb  add rsp, 0xF0
00007f30a29dcae2  pop r11
00007f30a29dcae4  pop r10
00007f30a29dcae6  pop r9
00007f30a29dcae8  pop r8
00007f30a29dcaea  pop rsi
00007f30a29dcaeb  pop rdi
00007f30a29dcaec  pop rdx
00007f30a29dcaed  pop rcx
00007f30a29dcaee  pop rax
00007f30a29dcaef  add rsp, 0x08
00007f30a29dcaf3  jmp 0x00007F30A29D9485
00007f30a29dcaf8  sub rsp, 0x08
00007f30a29dcafc  push rax
00007f30a29dcafd  push rcx
00007f30a29dcafe  push rdx
00007f30a29dcaff  push rdi
00007f30a29dcb00  push rsi
00007f30a29dcb01  push r8
00007f30a29dcb03  push r9
00007f30a29dcb05  push r10
00007f30a29dcb07  push r11
00007f30a29dcb09  sub rsp, 0xF0
00007f30a29dcb10  vmovaps [rsp], xmm0
00007f30a29dcb15  vmovaps [rsp+0x10], xmm1
00007f30a29dcb1b  vmovaps [rsp+0x20], xmm2
00007f30a29dcb21  vmovaps [rsp+0x30], xmm3
00007f30a29dcb27  vmovaps [rsp+0x40], xmm4
00007f30a29dcb2d  vmovaps [rsp+0x50], xmm5
00007f30a29dcb33  vmovaps [rsp+0x60], xmm6
00007f30a29dcb39  vmovaps [rsp+0x70], xmm7
00007f30a29dcb3f  vmovaps [rsp+0x80], xmm8
00007f30a29dcb48  vmovaps [rsp+0x90], xmm9
00007f30a29dcb51  vmovaps [rsp+0xA0], xmm10
00007f30a29dcb5a  vmovaps [rsp+0xB0], xmm11
00007f30a29dcb63  vmovaps [rsp+0xC0], xmm12
00007f30a29dcb6c  vmovaps [rsp+0xD0], xmm13
00007f30a29dcb75  vmovaps [rsp+0xE0], xmm14
00007f30a29dcb7e  sub rsp, 0x30
00007f30a29dcb82  movaps [rsp], xmm15
00007f30a29dcb87  movaps [rsp+0x10], xmm1
00007f30a29dcb8c  movaps [rsp+0x20], xmm5
00007f30a29dcb91  lea rdi, [rsp]
00007f30a29dcb95  mov esi, 0x00
00007f30a29dcb9a  mov rax, 0x5FE955026530
00007f30a29dcba4  call rax
00007f30a29dcba6  movaps xmm15, [rsp]
00007f30a29dcbab  add rsp, 0x30
00007f30a29dcbaf  vmovaps xmm0, [rsp]
00007f30a29dcbb4  vmovaps xmm1, [rsp+0x10]
00007f30a29dcbba  vmovaps xmm2, [rsp+0x20]
00007f30a29dcbc0  vmovaps xmm3, [rsp+0x30]
00007f30a29dcbc6  vmovaps xmm4, [rsp+0x40]
00007f30a29dcbcc  vmovaps xmm5, [rsp+0x50]
00007f30a29dcbd2  vmovaps xmm6, [rsp+0x60]
00007f30a29dcbd8  vmovaps xmm7, [rsp+0x70]
00007f30a29dcbde  vmovaps xmm8, [rsp+0x80]
00007f30a29dcbe7  vmovaps xmm9, [rsp+0x90]
00007f30a29dcbf0  vmovaps xmm10, [rsp+0xA0]
00007f30a29dcbf9  vmovaps xmm11, [rsp+0xB0]
00007f30a29dcc02  vmovaps xmm12, [rsp+0xC0]
00007f30a29dcc0b  vmovaps xmm13, [rsp+0xD0]
00007f30a29dcc14  vmovaps xmm14, [rsp+0xE0]
00007f30a29dcc1d  add rsp, 0xF0
00007f30a29dcc24  pop r11
00007f30a29dcc26  pop r10
00007f30a29dcc28  pop r9
00007f30a29dcc2a  pop r8
00007f30a29dcc2c  pop rsi
00007f30a29dcc2d  pop rdi
00007f30a29dcc2e  pop rdx
00007f30a29dcc2f  pop rcx
00007f30a29dcc30  pop rax
00007f30a29dcc31  add rsp, 0x08
00007f30a29dcc35  jmp 0x00007F30A29D94A0
00007f30a29dcc3a  call 0x00007F30A28D64F0
00007f30a29dcc3f  jmp 0x00007F30A29D94FB
00007f30a29dcc44  sub rsp, 0x08
00007f30a29dcc48  push rax
00007f30a29dcc49  push rcx
00007f30a29dcc4a  push rdx
00007f30a29dcc4b  push rdi
00007f30a29dcc4c  push rsi
00007f30a29dcc4d  push r8
00007f30a29dcc4f  push r9
00007f30a29dcc51  push r10
00007f30a29dcc53  push r11
00007f30a29dcc55  sub rsp, 0xF0
00007f30a29dcc5c  vmovaps [rsp], xmm0
00007f30a29dcc61  vmovaps [rsp+0x10], xmm1
00007f30a29dcc67  vmovaps [rsp+0x20], xmm2
00007f30a29dcc6d  vmovaps [rsp+0x30], xmm3
00007f30a29dcc73  vmovaps [rsp+0x40], xmm4
00007f30a29dcc79  vmovaps [rsp+0x50], xmm5
00007f30a29dcc7f  vmovaps [rsp+0x60], xmm6
00007f30a29dcc85  vmovaps [rsp+0x70], xmm7
00007f30a29dcc8b  vmovaps [rsp+0x80], xmm8
00007f30a29dcc94  vmovaps [rsp+0x90], xmm10
00007f30a29dcc9d  vmovaps [rsp+0xA0], xmm11
00007f30a29dcca6  vmovaps [rsp+0xB0], xmm12
00007f30a29dccaf  vmovaps [rsp+0xC0], xmm13
00007f30a29dccb8  vmovaps [rsp+0xD0], xmm14
00007f30a29dccc1  vmovaps [rsp+0xE0], xmm15
00007f30a29dccca  sub rsp, 0x30
00007f30a29dccce  movaps [rsp], xmm9
00007f30a29dccd3  movaps [rsp+0x10], xmm8
00007f30a29dccd9  movaps [rsp+0x20], xmm11
00007f30a29dccdf  lea rdi, [rsp]
00007f30a29dcce3  mov esi, 0x00
00007f30a29dcce8  mov rax, 0x5FE955026530
00007f30a29dccf2  call rax
00007f30a29dccf4  movaps xmm9, [rsp]
00007f30a29dccf9  add rsp, 0x30
00007f30a29dccfd  vmovaps xmm0, [rsp]
00007f30a29dcd02  vmovaps xmm1, [rsp+0x10]
00007f30a29dcd08  vmovaps xmm2, [rsp+0x20]
00007f30a29dcd0e  vmovaps xmm3, [rsp+0x30]
00007f30a29dcd14  vmovaps xmm4, [rsp+0x40]
00007f30a29dcd1a  vmovaps xmm5, [rsp+0x50]
00007f30a29dcd20  vmovaps xmm6, [rsp+0x60]
00007f30a29dcd26  vmovaps xmm7, [rsp+0x70]
00007f30a29dcd2c  vmovaps xmm8, [rsp+0x80]
00007f30a29dcd35  vmovaps xmm10, [rsp+0x90]
00007f30a29dcd3e  vmovaps xmm11, [rsp+0xA0]
00007f30a29dcd47  vmovaps xmm12, [rsp+0xB0]
00007f30a29dcd50  vmovaps xmm13, [rsp+0xC0]
00007f30a29dcd59  vmovaps xmm14, [rsp+0xD0]
00007f30a29dcd62  vmovaps xmm15, [rsp+0xE0]
00007f30a29dcd6b  add rsp, 0xF0
00007f30a29dcd72  pop r11
00007f30a29dcd74  pop r10
00007f30a29dcd76  pop r9
00007f30a29dcd78  pop r8
00007f30a29dcd7a  pop rsi
00007f30a29dcd7b  pop rdi
00007f30a29dcd7c  pop rdx
00007f30a29dcd7d  pop rcx
00007f30a29dcd7e  pop rax
00007f30a29dcd7f  add rsp, 0x08
00007f30a29dcd83  jmp 0x00007F30A29D9532
00007f30a29dcd88  sub rsp, 0x08
00007f30a29dcd8c  push rax
00007f30a29dcd8d  push rcx
00007f30a29dcd8e  push rdx
00007f30a29dcd8f  push rdi
00007f30a29dcd90  push rsi
00007f30a29dcd91  push r8
00007f30a29dcd93  push r9
00007f30a29dcd95  push r10
00007f30a29dcd97  push r11
00007f30a29dcd99  sub rsp, 0xF0
00007f30a29dcda0  vmovaps [rsp], xmm0
00007f30a29dcda5  vmovaps [rsp+0x10], xmm1
00007f30a29dcdab  vmovaps [rsp+0x20], xmm2
00007f30a29dcdb1  vmovaps [rsp+0x30], xmm3
00007f30a29dcdb7  vmovaps [rsp+0x40], xmm4
00007f30a29dcdbd  vmovaps [rsp+0x50], xmm5
00007f30a29dcdc3  vmovaps [rsp+0x60], xmm6
00007f30a29dcdc9  vmovaps [rsp+0x70], xmm7
00007f30a29dcdcf  vmovaps [rsp+0x80], xmm8
00007f30a29dcdd8  vmovaps [rsp+0x90], xmm9
00007f30a29dcde1  vmovaps [rsp+0xA0], xmm10
00007f30a29dcdea  vmovaps [rsp+0xB0], xmm12
00007f30a29dcdf3  vmovaps [rsp+0xC0], xmm13
00007f30a29dcdfc  vmovaps [rsp+0xD0], xmm14
00007f30a29dce05  vmovaps [rsp+0xE0], xmm15
00007f30a29dce0e  sub rsp, 0x30
00007f30a29dce12  movaps [rsp], xmm11
00007f30a29dce17  movaps [rsp+0x10], xmm10
00007f30a29dce1d  movaps [rsp+0x20], xmm6
00007f30a29dce22  lea rdi, [rsp]
00007f30a29dce26  mov esi, 0x00
00007f30a29dce2b  mov rax, 0x5FE955026530
00007f30a29dce35  call rax
00007f30a29dce37  movaps xmm11, [rsp]
00007f30a29dce3c  add rsp, 0x30
00007f30a29dce40  vmovaps xmm0, [rsp]
00007f30a29dce45  vmovaps xmm1, [rsp+0x10]
00007f30a29dce4b  vmovaps xmm2, [rsp+0x20]
00007f30a29dce51  vmovaps xmm3, [rsp+0x30]
00007f30a29dce57  vmovaps xmm4, [rsp+0x40]
00007f30a29dce5d  vmovaps xmm5, [rsp+0x50]
00007f30a29dce63  vmovaps xmm6, [rsp+0x60]
00007f30a29dce69  vmovaps xmm7, [rsp+0x70]
00007f30a29dce6f  vmovaps xmm8, [rsp+0x80]
00007f30a29dce78  vmovaps xmm9, [rsp+0x90]
00007f30a29dce81  vmovaps xmm10, [rsp+0xA0]
00007f30a29dce8a  vmovaps xmm12, [rsp+0xB0]
00007f30a29dce93  vmovaps xmm13, [rsp+0xC0]
00007f30a29dce9c  vmovaps xmm14, [rsp+0xD0]
00007f30a29dcea5  vmovaps xmm15, [rsp+0xE0]
00007f30a29dceae  add rsp, 0xF0
00007f30a29dceb5  pop r11
00007f30a29dceb7  pop r10
00007f30a29dceb9  pop r9
00007f30a29dcebb  pop r8
00007f30a29dcebd  pop rsi
00007f30a29dcebe  pop rdi
00007f30a29dcebf  pop rdx
00007f30a29dcec0  pop rcx
00007f30a29dcec1  pop rax
00007f30a29dcec2  add rsp, 0x08
00007f30a29dcec6  jmp 0x00007F30A29D954D
00007f30a29dcecb  sub rsp, 0x08
00007f30a29dcecf  push rax
00007f30a29dced0  push rcx
00007f30a29dced1  push rdx
00007f30a29dced2  push rdi
00007f30a29dced3  push rsi
00007f30a29dced4  push r8
00007f30a29dced6  push r9
00007f30a29dced8  push r10
00007f30a29dceda  push r11
00007f30a29dcedc  sub rsp, 0xF0
00007f30a29dcee3  vmovaps [rsp], xmm0
00007f30a29dcee8  vmovaps [rsp+0x10], xmm1
00007f30a29dceee  vmovaps [rsp+0x20], xmm2
00007f30a29dcef4  vmovaps [rsp+0x30], xmm3
00007f30a29dcefa  vmovaps [rsp+0x40], xmm4
00007f30a29dcf00  vmovaps [rsp+0x50], xmm5
00007f30a29dcf06  vmovaps [rsp+0x60], xmm6
00007f30a29dcf0c  vmovaps [rsp+0x70], xmm7
00007f30a29dcf12  vmovaps [rsp+0x80], xmm8
00007f30a29dcf1b  vmovaps [rsp+0x90], xmm9
00007f30a29dcf24  vmovaps [rsp+0xA0], xmm11
00007f30a29dcf2d  vmovaps [rsp+0xB0], xmm12
00007f30a29dcf36  vmovaps [rsp+0xC0], xmm13
00007f30a29dcf3f  vmovaps [rsp+0xD0], xmm14
00007f30a29dcf48  vmovaps [rsp+0xE0], xmm15
00007f30a29dcf51  sub rsp, 0x30
00007f30a29dcf55  movaps [rsp], xmm10
00007f30a29dcf5a  movaps [rsp+0x10], xmm14
00007f30a29dcf60  movaps [rsp+0x20], xmm4
00007f30a29dcf65  lea rdi, [rsp]
00007f30a29dcf69  mov esi, 0x00
00007f30a29dcf6e  mov rax, 0x5FE955026530
00007f30a29dcf78  call rax
00007f30a29dcf7a  movaps xmm10, [rsp]
00007f30a29dcf7f  add rsp, 0x30
00007f30a29dcf83  vmovaps xmm0, [rsp]
00007f30a29dcf88  vmovaps xmm1, [rsp+0x10]
00007f30a29dcf8e  vmovaps xmm2, [rsp+0x20]
00007f30a29dcf94  vmovaps xmm3, [rsp+0x30]
00007f30a29dcf9a  vmovaps xmm4, [rsp+0x40]
00007f30a29dcfa0  vmovaps xmm5, [rsp+0x50]
00007f30a29dcfa6  vmovaps xmm6, [rsp+0x60]
00007f30a29dcfac  vmovaps xmm7, [rsp+0x70]
00007f30a29dcfb2  vmovaps xmm8, [rsp+0x80]
00007f30a29dcfbb  vmovaps xmm9, [rsp+0x90]
00007f30a29dcfc4  vmovaps xmm11, [rsp+0xA0]
00007f30a29dcfcd  vmovaps xmm12, [rsp+0xB0]
00007f30a29dcfd6  vmovaps xmm13, [rsp+0xC0]
00007f30a29dcfdf  vmovaps xmm14, [rsp+0xD0]
00007f30a29dcfe8  vmovaps xmm15, [rsp+0xE0]
00007f30a29dcff1  add rsp, 0xF0
00007f30a29dcff8  pop r11
00007f30a29dcffa  pop r10
00007f30a29dcffc  pop r9
00007f30a29dcffe  pop r8
00007f30a29dd000  pop rsi
00007f30a29dd001  pop rdi
00007f30a29dd002  pop rdx
00007f30a29dd003  pop rcx
00007f30a29dd004  pop rax
00007f30a29dd005  add rsp, 0x08
00007f30a29dd009  jmp 0x00007F30A29D9568
00007f30a29dd00e  sub rsp, 0x08
00007f30a29dd012  push rax
00007f30a29dd013  push rcx
00007f30a29dd014  push rdx
00007f30a29dd015  push rdi
00007f30a29dd016  push rsi
00007f30a29dd017  push r8
00007f30a29dd019  push r9
00007f30a29dd01b  push r10
00007f30a29dd01d  push r11
00007f30a29dd01f  sub rsp, 0xF0
00007f30a29dd026  vmovaps [rsp], xmm0
00007f30a29dd02b  vmovaps [rsp+0x10], xmm1
00007f30a29dd031  vmovaps [rsp+0x20], xmm2
00007f30a29dd037  vmovaps [rsp+0x30], xmm3
00007f30a29dd03d  vmovaps [rsp+0x40], xmm4
00007f30a29dd043  vmovaps [rsp+0x50], xmm5
00007f30a29dd049  vmovaps [rsp+0x60], xmm6
00007f30a29dd04f  vmovaps [rsp+0x70], xmm7
00007f30a29dd055  vmovaps [rsp+0x80], xmm9
00007f30a29dd05e  vmovaps [rsp+0x90], xmm10
00007f30a29dd067  vmovaps [rsp+0xA0], xmm11
00007f30a29dd070  vmovaps [rsp+0xB0], xmm12
00007f30a29dd079  vmovaps [rsp+0xC0], xmm13
00007f30a29dd082  vmovaps [rsp+0xD0], xmm14
00007f30a29dd08b  vmovaps [rsp+0xE0], xmm15
00007f30a29dd094  sub rsp, 0x30
00007f30a29dd098  movaps [rsp], xmm8
00007f30a29dd09d  movaps [rsp+0x10], xmm1
00007f30a29dd0a2  movaps [rsp+0x20], xmm14
00007f30a29dd0a8  lea rdi, [rsp]
00007f30a29dd0ac  mov esi, 0x00
00007f30a29dd0b1  mov rax, 0x5FE955026530
00007f30a29dd0bb  call rax
00007f30a29dd0bd  movaps xmm8, [rsp]
00007f30a29dd0c2  add rsp, 0x30
00007f30a29dd0c6  vmovaps xmm0, [rsp]
00007f30a29dd0cb  vmovaps xmm1, [rsp+0x10]
00007f30a29dd0d1  vmovaps xmm2, [rsp+0x20]
00007f30a29dd0d7  vmovaps xmm3, [rsp+0x30]
00007f30a29dd0dd  vmovaps xmm4, [rsp+0x40]
00007f30a29dd0e3  vmovaps xmm5, [rsp+0x50]
00007f30a29dd0e9  vmovaps xmm6, [rsp+0x60]
00007f30a29dd0ef  vmovaps xmm7, [rsp+0x70]
00007f30a29dd0f5  vmovaps xmm9, [rsp+0x80]
00007f30a29dd0fe  vmovaps xmm10, [rsp+0x90]
00007f30a29dd107  vmovaps xmm11, [rsp+0xA0]
00007f30a29dd110  vmovaps xmm12, [rsp+0xB0]
00007f30a29dd119  vmovaps xmm13, [rsp+0xC0]
00007f30a29dd122  vmovaps xmm14, [rsp+0xD0]
00007f30a29dd12b  vmovaps xmm15, [rsp+0xE0]
00007f30a29dd134  add rsp, 0xF0
00007f30a29dd13b  pop r11
00007f30a29dd13d  pop r10
00007f30a29dd13f  pop r9
00007f30a29dd141  pop r8
00007f30a29dd143  pop rsi
00007f30a29dd144  pop rdi
00007f30a29dd145  pop rdx
00007f30a29dd146  pop rcx
00007f30a29dd147  pop rax
00007f30a29dd148  add rsp, 0x08
00007f30a29dd14c  jmp 0x00007F30A29D958E
00007f30a29dd151  sub rsp, 0x08
00007f30a29dd155  push rax
00007f30a29dd156  push rcx
00007f30a29dd157  push rdx
00007f30a29dd158  push rdi
00007f30a29dd159  push rsi
00007f30a29dd15a  push r8
00007f30a29dd15c  push r9
00007f30a29dd15e  push r10
00007f30a29dd160  push r11
00007f30a29dd162  sub rsp, 0xF0
00007f30a29dd169  vmovaps [rsp], xmm0
00007f30a29dd16e  vmovaps [rsp+0x10], xmm1
00007f30a29dd174  vmovaps [rsp+0x20], xmm2
00007f30a29dd17a  vmovaps [rsp+0x30], xmm3
00007f30a29dd180  vmovaps [rsp+0x40], xmm4
00007f30a29dd186  vmovaps [rsp+0x50], xmm5
00007f30a29dd18c  vmovaps [rsp+0x60], xmm7
00007f30a29dd192  vmovaps [rsp+0x70], xmm8
00007f30a29dd198  vmovaps [rsp+0x80], xmm9
00007f30a29dd1a1  vmovaps [rsp+0x90], xmm10
00007f30a29dd1aa  vmovaps [rsp+0xA0], xmm11
00007f30a29dd1b3  vmovaps [rsp+0xB0], xmm12
00007f30a29dd1bc  vmovaps [rsp+0xC0], xmm13
00007f30a29dd1c5  vmovaps [rsp+0xD0], xmm14
00007f30a29dd1ce  vmovaps [rsp+0xE0], xmm15
00007f30a29dd1d7  sub rsp, 0x30
00007f30a29dd1db  movaps [rsp], xmm6
00007f30a29dd1df  movaps [rsp+0x10], xmm1
00007f30a29dd1e4  movaps [rsp+0x20], xmm14
00007f30a29dd1ea  lea rdi, [rsp]
00007f30a29dd1ee  mov esi, 0x00
00007f30a29dd1f3  mov rax, 0x5FE955026530
00007f30a29dd1fd  call rax
00007f30a29dd1ff  movaps xmm6, [rsp]
00007f30a29dd203  add rsp, 0x30
00007f30a29dd207  vmovaps xmm0, [rsp]
00007f30a29dd20c  vmovaps xmm1, [rsp+0x10]
00007f30a29dd212  vmovaps xmm2, [rsp+0x20]
00007f30a29dd218  vmovaps xmm3, [rsp+0x30]
00007f30a29dd21e  vmovaps xmm4, [rsp+0x40]
00007f30a29dd224  vmovaps xmm5, [rsp+0x50]
00007f30a29dd22a  vmovaps xmm7, [rsp+0x60]
00007f30a29dd230  vmovaps xmm8, [rsp+0x70]
00007f30a29dd236  vmovaps xmm9, [rsp+0x80]
00007f30a29dd23f  vmovaps xmm10, [rsp+0x90]
00007f30a29dd248  vmovaps xmm11, [rsp+0xA0]
00007f30a29dd251  vmovaps xmm12, [rsp+0xB0]
00007f30a29dd25a  vmovaps xmm13, [rsp+0xC0]
00007f30a29dd263  vmovaps xmm14, [rsp+0xD0]
00007f30a29dd26c  vmovaps xmm15, [rsp+0xE0]
00007f30a29dd275  add rsp, 0xF0
00007f30a29dd27c  pop r11
00007f30a29dd27e  pop r10
00007f30a29dd280  pop r9
00007f30a29dd282  pop r8
00007f30a29dd284  pop rsi
00007f30a29dd285  pop rdi
00007f30a29dd286  pop rdx
00007f30a29dd287  pop rcx
00007f30a29dd288  pop rax
00007f30a29dd289  add rsp, 0x08
00007f30a29dd28d  jmp 0x00007F30A29D95BA
00007f30a29dd292  sub rsp, 0x08
00007f30a29dd296  push rax
00007f30a29dd297  push rcx
00007f30a29dd298  push rdx
00007f30a29dd299  push rdi
00007f30a29dd29a  push rsi
00007f30a29dd29b  push r8
00007f30a29dd29d  push r9
00007f30a29dd29f  push r10
00007f30a29dd2a1  push r11
00007f30a29dd2a3  sub rsp, 0xF0
00007f30a29dd2aa  vmovaps [rsp], xmm0
00007f30a29dd2af  vmovaps [rsp+0x10], xmm1
00007f30a29dd2b5  vmovaps [rsp+0x20], xmm2
00007f30a29dd2bb  vmovaps [rsp+0x30], xmm3
00007f30a29dd2c1  vmovaps [rsp+0x40], xmm4
00007f30a29dd2c7  vmovaps [rsp+0x50], xmm5
00007f30a29dd2cd  vmovaps [rsp+0x60], xmm6
00007f30a29dd2d3  vmovaps [rsp+0x70], xmm7
00007f30a29dd2d9  vmovaps [rsp+0x80], xmm8
00007f30a29dd2e2  vmovaps [rsp+0x90], xmm9
00007f30a29dd2eb  vmovaps [rsp+0xA0], xmm10
00007f30a29dd2f4  vmovaps [rsp+0xB0], xmm11
00007f30a29dd2fd  vmovaps [rsp+0xC0], xmm12
00007f30a29dd306  vmovaps [rsp+0xD0], xmm13
00007f30a29dd30f  vmovaps [rsp+0xE0], xmm15
00007f30a29dd318  sub rsp, 0x30
00007f30a29dd31c  movaps [rsp], xmm14
00007f30a29dd321  movaps [rsp+0x10], xmm12
00007f30a29dd327  movaps [rsp+0x20], xmm1
00007f30a29dd32c  lea rdi, [rsp]
00007f30a29dd330  mov esi, 0x00
00007f30a29dd335  mov rax, 0x5FE955026530
00007f30a29dd33f  call rax
00007f30a29dd341  movaps xmm14, [rsp]
00007f30a29dd346  add rsp, 0x30
00007f30a29dd34a  vmovaps xmm0, [rsp]
00007f30a29dd34f  vmovaps xmm1, [rsp+0x10]
00007f30a29dd355  vmovaps xmm2, [rsp+0x20]
00007f30a29dd35b  vmovaps xmm3, [rsp+0x30]
00007f30a29dd361  vmovaps xmm4, [rsp+0x40]
00007f30a29dd367  vmovaps xmm5, [rsp+0x50]
00007f30a29dd36d  vmovaps xmm6, [rsp+0x60]
00007f30a29dd373  vmovaps xmm7, [rsp+0x70]
00007f30a29dd379  vmovaps xmm8, [rsp+0x80]
00007f30a29dd382  vmovaps xmm9, [rsp+0x90]
00007f30a29dd38b  vmovaps xmm10, [rsp+0xA0]
00007f30a29dd394  vmovaps xmm11, [rsp+0xB0]
00007f30a29dd39d  vmovaps xmm12, [rsp+0xC0]
00007f30a29dd3a6  vmovaps xmm13, [rsp+0xD0]
00007f30a29dd3af  vmovaps xmm15, [rsp+0xE0]
00007f30a29dd3b8  add rsp, 0xF0
00007f30a29dd3bf  pop r11
00007f30a29dd3c1  pop r10
00007f30a29dd3c3  pop r9
00007f30a29dd3c5  pop r8
00007f30a29dd3c7  pop rsi
00007f30a29dd3c8  pop rdi
00007f30a29dd3c9  pop rdx
00007f30a29dd3ca  pop rcx
00007f30a29dd3cb  pop rax
00007f30a29dd3cc  add rsp, 0x08
00007f30a29dd3d0  jmp 0x00007F30A29D95E0
00007f30a29dd3d5  sub rsp, 0x08
00007f30a29dd3d9  push rax
00007f30a29dd3da  push rcx
00007f30a29dd3db  push rdx
00007f30a29dd3dc  push rdi
00007f30a29dd3dd  push rsi
00007f30a29dd3de  push r8
00007f30a29dd3e0  push r9
00007f30a29dd3e2  push r10
00007f30a29dd3e4  push r11
00007f30a29dd3e6  sub rsp, 0xF0
00007f30a29dd3ed  vmovaps [rsp], xmm0
00007f30a29dd3f2  vmovaps [rsp+0x10], xmm2
00007f30a29dd3f8  vmovaps [rsp+0x20], xmm3
00007f30a29dd3fe  vmovaps [rsp+0x30], xmm4
00007f30a29dd404  vmovaps [rsp+0x40], xmm5
00007f30a29dd40a  vmovaps [rsp+0x50], xmm6
00007f30a29dd410  vmovaps [rsp+0x60], xmm7
00007f30a29dd416  vmovaps [rsp+0x70], xmm8
00007f30a29dd41c  vmovaps [rsp+0x80], xmm9
00007f30a29dd425  vmovaps [rsp+0x90], xmm10
00007f30a29dd42e  vmovaps [rsp+0xA0], xmm11
00007f30a29dd437  vmovaps [rsp+0xB0], xmm12
00007f30a29dd440  vmovaps [rsp+0xC0], xmm13
00007f30a29dd449  vmovaps [rsp+0xD0], xmm14
00007f30a29dd452  vmovaps [rsp+0xE0], xmm15
00007f30a29dd45b  sub rsp, 0x30
00007f30a29dd45f  movaps [rsp], xmm1
00007f30a29dd463  movaps [rsp+0x10], xmm13
00007f30a29dd469  movaps [rsp+0x20], xmm9
00007f30a29dd46f  lea rdi, [rsp]
00007f30a29dd473  mov esi, 0x00
00007f30a29dd478  mov rax, 0x5FE955026530
00007f30a29dd482  call rax
00007f30a29dd484  movaps xmm1, [rsp]
00007f30a29dd488  add rsp, 0x30
00007f30a29dd48c  vmovaps xmm0, [rsp]
00007f30a29dd491  vmovaps xmm2, [rsp+0x10]
00007f30a29dd497  vmovaps xmm3, [rsp+0x20]
00007f30a29dd49d  vmovaps xmm4, [rsp+0x30]
00007f30a29dd4a3  vmovaps xmm5, [rsp+0x40]
00007f30a29dd4a9  vmovaps xmm6, [rsp+0x50]
00007f30a29dd4af  vmovaps xmm7, [rsp+0x60]
00007f30a29dd4b5  vmovaps xmm8, [rsp+0x70]
00007f30a29dd4bb  vmovaps xmm9, [rsp+0x80]
00007f30a29dd4c4  vmovaps xmm10, [rsp+0x90]
00007f30a29dd4cd  vmovaps xmm11, [rsp+0xA0]
00007f30a29dd4d6  vmovaps xmm12, [rsp+0xB0]
00007f30a29dd4df  vmovaps xmm13, [rsp+0xC0]
00007f30a29dd4e8  vmovaps xmm14, [rsp+0xD0]
00007f30a29dd4f1  vmovaps xmm15, [rsp+0xE0]
00007f30a29dd4fa  add rsp, 0xF0
00007f30a29dd501  pop r11
00007f30a29dd503  pop r10
00007f30a29dd505  pop r9
00007f30a29dd507  pop r8
00007f30a29dd509  pop rsi
00007f30a29dd50a  pop rdi
00007f30a29dd50b  pop rdx
00007f30a29dd50c  pop rcx
00007f30a29dd50d  pop rax
00007f30a29dd50e  add rsp, 0x08
00007f30a29dd512  jmp 0x00007F30A29D95FA
00007f30a29dd517  sub rsp, 0x08
00007f30a29dd51b  push rax
00007f30a29dd51c  push rcx
00007f30a29dd51d  push rdx
00007f30a29dd51e  push rdi
00007f30a29dd51f  push rsi
00007f30a29dd520  push r8
00007f30a29dd522  push r9
00007f30a29dd524  push r10
00007f30a29dd526  push r11
00007f30a29dd528  sub rsp, 0xF0
00007f30a29dd52f  vmovaps [rsp], xmm0
00007f30a29dd534  vmovaps [rsp+0x10], xmm1
00007f30a29dd53a  vmovaps [rsp+0x20], xmm2
00007f30a29dd540  vmovaps [rsp+0x30], xmm3
00007f30a29dd546  vmovaps [rsp+0x40], xmm4
00007f30a29dd54c  vmovaps [rsp+0x50], xmm5
00007f30a29dd552  vmovaps [rsp+0x60], xmm6
00007f30a29dd558  vmovaps [rsp+0x70], xmm7
00007f30a29dd55e  vmovaps [rsp+0x80], xmm8
00007f30a29dd567  vmovaps [rsp+0x90], xmm9
00007f30a29dd570  vmovaps [rsp+0xA0], xmm10
00007f30a29dd579  vmovaps [rsp+0xB0], xmm11
00007f30a29dd582  vmovaps [rsp+0xC0], xmm13
00007f30a29dd58b  vmovaps [rsp+0xD0], xmm14
00007f30a29dd594  vmovaps [rsp+0xE0], xmm15
00007f30a29dd59d  sub rsp, 0x30
00007f30a29dd5a1  movaps [rsp], xmm12
00007f30a29dd5a6  movaps [rsp+0x10], xmm7
00007f30a29dd5ab  movaps [rsp+0x20], xmm13
00007f30a29dd5b1  lea rdi, [rsp]
00007f30a29dd5b5  mov esi, 0x00
00007f30a29dd5ba  mov rax, 0x5FE955026530
00007f30a29dd5c4  call rax
00007f30a29dd5c6  movaps xmm12, [rsp]
00007f30a29dd5cb  add rsp, 0x30
00007f30a29dd5cf  vmovaps xmm0, [rsp]
00007f30a29dd5d4  vmovaps xmm1, [rsp+0x10]
00007f30a29dd5da  vmovaps xmm2, [rsp+0x20]
00007f30a29dd5e0  vmovaps xmm3, [rsp+0x30]
00007f30a29dd5e6  vmovaps xmm4, [rsp+0x40]
00007f30a29dd5ec  vmovaps xmm5, [rsp+0x50]
00007f30a29dd5f2  vmovaps xmm6, [rsp+0x60]
00007f30a29dd5f8  vmovaps xmm7, [rsp+0x70]
00007f30a29dd5fe  vmovaps xmm8, [rsp+0x80]
00007f30a29dd607  vmovaps xmm9, [rsp+0x90]
00007f30a29dd610  vmovaps xmm10, [rsp+0xA0]
00007f30a29dd619  vmovaps xmm11, [rsp+0xB0]
00007f30a29dd622  vmovaps xmm13, [rsp+0xC0]
00007f30a29dd62b  vmovaps xmm14, [rsp+0xD0]
00007f30a29dd634  vmovaps xmm15, [rsp+0xE0]
00007f30a29dd63d  add rsp, 0xF0
00007f30a29dd644  pop r11
00007f30a29dd646  pop r10
00007f30a29dd648  pop r9
00007f30a29dd64a  pop r8
00007f30a29dd64c  pop rsi
00007f30a29dd64d  pop rdi
00007f30a29dd64e  pop rdx
00007f30a29dd64f  pop rcx
00007f30a29dd650  pop rax
00007f30a29dd651  add rsp, 0x08
00007f30a29dd655  jmp 0x00007F30A29D9621
00007f30a29dd65a  sub rsp, 0x08
00007f30a29dd65e  push rax
00007f30a29dd65f  push rcx
00007f30a29dd660  push rdx
00007f30a29dd661  push rdi
00007f30a29dd662  push rsi
00007f30a29dd663  push r8
00007f30a29dd665  push r9
00007f30a29dd667  push r10
00007f30a29dd669  push r11
00007f30a29dd66b  sub rsp, 0xF0
00007f30a29dd672  vmovaps [rsp], xmm0
00007f30a29dd677  vmovaps [rsp+0x10], xmm1
00007f30a29dd67d  vmovaps [rsp+0x20], xmm2
00007f30a29dd683  vmovaps [rsp+0x30], xmm3
00007f30a29dd689  vmovaps [rsp+0x40], xmm4
00007f30a29dd68f  vmovaps [rsp+0x50], xmm5
00007f30a29dd695  vmovaps [rsp+0x60], xmm6
00007f30a29dd69b  vmovaps [rsp+0x70], xmm7
00007f30a29dd6a1  vmovaps [rsp+0x80], xmm8
00007f30a29dd6aa  vmovaps [rsp+0x90], xmm9
00007f30a29dd6b3  vmovaps [rsp+0xA0], xmm10
00007f30a29dd6bc  vmovaps [rsp+0xB0], xmm11
00007f30a29dd6c5  vmovaps [rsp+0xC0], xmm12
00007f30a29dd6ce  vmovaps [rsp+0xD0], xmm14
00007f30a29dd6d7  vmovaps [rsp+0xE0], xmm15
00007f30a29dd6e0  sub rsp, 0x30
00007f30a29dd6e4  movaps [rsp], xmm13
00007f30a29dd6e9  movaps [rsp+0x10], xmm15
00007f30a29dd6ef  movaps [rsp+0x20], xmm8
00007f30a29dd6f5  lea rdi, [rsp]
00007f30a29dd6f9  mov esi, 0x00
00007f30a29dd6fe  mov rax, 0x5FE955026530
00007f30a29dd708  call rax
00007f30a29dd70a  movaps xmm13, [rsp]
00007f30a29dd70f  add rsp, 0x30
00007f30a29dd713  vmovaps xmm0, [rsp]
00007f30a29dd718  vmovaps xmm1, [rsp+0x10]
00007f30a29dd71e  vmovaps xmm2, [rsp+0x20]
00007f30a29dd724  vmovaps xmm3, [rsp+0x30]
00007f30a29dd72a  vmovaps xmm4, [rsp+0x40]
00007f30a29dd730  vmovaps xmm5, [rsp+0x50]
00007f30a29dd736  vmovaps xmm6, [rsp+0x60]
00007f30a29dd73c  vmovaps xmm7, [rsp+0x70]
00007f30a29dd742  vmovaps xmm8, [rsp+0x80]
00007f30a29dd74b  vmovaps xmm9, [rsp+0x90]
00007f30a29dd754  vmovaps xmm10, [rsp+0xA0]
00007f30a29dd75d  vmovaps xmm11, [rsp+0xB0]
00007f30a29dd766  vmovaps xmm12, [rsp+0xC0]
00007f30a29dd76f  vmovaps xmm14, [rsp+0xD0]
00007f30a29dd778  vmovaps xmm15, [rsp+0xE0]
00007f30a29dd781  add rsp, 0xF0
00007f30a29dd788  pop r11
00007f30a29dd78a  pop r10
00007f30a29dd78c  pop r9
00007f30a29dd78e  pop r8
00007f30a29dd790  pop rsi
00007f30a29dd791  pop rdi
00007f30a29dd792  pop rdx
00007f30a29dd793  pop rcx
00007f30a29dd794  pop rax
00007f30a29dd795  add rsp, 0x08
00007f30a29dd799  jmp 0x00007F30A29D963C
00007f30a29dd79e  sub rsp, 0x08
00007f30a29dd7a2  push rax
00007f30a29dd7a3  push rcx
00007f30a29dd7a4  push rdx
00007f30a29dd7a5  push rdi
00007f30a29dd7a6  push rsi
00007f30a29dd7a7  push r8
00007f30a29dd7a9  push r9
00007f30a29dd7ab  push r10
00007f30a29dd7ad  push r11
00007f30a29dd7af  sub rsp, 0xF0
00007f30a29dd7b6  vmovaps [rsp], xmm0
00007f30a29dd7bb  vmovaps [rsp+0x10], xmm1
00007f30a29dd7c1  vmovaps [rsp+0x20], xmm2
00007f30a29dd7c7  vmovaps [rsp+0x30], xmm3
00007f30a29dd7cd  vmovaps [rsp+0x40], xmm4
00007f30a29dd7d3  vmovaps [rsp+0x50], xmm5
00007f30a29dd7d9  vmovaps [rsp+0x60], xmm6
00007f30a29dd7df  vmovaps [rsp+0x70], xmm7
00007f30a29dd7e5  vmovaps [rsp+0x80], xmm9
00007f30a29dd7ee  vmovaps [rsp+0x90], xmm10
00007f30a29dd7f7  vmovaps [rsp+0xA0], xmm11
00007f30a29dd800  vmovaps [rsp+0xB0], xmm12
00007f30a29dd809  vmovaps [rsp+0xC0], xmm13
00007f30a29dd812  vmovaps [rsp+0xD0], xmm14
00007f30a29dd81b  vmovaps [rsp+0xE0], xmm15
00007f30a29dd824  sub rsp, 0x30
00007f30a29dd828  movaps [rsp], xmm8
00007f30a29dd82d  movaps [rsp+0x10], xmm15
00007f30a29dd833  movaps [rsp+0x20], xmm9
00007f30a29dd839  lea rdi, [rsp]
00007f30a29dd83d  mov esi, 0x00
00007f30a29dd842  mov rax, 0x5FE955026530
00007f30a29dd84c  call rax
00007f30a29dd84e  movaps xmm8, [rsp]
00007f30a29dd853  add rsp, 0x30
00007f30a29dd857  vmovaps xmm0, [rsp]
00007f30a29dd85c  vmovaps xmm1, [rsp+0x10]
00007f30a29dd862  vmovaps xmm2, [rsp+0x20]
00007f30a29dd868  vmovaps xmm3, [rsp+0x30]
00007f30a29dd86e  vmovaps xmm4, [rsp+0x40]
00007f30a29dd874  vmovaps xmm5, [rsp+0x50]
00007f30a29dd87a  vmovaps xmm6, [rsp+0x60]
00007f30a29dd880  vmovaps xmm7, [rsp+0x70]
00007f30a29dd886  vmovaps xmm9, [rsp+0x80]
00007f30a29dd88f  vmovaps xmm10, [rsp+0x90]
00007f30a29dd898  vmovaps xmm11, [rsp+0xA0]
00007f30a29dd8a1  vmovaps xmm12, [rsp+0xB0]
00007f30a29dd8aa  vmovaps xmm13, [rsp+0xC0]
00007f30a29dd8b3  vmovaps xmm14, [rsp+0xD0]
00007f30a29dd8bc  vmovaps xmm15, [rsp+0xE0]
00007f30a29dd8c5  add rsp, 0xF0
00007f30a29dd8cc  pop r11
00007f30a29dd8ce  pop r10
00007f30a29dd8d0  pop r9
00007f30a29dd8d2  pop r8
00007f30a29dd8d4  pop rsi
00007f30a29dd8d5  pop rdi
00007f30a29dd8d6  pop rdx
00007f30a29dd8d7  pop rcx
00007f30a29dd8d8  pop rax
00007f30a29dd8d9  add rsp, 0x08
00007f30a29dd8dd  jmp 0x00007F30A29D966A
00007f30a29dd8e2  sub rsp, 0x08
00007f30a29dd8e6  push rax
00007f30a29dd8e7  push rcx
00007f30a29dd8e8  push rdx
00007f30a29dd8e9  push rdi
00007f30a29dd8ea  push rsi
00007f30a29dd8eb  push r8
00007f30a29dd8ed  push r9
00007f30a29dd8ef  push r10
00007f30a29dd8f1  push r11
00007f30a29dd8f3  sub rsp, 0xF0
00007f30a29dd8fa  vmovaps [rsp], xmm0
00007f30a29dd8ff  vmovaps [rsp+0x10], xmm1
00007f30a29dd905  vmovaps [rsp+0x20], xmm2
00007f30a29dd90b  vmovaps [rsp+0x30], xmm3
00007f30a29dd911  vmovaps [rsp+0x40], xmm4
00007f30a29dd917  vmovaps [rsp+0x50], xmm5
00007f30a29dd91d  vmovaps [rsp+0x60], xmm6
00007f30a29dd923  vmovaps [rsp+0x70], xmm7
00007f30a29dd929  vmovaps [rsp+0x80], xmm8
00007f30a29dd932  vmovaps [rsp+0x90], xmm9
00007f30a29dd93b  vmovaps [rsp+0xA0], xmm10
00007f30a29dd944  vmovaps [rsp+0xB0], xmm11
00007f30a29dd94d  vmovaps [rsp+0xC0], xmm12
00007f30a29dd956  vmovaps [rsp+0xD0], xmm13
00007f30a29dd95f  vmovaps [rsp+0xE0], xmm14
00007f30a29dd968  sub rsp, 0x30
00007f30a29dd96c  movaps [rsp], xmm15
00007f30a29dd971  movaps [rsp+0x10], xmm11
00007f30a29dd977  movaps [rsp+0x20], xmm6
00007f30a29dd97c  lea rdi, [rsp]
00007f30a29dd980  mov esi, 0x00
00007f30a29dd985  mov rax, 0x5FE955026530
00007f30a29dd98f  call rax
00007f30a29dd991  movaps xmm15, [rsp]
00007f30a29dd996  add rsp, 0x30
00007f30a29dd99a  vmovaps xmm0, [rsp]
00007f30a29dd99f  vmovaps xmm1, [rsp+0x10]
00007f30a29dd9a5  vmovaps xmm2, [rsp+0x20]
00007f30a29dd9ab  vmovaps xmm3, [rsp+0x30]
00007f30a29dd9b1  vmovaps xmm4, [rsp+0x40]
00007f30a29dd9b7  vmovaps xmm5, [rsp+0x50]
00007f30a29dd9bd  vmovaps xmm6, [rsp+0x60]
00007f30a29dd9c3  vmovaps xmm7, [rsp+0x70]
00007f30a29dd9c9  vmovaps xmm8, [rsp+0x80]
00007f30a29dd9d2  vmovaps xmm9, [rsp+0x90]
00007f30a29dd9db  vmovaps xmm10, [rsp+0xA0]
00007f30a29dd9e4  vmovaps xmm11, [rsp+0xB0]
00007f30a29dd9ed  vmovaps xmm12, [rsp+0xC0]
00007f30a29dd9f6  vmovaps xmm13, [rsp+0xD0]
00007f30a29dd9ff  vmovaps xmm14, [rsp+0xE0]
00007f30a29dda08  add rsp, 0xF0
00007f30a29dda0f  pop r11
00007f30a29dda11  pop r10
00007f30a29dda13  pop r9
00007f30a29dda15  pop r8
00007f30a29dda17  pop rsi
00007f30a29dda18  pop rdi
00007f30a29dda19  pop rdx
00007f30a29dda1a  pop rcx
00007f30a29dda1b  pop rax
00007f30a29dda1c  add rsp, 0x08
00007f30a29dda20  jmp 0x00007F30A29D9685
00007f30a29dda25  sub rsp, 0x08
00007f30a29dda29  push rax
00007f30a29dda2a  push rcx
00007f30a29dda2b  push rdx
00007f30a29dda2c  push rdi
00007f30a29dda2d  push rsi
00007f30a29dda2e  push r8
00007f30a29dda30  push r9
00007f30a29dda32  push r10
00007f30a29dda34  push r11
00007f30a29dda36  sub rsp, 0xF0
00007f30a29dda3d  vmovaps [rsp], xmm0
00007f30a29dda42  vmovaps [rsp+0x10], xmm1
00007f30a29dda48  vmovaps [rsp+0x20], xmm2
00007f30a29dda4e  vmovaps [rsp+0x30], xmm3
00007f30a29dda54  vmovaps [rsp+0x40], xmm4
00007f30a29dda5a  vmovaps [rsp+0x50], xmm5
00007f30a29dda60  vmovaps [rsp+0x60], xmm6
00007f30a29dda66  vmovaps [rsp+0x70], xmm8
00007f30a29dda6c  vmovaps [rsp+0x80], xmm9
00007f30a29dda75  vmovaps [rsp+0x90], xmm10
00007f30a29dda7e  vmovaps [rsp+0xA0], xmm11
00007f30a29dda87  vmovaps [rsp+0xB0], xmm12
00007f30a29dda90  vmovaps [rsp+0xC0], xmm13
00007f30a29dda99  vmovaps [rsp+0xD0], xmm14
00007f30a29ddaa2  vmovaps [rsp+0xE0], xmm15
00007f30a29ddaab  sub rsp, 0x30
00007f30a29ddaaf  movaps [rsp], xmm7
00007f30a29ddab3  movaps [rsp+0x10], xmm11
00007f30a29ddab9  movaps [rsp+0x20], xmm9
00007f30a29ddabf  lea rdi, [rsp]
00007f30a29ddac3  mov esi, 0x00
00007f30a29ddac8  mov rax, 0x5FE955026530
00007f30a29ddad2  call rax
00007f30a29ddad4  movaps xmm7, [rsp]
00007f30a29ddad8  add rsp, 0x30
00007f30a29ddadc  vmovaps xmm0, [rsp]
00007f30a29ddae1  vmovaps xmm1, [rsp+0x10]
00007f30a29ddae7  vmovaps xmm2, [rsp+0x20]
00007f30a29ddaed  vmovaps xmm3, [rsp+0x30]
00007f30a29ddaf3  vmovaps xmm4, [rsp+0x40]
00007f30a29ddaf9  vmovaps xmm5, [rsp+0x50]
00007f30a29ddaff  vmovaps xmm6, [rsp+0x60]
00007f30a29ddb05  vmovaps xmm8, [rsp+0x70]
00007f30a29ddb0b  vmovaps xmm9, [rsp+0x80]
00007f30a29ddb14  vmovaps xmm10, [rsp+0x90]
00007f30a29ddb1d  vmovaps xmm11, [rsp+0xA0]
00007f30a29ddb26  vmovaps xmm12, [rsp+0xB0]
00007f30a29ddb2f  vmovaps xmm13, [rsp+0xC0]
00007f30a29ddb38  vmovaps xmm14, [rsp+0xD0]
00007f30a29ddb41  vmovaps xmm15, [rsp+0xE0]
00007f30a29ddb4a  add rsp, 0xF0
00007f30a29ddb51  pop r11
00007f30a29ddb53  pop r10
00007f30a29ddb55  pop r9
00007f30a29ddb57  pop r8
00007f30a29ddb59  pop rsi
00007f30a29ddb5a  pop rdi
00007f30a29ddb5b  pop rdx
00007f30a29ddb5c  pop rcx
00007f30a29ddb5d  pop rax
00007f30a29ddb5e  add rsp, 0x08
00007f30a29ddb62  jmp 0x00007F30A29D96B2
00007f30a29ddb67  sub rsp, 0x08
00007f30a29ddb6b  push rax
00007f30a29ddb6c  push rcx
00007f30a29ddb6d  push rdx
00007f30a29ddb6e  push rdi
00007f30a29ddb6f  push rsi
00007f30a29ddb70  push r8
00007f30a29ddb72  push r9
00007f30a29ddb74  push r10
00007f30a29ddb76  push r11
00007f30a29ddb78  sub rsp, 0xF0
00007f30a29ddb7f  vmovaps [rsp], xmm0
00007f30a29ddb84  vmovaps [rsp+0x10], xmm1
00007f30a29ddb8a  vmovaps [rsp+0x20], xmm2
00007f30a29ddb90  vmovaps [rsp+0x30], xmm3
00007f30a29ddb96  vmovaps [rsp+0x40], xmm4
00007f30a29ddb9c  vmovaps [rsp+0x50], xmm5
00007f30a29ddba2  vmovaps [rsp+0x60], xmm6
00007f30a29ddba8  vmovaps [rsp+0x70], xmm7
00007f30a29ddbae  vmovaps [rsp+0x80], xmm8
00007f30a29ddbb7  vmovaps [rsp+0x90], xmm9
00007f30a29ddbc0  vmovaps [rsp+0xA0], xmm10
00007f30a29ddbc9  vmovaps [rsp+0xB0], xmm12
00007f30a29ddbd2  vmovaps [rsp+0xC0], xmm13
00007f30a29ddbdb  vmovaps [rsp+0xD0], xmm14
00007f30a29ddbe4  vmovaps [rsp+0xE0], xmm15
00007f30a29ddbed  sub rsp, 0x30
00007f30a29ddbf1  movaps [rsp], xmm11
00007f30a29ddbf6  movaps [rsp+0x10], xmm10
00007f30a29ddbfc  movaps [rsp+0x20], xmm14
00007f30a29ddc02  lea rdi, [rsp]
00007f30a29ddc06  mov esi, 0x00
00007f30a29ddc0b  mov rax, 0x5FE955026530
00007f30a29ddc15  call rax
00007f30a29ddc17  movaps xmm11, [rsp]
00007f30a29ddc1c  add rsp, 0x30
00007f30a29ddc20  vmovaps xmm0, [rsp]
00007f30a29ddc25  vmovaps xmm1, [rsp+0x10]
00007f30a29ddc2b  vmovaps xmm2, [rsp+0x20]
00007f30a29ddc31  vmovaps xmm3, [rsp+0x30]
00007f30a29ddc37  vmovaps xmm4, [rsp+0x40]
00007f30a29ddc3d  vmovaps xmm5, [rsp+0x50]
00007f30a29ddc43  vmovaps xmm6, [rsp+0x60]
00007f30a29ddc49  vmovaps xmm7, [rsp+0x70]
00007f30a29ddc4f  vmovaps xmm8, [rsp+0x80]
00007f30a29ddc58  vmovaps xmm9, [rsp+0x90]
00007f30a29ddc61  vmovaps xmm10, [rsp+0xA0]
00007f30a29ddc6a  vmovaps xmm12, [rsp+0xB0]
00007f30a29ddc73  vmovaps xmm13, [rsp+0xC0]
00007f30a29ddc7c  vmovaps xmm14, [rsp+0xD0]
00007f30a29ddc85  vmovaps xmm15, [rsp+0xE0]
00007f30a29ddc8e  add rsp, 0xF0
00007f30a29ddc95  pop r11
00007f30a29ddc97  pop r10
00007f30a29ddc99  pop r9
00007f30a29ddc9b  pop r8
00007f30a29ddc9d  pop rsi
00007f30a29ddc9e  pop rdi
00007f30a29ddc9f  pop rdx
00007f30a29ddca0  pop rcx
00007f30a29ddca1  pop rax
00007f30a29ddca2  add rsp, 0x08
00007f30a29ddca6  jmp 0x00007F30A29D96CD
00007f30a29ddcab  call 0x00007F30A28E45A0
00007f30a29ddcb0  jmp 0x00007F30A29D96D7
00007f30a29ddcb5  sub rsp, 0x08
00007f30a29ddcb9  push rax
00007f30a29ddcba  push rcx
00007f30a29ddcbb  push rdx
00007f30a29ddcbc  push rdi
00007f30a29ddcbd  push rsi
00007f30a29ddcbe  push r8
00007f30a29ddcc0  push r9
00007f30a29ddcc2  push r10
00007f30a29ddcc4  push r11
00007f30a29ddcc6  sub rsp, 0xF0
00007f30a29ddccd  vmovaps [rsp], xmm0
00007f30a29ddcd2  vmovaps [rsp+0x10], xmm1
00007f30a29ddcd8  vmovaps [rsp+0x20], xmm2
00007f30a29ddcde  vmovaps [rsp+0x30], xmm3
00007f30a29ddce4  vmovaps [rsp+0x40], xmm4
00007f30a29ddcea  vmovaps [rsp+0x50], xmm5
00007f30a29ddcf0  vmovaps [rsp+0x60], xmm6
00007f30a29ddcf6  vmovaps [rsp+0x70], xmm7
00007f30a29ddcfc  vmovaps [rsp+0x80], xmm8
00007f30a29ddd05  vmovaps [rsp+0x90], xmm9
00007f30a29ddd0e  vmovaps [rsp+0xA0], xmm11
00007f30a29ddd17  vmovaps [rsp+0xB0], xmm12
00007f30a29ddd20  vmovaps [rsp+0xC0], xmm13
00007f30a29ddd29  vmovaps [rsp+0xD0], xmm14
00007f30a29ddd32  vmovaps [rsp+0xE0], xmm15
00007f30a29ddd3b  sub rsp, 0x30
00007f30a29ddd3f  movaps [rsp], xmm10
00007f30a29ddd44  movaps [rsp+0x10], xmm1
00007f30a29ddd49  movaps [rsp+0x20], xmm12
00007f30a29ddd4f  lea rdi, [rsp]
00007f30a29ddd53  mov esi, 0x00
00007f30a29ddd58  mov rax, 0x5FE955026530
00007f30a29ddd62  call rax
00007f30a29ddd64  movaps xmm10, [rsp]
00007f30a29ddd69  add rsp, 0x30
00007f30a29ddd6d  vmovaps xmm0, [rsp]
00007f30a29ddd72  vmovaps xmm1, [rsp+0x10]
00007f30a29ddd78  vmovaps xmm2, [rsp+0x20]
00007f30a29ddd7e  vmovaps xmm3, [rsp+0x30]
00007f30a29ddd84  vmovaps xmm4, [rsp+0x40]
00007f30a29ddd8a  vmovaps xmm5, [rsp+0x50]
00007f30a29ddd90  vmovaps xmm6, [rsp+0x60]
00007f30a29ddd96  vmovaps xmm7, [rsp+0x70]
00007f30a29ddd9c  vmovaps xmm8, [rsp+0x80]
00007f30a29ddda5  vmovaps xmm9, [rsp+0x90]
00007f30a29dddae  vmovaps xmm11, [rsp+0xA0]
00007f30a29dddb7  vmovaps xmm12, [rsp+0xB0]
00007f30a29dddc0  vmovaps xmm13, [rsp+0xC0]
00007f30a29dddc9  vmovaps xmm14, [rsp+0xD0]
00007f30a29dddd2  vmovaps xmm15, [rsp+0xE0]
00007f30a29ddddb  add rsp, 0xF0
00007f30a29ddde2  pop r11
00007f30a29ddde4  pop r10
00007f30a29ddde6  pop r9
00007f30a29ddde8  pop r8
00007f30a29dddea  pop rsi
00007f30a29dddeb  pop rdi
00007f30a29dddec  pop rdx
00007f30a29ddded  pop rcx
00007f30a29dddee  pop rax
00007f30a29dddef  add rsp, 0x08
00007f30a29dddf3  jmp 0x00007F30A29D96FA
00007f30a29dddf8  sub rsp, 0x08
00007f30a29dddfc  push rax
00007f30a29dddfd  push rcx
00007f30a29dddfe  push rdx
00007f30a29dddff  push rdi
00007f30a29dde00  push rsi
00007f30a29dde01  push r8
00007f30a29dde03  push r9
00007f30a29dde05  push r10
00007f30a29dde07  push r11
00007f30a29dde09  sub rsp, 0xF0
00007f30a29dde10  vmovaps [rsp], xmm0
00007f30a29dde15  vmovaps [rsp+0x10], xmm1
00007f30a29dde1b  vmovaps [rsp+0x20], xmm2
00007f30a29dde21  vmovaps [rsp+0x30], xmm3
00007f30a29dde27  vmovaps [rsp+0x40], xmm4
00007f30a29dde2d  vmovaps [rsp+0x50], xmm5
00007f30a29dde33  vmovaps [rsp+0x60], xmm6
00007f30a29dde39  vmovaps [rsp+0x70], xmm7
00007f30a29dde3f  vmovaps [rsp+0x80], xmm8
00007f30a29dde48  vmovaps [rsp+0x90], xmm9
00007f30a29dde51  vmovaps [rsp+0xA0], xmm10
00007f30a29dde5a  vmovaps [rsp+0xB0], xmm11
00007f30a29dde63  vmovaps [rsp+0xC0], xmm13
00007f30a29dde6c  vmovaps [rsp+0xD0], xmm14
00007f30a29dde75  vmovaps [rsp+0xE0], xmm15
00007f30a29dde7e  sub rsp, 0x30
00007f30a29dde82  movaps [rsp], xmm12
00007f30a29dde87  movaps [rsp+0x10], xmm14
00007f30a29dde8d  movaps [rsp+0x20], xmm1
00007f30a29dde92  lea rdi, [rsp]
00007f30a29dde96  mov esi, 0x00
00007f30a29dde9b  mov rax, 0x5FE955026530
00007f30a29ddea5  call rax
00007f30a29ddea7  movaps xmm12, [rsp]
00007f30a29ddeac  add rsp, 0x30
00007f30a29ddeb0  vmovaps xmm0, [rsp]
00007f30a29ddeb5  vmovaps xmm1, [rsp+0x10]
00007f30a29ddebb  vmovaps xmm2, [rsp+0x20]
00007f30a29ddec1  vmovaps xmm3, [rsp+0x30]
00007f30a29ddec7  vmovaps xmm4, [rsp+0x40]
00007f30a29ddecd  vmovaps xmm5, [rsp+0x50]
00007f30a29dded3  vmovaps xmm6, [rsp+0x60]
00007f30a29dded9  vmovaps xmm7, [rsp+0x70]
00007f30a29ddedf  vmovaps xmm8, [rsp+0x80]
00007f30a29ddee8  vmovaps xmm9, [rsp+0x90]
00007f30a29ddef1  vmovaps xmm10, [rsp+0xA0]
00007f30a29ddefa  vmovaps xmm11, [rsp+0xB0]
00007f30a29ddf03  vmovaps xmm13, [rsp+0xC0]
00007f30a29ddf0c  vmovaps xmm14, [rsp+0xD0]
00007f30a29ddf15  vmovaps xmm15, [rsp+0xE0]
00007f30a29ddf1e  add rsp, 0xF0
00007f30a29ddf25  pop r11
00007f30a29ddf27  pop r10
00007f30a29ddf29  pop r9
00007f30a29ddf2b  pop r8
00007f30a29ddf2d  pop rsi
00007f30a29ddf2e  pop rdi
00007f30a29ddf2f  pop rdx
00007f30a29ddf30  pop rcx
00007f30a29ddf31  pop rax
00007f30a29ddf32  add rsp, 0x08
00007f30a29ddf36  jmp 0x00007F30A29D9729
00007f30a29ddf3b  sub rsp, 0x08
00007f30a29ddf3f  push rax
00007f30a29ddf40  push rcx
00007f30a29ddf41  push rdx
00007f30a29ddf42  push rdi
00007f30a29ddf43  push rsi
00007f30a29ddf44  push r8
00007f30a29ddf46  push r9
00007f30a29ddf48  push r10
00007f30a29ddf4a  push r11
00007f30a29ddf4c  sub rsp, 0xF0
00007f30a29ddf53  vmovaps [rsp], xmm0
00007f30a29ddf58  vmovaps [rsp+0x10], xmm1
00007f30a29ddf5e  vmovaps [rsp+0x20], xmm2
00007f30a29ddf64  vmovaps [rsp+0x30], xmm3
00007f30a29ddf6a  vmovaps [rsp+0x40], xmm4
00007f30a29ddf70  vmovaps [rsp+0x50], xmm5
00007f30a29ddf76  vmovaps [rsp+0x60], xmm6
00007f30a29ddf7c  vmovaps [rsp+0x70], xmm7
00007f30a29ddf82  vmovaps [rsp+0x80], xmm8
00007f30a29ddf8b  vmovaps [rsp+0x90], xmm9
00007f30a29ddf94  vmovaps [rsp+0xA0], xmm10
00007f30a29ddf9d  vmovaps [rsp+0xB0], xmm11
00007f30a29ddfa6  vmovaps [rsp+0xC0], xmm12
00007f30a29ddfaf  vmovaps [rsp+0xD0], xmm13
00007f30a29ddfb8  vmovaps [rsp+0xE0], xmm15
00007f30a29ddfc1  sub rsp, 0x30
00007f30a29ddfc5  movaps [rsp], xmm14
00007f30a29ddfca  movaps [rsp+0x10], xmm9
00007f30a29ddfd0  movaps [rsp+0x20], xmm1
00007f30a29ddfd5  lea rdi, [rsp]
00007f30a29ddfd9  mov esi, 0x00
00007f30a29ddfde  mov rax, 0x5FE955026530
00007f30a29ddfe8  call rax
00007f30a29ddfea  movaps xmm14, [rsp]
00007f30a29ddfef  add rsp, 0x30
00007f30a29ddff3  vmovaps xmm0, [rsp]
00007f30a29ddff8  vmovaps xmm1, [rsp+0x10]
00007f30a29ddffe  vmovaps xmm2, [rsp+0x20]
00007f30a29de004  vmovaps xmm3, [rsp+0x30]
00007f30a29de00a  vmovaps xmm4, [rsp+0x40]
00007f30a29de010  vmovaps xmm5, [rsp+0x50]
00007f30a29de016  vmovaps xmm6, [rsp+0x60]
00007f30a29de01c  vmovaps xmm7, [rsp+0x70]
00007f30a29de022  vmovaps xmm8, [rsp+0x80]
00007f30a29de02b  vmovaps xmm9, [rsp+0x90]
00007f30a29de034  vmovaps xmm10, [rsp+0xA0]
00007f30a29de03d  vmovaps xmm11, [rsp+0xB0]
00007f30a29de046  vmovaps xmm12, [rsp+0xC0]
00007f30a29de04f  vmovaps xmm13, [rsp+0xD0]
00007f30a29de058  vmovaps xmm15, [rsp+0xE0]
00007f30a29de061  add rsp, 0xF0
00007f30a29de068  pop r11
00007f30a29de06a  pop r10
00007f30a29de06c  pop r9
00007f30a29de06e  pop r8
00007f30a29de070  pop rsi
00007f30a29de071  pop rdi
00007f30a29de072  pop rdx
00007f30a29de073  pop rcx
00007f30a29de074  pop rax
00007f30a29de075  add rsp, 0x08
00007f30a29de079  jmp 0x00007F30A29D9758
00007f30a29de07e  sub rsp, 0x08
00007f30a29de082  push rax
00007f30a29de083  push rcx
00007f30a29de084  push rdx
00007f30a29de085  push rdi
00007f30a29de086  push rsi
00007f30a29de087  push r8
00007f30a29de089  push r9
00007f30a29de08b  push r10
00007f30a29de08d  push r11
00007f30a29de08f  sub rsp, 0xF0
00007f30a29de096  vmovaps [rsp], xmm0
00007f30a29de09b  vmovaps [rsp+0x10], xmm2
00007f30a29de0a1  vmovaps [rsp+0x20], xmm3
00007f30a29de0a7  vmovaps [rsp+0x30], xmm4
00007f30a29de0ad  vmovaps [rsp+0x40], xmm5
00007f30a29de0b3  vmovaps [rsp+0x50], xmm6
00007f30a29de0b9  vmovaps [rsp+0x60], xmm7
00007f30a29de0bf  vmovaps [rsp+0x70], xmm8
00007f30a29de0c5  vmovaps [rsp+0x80], xmm9
00007f30a29de0ce  vmovaps [rsp+0x90], xmm10
00007f30a29de0d7  vmovaps [rsp+0xA0], xmm11
00007f30a29de0e0  vmovaps [rsp+0xB0], xmm12
00007f30a29de0e9  vmovaps [rsp+0xC0], xmm13
00007f30a29de0f2  vmovaps [rsp+0xD0], xmm14
00007f30a29de0fb  vmovaps [rsp+0xE0], xmm15
00007f30a29de104  sub rsp, 0x30
00007f30a29de108  movaps [rsp], xmm1
00007f30a29de10c  movaps [rsp+0x10], xmm13
00007f30a29de112  movaps [rsp+0x20], xmm8
00007f30a29de118  lea rdi, [rsp]
00007f30a29de11c  mov esi, 0x00
00007f30a29de121  mov rax, 0x5FE955026530
00007f30a29de12b  call rax
00007f30a29de12d  movaps xmm1, [rsp]
00007f30a29de131  add rsp, 0x30
00007f30a29de135  vmovaps xmm0, [rsp]
00007f30a29de13a  vmovaps xmm2, [rsp+0x10]
00007f30a29de140  vmovaps xmm3, [rsp+0x20]
00007f30a29de146  vmovaps xmm4, [rsp+0x30]
00007f30a29de14c  vmovaps xmm5, [rsp+0x40]
00007f30a29de152  vmovaps xmm6, [rsp+0x50]
00007f30a29de158  vmovaps xmm7, [rsp+0x60]
00007f30a29de15e  vmovaps xmm8, [rsp+0x70]
00007f30a29de164  vmovaps xmm9, [rsp+0x80]
00007f30a29de16d  vmovaps xmm10, [rsp+0x90]
00007f30a29de176  vmovaps xmm11, [rsp+0xA0]
00007f30a29de17f  vmovaps xmm12, [rsp+0xB0]
00007f30a29de188  vmovaps xmm13, [rsp+0xC0]
00007f30a29de191  vmovaps xmm14, [rsp+0xD0]
00007f30a29de19a  vmovaps xmm15, [rsp+0xE0]
00007f30a29de1a3  add rsp, 0xF0
00007f30a29de1aa  pop r11
00007f30a29de1ac  pop r10
00007f30a29de1ae  pop r9
00007f30a29de1b0  pop r8
00007f30a29de1b2  pop rsi
00007f30a29de1b3  pop rdi
00007f30a29de1b4  pop rdx
00007f30a29de1b5  pop rcx
00007f30a29de1b6  pop rax
00007f30a29de1b7  add rsp, 0x08
00007f30a29de1bb  jmp 0x00007F30A29D977A
00007f30a29de1c0  call 0x00007F30A280C260
00007f30a29de1c5  jmp 0x00007F30A29D9788
00007f30a29de1ca  call 0x00007F30A28DE950
00007f30a29de1cf  jmp 0x00007F30A29D9792
00007f30a29de1d4  sub rsp, 0x08
00007f30a29de1d8  push rax
00007f30a29de1d9  push rcx
00007f30a29de1da  push rdx
00007f30a29de1db  push rdi
00007f30a29de1dc  push rsi
00007f30a29de1dd  push r8
00007f30a29de1df  push r9
00007f30a29de1e1  push r10
00007f30a29de1e3  push r11
00007f30a29de1e5  sub rsp, 0xF0
00007f30a29de1ec  vmovaps [rsp], xmm0
00007f30a29de1f1  vmovaps [rsp+0x10], xmm1
00007f30a29de1f7  vmovaps [rsp+0x20], xmm2
00007f30a29de1fd  vmovaps [rsp+0x30], xmm3
00007f30a29de203  vmovaps [rsp+0x40], xmm4
00007f30a29de209  vmovaps [rsp+0x50], xmm5
00007f30a29de20f  vmovaps [rsp+0x60], xmm6
00007f30a29de215  vmovaps [rsp+0x70], xmm7
00007f30a29de21b  vmovaps [rsp+0x80], xmm9
00007f30a29de224  vmovaps [rsp+0x90], xmm10
00007f30a29de22d  vmovaps [rsp+0xA0], xmm11
00007f30a29de236  vmovaps [rsp+0xB0], xmm12
00007f30a29de23f  vmovaps [rsp+0xC0], xmm13
00007f30a29de248  vmovaps [rsp+0xD0], xmm14
00007f30a29de251  vmovaps [rsp+0xE0], xmm15
00007f30a29de25a  sub rsp, 0x30
00007f30a29de25e  movaps [rsp], xmm8
00007f30a29de263  movaps [rsp+0x10], xmm15
00007f30a29de269  movaps [rsp+0x20], xmm7
00007f30a29de26e  lea rdi, [rsp]
00007f30a29de272  mov esi, 0x00
00007f30a29de277  mov rax, 0x5FE955026530
00007f30a29de281  call rax
00007f30a29de283  movaps xmm8, [rsp]
00007f30a29de288  add rsp, 0x30
00007f30a29de28c  vmovaps xmm0, [rsp]
00007f30a29de291  vmovaps xmm1, [rsp+0x10]
00007f30a29de297  vmovaps xmm2, [rsp+0x20]
00007f30a29de29d  vmovaps xmm3, [rsp+0x30]
00007f30a29de2a3  vmovaps xmm4, [rsp+0x40]
00007f30a29de2a9  vmovaps xmm5, [rsp+0x50]
00007f30a29de2af  vmovaps xmm6, [rsp+0x60]
00007f30a29de2b5  vmovaps xmm7, [rsp+0x70]
00007f30a29de2bb  vmovaps xmm9, [rsp+0x80]
00007f30a29de2c4  vmovaps xmm10, [rsp+0x90]
00007f30a29de2cd  vmovaps xmm11, [rsp+0xA0]
00007f30a29de2d6  vmovaps xmm12, [rsp+0xB0]
00007f30a29de2df  vmovaps xmm13, [rsp+0xC0]
00007f30a29de2e8  vmovaps xmm14, [rsp+0xD0]
00007f30a29de2f1  vmovaps xmm15, [rsp+0xE0]
00007f30a29de2fa  add rsp, 0xF0
00007f30a29de301  pop r11
00007f30a29de303  pop r10
00007f30a29de305  pop r9
00007f30a29de307  pop r8
00007f30a29de309  pop rsi
00007f30a29de30a  pop rdi
00007f30a29de30b  pop rdx
00007f30a29de30c  pop rcx
00007f30a29de30d  pop rax
00007f30a29de30e  add rsp, 0x08
00007f30a29de312  jmp 0x00007F30A29D97B4
00007f30a29de317  sub rsp, 0x08
00007f30a29de31b  push rax
00007f30a29de31c  push rcx
00007f30a29de31d  push rdx
00007f30a29de31e  push rdi
00007f30a29de31f  push rsi
00007f30a29de320  push r8
00007f30a29de322  push r9
00007f30a29de324  push r10
00007f30a29de326  push r11
00007f30a29de328  sub rsp, 0xF0
00007f30a29de32f  vmovaps [rsp], xmm0
00007f30a29de334  vmovaps [rsp+0x10], xmm1
00007f30a29de33a  vmovaps [rsp+0x20], xmm2
00007f30a29de340  vmovaps [rsp+0x30], xmm3
00007f30a29de346  vmovaps [rsp+0x40], xmm4
00007f30a29de34c  vmovaps [rsp+0x50], xmm5
00007f30a29de352  vmovaps [rsp+0x60], xmm6
00007f30a29de358  vmovaps [rsp+0x70], xmm8
00007f30a29de35e  vmovaps [rsp+0x80], xmm9
00007f30a29de367  vmovaps [rsp+0x90], xmm10
00007f30a29de370  vmovaps [rsp+0xA0], xmm11
00007f30a29de379  vmovaps [rsp+0xB0], xmm12
00007f30a29de382  vmovaps [rsp+0xC0], xmm13
00007f30a29de38b  vmovaps [rsp+0xD0], xmm14
00007f30a29de394  vmovaps [rsp+0xE0], xmm15
00007f30a29de39d  sub rsp, 0x30
00007f30a29de3a1  movaps [rsp], xmm7
00007f30a29de3a5  movaps [rsp+0x10], xmm9
00007f30a29de3ab  movaps [rsp+0x20], xmm15
00007f30a29de3b1  lea rdi, [rsp]
00007f30a29de3b5  mov esi, 0x00
00007f30a29de3ba  mov rax, 0x5FE955026530
00007f30a29de3c4  call rax
00007f30a29de3c6  movaps xmm7, [rsp]
00007f30a29de3ca  add rsp, 0x30
00007f30a29de3ce  vmovaps xmm0, [rsp]
00007f30a29de3d3  vmovaps xmm1, [rsp+0x10]
00007f30a29de3d9  vmovaps xmm2, [rsp+0x20]
00007f30a29de3df  vmovaps xmm3, [rsp+0x30]
00007f30a29de3e5  vmovaps xmm4, [rsp+0x40]
00007f30a29de3eb  vmovaps xmm5, [rsp+0x50]
00007f30a29de3f1  vmovaps xmm6, [rsp+0x60]
00007f30a29de3f7  vmovaps xmm8, [rsp+0x70]
00007f30a29de3fd  vmovaps xmm9, [rsp+0x80]
00007f30a29de406  vmovaps xmm10, [rsp+0x90]
00007f30a29de40f  vmovaps xmm11, [rsp+0xA0]
00007f30a29de418  vmovaps xmm12, [rsp+0xB0]
00007f30a29de421  vmovaps xmm13, [rsp+0xC0]
00007f30a29de42a  vmovaps xmm14, [rsp+0xD0]
00007f30a29de433  vmovaps xmm15, [rsp+0xE0]
00007f30a29de43c  add rsp, 0xF0
00007f30a29de443  pop r11
00007f30a29de445  pop r10
00007f30a29de447  pop r9
00007f30a29de449  pop r8
00007f30a29de44b  pop rsi
00007f30a29de44c  pop rdi
00007f30a29de44d  pop rdx
00007f30a29de44e  pop rcx
00007f30a29de44f  pop rax
00007f30a29de450  add rsp, 0x08
00007f30a29de454  jmp 0x00007F30A29D97E1
00007f30a29de459  sub rsp, 0x08
00007f30a29de45d  push rax
00007f30a29de45e  push rcx
00007f30a29de45f  push rdx
00007f30a29de460  push rdi
00007f30a29de461  push rsi
00007f30a29de462  push r8
00007f30a29de464  push r9
00007f30a29de466  push r10
00007f30a29de468  push r11
00007f30a29de46a  sub rsp, 0xF0
00007f30a29de471  vmovaps [rsp], xmm0
00007f30a29de476  vmovaps [rsp+0x10], xmm1
00007f30a29de47c  vmovaps [rsp+0x20], xmm2
00007f30a29de482  vmovaps [rsp+0x30], xmm3
00007f30a29de488  vmovaps [rsp+0x40], xmm4
00007f30a29de48e  vmovaps [rsp+0x50], xmm5
00007f30a29de494  vmovaps [rsp+0x60], xmm6
00007f30a29de49a  vmovaps [rsp+0x70], xmm7
00007f30a29de4a0  vmovaps [rsp+0x80], xmm8
00007f30a29de4a9  vmovaps [rsp+0x90], xmm10
00007f30a29de4b2  vmovaps [rsp+0xA0], xmm11
00007f30a29de4bb  vmovaps [rsp+0xB0], xmm12
00007f30a29de4c4  vmovaps [rsp+0xC0], xmm13
00007f30a29de4cd  vmovaps [rsp+0xD0], xmm14
00007f30a29de4d6  vmovaps [rsp+0xE0], xmm15
00007f30a29de4df  sub rsp, 0x30
00007f30a29de4e3  movaps [rsp], xmm9
00007f30a29de4e8  movaps [rsp+0x10], xmm13
00007f30a29de4ee  movaps [rsp+0x20], xmm15
00007f30a29de4f4  lea rdi, [rsp]
00007f30a29de4f8  mov esi, 0x00
00007f30a29de4fd  mov rax, 0x5FE955026530
00007f30a29de507  call rax
00007f30a29de509  movaps xmm9, [rsp]
00007f30a29de50e  add rsp, 0x30
00007f30a29de512  vmovaps xmm0, [rsp]
00007f30a29de517  vmovaps xmm1, [rsp+0x10]
00007f30a29de51d  vmovaps xmm2, [rsp+0x20]
00007f30a29de523  vmovaps xmm3, [rsp+0x30]
00007f30a29de529  vmovaps xmm4, [rsp+0x40]
00007f30a29de52f  vmovaps xmm5, [rsp+0x50]
00007f30a29de535  vmovaps xmm6, [rsp+0x60]
00007f30a29de53b  vmovaps xmm7, [rsp+0x70]
00007f30a29de541  vmovaps xmm8, [rsp+0x80]
00007f30a29de54a  vmovaps xmm10, [rsp+0x90]
00007f30a29de553  vmovaps xmm11, [rsp+0xA0]
00007f30a29de55c  vmovaps xmm12, [rsp+0xB0]
00007f30a29de565  vmovaps xmm13, [rsp+0xC0]
00007f30a29de56e  vmovaps xmm14, [rsp+0xD0]
00007f30a29de577  vmovaps xmm15, [rsp+0xE0]
00007f30a29de580  add rsp, 0xF0
00007f30a29de587  pop r11
00007f30a29de589  pop r10
00007f30a29de58b  pop r9
00007f30a29de58d  pop r8
00007f30a29de58f  pop rsi
00007f30a29de590  pop rdi
00007f30a29de591  pop rdx
00007f30a29de592  pop rcx
00007f30a29de593  pop rax
00007f30a29de594  add rsp, 0x08
00007f30a29de598  jmp 0x00007F30A29D980F
00007f30a29de59d  sub rsp, 0x08
00007f30a29de5a1  push rax
00007f30a29de5a2  push rcx
00007f30a29de5a3  push rdx
00007f30a29de5a4  push rdi
00007f30a29de5a5  push rsi
00007f30a29de5a6  push r8
00007f30a29de5a8  push r9
00007f30a29de5aa  push r10
00007f30a29de5ac  push r11
00007f30a29de5ae  sub rsp, 0xF0
00007f30a29de5b5  vmovaps [rsp], xmm0
00007f30a29de5ba  vmovaps [rsp+0x10], xmm1
00007f30a29de5c0  vmovaps [rsp+0x20], xmm2
00007f30a29de5c6  vmovaps [rsp+0x30], xmm3
00007f30a29de5cc  vmovaps [rsp+0x40], xmm4
00007f30a29de5d2  vmovaps [rsp+0x50], xmm5
00007f30a29de5d8  vmovaps [rsp+0x60], xmm6
00007f30a29de5de  vmovaps [rsp+0x70], xmm7
00007f30a29de5e4  vmovaps [rsp+0x80], xmm8
00007f30a29de5ed  vmovaps [rsp+0x90], xmm9
00007f30a29de5f6  vmovaps [rsp+0xA0], xmm10
00007f30a29de5ff  vmovaps [rsp+0xB0], xmm11
00007f30a29de608  vmovaps [rsp+0xC0], xmm12
00007f30a29de611  vmovaps [rsp+0xD0], xmm13
00007f30a29de61a  vmovaps [rsp+0xE0], xmm14
00007f30a29de623  sub rsp, 0x30
00007f30a29de627  movaps [rsp], xmm15
00007f30a29de62c  movaps [rsp+0x10], xmm11
00007f30a29de632  movaps [rsp+0x20], xmm12
00007f30a29de638  lea rdi, [rsp]
00007f30a29de63c  mov esi, 0x00
00007f30a29de641  mov rax, 0x5FE955026530
00007f30a29de64b  call rax
00007f30a29de64d  movaps xmm15, [rsp]
00007f30a29de652  add rsp, 0x30
00007f30a29de656  vmovaps xmm0, [rsp]
00007f30a29de65b  vmovaps xmm1, [rsp+0x10]
00007f30a29de661  vmovaps xmm2, [rsp+0x20]
00007f30a29de667  vmovaps xmm3, [rsp+0x30]
00007f30a29de66d  vmovaps xmm4, [rsp+0x40]
00007f30a29de673  vmovaps xmm5, [rsp+0x50]
00007f30a29de679  vmovaps xmm6, [rsp+0x60]
00007f30a29de67f  vmovaps xmm7, [rsp+0x70]
00007f30a29de685  vmovaps xmm8, [rsp+0x80]
00007f30a29de68e  vmovaps xmm9, [rsp+0x90]
00007f30a29de697  vmovaps xmm10, [rsp+0xA0]
00007f30a29de6a0  vmovaps xmm11, [rsp+0xB0]
00007f30a29de6a9  vmovaps xmm12, [rsp+0xC0]
00007f30a29de6b2  vmovaps xmm13, [rsp+0xD0]
00007f30a29de6bb  vmovaps xmm14, [rsp+0xE0]
00007f30a29de6c4  add rsp, 0xF0
00007f30a29de6cb  pop r11
00007f30a29de6cd  pop r10
00007f30a29de6cf  pop r9
00007f30a29de6d1  pop r8
00007f30a29de6d3  pop rsi
00007f30a29de6d4  pop rdi
00007f30a29de6d5  pop rdx
00007f30a29de6d6  pop rcx
00007f30a29de6d7  pop rax
00007f30a29de6d8  add rsp, 0x08
00007f30a29de6dc  jmp 0x00007F30A29D982A
00007f30a29de6e1  sub rsp, 0x08
00007f30a29de6e5  push rax
00007f30a29de6e6  push rcx
00007f30a29de6e7  push rdx
00007f30a29de6e8  push rdi
00007f30a29de6e9  push rsi
00007f30a29de6ea  push r8
00007f30a29de6ec  push r9
00007f30a29de6ee  push r10
00007f30a29de6f0  push r11
00007f30a29de6f2  sub rsp, 0xF0
00007f30a29de6f9  vmovaps [rsp], xmm0
00007f30a29de6fe  vmovaps [rsp+0x10], xmm1
00007f30a29de704  vmovaps [rsp+0x20], xmm2
00007f30a29de70a  vmovaps [rsp+0x30], xmm3
00007f30a29de710  vmovaps [rsp+0x40], xmm4
00007f30a29de716  vmovaps [rsp+0x50], xmm5
00007f30a29de71c  vmovaps [rsp+0x60], xmm6
00007f30a29de722  vmovaps [rsp+0x70], xmm7
00007f30a29de728  vmovaps [rsp+0x80], xmm8
00007f30a29de731  vmovaps [rsp+0x90], xmm9
00007f30a29de73a  vmovaps [rsp+0xA0], xmm10
00007f30a29de743  vmovaps [rsp+0xB0], xmm11
00007f30a29de74c  vmovaps [rsp+0xC0], xmm12
00007f30a29de755  vmovaps [rsp+0xD0], xmm14
00007f30a29de75e  vmovaps [rsp+0xE0], xmm15
00007f30a29de767  sub rsp, 0x30
00007f30a29de76b  movaps [rsp], xmm13
00007f30a29de770  movaps [rsp+0x10], xmm10
00007f30a29de776  movaps [rsp+0x20], xmm14
00007f30a29de77c  lea rdi, [rsp]
00007f30a29de780  mov esi, 0x00
00007f30a29de785  mov rax, 0x5FE955026530
00007f30a29de78f  call rax
00007f30a29de791  movaps xmm13, [rsp]
00007f30a29de796  add rsp, 0x30
00007f30a29de79a  vmovaps xmm0, [rsp]
00007f30a29de79f  vmovaps xmm1, [rsp+0x10]
00007f30a29de7a5  vmovaps xmm2, [rsp+0x20]
00007f30a29de7ab  vmovaps xmm3, [rsp+0x30]
00007f30a29de7b1  vmovaps xmm4, [rsp+0x40]
00007f30a29de7b7  vmovaps xmm5, [rsp+0x50]
00007f30a29de7bd  vmovaps xmm6, [rsp+0x60]
00007f30a29de7c3  vmovaps xmm7, [rsp+0x70]
00007f30a29de7c9  vmovaps xmm8, [rsp+0x80]
00007f30a29de7d2  vmovaps xmm9, [rsp+0x90]
00007f30a29de7db  vmovaps xmm10, [rsp+0xA0]
00007f30a29de7e4  vmovaps xmm11, [rsp+0xB0]
00007f30a29de7ed  vmovaps xmm12, [rsp+0xC0]
00007f30a29de7f6  vmovaps xmm14, [rsp+0xD0]
00007f30a29de7ff  vmovaps xmm15, [rsp+0xE0]
00007f30a29de808  add rsp, 0xF0
00007f30a29de80f  pop r11
00007f30a29de811  pop r10
00007f30a29de813  pop r9
00007f30a29de815  pop r8
00007f30a29de817  pop rsi
00007f30a29de818  pop rdi
00007f30a29de819  pop rdx
00007f30a29de81a  pop rcx
00007f30a29de81b  pop rax
00007f30a29de81c  add rsp, 0x08
00007f30a29de820  jmp 0x00007F30A29D984D
00007f30a29de825  sub rsp, 0x08
00007f30a29de829  push rax
00007f30a29de82a  push rcx
00007f30a29de82b  push rdx
00007f30a29de82c  push rdi
00007f30a29de82d  push rsi
00007f30a29de82e  push r8
00007f30a29de830  push r9
00007f30a29de832  push r10
00007f30a29de834  push r11
00007f30a29de836  sub rsp, 0xF0
00007f30a29de83d  vmovaps [rsp], xmm0
00007f30a29de842  vmovaps [rsp+0x10], xmm1
00007f30a29de848  vmovaps [rsp+0x20], xmm2
00007f30a29de84e  vmovaps [rsp+0x30], xmm3
00007f30a29de854  vmovaps [rsp+0x40], xmm4
00007f30a29de85a  vmovaps [rsp+0x50], xmm5
00007f30a29de860  vmovaps [rsp+0x60], xmm6
00007f30a29de866  vmovaps [rsp+0x70], xmm7
00007f30a29de86c  vmovaps [rsp+0x80], xmm8
00007f30a29de875  vmovaps [rsp+0x90], xmm9
00007f30a29de87e  vmovaps [rsp+0xA0], xmm10
00007f30a29de887  vmovaps [rsp+0xB0], xmm11
00007f30a29de890  vmovaps [rsp+0xC0], xmm12
00007f30a29de899  vmovaps [rsp+0xD0], xmm13
00007f30a29de8a2  vmovaps [rsp+0xE0], xmm15
00007f30a29de8ab  sub rsp, 0x30
00007f30a29de8af  movaps [rsp], xmm14
00007f30a29de8b4  movaps [rsp+0x10], xmm1
00007f30a29de8b9  movaps [rsp+0x20], xmm7
00007f30a29de8be  lea rdi, [rsp]
00007f30a29de8c2  mov esi, 0x00
00007f30a29de8c7  mov rax, 0x5FE955026530
00007f30a29de8d1  call rax
00007f30a29de8d3  movaps xmm14, [rsp]
00007f30a29de8d8  add rsp, 0x30
00007f30a29de8dc  vmovaps xmm0, [rsp]
00007f30a29de8e1  vmovaps xmm1, [rsp+0x10]
00007f30a29de8e7  vmovaps xmm2, [rsp+0x20]
00007f30a29de8ed  vmovaps xmm3, [rsp+0x30]
00007f30a29de8f3  vmovaps xmm4, [rsp+0x40]
00007f30a29de8f9  vmovaps xmm5, [rsp+0x50]
00007f30a29de8ff  vmovaps xmm6, [rsp+0x60]
00007f30a29de905  vmovaps xmm7, [rsp+0x70]
00007f30a29de90b  vmovaps xmm8, [rsp+0x80]
00007f30a29de914  vmovaps xmm9, [rsp+0x90]
00007f30a29de91d  vmovaps xmm10, [rsp+0xA0]
00007f30a29de926  vmovaps xmm11, [rsp+0xB0]
00007f30a29de92f  vmovaps xmm12, [rsp+0xC0]
00007f30a29de938  vmovaps xmm13, [rsp+0xD0]
00007f30a29de941  vmovaps xmm15, [rsp+0xE0]
00007f30a29de94a  add rsp, 0xF0
00007f30a29de951  pop r11
00007f30a29de953  pop r10
00007f30a29de955  pop r9
00007f30a29de957  pop r8
00007f30a29de959  pop rsi
00007f30a29de95a  pop rdi
00007f30a29de95b  pop rdx
00007f30a29de95c  pop rcx
00007f30a29de95d  pop rax
00007f30a29de95e  add rsp, 0x08
00007f30a29de962  jmp 0x00007F30A29D9870
00007f30a29de967  sub rsp, 0x08
00007f30a29de96b  push rax
00007f30a29de96c  push rcx
00007f30a29de96d  push rdx
00007f30a29de96e  push rdi
00007f30a29de96f  push rsi
00007f30a29de970  push r8
00007f30a29de972  push r9
00007f30a29de974  push r10
00007f30a29de976  push r11
00007f30a29de978  sub rsp, 0xF0
00007f30a29de97f  vmovaps [rsp], xmm0
00007f30a29de984  vmovaps [rsp+0x10], xmm2
00007f30a29de98a  vmovaps [rsp+0x20], xmm3
00007f30a29de990  vmovaps [rsp+0x30], xmm4
00007f30a29de996  vmovaps [rsp+0x40], xmm5
00007f30a29de99c  vmovaps [rsp+0x50], xmm6
00007f30a29de9a2  vmovaps [rsp+0x60], xmm7
00007f30a29de9a8  vmovaps [rsp+0x70], xmm8
00007f30a29de9ae  vmovaps [rsp+0x80], xmm9
00007f30a29de9b7  vmovaps [rsp+0x90], xmm10
00007f30a29de9c0  vmovaps [rsp+0xA0], xmm11
00007f30a29de9c9  vmovaps [rsp+0xB0], xmm12
00007f30a29de9d2  vmovaps [rsp+0xC0], xmm13
00007f30a29de9db  vmovaps [rsp+0xD0], xmm14
00007f30a29de9e4  vmovaps [rsp+0xE0], xmm15
00007f30a29de9ed  sub rsp, 0x30
00007f30a29de9f1  movaps [rsp], xmm1
00007f30a29de9f5  movaps [rsp+0x10], xmm8
00007f30a29de9fb  movaps [rsp+0x20], xmm9
00007f30a29dea01  lea rdi, [rsp]
00007f30a29dea05  mov esi, 0x00
00007f30a29dea0a  mov rax, 0x5FE955026530
00007f30a29dea14  call rax
00007f30a29dea16  movaps xmm1, [rsp]
00007f30a29dea1a  add rsp, 0x30
00007f30a29dea1e  vmovaps xmm0, [rsp]
00007f30a29dea23  vmovaps xmm2, [rsp+0x10]
00007f30a29dea29  vmovaps xmm3, [rsp+0x20]
00007f30a29dea2f  vmovaps xmm4, [rsp+0x30]
00007f30a29dea35  vmovaps xmm5, [rsp+0x40]
00007f30a29dea3b  vmovaps xmm6, [rsp+0x50]
00007f30a29dea41  vmovaps xmm7, [rsp+0x60]
00007f30a29dea47  vmovaps xmm8, [rsp+0x70]
00007f30a29dea4d  vmovaps xmm9, [rsp+0x80]
00007f30a29dea56  vmovaps xmm10, [rsp+0x90]
00007f30a29dea5f  vmovaps xmm11, [rsp+0xA0]
00007f30a29dea68  vmovaps xmm12, [rsp+0xB0]
00007f30a29dea71  vmovaps xmm13, [rsp+0xC0]
00007f30a29dea7a  vmovaps xmm14, [rsp+0xD0]
00007f30a29dea83  vmovaps xmm15, [rsp+0xE0]
00007f30a29dea8c  add rsp, 0xF0
00007f30a29dea93  pop r11
00007f30a29dea95  pop r10
00007f30a29dea97  pop r9
00007f30a29dea99  pop r8
00007f30a29dea9b  pop rsi
00007f30a29dea9c  pop rdi
00007f30a29dea9d  pop rdx
00007f30a29dea9e  pop rcx
00007f30a29dea9f  pop rax
00007f30a29deaa0  add rsp, 0x08
00007f30a29deaa4  jmp 0x00007F30A29D9892
00007f30a29deaa9  call 0x00007F30A28B3E40
00007f30a29deaae  jmp 0x00007F30A29D98A0
00007f30a29deab3  call 0x00007F30A280C380
00007f30a29deab8  jmp 0x00007F30A29D98AA
00007f30a29deabd  call 0x00007F30A280D600
00007f30a29deac2  jmp 0x00007F30A29D98B4
00007f30a29deac7  call 0x00007F30A27FF540
00007f30a29deacc  jmp 0x00007F30A29D98BE
00007f30a29dead1  int3
00007f30a29dead2  nop [rax+rax*1], ax
00007f30a29deadb  nop [rax+rax*1], eax
00007f30a29deae0  mov eax, [r15+0x48]
00007f30a29deae4  lea r14d, [eax+0x01]
00007f30a29deae9  mov [rsp+0x10], r14d
00007f30a29deaee  mov r14d, r14d
00007f30a29deaf1  mov [r15+0x48], r14
00007f30a29deaf5  xor eax, eax
00007f30a29deaf7  mov r14d, [rsp+0x10]
00007f30a29deafc  cmp r14d, 0x1F4
00007f30a29deb03  cmc
00007f30a29deb04  lahf
00007f30a29deb05  seto al
00007f30a29deb08  mov [r15+0x108], eax
00007f30a29deb0f  mov eax, [r15+0x108]
00007f30a29deb16  sahf
00007f30a29deb17  jnz 0x00007F30A29DEB49
00007f30a29deb19  cmp dword ptr [r15+0x318], 0x00
00007f30a29deb21  jz 0x00007F30A29E4C90
00007f30a29deb27  nop [rax+rax*1], ax
00007f30a29deb30  nop [rax+rax*1], eax
00007f30a29deb38  mov eax, 0x4106DC
00007f30a29deb3d  mov [r15+0x100], rax
00007f30a29deb44  jmp 0x00007F30A27FE110
00007f30a29deb49  cmp dword ptr [r15+0x318], 0x00
00007f30a29deb51  jz 0x00007F30A29DEB80
00007f30a29deb57  nop [rax+rax*1], ax
00007f30a29deb60  nop [rax+rax*1], eax
00007f30a29deb68  mov eax, 0x410500
00007f30a29deb6d  mov [r15+0x100], rax
00007f30a29deb74  jmp 0x00007F30A27FE110
00007f30a29deb79  int3
00007f30a29deb7a  int3
00007f30a29deb7b  nop [rax+rax*1], eax
00007f30a29deb80  mov rax, [r15+0x40]
00007f30a29deb84  movaps xmm1, [r15+0x1D0]
00007f30a29deb8c  vmovaps [rsp+0x10], xmm1
00007f30a29deb92  vmovaps xmm15, [rsp+0x10]
00007f30a29deb98  por xmm1, xmm15
00007f30a29deb9d  movaps xmm14, [r15+0x1A0]
00007f30a29deba5  vmovaps [rsp+0x10], xmm14
00007f30a29debab  vmovaps xmm13, [rsp+0x10]
00007f30a29debb1  por xmm14, xmm13
00007f30a29debb6  lea r14, [rax+0x30]
00007f30a29debba  mov r12, [r13+r14*1]
00007f30a29debbf  lea r14, [rax+0x38]
00007f30a29debc3  mov r11, [r13+r14*1]
00007f30a29debc8  movq xmm13, r12
00007f30a29debcd  movq xmm12, r11
00007f30a29debd2  movq xmm13, xmm13
00007f30a29debd7  vmovaps [rsp+0x10], xmm13
00007f30a29debdd  movq xmm13, xmm13
00007f30a29debe2  movaps [r15+0x130], xmm13
00007f30a29debea  movq xmm12, xmm12
00007f30a29debef  vmovaps [rsp+0x20], xmm12
00007f30a29debf5  movq xmm12, xmm12
00007f30a29debfa  movaps [r15+0x280], xmm12
00007f30a29dec02  movaps xmm13, [r15+0x270]
00007f30a29dec0a  vmovaps [rsp+0x30], xmm13
00007f30a29dec10  vmovaps xmm12, [rsp+0x30]
00007f30a29dec16  por xmm13, xmm12
00007f30a29dec1b  lea r14, [rax+0x20]
00007f30a29dec1f  mov r12, [r13+r14*1]
00007f30a29dec24  lea r14, [rax+0x28]
00007f30a29dec28  mov r11, [r13+r14*1]
00007f30a29dec2d  movq xmm12, r12
00007f30a29dec32  movq xmm11, r11
00007f30a29dec37  movq xmm12, xmm12
00007f30a29dec3c  vmovaps [rsp+0x30], xmm12
00007f30a29dec42  movq xmm12, xmm12
00007f30a29dec47  movaps [r15+0x150], xmm12
00007f30a29dec4f  movq xmm11, xmm11
00007f30a29dec54  vmovaps [rsp+0x40], xmm11
00007f30a29dec5a  movq xmm11, xmm11
00007f30a29dec5f  movaps [r15+0x140], xmm11
00007f30a29dec67  lea r14, [rax+0x10]
00007f30a29dec6b  mov r12, [r13+r14*1]
00007f30a29dec70  lea r14, [rax+0x18]
00007f30a29dec74  mov r11, [r13+r14*1]
00007f30a29dec79  movq xmm12, r12
00007f30a29dec7e  movq xmm11, r11
00007f30a29dec83  movq xmm12, xmm12
00007f30a29dec88  vmovaps [rsp+0x50], xmm12
00007f30a29dec8e  movq xmm12, xmm12
00007f30a29dec93  movaps [r15+0x170], xmm12
00007f30a29dec9b  movq xmm11, xmm11
00007f30a29deca0  vmovaps [rsp+0x60], xmm11
00007f30a29deca6  movq xmm11, xmm11
00007f30a29decab  movaps [r15+0x160], xmm11
00007f30a29decb3  mov r14, [r13+rax*1]
00007f30a29decb8  vmovq xmm12, r14
00007f30a29decbd  vpbroadcastq xmm12, xmm12
00007f30a29decc2  lea r14, [rax+0x08]
00007f30a29decc6  mov rax, [r13+r14*1]
00007f30a29deccb  movq xmm11, rax
00007f30a29decd0  movaps [r15+0x230], xmm11
00007f30a29decd8  mov rax, [r15+0xF8]
00007f30a29decdf  lea r14, [rax+0x50]
00007f30a29dece3  movups xmm11, [r13+r14*1]
00007f30a29dece9  lea r14, [rax+0x60]
00007f30a29deced  movups xmm10, [r13+r14*1]
00007f30a29decf3  lea r14, [rax+0x30]
00007f30a29decf7  movups xmm9, [r13+r14*1]
00007f30a29decfd  mov r14, [r15+0x50]
00007f30a29ded01  mov [r15+0x60], r14
00007f30a29ded05  mov qword ptr [r15+0x58], 0x40
00007f30a29ded0d  movaps xmm8, xmm12
00007f30a29ded11  mulpd xmm8, xmm15
00007f30a29ded16  vcmppd xmm7, xmm8, xmm8, 0x03
00007f30a29ded1c  ptest xmm7, xmm7
00007f30a29ded21  jnz 0x00007F30A29DFB4A
00007f30a29ded27  movq xmm15, qword ptr [r15+0x230]
00007f30a29ded30  vmovaps [rsp+0x70], xmm15
00007f30a29ded36  vpermilpd xmm15, xmm15, 0x00
00007f30a29ded3c  movaps xmm7, xmm9
00007f30a29ded40  mulpd xmm7, xmm15
00007f30a29ded45  vcmppd xmm6, xmm7, xmm7, 0x03
00007f30a29ded4a  ptest xmm6, xmm6
00007f30a29ded4f  jnz 0x00007F30A29DFC8E
00007f30a29ded55  vxorps xmm15, xmm15, xmm15
00007f30a29ded5a  vpbroadcastq xmm15, xmm15
00007f30a29ded5f  movaps xmm9, xmm12
00007f30a29ded63  mulpd xmm9, xmm10
00007f30a29ded68  vcmppd xmm6, xmm9, xmm9, 0x03
00007f30a29ded6e  ptest xmm6, xmm6
00007f30a29ded73  jnz 0x00007F30A29DFDD0
00007f30a29ded79  movaps xmm10, xmm12
00007f30a29ded7d  mulpd xmm10, xmm11
00007f30a29ded82  vcmppd xmm6, xmm10, xmm10, 0x03
00007f30a29ded88  ptest xmm6, xmm6
00007f30a29ded8d  jnz 0x00007F30A29DFF14
00007f30a29ded93  movaps xmm11, [r15+0x1F0]
00007f30a29ded9b  movaps xmm6, xmm12
00007f30a29ded9f  mulpd xmm6, xmm11
00007f30a29deda4  vcmppd xmm5, xmm6, xmm6, 0x03
00007f30a29deda9  ptest xmm5, xmm5
00007f30a29dedae  jnz 0x00007F30A29E0058
00007f30a29dedb4  movaps xmm12, [r15+0x2A0]
00007f30a29dedbc  vmovaps [rsp+0x80], xmm12
00007f30a29dedc5  vmovaps xmm11, [rsp+0x80]
00007f30a29dedce  por xmm12, xmm11
00007f30a29dedd3  movaps xmm11, [r15+0x250]
00007f30a29deddb  vmovaps [rsp+0x80], xmm11
00007f30a29dede4  vmovaps xmm5, [rsp+0x80]
00007f30a29deded  por xmm11, xmm5
00007f30a29dedf2  vmovaps xmm4, [rsp+0x70]
00007f30a29dedf8  vpermilpd xmm4, xmm4, 0x00
00007f30a29dedfe  movaps xmm3, xmm5
00007f30a29dee01  mulpd xmm3, xmm4
00007f30a29dee05  vcmppd xmm2, xmm3, xmm3, 0x03
00007f30a29dee0a  ptest xmm2, xmm2
00007f30a29dee0f  jnz 0x00007F30A29E019A
00007f30a29dee15  mov [rsp+0x80], rax
00007f30a29dee1d  xor eax, eax
00007f30a29dee1f  mov r12d, 0x40
00007f30a29dee25  mov r11d, 0x200
00007f30a29dee2b  cmp r12, r11
00007f30a29dee2e  cmc
00007f30a29dee2f  lahf
00007f30a29dee30  seto al
00007f30a29dee33  mov [r15+0x108], eax
00007f30a29dee3a  movaps xmm5, xmm8
00007f30a29dee3e  addpd xmm5, xmm15
00007f30a29dee43  vcmppd xmm4, xmm5, xmm5, 0x03
00007f30a29dee48  ptest xmm4, xmm4
00007f30a29dee4d  jnz 0x00007F30A29E02DA
00007f30a29dee53  movaps xmm8, [r15+0x1B0]
00007f30a29dee5b  movaps xmm4, xmm9
00007f30a29dee5f  addpd xmm4, xmm8
00007f30a29dee64  vcmppd xmm2, xmm4, xmm4, 0x03
00007f30a29dee69  ptest xmm2, xmm2
00007f30a29dee6e  jnz 0x00007F30A29E041C
00007f30a29dee74  movaps xmm9, xmm10
00007f30a29dee78  addpd xmm9, xmm8
00007f30a29dee7d  vcmppd xmm2, xmm9, xmm9, 0x03
00007f30a29dee83  ptest xmm2, xmm2
00007f30a29dee88  jnz 0x00007F30A29E055E
00007f30a29dee8e  movaps xmm10, [r15+0x2F0]
00007f30a29dee96  vmovaps [rsp+0x90], xmm10
00007f30a29dee9f  vmovaps xmm8, [rsp+0x90]
00007f30a29deea8  por xmm10, xmm8
00007f30a29deead  movaps xmm8, [r15+0x2E0]
00007f30a29deeb5  vmovaps [rsp+0x90], xmm8
00007f30a29deebe  vmovaps xmm2, [rsp+0x90]
00007f30a29deec7  por xmm8, xmm2
00007f30a29deecc  movaps xmm2, [r15+0x2D0]
00007f30a29deed4  vmovaps [rsp+0x90], xmm2
00007f30a29deedd  vmovaps [rsp+0xA0], xmm1
00007f30a29deee6  vmovaps xmm1, [rsp+0x90]
00007f30a29deeef  por xmm2, xmm1
00007f30a29deef3  movaps xmm1, [r15+0x200]
00007f30a29deefb  vmovaps [rsp+0x90], xmm1
00007f30a29def04  vmovaps [rsp+0xB0], xmm15
00007f30a29def0d  vmovaps xmm15, [rsp+0x90]
00007f30a29def16  por xmm1, xmm15
00007f30a29def1b  movaps xmm15, [r15+0x1C0]
00007f30a29def23  vmovaps [rsp+0x90], xmm15
00007f30a29def2c  vmovaps [rsp+0xC0], xmm1
00007f30a29def35  vmovaps xmm1, [rsp+0x90]
00007f30a29def3e  por xmm15, xmm1
00007f30a29def43  movaps xmm1, [r15+0x190]
00007f30a29def4b  vmovaps [rsp+0x90], xmm1
00007f30a29def54  vmovaps [rsp+0xD0], xmm15
00007f30a29def5d  vmovaps xmm15, [rsp+0x90]
00007f30a29def66  por xmm1, xmm15
00007f30a29def6b  movaps xmm15, [r15+0x300]
00007f30a29def73  vmovaps [rsp+0x90], xmm15
00007f30a29def7c  vmovaps [rsp+0xE0], xmm1
00007f30a29def85  vmovaps xmm1, [rsp+0x90]
00007f30a29def8e  por xmm15, xmm1
00007f30a29def93  mov rax, [rsp+0x80]
00007f30a29def9b  lea r12, [rax+0xA0]
00007f30a29defa2  movups xmm1, [r13+r12*1]
00007f30a29defa8  lea r12, [rax+0xB0]
00007f30a29defaf  vmovaps [rsp+0x80], xmm1
00007f30a29defb8  movups xmm1, [r13+r12*1]
00007f30a29defbe  vmovaps [rsp+0x90], xmm1
00007f30a29defc7  vmovaps [rsp+0xF0], xmm15
00007f30a29defd0  vmovaps xmm15, [rsp+0xB0]
00007f30a29defd9  vmovaps [rsp+0xB0], xmm14
00007f30a29defe2  movaps xmm1, xmm6
00007f30a29defe5  addpd xmm1, xmm15
00007f30a29defea  vcmppd xmm14, xmm1, xmm1, 0x03
00007f30a29defef  ptest xmm14, xmm14
00007f30a29deff5  jnz 0x00007F30A29E06B6
00007f30a29deffb  lea r12, [rax+0xF0]
00007f30a29df002  movups xmm15, [r13+r12*1]
00007f30a29df008  movaps xmm14, xmm4
00007f30a29df00c  addpd xmm14, xmm3
00007f30a29df011  vcmppd xmm6, xmm14, xmm14, 0x03
00007f30a29df017  ptest xmm6, xmm6
00007f30a29df01c  jnz 0x00007F30A29E0801
00007f30a29df022  movaps xmm6, xmm9
00007f30a29df026  addpd xmm6, xmm7
00007f30a29df02a  vcmppd xmm4, xmm6, xmm6, 0x03
00007f30a29df02f  ptest xmm4, xmm4
00007f30a29df034  jnz 0x00007F30A29E0943
00007f30a29df03a  vmovaps xmm9, [rsp+0x70]
00007f30a29df040  vpermilpd xmm9, xmm9, 0x00
00007f30a29df046  vmovaps xmm4, [rsp+0x90]
00007f30a29df04f  movaps xmm7, xmm4
00007f30a29df052  mulpd xmm7, xmm9
00007f30a29df057  vcmppd xmm3, xmm7, xmm7, 0x03
00007f30a29df05c  ptest xmm3, xmm3
00007f30a29df061  jnz 0x00007F30A29E0A84
00007f30a29df067  vmovaps xmm9, [rsp+0x50]
00007f30a29df06d  vpermilpd xmm9, xmm9, 0x00
00007f30a29df073  movaps xmm4, xmm15
00007f30a29df077  mulpd xmm4, xmm9
00007f30a29df07c  vcmppd xmm3, xmm4, xmm4, 0x03
00007f30a29df081  ptest xmm3, xmm3
00007f30a29df086  jnz 0x00007F30A29E0BC5
00007f30a29df08c  lea r12, [rax+0xE0]
00007f30a29df093  movups xmm15, [r13+r12*1]
00007f30a29df099  vmovaps xmm9, [rsp+0x70]
00007f30a29df09f  vpermilpd xmm9, xmm9, 0x00
00007f30a29df0a5  vmovaps [rsp+0x70], xmm1
00007f30a29df0ab  vmovaps xmm1, [rsp+0x80]
00007f30a29df0b4  vmovaps [rsp+0x80], xmm15
00007f30a29df0bd  movaps xmm3, xmm1
00007f30a29df0c0  mulpd xmm3, xmm9
00007f30a29df0c5  vcmppd xmm15, xmm3, xmm3, 0x03
00007f30a29df0ca  ptest xmm15, xmm15
00007f30a29df0d0  jnz 0x00007F30A29E0D11
00007f30a29df0d6  vmovaps xmm1, [rsp+0xF0]
00007f30a29df0df  vmovaps xmm15, [rsp+0xF0]
00007f30a29df0e8  por xmm1, xmm15
00007f30a29df0ed  movaps [r15+0x300], xmm1
00007f30a29df0f5  vmovaps xmm15, [rsp+0xE0]
00007f30a29df0fe  vmovaps xmm9, [rsp+0xE0]
00007f30a29df107  por xmm15, xmm9
00007f30a29df10c  movaps [r15+0x190], xmm15
00007f30a29df114  vmovaps xmm9, [rsp+0x50]
00007f30a29df11a  vpermilpd xmm9, xmm9, 0x00
00007f30a29df120  vmovaps [rsp+0x90], xmm1
00007f30a29df129  vmovaps [rsp+0xE0], xmm15
00007f30a29df132  vmovaps xmm15, [rsp+0x80]
00007f30a29df13b  vmovaps [rsp+0x80], xmm14
00007f30a29df144  movaps xmm1, xmm15
00007f30a29df148  mulpd xmm1, xmm9
00007f30a29df14d  vcmppd xmm14, xmm1, xmm1, 0x03
00007f30a29df152  ptest xmm14, xmm14
00007f30a29df158  jnz 0x00007F30A29E0E52
00007f30a29df15e  lea r12, [rax+0x90]
00007f30a29df165  movups xmm15, [r13+r12*1]
00007f30a29df16b  vmovaps xmm14, [rsp+0xD0]
00007f30a29df174  vmovaps xmm9, [rsp+0xD0]
00007f30a29df17d  por xmm14, xmm9
00007f30a29df182  movaps [r15+0x1C0], xmm14
00007f30a29df18a  vmovaps xmm9, [rsp+0xC0]
00007f30a29df193  vmovaps [rsp+0xD0], xmm1
00007f30a29df19c  vmovaps xmm1, [rsp+0xC0]
00007f30a29df1a5  por xmm9, xmm1
00007f30a29df1aa  movaps [r15+0x200], xmm9
00007f30a29df1b2  vmovaps [rsp+0xC0], xmm2
00007f30a29df1bb  vmovaps xmm1, [rsp+0xC0]
00007f30a29df1c4  por xmm2, xmm1
00007f30a29df1c8  movaps [r15+0x2D0], xmm2
00007f30a29df1d0  vmovaps [rsp+0xC0], xmm8
00007f30a29df1d9  vmovaps xmm1, [rsp+0xC0]
00007f30a29df1e2  por xmm8, xmm1
00007f30a29df1e7  movaps [r15+0x2E0], xmm8
00007f30a29df1ef  vmovaps [rsp+0xC0], xmm15
00007f30a29df1f8  movaps xmm1, xmm5
00007f30a29df1fb  addpd xmm1, xmm7
00007f30a29df1ff  vcmppd xmm15, xmm1, xmm1, 0x03
00007f30a29df204  ptest xmm15, xmm15
00007f30a29df20a  jnz 0x00007F30A29E0F9E
00007f30a29df210  vmovaps xmm15, [rsp+0x50]
00007f30a29df216  vpermilpd xmm15, xmm15, 0x00
00007f30a29df21c  vmovaps xmm5, [rsp+0xC0]
00007f30a29df225  vmovaps [rsp+0xC0], xmm1
00007f30a29df22e  movaps xmm7, xmm5
00007f30a29df231  mulpd xmm7, xmm15
00007f30a29df236  vcmppd xmm1, xmm7, xmm7, 0x03
00007f30a29df23b  ptest xmm1, xmm1
00007f30a29df240  jnz 0x00007F30A29E10DE
00007f30a29df246  lea r12, [rax+0x80]
00007f30a29df24d  movups xmm1, [r13+r12*1]
00007f30a29df253  vmovaps xmm5, [rsp+0x70]
00007f30a29df259  vmovaps [rsp+0x70], xmm1
00007f30a29df25f  movaps xmm15, xmm5
00007f30a29df263  addpd xmm15, xmm3
00007f30a29df268  vcmppd xmm1, xmm15, xmm15, 0x03
00007f30a29df26e  ptest xmm1, xmm1
00007f30a29df273  jnz 0x00007F30A29E1229
00007f30a29df279  vmovaps xmm5, [rsp+0x80]
00007f30a29df282  movaps xmm1, xmm5
00007f30a29df285  addpd xmm1, xmm4
00007f30a29df289  vcmppd xmm3, xmm1, xmm1, 0x03
00007f30a29df28e  ptest xmm3, xmm3
00007f30a29df293  jnz 0x00007F30A29E136B
00007f30a29df299  vmovaps [rsp+0x80], xmm10
00007f30a29df2a2  vmovaps xmm5, [rsp+0x80]
00007f30a29df2ab  por xmm10, xmm5
00007f30a29df2b0  movaps [r15+0x2F0], xmm10
00007f30a29df2b8  vmovaps xmm5, [rsp+0x50]
00007f30a29df2be  vpermilpd xmm5, xmm5, 0x00
00007f30a29df2c4  vmovaps xmm3, [rsp+0x70]
00007f30a29df2ca  vmovaps [rsp+0x50], xmm1
00007f30a29df2d0  movaps xmm4, xmm3
00007f30a29df2d3  mulpd xmm4, xmm5
00007f30a29df2d7  vcmppd xmm1, xmm4, xmm4, 0x03
00007f30a29df2dc  ptest xmm1, xmm1
00007f30a29df2e1  jnz 0x00007F30A29E14AB
00007f30a29df2e7  lea r12, [rax+0xD0]
00007f30a29df2ee  movups xmm1, [r13+r12*1]
00007f30a29df2f4  vmovaps xmm3, [rsp+0xD0]
00007f30a29df2fd  vmovaps [rsp+0x70], xmm1
00007f30a29df303  movaps xmm5, xmm6
00007f30a29df306  addpd xmm5, xmm3
00007f30a29df30a  vcmppd xmm1, xmm5, xmm5, 0x03
00007f30a29df30f  ptest xmm1, xmm1
00007f30a29df314  jnz 0x00007F30A29E15F5
00007f30a29df31a  vmovaps xmm1, [rsp+0x60]
00007f30a29df320  vpermilpd xmm1, xmm1, 0x00
00007f30a29df326  movaps xmm6, xmm9
00007f30a29df32a  mulpd xmm6, xmm1
00007f30a29df32e  vcmppd xmm3, xmm6, xmm6, 0x03
00007f30a29df333  ptest xmm3, xmm3
00007f30a29df338  jnz 0x00007F30A29E1735
00007f30a29df33e  movaps [r15+0x260], xmm6
00007f30a29df346  vxorps xmm1, xmm1, xmm1
00007f30a29df34a  vpbroadcastq xmm1, xmm1
00007f30a29df34f  movaps [r15+0x1B0], xmm1
00007f30a29df357  vmovaps xmm1, [rsp+0x60]
00007f30a29df35d  vpermilpd xmm1, xmm1, 0x00
00007f30a29df363  vmovaps xmm3, [rsp+0x70]
00007f30a29df369  vmovaps [rsp+0x70], xmm15
00007f30a29df36f  movaps xmm9, xmm3
00007f30a29df373  mulpd xmm9, xmm1
00007f30a29df378  vcmppd xmm15, xmm9, xmm9, 0x03
00007f30a29df37e  ptest xmm15, xmm15
00007f30a29df384  jnz 0x00007F30A29E1876
00007f30a29df38a  lea r12, [rax+0xC0]
00007f30a29df391  movups xmm1, [r13+r12*1]
00007f30a29df397  vmovaps xmm3, [rsp+0xC0]
00007f30a29df3a0  vmovaps [rsp+0x80], xmm1
00007f30a29df3a9  movaps xmm15, xmm3
00007f30a29df3ad  addpd xmm15, xmm7
00007f30a29df3b2  vcmppd xmm1, xmm15, xmm15, 0x03
00007f30a29df3b8  ptest xmm1, xmm1
00007f30a29df3bd  jnz 0x00007F30A29E19C2
00007f30a29df3c3  vmovaps [rsp+0xC0], xmm13
00007f30a29df3cc  vmovaps xmm1, [rsp+0xC0]
00007f30a29df3d5  por xmm13, xmm1
00007f30a29df3da  movaps [r15+0x270], xmm13
00007f30a29df3e2  vmovaps xmm1, [rsp+0xB0]
00007f30a29df3eb  vmovaps xmm7, [rsp+0xB0]
00007f30a29df3f4  por xmm1, xmm7
00007f30a29df3f8  movaps [r15+0x1A0], xmm1
00007f30a29df400  vmovaps xmm1, [rsp+0x60]
00007f30a29df406  vpermilpd xmm1, xmm1, 0x00
00007f30a29df40c  vmovaps [rsp+0xB0], xmm1
00007f30a29df415  vmovaps xmm1, [rsp+0x80]
00007f30a29df41e  vmovaps [rsp+0x80], xmm15
00007f30a29df427  vmovaps xmm15, [rsp+0xB0]
00007f30a29df430  vmovaps [rsp+0xB0], xmm14
00007f30a29df439  movaps xmm3, xmm1
00007f30a29df43c  mulpd xmm3, xmm15
00007f30a29df441  vcmppd xmm14, xmm3, xmm3, 0x03
00007f30a29df446  ptest xmm14, xmm14
00007f30a29df44c  jnz 0x00007F30A29E1B04
00007f30a29df452  lea r12, [rax+0x20]
00007f30a29df456  movups xmm1, [r13+r12*1]
00007f30a29df45c  movaps [r15+0x110], xmm1
00007f30a29df464  vmovaps xmm14, [rsp+0x70]
00007f30a29df46a  vmovaps [rsp+0x70], xmm1
00007f30a29df470  movaps xmm15, xmm14
00007f30a29df474  addpd xmm15, xmm4
00007f30a29df479  vcmppd xmm1, xmm15, xmm15, 0x03
00007f30a29df47f  ptest xmm1, xmm1
00007f30a29df484  jnz 0x00007F30A29E1C4F
00007f30a29df48a  vmovaps xmm1, [rsp+0x60]
00007f30a29df490  vpermilpd xmm1, xmm1, 0x00
00007f30a29df496  movaps xmm14, xmm2
00007f30a29df49a  mulpd xmm14, xmm1
00007f30a29df49f  vcmppd xmm4, xmm14, xmm14, 0x03
00007f30a29df4a5  ptest xmm4, xmm4
00007f30a29df4aa  jnz 0x00007F30A29E1D92
00007f30a29df4b0  vmovaps xmm4, [rsp+0x50]
00007f30a29df4b6  movaps xmm1, xmm4
00007f30a29df4b9  addpd xmm1, xmm9
00007f30a29df4be  vcmppd xmm2, xmm1, xmm1, 0x03
00007f30a29df4c3  ptest xmm2, xmm2
00007f30a29df4c8  jnz 0x00007F30A29E1ED4
00007f30a29df4ce  vmovaps xmm9, [rsp+0x30]
00007f30a29df4d4  vpermilpd xmm9, xmm9, 0x00
00007f30a29df4da  vmovaps xmm2, [rsp+0x70]
00007f30a29df4e0  vmovaps [rsp+0x50], xmm1
00007f30a29df4e6  movaps xmm4, xmm2
00007f30a29df4e9  mulpd xmm4, xmm9
00007f30a29df4ee  vcmppd xmm1, xmm4, xmm4, 0x03
00007f30a29df4f3  ptest xmm1, xmm1
00007f30a29df4f8  jnz 0x00007F30A29E2015
00007f30a29df4fe  vmovaps xmm1, [rsp+0x30]
00007f30a29df504  vpermilpd xmm1, xmm1, 0x00
00007f30a29df50a  vmovaps xmm2, [rsp+0x90]
00007f30a29df513  vmovaps [rsp+0x60], xmm15
00007f30a29df519  movaps xmm9, xmm2
00007f30a29df51d  mulpd xmm9, xmm1
00007f30a29df522  vcmppd xmm15, xmm9, xmm9, 0x03
00007f30a29df528  ptest xmm15, xmm15
00007f30a29df52e  jnz 0x00007F30A29E2156
00007f30a29df534  vmovaps xmm15, [rsp+0x80]
00007f30a29df53d  movaps xmm1, xmm15
00007f30a29df541  addpd xmm1, xmm6
00007f30a29df545  vcmppd xmm2, xmm1, xmm1, 0x03
00007f30a29df54a  ptest xmm2, xmm2
00007f30a29df54f  jnz 0x00007F30A29E2298
00007f30a29df555  movaps xmm15, xmm5
00007f30a29df559  addpd xmm15, xmm3
00007f30a29df55e  vcmppd xmm6, xmm15, xmm15, 0x03
00007f30a29df564  ptest xmm6, xmm6
00007f30a29df569  jnz 0x00007F30A29E23D9
00007f30a29df56f  vmovaps xmm6, [rsp+0x30]
00007f30a29df575  vpermilpd xmm6, xmm6, 0x00
00007f30a29df57b  movaps xmm5, xmm8
00007f30a29df57f  mulpd xmm5, xmm6
00007f30a29df583  vcmppd xmm3, xmm5, xmm5, 0x03
00007f30a29df588  ptest xmm3, xmm3
00007f30a29df58d  jnz 0x00007F30A29E251B
00007f30a29df593  vmovaps xmm8, [rsp+0x30]
00007f30a29df599  vpermilpd xmm8, xmm8, 0x00
00007f30a29df59f  movaps xmm6, xmm10
00007f30a29df5a3  mulpd xmm6, xmm8
00007f30a29df5a8  vcmppd xmm3, xmm6, xmm6, 0x03
00007f30a29df5ad  ptest xmm3, xmm3
00007f30a29df5b2  jnz 0x00007F30A29E265C
00007f30a29df5b8  vmovaps xmm8, [rsp+0x60]
00007f30a29df5be  movaps xmm10, xmm8
00007f30a29df5c2  addpd xmm10, xmm14
00007f30a29df5c7  vcmppd xmm3, xmm10, xmm10, 0x03
00007f30a29df5cd  ptest xmm3, xmm3
00007f30a29df5d2  jnz 0x00007F30A29E279E
00007f30a29df5d8  vmovaps xmm8, [rsp+0x50]
00007f30a29df5de  movaps xmm14, xmm8
00007f30a29df5e2  addpd xmm14, xmm4
00007f30a29df5e7  vcmppd xmm3, xmm14, xmm14, 0x03
00007f30a29df5ed  ptest xmm3, xmm3
00007f30a29df5f2  jnz 0x00007F30A29E28E2
00007f30a29df5f8  vmovaps xmm8, [rsp+0x40]
00007f30a29df5fe  vpermilpd xmm8, xmm8, 0x00
00007f30a29df604  movaps xmm4, xmm13
00007f30a29df608  mulpd xmm4, xmm8
00007f30a29df60d  vcmppd xmm3, xmm4, xmm4, 0x03
00007f30a29df612  ptest xmm3, xmm3
00007f30a29df617  jnz 0x00007F30A29E2A25
00007f30a29df61d  movaps xmm13, xmm15
00007f30a29df621  addpd xmm13, xmm9
00007f30a29df626  vcmppd xmm8, xmm13, xmm13, 0x03
00007f30a29df62c  ptest xmm8, xmm8
00007f30a29df632  jnz 0x00007F30A29E2B67
00007f30a29df638  movaps xmm15, xmm1
00007f30a29df63c  addpd xmm15, xmm5
00007f30a29df641  vcmppd xmm9, xmm15, xmm15, 0x03
00007f30a29df647  ptest xmm9, xmm9
00007f30a29df64d  jnz 0x00007F30A29E2CAB
00007f30a29df653  vmovaps [rsp+0x30], xmm11
00007f30a29df659  vmovaps xmm1, [rsp+0x30]
00007f30a29df65f  por xmm11, xmm1
00007f30a29df664  movaps [r15+0x250], xmm11
00007f30a29df66c  vmovaps [rsp+0x30], xmm12
00007f30a29df672  vmovaps xmm1, [rsp+0x30]
00007f30a29df678  por xmm12, xmm1
00007f30a29df67d  movaps [r15+0x2A0], xmm12
00007f30a29df685  vmovaps xmm1, [rsp+0xA0]
00007f30a29df68e  vmovaps xmm11, [rsp+0xA0]
00007f30a29df697  por xmm1, xmm11
00007f30a29df69c  movaps [r15+0x1D0], xmm1
00007f30a29df6a4  lea r12, [rax+0x40]
00007f30a29df6a8  movups xmm1, [r13+r12*1]
00007f30a29df6ae  movaps [r15+0x2C0], xmm1
00007f30a29df6b6  vmovaps xmm11, [rsp+0x40]
00007f30a29df6bc  vpermilpd xmm11, xmm11, 0x00
00007f30a29df6c2  vmovaps xmm8, [rsp+0xE0]
00007f30a29df6cb  movaps xmm9, xmm8
00007f30a29df6cf  mulpd xmm9, xmm11
00007f30a29df6d4  vcmppd xmm5, xmm9, xmm9, 0x03
00007f30a29df6da  ptest xmm5, xmm5
00007f30a29df6df  jnz 0x00007F30A29E2DF7
00007f30a29df6e5  movaps xmm11, xmm10
00007f30a29df6e9  addpd xmm11, xmm6
00007f30a29df6ee  vcmppd xmm8, xmm11, xmm11, 0x03
00007f30a29df6f4  ptest xmm8, xmm8
00007f30a29df6fa  jnz 0x00007F30A29E2F3B
00007f30a29df700  movaps xmm10, xmm14
00007f30a29df704  addpd xmm10, xmm4
00007f30a29df709  vcmppd xmm8, xmm10, xmm10, 0x03
00007f30a29df70f  ptest xmm8, xmm8
00007f30a29df715  jnz 0x00007F30A29E307E
00007f30a29df71b  vmovaps xmm14, [rsp+0x40]
00007f30a29df721  vpermilpd xmm14, xmm14, 0x00
00007f30a29df727  movaps xmm8, xmm1
00007f30a29df72b  mulpd xmm8, xmm14
00007f30a29df730  vcmppd xmm6, xmm8, xmm8, 0x03
00007f30a29df736  ptest xmm6, xmm6
00007f30a29df73b  jnz 0x00007F30A29E31C1
00007f30a29df741  movaps xmm1, [r15+0x2B0]
00007f30a29df749  vmovaps xmm14, [rsp+0x40]
00007f30a29df74f  vpermilpd xmm14, xmm14, 0x00
00007f30a29df755  movaps xmm6, xmm1
00007f30a29df758  mulpd xmm6, xmm14
00007f30a29df75d  vcmppd xmm5, xmm6, xmm6, 0x03
00007f30a29df762  ptest xmm5, xmm5
00007f30a29df767  jnz 0x00007F30A29E3304
00007f30a29df76d  vmovaps xmm1, [rsp+0x10]
00007f30a29df773  vpermilpd xmm1, xmm1, 0x00
00007f30a29df779  movaps xmm14, xmm12
00007f30a29df77d  mulpd xmm14, xmm1
00007f30a29df782  vcmppd xmm5, xmm14, xmm14, 0x03
00007f30a29df788  ptest xmm5, xmm5
00007f30a29df78d  jnz 0x00007F30A29E3445
00007f30a29df793  movaps xmm1, xmm13
00007f30a29df797  addpd xmm1, xmm9
00007f30a29df79c  vcmppd xmm12, xmm1, xmm1, 0x03
00007f30a29df7a1  ptest xmm12, xmm12
00007f30a29df7a7  jnz 0x00007F30A29E3588
00007f30a29df7ad  vmovaps xmm13, [rsp+0x10]
00007f30a29df7b3  vpermilpd xmm13, xmm13, 0x00
00007f30a29df7b9  movaps xmm12, xmm7
00007f30a29df7bd  mulpd xmm12, xmm13
00007f30a29df7c2  vcmppd xmm9, xmm12, xmm12, 0x03
00007f30a29df7c8  ptest xmm9, xmm9
00007f30a29df7ce  jnz 0x00007F30A29E36CA
00007f30a29df7d4  movaps xmm13, xmm15
00007f30a29df7d8  addpd xmm13, xmm8
00007f30a29df7dd  vcmppd xmm9, xmm13, xmm13, 0x03
00007f30a29df7e3  ptest xmm9, xmm9
00007f30a29df7e9  jnz 0x00007F30A29E380D
00007f30a29df7ef  movaps xmm15, [r15+0x290]
00007f30a29df7f7  vmovaps xmm9, [rsp+0x10]
00007f30a29df7fd  vpermilpd xmm9, xmm9, 0x00
00007f30a29df803  movaps xmm8, xmm15
00007f30a29df807  mulpd xmm8, xmm9
00007f30a29df80c  vcmppd xmm7, xmm8, xmm8, 0x03
00007f30a29df812  ptest xmm7, xmm7
00007f30a29df817  jnz 0x00007F30A29E3951
00007f30a29df81d  movaps xmm15, xmm11
00007f30a29df821  addpd xmm15, xmm6
00007f30a29df826  vcmppd xmm9, xmm15, xmm15, 0x03
00007f30a29df82c  ptest xmm9, xmm9
00007f30a29df832  jnz 0x00007F30A29E3A95
00007f30a29df838  movaps xmm11, [r15+0x1E0]
00007f30a29df840  vmovaps xmm9, [rsp+0x10]
00007f30a29df846  vpermilpd xmm9, xmm9, 0x00
00007f30a29df84c  movaps xmm7, xmm11
00007f30a29df850  mulpd xmm7, xmm9
00007f30a29df855  vcmppd xmm6, xmm7, xmm7, 0x03
00007f30a29df85a  ptest xmm6, xmm6
00007f30a29df85f  jnz 0x00007F30A29E3BD8
00007f30a29df865  movaps xmm11, xmm10
00007f30a29df869  addpd xmm11, xmm14
00007f30a29df86e  vcmppd xmm9, xmm11, xmm11, 0x03
00007f30a29df874  ptest xmm9, xmm9
00007f30a29df87a  jnz 0x00007F30A29E3D1A
00007f30a29df880  lea r12, [rax+0x70]
00007f30a29df884  movups xmm14, [r13+r12*1]
00007f30a29df88a  movaps [r15+0x240], xmm14
00007f30a29df892  movaps xmm10, xmm1
00007f30a29df896  addpd xmm10, xmm12
00007f30a29df89b  vcmppd xmm9, xmm10, xmm10, 0x03
00007f30a29df8a1  ptest xmm9, xmm9
00007f30a29df8a7  jnz 0x00007F30A29E3E68
00007f30a29df8ad  movaps [r15+0x170], xmm10
00007f30a29df8b5  vmovaps xmm1, [rsp+0x20]
00007f30a29df8bb  vpermilpd xmm1, xmm1, 0x00
00007f30a29df8c1  movaps xmm12, xmm14
00007f30a29df8c5  mulpd xmm12, xmm1
00007f30a29df8ca  vcmppd xmm9, xmm12, xmm12, 0x03
00007f30a29df8d0  ptest xmm9, xmm9
00007f30a29df8d6  jnz 0x00007F30A29E3FAB
00007f30a29df8dc  vmovaps xmm1, [rsp+0x20]
00007f30a29df8e2  vpermilpd xmm1, xmm1, 0x00
00007f30a29df8e8  vmovaps xmm9, [rsp+0xB0]
00007f30a29df8f1  movaps xmm14, xmm9
00007f30a29df8f5  mulpd xmm14, xmm1
00007f30a29df8fa  vcmppd xmm6, xmm14, xmm14, 0x03
00007f30a29df900  ptest xmm6, xmm6
00007f30a29df905  jnz 0x00007F30A29E40EE
00007f30a29df90b  movaps [r15+0x180], xmm14
00007f30a29df913  movaps xmm1, xmm13
00007f30a29df917  addpd xmm1, xmm8
00007f30a29df91c  vcmppd xmm9, xmm1, xmm1, 0x03
00007f30a29df921  ptest xmm9, xmm9
00007f30a29df927  jnz 0x00007F30A29E4231
00007f30a29df92d  movaps [r15+0x210], xmm1
00007f30a29df935  movups xmm13, [r13+rax*1]
00007f30a29df93b  lea r12, [rax+0x10]
00007f30a29df93f  movups xmm9, [r13+r12*1]
00007f30a29df945  movaps [r15+0x230], xmm9
00007f30a29df94d  movaps xmm8, xmm15
00007f30a29df951  addpd xmm8, xmm7
00007f30a29df956  vcmppd xmm6, xmm8, xmm8, 0x03
00007f30a29df95c  ptest xmm6, xmm6
00007f30a29df961  jnz 0x00007F30A29E4387
00007f30a29df967  movaps [r15+0x130], xmm8
00007f30a29df96f  vmovaps xmm15, [rsp+0x20]
00007f30a29df975  vpermilpd xmm15, xmm15, 0x00
00007f30a29df97b  movaps xmm7, xmm9
00007f30a29df97f  mulpd xmm7, xmm15
00007f30a29df984  vcmppd xmm6, xmm7, xmm7, 0x03
00007f30a29df989  ptest xmm6, xmm6
00007f30a29df98e  jnz 0x00007F30A29E44CA
00007f30a29df994  movaps [r15+0x220], xmm7
00007f30a29df99c  vmovaps xmm15, [rsp+0x20]
00007f30a29df9a2  vpermilpd xmm15, xmm15, 0x00
00007f30a29df9a8  movaps xmm9, xmm13
00007f30a29df9ac  mulpd xmm9, xmm15
00007f30a29df9b1  vcmppd xmm6, xmm9, xmm9, 0x03
00007f30a29df9b7  ptest xmm6, xmm6
00007f30a29df9bc  jnz 0x00007F30A29E460C
00007f30a29df9c2  movaps xmm15, xmm11
00007f30a29df9c6  addpd xmm15, xmm12
00007f30a29df9cb  vcmppd xmm13, xmm15, xmm15, 0x03
00007f30a29df9d1  ptest xmm13, xmm13
00007f30a29df9d7  jnz 0x00007F30A29E4750
00007f30a29df9dd  movaps [r15+0x140], xmm15
00007f30a29df9e5  movaps xmm13, xmm10
00007f30a29df9e9  addpd xmm13, xmm14
00007f30a29df9ee  vcmppd xmm12, xmm13, xmm13, 0x03
00007f30a29df9f4  ptest xmm12, xmm12
00007f30a29df9fa  jnz 0x00007F30A29E4894
00007f30a29dfa00  movaps [r15+0x150], xmm13
00007f30a29dfa08  movaps xmm14, xmm1
00007f30a29dfa0c  addpd xmm14, xmm7
00007f30a29dfa11  vcmppd xmm12, xmm14, xmm14, 0x03
00007f30a29dfa17  ptest xmm12, xmm12
00007f30a29dfa1d  jnz 0x00007F30A29E49D8
00007f30a29dfa23  movaps [r15+0x160], xmm14
00007f30a29dfa2b  movaps xmm1, xmm8
00007f30a29dfa2f  addpd xmm1, xmm9
00007f30a29dfa34  vcmppd xmm12, xmm1, xmm1, 0x03
00007f30a29dfa39  ptest xmm12, xmm12
00007f30a29dfa3f  jnz 0x00007F30A29E4B1A
00007f30a29dfa45  movaps [r15+0x120], xmm1
00007f30a29dfa4d  movups [r13+r14*1], xmm15
00007f30a29dfa53  lea rax, [r14+0x10]
00007f30a29dfa57  movups [r13+rax*1], xmm13
00007f30a29dfa5d  lea rax, [r14+0x20]
00007f30a29dfa61  movups [r13+rax*1], xmm14
00007f30a29dfa67  lea rax, [r14+0x30]
00007f30a29dfa6b  movups [r13+rax*1], xmm1
00007f30a29dfa71  mov eax, [r15+0x108]
00007f30a29dfa78  sahf
00007f30a29dfa79  jnz 0x00007F30A29DFAAB
00007f30a29dfa7b  cmp dword ptr [r15+0x318], 0x00
00007f30a29dfa83  jz 0x00007F30A29DEAE0
00007f30a29dfa89  nop [rax+rax*1], ax
00007f30a29dfa92  nop [rax+rax*1], eax
00007f30a29dfa9a  mov eax, 0x4106D0
00007f30a29dfa9f  mov [r15+0x100], rax
00007f30a29dfaa6  jmp 0x00007F30A27FE110
00007f30a29dfaab  cmp dword ptr [r15+0x318], 0x00
00007f30a29dfab3  jz 0x00007F30A29D89C0
00007f30a29dfab9  nop [rax+rax*1], ax
00007f30a29dfac2  nop [rax+rax*1], eax
00007f30a29dfaca  mov eax, 0x410504
00007f30a29dfacf  mov [r15+0x100], rax
00007f30a29dfad6  jmp 0x00007F30A27FE110
00007f30a29dfadb  int3
00007f30a29dfadc  call 0x00007F30A28E27E0
00007f30a29dfae1  jmp 0x00007F30A29DEBBF
00007f30a29dfae6  call 0x00007F30A28E1570
00007f30a29dfaeb  jmp 0x00007F30A29DEBC8
00007f30a29dfaf0  call 0x00007F30A28E27E0
00007f30a29dfaf5  jmp 0x00007F30A29DEC24
00007f30a29dfafa  call 0x00007F30A28E1570
00007f30a29dfaff  jmp 0x00007F30A29DEC2D
00007f30a29dfb04  call 0x00007F30A28E27E0
00007f30a29dfb09  jmp 0x00007F30A29DEC70
00007f30a29dfb0e  call 0x00007F30A28E1570
00007f30a29dfb13  jmp 0x00007F30A29DEC79
00007f30a29dfb18  call 0x00007F30A280DC20
00007f30a29dfb1d  jmp 0x00007F30A29DECB8
00007f30a29dfb22  call 0x00007F30A28D59C0
00007f30a29dfb27  jmp 0x00007F30A29DECCB
00007f30a29dfb2c  call 0x00007F30A28E0E30
00007f30a29dfb31  jmp 0x00007F30A29DECE9
00007f30a29dfb36  call 0x00007F30A28DFBC0
00007f30a29dfb3b  jmp 0x00007F30A29DECF3
00007f30a29dfb40  call 0x00007F30A28DE950
00007f30a29dfb45  jmp 0x00007F30A29DECFD
00007f30a29dfb4a  sub rsp, 0x08
00007f30a29dfb4e  push rax
00007f30a29dfb4f  push rcx
00007f30a29dfb50  push rdx
00007f30a29dfb51  push rdi
00007f30a29dfb52  push rsi
00007f30a29dfb53  push r8
00007f30a29dfb55  push r9
00007f30a29dfb57  push r10
00007f30a29dfb59  push r11
00007f30a29dfb5b  sub rsp, 0xF0
00007f30a29dfb62  vmovaps [rsp], xmm0
00007f30a29dfb67  vmovaps [rsp+0x10], xmm1
00007f30a29dfb6d  vmovaps [rsp+0x20], xmm2
00007f30a29dfb73  vmovaps [rsp+0x30], xmm3
00007f30a29dfb79  vmovaps [rsp+0x40], xmm4
00007f30a29dfb7f  vmovaps [rsp+0x50], xmm5
00007f30a29dfb85  vmovaps [rsp+0x60], xmm6
00007f30a29dfb8b  vmovaps [rsp+0x70], xmm7
00007f30a29dfb91  vmovaps [rsp+0x80], xmm9
00007f30a29dfb9a  vmovaps [rsp+0x90], xmm10
00007f30a29dfba3  vmovaps [rsp+0xA0], xmm11
00007f30a29dfbac  vmovaps [rsp+0xB0], xmm12
00007f30a29dfbb5  vmovaps [rsp+0xC0], xmm13
00007f30a29dfbbe  vmovaps [rsp+0xD0], xmm14
00007f30a29dfbc7  vmovaps [rsp+0xE0], xmm15
00007f30a29dfbd0  sub rsp, 0x30
00007f30a29dfbd4  movaps [rsp], xmm8
00007f30a29dfbd9  movaps [rsp+0x10], xmm12
00007f30a29dfbdf  movaps [rsp+0x20], xmm15
00007f30a29dfbe5  lea rdi, [rsp]
00007f30a29dfbe9  mov esi, 0x00
00007f30a29dfbee  mov rax, 0x5FE955026530
00007f30a29dfbf8  call rax
00007f30a29dfbfa  movaps xmm8, [rsp]
00007f30a29dfbff  add rsp, 0x30
00007f30a29dfc03  vmovaps xmm0, [rsp]
00007f30a29dfc08  vmovaps xmm1, [rsp+0x10]
00007f30a29dfc0e  vmovaps xmm2, [rsp+0x20]
00007f30a29dfc14  vmovaps xmm3, [rsp+0x30]
00007f30a29dfc1a  vmovaps xmm4, [rsp+0x40]
00007f30a29dfc20  vmovaps xmm5, [rsp+0x50]
00007f30a29dfc26  vmovaps xmm6, [rsp+0x60]
00007f30a29dfc2c  vmovaps xmm7, [rsp+0x70]
00007f30a29dfc32  vmovaps xmm9, [rsp+0x80]
00007f30a29dfc3b  vmovaps xmm10, [rsp+0x90]
00007f30a29dfc44  vmovaps xmm11, [rsp+0xA0]
00007f30a29dfc4d  vmovaps xmm12, [rsp+0xB0]
00007f30a29dfc56  vmovaps xmm13, [rsp+0xC0]
00007f30a29dfc5f  vmovaps xmm14, [rsp+0xD0]
00007f30a29dfc68  vmovaps xmm15, [rsp+0xE0]
00007f30a29dfc71  add rsp, 0xF0
00007f30a29dfc78  pop r11
00007f30a29dfc7a  pop r10
00007f30a29dfc7c  pop r9
00007f30a29dfc7e  pop r8
00007f30a29dfc80  pop rsi
00007f30a29dfc81  pop rdi
00007f30a29dfc82  pop rdx
00007f30a29dfc83  pop rcx
00007f30a29dfc84  pop rax
00007f30a29dfc85  add rsp, 0x08
00007f30a29dfc89  jmp 0x00007F30A29DED27
00007f30a29dfc8e  sub rsp, 0x08
00007f30a29dfc92  push rax
00007f30a29dfc93  push rcx
00007f30a29dfc94  push rdx
00007f30a29dfc95  push rdi
00007f30a29dfc96  push rsi
00007f30a29dfc97  push r8
00007f30a29dfc99  push r9
00007f30a29dfc9b  push r10
00007f30a29dfc9d  push r11
00007f30a29dfc9f  sub rsp, 0xF0
00007f30a29dfca6  vmovaps [rsp], xmm0
00007f30a29dfcab  vmovaps [rsp+0x10], xmm1
00007f30a29dfcb1  vmovaps [rsp+0x20], xmm2
00007f30a29dfcb7  vmovaps [rsp+0x30], xmm3
00007f30a29dfcbd  vmovaps [rsp+0x40], xmm4
00007f30a29dfcc3  vmovaps [rsp+0x50], xmm5
00007f30a29dfcc9  vmovaps [rsp+0x60], xmm6
00007f30a29dfccf  vmovaps [rsp+0x70], xmm8
00007f30a29dfcd5  vmovaps [rsp+0x80], xmm9
00007f30a29dfcde  vmovaps [rsp+0x90], xmm10
00007f30a29dfce7  vmovaps [rsp+0xA0], xmm11
00007f30a29dfcf0  vmovaps [rsp+0xB0], xmm12
00007f30a29dfcf9  vmovaps [rsp+0xC0], xmm13
00007f30a29dfd02  vmovaps [rsp+0xD0], xmm14
00007f30a29dfd0b  vmovaps [rsp+0xE0], xmm15
00007f30a29dfd14  sub rsp, 0x30
00007f30a29dfd18  movaps [rsp], xmm7
00007f30a29dfd1c  movaps [rsp+0x10], xmm9
00007f30a29dfd22  movaps [rsp+0x20], xmm15
00007f30a29dfd28  lea rdi, [rsp]
00007f30a29dfd2c  mov esi, 0x00
00007f30a29dfd31  mov rax, 0x5FE955026530
00007f30a29dfd3b  call rax
00007f30a29dfd3d  movaps xmm7, [rsp]
00007f30a29dfd41  add rsp, 0x30
00007f30a29dfd45  vmovaps xmm0, [rsp]
00007f30a29dfd4a  vmovaps xmm1, [rsp+0x10]
00007f30a29dfd50  vmovaps xmm2, [rsp+0x20]
00007f30a29dfd56  vmovaps xmm3, [rsp+0x30]
00007f30a29dfd5c  vmovaps xmm4, [rsp+0x40]
00007f30a29dfd62  vmovaps xmm5, [rsp+0x50]
00007f30a29dfd68  vmovaps xmm6, [rsp+0x60]
00007f30a29dfd6e  vmovaps xmm8, [rsp+0x70]
00007f30a29dfd74  vmovaps xmm9, [rsp+0x80]
00007f30a29dfd7d  vmovaps xmm10, [rsp+0x90]
00007f30a29dfd86  vmovaps xmm11, [rsp+0xA0]
00007f30a29dfd8f  vmovaps xmm12, [rsp+0xB0]
00007f30a29dfd98  vmovaps xmm13, [rsp+0xC0]
00007f30a29dfda1  vmovaps xmm14, [rsp+0xD0]
00007f30a29dfdaa  vmovaps xmm15, [rsp+0xE0]
00007f30a29dfdb3  add rsp, 0xF0
00007f30a29dfdba  pop r11
00007f30a29dfdbc  pop r10
00007f30a29dfdbe  pop r9
00007f30a29dfdc0  pop r8
00007f30a29dfdc2  pop rsi
00007f30a29dfdc3  pop rdi
00007f30a29dfdc4  pop rdx
00007f30a29dfdc5  pop rcx
00007f30a29dfdc6  pop rax
00007f30a29dfdc7  add rsp, 0x08
00007f30a29dfdcb  jmp 0x00007F30A29DED55
00007f30a29dfdd0  sub rsp, 0x08
00007f30a29dfdd4  push rax
00007f30a29dfdd5  push rcx
00007f30a29dfdd6  push rdx
00007f30a29dfdd7  push rdi
00007f30a29dfdd8  push rsi
00007f30a29dfdd9  push r8
00007f30a29dfddb  push r9
00007f30a29dfddd  push r10
00007f30a29dfddf  push r11
00007f30a29dfde1  sub rsp, 0xF0
00007f30a29dfde8  vmovaps [rsp], xmm0
00007f30a29dfded  vmovaps [rsp+0x10], xmm1
00007f30a29dfdf3  vmovaps [rsp+0x20], xmm2
00007f30a29dfdf9  vmovaps [rsp+0x30], xmm3
00007f30a29dfdff  vmovaps [rsp+0x40], xmm4
00007f30a29dfe05  vmovaps [rsp+0x50], xmm5
00007f30a29dfe0b  vmovaps [rsp+0x60], xmm6
00007f30a29dfe11  vmovaps [rsp+0x70], xmm7
00007f30a29dfe17  vmovaps [rsp+0x80], xmm8
00007f30a29dfe20  vmovaps [rsp+0x90], xmm10
00007f30a29dfe29  vmovaps [rsp+0xA0], xmm11
00007f30a29dfe32  vmovaps [rsp+0xB0], xmm12
00007f30a29dfe3b  vmovaps [rsp+0xC0], xmm13
00007f30a29dfe44  vmovaps [rsp+0xD0], xmm14
00007f30a29dfe4d  vmovaps [rsp+0xE0], xmm15
00007f30a29dfe56  sub rsp, 0x30
00007f30a29dfe5a  movaps [rsp], xmm9
00007f30a29dfe5f  movaps [rsp+0x10], xmm12
00007f30a29dfe65  movaps [rsp+0x20], xmm10
00007f30a29dfe6b  lea rdi, [rsp]
00007f30a29dfe6f  mov esi, 0x00
00007f30a29dfe74  mov rax, 0x5FE955026530
00007f30a29dfe7e  call rax
00007f30a29dfe80  movaps xmm9, [rsp]
00007f30a29dfe85  add rsp, 0x30
00007f30a29dfe89  vmovaps xmm0, [rsp]
00007f30a29dfe8e  vmovaps xmm1, [rsp+0x10]
00007f30a29dfe94  vmovaps xmm2, [rsp+0x20]
00007f30a29dfe9a  vmovaps xmm3, [rsp+0x30]
00007f30a29dfea0  vmovaps xmm4, [rsp+0x40]
00007f30a29dfea6  vmovaps xmm5, [rsp+0x50]
00007f30a29dfeac  vmovaps xmm6, [rsp+0x60]
00007f30a29dfeb2  vmovaps xmm7, [rsp+0x70]
00007f30a29dfeb8  vmovaps xmm8, [rsp+0x80]
00007f30a29dfec1  vmovaps xmm10, [rsp+0x90]
00007f30a29dfeca  vmovaps xmm11, [rsp+0xA0]
00007f30a29dfed3  vmovaps xmm12, [rsp+0xB0]
00007f30a29dfedc  vmovaps xmm13, [rsp+0xC0]
00007f30a29dfee5  vmovaps xmm14, [rsp+0xD0]
00007f30a29dfeee  vmovaps xmm15, [rsp+0xE0]
00007f30a29dfef7  add rsp, 0xF0
00007f30a29dfefe  pop r11
00007f30a29dff00  pop r10
00007f30a29dff02  pop r9
00007f30a29dff04  pop r8
00007f30a29dff06  pop rsi
00007f30a29dff07  pop rdi
00007f30a29dff08  pop rdx
00007f30a29dff09  pop rcx
00007f30a29dff0a  pop rax
00007f30a29dff0b  add rsp, 0x08
00007f30a29dff0f  jmp 0x00007F30A29DED79
00007f30a29dff14  sub rsp, 0x08
00007f30a29dff18  push rax
00007f30a29dff19  push rcx
00007f30a29dff1a  push rdx
00007f30a29dff1b  push rdi
00007f30a29dff1c  push rsi
00007f30a29dff1d  push r8
00007f30a29dff1f  push r9
00007f30a29dff21  push r10
00007f30a29dff23  push r11
00007f30a29dff25  sub rsp, 0xF0
00007f30a29dff2c  vmovaps [rsp], xmm0
00007f30a29dff31  vmovaps [rsp+0x10], xmm1
00007f30a29dff37  vmovaps [rsp+0x20], xmm2
00007f30a29dff3d  vmovaps [rsp+0x30], xmm3
00007f30a29dff43  vmovaps [rsp+0x40], xmm4
00007f30a29dff49  vmovaps [rsp+0x50], xmm5
00007f30a29dff4f  vmovaps [rsp+0x60], xmm6
00007f30a29dff55  vmovaps [rsp+0x70], xmm7
00007f30a29dff5b  vmovaps [rsp+0x80], xmm8
00007f30a29dff64  vmovaps [rsp+0x90], xmm9
00007f30a29dff6d  vmovaps [rsp+0xA0], xmm11
00007f30a29dff76  vmovaps [rsp+0xB0], xmm12
00007f30a29dff7f  vmovaps [rsp+0xC0], xmm13
00007f30a29dff88  vmovaps [rsp+0xD0], xmm14
00007f30a29dff91  vmovaps [rsp+0xE0], xmm15
00007f30a29dff9a  sub rsp, 0x30
00007f30a29dff9e  movaps [rsp], xmm10
00007f30a29dffa3  movaps [rsp+0x10], xmm12
00007f30a29dffa9  movaps [rsp+0x20], xmm11
00007f30a29dffaf  lea rdi, [rsp]
00007f30a29dffb3  mov esi, 0x00
00007f30a29dffb8  mov rax, 0x5FE955026530
00007f30a29dffc2  call rax
00007f30a29dffc4  movaps xmm10, [rsp]
00007f30a29dffc9  add rsp, 0x30
00007f30a29dffcd  vmovaps xmm0, [rsp]
00007f30a29dffd2  vmovaps xmm1, [rsp+0x10]
00007f30a29dffd8  vmovaps xmm2, [rsp+0x20]
00007f30a29dffde  vmovaps xmm3, [rsp+0x30]
00007f30a29dffe4  vmovaps xmm4, [rsp+0x40]
00007f30a29dffea  vmovaps xmm5, [rsp+0x50]
00007f30a29dfff0  vmovaps xmm6, [rsp+0x60]
00007f30a29dfff6  vmovaps xmm7, [rsp+0x70]
00007f30a29dfffc  vmovaps xmm8, [rsp+0x80]
00007f30a29e0005  vmovaps xmm9, [rsp+0x90]
00007f30a29e000e  vmovaps xmm11, [rsp+0xA0]
00007f30a29e0017  vmovaps xmm12, [rsp+0xB0]
00007f30a29e0020  vmovaps xmm13, [rsp+0xC0]
00007f30a29e0029  vmovaps xmm14, [rsp+0xD0]
00007f30a29e0032  vmovaps xmm15, [rsp+0xE0]
00007f30a29e003b  add rsp, 0xF0
00007f30a29e0042  pop r11
00007f30a29e0044  pop r10
00007f30a29e0046  pop r9
00007f30a29e0048  pop r8
00007f30a29e004a  pop rsi
00007f30a29e004b  pop rdi
00007f30a29e004c  pop rdx
00007f30a29e004d  pop rcx
00007f30a29e004e  pop rax
00007f30a29e004f  add rsp, 0x08
00007f30a29e0053  jmp 0x00007F30A29DED93
00007f30a29e0058  sub rsp, 0x08
00007f30a29e005c  push rax
00007f30a29e005d  push rcx
00007f30a29e005e  push rdx
00007f30a29e005f  push rdi
00007f30a29e0060  push rsi
00007f30a29e0061  push r8
00007f30a29e0063  push r9
00007f30a29e0065  push r10
00007f30a29e0067  push r11
00007f30a29e0069  sub rsp, 0xF0
00007f30a29e0070  vmovaps [rsp], xmm0
00007f30a29e0075  vmovaps [rsp+0x10], xmm1
00007f30a29e007b  vmovaps [rsp+0x20], xmm2
00007f30a29e0081  vmovaps [rsp+0x30], xmm3
00007f30a29e0087  vmovaps [rsp+0x40], xmm4
00007f30a29e008d  vmovaps [rsp+0x50], xmm5
00007f30a29e0093  vmovaps [rsp+0x60], xmm7
00007f30a29e0099  vmovaps [rsp+0x70], xmm8
00007f30a29e009f  vmovaps [rsp+0x80], xmm9
00007f30a29e00a8  vmovaps [rsp+0x90], xmm10
00007f30a29e00b1  vmovaps [rsp+0xA0], xmm11
00007f30a29e00ba  vmovaps [rsp+0xB0], xmm12
00007f30a29e00c3  vmovaps [rsp+0xC0], xmm13
00007f30a29e00cc  vmovaps [rsp+0xD0], xmm14
00007f30a29e00d5  vmovaps [rsp+0xE0], xmm15
00007f30a29e00de  sub rsp, 0x30
00007f30a29e00e2  movaps [rsp], xmm6
00007f30a29e00e6  movaps [rsp+0x10], xmm12
00007f30a29e00ec  movaps [rsp+0x20], xmm11
00007f30a29e00f2  lea rdi, [rsp]
00007f30a29e00f6  mov esi, 0x00
00007f30a29e00fb  mov rax, 0x5FE955026530
00007f30a29e0105  call rax
00007f30a29e0107  movaps xmm6, [rsp]
00007f30a29e010b  add rsp, 0x30
00007f30a29e010f  vmovaps xmm0, [rsp]
00007f30a29e0114  vmovaps xmm1, [rsp+0x10]
00007f30a29e011a  vmovaps xmm2, [rsp+0x20]
00007f30a29e0120  vmovaps xmm3, [rsp+0x30]
00007f30a29e0126  vmovaps xmm4, [rsp+0x40]
00007f30a29e012c  vmovaps xmm5, [rsp+0x50]
00007f30a29e0132  vmovaps xmm7, [rsp+0x60]
00007f30a29e0138  vmovaps xmm8, [rsp+0x70]
00007f30a29e013e  vmovaps xmm9, [rsp+0x80]
00007f30a29e0147  vmovaps xmm10, [rsp+0x90]
00007f30a29e0150  vmovaps xmm11, [rsp+0xA0]
00007f30a29e0159  vmovaps xmm12, [rsp+0xB0]
00007f30a29e0162  vmovaps xmm13, [rsp+0xC0]
00007f30a29e016b  vmovaps xmm14, [rsp+0xD0]
00007f30a29e0174  vmovaps xmm15, [rsp+0xE0]
00007f30a29e017d  add rsp, 0xF0
00007f30a29e0184  pop r11
00007f30a29e0186  pop r10
00007f30a29e0188  pop r9
00007f30a29e018a  pop r8
00007f30a29e018c  pop rsi
00007f30a29e018d  pop rdi
00007f30a29e018e  pop rdx
00007f30a29e018f  pop rcx
00007f30a29e0190  pop rax
00007f30a29e0191  add rsp, 0x08
00007f30a29e0195  jmp 0x00007F30A29DEDB4
00007f30a29e019a  sub rsp, 0x08
00007f30a29e019e  push rax
00007f30a29e019f  push rcx
00007f30a29e01a0  push rdx
00007f30a29e01a1  push rdi
00007f30a29e01a2  push rsi
00007f30a29e01a3  push r8
00007f30a29e01a5  push r9
00007f30a29e01a7  push r10
00007f30a29e01a9  push r11
00007f30a29e01ab  sub rsp, 0xF0
00007f30a29e01b2  vmovaps [rsp], xmm0
00007f30a29e01b7  vmovaps [rsp+0x10], xmm1
00007f30a29e01bd  vmovaps [rsp+0x20], xmm2
00007f30a29e01c3  vmovaps [rsp+0x30], xmm4
00007f30a29e01c9  vmovaps [rsp+0x40], xmm5
00007f30a29e01cf  vmovaps [rsp+0x50], xmm6
00007f30a29e01d5  vmovaps [rsp+0x60], xmm7
00007f30a29e01db  vmovaps [rsp+0x70], xmm8
00007f30a29e01e1  vmovaps [rsp+0x80], xmm9
00007f30a29e01ea  vmovaps [rsp+0x90], xmm10
00007f30a29e01f3  vmovaps [rsp+0xA0], xmm11
00007f30a29e01fc  vmovaps [rsp+0xB0], xmm12
00007f30a29e0205  vmovaps [rsp+0xC0], xmm13
00007f30a29e020e  vmovaps [rsp+0xD0], xmm14
00007f30a29e0217  vmovaps [rsp+0xE0], xmm15
00007f30a29e0220  sub rsp, 0x30
00007f30a29e0224  movaps [rsp], xmm3
00007f30a29e0228  movaps [rsp+0x10], xmm5
00007f30a29e022d  movaps [rsp+0x20], xmm4
00007f30a29e0232  lea rdi, [rsp]
00007f30a29e0236  mov esi, 0x00
00007f30a29e023b  mov rax, 0x5FE955026530
00007f30a29e0245  call rax
00007f30a29e0247  movaps xmm3, [rsp]
00007f30a29e024b  add rsp, 0x30
00007f30a29e024f  vmovaps xmm0, [rsp]
00007f30a29e0254  vmovaps xmm1, [rsp+0x10]
00007f30a29e025a  vmovaps xmm2, [rsp+0x20]
00007f30a29e0260  vmovaps xmm4, [rsp+0x30]
00007f30a29e0266  vmovaps xmm5, [rsp+0x40]
00007f30a29e026c  vmovaps xmm6, [rsp+0x50]
00007f30a29e0272  vmovaps xmm7, [rsp+0x60]
00007f30a29e0278  vmovaps xmm8, [rsp+0x70]
00007f30a29e027e  vmovaps xmm9, [rsp+0x80]
00007f30a29e0287  vmovaps xmm10, [rsp+0x90]
00007f30a29e0290  vmovaps xmm11, [rsp+0xA0]
00007f30a29e0299  vmovaps xmm12, [rsp+0xB0]
00007f30a29e02a2  vmovaps xmm13, [rsp+0xC0]
00007f30a29e02ab  vmovaps xmm14, [rsp+0xD0]
00007f30a29e02b4  vmovaps xmm15, [rsp+0xE0]
00007f30a29e02bd  add rsp, 0xF0
00007f30a29e02c4  pop r11
00007f30a29e02c6  pop r10
00007f30a29e02c8  pop r9
00007f30a29e02ca  pop r8
00007f30a29e02cc  pop rsi
00007f30a29e02cd  pop rdi
00007f30a29e02ce  pop rdx
00007f30a29e02cf  pop rcx
00007f30a29e02d0  pop rax
00007f30a29e02d1  add rsp, 0x08
00007f30a29e02d5  jmp 0x00007F30A29DEE15
00007f30a29e02da  sub rsp, 0x08
00007f30a29e02de  push rax
00007f30a29e02df  push rcx
00007f30a29e02e0  push rdx
00007f30a29e02e1  push rdi
00007f30a29e02e2  push rsi
00007f30a29e02e3  push r8
00007f30a29e02e5  push r9
00007f30a29e02e7  push r10
00007f30a29e02e9  push r11
00007f30a29e02eb  sub rsp, 0xF0
00007f30a29e02f2  vmovaps [rsp], xmm0
00007f30a29e02f7  vmovaps [rsp+0x10], xmm1
00007f30a29e02fd  vmovaps [rsp+0x20], xmm2
00007f30a29e0303  vmovaps [rsp+0x30], xmm3
00007f30a29e0309  vmovaps [rsp+0x40], xmm4
00007f30a29e030f  vmovaps [rsp+0x50], xmm6
00007f30a29e0315  vmovaps [rsp+0x60], xmm7
00007f30a29e031b  vmovaps [rsp+0x70], xmm8
00007f30a29e0321  vmovaps [rsp+0x80], xmm9
00007f30a29e032a  vmovaps [rsp+0x90], xmm10
00007f30a29e0333  vmovaps [rsp+0xA0], xmm11
00007f30a29e033c  vmovaps [rsp+0xB0], xmm12
00007f30a29e0345  vmovaps [rsp+0xC0], xmm13
00007f30a29e034e  vmovaps [rsp+0xD0], xmm14
00007f30a29e0357  vmovaps [rsp+0xE0], xmm15
00007f30a29e0360  sub rsp, 0x30
00007f30a29e0364  movaps [rsp], xmm5
00007f30a29e0368  movaps [rsp+0x10], xmm8
00007f30a29e036e  movaps [rsp+0x20], xmm15
00007f30a29e0374  lea rdi, [rsp]
00007f30a29e0378  mov esi, 0x00
00007f30a29e037d  mov rax, 0x5FE955026530
00007f30a29e0387  call rax
00007f30a29e0389  movaps xmm5, [rsp]
00007f30a29e038d  add rsp, 0x30
00007f30a29e0391  vmovaps xmm0, [rsp]
00007f30a29e0396  vmovaps xmm1, [rsp+0x10]
00007f30a29e039c  vmovaps xmm2, [rsp+0x20]
00007f30a29e03a2  vmovaps xmm3, [rsp+0x30]
00007f30a29e03a8  vmovaps xmm4, [rsp+0x40]
00007f30a29e03ae  vmovaps xmm6, [rsp+0x50]
00007f30a29e03b4  vmovaps xmm7, [rsp+0x60]
00007f30a29e03ba  vmovaps xmm8, [rsp+0x70]
00007f30a29e03c0  vmovaps xmm9, [rsp+0x80]
00007f30a29e03c9  vmovaps xmm10, [rsp+0x90]
00007f30a29e03d2  vmovaps xmm11, [rsp+0xA0]
00007f30a29e03db  vmovaps xmm12, [rsp+0xB0]
00007f30a29e03e4  vmovaps xmm13, [rsp+0xC0]
00007f30a29e03ed  vmovaps xmm14, [rsp+0xD0]
00007f30a29e03f6  vmovaps xmm15, [rsp+0xE0]
00007f30a29e03ff  add rsp, 0xF0
00007f30a29e0406  pop r11
00007f30a29e0408  pop r10
00007f30a29e040a  pop r9
00007f30a29e040c  pop r8
00007f30a29e040e  pop rsi
00007f30a29e040f  pop rdi
00007f30a29e0410  pop rdx
00007f30a29e0411  pop rcx
00007f30a29e0412  pop rax
00007f30a29e0413  add rsp, 0x08
00007f30a29e0417  jmp 0x00007F30A29DEE53
00007f30a29e041c  sub rsp, 0x08
00007f30a29e0420  push rax
00007f30a29e0421  push rcx
00007f30a29e0422  push rdx
00007f30a29e0423  push rdi
00007f30a29e0424  push rsi
00007f30a29e0425  push r8
00007f30a29e0427  push r9
00007f30a29e0429  push r10
00007f30a29e042b  push r11
00007f30a29e042d  sub rsp, 0xF0
00007f30a29e0434  vmovaps [rsp], xmm0
00007f30a29e0439  vmovaps [rsp+0x10], xmm1
00007f30a29e043f  vmovaps [rsp+0x20], xmm2
00007f30a29e0445  vmovaps [rsp+0x30], xmm3
00007f30a29e044b  vmovaps [rsp+0x40], xmm5
00007f30a29e0451  vmovaps [rsp+0x50], xmm6
00007f30a29e0457  vmovaps [rsp+0x60], xmm7
00007f30a29e045d  vmovaps [rsp+0x70], xmm8
00007f30a29e0463  vmovaps [rsp+0x80], xmm9
00007f30a29e046c  vmovaps [rsp+0x90], xmm10
00007f30a29e0475  vmovaps [rsp+0xA0], xmm11
00007f30a29e047e  vmovaps [rsp+0xB0], xmm12
00007f30a29e0487  vmovaps [rsp+0xC0], xmm13
00007f30a29e0490  vmovaps [rsp+0xD0], xmm14
00007f30a29e0499  vmovaps [rsp+0xE0], xmm15
00007f30a29e04a2  sub rsp, 0x30
00007f30a29e04a6  movaps [rsp], xmm4
00007f30a29e04aa  movaps [rsp+0x10], xmm9
00007f30a29e04b0  movaps [rsp+0x20], xmm8
00007f30a29e04b6  lea rdi, [rsp]
00007f30a29e04ba  mov esi, 0x00
00007f30a29e04bf  mov rax, 0x5FE955026530
00007f30a29e04c9  call rax
00007f30a29e04cb  movaps xmm4, [rsp]
00007f30a29e04cf  add rsp, 0x30
00007f30a29e04d3  vmovaps xmm0, [rsp]
00007f30a29e04d8  vmovaps xmm1, [rsp+0x10]
00007f30a29e04de  vmovaps xmm2, [rsp+0x20]
00007f30a29e04e4  vmovaps xmm3, [rsp+0x30]
00007f30a29e04ea  vmovaps xmm5, [rsp+0x40]
00007f30a29e04f0  vmovaps xmm6, [rsp+0x50]
00007f30a29e04f6  vmovaps xmm7, [rsp+0x60]
00007f30a29e04fc  vmovaps xmm8, [rsp+0x70]
00007f30a29e0502  vmovaps xmm9, [rsp+0x80]
00007f30a29e050b  vmovaps xmm10, [rsp+0x90]
00007f30a29e0514  vmovaps xmm11, [rsp+0xA0]
00007f30a29e051d  vmovaps xmm12, [rsp+0xB0]
00007f30a29e0526  vmovaps xmm13, [rsp+0xC0]
00007f30a29e052f  vmovaps xmm14, [rsp+0xD0]
00007f30a29e0538  vmovaps xmm15, [rsp+0xE0]
00007f30a29e0541  add rsp, 0xF0
00007f30a29e0548  pop r11
00007f30a29e054a  pop r10
00007f30a29e054c  pop r9
00007f30a29e054e  pop r8
00007f30a29e0550  pop rsi
00007f30a29e0551  pop rdi
00007f30a29e0552  pop rdx
00007f30a29e0553  pop rcx
00007f30a29e0554  pop rax
00007f30a29e0555  add rsp, 0x08
00007f30a29e0559  jmp 0x00007F30A29DEE74
00007f30a29e055e  sub rsp, 0x08
00007f30a29e0562  push rax
00007f30a29e0563  push rcx
00007f30a29e0564  push rdx
00007f30a29e0565  push rdi
00007f30a29e0566  push rsi
00007f30a29e0567  push r8
00007f30a29e0569  push r9
00007f30a29e056b  push r10
00007f30a29e056d  push r11
00007f30a29e056f  sub rsp, 0xF0
00007f30a29e0576  vmovaps [rsp], xmm0
00007f30a29e057b  vmovaps [rsp+0x10], xmm1
00007f30a29e0581  vmovaps [rsp+0x20], xmm2
00007f30a29e0587  vmovaps [rsp+0x30], xmm3
00007f30a29e058d  vmovaps [rsp+0x40], xmm4
00007f30a29e0593  vmovaps [rsp+0x50], xmm5
00007f30a29e0599  vmovaps [rsp+0x60], xmm6
00007f30a29e059f  vmovaps [rsp+0x70], xmm7
00007f30a29e05a5  vmovaps [rsp+0x80], xmm8
00007f30a29e05ae  vmovaps [rsp+0x90], xmm10
00007f30a29e05b7  vmovaps [rsp+0xA0], xmm11
00007f30a29e05c0  vmovaps [rsp+0xB0], xmm12
00007f30a29e05c9  vmovaps [rsp+0xC0], xmm13
00007f30a29e05d2  vmovaps [rsp+0xD0], xmm14
00007f30a29e05db  vmovaps [rsp+0xE0], xmm15
00007f30a29e05e4  sub rsp, 0x30
00007f30a29e05e8  movaps [rsp], xmm9
00007f30a29e05ed  movaps [rsp+0x10], xmm10
00007f30a29e05f3  movaps [rsp+0x20], xmm8
00007f30a29e05f9  lea rdi, [rsp]
00007f30a29e05fd  mov esi, 0x00
00007f30a29e0602  mov rax, 0x5FE955026530
00007f30a29e060c  call rax
00007f30a29e060e  movaps xmm9, [rsp]
00007f30a29e0613  add rsp, 0x30
00007f30a29e0617  vmovaps xmm0, [rsp]
00007f30a29e061c  vmovaps xmm1, [rsp+0x10]
00007f30a29e0622  vmovaps xmm2, [rsp+0x20]
00007f30a29e0628  vmovaps xmm3, [rsp+0x30]
00007f30a29e062e  vmovaps xmm4, [rsp+0x40]
00007f30a29e0634  vmovaps xmm5, [rsp+0x50]
00007f30a29e063a  vmovaps xmm6, [rsp+0x60]
00007f30a29e0640  vmovaps xmm7, [rsp+0x70]
00007f30a29e0646  vmovaps xmm8, [rsp+0x80]
00007f30a29e064f  vmovaps xmm10, [rsp+0x90]
00007f30a29e0658  vmovaps xmm11, [rsp+0xA0]
00007f30a29e0661  vmovaps xmm12, [rsp+0xB0]
00007f30a29e066a  vmovaps xmm13, [rsp+0xC0]
00007f30a29e0673  vmovaps xmm14, [rsp+0xD0]
00007f30a29e067c  vmovaps xmm15, [rsp+0xE0]
00007f30a29e0685  add rsp, 0xF0
00007f30a29e068c  pop r11
00007f30a29e068e  pop r10
00007f30a29e0690  pop r9
00007f30a29e0692  pop r8
00007f30a29e0694  pop rsi
00007f30a29e0695  pop rdi
00007f30a29e0696  pop rdx
00007f30a29e0697  pop rcx
00007f30a29e0698  pop rax
00007f30a29e0699  add rsp, 0x08
00007f30a29e069d  jmp 0x00007F30A29DEE8E
00007f30a29e06a2  call 0x00007F30A28B52F0
00007f30a29e06a7  jmp 0x00007F30A29DEFA8
00007f30a29e06ac  call 0x00007F30A28B52F0
00007f30a29e06b1  jmp 0x00007F30A29DEFBE
00007f30a29e06b6  sub rsp, 0x08
00007f30a29e06ba  push rax
00007f30a29e06bb  push rcx
00007f30a29e06bc  push rdx
00007f30a29e06bd  push rdi
00007f30a29e06be  push rsi
00007f30a29e06bf  push r8
00007f30a29e06c1  push r9
00007f30a29e06c3  push r10
00007f30a29e06c5  push r11
00007f30a29e06c7  sub rsp, 0xF0
00007f30a29e06ce  vmovaps [rsp], xmm0
00007f30a29e06d3  vmovaps [rsp+0x10], xmm2
00007f30a29e06d9  vmovaps [rsp+0x20], xmm3
00007f30a29e06df  vmovaps [rsp+0x30], xmm4
00007f30a29e06e5  vmovaps [rsp+0x40], xmm5
00007f30a29e06eb  vmovaps [rsp+0x50], xmm6
00007f30a29e06f1  vmovaps [rsp+0x60], xmm7
00007f30a29e06f7  vmovaps [rsp+0x70], xmm8
00007f30a29e06fd  vmovaps [rsp+0x80], xmm9
00007f30a29e0706  vmovaps [rsp+0x90], xmm10
00007f30a29e070f  vmovaps [rsp+0xA0], xmm11
00007f30a29e0718  vmovaps [rsp+0xB0], xmm12
00007f30a29e0721  vmovaps [rsp+0xC0], xmm13
00007f30a29e072a  vmovaps [rsp+0xD0], xmm14
00007f30a29e0733  vmovaps [rsp+0xE0], xmm15
00007f30a29e073c  sub rsp, 0x30
00007f30a29e0740  movaps [rsp], xmm1
00007f30a29e0744  movaps [rsp+0x10], xmm6
00007f30a29e0749  movaps [rsp+0x20], xmm15
00007f30a29e074f  lea rdi, [rsp]
00007f30a29e0753  mov esi, 0x00
00007f30a29e0758  mov rax, 0x5FE955026530
00007f30a29e0762  call rax
00007f30a29e0764  movaps xmm1, [rsp]
00007f30a29e0768  add rsp, 0x30
00007f30a29e076c  vmovaps xmm0, [rsp]
00007f30a29e0771  vmovaps xmm2, [rsp+0x10]
00007f30a29e0777  vmovaps xmm3, [rsp+0x20]
00007f30a29e077d  vmovaps xmm4, [rsp+0x30]
00007f30a29e0783  vmovaps xmm5, [rsp+0x40]
00007f30a29e0789  vmovaps xmm6, [rsp+0x50]
00007f30a29e078f  vmovaps xmm7, [rsp+0x60]
00007f30a29e0795  vmovaps xmm8, [rsp+0x70]
00007f30a29e079b  vmovaps xmm9, [rsp+0x80]
00007f30a29e07a4  vmovaps xmm10, [rsp+0x90]
00007f30a29e07ad  vmovaps xmm11, [rsp+0xA0]
00007f30a29e07b6  vmovaps xmm12, [rsp+0xB0]
00007f30a29e07bf  vmovaps xmm13, [rsp+0xC0]
00007f30a29e07c8  vmovaps xmm14, [rsp+0xD0]
00007f30a29e07d1  vmovaps xmm15, [rsp+0xE0]
00007f30a29e07da  add rsp, 0xF0
00007f30a29e07e1  pop r11
00007f30a29e07e3  pop r10
00007f30a29e07e5  pop r9
00007f30a29e07e7  pop r8
00007f30a29e07e9  pop rsi
00007f30a29e07ea  pop rdi
00007f30a29e07eb  pop rdx
00007f30a29e07ec  pop rcx
00007f30a29e07ed  pop rax
00007f30a29e07ee  add rsp, 0x08
00007f30a29e07f2  jmp 0x00007F30A29DEFFB
00007f30a29e07f7  call 0x00007F30A28C4620
00007f30a29e07fc  jmp 0x00007F30A29DF008
00007f30a29e0801  sub rsp, 0x08
00007f30a29e0805  push rax
00007f30a29e0806  push rcx
00007f30a29e0807  push rdx
00007f30a29e0808  push rdi
00007f30a29e0809  push rsi
00007f30a29e080a  push r8
00007f30a29e080c  push r9
00007f30a29e080e  push r10
00007f30a29e0810  push r11
00007f30a29e0812  sub rsp, 0xF0
00007f30a29e0819  vmovaps [rsp], xmm0
00007f30a29e081e  vmovaps [rsp+0x10], xmm1
00007f30a29e0824  vmovaps [rsp+0x20], xmm2
00007f30a29e082a  vmovaps [rsp+0x30], xmm3
00007f30a29e0830  vmovaps [rsp+0x40], xmm4
00007f30a29e0836  vmovaps [rsp+0x50], xmm5
00007f30a29e083c  vmovaps [rsp+0x60], xmm6
00007f30a29e0842  vmovaps [rsp+0x70], xmm7
00007f30a29e0848  vmovaps [rsp+0x80], xmm8
00007f30a29e0851  vmovaps [rsp+0x90], xmm9
00007f30a29e085a  vmovaps [rsp+0xA0], xmm10
00007f30a29e0863  vmovaps [rsp+0xB0], xmm11
00007f30a29e086c  vmovaps [rsp+0xC0], xmm12
00007f30a29e0875  vmovaps [rsp+0xD0], xmm13
00007f30a29e087e  vmovaps [rsp+0xE0], xmm15
00007f30a29e0887  sub rsp, 0x30
00007f30a29e088b  movaps [rsp], xmm14
00007f30a29e0890  movaps [rsp+0x10], xmm4
00007f30a29e0895  movaps [rsp+0x20], xmm3
00007f30a29e089a  lea rdi, [rsp]
00007f30a29e089e  mov esi, 0x00
00007f30a29e08a3  mov rax, 0x5FE955026530
00007f30a29e08ad  call rax
00007f30a29e08af  movaps xmm14, [rsp]
00007f30a29e08b4  add rsp, 0x30
00007f30a29e08b8  vmovaps xmm0, [rsp]
00007f30a29e08bd  vmovaps xmm1, [rsp+0x10]
00007f30a29e08c3  vmovaps xmm2, [rsp+0x20]
00007f30a29e08c9  vmovaps xmm3, [rsp+0x30]
00007f30a29e08cf  vmovaps xmm4, [rsp+0x40]
00007f30a29e08d5  vmovaps xmm5, [rsp+0x50]
00007f30a29e08db  vmovaps xmm6, [rsp+0x60]
00007f30a29e08e1  vmovaps xmm7, [rsp+0x70]
00007f30a29e08e7  vmovaps xmm8, [rsp+0x80]
00007f30a29e08f0  vmovaps xmm9, [rsp+0x90]
00007f30a29e08f9  vmovaps xmm10, [rsp+0xA0]
00007f30a29e0902  vmovaps xmm11, [rsp+0xB0]
00007f30a29e090b  vmovaps xmm12, [rsp+0xC0]
00007f30a29e0914  vmovaps xmm13, [rsp+0xD0]
00007f30a29e091d  vmovaps xmm15, [rsp+0xE0]
00007f30a29e0926  add rsp, 0xF0
00007f30a29e092d  pop r11
00007f30a29e092f  pop r10
00007f30a29e0931  pop r9
00007f30a29e0933  pop r8
00007f30a29e0935  pop rsi
00007f30a29e0936  pop rdi
00007f30a29e0937  pop rdx
00007f30a29e0938  pop rcx
00007f30a29e0939  pop rax
00007f30a29e093a  add rsp, 0x08
00007f30a29e093e  jmp 0x00007F30A29DF022
00007f30a29e0943  sub rsp, 0x08
00007f30a29e0947  push rax
00007f30a29e0948  push rcx
00007f30a29e0949  push rdx
00007f30a29e094a  push rdi
00007f30a29e094b  push rsi
00007f30a29e094c  push r8
00007f30a29e094e  push r9
00007f30a29e0950  push r10
00007f30a29e0952  push r11
00007f30a29e0954  sub rsp, 0xF0
00007f30a29e095b  vmovaps [rsp], xmm0
00007f30a29e0960  vmovaps [rsp+0x10], xmm1
00007f30a29e0966  vmovaps [rsp+0x20], xmm2
00007f30a29e096c  vmovaps [rsp+0x30], xmm3
00007f30a29e0972  vmovaps [rsp+0x40], xmm4
00007f30a29e0978  vmovaps [rsp+0x50], xmm5
00007f30a29e097e  vmovaps [rsp+0x60], xmm7
00007f30a29e0984  vmovaps [rsp+0x70], xmm8
00007f30a29e098a  vmovaps [rsp+0x80], xmm9
00007f30a29e0993  vmovaps [rsp+0x90], xmm10
00007f30a29e099c  vmovaps [rsp+0xA0], xmm11
00007f30a29e09a5  vmovaps [rsp+0xB0], xmm12
00007f30a29e09ae  vmovaps [rsp+0xC0], xmm13
00007f30a29e09b7  vmovaps [rsp+0xD0], xmm14
00007f30a29e09c0  vmovaps [rsp+0xE0], xmm15
00007f30a29e09c9  sub rsp, 0x30
00007f30a29e09cd  movaps [rsp], xmm6
00007f30a29e09d1  movaps [rsp+0x10], xmm9
00007f30a29e09d7  movaps [rsp+0x20], xmm7
00007f30a29e09dc  lea rdi, [rsp]
00007f30a29e09e0  mov esi, 0x00
00007f30a29e09e5  mov rax, 0x5FE955026530
00007f30a29e09ef  call rax
00007f30a29e09f1  movaps xmm6, [rsp]
00007f30a29e09f5  add rsp, 0x30
00007f30a29e09f9  vmovaps xmm0, [rsp]
00007f30a29e09fe  vmovaps xmm1, [rsp+0x10]
00007f30a29e0a04  vmovaps xmm2, [rsp+0x20]
00007f30a29e0a0a  vmovaps xmm3, [rsp+0x30]
00007f30a29e0a10  vmovaps xmm4, [rsp+0x40]
00007f30a29e0a16  vmovaps xmm5, [rsp+0x50]
00007f30a29e0a1c  vmovaps xmm7, [rsp+0x60]
00007f30a29e0a22  vmovaps xmm8, [rsp+0x70]
00007f30a29e0a28  vmovaps xmm9, [rsp+0x80]
00007f30a29e0a31  vmovaps xmm10, [rsp+0x90]
00007f30a29e0a3a  vmovaps xmm11, [rsp+0xA0]
00007f30a29e0a43  vmovaps xmm12, [rsp+0xB0]
00007f30a29e0a4c  vmovaps xmm13, [rsp+0xC0]
00007f30a29e0a55  vmovaps xmm14, [rsp+0xD0]
00007f30a29e0a5e  vmovaps xmm15, [rsp+0xE0]
00007f30a29e0a67  add rsp, 0xF0
00007f30a29e0a6e  pop r11
00007f30a29e0a70  pop r10
00007f30a29e0a72  pop r9
00007f30a29e0a74  pop r8
00007f30a29e0a76  pop rsi
00007f30a29e0a77  pop rdi
00007f30a29e0a78  pop rdx
00007f30a29e0a79  pop rcx
00007f30a29e0a7a  pop rax
00007f30a29e0a7b  add rsp, 0x08
00007f30a29e0a7f  jmp 0x00007F30A29DF03A
00007f30a29e0a84  sub rsp, 0x08
00007f30a29e0a88  push rax
00007f30a29e0a89  push rcx
00007f30a29e0a8a  push rdx
00007f30a29e0a8b  push rdi
00007f30a29e0a8c  push rsi
00007f30a29e0a8d  push r8
00007f30a29e0a8f  push r9
00007f30a29e0a91  push r10
00007f30a29e0a93  push r11
00007f30a29e0a95  sub rsp, 0xF0
00007f30a29e0a9c  vmovaps [rsp], xmm0
00007f30a29e0aa1  vmovaps [rsp+0x10], xmm1
00007f30a29e0aa7  vmovaps [rsp+0x20], xmm2
00007f30a29e0aad  vmovaps [rsp+0x30], xmm3
00007f30a29e0ab3  vmovaps [rsp+0x40], xmm4
00007f30a29e0ab9  vmovaps [rsp+0x50], xmm5
00007f30a29e0abf  vmovaps [rsp+0x60], xmm6
00007f30a29e0ac5  vmovaps [rsp+0x70], xmm8
00007f30a29e0acb  vmovaps [rsp+0x80], xmm9
00007f30a29e0ad4  vmovaps [rsp+0x90], xmm10
00007f30a29e0add  vmovaps [rsp+0xA0], xmm11
00007f30a29e0ae6  vmovaps [rsp+0xB0], xmm12
00007f30a29e0aef  vmovaps [rsp+0xC0], xmm13
00007f30a29e0af8  vmovaps [rsp+0xD0], xmm14
00007f30a29e0b01  vmovaps [rsp+0xE0], xmm15
00007f30a29e0b0a  sub rsp, 0x30
00007f30a29e0b0e  movaps [rsp], xmm7
00007f30a29e0b12  movaps [rsp+0x10], xmm4
00007f30a29e0b17  movaps [rsp+0x20], xmm9
00007f30a29e0b1d  lea rdi, [rsp]
00007f30a29e0b21  mov esi, 0x00
00007f30a29e0b26  mov rax, 0x5FE955026530
00007f30a29e0b30  call rax
00007f30a29e0b32  movaps xmm7, [rsp]
00007f30a29e0b36  add rsp, 0x30
00007f30a29e0b3a  vmovaps xmm0, [rsp]
00007f30a29e0b3f  vmovaps xmm1, [rsp+0x10]
00007f30a29e0b45  vmovaps xmm2, [rsp+0x20]
00007f30a29e0b4b  vmovaps xmm3, [rsp+0x30]
00007f30a29e0b51  vmovaps xmm4, [rsp+0x40]
00007f30a29e0b57  vmovaps xmm5, [rsp+0x50]
00007f30a29e0b5d  vmovaps xmm6, [rsp+0x60]
00007f30a29e0b63  vmovaps xmm8, [rsp+0x70]
00007f30a29e0b69  vmovaps xmm9, [rsp+0x80]
00007f30a29e0b72  vmovaps xmm10, [rsp+0x90]
00007f30a29e0b7b  vmovaps xmm11, [rsp+0xA0]
00007f30a29e0b84  vmovaps xmm12, [rsp+0xB0]
00007f30a29e0b8d  vmovaps xmm13, [rsp+0xC0]
00007f30a29e0b96  vmovaps xmm14, [rsp+0xD0]
00007f30a29e0b9f  vmovaps xmm15, [rsp+0xE0]
00007f30a29e0ba8  add rsp, 0xF0
00007f30a29e0baf  pop r11
00007f30a29e0bb1  pop r10
00007f30a29e0bb3  pop r9
00007f30a29e0bb5  pop r8
00007f30a29e0bb7  pop rsi
00007f30a29e0bb8  pop rdi
00007f30a29e0bb9  pop rdx
00007f30a29e0bba  pop rcx
00007f30a29e0bbb  pop rax
00007f30a29e0bbc  add rsp, 0x08
00007f30a29e0bc0  jmp 0x00007F30A29DF067
00007f30a29e0bc5  sub rsp, 0x08
00007f30a29e0bc9  push rax
00007f30a29e0bca  push rcx
00007f30a29e0bcb  push rdx
00007f30a29e0bcc  push rdi
00007f30a29e0bcd  push rsi
00007f30a29e0bce  push r8
00007f30a29e0bd0  push r9
00007f30a29e0bd2  push r10
00007f30a29e0bd4  push r11
00007f30a29e0bd6  sub rsp, 0xF0
00007f30a29e0bdd  vmovaps [rsp], xmm0
00007f30a29e0be2  vmovaps [rsp+0x10], xmm1
00007f30a29e0be8  vmovaps [rsp+0x20], xmm2
00007f30a29e0bee  vmovaps [rsp+0x30], xmm3
00007f30a29e0bf4  vmovaps [rsp+0x40], xmm5
00007f30a29e0bfa  vmovaps [rsp+0x50], xmm6
00007f30a29e0c00  vmovaps [rsp+0x60], xmm7
00007f30a29e0c06  vmovaps [rsp+0x70], xmm8
00007f30a29e0c0c  vmovaps [rsp+0x80], xmm9
00007f30a29e0c15  vmovaps [rsp+0x90], xmm10
00007f30a29e0c1e  vmovaps [rsp+0xA0], xmm11
00007f30a29e0c27  vmovaps [rsp+0xB0], xmm12
00007f30a29e0c30  vmovaps [rsp+0xC0], xmm13
00007f30a29e0c39  vmovaps [rsp+0xD0], xmm14
00007f30a29e0c42  vmovaps [rsp+0xE0], xmm15
00007f30a29e0c4b  sub rsp, 0x30
00007f30a29e0c4f  movaps [rsp], xmm4
00007f30a29e0c53  movaps [rsp+0x10], xmm15
00007f30a29e0c59  movaps [rsp+0x20], xmm9
00007f30a29e0c5f  lea rdi, [rsp]
00007f30a29e0c63  mov esi, 0x00
00007f30a29e0c68  mov rax, 0x5FE955026530
00007f30a29e0c72  call rax
00007f30a29e0c74  movaps xmm4, [rsp]
00007f30a29e0c78  add rsp, 0x30
00007f30a29e0c7c  vmovaps xmm0, [rsp]
00007f30a29e0c81  vmovaps xmm1, [rsp+0x10]
00007f30a29e0c87  vmovaps xmm2, [rsp+0x20]
00007f30a29e0c8d  vmovaps xmm3, [rsp+0x30]
00007f30a29e0c93  vmovaps xmm5, [rsp+0x40]
00007f30a29e0c99  vmovaps xmm6, [rsp+0x50]
00007f30a29e0c9f  vmovaps xmm7, [rsp+0x60]
00007f30a29e0ca5  vmovaps xmm8, [rsp+0x70]
00007f30a29e0cab  vmovaps xmm9, [rsp+0x80]
00007f30a29e0cb4  vmovaps xmm10, [rsp+0x90]
00007f30a29e0cbd  vmovaps xmm11, [rsp+0xA0]
00007f30a29e0cc6  vmovaps xmm12, [rsp+0xB0]
00007f30a29e0ccf  vmovaps xmm13, [rsp+0xC0]
00007f30a29e0cd8  vmovaps xmm14, [rsp+0xD0]
00007f30a29e0ce1  vmovaps xmm15, [rsp+0xE0]
00007f30a29e0cea  add rsp, 0xF0
00007f30a29e0cf1  pop r11
00007f30a29e0cf3  pop r10
00007f30a29e0cf5  pop r9
00007f30a29e0cf7  pop r8
00007f30a29e0cf9  pop rsi
00007f30a29e0cfa  pop rdi
00007f30a29e0cfb  pop rdx
00007f30a29e0cfc  pop rcx
00007f30a29e0cfd  pop rax
00007f30a29e0cfe  add rsp, 0x08
00007f30a29e0d02  jmp 0x00007F30A29DF08C
00007f30a29e0d07  call 0x00007F30A28C4620
00007f30a29e0d0c  jmp 0x00007F30A29DF099
00007f30a29e0d11  sub rsp, 0x08
00007f30a29e0d15  push rax
00007f30a29e0d16  push rcx
00007f30a29e0d17  push rdx
00007f30a29e0d18  push rdi
00007f30a29e0d19  push rsi
00007f30a29e0d1a  push r8
00007f30a29e0d1c  push r9
00007f30a29e0d1e  push r10
00007f30a29e0d20  push r11
00007f30a29e0d22  sub rsp, 0xF0
00007f30a29e0d29  vmovaps [rsp], xmm0
00007f30a29e0d2e  vmovaps [rsp+0x10], xmm1
00007f30a29e0d34  vmovaps [rsp+0x20], xmm2
00007f30a29e0d3a  vmovaps [rsp+0x30], xmm4
00007f30a29e0d40  vmovaps [rsp+0x40], xmm5
00007f30a29e0d46  vmovaps [rsp+0x50], xmm6
00007f30a29e0d4c  vmovaps [rsp+0x60], xmm7
00007f30a29e0d52  vmovaps [rsp+0x70], xmm8
00007f30a29e0d58  vmovaps [rsp+0x80], xmm9
00007f30a29e0d61  vmovaps [rsp+0x90], xmm10
00007f30a29e0d6a  vmovaps [rsp+0xA0], xmm11
00007f30a29e0d73  vmovaps [rsp+0xB0], xmm12
00007f30a29e0d7c  vmovaps [rsp+0xC0], xmm13
00007f30a29e0d85  vmovaps [rsp+0xD0], xmm14
00007f30a29e0d8e  vmovaps [rsp+0xE0], xmm15
00007f30a29e0d97  sub rsp, 0x30
00007f30a29e0d9b  movaps [rsp], xmm3
00007f30a29e0d9f  movaps [rsp+0x10], xmm1
00007f30a29e0da4  movaps [rsp+0x20], xmm9
00007f30a29e0daa  lea rdi, [rsp]
00007f30a29e0dae  mov esi, 0x00
00007f30a29e0db3  mov rax, 0x5FE955026530
00007f30a29e0dbd  call rax
00007f30a29e0dbf  movaps xmm3, [rsp]
00007f30a29e0dc3  add rsp, 0x30
00007f30a29e0dc7  vmovaps xmm0, [rsp]
00007f30a29e0dcc  vmovaps xmm1, [rsp+0x10]
00007f30a29e0dd2  vmovaps xmm2, [rsp+0x20]
00007f30a29e0dd8  vmovaps xmm4, [rsp+0x30]
00007f30a29e0dde  vmovaps xmm5, [rsp+0x40]
00007f30a29e0de4  vmovaps xmm6, [rsp+0x50]
00007f30a29e0dea  vmovaps xmm7, [rsp+0x60]
00007f30a29e0df0  vmovaps xmm8, [rsp+0x70]
00007f30a29e0df6  vmovaps xmm9, [rsp+0x80]
00007f30a29e0dff  vmovaps xmm10, [rsp+0x90]
00007f30a29e0e08  vmovaps xmm11, [rsp+0xA0]
00007f30a29e0e11  vmovaps xmm12, [rsp+0xB0]
00007f30a29e0e1a  vmovaps xmm13, [rsp+0xC0]
00007f30a29e0e23  vmovaps xmm14, [rsp+0xD0]
00007f30a29e0e2c  vmovaps xmm15, [rsp+0xE0]
00007f30a29e0e35  add rsp, 0xF0
00007f30a29e0e3c  pop r11
00007f30a29e0e3e  pop r10
00007f30a29e0e40  pop r9
00007f30a29e0e42  pop r8
00007f30a29e0e44  pop rsi
00007f30a29e0e45  pop rdi
00007f30a29e0e46  pop rdx
00007f30a29e0e47  pop rcx
00007f30a29e0e48  pop rax
00007f30a29e0e49  add rsp, 0x08
00007f30a29e0e4d  jmp 0x00007F30A29DF0D6
00007f30a29e0e52  sub rsp, 0x08
00007f30a29e0e56  push rax
00007f30a29e0e57  push rcx
00007f30a29e0e58  push rdx
00007f30a29e0e59  push rdi
00007f30a29e0e5a  push rsi
00007f30a29e0e5b  push r8
00007f30a29e0e5d  push r9
00007f30a29e0e5f  push r10
00007f30a29e0e61  push r11
00007f30a29e0e63  sub rsp, 0xF0
00007f30a29e0e6a  vmovaps [rsp], xmm0
00007f30a29e0e6f  vmovaps [rsp+0x10], xmm2
00007f30a29e0e75  vmovaps [rsp+0x20], xmm3
00007f30a29e0e7b  vmovaps [rsp+0x30], xmm4
00007f30a29e0e81  vmovaps [rsp+0x40], xmm5
00007f30a29e0e87  vmovaps [rsp+0x50], xmm6
00007f30a29e0e8d  vmovaps [rsp+0x60], xmm7
00007f30a29e0e93  vmovaps [rsp+0x70], xmm8
00007f30a29e0e99  vmovaps [rsp+0x80], xmm9
00007f30a29e0ea2  vmovaps [rsp+0x90], xmm10
00007f30a29e0eab  vmovaps [rsp+0xA0], xmm11
00007f30a29e0eb4  vmovaps [rsp+0xB0], xmm12
00007f30a29e0ebd  vmovaps [rsp+0xC0], xmm13
00007f30a29e0ec6  vmovaps [rsp+0xD0], xmm14
00007f30a29e0ecf  vmovaps [rsp+0xE0], xmm15
00007f30a29e0ed8  sub rsp, 0x30
00007f30a29e0edc  movaps [rsp], xmm1
00007f30a29e0ee0  movaps [rsp+0x10], xmm15
00007f30a29e0ee6  movaps [rsp+0x20], xmm9
00007f30a29e0eec  lea rdi, [rsp]
00007f30a29e0ef0  mov esi, 0x00
00007f30a29e0ef5  mov rax, 0x5FE955026530
00007f30a29e0eff  call rax
00007f30a29e0f01  movaps xmm1, [rsp]
00007f30a29e0f05  add rsp, 0x30
00007f30a29e0f09  vmovaps xmm0, [rsp]
00007f30a29e0f0e  vmovaps xmm2, [rsp+0x10]
00007f30a29e0f14  vmovaps xmm3, [rsp+0x20]
00007f30a29e0f1a  vmovaps xmm4, [rsp+0x30]
00007f30a29e0f20  vmovaps xmm5, [rsp+0x40]
00007f30a29e0f26  vmovaps xmm6, [rsp+0x50]
00007f30a29e0f2c  vmovaps xmm7, [rsp+0x60]
00007f30a29e0f32  vmovaps xmm8, [rsp+0x70]
00007f30a29e0f38  vmovaps xmm9, [rsp+0x80]
00007f30a29e0f41  vmovaps xmm10, [rsp+0x90]
00007f30a29e0f4a  vmovaps xmm11, [rsp+0xA0]
00007f30a29e0f53  vmovaps xmm12, [rsp+0xB0]
00007f30a29e0f5c  vmovaps xmm13, [rsp+0xC0]
00007f30a29e0f65  vmovaps xmm14, [rsp+0xD0]
00007f30a29e0f6e  vmovaps xmm15, [rsp+0xE0]
00007f30a29e0f77  add rsp, 0xF0
00007f30a29e0f7e  pop r11
00007f30a29e0f80  pop r10
00007f30a29e0f82  pop r9
00007f30a29e0f84  pop r8
00007f30a29e0f86  pop rsi
00007f30a29e0f87  pop rdi
00007f30a29e0f88  pop rdx
00007f30a29e0f89  pop rcx
00007f30a29e0f8a  pop rax
00007f30a29e0f8b  add rsp, 0x08
00007f30a29e0f8f  jmp 0x00007F30A29DF15E
00007f30a29e0f94  call 0x00007F30A28C4620
00007f30a29e0f99  jmp 0x00007F30A29DF16B
00007f30a29e0f9e  sub rsp, 0x08
00007f30a29e0fa2  push rax
00007f30a29e0fa3  push rcx
00007f30a29e0fa4  push rdx
00007f30a29e0fa5  push rdi
00007f30a29e0fa6  push rsi
00007f30a29e0fa7  push r8
00007f30a29e0fa9  push r9
00007f30a29e0fab  push r10
00007f30a29e0fad  push r11
00007f30a29e0faf  sub rsp, 0xF0
00007f30a29e0fb6  vmovaps [rsp], xmm0
00007f30a29e0fbb  vmovaps [rsp+0x10], xmm2
00007f30a29e0fc1  vmovaps [rsp+0x20], xmm3
00007f30a29e0fc7  vmovaps [rsp+0x30], xmm4
00007f30a29e0fcd  vmovaps [rsp+0x40], xmm5
00007f30a29e0fd3  vmovaps [rsp+0x50], xmm6
00007f30a29e0fd9  vmovaps [rsp+0x60], xmm7
00007f30a29e0fdf  vmovaps [rsp+0x70], xmm8
00007f30a29e0fe5  vmovaps [rsp+0x80], xmm9
00007f30a29e0fee  vmovaps [rsp+0x90], xmm10
00007f30a29e0ff7  vmovaps [rsp+0xA0], xmm11
00007f30a29e1000  vmovaps [rsp+0xB0], xmm12
00007f30a29e1009  vmovaps [rsp+0xC0], xmm13
00007f30a29e1012  vmovaps [rsp+0xD0], xmm14
00007f30a29e101b  vmovaps [rsp+0xE0], xmm15
00007f30a29e1024  sub rsp, 0x30
00007f30a29e1028  movaps [rsp], xmm1
00007f30a29e102c  movaps [rsp+0x10], xmm5
00007f30a29e1031  movaps [rsp+0x20], xmm7
00007f30a29e1036  lea rdi, [rsp]
00007f30a29e103a  mov esi, 0x00
00007f30a29e103f  mov rax, 0x5FE955026530
00007f30a29e1049  call rax
00007f30a29e104b  movaps xmm1, [rsp]
00007f30a29e104f  add rsp, 0x30
00007f30a29e1053  vmovaps xmm0, [rsp]
00007f30a29e1058  vmovaps xmm2, [rsp+0x10]
00007f30a29e105e  vmovaps xmm3, [rsp+0x20]
00007f30a29e1064  vmovaps xmm4, [rsp+0x30]
00007f30a29e106a  vmovaps xmm5, [rsp+0x40]
00007f30a29e1070  vmovaps xmm6, [rsp+0x50]
00007f30a29e1076  vmovaps xmm7, [rsp+0x60]
00007f30a29e107c  vmovaps xmm8, [rsp+0x70]
00007f30a29e1082  vmovaps xmm9, [rsp+0x80]
00007f30a29e108b  vmovaps xmm10, [rsp+0x90]
00007f30a29e1094  vmovaps xmm11, [rsp+0xA0]
00007f30a29e109d  vmovaps xmm12, [rsp+0xB0]
00007f30a29e10a6  vmovaps xmm13, [rsp+0xC0]
00007f30a29e10af  vmovaps xmm14, [rsp+0xD0]
00007f30a29e10b8  vmovaps xmm15, [rsp+0xE0]
00007f30a29e10c1  add rsp, 0xF0
00007f30a29e10c8  pop r11
00007f30a29e10ca  pop r10
00007f30a29e10cc  pop r9
00007f30a29e10ce  pop r8
00007f30a29e10d0  pop rsi
00007f30a29e10d1  pop rdi
00007f30a29e10d2  pop rdx
00007f30a29e10d3  pop rcx
00007f30a29e10d4  pop rax
00007f30a29e10d5  add rsp, 0x08
00007f30a29e10d9  jmp 0x00007F30A29DF210
00007f30a29e10de  sub rsp, 0x08
00007f30a29e10e2  push rax
00007f30a29e10e3  push rcx
00007f30a29e10e4  push rdx
00007f30a29e10e5  push rdi
00007f30a29e10e6  push rsi
00007f30a29e10e7  push r8
00007f30a29e10e9  push r9
00007f30a29e10eb  push r10
00007f30a29e10ed  push r11
00007f30a29e10ef  sub rsp, 0xF0
00007f30a29e10f6  vmovaps [rsp], xmm0
00007f30a29e10fb  vmovaps [rsp+0x10], xmm1
00007f30a29e1101  vmovaps [rsp+0x20], xmm2
00007f30a29e1107  vmovaps [rsp+0x30], xmm3
00007f30a29e110d  vmovaps [rsp+0x40], xmm4
00007f30a29e1113  vmovaps [rsp+0x50], xmm5
00007f30a29e1119  vmovaps [rsp+0x60], xmm6
00007f30a29e111f  vmovaps [rsp+0x70], xmm8
00007f30a29e1125  vmovaps [rsp+0x80], xmm9
00007f30a29e112e  vmovaps [rsp+0x90], xmm10
00007f30a29e1137  vmovaps [rsp+0xA0], xmm11
00007f30a29e1140  vmovaps [rsp+0xB0], xmm12
00007f30a29e1149  vmovaps [rsp+0xC0], xmm13
00007f30a29e1152  vmovaps [rsp+0xD0], xmm14
00007f30a29e115b  vmovaps [rsp+0xE0], xmm15
00007f30a29e1164  sub rsp, 0x30
00007f30a29e1168  movaps [rsp], xmm7
00007f30a29e116c  movaps [rsp+0x10], xmm5
00007f30a29e1171  movaps [rsp+0x20], xmm15
00007f30a29e1177  lea rdi, [rsp]
00007f30a29e117b  mov esi, 0x00
00007f30a29e1180  mov rax, 0x5FE955026530
00007f30a29e118a  call rax
00007f30a29e118c  movaps xmm7, [rsp]
00007f30a29e1190  add rsp, 0x30
00007f30a29e1194  vmovaps xmm0, [rsp]
00007f30a29e1199  vmovaps xmm1, [rsp+0x10]
00007f30a29e119f  vmovaps xmm2, [rsp+0x20]
00007f30a29e11a5  vmovaps xmm3, [rsp+0x30]
00007f30a29e11ab  vmovaps xmm4, [rsp+0x40]
00007f30a29e11b1  vmovaps xmm5, [rsp+0x50]
00007f30a29e11b7  vmovaps xmm6, [rsp+0x60]
00007f30a29e11bd  vmovaps xmm8, [rsp+0x70]
00007f30a29e11c3  vmovaps xmm9, [rsp+0x80]
00007f30a29e11cc  vmovaps xmm10, [rsp+0x90]
00007f30a29e11d5  vmovaps xmm11, [rsp+0xA0]
00007f30a29e11de  vmovaps xmm12, [rsp+0xB0]
00007f30a29e11e7  vmovaps xmm13, [rsp+0xC0]
00007f30a29e11f0  vmovaps xmm14, [rsp+0xD0]
00007f30a29e11f9  vmovaps xmm15, [rsp+0xE0]
00007f30a29e1202  add rsp, 0xF0
00007f30a29e1209  pop r11
00007f30a29e120b  pop r10
00007f30a29e120d  pop r9
00007f30a29e120f  pop r8
00007f30a29e1211  pop rsi
00007f30a29e1212  pop rdi
00007f30a29e1213  pop rdx
00007f30a29e1214  pop rcx
00007f30a29e1215  pop rax
00007f30a29e1216  add rsp, 0x08
00007f30a29e121a  jmp 0x00007F30A29DF246
00007f30a29e121f  call 0x00007F30A28B52F0
00007f30a29e1224  jmp 0x00007F30A29DF253
00007f30a29e1229  sub rsp, 0x08
00007f30a29e122d  push rax
00007f30a29e122e  push rcx
00007f30a29e122f  push rdx
00007f30a29e1230  push rdi
00007f30a29e1231  push rsi
00007f30a29e1232  push r8
00007f30a29e1234  push r9
00007f30a29e1236  push r10
00007f30a29e1238  push r11
00007f30a29e123a  sub rsp, 0xF0
00007f30a29e1241  vmovaps [rsp], xmm0
00007f30a29e1246  vmovaps [rsp+0x10], xmm1
00007f30a29e124c  vmovaps [rsp+0x20], xmm2
00007f30a29e1252  vmovaps [rsp+0x30], xmm3
00007f30a29e1258  vmovaps [rsp+0x40], xmm4
00007f30a29e125e  vmovaps [rsp+0x50], xmm5
00007f30a29e1264  vmovaps [rsp+0x60], xmm6
00007f30a29e126a  vmovaps [rsp+0x70], xmm7
00007f30a29e1270  vmovaps [rsp+0x80], xmm8
00007f30a29e1279  vmovaps [rsp+0x90], xmm9
00007f30a29e1282  vmovaps [rsp+0xA0], xmm10
00007f30a29e128b  vmovaps [rsp+0xB0], xmm11
00007f30a29e1294  vmovaps [rsp+0xC0], xmm12
00007f30a29e129d  vmovaps [rsp+0xD0], xmm13
00007f30a29e12a6  vmovaps [rsp+0xE0], xmm14
00007f30a29e12af  sub rsp, 0x30
00007f30a29e12b3  movaps [rsp], xmm15
00007f30a29e12b8  movaps [rsp+0x10], xmm5
00007f30a29e12bd  movaps [rsp+0x20], xmm3
00007f30a29e12c2  lea rdi, [rsp]
00007f30a29e12c6  mov esi, 0x00
00007f30a29e12cb  mov rax, 0x5FE955026530
00007f30a29e12d5  call rax
00007f30a29e12d7  movaps xmm15, [rsp]
00007f30a29e12dc  add rsp, 0x30
00007f30a29e12e0  vmovaps xmm0, [rsp]
00007f30a29e12e5  vmovaps xmm1, [rsp+0x10]
00007f30a29e12eb  vmovaps xmm2, [rsp+0x20]
00007f30a29e12f1  vmovaps xmm3, [rsp+0x30]
00007f30a29e12f7  vmovaps xmm4, [rsp+0x40]
00007f30a29e12fd  vmovaps xmm5, [rsp+0x50]
00007f30a29e1303  vmovaps xmm6, [rsp+0x60]
00007f30a29e1309  vmovaps xmm7, [rsp+0x70]
00007f30a29e130f  vmovaps xmm8, [rsp+0x80]
00007f30a29e1318  vmovaps xmm9, [rsp+0x90]
00007f30a29e1321  vmovaps xmm10, [rsp+0xA0]
00007f30a29e132a  vmovaps xmm11, [rsp+0xB0]
00007f30a29e1333  vmovaps xmm12, [rsp+0xC0]
00007f30a29e133c  vmovaps xmm13, [rsp+0xD0]
00007f30a29e1345  vmovaps xmm14, [rsp+0xE0]
00007f30a29e134e  add rsp, 0xF0
00007f30a29e1355  pop r11
00007f30a29e1357  pop r10
00007f30a29e1359  pop r9
00007f30a29e135b  pop r8
00007f30a29e135d  pop rsi
00007f30a29e135e  pop rdi
00007f30a29e135f  pop rdx
00007f30a29e1360  pop rcx
00007f30a29e1361  pop rax
00007f30a29e1362  add rsp, 0x08
00007f30a29e1366  jmp 0x00007F30A29DF279
00007f30a29e136b  sub rsp, 0x08
00007f30a29e136f  push rax
00007f30a29e1370  push rcx
00007f30a29e1371  push rdx
00007f30a29e1372  push rdi
00007f30a29e1373  push rsi
00007f30a29e1374  push r8
00007f30a29e1376  push r9
00007f30a29e1378  push r10
00007f30a29e137a  push r11
00007f30a29e137c  sub rsp, 0xF0
00007f30a29e1383  vmovaps [rsp], xmm0
00007f30a29e1388  vmovaps [rsp+0x10], xmm2
00007f30a29e138e  vmovaps [rsp+0x20], xmm3
00007f30a29e1394  vmovaps [rsp+0x30], xmm4
00007f30a29e139a  vmovaps [rsp+0x40], xmm5
00007f30a29e13a0  vmovaps [rsp+0x50], xmm6
00007f30a29e13a6  vmovaps [rsp+0x60], xmm7
00007f30a29e13ac  vmovaps [rsp+0x70], xmm8
00007f30a29e13b2  vmovaps [rsp+0x80], xmm9
00007f30a29e13bb  vmovaps [rsp+0x90], xmm10
00007f30a29e13c4  vmovaps [rsp+0xA0], xmm11
00007f30a29e13cd  vmovaps [rsp+0xB0], xmm12
00007f30a29e13d6  vmovaps [rsp+0xC0], xmm13
00007f30a29e13df  vmovaps [rsp+0xD0], xmm14
00007f30a29e13e8  vmovaps [rsp+0xE0], xmm15
00007f30a29e13f1  sub rsp, 0x30
00007f30a29e13f5  movaps [rsp], xmm1
00007f30a29e13f9  movaps [rsp+0x10], xmm5
00007f30a29e13fe  movaps [rsp+0x20], xmm4
00007f30a29e1403  lea rdi, [rsp]
00007f30a29e1407  mov esi, 0x00
00007f30a29e140c  mov rax, 0x5FE955026530
00007f30a29e1416  call rax
00007f30a29e1418  movaps xmm1, [rsp]
00007f30a29e141c  add rsp, 0x30
00007f30a29e1420  vmovaps xmm0, [rsp]
00007f30a29e1425  vmovaps xmm2, [rsp+0x10]
00007f30a29e142b  vmovaps xmm3, [rsp+0x20]
00007f30a29e1431  vmovaps xmm4, [rsp+0x30]
00007f30a29e1437  vmovaps xmm5, [rsp+0x40]
00007f30a29e143d  vmovaps xmm6, [rsp+0x50]
00007f30a29e1443  vmovaps xmm7, [rsp+0x60]
00007f30a29e1449  vmovaps xmm8, [rsp+0x70]
00007f30a29e144f  vmovaps xmm9, [rsp+0x80]
00007f30a29e1458  vmovaps xmm10, [rsp+0x90]
00007f30a29e1461  vmovaps xmm11, [rsp+0xA0]
00007f30a29e146a  vmovaps xmm12, [rsp+0xB0]
00007f30a29e1473  vmovaps xmm13, [rsp+0xC0]
00007f30a29e147c  vmovaps xmm14, [rsp+0xD0]
00007f30a29e1485  vmovaps xmm15, [rsp+0xE0]
00007f30a29e148e  add rsp, 0xF0
00007f30a29e1495  pop r11
00007f30a29e1497  pop r10
00007f30a29e1499  pop r9
00007f30a29e149b  pop r8
00007f30a29e149d  pop rsi
00007f30a29e149e  pop rdi
00007f30a29e149f  pop rdx
00007f30a29e14a0  pop rcx
00007f30a29e14a1  pop rax
00007f30a29e14a2  add rsp, 0x08
00007f30a29e14a6  jmp 0x00007F30A29DF299
00007f30a29e14ab  sub rsp, 0x08
00007f30a29e14af  push rax
00007f30a29e14b0  push rcx
00007f30a29e14b1  push rdx
00007f30a29e14b2  push rdi
00007f30a29e14b3  push rsi
00007f30a29e14b4  push r8
00007f30a29e14b6  push r9
00007f30a29e14b8  push r10
00007f30a29e14ba  push r11
00007f30a29e14bc  sub rsp, 0xF0
00007f30a29e14c3  vmovaps [rsp], xmm0
00007f30a29e14c8  vmovaps [rsp+0x10], xmm1
00007f30a29e14ce  vmovaps [rsp+0x20], xmm2
00007f30a29e14d4  vmovaps [rsp+0x30], xmm3
00007f30a29e14da  vmovaps [rsp+0x40], xmm5
00007f30a29e14e0  vmovaps [rsp+0x50], xmm6
00007f30a29e14e6  vmovaps [rsp+0x60], xmm7
00007f30a29e14ec  vmovaps [rsp+0x70], xmm8
00007f30a29e14f2  vmovaps [rsp+0x80], xmm9
00007f30a29e14fb  vmovaps [rsp+0x90], xmm10
00007f30a29e1504  vmovaps [rsp+0xA0], xmm11
00007f30a29e150d  vmovaps [rsp+0xB0], xmm12
00007f30a29e1516  vmovaps [rsp+0xC0], xmm13
00007f30a29e151f  vmovaps [rsp+0xD0], xmm14
00007f30a29e1528  vmovaps [rsp+0xE0], xmm15
00007f30a29e1531  sub rsp, 0x30
00007f30a29e1535  movaps [rsp], xmm4
00007f30a29e1539  movaps [rsp+0x10], xmm3
00007f30a29e153e  movaps [rsp+0x20], xmm5
00007f30a29e1543  lea rdi, [rsp]
00007f30a29e1547  mov esi, 0x00
00007f30a29e154c  mov rax, 0x5FE955026530
00007f30a29e1556  call rax
00007f30a29e1558  movaps xmm4, [rsp]
00007f30a29e155c  add rsp, 0x30
00007f30a29e1560  vmovaps xmm0, [rsp]
00007f30a29e1565  vmovaps xmm1, [rsp+0x10]
00007f30a29e156b  vmovaps xmm2, [rsp+0x20]
00007f30a29e1571  vmovaps xmm3, [rsp+0x30]
00007f30a29e1577  vmovaps xmm5, [rsp+0x40]
00007f30a29e157d  vmovaps xmm6, [rsp+0x50]
00007f30a29e1583  vmovaps xmm7, [rsp+0x60]
00007f30a29e1589  vmovaps xmm8, [rsp+0x70]
00007f30a29e158f  vmovaps xmm9, [rsp+0x80]
00007f30a29e1598  vmovaps xmm10, [rsp+0x90]
00007f30a29e15a1  vmovaps xmm11, [rsp+0xA0]
00007f30a29e15aa  vmovaps xmm12, [rsp+0xB0]
00007f30a29e15b3  vmovaps xmm13, [rsp+0xC0]
00007f30a29e15bc  vmovaps xmm14, [rsp+0xD0]
00007f30a29e15c5  vmovaps xmm15, [rsp+0xE0]
00007f30a29e15ce  add rsp, 0xF0
00007f30a29e15d5  pop r11
00007f30a29e15d7  pop r10
00007f30a29e15d9  pop r9
00007f30a29e15db  pop r8
00007f30a29e15dd  pop rsi
00007f30a29e15de  pop rdi
00007f30a29e15df  pop rdx
00007f30a29e15e0  pop rcx
00007f30a29e15e1  pop rax
00007f30a29e15e2  add rsp, 0x08
00007f30a29e15e6  jmp 0x00007F30A29DF2E7
00007f30a29e15eb  call 0x00007F30A28B52F0
00007f30a29e15f0  jmp 0x00007F30A29DF2F4
00007f30a29e15f5  sub rsp, 0x08
00007f30a29e15f9  push rax
00007f30a29e15fa  push rcx
00007f30a29e15fb  push rdx
00007f30a29e15fc  push rdi
00007f30a29e15fd  push rsi
00007f30a29e15fe  push r8
00007f30a29e1600  push r9
00007f30a29e1602  push r10
00007f30a29e1604  push r11
00007f30a29e1606  sub rsp, 0xF0
00007f30a29e160d  vmovaps [rsp], xmm0
00007f30a29e1612  vmovaps [rsp+0x10], xmm1
00007f30a29e1618  vmovaps [rsp+0x20], xmm2
00007f30a29e161e  vmovaps [rsp+0x30], xmm3
00007f30a29e1624  vmovaps [rsp+0x40], xmm4
00007f30a29e162a  vmovaps [rsp+0x50], xmm6
00007f30a29e1630  vmovaps [rsp+0x60], xmm7
00007f30a29e1636  vmovaps [rsp+0x70], xmm8
00007f30a29e163c  vmovaps [rsp+0x80], xmm9
00007f30a29e1645  vmovaps [rsp+0x90], xmm10
00007f30a29e164e  vmovaps [rsp+0xA0], xmm11
00007f30a29e1657  vmovaps [rsp+0xB0], xmm12
00007f30a29e1660  vmovaps [rsp+0xC0], xmm13
00007f30a29e1669  vmovaps [rsp+0xD0], xmm14
00007f30a29e1672  vmovaps [rsp+0xE0], xmm15
00007f30a29e167b  sub rsp, 0x30
00007f30a29e167f  movaps [rsp], xmm5
00007f30a29e1683  movaps [rsp+0x10], xmm6
00007f30a29e1688  movaps [rsp+0x20], xmm3
00007f30a29e168d  lea rdi, [rsp]
00007f30a29e1691  mov esi, 0x00
00007f30a29e1696  mov rax, 0x5FE955026530
00007f30a29e16a0  call rax
00007f30a29e16a2  movaps xmm5, [rsp]
00007f30a29e16a6  add rsp, 0x30
00007f30a29e16aa  vmovaps xmm0, [rsp]
00007f30a29e16af  vmovaps xmm1, [rsp+0x10]
00007f30a29e16b5  vmovaps xmm2, [rsp+0x20]
00007f30a29e16bb  vmovaps xmm3, [rsp+0x30]
00007f30a29e16c1  vmovaps xmm4, [rsp+0x40]
00007f30a29e16c7  vmovaps xmm6, [rsp+0x50]
00007f30a29e16cd  vmovaps xmm7, [rsp+0x60]
00007f30a29e16d3  vmovaps xmm8, [rsp+0x70]
00007f30a29e16d9  vmovaps xmm9, [rsp+0x80]
00007f30a29e16e2  vmovaps xmm10, [rsp+0x90]
00007f30a29e16eb  vmovaps xmm11, [rsp+0xA0]
00007f30a29e16f4  vmovaps xmm12, [rsp+0xB0]
00007f30a29e16fd  vmovaps xmm13, [rsp+0xC0]
00007f30a29e1706  vmovaps xmm14, [rsp+0xD0]
00007f30a29e170f  vmovaps xmm15, [rsp+0xE0]
00007f30a29e1718  add rsp, 0xF0
00007f30a29e171f  pop r11
00007f30a29e1721  pop r10
00007f30a29e1723  pop r9
00007f30a29e1725  pop r8
00007f30a29e1727  pop rsi
00007f30a29e1728  pop rdi
00007f30a29e1729  pop rdx
00007f30a29e172a  pop rcx
00007f30a29e172b  pop rax
00007f30a29e172c  add rsp, 0x08
00007f30a29e1730  jmp 0x00007F30A29DF31A
00007f30a29e1735  sub rsp, 0x08
00007f30a29e1739  push rax
00007f30a29e173a  push rcx
00007f30a29e173b  push rdx
00007f30a29e173c  push rdi
00007f30a29e173d  push rsi
00007f30a29e173e  push r8
00007f30a29e1740  push r9
00007f30a29e1742  push r10
00007f30a29e1744  push r11
00007f30a29e1746  sub rsp, 0xF0
00007f30a29e174d  vmovaps [rsp], xmm0
00007f30a29e1752  vmovaps [rsp+0x10], xmm1
00007f30a29e1758  vmovaps [rsp+0x20], xmm2
00007f30a29e175e  vmovaps [rsp+0x30], xmm3
00007f30a29e1764  vmovaps [rsp+0x40], xmm4
00007f30a29e176a  vmovaps [rsp+0x50], xmm5
00007f30a29e1770  vmovaps [rsp+0x60], xmm7
00007f30a29e1776  vmovaps [rsp+0x70], xmm8
00007f30a29e177c  vmovaps [rsp+0x80], xmm9
00007f30a29e1785  vmovaps [rsp+0x90], xmm10
00007f30a29e178e  vmovaps [rsp+0xA0], xmm11
00007f30a29e1797  vmovaps [rsp+0xB0], xmm12
00007f30a29e17a0  vmovaps [rsp+0xC0], xmm13
00007f30a29e17a9  vmovaps [rsp+0xD0], xmm14
00007f30a29e17b2  vmovaps [rsp+0xE0], xmm15
00007f30a29e17bb  sub rsp, 0x30
00007f30a29e17bf  movaps [rsp], xmm6
00007f30a29e17c3  movaps [rsp+0x10], xmm9
00007f30a29e17c9  movaps [rsp+0x20], xmm1
00007f30a29e17ce  lea rdi, [rsp]
00007f30a29e17d2  mov esi, 0x00
00007f30a29e17d7  mov rax, 0x5FE955026530
00007f30a29e17e1  call rax
00007f30a29e17e3  movaps xmm6, [rsp]
00007f30a29e17e7  add rsp, 0x30
00007f30a29e17eb  vmovaps xmm0, [rsp]
00007f30a29e17f0  vmovaps xmm1, [rsp+0x10]
00007f30a29e17f6  vmovaps xmm2, [rsp+0x20]
00007f30a29e17fc  vmovaps xmm3, [rsp+0x30]
00007f30a29e1802  vmovaps xmm4, [rsp+0x40]
00007f30a29e1808  vmovaps xmm5, [rsp+0x50]
00007f30a29e180e  vmovaps xmm7, [rsp+0x60]
00007f30a29e1814  vmovaps xmm8, [rsp+0x70]
00007f30a29e181a  vmovaps xmm9, [rsp+0x80]
00007f30a29e1823  vmovaps xmm10, [rsp+0x90]
00007f30a29e182c  vmovaps xmm11, [rsp+0xA0]
00007f30a29e1835  vmovaps xmm12, [rsp+0xB0]
00007f30a29e183e  vmovaps xmm13, [rsp+0xC0]
00007f30a29e1847  vmovaps xmm14, [rsp+0xD0]
00007f30a29e1850  vmovaps xmm15, [rsp+0xE0]
00007f30a29e1859  add rsp, 0xF0
00007f30a29e1860  pop r11
00007f30a29e1862  pop r10
00007f30a29e1864  pop r9
00007f30a29e1866  pop r8
00007f30a29e1868  pop rsi
00007f30a29e1869  pop rdi
00007f30a29e186a  pop rdx
00007f30a29e186b  pop rcx
00007f30a29e186c  pop rax
00007f30a29e186d  add rsp, 0x08
00007f30a29e1871  jmp 0x00007F30A29DF33E
00007f30a29e1876  sub rsp, 0x08
00007f30a29e187a  push rax
00007f30a29e187b  push rcx
00007f30a29e187c  push rdx
00007f30a29e187d  push rdi
00007f30a29e187e  push rsi
00007f30a29e187f  push r8
00007f30a29e1881  push r9
00007f30a29e1883  push r10
00007f30a29e1885  push r11
00007f30a29e1887  sub rsp, 0xF0
00007f30a29e188e  vmovaps [rsp], xmm0
00007f30a29e1893  vmovaps [rsp+0x10], xmm1
00007f30a29e1899  vmovaps [rsp+0x20], xmm2
00007f30a29e189f  vmovaps [rsp+0x30], xmm3
00007f30a29e18a5  vmovaps [rsp+0x40], xmm4
00007f30a29e18ab  vmovaps [rsp+0x50], xmm5
00007f30a29e18b1  vmovaps [rsp+0x60], xmm6
00007f30a29e18b7  vmovaps [rsp+0x70], xmm7
00007f30a29e18bd  vmovaps [rsp+0x80], xmm8
00007f30a29e18c6  vmovaps [rsp+0x90], xmm10
00007f30a29e18cf  vmovaps [rsp+0xA0], xmm11
00007f30a29e18d8  vmovaps [rsp+0xB0], xmm12
00007f30a29e18e1  vmovaps [rsp+0xC0], xmm13
00007f30a29e18ea  vmovaps [rsp+0xD0], xmm14
00007f30a29e18f3  vmovaps [rsp+0xE0], xmm15
00007f30a29e18fc  sub rsp, 0x30
00007f30a29e1900  movaps [rsp], xmm9
00007f30a29e1905  movaps [rsp+0x10], xmm3
00007f30a29e190a  movaps [rsp+0x20], xmm1
00007f30a29e190f  lea rdi, [rsp]
00007f30a29e1913  mov esi, 0x00
00007f30a29e1918  mov rax, 0x5FE955026530
00007f30a29e1922  call rax
00007f30a29e1924  movaps xmm9, [rsp]
00007f30a29e1929  add rsp, 0x30
00007f30a29e192d  vmovaps xmm0, [rsp]
00007f30a29e1932  vmovaps xmm1, [rsp+0x10]
00007f30a29e1938  vmovaps xmm2, [rsp+0x20]
00007f30a29e193e  vmovaps xmm3, [rsp+0x30]
00007f30a29e1944  vmovaps xmm4, [rsp+0x40]
00007f30a29e194a  vmovaps xmm5, [rsp+0x50]
00007f30a29e1950  vmovaps xmm6, [rsp+0x60]
00007f30a29e1956  vmovaps xmm7, [rsp+0x70]
00007f30a29e195c  vmovaps xmm8, [rsp+0x80]
00007f30a29e1965  vmovaps xmm10, [rsp+0x90]
00007f30a29e196e  vmovaps xmm11, [rsp+0xA0]
00007f30a29e1977  vmovaps xmm12, [rsp+0xB0]
00007f30a29e1980  vmovaps xmm13, [rsp+0xC0]
00007f30a29e1989  vmovaps xmm14, [rsp+0xD0]
00007f30a29e1992  vmovaps xmm15, [rsp+0xE0]
00007f30a29e199b  add rsp, 0xF0
00007f30a29e19a2  pop r11
00007f30a29e19a4  pop r10
00007f30a29e19a6  pop r9
00007f30a29e19a8  pop r8
00007f30a29e19aa  pop rsi
00007f30a29e19ab  pop rdi
00007f30a29e19ac  pop rdx
00007f30a29e19ad  pop rcx
00007f30a29e19ae  pop rax
00007f30a29e19af  add rsp, 0x08
00007f30a29e19b3  jmp 0x00007F30A29DF38A
00007f30a29e19b8  call 0x00007F30A28B52F0
00007f30a29e19bd  jmp 0x00007F30A29DF397
00007f30a29e19c2  sub rsp, 0x08
00007f30a29e19c6  push rax
00007f30a29e19c7  push rcx
00007f30a29e19c8  push rdx
00007f30a29e19c9  push rdi
00007f30a29e19ca  push rsi
00007f30a29e19cb  push r8
00007f30a29e19cd  push r9
00007f30a29e19cf  push r10
00007f30a29e19d1  push r11
00007f30a29e19d3  sub rsp, 0xF0
00007f30a29e19da  vmovaps [rsp], xmm0
00007f30a29e19df  vmovaps [rsp+0x10], xmm1
00007f30a29e19e5  vmovaps [rsp+0x20], xmm2
00007f30a29e19eb  vmovaps [rsp+0x30], xmm3
00007f30a29e19f1  vmovaps [rsp+0x40], xmm4
00007f30a29e19f7  vmovaps [rsp+0x50], xmm5
00007f30a29e19fd  vmovaps [rsp+0x60], xmm6
00007f30a29e1a03  vmovaps [rsp+0x70], xmm7
00007f30a29e1a09  vmovaps [rsp+0x80], xmm8
00007f30a29e1a12  vmovaps [rsp+0x90], xmm9
00007f30a29e1a1b  vmovaps [rsp+0xA0], xmm10
00007f30a29e1a24  vmovaps [rsp+0xB0], xmm11
00007f30a29e1a2d  vmovaps [rsp+0xC0], xmm12
00007f30a29e1a36  vmovaps [rsp+0xD0], xmm13
00007f30a29e1a3f  vmovaps [rsp+0xE0], xmm14
00007f30a29e1a48  sub rsp, 0x30
00007f30a29e1a4c  movaps [rsp], xmm15
00007f30a29e1a51  movaps [rsp+0x10], xmm3
00007f30a29e1a56  movaps [rsp+0x20], xmm7
00007f30a29e1a5b  lea rdi, [rsp]
00007f30a29e1a5f  mov esi, 0x00
00007f30a29e1a64  mov rax, 0x5FE955026530
00007f30a29e1a6e  call rax
00007f30a29e1a70  movaps xmm15, [rsp]
00007f30a29e1a75  add rsp, 0x30
00007f30a29e1a79  vmovaps xmm0, [rsp]
00007f30a29e1a7e  vmovaps xmm1, [rsp+0x10]
00007f30a29e1a84  vmovaps xmm2, [rsp+0x20]
00007f30a29e1a8a  vmovaps xmm3, [rsp+0x30]
00007f30a29e1a90  vmovaps xmm4, [rsp+0x40]
00007f30a29e1a96  vmovaps xmm5, [rsp+0x50]
00007f30a29e1a9c  vmovaps xmm6, [rsp+0x60]
00007f30a29e1aa2  vmovaps xmm7, [rsp+0x70]
00007f30a29e1aa8  vmovaps xmm8, [rsp+0x80]
00007f30a29e1ab1  vmovaps xmm9, [rsp+0x90]
00007f30a29e1aba  vmovaps xmm10, [rsp+0xA0]
00007f30a29e1ac3  vmovaps xmm11, [rsp+0xB0]
00007f30a29e1acc  vmovaps xmm12, [rsp+0xC0]
00007f30a29e1ad5  vmovaps xmm13, [rsp+0xD0]
00007f30a29e1ade  vmovaps xmm14, [rsp+0xE0]
00007f30a29e1ae7  add rsp, 0xF0
00007f30a29e1aee  pop r11
00007f30a29e1af0  pop r10
00007f30a29e1af2  pop r9
00007f30a29e1af4  pop r8
00007f30a29e1af6  pop rsi
00007f30a29e1af7  pop rdi
00007f30a29e1af8  pop rdx
00007f30a29e1af9  pop rcx
00007f30a29e1afa  pop rax
00007f30a29e1afb  add rsp, 0x08
00007f30a29e1aff  jmp 0x00007F30A29DF3C3
00007f30a29e1b04  sub rsp, 0x08
00007f30a29e1b08  push rax
00007f30a29e1b09  push rcx
00007f30a29e1b0a  push rdx
00007f30a29e1b0b  push rdi
00007f30a29e1b0c  push rsi
00007f30a29e1b0d  push r8
00007f30a29e1b0f  push r9
00007f30a29e1b11  push r10
00007f30a29e1b13  push r11
00007f30a29e1b15  sub rsp, 0xF0
00007f30a29e1b1c  vmovaps [rsp], xmm0
00007f30a29e1b21  vmovaps [rsp+0x10], xmm1
00007f30a29e1b27  vmovaps [rsp+0x20], xmm2
00007f30a29e1b2d  vmovaps [rsp+0x30], xmm4
00007f30a29e1b33  vmovaps [rsp+0x40], xmm5
00007f30a29e1b39  vmovaps [rsp+0x50], xmm6
00007f30a29e1b3f  vmovaps [rsp+0x60], xmm7
00007f30a29e1b45  vmovaps [rsp+0x70], xmm8
00007f30a29e1b4b  vmovaps [rsp+0x80], xmm9
00007f30a29e1b54  vmovaps [rsp+0x90], xmm10
00007f30a29e1b5d  vmovaps [rsp+0xA0], xmm11
00007f30a29e1b66  vmovaps [rsp+0xB0], xmm12
00007f30a29e1b6f  vmovaps [rsp+0xC0], xmm13
00007f30a29e1b78  vmovaps [rsp+0xD0], xmm14
00007f30a29e1b81  vmovaps [rsp+0xE0], xmm15
00007f30a29e1b8a  sub rsp, 0x30
00007f30a29e1b8e  movaps [rsp], xmm3
00007f30a29e1b92  movaps [rsp+0x10], xmm1
00007f30a29e1b97  movaps [rsp+0x20], xmm15
00007f30a29e1b9d  lea rdi, [rsp]
00007f30a29e1ba1  mov esi, 0x00
00007f30a29e1ba6  mov rax, 0x5FE955026530
00007f30a29e1bb0  call rax
00007f30a29e1bb2  movaps xmm3, [rsp]
00007f30a29e1bb6  add rsp, 0x30
00007f30a29e1bba  vmovaps xmm0, [rsp]
00007f30a29e1bbf  vmovaps xmm1, [rsp+0x10]
00007f30a29e1bc5  vmovaps xmm2, [rsp+0x20]
00007f30a29e1bcb  vmovaps xmm4, [rsp+0x30]
00007f30a29e1bd1  vmovaps xmm5, [rsp+0x40]
00007f30a29e1bd7  vmovaps xmm6, [rsp+0x50]
00007f30a29e1bdd  vmovaps xmm7, [rsp+0x60]
00007f30a29e1be3  vmovaps xmm8, [rsp+0x70]
00007f30a29e1be9  vmovaps xmm9, [rsp+0x80]
00007f30a29e1bf2  vmovaps xmm10, [rsp+0x90]
00007f30a29e1bfb  vmovaps xmm11, [rsp+0xA0]
00007f30a29e1c04  vmovaps xmm12, [rsp+0xB0]
00007f30a29e1c0d  vmovaps xmm13, [rsp+0xC0]
00007f30a29e1c16  vmovaps xmm14, [rsp+0xD0]
00007f30a29e1c1f  vmovaps xmm15, [rsp+0xE0]
00007f30a29e1c28  add rsp, 0xF0
00007f30a29e1c2f  pop r11
00007f30a29e1c31  pop r10
00007f30a29e1c33  pop r9
00007f30a29e1c35  pop r8
00007f30a29e1c37  pop rsi
00007f30a29e1c38  pop rdi
00007f30a29e1c39  pop rdx
00007f30a29e1c3a  pop rcx
00007f30a29e1c3b  pop rax
00007f30a29e1c3c  add rsp, 0x08
00007f30a29e1c40  jmp 0x00007F30A29DF452
00007f30a29e1c45  call 0x00007F30A28B52F0
00007f30a29e1c4a  jmp 0x00007F30A29DF45C
00007f30a29e1c4f  sub rsp, 0x08
00007f30a29e1c53  push rax
00007f30a29e1c54  push rcx
00007f30a29e1c55  push rdx
00007f30a29e1c56  push rdi
00007f30a29e1c57  push rsi
00007f30a29e1c58  push r8
00007f30a29e1c5a  push r9
00007f30a29e1c5c  push r10
00007f30a29e1c5e  push r11
00007f30a29e1c60  sub rsp, 0xF0
00007f30a29e1c67  vmovaps [rsp], xmm0
00007f30a29e1c6c  vmovaps [rsp+0x10], xmm1
00007f30a29e1c72  vmovaps [rsp+0x20], xmm2
00007f30a29e1c78  vmovaps [rsp+0x30], xmm3
00007f30a29e1c7e  vmovaps [rsp+0x40], xmm4
00007f30a29e1c84  vmovaps [rsp+0x50], xmm5
00007f30a29e1c8a  vmovaps [rsp+0x60], xmm6
00007f30a29e1c90  vmovaps [rsp+0x70], xmm7
00007f30a29e1c96  vmovaps [rsp+0x80], xmm8
00007f30a29e1c9f  vmovaps [rsp+0x90], xmm9
00007f30a29e1ca8  vmovaps [rsp+0xA0], xmm10
00007f30a29e1cb1  vmovaps [rsp+0xB0], xmm11
00007f30a29e1cba  vmovaps [rsp+0xC0], xmm12
00007f30a29e1cc3  vmovaps [rsp+0xD0], xmm13
00007f30a29e1ccc  vmovaps [rsp+0xE0], xmm14
00007f30a29e1cd5  sub rsp, 0x30
00007f30a29e1cd9  movaps [rsp], xmm15
00007f30a29e1cde  movaps [rsp+0x10], xmm14
00007f30a29e1ce4  movaps [rsp+0x20], xmm4
00007f30a29e1ce9  lea rdi, [rsp]
00007f30a29e1ced  mov esi, 0x00
00007f30a29e1cf2  mov rax, 0x5FE955026530
00007f30a29e1cfc  call rax
00007f30a29e1cfe  movaps xmm15, [rsp]
00007f30a29e1d03  add rsp, 0x30
00007f30a29e1d07  vmovaps xmm0, [rsp]
00007f30a29e1d0c  vmovaps xmm1, [rsp+0x10]
00007f30a29e1d12  vmovaps xmm2, [rsp+0x20]
00007f30a29e1d18  vmovaps xmm3, [rsp+0x30]
00007f30a29e1d1e  vmovaps xmm4, [rsp+0x40]
00007f30a29e1d24  vmovaps xmm5, [rsp+0x50]
00007f30a29e1d2a  vmovaps xmm6, [rsp+0x60]
00007f30a29e1d30  vmovaps xmm7, [rsp+0x70]
00007f30a29e1d36  vmovaps xmm8, [rsp+0x80]
00007f30a29e1d3f  vmovaps xmm9, [rsp+0x90]
00007f30a29e1d48  vmovaps xmm10, [rsp+0xA0]
00007f30a29e1d51  vmovaps xmm11, [rsp+0xB0]
00007f30a29e1d5a  vmovaps xmm12, [rsp+0xC0]
00007f30a29e1d63  vmovaps xmm13, [rsp+0xD0]
00007f30a29e1d6c  vmovaps xmm14, [rsp+0xE0]
00007f30a29e1d75  add rsp, 0xF0
00007f30a29e1d7c  pop r11
00007f30a29e1d7e  pop r10
00007f30a29e1d80  pop r9
00007f30a29e1d82  pop r8
00007f30a29e1d84  pop rsi
00007f30a29e1d85  pop rdi
00007f30a29e1d86  pop rdx
00007f30a29e1d87  pop rcx
00007f30a29e1d88  pop rax
00007f30a29e1d89  add rsp, 0x08
00007f30a29e1d8d  jmp 0x00007F30A29DF48A
00007f30a29e1d92  sub rsp, 0x08
00007f30a29e1d96  push rax
00007f30a29e1d97  push rcx
00007f30a29e1d98  push rdx
00007f30a29e1d99  push rdi
00007f30a29e1d9a  push rsi
00007f30a29e1d9b  push r8
00007f30a29e1d9d  push r9
00007f30a29e1d9f  push r10
00007f30a29e1da1  push r11
00007f30a29e1da3  sub rsp, 0xF0
00007f30a29e1daa  vmovaps [rsp], xmm0
00007f30a29e1daf  vmovaps [rsp+0x10], xmm1
00007f30a29e1db5  vmovaps [rsp+0x20], xmm2
00007f30a29e1dbb  vmovaps [rsp+0x30], xmm3
00007f30a29e1dc1  vmovaps [rsp+0x40], xmm4
00007f30a29e1dc7  vmovaps [rsp+0x50], xmm5
00007f30a29e1dcd  vmovaps [rsp+0x60], xmm6
00007f30a29e1dd3  vmovaps [rsp+0x70], xmm7
00007f30a29e1dd9  vmovaps [rsp+0x80], xmm8
00007f30a29e1de2  vmovaps [rsp+0x90], xmm9
00007f30a29e1deb  vmovaps [rsp+0xA0], xmm10
00007f30a29e1df4  vmovaps [rsp+0xB0], xmm11
00007f30a29e1dfd  vmovaps [rsp+0xC0], xmm12
00007f30a29e1e06  vmovaps [rsp+0xD0], xmm13
00007f30a29e1e0f  vmovaps [rsp+0xE0], xmm15
00007f30a29e1e18  sub rsp, 0x30
00007f30a29e1e1c  movaps [rsp], xmm14
00007f30a29e1e21  movaps [rsp+0x10], xmm2
00007f30a29e1e26  movaps [rsp+0x20], xmm1
00007f30a29e1e2b  lea rdi, [rsp]
00007f30a29e1e2f  mov esi, 0x00
00007f30a29e1e34  mov rax, 0x5FE955026530
00007f30a29e1e3e  call rax
00007f30a29e1e40  movaps xmm14, [rsp]
00007f30a29e1e45  add rsp, 0x30
00007f30a29e1e49  vmovaps xmm0, [rsp]
00007f30a29e1e4e  vmovaps xmm1, [rsp+0x10]
00007f30a29e1e54  vmovaps xmm2, [rsp+0x20]
00007f30a29e1e5a  vmovaps xmm3, [rsp+0x30]
00007f30a29e1e60  vmovaps xmm4, [rsp+0x40]
00007f30a29e1e66  vmovaps xmm5, [rsp+0x50]
00007f30a29e1e6c  vmovaps xmm6, [rsp+0x60]
00007f30a29e1e72  vmovaps xmm7, [rsp+0x70]
00007f30a29e1e78  vmovaps xmm8, [rsp+0x80]
00007f30a29e1e81  vmovaps xmm9, [rsp+0x90]
00007f30a29e1e8a  vmovaps xmm10, [rsp+0xA0]
00007f30a29e1e93  vmovaps xmm11, [rsp+0xB0]
00007f30a29e1e9c  vmovaps xmm12, [rsp+0xC0]
00007f30a29e1ea5  vmovaps xmm13, [rsp+0xD0]
00007f30a29e1eae  vmovaps xmm15, [rsp+0xE0]
00007f30a29e1eb7  add rsp, 0xF0
00007f30a29e1ebe  pop r11
00007f30a29e1ec0  pop r10
00007f30a29e1ec2  pop r9
00007f30a29e1ec4  pop r8
00007f30a29e1ec6  pop rsi
00007f30a29e1ec7  pop rdi
00007f30a29e1ec8  pop rdx
00007f30a29e1ec9  pop rcx
00007f30a29e1eca  pop rax
00007f30a29e1ecb  add rsp, 0x08
00007f30a29e1ecf  jmp 0x00007F30A29DF4B0
00007f30a29e1ed4  sub rsp, 0x08
00007f30a29e1ed8  push rax
00007f30a29e1ed9  push rcx
00007f30a29e1eda  push rdx
00007f30a29e1edb  push rdi
00007f30a29e1edc  push rsi
00007f30a29e1edd  push r8
00007f30a29e1edf  push r9
00007f30a29e1ee1  push r10
00007f30a29e1ee3  push r11
00007f30a29e1ee5  sub rsp, 0xF0
00007f30a29e1eec  vmovaps [rsp], xmm0
00007f30a29e1ef1  vmovaps [rsp+0x10], xmm2
00007f30a29e1ef7  vmovaps [rsp+0x20], xmm3
00007f30a29e1efd  vmovaps [rsp+0x30], xmm4
00007f30a29e1f03  vmovaps [rsp+0x40], xmm5
00007f30a29e1f09  vmovaps [rsp+0x50], xmm6
00007f30a29e1f0f  vmovaps [rsp+0x60], xmm7
00007f30a29e1f15  vmovaps [rsp+0x70], xmm8
00007f30a29e1f1b  vmovaps [rsp+0x80], xmm9
00007f30a29e1f24  vmovaps [rsp+0x90], xmm10
00007f30a29e1f2d  vmovaps [rsp+0xA0], xmm11
00007f30a29e1f36  vmovaps [rsp+0xB0], xmm12
00007f30a29e1f3f  vmovaps [rsp+0xC0], xmm13
00007f30a29e1f48  vmovaps [rsp+0xD0], xmm14
00007f30a29e1f51  vmovaps [rsp+0xE0], xmm15
00007f30a29e1f5a  sub rsp, 0x30
00007f30a29e1f5e  movaps [rsp], xmm1
00007f30a29e1f62  movaps [rsp+0x10], xmm4
00007f30a29e1f67  movaps [rsp+0x20], xmm9
00007f30a29e1f6d  lea rdi, [rsp]
00007f30a29e1f71  mov esi, 0x00
00007f30a29e1f76  mov rax, 0x5FE955026530
00007f30a29e1f80  call rax
00007f30a29e1f82  movaps xmm1, [rsp]
00007f30a29e1f86  add rsp, 0x30
00007f30a29e1f8a  vmovaps xmm0, [rsp]
00007f30a29e1f8f  vmovaps xmm2, [rsp+0x10]
00007f30a29e1f95  vmovaps xmm3, [rsp+0x20]
00007f30a29e1f9b  vmovaps xmm4, [rsp+0x30]
00007f30a29e1fa1  vmovaps xmm5, [rsp+0x40]
00007f30a29e1fa7  vmovaps xmm6, [rsp+0x50]
00007f30a29e1fad  vmovaps xmm7, [rsp+0x60]
00007f30a29e1fb3  vmovaps xmm8, [rsp+0x70]
00007f30a29e1fb9  vmovaps xmm9, [rsp+0x80]
00007f30a29e1fc2  vmovaps xmm10, [rsp+0x90]
00007f30a29e1fcb  vmovaps xmm11, [rsp+0xA0]
00007f30a29e1fd4  vmovaps xmm12, [rsp+0xB0]
00007f30a29e1fdd  vmovaps xmm13, [rsp+0xC0]
00007f30a29e1fe6  vmovaps xmm14, [rsp+0xD0]
00007f30a29e1fef  vmovaps xmm15, [rsp+0xE0]
00007f30a29e1ff8  add rsp, 0xF0
00007f30a29e1fff  pop r11
00007f30a29e2001  pop r10
00007f30a29e2003  pop r9
00007f30a29e2005  pop r8
00007f30a29e2007  pop rsi
00007f30a29e2008  pop rdi
00007f30a29e2009  pop rdx
00007f30a29e200a  pop rcx
00007f30a29e200b  pop rax
00007f30a29e200c  add rsp, 0x08
00007f30a29e2010  jmp 0x00007F30A29DF4CE
00007f30a29e2015  sub rsp, 0x08
00007f30a29e2019  push rax
00007f30a29e201a  push rcx
00007f30a29e201b  push rdx
00007f30a29e201c  push rdi
00007f30a29e201d  push rsi
00007f30a29e201e  push r8
00007f30a29e2020  push r9
00007f30a29e2022  push r10
00007f30a29e2024  push r11
00007f30a29e2026  sub rsp, 0xF0
00007f30a29e202d  vmovaps [rsp], xmm0
00007f30a29e2032  vmovaps [rsp+0x10], xmm1
00007f30a29e2038  vmovaps [rsp+0x20], xmm2
00007f30a29e203e  vmovaps [rsp+0x30], xmm3
00007f30a29e2044  vmovaps [rsp+0x40], xmm5
00007f30a29e204a  vmovaps [rsp+0x50], xmm6
00007f30a29e2050  vmovaps [rsp+0x60], xmm7
00007f30a29e2056  vmovaps [rsp+0x70], xmm8
00007f30a29e205c  vmovaps [rsp+0x80], xmm9
00007f30a29e2065  vmovaps [rsp+0x90], xmm10
00007f30a29e206e  vmovaps [rsp+0xA0], xmm11
00007f30a29e2077  vmovaps [rsp+0xB0], xmm12
00007f30a29e2080  vmovaps [rsp+0xC0], xmm13
00007f30a29e2089  vmovaps [rsp+0xD0], xmm14
00007f30a29e2092  vmovaps [rsp+0xE0], xmm15
00007f30a29e209b  sub rsp, 0x30
00007f30a29e209f  movaps [rsp], xmm4
00007f30a29e20a3  movaps [rsp+0x10], xmm2
00007f30a29e20a8  movaps [rsp+0x20], xmm9
00007f30a29e20ae  lea rdi, [rsp]
00007f30a29e20b2  mov esi, 0x00
00007f30a29e20b7  mov rax, 0x5FE955026530
00007f30a29e20c1  call rax
00007f30a29e20c3  movaps xmm4, [rsp]
00007f30a29e20c7  add rsp, 0x30
00007f30a29e20cb  vmovaps xmm0, [rsp]
00007f30a29e20d0  vmovaps xmm1, [rsp+0x10]
00007f30a29e20d6  vmovaps xmm2, [rsp+0x20]
00007f30a29e20dc  vmovaps xmm3, [rsp+0x30]
00007f30a29e20e2  vmovaps xmm5, [rsp+0x40]
00007f30a29e20e8  vmovaps xmm6, [rsp+0x50]
00007f30a29e20ee  vmovaps xmm7, [rsp+0x60]
00007f30a29e20f4  vmovaps xmm8, [rsp+0x70]
00007f30a29e20fa  vmovaps xmm9, [rsp+0x80]
00007f30a29e2103  vmovaps xmm10, [rsp+0x90]
00007f30a29e210c  vmovaps xmm11, [rsp+0xA0]
00007f30a29e2115  vmovaps xmm12, [rsp+0xB0]
00007f30a29e211e  vmovaps xmm13, [rsp+0xC0]
00007f30a29e2127  vmovaps xmm14, [rsp+0xD0]
00007f30a29e2130  vmovaps xmm15, [rsp+0xE0]
00007f30a29e2139  add rsp, 0xF0
00007f30a29e2140  pop r11
00007f30a29e2142  pop r10
00007f30a29e2144  pop r9
00007f30a29e2146  pop r8
00007f30a29e2148  pop rsi
00007f30a29e2149  pop rdi
00007f30a29e214a  pop rdx
00007f30a29e214b  pop rcx
00007f30a29e214c  pop rax
00007f30a29e214d  add rsp, 0x08
00007f30a29e2151  jmp 0x00007F30A29DF4FE
00007f30a29e2156  sub rsp, 0x08
00007f30a29e215a  push rax
00007f30a29e215b  push rcx
00007f30a29e215c  push rdx
00007f30a29e215d  push rdi
00007f30a29e215e  push rsi
00007f30a29e215f  push r8
00007f30a29e2161  push r9
00007f30a29e2163  push r10
00007f30a29e2165  push r11
00007f30a29e2167  sub rsp, 0xF0
00007f30a29e216e  vmovaps [rsp], xmm0
00007f30a29e2173  vmovaps [rsp+0x10], xmm1
00007f30a29e2179  vmovaps [rsp+0x20], xmm2
00007f30a29e217f  vmovaps [rsp+0x30], xmm3
00007f30a29e2185  vmovaps [rsp+0x40], xmm4
00007f30a29e218b  vmovaps [rsp+0x50], xmm5
00007f30a29e2191  vmovaps [rsp+0x60], xmm6
00007f30a29e2197  vmovaps [rsp+0x70], xmm7
00007f30a29e219d  vmovaps [rsp+0x80], xmm8
00007f30a29e21a6  vmovaps [rsp+0x90], xmm10
00007f30a29e21af  vmovaps [rsp+0xA0], xmm11
00007f30a29e21b8  vmovaps [rsp+0xB0], xmm12
00007f30a29e21c1  vmovaps [rsp+0xC0], xmm13
00007f30a29e21ca  vmovaps [rsp+0xD0], xmm14
00007f30a29e21d3  vmovaps [rsp+0xE0], xmm15
00007f30a29e21dc  sub rsp, 0x30
00007f30a29e21e0  movaps [rsp], xmm9
00007f30a29e21e5  movaps [rsp+0x10], xmm2
00007f30a29e21ea  movaps [rsp+0x20], xmm1
00007f30a29e21ef  lea rdi, [rsp]
00007f30a29e21f3  mov esi, 0x00
00007f30a29e21f8  mov rax, 0x5FE955026530
00007f30a29e2202  call rax
00007f30a29e2204  movaps xmm9, [rsp]
00007f30a29e2209  add rsp, 0x30
00007f30a29e220d  vmovaps xmm0, [rsp]
00007f30a29e2212  vmovaps xmm1, [rsp+0x10]
00007f30a29e2218  vmovaps xmm2, [rsp+0x20]
00007f30a29e221e  vmovaps xmm3, [rsp+0x30]
00007f30a29e2224  vmovaps xmm4, [rsp+0x40]
00007f30a29e222a  vmovaps xmm5, [rsp+0x50]
00007f30a29e2230  vmovaps xmm6, [rsp+0x60]
00007f30a29e2236  vmovaps xmm7, [rsp+0x70]
00007f30a29e223c  vmovaps xmm8, [rsp+0x80]
00007f30a29e2245  vmovaps xmm10, [rsp+0x90]
00007f30a29e224e  vmovaps xmm11, [rsp+0xA0]
00007f30a29e2257  vmovaps xmm12, [rsp+0xB0]
00007f30a29e2260  vmovaps xmm13, [rsp+0xC0]
00007f30a29e2269  vmovaps xmm14, [rsp+0xD0]
00007f30a29e2272  vmovaps xmm15, [rsp+0xE0]
00007f30a29e227b  add rsp, 0xF0
00007f30a29e2282  pop r11
00007f30a29e2284  pop r10
00007f30a29e2286  pop r9
00007f30a29e2288  pop r8
00007f30a29e228a  pop rsi
00007f30a29e228b  pop rdi
00007f30a29e228c  pop rdx
00007f30a29e228d  pop rcx
00007f30a29e228e  pop rax
00007f30a29e228f  add rsp, 0x08
00007f30a29e2293  jmp 0x00007F30A29DF534
00007f30a29e2298  sub rsp, 0x08
00007f30a29e229c  push rax
00007f30a29e229d  push rcx
00007f30a29e229e  push rdx
00007f30a29e229f  push rdi
00007f30a29e22a0  push rsi
00007f30a29e22a1  push r8
00007f30a29e22a3  push r9
00007f30a29e22a5  push r10
00007f30a29e22a7  push r11
00007f30a29e22a9  sub rsp, 0xF0
00007f30a29e22b0  vmovaps [rsp], xmm0
00007f30a29e22b5  vmovaps [rsp+0x10], xmm2
00007f30a29e22bb  vmovaps [rsp+0x20], xmm3
00007f30a29e22c1  vmovaps [rsp+0x30], xmm4
00007f30a29e22c7  vmovaps [rsp+0x40], xmm5
00007f30a29e22cd  vmovaps [rsp+0x50], xmm6
00007f30a29e22d3  vmovaps [rsp+0x60], xmm7
00007f30a29e22d9  vmovaps [rsp+0x70], xmm8
00007f30a29e22df  vmovaps [rsp+0x80], xmm9
00007f30a29e22e8  vmovaps [rsp+0x90], xmm10
00007f30a29e22f1  vmovaps [rsp+0xA0], xmm11
00007f30a29e22fa  vmovaps [rsp+0xB0], xmm12
00007f30a29e2303  vmovaps [rsp+0xC0], xmm13
00007f30a29e230c  vmovaps [rsp+0xD0], xmm14
00007f30a29e2315  vmovaps [rsp+0xE0], xmm15
00007f30a29e231e  sub rsp, 0x30
00007f30a29e2322  movaps [rsp], xmm1
00007f30a29e2326  movaps [rsp+0x10], xmm15
00007f30a29e232c  movaps [rsp+0x20], xmm6
00007f30a29e2331  lea rdi, [rsp]
00007f30a29e2335  mov esi, 0x00
00007f30a29e233a  mov rax, 0x5FE955026530
00007f30a29e2344  call rax
00007f30a29e2346  movaps xmm1, [rsp]
00007f30a29e234a  add rsp, 0x30
00007f30a29e234e  vmovaps xmm0, [rsp]
00007f30a29e2353  vmovaps xmm2, [rsp+0x10]
00007f30a29e2359  vmovaps xmm3, [rsp+0x20]
00007f30a29e235f  vmovaps xmm4, [rsp+0x30]
00007f30a29e2365  vmovaps xmm5, [rsp+0x40]
00007f30a29e236b  vmovaps xmm6, [rsp+0x50]
00007f30a29e2371  vmovaps xmm7, [rsp+0x60]
00007f30a29e2377  vmovaps xmm8, [rsp+0x70]
00007f30a29e237d  vmovaps xmm9, [rsp+0x80]
00007f30a29e2386  vmovaps xmm10, [rsp+0x90]
00007f30a29e238f  vmovaps xmm11, [rsp+0xA0]
00007f30a29e2398  vmovaps xmm12, [rsp+0xB0]
00007f30a29e23a1  vmovaps xmm13, [rsp+0xC0]
00007f30a29e23aa  vmovaps xmm14, [rsp+0xD0]
00007f30a29e23b3  vmovaps xmm15, [rsp+0xE0]
00007f30a29e23bc  add rsp, 0xF0
00007f30a29e23c3  pop r11
00007f30a29e23c5  pop r10
00007f30a29e23c7  pop r9
00007f30a29e23c9  pop r8
00007f30a29e23cb  pop rsi
00007f30a29e23cc  pop rdi
00007f30a29e23cd  pop rdx
00007f30a29e23ce  pop rcx
00007f30a29e23cf  pop rax
00007f30a29e23d0  add rsp, 0x08
00007f30a29e23d4  jmp 0x00007F30A29DF555
00007f30a29e23d9  sub rsp, 0x08
00007f30a29e23dd  push rax
00007f30a29e23de  push rcx
00007f30a29e23df  push rdx
00007f30a29e23e0  push rdi
00007f30a29e23e1  push rsi
00007f30a29e23e2  push r8
00007f30a29e23e4  push r9
00007f30a29e23e6  push r10
00007f30a29e23e8  push r11
00007f30a29e23ea  sub rsp, 0xF0
00007f30a29e23f1  vmovaps [rsp], xmm0
00007f30a29e23f6  vmovaps [rsp+0x10], xmm1
00007f30a29e23fc  vmovaps [rsp+0x20], xmm2
00007f30a29e2402  vmovaps [rsp+0x30], xmm3
00007f30a29e2408  vmovaps [rsp+0x40], xmm4
00007f30a29e240e  vmovaps [rsp+0x50], xmm5
00007f30a29e2414  vmovaps [rsp+0x60], xmm6
00007f30a29e241a  vmovaps [rsp+0x70], xmm7
00007f30a29e2420  vmovaps [rsp+0x80], xmm8
00007f30a29e2429  vmovaps [rsp+0x90], xmm9
00007f30a29e2432  vmovaps [rsp+0xA0], xmm10
00007f30a29e243b  vmovaps [rsp+0xB0], xmm11
00007f30a29e2444  vmovaps [rsp+0xC0], xmm12
00007f30a29e244d  vmovaps [rsp+0xD0], xmm13
00007f30a29e2456  vmovaps [rsp+0xE0], xmm14
00007f30a29e245f  sub rsp, 0x30
00007f30a29e2463  movaps [rsp], xmm15
00007f30a29e2468  movaps [rsp+0x10], xmm5
00007f30a29e246d  movaps [rsp+0x20], xmm3
00007f30a29e2472  lea rdi, [rsp]
00007f30a29e2476  mov esi, 0x00
00007f30a29e247b  mov rax, 0x5FE955026530
00007f30a29e2485  call rax
00007f30a29e2487  movaps xmm15, [rsp]
00007f30a29e248c  add rsp, 0x30
00007f30a29e2490  vmovaps xmm0, [rsp]
00007f30a29e2495  vmovaps xmm1, [rsp+0x10]
00007f30a29e249b  vmovaps xmm2, [rsp+0x20]
00007f30a29e24a1  vmovaps xmm3, [rsp+0x30]
00007f30a29e24a7  vmovaps xmm4, [rsp+0x40]
00007f30a29e24ad  vmovaps xmm5, [rsp+0x50]
00007f30a29e24b3  vmovaps xmm6, [rsp+0x60]
00007f30a29e24b9  vmovaps xmm7, [rsp+0x70]
00007f30a29e24bf  vmovaps xmm8, [rsp+0x80]
00007f30a29e24c8  vmovaps xmm9, [rsp+0x90]
00007f30a29e24d1  vmovaps xmm10, [rsp+0xA0]
00007f30a29e24da  vmovaps xmm11, [rsp+0xB0]
00007f30a29e24e3  vmovaps xmm12, [rsp+0xC0]
00007f30a29e24ec  vmovaps xmm13, [rsp+0xD0]
00007f30a29e24f5  vmovaps xmm14, [rsp+0xE0]
00007f30a29e24fe  add rsp, 0xF0
00007f30a29e2505  pop r11
00007f30a29e2507  pop r10
00007f30a29e2509  pop r9
00007f30a29e250b  pop r8
00007f30a29e250d  pop rsi
00007f30a29e250e  pop rdi
00007f30a29e250f  pop rdx
00007f30a29e2510  pop rcx
00007f30a29e2511  pop rax
00007f30a29e2512  add rsp, 0x08
00007f30a29e2516  jmp 0x00007F30A29DF56F
00007f30a29e251b  sub rsp, 0x08
00007f30a29e251f  push rax
00007f30a29e2520  push rcx
00007f30a29e2521  push rdx
00007f30a29e2522  push rdi
00007f30a29e2523  push rsi
00007f30a29e2524  push r8
00007f30a29e2526  push r9
00007f30a29e2528  push r10
00007f30a29e252a  push r11
00007f30a29e252c  sub rsp, 0xF0
00007f30a29e2533  vmovaps [rsp], xmm0
00007f30a29e2538  vmovaps [rsp+0x10], xmm1
00007f30a29e253e  vmovaps [rsp+0x20], xmm2
00007f30a29e2544  vmovaps [rsp+0x30], xmm3
00007f30a29e254a  vmovaps [rsp+0x40], xmm4
00007f30a29e2550  vmovaps [rsp+0x50], xmm6
00007f30a29e2556  vmovaps [rsp+0x60], xmm7
00007f30a29e255c  vmovaps [rsp+0x70], xmm8
00007f30a29e2562  vmovaps [rsp+0x80], xmm9
00007f30a29e256b  vmovaps [rsp+0x90], xmm10
00007f30a29e2574  vmovaps [rsp+0xA0], xmm11
00007f30a29e257d  vmovaps [rsp+0xB0], xmm12
00007f30a29e2586  vmovaps [rsp+0xC0], xmm13
00007f30a29e258f  vmovaps [rsp+0xD0], xmm14
00007f30a29e2598  vmovaps [rsp+0xE0], xmm15
00007f30a29e25a1  sub rsp, 0x30
00007f30a29e25a5  movaps [rsp], xmm5
00007f30a29e25a9  movaps [rsp+0x10], xmm8
00007f30a29e25af  movaps [rsp+0x20], xmm6
00007f30a29e25b4  lea rdi, [rsp]
00007f30a29e25b8  mov esi, 0x00
00007f30a29e25bd  mov rax, 0x5FE955026530
00007f30a29e25c7  call rax
00007f30a29e25c9  movaps xmm5, [rsp]
00007f30a29e25cd  add rsp, 0x30
00007f30a29e25d1  vmovaps xmm0, [rsp]
00007f30a29e25d6  vmovaps xmm1, [rsp+0x10]
00007f30a29e25dc  vmovaps xmm2, [rsp+0x20]
00007f30a29e25e2  vmovaps xmm3, [rsp+0x30]
00007f30a29e25e8  vmovaps xmm4, [rsp+0x40]
00007f30a29e25ee  vmovaps xmm6, [rsp+0x50]
00007f30a29e25f4  vmovaps xmm7, [rsp+0x60]
00007f30a29e25fa  vmovaps xmm8, [rsp+0x70]
00007f30a29e2600  vmovaps xmm9, [rsp+0x80]
00007f30a29e2609  vmovaps xmm10, [rsp+0x90]
00007f30a29e2612  vmovaps xmm11, [rsp+0xA0]
00007f30a29e261b  vmovaps xmm12, [rsp+0xB0]
00007f30a29e2624  vmovaps xmm13, [rsp+0xC0]
00007f30a29e262d  vmovaps xmm14, [rsp+0xD0]
00007f30a29e2636  vmovaps xmm15, [rsp+0xE0]
00007f30a29e263f  add rsp, 0xF0
00007f30a29e2646  pop r11
00007f30a29e2648  pop r10
00007f30a29e264a  pop r9
00007f30a29e264c  pop r8
00007f30a29e264e  pop rsi
00007f30a29e264f  pop rdi
00007f30a29e2650  pop rdx
00007f30a29e2651  pop rcx
00007f30a29e2652  pop rax
00007f30a29e2653  add rsp, 0x08
00007f30a29e2657  jmp 0x00007F30A29DF593
00007f30a29e265c  sub rsp, 0x08
00007f30a29e2660  push rax
00007f30a29e2661  push rcx
00007f30a29e2662  push rdx
00007f30a29e2663  push rdi
00007f30a29e2664  push rsi
00007f30a29e2665  push r8
00007f30a29e2667  push r9
00007f30a29e2669  push r10
00007f30a29e266b  push r11
00007f30a29e266d  sub rsp, 0xF0
00007f30a29e2674  vmovaps [rsp], xmm0
00007f30a29e2679  vmovaps [rsp+0x10], xmm1
00007f30a29e267f  vmovaps [rsp+0x20], xmm2
00007f30a29e2685  vmovaps [rsp+0x30], xmm3
00007f30a29e268b  vmovaps [rsp+0x40], xmm4
00007f30a29e2691  vmovaps [rsp+0x50], xmm5
00007f30a29e2697  vmovaps [rsp+0x60], xmm7
00007f30a29e269d  vmovaps [rsp+0x70], xmm8
00007f30a29e26a3  vmovaps [rsp+0x80], xmm9
00007f30a29e26ac  vmovaps [rsp+0x90], xmm10
00007f30a29e26b5  vmovaps [rsp+0xA0], xmm11
00007f30a29e26be  vmovaps [rsp+0xB0], xmm12
00007f30a29e26c7  vmovaps [rsp+0xC0], xmm13
00007f30a29e26d0  vmovaps [rsp+0xD0], xmm14
00007f30a29e26d9  vmovaps [rsp+0xE0], xmm15
00007f30a29e26e2  sub rsp, 0x30
00007f30a29e26e6  movaps [rsp], xmm6
00007f30a29e26ea  movaps [rsp+0x10], xmm10
00007f30a29e26f0  movaps [rsp+0x20], xmm8
00007f30a29e26f6  lea rdi, [rsp]
00007f30a29e26fa  mov esi, 0x00
00007f30a29e26ff  mov rax, 0x5FE955026530
00007f30a29e2709  call rax
00007f30a29e270b  movaps xmm6, [rsp]
00007f30a29e270f  add rsp, 0x30
00007f30a29e2713  vmovaps xmm0, [rsp]
00007f30a29e2718  vmovaps xmm1, [rsp+0x10]
00007f30a29e271e  vmovaps xmm2, [rsp+0x20]
00007f30a29e2724  vmovaps xmm3, [rsp+0x30]
00007f30a29e272a  vmovaps xmm4, [rsp+0x40]
00007f30a29e2730  vmovaps xmm5, [rsp+0x50]
00007f30a29e2736  vmovaps xmm7, [rsp+0x60]
00007f30a29e273c  vmovaps xmm8, [rsp+0x70]
00007f30a29e2742  vmovaps xmm9, [rsp+0x80]
00007f30a29e274b  vmovaps xmm10, [rsp+0x90]
00007f30a29e2754  vmovaps xmm11, [rsp+0xA0]
00007f30a29e275d  vmovaps xmm12, [rsp+0xB0]
00007f30a29e2766  vmovaps xmm13, [rsp+0xC0]
00007f30a29e276f  vmovaps xmm14, [rsp+0xD0]
00007f30a29e2778  vmovaps xmm15, [rsp+0xE0]
00007f30a29e2781  add rsp, 0xF0
00007f30a29e2788  pop r11
00007f30a29e278a  pop r10
00007f30a29e278c  pop r9
00007f30a29e278e  pop r8
00007f30a29e2790  pop rsi
00007f30a29e2791  pop rdi
00007f30a29e2792  pop rdx
00007f30a29e2793  pop rcx
00007f30a29e2794  pop rax
00007f30a29e2795  add rsp, 0x08
00007f30a29e2799  jmp 0x00007F30A29DF5B8
00007f30a29e279e  sub rsp, 0x08
00007f30a29e27a2  push rax
00007f30a29e27a3  push rcx
00007f30a29e27a4  push rdx
00007f30a29e27a5  push rdi
00007f30a29e27a6  push rsi
00007f30a29e27a7  push r8
00007f30a29e27a9  push r9
00007f30a29e27ab  push r10
00007f30a29e27ad  push r11
00007f30a29e27af  sub rsp, 0xF0
00007f30a29e27b6  vmovaps [rsp], xmm0
00007f30a29e27bb  vmovaps [rsp+0x10], xmm1
00007f30a29e27c1  vmovaps [rsp+0x20], xmm2
00007f30a29e27c7  vmovaps [rsp+0x30], xmm3
00007f30a29e27cd  vmovaps [rsp+0x40], xmm4
00007f30a29e27d3  vmovaps [rsp+0x50], xmm5
00007f30a29e27d9  vmovaps [rsp+0x60], xmm6
00007f30a29e27df  vmovaps [rsp+0x70], xmm7
00007f30a29e27e5  vmovaps [rsp+0x80], xmm8
00007f30a29e27ee  vmovaps [rsp+0x90], xmm9
00007f30a29e27f7  vmovaps [rsp+0xA0], xmm11
00007f30a29e2800  vmovaps [rsp+0xB0], xmm12
00007f30a29e2809  vmovaps [rsp+0xC0], xmm13
00007f30a29e2812  vmovaps [rsp+0xD0], xmm14
00007f30a29e281b  vmovaps [rsp+0xE0], xmm15
00007f30a29e2824  sub rsp, 0x30
00007f30a29e2828  movaps [rsp], xmm10
00007f30a29e282d  movaps [rsp+0x10], xmm8
00007f30a29e2833  movaps [rsp+0x20], xmm14
00007f30a29e2839  lea rdi, [rsp]
00007f30a29e283d  mov esi, 0x00
00007f30a29e2842  mov rax, 0x5FE955026530
00007f30a29e284c  call rax
00007f30a29e284e  movaps xmm10, [rsp]
00007f30a29e2853  add rsp, 0x30
00007f30a29e2857  vmovaps xmm0, [rsp]
00007f30a29e285c  vmovaps xmm1, [rsp+0x10]
00007f30a29e2862  vmovaps xmm2, [rsp+0x20]
00007f30a29e2868  vmovaps xmm3, [rsp+0x30]
00007f30a29e286e  vmovaps xmm4, [rsp+0x40]
00007f30a29e2874  vmovaps xmm5, [rsp+0x50]
00007f30a29e287a  vmovaps xmm6, [rsp+0x60]
00007f30a29e2880  vmovaps xmm7, [rsp+0x70]
00007f30a29e2886  vmovaps xmm8, [rsp+0x80]
00007f30a29e288f  vmovaps xmm9, [rsp+0x90]
00007f30a29e2898  vmovaps xmm11, [rsp+0xA0]
00007f30a29e28a1  vmovaps xmm12, [rsp+0xB0]
00007f30a29e28aa  vmovaps xmm13, [rsp+0xC0]
00007f30a29e28b3  vmovaps xmm14, [rsp+0xD0]
00007f30a29e28bc  vmovaps xmm15, [rsp+0xE0]
00007f30a29e28c5  add rsp, 0xF0
00007f30a29e28cc  pop r11
00007f30a29e28ce  pop r10
00007f30a29e28d0  pop r9
00007f30a29e28d2  pop r8
00007f30a29e28d4  pop rsi
00007f30a29e28d5  pop rdi
00007f30a29e28d6  pop rdx
00007f30a29e28d7  pop rcx
00007f30a29e28d8  pop rax
00007f30a29e28d9  add rsp, 0x08
00007f30a29e28dd  jmp 0x00007F30A29DF5D8
00007f30a29e28e2  sub rsp, 0x08
00007f30a29e28e6  push rax
00007f30a29e28e7  push rcx
00007f30a29e28e8  push rdx
00007f30a29e28e9  push rdi
00007f30a29e28ea  push rsi
00007f30a29e28eb  push r8
00007f30a29e28ed  push r9
00007f30a29e28ef  push r10
00007f30a29e28f1  push r11
00007f30a29e28f3  sub rsp, 0xF0
00007f30a29e28fa  vmovaps [rsp], xmm0
00007f30a29e28ff  vmovaps [rsp+0x10], xmm1
00007f30a29e2905  vmovaps [rsp+0x20], xmm2
00007f30a29e290b  vmovaps [rsp+0x30], xmm3
00007f30a29e2911  vmovaps [rsp+0x40], xmm4
00007f30a29e2917  vmovaps [rsp+0x50], xmm5
00007f30a29e291d  vmovaps [rsp+0x60], xmm6
00007f30a29e2923  vmovaps [rsp+0x70], xmm7
00007f30a29e2929  vmovaps [rsp+0x80], xmm8
00007f30a29e2932  vmovaps [rsp+0x90], xmm9
00007f30a29e293b  vmovaps [rsp+0xA0], xmm10
00007f30a29e2944  vmovaps [rsp+0xB0], xmm11
00007f30a29e294d  vmovaps [rsp+0xC0], xmm12
00007f30a29e2956  vmovaps [rsp+0xD0], xmm13
00007f30a29e295f  vmovaps [rsp+0xE0], xmm15
00007f30a29e2968  sub rsp, 0x30
00007f30a29e296c  movaps [rsp], xmm14
00007f30a29e2971  movaps [rsp+0x10], xmm8
00007f30a29e2977  movaps [rsp+0x20], xmm4
00007f30a29e297c  lea rdi, [rsp]
00007f30a29e2980  mov esi, 0x00
00007f30a29e2985  mov rax, 0x5FE955026530
00007f30a29e298f  call rax
00007f30a29e2991  movaps xmm14, [rsp]
00007f30a29e2996  add rsp, 0x30
00007f30a29e299a  vmovaps xmm0, [rsp]
00007f30a29e299f  vmovaps xmm1, [rsp+0x10]
00007f30a29e29a5  vmovaps xmm2, [rsp+0x20]
00007f30a29e29ab  vmovaps xmm3, [rsp+0x30]
00007f30a29e29b1  vmovaps xmm4, [rsp+0x40]
00007f30a29e29b7  vmovaps xmm5, [rsp+0x50]
00007f30a29e29bd  vmovaps xmm6, [rsp+0x60]
00007f30a29e29c3  vmovaps xmm7, [rsp+0x70]
00007f30a29e29c9  vmovaps xmm8, [rsp+0x80]
00007f30a29e29d2  vmovaps xmm9, [rsp+0x90]
00007f30a29e29db  vmovaps xmm10, [rsp+0xA0]
00007f30a29e29e4  vmovaps xmm11, [rsp+0xB0]
00007f30a29e29ed  vmovaps xmm12, [rsp+0xC0]
00007f30a29e29f6  vmovaps xmm13, [rsp+0xD0]
00007f30a29e29ff  vmovaps xmm15, [rsp+0xE0]
00007f30a29e2a08  add rsp, 0xF0
00007f30a29e2a0f  pop r11
00007f30a29e2a11  pop r10
00007f30a29e2a13  pop r9
00007f30a29e2a15  pop r8
00007f30a29e2a17  pop rsi
00007f30a29e2a18  pop rdi
00007f30a29e2a19  pop rdx
00007f30a29e2a1a  pop rcx
00007f30a29e2a1b  pop rax
00007f30a29e2a1c  add rsp, 0x08
00007f30a29e2a20  jmp 0x00007F30A29DF5F8
00007f30a29e2a25  sub rsp, 0x08
00007f30a29e2a29  push rax
00007f30a29e2a2a  push rcx
00007f30a29e2a2b  push rdx
00007f30a29e2a2c  push rdi
00007f30a29e2a2d  push rsi
00007f30a29e2a2e  push r8
00007f30a29e2a30  push r9
00007f30a29e2a32  push r10
00007f30a29e2a34  push r11
00007f30a29e2a36  sub rsp, 0xF0
00007f30a29e2a3d  vmovaps [rsp], xmm0
00007f30a29e2a42  vmovaps [rsp+0x10], xmm1
00007f30a29e2a48  vmovaps [rsp+0x20], xmm2
00007f30a29e2a4e  vmovaps [rsp+0x30], xmm3
00007f30a29e2a54  vmovaps [rsp+0x40], xmm5
00007f30a29e2a5a  vmovaps [rsp+0x50], xmm6
00007f30a29e2a60  vmovaps [rsp+0x60], xmm7
00007f30a29e2a66  vmovaps [rsp+0x70], xmm8
00007f30a29e2a6c  vmovaps [rsp+0x80], xmm9
00007f30a29e2a75  vmovaps [rsp+0x90], xmm10
00007f30a29e2a7e  vmovaps [rsp+0xA0], xmm11
00007f30a29e2a87  vmovaps [rsp+0xB0], xmm12
00007f30a29e2a90  vmovaps [rsp+0xC0], xmm13
00007f30a29e2a99  vmovaps [rsp+0xD0], xmm14
00007f30a29e2aa2  vmovaps [rsp+0xE0], xmm15
00007f30a29e2aab  sub rsp, 0x30
00007f30a29e2aaf  movaps [rsp], xmm4
00007f30a29e2ab3  movaps [rsp+0x10], xmm13
00007f30a29e2ab9  movaps [rsp+0x20], xmm8
00007f30a29e2abf  lea rdi, [rsp]
00007f30a29e2ac3  mov esi, 0x00
00007f30a29e2ac8  mov rax, 0x5FE955026530
00007f30a29e2ad2  call rax
00007f30a29e2ad4  movaps xmm4, [rsp]
00007f30a29e2ad8  add rsp, 0x30
00007f30a29e2adc  vmovaps xmm0, [rsp]
00007f30a29e2ae1  vmovaps xmm1, [rsp+0x10]
00007f30a29e2ae7  vmovaps xmm2, [rsp+0x20]
00007f30a29e2aed  vmovaps xmm3, [rsp+0x30]
00007f30a29e2af3  vmovaps xmm5, [rsp+0x40]
00007f30a29e2af9  vmovaps xmm6, [rsp+0x50]
00007f30a29e2aff  vmovaps xmm7, [rsp+0x60]
00007f30a29e2b05  vmovaps xmm8, [rsp+0x70]
00007f30a29e2b0b  vmovaps xmm9, [rsp+0x80]
00007f30a29e2b14  vmovaps xmm10, [rsp+0x90]
00007f30a29e2b1d  vmovaps xmm11, [rsp+0xA0]
00007f30a29e2b26  vmovaps xmm12, [rsp+0xB0]
00007f30a29e2b2f  vmovaps xmm13, [rsp+0xC0]
00007f30a29e2b38  vmovaps xmm14, [rsp+0xD0]
00007f30a29e2b41  vmovaps xmm15, [rsp+0xE0]
00007f30a29e2b4a  add rsp, 0xF0
00007f30a29e2b51  pop r11
00007f30a29e2b53  pop r10
00007f30a29e2b55  pop r9
00007f30a29e2b57  pop r8
00007f30a29e2b59  pop rsi
00007f30a29e2b5a  pop rdi
00007f30a29e2b5b  pop rdx
00007f30a29e2b5c  pop rcx
00007f30a29e2b5d  pop rax
00007f30a29e2b5e  add rsp, 0x08
00007f30a29e2b62  jmp 0x00007F30A29DF61D
00007f30a29e2b67  sub rsp, 0x08
00007f30a29e2b6b  push rax
00007f30a29e2b6c  push rcx
00007f30a29e2b6d  push rdx
00007f30a29e2b6e  push rdi
00007f30a29e2b6f  push rsi
00007f30a29e2b70  push r8
00007f30a29e2b72  push r9
00007f30a29e2b74  push r10
00007f30a29e2b76  push r11
00007f30a29e2b78  sub rsp, 0xF0
00007f30a29e2b7f  vmovaps [rsp], xmm0
00007f30a29e2b84  vmovaps [rsp+0x10], xmm1
00007f30a29e2b8a  vmovaps [rsp+0x20], xmm2
00007f30a29e2b90  vmovaps [rsp+0x30], xmm3
00007f30a29e2b96  vmovaps [rsp+0x40], xmm4
00007f30a29e2b9c  vmovaps [rsp+0x50], xmm5
00007f30a29e2ba2  vmovaps [rsp+0x60], xmm6
00007f30a29e2ba8  vmovaps [rsp+0x70], xmm7
00007f30a29e2bae  vmovaps [rsp+0x80], xmm8
00007f30a29e2bb7  vmovaps [rsp+0x90], xmm9
00007f30a29e2bc0  vmovaps [rsp+0xA0], xmm10
00007f30a29e2bc9  vmovaps [rsp+0xB0], xmm11
00007f30a29e2bd2  vmovaps [rsp+0xC0], xmm12
00007f30a29e2bdb  vmovaps [rsp+0xD0], xmm14
00007f30a29e2be4  vmovaps [rsp+0xE0], xmm15
00007f30a29e2bed  sub rsp, 0x30
00007f30a29e2bf1  movaps [rsp], xmm13
00007f30a29e2bf6  movaps [rsp+0x10], xmm15
00007f30a29e2bfc  movaps [rsp+0x20], xmm9
00007f30a29e2c02  lea rdi, [rsp]
00007f30a29e2c06  mov esi, 0x00
00007f30a29e2c0b  mov rax, 0x5FE955026530
00007f30a29e2c15  call rax
00007f30a29e2c17  movaps xmm13, [rsp]
00007f30a29e2c1c  add rsp, 0x30
00007f30a29e2c20  vmovaps xmm0, [rsp]
00007f30a29e2c25  vmovaps xmm1, [rsp+0x10]
00007f30a29e2c2b  vmovaps xmm2, [rsp+0x20]
00007f30a29e2c31  vmovaps xmm3, [rsp+0x30]
00007f30a29e2c37  vmovaps xmm4, [rsp+0x40]
00007f30a29e2c3d  vmovaps xmm5, [rsp+0x50]
00007f30a29e2c43  vmovaps xmm6, [rsp+0x60]
00007f30a29e2c49  vmovaps xmm7, [rsp+0x70]
00007f30a29e2c4f  vmovaps xmm8, [rsp+0x80]
00007f30a29e2c58  vmovaps xmm9, [rsp+0x90]
00007f30a29e2c61  vmovaps xmm10, [rsp+0xA0]
00007f30a29e2c6a  vmovaps xmm11, [rsp+0xB0]
00007f30a29e2c73  vmovaps xmm12, [rsp+0xC0]
00007f30a29e2c7c  vmovaps xmm14, [rsp+0xD0]
00007f30a29e2c85  vmovaps xmm15, [rsp+0xE0]
00007f30a29e2c8e  add rsp, 0xF0
00007f30a29e2c95  pop r11
00007f30a29e2c97  pop r10
00007f30a29e2c99  pop r9
00007f30a29e2c9b  pop r8
00007f30a29e2c9d  pop rsi
00007f30a29e2c9e  pop rdi
00007f30a29e2c9f  pop rdx
00007f30a29e2ca0  pop rcx
00007f30a29e2ca1  pop rax
00007f30a29e2ca2  add rsp, 0x08
00007f30a29e2ca6  jmp 0x00007F30A29DF638
00007f30a29e2cab  sub rsp, 0x08
00007f30a29e2caf  push rax
00007f30a29e2cb0  push rcx
00007f30a29e2cb1  push rdx
00007f30a29e2cb2  push rdi
00007f30a29e2cb3  push rsi
00007f30a29e2cb4  push r8
00007f30a29e2cb6  push r9
00007f30a29e2cb8  push r10
00007f30a29e2cba  push r11
00007f30a29e2cbc  sub rsp, 0xF0
00007f30a29e2cc3  vmovaps [rsp], xmm0
00007f30a29e2cc8  vmovaps [rsp+0x10], xmm1
00007f30a29e2cce  vmovaps [rsp+0x20], xmm2
00007f30a29e2cd4  vmovaps [rsp+0x30], xmm3
00007f30a29e2cda  vmovaps [rsp+0x40], xmm4
00007f30a29e2ce0  vmovaps [rsp+0x50], xmm5
00007f30a29e2ce6  vmovaps [rsp+0x60], xmm6
00007f30a29e2cec  vmovaps [rsp+0x70], xmm7
00007f30a29e2cf2  vmovaps [rsp+0x80], xmm8
00007f30a29e2cfb  vmovaps [rsp+0x90], xmm9
00007f30a29e2d04  vmovaps [rsp+0xA0], xmm10
00007f30a29e2d0d  vmovaps [rsp+0xB0], xmm11
00007f30a29e2d16  vmovaps [rsp+0xC0], xmm12
00007f30a29e2d1f  vmovaps [rsp+0xD0], xmm13
00007f30a29e2d28  vmovaps [rsp+0xE0], xmm14
00007f30a29e2d31  sub rsp, 0x30
00007f30a29e2d35  movaps [rsp], xmm15
00007f30a29e2d3a  movaps [rsp+0x10], xmm1
00007f30a29e2d3f  movaps [rsp+0x20], xmm5
00007f30a29e2d44  lea rdi, [rsp]
00007f30a29e2d48  mov esi, 0x00
00007f30a29e2d4d  mov rax, 0x5FE955026530
00007f30a29e2d57  call rax
00007f30a29e2d59  movaps xmm15, [rsp]
00007f30a29e2d5e  add rsp, 0x30
00007f30a29e2d62  vmovaps xmm0, [rsp]
00007f30a29e2d67  vmovaps xmm1, [rsp+0x10]
00007f30a29e2d6d  vmovaps xmm2, [rsp+0x20]
00007f30a29e2d73  vmovaps xmm3, [rsp+0x30]
00007f30a29e2d79  vmovaps xmm4, [rsp+0x40]
00007f30a29e2d7f  vmovaps xmm5, [rsp+0x50]
00007f30a29e2d85  vmovaps xmm6, [rsp+0x60]
00007f30a29e2d8b  vmovaps xmm7, [rsp+0x70]
00007f30a29e2d91  vmovaps xmm8, [rsp+0x80]
00007f30a29e2d9a  vmovaps xmm9, [rsp+0x90]
00007f30a29e2da3  vmovaps xmm10, [rsp+0xA0]
00007f30a29e2dac  vmovaps xmm11, [rsp+0xB0]
00007f30a29e2db5  vmovaps xmm12, [rsp+0xC0]
00007f30a29e2dbe  vmovaps xmm13, [rsp+0xD0]
00007f30a29e2dc7  vmovaps xmm14, [rsp+0xE0]
00007f30a29e2dd0  add rsp, 0xF0
00007f30a29e2dd7  pop r11
00007f30a29e2dd9  pop r10
00007f30a29e2ddb  pop r9
00007f30a29e2ddd  pop r8
00007f30a29e2ddf  pop rsi
00007f30a29e2de0  pop rdi
00007f30a29e2de1  pop rdx
00007f30a29e2de2  pop rcx
00007f30a29e2de3  pop rax
00007f30a29e2de4  add rsp, 0x08
00007f30a29e2de8  jmp 0x00007F30A29DF653
00007f30a29e2ded  call 0x00007F30A28B52F0
00007f30a29e2df2  jmp 0x00007F30A29DF6AE
00007f30a29e2df7  sub rsp, 0x08
00007f30a29e2dfb  push rax
00007f30a29e2dfc  push rcx
00007f30a29e2dfd  push rdx
00007f30a29e2dfe  push rdi
00007f30a29e2dff  push rsi
00007f30a29e2e00  push r8
00007f30a29e2e02  push r9
00007f30a29e2e04  push r10
00007f30a29e2e06  push r11
00007f30a29e2e08  sub rsp, 0xF0
00007f30a29e2e0f  vmovaps [rsp], xmm0
00007f30a29e2e14  vmovaps [rsp+0x10], xmm1
00007f30a29e2e1a  vmovaps [rsp+0x20], xmm2
00007f30a29e2e20  vmovaps [rsp+0x30], xmm3
00007f30a29e2e26  vmovaps [rsp+0x40], xmm4
00007f30a29e2e2c  vmovaps [rsp+0x50], xmm5
00007f30a29e2e32  vmovaps [rsp+0x60], xmm6
00007f30a29e2e38  vmovaps [rsp+0x70], xmm7
00007f30a29e2e3e  vmovaps [rsp+0x80], xmm8
00007f30a29e2e47  vmovaps [rsp+0x90], xmm10
00007f30a29e2e50  vmovaps [rsp+0xA0], xmm11
00007f30a29e2e59  vmovaps [rsp+0xB0], xmm12
00007f30a29e2e62  vmovaps [rsp+0xC0], xmm13
00007f30a29e2e6b  vmovaps [rsp+0xD0], xmm14
00007f30a29e2e74  vmovaps [rsp+0xE0], xmm15
00007f30a29e2e7d  sub rsp, 0x30
00007f30a29e2e81  movaps [rsp], xmm9
00007f30a29e2e86  movaps [rsp+0x10], xmm8
00007f30a29e2e8c  movaps [rsp+0x20], xmm11
00007f30a29e2e92  lea rdi, [rsp]
00007f30a29e2e96  mov esi, 0x00
00007f30a29e2e9b  mov rax, 0x5FE955026530
00007f30a29e2ea5  call rax
00007f30a29e2ea7  movaps xmm9, [rsp]
00007f30a29e2eac  add rsp, 0x30
00007f30a29e2eb0  vmovaps xmm0, [rsp]
00007f30a29e2eb5  vmovaps xmm1, [rsp+0x10]
00007f30a29e2ebb  vmovaps xmm2, [rsp+0x20]
00007f30a29e2ec1  vmovaps xmm3, [rsp+0x30]
00007f30a29e2ec7  vmovaps xmm4, [rsp+0x40]
00007f30a29e2ecd  vmovaps xmm5, [rsp+0x50]
00007f30a29e2ed3  vmovaps xmm6, [rsp+0x60]
00007f30a29e2ed9  vmovaps xmm7, [rsp+0x70]
00007f30a29e2edf  vmovaps xmm8, [rsp+0x80]
00007f30a29e2ee8  vmovaps xmm10, [rsp+0x90]
00007f30a29e2ef1  vmovaps xmm11, [rsp+0xA0]
00007f30a29e2efa  vmovaps xmm12, [rsp+0xB0]
00007f30a29e2f03  vmovaps xmm13, [rsp+0xC0]
00007f30a29e2f0c  vmovaps xmm14, [rsp+0xD0]
00007f30a29e2f15  vmovaps xmm15, [rsp+0xE0]
00007f30a29e2f1e  add rsp, 0xF0
00007f30a29e2f25  pop r11
00007f30a29e2f27  pop r10
00007f30a29e2f29  pop r9
00007f30a29e2f2b  pop r8
00007f30a29e2f2d  pop rsi
00007f30a29e2f2e  pop rdi
00007f30a29e2f2f  pop rdx
00007f30a29e2f30  pop rcx
00007f30a29e2f31  pop rax
00007f30a29e2f32  add rsp, 0x08
00007f30a29e2f36  jmp 0x00007F30A29DF6E5
00007f30a29e2f3b  sub rsp, 0x08
00007f30a29e2f3f  push rax
00007f30a29e2f40  push rcx
00007f30a29e2f41  push rdx
00007f30a29e2f42  push rdi
00007f30a29e2f43  push rsi
00007f30a29e2f44  push r8
00007f30a29e2f46  push r9
00007f30a29e2f48  push r10
00007f30a29e2f4a  push r11
00007f30a29e2f4c  sub rsp, 0xF0
00007f30a29e2f53  vmovaps [rsp], xmm0
00007f30a29e2f58  vmovaps [rsp+0x10], xmm1
00007f30a29e2f5e  vmovaps [rsp+0x20], xmm2
00007f30a29e2f64  vmovaps [rsp+0x30], xmm3
00007f30a29e2f6a  vmovaps [rsp+0x40], xmm4
00007f30a29e2f70  vmovaps [rsp+0x50], xmm5
00007f30a29e2f76  vmovaps [rsp+0x60], xmm6
00007f30a29e2f7c  vmovaps [rsp+0x70], xmm7
00007f30a29e2f82  vmovaps [rsp+0x80], xmm8
00007f30a29e2f8b  vmovaps [rsp+0x90], xmm9
00007f30a29e2f94  vmovaps [rsp+0xA0], xmm10
00007f30a29e2f9d  vmovaps [rsp+0xB0], xmm12
00007f30a29e2fa6  vmovaps [rsp+0xC0], xmm13
00007f30a29e2faf  vmovaps [rsp+0xD0], xmm14
00007f30a29e2fb8  vmovaps [rsp+0xE0], xmm15
00007f30a29e2fc1  sub rsp, 0x30
00007f30a29e2fc5  movaps [rsp], xmm11
00007f30a29e2fca  movaps [rsp+0x10], xmm10
00007f30a29e2fd0  movaps [rsp+0x20], xmm6
00007f30a29e2fd5  lea rdi, [rsp]
00007f30a29e2fd9  mov esi, 0x00
00007f30a29e2fde  mov rax, 0x5FE955026530
00007f30a29e2fe8  call rax
00007f30a29e2fea  movaps xmm11, [rsp]
00007f30a29e2fef  add rsp, 0x30
00007f30a29e2ff3  vmovaps xmm0, [rsp]
00007f30a29e2ff8  vmovaps xmm1, [rsp+0x10]
00007f30a29e2ffe  vmovaps xmm2, [rsp+0x20]
00007f30a29e3004  vmovaps xmm3, [rsp+0x30]
00007f30a29e300a  vmovaps xmm4, [rsp+0x40]
00007f30a29e3010  vmovaps xmm5, [rsp+0x50]
00007f30a29e3016  vmovaps xmm6, [rsp+0x60]
00007f30a29e301c  vmovaps xmm7, [rsp+0x70]
00007f30a29e3022  vmovaps xmm8, [rsp+0x80]
00007f30a29e302b  vmovaps xmm9, [rsp+0x90]
00007f30a29e3034  vmovaps xmm10, [rsp+0xA0]
00007f30a29e303d  vmovaps xmm12, [rsp+0xB0]
00007f30a29e3046  vmovaps xmm13, [rsp+0xC0]
00007f30a29e304f  vmovaps xmm14, [rsp+0xD0]
00007f30a29e3058  vmovaps xmm15, [rsp+0xE0]
00007f30a29e3061  add rsp, 0xF0
00007f30a29e3068  pop r11
00007f30a29e306a  pop r10
00007f30a29e306c  pop r9
00007f30a29e306e  pop r8
00007f30a29e3070  pop rsi
00007f30a29e3071  pop rdi
00007f30a29e3072  pop rdx
00007f30a29e3073  pop rcx
00007f30a29e3074  pop rax
00007f30a29e3075  add rsp, 0x08
00007f30a29e3079  jmp 0x00007F30A29DF700
00007f30a29e307e  sub rsp, 0x08
00007f30a29e3082  push rax
00007f30a29e3083  push rcx
00007f30a29e3084  push rdx
00007f30a29e3085  push rdi
00007f30a29e3086  push rsi
00007f30a29e3087  push r8
00007f30a29e3089  push r9
00007f30a29e308b  push r10
00007f30a29e308d  push r11
00007f30a29e308f  sub rsp, 0xF0
00007f30a29e3096  vmovaps [rsp], xmm0
00007f30a29e309b  vmovaps [rsp+0x10], xmm1
00007f30a29e30a1  vmovaps [rsp+0x20], xmm2
00007f30a29e30a7  vmovaps [rsp+0x30], xmm3
00007f30a29e30ad  vmovaps [rsp+0x40], xmm4
00007f30a29e30b3  vmovaps [rsp+0x50], xmm5
00007f30a29e30b9  vmovaps [rsp+0x60], xmm6
00007f30a29e30bf  vmovaps [rsp+0x70], xmm7
00007f30a29e30c5  vmovaps [rsp+0x80], xmm8
00007f30a29e30ce  vmovaps [rsp+0x90], xmm9
00007f30a29e30d7  vmovaps [rsp+0xA0], xmm11
00007f30a29e30e0  vmovaps [rsp+0xB0], xmm12
00007f30a29e30e9  vmovaps [rsp+0xC0], xmm13
00007f30a29e30f2  vmovaps [rsp+0xD0], xmm14
00007f30a29e30fb  vmovaps [rsp+0xE0], xmm15
00007f30a29e3104  sub rsp, 0x30
00007f30a29e3108  movaps [rsp], xmm10
00007f30a29e310d  movaps [rsp+0x10], xmm14
00007f30a29e3113  movaps [rsp+0x20], xmm4
00007f30a29e3118  lea rdi, [rsp]
00007f30a29e311c  mov esi, 0x00
00007f30a29e3121  mov rax, 0x5FE955026530
00007f30a29e312b  call rax
00007f30a29e312d  movaps xmm10, [rsp]
00007f30a29e3132  add rsp, 0x30
00007f30a29e3136  vmovaps xmm0, [rsp]
00007f30a29e313b  vmovaps xmm1, [rsp+0x10]
00007f30a29e3141  vmovaps xmm2, [rsp+0x20]
00007f30a29e3147  vmovaps xmm3, [rsp+0x30]
00007f30a29e314d  vmovaps xmm4, [rsp+0x40]
00007f30a29e3153  vmovaps xmm5, [rsp+0x50]
00007f30a29e3159  vmovaps xmm6, [rsp+0x60]
00007f30a29e315f  vmovaps xmm7, [rsp+0x70]
00007f30a29e3165  vmovaps xmm8, [rsp+0x80]
00007f30a29e316e  vmovaps xmm9, [rsp+0x90]
00007f30a29e3177  vmovaps xmm11, [rsp+0xA0]
00007f30a29e3180  vmovaps xmm12, [rsp+0xB0]
00007f30a29e3189  vmovaps xmm13, [rsp+0xC0]
00007f30a29e3192  vmovaps xmm14, [rsp+0xD0]
00007f30a29e319b  vmovaps xmm15, [rsp+0xE0]
00007f30a29e31a4  add rsp, 0xF0
00007f30a29e31ab  pop r11
00007f30a29e31ad  pop r10
00007f30a29e31af  pop r9
00007f30a29e31b1  pop r8
00007f30a29e31b3  pop rsi
00007f30a29e31b4  pop rdi
00007f30a29e31b5  pop rdx
00007f30a29e31b6  pop rcx
00007f30a29e31b7  pop rax
00007f30a29e31b8  add rsp, 0x08
00007f30a29e31bc  jmp 0x00007F30A29DF71B
00007f30a29e31c1  sub rsp, 0x08
00007f30a29e31c5  push rax
00007f30a29e31c6  push rcx
00007f30a29e31c7  push rdx
00007f30a29e31c8  push rdi
00007f30a29e31c9  push rsi
00007f30a29e31ca  push r8
00007f30a29e31cc  push r9
00007f30a29e31ce  push r10
00007f30a29e31d0  push r11
00007f30a29e31d2  sub rsp, 0xF0
00007f30a29e31d9  vmovaps [rsp], xmm0
00007f30a29e31de  vmovaps [rsp+0x10], xmm1
00007f30a29e31e4  vmovaps [rsp+0x20], xmm2
00007f30a29e31ea  vmovaps [rsp+0x30], xmm3
00007f30a29e31f0  vmovaps [rsp+0x40], xmm4
00007f30a29e31f6  vmovaps [rsp+0x50], xmm5
00007f30a29e31fc  vmovaps [rsp+0x60], xmm6
00007f30a29e3202  vmovaps [rsp+0x70], xmm7
00007f30a29e3208  vmovaps [rsp+0x80], xmm9
00007f30a29e3211  vmovaps [rsp+0x90], xmm10
00007f30a29e321a  vmovaps [rsp+0xA0], xmm11
00007f30a29e3223  vmovaps [rsp+0xB0], xmm12
00007f30a29e322c  vmovaps [rsp+0xC0], xmm13
00007f30a29e3235  vmovaps [rsp+0xD0], xmm14
00007f30a29e323e  vmovaps [rsp+0xE0], xmm15
00007f30a29e3247  sub rsp, 0x30
00007f30a29e324b  movaps [rsp], xmm8
00007f30a29e3250  movaps [rsp+0x10], xmm1
00007f30a29e3255  movaps [rsp+0x20], xmm14
00007f30a29e325b  lea rdi, [rsp]
00007f30a29e325f  mov esi, 0x00
00007f30a29e3264  mov rax, 0x5FE955026530
00007f30a29e326e  call rax
00007f30a29e3270  movaps xmm8, [rsp]
00007f30a29e3275  add rsp, 0x30
00007f30a29e3279  vmovaps xmm0, [rsp]
00007f30a29e327e  vmovaps xmm1, [rsp+0x10]
00007f30a29e3284  vmovaps xmm2, [rsp+0x20]
00007f30a29e328a  vmovaps xmm3, [rsp+0x30]
00007f30a29e3290  vmovaps xmm4, [rsp+0x40]
00007f30a29e3296  vmovaps xmm5, [rsp+0x50]
00007f30a29e329c  vmovaps xmm6, [rsp+0x60]
00007f30a29e32a2  vmovaps xmm7, [rsp+0x70]
00007f30a29e32a8  vmovaps xmm9, [rsp+0x80]
00007f30a29e32b1  vmovaps xmm10, [rsp+0x90]
00007f30a29e32ba  vmovaps xmm11, [rsp+0xA0]
00007f30a29e32c3  vmovaps xmm12, [rsp+0xB0]
00007f30a29e32cc  vmovaps xmm13, [rsp+0xC0]
00007f30a29e32d5  vmovaps xmm14, [rsp+0xD0]
00007f30a29e32de  vmovaps xmm15, [rsp+0xE0]
00007f30a29e32e7  add rsp, 0xF0
00007f30a29e32ee  pop r11
00007f30a29e32f0  pop r10
00007f30a29e32f2  pop r9
00007f30a29e32f4  pop r8
00007f30a29e32f6  pop rsi
00007f30a29e32f7  pop rdi
00007f30a29e32f8  pop rdx
00007f30a29e32f9  pop rcx
00007f30a29e32fa  pop rax
00007f30a29e32fb  add rsp, 0x08
00007f30a29e32ff  jmp 0x00007F30A29DF741
00007f30a29e3304  sub rsp, 0x08
00007f30a29e3308  push rax
00007f30a29e3309  push rcx
00007f30a29e330a  push rdx
00007f30a29e330b  push rdi
00007f30a29e330c  push rsi
00007f30a29e330d  push r8
00007f30a29e330f  push r9
00007f30a29e3311  push r10
00007f30a29e3313  push r11
00007f30a29e3315  sub rsp, 0xF0
00007f30a29e331c  vmovaps [rsp], xmm0
00007f30a29e3321  vmovaps [rsp+0x10], xmm1
00007f30a29e3327  vmovaps [rsp+0x20], xmm2
00007f30a29e332d  vmovaps [rsp+0x30], xmm3
00007f30a29e3333  vmovaps [rsp+0x40], xmm4
00007f30a29e3339  vmovaps [rsp+0x50], xmm5
00007f30a29e333f  vmovaps [rsp+0x60], xmm7
00007f30a29e3345  vmovaps [rsp+0x70], xmm8
00007f30a29e334b  vmovaps [rsp+0x80], xmm9
00007f30a29e3354  vmovaps [rsp+0x90], xmm10
00007f30a29e335d  vmovaps [rsp+0xA0], xmm11
00007f30a29e3366  vmovaps [rsp+0xB0], xmm12
00007f30a29e336f  vmovaps [rsp+0xC0], xmm13
00007f30a29e3378  vmovaps [rsp+0xD0], xmm14
00007f30a29e3381  vmovaps [rsp+0xE0], xmm15
00007f30a29e338a  sub rsp, 0x30
00007f30a29e338e  movaps [rsp], xmm6
00007f30a29e3392  movaps [rsp+0x10], xmm1
00007f30a29e3397  movaps [rsp+0x20], xmm14
00007f30a29e339d  lea rdi, [rsp]
00007f30a29e33a1  mov esi, 0x00
00007f30a29e33a6  mov rax, 0x5FE955026530
00007f30a29e33b0  call rax
00007f30a29e33b2  movaps xmm6, [rsp]
00007f30a29e33b6  add rsp, 0x30
00007f30a29e33ba  vmovaps xmm0, [rsp]
00007f30a29e33bf  vmovaps xmm1, [rsp+0x10]
00007f30a29e33c5  vmovaps xmm2, [rsp+0x20]
00007f30a29e33cb  vmovaps xmm3, [rsp+0x30]
00007f30a29e33d1  vmovaps xmm4, [rsp+0x40]
00007f30a29e33d7  vmovaps xmm5, [rsp+0x50]
00007f30a29e33dd  vmovaps xmm7, [rsp+0x60]
00007f30a29e33e3  vmovaps xmm8, [rsp+0x70]
00007f30a29e33e9  vmovaps xmm9, [rsp+0x80]
00007f30a29e33f2  vmovaps xmm10, [rsp+0x90]
00007f30a29e33fb  vmovaps xmm11, [rsp+0xA0]
00007f30a29e3404  vmovaps xmm12, [rsp+0xB0]
00007f30a29e340d  vmovaps xmm13, [rsp+0xC0]
00007f30a29e3416  vmovaps xmm14, [rsp+0xD0]
00007f30a29e341f  vmovaps xmm15, [rsp+0xE0]
00007f30a29e3428  add rsp, 0xF0
00007f30a29e342f  pop r11
00007f30a29e3431  pop r10
00007f30a29e3433  pop r9
00007f30a29e3435  pop r8
00007f30a29e3437  pop rsi
00007f30a29e3438  pop rdi
00007f30a29e3439  pop rdx
00007f30a29e343a  pop rcx
00007f30a29e343b  pop rax
00007f30a29e343c  add rsp, 0x08
00007f30a29e3440  jmp 0x00007F30A29DF76D
00007f30a29e3445  sub rsp, 0x08
00007f30a29e3449  push rax
00007f30a29e344a  push rcx
00007f30a29e344b  push rdx
00007f30a29e344c  push rdi
00007f30a29e344d  push rsi
00007f30a29e344e  push r8
00007f30a29e3450  push r9
00007f30a29e3452  push r10
00007f30a29e3454  push r11
00007f30a29e3456  sub rsp, 0xF0
00007f30a29e345d  vmovaps [rsp], xmm0
00007f30a29e3462  vmovaps [rsp+0x10], xmm1
00007f30a29e3468  vmovaps [rsp+0x20], xmm2
00007f30a29e346e  vmovaps [rsp+0x30], xmm3
00007f30a29e3474  vmovaps [rsp+0x40], xmm4
00007f30a29e347a  vmovaps [rsp+0x50], xmm5
00007f30a29e3480  vmovaps [rsp+0x60], xmm6
00007f30a29e3486  vmovaps [rsp+0x70], xmm7
00007f30a29e348c  vmovaps [rsp+0x80], xmm8
00007f30a29e3495  vmovaps [rsp+0x90], xmm9
00007f30a29e349e  vmovaps [rsp+0xA0], xmm10
00007f30a29e34a7  vmovaps [rsp+0xB0], xmm11
00007f30a29e34b0  vmovaps [rsp+0xC0], xmm12
00007f30a29e34b9  vmovaps [rsp+0xD0], xmm13
00007f30a29e34c2  vmovaps [rsp+0xE0], xmm15
00007f30a29e34cb  sub rsp, 0x30
00007f30a29e34cf  movaps [rsp], xmm14
00007f30a29e34d4  movaps [rsp+0x10], xmm12
00007f30a29e34da  movaps [rsp+0x20], xmm1
00007f30a29e34df  lea rdi, [rsp]
00007f30a29e34e3  mov esi, 0x00
00007f30a29e34e8  mov rax, 0x5FE955026530
00007f30a29e34f2  call rax
00007f30a29e34f4  movaps xmm14, [rsp]
00007f30a29e34f9  add rsp, 0x30
00007f30a29e34fd  vmovaps xmm0, [rsp]
00007f30a29e3502  vmovaps xmm1, [rsp+0x10]
00007f30a29e3508  vmovaps xmm2, [rsp+0x20]
00007f30a29e350e  vmovaps xmm3, [rsp+0x30]
00007f30a29e3514  vmovaps xmm4, [rsp+0x40]
00007f30a29e351a  vmovaps xmm5, [rsp+0x50]
00007f30a29e3520  vmovaps xmm6, [rsp+0x60]
00007f30a29e3526  vmovaps xmm7, [rsp+0x70]
00007f30a29e352c  vmovaps xmm8, [rsp+0x80]
00007f30a29e3535  vmovaps xmm9, [rsp+0x90]
00007f30a29e353e  vmovaps xmm10, [rsp+0xA0]
00007f30a29e3547  vmovaps xmm11, [rsp+0xB0]
00007f30a29e3550  vmovaps xmm12, [rsp+0xC0]
00007f30a29e3559  vmovaps xmm13, [rsp+0xD0]
00007f30a29e3562  vmovaps xmm15, [rsp+0xE0]
00007f30a29e356b  add rsp, 0xF0
00007f30a29e3572  pop r11
00007f30a29e3574  pop r10
00007f30a29e3576  pop r9
00007f30a29e3578  pop r8
00007f30a29e357a  pop rsi
00007f30a29e357b  pop rdi
00007f30a29e357c  pop rdx
00007f30a29e357d  pop rcx
00007f30a29e357e  pop rax
00007f30a29e357f  add rsp, 0x08
00007f30a29e3583  jmp 0x00007F30A29DF793
00007f30a29e3588  sub rsp, 0x08
00007f30a29e358c  push rax
00007f30a29e358d  push rcx
00007f30a29e358e  push rdx
00007f30a29e358f  push rdi
00007f30a29e3590  push rsi
00007f30a29e3591  push r8
00007f30a29e3593  push r9
00007f30a29e3595  push r10
00007f30a29e3597  push r11
00007f30a29e3599  sub rsp, 0xF0
00007f30a29e35a0  vmovaps [rsp], xmm0
00007f30a29e35a5  vmovaps [rsp+0x10], xmm2
00007f30a29e35ab  vmovaps [rsp+0x20], xmm3
00007f30a29e35b1  vmovaps [rsp+0x30], xmm4
00007f30a29e35b7  vmovaps [rsp+0x40], xmm5
00007f30a29e35bd  vmovaps [rsp+0x50], xmm6
00007f30a29e35c3  vmovaps [rsp+0x60], xmm7
00007f30a29e35c9  vmovaps [rsp+0x70], xmm8
00007f30a29e35cf  vmovaps [rsp+0x80], xmm9
00007f30a29e35d8  vmovaps [rsp+0x90], xmm10
00007f30a29e35e1  vmovaps [rsp+0xA0], xmm11
00007f30a29e35ea  vmovaps [rsp+0xB0], xmm12
00007f30a29e35f3  vmovaps [rsp+0xC0], xmm13
00007f30a29e35fc  vmovaps [rsp+0xD0], xmm14
00007f30a29e3605  vmovaps [rsp+0xE0], xmm15
00007f30a29e360e  sub rsp, 0x30
00007f30a29e3612  movaps [rsp], xmm1
00007f30a29e3616  movaps [rsp+0x10], xmm13
00007f30a29e361c  movaps [rsp+0x20], xmm9
00007f30a29e3622  lea rdi, [rsp]
00007f30a29e3626  mov esi, 0x00
00007f30a29e362b  mov rax, 0x5FE955026530
00007f30a29e3635  call rax
00007f30a29e3637  movaps xmm1, [rsp]
00007f30a29e363b  add rsp, 0x30
00007f30a29e363f  vmovaps xmm0, [rsp]
00007f30a29e3644  vmovaps xmm2, [rsp+0x10]
00007f30a29e364a  vmovaps xmm3, [rsp+0x20]
00007f30a29e3650  vmovaps xmm4, [rsp+0x30]
00007f30a29e3656  vmovaps xmm5, [rsp+0x40]
00007f30a29e365c  vmovaps xmm6, [rsp+0x50]
00007f30a29e3662  vmovaps xmm7, [rsp+0x60]
00007f30a29e3668  vmovaps xmm8, [rsp+0x70]
00007f30a29e366e  vmovaps xmm9, [rsp+0x80]
00007f30a29e3677  vmovaps xmm10, [rsp+0x90]
00007f30a29e3680  vmovaps xmm11, [rsp+0xA0]
00007f30a29e3689  vmovaps xmm12, [rsp+0xB0]
00007f30a29e3692  vmovaps xmm13, [rsp+0xC0]
00007f30a29e369b  vmovaps xmm14, [rsp+0xD0]
00007f30a29e36a4  vmovaps xmm15, [rsp+0xE0]
00007f30a29e36ad  add rsp, 0xF0
00007f30a29e36b4  pop r11
00007f30a29e36b6  pop r10
00007f30a29e36b8  pop r9
00007f30a29e36ba  pop r8
00007f30a29e36bc  pop rsi
00007f30a29e36bd  pop rdi
00007f30a29e36be  pop rdx
00007f30a29e36bf  pop rcx
00007f30a29e36c0  pop rax
00007f30a29e36c1  add rsp, 0x08
00007f30a29e36c5  jmp 0x00007F30A29DF7AD
00007f30a29e36ca  sub rsp, 0x08
00007f30a29e36ce  push rax
00007f30a29e36cf  push rcx
00007f30a29e36d0  push rdx
00007f30a29e36d1  push rdi
00007f30a29e36d2  push rsi
00007f30a29e36d3  push r8
00007f30a29e36d5  push r9
00007f30a29e36d7  push r10
00007f30a29e36d9  push r11
00007f30a29e36db  sub rsp, 0xF0
00007f30a29e36e2  vmovaps [rsp], xmm0
00007f30a29e36e7  vmovaps [rsp+0x10], xmm1
00007f30a29e36ed  vmovaps [rsp+0x20], xmm2
00007f30a29e36f3  vmovaps [rsp+0x30], xmm3
00007f30a29e36f9  vmovaps [rsp+0x40], xmm4
00007f30a29e36ff  vmovaps [rsp+0x50], xmm5
00007f30a29e3705  vmovaps [rsp+0x60], xmm6
00007f30a29e370b  vmovaps [rsp+0x70], xmm7
00007f30a29e3711  vmovaps [rsp+0x80], xmm8
00007f30a29e371a  vmovaps [rsp+0x90], xmm9
00007f30a29e3723  vmovaps [rsp+0xA0], xmm10
00007f30a29e372c  vmovaps [rsp+0xB0], xmm11
00007f30a29e3735  vmovaps [rsp+0xC0], xmm13
00007f30a29e373e  vmovaps [rsp+0xD0], xmm14
00007f30a29e3747  vmovaps [rsp+0xE0], xmm15
00007f30a29e3750  sub rsp, 0x30
00007f30a29e3754  movaps [rsp], xmm12
00007f30a29e3759  movaps [rsp+0x10], xmm7
00007f30a29e375e  movaps [rsp+0x20], xmm13
00007f30a29e3764  lea rdi, [rsp]
00007f30a29e3768  mov esi, 0x00
00007f30a29e376d  mov rax, 0x5FE955026530
00007f30a29e3777  call rax
00007f30a29e3779  movaps xmm12, [rsp]
00007f30a29e377e  add rsp, 0x30
00007f30a29e3782  vmovaps xmm0, [rsp]
00007f30a29e3787  vmovaps xmm1, [rsp+0x10]
00007f30a29e378d  vmovaps xmm2, [rsp+0x20]
00007f30a29e3793  vmovaps xmm3, [rsp+0x30]
00007f30a29e3799  vmovaps xmm4, [rsp+0x40]
00007f30a29e379f  vmovaps xmm5, [rsp+0x50]
00007f30a29e37a5  vmovaps xmm6, [rsp+0x60]
00007f30a29e37ab  vmovaps xmm7, [rsp+0x70]
00007f30a29e37b1  vmovaps xmm8, [rsp+0x80]
00007f30a29e37ba  vmovaps xmm9, [rsp+0x90]
00007f30a29e37c3  vmovaps xmm10, [rsp+0xA0]
00007f30a29e37cc  vmovaps xmm11, [rsp+0xB0]
00007f30a29e37d5  vmovaps xmm13, [rsp+0xC0]
00007f30a29e37de  vmovaps xmm14, [rsp+0xD0]
00007f30a29e37e7  vmovaps xmm15, [rsp+0xE0]
00007f30a29e37f0  add rsp, 0xF0
00007f30a29e37f7  pop r11
00007f30a29e37f9  pop r10
00007f30a29e37fb  pop r9
00007f30a29e37fd  pop r8
00007f30a29e37ff  pop rsi
00007f30a29e3800  pop rdi
00007f30a29e3801  pop rdx
00007f30a29e3802  pop rcx
00007f30a29e3803  pop rax
00007f30a29e3804  add rsp, 0x08
00007f30a29e3808  jmp 0x00007F30A29DF7D4
00007f30a29e380d  sub rsp, 0x08
00007f30a29e3811  push rax
00007f30a29e3812  push rcx
00007f30a29e3813  push rdx
00007f30a29e3814  push rdi
00007f30a29e3815  push rsi
00007f30a29e3816  push r8
00007f30a29e3818  push r9
00007f30a29e381a  push r10
00007f30a29e381c  push r11
00007f30a29e381e  sub rsp, 0xF0
00007f30a29e3825  vmovaps [rsp], xmm0
00007f30a29e382a  vmovaps [rsp+0x10], xmm1
00007f30a29e3830  vmovaps [rsp+0x20], xmm2
00007f30a29e3836  vmovaps [rsp+0x30], xmm3
00007f30a29e383c  vmovaps [rsp+0x40], xmm4
00007f30a29e3842  vmovaps [rsp+0x50], xmm5
00007f30a29e3848  vmovaps [rsp+0x60], xmm6
00007f30a29e384e  vmovaps [rsp+0x70], xmm7
00007f30a29e3854  vmovaps [rsp+0x80], xmm8
00007f30a29e385d  vmovaps [rsp+0x90], xmm9
00007f30a29e3866  vmovaps [rsp+0xA0], xmm10
00007f30a29e386f  vmovaps [rsp+0xB0], xmm11
00007f30a29e3878  vmovaps [rsp+0xC0], xmm12
00007f30a29e3881  vmovaps [rsp+0xD0], xmm14
00007f30a29e388a  vmovaps [rsp+0xE0], xmm15
00007f30a29e3893  sub rsp, 0x30
00007f30a29e3897  movaps [rsp], xmm13
00007f30a29e389c  movaps [rsp+0x10], xmm15
00007f30a29e38a2  movaps [rsp+0x20], xmm8
00007f30a29e38a8  lea rdi, [rsp]
00007f30a29e38ac  mov esi, 0x00
00007f30a29e38b1  mov rax, 0x5FE955026530
00007f30a29e38bb  call rax
00007f30a29e38bd  movaps xmm13, [rsp]
00007f30a29e38c2  add rsp, 0x30
00007f30a29e38c6  vmovaps xmm0, [rsp]
00007f30a29e38cb  vmovaps xmm1, [rsp+0x10]
00007f30a29e38d1  vmovaps xmm2, [rsp+0x20]
00007f30a29e38d7  vmovaps xmm3, [rsp+0x30]
00007f30a29e38dd  vmovaps xmm4, [rsp+0x40]
00007f30a29e38e3  vmovaps xmm5, [rsp+0x50]
00007f30a29e38e9  vmovaps xmm6, [rsp+0x60]
00007f30a29e38ef  vmovaps xmm7, [rsp+0x70]
00007f30a29e38f5  vmovaps xmm8, [rsp+0x80]
00007f30a29e38fe  vmovaps xmm9, [rsp+0x90]
00007f30a29e3907  vmovaps xmm10, [rsp+0xA0]
00007f30a29e3910  vmovaps xmm11, [rsp+0xB0]
00007f30a29e3919  vmovaps xmm12, [rsp+0xC0]
00007f30a29e3922  vmovaps xmm14, [rsp+0xD0]
00007f30a29e392b  vmovaps xmm15, [rsp+0xE0]
00007f30a29e3934  add rsp, 0xF0
00007f30a29e393b  pop r11
00007f30a29e393d  pop r10
00007f30a29e393f  pop r9
00007f30a29e3941  pop r8
00007f30a29e3943  pop rsi
00007f30a29e3944  pop rdi
00007f30a29e3945  pop rdx
00007f30a29e3946  pop rcx
00007f30a29e3947  pop rax
00007f30a29e3948  add rsp, 0x08
00007f30a29e394c  jmp 0x00007F30A29DF7EF
00007f30a29e3951  sub rsp, 0x08
00007f30a29e3955  push rax
00007f30a29e3956  push rcx
00007f30a29e3957  push rdx
00007f30a29e3958  push rdi
00007f30a29e3959  push rsi
00007f30a29e395a  push r8
00007f30a29e395c  push r9
00007f30a29e395e  push r10
00007f30a29e3960  push r11
00007f30a29e3962  sub rsp, 0xF0
00007f30a29e3969  vmovaps [rsp], xmm0
00007f30a29e396e  vmovaps [rsp+0x10], xmm1
00007f30a29e3974  vmovaps [rsp+0x20], xmm2
00007f30a29e397a  vmovaps [rsp+0x30], xmm3
00007f30a29e3980  vmovaps [rsp+0x40], xmm4
00007f30a29e3986  vmovaps [rsp+0x50], xmm5
00007f30a29e398c  vmovaps [rsp+0x60], xmm6
00007f30a29e3992  vmovaps [rsp+0x70], xmm7
00007f30a29e3998  vmovaps [rsp+0x80], xmm9
00007f30a29e39a1  vmovaps [rsp+0x90], xmm10
00007f30a29e39aa  vmovaps [rsp+0xA0], xmm11
00007f30a29e39b3  vmovaps [rsp+0xB0], xmm12
00007f30a29e39bc  vmovaps [rsp+0xC0], xmm13
00007f30a29e39c5  vmovaps [rsp+0xD0], xmm14
00007f30a29e39ce  vmovaps [rsp+0xE0], xmm15
00007f30a29e39d7  sub rsp, 0x30
00007f30a29e39db  movaps [rsp], xmm8
00007f30a29e39e0  movaps [rsp+0x10], xmm15
00007f30a29e39e6  movaps [rsp+0x20], xmm9
00007f30a29e39ec  lea rdi, [rsp]
00007f30a29e39f0  mov esi, 0x00
00007f30a29e39f5  mov rax, 0x5FE955026530
00007f30a29e39ff  call rax
00007f30a29e3a01  movaps xmm8, [rsp]
00007f30a29e3a06  add rsp, 0x30
00007f30a29e3a0a  vmovaps xmm0, [rsp]
00007f30a29e3a0f  vmovaps xmm1, [rsp+0x10]
00007f30a29e3a15  vmovaps xmm2, [rsp+0x20]
00007f30a29e3a1b  vmovaps xmm3, [rsp+0x30]
00007f30a29e3a21  vmovaps xmm4, [rsp+0x40]
00007f30a29e3a27  vmovaps xmm5, [rsp+0x50]
00007f30a29e3a2d  vmovaps xmm6, [rsp+0x60]
00007f30a29e3a33  vmovaps xmm7, [rsp+0x70]
00007f30a29e3a39  vmovaps xmm9, [rsp+0x80]
00007f30a29e3a42  vmovaps xmm10, [rsp+0x90]
00007f30a29e3a4b  vmovaps xmm11, [rsp+0xA0]
00007f30a29e3a54  vmovaps xmm12, [rsp+0xB0]
00007f30a29e3a5d  vmovaps xmm13, [rsp+0xC0]
00007f30a29e3a66  vmovaps xmm14, [rsp+0xD0]
00007f30a29e3a6f  vmovaps xmm15, [rsp+0xE0]
00007f30a29e3a78  add rsp, 0xF0
00007f30a29e3a7f  pop r11
00007f30a29e3a81  pop r10
00007f30a29e3a83  pop r9
00007f30a29e3a85  pop r8
00007f30a29e3a87  pop rsi
00007f30a29e3a88  pop rdi
00007f30a29e3a89  pop rdx
00007f30a29e3a8a  pop rcx
00007f30a29e3a8b  pop rax
00007f30a29e3a8c  add rsp, 0x08
00007f30a29e3a90  jmp 0x00007F30A29DF81D
00007f30a29e3a95  sub rsp, 0x08
00007f30a29e3a99  push rax
00007f30a29e3a9a  push rcx
00007f30a29e3a9b  push rdx
00007f30a29e3a9c  push rdi
00007f30a29e3a9d  push rsi
00007f30a29e3a9e  push r8
00007f30a29e3aa0  push r9
00007f30a29e3aa2  push r10
00007f30a29e3aa4  push r11
00007f30a29e3aa6  sub rsp, 0xF0
00007f30a29e3aad  vmovaps [rsp], xmm0
00007f30a29e3ab2  vmovaps [rsp+0x10], xmm1
00007f30a29e3ab8  vmovaps [rsp+0x20], xmm2
00007f30a29e3abe  vmovaps [rsp+0x30], xmm3
00007f30a29e3ac4  vmovaps [rsp+0x40], xmm4
00007f30a29e3aca  vmovaps [rsp+0x50], xmm5
00007f30a29e3ad0  vmovaps [rsp+0x60], xmm6
00007f30a29e3ad6  vmovaps [rsp+0x70], xmm7
00007f30a29e3adc  vmovaps [rsp+0x80], xmm8
00007f30a29e3ae5  vmovaps [rsp+0x90], xmm9
00007f30a29e3aee  vmovaps [rsp+0xA0], xmm10
00007f30a29e3af7  vmovaps [rsp+0xB0], xmm11
00007f30a29e3b00  vmovaps [rsp+0xC0], xmm12
00007f30a29e3b09  vmovaps [rsp+0xD0], xmm13
00007f30a29e3b12  vmovaps [rsp+0xE0], xmm14
00007f30a29e3b1b  sub rsp, 0x30
00007f30a29e3b1f  movaps [rsp], xmm15
00007f30a29e3b24  movaps [rsp+0x10], xmm11
00007f30a29e3b2a  movaps [rsp+0x20], xmm6
00007f30a29e3b2f  lea rdi, [rsp]
00007f30a29e3b33  mov esi, 0x00
00007f30a29e3b38  mov rax, 0x5FE955026530
00007f30a29e3b42  call rax
00007f30a29e3b44  movaps xmm15, [rsp]
00007f30a29e3b49  add rsp, 0x30
00007f30a29e3b4d  vmovaps xmm0, [rsp]
00007f30a29e3b52  vmovaps xmm1, [rsp+0x10]
00007f30a29e3b58  vmovaps xmm2, [rsp+0x20]
00007f30a29e3b5e  vmovaps xmm3, [rsp+0x30]
00007f30a29e3b64  vmovaps xmm4, [rsp+0x40]
00007f30a29e3b6a  vmovaps xmm5, [rsp+0x50]
00007f30a29e3b70  vmovaps xmm6, [rsp+0x60]
00007f30a29e3b76  vmovaps xmm7, [rsp+0x70]
00007f30a29e3b7c  vmovaps xmm8, [rsp+0x80]
00007f30a29e3b85  vmovaps xmm9, [rsp+0x90]
00007f30a29e3b8e  vmovaps xmm10, [rsp+0xA0]
00007f30a29e3b97  vmovaps xmm11, [rsp+0xB0]
00007f30a29e3ba0  vmovaps xmm12, [rsp+0xC0]
00007f30a29e3ba9  vmovaps xmm13, [rsp+0xD0]
00007f30a29e3bb2  vmovaps xmm14, [rsp+0xE0]
00007f30a29e3bbb  add rsp, 0xF0
00007f30a29e3bc2  pop r11
00007f30a29e3bc4  pop r10
00007f30a29e3bc6  pop r9
00007f30a29e3bc8  pop r8
00007f30a29e3bca  pop rsi
00007f30a29e3bcb  pop rdi
00007f30a29e3bcc  pop rdx
00007f30a29e3bcd  pop rcx
00007f30a29e3bce  pop rax
00007f30a29e3bcf  add rsp, 0x08
00007f30a29e3bd3  jmp 0x00007F30A29DF838
00007f30a29e3bd8  sub rsp, 0x08
00007f30a29e3bdc  push rax
00007f30a29e3bdd  push rcx
00007f30a29e3bde  push rdx
00007f30a29e3bdf  push rdi
00007f30a29e3be0  push rsi
00007f30a29e3be1  push r8
00007f30a29e3be3  push r9
00007f30a29e3be5  push r10
00007f30a29e3be7  push r11
00007f30a29e3be9  sub rsp, 0xF0
00007f30a29e3bf0  vmovaps [rsp], xmm0
00007f30a29e3bf5  vmovaps [rsp+0x10], xmm1
00007f30a29e3bfb  vmovaps [rsp+0x20], xmm2
00007f30a29e3c01  vmovaps [rsp+0x30], xmm3
00007f30a29e3c07  vmovaps [rsp+0x40], xmm4
00007f30a29e3c0d  vmovaps [rsp+0x50], xmm5
00007f30a29e3c13  vmovaps [rsp+0x60], xmm6
00007f30a29e3c19  vmovaps [rsp+0x70], xmm8
00007f30a29e3c1f  vmovaps [rsp+0x80], xmm9
00007f30a29e3c28  vmovaps [rsp+0x90], xmm10
00007f30a29e3c31  vmovaps [rsp+0xA0], xmm11
00007f30a29e3c3a  vmovaps [rsp+0xB0], xmm12
00007f30a29e3c43  vmovaps [rsp+0xC0], xmm13
00007f30a29e3c4c  vmovaps [rsp+0xD0], xmm14
00007f30a29e3c55  vmovaps [rsp+0xE0], xmm15
00007f30a29e3c5e  sub rsp, 0x30
00007f30a29e3c62  movaps [rsp], xmm7
00007f30a29e3c66  movaps [rsp+0x10], xmm11
00007f30a29e3c6c  movaps [rsp+0x20], xmm9
00007f30a29e3c72  lea rdi, [rsp]
00007f30a29e3c76  mov esi, 0x00
00007f30a29e3c7b  mov rax, 0x5FE955026530
00007f30a29e3c85  call rax
00007f30a29e3c87  movaps xmm7, [rsp]
00007f30a29e3c8b  add rsp, 0x30
00007f30a29e3c8f  vmovaps xmm0, [rsp]
00007f30a29e3c94  vmovaps xmm1, [rsp+0x10]
00007f30a29e3c9a  vmovaps xmm2, [rsp+0x20]
00007f30a29e3ca0  vmovaps xmm3, [rsp+0x30]
00007f30a29e3ca6  vmovaps xmm4, [rsp+0x40]
00007f30a29e3cac  vmovaps xmm5, [rsp+0x50]
00007f30a29e3cb2  vmovaps xmm6, [rsp+0x60]
00007f30a29e3cb8  vmovaps xmm8, [rsp+0x70]
00007f30a29e3cbe  vmovaps xmm9, [rsp+0x80]
00007f30a29e3cc7  vmovaps xmm10, [rsp+0x90]
00007f30a29e3cd0  vmovaps xmm11, [rsp+0xA0]
00007f30a29e3cd9  vmovaps xmm12, [rsp+0xB0]
00007f30a29e3ce2  vmovaps xmm13, [rsp+0xC0]
00007f30a29e3ceb  vmovaps xmm14, [rsp+0xD0]
00007f30a29e3cf4  vmovaps xmm15, [rsp+0xE0]
00007f30a29e3cfd  add rsp, 0xF0
00007f30a29e3d04  pop r11
00007f30a29e3d06  pop r10
00007f30a29e3d08  pop r9
00007f30a29e3d0a  pop r8
00007f30a29e3d0c  pop rsi
00007f30a29e3d0d  pop rdi
00007f30a29e3d0e  pop rdx
00007f30a29e3d0f  pop rcx
00007f30a29e3d10  pop rax
00007f30a29e3d11  add rsp, 0x08
00007f30a29e3d15  jmp 0x00007F30A29DF865
00007f30a29e3d1a  sub rsp, 0x08
00007f30a29e3d1e  push rax
00007f30a29e3d1f  push rcx
00007f30a29e3d20  push rdx
00007f30a29e3d21  push rdi
00007f30a29e3d22  push rsi
00007f30a29e3d23  push r8
00007f30a29e3d25  push r9
00007f30a29e3d27  push r10
00007f30a29e3d29  push r11
00007f30a29e3d2b  sub rsp, 0xF0
00007f30a29e3d32  vmovaps [rsp], xmm0
00007f30a29e3d37  vmovaps [rsp+0x10], xmm1
00007f30a29e3d3d  vmovaps [rsp+0x20], xmm2
00007f30a29e3d43  vmovaps [rsp+0x30], xmm3
00007f30a29e3d49  vmovaps [rsp+0x40], xmm4
00007f30a29e3d4f  vmovaps [rsp+0x50], xmm5
00007f30a29e3d55  vmovaps [rsp+0x60], xmm6
00007f30a29e3d5b  vmovaps [rsp+0x70], xmm7
00007f30a29e3d61  vmovaps [rsp+0x80], xmm8
00007f30a29e3d6a  vmovaps [rsp+0x90], xmm9
00007f30a29e3d73  vmovaps [rsp+0xA0], xmm10
00007f30a29e3d7c  vmovaps [rsp+0xB0], xmm12
00007f30a29e3d85  vmovaps [rsp+0xC0], xmm13
00007f30a29e3d8e  vmovaps [rsp+0xD0], xmm14
00007f30a29e3d97  vmovaps [rsp+0xE0], xmm15
00007f30a29e3da0  sub rsp, 0x30
00007f30a29e3da4  movaps [rsp], xmm11
00007f30a29e3da9  movaps [rsp+0x10], xmm10
00007f30a29e3daf  movaps [rsp+0x20], xmm14
00007f30a29e3db5  lea rdi, [rsp]
00007f30a29e3db9  mov esi, 0x00
00007f30a29e3dbe  mov rax, 0x5FE955026530
00007f30a29e3dc8  call rax
00007f30a29e3dca  movaps xmm11, [rsp]
00007f30a29e3dcf  add rsp, 0x30
00007f30a29e3dd3  vmovaps xmm0, [rsp]
00007f30a29e3dd8  vmovaps xmm1, [rsp+0x10]
00007f30a29e3dde  vmovaps xmm2, [rsp+0x20]
00007f30a29e3de4  vmovaps xmm3, [rsp+0x30]
00007f30a29e3dea  vmovaps xmm4, [rsp+0x40]
00007f30a29e3df0  vmovaps xmm5, [rsp+0x50]
00007f30a29e3df6  vmovaps xmm6, [rsp+0x60]
00007f30a29e3dfc  vmovaps xmm7, [rsp+0x70]
00007f30a29e3e02  vmovaps xmm8, [rsp+0x80]
00007f30a29e3e0b  vmovaps xmm9, [rsp+0x90]
00007f30a29e3e14  vmovaps xmm10, [rsp+0xA0]
00007f30a29e3e1d  vmovaps xmm12, [rsp+0xB0]
00007f30a29e3e26  vmovaps xmm13, [rsp+0xC0]
00007f30a29e3e2f  vmovaps xmm14, [rsp+0xD0]
00007f30a29e3e38  vmovaps xmm15, [rsp+0xE0]
00007f30a29e3e41  add rsp, 0xF0
00007f30a29e3e48  pop r11
00007f30a29e3e4a  pop r10
00007f30a29e3e4c  pop r9
00007f30a29e3e4e  pop r8
00007f30a29e3e50  pop rsi
00007f30a29e3e51  pop rdi
00007f30a29e3e52  pop rdx
00007f30a29e3e53  pop rcx
00007f30a29e3e54  pop rax
00007f30a29e3e55  add rsp, 0x08
00007f30a29e3e59  jmp 0x00007F30A29DF880
00007f30a29e3e5e  call 0x00007F30A28C33A0
00007f30a29e3e63  jmp 0x00007F30A29DF88A
00007f30a29e3e68  sub rsp, 0x08
00007f30a29e3e6c  push rax
00007f30a29e3e6d  push rcx
00007f30a29e3e6e  push rdx
00007f30a29e3e6f  push rdi
00007f30a29e3e70  push rsi
00007f30a29e3e71  push r8
00007f30a29e3e73  push r9
00007f30a29e3e75  push r10
00007f30a29e3e77  push r11
00007f30a29e3e79  sub rsp, 0xF0
00007f30a29e3e80  vmovaps [rsp], xmm0
00007f30a29e3e85  vmovaps [rsp+0x10], xmm1
00007f30a29e3e8b  vmovaps [rsp+0x20], xmm2
00007f30a29e3e91  vmovaps [rsp+0x30], xmm3
00007f30a29e3e97  vmovaps [rsp+0x40], xmm4
00007f30a29e3e9d  vmovaps [rsp+0x50], xmm5
00007f30a29e3ea3  vmovaps [rsp+0x60], xmm6
00007f30a29e3ea9  vmovaps [rsp+0x70], xmm7
00007f30a29e3eaf  vmovaps [rsp+0x80], xmm8
00007f30a29e3eb8  vmovaps [rsp+0x90], xmm9
00007f30a29e3ec1  vmovaps [rsp+0xA0], xmm11
00007f30a29e3eca  vmovaps [rsp+0xB0], xmm12
00007f30a29e3ed3  vmovaps [rsp+0xC0], xmm13
00007f30a29e3edc  vmovaps [rsp+0xD0], xmm14
00007f30a29e3ee5  vmovaps [rsp+0xE0], xmm15
00007f30a29e3eee  sub rsp, 0x30
00007f30a29e3ef2  movaps [rsp], xmm10
00007f30a29e3ef7  movaps [rsp+0x10], xmm1
00007f30a29e3efc  movaps [rsp+0x20], xmm12
00007f30a29e3f02  lea rdi, [rsp]
00007f30a29e3f06  mov esi, 0x00
00007f30a29e3f0b  mov rax, 0x5FE955026530
00007f30a29e3f15  call rax
00007f30a29e3f17  movaps xmm10, [rsp]
00007f30a29e3f1c  add rsp, 0x30
00007f30a29e3f20  vmovaps xmm0, [rsp]
00007f30a29e3f25  vmovaps xmm1, [rsp+0x10]
00007f30a29e3f2b  vmovaps xmm2, [rsp+0x20]
00007f30a29e3f31  vmovaps xmm3, [rsp+0x30]
00007f30a29e3f37  vmovaps xmm4, [rsp+0x40]
00007f30a29e3f3d  vmovaps xmm5, [rsp+0x50]
00007f30a29e3f43  vmovaps xmm6, [rsp+0x60]
00007f30a29e3f49  vmovaps xmm7, [rsp+0x70]
00007f30a29e3f4f  vmovaps xmm8, [rsp+0x80]
00007f30a29e3f58  vmovaps xmm9, [rsp+0x90]
00007f30a29e3f61  vmovaps xmm11, [rsp+0xA0]
00007f30a29e3f6a  vmovaps xmm12, [rsp+0xB0]
00007f30a29e3f73  vmovaps xmm13, [rsp+0xC0]
00007f30a29e3f7c  vmovaps xmm14, [rsp+0xD0]
00007f30a29e3f85  vmovaps xmm15, [rsp+0xE0]
00007f30a29e3f8e  add rsp, 0xF0
00007f30a29e3f95  pop r11
00007f30a29e3f97  pop r10
00007f30a29e3f99  pop r9
00007f30a29e3f9b  pop r8
00007f30a29e3f9d  pop rsi
00007f30a29e3f9e  pop rdi
00007f30a29e3f9f  pop rdx
00007f30a29e3fa0  pop rcx
00007f30a29e3fa1  pop rax
00007f30a29e3fa2  add rsp, 0x08
00007f30a29e3fa6  jmp 0x00007F30A29DF8AD
00007f30a29e3fab  sub rsp, 0x08
00007f30a29e3faf  push rax
00007f30a29e3fb0  push rcx
00007f30a29e3fb1  push rdx
00007f30a29e3fb2  push rdi
00007f30a29e3fb3  push rsi
00007f30a29e3fb4  push r8
00007f30a29e3fb6  push r9
00007f30a29e3fb8  push r10
00007f30a29e3fba  push r11
00007f30a29e3fbc  sub rsp, 0xF0
00007f30a29e3fc3  vmovaps [rsp], xmm0
00007f30a29e3fc8  vmovaps [rsp+0x10], xmm1
00007f30a29e3fce  vmovaps [rsp+0x20], xmm2
00007f30a29e3fd4  vmovaps [rsp+0x30], xmm3
00007f30a29e3fda  vmovaps [rsp+0x40], xmm4
00007f30a29e3fe0  vmovaps [rsp+0x50], xmm5
00007f30a29e3fe6  vmovaps [rsp+0x60], xmm6
00007f30a29e3fec  vmovaps [rsp+0x70], xmm7
00007f30a29e3ff2  vmovaps [rsp+0x80], xmm8
00007f30a29e3ffb  vmovaps [rsp+0x90], xmm9
00007f30a29e4004  vmovaps [rsp+0xA0], xmm10
00007f30a29e400d  vmovaps [rsp+0xB0], xmm11
00007f30a29e4016  vmovaps [rsp+0xC0], xmm13
00007f30a29e401f  vmovaps [rsp+0xD0], xmm14
00007f30a29e4028  vmovaps [rsp+0xE0], xmm15
00007f30a29e4031  sub rsp, 0x30
00007f30a29e4035  movaps [rsp], xmm12
00007f30a29e403a  movaps [rsp+0x10], xmm14
00007f30a29e4040  movaps [rsp+0x20], xmm1
00007f30a29e4045  lea rdi, [rsp]
00007f30a29e4049  mov esi, 0x00
00007f30a29e404e  mov rax, 0x5FE955026530
00007f30a29e4058  call rax
00007f30a29e405a  movaps xmm12, [rsp]
00007f30a29e405f  add rsp, 0x30
00007f30a29e4063  vmovaps xmm0, [rsp]
00007f30a29e4068  vmovaps xmm1, [rsp+0x10]
00007f30a29e406e  vmovaps xmm2, [rsp+0x20]
00007f30a29e4074  vmovaps xmm3, [rsp+0x30]
00007f30a29e407a  vmovaps xmm4, [rsp+0x40]
00007f30a29e4080  vmovaps xmm5, [rsp+0x50]
00007f30a29e4086  vmovaps xmm6, [rsp+0x60]
00007f30a29e408c  vmovaps xmm7, [rsp+0x70]
00007f30a29e4092  vmovaps xmm8, [rsp+0x80]
00007f30a29e409b  vmovaps xmm9, [rsp+0x90]
00007f30a29e40a4  vmovaps xmm10, [rsp+0xA0]
00007f30a29e40ad  vmovaps xmm11, [rsp+0xB0]
00007f30a29e40b6  vmovaps xmm13, [rsp+0xC0]
00007f30a29e40bf  vmovaps xmm14, [rsp+0xD0]
00007f30a29e40c8  vmovaps xmm15, [rsp+0xE0]
00007f30a29e40d1  add rsp, 0xF0
00007f30a29e40d8  pop r11
00007f30a29e40da  pop r10
00007f30a29e40dc  pop r9
00007f30a29e40de  pop r8
00007f30a29e40e0  pop rsi
00007f30a29e40e1  pop rdi
00007f30a29e40e2  pop rdx
00007f30a29e40e3  pop rcx
00007f30a29e40e4  pop rax
00007f30a29e40e5  add rsp, 0x08
00007f30a29e40e9  jmp 0x00007F30A29DF8DC
00007f30a29e40ee  sub rsp, 0x08
00007f30a29e40f2  push rax
00007f30a29e40f3  push rcx
00007f30a29e40f4  push rdx
00007f30a29e40f5  push rdi
00007f30a29e40f6  push rsi
00007f30a29e40f7  push r8
00007f30a29e40f9  push r9
00007f30a29e40fb  push r10
00007f30a29e40fd  push r11
00007f30a29e40ff  sub rsp, 0xF0
00007f30a29e4106  vmovaps [rsp], xmm0
00007f30a29e410b  vmovaps [rsp+0x10], xmm1
00007f30a29e4111  vmovaps [rsp+0x20], xmm2
00007f30a29e4117  vmovaps [rsp+0x30], xmm3
00007f30a29e411d  vmovaps [rsp+0x40], xmm4
00007f30a29e4123  vmovaps [rsp+0x50], xmm5
00007f30a29e4129  vmovaps [rsp+0x60], xmm6
00007f30a29e412f  vmovaps [rsp+0x70], xmm7
00007f30a29e4135  vmovaps [rsp+0x80], xmm8
00007f30a29e413e  vmovaps [rsp+0x90], xmm9
00007f30a29e4147  vmovaps [rsp+0xA0], xmm10
00007f30a29e4150  vmovaps [rsp+0xB0], xmm11
00007f30a29e4159  vmovaps [rsp+0xC0], xmm12
00007f30a29e4162  vmovaps [rsp+0xD0], xmm13
00007f30a29e416b  vmovaps [rsp+0xE0], xmm15
00007f30a29e4174  sub rsp, 0x30
00007f30a29e4178  movaps [rsp], xmm14
00007f30a29e417d  movaps [rsp+0x10], xmm9
00007f30a29e4183  movaps [rsp+0x20], xmm1
00007f30a29e4188  lea rdi, [rsp]
00007f30a29e418c  mov esi, 0x00
00007f30a29e4191  mov rax, 0x5FE955026530
00007f30a29e419b  call rax
00007f30a29e419d  movaps xmm14, [rsp]
00007f30a29e41a2  add rsp, 0x30
00007f30a29e41a6  vmovaps xmm0, [rsp]
00007f30a29e41ab  vmovaps xmm1, [rsp+0x10]
00007f30a29e41b1  vmovaps xmm2, [rsp+0x20]
00007f30a29e41b7  vmovaps xmm3, [rsp+0x30]
00007f30a29e41bd  vmovaps xmm4, [rsp+0x40]
00007f30a29e41c3  vmovaps xmm5, [rsp+0x50]
00007f30a29e41c9  vmovaps xmm6, [rsp+0x60]
00007f30a29e41cf  vmovaps xmm7, [rsp+0x70]
00007f30a29e41d5  vmovaps xmm8, [rsp+0x80]
00007f30a29e41de  vmovaps xmm9, [rsp+0x90]
00007f30a29e41e7  vmovaps xmm10, [rsp+0xA0]
00007f30a29e41f0  vmovaps xmm11, [rsp+0xB0]
00007f30a29e41f9  vmovaps xmm12, [rsp+0xC0]
00007f30a29e4202  vmovaps xmm13, [rsp+0xD0]
00007f30a29e420b  vmovaps xmm15, [rsp+0xE0]
00007f30a29e4214  add rsp, 0xF0
00007f30a29e421b  pop r11
00007f30a29e421d  pop r10
00007f30a29e421f  pop r9
00007f30a29e4221  pop r8
00007f30a29e4223  pop rsi
00007f30a29e4224  pop rdi
00007f30a29e4225  pop rdx
00007f30a29e4226  pop rcx
00007f30a29e4227  pop rax
00007f30a29e4228  add rsp, 0x08
00007f30a29e422c  jmp 0x00007F30A29DF90B
00007f30a29e4231  sub rsp, 0x08
00007f30a29e4235  push rax
00007f30a29e4236  push rcx
00007f30a29e4237  push rdx
00007f30a29e4238  push rdi
00007f30a29e4239  push rsi
00007f30a29e423a  push r8
00007f30a29e423c  push r9
00007f30a29e423e  push r10
00007f30a29e4240  push r11
00007f30a29e4242  sub rsp, 0xF0
00007f30a29e4249  vmovaps [rsp], xmm0
00007f30a29e424e  vmovaps [rsp+0x10], xmm2
00007f30a29e4254  vmovaps [rsp+0x20], xmm3
00007f30a29e425a  vmovaps [rsp+0x30], xmm4
00007f30a29e4260  vmovaps [rsp+0x40], xmm5
00007f30a29e4266  vmovaps [rsp+0x50], xmm6
00007f30a29e426c  vmovaps [rsp+0x60], xmm7
00007f30a29e4272  vmovaps [rsp+0x70], xmm8
00007f30a29e4278  vmovaps [rsp+0x80], xmm9
00007f30a29e4281  vmovaps [rsp+0x90], xmm10
00007f30a29e428a  vmovaps [rsp+0xA0], xmm11
00007f30a29e4293  vmovaps [rsp+0xB0], xmm12
00007f30a29e429c  vmovaps [rsp+0xC0], xmm13
00007f30a29e42a5  vmovaps [rsp+0xD0], xmm14
00007f30a29e42ae  vmovaps [rsp+0xE0], xmm15
00007f30a29e42b7  sub rsp, 0x30
00007f30a29e42bb  movaps [rsp], xmm1
00007f30a29e42bf  movaps [rsp+0x10], xmm13
00007f30a29e42c5  movaps [rsp+0x20], xmm8
00007f30a29e42cb  lea rdi, [rsp]
00007f30a29e42cf  mov esi, 0x00
00007f30a29e42d4  mov rax, 0x5FE955026530
00007f30a29e42de  call rax
00007f30a29e42e0  movaps xmm1, [rsp]
00007f30a29e42e4  add rsp, 0x30
00007f30a29e42e8  vmovaps xmm0, [rsp]
00007f30a29e42ed  vmovaps xmm2, [rsp+0x10]
00007f30a29e42f3  vmovaps xmm3, [rsp+0x20]
00007f30a29e42f9  vmovaps xmm4, [rsp+0x30]
00007f30a29e42ff  vmovaps xmm5, [rsp+0x40]
00007f30a29e4305  vmovaps xmm6, [rsp+0x50]
00007f30a29e430b  vmovaps xmm7, [rsp+0x60]
00007f30a29e4311  vmovaps xmm8, [rsp+0x70]
00007f30a29e4317  vmovaps xmm9, [rsp+0x80]
00007f30a29e4320  vmovaps xmm10, [rsp+0x90]
00007f30a29e4329  vmovaps xmm11, [rsp+0xA0]
00007f30a29e4332  vmovaps xmm12, [rsp+0xB0]
00007f30a29e433b  vmovaps xmm13, [rsp+0xC0]
00007f30a29e4344  vmovaps xmm14, [rsp+0xD0]
00007f30a29e434d  vmovaps xmm15, [rsp+0xE0]
00007f30a29e4356  add rsp, 0xF0
00007f30a29e435d  pop r11
00007f30a29e435f  pop r10
00007f30a29e4361  pop r9
00007f30a29e4363  pop r8
00007f30a29e4365  pop rsi
00007f30a29e4366  pop rdi
00007f30a29e4367  pop rdx
00007f30a29e4368  pop rcx
00007f30a29e4369  pop rax
00007f30a29e436a  add rsp, 0x08
00007f30a29e436e  jmp 0x00007F30A29DF92D
00007f30a29e4373  call 0x00007F30A280C260
00007f30a29e4378  jmp 0x00007F30A29DF93B
00007f30a29e437d  call 0x00007F30A28BD750
00007f30a29e4382  jmp 0x00007F30A29DF945
00007f30a29e4387  sub rsp, 0x08
00007f30a29e438b  push rax
00007f30a29e438c  push rcx
00007f30a29e438d  push rdx
00007f30a29e438e  push rdi
00007f30a29e438f  push rsi
00007f30a29e4390  push r8
00007f30a29e4392  push r9
00007f30a29e4394  push r10
00007f30a29e4396  push r11
00007f30a29e4398  sub rsp, 0xF0
00007f30a29e439f  vmovaps [rsp], xmm0
00007f30a29e43a4  vmovaps [rsp+0x10], xmm1
00007f30a29e43aa  vmovaps [rsp+0x20], xmm2
00007f30a29e43b0  vmovaps [rsp+0x30], xmm3
00007f30a29e43b6  vmovaps [rsp+0x40], xmm4
00007f30a29e43bc  vmovaps [rsp+0x50], xmm5
00007f30a29e43c2  vmovaps [rsp+0x60], xmm6
00007f30a29e43c8  vmovaps [rsp+0x70], xmm7
00007f30a29e43ce  vmovaps [rsp+0x80], xmm9
00007f30a29e43d7  vmovaps [rsp+0x90], xmm10
00007f30a29e43e0  vmovaps [rsp+0xA0], xmm11
00007f30a29e43e9  vmovaps [rsp+0xB0], xmm12
00007f30a29e43f2  vmovaps [rsp+0xC0], xmm13
00007f30a29e43fb  vmovaps [rsp+0xD0], xmm14
00007f30a29e4404  vmovaps [rsp+0xE0], xmm15
00007f30a29e440d  sub rsp, 0x30
00007f30a29e4411  movaps [rsp], xmm8
00007f30a29e4416  movaps [rsp+0x10], xmm15
00007f30a29e441c  movaps [rsp+0x20], xmm7
00007f30a29e4421  lea rdi, [rsp]
00007f30a29e4425  mov esi, 0x00
00007f30a29e442a  mov rax, 0x5FE955026530
00007f30a29e4434  call rax
00007f30a29e4436  movaps xmm8, [rsp]
00007f30a29e443b  add rsp, 0x30
00007f30a29e443f  vmovaps xmm0, [rsp]
00007f30a29e4444  vmovaps xmm1, [rsp+0x10]
00007f30a29e444a  vmovaps xmm2, [rsp+0x20]
00007f30a29e4450  vmovaps xmm3, [rsp+0x30]
00007f30a29e4456  vmovaps xmm4, [rsp+0x40]
00007f30a29e445c  vmovaps xmm5, [rsp+0x50]
00007f30a29e4462  vmovaps xmm6, [rsp+0x60]
00007f30a29e4468  vmovaps xmm7, [rsp+0x70]
00007f30a29e446e  vmovaps xmm9, [rsp+0x80]
00007f30a29e4477  vmovaps xmm10, [rsp+0x90]
00007f30a29e4480  vmovaps xmm11, [rsp+0xA0]
00007f30a29e4489  vmovaps xmm12, [rsp+0xB0]
00007f30a29e4492  vmovaps xmm13, [rsp+0xC0]
00007f30a29e449b  vmovaps xmm14, [rsp+0xD0]
00007f30a29e44a4  vmovaps xmm15, [rsp+0xE0]
00007f30a29e44ad  add rsp, 0xF0
00007f30a29e44b4  pop r11
00007f30a29e44b6  pop r10
00007f30a29e44b8  pop r9
00007f30a29e44ba  pop r8
00007f30a29e44bc  pop rsi
00007f30a29e44bd  pop rdi
00007f30a29e44be  pop rdx
00007f30a29e44bf  pop rcx
00007f30a29e44c0  pop rax
00007f30a29e44c1  add rsp, 0x08
00007f30a29e44c5  jmp 0x00007F30A29DF967
00007f30a29e44ca  sub rsp, 0x08
00007f30a29e44ce  push rax
00007f30a29e44cf  push rcx
00007f30a29e44d0  push rdx
00007f30a29e44d1  push rdi
00007f30a29e44d2  push rsi
00007f30a29e44d3  push r8
00007f30a29e44d5  push r9
00007f30a29e44d7  push r10
00007f30a29e44d9  push r11
00007f30a29e44db  sub rsp, 0xF0
00007f30a29e44e2  vmovaps [rsp], xmm0
00007f30a29e44e7  vmovaps [rsp+0x10], xmm1
00007f30a29e44ed  vmovaps [rsp+0x20], xmm2
00007f30a29e44f3  vmovaps [rsp+0x30], xmm3
00007f30a29e44f9  vmovaps [rsp+0x40], xmm4
00007f30a29e44ff  vmovaps [rsp+0x50], xmm5
00007f30a29e4505  vmovaps [rsp+0x60], xmm6
00007f30a29e450b  vmovaps [rsp+0x70], xmm8
00007f30a29e4511  vmovaps [rsp+0x80], xmm9
00007f30a29e451a  vmovaps [rsp+0x90], xmm10
00007f30a29e4523  vmovaps [rsp+0xA0], xmm11
00007f30a29e452c  vmovaps [rsp+0xB0], xmm12
00007f30a29e4535  vmovaps [rsp+0xC0], xmm13
00007f30a29e453e  vmovaps [rsp+0xD0], xmm14
00007f30a29e4547  vmovaps [rsp+0xE0], xmm15
00007f30a29e4550  sub rsp, 0x30
00007f30a29e4554  movaps [rsp], xmm7
00007f30a29e4558  movaps [rsp+0x10], xmm9
00007f30a29e455e  movaps [rsp+0x20], xmm15
00007f30a29e4564  lea rdi, [rsp]
00007f30a29e4568  mov esi, 0x00
00007f30a29e456d  mov rax, 0x5FE955026530
00007f30a29e4577  call rax
00007f30a29e4579  movaps xmm7, [rsp]
00007f30a29e457d  add rsp, 0x30
00007f30a29e4581  vmovaps xmm0, [rsp]
00007f30a29e4586  vmovaps xmm1, [rsp+0x10]
00007f30a29e458c  vmovaps xmm2, [rsp+0x20]
00007f30a29e4592  vmovaps xmm3, [rsp+0x30]
00007f30a29e4598  vmovaps xmm4, [rsp+0x40]
00007f30a29e459e  vmovaps xmm5, [rsp+0x50]
00007f30a29e45a4  vmovaps xmm6, [rsp+0x60]
00007f30a29e45aa  vmovaps xmm8, [rsp+0x70]
00007f30a29e45b0  vmovaps xmm9, [rsp+0x80]
00007f30a29e45b9  vmovaps xmm10, [rsp+0x90]
00007f30a29e45c2  vmovaps xmm11, [rsp+0xA0]
00007f30a29e45cb  vmovaps xmm12, [rsp+0xB0]
00007f30a29e45d4  vmovaps xmm13, [rsp+0xC0]
00007f30a29e45dd  vmovaps xmm14, [rsp+0xD0]
00007f30a29e45e6  vmovaps xmm15, [rsp+0xE0]
00007f30a29e45ef  add rsp, 0xF0
00007f30a29e45f6  pop r11
00007f30a29e45f8  pop r10
00007f30a29e45fa  pop r9
00007f30a29e45fc  pop r8
00007f30a29e45fe  pop rsi
00007f30a29e45ff  pop rdi
00007f30a29e4600  pop rdx
00007f30a29e4601  pop rcx
00007f30a29e4602  pop rax
00007f30a29e4603  add rsp, 0x08
00007f30a29e4607  jmp 0x00007F30A29DF994
00007f30a29e460c  sub rsp, 0x08
00007f30a29e4610  push rax
00007f30a29e4611  push rcx
00007f30a29e4612  push rdx
00007f30a29e4613  push rdi
00007f30a29e4614  push rsi
00007f30a29e4615  push r8
00007f30a29e4617  push r9
00007f30a29e4619  push r10
00007f30a29e461b  push r11
00007f30a29e461d  sub rsp, 0xF0
00007f30a29e4624  vmovaps [rsp], xmm0
00007f30a29e4629  vmovaps [rsp+0x10], xmm1
00007f30a29e462f  vmovaps [rsp+0x20], xmm2
00007f30a29e4635  vmovaps [rsp+0x30], xmm3
00007f30a29e463b  vmovaps [rsp+0x40], xmm4
00007f30a29e4641  vmovaps [rsp+0x50], xmm5
00007f30a29e4647  vmovaps [rsp+0x60], xmm6
00007f30a29e464d  vmovaps [rsp+0x70], xmm7
00007f30a29e4653  vmovaps [rsp+0x80], xmm8
00007f30a29e465c  vmovaps [rsp+0x90], xmm10
00007f30a29e4665  vmovaps [rsp+0xA0], xmm11
00007f30a29e466e  vmovaps [rsp+0xB0], xmm12
00007f30a29e4677  vmovaps [rsp+0xC0], xmm13
00007f30a29e4680  vmovaps [rsp+0xD0], xmm14
00007f30a29e4689  vmovaps [rsp+0xE0], xmm15
00007f30a29e4692  sub rsp, 0x30
00007f30a29e4696  movaps [rsp], xmm9
00007f30a29e469b  movaps [rsp+0x10], xmm13
00007f30a29e46a1  movaps [rsp+0x20], xmm15
00007f30a29e46a7  lea rdi, [rsp]
00007f30a29e46ab  mov esi, 0x00
00007f30a29e46b0  mov rax, 0x5FE955026530
00007f30a29e46ba  call rax
00007f30a29e46bc  movaps xmm9, [rsp]
00007f30a29e46c1  add rsp, 0x30
00007f30a29e46c5  vmovaps xmm0, [rsp]
00007f30a29e46ca  vmovaps xmm1, [rsp+0x10]
00007f30a29e46d0  vmovaps xmm2, [rsp+0x20]
00007f30a29e46d6  vmovaps xmm3, [rsp+0x30]
00007f30a29e46dc  vmovaps xmm4, [rsp+0x40]
00007f30a29e46e2  vmovaps xmm5, [rsp+0x50]
00007f30a29e46e8  vmovaps xmm6, [rsp+0x60]
00007f30a29e46ee  vmovaps xmm7, [rsp+0x70]
00007f30a29e46f4  vmovaps xmm8, [rsp+0x80]
00007f30a29e46fd  vmovaps xmm10, [rsp+0x90]
00007f30a29e4706  vmovaps xmm11, [rsp+0xA0]
00007f30a29e470f  vmovaps xmm12, [rsp+0xB0]
00007f30a29e4718  vmovaps xmm13, [rsp+0xC0]
00007f30a29e4721  vmovaps xmm14, [rsp+0xD0]
00007f30a29e472a  vmovaps xmm15, [rsp+0xE0]
00007f30a29e4733  add rsp, 0xF0
00007f30a29e473a  pop r11
00007f30a29e473c  pop r10
00007f30a29e473e  pop r9
00007f30a29e4740  pop r8
00007f30a29e4742  pop rsi
00007f30a29e4743  pop rdi
00007f30a29e4744  pop rdx
00007f30a29e4745  pop rcx
00007f30a29e4746  pop rax
00007f30a29e4747  add rsp, 0x08
00007f30a29e474b  jmp 0x00007F30A29DF9C2
00007f30a29e4750  sub rsp, 0x08
00007f30a29e4754  push rax
00007f30a29e4755  push rcx
00007f30a29e4756  push rdx
00007f30a29e4757  push rdi
00007f30a29e4758  push rsi
00007f30a29e4759  push r8
00007f30a29e475b  push r9
00007f30a29e475d  push r10
00007f30a29e475f  push r11
00007f30a29e4761  sub rsp, 0xF0
00007f30a29e4768  vmovaps [rsp], xmm0
00007f30a29e476d  vmovaps [rsp+0x10], xmm1
00007f30a29e4773  vmovaps [rsp+0x20], xmm2
00007f30a29e4779  vmovaps [rsp+0x30], xmm3
00007f30a29e477f  vmovaps [rsp+0x40], xmm4
00007f30a29e4785  vmovaps [rsp+0x50], xmm5
00007f30a29e478b  vmovaps [rsp+0x60], xmm6
00007f30a29e4791  vmovaps [rsp+0x70], xmm7
00007f30a29e4797  vmovaps [rsp+0x80], xmm8
00007f30a29e47a0  vmovaps [rsp+0x90], xmm9
00007f30a29e47a9  vmovaps [rsp+0xA0], xmm10
00007f30a29e47b2  vmovaps [rsp+0xB0], xmm11
00007f30a29e47bb  vmovaps [rsp+0xC0], xmm12
00007f30a29e47c4  vmovaps [rsp+0xD0], xmm13
00007f30a29e47cd  vmovaps [rsp+0xE0], xmm14
00007f30a29e47d6  sub rsp, 0x30
00007f30a29e47da  movaps [rsp], xmm15
00007f30a29e47df  movaps [rsp+0x10], xmm11
00007f30a29e47e5  movaps [rsp+0x20], xmm12
00007f30a29e47eb  lea rdi, [rsp]
00007f30a29e47ef  mov esi, 0x00
00007f30a29e47f4  mov rax, 0x5FE955026530
00007f30a29e47fe  call rax
00007f30a29e4800  movaps xmm15, [rsp]
00007f30a29e4805  add rsp, 0x30
00007f30a29e4809  vmovaps xmm0, [rsp]
00007f30a29e480e  vmovaps xmm1, [rsp+0x10]
00007f30a29e4814  vmovaps xmm2, [rsp+0x20]
00007f30a29e481a  vmovaps xmm3, [rsp+0x30]
00007f30a29e4820  vmovaps xmm4, [rsp+0x40]
00007f30a29e4826  vmovaps xmm5, [rsp+0x50]
00007f30a29e482c  vmovaps xmm6, [rsp+0x60]
00007f30a29e4832  vmovaps xmm7, [rsp+0x70]
00007f30a29e4838  vmovaps xmm8, [rsp+0x80]
00007f30a29e4841  vmovaps xmm9, [rsp+0x90]
00007f30a29e484a  vmovaps xmm10, [rsp+0xA0]
00007f30a29e4853  vmovaps xmm11, [rsp+0xB0]
00007f30a29e485c  vmovaps xmm12, [rsp+0xC0]
00007f30a29e4865  vmovaps xmm13, [rsp+0xD0]
00007f30a29e486e  vmovaps xmm14, [rsp+0xE0]
00007f30a29e4877  add rsp, 0xF0
00007f30a29e487e  pop r11
00007f30a29e4880  pop r10
00007f30a29e4882  pop r9
00007f30a29e4884  pop r8
00007f30a29e4886  pop rsi
00007f30a29e4887  pop rdi
00007f30a29e4888  pop rdx
00007f30a29e4889  pop rcx
00007f30a29e488a  pop rax
00007f30a29e488b  add rsp, 0x08
00007f30a29e488f  jmp 0x00007F30A29DF9DD
00007f30a29e4894  sub rsp, 0x08
00007f30a29e4898  push rax
00007f30a29e4899  push rcx
00007f30a29e489a  push rdx
00007f30a29e489b  push rdi
00007f30a29e489c  push rsi
00007f30a29e489d  push r8
00007f30a29e489f  push r9
00007f30a29e48a1  push r10
00007f30a29e48a3  push r11
00007f30a29e48a5  sub rsp, 0xF0
00007f30a29e48ac  vmovaps [rsp], xmm0
00007f30a29e48b1  vmovaps [rsp+0x10], xmm1
00007f30a29e48b7  vmovaps [rsp+0x20], xmm2
00007f30a29e48bd  vmovaps [rsp+0x30], xmm3
00007f30a29e48c3  vmovaps [rsp+0x40], xmm4
00007f30a29e48c9  vmovaps [rsp+0x50], xmm5
00007f30a29e48cf  vmovaps [rsp+0x60], xmm6
00007f30a29e48d5  vmovaps [rsp+0x70], xmm7
00007f30a29e48db  vmovaps [rsp+0x80], xmm8
00007f30a29e48e4  vmovaps [rsp+0x90], xmm9
00007f30a29e48ed  vmovaps [rsp+0xA0], xmm10
00007f30a29e48f6  vmovaps [rsp+0xB0], xmm11
00007f30a29e48ff  vmovaps [rsp+0xC0], xmm12
00007f30a29e4908  vmovaps [rsp+0xD0], xmm14
00007f30a29e4911  vmovaps [rsp+0xE0], xmm15
00007f30a29e491a  sub rsp, 0x30
00007f30a29e491e  movaps [rsp], xmm13
00007f30a29e4923  movaps [rsp+0x10], xmm10
00007f30a29e4929  movaps [rsp+0x20], xmm14
00007f30a29e492f  lea rdi, [rsp]
00007f30a29e4933  mov esi, 0x00
00007f30a29e4938  mov rax, 0x5FE955026530
00007f30a29e4942  call rax
00007f30a29e4944  movaps xmm13, [rsp]
00007f30a29e4949  add rsp, 0x30
00007f30a29e494d  vmovaps xmm0, [rsp]
00007f30a29e4952  vmovaps xmm1, [rsp+0x10]
00007f30a29e4958  vmovaps xmm2, [rsp+0x20]
00007f30a29e495e  vmovaps xmm3, [rsp+0x30]
00007f30a29e4964  vmovaps xmm4, [rsp+0x40]
00007f30a29e496a  vmovaps xmm5, [rsp+0x50]
00007f30a29e4970  vmovaps xmm6, [rsp+0x60]
00007f30a29e4976  vmovaps xmm7, [rsp+0x70]
00007f30a29e497c  vmovaps xmm8, [rsp+0x80]
00007f30a29e4985  vmovaps xmm9, [rsp+0x90]
00007f30a29e498e  vmovaps xmm10, [rsp+0xA0]
00007f30a29e4997  vmovaps xmm11, [rsp+0xB0]
00007f30a29e49a0  vmovaps xmm12, [rsp+0xC0]
00007f30a29e49a9  vmovaps xmm14, [rsp+0xD0]
00007f30a29e49b2  vmovaps xmm15, [rsp+0xE0]
00007f30a29e49bb  add rsp, 0xF0
00007f30a29e49c2  pop r11
00007f30a29e49c4  pop r10
00007f30a29e49c6  pop r9
00007f30a29e49c8  pop r8
00007f30a29e49ca  pop rsi
00007f30a29e49cb  pop rdi
00007f30a29e49cc  pop rdx
00007f30a29e49cd  pop rcx
00007f30a29e49ce  pop rax
00007f30a29e49cf  add rsp, 0x08
00007f30a29e49d3  jmp 0x00007F30A29DFA00
00007f30a29e49d8  sub rsp, 0x08
00007f30a29e49dc  push rax
00007f30a29e49dd  push rcx
00007f30a29e49de  push rdx
00007f30a29e49df  push rdi
00007f30a29e49e0  push rsi
00007f30a29e49e1  push r8
00007f30a29e49e3  push r9
00007f30a29e49e5  push r10
00007f30a29e49e7  push r11
00007f30a29e49e9  sub rsp, 0xF0
00007f30a29e49f0  vmovaps [rsp], xmm0
00007f30a29e49f5  vmovaps [rsp+0x10], xmm1
00007f30a29e49fb  vmovaps [rsp+0x20], xmm2
00007f30a29e4a01  vmovaps [rsp+0x30], xmm3
00007f30a29e4a07  vmovaps [rsp+0x40], xmm4
00007f30a29e4a0d  vmovaps [rsp+0x50], xmm5
00007f30a29e4a13  vmovaps [rsp+0x60], xmm6
00007f30a29e4a19  vmovaps [rsp+0x70], xmm7
00007f30a29e4a1f  vmovaps [rsp+0x80], xmm8
00007f30a29e4a28  vmovaps [rsp+0x90], xmm9
00007f30a29e4a31  vmovaps [rsp+0xA0], xmm10
00007f30a29e4a3a  vmovaps [rsp+0xB0], xmm11
00007f30a29e4a43  vmovaps [rsp+0xC0], xmm12
00007f30a29e4a4c  vmovaps [rsp+0xD0], xmm13
00007f30a29e4a55  vmovaps [rsp+0xE0], xmm15
00007f30a29e4a5e  sub rsp, 0x30
00007f30a29e4a62  movaps [rsp], xmm14
00007f30a29e4a67  movaps [rsp+0x10], xmm1
00007f30a29e4a6c  movaps [rsp+0x20], xmm7
00007f30a29e4a71  lea rdi, [rsp]
00007f30a29e4a75  mov esi, 0x00
00007f30a29e4a7a  mov rax, 0x5FE955026530
00007f30a29e4a84  call rax
00007f30a29e4a86  movaps xmm14, [rsp]
00007f30a29e4a8b  add rsp, 0x30
00007f30a29e4a8f  vmovaps xmm0, [rsp]
00007f30a29e4a94  vmovaps xmm1, [rsp+0x10]
00007f30a29e4a9a  vmovaps xmm2, [rsp+0x20]
00007f30a29e4aa0  vmovaps xmm3, [rsp+0x30]
00007f30a29e4aa6  vmovaps xmm4, [rsp+0x40]
00007f30a29e4aac  vmovaps xmm5, [rsp+0x50]
00007f30a29e4ab2  vmovaps xmm6, [rsp+0x60]
00007f30a29e4ab8  vmovaps xmm7, [rsp+0x70]
00007f30a29e4abe  vmovaps xmm8, [rsp+0x80]
00007f30a29e4ac7  vmovaps xmm9, [rsp+0x90]
00007f30a29e4ad0  vmovaps xmm10, [rsp+0xA0]
00007f30a29e4ad9  vmovaps xmm11, [rsp+0xB0]
00007f30a29e4ae2  vmovaps xmm12, [rsp+0xC0]
00007f30a29e4aeb  vmovaps xmm13, [rsp+0xD0]
00007f30a29e4af4  vmovaps xmm15, [rsp+0xE0]
00007f30a29e4afd  add rsp, 0xF0
00007f30a29e4b04  pop r11
00007f30a29e4b06  pop r10
00007f30a29e4b08  pop r9
00007f30a29e4b0a  pop r8
00007f30a29e4b0c  pop rsi
00007f30a29e4b0d  pop rdi
00007f30a29e4b0e  pop rdx
00007f30a29e4b0f  pop rcx
00007f30a29e4b10  pop rax
00007f30a29e4b11  add rsp, 0x08
00007f30a29e4b15  jmp 0x00007F30A29DFA23
00007f30a29e4b1a  sub rsp, 0x08
00007f30a29e4b1e  push rax
00007f30a29e4b1f  push rcx
00007f30a29e4b20  push rdx
00007f30a29e4b21  push rdi
00007f30a29e4b22  push rsi
00007f30a29e4b23  push r8
00007f30a29e4b25  push r9
00007f30a29e4b27  push r10
00007f30a29e4b29  push r11
00007f30a29e4b2b  sub rsp, 0xF0
00007f30a29e4b32  vmovaps [rsp], xmm0
00007f30a29e4b37  vmovaps [rsp+0x10], xmm2
00007f30a29e4b3d  vmovaps [rsp+0x20], xmm3
00007f30a29e4b43  vmovaps [rsp+0x30], xmm4
00007f30a29e4b49  vmovaps [rsp+0x40], xmm5
00007f30a29e4b4f  vmovaps [rsp+0x50], xmm6
00007f30a29e4b55  vmovaps [rsp+0x60], xmm7
00007f30a29e4b5b  vmovaps [rsp+0x70], xmm8
00007f30a29e4b61  vmovaps [rsp+0x80], xmm9
00007f30a29e4b6a  vmovaps [rsp+0x90], xmm10
00007f30a29e4b73  vmovaps [rsp+0xA0], xmm11
00007f30a29e4b7c  vmovaps [rsp+0xB0], xmm12
00007f30a29e4b85  vmovaps [rsp+0xC0], xmm13
00007f30a29e4b8e  vmovaps [rsp+0xD0], xmm14
00007f30a29e4b97  vmovaps [rsp+0xE0], xmm15
00007f30a29e4ba0  sub rsp, 0x30
00007f30a29e4ba4  movaps [rsp], xmm1
00007f30a29e4ba8  movaps [rsp+0x10], xmm8
00007f30a29e4bae  movaps [rsp+0x20], xmm9
00007f30a29e4bb4  lea rdi, [rsp]
00007f30a29e4bb8  mov esi, 0x00
00007f30a29e4bbd  mov rax, 0x5FE955026530
00007f30a29e4bc7  call rax
00007f30a29e4bc9  movaps xmm1, [rsp]
00007f30a29e4bcd  add rsp, 0x30
00007f30a29e4bd1  vmovaps xmm0, [rsp]
00007f30a29e4bd6  vmovaps xmm2, [rsp+0x10]
00007f30a29e4bdc  vmovaps xmm3, [rsp+0x20]
00007f30a29e4be2  vmovaps xmm4, [rsp+0x30]
00007f30a29e4be8  vmovaps xmm5, [rsp+0x40]
00007f30a29e4bee  vmovaps xmm6, [rsp+0x50]
00007f30a29e4bf4  vmovaps xmm7, [rsp+0x60]
00007f30a29e4bfa  vmovaps xmm8, [rsp+0x70]
00007f30a29e4c00  vmovaps xmm9, [rsp+0x80]
00007f30a29e4c09  vmovaps xmm10, [rsp+0x90]
00007f30a29e4c12  vmovaps xmm11, [rsp+0xA0]
00007f30a29e4c1b  vmovaps xmm12, [rsp+0xB0]
00007f30a29e4c24  vmovaps xmm13, [rsp+0xC0]
00007f30a29e4c2d  vmovaps xmm14, [rsp+0xD0]
00007f30a29e4c36  vmovaps xmm15, [rsp+0xE0]
00007f30a29e4c3f  add rsp, 0xF0
00007f30a29e4c46  pop r11
00007f30a29e4c48  pop r10
00007f30a29e4c4a  pop r9
00007f30a29e4c4c  pop r8
00007f30a29e4c4e  pop rsi
00007f30a29e4c4f  pop rdi
00007f30a29e4c50  pop rdx
00007f30a29e4c51  pop rcx
00007f30a29e4c52  pop rax
00007f30a29e4c53  add rsp, 0x08
00007f30a29e4c57  jmp 0x00007F30A29DFA45
00007f30a29e4c5c  call 0x00007F30A28E5940
00007f30a29e4c61  jmp 0x00007F30A29DFA53
00007f30a29e4c66  call 0x00007F30A280C380
00007f30a29e4c6b  jmp 0x00007F30A29DFA5D
00007f30a29e4c70  call 0x00007F30A280D600
00007f30a29e4c75  jmp 0x00007F30A29DFA67
00007f30a29e4c7a  call 0x00007F30A27FF540
00007f30a29e4c7f  jmp 0x00007F30A29DFA71
00007f30a29e4c84  int3
00007f30a29e4c85  nop [rax+rax*1], ax
00007f30a29e4c8e  nop
00007f30a29e4c90  mov qword ptr [r15+0x40], 0x430000
00007f30a29e4c98  mov eax, 0x430CC0
00007f30a29e4c9d  mov r14, [r13+rax*1]
00007f30a29e4ca2  movq xmm1, r14
00007f30a29e4ca7  mov rax, [r15+0x50]
00007f30a29e4cab  movups xmm15, [r13+rax*1]
00007f30a29e4cb1  movaps [r15+0x120], xmm15
00007f30a29e4cb9  mov qword ptr [r15+0x48], 0x10
00007f30a29e4cc1  xor eax, eax
00007f30a29e4cc3  mov r14d, 0x10
00007f30a29e4cc9  mov r12d, 0x200
00007f30a29e4ccf  cmp r14, r12
00007f30a29e4cd2  cmc
00007f30a29e4cd3  lahf
00007f30a29e4cd4  seto al
00007f30a29e4cd7  mov [r15+0x108], eax
00007f30a29e4cde  pextrq rax, xmm15, 0x01
00007f30a29e4ce5  movq xmm14, rax
00007f30a29e4cea  movaps [r15+0x130], xmm14
00007f30a29e4cf2  movq rax, xmm1
00007f30a29e4cf7  movq r14, xmm15
00007f30a29e4cfc  vmovq xmm1, rax
00007f30a29e4d01  vmovq xmm15, r14
00007f30a29e4d06  movaps xmm13, xmm1
00007f30a29e4d0a  addsd xmm13, xmm15
00007f30a29e4d0f  ucomisd xmm13, xmm13
00007f30a29e4d14  jp 0x00007F30A29E4DD3
00007f30a29e4d1a  movq xmm13, xmm13
00007f30a29e4d1f  movq rax, xmm13
00007f30a29e4d24  movq r14, xmm14
00007f30a29e4d29  vmovq xmm1, rax
00007f30a29e4d2e  vmovq xmm15, r14
00007f30a29e4d33  movaps xmm14, xmm1
00007f30a29e4d37  addsd xmm14, xmm15
00007f30a29e4d3c  ucomisd xmm14, xmm14
00007f30a29e4d41  jp 0x00007F30A29E4E1B
00007f30a29e4d47  movq xmm14, xmm14
00007f30a29e4d4c  movaps [r15+0x110], xmm14
00007f30a29e4d54  mov eax, [r15+0x108]
00007f30a29e4d5b  sahf
00007f30a29e4d5c  jnz 0x00007F30A29E4D8E
00007f30a29e4d5e  cmp dword ptr [r15+0x318], 0x00
00007f30a29e4d66  jz 0x00007F30A29E5030
00007f30a29e4d6c  nop [rax+rax*1], ax
00007f30a29e4d75  nop [rax+rax*1], eax
00007f30a29e4d7d  mov eax, 0x410704
00007f30a29e4d82  mov [r15+0x100], rax
00007f30a29e4d89  jmp 0x00007F30A27FE110
00007f30a29e4d8e  cmp dword ptr [r15+0x318], 0x00
00007f30a29e4d96  jz 0x00007F30A29E4E70
00007f30a29e4d9c  nop [rax+rax*1], ax
00007f30a29e4da5  nop [rax+rax*1], eax
00007f30a29e4dad  mov eax, 0x4106E8
00007f30a29e4db2  mov [r15+0x100], rax
00007f30a29e4db9  jmp 0x00007F30A27FE110
00007f30a29e4dbe  int3
00007f30a29e4dbf  call 0x00007F30A280DC20
00007f30a29e4dc4  jmp 0x00007F30A29E4CA2
00007f30a29e4dc9  call 0x00007F30A280E760
00007f30a29e4dce  jmp 0x00007F30A29E4CB1
00007f30a29e4dd3  ucomisd xmm1, xmm15
00007f30a29e4dd8  jp 0x00007F30A29E4DE7
00007f30a29e4dda  movaps xmm13, [0x00007F30A25FE060]
00007f30a29e4de2  jmp 0x00007F30A29E4D1A
00007f30a29e4de7  vxorps xmm0, xmm1, xmm15
00007f30a29e4dec  pextrw eax, xmm0, 0x03
00007f30a29e4df1  and eax, 0x7FF8
00007f30a29e4df6  cmp eax, 0x08
00007f30a29e4df9  jnz 0x00007F30A29E4D1A
00007f30a29e4dff  movq rax, xmm15
00007f30a29e4e04  shl rax, 0x0D
00007f30a29e4e08  jbe 0x00007F30A29E4D1A
00007f30a29e4e0e  vorps xmm13, xmm15, [0x00007F30A25FE070]
00007f30a29e4e16  jmp 0x00007F30A29E4D1A
00007f30a29e4e1b  ucomisd xmm1, xmm15
00007f30a29e4e20  jp 0x00007F30A29E4E2F
00007f30a29e4e22  movaps xmm14, [0x00007F30A25FE060]
00007f30a29e4e2a  jmp 0x00007F30A29E4D47
00007f30a29e4e2f  vxorps xmm0, xmm1, xmm15
00007f30a29e4e34  pextrw eax, xmm0, 0x03
00007f30a29e4e39  and eax, 0x7FF8
00007f30a29e4e3e  cmp eax, 0x08
00007f30a29e4e41  jnz 0x00007F30A29E4D47
00007f30a29e4e47  movq rax, xmm15
00007f30a29e4e4c  shl rax, 0x0D
00007f30a29e4e50  jbe 0x00007F30A29E4D47
00007f30a29e4e56  vorps xmm14, xmm15, [0x00007F30A25FE070]
00007f30a29e4e5e  jmp 0x00007F30A29E4D47
00007f30a29e4e63  int3
00007f30a29e4e64  nop [rax+rax*1], ax
00007f30a29e4e6d  nop [rax], eax
00007f30a29e4e70  mov rax, [r15+0x48]
00007f30a29e4e74  mov r14, [r15+0x50]
00007f30a29e4e78  lea r12, [r14+rax*1]
00007f30a29e4e7c  movups xmm1, [r13+r12*1]
00007f30a29e4e82  movaps [r15+0x120], xmm1
00007f30a29e4e8a  lea r14, [rax+0x10]
00007f30a29e4e8e  mov [r15+0x48], r14
00007f30a29e4e92  xor eax, eax
00007f30a29e4e94  mov r12d, 0x200
00007f30a29e4e9a  cmp r14, r12
00007f30a29e4e9d  cmc
00007f30a29e4e9e  lahf
00007f30a29e4e9f  seto al
00007f30a29e4ea2  mov [r15+0x108], eax
00007f30a29e4ea9  pextrq rax, xmm1, 0x01
00007f30a29e4eb0  movq xmm15, rax
00007f30a29e4eb5  movaps [r15+0x130], xmm15
00007f30a29e4ebd  movaps xmm14, [r15+0x110]
00007f30a29e4ec5  movq rax, xmm14
00007f30a29e4eca  movq r14, xmm1
00007f30a29e4ecf  vmovq xmm1, rax
00007f30a29e4ed4  vmovq xmm14, r14
00007f30a29e4ed9  movaps xmm13, xmm1
00007f30a29e4edd  addsd xmm13, xmm14
00007f30a29e4ee2  ucomisd xmm13, xmm13
00007f30a29e4ee7  jp 0x00007F30A29E4F9C
00007f30a29e4eed  movq xmm13, xmm13
00007f30a29e4ef2  movq rax, xmm13
00007f30a29e4ef7  movq r14, xmm15
00007f30a29e4efc  vmovq xmm1, rax
00007f30a29e4f01  vmovq xmm15, r14
00007f30a29e4f06  movaps xmm14, xmm1
00007f30a29e4f0a  addsd xmm14, xmm15
00007f30a29e4f0f  ucomisd xmm14, xmm14
00007f30a29e4f14  jp 0x00007F30A29E4FE4
00007f30a29e4f1a  movq xmm14, xmm14
00007f30a29e4f1f  movaps [r15+0x110], xmm14
00007f30a29e4f27  mov eax, [r15+0x108]
00007f30a29e4f2e  sahf
00007f30a29e4f2f  jnz 0x00007F30A29E4F61
00007f30a29e4f31  cmp dword ptr [r15+0x318], 0x00
00007f30a29e4f39  jz 0x00007F30A29E5030
00007f30a29e4f3f  nop [rax+rax*1], ax
00007f30a29e4f48  nop [rax+rax*1], eax
00007f30a29e4f50  mov eax, 0x410704
00007f30a29e4f55  mov [r15+0x100], rax
00007f30a29e4f5c  jmp 0x00007F30A27FE110
00007f30a29e4f61  cmp dword ptr [r15+0x318], 0x00
00007f30a29e4f69  jz 0x00007F30A29E4E70
00007f30a29e4f6f  nop [rax+rax*1], ax
00007f30a29e4f78  nop [rax+rax*1], eax
00007f30a29e4f80  mov eax, 0x4106E8
00007f30a29e4f85  mov [r15+0x100], rax
00007f30a29e4f8c  jmp 0x00007F30A27FE110
00007f30a29e4f91  int3
00007f30a29e4f92  call 0x00007F30A28B52F0
00007f30a29e4f97  jmp 0x00007F30A29E4E82
00007f30a29e4f9c  ucomisd xmm1, xmm14
00007f30a29e4fa1  jp 0x00007F30A29E4FB0
00007f30a29e4fa3  movaps xmm13, [0x00007F30A25FE060]
00007f30a29e4fab  jmp 0x00007F30A29E4EED
00007f30a29e4fb0  vxorps xmm0, xmm1, xmm14
00007f30a29e4fb5  pextrw eax, xmm0, 0x03
00007f30a29e4fba  and eax, 0x7FF8
00007f30a29e4fbf  cmp eax, 0x08
00007f30a29e4fc2  jnz 0x00007F30A29E4EED
00007f30a29e4fc8  movq rax, xmm14
00007f30a29e4fcd  shl rax, 0x0D
00007f30a29e4fd1  jbe 0x00007F30A29E4EED
00007f30a29e4fd7  vorps xmm13, xmm14, [0x00007F30A25FE070]
00007f30a29e4fdf  jmp 0x00007F30A29E4EED
00007f30a29e4fe4  ucomisd xmm1, xmm15
00007f30a29e4fe9  jp 0x00007F30A29E4FF8
00007f30a29e4feb  movaps xmm14, [0x00007F30A25FE060]
00007f30a29e4ff3  jmp 0x00007F30A29E4F1A
00007f30a29e4ff8  vxorps xmm0, xmm1, xmm15
00007f30a29e4ffd  pextrw eax, xmm0, 0x03
00007f30a29e5002  and eax, 0x7FF8
00007f30a29e5007  cmp eax, 0x08
00007f30a29e500a  jnz 0x00007F30A29E4F1A
00007f30a29e5010  movq rax, xmm15
00007f30a29e5015  shl rax, 0x0D
00007f30a29e5019  jbe 0x00007F30A29E4F1A
00007f30a29e501f  vorps xmm14, xmm15, [0x00007F30A25FE070]
00007f30a29e5027  jmp 0x00007F30A29E4F1A
00007f30a29e502c  int3
00007f30a29e502d  nop [rax], eax
00007f30a29e5030  mov rax, [r15+0xF8]
00007f30a29e5037  lea r14, [rax+0x1D0]
00007f30a29e503e  mov r12, [r13+r14*1]
00007f30a29e5043  lea r14, [rax+0x1D8]
00007f30a29e504a  mov r11, [r13+r14*1]
00007f30a29e504f  mov [r15+0xA0], r12
00007f30a29e5056  mov [r15+0x98], r11
00007f30a29e505d  mov r14, [r15+0x40]
00007f30a29e5061  lea r12, [r14+0xCC0]
00007f30a29e5068  movaps xmm1, [r15+0x110]
00007f30a29e5070  movq r14, xmm1
00007f30a29e5075  mov [r13+r12*1], r14
00007f30a29e507a  lea r14, [rax+0x1C0]
00007f30a29e5081  mov r12, [r13+r14*1]
00007f30a29e5086  lea r14, [rax+0x1C8]
00007f30a29e508d  mov r11, [r13+r14*1]
00007f30a29e5092  mov [r15+0xE8], r12
00007f30a29e5099  mov [r15+0xF0], r11
00007f30a29e50a0  lea r14, [rax+0x1B0]
00007f30a29e50a7  mov r12, [r13+r14*1]
00007f30a29e50ac  lea r14, [rax+0x1B8]
00007f30a29e50b3  mov r10, [r13+r14*1]
00007f30a29e50b8  movq xmm1, r12
00007f30a29e50bd  movq xmm15, r10
00007f30a29e50c2  movq xmm1, xmm1
00007f30a29e50c6  movq xmm1, xmm1
00007f30a29e50ca  movaps [r15+0x1A0], xmm1
00007f30a29e50d2  movq xmm15, xmm15
00007f30a29e50d7  movq xmm15, xmm15
00007f30a29e50dc  movaps [r15+0x190], xmm15
00007f30a29e50e4  lea r14, [rax+0x1A0]
00007f30a29e50eb  mov r12, [r13+r14*1]
00007f30a29e50f0  lea r14, [rax+0x1A8]
00007f30a29e50f7  mov r10, [r13+r14*1]
00007f30a29e50fc  movq xmm1, r12
00007f30a29e5101  movq xmm15, r10
00007f30a29e5106  movq xmm1, xmm1
00007f30a29e510a  movq xmm1, xmm1
00007f30a29e510e  movaps [r15+0x1C0], xmm1
00007f30a29e5116  movq xmm15, xmm15
00007f30a29e511b  movq xmm15, xmm15
00007f30a29e5120  movaps [r15+0x1B0], xmm15
00007f30a29e5128  lea r14, [rax+0x190]
00007f30a29e512f  mov r12, [r13+r14*1]
00007f30a29e5134  lea r14, [rax+0x198]
00007f30a29e513b  mov r10, [r13+r14*1]
00007f30a29e5140  movq xmm1, r12
00007f30a29e5145  movq xmm15, r10
00007f30a29e514a  movq xmm1, xmm1
00007f30a29e514e  movq xmm1, xmm1
00007f30a29e5152  movaps [r15+0x1E0], xmm1
00007f30a29e515a  movq xmm15, xmm15
00007f30a29e515f  movq xmm15, xmm15
00007f30a29e5164  movaps [r15+0x1D0], xmm15
00007f30a29e516c  lea r14, [rax+0x180]
00007f30a29e5173  mov r12, [r13+r14*1]
00007f30a29e5178  lea r14, [rax+0x188]
00007f30a29e517f  mov r10, [r13+r14*1]
00007f30a29e5184  movq xmm1, r12
00007f30a29e5189  movq xmm15, r10
00007f30a29e518e  movq xmm1, xmm1
00007f30a29e5192  movq xmm1, xmm1
00007f30a29e5196  movaps [r15+0x200], xmm1
00007f30a29e519e  movq xmm15, xmm15
00007f30a29e51a3  movq xmm15, xmm15
00007f30a29e51a8  movaps [r15+0x1F0], xmm15
00007f30a29e51b0  lea r14, [rax+0x1E0]
00007f30a29e51b7  mov [r15+0xF8], r14
00007f30a29e51be  mov [r15+0x100], r11
00007f30a29e51c5  jmp 0x00007F30A29CE5C0
00007f30a29e51ca  int3
00007f30a29e51cb  call 0x00007F30A28E27E0
00007f30a29e51d0  jmp 0x00007F30A29E5043
00007f30a29e51d5  call 0x00007F30A28E1570
00007f30a29e51da  jmp 0x00007F30A29E504F
00007f30a29e51df  call 0x00007F30A28C3FE0
00007f30a29e51e4  jmp 0x00007F30A29E507A
00007f30a29e51e9  call 0x00007F30A28E27E0
00007f30a29e51ee  jmp 0x00007F30A29E5086
00007f30a29e51f3  call 0x00007F30A28E1570
00007f30a29e51f8  jmp 0x00007F30A29E5092
00007f30a29e51fd  call 0x00007F30A28E27E0
00007f30a29e5202  jmp 0x00007F30A29E50AC
00007f30a29e5207  call 0x00007F30A28E0300
00007f30a29e520c  jmp 0x00007F30A29E50B8
00007f30a29e5211  call 0x00007F30A28E27E0
00007f30a29e5216  jmp 0x00007F30A29E50F0
00007f30a29e521b  call 0x00007F30A28E0300
00007f30a29e5220  jmp 0x00007F30A29E50FC
00007f30a29e5225  call 0x00007F30A28E27E0
00007f30a29e522a  jmp 0x00007F30A29E5134
00007f30a29e522f  call 0x00007F30A28E0300
00007f30a29e5234  jmp 0x00007F30A29E5140
00007f30a29e5239  call 0x00007F30A28E27E0
00007f30a29e523e  jmp 0x00007F30A29E5178
00007f30a29e5243  call 0x00007F30A28E0300
00007f30a29e5248  jmp 0x00007F30A29E5184
00007f30a29e524d  int3
00007f30a29e524e  nop
00007f30a29e5250  mov qword ptr [r15+0x100], 0x04
00007f30a29e525b  mov esi, 0x00
00007f30a29e5260  mov edx, 0x09
00007f30a29e5265  mov rdi, 0x7FFC6D4A6E20
00007f30a29e526f  mov rax, 0x5FE954EB9970
00007f30a29e5279  call rax
00007f30a29e527b  cmp dword ptr [r15+0x318], 0x00
00007f30a29e5283  jnz 0x00007F30A27FE110
00007f30a29e5289  jmp 0x00007F30A27FE0A0
00007f30a29e528e  int3
00007f30a29e528f  int3
