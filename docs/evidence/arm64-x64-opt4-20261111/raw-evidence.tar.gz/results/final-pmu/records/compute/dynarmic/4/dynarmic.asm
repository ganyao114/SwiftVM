0000796da41ce69b  nop [rax+rax*1], eax
0000796da41ce6a0  mov rax, [r15+0xF8]
0000796da41ce6a7  lea r14, [rax-0x1E0]
0000796da41ce6ae  mov [r15+0xF8], r14
0000796da41ce6b5  lea rax, [r14+0x1D0]
0000796da41ce6bc  mov r12, [r15+0xA0]
0000796da41ce6c3  mov r11, [r15+0x98]
0000796da41ce6ca  mov [r13+rax*1], r12
0000796da41ce6cf  lea rax, [r14+0x1D8]
0000796da41ce6d6  mov [r13+rax*1], r11
0000796da41ce6db  mov eax, 0x420AA0
0000796da41ce6e0  movups xmm1, [r13+rax*1]
0000796da41ce6e6  mov eax, 0x420A30
0000796da41ce6eb  movups xmm15, [r13+rax*1]
0000796da41ce6f1  mov eax, 0x420AC0
0000796da41ce6f6  movups xmm14, [r13+rax*1]
0000796da41ce6fc  mov eax, 0x420A60
0000796da41ce701  movups xmm13, [r13+rax*1]
0000796da41ce707  mov qword ptr [r15+0x98], 0x430CD0
0000796da41ce712  mov eax, 0x420AD0
0000796da41ce717  movups xmm12, [r13+rax*1]
0000796da41ce71d  mov eax, 0x430CD0
0000796da41ce722  movups [r13+rax*1], xmm1
0000796da41ce728  mov eax, 0x430CE0
0000796da41ce72d  movups [r13+rax*1], xmm15
0000796da41ce733  mov eax, 0x430CF0
0000796da41ce738  movups [r13+rax*1], xmm14
0000796da41ce73e  mov eax, 0x430D00
0000796da41ce743  movups [r13+rax*1], xmm13
0000796da41ce749  mov eax, 0x420A20
0000796da41ce74e  movups xmm14, [r13+rax*1]
0000796da41ce754  mov eax, 0x420A10
0000796da41ce759  movups xmm13, [r13+rax*1]
0000796da41ce75f  mov eax, 0x430DD0
0000796da41ce764  movups [r13+rax*1], xmm1
0000796da41ce76a  mov eax, 0x430DE0
0000796da41ce76f  movups [r13+rax*1], xmm15
0000796da41ce775  mov eax, 0x430D10
0000796da41ce77a  movups [r13+rax*1], xmm12
0000796da41ce780  mov eax, 0x430D20
0000796da41ce785  movups [r13+rax*1], xmm14
0000796da41ce78b  mov eax, 0x420A00
0000796da41ce790  movups xmm1, [r13+rax*1]
0000796da41ce796  mov eax, 0x420A70
0000796da41ce79b  movups xmm15, [r13+rax*1]
0000796da41ce7a1  mov eax, 0x430D30
0000796da41ce7a6  movups [r13+rax*1], xmm13
0000796da41ce7ac  mov eax, 0x430D40
0000796da41ce7b1  movups [r13+rax*1], xmm1
0000796da41ce7b7  mov eax, 0x420A80
0000796da41ce7bc  movups xmm1, [r13+rax*1]
0000796da41ce7c2  mov eax, 0x420A50
0000796da41ce7c7  movups xmm14, [r13+rax*1]
0000796da41ce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
0000796da41ce7d5  mov eax, 0x430D50
0000796da41ce7da  movups [r13+rax*1], xmm15
0000796da41ce7e0  mov eax, 0x430D60
0000796da41ce7e5  movups [r13+rax*1], xmm1
0000796da41ce7eb  mov eax, 0x420AF0
0000796da41ce7f0  movups xmm1, [r13+rax*1]
0000796da41ce7f6  mov eax, 0x420B00
0000796da41ce7fb  movups xmm15, [r13+rax*1]
0000796da41ce801  movaps [r15+0x150], xmm15
0000796da41ce809  mov qword ptr [r15+0xA0], 0x3E8
0000796da41ce814  mov eax, 0x430D70
0000796da41ce819  movups [r13+rax*1], xmm14
0000796da41ce81f  mov eax, 0x430D80
0000796da41ce824  movups [r13+rax*1], xmm1
0000796da41ce82a  mov eax, 0x420AE0
0000796da41ce82f  movups xmm1, [r13+rax*1]
0000796da41ce835  mov eax, 0x420A90
0000796da41ce83a  movups xmm14, [r13+rax*1]
0000796da41ce840  movaps [r15+0x140], xmm14
0000796da41ce848  lea rax, [r14+0x180]
0000796da41ce84f  movq xmm13, qword ptr [r15+0x200]
0000796da41ce858  movq xmm12, qword ptr [r15+0x1F0]
0000796da41ce861  movq r12, xmm13
0000796da41ce866  movq r11, xmm12
0000796da41ce86b  mov [r13+rax*1], r12
0000796da41ce870  lea rax, [r14+0x188]
0000796da41ce877  mov [r13+rax*1], r11
0000796da41ce87c  mov eax, 0x430D90
0000796da41ce881  movups [r13+rax*1], xmm15
0000796da41ce887  mov eax, 0x430DA0
0000796da41ce88c  movups [r13+rax*1], xmm1
0000796da41ce892  mov eax, 0x420AB0
0000796da41ce897  movups xmm1, [r13+rax*1]
0000796da41ce89d  mov eax, 0x420B18
0000796da41ce8a2  mov r12, [r13+rax*1]
0000796da41ce8a7  movq xmm15, r12
0000796da41ce8ac  mov qword ptr [r15+0x40], 0x420B20
0000796da41ce8b4  mov eax, 0x430DB0
0000796da41ce8b9  movups [r13+rax*1], xmm14
0000796da41ce8bf  mov eax, 0x430DC0
0000796da41ce8c4  movups [r13+rax*1], xmm1
0000796da41ce8ca  mov eax, 0x420B80
0000796da41ce8cf  movups xmm1, [r13+rax*1]
0000796da41ce8d5  movq rax, xmm15
0000796da41ce8da  mov r12d, 0x430DF0
0000796da41ce8e0  mov [r13+r12*1], rax
0000796da41ce8e5  mov eax, 0x420B60
0000796da41ce8ea  movups xmm15, [r13+rax*1]
0000796da41ce8f0  mov eax, 0x420B70
0000796da41ce8f5  movups xmm14, [r13+rax*1]
0000796da41ce8fb  lea rax, [r14+0x160]
0000796da41ce902  movups [r13+rax*1], xmm1
0000796da41ce908  lea rax, [r14+0x190]
0000796da41ce90f  movq xmm1, qword ptr [r15+0x1E0]
0000796da41ce918  movq xmm13, qword ptr [r15+0x1D0]
0000796da41ce921  movq r12, xmm1
0000796da41ce926  movq r11, xmm13
0000796da41ce92b  mov [r13+rax*1], r12
0000796da41ce930  lea rax, [r14+0x198]
0000796da41ce937  mov [r13+rax*1], r11
0000796da41ce93c  lea rax, [r14+0x140]
0000796da41ce943  movups [r13+rax*1], xmm15
0000796da41ce949  lea rax, [r14+0x150]
0000796da41ce950  movups [r13+rax*1], xmm14
0000796da41ce956  mov eax, 0x420B20
0000796da41ce95b  movups xmm1, [r13+rax*1]
0000796da41ce961  mov eax, 0x420B30
0000796da41ce966  movups xmm15, [r13+rax*1]
0000796da41ce96c  movaps [r15+0x120], xmm15
0000796da41ce974  lea rax, [r14+0x1A0]
0000796da41ce97b  movq xmm14, qword ptr [r15+0x1C0]
0000796da41ce984  movq xmm13, qword ptr [r15+0x1B0]
0000796da41ce98d  movq r12, xmm14
0000796da41ce992  movq r11, xmm13
0000796da41ce997  mov [r13+rax*1], r12
0000796da41ce99c  lea rax, [r14+0x1A8]
0000796da41ce9a3  mov [r13+rax*1], r11
0000796da41ce9a8  lea rax, [r14+0x1B0]
0000796da41ce9af  movq xmm14, qword ptr [r15+0x1A0]
0000796da41ce9b8  movq xmm13, qword ptr [r15+0x190]
0000796da41ce9c1  movq r12, xmm14
0000796da41ce9c6  movq r11, xmm13
0000796da41ce9cb  mov [r13+rax*1], r12
0000796da41ce9d0  lea rax, [r14+0x1B8]
0000796da41ce9d7  mov [r13+rax*1], r11
0000796da41ce9dc  lea rax, [r14+0x100]
0000796da41ce9e3  movups [r13+rax*1], xmm1
0000796da41ce9e9  lea rax, [r14+0x110]
0000796da41ce9f0  movups [r13+rax*1], xmm15
0000796da41ce9f6  mov eax, 0x420B40
0000796da41ce9fb  movups xmm1, [r13+rax*1]
0000796da41cea01  mov eax, 0x420B50
0000796da41cea06  movups xmm15, [r13+rax*1]
0000796da41cea0c  movaps [r15+0x110], xmm1
0000796da41cea14  movaps [r15+0x130], xmm15
0000796da41cea1c  lea rax, [r14+0x1C0]
0000796da41cea23  mov r12, [r15+0xE8]
0000796da41cea2a  mov r11, [r15+0xF0]
0000796da41cea31  mov [r13+rax*1], r12
0000796da41cea36  lea rax, [r14+0x1C8]
0000796da41cea3d  mov [r13+rax*1], r11
0000796da41cea42  mov eax, 0x430DF8
0000796da41cea47  mov r12d, 0x421DF8D3
0000796da41cea4d  mov [r13+rax*1], r12d
0000796da41cea52  lea rax, [r14+0x120]
0000796da41cea59  movups [r13+rax*1], xmm1
0000796da41cea5f  lea rax, [r14+0x130]
0000796da41cea66  movups [r13+rax*1], xmm15
0000796da41cea6c  lea rax, [r14+0x100]
0000796da41cea73  mov [r15], rax
0000796da41cea76  mov qword ptr [r15+0x08], 0x430CD0
0000796da41cea7e  mov qword ptr [r15+0x10], 0x12C
0000796da41cea86  mov qword ptr [r15+0xF0], 0x410284
0000796da41cea91  mov r14d, [r15+0x320]
0000796da41cea98  mov eax, 0x410284
0000796da41cea9d  mov rcx, 0x796DA41D07C0
0000796da41ceaa7  mov [r15+r14*8+0x328], rax
0000796da41ceaaf  mov [r15+r14*8+0x368], rcx
0000796da41ceab7  add r14d, 0x01
0000796da41ceabb  and r14d, 0x07
0000796da41ceabf  mov [r15+0x320], r14d
0000796da41ceac6  cmp dword ptr [r15+0x318], 0x00
0000796da41ceace  jz 0x0000796DA41CED70
0000796da41cead4  nop [rax+rax*1], ax
0000796da41ceadd  nop [rax+rax*1], eax
0000796da41ceae5  mov eax, 0x410728
0000796da41ceaea  mov [r15+0x100], rax
0000796da41ceaf1  jmp 0x0000796DA3FFE110
0000796da41ceaf6  int3
0000796da41ceaf7  call 0x0000796DA400BC20
0000796da41ceafc  jmp 0x0000796DA41CE6CF
0000796da41ceb01  call 0x0000796DA400A9A0
0000796da41ceb06  jmp 0x0000796DA41CE6DB
0000796da41ceb0b  call 0x0000796DA3FFF430
0000796da41ceb10  jmp 0x0000796DA41CE6E6
0000796da41ceb15  call 0x0000796DA400E760
0000796da41ceb1a  jmp 0x0000796DA41CE6F1
0000796da41ceb1f  call 0x0000796DA400D4E0
0000796da41ceb24  jmp 0x0000796DA41CE6FC
0000796da41ceb29  call 0x0000796DA400C260
0000796da41ceb2e  jmp 0x0000796DA41CE707
0000796da41ceb33  call 0x0000796DA400AFE0
0000796da41ceb38  jmp 0x0000796DA41CE71D
0000796da41ceb3d  call 0x0000796DA3FFF540
0000796da41ceb42  jmp 0x0000796DA41CE728
0000796da41ceb47  call 0x0000796DA400E880
0000796da41ceb4c  jmp 0x0000796DA41CE733
0000796da41ceb51  call 0x0000796DA400D600
0000796da41ceb56  jmp 0x0000796DA41CE73E
0000796da41ceb5b  call 0x0000796DA400C380
0000796da41ceb60  jmp 0x0000796DA41CE749
0000796da41ceb65  call 0x0000796DA400D4E0
0000796da41ceb6a  jmp 0x0000796DA41CE754
0000796da41ceb6f  call 0x0000796DA400C260
0000796da41ceb74  jmp 0x0000796DA41CE75F
0000796da41ceb79  call 0x0000796DA3FFF540
0000796da41ceb7e  jmp 0x0000796DA41CE76A
0000796da41ceb83  call 0x0000796DA400E880
0000796da41ceb88  jmp 0x0000796DA41CE775
0000796da41ceb8d  call 0x0000796DA400B100
0000796da41ceb92  jmp 0x0000796DA41CE780
0000796da41ceb97  call 0x0000796DA400D600
0000796da41ceb9c  jmp 0x0000796DA41CE78B
0000796da41ceba1  call 0x0000796DA3FFF430
0000796da41ceba6  jmp 0x0000796DA41CE796
0000796da41cebab  call 0x0000796DA400E760
0000796da41cebb0  jmp 0x0000796DA41CE7A1
0000796da41cebb5  call 0x0000796DA400C380
0000796da41cebba  jmp 0x0000796DA41CE7AC
0000796da41cebbf  call 0x0000796DA3FFF540
0000796da41cebc4  jmp 0x0000796DA41CE7B7
0000796da41cebc9  call 0x0000796DA3FFF430
0000796da41cebce  jmp 0x0000796DA41CE7C2
0000796da41cebd3  call 0x0000796DA400D4E0
0000796da41cebd8  jmp 0x0000796DA41CE7CD
0000796da41cebdd  call 0x0000796DA400E880
0000796da41cebe2  jmp 0x0000796DA41CE7E0
0000796da41cebe7  call 0x0000796DA3FFF540
0000796da41cebec  jmp 0x0000796DA41CE7EB
0000796da41cebf1  call 0x0000796DA3FFF430
0000796da41cebf6  jmp 0x0000796DA41CE7F6
0000796da41cebfb  call 0x0000796DA400E760
0000796da41cec00  jmp 0x0000796DA41CE801
0000796da41cec05  call 0x0000796DA400D600
0000796da41cec0a  jmp 0x0000796DA41CE81F
0000796da41cec0f  call 0x0000796DA3FFF540
0000796da41cec14  jmp 0x0000796DA41CE82A
0000796da41cec19  call 0x0000796DA3FFF430
0000796da41cec1e  jmp 0x0000796DA41CE835
0000796da41cec23  call 0x0000796DA400D4E0
0000796da41cec28  jmp 0x0000796DA41CE840
0000796da41cec2d  call 0x0000796DA400BC20
0000796da41cec32  jmp 0x0000796DA41CE870
0000796da41cec37  call 0x0000796DA400A9A0
0000796da41cec3c  jmp 0x0000796DA41CE87C
0000796da41cec41  call 0x0000796DA400E880
0000796da41cec46  jmp 0x0000796DA41CE887
0000796da41cec4b  call 0x0000796DA3FFF540
0000796da41cec50  jmp 0x0000796DA41CE892
0000796da41cec55  call 0x0000796DA3FFF430
0000796da41cec5a  jmp 0x0000796DA41CE89D
0000796da41cec5f  call 0x0000796DA400B720
0000796da41cec64  jmp 0x0000796DA41CE8A7
0000796da41cec69  call 0x0000796DA400D600
0000796da41cec6e  jmp 0x0000796DA41CE8BF
0000796da41cec73  call 0x0000796DA3FFF540
0000796da41cec78  jmp 0x0000796DA41CE8CA
0000796da41cec7d  call 0x0000796DA3FFF430
0000796da41cec82  jmp 0x0000796DA41CE8D5
0000796da41cec87  call 0x0000796DA40B4CB0
0000796da41cec8c  jmp 0x0000796DA41CE8E5
0000796da41cec91  call 0x0000796DA400E760
0000796da41cec96  jmp 0x0000796DA41CE8F0
0000796da41cec9b  call 0x0000796DA400D4E0
0000796da41ceca0  jmp 0x0000796DA41CE8FB
0000796da41ceca5  call 0x0000796DA3FFF540
0000796da41cecaa  jmp 0x0000796DA41CE908
0000796da41cecaf  call 0x0000796DA400BC20
0000796da41cecb4  jmp 0x0000796DA41CE930
0000796da41cecb9  call 0x0000796DA400A9A0
0000796da41cecbe  jmp 0x0000796DA41CE93C
0000796da41cecc3  call 0x0000796DA400E880
0000796da41cecc8  jmp 0x0000796DA41CE949
0000796da41ceccd  call 0x0000796DA400D600
0000796da41cecd2  jmp 0x0000796DA41CE956
0000796da41cecd7  call 0x0000796DA3FFF430
0000796da41cecdc  jmp 0x0000796DA41CE961
0000796da41cece1  call 0x0000796DA400E760
0000796da41cece6  jmp 0x0000796DA41CE96C
0000796da41ceceb  call 0x0000796DA400BC20
0000796da41cecf0  jmp 0x0000796DA41CE99C
0000796da41cecf5  call 0x0000796DA400A9A0
0000796da41cecfa  jmp 0x0000796DA41CE9A8
0000796da41cecff  call 0x0000796DA400BC20
0000796da41ced04  jmp 0x0000796DA41CE9D0
0000796da41ced09  call 0x0000796DA400A9A0
0000796da41ced0e  jmp 0x0000796DA41CE9DC
0000796da41ced13  call 0x0000796DA3FFF540
0000796da41ced18  jmp 0x0000796DA41CE9E9
0000796da41ced1d  call 0x0000796DA400E880
0000796da41ced22  jmp 0x0000796DA41CE9F6
0000796da41ced27  call 0x0000796DA3FFF430
0000796da41ced2c  jmp 0x0000796DA41CEA01
0000796da41ced31  call 0x0000796DA400E760
0000796da41ced36  jmp 0x0000796DA41CEA0C
0000796da41ced3b  call 0x0000796DA400BC20
0000796da41ced40  jmp 0x0000796DA41CEA36
0000796da41ced45  call 0x0000796DA400A9A0
0000796da41ced4a  jmp 0x0000796DA41CEA42
0000796da41ced4f  call 0x0000796DA400BAE0
0000796da41ced54  jmp 0x0000796DA41CEA52
0000796da41ced59  call 0x0000796DA3FFF540
0000796da41ced5e  jmp 0x0000796DA41CEA5F
0000796da41ced63  call 0x0000796DA400E880
0000796da41ced68  jmp 0x0000796DA41CEA6C
0000796da41ced6d  int3
0000796da41ced6e  nop
0000796da41ced70  mov rax, [r15]
0000796da41ced73  lea r14, [rax+0x20]
0000796da41ced77  mov r12, [r13+r14*1]
0000796da41ced7c  mov r14, [r15+0x10]
0000796da41ced80  lea r11, [r12+r14*1]
0000796da41ced84  mov [r15+0x40], r11
0000796da41ced88  lea r12, [rax+0x20]
0000796da41ced8c  mov [r13+r12*1], r11
0000796da41ced91  test r14, r14
0000796da41ced94  setz r14b
0000796da41ced98  movzx r14, r14b
0000796da41ced9c  mov [rsp+0x414], r14b
0000796da41ceda4  cmp byte ptr [rsp+0x414], 0x00
0000796da41cedac  jz 0x0000796DA41CEDDE
0000796da41cedae  cmp dword ptr [r15+0x318], 0x00
0000796da41cedb6  mov eax, 0x4109A0
0000796da41cedbb  mov [r15+0x100], rax
0000796da41cedc2  jz 0x0000796DA3FFE0A0
0000796da41cedc8  nop [rax+rax*1], eax
0000796da41cedcd  mov eax, 0x4109A0
0000796da41cedd2  mov [r15+0x100], rax
0000796da41cedd9  jmp 0x0000796DA3FFE110
0000796da41cedde  cmp dword ptr [r15+0x318], 0x00
0000796da41cede6  jz 0x0000796DA41CEE30
0000796da41cedec  nop [rax+rax*1], ax
0000796da41cedf5  nop [rax+rax*1], eax
0000796da41cedfd  mov eax, 0x410738
0000796da41cee02  mov [r15+0x100], rax
0000796da41cee09  jmp 0x0000796DA3FFE110
0000796da41cee0e  int3
0000796da41cee0f  call 0x0000796DA40E27E0
0000796da41cee14  jmp 0x0000796DA41CED7C
0000796da41cee19  call 0x0000796DA40C0860
0000796da41cee1e  jmp 0x0000796DA41CED91
0000796da41cee23  int3
0000796da41cee24  nop [rax+rax*1], ax
0000796da41cee2d  nop [rax], eax
0000796da41cee30  mov rax, [r15+0xF8]
0000796da41cee37  lea r14, [rax-0x150]
0000796da41cee3e  mov [r15+0xF8], r14
0000796da41cee45  mov rax, [r15]
0000796da41cee48  lea r12, [rax+0x68]
0000796da41cee4c  mov r11, [r13+r12*1]
0000796da41cee51  mov [r15+0x88], r11
0000796da41cee58  lea r12, [rax+0x28]
0000796da41cee5c  mov [r15+0x40], r12
0000796da41cee60  mov [r15+0x48], r14
0000796da41cee64  mov qword ptr [r15+0x50], 0x420B90
0000796da41cee6c  lea rax, [r14+0x100]
0000796da41cee73  mov r12, [r15+0xE8]
0000796da41cee7a  mov r11, [r15+0xD8]
0000796da41cee81  mov [r13+rax*1], r12
0000796da41cee86  lea rax, [r14+0x108]
0000796da41cee8d  mov [r13+rax*1], r11
0000796da41cee92  lea rax, [r14+0x110]
0000796da41cee99  mov r12, [r15+0xD0]
0000796da41ceea0  mov r11, [r15+0xC8]
0000796da41ceea7  mov [r13+rax*1], r12
0000796da41ceeac  lea rax, [r14+0x118]
0000796da41ceeb3  mov [r13+rax*1], r11
0000796da41ceeb8  lea rax, [r14+0x120]
0000796da41ceebf  mov r12, [r15+0xC0]
0000796da41ceec6  mov r11, [r15+0xB8]
0000796da41ceecd  mov [r13+rax*1], r12
0000796da41ceed2  lea rax, [r14+0x128]
0000796da41ceed9  mov [r13+rax*1], r11
0000796da41ceede  lea rax, [r14+0x130]
0000796da41ceee5  mov r12, [r15+0xB0]
0000796da41ceeec  mov r11, [r15+0xA8]
0000796da41ceef3  mov [r13+rax*1], r12
0000796da41ceef8  lea rax, [r14+0x138]
0000796da41ceeff  mov [r13+rax*1], r11
0000796da41cef04  lea rax, [r14+0x140]
0000796da41cef0b  mov r12, [r15+0xA0]
0000796da41cef12  mov r11, [r15+0x98]
0000796da41cef19  mov [r13+rax*1], r12
0000796da41cef1e  lea rax, [r14+0x148]
0000796da41cef25  mov [r13+rax*1], r11
0000796da41cef2a  cmp dword ptr [r15+0x318], 0x00
0000796da41cef32  jz 0x0000796DA41CEFD0
0000796da41cef38  nop [rax+rax*1], ax
0000796da41cef41  nop [rax+rax*1], eax
0000796da41cef49  mov eax, 0x410770
0000796da41cef4e  mov [r15+0x100], rax
0000796da41cef55  jmp 0x0000796DA3FFE110
0000796da41cef5a  int3
0000796da41cef5b  call 0x0000796DA40C0370
0000796da41cef60  jmp 0x0000796DA41CEE51
0000796da41cef65  call 0x0000796DA400BC20
0000796da41cef6a  jmp 0x0000796DA41CEE86
0000796da41cef6f  call 0x0000796DA400A9A0
0000796da41cef74  jmp 0x0000796DA41CEE92
0000796da41cef79  call 0x0000796DA400BC20
0000796da41cef7e  jmp 0x0000796DA41CEEAC
0000796da41cef83  call 0x0000796DA400A9A0
0000796da41cef88  jmp 0x0000796DA41CEEB8
0000796da41cef8d  call 0x0000796DA400BC20
0000796da41cef92  jmp 0x0000796DA41CEED2
0000796da41cef97  call 0x0000796DA400A9A0
0000796da41cef9c  jmp 0x0000796DA41CEEDE
0000796da41cefa1  call 0x0000796DA400BC20
0000796da41cefa6  jmp 0x0000796DA41CEEF8
0000796da41cefab  call 0x0000796DA400A9A0
0000796da41cefb0  jmp 0x0000796DA41CEF04
0000796da41cefb5  call 0x0000796DA400BC20
0000796da41cefba  jmp 0x0000796DA41CEF1E
0000796da41cefbf  call 0x0000796DA400A9A0
0000796da41cefc4  jmp 0x0000796DA41CEF2A
0000796da41cefc9  int3
0000796da41cefca  nop [rax+rax*1], ax
0000796da41cefd0  mov rax, [r15+0x08]
0000796da41cefd4  movzx r14d, byte ptr [r13+rax*1]
0000796da41cefda  movzx r14d, r14b
0000796da41cefde  mov [rsp+0x10], r14d
0000796da41cefe3  mov r14d, r14d
0000796da41cefe6  mov [r15+0x58], r14
0000796da41cefea  lea r14, [rax+0x01]
0000796da41cefee  mov [r15+0x08], r14
0000796da41ceff2  mov rax, [r15+0x88]
0000796da41ceff9  lea r14, [rax+0x01]
0000796da41ceffd  mov r12, [r15]
0000796da41cf000  lea r11, [r12+0x68]
0000796da41cf005  mov [r13+r11*1], r14
0000796da41cf00a  lea r14, [r12+rax*1]
0000796da41cf00e  mov [r15+0x60], r14
0000796da41cf012  lea rax, [r14+0x28]
0000796da41cf016  mov r11d, [rsp+0x10]
0000796da41cf01b  movzx r14d, r11b
0000796da41cf01f  mov [r13+rax*1], r14b
0000796da41cf024  lea rax, [r12+0x68]
0000796da41cf029  mov r14, [r13+rax*1]
0000796da41cf02e  mov [r15+0x88], r14
0000796da41cf035  xor eax, eax
0000796da41cf037  mov r12d, 0x40
0000796da41cf03d  cmp r14, r12
0000796da41cf040  cmc
0000796da41cf041  lahf
0000796da41cf042  seto al
0000796da41cf045  mov [r15+0x108], eax
0000796da41cf04c  mov eax, [r15+0x108]
0000796da41cf053  sahf
0000796da41cf054  jnz 0x0000796DA41CF086
0000796da41cf056  cmp dword ptr [r15+0x318], 0x00
0000796da41cf05e  jz 0x0000796DA41CF170
0000796da41cf064  nop [rax+rax*1], ax
0000796da41cf06d  nop [rax+rax*1], eax
0000796da41cf075  mov eax, 0x410790
0000796da41cf07a  mov [r15+0x100], rax
0000796da41cf081  jmp 0x0000796DA3FFE110
0000796da41cf086  cmp dword ptr [r15+0x318], 0x00
0000796da41cf08e  jz 0x0000796DA41CF0E0
0000796da41cf094  nop [rax+rax*1], ax
0000796da41cf09d  nop [rax+rax*1], eax
0000796da41cf0a5  mov eax, 0x410768
0000796da41cf0aa  mov [r15+0x100], rax
0000796da41cf0b1  jmp 0x0000796DA3FFE110
0000796da41cf0b6  int3
0000796da41cf0b7  call 0x0000796DA400D860
0000796da41cf0bc  jmp 0x0000796DA41CEFDA
0000796da41cf0c1  call 0x0000796DA40B36E0
0000796da41cf0c6  jmp 0x0000796DA41CF00A
0000796da41cf0cb  call 0x0000796DA400DD60
0000796da41cf0d0  jmp 0x0000796DA41CF024
0000796da41cf0d5  call 0x0000796DA400DC20
0000796da41cf0da  jmp 0x0000796DA41CF02E
0000796da41cf0df  int3
0000796da41cf0e0  mov rax, [r15+0x10]
0000796da41cf0e4  lea r14, [rax-0x01]
0000796da41cf0e8  mov [r15+0x10], r14
0000796da41cf0ec  test r14, r14
0000796da41cf0ef  setz r14b
0000796da41cf0f3  movzx r14, r14b
0000796da41cf0f7  mov [rsp+0x414], r14b
0000796da41cf0ff  cmp byte ptr [rsp+0x414], 0x00
0000796da41cf107  jz 0x0000796DA41CF139
0000796da41cf109  cmp dword ptr [r15+0x318], 0x00
0000796da41cf111  jz 0x0000796DA41D0670
0000796da41cf117  nop [rax+rax*1], ax
0000796da41cf120  nop [rax+rax*1], eax
0000796da41cf128  mov eax, 0x410988
0000796da41cf12d  mov [r15+0x100], rax
0000796da41cf134  jmp 0x0000796DA3FFE110
0000796da41cf139  cmp dword ptr [r15+0x318], 0x00
0000796da41cf141  jz 0x0000796DA41CEFD0
0000796da41cf147  nop [rax+rax*1], ax
0000796da41cf150  nop [rax+rax*1], eax
0000796da41cf158  mov eax, 0x410770
0000796da41cf15d  mov [r15+0x100], rax
0000796da41cf164  jmp 0x0000796DA3FFE110
0000796da41cf169  int3
0000796da41cf16a  int3
0000796da41cf16b  nop [rax+rax*1], eax
0000796da41cf170  mov rax, [r15+0x40]
0000796da41cf174  movzx r14d, byte ptr [r13+rax*1]
0000796da41cf17a  movaps xmm1, [r15+0x110]
0000796da41cf182  pinsrb xmm1, r14d, 0x00
0000796da41cf189  lea r14, [rax+0x01]
0000796da41cf18d  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf193  movaps xmm15, [r15+0x120]
0000796da41cf19b  pinsrb xmm15, r12d, 0x00
0000796da41cf1a2  lea r14, [rax+0x02]
0000796da41cf1a6  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf1ac  movaps xmm14, [r15+0x130]
0000796da41cf1b4  pinsrb xmm14, r12d, 0x00
0000796da41cf1bb  lea r14, [rax+0x03]
0000796da41cf1bf  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf1c5  movaps xmm13, [r15+0x140]
0000796da41cf1cd  pinsrb xmm13, r12d, 0x00
0000796da41cf1d4  lea r14, [rax+0x04]
0000796da41cf1d8  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf1de  pinsrb xmm1, r12d, 0x01
0000796da41cf1e5  lea r14, [rax+0x05]
0000796da41cf1e9  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf1ef  pinsrb xmm15, r12d, 0x01
0000796da41cf1f6  lea r14, [rax+0x06]
0000796da41cf1fa  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf200  pinsrb xmm14, r12d, 0x01
0000796da41cf207  lea r14, [rax+0x07]
0000796da41cf20b  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf211  pinsrb xmm13, r12d, 0x01
0000796da41cf218  lea r14, [rax+0x08]
0000796da41cf21c  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf222  pinsrb xmm1, r12d, 0x02
0000796da41cf229  lea r14, [rax+0x09]
0000796da41cf22d  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf233  pinsrb xmm15, r12d, 0x02
0000796da41cf23a  lea r14, [rax+0x0A]
0000796da41cf23e  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf244  pinsrb xmm14, r12d, 0x02
0000796da41cf24b  lea r14, [rax+0x0B]
0000796da41cf24f  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf255  pinsrb xmm13, r12d, 0x02
0000796da41cf25c  lea r14, [rax+0x0C]
0000796da41cf260  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf266  pinsrb xmm1, r12d, 0x03
0000796da41cf26d  lea r14, [rax+0x0D]
0000796da41cf271  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf277  pinsrb xmm15, r12d, 0x03
0000796da41cf27e  lea r14, [rax+0x0E]
0000796da41cf282  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf288  pinsrb xmm14, r12d, 0x03
0000796da41cf28f  lea r14, [rax+0x0F]
0000796da41cf293  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf299  pinsrb xmm13, r12d, 0x03
0000796da41cf2a0  lea r14, [rax+0x10]
0000796da41cf2a4  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf2aa  pinsrb xmm1, r12d, 0x04
0000796da41cf2b1  lea r14, [rax+0x11]
0000796da41cf2b5  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf2bb  pinsrb xmm15, r12d, 0x04
0000796da41cf2c2  lea r14, [rax+0x12]
0000796da41cf2c6  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf2cc  pinsrb xmm14, r12d, 0x04
0000796da41cf2d3  lea r14, [rax+0x13]
0000796da41cf2d7  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf2dd  pinsrb xmm13, r12d, 0x04
0000796da41cf2e4  lea r14, [rax+0x14]
0000796da41cf2e8  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf2ee  pinsrb xmm1, r12d, 0x05
0000796da41cf2f5  lea r14, [rax+0x15]
0000796da41cf2f9  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf2ff  pinsrb xmm15, r12d, 0x05
0000796da41cf306  lea r14, [rax+0x16]
0000796da41cf30a  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf310  pinsrb xmm14, r12d, 0x05
0000796da41cf317  lea r14, [rax+0x17]
0000796da41cf31b  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf321  pinsrb xmm13, r12d, 0x05
0000796da41cf328  lea r14, [rax+0x18]
0000796da41cf32c  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf332  pinsrb xmm1, r12d, 0x06
0000796da41cf339  lea r14, [rax+0x19]
0000796da41cf33d  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf343  pinsrb xmm15, r12d, 0x06
0000796da41cf34a  lea r14, [rax+0x1A]
0000796da41cf34e  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf354  pinsrb xmm14, r12d, 0x06
0000796da41cf35b  lea r14, [rax+0x1B]
0000796da41cf35f  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf365  pinsrb xmm13, r12d, 0x06
0000796da41cf36c  lea r14, [rax+0x1C]
0000796da41cf370  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf376  pinsrb xmm1, r12d, 0x07
0000796da41cf37d  lea r14, [rax+0x1D]
0000796da41cf381  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf387  pinsrb xmm15, r12d, 0x07
0000796da41cf38e  lea r14, [rax+0x1E]
0000796da41cf392  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf398  pinsrb xmm14, r12d, 0x07
0000796da41cf39f  lea r14, [rax+0x1F]
0000796da41cf3a3  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf3a9  pinsrb xmm13, r12d, 0x07
0000796da41cf3b0  lea r14, [rax+0x20]
0000796da41cf3b4  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf3ba  pinsrb xmm1, r12d, 0x08
0000796da41cf3c1  lea r14, [rax+0x21]
0000796da41cf3c5  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf3cb  pinsrb xmm15, r12d, 0x08
0000796da41cf3d2  lea r14, [rax+0x22]
0000796da41cf3d6  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf3dc  pinsrb xmm14, r12d, 0x08
0000796da41cf3e3  lea r14, [rax+0x23]
0000796da41cf3e7  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf3ed  pinsrb xmm13, r12d, 0x08
0000796da41cf3f4  lea r14, [rax+0x24]
0000796da41cf3f8  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf3fe  pinsrb xmm1, r12d, 0x09
0000796da41cf405  lea r14, [rax+0x25]
0000796da41cf409  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf40f  pinsrb xmm15, r12d, 0x09
0000796da41cf416  lea r14, [rax+0x26]
0000796da41cf41a  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf420  pinsrb xmm14, r12d, 0x09
0000796da41cf427  lea r14, [rax+0x27]
0000796da41cf42b  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf431  pinsrb xmm13, r12d, 0x09
0000796da41cf438  lea r14, [rax+0x28]
0000796da41cf43c  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf442  pinsrb xmm1, r12d, 0x0A
0000796da41cf449  lea r14, [rax+0x29]
0000796da41cf44d  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf453  pinsrb xmm15, r12d, 0x0A
0000796da41cf45a  lea r14, [rax+0x2A]
0000796da41cf45e  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf464  pinsrb xmm14, r12d, 0x0A
0000796da41cf46b  lea r14, [rax+0x2B]
0000796da41cf46f  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf475  pinsrb xmm13, r12d, 0x0A
0000796da41cf47c  lea r14, [rax+0x2C]
0000796da41cf480  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf486  pinsrb xmm1, r12d, 0x0B
0000796da41cf48d  lea r14, [rax+0x2D]
0000796da41cf491  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf497  pinsrb xmm15, r12d, 0x0B
0000796da41cf49e  lea r14, [rax+0x2E]
0000796da41cf4a2  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf4a8  pinsrb xmm14, r12d, 0x0B
0000796da41cf4af  lea r14, [rax+0x2F]
0000796da41cf4b3  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf4b9  pinsrb xmm13, r12d, 0x0B
0000796da41cf4c0  lea r14, [rax+0x30]
0000796da41cf4c4  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf4ca  pinsrb xmm1, r12d, 0x0C
0000796da41cf4d1  lea r14, [rax+0x31]
0000796da41cf4d5  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf4db  pinsrb xmm15, r12d, 0x0C
0000796da41cf4e2  lea r14, [rax+0x32]
0000796da41cf4e6  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf4ec  pinsrb xmm14, r12d, 0x0C
0000796da41cf4f3  lea r14, [rax+0x33]
0000796da41cf4f7  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf4fd  pinsrb xmm13, r12d, 0x0C
0000796da41cf504  lea r14, [rax+0x34]
0000796da41cf508  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf50e  pinsrb xmm1, r12d, 0x0D
0000796da41cf515  lea r14, [rax+0x35]
0000796da41cf519  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf51f  pinsrb xmm15, r12d, 0x0D
0000796da41cf526  lea r14, [rax+0x36]
0000796da41cf52a  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf530  pinsrb xmm14, r12d, 0x0D
0000796da41cf537  lea r14, [rax+0x37]
0000796da41cf53b  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf541  pinsrb xmm13, r12d, 0x0D
0000796da41cf548  lea r14, [rax+0x38]
0000796da41cf54c  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf552  pinsrb xmm1, r12d, 0x0E
0000796da41cf559  lea r14, [rax+0x39]
0000796da41cf55d  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf563  pinsrb xmm15, r12d, 0x0E
0000796da41cf56a  lea r14, [rax+0x3A]
0000796da41cf56e  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf574  pinsrb xmm14, r12d, 0x0E
0000796da41cf57b  lea r14, [rax+0x3B]
0000796da41cf57f  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf585  pinsrb xmm13, r12d, 0x0E
0000796da41cf58c  lea r14, [rax+0x3C]
0000796da41cf590  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf596  pinsrb xmm1, r12d, 0x0F
0000796da41cf59d  movaps [r15+0x110], xmm1
0000796da41cf5a5  lea r14, [rax+0x3D]
0000796da41cf5a9  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf5af  pinsrb xmm15, r12d, 0x0F
0000796da41cf5b6  movaps [r15+0x120], xmm15
0000796da41cf5be  lea r14, [rax+0x3E]
0000796da41cf5c2  movzx r12d, byte ptr [r13+r14*1]
0000796da41cf5c8  pinsrb xmm14, r12d, 0x0F
0000796da41cf5cf  movaps [r15+0x130], xmm14
0000796da41cf5d7  lea r14, [rax+0x3F]
0000796da41cf5db  movzx eax, byte ptr [r13+r14*1]
0000796da41cf5e1  pinsrb xmm13, eax, 0x0F
0000796da41cf5e8  movaps [r15+0x140], xmm13
0000796da41cf5f0  movq xmm1, qword ptr [r15+0x120]
0000796da41cf5f9  pmovzxbw xmm1, xmm1
0000796da41cf5fe  psllw xmm1, 0x00
0000796da41cf603  movaps [r15+0x150], xmm1
0000796da41cf60b  movq xmm1, qword ptr [r15+0x130]
0000796da41cf614  pmovzxbw xmm1, xmm1
0000796da41cf619  psllw xmm1, 0x00
0000796da41cf61e  movaps [r15+0x160], xmm1
0000796da41cf626  movq xmm1, qword ptr [r15+0x110]
0000796da41cf62f  pmovzxbw xmm1, xmm1
0000796da41cf634  psllw xmm1, 0x00
0000796da41cf639  movaps [r15+0x170], xmm1
0000796da41cf641  movaps xmm15, [r15+0x110]
0000796da41cf649  pextrq rax, xmm15, 0x01
0000796da41cf650  movq xmm15, rax
0000796da41cf655  pmovzxbw xmm15, xmm15
0000796da41cf65b  psllw xmm15, 0x00
0000796da41cf661  movaps [r15+0x180], xmm15
0000796da41cf669  movaps xmm14, [r15+0x120]
0000796da41cf671  pextrq rax, xmm14, 0x01
0000796da41cf678  movq xmm14, rax
0000796da41cf67d  pmovzxbw xmm14, xmm14
0000796da41cf683  psllw xmm14, 0x00
0000796da41cf689  movaps [r15+0x210], xmm14
0000796da41cf691  movaps xmm13, [r15+0x130]
0000796da41cf699  pextrq rax, xmm13, 0x01
0000796da41cf6a0  movq xmm13, rax
0000796da41cf6a5  pmovzxbw xmm13, xmm13
0000796da41cf6ab  psllw xmm13, 0x00
0000796da41cf6b1  movaps [r15+0x220], xmm13
0000796da41cf6b9  movq xmm12, qword ptr [r15+0x140]
0000796da41cf6c2  pmovzxbw xmm12, xmm12
0000796da41cf6c8  psllw xmm12, 0x00
0000796da41cf6ce  movaps [r15+0x250], xmm12
0000796da41cf6d6  movaps xmm12, [r15+0x140]
0000796da41cf6de  pextrq rax, xmm12, 0x01
0000796da41cf6e5  movq xmm12, rax
0000796da41cf6ea  pmovzxbw xmm12, xmm12
0000796da41cf6f0  psllw xmm12, 0x00
0000796da41cf6f6  movaps [r15+0x110], xmm12
0000796da41cf6fe  movq xmm11, qword ptr [r15+0x150]
0000796da41cf707  pmovzxwd xmm11, xmm11
0000796da41cf70d  pslld xmm11, 0x10
0000796da41cf713  movq xmm10, qword ptr [r15+0x160]
0000796da41cf71c  pmovzxwd xmm10, xmm10
0000796da41cf722  pslld xmm10, 0x08
0000796da41cf728  pextrq rax, xmm1, 0x01
0000796da41cf72f  movq xmm1, rax
0000796da41cf734  pmovzxwd xmm1, xmm1
0000796da41cf739  pslld xmm1, 0x00
0000796da41cf73e  movaps [r15+0x260], xmm1
0000796da41cf746  pextrq rax, xmm15, 0x01
0000796da41cf74d  movq xmm15, rax
0000796da41cf752  pmovzxwd xmm15, xmm15
0000796da41cf758  pslld xmm15, 0x00
0000796da41cf75e  movaps [r15+0x270], xmm15
0000796da41cf766  movq xmm9, qword ptr [r15+0x170]
0000796da41cf76f  pmovzxwd xmm9, xmm9
0000796da41cf775  pslld xmm9, 0x00
0000796da41cf77b  pextrq rax, xmm14, 0x01
0000796da41cf782  movq xmm14, rax
0000796da41cf787  pmovzxwd xmm14, xmm14
0000796da41cf78d  pslld xmm14, 0x10
0000796da41cf793  movaps [r15+0x280], xmm14
0000796da41cf79b  movq xmm8, qword ptr [r15+0x180]
0000796da41cf7a4  pmovzxwd xmm8, xmm8
0000796da41cf7aa  pslld xmm8, 0x00
0000796da41cf7b0  movq xmm7, qword ptr [r15+0x210]
0000796da41cf7b9  pmovzxwd xmm7, xmm7
0000796da41cf7be  pslld xmm7, 0x10
0000796da41cf7c3  movaps xmm6, [r15+0x150]
0000796da41cf7cb  pextrq rax, xmm6, 0x01
0000796da41cf7d2  movq xmm6, rax
0000796da41cf7d7  pmovzxwd xmm6, xmm6
0000796da41cf7dc  pslld xmm6, 0x10
0000796da41cf7e1  por xmm11, xmm10
0000796da41cf7e6  movaps [r15+0x230], xmm11
0000796da41cf7ee  pextrq rax, xmm13, 0x01
0000796da41cf7f5  movq xmm13, rax
0000796da41cf7fa  pmovzxwd xmm13, xmm13
0000796da41cf800  pslld xmm13, 0x08
0000796da41cf806  movaps [r15+0x240], xmm13
0000796da41cf80e  movq xmm10, qword ptr [r15+0x220]
0000796da41cf817  pmovzxwd xmm10, xmm10
0000796da41cf81d  pslld xmm10, 0x08
0000796da41cf823  movaps xmm5, [r15+0x160]
0000796da41cf82b  pextrq rax, xmm5, 0x01
0000796da41cf832  movq xmm5, rax
0000796da41cf837  pmovzxwd xmm5, xmm5
0000796da41cf83c  pslld xmm5, 0x08
0000796da41cf841  pslld xmm9, 0x18
0000796da41cf847  pslld xmm15, 0x18
0000796da41cf84d  pslld xmm8, 0x18
0000796da41cf853  movq xmm4, qword ptr [r15+0x250]
0000796da41cf85c  pmovzxwd xmm4, xmm4
0000796da41cf861  pslld xmm4, 0x00
0000796da41cf866  por xmm14, xmm13
0000796da41cf86b  por xmm7, xmm10
0000796da41cf870  movaps [r15+0x210], xmm7
0000796da41cf878  pslld xmm1, 0x18
0000796da41cf87d  movaps [r15+0x220], xmm1
0000796da41cf885  por xmm6, xmm5
0000796da41cf889  por xmm11, xmm9
0000796da41cf88e  movaps [r15+0x160], xmm11
0000796da41cf896  pextrq rax, xmm12, 0x01
0000796da41cf89d  movq xmm13, rax
0000796da41cf8a2  pmovzxwd xmm13, xmm13
0000796da41cf8a8  pslld xmm13, 0x00
0000796da41cf8ae  movaps [r15+0x170], xmm13
0000796da41cf8b6  movq xmm12, qword ptr [r15+0x110]
0000796da41cf8bf  pmovzxwd xmm12, xmm12
0000796da41cf8c5  pslld xmm12, 0x00
0000796da41cf8cb  por xmm14, xmm15
0000796da41cf8d0  por xmm7, xmm8
0000796da41cf8d5  movaps xmm15, [r15+0x250]
0000796da41cf8dd  pextrq rax, xmm15, 0x01
0000796da41cf8e4  movq xmm15, rax
0000796da41cf8e9  pmovzxwd xmm15, xmm15
0000796da41cf8ef  pslld xmm15, 0x00
0000796da41cf8f5  movaps [r15+0x180], xmm15
0000796da41cf8fd  por xmm6, xmm1
0000796da41cf901  movaps [r15+0x150], xmm6
0000796da41cf909  por xmm11, xmm4
0000796da41cf90e  movaps [r15+0x140], xmm11
0000796da41cf916  por xmm7, xmm12
0000796da41cf91b  movaps [r15+0x110], xmm7
0000796da41cf923  por xmm14, xmm13
0000796da41cf928  movaps [r15+0x120], xmm14
0000796da41cf930  por xmm6, xmm15
0000796da41cf935  movaps [r15+0x130], xmm6
0000796da41cf93d  mov rax, [r15+0xF8]
0000796da41cf944  lea r14, [rax+0x20]
0000796da41cf948  movups [r13+r14*1], xmm7
0000796da41cf94e  lea r14, [rax+0x30]
0000796da41cf952  movups [r13+r14*1], xmm14
0000796da41cf958  movups [r13+rax*1], xmm11
0000796da41cf95e  lea r14, [rax+0x10]
0000796da41cf962  movups [r13+r14*1], xmm6
0000796da41cf968  mov r14d, [r13+rax*1]
0000796da41cf96d  mov rax, [r15+0x48]
0000796da41cf971  mov [r15+0x68], rax
0000796da41cf975  mov qword ptr [r15+0x58], 0x04
0000796da41cf97d  lea r12, [rax+0x04]
0000796da41cf981  mov r11d, [r13+r12*1]
0000796da41cf986  mov [rsp+0x10], r11d
0000796da41cf98b  mov r11d, r11d
0000796da41cf98e  mov [r15+0x70], r11
0000796da41cf992  lea r12, [rax+0x38]
0000796da41cf996  mov r11d, [r13+r12*1]
0000796da41cf99b  lea r12, [rax+0x24]
0000796da41cf99f  mov r10d, [r13+r12*1]
0000796da41cf9a4  mov [rsp+0x20], r10d
0000796da41cf9a9  mov r10d, r10d
0000796da41cf9ac  mov [r15+0x90], r10
0000796da41cf9b3  mov [rsp+0x30], rax
0000796da41cf9b8  xor eax, eax
0000796da41cf9ba  mov r12d, 0x04
0000796da41cf9c0  mov r10d, 0xC0
0000796da41cf9c6  cmp r12, r10
0000796da41cf9c9  cmc
0000796da41cf9ca  lahf
0000796da41cf9cb  seto al
0000796da41cf9ce  mov [r15+0x108], eax
0000796da41cf9d5  mov eax, [rsp+0x10]
0000796da41cf9d9  mov r12d, [rsp+0x10]
0000796da41cf9de  shrd eax, r12d, 0x07
0000796da41cf9e3  mov [rsp+0x10], r11d
0000796da41cf9e8  mov r10d, [rsp+0x10]
0000796da41cf9ed  shrd r11d, r10d, 0x11
0000796da41cf9f2  mov r9d, [rsp+0x20]
0000796da41cf9f7  lea r8d, [r9d+r14d*1]
0000796da41cf9fc  rorx r14d, r12d, 0x12
0000796da41cfa02  xor eax, r14d
0000796da41cfa05  rorx r14d, r10d, 0x13
0000796da41cfa0b  xor r11d, r14d
0000796da41cfa0e  mov [rsp+0x10], r11d
0000796da41cfa13  mov r11d, r11d
0000796da41cfa16  mov [r15+0x88], r11
0000796da41cfa1d  mov [rsp+0x20], r12d
0000796da41cfa22  shr r12d, 0x03
0000796da41cfa26  xor eax, r12d
0000796da41cfa29  mov [rsp+0x40], eax
0000796da41cfa2d  mov eax, eax
0000796da41cfa2f  mov [r15+0x80], rax
0000796da41cfa36  shr r10d, 0x0A
0000796da41cfa3a  mov eax, [rsp+0x10]
0000796da41cfa3e  xor eax, r10d
0000796da41cfa41  mov [rsp+0x10], eax
0000796da41cfa45  mov eax, eax
0000796da41cfa47  mov [r15+0x78], rax
0000796da41cfa4b  mov eax, [rsp+0x40]
0000796da41cfa4f  lea r14d, [r8d+eax*1]
0000796da41cfa54  mov eax, [rsp+0x10]
0000796da41cfa58  lea r12d, [r14d+eax*1]
0000796da41cfa5d  mov rax, [rsp+0x30]
0000796da41cfa62  lea r14, [rax+0x40]
0000796da41cfa66  mov [r13+r14*1], r12d
0000796da41cfa6b  mov eax, [rsp+0x20]
0000796da41cfa6f  mov eax, eax
0000796da41cfa71  mov [r15+0x60], rax
0000796da41cfa75  mov eax, [r15+0x108]
0000796da41cfa7c  sahf
0000796da41cfa7d  jnz 0x0000796DA41CFAAF
0000796da41cfa7f  cmp dword ptr [r15+0x318], 0x00
0000796da41cfa87  jz 0x0000796DA41CFF70
0000796da41cfa8d  nop [rax+rax*1], ax
0000796da41cfa96  nop [rax+rax*1], eax
0000796da41cfa9e  mov eax, 0x41088C
0000796da41cfaa3  mov [r15+0x100], rax
0000796da41cfaaa  jmp 0x0000796DA3FFE110
0000796da41cfaaf  cmp dword ptr [r15+0x318], 0x00
0000796da41cfab7  jz 0x0000796DA41CFDC0
0000796da41cfabd  nop [rax+rax*1], ax
0000796da41cfac6  nop [rax+rax*1], eax
0000796da41cface  mov eax, 0x410844
0000796da41cfad3  mov [r15+0x100], rax
0000796da41cfada  jmp 0x0000796DA3FFE110
0000796da41cfadf  int3
0000796da41cfae0  call 0x0000796DA400D860
0000796da41cfae5  jmp 0x0000796DA41CF17A
0000796da41cfaea  call 0x0000796DA40E2420
0000796da41cfaef  jmp 0x0000796DA41CF193
0000796da41cfaf4  call 0x0000796DA40E2420
0000796da41cfaf9  jmp 0x0000796DA41CF1AC
0000796da41cfafe  call 0x0000796DA40E2420
0000796da41cfb03  jmp 0x0000796DA41CF1C5
0000796da41cfb08  call 0x0000796DA40E2420
0000796da41cfb0d  jmp 0x0000796DA41CF1DE
0000796da41cfb12  call 0x0000796DA40E2420
0000796da41cfb17  jmp 0x0000796DA41CF1EF
0000796da41cfb1c  call 0x0000796DA40E2420
0000796da41cfb21  jmp 0x0000796DA41CF200
0000796da41cfb26  call 0x0000796DA40E2420
0000796da41cfb2b  jmp 0x0000796DA41CF211
0000796da41cfb30  call 0x0000796DA40E2420
0000796da41cfb35  jmp 0x0000796DA41CF222
0000796da41cfb3a  call 0x0000796DA40E2420
0000796da41cfb3f  jmp 0x0000796DA41CF233
0000796da41cfb44  call 0x0000796DA40E2420
0000796da41cfb49  jmp 0x0000796DA41CF244
0000796da41cfb4e  call 0x0000796DA40E2420
0000796da41cfb53  jmp 0x0000796DA41CF255
0000796da41cfb58  call 0x0000796DA40E2420
0000796da41cfb5d  jmp 0x0000796DA41CF266
0000796da41cfb62  call 0x0000796DA40E2420
0000796da41cfb67  jmp 0x0000796DA41CF277
0000796da41cfb6c  call 0x0000796DA40E2420
0000796da41cfb71  jmp 0x0000796DA41CF288
0000796da41cfb76  call 0x0000796DA40E2420
0000796da41cfb7b  jmp 0x0000796DA41CF299
0000796da41cfb80  call 0x0000796DA40E2420
0000796da41cfb85  jmp 0x0000796DA41CF2AA
0000796da41cfb8a  call 0x0000796DA40E2420
0000796da41cfb8f  jmp 0x0000796DA41CF2BB
0000796da41cfb94  call 0x0000796DA40E2420
0000796da41cfb99  jmp 0x0000796DA41CF2CC
0000796da41cfb9e  call 0x0000796DA40E2420
0000796da41cfba3  jmp 0x0000796DA41CF2DD
0000796da41cfba8  call 0x0000796DA40E2420
0000796da41cfbad  jmp 0x0000796DA41CF2EE
0000796da41cfbb2  call 0x0000796DA40E2420
0000796da41cfbb7  jmp 0x0000796DA41CF2FF
0000796da41cfbbc  call 0x0000796DA40E2420
0000796da41cfbc1  jmp 0x0000796DA41CF310
0000796da41cfbc6  call 0x0000796DA40E2420
0000796da41cfbcb  jmp 0x0000796DA41CF321
0000796da41cfbd0  call 0x0000796DA40E2420
0000796da41cfbd5  jmp 0x0000796DA41CF332
0000796da41cfbda  call 0x0000796DA40E2420
0000796da41cfbdf  jmp 0x0000796DA41CF343
0000796da41cfbe4  call 0x0000796DA40E2420
0000796da41cfbe9  jmp 0x0000796DA41CF354
0000796da41cfbee  call 0x0000796DA40E2420
0000796da41cfbf3  jmp 0x0000796DA41CF365
0000796da41cfbf8  call 0x0000796DA40E2420
0000796da41cfbfd  jmp 0x0000796DA41CF376
0000796da41cfc02  call 0x0000796DA40E2420
0000796da41cfc07  jmp 0x0000796DA41CF387
0000796da41cfc0c  call 0x0000796DA40E2420
0000796da41cfc11  jmp 0x0000796DA41CF398
0000796da41cfc16  call 0x0000796DA40E2420
0000796da41cfc1b  jmp 0x0000796DA41CF3A9
0000796da41cfc20  call 0x0000796DA40E2420
0000796da41cfc25  jmp 0x0000796DA41CF3BA
0000796da41cfc2a  call 0x0000796DA40E2420
0000796da41cfc2f  jmp 0x0000796DA41CF3CB
0000796da41cfc34  call 0x0000796DA40E2420
0000796da41cfc39  jmp 0x0000796DA41CF3DC
0000796da41cfc3e  call 0x0000796DA40E2420
0000796da41cfc43  jmp 0x0000796DA41CF3ED
0000796da41cfc48  call 0x0000796DA40E2420
0000796da41cfc4d  jmp 0x0000796DA41CF3FE
0000796da41cfc52  call 0x0000796DA40E2420
0000796da41cfc57  jmp 0x0000796DA41CF40F
0000796da41cfc5c  call 0x0000796DA40E2420
0000796da41cfc61  jmp 0x0000796DA41CF420
0000796da41cfc66  call 0x0000796DA40E2420
0000796da41cfc6b  jmp 0x0000796DA41CF431
0000796da41cfc70  call 0x0000796DA40E2420
0000796da41cfc75  jmp 0x0000796DA41CF442
0000796da41cfc7a  call 0x0000796DA40E2420
0000796da41cfc7f  jmp 0x0000796DA41CF453
0000796da41cfc84  call 0x0000796DA40E2420
0000796da41cfc89  jmp 0x0000796DA41CF464
0000796da41cfc8e  call 0x0000796DA40E2420
0000796da41cfc93  jmp 0x0000796DA41CF475
0000796da41cfc98  call 0x0000796DA40E2420
0000796da41cfc9d  jmp 0x0000796DA41CF486
0000796da41cfca2  call 0x0000796DA40E2420
0000796da41cfca7  jmp 0x0000796DA41CF497
0000796da41cfcac  call 0x0000796DA40E2420
0000796da41cfcb1  jmp 0x0000796DA41CF4A8
0000796da41cfcb6  call 0x0000796DA40E2420
0000796da41cfcbb  jmp 0x0000796DA41CF4B9
0000796da41cfcc0  call 0x0000796DA40E2420
0000796da41cfcc5  jmp 0x0000796DA41CF4CA
0000796da41cfcca  call 0x0000796DA40E2420
0000796da41cfccf  jmp 0x0000796DA41CF4DB
0000796da41cfcd4  call 0x0000796DA40E2420
0000796da41cfcd9  jmp 0x0000796DA41CF4EC
0000796da41cfcde  call 0x0000796DA40E2420
0000796da41cfce3  jmp 0x0000796DA41CF4FD
0000796da41cfce8  call 0x0000796DA40E2420
0000796da41cfced  jmp 0x0000796DA41CF50E
0000796da41cfcf2  call 0x0000796DA40E2420
0000796da41cfcf7  jmp 0x0000796DA41CF51F
0000796da41cfcfc  call 0x0000796DA40E2420
0000796da41cfd01  jmp 0x0000796DA41CF530
0000796da41cfd06  call 0x0000796DA40E2420
0000796da41cfd0b  jmp 0x0000796DA41CF541
0000796da41cfd10  call 0x0000796DA40E2420
0000796da41cfd15  jmp 0x0000796DA41CF552
0000796da41cfd1a  call 0x0000796DA40E2420
0000796da41cfd1f  jmp 0x0000796DA41CF563
0000796da41cfd24  call 0x0000796DA40E2420
0000796da41cfd29  jmp 0x0000796DA41CF574
0000796da41cfd2e  call 0x0000796DA40E2420
0000796da41cfd33  jmp 0x0000796DA41CF585
0000796da41cfd38  call 0x0000796DA40E2420
0000796da41cfd3d  jmp 0x0000796DA41CF596
0000796da41cfd42  call 0x0000796DA40E2420
0000796da41cfd47  jmp 0x0000796DA41CF5AF
0000796da41cfd4c  call 0x0000796DA40E2420
0000796da41cfd51  jmp 0x0000796DA41CF5C8
0000796da41cfd56  call 0x0000796DA40D5610
0000796da41cfd5b  jmp 0x0000796DA41CF5E1
0000796da41cfd60  call 0x0000796DA40DC580
0000796da41cfd65  jmp 0x0000796DA41CF94E
0000796da41cfd6a  call 0x0000796DA40E46C0
0000796da41cfd6f  jmp 0x0000796DA41CF958
0000796da41cfd74  call 0x0000796DA4009E90
0000796da41cfd79  jmp 0x0000796DA41CF95E
0000796da41cfd7e  call 0x0000796DA40DB310
0000796da41cfd83  jmp 0x0000796DA41CF968
0000796da41cfd88  call 0x0000796DA400DAE0
0000796da41cfd8d  jmp 0x0000796DA41CF96D
0000796da41cfd92  call 0x0000796DA40C0230
0000796da41cfd97  jmp 0x0000796DA41CF986
0000796da41cfd9c  call 0x0000796DA40C0230
0000796da41cfda1  jmp 0x0000796DA41CF99B
0000796da41cfda6  call 0x0000796DA40BEFC0
0000796da41cfdab  jmp 0x0000796DA41CF9A4
0000796da41cfdb0  call 0x0000796DA40E2BA0
0000796da41cfdb5  jmp 0x0000796DA41CFA6B
0000796da41cfdba  int3
0000796da41cfdbb  nop [rax+rax*1], eax
0000796da41cfdc0  mov rax, [r15+0x48]
0000796da41cfdc4  mov r14, [r15+0x58]
0000796da41cfdc8  lea r12, [rax+r14*1]
0000796da41cfdcc  mov [r15+0x68], r12
0000796da41cfdd0  lea rax, [r14+0x04]
0000796da41cfdd4  mov [r15+0x58], rax
0000796da41cfdd8  lea r14, [r12+0x04]
0000796da41cfddd  mov r11d, [r13+r14*1]
0000796da41cfde2  mov [rsp+0x10], r11d
0000796da41cfde7  mov r11d, r11d
0000796da41cfdea  mov [r15+0x70], r11
0000796da41cfdee  lea r14, [r12+0x38]
0000796da41cfdf3  mov r11d, [r13+r14*1]
0000796da41cfdf8  lea r14, [r12+0x24]
0000796da41cfdfd  mov r10d, [r13+r14*1]
0000796da41cfe02  mov [rsp+0x20], r10d
0000796da41cfe07  mov r10d, r10d
0000796da41cfe0a  mov [r15+0x90], r10
0000796da41cfe11  mov [rsp+0x30], rax
0000796da41cfe16  xor eax, eax
0000796da41cfe18  mov r14, [rsp+0x30]
0000796da41cfe1d  mov r10d, 0xC0
0000796da41cfe23  cmp r14, r10
0000796da41cfe26  cmc
0000796da41cfe27  lahf
0000796da41cfe28  seto al
0000796da41cfe2b  mov [r15+0x108], eax
0000796da41cfe32  mov eax, [rsp+0x10]
0000796da41cfe36  mov r14d, [rsp+0x10]
0000796da41cfe3b  shrd eax, r14d, 0x07
0000796da41cfe40  mov [rsp+0x10], r11d
0000796da41cfe45  mov r10d, [rsp+0x10]
0000796da41cfe4a  shrd r11d, r10d, 0x11
0000796da41cfe4f  mov r9d, [r15+0x60]
0000796da41cfe53  mov r8d, [rsp+0x20]
0000796da41cfe58  lea ebp, [r8d+r9d*1]
0000796da41cfe5d  rorx r9d, r14d, 0x12
0000796da41cfe63  xor eax, r9d
0000796da41cfe66  rorx r9d, r10d, 0x13
0000796da41cfe6c  xor r11d, r9d
0000796da41cfe6f  mov [rsp+0x10], r11d
0000796da41cfe74  mov r11d, r11d
0000796da41cfe77  mov [r15+0x88], r11
0000796da41cfe7e  mov [rsp+0x20], r14d
0000796da41cfe83  shr r14d, 0x03
0000796da41cfe87  xor eax, r14d
0000796da41cfe8a  mov [rsp+0x30], eax
0000796da41cfe8e  mov eax, eax
0000796da41cfe90  mov [r15+0x80], rax
0000796da41cfe97  shr r10d, 0x0A
0000796da41cfe9b  mov eax, [rsp+0x10]
0000796da41cfe9f  xor eax, r10d
0000796da41cfea2  mov [rsp+0x10], eax
0000796da41cfea6  mov eax, eax
0000796da41cfea8  mov [r15+0x78], rax
0000796da41cfeac  mov eax, [rsp+0x30]
0000796da41cfeb0  lea r14d, [ebp+eax*1]
0000796da41cfeb6  mov eax, [rsp+0x10]
0000796da41cfeba  lea r11d, [r14d+eax*1]
0000796da41cfebf  lea rax, [r12+0x40]
0000796da41cfec4  mov [r13+rax*1], r11d
0000796da41cfec9  mov eax, [rsp+0x20]
0000796da41cfecd  mov eax, eax
0000796da41cfecf  mov [r15+0x60], rax
0000796da41cfed3  mov eax, [r15+0x108]
0000796da41cfeda  sahf
0000796da41cfedb  jnz 0x0000796DA41CFF0D
0000796da41cfedd  cmp dword ptr [r15+0x318], 0x00
0000796da41cfee5  jz 0x0000796DA41CFF70
0000796da41cfeeb  nop [rax+rax*1], ax
0000796da41cfef4  nop [rax+rax*1], eax
0000796da41cfefc  mov eax, 0x41088C
0000796da41cff01  mov [r15+0x100], rax
0000796da41cff08  jmp 0x0000796DA3FFE110
0000796da41cff0d  cmp dword ptr [r15+0x318], 0x00
0000796da41cff15  jz 0x0000796DA41CFDC0
0000796da41cff1b  nop [rax+rax*1], ax
0000796da41cff24  nop [rax+rax*1], eax
0000796da41cff2c  mov eax, 0x410844
0000796da41cff31  mov [r15+0x100], rax
0000796da41cff38  jmp 0x0000796DA3FFE110
0000796da41cff3d  int3
0000796da41cff3e  call 0x0000796DA40E1430
0000796da41cff43  jmp 0x0000796DA41CFDE2
0000796da41cff48  call 0x0000796DA40E1430
0000796da41cff4d  jmp 0x0000796DA41CFDF8
0000796da41cff52  call 0x0000796DA40E01C0
0000796da41cff57  jmp 0x0000796DA41CFE02
0000796da41cff5c  call 0x0000796DA400A860
0000796da41cff61  jmp 0x0000796DA41CFEC9
0000796da41cff66  int3
0000796da41cff67  nop [rax+rax*1], ax
0000796da41cff70  mov rax, [r15]
0000796da41cff73  mov r14d, [r13+rax*1]
0000796da41cff78  lea r12, [rax+0x04]
0000796da41cff7c  mov r11d, [r13+r12*1]
0000796da41cff81  mov [rsp+0x10], r14d
0000796da41cff86  mov r14d, r14d
0000796da41cff89  mov [r15+0x78], r14
0000796da41cff8d  mov [rsp+0x20], r11d
0000796da41cff92  mov r11d, r11d
0000796da41cff95  mov [r15+0x80], r11
0000796da41cff9c  lea r14, [rax+0x08]
0000796da41cffa0  mov r12d, [r13+r14*1]
0000796da41cffa5  lea r14, [rax+0x0C]
0000796da41cffa9  mov r11d, [r13+r14*1]
0000796da41cffae  mov [rsp+0x30], r12d
0000796da41cffb3  mov r12d, r12d
0000796da41cffb6  mov [r15+0x70], r12
0000796da41cffba  mov [rsp+0x40], r11d
0000796da41cffbf  mov r11d, r11d
0000796da41cffc2  mov [r15+0x68], r11
0000796da41cffc6  lea r14, [rax+0x18]
0000796da41cffca  mov r12d, [r13+r14*1]
0000796da41cffcf  lea r14, [rax+0x1C]
0000796da41cffd3  mov r11d, [r13+r14*1]
0000796da41cffd8  mov [rsp+0x50], r12d
0000796da41cffdd  mov r12d, r12d
0000796da41cffe0  mov [r15+0x58], r12
0000796da41cffe4  mov [rsp+0x60], r11d
0000796da41cffe9  mov r11d, r11d
0000796da41cffec  mov [r15+0x60], r11
0000796da41cfff0  lea r14, [rax+0x10]
0000796da41cfff4  mov r12d, [r13+r14*1]
0000796da41cfff9  lea r14, [rax+0x14]
0000796da41cfffd  mov eax, [r13+r14*1]
0000796da41d0002  mov [rsp+0x70], r12d
0000796da41d0007  mov r12d, r12d
0000796da41d000a  mov [r15+0x18], r12
0000796da41d000e  mov [rsp+0x80], eax
0000796da41d0015  mov eax, eax
0000796da41d0017  mov [r15+0x90], rax
0000796da41d001e  mov eax, [rsp+0x70]
0000796da41d0022  mov eax, eax
0000796da41d0024  mov [r15+0x30], rax
0000796da41d0028  mov eax, [rsp+0x50]
0000796da41d002c  mov eax, eax
0000796da41d002e  mov [r15+0xA0], rax
0000796da41d0035  mov eax, [rsp+0x30]
0000796da41d0039  mov eax, eax
0000796da41d003b  mov [r15+0x28], rax
0000796da41d003f  mov eax, [rsp+0x20]
0000796da41d0043  mov eax, eax
0000796da41d0045  mov [r15+0x98], rax
0000796da41d004c  mov eax, [rsp+0x10]
0000796da41d0050  mov eax, eax
0000796da41d0052  mov [r15+0x38], rax
0000796da41d0056  mov eax, [rsp+0x70]
0000796da41d005a  mov r14d, [rsp+0x70]
0000796da41d005f  shrd eax, r14d, 0x06
0000796da41d0064  mov [rsp+0x70], r14d
0000796da41d0069  mov r12d, [rsp+0x80]
0000796da41d0071  and r14d, r12d
0000796da41d0074  mov r11d, [rsp+0x10]
0000796da41d0079  mov r10d, [rsp+0x10]
0000796da41d007e  shrd r11d, r10d, 0x02
0000796da41d0083  mov [rsp+0x10], r12d
0000796da41d0088  mov r12d, r12d
0000796da41d008b  mov [r15+0x20], r12
0000796da41d008f  mov r12, [r15+0x50]
0000796da41d0093  mov r9d, [r13+r12*1]
0000796da41d0098  mov r12d, [rsp+0x50]
0000796da41d009d  mov r8d, [rsp+0x70]
0000796da41d00a2  andn ebp, r8d, r12d
0000796da41d00a7  mov edi, [rsp+0x60]
0000796da41d00ab  lea esi, [r14d+edi*1]
0000796da41d00b0  rorx r14d, r8d, 0x0B
0000796da41d00b6  xor eax, r14d
0000796da41d00b9  rorx r14d, r10d, 0x0D
0000796da41d00bf  xor r11d, r14d
0000796da41d00c2  lea edi, [esi+ebp*1]
0000796da41d00c6  mov r14, [r15+0x48]
0000796da41d00ca  mov ebp, [r13+r14*1]
0000796da41d00cf  mov r14d, [rsp+0x30]
0000796da41d00d4  mov esi, [rsp+0x20]
0000796da41d00d8  and r14d, esi
0000796da41d00db  mov [rsp+0x20], r14d
0000796da41d00e0  mov r14d, r14d
0000796da41d00e3  mov [r15+0xD8], r14
0000796da41d00ea  lea r14d, [edi+r9d*1]
0000796da41d00ef  mov r9d, [rsp+0x30]
0000796da41d00f4  xor r9d, esi
0000796da41d00f7  rorx edi, r8d, 0x19
0000796da41d00fd  xor eax, edi
0000796da41d00ff  and r9d, r10d
0000796da41d0102  rorx edi, r10d, 0x16
0000796da41d0108  xor r11d, edi
0000796da41d010b  mov [rsp+0x30], r11d
0000796da41d0110  mov r11d, r11d
0000796da41d0113  mov [r15+0xD0], r11
0000796da41d011a  lea r11d, [r14d+ebp*1]
0000796da41d011f  mov r10d, [rsp+0x20]
0000796da41d0124  xor r9d, r10d
0000796da41d0127  lea r14d, [r11d+eax*1]
0000796da41d012c  mov qword ptr [r15+0x88], 0x04
0000796da41d0137  mov eax, [rsp+0x30]
0000796da41d013b  lea r11d, [r9d+eax*1]
0000796da41d0140  mov eax, [rsp+0x40]
0000796da41d0144  lea r10d, [r14d+eax*1]
0000796da41d0149  mov r10d, r10d
0000796da41d014c  mov [r15+0xB8], r10
0000796da41d0153  xor eax, eax
0000796da41d0155  mov r10d, 0x04
0000796da41d015b  mov r9d, 0x100
0000796da41d0161  cmp r10, r9
0000796da41d0164  cmc
0000796da41d0165  lahf
0000796da41d0166  seto al
0000796da41d0169  mov [r15+0x108], eax
0000796da41d0170  lea eax, [r11d+r14d*1]
0000796da41d0175  mov eax, eax
0000796da41d0177  mov [r15+0xA8], rax
0000796da41d017e  mov r12d, r12d
0000796da41d0181  mov [r15+0xB0], r12
0000796da41d0188  mov eax, [rsp+0x10]
0000796da41d018c  mov eax, eax
0000796da41d018e  mov [r15+0xC0], rax
0000796da41d0195  mov r8d, r8d
0000796da41d0198  mov [r15+0xC8], r8
0000796da41d019f  mov eax, [r15+0x108]
0000796da41d01a6  sahf
0000796da41d01a7  jnz 0x0000796DA41D01D9
0000796da41d01a9  cmp dword ptr [r15+0x318], 0x00
0000796da41d01b1  jz 0x0000796DA41D04A0
0000796da41d01b7  nop [rax+rax*1], ax
0000796da41d01c0  nop [rax+rax*1], eax
0000796da41d01c8  mov eax, 0x41094C
0000796da41d01cd  mov [r15+0x100], rax
0000796da41d01d4  jmp 0x0000796DA3FFE110
0000796da41d01d9  cmp dword ptr [r15+0x318], 0x00
0000796da41d01e1  jz 0x0000796DA41D0270
0000796da41d01e7  nop [rax+rax*1], ax
0000796da41d01f0  nop [rax+rax*1], eax
0000796da41d01f8  mov eax, 0x4108C0
0000796da41d01fd  mov [r15+0x100], rax
0000796da41d0204  jmp 0x0000796DA3FFE110
0000796da41d0209  int3
0000796da41d020a  call 0x0000796DA400DAE0
0000796da41d020f  jmp 0x0000796DA41CFF78
0000796da41d0214  call 0x0000796DA40C0230
0000796da41d0219  jmp 0x0000796DA41CFF81
0000796da41d021e  call 0x0000796DA40E26A0
0000796da41d0223  jmp 0x0000796DA41CFFA5
0000796da41d0228  call 0x0000796DA40E1430
0000796da41d022d  jmp 0x0000796DA41CFFAE
0000796da41d0232  call 0x0000796DA40E26A0
0000796da41d0237  jmp 0x0000796DA41CFFCF
0000796da41d023c  call 0x0000796DA40E1430
0000796da41d0241  jmp 0x0000796DA41CFFD8
0000796da41d0246  call 0x0000796DA40E26A0
0000796da41d024b  jmp 0x0000796DA41CFFF9
0000796da41d0250  call 0x0000796DA40D5890
0000796da41d0255  jmp 0x0000796DA41D0002
0000796da41d025a  call 0x0000796DA40BDD50
0000796da41d025f  jmp 0x0000796DA41D0098
0000796da41d0264  call 0x0000796DA40DA580
0000796da41d0269  jmp 0x0000796DA41D00CF
0000796da41d026e  int3
0000796da41d026f  nop
0000796da41d0270  mov eax, [r15+0xB8]
0000796da41d0277  mov [rsp+0x10], eax
0000796da41d027b  mov eax, eax
0000796da41d027d  mov [r15+0x30], rax
0000796da41d0281  mov eax, [r15+0xC0]
0000796da41d0288  mov [rsp+0x20], eax
0000796da41d028c  mov eax, eax
0000796da41d028e  mov [r15+0xA0], rax
0000796da41d0295  mov eax, [r15+0x28]
0000796da41d0299  mov r14d, [r15+0x98]
0000796da41d02a0  mov [rsp+0x30], r14d
0000796da41d02a5  mov r14d, r14d
0000796da41d02a8  mov [r15+0x28], r14
0000796da41d02ac  mov r14d, [r15+0x38]
0000796da41d02b0  mov [rsp+0x40], r14d
0000796da41d02b5  mov r14d, r14d
0000796da41d02b8  mov [r15+0x98], r14
0000796da41d02bf  mov r14d, [r15+0xA8]
0000796da41d02c6  mov [rsp+0x50], r14d
0000796da41d02cb  mov r14d, r14d
0000796da41d02ce  mov [r15+0x38], r14
0000796da41d02d2  mov r14d, [rsp+0x10]
0000796da41d02d7  mov r12d, [rsp+0x10]
0000796da41d02dc  shrd r14d, r12d, 0x06
0000796da41d02e1  mov r11d, [r15+0xC8]
0000796da41d02e8  mov [rsp+0x10], r12d
0000796da41d02ed  and r12d, r11d
0000796da41d02f0  mov r10d, [rsp+0x50]
0000796da41d02f5  mov r9d, [rsp+0x50]
0000796da41d02fa  shrd r10d, r9d, 0x02
0000796da41d02ff  mov [rsp+0x50], r11d
0000796da41d0304  mov r11d, r11d
0000796da41d0307  mov [r15+0x20], r11
0000796da41d030b  mov r11, [r15+0x88]
0000796da41d0312  mov r8, [r15+0x50]
0000796da41d0316  lea rbp, [r8+r11*1]
0000796da41d031a  mov r8d, [r13+rbp*1]
0000796da41d031f  mov ebp, [rsp+0x20]
0000796da41d0323  mov edi, [rsp+0x10]
0000796da41d0327  andn esi, edi, ebp
0000796da41d032c  mov edx, [r15+0xB0]
0000796da41d0333  lea ecx, [r12d+edx*1]
0000796da41d0338  rorx r12d, edi, 0x0B
0000796da41d033e  xor r14d, r12d
0000796da41d0341  rorx r12d, r9d, 0x0D
0000796da41d0347  xor r10d, r12d
0000796da41d034a  lea r12d, [ecx+esi*1]
0000796da41d034f  mov rsi, [r15+0x48]
0000796da41d0353  lea rdx, [rsi+r11*1]
0000796da41d0357  mov esi, [r13+rdx*1]
0000796da41d035c  mov edx, [rsp+0x30]
0000796da41d0360  mov ecx, [rsp+0x40]
0000796da41d0364  and edx, ecx
0000796da41d0366  mov [rsp+0x10], edx
0000796da41d036a  mov edx, edx
0000796da41d036c  mov [r15+0xD8], rdx
0000796da41d0373  lea edx, [r12d+r8d*1]
0000796da41d0378  mov r12d, [rsp+0x30]
0000796da41d037d  xor r12d, ecx
0000796da41d0380  rorx r8d, edi, 0x19
0000796da41d0386  xor r14d, r8d
0000796da41d0389  and r12d, r9d
0000796da41d038c  rorx r8d, r9d, 0x16
0000796da41d0392  xor r10d, r8d
0000796da41d0395  mov [rsp+0x20], r10d
0000796da41d039a  mov r10d, r10d
0000796da41d039d  mov [r15+0xD0], r10
0000796da41d03a4  lea r10d, [edx+esi*1]
0000796da41d03a9  mov r9d, [rsp+0x10]
0000796da41d03ae  xor r12d, r9d
0000796da41d03b1  lea r9d, [r10d+r14d*1]
0000796da41d03b6  lea r14, [r11+0x04]
0000796da41d03ba  mov [r15+0x88], r14
0000796da41d03c1  mov r11d, [rsp+0x20]
0000796da41d03c6  lea r10d, [r12d+r11d*1]
0000796da41d03cb  lea r11d, [r9d+eax*1]
0000796da41d03d0  mov r11d, r11d
0000796da41d03d3  mov [r15+0xB8], r11
0000796da41d03da  xor eax, eax
0000796da41d03dc  mov r12d, 0x100
0000796da41d03e2  cmp r14, r12
0000796da41d03e5  cmc
0000796da41d03e6  lahf
0000796da41d03e7  seto al
0000796da41d03ea  mov [r15+0x108], eax
0000796da41d03f1  lea eax, [r10d+r9d*1]
0000796da41d03f6  mov eax, eax
0000796da41d03f8  mov [r15+0xA8], rax
0000796da41d03ff  mov ebp, ebp
0000796da41d0401  mov [r15+0xB0], rbp
0000796da41d0408  mov eax, [rsp+0x50]
0000796da41d040c  mov eax, eax
0000796da41d040e  mov [r15+0xC0], rax
0000796da41d0415  mov edi, edi
0000796da41d0417  mov [r15+0xC8], rdi
0000796da41d041e  mov eax, [r15+0x108]
0000796da41d0425  sahf
0000796da41d0426  jnz 0x0000796DA41D0458
0000796da41d0428  cmp dword ptr [r15+0x318], 0x00
0000796da41d0430  jz 0x0000796DA41D04A0
0000796da41d0436  nop [rax+rax*1], ax
0000796da41d043f  nop [rax+rax*1], eax
0000796da41d0447  mov eax, 0x41094C
0000796da41d044c  mov [r15+0x100], rax
0000796da41d0453  jmp 0x0000796DA3FFE110
0000796da41d0458  cmp dword ptr [r15+0x318], 0x00
0000796da41d0460  jz 0x0000796DA41D0270
0000796da41d0466  nop [rax+rax*1], ax
0000796da41d046f  nop [rax+rax*1], eax
0000796da41d0477  mov eax, 0x4108C0
0000796da41d047c  mov [r15+0x100], rax
0000796da41d0483  jmp 0x0000796DA3FFE110
0000796da41d0488  int3
0000796da41d0489  call 0x0000796DA4049010
0000796da41d048e  jmp 0x0000796DA41D031F
0000796da41d0493  call 0x0000796DA4025930
0000796da41d0498  jmp 0x0000796DA41D035C
0000796da41d049d  int3
0000796da41d049e  nop
0000796da41d04a0  mov eax, [r15+0x98]
0000796da41d04a7  mov r14d, [r15+0x70]
0000796da41d04ab  lea r12d, [eax+r14d*1]
0000796da41d04b0  mov eax, [r15+0x28]
0000796da41d04b4  mov r14d, [r15+0x68]
0000796da41d04b8  lea r11d, [eax+r14d*1]
0000796da41d04bd  mov qword ptr [r15+0x88], 0x00
0000796da41d04c8  mov eax, [r15+0xA8]
0000796da41d04cf  mov r14d, [r15+0x78]
0000796da41d04d3  lea r10d, [eax+r14d*1]
0000796da41d04d8  mov [rsp+0x10], r10d
0000796da41d04dd  mov r10d, r10d
0000796da41d04e0  mov [r15+0x78], r10
0000796da41d04e4  mov eax, [r15+0x38]
0000796da41d04e8  mov r14d, [r15+0x80]
0000796da41d04ef  lea r10d, [eax+r14d*1]
0000796da41d04f4  mov [rsp+0x20], r10d
0000796da41d04f9  mov r10d, r10d
0000796da41d04fc  mov [r15+0x80], r10
0000796da41d0503  mov rax, [r15]
0000796da41d0506  lea r14, [rax+0x08]
0000796da41d050a  mov [r13+r14*1], r12d
0000796da41d050f  lea r14, [rax+0x0C]
0000796da41d0513  mov [r13+r14*1], r11d
0000796da41d0518  mov r14d, [r15+0xB8]
0000796da41d051f  mov r12d, [r15+0x18]
0000796da41d0523  lea r11d, [r14d+r12d*1]
0000796da41d0528  mov [rsp+0x30], r11d
0000796da41d052d  mov r11d, r11d
0000796da41d0530  mov [r15+0x68], r11
0000796da41d0534  mov r14d, [r15+0x30]
0000796da41d0538  mov r12d, [r15+0x90]
0000796da41d053f  lea r11d, [r14d+r12d*1]
0000796da41d0544  mov [rsp+0x40], r11d
0000796da41d0549  mov r11d, r11d
0000796da41d054c  mov [r15+0x70], r11
0000796da41d0550  mov r14d, [r15+0x20]
0000796da41d0554  mov r12d, [r15+0x58]
0000796da41d0558  lea r11d, [r14d+r12d*1]
0000796da41d055d  mov [rsp+0x50], r11d
0000796da41d0562  mov r11d, r11d
0000796da41d0565  mov [r15+0x58], r11
0000796da41d0569  mov r14d, [r15+0xA0]
0000796da41d0570  mov r12d, [r15+0x60]
0000796da41d0574  lea r11d, [r14d+r12d*1]
0000796da41d0579  mov [rsp+0x60], r11d
0000796da41d057e  mov r11d, r11d
0000796da41d0581  mov [r15+0x60], r11
0000796da41d0585  mov r14d, [rsp+0x10]
0000796da41d058a  mov [r13+rax*1], r14d
0000796da41d058f  lea r14, [rax+0x04]
0000796da41d0593  mov r12d, [rsp+0x20]
0000796da41d0598  mov [r13+r14*1], r12d
0000796da41d059d  lea r14, [rax+0x10]
0000796da41d05a1  mov r12d, [rsp+0x30]
0000796da41d05a6  mov [r13+r14*1], r12d
0000796da41d05ab  lea r14, [rax+0x14]
0000796da41d05af  mov r12d, [rsp+0x40]
0000796da41d05b4  mov [r13+r14*1], r12d
0000796da41d05b9  lea r14, [rax+0x18]
0000796da41d05bd  mov r12d, [rsp+0x50]
0000796da41d05c2  mov [r13+r14*1], r12d
0000796da41d05c7  lea r14, [rax+0x1C]
0000796da41d05cb  mov r12d, [rsp+0x60]
0000796da41d05d0  mov [r13+r14*1], r12d
0000796da41d05d5  lea r14, [rax+0x68]
0000796da41d05d9  xor eax, eax
0000796da41d05db  mov [r13+r14*1], rax
0000796da41d05e0  cmp dword ptr [r15+0x318], 0x00
0000796da41d05e8  jz 0x0000796DA41CF0E0
0000796da41d05ee  nop [rax+rax*1], ax
0000796da41d05f7  nop [rax+rax*1], eax
0000796da41d05ff  mov eax, 0x410768
0000796da41d0604  mov [r15+0x100], rax
0000796da41d060b  jmp 0x0000796DA3FFE110
0000796da41d0610  int3
0000796da41d0611  call 0x0000796DA40E2BA0
0000796da41d0616  jmp 0x0000796DA41D050F
0000796da41d061b  call 0x0000796DA40E1920
0000796da41d0620  jmp 0x0000796DA41D0518
0000796da41d0625  call 0x0000796DA400DFE0
0000796da41d062a  jmp 0x0000796DA41D058F
0000796da41d062f  call 0x0000796DA40E2BA0
0000796da41d0634  jmp 0x0000796DA41D059D
0000796da41d0639  call 0x0000796DA40E2BA0
0000796da41d063e  jmp 0x0000796DA41D05AB
0000796da41d0643  call 0x0000796DA40E2BA0
0000796da41d0648  jmp 0x0000796DA41D05B9
0000796da41d064d  call 0x0000796DA40E2BA0
0000796da41d0652  jmp 0x0000796DA41D05C7
0000796da41d0657  call 0x0000796DA40E2BA0
0000796da41d065c  jmp 0x0000796DA41D05D5
0000796da41d0661  call 0x0000796DA40D5EB0
0000796da41d0666  jmp 0x0000796DA41D05E0
0000796da41d066b  int3
0000796da41d066c  nop [rax], eax
0000796da41d0670  mov rax, [r15+0xF8]
0000796da41d0677  lea r14, [rax+0x140]
0000796da41d067e  mov r12, [r13+r14*1]
0000796da41d0683  lea r14, [rax+0x148]
0000796da41d068a  mov r11, [r13+r14*1]
0000796da41d068f  mov [r15+0xA0], r12
0000796da41d0696  mov [r15+0x98], r11
0000796da41d069d  lea r14, [rax+0x130]
0000796da41d06a4  mov r12, [r13+r14*1]
0000796da41d06a9  lea r14, [rax+0x138]
0000796da41d06b0  mov r11, [r13+r14*1]
0000796da41d06b5  mov [r15+0xB0], r12
0000796da41d06bc  mov [r15+0xA8], r11
0000796da41d06c3  lea r14, [rax+0x120]
0000796da41d06ca  mov r12, [r13+r14*1]
0000796da41d06cf  lea r14, [rax+0x128]
0000796da41d06d6  mov r11, [r13+r14*1]
0000796da41d06db  mov [r15+0xC0], r12
0000796da41d06e2  mov [r15+0xB8], r11
0000796da41d06e9  lea r14, [rax+0x110]
0000796da41d06f0  mov r12, [r13+r14*1]
0000796da41d06f5  lea r14, [rax+0x118]
0000796da41d06fc  mov r11, [r13+r14*1]
0000796da41d0701  mov [r15+0xD0], r12
0000796da41d0708  mov [r15+0xC8], r11
0000796da41d070f  lea r14, [rax+0x100]
0000796da41d0716  mov r12, [r13+r14*1]
0000796da41d071b  lea r14, [rax+0x108]
0000796da41d0722  mov r11, [r13+r14*1]
0000796da41d0727  mov [r15+0xE8], r12
0000796da41d072e  mov [r15+0xD8], r11
0000796da41d0735  lea r14, [rax+0x150]
0000796da41d073c  mov [r15+0xF8], r14
0000796da41d0743  mov rax, [r15+0xF0]
0000796da41d074a  mov [r15+0x100], rax
0000796da41d0751  jmp 0x0000796DA41CE5C0
0000796da41d0756  int3
0000796da41d0757  call 0x0000796DA40E27E0
0000796da41d075c  jmp 0x0000796DA41D0683
0000796da41d0761  call 0x0000796DA40E1570
0000796da41d0766  jmp 0x0000796DA41D068F
0000796da41d076b  call 0x0000796DA40E27E0
0000796da41d0770  jmp 0x0000796DA41D06A9
0000796da41d0775  call 0x0000796DA40E1570
0000796da41d077a  jmp 0x0000796DA41D06B5
0000796da41d077f  call 0x0000796DA40E27E0
0000796da41d0784  jmp 0x0000796DA41D06CF
0000796da41d0789  call 0x0000796DA40E1570
0000796da41d078e  jmp 0x0000796DA41D06DB
0000796da41d0793  call 0x0000796DA40E27E0
0000796da41d0798  jmp 0x0000796DA41D06F5
0000796da41d079d  call 0x0000796DA40E1570
0000796da41d07a2  jmp 0x0000796DA41D0701
0000796da41d07a7  call 0x0000796DA40E27E0
0000796da41d07ac  jmp 0x0000796DA41D071B
0000796da41d07b1  call 0x0000796DA40E1570
0000796da41d07b6  jmp 0x0000796DA41D0727
0000796da41d07bb  int3
0000796da41d07bc  nop [rax], eax
0000796da41d07c0  mov eax, [r15+0xA0]
0000796da41d07c7  mov [rsp+0x10], eax
0000796da41d07cb  xor eax, eax
0000796da41d07cd  mov r14d, [rsp+0x10]
0000796da41d07d2  sub r14d, 0x01
0000796da41d07d6  cmc
0000796da41d07d7  lahf
0000796da41d07d8  seto al
0000796da41d07db  mov [r15+0x108], eax
0000796da41d07e2  mov r14d, r14d
0000796da41d07e5  mov [r15+0xA0], r14
0000796da41d07ec  mov eax, [r15+0x108]
0000796da41d07f3  sahf
0000796da41d07f4  jnz 0x0000796DA41D0826
0000796da41d07f6  cmp dword ptr [r15+0x318], 0x00
0000796da41d07fe  jz 0x0000796DA41D0900
0000796da41d0804  nop [rax+rax*1], ax
0000796da41d080d  nop [rax+rax*1], eax
0000796da41d0815  mov eax, 0x41028C
0000796da41d081a  mov [r15+0x100], rax
0000796da41d0821  jmp 0x0000796DA3FFE110
0000796da41d0826  cmp dword ptr [r15+0x318], 0x00
0000796da41d082e  jz 0x0000796DA41D0860
0000796da41d0834  nop [rax+rax*1], ax
0000796da41d083d  nop [rax+rax*1], eax
0000796da41d0845  mov eax, 0x410274
0000796da41d084a  mov [r15+0x100], rax
0000796da41d0851  jmp 0x0000796DA3FFE110
0000796da41d0856  int3
0000796da41d0857  int3
0000796da41d0858  nop [rax+rax*1], eax
0000796da41d0860  mov rax, [r15+0xF8]
0000796da41d0867  lea r14, [rax+0x100]
0000796da41d086e  mov [r15], r14
0000796da41d0871  mov rax, [r15+0x98]
0000796da41d0878  mov [r15+0x08], rax
0000796da41d087c  mov qword ptr [r15+0x10], 0x12C
0000796da41d0884  mov qword ptr [r15+0xF0], 0x410284
0000796da41d088f  mov r14d, [r15+0x320]
0000796da41d0896  mov eax, 0x410284
0000796da41d089b  mov rcx, 0x796DA41D07C0
0000796da41d08a5  mov [r15+r14*8+0x328], rax
0000796da41d08ad  mov [r15+r14*8+0x368], rcx
0000796da41d08b5  add r14d, 0x01
0000796da41d08b9  and r14d, 0x07
0000796da41d08bd  mov [r15+0x320], r14d
0000796da41d08c4  cmp dword ptr [r15+0x318], 0x00
0000796da41d08cc  jz 0x0000796DA41CED70
0000796da41d08d2  nop [rax+rax*1], ax
0000796da41d08db  nop [rax+rax*1], eax
0000796da41d08e3  mov eax, 0x410728
0000796da41d08e8  mov [r15+0x100], rax
0000796da41d08ef  jmp 0x0000796DA3FFE110
0000796da41d08f4  int3
0000796da41d08f5  int3
0000796da41d08f6  nop [rax+rax*1], ax
0000796da41d08ff  nop
0000796da41d0900  mov rax, [r15+0xF8]
0000796da41d0907  lea r14, [rax+0x120]
0000796da41d090e  mov r12, [r13+r14*1]
0000796da41d0913  mov [r15+0x98], r12
0000796da41d091a  mov qword ptr [r15+0x40], 0x80
0000796da41d0922  lea r14, [rax+0x100]
0000796da41d0929  mov [r15], r14
0000796da41d092c  lea r14, [rax+0x17C]
0000796da41d0933  mov [r15+0x08], r14
0000796da41d0937  mov qword ptr [r15+0x10], 0x01
0000796da41d093f  lea r14, [rax+0x17C]
0000796da41d0946  mov eax, 0x80
0000796da41d094b  mov [r13+r14*1], al
0000796da41d0950  mov qword ptr [r15+0xF0], 0x4102A8
0000796da41d095b  mov r14d, [r15+0x320]
0000796da41d0962  mov eax, 0x4102A8
0000796da41d0967  mov rcx, 0x796DA41D09E0
0000796da41d0971  mov [r15+r14*8+0x328], rax
0000796da41d0979  mov [r15+r14*8+0x368], rcx
0000796da41d0981  add r14d, 0x01
0000796da41d0985  and r14d, 0x07
0000796da41d0989  mov [r15+0x320], r14d
0000796da41d0990  cmp dword ptr [r15+0x318], 0x00
0000796da41d0998  jz 0x0000796DA41CED70
0000796da41d099e  nop [rax+rax*1], ax
0000796da41d09a7  nop [rax+rax*1], eax
0000796da41d09af  mov eax, 0x410728
0000796da41d09b4  mov [r15+0x100], rax
0000796da41d09bb  jmp 0x0000796DA3FFE110
0000796da41d09c0  int3
0000796da41d09c1  call 0x0000796DA40E27E0
0000796da41d09c6  jmp 0x0000796DA41D0913
0000796da41d09cb  call 0x0000796DA40D5AF0
0000796da41d09d0  jmp 0x0000796DA41D0950
0000796da41d09d5  int3
0000796da41d09d6  nop [rax+rax*1], ax
0000796da41d09df  nop
0000796da41d09e0  mov rax, [r15+0xF8]
0000796da41d09e7  lea r14, [rax+0x168]
0000796da41d09ee  mov r12, [r13+r14*1]
0000796da41d09f3  mov [r15+0x40], r12
0000796da41d09f7  lea r14, [rax+0x178]
0000796da41d09fe  xor eax, eax
0000796da41d0a00  mov [r13+r14*1], al
0000796da41d0a05  xor eax, eax
0000796da41d0a07  mov r14d, 0x38
0000796da41d0a0d  cmp r12, r14
0000796da41d0a10  cmc
0000796da41d0a11  lahf
0000796da41d0a12  seto al
0000796da41d0a15  mov [r15+0x108], eax
0000796da41d0a1c  mov eax, [r15+0x108]
0000796da41d0a23  sahf
0000796da41d0a24  jz 0x0000796DA41D0A56
0000796da41d0a26  cmp dword ptr [r15+0x318], 0x00
0000796da41d0a2e  jz 0x0000796DA41D0AA0
0000796da41d0a34  nop [rax+rax*1], ax
0000796da41d0a3d  nop [rax+rax*1], eax
0000796da41d0a45  mov eax, 0x4102B8
0000796da41d0a4a  mov [r15+0x100], rax
0000796da41d0a51  jmp 0x0000796DA3FFE110
0000796da41d0a56  cmp dword ptr [r15+0x318], 0x00
0000796da41d0a5e  jz 0x0000796DA41D0BF0
0000796da41d0a64  nop [rax+rax*1], ax
0000796da41d0a6d  nop [rax+rax*1], eax
0000796da41d0a75  mov eax, 0x4102D4
0000796da41d0a7a  mov [r15+0x100], rax
0000796da41d0a81  jmp 0x0000796DA3FFE110
0000796da41d0a86  int3
0000796da41d0a87  call 0x0000796DA40E27E0
0000796da41d0a8c  jmp 0x0000796DA41D09F3
0000796da41d0a91  call 0x0000796DA40D5AF0
0000796da41d0a96  jmp 0x0000796DA41D0A05
0000796da41d0a9b  int3
0000796da41d0a9c  nop [rax], eax
0000796da41d0aa0  mov rax, [r15+0xF8]
0000796da41d0aa7  lea r14, [rax+0x100]
0000796da41d0aae  mov [r15], r14
0000796da41d0ab1  lea r14, [rax+0x178]
0000796da41d0ab8  mov [r15+0x08], r14
0000796da41d0abc  mov qword ptr [r15+0x10], 0x01
0000796da41d0ac4  mov qword ptr [r15+0xF0], 0x4102C8
0000796da41d0acf  mov r14d, [r15+0x320]
0000796da41d0ad6  mov eax, 0x4102C8
0000796da41d0adb  mov rcx, 0x796DA41D0B40
0000796da41d0ae5  mov [r15+r14*8+0x328], rax
0000796da41d0aed  mov [r15+r14*8+0x368], rcx
0000796da41d0af5  add r14d, 0x01
0000796da41d0af9  and r14d, 0x07
0000796da41d0afd  mov [r15+0x320], r14d
0000796da41d0b04  cmp dword ptr [r15+0x318], 0x00
0000796da41d0b0c  jz 0x0000796DA41CED70
0000796da41d0b12  nop [rax+rax*1], ax
0000796da41d0b1b  nop [rax+rax*1], eax
0000796da41d0b23  mov eax, 0x410728
0000796da41d0b28  mov [r15+0x100], rax
0000796da41d0b2f  jmp 0x0000796DA3FFE110
0000796da41d0b34  int3
0000796da41d0b35  int3
0000796da41d0b36  nop [rax+rax*1], ax
0000796da41d0b3f  nop
0000796da41d0b40  mov rax, [r15+0xF8]
0000796da41d0b47  lea r14, [rax+0x168]
0000796da41d0b4e  mov rax, [r13+r14*1]
0000796da41d0b53  mov [r15+0x40], rax
0000796da41d0b57  mov [rsp+0x10], rax
0000796da41d0b5c  xor eax, eax
0000796da41d0b5e  mov r14, [rsp+0x10]
0000796da41d0b63  mov r12d, 0x38
0000796da41d0b69  cmp r14, r12
0000796da41d0b6c  cmc
0000796da41d0b6d  lahf
0000796da41d0b6e  seto al
0000796da41d0b71  mov [r15+0x108], eax
0000796da41d0b78  mov eax, [r15+0x108]
0000796da41d0b7f  sahf
0000796da41d0b80  jnz 0x0000796DA41D0BB2
0000796da41d0b82  cmp dword ptr [r15+0x318], 0x00
0000796da41d0b8a  jz 0x0000796DA41D0BF0
0000796da41d0b90  nop [rax+rax*1], ax
0000796da41d0b99  nop [rax+rax*1], eax
0000796da41d0ba1  mov eax, 0x4102D4
0000796da41d0ba6  mov [r15+0x100], rax
0000796da41d0bad  jmp 0x0000796DA3FFE110
0000796da41d0bb2  cmp dword ptr [r15+0x318], 0x00
0000796da41d0bba  jz 0x0000796DA41D0AA0
0000796da41d0bc0  nop [rax+rax*1], ax
0000796da41d0bc9  nop [rax+rax*1], eax
0000796da41d0bd1  mov eax, 0x4102B8
0000796da41d0bd6  mov [r15+0x100], rax
0000796da41d0bdd  jmp 0x0000796DA3FFE110
0000796da41d0be2  int3
0000796da41d0be3  call 0x0000796DA40D59C0
0000796da41d0be8  jmp 0x0000796DA41D0B53
0000796da41d0bed  int3
0000796da41d0bee  nop
0000796da41d0bf0  mov rax, [r15+0x98]
0000796da41d0bf7  rorx r14, rax, 0x3D
0000796da41d0bfd  and r14, 0xFFFFFFFFFFFFFFF8
0000796da41d0c01  mov rax, [r15+0xF8]
0000796da41d0c08  lea r12, [rax+0x100]
0000796da41d0c0f  mov [r15], r12
0000796da41d0c12  lea r12, [rax+0x170]
0000796da41d0c19  mov [r15+0x08], r12
0000796da41d0c1d  mov qword ptr [r15+0x10], 0x08
0000796da41d0c25  bswap r14
0000796da41d0c28  mov [r15+0x40], r14
0000796da41d0c2c  lea r12, [rax+0x170]
0000796da41d0c33  mov [r13+r12*1], r14
0000796da41d0c38  mov qword ptr [r15+0xF0], 0x4102F0
0000796da41d0c43  mov r14d, [r15+0x320]
0000796da41d0c4a  mov eax, 0x4102F0
0000796da41d0c4f  mov rcx, 0x796DA41D0CC0
0000796da41d0c59  mov [r15+r14*8+0x328], rax
0000796da41d0c61  mov [r15+r14*8+0x368], rcx
0000796da41d0c69  add r14d, 0x01
0000796da41d0c6d  and r14d, 0x07
0000796da41d0c71  mov [r15+0x320], r14d
0000796da41d0c78  cmp dword ptr [r15+0x318], 0x00
0000796da41d0c80  jz 0x0000796DA41CED70
0000796da41d0c86  nop [rax+rax*1], ax
0000796da41d0c8f  nop [rax+rax*1], eax
0000796da41d0c97  mov eax, 0x410728
0000796da41d0c9c  mov [r15+0x100], rax
0000796da41d0ca3  jmp 0x0000796DA3FFE110
0000796da41d0ca8  int3
0000796da41d0ca9  call 0x0000796DA40C3FE0
0000796da41d0cae  jmp 0x0000796DA41D0C38
0000796da41d0cb3  int3
0000796da41d0cb4  nop [rax+rax*1], ax
0000796da41d0cbd  nop [rax], eax
0000796da41d0cc0  mov rax, [r15+0xF8]
0000796da41d0cc7  lea r14, [rax+0x100]
0000796da41d0cce  mov r12d, [r13+r14*1]
0000796da41d0cd3  lea r14, [rax+0x104]
0000796da41d0cda  mov r11d, [r13+r14*1]
0000796da41d0cdf  mov qword ptr [r15+0x48], 0x430C90
0000796da41d0ce7  lea r14, [rax+0x108]
0000796da41d0cee  mov r10d, [r13+r14*1]
0000796da41d0cf3  lea r14, [rax+0x10C]
0000796da41d0cfa  mov r9d, [r13+r14*1]
0000796da41d0cff  bswap r12d
0000796da41d0d02  bswap r11d
0000796da41d0d05  mov qword ptr [r15+0xA0], 0x00
0000796da41d0d10  mov r14d, 0x430C90
0000796da41d0d16  mov [r13+r14*1], r12d
0000796da41d0d1b  mov r14d, 0x430C94
0000796da41d0d21  mov [r13+r14*1], r11d
0000796da41d0d26  bswap r10d
0000796da41d0d29  lea r14, [rax+0x110]
0000796da41d0d30  mov r12d, [r13+r14*1]
0000796da41d0d35  bswap r9d
0000796da41d0d38  lea r14, [rax+0x114]
0000796da41d0d3f  mov r11d, [r13+r14*1]
0000796da41d0d44  mov qword ptr [r15+0x98], 0x430DFC
0000796da41d0d4f  mov r14d, 0x430C98
0000796da41d0d55  mov [r13+r14*1], r10d
0000796da41d0d5a  mov r14d, 0x430C9C
0000796da41d0d60  mov [r13+r14*1], r9d
0000796da41d0d65  bswap r12d
0000796da41d0d68  lea r14, [rax+0x118]
0000796da41d0d6f  mov r10d, [r13+r14*1]
0000796da41d0d74  bswap r11d
0000796da41d0d77  mov [rsp+0x10], r11d
0000796da41d0d7c  mov r11d, r11d
0000796da41d0d7f  mov [r15+0x58], r11
0000796da41d0d83  lea r14, [rax+0x11C]
0000796da41d0d8a  mov eax, [r13+r14*1]
0000796da41d0d8f  mov [rsp+0x20], eax
0000796da41d0d93  mov eax, eax
0000796da41d0d95  mov [r15+0x60], rax
0000796da41d0d99  mov eax, 0x430CA0
0000796da41d0d9e  mov [r13+rax*1], r12d
0000796da41d0da3  mov eax, 0x430CA4
0000796da41d0da8  mov r14d, [rsp+0x10]
0000796da41d0dad  mov [r13+rax*1], r14d
0000796da41d0db2  bswap r10d
0000796da41d0db5  mov [rsp+0x10], r10d
0000796da41d0dba  mov r10d, r10d
0000796da41d0dbd  mov [r15+0x40], r10
0000796da41d0dc1  mov eax, [rsp+0x20]
0000796da41d0dc5  bswap eax
0000796da41d0dc7  mov [rsp+0x20], eax
0000796da41d0dcb  mov eax, eax
0000796da41d0dcd  mov [r15+0x50], rax
0000796da41d0dd1  mov eax, 0x430CA8
0000796da41d0dd6  mov r14d, [rsp+0x10]
0000796da41d0ddb  mov [r13+rax*1], r14d
0000796da41d0de0  mov eax, 0x430CAC
0000796da41d0de5  mov r14d, [rsp+0x20]
0000796da41d0dea  mov [r13+rax*1], r14d
0000796da41d0def  mov eax, [r15+0xA0]
0000796da41d0df6  lea r14d, [eax+0x11]
0000796da41d0dfb  mov r14d, r14d
0000796da41d0dfe  mov [r15], r14
0000796da41d0e01  mov qword ptr [r15+0xF0], 0x41035C
0000796da41d0e0c  mov r14d, [r15+0x320]
0000796da41d0e13  mov eax, 0x41035C
0000796da41d0e18  mov rcx, 0x796DA41D0F90
0000796da41d0e22  mov [r15+r14*8+0x328], rax
0000796da41d0e2a  mov [r15+r14*8+0x368], rcx
0000796da41d0e32  add r14d, 0x01
0000796da41d0e36  and r14d, 0x07
0000796da41d0e3a  mov [r15+0x320], r14d
0000796da41d0e41  cmp dword ptr [r15+0x318], 0x00
0000796da41d0e49  jz 0x0000796DA41D0F20
0000796da41d0e4f  nop [rax+rax*1], ax
0000796da41d0e58  nop [rax+rax*1], eax
0000796da41d0e60  mov eax, 0x4109A4
0000796da41d0e65  mov [r15+0x100], rax
0000796da41d0e6c  jmp 0x0000796DA3FFE110
0000796da41d0e71  int3
0000796da41d0e72  call 0x0000796DA40E26A0
0000796da41d0e77  jmp 0x0000796DA41D0CD3
0000796da41d0e7c  call 0x0000796DA40E1430
0000796da41d0e81  jmp 0x0000796DA41D0CDF
0000796da41d0e86  call 0x0000796DA40E01C0
0000796da41d0e8b  jmp 0x0000796DA41D0CF3
0000796da41d0e90  call 0x0000796DA40DEF50
0000796da41d0e95  jmp 0x0000796DA41D0CFF
0000796da41d0e9a  call 0x0000796DA40E2BA0
0000796da41d0e9f  jmp 0x0000796DA41D0D1B
0000796da41d0ea4  call 0x0000796DA40E1920
0000796da41d0ea9  jmp 0x0000796DA41D0D26
0000796da41d0eae  call 0x0000796DA40E26A0
0000796da41d0eb3  jmp 0x0000796DA41D0D35
0000796da41d0eb8  call 0x0000796DA40E1430
0000796da41d0ebd  jmp 0x0000796DA41D0D44
0000796da41d0ec2  call 0x0000796DA40E06B0
0000796da41d0ec7  jmp 0x0000796DA41D0D5A
0000796da41d0ecc  call 0x0000796DA40DF440
0000796da41d0ed1  jmp 0x0000796DA41D0D65
0000796da41d0ed6  call 0x0000796DA40E01C0
0000796da41d0edb  jmp 0x0000796DA41D0D74
0000796da41d0ee0  call 0x0000796DA40D5890
0000796da41d0ee5  jmp 0x0000796DA41D0D8F
0000796da41d0eea  call 0x0000796DA400BAE0
0000796da41d0eef  jmp 0x0000796DA41D0DA3
0000796da41d0ef4  call 0x0000796DA400DFE0
0000796da41d0ef9  jmp 0x0000796DA41D0DB2
0000796da41d0efe  call 0x0000796DA400DFE0
0000796da41d0f03  jmp 0x0000796DA41D0DE0
0000796da41d0f08  call 0x0000796DA400DFE0
0000796da41d0f0d  jmp 0x0000796DA41D0DEF
0000796da41d0f12  int3
0000796da41d0f13  nop [rax+rax*1], ax
0000796da41d0f1c  nop [rax], eax
0000796da41d0f20  mov eax, [r15]
0000796da41d0f23  mov [rsp+0x10], eax
0000796da41d0f27  shr eax, 0x10
0000796da41d0f2a  mov r14d, [rsp+0x10]
0000796da41d0f2f  xor r14d, eax
0000796da41d0f32  imul r14d, r14d, 0x7FEB352D
0000796da41d0f39  mov eax, 0x846CA68B
0000796da41d0f3e  mov eax, eax
0000796da41d0f40  mov [r15+0x48], rax
0000796da41d0f44  mov [rsp+0x10], r14d
0000796da41d0f49  shr r14d, 0x0F
0000796da41d0f4d  mov eax, [rsp+0x10]
0000796da41d0f51  xor eax, r14d
0000796da41d0f54  imul eax, eax, 0x846CA68B
0000796da41d0f5a  mov [rsp+0x10], eax
0000796da41d0f5e  mov eax, eax
0000796da41d0f60  mov [r15+0x40], rax
0000796da41d0f64  mov eax, [rsp+0x10]
0000796da41d0f68  shr eax, 0x10
0000796da41d0f6b  mov r14d, [rsp+0x10]
0000796da41d0f70  xor r14d, eax
0000796da41d0f73  mov r14d, r14d
0000796da41d0f76  mov [r15], r14
0000796da41d0f79  mov rax, [r15+0xF0]
0000796da41d0f80  mov [r15+0x100], rax
0000796da41d0f87  jmp 0x0000796DA41CE5C0
0000796da41d0f8c  int3
0000796da41d0f8d  int3
0000796da41d0f8e  nop
0000796da41d0f90  mov rax, [r15+0xA0]
0000796da41d0f97  mov [rsp+0x10], rax
0000796da41d0f9c  shl rax, 0x02
0000796da41d0fa0  mov r14, [r15+0x98]
0000796da41d0fa7  lea r12, [r14+rax*1]
0000796da41d0fab  mov eax, [r15]
0000796da41d0fae  mov [r13+r12*1], eax
0000796da41d0fb3  mov rax, [rsp+0x10]
0000796da41d0fb8  lea r14, [rax+0x01]
0000796da41d0fbc  mov [r15+0xA0], r14
0000796da41d0fc3  xor eax, eax
0000796da41d0fc5  mov r12d, 0x400
0000796da41d0fcb  cmp r14, r12
0000796da41d0fce  cmc
0000796da41d0fcf  lahf
0000796da41d0fd0  seto al
0000796da41d0fd3  mov [r15+0x108], eax
0000796da41d0fda  mov eax, [r15+0x108]
0000796da41d0fe1  sahf
0000796da41d0fe2  jnz 0x0000796DA41D1014
0000796da41d0fe4  cmp dword ptr [r15+0x318], 0x00
0000796da41d0fec  jz 0x0000796DA41D10E0
0000796da41d0ff2  nop [rax+rax*1], ax
0000796da41d0ffb  nop [rax+rax*1], eax
0000796da41d1003  mov eax, 0x41036C
0000796da41d1008  mov [r15+0x100], rax
0000796da41d100f  jmp 0x0000796DA3FFE110
0000796da41d1014  cmp dword ptr [r15+0x318], 0x00
0000796da41d101c  jz 0x0000796DA41D1050
0000796da41d1022  nop [rax+rax*1], ax
0000796da41d102b  nop [rax+rax*1], eax
0000796da41d1033  mov eax, 0x410354
0000796da41d1038  mov [r15+0x100], rax
0000796da41d103f  jmp 0x0000796DA3FFE110
0000796da41d1044  int3
0000796da41d1045  call 0x0000796DA40B4B70
0000796da41d104a  jmp 0x0000796DA41D0FB3
0000796da41d104f  int3
0000796da41d1050  mov eax, [r15+0xA0]
0000796da41d1057  lea r14d, [eax+0x11]
0000796da41d105c  mov r14d, r14d
0000796da41d105f  mov [r15], r14
0000796da41d1062  mov qword ptr [r15+0xF0], 0x41035C
0000796da41d106d  mov r14d, [r15+0x320]
0000796da41d1074  mov eax, 0x41035C
0000796da41d1079  mov rcx, 0x796DA41D0F90
0000796da41d1083  mov [r15+r14*8+0x328], rax
0000796da41d108b  mov [r15+r14*8+0x368], rcx
0000796da41d1093  add r14d, 0x01
0000796da41d1097  and r14d, 0x07
0000796da41d109b  mov [r15+0x320], r14d
0000796da41d10a2  cmp dword ptr [r15+0x318], 0x00
0000796da41d10aa  jz 0x0000796DA41D0F20
0000796da41d10b0  nop [rax+rax*1], ax
0000796da41d10b9  nop [rax+rax*1], eax
0000796da41d10c1  mov eax, 0x4109A4
0000796da41d10c6  mov [r15+0x100], rax
0000796da41d10cd  jmp 0x0000796DA3FFE110
0000796da41d10d2  int3
0000796da41d10d3  int3
0000796da41d10d4  nop [rax+rax*1], ax
0000796da41d10dd  nop [rax], eax
0000796da41d10e0  mov qword ptr [r15+0x40], 0x01
0000796da41d10e8  cmp dword ptr [r15+0x318], 0x00
0000796da41d10f0  jz 0x0000796DA41D1120
0000796da41d10f6  nop [rax+rax*1], ax
0000796da41d10ff  nop [rax+rax*1], eax
0000796da41d1107  mov eax, 0x410388
0000796da41d110c  mov [r15+0x100], rax
0000796da41d1113  jmp 0x0000796DA3FFE110
0000796da41d1118  int3
0000796da41d1119  int3
0000796da41d111a  nop [rax+rax*1], ax
0000796da41d1120  mov rax, [r15+0x40]
0000796da41d1124  mov [rsp+0x10], rax
0000796da41d1129  shl rax, 0x02
0000796da41d112d  mov r14, [r15+0x98]
0000796da41d1134  lea r12, [r14+rax*1]
0000796da41d1138  mov eax, [r13+r12*1]
0000796da41d113d  mov [rsp+0x20], eax
0000796da41d1141  mov eax, eax
0000796da41d1143  mov [r15+0x48], rax
0000796da41d1147  mov rax, [rsp+0x10]
0000796da41d114c  mov [r15+0x50], rax
0000796da41d1150  mov eax, [r15+0x50]
0000796da41d1154  lea r12d, [eax-0x01]
0000796da41d1159  mov r12d, r12d
0000796da41d115c  mov [r15+0x58], r12
0000796da41d1160  mov rax, [r15+0x58]
0000796da41d1164  mov r12d, eax
0000796da41d1167  mov r12d, r12d
0000796da41d116a  shl r12, 0x02
0000796da41d116e  lea rax, [r14+r12*1]
0000796da41d1172  mov r14d, [r13+rax*1]
0000796da41d1177  mov [rsp+0x10], r14d
0000796da41d117c  mov r14d, r14d
0000796da41d117f  mov [r15+0x60], r14
0000796da41d1183  xor eax, eax
0000796da41d1185  mov r14d, [rsp+0x10]
0000796da41d118a  mov r12d, [rsp+0x20]
0000796da41d118f  cmp r14d, r12d
0000796da41d1192  cmc
0000796da41d1193  lahf
0000796da41d1194  seto al
0000796da41d1197  mov [r15+0x108], eax
0000796da41d119e  mov eax, [r15+0x108]
0000796da41d11a5  sahf
0000796da41d11a6  cmc
0000796da41d11a7  jbe 0x0000796DA41D11D9
0000796da41d11a9  cmp dword ptr [r15+0x318], 0x00
0000796da41d11b1  jz 0x0000796DA41D1220
0000796da41d11b7  nop [rax+rax*1], ax
0000796da41d11c0  nop [rax+rax*1], eax
0000796da41d11c8  mov eax, 0x4103A0
0000796da41d11cd  mov [r15+0x100], rax
0000796da41d11d4  jmp 0x0000796DA3FFE110
0000796da41d11d9  cmp dword ptr [r15+0x318], 0x00
0000796da41d11e1  jz 0x0000796DA41D14C0
0000796da41d11e7  nop [rax+rax*1], ax
0000796da41d11f0  nop [rax+rax*1], eax
0000796da41d11f8  mov eax, 0x410378
0000796da41d11fd  mov [r15+0x100], rax
0000796da41d1204  jmp 0x0000796DA3FFE110
0000796da41d1209  int3
0000796da41d120a  call 0x0000796DA40B4690
0000796da41d120f  jmp 0x0000796DA41D113D
0000796da41d1214  call 0x0000796DA400DAE0
0000796da41d1219  jmp 0x0000796DA41D1177
0000796da41d121e  int3
0000796da41d121f  nop
0000796da41d1220  mov rax, [r15+0x50]
0000796da41d1224  mov [rsp+0x10], rax
0000796da41d1229  shl rax, 0x02
0000796da41d122d  mov r14, [r15+0x98]
0000796da41d1234  lea r12, [r14+rax*1]
0000796da41d1238  mov eax, [r15+0x60]
0000796da41d123c  mov [r13+r12*1], eax
0000796da41d1241  mov rax, [rsp+0x10]
0000796da41d1246  lea r14, [rax-0x01]
0000796da41d124a  mov [r15+0x50], r14
0000796da41d124e  mov rax, [r15+0x58]
0000796da41d1252  test rax, rax
0000796da41d1255  setz al
0000796da41d1258  movzx rax, al
0000796da41d125c  mov [rsp+0x414], al
0000796da41d1263  cmp byte ptr [rsp+0x414], 0x00
0000796da41d126b  jz 0x0000796DA41D129D
0000796da41d126d  cmp dword ptr [r15+0x318], 0x00
0000796da41d1275  jz 0x0000796DA41D12E0
0000796da41d127b  nop [rax+rax*1], ax
0000796da41d1284  nop [rax+rax*1], eax
0000796da41d128c  mov eax, 0x4103AC
0000796da41d1291  mov [r15+0x100], rax
0000796da41d1298  jmp 0x0000796DA3FFE110
0000796da41d129d  cmp dword ptr [r15+0x318], 0x00
0000796da41d12a5  jz 0x0000796DA41D13E0
0000796da41d12ab  nop [rax+rax*1], ax
0000796da41d12b4  nop [rax+rax*1], eax
0000796da41d12bc  mov eax, 0x410390
0000796da41d12c1  mov [r15+0x100], rax
0000796da41d12c8  jmp 0x0000796DA3FFE110
0000796da41d12cd  int3
0000796da41d12ce  call 0x0000796DA40B4B70
0000796da41d12d3  jmp 0x0000796DA41D1241
0000796da41d12d8  int3
0000796da41d12d9  nop [rax], eax
0000796da41d12e0  cmp dword ptr [r15+0x318], 0x00
0000796da41d12e8  jz 0x0000796DA41D1320
0000796da41d12ee  nop [rax+rax*1], ax
0000796da41d12f7  nop [rax+rax*1], eax
0000796da41d12ff  mov eax, 0x410374
0000796da41d1304  mov [r15+0x100], rax
0000796da41d130b  jmp 0x0000796DA3FFE110
0000796da41d1310  int3
0000796da41d1311  int3
0000796da41d1312  nop [rax+rax*1], ax
0000796da41d131b  nop [rax+rax*1], eax
0000796da41d1320  mov qword ptr [r15+0x50], 0x00
0000796da41d1328  mov rax, [r15+0x40]
0000796da41d132c  lea r14, [rax+0x01]
0000796da41d1330  mov [r15+0x40], r14
0000796da41d1334  mov rax, [r15+0x98]
0000796da41d133b  mov r12d, [r15+0x48]
0000796da41d133f  mov [r13+rax*1], r12d
0000796da41d1344  xor eax, eax
0000796da41d1346  mov r12d, 0x400
0000796da41d134c  cmp r14, r12
0000796da41d134f  cmc
0000796da41d1350  lahf
0000796da41d1351  seto al
0000796da41d1354  mov [r15+0x108], eax
0000796da41d135b  mov eax, [r15+0x108]
0000796da41d1362  sahf
0000796da41d1363  jz 0x0000796DA41D1395
0000796da41d1365  cmp dword ptr [r15+0x318], 0x00
0000796da41d136d  jz 0x0000796DA41D1120
0000796da41d1373  nop [rax+rax*1], ax
0000796da41d137c  nop [rax+rax*1], eax
0000796da41d1384  mov eax, 0x410388
0000796da41d1389  mov [r15+0x100], rax
0000796da41d1390  jmp 0x0000796DA3FFE110
0000796da41d1395  cmp dword ptr [r15+0x318], 0x00
0000796da41d139d  jz 0x0000796DA41D1580
0000796da41d13a3  nop [rax+rax*1], ax
0000796da41d13ac  nop [rax+rax*1], eax
0000796da41d13b4  mov eax, 0x4103B0
0000796da41d13b9  mov [r15+0x100], rax
0000796da41d13c0  jmp 0x0000796DA3FFE110
0000796da41d13c5  int3
0000796da41d13c6  call 0x0000796DA400BAE0
0000796da41d13cb  jmp 0x0000796DA41D1344
0000796da41d13d0  int3
0000796da41d13d1  nop [rax+rax*1], ax
0000796da41d13da  nop [rax+rax*1], ax
0000796da41d13e0  mov eax, [r15+0x50]
0000796da41d13e4  lea r14d, [eax-0x01]
0000796da41d13e9  mov r14d, r14d
0000796da41d13ec  mov [r15+0x58], r14
0000796da41d13f0  mov rax, [r15+0x58]
0000796da41d13f4  mov r14d, eax
0000796da41d13f7  mov r14d, r14d
0000796da41d13fa  shl r14, 0x02
0000796da41d13fe  mov rax, [r15+0x98]
0000796da41d1405  lea r12, [rax+r14*1]
0000796da41d1409  mov eax, [r13+r12*1]
0000796da41d140e  mov [rsp+0x10], eax
0000796da41d1412  mov eax, eax
0000796da41d1414  mov [r15+0x60], rax
0000796da41d1418  mov eax, [r15+0x48]
0000796da41d141c  mov [rsp+0x20], eax
0000796da41d1420  xor eax, eax
0000796da41d1422  mov r14d, [rsp+0x10]
0000796da41d1427  mov r12d, [rsp+0x20]
0000796da41d142c  cmp r14d, r12d
0000796da41d142f  cmc
0000796da41d1430  lahf
0000796da41d1431  seto al
0000796da41d1434  mov [r15+0x108], eax
0000796da41d143b  mov eax, [r15+0x108]
0000796da41d1442  sahf
0000796da41d1443  cmc
0000796da41d1444  jbe 0x0000796DA41D1476
0000796da41d1446  cmp dword ptr [r15+0x318], 0x00
0000796da41d144e  jz 0x0000796DA41D1220
0000796da41d1454  nop [rax+rax*1], ax
0000796da41d145d  nop [rax+rax*1], eax
0000796da41d1465  mov eax, 0x4103A0
0000796da41d146a  mov [r15+0x100], rax
0000796da41d1471  jmp 0x0000796DA3FFE110
0000796da41d1476  cmp dword ptr [r15+0x318], 0x00
0000796da41d147e  jz 0x0000796DA41D14C0
0000796da41d1484  nop [rax+rax*1], ax
0000796da41d148d  nop [rax+rax*1], eax
0000796da41d1495  mov eax, 0x410378
0000796da41d149a  mov [r15+0x100], rax
0000796da41d14a1  jmp 0x0000796DA3FFE110
0000796da41d14a6  int3
0000796da41d14a7  call 0x0000796DA40B4690
0000796da41d14ac  jmp 0x0000796DA41D140E
0000796da41d14b1  int3
0000796da41d14b2  nop [rax+rax*1], ax
0000796da41d14bb  nop [rax+rax*1], eax
0000796da41d14c0  mov rax, [r15+0x40]
0000796da41d14c4  lea r14, [rax+0x01]
0000796da41d14c8  mov [r15+0x40], r14
0000796da41d14cc  mov rax, [r15+0x50]
0000796da41d14d0  mov r12d, eax
0000796da41d14d3  mov r12d, r12d
0000796da41d14d6  shl r12, 0x02
0000796da41d14da  mov rax, [r15+0x98]
0000796da41d14e1  lea r11, [rax+r12*1]
0000796da41d14e5  mov eax, [r15+0x48]
0000796da41d14e9  mov [r13+r11*1], eax
0000796da41d14ee  xor eax, eax
0000796da41d14f0  mov r12d, 0x400
0000796da41d14f6  cmp r14, r12
0000796da41d14f9  cmc
0000796da41d14fa  lahf
0000796da41d14fb  seto al
0000796da41d14fe  mov [r15+0x108], eax
0000796da41d1505  mov eax, [r15+0x108]
0000796da41d150c  sahf
0000796da41d150d  jz 0x0000796DA41D153F
0000796da41d150f  cmp dword ptr [r15+0x318], 0x00
0000796da41d1517  jz 0x0000796DA41D1120
0000796da41d151d  nop [rax+rax*1], ax
0000796da41d1526  nop [rax+rax*1], eax
0000796da41d152e  mov eax, 0x410388
0000796da41d1533  mov [r15+0x100], rax
0000796da41d153a  jmp 0x0000796DA3FFE110
0000796da41d153f  cmp dword ptr [r15+0x318], 0x00
0000796da41d1547  jz 0x0000796DA41D1580
0000796da41d154d  nop [rax+rax*1], ax
0000796da41d1556  nop [rax+rax*1], eax
0000796da41d155e  mov eax, 0x4103B0
0000796da41d1563  mov [r15+0x100], rax
0000796da41d156a  jmp 0x0000796DA3FFE110
0000796da41d156f  int3
0000796da41d1570  call 0x0000796DA40A4270
0000796da41d1575  jmp 0x0000796DA41D14EE
0000796da41d157a  int3
0000796da41d157b  nop [rax+rax*1], eax
0000796da41d1580  mov qword ptr [r15+0x40], 0x430000
0000796da41d1588  mov eax, 0x430CB0
0000796da41d158d  mov r14, [r13+rax*1]
0000796da41d1592  mov rax, [r15+0x98]
0000796da41d1599  mov r12d, [r13+rax*1]
0000796da41d159e  lea r11, [rax+0x04]
0000796da41d15a2  mov eax, [r13+r11*1]
0000796da41d15a7  mov r12d, r12d
0000796da41d15aa  mov [r15+0x68], r12
0000796da41d15ae  mov eax, eax
0000796da41d15b0  mov [r15+0x60], rax
0000796da41d15b4  mov rax, [r15+0x68]
0000796da41d15b8  mov [r15+0x68], rax
0000796da41d15bc  mov qword ptr [r15+0x58], 0x02
0000796da41d15c4  mov [rsp+0x10], rax
0000796da41d15c9  xor eax, eax
0000796da41d15cb  mov r12d, 0x02
0000796da41d15d1  mov r11d, 0x400
0000796da41d15d7  cmp r12, r11
0000796da41d15da  cmc
0000796da41d15db  lahf
0000796da41d15dc  seto al
0000796da41d15df  mov [r15+0x108], eax
0000796da41d15e6  mov rax, [r15+0x60]
0000796da41d15ea  mov r12d, 0x02
0000796da41d15f0  imul rax, r12
0000796da41d15f4  mov [r15+0x50], rax
0000796da41d15f8  mov rax, [rsp+0x10]
0000796da41d15fd  lea r12, [rax+r14*1]
0000796da41d1601  mov [r15+0x48], r12
0000796da41d1605  mov eax, [r15+0x108]
0000796da41d160c  sahf
0000796da41d160d  jnz 0x0000796DA41D163F
0000796da41d160f  cmp dword ptr [r15+0x318], 0x00
0000796da41d1617  jz 0x0000796DA41D17B0
0000796da41d161d  nop [rax+rax*1], ax
0000796da41d1626  nop [rax+rax*1], eax
0000796da41d162e  mov eax, 0x4103E0
0000796da41d1633  mov [r15+0x100], rax
0000796da41d163a  jmp 0x0000796DA3FFE110
0000796da41d163f  cmp dword ptr [r15+0x318], 0x00
0000796da41d1647  jz 0x0000796DA41D1690
0000796da41d164d  nop [rax+rax*1], ax
0000796da41d1656  nop [rax+rax*1], eax
0000796da41d165e  mov eax, 0x4103C0
0000796da41d1663  mov [r15+0x100], rax
0000796da41d166a  jmp 0x0000796DA3FFE110
0000796da41d166f  int3
0000796da41d1670  call 0x0000796DA400DC20
0000796da41d1675  jmp 0x0000796DA41D1592
0000796da41d167a  call 0x0000796DA400B5E0
0000796da41d167f  jmp 0x0000796DA41D159E
0000796da41d1684  call 0x0000796DA40A3D90
0000796da41d1689  jmp 0x0000796DA41D15A7
0000796da41d168e  int3
0000796da41d168f  nop
0000796da41d1690  mov rax, [r15+0x98]
0000796da41d1697  mov r14, [r15+0x58]
0000796da41d169b  mov [rsp+0x10], r14
0000796da41d16a0  shl r14, 0x02
0000796da41d16a4  lea r12, [rax+r14*1]
0000796da41d16a8  mov eax, [r13+r12*1]
0000796da41d16ad  lea r14, [r12+0x04]
0000796da41d16b2  mov r12d, [r13+r14*1]
0000796da41d16b7  mov eax, eax
0000796da41d16b9  mov [r15+0x68], rax
0000796da41d16bd  mov r12d, r12d
0000796da41d16c0  mov [r15+0x60], r12
0000796da41d16c4  mov rax, [r15+0x68]
0000796da41d16c8  mov [rsp+0x20], rax
0000796da41d16cd  mov r14, [rsp+0x10]
0000796da41d16d2  imul rax, r14
0000796da41d16d6  mov r12, [rsp+0x20]
0000796da41d16db  lea r11, [r12+rax*1]
0000796da41d16df  mov [r15+0x68], r11
0000796da41d16e3  lea rax, [r14+0x02]
0000796da41d16e7  mov [r15+0x58], rax
0000796da41d16eb  mov [rsp+0x10], rax
0000796da41d16f0  xor eax, eax
0000796da41d16f2  mov r14, [rsp+0x10]
0000796da41d16f7  mov r12d, 0x400
0000796da41d16fd  cmp r14, r12
0000796da41d1700  cmc
0000796da41d1701  lahf
0000796da41d1702  seto al
0000796da41d1705  mov [r15+0x108], eax
0000796da41d170c  mov rax, [r15+0x50]
0000796da41d1710  mov r12, [r15+0x60]
0000796da41d1714  imul r14, r12
0000796da41d1718  lea r12, [rax+r14*1]
0000796da41d171c  mov [r15+0x50], r12
0000796da41d1720  mov rax, [r15+0x48]
0000796da41d1724  lea r14, [r11+rax*1]
0000796da41d1728  mov [r15+0x48], r14
0000796da41d172c  mov eax, [r15+0x108]
0000796da41d1733  sahf
0000796da41d1734  jnz 0x0000796DA41D1766
0000796da41d1736  cmp dword ptr [r15+0x318], 0x00
0000796da41d173e  jz 0x0000796DA41D17B0
0000796da41d1744  nop [rax+rax*1], ax
0000796da41d174d  nop [rax+rax*1], eax
0000796da41d1755  mov eax, 0x4103E0
0000796da41d175a  mov [r15+0x100], rax
0000796da41d1761  jmp 0x0000796DA3FFE110
0000796da41d1766  cmp dword ptr [r15+0x318], 0x00
0000796da41d176e  jz 0x0000796DA41D1690
0000796da41d1774  nop [rax+rax*1], ax
0000796da41d177d  nop [rax+rax*1], eax
0000796da41d1785  mov eax, 0x4103C0
0000796da41d178a  mov [r15+0x100], rax
0000796da41d1791  jmp 0x0000796DA3FFE110
0000796da41d1796  int3
0000796da41d1797  call 0x0000796DA40B4690
0000796da41d179c  jmp 0x0000796DA41D16AD
0000796da41d17a1  call 0x0000796DA40E26A0
0000796da41d17a6  jmp 0x0000796DA41D16B7
0000796da41d17ab  int3
0000796da41d17ac  nop [rax], eax
0000796da41d17b0  mov qword ptr [r15+0x98], 0x00
0000796da41d17bb  mov rax, [r15+0x50]
0000796da41d17bf  mov r14, [r15+0x48]
0000796da41d17c3  lea r12, [rax+r14*1]
0000796da41d17c7  mov [r15+0x48], r12
0000796da41d17cb  mov rax, [r15+0x40]
0000796da41d17cf  lea r14, [rax+0xCB0]
0000796da41d17d6  mov [r13+r14*1], r12
0000796da41d17db  mov qword ptr [r15], 0x01
0000796da41d17e2  mov qword ptr [r15+0xF0], 0x4103F8
0000796da41d17ed  mov r14d, [r15+0x320]
0000796da41d17f4  mov eax, 0x4103F8
0000796da41d17f9  mov rcx, 0x796DA41D1860
0000796da41d1803  mov [r15+r14*8+0x328], rax
0000796da41d180b  mov [r15+r14*8+0x368], rcx
0000796da41d1813  add r14d, 0x01
0000796da41d1817  and r14d, 0x07
0000796da41d181b  mov [r15+0x320], r14d
0000796da41d1822  cmp dword ptr [r15+0x318], 0x00
0000796da41d182a  jz 0x0000796DA41D0F20
0000796da41d1830  nop [rax+rax*1], ax
0000796da41d1839  nop [rax+rax*1], eax
0000796da41d1841  mov eax, 0x4109A4
0000796da41d1846  mov [r15+0x100], rax
0000796da41d184d  jmp 0x0000796DA3FFE110
0000796da41d1852  int3
0000796da41d1853  call 0x0000796DA40E2CE0
0000796da41d1858  jmp 0x0000796DA41D17DB
0000796da41d185d  int3
0000796da41d185e  nop
0000796da41d1860  mov eax, [r15+0x98]
0000796da41d1867  lea r14d, [eax+0x01]
0000796da41d186c  mov [rsp+0x10], r14d
0000796da41d1871  mov r14d, r14d
0000796da41d1874  mov [r15+0x98], r14
0000796da41d187b  xor eax, eax
0000796da41d187d  mov r14d, [rsp+0x10]
0000796da41d1882  cmp r14d, 0x10000
0000796da41d1889  cmc
0000796da41d188a  lahf
0000796da41d188b  seto al
0000796da41d188e  mov [r15+0x108], eax
0000796da41d1895  mov eax, [r15+0x108]
0000796da41d189c  sahf
0000796da41d189d  jnz 0x0000796DA41D18CF
0000796da41d189f  cmp dword ptr [r15+0x318], 0x00
0000796da41d18a7  jz 0x0000796DA41D19A0
0000796da41d18ad  nop [rax+rax*1], ax
0000796da41d18b6  nop [rax+rax*1], eax
0000796da41d18be  mov eax, 0x410404
0000796da41d18c3  mov [r15+0x100], rax
0000796da41d18ca  jmp 0x0000796DA3FFE110
0000796da41d18cf  cmp dword ptr [r15+0x318], 0x00
0000796da41d18d7  jz 0x0000796DA41D1910
0000796da41d18dd  nop [rax+rax*1], ax
0000796da41d18e6  nop [rax+rax*1], eax
0000796da41d18ee  mov eax, 0x4103F0
0000796da41d18f3  mov [r15+0x100], rax
0000796da41d18fa  jmp 0x0000796DA3FFE110
0000796da41d18ff  int3
0000796da41d1900  int3
0000796da41d1901  nop [rax+rax*1], ax
0000796da41d190a  nop [rax+rax*1], ax
0000796da41d1910  mov eax, [r15]
0000796da41d1913  mov r14d, [r15+0x98]
0000796da41d191a  lea r12d, [eax+r14d*1]
0000796da41d191f  mov r12d, r12d
0000796da41d1922  mov [r15], r12
0000796da41d1925  mov qword ptr [r15+0xF0], 0x4103F8
0000796da41d1930  mov r14d, [r15+0x320]
0000796da41d1937  mov eax, 0x4103F8
0000796da41d193c  mov rcx, 0x796DA41D1860
0000796da41d1946  mov [r15+r14*8+0x328], rax
0000796da41d194e  mov [r15+r14*8+0x368], rcx
0000796da41d1956  add r14d, 0x01
0000796da41d195a  and r14d, 0x07
0000796da41d195e  mov [r15+0x320], r14d
0000796da41d1965  cmp dword ptr [r15+0x318], 0x00
0000796da41d196d  jz 0x0000796DA41D0F20
0000796da41d1973  nop [rax+rax*1], ax
0000796da41d197c  nop [rax+rax*1], eax
0000796da41d1984  mov eax, 0x4109A4
0000796da41d1989  mov [r15+0x100], rax
0000796da41d1990  jmp 0x0000796DA3FFE110
0000796da41d1995  int3
0000796da41d1996  int3
0000796da41d1997  nop [rax+rax*1], ax
0000796da41d19a0  vmovaps xmm1, [0x0000796DA3DFE010]
0000796da41d19a8  movq xmm1, xmm1
0000796da41d19ac  movaps [r15+0x110], xmm1
0000796da41d19b4  mov eax, 0x420B10
0000796da41d19b9  mov r14, [r13+rax*1]
0000796da41d19be  movq xmm1, r14
0000796da41d19c3  movaps [r15+0x120], xmm1
0000796da41d19cb  vmovaps xmm1, [0x0000796DA3DFE020]
0000796da41d19d3  movq xmm1, xmm1
0000796da41d19d7  movaps [r15+0x140], xmm1
0000796da41d19df  vmovaps xmm1, [0x0000796DA3DFE030]
0000796da41d19e7  vpbroadcastq xmm1, xmm1
0000796da41d19ec  movaps [r15+0x150], xmm1
0000796da41d19f4  mov qword ptr [r15+0x40], 0x02
0000796da41d19fc  vmovaps xmm15, [0x0000796DA3DFE040]
0000796da41d1a04  movq xmm15, xmm15
0000796da41d1a09  movaps [r15+0x160], xmm15
0000796da41d1a11  vmovaps xmm15, [0x0000796DA3DFE050]
0000796da41d1a19  vpbroadcastq xmm15, xmm15
0000796da41d1a1e  movaps [r15+0x130], xmm15
0000796da41d1a26  mov rax, [r15+0x40]
0000796da41d1a2a  vmovq xmm14, rax
0000796da41d1a2f  vpbroadcastq xmm14, xmm14
0000796da41d1a34  movaps [r15+0x170], xmm14
0000796da41d1a3c  mov eax, 0x420A40
0000796da41d1a41  movups xmm13, [r13+rax*1]
0000796da41d1a47  mov qword ptr [r15+0x40], 0x431E00
0000796da41d1a4f  mov eax, [r15]
0000796da41d1a52  mov r14d, 0x430CB8
0000796da41d1a58  mov [r13+r14*1], eax
0000796da41d1a5d  mov qword ptr [r15+0x50], 0x432000
0000796da41d1a65  vpmovqd xmm12, xmm13
0000796da41d1a6b  pxor xmm11, xmm11
0000796da41d1a70  punpcklqdq xmm12, xmm11
0000796da41d1a75  movaps [r15+0x210], xmm12
0000796da41d1a7d  movq xmm12, qword ptr [r15+0x140]
0000796da41d1a86  movq xmm11, qword ptr [r15+0x120]
0000796da41d1a8f  psubd xmm12, xmm11
0000796da41d1a94  movq xmm12, xmm12
0000796da41d1a99  paddq xmm13, xmm14
0000796da41d1a9e  movaps [r15+0x180], xmm13
0000796da41d1aa6  movq xmm14, qword ptr [r15+0x160]
0000796da41d1aaf  paddd xmm11, xmm14
0000796da41d1ab4  movq xmm11, xmm11
0000796da41d1ab9  movq xmm11, xmm11
0000796da41d1abe  movaps [r15+0x120], xmm11
0000796da41d1ac6  pmovzxdq xmm12, xmm12
0000796da41d1acc  psllq xmm12, 0x00
0000796da41d1ad2  movq xmm14, qword ptr [r15+0x210]
0000796da41d1adb  movq xmm13, qword ptr [r15+0x110]
0000796da41d1ae4  paddd xmm14, xmm13
0000796da41d1ae9  movq xmm14, xmm14
0000796da41d1aee  vcvtuqq2pd xmm12, xmm12
0000796da41d1af4  pmovzxdq xmm14, xmm14
0000796da41d1afa  psllq xmm14, 0x00
0000796da41d1b00  vcvtuqq2pd xmm14, xmm14
0000796da41d1b06  movaps xmm13, xmm12
0000796da41d1b0a  mulpd xmm13, xmm1
0000796da41d1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
0000796da41d1b15  ptest xmm11, xmm11
0000796da41d1b1b  jnz 0x0000796DA41D1C0F
0000796da41d1b21  movaps [r15+0x220], xmm13
0000796da41d1b29  mov eax, 0x432000
0000796da41d1b2e  movups [r13+rax*1], xmm13
0000796da41d1b34  movaps xmm1, xmm14
0000796da41d1b38  mulpd xmm1, xmm15
0000796da41d1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
0000796da41d1b42  ptest xmm13, xmm13
0000796da41d1b48  jnz 0x0000796DA41D1D5C
0000796da41d1b4e  movaps [r15+0x210], xmm1
0000796da41d1b56  mov eax, 0x431E00
0000796da41d1b5b  movups [r13+rax*1], xmm1
0000796da41d1b61  mov qword ptr [r15+0x48], 0x10
0000796da41d1b69  xor eax, eax
0000796da41d1b6b  mov r14d, 0x10
0000796da41d1b71  mov r12d, 0x200
0000796da41d1b77  cmp r14, r12
0000796da41d1b7a  cmc
0000796da41d1b7b  lahf
0000796da41d1b7c  seto al
0000796da41d1b7f  mov [r15+0x108], eax
0000796da41d1b86  mov eax, [r15+0x108]
0000796da41d1b8d  sahf
0000796da41d1b8e  jnz 0x0000796DA41D1BC0
0000796da41d1b90  cmp dword ptr [r15+0x318], 0x00
0000796da41d1b98  jz 0x0000796DA41D2300
0000796da41d1b9e  nop [rax+rax*1], ax
0000796da41d1ba7  nop [rax+rax*1], eax
0000796da41d1baf  mov eax, 0x410490
0000796da41d1bb4  mov [r15+0x100], rax
0000796da41d1bbb  jmp 0x0000796DA3FFE110
0000796da41d1bc0  cmp dword ptr [r15+0x318], 0x00
0000796da41d1bc8  jz 0x0000796DA41D1EB0
0000796da41d1bce  nop [rax+rax*1], ax
0000796da41d1bd7  nop [rax+rax*1], eax
0000796da41d1bdf  mov eax, 0x410450
0000796da41d1be4  mov [r15+0x100], rax
0000796da41d1beb  jmp 0x0000796DA3FFE110
0000796da41d1bf0  int3
0000796da41d1bf1  call 0x0000796DA400DC20
0000796da41d1bf6  jmp 0x0000796DA41D19BE
0000796da41d1bfb  call 0x0000796DA400C260
0000796da41d1c00  jmp 0x0000796DA41D1A47
0000796da41d1c05  call 0x0000796DA40D5D70
0000796da41d1c0a  jmp 0x0000796DA41D1A5D
0000796da41d1c0f  sub rsp, 0x08
0000796da41d1c13  push rax
0000796da41d1c14  push rcx
0000796da41d1c15  push rdx
0000796da41d1c16  push rdi
0000796da41d1c17  push rsi
0000796da41d1c18  push r8
0000796da41d1c1a  push r9
0000796da41d1c1c  push r10
0000796da41d1c1e  push r11
0000796da41d1c20  sub rsp, 0xF0
0000796da41d1c27  vmovaps [rsp], xmm0
0000796da41d1c2c  vmovaps [rsp+0x10], xmm1
0000796da41d1c32  vmovaps [rsp+0x20], xmm2
0000796da41d1c38  vmovaps [rsp+0x30], xmm3
0000796da41d1c3e  vmovaps [rsp+0x40], xmm4
0000796da41d1c44  vmovaps [rsp+0x50], xmm5
0000796da41d1c4a  vmovaps [rsp+0x60], xmm6
0000796da41d1c50  vmovaps [rsp+0x70], xmm7
0000796da41d1c56  vmovaps [rsp+0x80], xmm8
0000796da41d1c5f  vmovaps [rsp+0x90], xmm9
0000796da41d1c68  vmovaps [rsp+0xA0], xmm10
0000796da41d1c71  vmovaps [rsp+0xB0], xmm11
0000796da41d1c7a  vmovaps [rsp+0xC0], xmm12
0000796da41d1c83  vmovaps [rsp+0xD0], xmm14
0000796da41d1c8c  vmovaps [rsp+0xE0], xmm15
0000796da41d1c95  sub rsp, 0x30
0000796da41d1c99  movaps [rsp], xmm13
0000796da41d1c9e  movaps [rsp+0x10], xmm12
0000796da41d1ca4  movaps [rsp+0x20], xmm1
0000796da41d1ca9  lea rdi, [rsp]
0000796da41d1cad  mov esi, 0x00
0000796da41d1cb2  mov rax, 0x5E26CB66A530
0000796da41d1cbc  call rax
0000796da41d1cbe  movaps xmm13, [rsp]
0000796da41d1cc3  add rsp, 0x30
0000796da41d1cc7  vmovaps xmm0, [rsp]
0000796da41d1ccc  vmovaps xmm1, [rsp+0x10]
0000796da41d1cd2  vmovaps xmm2, [rsp+0x20]
0000796da41d1cd8  vmovaps xmm3, [rsp+0x30]
0000796da41d1cde  vmovaps xmm4, [rsp+0x40]
0000796da41d1ce4  vmovaps xmm5, [rsp+0x50]
0000796da41d1cea  vmovaps xmm6, [rsp+0x60]
0000796da41d1cf0  vmovaps xmm7, [rsp+0x70]
0000796da41d1cf6  vmovaps xmm8, [rsp+0x80]
0000796da41d1cff  vmovaps xmm9, [rsp+0x90]
0000796da41d1d08  vmovaps xmm10, [rsp+0xA0]
0000796da41d1d11  vmovaps xmm11, [rsp+0xB0]
0000796da41d1d1a  vmovaps xmm12, [rsp+0xC0]
0000796da41d1d23  vmovaps xmm14, [rsp+0xD0]
0000796da41d1d2c  vmovaps xmm15, [rsp+0xE0]
0000796da41d1d35  add rsp, 0xF0
0000796da41d1d3c  pop r11
0000796da41d1d3e  pop r10
0000796da41d1d40  pop r9
0000796da41d1d42  pop r8
0000796da41d1d44  pop rsi
0000796da41d1d45  pop rdi
0000796da41d1d46  pop rdx
0000796da41d1d47  pop rcx
0000796da41d1d48  pop rax
0000796da41d1d49  add rsp, 0x08
0000796da41d1d4d  jmp 0x0000796DA41D1B21
0000796da41d1d52  call 0x0000796DA400C380
0000796da41d1d57  jmp 0x0000796DA41D1B34
0000796da41d1d5c  sub rsp, 0x08
0000796da41d1d60  push rax
0000796da41d1d61  push rcx
0000796da41d1d62  push rdx
0000796da41d1d63  push rdi
0000796da41d1d64  push rsi
0000796da41d1d65  push r8
0000796da41d1d67  push r9
0000796da41d1d69  push r10
0000796da41d1d6b  push r11
0000796da41d1d6d  sub rsp, 0xF0
0000796da41d1d74  vmovaps [rsp], xmm0
0000796da41d1d79  vmovaps [rsp+0x10], xmm2
0000796da41d1d7f  vmovaps [rsp+0x20], xmm3
0000796da41d1d85  vmovaps [rsp+0x30], xmm4
0000796da41d1d8b  vmovaps [rsp+0x40], xmm5
0000796da41d1d91  vmovaps [rsp+0x50], xmm6
0000796da41d1d97  vmovaps [rsp+0x60], xmm7
0000796da41d1d9d  vmovaps [rsp+0x70], xmm8
0000796da41d1da3  vmovaps [rsp+0x80], xmm9
0000796da41d1dac  vmovaps [rsp+0x90], xmm10
0000796da41d1db5  vmovaps [rsp+0xA0], xmm11
0000796da41d1dbe  vmovaps [rsp+0xB0], xmm12
0000796da41d1dc7  vmovaps [rsp+0xC0], xmm13
0000796da41d1dd0  vmovaps [rsp+0xD0], xmm14
0000796da41d1dd9  vmovaps [rsp+0xE0], xmm15
0000796da41d1de2  sub rsp, 0x30
0000796da41d1de6  movaps [rsp], xmm1
0000796da41d1dea  movaps [rsp+0x10], xmm14
0000796da41d1df0  movaps [rsp+0x20], xmm15
0000796da41d1df6  lea rdi, [rsp]
0000796da41d1dfa  mov esi, 0x00
0000796da41d1dff  mov rax, 0x5E26CB66A530
0000796da41d1e09  call rax
0000796da41d1e0b  movaps xmm1, [rsp]
0000796da41d1e0f  add rsp, 0x30
0000796da41d1e13  vmovaps xmm0, [rsp]
0000796da41d1e18  vmovaps xmm2, [rsp+0x10]
0000796da41d1e1e  vmovaps xmm3, [rsp+0x20]
0000796da41d1e24  vmovaps xmm4, [rsp+0x30]
0000796da41d1e2a  vmovaps xmm5, [rsp+0x40]
0000796da41d1e30  vmovaps xmm6, [rsp+0x50]
0000796da41d1e36  vmovaps xmm7, [rsp+0x60]
0000796da41d1e3c  vmovaps xmm8, [rsp+0x70]
0000796da41d1e42  vmovaps xmm9, [rsp+0x80]
0000796da41d1e4b  vmovaps xmm10, [rsp+0x90]
0000796da41d1e54  vmovaps xmm11, [rsp+0xA0]
0000796da41d1e5d  vmovaps xmm12, [rsp+0xB0]
0000796da41d1e66  vmovaps xmm13, [rsp+0xC0]
0000796da41d1e6f  vmovaps xmm14, [rsp+0xD0]
0000796da41d1e78  vmovaps xmm15, [rsp+0xE0]
0000796da41d1e81  add rsp, 0xF0
0000796da41d1e88  pop r11
0000796da41d1e8a  pop r10
0000796da41d1e8c  pop r9
0000796da41d1e8e  pop r8
0000796da41d1e90  pop rsi
0000796da41d1e91  pop rdi
0000796da41d1e92  pop rdx
0000796da41d1e93  pop rcx
0000796da41d1e94  pop rax
0000796da41d1e95  add rsp, 0x08
0000796da41d1e99  jmp 0x0000796DA41D1B4E
0000796da41d1e9e  call 0x0000796DA3FFF540
0000796da41d1ea3  jmp 0x0000796DA41D1B61
0000796da41d1ea8  int3
0000796da41d1ea9  nop [rax], eax
0000796da41d1eb0  movaps xmm1, [r15+0x180]
0000796da41d1eb8  vpmovqd xmm15, xmm1
0000796da41d1ebe  pxor xmm14, xmm14
0000796da41d1ec3  punpcklqdq xmm15, xmm14
0000796da41d1ec8  movaps [r15+0x210], xmm15
0000796da41d1ed0  movq xmm15, qword ptr [r15+0x140]
0000796da41d1ed9  movq xmm14, qword ptr [r15+0x120]
0000796da41d1ee2  psubd xmm15, xmm14
0000796da41d1ee7  movq xmm15, xmm15
0000796da41d1eec  movaps xmm13, [r15+0x170]
0000796da41d1ef4  paddq xmm1, xmm13
0000796da41d1ef9  movaps [r15+0x180], xmm1
0000796da41d1f01  movq xmm1, qword ptr [r15+0x160]
0000796da41d1f0a  paddd xmm14, xmm1
0000796da41d1f0f  movq xmm14, xmm14
0000796da41d1f14  movq xmm14, xmm14
0000796da41d1f19  movaps [r15+0x120], xmm14
0000796da41d1f21  pmovzxdq xmm15, xmm15
0000796da41d1f27  psllq xmm15, 0x00
0000796da41d1f2d  movq xmm1, qword ptr [r15+0x210]
0000796da41d1f36  movq xmm14, qword ptr [r15+0x110]
0000796da41d1f3f  paddd xmm1, xmm14
0000796da41d1f44  movq xmm1, xmm1
0000796da41d1f48  vcvtuqq2pd xmm15, xmm15
0000796da41d1f4e  pmovzxdq xmm1, xmm1
0000796da41d1f53  psllq xmm1, 0x00
0000796da41d1f58  vcvtuqq2pd xmm1, xmm1
0000796da41d1f5e  movaps xmm14, [r15+0x150]
0000796da41d1f66  movaps xmm13, xmm15
0000796da41d1f6a  mulpd xmm13, xmm14
0000796da41d1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
0000796da41d1f75  ptest xmm12, xmm12
0000796da41d1f7b  jnz 0x0000796DA41D205E
0000796da41d1f81  movaps [r15+0x220], xmm13
0000796da41d1f89  mov rax, [r15+0x48]
0000796da41d1f8d  mov r14, [r15+0x50]
0000796da41d1f91  lea r12, [r14+rax*1]
0000796da41d1f95  movups [r13+r12*1], xmm13
0000796da41d1f9b  movaps xmm15, [r15+0x130]
0000796da41d1fa3  movaps xmm14, xmm1
0000796da41d1fa7  mulpd xmm14, xmm15
0000796da41d1fac  vcmppd xmm13, xmm14, xmm14, 0x03
0000796da41d1fb2  ptest xmm13, xmm13
0000796da41d1fb8  jnz 0x0000796DA41D21AC
0000796da41d1fbe  movaps [r15+0x210], xmm14
0000796da41d1fc6  mov r14, [r15+0x40]
0000796da41d1fca  lea r12, [r14+rax*1]
0000796da41d1fce  movups [r13+r12*1], xmm14
0000796da41d1fd4  lea r14, [rax+0x10]
0000796da41d1fd8  mov [r15+0x48], r14
0000796da41d1fdc  xor eax, eax
0000796da41d1fde  mov r12d, 0x200
0000796da41d1fe4  cmp r14, r12
0000796da41d1fe7  cmc
0000796da41d1fe8  lahf
0000796da41d1fe9  seto al
0000796da41d1fec  mov [r15+0x108], eax
0000796da41d1ff3  mov eax, [r15+0x108]
0000796da41d1ffa  sahf
0000796da41d1ffb  jnz 0x0000796DA41D202D
0000796da41d1ffd  cmp dword ptr [r15+0x318], 0x00
0000796da41d2005  jz 0x0000796DA41D2300
0000796da41d200b  nop [rax+rax*1], ax
0000796da41d2014  nop [rax+rax*1], eax
0000796da41d201c  mov eax, 0x410490
0000796da41d2021  mov [r15+0x100], rax
0000796da41d2028  jmp 0x0000796DA3FFE110
0000796da41d202d  cmp dword ptr [r15+0x318], 0x00
0000796da41d2035  jz 0x0000796DA41D1EB0
0000796da41d203b  nop [rax+rax*1], ax
0000796da41d2044  nop [rax+rax*1], eax
0000796da41d204c  mov eax, 0x410450
0000796da41d2051  mov [r15+0x100], rax
0000796da41d2058  jmp 0x0000796DA3FFE110
0000796da41d205d  int3
0000796da41d205e  sub rsp, 0x08
0000796da41d2062  push rax
0000796da41d2063  push rcx
0000796da41d2064  push rdx
0000796da41d2065  push rdi
0000796da41d2066  push rsi
0000796da41d2067  push r8
0000796da41d2069  push r9
0000796da41d206b  push r10
0000796da41d206d  push r11
0000796da41d206f  sub rsp, 0xF0
0000796da41d2076  vmovaps [rsp], xmm0
0000796da41d207b  vmovaps [rsp+0x10], xmm1
0000796da41d2081  vmovaps [rsp+0x20], xmm2
0000796da41d2087  vmovaps [rsp+0x30], xmm3
0000796da41d208d  vmovaps [rsp+0x40], xmm4
0000796da41d2093  vmovaps [rsp+0x50], xmm5
0000796da41d2099  vmovaps [rsp+0x60], xmm6
0000796da41d209f  vmovaps [rsp+0x70], xmm7
0000796da41d20a5  vmovaps [rsp+0x80], xmm8
0000796da41d20ae  vmovaps [rsp+0x90], xmm9
0000796da41d20b7  vmovaps [rsp+0xA0], xmm10
0000796da41d20c0  vmovaps [rsp+0xB0], xmm11
0000796da41d20c9  vmovaps [rsp+0xC0], xmm12
0000796da41d20d2  vmovaps [rsp+0xD0], xmm14
0000796da41d20db  vmovaps [rsp+0xE0], xmm15
0000796da41d20e4  sub rsp, 0x30
0000796da41d20e8  movaps [rsp], xmm13
0000796da41d20ed  movaps [rsp+0x10], xmm15
0000796da41d20f3  movaps [rsp+0x20], xmm14
0000796da41d20f9  lea rdi, [rsp]
0000796da41d20fd  mov esi, 0x00
0000796da41d2102  mov rax, 0x5E26CB66A530
0000796da41d210c  call rax
0000796da41d210e  movaps xmm13, [rsp]
0000796da41d2113  add rsp, 0x30
0000796da41d2117  vmovaps xmm0, [rsp]
0000796da41d211c  vmovaps xmm1, [rsp+0x10]
0000796da41d2122  vmovaps xmm2, [rsp+0x20]
0000796da41d2128  vmovaps xmm3, [rsp+0x30]
0000796da41d212e  vmovaps xmm4, [rsp+0x40]
0000796da41d2134  vmovaps xmm5, [rsp+0x50]
0000796da41d213a  vmovaps xmm6, [rsp+0x60]
0000796da41d2140  vmovaps xmm7, [rsp+0x70]
0000796da41d2146  vmovaps xmm8, [rsp+0x80]
0000796da41d214f  vmovaps xmm9, [rsp+0x90]
0000796da41d2158  vmovaps xmm10, [rsp+0xA0]
0000796da41d2161  vmovaps xmm11, [rsp+0xB0]
0000796da41d216a  vmovaps xmm12, [rsp+0xC0]
0000796da41d2173  vmovaps xmm14, [rsp+0xD0]
0000796da41d217c  vmovaps xmm15, [rsp+0xE0]
0000796da41d2185  add rsp, 0xF0
0000796da41d218c  pop r11
0000796da41d218e  pop r10
0000796da41d2190  pop r9
0000796da41d2192  pop r8
0000796da41d2194  pop rsi
0000796da41d2195  pop rdi
0000796da41d2196  pop rdx
0000796da41d2197  pop rcx
0000796da41d2198  pop rax
0000796da41d2199  add rsp, 0x08
0000796da41d219d  jmp 0x0000796DA41D1F81
0000796da41d21a2  call 0x0000796DA40C2240
0000796da41d21a7  jmp 0x0000796DA41D1F9B
0000796da41d21ac  sub rsp, 0x08
0000796da41d21b0  push rax
0000796da41d21b1  push rcx
0000796da41d21b2  push rdx
0000796da41d21b3  push rdi
0000796da41d21b4  push rsi
0000796da41d21b5  push r8
0000796da41d21b7  push r9
0000796da41d21b9  push r10
0000796da41d21bb  push r11
0000796da41d21bd  sub rsp, 0xF0
0000796da41d21c4  vmovaps [rsp], xmm0
0000796da41d21c9  vmovaps [rsp+0x10], xmm1
0000796da41d21cf  vmovaps [rsp+0x20], xmm2
0000796da41d21d5  vmovaps [rsp+0x30], xmm3
0000796da41d21db  vmovaps [rsp+0x40], xmm4
0000796da41d21e1  vmovaps [rsp+0x50], xmm5
0000796da41d21e7  vmovaps [rsp+0x60], xmm6
0000796da41d21ed  vmovaps [rsp+0x70], xmm7
0000796da41d21f3  vmovaps [rsp+0x80], xmm8
0000796da41d21fc  vmovaps [rsp+0x90], xmm9
0000796da41d2205  vmovaps [rsp+0xA0], xmm10
0000796da41d220e  vmovaps [rsp+0xB0], xmm11
0000796da41d2217  vmovaps [rsp+0xC0], xmm12
0000796da41d2220  vmovaps [rsp+0xD0], xmm13
0000796da41d2229  vmovaps [rsp+0xE0], xmm15
0000796da41d2232  sub rsp, 0x30
0000796da41d2236  movaps [rsp], xmm14
0000796da41d223b  movaps [rsp+0x10], xmm1
0000796da41d2240  movaps [rsp+0x20], xmm15
0000796da41d2246  lea rdi, [rsp]
0000796da41d224a  mov esi, 0x00
0000796da41d224f  mov rax, 0x5E26CB66A530
0000796da41d2259  call rax
0000796da41d225b  movaps xmm14, [rsp]
0000796da41d2260  add rsp, 0x30
0000796da41d2264  vmovaps xmm0, [rsp]
0000796da41d2269  vmovaps xmm1, [rsp+0x10]
0000796da41d226f  vmovaps xmm2, [rsp+0x20]
0000796da41d2275  vmovaps xmm3, [rsp+0x30]
0000796da41d227b  vmovaps xmm4, [rsp+0x40]
0000796da41d2281  vmovaps xmm5, [rsp+0x50]
0000796da41d2287  vmovaps xmm6, [rsp+0x60]
0000796da41d228d  vmovaps xmm7, [rsp+0x70]
0000796da41d2293  vmovaps xmm8, [rsp+0x80]
0000796da41d229c  vmovaps xmm9, [rsp+0x90]
0000796da41d22a5  vmovaps xmm10, [rsp+0xA0]
0000796da41d22ae  vmovaps xmm11, [rsp+0xB0]
0000796da41d22b7  vmovaps xmm12, [rsp+0xC0]
0000796da41d22c0  vmovaps xmm13, [rsp+0xD0]
0000796da41d22c9  vmovaps xmm15, [rsp+0xE0]
0000796da41d22d2  add rsp, 0xF0
0000796da41d22d9  pop r11
0000796da41d22db  pop r10
0000796da41d22dd  pop r9
0000796da41d22df  pop r8
0000796da41d22e1  pop rsi
0000796da41d22e2  pop rdi
0000796da41d22e3  pop rdx
0000796da41d22e4  pop rcx
0000796da41d22e5  pop rax
0000796da41d22e6  add rsp, 0x08
0000796da41d22ea  jmp 0x0000796DA41D1FBE
0000796da41d22ef  call 0x0000796DA40C34C0
0000796da41d22f4  jmp 0x0000796DA41D1FD4
0000796da41d22f9  int3
0000796da41d22fa  nop [rax+rax*1], ax
0000796da41d2300  mov rax, [r15+0x50]
0000796da41d2304  lea r14, [rax+0x80]
0000796da41d230b  movups xmm1, [r13+r14*1]
0000796da41d2311  lea r14, [rax+0x90]
0000796da41d2318  movups xmm15, [r13+r14*1]
0000796da41d231e  vxorps xmm14, xmm14, xmm14
0000796da41d2323  vpbroadcastq xmm14, xmm14
0000796da41d2328  lea r14, [rax+0x40]
0000796da41d232c  movups xmm13, [r13+r14*1]
0000796da41d2332  lea r14, [rax+0x50]
0000796da41d2336  movups xmm12, [r13+r14*1]
0000796da41d233c  mov qword ptr [r15+0x48], 0x00
0000796da41d2344  movups xmm11, [r13+rax*1]
0000796da41d234a  lea r14, [rax+0x10]
0000796da41d234e  movups xmm10, [r13+r14*1]
0000796da41d2354  mov r14, [r15+0xF8]
0000796da41d235b  lea r12, [r14+0xE0]
0000796da41d2362  movups [r13+r12*1], xmm15
0000796da41d2368  lea r12, [r14+0xF0]
0000796da41d236f  movups [r13+r12*1], xmm1
0000796da41d2375  lea r12, [rax+0xC0]
0000796da41d237c  movups xmm1, [r13+r12*1]
0000796da41d2382  lea r12, [rax+0xD0]
0000796da41d2389  movups xmm15, [r13+r12*1]
0000796da41d238f  lea r12, [rax+0x140]
0000796da41d2396  movups xmm9, [r13+r12*1]
0000796da41d239c  lea r12, [rax+0x150]
0000796da41d23a3  movups xmm8, [r13+r12*1]
0000796da41d23a9  lea r12, [rax+0x180]
0000796da41d23b0  movups xmm7, [r13+r12*1]
0000796da41d23b6  lea r12, [rax+0x190]
0000796da41d23bd  movups xmm6, [r13+r12*1]
0000796da41d23c3  lea r12, [r14+0xC0]
0000796da41d23ca  movups [r13+r12*1], xmm15
0000796da41d23d0  lea r12, [r14+0xD0]
0000796da41d23d7  movups [r13+r12*1], xmm1
0000796da41d23dd  lea r12, [rax+0x100]
0000796da41d23e4  movups xmm1, [r13+r12*1]
0000796da41d23ea  lea r12, [rax+0x110]
0000796da41d23f1  movups xmm15, [r13+r12*1]
0000796da41d23f7  lea r12, [rax+0x1C0]
0000796da41d23fe  movups xmm5, [r13+r12*1]
0000796da41d2404  lea r12, [rax+0x1D0]
0000796da41d240b  movups xmm4, [r13+r12*1]
0000796da41d2411  lea r12, [rax+0x20]
0000796da41d2415  movups xmm3, [r13+r12*1]
0000796da41d241b  lea r12, [rax+0x30]
0000796da41d241f  movups xmm2, [r13+r12*1]
0000796da41d2425  movaps [r15+0x1F0], xmm2
0000796da41d242d  lea r12, [r14+0x20]
0000796da41d2431  movups [r13+r12*1], xmm1
0000796da41d2437  lea r12, [r14+0x30]
0000796da41d243b  movups [r13+r12*1], xmm12
0000796da41d2441  lea r12, [rax+0x60]
0000796da41d2445  movups xmm1, [r13+r12*1]
0000796da41d244b  lea r12, [rax+0x70]
0000796da41d244f  movups xmm12, [r13+r12*1]
0000796da41d2455  lea r12, [r14+0x60]
0000796da41d2459  movups [r13+r12*1], xmm11
0000796da41d245f  lea r12, [r14+0x70]
0000796da41d2463  movups [r13+r12*1], xmm5
0000796da41d2469  lea r12, [rax+0xE0]
0000796da41d2470  movups xmm11, [r13+r12*1]
0000796da41d2476  lea r12, [rax+0xF0]
0000796da41d247d  movups xmm5, [r13+r12*1]
0000796da41d2483  lea r12, [rax+0x120]
0000796da41d248a  vmovaps [rsp+0x10], xmm1
0000796da41d2490  movups xmm1, [r13+r12*1]
0000796da41d2496  lea r12, [rax+0x130]
0000796da41d249d  vmovaps [rsp+0x20], xmm1
0000796da41d24a3  movups xmm1, [r13+r12*1]
0000796da41d24a9  lea r12, [r14+0xA0]
0000796da41d24b0  movups [r13+r12*1], xmm12
0000796da41d24b6  lea r12, [r14+0xB0]
0000796da41d24bd  vmovaps xmm12, [rsp+0x10]
0000796da41d24c3  movups [r13+r12*1], xmm12
0000796da41d24c9  lea r12, [rax+0xA0]
0000796da41d24d0  movups xmm12, [r13+r12*1]
0000796da41d24d6  lea r12, [rax+0xB0]
0000796da41d24dd  vmovaps [rsp+0x10], xmm1
0000796da41d24e3  movups xmm1, [r13+r12*1]
0000796da41d24e9  lea r12, [rax+0x160]
0000796da41d24f0  vmovaps [rsp+0x30], xmm1
0000796da41d24f6  movups xmm1, [r13+r12*1]
0000796da41d24fc  lea r12, [rax+0x170]
0000796da41d2503  vmovaps [rsp+0x40], xmm1
0000796da41d2509  movups xmm1, [r13+r12*1]
0000796da41d250f  movaps [r15+0x2B0], xmm1
0000796da41d2517  lea r12, [rax+0x1A0]
0000796da41d251e  vmovaps [rsp+0x50], xmm1
0000796da41d2524  movups xmm1, [r13+r12*1]
0000796da41d252a  lea r12, [rax+0x1B0]
0000796da41d2531  vmovaps [rsp+0x60], xmm1
0000796da41d2537  movups xmm1, [r13+r12*1]
0000796da41d253d  vmovaps [rsp+0x70], xmm1
0000796da41d2543  vmovaps xmm1, [rsp+0x60]
0000796da41d2549  movaps [r15+0x290], xmm1
0000796da41d2551  vmovaps [rsp+0x60], xmm1
0000796da41d2557  vmovaps xmm1, [rsp+0x70]
0000796da41d255d  movaps [r15+0x1E0], xmm1
0000796da41d2565  lea r12, [r14+0x80]
0000796da41d256c  vmovaps [rsp+0x70], xmm1
0000796da41d2572  vmovaps xmm1, [rsp+0x30]
0000796da41d2578  movups [r13+r12*1], xmm1
0000796da41d257e  lea r12, [r14+0x90]
0000796da41d2585  movups [r13+r12*1], xmm12
0000796da41d258b  lea r12, [rax+0x1E0]
0000796da41d2592  movups xmm1, [r13+r12*1]
0000796da41d2598  lea r12, [rax+0x1F0]
0000796da41d259f  movups xmm12, [r13+r12*1]
0000796da41d25a5  mov qword ptr [r15+0x50], 0x432200
0000796da41d25ad  lea rax, [r14+0x40]
0000796da41d25b1  vmovaps [rsp+0x30], xmm1
0000796da41d25b7  vmovaps xmm1, [rsp+0x40]
0000796da41d25bd  movups [r13+rax*1], xmm1
0000796da41d25c3  lea rax, [r14+0x50]
0000796da41d25c7  movups [r13+rax*1], xmm10
0000796da41d25cd  movups [r13+r14*1], xmm12
0000796da41d25d3  lea rax, [r14+0x10]
0000796da41d25d7  vmovaps xmm1, [rsp+0x30]
0000796da41d25dd  movups [r13+rax*1], xmm1
0000796da41d25e3  mov rax, [r15+0x40]
0000796da41d25e7  vmovaps [rsp+0x30], xmm3
0000796da41d25ed  vmovaps xmm1, [rsp+0x30]
0000796da41d25f3  por xmm3, xmm1
0000796da41d25f7  vmovaps [rsp+0x30], xmm6
0000796da41d25fd  vmovaps xmm12, [rsp+0x30]
0000796da41d2603  por xmm6, xmm12
0000796da41d2608  lea r12, [rax+0x30]
0000796da41d260c  mov r11, [r13+r12*1]
0000796da41d2611  lea r12, [rax+0x38]
0000796da41d2615  mov r10, [r13+r12*1]
0000796da41d261a  movq xmm12, r11
0000796da41d261f  movq xmm10, r10
0000796da41d2624  movq xmm12, xmm12
0000796da41d2629  vmovaps [rsp+0x30], xmm12
0000796da41d262f  movq xmm12, xmm12
0000796da41d2634  movaps [r15+0x130], xmm12
0000796da41d263c  movq xmm10, xmm10
0000796da41d2641  vmovaps [rsp+0x40], xmm10
0000796da41d2647  movq xmm10, xmm10
0000796da41d264c  movaps [r15+0x280], xmm10
0000796da41d2654  vmovaps [rsp+0x80], xmm9
0000796da41d265d  vmovaps xmm12, [rsp+0x80]
0000796da41d2666  por xmm9, xmm12
0000796da41d266b  lea r12, [rax+0x20]
0000796da41d266f  mov r11, [r13+r12*1]
0000796da41d2674  lea r12, [rax+0x28]
0000796da41d2678  mov r10, [r13+r12*1]
0000796da41d267d  movq xmm12, r11
0000796da41d2682  movq xmm10, r10
0000796da41d2687  movq xmm12, xmm12
0000796da41d268c  vmovaps [rsp+0x80], xmm12
0000796da41d2695  movq xmm12, xmm12
0000796da41d269a  movaps [r15+0x150], xmm12
0000796da41d26a2  movq xmm10, xmm10
0000796da41d26a7  vmovaps [rsp+0x90], xmm10
0000796da41d26b0  movq xmm10, xmm10
0000796da41d26b5  movaps [r15+0x140], xmm10
0000796da41d26bd  lea r12, [rax+0x10]
0000796da41d26c1  mov r11, [r13+r12*1]
0000796da41d26c6  lea r12, [rax+0x18]
0000796da41d26ca  mov r10, [r13+r12*1]
0000796da41d26cf  movq xmm12, r11
0000796da41d26d4  movq xmm10, r10
0000796da41d26d9  movq xmm12, xmm12
0000796da41d26de  vmovaps [rsp+0xA0], xmm12
0000796da41d26e7  movq xmm12, xmm12
0000796da41d26ec  movaps [r15+0x170], xmm12
0000796da41d26f4  movq xmm10, xmm10
0000796da41d26f9  vmovaps [rsp+0xB0], xmm10
0000796da41d2702  movq xmm10, xmm10
0000796da41d2707  movaps [r15+0x160], xmm10
0000796da41d270f  mov r12, [r13+rax*1]
0000796da41d2714  vmovq xmm12, r12
0000796da41d2719  vpbroadcastq xmm12, xmm12
0000796da41d271e  lea r12, [rax+0x08]
0000796da41d2722  mov rax, [r13+r12*1]
0000796da41d2727  movq xmm10, rax
0000796da41d272c  movaps [r15+0x230], xmm10
0000796da41d2734  lea rax, [r14+0x50]
0000796da41d2738  movups xmm10, [r13+rax*1]
0000796da41d273e  lea rax, [r14+0x60]
0000796da41d2742  vmovaps [rsp+0xC0], xmm1
0000796da41d274b  movups xmm1, [r13+rax*1]
0000796da41d2751  lea rax, [r14+0x30]
0000796da41d2755  vmovaps [rsp+0xD0], xmm1
0000796da41d275e  movups xmm1, [r13+rax*1]
0000796da41d2764  mov qword ptr [r15+0x60], 0x432200
0000796da41d276c  mov qword ptr [r15+0x58], 0x40
0000796da41d2774  vmovaps [rsp+0xE0], xmm1
0000796da41d277d  vmovaps [rsp+0xF0], xmm15
0000796da41d2786  vmovaps xmm15, [rsp+0xC0]
0000796da41d278f  vmovaps [rsp+0xC0], xmm14
0000796da41d2798  movaps xmm1, xmm12
0000796da41d279c  mulpd xmm1, xmm15
0000796da41d27a1  vcmppd xmm14, xmm1, xmm1, 0x03
0000796da41d27a6  ptest xmm14, xmm14
0000796da41d27ac  jnz 0x0000796DA41D3863
0000796da41d27b2  movq xmm15, qword ptr [r15+0x230]
0000796da41d27bb  vmovaps [rsp+0x100], xmm15
0000796da41d27c4  vpermilpd xmm15, xmm15, 0x00
0000796da41d27ca  vmovaps [rsp+0x110], xmm1
0000796da41d27d3  vmovaps xmm1, [rsp+0xE0]
0000796da41d27dc  vmovaps [rsp+0xE0], xmm13
0000796da41d27e5  movaps xmm14, xmm1
0000796da41d27e9  mulpd xmm14, xmm15
0000796da41d27ee  vcmppd xmm13, xmm14, xmm14, 0x03
0000796da41d27f4  ptest xmm13, xmm13
0000796da41d27fa  jnz 0x0000796DA41D39A5
0000796da41d2800  vxorps xmm1, xmm1, xmm1
0000796da41d2804  vpbroadcastq xmm1, xmm1
0000796da41d2809  vmovaps xmm13, [rsp+0xD0]
0000796da41d2812  vmovaps [rsp+0xD0], xmm1
0000796da41d281b  movaps xmm15, xmm12
0000796da41d281f  mulpd xmm15, xmm13
0000796da41d2824  vcmppd xmm1, xmm15, xmm15, 0x03
0000796da41d282a  ptest xmm1, xmm1
0000796da41d282f  jnz 0x0000796DA41D3AE8
0000796da41d2835  movaps xmm1, xmm12
0000796da41d2839  mulpd xmm1, xmm10
0000796da41d283e  vcmppd xmm13, xmm1, xmm1, 0x03
0000796da41d2843  ptest xmm13, xmm13
0000796da41d2849  jnz 0x0000796DA41D3C2C
0000796da41d284f  movaps xmm13, xmm12
0000796da41d2853  mulpd xmm13, xmm2
0000796da41d2858  vcmppd xmm10, xmm13, xmm13, 0x03
0000796da41d285e  ptest xmm10, xmm10
0000796da41d2864  jnz 0x0000796DA41D3D6E
0000796da41d286a  vmovaps [rsp+0x120], xmm7
0000796da41d2873  vmovaps xmm12, [rsp+0x120]
0000796da41d287c  por xmm7, xmm12
0000796da41d2881  vmovaps xmm12, [rsp+0xE0]
0000796da41d288a  vmovaps xmm10, [rsp+0xE0]
0000796da41d2893  por xmm12, xmm10
0000796da41d2898  vmovaps xmm2, [rsp+0x100]
0000796da41d28a1  vpermilpd xmm2, xmm2, 0x00
0000796da41d28a7  vmovaps [rsp+0xE0], xmm1
0000796da41d28b0  vmovaps [rsp+0x120], xmm15
0000796da41d28b9  movaps xmm1, xmm10
0000796da41d28bd  mulpd xmm1, xmm2
0000796da41d28c1  vcmppd xmm15, xmm1, xmm1, 0x03
0000796da41d28c6  ptest xmm15, xmm15
0000796da41d28cc  jnz 0x0000796DA41D3EB1
0000796da41d28d2  xor eax, eax
0000796da41d28d4  mov r12d, 0x40
0000796da41d28da  mov r11d, 0x200
0000796da41d28e0  cmp r12, r11
0000796da41d28e3  cmc
0000796da41d28e4  lahf
0000796da41d28e5  seto al
0000796da41d28e8  mov [r15+0x108], eax
0000796da41d28ef  vmovaps xmm10, [rsp+0x110]
0000796da41d28f8  vmovaps xmm2, [rsp+0xD0]
0000796da41d2901  vmovaps [rsp+0xD0], xmm1
0000796da41d290a  movaps xmm15, xmm10
0000796da41d290e  addpd xmm15, xmm2
0000796da41d2913  vcmppd xmm1, xmm15, xmm15, 0x03
0000796da41d2919  ptest xmm1, xmm1
0000796da41d291e  jnz 0x0000796DA41D3FF2
0000796da41d2924  vmovaps xmm10, [rsp+0x120]
0000796da41d292d  vmovaps [rsp+0x110], xmm15
0000796da41d2936  vmovaps xmm15, [rsp+0xC0]
0000796da41d293f  vmovaps [rsp+0xC0], xmm14
0000796da41d2948  movaps xmm1, xmm10
0000796da41d294c  addpd xmm1, xmm15
0000796da41d2951  vcmppd xmm14, xmm1, xmm1, 0x03
0000796da41d2956  ptest xmm14, xmm14
0000796da41d295c  jnz 0x0000796DA41D4135
0000796da41d2962  vmovaps xmm10, [rsp+0xE0]
0000796da41d296b  vmovaps [rsp+0xE0], xmm1
0000796da41d2974  movaps xmm14, xmm10
0000796da41d2978  addpd xmm14, xmm15
0000796da41d297d  vcmppd xmm1, xmm14, xmm14, 0x03
0000796da41d2983  ptest xmm1, xmm1
0000796da41d2988  jnz 0x0000796DA41D4277
0000796da41d298e  vmovaps xmm1, [rsp+0x10]
0000796da41d2994  vmovaps xmm15, [rsp+0x10]
0000796da41d299a  por xmm1, xmm15
0000796da41d299f  vmovaps xmm15, [rsp+0x20]
0000796da41d29a5  vmovaps xmm10, [rsp+0x20]
0000796da41d29ab  por xmm15, xmm10
0000796da41d29b0  vmovaps [rsp+0x10], xmm5
0000796da41d29b6  vmovaps xmm10, [rsp+0x10]
0000796da41d29bc  por xmm5, xmm10
0000796da41d29c1  vmovaps [rsp+0x10], xmm11
0000796da41d29c7  vmovaps xmm10, [rsp+0x10]
0000796da41d29cd  por xmm11, xmm10
0000796da41d29d2  vmovaps [rsp+0x10], xmm4
0000796da41d29d8  vmovaps xmm10, [rsp+0x10]
0000796da41d29de  por xmm4, xmm10
0000796da41d29e3  vmovaps [rsp+0x10], xmm8
0000796da41d29e9  vmovaps xmm10, [rsp+0x10]
0000796da41d29ef  por xmm8, xmm10
0000796da41d29f4  vmovaps xmm10, [rsp+0xF0]
0000796da41d29fd  vmovaps [rsp+0x10], xmm1
0000796da41d2a03  vmovaps xmm1, [rsp+0xF0]
0000796da41d2a0c  por xmm10, xmm1
0000796da41d2a11  lea rax, [r14+0xA0]
0000796da41d2a18  movups xmm1, [r13+rax*1]
0000796da41d2a1e  lea rax, [r14+0xB0]
0000796da41d2a25  vmovaps [rsp+0x20], xmm1
0000796da41d2a2b  movups xmm1, [r13+rax*1]
0000796da41d2a31  vmovaps [rsp+0xF0], xmm1
0000796da41d2a3a  vmovaps [rsp+0x120], xmm15
0000796da41d2a43  movaps xmm1, xmm13
0000796da41d2a47  addpd xmm1, xmm2
0000796da41d2a4b  vcmppd xmm15, xmm1, xmm1, 0x03
0000796da41d2a50  ptest xmm15, xmm15
0000796da41d2a56  jnz 0x0000796DA41D43CF
0000796da41d2a5c  lea rax, [r14+0xF0]
0000796da41d2a63  movups xmm15, [r13+rax*1]
0000796da41d2a69  vmovaps xmm2, [rsp+0xE0]
0000796da41d2a72  vmovaps [rsp+0xE0], xmm1
0000796da41d2a7b  vmovaps xmm1, [rsp+0xD0]
0000796da41d2a84  vmovaps [rsp+0xD0], xmm15
0000796da41d2a8d  movaps xmm13, xmm2
0000796da41d2a91  addpd xmm13, xmm1
0000796da41d2a96  vcmppd xmm15, xmm13, xmm13, 0x03
0000796da41d2a9c  ptest xmm15, xmm15
0000796da41d2aa2  jnz 0x0000796DA41D451A
0000796da41d2aa8  vmovaps xmm15, [rsp+0xC0]
0000796da41d2ab1  movaps xmm1, xmm14
0000796da41d2ab5  addpd xmm1, xmm15
0000796da41d2aba  vcmppd xmm2, xmm1, xmm1, 0x03
0000796da41d2abf  ptest xmm2, xmm2
0000796da41d2ac4  jnz 0x0000796DA41D465C
0000796da41d2aca  vmovaps xmm15, [rsp+0x100]
0000796da41d2ad3  vpermilpd xmm15, xmm15, 0x00
0000796da41d2ad9  vmovaps xmm2, [rsp+0xF0]
0000796da41d2ae2  vmovaps [rsp+0xC0], xmm1
0000796da41d2aeb  movaps xmm14, xmm2
0000796da41d2aef  mulpd xmm14, xmm15
0000796da41d2af4  vcmppd xmm1, xmm14, xmm14, 0x03
0000796da41d2afa  ptest xmm1, xmm1
0000796da41d2aff  jnz 0x0000796DA41D479E
0000796da41d2b05  vmovaps xmm1, [rsp+0xA0]
0000796da41d2b0e  vpermilpd xmm1, xmm1, 0x00
0000796da41d2b14  vmovaps xmm2, [rsp+0xD0]
0000796da41d2b1d  vmovaps [rsp+0xD0], xmm14
0000796da41d2b26  movaps xmm15, xmm2
0000796da41d2b2a  mulpd xmm15, xmm1
0000796da41d2b2f  vcmppd xmm14, xmm15, xmm15, 0x03
0000796da41d2b35  ptest xmm14, xmm14
0000796da41d2b3b  jnz 0x0000796DA41D48E1
0000796da41d2b41  lea rax, [r14+0xE0]
0000796da41d2b48  movups xmm1, [r13+rax*1]
0000796da41d2b4e  vmovaps xmm14, [rsp+0x100]
0000796da41d2b57  vpermilpd xmm14, xmm14, 0x00
0000796da41d2b5d  vmovaps [rsp+0xF0], xmm1
0000796da41d2b66  vmovaps xmm1, [rsp+0x20]
0000796da41d2b6c  vmovaps [rsp+0x20], xmm15
0000796da41d2b72  movaps xmm2, xmm1
0000796da41d2b75  mulpd xmm2, xmm14
0000796da41d2b7a  vcmppd xmm15, xmm2, xmm2, 0x03
0000796da41d2b7f  ptest xmm15, xmm15
0000796da41d2b85  jnz 0x0000796DA41D4A2D
0000796da41d2b8b  vmovaps [rsp+0x100], xmm10
0000796da41d2b94  vmovaps xmm1, [rsp+0x100]
0000796da41d2b9d  por xmm10, xmm1
0000796da41d2ba2  movaps [r15+0x300], xmm10
0000796da41d2baa  vmovaps [rsp+0x100], xmm8
0000796da41d2bb3  vmovaps xmm1, [rsp+0x100]
0000796da41d2bbc  por xmm8, xmm1
0000796da41d2bc1  movaps [r15+0x190], xmm8
0000796da41d2bc9  vmovaps xmm1, [rsp+0xA0]
0000796da41d2bd2  vpermilpd xmm1, xmm1, 0x00
0000796da41d2bd8  vmovaps xmm14, [rsp+0xF0]
0000796da41d2be1  vmovaps [rsp+0xF0], xmm13
0000796da41d2bea  movaps xmm15, xmm14
0000796da41d2bee  mulpd xmm15, xmm1
0000796da41d2bf3  vcmppd xmm13, xmm15, xmm15, 0x03
0000796da41d2bf9  ptest xmm13, xmm13
0000796da41d2bff  jnz 0x0000796DA41D4B6E
0000796da41d2c05  lea rax, [r14+0x90]
0000796da41d2c0c  movups xmm1, [r13+rax*1]
0000796da41d2c12  vmovaps [rsp+0x100], xmm4
0000796da41d2c1b  vmovaps xmm14, [rsp+0x100]
0000796da41d2c24  por xmm4, xmm14
0000796da41d2c29  movaps [r15+0x1C0], xmm4
0000796da41d2c31  vmovaps [rsp+0x100], xmm11
0000796da41d2c3a  vmovaps xmm14, [rsp+0x100]
0000796da41d2c43  por xmm11, xmm14
0000796da41d2c48  movaps [r15+0x200], xmm11
0000796da41d2c50  vmovaps [rsp+0x100], xmm5
0000796da41d2c59  vmovaps xmm14, [rsp+0x100]
0000796da41d2c62  por xmm5, xmm14
0000796da41d2c67  movaps [r15+0x2D0], xmm5
0000796da41d2c6f  vmovaps xmm14, [rsp+0x120]
0000796da41d2c78  vmovaps xmm13, [rsp+0x120]
0000796da41d2c81  por xmm14, xmm13
0000796da41d2c86  movaps [r15+0x2E0], xmm14
0000796da41d2c8e  vmovaps [rsp+0x100], xmm1
0000796da41d2c97  vmovaps xmm1, [rsp+0x110]
0000796da41d2ca0  vmovaps [rsp+0x110], xmm15
0000796da41d2ca9  vmovaps xmm15, [rsp+0xD0]
0000796da41d2cb2  vmovaps [rsp+0xD0], xmm14
0000796da41d2cbb  movaps xmm13, xmm1
0000796da41d2cbf  addpd xmm13, xmm15
0000796da41d2cc4  vcmppd xmm14, xmm13, xmm13, 0x03
0000796da41d2cca  ptest xmm14, xmm14
0000796da41d2cd0  jnz 0x0000796DA41D4CBB
0000796da41d2cd6  vmovaps xmm1, [rsp+0xA0]
0000796da41d2cdf  vpermilpd xmm1, xmm1, 0x00
0000796da41d2ce5  vmovaps xmm14, [rsp+0x100]
0000796da41d2cee  vmovaps [rsp+0x100], xmm13
0000796da41d2cf7  movaps xmm15, xmm14
0000796da41d2cfb  mulpd xmm15, xmm1
0000796da41d2d00  vcmppd xmm13, xmm15, xmm15, 0x03
0000796da41d2d06  ptest xmm13, xmm13
0000796da41d2d0c  jnz 0x0000796DA41D4DFE
0000796da41d2d12  lea rax, [r14+0x80]
0000796da41d2d19  movups xmm1, [r13+rax*1]
0000796da41d2d1f  vmovaps xmm13, [rsp+0xE0]
0000796da41d2d28  vmovaps [rsp+0xE0], xmm1
0000796da41d2d31  movaps xmm14, xmm13
0000796da41d2d35  addpd xmm14, xmm2
0000796da41d2d3a  vcmppd xmm1, xmm14, xmm14, 0x03
0000796da41d2d40  ptest xmm1, xmm1
0000796da41d2d45  jnz 0x0000796DA41D4F4B
0000796da41d2d4b  vmovaps xmm13, [rsp+0xF0]
0000796da41d2d54  vmovaps xmm2, [rsp+0x20]
0000796da41d2d5a  vmovaps [rsp+0x20], xmm15
0000796da41d2d60  movaps xmm1, xmm13
0000796da41d2d64  addpd xmm1, xmm2
0000796da41d2d68  vcmppd xmm15, xmm1, xmm1, 0x03
0000796da41d2d6d  ptest xmm15, xmm15
0000796da41d2d73  jnz 0x0000796DA41D508E
0000796da41d2d79  vmovaps xmm15, [rsp+0x10]
0000796da41d2d7f  vmovaps xmm13, [rsp+0x10]
0000796da41d2d85  por xmm15, xmm13
0000796da41d2d8a  movaps [r15+0x2F0], xmm15
0000796da41d2d92  vmovaps xmm13, [rsp+0xA0]
0000796da41d2d9b  vpermilpd xmm13, xmm13, 0x00
0000796da41d2da1  vmovaps [rsp+0x10], xmm1
0000796da41d2da7  vmovaps xmm1, [rsp+0xE0]
0000796da41d2db0  vmovaps [rsp+0xA0], xmm15
0000796da41d2db9  movaps xmm2, xmm1
0000796da41d2dbc  mulpd xmm2, xmm13
0000796da41d2dc1  vcmppd xmm15, xmm2, xmm2, 0x03
0000796da41d2dc6  ptest xmm15, xmm15
0000796da41d2dcc  jnz 0x0000796DA41D51CF
0000796da41d2dd2  lea rax, [r14+0xD0]
0000796da41d2dd9  movups xmm1, [r13+rax*1]
0000796da41d2ddf  vmovaps xmm13, [rsp+0xC0]
0000796da41d2de8  vmovaps [rsp+0xC0], xmm1
0000796da41d2df1  vmovaps xmm1, [rsp+0x110]
0000796da41d2dfa  vmovaps [rsp+0xE0], xmm14
0000796da41d2e03  movaps xmm15, xmm13
0000796da41d2e07  addpd xmm15, xmm1
0000796da41d2e0c  vcmppd xmm14, xmm15, xmm15, 0x03
0000796da41d2e12  ptest xmm14, xmm14
0000796da41d2e18  jnz 0x0000796DA41D531A
0000796da41d2e1e  vmovaps xmm1, [rsp+0xB0]
0000796da41d2e27  vpermilpd xmm1, xmm1, 0x00
0000796da41d2e2d  movaps xmm14, xmm11
0000796da41d2e31  mulpd xmm14, xmm1
0000796da41d2e36  vcmppd xmm13, xmm14, xmm14, 0x03
0000796da41d2e3c  ptest xmm13, xmm13
0000796da41d2e42  jnz 0x0000796DA41D545D
0000796da41d2e48  movaps [r15+0x260], xmm14
0000796da41d2e50  vxorps xmm1, xmm1, xmm1
0000796da41d2e54  vpbroadcastq xmm1, xmm1
0000796da41d2e59  movaps [r15+0x1B0], xmm1
0000796da41d2e61  vmovaps xmm1, [rsp+0xB0]
0000796da41d2e6a  vpermilpd xmm1, xmm1, 0x00
0000796da41d2e70  vmovaps xmm11, [rsp+0xC0]
0000796da41d2e79  vmovaps [rsp+0xC0], xmm15
0000796da41d2e82  movaps xmm13, xmm11
0000796da41d2e86  mulpd xmm13, xmm1
0000796da41d2e8b  vcmppd xmm15, xmm13, xmm13, 0x03
0000796da41d2e91  ptest xmm15, xmm15
0000796da41d2e97  jnz 0x0000796DA41D55A0
0000796da41d2e9d  lea rax, [r14+0xC0]
0000796da41d2ea4  movups xmm1, [r13+rax*1]
0000796da41d2eaa  vmovaps xmm11, [rsp+0x100]
0000796da41d2eb3  vmovaps [rsp+0xF0], xmm1
0000796da41d2ebc  vmovaps xmm1, [rsp+0x20]
0000796da41d2ec2  vmovaps [rsp+0x20], xmm14
0000796da41d2ec8  movaps xmm15, xmm11
0000796da41d2ecc  addpd xmm15, xmm1
0000796da41d2ed1  vcmppd xmm14, xmm15, xmm15, 0x03
0000796da41d2ed7  ptest xmm14, xmm14
0000796da41d2edd  jnz 0x0000796DA41D56ED
0000796da41d2ee3  vmovaps [rsp+0x100], xmm9
0000796da41d2eec  vmovaps xmm1, [rsp+0x100]
0000796da41d2ef5  por xmm9, xmm1
0000796da41d2efa  movaps [r15+0x270], xmm9
0000796da41d2f02  vmovaps [rsp+0x100], xmm6
0000796da41d2f0b  vmovaps xmm1, [rsp+0x100]
0000796da41d2f14  por xmm6, xmm1
0000796da41d2f18  movaps [r15+0x1A0], xmm6
0000796da41d2f20  vmovaps xmm14, [rsp+0xB0]
0000796da41d2f29  vpermilpd xmm14, xmm14, 0x00
0000796da41d2f2f  vmovaps xmm6, [rsp+0xF0]
0000796da41d2f38  vmovaps [rsp+0xF0], xmm1
0000796da41d2f41  movaps xmm11, xmm6
0000796da41d2f45  mulpd xmm11, xmm14
0000796da41d2f4a  vcmppd xmm1, xmm11, xmm11, 0x03
0000796da41d2f50  ptest xmm1, xmm1
0000796da41d2f55  jnz 0x0000796DA41D5830
0000796da41d2f5b  lea rax, [r14+0x20]
0000796da41d2f5f  movups xmm1, [r13+rax*1]
0000796da41d2f65  movaps [r15+0x110], xmm1
0000796da41d2f6d  vmovaps xmm6, [rsp+0xE0]
0000796da41d2f76  vmovaps [rsp+0xE0], xmm1
0000796da41d2f7f  movaps xmm14, xmm6
0000796da41d2f83  addpd xmm14, xmm2
0000796da41d2f88  vcmppd xmm1, xmm14, xmm14, 0x03
0000796da41d2f8e  ptest xmm1, xmm1
0000796da41d2f93  jnz 0x0000796DA41D597D
0000796da41d2f99  vmovaps xmm1, [rsp+0xB0]
0000796da41d2fa2  vpermilpd xmm1, xmm1, 0x00
0000796da41d2fa8  movaps xmm6, xmm5
0000796da41d2fab  mulpd xmm6, xmm1
0000796da41d2faf  vcmppd xmm2, xmm6, xmm6, 0x03
0000796da41d2fb4  ptest xmm2, xmm2
0000796da41d2fb9  jnz 0x0000796DA41D5ABF
0000796da41d2fbf  vmovaps xmm5, [rsp+0x10]
0000796da41d2fc5  movaps xmm1, xmm5
0000796da41d2fc8  addpd xmm1, xmm13
0000796da41d2fcd  vcmppd xmm2, xmm1, xmm1, 0x03
0000796da41d2fd2  ptest xmm2, xmm2
0000796da41d2fd7  jnz 0x0000796DA41D5BFF
0000796da41d2fdd  vmovaps xmm13, [rsp+0x80]
0000796da41d2fe6  vpermilpd xmm13, xmm13, 0x00
0000796da41d2fec  vmovaps xmm2, [rsp+0xE0]
0000796da41d2ff5  vmovaps [rsp+0x10], xmm1
0000796da41d2ffb  movaps xmm5, xmm2
0000796da41d2ffe  mulpd xmm5, xmm13
0000796da41d3003  vcmppd xmm1, xmm5, xmm5, 0x03
0000796da41d3008  ptest xmm1, xmm1
0000796da41d300d  jnz 0x0000796DA41D5D40
0000796da41d3013  vmovaps xmm1, [rsp+0x80]
0000796da41d301c  vpermilpd xmm1, xmm1, 0x00
0000796da41d3022  movaps xmm13, xmm10
0000796da41d3026  mulpd xmm13, xmm1
0000796da41d302b  vcmppd xmm2, xmm13, xmm13, 0x03
0000796da41d3031  ptest xmm2, xmm2
0000796da41d3036  jnz 0x0000796DA41D5E81
0000796da41d303c  vmovaps xmm10, [rsp+0x20]
0000796da41d3042  movaps xmm1, xmm15
0000796da41d3046  addpd xmm1, xmm10
0000796da41d304b  vcmppd xmm2, xmm1, xmm1, 0x03
0000796da41d3050  ptest xmm2, xmm2
0000796da41d3055  jnz 0x0000796DA41D5FC4
0000796da41d305b  vmovaps xmm10, [rsp+0xC0]
0000796da41d3064  movaps xmm15, xmm10
0000796da41d3068  addpd xmm15, xmm11
0000796da41d306d  vcmppd xmm2, xmm15, xmm15, 0x03
0000796da41d3073  ptest xmm2, xmm2
0000796da41d3078  jnz 0x0000796DA41D6106
0000796da41d307e  vmovaps xmm11, [rsp+0x80]
0000796da41d3087  vpermilpd xmm11, xmm11, 0x00
0000796da41d308d  vmovaps xmm2, [rsp+0xD0]
0000796da41d3096  vmovaps [rsp+0x20], xmm1
0000796da41d309c  movaps xmm10, xmm2
0000796da41d30a0  mulpd xmm10, xmm11
0000796da41d30a5  vcmppd xmm1, xmm10, xmm10, 0x03
0000796da41d30ab  ptest xmm1, xmm1
0000796da41d30b0  jnz 0x0000796DA41D624A
0000796da41d30b6  vmovaps xmm1, [rsp+0x80]
0000796da41d30bf  vpermilpd xmm1, xmm1, 0x00
0000796da41d30c5  vmovaps xmm2, [rsp+0xA0]
0000796da41d30ce  vmovaps [rsp+0x80], xmm15
0000796da41d30d7  movaps xmm11, xmm2
0000796da41d30db  mulpd xmm11, xmm1
0000796da41d30e0  vcmppd xmm15, xmm11, xmm11, 0x03
0000796da41d30e6  ptest xmm15, xmm15
0000796da41d30ec  jnz 0x0000796DA41D638D
0000796da41d30f2  movaps xmm1, xmm14
0000796da41d30f6  addpd xmm1, xmm6
0000796da41d30fa  vcmppd xmm15, xmm1, xmm1, 0x03
0000796da41d30ff  ptest xmm15, xmm15
0000796da41d3105  jnz 0x0000796DA41D64CF
0000796da41d310b  vmovaps xmm14, [rsp+0x10]
0000796da41d3111  movaps xmm15, xmm14
0000796da41d3115  addpd xmm15, xmm5
0000796da41d311a  vcmppd xmm6, xmm15, xmm15, 0x03
0000796da41d3120  ptest xmm6, xmm6
0000796da41d3125  jnz 0x0000796DA41D6610
0000796da41d312b  vmovaps xmm14, [rsp+0x90]
0000796da41d3134  vpermilpd xmm14, xmm14, 0x00
0000796da41d313a  movaps xmm6, xmm9
0000796da41d313e  mulpd xmm6, xmm14
0000796da41d3143  vcmppd xmm5, xmm6, xmm6, 0x03
0000796da41d3148  ptest xmm5, xmm5
0000796da41d314d  jnz 0x0000796DA41D6753
0000796da41d3153  vmovaps xmm9, [rsp+0x80]
0000796da41d315c  movaps xmm14, xmm9
0000796da41d3160  addpd xmm14, xmm13
0000796da41d3165  vcmppd xmm5, xmm14, xmm14, 0x03
0000796da41d316b  ptest xmm5, xmm5
0000796da41d3170  jnz 0x0000796DA41D6895
0000796da41d3176  vmovaps xmm9, [rsp+0x20]
0000796da41d317c  movaps xmm13, xmm9
0000796da41d3180  addpd xmm13, xmm10
0000796da41d3185  vcmppd xmm5, xmm13, xmm13, 0x03
0000796da41d318b  ptest xmm5, xmm5
0000796da41d3190  jnz 0x0000796DA41D69D9
0000796da41d3196  vmovaps [rsp+0x10], xmm12
0000796da41d319c  vmovaps xmm10, [rsp+0x10]
0000796da41d31a2  por xmm12, xmm10
0000796da41d31a7  movaps [r15+0x250], xmm12
0000796da41d31af  vmovaps [rsp+0x10], xmm7
0000796da41d31b5  vmovaps xmm12, [rsp+0x10]
0000796da41d31bb  por xmm7, xmm12
0000796da41d31c0  movaps [r15+0x2A0], xmm7
0000796da41d31c8  vmovaps [rsp+0x10], xmm3
0000796da41d31ce  vmovaps xmm12, [rsp+0x10]
0000796da41d31d4  por xmm3, xmm12
0000796da41d31d9  movaps [r15+0x1D0], xmm3
0000796da41d31e1  lea rax, [r14+0x40]
0000796da41d31e5  movups xmm12, [r13+rax*1]
0000796da41d31eb  movaps [r15+0x2C0], xmm12
0000796da41d31f3  vmovaps xmm10, [rsp+0x90]
0000796da41d31fc  vpermilpd xmm10, xmm10, 0x00
0000796da41d3202  movaps xmm9, xmm8
0000796da41d3206  mulpd xmm9, xmm10
0000796da41d320b  vcmppd xmm5, xmm9, xmm9, 0x03
0000796da41d3211  ptest xmm5, xmm5
0000796da41d3216  jnz 0x0000796DA41D6B27
0000796da41d321c  movaps xmm10, xmm1
0000796da41d3220  addpd xmm10, xmm11
0000796da41d3225  vcmppd xmm8, xmm10, xmm10, 0x03
0000796da41d322b  ptest xmm8, xmm8
0000796da41d3231  jnz 0x0000796DA41D6C6B
0000796da41d3237  movaps xmm1, xmm15
0000796da41d323b  addpd xmm1, xmm6
0000796da41d323f  vcmppd xmm11, xmm1, xmm1, 0x03
0000796da41d3244  ptest xmm11, xmm11
0000796da41d324a  jnz 0x0000796DA41D6DAE
0000796da41d3250  vmovaps xmm15, [rsp+0x90]
0000796da41d3259  vpermilpd xmm15, xmm15, 0x00
0000796da41d325f  movaps xmm11, xmm12
0000796da41d3263  mulpd xmm11, xmm15
0000796da41d3268  vcmppd xmm8, xmm11, xmm11, 0x03
0000796da41d326e  ptest xmm8, xmm8
0000796da41d3274  jnz 0x0000796DA41D6EEF
0000796da41d327a  vmovaps xmm15, [rsp+0x90]
0000796da41d3283  vpermilpd xmm15, xmm15, 0x00
0000796da41d3289  vmovaps xmm8, [rsp+0x50]
0000796da41d328f  movaps xmm12, xmm8
0000796da41d3293  mulpd xmm12, xmm15
0000796da41d3298  vcmppd xmm6, xmm12, xmm12, 0x03
0000796da41d329e  ptest xmm6, xmm6
0000796da41d32a3  jnz 0x0000796DA41D7033
0000796da41d32a9  vmovaps xmm15, [rsp+0x30]
0000796da41d32af  vpermilpd xmm15, xmm15, 0x00
0000796da41d32b5  movaps xmm8, xmm7
0000796da41d32b9  mulpd xmm8, xmm15
0000796da41d32be  vcmppd xmm6, xmm8, xmm8, 0x03
0000796da41d32c4  ptest xmm6, xmm6
0000796da41d32c9  jnz 0x0000796DA41D7177
0000796da41d32cf  movaps xmm15, xmm14
0000796da41d32d3  addpd xmm15, xmm9
0000796da41d32d8  vcmppd xmm7, xmm15, xmm15, 0x03
0000796da41d32de  ptest xmm7, xmm7
0000796da41d32e3  jnz 0x0000796DA41D72BA
0000796da41d32e9  vmovaps xmm14, [rsp+0x30]
0000796da41d32ef  vpermilpd xmm14, xmm14, 0x00
0000796da41d32f5  vmovaps xmm7, [rsp+0xF0]
0000796da41d32fe  movaps xmm9, xmm7
0000796da41d3302  mulpd xmm9, xmm14
0000796da41d3307  vcmppd xmm6, xmm9, xmm9, 0x03
0000796da41d330d  ptest xmm6, xmm6
0000796da41d3312  jnz 0x0000796DA41D73FE
0000796da41d3318  movaps xmm14, xmm13
0000796da41d331c  addpd xmm14, xmm11
0000796da41d3321  vcmppd xmm7, xmm14, xmm14, 0x03
0000796da41d3327  ptest xmm7, xmm7
0000796da41d332c  jnz 0x0000796DA41D7541
0000796da41d3332  vmovaps xmm13, [rsp+0x30]
0000796da41d3338  vpermilpd xmm13, xmm13, 0x00
0000796da41d333e  vmovaps xmm7, [rsp+0x60]
0000796da41d3344  movaps xmm11, xmm7
0000796da41d3348  mulpd xmm11, xmm13
0000796da41d334d  vcmppd xmm6, xmm11, xmm11, 0x03
0000796da41d3353  ptest xmm6, xmm6
0000796da41d3358  jnz 0x0000796DA41D7685
0000796da41d335e  movaps xmm13, xmm10
0000796da41d3362  addpd xmm13, xmm12
0000796da41d3367  vcmppd xmm7, xmm13, xmm13, 0x03
0000796da41d336d  ptest xmm7, xmm7
0000796da41d3372  jnz 0x0000796DA41D77C8
0000796da41d3378  vmovaps xmm12, [rsp+0x30]
0000796da41d337e  vpermilpd xmm12, xmm12, 0x00
0000796da41d3384  vmovaps xmm7, [rsp+0x70]
0000796da41d338a  movaps xmm10, xmm7
0000796da41d338e  mulpd xmm10, xmm12
0000796da41d3393  vcmppd xmm6, xmm10, xmm10, 0x03
0000796da41d3399  ptest xmm6, xmm6
0000796da41d339e  jnz 0x0000796DA41D790C
0000796da41d33a4  movaps xmm12, xmm1
0000796da41d33a8  addpd xmm12, xmm8
0000796da41d33ad  vcmppd xmm7, xmm12, xmm12, 0x03
0000796da41d33b3  ptest xmm7, xmm7
0000796da41d33b8  jnz 0x0000796DA41D7A4F
0000796da41d33be  lea rax, [r14+0x70]
0000796da41d33c2  movups xmm1, [r13+rax*1]
0000796da41d33c8  movaps [r15+0x240], xmm1
0000796da41d33d0  movaps xmm8, xmm15
0000796da41d33d4  addpd xmm8, xmm9
0000796da41d33d9  vcmppd xmm7, xmm8, xmm8, 0x03
0000796da41d33df  ptest xmm7, xmm7
0000796da41d33e4  jnz 0x0000796DA41D7B9C
0000796da41d33ea  movaps [r15+0x170], xmm8
0000796da41d33f2  vmovaps xmm15, [rsp+0x40]
0000796da41d33f8  vpermilpd xmm15, xmm15, 0x00
0000796da41d33fe  movaps xmm9, xmm1
0000796da41d3402  mulpd xmm9, xmm15
0000796da41d3407  vcmppd xmm7, xmm9, xmm9, 0x03
0000796da41d340d  ptest xmm7, xmm7
0000796da41d3412  jnz 0x0000796DA41D7CE0
0000796da41d3418  vmovaps xmm1, [rsp+0x40]
0000796da41d341e  vpermilpd xmm1, xmm1, 0x00
0000796da41d3424  movaps xmm15, xmm4
0000796da41d3428  mulpd xmm15, xmm1
0000796da41d342d  vcmppd xmm7, xmm15, xmm15, 0x03
0000796da41d3433  ptest xmm7, xmm7
0000796da41d3438  jnz 0x0000796DA41D7E23
0000796da41d343e  movaps [r15+0x180], xmm15
0000796da41d3446  movaps xmm1, xmm14
0000796da41d344a  addpd xmm1, xmm11
0000796da41d344f  vcmppd xmm7, xmm1, xmm1, 0x03
0000796da41d3454  ptest xmm7, xmm7
0000796da41d3459  jnz 0x0000796DA41D7F65
0000796da41d345f  movaps [r15+0x210], xmm1
0000796da41d3467  movups xmm14, [r13+r14*1]
0000796da41d346d  lea rax, [r14+0x10]
0000796da41d3471  movups xmm11, [r13+rax*1]
0000796da41d3477  movaps [r15+0x230], xmm11
0000796da41d347f  movaps xmm7, xmm13
0000796da41d3483  addpd xmm7, xmm10
0000796da41d3488  vcmppd xmm6, xmm7, xmm7, 0x03
0000796da41d348d  ptest xmm6, xmm6
0000796da41d3492  jnz 0x0000796DA41D80BB
0000796da41d3498  movaps [r15+0x130], xmm7
0000796da41d34a0  vmovaps xmm13, [rsp+0x40]
0000796da41d34a6  vpermilpd xmm13, xmm13, 0x00
0000796da41d34ac  movaps xmm10, xmm11
0000796da41d34b0  mulpd xmm10, xmm13
0000796da41d34b5  vcmppd xmm6, xmm10, xmm10, 0x03
0000796da41d34bb  ptest xmm6, xmm6
0000796da41d34c0  jnz 0x0000796DA41D81FD
0000796da41d34c6  movaps [r15+0x220], xmm10
0000796da41d34ce  vmovaps xmm13, [rsp+0x40]
0000796da41d34d4  vpermilpd xmm13, xmm13, 0x00
0000796da41d34da  movaps xmm11, xmm14
0000796da41d34de  mulpd xmm11, xmm13
0000796da41d34e3  vcmppd xmm6, xmm11, xmm11, 0x03
0000796da41d34e9  ptest xmm6, xmm6
0000796da41d34ee  jnz 0x0000796DA41D8341
0000796da41d34f4  movaps xmm14, xmm12
0000796da41d34f8  addpd xmm14, xmm9
0000796da41d34fd  vcmppd xmm13, xmm14, xmm14, 0x03
0000796da41d3503  ptest xmm13, xmm13
0000796da41d3509  jnz 0x0000796DA41D8485
0000796da41d350f  movaps [r15+0x140], xmm14
0000796da41d3517  movaps xmm13, xmm8
0000796da41d351b  addpd xmm13, xmm15
0000796da41d3520  vcmppd xmm12, xmm13, xmm13, 0x03
0000796da41d3526  ptest xmm12, xmm12
0000796da41d352c  jnz 0x0000796DA41D85C9
0000796da41d3532  movaps [r15+0x150], xmm13
0000796da41d353a  movaps xmm15, xmm1
0000796da41d353e  addpd xmm15, xmm10
0000796da41d3543  vcmppd xmm12, xmm15, xmm15, 0x03
0000796da41d3549  ptest xmm12, xmm12
0000796da41d354f  jnz 0x0000796DA41D870D
0000796da41d3555  movaps [r15+0x160], xmm15
0000796da41d355d  movaps xmm1, xmm7
0000796da41d3560  addpd xmm1, xmm11
0000796da41d3565  vcmppd xmm12, xmm1, xmm1, 0x03
0000796da41d356a  ptest xmm12, xmm12
0000796da41d3570  jnz 0x0000796DA41D8850
0000796da41d3576  movaps [r15+0x120], xmm1
0000796da41d357e  mov eax, 0x432200
0000796da41d3583  movups [r13+rax*1], xmm14
0000796da41d3589  mov eax, 0x432210
0000796da41d358e  movups [r13+rax*1], xmm13
0000796da41d3594  mov eax, 0x432220
0000796da41d3599  movups [r13+rax*1], xmm15
0000796da41d359f  mov eax, 0x432230
0000796da41d35a4  movups [r13+rax*1], xmm1
0000796da41d35aa  mov eax, [r15+0x108]
0000796da41d35b1  sahf
0000796da41d35b2  jnz 0x0000796DA41D35E4
0000796da41d35b4  cmp dword ptr [r15+0x318], 0x00
0000796da41d35bc  jz 0x0000796DA41DEAE0
0000796da41d35c2  nop [rax+rax*1], ax
0000796da41d35cb  nop [rax+rax*1], eax
0000796da41d35d3  mov eax, 0x4106D0
0000796da41d35d8  mov [r15+0x100], rax
0000796da41d35df  jmp 0x0000796DA3FFE110
0000796da41d35e4  cmp dword ptr [r15+0x318], 0x00
0000796da41d35ec  jz 0x0000796DA41D89C0
0000796da41d35f2  nop [rax+rax*1], ax
0000796da41d35fb  nop [rax+rax*1], eax
0000796da41d3603  mov eax, 0x410504
0000796da41d3608  mov [r15+0x100], rax
0000796da41d360f  jmp 0x0000796DA3FFE110
0000796da41d3614  int3
0000796da41d3615  call 0x0000796DA40D64F0
0000796da41d361a  jmp 0x0000796DA41D2311
0000796da41d361f  call 0x0000796DA40E5820
0000796da41d3624  jmp 0x0000796DA41D231E
0000796da41d3629  call 0x0000796DA40E3320
0000796da41d362e  jmp 0x0000796DA41D2332
0000796da41d3633  call 0x0000796DA40E20A0
0000796da41d3638  jmp 0x0000796DA41D233C
0000796da41d363d  call 0x0000796DA4009D70
0000796da41d3642  jmp 0x0000796DA41D234A
0000796da41d3647  call 0x0000796DA40DFBC0
0000796da41d364c  jmp 0x0000796DA41D2354
0000796da41d3651  call 0x0000796DA40C4740
0000796da41d3656  jmp 0x0000796DA41D2368
0000796da41d365b  call 0x0000796DA40B5400
0000796da41d3660  jmp 0x0000796DA41D2375
0000796da41d3665  call 0x0000796DA40B52F0
0000796da41d366a  jmp 0x0000796DA41D2382
0000796da41d366f  call 0x0000796DA40C4620
0000796da41d3674  jmp 0x0000796DA41D238F
0000796da41d3679  call 0x0000796DA40BD750
0000796da41d367e  jmp 0x0000796DA41D239C
0000796da41d3683  call 0x0000796DA40BC4E0
0000796da41d3688  jmp 0x0000796DA41D23A9
0000796da41d368d  call 0x0000796DA40BB270
0000796da41d3692  jmp 0x0000796DA41D23B6
0000796da41d3697  call 0x0000796DA40BA000
0000796da41d369c  jmp 0x0000796DA41D23C3
0000796da41d36a1  call 0x0000796DA40C4740
0000796da41d36a6  jmp 0x0000796DA41D23D0
0000796da41d36ab  call 0x0000796DA40B5400
0000796da41d36b0  jmp 0x0000796DA41D23DD
0000796da41d36b5  call 0x0000796DA40B52F0
0000796da41d36ba  jmp 0x0000796DA41D23EA
0000796da41d36bf  call 0x0000796DA40C4620
0000796da41d36c4  jmp 0x0000796DA41D23F7
0000796da41d36c9  call 0x0000796DA40B8D90
0000796da41d36ce  jmp 0x0000796DA41D2404
0000796da41d36d3  call 0x0000796DA40B8A20
0000796da41d36d8  jmp 0x0000796DA41D2411
0000796da41d36dd  call 0x0000796DA40B77B0
0000796da41d36e2  jmp 0x0000796DA41D241B
0000796da41d36e7  call 0x0000796DA40B6550
0000796da41d36ec  jmp 0x0000796DA41D2425
0000796da41d36f1  call 0x0000796DA40B5400
0000796da41d36f6  jmp 0x0000796DA41D2437
0000796da41d36fb  call 0x0000796DA40C0FC0
0000796da41d3700  jmp 0x0000796DA41D2441
0000796da41d3705  call 0x0000796DA40B52F0
0000796da41d370a  jmp 0x0000796DA41D244B
0000796da41d370f  call 0x0000796DA40C0EA0
0000796da41d3714  jmp 0x0000796DA41D2455
0000796da41d3719  call 0x0000796DA40BFD50
0000796da41d371e  jmp 0x0000796DA41D245F
0000796da41d3723  call 0x0000796DA40B8EA0
0000796da41d3728  jmp 0x0000796DA41D2469
0000796da41d372d  call 0x0000796DA40BFC30
0000796da41d3732  jmp 0x0000796DA41D2476
0000796da41d3737  call 0x0000796DA40B8D90
0000796da41d373c  jmp 0x0000796DA41D2483
0000796da41d3741  call 0x0000796DA40B52F0
0000796da41d3746  jmp 0x0000796DA41D2496
0000796da41d374b  call 0x0000796DA40B52F0
0000796da41d3750  jmp 0x0000796DA41D24A9
0000796da41d3755  call 0x0000796DA40C0FC0
0000796da41d375a  jmp 0x0000796DA41D24B6
0000796da41d375f  call 0x0000796DA40C0FC0
0000796da41d3764  jmp 0x0000796DA41D24C9
0000796da41d3769  call 0x0000796DA40C0EA0
0000796da41d376e  jmp 0x0000796DA41D24D6
0000796da41d3773  call 0x0000796DA40B52F0
0000796da41d3778  jmp 0x0000796DA41D24E9
0000796da41d377d  call 0x0000796DA40B52F0
0000796da41d3782  jmp 0x0000796DA41D24FC
0000796da41d3787  call 0x0000796DA40B52F0
0000796da41d378c  jmp 0x0000796DA41D250F
0000796da41d3791  call 0x0000796DA40B52F0
0000796da41d3796  jmp 0x0000796DA41D252A
0000796da41d379b  call 0x0000796DA40B52F0
0000796da41d37a0  jmp 0x0000796DA41D253D
0000796da41d37a5  call 0x0000796DA40B5400
0000796da41d37aa  jmp 0x0000796DA41D257E
0000796da41d37af  call 0x0000796DA40C0FC0
0000796da41d37b4  jmp 0x0000796DA41D258B
0000796da41d37b9  call 0x0000796DA40B52F0
0000796da41d37be  jmp 0x0000796DA41D2598
0000796da41d37c3  call 0x0000796DA40C0EA0
0000796da41d37c8  jmp 0x0000796DA41D25A5
0000796da41d37cd  call 0x0000796DA3FFF540
0000796da41d37d2  jmp 0x0000796DA41D25C3
0000796da41d37d7  call 0x0000796DA4008C20
0000796da41d37dc  jmp 0x0000796DA41D25CD
0000796da41d37e1  call 0x0000796DA40E21C0
0000796da41d37e6  jmp 0x0000796DA41D25D3
0000796da41d37eb  call 0x0000796DA3FFF540
0000796da41d37f0  jmp 0x0000796DA41D25E3
0000796da41d37f5  call 0x0000796DA40C0370
0000796da41d37fa  jmp 0x0000796DA41D2611
0000796da41d37ff  call 0x0000796DA40BF100
0000796da41d3804  jmp 0x0000796DA41D261A
0000796da41d3809  call 0x0000796DA40C0370
0000796da41d380e  jmp 0x0000796DA41D2674
0000796da41d3813  call 0x0000796DA40BF100
0000796da41d3818  jmp 0x0000796DA41D267D
0000796da41d381d  call 0x0000796DA40C0370
0000796da41d3822  jmp 0x0000796DA41D26C6
0000796da41d3827  call 0x0000796DA40BF100
0000796da41d382c  jmp 0x0000796DA41D26CF
0000796da41d3831  call 0x0000796DA400B720
0000796da41d3836  jmp 0x0000796DA41D2714
0000796da41d383b  call 0x0000796DA40B47C0
0000796da41d3840  jmp 0x0000796DA41D2727
0000796da41d3845  call 0x0000796DA4008B00
0000796da41d384a  jmp 0x0000796DA41D273E
0000796da41d384f  call 0x0000796DA3FFF430
0000796da41d3854  jmp 0x0000796DA41D2751
0000796da41d3859  call 0x0000796DA3FFF430
0000796da41d385e  jmp 0x0000796DA41D2764
0000796da41d3863  sub rsp, 0x08
0000796da41d3867  push rax
0000796da41d3868  push rcx
0000796da41d3869  push rdx
0000796da41d386a  push rdi
0000796da41d386b  push rsi
0000796da41d386c  push r8
0000796da41d386e  push r9
0000796da41d3870  push r10
0000796da41d3872  push r11
0000796da41d3874  sub rsp, 0xF0
0000796da41d387b  vmovaps [rsp], xmm0
0000796da41d3880  vmovaps [rsp+0x10], xmm2
0000796da41d3886  vmovaps [rsp+0x20], xmm3
0000796da41d388c  vmovaps [rsp+0x30], xmm4
0000796da41d3892  vmovaps [rsp+0x40], xmm5
0000796da41d3898  vmovaps [rsp+0x50], xmm6
0000796da41d389e  vmovaps [rsp+0x60], xmm7
0000796da41d38a4  vmovaps [rsp+0x70], xmm8
0000796da41d38aa  vmovaps [rsp+0x80], xmm9
0000796da41d38b3  vmovaps [rsp+0x90], xmm10
0000796da41d38bc  vmovaps [rsp+0xA0], xmm11
0000796da41d38c5  vmovaps [rsp+0xB0], xmm12
0000796da41d38ce  vmovaps [rsp+0xC0], xmm13
0000796da41d38d7  vmovaps [rsp+0xD0], xmm14
0000796da41d38e0  vmovaps [rsp+0xE0], xmm15
0000796da41d38e9  sub rsp, 0x30
0000796da41d38ed  movaps [rsp], xmm1
0000796da41d38f1  movaps [rsp+0x10], xmm12
0000796da41d38f7  movaps [rsp+0x20], xmm15
0000796da41d38fd  lea rdi, [rsp]
0000796da41d3901  mov esi, 0x00
0000796da41d3906  mov rax, 0x5E26CB66A530
0000796da41d3910  call rax
0000796da41d3912  movaps xmm1, [rsp]
0000796da41d3916  add rsp, 0x30
0000796da41d391a  vmovaps xmm0, [rsp]
0000796da41d391f  vmovaps xmm2, [rsp+0x10]
0000796da41d3925  vmovaps xmm3, [rsp+0x20]
0000796da41d392b  vmovaps xmm4, [rsp+0x30]
0000796da41d3931  vmovaps xmm5, [rsp+0x40]
0000796da41d3937  vmovaps xmm6, [rsp+0x50]
0000796da41d393d  vmovaps xmm7, [rsp+0x60]
0000796da41d3943  vmovaps xmm8, [rsp+0x70]
0000796da41d3949  vmovaps xmm9, [rsp+0x80]
0000796da41d3952  vmovaps xmm10, [rsp+0x90]
0000796da41d395b  vmovaps xmm11, [rsp+0xA0]
0000796da41d3964  vmovaps xmm12, [rsp+0xB0]
0000796da41d396d  vmovaps xmm13, [rsp+0xC0]
0000796da41d3976  vmovaps xmm14, [rsp+0xD0]
0000796da41d397f  vmovaps xmm15, [rsp+0xE0]
0000796da41d3988  add rsp, 0xF0
0000796da41d398f  pop r11
0000796da41d3991  pop r10
0000796da41d3993  pop r9
0000796da41d3995  pop r8
0000796da41d3997  pop rsi
0000796da41d3998  pop rdi
0000796da41d3999  pop rdx
0000796da41d399a  pop rcx
0000796da41d399b  pop rax
0000796da41d399c  add rsp, 0x08
0000796da41d39a0  jmp 0x0000796DA41D27B2
0000796da41d39a5  sub rsp, 0x08
0000796da41d39a9  push rax
0000796da41d39aa  push rcx
0000796da41d39ab  push rdx
0000796da41d39ac  push rdi
0000796da41d39ad  push rsi
0000796da41d39ae  push r8
0000796da41d39b0  push r9
0000796da41d39b2  push r10
0000796da41d39b4  push r11
0000796da41d39b6  sub rsp, 0xF0
0000796da41d39bd  vmovaps [rsp], xmm0
0000796da41d39c2  vmovaps [rsp+0x10], xmm1
0000796da41d39c8  vmovaps [rsp+0x20], xmm2
0000796da41d39ce  vmovaps [rsp+0x30], xmm3
0000796da41d39d4  vmovaps [rsp+0x40], xmm4
0000796da41d39da  vmovaps [rsp+0x50], xmm5
0000796da41d39e0  vmovaps [rsp+0x60], xmm6
0000796da41d39e6  vmovaps [rsp+0x70], xmm7
0000796da41d39ec  vmovaps [rsp+0x80], xmm8
0000796da41d39f5  vmovaps [rsp+0x90], xmm9
0000796da41d39fe  vmovaps [rsp+0xA0], xmm10
0000796da41d3a07  vmovaps [rsp+0xB0], xmm11
0000796da41d3a10  vmovaps [rsp+0xC0], xmm12
0000796da41d3a19  vmovaps [rsp+0xD0], xmm13
0000796da41d3a22  vmovaps [rsp+0xE0], xmm15
0000796da41d3a2b  sub rsp, 0x30
0000796da41d3a2f  movaps [rsp], xmm14
0000796da41d3a34  movaps [rsp+0x10], xmm1
0000796da41d3a39  movaps [rsp+0x20], xmm15
0000796da41d3a3f  lea rdi, [rsp]
0000796da41d3a43  mov esi, 0x00
0000796da41d3a48  mov rax, 0x5E26CB66A530
0000796da41d3a52  call rax
0000796da41d3a54  movaps xmm14, [rsp]
0000796da41d3a59  add rsp, 0x30
0000796da41d3a5d  vmovaps xmm0, [rsp]
0000796da41d3a62  vmovaps xmm1, [rsp+0x10]
0000796da41d3a68  vmovaps xmm2, [rsp+0x20]
0000796da41d3a6e  vmovaps xmm3, [rsp+0x30]
0000796da41d3a74  vmovaps xmm4, [rsp+0x40]
0000796da41d3a7a  vmovaps xmm5, [rsp+0x50]
0000796da41d3a80  vmovaps xmm6, [rsp+0x60]
0000796da41d3a86  vmovaps xmm7, [rsp+0x70]
0000796da41d3a8c  vmovaps xmm8, [rsp+0x80]
0000796da41d3a95  vmovaps xmm9, [rsp+0x90]
0000796da41d3a9e  vmovaps xmm10, [rsp+0xA0]
0000796da41d3aa7  vmovaps xmm11, [rsp+0xB0]
0000796da41d3ab0  vmovaps xmm12, [rsp+0xC0]
0000796da41d3ab9  vmovaps xmm13, [rsp+0xD0]
0000796da41d3ac2  vmovaps xmm15, [rsp+0xE0]
0000796da41d3acb  add rsp, 0xF0
0000796da41d3ad2  pop r11
0000796da41d3ad4  pop r10
0000796da41d3ad6  pop r9
0000796da41d3ad8  pop r8
0000796da41d3ada  pop rsi
0000796da41d3adb  pop rdi
0000796da41d3adc  pop rdx
0000796da41d3add  pop rcx
0000796da41d3ade  pop rax
0000796da41d3adf  add rsp, 0x08
0000796da41d3ae3  jmp 0x0000796DA41D2800
0000796da41d3ae8  sub rsp, 0x08
0000796da41d3aec  push rax
0000796da41d3aed  push rcx
0000796da41d3aee  push rdx
0000796da41d3aef  push rdi
0000796da41d3af0  push rsi
0000796da41d3af1  push r8
0000796da41d3af3  push r9
0000796da41d3af5  push r10
0000796da41d3af7  push r11
0000796da41d3af9  sub rsp, 0xF0
0000796da41d3b00  vmovaps [rsp], xmm0
0000796da41d3b05  vmovaps [rsp+0x10], xmm1
0000796da41d3b0b  vmovaps [rsp+0x20], xmm2
0000796da41d3b11  vmovaps [rsp+0x30], xmm3
0000796da41d3b17  vmovaps [rsp+0x40], xmm4
0000796da41d3b1d  vmovaps [rsp+0x50], xmm5
0000796da41d3b23  vmovaps [rsp+0x60], xmm6
0000796da41d3b29  vmovaps [rsp+0x70], xmm7
0000796da41d3b2f  vmovaps [rsp+0x80], xmm8
0000796da41d3b38  vmovaps [rsp+0x90], xmm9
0000796da41d3b41  vmovaps [rsp+0xA0], xmm10
0000796da41d3b4a  vmovaps [rsp+0xB0], xmm11
0000796da41d3b53  vmovaps [rsp+0xC0], xmm12
0000796da41d3b5c  vmovaps [rsp+0xD0], xmm13
0000796da41d3b65  vmovaps [rsp+0xE0], xmm14
0000796da41d3b6e  sub rsp, 0x30
0000796da41d3b72  movaps [rsp], xmm15
0000796da41d3b77  movaps [rsp+0x10], xmm12
0000796da41d3b7d  movaps [rsp+0x20], xmm13
0000796da41d3b83  lea rdi, [rsp]
0000796da41d3b87  mov esi, 0x00
0000796da41d3b8c  mov rax, 0x5E26CB66A530
0000796da41d3b96  call rax
0000796da41d3b98  movaps xmm15, [rsp]
0000796da41d3b9d  add rsp, 0x30
0000796da41d3ba1  vmovaps xmm0, [rsp]
0000796da41d3ba6  vmovaps xmm1, [rsp+0x10]
0000796da41d3bac  vmovaps xmm2, [rsp+0x20]
0000796da41d3bb2  vmovaps xmm3, [rsp+0x30]
0000796da41d3bb8  vmovaps xmm4, [rsp+0x40]
0000796da41d3bbe  vmovaps xmm5, [rsp+0x50]
0000796da41d3bc4  vmovaps xmm6, [rsp+0x60]
0000796da41d3bca  vmovaps xmm7, [rsp+0x70]
0000796da41d3bd0  vmovaps xmm8, [rsp+0x80]
0000796da41d3bd9  vmovaps xmm9, [rsp+0x90]
0000796da41d3be2  vmovaps xmm10, [rsp+0xA0]
0000796da41d3beb  vmovaps xmm11, [rsp+0xB0]
0000796da41d3bf4  vmovaps xmm12, [rsp+0xC0]
0000796da41d3bfd  vmovaps xmm13, [rsp+0xD0]
0000796da41d3c06  vmovaps xmm14, [rsp+0xE0]
0000796da41d3c0f  add rsp, 0xF0
0000796da41d3c16  pop r11
0000796da41d3c18  pop r10
0000796da41d3c1a  pop r9
0000796da41d3c1c  pop r8
0000796da41d3c1e  pop rsi
0000796da41d3c1f  pop rdi
0000796da41d3c20  pop rdx
0000796da41d3c21  pop rcx
0000796da41d3c22  pop rax
0000796da41d3c23  add rsp, 0x08
0000796da41d3c27  jmp 0x0000796DA41D2835
0000796da41d3c2c  sub rsp, 0x08
0000796da41d3c30  push rax
0000796da41d3c31  push rcx
0000796da41d3c32  push rdx
0000796da41d3c33  push rdi
0000796da41d3c34  push rsi
0000796da41d3c35  push r8
0000796da41d3c37  push r9
0000796da41d3c39  push r10
0000796da41d3c3b  push r11
0000796da41d3c3d  sub rsp, 0xF0
0000796da41d3c44  vmovaps [rsp], xmm0
0000796da41d3c49  vmovaps [rsp+0x10], xmm2
0000796da41d3c4f  vmovaps [rsp+0x20], xmm3
0000796da41d3c55  vmovaps [rsp+0x30], xmm4
0000796da41d3c5b  vmovaps [rsp+0x40], xmm5
0000796da41d3c61  vmovaps [rsp+0x50], xmm6
0000796da41d3c67  vmovaps [rsp+0x60], xmm7
0000796da41d3c6d  vmovaps [rsp+0x70], xmm8
0000796da41d3c73  vmovaps [rsp+0x80], xmm9
0000796da41d3c7c  vmovaps [rsp+0x90], xmm10
0000796da41d3c85  vmovaps [rsp+0xA0], xmm11
0000796da41d3c8e  vmovaps [rsp+0xB0], xmm12
0000796da41d3c97  vmovaps [rsp+0xC0], xmm13
0000796da41d3ca0  vmovaps [rsp+0xD0], xmm14
0000796da41d3ca9  vmovaps [rsp+0xE0], xmm15
0000796da41d3cb2  sub rsp, 0x30
0000796da41d3cb6  movaps [rsp], xmm1
0000796da41d3cba  movaps [rsp+0x10], xmm12
0000796da41d3cc0  movaps [rsp+0x20], xmm10
0000796da41d3cc6  lea rdi, [rsp]
0000796da41d3cca  mov esi, 0x00
0000796da41d3ccf  mov rax, 0x5E26CB66A530
0000796da41d3cd9  call rax
0000796da41d3cdb  movaps xmm1, [rsp]
0000796da41d3cdf  add rsp, 0x30
0000796da41d3ce3  vmovaps xmm0, [rsp]
0000796da41d3ce8  vmovaps xmm2, [rsp+0x10]
0000796da41d3cee  vmovaps xmm3, [rsp+0x20]
0000796da41d3cf4  vmovaps xmm4, [rsp+0x30]
0000796da41d3cfa  vmovaps xmm5, [rsp+0x40]
0000796da41d3d00  vmovaps xmm6, [rsp+0x50]
0000796da41d3d06  vmovaps xmm7, [rsp+0x60]
0000796da41d3d0c  vmovaps xmm8, [rsp+0x70]
0000796da41d3d12  vmovaps xmm9, [rsp+0x80]
0000796da41d3d1b  vmovaps xmm10, [rsp+0x90]
0000796da41d3d24  vmovaps xmm11, [rsp+0xA0]
0000796da41d3d2d  vmovaps xmm12, [rsp+0xB0]
0000796da41d3d36  vmovaps xmm13, [rsp+0xC0]
0000796da41d3d3f  vmovaps xmm14, [rsp+0xD0]
0000796da41d3d48  vmovaps xmm15, [rsp+0xE0]
0000796da41d3d51  add rsp, 0xF0
0000796da41d3d58  pop r11
0000796da41d3d5a  pop r10
0000796da41d3d5c  pop r9
0000796da41d3d5e  pop r8
0000796da41d3d60  pop rsi
0000796da41d3d61  pop rdi
0000796da41d3d62  pop rdx
0000796da41d3d63  pop rcx
0000796da41d3d64  pop rax
0000796da41d3d65  add rsp, 0x08
0000796da41d3d69  jmp 0x0000796DA41D284F
0000796da41d3d6e  sub rsp, 0x08
0000796da41d3d72  push rax
0000796da41d3d73  push rcx
0000796da41d3d74  push rdx
0000796da41d3d75  push rdi
0000796da41d3d76  push rsi
0000796da41d3d77  push r8
0000796da41d3d79  push r9
0000796da41d3d7b  push r10
0000796da41d3d7d  push r11
0000796da41d3d7f  sub rsp, 0xF0
0000796da41d3d86  vmovaps [rsp], xmm0
0000796da41d3d8b  vmovaps [rsp+0x10], xmm1
0000796da41d3d91  vmovaps [rsp+0x20], xmm2
0000796da41d3d97  vmovaps [rsp+0x30], xmm3
0000796da41d3d9d  vmovaps [rsp+0x40], xmm4
0000796da41d3da3  vmovaps [rsp+0x50], xmm5
0000796da41d3da9  vmovaps [rsp+0x60], xmm6
0000796da41d3daf  vmovaps [rsp+0x70], xmm7
0000796da41d3db5  vmovaps [rsp+0x80], xmm8
0000796da41d3dbe  vmovaps [rsp+0x90], xmm9
0000796da41d3dc7  vmovaps [rsp+0xA0], xmm10
0000796da41d3dd0  vmovaps [rsp+0xB0], xmm11
0000796da41d3dd9  vmovaps [rsp+0xC0], xmm12
0000796da41d3de2  vmovaps [rsp+0xD0], xmm14
0000796da41d3deb  vmovaps [rsp+0xE0], xmm15
0000796da41d3df4  sub rsp, 0x30
0000796da41d3df8  movaps [rsp], xmm13
0000796da41d3dfd  movaps [rsp+0x10], xmm12
0000796da41d3e03  movaps [rsp+0x20], xmm2
0000796da41d3e08  lea rdi, [rsp]
0000796da41d3e0c  mov esi, 0x00
0000796da41d3e11  mov rax, 0x5E26CB66A530
0000796da41d3e1b  call rax
0000796da41d3e1d  movaps xmm13, [rsp]
0000796da41d3e22  add rsp, 0x30
0000796da41d3e26  vmovaps xmm0, [rsp]
0000796da41d3e2b  vmovaps xmm1, [rsp+0x10]
0000796da41d3e31  vmovaps xmm2, [rsp+0x20]
0000796da41d3e37  vmovaps xmm3, [rsp+0x30]
0000796da41d3e3d  vmovaps xmm4, [rsp+0x40]
0000796da41d3e43  vmovaps xmm5, [rsp+0x50]
0000796da41d3e49  vmovaps xmm6, [rsp+0x60]
0000796da41d3e4f  vmovaps xmm7, [rsp+0x70]
0000796da41d3e55  vmovaps xmm8, [rsp+0x80]
0000796da41d3e5e  vmovaps xmm9, [rsp+0x90]
0000796da41d3e67  vmovaps xmm10, [rsp+0xA0]
0000796da41d3e70  vmovaps xmm11, [rsp+0xB0]
0000796da41d3e79  vmovaps xmm12, [rsp+0xC0]
0000796da41d3e82  vmovaps xmm14, [rsp+0xD0]
0000796da41d3e8b  vmovaps xmm15, [rsp+0xE0]
0000796da41d3e94  add rsp, 0xF0
0000796da41d3e9b  pop r11
0000796da41d3e9d  pop r10
0000796da41d3e9f  pop r9
0000796da41d3ea1  pop r8
0000796da41d3ea3  pop rsi
0000796da41d3ea4  pop rdi
0000796da41d3ea5  pop rdx
0000796da41d3ea6  pop rcx
0000796da41d3ea7  pop rax
0000796da41d3ea8  add rsp, 0x08
0000796da41d3eac  jmp 0x0000796DA41D286A
0000796da41d3eb1  sub rsp, 0x08
0000796da41d3eb5  push rax
0000796da41d3eb6  push rcx
0000796da41d3eb7  push rdx
0000796da41d3eb8  push rdi
0000796da41d3eb9  push rsi
0000796da41d3eba  push r8
0000796da41d3ebc  push r9
0000796da41d3ebe  push r10
0000796da41d3ec0  push r11
0000796da41d3ec2  sub rsp, 0xF0
0000796da41d3ec9  vmovaps [rsp], xmm0
0000796da41d3ece  vmovaps [rsp+0x10], xmm2
0000796da41d3ed4  vmovaps [rsp+0x20], xmm3
0000796da41d3eda  vmovaps [rsp+0x30], xmm4
0000796da41d3ee0  vmovaps [rsp+0x40], xmm5
0000796da41d3ee6  vmovaps [rsp+0x50], xmm6
0000796da41d3eec  vmovaps [rsp+0x60], xmm7
0000796da41d3ef2  vmovaps [rsp+0x70], xmm8
0000796da41d3ef8  vmovaps [rsp+0x80], xmm9
0000796da41d3f01  vmovaps [rsp+0x90], xmm10
0000796da41d3f0a  vmovaps [rsp+0xA0], xmm11
0000796da41d3f13  vmovaps [rsp+0xB0], xmm12
0000796da41d3f1c  vmovaps [rsp+0xC0], xmm13
0000796da41d3f25  vmovaps [rsp+0xD0], xmm14
0000796da41d3f2e  vmovaps [rsp+0xE0], xmm15
0000796da41d3f37  sub rsp, 0x30
0000796da41d3f3b  movaps [rsp], xmm1
0000796da41d3f3f  movaps [rsp+0x10], xmm10
0000796da41d3f45  movaps [rsp+0x20], xmm2
0000796da41d3f4a  lea rdi, [rsp]
0000796da41d3f4e  mov esi, 0x00
0000796da41d3f53  mov rax, 0x5E26CB66A530
0000796da41d3f5d  call rax
0000796da41d3f5f  movaps xmm1, [rsp]
0000796da41d3f63  add rsp, 0x30
0000796da41d3f67  vmovaps xmm0, [rsp]
0000796da41d3f6c  vmovaps xmm2, [rsp+0x10]
0000796da41d3f72  vmovaps xmm3, [rsp+0x20]
0000796da41d3f78  vmovaps xmm4, [rsp+0x30]
0000796da41d3f7e  vmovaps xmm5, [rsp+0x40]
0000796da41d3f84  vmovaps xmm6, [rsp+0x50]
0000796da41d3f8a  vmovaps xmm7, [rsp+0x60]
0000796da41d3f90  vmovaps xmm8, [rsp+0x70]
0000796da41d3f96  vmovaps xmm9, [rsp+0x80]
0000796da41d3f9f  vmovaps xmm10, [rsp+0x90]
0000796da41d3fa8  vmovaps xmm11, [rsp+0xA0]
0000796da41d3fb1  vmovaps xmm12, [rsp+0xB0]
0000796da41d3fba  vmovaps xmm13, [rsp+0xC0]
0000796da41d3fc3  vmovaps xmm14, [rsp+0xD0]
0000796da41d3fcc  vmovaps xmm15, [rsp+0xE0]
0000796da41d3fd5  add rsp, 0xF0
0000796da41d3fdc  pop r11
0000796da41d3fde  pop r10
0000796da41d3fe0  pop r9
0000796da41d3fe2  pop r8
0000796da41d3fe4  pop rsi
0000796da41d3fe5  pop rdi
0000796da41d3fe6  pop rdx
0000796da41d3fe7  pop rcx
0000796da41d3fe8  pop rax
0000796da41d3fe9  add rsp, 0x08
0000796da41d3fed  jmp 0x0000796DA41D28D2
0000796da41d3ff2  sub rsp, 0x08
0000796da41d3ff6  push rax
0000796da41d3ff7  push rcx
0000796da41d3ff8  push rdx
0000796da41d3ff9  push rdi
0000796da41d3ffa  push rsi
0000796da41d3ffb  push r8
0000796da41d3ffd  push r9
0000796da41d3fff  push r10
0000796da41d4001  push r11
0000796da41d4003  sub rsp, 0xF0
0000796da41d400a  vmovaps [rsp], xmm0
0000796da41d400f  vmovaps [rsp+0x10], xmm1
0000796da41d4015  vmovaps [rsp+0x20], xmm2
0000796da41d401b  vmovaps [rsp+0x30], xmm3
0000796da41d4021  vmovaps [rsp+0x40], xmm4
0000796da41d4027  vmovaps [rsp+0x50], xmm5
0000796da41d402d  vmovaps [rsp+0x60], xmm6
0000796da41d4033  vmovaps [rsp+0x70], xmm7
0000796da41d4039  vmovaps [rsp+0x80], xmm8
0000796da41d4042  vmovaps [rsp+0x90], xmm9
0000796da41d404b  vmovaps [rsp+0xA0], xmm10
0000796da41d4054  vmovaps [rsp+0xB0], xmm11
0000796da41d405d  vmovaps [rsp+0xC0], xmm12
0000796da41d4066  vmovaps [rsp+0xD0], xmm13
0000796da41d406f  vmovaps [rsp+0xE0], xmm14
0000796da41d4078  sub rsp, 0x30
0000796da41d407c  movaps [rsp], xmm15
0000796da41d4081  movaps [rsp+0x10], xmm10
0000796da41d4087  movaps [rsp+0x20], xmm2
0000796da41d408c  lea rdi, [rsp]
0000796da41d4090  mov esi, 0x00
0000796da41d4095  mov rax, 0x5E26CB66A530
0000796da41d409f  call rax
0000796da41d40a1  movaps xmm15, [rsp]
0000796da41d40a6  add rsp, 0x30
0000796da41d40aa  vmovaps xmm0, [rsp]
0000796da41d40af  vmovaps xmm1, [rsp+0x10]
0000796da41d40b5  vmovaps xmm2, [rsp+0x20]
0000796da41d40bb  vmovaps xmm3, [rsp+0x30]
0000796da41d40c1  vmovaps xmm4, [rsp+0x40]
0000796da41d40c7  vmovaps xmm5, [rsp+0x50]
0000796da41d40cd  vmovaps xmm6, [rsp+0x60]
0000796da41d40d3  vmovaps xmm7, [rsp+0x70]
0000796da41d40d9  vmovaps xmm8, [rsp+0x80]
0000796da41d40e2  vmovaps xmm9, [rsp+0x90]
0000796da41d40eb  vmovaps xmm10, [rsp+0xA0]
0000796da41d40f4  vmovaps xmm11, [rsp+0xB0]
0000796da41d40fd  vmovaps xmm12, [rsp+0xC0]
0000796da41d4106  vmovaps xmm13, [rsp+0xD0]
0000796da41d410f  vmovaps xmm14, [rsp+0xE0]
0000796da41d4118  add rsp, 0xF0
0000796da41d411f  pop r11
0000796da41d4121  pop r10
0000796da41d4123  pop r9
0000796da41d4125  pop r8
0000796da41d4127  pop rsi
0000796da41d4128  pop rdi
0000796da41d4129  pop rdx
0000796da41d412a  pop rcx
0000796da41d412b  pop rax
0000796da41d412c  add rsp, 0x08
0000796da41d4130  jmp 0x0000796DA41D2924
0000796da41d4135  sub rsp, 0x08
0000796da41d4139  push rax
0000796da41d413a  push rcx
0000796da41d413b  push rdx
0000796da41d413c  push rdi
0000796da41d413d  push rsi
0000796da41d413e  push r8
0000796da41d4140  push r9
0000796da41d4142  push r10
0000796da41d4144  push r11
0000796da41d4146  sub rsp, 0xF0
0000796da41d414d  vmovaps [rsp], xmm0
0000796da41d4152  vmovaps [rsp+0x10], xmm2
0000796da41d4158  vmovaps [rsp+0x20], xmm3
0000796da41d415e  vmovaps [rsp+0x30], xmm4
0000796da41d4164  vmovaps [rsp+0x40], xmm5
0000796da41d416a  vmovaps [rsp+0x50], xmm6
0000796da41d4170  vmovaps [rsp+0x60], xmm7
0000796da41d4176  vmovaps [rsp+0x70], xmm8
0000796da41d417c  vmovaps [rsp+0x80], xmm9
0000796da41d4185  vmovaps [rsp+0x90], xmm10
0000796da41d418e  vmovaps [rsp+0xA0], xmm11
0000796da41d4197  vmovaps [rsp+0xB0], xmm12
0000796da41d41a0  vmovaps [rsp+0xC0], xmm13
0000796da41d41a9  vmovaps [rsp+0xD0], xmm14
0000796da41d41b2  vmovaps [rsp+0xE0], xmm15
0000796da41d41bb  sub rsp, 0x30
0000796da41d41bf  movaps [rsp], xmm1
0000796da41d41c3  movaps [rsp+0x10], xmm10
0000796da41d41c9  movaps [rsp+0x20], xmm15
0000796da41d41cf  lea rdi, [rsp]
0000796da41d41d3  mov esi, 0x00
0000796da41d41d8  mov rax, 0x5E26CB66A530
0000796da41d41e2  call rax
0000796da41d41e4  movaps xmm1, [rsp]
0000796da41d41e8  add rsp, 0x30
0000796da41d41ec  vmovaps xmm0, [rsp]
0000796da41d41f1  vmovaps xmm2, [rsp+0x10]
0000796da41d41f7  vmovaps xmm3, [rsp+0x20]
0000796da41d41fd  vmovaps xmm4, [rsp+0x30]
0000796da41d4203  vmovaps xmm5, [rsp+0x40]
0000796da41d4209  vmovaps xmm6, [rsp+0x50]
0000796da41d420f  vmovaps xmm7, [rsp+0x60]
0000796da41d4215  vmovaps xmm8, [rsp+0x70]
0000796da41d421b  vmovaps xmm9, [rsp+0x80]
0000796da41d4224  vmovaps xmm10, [rsp+0x90]
0000796da41d422d  vmovaps xmm11, [rsp+0xA0]
0000796da41d4236  vmovaps xmm12, [rsp+0xB0]
0000796da41d423f  vmovaps xmm13, [rsp+0xC0]
0000796da41d4248  vmovaps xmm14, [rsp+0xD0]
0000796da41d4251  vmovaps xmm15, [rsp+0xE0]
0000796da41d425a  add rsp, 0xF0
0000796da41d4261  pop r11
0000796da41d4263  pop r10
0000796da41d4265  pop r9
0000796da41d4267  pop r8
0000796da41d4269  pop rsi
0000796da41d426a  pop rdi
0000796da41d426b  pop rdx
0000796da41d426c  pop rcx
0000796da41d426d  pop rax
0000796da41d426e  add rsp, 0x08
0000796da41d4272  jmp 0x0000796DA41D2962
0000796da41d4277  sub rsp, 0x08
0000796da41d427b  push rax
0000796da41d427c  push rcx
0000796da41d427d  push rdx
0000796da41d427e  push rdi
0000796da41d427f  push rsi
0000796da41d4280  push r8
0000796da41d4282  push r9
0000796da41d4284  push r10
0000796da41d4286  push r11
0000796da41d4288  sub rsp, 0xF0
0000796da41d428f  vmovaps [rsp], xmm0
0000796da41d4294  vmovaps [rsp+0x10], xmm1
0000796da41d429a  vmovaps [rsp+0x20], xmm2
0000796da41d42a0  vmovaps [rsp+0x30], xmm3
0000796da41d42a6  vmovaps [rsp+0x40], xmm4
0000796da41d42ac  vmovaps [rsp+0x50], xmm5
0000796da41d42b2  vmovaps [rsp+0x60], xmm6
0000796da41d42b8  vmovaps [rsp+0x70], xmm7
0000796da41d42be  vmovaps [rsp+0x80], xmm8
0000796da41d42c7  vmovaps [rsp+0x90], xmm9
0000796da41d42d0  vmovaps [rsp+0xA0], xmm10
0000796da41d42d9  vmovaps [rsp+0xB0], xmm11
0000796da41d42e2  vmovaps [rsp+0xC0], xmm12
0000796da41d42eb  vmovaps [rsp+0xD0], xmm13
0000796da41d42f4  vmovaps [rsp+0xE0], xmm15
0000796da41d42fd  sub rsp, 0x30
0000796da41d4301  movaps [rsp], xmm14
0000796da41d4306  movaps [rsp+0x10], xmm10
0000796da41d430c  movaps [rsp+0x20], xmm15
0000796da41d4312  lea rdi, [rsp]
0000796da41d4316  mov esi, 0x00
0000796da41d431b  mov rax, 0x5E26CB66A530
0000796da41d4325  call rax
0000796da41d4327  movaps xmm14, [rsp]
0000796da41d432c  add rsp, 0x30
0000796da41d4330  vmovaps xmm0, [rsp]
0000796da41d4335  vmovaps xmm1, [rsp+0x10]
0000796da41d433b  vmovaps xmm2, [rsp+0x20]
0000796da41d4341  vmovaps xmm3, [rsp+0x30]
0000796da41d4347  vmovaps xmm4, [rsp+0x40]
0000796da41d434d  vmovaps xmm5, [rsp+0x50]
0000796da41d4353  vmovaps xmm6, [rsp+0x60]
0000796da41d4359  vmovaps xmm7, [rsp+0x70]
0000796da41d435f  vmovaps xmm8, [rsp+0x80]
0000796da41d4368  vmovaps xmm9, [rsp+0x90]
0000796da41d4371  vmovaps xmm10, [rsp+0xA0]
0000796da41d437a  vmovaps xmm11, [rsp+0xB0]
0000796da41d4383  vmovaps xmm12, [rsp+0xC0]
0000796da41d438c  vmovaps xmm13, [rsp+0xD0]
0000796da41d4395  vmovaps xmm15, [rsp+0xE0]
0000796da41d439e  add rsp, 0xF0
0000796da41d43a5  pop r11
0000796da41d43a7  pop r10
0000796da41d43a9  pop r9
0000796da41d43ab  pop r8
0000796da41d43ad  pop rsi
0000796da41d43ae  pop rdi
0000796da41d43af  pop rdx
0000796da41d43b0  pop rcx
0000796da41d43b1  pop rax
0000796da41d43b2  add rsp, 0x08
0000796da41d43b6  jmp 0x0000796DA41D298E
0000796da41d43bb  call 0x0000796DA3FFF430
0000796da41d43c0  jmp 0x0000796DA41D2A1E
0000796da41d43c5  call 0x0000796DA3FFF430
0000796da41d43ca  jmp 0x0000796DA41D2A31
0000796da41d43cf  sub rsp, 0x08
0000796da41d43d3  push rax
0000796da41d43d4  push rcx
0000796da41d43d5  push rdx
0000796da41d43d6  push rdi
0000796da41d43d7  push rsi
0000796da41d43d8  push r8
0000796da41d43da  push r9
0000796da41d43dc  push r10
0000796da41d43de  push r11
0000796da41d43e0  sub rsp, 0xF0
0000796da41d43e7  vmovaps [rsp], xmm0
0000796da41d43ec  vmovaps [rsp+0x10], xmm2
0000796da41d43f2  vmovaps [rsp+0x20], xmm3
0000796da41d43f8  vmovaps [rsp+0x30], xmm4
0000796da41d43fe  vmovaps [rsp+0x40], xmm5
0000796da41d4404  vmovaps [rsp+0x50], xmm6
0000796da41d440a  vmovaps [rsp+0x60], xmm7
0000796da41d4410  vmovaps [rsp+0x70], xmm8
0000796da41d4416  vmovaps [rsp+0x80], xmm9
0000796da41d441f  vmovaps [rsp+0x90], xmm10
0000796da41d4428  vmovaps [rsp+0xA0], xmm11
0000796da41d4431  vmovaps [rsp+0xB0], xmm12
0000796da41d443a  vmovaps [rsp+0xC0], xmm13
0000796da41d4443  vmovaps [rsp+0xD0], xmm14
0000796da41d444c  vmovaps [rsp+0xE0], xmm15
0000796da41d4455  sub rsp, 0x30
0000796da41d4459  movaps [rsp], xmm1
0000796da41d445d  movaps [rsp+0x10], xmm13
0000796da41d4463  movaps [rsp+0x20], xmm2
0000796da41d4468  lea rdi, [rsp]
0000796da41d446c  mov esi, 0x00
0000796da41d4471  mov rax, 0x5E26CB66A530
0000796da41d447b  call rax
0000796da41d447d  movaps xmm1, [rsp]
0000796da41d4481  add rsp, 0x30
0000796da41d4485  vmovaps xmm0, [rsp]
0000796da41d448a  vmovaps xmm2, [rsp+0x10]
0000796da41d4490  vmovaps xmm3, [rsp+0x20]
0000796da41d4496  vmovaps xmm4, [rsp+0x30]
0000796da41d449c  vmovaps xmm5, [rsp+0x40]
0000796da41d44a2  vmovaps xmm6, [rsp+0x50]
0000796da41d44a8  vmovaps xmm7, [rsp+0x60]
0000796da41d44ae  vmovaps xmm8, [rsp+0x70]
0000796da41d44b4  vmovaps xmm9, [rsp+0x80]
0000796da41d44bd  vmovaps xmm10, [rsp+0x90]
0000796da41d44c6  vmovaps xmm11, [rsp+0xA0]
0000796da41d44cf  vmovaps xmm12, [rsp+0xB0]
0000796da41d44d8  vmovaps xmm13, [rsp+0xC0]
0000796da41d44e1  vmovaps xmm14, [rsp+0xD0]
0000796da41d44ea  vmovaps xmm15, [rsp+0xE0]
0000796da41d44f3  add rsp, 0xF0
0000796da41d44fa  pop r11
0000796da41d44fc  pop r10
0000796da41d44fe  pop r9
0000796da41d4500  pop r8
0000796da41d4502  pop rsi
0000796da41d4503  pop rdi
0000796da41d4504  pop rdx
0000796da41d4505  pop rcx
0000796da41d4506  pop rax
0000796da41d4507  add rsp, 0x08
0000796da41d450b  jmp 0x0000796DA41D2A5C
0000796da41d4510  call 0x0000796DA400E760
0000796da41d4515  jmp 0x0000796DA41D2A69
0000796da41d451a  sub rsp, 0x08
0000796da41d451e  push rax
0000796da41d451f  push rcx
0000796da41d4520  push rdx
0000796da41d4521  push rdi
0000796da41d4522  push rsi
0000796da41d4523  push r8
0000796da41d4525  push r9
0000796da41d4527  push r10
0000796da41d4529  push r11
0000796da41d452b  sub rsp, 0xF0
0000796da41d4532  vmovaps [rsp], xmm0
0000796da41d4537  vmovaps [rsp+0x10], xmm1
0000796da41d453d  vmovaps [rsp+0x20], xmm2
0000796da41d4543  vmovaps [rsp+0x30], xmm3
0000796da41d4549  vmovaps [rsp+0x40], xmm4
0000796da41d454f  vmovaps [rsp+0x50], xmm5
0000796da41d4555  vmovaps [rsp+0x60], xmm6
0000796da41d455b  vmovaps [rsp+0x70], xmm7
0000796da41d4561  vmovaps [rsp+0x80], xmm8
0000796da41d456a  vmovaps [rsp+0x90], xmm9
0000796da41d4573  vmovaps [rsp+0xA0], xmm10
0000796da41d457c  vmovaps [rsp+0xB0], xmm11
0000796da41d4585  vmovaps [rsp+0xC0], xmm12
0000796da41d458e  vmovaps [rsp+0xD0], xmm14
0000796da41d4597  vmovaps [rsp+0xE0], xmm15
0000796da41d45a0  sub rsp, 0x30
0000796da41d45a4  movaps [rsp], xmm13
0000796da41d45a9  movaps [rsp+0x10], xmm2
0000796da41d45ae  movaps [rsp+0x20], xmm1
0000796da41d45b3  lea rdi, [rsp]
0000796da41d45b7  mov esi, 0x00
0000796da41d45bc  mov rax, 0x5E26CB66A530
0000796da41d45c6  call rax
0000796da41d45c8  movaps xmm13, [rsp]
0000796da41d45cd  add rsp, 0x30
0000796da41d45d1  vmovaps xmm0, [rsp]
0000796da41d45d6  vmovaps xmm1, [rsp+0x10]
0000796da41d45dc  vmovaps xmm2, [rsp+0x20]
0000796da41d45e2  vmovaps xmm3, [rsp+0x30]
0000796da41d45e8  vmovaps xmm4, [rsp+0x40]
0000796da41d45ee  vmovaps xmm5, [rsp+0x50]
0000796da41d45f4  vmovaps xmm6, [rsp+0x60]
0000796da41d45fa  vmovaps xmm7, [rsp+0x70]
0000796da41d4600  vmovaps xmm8, [rsp+0x80]
0000796da41d4609  vmovaps xmm9, [rsp+0x90]
0000796da41d4612  vmovaps xmm10, [rsp+0xA0]
0000796da41d461b  vmovaps xmm11, [rsp+0xB0]
0000796da41d4624  vmovaps xmm12, [rsp+0xC0]
0000796da41d462d  vmovaps xmm14, [rsp+0xD0]
0000796da41d4636  vmovaps xmm15, [rsp+0xE0]
0000796da41d463f  add rsp, 0xF0
0000796da41d4646  pop r11
0000796da41d4648  pop r10
0000796da41d464a  pop r9
0000796da41d464c  pop r8
0000796da41d464e  pop rsi
0000796da41d464f  pop rdi
0000796da41d4650  pop rdx
0000796da41d4651  pop rcx
0000796da41d4652  pop rax
0000796da41d4653  add rsp, 0x08
0000796da41d4657  jmp 0x0000796DA41D2AA8
0000796da41d465c  sub rsp, 0x08
0000796da41d4660  push rax
0000796da41d4661  push rcx
0000796da41d4662  push rdx
0000796da41d4663  push rdi
0000796da41d4664  push rsi
0000796da41d4665  push r8
0000796da41d4667  push r9
0000796da41d4669  push r10
0000796da41d466b  push r11
0000796da41d466d  sub rsp, 0xF0
0000796da41d4674  vmovaps [rsp], xmm0
0000796da41d4679  vmovaps [rsp+0x10], xmm2
0000796da41d467f  vmovaps [rsp+0x20], xmm3
0000796da41d4685  vmovaps [rsp+0x30], xmm4
0000796da41d468b  vmovaps [rsp+0x40], xmm5
0000796da41d4691  vmovaps [rsp+0x50], xmm6
0000796da41d4697  vmovaps [rsp+0x60], xmm7
0000796da41d469d  vmovaps [rsp+0x70], xmm8
0000796da41d46a3  vmovaps [rsp+0x80], xmm9
0000796da41d46ac  vmovaps [rsp+0x90], xmm10
0000796da41d46b5  vmovaps [rsp+0xA0], xmm11
0000796da41d46be  vmovaps [rsp+0xB0], xmm12
0000796da41d46c7  vmovaps [rsp+0xC0], xmm13
0000796da41d46d0  vmovaps [rsp+0xD0], xmm14
0000796da41d46d9  vmovaps [rsp+0xE0], xmm15
0000796da41d46e2  sub rsp, 0x30
0000796da41d46e6  movaps [rsp], xmm1
0000796da41d46ea  movaps [rsp+0x10], xmm14
0000796da41d46f0  movaps [rsp+0x20], xmm15
0000796da41d46f6  lea rdi, [rsp]
0000796da41d46fa  mov esi, 0x00
0000796da41d46ff  mov rax, 0x5E26CB66A530
0000796da41d4709  call rax
0000796da41d470b  movaps xmm1, [rsp]
0000796da41d470f  add rsp, 0x30
0000796da41d4713  vmovaps xmm0, [rsp]
0000796da41d4718  vmovaps xmm2, [rsp+0x10]
0000796da41d471e  vmovaps xmm3, [rsp+0x20]
0000796da41d4724  vmovaps xmm4, [rsp+0x30]
0000796da41d472a  vmovaps xmm5, [rsp+0x40]
0000796da41d4730  vmovaps xmm6, [rsp+0x50]
0000796da41d4736  vmovaps xmm7, [rsp+0x60]
0000796da41d473c  vmovaps xmm8, [rsp+0x70]
0000796da41d4742  vmovaps xmm9, [rsp+0x80]
0000796da41d474b  vmovaps xmm10, [rsp+0x90]
0000796da41d4754  vmovaps xmm11, [rsp+0xA0]
0000796da41d475d  vmovaps xmm12, [rsp+0xB0]
0000796da41d4766  vmovaps xmm13, [rsp+0xC0]
0000796da41d476f  vmovaps xmm14, [rsp+0xD0]
0000796da41d4778  vmovaps xmm15, [rsp+0xE0]
0000796da41d4781  add rsp, 0xF0
0000796da41d4788  pop r11
0000796da41d478a  pop r10
0000796da41d478c  pop r9
0000796da41d478e  pop r8
0000796da41d4790  pop rsi
0000796da41d4791  pop rdi
0000796da41d4792  pop rdx
0000796da41d4793  pop rcx
0000796da41d4794  pop rax
0000796da41d4795  add rsp, 0x08
0000796da41d4799  jmp 0x0000796DA41D2ACA
0000796da41d479e  sub rsp, 0x08
0000796da41d47a2  push rax
0000796da41d47a3  push rcx
0000796da41d47a4  push rdx
0000796da41d47a5  push rdi
0000796da41d47a6  push rsi
0000796da41d47a7  push r8
0000796da41d47a9  push r9
0000796da41d47ab  push r10
0000796da41d47ad  push r11
0000796da41d47af  sub rsp, 0xF0
0000796da41d47b6  vmovaps [rsp], xmm0
0000796da41d47bb  vmovaps [rsp+0x10], xmm1
0000796da41d47c1  vmovaps [rsp+0x20], xmm2
0000796da41d47c7  vmovaps [rsp+0x30], xmm3
0000796da41d47cd  vmovaps [rsp+0x40], xmm4
0000796da41d47d3  vmovaps [rsp+0x50], xmm5
0000796da41d47d9  vmovaps [rsp+0x60], xmm6
0000796da41d47df  vmovaps [rsp+0x70], xmm7
0000796da41d47e5  vmovaps [rsp+0x80], xmm8
0000796da41d47ee  vmovaps [rsp+0x90], xmm9
0000796da41d47f7  vmovaps [rsp+0xA0], xmm10
0000796da41d4800  vmovaps [rsp+0xB0], xmm11
0000796da41d4809  vmovaps [rsp+0xC0], xmm12
0000796da41d4812  vmovaps [rsp+0xD0], xmm13
0000796da41d481b  vmovaps [rsp+0xE0], xmm15
0000796da41d4824  sub rsp, 0x30
0000796da41d4828  movaps [rsp], xmm14
0000796da41d482d  movaps [rsp+0x10], xmm2
0000796da41d4832  movaps [rsp+0x20], xmm15
0000796da41d4838  lea rdi, [rsp]
0000796da41d483c  mov esi, 0x00
0000796da41d4841  mov rax, 0x5E26CB66A530
0000796da41d484b  call rax
0000796da41d484d  movaps xmm14, [rsp]
0000796da41d4852  add rsp, 0x30
0000796da41d4856  vmovaps xmm0, [rsp]
0000796da41d485b  vmovaps xmm1, [rsp+0x10]
0000796da41d4861  vmovaps xmm2, [rsp+0x20]
0000796da41d4867  vmovaps xmm3, [rsp+0x30]
0000796da41d486d  vmovaps xmm4, [rsp+0x40]
0000796da41d4873  vmovaps xmm5, [rsp+0x50]
0000796da41d4879  vmovaps xmm6, [rsp+0x60]
0000796da41d487f  vmovaps xmm7, [rsp+0x70]
0000796da41d4885  vmovaps xmm8, [rsp+0x80]
0000796da41d488e  vmovaps xmm9, [rsp+0x90]
0000796da41d4897  vmovaps xmm10, [rsp+0xA0]
0000796da41d48a0  vmovaps xmm11, [rsp+0xB0]
0000796da41d48a9  vmovaps xmm12, [rsp+0xC0]
0000796da41d48b2  vmovaps xmm13, [rsp+0xD0]
0000796da41d48bb  vmovaps xmm15, [rsp+0xE0]
0000796da41d48c4  add rsp, 0xF0
0000796da41d48cb  pop r11
0000796da41d48cd  pop r10
0000796da41d48cf  pop r9
0000796da41d48d1  pop r8
0000796da41d48d3  pop rsi
0000796da41d48d4  pop rdi
0000796da41d48d5  pop rdx
0000796da41d48d6  pop rcx
0000796da41d48d7  pop rax
0000796da41d48d8  add rsp, 0x08
0000796da41d48dc  jmp 0x0000796DA41D2B05
0000796da41d48e1  sub rsp, 0x08
0000796da41d48e5  push rax
0000796da41d48e6  push rcx
0000796da41d48e7  push rdx
0000796da41d48e8  push rdi
0000796da41d48e9  push rsi
0000796da41d48ea  push r8
0000796da41d48ec  push r9
0000796da41d48ee  push r10
0000796da41d48f0  push r11
0000796da41d48f2  sub rsp, 0xF0
0000796da41d48f9  vmovaps [rsp], xmm0
0000796da41d48fe  vmovaps [rsp+0x10], xmm1
0000796da41d4904  vmovaps [rsp+0x20], xmm2
0000796da41d490a  vmovaps [rsp+0x30], xmm3
0000796da41d4910  vmovaps [rsp+0x40], xmm4
0000796da41d4916  vmovaps [rsp+0x50], xmm5
0000796da41d491c  vmovaps [rsp+0x60], xmm6
0000796da41d4922  vmovaps [rsp+0x70], xmm7
0000796da41d4928  vmovaps [rsp+0x80], xmm8
0000796da41d4931  vmovaps [rsp+0x90], xmm9
0000796da41d493a  vmovaps [rsp+0xA0], xmm10
0000796da41d4943  vmovaps [rsp+0xB0], xmm11
0000796da41d494c  vmovaps [rsp+0xC0], xmm12
0000796da41d4955  vmovaps [rsp+0xD0], xmm13
0000796da41d495e  vmovaps [rsp+0xE0], xmm14
0000796da41d4967  sub rsp, 0x30
0000796da41d496b  movaps [rsp], xmm15
0000796da41d4970  movaps [rsp+0x10], xmm2
0000796da41d4975  movaps [rsp+0x20], xmm1
0000796da41d497a  lea rdi, [rsp]
0000796da41d497e  mov esi, 0x00
0000796da41d4983  mov rax, 0x5E26CB66A530
0000796da41d498d  call rax
0000796da41d498f  movaps xmm15, [rsp]
0000796da41d4994  add rsp, 0x30
0000796da41d4998  vmovaps xmm0, [rsp]
0000796da41d499d  vmovaps xmm1, [rsp+0x10]
0000796da41d49a3  vmovaps xmm2, [rsp+0x20]
0000796da41d49a9  vmovaps xmm3, [rsp+0x30]
0000796da41d49af  vmovaps xmm4, [rsp+0x40]
0000796da41d49b5  vmovaps xmm5, [rsp+0x50]
0000796da41d49bb  vmovaps xmm6, [rsp+0x60]
0000796da41d49c1  vmovaps xmm7, [rsp+0x70]
0000796da41d49c7  vmovaps xmm8, [rsp+0x80]
0000796da41d49d0  vmovaps xmm9, [rsp+0x90]
0000796da41d49d9  vmovaps xmm10, [rsp+0xA0]
0000796da41d49e2  vmovaps xmm11, [rsp+0xB0]
0000796da41d49eb  vmovaps xmm12, [rsp+0xC0]
0000796da41d49f4  vmovaps xmm13, [rsp+0xD0]
0000796da41d49fd  vmovaps xmm14, [rsp+0xE0]
0000796da41d4a06  add rsp, 0xF0
0000796da41d4a0d  pop r11
0000796da41d4a0f  pop r10
0000796da41d4a11  pop r9
0000796da41d4a13  pop r8
0000796da41d4a15  pop rsi
0000796da41d4a16  pop rdi
0000796da41d4a17  pop rdx
0000796da41d4a18  pop rcx
0000796da41d4a19  pop rax
0000796da41d4a1a  add rsp, 0x08
0000796da41d4a1e  jmp 0x0000796DA41D2B41
0000796da41d4a23  call 0x0000796DA3FFF430
0000796da41d4a28  jmp 0x0000796DA41D2B4E
0000796da41d4a2d  sub rsp, 0x08
0000796da41d4a31  push rax
0000796da41d4a32  push rcx
0000796da41d4a33  push rdx
0000796da41d4a34  push rdi
0000796da41d4a35  push rsi
0000796da41d4a36  push r8
0000796da41d4a38  push r9
0000796da41d4a3a  push r10
0000796da41d4a3c  push r11
0000796da41d4a3e  sub rsp, 0xF0
0000796da41d4a45  vmovaps [rsp], xmm0
0000796da41d4a4a  vmovaps [rsp+0x10], xmm1
0000796da41d4a50  vmovaps [rsp+0x20], xmm3
0000796da41d4a56  vmovaps [rsp+0x30], xmm4
0000796da41d4a5c  vmovaps [rsp+0x40], xmm5
0000796da41d4a62  vmovaps [rsp+0x50], xmm6
0000796da41d4a68  vmovaps [rsp+0x60], xmm7
0000796da41d4a6e  vmovaps [rsp+0x70], xmm8
0000796da41d4a74  vmovaps [rsp+0x80], xmm9
0000796da41d4a7d  vmovaps [rsp+0x90], xmm10
0000796da41d4a86  vmovaps [rsp+0xA0], xmm11
0000796da41d4a8f  vmovaps [rsp+0xB0], xmm12
0000796da41d4a98  vmovaps [rsp+0xC0], xmm13
0000796da41d4aa1  vmovaps [rsp+0xD0], xmm14
0000796da41d4aaa  vmovaps [rsp+0xE0], xmm15
0000796da41d4ab3  sub rsp, 0x30
0000796da41d4ab7  movaps [rsp], xmm2
0000796da41d4abb  movaps [rsp+0x10], xmm1
0000796da41d4ac0  movaps [rsp+0x20], xmm14
0000796da41d4ac6  lea rdi, [rsp]
0000796da41d4aca  mov esi, 0x00
0000796da41d4acf  mov rax, 0x5E26CB66A530
0000796da41d4ad9  call rax
0000796da41d4adb  movaps xmm2, [rsp]
0000796da41d4adf  add rsp, 0x30
0000796da41d4ae3  vmovaps xmm0, [rsp]
0000796da41d4ae8  vmovaps xmm1, [rsp+0x10]
0000796da41d4aee  vmovaps xmm3, [rsp+0x20]
0000796da41d4af4  vmovaps xmm4, [rsp+0x30]
0000796da41d4afa  vmovaps xmm5, [rsp+0x40]
0000796da41d4b00  vmovaps xmm6, [rsp+0x50]
0000796da41d4b06  vmovaps xmm7, [rsp+0x60]
0000796da41d4b0c  vmovaps xmm8, [rsp+0x70]
0000796da41d4b12  vmovaps xmm9, [rsp+0x80]
0000796da41d4b1b  vmovaps xmm10, [rsp+0x90]
0000796da41d4b24  vmovaps xmm11, [rsp+0xA0]
0000796da41d4b2d  vmovaps xmm12, [rsp+0xB0]
0000796da41d4b36  vmovaps xmm13, [rsp+0xC0]
0000796da41d4b3f  vmovaps xmm14, [rsp+0xD0]
0000796da41d4b48  vmovaps xmm15, [rsp+0xE0]
0000796da41d4b51  add rsp, 0xF0
0000796da41d4b58  pop r11
0000796da41d4b5a  pop r10
0000796da41d4b5c  pop r9
0000796da41d4b5e  pop r8
0000796da41d4b60  pop rsi
0000796da41d4b61  pop rdi
0000796da41d4b62  pop rdx
0000796da41d4b63  pop rcx
0000796da41d4b64  pop rax
0000796da41d4b65  add rsp, 0x08
0000796da41d4b69  jmp 0x0000796DA41D2B8B
0000796da41d4b6e  sub rsp, 0x08
0000796da41d4b72  push rax
0000796da41d4b73  push rcx
0000796da41d4b74  push rdx
0000796da41d4b75  push rdi
0000796da41d4b76  push rsi
0000796da41d4b77  push r8
0000796da41d4b79  push r9
0000796da41d4b7b  push r10
0000796da41d4b7d  push r11
0000796da41d4b7f  sub rsp, 0xF0
0000796da41d4b86  vmovaps [rsp], xmm0
0000796da41d4b8b  vmovaps [rsp+0x10], xmm1
0000796da41d4b91  vmovaps [rsp+0x20], xmm2
0000796da41d4b97  vmovaps [rsp+0x30], xmm3
0000796da41d4b9d  vmovaps [rsp+0x40], xmm4
0000796da41d4ba3  vmovaps [rsp+0x50], xmm5
0000796da41d4ba9  vmovaps [rsp+0x60], xmm6
0000796da41d4baf  vmovaps [rsp+0x70], xmm7
0000796da41d4bb5  vmovaps [rsp+0x80], xmm8
0000796da41d4bbe  vmovaps [rsp+0x90], xmm9
0000796da41d4bc7  vmovaps [rsp+0xA0], xmm10
0000796da41d4bd0  vmovaps [rsp+0xB0], xmm11
0000796da41d4bd9  vmovaps [rsp+0xC0], xmm12
0000796da41d4be2  vmovaps [rsp+0xD0], xmm13
0000796da41d4beb  vmovaps [rsp+0xE0], xmm14
0000796da41d4bf4  sub rsp, 0x30
0000796da41d4bf8  movaps [rsp], xmm15
0000796da41d4bfd  movaps [rsp+0x10], xmm14
0000796da41d4c03  movaps [rsp+0x20], xmm1
0000796da41d4c08  lea rdi, [rsp]
0000796da41d4c0c  mov esi, 0x00
0000796da41d4c11  mov rax, 0x5E26CB66A530
0000796da41d4c1b  call rax
0000796da41d4c1d  movaps xmm15, [rsp]
0000796da41d4c22  add rsp, 0x30
0000796da41d4c26  vmovaps xmm0, [rsp]
0000796da41d4c2b  vmovaps xmm1, [rsp+0x10]
0000796da41d4c31  vmovaps xmm2, [rsp+0x20]
0000796da41d4c37  vmovaps xmm3, [rsp+0x30]
0000796da41d4c3d  vmovaps xmm4, [rsp+0x40]
0000796da41d4c43  vmovaps xmm5, [rsp+0x50]
0000796da41d4c49  vmovaps xmm6, [rsp+0x60]
0000796da41d4c4f  vmovaps xmm7, [rsp+0x70]
0000796da41d4c55  vmovaps xmm8, [rsp+0x80]
0000796da41d4c5e  vmovaps xmm9, [rsp+0x90]
0000796da41d4c67  vmovaps xmm10, [rsp+0xA0]
0000796da41d4c70  vmovaps xmm11, [rsp+0xB0]
0000796da41d4c79  vmovaps xmm12, [rsp+0xC0]
0000796da41d4c82  vmovaps xmm13, [rsp+0xD0]
0000796da41d4c8b  vmovaps xmm14, [rsp+0xE0]
0000796da41d4c94  add rsp, 0xF0
0000796da41d4c9b  pop r11
0000796da41d4c9d  pop r10
0000796da41d4c9f  pop r9
0000796da41d4ca1  pop r8
0000796da41d4ca3  pop rsi
0000796da41d4ca4  pop rdi
0000796da41d4ca5  pop rdx
0000796da41d4ca6  pop rcx
0000796da41d4ca7  pop rax
0000796da41d4ca8  add rsp, 0x08
0000796da41d4cac  jmp 0x0000796DA41D2C05
0000796da41d4cb1  call 0x0000796DA3FFF430
0000796da41d4cb6  jmp 0x0000796DA41D2C12
0000796da41d4cbb  sub rsp, 0x08
0000796da41d4cbf  push rax
0000796da41d4cc0  push rcx
0000796da41d4cc1  push rdx
0000796da41d4cc2  push rdi
0000796da41d4cc3  push rsi
0000796da41d4cc4  push r8
0000796da41d4cc6  push r9
0000796da41d4cc8  push r10
0000796da41d4cca  push r11
0000796da41d4ccc  sub rsp, 0xF0
0000796da41d4cd3  vmovaps [rsp], xmm0
0000796da41d4cd8  vmovaps [rsp+0x10], xmm1
0000796da41d4cde  vmovaps [rsp+0x20], xmm2
0000796da41d4ce4  vmovaps [rsp+0x30], xmm3
0000796da41d4cea  vmovaps [rsp+0x40], xmm4
0000796da41d4cf0  vmovaps [rsp+0x50], xmm5
0000796da41d4cf6  vmovaps [rsp+0x60], xmm6
0000796da41d4cfc  vmovaps [rsp+0x70], xmm7
0000796da41d4d02  vmovaps [rsp+0x80], xmm8
0000796da41d4d0b  vmovaps [rsp+0x90], xmm9
0000796da41d4d14  vmovaps [rsp+0xA0], xmm10
0000796da41d4d1d  vmovaps [rsp+0xB0], xmm11
0000796da41d4d26  vmovaps [rsp+0xC0], xmm12
0000796da41d4d2f  vmovaps [rsp+0xD0], xmm14
0000796da41d4d38  vmovaps [rsp+0xE0], xmm15
0000796da41d4d41  sub rsp, 0x30
0000796da41d4d45  movaps [rsp], xmm13
0000796da41d4d4a  movaps [rsp+0x10], xmm1
0000796da41d4d4f  movaps [rsp+0x20], xmm15
0000796da41d4d55  lea rdi, [rsp]
0000796da41d4d59  mov esi, 0x00
0000796da41d4d5e  mov rax, 0x5E26CB66A530
0000796da41d4d68  call rax
0000796da41d4d6a  movaps xmm13, [rsp]
0000796da41d4d6f  add rsp, 0x30
0000796da41d4d73  vmovaps xmm0, [rsp]
0000796da41d4d78  vmovaps xmm1, [rsp+0x10]
0000796da41d4d7e  vmovaps xmm2, [rsp+0x20]
0000796da41d4d84  vmovaps xmm3, [rsp+0x30]
0000796da41d4d8a  vmovaps xmm4, [rsp+0x40]
0000796da41d4d90  vmovaps xmm5, [rsp+0x50]
0000796da41d4d96  vmovaps xmm6, [rsp+0x60]
0000796da41d4d9c  vmovaps xmm7, [rsp+0x70]
0000796da41d4da2  vmovaps xmm8, [rsp+0x80]
0000796da41d4dab  vmovaps xmm9, [rsp+0x90]
0000796da41d4db4  vmovaps xmm10, [rsp+0xA0]
0000796da41d4dbd  vmovaps xmm11, [rsp+0xB0]
0000796da41d4dc6  vmovaps xmm12, [rsp+0xC0]
0000796da41d4dcf  vmovaps xmm14, [rsp+0xD0]
0000796da41d4dd8  vmovaps xmm15, [rsp+0xE0]
0000796da41d4de1  add rsp, 0xF0
0000796da41d4de8  pop r11
0000796da41d4dea  pop r10
0000796da41d4dec  pop r9
0000796da41d4dee  pop r8
0000796da41d4df0  pop rsi
0000796da41d4df1  pop rdi
0000796da41d4df2  pop rdx
0000796da41d4df3  pop rcx
0000796da41d4df4  pop rax
0000796da41d4df5  add rsp, 0x08
0000796da41d4df9  jmp 0x0000796DA41D2CD6
0000796da41d4dfe  sub rsp, 0x08
0000796da41d4e02  push rax
0000796da41d4e03  push rcx
0000796da41d4e04  push rdx
0000796da41d4e05  push rdi
0000796da41d4e06  push rsi
0000796da41d4e07  push r8
0000796da41d4e09  push r9
0000796da41d4e0b  push r10
0000796da41d4e0d  push r11
0000796da41d4e0f  sub rsp, 0xF0
0000796da41d4e16  vmovaps [rsp], xmm0
0000796da41d4e1b  vmovaps [rsp+0x10], xmm1
0000796da41d4e21  vmovaps [rsp+0x20], xmm2
0000796da41d4e27  vmovaps [rsp+0x30], xmm3
0000796da41d4e2d  vmovaps [rsp+0x40], xmm4
0000796da41d4e33  vmovaps [rsp+0x50], xmm5
0000796da41d4e39  vmovaps [rsp+0x60], xmm6
0000796da41d4e3f  vmovaps [rsp+0x70], xmm7
0000796da41d4e45  vmovaps [rsp+0x80], xmm8
0000796da41d4e4e  vmovaps [rsp+0x90], xmm9
0000796da41d4e57  vmovaps [rsp+0xA0], xmm10
0000796da41d4e60  vmovaps [rsp+0xB0], xmm11
0000796da41d4e69  vmovaps [rsp+0xC0], xmm12
0000796da41d4e72  vmovaps [rsp+0xD0], xmm13
0000796da41d4e7b  vmovaps [rsp+0xE0], xmm14
0000796da41d4e84  sub rsp, 0x30
0000796da41d4e88  movaps [rsp], xmm15
0000796da41d4e8d  movaps [rsp+0x10], xmm14
0000796da41d4e93  movaps [rsp+0x20], xmm1
0000796da41d4e98  lea rdi, [rsp]
0000796da41d4e9c  mov esi, 0x00
0000796da41d4ea1  mov rax, 0x5E26CB66A530
0000796da41d4eab  call rax
0000796da41d4ead  movaps xmm15, [rsp]
0000796da41d4eb2  add rsp, 0x30
0000796da41d4eb6  vmovaps xmm0, [rsp]
0000796da41d4ebb  vmovaps xmm1, [rsp+0x10]
0000796da41d4ec1  vmovaps xmm2, [rsp+0x20]
0000796da41d4ec7  vmovaps xmm3, [rsp+0x30]
0000796da41d4ecd  vmovaps xmm4, [rsp+0x40]
0000796da41d4ed3  vmovaps xmm5, [rsp+0x50]
0000796da41d4ed9  vmovaps xmm6, [rsp+0x60]
0000796da41d4edf  vmovaps xmm7, [rsp+0x70]
0000796da41d4ee5  vmovaps xmm8, [rsp+0x80]
0000796da41d4eee  vmovaps xmm9, [rsp+0x90]
0000796da41d4ef7  vmovaps xmm10, [rsp+0xA0]
0000796da41d4f00  vmovaps xmm11, [rsp+0xB0]
0000796da41d4f09  vmovaps xmm12, [rsp+0xC0]
0000796da41d4f12  vmovaps xmm13, [rsp+0xD0]
0000796da41d4f1b  vmovaps xmm14, [rsp+0xE0]
0000796da41d4f24  add rsp, 0xF0
0000796da41d4f2b  pop r11
0000796da41d4f2d  pop r10
0000796da41d4f2f  pop r9
0000796da41d4f31  pop r8
0000796da41d4f33  pop rsi
0000796da41d4f34  pop rdi
0000796da41d4f35  pop rdx
0000796da41d4f36  pop rcx
0000796da41d4f37  pop rax
0000796da41d4f38  add rsp, 0x08
0000796da41d4f3c  jmp 0x0000796DA41D2D12
0000796da41d4f41  call 0x0000796DA3FFF430
0000796da41d4f46  jmp 0x0000796DA41D2D1F
0000796da41d4f4b  sub rsp, 0x08
0000796da41d4f4f  push rax
0000796da41d4f50  push rcx
0000796da41d4f51  push rdx
0000796da41d4f52  push rdi
0000796da41d4f53  push rsi
0000796da41d4f54  push r8
0000796da41d4f56  push r9
0000796da41d4f58  push r10
0000796da41d4f5a  push r11
0000796da41d4f5c  sub rsp, 0xF0
0000796da41d4f63  vmovaps [rsp], xmm0
0000796da41d4f68  vmovaps [rsp+0x10], xmm1
0000796da41d4f6e  vmovaps [rsp+0x20], xmm2
0000796da41d4f74  vmovaps [rsp+0x30], xmm3
0000796da41d4f7a  vmovaps [rsp+0x40], xmm4
0000796da41d4f80  vmovaps [rsp+0x50], xmm5
0000796da41d4f86  vmovaps [rsp+0x60], xmm6
0000796da41d4f8c  vmovaps [rsp+0x70], xmm7
0000796da41d4f92  vmovaps [rsp+0x80], xmm8
0000796da41d4f9b  vmovaps [rsp+0x90], xmm9
0000796da41d4fa4  vmovaps [rsp+0xA0], xmm10
0000796da41d4fad  vmovaps [rsp+0xB0], xmm11
0000796da41d4fb6  vmovaps [rsp+0xC0], xmm12
0000796da41d4fbf  vmovaps [rsp+0xD0], xmm13
0000796da41d4fc8  vmovaps [rsp+0xE0], xmm15
0000796da41d4fd1  sub rsp, 0x30
0000796da41d4fd5  movaps [rsp], xmm14
0000796da41d4fda  movaps [rsp+0x10], xmm13
0000796da41d4fe0  movaps [rsp+0x20], xmm2
0000796da41d4fe5  lea rdi, [rsp]
0000796da41d4fe9  mov esi, 0x00
0000796da41d4fee  mov rax, 0x5E26CB66A530
0000796da41d4ff8  call rax
0000796da41d4ffa  movaps xmm14, [rsp]
0000796da41d4fff  add rsp, 0x30
0000796da41d5003  vmovaps xmm0, [rsp]
0000796da41d5008  vmovaps xmm1, [rsp+0x10]
0000796da41d500e  vmovaps xmm2, [rsp+0x20]
0000796da41d5014  vmovaps xmm3, [rsp+0x30]
0000796da41d501a  vmovaps xmm4, [rsp+0x40]
0000796da41d5020  vmovaps xmm5, [rsp+0x50]
0000796da41d5026  vmovaps xmm6, [rsp+0x60]
0000796da41d502c  vmovaps xmm7, [rsp+0x70]
0000796da41d5032  vmovaps xmm8, [rsp+0x80]
0000796da41d503b  vmovaps xmm9, [rsp+0x90]
0000796da41d5044  vmovaps xmm10, [rsp+0xA0]
0000796da41d504d  vmovaps xmm11, [rsp+0xB0]
0000796da41d5056  vmovaps xmm12, [rsp+0xC0]
0000796da41d505f  vmovaps xmm13, [rsp+0xD0]
0000796da41d5068  vmovaps xmm15, [rsp+0xE0]
0000796da41d5071  add rsp, 0xF0
0000796da41d5078  pop r11
0000796da41d507a  pop r10
0000796da41d507c  pop r9
0000796da41d507e  pop r8
0000796da41d5080  pop rsi
0000796da41d5081  pop rdi
0000796da41d5082  pop rdx
0000796da41d5083  pop rcx
0000796da41d5084  pop rax
0000796da41d5085  add rsp, 0x08
0000796da41d5089  jmp 0x0000796DA41D2D4B
0000796da41d508e  sub rsp, 0x08
0000796da41d5092  push rax
0000796da41d5093  push rcx
0000796da41d5094  push rdx
0000796da41d5095  push rdi
0000796da41d5096  push rsi
0000796da41d5097  push r8
0000796da41d5099  push r9
0000796da41d509b  push r10
0000796da41d509d  push r11
0000796da41d509f  sub rsp, 0xF0
0000796da41d50a6  vmovaps [rsp], xmm0
0000796da41d50ab  vmovaps [rsp+0x10], xmm2
0000796da41d50b1  vmovaps [rsp+0x20], xmm3
0000796da41d50b7  vmovaps [rsp+0x30], xmm4
0000796da41d50bd  vmovaps [rsp+0x40], xmm5
0000796da41d50c3  vmovaps [rsp+0x50], xmm6
0000796da41d50c9  vmovaps [rsp+0x60], xmm7
0000796da41d50cf  vmovaps [rsp+0x70], xmm8
0000796da41d50d5  vmovaps [rsp+0x80], xmm9
0000796da41d50de  vmovaps [rsp+0x90], xmm10
0000796da41d50e7  vmovaps [rsp+0xA0], xmm11
0000796da41d50f0  vmovaps [rsp+0xB0], xmm12
0000796da41d50f9  vmovaps [rsp+0xC0], xmm13
0000796da41d5102  vmovaps [rsp+0xD0], xmm14
0000796da41d510b  vmovaps [rsp+0xE0], xmm15
0000796da41d5114  sub rsp, 0x30
0000796da41d5118  movaps [rsp], xmm1
0000796da41d511c  movaps [rsp+0x10], xmm13
0000796da41d5122  movaps [rsp+0x20], xmm2
0000796da41d5127  lea rdi, [rsp]
0000796da41d512b  mov esi, 0x00
0000796da41d5130  mov rax, 0x5E26CB66A530
0000796da41d513a  call rax
0000796da41d513c  movaps xmm1, [rsp]
0000796da41d5140  add rsp, 0x30
0000796da41d5144  vmovaps xmm0, [rsp]
0000796da41d5149  vmovaps xmm2, [rsp+0x10]
0000796da41d514f  vmovaps xmm3, [rsp+0x20]
0000796da41d5155  vmovaps xmm4, [rsp+0x30]
0000796da41d515b  vmovaps xmm5, [rsp+0x40]
0000796da41d5161  vmovaps xmm6, [rsp+0x50]
0000796da41d5167  vmovaps xmm7, [rsp+0x60]
0000796da41d516d  vmovaps xmm8, [rsp+0x70]
0000796da41d5173  vmovaps xmm9, [rsp+0x80]
0000796da41d517c  vmovaps xmm10, [rsp+0x90]
0000796da41d5185  vmovaps xmm11, [rsp+0xA0]
0000796da41d518e  vmovaps xmm12, [rsp+0xB0]
0000796da41d5197  vmovaps xmm13, [rsp+0xC0]
0000796da41d51a0  vmovaps xmm14, [rsp+0xD0]
0000796da41d51a9  vmovaps xmm15, [rsp+0xE0]
0000796da41d51b2  add rsp, 0xF0
0000796da41d51b9  pop r11
0000796da41d51bb  pop r10
0000796da41d51bd  pop r9
0000796da41d51bf  pop r8
0000796da41d51c1  pop rsi
0000796da41d51c2  pop rdi
0000796da41d51c3  pop rdx
0000796da41d51c4  pop rcx
0000796da41d51c5  pop rax
0000796da41d51c6  add rsp, 0x08
0000796da41d51ca  jmp 0x0000796DA41D2D79
0000796da41d51cf  sub rsp, 0x08
0000796da41d51d3  push rax
0000796da41d51d4  push rcx
0000796da41d51d5  push rdx
0000796da41d51d6  push rdi
0000796da41d51d7  push rsi
0000796da41d51d8  push r8
0000796da41d51da  push r9
0000796da41d51dc  push r10
0000796da41d51de  push r11
0000796da41d51e0  sub rsp, 0xF0
0000796da41d51e7  vmovaps [rsp], xmm0
0000796da41d51ec  vmovaps [rsp+0x10], xmm1
0000796da41d51f2  vmovaps [rsp+0x20], xmm3
0000796da41d51f8  vmovaps [rsp+0x30], xmm4
0000796da41d51fe  vmovaps [rsp+0x40], xmm5
0000796da41d5204  vmovaps [rsp+0x50], xmm6
0000796da41d520a  vmovaps [rsp+0x60], xmm7
0000796da41d5210  vmovaps [rsp+0x70], xmm8
0000796da41d5216  vmovaps [rsp+0x80], xmm9
0000796da41d521f  vmovaps [rsp+0x90], xmm10
0000796da41d5228  vmovaps [rsp+0xA0], xmm11
0000796da41d5231  vmovaps [rsp+0xB0], xmm12
0000796da41d523a  vmovaps [rsp+0xC0], xmm13
0000796da41d5243  vmovaps [rsp+0xD0], xmm14
0000796da41d524c  vmovaps [rsp+0xE0], xmm15
0000796da41d5255  sub rsp, 0x30
0000796da41d5259  movaps [rsp], xmm2
0000796da41d525d  movaps [rsp+0x10], xmm1
0000796da41d5262  movaps [rsp+0x20], xmm13
0000796da41d5268  lea rdi, [rsp]
0000796da41d526c  mov esi, 0x00
0000796da41d5271  mov rax, 0x5E26CB66A530
0000796da41d527b  call rax
0000796da41d527d  movaps xmm2, [rsp]
0000796da41d5281  add rsp, 0x30
0000796da41d5285  vmovaps xmm0, [rsp]
0000796da41d528a  vmovaps xmm1, [rsp+0x10]
0000796da41d5290  vmovaps xmm3, [rsp+0x20]
0000796da41d5296  vmovaps xmm4, [rsp+0x30]
0000796da41d529c  vmovaps xmm5, [rsp+0x40]
0000796da41d52a2  vmovaps xmm6, [rsp+0x50]
0000796da41d52a8  vmovaps xmm7, [rsp+0x60]
0000796da41d52ae  vmovaps xmm8, [rsp+0x70]
0000796da41d52b4  vmovaps xmm9, [rsp+0x80]
0000796da41d52bd  vmovaps xmm10, [rsp+0x90]
0000796da41d52c6  vmovaps xmm11, [rsp+0xA0]
0000796da41d52cf  vmovaps xmm12, [rsp+0xB0]
0000796da41d52d8  vmovaps xmm13, [rsp+0xC0]
0000796da41d52e1  vmovaps xmm14, [rsp+0xD0]
0000796da41d52ea  vmovaps xmm15, [rsp+0xE0]
0000796da41d52f3  add rsp, 0xF0
0000796da41d52fa  pop r11
0000796da41d52fc  pop r10
0000796da41d52fe  pop r9
0000796da41d5300  pop r8
0000796da41d5302  pop rsi
0000796da41d5303  pop rdi
0000796da41d5304  pop rdx
0000796da41d5305  pop rcx
0000796da41d5306  pop rax
0000796da41d5307  add rsp, 0x08
0000796da41d530b  jmp 0x0000796DA41D2DD2
0000796da41d5310  call 0x0000796DA3FFF430
0000796da41d5315  jmp 0x0000796DA41D2DDF
0000796da41d531a  sub rsp, 0x08
0000796da41d531e  push rax
0000796da41d531f  push rcx
0000796da41d5320  push rdx
0000796da41d5321  push rdi
0000796da41d5322  push rsi
0000796da41d5323  push r8
0000796da41d5325  push r9
0000796da41d5327  push r10
0000796da41d5329  push r11
0000796da41d532b  sub rsp, 0xF0
0000796da41d5332  vmovaps [rsp], xmm0
0000796da41d5337  vmovaps [rsp+0x10], xmm1
0000796da41d533d  vmovaps [rsp+0x20], xmm2
0000796da41d5343  vmovaps [rsp+0x30], xmm3
0000796da41d5349  vmovaps [rsp+0x40], xmm4
0000796da41d534f  vmovaps [rsp+0x50], xmm5
0000796da41d5355  vmovaps [rsp+0x60], xmm6
0000796da41d535b  vmovaps [rsp+0x70], xmm7
0000796da41d5361  vmovaps [rsp+0x80], xmm8
0000796da41d536a  vmovaps [rsp+0x90], xmm9
0000796da41d5373  vmovaps [rsp+0xA0], xmm10
0000796da41d537c  vmovaps [rsp+0xB0], xmm11
0000796da41d5385  vmovaps [rsp+0xC0], xmm12
0000796da41d538e  vmovaps [rsp+0xD0], xmm13
0000796da41d5397  vmovaps [rsp+0xE0], xmm14
0000796da41d53a0  sub rsp, 0x30
0000796da41d53a4  movaps [rsp], xmm15
0000796da41d53a9  movaps [rsp+0x10], xmm13
0000796da41d53af  movaps [rsp+0x20], xmm1
0000796da41d53b4  lea rdi, [rsp]
0000796da41d53b8  mov esi, 0x00
0000796da41d53bd  mov rax, 0x5E26CB66A530
0000796da41d53c7  call rax
0000796da41d53c9  movaps xmm15, [rsp]
0000796da41d53ce  add rsp, 0x30
0000796da41d53d2  vmovaps xmm0, [rsp]
0000796da41d53d7  vmovaps xmm1, [rsp+0x10]
0000796da41d53dd  vmovaps xmm2, [rsp+0x20]
0000796da41d53e3  vmovaps xmm3, [rsp+0x30]
0000796da41d53e9  vmovaps xmm4, [rsp+0x40]
0000796da41d53ef  vmovaps xmm5, [rsp+0x50]
0000796da41d53f5  vmovaps xmm6, [rsp+0x60]
0000796da41d53fb  vmovaps xmm7, [rsp+0x70]
0000796da41d5401  vmovaps xmm8, [rsp+0x80]
0000796da41d540a  vmovaps xmm9, [rsp+0x90]
0000796da41d5413  vmovaps xmm10, [rsp+0xA0]
0000796da41d541c  vmovaps xmm11, [rsp+0xB0]
0000796da41d5425  vmovaps xmm12, [rsp+0xC0]
0000796da41d542e  vmovaps xmm13, [rsp+0xD0]
0000796da41d5437  vmovaps xmm14, [rsp+0xE0]
0000796da41d5440  add rsp, 0xF0
0000796da41d5447  pop r11
0000796da41d5449  pop r10
0000796da41d544b  pop r9
0000796da41d544d  pop r8
0000796da41d544f  pop rsi
0000796da41d5450  pop rdi
0000796da41d5451  pop rdx
0000796da41d5452  pop rcx
0000796da41d5453  pop rax
0000796da41d5454  add rsp, 0x08
0000796da41d5458  jmp 0x0000796DA41D2E1E
0000796da41d545d  sub rsp, 0x08
0000796da41d5461  push rax
0000796da41d5462  push rcx
0000796da41d5463  push rdx
0000796da41d5464  push rdi
0000796da41d5465  push rsi
0000796da41d5466  push r8
0000796da41d5468  push r9
0000796da41d546a  push r10
0000796da41d546c  push r11
0000796da41d546e  sub rsp, 0xF0
0000796da41d5475  vmovaps [rsp], xmm0
0000796da41d547a  vmovaps [rsp+0x10], xmm1
0000796da41d5480  vmovaps [rsp+0x20], xmm2
0000796da41d5486  vmovaps [rsp+0x30], xmm3
0000796da41d548c  vmovaps [rsp+0x40], xmm4
0000796da41d5492  vmovaps [rsp+0x50], xmm5
0000796da41d5498  vmovaps [rsp+0x60], xmm6
0000796da41d549e  vmovaps [rsp+0x70], xmm7
0000796da41d54a4  vmovaps [rsp+0x80], xmm8
0000796da41d54ad  vmovaps [rsp+0x90], xmm9
0000796da41d54b6  vmovaps [rsp+0xA0], xmm10
0000796da41d54bf  vmovaps [rsp+0xB0], xmm11
0000796da41d54c8  vmovaps [rsp+0xC0], xmm12
0000796da41d54d1  vmovaps [rsp+0xD0], xmm13
0000796da41d54da  vmovaps [rsp+0xE0], xmm15
0000796da41d54e3  sub rsp, 0x30
0000796da41d54e7  movaps [rsp], xmm14
0000796da41d54ec  movaps [rsp+0x10], xmm11
0000796da41d54f2  movaps [rsp+0x20], xmm1
0000796da41d54f7  lea rdi, [rsp]
0000796da41d54fb  mov esi, 0x00
0000796da41d5500  mov rax, 0x5E26CB66A530
0000796da41d550a  call rax
0000796da41d550c  movaps xmm14, [rsp]
0000796da41d5511  add rsp, 0x30
0000796da41d5515  vmovaps xmm0, [rsp]
0000796da41d551a  vmovaps xmm1, [rsp+0x10]
0000796da41d5520  vmovaps xmm2, [rsp+0x20]
0000796da41d5526  vmovaps xmm3, [rsp+0x30]
0000796da41d552c  vmovaps xmm4, [rsp+0x40]
0000796da41d5532  vmovaps xmm5, [rsp+0x50]
0000796da41d5538  vmovaps xmm6, [rsp+0x60]
0000796da41d553e  vmovaps xmm7, [rsp+0x70]
0000796da41d5544  vmovaps xmm8, [rsp+0x80]
0000796da41d554d  vmovaps xmm9, [rsp+0x90]
0000796da41d5556  vmovaps xmm10, [rsp+0xA0]
0000796da41d555f  vmovaps xmm11, [rsp+0xB0]
0000796da41d5568  vmovaps xmm12, [rsp+0xC0]
0000796da41d5571  vmovaps xmm13, [rsp+0xD0]
0000796da41d557a  vmovaps xmm15, [rsp+0xE0]
0000796da41d5583  add rsp, 0xF0
0000796da41d558a  pop r11
0000796da41d558c  pop r10
0000796da41d558e  pop r9
0000796da41d5590  pop r8
0000796da41d5592  pop rsi
0000796da41d5593  pop rdi
0000796da41d5594  pop rdx
0000796da41d5595  pop rcx
0000796da41d5596  pop rax
0000796da41d5597  add rsp, 0x08
0000796da41d559b  jmp 0x0000796DA41D2E48
0000796da41d55a0  sub rsp, 0x08
0000796da41d55a4  push rax
0000796da41d55a5  push rcx
0000796da41d55a6  push rdx
0000796da41d55a7  push rdi
0000796da41d55a8  push rsi
0000796da41d55a9  push r8
0000796da41d55ab  push r9
0000796da41d55ad  push r10
0000796da41d55af  push r11
0000796da41d55b1  sub rsp, 0xF0
0000796da41d55b8  vmovaps [rsp], xmm0
0000796da41d55bd  vmovaps [rsp+0x10], xmm1
0000796da41d55c3  vmovaps [rsp+0x20], xmm2
0000796da41d55c9  vmovaps [rsp+0x30], xmm3
0000796da41d55cf  vmovaps [rsp+0x40], xmm4
0000796da41d55d5  vmovaps [rsp+0x50], xmm5
0000796da41d55db  vmovaps [rsp+0x60], xmm6
0000796da41d55e1  vmovaps [rsp+0x70], xmm7
0000796da41d55e7  vmovaps [rsp+0x80], xmm8
0000796da41d55f0  vmovaps [rsp+0x90], xmm9
0000796da41d55f9  vmovaps [rsp+0xA0], xmm10
0000796da41d5602  vmovaps [rsp+0xB0], xmm11
0000796da41d560b  vmovaps [rsp+0xC0], xmm12
0000796da41d5614  vmovaps [rsp+0xD0], xmm14
0000796da41d561d  vmovaps [rsp+0xE0], xmm15
0000796da41d5626  sub rsp, 0x30
0000796da41d562a  movaps [rsp], xmm13
0000796da41d562f  movaps [rsp+0x10], xmm11
0000796da41d5635  movaps [rsp+0x20], xmm1
0000796da41d563a  lea rdi, [rsp]
0000796da41d563e  mov esi, 0x00
0000796da41d5643  mov rax, 0x5E26CB66A530
0000796da41d564d  call rax
0000796da41d564f  movaps xmm13, [rsp]
0000796da41d5654  add rsp, 0x30
0000796da41d5658  vmovaps xmm0, [rsp]
0000796da41d565d  vmovaps xmm1, [rsp+0x10]
0000796da41d5663  vmovaps xmm2, [rsp+0x20]
0000796da41d5669  vmovaps xmm3, [rsp+0x30]
0000796da41d566f  vmovaps xmm4, [rsp+0x40]
0000796da41d5675  vmovaps xmm5, [rsp+0x50]
0000796da41d567b  vmovaps xmm6, [rsp+0x60]
0000796da41d5681  vmovaps xmm7, [rsp+0x70]
0000796da41d5687  vmovaps xmm8, [rsp+0x80]
0000796da41d5690  vmovaps xmm9, [rsp+0x90]
0000796da41d5699  vmovaps xmm10, [rsp+0xA0]
0000796da41d56a2  vmovaps xmm11, [rsp+0xB0]
0000796da41d56ab  vmovaps xmm12, [rsp+0xC0]
0000796da41d56b4  vmovaps xmm14, [rsp+0xD0]
0000796da41d56bd  vmovaps xmm15, [rsp+0xE0]
0000796da41d56c6  add rsp, 0xF0
0000796da41d56cd  pop r11
0000796da41d56cf  pop r10
0000796da41d56d1  pop r9
0000796da41d56d3  pop r8
0000796da41d56d5  pop rsi
0000796da41d56d6  pop rdi
0000796da41d56d7  pop rdx
0000796da41d56d8  pop rcx
0000796da41d56d9  pop rax
0000796da41d56da  add rsp, 0x08
0000796da41d56de  jmp 0x0000796DA41D2E9D
0000796da41d56e3  call 0x0000796DA3FFF430
0000796da41d56e8  jmp 0x0000796DA41D2EAA
0000796da41d56ed  sub rsp, 0x08
0000796da41d56f1  push rax
0000796da41d56f2  push rcx
0000796da41d56f3  push rdx
0000796da41d56f4  push rdi
0000796da41d56f5  push rsi
0000796da41d56f6  push r8
0000796da41d56f8  push r9
0000796da41d56fa  push r10
0000796da41d56fc  push r11
0000796da41d56fe  sub rsp, 0xF0
0000796da41d5705  vmovaps [rsp], xmm0
0000796da41d570a  vmovaps [rsp+0x10], xmm1
0000796da41d5710  vmovaps [rsp+0x20], xmm2
0000796da41d5716  vmovaps [rsp+0x30], xmm3
0000796da41d571c  vmovaps [rsp+0x40], xmm4
0000796da41d5722  vmovaps [rsp+0x50], xmm5
0000796da41d5728  vmovaps [rsp+0x60], xmm6
0000796da41d572e  vmovaps [rsp+0x70], xmm7
0000796da41d5734  vmovaps [rsp+0x80], xmm8
0000796da41d573d  vmovaps [rsp+0x90], xmm9
0000796da41d5746  vmovaps [rsp+0xA0], xmm10
0000796da41d574f  vmovaps [rsp+0xB0], xmm11
0000796da41d5758  vmovaps [rsp+0xC0], xmm12
0000796da41d5761  vmovaps [rsp+0xD0], xmm13
0000796da41d576a  vmovaps [rsp+0xE0], xmm14
0000796da41d5773  sub rsp, 0x30
0000796da41d5777  movaps [rsp], xmm15
0000796da41d577c  movaps [rsp+0x10], xmm11
0000796da41d5782  movaps [rsp+0x20], xmm1
0000796da41d5787  lea rdi, [rsp]
0000796da41d578b  mov esi, 0x00
0000796da41d5790  mov rax, 0x5E26CB66A530
0000796da41d579a  call rax
0000796da41d579c  movaps xmm15, [rsp]
0000796da41d57a1  add rsp, 0x30
0000796da41d57a5  vmovaps xmm0, [rsp]
0000796da41d57aa  vmovaps xmm1, [rsp+0x10]
0000796da41d57b0  vmovaps xmm2, [rsp+0x20]
0000796da41d57b6  vmovaps xmm3, [rsp+0x30]
0000796da41d57bc  vmovaps xmm4, [rsp+0x40]
0000796da41d57c2  vmovaps xmm5, [rsp+0x50]
0000796da41d57c8  vmovaps xmm6, [rsp+0x60]
0000796da41d57ce  vmovaps xmm7, [rsp+0x70]
0000796da41d57d4  vmovaps xmm8, [rsp+0x80]
0000796da41d57dd  vmovaps xmm9, [rsp+0x90]
0000796da41d57e6  vmovaps xmm10, [rsp+0xA0]
0000796da41d57ef  vmovaps xmm11, [rsp+0xB0]
0000796da41d57f8  vmovaps xmm12, [rsp+0xC0]
0000796da41d5801  vmovaps xmm13, [rsp+0xD0]
0000796da41d580a  vmovaps xmm14, [rsp+0xE0]
0000796da41d5813  add rsp, 0xF0
0000796da41d581a  pop r11
0000796da41d581c  pop r10
0000796da41d581e  pop r9
0000796da41d5820  pop r8
0000796da41d5822  pop rsi
0000796da41d5823  pop rdi
0000796da41d5824  pop rdx
0000796da41d5825  pop rcx
0000796da41d5826  pop rax
0000796da41d5827  add rsp, 0x08
0000796da41d582b  jmp 0x0000796DA41D2EE3
0000796da41d5830  sub rsp, 0x08
0000796da41d5834  push rax
0000796da41d5835  push rcx
0000796da41d5836  push rdx
0000796da41d5837  push rdi
0000796da41d5838  push rsi
0000796da41d5839  push r8
0000796da41d583b  push r9
0000796da41d583d  push r10
0000796da41d583f  push r11
0000796da41d5841  sub rsp, 0xF0
0000796da41d5848  vmovaps [rsp], xmm0
0000796da41d584d  vmovaps [rsp+0x10], xmm1
0000796da41d5853  vmovaps [rsp+0x20], xmm2
0000796da41d5859  vmovaps [rsp+0x30], xmm3
0000796da41d585f  vmovaps [rsp+0x40], xmm4
0000796da41d5865  vmovaps [rsp+0x50], xmm5
0000796da41d586b  vmovaps [rsp+0x60], xmm6
0000796da41d5871  vmovaps [rsp+0x70], xmm7
0000796da41d5877  vmovaps [rsp+0x80], xmm8
0000796da41d5880  vmovaps [rsp+0x90], xmm9
0000796da41d5889  vmovaps [rsp+0xA0], xmm10
0000796da41d5892  vmovaps [rsp+0xB0], xmm12
0000796da41d589b  vmovaps [rsp+0xC0], xmm13
0000796da41d58a4  vmovaps [rsp+0xD0], xmm14
0000796da41d58ad  vmovaps [rsp+0xE0], xmm15
0000796da41d58b6  sub rsp, 0x30
0000796da41d58ba  movaps [rsp], xmm11
0000796da41d58bf  movaps [rsp+0x10], xmm6
0000796da41d58c4  movaps [rsp+0x20], xmm14
0000796da41d58ca  lea rdi, [rsp]
0000796da41d58ce  mov esi, 0x00
0000796da41d58d3  mov rax, 0x5E26CB66A530
0000796da41d58dd  call rax
0000796da41d58df  movaps xmm11, [rsp]
0000796da41d58e4  add rsp, 0x30
0000796da41d58e8  vmovaps xmm0, [rsp]
0000796da41d58ed  vmovaps xmm1, [rsp+0x10]
0000796da41d58f3  vmovaps xmm2, [rsp+0x20]
0000796da41d58f9  vmovaps xmm3, [rsp+0x30]
0000796da41d58ff  vmovaps xmm4, [rsp+0x40]
0000796da41d5905  vmovaps xmm5, [rsp+0x50]
0000796da41d590b  vmovaps xmm6, [rsp+0x60]
0000796da41d5911  vmovaps xmm7, [rsp+0x70]
0000796da41d5917  vmovaps xmm8, [rsp+0x80]
0000796da41d5920  vmovaps xmm9, [rsp+0x90]
0000796da41d5929  vmovaps xmm10, [rsp+0xA0]
0000796da41d5932  vmovaps xmm12, [rsp+0xB0]
0000796da41d593b  vmovaps xmm13, [rsp+0xC0]
0000796da41d5944  vmovaps xmm14, [rsp+0xD0]
0000796da41d594d  vmovaps xmm15, [rsp+0xE0]
0000796da41d5956  add rsp, 0xF0
0000796da41d595d  pop r11
0000796da41d595f  pop r10
0000796da41d5961  pop r9
0000796da41d5963  pop r8
0000796da41d5965  pop rsi
0000796da41d5966  pop rdi
0000796da41d5967  pop rdx
0000796da41d5968  pop rcx
0000796da41d5969  pop rax
0000796da41d596a  add rsp, 0x08
0000796da41d596e  jmp 0x0000796DA41D2F5B
0000796da41d5973  call 0x0000796DA3FFF430
0000796da41d5978  jmp 0x0000796DA41D2F65
0000796da41d597d  sub rsp, 0x08
0000796da41d5981  push rax
0000796da41d5982  push rcx
0000796da41d5983  push rdx
0000796da41d5984  push rdi
0000796da41d5985  push rsi
0000796da41d5986  push r8
0000796da41d5988  push r9
0000796da41d598a  push r10
0000796da41d598c  push r11
0000796da41d598e  sub rsp, 0xF0
0000796da41d5995  vmovaps [rsp], xmm0
0000796da41d599a  vmovaps [rsp+0x10], xmm1
0000796da41d59a0  vmovaps [rsp+0x20], xmm2
0000796da41d59a6  vmovaps [rsp+0x30], xmm3
0000796da41d59ac  vmovaps [rsp+0x40], xmm4
0000796da41d59b2  vmovaps [rsp+0x50], xmm5
0000796da41d59b8  vmovaps [rsp+0x60], xmm6
0000796da41d59be  vmovaps [rsp+0x70], xmm7
0000796da41d59c4  vmovaps [rsp+0x80], xmm8
0000796da41d59cd  vmovaps [rsp+0x90], xmm9
0000796da41d59d6  vmovaps [rsp+0xA0], xmm10
0000796da41d59df  vmovaps [rsp+0xB0], xmm11
0000796da41d59e8  vmovaps [rsp+0xC0], xmm12
0000796da41d59f1  vmovaps [rsp+0xD0], xmm13
0000796da41d59fa  vmovaps [rsp+0xE0], xmm15
0000796da41d5a03  sub rsp, 0x30
0000796da41d5a07  movaps [rsp], xmm14
0000796da41d5a0c  movaps [rsp+0x10], xmm6
0000796da41d5a11  movaps [rsp+0x20], xmm2
0000796da41d5a16  lea rdi, [rsp]
0000796da41d5a1a  mov esi, 0x00
0000796da41d5a1f  mov rax, 0x5E26CB66A530
0000796da41d5a29  call rax
0000796da41d5a2b  movaps xmm14, [rsp]
0000796da41d5a30  add rsp, 0x30
0000796da41d5a34  vmovaps xmm0, [rsp]
0000796da41d5a39  vmovaps xmm1, [rsp+0x10]
0000796da41d5a3f  vmovaps xmm2, [rsp+0x20]
0000796da41d5a45  vmovaps xmm3, [rsp+0x30]
0000796da41d5a4b  vmovaps xmm4, [rsp+0x40]
0000796da41d5a51  vmovaps xmm5, [rsp+0x50]
0000796da41d5a57  vmovaps xmm6, [rsp+0x60]
0000796da41d5a5d  vmovaps xmm7, [rsp+0x70]
0000796da41d5a63  vmovaps xmm8, [rsp+0x80]
0000796da41d5a6c  vmovaps xmm9, [rsp+0x90]
0000796da41d5a75  vmovaps xmm10, [rsp+0xA0]
0000796da41d5a7e  vmovaps xmm11, [rsp+0xB0]
0000796da41d5a87  vmovaps xmm12, [rsp+0xC0]
0000796da41d5a90  vmovaps xmm13, [rsp+0xD0]
0000796da41d5a99  vmovaps xmm15, [rsp+0xE0]
0000796da41d5aa2  add rsp, 0xF0
0000796da41d5aa9  pop r11
0000796da41d5aab  pop r10
0000796da41d5aad  pop r9
0000796da41d5aaf  pop r8
0000796da41d5ab1  pop rsi
0000796da41d5ab2  pop rdi
0000796da41d5ab3  pop rdx
0000796da41d5ab4  pop rcx
0000796da41d5ab5  pop rax
0000796da41d5ab6  add rsp, 0x08
0000796da41d5aba  jmp 0x0000796DA41D2F99
0000796da41d5abf  sub rsp, 0x08
0000796da41d5ac3  push rax
0000796da41d5ac4  push rcx
0000796da41d5ac5  push rdx
0000796da41d5ac6  push rdi
0000796da41d5ac7  push rsi
0000796da41d5ac8  push r8
0000796da41d5aca  push r9
0000796da41d5acc  push r10
0000796da41d5ace  push r11
0000796da41d5ad0  sub rsp, 0xF0
0000796da41d5ad7  vmovaps [rsp], xmm0
0000796da41d5adc  vmovaps [rsp+0x10], xmm1
0000796da41d5ae2  vmovaps [rsp+0x20], xmm2
0000796da41d5ae8  vmovaps [rsp+0x30], xmm3
0000796da41d5aee  vmovaps [rsp+0x40], xmm4
0000796da41d5af4  vmovaps [rsp+0x50], xmm5
0000796da41d5afa  vmovaps [rsp+0x60], xmm7
0000796da41d5b00  vmovaps [rsp+0x70], xmm8
0000796da41d5b06  vmovaps [rsp+0x80], xmm9
0000796da41d5b0f  vmovaps [rsp+0x90], xmm10
0000796da41d5b18  vmovaps [rsp+0xA0], xmm11
0000796da41d5b21  vmovaps [rsp+0xB0], xmm12
0000796da41d5b2a  vmovaps [rsp+0xC0], xmm13
0000796da41d5b33  vmovaps [rsp+0xD0], xmm14
0000796da41d5b3c  vmovaps [rsp+0xE0], xmm15
0000796da41d5b45  sub rsp, 0x30
0000796da41d5b49  movaps [rsp], xmm6
0000796da41d5b4d  movaps [rsp+0x10], xmm5
0000796da41d5b52  movaps [rsp+0x20], xmm1
0000796da41d5b57  lea rdi, [rsp]
0000796da41d5b5b  mov esi, 0x00
0000796da41d5b60  mov rax, 0x5E26CB66A530
0000796da41d5b6a  call rax
0000796da41d5b6c  movaps xmm6, [rsp]
0000796da41d5b70  add rsp, 0x30
0000796da41d5b74  vmovaps xmm0, [rsp]
0000796da41d5b79  vmovaps xmm1, [rsp+0x10]
0000796da41d5b7f  vmovaps xmm2, [rsp+0x20]
0000796da41d5b85  vmovaps xmm3, [rsp+0x30]
0000796da41d5b8b  vmovaps xmm4, [rsp+0x40]
0000796da41d5b91  vmovaps xmm5, [rsp+0x50]
0000796da41d5b97  vmovaps xmm7, [rsp+0x60]
0000796da41d5b9d  vmovaps xmm8, [rsp+0x70]
0000796da41d5ba3  vmovaps xmm9, [rsp+0x80]
0000796da41d5bac  vmovaps xmm10, [rsp+0x90]
0000796da41d5bb5  vmovaps xmm11, [rsp+0xA0]
0000796da41d5bbe  vmovaps xmm12, [rsp+0xB0]
0000796da41d5bc7  vmovaps xmm13, [rsp+0xC0]
0000796da41d5bd0  vmovaps xmm14, [rsp+0xD0]
0000796da41d5bd9  vmovaps xmm15, [rsp+0xE0]
0000796da41d5be2  add rsp, 0xF0
0000796da41d5be9  pop r11
0000796da41d5beb  pop r10
0000796da41d5bed  pop r9
0000796da41d5bef  pop r8
0000796da41d5bf1  pop rsi
0000796da41d5bf2  pop rdi
0000796da41d5bf3  pop rdx
0000796da41d5bf4  pop rcx
0000796da41d5bf5  pop rax
0000796da41d5bf6  add rsp, 0x08
0000796da41d5bfa  jmp 0x0000796DA41D2FBF
0000796da41d5bff  sub rsp, 0x08
0000796da41d5c03  push rax
0000796da41d5c04  push rcx
0000796da41d5c05  push rdx
0000796da41d5c06  push rdi
0000796da41d5c07  push rsi
0000796da41d5c08  push r8
0000796da41d5c0a  push r9
0000796da41d5c0c  push r10
0000796da41d5c0e  push r11
0000796da41d5c10  sub rsp, 0xF0
0000796da41d5c17  vmovaps [rsp], xmm0
0000796da41d5c1c  vmovaps [rsp+0x10], xmm2
0000796da41d5c22  vmovaps [rsp+0x20], xmm3
0000796da41d5c28  vmovaps [rsp+0x30], xmm4
0000796da41d5c2e  vmovaps [rsp+0x40], xmm5
0000796da41d5c34  vmovaps [rsp+0x50], xmm6
0000796da41d5c3a  vmovaps [rsp+0x60], xmm7
0000796da41d5c40  vmovaps [rsp+0x70], xmm8
0000796da41d5c46  vmovaps [rsp+0x80], xmm9
0000796da41d5c4f  vmovaps [rsp+0x90], xmm10
0000796da41d5c58  vmovaps [rsp+0xA0], xmm11
0000796da41d5c61  vmovaps [rsp+0xB0], xmm12
0000796da41d5c6a  vmovaps [rsp+0xC0], xmm13
0000796da41d5c73  vmovaps [rsp+0xD0], xmm14
0000796da41d5c7c  vmovaps [rsp+0xE0], xmm15
0000796da41d5c85  sub rsp, 0x30
0000796da41d5c89  movaps [rsp], xmm1
0000796da41d5c8d  movaps [rsp+0x10], xmm5
0000796da41d5c92  movaps [rsp+0x20], xmm13
0000796da41d5c98  lea rdi, [rsp]
0000796da41d5c9c  mov esi, 0x00
0000796da41d5ca1  mov rax, 0x5E26CB66A530
0000796da41d5cab  call rax
0000796da41d5cad  movaps xmm1, [rsp]
0000796da41d5cb1  add rsp, 0x30
0000796da41d5cb5  vmovaps xmm0, [rsp]
0000796da41d5cba  vmovaps xmm2, [rsp+0x10]
0000796da41d5cc0  vmovaps xmm3, [rsp+0x20]
0000796da41d5cc6  vmovaps xmm4, [rsp+0x30]
0000796da41d5ccc  vmovaps xmm5, [rsp+0x40]
0000796da41d5cd2  vmovaps xmm6, [rsp+0x50]
0000796da41d5cd8  vmovaps xmm7, [rsp+0x60]
0000796da41d5cde  vmovaps xmm8, [rsp+0x70]
0000796da41d5ce4  vmovaps xmm9, [rsp+0x80]
0000796da41d5ced  vmovaps xmm10, [rsp+0x90]
0000796da41d5cf6  vmovaps xmm11, [rsp+0xA0]
0000796da41d5cff  vmovaps xmm12, [rsp+0xB0]
0000796da41d5d08  vmovaps xmm13, [rsp+0xC0]
0000796da41d5d11  vmovaps xmm14, [rsp+0xD0]
0000796da41d5d1a  vmovaps xmm15, [rsp+0xE0]
0000796da41d5d23  add rsp, 0xF0
0000796da41d5d2a  pop r11
0000796da41d5d2c  pop r10
0000796da41d5d2e  pop r9
0000796da41d5d30  pop r8
0000796da41d5d32  pop rsi
0000796da41d5d33  pop rdi
0000796da41d5d34  pop rdx
0000796da41d5d35  pop rcx
0000796da41d5d36  pop rax
0000796da41d5d37  add rsp, 0x08
0000796da41d5d3b  jmp 0x0000796DA41D2FDD
0000796da41d5d40  sub rsp, 0x08
0000796da41d5d44  push rax
0000796da41d5d45  push rcx
0000796da41d5d46  push rdx
0000796da41d5d47  push rdi
0000796da41d5d48  push rsi
0000796da41d5d49  push r8
0000796da41d5d4b  push r9
0000796da41d5d4d  push r10
0000796da41d5d4f  push r11
0000796da41d5d51  sub rsp, 0xF0
0000796da41d5d58  vmovaps [rsp], xmm0
0000796da41d5d5d  vmovaps [rsp+0x10], xmm1
0000796da41d5d63  vmovaps [rsp+0x20], xmm2
0000796da41d5d69  vmovaps [rsp+0x30], xmm3
0000796da41d5d6f  vmovaps [rsp+0x40], xmm4
0000796da41d5d75  vmovaps [rsp+0x50], xmm6
0000796da41d5d7b  vmovaps [rsp+0x60], xmm7
0000796da41d5d81  vmovaps [rsp+0x70], xmm8
0000796da41d5d87  vmovaps [rsp+0x80], xmm9
0000796da41d5d90  vmovaps [rsp+0x90], xmm10
0000796da41d5d99  vmovaps [rsp+0xA0], xmm11
0000796da41d5da2  vmovaps [rsp+0xB0], xmm12
0000796da41d5dab  vmovaps [rsp+0xC0], xmm13
0000796da41d5db4  vmovaps [rsp+0xD0], xmm14
0000796da41d5dbd  vmovaps [rsp+0xE0], xmm15
0000796da41d5dc6  sub rsp, 0x30
0000796da41d5dca  movaps [rsp], xmm5
0000796da41d5dce  movaps [rsp+0x10], xmm2
0000796da41d5dd3  movaps [rsp+0x20], xmm13
0000796da41d5dd9  lea rdi, [rsp]
0000796da41d5ddd  mov esi, 0x00
0000796da41d5de2  mov rax, 0x5E26CB66A530
0000796da41d5dec  call rax
0000796da41d5dee  movaps xmm5, [rsp]
0000796da41d5df2  add rsp, 0x30
0000796da41d5df6  vmovaps xmm0, [rsp]
0000796da41d5dfb  vmovaps xmm1, [rsp+0x10]
0000796da41d5e01  vmovaps xmm2, [rsp+0x20]
0000796da41d5e07  vmovaps xmm3, [rsp+0x30]
0000796da41d5e0d  vmovaps xmm4, [rsp+0x40]
0000796da41d5e13  vmovaps xmm6, [rsp+0x50]
0000796da41d5e19  vmovaps xmm7, [rsp+0x60]
0000796da41d5e1f  vmovaps xmm8, [rsp+0x70]
0000796da41d5e25  vmovaps xmm9, [rsp+0x80]
0000796da41d5e2e  vmovaps xmm10, [rsp+0x90]
0000796da41d5e37  vmovaps xmm11, [rsp+0xA0]
0000796da41d5e40  vmovaps xmm12, [rsp+0xB0]
0000796da41d5e49  vmovaps xmm13, [rsp+0xC0]
0000796da41d5e52  vmovaps xmm14, [rsp+0xD0]
0000796da41d5e5b  vmovaps xmm15, [rsp+0xE0]
0000796da41d5e64  add rsp, 0xF0
0000796da41d5e6b  pop r11
0000796da41d5e6d  pop r10
0000796da41d5e6f  pop r9
0000796da41d5e71  pop r8
0000796da41d5e73  pop rsi
0000796da41d5e74  pop rdi
0000796da41d5e75  pop rdx
0000796da41d5e76  pop rcx
0000796da41d5e77  pop rax
0000796da41d5e78  add rsp, 0x08
0000796da41d5e7c  jmp 0x0000796DA41D3013
0000796da41d5e81  sub rsp, 0x08
0000796da41d5e85  push rax
0000796da41d5e86  push rcx
0000796da41d5e87  push rdx
0000796da41d5e88  push rdi
0000796da41d5e89  push rsi
0000796da41d5e8a  push r8
0000796da41d5e8c  push r9
0000796da41d5e8e  push r10
0000796da41d5e90  push r11
0000796da41d5e92  sub rsp, 0xF0
0000796da41d5e99  vmovaps [rsp], xmm0
0000796da41d5e9e  vmovaps [rsp+0x10], xmm1
0000796da41d5ea4  vmovaps [rsp+0x20], xmm2
0000796da41d5eaa  vmovaps [rsp+0x30], xmm3
0000796da41d5eb0  vmovaps [rsp+0x40], xmm4
0000796da41d5eb6  vmovaps [rsp+0x50], xmm5
0000796da41d5ebc  vmovaps [rsp+0x60], xmm6
0000796da41d5ec2  vmovaps [rsp+0x70], xmm7
0000796da41d5ec8  vmovaps [rsp+0x80], xmm8
0000796da41d5ed1  vmovaps [rsp+0x90], xmm9
0000796da41d5eda  vmovaps [rsp+0xA0], xmm10
0000796da41d5ee3  vmovaps [rsp+0xB0], xmm11
0000796da41d5eec  vmovaps [rsp+0xC0], xmm12
0000796da41d5ef5  vmovaps [rsp+0xD0], xmm14
0000796da41d5efe  vmovaps [rsp+0xE0], xmm15
0000796da41d5f07  sub rsp, 0x30
0000796da41d5f0b  movaps [rsp], xmm13
0000796da41d5f10  movaps [rsp+0x10], xmm10
0000796da41d5f16  movaps [rsp+0x20], xmm1
0000796da41d5f1b  lea rdi, [rsp]
0000796da41d5f1f  mov esi, 0x00
0000796da41d5f24  mov rax, 0x5E26CB66A530
0000796da41d5f2e  call rax
0000796da41d5f30  movaps xmm13, [rsp]
0000796da41d5f35  add rsp, 0x30
0000796da41d5f39  vmovaps xmm0, [rsp]
0000796da41d5f3e  vmovaps xmm1, [rsp+0x10]
0000796da41d5f44  vmovaps xmm2, [rsp+0x20]
0000796da41d5f4a  vmovaps xmm3, [rsp+0x30]
0000796da41d5f50  vmovaps xmm4, [rsp+0x40]
0000796da41d5f56  vmovaps xmm5, [rsp+0x50]
0000796da41d5f5c  vmovaps xmm6, [rsp+0x60]
0000796da41d5f62  vmovaps xmm7, [rsp+0x70]
0000796da41d5f68  vmovaps xmm8, [rsp+0x80]
0000796da41d5f71  vmovaps xmm9, [rsp+0x90]
0000796da41d5f7a  vmovaps xmm10, [rsp+0xA0]
0000796da41d5f83  vmovaps xmm11, [rsp+0xB0]
0000796da41d5f8c  vmovaps xmm12, [rsp+0xC0]
0000796da41d5f95  vmovaps xmm14, [rsp+0xD0]
0000796da41d5f9e  vmovaps xmm15, [rsp+0xE0]
0000796da41d5fa7  add rsp, 0xF0
0000796da41d5fae  pop r11
0000796da41d5fb0  pop r10
0000796da41d5fb2  pop r9
0000796da41d5fb4  pop r8
0000796da41d5fb6  pop rsi
0000796da41d5fb7  pop rdi
0000796da41d5fb8  pop rdx
0000796da41d5fb9  pop rcx
0000796da41d5fba  pop rax
0000796da41d5fbb  add rsp, 0x08
0000796da41d5fbf  jmp 0x0000796DA41D303C
0000796da41d5fc4  sub rsp, 0x08
0000796da41d5fc8  push rax
0000796da41d5fc9  push rcx
0000796da41d5fca  push rdx
0000796da41d5fcb  push rdi
0000796da41d5fcc  push rsi
0000796da41d5fcd  push r8
0000796da41d5fcf  push r9
0000796da41d5fd1  push r10
0000796da41d5fd3  push r11
0000796da41d5fd5  sub rsp, 0xF0
0000796da41d5fdc  vmovaps [rsp], xmm0
0000796da41d5fe1  vmovaps [rsp+0x10], xmm2
0000796da41d5fe7  vmovaps [rsp+0x20], xmm3
0000796da41d5fed  vmovaps [rsp+0x30], xmm4
0000796da41d5ff3  vmovaps [rsp+0x40], xmm5
0000796da41d5ff9  vmovaps [rsp+0x50], xmm6
0000796da41d5fff  vmovaps [rsp+0x60], xmm7
0000796da41d6005  vmovaps [rsp+0x70], xmm8
0000796da41d600b  vmovaps [rsp+0x80], xmm9
0000796da41d6014  vmovaps [rsp+0x90], xmm10
0000796da41d601d  vmovaps [rsp+0xA0], xmm11
0000796da41d6026  vmovaps [rsp+0xB0], xmm12
0000796da41d602f  vmovaps [rsp+0xC0], xmm13
0000796da41d6038  vmovaps [rsp+0xD0], xmm14
0000796da41d6041  vmovaps [rsp+0xE0], xmm15
0000796da41d604a  sub rsp, 0x30
0000796da41d604e  movaps [rsp], xmm1
0000796da41d6052  movaps [rsp+0x10], xmm15
0000796da41d6058  movaps [rsp+0x20], xmm10
0000796da41d605e  lea rdi, [rsp]
0000796da41d6062  mov esi, 0x00
0000796da41d6067  mov rax, 0x5E26CB66A530
0000796da41d6071  call rax
0000796da41d6073  movaps xmm1, [rsp]
0000796da41d6077  add rsp, 0x30
0000796da41d607b  vmovaps xmm0, [rsp]
0000796da41d6080  vmovaps xmm2, [rsp+0x10]
0000796da41d6086  vmovaps xmm3, [rsp+0x20]
0000796da41d608c  vmovaps xmm4, [rsp+0x30]
0000796da41d6092  vmovaps xmm5, [rsp+0x40]
0000796da41d6098  vmovaps xmm6, [rsp+0x50]
0000796da41d609e  vmovaps xmm7, [rsp+0x60]
0000796da41d60a4  vmovaps xmm8, [rsp+0x70]
0000796da41d60aa  vmovaps xmm9, [rsp+0x80]
0000796da41d60b3  vmovaps xmm10, [rsp+0x90]
0000796da41d60bc  vmovaps xmm11, [rsp+0xA0]
0000796da41d60c5  vmovaps xmm12, [rsp+0xB0]
0000796da41d60ce  vmovaps xmm13, [rsp+0xC0]
0000796da41d60d7  vmovaps xmm14, [rsp+0xD0]
0000796da41d60e0  vmovaps xmm15, [rsp+0xE0]
0000796da41d60e9  add rsp, 0xF0
0000796da41d60f0  pop r11
0000796da41d60f2  pop r10
0000796da41d60f4  pop r9
0000796da41d60f6  pop r8
0000796da41d60f8  pop rsi
0000796da41d60f9  pop rdi
0000796da41d60fa  pop rdx
0000796da41d60fb  pop rcx
0000796da41d60fc  pop rax
0000796da41d60fd  add rsp, 0x08
0000796da41d6101  jmp 0x0000796DA41D305B
0000796da41d6106  sub rsp, 0x08
0000796da41d610a  push rax
0000796da41d610b  push rcx
0000796da41d610c  push rdx
0000796da41d610d  push rdi
0000796da41d610e  push rsi
0000796da41d610f  push r8
0000796da41d6111  push r9
0000796da41d6113  push r10
0000796da41d6115  push r11
0000796da41d6117  sub rsp, 0xF0
0000796da41d611e  vmovaps [rsp], xmm0
0000796da41d6123  vmovaps [rsp+0x10], xmm1
0000796da41d6129  vmovaps [rsp+0x20], xmm2
0000796da41d612f  vmovaps [rsp+0x30], xmm3
0000796da41d6135  vmovaps [rsp+0x40], xmm4
0000796da41d613b  vmovaps [rsp+0x50], xmm5
0000796da41d6141  vmovaps [rsp+0x60], xmm6
0000796da41d6147  vmovaps [rsp+0x70], xmm7
0000796da41d614d  vmovaps [rsp+0x80], xmm8
0000796da41d6156  vmovaps [rsp+0x90], xmm9
0000796da41d615f  vmovaps [rsp+0xA0], xmm10
0000796da41d6168  vmovaps [rsp+0xB0], xmm11
0000796da41d6171  vmovaps [rsp+0xC0], xmm12
0000796da41d617a  vmovaps [rsp+0xD0], xmm13
0000796da41d6183  vmovaps [rsp+0xE0], xmm14
0000796da41d618c  sub rsp, 0x30
0000796da41d6190  movaps [rsp], xmm15
0000796da41d6195  movaps [rsp+0x10], xmm10
0000796da41d619b  movaps [rsp+0x20], xmm11
0000796da41d61a1  lea rdi, [rsp]
0000796da41d61a5  mov esi, 0x00
0000796da41d61aa  mov rax, 0x5E26CB66A530
0000796da41d61b4  call rax
0000796da41d61b6  movaps xmm15, [rsp]
0000796da41d61bb  add rsp, 0x30
0000796da41d61bf  vmovaps xmm0, [rsp]
0000796da41d61c4  vmovaps xmm1, [rsp+0x10]
0000796da41d61ca  vmovaps xmm2, [rsp+0x20]
0000796da41d61d0  vmovaps xmm3, [rsp+0x30]
0000796da41d61d6  vmovaps xmm4, [rsp+0x40]
0000796da41d61dc  vmovaps xmm5, [rsp+0x50]
0000796da41d61e2  vmovaps xmm6, [rsp+0x60]
0000796da41d61e8  vmovaps xmm7, [rsp+0x70]
0000796da41d61ee  vmovaps xmm8, [rsp+0x80]
0000796da41d61f7  vmovaps xmm9, [rsp+0x90]
0000796da41d6200  vmovaps xmm10, [rsp+0xA0]
0000796da41d6209  vmovaps xmm11, [rsp+0xB0]
0000796da41d6212  vmovaps xmm12, [rsp+0xC0]
0000796da41d621b  vmovaps xmm13, [rsp+0xD0]
0000796da41d6224  vmovaps xmm14, [rsp+0xE0]
0000796da41d622d  add rsp, 0xF0
0000796da41d6234  pop r11
0000796da41d6236  pop r10
0000796da41d6238  pop r9
0000796da41d623a  pop r8
0000796da41d623c  pop rsi
0000796da41d623d  pop rdi
0000796da41d623e  pop rdx
0000796da41d623f  pop rcx
0000796da41d6240  pop rax
0000796da41d6241  add rsp, 0x08
0000796da41d6245  jmp 0x0000796DA41D307E
0000796da41d624a  sub rsp, 0x08
0000796da41d624e  push rax
0000796da41d624f  push rcx
0000796da41d6250  push rdx
0000796da41d6251  push rdi
0000796da41d6252  push rsi
0000796da41d6253  push r8
0000796da41d6255  push r9
0000796da41d6257  push r10
0000796da41d6259  push r11
0000796da41d625b  sub rsp, 0xF0
0000796da41d6262  vmovaps [rsp], xmm0
0000796da41d6267  vmovaps [rsp+0x10], xmm1
0000796da41d626d  vmovaps [rsp+0x20], xmm2
0000796da41d6273  vmovaps [rsp+0x30], xmm3
0000796da41d6279  vmovaps [rsp+0x40], xmm4
0000796da41d627f  vmovaps [rsp+0x50], xmm5
0000796da41d6285  vmovaps [rsp+0x60], xmm6
0000796da41d628b  vmovaps [rsp+0x70], xmm7
0000796da41d6291  vmovaps [rsp+0x80], xmm8
0000796da41d629a  vmovaps [rsp+0x90], xmm9
0000796da41d62a3  vmovaps [rsp+0xA0], xmm11
0000796da41d62ac  vmovaps [rsp+0xB0], xmm12
0000796da41d62b5  vmovaps [rsp+0xC0], xmm13
0000796da41d62be  vmovaps [rsp+0xD0], xmm14
0000796da41d62c7  vmovaps [rsp+0xE0], xmm15
0000796da41d62d0  sub rsp, 0x30
0000796da41d62d4  movaps [rsp], xmm10
0000796da41d62d9  movaps [rsp+0x10], xmm2
0000796da41d62de  movaps [rsp+0x20], xmm11
0000796da41d62e4  lea rdi, [rsp]
0000796da41d62e8  mov esi, 0x00
0000796da41d62ed  mov rax, 0x5E26CB66A530
0000796da41d62f7  call rax
0000796da41d62f9  movaps xmm10, [rsp]
0000796da41d62fe  add rsp, 0x30
0000796da41d6302  vmovaps xmm0, [rsp]
0000796da41d6307  vmovaps xmm1, [rsp+0x10]
0000796da41d630d  vmovaps xmm2, [rsp+0x20]
0000796da41d6313  vmovaps xmm3, [rsp+0x30]
0000796da41d6319  vmovaps xmm4, [rsp+0x40]
0000796da41d631f  vmovaps xmm5, [rsp+0x50]
0000796da41d6325  vmovaps xmm6, [rsp+0x60]
0000796da41d632b  vmovaps xmm7, [rsp+0x70]
0000796da41d6331  vmovaps xmm8, [rsp+0x80]
0000796da41d633a  vmovaps xmm9, [rsp+0x90]
0000796da41d6343  vmovaps xmm11, [rsp+0xA0]
0000796da41d634c  vmovaps xmm12, [rsp+0xB0]
0000796da41d6355  vmovaps xmm13, [rsp+0xC0]
0000796da41d635e  vmovaps xmm14, [rsp+0xD0]
0000796da41d6367  vmovaps xmm15, [rsp+0xE0]
0000796da41d6370  add rsp, 0xF0
0000796da41d6377  pop r11
0000796da41d6379  pop r10
0000796da41d637b  pop r9
0000796da41d637d  pop r8
0000796da41d637f  pop rsi
0000796da41d6380  pop rdi
0000796da41d6381  pop rdx
0000796da41d6382  pop rcx
0000796da41d6383  pop rax
0000796da41d6384  add rsp, 0x08
0000796da41d6388  jmp 0x0000796DA41D30B6
0000796da41d638d  sub rsp, 0x08
0000796da41d6391  push rax
0000796da41d6392  push rcx
0000796da41d6393  push rdx
0000796da41d6394  push rdi
0000796da41d6395  push rsi
0000796da41d6396  push r8
0000796da41d6398  push r9
0000796da41d639a  push r10
0000796da41d639c  push r11
0000796da41d639e  sub rsp, 0xF0
0000796da41d63a5  vmovaps [rsp], xmm0
0000796da41d63aa  vmovaps [rsp+0x10], xmm1
0000796da41d63b0  vmovaps [rsp+0x20], xmm2
0000796da41d63b6  vmovaps [rsp+0x30], xmm3
0000796da41d63bc  vmovaps [rsp+0x40], xmm4
0000796da41d63c2  vmovaps [rsp+0x50], xmm5
0000796da41d63c8  vmovaps [rsp+0x60], xmm6
0000796da41d63ce  vmovaps [rsp+0x70], xmm7
0000796da41d63d4  vmovaps [rsp+0x80], xmm8
0000796da41d63dd  vmovaps [rsp+0x90], xmm9
0000796da41d63e6  vmovaps [rsp+0xA0], xmm10
0000796da41d63ef  vmovaps [rsp+0xB0], xmm12
0000796da41d63f8  vmovaps [rsp+0xC0], xmm13
0000796da41d6401  vmovaps [rsp+0xD0], xmm14
0000796da41d640a  vmovaps [rsp+0xE0], xmm15
0000796da41d6413  sub rsp, 0x30
0000796da41d6417  movaps [rsp], xmm11
0000796da41d641c  movaps [rsp+0x10], xmm2
0000796da41d6421  movaps [rsp+0x20], xmm1
0000796da41d6426  lea rdi, [rsp]
0000796da41d642a  mov esi, 0x00
0000796da41d642f  mov rax, 0x5E26CB66A530
0000796da41d6439  call rax
0000796da41d643b  movaps xmm11, [rsp]
0000796da41d6440  add rsp, 0x30
0000796da41d6444  vmovaps xmm0, [rsp]
0000796da41d6449  vmovaps xmm1, [rsp+0x10]
0000796da41d644f  vmovaps xmm2, [rsp+0x20]
0000796da41d6455  vmovaps xmm3, [rsp+0x30]
0000796da41d645b  vmovaps xmm4, [rsp+0x40]
0000796da41d6461  vmovaps xmm5, [rsp+0x50]
0000796da41d6467  vmovaps xmm6, [rsp+0x60]
0000796da41d646d  vmovaps xmm7, [rsp+0x70]
0000796da41d6473  vmovaps xmm8, [rsp+0x80]
0000796da41d647c  vmovaps xmm9, [rsp+0x90]
0000796da41d6485  vmovaps xmm10, [rsp+0xA0]
0000796da41d648e  vmovaps xmm12, [rsp+0xB0]
0000796da41d6497  vmovaps xmm13, [rsp+0xC0]
0000796da41d64a0  vmovaps xmm14, [rsp+0xD0]
0000796da41d64a9  vmovaps xmm15, [rsp+0xE0]
0000796da41d64b2  add rsp, 0xF0
0000796da41d64b9  pop r11
0000796da41d64bb  pop r10
0000796da41d64bd  pop r9
0000796da41d64bf  pop r8
0000796da41d64c1  pop rsi
0000796da41d64c2  pop rdi
0000796da41d64c3  pop rdx
0000796da41d64c4  pop rcx
0000796da41d64c5  pop rax
0000796da41d64c6  add rsp, 0x08
0000796da41d64ca  jmp 0x0000796DA41D30F2
0000796da41d64cf  sub rsp, 0x08
0000796da41d64d3  push rax
0000796da41d64d4  push rcx
0000796da41d64d5  push rdx
0000796da41d64d6  push rdi
0000796da41d64d7  push rsi
0000796da41d64d8  push r8
0000796da41d64da  push r9
0000796da41d64dc  push r10
0000796da41d64de  push r11
0000796da41d64e0  sub rsp, 0xF0
0000796da41d64e7  vmovaps [rsp], xmm0
0000796da41d64ec  vmovaps [rsp+0x10], xmm2
0000796da41d64f2  vmovaps [rsp+0x20], xmm3
0000796da41d64f8  vmovaps [rsp+0x30], xmm4
0000796da41d64fe  vmovaps [rsp+0x40], xmm5
0000796da41d6504  vmovaps [rsp+0x50], xmm6
0000796da41d650a  vmovaps [rsp+0x60], xmm7
0000796da41d6510  vmovaps [rsp+0x70], xmm8
0000796da41d6516  vmovaps [rsp+0x80], xmm9
0000796da41d651f  vmovaps [rsp+0x90], xmm10
0000796da41d6528  vmovaps [rsp+0xA0], xmm11
0000796da41d6531  vmovaps [rsp+0xB0], xmm12
0000796da41d653a  vmovaps [rsp+0xC0], xmm13
0000796da41d6543  vmovaps [rsp+0xD0], xmm14
0000796da41d654c  vmovaps [rsp+0xE0], xmm15
0000796da41d6555  sub rsp, 0x30
0000796da41d6559  movaps [rsp], xmm1
0000796da41d655d  movaps [rsp+0x10], xmm14
0000796da41d6563  movaps [rsp+0x20], xmm6
0000796da41d6568  lea rdi, [rsp]
0000796da41d656c  mov esi, 0x00
0000796da41d6571  mov rax, 0x5E26CB66A530
0000796da41d657b  call rax
0000796da41d657d  movaps xmm1, [rsp]
0000796da41d6581  add rsp, 0x30
0000796da41d6585  vmovaps xmm0, [rsp]
0000796da41d658a  vmovaps xmm2, [rsp+0x10]
0000796da41d6590  vmovaps xmm3, [rsp+0x20]
0000796da41d6596  vmovaps xmm4, [rsp+0x30]
0000796da41d659c  vmovaps xmm5, [rsp+0x40]
0000796da41d65a2  vmovaps xmm6, [rsp+0x50]
0000796da41d65a8  vmovaps xmm7, [rsp+0x60]
0000796da41d65ae  vmovaps xmm8, [rsp+0x70]
0000796da41d65b4  vmovaps xmm9, [rsp+0x80]
0000796da41d65bd  vmovaps xmm10, [rsp+0x90]
0000796da41d65c6  vmovaps xmm11, [rsp+0xA0]
0000796da41d65cf  vmovaps xmm12, [rsp+0xB0]
0000796da41d65d8  vmovaps xmm13, [rsp+0xC0]
0000796da41d65e1  vmovaps xmm14, [rsp+0xD0]
0000796da41d65ea  vmovaps xmm15, [rsp+0xE0]
0000796da41d65f3  add rsp, 0xF0
0000796da41d65fa  pop r11
0000796da41d65fc  pop r10
0000796da41d65fe  pop r9
0000796da41d6600  pop r8
0000796da41d6602  pop rsi
0000796da41d6603  pop rdi
0000796da41d6604  pop rdx
0000796da41d6605  pop rcx
0000796da41d6606  pop rax
0000796da41d6607  add rsp, 0x08
0000796da41d660b  jmp 0x0000796DA41D310B
0000796da41d6610  sub rsp, 0x08
0000796da41d6614  push rax
0000796da41d6615  push rcx
0000796da41d6616  push rdx
0000796da41d6617  push rdi
0000796da41d6618  push rsi
0000796da41d6619  push r8
0000796da41d661b  push r9
0000796da41d661d  push r10
0000796da41d661f  push r11
0000796da41d6621  sub rsp, 0xF0
0000796da41d6628  vmovaps [rsp], xmm0
0000796da41d662d  vmovaps [rsp+0x10], xmm1
0000796da41d6633  vmovaps [rsp+0x20], xmm2
0000796da41d6639  vmovaps [rsp+0x30], xmm3
0000796da41d663f  vmovaps [rsp+0x40], xmm4
0000796da41d6645  vmovaps [rsp+0x50], xmm5
0000796da41d664b  vmovaps [rsp+0x60], xmm6
0000796da41d6651  vmovaps [rsp+0x70], xmm7
0000796da41d6657  vmovaps [rsp+0x80], xmm8
0000796da41d6660  vmovaps [rsp+0x90], xmm9
0000796da41d6669  vmovaps [rsp+0xA0], xmm10
0000796da41d6672  vmovaps [rsp+0xB0], xmm11
0000796da41d667b  vmovaps [rsp+0xC0], xmm12
0000796da41d6684  vmovaps [rsp+0xD0], xmm13
0000796da41d668d  vmovaps [rsp+0xE0], xmm14
0000796da41d6696  sub rsp, 0x30
0000796da41d669a  movaps [rsp], xmm15
0000796da41d669f  movaps [rsp+0x10], xmm14
0000796da41d66a5  movaps [rsp+0x20], xmm5
0000796da41d66aa  lea rdi, [rsp]
0000796da41d66ae  mov esi, 0x00
0000796da41d66b3  mov rax, 0x5E26CB66A530
0000796da41d66bd  call rax
0000796da41d66bf  movaps xmm15, [rsp]
0000796da41d66c4  add rsp, 0x30
0000796da41d66c8  vmovaps xmm0, [rsp]
0000796da41d66cd  vmovaps xmm1, [rsp+0x10]
0000796da41d66d3  vmovaps xmm2, [rsp+0x20]
0000796da41d66d9  vmovaps xmm3, [rsp+0x30]
0000796da41d66df  vmovaps xmm4, [rsp+0x40]
0000796da41d66e5  vmovaps xmm5, [rsp+0x50]
0000796da41d66eb  vmovaps xmm6, [rsp+0x60]
0000796da41d66f1  vmovaps xmm7, [rsp+0x70]
0000796da41d66f7  vmovaps xmm8, [rsp+0x80]
0000796da41d6700  vmovaps xmm9, [rsp+0x90]
0000796da41d6709  vmovaps xmm10, [rsp+0xA0]
0000796da41d6712  vmovaps xmm11, [rsp+0xB0]
0000796da41d671b  vmovaps xmm12, [rsp+0xC0]
0000796da41d6724  vmovaps xmm13, [rsp+0xD0]
0000796da41d672d  vmovaps xmm14, [rsp+0xE0]
0000796da41d6736  add rsp, 0xF0
0000796da41d673d  pop r11
0000796da41d673f  pop r10
0000796da41d6741  pop r9
0000796da41d6743  pop r8
0000796da41d6745  pop rsi
0000796da41d6746  pop rdi
0000796da41d6747  pop rdx
0000796da41d6748  pop rcx
0000796da41d6749  pop rax
0000796da41d674a  add rsp, 0x08
0000796da41d674e  jmp 0x0000796DA41D312B
0000796da41d6753  sub rsp, 0x08
0000796da41d6757  push rax
0000796da41d6758  push rcx
0000796da41d6759  push rdx
0000796da41d675a  push rdi
0000796da41d675b  push rsi
0000796da41d675c  push r8
0000796da41d675e  push r9
0000796da41d6760  push r10
0000796da41d6762  push r11
0000796da41d6764  sub rsp, 0xF0
0000796da41d676b  vmovaps [rsp], xmm0
0000796da41d6770  vmovaps [rsp+0x10], xmm1
0000796da41d6776  vmovaps [rsp+0x20], xmm2
0000796da41d677c  vmovaps [rsp+0x30], xmm3
0000796da41d6782  vmovaps [rsp+0x40], xmm4
0000796da41d6788  vmovaps [rsp+0x50], xmm5
0000796da41d678e  vmovaps [rsp+0x60], xmm7
0000796da41d6794  vmovaps [rsp+0x70], xmm8
0000796da41d679a  vmovaps [rsp+0x80], xmm9
0000796da41d67a3  vmovaps [rsp+0x90], xmm10
0000796da41d67ac  vmovaps [rsp+0xA0], xmm11
0000796da41d67b5  vmovaps [rsp+0xB0], xmm12
0000796da41d67be  vmovaps [rsp+0xC0], xmm13
0000796da41d67c7  vmovaps [rsp+0xD0], xmm14
0000796da41d67d0  vmovaps [rsp+0xE0], xmm15
0000796da41d67d9  sub rsp, 0x30
0000796da41d67dd  movaps [rsp], xmm6
0000796da41d67e1  movaps [rsp+0x10], xmm9
0000796da41d67e7  movaps [rsp+0x20], xmm14
0000796da41d67ed  lea rdi, [rsp]
0000796da41d67f1  mov esi, 0x00
0000796da41d67f6  mov rax, 0x5E26CB66A530
0000796da41d6800  call rax
0000796da41d6802  movaps xmm6, [rsp]
0000796da41d6806  add rsp, 0x30
0000796da41d680a  vmovaps xmm0, [rsp]
0000796da41d680f  vmovaps xmm1, [rsp+0x10]
0000796da41d6815  vmovaps xmm2, [rsp+0x20]
0000796da41d681b  vmovaps xmm3, [rsp+0x30]
0000796da41d6821  vmovaps xmm4, [rsp+0x40]
0000796da41d6827  vmovaps xmm5, [rsp+0x50]
0000796da41d682d  vmovaps xmm7, [rsp+0x60]
0000796da41d6833  vmovaps xmm8, [rsp+0x70]
0000796da41d6839  vmovaps xmm9, [rsp+0x80]
0000796da41d6842  vmovaps xmm10, [rsp+0x90]
0000796da41d684b  vmovaps xmm11, [rsp+0xA0]
0000796da41d6854  vmovaps xmm12, [rsp+0xB0]
0000796da41d685d  vmovaps xmm13, [rsp+0xC0]
0000796da41d6866  vmovaps xmm14, [rsp+0xD0]
0000796da41d686f  vmovaps xmm15, [rsp+0xE0]
0000796da41d6878  add rsp, 0xF0
0000796da41d687f  pop r11
0000796da41d6881  pop r10
0000796da41d6883  pop r9
0000796da41d6885  pop r8
0000796da41d6887  pop rsi
0000796da41d6888  pop rdi
0000796da41d6889  pop rdx
0000796da41d688a  pop rcx
0000796da41d688b  pop rax
0000796da41d688c  add rsp, 0x08
0000796da41d6890  jmp 0x0000796DA41D3153
0000796da41d6895  sub rsp, 0x08
0000796da41d6899  push rax
0000796da41d689a  push rcx
0000796da41d689b  push rdx
0000796da41d689c  push rdi
0000796da41d689d  push rsi
0000796da41d689e  push r8
0000796da41d68a0  push r9
0000796da41d68a2  push r10
0000796da41d68a4  push r11
0000796da41d68a6  sub rsp, 0xF0
0000796da41d68ad  vmovaps [rsp], xmm0
0000796da41d68b2  vmovaps [rsp+0x10], xmm1
0000796da41d68b8  vmovaps [rsp+0x20], xmm2
0000796da41d68be  vmovaps [rsp+0x30], xmm3
0000796da41d68c4  vmovaps [rsp+0x40], xmm4
0000796da41d68ca  vmovaps [rsp+0x50], xmm5
0000796da41d68d0  vmovaps [rsp+0x60], xmm6
0000796da41d68d6  vmovaps [rsp+0x70], xmm7
0000796da41d68dc  vmovaps [rsp+0x80], xmm8
0000796da41d68e5  vmovaps [rsp+0x90], xmm9
0000796da41d68ee  vmovaps [rsp+0xA0], xmm10
0000796da41d68f7  vmovaps [rsp+0xB0], xmm11
0000796da41d6900  vmovaps [rsp+0xC0], xmm12
0000796da41d6909  vmovaps [rsp+0xD0], xmm13
0000796da41d6912  vmovaps [rsp+0xE0], xmm15
0000796da41d691b  sub rsp, 0x30
0000796da41d691f  movaps [rsp], xmm14
0000796da41d6924  movaps [rsp+0x10], xmm9
0000796da41d692a  movaps [rsp+0x20], xmm13
0000796da41d6930  lea rdi, [rsp]
0000796da41d6934  mov esi, 0x00
0000796da41d6939  mov rax, 0x5E26CB66A530
0000796da41d6943  call rax
0000796da41d6945  movaps xmm14, [rsp]
0000796da41d694a  add rsp, 0x30
0000796da41d694e  vmovaps xmm0, [rsp]
0000796da41d6953  vmovaps xmm1, [rsp+0x10]
0000796da41d6959  vmovaps xmm2, [rsp+0x20]
0000796da41d695f  vmovaps xmm3, [rsp+0x30]
0000796da41d6965  vmovaps xmm4, [rsp+0x40]
0000796da41d696b  vmovaps xmm5, [rsp+0x50]
0000796da41d6971  vmovaps xmm6, [rsp+0x60]
0000796da41d6977  vmovaps xmm7, [rsp+0x70]
0000796da41d697d  vmovaps xmm8, [rsp+0x80]
0000796da41d6986  vmovaps xmm9, [rsp+0x90]
0000796da41d698f  vmovaps xmm10, [rsp+0xA0]
0000796da41d6998  vmovaps xmm11, [rsp+0xB0]
0000796da41d69a1  vmovaps xmm12, [rsp+0xC0]
0000796da41d69aa  vmovaps xmm13, [rsp+0xD0]
0000796da41d69b3  vmovaps xmm15, [rsp+0xE0]
0000796da41d69bc  add rsp, 0xF0
0000796da41d69c3  pop r11
0000796da41d69c5  pop r10
0000796da41d69c7  pop r9
0000796da41d69c9  pop r8
0000796da41d69cb  pop rsi
0000796da41d69cc  pop rdi
0000796da41d69cd  pop rdx
0000796da41d69ce  pop rcx
0000796da41d69cf  pop rax
0000796da41d69d0  add rsp, 0x08
0000796da41d69d4  jmp 0x0000796DA41D3176
0000796da41d69d9  sub rsp, 0x08
0000796da41d69dd  push rax
0000796da41d69de  push rcx
0000796da41d69df  push rdx
0000796da41d69e0  push rdi
0000796da41d69e1  push rsi
0000796da41d69e2  push r8
0000796da41d69e4  push r9
0000796da41d69e6  push r10
0000796da41d69e8  push r11
0000796da41d69ea  sub rsp, 0xF0
0000796da41d69f1  vmovaps [rsp], xmm0
0000796da41d69f6  vmovaps [rsp+0x10], xmm1
0000796da41d69fc  vmovaps [rsp+0x20], xmm2
0000796da41d6a02  vmovaps [rsp+0x30], xmm3
0000796da41d6a08  vmovaps [rsp+0x40], xmm4
0000796da41d6a0e  vmovaps [rsp+0x50], xmm5
0000796da41d6a14  vmovaps [rsp+0x60], xmm6
0000796da41d6a1a  vmovaps [rsp+0x70], xmm7
0000796da41d6a20  vmovaps [rsp+0x80], xmm8
0000796da41d6a29  vmovaps [rsp+0x90], xmm9
0000796da41d6a32  vmovaps [rsp+0xA0], xmm10
0000796da41d6a3b  vmovaps [rsp+0xB0], xmm11
0000796da41d6a44  vmovaps [rsp+0xC0], xmm12
0000796da41d6a4d  vmovaps [rsp+0xD0], xmm14
0000796da41d6a56  vmovaps [rsp+0xE0], xmm15
0000796da41d6a5f  sub rsp, 0x30
0000796da41d6a63  movaps [rsp], xmm13
0000796da41d6a68  movaps [rsp+0x10], xmm9
0000796da41d6a6e  movaps [rsp+0x20], xmm10
0000796da41d6a74  lea rdi, [rsp]
0000796da41d6a78  mov esi, 0x00
0000796da41d6a7d  mov rax, 0x5E26CB66A530
0000796da41d6a87  call rax
0000796da41d6a89  movaps xmm13, [rsp]
0000796da41d6a8e  add rsp, 0x30
0000796da41d6a92  vmovaps xmm0, [rsp]
0000796da41d6a97  vmovaps xmm1, [rsp+0x10]
0000796da41d6a9d  vmovaps xmm2, [rsp+0x20]
0000796da41d6aa3  vmovaps xmm3, [rsp+0x30]
0000796da41d6aa9  vmovaps xmm4, [rsp+0x40]
0000796da41d6aaf  vmovaps xmm5, [rsp+0x50]
0000796da41d6ab5  vmovaps xmm6, [rsp+0x60]
0000796da41d6abb  vmovaps xmm7, [rsp+0x70]
0000796da41d6ac1  vmovaps xmm8, [rsp+0x80]
0000796da41d6aca  vmovaps xmm9, [rsp+0x90]
0000796da41d6ad3  vmovaps xmm10, [rsp+0xA0]
0000796da41d6adc  vmovaps xmm11, [rsp+0xB0]
0000796da41d6ae5  vmovaps xmm12, [rsp+0xC0]
0000796da41d6aee  vmovaps xmm14, [rsp+0xD0]
0000796da41d6af7  vmovaps xmm15, [rsp+0xE0]
0000796da41d6b00  add rsp, 0xF0
0000796da41d6b07  pop r11
0000796da41d6b09  pop r10
0000796da41d6b0b  pop r9
0000796da41d6b0d  pop r8
0000796da41d6b0f  pop rsi
0000796da41d6b10  pop rdi
0000796da41d6b11  pop rdx
0000796da41d6b12  pop rcx
0000796da41d6b13  pop rax
0000796da41d6b14  add rsp, 0x08
0000796da41d6b18  jmp 0x0000796DA41D3196
0000796da41d6b1d  call 0x0000796DA400AFE0
0000796da41d6b22  jmp 0x0000796DA41D31EB
0000796da41d6b27  sub rsp, 0x08
0000796da41d6b2b  push rax
0000796da41d6b2c  push rcx
0000796da41d6b2d  push rdx
0000796da41d6b2e  push rdi
0000796da41d6b2f  push rsi
0000796da41d6b30  push r8
0000796da41d6b32  push r9
0000796da41d6b34  push r10
0000796da41d6b36  push r11
0000796da41d6b38  sub rsp, 0xF0
0000796da41d6b3f  vmovaps [rsp], xmm0
0000796da41d6b44  vmovaps [rsp+0x10], xmm1
0000796da41d6b4a  vmovaps [rsp+0x20], xmm2
0000796da41d6b50  vmovaps [rsp+0x30], xmm3
0000796da41d6b56  vmovaps [rsp+0x40], xmm4
0000796da41d6b5c  vmovaps [rsp+0x50], xmm5
0000796da41d6b62  vmovaps [rsp+0x60], xmm6
0000796da41d6b68  vmovaps [rsp+0x70], xmm7
0000796da41d6b6e  vmovaps [rsp+0x80], xmm8
0000796da41d6b77  vmovaps [rsp+0x90], xmm10
0000796da41d6b80  vmovaps [rsp+0xA0], xmm11
0000796da41d6b89  vmovaps [rsp+0xB0], xmm12
0000796da41d6b92  vmovaps [rsp+0xC0], xmm13
0000796da41d6b9b  vmovaps [rsp+0xD0], xmm14
0000796da41d6ba4  vmovaps [rsp+0xE0], xmm15
0000796da41d6bad  sub rsp, 0x30
0000796da41d6bb1  movaps [rsp], xmm9
0000796da41d6bb6  movaps [rsp+0x10], xmm8
0000796da41d6bbc  movaps [rsp+0x20], xmm10
0000796da41d6bc2  lea rdi, [rsp]
0000796da41d6bc6  mov esi, 0x00
0000796da41d6bcb  mov rax, 0x5E26CB66A530
0000796da41d6bd5  call rax
0000796da41d6bd7  movaps xmm9, [rsp]
0000796da41d6bdc  add rsp, 0x30
0000796da41d6be0  vmovaps xmm0, [rsp]
0000796da41d6be5  vmovaps xmm1, [rsp+0x10]
0000796da41d6beb  vmovaps xmm2, [rsp+0x20]
0000796da41d6bf1  vmovaps xmm3, [rsp+0x30]
0000796da41d6bf7  vmovaps xmm4, [rsp+0x40]
0000796da41d6bfd  vmovaps xmm5, [rsp+0x50]
0000796da41d6c03  vmovaps xmm6, [rsp+0x60]
0000796da41d6c09  vmovaps xmm7, [rsp+0x70]
0000796da41d6c0f  vmovaps xmm8, [rsp+0x80]
0000796da41d6c18  vmovaps xmm10, [rsp+0x90]
0000796da41d6c21  vmovaps xmm11, [rsp+0xA0]
0000796da41d6c2a  vmovaps xmm12, [rsp+0xB0]
0000796da41d6c33  vmovaps xmm13, [rsp+0xC0]
0000796da41d6c3c  vmovaps xmm14, [rsp+0xD0]
0000796da41d6c45  vmovaps xmm15, [rsp+0xE0]
0000796da41d6c4e  add rsp, 0xF0
0000796da41d6c55  pop r11
0000796da41d6c57  pop r10
0000796da41d6c59  pop r9
0000796da41d6c5b  pop r8
0000796da41d6c5d  pop rsi
0000796da41d6c5e  pop rdi
0000796da41d6c5f  pop rdx
0000796da41d6c60  pop rcx
0000796da41d6c61  pop rax
0000796da41d6c62  add rsp, 0x08
0000796da41d6c66  jmp 0x0000796DA41D321C
0000796da41d6c6b  sub rsp, 0x08
0000796da41d6c6f  push rax
0000796da41d6c70  push rcx
0000796da41d6c71  push rdx
0000796da41d6c72  push rdi
0000796da41d6c73  push rsi
0000796da41d6c74  push r8
0000796da41d6c76  push r9
0000796da41d6c78  push r10
0000796da41d6c7a  push r11
0000796da41d6c7c  sub rsp, 0xF0
0000796da41d6c83  vmovaps [rsp], xmm0
0000796da41d6c88  vmovaps [rsp+0x10], xmm1
0000796da41d6c8e  vmovaps [rsp+0x20], xmm2
0000796da41d6c94  vmovaps [rsp+0x30], xmm3
0000796da41d6c9a  vmovaps [rsp+0x40], xmm4
0000796da41d6ca0  vmovaps [rsp+0x50], xmm5
0000796da41d6ca6  vmovaps [rsp+0x60], xmm6
0000796da41d6cac  vmovaps [rsp+0x70], xmm7
0000796da41d6cb2  vmovaps [rsp+0x80], xmm8
0000796da41d6cbb  vmovaps [rsp+0x90], xmm9
0000796da41d6cc4  vmovaps [rsp+0xA0], xmm11
0000796da41d6ccd  vmovaps [rsp+0xB0], xmm12
0000796da41d6cd6  vmovaps [rsp+0xC0], xmm13
0000796da41d6cdf  vmovaps [rsp+0xD0], xmm14
0000796da41d6ce8  vmovaps [rsp+0xE0], xmm15
0000796da41d6cf1  sub rsp, 0x30
0000796da41d6cf5  movaps [rsp], xmm10
0000796da41d6cfa  movaps [rsp+0x10], xmm1
0000796da41d6cff  movaps [rsp+0x20], xmm11
0000796da41d6d05  lea rdi, [rsp]
0000796da41d6d09  mov esi, 0x00
0000796da41d6d0e  mov rax, 0x5E26CB66A530
0000796da41d6d18  call rax
0000796da41d6d1a  movaps xmm10, [rsp]
0000796da41d6d1f  add rsp, 0x30
0000796da41d6d23  vmovaps xmm0, [rsp]
0000796da41d6d28  vmovaps xmm1, [rsp+0x10]
0000796da41d6d2e  vmovaps xmm2, [rsp+0x20]
0000796da41d6d34  vmovaps xmm3, [rsp+0x30]
0000796da41d6d3a  vmovaps xmm4, [rsp+0x40]
0000796da41d6d40  vmovaps xmm5, [rsp+0x50]
0000796da41d6d46  vmovaps xmm6, [rsp+0x60]
0000796da41d6d4c  vmovaps xmm7, [rsp+0x70]
0000796da41d6d52  vmovaps xmm8, [rsp+0x80]
0000796da41d6d5b  vmovaps xmm9, [rsp+0x90]
0000796da41d6d64  vmovaps xmm11, [rsp+0xA0]
0000796da41d6d6d  vmovaps xmm12, [rsp+0xB0]
0000796da41d6d76  vmovaps xmm13, [rsp+0xC0]
0000796da41d6d7f  vmovaps xmm14, [rsp+0xD0]
0000796da41d6d88  vmovaps xmm15, [rsp+0xE0]
0000796da41d6d91  add rsp, 0xF0
0000796da41d6d98  pop r11
0000796da41d6d9a  pop r10
0000796da41d6d9c  pop r9
0000796da41d6d9e  pop r8
0000796da41d6da0  pop rsi
0000796da41d6da1  pop rdi
0000796da41d6da2  pop rdx
0000796da41d6da3  pop rcx
0000796da41d6da4  pop rax
0000796da41d6da5  add rsp, 0x08
0000796da41d6da9  jmp 0x0000796DA41D3237
0000796da41d6dae  sub rsp, 0x08
0000796da41d6db2  push rax
0000796da41d6db3  push rcx
0000796da41d6db4  push rdx
0000796da41d6db5  push rdi
0000796da41d6db6  push rsi
0000796da41d6db7  push r8
0000796da41d6db9  push r9
0000796da41d6dbb  push r10
0000796da41d6dbd  push r11
0000796da41d6dbf  sub rsp, 0xF0
0000796da41d6dc6  vmovaps [rsp], xmm0
0000796da41d6dcb  vmovaps [rsp+0x10], xmm2
0000796da41d6dd1  vmovaps [rsp+0x20], xmm3
0000796da41d6dd7  vmovaps [rsp+0x30], xmm4
0000796da41d6ddd  vmovaps [rsp+0x40], xmm5
0000796da41d6de3  vmovaps [rsp+0x50], xmm6
0000796da41d6de9  vmovaps [rsp+0x60], xmm7
0000796da41d6def  vmovaps [rsp+0x70], xmm8
0000796da41d6df5  vmovaps [rsp+0x80], xmm9
0000796da41d6dfe  vmovaps [rsp+0x90], xmm10
0000796da41d6e07  vmovaps [rsp+0xA0], xmm11
0000796da41d6e10  vmovaps [rsp+0xB0], xmm12
0000796da41d6e19  vmovaps [rsp+0xC0], xmm13
0000796da41d6e22  vmovaps [rsp+0xD0], xmm14
0000796da41d6e2b  vmovaps [rsp+0xE0], xmm15
0000796da41d6e34  sub rsp, 0x30
0000796da41d6e38  movaps [rsp], xmm1
0000796da41d6e3c  movaps [rsp+0x10], xmm15
0000796da41d6e42  movaps [rsp+0x20], xmm6
0000796da41d6e47  lea rdi, [rsp]
0000796da41d6e4b  mov esi, 0x00
0000796da41d6e50  mov rax, 0x5E26CB66A530
0000796da41d6e5a  call rax
0000796da41d6e5c  movaps xmm1, [rsp]
0000796da41d6e60  add rsp, 0x30
0000796da41d6e64  vmovaps xmm0, [rsp]
0000796da41d6e69  vmovaps xmm2, [rsp+0x10]
0000796da41d6e6f  vmovaps xmm3, [rsp+0x20]
0000796da41d6e75  vmovaps xmm4, [rsp+0x30]
0000796da41d6e7b  vmovaps xmm5, [rsp+0x40]
0000796da41d6e81  vmovaps xmm6, [rsp+0x50]
0000796da41d6e87  vmovaps xmm7, [rsp+0x60]
0000796da41d6e8d  vmovaps xmm8, [rsp+0x70]
0000796da41d6e93  vmovaps xmm9, [rsp+0x80]
0000796da41d6e9c  vmovaps xmm10, [rsp+0x90]
0000796da41d6ea5  vmovaps xmm11, [rsp+0xA0]
0000796da41d6eae  vmovaps xmm12, [rsp+0xB0]
0000796da41d6eb7  vmovaps xmm13, [rsp+0xC0]
0000796da41d6ec0  vmovaps xmm14, [rsp+0xD0]
0000796da41d6ec9  vmovaps xmm15, [rsp+0xE0]
0000796da41d6ed2  add rsp, 0xF0
0000796da41d6ed9  pop r11
0000796da41d6edb  pop r10
0000796da41d6edd  pop r9
0000796da41d6edf  pop r8
0000796da41d6ee1  pop rsi
0000796da41d6ee2  pop rdi
0000796da41d6ee3  pop rdx
0000796da41d6ee4  pop rcx
0000796da41d6ee5  pop rax
0000796da41d6ee6  add rsp, 0x08
0000796da41d6eea  jmp 0x0000796DA41D3250
0000796da41d6eef  sub rsp, 0x08
0000796da41d6ef3  push rax
0000796da41d6ef4  push rcx
0000796da41d6ef5  push rdx
0000796da41d6ef6  push rdi
0000796da41d6ef7  push rsi
0000796da41d6ef8  push r8
0000796da41d6efa  push r9
0000796da41d6efc  push r10
0000796da41d6efe  push r11
0000796da41d6f00  sub rsp, 0xF0
0000796da41d6f07  vmovaps [rsp], xmm0
0000796da41d6f0c  vmovaps [rsp+0x10], xmm1
0000796da41d6f12  vmovaps [rsp+0x20], xmm2
0000796da41d6f18  vmovaps [rsp+0x30], xmm3
0000796da41d6f1e  vmovaps [rsp+0x40], xmm4
0000796da41d6f24  vmovaps [rsp+0x50], xmm5
0000796da41d6f2a  vmovaps [rsp+0x60], xmm6
0000796da41d6f30  vmovaps [rsp+0x70], xmm7
0000796da41d6f36  vmovaps [rsp+0x80], xmm8
0000796da41d6f3f  vmovaps [rsp+0x90], xmm9
0000796da41d6f48  vmovaps [rsp+0xA0], xmm10
0000796da41d6f51  vmovaps [rsp+0xB0], xmm12
0000796da41d6f5a  vmovaps [rsp+0xC0], xmm13
0000796da41d6f63  vmovaps [rsp+0xD0], xmm14
0000796da41d6f6c  vmovaps [rsp+0xE0], xmm15
0000796da41d6f75  sub rsp, 0x30
0000796da41d6f79  movaps [rsp], xmm11
0000796da41d6f7e  movaps [rsp+0x10], xmm12
0000796da41d6f84  movaps [rsp+0x20], xmm15
0000796da41d6f8a  lea rdi, [rsp]
0000796da41d6f8e  mov esi, 0x00
0000796da41d6f93  mov rax, 0x5E26CB66A530
0000796da41d6f9d  call rax
0000796da41d6f9f  movaps xmm11, [rsp]
0000796da41d6fa4  add rsp, 0x30
0000796da41d6fa8  vmovaps xmm0, [rsp]
0000796da41d6fad  vmovaps xmm1, [rsp+0x10]
0000796da41d6fb3  vmovaps xmm2, [rsp+0x20]
0000796da41d6fb9  vmovaps xmm3, [rsp+0x30]
0000796da41d6fbf  vmovaps xmm4, [rsp+0x40]
0000796da41d6fc5  vmovaps xmm5, [rsp+0x50]
0000796da41d6fcb  vmovaps xmm6, [rsp+0x60]
0000796da41d6fd1  vmovaps xmm7, [rsp+0x70]
0000796da41d6fd7  vmovaps xmm8, [rsp+0x80]
0000796da41d6fe0  vmovaps xmm9, [rsp+0x90]
0000796da41d6fe9  vmovaps xmm10, [rsp+0xA0]
0000796da41d6ff2  vmovaps xmm12, [rsp+0xB0]
0000796da41d6ffb  vmovaps xmm13, [rsp+0xC0]
0000796da41d7004  vmovaps xmm14, [rsp+0xD0]
0000796da41d700d  vmovaps xmm15, [rsp+0xE0]
0000796da41d7016  add rsp, 0xF0
0000796da41d701d  pop r11
0000796da41d701f  pop r10
0000796da41d7021  pop r9
0000796da41d7023  pop r8
0000796da41d7025  pop rsi
0000796da41d7026  pop rdi
0000796da41d7027  pop rdx
0000796da41d7028  pop rcx
0000796da41d7029  pop rax
0000796da41d702a  add rsp, 0x08
0000796da41d702e  jmp 0x0000796DA41D327A
0000796da41d7033  sub rsp, 0x08
0000796da41d7037  push rax
0000796da41d7038  push rcx
0000796da41d7039  push rdx
0000796da41d703a  push rdi
0000796da41d703b  push rsi
0000796da41d703c  push r8
0000796da41d703e  push r9
0000796da41d7040  push r10
0000796da41d7042  push r11
0000796da41d7044  sub rsp, 0xF0
0000796da41d704b  vmovaps [rsp], xmm0
0000796da41d7050  vmovaps [rsp+0x10], xmm1
0000796da41d7056  vmovaps [rsp+0x20], xmm2
0000796da41d705c  vmovaps [rsp+0x30], xmm3
0000796da41d7062  vmovaps [rsp+0x40], xmm4
0000796da41d7068  vmovaps [rsp+0x50], xmm5
0000796da41d706e  vmovaps [rsp+0x60], xmm6
0000796da41d7074  vmovaps [rsp+0x70], xmm7
0000796da41d707a  vmovaps [rsp+0x80], xmm8
0000796da41d7083  vmovaps [rsp+0x90], xmm9
0000796da41d708c  vmovaps [rsp+0xA0], xmm10
0000796da41d7095  vmovaps [rsp+0xB0], xmm11
0000796da41d709e  vmovaps [rsp+0xC0], xmm13
0000796da41d70a7  vmovaps [rsp+0xD0], xmm14
0000796da41d70b0  vmovaps [rsp+0xE0], xmm15
0000796da41d70b9  sub rsp, 0x30
0000796da41d70bd  movaps [rsp], xmm12
0000796da41d70c2  movaps [rsp+0x10], xmm8
0000796da41d70c8  movaps [rsp+0x20], xmm15
0000796da41d70ce  lea rdi, [rsp]
0000796da41d70d2  mov esi, 0x00
0000796da41d70d7  mov rax, 0x5E26CB66A530
0000796da41d70e1  call rax
0000796da41d70e3  movaps xmm12, [rsp]
0000796da41d70e8  add rsp, 0x30
0000796da41d70ec  vmovaps xmm0, [rsp]
0000796da41d70f1  vmovaps xmm1, [rsp+0x10]
0000796da41d70f7  vmovaps xmm2, [rsp+0x20]
0000796da41d70fd  vmovaps xmm3, [rsp+0x30]
0000796da41d7103  vmovaps xmm4, [rsp+0x40]
0000796da41d7109  vmovaps xmm5, [rsp+0x50]
0000796da41d710f  vmovaps xmm6, [rsp+0x60]
0000796da41d7115  vmovaps xmm7, [rsp+0x70]
0000796da41d711b  vmovaps xmm8, [rsp+0x80]
0000796da41d7124  vmovaps xmm9, [rsp+0x90]
0000796da41d712d  vmovaps xmm10, [rsp+0xA0]
0000796da41d7136  vmovaps xmm11, [rsp+0xB0]
0000796da41d713f  vmovaps xmm13, [rsp+0xC0]
0000796da41d7148  vmovaps xmm14, [rsp+0xD0]
0000796da41d7151  vmovaps xmm15, [rsp+0xE0]
0000796da41d715a  add rsp, 0xF0
0000796da41d7161  pop r11
0000796da41d7163  pop r10
0000796da41d7165  pop r9
0000796da41d7167  pop r8
0000796da41d7169  pop rsi
0000796da41d716a  pop rdi
0000796da41d716b  pop rdx
0000796da41d716c  pop rcx
0000796da41d716d  pop rax
0000796da41d716e  add rsp, 0x08
0000796da41d7172  jmp 0x0000796DA41D32A9
0000796da41d7177  sub rsp, 0x08
0000796da41d717b  push rax
0000796da41d717c  push rcx
0000796da41d717d  push rdx
0000796da41d717e  push rdi
0000796da41d717f  push rsi
0000796da41d7180  push r8
0000796da41d7182  push r9
0000796da41d7184  push r10
0000796da41d7186  push r11
0000796da41d7188  sub rsp, 0xF0
0000796da41d718f  vmovaps [rsp], xmm0
0000796da41d7194  vmovaps [rsp+0x10], xmm1
0000796da41d719a  vmovaps [rsp+0x20], xmm2
0000796da41d71a0  vmovaps [rsp+0x30], xmm3
0000796da41d71a6  vmovaps [rsp+0x40], xmm4
0000796da41d71ac  vmovaps [rsp+0x50], xmm5
0000796da41d71b2  vmovaps [rsp+0x60], xmm6
0000796da41d71b8  vmovaps [rsp+0x70], xmm7
0000796da41d71be  vmovaps [rsp+0x80], xmm9
0000796da41d71c7  vmovaps [rsp+0x90], xmm10
0000796da41d71d0  vmovaps [rsp+0xA0], xmm11
0000796da41d71d9  vmovaps [rsp+0xB0], xmm12
0000796da41d71e2  vmovaps [rsp+0xC0], xmm13
0000796da41d71eb  vmovaps [rsp+0xD0], xmm14
0000796da41d71f4  vmovaps [rsp+0xE0], xmm15
0000796da41d71fd  sub rsp, 0x30
0000796da41d7201  movaps [rsp], xmm8
0000796da41d7206  movaps [rsp+0x10], xmm7
0000796da41d720b  movaps [rsp+0x20], xmm15
0000796da41d7211  lea rdi, [rsp]
0000796da41d7215  mov esi, 0x00
0000796da41d721a  mov rax, 0x5E26CB66A530
0000796da41d7224  call rax
0000796da41d7226  movaps xmm8, [rsp]
0000796da41d722b  add rsp, 0x30
0000796da41d722f  vmovaps xmm0, [rsp]
0000796da41d7234  vmovaps xmm1, [rsp+0x10]
0000796da41d723a  vmovaps xmm2, [rsp+0x20]
0000796da41d7240  vmovaps xmm3, [rsp+0x30]
0000796da41d7246  vmovaps xmm4, [rsp+0x40]
0000796da41d724c  vmovaps xmm5, [rsp+0x50]
0000796da41d7252  vmovaps xmm6, [rsp+0x60]
0000796da41d7258  vmovaps xmm7, [rsp+0x70]
0000796da41d725e  vmovaps xmm9, [rsp+0x80]
0000796da41d7267  vmovaps xmm10, [rsp+0x90]
0000796da41d7270  vmovaps xmm11, [rsp+0xA0]
0000796da41d7279  vmovaps xmm12, [rsp+0xB0]
0000796da41d7282  vmovaps xmm13, [rsp+0xC0]
0000796da41d728b  vmovaps xmm14, [rsp+0xD0]
0000796da41d7294  vmovaps xmm15, [rsp+0xE0]
0000796da41d729d  add rsp, 0xF0
0000796da41d72a4  pop r11
0000796da41d72a6  pop r10
0000796da41d72a8  pop r9
0000796da41d72aa  pop r8
0000796da41d72ac  pop rsi
0000796da41d72ad  pop rdi
0000796da41d72ae  pop rdx
0000796da41d72af  pop rcx
0000796da41d72b0  pop rax
0000796da41d72b1  add rsp, 0x08
0000796da41d72b5  jmp 0x0000796DA41D32CF
0000796da41d72ba  sub rsp, 0x08
0000796da41d72be  push rax
0000796da41d72bf  push rcx
0000796da41d72c0  push rdx
0000796da41d72c1  push rdi
0000796da41d72c2  push rsi
0000796da41d72c3  push r8
0000796da41d72c5  push r9
0000796da41d72c7  push r10
0000796da41d72c9  push r11
0000796da41d72cb  sub rsp, 0xF0
0000796da41d72d2  vmovaps [rsp], xmm0
0000796da41d72d7  vmovaps [rsp+0x10], xmm1
0000796da41d72dd  vmovaps [rsp+0x20], xmm2
0000796da41d72e3  vmovaps [rsp+0x30], xmm3
0000796da41d72e9  vmovaps [rsp+0x40], xmm4
0000796da41d72ef  vmovaps [rsp+0x50], xmm5
0000796da41d72f5  vmovaps [rsp+0x60], xmm6
0000796da41d72fb  vmovaps [rsp+0x70], xmm7
0000796da41d7301  vmovaps [rsp+0x80], xmm8
0000796da41d730a  vmovaps [rsp+0x90], xmm9
0000796da41d7313  vmovaps [rsp+0xA0], xmm10
0000796da41d731c  vmovaps [rsp+0xB0], xmm11
0000796da41d7325  vmovaps [rsp+0xC0], xmm12
0000796da41d732e  vmovaps [rsp+0xD0], xmm13
0000796da41d7337  vmovaps [rsp+0xE0], xmm14
0000796da41d7340  sub rsp, 0x30
0000796da41d7344  movaps [rsp], xmm15
0000796da41d7349  movaps [rsp+0x10], xmm14
0000796da41d734f  movaps [rsp+0x20], xmm9
0000796da41d7355  lea rdi, [rsp]
0000796da41d7359  mov esi, 0x00
0000796da41d735e  mov rax, 0x5E26CB66A530
0000796da41d7368  call rax
0000796da41d736a  movaps xmm15, [rsp]
0000796da41d736f  add rsp, 0x30
0000796da41d7373  vmovaps xmm0, [rsp]
0000796da41d7378  vmovaps xmm1, [rsp+0x10]
0000796da41d737e  vmovaps xmm2, [rsp+0x20]
0000796da41d7384  vmovaps xmm3, [rsp+0x30]
0000796da41d738a  vmovaps xmm4, [rsp+0x40]
0000796da41d7390  vmovaps xmm5, [rsp+0x50]
0000796da41d7396  vmovaps xmm6, [rsp+0x60]
0000796da41d739c  vmovaps xmm7, [rsp+0x70]
0000796da41d73a2  vmovaps xmm8, [rsp+0x80]
0000796da41d73ab  vmovaps xmm9, [rsp+0x90]
0000796da41d73b4  vmovaps xmm10, [rsp+0xA0]
0000796da41d73bd  vmovaps xmm11, [rsp+0xB0]
0000796da41d73c6  vmovaps xmm12, [rsp+0xC0]
0000796da41d73cf  vmovaps xmm13, [rsp+0xD0]
0000796da41d73d8  vmovaps xmm14, [rsp+0xE0]
0000796da41d73e1  add rsp, 0xF0
0000796da41d73e8  pop r11
0000796da41d73ea  pop r10
0000796da41d73ec  pop r9
0000796da41d73ee  pop r8
0000796da41d73f0  pop rsi
0000796da41d73f1  pop rdi
0000796da41d73f2  pop rdx
0000796da41d73f3  pop rcx
0000796da41d73f4  pop rax
0000796da41d73f5  add rsp, 0x08
0000796da41d73f9  jmp 0x0000796DA41D32E9
0000796da41d73fe  sub rsp, 0x08
0000796da41d7402  push rax
0000796da41d7403  push rcx
0000796da41d7404  push rdx
0000796da41d7405  push rdi
0000796da41d7406  push rsi
0000796da41d7407  push r8
0000796da41d7409  push r9
0000796da41d740b  push r10
0000796da41d740d  push r11
0000796da41d740f  sub rsp, 0xF0
0000796da41d7416  vmovaps [rsp], xmm0
0000796da41d741b  vmovaps [rsp+0x10], xmm1
0000796da41d7421  vmovaps [rsp+0x20], xmm2
0000796da41d7427  vmovaps [rsp+0x30], xmm3
0000796da41d742d  vmovaps [rsp+0x40], xmm4
0000796da41d7433  vmovaps [rsp+0x50], xmm5
0000796da41d7439  vmovaps [rsp+0x60], xmm6
0000796da41d743f  vmovaps [rsp+0x70], xmm7
0000796da41d7445  vmovaps [rsp+0x80], xmm8
0000796da41d744e  vmovaps [rsp+0x90], xmm10
0000796da41d7457  vmovaps [rsp+0xA0], xmm11
0000796da41d7460  vmovaps [rsp+0xB0], xmm12
0000796da41d7469  vmovaps [rsp+0xC0], xmm13
0000796da41d7472  vmovaps [rsp+0xD0], xmm14
0000796da41d747b  vmovaps [rsp+0xE0], xmm15
0000796da41d7484  sub rsp, 0x30
0000796da41d7488  movaps [rsp], xmm9
0000796da41d748d  movaps [rsp+0x10], xmm7
0000796da41d7492  movaps [rsp+0x20], xmm14
0000796da41d7498  lea rdi, [rsp]
0000796da41d749c  mov esi, 0x00
0000796da41d74a1  mov rax, 0x5E26CB66A530
0000796da41d74ab  call rax
0000796da41d74ad  movaps xmm9, [rsp]
0000796da41d74b2  add rsp, 0x30
0000796da41d74b6  vmovaps xmm0, [rsp]
0000796da41d74bb  vmovaps xmm1, [rsp+0x10]
0000796da41d74c1  vmovaps xmm2, [rsp+0x20]
0000796da41d74c7  vmovaps xmm3, [rsp+0x30]
0000796da41d74cd  vmovaps xmm4, [rsp+0x40]
0000796da41d74d3  vmovaps xmm5, [rsp+0x50]
0000796da41d74d9  vmovaps xmm6, [rsp+0x60]
0000796da41d74df  vmovaps xmm7, [rsp+0x70]
0000796da41d74e5  vmovaps xmm8, [rsp+0x80]
0000796da41d74ee  vmovaps xmm10, [rsp+0x90]
0000796da41d74f7  vmovaps xmm11, [rsp+0xA0]
0000796da41d7500  vmovaps xmm12, [rsp+0xB0]
0000796da41d7509  vmovaps xmm13, [rsp+0xC0]
0000796da41d7512  vmovaps xmm14, [rsp+0xD0]
0000796da41d751b  vmovaps xmm15, [rsp+0xE0]
0000796da41d7524  add rsp, 0xF0
0000796da41d752b  pop r11
0000796da41d752d  pop r10
0000796da41d752f  pop r9
0000796da41d7531  pop r8
0000796da41d7533  pop rsi
0000796da41d7534  pop rdi
0000796da41d7535  pop rdx
0000796da41d7536  pop rcx
0000796da41d7537  pop rax
0000796da41d7538  add rsp, 0x08
0000796da41d753c  jmp 0x0000796DA41D3318
0000796da41d7541  sub rsp, 0x08
0000796da41d7545  push rax
0000796da41d7546  push rcx
0000796da41d7547  push rdx
0000796da41d7548  push rdi
0000796da41d7549  push rsi
0000796da41d754a  push r8
0000796da41d754c  push r9
0000796da41d754e  push r10
0000796da41d7550  push r11
0000796da41d7552  sub rsp, 0xF0
0000796da41d7559  vmovaps [rsp], xmm0
0000796da41d755e  vmovaps [rsp+0x10], xmm1
0000796da41d7564  vmovaps [rsp+0x20], xmm2
0000796da41d756a  vmovaps [rsp+0x30], xmm3
0000796da41d7570  vmovaps [rsp+0x40], xmm4
0000796da41d7576  vmovaps [rsp+0x50], xmm5
0000796da41d757c  vmovaps [rsp+0x60], xmm6
0000796da41d7582  vmovaps [rsp+0x70], xmm7
0000796da41d7588  vmovaps [rsp+0x80], xmm8
0000796da41d7591  vmovaps [rsp+0x90], xmm9
0000796da41d759a  vmovaps [rsp+0xA0], xmm10
0000796da41d75a3  vmovaps [rsp+0xB0], xmm11
0000796da41d75ac  vmovaps [rsp+0xC0], xmm12
0000796da41d75b5  vmovaps [rsp+0xD0], xmm13
0000796da41d75be  vmovaps [rsp+0xE0], xmm15
0000796da41d75c7  sub rsp, 0x30
0000796da41d75cb  movaps [rsp], xmm14
0000796da41d75d0  movaps [rsp+0x10], xmm13
0000796da41d75d6  movaps [rsp+0x20], xmm11
0000796da41d75dc  lea rdi, [rsp]
0000796da41d75e0  mov esi, 0x00
0000796da41d75e5  mov rax, 0x5E26CB66A530
0000796da41d75ef  call rax
0000796da41d75f1  movaps xmm14, [rsp]
0000796da41d75f6  add rsp, 0x30
0000796da41d75fa  vmovaps xmm0, [rsp]
0000796da41d75ff  vmovaps xmm1, [rsp+0x10]
0000796da41d7605  vmovaps xmm2, [rsp+0x20]
0000796da41d760b  vmovaps xmm3, [rsp+0x30]
0000796da41d7611  vmovaps xmm4, [rsp+0x40]
0000796da41d7617  vmovaps xmm5, [rsp+0x50]
0000796da41d761d  vmovaps xmm6, [rsp+0x60]
0000796da41d7623  vmovaps xmm7, [rsp+0x70]
0000796da41d7629  vmovaps xmm8, [rsp+0x80]
0000796da41d7632  vmovaps xmm9, [rsp+0x90]
0000796da41d763b  vmovaps xmm10, [rsp+0xA0]
0000796da41d7644  vmovaps xmm11, [rsp+0xB0]
0000796da41d764d  vmovaps xmm12, [rsp+0xC0]
0000796da41d7656  vmovaps xmm13, [rsp+0xD0]
0000796da41d765f  vmovaps xmm15, [rsp+0xE0]
0000796da41d7668  add rsp, 0xF0
0000796da41d766f  pop r11
0000796da41d7671  pop r10
0000796da41d7673  pop r9
0000796da41d7675  pop r8
0000796da41d7677  pop rsi
0000796da41d7678  pop rdi
0000796da41d7679  pop rdx
0000796da41d767a  pop rcx
0000796da41d767b  pop rax
0000796da41d767c  add rsp, 0x08
0000796da41d7680  jmp 0x0000796DA41D3332
0000796da41d7685  sub rsp, 0x08
0000796da41d7689  push rax
0000796da41d768a  push rcx
0000796da41d768b  push rdx
0000796da41d768c  push rdi
0000796da41d768d  push rsi
0000796da41d768e  push r8
0000796da41d7690  push r9
0000796da41d7692  push r10
0000796da41d7694  push r11
0000796da41d7696  sub rsp, 0xF0
0000796da41d769d  vmovaps [rsp], xmm0
0000796da41d76a2  vmovaps [rsp+0x10], xmm1
0000796da41d76a8  vmovaps [rsp+0x20], xmm2
0000796da41d76ae  vmovaps [rsp+0x30], xmm3
0000796da41d76b4  vmovaps [rsp+0x40], xmm4
0000796da41d76ba  vmovaps [rsp+0x50], xmm5
0000796da41d76c0  vmovaps [rsp+0x60], xmm6
0000796da41d76c6  vmovaps [rsp+0x70], xmm7
0000796da41d76cc  vmovaps [rsp+0x80], xmm8
0000796da41d76d5  vmovaps [rsp+0x90], xmm9
0000796da41d76de  vmovaps [rsp+0xA0], xmm10
0000796da41d76e7  vmovaps [rsp+0xB0], xmm12
0000796da41d76f0  vmovaps [rsp+0xC0], xmm13
0000796da41d76f9  vmovaps [rsp+0xD0], xmm14
0000796da41d7702  vmovaps [rsp+0xE0], xmm15
0000796da41d770b  sub rsp, 0x30
0000796da41d770f  movaps [rsp], xmm11
0000796da41d7714  movaps [rsp+0x10], xmm7
0000796da41d7719  movaps [rsp+0x20], xmm13
0000796da41d771f  lea rdi, [rsp]
0000796da41d7723  mov esi, 0x00
0000796da41d7728  mov rax, 0x5E26CB66A530
0000796da41d7732  call rax
0000796da41d7734  movaps xmm11, [rsp]
0000796da41d7739  add rsp, 0x30
0000796da41d773d  vmovaps xmm0, [rsp]
0000796da41d7742  vmovaps xmm1, [rsp+0x10]
0000796da41d7748  vmovaps xmm2, [rsp+0x20]
0000796da41d774e  vmovaps xmm3, [rsp+0x30]
0000796da41d7754  vmovaps xmm4, [rsp+0x40]
0000796da41d775a  vmovaps xmm5, [rsp+0x50]
0000796da41d7760  vmovaps xmm6, [rsp+0x60]
0000796da41d7766  vmovaps xmm7, [rsp+0x70]
0000796da41d776c  vmovaps xmm8, [rsp+0x80]
0000796da41d7775  vmovaps xmm9, [rsp+0x90]
0000796da41d777e  vmovaps xmm10, [rsp+0xA0]
0000796da41d7787  vmovaps xmm12, [rsp+0xB0]
0000796da41d7790  vmovaps xmm13, [rsp+0xC0]
0000796da41d7799  vmovaps xmm14, [rsp+0xD0]
0000796da41d77a2  vmovaps xmm15, [rsp+0xE0]
0000796da41d77ab  add rsp, 0xF0
0000796da41d77b2  pop r11
0000796da41d77b4  pop r10
0000796da41d77b6  pop r9
0000796da41d77b8  pop r8
0000796da41d77ba  pop rsi
0000796da41d77bb  pop rdi
0000796da41d77bc  pop rdx
0000796da41d77bd  pop rcx
0000796da41d77be  pop rax
0000796da41d77bf  add rsp, 0x08
0000796da41d77c3  jmp 0x0000796DA41D335E
0000796da41d77c8  sub rsp, 0x08
0000796da41d77cc  push rax
0000796da41d77cd  push rcx
0000796da41d77ce  push rdx
0000796da41d77cf  push rdi
0000796da41d77d0  push rsi
0000796da41d77d1  push r8
0000796da41d77d3  push r9
0000796da41d77d5  push r10
0000796da41d77d7  push r11
0000796da41d77d9  sub rsp, 0xF0
0000796da41d77e0  vmovaps [rsp], xmm0
0000796da41d77e5  vmovaps [rsp+0x10], xmm1
0000796da41d77eb  vmovaps [rsp+0x20], xmm2
0000796da41d77f1  vmovaps [rsp+0x30], xmm3
0000796da41d77f7  vmovaps [rsp+0x40], xmm4
0000796da41d77fd  vmovaps [rsp+0x50], xmm5
0000796da41d7803  vmovaps [rsp+0x60], xmm6
0000796da41d7809  vmovaps [rsp+0x70], xmm7
0000796da41d780f  vmovaps [rsp+0x80], xmm8
0000796da41d7818  vmovaps [rsp+0x90], xmm9
0000796da41d7821  vmovaps [rsp+0xA0], xmm10
0000796da41d782a  vmovaps [rsp+0xB0], xmm11
0000796da41d7833  vmovaps [rsp+0xC0], xmm12
0000796da41d783c  vmovaps [rsp+0xD0], xmm14
0000796da41d7845  vmovaps [rsp+0xE0], xmm15
0000796da41d784e  sub rsp, 0x30
0000796da41d7852  movaps [rsp], xmm13
0000796da41d7857  movaps [rsp+0x10], xmm10
0000796da41d785d  movaps [rsp+0x20], xmm12
0000796da41d7863  lea rdi, [rsp]
0000796da41d7867  mov esi, 0x00
0000796da41d786c  mov rax, 0x5E26CB66A530
0000796da41d7876  call rax
0000796da41d7878  movaps xmm13, [rsp]
0000796da41d787d  add rsp, 0x30
0000796da41d7881  vmovaps xmm0, [rsp]
0000796da41d7886  vmovaps xmm1, [rsp+0x10]
0000796da41d788c  vmovaps xmm2, [rsp+0x20]
0000796da41d7892  vmovaps xmm3, [rsp+0x30]
0000796da41d7898  vmovaps xmm4, [rsp+0x40]
0000796da41d789e  vmovaps xmm5, [rsp+0x50]
0000796da41d78a4  vmovaps xmm6, [rsp+0x60]
0000796da41d78aa  vmovaps xmm7, [rsp+0x70]
0000796da41d78b0  vmovaps xmm8, [rsp+0x80]
0000796da41d78b9  vmovaps xmm9, [rsp+0x90]
0000796da41d78c2  vmovaps xmm10, [rsp+0xA0]
0000796da41d78cb  vmovaps xmm11, [rsp+0xB0]
0000796da41d78d4  vmovaps xmm12, [rsp+0xC0]
0000796da41d78dd  vmovaps xmm14, [rsp+0xD0]
0000796da41d78e6  vmovaps xmm15, [rsp+0xE0]
0000796da41d78ef  add rsp, 0xF0
0000796da41d78f6  pop r11
0000796da41d78f8  pop r10
0000796da41d78fa  pop r9
0000796da41d78fc  pop r8
0000796da41d78fe  pop rsi
0000796da41d78ff  pop rdi
0000796da41d7900  pop rdx
0000796da41d7901  pop rcx
0000796da41d7902  pop rax
0000796da41d7903  add rsp, 0x08
0000796da41d7907  jmp 0x0000796DA41D3378
0000796da41d790c  sub rsp, 0x08
0000796da41d7910  push rax
0000796da41d7911  push rcx
0000796da41d7912  push rdx
0000796da41d7913  push rdi
0000796da41d7914  push rsi
0000796da41d7915  push r8
0000796da41d7917  push r9
0000796da41d7919  push r10
0000796da41d791b  push r11
0000796da41d791d  sub rsp, 0xF0
0000796da41d7924  vmovaps [rsp], xmm0
0000796da41d7929  vmovaps [rsp+0x10], xmm1
0000796da41d792f  vmovaps [rsp+0x20], xmm2
0000796da41d7935  vmovaps [rsp+0x30], xmm3
0000796da41d793b  vmovaps [rsp+0x40], xmm4
0000796da41d7941  vmovaps [rsp+0x50], xmm5
0000796da41d7947  vmovaps [rsp+0x60], xmm6
0000796da41d794d  vmovaps [rsp+0x70], xmm7
0000796da41d7953  vmovaps [rsp+0x80], xmm8
0000796da41d795c  vmovaps [rsp+0x90], xmm9
0000796da41d7965  vmovaps [rsp+0xA0], xmm11
0000796da41d796e  vmovaps [rsp+0xB0], xmm12
0000796da41d7977  vmovaps [rsp+0xC0], xmm13
0000796da41d7980  vmovaps [rsp+0xD0], xmm14
0000796da41d7989  vmovaps [rsp+0xE0], xmm15
0000796da41d7992  sub rsp, 0x30
0000796da41d7996  movaps [rsp], xmm10
0000796da41d799b  movaps [rsp+0x10], xmm7
0000796da41d79a0  movaps [rsp+0x20], xmm12
0000796da41d79a6  lea rdi, [rsp]
0000796da41d79aa  mov esi, 0x00
0000796da41d79af  mov rax, 0x5E26CB66A530
0000796da41d79b9  call rax
0000796da41d79bb  movaps xmm10, [rsp]
0000796da41d79c0  add rsp, 0x30
0000796da41d79c4  vmovaps xmm0, [rsp]
0000796da41d79c9  vmovaps xmm1, [rsp+0x10]
0000796da41d79cf  vmovaps xmm2, [rsp+0x20]
0000796da41d79d5  vmovaps xmm3, [rsp+0x30]
0000796da41d79db  vmovaps xmm4, [rsp+0x40]
0000796da41d79e1  vmovaps xmm5, [rsp+0x50]
0000796da41d79e7  vmovaps xmm6, [rsp+0x60]
0000796da41d79ed  vmovaps xmm7, [rsp+0x70]
0000796da41d79f3  vmovaps xmm8, [rsp+0x80]
0000796da41d79fc  vmovaps xmm9, [rsp+0x90]
0000796da41d7a05  vmovaps xmm11, [rsp+0xA0]
0000796da41d7a0e  vmovaps xmm12, [rsp+0xB0]
0000796da41d7a17  vmovaps xmm13, [rsp+0xC0]
0000796da41d7a20  vmovaps xmm14, [rsp+0xD0]
0000796da41d7a29  vmovaps xmm15, [rsp+0xE0]
0000796da41d7a32  add rsp, 0xF0
0000796da41d7a39  pop r11
0000796da41d7a3b  pop r10
0000796da41d7a3d  pop r9
0000796da41d7a3f  pop r8
0000796da41d7a41  pop rsi
0000796da41d7a42  pop rdi
0000796da41d7a43  pop rdx
0000796da41d7a44  pop rcx
0000796da41d7a45  pop rax
0000796da41d7a46  add rsp, 0x08
0000796da41d7a4a  jmp 0x0000796DA41D33A4
0000796da41d7a4f  sub rsp, 0x08
0000796da41d7a53  push rax
0000796da41d7a54  push rcx
0000796da41d7a55  push rdx
0000796da41d7a56  push rdi
0000796da41d7a57  push rsi
0000796da41d7a58  push r8
0000796da41d7a5a  push r9
0000796da41d7a5c  push r10
0000796da41d7a5e  push r11
0000796da41d7a60  sub rsp, 0xF0
0000796da41d7a67  vmovaps [rsp], xmm0
0000796da41d7a6c  vmovaps [rsp+0x10], xmm1
0000796da41d7a72  vmovaps [rsp+0x20], xmm2
0000796da41d7a78  vmovaps [rsp+0x30], xmm3
0000796da41d7a7e  vmovaps [rsp+0x40], xmm4
0000796da41d7a84  vmovaps [rsp+0x50], xmm5
0000796da41d7a8a  vmovaps [rsp+0x60], xmm6
0000796da41d7a90  vmovaps [rsp+0x70], xmm7
0000796da41d7a96  vmovaps [rsp+0x80], xmm8
0000796da41d7a9f  vmovaps [rsp+0x90], xmm9
0000796da41d7aa8  vmovaps [rsp+0xA0], xmm10
0000796da41d7ab1  vmovaps [rsp+0xB0], xmm11
0000796da41d7aba  vmovaps [rsp+0xC0], xmm13
0000796da41d7ac3  vmovaps [rsp+0xD0], xmm14
0000796da41d7acc  vmovaps [rsp+0xE0], xmm15
0000796da41d7ad5  sub rsp, 0x30
0000796da41d7ad9  movaps [rsp], xmm12
0000796da41d7ade  movaps [rsp+0x10], xmm1
0000796da41d7ae3  movaps [rsp+0x20], xmm8
0000796da41d7ae9  lea rdi, [rsp]
0000796da41d7aed  mov esi, 0x00
0000796da41d7af2  mov rax, 0x5E26CB66A530
0000796da41d7afc  call rax
0000796da41d7afe  movaps xmm12, [rsp]
0000796da41d7b03  add rsp, 0x30
0000796da41d7b07  vmovaps xmm0, [rsp]
0000796da41d7b0c  vmovaps xmm1, [rsp+0x10]
0000796da41d7b12  vmovaps xmm2, [rsp+0x20]
0000796da41d7b18  vmovaps xmm3, [rsp+0x30]
0000796da41d7b1e  vmovaps xmm4, [rsp+0x40]
0000796da41d7b24  vmovaps xmm5, [rsp+0x50]
0000796da41d7b2a  vmovaps xmm6, [rsp+0x60]
0000796da41d7b30  vmovaps xmm7, [rsp+0x70]
0000796da41d7b36  vmovaps xmm8, [rsp+0x80]
0000796da41d7b3f  vmovaps xmm9, [rsp+0x90]
0000796da41d7b48  vmovaps xmm10, [rsp+0xA0]
0000796da41d7b51  vmovaps xmm11, [rsp+0xB0]
0000796da41d7b5a  vmovaps xmm13, [rsp+0xC0]
0000796da41d7b63  vmovaps xmm14, [rsp+0xD0]
0000796da41d7b6c  vmovaps xmm15, [rsp+0xE0]
0000796da41d7b75  add rsp, 0xF0
0000796da41d7b7c  pop r11
0000796da41d7b7e  pop r10
0000796da41d7b80  pop r9
0000796da41d7b82  pop r8
0000796da41d7b84  pop rsi
0000796da41d7b85  pop rdi
0000796da41d7b86  pop rdx
0000796da41d7b87  pop rcx
0000796da41d7b88  pop rax
0000796da41d7b89  add rsp, 0x08
0000796da41d7b8d  jmp 0x0000796DA41D33BE
0000796da41d7b92  call 0x0000796DA3FFF430
0000796da41d7b97  jmp 0x0000796DA41D33C8
0000796da41d7b9c  sub rsp, 0x08
0000796da41d7ba0  push rax
0000796da41d7ba1  push rcx
0000796da41d7ba2  push rdx
0000796da41d7ba3  push rdi
0000796da41d7ba4  push rsi
0000796da41d7ba5  push r8
0000796da41d7ba7  push r9
0000796da41d7ba9  push r10
0000796da41d7bab  push r11
0000796da41d7bad  sub rsp, 0xF0
0000796da41d7bb4  vmovaps [rsp], xmm0
0000796da41d7bb9  vmovaps [rsp+0x10], xmm1
0000796da41d7bbf  vmovaps [rsp+0x20], xmm2
0000796da41d7bc5  vmovaps [rsp+0x30], xmm3
0000796da41d7bcb  vmovaps [rsp+0x40], xmm4
0000796da41d7bd1  vmovaps [rsp+0x50], xmm5
0000796da41d7bd7  vmovaps [rsp+0x60], xmm6
0000796da41d7bdd  vmovaps [rsp+0x70], xmm7
0000796da41d7be3  vmovaps [rsp+0x80], xmm9
0000796da41d7bec  vmovaps [rsp+0x90], xmm10
0000796da41d7bf5  vmovaps [rsp+0xA0], xmm11
0000796da41d7bfe  vmovaps [rsp+0xB0], xmm12
0000796da41d7c07  vmovaps [rsp+0xC0], xmm13
0000796da41d7c10  vmovaps [rsp+0xD0], xmm14
0000796da41d7c19  vmovaps [rsp+0xE0], xmm15
0000796da41d7c22  sub rsp, 0x30
0000796da41d7c26  movaps [rsp], xmm8
0000796da41d7c2b  movaps [rsp+0x10], xmm15
0000796da41d7c31  movaps [rsp+0x20], xmm9
0000796da41d7c37  lea rdi, [rsp]
0000796da41d7c3b  mov esi, 0x00
0000796da41d7c40  mov rax, 0x5E26CB66A530
0000796da41d7c4a  call rax
0000796da41d7c4c  movaps xmm8, [rsp]
0000796da41d7c51  add rsp, 0x30
0000796da41d7c55  vmovaps xmm0, [rsp]
0000796da41d7c5a  vmovaps xmm1, [rsp+0x10]
0000796da41d7c60  vmovaps xmm2, [rsp+0x20]
0000796da41d7c66  vmovaps xmm3, [rsp+0x30]
0000796da41d7c6c  vmovaps xmm4, [rsp+0x40]
0000796da41d7c72  vmovaps xmm5, [rsp+0x50]
0000796da41d7c78  vmovaps xmm6, [rsp+0x60]
0000796da41d7c7e  vmovaps xmm7, [rsp+0x70]
0000796da41d7c84  vmovaps xmm9, [rsp+0x80]
0000796da41d7c8d  vmovaps xmm10, [rsp+0x90]
0000796da41d7c96  vmovaps xmm11, [rsp+0xA0]
0000796da41d7c9f  vmovaps xmm12, [rsp+0xB0]
0000796da41d7ca8  vmovaps xmm13, [rsp+0xC0]
0000796da41d7cb1  vmovaps xmm14, [rsp+0xD0]
0000796da41d7cba  vmovaps xmm15, [rsp+0xE0]
0000796da41d7cc3  add rsp, 0xF0
0000796da41d7cca  pop r11
0000796da41d7ccc  pop r10
0000796da41d7cce  pop r9
0000796da41d7cd0  pop r8
0000796da41d7cd2  pop rsi
0000796da41d7cd3  pop rdi
0000796da41d7cd4  pop rdx
0000796da41d7cd5  pop rcx
0000796da41d7cd6  pop rax
0000796da41d7cd7  add rsp, 0x08
0000796da41d7cdb  jmp 0x0000796DA41D33EA
0000796da41d7ce0  sub rsp, 0x08
0000796da41d7ce4  push rax
0000796da41d7ce5  push rcx
0000796da41d7ce6  push rdx
0000796da41d7ce7  push rdi
0000796da41d7ce8  push rsi
0000796da41d7ce9  push r8
0000796da41d7ceb  push r9
0000796da41d7ced  push r10
0000796da41d7cef  push r11
0000796da41d7cf1  sub rsp, 0xF0
0000796da41d7cf8  vmovaps [rsp], xmm0
0000796da41d7cfd  vmovaps [rsp+0x10], xmm1
0000796da41d7d03  vmovaps [rsp+0x20], xmm2
0000796da41d7d09  vmovaps [rsp+0x30], xmm3
0000796da41d7d0f  vmovaps [rsp+0x40], xmm4
0000796da41d7d15  vmovaps [rsp+0x50], xmm5
0000796da41d7d1b  vmovaps [rsp+0x60], xmm6
0000796da41d7d21  vmovaps [rsp+0x70], xmm7
0000796da41d7d27  vmovaps [rsp+0x80], xmm8
0000796da41d7d30  vmovaps [rsp+0x90], xmm10
0000796da41d7d39  vmovaps [rsp+0xA0], xmm11
0000796da41d7d42  vmovaps [rsp+0xB0], xmm12
0000796da41d7d4b  vmovaps [rsp+0xC0], xmm13
0000796da41d7d54  vmovaps [rsp+0xD0], xmm14
0000796da41d7d5d  vmovaps [rsp+0xE0], xmm15
0000796da41d7d66  sub rsp, 0x30
0000796da41d7d6a  movaps [rsp], xmm9
0000796da41d7d6f  movaps [rsp+0x10], xmm1
0000796da41d7d74  movaps [rsp+0x20], xmm15
0000796da41d7d7a  lea rdi, [rsp]
0000796da41d7d7e  mov esi, 0x00
0000796da41d7d83  mov rax, 0x5E26CB66A530
0000796da41d7d8d  call rax
0000796da41d7d8f  movaps xmm9, [rsp]
0000796da41d7d94  add rsp, 0x30
0000796da41d7d98  vmovaps xmm0, [rsp]
0000796da41d7d9d  vmovaps xmm1, [rsp+0x10]
0000796da41d7da3  vmovaps xmm2, [rsp+0x20]
0000796da41d7da9  vmovaps xmm3, [rsp+0x30]
0000796da41d7daf  vmovaps xmm4, [rsp+0x40]
0000796da41d7db5  vmovaps xmm5, [rsp+0x50]
0000796da41d7dbb  vmovaps xmm6, [rsp+0x60]
0000796da41d7dc1  vmovaps xmm7, [rsp+0x70]
0000796da41d7dc7  vmovaps xmm8, [rsp+0x80]
0000796da41d7dd0  vmovaps xmm10, [rsp+0x90]
0000796da41d7dd9  vmovaps xmm11, [rsp+0xA0]
0000796da41d7de2  vmovaps xmm12, [rsp+0xB0]
0000796da41d7deb  vmovaps xmm13, [rsp+0xC0]
0000796da41d7df4  vmovaps xmm14, [rsp+0xD0]
0000796da41d7dfd  vmovaps xmm15, [rsp+0xE0]
0000796da41d7e06  add rsp, 0xF0
0000796da41d7e0d  pop r11
0000796da41d7e0f  pop r10
0000796da41d7e11  pop r9
0000796da41d7e13  pop r8
0000796da41d7e15  pop rsi
0000796da41d7e16  pop rdi
0000796da41d7e17  pop rdx
0000796da41d7e18  pop rcx
0000796da41d7e19  pop rax
0000796da41d7e1a  add rsp, 0x08
0000796da41d7e1e  jmp 0x0000796DA41D3418
0000796da41d7e23  sub rsp, 0x08
0000796da41d7e27  push rax
0000796da41d7e28  push rcx
0000796da41d7e29  push rdx
0000796da41d7e2a  push rdi
0000796da41d7e2b  push rsi
0000796da41d7e2c  push r8
0000796da41d7e2e  push r9
0000796da41d7e30  push r10
0000796da41d7e32  push r11
0000796da41d7e34  sub rsp, 0xF0
0000796da41d7e3b  vmovaps [rsp], xmm0
0000796da41d7e40  vmovaps [rsp+0x10], xmm1
0000796da41d7e46  vmovaps [rsp+0x20], xmm2
0000796da41d7e4c  vmovaps [rsp+0x30], xmm3
0000796da41d7e52  vmovaps [rsp+0x40], xmm4
0000796da41d7e58  vmovaps [rsp+0x50], xmm5
0000796da41d7e5e  vmovaps [rsp+0x60], xmm6
0000796da41d7e64  vmovaps [rsp+0x70], xmm7
0000796da41d7e6a  vmovaps [rsp+0x80], xmm8
0000796da41d7e73  vmovaps [rsp+0x90], xmm9
0000796da41d7e7c  vmovaps [rsp+0xA0], xmm10
0000796da41d7e85  vmovaps [rsp+0xB0], xmm11
0000796da41d7e8e  vmovaps [rsp+0xC0], xmm12
0000796da41d7e97  vmovaps [rsp+0xD0], xmm13
0000796da41d7ea0  vmovaps [rsp+0xE0], xmm14
0000796da41d7ea9  sub rsp, 0x30
0000796da41d7ead  movaps [rsp], xmm15
0000796da41d7eb2  movaps [rsp+0x10], xmm4
0000796da41d7eb7  movaps [rsp+0x20], xmm1
0000796da41d7ebc  lea rdi, [rsp]
0000796da41d7ec0  mov esi, 0x00
0000796da41d7ec5  mov rax, 0x5E26CB66A530
0000796da41d7ecf  call rax
0000796da41d7ed1  movaps xmm15, [rsp]
0000796da41d7ed6  add rsp, 0x30
0000796da41d7eda  vmovaps xmm0, [rsp]
0000796da41d7edf  vmovaps xmm1, [rsp+0x10]
0000796da41d7ee5  vmovaps xmm2, [rsp+0x20]
0000796da41d7eeb  vmovaps xmm3, [rsp+0x30]
0000796da41d7ef1  vmovaps xmm4, [rsp+0x40]
0000796da41d7ef7  vmovaps xmm5, [rsp+0x50]
0000796da41d7efd  vmovaps xmm6, [rsp+0x60]
0000796da41d7f03  vmovaps xmm7, [rsp+0x70]
0000796da41d7f09  vmovaps xmm8, [rsp+0x80]
0000796da41d7f12  vmovaps xmm9, [rsp+0x90]
0000796da41d7f1b  vmovaps xmm10, [rsp+0xA0]
0000796da41d7f24  vmovaps xmm11, [rsp+0xB0]
0000796da41d7f2d  vmovaps xmm12, [rsp+0xC0]
0000796da41d7f36  vmovaps xmm13, [rsp+0xD0]
0000796da41d7f3f  vmovaps xmm14, [rsp+0xE0]
0000796da41d7f48  add rsp, 0xF0
0000796da41d7f4f  pop r11
0000796da41d7f51  pop r10
0000796da41d7f53  pop r9
0000796da41d7f55  pop r8
0000796da41d7f57  pop rsi
0000796da41d7f58  pop rdi
0000796da41d7f59  pop rdx
0000796da41d7f5a  pop rcx
0000796da41d7f5b  pop rax
0000796da41d7f5c  add rsp, 0x08
0000796da41d7f60  jmp 0x0000796DA41D343E
0000796da41d7f65  sub rsp, 0x08
0000796da41d7f69  push rax
0000796da41d7f6a  push rcx
0000796da41d7f6b  push rdx
0000796da41d7f6c  push rdi
0000796da41d7f6d  push rsi
0000796da41d7f6e  push r8
0000796da41d7f70  push r9
0000796da41d7f72  push r10
0000796da41d7f74  push r11
0000796da41d7f76  sub rsp, 0xF0
0000796da41d7f7d  vmovaps [rsp], xmm0
0000796da41d7f82  vmovaps [rsp+0x10], xmm2
0000796da41d7f88  vmovaps [rsp+0x20], xmm3
0000796da41d7f8e  vmovaps [rsp+0x30], xmm4
0000796da41d7f94  vmovaps [rsp+0x40], xmm5
0000796da41d7f9a  vmovaps [rsp+0x50], xmm6
0000796da41d7fa0  vmovaps [rsp+0x60], xmm7
0000796da41d7fa6  vmovaps [rsp+0x70], xmm8
0000796da41d7fac  vmovaps [rsp+0x80], xmm9
0000796da41d7fb5  vmovaps [rsp+0x90], xmm10
0000796da41d7fbe  vmovaps [rsp+0xA0], xmm11
0000796da41d7fc7  vmovaps [rsp+0xB0], xmm12
0000796da41d7fd0  vmovaps [rsp+0xC0], xmm13
0000796da41d7fd9  vmovaps [rsp+0xD0], xmm14
0000796da41d7fe2  vmovaps [rsp+0xE0], xmm15
0000796da41d7feb  sub rsp, 0x30
0000796da41d7fef  movaps [rsp], xmm1
0000796da41d7ff3  movaps [rsp+0x10], xmm14
0000796da41d7ff9  movaps [rsp+0x20], xmm11
0000796da41d7fff  lea rdi, [rsp]
0000796da41d8003  mov esi, 0x00
0000796da41d8008  mov rax, 0x5E26CB66A530
0000796da41d8012  call rax
0000796da41d8014  movaps xmm1, [rsp]
0000796da41d8018  add rsp, 0x30
0000796da41d801c  vmovaps xmm0, [rsp]
0000796da41d8021  vmovaps xmm2, [rsp+0x10]
0000796da41d8027  vmovaps xmm3, [rsp+0x20]
0000796da41d802d  vmovaps xmm4, [rsp+0x30]
0000796da41d8033  vmovaps xmm5, [rsp+0x40]
0000796da41d8039  vmovaps xmm6, [rsp+0x50]
0000796da41d803f  vmovaps xmm7, [rsp+0x60]
0000796da41d8045  vmovaps xmm8, [rsp+0x70]
0000796da41d804b  vmovaps xmm9, [rsp+0x80]
0000796da41d8054  vmovaps xmm10, [rsp+0x90]
0000796da41d805d  vmovaps xmm11, [rsp+0xA0]
0000796da41d8066  vmovaps xmm12, [rsp+0xB0]
0000796da41d806f  vmovaps xmm13, [rsp+0xC0]
0000796da41d8078  vmovaps xmm14, [rsp+0xD0]
0000796da41d8081  vmovaps xmm15, [rsp+0xE0]
0000796da41d808a  add rsp, 0xF0
0000796da41d8091  pop r11
0000796da41d8093  pop r10
0000796da41d8095  pop r9
0000796da41d8097  pop r8
0000796da41d8099  pop rsi
0000796da41d809a  pop rdi
0000796da41d809b  pop rdx
0000796da41d809c  pop rcx
0000796da41d809d  pop rax
0000796da41d809e  add rsp, 0x08
0000796da41d80a2  jmp 0x0000796DA41D345F
0000796da41d80a7  call 0x0000796DA40E45A0
0000796da41d80ac  jmp 0x0000796DA41D346D
0000796da41d80b1  call 0x0000796DA4009D70
0000796da41d80b6  jmp 0x0000796DA41D3477
0000796da41d80bb  sub rsp, 0x08
0000796da41d80bf  push rax
0000796da41d80c0  push rcx
0000796da41d80c1  push rdx
0000796da41d80c2  push rdi
0000796da41d80c3  push rsi
0000796da41d80c4  push r8
0000796da41d80c6  push r9
0000796da41d80c8  push r10
0000796da41d80ca  push r11
0000796da41d80cc  sub rsp, 0xF0
0000796da41d80d3  vmovaps [rsp], xmm0
0000796da41d80d8  vmovaps [rsp+0x10], xmm1
0000796da41d80de  vmovaps [rsp+0x20], xmm2
0000796da41d80e4  vmovaps [rsp+0x30], xmm3
0000796da41d80ea  vmovaps [rsp+0x40], xmm4
0000796da41d80f0  vmovaps [rsp+0x50], xmm5
0000796da41d80f6  vmovaps [rsp+0x60], xmm6
0000796da41d80fc  vmovaps [rsp+0x70], xmm8
0000796da41d8102  vmovaps [rsp+0x80], xmm9
0000796da41d810b  vmovaps [rsp+0x90], xmm10
0000796da41d8114  vmovaps [rsp+0xA0], xmm11
0000796da41d811d  vmovaps [rsp+0xB0], xmm12
0000796da41d8126  vmovaps [rsp+0xC0], xmm13
0000796da41d812f  vmovaps [rsp+0xD0], xmm14
0000796da41d8138  vmovaps [rsp+0xE0], xmm15
0000796da41d8141  sub rsp, 0x30
0000796da41d8145  movaps [rsp], xmm7
0000796da41d8149  movaps [rsp+0x10], xmm13
0000796da41d814f  movaps [rsp+0x20], xmm10
0000796da41d8155  lea rdi, [rsp]
0000796da41d8159  mov esi, 0x00
0000796da41d815e  mov rax, 0x5E26CB66A530
0000796da41d8168  call rax
0000796da41d816a  movaps xmm7, [rsp]
0000796da41d816e  add rsp, 0x30
0000796da41d8172  vmovaps xmm0, [rsp]
0000796da41d8177  vmovaps xmm1, [rsp+0x10]
0000796da41d817d  vmovaps xmm2, [rsp+0x20]
0000796da41d8183  vmovaps xmm3, [rsp+0x30]
0000796da41d8189  vmovaps xmm4, [rsp+0x40]
0000796da41d818f  vmovaps xmm5, [rsp+0x50]
0000796da41d8195  vmovaps xmm6, [rsp+0x60]
0000796da41d819b  vmovaps xmm8, [rsp+0x70]
0000796da41d81a1  vmovaps xmm9, [rsp+0x80]
0000796da41d81aa  vmovaps xmm10, [rsp+0x90]
0000796da41d81b3  vmovaps xmm11, [rsp+0xA0]
0000796da41d81bc  vmovaps xmm12, [rsp+0xB0]
0000796da41d81c5  vmovaps xmm13, [rsp+0xC0]
0000796da41d81ce  vmovaps xmm14, [rsp+0xD0]
0000796da41d81d7  vmovaps xmm15, [rsp+0xE0]
0000796da41d81e0  add rsp, 0xF0
0000796da41d81e7  pop r11
0000796da41d81e9  pop r10
0000796da41d81eb  pop r9
0000796da41d81ed  pop r8
0000796da41d81ef  pop rsi
0000796da41d81f0  pop rdi
0000796da41d81f1  pop rdx
0000796da41d81f2  pop rcx
0000796da41d81f3  pop rax
0000796da41d81f4  add rsp, 0x08
0000796da41d81f8  jmp 0x0000796DA41D3498
0000796da41d81fd  sub rsp, 0x08
0000796da41d8201  push rax
0000796da41d8202  push rcx
0000796da41d8203  push rdx
0000796da41d8204  push rdi
0000796da41d8205  push rsi
0000796da41d8206  push r8
0000796da41d8208  push r9
0000796da41d820a  push r10
0000796da41d820c  push r11
0000796da41d820e  sub rsp, 0xF0
0000796da41d8215  vmovaps [rsp], xmm0
0000796da41d821a  vmovaps [rsp+0x10], xmm1
0000796da41d8220  vmovaps [rsp+0x20], xmm2
0000796da41d8226  vmovaps [rsp+0x30], xmm3
0000796da41d822c  vmovaps [rsp+0x40], xmm4
0000796da41d8232  vmovaps [rsp+0x50], xmm5
0000796da41d8238  vmovaps [rsp+0x60], xmm6
0000796da41d823e  vmovaps [rsp+0x70], xmm7
0000796da41d8244  vmovaps [rsp+0x80], xmm8
0000796da41d824d  vmovaps [rsp+0x90], xmm9
0000796da41d8256  vmovaps [rsp+0xA0], xmm11
0000796da41d825f  vmovaps [rsp+0xB0], xmm12
0000796da41d8268  vmovaps [rsp+0xC0], xmm13
0000796da41d8271  vmovaps [rsp+0xD0], xmm14
0000796da41d827a  vmovaps [rsp+0xE0], xmm15
0000796da41d8283  sub rsp, 0x30
0000796da41d8287  movaps [rsp], xmm10
0000796da41d828c  movaps [rsp+0x10], xmm11
0000796da41d8292  movaps [rsp+0x20], xmm13
0000796da41d8298  lea rdi, [rsp]
0000796da41d829c  mov esi, 0x00
0000796da41d82a1  mov rax, 0x5E26CB66A530
0000796da41d82ab  call rax
0000796da41d82ad  movaps xmm10, [rsp]
0000796da41d82b2  add rsp, 0x30
0000796da41d82b6  vmovaps xmm0, [rsp]
0000796da41d82bb  vmovaps xmm1, [rsp+0x10]
0000796da41d82c1  vmovaps xmm2, [rsp+0x20]
0000796da41d82c7  vmovaps xmm3, [rsp+0x30]
0000796da41d82cd  vmovaps xmm4, [rsp+0x40]
0000796da41d82d3  vmovaps xmm5, [rsp+0x50]
0000796da41d82d9  vmovaps xmm6, [rsp+0x60]
0000796da41d82df  vmovaps xmm7, [rsp+0x70]
0000796da41d82e5  vmovaps xmm8, [rsp+0x80]
0000796da41d82ee  vmovaps xmm9, [rsp+0x90]
0000796da41d82f7  vmovaps xmm11, [rsp+0xA0]
0000796da41d8300  vmovaps xmm12, [rsp+0xB0]
0000796da41d8309  vmovaps xmm13, [rsp+0xC0]
0000796da41d8312  vmovaps xmm14, [rsp+0xD0]
0000796da41d831b  vmovaps xmm15, [rsp+0xE0]
0000796da41d8324  add rsp, 0xF0
0000796da41d832b  pop r11
0000796da41d832d  pop r10
0000796da41d832f  pop r9
0000796da41d8331  pop r8
0000796da41d8333  pop rsi
0000796da41d8334  pop rdi
0000796da41d8335  pop rdx
0000796da41d8336  pop rcx
0000796da41d8337  pop rax
0000796da41d8338  add rsp, 0x08
0000796da41d833c  jmp 0x0000796DA41D34C6
0000796da41d8341  sub rsp, 0x08
0000796da41d8345  push rax
0000796da41d8346  push rcx
0000796da41d8347  push rdx
0000796da41d8348  push rdi
0000796da41d8349  push rsi
0000796da41d834a  push r8
0000796da41d834c  push r9
0000796da41d834e  push r10
0000796da41d8350  push r11
0000796da41d8352  sub rsp, 0xF0
0000796da41d8359  vmovaps [rsp], xmm0
0000796da41d835e  vmovaps [rsp+0x10], xmm1
0000796da41d8364  vmovaps [rsp+0x20], xmm2
0000796da41d836a  vmovaps [rsp+0x30], xmm3
0000796da41d8370  vmovaps [rsp+0x40], xmm4
0000796da41d8376  vmovaps [rsp+0x50], xmm5
0000796da41d837c  vmovaps [rsp+0x60], xmm6
0000796da41d8382  vmovaps [rsp+0x70], xmm7
0000796da41d8388  vmovaps [rsp+0x80], xmm8
0000796da41d8391  vmovaps [rsp+0x90], xmm9
0000796da41d839a  vmovaps [rsp+0xA0], xmm10
0000796da41d83a3  vmovaps [rsp+0xB0], xmm12
0000796da41d83ac  vmovaps [rsp+0xC0], xmm13
0000796da41d83b5  vmovaps [rsp+0xD0], xmm14
0000796da41d83be  vmovaps [rsp+0xE0], xmm15
0000796da41d83c7  sub rsp, 0x30
0000796da41d83cb  movaps [rsp], xmm11
0000796da41d83d0  movaps [rsp+0x10], xmm14
0000796da41d83d6  movaps [rsp+0x20], xmm13
0000796da41d83dc  lea rdi, [rsp]
0000796da41d83e0  mov esi, 0x00
0000796da41d83e5  mov rax, 0x5E26CB66A530
0000796da41d83ef  call rax
0000796da41d83f1  movaps xmm11, [rsp]
0000796da41d83f6  add rsp, 0x30
0000796da41d83fa  vmovaps xmm0, [rsp]
0000796da41d83ff  vmovaps xmm1, [rsp+0x10]
0000796da41d8405  vmovaps xmm2, [rsp+0x20]
0000796da41d840b  vmovaps xmm3, [rsp+0x30]
0000796da41d8411  vmovaps xmm4, [rsp+0x40]
0000796da41d8417  vmovaps xmm5, [rsp+0x50]
0000796da41d841d  vmovaps xmm6, [rsp+0x60]
0000796da41d8423  vmovaps xmm7, [rsp+0x70]
0000796da41d8429  vmovaps xmm8, [rsp+0x80]
0000796da41d8432  vmovaps xmm9, [rsp+0x90]
0000796da41d843b  vmovaps xmm10, [rsp+0xA0]
0000796da41d8444  vmovaps xmm12, [rsp+0xB0]
0000796da41d844d  vmovaps xmm13, [rsp+0xC0]
0000796da41d8456  vmovaps xmm14, [rsp+0xD0]
0000796da41d845f  vmovaps xmm15, [rsp+0xE0]
0000796da41d8468  add rsp, 0xF0
0000796da41d846f  pop r11
0000796da41d8471  pop r10
0000796da41d8473  pop r9
0000796da41d8475  pop r8
0000796da41d8477  pop rsi
0000796da41d8478  pop rdi
0000796da41d8479  pop rdx
0000796da41d847a  pop rcx
0000796da41d847b  pop rax
0000796da41d847c  add rsp, 0x08
0000796da41d8480  jmp 0x0000796DA41D34F4
0000796da41d8485  sub rsp, 0x08
0000796da41d8489  push rax
0000796da41d848a  push rcx
0000796da41d848b  push rdx
0000796da41d848c  push rdi
0000796da41d848d  push rsi
0000796da41d848e  push r8
0000796da41d8490  push r9
0000796da41d8492  push r10
0000796da41d8494  push r11
0000796da41d8496  sub rsp, 0xF0
0000796da41d849d  vmovaps [rsp], xmm0
0000796da41d84a2  vmovaps [rsp+0x10], xmm1
0000796da41d84a8  vmovaps [rsp+0x20], xmm2
0000796da41d84ae  vmovaps [rsp+0x30], xmm3
0000796da41d84b4  vmovaps [rsp+0x40], xmm4
0000796da41d84ba  vmovaps [rsp+0x50], xmm5
0000796da41d84c0  vmovaps [rsp+0x60], xmm6
0000796da41d84c6  vmovaps [rsp+0x70], xmm7
0000796da41d84cc  vmovaps [rsp+0x80], xmm8
0000796da41d84d5  vmovaps [rsp+0x90], xmm9
0000796da41d84de  vmovaps [rsp+0xA0], xmm10
0000796da41d84e7  vmovaps [rsp+0xB0], xmm11
0000796da41d84f0  vmovaps [rsp+0xC0], xmm12
0000796da41d84f9  vmovaps [rsp+0xD0], xmm13
0000796da41d8502  vmovaps [rsp+0xE0], xmm15
0000796da41d850b  sub rsp, 0x30
0000796da41d850f  movaps [rsp], xmm14
0000796da41d8514  movaps [rsp+0x10], xmm12
0000796da41d851a  movaps [rsp+0x20], xmm9
0000796da41d8520  lea rdi, [rsp]
0000796da41d8524  mov esi, 0x00
0000796da41d8529  mov rax, 0x5E26CB66A530
0000796da41d8533  call rax
0000796da41d8535  movaps xmm14, [rsp]
0000796da41d853a  add rsp, 0x30
0000796da41d853e  vmovaps xmm0, [rsp]
0000796da41d8543  vmovaps xmm1, [rsp+0x10]
0000796da41d8549  vmovaps xmm2, [rsp+0x20]
0000796da41d854f  vmovaps xmm3, [rsp+0x30]
0000796da41d8555  vmovaps xmm4, [rsp+0x40]
0000796da41d855b  vmovaps xmm5, [rsp+0x50]
0000796da41d8561  vmovaps xmm6, [rsp+0x60]
0000796da41d8567  vmovaps xmm7, [rsp+0x70]
0000796da41d856d  vmovaps xmm8, [rsp+0x80]
0000796da41d8576  vmovaps xmm9, [rsp+0x90]
0000796da41d857f  vmovaps xmm10, [rsp+0xA0]
0000796da41d8588  vmovaps xmm11, [rsp+0xB0]
0000796da41d8591  vmovaps xmm12, [rsp+0xC0]
0000796da41d859a  vmovaps xmm13, [rsp+0xD0]
0000796da41d85a3  vmovaps xmm15, [rsp+0xE0]
0000796da41d85ac  add rsp, 0xF0
0000796da41d85b3  pop r11
0000796da41d85b5  pop r10
0000796da41d85b7  pop r9
0000796da41d85b9  pop r8
0000796da41d85bb  pop rsi
0000796da41d85bc  pop rdi
0000796da41d85bd  pop rdx
0000796da41d85be  pop rcx
0000796da41d85bf  pop rax
0000796da41d85c0  add rsp, 0x08
0000796da41d85c4  jmp 0x0000796DA41D350F
0000796da41d85c9  sub rsp, 0x08
0000796da41d85cd  push rax
0000796da41d85ce  push rcx
0000796da41d85cf  push rdx
0000796da41d85d0  push rdi
0000796da41d85d1  push rsi
0000796da41d85d2  push r8
0000796da41d85d4  push r9
0000796da41d85d6  push r10
0000796da41d85d8  push r11
0000796da41d85da  sub rsp, 0xF0
0000796da41d85e1  vmovaps [rsp], xmm0
0000796da41d85e6  vmovaps [rsp+0x10], xmm1
0000796da41d85ec  vmovaps [rsp+0x20], xmm2
0000796da41d85f2  vmovaps [rsp+0x30], xmm3
0000796da41d85f8  vmovaps [rsp+0x40], xmm4
0000796da41d85fe  vmovaps [rsp+0x50], xmm5
0000796da41d8604  vmovaps [rsp+0x60], xmm6
0000796da41d860a  vmovaps [rsp+0x70], xmm7
0000796da41d8610  vmovaps [rsp+0x80], xmm8
0000796da41d8619  vmovaps [rsp+0x90], xmm9
0000796da41d8622  vmovaps [rsp+0xA0], xmm10
0000796da41d862b  vmovaps [rsp+0xB0], xmm11
0000796da41d8634  vmovaps [rsp+0xC0], xmm12
0000796da41d863d  vmovaps [rsp+0xD0], xmm14
0000796da41d8646  vmovaps [rsp+0xE0], xmm15
0000796da41d864f  sub rsp, 0x30
0000796da41d8653  movaps [rsp], xmm13
0000796da41d8658  movaps [rsp+0x10], xmm8
0000796da41d865e  movaps [rsp+0x20], xmm15
0000796da41d8664  lea rdi, [rsp]
0000796da41d8668  mov esi, 0x00
0000796da41d866d  mov rax, 0x5E26CB66A530
0000796da41d8677  call rax
0000796da41d8679  movaps xmm13, [rsp]
0000796da41d867e  add rsp, 0x30
0000796da41d8682  vmovaps xmm0, [rsp]
0000796da41d8687  vmovaps xmm1, [rsp+0x10]
0000796da41d868d  vmovaps xmm2, [rsp+0x20]
0000796da41d8693  vmovaps xmm3, [rsp+0x30]
0000796da41d8699  vmovaps xmm4, [rsp+0x40]
0000796da41d869f  vmovaps xmm5, [rsp+0x50]
0000796da41d86a5  vmovaps xmm6, [rsp+0x60]
0000796da41d86ab  vmovaps xmm7, [rsp+0x70]
0000796da41d86b1  vmovaps xmm8, [rsp+0x80]
0000796da41d86ba  vmovaps xmm9, [rsp+0x90]
0000796da41d86c3  vmovaps xmm10, [rsp+0xA0]
0000796da41d86cc  vmovaps xmm11, [rsp+0xB0]
0000796da41d86d5  vmovaps xmm12, [rsp+0xC0]
0000796da41d86de  vmovaps xmm14, [rsp+0xD0]
0000796da41d86e7  vmovaps xmm15, [rsp+0xE0]
0000796da41d86f0  add rsp, 0xF0
0000796da41d86f7  pop r11
0000796da41d86f9  pop r10
0000796da41d86fb  pop r9
0000796da41d86fd  pop r8
0000796da41d86ff  pop rsi
0000796da41d8700  pop rdi
0000796da41d8701  pop rdx
0000796da41d8702  pop rcx
0000796da41d8703  pop rax
0000796da41d8704  add rsp, 0x08
0000796da41d8708  jmp 0x0000796DA41D3532
0000796da41d870d  sub rsp, 0x08
0000796da41d8711  push rax
0000796da41d8712  push rcx
0000796da41d8713  push rdx
0000796da41d8714  push rdi
0000796da41d8715  push rsi
0000796da41d8716  push r8
0000796da41d8718  push r9
0000796da41d871a  push r10
0000796da41d871c  push r11
0000796da41d871e  sub rsp, 0xF0
0000796da41d8725  vmovaps [rsp], xmm0
0000796da41d872a  vmovaps [rsp+0x10], xmm1
0000796da41d8730  vmovaps [rsp+0x20], xmm2
0000796da41d8736  vmovaps [rsp+0x30], xmm3
0000796da41d873c  vmovaps [rsp+0x40], xmm4
0000796da41d8742  vmovaps [rsp+0x50], xmm5
0000796da41d8748  vmovaps [rsp+0x60], xmm6
0000796da41d874e  vmovaps [rsp+0x70], xmm7
0000796da41d8754  vmovaps [rsp+0x80], xmm8
0000796da41d875d  vmovaps [rsp+0x90], xmm9
0000796da41d8766  vmovaps [rsp+0xA0], xmm10
0000796da41d876f  vmovaps [rsp+0xB0], xmm11
0000796da41d8778  vmovaps [rsp+0xC0], xmm12
0000796da41d8781  vmovaps [rsp+0xD0], xmm13
0000796da41d878a  vmovaps [rsp+0xE0], xmm14
0000796da41d8793  sub rsp, 0x30
0000796da41d8797  movaps [rsp], xmm15
0000796da41d879c  movaps [rsp+0x10], xmm1
0000796da41d87a1  movaps [rsp+0x20], xmm10
0000796da41d87a7  lea rdi, [rsp]
0000796da41d87ab  mov esi, 0x00
0000796da41d87b0  mov rax, 0x5E26CB66A530
0000796da41d87ba  call rax
0000796da41d87bc  movaps xmm15, [rsp]
0000796da41d87c1  add rsp, 0x30
0000796da41d87c5  vmovaps xmm0, [rsp]
0000796da41d87ca  vmovaps xmm1, [rsp+0x10]
0000796da41d87d0  vmovaps xmm2, [rsp+0x20]
0000796da41d87d6  vmovaps xmm3, [rsp+0x30]
0000796da41d87dc  vmovaps xmm4, [rsp+0x40]
0000796da41d87e2  vmovaps xmm5, [rsp+0x50]
0000796da41d87e8  vmovaps xmm6, [rsp+0x60]
0000796da41d87ee  vmovaps xmm7, [rsp+0x70]
0000796da41d87f4  vmovaps xmm8, [rsp+0x80]
0000796da41d87fd  vmovaps xmm9, [rsp+0x90]
0000796da41d8806  vmovaps xmm10, [rsp+0xA0]
0000796da41d880f  vmovaps xmm11, [rsp+0xB0]
0000796da41d8818  vmovaps xmm12, [rsp+0xC0]
0000796da41d8821  vmovaps xmm13, [rsp+0xD0]
0000796da41d882a  vmovaps xmm14, [rsp+0xE0]
0000796da41d8833  add rsp, 0xF0
0000796da41d883a  pop r11
0000796da41d883c  pop r10
0000796da41d883e  pop r9
0000796da41d8840  pop r8
0000796da41d8842  pop rsi
0000796da41d8843  pop rdi
0000796da41d8844  pop rdx
0000796da41d8845  pop rcx
0000796da41d8846  pop rax
0000796da41d8847  add rsp, 0x08
0000796da41d884b  jmp 0x0000796DA41D3555
0000796da41d8850  sub rsp, 0x08
0000796da41d8854  push rax
0000796da41d8855  push rcx
0000796da41d8856  push rdx
0000796da41d8857  push rdi
0000796da41d8858  push rsi
0000796da41d8859  push r8
0000796da41d885b  push r9
0000796da41d885d  push r10
0000796da41d885f  push r11
0000796da41d8861  sub rsp, 0xF0
0000796da41d8868  vmovaps [rsp], xmm0
0000796da41d886d  vmovaps [rsp+0x10], xmm2
0000796da41d8873  vmovaps [rsp+0x20], xmm3
0000796da41d8879  vmovaps [rsp+0x30], xmm4
0000796da41d887f  vmovaps [rsp+0x40], xmm5
0000796da41d8885  vmovaps [rsp+0x50], xmm6
0000796da41d888b  vmovaps [rsp+0x60], xmm7
0000796da41d8891  vmovaps [rsp+0x70], xmm8
0000796da41d8897  vmovaps [rsp+0x80], xmm9
0000796da41d88a0  vmovaps [rsp+0x90], xmm10
0000796da41d88a9  vmovaps [rsp+0xA0], xmm11
0000796da41d88b2  vmovaps [rsp+0xB0], xmm12
0000796da41d88bb  vmovaps [rsp+0xC0], xmm13
0000796da41d88c4  vmovaps [rsp+0xD0], xmm14
0000796da41d88cd  vmovaps [rsp+0xE0], xmm15
0000796da41d88d6  sub rsp, 0x30
0000796da41d88da  movaps [rsp], xmm1
0000796da41d88de  movaps [rsp+0x10], xmm7
0000796da41d88e3  movaps [rsp+0x20], xmm11
0000796da41d88e9  lea rdi, [rsp]
0000796da41d88ed  mov esi, 0x00
0000796da41d88f2  mov rax, 0x5E26CB66A530
0000796da41d88fc  call rax
0000796da41d88fe  movaps xmm1, [rsp]
0000796da41d8902  add rsp, 0x30
0000796da41d8906  vmovaps xmm0, [rsp]
0000796da41d890b  vmovaps xmm2, [rsp+0x10]
0000796da41d8911  vmovaps xmm3, [rsp+0x20]
0000796da41d8917  vmovaps xmm4, [rsp+0x30]
0000796da41d891d  vmovaps xmm5, [rsp+0x40]
0000796da41d8923  vmovaps xmm6, [rsp+0x50]
0000796da41d8929  vmovaps xmm7, [rsp+0x60]
0000796da41d892f  vmovaps xmm8, [rsp+0x70]
0000796da41d8935  vmovaps xmm9, [rsp+0x80]
0000796da41d893e  vmovaps xmm10, [rsp+0x90]
0000796da41d8947  vmovaps xmm11, [rsp+0xA0]
0000796da41d8950  vmovaps xmm12, [rsp+0xB0]
0000796da41d8959  vmovaps xmm13, [rsp+0xC0]
0000796da41d8962  vmovaps xmm14, [rsp+0xD0]
0000796da41d896b  vmovaps xmm15, [rsp+0xE0]
0000796da41d8974  add rsp, 0xF0
0000796da41d897b  pop r11
0000796da41d897d  pop r10
0000796da41d897f  pop r9
0000796da41d8981  pop r8
0000796da41d8983  pop rsi
0000796da41d8984  pop rdi
0000796da41d8985  pop rdx
0000796da41d8986  pop rcx
0000796da41d8987  pop rax
0000796da41d8988  add rsp, 0x08
0000796da41d898c  jmp 0x0000796DA41D3576
0000796da41d8991  call 0x0000796DA400D600
0000796da41d8996  jmp 0x0000796DA41D3589
0000796da41d899b  call 0x0000796DA400C380
0000796da41d89a0  jmp 0x0000796DA41D3594
0000796da41d89a5  call 0x0000796DA400E880
0000796da41d89aa  jmp 0x0000796DA41D359F
0000796da41d89af  call 0x0000796DA3FFF540
0000796da41d89b4  jmp 0x0000796DA41D35AA
0000796da41d89b9  int3
0000796da41d89ba  nop [rax+rax*1], ax
0000796da41d89c0  mov rax, [r15+0x40]
0000796da41d89c4  mov r14, [r15+0x58]
0000796da41d89c8  lea r12, [rax+r14*1]
0000796da41d89cc  movaps xmm1, [r15+0x1D0]
0000796da41d89d4  vmovaps [rsp+0x10], xmm1
0000796da41d89da  vmovaps xmm15, [rsp+0x10]
0000796da41d89e0  por xmm1, xmm15
0000796da41d89e5  movaps xmm14, [r15+0x1A0]
0000796da41d89ed  vmovaps [rsp+0x10], xmm14
0000796da41d89f3  vmovaps xmm13, [rsp+0x10]
0000796da41d89f9  por xmm14, xmm13
0000796da41d89fe  lea rax, [r12+0x30]
0000796da41d8a03  mov r11, [r13+rax*1]
0000796da41d8a08  lea rax, [r12+0x38]
0000796da41d8a0d  mov r10, [r13+rax*1]
0000796da41d8a12  movq xmm13, r11
0000796da41d8a17  movq xmm12, r10
0000796da41d8a1c  movq xmm13, xmm13
0000796da41d8a21  vmovaps [rsp+0x10], xmm13
0000796da41d8a27  movq xmm13, xmm13
0000796da41d8a2c  movaps [r15+0x130], xmm13
0000796da41d8a34  movq xmm12, xmm12
0000796da41d8a39  vmovaps [rsp+0x20], xmm12
0000796da41d8a3f  movq xmm12, xmm12
0000796da41d8a44  movaps [r15+0x280], xmm12
0000796da41d8a4c  movaps xmm13, [r15+0x270]
0000796da41d8a54  vmovaps [rsp+0x30], xmm13
0000796da41d8a5a  vmovaps xmm12, [rsp+0x30]
0000796da41d8a60  por xmm13, xmm12
0000796da41d8a65  lea rax, [r12+0x20]
0000796da41d8a6a  mov r11, [r13+rax*1]
0000796da41d8a6f  lea rax, [r12+0x28]
0000796da41d8a74  mov r10, [r13+rax*1]
0000796da41d8a79  movq xmm12, r11
0000796da41d8a7e  movq xmm11, r10
0000796da41d8a83  movq xmm12, xmm12
0000796da41d8a88  vmovaps [rsp+0x30], xmm12
0000796da41d8a8e  movq xmm12, xmm12
0000796da41d8a93  movaps [r15+0x150], xmm12
0000796da41d8a9b  movq xmm11, xmm11
0000796da41d8aa0  vmovaps [rsp+0x40], xmm11
0000796da41d8aa6  movq xmm11, xmm11
0000796da41d8aab  movaps [r15+0x140], xmm11
0000796da41d8ab3  lea rax, [r12+0x10]
0000796da41d8ab8  mov r11, [r13+rax*1]
0000796da41d8abd  lea rax, [r12+0x18]
0000796da41d8ac2  mov r10, [r13+rax*1]
0000796da41d8ac7  movq xmm12, r11
0000796da41d8acc  movq xmm11, r10
0000796da41d8ad1  movq xmm12, xmm12
0000796da41d8ad6  vmovaps [rsp+0x50], xmm12
0000796da41d8adc  movq xmm12, xmm12
0000796da41d8ae1  movaps [r15+0x170], xmm12
0000796da41d8ae9  movq xmm11, xmm11
0000796da41d8aee  vmovaps [rsp+0x60], xmm11
0000796da41d8af4  movq xmm11, xmm11
0000796da41d8af9  movaps [r15+0x160], xmm11
0000796da41d8b01  mov rax, [r13+r12*1]
0000796da41d8b06  vmovq xmm12, rax
0000796da41d8b0b  vpbroadcastq xmm12, xmm12
0000796da41d8b10  lea rax, [r12+0x08]
0000796da41d8b15  mov r12, [r13+rax*1]
0000796da41d8b1a  movq xmm11, r12
0000796da41d8b1f  movaps [r15+0x230], xmm11
0000796da41d8b27  mov rax, [r15+0xF8]
0000796da41d8b2e  lea r12, [rax+0x50]
0000796da41d8b32  movups xmm11, [r13+r12*1]
0000796da41d8b38  lea r12, [rax+0x60]
0000796da41d8b3c  movups xmm10, [r13+r12*1]
0000796da41d8b42  lea r12, [rax+0x30]
0000796da41d8b46  movups xmm9, [r13+r12*1]
0000796da41d8b4c  mov r12, [r15+0x50]
0000796da41d8b50  lea r11, [r12+r14*1]
0000796da41d8b54  mov [r15+0x60], r11
0000796da41d8b58  lea r12, [r14+0x40]
0000796da41d8b5c  mov [r15+0x58], r12
0000796da41d8b60  movaps xmm8, xmm12
0000796da41d8b64  mulpd xmm8, xmm15
0000796da41d8b69  vcmppd xmm7, xmm8, xmm8, 0x03
0000796da41d8b6f  ptest xmm7, xmm7
0000796da41d8b74  jnz 0x0000796DA41D9997
0000796da41d8b7a  movq xmm15, qword ptr [r15+0x230]
0000796da41d8b83  vmovaps [rsp+0x70], xmm15
0000796da41d8b89  vpermilpd xmm15, xmm15, 0x00
0000796da41d8b8f  movaps xmm7, xmm9
0000796da41d8b93  mulpd xmm7, xmm15
0000796da41d8b98  vcmppd xmm6, xmm7, xmm7, 0x03
0000796da41d8b9d  ptest xmm6, xmm6
0000796da41d8ba2  jnz 0x0000796DA41D9ADB
0000796da41d8ba8  vxorps xmm15, xmm15, xmm15
0000796da41d8bad  vpbroadcastq xmm15, xmm15
0000796da41d8bb2  movaps xmm9, xmm12
0000796da41d8bb6  mulpd xmm9, xmm10
0000796da41d8bbb  vcmppd xmm6, xmm9, xmm9, 0x03
0000796da41d8bc1  ptest xmm6, xmm6
0000796da41d8bc6  jnz 0x0000796DA41D9C1D
0000796da41d8bcc  movaps xmm10, xmm12
0000796da41d8bd0  mulpd xmm10, xmm11
0000796da41d8bd5  vcmppd xmm6, xmm10, xmm10, 0x03
0000796da41d8bdb  ptest xmm6, xmm6
0000796da41d8be0  jnz 0x0000796DA41D9D61
0000796da41d8be6  movaps xmm11, [r15+0x1F0]
0000796da41d8bee  movaps xmm6, xmm12
0000796da41d8bf2  mulpd xmm6, xmm11
0000796da41d8bf7  vcmppd xmm5, xmm6, xmm6, 0x03
0000796da41d8bfc  ptest xmm5, xmm5
0000796da41d8c01  jnz 0x0000796DA41D9EA5
0000796da41d8c07  movaps xmm12, [r15+0x2A0]
0000796da41d8c0f  vmovaps [rsp+0x80], xmm12
0000796da41d8c18  vmovaps xmm11, [rsp+0x80]
0000796da41d8c21  por xmm12, xmm11
0000796da41d8c26  movaps xmm11, [r15+0x250]
0000796da41d8c2e  vmovaps [rsp+0x80], xmm11
0000796da41d8c37  vmovaps xmm5, [rsp+0x80]
0000796da41d8c40  por xmm11, xmm5
0000796da41d8c45  vmovaps xmm4, [rsp+0x70]
0000796da41d8c4b  vpermilpd xmm4, xmm4, 0x00
0000796da41d8c51  movaps xmm3, xmm5
0000796da41d8c54  mulpd xmm3, xmm4
0000796da41d8c58  vcmppd xmm2, xmm3, xmm3, 0x03
0000796da41d8c5d  ptest xmm2, xmm2
0000796da41d8c62  jnz 0x0000796DA41D9FE7
0000796da41d8c68  mov [rsp+0x80], rax
0000796da41d8c70  xor eax, eax
0000796da41d8c72  mov r14d, 0x200
0000796da41d8c78  cmp r12, r14
0000796da41d8c7b  cmc
0000796da41d8c7c  lahf
0000796da41d8c7d  seto al
0000796da41d8c80  mov [r15+0x108], eax
0000796da41d8c87  movaps xmm5, xmm8
0000796da41d8c8b  addpd xmm5, xmm15
0000796da41d8c90  vcmppd xmm4, xmm5, xmm5, 0x03
0000796da41d8c95  ptest xmm4, xmm4
0000796da41d8c9a  jnz 0x0000796DA41DA127
0000796da41d8ca0  movaps xmm8, [r15+0x1B0]
0000796da41d8ca8  movaps xmm4, xmm9
0000796da41d8cac  addpd xmm4, xmm8
0000796da41d8cb1  vcmppd xmm2, xmm4, xmm4, 0x03
0000796da41d8cb6  ptest xmm2, xmm2
0000796da41d8cbb  jnz 0x0000796DA41DA269
0000796da41d8cc1  movaps xmm9, xmm10
0000796da41d8cc5  addpd xmm9, xmm8
0000796da41d8cca  vcmppd xmm2, xmm9, xmm9, 0x03
0000796da41d8cd0  ptest xmm2, xmm2
0000796da41d8cd5  jnz 0x0000796DA41DA3AB
0000796da41d8cdb  movaps xmm10, [r15+0x2F0]
0000796da41d8ce3  vmovaps [rsp+0x90], xmm10
0000796da41d8cec  vmovaps xmm8, [rsp+0x90]
0000796da41d8cf5  por xmm10, xmm8
0000796da41d8cfa  movaps xmm8, [r15+0x2E0]
0000796da41d8d02  vmovaps [rsp+0x90], xmm8
0000796da41d8d0b  vmovaps xmm2, [rsp+0x90]
0000796da41d8d14  por xmm8, xmm2
0000796da41d8d19  movaps xmm2, [r15+0x2D0]
0000796da41d8d21  vmovaps [rsp+0x90], xmm2
0000796da41d8d2a  vmovaps [rsp+0xA0], xmm1
0000796da41d8d33  vmovaps xmm1, [rsp+0x90]
0000796da41d8d3c  por xmm2, xmm1
0000796da41d8d40  movaps xmm1, [r15+0x200]
0000796da41d8d48  vmovaps [rsp+0x90], xmm1
0000796da41d8d51  vmovaps [rsp+0xB0], xmm15
0000796da41d8d5a  vmovaps xmm15, [rsp+0x90]
0000796da41d8d63  por xmm1, xmm15
0000796da41d8d68  movaps xmm15, [r15+0x1C0]
0000796da41d8d70  vmovaps [rsp+0x90], xmm15
0000796da41d8d79  vmovaps [rsp+0xC0], xmm1
0000796da41d8d82  vmovaps xmm1, [rsp+0x90]
0000796da41d8d8b  por xmm15, xmm1
0000796da41d8d90  movaps xmm1, [r15+0x190]
0000796da41d8d98  vmovaps [rsp+0x90], xmm1
0000796da41d8da1  vmovaps [rsp+0xD0], xmm15
0000796da41d8daa  vmovaps xmm15, [rsp+0x90]
0000796da41d8db3  por xmm1, xmm15
0000796da41d8db8  movaps xmm15, [r15+0x300]
0000796da41d8dc0  vmovaps [rsp+0x90], xmm15
0000796da41d8dc9  vmovaps [rsp+0xE0], xmm1
0000796da41d8dd2  vmovaps xmm1, [rsp+0x90]
0000796da41d8ddb  por xmm15, xmm1
0000796da41d8de0  mov rax, [rsp+0x80]
0000796da41d8de8  lea r14, [rax+0xA0]
0000796da41d8def  movups xmm1, [r13+r14*1]
0000796da41d8df5  lea r14, [rax+0xB0]
0000796da41d8dfc  vmovaps [rsp+0x80], xmm1
0000796da41d8e05  movups xmm1, [r13+r14*1]
0000796da41d8e0b  vmovaps [rsp+0x90], xmm1
0000796da41d8e14  vmovaps [rsp+0xF0], xmm15
0000796da41d8e1d  vmovaps xmm15, [rsp+0xB0]
0000796da41d8e26  vmovaps [rsp+0xB0], xmm14
0000796da41d8e2f  movaps xmm1, xmm6
0000796da41d8e32  addpd xmm1, xmm15
0000796da41d8e37  vcmppd xmm14, xmm1, xmm1, 0x03
0000796da41d8e3c  ptest xmm14, xmm14
0000796da41d8e42  jnz 0x0000796DA41DA503
0000796da41d8e48  lea r14, [rax+0xF0]
0000796da41d8e4f  movups xmm15, [r13+r14*1]
0000796da41d8e55  movaps xmm14, xmm4
0000796da41d8e59  addpd xmm14, xmm3
0000796da41d8e5e  vcmppd xmm6, xmm14, xmm14, 0x03
0000796da41d8e64  ptest xmm6, xmm6
0000796da41d8e69  jnz 0x0000796DA41DA64E
0000796da41d8e6f  movaps xmm6, xmm9
0000796da41d8e73  addpd xmm6, xmm7
0000796da41d8e77  vcmppd xmm4, xmm6, xmm6, 0x03
0000796da41d8e7c  ptest xmm4, xmm4
0000796da41d8e81  jnz 0x0000796DA41DA790
0000796da41d8e87  vmovaps xmm9, [rsp+0x70]
0000796da41d8e8d  vpermilpd xmm9, xmm9, 0x00
0000796da41d8e93  vmovaps xmm4, [rsp+0x90]
0000796da41d8e9c  movaps xmm7, xmm4
0000796da41d8e9f  mulpd xmm7, xmm9
0000796da41d8ea4  vcmppd xmm3, xmm7, xmm7, 0x03
0000796da41d8ea9  ptest xmm3, xmm3
0000796da41d8eae  jnz 0x0000796DA41DA8D1
0000796da41d8eb4  vmovaps xmm9, [rsp+0x50]
0000796da41d8eba  vpermilpd xmm9, xmm9, 0x00
0000796da41d8ec0  movaps xmm4, xmm15
0000796da41d8ec4  mulpd xmm4, xmm9
0000796da41d8ec9  vcmppd xmm3, xmm4, xmm4, 0x03
0000796da41d8ece  ptest xmm3, xmm3
0000796da41d8ed3  jnz 0x0000796DA41DAA12
0000796da41d8ed9  lea r14, [rax+0xE0]
0000796da41d8ee0  movups xmm15, [r13+r14*1]
0000796da41d8ee6  vmovaps xmm9, [rsp+0x70]
0000796da41d8eec  vpermilpd xmm9, xmm9, 0x00
0000796da41d8ef2  vmovaps [rsp+0x70], xmm1
0000796da41d8ef8  vmovaps xmm1, [rsp+0x80]
0000796da41d8f01  vmovaps [rsp+0x80], xmm15
0000796da41d8f0a  movaps xmm3, xmm1
0000796da41d8f0d  mulpd xmm3, xmm9
0000796da41d8f12  vcmppd xmm15, xmm3, xmm3, 0x03
0000796da41d8f17  ptest xmm15, xmm15
0000796da41d8f1d  jnz 0x0000796DA41DAB5E
0000796da41d8f23  vmovaps xmm1, [rsp+0xF0]
0000796da41d8f2c  vmovaps xmm15, [rsp+0xF0]
0000796da41d8f35  por xmm1, xmm15
0000796da41d8f3a  movaps [r15+0x300], xmm1
0000796da41d8f42  vmovaps xmm15, [rsp+0xE0]
0000796da41d8f4b  vmovaps xmm9, [rsp+0xE0]
0000796da41d8f54  por xmm15, xmm9
0000796da41d8f59  movaps [r15+0x190], xmm15
0000796da41d8f61  vmovaps xmm9, [rsp+0x50]
0000796da41d8f67  vpermilpd xmm9, xmm9, 0x00
0000796da41d8f6d  vmovaps [rsp+0x90], xmm1
0000796da41d8f76  vmovaps [rsp+0xE0], xmm15
0000796da41d8f7f  vmovaps xmm15, [rsp+0x80]
0000796da41d8f88  vmovaps [rsp+0x80], xmm14
0000796da41d8f91  movaps xmm1, xmm15
0000796da41d8f95  mulpd xmm1, xmm9
0000796da41d8f9a  vcmppd xmm14, xmm1, xmm1, 0x03
0000796da41d8f9f  ptest xmm14, xmm14
0000796da41d8fa5  jnz 0x0000796DA41DAC9F
0000796da41d8fab  lea r14, [rax+0x90]
0000796da41d8fb2  movups xmm15, [r13+r14*1]
0000796da41d8fb8  vmovaps xmm14, [rsp+0xD0]
0000796da41d8fc1  vmovaps xmm9, [rsp+0xD0]
0000796da41d8fca  por xmm14, xmm9
0000796da41d8fcf  movaps [r15+0x1C0], xmm14
0000796da41d8fd7  vmovaps xmm9, [rsp+0xC0]
0000796da41d8fe0  vmovaps [rsp+0xD0], xmm1
0000796da41d8fe9  vmovaps xmm1, [rsp+0xC0]
0000796da41d8ff2  por xmm9, xmm1
0000796da41d8ff7  movaps [r15+0x200], xmm9
0000796da41d8fff  vmovaps [rsp+0xC0], xmm2
0000796da41d9008  vmovaps xmm1, [rsp+0xC0]
0000796da41d9011  por xmm2, xmm1
0000796da41d9015  movaps [r15+0x2D0], xmm2
0000796da41d901d  vmovaps [rsp+0xC0], xmm8
0000796da41d9026  vmovaps xmm1, [rsp+0xC0]
0000796da41d902f  por xmm8, xmm1
0000796da41d9034  movaps [r15+0x2E0], xmm8
0000796da41d903c  vmovaps [rsp+0xC0], xmm15
0000796da41d9045  movaps xmm1, xmm5
0000796da41d9048  addpd xmm1, xmm7
0000796da41d904c  vcmppd xmm15, xmm1, xmm1, 0x03
0000796da41d9051  ptest xmm15, xmm15
0000796da41d9057  jnz 0x0000796DA41DADEB
0000796da41d905d  vmovaps xmm15, [rsp+0x50]
0000796da41d9063  vpermilpd xmm15, xmm15, 0x00
0000796da41d9069  vmovaps xmm5, [rsp+0xC0]
0000796da41d9072  vmovaps [rsp+0xC0], xmm1
0000796da41d907b  movaps xmm7, xmm5
0000796da41d907e  mulpd xmm7, xmm15
0000796da41d9083  vcmppd xmm1, xmm7, xmm7, 0x03
0000796da41d9088  ptest xmm1, xmm1
0000796da41d908d  jnz 0x0000796DA41DAF2B
0000796da41d9093  lea r14, [rax+0x80]
0000796da41d909a  movups xmm1, [r13+r14*1]
0000796da41d90a0  vmovaps xmm5, [rsp+0x70]
0000796da41d90a6  vmovaps [rsp+0x70], xmm1
0000796da41d90ac  movaps xmm15, xmm5
0000796da41d90b0  addpd xmm15, xmm3
0000796da41d90b5  vcmppd xmm1, xmm15, xmm15, 0x03
0000796da41d90bb  ptest xmm1, xmm1
0000796da41d90c0  jnz 0x0000796DA41DB076
0000796da41d90c6  vmovaps xmm5, [rsp+0x80]
0000796da41d90cf  movaps xmm1, xmm5
0000796da41d90d2  addpd xmm1, xmm4
0000796da41d90d6  vcmppd xmm3, xmm1, xmm1, 0x03
0000796da41d90db  ptest xmm3, xmm3
0000796da41d90e0  jnz 0x0000796DA41DB1B8
0000796da41d90e6  vmovaps [rsp+0x80], xmm10
0000796da41d90ef  vmovaps xmm5, [rsp+0x80]
0000796da41d90f8  por xmm10, xmm5
0000796da41d90fd  movaps [r15+0x2F0], xmm10
0000796da41d9105  vmovaps xmm5, [rsp+0x50]
0000796da41d910b  vpermilpd xmm5, xmm5, 0x00
0000796da41d9111  vmovaps xmm3, [rsp+0x70]
0000796da41d9117  vmovaps [rsp+0x50], xmm1
0000796da41d911d  movaps xmm4, xmm3
0000796da41d9120  mulpd xmm4, xmm5
0000796da41d9124  vcmppd xmm1, xmm4, xmm4, 0x03
0000796da41d9129  ptest xmm1, xmm1
0000796da41d912e  jnz 0x0000796DA41DB2F8
0000796da41d9134  lea r14, [rax+0xD0]
0000796da41d913b  movups xmm1, [r13+r14*1]
0000796da41d9141  vmovaps xmm3, [rsp+0xD0]
0000796da41d914a  vmovaps [rsp+0x70], xmm1
0000796da41d9150  movaps xmm5, xmm6
0000796da41d9153  addpd xmm5, xmm3
0000796da41d9157  vcmppd xmm1, xmm5, xmm5, 0x03
0000796da41d915c  ptest xmm1, xmm1
0000796da41d9161  jnz 0x0000796DA41DB442
0000796da41d9167  vmovaps xmm1, [rsp+0x60]
0000796da41d916d  vpermilpd xmm1, xmm1, 0x00
0000796da41d9173  movaps xmm6, xmm9
0000796da41d9177  mulpd xmm6, xmm1
0000796da41d917b  vcmppd xmm3, xmm6, xmm6, 0x03
0000796da41d9180  ptest xmm3, xmm3
0000796da41d9185  jnz 0x0000796DA41DB582
0000796da41d918b  movaps [r15+0x260], xmm6
0000796da41d9193  vxorps xmm1, xmm1, xmm1
0000796da41d9197  vpbroadcastq xmm1, xmm1
0000796da41d919c  movaps [r15+0x1B0], xmm1
0000796da41d91a4  vmovaps xmm1, [rsp+0x60]
0000796da41d91aa  vpermilpd xmm1, xmm1, 0x00
0000796da41d91b0  vmovaps xmm3, [rsp+0x70]
0000796da41d91b6  vmovaps [rsp+0x70], xmm15
0000796da41d91bc  movaps xmm9, xmm3
0000796da41d91c0  mulpd xmm9, xmm1
0000796da41d91c5  vcmppd xmm15, xmm9, xmm9, 0x03
0000796da41d91cb  ptest xmm15, xmm15
0000796da41d91d1  jnz 0x0000796DA41DB6C3
0000796da41d91d7  lea r14, [rax+0xC0]
0000796da41d91de  movups xmm1, [r13+r14*1]
0000796da41d91e4  vmovaps xmm3, [rsp+0xC0]
0000796da41d91ed  vmovaps [rsp+0x80], xmm1
0000796da41d91f6  movaps xmm15, xmm3
0000796da41d91fa  addpd xmm15, xmm7
0000796da41d91ff  vcmppd xmm1, xmm15, xmm15, 0x03
0000796da41d9205  ptest xmm1, xmm1
0000796da41d920a  jnz 0x0000796DA41DB80F
0000796da41d9210  vmovaps [rsp+0xC0], xmm13
0000796da41d9219  vmovaps xmm1, [rsp+0xC0]
0000796da41d9222  por xmm13, xmm1
0000796da41d9227  movaps [r15+0x270], xmm13
0000796da41d922f  vmovaps xmm1, [rsp+0xB0]
0000796da41d9238  vmovaps xmm7, [rsp+0xB0]
0000796da41d9241  por xmm1, xmm7
0000796da41d9245  movaps [r15+0x1A0], xmm1
0000796da41d924d  vmovaps xmm1, [rsp+0x60]
0000796da41d9253  vpermilpd xmm1, xmm1, 0x00
0000796da41d9259  vmovaps [rsp+0xB0], xmm1
0000796da41d9262  vmovaps xmm1, [rsp+0x80]
0000796da41d926b  vmovaps [rsp+0x80], xmm15
0000796da41d9274  vmovaps xmm15, [rsp+0xB0]
0000796da41d927d  vmovaps [rsp+0xB0], xmm14
0000796da41d9286  movaps xmm3, xmm1
0000796da41d9289  mulpd xmm3, xmm15
0000796da41d928e  vcmppd xmm14, xmm3, xmm3, 0x03
0000796da41d9293  ptest xmm14, xmm14
0000796da41d9299  jnz 0x0000796DA41DB951
0000796da41d929f  lea r14, [rax+0x20]
0000796da41d92a3  movups xmm1, [r13+r14*1]
0000796da41d92a9  movaps [r15+0x110], xmm1
0000796da41d92b1  vmovaps xmm14, [rsp+0x70]
0000796da41d92b7  vmovaps [rsp+0x70], xmm1
0000796da41d92bd  movaps xmm15, xmm14
0000796da41d92c1  addpd xmm15, xmm4
0000796da41d92c6  vcmppd xmm1, xmm15, xmm15, 0x03
0000796da41d92cc  ptest xmm1, xmm1
0000796da41d92d1  jnz 0x0000796DA41DBA9C
0000796da41d92d7  vmovaps xmm1, [rsp+0x60]
0000796da41d92dd  vpermilpd xmm1, xmm1, 0x00
0000796da41d92e3  movaps xmm14, xmm2
0000796da41d92e7  mulpd xmm14, xmm1
0000796da41d92ec  vcmppd xmm4, xmm14, xmm14, 0x03
0000796da41d92f2  ptest xmm4, xmm4
0000796da41d92f7  jnz 0x0000796DA41DBBDF
0000796da41d92fd  vmovaps xmm4, [rsp+0x50]
0000796da41d9303  movaps xmm1, xmm4
0000796da41d9306  addpd xmm1, xmm9
0000796da41d930b  vcmppd xmm2, xmm1, xmm1, 0x03
0000796da41d9310  ptest xmm2, xmm2
0000796da41d9315  jnz 0x0000796DA41DBD21
0000796da41d931b  vmovaps xmm9, [rsp+0x30]
0000796da41d9321  vpermilpd xmm9, xmm9, 0x00
0000796da41d9327  vmovaps xmm2, [rsp+0x70]
0000796da41d932d  vmovaps [rsp+0x50], xmm1
0000796da41d9333  movaps xmm4, xmm2
0000796da41d9336  mulpd xmm4, xmm9
0000796da41d933b  vcmppd xmm1, xmm4, xmm4, 0x03
0000796da41d9340  ptest xmm1, xmm1
0000796da41d9345  jnz 0x0000796DA41DBE62
0000796da41d934b  vmovaps xmm1, [rsp+0x30]
0000796da41d9351  vpermilpd xmm1, xmm1, 0x00
0000796da41d9357  vmovaps xmm2, [rsp+0x90]
0000796da41d9360  vmovaps [rsp+0x60], xmm15
0000796da41d9366  movaps xmm9, xmm2
0000796da41d936a  mulpd xmm9, xmm1
0000796da41d936f  vcmppd xmm15, xmm9, xmm9, 0x03
0000796da41d9375  ptest xmm15, xmm15
0000796da41d937b  jnz 0x0000796DA41DBFA3
0000796da41d9381  vmovaps xmm15, [rsp+0x80]
0000796da41d938a  movaps xmm1, xmm15
0000796da41d938e  addpd xmm1, xmm6
0000796da41d9392  vcmppd xmm2, xmm1, xmm1, 0x03
0000796da41d9397  ptest xmm2, xmm2
0000796da41d939c  jnz 0x0000796DA41DC0E5
0000796da41d93a2  movaps xmm15, xmm5
0000796da41d93a6  addpd xmm15, xmm3
0000796da41d93ab  vcmppd xmm6, xmm15, xmm15, 0x03
0000796da41d93b1  ptest xmm6, xmm6
0000796da41d93b6  jnz 0x0000796DA41DC226
0000796da41d93bc  vmovaps xmm6, [rsp+0x30]
0000796da41d93c2  vpermilpd xmm6, xmm6, 0x00
0000796da41d93c8  movaps xmm5, xmm8
0000796da41d93cc  mulpd xmm5, xmm6
0000796da41d93d0  vcmppd xmm3, xmm5, xmm5, 0x03
0000796da41d93d5  ptest xmm3, xmm3
0000796da41d93da  jnz 0x0000796DA41DC368
0000796da41d93e0  vmovaps xmm8, [rsp+0x30]
0000796da41d93e6  vpermilpd xmm8, xmm8, 0x00
0000796da41d93ec  movaps xmm6, xmm10
0000796da41d93f0  mulpd xmm6, xmm8
0000796da41d93f5  vcmppd xmm3, xmm6, xmm6, 0x03
0000796da41d93fa  ptest xmm3, xmm3
0000796da41d93ff  jnz 0x0000796DA41DC4A9
0000796da41d9405  vmovaps xmm8, [rsp+0x60]
0000796da41d940b  movaps xmm10, xmm8
0000796da41d940f  addpd xmm10, xmm14
0000796da41d9414  vcmppd xmm3, xmm10, xmm10, 0x03
0000796da41d941a  ptest xmm3, xmm3
0000796da41d941f  jnz 0x0000796DA41DC5EB
0000796da41d9425  vmovaps xmm8, [rsp+0x50]
0000796da41d942b  movaps xmm14, xmm8
0000796da41d942f  addpd xmm14, xmm4
0000796da41d9434  vcmppd xmm3, xmm14, xmm14, 0x03
0000796da41d943a  ptest xmm3, xmm3
0000796da41d943f  jnz 0x0000796DA41DC72F
0000796da41d9445  vmovaps xmm8, [rsp+0x40]
0000796da41d944b  vpermilpd xmm8, xmm8, 0x00
0000796da41d9451  movaps xmm4, xmm13
0000796da41d9455  mulpd xmm4, xmm8
0000796da41d945a  vcmppd xmm3, xmm4, xmm4, 0x03
0000796da41d945f  ptest xmm3, xmm3
0000796da41d9464  jnz 0x0000796DA41DC872
0000796da41d946a  movaps xmm13, xmm15
0000796da41d946e  addpd xmm13, xmm9
0000796da41d9473  vcmppd xmm8, xmm13, xmm13, 0x03
0000796da41d9479  ptest xmm8, xmm8
0000796da41d947f  jnz 0x0000796DA41DC9B4
0000796da41d9485  movaps xmm15, xmm1
0000796da41d9489  addpd xmm15, xmm5
0000796da41d948e  vcmppd xmm9, xmm15, xmm15, 0x03
0000796da41d9494  ptest xmm9, xmm9
0000796da41d949a  jnz 0x0000796DA41DCAF8
0000796da41d94a0  vmovaps [rsp+0x30], xmm11
0000796da41d94a6  vmovaps xmm1, [rsp+0x30]
0000796da41d94ac  por xmm11, xmm1
0000796da41d94b1  movaps [r15+0x250], xmm11
0000796da41d94b9  vmovaps [rsp+0x30], xmm12
0000796da41d94bf  vmovaps xmm1, [rsp+0x30]
0000796da41d94c5  por xmm12, xmm1
0000796da41d94ca  movaps [r15+0x2A0], xmm12
0000796da41d94d2  vmovaps xmm1, [rsp+0xA0]
0000796da41d94db  vmovaps xmm11, [rsp+0xA0]
0000796da41d94e4  por xmm1, xmm11
0000796da41d94e9  movaps [r15+0x1D0], xmm1
0000796da41d94f1  lea r14, [rax+0x40]
0000796da41d94f5  movups xmm1, [r13+r14*1]
0000796da41d94fb  movaps [r15+0x2C0], xmm1
0000796da41d9503  vmovaps xmm11, [rsp+0x40]
0000796da41d9509  vpermilpd xmm11, xmm11, 0x00
0000796da41d950f  vmovaps xmm8, [rsp+0xE0]
0000796da41d9518  movaps xmm9, xmm8
0000796da41d951c  mulpd xmm9, xmm11
0000796da41d9521  vcmppd xmm5, xmm9, xmm9, 0x03
0000796da41d9527  ptest xmm5, xmm5
0000796da41d952c  jnz 0x0000796DA41DCC44
0000796da41d9532  movaps xmm11, xmm10
0000796da41d9536  addpd xmm11, xmm6
0000796da41d953b  vcmppd xmm8, xmm11, xmm11, 0x03
0000796da41d9541  ptest xmm8, xmm8
0000796da41d9547  jnz 0x0000796DA41DCD88
0000796da41d954d  movaps xmm10, xmm14
0000796da41d9551  addpd xmm10, xmm4
0000796da41d9556  vcmppd xmm8, xmm10, xmm10, 0x03
0000796da41d955c  ptest xmm8, xmm8
0000796da41d9562  jnz 0x0000796DA41DCECB
0000796da41d9568  vmovaps xmm14, [rsp+0x40]
0000796da41d956e  vpermilpd xmm14, xmm14, 0x00
0000796da41d9574  movaps xmm8, xmm1
0000796da41d9578  mulpd xmm8, xmm14
0000796da41d957d  vcmppd xmm6, xmm8, xmm8, 0x03
0000796da41d9583  ptest xmm6, xmm6
0000796da41d9588  jnz 0x0000796DA41DD00E
0000796da41d958e  movaps xmm1, [r15+0x2B0]
0000796da41d9596  vmovaps xmm14, [rsp+0x40]
0000796da41d959c  vpermilpd xmm14, xmm14, 0x00
0000796da41d95a2  movaps xmm6, xmm1
0000796da41d95a5  mulpd xmm6, xmm14
0000796da41d95aa  vcmppd xmm5, xmm6, xmm6, 0x03
0000796da41d95af  ptest xmm5, xmm5
0000796da41d95b4  jnz 0x0000796DA41DD151
0000796da41d95ba  vmovaps xmm1, [rsp+0x10]
0000796da41d95c0  vpermilpd xmm1, xmm1, 0x00
0000796da41d95c6  movaps xmm14, xmm12
0000796da41d95ca  mulpd xmm14, xmm1
0000796da41d95cf  vcmppd xmm5, xmm14, xmm14, 0x03
0000796da41d95d5  ptest xmm5, xmm5
0000796da41d95da  jnz 0x0000796DA41DD292
0000796da41d95e0  movaps xmm1, xmm13
0000796da41d95e4  addpd xmm1, xmm9
0000796da41d95e9  vcmppd xmm12, xmm1, xmm1, 0x03
0000796da41d95ee  ptest xmm12, xmm12
0000796da41d95f4  jnz 0x0000796DA41DD3D5
0000796da41d95fa  vmovaps xmm13, [rsp+0x10]
0000796da41d9600  vpermilpd xmm13, xmm13, 0x00
0000796da41d9606  movaps xmm12, xmm7
0000796da41d960a  mulpd xmm12, xmm13
0000796da41d960f  vcmppd xmm9, xmm12, xmm12, 0x03
0000796da41d9615  ptest xmm9, xmm9
0000796da41d961b  jnz 0x0000796DA41DD517
0000796da41d9621  movaps xmm13, xmm15
0000796da41d9625  addpd xmm13, xmm8
0000796da41d962a  vcmppd xmm9, xmm13, xmm13, 0x03
0000796da41d9630  ptest xmm9, xmm9
0000796da41d9636  jnz 0x0000796DA41DD65A
0000796da41d963c  movaps xmm15, [r15+0x290]
0000796da41d9644  vmovaps xmm9, [rsp+0x10]
0000796da41d964a  vpermilpd xmm9, xmm9, 0x00
0000796da41d9650  movaps xmm8, xmm15
0000796da41d9654  mulpd xmm8, xmm9
0000796da41d9659  vcmppd xmm7, xmm8, xmm8, 0x03
0000796da41d965f  ptest xmm7, xmm7
0000796da41d9664  jnz 0x0000796DA41DD79E
0000796da41d966a  movaps xmm15, xmm11
0000796da41d966e  addpd xmm15, xmm6
0000796da41d9673  vcmppd xmm9, xmm15, xmm15, 0x03
0000796da41d9679  ptest xmm9, xmm9
0000796da41d967f  jnz 0x0000796DA41DD8E2
0000796da41d9685  movaps xmm11, [r15+0x1E0]
0000796da41d968d  vmovaps xmm9, [rsp+0x10]
0000796da41d9693  vpermilpd xmm9, xmm9, 0x00
0000796da41d9699  movaps xmm7, xmm11
0000796da41d969d  mulpd xmm7, xmm9
0000796da41d96a2  vcmppd xmm6, xmm7, xmm7, 0x03
0000796da41d96a7  ptest xmm6, xmm6
0000796da41d96ac  jnz 0x0000796DA41DDA25
0000796da41d96b2  movaps xmm11, xmm10
0000796da41d96b6  addpd xmm11, xmm14
0000796da41d96bb  vcmppd xmm9, xmm11, xmm11, 0x03
0000796da41d96c1  ptest xmm9, xmm9
0000796da41d96c7  jnz 0x0000796DA41DDB67
0000796da41d96cd  lea r14, [rax+0x70]
0000796da41d96d1  movups xmm14, [r13+r14*1]
0000796da41d96d7  movaps [r15+0x240], xmm14
0000796da41d96df  movaps xmm10, xmm1
0000796da41d96e3  addpd xmm10, xmm12
0000796da41d96e8  vcmppd xmm9, xmm10, xmm10, 0x03
0000796da41d96ee  ptest xmm9, xmm9
0000796da41d96f4  jnz 0x0000796DA41DDCB5
0000796da41d96fa  movaps [r15+0x170], xmm10
0000796da41d9702  vmovaps xmm1, [rsp+0x20]
0000796da41d9708  vpermilpd xmm1, xmm1, 0x00
0000796da41d970e  movaps xmm12, xmm14
0000796da41d9712  mulpd xmm12, xmm1
0000796da41d9717  vcmppd xmm9, xmm12, xmm12, 0x03
0000796da41d971d  ptest xmm9, xmm9
0000796da41d9723  jnz 0x0000796DA41DDDF8
0000796da41d9729  vmovaps xmm1, [rsp+0x20]
0000796da41d972f  vpermilpd xmm1, xmm1, 0x00
0000796da41d9735  vmovaps xmm9, [rsp+0xB0]
0000796da41d973e  movaps xmm14, xmm9
0000796da41d9742  mulpd xmm14, xmm1
0000796da41d9747  vcmppd xmm6, xmm14, xmm14, 0x03
0000796da41d974d  ptest xmm6, xmm6
0000796da41d9752  jnz 0x0000796DA41DDF3B
0000796da41d9758  movaps [r15+0x180], xmm14
0000796da41d9760  movaps xmm1, xmm13
0000796da41d9764  addpd xmm1, xmm8
0000796da41d9769  vcmppd xmm9, xmm1, xmm1, 0x03
0000796da41d976e  ptest xmm9, xmm9
0000796da41d9774  jnz 0x0000796DA41DE07E
0000796da41d977a  movaps [r15+0x210], xmm1
0000796da41d9782  movups xmm13, [r13+rax*1]
0000796da41d9788  lea r14, [rax+0x10]
0000796da41d978c  movups xmm9, [r13+r14*1]
0000796da41d9792  movaps [r15+0x230], xmm9
0000796da41d979a  movaps xmm8, xmm15
0000796da41d979e  addpd xmm8, xmm7
0000796da41d97a3  vcmppd xmm6, xmm8, xmm8, 0x03
0000796da41d97a9  ptest xmm6, xmm6
0000796da41d97ae  jnz 0x0000796DA41DE1D4
0000796da41d97b4  movaps [r15+0x130], xmm8
0000796da41d97bc  vmovaps xmm15, [rsp+0x20]
0000796da41d97c2  vpermilpd xmm15, xmm15, 0x00
0000796da41d97c8  movaps xmm7, xmm9
0000796da41d97cc  mulpd xmm7, xmm15
0000796da41d97d1  vcmppd xmm6, xmm7, xmm7, 0x03
0000796da41d97d6  ptest xmm6, xmm6
0000796da41d97db  jnz 0x0000796DA41DE317
0000796da41d97e1  movaps [r15+0x220], xmm7
0000796da41d97e9  vmovaps xmm15, [rsp+0x20]
0000796da41d97ef  vpermilpd xmm15, xmm15, 0x00
0000796da41d97f5  movaps xmm9, xmm13
0000796da41d97f9  mulpd xmm9, xmm15
0000796da41d97fe  vcmppd xmm6, xmm9, xmm9, 0x03
0000796da41d9804  ptest xmm6, xmm6
0000796da41d9809  jnz 0x0000796DA41DE459
0000796da41d980f  movaps xmm15, xmm11
0000796da41d9813  addpd xmm15, xmm12
0000796da41d9818  vcmppd xmm13, xmm15, xmm15, 0x03
0000796da41d981e  ptest xmm13, xmm13
0000796da41d9824  jnz 0x0000796DA41DE59D
0000796da41d982a  movaps [r15+0x140], xmm15
0000796da41d9832  movaps xmm13, xmm10
0000796da41d9836  addpd xmm13, xmm14
0000796da41d983b  vcmppd xmm12, xmm13, xmm13, 0x03
0000796da41d9841  ptest xmm12, xmm12
0000796da41d9847  jnz 0x0000796DA41DE6E1
0000796da41d984d  movaps [r15+0x150], xmm13
0000796da41d9855  movaps xmm14, xmm1
0000796da41d9859  addpd xmm14, xmm7
0000796da41d985e  vcmppd xmm12, xmm14, xmm14, 0x03
0000796da41d9864  ptest xmm12, xmm12
0000796da41d986a  jnz 0x0000796DA41DE825
0000796da41d9870  movaps [r15+0x160], xmm14
0000796da41d9878  movaps xmm1, xmm8
0000796da41d987c  addpd xmm1, xmm9
0000796da41d9881  vcmppd xmm12, xmm1, xmm1, 0x03
0000796da41d9886  ptest xmm12, xmm12
0000796da41d988c  jnz 0x0000796DA41DE967
0000796da41d9892  movaps [r15+0x120], xmm1
0000796da41d989a  movups [r13+r11*1], xmm15
0000796da41d98a0  lea rax, [r11+0x10]
0000796da41d98a4  movups [r13+rax*1], xmm13
0000796da41d98aa  lea rax, [r11+0x20]
0000796da41d98ae  movups [r13+rax*1], xmm14
0000796da41d98b4  lea rax, [r11+0x30]
0000796da41d98b8  movups [r13+rax*1], xmm1
0000796da41d98be  mov eax, [r15+0x108]
0000796da41d98c5  sahf
0000796da41d98c6  jnz 0x0000796DA41D98F8
0000796da41d98c8  cmp dword ptr [r15+0x318], 0x00
0000796da41d98d0  jz 0x0000796DA41DEAE0
0000796da41d98d6  nop [rax+rax*1], ax
0000796da41d98df  nop [rax+rax*1], eax
0000796da41d98e7  mov eax, 0x4106D0
0000796da41d98ec  mov [r15+0x100], rax
0000796da41d98f3  jmp 0x0000796DA3FFE110
0000796da41d98f8  cmp dword ptr [r15+0x318], 0x00
0000796da41d9900  jz 0x0000796DA41D89C0
0000796da41d9906  nop [rax+rax*1], ax
0000796da41d990f  nop [rax+rax*1], eax
0000796da41d9917  mov eax, 0x410504
0000796da41d991c  mov [r15+0x100], rax
0000796da41d9923  jmp 0x0000796DA3FFE110
0000796da41d9928  int3
0000796da41d9929  call 0x0000796DA400A4B0
0000796da41d992e  jmp 0x0000796DA41D8A08
0000796da41d9933  call 0x0000796DA4009240
0000796da41d9938  jmp 0x0000796DA41D8A12
0000796da41d993d  call 0x0000796DA400A4B0
0000796da41d9942  jmp 0x0000796DA41D8A6F
0000796da41d9947  call 0x0000796DA4009240
0000796da41d994c  jmp 0x0000796DA41D8A79
0000796da41d9951  call 0x0000796DA400A4B0
0000796da41d9956  jmp 0x0000796DA41D8ABD
0000796da41d995b  call 0x0000796DA4009240
0000796da41d9960  jmp 0x0000796DA41D8AC7
0000796da41d9965  call 0x0000796DA40B47C0
0000796da41d996a  jmp 0x0000796DA41D8B06
0000796da41d996f  call 0x0000796DA400B720
0000796da41d9974  jmp 0x0000796DA41D8B1A
0000796da41d9979  call 0x0000796DA40BFC30
0000796da41d997e  jmp 0x0000796DA41D8B38
0000796da41d9983  call 0x0000796DA40BE9C0
0000796da41d9988  jmp 0x0000796DA41D8B42
0000796da41d998d  call 0x0000796DA40BD750
0000796da41d9992  jmp 0x0000796DA41D8B4C
0000796da41d9997  sub rsp, 0x08
0000796da41d999b  push rax
0000796da41d999c  push rcx
0000796da41d999d  push rdx
0000796da41d999e  push rdi
0000796da41d999f  push rsi
0000796da41d99a0  push r8
0000796da41d99a2  push r9
0000796da41d99a4  push r10
0000796da41d99a6  push r11
0000796da41d99a8  sub rsp, 0xF0
0000796da41d99af  vmovaps [rsp], xmm0
0000796da41d99b4  vmovaps [rsp+0x10], xmm1
0000796da41d99ba  vmovaps [rsp+0x20], xmm2
0000796da41d99c0  vmovaps [rsp+0x30], xmm3
0000796da41d99c6  vmovaps [rsp+0x40], xmm4
0000796da41d99cc  vmovaps [rsp+0x50], xmm5
0000796da41d99d2  vmovaps [rsp+0x60], xmm6
0000796da41d99d8  vmovaps [rsp+0x70], xmm7
0000796da41d99de  vmovaps [rsp+0x80], xmm9
0000796da41d99e7  vmovaps [rsp+0x90], xmm10
0000796da41d99f0  vmovaps [rsp+0xA0], xmm11
0000796da41d99f9  vmovaps [rsp+0xB0], xmm12
0000796da41d9a02  vmovaps [rsp+0xC0], xmm13
0000796da41d9a0b  vmovaps [rsp+0xD0], xmm14
0000796da41d9a14  vmovaps [rsp+0xE0], xmm15
0000796da41d9a1d  sub rsp, 0x30
0000796da41d9a21  movaps [rsp], xmm8
0000796da41d9a26  movaps [rsp+0x10], xmm12
0000796da41d9a2c  movaps [rsp+0x20], xmm15
0000796da41d9a32  lea rdi, [rsp]
0000796da41d9a36  mov esi, 0x00
0000796da41d9a3b  mov rax, 0x5E26CB66A530
0000796da41d9a45  call rax
0000796da41d9a47  movaps xmm8, [rsp]
0000796da41d9a4c  add rsp, 0x30
0000796da41d9a50  vmovaps xmm0, [rsp]
0000796da41d9a55  vmovaps xmm1, [rsp+0x10]
0000796da41d9a5b  vmovaps xmm2, [rsp+0x20]
0000796da41d9a61  vmovaps xmm3, [rsp+0x30]
0000796da41d9a67  vmovaps xmm4, [rsp+0x40]
0000796da41d9a6d  vmovaps xmm5, [rsp+0x50]
0000796da41d9a73  vmovaps xmm6, [rsp+0x60]
0000796da41d9a79  vmovaps xmm7, [rsp+0x70]
0000796da41d9a7f  vmovaps xmm9, [rsp+0x80]
0000796da41d9a88  vmovaps xmm10, [rsp+0x90]
0000796da41d9a91  vmovaps xmm11, [rsp+0xA0]
0000796da41d9a9a  vmovaps xmm12, [rsp+0xB0]
0000796da41d9aa3  vmovaps xmm13, [rsp+0xC0]
0000796da41d9aac  vmovaps xmm14, [rsp+0xD0]
0000796da41d9ab5  vmovaps xmm15, [rsp+0xE0]
0000796da41d9abe  add rsp, 0xF0
0000796da41d9ac5  pop r11
0000796da41d9ac7  pop r10
0000796da41d9ac9  pop r9
0000796da41d9acb  pop r8
0000796da41d9acd  pop rsi
0000796da41d9ace  pop rdi
0000796da41d9acf  pop rdx
0000796da41d9ad0  pop rcx
0000796da41d9ad1  pop rax
0000796da41d9ad2  add rsp, 0x08
0000796da41d9ad6  jmp 0x0000796DA41D8B7A
0000796da41d9adb  sub rsp, 0x08
0000796da41d9adf  push rax
0000796da41d9ae0  push rcx
0000796da41d9ae1  push rdx
0000796da41d9ae2  push rdi
0000796da41d9ae3  push rsi
0000796da41d9ae4  push r8
0000796da41d9ae6  push r9
0000796da41d9ae8  push r10
0000796da41d9aea  push r11
0000796da41d9aec  sub rsp, 0xF0
0000796da41d9af3  vmovaps [rsp], xmm0
0000796da41d9af8  vmovaps [rsp+0x10], xmm1
0000796da41d9afe  vmovaps [rsp+0x20], xmm2
0000796da41d9b04  vmovaps [rsp+0x30], xmm3
0000796da41d9b0a  vmovaps [rsp+0x40], xmm4
0000796da41d9b10  vmovaps [rsp+0x50], xmm5
0000796da41d9b16  vmovaps [rsp+0x60], xmm6
0000796da41d9b1c  vmovaps [rsp+0x70], xmm8
0000796da41d9b22  vmovaps [rsp+0x80], xmm9
0000796da41d9b2b  vmovaps [rsp+0x90], xmm10
0000796da41d9b34  vmovaps [rsp+0xA0], xmm11
0000796da41d9b3d  vmovaps [rsp+0xB0], xmm12
0000796da41d9b46  vmovaps [rsp+0xC0], xmm13
0000796da41d9b4f  vmovaps [rsp+0xD0], xmm14
0000796da41d9b58  vmovaps [rsp+0xE0], xmm15
0000796da41d9b61  sub rsp, 0x30
0000796da41d9b65  movaps [rsp], xmm7
0000796da41d9b69  movaps [rsp+0x10], xmm9
0000796da41d9b6f  movaps [rsp+0x20], xmm15
0000796da41d9b75  lea rdi, [rsp]
0000796da41d9b79  mov esi, 0x00
0000796da41d9b7e  mov rax, 0x5E26CB66A530
0000796da41d9b88  call rax
0000796da41d9b8a  movaps xmm7, [rsp]
0000796da41d9b8e  add rsp, 0x30
0000796da41d9b92  vmovaps xmm0, [rsp]
0000796da41d9b97  vmovaps xmm1, [rsp+0x10]
0000796da41d9b9d  vmovaps xmm2, [rsp+0x20]
0000796da41d9ba3  vmovaps xmm3, [rsp+0x30]
0000796da41d9ba9  vmovaps xmm4, [rsp+0x40]
0000796da41d9baf  vmovaps xmm5, [rsp+0x50]
0000796da41d9bb5  vmovaps xmm6, [rsp+0x60]
0000796da41d9bbb  vmovaps xmm8, [rsp+0x70]
0000796da41d9bc1  vmovaps xmm9, [rsp+0x80]
0000796da41d9bca  vmovaps xmm10, [rsp+0x90]
0000796da41d9bd3  vmovaps xmm11, [rsp+0xA0]
0000796da41d9bdc  vmovaps xmm12, [rsp+0xB0]
0000796da41d9be5  vmovaps xmm13, [rsp+0xC0]
0000796da41d9bee  vmovaps xmm14, [rsp+0xD0]
0000796da41d9bf7  vmovaps xmm15, [rsp+0xE0]
0000796da41d9c00  add rsp, 0xF0
0000796da41d9c07  pop r11
0000796da41d9c09  pop r10
0000796da41d9c0b  pop r9
0000796da41d9c0d  pop r8
0000796da41d9c0f  pop rsi
0000796da41d9c10  pop rdi
0000796da41d9c11  pop rdx
0000796da41d9c12  pop rcx
0000796da41d9c13  pop rax
0000796da41d9c14  add rsp, 0x08
0000796da41d9c18  jmp 0x0000796DA41D8BA8
0000796da41d9c1d  sub rsp, 0x08
0000796da41d9c21  push rax
0000796da41d9c22  push rcx
0000796da41d9c23  push rdx
0000796da41d9c24  push rdi
0000796da41d9c25  push rsi
0000796da41d9c26  push r8
0000796da41d9c28  push r9
0000796da41d9c2a  push r10
0000796da41d9c2c  push r11
0000796da41d9c2e  sub rsp, 0xF0
0000796da41d9c35  vmovaps [rsp], xmm0
0000796da41d9c3a  vmovaps [rsp+0x10], xmm1
0000796da41d9c40  vmovaps [rsp+0x20], xmm2
0000796da41d9c46  vmovaps [rsp+0x30], xmm3
0000796da41d9c4c  vmovaps [rsp+0x40], xmm4
0000796da41d9c52  vmovaps [rsp+0x50], xmm5
0000796da41d9c58  vmovaps [rsp+0x60], xmm6
0000796da41d9c5e  vmovaps [rsp+0x70], xmm7
0000796da41d9c64  vmovaps [rsp+0x80], xmm8
0000796da41d9c6d  vmovaps [rsp+0x90], xmm10
0000796da41d9c76  vmovaps [rsp+0xA0], xmm11
0000796da41d9c7f  vmovaps [rsp+0xB0], xmm12
0000796da41d9c88  vmovaps [rsp+0xC0], xmm13
0000796da41d9c91  vmovaps [rsp+0xD0], xmm14
0000796da41d9c9a  vmovaps [rsp+0xE0], xmm15
0000796da41d9ca3  sub rsp, 0x30
0000796da41d9ca7  movaps [rsp], xmm9
0000796da41d9cac  movaps [rsp+0x10], xmm12
0000796da41d9cb2  movaps [rsp+0x20], xmm10
0000796da41d9cb8  lea rdi, [rsp]
0000796da41d9cbc  mov esi, 0x00
0000796da41d9cc1  mov rax, 0x5E26CB66A530
0000796da41d9ccb  call rax
0000796da41d9ccd  movaps xmm9, [rsp]
0000796da41d9cd2  add rsp, 0x30
0000796da41d9cd6  vmovaps xmm0, [rsp]
0000796da41d9cdb  vmovaps xmm1, [rsp+0x10]
0000796da41d9ce1  vmovaps xmm2, [rsp+0x20]
0000796da41d9ce7  vmovaps xmm3, [rsp+0x30]
0000796da41d9ced  vmovaps xmm4, [rsp+0x40]
0000796da41d9cf3  vmovaps xmm5, [rsp+0x50]
0000796da41d9cf9  vmovaps xmm6, [rsp+0x60]
0000796da41d9cff  vmovaps xmm7, [rsp+0x70]
0000796da41d9d05  vmovaps xmm8, [rsp+0x80]
0000796da41d9d0e  vmovaps xmm10, [rsp+0x90]
0000796da41d9d17  vmovaps xmm11, [rsp+0xA0]
0000796da41d9d20  vmovaps xmm12, [rsp+0xB0]
0000796da41d9d29  vmovaps xmm13, [rsp+0xC0]
0000796da41d9d32  vmovaps xmm14, [rsp+0xD0]
0000796da41d9d3b  vmovaps xmm15, [rsp+0xE0]
0000796da41d9d44  add rsp, 0xF0
0000796da41d9d4b  pop r11
0000796da41d9d4d  pop r10
0000796da41d9d4f  pop r9
0000796da41d9d51  pop r8
0000796da41d9d53  pop rsi
0000796da41d9d54  pop rdi
0000796da41d9d55  pop rdx
0000796da41d9d56  pop rcx
0000796da41d9d57  pop rax
0000796da41d9d58  add rsp, 0x08
0000796da41d9d5c  jmp 0x0000796DA41D8BCC
0000796da41d9d61  sub rsp, 0x08
0000796da41d9d65  push rax
0000796da41d9d66  push rcx
0000796da41d9d67  push rdx
0000796da41d9d68  push rdi
0000796da41d9d69  push rsi
0000796da41d9d6a  push r8
0000796da41d9d6c  push r9
0000796da41d9d6e  push r10
0000796da41d9d70  push r11
0000796da41d9d72  sub rsp, 0xF0
0000796da41d9d79  vmovaps [rsp], xmm0
0000796da41d9d7e  vmovaps [rsp+0x10], xmm1
0000796da41d9d84  vmovaps [rsp+0x20], xmm2
0000796da41d9d8a  vmovaps [rsp+0x30], xmm3
0000796da41d9d90  vmovaps [rsp+0x40], xmm4
0000796da41d9d96  vmovaps [rsp+0x50], xmm5
0000796da41d9d9c  vmovaps [rsp+0x60], xmm6
0000796da41d9da2  vmovaps [rsp+0x70], xmm7
0000796da41d9da8  vmovaps [rsp+0x80], xmm8
0000796da41d9db1  vmovaps [rsp+0x90], xmm9
0000796da41d9dba  vmovaps [rsp+0xA0], xmm11
0000796da41d9dc3  vmovaps [rsp+0xB0], xmm12
0000796da41d9dcc  vmovaps [rsp+0xC0], xmm13
0000796da41d9dd5  vmovaps [rsp+0xD0], xmm14
0000796da41d9dde  vmovaps [rsp+0xE0], xmm15
0000796da41d9de7  sub rsp, 0x30
0000796da41d9deb  movaps [rsp], xmm10
0000796da41d9df0  movaps [rsp+0x10], xmm12
0000796da41d9df6  movaps [rsp+0x20], xmm11
0000796da41d9dfc  lea rdi, [rsp]
0000796da41d9e00  mov esi, 0x00
0000796da41d9e05  mov rax, 0x5E26CB66A530
0000796da41d9e0f  call rax
0000796da41d9e11  movaps xmm10, [rsp]
0000796da41d9e16  add rsp, 0x30
0000796da41d9e1a  vmovaps xmm0, [rsp]
0000796da41d9e1f  vmovaps xmm1, [rsp+0x10]
0000796da41d9e25  vmovaps xmm2, [rsp+0x20]
0000796da41d9e2b  vmovaps xmm3, [rsp+0x30]
0000796da41d9e31  vmovaps xmm4, [rsp+0x40]
0000796da41d9e37  vmovaps xmm5, [rsp+0x50]
0000796da41d9e3d  vmovaps xmm6, [rsp+0x60]
0000796da41d9e43  vmovaps xmm7, [rsp+0x70]
0000796da41d9e49  vmovaps xmm8, [rsp+0x80]
0000796da41d9e52  vmovaps xmm9, [rsp+0x90]
0000796da41d9e5b  vmovaps xmm11, [rsp+0xA0]
0000796da41d9e64  vmovaps xmm12, [rsp+0xB0]
0000796da41d9e6d  vmovaps xmm13, [rsp+0xC0]
0000796da41d9e76  vmovaps xmm14, [rsp+0xD0]
0000796da41d9e7f  vmovaps xmm15, [rsp+0xE0]
0000796da41d9e88  add rsp, 0xF0
0000796da41d9e8f  pop r11
0000796da41d9e91  pop r10
0000796da41d9e93  pop r9
0000796da41d9e95  pop r8
0000796da41d9e97  pop rsi
0000796da41d9e98  pop rdi
0000796da41d9e99  pop rdx
0000796da41d9e9a  pop rcx
0000796da41d9e9b  pop rax
0000796da41d9e9c  add rsp, 0x08
0000796da41d9ea0  jmp 0x0000796DA41D8BE6
0000796da41d9ea5  sub rsp, 0x08
0000796da41d9ea9  push rax
0000796da41d9eaa  push rcx
0000796da41d9eab  push rdx
0000796da41d9eac  push rdi
0000796da41d9ead  push rsi
0000796da41d9eae  push r8
0000796da41d9eb0  push r9
0000796da41d9eb2  push r10
0000796da41d9eb4  push r11
0000796da41d9eb6  sub rsp, 0xF0
0000796da41d9ebd  vmovaps [rsp], xmm0
0000796da41d9ec2  vmovaps [rsp+0x10], xmm1
0000796da41d9ec8  vmovaps [rsp+0x20], xmm2
0000796da41d9ece  vmovaps [rsp+0x30], xmm3
0000796da41d9ed4  vmovaps [rsp+0x40], xmm4
0000796da41d9eda  vmovaps [rsp+0x50], xmm5
0000796da41d9ee0  vmovaps [rsp+0x60], xmm7
0000796da41d9ee6  vmovaps [rsp+0x70], xmm8
0000796da41d9eec  vmovaps [rsp+0x80], xmm9
0000796da41d9ef5  vmovaps [rsp+0x90], xmm10
0000796da41d9efe  vmovaps [rsp+0xA0], xmm11
0000796da41d9f07  vmovaps [rsp+0xB0], xmm12
0000796da41d9f10  vmovaps [rsp+0xC0], xmm13
0000796da41d9f19  vmovaps [rsp+0xD0], xmm14
0000796da41d9f22  vmovaps [rsp+0xE0], xmm15
0000796da41d9f2b  sub rsp, 0x30
0000796da41d9f2f  movaps [rsp], xmm6
0000796da41d9f33  movaps [rsp+0x10], xmm12
0000796da41d9f39  movaps [rsp+0x20], xmm11
0000796da41d9f3f  lea rdi, [rsp]
0000796da41d9f43  mov esi, 0x00
0000796da41d9f48  mov rax, 0x5E26CB66A530
0000796da41d9f52  call rax
0000796da41d9f54  movaps xmm6, [rsp]
0000796da41d9f58  add rsp, 0x30
0000796da41d9f5c  vmovaps xmm0, [rsp]
0000796da41d9f61  vmovaps xmm1, [rsp+0x10]
0000796da41d9f67  vmovaps xmm2, [rsp+0x20]
0000796da41d9f6d  vmovaps xmm3, [rsp+0x30]
0000796da41d9f73  vmovaps xmm4, [rsp+0x40]
0000796da41d9f79  vmovaps xmm5, [rsp+0x50]
0000796da41d9f7f  vmovaps xmm7, [rsp+0x60]
0000796da41d9f85  vmovaps xmm8, [rsp+0x70]
0000796da41d9f8b  vmovaps xmm9, [rsp+0x80]
0000796da41d9f94  vmovaps xmm10, [rsp+0x90]
0000796da41d9f9d  vmovaps xmm11, [rsp+0xA0]
0000796da41d9fa6  vmovaps xmm12, [rsp+0xB0]
0000796da41d9faf  vmovaps xmm13, [rsp+0xC0]
0000796da41d9fb8  vmovaps xmm14, [rsp+0xD0]
0000796da41d9fc1  vmovaps xmm15, [rsp+0xE0]
0000796da41d9fca  add rsp, 0xF0
0000796da41d9fd1  pop r11
0000796da41d9fd3  pop r10
0000796da41d9fd5  pop r9
0000796da41d9fd7  pop r8
0000796da41d9fd9  pop rsi
0000796da41d9fda  pop rdi
0000796da41d9fdb  pop rdx
0000796da41d9fdc  pop rcx
0000796da41d9fdd  pop rax
0000796da41d9fde  add rsp, 0x08
0000796da41d9fe2  jmp 0x0000796DA41D8C07
0000796da41d9fe7  sub rsp, 0x08
0000796da41d9feb  push rax
0000796da41d9fec  push rcx
0000796da41d9fed  push rdx
0000796da41d9fee  push rdi
0000796da41d9fef  push rsi
0000796da41d9ff0  push r8
0000796da41d9ff2  push r9
0000796da41d9ff4  push r10
0000796da41d9ff6  push r11
0000796da41d9ff8  sub rsp, 0xF0
0000796da41d9fff  vmovaps [rsp], xmm0
0000796da41da004  vmovaps [rsp+0x10], xmm1
0000796da41da00a  vmovaps [rsp+0x20], xmm2
0000796da41da010  vmovaps [rsp+0x30], xmm4
0000796da41da016  vmovaps [rsp+0x40], xmm5
0000796da41da01c  vmovaps [rsp+0x50], xmm6
0000796da41da022  vmovaps [rsp+0x60], xmm7
0000796da41da028  vmovaps [rsp+0x70], xmm8
0000796da41da02e  vmovaps [rsp+0x80], xmm9
0000796da41da037  vmovaps [rsp+0x90], xmm10
0000796da41da040  vmovaps [rsp+0xA0], xmm11
0000796da41da049  vmovaps [rsp+0xB0], xmm12
0000796da41da052  vmovaps [rsp+0xC0], xmm13
0000796da41da05b  vmovaps [rsp+0xD0], xmm14
0000796da41da064  vmovaps [rsp+0xE0], xmm15
0000796da41da06d  sub rsp, 0x30
0000796da41da071  movaps [rsp], xmm3
0000796da41da075  movaps [rsp+0x10], xmm5
0000796da41da07a  movaps [rsp+0x20], xmm4
0000796da41da07f  lea rdi, [rsp]
0000796da41da083  mov esi, 0x00
0000796da41da088  mov rax, 0x5E26CB66A530
0000796da41da092  call rax
0000796da41da094  movaps xmm3, [rsp]
0000796da41da098  add rsp, 0x30
0000796da41da09c  vmovaps xmm0, [rsp]
0000796da41da0a1  vmovaps xmm1, [rsp+0x10]
0000796da41da0a7  vmovaps xmm2, [rsp+0x20]
0000796da41da0ad  vmovaps xmm4, [rsp+0x30]
0000796da41da0b3  vmovaps xmm5, [rsp+0x40]
0000796da41da0b9  vmovaps xmm6, [rsp+0x50]
0000796da41da0bf  vmovaps xmm7, [rsp+0x60]
0000796da41da0c5  vmovaps xmm8, [rsp+0x70]
0000796da41da0cb  vmovaps xmm9, [rsp+0x80]
0000796da41da0d4  vmovaps xmm10, [rsp+0x90]
0000796da41da0dd  vmovaps xmm11, [rsp+0xA0]
0000796da41da0e6  vmovaps xmm12, [rsp+0xB0]
0000796da41da0ef  vmovaps xmm13, [rsp+0xC0]
0000796da41da0f8  vmovaps xmm14, [rsp+0xD0]
0000796da41da101  vmovaps xmm15, [rsp+0xE0]
0000796da41da10a  add rsp, 0xF0
0000796da41da111  pop r11
0000796da41da113  pop r10
0000796da41da115  pop r9
0000796da41da117  pop r8
0000796da41da119  pop rsi
0000796da41da11a  pop rdi
0000796da41da11b  pop rdx
0000796da41da11c  pop rcx
0000796da41da11d  pop rax
0000796da41da11e  add rsp, 0x08
0000796da41da122  jmp 0x0000796DA41D8C68
0000796da41da127  sub rsp, 0x08
0000796da41da12b  push rax
0000796da41da12c  push rcx
0000796da41da12d  push rdx
0000796da41da12e  push rdi
0000796da41da12f  push rsi
0000796da41da130  push r8
0000796da41da132  push r9
0000796da41da134  push r10
0000796da41da136  push r11
0000796da41da138  sub rsp, 0xF0
0000796da41da13f  vmovaps [rsp], xmm0
0000796da41da144  vmovaps [rsp+0x10], xmm1
0000796da41da14a  vmovaps [rsp+0x20], xmm2
0000796da41da150  vmovaps [rsp+0x30], xmm3
0000796da41da156  vmovaps [rsp+0x40], xmm4
0000796da41da15c  vmovaps [rsp+0x50], xmm6
0000796da41da162  vmovaps [rsp+0x60], xmm7
0000796da41da168  vmovaps [rsp+0x70], xmm8
0000796da41da16e  vmovaps [rsp+0x80], xmm9
0000796da41da177  vmovaps [rsp+0x90], xmm10
0000796da41da180  vmovaps [rsp+0xA0], xmm11
0000796da41da189  vmovaps [rsp+0xB0], xmm12
0000796da41da192  vmovaps [rsp+0xC0], xmm13
0000796da41da19b  vmovaps [rsp+0xD0], xmm14
0000796da41da1a4  vmovaps [rsp+0xE0], xmm15
0000796da41da1ad  sub rsp, 0x30
0000796da41da1b1  movaps [rsp], xmm5
0000796da41da1b5  movaps [rsp+0x10], xmm8
0000796da41da1bb  movaps [rsp+0x20], xmm15
0000796da41da1c1  lea rdi, [rsp]
0000796da41da1c5  mov esi, 0x00
0000796da41da1ca  mov rax, 0x5E26CB66A530
0000796da41da1d4  call rax
0000796da41da1d6  movaps xmm5, [rsp]
0000796da41da1da  add rsp, 0x30
0000796da41da1de  vmovaps xmm0, [rsp]
0000796da41da1e3  vmovaps xmm1, [rsp+0x10]
0000796da41da1e9  vmovaps xmm2, [rsp+0x20]
0000796da41da1ef  vmovaps xmm3, [rsp+0x30]
0000796da41da1f5  vmovaps xmm4, [rsp+0x40]
0000796da41da1fb  vmovaps xmm6, [rsp+0x50]
0000796da41da201  vmovaps xmm7, [rsp+0x60]
0000796da41da207  vmovaps xmm8, [rsp+0x70]
0000796da41da20d  vmovaps xmm9, [rsp+0x80]
0000796da41da216  vmovaps xmm10, [rsp+0x90]
0000796da41da21f  vmovaps xmm11, [rsp+0xA0]
0000796da41da228  vmovaps xmm12, [rsp+0xB0]
0000796da41da231  vmovaps xmm13, [rsp+0xC0]
0000796da41da23a  vmovaps xmm14, [rsp+0xD0]
0000796da41da243  vmovaps xmm15, [rsp+0xE0]
0000796da41da24c  add rsp, 0xF0
0000796da41da253  pop r11
0000796da41da255  pop r10
0000796da41da257  pop r9
0000796da41da259  pop r8
0000796da41da25b  pop rsi
0000796da41da25c  pop rdi
0000796da41da25d  pop rdx
0000796da41da25e  pop rcx
0000796da41da25f  pop rax
0000796da41da260  add rsp, 0x08
0000796da41da264  jmp 0x0000796DA41D8CA0
0000796da41da269  sub rsp, 0x08
0000796da41da26d  push rax
0000796da41da26e  push rcx
0000796da41da26f  push rdx
0000796da41da270  push rdi
0000796da41da271  push rsi
0000796da41da272  push r8
0000796da41da274  push r9
0000796da41da276  push r10
0000796da41da278  push r11
0000796da41da27a  sub rsp, 0xF0
0000796da41da281  vmovaps [rsp], xmm0
0000796da41da286  vmovaps [rsp+0x10], xmm1
0000796da41da28c  vmovaps [rsp+0x20], xmm2
0000796da41da292  vmovaps [rsp+0x30], xmm3
0000796da41da298  vmovaps [rsp+0x40], xmm5
0000796da41da29e  vmovaps [rsp+0x50], xmm6
0000796da41da2a4  vmovaps [rsp+0x60], xmm7
0000796da41da2aa  vmovaps [rsp+0x70], xmm8
0000796da41da2b0  vmovaps [rsp+0x80], xmm9
0000796da41da2b9  vmovaps [rsp+0x90], xmm10
0000796da41da2c2  vmovaps [rsp+0xA0], xmm11
0000796da41da2cb  vmovaps [rsp+0xB0], xmm12
0000796da41da2d4  vmovaps [rsp+0xC0], xmm13
0000796da41da2dd  vmovaps [rsp+0xD0], xmm14
0000796da41da2e6  vmovaps [rsp+0xE0], xmm15
0000796da41da2ef  sub rsp, 0x30
0000796da41da2f3  movaps [rsp], xmm4
0000796da41da2f7  movaps [rsp+0x10], xmm9
0000796da41da2fd  movaps [rsp+0x20], xmm8
0000796da41da303  lea rdi, [rsp]
0000796da41da307  mov esi, 0x00
0000796da41da30c  mov rax, 0x5E26CB66A530
0000796da41da316  call rax
0000796da41da318  movaps xmm4, [rsp]
0000796da41da31c  add rsp, 0x30
0000796da41da320  vmovaps xmm0, [rsp]
0000796da41da325  vmovaps xmm1, [rsp+0x10]
0000796da41da32b  vmovaps xmm2, [rsp+0x20]
0000796da41da331  vmovaps xmm3, [rsp+0x30]
0000796da41da337  vmovaps xmm5, [rsp+0x40]
0000796da41da33d  vmovaps xmm6, [rsp+0x50]
0000796da41da343  vmovaps xmm7, [rsp+0x60]
0000796da41da349  vmovaps xmm8, [rsp+0x70]
0000796da41da34f  vmovaps xmm9, [rsp+0x80]
0000796da41da358  vmovaps xmm10, [rsp+0x90]
0000796da41da361  vmovaps xmm11, [rsp+0xA0]
0000796da41da36a  vmovaps xmm12, [rsp+0xB0]
0000796da41da373  vmovaps xmm13, [rsp+0xC0]
0000796da41da37c  vmovaps xmm14, [rsp+0xD0]
0000796da41da385  vmovaps xmm15, [rsp+0xE0]
0000796da41da38e  add rsp, 0xF0
0000796da41da395  pop r11
0000796da41da397  pop r10
0000796da41da399  pop r9
0000796da41da39b  pop r8
0000796da41da39d  pop rsi
0000796da41da39e  pop rdi
0000796da41da39f  pop rdx
0000796da41da3a0  pop rcx
0000796da41da3a1  pop rax
0000796da41da3a2  add rsp, 0x08
0000796da41da3a6  jmp 0x0000796DA41D8CC1
0000796da41da3ab  sub rsp, 0x08
0000796da41da3af  push rax
0000796da41da3b0  push rcx
0000796da41da3b1  push rdx
0000796da41da3b2  push rdi
0000796da41da3b3  push rsi
0000796da41da3b4  push r8
0000796da41da3b6  push r9
0000796da41da3b8  push r10
0000796da41da3ba  push r11
0000796da41da3bc  sub rsp, 0xF0
0000796da41da3c3  vmovaps [rsp], xmm0
0000796da41da3c8  vmovaps [rsp+0x10], xmm1
0000796da41da3ce  vmovaps [rsp+0x20], xmm2
0000796da41da3d4  vmovaps [rsp+0x30], xmm3
0000796da41da3da  vmovaps [rsp+0x40], xmm4
0000796da41da3e0  vmovaps [rsp+0x50], xmm5
0000796da41da3e6  vmovaps [rsp+0x60], xmm6
0000796da41da3ec  vmovaps [rsp+0x70], xmm7
0000796da41da3f2  vmovaps [rsp+0x80], xmm8
0000796da41da3fb  vmovaps [rsp+0x90], xmm10
0000796da41da404  vmovaps [rsp+0xA0], xmm11
0000796da41da40d  vmovaps [rsp+0xB0], xmm12
0000796da41da416  vmovaps [rsp+0xC0], xmm13
0000796da41da41f  vmovaps [rsp+0xD0], xmm14
0000796da41da428  vmovaps [rsp+0xE0], xmm15
0000796da41da431  sub rsp, 0x30
0000796da41da435  movaps [rsp], xmm9
0000796da41da43a  movaps [rsp+0x10], xmm10
0000796da41da440  movaps [rsp+0x20], xmm8
0000796da41da446  lea rdi, [rsp]
0000796da41da44a  mov esi, 0x00
0000796da41da44f  mov rax, 0x5E26CB66A530
0000796da41da459  call rax
0000796da41da45b  movaps xmm9, [rsp]
0000796da41da460  add rsp, 0x30
0000796da41da464  vmovaps xmm0, [rsp]
0000796da41da469  vmovaps xmm1, [rsp+0x10]
0000796da41da46f  vmovaps xmm2, [rsp+0x20]
0000796da41da475  vmovaps xmm3, [rsp+0x30]
0000796da41da47b  vmovaps xmm4, [rsp+0x40]
0000796da41da481  vmovaps xmm5, [rsp+0x50]
0000796da41da487  vmovaps xmm6, [rsp+0x60]
0000796da41da48d  vmovaps xmm7, [rsp+0x70]
0000796da41da493  vmovaps xmm8, [rsp+0x80]
0000796da41da49c  vmovaps xmm10, [rsp+0x90]
0000796da41da4a5  vmovaps xmm11, [rsp+0xA0]
0000796da41da4ae  vmovaps xmm12, [rsp+0xB0]
0000796da41da4b7  vmovaps xmm13, [rsp+0xC0]
0000796da41da4c0  vmovaps xmm14, [rsp+0xD0]
0000796da41da4c9  vmovaps xmm15, [rsp+0xE0]
0000796da41da4d2  add rsp, 0xF0
0000796da41da4d9  pop r11
0000796da41da4db  pop r10
0000796da41da4dd  pop r9
0000796da41da4df  pop r8
0000796da41da4e1  pop rsi
0000796da41da4e2  pop rdi
0000796da41da4e3  pop rdx
0000796da41da4e4  pop rcx
0000796da41da4e5  pop rax
0000796da41da4e6  add rsp, 0x08
0000796da41da4ea  jmp 0x0000796DA41D8CDB
0000796da41da4ef  call 0x0000796DA40D64F0
0000796da41da4f4  jmp 0x0000796DA41D8DF5
0000796da41da4f9  call 0x0000796DA40D64F0
0000796da41da4fe  jmp 0x0000796DA41D8E0B
0000796da41da503  sub rsp, 0x08
0000796da41da507  push rax
0000796da41da508  push rcx
0000796da41da509  push rdx
0000796da41da50a  push rdi
0000796da41da50b  push rsi
0000796da41da50c  push r8
0000796da41da50e  push r9
0000796da41da510  push r10
0000796da41da512  push r11
0000796da41da514  sub rsp, 0xF0
0000796da41da51b  vmovaps [rsp], xmm0
0000796da41da520  vmovaps [rsp+0x10], xmm2
0000796da41da526  vmovaps [rsp+0x20], xmm3
0000796da41da52c  vmovaps [rsp+0x30], xmm4
0000796da41da532  vmovaps [rsp+0x40], xmm5
0000796da41da538  vmovaps [rsp+0x50], xmm6
0000796da41da53e  vmovaps [rsp+0x60], xmm7
0000796da41da544  vmovaps [rsp+0x70], xmm8
0000796da41da54a  vmovaps [rsp+0x80], xmm9
0000796da41da553  vmovaps [rsp+0x90], xmm10
0000796da41da55c  vmovaps [rsp+0xA0], xmm11
0000796da41da565  vmovaps [rsp+0xB0], xmm12
0000796da41da56e  vmovaps [rsp+0xC0], xmm13
0000796da41da577  vmovaps [rsp+0xD0], xmm14
0000796da41da580  vmovaps [rsp+0xE0], xmm15
0000796da41da589  sub rsp, 0x30
0000796da41da58d  movaps [rsp], xmm1
0000796da41da591  movaps [rsp+0x10], xmm6
0000796da41da596  movaps [rsp+0x20], xmm15
0000796da41da59c  lea rdi, [rsp]
0000796da41da5a0  mov esi, 0x00
0000796da41da5a5  mov rax, 0x5E26CB66A530
0000796da41da5af  call rax
0000796da41da5b1  movaps xmm1, [rsp]
0000796da41da5b5  add rsp, 0x30
0000796da41da5b9  vmovaps xmm0, [rsp]
0000796da41da5be  vmovaps xmm2, [rsp+0x10]
0000796da41da5c4  vmovaps xmm3, [rsp+0x20]
0000796da41da5ca  vmovaps xmm4, [rsp+0x30]
0000796da41da5d0  vmovaps xmm5, [rsp+0x40]
0000796da41da5d6  vmovaps xmm6, [rsp+0x50]
0000796da41da5dc  vmovaps xmm7, [rsp+0x60]
0000796da41da5e2  vmovaps xmm8, [rsp+0x70]
0000796da41da5e8  vmovaps xmm9, [rsp+0x80]
0000796da41da5f1  vmovaps xmm10, [rsp+0x90]
0000796da41da5fa  vmovaps xmm11, [rsp+0xA0]
0000796da41da603  vmovaps xmm12, [rsp+0xB0]
0000796da41da60c  vmovaps xmm13, [rsp+0xC0]
0000796da41da615  vmovaps xmm14, [rsp+0xD0]
0000796da41da61e  vmovaps xmm15, [rsp+0xE0]
0000796da41da627  add rsp, 0xF0
0000796da41da62e  pop r11
0000796da41da630  pop r10
0000796da41da632  pop r9
0000796da41da634  pop r8
0000796da41da636  pop rsi
0000796da41da637  pop rdi
0000796da41da638  pop rdx
0000796da41da639  pop rcx
0000796da41da63a  pop rax
0000796da41da63b  add rsp, 0x08
0000796da41da63f  jmp 0x0000796DA41D8E48
0000796da41da644  call 0x0000796DA40E5820
0000796da41da649  jmp 0x0000796DA41D8E55
0000796da41da64e  sub rsp, 0x08
0000796da41da652  push rax
0000796da41da653  push rcx
0000796da41da654  push rdx
0000796da41da655  push rdi
0000796da41da656  push rsi
0000796da41da657  push r8
0000796da41da659  push r9
0000796da41da65b  push r10
0000796da41da65d  push r11
0000796da41da65f  sub rsp, 0xF0
0000796da41da666  vmovaps [rsp], xmm0
0000796da41da66b  vmovaps [rsp+0x10], xmm1
0000796da41da671  vmovaps [rsp+0x20], xmm2
0000796da41da677  vmovaps [rsp+0x30], xmm3
0000796da41da67d  vmovaps [rsp+0x40], xmm4
0000796da41da683  vmovaps [rsp+0x50], xmm5
0000796da41da689  vmovaps [rsp+0x60], xmm6
0000796da41da68f  vmovaps [rsp+0x70], xmm7
0000796da41da695  vmovaps [rsp+0x80], xmm8
0000796da41da69e  vmovaps [rsp+0x90], xmm9
0000796da41da6a7  vmovaps [rsp+0xA0], xmm10
0000796da41da6b0  vmovaps [rsp+0xB0], xmm11
0000796da41da6b9  vmovaps [rsp+0xC0], xmm12
0000796da41da6c2  vmovaps [rsp+0xD0], xmm13
0000796da41da6cb  vmovaps [rsp+0xE0], xmm15
0000796da41da6d4  sub rsp, 0x30
0000796da41da6d8  movaps [rsp], xmm14
0000796da41da6dd  movaps [rsp+0x10], xmm4
0000796da41da6e2  movaps [rsp+0x20], xmm3
0000796da41da6e7  lea rdi, [rsp]
0000796da41da6eb  mov esi, 0x00
0000796da41da6f0  mov rax, 0x5E26CB66A530
0000796da41da6fa  call rax
0000796da41da6fc  movaps xmm14, [rsp]
0000796da41da701  add rsp, 0x30
0000796da41da705  vmovaps xmm0, [rsp]
0000796da41da70a  vmovaps xmm1, [rsp+0x10]
0000796da41da710  vmovaps xmm2, [rsp+0x20]
0000796da41da716  vmovaps xmm3, [rsp+0x30]
0000796da41da71c  vmovaps xmm4, [rsp+0x40]
0000796da41da722  vmovaps xmm5, [rsp+0x50]
0000796da41da728  vmovaps xmm6, [rsp+0x60]
0000796da41da72e  vmovaps xmm7, [rsp+0x70]
0000796da41da734  vmovaps xmm8, [rsp+0x80]
0000796da41da73d  vmovaps xmm9, [rsp+0x90]
0000796da41da746  vmovaps xmm10, [rsp+0xA0]
0000796da41da74f  vmovaps xmm11, [rsp+0xB0]
0000796da41da758  vmovaps xmm12, [rsp+0xC0]
0000796da41da761  vmovaps xmm13, [rsp+0xD0]
0000796da41da76a  vmovaps xmm15, [rsp+0xE0]
0000796da41da773  add rsp, 0xF0
0000796da41da77a  pop r11
0000796da41da77c  pop r10
0000796da41da77e  pop r9
0000796da41da780  pop r8
0000796da41da782  pop rsi
0000796da41da783  pop rdi
0000796da41da784  pop rdx
0000796da41da785  pop rcx
0000796da41da786  pop rax
0000796da41da787  add rsp, 0x08
0000796da41da78b  jmp 0x0000796DA41D8E6F
0000796da41da790  sub rsp, 0x08
0000796da41da794  push rax
0000796da41da795  push rcx
0000796da41da796  push rdx
0000796da41da797  push rdi
0000796da41da798  push rsi
0000796da41da799  push r8
0000796da41da79b  push r9
0000796da41da79d  push r10
0000796da41da79f  push r11
0000796da41da7a1  sub rsp, 0xF0
0000796da41da7a8  vmovaps [rsp], xmm0
0000796da41da7ad  vmovaps [rsp+0x10], xmm1
0000796da41da7b3  vmovaps [rsp+0x20], xmm2
0000796da41da7b9  vmovaps [rsp+0x30], xmm3
0000796da41da7bf  vmovaps [rsp+0x40], xmm4
0000796da41da7c5  vmovaps [rsp+0x50], xmm5
0000796da41da7cb  vmovaps [rsp+0x60], xmm7
0000796da41da7d1  vmovaps [rsp+0x70], xmm8
0000796da41da7d7  vmovaps [rsp+0x80], xmm9
0000796da41da7e0  vmovaps [rsp+0x90], xmm10
0000796da41da7e9  vmovaps [rsp+0xA0], xmm11
0000796da41da7f2  vmovaps [rsp+0xB0], xmm12
0000796da41da7fb  vmovaps [rsp+0xC0], xmm13
0000796da41da804  vmovaps [rsp+0xD0], xmm14
0000796da41da80d  vmovaps [rsp+0xE0], xmm15
0000796da41da816  sub rsp, 0x30
0000796da41da81a  movaps [rsp], xmm6
0000796da41da81e  movaps [rsp+0x10], xmm9
0000796da41da824  movaps [rsp+0x20], xmm7
0000796da41da829  lea rdi, [rsp]
0000796da41da82d  mov esi, 0x00
0000796da41da832  mov rax, 0x5E26CB66A530
0000796da41da83c  call rax
0000796da41da83e  movaps xmm6, [rsp]
0000796da41da842  add rsp, 0x30
0000796da41da846  vmovaps xmm0, [rsp]
0000796da41da84b  vmovaps xmm1, [rsp+0x10]
0000796da41da851  vmovaps xmm2, [rsp+0x20]
0000796da41da857  vmovaps xmm3, [rsp+0x30]
0000796da41da85d  vmovaps xmm4, [rsp+0x40]
0000796da41da863  vmovaps xmm5, [rsp+0x50]
0000796da41da869  vmovaps xmm7, [rsp+0x60]
0000796da41da86f  vmovaps xmm8, [rsp+0x70]
0000796da41da875  vmovaps xmm9, [rsp+0x80]
0000796da41da87e  vmovaps xmm10, [rsp+0x90]
0000796da41da887  vmovaps xmm11, [rsp+0xA0]
0000796da41da890  vmovaps xmm12, [rsp+0xB0]
0000796da41da899  vmovaps xmm13, [rsp+0xC0]
0000796da41da8a2  vmovaps xmm14, [rsp+0xD0]
0000796da41da8ab  vmovaps xmm15, [rsp+0xE0]
0000796da41da8b4  add rsp, 0xF0
0000796da41da8bb  pop r11
0000796da41da8bd  pop r10
0000796da41da8bf  pop r9
0000796da41da8c1  pop r8
0000796da41da8c3  pop rsi
0000796da41da8c4  pop rdi
0000796da41da8c5  pop rdx
0000796da41da8c6  pop rcx
0000796da41da8c7  pop rax
0000796da41da8c8  add rsp, 0x08
0000796da41da8cc  jmp 0x0000796DA41D8E87
0000796da41da8d1  sub rsp, 0x08
0000796da41da8d5  push rax
0000796da41da8d6  push rcx
0000796da41da8d7  push rdx
0000796da41da8d8  push rdi
0000796da41da8d9  push rsi
0000796da41da8da  push r8
0000796da41da8dc  push r9
0000796da41da8de  push r10
0000796da41da8e0  push r11
0000796da41da8e2  sub rsp, 0xF0
0000796da41da8e9  vmovaps [rsp], xmm0
0000796da41da8ee  vmovaps [rsp+0x10], xmm1
0000796da41da8f4  vmovaps [rsp+0x20], xmm2
0000796da41da8fa  vmovaps [rsp+0x30], xmm3
0000796da41da900  vmovaps [rsp+0x40], xmm4
0000796da41da906  vmovaps [rsp+0x50], xmm5
0000796da41da90c  vmovaps [rsp+0x60], xmm6
0000796da41da912  vmovaps [rsp+0x70], xmm8
0000796da41da918  vmovaps [rsp+0x80], xmm9
0000796da41da921  vmovaps [rsp+0x90], xmm10
0000796da41da92a  vmovaps [rsp+0xA0], xmm11
0000796da41da933  vmovaps [rsp+0xB0], xmm12
0000796da41da93c  vmovaps [rsp+0xC0], xmm13
0000796da41da945  vmovaps [rsp+0xD0], xmm14
0000796da41da94e  vmovaps [rsp+0xE0], xmm15
0000796da41da957  sub rsp, 0x30
0000796da41da95b  movaps [rsp], xmm7
0000796da41da95f  movaps [rsp+0x10], xmm4
0000796da41da964  movaps [rsp+0x20], xmm9
0000796da41da96a  lea rdi, [rsp]
0000796da41da96e  mov esi, 0x00
0000796da41da973  mov rax, 0x5E26CB66A530
0000796da41da97d  call rax
0000796da41da97f  movaps xmm7, [rsp]
0000796da41da983  add rsp, 0x30
0000796da41da987  vmovaps xmm0, [rsp]
0000796da41da98c  vmovaps xmm1, [rsp+0x10]
0000796da41da992  vmovaps xmm2, [rsp+0x20]
0000796da41da998  vmovaps xmm3, [rsp+0x30]
0000796da41da99e  vmovaps xmm4, [rsp+0x40]
0000796da41da9a4  vmovaps xmm5, [rsp+0x50]
0000796da41da9aa  vmovaps xmm6, [rsp+0x60]
0000796da41da9b0  vmovaps xmm8, [rsp+0x70]
0000796da41da9b6  vmovaps xmm9, [rsp+0x80]
0000796da41da9bf  vmovaps xmm10, [rsp+0x90]
0000796da41da9c8  vmovaps xmm11, [rsp+0xA0]
0000796da41da9d1  vmovaps xmm12, [rsp+0xB0]
0000796da41da9da  vmovaps xmm13, [rsp+0xC0]
0000796da41da9e3  vmovaps xmm14, [rsp+0xD0]
0000796da41da9ec  vmovaps xmm15, [rsp+0xE0]
0000796da41da9f5  add rsp, 0xF0
0000796da41da9fc  pop r11
0000796da41da9fe  pop r10
0000796da41daa00  pop r9
0000796da41daa02  pop r8
0000796da41daa04  pop rsi
0000796da41daa05  pop rdi
0000796da41daa06  pop rdx
0000796da41daa07  pop rcx
0000796da41daa08  pop rax
0000796da41daa09  add rsp, 0x08
0000796da41daa0d  jmp 0x0000796DA41D8EB4
0000796da41daa12  sub rsp, 0x08
0000796da41daa16  push rax
0000796da41daa17  push rcx
0000796da41daa18  push rdx
0000796da41daa19  push rdi
0000796da41daa1a  push rsi
0000796da41daa1b  push r8
0000796da41daa1d  push r9
0000796da41daa1f  push r10
0000796da41daa21  push r11
0000796da41daa23  sub rsp, 0xF0
0000796da41daa2a  vmovaps [rsp], xmm0
0000796da41daa2f  vmovaps [rsp+0x10], xmm1
0000796da41daa35  vmovaps [rsp+0x20], xmm2
0000796da41daa3b  vmovaps [rsp+0x30], xmm3
0000796da41daa41  vmovaps [rsp+0x40], xmm5
0000796da41daa47  vmovaps [rsp+0x50], xmm6
0000796da41daa4d  vmovaps [rsp+0x60], xmm7
0000796da41daa53  vmovaps [rsp+0x70], xmm8
0000796da41daa59  vmovaps [rsp+0x80], xmm9
0000796da41daa62  vmovaps [rsp+0x90], xmm10
0000796da41daa6b  vmovaps [rsp+0xA0], xmm11
0000796da41daa74  vmovaps [rsp+0xB0], xmm12
0000796da41daa7d  vmovaps [rsp+0xC0], xmm13
0000796da41daa86  vmovaps [rsp+0xD0], xmm14
0000796da41daa8f  vmovaps [rsp+0xE0], xmm15
0000796da41daa98  sub rsp, 0x30
0000796da41daa9c  movaps [rsp], xmm4
0000796da41daaa0  movaps [rsp+0x10], xmm15
0000796da41daaa6  movaps [rsp+0x20], xmm9
0000796da41daaac  lea rdi, [rsp]
0000796da41daab0  mov esi, 0x00
0000796da41daab5  mov rax, 0x5E26CB66A530
0000796da41daabf  call rax
0000796da41daac1  movaps xmm4, [rsp]
0000796da41daac5  add rsp, 0x30
0000796da41daac9  vmovaps xmm0, [rsp]
0000796da41daace  vmovaps xmm1, [rsp+0x10]
0000796da41daad4  vmovaps xmm2, [rsp+0x20]
0000796da41daada  vmovaps xmm3, [rsp+0x30]
0000796da41daae0  vmovaps xmm5, [rsp+0x40]
0000796da41daae6  vmovaps xmm6, [rsp+0x50]
0000796da41daaec  vmovaps xmm7, [rsp+0x60]
0000796da41daaf2  vmovaps xmm8, [rsp+0x70]
0000796da41daaf8  vmovaps xmm9, [rsp+0x80]
0000796da41dab01  vmovaps xmm10, [rsp+0x90]
0000796da41dab0a  vmovaps xmm11, [rsp+0xA0]
0000796da41dab13  vmovaps xmm12, [rsp+0xB0]
0000796da41dab1c  vmovaps xmm13, [rsp+0xC0]
0000796da41dab25  vmovaps xmm14, [rsp+0xD0]
0000796da41dab2e  vmovaps xmm15, [rsp+0xE0]
0000796da41dab37  add rsp, 0xF0
0000796da41dab3e  pop r11
0000796da41dab40  pop r10
0000796da41dab42  pop r9
0000796da41dab44  pop r8
0000796da41dab46  pop rsi
0000796da41dab47  pop rdi
0000796da41dab48  pop rdx
0000796da41dab49  pop rcx
0000796da41dab4a  pop rax
0000796da41dab4b  add rsp, 0x08
0000796da41dab4f  jmp 0x0000796DA41D8ED9
0000796da41dab54  call 0x0000796DA40E5820
0000796da41dab59  jmp 0x0000796DA41D8EE6
0000796da41dab5e  sub rsp, 0x08
0000796da41dab62  push rax
0000796da41dab63  push rcx
0000796da41dab64  push rdx
0000796da41dab65  push rdi
0000796da41dab66  push rsi
0000796da41dab67  push r8
0000796da41dab69  push r9
0000796da41dab6b  push r10
0000796da41dab6d  push r11
0000796da41dab6f  sub rsp, 0xF0
0000796da41dab76  vmovaps [rsp], xmm0
0000796da41dab7b  vmovaps [rsp+0x10], xmm1
0000796da41dab81  vmovaps [rsp+0x20], xmm2
0000796da41dab87  vmovaps [rsp+0x30], xmm4
0000796da41dab8d  vmovaps [rsp+0x40], xmm5
0000796da41dab93  vmovaps [rsp+0x50], xmm6
0000796da41dab99  vmovaps [rsp+0x60], xmm7
0000796da41dab9f  vmovaps [rsp+0x70], xmm8
0000796da41daba5  vmovaps [rsp+0x80], xmm9
0000796da41dabae  vmovaps [rsp+0x90], xmm10
0000796da41dabb7  vmovaps [rsp+0xA0], xmm11
0000796da41dabc0  vmovaps [rsp+0xB0], xmm12
0000796da41dabc9  vmovaps [rsp+0xC0], xmm13
0000796da41dabd2  vmovaps [rsp+0xD0], xmm14
0000796da41dabdb  vmovaps [rsp+0xE0], xmm15
0000796da41dabe4  sub rsp, 0x30
0000796da41dabe8  movaps [rsp], xmm3
0000796da41dabec  movaps [rsp+0x10], xmm1
0000796da41dabf1  movaps [rsp+0x20], xmm9
0000796da41dabf7  lea rdi, [rsp]
0000796da41dabfb  mov esi, 0x00
0000796da41dac00  mov rax, 0x5E26CB66A530
0000796da41dac0a  call rax
0000796da41dac0c  movaps xmm3, [rsp]
0000796da41dac10  add rsp, 0x30
0000796da41dac14  vmovaps xmm0, [rsp]
0000796da41dac19  vmovaps xmm1, [rsp+0x10]
0000796da41dac1f  vmovaps xmm2, [rsp+0x20]
0000796da41dac25  vmovaps xmm4, [rsp+0x30]
0000796da41dac2b  vmovaps xmm5, [rsp+0x40]
0000796da41dac31  vmovaps xmm6, [rsp+0x50]
0000796da41dac37  vmovaps xmm7, [rsp+0x60]
0000796da41dac3d  vmovaps xmm8, [rsp+0x70]
0000796da41dac43  vmovaps xmm9, [rsp+0x80]
0000796da41dac4c  vmovaps xmm10, [rsp+0x90]
0000796da41dac55  vmovaps xmm11, [rsp+0xA0]
0000796da41dac5e  vmovaps xmm12, [rsp+0xB0]
0000796da41dac67  vmovaps xmm13, [rsp+0xC0]
0000796da41dac70  vmovaps xmm14, [rsp+0xD0]
0000796da41dac79  vmovaps xmm15, [rsp+0xE0]
0000796da41dac82  add rsp, 0xF0
0000796da41dac89  pop r11
0000796da41dac8b  pop r10
0000796da41dac8d  pop r9
0000796da41dac8f  pop r8
0000796da41dac91  pop rsi
0000796da41dac92  pop rdi
0000796da41dac93  pop rdx
0000796da41dac94  pop rcx
0000796da41dac95  pop rax
0000796da41dac96  add rsp, 0x08
0000796da41dac9a  jmp 0x0000796DA41D8F23
0000796da41dac9f  sub rsp, 0x08
0000796da41daca3  push rax
0000796da41daca4  push rcx
0000796da41daca5  push rdx
0000796da41daca6  push rdi
0000796da41daca7  push rsi
0000796da41daca8  push r8
0000796da41dacaa  push r9
0000796da41dacac  push r10
0000796da41dacae  push r11
0000796da41dacb0  sub rsp, 0xF0
0000796da41dacb7  vmovaps [rsp], xmm0
0000796da41dacbc  vmovaps [rsp+0x10], xmm2
0000796da41dacc2  vmovaps [rsp+0x20], xmm3
0000796da41dacc8  vmovaps [rsp+0x30], xmm4
0000796da41dacce  vmovaps [rsp+0x40], xmm5
0000796da41dacd4  vmovaps [rsp+0x50], xmm6
0000796da41dacda  vmovaps [rsp+0x60], xmm7
0000796da41dace0  vmovaps [rsp+0x70], xmm8
0000796da41dace6  vmovaps [rsp+0x80], xmm9
0000796da41dacef  vmovaps [rsp+0x90], xmm10
0000796da41dacf8  vmovaps [rsp+0xA0], xmm11
0000796da41dad01  vmovaps [rsp+0xB0], xmm12
0000796da41dad0a  vmovaps [rsp+0xC0], xmm13
0000796da41dad13  vmovaps [rsp+0xD0], xmm14
0000796da41dad1c  vmovaps [rsp+0xE0], xmm15
0000796da41dad25  sub rsp, 0x30
0000796da41dad29  movaps [rsp], xmm1
0000796da41dad2d  movaps [rsp+0x10], xmm15
0000796da41dad33  movaps [rsp+0x20], xmm9
0000796da41dad39  lea rdi, [rsp]
0000796da41dad3d  mov esi, 0x00
0000796da41dad42  mov rax, 0x5E26CB66A530
0000796da41dad4c  call rax
0000796da41dad4e  movaps xmm1, [rsp]
0000796da41dad52  add rsp, 0x30
0000796da41dad56  vmovaps xmm0, [rsp]
0000796da41dad5b  vmovaps xmm2, [rsp+0x10]
0000796da41dad61  vmovaps xmm3, [rsp+0x20]
0000796da41dad67  vmovaps xmm4, [rsp+0x30]
0000796da41dad6d  vmovaps xmm5, [rsp+0x40]
0000796da41dad73  vmovaps xmm6, [rsp+0x50]
0000796da41dad79  vmovaps xmm7, [rsp+0x60]
0000796da41dad7f  vmovaps xmm8, [rsp+0x70]
0000796da41dad85  vmovaps xmm9, [rsp+0x80]
0000796da41dad8e  vmovaps xmm10, [rsp+0x90]
0000796da41dad97  vmovaps xmm11, [rsp+0xA0]
0000796da41dada0  vmovaps xmm12, [rsp+0xB0]
0000796da41dada9  vmovaps xmm13, [rsp+0xC0]
0000796da41dadb2  vmovaps xmm14, [rsp+0xD0]
0000796da41dadbb  vmovaps xmm15, [rsp+0xE0]
0000796da41dadc4  add rsp, 0xF0
0000796da41dadcb  pop r11
0000796da41dadcd  pop r10
0000796da41dadcf  pop r9
0000796da41dadd1  pop r8
0000796da41dadd3  pop rsi
0000796da41dadd4  pop rdi
0000796da41dadd5  pop rdx
0000796da41dadd6  pop rcx
0000796da41dadd7  pop rax
0000796da41dadd8  add rsp, 0x08
0000796da41daddc  jmp 0x0000796DA41D8FAB
0000796da41dade1  call 0x0000796DA40E5820
0000796da41dade6  jmp 0x0000796DA41D8FB8
0000796da41dadeb  sub rsp, 0x08
0000796da41dadef  push rax
0000796da41dadf0  push rcx
0000796da41dadf1  push rdx
0000796da41dadf2  push rdi
0000796da41dadf3  push rsi
0000796da41dadf4  push r8
0000796da41dadf6  push r9
0000796da41dadf8  push r10
0000796da41dadfa  push r11
0000796da41dadfc  sub rsp, 0xF0
0000796da41dae03  vmovaps [rsp], xmm0
0000796da41dae08  vmovaps [rsp+0x10], xmm2
0000796da41dae0e  vmovaps [rsp+0x20], xmm3
0000796da41dae14  vmovaps [rsp+0x30], xmm4
0000796da41dae1a  vmovaps [rsp+0x40], xmm5
0000796da41dae20  vmovaps [rsp+0x50], xmm6
0000796da41dae26  vmovaps [rsp+0x60], xmm7
0000796da41dae2c  vmovaps [rsp+0x70], xmm8
0000796da41dae32  vmovaps [rsp+0x80], xmm9
0000796da41dae3b  vmovaps [rsp+0x90], xmm10
0000796da41dae44  vmovaps [rsp+0xA0], xmm11
0000796da41dae4d  vmovaps [rsp+0xB0], xmm12
0000796da41dae56  vmovaps [rsp+0xC0], xmm13
0000796da41dae5f  vmovaps [rsp+0xD0], xmm14
0000796da41dae68  vmovaps [rsp+0xE0], xmm15
0000796da41dae71  sub rsp, 0x30
0000796da41dae75  movaps [rsp], xmm1
0000796da41dae79  movaps [rsp+0x10], xmm5
0000796da41dae7e  movaps [rsp+0x20], xmm7
0000796da41dae83  lea rdi, [rsp]
0000796da41dae87  mov esi, 0x00
0000796da41dae8c  mov rax, 0x5E26CB66A530
0000796da41dae96  call rax
0000796da41dae98  movaps xmm1, [rsp]
0000796da41dae9c  add rsp, 0x30
0000796da41daea0  vmovaps xmm0, [rsp]
0000796da41daea5  vmovaps xmm2, [rsp+0x10]
0000796da41daeab  vmovaps xmm3, [rsp+0x20]
0000796da41daeb1  vmovaps xmm4, [rsp+0x30]
0000796da41daeb7  vmovaps xmm5, [rsp+0x40]
0000796da41daebd  vmovaps xmm6, [rsp+0x50]
0000796da41daec3  vmovaps xmm7, [rsp+0x60]
0000796da41daec9  vmovaps xmm8, [rsp+0x70]
0000796da41daecf  vmovaps xmm9, [rsp+0x80]
0000796da41daed8  vmovaps xmm10, [rsp+0x90]
0000796da41daee1  vmovaps xmm11, [rsp+0xA0]
0000796da41daeea  vmovaps xmm12, [rsp+0xB0]
0000796da41daef3  vmovaps xmm13, [rsp+0xC0]
0000796da41daefc  vmovaps xmm14, [rsp+0xD0]
0000796da41daf05  vmovaps xmm15, [rsp+0xE0]
0000796da41daf0e  add rsp, 0xF0
0000796da41daf15  pop r11
0000796da41daf17  pop r10
0000796da41daf19  pop r9
0000796da41daf1b  pop r8
0000796da41daf1d  pop rsi
0000796da41daf1e  pop rdi
0000796da41daf1f  pop rdx
0000796da41daf20  pop rcx
0000796da41daf21  pop rax
0000796da41daf22  add rsp, 0x08
0000796da41daf26  jmp 0x0000796DA41D905D
0000796da41daf2b  sub rsp, 0x08
0000796da41daf2f  push rax
0000796da41daf30  push rcx
0000796da41daf31  push rdx
0000796da41daf32  push rdi
0000796da41daf33  push rsi
0000796da41daf34  push r8
0000796da41daf36  push r9
0000796da41daf38  push r10
0000796da41daf3a  push r11
0000796da41daf3c  sub rsp, 0xF0
0000796da41daf43  vmovaps [rsp], xmm0
0000796da41daf48  vmovaps [rsp+0x10], xmm1
0000796da41daf4e  vmovaps [rsp+0x20], xmm2
0000796da41daf54  vmovaps [rsp+0x30], xmm3
0000796da41daf5a  vmovaps [rsp+0x40], xmm4
0000796da41daf60  vmovaps [rsp+0x50], xmm5
0000796da41daf66  vmovaps [rsp+0x60], xmm6
0000796da41daf6c  vmovaps [rsp+0x70], xmm8
0000796da41daf72  vmovaps [rsp+0x80], xmm9
0000796da41daf7b  vmovaps [rsp+0x90], xmm10
0000796da41daf84  vmovaps [rsp+0xA0], xmm11
0000796da41daf8d  vmovaps [rsp+0xB0], xmm12
0000796da41daf96  vmovaps [rsp+0xC0], xmm13
0000796da41daf9f  vmovaps [rsp+0xD0], xmm14
0000796da41dafa8  vmovaps [rsp+0xE0], xmm15
0000796da41dafb1  sub rsp, 0x30
0000796da41dafb5  movaps [rsp], xmm7
0000796da41dafb9  movaps [rsp+0x10], xmm5
0000796da41dafbe  movaps [rsp+0x20], xmm15
0000796da41dafc4  lea rdi, [rsp]
0000796da41dafc8  mov esi, 0x00
0000796da41dafcd  mov rax, 0x5E26CB66A530
0000796da41dafd7  call rax
0000796da41dafd9  movaps xmm7, [rsp]
0000796da41dafdd  add rsp, 0x30
0000796da41dafe1  vmovaps xmm0, [rsp]
0000796da41dafe6  vmovaps xmm1, [rsp+0x10]
0000796da41dafec  vmovaps xmm2, [rsp+0x20]
0000796da41daff2  vmovaps xmm3, [rsp+0x30]
0000796da41daff8  vmovaps xmm4, [rsp+0x40]
0000796da41daffe  vmovaps xmm5, [rsp+0x50]
0000796da41db004  vmovaps xmm6, [rsp+0x60]
0000796da41db00a  vmovaps xmm8, [rsp+0x70]
0000796da41db010  vmovaps xmm9, [rsp+0x80]
0000796da41db019  vmovaps xmm10, [rsp+0x90]
0000796da41db022  vmovaps xmm11, [rsp+0xA0]
0000796da41db02b  vmovaps xmm12, [rsp+0xB0]
0000796da41db034  vmovaps xmm13, [rsp+0xC0]
0000796da41db03d  vmovaps xmm14, [rsp+0xD0]
0000796da41db046  vmovaps xmm15, [rsp+0xE0]
0000796da41db04f  add rsp, 0xF0
0000796da41db056  pop r11
0000796da41db058  pop r10
0000796da41db05a  pop r9
0000796da41db05c  pop r8
0000796da41db05e  pop rsi
0000796da41db05f  pop rdi
0000796da41db060  pop rdx
0000796da41db061  pop rcx
0000796da41db062  pop rax
0000796da41db063  add rsp, 0x08
0000796da41db067  jmp 0x0000796DA41D9093
0000796da41db06c  call 0x0000796DA40D64F0
0000796da41db071  jmp 0x0000796DA41D90A0
0000796da41db076  sub rsp, 0x08
0000796da41db07a  push rax
0000796da41db07b  push rcx
0000796da41db07c  push rdx
0000796da41db07d  push rdi
0000796da41db07e  push rsi
0000796da41db07f  push r8
0000796da41db081  push r9
0000796da41db083  push r10
0000796da41db085  push r11
0000796da41db087  sub rsp, 0xF0
0000796da41db08e  vmovaps [rsp], xmm0
0000796da41db093  vmovaps [rsp+0x10], xmm1
0000796da41db099  vmovaps [rsp+0x20], xmm2
0000796da41db09f  vmovaps [rsp+0x30], xmm3
0000796da41db0a5  vmovaps [rsp+0x40], xmm4
0000796da41db0ab  vmovaps [rsp+0x50], xmm5
0000796da41db0b1  vmovaps [rsp+0x60], xmm6
0000796da41db0b7  vmovaps [rsp+0x70], xmm7
0000796da41db0bd  vmovaps [rsp+0x80], xmm8
0000796da41db0c6  vmovaps [rsp+0x90], xmm9
0000796da41db0cf  vmovaps [rsp+0xA0], xmm10
0000796da41db0d8  vmovaps [rsp+0xB0], xmm11
0000796da41db0e1  vmovaps [rsp+0xC0], xmm12
0000796da41db0ea  vmovaps [rsp+0xD0], xmm13
0000796da41db0f3  vmovaps [rsp+0xE0], xmm14
0000796da41db0fc  sub rsp, 0x30
0000796da41db100  movaps [rsp], xmm15
0000796da41db105  movaps [rsp+0x10], xmm5
0000796da41db10a  movaps [rsp+0x20], xmm3
0000796da41db10f  lea rdi, [rsp]
0000796da41db113  mov esi, 0x00
0000796da41db118  mov rax, 0x5E26CB66A530
0000796da41db122  call rax
0000796da41db124  movaps xmm15, [rsp]
0000796da41db129  add rsp, 0x30
0000796da41db12d  vmovaps xmm0, [rsp]
0000796da41db132  vmovaps xmm1, [rsp+0x10]
0000796da41db138  vmovaps xmm2, [rsp+0x20]
0000796da41db13e  vmovaps xmm3, [rsp+0x30]
0000796da41db144  vmovaps xmm4, [rsp+0x40]
0000796da41db14a  vmovaps xmm5, [rsp+0x50]
0000796da41db150  vmovaps xmm6, [rsp+0x60]
0000796da41db156  vmovaps xmm7, [rsp+0x70]
0000796da41db15c  vmovaps xmm8, [rsp+0x80]
0000796da41db165  vmovaps xmm9, [rsp+0x90]
0000796da41db16e  vmovaps xmm10, [rsp+0xA0]
0000796da41db177  vmovaps xmm11, [rsp+0xB0]
0000796da41db180  vmovaps xmm12, [rsp+0xC0]
0000796da41db189  vmovaps xmm13, [rsp+0xD0]
0000796da41db192  vmovaps xmm14, [rsp+0xE0]
0000796da41db19b  add rsp, 0xF0
0000796da41db1a2  pop r11
0000796da41db1a4  pop r10
0000796da41db1a6  pop r9
0000796da41db1a8  pop r8
0000796da41db1aa  pop rsi
0000796da41db1ab  pop rdi
0000796da41db1ac  pop rdx
0000796da41db1ad  pop rcx
0000796da41db1ae  pop rax
0000796da41db1af  add rsp, 0x08
0000796da41db1b3  jmp 0x0000796DA41D90C6
0000796da41db1b8  sub rsp, 0x08
0000796da41db1bc  push rax
0000796da41db1bd  push rcx
0000796da41db1be  push rdx
0000796da41db1bf  push rdi
0000796da41db1c0  push rsi
0000796da41db1c1  push r8
0000796da41db1c3  push r9
0000796da41db1c5  push r10
0000796da41db1c7  push r11
0000796da41db1c9  sub rsp, 0xF0
0000796da41db1d0  vmovaps [rsp], xmm0
0000796da41db1d5  vmovaps [rsp+0x10], xmm2
0000796da41db1db  vmovaps [rsp+0x20], xmm3
0000796da41db1e1  vmovaps [rsp+0x30], xmm4
0000796da41db1e7  vmovaps [rsp+0x40], xmm5
0000796da41db1ed  vmovaps [rsp+0x50], xmm6
0000796da41db1f3  vmovaps [rsp+0x60], xmm7
0000796da41db1f9  vmovaps [rsp+0x70], xmm8
0000796da41db1ff  vmovaps [rsp+0x80], xmm9
0000796da41db208  vmovaps [rsp+0x90], xmm10
0000796da41db211  vmovaps [rsp+0xA0], xmm11
0000796da41db21a  vmovaps [rsp+0xB0], xmm12
0000796da41db223  vmovaps [rsp+0xC0], xmm13
0000796da41db22c  vmovaps [rsp+0xD0], xmm14
0000796da41db235  vmovaps [rsp+0xE0], xmm15
0000796da41db23e  sub rsp, 0x30
0000796da41db242  movaps [rsp], xmm1
0000796da41db246  movaps [rsp+0x10], xmm5
0000796da41db24b  movaps [rsp+0x20], xmm4
0000796da41db250  lea rdi, [rsp]
0000796da41db254  mov esi, 0x00
0000796da41db259  mov rax, 0x5E26CB66A530
0000796da41db263  call rax
0000796da41db265  movaps xmm1, [rsp]
0000796da41db269  add rsp, 0x30
0000796da41db26d  vmovaps xmm0, [rsp]
0000796da41db272  vmovaps xmm2, [rsp+0x10]
0000796da41db278  vmovaps xmm3, [rsp+0x20]
0000796da41db27e  vmovaps xmm4, [rsp+0x30]
0000796da41db284  vmovaps xmm5, [rsp+0x40]
0000796da41db28a  vmovaps xmm6, [rsp+0x50]
0000796da41db290  vmovaps xmm7, [rsp+0x60]
0000796da41db296  vmovaps xmm8, [rsp+0x70]
0000796da41db29c  vmovaps xmm9, [rsp+0x80]
0000796da41db2a5  vmovaps xmm10, [rsp+0x90]
0000796da41db2ae  vmovaps xmm11, [rsp+0xA0]
0000796da41db2b7  vmovaps xmm12, [rsp+0xB0]
0000796da41db2c0  vmovaps xmm13, [rsp+0xC0]
0000796da41db2c9  vmovaps xmm14, [rsp+0xD0]
0000796da41db2d2  vmovaps xmm15, [rsp+0xE0]
0000796da41db2db  add rsp, 0xF0
0000796da41db2e2  pop r11
0000796da41db2e4  pop r10
0000796da41db2e6  pop r9
0000796da41db2e8  pop r8
0000796da41db2ea  pop rsi
0000796da41db2eb  pop rdi
0000796da41db2ec  pop rdx
0000796da41db2ed  pop rcx
0000796da41db2ee  pop rax
0000796da41db2ef  add rsp, 0x08
0000796da41db2f3  jmp 0x0000796DA41D90E6
0000796da41db2f8  sub rsp, 0x08
0000796da41db2fc  push rax
0000796da41db2fd  push rcx
0000796da41db2fe  push rdx
0000796da41db2ff  push rdi
0000796da41db300  push rsi
0000796da41db301  push r8
0000796da41db303  push r9
0000796da41db305  push r10
0000796da41db307  push r11
0000796da41db309  sub rsp, 0xF0
0000796da41db310  vmovaps [rsp], xmm0
0000796da41db315  vmovaps [rsp+0x10], xmm1
0000796da41db31b  vmovaps [rsp+0x20], xmm2
0000796da41db321  vmovaps [rsp+0x30], xmm3
0000796da41db327  vmovaps [rsp+0x40], xmm5
0000796da41db32d  vmovaps [rsp+0x50], xmm6
0000796da41db333  vmovaps [rsp+0x60], xmm7
0000796da41db339  vmovaps [rsp+0x70], xmm8
0000796da41db33f  vmovaps [rsp+0x80], xmm9
0000796da41db348  vmovaps [rsp+0x90], xmm10
0000796da41db351  vmovaps [rsp+0xA0], xmm11
0000796da41db35a  vmovaps [rsp+0xB0], xmm12
0000796da41db363  vmovaps [rsp+0xC0], xmm13
0000796da41db36c  vmovaps [rsp+0xD0], xmm14
0000796da41db375  vmovaps [rsp+0xE0], xmm15
0000796da41db37e  sub rsp, 0x30
0000796da41db382  movaps [rsp], xmm4
0000796da41db386  movaps [rsp+0x10], xmm3
0000796da41db38b  movaps [rsp+0x20], xmm5
0000796da41db390  lea rdi, [rsp]
0000796da41db394  mov esi, 0x00
0000796da41db399  mov rax, 0x5E26CB66A530
0000796da41db3a3  call rax
0000796da41db3a5  movaps xmm4, [rsp]
0000796da41db3a9  add rsp, 0x30
0000796da41db3ad  vmovaps xmm0, [rsp]
0000796da41db3b2  vmovaps xmm1, [rsp+0x10]
0000796da41db3b8  vmovaps xmm2, [rsp+0x20]
0000796da41db3be  vmovaps xmm3, [rsp+0x30]
0000796da41db3c4  vmovaps xmm5, [rsp+0x40]
0000796da41db3ca  vmovaps xmm6, [rsp+0x50]
0000796da41db3d0  vmovaps xmm7, [rsp+0x60]
0000796da41db3d6  vmovaps xmm8, [rsp+0x70]
0000796da41db3dc  vmovaps xmm9, [rsp+0x80]
0000796da41db3e5  vmovaps xmm10, [rsp+0x90]
0000796da41db3ee  vmovaps xmm11, [rsp+0xA0]
0000796da41db3f7  vmovaps xmm12, [rsp+0xB0]
0000796da41db400  vmovaps xmm13, [rsp+0xC0]
0000796da41db409  vmovaps xmm14, [rsp+0xD0]
0000796da41db412  vmovaps xmm15, [rsp+0xE0]
0000796da41db41b  add rsp, 0xF0
0000796da41db422  pop r11
0000796da41db424  pop r10
0000796da41db426  pop r9
0000796da41db428  pop r8
0000796da41db42a  pop rsi
0000796da41db42b  pop rdi
0000796da41db42c  pop rdx
0000796da41db42d  pop rcx
0000796da41db42e  pop rax
0000796da41db42f  add rsp, 0x08
0000796da41db433  jmp 0x0000796DA41D9134
0000796da41db438  call 0x0000796DA40D64F0
0000796da41db43d  jmp 0x0000796DA41D9141
0000796da41db442  sub rsp, 0x08
0000796da41db446  push rax
0000796da41db447  push rcx
0000796da41db448  push rdx
0000796da41db449  push rdi
0000796da41db44a  push rsi
0000796da41db44b  push r8
0000796da41db44d  push r9
0000796da41db44f  push r10
0000796da41db451  push r11
0000796da41db453  sub rsp, 0xF0
0000796da41db45a  vmovaps [rsp], xmm0
0000796da41db45f  vmovaps [rsp+0x10], xmm1
0000796da41db465  vmovaps [rsp+0x20], xmm2
0000796da41db46b  vmovaps [rsp+0x30], xmm3
0000796da41db471  vmovaps [rsp+0x40], xmm4
0000796da41db477  vmovaps [rsp+0x50], xmm6
0000796da41db47d  vmovaps [rsp+0x60], xmm7
0000796da41db483  vmovaps [rsp+0x70], xmm8
0000796da41db489  vmovaps [rsp+0x80], xmm9
0000796da41db492  vmovaps [rsp+0x90], xmm10
0000796da41db49b  vmovaps [rsp+0xA0], xmm11
0000796da41db4a4  vmovaps [rsp+0xB0], xmm12
0000796da41db4ad  vmovaps [rsp+0xC0], xmm13
0000796da41db4b6  vmovaps [rsp+0xD0], xmm14
0000796da41db4bf  vmovaps [rsp+0xE0], xmm15
0000796da41db4c8  sub rsp, 0x30
0000796da41db4cc  movaps [rsp], xmm5
0000796da41db4d0  movaps [rsp+0x10], xmm6
0000796da41db4d5  movaps [rsp+0x20], xmm3
0000796da41db4da  lea rdi, [rsp]
0000796da41db4de  mov esi, 0x00
0000796da41db4e3  mov rax, 0x5E26CB66A530
0000796da41db4ed  call rax
0000796da41db4ef  movaps xmm5, [rsp]
0000796da41db4f3  add rsp, 0x30
0000796da41db4f7  vmovaps xmm0, [rsp]
0000796da41db4fc  vmovaps xmm1, [rsp+0x10]
0000796da41db502  vmovaps xmm2, [rsp+0x20]
0000796da41db508  vmovaps xmm3, [rsp+0x30]
0000796da41db50e  vmovaps xmm4, [rsp+0x40]
0000796da41db514  vmovaps xmm6, [rsp+0x50]
0000796da41db51a  vmovaps xmm7, [rsp+0x60]
0000796da41db520  vmovaps xmm8, [rsp+0x70]
0000796da41db526  vmovaps xmm9, [rsp+0x80]
0000796da41db52f  vmovaps xmm10, [rsp+0x90]
0000796da41db538  vmovaps xmm11, [rsp+0xA0]
0000796da41db541  vmovaps xmm12, [rsp+0xB0]
0000796da41db54a  vmovaps xmm13, [rsp+0xC0]
0000796da41db553  vmovaps xmm14, [rsp+0xD0]
0000796da41db55c  vmovaps xmm15, [rsp+0xE0]
0000796da41db565  add rsp, 0xF0
0000796da41db56c  pop r11
0000796da41db56e  pop r10
0000796da41db570  pop r9
0000796da41db572  pop r8
0000796da41db574  pop rsi
0000796da41db575  pop rdi
0000796da41db576  pop rdx
0000796da41db577  pop rcx
0000796da41db578  pop rax
0000796da41db579  add rsp, 0x08
0000796da41db57d  jmp 0x0000796DA41D9167
0000796da41db582  sub rsp, 0x08
0000796da41db586  push rax
0000796da41db587  push rcx
0000796da41db588  push rdx
0000796da41db589  push rdi
0000796da41db58a  push rsi
0000796da41db58b  push r8
0000796da41db58d  push r9
0000796da41db58f  push r10
0000796da41db591  push r11
0000796da41db593  sub rsp, 0xF0
0000796da41db59a  vmovaps [rsp], xmm0
0000796da41db59f  vmovaps [rsp+0x10], xmm1
0000796da41db5a5  vmovaps [rsp+0x20], xmm2
0000796da41db5ab  vmovaps [rsp+0x30], xmm3
0000796da41db5b1  vmovaps [rsp+0x40], xmm4
0000796da41db5b7  vmovaps [rsp+0x50], xmm5
0000796da41db5bd  vmovaps [rsp+0x60], xmm7
0000796da41db5c3  vmovaps [rsp+0x70], xmm8
0000796da41db5c9  vmovaps [rsp+0x80], xmm9
0000796da41db5d2  vmovaps [rsp+0x90], xmm10
0000796da41db5db  vmovaps [rsp+0xA0], xmm11
0000796da41db5e4  vmovaps [rsp+0xB0], xmm12
0000796da41db5ed  vmovaps [rsp+0xC0], xmm13
0000796da41db5f6  vmovaps [rsp+0xD0], xmm14
0000796da41db5ff  vmovaps [rsp+0xE0], xmm15
0000796da41db608  sub rsp, 0x30
0000796da41db60c  movaps [rsp], xmm6
0000796da41db610  movaps [rsp+0x10], xmm9
0000796da41db616  movaps [rsp+0x20], xmm1
0000796da41db61b  lea rdi, [rsp]
0000796da41db61f  mov esi, 0x00
0000796da41db624  mov rax, 0x5E26CB66A530
0000796da41db62e  call rax
0000796da41db630  movaps xmm6, [rsp]
0000796da41db634  add rsp, 0x30
0000796da41db638  vmovaps xmm0, [rsp]
0000796da41db63d  vmovaps xmm1, [rsp+0x10]
0000796da41db643  vmovaps xmm2, [rsp+0x20]
0000796da41db649  vmovaps xmm3, [rsp+0x30]
0000796da41db64f  vmovaps xmm4, [rsp+0x40]
0000796da41db655  vmovaps xmm5, [rsp+0x50]
0000796da41db65b  vmovaps xmm7, [rsp+0x60]
0000796da41db661  vmovaps xmm8, [rsp+0x70]
0000796da41db667  vmovaps xmm9, [rsp+0x80]
0000796da41db670  vmovaps xmm10, [rsp+0x90]
0000796da41db679  vmovaps xmm11, [rsp+0xA0]
0000796da41db682  vmovaps xmm12, [rsp+0xB0]
0000796da41db68b  vmovaps xmm13, [rsp+0xC0]
0000796da41db694  vmovaps xmm14, [rsp+0xD0]
0000796da41db69d  vmovaps xmm15, [rsp+0xE0]
0000796da41db6a6  add rsp, 0xF0
0000796da41db6ad  pop r11
0000796da41db6af  pop r10
0000796da41db6b1  pop r9
0000796da41db6b3  pop r8
0000796da41db6b5  pop rsi
0000796da41db6b6  pop rdi
0000796da41db6b7  pop rdx
0000796da41db6b8  pop rcx
0000796da41db6b9  pop rax
0000796da41db6ba  add rsp, 0x08
0000796da41db6be  jmp 0x0000796DA41D918B
0000796da41db6c3  sub rsp, 0x08
0000796da41db6c7  push rax
0000796da41db6c8  push rcx
0000796da41db6c9  push rdx
0000796da41db6ca  push rdi
0000796da41db6cb  push rsi
0000796da41db6cc  push r8
0000796da41db6ce  push r9
0000796da41db6d0  push r10
0000796da41db6d2  push r11
0000796da41db6d4  sub rsp, 0xF0
0000796da41db6db  vmovaps [rsp], xmm0
0000796da41db6e0  vmovaps [rsp+0x10], xmm1
0000796da41db6e6  vmovaps [rsp+0x20], xmm2
0000796da41db6ec  vmovaps [rsp+0x30], xmm3
0000796da41db6f2  vmovaps [rsp+0x40], xmm4
0000796da41db6f8  vmovaps [rsp+0x50], xmm5
0000796da41db6fe  vmovaps [rsp+0x60], xmm6
0000796da41db704  vmovaps [rsp+0x70], xmm7
0000796da41db70a  vmovaps [rsp+0x80], xmm8
0000796da41db713  vmovaps [rsp+0x90], xmm10
0000796da41db71c  vmovaps [rsp+0xA0], xmm11
0000796da41db725  vmovaps [rsp+0xB0], xmm12
0000796da41db72e  vmovaps [rsp+0xC0], xmm13
0000796da41db737  vmovaps [rsp+0xD0], xmm14
0000796da41db740  vmovaps [rsp+0xE0], xmm15
0000796da41db749  sub rsp, 0x30
0000796da41db74d  movaps [rsp], xmm9
0000796da41db752  movaps [rsp+0x10], xmm3
0000796da41db757  movaps [rsp+0x20], xmm1
0000796da41db75c  lea rdi, [rsp]
0000796da41db760  mov esi, 0x00
0000796da41db765  mov rax, 0x5E26CB66A530
0000796da41db76f  call rax
0000796da41db771  movaps xmm9, [rsp]
0000796da41db776  add rsp, 0x30
0000796da41db77a  vmovaps xmm0, [rsp]
0000796da41db77f  vmovaps xmm1, [rsp+0x10]
0000796da41db785  vmovaps xmm2, [rsp+0x20]
0000796da41db78b  vmovaps xmm3, [rsp+0x30]
0000796da41db791  vmovaps xmm4, [rsp+0x40]
0000796da41db797  vmovaps xmm5, [rsp+0x50]
0000796da41db79d  vmovaps xmm6, [rsp+0x60]
0000796da41db7a3  vmovaps xmm7, [rsp+0x70]
0000796da41db7a9  vmovaps xmm8, [rsp+0x80]
0000796da41db7b2  vmovaps xmm10, [rsp+0x90]
0000796da41db7bb  vmovaps xmm11, [rsp+0xA0]
0000796da41db7c4  vmovaps xmm12, [rsp+0xB0]
0000796da41db7cd  vmovaps xmm13, [rsp+0xC0]
0000796da41db7d6  vmovaps xmm14, [rsp+0xD0]
0000796da41db7df  vmovaps xmm15, [rsp+0xE0]
0000796da41db7e8  add rsp, 0xF0
0000796da41db7ef  pop r11
0000796da41db7f1  pop r10
0000796da41db7f3  pop r9
0000796da41db7f5  pop r8
0000796da41db7f7  pop rsi
0000796da41db7f8  pop rdi
0000796da41db7f9  pop rdx
0000796da41db7fa  pop rcx
0000796da41db7fb  pop rax
0000796da41db7fc  add rsp, 0x08
0000796da41db800  jmp 0x0000796DA41D91D7
0000796da41db805  call 0x0000796DA40D64F0
0000796da41db80a  jmp 0x0000796DA41D91E4
0000796da41db80f  sub rsp, 0x08
0000796da41db813  push rax
0000796da41db814  push rcx
0000796da41db815  push rdx
0000796da41db816  push rdi
0000796da41db817  push rsi
0000796da41db818  push r8
0000796da41db81a  push r9
0000796da41db81c  push r10
0000796da41db81e  push r11
0000796da41db820  sub rsp, 0xF0
0000796da41db827  vmovaps [rsp], xmm0
0000796da41db82c  vmovaps [rsp+0x10], xmm1
0000796da41db832  vmovaps [rsp+0x20], xmm2
0000796da41db838  vmovaps [rsp+0x30], xmm3
0000796da41db83e  vmovaps [rsp+0x40], xmm4
0000796da41db844  vmovaps [rsp+0x50], xmm5
0000796da41db84a  vmovaps [rsp+0x60], xmm6
0000796da41db850  vmovaps [rsp+0x70], xmm7
0000796da41db856  vmovaps [rsp+0x80], xmm8
0000796da41db85f  vmovaps [rsp+0x90], xmm9
0000796da41db868  vmovaps [rsp+0xA0], xmm10
0000796da41db871  vmovaps [rsp+0xB0], xmm11
0000796da41db87a  vmovaps [rsp+0xC0], xmm12
0000796da41db883  vmovaps [rsp+0xD0], xmm13
0000796da41db88c  vmovaps [rsp+0xE0], xmm14
0000796da41db895  sub rsp, 0x30
0000796da41db899  movaps [rsp], xmm15
0000796da41db89e  movaps [rsp+0x10], xmm3
0000796da41db8a3  movaps [rsp+0x20], xmm7
0000796da41db8a8  lea rdi, [rsp]
0000796da41db8ac  mov esi, 0x00
0000796da41db8b1  mov rax, 0x5E26CB66A530
0000796da41db8bb  call rax
0000796da41db8bd  movaps xmm15, [rsp]
0000796da41db8c2  add rsp, 0x30
0000796da41db8c6  vmovaps xmm0, [rsp]
0000796da41db8cb  vmovaps xmm1, [rsp+0x10]
0000796da41db8d1  vmovaps xmm2, [rsp+0x20]
0000796da41db8d7  vmovaps xmm3, [rsp+0x30]
0000796da41db8dd  vmovaps xmm4, [rsp+0x40]
0000796da41db8e3  vmovaps xmm5, [rsp+0x50]
0000796da41db8e9  vmovaps xmm6, [rsp+0x60]
0000796da41db8ef  vmovaps xmm7, [rsp+0x70]
0000796da41db8f5  vmovaps xmm8, [rsp+0x80]
0000796da41db8fe  vmovaps xmm9, [rsp+0x90]
0000796da41db907  vmovaps xmm10, [rsp+0xA0]
0000796da41db910  vmovaps xmm11, [rsp+0xB0]
0000796da41db919  vmovaps xmm12, [rsp+0xC0]
0000796da41db922  vmovaps xmm13, [rsp+0xD0]
0000796da41db92b  vmovaps xmm14, [rsp+0xE0]
0000796da41db934  add rsp, 0xF0
0000796da41db93b  pop r11
0000796da41db93d  pop r10
0000796da41db93f  pop r9
0000796da41db941  pop r8
0000796da41db943  pop rsi
0000796da41db944  pop rdi
0000796da41db945  pop rdx
0000796da41db946  pop rcx
0000796da41db947  pop rax
0000796da41db948  add rsp, 0x08
0000796da41db94c  jmp 0x0000796DA41D9210
0000796da41db951  sub rsp, 0x08
0000796da41db955  push rax
0000796da41db956  push rcx
0000796da41db957  push rdx
0000796da41db958  push rdi
0000796da41db959  push rsi
0000796da41db95a  push r8
0000796da41db95c  push r9
0000796da41db95e  push r10
0000796da41db960  push r11
0000796da41db962  sub rsp, 0xF0
0000796da41db969  vmovaps [rsp], xmm0
0000796da41db96e  vmovaps [rsp+0x10], xmm1
0000796da41db974  vmovaps [rsp+0x20], xmm2
0000796da41db97a  vmovaps [rsp+0x30], xmm4
0000796da41db980  vmovaps [rsp+0x40], xmm5
0000796da41db986  vmovaps [rsp+0x50], xmm6
0000796da41db98c  vmovaps [rsp+0x60], xmm7
0000796da41db992  vmovaps [rsp+0x70], xmm8
0000796da41db998  vmovaps [rsp+0x80], xmm9
0000796da41db9a1  vmovaps [rsp+0x90], xmm10
0000796da41db9aa  vmovaps [rsp+0xA0], xmm11
0000796da41db9b3  vmovaps [rsp+0xB0], xmm12
0000796da41db9bc  vmovaps [rsp+0xC0], xmm13
0000796da41db9c5  vmovaps [rsp+0xD0], xmm14
0000796da41db9ce  vmovaps [rsp+0xE0], xmm15
0000796da41db9d7  sub rsp, 0x30
0000796da41db9db  movaps [rsp], xmm3
0000796da41db9df  movaps [rsp+0x10], xmm1
0000796da41db9e4  movaps [rsp+0x20], xmm15
0000796da41db9ea  lea rdi, [rsp]
0000796da41db9ee  mov esi, 0x00
0000796da41db9f3  mov rax, 0x5E26CB66A530
0000796da41db9fd  call rax
0000796da41db9ff  movaps xmm3, [rsp]
0000796da41dba03  add rsp, 0x30
0000796da41dba07  vmovaps xmm0, [rsp]
0000796da41dba0c  vmovaps xmm1, [rsp+0x10]
0000796da41dba12  vmovaps xmm2, [rsp+0x20]
0000796da41dba18  vmovaps xmm4, [rsp+0x30]
0000796da41dba1e  vmovaps xmm5, [rsp+0x40]
0000796da41dba24  vmovaps xmm6, [rsp+0x50]
0000796da41dba2a  vmovaps xmm7, [rsp+0x60]
0000796da41dba30  vmovaps xmm8, [rsp+0x70]
0000796da41dba36  vmovaps xmm9, [rsp+0x80]
0000796da41dba3f  vmovaps xmm10, [rsp+0x90]
0000796da41dba48  vmovaps xmm11, [rsp+0xA0]
0000796da41dba51  vmovaps xmm12, [rsp+0xB0]
0000796da41dba5a  vmovaps xmm13, [rsp+0xC0]
0000796da41dba63  vmovaps xmm14, [rsp+0xD0]
0000796da41dba6c  vmovaps xmm15, [rsp+0xE0]
0000796da41dba75  add rsp, 0xF0
0000796da41dba7c  pop r11
0000796da41dba7e  pop r10
0000796da41dba80  pop r9
0000796da41dba82  pop r8
0000796da41dba84  pop rsi
0000796da41dba85  pop rdi
0000796da41dba86  pop rdx
0000796da41dba87  pop rcx
0000796da41dba88  pop rax
0000796da41dba89  add rsp, 0x08
0000796da41dba8d  jmp 0x0000796DA41D929F
0000796da41dba92  call 0x0000796DA40D64F0
0000796da41dba97  jmp 0x0000796DA41D92A9
0000796da41dba9c  sub rsp, 0x08
0000796da41dbaa0  push rax
0000796da41dbaa1  push rcx
0000796da41dbaa2  push rdx
0000796da41dbaa3  push rdi
0000796da41dbaa4  push rsi
0000796da41dbaa5  push r8
0000796da41dbaa7  push r9
0000796da41dbaa9  push r10
0000796da41dbaab  push r11
0000796da41dbaad  sub rsp, 0xF0
0000796da41dbab4  vmovaps [rsp], xmm0
0000796da41dbab9  vmovaps [rsp+0x10], xmm1
0000796da41dbabf  vmovaps [rsp+0x20], xmm2
0000796da41dbac5  vmovaps [rsp+0x30], xmm3
0000796da41dbacb  vmovaps [rsp+0x40], xmm4
0000796da41dbad1  vmovaps [rsp+0x50], xmm5
0000796da41dbad7  vmovaps [rsp+0x60], xmm6
0000796da41dbadd  vmovaps [rsp+0x70], xmm7
0000796da41dbae3  vmovaps [rsp+0x80], xmm8
0000796da41dbaec  vmovaps [rsp+0x90], xmm9
0000796da41dbaf5  vmovaps [rsp+0xA0], xmm10
0000796da41dbafe  vmovaps [rsp+0xB0], xmm11
0000796da41dbb07  vmovaps [rsp+0xC0], xmm12
0000796da41dbb10  vmovaps [rsp+0xD0], xmm13
0000796da41dbb19  vmovaps [rsp+0xE0], xmm14
0000796da41dbb22  sub rsp, 0x30
0000796da41dbb26  movaps [rsp], xmm15
0000796da41dbb2b  movaps [rsp+0x10], xmm14
0000796da41dbb31  movaps [rsp+0x20], xmm4
0000796da41dbb36  lea rdi, [rsp]
0000796da41dbb3a  mov esi, 0x00
0000796da41dbb3f  mov rax, 0x5E26CB66A530
0000796da41dbb49  call rax
0000796da41dbb4b  movaps xmm15, [rsp]
0000796da41dbb50  add rsp, 0x30
0000796da41dbb54  vmovaps xmm0, [rsp]
0000796da41dbb59  vmovaps xmm1, [rsp+0x10]
0000796da41dbb5f  vmovaps xmm2, [rsp+0x20]
0000796da41dbb65  vmovaps xmm3, [rsp+0x30]
0000796da41dbb6b  vmovaps xmm4, [rsp+0x40]
0000796da41dbb71  vmovaps xmm5, [rsp+0x50]
0000796da41dbb77  vmovaps xmm6, [rsp+0x60]
0000796da41dbb7d  vmovaps xmm7, [rsp+0x70]
0000796da41dbb83  vmovaps xmm8, [rsp+0x80]
0000796da41dbb8c  vmovaps xmm9, [rsp+0x90]
0000796da41dbb95  vmovaps xmm10, [rsp+0xA0]
0000796da41dbb9e  vmovaps xmm11, [rsp+0xB0]
0000796da41dbba7  vmovaps xmm12, [rsp+0xC0]
0000796da41dbbb0  vmovaps xmm13, [rsp+0xD0]
0000796da41dbbb9  vmovaps xmm14, [rsp+0xE0]
0000796da41dbbc2  add rsp, 0xF0
0000796da41dbbc9  pop r11
0000796da41dbbcb  pop r10
0000796da41dbbcd  pop r9
0000796da41dbbcf  pop r8
0000796da41dbbd1  pop rsi
0000796da41dbbd2  pop rdi
0000796da41dbbd3  pop rdx
0000796da41dbbd4  pop rcx
0000796da41dbbd5  pop rax
0000796da41dbbd6  add rsp, 0x08
0000796da41dbbda  jmp 0x0000796DA41D92D7
0000796da41dbbdf  sub rsp, 0x08
0000796da41dbbe3  push rax
0000796da41dbbe4  push rcx
0000796da41dbbe5  push rdx
0000796da41dbbe6  push rdi
0000796da41dbbe7  push rsi
0000796da41dbbe8  push r8
0000796da41dbbea  push r9
0000796da41dbbec  push r10
0000796da41dbbee  push r11
0000796da41dbbf0  sub rsp, 0xF0
0000796da41dbbf7  vmovaps [rsp], xmm0
0000796da41dbbfc  vmovaps [rsp+0x10], xmm1
0000796da41dbc02  vmovaps [rsp+0x20], xmm2
0000796da41dbc08  vmovaps [rsp+0x30], xmm3
0000796da41dbc0e  vmovaps [rsp+0x40], xmm4
0000796da41dbc14  vmovaps [rsp+0x50], xmm5
0000796da41dbc1a  vmovaps [rsp+0x60], xmm6
0000796da41dbc20  vmovaps [rsp+0x70], xmm7
0000796da41dbc26  vmovaps [rsp+0x80], xmm8
0000796da41dbc2f  vmovaps [rsp+0x90], xmm9
0000796da41dbc38  vmovaps [rsp+0xA0], xmm10
0000796da41dbc41  vmovaps [rsp+0xB0], xmm11
0000796da41dbc4a  vmovaps [rsp+0xC0], xmm12
0000796da41dbc53  vmovaps [rsp+0xD0], xmm13
0000796da41dbc5c  vmovaps [rsp+0xE0], xmm15
0000796da41dbc65  sub rsp, 0x30
0000796da41dbc69  movaps [rsp], xmm14
0000796da41dbc6e  movaps [rsp+0x10], xmm2
0000796da41dbc73  movaps [rsp+0x20], xmm1
0000796da41dbc78  lea rdi, [rsp]
0000796da41dbc7c  mov esi, 0x00
0000796da41dbc81  mov rax, 0x5E26CB66A530
0000796da41dbc8b  call rax
0000796da41dbc8d  movaps xmm14, [rsp]
0000796da41dbc92  add rsp, 0x30
0000796da41dbc96  vmovaps xmm0, [rsp]
0000796da41dbc9b  vmovaps xmm1, [rsp+0x10]
0000796da41dbca1  vmovaps xmm2, [rsp+0x20]
0000796da41dbca7  vmovaps xmm3, [rsp+0x30]
0000796da41dbcad  vmovaps xmm4, [rsp+0x40]
0000796da41dbcb3  vmovaps xmm5, [rsp+0x50]
0000796da41dbcb9  vmovaps xmm6, [rsp+0x60]
0000796da41dbcbf  vmovaps xmm7, [rsp+0x70]
0000796da41dbcc5  vmovaps xmm8, [rsp+0x80]
0000796da41dbcce  vmovaps xmm9, [rsp+0x90]
0000796da41dbcd7  vmovaps xmm10, [rsp+0xA0]
0000796da41dbce0  vmovaps xmm11, [rsp+0xB0]
0000796da41dbce9  vmovaps xmm12, [rsp+0xC0]
0000796da41dbcf2  vmovaps xmm13, [rsp+0xD0]
0000796da41dbcfb  vmovaps xmm15, [rsp+0xE0]
0000796da41dbd04  add rsp, 0xF0
0000796da41dbd0b  pop r11
0000796da41dbd0d  pop r10
0000796da41dbd0f  pop r9
0000796da41dbd11  pop r8
0000796da41dbd13  pop rsi
0000796da41dbd14  pop rdi
0000796da41dbd15  pop rdx
0000796da41dbd16  pop rcx
0000796da41dbd17  pop rax
0000796da41dbd18  add rsp, 0x08
0000796da41dbd1c  jmp 0x0000796DA41D92FD
0000796da41dbd21  sub rsp, 0x08
0000796da41dbd25  push rax
0000796da41dbd26  push rcx
0000796da41dbd27  push rdx
0000796da41dbd28  push rdi
0000796da41dbd29  push rsi
0000796da41dbd2a  push r8
0000796da41dbd2c  push r9
0000796da41dbd2e  push r10
0000796da41dbd30  push r11
0000796da41dbd32  sub rsp, 0xF0
0000796da41dbd39  vmovaps [rsp], xmm0
0000796da41dbd3e  vmovaps [rsp+0x10], xmm2
0000796da41dbd44  vmovaps [rsp+0x20], xmm3
0000796da41dbd4a  vmovaps [rsp+0x30], xmm4
0000796da41dbd50  vmovaps [rsp+0x40], xmm5
0000796da41dbd56  vmovaps [rsp+0x50], xmm6
0000796da41dbd5c  vmovaps [rsp+0x60], xmm7
0000796da41dbd62  vmovaps [rsp+0x70], xmm8
0000796da41dbd68  vmovaps [rsp+0x80], xmm9
0000796da41dbd71  vmovaps [rsp+0x90], xmm10
0000796da41dbd7a  vmovaps [rsp+0xA0], xmm11
0000796da41dbd83  vmovaps [rsp+0xB0], xmm12
0000796da41dbd8c  vmovaps [rsp+0xC0], xmm13
0000796da41dbd95  vmovaps [rsp+0xD0], xmm14
0000796da41dbd9e  vmovaps [rsp+0xE0], xmm15
0000796da41dbda7  sub rsp, 0x30
0000796da41dbdab  movaps [rsp], xmm1
0000796da41dbdaf  movaps [rsp+0x10], xmm4
0000796da41dbdb4  movaps [rsp+0x20], xmm9
0000796da41dbdba  lea rdi, [rsp]
0000796da41dbdbe  mov esi, 0x00
0000796da41dbdc3  mov rax, 0x5E26CB66A530
0000796da41dbdcd  call rax
0000796da41dbdcf  movaps xmm1, [rsp]
0000796da41dbdd3  add rsp, 0x30
0000796da41dbdd7  vmovaps xmm0, [rsp]
0000796da41dbddc  vmovaps xmm2, [rsp+0x10]
0000796da41dbde2  vmovaps xmm3, [rsp+0x20]
0000796da41dbde8  vmovaps xmm4, [rsp+0x30]
0000796da41dbdee  vmovaps xmm5, [rsp+0x40]
0000796da41dbdf4  vmovaps xmm6, [rsp+0x50]
0000796da41dbdfa  vmovaps xmm7, [rsp+0x60]
0000796da41dbe00  vmovaps xmm8, [rsp+0x70]
0000796da41dbe06  vmovaps xmm9, [rsp+0x80]
0000796da41dbe0f  vmovaps xmm10, [rsp+0x90]
0000796da41dbe18  vmovaps xmm11, [rsp+0xA0]
0000796da41dbe21  vmovaps xmm12, [rsp+0xB0]
0000796da41dbe2a  vmovaps xmm13, [rsp+0xC0]
0000796da41dbe33  vmovaps xmm14, [rsp+0xD0]
0000796da41dbe3c  vmovaps xmm15, [rsp+0xE0]
0000796da41dbe45  add rsp, 0xF0
0000796da41dbe4c  pop r11
0000796da41dbe4e  pop r10
0000796da41dbe50  pop r9
0000796da41dbe52  pop r8
0000796da41dbe54  pop rsi
0000796da41dbe55  pop rdi
0000796da41dbe56  pop rdx
0000796da41dbe57  pop rcx
0000796da41dbe58  pop rax
0000796da41dbe59  add rsp, 0x08
0000796da41dbe5d  jmp 0x0000796DA41D931B
0000796da41dbe62  sub rsp, 0x08
0000796da41dbe66  push rax
0000796da41dbe67  push rcx
0000796da41dbe68  push rdx
0000796da41dbe69  push rdi
0000796da41dbe6a  push rsi
0000796da41dbe6b  push r8
0000796da41dbe6d  push r9
0000796da41dbe6f  push r10
0000796da41dbe71  push r11
0000796da41dbe73  sub rsp, 0xF0
0000796da41dbe7a  vmovaps [rsp], xmm0
0000796da41dbe7f  vmovaps [rsp+0x10], xmm1
0000796da41dbe85  vmovaps [rsp+0x20], xmm2
0000796da41dbe8b  vmovaps [rsp+0x30], xmm3
0000796da41dbe91  vmovaps [rsp+0x40], xmm5
0000796da41dbe97  vmovaps [rsp+0x50], xmm6
0000796da41dbe9d  vmovaps [rsp+0x60], xmm7
0000796da41dbea3  vmovaps [rsp+0x70], xmm8
0000796da41dbea9  vmovaps [rsp+0x80], xmm9
0000796da41dbeb2  vmovaps [rsp+0x90], xmm10
0000796da41dbebb  vmovaps [rsp+0xA0], xmm11
0000796da41dbec4  vmovaps [rsp+0xB0], xmm12
0000796da41dbecd  vmovaps [rsp+0xC0], xmm13
0000796da41dbed6  vmovaps [rsp+0xD0], xmm14
0000796da41dbedf  vmovaps [rsp+0xE0], xmm15
0000796da41dbee8  sub rsp, 0x30
0000796da41dbeec  movaps [rsp], xmm4
0000796da41dbef0  movaps [rsp+0x10], xmm2
0000796da41dbef5  movaps [rsp+0x20], xmm9
0000796da41dbefb  lea rdi, [rsp]
0000796da41dbeff  mov esi, 0x00
0000796da41dbf04  mov rax, 0x5E26CB66A530
0000796da41dbf0e  call rax
0000796da41dbf10  movaps xmm4, [rsp]
0000796da41dbf14  add rsp, 0x30
0000796da41dbf18  vmovaps xmm0, [rsp]
0000796da41dbf1d  vmovaps xmm1, [rsp+0x10]
0000796da41dbf23  vmovaps xmm2, [rsp+0x20]
0000796da41dbf29  vmovaps xmm3, [rsp+0x30]
0000796da41dbf2f  vmovaps xmm5, [rsp+0x40]
0000796da41dbf35  vmovaps xmm6, [rsp+0x50]
0000796da41dbf3b  vmovaps xmm7, [rsp+0x60]
0000796da41dbf41  vmovaps xmm8, [rsp+0x70]
0000796da41dbf47  vmovaps xmm9, [rsp+0x80]
0000796da41dbf50  vmovaps xmm10, [rsp+0x90]
0000796da41dbf59  vmovaps xmm11, [rsp+0xA0]
0000796da41dbf62  vmovaps xmm12, [rsp+0xB0]
0000796da41dbf6b  vmovaps xmm13, [rsp+0xC0]
0000796da41dbf74  vmovaps xmm14, [rsp+0xD0]
0000796da41dbf7d  vmovaps xmm15, [rsp+0xE0]
0000796da41dbf86  add rsp, 0xF0
0000796da41dbf8d  pop r11
0000796da41dbf8f  pop r10
0000796da41dbf91  pop r9
0000796da41dbf93  pop r8
0000796da41dbf95  pop rsi
0000796da41dbf96  pop rdi
0000796da41dbf97  pop rdx
0000796da41dbf98  pop rcx
0000796da41dbf99  pop rax
0000796da41dbf9a  add rsp, 0x08
0000796da41dbf9e  jmp 0x0000796DA41D934B
0000796da41dbfa3  sub rsp, 0x08
0000796da41dbfa7  push rax
0000796da41dbfa8  push rcx
0000796da41dbfa9  push rdx
0000796da41dbfaa  push rdi
0000796da41dbfab  push rsi
0000796da41dbfac  push r8
0000796da41dbfae  push r9
0000796da41dbfb0  push r10
0000796da41dbfb2  push r11
0000796da41dbfb4  sub rsp, 0xF0
0000796da41dbfbb  vmovaps [rsp], xmm0
0000796da41dbfc0  vmovaps [rsp+0x10], xmm1
0000796da41dbfc6  vmovaps [rsp+0x20], xmm2
0000796da41dbfcc  vmovaps [rsp+0x30], xmm3
0000796da41dbfd2  vmovaps [rsp+0x40], xmm4
0000796da41dbfd8  vmovaps [rsp+0x50], xmm5
0000796da41dbfde  vmovaps [rsp+0x60], xmm6
0000796da41dbfe4  vmovaps [rsp+0x70], xmm7
0000796da41dbfea  vmovaps [rsp+0x80], xmm8
0000796da41dbff3  vmovaps [rsp+0x90], xmm10
0000796da41dbffc  vmovaps [rsp+0xA0], xmm11
0000796da41dc005  vmovaps [rsp+0xB0], xmm12
0000796da41dc00e  vmovaps [rsp+0xC0], xmm13
0000796da41dc017  vmovaps [rsp+0xD0], xmm14
0000796da41dc020  vmovaps [rsp+0xE0], xmm15
0000796da41dc029  sub rsp, 0x30
0000796da41dc02d  movaps [rsp], xmm9
0000796da41dc032  movaps [rsp+0x10], xmm2
0000796da41dc037  movaps [rsp+0x20], xmm1
0000796da41dc03c  lea rdi, [rsp]
0000796da41dc040  mov esi, 0x00
0000796da41dc045  mov rax, 0x5E26CB66A530
0000796da41dc04f  call rax
0000796da41dc051  movaps xmm9, [rsp]
0000796da41dc056  add rsp, 0x30
0000796da41dc05a  vmovaps xmm0, [rsp]
0000796da41dc05f  vmovaps xmm1, [rsp+0x10]
0000796da41dc065  vmovaps xmm2, [rsp+0x20]
0000796da41dc06b  vmovaps xmm3, [rsp+0x30]
0000796da41dc071  vmovaps xmm4, [rsp+0x40]
0000796da41dc077  vmovaps xmm5, [rsp+0x50]
0000796da41dc07d  vmovaps xmm6, [rsp+0x60]
0000796da41dc083  vmovaps xmm7, [rsp+0x70]
0000796da41dc089  vmovaps xmm8, [rsp+0x80]
0000796da41dc092  vmovaps xmm10, [rsp+0x90]
0000796da41dc09b  vmovaps xmm11, [rsp+0xA0]
0000796da41dc0a4  vmovaps xmm12, [rsp+0xB0]
0000796da41dc0ad  vmovaps xmm13, [rsp+0xC0]
0000796da41dc0b6  vmovaps xmm14, [rsp+0xD0]
0000796da41dc0bf  vmovaps xmm15, [rsp+0xE0]
0000796da41dc0c8  add rsp, 0xF0
0000796da41dc0cf  pop r11
0000796da41dc0d1  pop r10
0000796da41dc0d3  pop r9
0000796da41dc0d5  pop r8
0000796da41dc0d7  pop rsi
0000796da41dc0d8  pop rdi
0000796da41dc0d9  pop rdx
0000796da41dc0da  pop rcx
0000796da41dc0db  pop rax
0000796da41dc0dc  add rsp, 0x08
0000796da41dc0e0  jmp 0x0000796DA41D9381
0000796da41dc0e5  sub rsp, 0x08
0000796da41dc0e9  push rax
0000796da41dc0ea  push rcx
0000796da41dc0eb  push rdx
0000796da41dc0ec  push rdi
0000796da41dc0ed  push rsi
0000796da41dc0ee  push r8
0000796da41dc0f0  push r9
0000796da41dc0f2  push r10
0000796da41dc0f4  push r11
0000796da41dc0f6  sub rsp, 0xF0
0000796da41dc0fd  vmovaps [rsp], xmm0
0000796da41dc102  vmovaps [rsp+0x10], xmm2
0000796da41dc108  vmovaps [rsp+0x20], xmm3
0000796da41dc10e  vmovaps [rsp+0x30], xmm4
0000796da41dc114  vmovaps [rsp+0x40], xmm5
0000796da41dc11a  vmovaps [rsp+0x50], xmm6
0000796da41dc120  vmovaps [rsp+0x60], xmm7
0000796da41dc126  vmovaps [rsp+0x70], xmm8
0000796da41dc12c  vmovaps [rsp+0x80], xmm9
0000796da41dc135  vmovaps [rsp+0x90], xmm10
0000796da41dc13e  vmovaps [rsp+0xA0], xmm11
0000796da41dc147  vmovaps [rsp+0xB0], xmm12
0000796da41dc150  vmovaps [rsp+0xC0], xmm13
0000796da41dc159  vmovaps [rsp+0xD0], xmm14
0000796da41dc162  vmovaps [rsp+0xE0], xmm15
0000796da41dc16b  sub rsp, 0x30
0000796da41dc16f  movaps [rsp], xmm1
0000796da41dc173  movaps [rsp+0x10], xmm15
0000796da41dc179  movaps [rsp+0x20], xmm6
0000796da41dc17e  lea rdi, [rsp]
0000796da41dc182  mov esi, 0x00
0000796da41dc187  mov rax, 0x5E26CB66A530
0000796da41dc191  call rax
0000796da41dc193  movaps xmm1, [rsp]
0000796da41dc197  add rsp, 0x30
0000796da41dc19b  vmovaps xmm0, [rsp]
0000796da41dc1a0  vmovaps xmm2, [rsp+0x10]
0000796da41dc1a6  vmovaps xmm3, [rsp+0x20]
0000796da41dc1ac  vmovaps xmm4, [rsp+0x30]
0000796da41dc1b2  vmovaps xmm5, [rsp+0x40]
0000796da41dc1b8  vmovaps xmm6, [rsp+0x50]
0000796da41dc1be  vmovaps xmm7, [rsp+0x60]
0000796da41dc1c4  vmovaps xmm8, [rsp+0x70]
0000796da41dc1ca  vmovaps xmm9, [rsp+0x80]
0000796da41dc1d3  vmovaps xmm10, [rsp+0x90]
0000796da41dc1dc  vmovaps xmm11, [rsp+0xA0]
0000796da41dc1e5  vmovaps xmm12, [rsp+0xB0]
0000796da41dc1ee  vmovaps xmm13, [rsp+0xC0]
0000796da41dc1f7  vmovaps xmm14, [rsp+0xD0]
0000796da41dc200  vmovaps xmm15, [rsp+0xE0]
0000796da41dc209  add rsp, 0xF0
0000796da41dc210  pop r11
0000796da41dc212  pop r10
0000796da41dc214  pop r9
0000796da41dc216  pop r8
0000796da41dc218  pop rsi
0000796da41dc219  pop rdi
0000796da41dc21a  pop rdx
0000796da41dc21b  pop rcx
0000796da41dc21c  pop rax
0000796da41dc21d  add rsp, 0x08
0000796da41dc221  jmp 0x0000796DA41D93A2
0000796da41dc226  sub rsp, 0x08
0000796da41dc22a  push rax
0000796da41dc22b  push rcx
0000796da41dc22c  push rdx
0000796da41dc22d  push rdi
0000796da41dc22e  push rsi
0000796da41dc22f  push r8
0000796da41dc231  push r9
0000796da41dc233  push r10
0000796da41dc235  push r11
0000796da41dc237  sub rsp, 0xF0
0000796da41dc23e  vmovaps [rsp], xmm0
0000796da41dc243  vmovaps [rsp+0x10], xmm1
0000796da41dc249  vmovaps [rsp+0x20], xmm2
0000796da41dc24f  vmovaps [rsp+0x30], xmm3
0000796da41dc255  vmovaps [rsp+0x40], xmm4
0000796da41dc25b  vmovaps [rsp+0x50], xmm5
0000796da41dc261  vmovaps [rsp+0x60], xmm6
0000796da41dc267  vmovaps [rsp+0x70], xmm7
0000796da41dc26d  vmovaps [rsp+0x80], xmm8
0000796da41dc276  vmovaps [rsp+0x90], xmm9
0000796da41dc27f  vmovaps [rsp+0xA0], xmm10
0000796da41dc288  vmovaps [rsp+0xB0], xmm11
0000796da41dc291  vmovaps [rsp+0xC0], xmm12
0000796da41dc29a  vmovaps [rsp+0xD0], xmm13
0000796da41dc2a3  vmovaps [rsp+0xE0], xmm14
0000796da41dc2ac  sub rsp, 0x30
0000796da41dc2b0  movaps [rsp], xmm15
0000796da41dc2b5  movaps [rsp+0x10], xmm5
0000796da41dc2ba  movaps [rsp+0x20], xmm3
0000796da41dc2bf  lea rdi, [rsp]
0000796da41dc2c3  mov esi, 0x00
0000796da41dc2c8  mov rax, 0x5E26CB66A530
0000796da41dc2d2  call rax
0000796da41dc2d4  movaps xmm15, [rsp]
0000796da41dc2d9  add rsp, 0x30
0000796da41dc2dd  vmovaps xmm0, [rsp]
0000796da41dc2e2  vmovaps xmm1, [rsp+0x10]
0000796da41dc2e8  vmovaps xmm2, [rsp+0x20]
0000796da41dc2ee  vmovaps xmm3, [rsp+0x30]
0000796da41dc2f4  vmovaps xmm4, [rsp+0x40]
0000796da41dc2fa  vmovaps xmm5, [rsp+0x50]
0000796da41dc300  vmovaps xmm6, [rsp+0x60]
0000796da41dc306  vmovaps xmm7, [rsp+0x70]
0000796da41dc30c  vmovaps xmm8, [rsp+0x80]
0000796da41dc315  vmovaps xmm9, [rsp+0x90]
0000796da41dc31e  vmovaps xmm10, [rsp+0xA0]
0000796da41dc327  vmovaps xmm11, [rsp+0xB0]
0000796da41dc330  vmovaps xmm12, [rsp+0xC0]
0000796da41dc339  vmovaps xmm13, [rsp+0xD0]
0000796da41dc342  vmovaps xmm14, [rsp+0xE0]
0000796da41dc34b  add rsp, 0xF0
0000796da41dc352  pop r11
0000796da41dc354  pop r10
0000796da41dc356  pop r9
0000796da41dc358  pop r8
0000796da41dc35a  pop rsi
0000796da41dc35b  pop rdi
0000796da41dc35c  pop rdx
0000796da41dc35d  pop rcx
0000796da41dc35e  pop rax
0000796da41dc35f  add rsp, 0x08
0000796da41dc363  jmp 0x0000796DA41D93BC
0000796da41dc368  sub rsp, 0x08
0000796da41dc36c  push rax
0000796da41dc36d  push rcx
0000796da41dc36e  push rdx
0000796da41dc36f  push rdi
0000796da41dc370  push rsi
0000796da41dc371  push r8
0000796da41dc373  push r9
0000796da41dc375  push r10
0000796da41dc377  push r11
0000796da41dc379  sub rsp, 0xF0
0000796da41dc380  vmovaps [rsp], xmm0
0000796da41dc385  vmovaps [rsp+0x10], xmm1
0000796da41dc38b  vmovaps [rsp+0x20], xmm2
0000796da41dc391  vmovaps [rsp+0x30], xmm3
0000796da41dc397  vmovaps [rsp+0x40], xmm4
0000796da41dc39d  vmovaps [rsp+0x50], xmm6
0000796da41dc3a3  vmovaps [rsp+0x60], xmm7
0000796da41dc3a9  vmovaps [rsp+0x70], xmm8
0000796da41dc3af  vmovaps [rsp+0x80], xmm9
0000796da41dc3b8  vmovaps [rsp+0x90], xmm10
0000796da41dc3c1  vmovaps [rsp+0xA0], xmm11
0000796da41dc3ca  vmovaps [rsp+0xB0], xmm12
0000796da41dc3d3  vmovaps [rsp+0xC0], xmm13
0000796da41dc3dc  vmovaps [rsp+0xD0], xmm14
0000796da41dc3e5  vmovaps [rsp+0xE0], xmm15
0000796da41dc3ee  sub rsp, 0x30
0000796da41dc3f2  movaps [rsp], xmm5
0000796da41dc3f6  movaps [rsp+0x10], xmm8
0000796da41dc3fc  movaps [rsp+0x20], xmm6
0000796da41dc401  lea rdi, [rsp]
0000796da41dc405  mov esi, 0x00
0000796da41dc40a  mov rax, 0x5E26CB66A530
0000796da41dc414  call rax
0000796da41dc416  movaps xmm5, [rsp]
0000796da41dc41a  add rsp, 0x30
0000796da41dc41e  vmovaps xmm0, [rsp]
0000796da41dc423  vmovaps xmm1, [rsp+0x10]
0000796da41dc429  vmovaps xmm2, [rsp+0x20]
0000796da41dc42f  vmovaps xmm3, [rsp+0x30]
0000796da41dc435  vmovaps xmm4, [rsp+0x40]
0000796da41dc43b  vmovaps xmm6, [rsp+0x50]
0000796da41dc441  vmovaps xmm7, [rsp+0x60]
0000796da41dc447  vmovaps xmm8, [rsp+0x70]
0000796da41dc44d  vmovaps xmm9, [rsp+0x80]
0000796da41dc456  vmovaps xmm10, [rsp+0x90]
0000796da41dc45f  vmovaps xmm11, [rsp+0xA0]
0000796da41dc468  vmovaps xmm12, [rsp+0xB0]
0000796da41dc471  vmovaps xmm13, [rsp+0xC0]
0000796da41dc47a  vmovaps xmm14, [rsp+0xD0]
0000796da41dc483  vmovaps xmm15, [rsp+0xE0]
0000796da41dc48c  add rsp, 0xF0
0000796da41dc493  pop r11
0000796da41dc495  pop r10
0000796da41dc497  pop r9
0000796da41dc499  pop r8
0000796da41dc49b  pop rsi
0000796da41dc49c  pop rdi
0000796da41dc49d  pop rdx
0000796da41dc49e  pop rcx
0000796da41dc49f  pop rax
0000796da41dc4a0  add rsp, 0x08
0000796da41dc4a4  jmp 0x0000796DA41D93E0
0000796da41dc4a9  sub rsp, 0x08
0000796da41dc4ad  push rax
0000796da41dc4ae  push rcx
0000796da41dc4af  push rdx
0000796da41dc4b0  push rdi
0000796da41dc4b1  push rsi
0000796da41dc4b2  push r8
0000796da41dc4b4  push r9
0000796da41dc4b6  push r10
0000796da41dc4b8  push r11
0000796da41dc4ba  sub rsp, 0xF0
0000796da41dc4c1  vmovaps [rsp], xmm0
0000796da41dc4c6  vmovaps [rsp+0x10], xmm1
0000796da41dc4cc  vmovaps [rsp+0x20], xmm2
0000796da41dc4d2  vmovaps [rsp+0x30], xmm3
0000796da41dc4d8  vmovaps [rsp+0x40], xmm4
0000796da41dc4de  vmovaps [rsp+0x50], xmm5
0000796da41dc4e4  vmovaps [rsp+0x60], xmm7
0000796da41dc4ea  vmovaps [rsp+0x70], xmm8
0000796da41dc4f0  vmovaps [rsp+0x80], xmm9
0000796da41dc4f9  vmovaps [rsp+0x90], xmm10
0000796da41dc502  vmovaps [rsp+0xA0], xmm11
0000796da41dc50b  vmovaps [rsp+0xB0], xmm12
0000796da41dc514  vmovaps [rsp+0xC0], xmm13
0000796da41dc51d  vmovaps [rsp+0xD0], xmm14
0000796da41dc526  vmovaps [rsp+0xE0], xmm15
0000796da41dc52f  sub rsp, 0x30
0000796da41dc533  movaps [rsp], xmm6
0000796da41dc537  movaps [rsp+0x10], xmm10
0000796da41dc53d  movaps [rsp+0x20], xmm8
0000796da41dc543  lea rdi, [rsp]
0000796da41dc547  mov esi, 0x00
0000796da41dc54c  mov rax, 0x5E26CB66A530
0000796da41dc556  call rax
0000796da41dc558  movaps xmm6, [rsp]
0000796da41dc55c  add rsp, 0x30
0000796da41dc560  vmovaps xmm0, [rsp]
0000796da41dc565  vmovaps xmm1, [rsp+0x10]
0000796da41dc56b  vmovaps xmm2, [rsp+0x20]
0000796da41dc571  vmovaps xmm3, [rsp+0x30]
0000796da41dc577  vmovaps xmm4, [rsp+0x40]
0000796da41dc57d  vmovaps xmm5, [rsp+0x50]
0000796da41dc583  vmovaps xmm7, [rsp+0x60]
0000796da41dc589  vmovaps xmm8, [rsp+0x70]
0000796da41dc58f  vmovaps xmm9, [rsp+0x80]
0000796da41dc598  vmovaps xmm10, [rsp+0x90]
0000796da41dc5a1  vmovaps xmm11, [rsp+0xA0]
0000796da41dc5aa  vmovaps xmm12, [rsp+0xB0]
0000796da41dc5b3  vmovaps xmm13, [rsp+0xC0]
0000796da41dc5bc  vmovaps xmm14, [rsp+0xD0]
0000796da41dc5c5  vmovaps xmm15, [rsp+0xE0]
0000796da41dc5ce  add rsp, 0xF0
0000796da41dc5d5  pop r11
0000796da41dc5d7  pop r10
0000796da41dc5d9  pop r9
0000796da41dc5db  pop r8
0000796da41dc5dd  pop rsi
0000796da41dc5de  pop rdi
0000796da41dc5df  pop rdx
0000796da41dc5e0  pop rcx
0000796da41dc5e1  pop rax
0000796da41dc5e2  add rsp, 0x08
0000796da41dc5e6  jmp 0x0000796DA41D9405
0000796da41dc5eb  sub rsp, 0x08
0000796da41dc5ef  push rax
0000796da41dc5f0  push rcx
0000796da41dc5f1  push rdx
0000796da41dc5f2  push rdi
0000796da41dc5f3  push rsi
0000796da41dc5f4  push r8
0000796da41dc5f6  push r9
0000796da41dc5f8  push r10
0000796da41dc5fa  push r11
0000796da41dc5fc  sub rsp, 0xF0
0000796da41dc603  vmovaps [rsp], xmm0
0000796da41dc608  vmovaps [rsp+0x10], xmm1
0000796da41dc60e  vmovaps [rsp+0x20], xmm2
0000796da41dc614  vmovaps [rsp+0x30], xmm3
0000796da41dc61a  vmovaps [rsp+0x40], xmm4
0000796da41dc620  vmovaps [rsp+0x50], xmm5
0000796da41dc626  vmovaps [rsp+0x60], xmm6
0000796da41dc62c  vmovaps [rsp+0x70], xmm7
0000796da41dc632  vmovaps [rsp+0x80], xmm8
0000796da41dc63b  vmovaps [rsp+0x90], xmm9
0000796da41dc644  vmovaps [rsp+0xA0], xmm11
0000796da41dc64d  vmovaps [rsp+0xB0], xmm12
0000796da41dc656  vmovaps [rsp+0xC0], xmm13
0000796da41dc65f  vmovaps [rsp+0xD0], xmm14
0000796da41dc668  vmovaps [rsp+0xE0], xmm15
0000796da41dc671  sub rsp, 0x30
0000796da41dc675  movaps [rsp], xmm10
0000796da41dc67a  movaps [rsp+0x10], xmm8
0000796da41dc680  movaps [rsp+0x20], xmm14
0000796da41dc686  lea rdi, [rsp]
0000796da41dc68a  mov esi, 0x00
0000796da41dc68f  mov rax, 0x5E26CB66A530
0000796da41dc699  call rax
0000796da41dc69b  movaps xmm10, [rsp]
0000796da41dc6a0  add rsp, 0x30
0000796da41dc6a4  vmovaps xmm0, [rsp]
0000796da41dc6a9  vmovaps xmm1, [rsp+0x10]
0000796da41dc6af  vmovaps xmm2, [rsp+0x20]
0000796da41dc6b5  vmovaps xmm3, [rsp+0x30]
0000796da41dc6bb  vmovaps xmm4, [rsp+0x40]
0000796da41dc6c1  vmovaps xmm5, [rsp+0x50]
0000796da41dc6c7  vmovaps xmm6, [rsp+0x60]
0000796da41dc6cd  vmovaps xmm7, [rsp+0x70]
0000796da41dc6d3  vmovaps xmm8, [rsp+0x80]
0000796da41dc6dc  vmovaps xmm9, [rsp+0x90]
0000796da41dc6e5  vmovaps xmm11, [rsp+0xA0]
0000796da41dc6ee  vmovaps xmm12, [rsp+0xB0]
0000796da41dc6f7  vmovaps xmm13, [rsp+0xC0]
0000796da41dc700  vmovaps xmm14, [rsp+0xD0]
0000796da41dc709  vmovaps xmm15, [rsp+0xE0]
0000796da41dc712  add rsp, 0xF0
0000796da41dc719  pop r11
0000796da41dc71b  pop r10
0000796da41dc71d  pop r9
0000796da41dc71f  pop r8
0000796da41dc721  pop rsi
0000796da41dc722  pop rdi
0000796da41dc723  pop rdx
0000796da41dc724  pop rcx
0000796da41dc725  pop rax
0000796da41dc726  add rsp, 0x08
0000796da41dc72a  jmp 0x0000796DA41D9425
0000796da41dc72f  sub rsp, 0x08
0000796da41dc733  push rax
0000796da41dc734  push rcx
0000796da41dc735  push rdx
0000796da41dc736  push rdi
0000796da41dc737  push rsi
0000796da41dc738  push r8
0000796da41dc73a  push r9
0000796da41dc73c  push r10
0000796da41dc73e  push r11
0000796da41dc740  sub rsp, 0xF0
0000796da41dc747  vmovaps [rsp], xmm0
0000796da41dc74c  vmovaps [rsp+0x10], xmm1
0000796da41dc752  vmovaps [rsp+0x20], xmm2
0000796da41dc758  vmovaps [rsp+0x30], xmm3
0000796da41dc75e  vmovaps [rsp+0x40], xmm4
0000796da41dc764  vmovaps [rsp+0x50], xmm5
0000796da41dc76a  vmovaps [rsp+0x60], xmm6
0000796da41dc770  vmovaps [rsp+0x70], xmm7
0000796da41dc776  vmovaps [rsp+0x80], xmm8
0000796da41dc77f  vmovaps [rsp+0x90], xmm9
0000796da41dc788  vmovaps [rsp+0xA0], xmm10
0000796da41dc791  vmovaps [rsp+0xB0], xmm11
0000796da41dc79a  vmovaps [rsp+0xC0], xmm12
0000796da41dc7a3  vmovaps [rsp+0xD0], xmm13
0000796da41dc7ac  vmovaps [rsp+0xE0], xmm15
0000796da41dc7b5  sub rsp, 0x30
0000796da41dc7b9  movaps [rsp], xmm14
0000796da41dc7be  movaps [rsp+0x10], xmm8
0000796da41dc7c4  movaps [rsp+0x20], xmm4
0000796da41dc7c9  lea rdi, [rsp]
0000796da41dc7cd  mov esi, 0x00
0000796da41dc7d2  mov rax, 0x5E26CB66A530
0000796da41dc7dc  call rax
0000796da41dc7de  movaps xmm14, [rsp]
0000796da41dc7e3  add rsp, 0x30
0000796da41dc7e7  vmovaps xmm0, [rsp]
0000796da41dc7ec  vmovaps xmm1, [rsp+0x10]
0000796da41dc7f2  vmovaps xmm2, [rsp+0x20]
0000796da41dc7f8  vmovaps xmm3, [rsp+0x30]
0000796da41dc7fe  vmovaps xmm4, [rsp+0x40]
0000796da41dc804  vmovaps xmm5, [rsp+0x50]
0000796da41dc80a  vmovaps xmm6, [rsp+0x60]
0000796da41dc810  vmovaps xmm7, [rsp+0x70]
0000796da41dc816  vmovaps xmm8, [rsp+0x80]
0000796da41dc81f  vmovaps xmm9, [rsp+0x90]
0000796da41dc828  vmovaps xmm10, [rsp+0xA0]
0000796da41dc831  vmovaps xmm11, [rsp+0xB0]
0000796da41dc83a  vmovaps xmm12, [rsp+0xC0]
0000796da41dc843  vmovaps xmm13, [rsp+0xD0]
0000796da41dc84c  vmovaps xmm15, [rsp+0xE0]
0000796da41dc855  add rsp, 0xF0
0000796da41dc85c  pop r11
0000796da41dc85e  pop r10
0000796da41dc860  pop r9
0000796da41dc862  pop r8
0000796da41dc864  pop rsi
0000796da41dc865  pop rdi
0000796da41dc866  pop rdx
0000796da41dc867  pop rcx
0000796da41dc868  pop rax
0000796da41dc869  add rsp, 0x08
0000796da41dc86d  jmp 0x0000796DA41D9445
0000796da41dc872  sub rsp, 0x08
0000796da41dc876  push rax
0000796da41dc877  push rcx
0000796da41dc878  push rdx
0000796da41dc879  push rdi
0000796da41dc87a  push rsi
0000796da41dc87b  push r8
0000796da41dc87d  push r9
0000796da41dc87f  push r10
0000796da41dc881  push r11
0000796da41dc883  sub rsp, 0xF0
0000796da41dc88a  vmovaps [rsp], xmm0
0000796da41dc88f  vmovaps [rsp+0x10], xmm1
0000796da41dc895  vmovaps [rsp+0x20], xmm2
0000796da41dc89b  vmovaps [rsp+0x30], xmm3
0000796da41dc8a1  vmovaps [rsp+0x40], xmm5
0000796da41dc8a7  vmovaps [rsp+0x50], xmm6
0000796da41dc8ad  vmovaps [rsp+0x60], xmm7
0000796da41dc8b3  vmovaps [rsp+0x70], xmm8
0000796da41dc8b9  vmovaps [rsp+0x80], xmm9
0000796da41dc8c2  vmovaps [rsp+0x90], xmm10
0000796da41dc8cb  vmovaps [rsp+0xA0], xmm11
0000796da41dc8d4  vmovaps [rsp+0xB0], xmm12
0000796da41dc8dd  vmovaps [rsp+0xC0], xmm13
0000796da41dc8e6  vmovaps [rsp+0xD0], xmm14
0000796da41dc8ef  vmovaps [rsp+0xE0], xmm15
0000796da41dc8f8  sub rsp, 0x30
0000796da41dc8fc  movaps [rsp], xmm4
0000796da41dc900  movaps [rsp+0x10], xmm13
0000796da41dc906  movaps [rsp+0x20], xmm8
0000796da41dc90c  lea rdi, [rsp]
0000796da41dc910  mov esi, 0x00
0000796da41dc915  mov rax, 0x5E26CB66A530
0000796da41dc91f  call rax
0000796da41dc921  movaps xmm4, [rsp]
0000796da41dc925  add rsp, 0x30
0000796da41dc929  vmovaps xmm0, [rsp]
0000796da41dc92e  vmovaps xmm1, [rsp+0x10]
0000796da41dc934  vmovaps xmm2, [rsp+0x20]
0000796da41dc93a  vmovaps xmm3, [rsp+0x30]
0000796da41dc940  vmovaps xmm5, [rsp+0x40]
0000796da41dc946  vmovaps xmm6, [rsp+0x50]
0000796da41dc94c  vmovaps xmm7, [rsp+0x60]
0000796da41dc952  vmovaps xmm8, [rsp+0x70]
0000796da41dc958  vmovaps xmm9, [rsp+0x80]
0000796da41dc961  vmovaps xmm10, [rsp+0x90]
0000796da41dc96a  vmovaps xmm11, [rsp+0xA0]
0000796da41dc973  vmovaps xmm12, [rsp+0xB0]
0000796da41dc97c  vmovaps xmm13, [rsp+0xC0]
0000796da41dc985  vmovaps xmm14, [rsp+0xD0]
0000796da41dc98e  vmovaps xmm15, [rsp+0xE0]
0000796da41dc997  add rsp, 0xF0
0000796da41dc99e  pop r11
0000796da41dc9a0  pop r10
0000796da41dc9a2  pop r9
0000796da41dc9a4  pop r8
0000796da41dc9a6  pop rsi
0000796da41dc9a7  pop rdi
0000796da41dc9a8  pop rdx
0000796da41dc9a9  pop rcx
0000796da41dc9aa  pop rax
0000796da41dc9ab  add rsp, 0x08
0000796da41dc9af  jmp 0x0000796DA41D946A
0000796da41dc9b4  sub rsp, 0x08
0000796da41dc9b8  push rax
0000796da41dc9b9  push rcx
0000796da41dc9ba  push rdx
0000796da41dc9bb  push rdi
0000796da41dc9bc  push rsi
0000796da41dc9bd  push r8
0000796da41dc9bf  push r9
0000796da41dc9c1  push r10
0000796da41dc9c3  push r11
0000796da41dc9c5  sub rsp, 0xF0
0000796da41dc9cc  vmovaps [rsp], xmm0
0000796da41dc9d1  vmovaps [rsp+0x10], xmm1
0000796da41dc9d7  vmovaps [rsp+0x20], xmm2
0000796da41dc9dd  vmovaps [rsp+0x30], xmm3
0000796da41dc9e3  vmovaps [rsp+0x40], xmm4
0000796da41dc9e9  vmovaps [rsp+0x50], xmm5
0000796da41dc9ef  vmovaps [rsp+0x60], xmm6
0000796da41dc9f5  vmovaps [rsp+0x70], xmm7
0000796da41dc9fb  vmovaps [rsp+0x80], xmm8
0000796da41dca04  vmovaps [rsp+0x90], xmm9
0000796da41dca0d  vmovaps [rsp+0xA0], xmm10
0000796da41dca16  vmovaps [rsp+0xB0], xmm11
0000796da41dca1f  vmovaps [rsp+0xC0], xmm12
0000796da41dca28  vmovaps [rsp+0xD0], xmm14
0000796da41dca31  vmovaps [rsp+0xE0], xmm15
0000796da41dca3a  sub rsp, 0x30
0000796da41dca3e  movaps [rsp], xmm13
0000796da41dca43  movaps [rsp+0x10], xmm15
0000796da41dca49  movaps [rsp+0x20], xmm9
0000796da41dca4f  lea rdi, [rsp]
0000796da41dca53  mov esi, 0x00
0000796da41dca58  mov rax, 0x5E26CB66A530
0000796da41dca62  call rax
0000796da41dca64  movaps xmm13, [rsp]
0000796da41dca69  add rsp, 0x30
0000796da41dca6d  vmovaps xmm0, [rsp]
0000796da41dca72  vmovaps xmm1, [rsp+0x10]
0000796da41dca78  vmovaps xmm2, [rsp+0x20]
0000796da41dca7e  vmovaps xmm3, [rsp+0x30]
0000796da41dca84  vmovaps xmm4, [rsp+0x40]
0000796da41dca8a  vmovaps xmm5, [rsp+0x50]
0000796da41dca90  vmovaps xmm6, [rsp+0x60]
0000796da41dca96  vmovaps xmm7, [rsp+0x70]
0000796da41dca9c  vmovaps xmm8, [rsp+0x80]
0000796da41dcaa5  vmovaps xmm9, [rsp+0x90]
0000796da41dcaae  vmovaps xmm10, [rsp+0xA0]
0000796da41dcab7  vmovaps xmm11, [rsp+0xB0]
0000796da41dcac0  vmovaps xmm12, [rsp+0xC0]
0000796da41dcac9  vmovaps xmm14, [rsp+0xD0]
0000796da41dcad2  vmovaps xmm15, [rsp+0xE0]
0000796da41dcadb  add rsp, 0xF0
0000796da41dcae2  pop r11
0000796da41dcae4  pop r10
0000796da41dcae6  pop r9
0000796da41dcae8  pop r8
0000796da41dcaea  pop rsi
0000796da41dcaeb  pop rdi
0000796da41dcaec  pop rdx
0000796da41dcaed  pop rcx
0000796da41dcaee  pop rax
0000796da41dcaef  add rsp, 0x08
0000796da41dcaf3  jmp 0x0000796DA41D9485
0000796da41dcaf8  sub rsp, 0x08
0000796da41dcafc  push rax
0000796da41dcafd  push rcx
0000796da41dcafe  push rdx
0000796da41dcaff  push rdi
0000796da41dcb00  push rsi
0000796da41dcb01  push r8
0000796da41dcb03  push r9
0000796da41dcb05  push r10
0000796da41dcb07  push r11
0000796da41dcb09  sub rsp, 0xF0
0000796da41dcb10  vmovaps [rsp], xmm0
0000796da41dcb15  vmovaps [rsp+0x10], xmm1
0000796da41dcb1b  vmovaps [rsp+0x20], xmm2
0000796da41dcb21  vmovaps [rsp+0x30], xmm3
0000796da41dcb27  vmovaps [rsp+0x40], xmm4
0000796da41dcb2d  vmovaps [rsp+0x50], xmm5
0000796da41dcb33  vmovaps [rsp+0x60], xmm6
0000796da41dcb39  vmovaps [rsp+0x70], xmm7
0000796da41dcb3f  vmovaps [rsp+0x80], xmm8
0000796da41dcb48  vmovaps [rsp+0x90], xmm9
0000796da41dcb51  vmovaps [rsp+0xA0], xmm10
0000796da41dcb5a  vmovaps [rsp+0xB0], xmm11
0000796da41dcb63  vmovaps [rsp+0xC0], xmm12
0000796da41dcb6c  vmovaps [rsp+0xD0], xmm13
0000796da41dcb75  vmovaps [rsp+0xE0], xmm14
0000796da41dcb7e  sub rsp, 0x30
0000796da41dcb82  movaps [rsp], xmm15
0000796da41dcb87  movaps [rsp+0x10], xmm1
0000796da41dcb8c  movaps [rsp+0x20], xmm5
0000796da41dcb91  lea rdi, [rsp]
0000796da41dcb95  mov esi, 0x00
0000796da41dcb9a  mov rax, 0x5E26CB66A530
0000796da41dcba4  call rax
0000796da41dcba6  movaps xmm15, [rsp]
0000796da41dcbab  add rsp, 0x30
0000796da41dcbaf  vmovaps xmm0, [rsp]
0000796da41dcbb4  vmovaps xmm1, [rsp+0x10]
0000796da41dcbba  vmovaps xmm2, [rsp+0x20]
0000796da41dcbc0  vmovaps xmm3, [rsp+0x30]
0000796da41dcbc6  vmovaps xmm4, [rsp+0x40]
0000796da41dcbcc  vmovaps xmm5, [rsp+0x50]
0000796da41dcbd2  vmovaps xmm6, [rsp+0x60]
0000796da41dcbd8  vmovaps xmm7, [rsp+0x70]
0000796da41dcbde  vmovaps xmm8, [rsp+0x80]
0000796da41dcbe7  vmovaps xmm9, [rsp+0x90]
0000796da41dcbf0  vmovaps xmm10, [rsp+0xA0]
0000796da41dcbf9  vmovaps xmm11, [rsp+0xB0]
0000796da41dcc02  vmovaps xmm12, [rsp+0xC0]
0000796da41dcc0b  vmovaps xmm13, [rsp+0xD0]
0000796da41dcc14  vmovaps xmm14, [rsp+0xE0]
0000796da41dcc1d  add rsp, 0xF0
0000796da41dcc24  pop r11
0000796da41dcc26  pop r10
0000796da41dcc28  pop r9
0000796da41dcc2a  pop r8
0000796da41dcc2c  pop rsi
0000796da41dcc2d  pop rdi
0000796da41dcc2e  pop rdx
0000796da41dcc2f  pop rcx
0000796da41dcc30  pop rax
0000796da41dcc31  add rsp, 0x08
0000796da41dcc35  jmp 0x0000796DA41D94A0
0000796da41dcc3a  call 0x0000796DA40D64F0
0000796da41dcc3f  jmp 0x0000796DA41D94FB
0000796da41dcc44  sub rsp, 0x08
0000796da41dcc48  push rax
0000796da41dcc49  push rcx
0000796da41dcc4a  push rdx
0000796da41dcc4b  push rdi
0000796da41dcc4c  push rsi
0000796da41dcc4d  push r8
0000796da41dcc4f  push r9
0000796da41dcc51  push r10
0000796da41dcc53  push r11
0000796da41dcc55  sub rsp, 0xF0
0000796da41dcc5c  vmovaps [rsp], xmm0
0000796da41dcc61  vmovaps [rsp+0x10], xmm1
0000796da41dcc67  vmovaps [rsp+0x20], xmm2
0000796da41dcc6d  vmovaps [rsp+0x30], xmm3
0000796da41dcc73  vmovaps [rsp+0x40], xmm4
0000796da41dcc79  vmovaps [rsp+0x50], xmm5
0000796da41dcc7f  vmovaps [rsp+0x60], xmm6
0000796da41dcc85  vmovaps [rsp+0x70], xmm7
0000796da41dcc8b  vmovaps [rsp+0x80], xmm8
0000796da41dcc94  vmovaps [rsp+0x90], xmm10
0000796da41dcc9d  vmovaps [rsp+0xA0], xmm11
0000796da41dcca6  vmovaps [rsp+0xB0], xmm12
0000796da41dccaf  vmovaps [rsp+0xC0], xmm13
0000796da41dccb8  vmovaps [rsp+0xD0], xmm14
0000796da41dccc1  vmovaps [rsp+0xE0], xmm15
0000796da41dccca  sub rsp, 0x30
0000796da41dccce  movaps [rsp], xmm9
0000796da41dccd3  movaps [rsp+0x10], xmm8
0000796da41dccd9  movaps [rsp+0x20], xmm11
0000796da41dccdf  lea rdi, [rsp]
0000796da41dcce3  mov esi, 0x00
0000796da41dcce8  mov rax, 0x5E26CB66A530
0000796da41dccf2  call rax
0000796da41dccf4  movaps xmm9, [rsp]
0000796da41dccf9  add rsp, 0x30
0000796da41dccfd  vmovaps xmm0, [rsp]
0000796da41dcd02  vmovaps xmm1, [rsp+0x10]
0000796da41dcd08  vmovaps xmm2, [rsp+0x20]
0000796da41dcd0e  vmovaps xmm3, [rsp+0x30]
0000796da41dcd14  vmovaps xmm4, [rsp+0x40]
0000796da41dcd1a  vmovaps xmm5, [rsp+0x50]
0000796da41dcd20  vmovaps xmm6, [rsp+0x60]
0000796da41dcd26  vmovaps xmm7, [rsp+0x70]
0000796da41dcd2c  vmovaps xmm8, [rsp+0x80]
0000796da41dcd35  vmovaps xmm10, [rsp+0x90]
0000796da41dcd3e  vmovaps xmm11, [rsp+0xA0]
0000796da41dcd47  vmovaps xmm12, [rsp+0xB0]
0000796da41dcd50  vmovaps xmm13, [rsp+0xC0]
0000796da41dcd59  vmovaps xmm14, [rsp+0xD0]
0000796da41dcd62  vmovaps xmm15, [rsp+0xE0]
0000796da41dcd6b  add rsp, 0xF0
0000796da41dcd72  pop r11
0000796da41dcd74  pop r10
0000796da41dcd76  pop r9
0000796da41dcd78  pop r8
0000796da41dcd7a  pop rsi
0000796da41dcd7b  pop rdi
0000796da41dcd7c  pop rdx
0000796da41dcd7d  pop rcx
0000796da41dcd7e  pop rax
0000796da41dcd7f  add rsp, 0x08
0000796da41dcd83  jmp 0x0000796DA41D9532
0000796da41dcd88  sub rsp, 0x08
0000796da41dcd8c  push rax
0000796da41dcd8d  push rcx
0000796da41dcd8e  push rdx
0000796da41dcd8f  push rdi
0000796da41dcd90  push rsi
0000796da41dcd91  push r8
0000796da41dcd93  push r9
0000796da41dcd95  push r10
0000796da41dcd97  push r11
0000796da41dcd99  sub rsp, 0xF0
0000796da41dcda0  vmovaps [rsp], xmm0
0000796da41dcda5  vmovaps [rsp+0x10], xmm1
0000796da41dcdab  vmovaps [rsp+0x20], xmm2
0000796da41dcdb1  vmovaps [rsp+0x30], xmm3
0000796da41dcdb7  vmovaps [rsp+0x40], xmm4
0000796da41dcdbd  vmovaps [rsp+0x50], xmm5
0000796da41dcdc3  vmovaps [rsp+0x60], xmm6
0000796da41dcdc9  vmovaps [rsp+0x70], xmm7
0000796da41dcdcf  vmovaps [rsp+0x80], xmm8
0000796da41dcdd8  vmovaps [rsp+0x90], xmm9
0000796da41dcde1  vmovaps [rsp+0xA0], xmm10
0000796da41dcdea  vmovaps [rsp+0xB0], xmm12
0000796da41dcdf3  vmovaps [rsp+0xC0], xmm13
0000796da41dcdfc  vmovaps [rsp+0xD0], xmm14
0000796da41dce05  vmovaps [rsp+0xE0], xmm15
0000796da41dce0e  sub rsp, 0x30
0000796da41dce12  movaps [rsp], xmm11
0000796da41dce17  movaps [rsp+0x10], xmm10
0000796da41dce1d  movaps [rsp+0x20], xmm6
0000796da41dce22  lea rdi, [rsp]
0000796da41dce26  mov esi, 0x00
0000796da41dce2b  mov rax, 0x5E26CB66A530
0000796da41dce35  call rax
0000796da41dce37  movaps xmm11, [rsp]
0000796da41dce3c  add rsp, 0x30
0000796da41dce40  vmovaps xmm0, [rsp]
0000796da41dce45  vmovaps xmm1, [rsp+0x10]
0000796da41dce4b  vmovaps xmm2, [rsp+0x20]
0000796da41dce51  vmovaps xmm3, [rsp+0x30]
0000796da41dce57  vmovaps xmm4, [rsp+0x40]
0000796da41dce5d  vmovaps xmm5, [rsp+0x50]
0000796da41dce63  vmovaps xmm6, [rsp+0x60]
0000796da41dce69  vmovaps xmm7, [rsp+0x70]
0000796da41dce6f  vmovaps xmm8, [rsp+0x80]
0000796da41dce78  vmovaps xmm9, [rsp+0x90]
0000796da41dce81  vmovaps xmm10, [rsp+0xA0]
0000796da41dce8a  vmovaps xmm12, [rsp+0xB0]
0000796da41dce93  vmovaps xmm13, [rsp+0xC0]
0000796da41dce9c  vmovaps xmm14, [rsp+0xD0]
0000796da41dcea5  vmovaps xmm15, [rsp+0xE0]
0000796da41dceae  add rsp, 0xF0
0000796da41dceb5  pop r11
0000796da41dceb7  pop r10
0000796da41dceb9  pop r9
0000796da41dcebb  pop r8
0000796da41dcebd  pop rsi
0000796da41dcebe  pop rdi
0000796da41dcebf  pop rdx
0000796da41dcec0  pop rcx
0000796da41dcec1  pop rax
0000796da41dcec2  add rsp, 0x08
0000796da41dcec6  jmp 0x0000796DA41D954D
0000796da41dcecb  sub rsp, 0x08
0000796da41dcecf  push rax
0000796da41dced0  push rcx
0000796da41dced1  push rdx
0000796da41dced2  push rdi
0000796da41dced3  push rsi
0000796da41dced4  push r8
0000796da41dced6  push r9
0000796da41dced8  push r10
0000796da41dceda  push r11
0000796da41dcedc  sub rsp, 0xF0
0000796da41dcee3  vmovaps [rsp], xmm0
0000796da41dcee8  vmovaps [rsp+0x10], xmm1
0000796da41dceee  vmovaps [rsp+0x20], xmm2
0000796da41dcef4  vmovaps [rsp+0x30], xmm3
0000796da41dcefa  vmovaps [rsp+0x40], xmm4
0000796da41dcf00  vmovaps [rsp+0x50], xmm5
0000796da41dcf06  vmovaps [rsp+0x60], xmm6
0000796da41dcf0c  vmovaps [rsp+0x70], xmm7
0000796da41dcf12  vmovaps [rsp+0x80], xmm8
0000796da41dcf1b  vmovaps [rsp+0x90], xmm9
0000796da41dcf24  vmovaps [rsp+0xA0], xmm11
0000796da41dcf2d  vmovaps [rsp+0xB0], xmm12
0000796da41dcf36  vmovaps [rsp+0xC0], xmm13
0000796da41dcf3f  vmovaps [rsp+0xD0], xmm14
0000796da41dcf48  vmovaps [rsp+0xE0], xmm15
0000796da41dcf51  sub rsp, 0x30
0000796da41dcf55  movaps [rsp], xmm10
0000796da41dcf5a  movaps [rsp+0x10], xmm14
0000796da41dcf60  movaps [rsp+0x20], xmm4
0000796da41dcf65  lea rdi, [rsp]
0000796da41dcf69  mov esi, 0x00
0000796da41dcf6e  mov rax, 0x5E26CB66A530
0000796da41dcf78  call rax
0000796da41dcf7a  movaps xmm10, [rsp]
0000796da41dcf7f  add rsp, 0x30
0000796da41dcf83  vmovaps xmm0, [rsp]
0000796da41dcf88  vmovaps xmm1, [rsp+0x10]
0000796da41dcf8e  vmovaps xmm2, [rsp+0x20]
0000796da41dcf94  vmovaps xmm3, [rsp+0x30]
0000796da41dcf9a  vmovaps xmm4, [rsp+0x40]
0000796da41dcfa0  vmovaps xmm5, [rsp+0x50]
0000796da41dcfa6  vmovaps xmm6, [rsp+0x60]
0000796da41dcfac  vmovaps xmm7, [rsp+0x70]
0000796da41dcfb2  vmovaps xmm8, [rsp+0x80]
0000796da41dcfbb  vmovaps xmm9, [rsp+0x90]
0000796da41dcfc4  vmovaps xmm11, [rsp+0xA0]
0000796da41dcfcd  vmovaps xmm12, [rsp+0xB0]
0000796da41dcfd6  vmovaps xmm13, [rsp+0xC0]
0000796da41dcfdf  vmovaps xmm14, [rsp+0xD0]
0000796da41dcfe8  vmovaps xmm15, [rsp+0xE0]
0000796da41dcff1  add rsp, 0xF0
0000796da41dcff8  pop r11
0000796da41dcffa  pop r10
0000796da41dcffc  pop r9
0000796da41dcffe  pop r8
0000796da41dd000  pop rsi
0000796da41dd001  pop rdi
0000796da41dd002  pop rdx
0000796da41dd003  pop rcx
0000796da41dd004  pop rax
0000796da41dd005  add rsp, 0x08
0000796da41dd009  jmp 0x0000796DA41D9568
0000796da41dd00e  sub rsp, 0x08
0000796da41dd012  push rax
0000796da41dd013  push rcx
0000796da41dd014  push rdx
0000796da41dd015  push rdi
0000796da41dd016  push rsi
0000796da41dd017  push r8
0000796da41dd019  push r9
0000796da41dd01b  push r10
0000796da41dd01d  push r11
0000796da41dd01f  sub rsp, 0xF0
0000796da41dd026  vmovaps [rsp], xmm0
0000796da41dd02b  vmovaps [rsp+0x10], xmm1
0000796da41dd031  vmovaps [rsp+0x20], xmm2
0000796da41dd037  vmovaps [rsp+0x30], xmm3
0000796da41dd03d  vmovaps [rsp+0x40], xmm4
0000796da41dd043  vmovaps [rsp+0x50], xmm5
0000796da41dd049  vmovaps [rsp+0x60], xmm6
0000796da41dd04f  vmovaps [rsp+0x70], xmm7
0000796da41dd055  vmovaps [rsp+0x80], xmm9
0000796da41dd05e  vmovaps [rsp+0x90], xmm10
0000796da41dd067  vmovaps [rsp+0xA0], xmm11
0000796da41dd070  vmovaps [rsp+0xB0], xmm12
0000796da41dd079  vmovaps [rsp+0xC0], xmm13
0000796da41dd082  vmovaps [rsp+0xD0], xmm14
0000796da41dd08b  vmovaps [rsp+0xE0], xmm15
0000796da41dd094  sub rsp, 0x30
0000796da41dd098  movaps [rsp], xmm8
0000796da41dd09d  movaps [rsp+0x10], xmm1
0000796da41dd0a2  movaps [rsp+0x20], xmm14
0000796da41dd0a8  lea rdi, [rsp]
0000796da41dd0ac  mov esi, 0x00
0000796da41dd0b1  mov rax, 0x5E26CB66A530
0000796da41dd0bb  call rax
0000796da41dd0bd  movaps xmm8, [rsp]
0000796da41dd0c2  add rsp, 0x30
0000796da41dd0c6  vmovaps xmm0, [rsp]
0000796da41dd0cb  vmovaps xmm1, [rsp+0x10]
0000796da41dd0d1  vmovaps xmm2, [rsp+0x20]
0000796da41dd0d7  vmovaps xmm3, [rsp+0x30]
0000796da41dd0dd  vmovaps xmm4, [rsp+0x40]
0000796da41dd0e3  vmovaps xmm5, [rsp+0x50]
0000796da41dd0e9  vmovaps xmm6, [rsp+0x60]
0000796da41dd0ef  vmovaps xmm7, [rsp+0x70]
0000796da41dd0f5  vmovaps xmm9, [rsp+0x80]
0000796da41dd0fe  vmovaps xmm10, [rsp+0x90]
0000796da41dd107  vmovaps xmm11, [rsp+0xA0]
0000796da41dd110  vmovaps xmm12, [rsp+0xB0]
0000796da41dd119  vmovaps xmm13, [rsp+0xC0]
0000796da41dd122  vmovaps xmm14, [rsp+0xD0]
0000796da41dd12b  vmovaps xmm15, [rsp+0xE0]
0000796da41dd134  add rsp, 0xF0
0000796da41dd13b  pop r11
0000796da41dd13d  pop r10
0000796da41dd13f  pop r9
0000796da41dd141  pop r8
0000796da41dd143  pop rsi
0000796da41dd144  pop rdi
0000796da41dd145  pop rdx
0000796da41dd146  pop rcx
0000796da41dd147  pop rax
0000796da41dd148  add rsp, 0x08
0000796da41dd14c  jmp 0x0000796DA41D958E
0000796da41dd151  sub rsp, 0x08
0000796da41dd155  push rax
0000796da41dd156  push rcx
0000796da41dd157  push rdx
0000796da41dd158  push rdi
0000796da41dd159  push rsi
0000796da41dd15a  push r8
0000796da41dd15c  push r9
0000796da41dd15e  push r10
0000796da41dd160  push r11
0000796da41dd162  sub rsp, 0xF0
0000796da41dd169  vmovaps [rsp], xmm0
0000796da41dd16e  vmovaps [rsp+0x10], xmm1
0000796da41dd174  vmovaps [rsp+0x20], xmm2
0000796da41dd17a  vmovaps [rsp+0x30], xmm3
0000796da41dd180  vmovaps [rsp+0x40], xmm4
0000796da41dd186  vmovaps [rsp+0x50], xmm5
0000796da41dd18c  vmovaps [rsp+0x60], xmm7
0000796da41dd192  vmovaps [rsp+0x70], xmm8
0000796da41dd198  vmovaps [rsp+0x80], xmm9
0000796da41dd1a1  vmovaps [rsp+0x90], xmm10
0000796da41dd1aa  vmovaps [rsp+0xA0], xmm11
0000796da41dd1b3  vmovaps [rsp+0xB0], xmm12
0000796da41dd1bc  vmovaps [rsp+0xC0], xmm13
0000796da41dd1c5  vmovaps [rsp+0xD0], xmm14
0000796da41dd1ce  vmovaps [rsp+0xE0], xmm15
0000796da41dd1d7  sub rsp, 0x30
0000796da41dd1db  movaps [rsp], xmm6
0000796da41dd1df  movaps [rsp+0x10], xmm1
0000796da41dd1e4  movaps [rsp+0x20], xmm14
0000796da41dd1ea  lea rdi, [rsp]
0000796da41dd1ee  mov esi, 0x00
0000796da41dd1f3  mov rax, 0x5E26CB66A530
0000796da41dd1fd  call rax
0000796da41dd1ff  movaps xmm6, [rsp]
0000796da41dd203  add rsp, 0x30
0000796da41dd207  vmovaps xmm0, [rsp]
0000796da41dd20c  vmovaps xmm1, [rsp+0x10]
0000796da41dd212  vmovaps xmm2, [rsp+0x20]
0000796da41dd218  vmovaps xmm3, [rsp+0x30]
0000796da41dd21e  vmovaps xmm4, [rsp+0x40]
0000796da41dd224  vmovaps xmm5, [rsp+0x50]
0000796da41dd22a  vmovaps xmm7, [rsp+0x60]
0000796da41dd230  vmovaps xmm8, [rsp+0x70]
0000796da41dd236  vmovaps xmm9, [rsp+0x80]
0000796da41dd23f  vmovaps xmm10, [rsp+0x90]
0000796da41dd248  vmovaps xmm11, [rsp+0xA0]
0000796da41dd251  vmovaps xmm12, [rsp+0xB0]
0000796da41dd25a  vmovaps xmm13, [rsp+0xC0]
0000796da41dd263  vmovaps xmm14, [rsp+0xD0]
0000796da41dd26c  vmovaps xmm15, [rsp+0xE0]
0000796da41dd275  add rsp, 0xF0
0000796da41dd27c  pop r11
0000796da41dd27e  pop r10
0000796da41dd280  pop r9
0000796da41dd282  pop r8
0000796da41dd284  pop rsi
0000796da41dd285  pop rdi
0000796da41dd286  pop rdx
0000796da41dd287  pop rcx
0000796da41dd288  pop rax
0000796da41dd289  add rsp, 0x08
0000796da41dd28d  jmp 0x0000796DA41D95BA
0000796da41dd292  sub rsp, 0x08
0000796da41dd296  push rax
0000796da41dd297  push rcx
0000796da41dd298  push rdx
0000796da41dd299  push rdi
0000796da41dd29a  push rsi
0000796da41dd29b  push r8
0000796da41dd29d  push r9
0000796da41dd29f  push r10
0000796da41dd2a1  push r11
0000796da41dd2a3  sub rsp, 0xF0
0000796da41dd2aa  vmovaps [rsp], xmm0
0000796da41dd2af  vmovaps [rsp+0x10], xmm1
0000796da41dd2b5  vmovaps [rsp+0x20], xmm2
0000796da41dd2bb  vmovaps [rsp+0x30], xmm3
0000796da41dd2c1  vmovaps [rsp+0x40], xmm4
0000796da41dd2c7  vmovaps [rsp+0x50], xmm5
0000796da41dd2cd  vmovaps [rsp+0x60], xmm6
0000796da41dd2d3  vmovaps [rsp+0x70], xmm7
0000796da41dd2d9  vmovaps [rsp+0x80], xmm8
0000796da41dd2e2  vmovaps [rsp+0x90], xmm9
0000796da41dd2eb  vmovaps [rsp+0xA0], xmm10
0000796da41dd2f4  vmovaps [rsp+0xB0], xmm11
0000796da41dd2fd  vmovaps [rsp+0xC0], xmm12
0000796da41dd306  vmovaps [rsp+0xD0], xmm13
0000796da41dd30f  vmovaps [rsp+0xE0], xmm15
0000796da41dd318  sub rsp, 0x30
0000796da41dd31c  movaps [rsp], xmm14
0000796da41dd321  movaps [rsp+0x10], xmm12
0000796da41dd327  movaps [rsp+0x20], xmm1
0000796da41dd32c  lea rdi, [rsp]
0000796da41dd330  mov esi, 0x00
0000796da41dd335  mov rax, 0x5E26CB66A530
0000796da41dd33f  call rax
0000796da41dd341  movaps xmm14, [rsp]
0000796da41dd346  add rsp, 0x30
0000796da41dd34a  vmovaps xmm0, [rsp]
0000796da41dd34f  vmovaps xmm1, [rsp+0x10]
0000796da41dd355  vmovaps xmm2, [rsp+0x20]
0000796da41dd35b  vmovaps xmm3, [rsp+0x30]
0000796da41dd361  vmovaps xmm4, [rsp+0x40]
0000796da41dd367  vmovaps xmm5, [rsp+0x50]
0000796da41dd36d  vmovaps xmm6, [rsp+0x60]
0000796da41dd373  vmovaps xmm7, [rsp+0x70]
0000796da41dd379  vmovaps xmm8, [rsp+0x80]
0000796da41dd382  vmovaps xmm9, [rsp+0x90]
0000796da41dd38b  vmovaps xmm10, [rsp+0xA0]
0000796da41dd394  vmovaps xmm11, [rsp+0xB0]
0000796da41dd39d  vmovaps xmm12, [rsp+0xC0]
0000796da41dd3a6  vmovaps xmm13, [rsp+0xD0]
0000796da41dd3af  vmovaps xmm15, [rsp+0xE0]
0000796da41dd3b8  add rsp, 0xF0
0000796da41dd3bf  pop r11
0000796da41dd3c1  pop r10
0000796da41dd3c3  pop r9
0000796da41dd3c5  pop r8
0000796da41dd3c7  pop rsi
0000796da41dd3c8  pop rdi
0000796da41dd3c9  pop rdx
0000796da41dd3ca  pop rcx
0000796da41dd3cb  pop rax
0000796da41dd3cc  add rsp, 0x08
0000796da41dd3d0  jmp 0x0000796DA41D95E0
0000796da41dd3d5  sub rsp, 0x08
0000796da41dd3d9  push rax
0000796da41dd3da  push rcx
0000796da41dd3db  push rdx
0000796da41dd3dc  push rdi
0000796da41dd3dd  push rsi
0000796da41dd3de  push r8
0000796da41dd3e0  push r9
0000796da41dd3e2  push r10
0000796da41dd3e4  push r11
0000796da41dd3e6  sub rsp, 0xF0
0000796da41dd3ed  vmovaps [rsp], xmm0
0000796da41dd3f2  vmovaps [rsp+0x10], xmm2
0000796da41dd3f8  vmovaps [rsp+0x20], xmm3
0000796da41dd3fe  vmovaps [rsp+0x30], xmm4
0000796da41dd404  vmovaps [rsp+0x40], xmm5
0000796da41dd40a  vmovaps [rsp+0x50], xmm6
0000796da41dd410  vmovaps [rsp+0x60], xmm7
0000796da41dd416  vmovaps [rsp+0x70], xmm8
0000796da41dd41c  vmovaps [rsp+0x80], xmm9
0000796da41dd425  vmovaps [rsp+0x90], xmm10
0000796da41dd42e  vmovaps [rsp+0xA0], xmm11
0000796da41dd437  vmovaps [rsp+0xB0], xmm12
0000796da41dd440  vmovaps [rsp+0xC0], xmm13
0000796da41dd449  vmovaps [rsp+0xD0], xmm14
0000796da41dd452  vmovaps [rsp+0xE0], xmm15
0000796da41dd45b  sub rsp, 0x30
0000796da41dd45f  movaps [rsp], xmm1
0000796da41dd463  movaps [rsp+0x10], xmm13
0000796da41dd469  movaps [rsp+0x20], xmm9
0000796da41dd46f  lea rdi, [rsp]
0000796da41dd473  mov esi, 0x00
0000796da41dd478  mov rax, 0x5E26CB66A530
0000796da41dd482  call rax
0000796da41dd484  movaps xmm1, [rsp]
0000796da41dd488  add rsp, 0x30
0000796da41dd48c  vmovaps xmm0, [rsp]
0000796da41dd491  vmovaps xmm2, [rsp+0x10]
0000796da41dd497  vmovaps xmm3, [rsp+0x20]
0000796da41dd49d  vmovaps xmm4, [rsp+0x30]
0000796da41dd4a3  vmovaps xmm5, [rsp+0x40]
0000796da41dd4a9  vmovaps xmm6, [rsp+0x50]
0000796da41dd4af  vmovaps xmm7, [rsp+0x60]
0000796da41dd4b5  vmovaps xmm8, [rsp+0x70]
0000796da41dd4bb  vmovaps xmm9, [rsp+0x80]
0000796da41dd4c4  vmovaps xmm10, [rsp+0x90]
0000796da41dd4cd  vmovaps xmm11, [rsp+0xA0]
0000796da41dd4d6  vmovaps xmm12, [rsp+0xB0]
0000796da41dd4df  vmovaps xmm13, [rsp+0xC0]
0000796da41dd4e8  vmovaps xmm14, [rsp+0xD0]
0000796da41dd4f1  vmovaps xmm15, [rsp+0xE0]
0000796da41dd4fa  add rsp, 0xF0
0000796da41dd501  pop r11
0000796da41dd503  pop r10
0000796da41dd505  pop r9
0000796da41dd507  pop r8
0000796da41dd509  pop rsi
0000796da41dd50a  pop rdi
0000796da41dd50b  pop rdx
0000796da41dd50c  pop rcx
0000796da41dd50d  pop rax
0000796da41dd50e  add rsp, 0x08
0000796da41dd512  jmp 0x0000796DA41D95FA
0000796da41dd517  sub rsp, 0x08
0000796da41dd51b  push rax
0000796da41dd51c  push rcx
0000796da41dd51d  push rdx
0000796da41dd51e  push rdi
0000796da41dd51f  push rsi
0000796da41dd520  push r8
0000796da41dd522  push r9
0000796da41dd524  push r10
0000796da41dd526  push r11
0000796da41dd528  sub rsp, 0xF0
0000796da41dd52f  vmovaps [rsp], xmm0
0000796da41dd534  vmovaps [rsp+0x10], xmm1
0000796da41dd53a  vmovaps [rsp+0x20], xmm2
0000796da41dd540  vmovaps [rsp+0x30], xmm3
0000796da41dd546  vmovaps [rsp+0x40], xmm4
0000796da41dd54c  vmovaps [rsp+0x50], xmm5
0000796da41dd552  vmovaps [rsp+0x60], xmm6
0000796da41dd558  vmovaps [rsp+0x70], xmm7
0000796da41dd55e  vmovaps [rsp+0x80], xmm8
0000796da41dd567  vmovaps [rsp+0x90], xmm9
0000796da41dd570  vmovaps [rsp+0xA0], xmm10
0000796da41dd579  vmovaps [rsp+0xB0], xmm11
0000796da41dd582  vmovaps [rsp+0xC0], xmm13
0000796da41dd58b  vmovaps [rsp+0xD0], xmm14
0000796da41dd594  vmovaps [rsp+0xE0], xmm15
0000796da41dd59d  sub rsp, 0x30
0000796da41dd5a1  movaps [rsp], xmm12
0000796da41dd5a6  movaps [rsp+0x10], xmm7
0000796da41dd5ab  movaps [rsp+0x20], xmm13
0000796da41dd5b1  lea rdi, [rsp]
0000796da41dd5b5  mov esi, 0x00
0000796da41dd5ba  mov rax, 0x5E26CB66A530
0000796da41dd5c4  call rax
0000796da41dd5c6  movaps xmm12, [rsp]
0000796da41dd5cb  add rsp, 0x30
0000796da41dd5cf  vmovaps xmm0, [rsp]
0000796da41dd5d4  vmovaps xmm1, [rsp+0x10]
0000796da41dd5da  vmovaps xmm2, [rsp+0x20]
0000796da41dd5e0  vmovaps xmm3, [rsp+0x30]
0000796da41dd5e6  vmovaps xmm4, [rsp+0x40]
0000796da41dd5ec  vmovaps xmm5, [rsp+0x50]
0000796da41dd5f2  vmovaps xmm6, [rsp+0x60]
0000796da41dd5f8  vmovaps xmm7, [rsp+0x70]
0000796da41dd5fe  vmovaps xmm8, [rsp+0x80]
0000796da41dd607  vmovaps xmm9, [rsp+0x90]
0000796da41dd610  vmovaps xmm10, [rsp+0xA0]
0000796da41dd619  vmovaps xmm11, [rsp+0xB0]
0000796da41dd622  vmovaps xmm13, [rsp+0xC0]
0000796da41dd62b  vmovaps xmm14, [rsp+0xD0]
0000796da41dd634  vmovaps xmm15, [rsp+0xE0]
0000796da41dd63d  add rsp, 0xF0
0000796da41dd644  pop r11
0000796da41dd646  pop r10
0000796da41dd648  pop r9
0000796da41dd64a  pop r8
0000796da41dd64c  pop rsi
0000796da41dd64d  pop rdi
0000796da41dd64e  pop rdx
0000796da41dd64f  pop rcx
0000796da41dd650  pop rax
0000796da41dd651  add rsp, 0x08
0000796da41dd655  jmp 0x0000796DA41D9621
0000796da41dd65a  sub rsp, 0x08
0000796da41dd65e  push rax
0000796da41dd65f  push rcx
0000796da41dd660  push rdx
0000796da41dd661  push rdi
0000796da41dd662  push rsi
0000796da41dd663  push r8
0000796da41dd665  push r9
0000796da41dd667  push r10
0000796da41dd669  push r11
0000796da41dd66b  sub rsp, 0xF0
0000796da41dd672  vmovaps [rsp], xmm0
0000796da41dd677  vmovaps [rsp+0x10], xmm1
0000796da41dd67d  vmovaps [rsp+0x20], xmm2
0000796da41dd683  vmovaps [rsp+0x30], xmm3
0000796da41dd689  vmovaps [rsp+0x40], xmm4
0000796da41dd68f  vmovaps [rsp+0x50], xmm5
0000796da41dd695  vmovaps [rsp+0x60], xmm6
0000796da41dd69b  vmovaps [rsp+0x70], xmm7
0000796da41dd6a1  vmovaps [rsp+0x80], xmm8
0000796da41dd6aa  vmovaps [rsp+0x90], xmm9
0000796da41dd6b3  vmovaps [rsp+0xA0], xmm10
0000796da41dd6bc  vmovaps [rsp+0xB0], xmm11
0000796da41dd6c5  vmovaps [rsp+0xC0], xmm12
0000796da41dd6ce  vmovaps [rsp+0xD0], xmm14
0000796da41dd6d7  vmovaps [rsp+0xE0], xmm15
0000796da41dd6e0  sub rsp, 0x30
0000796da41dd6e4  movaps [rsp], xmm13
0000796da41dd6e9  movaps [rsp+0x10], xmm15
0000796da41dd6ef  movaps [rsp+0x20], xmm8
0000796da41dd6f5  lea rdi, [rsp]
0000796da41dd6f9  mov esi, 0x00
0000796da41dd6fe  mov rax, 0x5E26CB66A530
0000796da41dd708  call rax
0000796da41dd70a  movaps xmm13, [rsp]
0000796da41dd70f  add rsp, 0x30
0000796da41dd713  vmovaps xmm0, [rsp]
0000796da41dd718  vmovaps xmm1, [rsp+0x10]
0000796da41dd71e  vmovaps xmm2, [rsp+0x20]
0000796da41dd724  vmovaps xmm3, [rsp+0x30]
0000796da41dd72a  vmovaps xmm4, [rsp+0x40]
0000796da41dd730  vmovaps xmm5, [rsp+0x50]
0000796da41dd736  vmovaps xmm6, [rsp+0x60]
0000796da41dd73c  vmovaps xmm7, [rsp+0x70]
0000796da41dd742  vmovaps xmm8, [rsp+0x80]
0000796da41dd74b  vmovaps xmm9, [rsp+0x90]
0000796da41dd754  vmovaps xmm10, [rsp+0xA0]
0000796da41dd75d  vmovaps xmm11, [rsp+0xB0]
0000796da41dd766  vmovaps xmm12, [rsp+0xC0]
0000796da41dd76f  vmovaps xmm14, [rsp+0xD0]
0000796da41dd778  vmovaps xmm15, [rsp+0xE0]
0000796da41dd781  add rsp, 0xF0
0000796da41dd788  pop r11
0000796da41dd78a  pop r10
0000796da41dd78c  pop r9
0000796da41dd78e  pop r8
0000796da41dd790  pop rsi
0000796da41dd791  pop rdi
0000796da41dd792  pop rdx
0000796da41dd793  pop rcx
0000796da41dd794  pop rax
0000796da41dd795  add rsp, 0x08
0000796da41dd799  jmp 0x0000796DA41D963C
0000796da41dd79e  sub rsp, 0x08
0000796da41dd7a2  push rax
0000796da41dd7a3  push rcx
0000796da41dd7a4  push rdx
0000796da41dd7a5  push rdi
0000796da41dd7a6  push rsi
0000796da41dd7a7  push r8
0000796da41dd7a9  push r9
0000796da41dd7ab  push r10
0000796da41dd7ad  push r11
0000796da41dd7af  sub rsp, 0xF0
0000796da41dd7b6  vmovaps [rsp], xmm0
0000796da41dd7bb  vmovaps [rsp+0x10], xmm1
0000796da41dd7c1  vmovaps [rsp+0x20], xmm2
0000796da41dd7c7  vmovaps [rsp+0x30], xmm3
0000796da41dd7cd  vmovaps [rsp+0x40], xmm4
0000796da41dd7d3  vmovaps [rsp+0x50], xmm5
0000796da41dd7d9  vmovaps [rsp+0x60], xmm6
0000796da41dd7df  vmovaps [rsp+0x70], xmm7
0000796da41dd7e5  vmovaps [rsp+0x80], xmm9
0000796da41dd7ee  vmovaps [rsp+0x90], xmm10
0000796da41dd7f7  vmovaps [rsp+0xA0], xmm11
0000796da41dd800  vmovaps [rsp+0xB0], xmm12
0000796da41dd809  vmovaps [rsp+0xC0], xmm13
0000796da41dd812  vmovaps [rsp+0xD0], xmm14
0000796da41dd81b  vmovaps [rsp+0xE0], xmm15
0000796da41dd824  sub rsp, 0x30
0000796da41dd828  movaps [rsp], xmm8
0000796da41dd82d  movaps [rsp+0x10], xmm15
0000796da41dd833  movaps [rsp+0x20], xmm9
0000796da41dd839  lea rdi, [rsp]
0000796da41dd83d  mov esi, 0x00
0000796da41dd842  mov rax, 0x5E26CB66A530
0000796da41dd84c  call rax
0000796da41dd84e  movaps xmm8, [rsp]
0000796da41dd853  add rsp, 0x30
0000796da41dd857  vmovaps xmm0, [rsp]
0000796da41dd85c  vmovaps xmm1, [rsp+0x10]
0000796da41dd862  vmovaps xmm2, [rsp+0x20]
0000796da41dd868  vmovaps xmm3, [rsp+0x30]
0000796da41dd86e  vmovaps xmm4, [rsp+0x40]
0000796da41dd874  vmovaps xmm5, [rsp+0x50]
0000796da41dd87a  vmovaps xmm6, [rsp+0x60]
0000796da41dd880  vmovaps xmm7, [rsp+0x70]
0000796da41dd886  vmovaps xmm9, [rsp+0x80]
0000796da41dd88f  vmovaps xmm10, [rsp+0x90]
0000796da41dd898  vmovaps xmm11, [rsp+0xA0]
0000796da41dd8a1  vmovaps xmm12, [rsp+0xB0]
0000796da41dd8aa  vmovaps xmm13, [rsp+0xC0]
0000796da41dd8b3  vmovaps xmm14, [rsp+0xD0]
0000796da41dd8bc  vmovaps xmm15, [rsp+0xE0]
0000796da41dd8c5  add rsp, 0xF0
0000796da41dd8cc  pop r11
0000796da41dd8ce  pop r10
0000796da41dd8d0  pop r9
0000796da41dd8d2  pop r8
0000796da41dd8d4  pop rsi
0000796da41dd8d5  pop rdi
0000796da41dd8d6  pop rdx
0000796da41dd8d7  pop rcx
0000796da41dd8d8  pop rax
0000796da41dd8d9  add rsp, 0x08
0000796da41dd8dd  jmp 0x0000796DA41D966A
0000796da41dd8e2  sub rsp, 0x08
0000796da41dd8e6  push rax
0000796da41dd8e7  push rcx
0000796da41dd8e8  push rdx
0000796da41dd8e9  push rdi
0000796da41dd8ea  push rsi
0000796da41dd8eb  push r8
0000796da41dd8ed  push r9
0000796da41dd8ef  push r10
0000796da41dd8f1  push r11
0000796da41dd8f3  sub rsp, 0xF0
0000796da41dd8fa  vmovaps [rsp], xmm0
0000796da41dd8ff  vmovaps [rsp+0x10], xmm1
0000796da41dd905  vmovaps [rsp+0x20], xmm2
0000796da41dd90b  vmovaps [rsp+0x30], xmm3
0000796da41dd911  vmovaps [rsp+0x40], xmm4
0000796da41dd917  vmovaps [rsp+0x50], xmm5
0000796da41dd91d  vmovaps [rsp+0x60], xmm6
0000796da41dd923  vmovaps [rsp+0x70], xmm7
0000796da41dd929  vmovaps [rsp+0x80], xmm8
0000796da41dd932  vmovaps [rsp+0x90], xmm9
0000796da41dd93b  vmovaps [rsp+0xA0], xmm10
0000796da41dd944  vmovaps [rsp+0xB0], xmm11
0000796da41dd94d  vmovaps [rsp+0xC0], xmm12
0000796da41dd956  vmovaps [rsp+0xD0], xmm13
0000796da41dd95f  vmovaps [rsp+0xE0], xmm14
0000796da41dd968  sub rsp, 0x30
0000796da41dd96c  movaps [rsp], xmm15
0000796da41dd971  movaps [rsp+0x10], xmm11
0000796da41dd977  movaps [rsp+0x20], xmm6
0000796da41dd97c  lea rdi, [rsp]
0000796da41dd980  mov esi, 0x00
0000796da41dd985  mov rax, 0x5E26CB66A530
0000796da41dd98f  call rax
0000796da41dd991  movaps xmm15, [rsp]
0000796da41dd996  add rsp, 0x30
0000796da41dd99a  vmovaps xmm0, [rsp]
0000796da41dd99f  vmovaps xmm1, [rsp+0x10]
0000796da41dd9a5  vmovaps xmm2, [rsp+0x20]
0000796da41dd9ab  vmovaps xmm3, [rsp+0x30]
0000796da41dd9b1  vmovaps xmm4, [rsp+0x40]
0000796da41dd9b7  vmovaps xmm5, [rsp+0x50]
0000796da41dd9bd  vmovaps xmm6, [rsp+0x60]
0000796da41dd9c3  vmovaps xmm7, [rsp+0x70]
0000796da41dd9c9  vmovaps xmm8, [rsp+0x80]
0000796da41dd9d2  vmovaps xmm9, [rsp+0x90]
0000796da41dd9db  vmovaps xmm10, [rsp+0xA0]
0000796da41dd9e4  vmovaps xmm11, [rsp+0xB0]
0000796da41dd9ed  vmovaps xmm12, [rsp+0xC0]
0000796da41dd9f6  vmovaps xmm13, [rsp+0xD0]
0000796da41dd9ff  vmovaps xmm14, [rsp+0xE0]
0000796da41dda08  add rsp, 0xF0
0000796da41dda0f  pop r11
0000796da41dda11  pop r10
0000796da41dda13  pop r9
0000796da41dda15  pop r8
0000796da41dda17  pop rsi
0000796da41dda18  pop rdi
0000796da41dda19  pop rdx
0000796da41dda1a  pop rcx
0000796da41dda1b  pop rax
0000796da41dda1c  add rsp, 0x08
0000796da41dda20  jmp 0x0000796DA41D9685
0000796da41dda25  sub rsp, 0x08
0000796da41dda29  push rax
0000796da41dda2a  push rcx
0000796da41dda2b  push rdx
0000796da41dda2c  push rdi
0000796da41dda2d  push rsi
0000796da41dda2e  push r8
0000796da41dda30  push r9
0000796da41dda32  push r10
0000796da41dda34  push r11
0000796da41dda36  sub rsp, 0xF0
0000796da41dda3d  vmovaps [rsp], xmm0
0000796da41dda42  vmovaps [rsp+0x10], xmm1
0000796da41dda48  vmovaps [rsp+0x20], xmm2
0000796da41dda4e  vmovaps [rsp+0x30], xmm3
0000796da41dda54  vmovaps [rsp+0x40], xmm4
0000796da41dda5a  vmovaps [rsp+0x50], xmm5
0000796da41dda60  vmovaps [rsp+0x60], xmm6
0000796da41dda66  vmovaps [rsp+0x70], xmm8
0000796da41dda6c  vmovaps [rsp+0x80], xmm9
0000796da41dda75  vmovaps [rsp+0x90], xmm10
0000796da41dda7e  vmovaps [rsp+0xA0], xmm11
0000796da41dda87  vmovaps [rsp+0xB0], xmm12
0000796da41dda90  vmovaps [rsp+0xC0], xmm13
0000796da41dda99  vmovaps [rsp+0xD0], xmm14
0000796da41ddaa2  vmovaps [rsp+0xE0], xmm15
0000796da41ddaab  sub rsp, 0x30
0000796da41ddaaf  movaps [rsp], xmm7
0000796da41ddab3  movaps [rsp+0x10], xmm11
0000796da41ddab9  movaps [rsp+0x20], xmm9
0000796da41ddabf  lea rdi, [rsp]
0000796da41ddac3  mov esi, 0x00
0000796da41ddac8  mov rax, 0x5E26CB66A530
0000796da41ddad2  call rax
0000796da41ddad4  movaps xmm7, [rsp]
0000796da41ddad8  add rsp, 0x30
0000796da41ddadc  vmovaps xmm0, [rsp]
0000796da41ddae1  vmovaps xmm1, [rsp+0x10]
0000796da41ddae7  vmovaps xmm2, [rsp+0x20]
0000796da41ddaed  vmovaps xmm3, [rsp+0x30]
0000796da41ddaf3  vmovaps xmm4, [rsp+0x40]
0000796da41ddaf9  vmovaps xmm5, [rsp+0x50]
0000796da41ddaff  vmovaps xmm6, [rsp+0x60]
0000796da41ddb05  vmovaps xmm8, [rsp+0x70]
0000796da41ddb0b  vmovaps xmm9, [rsp+0x80]
0000796da41ddb14  vmovaps xmm10, [rsp+0x90]
0000796da41ddb1d  vmovaps xmm11, [rsp+0xA0]
0000796da41ddb26  vmovaps xmm12, [rsp+0xB0]
0000796da41ddb2f  vmovaps xmm13, [rsp+0xC0]
0000796da41ddb38  vmovaps xmm14, [rsp+0xD0]
0000796da41ddb41  vmovaps xmm15, [rsp+0xE0]
0000796da41ddb4a  add rsp, 0xF0
0000796da41ddb51  pop r11
0000796da41ddb53  pop r10
0000796da41ddb55  pop r9
0000796da41ddb57  pop r8
0000796da41ddb59  pop rsi
0000796da41ddb5a  pop rdi
0000796da41ddb5b  pop rdx
0000796da41ddb5c  pop rcx
0000796da41ddb5d  pop rax
0000796da41ddb5e  add rsp, 0x08
0000796da41ddb62  jmp 0x0000796DA41D96B2
0000796da41ddb67  sub rsp, 0x08
0000796da41ddb6b  push rax
0000796da41ddb6c  push rcx
0000796da41ddb6d  push rdx
0000796da41ddb6e  push rdi
0000796da41ddb6f  push rsi
0000796da41ddb70  push r8
0000796da41ddb72  push r9
0000796da41ddb74  push r10
0000796da41ddb76  push r11
0000796da41ddb78  sub rsp, 0xF0
0000796da41ddb7f  vmovaps [rsp], xmm0
0000796da41ddb84  vmovaps [rsp+0x10], xmm1
0000796da41ddb8a  vmovaps [rsp+0x20], xmm2
0000796da41ddb90  vmovaps [rsp+0x30], xmm3
0000796da41ddb96  vmovaps [rsp+0x40], xmm4
0000796da41ddb9c  vmovaps [rsp+0x50], xmm5
0000796da41ddba2  vmovaps [rsp+0x60], xmm6
0000796da41ddba8  vmovaps [rsp+0x70], xmm7
0000796da41ddbae  vmovaps [rsp+0x80], xmm8
0000796da41ddbb7  vmovaps [rsp+0x90], xmm9
0000796da41ddbc0  vmovaps [rsp+0xA0], xmm10
0000796da41ddbc9  vmovaps [rsp+0xB0], xmm12
0000796da41ddbd2  vmovaps [rsp+0xC0], xmm13
0000796da41ddbdb  vmovaps [rsp+0xD0], xmm14
0000796da41ddbe4  vmovaps [rsp+0xE0], xmm15
0000796da41ddbed  sub rsp, 0x30
0000796da41ddbf1  movaps [rsp], xmm11
0000796da41ddbf6  movaps [rsp+0x10], xmm10
0000796da41ddbfc  movaps [rsp+0x20], xmm14
0000796da41ddc02  lea rdi, [rsp]
0000796da41ddc06  mov esi, 0x00
0000796da41ddc0b  mov rax, 0x5E26CB66A530
0000796da41ddc15  call rax
0000796da41ddc17  movaps xmm11, [rsp]
0000796da41ddc1c  add rsp, 0x30
0000796da41ddc20  vmovaps xmm0, [rsp]
0000796da41ddc25  vmovaps xmm1, [rsp+0x10]
0000796da41ddc2b  vmovaps xmm2, [rsp+0x20]
0000796da41ddc31  vmovaps xmm3, [rsp+0x30]
0000796da41ddc37  vmovaps xmm4, [rsp+0x40]
0000796da41ddc3d  vmovaps xmm5, [rsp+0x50]
0000796da41ddc43  vmovaps xmm6, [rsp+0x60]
0000796da41ddc49  vmovaps xmm7, [rsp+0x70]
0000796da41ddc4f  vmovaps xmm8, [rsp+0x80]
0000796da41ddc58  vmovaps xmm9, [rsp+0x90]
0000796da41ddc61  vmovaps xmm10, [rsp+0xA0]
0000796da41ddc6a  vmovaps xmm12, [rsp+0xB0]
0000796da41ddc73  vmovaps xmm13, [rsp+0xC0]
0000796da41ddc7c  vmovaps xmm14, [rsp+0xD0]
0000796da41ddc85  vmovaps xmm15, [rsp+0xE0]
0000796da41ddc8e  add rsp, 0xF0
0000796da41ddc95  pop r11
0000796da41ddc97  pop r10
0000796da41ddc99  pop r9
0000796da41ddc9b  pop r8
0000796da41ddc9d  pop rsi
0000796da41ddc9e  pop rdi
0000796da41ddc9f  pop rdx
0000796da41ddca0  pop rcx
0000796da41ddca1  pop rax
0000796da41ddca2  add rsp, 0x08
0000796da41ddca6  jmp 0x0000796DA41D96CD
0000796da41ddcab  call 0x0000796DA40E45A0
0000796da41ddcb0  jmp 0x0000796DA41D96D7
0000796da41ddcb5  sub rsp, 0x08
0000796da41ddcb9  push rax
0000796da41ddcba  push rcx
0000796da41ddcbb  push rdx
0000796da41ddcbc  push rdi
0000796da41ddcbd  push rsi
0000796da41ddcbe  push r8
0000796da41ddcc0  push r9
0000796da41ddcc2  push r10
0000796da41ddcc4  push r11
0000796da41ddcc6  sub rsp, 0xF0
0000796da41ddccd  vmovaps [rsp], xmm0
0000796da41ddcd2  vmovaps [rsp+0x10], xmm1
0000796da41ddcd8  vmovaps [rsp+0x20], xmm2
0000796da41ddcde  vmovaps [rsp+0x30], xmm3
0000796da41ddce4  vmovaps [rsp+0x40], xmm4
0000796da41ddcea  vmovaps [rsp+0x50], xmm5
0000796da41ddcf0  vmovaps [rsp+0x60], xmm6
0000796da41ddcf6  vmovaps [rsp+0x70], xmm7
0000796da41ddcfc  vmovaps [rsp+0x80], xmm8
0000796da41ddd05  vmovaps [rsp+0x90], xmm9
0000796da41ddd0e  vmovaps [rsp+0xA0], xmm11
0000796da41ddd17  vmovaps [rsp+0xB0], xmm12
0000796da41ddd20  vmovaps [rsp+0xC0], xmm13
0000796da41ddd29  vmovaps [rsp+0xD0], xmm14
0000796da41ddd32  vmovaps [rsp+0xE0], xmm15
0000796da41ddd3b  sub rsp, 0x30
0000796da41ddd3f  movaps [rsp], xmm10
0000796da41ddd44  movaps [rsp+0x10], xmm1
0000796da41ddd49  movaps [rsp+0x20], xmm12
0000796da41ddd4f  lea rdi, [rsp]
0000796da41ddd53  mov esi, 0x00
0000796da41ddd58  mov rax, 0x5E26CB66A530
0000796da41ddd62  call rax
0000796da41ddd64  movaps xmm10, [rsp]
0000796da41ddd69  add rsp, 0x30
0000796da41ddd6d  vmovaps xmm0, [rsp]
0000796da41ddd72  vmovaps xmm1, [rsp+0x10]
0000796da41ddd78  vmovaps xmm2, [rsp+0x20]
0000796da41ddd7e  vmovaps xmm3, [rsp+0x30]
0000796da41ddd84  vmovaps xmm4, [rsp+0x40]
0000796da41ddd8a  vmovaps xmm5, [rsp+0x50]
0000796da41ddd90  vmovaps xmm6, [rsp+0x60]
0000796da41ddd96  vmovaps xmm7, [rsp+0x70]
0000796da41ddd9c  vmovaps xmm8, [rsp+0x80]
0000796da41ddda5  vmovaps xmm9, [rsp+0x90]
0000796da41dddae  vmovaps xmm11, [rsp+0xA0]
0000796da41dddb7  vmovaps xmm12, [rsp+0xB0]
0000796da41dddc0  vmovaps xmm13, [rsp+0xC0]
0000796da41dddc9  vmovaps xmm14, [rsp+0xD0]
0000796da41dddd2  vmovaps xmm15, [rsp+0xE0]
0000796da41ddddb  add rsp, 0xF0
0000796da41ddde2  pop r11
0000796da41ddde4  pop r10
0000796da41ddde6  pop r9
0000796da41ddde8  pop r8
0000796da41dddea  pop rsi
0000796da41dddeb  pop rdi
0000796da41dddec  pop rdx
0000796da41ddded  pop rcx
0000796da41dddee  pop rax
0000796da41dddef  add rsp, 0x08
0000796da41dddf3  jmp 0x0000796DA41D96FA
0000796da41dddf8  sub rsp, 0x08
0000796da41dddfc  push rax
0000796da41dddfd  push rcx
0000796da41dddfe  push rdx
0000796da41dddff  push rdi
0000796da41dde00  push rsi
0000796da41dde01  push r8
0000796da41dde03  push r9
0000796da41dde05  push r10
0000796da41dde07  push r11
0000796da41dde09  sub rsp, 0xF0
0000796da41dde10  vmovaps [rsp], xmm0
0000796da41dde15  vmovaps [rsp+0x10], xmm1
0000796da41dde1b  vmovaps [rsp+0x20], xmm2
0000796da41dde21  vmovaps [rsp+0x30], xmm3
0000796da41dde27  vmovaps [rsp+0x40], xmm4
0000796da41dde2d  vmovaps [rsp+0x50], xmm5
0000796da41dde33  vmovaps [rsp+0x60], xmm6
0000796da41dde39  vmovaps [rsp+0x70], xmm7
0000796da41dde3f  vmovaps [rsp+0x80], xmm8
0000796da41dde48  vmovaps [rsp+0x90], xmm9
0000796da41dde51  vmovaps [rsp+0xA0], xmm10
0000796da41dde5a  vmovaps [rsp+0xB0], xmm11
0000796da41dde63  vmovaps [rsp+0xC0], xmm13
0000796da41dde6c  vmovaps [rsp+0xD0], xmm14
0000796da41dde75  vmovaps [rsp+0xE0], xmm15
0000796da41dde7e  sub rsp, 0x30
0000796da41dde82  movaps [rsp], xmm12
0000796da41dde87  movaps [rsp+0x10], xmm14
0000796da41dde8d  movaps [rsp+0x20], xmm1
0000796da41dde92  lea rdi, [rsp]
0000796da41dde96  mov esi, 0x00
0000796da41dde9b  mov rax, 0x5E26CB66A530
0000796da41ddea5  call rax
0000796da41ddea7  movaps xmm12, [rsp]
0000796da41ddeac  add rsp, 0x30
0000796da41ddeb0  vmovaps xmm0, [rsp]
0000796da41ddeb5  vmovaps xmm1, [rsp+0x10]
0000796da41ddebb  vmovaps xmm2, [rsp+0x20]
0000796da41ddec1  vmovaps xmm3, [rsp+0x30]
0000796da41ddec7  vmovaps xmm4, [rsp+0x40]
0000796da41ddecd  vmovaps xmm5, [rsp+0x50]
0000796da41dded3  vmovaps xmm6, [rsp+0x60]
0000796da41dded9  vmovaps xmm7, [rsp+0x70]
0000796da41ddedf  vmovaps xmm8, [rsp+0x80]
0000796da41ddee8  vmovaps xmm9, [rsp+0x90]
0000796da41ddef1  vmovaps xmm10, [rsp+0xA0]
0000796da41ddefa  vmovaps xmm11, [rsp+0xB0]
0000796da41ddf03  vmovaps xmm13, [rsp+0xC0]
0000796da41ddf0c  vmovaps xmm14, [rsp+0xD0]
0000796da41ddf15  vmovaps xmm15, [rsp+0xE0]
0000796da41ddf1e  add rsp, 0xF0
0000796da41ddf25  pop r11
0000796da41ddf27  pop r10
0000796da41ddf29  pop r9
0000796da41ddf2b  pop r8
0000796da41ddf2d  pop rsi
0000796da41ddf2e  pop rdi
0000796da41ddf2f  pop rdx
0000796da41ddf30  pop rcx
0000796da41ddf31  pop rax
0000796da41ddf32  add rsp, 0x08
0000796da41ddf36  jmp 0x0000796DA41D9729
0000796da41ddf3b  sub rsp, 0x08
0000796da41ddf3f  push rax
0000796da41ddf40  push rcx
0000796da41ddf41  push rdx
0000796da41ddf42  push rdi
0000796da41ddf43  push rsi
0000796da41ddf44  push r8
0000796da41ddf46  push r9
0000796da41ddf48  push r10
0000796da41ddf4a  push r11
0000796da41ddf4c  sub rsp, 0xF0
0000796da41ddf53  vmovaps [rsp], xmm0
0000796da41ddf58  vmovaps [rsp+0x10], xmm1
0000796da41ddf5e  vmovaps [rsp+0x20], xmm2
0000796da41ddf64  vmovaps [rsp+0x30], xmm3
0000796da41ddf6a  vmovaps [rsp+0x40], xmm4
0000796da41ddf70  vmovaps [rsp+0x50], xmm5
0000796da41ddf76  vmovaps [rsp+0x60], xmm6
0000796da41ddf7c  vmovaps [rsp+0x70], xmm7
0000796da41ddf82  vmovaps [rsp+0x80], xmm8
0000796da41ddf8b  vmovaps [rsp+0x90], xmm9
0000796da41ddf94  vmovaps [rsp+0xA0], xmm10
0000796da41ddf9d  vmovaps [rsp+0xB0], xmm11
0000796da41ddfa6  vmovaps [rsp+0xC0], xmm12
0000796da41ddfaf  vmovaps [rsp+0xD0], xmm13
0000796da41ddfb8  vmovaps [rsp+0xE0], xmm15
0000796da41ddfc1  sub rsp, 0x30
0000796da41ddfc5  movaps [rsp], xmm14
0000796da41ddfca  movaps [rsp+0x10], xmm9
0000796da41ddfd0  movaps [rsp+0x20], xmm1
0000796da41ddfd5  lea rdi, [rsp]
0000796da41ddfd9  mov esi, 0x00
0000796da41ddfde  mov rax, 0x5E26CB66A530
0000796da41ddfe8  call rax
0000796da41ddfea  movaps xmm14, [rsp]
0000796da41ddfef  add rsp, 0x30
0000796da41ddff3  vmovaps xmm0, [rsp]
0000796da41ddff8  vmovaps xmm1, [rsp+0x10]
0000796da41ddffe  vmovaps xmm2, [rsp+0x20]
0000796da41de004  vmovaps xmm3, [rsp+0x30]
0000796da41de00a  vmovaps xmm4, [rsp+0x40]
0000796da41de010  vmovaps xmm5, [rsp+0x50]
0000796da41de016  vmovaps xmm6, [rsp+0x60]
0000796da41de01c  vmovaps xmm7, [rsp+0x70]
0000796da41de022  vmovaps xmm8, [rsp+0x80]
0000796da41de02b  vmovaps xmm9, [rsp+0x90]
0000796da41de034  vmovaps xmm10, [rsp+0xA0]
0000796da41de03d  vmovaps xmm11, [rsp+0xB0]
0000796da41de046  vmovaps xmm12, [rsp+0xC0]
0000796da41de04f  vmovaps xmm13, [rsp+0xD0]
0000796da41de058  vmovaps xmm15, [rsp+0xE0]
0000796da41de061  add rsp, 0xF0
0000796da41de068  pop r11
0000796da41de06a  pop r10
0000796da41de06c  pop r9
0000796da41de06e  pop r8
0000796da41de070  pop rsi
0000796da41de071  pop rdi
0000796da41de072  pop rdx
0000796da41de073  pop rcx
0000796da41de074  pop rax
0000796da41de075  add rsp, 0x08
0000796da41de079  jmp 0x0000796DA41D9758
0000796da41de07e  sub rsp, 0x08
0000796da41de082  push rax
0000796da41de083  push rcx
0000796da41de084  push rdx
0000796da41de085  push rdi
0000796da41de086  push rsi
0000796da41de087  push r8
0000796da41de089  push r9
0000796da41de08b  push r10
0000796da41de08d  push r11
0000796da41de08f  sub rsp, 0xF0
0000796da41de096  vmovaps [rsp], xmm0
0000796da41de09b  vmovaps [rsp+0x10], xmm2
0000796da41de0a1  vmovaps [rsp+0x20], xmm3
0000796da41de0a7  vmovaps [rsp+0x30], xmm4
0000796da41de0ad  vmovaps [rsp+0x40], xmm5
0000796da41de0b3  vmovaps [rsp+0x50], xmm6
0000796da41de0b9  vmovaps [rsp+0x60], xmm7
0000796da41de0bf  vmovaps [rsp+0x70], xmm8
0000796da41de0c5  vmovaps [rsp+0x80], xmm9
0000796da41de0ce  vmovaps [rsp+0x90], xmm10
0000796da41de0d7  vmovaps [rsp+0xA0], xmm11
0000796da41de0e0  vmovaps [rsp+0xB0], xmm12
0000796da41de0e9  vmovaps [rsp+0xC0], xmm13
0000796da41de0f2  vmovaps [rsp+0xD0], xmm14
0000796da41de0fb  vmovaps [rsp+0xE0], xmm15
0000796da41de104  sub rsp, 0x30
0000796da41de108  movaps [rsp], xmm1
0000796da41de10c  movaps [rsp+0x10], xmm13
0000796da41de112  movaps [rsp+0x20], xmm8
0000796da41de118  lea rdi, [rsp]
0000796da41de11c  mov esi, 0x00
0000796da41de121  mov rax, 0x5E26CB66A530
0000796da41de12b  call rax
0000796da41de12d  movaps xmm1, [rsp]
0000796da41de131  add rsp, 0x30
0000796da41de135  vmovaps xmm0, [rsp]
0000796da41de13a  vmovaps xmm2, [rsp+0x10]
0000796da41de140  vmovaps xmm3, [rsp+0x20]
0000796da41de146  vmovaps xmm4, [rsp+0x30]
0000796da41de14c  vmovaps xmm5, [rsp+0x40]
0000796da41de152  vmovaps xmm6, [rsp+0x50]
0000796da41de158  vmovaps xmm7, [rsp+0x60]
0000796da41de15e  vmovaps xmm8, [rsp+0x70]
0000796da41de164  vmovaps xmm9, [rsp+0x80]
0000796da41de16d  vmovaps xmm10, [rsp+0x90]
0000796da41de176  vmovaps xmm11, [rsp+0xA0]
0000796da41de17f  vmovaps xmm12, [rsp+0xB0]
0000796da41de188  vmovaps xmm13, [rsp+0xC0]
0000796da41de191  vmovaps xmm14, [rsp+0xD0]
0000796da41de19a  vmovaps xmm15, [rsp+0xE0]
0000796da41de1a3  add rsp, 0xF0
0000796da41de1aa  pop r11
0000796da41de1ac  pop r10
0000796da41de1ae  pop r9
0000796da41de1b0  pop r8
0000796da41de1b2  pop rsi
0000796da41de1b3  pop rdi
0000796da41de1b4  pop rdx
0000796da41de1b5  pop rcx
0000796da41de1b6  pop rax
0000796da41de1b7  add rsp, 0x08
0000796da41de1bb  jmp 0x0000796DA41D977A
0000796da41de1c0  call 0x0000796DA400C260
0000796da41de1c5  jmp 0x0000796DA41D9788
0000796da41de1ca  call 0x0000796DA40DE950
0000796da41de1cf  jmp 0x0000796DA41D9792
0000796da41de1d4  sub rsp, 0x08
0000796da41de1d8  push rax
0000796da41de1d9  push rcx
0000796da41de1da  push rdx
0000796da41de1db  push rdi
0000796da41de1dc  push rsi
0000796da41de1dd  push r8
0000796da41de1df  push r9
0000796da41de1e1  push r10
0000796da41de1e3  push r11
0000796da41de1e5  sub rsp, 0xF0
0000796da41de1ec  vmovaps [rsp], xmm0
0000796da41de1f1  vmovaps [rsp+0x10], xmm1
0000796da41de1f7  vmovaps [rsp+0x20], xmm2
0000796da41de1fd  vmovaps [rsp+0x30], xmm3
0000796da41de203  vmovaps [rsp+0x40], xmm4
0000796da41de209  vmovaps [rsp+0x50], xmm5
0000796da41de20f  vmovaps [rsp+0x60], xmm6
0000796da41de215  vmovaps [rsp+0x70], xmm7
0000796da41de21b  vmovaps [rsp+0x80], xmm9
0000796da41de224  vmovaps [rsp+0x90], xmm10
0000796da41de22d  vmovaps [rsp+0xA0], xmm11
0000796da41de236  vmovaps [rsp+0xB0], xmm12
0000796da41de23f  vmovaps [rsp+0xC0], xmm13
0000796da41de248  vmovaps [rsp+0xD0], xmm14
0000796da41de251  vmovaps [rsp+0xE0], xmm15
0000796da41de25a  sub rsp, 0x30
0000796da41de25e  movaps [rsp], xmm8
0000796da41de263  movaps [rsp+0x10], xmm15
0000796da41de269  movaps [rsp+0x20], xmm7
0000796da41de26e  lea rdi, [rsp]
0000796da41de272  mov esi, 0x00
0000796da41de277  mov rax, 0x5E26CB66A530
0000796da41de281  call rax
0000796da41de283  movaps xmm8, [rsp]
0000796da41de288  add rsp, 0x30
0000796da41de28c  vmovaps xmm0, [rsp]
0000796da41de291  vmovaps xmm1, [rsp+0x10]
0000796da41de297  vmovaps xmm2, [rsp+0x20]
0000796da41de29d  vmovaps xmm3, [rsp+0x30]
0000796da41de2a3  vmovaps xmm4, [rsp+0x40]
0000796da41de2a9  vmovaps xmm5, [rsp+0x50]
0000796da41de2af  vmovaps xmm6, [rsp+0x60]
0000796da41de2b5  vmovaps xmm7, [rsp+0x70]
0000796da41de2bb  vmovaps xmm9, [rsp+0x80]
0000796da41de2c4  vmovaps xmm10, [rsp+0x90]
0000796da41de2cd  vmovaps xmm11, [rsp+0xA0]
0000796da41de2d6  vmovaps xmm12, [rsp+0xB0]
0000796da41de2df  vmovaps xmm13, [rsp+0xC0]
0000796da41de2e8  vmovaps xmm14, [rsp+0xD0]
0000796da41de2f1  vmovaps xmm15, [rsp+0xE0]
0000796da41de2fa  add rsp, 0xF0
0000796da41de301  pop r11
0000796da41de303  pop r10
0000796da41de305  pop r9
0000796da41de307  pop r8
0000796da41de309  pop rsi
0000796da41de30a  pop rdi
0000796da41de30b  pop rdx
0000796da41de30c  pop rcx
0000796da41de30d  pop rax
0000796da41de30e  add rsp, 0x08
0000796da41de312  jmp 0x0000796DA41D97B4
0000796da41de317  sub rsp, 0x08
0000796da41de31b  push rax
0000796da41de31c  push rcx
0000796da41de31d  push rdx
0000796da41de31e  push rdi
0000796da41de31f  push rsi
0000796da41de320  push r8
0000796da41de322  push r9
0000796da41de324  push r10
0000796da41de326  push r11
0000796da41de328  sub rsp, 0xF0
0000796da41de32f  vmovaps [rsp], xmm0
0000796da41de334  vmovaps [rsp+0x10], xmm1
0000796da41de33a  vmovaps [rsp+0x20], xmm2
0000796da41de340  vmovaps [rsp+0x30], xmm3
0000796da41de346  vmovaps [rsp+0x40], xmm4
0000796da41de34c  vmovaps [rsp+0x50], xmm5
0000796da41de352  vmovaps [rsp+0x60], xmm6
0000796da41de358  vmovaps [rsp+0x70], xmm8
0000796da41de35e  vmovaps [rsp+0x80], xmm9
0000796da41de367  vmovaps [rsp+0x90], xmm10
0000796da41de370  vmovaps [rsp+0xA0], xmm11
0000796da41de379  vmovaps [rsp+0xB0], xmm12
0000796da41de382  vmovaps [rsp+0xC0], xmm13
0000796da41de38b  vmovaps [rsp+0xD0], xmm14
0000796da41de394  vmovaps [rsp+0xE0], xmm15
0000796da41de39d  sub rsp, 0x30
0000796da41de3a1  movaps [rsp], xmm7
0000796da41de3a5  movaps [rsp+0x10], xmm9
0000796da41de3ab  movaps [rsp+0x20], xmm15
0000796da41de3b1  lea rdi, [rsp]
0000796da41de3b5  mov esi, 0x00
0000796da41de3ba  mov rax, 0x5E26CB66A530
0000796da41de3c4  call rax
0000796da41de3c6  movaps xmm7, [rsp]
0000796da41de3ca  add rsp, 0x30
0000796da41de3ce  vmovaps xmm0, [rsp]
0000796da41de3d3  vmovaps xmm1, [rsp+0x10]
0000796da41de3d9  vmovaps xmm2, [rsp+0x20]
0000796da41de3df  vmovaps xmm3, [rsp+0x30]
0000796da41de3e5  vmovaps xmm4, [rsp+0x40]
0000796da41de3eb  vmovaps xmm5, [rsp+0x50]
0000796da41de3f1  vmovaps xmm6, [rsp+0x60]
0000796da41de3f7  vmovaps xmm8, [rsp+0x70]
0000796da41de3fd  vmovaps xmm9, [rsp+0x80]
0000796da41de406  vmovaps xmm10, [rsp+0x90]
0000796da41de40f  vmovaps xmm11, [rsp+0xA0]
0000796da41de418  vmovaps xmm12, [rsp+0xB0]
0000796da41de421  vmovaps xmm13, [rsp+0xC0]
0000796da41de42a  vmovaps xmm14, [rsp+0xD0]
0000796da41de433  vmovaps xmm15, [rsp+0xE0]
0000796da41de43c  add rsp, 0xF0
0000796da41de443  pop r11
0000796da41de445  pop r10
0000796da41de447  pop r9
0000796da41de449  pop r8
0000796da41de44b  pop rsi
0000796da41de44c  pop rdi
0000796da41de44d  pop rdx
0000796da41de44e  pop rcx
0000796da41de44f  pop rax
0000796da41de450  add rsp, 0x08
0000796da41de454  jmp 0x0000796DA41D97E1
0000796da41de459  sub rsp, 0x08
0000796da41de45d  push rax
0000796da41de45e  push rcx
0000796da41de45f  push rdx
0000796da41de460  push rdi
0000796da41de461  push rsi
0000796da41de462  push r8
0000796da41de464  push r9
0000796da41de466  push r10
0000796da41de468  push r11
0000796da41de46a  sub rsp, 0xF0
0000796da41de471  vmovaps [rsp], xmm0
0000796da41de476  vmovaps [rsp+0x10], xmm1
0000796da41de47c  vmovaps [rsp+0x20], xmm2
0000796da41de482  vmovaps [rsp+0x30], xmm3
0000796da41de488  vmovaps [rsp+0x40], xmm4
0000796da41de48e  vmovaps [rsp+0x50], xmm5
0000796da41de494  vmovaps [rsp+0x60], xmm6
0000796da41de49a  vmovaps [rsp+0x70], xmm7
0000796da41de4a0  vmovaps [rsp+0x80], xmm8
0000796da41de4a9  vmovaps [rsp+0x90], xmm10
0000796da41de4b2  vmovaps [rsp+0xA0], xmm11
0000796da41de4bb  vmovaps [rsp+0xB0], xmm12
0000796da41de4c4  vmovaps [rsp+0xC0], xmm13
0000796da41de4cd  vmovaps [rsp+0xD0], xmm14
0000796da41de4d6  vmovaps [rsp+0xE0], xmm15
0000796da41de4df  sub rsp, 0x30
0000796da41de4e3  movaps [rsp], xmm9
0000796da41de4e8  movaps [rsp+0x10], xmm13
0000796da41de4ee  movaps [rsp+0x20], xmm15
0000796da41de4f4  lea rdi, [rsp]
0000796da41de4f8  mov esi, 0x00
0000796da41de4fd  mov rax, 0x5E26CB66A530
0000796da41de507  call rax
0000796da41de509  movaps xmm9, [rsp]
0000796da41de50e  add rsp, 0x30
0000796da41de512  vmovaps xmm0, [rsp]
0000796da41de517  vmovaps xmm1, [rsp+0x10]
0000796da41de51d  vmovaps xmm2, [rsp+0x20]
0000796da41de523  vmovaps xmm3, [rsp+0x30]
0000796da41de529  vmovaps xmm4, [rsp+0x40]
0000796da41de52f  vmovaps xmm5, [rsp+0x50]
0000796da41de535  vmovaps xmm6, [rsp+0x60]
0000796da41de53b  vmovaps xmm7, [rsp+0x70]
0000796da41de541  vmovaps xmm8, [rsp+0x80]
0000796da41de54a  vmovaps xmm10, [rsp+0x90]
0000796da41de553  vmovaps xmm11, [rsp+0xA0]
0000796da41de55c  vmovaps xmm12, [rsp+0xB0]
0000796da41de565  vmovaps xmm13, [rsp+0xC0]
0000796da41de56e  vmovaps xmm14, [rsp+0xD0]
0000796da41de577  vmovaps xmm15, [rsp+0xE0]
0000796da41de580  add rsp, 0xF0
0000796da41de587  pop r11
0000796da41de589  pop r10
0000796da41de58b  pop r9
0000796da41de58d  pop r8
0000796da41de58f  pop rsi
0000796da41de590  pop rdi
0000796da41de591  pop rdx
0000796da41de592  pop rcx
0000796da41de593  pop rax
0000796da41de594  add rsp, 0x08
0000796da41de598  jmp 0x0000796DA41D980F
0000796da41de59d  sub rsp, 0x08
0000796da41de5a1  push rax
0000796da41de5a2  push rcx
0000796da41de5a3  push rdx
0000796da41de5a4  push rdi
0000796da41de5a5  push rsi
0000796da41de5a6  push r8
0000796da41de5a8  push r9
0000796da41de5aa  push r10
0000796da41de5ac  push r11
0000796da41de5ae  sub rsp, 0xF0
0000796da41de5b5  vmovaps [rsp], xmm0
0000796da41de5ba  vmovaps [rsp+0x10], xmm1
0000796da41de5c0  vmovaps [rsp+0x20], xmm2
0000796da41de5c6  vmovaps [rsp+0x30], xmm3
0000796da41de5cc  vmovaps [rsp+0x40], xmm4
0000796da41de5d2  vmovaps [rsp+0x50], xmm5
0000796da41de5d8  vmovaps [rsp+0x60], xmm6
0000796da41de5de  vmovaps [rsp+0x70], xmm7
0000796da41de5e4  vmovaps [rsp+0x80], xmm8
0000796da41de5ed  vmovaps [rsp+0x90], xmm9
0000796da41de5f6  vmovaps [rsp+0xA0], xmm10
0000796da41de5ff  vmovaps [rsp+0xB0], xmm11
0000796da41de608  vmovaps [rsp+0xC0], xmm12
0000796da41de611  vmovaps [rsp+0xD0], xmm13
0000796da41de61a  vmovaps [rsp+0xE0], xmm14
0000796da41de623  sub rsp, 0x30
0000796da41de627  movaps [rsp], xmm15
0000796da41de62c  movaps [rsp+0x10], xmm11
0000796da41de632  movaps [rsp+0x20], xmm12
0000796da41de638  lea rdi, [rsp]
0000796da41de63c  mov esi, 0x00
0000796da41de641  mov rax, 0x5E26CB66A530
0000796da41de64b  call rax
0000796da41de64d  movaps xmm15, [rsp]
0000796da41de652  add rsp, 0x30
0000796da41de656  vmovaps xmm0, [rsp]
0000796da41de65b  vmovaps xmm1, [rsp+0x10]
0000796da41de661  vmovaps xmm2, [rsp+0x20]
0000796da41de667  vmovaps xmm3, [rsp+0x30]
0000796da41de66d  vmovaps xmm4, [rsp+0x40]
0000796da41de673  vmovaps xmm5, [rsp+0x50]
0000796da41de679  vmovaps xmm6, [rsp+0x60]
0000796da41de67f  vmovaps xmm7, [rsp+0x70]
0000796da41de685  vmovaps xmm8, [rsp+0x80]
0000796da41de68e  vmovaps xmm9, [rsp+0x90]
0000796da41de697  vmovaps xmm10, [rsp+0xA0]
0000796da41de6a0  vmovaps xmm11, [rsp+0xB0]
0000796da41de6a9  vmovaps xmm12, [rsp+0xC0]
0000796da41de6b2  vmovaps xmm13, [rsp+0xD0]
0000796da41de6bb  vmovaps xmm14, [rsp+0xE0]
0000796da41de6c4  add rsp, 0xF0
0000796da41de6cb  pop r11
0000796da41de6cd  pop r10
0000796da41de6cf  pop r9
0000796da41de6d1  pop r8
0000796da41de6d3  pop rsi
0000796da41de6d4  pop rdi
0000796da41de6d5  pop rdx
0000796da41de6d6  pop rcx
0000796da41de6d7  pop rax
0000796da41de6d8  add rsp, 0x08
0000796da41de6dc  jmp 0x0000796DA41D982A
0000796da41de6e1  sub rsp, 0x08
0000796da41de6e5  push rax
0000796da41de6e6  push rcx
0000796da41de6e7  push rdx
0000796da41de6e8  push rdi
0000796da41de6e9  push rsi
0000796da41de6ea  push r8
0000796da41de6ec  push r9
0000796da41de6ee  push r10
0000796da41de6f0  push r11
0000796da41de6f2  sub rsp, 0xF0
0000796da41de6f9  vmovaps [rsp], xmm0
0000796da41de6fe  vmovaps [rsp+0x10], xmm1
0000796da41de704  vmovaps [rsp+0x20], xmm2
0000796da41de70a  vmovaps [rsp+0x30], xmm3
0000796da41de710  vmovaps [rsp+0x40], xmm4
0000796da41de716  vmovaps [rsp+0x50], xmm5
0000796da41de71c  vmovaps [rsp+0x60], xmm6
0000796da41de722  vmovaps [rsp+0x70], xmm7
0000796da41de728  vmovaps [rsp+0x80], xmm8
0000796da41de731  vmovaps [rsp+0x90], xmm9
0000796da41de73a  vmovaps [rsp+0xA0], xmm10
0000796da41de743  vmovaps [rsp+0xB0], xmm11
0000796da41de74c  vmovaps [rsp+0xC0], xmm12
0000796da41de755  vmovaps [rsp+0xD0], xmm14
0000796da41de75e  vmovaps [rsp+0xE0], xmm15
0000796da41de767  sub rsp, 0x30
0000796da41de76b  movaps [rsp], xmm13
0000796da41de770  movaps [rsp+0x10], xmm10
0000796da41de776  movaps [rsp+0x20], xmm14
0000796da41de77c  lea rdi, [rsp]
0000796da41de780  mov esi, 0x00
0000796da41de785  mov rax, 0x5E26CB66A530
0000796da41de78f  call rax
0000796da41de791  movaps xmm13, [rsp]
0000796da41de796  add rsp, 0x30
0000796da41de79a  vmovaps xmm0, [rsp]
0000796da41de79f  vmovaps xmm1, [rsp+0x10]
0000796da41de7a5  vmovaps xmm2, [rsp+0x20]
0000796da41de7ab  vmovaps xmm3, [rsp+0x30]
0000796da41de7b1  vmovaps xmm4, [rsp+0x40]
0000796da41de7b7  vmovaps xmm5, [rsp+0x50]
0000796da41de7bd  vmovaps xmm6, [rsp+0x60]
0000796da41de7c3  vmovaps xmm7, [rsp+0x70]
0000796da41de7c9  vmovaps xmm8, [rsp+0x80]
0000796da41de7d2  vmovaps xmm9, [rsp+0x90]
0000796da41de7db  vmovaps xmm10, [rsp+0xA0]
0000796da41de7e4  vmovaps xmm11, [rsp+0xB0]
0000796da41de7ed  vmovaps xmm12, [rsp+0xC0]
0000796da41de7f6  vmovaps xmm14, [rsp+0xD0]
0000796da41de7ff  vmovaps xmm15, [rsp+0xE0]
0000796da41de808  add rsp, 0xF0
0000796da41de80f  pop r11
0000796da41de811  pop r10
0000796da41de813  pop r9
0000796da41de815  pop r8
0000796da41de817  pop rsi
0000796da41de818  pop rdi
0000796da41de819  pop rdx
0000796da41de81a  pop rcx
0000796da41de81b  pop rax
0000796da41de81c  add rsp, 0x08
0000796da41de820  jmp 0x0000796DA41D984D
0000796da41de825  sub rsp, 0x08
0000796da41de829  push rax
0000796da41de82a  push rcx
0000796da41de82b  push rdx
0000796da41de82c  push rdi
0000796da41de82d  push rsi
0000796da41de82e  push r8
0000796da41de830  push r9
0000796da41de832  push r10
0000796da41de834  push r11
0000796da41de836  sub rsp, 0xF0
0000796da41de83d  vmovaps [rsp], xmm0
0000796da41de842  vmovaps [rsp+0x10], xmm1
0000796da41de848  vmovaps [rsp+0x20], xmm2
0000796da41de84e  vmovaps [rsp+0x30], xmm3
0000796da41de854  vmovaps [rsp+0x40], xmm4
0000796da41de85a  vmovaps [rsp+0x50], xmm5
0000796da41de860  vmovaps [rsp+0x60], xmm6
0000796da41de866  vmovaps [rsp+0x70], xmm7
0000796da41de86c  vmovaps [rsp+0x80], xmm8
0000796da41de875  vmovaps [rsp+0x90], xmm9
0000796da41de87e  vmovaps [rsp+0xA0], xmm10
0000796da41de887  vmovaps [rsp+0xB0], xmm11
0000796da41de890  vmovaps [rsp+0xC0], xmm12
0000796da41de899  vmovaps [rsp+0xD0], xmm13
0000796da41de8a2  vmovaps [rsp+0xE0], xmm15
0000796da41de8ab  sub rsp, 0x30
0000796da41de8af  movaps [rsp], xmm14
0000796da41de8b4  movaps [rsp+0x10], xmm1
0000796da41de8b9  movaps [rsp+0x20], xmm7
0000796da41de8be  lea rdi, [rsp]
0000796da41de8c2  mov esi, 0x00
0000796da41de8c7  mov rax, 0x5E26CB66A530
0000796da41de8d1  call rax
0000796da41de8d3  movaps xmm14, [rsp]
0000796da41de8d8  add rsp, 0x30
0000796da41de8dc  vmovaps xmm0, [rsp]
0000796da41de8e1  vmovaps xmm1, [rsp+0x10]
0000796da41de8e7  vmovaps xmm2, [rsp+0x20]
0000796da41de8ed  vmovaps xmm3, [rsp+0x30]
0000796da41de8f3  vmovaps xmm4, [rsp+0x40]
0000796da41de8f9  vmovaps xmm5, [rsp+0x50]
0000796da41de8ff  vmovaps xmm6, [rsp+0x60]
0000796da41de905  vmovaps xmm7, [rsp+0x70]
0000796da41de90b  vmovaps xmm8, [rsp+0x80]
0000796da41de914  vmovaps xmm9, [rsp+0x90]
0000796da41de91d  vmovaps xmm10, [rsp+0xA0]
0000796da41de926  vmovaps xmm11, [rsp+0xB0]
0000796da41de92f  vmovaps xmm12, [rsp+0xC0]
0000796da41de938  vmovaps xmm13, [rsp+0xD0]
0000796da41de941  vmovaps xmm15, [rsp+0xE0]
0000796da41de94a  add rsp, 0xF0
0000796da41de951  pop r11
0000796da41de953  pop r10
0000796da41de955  pop r9
0000796da41de957  pop r8
0000796da41de959  pop rsi
0000796da41de95a  pop rdi
0000796da41de95b  pop rdx
0000796da41de95c  pop rcx
0000796da41de95d  pop rax
0000796da41de95e  add rsp, 0x08
0000796da41de962  jmp 0x0000796DA41D9870
0000796da41de967  sub rsp, 0x08
0000796da41de96b  push rax
0000796da41de96c  push rcx
0000796da41de96d  push rdx
0000796da41de96e  push rdi
0000796da41de96f  push rsi
0000796da41de970  push r8
0000796da41de972  push r9
0000796da41de974  push r10
0000796da41de976  push r11
0000796da41de978  sub rsp, 0xF0
0000796da41de97f  vmovaps [rsp], xmm0
0000796da41de984  vmovaps [rsp+0x10], xmm2
0000796da41de98a  vmovaps [rsp+0x20], xmm3
0000796da41de990  vmovaps [rsp+0x30], xmm4
0000796da41de996  vmovaps [rsp+0x40], xmm5
0000796da41de99c  vmovaps [rsp+0x50], xmm6
0000796da41de9a2  vmovaps [rsp+0x60], xmm7
0000796da41de9a8  vmovaps [rsp+0x70], xmm8
0000796da41de9ae  vmovaps [rsp+0x80], xmm9
0000796da41de9b7  vmovaps [rsp+0x90], xmm10
0000796da41de9c0  vmovaps [rsp+0xA0], xmm11
0000796da41de9c9  vmovaps [rsp+0xB0], xmm12
0000796da41de9d2  vmovaps [rsp+0xC0], xmm13
0000796da41de9db  vmovaps [rsp+0xD0], xmm14
0000796da41de9e4  vmovaps [rsp+0xE0], xmm15
0000796da41de9ed  sub rsp, 0x30
0000796da41de9f1  movaps [rsp], xmm1
0000796da41de9f5  movaps [rsp+0x10], xmm8
0000796da41de9fb  movaps [rsp+0x20], xmm9
0000796da41dea01  lea rdi, [rsp]
0000796da41dea05  mov esi, 0x00
0000796da41dea0a  mov rax, 0x5E26CB66A530
0000796da41dea14  call rax
0000796da41dea16  movaps xmm1, [rsp]
0000796da41dea1a  add rsp, 0x30
0000796da41dea1e  vmovaps xmm0, [rsp]
0000796da41dea23  vmovaps xmm2, [rsp+0x10]
0000796da41dea29  vmovaps xmm3, [rsp+0x20]
0000796da41dea2f  vmovaps xmm4, [rsp+0x30]
0000796da41dea35  vmovaps xmm5, [rsp+0x40]
0000796da41dea3b  vmovaps xmm6, [rsp+0x50]
0000796da41dea41  vmovaps xmm7, [rsp+0x60]
0000796da41dea47  vmovaps xmm8, [rsp+0x70]
0000796da41dea4d  vmovaps xmm9, [rsp+0x80]
0000796da41dea56  vmovaps xmm10, [rsp+0x90]
0000796da41dea5f  vmovaps xmm11, [rsp+0xA0]
0000796da41dea68  vmovaps xmm12, [rsp+0xB0]
0000796da41dea71  vmovaps xmm13, [rsp+0xC0]
0000796da41dea7a  vmovaps xmm14, [rsp+0xD0]
0000796da41dea83  vmovaps xmm15, [rsp+0xE0]
0000796da41dea8c  add rsp, 0xF0
0000796da41dea93  pop r11
0000796da41dea95  pop r10
0000796da41dea97  pop r9
0000796da41dea99  pop r8
0000796da41dea9b  pop rsi
0000796da41dea9c  pop rdi
0000796da41dea9d  pop rdx
0000796da41dea9e  pop rcx
0000796da41dea9f  pop rax
0000796da41deaa0  add rsp, 0x08
0000796da41deaa4  jmp 0x0000796DA41D9892
0000796da41deaa9  call 0x0000796DA40B3E40
0000796da41deaae  jmp 0x0000796DA41D98A0
0000796da41deab3  call 0x0000796DA400C380
0000796da41deab8  jmp 0x0000796DA41D98AA
0000796da41deabd  call 0x0000796DA400D600
0000796da41deac2  jmp 0x0000796DA41D98B4
0000796da41deac7  call 0x0000796DA3FFF540
0000796da41deacc  jmp 0x0000796DA41D98BE
0000796da41dead1  int3
0000796da41dead2  nop [rax+rax*1], ax
0000796da41deadb  nop [rax+rax*1], eax
0000796da41deae0  mov eax, [r15+0x48]
0000796da41deae4  lea r14d, [eax+0x01]
0000796da41deae9  mov [rsp+0x10], r14d
0000796da41deaee  mov r14d, r14d
0000796da41deaf1  mov [r15+0x48], r14
0000796da41deaf5  xor eax, eax
0000796da41deaf7  mov r14d, [rsp+0x10]
0000796da41deafc  cmp r14d, 0x1F4
0000796da41deb03  cmc
0000796da41deb04  lahf
0000796da41deb05  seto al
0000796da41deb08  mov [r15+0x108], eax
0000796da41deb0f  mov eax, [r15+0x108]
0000796da41deb16  sahf
0000796da41deb17  jnz 0x0000796DA41DEB49
0000796da41deb19  cmp dword ptr [r15+0x318], 0x00
0000796da41deb21  jz 0x0000796DA41E4C90
0000796da41deb27  nop [rax+rax*1], ax
0000796da41deb30  nop [rax+rax*1], eax
0000796da41deb38  mov eax, 0x4106DC
0000796da41deb3d  mov [r15+0x100], rax
0000796da41deb44  jmp 0x0000796DA3FFE110
0000796da41deb49  cmp dword ptr [r15+0x318], 0x00
0000796da41deb51  jz 0x0000796DA41DEB80
0000796da41deb57  nop [rax+rax*1], ax
0000796da41deb60  nop [rax+rax*1], eax
0000796da41deb68  mov eax, 0x410500
0000796da41deb6d  mov [r15+0x100], rax
0000796da41deb74  jmp 0x0000796DA3FFE110
0000796da41deb79  int3
0000796da41deb7a  int3
0000796da41deb7b  nop [rax+rax*1], eax
0000796da41deb80  mov rax, [r15+0x40]
0000796da41deb84  movaps xmm1, [r15+0x1D0]
0000796da41deb8c  vmovaps [rsp+0x10], xmm1
0000796da41deb92  vmovaps xmm15, [rsp+0x10]
0000796da41deb98  por xmm1, xmm15
0000796da41deb9d  movaps xmm14, [r15+0x1A0]
0000796da41deba5  vmovaps [rsp+0x10], xmm14
0000796da41debab  vmovaps xmm13, [rsp+0x10]
0000796da41debb1  por xmm14, xmm13
0000796da41debb6  lea r14, [rax+0x30]
0000796da41debba  mov r12, [r13+r14*1]
0000796da41debbf  lea r14, [rax+0x38]
0000796da41debc3  mov r11, [r13+r14*1]
0000796da41debc8  movq xmm13, r12
0000796da41debcd  movq xmm12, r11
0000796da41debd2  movq xmm13, xmm13
0000796da41debd7  vmovaps [rsp+0x10], xmm13
0000796da41debdd  movq xmm13, xmm13
0000796da41debe2  movaps [r15+0x130], xmm13
0000796da41debea  movq xmm12, xmm12
0000796da41debef  vmovaps [rsp+0x20], xmm12
0000796da41debf5  movq xmm12, xmm12
0000796da41debfa  movaps [r15+0x280], xmm12
0000796da41dec02  movaps xmm13, [r15+0x270]
0000796da41dec0a  vmovaps [rsp+0x30], xmm13
0000796da41dec10  vmovaps xmm12, [rsp+0x30]
0000796da41dec16  por xmm13, xmm12
0000796da41dec1b  lea r14, [rax+0x20]
0000796da41dec1f  mov r12, [r13+r14*1]
0000796da41dec24  lea r14, [rax+0x28]
0000796da41dec28  mov r11, [r13+r14*1]
0000796da41dec2d  movq xmm12, r12
0000796da41dec32  movq xmm11, r11
0000796da41dec37  movq xmm12, xmm12
0000796da41dec3c  vmovaps [rsp+0x30], xmm12
0000796da41dec42  movq xmm12, xmm12
0000796da41dec47  movaps [r15+0x150], xmm12
0000796da41dec4f  movq xmm11, xmm11
0000796da41dec54  vmovaps [rsp+0x40], xmm11
0000796da41dec5a  movq xmm11, xmm11
0000796da41dec5f  movaps [r15+0x140], xmm11
0000796da41dec67  lea r14, [rax+0x10]
0000796da41dec6b  mov r12, [r13+r14*1]
0000796da41dec70  lea r14, [rax+0x18]
0000796da41dec74  mov r11, [r13+r14*1]
0000796da41dec79  movq xmm12, r12
0000796da41dec7e  movq xmm11, r11
0000796da41dec83  movq xmm12, xmm12
0000796da41dec88  vmovaps [rsp+0x50], xmm12
0000796da41dec8e  movq xmm12, xmm12
0000796da41dec93  movaps [r15+0x170], xmm12
0000796da41dec9b  movq xmm11, xmm11
0000796da41deca0  vmovaps [rsp+0x60], xmm11
0000796da41deca6  movq xmm11, xmm11
0000796da41decab  movaps [r15+0x160], xmm11
0000796da41decb3  mov r14, [r13+rax*1]
0000796da41decb8  vmovq xmm12, r14
0000796da41decbd  vpbroadcastq xmm12, xmm12
0000796da41decc2  lea r14, [rax+0x08]
0000796da41decc6  mov rax, [r13+r14*1]
0000796da41deccb  movq xmm11, rax
0000796da41decd0  movaps [r15+0x230], xmm11
0000796da41decd8  mov rax, [r15+0xF8]
0000796da41decdf  lea r14, [rax+0x50]
0000796da41dece3  movups xmm11, [r13+r14*1]
0000796da41dece9  lea r14, [rax+0x60]
0000796da41deced  movups xmm10, [r13+r14*1]
0000796da41decf3  lea r14, [rax+0x30]
0000796da41decf7  movups xmm9, [r13+r14*1]
0000796da41decfd  mov r14, [r15+0x50]
0000796da41ded01  mov [r15+0x60], r14
0000796da41ded05  mov qword ptr [r15+0x58], 0x40
0000796da41ded0d  movaps xmm8, xmm12
0000796da41ded11  mulpd xmm8, xmm15
0000796da41ded16  vcmppd xmm7, xmm8, xmm8, 0x03
0000796da41ded1c  ptest xmm7, xmm7
0000796da41ded21  jnz 0x0000796DA41DFB4A
0000796da41ded27  movq xmm15, qword ptr [r15+0x230]
0000796da41ded30  vmovaps [rsp+0x70], xmm15
0000796da41ded36  vpermilpd xmm15, xmm15, 0x00
0000796da41ded3c  movaps xmm7, xmm9
0000796da41ded40  mulpd xmm7, xmm15
0000796da41ded45  vcmppd xmm6, xmm7, xmm7, 0x03
0000796da41ded4a  ptest xmm6, xmm6
0000796da41ded4f  jnz 0x0000796DA41DFC8E
0000796da41ded55  vxorps xmm15, xmm15, xmm15
0000796da41ded5a  vpbroadcastq xmm15, xmm15
0000796da41ded5f  movaps xmm9, xmm12
0000796da41ded63  mulpd xmm9, xmm10
0000796da41ded68  vcmppd xmm6, xmm9, xmm9, 0x03
0000796da41ded6e  ptest xmm6, xmm6
0000796da41ded73  jnz 0x0000796DA41DFDD0
0000796da41ded79  movaps xmm10, xmm12
0000796da41ded7d  mulpd xmm10, xmm11
0000796da41ded82  vcmppd xmm6, xmm10, xmm10, 0x03
0000796da41ded88  ptest xmm6, xmm6
0000796da41ded8d  jnz 0x0000796DA41DFF14
0000796da41ded93  movaps xmm11, [r15+0x1F0]
0000796da41ded9b  movaps xmm6, xmm12
0000796da41ded9f  mulpd xmm6, xmm11
0000796da41deda4  vcmppd xmm5, xmm6, xmm6, 0x03
0000796da41deda9  ptest xmm5, xmm5
0000796da41dedae  jnz 0x0000796DA41E0058
0000796da41dedb4  movaps xmm12, [r15+0x2A0]
0000796da41dedbc  vmovaps [rsp+0x80], xmm12
0000796da41dedc5  vmovaps xmm11, [rsp+0x80]
0000796da41dedce  por xmm12, xmm11
0000796da41dedd3  movaps xmm11, [r15+0x250]
0000796da41deddb  vmovaps [rsp+0x80], xmm11
0000796da41dede4  vmovaps xmm5, [rsp+0x80]
0000796da41deded  por xmm11, xmm5
0000796da41dedf2  vmovaps xmm4, [rsp+0x70]
0000796da41dedf8  vpermilpd xmm4, xmm4, 0x00
0000796da41dedfe  movaps xmm3, xmm5
0000796da41dee01  mulpd xmm3, xmm4
0000796da41dee05  vcmppd xmm2, xmm3, xmm3, 0x03
0000796da41dee0a  ptest xmm2, xmm2
0000796da41dee0f  jnz 0x0000796DA41E019A
0000796da41dee15  mov [rsp+0x80], rax
0000796da41dee1d  xor eax, eax
0000796da41dee1f  mov r12d, 0x40
0000796da41dee25  mov r11d, 0x200
0000796da41dee2b  cmp r12, r11
0000796da41dee2e  cmc
0000796da41dee2f  lahf
0000796da41dee30  seto al
0000796da41dee33  mov [r15+0x108], eax
0000796da41dee3a  movaps xmm5, xmm8
0000796da41dee3e  addpd xmm5, xmm15
0000796da41dee43  vcmppd xmm4, xmm5, xmm5, 0x03
0000796da41dee48  ptest xmm4, xmm4
0000796da41dee4d  jnz 0x0000796DA41E02DA
0000796da41dee53  movaps xmm8, [r15+0x1B0]
0000796da41dee5b  movaps xmm4, xmm9
0000796da41dee5f  addpd xmm4, xmm8
0000796da41dee64  vcmppd xmm2, xmm4, xmm4, 0x03
0000796da41dee69  ptest xmm2, xmm2
0000796da41dee6e  jnz 0x0000796DA41E041C
0000796da41dee74  movaps xmm9, xmm10
0000796da41dee78  addpd xmm9, xmm8
0000796da41dee7d  vcmppd xmm2, xmm9, xmm9, 0x03
0000796da41dee83  ptest xmm2, xmm2
0000796da41dee88  jnz 0x0000796DA41E055E
0000796da41dee8e  movaps xmm10, [r15+0x2F0]
0000796da41dee96  vmovaps [rsp+0x90], xmm10
0000796da41dee9f  vmovaps xmm8, [rsp+0x90]
0000796da41deea8  por xmm10, xmm8
0000796da41deead  movaps xmm8, [r15+0x2E0]
0000796da41deeb5  vmovaps [rsp+0x90], xmm8
0000796da41deebe  vmovaps xmm2, [rsp+0x90]
0000796da41deec7  por xmm8, xmm2
0000796da41deecc  movaps xmm2, [r15+0x2D0]
0000796da41deed4  vmovaps [rsp+0x90], xmm2
0000796da41deedd  vmovaps [rsp+0xA0], xmm1
0000796da41deee6  vmovaps xmm1, [rsp+0x90]
0000796da41deeef  por xmm2, xmm1
0000796da41deef3  movaps xmm1, [r15+0x200]
0000796da41deefb  vmovaps [rsp+0x90], xmm1
0000796da41def04  vmovaps [rsp+0xB0], xmm15
0000796da41def0d  vmovaps xmm15, [rsp+0x90]
0000796da41def16  por xmm1, xmm15
0000796da41def1b  movaps xmm15, [r15+0x1C0]
0000796da41def23  vmovaps [rsp+0x90], xmm15
0000796da41def2c  vmovaps [rsp+0xC0], xmm1
0000796da41def35  vmovaps xmm1, [rsp+0x90]
0000796da41def3e  por xmm15, xmm1
0000796da41def43  movaps xmm1, [r15+0x190]
0000796da41def4b  vmovaps [rsp+0x90], xmm1
0000796da41def54  vmovaps [rsp+0xD0], xmm15
0000796da41def5d  vmovaps xmm15, [rsp+0x90]
0000796da41def66  por xmm1, xmm15
0000796da41def6b  movaps xmm15, [r15+0x300]
0000796da41def73  vmovaps [rsp+0x90], xmm15
0000796da41def7c  vmovaps [rsp+0xE0], xmm1
0000796da41def85  vmovaps xmm1, [rsp+0x90]
0000796da41def8e  por xmm15, xmm1
0000796da41def93  mov rax, [rsp+0x80]
0000796da41def9b  lea r12, [rax+0xA0]
0000796da41defa2  movups xmm1, [r13+r12*1]
0000796da41defa8  lea r12, [rax+0xB0]
0000796da41defaf  vmovaps [rsp+0x80], xmm1
0000796da41defb8  movups xmm1, [r13+r12*1]
0000796da41defbe  vmovaps [rsp+0x90], xmm1
0000796da41defc7  vmovaps [rsp+0xF0], xmm15
0000796da41defd0  vmovaps xmm15, [rsp+0xB0]
0000796da41defd9  vmovaps [rsp+0xB0], xmm14
0000796da41defe2  movaps xmm1, xmm6
0000796da41defe5  addpd xmm1, xmm15
0000796da41defea  vcmppd xmm14, xmm1, xmm1, 0x03
0000796da41defef  ptest xmm14, xmm14
0000796da41deff5  jnz 0x0000796DA41E06B6
0000796da41deffb  lea r12, [rax+0xF0]
0000796da41df002  movups xmm15, [r13+r12*1]
0000796da41df008  movaps xmm14, xmm4
0000796da41df00c  addpd xmm14, xmm3
0000796da41df011  vcmppd xmm6, xmm14, xmm14, 0x03
0000796da41df017  ptest xmm6, xmm6
0000796da41df01c  jnz 0x0000796DA41E0801
0000796da41df022  movaps xmm6, xmm9
0000796da41df026  addpd xmm6, xmm7
0000796da41df02a  vcmppd xmm4, xmm6, xmm6, 0x03
0000796da41df02f  ptest xmm4, xmm4
0000796da41df034  jnz 0x0000796DA41E0943
0000796da41df03a  vmovaps xmm9, [rsp+0x70]
0000796da41df040  vpermilpd xmm9, xmm9, 0x00
0000796da41df046  vmovaps xmm4, [rsp+0x90]
0000796da41df04f  movaps xmm7, xmm4
0000796da41df052  mulpd xmm7, xmm9
0000796da41df057  vcmppd xmm3, xmm7, xmm7, 0x03
0000796da41df05c  ptest xmm3, xmm3
0000796da41df061  jnz 0x0000796DA41E0A84
0000796da41df067  vmovaps xmm9, [rsp+0x50]
0000796da41df06d  vpermilpd xmm9, xmm9, 0x00
0000796da41df073  movaps xmm4, xmm15
0000796da41df077  mulpd xmm4, xmm9
0000796da41df07c  vcmppd xmm3, xmm4, xmm4, 0x03
0000796da41df081  ptest xmm3, xmm3
0000796da41df086  jnz 0x0000796DA41E0BC5
0000796da41df08c  lea r12, [rax+0xE0]
0000796da41df093  movups xmm15, [r13+r12*1]
0000796da41df099  vmovaps xmm9, [rsp+0x70]
0000796da41df09f  vpermilpd xmm9, xmm9, 0x00
0000796da41df0a5  vmovaps [rsp+0x70], xmm1
0000796da41df0ab  vmovaps xmm1, [rsp+0x80]
0000796da41df0b4  vmovaps [rsp+0x80], xmm15
0000796da41df0bd  movaps xmm3, xmm1
0000796da41df0c0  mulpd xmm3, xmm9
0000796da41df0c5  vcmppd xmm15, xmm3, xmm3, 0x03
0000796da41df0ca  ptest xmm15, xmm15
0000796da41df0d0  jnz 0x0000796DA41E0D11
0000796da41df0d6  vmovaps xmm1, [rsp+0xF0]
0000796da41df0df  vmovaps xmm15, [rsp+0xF0]
0000796da41df0e8  por xmm1, xmm15
0000796da41df0ed  movaps [r15+0x300], xmm1
0000796da41df0f5  vmovaps xmm15, [rsp+0xE0]
0000796da41df0fe  vmovaps xmm9, [rsp+0xE0]
0000796da41df107  por xmm15, xmm9
0000796da41df10c  movaps [r15+0x190], xmm15
0000796da41df114  vmovaps xmm9, [rsp+0x50]
0000796da41df11a  vpermilpd xmm9, xmm9, 0x00
0000796da41df120  vmovaps [rsp+0x90], xmm1
0000796da41df129  vmovaps [rsp+0xE0], xmm15
0000796da41df132  vmovaps xmm15, [rsp+0x80]
0000796da41df13b  vmovaps [rsp+0x80], xmm14
0000796da41df144  movaps xmm1, xmm15
0000796da41df148  mulpd xmm1, xmm9
0000796da41df14d  vcmppd xmm14, xmm1, xmm1, 0x03
0000796da41df152  ptest xmm14, xmm14
0000796da41df158  jnz 0x0000796DA41E0E52
0000796da41df15e  lea r12, [rax+0x90]
0000796da41df165  movups xmm15, [r13+r12*1]
0000796da41df16b  vmovaps xmm14, [rsp+0xD0]
0000796da41df174  vmovaps xmm9, [rsp+0xD0]
0000796da41df17d  por xmm14, xmm9
0000796da41df182  movaps [r15+0x1C0], xmm14
0000796da41df18a  vmovaps xmm9, [rsp+0xC0]
0000796da41df193  vmovaps [rsp+0xD0], xmm1
0000796da41df19c  vmovaps xmm1, [rsp+0xC0]
0000796da41df1a5  por xmm9, xmm1
0000796da41df1aa  movaps [r15+0x200], xmm9
0000796da41df1b2  vmovaps [rsp+0xC0], xmm2
0000796da41df1bb  vmovaps xmm1, [rsp+0xC0]
0000796da41df1c4  por xmm2, xmm1
0000796da41df1c8  movaps [r15+0x2D0], xmm2
0000796da41df1d0  vmovaps [rsp+0xC0], xmm8
0000796da41df1d9  vmovaps xmm1, [rsp+0xC0]
0000796da41df1e2  por xmm8, xmm1
0000796da41df1e7  movaps [r15+0x2E0], xmm8
0000796da41df1ef  vmovaps [rsp+0xC0], xmm15
0000796da41df1f8  movaps xmm1, xmm5
0000796da41df1fb  addpd xmm1, xmm7
0000796da41df1ff  vcmppd xmm15, xmm1, xmm1, 0x03
0000796da41df204  ptest xmm15, xmm15
0000796da41df20a  jnz 0x0000796DA41E0F9E
0000796da41df210  vmovaps xmm15, [rsp+0x50]
0000796da41df216  vpermilpd xmm15, xmm15, 0x00
0000796da41df21c  vmovaps xmm5, [rsp+0xC0]
0000796da41df225  vmovaps [rsp+0xC0], xmm1
0000796da41df22e  movaps xmm7, xmm5
0000796da41df231  mulpd xmm7, xmm15
0000796da41df236  vcmppd xmm1, xmm7, xmm7, 0x03
0000796da41df23b  ptest xmm1, xmm1
0000796da41df240  jnz 0x0000796DA41E10DE
0000796da41df246  lea r12, [rax+0x80]
0000796da41df24d  movups xmm1, [r13+r12*1]
0000796da41df253  vmovaps xmm5, [rsp+0x70]
0000796da41df259  vmovaps [rsp+0x70], xmm1
0000796da41df25f  movaps xmm15, xmm5
0000796da41df263  addpd xmm15, xmm3
0000796da41df268  vcmppd xmm1, xmm15, xmm15, 0x03
0000796da41df26e  ptest xmm1, xmm1
0000796da41df273  jnz 0x0000796DA41E1229
0000796da41df279  vmovaps xmm5, [rsp+0x80]
0000796da41df282  movaps xmm1, xmm5
0000796da41df285  addpd xmm1, xmm4
0000796da41df289  vcmppd xmm3, xmm1, xmm1, 0x03
0000796da41df28e  ptest xmm3, xmm3
0000796da41df293  jnz 0x0000796DA41E136B
0000796da41df299  vmovaps [rsp+0x80], xmm10
0000796da41df2a2  vmovaps xmm5, [rsp+0x80]
0000796da41df2ab  por xmm10, xmm5
0000796da41df2b0  movaps [r15+0x2F0], xmm10
0000796da41df2b8  vmovaps xmm5, [rsp+0x50]
0000796da41df2be  vpermilpd xmm5, xmm5, 0x00
0000796da41df2c4  vmovaps xmm3, [rsp+0x70]
0000796da41df2ca  vmovaps [rsp+0x50], xmm1
0000796da41df2d0  movaps xmm4, xmm3
0000796da41df2d3  mulpd xmm4, xmm5
0000796da41df2d7  vcmppd xmm1, xmm4, xmm4, 0x03
0000796da41df2dc  ptest xmm1, xmm1
0000796da41df2e1  jnz 0x0000796DA41E14AB
0000796da41df2e7  lea r12, [rax+0xD0]
0000796da41df2ee  movups xmm1, [r13+r12*1]
0000796da41df2f4  vmovaps xmm3, [rsp+0xD0]
0000796da41df2fd  vmovaps [rsp+0x70], xmm1
0000796da41df303  movaps xmm5, xmm6
0000796da41df306  addpd xmm5, xmm3
0000796da41df30a  vcmppd xmm1, xmm5, xmm5, 0x03
0000796da41df30f  ptest xmm1, xmm1
0000796da41df314  jnz 0x0000796DA41E15F5
0000796da41df31a  vmovaps xmm1, [rsp+0x60]
0000796da41df320  vpermilpd xmm1, xmm1, 0x00
0000796da41df326  movaps xmm6, xmm9
0000796da41df32a  mulpd xmm6, xmm1
0000796da41df32e  vcmppd xmm3, xmm6, xmm6, 0x03
0000796da41df333  ptest xmm3, xmm3
0000796da41df338  jnz 0x0000796DA41E1735
0000796da41df33e  movaps [r15+0x260], xmm6
0000796da41df346  vxorps xmm1, xmm1, xmm1
0000796da41df34a  vpbroadcastq xmm1, xmm1
0000796da41df34f  movaps [r15+0x1B0], xmm1
0000796da41df357  vmovaps xmm1, [rsp+0x60]
0000796da41df35d  vpermilpd xmm1, xmm1, 0x00
0000796da41df363  vmovaps xmm3, [rsp+0x70]
0000796da41df369  vmovaps [rsp+0x70], xmm15
0000796da41df36f  movaps xmm9, xmm3
0000796da41df373  mulpd xmm9, xmm1
0000796da41df378  vcmppd xmm15, xmm9, xmm9, 0x03
0000796da41df37e  ptest xmm15, xmm15
0000796da41df384  jnz 0x0000796DA41E1876
0000796da41df38a  lea r12, [rax+0xC0]
0000796da41df391  movups xmm1, [r13+r12*1]
0000796da41df397  vmovaps xmm3, [rsp+0xC0]
0000796da41df3a0  vmovaps [rsp+0x80], xmm1
0000796da41df3a9  movaps xmm15, xmm3
0000796da41df3ad  addpd xmm15, xmm7
0000796da41df3b2  vcmppd xmm1, xmm15, xmm15, 0x03
0000796da41df3b8  ptest xmm1, xmm1
0000796da41df3bd  jnz 0x0000796DA41E19C2
0000796da41df3c3  vmovaps [rsp+0xC0], xmm13
0000796da41df3cc  vmovaps xmm1, [rsp+0xC0]
0000796da41df3d5  por xmm13, xmm1
0000796da41df3da  movaps [r15+0x270], xmm13
0000796da41df3e2  vmovaps xmm1, [rsp+0xB0]
0000796da41df3eb  vmovaps xmm7, [rsp+0xB0]
0000796da41df3f4  por xmm1, xmm7
0000796da41df3f8  movaps [r15+0x1A0], xmm1
0000796da41df400  vmovaps xmm1, [rsp+0x60]
0000796da41df406  vpermilpd xmm1, xmm1, 0x00
0000796da41df40c  vmovaps [rsp+0xB0], xmm1
0000796da41df415  vmovaps xmm1, [rsp+0x80]
0000796da41df41e  vmovaps [rsp+0x80], xmm15
0000796da41df427  vmovaps xmm15, [rsp+0xB0]
0000796da41df430  vmovaps [rsp+0xB0], xmm14
0000796da41df439  movaps xmm3, xmm1
0000796da41df43c  mulpd xmm3, xmm15
0000796da41df441  vcmppd xmm14, xmm3, xmm3, 0x03
0000796da41df446  ptest xmm14, xmm14
0000796da41df44c  jnz 0x0000796DA41E1B04
0000796da41df452  lea r12, [rax+0x20]
0000796da41df456  movups xmm1, [r13+r12*1]
0000796da41df45c  movaps [r15+0x110], xmm1
0000796da41df464  vmovaps xmm14, [rsp+0x70]
0000796da41df46a  vmovaps [rsp+0x70], xmm1
0000796da41df470  movaps xmm15, xmm14
0000796da41df474  addpd xmm15, xmm4
0000796da41df479  vcmppd xmm1, xmm15, xmm15, 0x03
0000796da41df47f  ptest xmm1, xmm1
0000796da41df484  jnz 0x0000796DA41E1C4F
0000796da41df48a  vmovaps xmm1, [rsp+0x60]
0000796da41df490  vpermilpd xmm1, xmm1, 0x00
0000796da41df496  movaps xmm14, xmm2
0000796da41df49a  mulpd xmm14, xmm1
0000796da41df49f  vcmppd xmm4, xmm14, xmm14, 0x03
0000796da41df4a5  ptest xmm4, xmm4
0000796da41df4aa  jnz 0x0000796DA41E1D92
0000796da41df4b0  vmovaps xmm4, [rsp+0x50]
0000796da41df4b6  movaps xmm1, xmm4
0000796da41df4b9  addpd xmm1, xmm9
0000796da41df4be  vcmppd xmm2, xmm1, xmm1, 0x03
0000796da41df4c3  ptest xmm2, xmm2
0000796da41df4c8  jnz 0x0000796DA41E1ED4
0000796da41df4ce  vmovaps xmm9, [rsp+0x30]
0000796da41df4d4  vpermilpd xmm9, xmm9, 0x00
0000796da41df4da  vmovaps xmm2, [rsp+0x70]
0000796da41df4e0  vmovaps [rsp+0x50], xmm1
0000796da41df4e6  movaps xmm4, xmm2
0000796da41df4e9  mulpd xmm4, xmm9
0000796da41df4ee  vcmppd xmm1, xmm4, xmm4, 0x03
0000796da41df4f3  ptest xmm1, xmm1
0000796da41df4f8  jnz 0x0000796DA41E2015
0000796da41df4fe  vmovaps xmm1, [rsp+0x30]
0000796da41df504  vpermilpd xmm1, xmm1, 0x00
0000796da41df50a  vmovaps xmm2, [rsp+0x90]
0000796da41df513  vmovaps [rsp+0x60], xmm15
0000796da41df519  movaps xmm9, xmm2
0000796da41df51d  mulpd xmm9, xmm1
0000796da41df522  vcmppd xmm15, xmm9, xmm9, 0x03
0000796da41df528  ptest xmm15, xmm15
0000796da41df52e  jnz 0x0000796DA41E2156
0000796da41df534  vmovaps xmm15, [rsp+0x80]
0000796da41df53d  movaps xmm1, xmm15
0000796da41df541  addpd xmm1, xmm6
0000796da41df545  vcmppd xmm2, xmm1, xmm1, 0x03
0000796da41df54a  ptest xmm2, xmm2
0000796da41df54f  jnz 0x0000796DA41E2298
0000796da41df555  movaps xmm15, xmm5
0000796da41df559  addpd xmm15, xmm3
0000796da41df55e  vcmppd xmm6, xmm15, xmm15, 0x03
0000796da41df564  ptest xmm6, xmm6
0000796da41df569  jnz 0x0000796DA41E23D9
0000796da41df56f  vmovaps xmm6, [rsp+0x30]
0000796da41df575  vpermilpd xmm6, xmm6, 0x00
0000796da41df57b  movaps xmm5, xmm8
0000796da41df57f  mulpd xmm5, xmm6
0000796da41df583  vcmppd xmm3, xmm5, xmm5, 0x03
0000796da41df588  ptest xmm3, xmm3
0000796da41df58d  jnz 0x0000796DA41E251B
0000796da41df593  vmovaps xmm8, [rsp+0x30]
0000796da41df599  vpermilpd xmm8, xmm8, 0x00
0000796da41df59f  movaps xmm6, xmm10
0000796da41df5a3  mulpd xmm6, xmm8
0000796da41df5a8  vcmppd xmm3, xmm6, xmm6, 0x03
0000796da41df5ad  ptest xmm3, xmm3
0000796da41df5b2  jnz 0x0000796DA41E265C
0000796da41df5b8  vmovaps xmm8, [rsp+0x60]
0000796da41df5be  movaps xmm10, xmm8
0000796da41df5c2  addpd xmm10, xmm14
0000796da41df5c7  vcmppd xmm3, xmm10, xmm10, 0x03
0000796da41df5cd  ptest xmm3, xmm3
0000796da41df5d2  jnz 0x0000796DA41E279E
0000796da41df5d8  vmovaps xmm8, [rsp+0x50]
0000796da41df5de  movaps xmm14, xmm8
0000796da41df5e2  addpd xmm14, xmm4
0000796da41df5e7  vcmppd xmm3, xmm14, xmm14, 0x03
0000796da41df5ed  ptest xmm3, xmm3
0000796da41df5f2  jnz 0x0000796DA41E28E2
0000796da41df5f8  vmovaps xmm8, [rsp+0x40]
0000796da41df5fe  vpermilpd xmm8, xmm8, 0x00
0000796da41df604  movaps xmm4, xmm13
0000796da41df608  mulpd xmm4, xmm8
0000796da41df60d  vcmppd xmm3, xmm4, xmm4, 0x03
0000796da41df612  ptest xmm3, xmm3
0000796da41df617  jnz 0x0000796DA41E2A25
0000796da41df61d  movaps xmm13, xmm15
0000796da41df621  addpd xmm13, xmm9
0000796da41df626  vcmppd xmm8, xmm13, xmm13, 0x03
0000796da41df62c  ptest xmm8, xmm8
0000796da41df632  jnz 0x0000796DA41E2B67
0000796da41df638  movaps xmm15, xmm1
0000796da41df63c  addpd xmm15, xmm5
0000796da41df641  vcmppd xmm9, xmm15, xmm15, 0x03
0000796da41df647  ptest xmm9, xmm9
0000796da41df64d  jnz 0x0000796DA41E2CAB
0000796da41df653  vmovaps [rsp+0x30], xmm11
0000796da41df659  vmovaps xmm1, [rsp+0x30]
0000796da41df65f  por xmm11, xmm1
0000796da41df664  movaps [r15+0x250], xmm11
0000796da41df66c  vmovaps [rsp+0x30], xmm12
0000796da41df672  vmovaps xmm1, [rsp+0x30]
0000796da41df678  por xmm12, xmm1
0000796da41df67d  movaps [r15+0x2A0], xmm12
0000796da41df685  vmovaps xmm1, [rsp+0xA0]
0000796da41df68e  vmovaps xmm11, [rsp+0xA0]
0000796da41df697  por xmm1, xmm11
0000796da41df69c  movaps [r15+0x1D0], xmm1
0000796da41df6a4  lea r12, [rax+0x40]
0000796da41df6a8  movups xmm1, [r13+r12*1]
0000796da41df6ae  movaps [r15+0x2C0], xmm1
0000796da41df6b6  vmovaps xmm11, [rsp+0x40]
0000796da41df6bc  vpermilpd xmm11, xmm11, 0x00
0000796da41df6c2  vmovaps xmm8, [rsp+0xE0]
0000796da41df6cb  movaps xmm9, xmm8
0000796da41df6cf  mulpd xmm9, xmm11
0000796da41df6d4  vcmppd xmm5, xmm9, xmm9, 0x03
0000796da41df6da  ptest xmm5, xmm5
0000796da41df6df  jnz 0x0000796DA41E2DF7
0000796da41df6e5  movaps xmm11, xmm10
0000796da41df6e9  addpd xmm11, xmm6
0000796da41df6ee  vcmppd xmm8, xmm11, xmm11, 0x03
0000796da41df6f4  ptest xmm8, xmm8
0000796da41df6fa  jnz 0x0000796DA41E2F3B
0000796da41df700  movaps xmm10, xmm14
0000796da41df704  addpd xmm10, xmm4
0000796da41df709  vcmppd xmm8, xmm10, xmm10, 0x03
0000796da41df70f  ptest xmm8, xmm8
0000796da41df715  jnz 0x0000796DA41E307E
0000796da41df71b  vmovaps xmm14, [rsp+0x40]
0000796da41df721  vpermilpd xmm14, xmm14, 0x00
0000796da41df727  movaps xmm8, xmm1
0000796da41df72b  mulpd xmm8, xmm14
0000796da41df730  vcmppd xmm6, xmm8, xmm8, 0x03
0000796da41df736  ptest xmm6, xmm6
0000796da41df73b  jnz 0x0000796DA41E31C1
0000796da41df741  movaps xmm1, [r15+0x2B0]
0000796da41df749  vmovaps xmm14, [rsp+0x40]
0000796da41df74f  vpermilpd xmm14, xmm14, 0x00
0000796da41df755  movaps xmm6, xmm1
0000796da41df758  mulpd xmm6, xmm14
0000796da41df75d  vcmppd xmm5, xmm6, xmm6, 0x03
0000796da41df762  ptest xmm5, xmm5
0000796da41df767  jnz 0x0000796DA41E3304
0000796da41df76d  vmovaps xmm1, [rsp+0x10]
0000796da41df773  vpermilpd xmm1, xmm1, 0x00
0000796da41df779  movaps xmm14, xmm12
0000796da41df77d  mulpd xmm14, xmm1
0000796da41df782  vcmppd xmm5, xmm14, xmm14, 0x03
0000796da41df788  ptest xmm5, xmm5
0000796da41df78d  jnz 0x0000796DA41E3445
0000796da41df793  movaps xmm1, xmm13
0000796da41df797  addpd xmm1, xmm9
0000796da41df79c  vcmppd xmm12, xmm1, xmm1, 0x03
0000796da41df7a1  ptest xmm12, xmm12
0000796da41df7a7  jnz 0x0000796DA41E3588
0000796da41df7ad  vmovaps xmm13, [rsp+0x10]
0000796da41df7b3  vpermilpd xmm13, xmm13, 0x00
0000796da41df7b9  movaps xmm12, xmm7
0000796da41df7bd  mulpd xmm12, xmm13
0000796da41df7c2  vcmppd xmm9, xmm12, xmm12, 0x03
0000796da41df7c8  ptest xmm9, xmm9
0000796da41df7ce  jnz 0x0000796DA41E36CA
0000796da41df7d4  movaps xmm13, xmm15
0000796da41df7d8  addpd xmm13, xmm8
0000796da41df7dd  vcmppd xmm9, xmm13, xmm13, 0x03
0000796da41df7e3  ptest xmm9, xmm9
0000796da41df7e9  jnz 0x0000796DA41E380D
0000796da41df7ef  movaps xmm15, [r15+0x290]
0000796da41df7f7  vmovaps xmm9, [rsp+0x10]
0000796da41df7fd  vpermilpd xmm9, xmm9, 0x00
0000796da41df803  movaps xmm8, xmm15
0000796da41df807  mulpd xmm8, xmm9
0000796da41df80c  vcmppd xmm7, xmm8, xmm8, 0x03
0000796da41df812  ptest xmm7, xmm7
0000796da41df817  jnz 0x0000796DA41E3951
0000796da41df81d  movaps xmm15, xmm11
0000796da41df821  addpd xmm15, xmm6
0000796da41df826  vcmppd xmm9, xmm15, xmm15, 0x03
0000796da41df82c  ptest xmm9, xmm9
0000796da41df832  jnz 0x0000796DA41E3A95
0000796da41df838  movaps xmm11, [r15+0x1E0]
0000796da41df840  vmovaps xmm9, [rsp+0x10]
0000796da41df846  vpermilpd xmm9, xmm9, 0x00
0000796da41df84c  movaps xmm7, xmm11
0000796da41df850  mulpd xmm7, xmm9
0000796da41df855  vcmppd xmm6, xmm7, xmm7, 0x03
0000796da41df85a  ptest xmm6, xmm6
0000796da41df85f  jnz 0x0000796DA41E3BD8
0000796da41df865  movaps xmm11, xmm10
0000796da41df869  addpd xmm11, xmm14
0000796da41df86e  vcmppd xmm9, xmm11, xmm11, 0x03
0000796da41df874  ptest xmm9, xmm9
0000796da41df87a  jnz 0x0000796DA41E3D1A
0000796da41df880  lea r12, [rax+0x70]
0000796da41df884  movups xmm14, [r13+r12*1]
0000796da41df88a  movaps [r15+0x240], xmm14
0000796da41df892  movaps xmm10, xmm1
0000796da41df896  addpd xmm10, xmm12
0000796da41df89b  vcmppd xmm9, xmm10, xmm10, 0x03
0000796da41df8a1  ptest xmm9, xmm9
0000796da41df8a7  jnz 0x0000796DA41E3E68
0000796da41df8ad  movaps [r15+0x170], xmm10
0000796da41df8b5  vmovaps xmm1, [rsp+0x20]
0000796da41df8bb  vpermilpd xmm1, xmm1, 0x00
0000796da41df8c1  movaps xmm12, xmm14
0000796da41df8c5  mulpd xmm12, xmm1
0000796da41df8ca  vcmppd xmm9, xmm12, xmm12, 0x03
0000796da41df8d0  ptest xmm9, xmm9
0000796da41df8d6  jnz 0x0000796DA41E3FAB
0000796da41df8dc  vmovaps xmm1, [rsp+0x20]
0000796da41df8e2  vpermilpd xmm1, xmm1, 0x00
0000796da41df8e8  vmovaps xmm9, [rsp+0xB0]
0000796da41df8f1  movaps xmm14, xmm9
0000796da41df8f5  mulpd xmm14, xmm1
0000796da41df8fa  vcmppd xmm6, xmm14, xmm14, 0x03
0000796da41df900  ptest xmm6, xmm6
0000796da41df905  jnz 0x0000796DA41E40EE
0000796da41df90b  movaps [r15+0x180], xmm14
0000796da41df913  movaps xmm1, xmm13
0000796da41df917  addpd xmm1, xmm8
0000796da41df91c  vcmppd xmm9, xmm1, xmm1, 0x03
0000796da41df921  ptest xmm9, xmm9
0000796da41df927  jnz 0x0000796DA41E4231
0000796da41df92d  movaps [r15+0x210], xmm1
0000796da41df935  movups xmm13, [r13+rax*1]
0000796da41df93b  lea r12, [rax+0x10]
0000796da41df93f  movups xmm9, [r13+r12*1]
0000796da41df945  movaps [r15+0x230], xmm9
0000796da41df94d  movaps xmm8, xmm15
0000796da41df951  addpd xmm8, xmm7
0000796da41df956  vcmppd xmm6, xmm8, xmm8, 0x03
0000796da41df95c  ptest xmm6, xmm6
0000796da41df961  jnz 0x0000796DA41E4387
0000796da41df967  movaps [r15+0x130], xmm8
0000796da41df96f  vmovaps xmm15, [rsp+0x20]
0000796da41df975  vpermilpd xmm15, xmm15, 0x00
0000796da41df97b  movaps xmm7, xmm9
0000796da41df97f  mulpd xmm7, xmm15
0000796da41df984  vcmppd xmm6, xmm7, xmm7, 0x03
0000796da41df989  ptest xmm6, xmm6
0000796da41df98e  jnz 0x0000796DA41E44CA
0000796da41df994  movaps [r15+0x220], xmm7
0000796da41df99c  vmovaps xmm15, [rsp+0x20]
0000796da41df9a2  vpermilpd xmm15, xmm15, 0x00
0000796da41df9a8  movaps xmm9, xmm13
0000796da41df9ac  mulpd xmm9, xmm15
0000796da41df9b1  vcmppd xmm6, xmm9, xmm9, 0x03
0000796da41df9b7  ptest xmm6, xmm6
0000796da41df9bc  jnz 0x0000796DA41E460C
0000796da41df9c2  movaps xmm15, xmm11
0000796da41df9c6  addpd xmm15, xmm12
0000796da41df9cb  vcmppd xmm13, xmm15, xmm15, 0x03
0000796da41df9d1  ptest xmm13, xmm13
0000796da41df9d7  jnz 0x0000796DA41E4750
0000796da41df9dd  movaps [r15+0x140], xmm15
0000796da41df9e5  movaps xmm13, xmm10
0000796da41df9e9  addpd xmm13, xmm14
0000796da41df9ee  vcmppd xmm12, xmm13, xmm13, 0x03
0000796da41df9f4  ptest xmm12, xmm12
0000796da41df9fa  jnz 0x0000796DA41E4894
0000796da41dfa00  movaps [r15+0x150], xmm13
0000796da41dfa08  movaps xmm14, xmm1
0000796da41dfa0c  addpd xmm14, xmm7
0000796da41dfa11  vcmppd xmm12, xmm14, xmm14, 0x03
0000796da41dfa17  ptest xmm12, xmm12
0000796da41dfa1d  jnz 0x0000796DA41E49D8
0000796da41dfa23  movaps [r15+0x160], xmm14
0000796da41dfa2b  movaps xmm1, xmm8
0000796da41dfa2f  addpd xmm1, xmm9
0000796da41dfa34  vcmppd xmm12, xmm1, xmm1, 0x03
0000796da41dfa39  ptest xmm12, xmm12
0000796da41dfa3f  jnz 0x0000796DA41E4B1A
0000796da41dfa45  movaps [r15+0x120], xmm1
0000796da41dfa4d  movups [r13+r14*1], xmm15
0000796da41dfa53  lea rax, [r14+0x10]
0000796da41dfa57  movups [r13+rax*1], xmm13
0000796da41dfa5d  lea rax, [r14+0x20]
0000796da41dfa61  movups [r13+rax*1], xmm14
0000796da41dfa67  lea rax, [r14+0x30]
0000796da41dfa6b  movups [r13+rax*1], xmm1
0000796da41dfa71  mov eax, [r15+0x108]
0000796da41dfa78  sahf
0000796da41dfa79  jnz 0x0000796DA41DFAAB
0000796da41dfa7b  cmp dword ptr [r15+0x318], 0x00
0000796da41dfa83  jz 0x0000796DA41DEAE0
0000796da41dfa89  nop [rax+rax*1], ax
0000796da41dfa92  nop [rax+rax*1], eax
0000796da41dfa9a  mov eax, 0x4106D0
0000796da41dfa9f  mov [r15+0x100], rax
0000796da41dfaa6  jmp 0x0000796DA3FFE110
0000796da41dfaab  cmp dword ptr [r15+0x318], 0x00
0000796da41dfab3  jz 0x0000796DA41D89C0
0000796da41dfab9  nop [rax+rax*1], ax
0000796da41dfac2  nop [rax+rax*1], eax
0000796da41dfaca  mov eax, 0x410504
0000796da41dfacf  mov [r15+0x100], rax
0000796da41dfad6  jmp 0x0000796DA3FFE110
0000796da41dfadb  int3
0000796da41dfadc  call 0x0000796DA40E27E0
0000796da41dfae1  jmp 0x0000796DA41DEBBF
0000796da41dfae6  call 0x0000796DA40E1570
0000796da41dfaeb  jmp 0x0000796DA41DEBC8
0000796da41dfaf0  call 0x0000796DA40E27E0
0000796da41dfaf5  jmp 0x0000796DA41DEC24
0000796da41dfafa  call 0x0000796DA40E1570
0000796da41dfaff  jmp 0x0000796DA41DEC2D
0000796da41dfb04  call 0x0000796DA40E27E0
0000796da41dfb09  jmp 0x0000796DA41DEC70
0000796da41dfb0e  call 0x0000796DA40E1570
0000796da41dfb13  jmp 0x0000796DA41DEC79
0000796da41dfb18  call 0x0000796DA400DC20
0000796da41dfb1d  jmp 0x0000796DA41DECB8
0000796da41dfb22  call 0x0000796DA40D59C0
0000796da41dfb27  jmp 0x0000796DA41DECCB
0000796da41dfb2c  call 0x0000796DA40E0E30
0000796da41dfb31  jmp 0x0000796DA41DECE9
0000796da41dfb36  call 0x0000796DA40DFBC0
0000796da41dfb3b  jmp 0x0000796DA41DECF3
0000796da41dfb40  call 0x0000796DA40DE950
0000796da41dfb45  jmp 0x0000796DA41DECFD
0000796da41dfb4a  sub rsp, 0x08
0000796da41dfb4e  push rax
0000796da41dfb4f  push rcx
0000796da41dfb50  push rdx
0000796da41dfb51  push rdi
0000796da41dfb52  push rsi
0000796da41dfb53  push r8
0000796da41dfb55  push r9
0000796da41dfb57  push r10
0000796da41dfb59  push r11
0000796da41dfb5b  sub rsp, 0xF0
0000796da41dfb62  vmovaps [rsp], xmm0
0000796da41dfb67  vmovaps [rsp+0x10], xmm1
0000796da41dfb6d  vmovaps [rsp+0x20], xmm2
0000796da41dfb73  vmovaps [rsp+0x30], xmm3
0000796da41dfb79  vmovaps [rsp+0x40], xmm4
0000796da41dfb7f  vmovaps [rsp+0x50], xmm5
0000796da41dfb85  vmovaps [rsp+0x60], xmm6
0000796da41dfb8b  vmovaps [rsp+0x70], xmm7
0000796da41dfb91  vmovaps [rsp+0x80], xmm9
0000796da41dfb9a  vmovaps [rsp+0x90], xmm10
0000796da41dfba3  vmovaps [rsp+0xA0], xmm11
0000796da41dfbac  vmovaps [rsp+0xB0], xmm12
0000796da41dfbb5  vmovaps [rsp+0xC0], xmm13
0000796da41dfbbe  vmovaps [rsp+0xD0], xmm14
0000796da41dfbc7  vmovaps [rsp+0xE0], xmm15
0000796da41dfbd0  sub rsp, 0x30
0000796da41dfbd4  movaps [rsp], xmm8
0000796da41dfbd9  movaps [rsp+0x10], xmm12
0000796da41dfbdf  movaps [rsp+0x20], xmm15
0000796da41dfbe5  lea rdi, [rsp]
0000796da41dfbe9  mov esi, 0x00
0000796da41dfbee  mov rax, 0x5E26CB66A530
0000796da41dfbf8  call rax
0000796da41dfbfa  movaps xmm8, [rsp]
0000796da41dfbff  add rsp, 0x30
0000796da41dfc03  vmovaps xmm0, [rsp]
0000796da41dfc08  vmovaps xmm1, [rsp+0x10]
0000796da41dfc0e  vmovaps xmm2, [rsp+0x20]
0000796da41dfc14  vmovaps xmm3, [rsp+0x30]
0000796da41dfc1a  vmovaps xmm4, [rsp+0x40]
0000796da41dfc20  vmovaps xmm5, [rsp+0x50]
0000796da41dfc26  vmovaps xmm6, [rsp+0x60]
0000796da41dfc2c  vmovaps xmm7, [rsp+0x70]
0000796da41dfc32  vmovaps xmm9, [rsp+0x80]
0000796da41dfc3b  vmovaps xmm10, [rsp+0x90]
0000796da41dfc44  vmovaps xmm11, [rsp+0xA0]
0000796da41dfc4d  vmovaps xmm12, [rsp+0xB0]
0000796da41dfc56  vmovaps xmm13, [rsp+0xC0]
0000796da41dfc5f  vmovaps xmm14, [rsp+0xD0]
0000796da41dfc68  vmovaps xmm15, [rsp+0xE0]
0000796da41dfc71  add rsp, 0xF0
0000796da41dfc78  pop r11
0000796da41dfc7a  pop r10
0000796da41dfc7c  pop r9
0000796da41dfc7e  pop r8
0000796da41dfc80  pop rsi
0000796da41dfc81  pop rdi
0000796da41dfc82  pop rdx
0000796da41dfc83  pop rcx
0000796da41dfc84  pop rax
0000796da41dfc85  add rsp, 0x08
0000796da41dfc89  jmp 0x0000796DA41DED27
0000796da41dfc8e  sub rsp, 0x08
0000796da41dfc92  push rax
0000796da41dfc93  push rcx
0000796da41dfc94  push rdx
0000796da41dfc95  push rdi
0000796da41dfc96  push rsi
0000796da41dfc97  push r8
0000796da41dfc99  push r9
0000796da41dfc9b  push r10
0000796da41dfc9d  push r11
0000796da41dfc9f  sub rsp, 0xF0
0000796da41dfca6  vmovaps [rsp], xmm0
0000796da41dfcab  vmovaps [rsp+0x10], xmm1
0000796da41dfcb1  vmovaps [rsp+0x20], xmm2
0000796da41dfcb7  vmovaps [rsp+0x30], xmm3
0000796da41dfcbd  vmovaps [rsp+0x40], xmm4
0000796da41dfcc3  vmovaps [rsp+0x50], xmm5
0000796da41dfcc9  vmovaps [rsp+0x60], xmm6
0000796da41dfccf  vmovaps [rsp+0x70], xmm8
0000796da41dfcd5  vmovaps [rsp+0x80], xmm9
0000796da41dfcde  vmovaps [rsp+0x90], xmm10
0000796da41dfce7  vmovaps [rsp+0xA0], xmm11
0000796da41dfcf0  vmovaps [rsp+0xB0], xmm12
0000796da41dfcf9  vmovaps [rsp+0xC0], xmm13
0000796da41dfd02  vmovaps [rsp+0xD0], xmm14
0000796da41dfd0b  vmovaps [rsp+0xE0], xmm15
0000796da41dfd14  sub rsp, 0x30
0000796da41dfd18  movaps [rsp], xmm7
0000796da41dfd1c  movaps [rsp+0x10], xmm9
0000796da41dfd22  movaps [rsp+0x20], xmm15
0000796da41dfd28  lea rdi, [rsp]
0000796da41dfd2c  mov esi, 0x00
0000796da41dfd31  mov rax, 0x5E26CB66A530
0000796da41dfd3b  call rax
0000796da41dfd3d  movaps xmm7, [rsp]
0000796da41dfd41  add rsp, 0x30
0000796da41dfd45  vmovaps xmm0, [rsp]
0000796da41dfd4a  vmovaps xmm1, [rsp+0x10]
0000796da41dfd50  vmovaps xmm2, [rsp+0x20]
0000796da41dfd56  vmovaps xmm3, [rsp+0x30]
0000796da41dfd5c  vmovaps xmm4, [rsp+0x40]
0000796da41dfd62  vmovaps xmm5, [rsp+0x50]
0000796da41dfd68  vmovaps xmm6, [rsp+0x60]
0000796da41dfd6e  vmovaps xmm8, [rsp+0x70]
0000796da41dfd74  vmovaps xmm9, [rsp+0x80]
0000796da41dfd7d  vmovaps xmm10, [rsp+0x90]
0000796da41dfd86  vmovaps xmm11, [rsp+0xA0]
0000796da41dfd8f  vmovaps xmm12, [rsp+0xB0]
0000796da41dfd98  vmovaps xmm13, [rsp+0xC0]
0000796da41dfda1  vmovaps xmm14, [rsp+0xD0]
0000796da41dfdaa  vmovaps xmm15, [rsp+0xE0]
0000796da41dfdb3  add rsp, 0xF0
0000796da41dfdba  pop r11
0000796da41dfdbc  pop r10
0000796da41dfdbe  pop r9
0000796da41dfdc0  pop r8
0000796da41dfdc2  pop rsi
0000796da41dfdc3  pop rdi
0000796da41dfdc4  pop rdx
0000796da41dfdc5  pop rcx
0000796da41dfdc6  pop rax
0000796da41dfdc7  add rsp, 0x08
0000796da41dfdcb  jmp 0x0000796DA41DED55
0000796da41dfdd0  sub rsp, 0x08
0000796da41dfdd4  push rax
0000796da41dfdd5  push rcx
0000796da41dfdd6  push rdx
0000796da41dfdd7  push rdi
0000796da41dfdd8  push rsi
0000796da41dfdd9  push r8
0000796da41dfddb  push r9
0000796da41dfddd  push r10
0000796da41dfddf  push r11
0000796da41dfde1  sub rsp, 0xF0
0000796da41dfde8  vmovaps [rsp], xmm0
0000796da41dfded  vmovaps [rsp+0x10], xmm1
0000796da41dfdf3  vmovaps [rsp+0x20], xmm2
0000796da41dfdf9  vmovaps [rsp+0x30], xmm3
0000796da41dfdff  vmovaps [rsp+0x40], xmm4
0000796da41dfe05  vmovaps [rsp+0x50], xmm5
0000796da41dfe0b  vmovaps [rsp+0x60], xmm6
0000796da41dfe11  vmovaps [rsp+0x70], xmm7
0000796da41dfe17  vmovaps [rsp+0x80], xmm8
0000796da41dfe20  vmovaps [rsp+0x90], xmm10
0000796da41dfe29  vmovaps [rsp+0xA0], xmm11
0000796da41dfe32  vmovaps [rsp+0xB0], xmm12
0000796da41dfe3b  vmovaps [rsp+0xC0], xmm13
0000796da41dfe44  vmovaps [rsp+0xD0], xmm14
0000796da41dfe4d  vmovaps [rsp+0xE0], xmm15
0000796da41dfe56  sub rsp, 0x30
0000796da41dfe5a  movaps [rsp], xmm9
0000796da41dfe5f  movaps [rsp+0x10], xmm12
0000796da41dfe65  movaps [rsp+0x20], xmm10
0000796da41dfe6b  lea rdi, [rsp]
0000796da41dfe6f  mov esi, 0x00
0000796da41dfe74  mov rax, 0x5E26CB66A530
0000796da41dfe7e  call rax
0000796da41dfe80  movaps xmm9, [rsp]
0000796da41dfe85  add rsp, 0x30
0000796da41dfe89  vmovaps xmm0, [rsp]
0000796da41dfe8e  vmovaps xmm1, [rsp+0x10]
0000796da41dfe94  vmovaps xmm2, [rsp+0x20]
0000796da41dfe9a  vmovaps xmm3, [rsp+0x30]
0000796da41dfea0  vmovaps xmm4, [rsp+0x40]
0000796da41dfea6  vmovaps xmm5, [rsp+0x50]
0000796da41dfeac  vmovaps xmm6, [rsp+0x60]
0000796da41dfeb2  vmovaps xmm7, [rsp+0x70]
0000796da41dfeb8  vmovaps xmm8, [rsp+0x80]
0000796da41dfec1  vmovaps xmm10, [rsp+0x90]
0000796da41dfeca  vmovaps xmm11, [rsp+0xA0]
0000796da41dfed3  vmovaps xmm12, [rsp+0xB0]
0000796da41dfedc  vmovaps xmm13, [rsp+0xC0]
0000796da41dfee5  vmovaps xmm14, [rsp+0xD0]
0000796da41dfeee  vmovaps xmm15, [rsp+0xE0]
0000796da41dfef7  add rsp, 0xF0
0000796da41dfefe  pop r11
0000796da41dff00  pop r10
0000796da41dff02  pop r9
0000796da41dff04  pop r8
0000796da41dff06  pop rsi
0000796da41dff07  pop rdi
0000796da41dff08  pop rdx
0000796da41dff09  pop rcx
0000796da41dff0a  pop rax
0000796da41dff0b  add rsp, 0x08
0000796da41dff0f  jmp 0x0000796DA41DED79
0000796da41dff14  sub rsp, 0x08
0000796da41dff18  push rax
0000796da41dff19  push rcx
0000796da41dff1a  push rdx
0000796da41dff1b  push rdi
0000796da41dff1c  push rsi
0000796da41dff1d  push r8
0000796da41dff1f  push r9
0000796da41dff21  push r10
0000796da41dff23  push r11
0000796da41dff25  sub rsp, 0xF0
0000796da41dff2c  vmovaps [rsp], xmm0
0000796da41dff31  vmovaps [rsp+0x10], xmm1
0000796da41dff37  vmovaps [rsp+0x20], xmm2
0000796da41dff3d  vmovaps [rsp+0x30], xmm3
0000796da41dff43  vmovaps [rsp+0x40], xmm4
0000796da41dff49  vmovaps [rsp+0x50], xmm5
0000796da41dff4f  vmovaps [rsp+0x60], xmm6
0000796da41dff55  vmovaps [rsp+0x70], xmm7
0000796da41dff5b  vmovaps [rsp+0x80], xmm8
0000796da41dff64  vmovaps [rsp+0x90], xmm9
0000796da41dff6d  vmovaps [rsp+0xA0], xmm11
0000796da41dff76  vmovaps [rsp+0xB0], xmm12
0000796da41dff7f  vmovaps [rsp+0xC0], xmm13
0000796da41dff88  vmovaps [rsp+0xD0], xmm14
0000796da41dff91  vmovaps [rsp+0xE0], xmm15
0000796da41dff9a  sub rsp, 0x30
0000796da41dff9e  movaps [rsp], xmm10
0000796da41dffa3  movaps [rsp+0x10], xmm12
0000796da41dffa9  movaps [rsp+0x20], xmm11
0000796da41dffaf  lea rdi, [rsp]
0000796da41dffb3  mov esi, 0x00
0000796da41dffb8  mov rax, 0x5E26CB66A530
0000796da41dffc2  call rax
0000796da41dffc4  movaps xmm10, [rsp]
0000796da41dffc9  add rsp, 0x30
0000796da41dffcd  vmovaps xmm0, [rsp]
0000796da41dffd2  vmovaps xmm1, [rsp+0x10]
0000796da41dffd8  vmovaps xmm2, [rsp+0x20]
0000796da41dffde  vmovaps xmm3, [rsp+0x30]
0000796da41dffe4  vmovaps xmm4, [rsp+0x40]
0000796da41dffea  vmovaps xmm5, [rsp+0x50]
0000796da41dfff0  vmovaps xmm6, [rsp+0x60]
0000796da41dfff6  vmovaps xmm7, [rsp+0x70]
0000796da41dfffc  vmovaps xmm8, [rsp+0x80]
0000796da41e0005  vmovaps xmm9, [rsp+0x90]
0000796da41e000e  vmovaps xmm11, [rsp+0xA0]
0000796da41e0017  vmovaps xmm12, [rsp+0xB0]
0000796da41e0020  vmovaps xmm13, [rsp+0xC0]
0000796da41e0029  vmovaps xmm14, [rsp+0xD0]
0000796da41e0032  vmovaps xmm15, [rsp+0xE0]
0000796da41e003b  add rsp, 0xF0
0000796da41e0042  pop r11
0000796da41e0044  pop r10
0000796da41e0046  pop r9
0000796da41e0048  pop r8
0000796da41e004a  pop rsi
0000796da41e004b  pop rdi
0000796da41e004c  pop rdx
0000796da41e004d  pop rcx
0000796da41e004e  pop rax
0000796da41e004f  add rsp, 0x08
0000796da41e0053  jmp 0x0000796DA41DED93
0000796da41e0058  sub rsp, 0x08
0000796da41e005c  push rax
0000796da41e005d  push rcx
0000796da41e005e  push rdx
0000796da41e005f  push rdi
0000796da41e0060  push rsi
0000796da41e0061  push r8
0000796da41e0063  push r9
0000796da41e0065  push r10
0000796da41e0067  push r11
0000796da41e0069  sub rsp, 0xF0
0000796da41e0070  vmovaps [rsp], xmm0
0000796da41e0075  vmovaps [rsp+0x10], xmm1
0000796da41e007b  vmovaps [rsp+0x20], xmm2
0000796da41e0081  vmovaps [rsp+0x30], xmm3
0000796da41e0087  vmovaps [rsp+0x40], xmm4
0000796da41e008d  vmovaps [rsp+0x50], xmm5
0000796da41e0093  vmovaps [rsp+0x60], xmm7
0000796da41e0099  vmovaps [rsp+0x70], xmm8
0000796da41e009f  vmovaps [rsp+0x80], xmm9
0000796da41e00a8  vmovaps [rsp+0x90], xmm10
0000796da41e00b1  vmovaps [rsp+0xA0], xmm11
0000796da41e00ba  vmovaps [rsp+0xB0], xmm12
0000796da41e00c3  vmovaps [rsp+0xC0], xmm13
0000796da41e00cc  vmovaps [rsp+0xD0], xmm14
0000796da41e00d5  vmovaps [rsp+0xE0], xmm15
0000796da41e00de  sub rsp, 0x30
0000796da41e00e2  movaps [rsp], xmm6
0000796da41e00e6  movaps [rsp+0x10], xmm12
0000796da41e00ec  movaps [rsp+0x20], xmm11
0000796da41e00f2  lea rdi, [rsp]
0000796da41e00f6  mov esi, 0x00
0000796da41e00fb  mov rax, 0x5E26CB66A530
0000796da41e0105  call rax
0000796da41e0107  movaps xmm6, [rsp]
0000796da41e010b  add rsp, 0x30
0000796da41e010f  vmovaps xmm0, [rsp]
0000796da41e0114  vmovaps xmm1, [rsp+0x10]
0000796da41e011a  vmovaps xmm2, [rsp+0x20]
0000796da41e0120  vmovaps xmm3, [rsp+0x30]
0000796da41e0126  vmovaps xmm4, [rsp+0x40]
0000796da41e012c  vmovaps xmm5, [rsp+0x50]
0000796da41e0132  vmovaps xmm7, [rsp+0x60]
0000796da41e0138  vmovaps xmm8, [rsp+0x70]
0000796da41e013e  vmovaps xmm9, [rsp+0x80]
0000796da41e0147  vmovaps xmm10, [rsp+0x90]
0000796da41e0150  vmovaps xmm11, [rsp+0xA0]
0000796da41e0159  vmovaps xmm12, [rsp+0xB0]
0000796da41e0162  vmovaps xmm13, [rsp+0xC0]
0000796da41e016b  vmovaps xmm14, [rsp+0xD0]
0000796da41e0174  vmovaps xmm15, [rsp+0xE0]
0000796da41e017d  add rsp, 0xF0
0000796da41e0184  pop r11
0000796da41e0186  pop r10
0000796da41e0188  pop r9
0000796da41e018a  pop r8
0000796da41e018c  pop rsi
0000796da41e018d  pop rdi
0000796da41e018e  pop rdx
0000796da41e018f  pop rcx
0000796da41e0190  pop rax
0000796da41e0191  add rsp, 0x08
0000796da41e0195  jmp 0x0000796DA41DEDB4
0000796da41e019a  sub rsp, 0x08
0000796da41e019e  push rax
0000796da41e019f  push rcx
0000796da41e01a0  push rdx
0000796da41e01a1  push rdi
0000796da41e01a2  push rsi
0000796da41e01a3  push r8
0000796da41e01a5  push r9
0000796da41e01a7  push r10
0000796da41e01a9  push r11
0000796da41e01ab  sub rsp, 0xF0
0000796da41e01b2  vmovaps [rsp], xmm0
0000796da41e01b7  vmovaps [rsp+0x10], xmm1
0000796da41e01bd  vmovaps [rsp+0x20], xmm2
0000796da41e01c3  vmovaps [rsp+0x30], xmm4
0000796da41e01c9  vmovaps [rsp+0x40], xmm5
0000796da41e01cf  vmovaps [rsp+0x50], xmm6
0000796da41e01d5  vmovaps [rsp+0x60], xmm7
0000796da41e01db  vmovaps [rsp+0x70], xmm8
0000796da41e01e1  vmovaps [rsp+0x80], xmm9
0000796da41e01ea  vmovaps [rsp+0x90], xmm10
0000796da41e01f3  vmovaps [rsp+0xA0], xmm11
0000796da41e01fc  vmovaps [rsp+0xB0], xmm12
0000796da41e0205  vmovaps [rsp+0xC0], xmm13
0000796da41e020e  vmovaps [rsp+0xD0], xmm14
0000796da41e0217  vmovaps [rsp+0xE0], xmm15
0000796da41e0220  sub rsp, 0x30
0000796da41e0224  movaps [rsp], xmm3
0000796da41e0228  movaps [rsp+0x10], xmm5
0000796da41e022d  movaps [rsp+0x20], xmm4
0000796da41e0232  lea rdi, [rsp]
0000796da41e0236  mov esi, 0x00
0000796da41e023b  mov rax, 0x5E26CB66A530
0000796da41e0245  call rax
0000796da41e0247  movaps xmm3, [rsp]
0000796da41e024b  add rsp, 0x30
0000796da41e024f  vmovaps xmm0, [rsp]
0000796da41e0254  vmovaps xmm1, [rsp+0x10]
0000796da41e025a  vmovaps xmm2, [rsp+0x20]
0000796da41e0260  vmovaps xmm4, [rsp+0x30]
0000796da41e0266  vmovaps xmm5, [rsp+0x40]
0000796da41e026c  vmovaps xmm6, [rsp+0x50]
0000796da41e0272  vmovaps xmm7, [rsp+0x60]
0000796da41e0278  vmovaps xmm8, [rsp+0x70]
0000796da41e027e  vmovaps xmm9, [rsp+0x80]
0000796da41e0287  vmovaps xmm10, [rsp+0x90]
0000796da41e0290  vmovaps xmm11, [rsp+0xA0]
0000796da41e0299  vmovaps xmm12, [rsp+0xB0]
0000796da41e02a2  vmovaps xmm13, [rsp+0xC0]
0000796da41e02ab  vmovaps xmm14, [rsp+0xD0]
0000796da41e02b4  vmovaps xmm15, [rsp+0xE0]
0000796da41e02bd  add rsp, 0xF0
0000796da41e02c4  pop r11
0000796da41e02c6  pop r10
0000796da41e02c8  pop r9
0000796da41e02ca  pop r8
0000796da41e02cc  pop rsi
0000796da41e02cd  pop rdi
0000796da41e02ce  pop rdx
0000796da41e02cf  pop rcx
0000796da41e02d0  pop rax
0000796da41e02d1  add rsp, 0x08
0000796da41e02d5  jmp 0x0000796DA41DEE15
0000796da41e02da  sub rsp, 0x08
0000796da41e02de  push rax
0000796da41e02df  push rcx
0000796da41e02e0  push rdx
0000796da41e02e1  push rdi
0000796da41e02e2  push rsi
0000796da41e02e3  push r8
0000796da41e02e5  push r9
0000796da41e02e7  push r10
0000796da41e02e9  push r11
0000796da41e02eb  sub rsp, 0xF0
0000796da41e02f2  vmovaps [rsp], xmm0
0000796da41e02f7  vmovaps [rsp+0x10], xmm1
0000796da41e02fd  vmovaps [rsp+0x20], xmm2
0000796da41e0303  vmovaps [rsp+0x30], xmm3
0000796da41e0309  vmovaps [rsp+0x40], xmm4
0000796da41e030f  vmovaps [rsp+0x50], xmm6
0000796da41e0315  vmovaps [rsp+0x60], xmm7
0000796da41e031b  vmovaps [rsp+0x70], xmm8
0000796da41e0321  vmovaps [rsp+0x80], xmm9
0000796da41e032a  vmovaps [rsp+0x90], xmm10
0000796da41e0333  vmovaps [rsp+0xA0], xmm11
0000796da41e033c  vmovaps [rsp+0xB0], xmm12
0000796da41e0345  vmovaps [rsp+0xC0], xmm13
0000796da41e034e  vmovaps [rsp+0xD0], xmm14
0000796da41e0357  vmovaps [rsp+0xE0], xmm15
0000796da41e0360  sub rsp, 0x30
0000796da41e0364  movaps [rsp], xmm5
0000796da41e0368  movaps [rsp+0x10], xmm8
0000796da41e036e  movaps [rsp+0x20], xmm15
0000796da41e0374  lea rdi, [rsp]
0000796da41e0378  mov esi, 0x00
0000796da41e037d  mov rax, 0x5E26CB66A530
0000796da41e0387  call rax
0000796da41e0389  movaps xmm5, [rsp]
0000796da41e038d  add rsp, 0x30
0000796da41e0391  vmovaps xmm0, [rsp]
0000796da41e0396  vmovaps xmm1, [rsp+0x10]
0000796da41e039c  vmovaps xmm2, [rsp+0x20]
0000796da41e03a2  vmovaps xmm3, [rsp+0x30]
0000796da41e03a8  vmovaps xmm4, [rsp+0x40]
0000796da41e03ae  vmovaps xmm6, [rsp+0x50]
0000796da41e03b4  vmovaps xmm7, [rsp+0x60]
0000796da41e03ba  vmovaps xmm8, [rsp+0x70]
0000796da41e03c0  vmovaps xmm9, [rsp+0x80]
0000796da41e03c9  vmovaps xmm10, [rsp+0x90]
0000796da41e03d2  vmovaps xmm11, [rsp+0xA0]
0000796da41e03db  vmovaps xmm12, [rsp+0xB0]
0000796da41e03e4  vmovaps xmm13, [rsp+0xC0]
0000796da41e03ed  vmovaps xmm14, [rsp+0xD0]
0000796da41e03f6  vmovaps xmm15, [rsp+0xE0]
0000796da41e03ff  add rsp, 0xF0
0000796da41e0406  pop r11
0000796da41e0408  pop r10
0000796da41e040a  pop r9
0000796da41e040c  pop r8
0000796da41e040e  pop rsi
0000796da41e040f  pop rdi
0000796da41e0410  pop rdx
0000796da41e0411  pop rcx
0000796da41e0412  pop rax
0000796da41e0413  add rsp, 0x08
0000796da41e0417  jmp 0x0000796DA41DEE53
0000796da41e041c  sub rsp, 0x08
0000796da41e0420  push rax
0000796da41e0421  push rcx
0000796da41e0422  push rdx
0000796da41e0423  push rdi
0000796da41e0424  push rsi
0000796da41e0425  push r8
0000796da41e0427  push r9
0000796da41e0429  push r10
0000796da41e042b  push r11
0000796da41e042d  sub rsp, 0xF0
0000796da41e0434  vmovaps [rsp], xmm0
0000796da41e0439  vmovaps [rsp+0x10], xmm1
0000796da41e043f  vmovaps [rsp+0x20], xmm2
0000796da41e0445  vmovaps [rsp+0x30], xmm3
0000796da41e044b  vmovaps [rsp+0x40], xmm5
0000796da41e0451  vmovaps [rsp+0x50], xmm6
0000796da41e0457  vmovaps [rsp+0x60], xmm7
0000796da41e045d  vmovaps [rsp+0x70], xmm8
0000796da41e0463  vmovaps [rsp+0x80], xmm9
0000796da41e046c  vmovaps [rsp+0x90], xmm10
0000796da41e0475  vmovaps [rsp+0xA0], xmm11
0000796da41e047e  vmovaps [rsp+0xB0], xmm12
0000796da41e0487  vmovaps [rsp+0xC0], xmm13
0000796da41e0490  vmovaps [rsp+0xD0], xmm14
0000796da41e0499  vmovaps [rsp+0xE0], xmm15
0000796da41e04a2  sub rsp, 0x30
0000796da41e04a6  movaps [rsp], xmm4
0000796da41e04aa  movaps [rsp+0x10], xmm9
0000796da41e04b0  movaps [rsp+0x20], xmm8
0000796da41e04b6  lea rdi, [rsp]
0000796da41e04ba  mov esi, 0x00
0000796da41e04bf  mov rax, 0x5E26CB66A530
0000796da41e04c9  call rax
0000796da41e04cb  movaps xmm4, [rsp]
0000796da41e04cf  add rsp, 0x30
0000796da41e04d3  vmovaps xmm0, [rsp]
0000796da41e04d8  vmovaps xmm1, [rsp+0x10]
0000796da41e04de  vmovaps xmm2, [rsp+0x20]
0000796da41e04e4  vmovaps xmm3, [rsp+0x30]
0000796da41e04ea  vmovaps xmm5, [rsp+0x40]
0000796da41e04f0  vmovaps xmm6, [rsp+0x50]
0000796da41e04f6  vmovaps xmm7, [rsp+0x60]
0000796da41e04fc  vmovaps xmm8, [rsp+0x70]
0000796da41e0502  vmovaps xmm9, [rsp+0x80]
0000796da41e050b  vmovaps xmm10, [rsp+0x90]
0000796da41e0514  vmovaps xmm11, [rsp+0xA0]
0000796da41e051d  vmovaps xmm12, [rsp+0xB0]
0000796da41e0526  vmovaps xmm13, [rsp+0xC0]
0000796da41e052f  vmovaps xmm14, [rsp+0xD0]
0000796da41e0538  vmovaps xmm15, [rsp+0xE0]
0000796da41e0541  add rsp, 0xF0
0000796da41e0548  pop r11
0000796da41e054a  pop r10
0000796da41e054c  pop r9
0000796da41e054e  pop r8
0000796da41e0550  pop rsi
0000796da41e0551  pop rdi
0000796da41e0552  pop rdx
0000796da41e0553  pop rcx
0000796da41e0554  pop rax
0000796da41e0555  add rsp, 0x08
0000796da41e0559  jmp 0x0000796DA41DEE74
0000796da41e055e  sub rsp, 0x08
0000796da41e0562  push rax
0000796da41e0563  push rcx
0000796da41e0564  push rdx
0000796da41e0565  push rdi
0000796da41e0566  push rsi
0000796da41e0567  push r8
0000796da41e0569  push r9
0000796da41e056b  push r10
0000796da41e056d  push r11
0000796da41e056f  sub rsp, 0xF0
0000796da41e0576  vmovaps [rsp], xmm0
0000796da41e057b  vmovaps [rsp+0x10], xmm1
0000796da41e0581  vmovaps [rsp+0x20], xmm2
0000796da41e0587  vmovaps [rsp+0x30], xmm3
0000796da41e058d  vmovaps [rsp+0x40], xmm4
0000796da41e0593  vmovaps [rsp+0x50], xmm5
0000796da41e0599  vmovaps [rsp+0x60], xmm6
0000796da41e059f  vmovaps [rsp+0x70], xmm7
0000796da41e05a5  vmovaps [rsp+0x80], xmm8
0000796da41e05ae  vmovaps [rsp+0x90], xmm10
0000796da41e05b7  vmovaps [rsp+0xA0], xmm11
0000796da41e05c0  vmovaps [rsp+0xB0], xmm12
0000796da41e05c9  vmovaps [rsp+0xC0], xmm13
0000796da41e05d2  vmovaps [rsp+0xD0], xmm14
0000796da41e05db  vmovaps [rsp+0xE0], xmm15
0000796da41e05e4  sub rsp, 0x30
0000796da41e05e8  movaps [rsp], xmm9
0000796da41e05ed  movaps [rsp+0x10], xmm10
0000796da41e05f3  movaps [rsp+0x20], xmm8
0000796da41e05f9  lea rdi, [rsp]
0000796da41e05fd  mov esi, 0x00
0000796da41e0602  mov rax, 0x5E26CB66A530
0000796da41e060c  call rax
0000796da41e060e  movaps xmm9, [rsp]
0000796da41e0613  add rsp, 0x30
0000796da41e0617  vmovaps xmm0, [rsp]
0000796da41e061c  vmovaps xmm1, [rsp+0x10]
0000796da41e0622  vmovaps xmm2, [rsp+0x20]
0000796da41e0628  vmovaps xmm3, [rsp+0x30]
0000796da41e062e  vmovaps xmm4, [rsp+0x40]
0000796da41e0634  vmovaps xmm5, [rsp+0x50]
0000796da41e063a  vmovaps xmm6, [rsp+0x60]
0000796da41e0640  vmovaps xmm7, [rsp+0x70]
0000796da41e0646  vmovaps xmm8, [rsp+0x80]
0000796da41e064f  vmovaps xmm10, [rsp+0x90]
0000796da41e0658  vmovaps xmm11, [rsp+0xA0]
0000796da41e0661  vmovaps xmm12, [rsp+0xB0]
0000796da41e066a  vmovaps xmm13, [rsp+0xC0]
0000796da41e0673  vmovaps xmm14, [rsp+0xD0]
0000796da41e067c  vmovaps xmm15, [rsp+0xE0]
0000796da41e0685  add rsp, 0xF0
0000796da41e068c  pop r11
0000796da41e068e  pop r10
0000796da41e0690  pop r9
0000796da41e0692  pop r8
0000796da41e0694  pop rsi
0000796da41e0695  pop rdi
0000796da41e0696  pop rdx
0000796da41e0697  pop rcx
0000796da41e0698  pop rax
0000796da41e0699  add rsp, 0x08
0000796da41e069d  jmp 0x0000796DA41DEE8E
0000796da41e06a2  call 0x0000796DA40B52F0
0000796da41e06a7  jmp 0x0000796DA41DEFA8
0000796da41e06ac  call 0x0000796DA40B52F0
0000796da41e06b1  jmp 0x0000796DA41DEFBE
0000796da41e06b6  sub rsp, 0x08
0000796da41e06ba  push rax
0000796da41e06bb  push rcx
0000796da41e06bc  push rdx
0000796da41e06bd  push rdi
0000796da41e06be  push rsi
0000796da41e06bf  push r8
0000796da41e06c1  push r9
0000796da41e06c3  push r10
0000796da41e06c5  push r11
0000796da41e06c7  sub rsp, 0xF0
0000796da41e06ce  vmovaps [rsp], xmm0
0000796da41e06d3  vmovaps [rsp+0x10], xmm2
0000796da41e06d9  vmovaps [rsp+0x20], xmm3
0000796da41e06df  vmovaps [rsp+0x30], xmm4
0000796da41e06e5  vmovaps [rsp+0x40], xmm5
0000796da41e06eb  vmovaps [rsp+0x50], xmm6
0000796da41e06f1  vmovaps [rsp+0x60], xmm7
0000796da41e06f7  vmovaps [rsp+0x70], xmm8
0000796da41e06fd  vmovaps [rsp+0x80], xmm9
0000796da41e0706  vmovaps [rsp+0x90], xmm10
0000796da41e070f  vmovaps [rsp+0xA0], xmm11
0000796da41e0718  vmovaps [rsp+0xB0], xmm12
0000796da41e0721  vmovaps [rsp+0xC0], xmm13
0000796da41e072a  vmovaps [rsp+0xD0], xmm14
0000796da41e0733  vmovaps [rsp+0xE0], xmm15
0000796da41e073c  sub rsp, 0x30
0000796da41e0740  movaps [rsp], xmm1
0000796da41e0744  movaps [rsp+0x10], xmm6
0000796da41e0749  movaps [rsp+0x20], xmm15
0000796da41e074f  lea rdi, [rsp]
0000796da41e0753  mov esi, 0x00
0000796da41e0758  mov rax, 0x5E26CB66A530
0000796da41e0762  call rax
0000796da41e0764  movaps xmm1, [rsp]
0000796da41e0768  add rsp, 0x30
0000796da41e076c  vmovaps xmm0, [rsp]
0000796da41e0771  vmovaps xmm2, [rsp+0x10]
0000796da41e0777  vmovaps xmm3, [rsp+0x20]
0000796da41e077d  vmovaps xmm4, [rsp+0x30]
0000796da41e0783  vmovaps xmm5, [rsp+0x40]
0000796da41e0789  vmovaps xmm6, [rsp+0x50]
0000796da41e078f  vmovaps xmm7, [rsp+0x60]
0000796da41e0795  vmovaps xmm8, [rsp+0x70]
0000796da41e079b  vmovaps xmm9, [rsp+0x80]
0000796da41e07a4  vmovaps xmm10, [rsp+0x90]
0000796da41e07ad  vmovaps xmm11, [rsp+0xA0]
0000796da41e07b6  vmovaps xmm12, [rsp+0xB0]
0000796da41e07bf  vmovaps xmm13, [rsp+0xC0]
0000796da41e07c8  vmovaps xmm14, [rsp+0xD0]
0000796da41e07d1  vmovaps xmm15, [rsp+0xE0]
0000796da41e07da  add rsp, 0xF0
0000796da41e07e1  pop r11
0000796da41e07e3  pop r10
0000796da41e07e5  pop r9
0000796da41e07e7  pop r8
0000796da41e07e9  pop rsi
0000796da41e07ea  pop rdi
0000796da41e07eb  pop rdx
0000796da41e07ec  pop rcx
0000796da41e07ed  pop rax
0000796da41e07ee  add rsp, 0x08
0000796da41e07f2  jmp 0x0000796DA41DEFFB
0000796da41e07f7  call 0x0000796DA40C4620
0000796da41e07fc  jmp 0x0000796DA41DF008
0000796da41e0801  sub rsp, 0x08
0000796da41e0805  push rax
0000796da41e0806  push rcx
0000796da41e0807  push rdx
0000796da41e0808  push rdi
0000796da41e0809  push rsi
0000796da41e080a  push r8
0000796da41e080c  push r9
0000796da41e080e  push r10
0000796da41e0810  push r11
0000796da41e0812  sub rsp, 0xF0
0000796da41e0819  vmovaps [rsp], xmm0
0000796da41e081e  vmovaps [rsp+0x10], xmm1
0000796da41e0824  vmovaps [rsp+0x20], xmm2
0000796da41e082a  vmovaps [rsp+0x30], xmm3
0000796da41e0830  vmovaps [rsp+0x40], xmm4
0000796da41e0836  vmovaps [rsp+0x50], xmm5
0000796da41e083c  vmovaps [rsp+0x60], xmm6
0000796da41e0842  vmovaps [rsp+0x70], xmm7
0000796da41e0848  vmovaps [rsp+0x80], xmm8
0000796da41e0851  vmovaps [rsp+0x90], xmm9
0000796da41e085a  vmovaps [rsp+0xA0], xmm10
0000796da41e0863  vmovaps [rsp+0xB0], xmm11
0000796da41e086c  vmovaps [rsp+0xC0], xmm12
0000796da41e0875  vmovaps [rsp+0xD0], xmm13
0000796da41e087e  vmovaps [rsp+0xE0], xmm15
0000796da41e0887  sub rsp, 0x30
0000796da41e088b  movaps [rsp], xmm14
0000796da41e0890  movaps [rsp+0x10], xmm4
0000796da41e0895  movaps [rsp+0x20], xmm3
0000796da41e089a  lea rdi, [rsp]
0000796da41e089e  mov esi, 0x00
0000796da41e08a3  mov rax, 0x5E26CB66A530
0000796da41e08ad  call rax
0000796da41e08af  movaps xmm14, [rsp]
0000796da41e08b4  add rsp, 0x30
0000796da41e08b8  vmovaps xmm0, [rsp]
0000796da41e08bd  vmovaps xmm1, [rsp+0x10]
0000796da41e08c3  vmovaps xmm2, [rsp+0x20]
0000796da41e08c9  vmovaps xmm3, [rsp+0x30]
0000796da41e08cf  vmovaps xmm4, [rsp+0x40]
0000796da41e08d5  vmovaps xmm5, [rsp+0x50]
0000796da41e08db  vmovaps xmm6, [rsp+0x60]
0000796da41e08e1  vmovaps xmm7, [rsp+0x70]
0000796da41e08e7  vmovaps xmm8, [rsp+0x80]
0000796da41e08f0  vmovaps xmm9, [rsp+0x90]
0000796da41e08f9  vmovaps xmm10, [rsp+0xA0]
0000796da41e0902  vmovaps xmm11, [rsp+0xB0]
0000796da41e090b  vmovaps xmm12, [rsp+0xC0]
0000796da41e0914  vmovaps xmm13, [rsp+0xD0]
0000796da41e091d  vmovaps xmm15, [rsp+0xE0]
0000796da41e0926  add rsp, 0xF0
0000796da41e092d  pop r11
0000796da41e092f  pop r10
0000796da41e0931  pop r9
0000796da41e0933  pop r8
0000796da41e0935  pop rsi
0000796da41e0936  pop rdi
0000796da41e0937  pop rdx
0000796da41e0938  pop rcx
0000796da41e0939  pop rax
0000796da41e093a  add rsp, 0x08
0000796da41e093e  jmp 0x0000796DA41DF022
0000796da41e0943  sub rsp, 0x08
0000796da41e0947  push rax
0000796da41e0948  push rcx
0000796da41e0949  push rdx
0000796da41e094a  push rdi
0000796da41e094b  push rsi
0000796da41e094c  push r8
0000796da41e094e  push r9
0000796da41e0950  push r10
0000796da41e0952  push r11
0000796da41e0954  sub rsp, 0xF0
0000796da41e095b  vmovaps [rsp], xmm0
0000796da41e0960  vmovaps [rsp+0x10], xmm1
0000796da41e0966  vmovaps [rsp+0x20], xmm2
0000796da41e096c  vmovaps [rsp+0x30], xmm3
0000796da41e0972  vmovaps [rsp+0x40], xmm4
0000796da41e0978  vmovaps [rsp+0x50], xmm5
0000796da41e097e  vmovaps [rsp+0x60], xmm7
0000796da41e0984  vmovaps [rsp+0x70], xmm8
0000796da41e098a  vmovaps [rsp+0x80], xmm9
0000796da41e0993  vmovaps [rsp+0x90], xmm10
0000796da41e099c  vmovaps [rsp+0xA0], xmm11
0000796da41e09a5  vmovaps [rsp+0xB0], xmm12
0000796da41e09ae  vmovaps [rsp+0xC0], xmm13
0000796da41e09b7  vmovaps [rsp+0xD0], xmm14
0000796da41e09c0  vmovaps [rsp+0xE0], xmm15
0000796da41e09c9  sub rsp, 0x30
0000796da41e09cd  movaps [rsp], xmm6
0000796da41e09d1  movaps [rsp+0x10], xmm9
0000796da41e09d7  movaps [rsp+0x20], xmm7
0000796da41e09dc  lea rdi, [rsp]
0000796da41e09e0  mov esi, 0x00
0000796da41e09e5  mov rax, 0x5E26CB66A530
0000796da41e09ef  call rax
0000796da41e09f1  movaps xmm6, [rsp]
0000796da41e09f5  add rsp, 0x30
0000796da41e09f9  vmovaps xmm0, [rsp]
0000796da41e09fe  vmovaps xmm1, [rsp+0x10]
0000796da41e0a04  vmovaps xmm2, [rsp+0x20]
0000796da41e0a0a  vmovaps xmm3, [rsp+0x30]
0000796da41e0a10  vmovaps xmm4, [rsp+0x40]
0000796da41e0a16  vmovaps xmm5, [rsp+0x50]
0000796da41e0a1c  vmovaps xmm7, [rsp+0x60]
0000796da41e0a22  vmovaps xmm8, [rsp+0x70]
0000796da41e0a28  vmovaps xmm9, [rsp+0x80]
0000796da41e0a31  vmovaps xmm10, [rsp+0x90]
0000796da41e0a3a  vmovaps xmm11, [rsp+0xA0]
0000796da41e0a43  vmovaps xmm12, [rsp+0xB0]
0000796da41e0a4c  vmovaps xmm13, [rsp+0xC0]
0000796da41e0a55  vmovaps xmm14, [rsp+0xD0]
0000796da41e0a5e  vmovaps xmm15, [rsp+0xE0]
0000796da41e0a67  add rsp, 0xF0
0000796da41e0a6e  pop r11
0000796da41e0a70  pop r10
0000796da41e0a72  pop r9
0000796da41e0a74  pop r8
0000796da41e0a76  pop rsi
0000796da41e0a77  pop rdi
0000796da41e0a78  pop rdx
0000796da41e0a79  pop rcx
0000796da41e0a7a  pop rax
0000796da41e0a7b  add rsp, 0x08
0000796da41e0a7f  jmp 0x0000796DA41DF03A
0000796da41e0a84  sub rsp, 0x08
0000796da41e0a88  push rax
0000796da41e0a89  push rcx
0000796da41e0a8a  push rdx
0000796da41e0a8b  push rdi
0000796da41e0a8c  push rsi
0000796da41e0a8d  push r8
0000796da41e0a8f  push r9
0000796da41e0a91  push r10
0000796da41e0a93  push r11
0000796da41e0a95  sub rsp, 0xF0
0000796da41e0a9c  vmovaps [rsp], xmm0
0000796da41e0aa1  vmovaps [rsp+0x10], xmm1
0000796da41e0aa7  vmovaps [rsp+0x20], xmm2
0000796da41e0aad  vmovaps [rsp+0x30], xmm3
0000796da41e0ab3  vmovaps [rsp+0x40], xmm4
0000796da41e0ab9  vmovaps [rsp+0x50], xmm5
0000796da41e0abf  vmovaps [rsp+0x60], xmm6
0000796da41e0ac5  vmovaps [rsp+0x70], xmm8
0000796da41e0acb  vmovaps [rsp+0x80], xmm9
0000796da41e0ad4  vmovaps [rsp+0x90], xmm10
0000796da41e0add  vmovaps [rsp+0xA0], xmm11
0000796da41e0ae6  vmovaps [rsp+0xB0], xmm12
0000796da41e0aef  vmovaps [rsp+0xC0], xmm13
0000796da41e0af8  vmovaps [rsp+0xD0], xmm14
0000796da41e0b01  vmovaps [rsp+0xE0], xmm15
0000796da41e0b0a  sub rsp, 0x30
0000796da41e0b0e  movaps [rsp], xmm7
0000796da41e0b12  movaps [rsp+0x10], xmm4
0000796da41e0b17  movaps [rsp+0x20], xmm9
0000796da41e0b1d  lea rdi, [rsp]
0000796da41e0b21  mov esi, 0x00
0000796da41e0b26  mov rax, 0x5E26CB66A530
0000796da41e0b30  call rax
0000796da41e0b32  movaps xmm7, [rsp]
0000796da41e0b36  add rsp, 0x30
0000796da41e0b3a  vmovaps xmm0, [rsp]
0000796da41e0b3f  vmovaps xmm1, [rsp+0x10]
0000796da41e0b45  vmovaps xmm2, [rsp+0x20]
0000796da41e0b4b  vmovaps xmm3, [rsp+0x30]
0000796da41e0b51  vmovaps xmm4, [rsp+0x40]
0000796da41e0b57  vmovaps xmm5, [rsp+0x50]
0000796da41e0b5d  vmovaps xmm6, [rsp+0x60]
0000796da41e0b63  vmovaps xmm8, [rsp+0x70]
0000796da41e0b69  vmovaps xmm9, [rsp+0x80]
0000796da41e0b72  vmovaps xmm10, [rsp+0x90]
0000796da41e0b7b  vmovaps xmm11, [rsp+0xA0]
0000796da41e0b84  vmovaps xmm12, [rsp+0xB0]
0000796da41e0b8d  vmovaps xmm13, [rsp+0xC0]
0000796da41e0b96  vmovaps xmm14, [rsp+0xD0]
0000796da41e0b9f  vmovaps xmm15, [rsp+0xE0]
0000796da41e0ba8  add rsp, 0xF0
0000796da41e0baf  pop r11
0000796da41e0bb1  pop r10
0000796da41e0bb3  pop r9
0000796da41e0bb5  pop r8
0000796da41e0bb7  pop rsi
0000796da41e0bb8  pop rdi
0000796da41e0bb9  pop rdx
0000796da41e0bba  pop rcx
0000796da41e0bbb  pop rax
0000796da41e0bbc  add rsp, 0x08
0000796da41e0bc0  jmp 0x0000796DA41DF067
0000796da41e0bc5  sub rsp, 0x08
0000796da41e0bc9  push rax
0000796da41e0bca  push rcx
0000796da41e0bcb  push rdx
0000796da41e0bcc  push rdi
0000796da41e0bcd  push rsi
0000796da41e0bce  push r8
0000796da41e0bd0  push r9
0000796da41e0bd2  push r10
0000796da41e0bd4  push r11
0000796da41e0bd6  sub rsp, 0xF0
0000796da41e0bdd  vmovaps [rsp], xmm0
0000796da41e0be2  vmovaps [rsp+0x10], xmm1
0000796da41e0be8  vmovaps [rsp+0x20], xmm2
0000796da41e0bee  vmovaps [rsp+0x30], xmm3
0000796da41e0bf4  vmovaps [rsp+0x40], xmm5
0000796da41e0bfa  vmovaps [rsp+0x50], xmm6
0000796da41e0c00  vmovaps [rsp+0x60], xmm7
0000796da41e0c06  vmovaps [rsp+0x70], xmm8
0000796da41e0c0c  vmovaps [rsp+0x80], xmm9
0000796da41e0c15  vmovaps [rsp+0x90], xmm10
0000796da41e0c1e  vmovaps [rsp+0xA0], xmm11
0000796da41e0c27  vmovaps [rsp+0xB0], xmm12
0000796da41e0c30  vmovaps [rsp+0xC0], xmm13
0000796da41e0c39  vmovaps [rsp+0xD0], xmm14
0000796da41e0c42  vmovaps [rsp+0xE0], xmm15
0000796da41e0c4b  sub rsp, 0x30
0000796da41e0c4f  movaps [rsp], xmm4
0000796da41e0c53  movaps [rsp+0x10], xmm15
0000796da41e0c59  movaps [rsp+0x20], xmm9
0000796da41e0c5f  lea rdi, [rsp]
0000796da41e0c63  mov esi, 0x00
0000796da41e0c68  mov rax, 0x5E26CB66A530
0000796da41e0c72  call rax
0000796da41e0c74  movaps xmm4, [rsp]
0000796da41e0c78  add rsp, 0x30
0000796da41e0c7c  vmovaps xmm0, [rsp]
0000796da41e0c81  vmovaps xmm1, [rsp+0x10]
0000796da41e0c87  vmovaps xmm2, [rsp+0x20]
0000796da41e0c8d  vmovaps xmm3, [rsp+0x30]
0000796da41e0c93  vmovaps xmm5, [rsp+0x40]
0000796da41e0c99  vmovaps xmm6, [rsp+0x50]
0000796da41e0c9f  vmovaps xmm7, [rsp+0x60]
0000796da41e0ca5  vmovaps xmm8, [rsp+0x70]
0000796da41e0cab  vmovaps xmm9, [rsp+0x80]
0000796da41e0cb4  vmovaps xmm10, [rsp+0x90]
0000796da41e0cbd  vmovaps xmm11, [rsp+0xA0]
0000796da41e0cc6  vmovaps xmm12, [rsp+0xB0]
0000796da41e0ccf  vmovaps xmm13, [rsp+0xC0]
0000796da41e0cd8  vmovaps xmm14, [rsp+0xD0]
0000796da41e0ce1  vmovaps xmm15, [rsp+0xE0]
0000796da41e0cea  add rsp, 0xF0
0000796da41e0cf1  pop r11
0000796da41e0cf3  pop r10
0000796da41e0cf5  pop r9
0000796da41e0cf7  pop r8
0000796da41e0cf9  pop rsi
0000796da41e0cfa  pop rdi
0000796da41e0cfb  pop rdx
0000796da41e0cfc  pop rcx
0000796da41e0cfd  pop rax
0000796da41e0cfe  add rsp, 0x08
0000796da41e0d02  jmp 0x0000796DA41DF08C
0000796da41e0d07  call 0x0000796DA40C4620
0000796da41e0d0c  jmp 0x0000796DA41DF099
0000796da41e0d11  sub rsp, 0x08
0000796da41e0d15  push rax
0000796da41e0d16  push rcx
0000796da41e0d17  push rdx
0000796da41e0d18  push rdi
0000796da41e0d19  push rsi
0000796da41e0d1a  push r8
0000796da41e0d1c  push r9
0000796da41e0d1e  push r10
0000796da41e0d20  push r11
0000796da41e0d22  sub rsp, 0xF0
0000796da41e0d29  vmovaps [rsp], xmm0
0000796da41e0d2e  vmovaps [rsp+0x10], xmm1
0000796da41e0d34  vmovaps [rsp+0x20], xmm2
0000796da41e0d3a  vmovaps [rsp+0x30], xmm4
0000796da41e0d40  vmovaps [rsp+0x40], xmm5
0000796da41e0d46  vmovaps [rsp+0x50], xmm6
0000796da41e0d4c  vmovaps [rsp+0x60], xmm7
0000796da41e0d52  vmovaps [rsp+0x70], xmm8
0000796da41e0d58  vmovaps [rsp+0x80], xmm9
0000796da41e0d61  vmovaps [rsp+0x90], xmm10
0000796da41e0d6a  vmovaps [rsp+0xA0], xmm11
0000796da41e0d73  vmovaps [rsp+0xB0], xmm12
0000796da41e0d7c  vmovaps [rsp+0xC0], xmm13
0000796da41e0d85  vmovaps [rsp+0xD0], xmm14
0000796da41e0d8e  vmovaps [rsp+0xE0], xmm15
0000796da41e0d97  sub rsp, 0x30
0000796da41e0d9b  movaps [rsp], xmm3
0000796da41e0d9f  movaps [rsp+0x10], xmm1
0000796da41e0da4  movaps [rsp+0x20], xmm9
0000796da41e0daa  lea rdi, [rsp]
0000796da41e0dae  mov esi, 0x00
0000796da41e0db3  mov rax, 0x5E26CB66A530
0000796da41e0dbd  call rax
0000796da41e0dbf  movaps xmm3, [rsp]
0000796da41e0dc3  add rsp, 0x30
0000796da41e0dc7  vmovaps xmm0, [rsp]
0000796da41e0dcc  vmovaps xmm1, [rsp+0x10]
0000796da41e0dd2  vmovaps xmm2, [rsp+0x20]
0000796da41e0dd8  vmovaps xmm4, [rsp+0x30]
0000796da41e0dde  vmovaps xmm5, [rsp+0x40]
0000796da41e0de4  vmovaps xmm6, [rsp+0x50]
0000796da41e0dea  vmovaps xmm7, [rsp+0x60]
0000796da41e0df0  vmovaps xmm8, [rsp+0x70]
0000796da41e0df6  vmovaps xmm9, [rsp+0x80]
0000796da41e0dff  vmovaps xmm10, [rsp+0x90]
0000796da41e0e08  vmovaps xmm11, [rsp+0xA0]
0000796da41e0e11  vmovaps xmm12, [rsp+0xB0]
0000796da41e0e1a  vmovaps xmm13, [rsp+0xC0]
0000796da41e0e23  vmovaps xmm14, [rsp+0xD0]
0000796da41e0e2c  vmovaps xmm15, [rsp+0xE0]
0000796da41e0e35  add rsp, 0xF0
0000796da41e0e3c  pop r11
0000796da41e0e3e  pop r10
0000796da41e0e40  pop r9
0000796da41e0e42  pop r8
0000796da41e0e44  pop rsi
0000796da41e0e45  pop rdi
0000796da41e0e46  pop rdx
0000796da41e0e47  pop rcx
0000796da41e0e48  pop rax
0000796da41e0e49  add rsp, 0x08
0000796da41e0e4d  jmp 0x0000796DA41DF0D6
0000796da41e0e52  sub rsp, 0x08
0000796da41e0e56  push rax
0000796da41e0e57  push rcx
0000796da41e0e58  push rdx
0000796da41e0e59  push rdi
0000796da41e0e5a  push rsi
0000796da41e0e5b  push r8
0000796da41e0e5d  push r9
0000796da41e0e5f  push r10
0000796da41e0e61  push r11
0000796da41e0e63  sub rsp, 0xF0
0000796da41e0e6a  vmovaps [rsp], xmm0
0000796da41e0e6f  vmovaps [rsp+0x10], xmm2
0000796da41e0e75  vmovaps [rsp+0x20], xmm3
0000796da41e0e7b  vmovaps [rsp+0x30], xmm4
0000796da41e0e81  vmovaps [rsp+0x40], xmm5
0000796da41e0e87  vmovaps [rsp+0x50], xmm6
0000796da41e0e8d  vmovaps [rsp+0x60], xmm7
0000796da41e0e93  vmovaps [rsp+0x70], xmm8
0000796da41e0e99  vmovaps [rsp+0x80], xmm9
0000796da41e0ea2  vmovaps [rsp+0x90], xmm10
0000796da41e0eab  vmovaps [rsp+0xA0], xmm11
0000796da41e0eb4  vmovaps [rsp+0xB0], xmm12
0000796da41e0ebd  vmovaps [rsp+0xC0], xmm13
0000796da41e0ec6  vmovaps [rsp+0xD0], xmm14
0000796da41e0ecf  vmovaps [rsp+0xE0], xmm15
0000796da41e0ed8  sub rsp, 0x30
0000796da41e0edc  movaps [rsp], xmm1
0000796da41e0ee0  movaps [rsp+0x10], xmm15
0000796da41e0ee6  movaps [rsp+0x20], xmm9
0000796da41e0eec  lea rdi, [rsp]
0000796da41e0ef0  mov esi, 0x00
0000796da41e0ef5  mov rax, 0x5E26CB66A530
0000796da41e0eff  call rax
0000796da41e0f01  movaps xmm1, [rsp]
0000796da41e0f05  add rsp, 0x30
0000796da41e0f09  vmovaps xmm0, [rsp]
0000796da41e0f0e  vmovaps xmm2, [rsp+0x10]
0000796da41e0f14  vmovaps xmm3, [rsp+0x20]
0000796da41e0f1a  vmovaps xmm4, [rsp+0x30]
0000796da41e0f20  vmovaps xmm5, [rsp+0x40]
0000796da41e0f26  vmovaps xmm6, [rsp+0x50]
0000796da41e0f2c  vmovaps xmm7, [rsp+0x60]
0000796da41e0f32  vmovaps xmm8, [rsp+0x70]
0000796da41e0f38  vmovaps xmm9, [rsp+0x80]
0000796da41e0f41  vmovaps xmm10, [rsp+0x90]
0000796da41e0f4a  vmovaps xmm11, [rsp+0xA0]
0000796da41e0f53  vmovaps xmm12, [rsp+0xB0]
0000796da41e0f5c  vmovaps xmm13, [rsp+0xC0]
0000796da41e0f65  vmovaps xmm14, [rsp+0xD0]
0000796da41e0f6e  vmovaps xmm15, [rsp+0xE0]
0000796da41e0f77  add rsp, 0xF0
0000796da41e0f7e  pop r11
0000796da41e0f80  pop r10
0000796da41e0f82  pop r9
0000796da41e0f84  pop r8
0000796da41e0f86  pop rsi
0000796da41e0f87  pop rdi
0000796da41e0f88  pop rdx
0000796da41e0f89  pop rcx
0000796da41e0f8a  pop rax
0000796da41e0f8b  add rsp, 0x08
0000796da41e0f8f  jmp 0x0000796DA41DF15E
0000796da41e0f94  call 0x0000796DA40C4620
0000796da41e0f99  jmp 0x0000796DA41DF16B
0000796da41e0f9e  sub rsp, 0x08
0000796da41e0fa2  push rax
0000796da41e0fa3  push rcx
0000796da41e0fa4  push rdx
0000796da41e0fa5  push rdi
0000796da41e0fa6  push rsi
0000796da41e0fa7  push r8
0000796da41e0fa9  push r9
0000796da41e0fab  push r10
0000796da41e0fad  push r11
0000796da41e0faf  sub rsp, 0xF0
0000796da41e0fb6  vmovaps [rsp], xmm0
0000796da41e0fbb  vmovaps [rsp+0x10], xmm2
0000796da41e0fc1  vmovaps [rsp+0x20], xmm3
0000796da41e0fc7  vmovaps [rsp+0x30], xmm4
0000796da41e0fcd  vmovaps [rsp+0x40], xmm5
0000796da41e0fd3  vmovaps [rsp+0x50], xmm6
0000796da41e0fd9  vmovaps [rsp+0x60], xmm7
0000796da41e0fdf  vmovaps [rsp+0x70], xmm8
0000796da41e0fe5  vmovaps [rsp+0x80], xmm9
0000796da41e0fee  vmovaps [rsp+0x90], xmm10
0000796da41e0ff7  vmovaps [rsp+0xA0], xmm11
0000796da41e1000  vmovaps [rsp+0xB0], xmm12
0000796da41e1009  vmovaps [rsp+0xC0], xmm13
0000796da41e1012  vmovaps [rsp+0xD0], xmm14
0000796da41e101b  vmovaps [rsp+0xE0], xmm15
0000796da41e1024  sub rsp, 0x30
0000796da41e1028  movaps [rsp], xmm1
0000796da41e102c  movaps [rsp+0x10], xmm5
0000796da41e1031  movaps [rsp+0x20], xmm7
0000796da41e1036  lea rdi, [rsp]
0000796da41e103a  mov esi, 0x00
0000796da41e103f  mov rax, 0x5E26CB66A530
0000796da41e1049  call rax
0000796da41e104b  movaps xmm1, [rsp]
0000796da41e104f  add rsp, 0x30
0000796da41e1053  vmovaps xmm0, [rsp]
0000796da41e1058  vmovaps xmm2, [rsp+0x10]
0000796da41e105e  vmovaps xmm3, [rsp+0x20]
0000796da41e1064  vmovaps xmm4, [rsp+0x30]
0000796da41e106a  vmovaps xmm5, [rsp+0x40]
0000796da41e1070  vmovaps xmm6, [rsp+0x50]
0000796da41e1076  vmovaps xmm7, [rsp+0x60]
0000796da41e107c  vmovaps xmm8, [rsp+0x70]
0000796da41e1082  vmovaps xmm9, [rsp+0x80]
0000796da41e108b  vmovaps xmm10, [rsp+0x90]
0000796da41e1094  vmovaps xmm11, [rsp+0xA0]
0000796da41e109d  vmovaps xmm12, [rsp+0xB0]
0000796da41e10a6  vmovaps xmm13, [rsp+0xC0]
0000796da41e10af  vmovaps xmm14, [rsp+0xD0]
0000796da41e10b8  vmovaps xmm15, [rsp+0xE0]
0000796da41e10c1  add rsp, 0xF0
0000796da41e10c8  pop r11
0000796da41e10ca  pop r10
0000796da41e10cc  pop r9
0000796da41e10ce  pop r8
0000796da41e10d0  pop rsi
0000796da41e10d1  pop rdi
0000796da41e10d2  pop rdx
0000796da41e10d3  pop rcx
0000796da41e10d4  pop rax
0000796da41e10d5  add rsp, 0x08
0000796da41e10d9  jmp 0x0000796DA41DF210
0000796da41e10de  sub rsp, 0x08
0000796da41e10e2  push rax
0000796da41e10e3  push rcx
0000796da41e10e4  push rdx
0000796da41e10e5  push rdi
0000796da41e10e6  push rsi
0000796da41e10e7  push r8
0000796da41e10e9  push r9
0000796da41e10eb  push r10
0000796da41e10ed  push r11
0000796da41e10ef  sub rsp, 0xF0
0000796da41e10f6  vmovaps [rsp], xmm0
0000796da41e10fb  vmovaps [rsp+0x10], xmm1
0000796da41e1101  vmovaps [rsp+0x20], xmm2
0000796da41e1107  vmovaps [rsp+0x30], xmm3
0000796da41e110d  vmovaps [rsp+0x40], xmm4
0000796da41e1113  vmovaps [rsp+0x50], xmm5
0000796da41e1119  vmovaps [rsp+0x60], xmm6
0000796da41e111f  vmovaps [rsp+0x70], xmm8
0000796da41e1125  vmovaps [rsp+0x80], xmm9
0000796da41e112e  vmovaps [rsp+0x90], xmm10
0000796da41e1137  vmovaps [rsp+0xA0], xmm11
0000796da41e1140  vmovaps [rsp+0xB0], xmm12
0000796da41e1149  vmovaps [rsp+0xC0], xmm13
0000796da41e1152  vmovaps [rsp+0xD0], xmm14
0000796da41e115b  vmovaps [rsp+0xE0], xmm15
0000796da41e1164  sub rsp, 0x30
0000796da41e1168  movaps [rsp], xmm7
0000796da41e116c  movaps [rsp+0x10], xmm5
0000796da41e1171  movaps [rsp+0x20], xmm15
0000796da41e1177  lea rdi, [rsp]
0000796da41e117b  mov esi, 0x00
0000796da41e1180  mov rax, 0x5E26CB66A530
0000796da41e118a  call rax
0000796da41e118c  movaps xmm7, [rsp]
0000796da41e1190  add rsp, 0x30
0000796da41e1194  vmovaps xmm0, [rsp]
0000796da41e1199  vmovaps xmm1, [rsp+0x10]
0000796da41e119f  vmovaps xmm2, [rsp+0x20]
0000796da41e11a5  vmovaps xmm3, [rsp+0x30]
0000796da41e11ab  vmovaps xmm4, [rsp+0x40]
0000796da41e11b1  vmovaps xmm5, [rsp+0x50]
0000796da41e11b7  vmovaps xmm6, [rsp+0x60]
0000796da41e11bd  vmovaps xmm8, [rsp+0x70]
0000796da41e11c3  vmovaps xmm9, [rsp+0x80]
0000796da41e11cc  vmovaps xmm10, [rsp+0x90]
0000796da41e11d5  vmovaps xmm11, [rsp+0xA0]
0000796da41e11de  vmovaps xmm12, [rsp+0xB0]
0000796da41e11e7  vmovaps xmm13, [rsp+0xC0]
0000796da41e11f0  vmovaps xmm14, [rsp+0xD0]
0000796da41e11f9  vmovaps xmm15, [rsp+0xE0]
0000796da41e1202  add rsp, 0xF0
0000796da41e1209  pop r11
0000796da41e120b  pop r10
0000796da41e120d  pop r9
0000796da41e120f  pop r8
0000796da41e1211  pop rsi
0000796da41e1212  pop rdi
0000796da41e1213  pop rdx
0000796da41e1214  pop rcx
0000796da41e1215  pop rax
0000796da41e1216  add rsp, 0x08
0000796da41e121a  jmp 0x0000796DA41DF246
0000796da41e121f  call 0x0000796DA40B52F0
0000796da41e1224  jmp 0x0000796DA41DF253
0000796da41e1229  sub rsp, 0x08
0000796da41e122d  push rax
0000796da41e122e  push rcx
0000796da41e122f  push rdx
0000796da41e1230  push rdi
0000796da41e1231  push rsi
0000796da41e1232  push r8
0000796da41e1234  push r9
0000796da41e1236  push r10
0000796da41e1238  push r11
0000796da41e123a  sub rsp, 0xF0
0000796da41e1241  vmovaps [rsp], xmm0
0000796da41e1246  vmovaps [rsp+0x10], xmm1
0000796da41e124c  vmovaps [rsp+0x20], xmm2
0000796da41e1252  vmovaps [rsp+0x30], xmm3
0000796da41e1258  vmovaps [rsp+0x40], xmm4
0000796da41e125e  vmovaps [rsp+0x50], xmm5
0000796da41e1264  vmovaps [rsp+0x60], xmm6
0000796da41e126a  vmovaps [rsp+0x70], xmm7
0000796da41e1270  vmovaps [rsp+0x80], xmm8
0000796da41e1279  vmovaps [rsp+0x90], xmm9
0000796da41e1282  vmovaps [rsp+0xA0], xmm10
0000796da41e128b  vmovaps [rsp+0xB0], xmm11
0000796da41e1294  vmovaps [rsp+0xC0], xmm12
0000796da41e129d  vmovaps [rsp+0xD0], xmm13
0000796da41e12a6  vmovaps [rsp+0xE0], xmm14
0000796da41e12af  sub rsp, 0x30
0000796da41e12b3  movaps [rsp], xmm15
0000796da41e12b8  movaps [rsp+0x10], xmm5
0000796da41e12bd  movaps [rsp+0x20], xmm3
0000796da41e12c2  lea rdi, [rsp]
0000796da41e12c6  mov esi, 0x00
0000796da41e12cb  mov rax, 0x5E26CB66A530
0000796da41e12d5  call rax
0000796da41e12d7  movaps xmm15, [rsp]
0000796da41e12dc  add rsp, 0x30
0000796da41e12e0  vmovaps xmm0, [rsp]
0000796da41e12e5  vmovaps xmm1, [rsp+0x10]
0000796da41e12eb  vmovaps xmm2, [rsp+0x20]
0000796da41e12f1  vmovaps xmm3, [rsp+0x30]
0000796da41e12f7  vmovaps xmm4, [rsp+0x40]
0000796da41e12fd  vmovaps xmm5, [rsp+0x50]
0000796da41e1303  vmovaps xmm6, [rsp+0x60]
0000796da41e1309  vmovaps xmm7, [rsp+0x70]
0000796da41e130f  vmovaps xmm8, [rsp+0x80]
0000796da41e1318  vmovaps xmm9, [rsp+0x90]
0000796da41e1321  vmovaps xmm10, [rsp+0xA0]
0000796da41e132a  vmovaps xmm11, [rsp+0xB0]
0000796da41e1333  vmovaps xmm12, [rsp+0xC0]
0000796da41e133c  vmovaps xmm13, [rsp+0xD0]
0000796da41e1345  vmovaps xmm14, [rsp+0xE0]
0000796da41e134e  add rsp, 0xF0
0000796da41e1355  pop r11
0000796da41e1357  pop r10
0000796da41e1359  pop r9
0000796da41e135b  pop r8
0000796da41e135d  pop rsi
0000796da41e135e  pop rdi
0000796da41e135f  pop rdx
0000796da41e1360  pop rcx
0000796da41e1361  pop rax
0000796da41e1362  add rsp, 0x08
0000796da41e1366  jmp 0x0000796DA41DF279
0000796da41e136b  sub rsp, 0x08
0000796da41e136f  push rax
0000796da41e1370  push rcx
0000796da41e1371  push rdx
0000796da41e1372  push rdi
0000796da41e1373  push rsi
0000796da41e1374  push r8
0000796da41e1376  push r9
0000796da41e1378  push r10
0000796da41e137a  push r11
0000796da41e137c  sub rsp, 0xF0
0000796da41e1383  vmovaps [rsp], xmm0
0000796da41e1388  vmovaps [rsp+0x10], xmm2
0000796da41e138e  vmovaps [rsp+0x20], xmm3
0000796da41e1394  vmovaps [rsp+0x30], xmm4
0000796da41e139a  vmovaps [rsp+0x40], xmm5
0000796da41e13a0  vmovaps [rsp+0x50], xmm6
0000796da41e13a6  vmovaps [rsp+0x60], xmm7
0000796da41e13ac  vmovaps [rsp+0x70], xmm8
0000796da41e13b2  vmovaps [rsp+0x80], xmm9
0000796da41e13bb  vmovaps [rsp+0x90], xmm10
0000796da41e13c4  vmovaps [rsp+0xA0], xmm11
0000796da41e13cd  vmovaps [rsp+0xB0], xmm12
0000796da41e13d6  vmovaps [rsp+0xC0], xmm13
0000796da41e13df  vmovaps [rsp+0xD0], xmm14
0000796da41e13e8  vmovaps [rsp+0xE0], xmm15
0000796da41e13f1  sub rsp, 0x30
0000796da41e13f5  movaps [rsp], xmm1
0000796da41e13f9  movaps [rsp+0x10], xmm5
0000796da41e13fe  movaps [rsp+0x20], xmm4
0000796da41e1403  lea rdi, [rsp]
0000796da41e1407  mov esi, 0x00
0000796da41e140c  mov rax, 0x5E26CB66A530
0000796da41e1416  call rax
0000796da41e1418  movaps xmm1, [rsp]
0000796da41e141c  add rsp, 0x30
0000796da41e1420  vmovaps xmm0, [rsp]
0000796da41e1425  vmovaps xmm2, [rsp+0x10]
0000796da41e142b  vmovaps xmm3, [rsp+0x20]
0000796da41e1431  vmovaps xmm4, [rsp+0x30]
0000796da41e1437  vmovaps xmm5, [rsp+0x40]
0000796da41e143d  vmovaps xmm6, [rsp+0x50]
0000796da41e1443  vmovaps xmm7, [rsp+0x60]
0000796da41e1449  vmovaps xmm8, [rsp+0x70]
0000796da41e144f  vmovaps xmm9, [rsp+0x80]
0000796da41e1458  vmovaps xmm10, [rsp+0x90]
0000796da41e1461  vmovaps xmm11, [rsp+0xA0]
0000796da41e146a  vmovaps xmm12, [rsp+0xB0]
0000796da41e1473  vmovaps xmm13, [rsp+0xC0]
0000796da41e147c  vmovaps xmm14, [rsp+0xD0]
0000796da41e1485  vmovaps xmm15, [rsp+0xE0]
0000796da41e148e  add rsp, 0xF0
0000796da41e1495  pop r11
0000796da41e1497  pop r10
0000796da41e1499  pop r9
0000796da41e149b  pop r8
0000796da41e149d  pop rsi
0000796da41e149e  pop rdi
0000796da41e149f  pop rdx
0000796da41e14a0  pop rcx
0000796da41e14a1  pop rax
0000796da41e14a2  add rsp, 0x08
0000796da41e14a6  jmp 0x0000796DA41DF299
0000796da41e14ab  sub rsp, 0x08
0000796da41e14af  push rax
0000796da41e14b0  push rcx
0000796da41e14b1  push rdx
0000796da41e14b2  push rdi
0000796da41e14b3  push rsi
0000796da41e14b4  push r8
0000796da41e14b6  push r9
0000796da41e14b8  push r10
0000796da41e14ba  push r11
0000796da41e14bc  sub rsp, 0xF0
0000796da41e14c3  vmovaps [rsp], xmm0
0000796da41e14c8  vmovaps [rsp+0x10], xmm1
0000796da41e14ce  vmovaps [rsp+0x20], xmm2
0000796da41e14d4  vmovaps [rsp+0x30], xmm3
0000796da41e14da  vmovaps [rsp+0x40], xmm5
0000796da41e14e0  vmovaps [rsp+0x50], xmm6
0000796da41e14e6  vmovaps [rsp+0x60], xmm7
0000796da41e14ec  vmovaps [rsp+0x70], xmm8
0000796da41e14f2  vmovaps [rsp+0x80], xmm9
0000796da41e14fb  vmovaps [rsp+0x90], xmm10
0000796da41e1504  vmovaps [rsp+0xA0], xmm11
0000796da41e150d  vmovaps [rsp+0xB0], xmm12
0000796da41e1516  vmovaps [rsp+0xC0], xmm13
0000796da41e151f  vmovaps [rsp+0xD0], xmm14
0000796da41e1528  vmovaps [rsp+0xE0], xmm15
0000796da41e1531  sub rsp, 0x30
0000796da41e1535  movaps [rsp], xmm4
0000796da41e1539  movaps [rsp+0x10], xmm3
0000796da41e153e  movaps [rsp+0x20], xmm5
0000796da41e1543  lea rdi, [rsp]
0000796da41e1547  mov esi, 0x00
0000796da41e154c  mov rax, 0x5E26CB66A530
0000796da41e1556  call rax
0000796da41e1558  movaps xmm4, [rsp]
0000796da41e155c  add rsp, 0x30
0000796da41e1560  vmovaps xmm0, [rsp]
0000796da41e1565  vmovaps xmm1, [rsp+0x10]
0000796da41e156b  vmovaps xmm2, [rsp+0x20]
0000796da41e1571  vmovaps xmm3, [rsp+0x30]
0000796da41e1577  vmovaps xmm5, [rsp+0x40]
0000796da41e157d  vmovaps xmm6, [rsp+0x50]
0000796da41e1583  vmovaps xmm7, [rsp+0x60]
0000796da41e1589  vmovaps xmm8, [rsp+0x70]
0000796da41e158f  vmovaps xmm9, [rsp+0x80]
0000796da41e1598  vmovaps xmm10, [rsp+0x90]
0000796da41e15a1  vmovaps xmm11, [rsp+0xA0]
0000796da41e15aa  vmovaps xmm12, [rsp+0xB0]
0000796da41e15b3  vmovaps xmm13, [rsp+0xC0]
0000796da41e15bc  vmovaps xmm14, [rsp+0xD0]
0000796da41e15c5  vmovaps xmm15, [rsp+0xE0]
0000796da41e15ce  add rsp, 0xF0
0000796da41e15d5  pop r11
0000796da41e15d7  pop r10
0000796da41e15d9  pop r9
0000796da41e15db  pop r8
0000796da41e15dd  pop rsi
0000796da41e15de  pop rdi
0000796da41e15df  pop rdx
0000796da41e15e0  pop rcx
0000796da41e15e1  pop rax
0000796da41e15e2  add rsp, 0x08
0000796da41e15e6  jmp 0x0000796DA41DF2E7
0000796da41e15eb  call 0x0000796DA40B52F0
0000796da41e15f0  jmp 0x0000796DA41DF2F4
0000796da41e15f5  sub rsp, 0x08
0000796da41e15f9  push rax
0000796da41e15fa  push rcx
0000796da41e15fb  push rdx
0000796da41e15fc  push rdi
0000796da41e15fd  push rsi
0000796da41e15fe  push r8
0000796da41e1600  push r9
0000796da41e1602  push r10
0000796da41e1604  push r11
0000796da41e1606  sub rsp, 0xF0
0000796da41e160d  vmovaps [rsp], xmm0
0000796da41e1612  vmovaps [rsp+0x10], xmm1
0000796da41e1618  vmovaps [rsp+0x20], xmm2
0000796da41e161e  vmovaps [rsp+0x30], xmm3
0000796da41e1624  vmovaps [rsp+0x40], xmm4
0000796da41e162a  vmovaps [rsp+0x50], xmm6
0000796da41e1630  vmovaps [rsp+0x60], xmm7
0000796da41e1636  vmovaps [rsp+0x70], xmm8
0000796da41e163c  vmovaps [rsp+0x80], xmm9
0000796da41e1645  vmovaps [rsp+0x90], xmm10
0000796da41e164e  vmovaps [rsp+0xA0], xmm11
0000796da41e1657  vmovaps [rsp+0xB0], xmm12
0000796da41e1660  vmovaps [rsp+0xC0], xmm13
0000796da41e1669  vmovaps [rsp+0xD0], xmm14
0000796da41e1672  vmovaps [rsp+0xE0], xmm15
0000796da41e167b  sub rsp, 0x30
0000796da41e167f  movaps [rsp], xmm5
0000796da41e1683  movaps [rsp+0x10], xmm6
0000796da41e1688  movaps [rsp+0x20], xmm3
0000796da41e168d  lea rdi, [rsp]
0000796da41e1691  mov esi, 0x00
0000796da41e1696  mov rax, 0x5E26CB66A530
0000796da41e16a0  call rax
0000796da41e16a2  movaps xmm5, [rsp]
0000796da41e16a6  add rsp, 0x30
0000796da41e16aa  vmovaps xmm0, [rsp]
0000796da41e16af  vmovaps xmm1, [rsp+0x10]
0000796da41e16b5  vmovaps xmm2, [rsp+0x20]
0000796da41e16bb  vmovaps xmm3, [rsp+0x30]
0000796da41e16c1  vmovaps xmm4, [rsp+0x40]
0000796da41e16c7  vmovaps xmm6, [rsp+0x50]
0000796da41e16cd  vmovaps xmm7, [rsp+0x60]
0000796da41e16d3  vmovaps xmm8, [rsp+0x70]
0000796da41e16d9  vmovaps xmm9, [rsp+0x80]
0000796da41e16e2  vmovaps xmm10, [rsp+0x90]
0000796da41e16eb  vmovaps xmm11, [rsp+0xA0]
0000796da41e16f4  vmovaps xmm12, [rsp+0xB0]
0000796da41e16fd  vmovaps xmm13, [rsp+0xC0]
0000796da41e1706  vmovaps xmm14, [rsp+0xD0]
0000796da41e170f  vmovaps xmm15, [rsp+0xE0]
0000796da41e1718  add rsp, 0xF0
0000796da41e171f  pop r11
0000796da41e1721  pop r10
0000796da41e1723  pop r9
0000796da41e1725  pop r8
0000796da41e1727  pop rsi
0000796da41e1728  pop rdi
0000796da41e1729  pop rdx
0000796da41e172a  pop rcx
0000796da41e172b  pop rax
0000796da41e172c  add rsp, 0x08
0000796da41e1730  jmp 0x0000796DA41DF31A
0000796da41e1735  sub rsp, 0x08
0000796da41e1739  push rax
0000796da41e173a  push rcx
0000796da41e173b  push rdx
0000796da41e173c  push rdi
0000796da41e173d  push rsi
0000796da41e173e  push r8
0000796da41e1740  push r9
0000796da41e1742  push r10
0000796da41e1744  push r11
0000796da41e1746  sub rsp, 0xF0
0000796da41e174d  vmovaps [rsp], xmm0
0000796da41e1752  vmovaps [rsp+0x10], xmm1
0000796da41e1758  vmovaps [rsp+0x20], xmm2
0000796da41e175e  vmovaps [rsp+0x30], xmm3
0000796da41e1764  vmovaps [rsp+0x40], xmm4
0000796da41e176a  vmovaps [rsp+0x50], xmm5
0000796da41e1770  vmovaps [rsp+0x60], xmm7
0000796da41e1776  vmovaps [rsp+0x70], xmm8
0000796da41e177c  vmovaps [rsp+0x80], xmm9
0000796da41e1785  vmovaps [rsp+0x90], xmm10
0000796da41e178e  vmovaps [rsp+0xA0], xmm11
0000796da41e1797  vmovaps [rsp+0xB0], xmm12
0000796da41e17a0  vmovaps [rsp+0xC0], xmm13
0000796da41e17a9  vmovaps [rsp+0xD0], xmm14
0000796da41e17b2  vmovaps [rsp+0xE0], xmm15
0000796da41e17bb  sub rsp, 0x30
0000796da41e17bf  movaps [rsp], xmm6
0000796da41e17c3  movaps [rsp+0x10], xmm9
0000796da41e17c9  movaps [rsp+0x20], xmm1
0000796da41e17ce  lea rdi, [rsp]
0000796da41e17d2  mov esi, 0x00
0000796da41e17d7  mov rax, 0x5E26CB66A530
0000796da41e17e1  call rax
0000796da41e17e3  movaps xmm6, [rsp]
0000796da41e17e7  add rsp, 0x30
0000796da41e17eb  vmovaps xmm0, [rsp]
0000796da41e17f0  vmovaps xmm1, [rsp+0x10]
0000796da41e17f6  vmovaps xmm2, [rsp+0x20]
0000796da41e17fc  vmovaps xmm3, [rsp+0x30]
0000796da41e1802  vmovaps xmm4, [rsp+0x40]
0000796da41e1808  vmovaps xmm5, [rsp+0x50]
0000796da41e180e  vmovaps xmm7, [rsp+0x60]
0000796da41e1814  vmovaps xmm8, [rsp+0x70]
0000796da41e181a  vmovaps xmm9, [rsp+0x80]
0000796da41e1823  vmovaps xmm10, [rsp+0x90]
0000796da41e182c  vmovaps xmm11, [rsp+0xA0]
0000796da41e1835  vmovaps xmm12, [rsp+0xB0]
0000796da41e183e  vmovaps xmm13, [rsp+0xC0]
0000796da41e1847  vmovaps xmm14, [rsp+0xD0]
0000796da41e1850  vmovaps xmm15, [rsp+0xE0]
0000796da41e1859  add rsp, 0xF0
0000796da41e1860  pop r11
0000796da41e1862  pop r10
0000796da41e1864  pop r9
0000796da41e1866  pop r8
0000796da41e1868  pop rsi
0000796da41e1869  pop rdi
0000796da41e186a  pop rdx
0000796da41e186b  pop rcx
0000796da41e186c  pop rax
0000796da41e186d  add rsp, 0x08
0000796da41e1871  jmp 0x0000796DA41DF33E
0000796da41e1876  sub rsp, 0x08
0000796da41e187a  push rax
0000796da41e187b  push rcx
0000796da41e187c  push rdx
0000796da41e187d  push rdi
0000796da41e187e  push rsi
0000796da41e187f  push r8
0000796da41e1881  push r9
0000796da41e1883  push r10
0000796da41e1885  push r11
0000796da41e1887  sub rsp, 0xF0
0000796da41e188e  vmovaps [rsp], xmm0
0000796da41e1893  vmovaps [rsp+0x10], xmm1
0000796da41e1899  vmovaps [rsp+0x20], xmm2
0000796da41e189f  vmovaps [rsp+0x30], xmm3
0000796da41e18a5  vmovaps [rsp+0x40], xmm4
0000796da41e18ab  vmovaps [rsp+0x50], xmm5
0000796da41e18b1  vmovaps [rsp+0x60], xmm6
0000796da41e18b7  vmovaps [rsp+0x70], xmm7
0000796da41e18bd  vmovaps [rsp+0x80], xmm8
0000796da41e18c6  vmovaps [rsp+0x90], xmm10
0000796da41e18cf  vmovaps [rsp+0xA0], xmm11
0000796da41e18d8  vmovaps [rsp+0xB0], xmm12
0000796da41e18e1  vmovaps [rsp+0xC0], xmm13
0000796da41e18ea  vmovaps [rsp+0xD0], xmm14
0000796da41e18f3  vmovaps [rsp+0xE0], xmm15
0000796da41e18fc  sub rsp, 0x30
0000796da41e1900  movaps [rsp], xmm9
0000796da41e1905  movaps [rsp+0x10], xmm3
0000796da41e190a  movaps [rsp+0x20], xmm1
0000796da41e190f  lea rdi, [rsp]
0000796da41e1913  mov esi, 0x00
0000796da41e1918  mov rax, 0x5E26CB66A530
0000796da41e1922  call rax
0000796da41e1924  movaps xmm9, [rsp]
0000796da41e1929  add rsp, 0x30
0000796da41e192d  vmovaps xmm0, [rsp]
0000796da41e1932  vmovaps xmm1, [rsp+0x10]
0000796da41e1938  vmovaps xmm2, [rsp+0x20]
0000796da41e193e  vmovaps xmm3, [rsp+0x30]
0000796da41e1944  vmovaps xmm4, [rsp+0x40]
0000796da41e194a  vmovaps xmm5, [rsp+0x50]
0000796da41e1950  vmovaps xmm6, [rsp+0x60]
0000796da41e1956  vmovaps xmm7, [rsp+0x70]
0000796da41e195c  vmovaps xmm8, [rsp+0x80]
0000796da41e1965  vmovaps xmm10, [rsp+0x90]
0000796da41e196e  vmovaps xmm11, [rsp+0xA0]
0000796da41e1977  vmovaps xmm12, [rsp+0xB0]
0000796da41e1980  vmovaps xmm13, [rsp+0xC0]
0000796da41e1989  vmovaps xmm14, [rsp+0xD0]
0000796da41e1992  vmovaps xmm15, [rsp+0xE0]
0000796da41e199b  add rsp, 0xF0
0000796da41e19a2  pop r11
0000796da41e19a4  pop r10
0000796da41e19a6  pop r9
0000796da41e19a8  pop r8
0000796da41e19aa  pop rsi
0000796da41e19ab  pop rdi
0000796da41e19ac  pop rdx
0000796da41e19ad  pop rcx
0000796da41e19ae  pop rax
0000796da41e19af  add rsp, 0x08
0000796da41e19b3  jmp 0x0000796DA41DF38A
0000796da41e19b8  call 0x0000796DA40B52F0
0000796da41e19bd  jmp 0x0000796DA41DF397
0000796da41e19c2  sub rsp, 0x08
0000796da41e19c6  push rax
0000796da41e19c7  push rcx
0000796da41e19c8  push rdx
0000796da41e19c9  push rdi
0000796da41e19ca  push rsi
0000796da41e19cb  push r8
0000796da41e19cd  push r9
0000796da41e19cf  push r10
0000796da41e19d1  push r11
0000796da41e19d3  sub rsp, 0xF0
0000796da41e19da  vmovaps [rsp], xmm0
0000796da41e19df  vmovaps [rsp+0x10], xmm1
0000796da41e19e5  vmovaps [rsp+0x20], xmm2
0000796da41e19eb  vmovaps [rsp+0x30], xmm3
0000796da41e19f1  vmovaps [rsp+0x40], xmm4
0000796da41e19f7  vmovaps [rsp+0x50], xmm5
0000796da41e19fd  vmovaps [rsp+0x60], xmm6
0000796da41e1a03  vmovaps [rsp+0x70], xmm7
0000796da41e1a09  vmovaps [rsp+0x80], xmm8
0000796da41e1a12  vmovaps [rsp+0x90], xmm9
0000796da41e1a1b  vmovaps [rsp+0xA0], xmm10
0000796da41e1a24  vmovaps [rsp+0xB0], xmm11
0000796da41e1a2d  vmovaps [rsp+0xC0], xmm12
0000796da41e1a36  vmovaps [rsp+0xD0], xmm13
0000796da41e1a3f  vmovaps [rsp+0xE0], xmm14
0000796da41e1a48  sub rsp, 0x30
0000796da41e1a4c  movaps [rsp], xmm15
0000796da41e1a51  movaps [rsp+0x10], xmm3
0000796da41e1a56  movaps [rsp+0x20], xmm7
0000796da41e1a5b  lea rdi, [rsp]
0000796da41e1a5f  mov esi, 0x00
0000796da41e1a64  mov rax, 0x5E26CB66A530
0000796da41e1a6e  call rax
0000796da41e1a70  movaps xmm15, [rsp]
0000796da41e1a75  add rsp, 0x30
0000796da41e1a79  vmovaps xmm0, [rsp]
0000796da41e1a7e  vmovaps xmm1, [rsp+0x10]
0000796da41e1a84  vmovaps xmm2, [rsp+0x20]
0000796da41e1a8a  vmovaps xmm3, [rsp+0x30]
0000796da41e1a90  vmovaps xmm4, [rsp+0x40]
0000796da41e1a96  vmovaps xmm5, [rsp+0x50]
0000796da41e1a9c  vmovaps xmm6, [rsp+0x60]
0000796da41e1aa2  vmovaps xmm7, [rsp+0x70]
0000796da41e1aa8  vmovaps xmm8, [rsp+0x80]
0000796da41e1ab1  vmovaps xmm9, [rsp+0x90]
0000796da41e1aba  vmovaps xmm10, [rsp+0xA0]
0000796da41e1ac3  vmovaps xmm11, [rsp+0xB0]
0000796da41e1acc  vmovaps xmm12, [rsp+0xC0]
0000796da41e1ad5  vmovaps xmm13, [rsp+0xD0]
0000796da41e1ade  vmovaps xmm14, [rsp+0xE0]
0000796da41e1ae7  add rsp, 0xF0
0000796da41e1aee  pop r11
0000796da41e1af0  pop r10
0000796da41e1af2  pop r9
0000796da41e1af4  pop r8
0000796da41e1af6  pop rsi
0000796da41e1af7  pop rdi
0000796da41e1af8  pop rdx
0000796da41e1af9  pop rcx
0000796da41e1afa  pop rax
0000796da41e1afb  add rsp, 0x08
0000796da41e1aff  jmp 0x0000796DA41DF3C3
0000796da41e1b04  sub rsp, 0x08
0000796da41e1b08  push rax
0000796da41e1b09  push rcx
0000796da41e1b0a  push rdx
0000796da41e1b0b  push rdi
0000796da41e1b0c  push rsi
0000796da41e1b0d  push r8
0000796da41e1b0f  push r9
0000796da41e1b11  push r10
0000796da41e1b13  push r11
0000796da41e1b15  sub rsp, 0xF0
0000796da41e1b1c  vmovaps [rsp], xmm0
0000796da41e1b21  vmovaps [rsp+0x10], xmm1
0000796da41e1b27  vmovaps [rsp+0x20], xmm2
0000796da41e1b2d  vmovaps [rsp+0x30], xmm4
0000796da41e1b33  vmovaps [rsp+0x40], xmm5
0000796da41e1b39  vmovaps [rsp+0x50], xmm6
0000796da41e1b3f  vmovaps [rsp+0x60], xmm7
0000796da41e1b45  vmovaps [rsp+0x70], xmm8
0000796da41e1b4b  vmovaps [rsp+0x80], xmm9
0000796da41e1b54  vmovaps [rsp+0x90], xmm10
0000796da41e1b5d  vmovaps [rsp+0xA0], xmm11
0000796da41e1b66  vmovaps [rsp+0xB0], xmm12
0000796da41e1b6f  vmovaps [rsp+0xC0], xmm13
0000796da41e1b78  vmovaps [rsp+0xD0], xmm14
0000796da41e1b81  vmovaps [rsp+0xE0], xmm15
0000796da41e1b8a  sub rsp, 0x30
0000796da41e1b8e  movaps [rsp], xmm3
0000796da41e1b92  movaps [rsp+0x10], xmm1
0000796da41e1b97  movaps [rsp+0x20], xmm15
0000796da41e1b9d  lea rdi, [rsp]
0000796da41e1ba1  mov esi, 0x00
0000796da41e1ba6  mov rax, 0x5E26CB66A530
0000796da41e1bb0  call rax
0000796da41e1bb2  movaps xmm3, [rsp]
0000796da41e1bb6  add rsp, 0x30
0000796da41e1bba  vmovaps xmm0, [rsp]
0000796da41e1bbf  vmovaps xmm1, [rsp+0x10]
0000796da41e1bc5  vmovaps xmm2, [rsp+0x20]
0000796da41e1bcb  vmovaps xmm4, [rsp+0x30]
0000796da41e1bd1  vmovaps xmm5, [rsp+0x40]
0000796da41e1bd7  vmovaps xmm6, [rsp+0x50]
0000796da41e1bdd  vmovaps xmm7, [rsp+0x60]
0000796da41e1be3  vmovaps xmm8, [rsp+0x70]
0000796da41e1be9  vmovaps xmm9, [rsp+0x80]
0000796da41e1bf2  vmovaps xmm10, [rsp+0x90]
0000796da41e1bfb  vmovaps xmm11, [rsp+0xA0]
0000796da41e1c04  vmovaps xmm12, [rsp+0xB0]
0000796da41e1c0d  vmovaps xmm13, [rsp+0xC0]
0000796da41e1c16  vmovaps xmm14, [rsp+0xD0]
0000796da41e1c1f  vmovaps xmm15, [rsp+0xE0]
0000796da41e1c28  add rsp, 0xF0
0000796da41e1c2f  pop r11
0000796da41e1c31  pop r10
0000796da41e1c33  pop r9
0000796da41e1c35  pop r8
0000796da41e1c37  pop rsi
0000796da41e1c38  pop rdi
0000796da41e1c39  pop rdx
0000796da41e1c3a  pop rcx
0000796da41e1c3b  pop rax
0000796da41e1c3c  add rsp, 0x08
0000796da41e1c40  jmp 0x0000796DA41DF452
0000796da41e1c45  call 0x0000796DA40B52F0
0000796da41e1c4a  jmp 0x0000796DA41DF45C
0000796da41e1c4f  sub rsp, 0x08
0000796da41e1c53  push rax
0000796da41e1c54  push rcx
0000796da41e1c55  push rdx
0000796da41e1c56  push rdi
0000796da41e1c57  push rsi
0000796da41e1c58  push r8
0000796da41e1c5a  push r9
0000796da41e1c5c  push r10
0000796da41e1c5e  push r11
0000796da41e1c60  sub rsp, 0xF0
0000796da41e1c67  vmovaps [rsp], xmm0
0000796da41e1c6c  vmovaps [rsp+0x10], xmm1
0000796da41e1c72  vmovaps [rsp+0x20], xmm2
0000796da41e1c78  vmovaps [rsp+0x30], xmm3
0000796da41e1c7e  vmovaps [rsp+0x40], xmm4
0000796da41e1c84  vmovaps [rsp+0x50], xmm5
0000796da41e1c8a  vmovaps [rsp+0x60], xmm6
0000796da41e1c90  vmovaps [rsp+0x70], xmm7
0000796da41e1c96  vmovaps [rsp+0x80], xmm8
0000796da41e1c9f  vmovaps [rsp+0x90], xmm9
0000796da41e1ca8  vmovaps [rsp+0xA0], xmm10
0000796da41e1cb1  vmovaps [rsp+0xB0], xmm11
0000796da41e1cba  vmovaps [rsp+0xC0], xmm12
0000796da41e1cc3  vmovaps [rsp+0xD0], xmm13
0000796da41e1ccc  vmovaps [rsp+0xE0], xmm14
0000796da41e1cd5  sub rsp, 0x30
0000796da41e1cd9  movaps [rsp], xmm15
0000796da41e1cde  movaps [rsp+0x10], xmm14
0000796da41e1ce4  movaps [rsp+0x20], xmm4
0000796da41e1ce9  lea rdi, [rsp]
0000796da41e1ced  mov esi, 0x00
0000796da41e1cf2  mov rax, 0x5E26CB66A530
0000796da41e1cfc  call rax
0000796da41e1cfe  movaps xmm15, [rsp]
0000796da41e1d03  add rsp, 0x30
0000796da41e1d07  vmovaps xmm0, [rsp]
0000796da41e1d0c  vmovaps xmm1, [rsp+0x10]
0000796da41e1d12  vmovaps xmm2, [rsp+0x20]
0000796da41e1d18  vmovaps xmm3, [rsp+0x30]
0000796da41e1d1e  vmovaps xmm4, [rsp+0x40]
0000796da41e1d24  vmovaps xmm5, [rsp+0x50]
0000796da41e1d2a  vmovaps xmm6, [rsp+0x60]
0000796da41e1d30  vmovaps xmm7, [rsp+0x70]
0000796da41e1d36  vmovaps xmm8, [rsp+0x80]
0000796da41e1d3f  vmovaps xmm9, [rsp+0x90]
0000796da41e1d48  vmovaps xmm10, [rsp+0xA0]
0000796da41e1d51  vmovaps xmm11, [rsp+0xB0]
0000796da41e1d5a  vmovaps xmm12, [rsp+0xC0]
0000796da41e1d63  vmovaps xmm13, [rsp+0xD0]
0000796da41e1d6c  vmovaps xmm14, [rsp+0xE0]
0000796da41e1d75  add rsp, 0xF0
0000796da41e1d7c  pop r11
0000796da41e1d7e  pop r10
0000796da41e1d80  pop r9
0000796da41e1d82  pop r8
0000796da41e1d84  pop rsi
0000796da41e1d85  pop rdi
0000796da41e1d86  pop rdx
0000796da41e1d87  pop rcx
0000796da41e1d88  pop rax
0000796da41e1d89  add rsp, 0x08
0000796da41e1d8d  jmp 0x0000796DA41DF48A
0000796da41e1d92  sub rsp, 0x08
0000796da41e1d96  push rax
0000796da41e1d97  push rcx
0000796da41e1d98  push rdx
0000796da41e1d99  push rdi
0000796da41e1d9a  push rsi
0000796da41e1d9b  push r8
0000796da41e1d9d  push r9
0000796da41e1d9f  push r10
0000796da41e1da1  push r11
0000796da41e1da3  sub rsp, 0xF0
0000796da41e1daa  vmovaps [rsp], xmm0
0000796da41e1daf  vmovaps [rsp+0x10], xmm1
0000796da41e1db5  vmovaps [rsp+0x20], xmm2
0000796da41e1dbb  vmovaps [rsp+0x30], xmm3
0000796da41e1dc1  vmovaps [rsp+0x40], xmm4
0000796da41e1dc7  vmovaps [rsp+0x50], xmm5
0000796da41e1dcd  vmovaps [rsp+0x60], xmm6
0000796da41e1dd3  vmovaps [rsp+0x70], xmm7
0000796da41e1dd9  vmovaps [rsp+0x80], xmm8
0000796da41e1de2  vmovaps [rsp+0x90], xmm9
0000796da41e1deb  vmovaps [rsp+0xA0], xmm10
0000796da41e1df4  vmovaps [rsp+0xB0], xmm11
0000796da41e1dfd  vmovaps [rsp+0xC0], xmm12
0000796da41e1e06  vmovaps [rsp+0xD0], xmm13
0000796da41e1e0f  vmovaps [rsp+0xE0], xmm15
0000796da41e1e18  sub rsp, 0x30
0000796da41e1e1c  movaps [rsp], xmm14
0000796da41e1e21  movaps [rsp+0x10], xmm2
0000796da41e1e26  movaps [rsp+0x20], xmm1
0000796da41e1e2b  lea rdi, [rsp]
0000796da41e1e2f  mov esi, 0x00
0000796da41e1e34  mov rax, 0x5E26CB66A530
0000796da41e1e3e  call rax
0000796da41e1e40  movaps xmm14, [rsp]
0000796da41e1e45  add rsp, 0x30
0000796da41e1e49  vmovaps xmm0, [rsp]
0000796da41e1e4e  vmovaps xmm1, [rsp+0x10]
0000796da41e1e54  vmovaps xmm2, [rsp+0x20]
0000796da41e1e5a  vmovaps xmm3, [rsp+0x30]
0000796da41e1e60  vmovaps xmm4, [rsp+0x40]
0000796da41e1e66  vmovaps xmm5, [rsp+0x50]
0000796da41e1e6c  vmovaps xmm6, [rsp+0x60]
0000796da41e1e72  vmovaps xmm7, [rsp+0x70]
0000796da41e1e78  vmovaps xmm8, [rsp+0x80]
0000796da41e1e81  vmovaps xmm9, [rsp+0x90]
0000796da41e1e8a  vmovaps xmm10, [rsp+0xA0]
0000796da41e1e93  vmovaps xmm11, [rsp+0xB0]
0000796da41e1e9c  vmovaps xmm12, [rsp+0xC0]
0000796da41e1ea5  vmovaps xmm13, [rsp+0xD0]
0000796da41e1eae  vmovaps xmm15, [rsp+0xE0]
0000796da41e1eb7  add rsp, 0xF0
0000796da41e1ebe  pop r11
0000796da41e1ec0  pop r10
0000796da41e1ec2  pop r9
0000796da41e1ec4  pop r8
0000796da41e1ec6  pop rsi
0000796da41e1ec7  pop rdi
0000796da41e1ec8  pop rdx
0000796da41e1ec9  pop rcx
0000796da41e1eca  pop rax
0000796da41e1ecb  add rsp, 0x08
0000796da41e1ecf  jmp 0x0000796DA41DF4B0
0000796da41e1ed4  sub rsp, 0x08
0000796da41e1ed8  push rax
0000796da41e1ed9  push rcx
0000796da41e1eda  push rdx
0000796da41e1edb  push rdi
0000796da41e1edc  push rsi
0000796da41e1edd  push r8
0000796da41e1edf  push r9
0000796da41e1ee1  push r10
0000796da41e1ee3  push r11
0000796da41e1ee5  sub rsp, 0xF0
0000796da41e1eec  vmovaps [rsp], xmm0
0000796da41e1ef1  vmovaps [rsp+0x10], xmm2
0000796da41e1ef7  vmovaps [rsp+0x20], xmm3
0000796da41e1efd  vmovaps [rsp+0x30], xmm4
0000796da41e1f03  vmovaps [rsp+0x40], xmm5
0000796da41e1f09  vmovaps [rsp+0x50], xmm6
0000796da41e1f0f  vmovaps [rsp+0x60], xmm7
0000796da41e1f15  vmovaps [rsp+0x70], xmm8
0000796da41e1f1b  vmovaps [rsp+0x80], xmm9
0000796da41e1f24  vmovaps [rsp+0x90], xmm10
0000796da41e1f2d  vmovaps [rsp+0xA0], xmm11
0000796da41e1f36  vmovaps [rsp+0xB0], xmm12
0000796da41e1f3f  vmovaps [rsp+0xC0], xmm13
0000796da41e1f48  vmovaps [rsp+0xD0], xmm14
0000796da41e1f51  vmovaps [rsp+0xE0], xmm15
0000796da41e1f5a  sub rsp, 0x30
0000796da41e1f5e  movaps [rsp], xmm1
0000796da41e1f62  movaps [rsp+0x10], xmm4
0000796da41e1f67  movaps [rsp+0x20], xmm9
0000796da41e1f6d  lea rdi, [rsp]
0000796da41e1f71  mov esi, 0x00
0000796da41e1f76  mov rax, 0x5E26CB66A530
0000796da41e1f80  call rax
0000796da41e1f82  movaps xmm1, [rsp]
0000796da41e1f86  add rsp, 0x30
0000796da41e1f8a  vmovaps xmm0, [rsp]
0000796da41e1f8f  vmovaps xmm2, [rsp+0x10]
0000796da41e1f95  vmovaps xmm3, [rsp+0x20]
0000796da41e1f9b  vmovaps xmm4, [rsp+0x30]
0000796da41e1fa1  vmovaps xmm5, [rsp+0x40]
0000796da41e1fa7  vmovaps xmm6, [rsp+0x50]
0000796da41e1fad  vmovaps xmm7, [rsp+0x60]
0000796da41e1fb3  vmovaps xmm8, [rsp+0x70]
0000796da41e1fb9  vmovaps xmm9, [rsp+0x80]
0000796da41e1fc2  vmovaps xmm10, [rsp+0x90]
0000796da41e1fcb  vmovaps xmm11, [rsp+0xA0]
0000796da41e1fd4  vmovaps xmm12, [rsp+0xB0]
0000796da41e1fdd  vmovaps xmm13, [rsp+0xC0]
0000796da41e1fe6  vmovaps xmm14, [rsp+0xD0]
0000796da41e1fef  vmovaps xmm15, [rsp+0xE0]
0000796da41e1ff8  add rsp, 0xF0
0000796da41e1fff  pop r11
0000796da41e2001  pop r10
0000796da41e2003  pop r9
0000796da41e2005  pop r8
0000796da41e2007  pop rsi
0000796da41e2008  pop rdi
0000796da41e2009  pop rdx
0000796da41e200a  pop rcx
0000796da41e200b  pop rax
0000796da41e200c  add rsp, 0x08
0000796da41e2010  jmp 0x0000796DA41DF4CE
0000796da41e2015  sub rsp, 0x08
0000796da41e2019  push rax
0000796da41e201a  push rcx
0000796da41e201b  push rdx
0000796da41e201c  push rdi
0000796da41e201d  push rsi
0000796da41e201e  push r8
0000796da41e2020  push r9
0000796da41e2022  push r10
0000796da41e2024  push r11
0000796da41e2026  sub rsp, 0xF0
0000796da41e202d  vmovaps [rsp], xmm0
0000796da41e2032  vmovaps [rsp+0x10], xmm1
0000796da41e2038  vmovaps [rsp+0x20], xmm2
0000796da41e203e  vmovaps [rsp+0x30], xmm3
0000796da41e2044  vmovaps [rsp+0x40], xmm5
0000796da41e204a  vmovaps [rsp+0x50], xmm6
0000796da41e2050  vmovaps [rsp+0x60], xmm7
0000796da41e2056  vmovaps [rsp+0x70], xmm8
0000796da41e205c  vmovaps [rsp+0x80], xmm9
0000796da41e2065  vmovaps [rsp+0x90], xmm10
0000796da41e206e  vmovaps [rsp+0xA0], xmm11
0000796da41e2077  vmovaps [rsp+0xB0], xmm12
0000796da41e2080  vmovaps [rsp+0xC0], xmm13
0000796da41e2089  vmovaps [rsp+0xD0], xmm14
0000796da41e2092  vmovaps [rsp+0xE0], xmm15
0000796da41e209b  sub rsp, 0x30
0000796da41e209f  movaps [rsp], xmm4
0000796da41e20a3  movaps [rsp+0x10], xmm2
0000796da41e20a8  movaps [rsp+0x20], xmm9
0000796da41e20ae  lea rdi, [rsp]
0000796da41e20b2  mov esi, 0x00
0000796da41e20b7  mov rax, 0x5E26CB66A530
0000796da41e20c1  call rax
0000796da41e20c3  movaps xmm4, [rsp]
0000796da41e20c7  add rsp, 0x30
0000796da41e20cb  vmovaps xmm0, [rsp]
0000796da41e20d0  vmovaps xmm1, [rsp+0x10]
0000796da41e20d6  vmovaps xmm2, [rsp+0x20]
0000796da41e20dc  vmovaps xmm3, [rsp+0x30]
0000796da41e20e2  vmovaps xmm5, [rsp+0x40]
0000796da41e20e8  vmovaps xmm6, [rsp+0x50]
0000796da41e20ee  vmovaps xmm7, [rsp+0x60]
0000796da41e20f4  vmovaps xmm8, [rsp+0x70]
0000796da41e20fa  vmovaps xmm9, [rsp+0x80]
0000796da41e2103  vmovaps xmm10, [rsp+0x90]
0000796da41e210c  vmovaps xmm11, [rsp+0xA0]
0000796da41e2115  vmovaps xmm12, [rsp+0xB0]
0000796da41e211e  vmovaps xmm13, [rsp+0xC0]
0000796da41e2127  vmovaps xmm14, [rsp+0xD0]
0000796da41e2130  vmovaps xmm15, [rsp+0xE0]
0000796da41e2139  add rsp, 0xF0
0000796da41e2140  pop r11
0000796da41e2142  pop r10
0000796da41e2144  pop r9
0000796da41e2146  pop r8
0000796da41e2148  pop rsi
0000796da41e2149  pop rdi
0000796da41e214a  pop rdx
0000796da41e214b  pop rcx
0000796da41e214c  pop rax
0000796da41e214d  add rsp, 0x08
0000796da41e2151  jmp 0x0000796DA41DF4FE
0000796da41e2156  sub rsp, 0x08
0000796da41e215a  push rax
0000796da41e215b  push rcx
0000796da41e215c  push rdx
0000796da41e215d  push rdi
0000796da41e215e  push rsi
0000796da41e215f  push r8
0000796da41e2161  push r9
0000796da41e2163  push r10
0000796da41e2165  push r11
0000796da41e2167  sub rsp, 0xF0
0000796da41e216e  vmovaps [rsp], xmm0
0000796da41e2173  vmovaps [rsp+0x10], xmm1
0000796da41e2179  vmovaps [rsp+0x20], xmm2
0000796da41e217f  vmovaps [rsp+0x30], xmm3
0000796da41e2185  vmovaps [rsp+0x40], xmm4
0000796da41e218b  vmovaps [rsp+0x50], xmm5
0000796da41e2191  vmovaps [rsp+0x60], xmm6
0000796da41e2197  vmovaps [rsp+0x70], xmm7
0000796da41e219d  vmovaps [rsp+0x80], xmm8
0000796da41e21a6  vmovaps [rsp+0x90], xmm10
0000796da41e21af  vmovaps [rsp+0xA0], xmm11
0000796da41e21b8  vmovaps [rsp+0xB0], xmm12
0000796da41e21c1  vmovaps [rsp+0xC0], xmm13
0000796da41e21ca  vmovaps [rsp+0xD0], xmm14
0000796da41e21d3  vmovaps [rsp+0xE0], xmm15
0000796da41e21dc  sub rsp, 0x30
0000796da41e21e0  movaps [rsp], xmm9
0000796da41e21e5  movaps [rsp+0x10], xmm2
0000796da41e21ea  movaps [rsp+0x20], xmm1
0000796da41e21ef  lea rdi, [rsp]
0000796da41e21f3  mov esi, 0x00
0000796da41e21f8  mov rax, 0x5E26CB66A530
0000796da41e2202  call rax
0000796da41e2204  movaps xmm9, [rsp]
0000796da41e2209  add rsp, 0x30
0000796da41e220d  vmovaps xmm0, [rsp]
0000796da41e2212  vmovaps xmm1, [rsp+0x10]
0000796da41e2218  vmovaps xmm2, [rsp+0x20]
0000796da41e221e  vmovaps xmm3, [rsp+0x30]
0000796da41e2224  vmovaps xmm4, [rsp+0x40]
0000796da41e222a  vmovaps xmm5, [rsp+0x50]
0000796da41e2230  vmovaps xmm6, [rsp+0x60]
0000796da41e2236  vmovaps xmm7, [rsp+0x70]
0000796da41e223c  vmovaps xmm8, [rsp+0x80]
0000796da41e2245  vmovaps xmm10, [rsp+0x90]
0000796da41e224e  vmovaps xmm11, [rsp+0xA0]
0000796da41e2257  vmovaps xmm12, [rsp+0xB0]
0000796da41e2260  vmovaps xmm13, [rsp+0xC0]
0000796da41e2269  vmovaps xmm14, [rsp+0xD0]
0000796da41e2272  vmovaps xmm15, [rsp+0xE0]
0000796da41e227b  add rsp, 0xF0
0000796da41e2282  pop r11
0000796da41e2284  pop r10
0000796da41e2286  pop r9
0000796da41e2288  pop r8
0000796da41e228a  pop rsi
0000796da41e228b  pop rdi
0000796da41e228c  pop rdx
0000796da41e228d  pop rcx
0000796da41e228e  pop rax
0000796da41e228f  add rsp, 0x08
0000796da41e2293  jmp 0x0000796DA41DF534
0000796da41e2298  sub rsp, 0x08
0000796da41e229c  push rax
0000796da41e229d  push rcx
0000796da41e229e  push rdx
0000796da41e229f  push rdi
0000796da41e22a0  push rsi
0000796da41e22a1  push r8
0000796da41e22a3  push r9
0000796da41e22a5  push r10
0000796da41e22a7  push r11
0000796da41e22a9  sub rsp, 0xF0
0000796da41e22b0  vmovaps [rsp], xmm0
0000796da41e22b5  vmovaps [rsp+0x10], xmm2
0000796da41e22bb  vmovaps [rsp+0x20], xmm3
0000796da41e22c1  vmovaps [rsp+0x30], xmm4
0000796da41e22c7  vmovaps [rsp+0x40], xmm5
0000796da41e22cd  vmovaps [rsp+0x50], xmm6
0000796da41e22d3  vmovaps [rsp+0x60], xmm7
0000796da41e22d9  vmovaps [rsp+0x70], xmm8
0000796da41e22df  vmovaps [rsp+0x80], xmm9
0000796da41e22e8  vmovaps [rsp+0x90], xmm10
0000796da41e22f1  vmovaps [rsp+0xA0], xmm11
0000796da41e22fa  vmovaps [rsp+0xB0], xmm12
0000796da41e2303  vmovaps [rsp+0xC0], xmm13
0000796da41e230c  vmovaps [rsp+0xD0], xmm14
0000796da41e2315  vmovaps [rsp+0xE0], xmm15
0000796da41e231e  sub rsp, 0x30
0000796da41e2322  movaps [rsp], xmm1
0000796da41e2326  movaps [rsp+0x10], xmm15
0000796da41e232c  movaps [rsp+0x20], xmm6
0000796da41e2331  lea rdi, [rsp]
0000796da41e2335  mov esi, 0x00
0000796da41e233a  mov rax, 0x5E26CB66A530
0000796da41e2344  call rax
0000796da41e2346  movaps xmm1, [rsp]
0000796da41e234a  add rsp, 0x30
0000796da41e234e  vmovaps xmm0, [rsp]
0000796da41e2353  vmovaps xmm2, [rsp+0x10]
0000796da41e2359  vmovaps xmm3, [rsp+0x20]
0000796da41e235f  vmovaps xmm4, [rsp+0x30]
0000796da41e2365  vmovaps xmm5, [rsp+0x40]
0000796da41e236b  vmovaps xmm6, [rsp+0x50]
0000796da41e2371  vmovaps xmm7, [rsp+0x60]
0000796da41e2377  vmovaps xmm8, [rsp+0x70]
0000796da41e237d  vmovaps xmm9, [rsp+0x80]
0000796da41e2386  vmovaps xmm10, [rsp+0x90]
0000796da41e238f  vmovaps xmm11, [rsp+0xA0]
0000796da41e2398  vmovaps xmm12, [rsp+0xB0]
0000796da41e23a1  vmovaps xmm13, [rsp+0xC0]
0000796da41e23aa  vmovaps xmm14, [rsp+0xD0]
0000796da41e23b3  vmovaps xmm15, [rsp+0xE0]
0000796da41e23bc  add rsp, 0xF0
0000796da41e23c3  pop r11
0000796da41e23c5  pop r10
0000796da41e23c7  pop r9
0000796da41e23c9  pop r8
0000796da41e23cb  pop rsi
0000796da41e23cc  pop rdi
0000796da41e23cd  pop rdx
0000796da41e23ce  pop rcx
0000796da41e23cf  pop rax
0000796da41e23d0  add rsp, 0x08
0000796da41e23d4  jmp 0x0000796DA41DF555
0000796da41e23d9  sub rsp, 0x08
0000796da41e23dd  push rax
0000796da41e23de  push rcx
0000796da41e23df  push rdx
0000796da41e23e0  push rdi
0000796da41e23e1  push rsi
0000796da41e23e2  push r8
0000796da41e23e4  push r9
0000796da41e23e6  push r10
0000796da41e23e8  push r11
0000796da41e23ea  sub rsp, 0xF0
0000796da41e23f1  vmovaps [rsp], xmm0
0000796da41e23f6  vmovaps [rsp+0x10], xmm1
0000796da41e23fc  vmovaps [rsp+0x20], xmm2
0000796da41e2402  vmovaps [rsp+0x30], xmm3
0000796da41e2408  vmovaps [rsp+0x40], xmm4
0000796da41e240e  vmovaps [rsp+0x50], xmm5
0000796da41e2414  vmovaps [rsp+0x60], xmm6
0000796da41e241a  vmovaps [rsp+0x70], xmm7
0000796da41e2420  vmovaps [rsp+0x80], xmm8
0000796da41e2429  vmovaps [rsp+0x90], xmm9
0000796da41e2432  vmovaps [rsp+0xA0], xmm10
0000796da41e243b  vmovaps [rsp+0xB0], xmm11
0000796da41e2444  vmovaps [rsp+0xC0], xmm12
0000796da41e244d  vmovaps [rsp+0xD0], xmm13
0000796da41e2456  vmovaps [rsp+0xE0], xmm14
0000796da41e245f  sub rsp, 0x30
0000796da41e2463  movaps [rsp], xmm15
0000796da41e2468  movaps [rsp+0x10], xmm5
0000796da41e246d  movaps [rsp+0x20], xmm3
0000796da41e2472  lea rdi, [rsp]
0000796da41e2476  mov esi, 0x00
0000796da41e247b  mov rax, 0x5E26CB66A530
0000796da41e2485  call rax
0000796da41e2487  movaps xmm15, [rsp]
0000796da41e248c  add rsp, 0x30
0000796da41e2490  vmovaps xmm0, [rsp]
0000796da41e2495  vmovaps xmm1, [rsp+0x10]
0000796da41e249b  vmovaps xmm2, [rsp+0x20]
0000796da41e24a1  vmovaps xmm3, [rsp+0x30]
0000796da41e24a7  vmovaps xmm4, [rsp+0x40]
0000796da41e24ad  vmovaps xmm5, [rsp+0x50]
0000796da41e24b3  vmovaps xmm6, [rsp+0x60]
0000796da41e24b9  vmovaps xmm7, [rsp+0x70]
0000796da41e24bf  vmovaps xmm8, [rsp+0x80]
0000796da41e24c8  vmovaps xmm9, [rsp+0x90]
0000796da41e24d1  vmovaps xmm10, [rsp+0xA0]
0000796da41e24da  vmovaps xmm11, [rsp+0xB0]
0000796da41e24e3  vmovaps xmm12, [rsp+0xC0]
0000796da41e24ec  vmovaps xmm13, [rsp+0xD0]
0000796da41e24f5  vmovaps xmm14, [rsp+0xE0]
0000796da41e24fe  add rsp, 0xF0
0000796da41e2505  pop r11
0000796da41e2507  pop r10
0000796da41e2509  pop r9
0000796da41e250b  pop r8
0000796da41e250d  pop rsi
0000796da41e250e  pop rdi
0000796da41e250f  pop rdx
0000796da41e2510  pop rcx
0000796da41e2511  pop rax
0000796da41e2512  add rsp, 0x08
0000796da41e2516  jmp 0x0000796DA41DF56F
0000796da41e251b  sub rsp, 0x08
0000796da41e251f  push rax
0000796da41e2520  push rcx
0000796da41e2521  push rdx
0000796da41e2522  push rdi
0000796da41e2523  push rsi
0000796da41e2524  push r8
0000796da41e2526  push r9
0000796da41e2528  push r10
0000796da41e252a  push r11
0000796da41e252c  sub rsp, 0xF0
0000796da41e2533  vmovaps [rsp], xmm0
0000796da41e2538  vmovaps [rsp+0x10], xmm1
0000796da41e253e  vmovaps [rsp+0x20], xmm2
0000796da41e2544  vmovaps [rsp+0x30], xmm3
0000796da41e254a  vmovaps [rsp+0x40], xmm4
0000796da41e2550  vmovaps [rsp+0x50], xmm6
0000796da41e2556  vmovaps [rsp+0x60], xmm7
0000796da41e255c  vmovaps [rsp+0x70], xmm8
0000796da41e2562  vmovaps [rsp+0x80], xmm9
0000796da41e256b  vmovaps [rsp+0x90], xmm10
0000796da41e2574  vmovaps [rsp+0xA0], xmm11
0000796da41e257d  vmovaps [rsp+0xB0], xmm12
0000796da41e2586  vmovaps [rsp+0xC0], xmm13
0000796da41e258f  vmovaps [rsp+0xD0], xmm14
0000796da41e2598  vmovaps [rsp+0xE0], xmm15
0000796da41e25a1  sub rsp, 0x30
0000796da41e25a5  movaps [rsp], xmm5
0000796da41e25a9  movaps [rsp+0x10], xmm8
0000796da41e25af  movaps [rsp+0x20], xmm6
0000796da41e25b4  lea rdi, [rsp]
0000796da41e25b8  mov esi, 0x00
0000796da41e25bd  mov rax, 0x5E26CB66A530
0000796da41e25c7  call rax
0000796da41e25c9  movaps xmm5, [rsp]
0000796da41e25cd  add rsp, 0x30
0000796da41e25d1  vmovaps xmm0, [rsp]
0000796da41e25d6  vmovaps xmm1, [rsp+0x10]
0000796da41e25dc  vmovaps xmm2, [rsp+0x20]
0000796da41e25e2  vmovaps xmm3, [rsp+0x30]
0000796da41e25e8  vmovaps xmm4, [rsp+0x40]
0000796da41e25ee  vmovaps xmm6, [rsp+0x50]
0000796da41e25f4  vmovaps xmm7, [rsp+0x60]
0000796da41e25fa  vmovaps xmm8, [rsp+0x70]
0000796da41e2600  vmovaps xmm9, [rsp+0x80]
0000796da41e2609  vmovaps xmm10, [rsp+0x90]
0000796da41e2612  vmovaps xmm11, [rsp+0xA0]
0000796da41e261b  vmovaps xmm12, [rsp+0xB0]
0000796da41e2624  vmovaps xmm13, [rsp+0xC0]
0000796da41e262d  vmovaps xmm14, [rsp+0xD0]
0000796da41e2636  vmovaps xmm15, [rsp+0xE0]
0000796da41e263f  add rsp, 0xF0
0000796da41e2646  pop r11
0000796da41e2648  pop r10
0000796da41e264a  pop r9
0000796da41e264c  pop r8
0000796da41e264e  pop rsi
0000796da41e264f  pop rdi
0000796da41e2650  pop rdx
0000796da41e2651  pop rcx
0000796da41e2652  pop rax
0000796da41e2653  add rsp, 0x08
0000796da41e2657  jmp 0x0000796DA41DF593
0000796da41e265c  sub rsp, 0x08
0000796da41e2660  push rax
0000796da41e2661  push rcx
0000796da41e2662  push rdx
0000796da41e2663  push rdi
0000796da41e2664  push rsi
0000796da41e2665  push r8
0000796da41e2667  push r9
0000796da41e2669  push r10
0000796da41e266b  push r11
0000796da41e266d  sub rsp, 0xF0
0000796da41e2674  vmovaps [rsp], xmm0
0000796da41e2679  vmovaps [rsp+0x10], xmm1
0000796da41e267f  vmovaps [rsp+0x20], xmm2
0000796da41e2685  vmovaps [rsp+0x30], xmm3
0000796da41e268b  vmovaps [rsp+0x40], xmm4
0000796da41e2691  vmovaps [rsp+0x50], xmm5
0000796da41e2697  vmovaps [rsp+0x60], xmm7
0000796da41e269d  vmovaps [rsp+0x70], xmm8
0000796da41e26a3  vmovaps [rsp+0x80], xmm9
0000796da41e26ac  vmovaps [rsp+0x90], xmm10
0000796da41e26b5  vmovaps [rsp+0xA0], xmm11
0000796da41e26be  vmovaps [rsp+0xB0], xmm12
0000796da41e26c7  vmovaps [rsp+0xC0], xmm13
0000796da41e26d0  vmovaps [rsp+0xD0], xmm14
0000796da41e26d9  vmovaps [rsp+0xE0], xmm15
0000796da41e26e2  sub rsp, 0x30
0000796da41e26e6  movaps [rsp], xmm6
0000796da41e26ea  movaps [rsp+0x10], xmm10
0000796da41e26f0  movaps [rsp+0x20], xmm8
0000796da41e26f6  lea rdi, [rsp]
0000796da41e26fa  mov esi, 0x00
0000796da41e26ff  mov rax, 0x5E26CB66A530
0000796da41e2709  call rax
0000796da41e270b  movaps xmm6, [rsp]
0000796da41e270f  add rsp, 0x30
0000796da41e2713  vmovaps xmm0, [rsp]
0000796da41e2718  vmovaps xmm1, [rsp+0x10]
0000796da41e271e  vmovaps xmm2, [rsp+0x20]
0000796da41e2724  vmovaps xmm3, [rsp+0x30]
0000796da41e272a  vmovaps xmm4, [rsp+0x40]
0000796da41e2730  vmovaps xmm5, [rsp+0x50]
0000796da41e2736  vmovaps xmm7, [rsp+0x60]
0000796da41e273c  vmovaps xmm8, [rsp+0x70]
0000796da41e2742  vmovaps xmm9, [rsp+0x80]
0000796da41e274b  vmovaps xmm10, [rsp+0x90]
0000796da41e2754  vmovaps xmm11, [rsp+0xA0]
0000796da41e275d  vmovaps xmm12, [rsp+0xB0]
0000796da41e2766  vmovaps xmm13, [rsp+0xC0]
0000796da41e276f  vmovaps xmm14, [rsp+0xD0]
0000796da41e2778  vmovaps xmm15, [rsp+0xE0]
0000796da41e2781  add rsp, 0xF0
0000796da41e2788  pop r11
0000796da41e278a  pop r10
0000796da41e278c  pop r9
0000796da41e278e  pop r8
0000796da41e2790  pop rsi
0000796da41e2791  pop rdi
0000796da41e2792  pop rdx
0000796da41e2793  pop rcx
0000796da41e2794  pop rax
0000796da41e2795  add rsp, 0x08
0000796da41e2799  jmp 0x0000796DA41DF5B8
0000796da41e279e  sub rsp, 0x08
0000796da41e27a2  push rax
0000796da41e27a3  push rcx
0000796da41e27a4  push rdx
0000796da41e27a5  push rdi
0000796da41e27a6  push rsi
0000796da41e27a7  push r8
0000796da41e27a9  push r9
0000796da41e27ab  push r10
0000796da41e27ad  push r11
0000796da41e27af  sub rsp, 0xF0
0000796da41e27b6  vmovaps [rsp], xmm0
0000796da41e27bb  vmovaps [rsp+0x10], xmm1
0000796da41e27c1  vmovaps [rsp+0x20], xmm2
0000796da41e27c7  vmovaps [rsp+0x30], xmm3
0000796da41e27cd  vmovaps [rsp+0x40], xmm4
0000796da41e27d3  vmovaps [rsp+0x50], xmm5
0000796da41e27d9  vmovaps [rsp+0x60], xmm6
0000796da41e27df  vmovaps [rsp+0x70], xmm7
0000796da41e27e5  vmovaps [rsp+0x80], xmm8
0000796da41e27ee  vmovaps [rsp+0x90], xmm9
0000796da41e27f7  vmovaps [rsp+0xA0], xmm11
0000796da41e2800  vmovaps [rsp+0xB0], xmm12
0000796da41e2809  vmovaps [rsp+0xC0], xmm13
0000796da41e2812  vmovaps [rsp+0xD0], xmm14
0000796da41e281b  vmovaps [rsp+0xE0], xmm15
0000796da41e2824  sub rsp, 0x30
0000796da41e2828  movaps [rsp], xmm10
0000796da41e282d  movaps [rsp+0x10], xmm8
0000796da41e2833  movaps [rsp+0x20], xmm14
0000796da41e2839  lea rdi, [rsp]
0000796da41e283d  mov esi, 0x00
0000796da41e2842  mov rax, 0x5E26CB66A530
0000796da41e284c  call rax
0000796da41e284e  movaps xmm10, [rsp]
0000796da41e2853  add rsp, 0x30
0000796da41e2857  vmovaps xmm0, [rsp]
0000796da41e285c  vmovaps xmm1, [rsp+0x10]
0000796da41e2862  vmovaps xmm2, [rsp+0x20]
0000796da41e2868  vmovaps xmm3, [rsp+0x30]
0000796da41e286e  vmovaps xmm4, [rsp+0x40]
0000796da41e2874  vmovaps xmm5, [rsp+0x50]
0000796da41e287a  vmovaps xmm6, [rsp+0x60]
0000796da41e2880  vmovaps xmm7, [rsp+0x70]
0000796da41e2886  vmovaps xmm8, [rsp+0x80]
0000796da41e288f  vmovaps xmm9, [rsp+0x90]
0000796da41e2898  vmovaps xmm11, [rsp+0xA0]
0000796da41e28a1  vmovaps xmm12, [rsp+0xB0]
0000796da41e28aa  vmovaps xmm13, [rsp+0xC0]
0000796da41e28b3  vmovaps xmm14, [rsp+0xD0]
0000796da41e28bc  vmovaps xmm15, [rsp+0xE0]
0000796da41e28c5  add rsp, 0xF0
0000796da41e28cc  pop r11
0000796da41e28ce  pop r10
0000796da41e28d0  pop r9
0000796da41e28d2  pop r8
0000796da41e28d4  pop rsi
0000796da41e28d5  pop rdi
0000796da41e28d6  pop rdx
0000796da41e28d7  pop rcx
0000796da41e28d8  pop rax
0000796da41e28d9  add rsp, 0x08
0000796da41e28dd  jmp 0x0000796DA41DF5D8
0000796da41e28e2  sub rsp, 0x08
0000796da41e28e6  push rax
0000796da41e28e7  push rcx
0000796da41e28e8  push rdx
0000796da41e28e9  push rdi
0000796da41e28ea  push rsi
0000796da41e28eb  push r8
0000796da41e28ed  push r9
0000796da41e28ef  push r10
0000796da41e28f1  push r11
0000796da41e28f3  sub rsp, 0xF0
0000796da41e28fa  vmovaps [rsp], xmm0
0000796da41e28ff  vmovaps [rsp+0x10], xmm1
0000796da41e2905  vmovaps [rsp+0x20], xmm2
0000796da41e290b  vmovaps [rsp+0x30], xmm3
0000796da41e2911  vmovaps [rsp+0x40], xmm4
0000796da41e2917  vmovaps [rsp+0x50], xmm5
0000796da41e291d  vmovaps [rsp+0x60], xmm6
0000796da41e2923  vmovaps [rsp+0x70], xmm7
0000796da41e2929  vmovaps [rsp+0x80], xmm8
0000796da41e2932  vmovaps [rsp+0x90], xmm9
0000796da41e293b  vmovaps [rsp+0xA0], xmm10
0000796da41e2944  vmovaps [rsp+0xB0], xmm11
0000796da41e294d  vmovaps [rsp+0xC0], xmm12
0000796da41e2956  vmovaps [rsp+0xD0], xmm13
0000796da41e295f  vmovaps [rsp+0xE0], xmm15
0000796da41e2968  sub rsp, 0x30
0000796da41e296c  movaps [rsp], xmm14
0000796da41e2971  movaps [rsp+0x10], xmm8
0000796da41e2977  movaps [rsp+0x20], xmm4
0000796da41e297c  lea rdi, [rsp]
0000796da41e2980  mov esi, 0x00
0000796da41e2985  mov rax, 0x5E26CB66A530
0000796da41e298f  call rax
0000796da41e2991  movaps xmm14, [rsp]
0000796da41e2996  add rsp, 0x30
0000796da41e299a  vmovaps xmm0, [rsp]
0000796da41e299f  vmovaps xmm1, [rsp+0x10]
0000796da41e29a5  vmovaps xmm2, [rsp+0x20]
0000796da41e29ab  vmovaps xmm3, [rsp+0x30]
0000796da41e29b1  vmovaps xmm4, [rsp+0x40]
0000796da41e29b7  vmovaps xmm5, [rsp+0x50]
0000796da41e29bd  vmovaps xmm6, [rsp+0x60]
0000796da41e29c3  vmovaps xmm7, [rsp+0x70]
0000796da41e29c9  vmovaps xmm8, [rsp+0x80]
0000796da41e29d2  vmovaps xmm9, [rsp+0x90]
0000796da41e29db  vmovaps xmm10, [rsp+0xA0]
0000796da41e29e4  vmovaps xmm11, [rsp+0xB0]
0000796da41e29ed  vmovaps xmm12, [rsp+0xC0]
0000796da41e29f6  vmovaps xmm13, [rsp+0xD0]
0000796da41e29ff  vmovaps xmm15, [rsp+0xE0]
0000796da41e2a08  add rsp, 0xF0
0000796da41e2a0f  pop r11
0000796da41e2a11  pop r10
0000796da41e2a13  pop r9
0000796da41e2a15  pop r8
0000796da41e2a17  pop rsi
0000796da41e2a18  pop rdi
0000796da41e2a19  pop rdx
0000796da41e2a1a  pop rcx
0000796da41e2a1b  pop rax
0000796da41e2a1c  add rsp, 0x08
0000796da41e2a20  jmp 0x0000796DA41DF5F8
0000796da41e2a25  sub rsp, 0x08
0000796da41e2a29  push rax
0000796da41e2a2a  push rcx
0000796da41e2a2b  push rdx
0000796da41e2a2c  push rdi
0000796da41e2a2d  push rsi
0000796da41e2a2e  push r8
0000796da41e2a30  push r9
0000796da41e2a32  push r10
0000796da41e2a34  push r11
0000796da41e2a36  sub rsp, 0xF0
0000796da41e2a3d  vmovaps [rsp], xmm0
0000796da41e2a42  vmovaps [rsp+0x10], xmm1
0000796da41e2a48  vmovaps [rsp+0x20], xmm2
0000796da41e2a4e  vmovaps [rsp+0x30], xmm3
0000796da41e2a54  vmovaps [rsp+0x40], xmm5
0000796da41e2a5a  vmovaps [rsp+0x50], xmm6
0000796da41e2a60  vmovaps [rsp+0x60], xmm7
0000796da41e2a66  vmovaps [rsp+0x70], xmm8
0000796da41e2a6c  vmovaps [rsp+0x80], xmm9
0000796da41e2a75  vmovaps [rsp+0x90], xmm10
0000796da41e2a7e  vmovaps [rsp+0xA0], xmm11
0000796da41e2a87  vmovaps [rsp+0xB0], xmm12
0000796da41e2a90  vmovaps [rsp+0xC0], xmm13
0000796da41e2a99  vmovaps [rsp+0xD0], xmm14
0000796da41e2aa2  vmovaps [rsp+0xE0], xmm15
0000796da41e2aab  sub rsp, 0x30
0000796da41e2aaf  movaps [rsp], xmm4
0000796da41e2ab3  movaps [rsp+0x10], xmm13
0000796da41e2ab9  movaps [rsp+0x20], xmm8
0000796da41e2abf  lea rdi, [rsp]
0000796da41e2ac3  mov esi, 0x00
0000796da41e2ac8  mov rax, 0x5E26CB66A530
0000796da41e2ad2  call rax
0000796da41e2ad4  movaps xmm4, [rsp]
0000796da41e2ad8  add rsp, 0x30
0000796da41e2adc  vmovaps xmm0, [rsp]
0000796da41e2ae1  vmovaps xmm1, [rsp+0x10]
0000796da41e2ae7  vmovaps xmm2, [rsp+0x20]
0000796da41e2aed  vmovaps xmm3, [rsp+0x30]
0000796da41e2af3  vmovaps xmm5, [rsp+0x40]
0000796da41e2af9  vmovaps xmm6, [rsp+0x50]
0000796da41e2aff  vmovaps xmm7, [rsp+0x60]
0000796da41e2b05  vmovaps xmm8, [rsp+0x70]
0000796da41e2b0b  vmovaps xmm9, [rsp+0x80]
0000796da41e2b14  vmovaps xmm10, [rsp+0x90]
0000796da41e2b1d  vmovaps xmm11, [rsp+0xA0]
0000796da41e2b26  vmovaps xmm12, [rsp+0xB0]
0000796da41e2b2f  vmovaps xmm13, [rsp+0xC0]
0000796da41e2b38  vmovaps xmm14, [rsp+0xD0]
0000796da41e2b41  vmovaps xmm15, [rsp+0xE0]
0000796da41e2b4a  add rsp, 0xF0
0000796da41e2b51  pop r11
0000796da41e2b53  pop r10
0000796da41e2b55  pop r9
0000796da41e2b57  pop r8
0000796da41e2b59  pop rsi
0000796da41e2b5a  pop rdi
0000796da41e2b5b  pop rdx
0000796da41e2b5c  pop rcx
0000796da41e2b5d  pop rax
0000796da41e2b5e  add rsp, 0x08
0000796da41e2b62  jmp 0x0000796DA41DF61D
0000796da41e2b67  sub rsp, 0x08
0000796da41e2b6b  push rax
0000796da41e2b6c  push rcx
0000796da41e2b6d  push rdx
0000796da41e2b6e  push rdi
0000796da41e2b6f  push rsi
0000796da41e2b70  push r8
0000796da41e2b72  push r9
0000796da41e2b74  push r10
0000796da41e2b76  push r11
0000796da41e2b78  sub rsp, 0xF0
0000796da41e2b7f  vmovaps [rsp], xmm0
0000796da41e2b84  vmovaps [rsp+0x10], xmm1
0000796da41e2b8a  vmovaps [rsp+0x20], xmm2
0000796da41e2b90  vmovaps [rsp+0x30], xmm3
0000796da41e2b96  vmovaps [rsp+0x40], xmm4
0000796da41e2b9c  vmovaps [rsp+0x50], xmm5
0000796da41e2ba2  vmovaps [rsp+0x60], xmm6
0000796da41e2ba8  vmovaps [rsp+0x70], xmm7
0000796da41e2bae  vmovaps [rsp+0x80], xmm8
0000796da41e2bb7  vmovaps [rsp+0x90], xmm9
0000796da41e2bc0  vmovaps [rsp+0xA0], xmm10
0000796da41e2bc9  vmovaps [rsp+0xB0], xmm11
0000796da41e2bd2  vmovaps [rsp+0xC0], xmm12
0000796da41e2bdb  vmovaps [rsp+0xD0], xmm14
0000796da41e2be4  vmovaps [rsp+0xE0], xmm15
0000796da41e2bed  sub rsp, 0x30
0000796da41e2bf1  movaps [rsp], xmm13
0000796da41e2bf6  movaps [rsp+0x10], xmm15
0000796da41e2bfc  movaps [rsp+0x20], xmm9
0000796da41e2c02  lea rdi, [rsp]
0000796da41e2c06  mov esi, 0x00
0000796da41e2c0b  mov rax, 0x5E26CB66A530
0000796da41e2c15  call rax
0000796da41e2c17  movaps xmm13, [rsp]
0000796da41e2c1c  add rsp, 0x30
0000796da41e2c20  vmovaps xmm0, [rsp]
0000796da41e2c25  vmovaps xmm1, [rsp+0x10]
0000796da41e2c2b  vmovaps xmm2, [rsp+0x20]
0000796da41e2c31  vmovaps xmm3, [rsp+0x30]
0000796da41e2c37  vmovaps xmm4, [rsp+0x40]
0000796da41e2c3d  vmovaps xmm5, [rsp+0x50]
0000796da41e2c43  vmovaps xmm6, [rsp+0x60]
0000796da41e2c49  vmovaps xmm7, [rsp+0x70]
0000796da41e2c4f  vmovaps xmm8, [rsp+0x80]
0000796da41e2c58  vmovaps xmm9, [rsp+0x90]
0000796da41e2c61  vmovaps xmm10, [rsp+0xA0]
0000796da41e2c6a  vmovaps xmm11, [rsp+0xB0]
0000796da41e2c73  vmovaps xmm12, [rsp+0xC0]
0000796da41e2c7c  vmovaps xmm14, [rsp+0xD0]
0000796da41e2c85  vmovaps xmm15, [rsp+0xE0]
0000796da41e2c8e  add rsp, 0xF0
0000796da41e2c95  pop r11
0000796da41e2c97  pop r10
0000796da41e2c99  pop r9
0000796da41e2c9b  pop r8
0000796da41e2c9d  pop rsi
0000796da41e2c9e  pop rdi
0000796da41e2c9f  pop rdx
0000796da41e2ca0  pop rcx
0000796da41e2ca1  pop rax
0000796da41e2ca2  add rsp, 0x08
0000796da41e2ca6  jmp 0x0000796DA41DF638
0000796da41e2cab  sub rsp, 0x08
0000796da41e2caf  push rax
0000796da41e2cb0  push rcx
0000796da41e2cb1  push rdx
0000796da41e2cb2  push rdi
0000796da41e2cb3  push rsi
0000796da41e2cb4  push r8
0000796da41e2cb6  push r9
0000796da41e2cb8  push r10
0000796da41e2cba  push r11
0000796da41e2cbc  sub rsp, 0xF0
0000796da41e2cc3  vmovaps [rsp], xmm0
0000796da41e2cc8  vmovaps [rsp+0x10], xmm1
0000796da41e2cce  vmovaps [rsp+0x20], xmm2
0000796da41e2cd4  vmovaps [rsp+0x30], xmm3
0000796da41e2cda  vmovaps [rsp+0x40], xmm4
0000796da41e2ce0  vmovaps [rsp+0x50], xmm5
0000796da41e2ce6  vmovaps [rsp+0x60], xmm6
0000796da41e2cec  vmovaps [rsp+0x70], xmm7
0000796da41e2cf2  vmovaps [rsp+0x80], xmm8
0000796da41e2cfb  vmovaps [rsp+0x90], xmm9
0000796da41e2d04  vmovaps [rsp+0xA0], xmm10
0000796da41e2d0d  vmovaps [rsp+0xB0], xmm11
0000796da41e2d16  vmovaps [rsp+0xC0], xmm12
0000796da41e2d1f  vmovaps [rsp+0xD0], xmm13
0000796da41e2d28  vmovaps [rsp+0xE0], xmm14
0000796da41e2d31  sub rsp, 0x30
0000796da41e2d35  movaps [rsp], xmm15
0000796da41e2d3a  movaps [rsp+0x10], xmm1
0000796da41e2d3f  movaps [rsp+0x20], xmm5
0000796da41e2d44  lea rdi, [rsp]
0000796da41e2d48  mov esi, 0x00
0000796da41e2d4d  mov rax, 0x5E26CB66A530
0000796da41e2d57  call rax
0000796da41e2d59  movaps xmm15, [rsp]
0000796da41e2d5e  add rsp, 0x30
0000796da41e2d62  vmovaps xmm0, [rsp]
0000796da41e2d67  vmovaps xmm1, [rsp+0x10]
0000796da41e2d6d  vmovaps xmm2, [rsp+0x20]
0000796da41e2d73  vmovaps xmm3, [rsp+0x30]
0000796da41e2d79  vmovaps xmm4, [rsp+0x40]
0000796da41e2d7f  vmovaps xmm5, [rsp+0x50]
0000796da41e2d85  vmovaps xmm6, [rsp+0x60]
0000796da41e2d8b  vmovaps xmm7, [rsp+0x70]
0000796da41e2d91  vmovaps xmm8, [rsp+0x80]
0000796da41e2d9a  vmovaps xmm9, [rsp+0x90]
0000796da41e2da3  vmovaps xmm10, [rsp+0xA0]
0000796da41e2dac  vmovaps xmm11, [rsp+0xB0]
0000796da41e2db5  vmovaps xmm12, [rsp+0xC0]
0000796da41e2dbe  vmovaps xmm13, [rsp+0xD0]
0000796da41e2dc7  vmovaps xmm14, [rsp+0xE0]
0000796da41e2dd0  add rsp, 0xF0
0000796da41e2dd7  pop r11
0000796da41e2dd9  pop r10
0000796da41e2ddb  pop r9
0000796da41e2ddd  pop r8
0000796da41e2ddf  pop rsi
0000796da41e2de0  pop rdi
0000796da41e2de1  pop rdx
0000796da41e2de2  pop rcx
0000796da41e2de3  pop rax
0000796da41e2de4  add rsp, 0x08
0000796da41e2de8  jmp 0x0000796DA41DF653
0000796da41e2ded  call 0x0000796DA40B52F0
0000796da41e2df2  jmp 0x0000796DA41DF6AE
0000796da41e2df7  sub rsp, 0x08
0000796da41e2dfb  push rax
0000796da41e2dfc  push rcx
0000796da41e2dfd  push rdx
0000796da41e2dfe  push rdi
0000796da41e2dff  push rsi
0000796da41e2e00  push r8
0000796da41e2e02  push r9
0000796da41e2e04  push r10
0000796da41e2e06  push r11
0000796da41e2e08  sub rsp, 0xF0
0000796da41e2e0f  vmovaps [rsp], xmm0
0000796da41e2e14  vmovaps [rsp+0x10], xmm1
0000796da41e2e1a  vmovaps [rsp+0x20], xmm2
0000796da41e2e20  vmovaps [rsp+0x30], xmm3
0000796da41e2e26  vmovaps [rsp+0x40], xmm4
0000796da41e2e2c  vmovaps [rsp+0x50], xmm5
0000796da41e2e32  vmovaps [rsp+0x60], xmm6
0000796da41e2e38  vmovaps [rsp+0x70], xmm7
0000796da41e2e3e  vmovaps [rsp+0x80], xmm8
0000796da41e2e47  vmovaps [rsp+0x90], xmm10
0000796da41e2e50  vmovaps [rsp+0xA0], xmm11
0000796da41e2e59  vmovaps [rsp+0xB0], xmm12
0000796da41e2e62  vmovaps [rsp+0xC0], xmm13
0000796da41e2e6b  vmovaps [rsp+0xD0], xmm14
0000796da41e2e74  vmovaps [rsp+0xE0], xmm15
0000796da41e2e7d  sub rsp, 0x30
0000796da41e2e81  movaps [rsp], xmm9
0000796da41e2e86  movaps [rsp+0x10], xmm8
0000796da41e2e8c  movaps [rsp+0x20], xmm11
0000796da41e2e92  lea rdi, [rsp]
0000796da41e2e96  mov esi, 0x00
0000796da41e2e9b  mov rax, 0x5E26CB66A530
0000796da41e2ea5  call rax
0000796da41e2ea7  movaps xmm9, [rsp]
0000796da41e2eac  add rsp, 0x30
0000796da41e2eb0  vmovaps xmm0, [rsp]
0000796da41e2eb5  vmovaps xmm1, [rsp+0x10]
0000796da41e2ebb  vmovaps xmm2, [rsp+0x20]
0000796da41e2ec1  vmovaps xmm3, [rsp+0x30]
0000796da41e2ec7  vmovaps xmm4, [rsp+0x40]
0000796da41e2ecd  vmovaps xmm5, [rsp+0x50]
0000796da41e2ed3  vmovaps xmm6, [rsp+0x60]
0000796da41e2ed9  vmovaps xmm7, [rsp+0x70]
0000796da41e2edf  vmovaps xmm8, [rsp+0x80]
0000796da41e2ee8  vmovaps xmm10, [rsp+0x90]
0000796da41e2ef1  vmovaps xmm11, [rsp+0xA0]
0000796da41e2efa  vmovaps xmm12, [rsp+0xB0]
0000796da41e2f03  vmovaps xmm13, [rsp+0xC0]
0000796da41e2f0c  vmovaps xmm14, [rsp+0xD0]
0000796da41e2f15  vmovaps xmm15, [rsp+0xE0]
0000796da41e2f1e  add rsp, 0xF0
0000796da41e2f25  pop r11
0000796da41e2f27  pop r10
0000796da41e2f29  pop r9
0000796da41e2f2b  pop r8
0000796da41e2f2d  pop rsi
0000796da41e2f2e  pop rdi
0000796da41e2f2f  pop rdx
0000796da41e2f30  pop rcx
0000796da41e2f31  pop rax
0000796da41e2f32  add rsp, 0x08
0000796da41e2f36  jmp 0x0000796DA41DF6E5
0000796da41e2f3b  sub rsp, 0x08
0000796da41e2f3f  push rax
0000796da41e2f40  push rcx
0000796da41e2f41  push rdx
0000796da41e2f42  push rdi
0000796da41e2f43  push rsi
0000796da41e2f44  push r8
0000796da41e2f46  push r9
0000796da41e2f48  push r10
0000796da41e2f4a  push r11
0000796da41e2f4c  sub rsp, 0xF0
0000796da41e2f53  vmovaps [rsp], xmm0
0000796da41e2f58  vmovaps [rsp+0x10], xmm1
0000796da41e2f5e  vmovaps [rsp+0x20], xmm2
0000796da41e2f64  vmovaps [rsp+0x30], xmm3
0000796da41e2f6a  vmovaps [rsp+0x40], xmm4
0000796da41e2f70  vmovaps [rsp+0x50], xmm5
0000796da41e2f76  vmovaps [rsp+0x60], xmm6
0000796da41e2f7c  vmovaps [rsp+0x70], xmm7
0000796da41e2f82  vmovaps [rsp+0x80], xmm8
0000796da41e2f8b  vmovaps [rsp+0x90], xmm9
0000796da41e2f94  vmovaps [rsp+0xA0], xmm10
0000796da41e2f9d  vmovaps [rsp+0xB0], xmm12
0000796da41e2fa6  vmovaps [rsp+0xC0], xmm13
0000796da41e2faf  vmovaps [rsp+0xD0], xmm14
0000796da41e2fb8  vmovaps [rsp+0xE0], xmm15
0000796da41e2fc1  sub rsp, 0x30
0000796da41e2fc5  movaps [rsp], xmm11
0000796da41e2fca  movaps [rsp+0x10], xmm10
0000796da41e2fd0  movaps [rsp+0x20], xmm6
0000796da41e2fd5  lea rdi, [rsp]
0000796da41e2fd9  mov esi, 0x00
0000796da41e2fde  mov rax, 0x5E26CB66A530
0000796da41e2fe8  call rax
0000796da41e2fea  movaps xmm11, [rsp]
0000796da41e2fef  add rsp, 0x30
0000796da41e2ff3  vmovaps xmm0, [rsp]
0000796da41e2ff8  vmovaps xmm1, [rsp+0x10]
0000796da41e2ffe  vmovaps xmm2, [rsp+0x20]
0000796da41e3004  vmovaps xmm3, [rsp+0x30]
0000796da41e300a  vmovaps xmm4, [rsp+0x40]
0000796da41e3010  vmovaps xmm5, [rsp+0x50]
0000796da41e3016  vmovaps xmm6, [rsp+0x60]
0000796da41e301c  vmovaps xmm7, [rsp+0x70]
0000796da41e3022  vmovaps xmm8, [rsp+0x80]
0000796da41e302b  vmovaps xmm9, [rsp+0x90]
0000796da41e3034  vmovaps xmm10, [rsp+0xA0]
0000796da41e303d  vmovaps xmm12, [rsp+0xB0]
0000796da41e3046  vmovaps xmm13, [rsp+0xC0]
0000796da41e304f  vmovaps xmm14, [rsp+0xD0]
0000796da41e3058  vmovaps xmm15, [rsp+0xE0]
0000796da41e3061  add rsp, 0xF0
0000796da41e3068  pop r11
0000796da41e306a  pop r10
0000796da41e306c  pop r9
0000796da41e306e  pop r8
0000796da41e3070  pop rsi
0000796da41e3071  pop rdi
0000796da41e3072  pop rdx
0000796da41e3073  pop rcx
0000796da41e3074  pop rax
0000796da41e3075  add rsp, 0x08
0000796da41e3079  jmp 0x0000796DA41DF700
0000796da41e307e  sub rsp, 0x08
0000796da41e3082  push rax
0000796da41e3083  push rcx
0000796da41e3084  push rdx
0000796da41e3085  push rdi
0000796da41e3086  push rsi
0000796da41e3087  push r8
0000796da41e3089  push r9
0000796da41e308b  push r10
0000796da41e308d  push r11
0000796da41e308f  sub rsp, 0xF0
0000796da41e3096  vmovaps [rsp], xmm0
0000796da41e309b  vmovaps [rsp+0x10], xmm1
0000796da41e30a1  vmovaps [rsp+0x20], xmm2
0000796da41e30a7  vmovaps [rsp+0x30], xmm3
0000796da41e30ad  vmovaps [rsp+0x40], xmm4
0000796da41e30b3  vmovaps [rsp+0x50], xmm5
0000796da41e30b9  vmovaps [rsp+0x60], xmm6
0000796da41e30bf  vmovaps [rsp+0x70], xmm7
0000796da41e30c5  vmovaps [rsp+0x80], xmm8
0000796da41e30ce  vmovaps [rsp+0x90], xmm9
0000796da41e30d7  vmovaps [rsp+0xA0], xmm11
0000796da41e30e0  vmovaps [rsp+0xB0], xmm12
0000796da41e30e9  vmovaps [rsp+0xC0], xmm13
0000796da41e30f2  vmovaps [rsp+0xD0], xmm14
0000796da41e30fb  vmovaps [rsp+0xE0], xmm15
0000796da41e3104  sub rsp, 0x30
0000796da41e3108  movaps [rsp], xmm10
0000796da41e310d  movaps [rsp+0x10], xmm14
0000796da41e3113  movaps [rsp+0x20], xmm4
0000796da41e3118  lea rdi, [rsp]
0000796da41e311c  mov esi, 0x00
0000796da41e3121  mov rax, 0x5E26CB66A530
0000796da41e312b  call rax
0000796da41e312d  movaps xmm10, [rsp]
0000796da41e3132  add rsp, 0x30
0000796da41e3136  vmovaps xmm0, [rsp]
0000796da41e313b  vmovaps xmm1, [rsp+0x10]
0000796da41e3141  vmovaps xmm2, [rsp+0x20]
0000796da41e3147  vmovaps xmm3, [rsp+0x30]
0000796da41e314d  vmovaps xmm4, [rsp+0x40]
0000796da41e3153  vmovaps xmm5, [rsp+0x50]
0000796da41e3159  vmovaps xmm6, [rsp+0x60]
0000796da41e315f  vmovaps xmm7, [rsp+0x70]
0000796da41e3165  vmovaps xmm8, [rsp+0x80]
0000796da41e316e  vmovaps xmm9, [rsp+0x90]
0000796da41e3177  vmovaps xmm11, [rsp+0xA0]
0000796da41e3180  vmovaps xmm12, [rsp+0xB0]
0000796da41e3189  vmovaps xmm13, [rsp+0xC0]
0000796da41e3192  vmovaps xmm14, [rsp+0xD0]
0000796da41e319b  vmovaps xmm15, [rsp+0xE0]
0000796da41e31a4  add rsp, 0xF0
0000796da41e31ab  pop r11
0000796da41e31ad  pop r10
0000796da41e31af  pop r9
0000796da41e31b1  pop r8
0000796da41e31b3  pop rsi
0000796da41e31b4  pop rdi
0000796da41e31b5  pop rdx
0000796da41e31b6  pop rcx
0000796da41e31b7  pop rax
0000796da41e31b8  add rsp, 0x08
0000796da41e31bc  jmp 0x0000796DA41DF71B
0000796da41e31c1  sub rsp, 0x08
0000796da41e31c5  push rax
0000796da41e31c6  push rcx
0000796da41e31c7  push rdx
0000796da41e31c8  push rdi
0000796da41e31c9  push rsi
0000796da41e31ca  push r8
0000796da41e31cc  push r9
0000796da41e31ce  push r10
0000796da41e31d0  push r11
0000796da41e31d2  sub rsp, 0xF0
0000796da41e31d9  vmovaps [rsp], xmm0
0000796da41e31de  vmovaps [rsp+0x10], xmm1
0000796da41e31e4  vmovaps [rsp+0x20], xmm2
0000796da41e31ea  vmovaps [rsp+0x30], xmm3
0000796da41e31f0  vmovaps [rsp+0x40], xmm4
0000796da41e31f6  vmovaps [rsp+0x50], xmm5
0000796da41e31fc  vmovaps [rsp+0x60], xmm6
0000796da41e3202  vmovaps [rsp+0x70], xmm7
0000796da41e3208  vmovaps [rsp+0x80], xmm9
0000796da41e3211  vmovaps [rsp+0x90], xmm10
0000796da41e321a  vmovaps [rsp+0xA0], xmm11
0000796da41e3223  vmovaps [rsp+0xB0], xmm12
0000796da41e322c  vmovaps [rsp+0xC0], xmm13
0000796da41e3235  vmovaps [rsp+0xD0], xmm14
0000796da41e323e  vmovaps [rsp+0xE0], xmm15
0000796da41e3247  sub rsp, 0x30
0000796da41e324b  movaps [rsp], xmm8
0000796da41e3250  movaps [rsp+0x10], xmm1
0000796da41e3255  movaps [rsp+0x20], xmm14
0000796da41e325b  lea rdi, [rsp]
0000796da41e325f  mov esi, 0x00
0000796da41e3264  mov rax, 0x5E26CB66A530
0000796da41e326e  call rax
0000796da41e3270  movaps xmm8, [rsp]
0000796da41e3275  add rsp, 0x30
0000796da41e3279  vmovaps xmm0, [rsp]
0000796da41e327e  vmovaps xmm1, [rsp+0x10]
0000796da41e3284  vmovaps xmm2, [rsp+0x20]
0000796da41e328a  vmovaps xmm3, [rsp+0x30]
0000796da41e3290  vmovaps xmm4, [rsp+0x40]
0000796da41e3296  vmovaps xmm5, [rsp+0x50]
0000796da41e329c  vmovaps xmm6, [rsp+0x60]
0000796da41e32a2  vmovaps xmm7, [rsp+0x70]
0000796da41e32a8  vmovaps xmm9, [rsp+0x80]
0000796da41e32b1  vmovaps xmm10, [rsp+0x90]
0000796da41e32ba  vmovaps xmm11, [rsp+0xA0]
0000796da41e32c3  vmovaps xmm12, [rsp+0xB0]
0000796da41e32cc  vmovaps xmm13, [rsp+0xC0]
0000796da41e32d5  vmovaps xmm14, [rsp+0xD0]
0000796da41e32de  vmovaps xmm15, [rsp+0xE0]
0000796da41e32e7  add rsp, 0xF0
0000796da41e32ee  pop r11
0000796da41e32f0  pop r10
0000796da41e32f2  pop r9
0000796da41e32f4  pop r8
0000796da41e32f6  pop rsi
0000796da41e32f7  pop rdi
0000796da41e32f8  pop rdx
0000796da41e32f9  pop rcx
0000796da41e32fa  pop rax
0000796da41e32fb  add rsp, 0x08
0000796da41e32ff  jmp 0x0000796DA41DF741
0000796da41e3304  sub rsp, 0x08
0000796da41e3308  push rax
0000796da41e3309  push rcx
0000796da41e330a  push rdx
0000796da41e330b  push rdi
0000796da41e330c  push rsi
0000796da41e330d  push r8
0000796da41e330f  push r9
0000796da41e3311  push r10
0000796da41e3313  push r11
0000796da41e3315  sub rsp, 0xF0
0000796da41e331c  vmovaps [rsp], xmm0
0000796da41e3321  vmovaps [rsp+0x10], xmm1
0000796da41e3327  vmovaps [rsp+0x20], xmm2
0000796da41e332d  vmovaps [rsp+0x30], xmm3
0000796da41e3333  vmovaps [rsp+0x40], xmm4
0000796da41e3339  vmovaps [rsp+0x50], xmm5
0000796da41e333f  vmovaps [rsp+0x60], xmm7
0000796da41e3345  vmovaps [rsp+0x70], xmm8
0000796da41e334b  vmovaps [rsp+0x80], xmm9
0000796da41e3354  vmovaps [rsp+0x90], xmm10
0000796da41e335d  vmovaps [rsp+0xA0], xmm11
0000796da41e3366  vmovaps [rsp+0xB0], xmm12
0000796da41e336f  vmovaps [rsp+0xC0], xmm13
0000796da41e3378  vmovaps [rsp+0xD0], xmm14
0000796da41e3381  vmovaps [rsp+0xE0], xmm15
0000796da41e338a  sub rsp, 0x30
0000796da41e338e  movaps [rsp], xmm6
0000796da41e3392  movaps [rsp+0x10], xmm1
0000796da41e3397  movaps [rsp+0x20], xmm14
0000796da41e339d  lea rdi, [rsp]
0000796da41e33a1  mov esi, 0x00
0000796da41e33a6  mov rax, 0x5E26CB66A530
0000796da41e33b0  call rax
0000796da41e33b2  movaps xmm6, [rsp]
0000796da41e33b6  add rsp, 0x30
0000796da41e33ba  vmovaps xmm0, [rsp]
0000796da41e33bf  vmovaps xmm1, [rsp+0x10]
0000796da41e33c5  vmovaps xmm2, [rsp+0x20]
0000796da41e33cb  vmovaps xmm3, [rsp+0x30]
0000796da41e33d1  vmovaps xmm4, [rsp+0x40]
0000796da41e33d7  vmovaps xmm5, [rsp+0x50]
0000796da41e33dd  vmovaps xmm7, [rsp+0x60]
0000796da41e33e3  vmovaps xmm8, [rsp+0x70]
0000796da41e33e9  vmovaps xmm9, [rsp+0x80]
0000796da41e33f2  vmovaps xmm10, [rsp+0x90]
0000796da41e33fb  vmovaps xmm11, [rsp+0xA0]
0000796da41e3404  vmovaps xmm12, [rsp+0xB0]
0000796da41e340d  vmovaps xmm13, [rsp+0xC0]
0000796da41e3416  vmovaps xmm14, [rsp+0xD0]
0000796da41e341f  vmovaps xmm15, [rsp+0xE0]
0000796da41e3428  add rsp, 0xF0
0000796da41e342f  pop r11
0000796da41e3431  pop r10
0000796da41e3433  pop r9
0000796da41e3435  pop r8
0000796da41e3437  pop rsi
0000796da41e3438  pop rdi
0000796da41e3439  pop rdx
0000796da41e343a  pop rcx
0000796da41e343b  pop rax
0000796da41e343c  add rsp, 0x08
0000796da41e3440  jmp 0x0000796DA41DF76D
0000796da41e3445  sub rsp, 0x08
0000796da41e3449  push rax
0000796da41e344a  push rcx
0000796da41e344b  push rdx
0000796da41e344c  push rdi
0000796da41e344d  push rsi
0000796da41e344e  push r8
0000796da41e3450  push r9
0000796da41e3452  push r10
0000796da41e3454  push r11
0000796da41e3456  sub rsp, 0xF0
0000796da41e345d  vmovaps [rsp], xmm0
0000796da41e3462  vmovaps [rsp+0x10], xmm1
0000796da41e3468  vmovaps [rsp+0x20], xmm2
0000796da41e346e  vmovaps [rsp+0x30], xmm3
0000796da41e3474  vmovaps [rsp+0x40], xmm4
0000796da41e347a  vmovaps [rsp+0x50], xmm5
0000796da41e3480  vmovaps [rsp+0x60], xmm6
0000796da41e3486  vmovaps [rsp+0x70], xmm7
0000796da41e348c  vmovaps [rsp+0x80], xmm8
0000796da41e3495  vmovaps [rsp+0x90], xmm9
0000796da41e349e  vmovaps [rsp+0xA0], xmm10
0000796da41e34a7  vmovaps [rsp+0xB0], xmm11
0000796da41e34b0  vmovaps [rsp+0xC0], xmm12
0000796da41e34b9  vmovaps [rsp+0xD0], xmm13
0000796da41e34c2  vmovaps [rsp+0xE0], xmm15
0000796da41e34cb  sub rsp, 0x30
0000796da41e34cf  movaps [rsp], xmm14
0000796da41e34d4  movaps [rsp+0x10], xmm12
0000796da41e34da  movaps [rsp+0x20], xmm1
0000796da41e34df  lea rdi, [rsp]
0000796da41e34e3  mov esi, 0x00
0000796da41e34e8  mov rax, 0x5E26CB66A530
0000796da41e34f2  call rax
0000796da41e34f4  movaps xmm14, [rsp]
0000796da41e34f9  add rsp, 0x30
0000796da41e34fd  vmovaps xmm0, [rsp]
0000796da41e3502  vmovaps xmm1, [rsp+0x10]
0000796da41e3508  vmovaps xmm2, [rsp+0x20]
0000796da41e350e  vmovaps xmm3, [rsp+0x30]
0000796da41e3514  vmovaps xmm4, [rsp+0x40]
0000796da41e351a  vmovaps xmm5, [rsp+0x50]
0000796da41e3520  vmovaps xmm6, [rsp+0x60]
0000796da41e3526  vmovaps xmm7, [rsp+0x70]
0000796da41e352c  vmovaps xmm8, [rsp+0x80]
0000796da41e3535  vmovaps xmm9, [rsp+0x90]
0000796da41e353e  vmovaps xmm10, [rsp+0xA0]
0000796da41e3547  vmovaps xmm11, [rsp+0xB0]
0000796da41e3550  vmovaps xmm12, [rsp+0xC0]
0000796da41e3559  vmovaps xmm13, [rsp+0xD0]
0000796da41e3562  vmovaps xmm15, [rsp+0xE0]
0000796da41e356b  add rsp, 0xF0
0000796da41e3572  pop r11
0000796da41e3574  pop r10
0000796da41e3576  pop r9
0000796da41e3578  pop r8
0000796da41e357a  pop rsi
0000796da41e357b  pop rdi
0000796da41e357c  pop rdx
0000796da41e357d  pop rcx
0000796da41e357e  pop rax
0000796da41e357f  add rsp, 0x08
0000796da41e3583  jmp 0x0000796DA41DF793
0000796da41e3588  sub rsp, 0x08
0000796da41e358c  push rax
0000796da41e358d  push rcx
0000796da41e358e  push rdx
0000796da41e358f  push rdi
0000796da41e3590  push rsi
0000796da41e3591  push r8
0000796da41e3593  push r9
0000796da41e3595  push r10
0000796da41e3597  push r11
0000796da41e3599  sub rsp, 0xF0
0000796da41e35a0  vmovaps [rsp], xmm0
0000796da41e35a5  vmovaps [rsp+0x10], xmm2
0000796da41e35ab  vmovaps [rsp+0x20], xmm3
0000796da41e35b1  vmovaps [rsp+0x30], xmm4
0000796da41e35b7  vmovaps [rsp+0x40], xmm5
0000796da41e35bd  vmovaps [rsp+0x50], xmm6
0000796da41e35c3  vmovaps [rsp+0x60], xmm7
0000796da41e35c9  vmovaps [rsp+0x70], xmm8
0000796da41e35cf  vmovaps [rsp+0x80], xmm9
0000796da41e35d8  vmovaps [rsp+0x90], xmm10
0000796da41e35e1  vmovaps [rsp+0xA0], xmm11
0000796da41e35ea  vmovaps [rsp+0xB0], xmm12
0000796da41e35f3  vmovaps [rsp+0xC0], xmm13
0000796da41e35fc  vmovaps [rsp+0xD0], xmm14
0000796da41e3605  vmovaps [rsp+0xE0], xmm15
0000796da41e360e  sub rsp, 0x30
0000796da41e3612  movaps [rsp], xmm1
0000796da41e3616  movaps [rsp+0x10], xmm13
0000796da41e361c  movaps [rsp+0x20], xmm9
0000796da41e3622  lea rdi, [rsp]
0000796da41e3626  mov esi, 0x00
0000796da41e362b  mov rax, 0x5E26CB66A530
0000796da41e3635  call rax
0000796da41e3637  movaps xmm1, [rsp]
0000796da41e363b  add rsp, 0x30
0000796da41e363f  vmovaps xmm0, [rsp]
0000796da41e3644  vmovaps xmm2, [rsp+0x10]
0000796da41e364a  vmovaps xmm3, [rsp+0x20]
0000796da41e3650  vmovaps xmm4, [rsp+0x30]
0000796da41e3656  vmovaps xmm5, [rsp+0x40]
0000796da41e365c  vmovaps xmm6, [rsp+0x50]
0000796da41e3662  vmovaps xmm7, [rsp+0x60]
0000796da41e3668  vmovaps xmm8, [rsp+0x70]
0000796da41e366e  vmovaps xmm9, [rsp+0x80]
0000796da41e3677  vmovaps xmm10, [rsp+0x90]
0000796da41e3680  vmovaps xmm11, [rsp+0xA0]
0000796da41e3689  vmovaps xmm12, [rsp+0xB0]
0000796da41e3692  vmovaps xmm13, [rsp+0xC0]
0000796da41e369b  vmovaps xmm14, [rsp+0xD0]
0000796da41e36a4  vmovaps xmm15, [rsp+0xE0]
0000796da41e36ad  add rsp, 0xF0
0000796da41e36b4  pop r11
0000796da41e36b6  pop r10
0000796da41e36b8  pop r9
0000796da41e36ba  pop r8
0000796da41e36bc  pop rsi
0000796da41e36bd  pop rdi
0000796da41e36be  pop rdx
0000796da41e36bf  pop rcx
0000796da41e36c0  pop rax
0000796da41e36c1  add rsp, 0x08
0000796da41e36c5  jmp 0x0000796DA41DF7AD
0000796da41e36ca  sub rsp, 0x08
0000796da41e36ce  push rax
0000796da41e36cf  push rcx
0000796da41e36d0  push rdx
0000796da41e36d1  push rdi
0000796da41e36d2  push rsi
0000796da41e36d3  push r8
0000796da41e36d5  push r9
0000796da41e36d7  push r10
0000796da41e36d9  push r11
0000796da41e36db  sub rsp, 0xF0
0000796da41e36e2  vmovaps [rsp], xmm0
0000796da41e36e7  vmovaps [rsp+0x10], xmm1
0000796da41e36ed  vmovaps [rsp+0x20], xmm2
0000796da41e36f3  vmovaps [rsp+0x30], xmm3
0000796da41e36f9  vmovaps [rsp+0x40], xmm4
0000796da41e36ff  vmovaps [rsp+0x50], xmm5
0000796da41e3705  vmovaps [rsp+0x60], xmm6
0000796da41e370b  vmovaps [rsp+0x70], xmm7
0000796da41e3711  vmovaps [rsp+0x80], xmm8
0000796da41e371a  vmovaps [rsp+0x90], xmm9
0000796da41e3723  vmovaps [rsp+0xA0], xmm10
0000796da41e372c  vmovaps [rsp+0xB0], xmm11
0000796da41e3735  vmovaps [rsp+0xC0], xmm13
0000796da41e373e  vmovaps [rsp+0xD0], xmm14
0000796da41e3747  vmovaps [rsp+0xE0], xmm15
0000796da41e3750  sub rsp, 0x30
0000796da41e3754  movaps [rsp], xmm12
0000796da41e3759  movaps [rsp+0x10], xmm7
0000796da41e375e  movaps [rsp+0x20], xmm13
0000796da41e3764  lea rdi, [rsp]
0000796da41e3768  mov esi, 0x00
0000796da41e376d  mov rax, 0x5E26CB66A530
0000796da41e3777  call rax
0000796da41e3779  movaps xmm12, [rsp]
0000796da41e377e  add rsp, 0x30
0000796da41e3782  vmovaps xmm0, [rsp]
0000796da41e3787  vmovaps xmm1, [rsp+0x10]
0000796da41e378d  vmovaps xmm2, [rsp+0x20]
0000796da41e3793  vmovaps xmm3, [rsp+0x30]
0000796da41e3799  vmovaps xmm4, [rsp+0x40]
0000796da41e379f  vmovaps xmm5, [rsp+0x50]
0000796da41e37a5  vmovaps xmm6, [rsp+0x60]
0000796da41e37ab  vmovaps xmm7, [rsp+0x70]
0000796da41e37b1  vmovaps xmm8, [rsp+0x80]
0000796da41e37ba  vmovaps xmm9, [rsp+0x90]
0000796da41e37c3  vmovaps xmm10, [rsp+0xA0]
0000796da41e37cc  vmovaps xmm11, [rsp+0xB0]
0000796da41e37d5  vmovaps xmm13, [rsp+0xC0]
0000796da41e37de  vmovaps xmm14, [rsp+0xD0]
0000796da41e37e7  vmovaps xmm15, [rsp+0xE0]
0000796da41e37f0  add rsp, 0xF0
0000796da41e37f7  pop r11
0000796da41e37f9  pop r10
0000796da41e37fb  pop r9
0000796da41e37fd  pop r8
0000796da41e37ff  pop rsi
0000796da41e3800  pop rdi
0000796da41e3801  pop rdx
0000796da41e3802  pop rcx
0000796da41e3803  pop rax
0000796da41e3804  add rsp, 0x08
0000796da41e3808  jmp 0x0000796DA41DF7D4
0000796da41e380d  sub rsp, 0x08
0000796da41e3811  push rax
0000796da41e3812  push rcx
0000796da41e3813  push rdx
0000796da41e3814  push rdi
0000796da41e3815  push rsi
0000796da41e3816  push r8
0000796da41e3818  push r9
0000796da41e381a  push r10
0000796da41e381c  push r11
0000796da41e381e  sub rsp, 0xF0
0000796da41e3825  vmovaps [rsp], xmm0
0000796da41e382a  vmovaps [rsp+0x10], xmm1
0000796da41e3830  vmovaps [rsp+0x20], xmm2
0000796da41e3836  vmovaps [rsp+0x30], xmm3
0000796da41e383c  vmovaps [rsp+0x40], xmm4
0000796da41e3842  vmovaps [rsp+0x50], xmm5
0000796da41e3848  vmovaps [rsp+0x60], xmm6
0000796da41e384e  vmovaps [rsp+0x70], xmm7
0000796da41e3854  vmovaps [rsp+0x80], xmm8
0000796da41e385d  vmovaps [rsp+0x90], xmm9
0000796da41e3866  vmovaps [rsp+0xA0], xmm10
0000796da41e386f  vmovaps [rsp+0xB0], xmm11
0000796da41e3878  vmovaps [rsp+0xC0], xmm12
0000796da41e3881  vmovaps [rsp+0xD0], xmm14
0000796da41e388a  vmovaps [rsp+0xE0], xmm15
0000796da41e3893  sub rsp, 0x30
0000796da41e3897  movaps [rsp], xmm13
0000796da41e389c  movaps [rsp+0x10], xmm15
0000796da41e38a2  movaps [rsp+0x20], xmm8
0000796da41e38a8  lea rdi, [rsp]
0000796da41e38ac  mov esi, 0x00
0000796da41e38b1  mov rax, 0x5E26CB66A530
0000796da41e38bb  call rax
0000796da41e38bd  movaps xmm13, [rsp]
0000796da41e38c2  add rsp, 0x30
0000796da41e38c6  vmovaps xmm0, [rsp]
0000796da41e38cb  vmovaps xmm1, [rsp+0x10]
0000796da41e38d1  vmovaps xmm2, [rsp+0x20]
0000796da41e38d7  vmovaps xmm3, [rsp+0x30]
0000796da41e38dd  vmovaps xmm4, [rsp+0x40]
0000796da41e38e3  vmovaps xmm5, [rsp+0x50]
0000796da41e38e9  vmovaps xmm6, [rsp+0x60]
0000796da41e38ef  vmovaps xmm7, [rsp+0x70]
0000796da41e38f5  vmovaps xmm8, [rsp+0x80]
0000796da41e38fe  vmovaps xmm9, [rsp+0x90]
0000796da41e3907  vmovaps xmm10, [rsp+0xA0]
0000796da41e3910  vmovaps xmm11, [rsp+0xB0]
0000796da41e3919  vmovaps xmm12, [rsp+0xC0]
0000796da41e3922  vmovaps xmm14, [rsp+0xD0]
0000796da41e392b  vmovaps xmm15, [rsp+0xE0]
0000796da41e3934  add rsp, 0xF0
0000796da41e393b  pop r11
0000796da41e393d  pop r10
0000796da41e393f  pop r9
0000796da41e3941  pop r8
0000796da41e3943  pop rsi
0000796da41e3944  pop rdi
0000796da41e3945  pop rdx
0000796da41e3946  pop rcx
0000796da41e3947  pop rax
0000796da41e3948  add rsp, 0x08
0000796da41e394c  jmp 0x0000796DA41DF7EF
0000796da41e3951  sub rsp, 0x08
0000796da41e3955  push rax
0000796da41e3956  push rcx
0000796da41e3957  push rdx
0000796da41e3958  push rdi
0000796da41e3959  push rsi
0000796da41e395a  push r8
0000796da41e395c  push r9
0000796da41e395e  push r10
0000796da41e3960  push r11
0000796da41e3962  sub rsp, 0xF0
0000796da41e3969  vmovaps [rsp], xmm0
0000796da41e396e  vmovaps [rsp+0x10], xmm1
0000796da41e3974  vmovaps [rsp+0x20], xmm2
0000796da41e397a  vmovaps [rsp+0x30], xmm3
0000796da41e3980  vmovaps [rsp+0x40], xmm4
0000796da41e3986  vmovaps [rsp+0x50], xmm5
0000796da41e398c  vmovaps [rsp+0x60], xmm6
0000796da41e3992  vmovaps [rsp+0x70], xmm7
0000796da41e3998  vmovaps [rsp+0x80], xmm9
0000796da41e39a1  vmovaps [rsp+0x90], xmm10
0000796da41e39aa  vmovaps [rsp+0xA0], xmm11
0000796da41e39b3  vmovaps [rsp+0xB0], xmm12
0000796da41e39bc  vmovaps [rsp+0xC0], xmm13
0000796da41e39c5  vmovaps [rsp+0xD0], xmm14
0000796da41e39ce  vmovaps [rsp+0xE0], xmm15
0000796da41e39d7  sub rsp, 0x30
0000796da41e39db  movaps [rsp], xmm8
0000796da41e39e0  movaps [rsp+0x10], xmm15
0000796da41e39e6  movaps [rsp+0x20], xmm9
0000796da41e39ec  lea rdi, [rsp]
0000796da41e39f0  mov esi, 0x00
0000796da41e39f5  mov rax, 0x5E26CB66A530
0000796da41e39ff  call rax
0000796da41e3a01  movaps xmm8, [rsp]
0000796da41e3a06  add rsp, 0x30
0000796da41e3a0a  vmovaps xmm0, [rsp]
0000796da41e3a0f  vmovaps xmm1, [rsp+0x10]
0000796da41e3a15  vmovaps xmm2, [rsp+0x20]
0000796da41e3a1b  vmovaps xmm3, [rsp+0x30]
0000796da41e3a21  vmovaps xmm4, [rsp+0x40]
0000796da41e3a27  vmovaps xmm5, [rsp+0x50]
0000796da41e3a2d  vmovaps xmm6, [rsp+0x60]
0000796da41e3a33  vmovaps xmm7, [rsp+0x70]
0000796da41e3a39  vmovaps xmm9, [rsp+0x80]
0000796da41e3a42  vmovaps xmm10, [rsp+0x90]
0000796da41e3a4b  vmovaps xmm11, [rsp+0xA0]
0000796da41e3a54  vmovaps xmm12, [rsp+0xB0]
0000796da41e3a5d  vmovaps xmm13, [rsp+0xC0]
0000796da41e3a66  vmovaps xmm14, [rsp+0xD0]
0000796da41e3a6f  vmovaps xmm15, [rsp+0xE0]
0000796da41e3a78  add rsp, 0xF0
0000796da41e3a7f  pop r11
0000796da41e3a81  pop r10
0000796da41e3a83  pop r9
0000796da41e3a85  pop r8
0000796da41e3a87  pop rsi
0000796da41e3a88  pop rdi
0000796da41e3a89  pop rdx
0000796da41e3a8a  pop rcx
0000796da41e3a8b  pop rax
0000796da41e3a8c  add rsp, 0x08
0000796da41e3a90  jmp 0x0000796DA41DF81D
0000796da41e3a95  sub rsp, 0x08
0000796da41e3a99  push rax
0000796da41e3a9a  push rcx
0000796da41e3a9b  push rdx
0000796da41e3a9c  push rdi
0000796da41e3a9d  push rsi
0000796da41e3a9e  push r8
0000796da41e3aa0  push r9
0000796da41e3aa2  push r10
0000796da41e3aa4  push r11
0000796da41e3aa6  sub rsp, 0xF0
0000796da41e3aad  vmovaps [rsp], xmm0
0000796da41e3ab2  vmovaps [rsp+0x10], xmm1
0000796da41e3ab8  vmovaps [rsp+0x20], xmm2
0000796da41e3abe  vmovaps [rsp+0x30], xmm3
0000796da41e3ac4  vmovaps [rsp+0x40], xmm4
0000796da41e3aca  vmovaps [rsp+0x50], xmm5
0000796da41e3ad0  vmovaps [rsp+0x60], xmm6
0000796da41e3ad6  vmovaps [rsp+0x70], xmm7
0000796da41e3adc  vmovaps [rsp+0x80], xmm8
0000796da41e3ae5  vmovaps [rsp+0x90], xmm9
0000796da41e3aee  vmovaps [rsp+0xA0], xmm10
0000796da41e3af7  vmovaps [rsp+0xB0], xmm11
0000796da41e3b00  vmovaps [rsp+0xC0], xmm12
0000796da41e3b09  vmovaps [rsp+0xD0], xmm13
0000796da41e3b12  vmovaps [rsp+0xE0], xmm14
0000796da41e3b1b  sub rsp, 0x30
0000796da41e3b1f  movaps [rsp], xmm15
0000796da41e3b24  movaps [rsp+0x10], xmm11
0000796da41e3b2a  movaps [rsp+0x20], xmm6
0000796da41e3b2f  lea rdi, [rsp]
0000796da41e3b33  mov esi, 0x00
0000796da41e3b38  mov rax, 0x5E26CB66A530
0000796da41e3b42  call rax
0000796da41e3b44  movaps xmm15, [rsp]
0000796da41e3b49  add rsp, 0x30
0000796da41e3b4d  vmovaps xmm0, [rsp]
0000796da41e3b52  vmovaps xmm1, [rsp+0x10]
0000796da41e3b58  vmovaps xmm2, [rsp+0x20]
0000796da41e3b5e  vmovaps xmm3, [rsp+0x30]
0000796da41e3b64  vmovaps xmm4, [rsp+0x40]
0000796da41e3b6a  vmovaps xmm5, [rsp+0x50]
0000796da41e3b70  vmovaps xmm6, [rsp+0x60]
0000796da41e3b76  vmovaps xmm7, [rsp+0x70]
0000796da41e3b7c  vmovaps xmm8, [rsp+0x80]
0000796da41e3b85  vmovaps xmm9, [rsp+0x90]
0000796da41e3b8e  vmovaps xmm10, [rsp+0xA0]
0000796da41e3b97  vmovaps xmm11, [rsp+0xB0]
0000796da41e3ba0  vmovaps xmm12, [rsp+0xC0]
0000796da41e3ba9  vmovaps xmm13, [rsp+0xD0]
0000796da41e3bb2  vmovaps xmm14, [rsp+0xE0]
0000796da41e3bbb  add rsp, 0xF0
0000796da41e3bc2  pop r11
0000796da41e3bc4  pop r10
0000796da41e3bc6  pop r9
0000796da41e3bc8  pop r8
0000796da41e3bca  pop rsi
0000796da41e3bcb  pop rdi
0000796da41e3bcc  pop rdx
0000796da41e3bcd  pop rcx
0000796da41e3bce  pop rax
0000796da41e3bcf  add rsp, 0x08
0000796da41e3bd3  jmp 0x0000796DA41DF838
0000796da41e3bd8  sub rsp, 0x08
0000796da41e3bdc  push rax
0000796da41e3bdd  push rcx
0000796da41e3bde  push rdx
0000796da41e3bdf  push rdi
0000796da41e3be0  push rsi
0000796da41e3be1  push r8
0000796da41e3be3  push r9
0000796da41e3be5  push r10
0000796da41e3be7  push r11
0000796da41e3be9  sub rsp, 0xF0
0000796da41e3bf0  vmovaps [rsp], xmm0
0000796da41e3bf5  vmovaps [rsp+0x10], xmm1
0000796da41e3bfb  vmovaps [rsp+0x20], xmm2
0000796da41e3c01  vmovaps [rsp+0x30], xmm3
0000796da41e3c07  vmovaps [rsp+0x40], xmm4
0000796da41e3c0d  vmovaps [rsp+0x50], xmm5
0000796da41e3c13  vmovaps [rsp+0x60], xmm6
0000796da41e3c19  vmovaps [rsp+0x70], xmm8
0000796da41e3c1f  vmovaps [rsp+0x80], xmm9
0000796da41e3c28  vmovaps [rsp+0x90], xmm10
0000796da41e3c31  vmovaps [rsp+0xA0], xmm11
0000796da41e3c3a  vmovaps [rsp+0xB0], xmm12
0000796da41e3c43  vmovaps [rsp+0xC0], xmm13
0000796da41e3c4c  vmovaps [rsp+0xD0], xmm14
0000796da41e3c55  vmovaps [rsp+0xE0], xmm15
0000796da41e3c5e  sub rsp, 0x30
0000796da41e3c62  movaps [rsp], xmm7
0000796da41e3c66  movaps [rsp+0x10], xmm11
0000796da41e3c6c  movaps [rsp+0x20], xmm9
0000796da41e3c72  lea rdi, [rsp]
0000796da41e3c76  mov esi, 0x00
0000796da41e3c7b  mov rax, 0x5E26CB66A530
0000796da41e3c85  call rax
0000796da41e3c87  movaps xmm7, [rsp]
0000796da41e3c8b  add rsp, 0x30
0000796da41e3c8f  vmovaps xmm0, [rsp]
0000796da41e3c94  vmovaps xmm1, [rsp+0x10]
0000796da41e3c9a  vmovaps xmm2, [rsp+0x20]
0000796da41e3ca0  vmovaps xmm3, [rsp+0x30]
0000796da41e3ca6  vmovaps xmm4, [rsp+0x40]
0000796da41e3cac  vmovaps xmm5, [rsp+0x50]
0000796da41e3cb2  vmovaps xmm6, [rsp+0x60]
0000796da41e3cb8  vmovaps xmm8, [rsp+0x70]
0000796da41e3cbe  vmovaps xmm9, [rsp+0x80]
0000796da41e3cc7  vmovaps xmm10, [rsp+0x90]
0000796da41e3cd0  vmovaps xmm11, [rsp+0xA0]
0000796da41e3cd9  vmovaps xmm12, [rsp+0xB0]
0000796da41e3ce2  vmovaps xmm13, [rsp+0xC0]
0000796da41e3ceb  vmovaps xmm14, [rsp+0xD0]
0000796da41e3cf4  vmovaps xmm15, [rsp+0xE0]
0000796da41e3cfd  add rsp, 0xF0
0000796da41e3d04  pop r11
0000796da41e3d06  pop r10
0000796da41e3d08  pop r9
0000796da41e3d0a  pop r8
0000796da41e3d0c  pop rsi
0000796da41e3d0d  pop rdi
0000796da41e3d0e  pop rdx
0000796da41e3d0f  pop rcx
0000796da41e3d10  pop rax
0000796da41e3d11  add rsp, 0x08
0000796da41e3d15  jmp 0x0000796DA41DF865
0000796da41e3d1a  sub rsp, 0x08
0000796da41e3d1e  push rax
0000796da41e3d1f  push rcx
0000796da41e3d20  push rdx
0000796da41e3d21  push rdi
0000796da41e3d22  push rsi
0000796da41e3d23  push r8
0000796da41e3d25  push r9
0000796da41e3d27  push r10
0000796da41e3d29  push r11
0000796da41e3d2b  sub rsp, 0xF0
0000796da41e3d32  vmovaps [rsp], xmm0
0000796da41e3d37  vmovaps [rsp+0x10], xmm1
0000796da41e3d3d  vmovaps [rsp+0x20], xmm2
0000796da41e3d43  vmovaps [rsp+0x30], xmm3
0000796da41e3d49  vmovaps [rsp+0x40], xmm4
0000796da41e3d4f  vmovaps [rsp+0x50], xmm5
0000796da41e3d55  vmovaps [rsp+0x60], xmm6
0000796da41e3d5b  vmovaps [rsp+0x70], xmm7
0000796da41e3d61  vmovaps [rsp+0x80], xmm8
0000796da41e3d6a  vmovaps [rsp+0x90], xmm9
0000796da41e3d73  vmovaps [rsp+0xA0], xmm10
0000796da41e3d7c  vmovaps [rsp+0xB0], xmm12
0000796da41e3d85  vmovaps [rsp+0xC0], xmm13
0000796da41e3d8e  vmovaps [rsp+0xD0], xmm14
0000796da41e3d97  vmovaps [rsp+0xE0], xmm15
0000796da41e3da0  sub rsp, 0x30
0000796da41e3da4  movaps [rsp], xmm11
0000796da41e3da9  movaps [rsp+0x10], xmm10
0000796da41e3daf  movaps [rsp+0x20], xmm14
0000796da41e3db5  lea rdi, [rsp]
0000796da41e3db9  mov esi, 0x00
0000796da41e3dbe  mov rax, 0x5E26CB66A530
0000796da41e3dc8  call rax
0000796da41e3dca  movaps xmm11, [rsp]
0000796da41e3dcf  add rsp, 0x30
0000796da41e3dd3  vmovaps xmm0, [rsp]
0000796da41e3dd8  vmovaps xmm1, [rsp+0x10]
0000796da41e3dde  vmovaps xmm2, [rsp+0x20]
0000796da41e3de4  vmovaps xmm3, [rsp+0x30]
0000796da41e3dea  vmovaps xmm4, [rsp+0x40]
0000796da41e3df0  vmovaps xmm5, [rsp+0x50]
0000796da41e3df6  vmovaps xmm6, [rsp+0x60]
0000796da41e3dfc  vmovaps xmm7, [rsp+0x70]
0000796da41e3e02  vmovaps xmm8, [rsp+0x80]
0000796da41e3e0b  vmovaps xmm9, [rsp+0x90]
0000796da41e3e14  vmovaps xmm10, [rsp+0xA0]
0000796da41e3e1d  vmovaps xmm12, [rsp+0xB0]
0000796da41e3e26  vmovaps xmm13, [rsp+0xC0]
0000796da41e3e2f  vmovaps xmm14, [rsp+0xD0]
0000796da41e3e38  vmovaps xmm15, [rsp+0xE0]
0000796da41e3e41  add rsp, 0xF0
0000796da41e3e48  pop r11
0000796da41e3e4a  pop r10
0000796da41e3e4c  pop r9
0000796da41e3e4e  pop r8
0000796da41e3e50  pop rsi
0000796da41e3e51  pop rdi
0000796da41e3e52  pop rdx
0000796da41e3e53  pop rcx
0000796da41e3e54  pop rax
0000796da41e3e55  add rsp, 0x08
0000796da41e3e59  jmp 0x0000796DA41DF880
0000796da41e3e5e  call 0x0000796DA40C33A0
0000796da41e3e63  jmp 0x0000796DA41DF88A
0000796da41e3e68  sub rsp, 0x08
0000796da41e3e6c  push rax
0000796da41e3e6d  push rcx
0000796da41e3e6e  push rdx
0000796da41e3e6f  push rdi
0000796da41e3e70  push rsi
0000796da41e3e71  push r8
0000796da41e3e73  push r9
0000796da41e3e75  push r10
0000796da41e3e77  push r11
0000796da41e3e79  sub rsp, 0xF0
0000796da41e3e80  vmovaps [rsp], xmm0
0000796da41e3e85  vmovaps [rsp+0x10], xmm1
0000796da41e3e8b  vmovaps [rsp+0x20], xmm2
0000796da41e3e91  vmovaps [rsp+0x30], xmm3
0000796da41e3e97  vmovaps [rsp+0x40], xmm4
0000796da41e3e9d  vmovaps [rsp+0x50], xmm5
0000796da41e3ea3  vmovaps [rsp+0x60], xmm6
0000796da41e3ea9  vmovaps [rsp+0x70], xmm7
0000796da41e3eaf  vmovaps [rsp+0x80], xmm8
0000796da41e3eb8  vmovaps [rsp+0x90], xmm9
0000796da41e3ec1  vmovaps [rsp+0xA0], xmm11
0000796da41e3eca  vmovaps [rsp+0xB0], xmm12
0000796da41e3ed3  vmovaps [rsp+0xC0], xmm13
0000796da41e3edc  vmovaps [rsp+0xD0], xmm14
0000796da41e3ee5  vmovaps [rsp+0xE0], xmm15
0000796da41e3eee  sub rsp, 0x30
0000796da41e3ef2  movaps [rsp], xmm10
0000796da41e3ef7  movaps [rsp+0x10], xmm1
0000796da41e3efc  movaps [rsp+0x20], xmm12
0000796da41e3f02  lea rdi, [rsp]
0000796da41e3f06  mov esi, 0x00
0000796da41e3f0b  mov rax, 0x5E26CB66A530
0000796da41e3f15  call rax
0000796da41e3f17  movaps xmm10, [rsp]
0000796da41e3f1c  add rsp, 0x30
0000796da41e3f20  vmovaps xmm0, [rsp]
0000796da41e3f25  vmovaps xmm1, [rsp+0x10]
0000796da41e3f2b  vmovaps xmm2, [rsp+0x20]
0000796da41e3f31  vmovaps xmm3, [rsp+0x30]
0000796da41e3f37  vmovaps xmm4, [rsp+0x40]
0000796da41e3f3d  vmovaps xmm5, [rsp+0x50]
0000796da41e3f43  vmovaps xmm6, [rsp+0x60]
0000796da41e3f49  vmovaps xmm7, [rsp+0x70]
0000796da41e3f4f  vmovaps xmm8, [rsp+0x80]
0000796da41e3f58  vmovaps xmm9, [rsp+0x90]
0000796da41e3f61  vmovaps xmm11, [rsp+0xA0]
0000796da41e3f6a  vmovaps xmm12, [rsp+0xB0]
0000796da41e3f73  vmovaps xmm13, [rsp+0xC0]
0000796da41e3f7c  vmovaps xmm14, [rsp+0xD0]
0000796da41e3f85  vmovaps xmm15, [rsp+0xE0]
0000796da41e3f8e  add rsp, 0xF0
0000796da41e3f95  pop r11
0000796da41e3f97  pop r10
0000796da41e3f99  pop r9
0000796da41e3f9b  pop r8
0000796da41e3f9d  pop rsi
0000796da41e3f9e  pop rdi
0000796da41e3f9f  pop rdx
0000796da41e3fa0  pop rcx
0000796da41e3fa1  pop rax
0000796da41e3fa2  add rsp, 0x08
0000796da41e3fa6  jmp 0x0000796DA41DF8AD
0000796da41e3fab  sub rsp, 0x08
0000796da41e3faf  push rax
0000796da41e3fb0  push rcx
0000796da41e3fb1  push rdx
0000796da41e3fb2  push rdi
0000796da41e3fb3  push rsi
0000796da41e3fb4  push r8
0000796da41e3fb6  push r9
0000796da41e3fb8  push r10
0000796da41e3fba  push r11
0000796da41e3fbc  sub rsp, 0xF0
0000796da41e3fc3  vmovaps [rsp], xmm0
0000796da41e3fc8  vmovaps [rsp+0x10], xmm1
0000796da41e3fce  vmovaps [rsp+0x20], xmm2
0000796da41e3fd4  vmovaps [rsp+0x30], xmm3
0000796da41e3fda  vmovaps [rsp+0x40], xmm4
0000796da41e3fe0  vmovaps [rsp+0x50], xmm5
0000796da41e3fe6  vmovaps [rsp+0x60], xmm6
0000796da41e3fec  vmovaps [rsp+0x70], xmm7
0000796da41e3ff2  vmovaps [rsp+0x80], xmm8
0000796da41e3ffb  vmovaps [rsp+0x90], xmm9
0000796da41e4004  vmovaps [rsp+0xA0], xmm10
0000796da41e400d  vmovaps [rsp+0xB0], xmm11
0000796da41e4016  vmovaps [rsp+0xC0], xmm13
0000796da41e401f  vmovaps [rsp+0xD0], xmm14
0000796da41e4028  vmovaps [rsp+0xE0], xmm15
0000796da41e4031  sub rsp, 0x30
0000796da41e4035  movaps [rsp], xmm12
0000796da41e403a  movaps [rsp+0x10], xmm14
0000796da41e4040  movaps [rsp+0x20], xmm1
0000796da41e4045  lea rdi, [rsp]
0000796da41e4049  mov esi, 0x00
0000796da41e404e  mov rax, 0x5E26CB66A530
0000796da41e4058  call rax
0000796da41e405a  movaps xmm12, [rsp]
0000796da41e405f  add rsp, 0x30
0000796da41e4063  vmovaps xmm0, [rsp]
0000796da41e4068  vmovaps xmm1, [rsp+0x10]
0000796da41e406e  vmovaps xmm2, [rsp+0x20]
0000796da41e4074  vmovaps xmm3, [rsp+0x30]
0000796da41e407a  vmovaps xmm4, [rsp+0x40]
0000796da41e4080  vmovaps xmm5, [rsp+0x50]
0000796da41e4086  vmovaps xmm6, [rsp+0x60]
0000796da41e408c  vmovaps xmm7, [rsp+0x70]
0000796da41e4092  vmovaps xmm8, [rsp+0x80]
0000796da41e409b  vmovaps xmm9, [rsp+0x90]
0000796da41e40a4  vmovaps xmm10, [rsp+0xA0]
0000796da41e40ad  vmovaps xmm11, [rsp+0xB0]
0000796da41e40b6  vmovaps xmm13, [rsp+0xC0]
0000796da41e40bf  vmovaps xmm14, [rsp+0xD0]
0000796da41e40c8  vmovaps xmm15, [rsp+0xE0]
0000796da41e40d1  add rsp, 0xF0
0000796da41e40d8  pop r11
0000796da41e40da  pop r10
0000796da41e40dc  pop r9
0000796da41e40de  pop r8
0000796da41e40e0  pop rsi
0000796da41e40e1  pop rdi
0000796da41e40e2  pop rdx
0000796da41e40e3  pop rcx
0000796da41e40e4  pop rax
0000796da41e40e5  add rsp, 0x08
0000796da41e40e9  jmp 0x0000796DA41DF8DC
0000796da41e40ee  sub rsp, 0x08
0000796da41e40f2  push rax
0000796da41e40f3  push rcx
0000796da41e40f4  push rdx
0000796da41e40f5  push rdi
0000796da41e40f6  push rsi
0000796da41e40f7  push r8
0000796da41e40f9  push r9
0000796da41e40fb  push r10
0000796da41e40fd  push r11
0000796da41e40ff  sub rsp, 0xF0
0000796da41e4106  vmovaps [rsp], xmm0
0000796da41e410b  vmovaps [rsp+0x10], xmm1
0000796da41e4111  vmovaps [rsp+0x20], xmm2
0000796da41e4117  vmovaps [rsp+0x30], xmm3
0000796da41e411d  vmovaps [rsp+0x40], xmm4
0000796da41e4123  vmovaps [rsp+0x50], xmm5
0000796da41e4129  vmovaps [rsp+0x60], xmm6
0000796da41e412f  vmovaps [rsp+0x70], xmm7
0000796da41e4135  vmovaps [rsp+0x80], xmm8
0000796da41e413e  vmovaps [rsp+0x90], xmm9
0000796da41e4147  vmovaps [rsp+0xA0], xmm10
0000796da41e4150  vmovaps [rsp+0xB0], xmm11
0000796da41e4159  vmovaps [rsp+0xC0], xmm12
0000796da41e4162  vmovaps [rsp+0xD0], xmm13
0000796da41e416b  vmovaps [rsp+0xE0], xmm15
0000796da41e4174  sub rsp, 0x30
0000796da41e4178  movaps [rsp], xmm14
0000796da41e417d  movaps [rsp+0x10], xmm9
0000796da41e4183  movaps [rsp+0x20], xmm1
0000796da41e4188  lea rdi, [rsp]
0000796da41e418c  mov esi, 0x00
0000796da41e4191  mov rax, 0x5E26CB66A530
0000796da41e419b  call rax
0000796da41e419d  movaps xmm14, [rsp]
0000796da41e41a2  add rsp, 0x30
0000796da41e41a6  vmovaps xmm0, [rsp]
0000796da41e41ab  vmovaps xmm1, [rsp+0x10]
0000796da41e41b1  vmovaps xmm2, [rsp+0x20]
0000796da41e41b7  vmovaps xmm3, [rsp+0x30]
0000796da41e41bd  vmovaps xmm4, [rsp+0x40]
0000796da41e41c3  vmovaps xmm5, [rsp+0x50]
0000796da41e41c9  vmovaps xmm6, [rsp+0x60]
0000796da41e41cf  vmovaps xmm7, [rsp+0x70]
0000796da41e41d5  vmovaps xmm8, [rsp+0x80]
0000796da41e41de  vmovaps xmm9, [rsp+0x90]
0000796da41e41e7  vmovaps xmm10, [rsp+0xA0]
0000796da41e41f0  vmovaps xmm11, [rsp+0xB0]
0000796da41e41f9  vmovaps xmm12, [rsp+0xC0]
0000796da41e4202  vmovaps xmm13, [rsp+0xD0]
0000796da41e420b  vmovaps xmm15, [rsp+0xE0]
0000796da41e4214  add rsp, 0xF0
0000796da41e421b  pop r11
0000796da41e421d  pop r10
0000796da41e421f  pop r9
0000796da41e4221  pop r8
0000796da41e4223  pop rsi
0000796da41e4224  pop rdi
0000796da41e4225  pop rdx
0000796da41e4226  pop rcx
0000796da41e4227  pop rax
0000796da41e4228  add rsp, 0x08
0000796da41e422c  jmp 0x0000796DA41DF90B
0000796da41e4231  sub rsp, 0x08
0000796da41e4235  push rax
0000796da41e4236  push rcx
0000796da41e4237  push rdx
0000796da41e4238  push rdi
0000796da41e4239  push rsi
0000796da41e423a  push r8
0000796da41e423c  push r9
0000796da41e423e  push r10
0000796da41e4240  push r11
0000796da41e4242  sub rsp, 0xF0
0000796da41e4249  vmovaps [rsp], xmm0
0000796da41e424e  vmovaps [rsp+0x10], xmm2
0000796da41e4254  vmovaps [rsp+0x20], xmm3
0000796da41e425a  vmovaps [rsp+0x30], xmm4
0000796da41e4260  vmovaps [rsp+0x40], xmm5
0000796da41e4266  vmovaps [rsp+0x50], xmm6
0000796da41e426c  vmovaps [rsp+0x60], xmm7
0000796da41e4272  vmovaps [rsp+0x70], xmm8
0000796da41e4278  vmovaps [rsp+0x80], xmm9
0000796da41e4281  vmovaps [rsp+0x90], xmm10
0000796da41e428a  vmovaps [rsp+0xA0], xmm11
0000796da41e4293  vmovaps [rsp+0xB0], xmm12
0000796da41e429c  vmovaps [rsp+0xC0], xmm13
0000796da41e42a5  vmovaps [rsp+0xD0], xmm14
0000796da41e42ae  vmovaps [rsp+0xE0], xmm15
0000796da41e42b7  sub rsp, 0x30
0000796da41e42bb  movaps [rsp], xmm1
0000796da41e42bf  movaps [rsp+0x10], xmm13
0000796da41e42c5  movaps [rsp+0x20], xmm8
0000796da41e42cb  lea rdi, [rsp]
0000796da41e42cf  mov esi, 0x00
0000796da41e42d4  mov rax, 0x5E26CB66A530
0000796da41e42de  call rax
0000796da41e42e0  movaps xmm1, [rsp]
0000796da41e42e4  add rsp, 0x30
0000796da41e42e8  vmovaps xmm0, [rsp]
0000796da41e42ed  vmovaps xmm2, [rsp+0x10]
0000796da41e42f3  vmovaps xmm3, [rsp+0x20]
0000796da41e42f9  vmovaps xmm4, [rsp+0x30]
0000796da41e42ff  vmovaps xmm5, [rsp+0x40]
0000796da41e4305  vmovaps xmm6, [rsp+0x50]
0000796da41e430b  vmovaps xmm7, [rsp+0x60]
0000796da41e4311  vmovaps xmm8, [rsp+0x70]
0000796da41e4317  vmovaps xmm9, [rsp+0x80]
0000796da41e4320  vmovaps xmm10, [rsp+0x90]
0000796da41e4329  vmovaps xmm11, [rsp+0xA0]
0000796da41e4332  vmovaps xmm12, [rsp+0xB0]
0000796da41e433b  vmovaps xmm13, [rsp+0xC0]
0000796da41e4344  vmovaps xmm14, [rsp+0xD0]
0000796da41e434d  vmovaps xmm15, [rsp+0xE0]
0000796da41e4356  add rsp, 0xF0
0000796da41e435d  pop r11
0000796da41e435f  pop r10
0000796da41e4361  pop r9
0000796da41e4363  pop r8
0000796da41e4365  pop rsi
0000796da41e4366  pop rdi
0000796da41e4367  pop rdx
0000796da41e4368  pop rcx
0000796da41e4369  pop rax
0000796da41e436a  add rsp, 0x08
0000796da41e436e  jmp 0x0000796DA41DF92D
0000796da41e4373  call 0x0000796DA400C260
0000796da41e4378  jmp 0x0000796DA41DF93B
0000796da41e437d  call 0x0000796DA40BD750
0000796da41e4382  jmp 0x0000796DA41DF945
0000796da41e4387  sub rsp, 0x08
0000796da41e438b  push rax
0000796da41e438c  push rcx
0000796da41e438d  push rdx
0000796da41e438e  push rdi
0000796da41e438f  push rsi
0000796da41e4390  push r8
0000796da41e4392  push r9
0000796da41e4394  push r10
0000796da41e4396  push r11
0000796da41e4398  sub rsp, 0xF0
0000796da41e439f  vmovaps [rsp], xmm0
0000796da41e43a4  vmovaps [rsp+0x10], xmm1
0000796da41e43aa  vmovaps [rsp+0x20], xmm2
0000796da41e43b0  vmovaps [rsp+0x30], xmm3
0000796da41e43b6  vmovaps [rsp+0x40], xmm4
0000796da41e43bc  vmovaps [rsp+0x50], xmm5
0000796da41e43c2  vmovaps [rsp+0x60], xmm6
0000796da41e43c8  vmovaps [rsp+0x70], xmm7
0000796da41e43ce  vmovaps [rsp+0x80], xmm9
0000796da41e43d7  vmovaps [rsp+0x90], xmm10
0000796da41e43e0  vmovaps [rsp+0xA0], xmm11
0000796da41e43e9  vmovaps [rsp+0xB0], xmm12
0000796da41e43f2  vmovaps [rsp+0xC0], xmm13
0000796da41e43fb  vmovaps [rsp+0xD0], xmm14
0000796da41e4404  vmovaps [rsp+0xE0], xmm15
0000796da41e440d  sub rsp, 0x30
0000796da41e4411  movaps [rsp], xmm8
0000796da41e4416  movaps [rsp+0x10], xmm15
0000796da41e441c  movaps [rsp+0x20], xmm7
0000796da41e4421  lea rdi, [rsp]
0000796da41e4425  mov esi, 0x00
0000796da41e442a  mov rax, 0x5E26CB66A530
0000796da41e4434  call rax
0000796da41e4436  movaps xmm8, [rsp]
0000796da41e443b  add rsp, 0x30
0000796da41e443f  vmovaps xmm0, [rsp]
0000796da41e4444  vmovaps xmm1, [rsp+0x10]
0000796da41e444a  vmovaps xmm2, [rsp+0x20]
0000796da41e4450  vmovaps xmm3, [rsp+0x30]
0000796da41e4456  vmovaps xmm4, [rsp+0x40]
0000796da41e445c  vmovaps xmm5, [rsp+0x50]
0000796da41e4462  vmovaps xmm6, [rsp+0x60]
0000796da41e4468  vmovaps xmm7, [rsp+0x70]
0000796da41e446e  vmovaps xmm9, [rsp+0x80]
0000796da41e4477  vmovaps xmm10, [rsp+0x90]
0000796da41e4480  vmovaps xmm11, [rsp+0xA0]
0000796da41e4489  vmovaps xmm12, [rsp+0xB0]
0000796da41e4492  vmovaps xmm13, [rsp+0xC0]
0000796da41e449b  vmovaps xmm14, [rsp+0xD0]
0000796da41e44a4  vmovaps xmm15, [rsp+0xE0]
0000796da41e44ad  add rsp, 0xF0
0000796da41e44b4  pop r11
0000796da41e44b6  pop r10
0000796da41e44b8  pop r9
0000796da41e44ba  pop r8
0000796da41e44bc  pop rsi
0000796da41e44bd  pop rdi
0000796da41e44be  pop rdx
0000796da41e44bf  pop rcx
0000796da41e44c0  pop rax
0000796da41e44c1  add rsp, 0x08
0000796da41e44c5  jmp 0x0000796DA41DF967
0000796da41e44ca  sub rsp, 0x08
0000796da41e44ce  push rax
0000796da41e44cf  push rcx
0000796da41e44d0  push rdx
0000796da41e44d1  push rdi
0000796da41e44d2  push rsi
0000796da41e44d3  push r8
0000796da41e44d5  push r9
0000796da41e44d7  push r10
0000796da41e44d9  push r11
0000796da41e44db  sub rsp, 0xF0
0000796da41e44e2  vmovaps [rsp], xmm0
0000796da41e44e7  vmovaps [rsp+0x10], xmm1
0000796da41e44ed  vmovaps [rsp+0x20], xmm2
0000796da41e44f3  vmovaps [rsp+0x30], xmm3
0000796da41e44f9  vmovaps [rsp+0x40], xmm4
0000796da41e44ff  vmovaps [rsp+0x50], xmm5
0000796da41e4505  vmovaps [rsp+0x60], xmm6
0000796da41e450b  vmovaps [rsp+0x70], xmm8
0000796da41e4511  vmovaps [rsp+0x80], xmm9
0000796da41e451a  vmovaps [rsp+0x90], xmm10
0000796da41e4523  vmovaps [rsp+0xA0], xmm11
0000796da41e452c  vmovaps [rsp+0xB0], xmm12
0000796da41e4535  vmovaps [rsp+0xC0], xmm13
0000796da41e453e  vmovaps [rsp+0xD0], xmm14
0000796da41e4547  vmovaps [rsp+0xE0], xmm15
0000796da41e4550  sub rsp, 0x30
0000796da41e4554  movaps [rsp], xmm7
0000796da41e4558  movaps [rsp+0x10], xmm9
0000796da41e455e  movaps [rsp+0x20], xmm15
0000796da41e4564  lea rdi, [rsp]
0000796da41e4568  mov esi, 0x00
0000796da41e456d  mov rax, 0x5E26CB66A530
0000796da41e4577  call rax
0000796da41e4579  movaps xmm7, [rsp]
0000796da41e457d  add rsp, 0x30
0000796da41e4581  vmovaps xmm0, [rsp]
0000796da41e4586  vmovaps xmm1, [rsp+0x10]
0000796da41e458c  vmovaps xmm2, [rsp+0x20]
0000796da41e4592  vmovaps xmm3, [rsp+0x30]
0000796da41e4598  vmovaps xmm4, [rsp+0x40]
0000796da41e459e  vmovaps xmm5, [rsp+0x50]
0000796da41e45a4  vmovaps xmm6, [rsp+0x60]
0000796da41e45aa  vmovaps xmm8, [rsp+0x70]
0000796da41e45b0  vmovaps xmm9, [rsp+0x80]
0000796da41e45b9  vmovaps xmm10, [rsp+0x90]
0000796da41e45c2  vmovaps xmm11, [rsp+0xA0]
0000796da41e45cb  vmovaps xmm12, [rsp+0xB0]
0000796da41e45d4  vmovaps xmm13, [rsp+0xC0]
0000796da41e45dd  vmovaps xmm14, [rsp+0xD0]
0000796da41e45e6  vmovaps xmm15, [rsp+0xE0]
0000796da41e45ef  add rsp, 0xF0
0000796da41e45f6  pop r11
0000796da41e45f8  pop r10
0000796da41e45fa  pop r9
0000796da41e45fc  pop r8
0000796da41e45fe  pop rsi
0000796da41e45ff  pop rdi
0000796da41e4600  pop rdx
0000796da41e4601  pop rcx
0000796da41e4602  pop rax
0000796da41e4603  add rsp, 0x08
0000796da41e4607  jmp 0x0000796DA41DF994
0000796da41e460c  sub rsp, 0x08
0000796da41e4610  push rax
0000796da41e4611  push rcx
0000796da41e4612  push rdx
0000796da41e4613  push rdi
0000796da41e4614  push rsi
0000796da41e4615  push r8
0000796da41e4617  push r9
0000796da41e4619  push r10
0000796da41e461b  push r11
0000796da41e461d  sub rsp, 0xF0
0000796da41e4624  vmovaps [rsp], xmm0
0000796da41e4629  vmovaps [rsp+0x10], xmm1
0000796da41e462f  vmovaps [rsp+0x20], xmm2
0000796da41e4635  vmovaps [rsp+0x30], xmm3
0000796da41e463b  vmovaps [rsp+0x40], xmm4
0000796da41e4641  vmovaps [rsp+0x50], xmm5
0000796da41e4647  vmovaps [rsp+0x60], xmm6
0000796da41e464d  vmovaps [rsp+0x70], xmm7
0000796da41e4653  vmovaps [rsp+0x80], xmm8
0000796da41e465c  vmovaps [rsp+0x90], xmm10
0000796da41e4665  vmovaps [rsp+0xA0], xmm11
0000796da41e466e  vmovaps [rsp+0xB0], xmm12
0000796da41e4677  vmovaps [rsp+0xC0], xmm13
0000796da41e4680  vmovaps [rsp+0xD0], xmm14
0000796da41e4689  vmovaps [rsp+0xE0], xmm15
0000796da41e4692  sub rsp, 0x30
0000796da41e4696  movaps [rsp], xmm9
0000796da41e469b  movaps [rsp+0x10], xmm13
0000796da41e46a1  movaps [rsp+0x20], xmm15
0000796da41e46a7  lea rdi, [rsp]
0000796da41e46ab  mov esi, 0x00
0000796da41e46b0  mov rax, 0x5E26CB66A530
0000796da41e46ba  call rax
0000796da41e46bc  movaps xmm9, [rsp]
0000796da41e46c1  add rsp, 0x30
0000796da41e46c5  vmovaps xmm0, [rsp]
0000796da41e46ca  vmovaps xmm1, [rsp+0x10]
0000796da41e46d0  vmovaps xmm2, [rsp+0x20]
0000796da41e46d6  vmovaps xmm3, [rsp+0x30]
0000796da41e46dc  vmovaps xmm4, [rsp+0x40]
0000796da41e46e2  vmovaps xmm5, [rsp+0x50]
0000796da41e46e8  vmovaps xmm6, [rsp+0x60]
0000796da41e46ee  vmovaps xmm7, [rsp+0x70]
0000796da41e46f4  vmovaps xmm8, [rsp+0x80]
0000796da41e46fd  vmovaps xmm10, [rsp+0x90]
0000796da41e4706  vmovaps xmm11, [rsp+0xA0]
0000796da41e470f  vmovaps xmm12, [rsp+0xB0]
0000796da41e4718  vmovaps xmm13, [rsp+0xC0]
0000796da41e4721  vmovaps xmm14, [rsp+0xD0]
0000796da41e472a  vmovaps xmm15, [rsp+0xE0]
0000796da41e4733  add rsp, 0xF0
0000796da41e473a  pop r11
0000796da41e473c  pop r10
0000796da41e473e  pop r9
0000796da41e4740  pop r8
0000796da41e4742  pop rsi
0000796da41e4743  pop rdi
0000796da41e4744  pop rdx
0000796da41e4745  pop rcx
0000796da41e4746  pop rax
0000796da41e4747  add rsp, 0x08
0000796da41e474b  jmp 0x0000796DA41DF9C2
0000796da41e4750  sub rsp, 0x08
0000796da41e4754  push rax
0000796da41e4755  push rcx
0000796da41e4756  push rdx
0000796da41e4757  push rdi
0000796da41e4758  push rsi
0000796da41e4759  push r8
0000796da41e475b  push r9
0000796da41e475d  push r10
0000796da41e475f  push r11
0000796da41e4761  sub rsp, 0xF0
0000796da41e4768  vmovaps [rsp], xmm0
0000796da41e476d  vmovaps [rsp+0x10], xmm1
0000796da41e4773  vmovaps [rsp+0x20], xmm2
0000796da41e4779  vmovaps [rsp+0x30], xmm3
0000796da41e477f  vmovaps [rsp+0x40], xmm4
0000796da41e4785  vmovaps [rsp+0x50], xmm5
0000796da41e478b  vmovaps [rsp+0x60], xmm6
0000796da41e4791  vmovaps [rsp+0x70], xmm7
0000796da41e4797  vmovaps [rsp+0x80], xmm8
0000796da41e47a0  vmovaps [rsp+0x90], xmm9
0000796da41e47a9  vmovaps [rsp+0xA0], xmm10
0000796da41e47b2  vmovaps [rsp+0xB0], xmm11
0000796da41e47bb  vmovaps [rsp+0xC0], xmm12
0000796da41e47c4  vmovaps [rsp+0xD0], xmm13
0000796da41e47cd  vmovaps [rsp+0xE0], xmm14
0000796da41e47d6  sub rsp, 0x30
0000796da41e47da  movaps [rsp], xmm15
0000796da41e47df  movaps [rsp+0x10], xmm11
0000796da41e47e5  movaps [rsp+0x20], xmm12
0000796da41e47eb  lea rdi, [rsp]
0000796da41e47ef  mov esi, 0x00
0000796da41e47f4  mov rax, 0x5E26CB66A530
0000796da41e47fe  call rax
0000796da41e4800  movaps xmm15, [rsp]
0000796da41e4805  add rsp, 0x30
0000796da41e4809  vmovaps xmm0, [rsp]
0000796da41e480e  vmovaps xmm1, [rsp+0x10]
0000796da41e4814  vmovaps xmm2, [rsp+0x20]
0000796da41e481a  vmovaps xmm3, [rsp+0x30]
0000796da41e4820  vmovaps xmm4, [rsp+0x40]
0000796da41e4826  vmovaps xmm5, [rsp+0x50]
0000796da41e482c  vmovaps xmm6, [rsp+0x60]
0000796da41e4832  vmovaps xmm7, [rsp+0x70]
0000796da41e4838  vmovaps xmm8, [rsp+0x80]
0000796da41e4841  vmovaps xmm9, [rsp+0x90]
0000796da41e484a  vmovaps xmm10, [rsp+0xA0]
0000796da41e4853  vmovaps xmm11, [rsp+0xB0]
0000796da41e485c  vmovaps xmm12, [rsp+0xC0]
0000796da41e4865  vmovaps xmm13, [rsp+0xD0]
0000796da41e486e  vmovaps xmm14, [rsp+0xE0]
0000796da41e4877  add rsp, 0xF0
0000796da41e487e  pop r11
0000796da41e4880  pop r10
0000796da41e4882  pop r9
0000796da41e4884  pop r8
0000796da41e4886  pop rsi
0000796da41e4887  pop rdi
0000796da41e4888  pop rdx
0000796da41e4889  pop rcx
0000796da41e488a  pop rax
0000796da41e488b  add rsp, 0x08
0000796da41e488f  jmp 0x0000796DA41DF9DD
0000796da41e4894  sub rsp, 0x08
0000796da41e4898  push rax
0000796da41e4899  push rcx
0000796da41e489a  push rdx
0000796da41e489b  push rdi
0000796da41e489c  push rsi
0000796da41e489d  push r8
0000796da41e489f  push r9
0000796da41e48a1  push r10
0000796da41e48a3  push r11
0000796da41e48a5  sub rsp, 0xF0
0000796da41e48ac  vmovaps [rsp], xmm0
0000796da41e48b1  vmovaps [rsp+0x10], xmm1
0000796da41e48b7  vmovaps [rsp+0x20], xmm2
0000796da41e48bd  vmovaps [rsp+0x30], xmm3
0000796da41e48c3  vmovaps [rsp+0x40], xmm4
0000796da41e48c9  vmovaps [rsp+0x50], xmm5
0000796da41e48cf  vmovaps [rsp+0x60], xmm6
0000796da41e48d5  vmovaps [rsp+0x70], xmm7
0000796da41e48db  vmovaps [rsp+0x80], xmm8
0000796da41e48e4  vmovaps [rsp+0x90], xmm9
0000796da41e48ed  vmovaps [rsp+0xA0], xmm10
0000796da41e48f6  vmovaps [rsp+0xB0], xmm11
0000796da41e48ff  vmovaps [rsp+0xC0], xmm12
0000796da41e4908  vmovaps [rsp+0xD0], xmm14
0000796da41e4911  vmovaps [rsp+0xE0], xmm15
0000796da41e491a  sub rsp, 0x30
0000796da41e491e  movaps [rsp], xmm13
0000796da41e4923  movaps [rsp+0x10], xmm10
0000796da41e4929  movaps [rsp+0x20], xmm14
0000796da41e492f  lea rdi, [rsp]
0000796da41e4933  mov esi, 0x00
0000796da41e4938  mov rax, 0x5E26CB66A530
0000796da41e4942  call rax
0000796da41e4944  movaps xmm13, [rsp]
0000796da41e4949  add rsp, 0x30
0000796da41e494d  vmovaps xmm0, [rsp]
0000796da41e4952  vmovaps xmm1, [rsp+0x10]
0000796da41e4958  vmovaps xmm2, [rsp+0x20]
0000796da41e495e  vmovaps xmm3, [rsp+0x30]
0000796da41e4964  vmovaps xmm4, [rsp+0x40]
0000796da41e496a  vmovaps xmm5, [rsp+0x50]
0000796da41e4970  vmovaps xmm6, [rsp+0x60]
0000796da41e4976  vmovaps xmm7, [rsp+0x70]
0000796da41e497c  vmovaps xmm8, [rsp+0x80]
0000796da41e4985  vmovaps xmm9, [rsp+0x90]
0000796da41e498e  vmovaps xmm10, [rsp+0xA0]
0000796da41e4997  vmovaps xmm11, [rsp+0xB0]
0000796da41e49a0  vmovaps xmm12, [rsp+0xC0]
0000796da41e49a9  vmovaps xmm14, [rsp+0xD0]
0000796da41e49b2  vmovaps xmm15, [rsp+0xE0]
0000796da41e49bb  add rsp, 0xF0
0000796da41e49c2  pop r11
0000796da41e49c4  pop r10
0000796da41e49c6  pop r9
0000796da41e49c8  pop r8
0000796da41e49ca  pop rsi
0000796da41e49cb  pop rdi
0000796da41e49cc  pop rdx
0000796da41e49cd  pop rcx
0000796da41e49ce  pop rax
0000796da41e49cf  add rsp, 0x08
0000796da41e49d3  jmp 0x0000796DA41DFA00
0000796da41e49d8  sub rsp, 0x08
0000796da41e49dc  push rax
0000796da41e49dd  push rcx
0000796da41e49de  push rdx
0000796da41e49df  push rdi
0000796da41e49e0  push rsi
0000796da41e49e1  push r8
0000796da41e49e3  push r9
0000796da41e49e5  push r10
0000796da41e49e7  push r11
0000796da41e49e9  sub rsp, 0xF0
0000796da41e49f0  vmovaps [rsp], xmm0
0000796da41e49f5  vmovaps [rsp+0x10], xmm1
0000796da41e49fb  vmovaps [rsp+0x20], xmm2
0000796da41e4a01  vmovaps [rsp+0x30], xmm3
0000796da41e4a07  vmovaps [rsp+0x40], xmm4
0000796da41e4a0d  vmovaps [rsp+0x50], xmm5
0000796da41e4a13  vmovaps [rsp+0x60], xmm6
0000796da41e4a19  vmovaps [rsp+0x70], xmm7
0000796da41e4a1f  vmovaps [rsp+0x80], xmm8
0000796da41e4a28  vmovaps [rsp+0x90], xmm9
0000796da41e4a31  vmovaps [rsp+0xA0], xmm10
0000796da41e4a3a  vmovaps [rsp+0xB0], xmm11
0000796da41e4a43  vmovaps [rsp+0xC0], xmm12
0000796da41e4a4c  vmovaps [rsp+0xD0], xmm13
0000796da41e4a55  vmovaps [rsp+0xE0], xmm15
0000796da41e4a5e  sub rsp, 0x30
0000796da41e4a62  movaps [rsp], xmm14
0000796da41e4a67  movaps [rsp+0x10], xmm1
0000796da41e4a6c  movaps [rsp+0x20], xmm7
0000796da41e4a71  lea rdi, [rsp]
0000796da41e4a75  mov esi, 0x00
0000796da41e4a7a  mov rax, 0x5E26CB66A530
0000796da41e4a84  call rax
0000796da41e4a86  movaps xmm14, [rsp]
0000796da41e4a8b  add rsp, 0x30
0000796da41e4a8f  vmovaps xmm0, [rsp]
0000796da41e4a94  vmovaps xmm1, [rsp+0x10]
0000796da41e4a9a  vmovaps xmm2, [rsp+0x20]
0000796da41e4aa0  vmovaps xmm3, [rsp+0x30]
0000796da41e4aa6  vmovaps xmm4, [rsp+0x40]
0000796da41e4aac  vmovaps xmm5, [rsp+0x50]
0000796da41e4ab2  vmovaps xmm6, [rsp+0x60]
0000796da41e4ab8  vmovaps xmm7, [rsp+0x70]
0000796da41e4abe  vmovaps xmm8, [rsp+0x80]
0000796da41e4ac7  vmovaps xmm9, [rsp+0x90]
0000796da41e4ad0  vmovaps xmm10, [rsp+0xA0]
0000796da41e4ad9  vmovaps xmm11, [rsp+0xB0]
0000796da41e4ae2  vmovaps xmm12, [rsp+0xC0]
0000796da41e4aeb  vmovaps xmm13, [rsp+0xD0]
0000796da41e4af4  vmovaps xmm15, [rsp+0xE0]
0000796da41e4afd  add rsp, 0xF0
0000796da41e4b04  pop r11
0000796da41e4b06  pop r10
0000796da41e4b08  pop r9
0000796da41e4b0a  pop r8
0000796da41e4b0c  pop rsi
0000796da41e4b0d  pop rdi
0000796da41e4b0e  pop rdx
0000796da41e4b0f  pop rcx
0000796da41e4b10  pop rax
0000796da41e4b11  add rsp, 0x08
0000796da41e4b15  jmp 0x0000796DA41DFA23
0000796da41e4b1a  sub rsp, 0x08
0000796da41e4b1e  push rax
0000796da41e4b1f  push rcx
0000796da41e4b20  push rdx
0000796da41e4b21  push rdi
0000796da41e4b22  push rsi
0000796da41e4b23  push r8
0000796da41e4b25  push r9
0000796da41e4b27  push r10
0000796da41e4b29  push r11
0000796da41e4b2b  sub rsp, 0xF0
0000796da41e4b32  vmovaps [rsp], xmm0
0000796da41e4b37  vmovaps [rsp+0x10], xmm2
0000796da41e4b3d  vmovaps [rsp+0x20], xmm3
0000796da41e4b43  vmovaps [rsp+0x30], xmm4
0000796da41e4b49  vmovaps [rsp+0x40], xmm5
0000796da41e4b4f  vmovaps [rsp+0x50], xmm6
0000796da41e4b55  vmovaps [rsp+0x60], xmm7
0000796da41e4b5b  vmovaps [rsp+0x70], xmm8
0000796da41e4b61  vmovaps [rsp+0x80], xmm9
0000796da41e4b6a  vmovaps [rsp+0x90], xmm10
0000796da41e4b73  vmovaps [rsp+0xA0], xmm11
0000796da41e4b7c  vmovaps [rsp+0xB0], xmm12
0000796da41e4b85  vmovaps [rsp+0xC0], xmm13
0000796da41e4b8e  vmovaps [rsp+0xD0], xmm14
0000796da41e4b97  vmovaps [rsp+0xE0], xmm15
0000796da41e4ba0  sub rsp, 0x30
0000796da41e4ba4  movaps [rsp], xmm1
0000796da41e4ba8  movaps [rsp+0x10], xmm8
0000796da41e4bae  movaps [rsp+0x20], xmm9
0000796da41e4bb4  lea rdi, [rsp]
0000796da41e4bb8  mov esi, 0x00
0000796da41e4bbd  mov rax, 0x5E26CB66A530
0000796da41e4bc7  call rax
0000796da41e4bc9  movaps xmm1, [rsp]
0000796da41e4bcd  add rsp, 0x30
0000796da41e4bd1  vmovaps xmm0, [rsp]
0000796da41e4bd6  vmovaps xmm2, [rsp+0x10]
0000796da41e4bdc  vmovaps xmm3, [rsp+0x20]
0000796da41e4be2  vmovaps xmm4, [rsp+0x30]
0000796da41e4be8  vmovaps xmm5, [rsp+0x40]
0000796da41e4bee  vmovaps xmm6, [rsp+0x50]
0000796da41e4bf4  vmovaps xmm7, [rsp+0x60]
0000796da41e4bfa  vmovaps xmm8, [rsp+0x70]
0000796da41e4c00  vmovaps xmm9, [rsp+0x80]
0000796da41e4c09  vmovaps xmm10, [rsp+0x90]
0000796da41e4c12  vmovaps xmm11, [rsp+0xA0]
0000796da41e4c1b  vmovaps xmm12, [rsp+0xB0]
0000796da41e4c24  vmovaps xmm13, [rsp+0xC0]
0000796da41e4c2d  vmovaps xmm14, [rsp+0xD0]
0000796da41e4c36  vmovaps xmm15, [rsp+0xE0]
0000796da41e4c3f  add rsp, 0xF0
0000796da41e4c46  pop r11
0000796da41e4c48  pop r10
0000796da41e4c4a  pop r9
0000796da41e4c4c  pop r8
0000796da41e4c4e  pop rsi
0000796da41e4c4f  pop rdi
0000796da41e4c50  pop rdx
0000796da41e4c51  pop rcx
0000796da41e4c52  pop rax
0000796da41e4c53  add rsp, 0x08
0000796da41e4c57  jmp 0x0000796DA41DFA45
0000796da41e4c5c  call 0x0000796DA40E5940
0000796da41e4c61  jmp 0x0000796DA41DFA53
0000796da41e4c66  call 0x0000796DA400C380
0000796da41e4c6b  jmp 0x0000796DA41DFA5D
0000796da41e4c70  call 0x0000796DA400D600
0000796da41e4c75  jmp 0x0000796DA41DFA67
0000796da41e4c7a  call 0x0000796DA3FFF540
0000796da41e4c7f  jmp 0x0000796DA41DFA71
0000796da41e4c84  int3
0000796da41e4c85  nop [rax+rax*1], ax
0000796da41e4c8e  nop
0000796da41e4c90  mov qword ptr [r15+0x40], 0x430000
0000796da41e4c98  mov eax, 0x430CC0
0000796da41e4c9d  mov r14, [r13+rax*1]
0000796da41e4ca2  movq xmm1, r14
0000796da41e4ca7  mov rax, [r15+0x50]
0000796da41e4cab  movups xmm15, [r13+rax*1]
0000796da41e4cb1  movaps [r15+0x120], xmm15
0000796da41e4cb9  mov qword ptr [r15+0x48], 0x10
0000796da41e4cc1  xor eax, eax
0000796da41e4cc3  mov r14d, 0x10
0000796da41e4cc9  mov r12d, 0x200
0000796da41e4ccf  cmp r14, r12
0000796da41e4cd2  cmc
0000796da41e4cd3  lahf
0000796da41e4cd4  seto al
0000796da41e4cd7  mov [r15+0x108], eax
0000796da41e4cde  pextrq rax, xmm15, 0x01
0000796da41e4ce5  movq xmm14, rax
0000796da41e4cea  movaps [r15+0x130], xmm14
0000796da41e4cf2  movq rax, xmm1
0000796da41e4cf7  movq r14, xmm15
0000796da41e4cfc  vmovq xmm1, rax
0000796da41e4d01  vmovq xmm15, r14
0000796da41e4d06  movaps xmm13, xmm1
0000796da41e4d0a  addsd xmm13, xmm15
0000796da41e4d0f  ucomisd xmm13, xmm13
0000796da41e4d14  jp 0x0000796DA41E4DD3
0000796da41e4d1a  movq xmm13, xmm13
0000796da41e4d1f  movq rax, xmm13
0000796da41e4d24  movq r14, xmm14
0000796da41e4d29  vmovq xmm1, rax
0000796da41e4d2e  vmovq xmm15, r14
0000796da41e4d33  movaps xmm14, xmm1
0000796da41e4d37  addsd xmm14, xmm15
0000796da41e4d3c  ucomisd xmm14, xmm14
0000796da41e4d41  jp 0x0000796DA41E4E1B
0000796da41e4d47  movq xmm14, xmm14
0000796da41e4d4c  movaps [r15+0x110], xmm14
0000796da41e4d54  mov eax, [r15+0x108]
0000796da41e4d5b  sahf
0000796da41e4d5c  jnz 0x0000796DA41E4D8E
0000796da41e4d5e  cmp dword ptr [r15+0x318], 0x00
0000796da41e4d66  jz 0x0000796DA41E5030
0000796da41e4d6c  nop [rax+rax*1], ax
0000796da41e4d75  nop [rax+rax*1], eax
0000796da41e4d7d  mov eax, 0x410704
0000796da41e4d82  mov [r15+0x100], rax
0000796da41e4d89  jmp 0x0000796DA3FFE110
0000796da41e4d8e  cmp dword ptr [r15+0x318], 0x00
0000796da41e4d96  jz 0x0000796DA41E4E70
0000796da41e4d9c  nop [rax+rax*1], ax
0000796da41e4da5  nop [rax+rax*1], eax
0000796da41e4dad  mov eax, 0x4106E8
0000796da41e4db2  mov [r15+0x100], rax
0000796da41e4db9  jmp 0x0000796DA3FFE110
0000796da41e4dbe  int3
0000796da41e4dbf  call 0x0000796DA400DC20
0000796da41e4dc4  jmp 0x0000796DA41E4CA2
0000796da41e4dc9  call 0x0000796DA400E760
0000796da41e4dce  jmp 0x0000796DA41E4CB1
0000796da41e4dd3  ucomisd xmm1, xmm15
0000796da41e4dd8  jp 0x0000796DA41E4DE7
0000796da41e4dda  movaps xmm13, [0x0000796DA3DFE060]
0000796da41e4de2  jmp 0x0000796DA41E4D1A
0000796da41e4de7  vxorps xmm0, xmm1, xmm15
0000796da41e4dec  pextrw eax, xmm0, 0x03
0000796da41e4df1  and eax, 0x7FF8
0000796da41e4df6  cmp eax, 0x08
0000796da41e4df9  jnz 0x0000796DA41E4D1A
0000796da41e4dff  movq rax, xmm15
0000796da41e4e04  shl rax, 0x0D
0000796da41e4e08  jbe 0x0000796DA41E4D1A
0000796da41e4e0e  vorps xmm13, xmm15, [0x0000796DA3DFE070]
0000796da41e4e16  jmp 0x0000796DA41E4D1A
0000796da41e4e1b  ucomisd xmm1, xmm15
0000796da41e4e20  jp 0x0000796DA41E4E2F
0000796da41e4e22  movaps xmm14, [0x0000796DA3DFE060]
0000796da41e4e2a  jmp 0x0000796DA41E4D47
0000796da41e4e2f  vxorps xmm0, xmm1, xmm15
0000796da41e4e34  pextrw eax, xmm0, 0x03
0000796da41e4e39  and eax, 0x7FF8
0000796da41e4e3e  cmp eax, 0x08
0000796da41e4e41  jnz 0x0000796DA41E4D47
0000796da41e4e47  movq rax, xmm15
0000796da41e4e4c  shl rax, 0x0D
0000796da41e4e50  jbe 0x0000796DA41E4D47
0000796da41e4e56  vorps xmm14, xmm15, [0x0000796DA3DFE070]
0000796da41e4e5e  jmp 0x0000796DA41E4D47
0000796da41e4e63  int3
0000796da41e4e64  nop [rax+rax*1], ax
0000796da41e4e6d  nop [rax], eax
0000796da41e4e70  mov rax, [r15+0x48]
0000796da41e4e74  mov r14, [r15+0x50]
0000796da41e4e78  lea r12, [r14+rax*1]
0000796da41e4e7c  movups xmm1, [r13+r12*1]
0000796da41e4e82  movaps [r15+0x120], xmm1
0000796da41e4e8a  lea r14, [rax+0x10]
0000796da41e4e8e  mov [r15+0x48], r14
0000796da41e4e92  xor eax, eax
0000796da41e4e94  mov r12d, 0x200
0000796da41e4e9a  cmp r14, r12
0000796da41e4e9d  cmc
0000796da41e4e9e  lahf
0000796da41e4e9f  seto al
0000796da41e4ea2  mov [r15+0x108], eax
0000796da41e4ea9  pextrq rax, xmm1, 0x01
0000796da41e4eb0  movq xmm15, rax
0000796da41e4eb5  movaps [r15+0x130], xmm15
0000796da41e4ebd  movaps xmm14, [r15+0x110]
0000796da41e4ec5  movq rax, xmm14
0000796da41e4eca  movq r14, xmm1
0000796da41e4ecf  vmovq xmm1, rax
0000796da41e4ed4  vmovq xmm14, r14
0000796da41e4ed9  movaps xmm13, xmm1
0000796da41e4edd  addsd xmm13, xmm14
0000796da41e4ee2  ucomisd xmm13, xmm13
0000796da41e4ee7  jp 0x0000796DA41E4F9C
0000796da41e4eed  movq xmm13, xmm13
0000796da41e4ef2  movq rax, xmm13
0000796da41e4ef7  movq r14, xmm15
0000796da41e4efc  vmovq xmm1, rax
0000796da41e4f01  vmovq xmm15, r14
0000796da41e4f06  movaps xmm14, xmm1
0000796da41e4f0a  addsd xmm14, xmm15
0000796da41e4f0f  ucomisd xmm14, xmm14
0000796da41e4f14  jp 0x0000796DA41E4FE4
0000796da41e4f1a  movq xmm14, xmm14
0000796da41e4f1f  movaps [r15+0x110], xmm14
0000796da41e4f27  mov eax, [r15+0x108]
0000796da41e4f2e  sahf
0000796da41e4f2f  jnz 0x0000796DA41E4F61
0000796da41e4f31  cmp dword ptr [r15+0x318], 0x00
0000796da41e4f39  jz 0x0000796DA41E5030
0000796da41e4f3f  nop [rax+rax*1], ax
0000796da41e4f48  nop [rax+rax*1], eax
0000796da41e4f50  mov eax, 0x410704
0000796da41e4f55  mov [r15+0x100], rax
0000796da41e4f5c  jmp 0x0000796DA3FFE110
0000796da41e4f61  cmp dword ptr [r15+0x318], 0x00
0000796da41e4f69  jz 0x0000796DA41E4E70
0000796da41e4f6f  nop [rax+rax*1], ax
0000796da41e4f78  nop [rax+rax*1], eax
0000796da41e4f80  mov eax, 0x4106E8
0000796da41e4f85  mov [r15+0x100], rax
0000796da41e4f8c  jmp 0x0000796DA3FFE110
0000796da41e4f91  int3
0000796da41e4f92  call 0x0000796DA40B52F0
0000796da41e4f97  jmp 0x0000796DA41E4E82
0000796da41e4f9c  ucomisd xmm1, xmm14
0000796da41e4fa1  jp 0x0000796DA41E4FB0
0000796da41e4fa3  movaps xmm13, [0x0000796DA3DFE060]
0000796da41e4fab  jmp 0x0000796DA41E4EED
0000796da41e4fb0  vxorps xmm0, xmm1, xmm14
0000796da41e4fb5  pextrw eax, xmm0, 0x03
0000796da41e4fba  and eax, 0x7FF8
0000796da41e4fbf  cmp eax, 0x08
0000796da41e4fc2  jnz 0x0000796DA41E4EED
0000796da41e4fc8  movq rax, xmm14
0000796da41e4fcd  shl rax, 0x0D
0000796da41e4fd1  jbe 0x0000796DA41E4EED
0000796da41e4fd7  vorps xmm13, xmm14, [0x0000796DA3DFE070]
0000796da41e4fdf  jmp 0x0000796DA41E4EED
0000796da41e4fe4  ucomisd xmm1, xmm15
0000796da41e4fe9  jp 0x0000796DA41E4FF8
0000796da41e4feb  movaps xmm14, [0x0000796DA3DFE060]
0000796da41e4ff3  jmp 0x0000796DA41E4F1A
0000796da41e4ff8  vxorps xmm0, xmm1, xmm15
0000796da41e4ffd  pextrw eax, xmm0, 0x03
0000796da41e5002  and eax, 0x7FF8
0000796da41e5007  cmp eax, 0x08
0000796da41e500a  jnz 0x0000796DA41E4F1A
0000796da41e5010  movq rax, xmm15
0000796da41e5015  shl rax, 0x0D
0000796da41e5019  jbe 0x0000796DA41E4F1A
0000796da41e501f  vorps xmm14, xmm15, [0x0000796DA3DFE070]
0000796da41e5027  jmp 0x0000796DA41E4F1A
0000796da41e502c  int3
0000796da41e502d  nop [rax], eax
0000796da41e5030  mov rax, [r15+0xF8]
0000796da41e5037  lea r14, [rax+0x1D0]
0000796da41e503e  mov r12, [r13+r14*1]
0000796da41e5043  lea r14, [rax+0x1D8]
0000796da41e504a  mov r11, [r13+r14*1]
0000796da41e504f  mov [r15+0xA0], r12
0000796da41e5056  mov [r15+0x98], r11
0000796da41e505d  mov r14, [r15+0x40]
0000796da41e5061  lea r12, [r14+0xCC0]
0000796da41e5068  movaps xmm1, [r15+0x110]
0000796da41e5070  movq r14, xmm1
0000796da41e5075  mov [r13+r12*1], r14
0000796da41e507a  lea r14, [rax+0x1C0]
0000796da41e5081  mov r12, [r13+r14*1]
0000796da41e5086  lea r14, [rax+0x1C8]
0000796da41e508d  mov r11, [r13+r14*1]
0000796da41e5092  mov [r15+0xE8], r12
0000796da41e5099  mov [r15+0xF0], r11
0000796da41e50a0  lea r14, [rax+0x1B0]
0000796da41e50a7  mov r12, [r13+r14*1]
0000796da41e50ac  lea r14, [rax+0x1B8]
0000796da41e50b3  mov r10, [r13+r14*1]
0000796da41e50b8  movq xmm1, r12
0000796da41e50bd  movq xmm15, r10
0000796da41e50c2  movq xmm1, xmm1
0000796da41e50c6  movq xmm1, xmm1
0000796da41e50ca  movaps [r15+0x1A0], xmm1
0000796da41e50d2  movq xmm15, xmm15
0000796da41e50d7  movq xmm15, xmm15
0000796da41e50dc  movaps [r15+0x190], xmm15
0000796da41e50e4  lea r14, [rax+0x1A0]
0000796da41e50eb  mov r12, [r13+r14*1]
0000796da41e50f0  lea r14, [rax+0x1A8]
0000796da41e50f7  mov r10, [r13+r14*1]
0000796da41e50fc  movq xmm1, r12
0000796da41e5101  movq xmm15, r10
0000796da41e5106  movq xmm1, xmm1
0000796da41e510a  movq xmm1, xmm1
0000796da41e510e  movaps [r15+0x1C0], xmm1
0000796da41e5116  movq xmm15, xmm15
0000796da41e511b  movq xmm15, xmm15
0000796da41e5120  movaps [r15+0x1B0], xmm15
0000796da41e5128  lea r14, [rax+0x190]
0000796da41e512f  mov r12, [r13+r14*1]
0000796da41e5134  lea r14, [rax+0x198]
0000796da41e513b  mov r10, [r13+r14*1]
0000796da41e5140  movq xmm1, r12
0000796da41e5145  movq xmm15, r10
0000796da41e514a  movq xmm1, xmm1
0000796da41e514e  movq xmm1, xmm1
0000796da41e5152  movaps [r15+0x1E0], xmm1
0000796da41e515a  movq xmm15, xmm15
0000796da41e515f  movq xmm15, xmm15
0000796da41e5164  movaps [r15+0x1D0], xmm15
0000796da41e516c  lea r14, [rax+0x180]
0000796da41e5173  mov r12, [r13+r14*1]
0000796da41e5178  lea r14, [rax+0x188]
0000796da41e517f  mov r10, [r13+r14*1]
0000796da41e5184  movq xmm1, r12
0000796da41e5189  movq xmm15, r10
0000796da41e518e  movq xmm1, xmm1
0000796da41e5192  movq xmm1, xmm1
0000796da41e5196  movaps [r15+0x200], xmm1
0000796da41e519e  movq xmm15, xmm15
0000796da41e51a3  movq xmm15, xmm15
0000796da41e51a8  movaps [r15+0x1F0], xmm15
0000796da41e51b0  lea r14, [rax+0x1E0]
0000796da41e51b7  mov [r15+0xF8], r14
0000796da41e51be  mov [r15+0x100], r11
0000796da41e51c5  jmp 0x0000796DA41CE5C0
0000796da41e51ca  int3
0000796da41e51cb  call 0x0000796DA40E27E0
0000796da41e51d0  jmp 0x0000796DA41E5043
0000796da41e51d5  call 0x0000796DA40E1570
0000796da41e51da  jmp 0x0000796DA41E504F
0000796da41e51df  call 0x0000796DA40C3FE0
0000796da41e51e4  jmp 0x0000796DA41E507A
0000796da41e51e9  call 0x0000796DA40E27E0
0000796da41e51ee  jmp 0x0000796DA41E5086
0000796da41e51f3  call 0x0000796DA40E1570
0000796da41e51f8  jmp 0x0000796DA41E5092
0000796da41e51fd  call 0x0000796DA40E27E0
0000796da41e5202  jmp 0x0000796DA41E50AC
0000796da41e5207  call 0x0000796DA40E0300
0000796da41e520c  jmp 0x0000796DA41E50B8
0000796da41e5211  call 0x0000796DA40E27E0
0000796da41e5216  jmp 0x0000796DA41E50F0
0000796da41e521b  call 0x0000796DA40E0300
0000796da41e5220  jmp 0x0000796DA41E50FC
0000796da41e5225  call 0x0000796DA40E27E0
0000796da41e522a  jmp 0x0000796DA41E5134
0000796da41e522f  call 0x0000796DA40E0300
0000796da41e5234  jmp 0x0000796DA41E5140
0000796da41e5239  call 0x0000796DA40E27E0
0000796da41e523e  jmp 0x0000796DA41E5178
0000796da41e5243  call 0x0000796DA40E0300
0000796da41e5248  jmp 0x0000796DA41E5184
0000796da41e524d  int3
0000796da41e524e  nop
0000796da41e5250  mov qword ptr [r15+0x100], 0x04
0000796da41e525b  mov esi, 0x00
0000796da41e5260  mov edx, 0x09
0000796da41e5265  mov rdi, 0x7FFD26A3E190
0000796da41e526f  mov rax, 0x5E26CB4FD970
0000796da41e5279  call rax
0000796da41e527b  cmp dword ptr [r15+0x318], 0x00
0000796da41e5283  jnz 0x0000796DA3FFE110
0000796da41e5289  jmp 0x0000796DA3FFE0A0
0000796da41e528e  int3
0000796da41e528f  int3
