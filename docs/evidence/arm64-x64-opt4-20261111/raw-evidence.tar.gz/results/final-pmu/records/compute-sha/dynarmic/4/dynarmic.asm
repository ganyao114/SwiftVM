000077fbc3dce69b  nop [rax+rax*1], eax
000077fbc3dce6a0  mov rax, [r15+0xF8]
000077fbc3dce6a7  lea r14, [rax-0xA0]
000077fbc3dce6ae  mov [r15+0xF8], r14
000077fbc3dce6b5  lea rax, [r14+0x90]
000077fbc3dce6bc  mov r12, [r15+0xA0]
000077fbc3dce6c3  mov r11, [r15+0x98]
000077fbc3dce6ca  mov [r13+rax*1], r12
000077fbc3dce6cf  lea rax, [r14+0x98]
000077fbc3dce6d6  mov [r13+rax*1], r11
000077fbc3dce6db  mov eax, 0x420670
000077fbc3dce6e0  movups xmm1, [r13+rax*1]
000077fbc3dce6e6  mov eax, 0x420610
000077fbc3dce6eb  movups xmm15, [r13+rax*1]
000077fbc3dce6f1  mov eax, 0x420690
000077fbc3dce6f6  movups xmm14, [r13+rax*1]
000077fbc3dce6fc  mov eax, 0x420630
000077fbc3dce701  movups xmm13, [r13+rax*1]
000077fbc3dce707  mov qword ptr [r15+0x98], 0x4308A0
000077fbc3dce712  mov eax, 0x4206A0
000077fbc3dce717  movups xmm12, [r13+rax*1]
000077fbc3dce71d  mov eax, 0x4308A0
000077fbc3dce722  movups [r13+rax*1], xmm1
000077fbc3dce728  mov eax, 0x4308B0
000077fbc3dce72d  movups [r13+rax*1], xmm15
000077fbc3dce733  mov eax, 0x4308C0
000077fbc3dce738  movups [r13+rax*1], xmm14
000077fbc3dce73e  mov eax, 0x4308D0
000077fbc3dce743  movups [r13+rax*1], xmm13
000077fbc3dce749  mov eax, 0x420600
000077fbc3dce74e  movups xmm14, [r13+rax*1]
000077fbc3dce754  mov eax, 0x4205F0
000077fbc3dce759  movups xmm13, [r13+rax*1]
000077fbc3dce75f  mov eax, 0x4309A0
000077fbc3dce764  movups [r13+rax*1], xmm1
000077fbc3dce76a  mov eax, 0x4309B0
000077fbc3dce76f  movups [r13+rax*1], xmm15
000077fbc3dce775  mov eax, 0x4308E0
000077fbc3dce77a  movups [r13+rax*1], xmm12
000077fbc3dce780  mov eax, 0x4308F0
000077fbc3dce785  movups [r13+rax*1], xmm14
000077fbc3dce78b  mov eax, 0x4205E0
000077fbc3dce790  movups xmm1, [r13+rax*1]
000077fbc3dce796  mov eax, 0x420640
000077fbc3dce79b  movups xmm15, [r13+rax*1]
000077fbc3dce7a1  mov eax, 0x430900
000077fbc3dce7a6  movups [r13+rax*1], xmm13
000077fbc3dce7ac  mov eax, 0x430910
000077fbc3dce7b1  movups [r13+rax*1], xmm1
000077fbc3dce7b7  mov eax, 0x420650
000077fbc3dce7bc  movups xmm1, [r13+rax*1]
000077fbc3dce7c2  mov eax, 0x420620
000077fbc3dce7c7  movups xmm14, [r13+rax*1]
000077fbc3dce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
000077fbc3dce7d5  mov eax, 0x430920
000077fbc3dce7da  movups [r13+rax*1], xmm15
000077fbc3dce7e0  mov eax, 0x430930
000077fbc3dce7e5  movups [r13+rax*1], xmm1
000077fbc3dce7eb  mov eax, 0x4206C0
000077fbc3dce7f0  movups xmm1, [r13+rax*1]
000077fbc3dce7f6  mov eax, 0x4206D0
000077fbc3dce7fb  movups xmm15, [r13+rax*1]
000077fbc3dce801  movaps [r15+0x150], xmm15
000077fbc3dce809  mov qword ptr [r15+0xA0], 0x3E8
000077fbc3dce814  mov eax, 0x430940
000077fbc3dce819  movups [r13+rax*1], xmm14
000077fbc3dce81f  mov eax, 0x430950
000077fbc3dce824  movups [r13+rax*1], xmm1
000077fbc3dce82a  mov eax, 0x4206B0
000077fbc3dce82f  movups xmm1, [r13+rax*1]
000077fbc3dce835  mov eax, 0x420660
000077fbc3dce83a  movups xmm14, [r13+rax*1]
000077fbc3dce840  movaps [r15+0x140], xmm14
000077fbc3dce848  lea rax, [r14+0x80]
000077fbc3dce84f  mov r12, [r15+0xF0]
000077fbc3dce856  mov [r13+rax*1], r12
000077fbc3dce85b  mov eax, 0x430960
000077fbc3dce860  movups [r13+rax*1], xmm15
000077fbc3dce866  mov eax, 0x430970
000077fbc3dce86b  movups [r13+rax*1], xmm1
000077fbc3dce871  mov eax, 0x420680
000077fbc3dce876  movups xmm1, [r13+rax*1]
000077fbc3dce87c  mov eax, 0x4206E0
000077fbc3dce881  mov r12, [r13+rax*1]
000077fbc3dce886  movq xmm15, r12
000077fbc3dce88b  mov qword ptr [r15+0x40], 0x4206E8
000077fbc3dce893  mov eax, 0x430980
000077fbc3dce898  movups [r13+rax*1], xmm14
000077fbc3dce89e  mov eax, 0x430990
000077fbc3dce8a3  movups [r13+rax*1], xmm1
000077fbc3dce8a9  mov eax, 0x420748
000077fbc3dce8ae  movups xmm1, [r13+rax*1]
000077fbc3dce8b4  movq rax, xmm15
000077fbc3dce8b9  mov r12d, 0x4309C0
000077fbc3dce8bf  mov [r13+r12*1], rax
000077fbc3dce8c4  mov eax, 0x420728
000077fbc3dce8c9  movups xmm15, [r13+rax*1]
000077fbc3dce8cf  mov eax, 0x420738
000077fbc3dce8d4  movups xmm14, [r13+rax*1]
000077fbc3dce8da  lea rax, [r14+0x60]
000077fbc3dce8de  movups [r13+rax*1], xmm1
000077fbc3dce8e4  mov eax, 0x4309C8
000077fbc3dce8e9  mov r12d, 0x421DF8D3
000077fbc3dce8ef  mov [r13+rax*1], r12d
000077fbc3dce8f4  lea rax, [r14+0x40]
000077fbc3dce8f8  movups [r13+rax*1], xmm15
000077fbc3dce8fe  lea rax, [r14+0x50]
000077fbc3dce902  movups [r13+rax*1], xmm14
000077fbc3dce908  mov eax, 0x4206E8
000077fbc3dce90d  movups xmm1, [r13+rax*1]
000077fbc3dce913  mov eax, 0x4206F8
000077fbc3dce918  movups xmm15, [r13+rax*1]
000077fbc3dce91e  movaps [r15+0x120], xmm15
000077fbc3dce926  movups [r13+r14*1], xmm1
000077fbc3dce92c  lea rax, [r14+0x10]
000077fbc3dce930  movups [r13+rax*1], xmm15
000077fbc3dce936  mov eax, 0x420708
000077fbc3dce93b  movups xmm1, [r13+rax*1]
000077fbc3dce941  mov eax, 0x420718
000077fbc3dce946  movups xmm15, [r13+rax*1]
000077fbc3dce94c  movaps [r15+0x110], xmm1
000077fbc3dce954  movaps [r15+0x130], xmm15
000077fbc3dce95c  lea rax, [r14+0x20]
000077fbc3dce960  movups [r13+rax*1], xmm1
000077fbc3dce966  lea rax, [r14+0x30]
000077fbc3dce96a  movups [r13+rax*1], xmm15
000077fbc3dce970  mov [r15], r14
000077fbc3dce973  mov qword ptr [r15+0x08], 0x4308A0
000077fbc3dce97b  mov qword ptr [r15+0x10], 0x12C
000077fbc3dce983  mov qword ptr [r15+0xF0], 0x410274
000077fbc3dce98e  mov r14d, [r15+0x320]
000077fbc3dce995  mov eax, 0x410274
000077fbc3dce99a  mov rcx, 0x77FBC3DD0670
000077fbc3dce9a4  mov [r15+r14*8+0x328], rax
000077fbc3dce9ac  mov [r15+r14*8+0x368], rcx
000077fbc3dce9b4  add r14d, 0x01
000077fbc3dce9b8  and r14d, 0x07
000077fbc3dce9bc  mov [r15+0x320], r14d
000077fbc3dce9c3  cmp dword ptr [r15+0x318], 0x00
000077fbc3dce9cb  jz 0x000077FBC3DCEC20
000077fbc3dce9d1  nop [rax+rax*1], ax
000077fbc3dce9da  nop [rax+rax*1], eax
000077fbc3dce9e2  mov eax, 0x410338
000077fbc3dce9e7  mov [r15+0x100], rax
000077fbc3dce9ee  jmp 0x000077FBC3BFE110
000077fbc3dce9f3  int3
000077fbc3dce9f4  call 0x000077FBC3C0BC20
000077fbc3dce9f9  jmp 0x000077FBC3DCE6CF
000077fbc3dce9fe  call 0x000077FBC3C0A9A0
000077fbc3dcea03  jmp 0x000077FBC3DCE6DB
000077fbc3dcea08  call 0x000077FBC3BFF430
000077fbc3dcea0d  jmp 0x000077FBC3DCE6E6
000077fbc3dcea12  call 0x000077FBC3C0E760
000077fbc3dcea17  jmp 0x000077FBC3DCE6F1
000077fbc3dcea1c  call 0x000077FBC3C0D4E0
000077fbc3dcea21  jmp 0x000077FBC3DCE6FC
000077fbc3dcea26  call 0x000077FBC3C0C260
000077fbc3dcea2b  jmp 0x000077FBC3DCE707
000077fbc3dcea30  call 0x000077FBC3C0AFE0
000077fbc3dcea35  jmp 0x000077FBC3DCE71D
000077fbc3dcea3a  call 0x000077FBC3BFF540
000077fbc3dcea3f  jmp 0x000077FBC3DCE728
000077fbc3dcea44  call 0x000077FBC3C0E880
000077fbc3dcea49  jmp 0x000077FBC3DCE733
000077fbc3dcea4e  call 0x000077FBC3C0D600
000077fbc3dcea53  jmp 0x000077FBC3DCE73E
000077fbc3dcea58  call 0x000077FBC3C0C380
000077fbc3dcea5d  jmp 0x000077FBC3DCE749
000077fbc3dcea62  call 0x000077FBC3C0D4E0
000077fbc3dcea67  jmp 0x000077FBC3DCE754
000077fbc3dcea6c  call 0x000077FBC3C0C260
000077fbc3dcea71  jmp 0x000077FBC3DCE75F
000077fbc3dcea76  call 0x000077FBC3BFF540
000077fbc3dcea7b  jmp 0x000077FBC3DCE76A
000077fbc3dcea80  call 0x000077FBC3C0E880
000077fbc3dcea85  jmp 0x000077FBC3DCE775
000077fbc3dcea8a  call 0x000077FBC3C0B100
000077fbc3dcea8f  jmp 0x000077FBC3DCE780
000077fbc3dcea94  call 0x000077FBC3C0D600
000077fbc3dcea99  jmp 0x000077FBC3DCE78B
000077fbc3dcea9e  call 0x000077FBC3BFF430
000077fbc3dceaa3  jmp 0x000077FBC3DCE796
000077fbc3dceaa8  call 0x000077FBC3C0E760
000077fbc3dceaad  jmp 0x000077FBC3DCE7A1
000077fbc3dceab2  call 0x000077FBC3C0C380
000077fbc3dceab7  jmp 0x000077FBC3DCE7AC
000077fbc3dceabc  call 0x000077FBC3BFF540
000077fbc3dceac1  jmp 0x000077FBC3DCE7B7
000077fbc3dceac6  call 0x000077FBC3BFF430
000077fbc3dceacb  jmp 0x000077FBC3DCE7C2
000077fbc3dcead0  call 0x000077FBC3C0D4E0
000077fbc3dcead5  jmp 0x000077FBC3DCE7CD
000077fbc3dceada  call 0x000077FBC3C0E880
000077fbc3dceadf  jmp 0x000077FBC3DCE7E0
000077fbc3dceae4  call 0x000077FBC3BFF540
000077fbc3dceae9  jmp 0x000077FBC3DCE7EB
000077fbc3dceaee  call 0x000077FBC3BFF430
000077fbc3dceaf3  jmp 0x000077FBC3DCE7F6
000077fbc3dceaf8  call 0x000077FBC3C0E760
000077fbc3dceafd  jmp 0x000077FBC3DCE801
000077fbc3dceb02  call 0x000077FBC3C0D600
000077fbc3dceb07  jmp 0x000077FBC3DCE81F
000077fbc3dceb0c  call 0x000077FBC3BFF540
000077fbc3dceb11  jmp 0x000077FBC3DCE82A
000077fbc3dceb16  call 0x000077FBC3BFF430
000077fbc3dceb1b  jmp 0x000077FBC3DCE835
000077fbc3dceb20  call 0x000077FBC3C0D4E0
000077fbc3dceb25  jmp 0x000077FBC3DCE840
000077fbc3dceb2a  call 0x000077FBC3C0BC20
000077fbc3dceb2f  jmp 0x000077FBC3DCE85B
000077fbc3dceb34  call 0x000077FBC3C0E880
000077fbc3dceb39  jmp 0x000077FBC3DCE866
000077fbc3dceb3e  call 0x000077FBC3BFF540
000077fbc3dceb43  jmp 0x000077FBC3DCE871
000077fbc3dceb48  call 0x000077FBC3BFF430
000077fbc3dceb4d  jmp 0x000077FBC3DCE87C
000077fbc3dceb52  call 0x000077FBC3C0B720
000077fbc3dceb57  jmp 0x000077FBC3DCE886
000077fbc3dceb5c  call 0x000077FBC3C0D600
000077fbc3dceb61  jmp 0x000077FBC3DCE89E
000077fbc3dceb66  call 0x000077FBC3BFF540
000077fbc3dceb6b  jmp 0x000077FBC3DCE8A9
000077fbc3dceb70  call 0x000077FBC3BFF430
000077fbc3dceb75  jmp 0x000077FBC3DCE8B4
000077fbc3dceb7a  call 0x000077FBC3CB4CB0
000077fbc3dceb7f  jmp 0x000077FBC3DCE8C4
000077fbc3dceb84  call 0x000077FBC3C0E760
000077fbc3dceb89  jmp 0x000077FBC3DCE8CF
000077fbc3dceb8e  call 0x000077FBC3C0D4E0
000077fbc3dceb93  jmp 0x000077FBC3DCE8DA
000077fbc3dceb98  call 0x000077FBC3BFF540
000077fbc3dceb9d  jmp 0x000077FBC3DCE8E4
000077fbc3dceba2  call 0x000077FBC3C0BAE0
000077fbc3dceba7  jmp 0x000077FBC3DCE8F4
000077fbc3dcebac  call 0x000077FBC3C0E880
000077fbc3dcebb1  jmp 0x000077FBC3DCE8FE
000077fbc3dcebb6  call 0x000077FBC3C0D600
000077fbc3dcebbb  jmp 0x000077FBC3DCE908
000077fbc3dcebc0  call 0x000077FBC3BFF430
000077fbc3dcebc5  jmp 0x000077FBC3DCE913
000077fbc3dcebca  call 0x000077FBC3C0E760
000077fbc3dcebcf  jmp 0x000077FBC3DCE91E
000077fbc3dcebd4  call 0x000077FBC3CD6600
000077fbc3dcebd9  jmp 0x000077FBC3DCE92C
000077fbc3dcebde  call 0x000077FBC3C0E880
000077fbc3dcebe3  jmp 0x000077FBC3DCE936
000077fbc3dcebe8  call 0x000077FBC3BFF430
000077fbc3dcebed  jmp 0x000077FBC3DCE941
000077fbc3dcebf2  call 0x000077FBC3C0E760
000077fbc3dcebf7  jmp 0x000077FBC3DCE94C
000077fbc3dcebfc  call 0x000077FBC3BFF540
000077fbc3dcec01  jmp 0x000077FBC3DCE966
000077fbc3dcec06  call 0x000077FBC3C0E880
000077fbc3dcec0b  jmp 0x000077FBC3DCE970
000077fbc3dcec10  int3
000077fbc3dcec11  nop [rax+rax*1], ax
000077fbc3dcec1a  nop [rax+rax*1], ax
000077fbc3dcec20  mov rax, [r15]
000077fbc3dcec23  lea r14, [rax+0x20]
000077fbc3dcec27  mov r12, [r13+r14*1]
000077fbc3dcec2c  mov r14, [r15+0x10]
000077fbc3dcec30  lea r11, [r12+r14*1]
000077fbc3dcec34  mov [r15+0x40], r11
000077fbc3dcec38  lea r12, [rax+0x20]
000077fbc3dcec3c  mov [r13+r12*1], r11
000077fbc3dcec41  test r14, r14
000077fbc3dcec44  setz r14b
000077fbc3dcec48  movzx r14, r14b
000077fbc3dcec4c  mov [rsp+0x414], r14b
000077fbc3dcec54  cmp byte ptr [rsp+0x414], 0x00
000077fbc3dcec5c  jz 0x000077FBC3DCEC8E
000077fbc3dcec5e  cmp dword ptr [r15+0x318], 0x00
000077fbc3dcec66  mov eax, 0x4105B0
000077fbc3dcec6b  mov [r15+0x100], rax
000077fbc3dcec72  jz 0x000077FBC3BFE0A0
000077fbc3dcec78  nop [rax+rax*1], eax
000077fbc3dcec7d  mov eax, 0x4105B0
000077fbc3dcec82  mov [r15+0x100], rax
000077fbc3dcec89  jmp 0x000077FBC3BFE110
000077fbc3dcec8e  cmp dword ptr [r15+0x318], 0x00
000077fbc3dcec96  jz 0x000077FBC3DCECE0
000077fbc3dcec9c  nop [rax+rax*1], ax
000077fbc3dceca5  nop [rax+rax*1], eax
000077fbc3dcecad  mov eax, 0x410348
000077fbc3dcecb2  mov [r15+0x100], rax
000077fbc3dcecb9  jmp 0x000077FBC3BFE110
000077fbc3dcecbe  int3
000077fbc3dcecbf  call 0x000077FBC3CE27E0
000077fbc3dcecc4  jmp 0x000077FBC3DCEC2C
000077fbc3dcecc9  call 0x000077FBC3CC0860
000077fbc3dcecce  jmp 0x000077FBC3DCEC41
000077fbc3dcecd3  int3
000077fbc3dcecd4  nop [rax+rax*1], ax
000077fbc3dcecdd  nop [rax], eax
000077fbc3dcece0  mov rax, [r15+0xF8]
000077fbc3dcece7  lea r14, [rax-0x150]
000077fbc3dcecee  mov [r15+0xF8], r14
000077fbc3dcecf5  mov rax, [r15]
000077fbc3dcecf8  lea r12, [rax+0x68]
000077fbc3dcecfc  mov r11, [r13+r12*1]
000077fbc3dced01  mov [r15+0x88], r11
000077fbc3dced08  lea r12, [rax+0x28]
000077fbc3dced0c  mov [r15+0x40], r12
000077fbc3dced10  mov [r15+0x48], r14
000077fbc3dced14  mov qword ptr [r15+0x50], 0x420758
000077fbc3dced1c  lea rax, [r14+0x100]
000077fbc3dced23  mov r12, [r15+0xE8]
000077fbc3dced2a  mov r11, [r15+0xD8]
000077fbc3dced31  mov [r13+rax*1], r12
000077fbc3dced36  lea rax, [r14+0x108]
000077fbc3dced3d  mov [r13+rax*1], r11
000077fbc3dced42  lea rax, [r14+0x110]
000077fbc3dced49  mov r12, [r15+0xD0]
000077fbc3dced50  mov r11, [r15+0xC8]
000077fbc3dced57  mov [r13+rax*1], r12
000077fbc3dced5c  lea rax, [r14+0x118]
000077fbc3dced63  mov [r13+rax*1], r11
000077fbc3dced68  lea rax, [r14+0x120]
000077fbc3dced6f  mov r12, [r15+0xC0]
000077fbc3dced76  mov r11, [r15+0xB8]
000077fbc3dced7d  mov [r13+rax*1], r12
000077fbc3dced82  lea rax, [r14+0x128]
000077fbc3dced89  mov [r13+rax*1], r11
000077fbc3dced8e  lea rax, [r14+0x130]
000077fbc3dced95  mov r12, [r15+0xB0]
000077fbc3dced9c  mov r11, [r15+0xA8]
000077fbc3dceda3  mov [r13+rax*1], r12
000077fbc3dceda8  lea rax, [r14+0x138]
000077fbc3dcedaf  mov [r13+rax*1], r11
000077fbc3dcedb4  lea rax, [r14+0x140]
000077fbc3dcedbb  mov r12, [r15+0xA0]
000077fbc3dcedc2  mov r11, [r15+0x98]
000077fbc3dcedc9  mov [r13+rax*1], r12
000077fbc3dcedce  lea rax, [r14+0x148]
000077fbc3dcedd5  mov [r13+rax*1], r11
000077fbc3dcedda  cmp dword ptr [r15+0x318], 0x00
000077fbc3dcede2  jz 0x000077FBC3DCEE80
000077fbc3dcede8  nop [rax+rax*1], ax
000077fbc3dcedf1  nop [rax+rax*1], eax
000077fbc3dcedf9  mov eax, 0x410380
000077fbc3dcedfe  mov [r15+0x100], rax
000077fbc3dcee05  jmp 0x000077FBC3BFE110
000077fbc3dcee0a  int3
000077fbc3dcee0b  call 0x000077FBC3CC0370
000077fbc3dcee10  jmp 0x000077FBC3DCED01
000077fbc3dcee15  call 0x000077FBC3C0BC20
000077fbc3dcee1a  jmp 0x000077FBC3DCED36
000077fbc3dcee1f  call 0x000077FBC3C0A9A0
000077fbc3dcee24  jmp 0x000077FBC3DCED42
000077fbc3dcee29  call 0x000077FBC3C0BC20
000077fbc3dcee2e  jmp 0x000077FBC3DCED5C
000077fbc3dcee33  call 0x000077FBC3C0A9A0
000077fbc3dcee38  jmp 0x000077FBC3DCED68
000077fbc3dcee3d  call 0x000077FBC3C0BC20
000077fbc3dcee42  jmp 0x000077FBC3DCED82
000077fbc3dcee47  call 0x000077FBC3C0A9A0
000077fbc3dcee4c  jmp 0x000077FBC3DCED8E
000077fbc3dcee51  call 0x000077FBC3C0BC20
000077fbc3dcee56  jmp 0x000077FBC3DCEDA8
000077fbc3dcee5b  call 0x000077FBC3C0A9A0
000077fbc3dcee60  jmp 0x000077FBC3DCEDB4
000077fbc3dcee65  call 0x000077FBC3C0BC20
000077fbc3dcee6a  jmp 0x000077FBC3DCEDCE
000077fbc3dcee6f  call 0x000077FBC3C0A9A0
000077fbc3dcee74  jmp 0x000077FBC3DCEDDA
000077fbc3dcee79  int3
000077fbc3dcee7a  nop [rax+rax*1], ax
000077fbc3dcee80  mov rax, [r15+0x08]
000077fbc3dcee84  movzx r14d, byte ptr [r13+rax*1]
000077fbc3dcee8a  movzx r14d, r14b
000077fbc3dcee8e  mov [rsp+0x10], r14d
000077fbc3dcee93  mov r14d, r14d
000077fbc3dcee96  mov [r15+0x58], r14
000077fbc3dcee9a  lea r14, [rax+0x01]
000077fbc3dcee9e  mov [r15+0x08], r14
000077fbc3dceea2  mov rax, [r15+0x88]
000077fbc3dceea9  lea r14, [rax+0x01]
000077fbc3dceead  mov r12, [r15]
000077fbc3dceeb0  lea r11, [r12+0x68]
000077fbc3dceeb5  mov [r13+r11*1], r14
000077fbc3dceeba  lea r14, [r12+rax*1]
000077fbc3dceebe  mov [r15+0x60], r14
000077fbc3dceec2  lea rax, [r14+0x28]
000077fbc3dceec6  mov r11d, [rsp+0x10]
000077fbc3dceecb  movzx r14d, r11b
000077fbc3dceecf  mov [r13+rax*1], r14b
000077fbc3dceed4  lea rax, [r12+0x68]
000077fbc3dceed9  mov r14, [r13+rax*1]
000077fbc3dceede  mov [r15+0x88], r14
000077fbc3dceee5  xor eax, eax
000077fbc3dceee7  mov r12d, 0x40
000077fbc3dceeed  cmp r14, r12
000077fbc3dceef0  cmc
000077fbc3dceef1  lahf
000077fbc3dceef2  seto al
000077fbc3dceef5  mov [r15+0x108], eax
000077fbc3dceefc  mov eax, [r15+0x108]
000077fbc3dcef03  sahf
000077fbc3dcef04  jnz 0x000077FBC3DCEF36
000077fbc3dcef06  cmp dword ptr [r15+0x318], 0x00
000077fbc3dcef0e  jz 0x000077FBC3DCF020
000077fbc3dcef14  nop [rax+rax*1], ax
000077fbc3dcef1d  nop [rax+rax*1], eax
000077fbc3dcef25  mov eax, 0x4103A0
000077fbc3dcef2a  mov [r15+0x100], rax
000077fbc3dcef31  jmp 0x000077FBC3BFE110
000077fbc3dcef36  cmp dword ptr [r15+0x318], 0x00
000077fbc3dcef3e  jz 0x000077FBC3DCEF90
000077fbc3dcef44  nop [rax+rax*1], ax
000077fbc3dcef4d  nop [rax+rax*1], eax
000077fbc3dcef55  mov eax, 0x410378
000077fbc3dcef5a  mov [r15+0x100], rax
000077fbc3dcef61  jmp 0x000077FBC3BFE110
000077fbc3dcef66  int3
000077fbc3dcef67  call 0x000077FBC3C0D860
000077fbc3dcef6c  jmp 0x000077FBC3DCEE8A
000077fbc3dcef71  call 0x000077FBC3CB36E0
000077fbc3dcef76  jmp 0x000077FBC3DCEEBA
000077fbc3dcef7b  call 0x000077FBC3C0DD60
000077fbc3dcef80  jmp 0x000077FBC3DCEED4
000077fbc3dcef85  call 0x000077FBC3C0DC20
000077fbc3dcef8a  jmp 0x000077FBC3DCEEDE
000077fbc3dcef8f  int3
000077fbc3dcef90  mov rax, [r15+0x10]
000077fbc3dcef94  lea r14, [rax-0x01]
000077fbc3dcef98  mov [r15+0x10], r14
000077fbc3dcef9c  test r14, r14
000077fbc3dcef9f  setz r14b
000077fbc3dcefa3  movzx r14, r14b
000077fbc3dcefa7  mov [rsp+0x414], r14b
000077fbc3dcefaf  cmp byte ptr [rsp+0x414], 0x00
000077fbc3dcefb7  jz 0x000077FBC3DCEFE9
000077fbc3dcefb9  cmp dword ptr [r15+0x318], 0x00
000077fbc3dcefc1  jz 0x000077FBC3DD0520
000077fbc3dcefc7  nop [rax+rax*1], ax
000077fbc3dcefd0  nop [rax+rax*1], eax
000077fbc3dcefd8  mov eax, 0x410598
000077fbc3dcefdd  mov [r15+0x100], rax
000077fbc3dcefe4  jmp 0x000077FBC3BFE110
000077fbc3dcefe9  cmp dword ptr [r15+0x318], 0x00
000077fbc3dceff1  jz 0x000077FBC3DCEE80
000077fbc3dceff7  nop [rax+rax*1], ax
000077fbc3dcf000  nop [rax+rax*1], eax
000077fbc3dcf008  mov eax, 0x410380
000077fbc3dcf00d  mov [r15+0x100], rax
000077fbc3dcf014  jmp 0x000077FBC3BFE110
000077fbc3dcf019  int3
000077fbc3dcf01a  int3
000077fbc3dcf01b  nop [rax+rax*1], eax
000077fbc3dcf020  mov rax, [r15+0x40]
000077fbc3dcf024  movzx r14d, byte ptr [r13+rax*1]
000077fbc3dcf02a  movaps xmm1, [r15+0x110]
000077fbc3dcf032  pinsrb xmm1, r14d, 0x00
000077fbc3dcf039  lea r14, [rax+0x01]
000077fbc3dcf03d  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf043  movaps xmm15, [r15+0x120]
000077fbc3dcf04b  pinsrb xmm15, r12d, 0x00
000077fbc3dcf052  lea r14, [rax+0x02]
000077fbc3dcf056  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf05c  movaps xmm14, [r15+0x130]
000077fbc3dcf064  pinsrb xmm14, r12d, 0x00
000077fbc3dcf06b  lea r14, [rax+0x03]
000077fbc3dcf06f  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf075  movaps xmm13, [r15+0x140]
000077fbc3dcf07d  pinsrb xmm13, r12d, 0x00
000077fbc3dcf084  lea r14, [rax+0x04]
000077fbc3dcf088  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf08e  pinsrb xmm1, r12d, 0x01
000077fbc3dcf095  lea r14, [rax+0x05]
000077fbc3dcf099  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf09f  pinsrb xmm15, r12d, 0x01
000077fbc3dcf0a6  lea r14, [rax+0x06]
000077fbc3dcf0aa  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf0b0  pinsrb xmm14, r12d, 0x01
000077fbc3dcf0b7  lea r14, [rax+0x07]
000077fbc3dcf0bb  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf0c1  pinsrb xmm13, r12d, 0x01
000077fbc3dcf0c8  lea r14, [rax+0x08]
000077fbc3dcf0cc  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf0d2  pinsrb xmm1, r12d, 0x02
000077fbc3dcf0d9  lea r14, [rax+0x09]
000077fbc3dcf0dd  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf0e3  pinsrb xmm15, r12d, 0x02
000077fbc3dcf0ea  lea r14, [rax+0x0A]
000077fbc3dcf0ee  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf0f4  pinsrb xmm14, r12d, 0x02
000077fbc3dcf0fb  lea r14, [rax+0x0B]
000077fbc3dcf0ff  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf105  pinsrb xmm13, r12d, 0x02
000077fbc3dcf10c  lea r14, [rax+0x0C]
000077fbc3dcf110  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf116  pinsrb xmm1, r12d, 0x03
000077fbc3dcf11d  lea r14, [rax+0x0D]
000077fbc3dcf121  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf127  pinsrb xmm15, r12d, 0x03
000077fbc3dcf12e  lea r14, [rax+0x0E]
000077fbc3dcf132  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf138  pinsrb xmm14, r12d, 0x03
000077fbc3dcf13f  lea r14, [rax+0x0F]
000077fbc3dcf143  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf149  pinsrb xmm13, r12d, 0x03
000077fbc3dcf150  lea r14, [rax+0x10]
000077fbc3dcf154  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf15a  pinsrb xmm1, r12d, 0x04
000077fbc3dcf161  lea r14, [rax+0x11]
000077fbc3dcf165  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf16b  pinsrb xmm15, r12d, 0x04
000077fbc3dcf172  lea r14, [rax+0x12]
000077fbc3dcf176  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf17c  pinsrb xmm14, r12d, 0x04
000077fbc3dcf183  lea r14, [rax+0x13]
000077fbc3dcf187  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf18d  pinsrb xmm13, r12d, 0x04
000077fbc3dcf194  lea r14, [rax+0x14]
000077fbc3dcf198  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf19e  pinsrb xmm1, r12d, 0x05
000077fbc3dcf1a5  lea r14, [rax+0x15]
000077fbc3dcf1a9  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf1af  pinsrb xmm15, r12d, 0x05
000077fbc3dcf1b6  lea r14, [rax+0x16]
000077fbc3dcf1ba  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf1c0  pinsrb xmm14, r12d, 0x05
000077fbc3dcf1c7  lea r14, [rax+0x17]
000077fbc3dcf1cb  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf1d1  pinsrb xmm13, r12d, 0x05
000077fbc3dcf1d8  lea r14, [rax+0x18]
000077fbc3dcf1dc  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf1e2  pinsrb xmm1, r12d, 0x06
000077fbc3dcf1e9  lea r14, [rax+0x19]
000077fbc3dcf1ed  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf1f3  pinsrb xmm15, r12d, 0x06
000077fbc3dcf1fa  lea r14, [rax+0x1A]
000077fbc3dcf1fe  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf204  pinsrb xmm14, r12d, 0x06
000077fbc3dcf20b  lea r14, [rax+0x1B]
000077fbc3dcf20f  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf215  pinsrb xmm13, r12d, 0x06
000077fbc3dcf21c  lea r14, [rax+0x1C]
000077fbc3dcf220  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf226  pinsrb xmm1, r12d, 0x07
000077fbc3dcf22d  lea r14, [rax+0x1D]
000077fbc3dcf231  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf237  pinsrb xmm15, r12d, 0x07
000077fbc3dcf23e  lea r14, [rax+0x1E]
000077fbc3dcf242  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf248  pinsrb xmm14, r12d, 0x07
000077fbc3dcf24f  lea r14, [rax+0x1F]
000077fbc3dcf253  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf259  pinsrb xmm13, r12d, 0x07
000077fbc3dcf260  lea r14, [rax+0x20]
000077fbc3dcf264  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf26a  pinsrb xmm1, r12d, 0x08
000077fbc3dcf271  lea r14, [rax+0x21]
000077fbc3dcf275  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf27b  pinsrb xmm15, r12d, 0x08
000077fbc3dcf282  lea r14, [rax+0x22]
000077fbc3dcf286  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf28c  pinsrb xmm14, r12d, 0x08
000077fbc3dcf293  lea r14, [rax+0x23]
000077fbc3dcf297  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf29d  pinsrb xmm13, r12d, 0x08
000077fbc3dcf2a4  lea r14, [rax+0x24]
000077fbc3dcf2a8  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf2ae  pinsrb xmm1, r12d, 0x09
000077fbc3dcf2b5  lea r14, [rax+0x25]
000077fbc3dcf2b9  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf2bf  pinsrb xmm15, r12d, 0x09
000077fbc3dcf2c6  lea r14, [rax+0x26]
000077fbc3dcf2ca  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf2d0  pinsrb xmm14, r12d, 0x09
000077fbc3dcf2d7  lea r14, [rax+0x27]
000077fbc3dcf2db  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf2e1  pinsrb xmm13, r12d, 0x09
000077fbc3dcf2e8  lea r14, [rax+0x28]
000077fbc3dcf2ec  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf2f2  pinsrb xmm1, r12d, 0x0A
000077fbc3dcf2f9  lea r14, [rax+0x29]
000077fbc3dcf2fd  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf303  pinsrb xmm15, r12d, 0x0A
000077fbc3dcf30a  lea r14, [rax+0x2A]
000077fbc3dcf30e  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf314  pinsrb xmm14, r12d, 0x0A
000077fbc3dcf31b  lea r14, [rax+0x2B]
000077fbc3dcf31f  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf325  pinsrb xmm13, r12d, 0x0A
000077fbc3dcf32c  lea r14, [rax+0x2C]
000077fbc3dcf330  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf336  pinsrb xmm1, r12d, 0x0B
000077fbc3dcf33d  lea r14, [rax+0x2D]
000077fbc3dcf341  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf347  pinsrb xmm15, r12d, 0x0B
000077fbc3dcf34e  lea r14, [rax+0x2E]
000077fbc3dcf352  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf358  pinsrb xmm14, r12d, 0x0B
000077fbc3dcf35f  lea r14, [rax+0x2F]
000077fbc3dcf363  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf369  pinsrb xmm13, r12d, 0x0B
000077fbc3dcf370  lea r14, [rax+0x30]
000077fbc3dcf374  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf37a  pinsrb xmm1, r12d, 0x0C
000077fbc3dcf381  lea r14, [rax+0x31]
000077fbc3dcf385  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf38b  pinsrb xmm15, r12d, 0x0C
000077fbc3dcf392  lea r14, [rax+0x32]
000077fbc3dcf396  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf39c  pinsrb xmm14, r12d, 0x0C
000077fbc3dcf3a3  lea r14, [rax+0x33]
000077fbc3dcf3a7  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf3ad  pinsrb xmm13, r12d, 0x0C
000077fbc3dcf3b4  lea r14, [rax+0x34]
000077fbc3dcf3b8  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf3be  pinsrb xmm1, r12d, 0x0D
000077fbc3dcf3c5  lea r14, [rax+0x35]
000077fbc3dcf3c9  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf3cf  pinsrb xmm15, r12d, 0x0D
000077fbc3dcf3d6  lea r14, [rax+0x36]
000077fbc3dcf3da  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf3e0  pinsrb xmm14, r12d, 0x0D
000077fbc3dcf3e7  lea r14, [rax+0x37]
000077fbc3dcf3eb  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf3f1  pinsrb xmm13, r12d, 0x0D
000077fbc3dcf3f8  lea r14, [rax+0x38]
000077fbc3dcf3fc  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf402  pinsrb xmm1, r12d, 0x0E
000077fbc3dcf409  lea r14, [rax+0x39]
000077fbc3dcf40d  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf413  pinsrb xmm15, r12d, 0x0E
000077fbc3dcf41a  lea r14, [rax+0x3A]
000077fbc3dcf41e  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf424  pinsrb xmm14, r12d, 0x0E
000077fbc3dcf42b  lea r14, [rax+0x3B]
000077fbc3dcf42f  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf435  pinsrb xmm13, r12d, 0x0E
000077fbc3dcf43c  lea r14, [rax+0x3C]
000077fbc3dcf440  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf446  pinsrb xmm1, r12d, 0x0F
000077fbc3dcf44d  movaps [r15+0x110], xmm1
000077fbc3dcf455  lea r14, [rax+0x3D]
000077fbc3dcf459  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf45f  pinsrb xmm15, r12d, 0x0F
000077fbc3dcf466  movaps [r15+0x120], xmm15
000077fbc3dcf46e  lea r14, [rax+0x3E]
000077fbc3dcf472  movzx r12d, byte ptr [r13+r14*1]
000077fbc3dcf478  pinsrb xmm14, r12d, 0x0F
000077fbc3dcf47f  movaps [r15+0x130], xmm14
000077fbc3dcf487  lea r14, [rax+0x3F]
000077fbc3dcf48b  movzx eax, byte ptr [r13+r14*1]
000077fbc3dcf491  pinsrb xmm13, eax, 0x0F
000077fbc3dcf498  movaps [r15+0x140], xmm13
000077fbc3dcf4a0  movq xmm1, qword ptr [r15+0x120]
000077fbc3dcf4a9  pmovzxbw xmm1, xmm1
000077fbc3dcf4ae  psllw xmm1, 0x00
000077fbc3dcf4b3  movaps [r15+0x150], xmm1
000077fbc3dcf4bb  movq xmm1, qword ptr [r15+0x130]
000077fbc3dcf4c4  pmovzxbw xmm1, xmm1
000077fbc3dcf4c9  psllw xmm1, 0x00
000077fbc3dcf4ce  movaps [r15+0x160], xmm1
000077fbc3dcf4d6  movq xmm1, qword ptr [r15+0x110]
000077fbc3dcf4df  pmovzxbw xmm1, xmm1
000077fbc3dcf4e4  psllw xmm1, 0x00
000077fbc3dcf4e9  movaps [r15+0x170], xmm1
000077fbc3dcf4f1  movaps xmm15, [r15+0x110]
000077fbc3dcf4f9  pextrq rax, xmm15, 0x01
000077fbc3dcf500  movq xmm15, rax
000077fbc3dcf505  pmovzxbw xmm15, xmm15
000077fbc3dcf50b  psllw xmm15, 0x00
000077fbc3dcf511  movaps [r15+0x180], xmm15
000077fbc3dcf519  movaps xmm14, [r15+0x120]
000077fbc3dcf521  pextrq rax, xmm14, 0x01
000077fbc3dcf528  movq xmm14, rax
000077fbc3dcf52d  pmovzxbw xmm14, xmm14
000077fbc3dcf533  psllw xmm14, 0x00
000077fbc3dcf539  movaps [r15+0x210], xmm14
000077fbc3dcf541  movaps xmm13, [r15+0x130]
000077fbc3dcf549  pextrq rax, xmm13, 0x01
000077fbc3dcf550  movq xmm13, rax
000077fbc3dcf555  pmovzxbw xmm13, xmm13
000077fbc3dcf55b  psllw xmm13, 0x00
000077fbc3dcf561  movaps [r15+0x220], xmm13
000077fbc3dcf569  movq xmm12, qword ptr [r15+0x140]
000077fbc3dcf572  pmovzxbw xmm12, xmm12
000077fbc3dcf578  psllw xmm12, 0x00
000077fbc3dcf57e  movaps [r15+0x250], xmm12
000077fbc3dcf586  movaps xmm12, [r15+0x140]
000077fbc3dcf58e  pextrq rax, xmm12, 0x01
000077fbc3dcf595  movq xmm12, rax
000077fbc3dcf59a  pmovzxbw xmm12, xmm12
000077fbc3dcf5a0  psllw xmm12, 0x00
000077fbc3dcf5a6  movaps [r15+0x110], xmm12
000077fbc3dcf5ae  movq xmm11, qword ptr [r15+0x150]
000077fbc3dcf5b7  pmovzxwd xmm11, xmm11
000077fbc3dcf5bd  pslld xmm11, 0x10
000077fbc3dcf5c3  movq xmm10, qword ptr [r15+0x160]
000077fbc3dcf5cc  pmovzxwd xmm10, xmm10
000077fbc3dcf5d2  pslld xmm10, 0x08
000077fbc3dcf5d8  pextrq rax, xmm1, 0x01
000077fbc3dcf5df  movq xmm1, rax
000077fbc3dcf5e4  pmovzxwd xmm1, xmm1
000077fbc3dcf5e9  pslld xmm1, 0x00
000077fbc3dcf5ee  movaps [r15+0x260], xmm1
000077fbc3dcf5f6  pextrq rax, xmm15, 0x01
000077fbc3dcf5fd  movq xmm15, rax
000077fbc3dcf602  pmovzxwd xmm15, xmm15
000077fbc3dcf608  pslld xmm15, 0x00
000077fbc3dcf60e  movaps [r15+0x270], xmm15
000077fbc3dcf616  movq xmm9, qword ptr [r15+0x170]
000077fbc3dcf61f  pmovzxwd xmm9, xmm9
000077fbc3dcf625  pslld xmm9, 0x00
000077fbc3dcf62b  pextrq rax, xmm14, 0x01
000077fbc3dcf632  movq xmm14, rax
000077fbc3dcf637  pmovzxwd xmm14, xmm14
000077fbc3dcf63d  pslld xmm14, 0x10
000077fbc3dcf643  movaps [r15+0x280], xmm14
000077fbc3dcf64b  movq xmm8, qword ptr [r15+0x180]
000077fbc3dcf654  pmovzxwd xmm8, xmm8
000077fbc3dcf65a  pslld xmm8, 0x00
000077fbc3dcf660  movq xmm7, qword ptr [r15+0x210]
000077fbc3dcf669  pmovzxwd xmm7, xmm7
000077fbc3dcf66e  pslld xmm7, 0x10
000077fbc3dcf673  movaps xmm6, [r15+0x150]
000077fbc3dcf67b  pextrq rax, xmm6, 0x01
000077fbc3dcf682  movq xmm6, rax
000077fbc3dcf687  pmovzxwd xmm6, xmm6
000077fbc3dcf68c  pslld xmm6, 0x10
000077fbc3dcf691  por xmm11, xmm10
000077fbc3dcf696  movaps [r15+0x230], xmm11
000077fbc3dcf69e  pextrq rax, xmm13, 0x01
000077fbc3dcf6a5  movq xmm13, rax
000077fbc3dcf6aa  pmovzxwd xmm13, xmm13
000077fbc3dcf6b0  pslld xmm13, 0x08
000077fbc3dcf6b6  movaps [r15+0x240], xmm13
000077fbc3dcf6be  movq xmm10, qword ptr [r15+0x220]
000077fbc3dcf6c7  pmovzxwd xmm10, xmm10
000077fbc3dcf6cd  pslld xmm10, 0x08
000077fbc3dcf6d3  movaps xmm5, [r15+0x160]
000077fbc3dcf6db  pextrq rax, xmm5, 0x01
000077fbc3dcf6e2  movq xmm5, rax
000077fbc3dcf6e7  pmovzxwd xmm5, xmm5
000077fbc3dcf6ec  pslld xmm5, 0x08
000077fbc3dcf6f1  pslld xmm9, 0x18
000077fbc3dcf6f7  pslld xmm15, 0x18
000077fbc3dcf6fd  pslld xmm8, 0x18
000077fbc3dcf703  movq xmm4, qword ptr [r15+0x250]
000077fbc3dcf70c  pmovzxwd xmm4, xmm4
000077fbc3dcf711  pslld xmm4, 0x00
000077fbc3dcf716  por xmm14, xmm13
000077fbc3dcf71b  por xmm7, xmm10
000077fbc3dcf720  movaps [r15+0x210], xmm7
000077fbc3dcf728  pslld xmm1, 0x18
000077fbc3dcf72d  movaps [r15+0x220], xmm1
000077fbc3dcf735  por xmm6, xmm5
000077fbc3dcf739  por xmm11, xmm9
000077fbc3dcf73e  movaps [r15+0x160], xmm11
000077fbc3dcf746  pextrq rax, xmm12, 0x01
000077fbc3dcf74d  movq xmm13, rax
000077fbc3dcf752  pmovzxwd xmm13, xmm13
000077fbc3dcf758  pslld xmm13, 0x00
000077fbc3dcf75e  movaps [r15+0x170], xmm13
000077fbc3dcf766  movq xmm12, qword ptr [r15+0x110]
000077fbc3dcf76f  pmovzxwd xmm12, xmm12
000077fbc3dcf775  pslld xmm12, 0x00
000077fbc3dcf77b  por xmm14, xmm15
000077fbc3dcf780  por xmm7, xmm8
000077fbc3dcf785  movaps xmm15, [r15+0x250]
000077fbc3dcf78d  pextrq rax, xmm15, 0x01
000077fbc3dcf794  movq xmm15, rax
000077fbc3dcf799  pmovzxwd xmm15, xmm15
000077fbc3dcf79f  pslld xmm15, 0x00
000077fbc3dcf7a5  movaps [r15+0x180], xmm15
000077fbc3dcf7ad  por xmm6, xmm1
000077fbc3dcf7b1  movaps [r15+0x150], xmm6
000077fbc3dcf7b9  por xmm11, xmm4
000077fbc3dcf7be  movaps [r15+0x140], xmm11
000077fbc3dcf7c6  por xmm7, xmm12
000077fbc3dcf7cb  movaps [r15+0x110], xmm7
000077fbc3dcf7d3  por xmm14, xmm13
000077fbc3dcf7d8  movaps [r15+0x120], xmm14
000077fbc3dcf7e0  por xmm6, xmm15
000077fbc3dcf7e5  movaps [r15+0x130], xmm6
000077fbc3dcf7ed  mov rax, [r15+0xF8]
000077fbc3dcf7f4  lea r14, [rax+0x20]
000077fbc3dcf7f8  movups [r13+r14*1], xmm7
000077fbc3dcf7fe  lea r14, [rax+0x30]
000077fbc3dcf802  movups [r13+r14*1], xmm14
000077fbc3dcf808  movups [r13+rax*1], xmm11
000077fbc3dcf80e  lea r14, [rax+0x10]
000077fbc3dcf812  movups [r13+r14*1], xmm6
000077fbc3dcf818  mov r14d, [r13+rax*1]
000077fbc3dcf81d  mov rax, [r15+0x48]
000077fbc3dcf821  mov [r15+0x68], rax
000077fbc3dcf825  mov qword ptr [r15+0x58], 0x04
000077fbc3dcf82d  lea r12, [rax+0x04]
000077fbc3dcf831  mov r11d, [r13+r12*1]
000077fbc3dcf836  mov [rsp+0x10], r11d
000077fbc3dcf83b  mov r11d, r11d
000077fbc3dcf83e  mov [r15+0x70], r11
000077fbc3dcf842  lea r12, [rax+0x38]
000077fbc3dcf846  mov r11d, [r13+r12*1]
000077fbc3dcf84b  lea r12, [rax+0x24]
000077fbc3dcf84f  mov r10d, [r13+r12*1]
000077fbc3dcf854  mov [rsp+0x20], r10d
000077fbc3dcf859  mov r10d, r10d
000077fbc3dcf85c  mov [r15+0x90], r10
000077fbc3dcf863  mov [rsp+0x30], rax
000077fbc3dcf868  xor eax, eax
000077fbc3dcf86a  mov r12d, 0x04
000077fbc3dcf870  mov r10d, 0xC0
000077fbc3dcf876  cmp r12, r10
000077fbc3dcf879  cmc
000077fbc3dcf87a  lahf
000077fbc3dcf87b  seto al
000077fbc3dcf87e  mov [r15+0x108], eax
000077fbc3dcf885  mov eax, [rsp+0x10]
000077fbc3dcf889  mov r12d, [rsp+0x10]
000077fbc3dcf88e  shrd eax, r12d, 0x07
000077fbc3dcf893  mov [rsp+0x10], r11d
000077fbc3dcf898  mov r10d, [rsp+0x10]
000077fbc3dcf89d  shrd r11d, r10d, 0x11
000077fbc3dcf8a2  mov r9d, [rsp+0x20]
000077fbc3dcf8a7  lea r8d, [r9d+r14d*1]
000077fbc3dcf8ac  rorx r14d, r12d, 0x12
000077fbc3dcf8b2  xor eax, r14d
000077fbc3dcf8b5  rorx r14d, r10d, 0x13
000077fbc3dcf8bb  xor r11d, r14d
000077fbc3dcf8be  mov [rsp+0x10], r11d
000077fbc3dcf8c3  mov r11d, r11d
000077fbc3dcf8c6  mov [r15+0x88], r11
000077fbc3dcf8cd  mov [rsp+0x20], r12d
000077fbc3dcf8d2  shr r12d, 0x03
000077fbc3dcf8d6  xor eax, r12d
000077fbc3dcf8d9  mov [rsp+0x40], eax
000077fbc3dcf8dd  mov eax, eax
000077fbc3dcf8df  mov [r15+0x80], rax
000077fbc3dcf8e6  shr r10d, 0x0A
000077fbc3dcf8ea  mov eax, [rsp+0x10]
000077fbc3dcf8ee  xor eax, r10d
000077fbc3dcf8f1  mov [rsp+0x10], eax
000077fbc3dcf8f5  mov eax, eax
000077fbc3dcf8f7  mov [r15+0x78], rax
000077fbc3dcf8fb  mov eax, [rsp+0x40]
000077fbc3dcf8ff  lea r14d, [r8d+eax*1]
000077fbc3dcf904  mov eax, [rsp+0x10]
000077fbc3dcf908  lea r12d, [r14d+eax*1]
000077fbc3dcf90d  mov rax, [rsp+0x30]
000077fbc3dcf912  lea r14, [rax+0x40]
000077fbc3dcf916  mov [r13+r14*1], r12d
000077fbc3dcf91b  mov eax, [rsp+0x20]
000077fbc3dcf91f  mov eax, eax
000077fbc3dcf921  mov [r15+0x60], rax
000077fbc3dcf925  mov eax, [r15+0x108]
000077fbc3dcf92c  sahf
000077fbc3dcf92d  jnz 0x000077FBC3DCF95F
000077fbc3dcf92f  cmp dword ptr [r15+0x318], 0x00
000077fbc3dcf937  jz 0x000077FBC3DCFE20
000077fbc3dcf93d  nop [rax+rax*1], ax
000077fbc3dcf946  nop [rax+rax*1], eax
000077fbc3dcf94e  mov eax, 0x41049C
000077fbc3dcf953  mov [r15+0x100], rax
000077fbc3dcf95a  jmp 0x000077FBC3BFE110
000077fbc3dcf95f  cmp dword ptr [r15+0x318], 0x00
000077fbc3dcf967  jz 0x000077FBC3DCFC70
000077fbc3dcf96d  nop [rax+rax*1], ax
000077fbc3dcf976  nop [rax+rax*1], eax
000077fbc3dcf97e  mov eax, 0x410454
000077fbc3dcf983  mov [r15+0x100], rax
000077fbc3dcf98a  jmp 0x000077FBC3BFE110
000077fbc3dcf98f  int3
000077fbc3dcf990  call 0x000077FBC3C0D860
000077fbc3dcf995  jmp 0x000077FBC3DCF02A
000077fbc3dcf99a  call 0x000077FBC3CE2420
000077fbc3dcf99f  jmp 0x000077FBC3DCF043
000077fbc3dcf9a4  call 0x000077FBC3CE2420
000077fbc3dcf9a9  jmp 0x000077FBC3DCF05C
000077fbc3dcf9ae  call 0x000077FBC3CE2420
000077fbc3dcf9b3  jmp 0x000077FBC3DCF075
000077fbc3dcf9b8  call 0x000077FBC3CE2420
000077fbc3dcf9bd  jmp 0x000077FBC3DCF08E
000077fbc3dcf9c2  call 0x000077FBC3CE2420
000077fbc3dcf9c7  jmp 0x000077FBC3DCF09F
000077fbc3dcf9cc  call 0x000077FBC3CE2420
000077fbc3dcf9d1  jmp 0x000077FBC3DCF0B0
000077fbc3dcf9d6  call 0x000077FBC3CE2420
000077fbc3dcf9db  jmp 0x000077FBC3DCF0C1
000077fbc3dcf9e0  call 0x000077FBC3CE2420
000077fbc3dcf9e5  jmp 0x000077FBC3DCF0D2
000077fbc3dcf9ea  call 0x000077FBC3CE2420
000077fbc3dcf9ef  jmp 0x000077FBC3DCF0E3
000077fbc3dcf9f4  call 0x000077FBC3CE2420
000077fbc3dcf9f9  jmp 0x000077FBC3DCF0F4
000077fbc3dcf9fe  call 0x000077FBC3CE2420
000077fbc3dcfa03  jmp 0x000077FBC3DCF105
000077fbc3dcfa08  call 0x000077FBC3CE2420
000077fbc3dcfa0d  jmp 0x000077FBC3DCF116
000077fbc3dcfa12  call 0x000077FBC3CE2420
000077fbc3dcfa17  jmp 0x000077FBC3DCF127
000077fbc3dcfa1c  call 0x000077FBC3CE2420
000077fbc3dcfa21  jmp 0x000077FBC3DCF138
000077fbc3dcfa26  call 0x000077FBC3CE2420
000077fbc3dcfa2b  jmp 0x000077FBC3DCF149
000077fbc3dcfa30  call 0x000077FBC3CE2420
000077fbc3dcfa35  jmp 0x000077FBC3DCF15A
000077fbc3dcfa3a  call 0x000077FBC3CE2420
000077fbc3dcfa3f  jmp 0x000077FBC3DCF16B
000077fbc3dcfa44  call 0x000077FBC3CE2420
000077fbc3dcfa49  jmp 0x000077FBC3DCF17C
000077fbc3dcfa4e  call 0x000077FBC3CE2420
000077fbc3dcfa53  jmp 0x000077FBC3DCF18D
000077fbc3dcfa58  call 0x000077FBC3CE2420
000077fbc3dcfa5d  jmp 0x000077FBC3DCF19E
000077fbc3dcfa62  call 0x000077FBC3CE2420
000077fbc3dcfa67  jmp 0x000077FBC3DCF1AF
000077fbc3dcfa6c  call 0x000077FBC3CE2420
000077fbc3dcfa71  jmp 0x000077FBC3DCF1C0
000077fbc3dcfa76  call 0x000077FBC3CE2420
000077fbc3dcfa7b  jmp 0x000077FBC3DCF1D1
000077fbc3dcfa80  call 0x000077FBC3CE2420
000077fbc3dcfa85  jmp 0x000077FBC3DCF1E2
000077fbc3dcfa8a  call 0x000077FBC3CE2420
000077fbc3dcfa8f  jmp 0x000077FBC3DCF1F3
000077fbc3dcfa94  call 0x000077FBC3CE2420
000077fbc3dcfa99  jmp 0x000077FBC3DCF204
000077fbc3dcfa9e  call 0x000077FBC3CE2420
000077fbc3dcfaa3  jmp 0x000077FBC3DCF215
000077fbc3dcfaa8  call 0x000077FBC3CE2420
000077fbc3dcfaad  jmp 0x000077FBC3DCF226
000077fbc3dcfab2  call 0x000077FBC3CE2420
000077fbc3dcfab7  jmp 0x000077FBC3DCF237
000077fbc3dcfabc  call 0x000077FBC3CE2420
000077fbc3dcfac1  jmp 0x000077FBC3DCF248
000077fbc3dcfac6  call 0x000077FBC3CE2420
000077fbc3dcfacb  jmp 0x000077FBC3DCF259
000077fbc3dcfad0  call 0x000077FBC3CE2420
000077fbc3dcfad5  jmp 0x000077FBC3DCF26A
000077fbc3dcfada  call 0x000077FBC3CE2420
000077fbc3dcfadf  jmp 0x000077FBC3DCF27B
000077fbc3dcfae4  call 0x000077FBC3CE2420
000077fbc3dcfae9  jmp 0x000077FBC3DCF28C
000077fbc3dcfaee  call 0x000077FBC3CE2420
000077fbc3dcfaf3  jmp 0x000077FBC3DCF29D
000077fbc3dcfaf8  call 0x000077FBC3CE2420
000077fbc3dcfafd  jmp 0x000077FBC3DCF2AE
000077fbc3dcfb02  call 0x000077FBC3CE2420
000077fbc3dcfb07  jmp 0x000077FBC3DCF2BF
000077fbc3dcfb0c  call 0x000077FBC3CE2420
000077fbc3dcfb11  jmp 0x000077FBC3DCF2D0
000077fbc3dcfb16  call 0x000077FBC3CE2420
000077fbc3dcfb1b  jmp 0x000077FBC3DCF2E1
000077fbc3dcfb20  call 0x000077FBC3CE2420
000077fbc3dcfb25  jmp 0x000077FBC3DCF2F2
000077fbc3dcfb2a  call 0x000077FBC3CE2420
000077fbc3dcfb2f  jmp 0x000077FBC3DCF303
000077fbc3dcfb34  call 0x000077FBC3CE2420
000077fbc3dcfb39  jmp 0x000077FBC3DCF314
000077fbc3dcfb3e  call 0x000077FBC3CE2420
000077fbc3dcfb43  jmp 0x000077FBC3DCF325
000077fbc3dcfb48  call 0x000077FBC3CE2420
000077fbc3dcfb4d  jmp 0x000077FBC3DCF336
000077fbc3dcfb52  call 0x000077FBC3CE2420
000077fbc3dcfb57  jmp 0x000077FBC3DCF347
000077fbc3dcfb5c  call 0x000077FBC3CE2420
000077fbc3dcfb61  jmp 0x000077FBC3DCF358
000077fbc3dcfb66  call 0x000077FBC3CE2420
000077fbc3dcfb6b  jmp 0x000077FBC3DCF369
000077fbc3dcfb70  call 0x000077FBC3CE2420
000077fbc3dcfb75  jmp 0x000077FBC3DCF37A
000077fbc3dcfb7a  call 0x000077FBC3CE2420
000077fbc3dcfb7f  jmp 0x000077FBC3DCF38B
000077fbc3dcfb84  call 0x000077FBC3CE2420
000077fbc3dcfb89  jmp 0x000077FBC3DCF39C
000077fbc3dcfb8e  call 0x000077FBC3CE2420
000077fbc3dcfb93  jmp 0x000077FBC3DCF3AD
000077fbc3dcfb98  call 0x000077FBC3CE2420
000077fbc3dcfb9d  jmp 0x000077FBC3DCF3BE
000077fbc3dcfba2  call 0x000077FBC3CE2420
000077fbc3dcfba7  jmp 0x000077FBC3DCF3CF
000077fbc3dcfbac  call 0x000077FBC3CE2420
000077fbc3dcfbb1  jmp 0x000077FBC3DCF3E0
000077fbc3dcfbb6  call 0x000077FBC3CE2420
000077fbc3dcfbbb  jmp 0x000077FBC3DCF3F1
000077fbc3dcfbc0  call 0x000077FBC3CE2420
000077fbc3dcfbc5  jmp 0x000077FBC3DCF402
000077fbc3dcfbca  call 0x000077FBC3CE2420
000077fbc3dcfbcf  jmp 0x000077FBC3DCF413
000077fbc3dcfbd4  call 0x000077FBC3CE2420
000077fbc3dcfbd9  jmp 0x000077FBC3DCF424
000077fbc3dcfbde  call 0x000077FBC3CE2420
000077fbc3dcfbe3  jmp 0x000077FBC3DCF435
000077fbc3dcfbe8  call 0x000077FBC3CE2420
000077fbc3dcfbed  jmp 0x000077FBC3DCF446
000077fbc3dcfbf2  call 0x000077FBC3CE2420
000077fbc3dcfbf7  jmp 0x000077FBC3DCF45F
000077fbc3dcfbfc  call 0x000077FBC3CE2420
000077fbc3dcfc01  jmp 0x000077FBC3DCF478
000077fbc3dcfc06  call 0x000077FBC3CD5610
000077fbc3dcfc0b  jmp 0x000077FBC3DCF491
000077fbc3dcfc10  call 0x000077FBC3CDC580
000077fbc3dcfc15  jmp 0x000077FBC3DCF7FE
000077fbc3dcfc1a  call 0x000077FBC3CE46C0
000077fbc3dcfc1f  jmp 0x000077FBC3DCF808
000077fbc3dcfc24  call 0x000077FBC3C09E90
000077fbc3dcfc29  jmp 0x000077FBC3DCF80E
000077fbc3dcfc2e  call 0x000077FBC3CDB310
000077fbc3dcfc33  jmp 0x000077FBC3DCF818
000077fbc3dcfc38  call 0x000077FBC3C0DAE0
000077fbc3dcfc3d  jmp 0x000077FBC3DCF81D
000077fbc3dcfc42  call 0x000077FBC3CC0230
000077fbc3dcfc47  jmp 0x000077FBC3DCF836
000077fbc3dcfc4c  call 0x000077FBC3CC0230
000077fbc3dcfc51  jmp 0x000077FBC3DCF84B
000077fbc3dcfc56  call 0x000077FBC3CBEFC0
000077fbc3dcfc5b  jmp 0x000077FBC3DCF854
000077fbc3dcfc60  call 0x000077FBC3CE2BA0
000077fbc3dcfc65  jmp 0x000077FBC3DCF91B
000077fbc3dcfc6a  int3
000077fbc3dcfc6b  nop [rax+rax*1], eax
000077fbc3dcfc70  mov rax, [r15+0x48]
000077fbc3dcfc74  mov r14, [r15+0x58]
000077fbc3dcfc78  lea r12, [rax+r14*1]
000077fbc3dcfc7c  mov [r15+0x68], r12
000077fbc3dcfc80  lea rax, [r14+0x04]
000077fbc3dcfc84  mov [r15+0x58], rax
000077fbc3dcfc88  lea r14, [r12+0x04]
000077fbc3dcfc8d  mov r11d, [r13+r14*1]
000077fbc3dcfc92  mov [rsp+0x10], r11d
000077fbc3dcfc97  mov r11d, r11d
000077fbc3dcfc9a  mov [r15+0x70], r11
000077fbc3dcfc9e  lea r14, [r12+0x38]
000077fbc3dcfca3  mov r11d, [r13+r14*1]
000077fbc3dcfca8  lea r14, [r12+0x24]
000077fbc3dcfcad  mov r10d, [r13+r14*1]
000077fbc3dcfcb2  mov [rsp+0x20], r10d
000077fbc3dcfcb7  mov r10d, r10d
000077fbc3dcfcba  mov [r15+0x90], r10
000077fbc3dcfcc1  mov [rsp+0x30], rax
000077fbc3dcfcc6  xor eax, eax
000077fbc3dcfcc8  mov r14, [rsp+0x30]
000077fbc3dcfccd  mov r10d, 0xC0
000077fbc3dcfcd3  cmp r14, r10
000077fbc3dcfcd6  cmc
000077fbc3dcfcd7  lahf
000077fbc3dcfcd8  seto al
000077fbc3dcfcdb  mov [r15+0x108], eax
000077fbc3dcfce2  mov eax, [rsp+0x10]
000077fbc3dcfce6  mov r14d, [rsp+0x10]
000077fbc3dcfceb  shrd eax, r14d, 0x07
000077fbc3dcfcf0  mov [rsp+0x10], r11d
000077fbc3dcfcf5  mov r10d, [rsp+0x10]
000077fbc3dcfcfa  shrd r11d, r10d, 0x11
000077fbc3dcfcff  mov r9d, [r15+0x60]
000077fbc3dcfd03  mov r8d, [rsp+0x20]
000077fbc3dcfd08  lea ebp, [r8d+r9d*1]
000077fbc3dcfd0d  rorx r9d, r14d, 0x12
000077fbc3dcfd13  xor eax, r9d
000077fbc3dcfd16  rorx r9d, r10d, 0x13
000077fbc3dcfd1c  xor r11d, r9d
000077fbc3dcfd1f  mov [rsp+0x10], r11d
000077fbc3dcfd24  mov r11d, r11d
000077fbc3dcfd27  mov [r15+0x88], r11
000077fbc3dcfd2e  mov [rsp+0x20], r14d
000077fbc3dcfd33  shr r14d, 0x03
000077fbc3dcfd37  xor eax, r14d
000077fbc3dcfd3a  mov [rsp+0x30], eax
000077fbc3dcfd3e  mov eax, eax
000077fbc3dcfd40  mov [r15+0x80], rax
000077fbc3dcfd47  shr r10d, 0x0A
000077fbc3dcfd4b  mov eax, [rsp+0x10]
000077fbc3dcfd4f  xor eax, r10d
000077fbc3dcfd52  mov [rsp+0x10], eax
000077fbc3dcfd56  mov eax, eax
000077fbc3dcfd58  mov [r15+0x78], rax
000077fbc3dcfd5c  mov eax, [rsp+0x30]
000077fbc3dcfd60  lea r14d, [ebp+eax*1]
000077fbc3dcfd66  mov eax, [rsp+0x10]
000077fbc3dcfd6a  lea r11d, [r14d+eax*1]
000077fbc3dcfd6f  lea rax, [r12+0x40]
000077fbc3dcfd74  mov [r13+rax*1], r11d
000077fbc3dcfd79  mov eax, [rsp+0x20]
000077fbc3dcfd7d  mov eax, eax
000077fbc3dcfd7f  mov [r15+0x60], rax
000077fbc3dcfd83  mov eax, [r15+0x108]
000077fbc3dcfd8a  sahf
000077fbc3dcfd8b  jnz 0x000077FBC3DCFDBD
000077fbc3dcfd8d  cmp dword ptr [r15+0x318], 0x00
000077fbc3dcfd95  jz 0x000077FBC3DCFE20
000077fbc3dcfd9b  nop [rax+rax*1], ax
000077fbc3dcfda4  nop [rax+rax*1], eax
000077fbc3dcfdac  mov eax, 0x41049C
000077fbc3dcfdb1  mov [r15+0x100], rax
000077fbc3dcfdb8  jmp 0x000077FBC3BFE110
000077fbc3dcfdbd  cmp dword ptr [r15+0x318], 0x00
000077fbc3dcfdc5  jz 0x000077FBC3DCFC70
000077fbc3dcfdcb  nop [rax+rax*1], ax
000077fbc3dcfdd4  nop [rax+rax*1], eax
000077fbc3dcfddc  mov eax, 0x410454
000077fbc3dcfde1  mov [r15+0x100], rax
000077fbc3dcfde8  jmp 0x000077FBC3BFE110
000077fbc3dcfded  int3
000077fbc3dcfdee  call 0x000077FBC3CE1430
000077fbc3dcfdf3  jmp 0x000077FBC3DCFC92
000077fbc3dcfdf8  call 0x000077FBC3CE1430
000077fbc3dcfdfd  jmp 0x000077FBC3DCFCA8
000077fbc3dcfe02  call 0x000077FBC3CE01C0
000077fbc3dcfe07  jmp 0x000077FBC3DCFCB2
000077fbc3dcfe0c  call 0x000077FBC3C0A860
000077fbc3dcfe11  jmp 0x000077FBC3DCFD79
000077fbc3dcfe16  int3
000077fbc3dcfe17  nop [rax+rax*1], ax
000077fbc3dcfe20  mov rax, [r15]
000077fbc3dcfe23  mov r14d, [r13+rax*1]
000077fbc3dcfe28  lea r12, [rax+0x04]
000077fbc3dcfe2c  mov r11d, [r13+r12*1]
000077fbc3dcfe31  mov [rsp+0x10], r14d
000077fbc3dcfe36  mov r14d, r14d
000077fbc3dcfe39  mov [r15+0x78], r14
000077fbc3dcfe3d  mov [rsp+0x20], r11d
000077fbc3dcfe42  mov r11d, r11d
000077fbc3dcfe45  mov [r15+0x80], r11
000077fbc3dcfe4c  lea r14, [rax+0x08]
000077fbc3dcfe50  mov r12d, [r13+r14*1]
000077fbc3dcfe55  lea r14, [rax+0x0C]
000077fbc3dcfe59  mov r11d, [r13+r14*1]
000077fbc3dcfe5e  mov [rsp+0x30], r12d
000077fbc3dcfe63  mov r12d, r12d
000077fbc3dcfe66  mov [r15+0x70], r12
000077fbc3dcfe6a  mov [rsp+0x40], r11d
000077fbc3dcfe6f  mov r11d, r11d
000077fbc3dcfe72  mov [r15+0x68], r11
000077fbc3dcfe76  lea r14, [rax+0x18]
000077fbc3dcfe7a  mov r12d, [r13+r14*1]
000077fbc3dcfe7f  lea r14, [rax+0x1C]
000077fbc3dcfe83  mov r11d, [r13+r14*1]
000077fbc3dcfe88  mov [rsp+0x50], r12d
000077fbc3dcfe8d  mov r12d, r12d
000077fbc3dcfe90  mov [r15+0x58], r12
000077fbc3dcfe94  mov [rsp+0x60], r11d
000077fbc3dcfe99  mov r11d, r11d
000077fbc3dcfe9c  mov [r15+0x60], r11
000077fbc3dcfea0  lea r14, [rax+0x10]
000077fbc3dcfea4  mov r12d, [r13+r14*1]
000077fbc3dcfea9  lea r14, [rax+0x14]
000077fbc3dcfead  mov eax, [r13+r14*1]
000077fbc3dcfeb2  mov [rsp+0x70], r12d
000077fbc3dcfeb7  mov r12d, r12d
000077fbc3dcfeba  mov [r15+0x18], r12
000077fbc3dcfebe  mov [rsp+0x80], eax
000077fbc3dcfec5  mov eax, eax
000077fbc3dcfec7  mov [r15+0x90], rax
000077fbc3dcfece  mov eax, [rsp+0x70]
000077fbc3dcfed2  mov eax, eax
000077fbc3dcfed4  mov [r15+0x30], rax
000077fbc3dcfed8  mov eax, [rsp+0x50]
000077fbc3dcfedc  mov eax, eax
000077fbc3dcfede  mov [r15+0xA0], rax
000077fbc3dcfee5  mov eax, [rsp+0x30]
000077fbc3dcfee9  mov eax, eax
000077fbc3dcfeeb  mov [r15+0x28], rax
000077fbc3dcfeef  mov eax, [rsp+0x20]
000077fbc3dcfef3  mov eax, eax
000077fbc3dcfef5  mov [r15+0x98], rax
000077fbc3dcfefc  mov eax, [rsp+0x10]
000077fbc3dcff00  mov eax, eax
000077fbc3dcff02  mov [r15+0x38], rax
000077fbc3dcff06  mov eax, [rsp+0x70]
000077fbc3dcff0a  mov r14d, [rsp+0x70]
000077fbc3dcff0f  shrd eax, r14d, 0x06
000077fbc3dcff14  mov [rsp+0x70], r14d
000077fbc3dcff19  mov r12d, [rsp+0x80]
000077fbc3dcff21  and r14d, r12d
000077fbc3dcff24  mov r11d, [rsp+0x10]
000077fbc3dcff29  mov r10d, [rsp+0x10]
000077fbc3dcff2e  shrd r11d, r10d, 0x02
000077fbc3dcff33  mov [rsp+0x10], r12d
000077fbc3dcff38  mov r12d, r12d
000077fbc3dcff3b  mov [r15+0x20], r12
000077fbc3dcff3f  mov r12, [r15+0x50]
000077fbc3dcff43  mov r9d, [r13+r12*1]
000077fbc3dcff48  mov r12d, [rsp+0x50]
000077fbc3dcff4d  mov r8d, [rsp+0x70]
000077fbc3dcff52  andn ebp, r8d, r12d
000077fbc3dcff57  mov edi, [rsp+0x60]
000077fbc3dcff5b  lea esi, [r14d+edi*1]
000077fbc3dcff60  rorx r14d, r8d, 0x0B
000077fbc3dcff66  xor eax, r14d
000077fbc3dcff69  rorx r14d, r10d, 0x0D
000077fbc3dcff6f  xor r11d, r14d
000077fbc3dcff72  lea edi, [esi+ebp*1]
000077fbc3dcff76  mov r14, [r15+0x48]
000077fbc3dcff7a  mov ebp, [r13+r14*1]
000077fbc3dcff7f  mov r14d, [rsp+0x30]
000077fbc3dcff84  mov esi, [rsp+0x20]
000077fbc3dcff88  and r14d, esi
000077fbc3dcff8b  mov [rsp+0x20], r14d
000077fbc3dcff90  mov r14d, r14d
000077fbc3dcff93  mov [r15+0xD8], r14
000077fbc3dcff9a  lea r14d, [edi+r9d*1]
000077fbc3dcff9f  mov r9d, [rsp+0x30]
000077fbc3dcffa4  xor r9d, esi
000077fbc3dcffa7  rorx edi, r8d, 0x19
000077fbc3dcffad  xor eax, edi
000077fbc3dcffaf  and r9d, r10d
000077fbc3dcffb2  rorx edi, r10d, 0x16
000077fbc3dcffb8  xor r11d, edi
000077fbc3dcffbb  mov [rsp+0x30], r11d
000077fbc3dcffc0  mov r11d, r11d
000077fbc3dcffc3  mov [r15+0xD0], r11
000077fbc3dcffca  lea r11d, [r14d+ebp*1]
000077fbc3dcffcf  mov r10d, [rsp+0x20]
000077fbc3dcffd4  xor r9d, r10d
000077fbc3dcffd7  lea r14d, [r11d+eax*1]
000077fbc3dcffdc  mov qword ptr [r15+0x88], 0x04
000077fbc3dcffe7  mov eax, [rsp+0x30]
000077fbc3dcffeb  lea r11d, [r9d+eax*1]
000077fbc3dcfff0  mov eax, [rsp+0x40]
000077fbc3dcfff4  lea r10d, [r14d+eax*1]
000077fbc3dcfff9  mov r10d, r10d
000077fbc3dcfffc  mov [r15+0xB8], r10
000077fbc3dd0003  xor eax, eax
000077fbc3dd0005  mov r10d, 0x04
000077fbc3dd000b  mov r9d, 0x100
000077fbc3dd0011  cmp r10, r9
000077fbc3dd0014  cmc
000077fbc3dd0015  lahf
000077fbc3dd0016  seto al
000077fbc3dd0019  mov [r15+0x108], eax
000077fbc3dd0020  lea eax, [r11d+r14d*1]
000077fbc3dd0025  mov eax, eax
000077fbc3dd0027  mov [r15+0xA8], rax
000077fbc3dd002e  mov r12d, r12d
000077fbc3dd0031  mov [r15+0xB0], r12
000077fbc3dd0038  mov eax, [rsp+0x10]
000077fbc3dd003c  mov eax, eax
000077fbc3dd003e  mov [r15+0xC0], rax
000077fbc3dd0045  mov r8d, r8d
000077fbc3dd0048  mov [r15+0xC8], r8
000077fbc3dd004f  mov eax, [r15+0x108]
000077fbc3dd0056  sahf
000077fbc3dd0057  jnz 0x000077FBC3DD0089
000077fbc3dd0059  cmp dword ptr [r15+0x318], 0x00
000077fbc3dd0061  jz 0x000077FBC3DD0350
000077fbc3dd0067  nop [rax+rax*1], ax
000077fbc3dd0070  nop [rax+rax*1], eax
000077fbc3dd0078  mov eax, 0x41055C
000077fbc3dd007d  mov [r15+0x100], rax
000077fbc3dd0084  jmp 0x000077FBC3BFE110
000077fbc3dd0089  cmp dword ptr [r15+0x318], 0x00
000077fbc3dd0091  jz 0x000077FBC3DD0120
000077fbc3dd0097  nop [rax+rax*1], ax
000077fbc3dd00a0  nop [rax+rax*1], eax
000077fbc3dd00a8  mov eax, 0x4104D0
000077fbc3dd00ad  mov [r15+0x100], rax
000077fbc3dd00b4  jmp 0x000077FBC3BFE110
000077fbc3dd00b9  int3
000077fbc3dd00ba  call 0x000077FBC3C0DAE0
000077fbc3dd00bf  jmp 0x000077FBC3DCFE28
000077fbc3dd00c4  call 0x000077FBC3CC0230
000077fbc3dd00c9  jmp 0x000077FBC3DCFE31
000077fbc3dd00ce  call 0x000077FBC3CE26A0
000077fbc3dd00d3  jmp 0x000077FBC3DCFE55
000077fbc3dd00d8  call 0x000077FBC3CE1430
000077fbc3dd00dd  jmp 0x000077FBC3DCFE5E
000077fbc3dd00e2  call 0x000077FBC3CE26A0
000077fbc3dd00e7  jmp 0x000077FBC3DCFE7F
000077fbc3dd00ec  call 0x000077FBC3CE1430
000077fbc3dd00f1  jmp 0x000077FBC3DCFE88
000077fbc3dd00f6  call 0x000077FBC3CE26A0
000077fbc3dd00fb  jmp 0x000077FBC3DCFEA9
000077fbc3dd0100  call 0x000077FBC3CD5890
000077fbc3dd0105  jmp 0x000077FBC3DCFEB2
000077fbc3dd010a  call 0x000077FBC3CBDD50
000077fbc3dd010f  jmp 0x000077FBC3DCFF48
000077fbc3dd0114  call 0x000077FBC3CDA580
000077fbc3dd0119  jmp 0x000077FBC3DCFF7F
000077fbc3dd011e  int3
000077fbc3dd011f  nop
000077fbc3dd0120  mov eax, [r15+0xB8]
000077fbc3dd0127  mov [rsp+0x10], eax
000077fbc3dd012b  mov eax, eax
000077fbc3dd012d  mov [r15+0x30], rax
000077fbc3dd0131  mov eax, [r15+0xC0]
000077fbc3dd0138  mov [rsp+0x20], eax
000077fbc3dd013c  mov eax, eax
000077fbc3dd013e  mov [r15+0xA0], rax
000077fbc3dd0145  mov eax, [r15+0x28]
000077fbc3dd0149  mov r14d, [r15+0x98]
000077fbc3dd0150  mov [rsp+0x30], r14d
000077fbc3dd0155  mov r14d, r14d
000077fbc3dd0158  mov [r15+0x28], r14
000077fbc3dd015c  mov r14d, [r15+0x38]
000077fbc3dd0160  mov [rsp+0x40], r14d
000077fbc3dd0165  mov r14d, r14d
000077fbc3dd0168  mov [r15+0x98], r14
000077fbc3dd016f  mov r14d, [r15+0xA8]
000077fbc3dd0176  mov [rsp+0x50], r14d
000077fbc3dd017b  mov r14d, r14d
000077fbc3dd017e  mov [r15+0x38], r14
000077fbc3dd0182  mov r14d, [rsp+0x10]
000077fbc3dd0187  mov r12d, [rsp+0x10]
000077fbc3dd018c  shrd r14d, r12d, 0x06
000077fbc3dd0191  mov r11d, [r15+0xC8]
000077fbc3dd0198  mov [rsp+0x10], r12d
000077fbc3dd019d  and r12d, r11d
000077fbc3dd01a0  mov r10d, [rsp+0x50]
000077fbc3dd01a5  mov r9d, [rsp+0x50]
000077fbc3dd01aa  shrd r10d, r9d, 0x02
000077fbc3dd01af  mov [rsp+0x50], r11d
000077fbc3dd01b4  mov r11d, r11d
000077fbc3dd01b7  mov [r15+0x20], r11
000077fbc3dd01bb  mov r11, [r15+0x88]
000077fbc3dd01c2  mov r8, [r15+0x50]
000077fbc3dd01c6  lea rbp, [r8+r11*1]
000077fbc3dd01ca  mov r8d, [r13+rbp*1]
000077fbc3dd01cf  mov ebp, [rsp+0x20]
000077fbc3dd01d3  mov edi, [rsp+0x10]
000077fbc3dd01d7  andn esi, edi, ebp
000077fbc3dd01dc  mov edx, [r15+0xB0]
000077fbc3dd01e3  lea ecx, [r12d+edx*1]
000077fbc3dd01e8  rorx r12d, edi, 0x0B
000077fbc3dd01ee  xor r14d, r12d
000077fbc3dd01f1  rorx r12d, r9d, 0x0D
000077fbc3dd01f7  xor r10d, r12d
000077fbc3dd01fa  lea r12d, [ecx+esi*1]
000077fbc3dd01ff  mov rsi, [r15+0x48]
000077fbc3dd0203  lea rdx, [rsi+r11*1]
000077fbc3dd0207  mov esi, [r13+rdx*1]
000077fbc3dd020c  mov edx, [rsp+0x30]
000077fbc3dd0210  mov ecx, [rsp+0x40]
000077fbc3dd0214  and edx, ecx
000077fbc3dd0216  mov [rsp+0x10], edx
000077fbc3dd021a  mov edx, edx
000077fbc3dd021c  mov [r15+0xD8], rdx
000077fbc3dd0223  lea edx, [r12d+r8d*1]
000077fbc3dd0228  mov r12d, [rsp+0x30]
000077fbc3dd022d  xor r12d, ecx
000077fbc3dd0230  rorx r8d, edi, 0x19
000077fbc3dd0236  xor r14d, r8d
000077fbc3dd0239  and r12d, r9d
000077fbc3dd023c  rorx r8d, r9d, 0x16
000077fbc3dd0242  xor r10d, r8d
000077fbc3dd0245  mov [rsp+0x20], r10d
000077fbc3dd024a  mov r10d, r10d
000077fbc3dd024d  mov [r15+0xD0], r10
000077fbc3dd0254  lea r10d, [edx+esi*1]
000077fbc3dd0259  mov r9d, [rsp+0x10]
000077fbc3dd025e  xor r12d, r9d
000077fbc3dd0261  lea r9d, [r10d+r14d*1]
000077fbc3dd0266  lea r14, [r11+0x04]
000077fbc3dd026a  mov [r15+0x88], r14
000077fbc3dd0271  mov r11d, [rsp+0x20]
000077fbc3dd0276  lea r10d, [r12d+r11d*1]
000077fbc3dd027b  lea r11d, [r9d+eax*1]
000077fbc3dd0280  mov r11d, r11d
000077fbc3dd0283  mov [r15+0xB8], r11
000077fbc3dd028a  xor eax, eax
000077fbc3dd028c  mov r12d, 0x100
000077fbc3dd0292  cmp r14, r12
000077fbc3dd0295  cmc
000077fbc3dd0296  lahf
000077fbc3dd0297  seto al
000077fbc3dd029a  mov [r15+0x108], eax
000077fbc3dd02a1  lea eax, [r10d+r9d*1]
000077fbc3dd02a6  mov eax, eax
000077fbc3dd02a8  mov [r15+0xA8], rax
000077fbc3dd02af  mov ebp, ebp
000077fbc3dd02b1  mov [r15+0xB0], rbp
000077fbc3dd02b8  mov eax, [rsp+0x50]
000077fbc3dd02bc  mov eax, eax
000077fbc3dd02be  mov [r15+0xC0], rax
000077fbc3dd02c5  mov edi, edi
000077fbc3dd02c7  mov [r15+0xC8], rdi
000077fbc3dd02ce  mov eax, [r15+0x108]
000077fbc3dd02d5  sahf
000077fbc3dd02d6  jnz 0x000077FBC3DD0308
000077fbc3dd02d8  cmp dword ptr [r15+0x318], 0x00
000077fbc3dd02e0  jz 0x000077FBC3DD0350
000077fbc3dd02e6  nop [rax+rax*1], ax
000077fbc3dd02ef  nop [rax+rax*1], eax
000077fbc3dd02f7  mov eax, 0x41055C
000077fbc3dd02fc  mov [r15+0x100], rax
000077fbc3dd0303  jmp 0x000077FBC3BFE110
000077fbc3dd0308  cmp dword ptr [r15+0x318], 0x00
000077fbc3dd0310  jz 0x000077FBC3DD0120
000077fbc3dd0316  nop [rax+rax*1], ax
000077fbc3dd031f  nop [rax+rax*1], eax
000077fbc3dd0327  mov eax, 0x4104D0
000077fbc3dd032c  mov [r15+0x100], rax
000077fbc3dd0333  jmp 0x000077FBC3BFE110
000077fbc3dd0338  int3
000077fbc3dd0339  call 0x000077FBC3C49010
000077fbc3dd033e  jmp 0x000077FBC3DD01CF
000077fbc3dd0343  call 0x000077FBC3C25930
000077fbc3dd0348  jmp 0x000077FBC3DD020C
000077fbc3dd034d  int3
000077fbc3dd034e  nop
000077fbc3dd0350  mov eax, [r15+0x98]
000077fbc3dd0357  mov r14d, [r15+0x70]
000077fbc3dd035b  lea r12d, [eax+r14d*1]
000077fbc3dd0360  mov eax, [r15+0x28]
000077fbc3dd0364  mov r14d, [r15+0x68]
000077fbc3dd0368  lea r11d, [eax+r14d*1]
000077fbc3dd036d  mov qword ptr [r15+0x88], 0x00
000077fbc3dd0378  mov eax, [r15+0xA8]
000077fbc3dd037f  mov r14d, [r15+0x78]
000077fbc3dd0383  lea r10d, [eax+r14d*1]
000077fbc3dd0388  mov [rsp+0x10], r10d
000077fbc3dd038d  mov r10d, r10d
000077fbc3dd0390  mov [r15+0x78], r10
000077fbc3dd0394  mov eax, [r15+0x38]
000077fbc3dd0398  mov r14d, [r15+0x80]
000077fbc3dd039f  lea r10d, [eax+r14d*1]
000077fbc3dd03a4  mov [rsp+0x20], r10d
000077fbc3dd03a9  mov r10d, r10d
000077fbc3dd03ac  mov [r15+0x80], r10
000077fbc3dd03b3  mov rax, [r15]
000077fbc3dd03b6  lea r14, [rax+0x08]
000077fbc3dd03ba  mov [r13+r14*1], r12d
000077fbc3dd03bf  lea r14, [rax+0x0C]
000077fbc3dd03c3  mov [r13+r14*1], r11d
000077fbc3dd03c8  mov r14d, [r15+0xB8]
000077fbc3dd03cf  mov r12d, [r15+0x18]
000077fbc3dd03d3  lea r11d, [r14d+r12d*1]
000077fbc3dd03d8  mov [rsp+0x30], r11d
000077fbc3dd03dd  mov r11d, r11d
000077fbc3dd03e0  mov [r15+0x68], r11
000077fbc3dd03e4  mov r14d, [r15+0x30]
000077fbc3dd03e8  mov r12d, [r15+0x90]
000077fbc3dd03ef  lea r11d, [r14d+r12d*1]
000077fbc3dd03f4  mov [rsp+0x40], r11d
000077fbc3dd03f9  mov r11d, r11d
000077fbc3dd03fc  mov [r15+0x70], r11
000077fbc3dd0400  mov r14d, [r15+0x20]
000077fbc3dd0404  mov r12d, [r15+0x58]
000077fbc3dd0408  lea r11d, [r14d+r12d*1]
000077fbc3dd040d  mov [rsp+0x50], r11d
000077fbc3dd0412  mov r11d, r11d
000077fbc3dd0415  mov [r15+0x58], r11
000077fbc3dd0419  mov r14d, [r15+0xA0]
000077fbc3dd0420  mov r12d, [r15+0x60]
000077fbc3dd0424  lea r11d, [r14d+r12d*1]
000077fbc3dd0429  mov [rsp+0x60], r11d
000077fbc3dd042e  mov r11d, r11d
000077fbc3dd0431  mov [r15+0x60], r11
000077fbc3dd0435  mov r14d, [rsp+0x10]
000077fbc3dd043a  mov [r13+rax*1], r14d
000077fbc3dd043f  lea r14, [rax+0x04]
000077fbc3dd0443  mov r12d, [rsp+0x20]
000077fbc3dd0448  mov [r13+r14*1], r12d
000077fbc3dd044d  lea r14, [rax+0x10]
000077fbc3dd0451  mov r12d, [rsp+0x30]
000077fbc3dd0456  mov [r13+r14*1], r12d
000077fbc3dd045b  lea r14, [rax+0x14]
000077fbc3dd045f  mov r12d, [rsp+0x40]
000077fbc3dd0464  mov [r13+r14*1], r12d
000077fbc3dd0469  lea r14, [rax+0x18]
000077fbc3dd046d  mov r12d, [rsp+0x50]
000077fbc3dd0472  mov [r13+r14*1], r12d
000077fbc3dd0477  lea r14, [rax+0x1C]
000077fbc3dd047b  mov r12d, [rsp+0x60]
000077fbc3dd0480  mov [r13+r14*1], r12d
000077fbc3dd0485  lea r14, [rax+0x68]
000077fbc3dd0489  xor eax, eax
000077fbc3dd048b  mov [r13+r14*1], rax
000077fbc3dd0490  cmp dword ptr [r15+0x318], 0x00
000077fbc3dd0498  jz 0x000077FBC3DCEF90
000077fbc3dd049e  nop [rax+rax*1], ax
000077fbc3dd04a7  nop [rax+rax*1], eax
000077fbc3dd04af  mov eax, 0x410378
000077fbc3dd04b4  mov [r15+0x100], rax
000077fbc3dd04bb  jmp 0x000077FBC3BFE110
000077fbc3dd04c0  int3
000077fbc3dd04c1  call 0x000077FBC3CE2BA0
000077fbc3dd04c6  jmp 0x000077FBC3DD03BF
000077fbc3dd04cb  call 0x000077FBC3CE1920
000077fbc3dd04d0  jmp 0x000077FBC3DD03C8
000077fbc3dd04d5  call 0x000077FBC3C0DFE0
000077fbc3dd04da  jmp 0x000077FBC3DD043F
000077fbc3dd04df  call 0x000077FBC3CE2BA0
000077fbc3dd04e4  jmp 0x000077FBC3DD044D
000077fbc3dd04e9  call 0x000077FBC3CE2BA0
000077fbc3dd04ee  jmp 0x000077FBC3DD045B
000077fbc3dd04f3  call 0x000077FBC3CE2BA0
000077fbc3dd04f8  jmp 0x000077FBC3DD0469
000077fbc3dd04fd  call 0x000077FBC3CE2BA0
000077fbc3dd0502  jmp 0x000077FBC3DD0477
000077fbc3dd0507  call 0x000077FBC3CE2BA0
000077fbc3dd050c  jmp 0x000077FBC3DD0485
000077fbc3dd0511  call 0x000077FBC3CD5EB0
000077fbc3dd0516  jmp 0x000077FBC3DD0490
000077fbc3dd051b  int3
000077fbc3dd051c  nop [rax], eax
000077fbc3dd0520  mov rax, [r15+0xF8]
000077fbc3dd0527  lea r14, [rax+0x140]
000077fbc3dd052e  mov r12, [r13+r14*1]
000077fbc3dd0533  lea r14, [rax+0x148]
000077fbc3dd053a  mov r11, [r13+r14*1]
000077fbc3dd053f  mov [r15+0xA0], r12
000077fbc3dd0546  mov [r15+0x98], r11
000077fbc3dd054d  lea r14, [rax+0x130]
000077fbc3dd0554  mov r12, [r13+r14*1]
000077fbc3dd0559  lea r14, [rax+0x138]
000077fbc3dd0560  mov r11, [r13+r14*1]
000077fbc3dd0565  mov [r15+0xB0], r12
000077fbc3dd056c  mov [r15+0xA8], r11
000077fbc3dd0573  lea r14, [rax+0x120]
000077fbc3dd057a  mov r12, [r13+r14*1]
000077fbc3dd057f  lea r14, [rax+0x128]
000077fbc3dd0586  mov r11, [r13+r14*1]
000077fbc3dd058b  mov [r15+0xC0], r12
000077fbc3dd0592  mov [r15+0xB8], r11
000077fbc3dd0599  lea r14, [rax+0x110]
000077fbc3dd05a0  mov r12, [r13+r14*1]
000077fbc3dd05a5  lea r14, [rax+0x118]
000077fbc3dd05ac  mov r11, [r13+r14*1]
000077fbc3dd05b1  mov [r15+0xD0], r12
000077fbc3dd05b8  mov [r15+0xC8], r11
000077fbc3dd05bf  lea r14, [rax+0x100]
000077fbc3dd05c6  mov r12, [r13+r14*1]
000077fbc3dd05cb  lea r14, [rax+0x108]
000077fbc3dd05d2  mov r11, [r13+r14*1]
000077fbc3dd05d7  mov [r15+0xE8], r12
000077fbc3dd05de  mov [r15+0xD8], r11
000077fbc3dd05e5  lea r14, [rax+0x150]
000077fbc3dd05ec  mov [r15+0xF8], r14
000077fbc3dd05f3  mov rax, [r15+0xF0]
000077fbc3dd05fa  mov [r15+0x100], rax
000077fbc3dd0601  jmp 0x000077FBC3DCE5C0
000077fbc3dd0606  int3
000077fbc3dd0607  call 0x000077FBC3CE27E0
000077fbc3dd060c  jmp 0x000077FBC3DD0533
000077fbc3dd0611  call 0x000077FBC3CE1570
000077fbc3dd0616  jmp 0x000077FBC3DD053F
000077fbc3dd061b  call 0x000077FBC3CE27E0
000077fbc3dd0620  jmp 0x000077FBC3DD0559
000077fbc3dd0625  call 0x000077FBC3CE1570
000077fbc3dd062a  jmp 0x000077FBC3DD0565
000077fbc3dd062f  call 0x000077FBC3CE27E0
000077fbc3dd0634  jmp 0x000077FBC3DD057F
000077fbc3dd0639  call 0x000077FBC3CE1570
000077fbc3dd063e  jmp 0x000077FBC3DD058B
000077fbc3dd0643  call 0x000077FBC3CE27E0
000077fbc3dd0648  jmp 0x000077FBC3DD05A5
000077fbc3dd064d  call 0x000077FBC3CE1570
000077fbc3dd0652  jmp 0x000077FBC3DD05B1
000077fbc3dd0657  call 0x000077FBC3CE27E0
000077fbc3dd065c  jmp 0x000077FBC3DD05CB
000077fbc3dd0661  call 0x000077FBC3CE1570
000077fbc3dd0666  jmp 0x000077FBC3DD05D7
000077fbc3dd066b  int3
000077fbc3dd066c  nop [rax], eax
000077fbc3dd0670  mov eax, [r15+0xA0]
000077fbc3dd0677  mov [rsp+0x10], eax
000077fbc3dd067b  xor eax, eax
000077fbc3dd067d  mov r14d, [rsp+0x10]
000077fbc3dd0682  sub r14d, 0x01
000077fbc3dd0686  cmc
000077fbc3dd0687  lahf
000077fbc3dd0688  seto al
000077fbc3dd068b  mov [r15+0x108], eax
000077fbc3dd0692  mov r14d, r14d
000077fbc3dd0695  mov [r15+0xA0], r14
000077fbc3dd069c  mov eax, [r15+0x108]
000077fbc3dd06a3  sahf
000077fbc3dd06a4  jnz 0x000077FBC3DD06D6
000077fbc3dd06a6  cmp dword ptr [r15+0x318], 0x00
000077fbc3dd06ae  jz 0x000077FBC3DD07A0
000077fbc3dd06b4  nop [rax+rax*1], ax
000077fbc3dd06bd  nop [rax+rax*1], eax
000077fbc3dd06c5  mov eax, 0x41027C
000077fbc3dd06ca  mov [r15+0x100], rax
000077fbc3dd06d1  jmp 0x000077FBC3BFE110
000077fbc3dd06d6  cmp dword ptr [r15+0x318], 0x00
000077fbc3dd06de  jz 0x000077FBC3DD0710
000077fbc3dd06e4  nop [rax+rax*1], ax
000077fbc3dd06ed  nop [rax+rax*1], eax
000077fbc3dd06f5  mov eax, 0x410264
000077fbc3dd06fa  mov [r15+0x100], rax
000077fbc3dd0701  jmp 0x000077FBC3BFE110
000077fbc3dd0706  int3
000077fbc3dd0707  int3
000077fbc3dd0708  nop [rax+rax*1], eax
000077fbc3dd0710  mov rax, [r15+0xF8]
000077fbc3dd0717  mov [r15], rax
000077fbc3dd071a  mov rax, [r15+0x98]
000077fbc3dd0721  mov [r15+0x08], rax
000077fbc3dd0725  mov qword ptr [r15+0x10], 0x12C
000077fbc3dd072d  mov qword ptr [r15+0xF0], 0x410274
000077fbc3dd0738  mov r14d, [r15+0x320]
000077fbc3dd073f  mov eax, 0x410274
000077fbc3dd0744  mov rcx, 0x77FBC3DD0670
000077fbc3dd074e  mov [r15+r14*8+0x328], rax
000077fbc3dd0756  mov [r15+r14*8+0x368], rcx
000077fbc3dd075e  add r14d, 0x01
000077fbc3dd0762  and r14d, 0x07
000077fbc3dd0766  mov [r15+0x320], r14d
000077fbc3dd076d  cmp dword ptr [r15+0x318], 0x00
000077fbc3dd0775  jz 0x000077FBC3DCEC20
000077fbc3dd077b  nop [rax+rax*1], ax
000077fbc3dd0784  nop [rax+rax*1], eax
000077fbc3dd078c  mov eax, 0x410338
000077fbc3dd0791  mov [r15+0x100], rax
000077fbc3dd0798  jmp 0x000077FBC3BFE110
000077fbc3dd079d  int3
000077fbc3dd079e  int3
000077fbc3dd079f  nop
000077fbc3dd07a0  mov rax, [r15+0xF8]
000077fbc3dd07a7  lea r14, [rax+0x20]
000077fbc3dd07ab  mov r12, [r13+r14*1]
000077fbc3dd07b0  mov [r15+0x98], r12
000077fbc3dd07b7  mov qword ptr [r15+0x40], 0x80
000077fbc3dd07bf  mov [r15], rax
000077fbc3dd07c2  lea r14, [rax+0x8C]
000077fbc3dd07c9  mov [r15+0x08], r14
000077fbc3dd07cd  mov qword ptr [r15+0x10], 0x01
000077fbc3dd07d5  lea r14, [rax+0x8C]
000077fbc3dd07dc  mov eax, 0x80
000077fbc3dd07e1  mov [r13+r14*1], al
000077fbc3dd07e6  mov qword ptr [r15+0xF0], 0x410298
000077fbc3dd07f1  mov r14d, [r15+0x320]
000077fbc3dd07f8  mov eax, 0x410298
000077fbc3dd07fd  mov rcx, 0x77FBC3DD0870
000077fbc3dd0807  mov [r15+r14*8+0x328], rax
000077fbc3dd080f  mov [r15+r14*8+0x368], rcx
000077fbc3dd0817  add r14d, 0x01
000077fbc3dd081b  and r14d, 0x07
000077fbc3dd081f  mov [r15+0x320], r14d
000077fbc3dd0826  cmp dword ptr [r15+0x318], 0x00
000077fbc3dd082e  jz 0x000077FBC3DCEC20
000077fbc3dd0834  nop [rax+rax*1], ax
000077fbc3dd083d  nop [rax+rax*1], eax
000077fbc3dd0845  mov eax, 0x410338
000077fbc3dd084a  mov [r15+0x100], rax
000077fbc3dd0851  jmp 0x000077FBC3BFE110
000077fbc3dd0856  int3
000077fbc3dd0857  call 0x000077FBC3CE27E0
000077fbc3dd085c  jmp 0x000077FBC3DD07B0
000077fbc3dd0861  call 0x000077FBC3CD5AF0
000077fbc3dd0866  jmp 0x000077FBC3DD07E6
000077fbc3dd086b  int3
000077fbc3dd086c  nop [rax], eax
000077fbc3dd0870  mov rax, [r15+0xF8]
000077fbc3dd0877  lea r14, [rax+0x68]
000077fbc3dd087b  mov r12, [r13+r14*1]
000077fbc3dd0880  mov [r15+0x40], r12
000077fbc3dd0884  lea r14, [rax+0x88]
000077fbc3dd088b  xor eax, eax
000077fbc3dd088d  mov [r13+r14*1], al
000077fbc3dd0892  xor eax, eax
000077fbc3dd0894  mov r14d, 0x38
000077fbc3dd089a  cmp r12, r14
000077fbc3dd089d  cmc
000077fbc3dd089e  lahf
000077fbc3dd089f  seto al
000077fbc3dd08a2  mov [r15+0x108], eax
000077fbc3dd08a9  mov eax, [r15+0x108]
000077fbc3dd08b0  sahf
000077fbc3dd08b1  jz 0x000077FBC3DD08E3
000077fbc3dd08b3  cmp dword ptr [r15+0x318], 0x00
000077fbc3dd08bb  jz 0x000077FBC3DD0930
000077fbc3dd08c1  nop [rax+rax*1], ax
000077fbc3dd08ca  nop [rax+rax*1], eax
000077fbc3dd08d2  mov eax, 0x4102A8
000077fbc3dd08d7  mov [r15+0x100], rax
000077fbc3dd08de  jmp 0x000077FBC3BFE110
000077fbc3dd08e3  cmp dword ptr [r15+0x318], 0x00
000077fbc3dd08eb  jz 0x000077FBC3DD0A70
000077fbc3dd08f1  nop [rax+rax*1], ax
000077fbc3dd08fa  nop [rax+rax*1], eax
000077fbc3dd0902  mov eax, 0x4102C4
000077fbc3dd0907  mov [r15+0x100], rax
000077fbc3dd090e  jmp 0x000077FBC3BFE110
000077fbc3dd0913  int3
000077fbc3dd0914  call 0x000077FBC3CE27E0
000077fbc3dd0919  jmp 0x000077FBC3DD0880
000077fbc3dd091e  call 0x000077FBC3CD5AF0
000077fbc3dd0923  jmp 0x000077FBC3DD0892
000077fbc3dd0928  int3
000077fbc3dd0929  nop [rax], eax
000077fbc3dd0930  mov rax, [r15+0xF8]
000077fbc3dd0937  mov [r15], rax
000077fbc3dd093a  lea r14, [rax+0x88]
000077fbc3dd0941  mov [r15+0x08], r14
000077fbc3dd0945  mov qword ptr [r15+0x10], 0x01
000077fbc3dd094d  mov qword ptr [r15+0xF0], 0x4102B8
000077fbc3dd0958  mov r14d, [r15+0x320]
000077fbc3dd095f  mov eax, 0x4102B8
000077fbc3dd0964  mov rcx, 0x77FBC3DD09C0
000077fbc3dd096e  mov [r15+r14*8+0x328], rax
000077fbc3dd0976  mov [r15+r14*8+0x368], rcx
000077fbc3dd097e  add r14d, 0x01
000077fbc3dd0982  and r14d, 0x07
000077fbc3dd0986  mov [r15+0x320], r14d
000077fbc3dd098d  cmp dword ptr [r15+0x318], 0x00
000077fbc3dd0995  jz 0x000077FBC3DCEC20
000077fbc3dd099b  nop [rax+rax*1], ax
000077fbc3dd09a4  nop [rax+rax*1], eax
000077fbc3dd09ac  mov eax, 0x410338
000077fbc3dd09b1  mov [r15+0x100], rax
000077fbc3dd09b8  jmp 0x000077FBC3BFE110
000077fbc3dd09bd  int3
000077fbc3dd09be  int3
000077fbc3dd09bf  nop
000077fbc3dd09c0  mov rax, [r15+0xF8]
000077fbc3dd09c7  lea r14, [rax+0x68]
000077fbc3dd09cb  mov rax, [r13+r14*1]
000077fbc3dd09d0  mov [r15+0x40], rax
000077fbc3dd09d4  mov [rsp+0x10], rax
000077fbc3dd09d9  xor eax, eax
000077fbc3dd09db  mov r14, [rsp+0x10]
000077fbc3dd09e0  mov r12d, 0x38
000077fbc3dd09e6  cmp r14, r12
000077fbc3dd09e9  cmc
000077fbc3dd09ea  lahf
000077fbc3dd09eb  seto al
000077fbc3dd09ee  mov [r15+0x108], eax
000077fbc3dd09f5  mov eax, [r15+0x108]
000077fbc3dd09fc  sahf
000077fbc3dd09fd  jnz 0x000077FBC3DD0A2F
000077fbc3dd09ff  cmp dword ptr [r15+0x318], 0x00
000077fbc3dd0a07  jz 0x000077FBC3DD0A70
000077fbc3dd0a0d  nop [rax+rax*1], ax
000077fbc3dd0a16  nop [rax+rax*1], eax
000077fbc3dd0a1e  mov eax, 0x4102C4
000077fbc3dd0a23  mov [r15+0x100], rax
000077fbc3dd0a2a  jmp 0x000077FBC3BFE110
000077fbc3dd0a2f  cmp dword ptr [r15+0x318], 0x00
000077fbc3dd0a37  jz 0x000077FBC3DD0930
000077fbc3dd0a3d  nop [rax+rax*1], ax
000077fbc3dd0a46  nop [rax+rax*1], eax
000077fbc3dd0a4e  mov eax, 0x4102A8
000077fbc3dd0a53  mov [r15+0x100], rax
000077fbc3dd0a5a  jmp 0x000077FBC3BFE110
000077fbc3dd0a5f  int3
000077fbc3dd0a60  call 0x000077FBC3CD59C0
000077fbc3dd0a65  jmp 0x000077FBC3DD09D0
000077fbc3dd0a6a  int3
000077fbc3dd0a6b  nop [rax+rax*1], eax
000077fbc3dd0a70  mov rax, [r15+0x98]
000077fbc3dd0a77  rorx r14, rax, 0x3D
000077fbc3dd0a7d  and r14, 0xFFFFFFFFFFFFFFF8
000077fbc3dd0a81  mov rax, [r15+0xF8]
000077fbc3dd0a88  mov [r15], rax
000077fbc3dd0a8b  lea r12, [rax+0x78]
000077fbc3dd0a8f  mov [r15+0x08], r12
000077fbc3dd0a93  mov qword ptr [r15+0x10], 0x08
000077fbc3dd0a9b  bswap r14
000077fbc3dd0a9e  mov [r15+0x40], r14
000077fbc3dd0aa2  lea r12, [rax+0x78]
000077fbc3dd0aa6  mov [r13+r12*1], r14
000077fbc3dd0aab  mov qword ptr [r15+0xF0], 0x4102E0
000077fbc3dd0ab6  mov r14d, [r15+0x320]
000077fbc3dd0abd  mov eax, 0x4102E0
000077fbc3dd0ac2  mov rcx, 0x77FBC3DD0B30
000077fbc3dd0acc  mov [r15+r14*8+0x328], rax
000077fbc3dd0ad4  mov [r15+r14*8+0x368], rcx
000077fbc3dd0adc  add r14d, 0x01
000077fbc3dd0ae0  and r14d, 0x07
000077fbc3dd0ae4  mov [r15+0x320], r14d
000077fbc3dd0aeb  cmp dword ptr [r15+0x318], 0x00
000077fbc3dd0af3  jz 0x000077FBC3DCEC20
000077fbc3dd0af9  nop [rax+rax*1], ax
000077fbc3dd0b02  nop [rax+rax*1], eax
000077fbc3dd0b0a  mov eax, 0x410338
000077fbc3dd0b0f  mov [r15+0x100], rax
000077fbc3dd0b16  jmp 0x000077FBC3BFE110
000077fbc3dd0b1b  int3
000077fbc3dd0b1c  call 0x000077FBC3CC3FE0
000077fbc3dd0b21  jmp 0x000077FBC3DD0AAB
000077fbc3dd0b26  int3
000077fbc3dd0b27  nop [rax+rax*1], ax
000077fbc3dd0b30  mov rax, [r15+0xF8]
000077fbc3dd0b37  mov r14d, [r13+rax*1]
000077fbc3dd0b3c  lea r12, [rax+0x04]
000077fbc3dd0b40  mov r11d, [r13+r12*1]
000077fbc3dd0b45  lea r12, [rax+0x08]
000077fbc3dd0b49  mov r10d, [r13+r12*1]
000077fbc3dd0b4e  lea r12, [rax+0x0C]
000077fbc3dd0b52  mov r9d, [r13+r12*1]
000077fbc3dd0b57  mov qword ptr [r15+0x48], 0x430860
000077fbc3dd0b5f  lea r12, [rax+0x80]
000077fbc3dd0b66  mov r8, [r13+r12*1]
000077fbc3dd0b6b  mov [r15+0xF0], r8
000077fbc3dd0b72  bswap r14d
000077fbc3dd0b75  bswap r11d
000077fbc3dd0b78  mov r12d, 0x430860
000077fbc3dd0b7e  mov [r13+r12*1], r14d
000077fbc3dd0b83  mov r14d, 0x430864
000077fbc3dd0b89  mov [r13+r14*1], r11d
000077fbc3dd0b8e  bswap r10d
000077fbc3dd0b91  bswap r9d
000077fbc3dd0b94  lea r14, [rax+0x10]
000077fbc3dd0b98  mov r12d, [r13+r14*1]
000077fbc3dd0b9d  lea r14, [rax+0x14]
000077fbc3dd0ba1  mov r11d, [r13+r14*1]
000077fbc3dd0ba6  mov r14d, 0x430868
000077fbc3dd0bac  mov [r13+r14*1], r10d
000077fbc3dd0bb1  mov r14d, 0x43086C
000077fbc3dd0bb7  mov [r13+r14*1], r9d
000077fbc3dd0bbc  lea r14, [rax+0x90]
000077fbc3dd0bc3  mov r10, [r13+r14*1]
000077fbc3dd0bc8  lea r14, [rax+0x98]
000077fbc3dd0bcf  mov r9, [r13+r14*1]
000077fbc3dd0bd4  mov [r15+0xA0], r10
000077fbc3dd0bdb  mov [r15+0x98], r9
000077fbc3dd0be2  bswap r12d
000077fbc3dd0be5  bswap r11d
000077fbc3dd0be8  mov [rsp+0x10], r11d
000077fbc3dd0bed  mov r11d, r11d
000077fbc3dd0bf0  mov [r15+0x58], r11
000077fbc3dd0bf4  lea r14, [rax+0x18]
000077fbc3dd0bf8  mov r11d, [r13+r14*1]
000077fbc3dd0bfd  lea r14, [rax+0x1C]
000077fbc3dd0c01  mov r10d, [r13+r14*1]
000077fbc3dd0c06  mov [rsp+0x20], r10d
000077fbc3dd0c0b  mov r10d, r10d
000077fbc3dd0c0e  mov [r15+0x60], r10
000077fbc3dd0c12  mov r14d, 0x430870
000077fbc3dd0c18  mov [r13+r14*1], r12d
000077fbc3dd0c1d  mov r14d, 0x430874
000077fbc3dd0c23  mov r12d, [rsp+0x10]
000077fbc3dd0c28  mov [r13+r14*1], r12d
000077fbc3dd0c2d  bswap r11d
000077fbc3dd0c30  mov [rsp+0x10], r11d
000077fbc3dd0c35  mov r11d, r11d
000077fbc3dd0c38  mov [r15+0x40], r11
000077fbc3dd0c3c  mov r14d, [rsp+0x20]
000077fbc3dd0c41  bswap r14d
000077fbc3dd0c44  mov [rsp+0x20], r14d
000077fbc3dd0c49  mov r14d, r14d
000077fbc3dd0c4c  mov [r15+0x50], r14
000077fbc3dd0c50  mov r14d, 0x430878
000077fbc3dd0c56  mov r12d, [rsp+0x10]
000077fbc3dd0c5b  mov [r13+r14*1], r12d
000077fbc3dd0c60  mov r14d, 0x43087C
000077fbc3dd0c66  mov r12d, [rsp+0x20]
000077fbc3dd0c6b  mov [r13+r14*1], r12d
000077fbc3dd0c70  lea r14, [rax+0xA0]
000077fbc3dd0c77  mov [r15+0xF8], r14
000077fbc3dd0c7e  mov [r15+0x100], r8
000077fbc3dd0c85  jmp 0x000077FBC3DCE5C0
000077fbc3dd0c8a  int3
000077fbc3dd0c8b  call 0x000077FBC3C0DAE0
000077fbc3dd0c90  jmp 0x000077FBC3DD0B3C
000077fbc3dd0c95  call 0x000077FBC3CC0230
000077fbc3dd0c9a  jmp 0x000077FBC3DD0B45
000077fbc3dd0c9f  call 0x000077FBC3CBEFC0
000077fbc3dd0ca4  jmp 0x000077FBC3DD0B4E
000077fbc3dd0ca9  call 0x000077FBC3CBDD50
000077fbc3dd0cae  jmp 0x000077FBC3DD0B57
000077fbc3dd0cb3  call 0x000077FBC3CBCC20
000077fbc3dd0cb8  jmp 0x000077FBC3DD0B6B
000077fbc3dd0cbd  call 0x000077FBC3CC3EA0
000077fbc3dd0cc2  jmp 0x000077FBC3DD0B83
000077fbc3dd0cc7  call 0x000077FBC3CE1920
000077fbc3dd0ccc  jmp 0x000077FBC3DD0B8E
000077fbc3dd0cd1  call 0x000077FBC3CE26A0
000077fbc3dd0cd6  jmp 0x000077FBC3DD0B9D
000077fbc3dd0cdb  call 0x000077FBC3CE1430
000077fbc3dd0ce0  jmp 0x000077FBC3DD0BA6
000077fbc3dd0ce5  call 0x000077FBC3CE06B0
000077fbc3dd0cea  jmp 0x000077FBC3DD0BB1
000077fbc3dd0cef  call 0x000077FBC3CDF440
000077fbc3dd0cf4  jmp 0x000077FBC3DD0BBC
000077fbc3dd0cf9  call 0x000077FBC3CE0300
000077fbc3dd0cfe  jmp 0x000077FBC3DD0BC8
000077fbc3dd0d03  call 0x000077FBC3CDF090
000077fbc3dd0d08  jmp 0x000077FBC3DD0BD4
000077fbc3dd0d0d  call 0x000077FBC3CE1430
000077fbc3dd0d12  jmp 0x000077FBC3DD0BFD
000077fbc3dd0d17  call 0x000077FBC3CE01C0
000077fbc3dd0d1c  jmp 0x000077FBC3DD0C06
000077fbc3dd0d21  call 0x000077FBC3CE2BA0
000077fbc3dd0d26  jmp 0x000077FBC3DD0C1D
000077fbc3dd0d2b  call 0x000077FBC3CE2BA0
000077fbc3dd0d30  jmp 0x000077FBC3DD0C2D
000077fbc3dd0d35  call 0x000077FBC3CE2BA0
000077fbc3dd0d3a  jmp 0x000077FBC3DD0C60
000077fbc3dd0d3f  call 0x000077FBC3CE2BA0
000077fbc3dd0d44  jmp 0x000077FBC3DD0C70
000077fbc3dd0d49  int3
000077fbc3dd0d4a  nop [rax+rax*1], ax
000077fbc3dd0d50  mov qword ptr [r15+0x100], 0x04
000077fbc3dd0d5b  mov esi, 0x00
000077fbc3dd0d60  mov edx, 0x09
000077fbc3dd0d65  mov rdi, 0x7FFD57F40D00
000077fbc3dd0d6f  mov rax, 0x56A27AF80970
000077fbc3dd0d79  call rax
000077fbc3dd0d7b  cmp dword ptr [r15+0x318], 0x00
000077fbc3dd0d83  jnz 0x000077FBC3BFE110
000077fbc3dd0d89  jmp 0x000077FBC3BFE0A0
000077fbc3dd0d8e  int3
000077fbc3dd0d8f  int3
