000072acf27ce69b  nop [rax+rax*1], eax
000072acf27ce6a0  mov rax, [r15+0xF8]
000072acf27ce6a7  lea r14, [rax-0xA0]
000072acf27ce6ae  mov [r15+0xF8], r14
000072acf27ce6b5  lea rax, [r14+0x90]
000072acf27ce6bc  mov r12, [r15+0xA0]
000072acf27ce6c3  mov r11, [r15+0x98]
000072acf27ce6ca  mov [r13+rax*1], r12
000072acf27ce6cf  lea rax, [r14+0x98]
000072acf27ce6d6  mov [r13+rax*1], r11
000072acf27ce6db  mov eax, 0x420670
000072acf27ce6e0  movups xmm1, [r13+rax*1]
000072acf27ce6e6  mov eax, 0x420610
000072acf27ce6eb  movups xmm15, [r13+rax*1]
000072acf27ce6f1  mov eax, 0x420690
000072acf27ce6f6  movups xmm14, [r13+rax*1]
000072acf27ce6fc  mov eax, 0x420630
000072acf27ce701  movups xmm13, [r13+rax*1]
000072acf27ce707  mov qword ptr [r15+0x98], 0x4308A0
000072acf27ce712  mov eax, 0x4206A0
000072acf27ce717  movups xmm12, [r13+rax*1]
000072acf27ce71d  mov eax, 0x4308A0
000072acf27ce722  movups [r13+rax*1], xmm1
000072acf27ce728  mov eax, 0x4308B0
000072acf27ce72d  movups [r13+rax*1], xmm15
000072acf27ce733  mov eax, 0x4308C0
000072acf27ce738  movups [r13+rax*1], xmm14
000072acf27ce73e  mov eax, 0x4308D0
000072acf27ce743  movups [r13+rax*1], xmm13
000072acf27ce749  mov eax, 0x420600
000072acf27ce74e  movups xmm14, [r13+rax*1]
000072acf27ce754  mov eax, 0x4205F0
000072acf27ce759  movups xmm13, [r13+rax*1]
000072acf27ce75f  mov eax, 0x4309A0
000072acf27ce764  movups [r13+rax*1], xmm1
000072acf27ce76a  mov eax, 0x4309B0
000072acf27ce76f  movups [r13+rax*1], xmm15
000072acf27ce775  mov eax, 0x4308E0
000072acf27ce77a  movups [r13+rax*1], xmm12
000072acf27ce780  mov eax, 0x4308F0
000072acf27ce785  movups [r13+rax*1], xmm14
000072acf27ce78b  mov eax, 0x4205E0
000072acf27ce790  movups xmm1, [r13+rax*1]
000072acf27ce796  mov eax, 0x420640
000072acf27ce79b  movups xmm15, [r13+rax*1]
000072acf27ce7a1  mov eax, 0x430900
000072acf27ce7a6  movups [r13+rax*1], xmm13
000072acf27ce7ac  mov eax, 0x430910
000072acf27ce7b1  movups [r13+rax*1], xmm1
000072acf27ce7b7  mov eax, 0x420650
000072acf27ce7bc  movups xmm1, [r13+rax*1]
000072acf27ce7c2  mov eax, 0x420620
000072acf27ce7c7  movups xmm14, [r13+rax*1]
000072acf27ce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
000072acf27ce7d5  mov eax, 0x430920
000072acf27ce7da  movups [r13+rax*1], xmm15
000072acf27ce7e0  mov eax, 0x430930
000072acf27ce7e5  movups [r13+rax*1], xmm1
000072acf27ce7eb  mov eax, 0x4206C0
000072acf27ce7f0  movups xmm1, [r13+rax*1]
000072acf27ce7f6  mov eax, 0x4206D0
000072acf27ce7fb  movups xmm15, [r13+rax*1]
000072acf27ce801  movaps [r15+0x150], xmm15
000072acf27ce809  mov qword ptr [r15+0xA0], 0x3E8
000072acf27ce814  mov eax, 0x430940
000072acf27ce819  movups [r13+rax*1], xmm14
000072acf27ce81f  mov eax, 0x430950
000072acf27ce824  movups [r13+rax*1], xmm1
000072acf27ce82a  mov eax, 0x4206B0
000072acf27ce82f  movups xmm1, [r13+rax*1]
000072acf27ce835  mov eax, 0x420660
000072acf27ce83a  movups xmm14, [r13+rax*1]
000072acf27ce840  movaps [r15+0x140], xmm14
000072acf27ce848  lea rax, [r14+0x80]
000072acf27ce84f  mov r12, [r15+0xF0]
000072acf27ce856  mov [r13+rax*1], r12
000072acf27ce85b  mov eax, 0x430960
000072acf27ce860  movups [r13+rax*1], xmm15
000072acf27ce866  mov eax, 0x430970
000072acf27ce86b  movups [r13+rax*1], xmm1
000072acf27ce871  mov eax, 0x420680
000072acf27ce876  movups xmm1, [r13+rax*1]
000072acf27ce87c  mov eax, 0x4206E0
000072acf27ce881  mov r12, [r13+rax*1]
000072acf27ce886  movq xmm15, r12
000072acf27ce88b  mov qword ptr [r15+0x40], 0x4206E8
000072acf27ce893  mov eax, 0x430980
000072acf27ce898  movups [r13+rax*1], xmm14
000072acf27ce89e  mov eax, 0x430990
000072acf27ce8a3  movups [r13+rax*1], xmm1
000072acf27ce8a9  mov eax, 0x420748
000072acf27ce8ae  movups xmm1, [r13+rax*1]
000072acf27ce8b4  movq rax, xmm15
000072acf27ce8b9  mov r12d, 0x4309C0
000072acf27ce8bf  mov [r13+r12*1], rax
000072acf27ce8c4  mov eax, 0x420728
000072acf27ce8c9  movups xmm15, [r13+rax*1]
000072acf27ce8cf  mov eax, 0x420738
000072acf27ce8d4  movups xmm14, [r13+rax*1]
000072acf27ce8da  lea rax, [r14+0x60]
000072acf27ce8de  movups [r13+rax*1], xmm1
000072acf27ce8e4  mov eax, 0x4309C8
000072acf27ce8e9  mov r12d, 0x421DF8D3
000072acf27ce8ef  mov [r13+rax*1], r12d
000072acf27ce8f4  lea rax, [r14+0x40]
000072acf27ce8f8  movups [r13+rax*1], xmm15
000072acf27ce8fe  lea rax, [r14+0x50]
000072acf27ce902  movups [r13+rax*1], xmm14
000072acf27ce908  mov eax, 0x4206E8
000072acf27ce90d  movups xmm1, [r13+rax*1]
000072acf27ce913  mov eax, 0x4206F8
000072acf27ce918  movups xmm15, [r13+rax*1]
000072acf27ce91e  movaps [r15+0x120], xmm15
000072acf27ce926  movups [r13+r14*1], xmm1
000072acf27ce92c  lea rax, [r14+0x10]
000072acf27ce930  movups [r13+rax*1], xmm15
000072acf27ce936  mov eax, 0x420708
000072acf27ce93b  movups xmm1, [r13+rax*1]
000072acf27ce941  mov eax, 0x420718
000072acf27ce946  movups xmm15, [r13+rax*1]
000072acf27ce94c  movaps [r15+0x110], xmm1
000072acf27ce954  movaps [r15+0x130], xmm15
000072acf27ce95c  lea rax, [r14+0x20]
000072acf27ce960  movups [r13+rax*1], xmm1
000072acf27ce966  lea rax, [r14+0x30]
000072acf27ce96a  movups [r13+rax*1], xmm15
000072acf27ce970  mov [r15], r14
000072acf27ce973  mov qword ptr [r15+0x08], 0x4308A0
000072acf27ce97b  mov qword ptr [r15+0x10], 0x12C
000072acf27ce983  mov qword ptr [r15+0xF0], 0x410274
000072acf27ce98e  mov r14d, [r15+0x320]
000072acf27ce995  mov eax, 0x410274
000072acf27ce99a  mov rcx, 0x72ACF27D0670
000072acf27ce9a4  mov [r15+r14*8+0x328], rax
000072acf27ce9ac  mov [r15+r14*8+0x368], rcx
000072acf27ce9b4  add r14d, 0x01
000072acf27ce9b8  and r14d, 0x07
000072acf27ce9bc  mov [r15+0x320], r14d
000072acf27ce9c3  cmp dword ptr [r15+0x318], 0x00
000072acf27ce9cb  jz 0x000072ACF27CEC20
000072acf27ce9d1  nop [rax+rax*1], ax
000072acf27ce9da  nop [rax+rax*1], eax
000072acf27ce9e2  mov eax, 0x410338
000072acf27ce9e7  mov [r15+0x100], rax
000072acf27ce9ee  jmp 0x000072ACF25FE110
000072acf27ce9f3  int3
000072acf27ce9f4  call 0x000072ACF260BC20
000072acf27ce9f9  jmp 0x000072ACF27CE6CF
000072acf27ce9fe  call 0x000072ACF260A9A0
000072acf27cea03  jmp 0x000072ACF27CE6DB
000072acf27cea08  call 0x000072ACF25FF430
000072acf27cea0d  jmp 0x000072ACF27CE6E6
000072acf27cea12  call 0x000072ACF260E760
000072acf27cea17  jmp 0x000072ACF27CE6F1
000072acf27cea1c  call 0x000072ACF260D4E0
000072acf27cea21  jmp 0x000072ACF27CE6FC
000072acf27cea26  call 0x000072ACF260C260
000072acf27cea2b  jmp 0x000072ACF27CE707
000072acf27cea30  call 0x000072ACF260AFE0
000072acf27cea35  jmp 0x000072ACF27CE71D
000072acf27cea3a  call 0x000072ACF25FF540
000072acf27cea3f  jmp 0x000072ACF27CE728
000072acf27cea44  call 0x000072ACF260E880
000072acf27cea49  jmp 0x000072ACF27CE733
000072acf27cea4e  call 0x000072ACF260D600
000072acf27cea53  jmp 0x000072ACF27CE73E
000072acf27cea58  call 0x000072ACF260C380
000072acf27cea5d  jmp 0x000072ACF27CE749
000072acf27cea62  call 0x000072ACF260D4E0
000072acf27cea67  jmp 0x000072ACF27CE754
000072acf27cea6c  call 0x000072ACF260C260
000072acf27cea71  jmp 0x000072ACF27CE75F
000072acf27cea76  call 0x000072ACF25FF540
000072acf27cea7b  jmp 0x000072ACF27CE76A
000072acf27cea80  call 0x000072ACF260E880
000072acf27cea85  jmp 0x000072ACF27CE775
000072acf27cea8a  call 0x000072ACF260B100
000072acf27cea8f  jmp 0x000072ACF27CE780
000072acf27cea94  call 0x000072ACF260D600
000072acf27cea99  jmp 0x000072ACF27CE78B
000072acf27cea9e  call 0x000072ACF25FF430
000072acf27ceaa3  jmp 0x000072ACF27CE796
000072acf27ceaa8  call 0x000072ACF260E760
000072acf27ceaad  jmp 0x000072ACF27CE7A1
000072acf27ceab2  call 0x000072ACF260C380
000072acf27ceab7  jmp 0x000072ACF27CE7AC
000072acf27ceabc  call 0x000072ACF25FF540
000072acf27ceac1  jmp 0x000072ACF27CE7B7
000072acf27ceac6  call 0x000072ACF25FF430
000072acf27ceacb  jmp 0x000072ACF27CE7C2
000072acf27cead0  call 0x000072ACF260D4E0
000072acf27cead5  jmp 0x000072ACF27CE7CD
000072acf27ceada  call 0x000072ACF260E880
000072acf27ceadf  jmp 0x000072ACF27CE7E0
000072acf27ceae4  call 0x000072ACF25FF540
000072acf27ceae9  jmp 0x000072ACF27CE7EB
000072acf27ceaee  call 0x000072ACF25FF430
000072acf27ceaf3  jmp 0x000072ACF27CE7F6
000072acf27ceaf8  call 0x000072ACF260E760
000072acf27ceafd  jmp 0x000072ACF27CE801
000072acf27ceb02  call 0x000072ACF260D600
000072acf27ceb07  jmp 0x000072ACF27CE81F
000072acf27ceb0c  call 0x000072ACF25FF540
000072acf27ceb11  jmp 0x000072ACF27CE82A
000072acf27ceb16  call 0x000072ACF25FF430
000072acf27ceb1b  jmp 0x000072ACF27CE835
000072acf27ceb20  call 0x000072ACF260D4E0
000072acf27ceb25  jmp 0x000072ACF27CE840
000072acf27ceb2a  call 0x000072ACF260BC20
000072acf27ceb2f  jmp 0x000072ACF27CE85B
000072acf27ceb34  call 0x000072ACF260E880
000072acf27ceb39  jmp 0x000072ACF27CE866
000072acf27ceb3e  call 0x000072ACF25FF540
000072acf27ceb43  jmp 0x000072ACF27CE871
000072acf27ceb48  call 0x000072ACF25FF430
000072acf27ceb4d  jmp 0x000072ACF27CE87C
000072acf27ceb52  call 0x000072ACF260B720
000072acf27ceb57  jmp 0x000072ACF27CE886
000072acf27ceb5c  call 0x000072ACF260D600
000072acf27ceb61  jmp 0x000072ACF27CE89E
000072acf27ceb66  call 0x000072ACF25FF540
000072acf27ceb6b  jmp 0x000072ACF27CE8A9
000072acf27ceb70  call 0x000072ACF25FF430
000072acf27ceb75  jmp 0x000072ACF27CE8B4
000072acf27ceb7a  call 0x000072ACF26B4CB0
000072acf27ceb7f  jmp 0x000072ACF27CE8C4
000072acf27ceb84  call 0x000072ACF260E760
000072acf27ceb89  jmp 0x000072ACF27CE8CF
000072acf27ceb8e  call 0x000072ACF260D4E0
000072acf27ceb93  jmp 0x000072ACF27CE8DA
000072acf27ceb98  call 0x000072ACF25FF540
000072acf27ceb9d  jmp 0x000072ACF27CE8E4
000072acf27ceba2  call 0x000072ACF260BAE0
000072acf27ceba7  jmp 0x000072ACF27CE8F4
000072acf27cebac  call 0x000072ACF260E880
000072acf27cebb1  jmp 0x000072ACF27CE8FE
000072acf27cebb6  call 0x000072ACF260D600
000072acf27cebbb  jmp 0x000072ACF27CE908
000072acf27cebc0  call 0x000072ACF25FF430
000072acf27cebc5  jmp 0x000072ACF27CE913
000072acf27cebca  call 0x000072ACF260E760
000072acf27cebcf  jmp 0x000072ACF27CE91E
000072acf27cebd4  call 0x000072ACF26D6600
000072acf27cebd9  jmp 0x000072ACF27CE92C
000072acf27cebde  call 0x000072ACF260E880
000072acf27cebe3  jmp 0x000072ACF27CE936
000072acf27cebe8  call 0x000072ACF25FF430
000072acf27cebed  jmp 0x000072ACF27CE941
000072acf27cebf2  call 0x000072ACF260E760
000072acf27cebf7  jmp 0x000072ACF27CE94C
000072acf27cebfc  call 0x000072ACF25FF540
000072acf27cec01  jmp 0x000072ACF27CE966
000072acf27cec06  call 0x000072ACF260E880
000072acf27cec0b  jmp 0x000072ACF27CE970
000072acf27cec10  int3
000072acf27cec11  nop [rax+rax*1], ax
000072acf27cec1a  nop [rax+rax*1], ax
000072acf27cec20  mov rax, [r15]
000072acf27cec23  lea r14, [rax+0x20]
000072acf27cec27  mov r12, [r13+r14*1]
000072acf27cec2c  mov r14, [r15+0x10]
000072acf27cec30  lea r11, [r12+r14*1]
000072acf27cec34  mov [r15+0x40], r11
000072acf27cec38  lea r12, [rax+0x20]
000072acf27cec3c  mov [r13+r12*1], r11
000072acf27cec41  test r14, r14
000072acf27cec44  setz r14b
000072acf27cec48  movzx r14, r14b
000072acf27cec4c  mov [rsp+0x414], r14b
000072acf27cec54  cmp byte ptr [rsp+0x414], 0x00
000072acf27cec5c  jz 0x000072ACF27CEC8E
000072acf27cec5e  cmp dword ptr [r15+0x318], 0x00
000072acf27cec66  mov eax, 0x4105B0
000072acf27cec6b  mov [r15+0x100], rax
000072acf27cec72  jz 0x000072ACF25FE0A0
000072acf27cec78  nop [rax+rax*1], eax
000072acf27cec7d  mov eax, 0x4105B0
000072acf27cec82  mov [r15+0x100], rax
000072acf27cec89  jmp 0x000072ACF25FE110
000072acf27cec8e  cmp dword ptr [r15+0x318], 0x00
000072acf27cec96  jz 0x000072ACF27CECE0
000072acf27cec9c  nop [rax+rax*1], ax
000072acf27ceca5  nop [rax+rax*1], eax
000072acf27cecad  mov eax, 0x410348
000072acf27cecb2  mov [r15+0x100], rax
000072acf27cecb9  jmp 0x000072ACF25FE110
000072acf27cecbe  int3
000072acf27cecbf  call 0x000072ACF26E27E0
000072acf27cecc4  jmp 0x000072ACF27CEC2C
000072acf27cecc9  call 0x000072ACF26C0860
000072acf27cecce  jmp 0x000072ACF27CEC41
000072acf27cecd3  int3
000072acf27cecd4  nop [rax+rax*1], ax
000072acf27cecdd  nop [rax], eax
000072acf27cece0  mov rax, [r15+0xF8]
000072acf27cece7  lea r14, [rax-0x150]
000072acf27cecee  mov [r15+0xF8], r14
000072acf27cecf5  mov rax, [r15]
000072acf27cecf8  lea r12, [rax+0x68]
000072acf27cecfc  mov r11, [r13+r12*1]
000072acf27ced01  mov [r15+0x88], r11
000072acf27ced08  lea r12, [rax+0x28]
000072acf27ced0c  mov [r15+0x40], r12
000072acf27ced10  mov [r15+0x48], r14
000072acf27ced14  mov qword ptr [r15+0x50], 0x420758
000072acf27ced1c  lea rax, [r14+0x100]
000072acf27ced23  mov r12, [r15+0xE8]
000072acf27ced2a  mov r11, [r15+0xD8]
000072acf27ced31  mov [r13+rax*1], r12
000072acf27ced36  lea rax, [r14+0x108]
000072acf27ced3d  mov [r13+rax*1], r11
000072acf27ced42  lea rax, [r14+0x110]
000072acf27ced49  mov r12, [r15+0xD0]
000072acf27ced50  mov r11, [r15+0xC8]
000072acf27ced57  mov [r13+rax*1], r12
000072acf27ced5c  lea rax, [r14+0x118]
000072acf27ced63  mov [r13+rax*1], r11
000072acf27ced68  lea rax, [r14+0x120]
000072acf27ced6f  mov r12, [r15+0xC0]
000072acf27ced76  mov r11, [r15+0xB8]
000072acf27ced7d  mov [r13+rax*1], r12
000072acf27ced82  lea rax, [r14+0x128]
000072acf27ced89  mov [r13+rax*1], r11
000072acf27ced8e  lea rax, [r14+0x130]
000072acf27ced95  mov r12, [r15+0xB0]
000072acf27ced9c  mov r11, [r15+0xA8]
000072acf27ceda3  mov [r13+rax*1], r12
000072acf27ceda8  lea rax, [r14+0x138]
000072acf27cedaf  mov [r13+rax*1], r11
000072acf27cedb4  lea rax, [r14+0x140]
000072acf27cedbb  mov r12, [r15+0xA0]
000072acf27cedc2  mov r11, [r15+0x98]
000072acf27cedc9  mov [r13+rax*1], r12
000072acf27cedce  lea rax, [r14+0x148]
000072acf27cedd5  mov [r13+rax*1], r11
000072acf27cedda  cmp dword ptr [r15+0x318], 0x00
000072acf27cede2  jz 0x000072ACF27CEE80
000072acf27cede8  nop [rax+rax*1], ax
000072acf27cedf1  nop [rax+rax*1], eax
000072acf27cedf9  mov eax, 0x410380
000072acf27cedfe  mov [r15+0x100], rax
000072acf27cee05  jmp 0x000072ACF25FE110
000072acf27cee0a  int3
000072acf27cee0b  call 0x000072ACF26C0370
000072acf27cee10  jmp 0x000072ACF27CED01
000072acf27cee15  call 0x000072ACF260BC20
000072acf27cee1a  jmp 0x000072ACF27CED36
000072acf27cee1f  call 0x000072ACF260A9A0
000072acf27cee24  jmp 0x000072ACF27CED42
000072acf27cee29  call 0x000072ACF260BC20
000072acf27cee2e  jmp 0x000072ACF27CED5C
000072acf27cee33  call 0x000072ACF260A9A0
000072acf27cee38  jmp 0x000072ACF27CED68
000072acf27cee3d  call 0x000072ACF260BC20
000072acf27cee42  jmp 0x000072ACF27CED82
000072acf27cee47  call 0x000072ACF260A9A0
000072acf27cee4c  jmp 0x000072ACF27CED8E
000072acf27cee51  call 0x000072ACF260BC20
000072acf27cee56  jmp 0x000072ACF27CEDA8
000072acf27cee5b  call 0x000072ACF260A9A0
000072acf27cee60  jmp 0x000072ACF27CEDB4
000072acf27cee65  call 0x000072ACF260BC20
000072acf27cee6a  jmp 0x000072ACF27CEDCE
000072acf27cee6f  call 0x000072ACF260A9A0
000072acf27cee74  jmp 0x000072ACF27CEDDA
000072acf27cee79  int3
000072acf27cee7a  nop [rax+rax*1], ax
000072acf27cee80  mov rax, [r15+0x08]
000072acf27cee84  movzx r14d, byte ptr [r13+rax*1]
000072acf27cee8a  movzx r14d, r14b
000072acf27cee8e  mov [rsp+0x10], r14d
000072acf27cee93  mov r14d, r14d
000072acf27cee96  mov [r15+0x58], r14
000072acf27cee9a  lea r14, [rax+0x01]
000072acf27cee9e  mov [r15+0x08], r14
000072acf27ceea2  mov rax, [r15+0x88]
000072acf27ceea9  lea r14, [rax+0x01]
000072acf27ceead  mov r12, [r15]
000072acf27ceeb0  lea r11, [r12+0x68]
000072acf27ceeb5  mov [r13+r11*1], r14
000072acf27ceeba  lea r14, [r12+rax*1]
000072acf27ceebe  mov [r15+0x60], r14
000072acf27ceec2  lea rax, [r14+0x28]
000072acf27ceec6  mov r11d, [rsp+0x10]
000072acf27ceecb  movzx r14d, r11b
000072acf27ceecf  mov [r13+rax*1], r14b
000072acf27ceed4  lea rax, [r12+0x68]
000072acf27ceed9  mov r14, [r13+rax*1]
000072acf27ceede  mov [r15+0x88], r14
000072acf27ceee5  xor eax, eax
000072acf27ceee7  mov r12d, 0x40
000072acf27ceeed  cmp r14, r12
000072acf27ceef0  cmc
000072acf27ceef1  lahf
000072acf27ceef2  seto al
000072acf27ceef5  mov [r15+0x108], eax
000072acf27ceefc  mov eax, [r15+0x108]
000072acf27cef03  sahf
000072acf27cef04  jnz 0x000072ACF27CEF36
000072acf27cef06  cmp dword ptr [r15+0x318], 0x00
000072acf27cef0e  jz 0x000072ACF27CF020
000072acf27cef14  nop [rax+rax*1], ax
000072acf27cef1d  nop [rax+rax*1], eax
000072acf27cef25  mov eax, 0x4103A0
000072acf27cef2a  mov [r15+0x100], rax
000072acf27cef31  jmp 0x000072ACF25FE110
000072acf27cef36  cmp dword ptr [r15+0x318], 0x00
000072acf27cef3e  jz 0x000072ACF27CEF90
000072acf27cef44  nop [rax+rax*1], ax
000072acf27cef4d  nop [rax+rax*1], eax
000072acf27cef55  mov eax, 0x410378
000072acf27cef5a  mov [r15+0x100], rax
000072acf27cef61  jmp 0x000072ACF25FE110
000072acf27cef66  int3
000072acf27cef67  call 0x000072ACF260D860
000072acf27cef6c  jmp 0x000072ACF27CEE8A
000072acf27cef71  call 0x000072ACF26B36E0
000072acf27cef76  jmp 0x000072ACF27CEEBA
000072acf27cef7b  call 0x000072ACF260DD60
000072acf27cef80  jmp 0x000072ACF27CEED4
000072acf27cef85  call 0x000072ACF260DC20
000072acf27cef8a  jmp 0x000072ACF27CEEDE
000072acf27cef8f  int3
000072acf27cef90  mov rax, [r15+0x10]
000072acf27cef94  lea r14, [rax-0x01]
000072acf27cef98  mov [r15+0x10], r14
000072acf27cef9c  test r14, r14
000072acf27cef9f  setz r14b
000072acf27cefa3  movzx r14, r14b
000072acf27cefa7  mov [rsp+0x414], r14b
000072acf27cefaf  cmp byte ptr [rsp+0x414], 0x00
000072acf27cefb7  jz 0x000072ACF27CEFE9
000072acf27cefb9  cmp dword ptr [r15+0x318], 0x00
000072acf27cefc1  jz 0x000072ACF27D0520
000072acf27cefc7  nop [rax+rax*1], ax
000072acf27cefd0  nop [rax+rax*1], eax
000072acf27cefd8  mov eax, 0x410598
000072acf27cefdd  mov [r15+0x100], rax
000072acf27cefe4  jmp 0x000072ACF25FE110
000072acf27cefe9  cmp dword ptr [r15+0x318], 0x00
000072acf27ceff1  jz 0x000072ACF27CEE80
000072acf27ceff7  nop [rax+rax*1], ax
000072acf27cf000  nop [rax+rax*1], eax
000072acf27cf008  mov eax, 0x410380
000072acf27cf00d  mov [r15+0x100], rax
000072acf27cf014  jmp 0x000072ACF25FE110
000072acf27cf019  int3
000072acf27cf01a  int3
000072acf27cf01b  nop [rax+rax*1], eax
000072acf27cf020  mov rax, [r15+0x40]
000072acf27cf024  movzx r14d, byte ptr [r13+rax*1]
000072acf27cf02a  movaps xmm1, [r15+0x110]
000072acf27cf032  pinsrb xmm1, r14d, 0x00
000072acf27cf039  lea r14, [rax+0x01]
000072acf27cf03d  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf043  movaps xmm15, [r15+0x120]
000072acf27cf04b  pinsrb xmm15, r12d, 0x00
000072acf27cf052  lea r14, [rax+0x02]
000072acf27cf056  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf05c  movaps xmm14, [r15+0x130]
000072acf27cf064  pinsrb xmm14, r12d, 0x00
000072acf27cf06b  lea r14, [rax+0x03]
000072acf27cf06f  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf075  movaps xmm13, [r15+0x140]
000072acf27cf07d  pinsrb xmm13, r12d, 0x00
000072acf27cf084  lea r14, [rax+0x04]
000072acf27cf088  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf08e  pinsrb xmm1, r12d, 0x01
000072acf27cf095  lea r14, [rax+0x05]
000072acf27cf099  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf09f  pinsrb xmm15, r12d, 0x01
000072acf27cf0a6  lea r14, [rax+0x06]
000072acf27cf0aa  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf0b0  pinsrb xmm14, r12d, 0x01
000072acf27cf0b7  lea r14, [rax+0x07]
000072acf27cf0bb  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf0c1  pinsrb xmm13, r12d, 0x01
000072acf27cf0c8  lea r14, [rax+0x08]
000072acf27cf0cc  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf0d2  pinsrb xmm1, r12d, 0x02
000072acf27cf0d9  lea r14, [rax+0x09]
000072acf27cf0dd  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf0e3  pinsrb xmm15, r12d, 0x02
000072acf27cf0ea  lea r14, [rax+0x0A]
000072acf27cf0ee  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf0f4  pinsrb xmm14, r12d, 0x02
000072acf27cf0fb  lea r14, [rax+0x0B]
000072acf27cf0ff  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf105  pinsrb xmm13, r12d, 0x02
000072acf27cf10c  lea r14, [rax+0x0C]
000072acf27cf110  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf116  pinsrb xmm1, r12d, 0x03
000072acf27cf11d  lea r14, [rax+0x0D]
000072acf27cf121  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf127  pinsrb xmm15, r12d, 0x03
000072acf27cf12e  lea r14, [rax+0x0E]
000072acf27cf132  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf138  pinsrb xmm14, r12d, 0x03
000072acf27cf13f  lea r14, [rax+0x0F]
000072acf27cf143  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf149  pinsrb xmm13, r12d, 0x03
000072acf27cf150  lea r14, [rax+0x10]
000072acf27cf154  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf15a  pinsrb xmm1, r12d, 0x04
000072acf27cf161  lea r14, [rax+0x11]
000072acf27cf165  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf16b  pinsrb xmm15, r12d, 0x04
000072acf27cf172  lea r14, [rax+0x12]
000072acf27cf176  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf17c  pinsrb xmm14, r12d, 0x04
000072acf27cf183  lea r14, [rax+0x13]
000072acf27cf187  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf18d  pinsrb xmm13, r12d, 0x04
000072acf27cf194  lea r14, [rax+0x14]
000072acf27cf198  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf19e  pinsrb xmm1, r12d, 0x05
000072acf27cf1a5  lea r14, [rax+0x15]
000072acf27cf1a9  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf1af  pinsrb xmm15, r12d, 0x05
000072acf27cf1b6  lea r14, [rax+0x16]
000072acf27cf1ba  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf1c0  pinsrb xmm14, r12d, 0x05
000072acf27cf1c7  lea r14, [rax+0x17]
000072acf27cf1cb  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf1d1  pinsrb xmm13, r12d, 0x05
000072acf27cf1d8  lea r14, [rax+0x18]
000072acf27cf1dc  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf1e2  pinsrb xmm1, r12d, 0x06
000072acf27cf1e9  lea r14, [rax+0x19]
000072acf27cf1ed  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf1f3  pinsrb xmm15, r12d, 0x06
000072acf27cf1fa  lea r14, [rax+0x1A]
000072acf27cf1fe  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf204  pinsrb xmm14, r12d, 0x06
000072acf27cf20b  lea r14, [rax+0x1B]
000072acf27cf20f  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf215  pinsrb xmm13, r12d, 0x06
000072acf27cf21c  lea r14, [rax+0x1C]
000072acf27cf220  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf226  pinsrb xmm1, r12d, 0x07
000072acf27cf22d  lea r14, [rax+0x1D]
000072acf27cf231  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf237  pinsrb xmm15, r12d, 0x07
000072acf27cf23e  lea r14, [rax+0x1E]
000072acf27cf242  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf248  pinsrb xmm14, r12d, 0x07
000072acf27cf24f  lea r14, [rax+0x1F]
000072acf27cf253  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf259  pinsrb xmm13, r12d, 0x07
000072acf27cf260  lea r14, [rax+0x20]
000072acf27cf264  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf26a  pinsrb xmm1, r12d, 0x08
000072acf27cf271  lea r14, [rax+0x21]
000072acf27cf275  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf27b  pinsrb xmm15, r12d, 0x08
000072acf27cf282  lea r14, [rax+0x22]
000072acf27cf286  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf28c  pinsrb xmm14, r12d, 0x08
000072acf27cf293  lea r14, [rax+0x23]
000072acf27cf297  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf29d  pinsrb xmm13, r12d, 0x08
000072acf27cf2a4  lea r14, [rax+0x24]
000072acf27cf2a8  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf2ae  pinsrb xmm1, r12d, 0x09
000072acf27cf2b5  lea r14, [rax+0x25]
000072acf27cf2b9  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf2bf  pinsrb xmm15, r12d, 0x09
000072acf27cf2c6  lea r14, [rax+0x26]
000072acf27cf2ca  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf2d0  pinsrb xmm14, r12d, 0x09
000072acf27cf2d7  lea r14, [rax+0x27]
000072acf27cf2db  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf2e1  pinsrb xmm13, r12d, 0x09
000072acf27cf2e8  lea r14, [rax+0x28]
000072acf27cf2ec  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf2f2  pinsrb xmm1, r12d, 0x0A
000072acf27cf2f9  lea r14, [rax+0x29]
000072acf27cf2fd  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf303  pinsrb xmm15, r12d, 0x0A
000072acf27cf30a  lea r14, [rax+0x2A]
000072acf27cf30e  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf314  pinsrb xmm14, r12d, 0x0A
000072acf27cf31b  lea r14, [rax+0x2B]
000072acf27cf31f  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf325  pinsrb xmm13, r12d, 0x0A
000072acf27cf32c  lea r14, [rax+0x2C]
000072acf27cf330  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf336  pinsrb xmm1, r12d, 0x0B
000072acf27cf33d  lea r14, [rax+0x2D]
000072acf27cf341  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf347  pinsrb xmm15, r12d, 0x0B
000072acf27cf34e  lea r14, [rax+0x2E]
000072acf27cf352  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf358  pinsrb xmm14, r12d, 0x0B
000072acf27cf35f  lea r14, [rax+0x2F]
000072acf27cf363  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf369  pinsrb xmm13, r12d, 0x0B
000072acf27cf370  lea r14, [rax+0x30]
000072acf27cf374  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf37a  pinsrb xmm1, r12d, 0x0C
000072acf27cf381  lea r14, [rax+0x31]
000072acf27cf385  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf38b  pinsrb xmm15, r12d, 0x0C
000072acf27cf392  lea r14, [rax+0x32]
000072acf27cf396  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf39c  pinsrb xmm14, r12d, 0x0C
000072acf27cf3a3  lea r14, [rax+0x33]
000072acf27cf3a7  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf3ad  pinsrb xmm13, r12d, 0x0C
000072acf27cf3b4  lea r14, [rax+0x34]
000072acf27cf3b8  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf3be  pinsrb xmm1, r12d, 0x0D
000072acf27cf3c5  lea r14, [rax+0x35]
000072acf27cf3c9  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf3cf  pinsrb xmm15, r12d, 0x0D
000072acf27cf3d6  lea r14, [rax+0x36]
000072acf27cf3da  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf3e0  pinsrb xmm14, r12d, 0x0D
000072acf27cf3e7  lea r14, [rax+0x37]
000072acf27cf3eb  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf3f1  pinsrb xmm13, r12d, 0x0D
000072acf27cf3f8  lea r14, [rax+0x38]
000072acf27cf3fc  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf402  pinsrb xmm1, r12d, 0x0E
000072acf27cf409  lea r14, [rax+0x39]
000072acf27cf40d  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf413  pinsrb xmm15, r12d, 0x0E
000072acf27cf41a  lea r14, [rax+0x3A]
000072acf27cf41e  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf424  pinsrb xmm14, r12d, 0x0E
000072acf27cf42b  lea r14, [rax+0x3B]
000072acf27cf42f  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf435  pinsrb xmm13, r12d, 0x0E
000072acf27cf43c  lea r14, [rax+0x3C]
000072acf27cf440  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf446  pinsrb xmm1, r12d, 0x0F
000072acf27cf44d  movaps [r15+0x110], xmm1
000072acf27cf455  lea r14, [rax+0x3D]
000072acf27cf459  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf45f  pinsrb xmm15, r12d, 0x0F
000072acf27cf466  movaps [r15+0x120], xmm15
000072acf27cf46e  lea r14, [rax+0x3E]
000072acf27cf472  movzx r12d, byte ptr [r13+r14*1]
000072acf27cf478  pinsrb xmm14, r12d, 0x0F
000072acf27cf47f  movaps [r15+0x130], xmm14
000072acf27cf487  lea r14, [rax+0x3F]
000072acf27cf48b  movzx eax, byte ptr [r13+r14*1]
000072acf27cf491  pinsrb xmm13, eax, 0x0F
000072acf27cf498  movaps [r15+0x140], xmm13
000072acf27cf4a0  movq xmm1, qword ptr [r15+0x120]
000072acf27cf4a9  pmovzxbw xmm1, xmm1
000072acf27cf4ae  psllw xmm1, 0x00
000072acf27cf4b3  movaps [r15+0x150], xmm1
000072acf27cf4bb  movq xmm1, qword ptr [r15+0x130]
000072acf27cf4c4  pmovzxbw xmm1, xmm1
000072acf27cf4c9  psllw xmm1, 0x00
000072acf27cf4ce  movaps [r15+0x160], xmm1
000072acf27cf4d6  movq xmm1, qword ptr [r15+0x110]
000072acf27cf4df  pmovzxbw xmm1, xmm1
000072acf27cf4e4  psllw xmm1, 0x00
000072acf27cf4e9  movaps [r15+0x170], xmm1
000072acf27cf4f1  movaps xmm15, [r15+0x110]
000072acf27cf4f9  pextrq rax, xmm15, 0x01
000072acf27cf500  movq xmm15, rax
000072acf27cf505  pmovzxbw xmm15, xmm15
000072acf27cf50b  psllw xmm15, 0x00
000072acf27cf511  movaps [r15+0x180], xmm15
000072acf27cf519  movaps xmm14, [r15+0x120]
000072acf27cf521  pextrq rax, xmm14, 0x01
000072acf27cf528  movq xmm14, rax
000072acf27cf52d  pmovzxbw xmm14, xmm14
000072acf27cf533  psllw xmm14, 0x00
000072acf27cf539  movaps [r15+0x210], xmm14
000072acf27cf541  movaps xmm13, [r15+0x130]
000072acf27cf549  pextrq rax, xmm13, 0x01
000072acf27cf550  movq xmm13, rax
000072acf27cf555  pmovzxbw xmm13, xmm13
000072acf27cf55b  psllw xmm13, 0x00
000072acf27cf561  movaps [r15+0x220], xmm13
000072acf27cf569  movq xmm12, qword ptr [r15+0x140]
000072acf27cf572  pmovzxbw xmm12, xmm12
000072acf27cf578  psllw xmm12, 0x00
000072acf27cf57e  movaps [r15+0x250], xmm12
000072acf27cf586  movaps xmm12, [r15+0x140]
000072acf27cf58e  pextrq rax, xmm12, 0x01
000072acf27cf595  movq xmm12, rax
000072acf27cf59a  pmovzxbw xmm12, xmm12
000072acf27cf5a0  psllw xmm12, 0x00
000072acf27cf5a6  movaps [r15+0x110], xmm12
000072acf27cf5ae  movq xmm11, qword ptr [r15+0x150]
000072acf27cf5b7  pmovzxwd xmm11, xmm11
000072acf27cf5bd  pslld xmm11, 0x10
000072acf27cf5c3  movq xmm10, qword ptr [r15+0x160]
000072acf27cf5cc  pmovzxwd xmm10, xmm10
000072acf27cf5d2  pslld xmm10, 0x08
000072acf27cf5d8  pextrq rax, xmm1, 0x01
000072acf27cf5df  movq xmm1, rax
000072acf27cf5e4  pmovzxwd xmm1, xmm1
000072acf27cf5e9  pslld xmm1, 0x00
000072acf27cf5ee  movaps [r15+0x260], xmm1
000072acf27cf5f6  pextrq rax, xmm15, 0x01
000072acf27cf5fd  movq xmm15, rax
000072acf27cf602  pmovzxwd xmm15, xmm15
000072acf27cf608  pslld xmm15, 0x00
000072acf27cf60e  movaps [r15+0x270], xmm15
000072acf27cf616  movq xmm9, qword ptr [r15+0x170]
000072acf27cf61f  pmovzxwd xmm9, xmm9
000072acf27cf625  pslld xmm9, 0x00
000072acf27cf62b  pextrq rax, xmm14, 0x01
000072acf27cf632  movq xmm14, rax
000072acf27cf637  pmovzxwd xmm14, xmm14
000072acf27cf63d  pslld xmm14, 0x10
000072acf27cf643  movaps [r15+0x280], xmm14
000072acf27cf64b  movq xmm8, qword ptr [r15+0x180]
000072acf27cf654  pmovzxwd xmm8, xmm8
000072acf27cf65a  pslld xmm8, 0x00
000072acf27cf660  movq xmm7, qword ptr [r15+0x210]
000072acf27cf669  pmovzxwd xmm7, xmm7
000072acf27cf66e  pslld xmm7, 0x10
000072acf27cf673  movaps xmm6, [r15+0x150]
000072acf27cf67b  pextrq rax, xmm6, 0x01
000072acf27cf682  movq xmm6, rax
000072acf27cf687  pmovzxwd xmm6, xmm6
000072acf27cf68c  pslld xmm6, 0x10
000072acf27cf691  por xmm11, xmm10
000072acf27cf696  movaps [r15+0x230], xmm11
000072acf27cf69e  pextrq rax, xmm13, 0x01
000072acf27cf6a5  movq xmm13, rax
000072acf27cf6aa  pmovzxwd xmm13, xmm13
000072acf27cf6b0  pslld xmm13, 0x08
000072acf27cf6b6  movaps [r15+0x240], xmm13
000072acf27cf6be  movq xmm10, qword ptr [r15+0x220]
000072acf27cf6c7  pmovzxwd xmm10, xmm10
000072acf27cf6cd  pslld xmm10, 0x08
000072acf27cf6d3  movaps xmm5, [r15+0x160]
000072acf27cf6db  pextrq rax, xmm5, 0x01
000072acf27cf6e2  movq xmm5, rax
000072acf27cf6e7  pmovzxwd xmm5, xmm5
000072acf27cf6ec  pslld xmm5, 0x08
000072acf27cf6f1  pslld xmm9, 0x18
000072acf27cf6f7  pslld xmm15, 0x18
000072acf27cf6fd  pslld xmm8, 0x18
000072acf27cf703  movq xmm4, qword ptr [r15+0x250]
000072acf27cf70c  pmovzxwd xmm4, xmm4
000072acf27cf711  pslld xmm4, 0x00
000072acf27cf716  por xmm14, xmm13
000072acf27cf71b  por xmm7, xmm10
000072acf27cf720  movaps [r15+0x210], xmm7
000072acf27cf728  pslld xmm1, 0x18
000072acf27cf72d  movaps [r15+0x220], xmm1
000072acf27cf735  por xmm6, xmm5
000072acf27cf739  por xmm11, xmm9
000072acf27cf73e  movaps [r15+0x160], xmm11
000072acf27cf746  pextrq rax, xmm12, 0x01
000072acf27cf74d  movq xmm13, rax
000072acf27cf752  pmovzxwd xmm13, xmm13
000072acf27cf758  pslld xmm13, 0x00
000072acf27cf75e  movaps [r15+0x170], xmm13
000072acf27cf766  movq xmm12, qword ptr [r15+0x110]
000072acf27cf76f  pmovzxwd xmm12, xmm12
000072acf27cf775  pslld xmm12, 0x00
000072acf27cf77b  por xmm14, xmm15
000072acf27cf780  por xmm7, xmm8
000072acf27cf785  movaps xmm15, [r15+0x250]
000072acf27cf78d  pextrq rax, xmm15, 0x01
000072acf27cf794  movq xmm15, rax
000072acf27cf799  pmovzxwd xmm15, xmm15
000072acf27cf79f  pslld xmm15, 0x00
000072acf27cf7a5  movaps [r15+0x180], xmm15
000072acf27cf7ad  por xmm6, xmm1
000072acf27cf7b1  movaps [r15+0x150], xmm6
000072acf27cf7b9  por xmm11, xmm4
000072acf27cf7be  movaps [r15+0x140], xmm11
000072acf27cf7c6  por xmm7, xmm12
000072acf27cf7cb  movaps [r15+0x110], xmm7
000072acf27cf7d3  por xmm14, xmm13
000072acf27cf7d8  movaps [r15+0x120], xmm14
000072acf27cf7e0  por xmm6, xmm15
000072acf27cf7e5  movaps [r15+0x130], xmm6
000072acf27cf7ed  mov rax, [r15+0xF8]
000072acf27cf7f4  lea r14, [rax+0x20]
000072acf27cf7f8  movups [r13+r14*1], xmm7
000072acf27cf7fe  lea r14, [rax+0x30]
000072acf27cf802  movups [r13+r14*1], xmm14
000072acf27cf808  movups [r13+rax*1], xmm11
000072acf27cf80e  lea r14, [rax+0x10]
000072acf27cf812  movups [r13+r14*1], xmm6
000072acf27cf818  mov r14d, [r13+rax*1]
000072acf27cf81d  mov rax, [r15+0x48]
000072acf27cf821  mov [r15+0x68], rax
000072acf27cf825  mov qword ptr [r15+0x58], 0x04
000072acf27cf82d  lea r12, [rax+0x04]
000072acf27cf831  mov r11d, [r13+r12*1]
000072acf27cf836  mov [rsp+0x10], r11d
000072acf27cf83b  mov r11d, r11d
000072acf27cf83e  mov [r15+0x70], r11
000072acf27cf842  lea r12, [rax+0x38]
000072acf27cf846  mov r11d, [r13+r12*1]
000072acf27cf84b  lea r12, [rax+0x24]
000072acf27cf84f  mov r10d, [r13+r12*1]
000072acf27cf854  mov [rsp+0x20], r10d
000072acf27cf859  mov r10d, r10d
000072acf27cf85c  mov [r15+0x90], r10
000072acf27cf863  mov [rsp+0x30], rax
000072acf27cf868  xor eax, eax
000072acf27cf86a  mov r12d, 0x04
000072acf27cf870  mov r10d, 0xC0
000072acf27cf876  cmp r12, r10
000072acf27cf879  cmc
000072acf27cf87a  lahf
000072acf27cf87b  seto al
000072acf27cf87e  mov [r15+0x108], eax
000072acf27cf885  mov eax, [rsp+0x10]
000072acf27cf889  mov r12d, [rsp+0x10]
000072acf27cf88e  shrd eax, r12d, 0x07
000072acf27cf893  mov [rsp+0x10], r11d
000072acf27cf898  mov r10d, [rsp+0x10]
000072acf27cf89d  shrd r11d, r10d, 0x11
000072acf27cf8a2  mov r9d, [rsp+0x20]
000072acf27cf8a7  lea r8d, [r9d+r14d*1]
000072acf27cf8ac  rorx r14d, r12d, 0x12
000072acf27cf8b2  xor eax, r14d
000072acf27cf8b5  rorx r14d, r10d, 0x13
000072acf27cf8bb  xor r11d, r14d
000072acf27cf8be  mov [rsp+0x10], r11d
000072acf27cf8c3  mov r11d, r11d
000072acf27cf8c6  mov [r15+0x88], r11
000072acf27cf8cd  mov [rsp+0x20], r12d
000072acf27cf8d2  shr r12d, 0x03
000072acf27cf8d6  xor eax, r12d
000072acf27cf8d9  mov [rsp+0x40], eax
000072acf27cf8dd  mov eax, eax
000072acf27cf8df  mov [r15+0x80], rax
000072acf27cf8e6  shr r10d, 0x0A
000072acf27cf8ea  mov eax, [rsp+0x10]
000072acf27cf8ee  xor eax, r10d
000072acf27cf8f1  mov [rsp+0x10], eax
000072acf27cf8f5  mov eax, eax
000072acf27cf8f7  mov [r15+0x78], rax
000072acf27cf8fb  mov eax, [rsp+0x40]
000072acf27cf8ff  lea r14d, [r8d+eax*1]
000072acf27cf904  mov eax, [rsp+0x10]
000072acf27cf908  lea r12d, [r14d+eax*1]
000072acf27cf90d  mov rax, [rsp+0x30]
000072acf27cf912  lea r14, [rax+0x40]
000072acf27cf916  mov [r13+r14*1], r12d
000072acf27cf91b  mov eax, [rsp+0x20]
000072acf27cf91f  mov eax, eax
000072acf27cf921  mov [r15+0x60], rax
000072acf27cf925  mov eax, [r15+0x108]
000072acf27cf92c  sahf
000072acf27cf92d  jnz 0x000072ACF27CF95F
000072acf27cf92f  cmp dword ptr [r15+0x318], 0x00
000072acf27cf937  jz 0x000072ACF27CFE20
000072acf27cf93d  nop [rax+rax*1], ax
000072acf27cf946  nop [rax+rax*1], eax
000072acf27cf94e  mov eax, 0x41049C
000072acf27cf953  mov [r15+0x100], rax
000072acf27cf95a  jmp 0x000072ACF25FE110
000072acf27cf95f  cmp dword ptr [r15+0x318], 0x00
000072acf27cf967  jz 0x000072ACF27CFC70
000072acf27cf96d  nop [rax+rax*1], ax
000072acf27cf976  nop [rax+rax*1], eax
000072acf27cf97e  mov eax, 0x410454
000072acf27cf983  mov [r15+0x100], rax
000072acf27cf98a  jmp 0x000072ACF25FE110
000072acf27cf98f  int3
000072acf27cf990  call 0x000072ACF260D860
000072acf27cf995  jmp 0x000072ACF27CF02A
000072acf27cf99a  call 0x000072ACF26E2420
000072acf27cf99f  jmp 0x000072ACF27CF043
000072acf27cf9a4  call 0x000072ACF26E2420
000072acf27cf9a9  jmp 0x000072ACF27CF05C
000072acf27cf9ae  call 0x000072ACF26E2420
000072acf27cf9b3  jmp 0x000072ACF27CF075
000072acf27cf9b8  call 0x000072ACF26E2420
000072acf27cf9bd  jmp 0x000072ACF27CF08E
000072acf27cf9c2  call 0x000072ACF26E2420
000072acf27cf9c7  jmp 0x000072ACF27CF09F
000072acf27cf9cc  call 0x000072ACF26E2420
000072acf27cf9d1  jmp 0x000072ACF27CF0B0
000072acf27cf9d6  call 0x000072ACF26E2420
000072acf27cf9db  jmp 0x000072ACF27CF0C1
000072acf27cf9e0  call 0x000072ACF26E2420
000072acf27cf9e5  jmp 0x000072ACF27CF0D2
000072acf27cf9ea  call 0x000072ACF26E2420
000072acf27cf9ef  jmp 0x000072ACF27CF0E3
000072acf27cf9f4  call 0x000072ACF26E2420
000072acf27cf9f9  jmp 0x000072ACF27CF0F4
000072acf27cf9fe  call 0x000072ACF26E2420
000072acf27cfa03  jmp 0x000072ACF27CF105
000072acf27cfa08  call 0x000072ACF26E2420
000072acf27cfa0d  jmp 0x000072ACF27CF116
000072acf27cfa12  call 0x000072ACF26E2420
000072acf27cfa17  jmp 0x000072ACF27CF127
000072acf27cfa1c  call 0x000072ACF26E2420
000072acf27cfa21  jmp 0x000072ACF27CF138
000072acf27cfa26  call 0x000072ACF26E2420
000072acf27cfa2b  jmp 0x000072ACF27CF149
000072acf27cfa30  call 0x000072ACF26E2420
000072acf27cfa35  jmp 0x000072ACF27CF15A
000072acf27cfa3a  call 0x000072ACF26E2420
000072acf27cfa3f  jmp 0x000072ACF27CF16B
000072acf27cfa44  call 0x000072ACF26E2420
000072acf27cfa49  jmp 0x000072ACF27CF17C
000072acf27cfa4e  call 0x000072ACF26E2420
000072acf27cfa53  jmp 0x000072ACF27CF18D
000072acf27cfa58  call 0x000072ACF26E2420
000072acf27cfa5d  jmp 0x000072ACF27CF19E
000072acf27cfa62  call 0x000072ACF26E2420
000072acf27cfa67  jmp 0x000072ACF27CF1AF
000072acf27cfa6c  call 0x000072ACF26E2420
000072acf27cfa71  jmp 0x000072ACF27CF1C0
000072acf27cfa76  call 0x000072ACF26E2420
000072acf27cfa7b  jmp 0x000072ACF27CF1D1
000072acf27cfa80  call 0x000072ACF26E2420
000072acf27cfa85  jmp 0x000072ACF27CF1E2
000072acf27cfa8a  call 0x000072ACF26E2420
000072acf27cfa8f  jmp 0x000072ACF27CF1F3
000072acf27cfa94  call 0x000072ACF26E2420
000072acf27cfa99  jmp 0x000072ACF27CF204
000072acf27cfa9e  call 0x000072ACF26E2420
000072acf27cfaa3  jmp 0x000072ACF27CF215
000072acf27cfaa8  call 0x000072ACF26E2420
000072acf27cfaad  jmp 0x000072ACF27CF226
000072acf27cfab2  call 0x000072ACF26E2420
000072acf27cfab7  jmp 0x000072ACF27CF237
000072acf27cfabc  call 0x000072ACF26E2420
000072acf27cfac1  jmp 0x000072ACF27CF248
000072acf27cfac6  call 0x000072ACF26E2420
000072acf27cfacb  jmp 0x000072ACF27CF259
000072acf27cfad0  call 0x000072ACF26E2420
000072acf27cfad5  jmp 0x000072ACF27CF26A
000072acf27cfada  call 0x000072ACF26E2420
000072acf27cfadf  jmp 0x000072ACF27CF27B
000072acf27cfae4  call 0x000072ACF26E2420
000072acf27cfae9  jmp 0x000072ACF27CF28C
000072acf27cfaee  call 0x000072ACF26E2420
000072acf27cfaf3  jmp 0x000072ACF27CF29D
000072acf27cfaf8  call 0x000072ACF26E2420
000072acf27cfafd  jmp 0x000072ACF27CF2AE
000072acf27cfb02  call 0x000072ACF26E2420
000072acf27cfb07  jmp 0x000072ACF27CF2BF
000072acf27cfb0c  call 0x000072ACF26E2420
000072acf27cfb11  jmp 0x000072ACF27CF2D0
000072acf27cfb16  call 0x000072ACF26E2420
000072acf27cfb1b  jmp 0x000072ACF27CF2E1
000072acf27cfb20  call 0x000072ACF26E2420
000072acf27cfb25  jmp 0x000072ACF27CF2F2
000072acf27cfb2a  call 0x000072ACF26E2420
000072acf27cfb2f  jmp 0x000072ACF27CF303
000072acf27cfb34  call 0x000072ACF26E2420
000072acf27cfb39  jmp 0x000072ACF27CF314
000072acf27cfb3e  call 0x000072ACF26E2420
000072acf27cfb43  jmp 0x000072ACF27CF325
000072acf27cfb48  call 0x000072ACF26E2420
000072acf27cfb4d  jmp 0x000072ACF27CF336
000072acf27cfb52  call 0x000072ACF26E2420
000072acf27cfb57  jmp 0x000072ACF27CF347
000072acf27cfb5c  call 0x000072ACF26E2420
000072acf27cfb61  jmp 0x000072ACF27CF358
000072acf27cfb66  call 0x000072ACF26E2420
000072acf27cfb6b  jmp 0x000072ACF27CF369
000072acf27cfb70  call 0x000072ACF26E2420
000072acf27cfb75  jmp 0x000072ACF27CF37A
000072acf27cfb7a  call 0x000072ACF26E2420
000072acf27cfb7f  jmp 0x000072ACF27CF38B
000072acf27cfb84  call 0x000072ACF26E2420
000072acf27cfb89  jmp 0x000072ACF27CF39C
000072acf27cfb8e  call 0x000072ACF26E2420
000072acf27cfb93  jmp 0x000072ACF27CF3AD
000072acf27cfb98  call 0x000072ACF26E2420
000072acf27cfb9d  jmp 0x000072ACF27CF3BE
000072acf27cfba2  call 0x000072ACF26E2420
000072acf27cfba7  jmp 0x000072ACF27CF3CF
000072acf27cfbac  call 0x000072ACF26E2420
000072acf27cfbb1  jmp 0x000072ACF27CF3E0
000072acf27cfbb6  call 0x000072ACF26E2420
000072acf27cfbbb  jmp 0x000072ACF27CF3F1
000072acf27cfbc0  call 0x000072ACF26E2420
000072acf27cfbc5  jmp 0x000072ACF27CF402
000072acf27cfbca  call 0x000072ACF26E2420
000072acf27cfbcf  jmp 0x000072ACF27CF413
000072acf27cfbd4  call 0x000072ACF26E2420
000072acf27cfbd9  jmp 0x000072ACF27CF424
000072acf27cfbde  call 0x000072ACF26E2420
000072acf27cfbe3  jmp 0x000072ACF27CF435
000072acf27cfbe8  call 0x000072ACF26E2420
000072acf27cfbed  jmp 0x000072ACF27CF446
000072acf27cfbf2  call 0x000072ACF26E2420
000072acf27cfbf7  jmp 0x000072ACF27CF45F
000072acf27cfbfc  call 0x000072ACF26E2420
000072acf27cfc01  jmp 0x000072ACF27CF478
000072acf27cfc06  call 0x000072ACF26D5610
000072acf27cfc0b  jmp 0x000072ACF27CF491
000072acf27cfc10  call 0x000072ACF26DC580
000072acf27cfc15  jmp 0x000072ACF27CF7FE
000072acf27cfc1a  call 0x000072ACF26E46C0
000072acf27cfc1f  jmp 0x000072ACF27CF808
000072acf27cfc24  call 0x000072ACF2609E90
000072acf27cfc29  jmp 0x000072ACF27CF80E
000072acf27cfc2e  call 0x000072ACF26DB310
000072acf27cfc33  jmp 0x000072ACF27CF818
000072acf27cfc38  call 0x000072ACF260DAE0
000072acf27cfc3d  jmp 0x000072ACF27CF81D
000072acf27cfc42  call 0x000072ACF26C0230
000072acf27cfc47  jmp 0x000072ACF27CF836
000072acf27cfc4c  call 0x000072ACF26C0230
000072acf27cfc51  jmp 0x000072ACF27CF84B
000072acf27cfc56  call 0x000072ACF26BEFC0
000072acf27cfc5b  jmp 0x000072ACF27CF854
000072acf27cfc60  call 0x000072ACF26E2BA0
000072acf27cfc65  jmp 0x000072ACF27CF91B
000072acf27cfc6a  int3
000072acf27cfc6b  nop [rax+rax*1], eax
000072acf27cfc70  mov rax, [r15+0x48]
000072acf27cfc74  mov r14, [r15+0x58]
000072acf27cfc78  lea r12, [rax+r14*1]
000072acf27cfc7c  mov [r15+0x68], r12
000072acf27cfc80  lea rax, [r14+0x04]
000072acf27cfc84  mov [r15+0x58], rax
000072acf27cfc88  lea r14, [r12+0x04]
000072acf27cfc8d  mov r11d, [r13+r14*1]
000072acf27cfc92  mov [rsp+0x10], r11d
000072acf27cfc97  mov r11d, r11d
000072acf27cfc9a  mov [r15+0x70], r11
000072acf27cfc9e  lea r14, [r12+0x38]
000072acf27cfca3  mov r11d, [r13+r14*1]
000072acf27cfca8  lea r14, [r12+0x24]
000072acf27cfcad  mov r10d, [r13+r14*1]
000072acf27cfcb2  mov [rsp+0x20], r10d
000072acf27cfcb7  mov r10d, r10d
000072acf27cfcba  mov [r15+0x90], r10
000072acf27cfcc1  mov [rsp+0x30], rax
000072acf27cfcc6  xor eax, eax
000072acf27cfcc8  mov r14, [rsp+0x30]
000072acf27cfccd  mov r10d, 0xC0
000072acf27cfcd3  cmp r14, r10
000072acf27cfcd6  cmc
000072acf27cfcd7  lahf
000072acf27cfcd8  seto al
000072acf27cfcdb  mov [r15+0x108], eax
000072acf27cfce2  mov eax, [rsp+0x10]
000072acf27cfce6  mov r14d, [rsp+0x10]
000072acf27cfceb  shrd eax, r14d, 0x07
000072acf27cfcf0  mov [rsp+0x10], r11d
000072acf27cfcf5  mov r10d, [rsp+0x10]
000072acf27cfcfa  shrd r11d, r10d, 0x11
000072acf27cfcff  mov r9d, [r15+0x60]
000072acf27cfd03  mov r8d, [rsp+0x20]
000072acf27cfd08  lea ebp, [r8d+r9d*1]
000072acf27cfd0d  rorx r9d, r14d, 0x12
000072acf27cfd13  xor eax, r9d
000072acf27cfd16  rorx r9d, r10d, 0x13
000072acf27cfd1c  xor r11d, r9d
000072acf27cfd1f  mov [rsp+0x10], r11d
000072acf27cfd24  mov r11d, r11d
000072acf27cfd27  mov [r15+0x88], r11
000072acf27cfd2e  mov [rsp+0x20], r14d
000072acf27cfd33  shr r14d, 0x03
000072acf27cfd37  xor eax, r14d
000072acf27cfd3a  mov [rsp+0x30], eax
000072acf27cfd3e  mov eax, eax
000072acf27cfd40  mov [r15+0x80], rax
000072acf27cfd47  shr r10d, 0x0A
000072acf27cfd4b  mov eax, [rsp+0x10]
000072acf27cfd4f  xor eax, r10d
000072acf27cfd52  mov [rsp+0x10], eax
000072acf27cfd56  mov eax, eax
000072acf27cfd58  mov [r15+0x78], rax
000072acf27cfd5c  mov eax, [rsp+0x30]
000072acf27cfd60  lea r14d, [ebp+eax*1]
000072acf27cfd66  mov eax, [rsp+0x10]
000072acf27cfd6a  lea r11d, [r14d+eax*1]
000072acf27cfd6f  lea rax, [r12+0x40]
000072acf27cfd74  mov [r13+rax*1], r11d
000072acf27cfd79  mov eax, [rsp+0x20]
000072acf27cfd7d  mov eax, eax
000072acf27cfd7f  mov [r15+0x60], rax
000072acf27cfd83  mov eax, [r15+0x108]
000072acf27cfd8a  sahf
000072acf27cfd8b  jnz 0x000072ACF27CFDBD
000072acf27cfd8d  cmp dword ptr [r15+0x318], 0x00
000072acf27cfd95  jz 0x000072ACF27CFE20
000072acf27cfd9b  nop [rax+rax*1], ax
000072acf27cfda4  nop [rax+rax*1], eax
000072acf27cfdac  mov eax, 0x41049C
000072acf27cfdb1  mov [r15+0x100], rax
000072acf27cfdb8  jmp 0x000072ACF25FE110
000072acf27cfdbd  cmp dword ptr [r15+0x318], 0x00
000072acf27cfdc5  jz 0x000072ACF27CFC70
000072acf27cfdcb  nop [rax+rax*1], ax
000072acf27cfdd4  nop [rax+rax*1], eax
000072acf27cfddc  mov eax, 0x410454
000072acf27cfde1  mov [r15+0x100], rax
000072acf27cfde8  jmp 0x000072ACF25FE110
000072acf27cfded  int3
000072acf27cfdee  call 0x000072ACF26E1430
000072acf27cfdf3  jmp 0x000072ACF27CFC92
000072acf27cfdf8  call 0x000072ACF26E1430
000072acf27cfdfd  jmp 0x000072ACF27CFCA8
000072acf27cfe02  call 0x000072ACF26E01C0
000072acf27cfe07  jmp 0x000072ACF27CFCB2
000072acf27cfe0c  call 0x000072ACF260A860
000072acf27cfe11  jmp 0x000072ACF27CFD79
000072acf27cfe16  int3
000072acf27cfe17  nop [rax+rax*1], ax
000072acf27cfe20  mov rax, [r15]
000072acf27cfe23  mov r14d, [r13+rax*1]
000072acf27cfe28  lea r12, [rax+0x04]
000072acf27cfe2c  mov r11d, [r13+r12*1]
000072acf27cfe31  mov [rsp+0x10], r14d
000072acf27cfe36  mov r14d, r14d
000072acf27cfe39  mov [r15+0x78], r14
000072acf27cfe3d  mov [rsp+0x20], r11d
000072acf27cfe42  mov r11d, r11d
000072acf27cfe45  mov [r15+0x80], r11
000072acf27cfe4c  lea r14, [rax+0x08]
000072acf27cfe50  mov r12d, [r13+r14*1]
000072acf27cfe55  lea r14, [rax+0x0C]
000072acf27cfe59  mov r11d, [r13+r14*1]
000072acf27cfe5e  mov [rsp+0x30], r12d
000072acf27cfe63  mov r12d, r12d
000072acf27cfe66  mov [r15+0x70], r12
000072acf27cfe6a  mov [rsp+0x40], r11d
000072acf27cfe6f  mov r11d, r11d
000072acf27cfe72  mov [r15+0x68], r11
000072acf27cfe76  lea r14, [rax+0x18]
000072acf27cfe7a  mov r12d, [r13+r14*1]
000072acf27cfe7f  lea r14, [rax+0x1C]
000072acf27cfe83  mov r11d, [r13+r14*1]
000072acf27cfe88  mov [rsp+0x50], r12d
000072acf27cfe8d  mov r12d, r12d
000072acf27cfe90  mov [r15+0x58], r12
000072acf27cfe94  mov [rsp+0x60], r11d
000072acf27cfe99  mov r11d, r11d
000072acf27cfe9c  mov [r15+0x60], r11
000072acf27cfea0  lea r14, [rax+0x10]
000072acf27cfea4  mov r12d, [r13+r14*1]
000072acf27cfea9  lea r14, [rax+0x14]
000072acf27cfead  mov eax, [r13+r14*1]
000072acf27cfeb2  mov [rsp+0x70], r12d
000072acf27cfeb7  mov r12d, r12d
000072acf27cfeba  mov [r15+0x18], r12
000072acf27cfebe  mov [rsp+0x80], eax
000072acf27cfec5  mov eax, eax
000072acf27cfec7  mov [r15+0x90], rax
000072acf27cfece  mov eax, [rsp+0x70]
000072acf27cfed2  mov eax, eax
000072acf27cfed4  mov [r15+0x30], rax
000072acf27cfed8  mov eax, [rsp+0x50]
000072acf27cfedc  mov eax, eax
000072acf27cfede  mov [r15+0xA0], rax
000072acf27cfee5  mov eax, [rsp+0x30]
000072acf27cfee9  mov eax, eax
000072acf27cfeeb  mov [r15+0x28], rax
000072acf27cfeef  mov eax, [rsp+0x20]
000072acf27cfef3  mov eax, eax
000072acf27cfef5  mov [r15+0x98], rax
000072acf27cfefc  mov eax, [rsp+0x10]
000072acf27cff00  mov eax, eax
000072acf27cff02  mov [r15+0x38], rax
000072acf27cff06  mov eax, [rsp+0x70]
000072acf27cff0a  mov r14d, [rsp+0x70]
000072acf27cff0f  shrd eax, r14d, 0x06
000072acf27cff14  mov [rsp+0x70], r14d
000072acf27cff19  mov r12d, [rsp+0x80]
000072acf27cff21  and r14d, r12d
000072acf27cff24  mov r11d, [rsp+0x10]
000072acf27cff29  mov r10d, [rsp+0x10]
000072acf27cff2e  shrd r11d, r10d, 0x02
000072acf27cff33  mov [rsp+0x10], r12d
000072acf27cff38  mov r12d, r12d
000072acf27cff3b  mov [r15+0x20], r12
000072acf27cff3f  mov r12, [r15+0x50]
000072acf27cff43  mov r9d, [r13+r12*1]
000072acf27cff48  mov r12d, [rsp+0x50]
000072acf27cff4d  mov r8d, [rsp+0x70]
000072acf27cff52  andn ebp, r8d, r12d
000072acf27cff57  mov edi, [rsp+0x60]
000072acf27cff5b  lea esi, [r14d+edi*1]
000072acf27cff60  rorx r14d, r8d, 0x0B
000072acf27cff66  xor eax, r14d
000072acf27cff69  rorx r14d, r10d, 0x0D
000072acf27cff6f  xor r11d, r14d
000072acf27cff72  lea edi, [esi+ebp*1]
000072acf27cff76  mov r14, [r15+0x48]
000072acf27cff7a  mov ebp, [r13+r14*1]
000072acf27cff7f  mov r14d, [rsp+0x30]
000072acf27cff84  mov esi, [rsp+0x20]
000072acf27cff88  and r14d, esi
000072acf27cff8b  mov [rsp+0x20], r14d
000072acf27cff90  mov r14d, r14d
000072acf27cff93  mov [r15+0xD8], r14
000072acf27cff9a  lea r14d, [edi+r9d*1]
000072acf27cff9f  mov r9d, [rsp+0x30]
000072acf27cffa4  xor r9d, esi
000072acf27cffa7  rorx edi, r8d, 0x19
000072acf27cffad  xor eax, edi
000072acf27cffaf  and r9d, r10d
000072acf27cffb2  rorx edi, r10d, 0x16
000072acf27cffb8  xor r11d, edi
000072acf27cffbb  mov [rsp+0x30], r11d
000072acf27cffc0  mov r11d, r11d
000072acf27cffc3  mov [r15+0xD0], r11
000072acf27cffca  lea r11d, [r14d+ebp*1]
000072acf27cffcf  mov r10d, [rsp+0x20]
000072acf27cffd4  xor r9d, r10d
000072acf27cffd7  lea r14d, [r11d+eax*1]
000072acf27cffdc  mov qword ptr [r15+0x88], 0x04
000072acf27cffe7  mov eax, [rsp+0x30]
000072acf27cffeb  lea r11d, [r9d+eax*1]
000072acf27cfff0  mov eax, [rsp+0x40]
000072acf27cfff4  lea r10d, [r14d+eax*1]
000072acf27cfff9  mov r10d, r10d
000072acf27cfffc  mov [r15+0xB8], r10
000072acf27d0003  xor eax, eax
000072acf27d0005  mov r10d, 0x04
000072acf27d000b  mov r9d, 0x100
000072acf27d0011  cmp r10, r9
000072acf27d0014  cmc
000072acf27d0015  lahf
000072acf27d0016  seto al
000072acf27d0019  mov [r15+0x108], eax
000072acf27d0020  lea eax, [r11d+r14d*1]
000072acf27d0025  mov eax, eax
000072acf27d0027  mov [r15+0xA8], rax
000072acf27d002e  mov r12d, r12d
000072acf27d0031  mov [r15+0xB0], r12
000072acf27d0038  mov eax, [rsp+0x10]
000072acf27d003c  mov eax, eax
000072acf27d003e  mov [r15+0xC0], rax
000072acf27d0045  mov r8d, r8d
000072acf27d0048  mov [r15+0xC8], r8
000072acf27d004f  mov eax, [r15+0x108]
000072acf27d0056  sahf
000072acf27d0057  jnz 0x000072ACF27D0089
000072acf27d0059  cmp dword ptr [r15+0x318], 0x00
000072acf27d0061  jz 0x000072ACF27D0350
000072acf27d0067  nop [rax+rax*1], ax
000072acf27d0070  nop [rax+rax*1], eax
000072acf27d0078  mov eax, 0x41055C
000072acf27d007d  mov [r15+0x100], rax
000072acf27d0084  jmp 0x000072ACF25FE110
000072acf27d0089  cmp dword ptr [r15+0x318], 0x00
000072acf27d0091  jz 0x000072ACF27D0120
000072acf27d0097  nop [rax+rax*1], ax
000072acf27d00a0  nop [rax+rax*1], eax
000072acf27d00a8  mov eax, 0x4104D0
000072acf27d00ad  mov [r15+0x100], rax
000072acf27d00b4  jmp 0x000072ACF25FE110
000072acf27d00b9  int3
000072acf27d00ba  call 0x000072ACF260DAE0
000072acf27d00bf  jmp 0x000072ACF27CFE28
000072acf27d00c4  call 0x000072ACF26C0230
000072acf27d00c9  jmp 0x000072ACF27CFE31
000072acf27d00ce  call 0x000072ACF26E26A0
000072acf27d00d3  jmp 0x000072ACF27CFE55
000072acf27d00d8  call 0x000072ACF26E1430
000072acf27d00dd  jmp 0x000072ACF27CFE5E
000072acf27d00e2  call 0x000072ACF26E26A0
000072acf27d00e7  jmp 0x000072ACF27CFE7F
000072acf27d00ec  call 0x000072ACF26E1430
000072acf27d00f1  jmp 0x000072ACF27CFE88
000072acf27d00f6  call 0x000072ACF26E26A0
000072acf27d00fb  jmp 0x000072ACF27CFEA9
000072acf27d0100  call 0x000072ACF26D5890
000072acf27d0105  jmp 0x000072ACF27CFEB2
000072acf27d010a  call 0x000072ACF26BDD50
000072acf27d010f  jmp 0x000072ACF27CFF48
000072acf27d0114  call 0x000072ACF26DA580
000072acf27d0119  jmp 0x000072ACF27CFF7F
000072acf27d011e  int3
000072acf27d011f  nop
000072acf27d0120  mov eax, [r15+0xB8]
000072acf27d0127  mov [rsp+0x10], eax
000072acf27d012b  mov eax, eax
000072acf27d012d  mov [r15+0x30], rax
000072acf27d0131  mov eax, [r15+0xC0]
000072acf27d0138  mov [rsp+0x20], eax
000072acf27d013c  mov eax, eax
000072acf27d013e  mov [r15+0xA0], rax
000072acf27d0145  mov eax, [r15+0x28]
000072acf27d0149  mov r14d, [r15+0x98]
000072acf27d0150  mov [rsp+0x30], r14d
000072acf27d0155  mov r14d, r14d
000072acf27d0158  mov [r15+0x28], r14
000072acf27d015c  mov r14d, [r15+0x38]
000072acf27d0160  mov [rsp+0x40], r14d
000072acf27d0165  mov r14d, r14d
000072acf27d0168  mov [r15+0x98], r14
000072acf27d016f  mov r14d, [r15+0xA8]
000072acf27d0176  mov [rsp+0x50], r14d
000072acf27d017b  mov r14d, r14d
000072acf27d017e  mov [r15+0x38], r14
000072acf27d0182  mov r14d, [rsp+0x10]
000072acf27d0187  mov r12d, [rsp+0x10]
000072acf27d018c  shrd r14d, r12d, 0x06
000072acf27d0191  mov r11d, [r15+0xC8]
000072acf27d0198  mov [rsp+0x10], r12d
000072acf27d019d  and r12d, r11d
000072acf27d01a0  mov r10d, [rsp+0x50]
000072acf27d01a5  mov r9d, [rsp+0x50]
000072acf27d01aa  shrd r10d, r9d, 0x02
000072acf27d01af  mov [rsp+0x50], r11d
000072acf27d01b4  mov r11d, r11d
000072acf27d01b7  mov [r15+0x20], r11
000072acf27d01bb  mov r11, [r15+0x88]
000072acf27d01c2  mov r8, [r15+0x50]
000072acf27d01c6  lea rbp, [r8+r11*1]
000072acf27d01ca  mov r8d, [r13+rbp*1]
000072acf27d01cf  mov ebp, [rsp+0x20]
000072acf27d01d3  mov edi, [rsp+0x10]
000072acf27d01d7  andn esi, edi, ebp
000072acf27d01dc  mov edx, [r15+0xB0]
000072acf27d01e3  lea ecx, [r12d+edx*1]
000072acf27d01e8  rorx r12d, edi, 0x0B
000072acf27d01ee  xor r14d, r12d
000072acf27d01f1  rorx r12d, r9d, 0x0D
000072acf27d01f7  xor r10d, r12d
000072acf27d01fa  lea r12d, [ecx+esi*1]
000072acf27d01ff  mov rsi, [r15+0x48]
000072acf27d0203  lea rdx, [rsi+r11*1]
000072acf27d0207  mov esi, [r13+rdx*1]
000072acf27d020c  mov edx, [rsp+0x30]
000072acf27d0210  mov ecx, [rsp+0x40]
000072acf27d0214  and edx, ecx
000072acf27d0216  mov [rsp+0x10], edx
000072acf27d021a  mov edx, edx
000072acf27d021c  mov [r15+0xD8], rdx
000072acf27d0223  lea edx, [r12d+r8d*1]
000072acf27d0228  mov r12d, [rsp+0x30]
000072acf27d022d  xor r12d, ecx
000072acf27d0230  rorx r8d, edi, 0x19
000072acf27d0236  xor r14d, r8d
000072acf27d0239  and r12d, r9d
000072acf27d023c  rorx r8d, r9d, 0x16
000072acf27d0242  xor r10d, r8d
000072acf27d0245  mov [rsp+0x20], r10d
000072acf27d024a  mov r10d, r10d
000072acf27d024d  mov [r15+0xD0], r10
000072acf27d0254  lea r10d, [edx+esi*1]
000072acf27d0259  mov r9d, [rsp+0x10]
000072acf27d025e  xor r12d, r9d
000072acf27d0261  lea r9d, [r10d+r14d*1]
000072acf27d0266  lea r14, [r11+0x04]
000072acf27d026a  mov [r15+0x88], r14
000072acf27d0271  mov r11d, [rsp+0x20]
000072acf27d0276  lea r10d, [r12d+r11d*1]
000072acf27d027b  lea r11d, [r9d+eax*1]
000072acf27d0280  mov r11d, r11d
000072acf27d0283  mov [r15+0xB8], r11
000072acf27d028a  xor eax, eax
000072acf27d028c  mov r12d, 0x100
000072acf27d0292  cmp r14, r12
000072acf27d0295  cmc
000072acf27d0296  lahf
000072acf27d0297  seto al
000072acf27d029a  mov [r15+0x108], eax
000072acf27d02a1  lea eax, [r10d+r9d*1]
000072acf27d02a6  mov eax, eax
000072acf27d02a8  mov [r15+0xA8], rax
000072acf27d02af  mov ebp, ebp
000072acf27d02b1  mov [r15+0xB0], rbp
000072acf27d02b8  mov eax, [rsp+0x50]
000072acf27d02bc  mov eax, eax
000072acf27d02be  mov [r15+0xC0], rax
000072acf27d02c5  mov edi, edi
000072acf27d02c7  mov [r15+0xC8], rdi
000072acf27d02ce  mov eax, [r15+0x108]
000072acf27d02d5  sahf
000072acf27d02d6  jnz 0x000072ACF27D0308
000072acf27d02d8  cmp dword ptr [r15+0x318], 0x00
000072acf27d02e0  jz 0x000072ACF27D0350
000072acf27d02e6  nop [rax+rax*1], ax
000072acf27d02ef  nop [rax+rax*1], eax
000072acf27d02f7  mov eax, 0x41055C
000072acf27d02fc  mov [r15+0x100], rax
000072acf27d0303  jmp 0x000072ACF25FE110
000072acf27d0308  cmp dword ptr [r15+0x318], 0x00
000072acf27d0310  jz 0x000072ACF27D0120
000072acf27d0316  nop [rax+rax*1], ax
000072acf27d031f  nop [rax+rax*1], eax
000072acf27d0327  mov eax, 0x4104D0
000072acf27d032c  mov [r15+0x100], rax
000072acf27d0333  jmp 0x000072ACF25FE110
000072acf27d0338  int3
000072acf27d0339  call 0x000072ACF2649010
000072acf27d033e  jmp 0x000072ACF27D01CF
000072acf27d0343  call 0x000072ACF2625930
000072acf27d0348  jmp 0x000072ACF27D020C
000072acf27d034d  int3
000072acf27d034e  nop
000072acf27d0350  mov eax, [r15+0x98]
000072acf27d0357  mov r14d, [r15+0x70]
000072acf27d035b  lea r12d, [eax+r14d*1]
000072acf27d0360  mov eax, [r15+0x28]
000072acf27d0364  mov r14d, [r15+0x68]
000072acf27d0368  lea r11d, [eax+r14d*1]
000072acf27d036d  mov qword ptr [r15+0x88], 0x00
000072acf27d0378  mov eax, [r15+0xA8]
000072acf27d037f  mov r14d, [r15+0x78]
000072acf27d0383  lea r10d, [eax+r14d*1]
000072acf27d0388  mov [rsp+0x10], r10d
000072acf27d038d  mov r10d, r10d
000072acf27d0390  mov [r15+0x78], r10
000072acf27d0394  mov eax, [r15+0x38]
000072acf27d0398  mov r14d, [r15+0x80]
000072acf27d039f  lea r10d, [eax+r14d*1]
000072acf27d03a4  mov [rsp+0x20], r10d
000072acf27d03a9  mov r10d, r10d
000072acf27d03ac  mov [r15+0x80], r10
000072acf27d03b3  mov rax, [r15]
000072acf27d03b6  lea r14, [rax+0x08]
000072acf27d03ba  mov [r13+r14*1], r12d
000072acf27d03bf  lea r14, [rax+0x0C]
000072acf27d03c3  mov [r13+r14*1], r11d
000072acf27d03c8  mov r14d, [r15+0xB8]
000072acf27d03cf  mov r12d, [r15+0x18]
000072acf27d03d3  lea r11d, [r14d+r12d*1]
000072acf27d03d8  mov [rsp+0x30], r11d
000072acf27d03dd  mov r11d, r11d
000072acf27d03e0  mov [r15+0x68], r11
000072acf27d03e4  mov r14d, [r15+0x30]
000072acf27d03e8  mov r12d, [r15+0x90]
000072acf27d03ef  lea r11d, [r14d+r12d*1]
000072acf27d03f4  mov [rsp+0x40], r11d
000072acf27d03f9  mov r11d, r11d
000072acf27d03fc  mov [r15+0x70], r11
000072acf27d0400  mov r14d, [r15+0x20]
000072acf27d0404  mov r12d, [r15+0x58]
000072acf27d0408  lea r11d, [r14d+r12d*1]
000072acf27d040d  mov [rsp+0x50], r11d
000072acf27d0412  mov r11d, r11d
000072acf27d0415  mov [r15+0x58], r11
000072acf27d0419  mov r14d, [r15+0xA0]
000072acf27d0420  mov r12d, [r15+0x60]
000072acf27d0424  lea r11d, [r14d+r12d*1]
000072acf27d0429  mov [rsp+0x60], r11d
000072acf27d042e  mov r11d, r11d
000072acf27d0431  mov [r15+0x60], r11
000072acf27d0435  mov r14d, [rsp+0x10]
000072acf27d043a  mov [r13+rax*1], r14d
000072acf27d043f  lea r14, [rax+0x04]
000072acf27d0443  mov r12d, [rsp+0x20]
000072acf27d0448  mov [r13+r14*1], r12d
000072acf27d044d  lea r14, [rax+0x10]
000072acf27d0451  mov r12d, [rsp+0x30]
000072acf27d0456  mov [r13+r14*1], r12d
000072acf27d045b  lea r14, [rax+0x14]
000072acf27d045f  mov r12d, [rsp+0x40]
000072acf27d0464  mov [r13+r14*1], r12d
000072acf27d0469  lea r14, [rax+0x18]
000072acf27d046d  mov r12d, [rsp+0x50]
000072acf27d0472  mov [r13+r14*1], r12d
000072acf27d0477  lea r14, [rax+0x1C]
000072acf27d047b  mov r12d, [rsp+0x60]
000072acf27d0480  mov [r13+r14*1], r12d
000072acf27d0485  lea r14, [rax+0x68]
000072acf27d0489  xor eax, eax
000072acf27d048b  mov [r13+r14*1], rax
000072acf27d0490  cmp dword ptr [r15+0x318], 0x00
000072acf27d0498  jz 0x000072ACF27CEF90
000072acf27d049e  nop [rax+rax*1], ax
000072acf27d04a7  nop [rax+rax*1], eax
000072acf27d04af  mov eax, 0x410378
000072acf27d04b4  mov [r15+0x100], rax
000072acf27d04bb  jmp 0x000072ACF25FE110
000072acf27d04c0  int3
000072acf27d04c1  call 0x000072ACF26E2BA0
000072acf27d04c6  jmp 0x000072ACF27D03BF
000072acf27d04cb  call 0x000072ACF26E1920
000072acf27d04d0  jmp 0x000072ACF27D03C8
000072acf27d04d5  call 0x000072ACF260DFE0
000072acf27d04da  jmp 0x000072ACF27D043F
000072acf27d04df  call 0x000072ACF26E2BA0
000072acf27d04e4  jmp 0x000072ACF27D044D
000072acf27d04e9  call 0x000072ACF26E2BA0
000072acf27d04ee  jmp 0x000072ACF27D045B
000072acf27d04f3  call 0x000072ACF26E2BA0
000072acf27d04f8  jmp 0x000072ACF27D0469
000072acf27d04fd  call 0x000072ACF26E2BA0
000072acf27d0502  jmp 0x000072ACF27D0477
000072acf27d0507  call 0x000072ACF26E2BA0
000072acf27d050c  jmp 0x000072ACF27D0485
000072acf27d0511  call 0x000072ACF26D5EB0
000072acf27d0516  jmp 0x000072ACF27D0490
000072acf27d051b  int3
000072acf27d051c  nop [rax], eax
000072acf27d0520  mov rax, [r15+0xF8]
000072acf27d0527  lea r14, [rax+0x140]
000072acf27d052e  mov r12, [r13+r14*1]
000072acf27d0533  lea r14, [rax+0x148]
000072acf27d053a  mov r11, [r13+r14*1]
000072acf27d053f  mov [r15+0xA0], r12
000072acf27d0546  mov [r15+0x98], r11
000072acf27d054d  lea r14, [rax+0x130]
000072acf27d0554  mov r12, [r13+r14*1]
000072acf27d0559  lea r14, [rax+0x138]
000072acf27d0560  mov r11, [r13+r14*1]
000072acf27d0565  mov [r15+0xB0], r12
000072acf27d056c  mov [r15+0xA8], r11
000072acf27d0573  lea r14, [rax+0x120]
000072acf27d057a  mov r12, [r13+r14*1]
000072acf27d057f  lea r14, [rax+0x128]
000072acf27d0586  mov r11, [r13+r14*1]
000072acf27d058b  mov [r15+0xC0], r12
000072acf27d0592  mov [r15+0xB8], r11
000072acf27d0599  lea r14, [rax+0x110]
000072acf27d05a0  mov r12, [r13+r14*1]
000072acf27d05a5  lea r14, [rax+0x118]
000072acf27d05ac  mov r11, [r13+r14*1]
000072acf27d05b1  mov [r15+0xD0], r12
000072acf27d05b8  mov [r15+0xC8], r11
000072acf27d05bf  lea r14, [rax+0x100]
000072acf27d05c6  mov r12, [r13+r14*1]
000072acf27d05cb  lea r14, [rax+0x108]
000072acf27d05d2  mov r11, [r13+r14*1]
000072acf27d05d7  mov [r15+0xE8], r12
000072acf27d05de  mov [r15+0xD8], r11
000072acf27d05e5  lea r14, [rax+0x150]
000072acf27d05ec  mov [r15+0xF8], r14
000072acf27d05f3  mov rax, [r15+0xF0]
000072acf27d05fa  mov [r15+0x100], rax
000072acf27d0601  jmp 0x000072ACF27CE5C0
000072acf27d0606  int3
000072acf27d0607  call 0x000072ACF26E27E0
000072acf27d060c  jmp 0x000072ACF27D0533
000072acf27d0611  call 0x000072ACF26E1570
000072acf27d0616  jmp 0x000072ACF27D053F
000072acf27d061b  call 0x000072ACF26E27E0
000072acf27d0620  jmp 0x000072ACF27D0559
000072acf27d0625  call 0x000072ACF26E1570
000072acf27d062a  jmp 0x000072ACF27D0565
000072acf27d062f  call 0x000072ACF26E27E0
000072acf27d0634  jmp 0x000072ACF27D057F
000072acf27d0639  call 0x000072ACF26E1570
000072acf27d063e  jmp 0x000072ACF27D058B
000072acf27d0643  call 0x000072ACF26E27E0
000072acf27d0648  jmp 0x000072ACF27D05A5
000072acf27d064d  call 0x000072ACF26E1570
000072acf27d0652  jmp 0x000072ACF27D05B1
000072acf27d0657  call 0x000072ACF26E27E0
000072acf27d065c  jmp 0x000072ACF27D05CB
000072acf27d0661  call 0x000072ACF26E1570
000072acf27d0666  jmp 0x000072ACF27D05D7
000072acf27d066b  int3
000072acf27d066c  nop [rax], eax
000072acf27d0670  mov eax, [r15+0xA0]
000072acf27d0677  mov [rsp+0x10], eax
000072acf27d067b  xor eax, eax
000072acf27d067d  mov r14d, [rsp+0x10]
000072acf27d0682  sub r14d, 0x01
000072acf27d0686  cmc
000072acf27d0687  lahf
000072acf27d0688  seto al
000072acf27d068b  mov [r15+0x108], eax
000072acf27d0692  mov r14d, r14d
000072acf27d0695  mov [r15+0xA0], r14
000072acf27d069c  mov eax, [r15+0x108]
000072acf27d06a3  sahf
000072acf27d06a4  jnz 0x000072ACF27D06D6
000072acf27d06a6  cmp dword ptr [r15+0x318], 0x00
000072acf27d06ae  jz 0x000072ACF27D07A0
000072acf27d06b4  nop [rax+rax*1], ax
000072acf27d06bd  nop [rax+rax*1], eax
000072acf27d06c5  mov eax, 0x41027C
000072acf27d06ca  mov [r15+0x100], rax
000072acf27d06d1  jmp 0x000072ACF25FE110
000072acf27d06d6  cmp dword ptr [r15+0x318], 0x00
000072acf27d06de  jz 0x000072ACF27D0710
000072acf27d06e4  nop [rax+rax*1], ax
000072acf27d06ed  nop [rax+rax*1], eax
000072acf27d06f5  mov eax, 0x410264
000072acf27d06fa  mov [r15+0x100], rax
000072acf27d0701  jmp 0x000072ACF25FE110
000072acf27d0706  int3
000072acf27d0707  int3
000072acf27d0708  nop [rax+rax*1], eax
000072acf27d0710  mov rax, [r15+0xF8]
000072acf27d0717  mov [r15], rax
000072acf27d071a  mov rax, [r15+0x98]
000072acf27d0721  mov [r15+0x08], rax
000072acf27d0725  mov qword ptr [r15+0x10], 0x12C
000072acf27d072d  mov qword ptr [r15+0xF0], 0x410274
000072acf27d0738  mov r14d, [r15+0x320]
000072acf27d073f  mov eax, 0x410274
000072acf27d0744  mov rcx, 0x72ACF27D0670
000072acf27d074e  mov [r15+r14*8+0x328], rax
000072acf27d0756  mov [r15+r14*8+0x368], rcx
000072acf27d075e  add r14d, 0x01
000072acf27d0762  and r14d, 0x07
000072acf27d0766  mov [r15+0x320], r14d
000072acf27d076d  cmp dword ptr [r15+0x318], 0x00
000072acf27d0775  jz 0x000072ACF27CEC20
000072acf27d077b  nop [rax+rax*1], ax
000072acf27d0784  nop [rax+rax*1], eax
000072acf27d078c  mov eax, 0x410338
000072acf27d0791  mov [r15+0x100], rax
000072acf27d0798  jmp 0x000072ACF25FE110
000072acf27d079d  int3
000072acf27d079e  int3
000072acf27d079f  nop
000072acf27d07a0  mov rax, [r15+0xF8]
000072acf27d07a7  lea r14, [rax+0x20]
000072acf27d07ab  mov r12, [r13+r14*1]
000072acf27d07b0  mov [r15+0x98], r12
000072acf27d07b7  mov qword ptr [r15+0x40], 0x80
000072acf27d07bf  mov [r15], rax
000072acf27d07c2  lea r14, [rax+0x8C]
000072acf27d07c9  mov [r15+0x08], r14
000072acf27d07cd  mov qword ptr [r15+0x10], 0x01
000072acf27d07d5  lea r14, [rax+0x8C]
000072acf27d07dc  mov eax, 0x80
000072acf27d07e1  mov [r13+r14*1], al
000072acf27d07e6  mov qword ptr [r15+0xF0], 0x410298
000072acf27d07f1  mov r14d, [r15+0x320]
000072acf27d07f8  mov eax, 0x410298
000072acf27d07fd  mov rcx, 0x72ACF27D0870
000072acf27d0807  mov [r15+r14*8+0x328], rax
000072acf27d080f  mov [r15+r14*8+0x368], rcx
000072acf27d0817  add r14d, 0x01
000072acf27d081b  and r14d, 0x07
000072acf27d081f  mov [r15+0x320], r14d
000072acf27d0826  cmp dword ptr [r15+0x318], 0x00
000072acf27d082e  jz 0x000072ACF27CEC20
000072acf27d0834  nop [rax+rax*1], ax
000072acf27d083d  nop [rax+rax*1], eax
000072acf27d0845  mov eax, 0x410338
000072acf27d084a  mov [r15+0x100], rax
000072acf27d0851  jmp 0x000072ACF25FE110
000072acf27d0856  int3
000072acf27d0857  call 0x000072ACF26E27E0
000072acf27d085c  jmp 0x000072ACF27D07B0
000072acf27d0861  call 0x000072ACF26D5AF0
000072acf27d0866  jmp 0x000072ACF27D07E6
000072acf27d086b  int3
000072acf27d086c  nop [rax], eax
000072acf27d0870  mov rax, [r15+0xF8]
000072acf27d0877  lea r14, [rax+0x68]
000072acf27d087b  mov r12, [r13+r14*1]
000072acf27d0880  mov [r15+0x40], r12
000072acf27d0884  lea r14, [rax+0x88]
000072acf27d088b  xor eax, eax
000072acf27d088d  mov [r13+r14*1], al
000072acf27d0892  xor eax, eax
000072acf27d0894  mov r14d, 0x38
000072acf27d089a  cmp r12, r14
000072acf27d089d  cmc
000072acf27d089e  lahf
000072acf27d089f  seto al
000072acf27d08a2  mov [r15+0x108], eax
000072acf27d08a9  mov eax, [r15+0x108]
000072acf27d08b0  sahf
000072acf27d08b1  jz 0x000072ACF27D08E3
000072acf27d08b3  cmp dword ptr [r15+0x318], 0x00
000072acf27d08bb  jz 0x000072ACF27D0930
000072acf27d08c1  nop [rax+rax*1], ax
000072acf27d08ca  nop [rax+rax*1], eax
000072acf27d08d2  mov eax, 0x4102A8
000072acf27d08d7  mov [r15+0x100], rax
000072acf27d08de  jmp 0x000072ACF25FE110
000072acf27d08e3  cmp dword ptr [r15+0x318], 0x00
000072acf27d08eb  jz 0x000072ACF27D0A70
000072acf27d08f1  nop [rax+rax*1], ax
000072acf27d08fa  nop [rax+rax*1], eax
000072acf27d0902  mov eax, 0x4102C4
000072acf27d0907  mov [r15+0x100], rax
000072acf27d090e  jmp 0x000072ACF25FE110
000072acf27d0913  int3
000072acf27d0914  call 0x000072ACF26E27E0
000072acf27d0919  jmp 0x000072ACF27D0880
000072acf27d091e  call 0x000072ACF26D5AF0
000072acf27d0923  jmp 0x000072ACF27D0892
000072acf27d0928  int3
000072acf27d0929  nop [rax], eax
000072acf27d0930  mov rax, [r15+0xF8]
000072acf27d0937  mov [r15], rax
000072acf27d093a  lea r14, [rax+0x88]
000072acf27d0941  mov [r15+0x08], r14
000072acf27d0945  mov qword ptr [r15+0x10], 0x01
000072acf27d094d  mov qword ptr [r15+0xF0], 0x4102B8
000072acf27d0958  mov r14d, [r15+0x320]
000072acf27d095f  mov eax, 0x4102B8
000072acf27d0964  mov rcx, 0x72ACF27D09C0
000072acf27d096e  mov [r15+r14*8+0x328], rax
000072acf27d0976  mov [r15+r14*8+0x368], rcx
000072acf27d097e  add r14d, 0x01
000072acf27d0982  and r14d, 0x07
000072acf27d0986  mov [r15+0x320], r14d
000072acf27d098d  cmp dword ptr [r15+0x318], 0x00
000072acf27d0995  jz 0x000072ACF27CEC20
000072acf27d099b  nop [rax+rax*1], ax
000072acf27d09a4  nop [rax+rax*1], eax
000072acf27d09ac  mov eax, 0x410338
000072acf27d09b1  mov [r15+0x100], rax
000072acf27d09b8  jmp 0x000072ACF25FE110
000072acf27d09bd  int3
000072acf27d09be  int3
000072acf27d09bf  nop
000072acf27d09c0  mov rax, [r15+0xF8]
000072acf27d09c7  lea r14, [rax+0x68]
000072acf27d09cb  mov rax, [r13+r14*1]
000072acf27d09d0  mov [r15+0x40], rax
000072acf27d09d4  mov [rsp+0x10], rax
000072acf27d09d9  xor eax, eax
000072acf27d09db  mov r14, [rsp+0x10]
000072acf27d09e0  mov r12d, 0x38
000072acf27d09e6  cmp r14, r12
000072acf27d09e9  cmc
000072acf27d09ea  lahf
000072acf27d09eb  seto al
000072acf27d09ee  mov [r15+0x108], eax
000072acf27d09f5  mov eax, [r15+0x108]
000072acf27d09fc  sahf
000072acf27d09fd  jnz 0x000072ACF27D0A2F
000072acf27d09ff  cmp dword ptr [r15+0x318], 0x00
000072acf27d0a07  jz 0x000072ACF27D0A70
000072acf27d0a0d  nop [rax+rax*1], ax
000072acf27d0a16  nop [rax+rax*1], eax
000072acf27d0a1e  mov eax, 0x4102C4
000072acf27d0a23  mov [r15+0x100], rax
000072acf27d0a2a  jmp 0x000072ACF25FE110
000072acf27d0a2f  cmp dword ptr [r15+0x318], 0x00
000072acf27d0a37  jz 0x000072ACF27D0930
000072acf27d0a3d  nop [rax+rax*1], ax
000072acf27d0a46  nop [rax+rax*1], eax
000072acf27d0a4e  mov eax, 0x4102A8
000072acf27d0a53  mov [r15+0x100], rax
000072acf27d0a5a  jmp 0x000072ACF25FE110
000072acf27d0a5f  int3
000072acf27d0a60  call 0x000072ACF26D59C0
000072acf27d0a65  jmp 0x000072ACF27D09D0
000072acf27d0a6a  int3
000072acf27d0a6b  nop [rax+rax*1], eax
000072acf27d0a70  mov rax, [r15+0x98]
000072acf27d0a77  rorx r14, rax, 0x3D
000072acf27d0a7d  and r14, 0xFFFFFFFFFFFFFFF8
000072acf27d0a81  mov rax, [r15+0xF8]
000072acf27d0a88  mov [r15], rax
000072acf27d0a8b  lea r12, [rax+0x78]
000072acf27d0a8f  mov [r15+0x08], r12
000072acf27d0a93  mov qword ptr [r15+0x10], 0x08
000072acf27d0a9b  bswap r14
000072acf27d0a9e  mov [r15+0x40], r14
000072acf27d0aa2  lea r12, [rax+0x78]
000072acf27d0aa6  mov [r13+r12*1], r14
000072acf27d0aab  mov qword ptr [r15+0xF0], 0x4102E0
000072acf27d0ab6  mov r14d, [r15+0x320]
000072acf27d0abd  mov eax, 0x4102E0
000072acf27d0ac2  mov rcx, 0x72ACF27D0B30
000072acf27d0acc  mov [r15+r14*8+0x328], rax
000072acf27d0ad4  mov [r15+r14*8+0x368], rcx
000072acf27d0adc  add r14d, 0x01
000072acf27d0ae0  and r14d, 0x07
000072acf27d0ae4  mov [r15+0x320], r14d
000072acf27d0aeb  cmp dword ptr [r15+0x318], 0x00
000072acf27d0af3  jz 0x000072ACF27CEC20
000072acf27d0af9  nop [rax+rax*1], ax
000072acf27d0b02  nop [rax+rax*1], eax
000072acf27d0b0a  mov eax, 0x410338
000072acf27d0b0f  mov [r15+0x100], rax
000072acf27d0b16  jmp 0x000072ACF25FE110
000072acf27d0b1b  int3
000072acf27d0b1c  call 0x000072ACF26C3FE0
000072acf27d0b21  jmp 0x000072ACF27D0AAB
000072acf27d0b26  int3
000072acf27d0b27  nop [rax+rax*1], ax
000072acf27d0b30  mov rax, [r15+0xF8]
000072acf27d0b37  mov r14d, [r13+rax*1]
000072acf27d0b3c  lea r12, [rax+0x04]
000072acf27d0b40  mov r11d, [r13+r12*1]
000072acf27d0b45  lea r12, [rax+0x08]
000072acf27d0b49  mov r10d, [r13+r12*1]
000072acf27d0b4e  lea r12, [rax+0x0C]
000072acf27d0b52  mov r9d, [r13+r12*1]
000072acf27d0b57  mov qword ptr [r15+0x48], 0x430860
000072acf27d0b5f  lea r12, [rax+0x80]
000072acf27d0b66  mov r8, [r13+r12*1]
000072acf27d0b6b  mov [r15+0xF0], r8
000072acf27d0b72  bswap r14d
000072acf27d0b75  bswap r11d
000072acf27d0b78  mov r12d, 0x430860
000072acf27d0b7e  mov [r13+r12*1], r14d
000072acf27d0b83  mov r14d, 0x430864
000072acf27d0b89  mov [r13+r14*1], r11d
000072acf27d0b8e  bswap r10d
000072acf27d0b91  bswap r9d
000072acf27d0b94  lea r14, [rax+0x10]
000072acf27d0b98  mov r12d, [r13+r14*1]
000072acf27d0b9d  lea r14, [rax+0x14]
000072acf27d0ba1  mov r11d, [r13+r14*1]
000072acf27d0ba6  mov r14d, 0x430868
000072acf27d0bac  mov [r13+r14*1], r10d
000072acf27d0bb1  mov r14d, 0x43086C
000072acf27d0bb7  mov [r13+r14*1], r9d
000072acf27d0bbc  lea r14, [rax+0x90]
000072acf27d0bc3  mov r10, [r13+r14*1]
000072acf27d0bc8  lea r14, [rax+0x98]
000072acf27d0bcf  mov r9, [r13+r14*1]
000072acf27d0bd4  mov [r15+0xA0], r10
000072acf27d0bdb  mov [r15+0x98], r9
000072acf27d0be2  bswap r12d
000072acf27d0be5  bswap r11d
000072acf27d0be8  mov [rsp+0x10], r11d
000072acf27d0bed  mov r11d, r11d
000072acf27d0bf0  mov [r15+0x58], r11
000072acf27d0bf4  lea r14, [rax+0x18]
000072acf27d0bf8  mov r11d, [r13+r14*1]
000072acf27d0bfd  lea r14, [rax+0x1C]
000072acf27d0c01  mov r10d, [r13+r14*1]
000072acf27d0c06  mov [rsp+0x20], r10d
000072acf27d0c0b  mov r10d, r10d
000072acf27d0c0e  mov [r15+0x60], r10
000072acf27d0c12  mov r14d, 0x430870
000072acf27d0c18  mov [r13+r14*1], r12d
000072acf27d0c1d  mov r14d, 0x430874
000072acf27d0c23  mov r12d, [rsp+0x10]
000072acf27d0c28  mov [r13+r14*1], r12d
000072acf27d0c2d  bswap r11d
000072acf27d0c30  mov [rsp+0x10], r11d
000072acf27d0c35  mov r11d, r11d
000072acf27d0c38  mov [r15+0x40], r11
000072acf27d0c3c  mov r14d, [rsp+0x20]
000072acf27d0c41  bswap r14d
000072acf27d0c44  mov [rsp+0x20], r14d
000072acf27d0c49  mov r14d, r14d
000072acf27d0c4c  mov [r15+0x50], r14
000072acf27d0c50  mov r14d, 0x430878
000072acf27d0c56  mov r12d, [rsp+0x10]
000072acf27d0c5b  mov [r13+r14*1], r12d
000072acf27d0c60  mov r14d, 0x43087C
000072acf27d0c66  mov r12d, [rsp+0x20]
000072acf27d0c6b  mov [r13+r14*1], r12d
000072acf27d0c70  lea r14, [rax+0xA0]
000072acf27d0c77  mov [r15+0xF8], r14
000072acf27d0c7e  mov [r15+0x100], r8
000072acf27d0c85  jmp 0x000072ACF27CE5C0
000072acf27d0c8a  int3
000072acf27d0c8b  call 0x000072ACF260DAE0
000072acf27d0c90  jmp 0x000072ACF27D0B3C
000072acf27d0c95  call 0x000072ACF26C0230
000072acf27d0c9a  jmp 0x000072ACF27D0B45
000072acf27d0c9f  call 0x000072ACF26BEFC0
000072acf27d0ca4  jmp 0x000072ACF27D0B4E
000072acf27d0ca9  call 0x000072ACF26BDD50
000072acf27d0cae  jmp 0x000072ACF27D0B57
000072acf27d0cb3  call 0x000072ACF26BCC20
000072acf27d0cb8  jmp 0x000072ACF27D0B6B
000072acf27d0cbd  call 0x000072ACF26C3EA0
000072acf27d0cc2  jmp 0x000072ACF27D0B83
000072acf27d0cc7  call 0x000072ACF26E1920
000072acf27d0ccc  jmp 0x000072ACF27D0B8E
000072acf27d0cd1  call 0x000072ACF26E26A0
000072acf27d0cd6  jmp 0x000072ACF27D0B9D
000072acf27d0cdb  call 0x000072ACF26E1430
000072acf27d0ce0  jmp 0x000072ACF27D0BA6
000072acf27d0ce5  call 0x000072ACF26E06B0
000072acf27d0cea  jmp 0x000072ACF27D0BB1
000072acf27d0cef  call 0x000072ACF26DF440
000072acf27d0cf4  jmp 0x000072ACF27D0BBC
000072acf27d0cf9  call 0x000072ACF26E0300
000072acf27d0cfe  jmp 0x000072ACF27D0BC8
000072acf27d0d03  call 0x000072ACF26DF090
000072acf27d0d08  jmp 0x000072ACF27D0BD4
000072acf27d0d0d  call 0x000072ACF26E1430
000072acf27d0d12  jmp 0x000072ACF27D0BFD
000072acf27d0d17  call 0x000072ACF26E01C0
000072acf27d0d1c  jmp 0x000072ACF27D0C06
000072acf27d0d21  call 0x000072ACF26E2BA0
000072acf27d0d26  jmp 0x000072ACF27D0C1D
000072acf27d0d2b  call 0x000072ACF26E2BA0
000072acf27d0d30  jmp 0x000072ACF27D0C2D
000072acf27d0d35  call 0x000072ACF26E2BA0
000072acf27d0d3a  jmp 0x000072ACF27D0C60
000072acf27d0d3f  call 0x000072ACF26E2BA0
000072acf27d0d44  jmp 0x000072ACF27D0C70
000072acf27d0d49  int3
000072acf27d0d4a  nop [rax+rax*1], ax
000072acf27d0d50  mov qword ptr [r15+0x100], 0x04
000072acf27d0d5b  mov esi, 0x00
000072acf27d0d60  mov edx, 0x09
000072acf27d0d65  mov rdi, 0x7FFD61794740
000072acf27d0d6f  mov rax, 0x5CC7E3D02970
000072acf27d0d79  call rax
000072acf27d0d7b  cmp dword ptr [r15+0x318], 0x00
000072acf27d0d83  jnz 0x000072ACF25FE110
000072acf27d0d89  jmp 0x000072ACF25FE0A0
000072acf27d0d8e  int3
000072acf27d0d8f  int3
