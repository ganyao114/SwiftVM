00007eff8a7ce69b  nop [rax+rax*1], eax
00007eff8a7ce6a0  mov rax, [r15+0xF8]
00007eff8a7ce6a7  lea r14, [rax-0xA0]
00007eff8a7ce6ae  mov [r15+0xF8], r14
00007eff8a7ce6b5  lea rax, [r14+0x90]
00007eff8a7ce6bc  mov r12, [r15+0xA0]
00007eff8a7ce6c3  mov r11, [r15+0x98]
00007eff8a7ce6ca  mov [r13+rax*1], r12
00007eff8a7ce6cf  lea rax, [r14+0x98]
00007eff8a7ce6d6  mov [r13+rax*1], r11
00007eff8a7ce6db  mov eax, 0x420670
00007eff8a7ce6e0  movups xmm1, [r13+rax*1]
00007eff8a7ce6e6  mov eax, 0x420610
00007eff8a7ce6eb  movups xmm15, [r13+rax*1]
00007eff8a7ce6f1  mov eax, 0x420690
00007eff8a7ce6f6  movups xmm14, [r13+rax*1]
00007eff8a7ce6fc  mov eax, 0x420630
00007eff8a7ce701  movups xmm13, [r13+rax*1]
00007eff8a7ce707  mov qword ptr [r15+0x98], 0x4308A0
00007eff8a7ce712  mov eax, 0x4206A0
00007eff8a7ce717  movups xmm12, [r13+rax*1]
00007eff8a7ce71d  mov eax, 0x4308A0
00007eff8a7ce722  movups [r13+rax*1], xmm1
00007eff8a7ce728  mov eax, 0x4308B0
00007eff8a7ce72d  movups [r13+rax*1], xmm15
00007eff8a7ce733  mov eax, 0x4308C0
00007eff8a7ce738  movups [r13+rax*1], xmm14
00007eff8a7ce73e  mov eax, 0x4308D0
00007eff8a7ce743  movups [r13+rax*1], xmm13
00007eff8a7ce749  mov eax, 0x420600
00007eff8a7ce74e  movups xmm14, [r13+rax*1]
00007eff8a7ce754  mov eax, 0x4205F0
00007eff8a7ce759  movups xmm13, [r13+rax*1]
00007eff8a7ce75f  mov eax, 0x4309A0
00007eff8a7ce764  movups [r13+rax*1], xmm1
00007eff8a7ce76a  mov eax, 0x4309B0
00007eff8a7ce76f  movups [r13+rax*1], xmm15
00007eff8a7ce775  mov eax, 0x4308E0
00007eff8a7ce77a  movups [r13+rax*1], xmm12
00007eff8a7ce780  mov eax, 0x4308F0
00007eff8a7ce785  movups [r13+rax*1], xmm14
00007eff8a7ce78b  mov eax, 0x4205E0
00007eff8a7ce790  movups xmm1, [r13+rax*1]
00007eff8a7ce796  mov eax, 0x420640
00007eff8a7ce79b  movups xmm15, [r13+rax*1]
00007eff8a7ce7a1  mov eax, 0x430900
00007eff8a7ce7a6  movups [r13+rax*1], xmm13
00007eff8a7ce7ac  mov eax, 0x430910
00007eff8a7ce7b1  movups [r13+rax*1], xmm1
00007eff8a7ce7b7  mov eax, 0x420650
00007eff8a7ce7bc  movups xmm1, [r13+rax*1]
00007eff8a7ce7c2  mov eax, 0x420620
00007eff8a7ce7c7  movups xmm14, [r13+rax*1]
00007eff8a7ce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
00007eff8a7ce7d5  mov eax, 0x430920
00007eff8a7ce7da  movups [r13+rax*1], xmm15
00007eff8a7ce7e0  mov eax, 0x430930
00007eff8a7ce7e5  movups [r13+rax*1], xmm1
00007eff8a7ce7eb  mov eax, 0x4206C0
00007eff8a7ce7f0  movups xmm1, [r13+rax*1]
00007eff8a7ce7f6  mov eax, 0x4206D0
00007eff8a7ce7fb  movups xmm15, [r13+rax*1]
00007eff8a7ce801  movaps [r15+0x150], xmm15
00007eff8a7ce809  mov qword ptr [r15+0xA0], 0x3E8
00007eff8a7ce814  mov eax, 0x430940
00007eff8a7ce819  movups [r13+rax*1], xmm14
00007eff8a7ce81f  mov eax, 0x430950
00007eff8a7ce824  movups [r13+rax*1], xmm1
00007eff8a7ce82a  mov eax, 0x4206B0
00007eff8a7ce82f  movups xmm1, [r13+rax*1]
00007eff8a7ce835  mov eax, 0x420660
00007eff8a7ce83a  movups xmm14, [r13+rax*1]
00007eff8a7ce840  movaps [r15+0x140], xmm14
00007eff8a7ce848  lea rax, [r14+0x80]
00007eff8a7ce84f  mov r12, [r15+0xF0]
00007eff8a7ce856  mov [r13+rax*1], r12
00007eff8a7ce85b  mov eax, 0x430960
00007eff8a7ce860  movups [r13+rax*1], xmm15
00007eff8a7ce866  mov eax, 0x430970
00007eff8a7ce86b  movups [r13+rax*1], xmm1
00007eff8a7ce871  mov eax, 0x420680
00007eff8a7ce876  movups xmm1, [r13+rax*1]
00007eff8a7ce87c  mov eax, 0x4206E0
00007eff8a7ce881  mov r12, [r13+rax*1]
00007eff8a7ce886  movq xmm15, r12
00007eff8a7ce88b  mov qword ptr [r15+0x40], 0x4206E8
00007eff8a7ce893  mov eax, 0x430980
00007eff8a7ce898  movups [r13+rax*1], xmm14
00007eff8a7ce89e  mov eax, 0x430990
00007eff8a7ce8a3  movups [r13+rax*1], xmm1
00007eff8a7ce8a9  mov eax, 0x420748
00007eff8a7ce8ae  movups xmm1, [r13+rax*1]
00007eff8a7ce8b4  movq rax, xmm15
00007eff8a7ce8b9  mov r12d, 0x4309C0
00007eff8a7ce8bf  mov [r13+r12*1], rax
00007eff8a7ce8c4  mov eax, 0x420728
00007eff8a7ce8c9  movups xmm15, [r13+rax*1]
00007eff8a7ce8cf  mov eax, 0x420738
00007eff8a7ce8d4  movups xmm14, [r13+rax*1]
00007eff8a7ce8da  lea rax, [r14+0x60]
00007eff8a7ce8de  movups [r13+rax*1], xmm1
00007eff8a7ce8e4  mov eax, 0x4309C8
00007eff8a7ce8e9  mov r12d, 0x421DF8D3
00007eff8a7ce8ef  mov [r13+rax*1], r12d
00007eff8a7ce8f4  lea rax, [r14+0x40]
00007eff8a7ce8f8  movups [r13+rax*1], xmm15
00007eff8a7ce8fe  lea rax, [r14+0x50]
00007eff8a7ce902  movups [r13+rax*1], xmm14
00007eff8a7ce908  mov eax, 0x4206E8
00007eff8a7ce90d  movups xmm1, [r13+rax*1]
00007eff8a7ce913  mov eax, 0x4206F8
00007eff8a7ce918  movups xmm15, [r13+rax*1]
00007eff8a7ce91e  movaps [r15+0x120], xmm15
00007eff8a7ce926  movups [r13+r14*1], xmm1
00007eff8a7ce92c  lea rax, [r14+0x10]
00007eff8a7ce930  movups [r13+rax*1], xmm15
00007eff8a7ce936  mov eax, 0x420708
00007eff8a7ce93b  movups xmm1, [r13+rax*1]
00007eff8a7ce941  mov eax, 0x420718
00007eff8a7ce946  movups xmm15, [r13+rax*1]
00007eff8a7ce94c  movaps [r15+0x110], xmm1
00007eff8a7ce954  movaps [r15+0x130], xmm15
00007eff8a7ce95c  lea rax, [r14+0x20]
00007eff8a7ce960  movups [r13+rax*1], xmm1
00007eff8a7ce966  lea rax, [r14+0x30]
00007eff8a7ce96a  movups [r13+rax*1], xmm15
00007eff8a7ce970  mov [r15], r14
00007eff8a7ce973  mov qword ptr [r15+0x08], 0x4308A0
00007eff8a7ce97b  mov qword ptr [r15+0x10], 0x12C
00007eff8a7ce983  mov qword ptr [r15+0xF0], 0x410274
00007eff8a7ce98e  mov r14d, [r15+0x320]
00007eff8a7ce995  mov eax, 0x410274
00007eff8a7ce99a  mov rcx, 0x7EFF8A7D0670
00007eff8a7ce9a4  mov [r15+r14*8+0x328], rax
00007eff8a7ce9ac  mov [r15+r14*8+0x368], rcx
00007eff8a7ce9b4  add r14d, 0x01
00007eff8a7ce9b8  and r14d, 0x07
00007eff8a7ce9bc  mov [r15+0x320], r14d
00007eff8a7ce9c3  cmp dword ptr [r15+0x318], 0x00
00007eff8a7ce9cb  jz 0x00007EFF8A7CEC20
00007eff8a7ce9d1  nop [rax+rax*1], ax
00007eff8a7ce9da  nop [rax+rax*1], eax
00007eff8a7ce9e2  mov eax, 0x410338
00007eff8a7ce9e7  mov [r15+0x100], rax
00007eff8a7ce9ee  jmp 0x00007EFF8A5FE110
00007eff8a7ce9f3  int3
00007eff8a7ce9f4  call 0x00007EFF8A60BC20
00007eff8a7ce9f9  jmp 0x00007EFF8A7CE6CF
00007eff8a7ce9fe  call 0x00007EFF8A60A9A0
00007eff8a7cea03  jmp 0x00007EFF8A7CE6DB
00007eff8a7cea08  call 0x00007EFF8A5FF430
00007eff8a7cea0d  jmp 0x00007EFF8A7CE6E6
00007eff8a7cea12  call 0x00007EFF8A60E760
00007eff8a7cea17  jmp 0x00007EFF8A7CE6F1
00007eff8a7cea1c  call 0x00007EFF8A60D4E0
00007eff8a7cea21  jmp 0x00007EFF8A7CE6FC
00007eff8a7cea26  call 0x00007EFF8A60C260
00007eff8a7cea2b  jmp 0x00007EFF8A7CE707
00007eff8a7cea30  call 0x00007EFF8A60AFE0
00007eff8a7cea35  jmp 0x00007EFF8A7CE71D
00007eff8a7cea3a  call 0x00007EFF8A5FF540
00007eff8a7cea3f  jmp 0x00007EFF8A7CE728
00007eff8a7cea44  call 0x00007EFF8A60E880
00007eff8a7cea49  jmp 0x00007EFF8A7CE733
00007eff8a7cea4e  call 0x00007EFF8A60D600
00007eff8a7cea53  jmp 0x00007EFF8A7CE73E
00007eff8a7cea58  call 0x00007EFF8A60C380
00007eff8a7cea5d  jmp 0x00007EFF8A7CE749
00007eff8a7cea62  call 0x00007EFF8A60D4E0
00007eff8a7cea67  jmp 0x00007EFF8A7CE754
00007eff8a7cea6c  call 0x00007EFF8A60C260
00007eff8a7cea71  jmp 0x00007EFF8A7CE75F
00007eff8a7cea76  call 0x00007EFF8A5FF540
00007eff8a7cea7b  jmp 0x00007EFF8A7CE76A
00007eff8a7cea80  call 0x00007EFF8A60E880
00007eff8a7cea85  jmp 0x00007EFF8A7CE775
00007eff8a7cea8a  call 0x00007EFF8A60B100
00007eff8a7cea8f  jmp 0x00007EFF8A7CE780
00007eff8a7cea94  call 0x00007EFF8A60D600
00007eff8a7cea99  jmp 0x00007EFF8A7CE78B
00007eff8a7cea9e  call 0x00007EFF8A5FF430
00007eff8a7ceaa3  jmp 0x00007EFF8A7CE796
00007eff8a7ceaa8  call 0x00007EFF8A60E760
00007eff8a7ceaad  jmp 0x00007EFF8A7CE7A1
00007eff8a7ceab2  call 0x00007EFF8A60C380
00007eff8a7ceab7  jmp 0x00007EFF8A7CE7AC
00007eff8a7ceabc  call 0x00007EFF8A5FF540
00007eff8a7ceac1  jmp 0x00007EFF8A7CE7B7
00007eff8a7ceac6  call 0x00007EFF8A5FF430
00007eff8a7ceacb  jmp 0x00007EFF8A7CE7C2
00007eff8a7cead0  call 0x00007EFF8A60D4E0
00007eff8a7cead5  jmp 0x00007EFF8A7CE7CD
00007eff8a7ceada  call 0x00007EFF8A60E880
00007eff8a7ceadf  jmp 0x00007EFF8A7CE7E0
00007eff8a7ceae4  call 0x00007EFF8A5FF540
00007eff8a7ceae9  jmp 0x00007EFF8A7CE7EB
00007eff8a7ceaee  call 0x00007EFF8A5FF430
00007eff8a7ceaf3  jmp 0x00007EFF8A7CE7F6
00007eff8a7ceaf8  call 0x00007EFF8A60E760
00007eff8a7ceafd  jmp 0x00007EFF8A7CE801
00007eff8a7ceb02  call 0x00007EFF8A60D600
00007eff8a7ceb07  jmp 0x00007EFF8A7CE81F
00007eff8a7ceb0c  call 0x00007EFF8A5FF540
00007eff8a7ceb11  jmp 0x00007EFF8A7CE82A
00007eff8a7ceb16  call 0x00007EFF8A5FF430
00007eff8a7ceb1b  jmp 0x00007EFF8A7CE835
00007eff8a7ceb20  call 0x00007EFF8A60D4E0
00007eff8a7ceb25  jmp 0x00007EFF8A7CE840
00007eff8a7ceb2a  call 0x00007EFF8A60BC20
00007eff8a7ceb2f  jmp 0x00007EFF8A7CE85B
00007eff8a7ceb34  call 0x00007EFF8A60E880
00007eff8a7ceb39  jmp 0x00007EFF8A7CE866
00007eff8a7ceb3e  call 0x00007EFF8A5FF540
00007eff8a7ceb43  jmp 0x00007EFF8A7CE871
00007eff8a7ceb48  call 0x00007EFF8A5FF430
00007eff8a7ceb4d  jmp 0x00007EFF8A7CE87C
00007eff8a7ceb52  call 0x00007EFF8A60B720
00007eff8a7ceb57  jmp 0x00007EFF8A7CE886
00007eff8a7ceb5c  call 0x00007EFF8A60D600
00007eff8a7ceb61  jmp 0x00007EFF8A7CE89E
00007eff8a7ceb66  call 0x00007EFF8A5FF540
00007eff8a7ceb6b  jmp 0x00007EFF8A7CE8A9
00007eff8a7ceb70  call 0x00007EFF8A5FF430
00007eff8a7ceb75  jmp 0x00007EFF8A7CE8B4
00007eff8a7ceb7a  call 0x00007EFF8A6B4CB0
00007eff8a7ceb7f  jmp 0x00007EFF8A7CE8C4
00007eff8a7ceb84  call 0x00007EFF8A60E760
00007eff8a7ceb89  jmp 0x00007EFF8A7CE8CF
00007eff8a7ceb8e  call 0x00007EFF8A60D4E0
00007eff8a7ceb93  jmp 0x00007EFF8A7CE8DA
00007eff8a7ceb98  call 0x00007EFF8A5FF540
00007eff8a7ceb9d  jmp 0x00007EFF8A7CE8E4
00007eff8a7ceba2  call 0x00007EFF8A60BAE0
00007eff8a7ceba7  jmp 0x00007EFF8A7CE8F4
00007eff8a7cebac  call 0x00007EFF8A60E880
00007eff8a7cebb1  jmp 0x00007EFF8A7CE8FE
00007eff8a7cebb6  call 0x00007EFF8A60D600
00007eff8a7cebbb  jmp 0x00007EFF8A7CE908
00007eff8a7cebc0  call 0x00007EFF8A5FF430
00007eff8a7cebc5  jmp 0x00007EFF8A7CE913
00007eff8a7cebca  call 0x00007EFF8A60E760
00007eff8a7cebcf  jmp 0x00007EFF8A7CE91E
00007eff8a7cebd4  call 0x00007EFF8A6D6600
00007eff8a7cebd9  jmp 0x00007EFF8A7CE92C
00007eff8a7cebde  call 0x00007EFF8A60E880
00007eff8a7cebe3  jmp 0x00007EFF8A7CE936
00007eff8a7cebe8  call 0x00007EFF8A5FF430
00007eff8a7cebed  jmp 0x00007EFF8A7CE941
00007eff8a7cebf2  call 0x00007EFF8A60E760
00007eff8a7cebf7  jmp 0x00007EFF8A7CE94C
00007eff8a7cebfc  call 0x00007EFF8A5FF540
00007eff8a7cec01  jmp 0x00007EFF8A7CE966
00007eff8a7cec06  call 0x00007EFF8A60E880
00007eff8a7cec0b  jmp 0x00007EFF8A7CE970
00007eff8a7cec10  int3
00007eff8a7cec11  nop [rax+rax*1], ax
00007eff8a7cec1a  nop [rax+rax*1], ax
00007eff8a7cec20  mov rax, [r15]
00007eff8a7cec23  lea r14, [rax+0x20]
00007eff8a7cec27  mov r12, [r13+r14*1]
00007eff8a7cec2c  mov r14, [r15+0x10]
00007eff8a7cec30  lea r11, [r12+r14*1]
00007eff8a7cec34  mov [r15+0x40], r11
00007eff8a7cec38  lea r12, [rax+0x20]
00007eff8a7cec3c  mov [r13+r12*1], r11
00007eff8a7cec41  test r14, r14
00007eff8a7cec44  setz r14b
00007eff8a7cec48  movzx r14, r14b
00007eff8a7cec4c  mov [rsp+0x414], r14b
00007eff8a7cec54  cmp byte ptr [rsp+0x414], 0x00
00007eff8a7cec5c  jz 0x00007EFF8A7CEC8E
00007eff8a7cec5e  cmp dword ptr [r15+0x318], 0x00
00007eff8a7cec66  mov eax, 0x4105B0
00007eff8a7cec6b  mov [r15+0x100], rax
00007eff8a7cec72  jz 0x00007EFF8A5FE0A0
00007eff8a7cec78  nop [rax+rax*1], eax
00007eff8a7cec7d  mov eax, 0x4105B0
00007eff8a7cec82  mov [r15+0x100], rax
00007eff8a7cec89  jmp 0x00007EFF8A5FE110
00007eff8a7cec8e  cmp dword ptr [r15+0x318], 0x00
00007eff8a7cec96  jz 0x00007EFF8A7CECE0
00007eff8a7cec9c  nop [rax+rax*1], ax
00007eff8a7ceca5  nop [rax+rax*1], eax
00007eff8a7cecad  mov eax, 0x410348
00007eff8a7cecb2  mov [r15+0x100], rax
00007eff8a7cecb9  jmp 0x00007EFF8A5FE110
00007eff8a7cecbe  int3
00007eff8a7cecbf  call 0x00007EFF8A6E27E0
00007eff8a7cecc4  jmp 0x00007EFF8A7CEC2C
00007eff8a7cecc9  call 0x00007EFF8A6C0860
00007eff8a7cecce  jmp 0x00007EFF8A7CEC41
00007eff8a7cecd3  int3
00007eff8a7cecd4  nop [rax+rax*1], ax
00007eff8a7cecdd  nop [rax], eax
00007eff8a7cece0  mov rax, [r15+0xF8]
00007eff8a7cece7  lea r14, [rax-0x150]
00007eff8a7cecee  mov [r15+0xF8], r14
00007eff8a7cecf5  mov rax, [r15]
00007eff8a7cecf8  lea r12, [rax+0x68]
00007eff8a7cecfc  mov r11, [r13+r12*1]
00007eff8a7ced01  mov [r15+0x88], r11
00007eff8a7ced08  lea r12, [rax+0x28]
00007eff8a7ced0c  mov [r15+0x40], r12
00007eff8a7ced10  mov [r15+0x48], r14
00007eff8a7ced14  mov qword ptr [r15+0x50], 0x420758
00007eff8a7ced1c  lea rax, [r14+0x100]
00007eff8a7ced23  mov r12, [r15+0xE8]
00007eff8a7ced2a  mov r11, [r15+0xD8]
00007eff8a7ced31  mov [r13+rax*1], r12
00007eff8a7ced36  lea rax, [r14+0x108]
00007eff8a7ced3d  mov [r13+rax*1], r11
00007eff8a7ced42  lea rax, [r14+0x110]
00007eff8a7ced49  mov r12, [r15+0xD0]
00007eff8a7ced50  mov r11, [r15+0xC8]
00007eff8a7ced57  mov [r13+rax*1], r12
00007eff8a7ced5c  lea rax, [r14+0x118]
00007eff8a7ced63  mov [r13+rax*1], r11
00007eff8a7ced68  lea rax, [r14+0x120]
00007eff8a7ced6f  mov r12, [r15+0xC0]
00007eff8a7ced76  mov r11, [r15+0xB8]
00007eff8a7ced7d  mov [r13+rax*1], r12
00007eff8a7ced82  lea rax, [r14+0x128]
00007eff8a7ced89  mov [r13+rax*1], r11
00007eff8a7ced8e  lea rax, [r14+0x130]
00007eff8a7ced95  mov r12, [r15+0xB0]
00007eff8a7ced9c  mov r11, [r15+0xA8]
00007eff8a7ceda3  mov [r13+rax*1], r12
00007eff8a7ceda8  lea rax, [r14+0x138]
00007eff8a7cedaf  mov [r13+rax*1], r11
00007eff8a7cedb4  lea rax, [r14+0x140]
00007eff8a7cedbb  mov r12, [r15+0xA0]
00007eff8a7cedc2  mov r11, [r15+0x98]
00007eff8a7cedc9  mov [r13+rax*1], r12
00007eff8a7cedce  lea rax, [r14+0x148]
00007eff8a7cedd5  mov [r13+rax*1], r11
00007eff8a7cedda  cmp dword ptr [r15+0x318], 0x00
00007eff8a7cede2  jz 0x00007EFF8A7CEE80
00007eff8a7cede8  nop [rax+rax*1], ax
00007eff8a7cedf1  nop [rax+rax*1], eax
00007eff8a7cedf9  mov eax, 0x410380
00007eff8a7cedfe  mov [r15+0x100], rax
00007eff8a7cee05  jmp 0x00007EFF8A5FE110
00007eff8a7cee0a  int3
00007eff8a7cee0b  call 0x00007EFF8A6C0370
00007eff8a7cee10  jmp 0x00007EFF8A7CED01
00007eff8a7cee15  call 0x00007EFF8A60BC20
00007eff8a7cee1a  jmp 0x00007EFF8A7CED36
00007eff8a7cee1f  call 0x00007EFF8A60A9A0
00007eff8a7cee24  jmp 0x00007EFF8A7CED42
00007eff8a7cee29  call 0x00007EFF8A60BC20
00007eff8a7cee2e  jmp 0x00007EFF8A7CED5C
00007eff8a7cee33  call 0x00007EFF8A60A9A0
00007eff8a7cee38  jmp 0x00007EFF8A7CED68
00007eff8a7cee3d  call 0x00007EFF8A60BC20
00007eff8a7cee42  jmp 0x00007EFF8A7CED82
00007eff8a7cee47  call 0x00007EFF8A60A9A0
00007eff8a7cee4c  jmp 0x00007EFF8A7CED8E
00007eff8a7cee51  call 0x00007EFF8A60BC20
00007eff8a7cee56  jmp 0x00007EFF8A7CEDA8
00007eff8a7cee5b  call 0x00007EFF8A60A9A0
00007eff8a7cee60  jmp 0x00007EFF8A7CEDB4
00007eff8a7cee65  call 0x00007EFF8A60BC20
00007eff8a7cee6a  jmp 0x00007EFF8A7CEDCE
00007eff8a7cee6f  call 0x00007EFF8A60A9A0
00007eff8a7cee74  jmp 0x00007EFF8A7CEDDA
00007eff8a7cee79  int3
00007eff8a7cee7a  nop [rax+rax*1], ax
00007eff8a7cee80  mov rax, [r15+0x08]
00007eff8a7cee84  movzx r14d, byte ptr [r13+rax*1]
00007eff8a7cee8a  movzx r14d, r14b
00007eff8a7cee8e  mov [rsp+0x10], r14d
00007eff8a7cee93  mov r14d, r14d
00007eff8a7cee96  mov [r15+0x58], r14
00007eff8a7cee9a  lea r14, [rax+0x01]
00007eff8a7cee9e  mov [r15+0x08], r14
00007eff8a7ceea2  mov rax, [r15+0x88]
00007eff8a7ceea9  lea r14, [rax+0x01]
00007eff8a7ceead  mov r12, [r15]
00007eff8a7ceeb0  lea r11, [r12+0x68]
00007eff8a7ceeb5  mov [r13+r11*1], r14
00007eff8a7ceeba  lea r14, [r12+rax*1]
00007eff8a7ceebe  mov [r15+0x60], r14
00007eff8a7ceec2  lea rax, [r14+0x28]
00007eff8a7ceec6  mov r11d, [rsp+0x10]
00007eff8a7ceecb  movzx r14d, r11b
00007eff8a7ceecf  mov [r13+rax*1], r14b
00007eff8a7ceed4  lea rax, [r12+0x68]
00007eff8a7ceed9  mov r14, [r13+rax*1]
00007eff8a7ceede  mov [r15+0x88], r14
00007eff8a7ceee5  xor eax, eax
00007eff8a7ceee7  mov r12d, 0x40
00007eff8a7ceeed  cmp r14, r12
00007eff8a7ceef0  cmc
00007eff8a7ceef1  lahf
00007eff8a7ceef2  seto al
00007eff8a7ceef5  mov [r15+0x108], eax
00007eff8a7ceefc  mov eax, [r15+0x108]
00007eff8a7cef03  sahf
00007eff8a7cef04  jnz 0x00007EFF8A7CEF36
00007eff8a7cef06  cmp dword ptr [r15+0x318], 0x00
00007eff8a7cef0e  jz 0x00007EFF8A7CF020
00007eff8a7cef14  nop [rax+rax*1], ax
00007eff8a7cef1d  nop [rax+rax*1], eax
00007eff8a7cef25  mov eax, 0x4103A0
00007eff8a7cef2a  mov [r15+0x100], rax
00007eff8a7cef31  jmp 0x00007EFF8A5FE110
00007eff8a7cef36  cmp dword ptr [r15+0x318], 0x00
00007eff8a7cef3e  jz 0x00007EFF8A7CEF90
00007eff8a7cef44  nop [rax+rax*1], ax
00007eff8a7cef4d  nop [rax+rax*1], eax
00007eff8a7cef55  mov eax, 0x410378
00007eff8a7cef5a  mov [r15+0x100], rax
00007eff8a7cef61  jmp 0x00007EFF8A5FE110
00007eff8a7cef66  int3
00007eff8a7cef67  call 0x00007EFF8A60D860
00007eff8a7cef6c  jmp 0x00007EFF8A7CEE8A
00007eff8a7cef71  call 0x00007EFF8A6B36E0
00007eff8a7cef76  jmp 0x00007EFF8A7CEEBA
00007eff8a7cef7b  call 0x00007EFF8A60DD60
00007eff8a7cef80  jmp 0x00007EFF8A7CEED4
00007eff8a7cef85  call 0x00007EFF8A60DC20
00007eff8a7cef8a  jmp 0x00007EFF8A7CEEDE
00007eff8a7cef8f  int3
00007eff8a7cef90  mov rax, [r15+0x10]
00007eff8a7cef94  lea r14, [rax-0x01]
00007eff8a7cef98  mov [r15+0x10], r14
00007eff8a7cef9c  test r14, r14
00007eff8a7cef9f  setz r14b
00007eff8a7cefa3  movzx r14, r14b
00007eff8a7cefa7  mov [rsp+0x414], r14b
00007eff8a7cefaf  cmp byte ptr [rsp+0x414], 0x00
00007eff8a7cefb7  jz 0x00007EFF8A7CEFE9
00007eff8a7cefb9  cmp dword ptr [r15+0x318], 0x00
00007eff8a7cefc1  jz 0x00007EFF8A7D0520
00007eff8a7cefc7  nop [rax+rax*1], ax
00007eff8a7cefd0  nop [rax+rax*1], eax
00007eff8a7cefd8  mov eax, 0x410598
00007eff8a7cefdd  mov [r15+0x100], rax
00007eff8a7cefe4  jmp 0x00007EFF8A5FE110
00007eff8a7cefe9  cmp dword ptr [r15+0x318], 0x00
00007eff8a7ceff1  jz 0x00007EFF8A7CEE80
00007eff8a7ceff7  nop [rax+rax*1], ax
00007eff8a7cf000  nop [rax+rax*1], eax
00007eff8a7cf008  mov eax, 0x410380
00007eff8a7cf00d  mov [r15+0x100], rax
00007eff8a7cf014  jmp 0x00007EFF8A5FE110
00007eff8a7cf019  int3
00007eff8a7cf01a  int3
00007eff8a7cf01b  nop [rax+rax*1], eax
00007eff8a7cf020  mov rax, [r15+0x40]
00007eff8a7cf024  movzx r14d, byte ptr [r13+rax*1]
00007eff8a7cf02a  movaps xmm1, [r15+0x110]
00007eff8a7cf032  pinsrb xmm1, r14d, 0x00
00007eff8a7cf039  lea r14, [rax+0x01]
00007eff8a7cf03d  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf043  movaps xmm15, [r15+0x120]
00007eff8a7cf04b  pinsrb xmm15, r12d, 0x00
00007eff8a7cf052  lea r14, [rax+0x02]
00007eff8a7cf056  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf05c  movaps xmm14, [r15+0x130]
00007eff8a7cf064  pinsrb xmm14, r12d, 0x00
00007eff8a7cf06b  lea r14, [rax+0x03]
00007eff8a7cf06f  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf075  movaps xmm13, [r15+0x140]
00007eff8a7cf07d  pinsrb xmm13, r12d, 0x00
00007eff8a7cf084  lea r14, [rax+0x04]
00007eff8a7cf088  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf08e  pinsrb xmm1, r12d, 0x01
00007eff8a7cf095  lea r14, [rax+0x05]
00007eff8a7cf099  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf09f  pinsrb xmm15, r12d, 0x01
00007eff8a7cf0a6  lea r14, [rax+0x06]
00007eff8a7cf0aa  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf0b0  pinsrb xmm14, r12d, 0x01
00007eff8a7cf0b7  lea r14, [rax+0x07]
00007eff8a7cf0bb  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf0c1  pinsrb xmm13, r12d, 0x01
00007eff8a7cf0c8  lea r14, [rax+0x08]
00007eff8a7cf0cc  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf0d2  pinsrb xmm1, r12d, 0x02
00007eff8a7cf0d9  lea r14, [rax+0x09]
00007eff8a7cf0dd  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf0e3  pinsrb xmm15, r12d, 0x02
00007eff8a7cf0ea  lea r14, [rax+0x0A]
00007eff8a7cf0ee  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf0f4  pinsrb xmm14, r12d, 0x02
00007eff8a7cf0fb  lea r14, [rax+0x0B]
00007eff8a7cf0ff  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf105  pinsrb xmm13, r12d, 0x02
00007eff8a7cf10c  lea r14, [rax+0x0C]
00007eff8a7cf110  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf116  pinsrb xmm1, r12d, 0x03
00007eff8a7cf11d  lea r14, [rax+0x0D]
00007eff8a7cf121  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf127  pinsrb xmm15, r12d, 0x03
00007eff8a7cf12e  lea r14, [rax+0x0E]
00007eff8a7cf132  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf138  pinsrb xmm14, r12d, 0x03
00007eff8a7cf13f  lea r14, [rax+0x0F]
00007eff8a7cf143  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf149  pinsrb xmm13, r12d, 0x03
00007eff8a7cf150  lea r14, [rax+0x10]
00007eff8a7cf154  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf15a  pinsrb xmm1, r12d, 0x04
00007eff8a7cf161  lea r14, [rax+0x11]
00007eff8a7cf165  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf16b  pinsrb xmm15, r12d, 0x04
00007eff8a7cf172  lea r14, [rax+0x12]
00007eff8a7cf176  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf17c  pinsrb xmm14, r12d, 0x04
00007eff8a7cf183  lea r14, [rax+0x13]
00007eff8a7cf187  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf18d  pinsrb xmm13, r12d, 0x04
00007eff8a7cf194  lea r14, [rax+0x14]
00007eff8a7cf198  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf19e  pinsrb xmm1, r12d, 0x05
00007eff8a7cf1a5  lea r14, [rax+0x15]
00007eff8a7cf1a9  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf1af  pinsrb xmm15, r12d, 0x05
00007eff8a7cf1b6  lea r14, [rax+0x16]
00007eff8a7cf1ba  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf1c0  pinsrb xmm14, r12d, 0x05
00007eff8a7cf1c7  lea r14, [rax+0x17]
00007eff8a7cf1cb  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf1d1  pinsrb xmm13, r12d, 0x05
00007eff8a7cf1d8  lea r14, [rax+0x18]
00007eff8a7cf1dc  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf1e2  pinsrb xmm1, r12d, 0x06
00007eff8a7cf1e9  lea r14, [rax+0x19]
00007eff8a7cf1ed  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf1f3  pinsrb xmm15, r12d, 0x06
00007eff8a7cf1fa  lea r14, [rax+0x1A]
00007eff8a7cf1fe  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf204  pinsrb xmm14, r12d, 0x06
00007eff8a7cf20b  lea r14, [rax+0x1B]
00007eff8a7cf20f  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf215  pinsrb xmm13, r12d, 0x06
00007eff8a7cf21c  lea r14, [rax+0x1C]
00007eff8a7cf220  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf226  pinsrb xmm1, r12d, 0x07
00007eff8a7cf22d  lea r14, [rax+0x1D]
00007eff8a7cf231  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf237  pinsrb xmm15, r12d, 0x07
00007eff8a7cf23e  lea r14, [rax+0x1E]
00007eff8a7cf242  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf248  pinsrb xmm14, r12d, 0x07
00007eff8a7cf24f  lea r14, [rax+0x1F]
00007eff8a7cf253  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf259  pinsrb xmm13, r12d, 0x07
00007eff8a7cf260  lea r14, [rax+0x20]
00007eff8a7cf264  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf26a  pinsrb xmm1, r12d, 0x08
00007eff8a7cf271  lea r14, [rax+0x21]
00007eff8a7cf275  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf27b  pinsrb xmm15, r12d, 0x08
00007eff8a7cf282  lea r14, [rax+0x22]
00007eff8a7cf286  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf28c  pinsrb xmm14, r12d, 0x08
00007eff8a7cf293  lea r14, [rax+0x23]
00007eff8a7cf297  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf29d  pinsrb xmm13, r12d, 0x08
00007eff8a7cf2a4  lea r14, [rax+0x24]
00007eff8a7cf2a8  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf2ae  pinsrb xmm1, r12d, 0x09
00007eff8a7cf2b5  lea r14, [rax+0x25]
00007eff8a7cf2b9  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf2bf  pinsrb xmm15, r12d, 0x09
00007eff8a7cf2c6  lea r14, [rax+0x26]
00007eff8a7cf2ca  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf2d0  pinsrb xmm14, r12d, 0x09
00007eff8a7cf2d7  lea r14, [rax+0x27]
00007eff8a7cf2db  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf2e1  pinsrb xmm13, r12d, 0x09
00007eff8a7cf2e8  lea r14, [rax+0x28]
00007eff8a7cf2ec  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf2f2  pinsrb xmm1, r12d, 0x0A
00007eff8a7cf2f9  lea r14, [rax+0x29]
00007eff8a7cf2fd  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf303  pinsrb xmm15, r12d, 0x0A
00007eff8a7cf30a  lea r14, [rax+0x2A]
00007eff8a7cf30e  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf314  pinsrb xmm14, r12d, 0x0A
00007eff8a7cf31b  lea r14, [rax+0x2B]
00007eff8a7cf31f  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf325  pinsrb xmm13, r12d, 0x0A
00007eff8a7cf32c  lea r14, [rax+0x2C]
00007eff8a7cf330  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf336  pinsrb xmm1, r12d, 0x0B
00007eff8a7cf33d  lea r14, [rax+0x2D]
00007eff8a7cf341  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf347  pinsrb xmm15, r12d, 0x0B
00007eff8a7cf34e  lea r14, [rax+0x2E]
00007eff8a7cf352  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf358  pinsrb xmm14, r12d, 0x0B
00007eff8a7cf35f  lea r14, [rax+0x2F]
00007eff8a7cf363  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf369  pinsrb xmm13, r12d, 0x0B
00007eff8a7cf370  lea r14, [rax+0x30]
00007eff8a7cf374  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf37a  pinsrb xmm1, r12d, 0x0C
00007eff8a7cf381  lea r14, [rax+0x31]
00007eff8a7cf385  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf38b  pinsrb xmm15, r12d, 0x0C
00007eff8a7cf392  lea r14, [rax+0x32]
00007eff8a7cf396  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf39c  pinsrb xmm14, r12d, 0x0C
00007eff8a7cf3a3  lea r14, [rax+0x33]
00007eff8a7cf3a7  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf3ad  pinsrb xmm13, r12d, 0x0C
00007eff8a7cf3b4  lea r14, [rax+0x34]
00007eff8a7cf3b8  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf3be  pinsrb xmm1, r12d, 0x0D
00007eff8a7cf3c5  lea r14, [rax+0x35]
00007eff8a7cf3c9  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf3cf  pinsrb xmm15, r12d, 0x0D
00007eff8a7cf3d6  lea r14, [rax+0x36]
00007eff8a7cf3da  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf3e0  pinsrb xmm14, r12d, 0x0D
00007eff8a7cf3e7  lea r14, [rax+0x37]
00007eff8a7cf3eb  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf3f1  pinsrb xmm13, r12d, 0x0D
00007eff8a7cf3f8  lea r14, [rax+0x38]
00007eff8a7cf3fc  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf402  pinsrb xmm1, r12d, 0x0E
00007eff8a7cf409  lea r14, [rax+0x39]
00007eff8a7cf40d  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf413  pinsrb xmm15, r12d, 0x0E
00007eff8a7cf41a  lea r14, [rax+0x3A]
00007eff8a7cf41e  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf424  pinsrb xmm14, r12d, 0x0E
00007eff8a7cf42b  lea r14, [rax+0x3B]
00007eff8a7cf42f  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf435  pinsrb xmm13, r12d, 0x0E
00007eff8a7cf43c  lea r14, [rax+0x3C]
00007eff8a7cf440  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf446  pinsrb xmm1, r12d, 0x0F
00007eff8a7cf44d  movaps [r15+0x110], xmm1
00007eff8a7cf455  lea r14, [rax+0x3D]
00007eff8a7cf459  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf45f  pinsrb xmm15, r12d, 0x0F
00007eff8a7cf466  movaps [r15+0x120], xmm15
00007eff8a7cf46e  lea r14, [rax+0x3E]
00007eff8a7cf472  movzx r12d, byte ptr [r13+r14*1]
00007eff8a7cf478  pinsrb xmm14, r12d, 0x0F
00007eff8a7cf47f  movaps [r15+0x130], xmm14
00007eff8a7cf487  lea r14, [rax+0x3F]
00007eff8a7cf48b  movzx eax, byte ptr [r13+r14*1]
00007eff8a7cf491  pinsrb xmm13, eax, 0x0F
00007eff8a7cf498  movaps [r15+0x140], xmm13
00007eff8a7cf4a0  movq xmm1, qword ptr [r15+0x120]
00007eff8a7cf4a9  pmovzxbw xmm1, xmm1
00007eff8a7cf4ae  psllw xmm1, 0x00
00007eff8a7cf4b3  movaps [r15+0x150], xmm1
00007eff8a7cf4bb  movq xmm1, qword ptr [r15+0x130]
00007eff8a7cf4c4  pmovzxbw xmm1, xmm1
00007eff8a7cf4c9  psllw xmm1, 0x00
00007eff8a7cf4ce  movaps [r15+0x160], xmm1
00007eff8a7cf4d6  movq xmm1, qword ptr [r15+0x110]
00007eff8a7cf4df  pmovzxbw xmm1, xmm1
00007eff8a7cf4e4  psllw xmm1, 0x00
00007eff8a7cf4e9  movaps [r15+0x170], xmm1
00007eff8a7cf4f1  movaps xmm15, [r15+0x110]
00007eff8a7cf4f9  pextrq rax, xmm15, 0x01
00007eff8a7cf500  movq xmm15, rax
00007eff8a7cf505  pmovzxbw xmm15, xmm15
00007eff8a7cf50b  psllw xmm15, 0x00
00007eff8a7cf511  movaps [r15+0x180], xmm15
00007eff8a7cf519  movaps xmm14, [r15+0x120]
00007eff8a7cf521  pextrq rax, xmm14, 0x01
00007eff8a7cf528  movq xmm14, rax
00007eff8a7cf52d  pmovzxbw xmm14, xmm14
00007eff8a7cf533  psllw xmm14, 0x00
00007eff8a7cf539  movaps [r15+0x210], xmm14
00007eff8a7cf541  movaps xmm13, [r15+0x130]
00007eff8a7cf549  pextrq rax, xmm13, 0x01
00007eff8a7cf550  movq xmm13, rax
00007eff8a7cf555  pmovzxbw xmm13, xmm13
00007eff8a7cf55b  psllw xmm13, 0x00
00007eff8a7cf561  movaps [r15+0x220], xmm13
00007eff8a7cf569  movq xmm12, qword ptr [r15+0x140]
00007eff8a7cf572  pmovzxbw xmm12, xmm12
00007eff8a7cf578  psllw xmm12, 0x00
00007eff8a7cf57e  movaps [r15+0x250], xmm12
00007eff8a7cf586  movaps xmm12, [r15+0x140]
00007eff8a7cf58e  pextrq rax, xmm12, 0x01
00007eff8a7cf595  movq xmm12, rax
00007eff8a7cf59a  pmovzxbw xmm12, xmm12
00007eff8a7cf5a0  psllw xmm12, 0x00
00007eff8a7cf5a6  movaps [r15+0x110], xmm12
00007eff8a7cf5ae  movq xmm11, qword ptr [r15+0x150]
00007eff8a7cf5b7  pmovzxwd xmm11, xmm11
00007eff8a7cf5bd  pslld xmm11, 0x10
00007eff8a7cf5c3  movq xmm10, qword ptr [r15+0x160]
00007eff8a7cf5cc  pmovzxwd xmm10, xmm10
00007eff8a7cf5d2  pslld xmm10, 0x08
00007eff8a7cf5d8  pextrq rax, xmm1, 0x01
00007eff8a7cf5df  movq xmm1, rax
00007eff8a7cf5e4  pmovzxwd xmm1, xmm1
00007eff8a7cf5e9  pslld xmm1, 0x00
00007eff8a7cf5ee  movaps [r15+0x260], xmm1
00007eff8a7cf5f6  pextrq rax, xmm15, 0x01
00007eff8a7cf5fd  movq xmm15, rax
00007eff8a7cf602  pmovzxwd xmm15, xmm15
00007eff8a7cf608  pslld xmm15, 0x00
00007eff8a7cf60e  movaps [r15+0x270], xmm15
00007eff8a7cf616  movq xmm9, qword ptr [r15+0x170]
00007eff8a7cf61f  pmovzxwd xmm9, xmm9
00007eff8a7cf625  pslld xmm9, 0x00
00007eff8a7cf62b  pextrq rax, xmm14, 0x01
00007eff8a7cf632  movq xmm14, rax
00007eff8a7cf637  pmovzxwd xmm14, xmm14
00007eff8a7cf63d  pslld xmm14, 0x10
00007eff8a7cf643  movaps [r15+0x280], xmm14
00007eff8a7cf64b  movq xmm8, qword ptr [r15+0x180]
00007eff8a7cf654  pmovzxwd xmm8, xmm8
00007eff8a7cf65a  pslld xmm8, 0x00
00007eff8a7cf660  movq xmm7, qword ptr [r15+0x210]
00007eff8a7cf669  pmovzxwd xmm7, xmm7
00007eff8a7cf66e  pslld xmm7, 0x10
00007eff8a7cf673  movaps xmm6, [r15+0x150]
00007eff8a7cf67b  pextrq rax, xmm6, 0x01
00007eff8a7cf682  movq xmm6, rax
00007eff8a7cf687  pmovzxwd xmm6, xmm6
00007eff8a7cf68c  pslld xmm6, 0x10
00007eff8a7cf691  por xmm11, xmm10
00007eff8a7cf696  movaps [r15+0x230], xmm11
00007eff8a7cf69e  pextrq rax, xmm13, 0x01
00007eff8a7cf6a5  movq xmm13, rax
00007eff8a7cf6aa  pmovzxwd xmm13, xmm13
00007eff8a7cf6b0  pslld xmm13, 0x08
00007eff8a7cf6b6  movaps [r15+0x240], xmm13
00007eff8a7cf6be  movq xmm10, qword ptr [r15+0x220]
00007eff8a7cf6c7  pmovzxwd xmm10, xmm10
00007eff8a7cf6cd  pslld xmm10, 0x08
00007eff8a7cf6d3  movaps xmm5, [r15+0x160]
00007eff8a7cf6db  pextrq rax, xmm5, 0x01
00007eff8a7cf6e2  movq xmm5, rax
00007eff8a7cf6e7  pmovzxwd xmm5, xmm5
00007eff8a7cf6ec  pslld xmm5, 0x08
00007eff8a7cf6f1  pslld xmm9, 0x18
00007eff8a7cf6f7  pslld xmm15, 0x18
00007eff8a7cf6fd  pslld xmm8, 0x18
00007eff8a7cf703  movq xmm4, qword ptr [r15+0x250]
00007eff8a7cf70c  pmovzxwd xmm4, xmm4
00007eff8a7cf711  pslld xmm4, 0x00
00007eff8a7cf716  por xmm14, xmm13
00007eff8a7cf71b  por xmm7, xmm10
00007eff8a7cf720  movaps [r15+0x210], xmm7
00007eff8a7cf728  pslld xmm1, 0x18
00007eff8a7cf72d  movaps [r15+0x220], xmm1
00007eff8a7cf735  por xmm6, xmm5
00007eff8a7cf739  por xmm11, xmm9
00007eff8a7cf73e  movaps [r15+0x160], xmm11
00007eff8a7cf746  pextrq rax, xmm12, 0x01
00007eff8a7cf74d  movq xmm13, rax
00007eff8a7cf752  pmovzxwd xmm13, xmm13
00007eff8a7cf758  pslld xmm13, 0x00
00007eff8a7cf75e  movaps [r15+0x170], xmm13
00007eff8a7cf766  movq xmm12, qword ptr [r15+0x110]
00007eff8a7cf76f  pmovzxwd xmm12, xmm12
00007eff8a7cf775  pslld xmm12, 0x00
00007eff8a7cf77b  por xmm14, xmm15
00007eff8a7cf780  por xmm7, xmm8
00007eff8a7cf785  movaps xmm15, [r15+0x250]
00007eff8a7cf78d  pextrq rax, xmm15, 0x01
00007eff8a7cf794  movq xmm15, rax
00007eff8a7cf799  pmovzxwd xmm15, xmm15
00007eff8a7cf79f  pslld xmm15, 0x00
00007eff8a7cf7a5  movaps [r15+0x180], xmm15
00007eff8a7cf7ad  por xmm6, xmm1
00007eff8a7cf7b1  movaps [r15+0x150], xmm6
00007eff8a7cf7b9  por xmm11, xmm4
00007eff8a7cf7be  movaps [r15+0x140], xmm11
00007eff8a7cf7c6  por xmm7, xmm12
00007eff8a7cf7cb  movaps [r15+0x110], xmm7
00007eff8a7cf7d3  por xmm14, xmm13
00007eff8a7cf7d8  movaps [r15+0x120], xmm14
00007eff8a7cf7e0  por xmm6, xmm15
00007eff8a7cf7e5  movaps [r15+0x130], xmm6
00007eff8a7cf7ed  mov rax, [r15+0xF8]
00007eff8a7cf7f4  lea r14, [rax+0x20]
00007eff8a7cf7f8  movups [r13+r14*1], xmm7
00007eff8a7cf7fe  lea r14, [rax+0x30]
00007eff8a7cf802  movups [r13+r14*1], xmm14
00007eff8a7cf808  movups [r13+rax*1], xmm11
00007eff8a7cf80e  lea r14, [rax+0x10]
00007eff8a7cf812  movups [r13+r14*1], xmm6
00007eff8a7cf818  mov r14d, [r13+rax*1]
00007eff8a7cf81d  mov rax, [r15+0x48]
00007eff8a7cf821  mov [r15+0x68], rax
00007eff8a7cf825  mov qword ptr [r15+0x58], 0x04
00007eff8a7cf82d  lea r12, [rax+0x04]
00007eff8a7cf831  mov r11d, [r13+r12*1]
00007eff8a7cf836  mov [rsp+0x10], r11d
00007eff8a7cf83b  mov r11d, r11d
00007eff8a7cf83e  mov [r15+0x70], r11
00007eff8a7cf842  lea r12, [rax+0x38]
00007eff8a7cf846  mov r11d, [r13+r12*1]
00007eff8a7cf84b  lea r12, [rax+0x24]
00007eff8a7cf84f  mov r10d, [r13+r12*1]
00007eff8a7cf854  mov [rsp+0x20], r10d
00007eff8a7cf859  mov r10d, r10d
00007eff8a7cf85c  mov [r15+0x90], r10
00007eff8a7cf863  mov [rsp+0x30], rax
00007eff8a7cf868  xor eax, eax
00007eff8a7cf86a  mov r12d, 0x04
00007eff8a7cf870  mov r10d, 0xC0
00007eff8a7cf876  cmp r12, r10
00007eff8a7cf879  cmc
00007eff8a7cf87a  lahf
00007eff8a7cf87b  seto al
00007eff8a7cf87e  mov [r15+0x108], eax
00007eff8a7cf885  mov eax, [rsp+0x10]
00007eff8a7cf889  mov r12d, [rsp+0x10]
00007eff8a7cf88e  shrd eax, r12d, 0x07
00007eff8a7cf893  mov [rsp+0x10], r11d
00007eff8a7cf898  mov r10d, [rsp+0x10]
00007eff8a7cf89d  shrd r11d, r10d, 0x11
00007eff8a7cf8a2  mov r9d, [rsp+0x20]
00007eff8a7cf8a7  lea r8d, [r9d+r14d*1]
00007eff8a7cf8ac  rorx r14d, r12d, 0x12
00007eff8a7cf8b2  xor eax, r14d
00007eff8a7cf8b5  rorx r14d, r10d, 0x13
00007eff8a7cf8bb  xor r11d, r14d
00007eff8a7cf8be  mov [rsp+0x10], r11d
00007eff8a7cf8c3  mov r11d, r11d
00007eff8a7cf8c6  mov [r15+0x88], r11
00007eff8a7cf8cd  mov [rsp+0x20], r12d
00007eff8a7cf8d2  shr r12d, 0x03
00007eff8a7cf8d6  xor eax, r12d
00007eff8a7cf8d9  mov [rsp+0x40], eax
00007eff8a7cf8dd  mov eax, eax
00007eff8a7cf8df  mov [r15+0x80], rax
00007eff8a7cf8e6  shr r10d, 0x0A
00007eff8a7cf8ea  mov eax, [rsp+0x10]
00007eff8a7cf8ee  xor eax, r10d
00007eff8a7cf8f1  mov [rsp+0x10], eax
00007eff8a7cf8f5  mov eax, eax
00007eff8a7cf8f7  mov [r15+0x78], rax
00007eff8a7cf8fb  mov eax, [rsp+0x40]
00007eff8a7cf8ff  lea r14d, [r8d+eax*1]
00007eff8a7cf904  mov eax, [rsp+0x10]
00007eff8a7cf908  lea r12d, [r14d+eax*1]
00007eff8a7cf90d  mov rax, [rsp+0x30]
00007eff8a7cf912  lea r14, [rax+0x40]
00007eff8a7cf916  mov [r13+r14*1], r12d
00007eff8a7cf91b  mov eax, [rsp+0x20]
00007eff8a7cf91f  mov eax, eax
00007eff8a7cf921  mov [r15+0x60], rax
00007eff8a7cf925  mov eax, [r15+0x108]
00007eff8a7cf92c  sahf
00007eff8a7cf92d  jnz 0x00007EFF8A7CF95F
00007eff8a7cf92f  cmp dword ptr [r15+0x318], 0x00
00007eff8a7cf937  jz 0x00007EFF8A7CFE20
00007eff8a7cf93d  nop [rax+rax*1], ax
00007eff8a7cf946  nop [rax+rax*1], eax
00007eff8a7cf94e  mov eax, 0x41049C
00007eff8a7cf953  mov [r15+0x100], rax
00007eff8a7cf95a  jmp 0x00007EFF8A5FE110
00007eff8a7cf95f  cmp dword ptr [r15+0x318], 0x00
00007eff8a7cf967  jz 0x00007EFF8A7CFC70
00007eff8a7cf96d  nop [rax+rax*1], ax
00007eff8a7cf976  nop [rax+rax*1], eax
00007eff8a7cf97e  mov eax, 0x410454
00007eff8a7cf983  mov [r15+0x100], rax
00007eff8a7cf98a  jmp 0x00007EFF8A5FE110
00007eff8a7cf98f  int3
00007eff8a7cf990  call 0x00007EFF8A60D860
00007eff8a7cf995  jmp 0x00007EFF8A7CF02A
00007eff8a7cf99a  call 0x00007EFF8A6E2420
00007eff8a7cf99f  jmp 0x00007EFF8A7CF043
00007eff8a7cf9a4  call 0x00007EFF8A6E2420
00007eff8a7cf9a9  jmp 0x00007EFF8A7CF05C
00007eff8a7cf9ae  call 0x00007EFF8A6E2420
00007eff8a7cf9b3  jmp 0x00007EFF8A7CF075
00007eff8a7cf9b8  call 0x00007EFF8A6E2420
00007eff8a7cf9bd  jmp 0x00007EFF8A7CF08E
00007eff8a7cf9c2  call 0x00007EFF8A6E2420
00007eff8a7cf9c7  jmp 0x00007EFF8A7CF09F
00007eff8a7cf9cc  call 0x00007EFF8A6E2420
00007eff8a7cf9d1  jmp 0x00007EFF8A7CF0B0
00007eff8a7cf9d6  call 0x00007EFF8A6E2420
00007eff8a7cf9db  jmp 0x00007EFF8A7CF0C1
00007eff8a7cf9e0  call 0x00007EFF8A6E2420
00007eff8a7cf9e5  jmp 0x00007EFF8A7CF0D2
00007eff8a7cf9ea  call 0x00007EFF8A6E2420
00007eff8a7cf9ef  jmp 0x00007EFF8A7CF0E3
00007eff8a7cf9f4  call 0x00007EFF8A6E2420
00007eff8a7cf9f9  jmp 0x00007EFF8A7CF0F4
00007eff8a7cf9fe  call 0x00007EFF8A6E2420
00007eff8a7cfa03  jmp 0x00007EFF8A7CF105
00007eff8a7cfa08  call 0x00007EFF8A6E2420
00007eff8a7cfa0d  jmp 0x00007EFF8A7CF116
00007eff8a7cfa12  call 0x00007EFF8A6E2420
00007eff8a7cfa17  jmp 0x00007EFF8A7CF127
00007eff8a7cfa1c  call 0x00007EFF8A6E2420
00007eff8a7cfa21  jmp 0x00007EFF8A7CF138
00007eff8a7cfa26  call 0x00007EFF8A6E2420
00007eff8a7cfa2b  jmp 0x00007EFF8A7CF149
00007eff8a7cfa30  call 0x00007EFF8A6E2420
00007eff8a7cfa35  jmp 0x00007EFF8A7CF15A
00007eff8a7cfa3a  call 0x00007EFF8A6E2420
00007eff8a7cfa3f  jmp 0x00007EFF8A7CF16B
00007eff8a7cfa44  call 0x00007EFF8A6E2420
00007eff8a7cfa49  jmp 0x00007EFF8A7CF17C
00007eff8a7cfa4e  call 0x00007EFF8A6E2420
00007eff8a7cfa53  jmp 0x00007EFF8A7CF18D
00007eff8a7cfa58  call 0x00007EFF8A6E2420
00007eff8a7cfa5d  jmp 0x00007EFF8A7CF19E
00007eff8a7cfa62  call 0x00007EFF8A6E2420
00007eff8a7cfa67  jmp 0x00007EFF8A7CF1AF
00007eff8a7cfa6c  call 0x00007EFF8A6E2420
00007eff8a7cfa71  jmp 0x00007EFF8A7CF1C0
00007eff8a7cfa76  call 0x00007EFF8A6E2420
00007eff8a7cfa7b  jmp 0x00007EFF8A7CF1D1
00007eff8a7cfa80  call 0x00007EFF8A6E2420
00007eff8a7cfa85  jmp 0x00007EFF8A7CF1E2
00007eff8a7cfa8a  call 0x00007EFF8A6E2420
00007eff8a7cfa8f  jmp 0x00007EFF8A7CF1F3
00007eff8a7cfa94  call 0x00007EFF8A6E2420
00007eff8a7cfa99  jmp 0x00007EFF8A7CF204
00007eff8a7cfa9e  call 0x00007EFF8A6E2420
00007eff8a7cfaa3  jmp 0x00007EFF8A7CF215
00007eff8a7cfaa8  call 0x00007EFF8A6E2420
00007eff8a7cfaad  jmp 0x00007EFF8A7CF226
00007eff8a7cfab2  call 0x00007EFF8A6E2420
00007eff8a7cfab7  jmp 0x00007EFF8A7CF237
00007eff8a7cfabc  call 0x00007EFF8A6E2420
00007eff8a7cfac1  jmp 0x00007EFF8A7CF248
00007eff8a7cfac6  call 0x00007EFF8A6E2420
00007eff8a7cfacb  jmp 0x00007EFF8A7CF259
00007eff8a7cfad0  call 0x00007EFF8A6E2420
00007eff8a7cfad5  jmp 0x00007EFF8A7CF26A
00007eff8a7cfada  call 0x00007EFF8A6E2420
00007eff8a7cfadf  jmp 0x00007EFF8A7CF27B
00007eff8a7cfae4  call 0x00007EFF8A6E2420
00007eff8a7cfae9  jmp 0x00007EFF8A7CF28C
00007eff8a7cfaee  call 0x00007EFF8A6E2420
00007eff8a7cfaf3  jmp 0x00007EFF8A7CF29D
00007eff8a7cfaf8  call 0x00007EFF8A6E2420
00007eff8a7cfafd  jmp 0x00007EFF8A7CF2AE
00007eff8a7cfb02  call 0x00007EFF8A6E2420
00007eff8a7cfb07  jmp 0x00007EFF8A7CF2BF
00007eff8a7cfb0c  call 0x00007EFF8A6E2420
00007eff8a7cfb11  jmp 0x00007EFF8A7CF2D0
00007eff8a7cfb16  call 0x00007EFF8A6E2420
00007eff8a7cfb1b  jmp 0x00007EFF8A7CF2E1
00007eff8a7cfb20  call 0x00007EFF8A6E2420
00007eff8a7cfb25  jmp 0x00007EFF8A7CF2F2
00007eff8a7cfb2a  call 0x00007EFF8A6E2420
00007eff8a7cfb2f  jmp 0x00007EFF8A7CF303
00007eff8a7cfb34  call 0x00007EFF8A6E2420
00007eff8a7cfb39  jmp 0x00007EFF8A7CF314
00007eff8a7cfb3e  call 0x00007EFF8A6E2420
00007eff8a7cfb43  jmp 0x00007EFF8A7CF325
00007eff8a7cfb48  call 0x00007EFF8A6E2420
00007eff8a7cfb4d  jmp 0x00007EFF8A7CF336
00007eff8a7cfb52  call 0x00007EFF8A6E2420
00007eff8a7cfb57  jmp 0x00007EFF8A7CF347
00007eff8a7cfb5c  call 0x00007EFF8A6E2420
00007eff8a7cfb61  jmp 0x00007EFF8A7CF358
00007eff8a7cfb66  call 0x00007EFF8A6E2420
00007eff8a7cfb6b  jmp 0x00007EFF8A7CF369
00007eff8a7cfb70  call 0x00007EFF8A6E2420
00007eff8a7cfb75  jmp 0x00007EFF8A7CF37A
00007eff8a7cfb7a  call 0x00007EFF8A6E2420
00007eff8a7cfb7f  jmp 0x00007EFF8A7CF38B
00007eff8a7cfb84  call 0x00007EFF8A6E2420
00007eff8a7cfb89  jmp 0x00007EFF8A7CF39C
00007eff8a7cfb8e  call 0x00007EFF8A6E2420
00007eff8a7cfb93  jmp 0x00007EFF8A7CF3AD
00007eff8a7cfb98  call 0x00007EFF8A6E2420
00007eff8a7cfb9d  jmp 0x00007EFF8A7CF3BE
00007eff8a7cfba2  call 0x00007EFF8A6E2420
00007eff8a7cfba7  jmp 0x00007EFF8A7CF3CF
00007eff8a7cfbac  call 0x00007EFF8A6E2420
00007eff8a7cfbb1  jmp 0x00007EFF8A7CF3E0
00007eff8a7cfbb6  call 0x00007EFF8A6E2420
00007eff8a7cfbbb  jmp 0x00007EFF8A7CF3F1
00007eff8a7cfbc0  call 0x00007EFF8A6E2420
00007eff8a7cfbc5  jmp 0x00007EFF8A7CF402
00007eff8a7cfbca  call 0x00007EFF8A6E2420
00007eff8a7cfbcf  jmp 0x00007EFF8A7CF413
00007eff8a7cfbd4  call 0x00007EFF8A6E2420
00007eff8a7cfbd9  jmp 0x00007EFF8A7CF424
00007eff8a7cfbde  call 0x00007EFF8A6E2420
00007eff8a7cfbe3  jmp 0x00007EFF8A7CF435
00007eff8a7cfbe8  call 0x00007EFF8A6E2420
00007eff8a7cfbed  jmp 0x00007EFF8A7CF446
00007eff8a7cfbf2  call 0x00007EFF8A6E2420
00007eff8a7cfbf7  jmp 0x00007EFF8A7CF45F
00007eff8a7cfbfc  call 0x00007EFF8A6E2420
00007eff8a7cfc01  jmp 0x00007EFF8A7CF478
00007eff8a7cfc06  call 0x00007EFF8A6D5610
00007eff8a7cfc0b  jmp 0x00007EFF8A7CF491
00007eff8a7cfc10  call 0x00007EFF8A6DC580
00007eff8a7cfc15  jmp 0x00007EFF8A7CF7FE
00007eff8a7cfc1a  call 0x00007EFF8A6E46C0
00007eff8a7cfc1f  jmp 0x00007EFF8A7CF808
00007eff8a7cfc24  call 0x00007EFF8A609E90
00007eff8a7cfc29  jmp 0x00007EFF8A7CF80E
00007eff8a7cfc2e  call 0x00007EFF8A6DB310
00007eff8a7cfc33  jmp 0x00007EFF8A7CF818
00007eff8a7cfc38  call 0x00007EFF8A60DAE0
00007eff8a7cfc3d  jmp 0x00007EFF8A7CF81D
00007eff8a7cfc42  call 0x00007EFF8A6C0230
00007eff8a7cfc47  jmp 0x00007EFF8A7CF836
00007eff8a7cfc4c  call 0x00007EFF8A6C0230
00007eff8a7cfc51  jmp 0x00007EFF8A7CF84B
00007eff8a7cfc56  call 0x00007EFF8A6BEFC0
00007eff8a7cfc5b  jmp 0x00007EFF8A7CF854
00007eff8a7cfc60  call 0x00007EFF8A6E2BA0
00007eff8a7cfc65  jmp 0x00007EFF8A7CF91B
00007eff8a7cfc6a  int3
00007eff8a7cfc6b  nop [rax+rax*1], eax
00007eff8a7cfc70  mov rax, [r15+0x48]
00007eff8a7cfc74  mov r14, [r15+0x58]
00007eff8a7cfc78  lea r12, [rax+r14*1]
00007eff8a7cfc7c  mov [r15+0x68], r12
00007eff8a7cfc80  lea rax, [r14+0x04]
00007eff8a7cfc84  mov [r15+0x58], rax
00007eff8a7cfc88  lea r14, [r12+0x04]
00007eff8a7cfc8d  mov r11d, [r13+r14*1]
00007eff8a7cfc92  mov [rsp+0x10], r11d
00007eff8a7cfc97  mov r11d, r11d
00007eff8a7cfc9a  mov [r15+0x70], r11
00007eff8a7cfc9e  lea r14, [r12+0x38]
00007eff8a7cfca3  mov r11d, [r13+r14*1]
00007eff8a7cfca8  lea r14, [r12+0x24]
00007eff8a7cfcad  mov r10d, [r13+r14*1]
00007eff8a7cfcb2  mov [rsp+0x20], r10d
00007eff8a7cfcb7  mov r10d, r10d
00007eff8a7cfcba  mov [r15+0x90], r10
00007eff8a7cfcc1  mov [rsp+0x30], rax
00007eff8a7cfcc6  xor eax, eax
00007eff8a7cfcc8  mov r14, [rsp+0x30]
00007eff8a7cfccd  mov r10d, 0xC0
00007eff8a7cfcd3  cmp r14, r10
00007eff8a7cfcd6  cmc
00007eff8a7cfcd7  lahf
00007eff8a7cfcd8  seto al
00007eff8a7cfcdb  mov [r15+0x108], eax
00007eff8a7cfce2  mov eax, [rsp+0x10]
00007eff8a7cfce6  mov r14d, [rsp+0x10]
00007eff8a7cfceb  shrd eax, r14d, 0x07
00007eff8a7cfcf0  mov [rsp+0x10], r11d
00007eff8a7cfcf5  mov r10d, [rsp+0x10]
00007eff8a7cfcfa  shrd r11d, r10d, 0x11
00007eff8a7cfcff  mov r9d, [r15+0x60]
00007eff8a7cfd03  mov r8d, [rsp+0x20]
00007eff8a7cfd08  lea ebp, [r8d+r9d*1]
00007eff8a7cfd0d  rorx r9d, r14d, 0x12
00007eff8a7cfd13  xor eax, r9d
00007eff8a7cfd16  rorx r9d, r10d, 0x13
00007eff8a7cfd1c  xor r11d, r9d
00007eff8a7cfd1f  mov [rsp+0x10], r11d
00007eff8a7cfd24  mov r11d, r11d
00007eff8a7cfd27  mov [r15+0x88], r11
00007eff8a7cfd2e  mov [rsp+0x20], r14d
00007eff8a7cfd33  shr r14d, 0x03
00007eff8a7cfd37  xor eax, r14d
00007eff8a7cfd3a  mov [rsp+0x30], eax
00007eff8a7cfd3e  mov eax, eax
00007eff8a7cfd40  mov [r15+0x80], rax
00007eff8a7cfd47  shr r10d, 0x0A
00007eff8a7cfd4b  mov eax, [rsp+0x10]
00007eff8a7cfd4f  xor eax, r10d
00007eff8a7cfd52  mov [rsp+0x10], eax
00007eff8a7cfd56  mov eax, eax
00007eff8a7cfd58  mov [r15+0x78], rax
00007eff8a7cfd5c  mov eax, [rsp+0x30]
00007eff8a7cfd60  lea r14d, [ebp+eax*1]
00007eff8a7cfd66  mov eax, [rsp+0x10]
00007eff8a7cfd6a  lea r11d, [r14d+eax*1]
00007eff8a7cfd6f  lea rax, [r12+0x40]
00007eff8a7cfd74  mov [r13+rax*1], r11d
00007eff8a7cfd79  mov eax, [rsp+0x20]
00007eff8a7cfd7d  mov eax, eax
00007eff8a7cfd7f  mov [r15+0x60], rax
00007eff8a7cfd83  mov eax, [r15+0x108]
00007eff8a7cfd8a  sahf
00007eff8a7cfd8b  jnz 0x00007EFF8A7CFDBD
00007eff8a7cfd8d  cmp dword ptr [r15+0x318], 0x00
00007eff8a7cfd95  jz 0x00007EFF8A7CFE20
00007eff8a7cfd9b  nop [rax+rax*1], ax
00007eff8a7cfda4  nop [rax+rax*1], eax
00007eff8a7cfdac  mov eax, 0x41049C
00007eff8a7cfdb1  mov [r15+0x100], rax
00007eff8a7cfdb8  jmp 0x00007EFF8A5FE110
00007eff8a7cfdbd  cmp dword ptr [r15+0x318], 0x00
00007eff8a7cfdc5  jz 0x00007EFF8A7CFC70
00007eff8a7cfdcb  nop [rax+rax*1], ax
00007eff8a7cfdd4  nop [rax+rax*1], eax
00007eff8a7cfddc  mov eax, 0x410454
00007eff8a7cfde1  mov [r15+0x100], rax
00007eff8a7cfde8  jmp 0x00007EFF8A5FE110
00007eff8a7cfded  int3
00007eff8a7cfdee  call 0x00007EFF8A6E1430
00007eff8a7cfdf3  jmp 0x00007EFF8A7CFC92
00007eff8a7cfdf8  call 0x00007EFF8A6E1430
00007eff8a7cfdfd  jmp 0x00007EFF8A7CFCA8
00007eff8a7cfe02  call 0x00007EFF8A6E01C0
00007eff8a7cfe07  jmp 0x00007EFF8A7CFCB2
00007eff8a7cfe0c  call 0x00007EFF8A60A860
00007eff8a7cfe11  jmp 0x00007EFF8A7CFD79
00007eff8a7cfe16  int3
00007eff8a7cfe17  nop [rax+rax*1], ax
00007eff8a7cfe20  mov rax, [r15]
00007eff8a7cfe23  mov r14d, [r13+rax*1]
00007eff8a7cfe28  lea r12, [rax+0x04]
00007eff8a7cfe2c  mov r11d, [r13+r12*1]
00007eff8a7cfe31  mov [rsp+0x10], r14d
00007eff8a7cfe36  mov r14d, r14d
00007eff8a7cfe39  mov [r15+0x78], r14
00007eff8a7cfe3d  mov [rsp+0x20], r11d
00007eff8a7cfe42  mov r11d, r11d
00007eff8a7cfe45  mov [r15+0x80], r11
00007eff8a7cfe4c  lea r14, [rax+0x08]
00007eff8a7cfe50  mov r12d, [r13+r14*1]
00007eff8a7cfe55  lea r14, [rax+0x0C]
00007eff8a7cfe59  mov r11d, [r13+r14*1]
00007eff8a7cfe5e  mov [rsp+0x30], r12d
00007eff8a7cfe63  mov r12d, r12d
00007eff8a7cfe66  mov [r15+0x70], r12
00007eff8a7cfe6a  mov [rsp+0x40], r11d
00007eff8a7cfe6f  mov r11d, r11d
00007eff8a7cfe72  mov [r15+0x68], r11
00007eff8a7cfe76  lea r14, [rax+0x18]
00007eff8a7cfe7a  mov r12d, [r13+r14*1]
00007eff8a7cfe7f  lea r14, [rax+0x1C]
00007eff8a7cfe83  mov r11d, [r13+r14*1]
00007eff8a7cfe88  mov [rsp+0x50], r12d
00007eff8a7cfe8d  mov r12d, r12d
00007eff8a7cfe90  mov [r15+0x58], r12
00007eff8a7cfe94  mov [rsp+0x60], r11d
00007eff8a7cfe99  mov r11d, r11d
00007eff8a7cfe9c  mov [r15+0x60], r11
00007eff8a7cfea0  lea r14, [rax+0x10]
00007eff8a7cfea4  mov r12d, [r13+r14*1]
00007eff8a7cfea9  lea r14, [rax+0x14]
00007eff8a7cfead  mov eax, [r13+r14*1]
00007eff8a7cfeb2  mov [rsp+0x70], r12d
00007eff8a7cfeb7  mov r12d, r12d
00007eff8a7cfeba  mov [r15+0x18], r12
00007eff8a7cfebe  mov [rsp+0x80], eax
00007eff8a7cfec5  mov eax, eax
00007eff8a7cfec7  mov [r15+0x90], rax
00007eff8a7cfece  mov eax, [rsp+0x70]
00007eff8a7cfed2  mov eax, eax
00007eff8a7cfed4  mov [r15+0x30], rax
00007eff8a7cfed8  mov eax, [rsp+0x50]
00007eff8a7cfedc  mov eax, eax
00007eff8a7cfede  mov [r15+0xA0], rax
00007eff8a7cfee5  mov eax, [rsp+0x30]
00007eff8a7cfee9  mov eax, eax
00007eff8a7cfeeb  mov [r15+0x28], rax
00007eff8a7cfeef  mov eax, [rsp+0x20]
00007eff8a7cfef3  mov eax, eax
00007eff8a7cfef5  mov [r15+0x98], rax
00007eff8a7cfefc  mov eax, [rsp+0x10]
00007eff8a7cff00  mov eax, eax
00007eff8a7cff02  mov [r15+0x38], rax
00007eff8a7cff06  mov eax, [rsp+0x70]
00007eff8a7cff0a  mov r14d, [rsp+0x70]
00007eff8a7cff0f  shrd eax, r14d, 0x06
00007eff8a7cff14  mov [rsp+0x70], r14d
00007eff8a7cff19  mov r12d, [rsp+0x80]
00007eff8a7cff21  and r14d, r12d
00007eff8a7cff24  mov r11d, [rsp+0x10]
00007eff8a7cff29  mov r10d, [rsp+0x10]
00007eff8a7cff2e  shrd r11d, r10d, 0x02
00007eff8a7cff33  mov [rsp+0x10], r12d
00007eff8a7cff38  mov r12d, r12d
00007eff8a7cff3b  mov [r15+0x20], r12
00007eff8a7cff3f  mov r12, [r15+0x50]
00007eff8a7cff43  mov r9d, [r13+r12*1]
00007eff8a7cff48  mov r12d, [rsp+0x50]
00007eff8a7cff4d  mov r8d, [rsp+0x70]
00007eff8a7cff52  andn ebp, r8d, r12d
00007eff8a7cff57  mov edi, [rsp+0x60]
00007eff8a7cff5b  lea esi, [r14d+edi*1]
00007eff8a7cff60  rorx r14d, r8d, 0x0B
00007eff8a7cff66  xor eax, r14d
00007eff8a7cff69  rorx r14d, r10d, 0x0D
00007eff8a7cff6f  xor r11d, r14d
00007eff8a7cff72  lea edi, [esi+ebp*1]
00007eff8a7cff76  mov r14, [r15+0x48]
00007eff8a7cff7a  mov ebp, [r13+r14*1]
00007eff8a7cff7f  mov r14d, [rsp+0x30]
00007eff8a7cff84  mov esi, [rsp+0x20]
00007eff8a7cff88  and r14d, esi
00007eff8a7cff8b  mov [rsp+0x20], r14d
00007eff8a7cff90  mov r14d, r14d
00007eff8a7cff93  mov [r15+0xD8], r14
00007eff8a7cff9a  lea r14d, [edi+r9d*1]
00007eff8a7cff9f  mov r9d, [rsp+0x30]
00007eff8a7cffa4  xor r9d, esi
00007eff8a7cffa7  rorx edi, r8d, 0x19
00007eff8a7cffad  xor eax, edi
00007eff8a7cffaf  and r9d, r10d
00007eff8a7cffb2  rorx edi, r10d, 0x16
00007eff8a7cffb8  xor r11d, edi
00007eff8a7cffbb  mov [rsp+0x30], r11d
00007eff8a7cffc0  mov r11d, r11d
00007eff8a7cffc3  mov [r15+0xD0], r11
00007eff8a7cffca  lea r11d, [r14d+ebp*1]
00007eff8a7cffcf  mov r10d, [rsp+0x20]
00007eff8a7cffd4  xor r9d, r10d
00007eff8a7cffd7  lea r14d, [r11d+eax*1]
00007eff8a7cffdc  mov qword ptr [r15+0x88], 0x04
00007eff8a7cffe7  mov eax, [rsp+0x30]
00007eff8a7cffeb  lea r11d, [r9d+eax*1]
00007eff8a7cfff0  mov eax, [rsp+0x40]
00007eff8a7cfff4  lea r10d, [r14d+eax*1]
00007eff8a7cfff9  mov r10d, r10d
00007eff8a7cfffc  mov [r15+0xB8], r10
00007eff8a7d0003  xor eax, eax
00007eff8a7d0005  mov r10d, 0x04
00007eff8a7d000b  mov r9d, 0x100
00007eff8a7d0011  cmp r10, r9
00007eff8a7d0014  cmc
00007eff8a7d0015  lahf
00007eff8a7d0016  seto al
00007eff8a7d0019  mov [r15+0x108], eax
00007eff8a7d0020  lea eax, [r11d+r14d*1]
00007eff8a7d0025  mov eax, eax
00007eff8a7d0027  mov [r15+0xA8], rax
00007eff8a7d002e  mov r12d, r12d
00007eff8a7d0031  mov [r15+0xB0], r12
00007eff8a7d0038  mov eax, [rsp+0x10]
00007eff8a7d003c  mov eax, eax
00007eff8a7d003e  mov [r15+0xC0], rax
00007eff8a7d0045  mov r8d, r8d
00007eff8a7d0048  mov [r15+0xC8], r8
00007eff8a7d004f  mov eax, [r15+0x108]
00007eff8a7d0056  sahf
00007eff8a7d0057  jnz 0x00007EFF8A7D0089
00007eff8a7d0059  cmp dword ptr [r15+0x318], 0x00
00007eff8a7d0061  jz 0x00007EFF8A7D0350
00007eff8a7d0067  nop [rax+rax*1], ax
00007eff8a7d0070  nop [rax+rax*1], eax
00007eff8a7d0078  mov eax, 0x41055C
00007eff8a7d007d  mov [r15+0x100], rax
00007eff8a7d0084  jmp 0x00007EFF8A5FE110
00007eff8a7d0089  cmp dword ptr [r15+0x318], 0x00
00007eff8a7d0091  jz 0x00007EFF8A7D0120
00007eff8a7d0097  nop [rax+rax*1], ax
00007eff8a7d00a0  nop [rax+rax*1], eax
00007eff8a7d00a8  mov eax, 0x4104D0
00007eff8a7d00ad  mov [r15+0x100], rax
00007eff8a7d00b4  jmp 0x00007EFF8A5FE110
00007eff8a7d00b9  int3
00007eff8a7d00ba  call 0x00007EFF8A60DAE0
00007eff8a7d00bf  jmp 0x00007EFF8A7CFE28
00007eff8a7d00c4  call 0x00007EFF8A6C0230
00007eff8a7d00c9  jmp 0x00007EFF8A7CFE31
00007eff8a7d00ce  call 0x00007EFF8A6E26A0
00007eff8a7d00d3  jmp 0x00007EFF8A7CFE55
00007eff8a7d00d8  call 0x00007EFF8A6E1430
00007eff8a7d00dd  jmp 0x00007EFF8A7CFE5E
00007eff8a7d00e2  call 0x00007EFF8A6E26A0
00007eff8a7d00e7  jmp 0x00007EFF8A7CFE7F
00007eff8a7d00ec  call 0x00007EFF8A6E1430
00007eff8a7d00f1  jmp 0x00007EFF8A7CFE88
00007eff8a7d00f6  call 0x00007EFF8A6E26A0
00007eff8a7d00fb  jmp 0x00007EFF8A7CFEA9
00007eff8a7d0100  call 0x00007EFF8A6D5890
00007eff8a7d0105  jmp 0x00007EFF8A7CFEB2
00007eff8a7d010a  call 0x00007EFF8A6BDD50
00007eff8a7d010f  jmp 0x00007EFF8A7CFF48
00007eff8a7d0114  call 0x00007EFF8A6DA580
00007eff8a7d0119  jmp 0x00007EFF8A7CFF7F
00007eff8a7d011e  int3
00007eff8a7d011f  nop
00007eff8a7d0120  mov eax, [r15+0xB8]
00007eff8a7d0127  mov [rsp+0x10], eax
00007eff8a7d012b  mov eax, eax
00007eff8a7d012d  mov [r15+0x30], rax
00007eff8a7d0131  mov eax, [r15+0xC0]
00007eff8a7d0138  mov [rsp+0x20], eax
00007eff8a7d013c  mov eax, eax
00007eff8a7d013e  mov [r15+0xA0], rax
00007eff8a7d0145  mov eax, [r15+0x28]
00007eff8a7d0149  mov r14d, [r15+0x98]
00007eff8a7d0150  mov [rsp+0x30], r14d
00007eff8a7d0155  mov r14d, r14d
00007eff8a7d0158  mov [r15+0x28], r14
00007eff8a7d015c  mov r14d, [r15+0x38]
00007eff8a7d0160  mov [rsp+0x40], r14d
00007eff8a7d0165  mov r14d, r14d
00007eff8a7d0168  mov [r15+0x98], r14
00007eff8a7d016f  mov r14d, [r15+0xA8]
00007eff8a7d0176  mov [rsp+0x50], r14d
00007eff8a7d017b  mov r14d, r14d
00007eff8a7d017e  mov [r15+0x38], r14
00007eff8a7d0182  mov r14d, [rsp+0x10]
00007eff8a7d0187  mov r12d, [rsp+0x10]
00007eff8a7d018c  shrd r14d, r12d, 0x06
00007eff8a7d0191  mov r11d, [r15+0xC8]
00007eff8a7d0198  mov [rsp+0x10], r12d
00007eff8a7d019d  and r12d, r11d
00007eff8a7d01a0  mov r10d, [rsp+0x50]
00007eff8a7d01a5  mov r9d, [rsp+0x50]
00007eff8a7d01aa  shrd r10d, r9d, 0x02
00007eff8a7d01af  mov [rsp+0x50], r11d
00007eff8a7d01b4  mov r11d, r11d
00007eff8a7d01b7  mov [r15+0x20], r11
00007eff8a7d01bb  mov r11, [r15+0x88]
00007eff8a7d01c2  mov r8, [r15+0x50]
00007eff8a7d01c6  lea rbp, [r8+r11*1]
00007eff8a7d01ca  mov r8d, [r13+rbp*1]
00007eff8a7d01cf  mov ebp, [rsp+0x20]
00007eff8a7d01d3  mov edi, [rsp+0x10]
00007eff8a7d01d7  andn esi, edi, ebp
00007eff8a7d01dc  mov edx, [r15+0xB0]
00007eff8a7d01e3  lea ecx, [r12d+edx*1]
00007eff8a7d01e8  rorx r12d, edi, 0x0B
00007eff8a7d01ee  xor r14d, r12d
00007eff8a7d01f1  rorx r12d, r9d, 0x0D
00007eff8a7d01f7  xor r10d, r12d
00007eff8a7d01fa  lea r12d, [ecx+esi*1]
00007eff8a7d01ff  mov rsi, [r15+0x48]
00007eff8a7d0203  lea rdx, [rsi+r11*1]
00007eff8a7d0207  mov esi, [r13+rdx*1]
00007eff8a7d020c  mov edx, [rsp+0x30]
00007eff8a7d0210  mov ecx, [rsp+0x40]
00007eff8a7d0214  and edx, ecx
00007eff8a7d0216  mov [rsp+0x10], edx
00007eff8a7d021a  mov edx, edx
00007eff8a7d021c  mov [r15+0xD8], rdx
00007eff8a7d0223  lea edx, [r12d+r8d*1]
00007eff8a7d0228  mov r12d, [rsp+0x30]
00007eff8a7d022d  xor r12d, ecx
00007eff8a7d0230  rorx r8d, edi, 0x19
00007eff8a7d0236  xor r14d, r8d
00007eff8a7d0239  and r12d, r9d
00007eff8a7d023c  rorx r8d, r9d, 0x16
00007eff8a7d0242  xor r10d, r8d
00007eff8a7d0245  mov [rsp+0x20], r10d
00007eff8a7d024a  mov r10d, r10d
00007eff8a7d024d  mov [r15+0xD0], r10
00007eff8a7d0254  lea r10d, [edx+esi*1]
00007eff8a7d0259  mov r9d, [rsp+0x10]
00007eff8a7d025e  xor r12d, r9d
00007eff8a7d0261  lea r9d, [r10d+r14d*1]
00007eff8a7d0266  lea r14, [r11+0x04]
00007eff8a7d026a  mov [r15+0x88], r14
00007eff8a7d0271  mov r11d, [rsp+0x20]
00007eff8a7d0276  lea r10d, [r12d+r11d*1]
00007eff8a7d027b  lea r11d, [r9d+eax*1]
00007eff8a7d0280  mov r11d, r11d
00007eff8a7d0283  mov [r15+0xB8], r11
00007eff8a7d028a  xor eax, eax
00007eff8a7d028c  mov r12d, 0x100
00007eff8a7d0292  cmp r14, r12
00007eff8a7d0295  cmc
00007eff8a7d0296  lahf
00007eff8a7d0297  seto al
00007eff8a7d029a  mov [r15+0x108], eax
00007eff8a7d02a1  lea eax, [r10d+r9d*1]
00007eff8a7d02a6  mov eax, eax
00007eff8a7d02a8  mov [r15+0xA8], rax
00007eff8a7d02af  mov ebp, ebp
00007eff8a7d02b1  mov [r15+0xB0], rbp
00007eff8a7d02b8  mov eax, [rsp+0x50]
00007eff8a7d02bc  mov eax, eax
00007eff8a7d02be  mov [r15+0xC0], rax
00007eff8a7d02c5  mov edi, edi
00007eff8a7d02c7  mov [r15+0xC8], rdi
00007eff8a7d02ce  mov eax, [r15+0x108]
00007eff8a7d02d5  sahf
00007eff8a7d02d6  jnz 0x00007EFF8A7D0308
00007eff8a7d02d8  cmp dword ptr [r15+0x318], 0x00
00007eff8a7d02e0  jz 0x00007EFF8A7D0350
00007eff8a7d02e6  nop [rax+rax*1], ax
00007eff8a7d02ef  nop [rax+rax*1], eax
00007eff8a7d02f7  mov eax, 0x41055C
00007eff8a7d02fc  mov [r15+0x100], rax
00007eff8a7d0303  jmp 0x00007EFF8A5FE110
00007eff8a7d0308  cmp dword ptr [r15+0x318], 0x00
00007eff8a7d0310  jz 0x00007EFF8A7D0120
00007eff8a7d0316  nop [rax+rax*1], ax
00007eff8a7d031f  nop [rax+rax*1], eax
00007eff8a7d0327  mov eax, 0x4104D0
00007eff8a7d032c  mov [r15+0x100], rax
00007eff8a7d0333  jmp 0x00007EFF8A5FE110
00007eff8a7d0338  int3
00007eff8a7d0339  call 0x00007EFF8A649010
00007eff8a7d033e  jmp 0x00007EFF8A7D01CF
00007eff8a7d0343  call 0x00007EFF8A625930
00007eff8a7d0348  jmp 0x00007EFF8A7D020C
00007eff8a7d034d  int3
00007eff8a7d034e  nop
00007eff8a7d0350  mov eax, [r15+0x98]
00007eff8a7d0357  mov r14d, [r15+0x70]
00007eff8a7d035b  lea r12d, [eax+r14d*1]
00007eff8a7d0360  mov eax, [r15+0x28]
00007eff8a7d0364  mov r14d, [r15+0x68]
00007eff8a7d0368  lea r11d, [eax+r14d*1]
00007eff8a7d036d  mov qword ptr [r15+0x88], 0x00
00007eff8a7d0378  mov eax, [r15+0xA8]
00007eff8a7d037f  mov r14d, [r15+0x78]
00007eff8a7d0383  lea r10d, [eax+r14d*1]
00007eff8a7d0388  mov [rsp+0x10], r10d
00007eff8a7d038d  mov r10d, r10d
00007eff8a7d0390  mov [r15+0x78], r10
00007eff8a7d0394  mov eax, [r15+0x38]
00007eff8a7d0398  mov r14d, [r15+0x80]
00007eff8a7d039f  lea r10d, [eax+r14d*1]
00007eff8a7d03a4  mov [rsp+0x20], r10d
00007eff8a7d03a9  mov r10d, r10d
00007eff8a7d03ac  mov [r15+0x80], r10
00007eff8a7d03b3  mov rax, [r15]
00007eff8a7d03b6  lea r14, [rax+0x08]
00007eff8a7d03ba  mov [r13+r14*1], r12d
00007eff8a7d03bf  lea r14, [rax+0x0C]
00007eff8a7d03c3  mov [r13+r14*1], r11d
00007eff8a7d03c8  mov r14d, [r15+0xB8]
00007eff8a7d03cf  mov r12d, [r15+0x18]
00007eff8a7d03d3  lea r11d, [r14d+r12d*1]
00007eff8a7d03d8  mov [rsp+0x30], r11d
00007eff8a7d03dd  mov r11d, r11d
00007eff8a7d03e0  mov [r15+0x68], r11
00007eff8a7d03e4  mov r14d, [r15+0x30]
00007eff8a7d03e8  mov r12d, [r15+0x90]
00007eff8a7d03ef  lea r11d, [r14d+r12d*1]
00007eff8a7d03f4  mov [rsp+0x40], r11d
00007eff8a7d03f9  mov r11d, r11d
00007eff8a7d03fc  mov [r15+0x70], r11
00007eff8a7d0400  mov r14d, [r15+0x20]
00007eff8a7d0404  mov r12d, [r15+0x58]
00007eff8a7d0408  lea r11d, [r14d+r12d*1]
00007eff8a7d040d  mov [rsp+0x50], r11d
00007eff8a7d0412  mov r11d, r11d
00007eff8a7d0415  mov [r15+0x58], r11
00007eff8a7d0419  mov r14d, [r15+0xA0]
00007eff8a7d0420  mov r12d, [r15+0x60]
00007eff8a7d0424  lea r11d, [r14d+r12d*1]
00007eff8a7d0429  mov [rsp+0x60], r11d
00007eff8a7d042e  mov r11d, r11d
00007eff8a7d0431  mov [r15+0x60], r11
00007eff8a7d0435  mov r14d, [rsp+0x10]
00007eff8a7d043a  mov [r13+rax*1], r14d
00007eff8a7d043f  lea r14, [rax+0x04]
00007eff8a7d0443  mov r12d, [rsp+0x20]
00007eff8a7d0448  mov [r13+r14*1], r12d
00007eff8a7d044d  lea r14, [rax+0x10]
00007eff8a7d0451  mov r12d, [rsp+0x30]
00007eff8a7d0456  mov [r13+r14*1], r12d
00007eff8a7d045b  lea r14, [rax+0x14]
00007eff8a7d045f  mov r12d, [rsp+0x40]
00007eff8a7d0464  mov [r13+r14*1], r12d
00007eff8a7d0469  lea r14, [rax+0x18]
00007eff8a7d046d  mov r12d, [rsp+0x50]
00007eff8a7d0472  mov [r13+r14*1], r12d
00007eff8a7d0477  lea r14, [rax+0x1C]
00007eff8a7d047b  mov r12d, [rsp+0x60]
00007eff8a7d0480  mov [r13+r14*1], r12d
00007eff8a7d0485  lea r14, [rax+0x68]
00007eff8a7d0489  xor eax, eax
00007eff8a7d048b  mov [r13+r14*1], rax
00007eff8a7d0490  cmp dword ptr [r15+0x318], 0x00
00007eff8a7d0498  jz 0x00007EFF8A7CEF90
00007eff8a7d049e  nop [rax+rax*1], ax
00007eff8a7d04a7  nop [rax+rax*1], eax
00007eff8a7d04af  mov eax, 0x410378
00007eff8a7d04b4  mov [r15+0x100], rax
00007eff8a7d04bb  jmp 0x00007EFF8A5FE110
00007eff8a7d04c0  int3
00007eff8a7d04c1  call 0x00007EFF8A6E2BA0
00007eff8a7d04c6  jmp 0x00007EFF8A7D03BF
00007eff8a7d04cb  call 0x00007EFF8A6E1920
00007eff8a7d04d0  jmp 0x00007EFF8A7D03C8
00007eff8a7d04d5  call 0x00007EFF8A60DFE0
00007eff8a7d04da  jmp 0x00007EFF8A7D043F
00007eff8a7d04df  call 0x00007EFF8A6E2BA0
00007eff8a7d04e4  jmp 0x00007EFF8A7D044D
00007eff8a7d04e9  call 0x00007EFF8A6E2BA0
00007eff8a7d04ee  jmp 0x00007EFF8A7D045B
00007eff8a7d04f3  call 0x00007EFF8A6E2BA0
00007eff8a7d04f8  jmp 0x00007EFF8A7D0469
00007eff8a7d04fd  call 0x00007EFF8A6E2BA0
00007eff8a7d0502  jmp 0x00007EFF8A7D0477
00007eff8a7d0507  call 0x00007EFF8A6E2BA0
00007eff8a7d050c  jmp 0x00007EFF8A7D0485
00007eff8a7d0511  call 0x00007EFF8A6D5EB0
00007eff8a7d0516  jmp 0x00007EFF8A7D0490
00007eff8a7d051b  int3
00007eff8a7d051c  nop [rax], eax
00007eff8a7d0520  mov rax, [r15+0xF8]
00007eff8a7d0527  lea r14, [rax+0x140]
00007eff8a7d052e  mov r12, [r13+r14*1]
00007eff8a7d0533  lea r14, [rax+0x148]
00007eff8a7d053a  mov r11, [r13+r14*1]
00007eff8a7d053f  mov [r15+0xA0], r12
00007eff8a7d0546  mov [r15+0x98], r11
00007eff8a7d054d  lea r14, [rax+0x130]
00007eff8a7d0554  mov r12, [r13+r14*1]
00007eff8a7d0559  lea r14, [rax+0x138]
00007eff8a7d0560  mov r11, [r13+r14*1]
00007eff8a7d0565  mov [r15+0xB0], r12
00007eff8a7d056c  mov [r15+0xA8], r11
00007eff8a7d0573  lea r14, [rax+0x120]
00007eff8a7d057a  mov r12, [r13+r14*1]
00007eff8a7d057f  lea r14, [rax+0x128]
00007eff8a7d0586  mov r11, [r13+r14*1]
00007eff8a7d058b  mov [r15+0xC0], r12
00007eff8a7d0592  mov [r15+0xB8], r11
00007eff8a7d0599  lea r14, [rax+0x110]
00007eff8a7d05a0  mov r12, [r13+r14*1]
00007eff8a7d05a5  lea r14, [rax+0x118]
00007eff8a7d05ac  mov r11, [r13+r14*1]
00007eff8a7d05b1  mov [r15+0xD0], r12
00007eff8a7d05b8  mov [r15+0xC8], r11
00007eff8a7d05bf  lea r14, [rax+0x100]
00007eff8a7d05c6  mov r12, [r13+r14*1]
00007eff8a7d05cb  lea r14, [rax+0x108]
00007eff8a7d05d2  mov r11, [r13+r14*1]
00007eff8a7d05d7  mov [r15+0xE8], r12
00007eff8a7d05de  mov [r15+0xD8], r11
00007eff8a7d05e5  lea r14, [rax+0x150]
00007eff8a7d05ec  mov [r15+0xF8], r14
00007eff8a7d05f3  mov rax, [r15+0xF0]
00007eff8a7d05fa  mov [r15+0x100], rax
00007eff8a7d0601  jmp 0x00007EFF8A7CE5C0
00007eff8a7d0606  int3
00007eff8a7d0607  call 0x00007EFF8A6E27E0
00007eff8a7d060c  jmp 0x00007EFF8A7D0533
00007eff8a7d0611  call 0x00007EFF8A6E1570
00007eff8a7d0616  jmp 0x00007EFF8A7D053F
00007eff8a7d061b  call 0x00007EFF8A6E27E0
00007eff8a7d0620  jmp 0x00007EFF8A7D0559
00007eff8a7d0625  call 0x00007EFF8A6E1570
00007eff8a7d062a  jmp 0x00007EFF8A7D0565
00007eff8a7d062f  call 0x00007EFF8A6E27E0
00007eff8a7d0634  jmp 0x00007EFF8A7D057F
00007eff8a7d0639  call 0x00007EFF8A6E1570
00007eff8a7d063e  jmp 0x00007EFF8A7D058B
00007eff8a7d0643  call 0x00007EFF8A6E27E0
00007eff8a7d0648  jmp 0x00007EFF8A7D05A5
00007eff8a7d064d  call 0x00007EFF8A6E1570
00007eff8a7d0652  jmp 0x00007EFF8A7D05B1
00007eff8a7d0657  call 0x00007EFF8A6E27E0
00007eff8a7d065c  jmp 0x00007EFF8A7D05CB
00007eff8a7d0661  call 0x00007EFF8A6E1570
00007eff8a7d0666  jmp 0x00007EFF8A7D05D7
00007eff8a7d066b  int3
00007eff8a7d066c  nop [rax], eax
00007eff8a7d0670  mov eax, [r15+0xA0]
00007eff8a7d0677  mov [rsp+0x10], eax
00007eff8a7d067b  xor eax, eax
00007eff8a7d067d  mov r14d, [rsp+0x10]
00007eff8a7d0682  sub r14d, 0x01
00007eff8a7d0686  cmc
00007eff8a7d0687  lahf
00007eff8a7d0688  seto al
00007eff8a7d068b  mov [r15+0x108], eax
00007eff8a7d0692  mov r14d, r14d
00007eff8a7d0695  mov [r15+0xA0], r14
00007eff8a7d069c  mov eax, [r15+0x108]
00007eff8a7d06a3  sahf
00007eff8a7d06a4  jnz 0x00007EFF8A7D06D6
00007eff8a7d06a6  cmp dword ptr [r15+0x318], 0x00
00007eff8a7d06ae  jz 0x00007EFF8A7D07A0
00007eff8a7d06b4  nop [rax+rax*1], ax
00007eff8a7d06bd  nop [rax+rax*1], eax
00007eff8a7d06c5  mov eax, 0x41027C
00007eff8a7d06ca  mov [r15+0x100], rax
00007eff8a7d06d1  jmp 0x00007EFF8A5FE110
00007eff8a7d06d6  cmp dword ptr [r15+0x318], 0x00
00007eff8a7d06de  jz 0x00007EFF8A7D0710
00007eff8a7d06e4  nop [rax+rax*1], ax
00007eff8a7d06ed  nop [rax+rax*1], eax
00007eff8a7d06f5  mov eax, 0x410264
00007eff8a7d06fa  mov [r15+0x100], rax
00007eff8a7d0701  jmp 0x00007EFF8A5FE110
00007eff8a7d0706  int3
00007eff8a7d0707  int3
00007eff8a7d0708  nop [rax+rax*1], eax
00007eff8a7d0710  mov rax, [r15+0xF8]
00007eff8a7d0717  mov [r15], rax
00007eff8a7d071a  mov rax, [r15+0x98]
00007eff8a7d0721  mov [r15+0x08], rax
00007eff8a7d0725  mov qword ptr [r15+0x10], 0x12C
00007eff8a7d072d  mov qword ptr [r15+0xF0], 0x410274
00007eff8a7d0738  mov r14d, [r15+0x320]
00007eff8a7d073f  mov eax, 0x410274
00007eff8a7d0744  mov rcx, 0x7EFF8A7D0670
00007eff8a7d074e  mov [r15+r14*8+0x328], rax
00007eff8a7d0756  mov [r15+r14*8+0x368], rcx
00007eff8a7d075e  add r14d, 0x01
00007eff8a7d0762  and r14d, 0x07
00007eff8a7d0766  mov [r15+0x320], r14d
00007eff8a7d076d  cmp dword ptr [r15+0x318], 0x00
00007eff8a7d0775  jz 0x00007EFF8A7CEC20
00007eff8a7d077b  nop [rax+rax*1], ax
00007eff8a7d0784  nop [rax+rax*1], eax
00007eff8a7d078c  mov eax, 0x410338
00007eff8a7d0791  mov [r15+0x100], rax
00007eff8a7d0798  jmp 0x00007EFF8A5FE110
00007eff8a7d079d  int3
00007eff8a7d079e  int3
00007eff8a7d079f  nop
00007eff8a7d07a0  mov rax, [r15+0xF8]
00007eff8a7d07a7  lea r14, [rax+0x20]
00007eff8a7d07ab  mov r12, [r13+r14*1]
00007eff8a7d07b0  mov [r15+0x98], r12
00007eff8a7d07b7  mov qword ptr [r15+0x40], 0x80
00007eff8a7d07bf  mov [r15], rax
00007eff8a7d07c2  lea r14, [rax+0x8C]
00007eff8a7d07c9  mov [r15+0x08], r14
00007eff8a7d07cd  mov qword ptr [r15+0x10], 0x01
00007eff8a7d07d5  lea r14, [rax+0x8C]
00007eff8a7d07dc  mov eax, 0x80
00007eff8a7d07e1  mov [r13+r14*1], al
00007eff8a7d07e6  mov qword ptr [r15+0xF0], 0x410298
00007eff8a7d07f1  mov r14d, [r15+0x320]
00007eff8a7d07f8  mov eax, 0x410298
00007eff8a7d07fd  mov rcx, 0x7EFF8A7D0870
00007eff8a7d0807  mov [r15+r14*8+0x328], rax
00007eff8a7d080f  mov [r15+r14*8+0x368], rcx
00007eff8a7d0817  add r14d, 0x01
00007eff8a7d081b  and r14d, 0x07
00007eff8a7d081f  mov [r15+0x320], r14d
00007eff8a7d0826  cmp dword ptr [r15+0x318], 0x00
00007eff8a7d082e  jz 0x00007EFF8A7CEC20
00007eff8a7d0834  nop [rax+rax*1], ax
00007eff8a7d083d  nop [rax+rax*1], eax
00007eff8a7d0845  mov eax, 0x410338
00007eff8a7d084a  mov [r15+0x100], rax
00007eff8a7d0851  jmp 0x00007EFF8A5FE110
00007eff8a7d0856  int3
00007eff8a7d0857  call 0x00007EFF8A6E27E0
00007eff8a7d085c  jmp 0x00007EFF8A7D07B0
00007eff8a7d0861  call 0x00007EFF8A6D5AF0
00007eff8a7d0866  jmp 0x00007EFF8A7D07E6
00007eff8a7d086b  int3
00007eff8a7d086c  nop [rax], eax
00007eff8a7d0870  mov rax, [r15+0xF8]
00007eff8a7d0877  lea r14, [rax+0x68]
00007eff8a7d087b  mov r12, [r13+r14*1]
00007eff8a7d0880  mov [r15+0x40], r12
00007eff8a7d0884  lea r14, [rax+0x88]
00007eff8a7d088b  xor eax, eax
00007eff8a7d088d  mov [r13+r14*1], al
00007eff8a7d0892  xor eax, eax
00007eff8a7d0894  mov r14d, 0x38
00007eff8a7d089a  cmp r12, r14
00007eff8a7d089d  cmc
00007eff8a7d089e  lahf
00007eff8a7d089f  seto al
00007eff8a7d08a2  mov [r15+0x108], eax
00007eff8a7d08a9  mov eax, [r15+0x108]
00007eff8a7d08b0  sahf
00007eff8a7d08b1  jz 0x00007EFF8A7D08E3
00007eff8a7d08b3  cmp dword ptr [r15+0x318], 0x00
00007eff8a7d08bb  jz 0x00007EFF8A7D0930
00007eff8a7d08c1  nop [rax+rax*1], ax
00007eff8a7d08ca  nop [rax+rax*1], eax
00007eff8a7d08d2  mov eax, 0x4102A8
00007eff8a7d08d7  mov [r15+0x100], rax
00007eff8a7d08de  jmp 0x00007EFF8A5FE110
00007eff8a7d08e3  cmp dword ptr [r15+0x318], 0x00
00007eff8a7d08eb  jz 0x00007EFF8A7D0A70
00007eff8a7d08f1  nop [rax+rax*1], ax
00007eff8a7d08fa  nop [rax+rax*1], eax
00007eff8a7d0902  mov eax, 0x4102C4
00007eff8a7d0907  mov [r15+0x100], rax
00007eff8a7d090e  jmp 0x00007EFF8A5FE110
00007eff8a7d0913  int3
00007eff8a7d0914  call 0x00007EFF8A6E27E0
00007eff8a7d0919  jmp 0x00007EFF8A7D0880
00007eff8a7d091e  call 0x00007EFF8A6D5AF0
00007eff8a7d0923  jmp 0x00007EFF8A7D0892
00007eff8a7d0928  int3
00007eff8a7d0929  nop [rax], eax
00007eff8a7d0930  mov rax, [r15+0xF8]
00007eff8a7d0937  mov [r15], rax
00007eff8a7d093a  lea r14, [rax+0x88]
00007eff8a7d0941  mov [r15+0x08], r14
00007eff8a7d0945  mov qword ptr [r15+0x10], 0x01
00007eff8a7d094d  mov qword ptr [r15+0xF0], 0x4102B8
00007eff8a7d0958  mov r14d, [r15+0x320]
00007eff8a7d095f  mov eax, 0x4102B8
00007eff8a7d0964  mov rcx, 0x7EFF8A7D09C0
00007eff8a7d096e  mov [r15+r14*8+0x328], rax
00007eff8a7d0976  mov [r15+r14*8+0x368], rcx
00007eff8a7d097e  add r14d, 0x01
00007eff8a7d0982  and r14d, 0x07
00007eff8a7d0986  mov [r15+0x320], r14d
00007eff8a7d098d  cmp dword ptr [r15+0x318], 0x00
00007eff8a7d0995  jz 0x00007EFF8A7CEC20
00007eff8a7d099b  nop [rax+rax*1], ax
00007eff8a7d09a4  nop [rax+rax*1], eax
00007eff8a7d09ac  mov eax, 0x410338
00007eff8a7d09b1  mov [r15+0x100], rax
00007eff8a7d09b8  jmp 0x00007EFF8A5FE110
00007eff8a7d09bd  int3
00007eff8a7d09be  int3
00007eff8a7d09bf  nop
00007eff8a7d09c0  mov rax, [r15+0xF8]
00007eff8a7d09c7  lea r14, [rax+0x68]
00007eff8a7d09cb  mov rax, [r13+r14*1]
00007eff8a7d09d0  mov [r15+0x40], rax
00007eff8a7d09d4  mov [rsp+0x10], rax
00007eff8a7d09d9  xor eax, eax
00007eff8a7d09db  mov r14, [rsp+0x10]
00007eff8a7d09e0  mov r12d, 0x38
00007eff8a7d09e6  cmp r14, r12
00007eff8a7d09e9  cmc
00007eff8a7d09ea  lahf
00007eff8a7d09eb  seto al
00007eff8a7d09ee  mov [r15+0x108], eax
00007eff8a7d09f5  mov eax, [r15+0x108]
00007eff8a7d09fc  sahf
00007eff8a7d09fd  jnz 0x00007EFF8A7D0A2F
00007eff8a7d09ff  cmp dword ptr [r15+0x318], 0x00
00007eff8a7d0a07  jz 0x00007EFF8A7D0A70
00007eff8a7d0a0d  nop [rax+rax*1], ax
00007eff8a7d0a16  nop [rax+rax*1], eax
00007eff8a7d0a1e  mov eax, 0x4102C4
00007eff8a7d0a23  mov [r15+0x100], rax
00007eff8a7d0a2a  jmp 0x00007EFF8A5FE110
00007eff8a7d0a2f  cmp dword ptr [r15+0x318], 0x00
00007eff8a7d0a37  jz 0x00007EFF8A7D0930
00007eff8a7d0a3d  nop [rax+rax*1], ax
00007eff8a7d0a46  nop [rax+rax*1], eax
00007eff8a7d0a4e  mov eax, 0x4102A8
00007eff8a7d0a53  mov [r15+0x100], rax
00007eff8a7d0a5a  jmp 0x00007EFF8A5FE110
00007eff8a7d0a5f  int3
00007eff8a7d0a60  call 0x00007EFF8A6D59C0
00007eff8a7d0a65  jmp 0x00007EFF8A7D09D0
00007eff8a7d0a6a  int3
00007eff8a7d0a6b  nop [rax+rax*1], eax
00007eff8a7d0a70  mov rax, [r15+0x98]
00007eff8a7d0a77  rorx r14, rax, 0x3D
00007eff8a7d0a7d  and r14, 0xFFFFFFFFFFFFFFF8
00007eff8a7d0a81  mov rax, [r15+0xF8]
00007eff8a7d0a88  mov [r15], rax
00007eff8a7d0a8b  lea r12, [rax+0x78]
00007eff8a7d0a8f  mov [r15+0x08], r12
00007eff8a7d0a93  mov qword ptr [r15+0x10], 0x08
00007eff8a7d0a9b  bswap r14
00007eff8a7d0a9e  mov [r15+0x40], r14
00007eff8a7d0aa2  lea r12, [rax+0x78]
00007eff8a7d0aa6  mov [r13+r12*1], r14
00007eff8a7d0aab  mov qword ptr [r15+0xF0], 0x4102E0
00007eff8a7d0ab6  mov r14d, [r15+0x320]
00007eff8a7d0abd  mov eax, 0x4102E0
00007eff8a7d0ac2  mov rcx, 0x7EFF8A7D0B30
00007eff8a7d0acc  mov [r15+r14*8+0x328], rax
00007eff8a7d0ad4  mov [r15+r14*8+0x368], rcx
00007eff8a7d0adc  add r14d, 0x01
00007eff8a7d0ae0  and r14d, 0x07
00007eff8a7d0ae4  mov [r15+0x320], r14d
00007eff8a7d0aeb  cmp dword ptr [r15+0x318], 0x00
00007eff8a7d0af3  jz 0x00007EFF8A7CEC20
00007eff8a7d0af9  nop [rax+rax*1], ax
00007eff8a7d0b02  nop [rax+rax*1], eax
00007eff8a7d0b0a  mov eax, 0x410338
00007eff8a7d0b0f  mov [r15+0x100], rax
00007eff8a7d0b16  jmp 0x00007EFF8A5FE110
00007eff8a7d0b1b  int3
00007eff8a7d0b1c  call 0x00007EFF8A6C3FE0
00007eff8a7d0b21  jmp 0x00007EFF8A7D0AAB
00007eff8a7d0b26  int3
00007eff8a7d0b27  nop [rax+rax*1], ax
00007eff8a7d0b30  mov rax, [r15+0xF8]
00007eff8a7d0b37  mov r14d, [r13+rax*1]
00007eff8a7d0b3c  lea r12, [rax+0x04]
00007eff8a7d0b40  mov r11d, [r13+r12*1]
00007eff8a7d0b45  lea r12, [rax+0x08]
00007eff8a7d0b49  mov r10d, [r13+r12*1]
00007eff8a7d0b4e  lea r12, [rax+0x0C]
00007eff8a7d0b52  mov r9d, [r13+r12*1]
00007eff8a7d0b57  mov qword ptr [r15+0x48], 0x430860
00007eff8a7d0b5f  lea r12, [rax+0x80]
00007eff8a7d0b66  mov r8, [r13+r12*1]
00007eff8a7d0b6b  mov [r15+0xF0], r8
00007eff8a7d0b72  bswap r14d
00007eff8a7d0b75  bswap r11d
00007eff8a7d0b78  mov r12d, 0x430860
00007eff8a7d0b7e  mov [r13+r12*1], r14d
00007eff8a7d0b83  mov r14d, 0x430864
00007eff8a7d0b89  mov [r13+r14*1], r11d
00007eff8a7d0b8e  bswap r10d
00007eff8a7d0b91  bswap r9d
00007eff8a7d0b94  lea r14, [rax+0x10]
00007eff8a7d0b98  mov r12d, [r13+r14*1]
00007eff8a7d0b9d  lea r14, [rax+0x14]
00007eff8a7d0ba1  mov r11d, [r13+r14*1]
00007eff8a7d0ba6  mov r14d, 0x430868
00007eff8a7d0bac  mov [r13+r14*1], r10d
00007eff8a7d0bb1  mov r14d, 0x43086C
00007eff8a7d0bb7  mov [r13+r14*1], r9d
00007eff8a7d0bbc  lea r14, [rax+0x90]
00007eff8a7d0bc3  mov r10, [r13+r14*1]
00007eff8a7d0bc8  lea r14, [rax+0x98]
00007eff8a7d0bcf  mov r9, [r13+r14*1]
00007eff8a7d0bd4  mov [r15+0xA0], r10
00007eff8a7d0bdb  mov [r15+0x98], r9
00007eff8a7d0be2  bswap r12d
00007eff8a7d0be5  bswap r11d
00007eff8a7d0be8  mov [rsp+0x10], r11d
00007eff8a7d0bed  mov r11d, r11d
00007eff8a7d0bf0  mov [r15+0x58], r11
00007eff8a7d0bf4  lea r14, [rax+0x18]
00007eff8a7d0bf8  mov r11d, [r13+r14*1]
00007eff8a7d0bfd  lea r14, [rax+0x1C]
00007eff8a7d0c01  mov r10d, [r13+r14*1]
00007eff8a7d0c06  mov [rsp+0x20], r10d
00007eff8a7d0c0b  mov r10d, r10d
00007eff8a7d0c0e  mov [r15+0x60], r10
00007eff8a7d0c12  mov r14d, 0x430870
00007eff8a7d0c18  mov [r13+r14*1], r12d
00007eff8a7d0c1d  mov r14d, 0x430874
00007eff8a7d0c23  mov r12d, [rsp+0x10]
00007eff8a7d0c28  mov [r13+r14*1], r12d
00007eff8a7d0c2d  bswap r11d
00007eff8a7d0c30  mov [rsp+0x10], r11d
00007eff8a7d0c35  mov r11d, r11d
00007eff8a7d0c38  mov [r15+0x40], r11
00007eff8a7d0c3c  mov r14d, [rsp+0x20]
00007eff8a7d0c41  bswap r14d
00007eff8a7d0c44  mov [rsp+0x20], r14d
00007eff8a7d0c49  mov r14d, r14d
00007eff8a7d0c4c  mov [r15+0x50], r14
00007eff8a7d0c50  mov r14d, 0x430878
00007eff8a7d0c56  mov r12d, [rsp+0x10]
00007eff8a7d0c5b  mov [r13+r14*1], r12d
00007eff8a7d0c60  mov r14d, 0x43087C
00007eff8a7d0c66  mov r12d, [rsp+0x20]
00007eff8a7d0c6b  mov [r13+r14*1], r12d
00007eff8a7d0c70  lea r14, [rax+0xA0]
00007eff8a7d0c77  mov [r15+0xF8], r14
00007eff8a7d0c7e  mov [r15+0x100], r8
00007eff8a7d0c85  jmp 0x00007EFF8A7CE5C0
00007eff8a7d0c8a  int3
00007eff8a7d0c8b  call 0x00007EFF8A60DAE0
00007eff8a7d0c90  jmp 0x00007EFF8A7D0B3C
00007eff8a7d0c95  call 0x00007EFF8A6C0230
00007eff8a7d0c9a  jmp 0x00007EFF8A7D0B45
00007eff8a7d0c9f  call 0x00007EFF8A6BEFC0
00007eff8a7d0ca4  jmp 0x00007EFF8A7D0B4E
00007eff8a7d0ca9  call 0x00007EFF8A6BDD50
00007eff8a7d0cae  jmp 0x00007EFF8A7D0B57
00007eff8a7d0cb3  call 0x00007EFF8A6BCC20
00007eff8a7d0cb8  jmp 0x00007EFF8A7D0B6B
00007eff8a7d0cbd  call 0x00007EFF8A6C3EA0
00007eff8a7d0cc2  jmp 0x00007EFF8A7D0B83
00007eff8a7d0cc7  call 0x00007EFF8A6E1920
00007eff8a7d0ccc  jmp 0x00007EFF8A7D0B8E
00007eff8a7d0cd1  call 0x00007EFF8A6E26A0
00007eff8a7d0cd6  jmp 0x00007EFF8A7D0B9D
00007eff8a7d0cdb  call 0x00007EFF8A6E1430
00007eff8a7d0ce0  jmp 0x00007EFF8A7D0BA6
00007eff8a7d0ce5  call 0x00007EFF8A6E06B0
00007eff8a7d0cea  jmp 0x00007EFF8A7D0BB1
00007eff8a7d0cef  call 0x00007EFF8A6DF440
00007eff8a7d0cf4  jmp 0x00007EFF8A7D0BBC
00007eff8a7d0cf9  call 0x00007EFF8A6E0300
00007eff8a7d0cfe  jmp 0x00007EFF8A7D0BC8
00007eff8a7d0d03  call 0x00007EFF8A6DF090
00007eff8a7d0d08  jmp 0x00007EFF8A7D0BD4
00007eff8a7d0d0d  call 0x00007EFF8A6E1430
00007eff8a7d0d12  jmp 0x00007EFF8A7D0BFD
00007eff8a7d0d17  call 0x00007EFF8A6E01C0
00007eff8a7d0d1c  jmp 0x00007EFF8A7D0C06
00007eff8a7d0d21  call 0x00007EFF8A6E2BA0
00007eff8a7d0d26  jmp 0x00007EFF8A7D0C1D
00007eff8a7d0d2b  call 0x00007EFF8A6E2BA0
00007eff8a7d0d30  jmp 0x00007EFF8A7D0C2D
00007eff8a7d0d35  call 0x00007EFF8A6E2BA0
00007eff8a7d0d3a  jmp 0x00007EFF8A7D0C60
00007eff8a7d0d3f  call 0x00007EFF8A6E2BA0
00007eff8a7d0d44  jmp 0x00007EFF8A7D0C70
00007eff8a7d0d49  int3
00007eff8a7d0d4a  nop [rax+rax*1], ax
00007eff8a7d0d50  mov qword ptr [r15+0x100], 0x04
00007eff8a7d0d5b  mov esi, 0x00
00007eff8a7d0d60  mov edx, 0x09
00007eff8a7d0d65  mov rdi, 0x7FFEB66B8B40
00007eff8a7d0d6f  mov rax, 0x5DB6371FC970
00007eff8a7d0d79  call rax
00007eff8a7d0d7b  cmp dword ptr [r15+0x318], 0x00
00007eff8a7d0d83  jnz 0x00007EFF8A5FE110
00007eff8a7d0d89  jmp 0x00007EFF8A5FE0A0
00007eff8a7d0d8e  int3
00007eff8a7d0d8f  int3
