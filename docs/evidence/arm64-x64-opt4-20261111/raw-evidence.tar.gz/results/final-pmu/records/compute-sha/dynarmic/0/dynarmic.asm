00007ec99e3ce69b  nop [rax+rax*1], eax
00007ec99e3ce6a0  mov rax, [r15+0xF8]
00007ec99e3ce6a7  lea r14, [rax-0xA0]
00007ec99e3ce6ae  mov [r15+0xF8], r14
00007ec99e3ce6b5  lea rax, [r14+0x90]
00007ec99e3ce6bc  mov r12, [r15+0xA0]
00007ec99e3ce6c3  mov r11, [r15+0x98]
00007ec99e3ce6ca  mov [r13+rax*1], r12
00007ec99e3ce6cf  lea rax, [r14+0x98]
00007ec99e3ce6d6  mov [r13+rax*1], r11
00007ec99e3ce6db  mov eax, 0x420670
00007ec99e3ce6e0  movups xmm1, [r13+rax*1]
00007ec99e3ce6e6  mov eax, 0x420610
00007ec99e3ce6eb  movups xmm15, [r13+rax*1]
00007ec99e3ce6f1  mov eax, 0x420690
00007ec99e3ce6f6  movups xmm14, [r13+rax*1]
00007ec99e3ce6fc  mov eax, 0x420630
00007ec99e3ce701  movups xmm13, [r13+rax*1]
00007ec99e3ce707  mov qword ptr [r15+0x98], 0x4308A0
00007ec99e3ce712  mov eax, 0x4206A0
00007ec99e3ce717  movups xmm12, [r13+rax*1]
00007ec99e3ce71d  mov eax, 0x4308A0
00007ec99e3ce722  movups [r13+rax*1], xmm1
00007ec99e3ce728  mov eax, 0x4308B0
00007ec99e3ce72d  movups [r13+rax*1], xmm15
00007ec99e3ce733  mov eax, 0x4308C0
00007ec99e3ce738  movups [r13+rax*1], xmm14
00007ec99e3ce73e  mov eax, 0x4308D0
00007ec99e3ce743  movups [r13+rax*1], xmm13
00007ec99e3ce749  mov eax, 0x420600
00007ec99e3ce74e  movups xmm14, [r13+rax*1]
00007ec99e3ce754  mov eax, 0x4205F0
00007ec99e3ce759  movups xmm13, [r13+rax*1]
00007ec99e3ce75f  mov eax, 0x4309A0
00007ec99e3ce764  movups [r13+rax*1], xmm1
00007ec99e3ce76a  mov eax, 0x4309B0
00007ec99e3ce76f  movups [r13+rax*1], xmm15
00007ec99e3ce775  mov eax, 0x4308E0
00007ec99e3ce77a  movups [r13+rax*1], xmm12
00007ec99e3ce780  mov eax, 0x4308F0
00007ec99e3ce785  movups [r13+rax*1], xmm14
00007ec99e3ce78b  mov eax, 0x4205E0
00007ec99e3ce790  movups xmm1, [r13+rax*1]
00007ec99e3ce796  mov eax, 0x420640
00007ec99e3ce79b  movups xmm15, [r13+rax*1]
00007ec99e3ce7a1  mov eax, 0x430900
00007ec99e3ce7a6  movups [r13+rax*1], xmm13
00007ec99e3ce7ac  mov eax, 0x430910
00007ec99e3ce7b1  movups [r13+rax*1], xmm1
00007ec99e3ce7b7  mov eax, 0x420650
00007ec99e3ce7bc  movups xmm1, [r13+rax*1]
00007ec99e3ce7c2  mov eax, 0x420620
00007ec99e3ce7c7  movups xmm14, [r13+rax*1]
00007ec99e3ce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
00007ec99e3ce7d5  mov eax, 0x430920
00007ec99e3ce7da  movups [r13+rax*1], xmm15
00007ec99e3ce7e0  mov eax, 0x430930
00007ec99e3ce7e5  movups [r13+rax*1], xmm1
00007ec99e3ce7eb  mov eax, 0x4206C0
00007ec99e3ce7f0  movups xmm1, [r13+rax*1]
00007ec99e3ce7f6  mov eax, 0x4206D0
00007ec99e3ce7fb  movups xmm15, [r13+rax*1]
00007ec99e3ce801  movaps [r15+0x150], xmm15
00007ec99e3ce809  mov qword ptr [r15+0xA0], 0x3E8
00007ec99e3ce814  mov eax, 0x430940
00007ec99e3ce819  movups [r13+rax*1], xmm14
00007ec99e3ce81f  mov eax, 0x430950
00007ec99e3ce824  movups [r13+rax*1], xmm1
00007ec99e3ce82a  mov eax, 0x4206B0
00007ec99e3ce82f  movups xmm1, [r13+rax*1]
00007ec99e3ce835  mov eax, 0x420660
00007ec99e3ce83a  movups xmm14, [r13+rax*1]
00007ec99e3ce840  movaps [r15+0x140], xmm14
00007ec99e3ce848  lea rax, [r14+0x80]
00007ec99e3ce84f  mov r12, [r15+0xF0]
00007ec99e3ce856  mov [r13+rax*1], r12
00007ec99e3ce85b  mov eax, 0x430960
00007ec99e3ce860  movups [r13+rax*1], xmm15
00007ec99e3ce866  mov eax, 0x430970
00007ec99e3ce86b  movups [r13+rax*1], xmm1
00007ec99e3ce871  mov eax, 0x420680
00007ec99e3ce876  movups xmm1, [r13+rax*1]
00007ec99e3ce87c  mov eax, 0x4206E0
00007ec99e3ce881  mov r12, [r13+rax*1]
00007ec99e3ce886  movq xmm15, r12
00007ec99e3ce88b  mov qword ptr [r15+0x40], 0x4206E8
00007ec99e3ce893  mov eax, 0x430980
00007ec99e3ce898  movups [r13+rax*1], xmm14
00007ec99e3ce89e  mov eax, 0x430990
00007ec99e3ce8a3  movups [r13+rax*1], xmm1
00007ec99e3ce8a9  mov eax, 0x420748
00007ec99e3ce8ae  movups xmm1, [r13+rax*1]
00007ec99e3ce8b4  movq rax, xmm15
00007ec99e3ce8b9  mov r12d, 0x4309C0
00007ec99e3ce8bf  mov [r13+r12*1], rax
00007ec99e3ce8c4  mov eax, 0x420728
00007ec99e3ce8c9  movups xmm15, [r13+rax*1]
00007ec99e3ce8cf  mov eax, 0x420738
00007ec99e3ce8d4  movups xmm14, [r13+rax*1]
00007ec99e3ce8da  lea rax, [r14+0x60]
00007ec99e3ce8de  movups [r13+rax*1], xmm1
00007ec99e3ce8e4  mov eax, 0x4309C8
00007ec99e3ce8e9  mov r12d, 0x421DF8D3
00007ec99e3ce8ef  mov [r13+rax*1], r12d
00007ec99e3ce8f4  lea rax, [r14+0x40]
00007ec99e3ce8f8  movups [r13+rax*1], xmm15
00007ec99e3ce8fe  lea rax, [r14+0x50]
00007ec99e3ce902  movups [r13+rax*1], xmm14
00007ec99e3ce908  mov eax, 0x4206E8
00007ec99e3ce90d  movups xmm1, [r13+rax*1]
00007ec99e3ce913  mov eax, 0x4206F8
00007ec99e3ce918  movups xmm15, [r13+rax*1]
00007ec99e3ce91e  movaps [r15+0x120], xmm15
00007ec99e3ce926  movups [r13+r14*1], xmm1
00007ec99e3ce92c  lea rax, [r14+0x10]
00007ec99e3ce930  movups [r13+rax*1], xmm15
00007ec99e3ce936  mov eax, 0x420708
00007ec99e3ce93b  movups xmm1, [r13+rax*1]
00007ec99e3ce941  mov eax, 0x420718
00007ec99e3ce946  movups xmm15, [r13+rax*1]
00007ec99e3ce94c  movaps [r15+0x110], xmm1
00007ec99e3ce954  movaps [r15+0x130], xmm15
00007ec99e3ce95c  lea rax, [r14+0x20]
00007ec99e3ce960  movups [r13+rax*1], xmm1
00007ec99e3ce966  lea rax, [r14+0x30]
00007ec99e3ce96a  movups [r13+rax*1], xmm15
00007ec99e3ce970  mov [r15], r14
00007ec99e3ce973  mov qword ptr [r15+0x08], 0x4308A0
00007ec99e3ce97b  mov qword ptr [r15+0x10], 0x12C
00007ec99e3ce983  mov qword ptr [r15+0xF0], 0x410274
00007ec99e3ce98e  mov r14d, [r15+0x320]
00007ec99e3ce995  mov eax, 0x410274
00007ec99e3ce99a  mov rcx, 0x7EC99E3D0670
00007ec99e3ce9a4  mov [r15+r14*8+0x328], rax
00007ec99e3ce9ac  mov [r15+r14*8+0x368], rcx
00007ec99e3ce9b4  add r14d, 0x01
00007ec99e3ce9b8  and r14d, 0x07
00007ec99e3ce9bc  mov [r15+0x320], r14d
00007ec99e3ce9c3  cmp dword ptr [r15+0x318], 0x00
00007ec99e3ce9cb  jz 0x00007EC99E3CEC20
00007ec99e3ce9d1  nop [rax+rax*1], ax
00007ec99e3ce9da  nop [rax+rax*1], eax
00007ec99e3ce9e2  mov eax, 0x410338
00007ec99e3ce9e7  mov [r15+0x100], rax
00007ec99e3ce9ee  jmp 0x00007EC99E1FE110
00007ec99e3ce9f3  int3
00007ec99e3ce9f4  call 0x00007EC99E20BC20
00007ec99e3ce9f9  jmp 0x00007EC99E3CE6CF
00007ec99e3ce9fe  call 0x00007EC99E20A9A0
00007ec99e3cea03  jmp 0x00007EC99E3CE6DB
00007ec99e3cea08  call 0x00007EC99E1FF430
00007ec99e3cea0d  jmp 0x00007EC99E3CE6E6
00007ec99e3cea12  call 0x00007EC99E20E760
00007ec99e3cea17  jmp 0x00007EC99E3CE6F1
00007ec99e3cea1c  call 0x00007EC99E20D4E0
00007ec99e3cea21  jmp 0x00007EC99E3CE6FC
00007ec99e3cea26  call 0x00007EC99E20C260
00007ec99e3cea2b  jmp 0x00007EC99E3CE707
00007ec99e3cea30  call 0x00007EC99E20AFE0
00007ec99e3cea35  jmp 0x00007EC99E3CE71D
00007ec99e3cea3a  call 0x00007EC99E1FF540
00007ec99e3cea3f  jmp 0x00007EC99E3CE728
00007ec99e3cea44  call 0x00007EC99E20E880
00007ec99e3cea49  jmp 0x00007EC99E3CE733
00007ec99e3cea4e  call 0x00007EC99E20D600
00007ec99e3cea53  jmp 0x00007EC99E3CE73E
00007ec99e3cea58  call 0x00007EC99E20C380
00007ec99e3cea5d  jmp 0x00007EC99E3CE749
00007ec99e3cea62  call 0x00007EC99E20D4E0
00007ec99e3cea67  jmp 0x00007EC99E3CE754
00007ec99e3cea6c  call 0x00007EC99E20C260
00007ec99e3cea71  jmp 0x00007EC99E3CE75F
00007ec99e3cea76  call 0x00007EC99E1FF540
00007ec99e3cea7b  jmp 0x00007EC99E3CE76A
00007ec99e3cea80  call 0x00007EC99E20E880
00007ec99e3cea85  jmp 0x00007EC99E3CE775
00007ec99e3cea8a  call 0x00007EC99E20B100
00007ec99e3cea8f  jmp 0x00007EC99E3CE780
00007ec99e3cea94  call 0x00007EC99E20D600
00007ec99e3cea99  jmp 0x00007EC99E3CE78B
00007ec99e3cea9e  call 0x00007EC99E1FF430
00007ec99e3ceaa3  jmp 0x00007EC99E3CE796
00007ec99e3ceaa8  call 0x00007EC99E20E760
00007ec99e3ceaad  jmp 0x00007EC99E3CE7A1
00007ec99e3ceab2  call 0x00007EC99E20C380
00007ec99e3ceab7  jmp 0x00007EC99E3CE7AC
00007ec99e3ceabc  call 0x00007EC99E1FF540
00007ec99e3ceac1  jmp 0x00007EC99E3CE7B7
00007ec99e3ceac6  call 0x00007EC99E1FF430
00007ec99e3ceacb  jmp 0x00007EC99E3CE7C2
00007ec99e3cead0  call 0x00007EC99E20D4E0
00007ec99e3cead5  jmp 0x00007EC99E3CE7CD
00007ec99e3ceada  call 0x00007EC99E20E880
00007ec99e3ceadf  jmp 0x00007EC99E3CE7E0
00007ec99e3ceae4  call 0x00007EC99E1FF540
00007ec99e3ceae9  jmp 0x00007EC99E3CE7EB
00007ec99e3ceaee  call 0x00007EC99E1FF430
00007ec99e3ceaf3  jmp 0x00007EC99E3CE7F6
00007ec99e3ceaf8  call 0x00007EC99E20E760
00007ec99e3ceafd  jmp 0x00007EC99E3CE801
00007ec99e3ceb02  call 0x00007EC99E20D600
00007ec99e3ceb07  jmp 0x00007EC99E3CE81F
00007ec99e3ceb0c  call 0x00007EC99E1FF540
00007ec99e3ceb11  jmp 0x00007EC99E3CE82A
00007ec99e3ceb16  call 0x00007EC99E1FF430
00007ec99e3ceb1b  jmp 0x00007EC99E3CE835
00007ec99e3ceb20  call 0x00007EC99E20D4E0
00007ec99e3ceb25  jmp 0x00007EC99E3CE840
00007ec99e3ceb2a  call 0x00007EC99E20BC20
00007ec99e3ceb2f  jmp 0x00007EC99E3CE85B
00007ec99e3ceb34  call 0x00007EC99E20E880
00007ec99e3ceb39  jmp 0x00007EC99E3CE866
00007ec99e3ceb3e  call 0x00007EC99E1FF540
00007ec99e3ceb43  jmp 0x00007EC99E3CE871
00007ec99e3ceb48  call 0x00007EC99E1FF430
00007ec99e3ceb4d  jmp 0x00007EC99E3CE87C
00007ec99e3ceb52  call 0x00007EC99E20B720
00007ec99e3ceb57  jmp 0x00007EC99E3CE886
00007ec99e3ceb5c  call 0x00007EC99E20D600
00007ec99e3ceb61  jmp 0x00007EC99E3CE89E
00007ec99e3ceb66  call 0x00007EC99E1FF540
00007ec99e3ceb6b  jmp 0x00007EC99E3CE8A9
00007ec99e3ceb70  call 0x00007EC99E1FF430
00007ec99e3ceb75  jmp 0x00007EC99E3CE8B4
00007ec99e3ceb7a  call 0x00007EC99E2B4CB0
00007ec99e3ceb7f  jmp 0x00007EC99E3CE8C4
00007ec99e3ceb84  call 0x00007EC99E20E760
00007ec99e3ceb89  jmp 0x00007EC99E3CE8CF
00007ec99e3ceb8e  call 0x00007EC99E20D4E0
00007ec99e3ceb93  jmp 0x00007EC99E3CE8DA
00007ec99e3ceb98  call 0x00007EC99E1FF540
00007ec99e3ceb9d  jmp 0x00007EC99E3CE8E4
00007ec99e3ceba2  call 0x00007EC99E20BAE0
00007ec99e3ceba7  jmp 0x00007EC99E3CE8F4
00007ec99e3cebac  call 0x00007EC99E20E880
00007ec99e3cebb1  jmp 0x00007EC99E3CE8FE
00007ec99e3cebb6  call 0x00007EC99E20D600
00007ec99e3cebbb  jmp 0x00007EC99E3CE908
00007ec99e3cebc0  call 0x00007EC99E1FF430
00007ec99e3cebc5  jmp 0x00007EC99E3CE913
00007ec99e3cebca  call 0x00007EC99E20E760
00007ec99e3cebcf  jmp 0x00007EC99E3CE91E
00007ec99e3cebd4  call 0x00007EC99E2D6600
00007ec99e3cebd9  jmp 0x00007EC99E3CE92C
00007ec99e3cebde  call 0x00007EC99E20E880
00007ec99e3cebe3  jmp 0x00007EC99E3CE936
00007ec99e3cebe8  call 0x00007EC99E1FF430
00007ec99e3cebed  jmp 0x00007EC99E3CE941
00007ec99e3cebf2  call 0x00007EC99E20E760
00007ec99e3cebf7  jmp 0x00007EC99E3CE94C
00007ec99e3cebfc  call 0x00007EC99E1FF540
00007ec99e3cec01  jmp 0x00007EC99E3CE966
00007ec99e3cec06  call 0x00007EC99E20E880
00007ec99e3cec0b  jmp 0x00007EC99E3CE970
00007ec99e3cec10  int3
00007ec99e3cec11  nop [rax+rax*1], ax
00007ec99e3cec1a  nop [rax+rax*1], ax
00007ec99e3cec20  mov rax, [r15]
00007ec99e3cec23  lea r14, [rax+0x20]
00007ec99e3cec27  mov r12, [r13+r14*1]
00007ec99e3cec2c  mov r14, [r15+0x10]
00007ec99e3cec30  lea r11, [r12+r14*1]
00007ec99e3cec34  mov [r15+0x40], r11
00007ec99e3cec38  lea r12, [rax+0x20]
00007ec99e3cec3c  mov [r13+r12*1], r11
00007ec99e3cec41  test r14, r14
00007ec99e3cec44  setz r14b
00007ec99e3cec48  movzx r14, r14b
00007ec99e3cec4c  mov [rsp+0x414], r14b
00007ec99e3cec54  cmp byte ptr [rsp+0x414], 0x00
00007ec99e3cec5c  jz 0x00007EC99E3CEC8E
00007ec99e3cec5e  cmp dword ptr [r15+0x318], 0x00
00007ec99e3cec66  mov eax, 0x4105B0
00007ec99e3cec6b  mov [r15+0x100], rax
00007ec99e3cec72  jz 0x00007EC99E1FE0A0
00007ec99e3cec78  nop [rax+rax*1], eax
00007ec99e3cec7d  mov eax, 0x4105B0
00007ec99e3cec82  mov [r15+0x100], rax
00007ec99e3cec89  jmp 0x00007EC99E1FE110
00007ec99e3cec8e  cmp dword ptr [r15+0x318], 0x00
00007ec99e3cec96  jz 0x00007EC99E3CECE0
00007ec99e3cec9c  nop [rax+rax*1], ax
00007ec99e3ceca5  nop [rax+rax*1], eax
00007ec99e3cecad  mov eax, 0x410348
00007ec99e3cecb2  mov [r15+0x100], rax
00007ec99e3cecb9  jmp 0x00007EC99E1FE110
00007ec99e3cecbe  int3
00007ec99e3cecbf  call 0x00007EC99E2E27E0
00007ec99e3cecc4  jmp 0x00007EC99E3CEC2C
00007ec99e3cecc9  call 0x00007EC99E2C0860
00007ec99e3cecce  jmp 0x00007EC99E3CEC41
00007ec99e3cecd3  int3
00007ec99e3cecd4  nop [rax+rax*1], ax
00007ec99e3cecdd  nop [rax], eax
00007ec99e3cece0  mov rax, [r15+0xF8]
00007ec99e3cece7  lea r14, [rax-0x150]
00007ec99e3cecee  mov [r15+0xF8], r14
00007ec99e3cecf5  mov rax, [r15]
00007ec99e3cecf8  lea r12, [rax+0x68]
00007ec99e3cecfc  mov r11, [r13+r12*1]
00007ec99e3ced01  mov [r15+0x88], r11
00007ec99e3ced08  lea r12, [rax+0x28]
00007ec99e3ced0c  mov [r15+0x40], r12
00007ec99e3ced10  mov [r15+0x48], r14
00007ec99e3ced14  mov qword ptr [r15+0x50], 0x420758
00007ec99e3ced1c  lea rax, [r14+0x100]
00007ec99e3ced23  mov r12, [r15+0xE8]
00007ec99e3ced2a  mov r11, [r15+0xD8]
00007ec99e3ced31  mov [r13+rax*1], r12
00007ec99e3ced36  lea rax, [r14+0x108]
00007ec99e3ced3d  mov [r13+rax*1], r11
00007ec99e3ced42  lea rax, [r14+0x110]
00007ec99e3ced49  mov r12, [r15+0xD0]
00007ec99e3ced50  mov r11, [r15+0xC8]
00007ec99e3ced57  mov [r13+rax*1], r12
00007ec99e3ced5c  lea rax, [r14+0x118]
00007ec99e3ced63  mov [r13+rax*1], r11
00007ec99e3ced68  lea rax, [r14+0x120]
00007ec99e3ced6f  mov r12, [r15+0xC0]
00007ec99e3ced76  mov r11, [r15+0xB8]
00007ec99e3ced7d  mov [r13+rax*1], r12
00007ec99e3ced82  lea rax, [r14+0x128]
00007ec99e3ced89  mov [r13+rax*1], r11
00007ec99e3ced8e  lea rax, [r14+0x130]
00007ec99e3ced95  mov r12, [r15+0xB0]
00007ec99e3ced9c  mov r11, [r15+0xA8]
00007ec99e3ceda3  mov [r13+rax*1], r12
00007ec99e3ceda8  lea rax, [r14+0x138]
00007ec99e3cedaf  mov [r13+rax*1], r11
00007ec99e3cedb4  lea rax, [r14+0x140]
00007ec99e3cedbb  mov r12, [r15+0xA0]
00007ec99e3cedc2  mov r11, [r15+0x98]
00007ec99e3cedc9  mov [r13+rax*1], r12
00007ec99e3cedce  lea rax, [r14+0x148]
00007ec99e3cedd5  mov [r13+rax*1], r11
00007ec99e3cedda  cmp dword ptr [r15+0x318], 0x00
00007ec99e3cede2  jz 0x00007EC99E3CEE80
00007ec99e3cede8  nop [rax+rax*1], ax
00007ec99e3cedf1  nop [rax+rax*1], eax
00007ec99e3cedf9  mov eax, 0x410380
00007ec99e3cedfe  mov [r15+0x100], rax
00007ec99e3cee05  jmp 0x00007EC99E1FE110
00007ec99e3cee0a  int3
00007ec99e3cee0b  call 0x00007EC99E2C0370
00007ec99e3cee10  jmp 0x00007EC99E3CED01
00007ec99e3cee15  call 0x00007EC99E20BC20
00007ec99e3cee1a  jmp 0x00007EC99E3CED36
00007ec99e3cee1f  call 0x00007EC99E20A9A0
00007ec99e3cee24  jmp 0x00007EC99E3CED42
00007ec99e3cee29  call 0x00007EC99E20BC20
00007ec99e3cee2e  jmp 0x00007EC99E3CED5C
00007ec99e3cee33  call 0x00007EC99E20A9A0
00007ec99e3cee38  jmp 0x00007EC99E3CED68
00007ec99e3cee3d  call 0x00007EC99E20BC20
00007ec99e3cee42  jmp 0x00007EC99E3CED82
00007ec99e3cee47  call 0x00007EC99E20A9A0
00007ec99e3cee4c  jmp 0x00007EC99E3CED8E
00007ec99e3cee51  call 0x00007EC99E20BC20
00007ec99e3cee56  jmp 0x00007EC99E3CEDA8
00007ec99e3cee5b  call 0x00007EC99E20A9A0
00007ec99e3cee60  jmp 0x00007EC99E3CEDB4
00007ec99e3cee65  call 0x00007EC99E20BC20
00007ec99e3cee6a  jmp 0x00007EC99E3CEDCE
00007ec99e3cee6f  call 0x00007EC99E20A9A0
00007ec99e3cee74  jmp 0x00007EC99E3CEDDA
00007ec99e3cee79  int3
00007ec99e3cee7a  nop [rax+rax*1], ax
00007ec99e3cee80  mov rax, [r15+0x08]
00007ec99e3cee84  movzx r14d, byte ptr [r13+rax*1]
00007ec99e3cee8a  movzx r14d, r14b
00007ec99e3cee8e  mov [rsp+0x10], r14d
00007ec99e3cee93  mov r14d, r14d
00007ec99e3cee96  mov [r15+0x58], r14
00007ec99e3cee9a  lea r14, [rax+0x01]
00007ec99e3cee9e  mov [r15+0x08], r14
00007ec99e3ceea2  mov rax, [r15+0x88]
00007ec99e3ceea9  lea r14, [rax+0x01]
00007ec99e3ceead  mov r12, [r15]
00007ec99e3ceeb0  lea r11, [r12+0x68]
00007ec99e3ceeb5  mov [r13+r11*1], r14
00007ec99e3ceeba  lea r14, [r12+rax*1]
00007ec99e3ceebe  mov [r15+0x60], r14
00007ec99e3ceec2  lea rax, [r14+0x28]
00007ec99e3ceec6  mov r11d, [rsp+0x10]
00007ec99e3ceecb  movzx r14d, r11b
00007ec99e3ceecf  mov [r13+rax*1], r14b
00007ec99e3ceed4  lea rax, [r12+0x68]
00007ec99e3ceed9  mov r14, [r13+rax*1]
00007ec99e3ceede  mov [r15+0x88], r14
00007ec99e3ceee5  xor eax, eax
00007ec99e3ceee7  mov r12d, 0x40
00007ec99e3ceeed  cmp r14, r12
00007ec99e3ceef0  cmc
00007ec99e3ceef1  lahf
00007ec99e3ceef2  seto al
00007ec99e3ceef5  mov [r15+0x108], eax
00007ec99e3ceefc  mov eax, [r15+0x108]
00007ec99e3cef03  sahf
00007ec99e3cef04  jnz 0x00007EC99E3CEF36
00007ec99e3cef06  cmp dword ptr [r15+0x318], 0x00
00007ec99e3cef0e  jz 0x00007EC99E3CF020
00007ec99e3cef14  nop [rax+rax*1], ax
00007ec99e3cef1d  nop [rax+rax*1], eax
00007ec99e3cef25  mov eax, 0x4103A0
00007ec99e3cef2a  mov [r15+0x100], rax
00007ec99e3cef31  jmp 0x00007EC99E1FE110
00007ec99e3cef36  cmp dword ptr [r15+0x318], 0x00
00007ec99e3cef3e  jz 0x00007EC99E3CEF90
00007ec99e3cef44  nop [rax+rax*1], ax
00007ec99e3cef4d  nop [rax+rax*1], eax
00007ec99e3cef55  mov eax, 0x410378
00007ec99e3cef5a  mov [r15+0x100], rax
00007ec99e3cef61  jmp 0x00007EC99E1FE110
00007ec99e3cef66  int3
00007ec99e3cef67  call 0x00007EC99E20D860
00007ec99e3cef6c  jmp 0x00007EC99E3CEE8A
00007ec99e3cef71  call 0x00007EC99E2B36E0
00007ec99e3cef76  jmp 0x00007EC99E3CEEBA
00007ec99e3cef7b  call 0x00007EC99E20DD60
00007ec99e3cef80  jmp 0x00007EC99E3CEED4
00007ec99e3cef85  call 0x00007EC99E20DC20
00007ec99e3cef8a  jmp 0x00007EC99E3CEEDE
00007ec99e3cef8f  int3
00007ec99e3cef90  mov rax, [r15+0x10]
00007ec99e3cef94  lea r14, [rax-0x01]
00007ec99e3cef98  mov [r15+0x10], r14
00007ec99e3cef9c  test r14, r14
00007ec99e3cef9f  setz r14b
00007ec99e3cefa3  movzx r14, r14b
00007ec99e3cefa7  mov [rsp+0x414], r14b
00007ec99e3cefaf  cmp byte ptr [rsp+0x414], 0x00
00007ec99e3cefb7  jz 0x00007EC99E3CEFE9
00007ec99e3cefb9  cmp dword ptr [r15+0x318], 0x00
00007ec99e3cefc1  jz 0x00007EC99E3D0520
00007ec99e3cefc7  nop [rax+rax*1], ax
00007ec99e3cefd0  nop [rax+rax*1], eax
00007ec99e3cefd8  mov eax, 0x410598
00007ec99e3cefdd  mov [r15+0x100], rax
00007ec99e3cefe4  jmp 0x00007EC99E1FE110
00007ec99e3cefe9  cmp dword ptr [r15+0x318], 0x00
00007ec99e3ceff1  jz 0x00007EC99E3CEE80
00007ec99e3ceff7  nop [rax+rax*1], ax
00007ec99e3cf000  nop [rax+rax*1], eax
00007ec99e3cf008  mov eax, 0x410380
00007ec99e3cf00d  mov [r15+0x100], rax
00007ec99e3cf014  jmp 0x00007EC99E1FE110
00007ec99e3cf019  int3
00007ec99e3cf01a  int3
00007ec99e3cf01b  nop [rax+rax*1], eax
00007ec99e3cf020  mov rax, [r15+0x40]
00007ec99e3cf024  movzx r14d, byte ptr [r13+rax*1]
00007ec99e3cf02a  movaps xmm1, [r15+0x110]
00007ec99e3cf032  pinsrb xmm1, r14d, 0x00
00007ec99e3cf039  lea r14, [rax+0x01]
00007ec99e3cf03d  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf043  movaps xmm15, [r15+0x120]
00007ec99e3cf04b  pinsrb xmm15, r12d, 0x00
00007ec99e3cf052  lea r14, [rax+0x02]
00007ec99e3cf056  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf05c  movaps xmm14, [r15+0x130]
00007ec99e3cf064  pinsrb xmm14, r12d, 0x00
00007ec99e3cf06b  lea r14, [rax+0x03]
00007ec99e3cf06f  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf075  movaps xmm13, [r15+0x140]
00007ec99e3cf07d  pinsrb xmm13, r12d, 0x00
00007ec99e3cf084  lea r14, [rax+0x04]
00007ec99e3cf088  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf08e  pinsrb xmm1, r12d, 0x01
00007ec99e3cf095  lea r14, [rax+0x05]
00007ec99e3cf099  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf09f  pinsrb xmm15, r12d, 0x01
00007ec99e3cf0a6  lea r14, [rax+0x06]
00007ec99e3cf0aa  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf0b0  pinsrb xmm14, r12d, 0x01
00007ec99e3cf0b7  lea r14, [rax+0x07]
00007ec99e3cf0bb  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf0c1  pinsrb xmm13, r12d, 0x01
00007ec99e3cf0c8  lea r14, [rax+0x08]
00007ec99e3cf0cc  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf0d2  pinsrb xmm1, r12d, 0x02
00007ec99e3cf0d9  lea r14, [rax+0x09]
00007ec99e3cf0dd  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf0e3  pinsrb xmm15, r12d, 0x02
00007ec99e3cf0ea  lea r14, [rax+0x0A]
00007ec99e3cf0ee  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf0f4  pinsrb xmm14, r12d, 0x02
00007ec99e3cf0fb  lea r14, [rax+0x0B]
00007ec99e3cf0ff  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf105  pinsrb xmm13, r12d, 0x02
00007ec99e3cf10c  lea r14, [rax+0x0C]
00007ec99e3cf110  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf116  pinsrb xmm1, r12d, 0x03
00007ec99e3cf11d  lea r14, [rax+0x0D]
00007ec99e3cf121  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf127  pinsrb xmm15, r12d, 0x03
00007ec99e3cf12e  lea r14, [rax+0x0E]
00007ec99e3cf132  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf138  pinsrb xmm14, r12d, 0x03
00007ec99e3cf13f  lea r14, [rax+0x0F]
00007ec99e3cf143  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf149  pinsrb xmm13, r12d, 0x03
00007ec99e3cf150  lea r14, [rax+0x10]
00007ec99e3cf154  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf15a  pinsrb xmm1, r12d, 0x04
00007ec99e3cf161  lea r14, [rax+0x11]
00007ec99e3cf165  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf16b  pinsrb xmm15, r12d, 0x04
00007ec99e3cf172  lea r14, [rax+0x12]
00007ec99e3cf176  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf17c  pinsrb xmm14, r12d, 0x04
00007ec99e3cf183  lea r14, [rax+0x13]
00007ec99e3cf187  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf18d  pinsrb xmm13, r12d, 0x04
00007ec99e3cf194  lea r14, [rax+0x14]
00007ec99e3cf198  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf19e  pinsrb xmm1, r12d, 0x05
00007ec99e3cf1a5  lea r14, [rax+0x15]
00007ec99e3cf1a9  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf1af  pinsrb xmm15, r12d, 0x05
00007ec99e3cf1b6  lea r14, [rax+0x16]
00007ec99e3cf1ba  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf1c0  pinsrb xmm14, r12d, 0x05
00007ec99e3cf1c7  lea r14, [rax+0x17]
00007ec99e3cf1cb  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf1d1  pinsrb xmm13, r12d, 0x05
00007ec99e3cf1d8  lea r14, [rax+0x18]
00007ec99e3cf1dc  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf1e2  pinsrb xmm1, r12d, 0x06
00007ec99e3cf1e9  lea r14, [rax+0x19]
00007ec99e3cf1ed  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf1f3  pinsrb xmm15, r12d, 0x06
00007ec99e3cf1fa  lea r14, [rax+0x1A]
00007ec99e3cf1fe  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf204  pinsrb xmm14, r12d, 0x06
00007ec99e3cf20b  lea r14, [rax+0x1B]
00007ec99e3cf20f  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf215  pinsrb xmm13, r12d, 0x06
00007ec99e3cf21c  lea r14, [rax+0x1C]
00007ec99e3cf220  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf226  pinsrb xmm1, r12d, 0x07
00007ec99e3cf22d  lea r14, [rax+0x1D]
00007ec99e3cf231  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf237  pinsrb xmm15, r12d, 0x07
00007ec99e3cf23e  lea r14, [rax+0x1E]
00007ec99e3cf242  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf248  pinsrb xmm14, r12d, 0x07
00007ec99e3cf24f  lea r14, [rax+0x1F]
00007ec99e3cf253  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf259  pinsrb xmm13, r12d, 0x07
00007ec99e3cf260  lea r14, [rax+0x20]
00007ec99e3cf264  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf26a  pinsrb xmm1, r12d, 0x08
00007ec99e3cf271  lea r14, [rax+0x21]
00007ec99e3cf275  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf27b  pinsrb xmm15, r12d, 0x08
00007ec99e3cf282  lea r14, [rax+0x22]
00007ec99e3cf286  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf28c  pinsrb xmm14, r12d, 0x08
00007ec99e3cf293  lea r14, [rax+0x23]
00007ec99e3cf297  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf29d  pinsrb xmm13, r12d, 0x08
00007ec99e3cf2a4  lea r14, [rax+0x24]
00007ec99e3cf2a8  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf2ae  pinsrb xmm1, r12d, 0x09
00007ec99e3cf2b5  lea r14, [rax+0x25]
00007ec99e3cf2b9  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf2bf  pinsrb xmm15, r12d, 0x09
00007ec99e3cf2c6  lea r14, [rax+0x26]
00007ec99e3cf2ca  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf2d0  pinsrb xmm14, r12d, 0x09
00007ec99e3cf2d7  lea r14, [rax+0x27]
00007ec99e3cf2db  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf2e1  pinsrb xmm13, r12d, 0x09
00007ec99e3cf2e8  lea r14, [rax+0x28]
00007ec99e3cf2ec  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf2f2  pinsrb xmm1, r12d, 0x0A
00007ec99e3cf2f9  lea r14, [rax+0x29]
00007ec99e3cf2fd  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf303  pinsrb xmm15, r12d, 0x0A
00007ec99e3cf30a  lea r14, [rax+0x2A]
00007ec99e3cf30e  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf314  pinsrb xmm14, r12d, 0x0A
00007ec99e3cf31b  lea r14, [rax+0x2B]
00007ec99e3cf31f  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf325  pinsrb xmm13, r12d, 0x0A
00007ec99e3cf32c  lea r14, [rax+0x2C]
00007ec99e3cf330  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf336  pinsrb xmm1, r12d, 0x0B
00007ec99e3cf33d  lea r14, [rax+0x2D]
00007ec99e3cf341  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf347  pinsrb xmm15, r12d, 0x0B
00007ec99e3cf34e  lea r14, [rax+0x2E]
00007ec99e3cf352  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf358  pinsrb xmm14, r12d, 0x0B
00007ec99e3cf35f  lea r14, [rax+0x2F]
00007ec99e3cf363  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf369  pinsrb xmm13, r12d, 0x0B
00007ec99e3cf370  lea r14, [rax+0x30]
00007ec99e3cf374  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf37a  pinsrb xmm1, r12d, 0x0C
00007ec99e3cf381  lea r14, [rax+0x31]
00007ec99e3cf385  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf38b  pinsrb xmm15, r12d, 0x0C
00007ec99e3cf392  lea r14, [rax+0x32]
00007ec99e3cf396  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf39c  pinsrb xmm14, r12d, 0x0C
00007ec99e3cf3a3  lea r14, [rax+0x33]
00007ec99e3cf3a7  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf3ad  pinsrb xmm13, r12d, 0x0C
00007ec99e3cf3b4  lea r14, [rax+0x34]
00007ec99e3cf3b8  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf3be  pinsrb xmm1, r12d, 0x0D
00007ec99e3cf3c5  lea r14, [rax+0x35]
00007ec99e3cf3c9  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf3cf  pinsrb xmm15, r12d, 0x0D
00007ec99e3cf3d6  lea r14, [rax+0x36]
00007ec99e3cf3da  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf3e0  pinsrb xmm14, r12d, 0x0D
00007ec99e3cf3e7  lea r14, [rax+0x37]
00007ec99e3cf3eb  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf3f1  pinsrb xmm13, r12d, 0x0D
00007ec99e3cf3f8  lea r14, [rax+0x38]
00007ec99e3cf3fc  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf402  pinsrb xmm1, r12d, 0x0E
00007ec99e3cf409  lea r14, [rax+0x39]
00007ec99e3cf40d  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf413  pinsrb xmm15, r12d, 0x0E
00007ec99e3cf41a  lea r14, [rax+0x3A]
00007ec99e3cf41e  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf424  pinsrb xmm14, r12d, 0x0E
00007ec99e3cf42b  lea r14, [rax+0x3B]
00007ec99e3cf42f  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf435  pinsrb xmm13, r12d, 0x0E
00007ec99e3cf43c  lea r14, [rax+0x3C]
00007ec99e3cf440  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf446  pinsrb xmm1, r12d, 0x0F
00007ec99e3cf44d  movaps [r15+0x110], xmm1
00007ec99e3cf455  lea r14, [rax+0x3D]
00007ec99e3cf459  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf45f  pinsrb xmm15, r12d, 0x0F
00007ec99e3cf466  movaps [r15+0x120], xmm15
00007ec99e3cf46e  lea r14, [rax+0x3E]
00007ec99e3cf472  movzx r12d, byte ptr [r13+r14*1]
00007ec99e3cf478  pinsrb xmm14, r12d, 0x0F
00007ec99e3cf47f  movaps [r15+0x130], xmm14
00007ec99e3cf487  lea r14, [rax+0x3F]
00007ec99e3cf48b  movzx eax, byte ptr [r13+r14*1]
00007ec99e3cf491  pinsrb xmm13, eax, 0x0F
00007ec99e3cf498  movaps [r15+0x140], xmm13
00007ec99e3cf4a0  movq xmm1, qword ptr [r15+0x120]
00007ec99e3cf4a9  pmovzxbw xmm1, xmm1
00007ec99e3cf4ae  psllw xmm1, 0x00
00007ec99e3cf4b3  movaps [r15+0x150], xmm1
00007ec99e3cf4bb  movq xmm1, qword ptr [r15+0x130]
00007ec99e3cf4c4  pmovzxbw xmm1, xmm1
00007ec99e3cf4c9  psllw xmm1, 0x00
00007ec99e3cf4ce  movaps [r15+0x160], xmm1
00007ec99e3cf4d6  movq xmm1, qword ptr [r15+0x110]
00007ec99e3cf4df  pmovzxbw xmm1, xmm1
00007ec99e3cf4e4  psllw xmm1, 0x00
00007ec99e3cf4e9  movaps [r15+0x170], xmm1
00007ec99e3cf4f1  movaps xmm15, [r15+0x110]
00007ec99e3cf4f9  pextrq rax, xmm15, 0x01
00007ec99e3cf500  movq xmm15, rax
00007ec99e3cf505  pmovzxbw xmm15, xmm15
00007ec99e3cf50b  psllw xmm15, 0x00
00007ec99e3cf511  movaps [r15+0x180], xmm15
00007ec99e3cf519  movaps xmm14, [r15+0x120]
00007ec99e3cf521  pextrq rax, xmm14, 0x01
00007ec99e3cf528  movq xmm14, rax
00007ec99e3cf52d  pmovzxbw xmm14, xmm14
00007ec99e3cf533  psllw xmm14, 0x00
00007ec99e3cf539  movaps [r15+0x210], xmm14
00007ec99e3cf541  movaps xmm13, [r15+0x130]
00007ec99e3cf549  pextrq rax, xmm13, 0x01
00007ec99e3cf550  movq xmm13, rax
00007ec99e3cf555  pmovzxbw xmm13, xmm13
00007ec99e3cf55b  psllw xmm13, 0x00
00007ec99e3cf561  movaps [r15+0x220], xmm13
00007ec99e3cf569  movq xmm12, qword ptr [r15+0x140]
00007ec99e3cf572  pmovzxbw xmm12, xmm12
00007ec99e3cf578  psllw xmm12, 0x00
00007ec99e3cf57e  movaps [r15+0x250], xmm12
00007ec99e3cf586  movaps xmm12, [r15+0x140]
00007ec99e3cf58e  pextrq rax, xmm12, 0x01
00007ec99e3cf595  movq xmm12, rax
00007ec99e3cf59a  pmovzxbw xmm12, xmm12
00007ec99e3cf5a0  psllw xmm12, 0x00
00007ec99e3cf5a6  movaps [r15+0x110], xmm12
00007ec99e3cf5ae  movq xmm11, qword ptr [r15+0x150]
00007ec99e3cf5b7  pmovzxwd xmm11, xmm11
00007ec99e3cf5bd  pslld xmm11, 0x10
00007ec99e3cf5c3  movq xmm10, qword ptr [r15+0x160]
00007ec99e3cf5cc  pmovzxwd xmm10, xmm10
00007ec99e3cf5d2  pslld xmm10, 0x08
00007ec99e3cf5d8  pextrq rax, xmm1, 0x01
00007ec99e3cf5df  movq xmm1, rax
00007ec99e3cf5e4  pmovzxwd xmm1, xmm1
00007ec99e3cf5e9  pslld xmm1, 0x00
00007ec99e3cf5ee  movaps [r15+0x260], xmm1
00007ec99e3cf5f6  pextrq rax, xmm15, 0x01
00007ec99e3cf5fd  movq xmm15, rax
00007ec99e3cf602  pmovzxwd xmm15, xmm15
00007ec99e3cf608  pslld xmm15, 0x00
00007ec99e3cf60e  movaps [r15+0x270], xmm15
00007ec99e3cf616  movq xmm9, qword ptr [r15+0x170]
00007ec99e3cf61f  pmovzxwd xmm9, xmm9
00007ec99e3cf625  pslld xmm9, 0x00
00007ec99e3cf62b  pextrq rax, xmm14, 0x01
00007ec99e3cf632  movq xmm14, rax
00007ec99e3cf637  pmovzxwd xmm14, xmm14
00007ec99e3cf63d  pslld xmm14, 0x10
00007ec99e3cf643  movaps [r15+0x280], xmm14
00007ec99e3cf64b  movq xmm8, qword ptr [r15+0x180]
00007ec99e3cf654  pmovzxwd xmm8, xmm8
00007ec99e3cf65a  pslld xmm8, 0x00
00007ec99e3cf660  movq xmm7, qword ptr [r15+0x210]
00007ec99e3cf669  pmovzxwd xmm7, xmm7
00007ec99e3cf66e  pslld xmm7, 0x10
00007ec99e3cf673  movaps xmm6, [r15+0x150]
00007ec99e3cf67b  pextrq rax, xmm6, 0x01
00007ec99e3cf682  movq xmm6, rax
00007ec99e3cf687  pmovzxwd xmm6, xmm6
00007ec99e3cf68c  pslld xmm6, 0x10
00007ec99e3cf691  por xmm11, xmm10
00007ec99e3cf696  movaps [r15+0x230], xmm11
00007ec99e3cf69e  pextrq rax, xmm13, 0x01
00007ec99e3cf6a5  movq xmm13, rax
00007ec99e3cf6aa  pmovzxwd xmm13, xmm13
00007ec99e3cf6b0  pslld xmm13, 0x08
00007ec99e3cf6b6  movaps [r15+0x240], xmm13
00007ec99e3cf6be  movq xmm10, qword ptr [r15+0x220]
00007ec99e3cf6c7  pmovzxwd xmm10, xmm10
00007ec99e3cf6cd  pslld xmm10, 0x08
00007ec99e3cf6d3  movaps xmm5, [r15+0x160]
00007ec99e3cf6db  pextrq rax, xmm5, 0x01
00007ec99e3cf6e2  movq xmm5, rax
00007ec99e3cf6e7  pmovzxwd xmm5, xmm5
00007ec99e3cf6ec  pslld xmm5, 0x08
00007ec99e3cf6f1  pslld xmm9, 0x18
00007ec99e3cf6f7  pslld xmm15, 0x18
00007ec99e3cf6fd  pslld xmm8, 0x18
00007ec99e3cf703  movq xmm4, qword ptr [r15+0x250]
00007ec99e3cf70c  pmovzxwd xmm4, xmm4
00007ec99e3cf711  pslld xmm4, 0x00
00007ec99e3cf716  por xmm14, xmm13
00007ec99e3cf71b  por xmm7, xmm10
00007ec99e3cf720  movaps [r15+0x210], xmm7
00007ec99e3cf728  pslld xmm1, 0x18
00007ec99e3cf72d  movaps [r15+0x220], xmm1
00007ec99e3cf735  por xmm6, xmm5
00007ec99e3cf739  por xmm11, xmm9
00007ec99e3cf73e  movaps [r15+0x160], xmm11
00007ec99e3cf746  pextrq rax, xmm12, 0x01
00007ec99e3cf74d  movq xmm13, rax
00007ec99e3cf752  pmovzxwd xmm13, xmm13
00007ec99e3cf758  pslld xmm13, 0x00
00007ec99e3cf75e  movaps [r15+0x170], xmm13
00007ec99e3cf766  movq xmm12, qword ptr [r15+0x110]
00007ec99e3cf76f  pmovzxwd xmm12, xmm12
00007ec99e3cf775  pslld xmm12, 0x00
00007ec99e3cf77b  por xmm14, xmm15
00007ec99e3cf780  por xmm7, xmm8
00007ec99e3cf785  movaps xmm15, [r15+0x250]
00007ec99e3cf78d  pextrq rax, xmm15, 0x01
00007ec99e3cf794  movq xmm15, rax
00007ec99e3cf799  pmovzxwd xmm15, xmm15
00007ec99e3cf79f  pslld xmm15, 0x00
00007ec99e3cf7a5  movaps [r15+0x180], xmm15
00007ec99e3cf7ad  por xmm6, xmm1
00007ec99e3cf7b1  movaps [r15+0x150], xmm6
00007ec99e3cf7b9  por xmm11, xmm4
00007ec99e3cf7be  movaps [r15+0x140], xmm11
00007ec99e3cf7c6  por xmm7, xmm12
00007ec99e3cf7cb  movaps [r15+0x110], xmm7
00007ec99e3cf7d3  por xmm14, xmm13
00007ec99e3cf7d8  movaps [r15+0x120], xmm14
00007ec99e3cf7e0  por xmm6, xmm15
00007ec99e3cf7e5  movaps [r15+0x130], xmm6
00007ec99e3cf7ed  mov rax, [r15+0xF8]
00007ec99e3cf7f4  lea r14, [rax+0x20]
00007ec99e3cf7f8  movups [r13+r14*1], xmm7
00007ec99e3cf7fe  lea r14, [rax+0x30]
00007ec99e3cf802  movups [r13+r14*1], xmm14
00007ec99e3cf808  movups [r13+rax*1], xmm11
00007ec99e3cf80e  lea r14, [rax+0x10]
00007ec99e3cf812  movups [r13+r14*1], xmm6
00007ec99e3cf818  mov r14d, [r13+rax*1]
00007ec99e3cf81d  mov rax, [r15+0x48]
00007ec99e3cf821  mov [r15+0x68], rax
00007ec99e3cf825  mov qword ptr [r15+0x58], 0x04
00007ec99e3cf82d  lea r12, [rax+0x04]
00007ec99e3cf831  mov r11d, [r13+r12*1]
00007ec99e3cf836  mov [rsp+0x10], r11d
00007ec99e3cf83b  mov r11d, r11d
00007ec99e3cf83e  mov [r15+0x70], r11
00007ec99e3cf842  lea r12, [rax+0x38]
00007ec99e3cf846  mov r11d, [r13+r12*1]
00007ec99e3cf84b  lea r12, [rax+0x24]
00007ec99e3cf84f  mov r10d, [r13+r12*1]
00007ec99e3cf854  mov [rsp+0x20], r10d
00007ec99e3cf859  mov r10d, r10d
00007ec99e3cf85c  mov [r15+0x90], r10
00007ec99e3cf863  mov [rsp+0x30], rax
00007ec99e3cf868  xor eax, eax
00007ec99e3cf86a  mov r12d, 0x04
00007ec99e3cf870  mov r10d, 0xC0
00007ec99e3cf876  cmp r12, r10
00007ec99e3cf879  cmc
00007ec99e3cf87a  lahf
00007ec99e3cf87b  seto al
00007ec99e3cf87e  mov [r15+0x108], eax
00007ec99e3cf885  mov eax, [rsp+0x10]
00007ec99e3cf889  mov r12d, [rsp+0x10]
00007ec99e3cf88e  shrd eax, r12d, 0x07
00007ec99e3cf893  mov [rsp+0x10], r11d
00007ec99e3cf898  mov r10d, [rsp+0x10]
00007ec99e3cf89d  shrd r11d, r10d, 0x11
00007ec99e3cf8a2  mov r9d, [rsp+0x20]
00007ec99e3cf8a7  lea r8d, [r9d+r14d*1]
00007ec99e3cf8ac  rorx r14d, r12d, 0x12
00007ec99e3cf8b2  xor eax, r14d
00007ec99e3cf8b5  rorx r14d, r10d, 0x13
00007ec99e3cf8bb  xor r11d, r14d
00007ec99e3cf8be  mov [rsp+0x10], r11d
00007ec99e3cf8c3  mov r11d, r11d
00007ec99e3cf8c6  mov [r15+0x88], r11
00007ec99e3cf8cd  mov [rsp+0x20], r12d
00007ec99e3cf8d2  shr r12d, 0x03
00007ec99e3cf8d6  xor eax, r12d
00007ec99e3cf8d9  mov [rsp+0x40], eax
00007ec99e3cf8dd  mov eax, eax
00007ec99e3cf8df  mov [r15+0x80], rax
00007ec99e3cf8e6  shr r10d, 0x0A
00007ec99e3cf8ea  mov eax, [rsp+0x10]
00007ec99e3cf8ee  xor eax, r10d
00007ec99e3cf8f1  mov [rsp+0x10], eax
00007ec99e3cf8f5  mov eax, eax
00007ec99e3cf8f7  mov [r15+0x78], rax
00007ec99e3cf8fb  mov eax, [rsp+0x40]
00007ec99e3cf8ff  lea r14d, [r8d+eax*1]
00007ec99e3cf904  mov eax, [rsp+0x10]
00007ec99e3cf908  lea r12d, [r14d+eax*1]
00007ec99e3cf90d  mov rax, [rsp+0x30]
00007ec99e3cf912  lea r14, [rax+0x40]
00007ec99e3cf916  mov [r13+r14*1], r12d
00007ec99e3cf91b  mov eax, [rsp+0x20]
00007ec99e3cf91f  mov eax, eax
00007ec99e3cf921  mov [r15+0x60], rax
00007ec99e3cf925  mov eax, [r15+0x108]
00007ec99e3cf92c  sahf
00007ec99e3cf92d  jnz 0x00007EC99E3CF95F
00007ec99e3cf92f  cmp dword ptr [r15+0x318], 0x00
00007ec99e3cf937  jz 0x00007EC99E3CFE20
00007ec99e3cf93d  nop [rax+rax*1], ax
00007ec99e3cf946  nop [rax+rax*1], eax
00007ec99e3cf94e  mov eax, 0x41049C
00007ec99e3cf953  mov [r15+0x100], rax
00007ec99e3cf95a  jmp 0x00007EC99E1FE110
00007ec99e3cf95f  cmp dword ptr [r15+0x318], 0x00
00007ec99e3cf967  jz 0x00007EC99E3CFC70
00007ec99e3cf96d  nop [rax+rax*1], ax
00007ec99e3cf976  nop [rax+rax*1], eax
00007ec99e3cf97e  mov eax, 0x410454
00007ec99e3cf983  mov [r15+0x100], rax
00007ec99e3cf98a  jmp 0x00007EC99E1FE110
00007ec99e3cf98f  int3
00007ec99e3cf990  call 0x00007EC99E20D860
00007ec99e3cf995  jmp 0x00007EC99E3CF02A
00007ec99e3cf99a  call 0x00007EC99E2E2420
00007ec99e3cf99f  jmp 0x00007EC99E3CF043
00007ec99e3cf9a4  call 0x00007EC99E2E2420
00007ec99e3cf9a9  jmp 0x00007EC99E3CF05C
00007ec99e3cf9ae  call 0x00007EC99E2E2420
00007ec99e3cf9b3  jmp 0x00007EC99E3CF075
00007ec99e3cf9b8  call 0x00007EC99E2E2420
00007ec99e3cf9bd  jmp 0x00007EC99E3CF08E
00007ec99e3cf9c2  call 0x00007EC99E2E2420
00007ec99e3cf9c7  jmp 0x00007EC99E3CF09F
00007ec99e3cf9cc  call 0x00007EC99E2E2420
00007ec99e3cf9d1  jmp 0x00007EC99E3CF0B0
00007ec99e3cf9d6  call 0x00007EC99E2E2420
00007ec99e3cf9db  jmp 0x00007EC99E3CF0C1
00007ec99e3cf9e0  call 0x00007EC99E2E2420
00007ec99e3cf9e5  jmp 0x00007EC99E3CF0D2
00007ec99e3cf9ea  call 0x00007EC99E2E2420
00007ec99e3cf9ef  jmp 0x00007EC99E3CF0E3
00007ec99e3cf9f4  call 0x00007EC99E2E2420
00007ec99e3cf9f9  jmp 0x00007EC99E3CF0F4
00007ec99e3cf9fe  call 0x00007EC99E2E2420
00007ec99e3cfa03  jmp 0x00007EC99E3CF105
00007ec99e3cfa08  call 0x00007EC99E2E2420
00007ec99e3cfa0d  jmp 0x00007EC99E3CF116
00007ec99e3cfa12  call 0x00007EC99E2E2420
00007ec99e3cfa17  jmp 0x00007EC99E3CF127
00007ec99e3cfa1c  call 0x00007EC99E2E2420
00007ec99e3cfa21  jmp 0x00007EC99E3CF138
00007ec99e3cfa26  call 0x00007EC99E2E2420
00007ec99e3cfa2b  jmp 0x00007EC99E3CF149
00007ec99e3cfa30  call 0x00007EC99E2E2420
00007ec99e3cfa35  jmp 0x00007EC99E3CF15A
00007ec99e3cfa3a  call 0x00007EC99E2E2420
00007ec99e3cfa3f  jmp 0x00007EC99E3CF16B
00007ec99e3cfa44  call 0x00007EC99E2E2420
00007ec99e3cfa49  jmp 0x00007EC99E3CF17C
00007ec99e3cfa4e  call 0x00007EC99E2E2420
00007ec99e3cfa53  jmp 0x00007EC99E3CF18D
00007ec99e3cfa58  call 0x00007EC99E2E2420
00007ec99e3cfa5d  jmp 0x00007EC99E3CF19E
00007ec99e3cfa62  call 0x00007EC99E2E2420
00007ec99e3cfa67  jmp 0x00007EC99E3CF1AF
00007ec99e3cfa6c  call 0x00007EC99E2E2420
00007ec99e3cfa71  jmp 0x00007EC99E3CF1C0
00007ec99e3cfa76  call 0x00007EC99E2E2420
00007ec99e3cfa7b  jmp 0x00007EC99E3CF1D1
00007ec99e3cfa80  call 0x00007EC99E2E2420
00007ec99e3cfa85  jmp 0x00007EC99E3CF1E2
00007ec99e3cfa8a  call 0x00007EC99E2E2420
00007ec99e3cfa8f  jmp 0x00007EC99E3CF1F3
00007ec99e3cfa94  call 0x00007EC99E2E2420
00007ec99e3cfa99  jmp 0x00007EC99E3CF204
00007ec99e3cfa9e  call 0x00007EC99E2E2420
00007ec99e3cfaa3  jmp 0x00007EC99E3CF215
00007ec99e3cfaa8  call 0x00007EC99E2E2420
00007ec99e3cfaad  jmp 0x00007EC99E3CF226
00007ec99e3cfab2  call 0x00007EC99E2E2420
00007ec99e3cfab7  jmp 0x00007EC99E3CF237
00007ec99e3cfabc  call 0x00007EC99E2E2420
00007ec99e3cfac1  jmp 0x00007EC99E3CF248
00007ec99e3cfac6  call 0x00007EC99E2E2420
00007ec99e3cfacb  jmp 0x00007EC99E3CF259
00007ec99e3cfad0  call 0x00007EC99E2E2420
00007ec99e3cfad5  jmp 0x00007EC99E3CF26A
00007ec99e3cfada  call 0x00007EC99E2E2420
00007ec99e3cfadf  jmp 0x00007EC99E3CF27B
00007ec99e3cfae4  call 0x00007EC99E2E2420
00007ec99e3cfae9  jmp 0x00007EC99E3CF28C
00007ec99e3cfaee  call 0x00007EC99E2E2420
00007ec99e3cfaf3  jmp 0x00007EC99E3CF29D
00007ec99e3cfaf8  call 0x00007EC99E2E2420
00007ec99e3cfafd  jmp 0x00007EC99E3CF2AE
00007ec99e3cfb02  call 0x00007EC99E2E2420
00007ec99e3cfb07  jmp 0x00007EC99E3CF2BF
00007ec99e3cfb0c  call 0x00007EC99E2E2420
00007ec99e3cfb11  jmp 0x00007EC99E3CF2D0
00007ec99e3cfb16  call 0x00007EC99E2E2420
00007ec99e3cfb1b  jmp 0x00007EC99E3CF2E1
00007ec99e3cfb20  call 0x00007EC99E2E2420
00007ec99e3cfb25  jmp 0x00007EC99E3CF2F2
00007ec99e3cfb2a  call 0x00007EC99E2E2420
00007ec99e3cfb2f  jmp 0x00007EC99E3CF303
00007ec99e3cfb34  call 0x00007EC99E2E2420
00007ec99e3cfb39  jmp 0x00007EC99E3CF314
00007ec99e3cfb3e  call 0x00007EC99E2E2420
00007ec99e3cfb43  jmp 0x00007EC99E3CF325
00007ec99e3cfb48  call 0x00007EC99E2E2420
00007ec99e3cfb4d  jmp 0x00007EC99E3CF336
00007ec99e3cfb52  call 0x00007EC99E2E2420
00007ec99e3cfb57  jmp 0x00007EC99E3CF347
00007ec99e3cfb5c  call 0x00007EC99E2E2420
00007ec99e3cfb61  jmp 0x00007EC99E3CF358
00007ec99e3cfb66  call 0x00007EC99E2E2420
00007ec99e3cfb6b  jmp 0x00007EC99E3CF369
00007ec99e3cfb70  call 0x00007EC99E2E2420
00007ec99e3cfb75  jmp 0x00007EC99E3CF37A
00007ec99e3cfb7a  call 0x00007EC99E2E2420
00007ec99e3cfb7f  jmp 0x00007EC99E3CF38B
00007ec99e3cfb84  call 0x00007EC99E2E2420
00007ec99e3cfb89  jmp 0x00007EC99E3CF39C
00007ec99e3cfb8e  call 0x00007EC99E2E2420
00007ec99e3cfb93  jmp 0x00007EC99E3CF3AD
00007ec99e3cfb98  call 0x00007EC99E2E2420
00007ec99e3cfb9d  jmp 0x00007EC99E3CF3BE
00007ec99e3cfba2  call 0x00007EC99E2E2420
00007ec99e3cfba7  jmp 0x00007EC99E3CF3CF
00007ec99e3cfbac  call 0x00007EC99E2E2420
00007ec99e3cfbb1  jmp 0x00007EC99E3CF3E0
00007ec99e3cfbb6  call 0x00007EC99E2E2420
00007ec99e3cfbbb  jmp 0x00007EC99E3CF3F1
00007ec99e3cfbc0  call 0x00007EC99E2E2420
00007ec99e3cfbc5  jmp 0x00007EC99E3CF402
00007ec99e3cfbca  call 0x00007EC99E2E2420
00007ec99e3cfbcf  jmp 0x00007EC99E3CF413
00007ec99e3cfbd4  call 0x00007EC99E2E2420
00007ec99e3cfbd9  jmp 0x00007EC99E3CF424
00007ec99e3cfbde  call 0x00007EC99E2E2420
00007ec99e3cfbe3  jmp 0x00007EC99E3CF435
00007ec99e3cfbe8  call 0x00007EC99E2E2420
00007ec99e3cfbed  jmp 0x00007EC99E3CF446
00007ec99e3cfbf2  call 0x00007EC99E2E2420
00007ec99e3cfbf7  jmp 0x00007EC99E3CF45F
00007ec99e3cfbfc  call 0x00007EC99E2E2420
00007ec99e3cfc01  jmp 0x00007EC99E3CF478
00007ec99e3cfc06  call 0x00007EC99E2D5610
00007ec99e3cfc0b  jmp 0x00007EC99E3CF491
00007ec99e3cfc10  call 0x00007EC99E2DC580
00007ec99e3cfc15  jmp 0x00007EC99E3CF7FE
00007ec99e3cfc1a  call 0x00007EC99E2E46C0
00007ec99e3cfc1f  jmp 0x00007EC99E3CF808
00007ec99e3cfc24  call 0x00007EC99E209E90
00007ec99e3cfc29  jmp 0x00007EC99E3CF80E
00007ec99e3cfc2e  call 0x00007EC99E2DB310
00007ec99e3cfc33  jmp 0x00007EC99E3CF818
00007ec99e3cfc38  call 0x00007EC99E20DAE0
00007ec99e3cfc3d  jmp 0x00007EC99E3CF81D
00007ec99e3cfc42  call 0x00007EC99E2C0230
00007ec99e3cfc47  jmp 0x00007EC99E3CF836
00007ec99e3cfc4c  call 0x00007EC99E2C0230
00007ec99e3cfc51  jmp 0x00007EC99E3CF84B
00007ec99e3cfc56  call 0x00007EC99E2BEFC0
00007ec99e3cfc5b  jmp 0x00007EC99E3CF854
00007ec99e3cfc60  call 0x00007EC99E2E2BA0
00007ec99e3cfc65  jmp 0x00007EC99E3CF91B
00007ec99e3cfc6a  int3
00007ec99e3cfc6b  nop [rax+rax*1], eax
00007ec99e3cfc70  mov rax, [r15+0x48]
00007ec99e3cfc74  mov r14, [r15+0x58]
00007ec99e3cfc78  lea r12, [rax+r14*1]
00007ec99e3cfc7c  mov [r15+0x68], r12
00007ec99e3cfc80  lea rax, [r14+0x04]
00007ec99e3cfc84  mov [r15+0x58], rax
00007ec99e3cfc88  lea r14, [r12+0x04]
00007ec99e3cfc8d  mov r11d, [r13+r14*1]
00007ec99e3cfc92  mov [rsp+0x10], r11d
00007ec99e3cfc97  mov r11d, r11d
00007ec99e3cfc9a  mov [r15+0x70], r11
00007ec99e3cfc9e  lea r14, [r12+0x38]
00007ec99e3cfca3  mov r11d, [r13+r14*1]
00007ec99e3cfca8  lea r14, [r12+0x24]
00007ec99e3cfcad  mov r10d, [r13+r14*1]
00007ec99e3cfcb2  mov [rsp+0x20], r10d
00007ec99e3cfcb7  mov r10d, r10d
00007ec99e3cfcba  mov [r15+0x90], r10
00007ec99e3cfcc1  mov [rsp+0x30], rax
00007ec99e3cfcc6  xor eax, eax
00007ec99e3cfcc8  mov r14, [rsp+0x30]
00007ec99e3cfccd  mov r10d, 0xC0
00007ec99e3cfcd3  cmp r14, r10
00007ec99e3cfcd6  cmc
00007ec99e3cfcd7  lahf
00007ec99e3cfcd8  seto al
00007ec99e3cfcdb  mov [r15+0x108], eax
00007ec99e3cfce2  mov eax, [rsp+0x10]
00007ec99e3cfce6  mov r14d, [rsp+0x10]
00007ec99e3cfceb  shrd eax, r14d, 0x07
00007ec99e3cfcf0  mov [rsp+0x10], r11d
00007ec99e3cfcf5  mov r10d, [rsp+0x10]
00007ec99e3cfcfa  shrd r11d, r10d, 0x11
00007ec99e3cfcff  mov r9d, [r15+0x60]
00007ec99e3cfd03  mov r8d, [rsp+0x20]
00007ec99e3cfd08  lea ebp, [r8d+r9d*1]
00007ec99e3cfd0d  rorx r9d, r14d, 0x12
00007ec99e3cfd13  xor eax, r9d
00007ec99e3cfd16  rorx r9d, r10d, 0x13
00007ec99e3cfd1c  xor r11d, r9d
00007ec99e3cfd1f  mov [rsp+0x10], r11d
00007ec99e3cfd24  mov r11d, r11d
00007ec99e3cfd27  mov [r15+0x88], r11
00007ec99e3cfd2e  mov [rsp+0x20], r14d
00007ec99e3cfd33  shr r14d, 0x03
00007ec99e3cfd37  xor eax, r14d
00007ec99e3cfd3a  mov [rsp+0x30], eax
00007ec99e3cfd3e  mov eax, eax
00007ec99e3cfd40  mov [r15+0x80], rax
00007ec99e3cfd47  shr r10d, 0x0A
00007ec99e3cfd4b  mov eax, [rsp+0x10]
00007ec99e3cfd4f  xor eax, r10d
00007ec99e3cfd52  mov [rsp+0x10], eax
00007ec99e3cfd56  mov eax, eax
00007ec99e3cfd58  mov [r15+0x78], rax
00007ec99e3cfd5c  mov eax, [rsp+0x30]
00007ec99e3cfd60  lea r14d, [ebp+eax*1]
00007ec99e3cfd66  mov eax, [rsp+0x10]
00007ec99e3cfd6a  lea r11d, [r14d+eax*1]
00007ec99e3cfd6f  lea rax, [r12+0x40]
00007ec99e3cfd74  mov [r13+rax*1], r11d
00007ec99e3cfd79  mov eax, [rsp+0x20]
00007ec99e3cfd7d  mov eax, eax
00007ec99e3cfd7f  mov [r15+0x60], rax
00007ec99e3cfd83  mov eax, [r15+0x108]
00007ec99e3cfd8a  sahf
00007ec99e3cfd8b  jnz 0x00007EC99E3CFDBD
00007ec99e3cfd8d  cmp dword ptr [r15+0x318], 0x00
00007ec99e3cfd95  jz 0x00007EC99E3CFE20
00007ec99e3cfd9b  nop [rax+rax*1], ax
00007ec99e3cfda4  nop [rax+rax*1], eax
00007ec99e3cfdac  mov eax, 0x41049C
00007ec99e3cfdb1  mov [r15+0x100], rax
00007ec99e3cfdb8  jmp 0x00007EC99E1FE110
00007ec99e3cfdbd  cmp dword ptr [r15+0x318], 0x00
00007ec99e3cfdc5  jz 0x00007EC99E3CFC70
00007ec99e3cfdcb  nop [rax+rax*1], ax
00007ec99e3cfdd4  nop [rax+rax*1], eax
00007ec99e3cfddc  mov eax, 0x410454
00007ec99e3cfde1  mov [r15+0x100], rax
00007ec99e3cfde8  jmp 0x00007EC99E1FE110
00007ec99e3cfded  int3
00007ec99e3cfdee  call 0x00007EC99E2E1430
00007ec99e3cfdf3  jmp 0x00007EC99E3CFC92
00007ec99e3cfdf8  call 0x00007EC99E2E1430
00007ec99e3cfdfd  jmp 0x00007EC99E3CFCA8
00007ec99e3cfe02  call 0x00007EC99E2E01C0
00007ec99e3cfe07  jmp 0x00007EC99E3CFCB2
00007ec99e3cfe0c  call 0x00007EC99E20A860
00007ec99e3cfe11  jmp 0x00007EC99E3CFD79
00007ec99e3cfe16  int3
00007ec99e3cfe17  nop [rax+rax*1], ax
00007ec99e3cfe20  mov rax, [r15]
00007ec99e3cfe23  mov r14d, [r13+rax*1]
00007ec99e3cfe28  lea r12, [rax+0x04]
00007ec99e3cfe2c  mov r11d, [r13+r12*1]
00007ec99e3cfe31  mov [rsp+0x10], r14d
00007ec99e3cfe36  mov r14d, r14d
00007ec99e3cfe39  mov [r15+0x78], r14
00007ec99e3cfe3d  mov [rsp+0x20], r11d
00007ec99e3cfe42  mov r11d, r11d
00007ec99e3cfe45  mov [r15+0x80], r11
00007ec99e3cfe4c  lea r14, [rax+0x08]
00007ec99e3cfe50  mov r12d, [r13+r14*1]
00007ec99e3cfe55  lea r14, [rax+0x0C]
00007ec99e3cfe59  mov r11d, [r13+r14*1]
00007ec99e3cfe5e  mov [rsp+0x30], r12d
00007ec99e3cfe63  mov r12d, r12d
00007ec99e3cfe66  mov [r15+0x70], r12
00007ec99e3cfe6a  mov [rsp+0x40], r11d
00007ec99e3cfe6f  mov r11d, r11d
00007ec99e3cfe72  mov [r15+0x68], r11
00007ec99e3cfe76  lea r14, [rax+0x18]
00007ec99e3cfe7a  mov r12d, [r13+r14*1]
00007ec99e3cfe7f  lea r14, [rax+0x1C]
00007ec99e3cfe83  mov r11d, [r13+r14*1]
00007ec99e3cfe88  mov [rsp+0x50], r12d
00007ec99e3cfe8d  mov r12d, r12d
00007ec99e3cfe90  mov [r15+0x58], r12
00007ec99e3cfe94  mov [rsp+0x60], r11d
00007ec99e3cfe99  mov r11d, r11d
00007ec99e3cfe9c  mov [r15+0x60], r11
00007ec99e3cfea0  lea r14, [rax+0x10]
00007ec99e3cfea4  mov r12d, [r13+r14*1]
00007ec99e3cfea9  lea r14, [rax+0x14]
00007ec99e3cfead  mov eax, [r13+r14*1]
00007ec99e3cfeb2  mov [rsp+0x70], r12d
00007ec99e3cfeb7  mov r12d, r12d
00007ec99e3cfeba  mov [r15+0x18], r12
00007ec99e3cfebe  mov [rsp+0x80], eax
00007ec99e3cfec5  mov eax, eax
00007ec99e3cfec7  mov [r15+0x90], rax
00007ec99e3cfece  mov eax, [rsp+0x70]
00007ec99e3cfed2  mov eax, eax
00007ec99e3cfed4  mov [r15+0x30], rax
00007ec99e3cfed8  mov eax, [rsp+0x50]
00007ec99e3cfedc  mov eax, eax
00007ec99e3cfede  mov [r15+0xA0], rax
00007ec99e3cfee5  mov eax, [rsp+0x30]
00007ec99e3cfee9  mov eax, eax
00007ec99e3cfeeb  mov [r15+0x28], rax
00007ec99e3cfeef  mov eax, [rsp+0x20]
00007ec99e3cfef3  mov eax, eax
00007ec99e3cfef5  mov [r15+0x98], rax
00007ec99e3cfefc  mov eax, [rsp+0x10]
00007ec99e3cff00  mov eax, eax
00007ec99e3cff02  mov [r15+0x38], rax
00007ec99e3cff06  mov eax, [rsp+0x70]
00007ec99e3cff0a  mov r14d, [rsp+0x70]
00007ec99e3cff0f  shrd eax, r14d, 0x06
00007ec99e3cff14  mov [rsp+0x70], r14d
00007ec99e3cff19  mov r12d, [rsp+0x80]
00007ec99e3cff21  and r14d, r12d
00007ec99e3cff24  mov r11d, [rsp+0x10]
00007ec99e3cff29  mov r10d, [rsp+0x10]
00007ec99e3cff2e  shrd r11d, r10d, 0x02
00007ec99e3cff33  mov [rsp+0x10], r12d
00007ec99e3cff38  mov r12d, r12d
00007ec99e3cff3b  mov [r15+0x20], r12
00007ec99e3cff3f  mov r12, [r15+0x50]
00007ec99e3cff43  mov r9d, [r13+r12*1]
00007ec99e3cff48  mov r12d, [rsp+0x50]
00007ec99e3cff4d  mov r8d, [rsp+0x70]
00007ec99e3cff52  andn ebp, r8d, r12d
00007ec99e3cff57  mov edi, [rsp+0x60]
00007ec99e3cff5b  lea esi, [r14d+edi*1]
00007ec99e3cff60  rorx r14d, r8d, 0x0B
00007ec99e3cff66  xor eax, r14d
00007ec99e3cff69  rorx r14d, r10d, 0x0D
00007ec99e3cff6f  xor r11d, r14d
00007ec99e3cff72  lea edi, [esi+ebp*1]
00007ec99e3cff76  mov r14, [r15+0x48]
00007ec99e3cff7a  mov ebp, [r13+r14*1]
00007ec99e3cff7f  mov r14d, [rsp+0x30]
00007ec99e3cff84  mov esi, [rsp+0x20]
00007ec99e3cff88  and r14d, esi
00007ec99e3cff8b  mov [rsp+0x20], r14d
00007ec99e3cff90  mov r14d, r14d
00007ec99e3cff93  mov [r15+0xD8], r14
00007ec99e3cff9a  lea r14d, [edi+r9d*1]
00007ec99e3cff9f  mov r9d, [rsp+0x30]
00007ec99e3cffa4  xor r9d, esi
00007ec99e3cffa7  rorx edi, r8d, 0x19
00007ec99e3cffad  xor eax, edi
00007ec99e3cffaf  and r9d, r10d
00007ec99e3cffb2  rorx edi, r10d, 0x16
00007ec99e3cffb8  xor r11d, edi
00007ec99e3cffbb  mov [rsp+0x30], r11d
00007ec99e3cffc0  mov r11d, r11d
00007ec99e3cffc3  mov [r15+0xD0], r11
00007ec99e3cffca  lea r11d, [r14d+ebp*1]
00007ec99e3cffcf  mov r10d, [rsp+0x20]
00007ec99e3cffd4  xor r9d, r10d
00007ec99e3cffd7  lea r14d, [r11d+eax*1]
00007ec99e3cffdc  mov qword ptr [r15+0x88], 0x04
00007ec99e3cffe7  mov eax, [rsp+0x30]
00007ec99e3cffeb  lea r11d, [r9d+eax*1]
00007ec99e3cfff0  mov eax, [rsp+0x40]
00007ec99e3cfff4  lea r10d, [r14d+eax*1]
00007ec99e3cfff9  mov r10d, r10d
00007ec99e3cfffc  mov [r15+0xB8], r10
00007ec99e3d0003  xor eax, eax
00007ec99e3d0005  mov r10d, 0x04
00007ec99e3d000b  mov r9d, 0x100
00007ec99e3d0011  cmp r10, r9
00007ec99e3d0014  cmc
00007ec99e3d0015  lahf
00007ec99e3d0016  seto al
00007ec99e3d0019  mov [r15+0x108], eax
00007ec99e3d0020  lea eax, [r11d+r14d*1]
00007ec99e3d0025  mov eax, eax
00007ec99e3d0027  mov [r15+0xA8], rax
00007ec99e3d002e  mov r12d, r12d
00007ec99e3d0031  mov [r15+0xB0], r12
00007ec99e3d0038  mov eax, [rsp+0x10]
00007ec99e3d003c  mov eax, eax
00007ec99e3d003e  mov [r15+0xC0], rax
00007ec99e3d0045  mov r8d, r8d
00007ec99e3d0048  mov [r15+0xC8], r8
00007ec99e3d004f  mov eax, [r15+0x108]
00007ec99e3d0056  sahf
00007ec99e3d0057  jnz 0x00007EC99E3D0089
00007ec99e3d0059  cmp dword ptr [r15+0x318], 0x00
00007ec99e3d0061  jz 0x00007EC99E3D0350
00007ec99e3d0067  nop [rax+rax*1], ax
00007ec99e3d0070  nop [rax+rax*1], eax
00007ec99e3d0078  mov eax, 0x41055C
00007ec99e3d007d  mov [r15+0x100], rax
00007ec99e3d0084  jmp 0x00007EC99E1FE110
00007ec99e3d0089  cmp dword ptr [r15+0x318], 0x00
00007ec99e3d0091  jz 0x00007EC99E3D0120
00007ec99e3d0097  nop [rax+rax*1], ax
00007ec99e3d00a0  nop [rax+rax*1], eax
00007ec99e3d00a8  mov eax, 0x4104D0
00007ec99e3d00ad  mov [r15+0x100], rax
00007ec99e3d00b4  jmp 0x00007EC99E1FE110
00007ec99e3d00b9  int3
00007ec99e3d00ba  call 0x00007EC99E20DAE0
00007ec99e3d00bf  jmp 0x00007EC99E3CFE28
00007ec99e3d00c4  call 0x00007EC99E2C0230
00007ec99e3d00c9  jmp 0x00007EC99E3CFE31
00007ec99e3d00ce  call 0x00007EC99E2E26A0
00007ec99e3d00d3  jmp 0x00007EC99E3CFE55
00007ec99e3d00d8  call 0x00007EC99E2E1430
00007ec99e3d00dd  jmp 0x00007EC99E3CFE5E
00007ec99e3d00e2  call 0x00007EC99E2E26A0
00007ec99e3d00e7  jmp 0x00007EC99E3CFE7F
00007ec99e3d00ec  call 0x00007EC99E2E1430
00007ec99e3d00f1  jmp 0x00007EC99E3CFE88
00007ec99e3d00f6  call 0x00007EC99E2E26A0
00007ec99e3d00fb  jmp 0x00007EC99E3CFEA9
00007ec99e3d0100  call 0x00007EC99E2D5890
00007ec99e3d0105  jmp 0x00007EC99E3CFEB2
00007ec99e3d010a  call 0x00007EC99E2BDD50
00007ec99e3d010f  jmp 0x00007EC99E3CFF48
00007ec99e3d0114  call 0x00007EC99E2DA580
00007ec99e3d0119  jmp 0x00007EC99E3CFF7F
00007ec99e3d011e  int3
00007ec99e3d011f  nop
00007ec99e3d0120  mov eax, [r15+0xB8]
00007ec99e3d0127  mov [rsp+0x10], eax
00007ec99e3d012b  mov eax, eax
00007ec99e3d012d  mov [r15+0x30], rax
00007ec99e3d0131  mov eax, [r15+0xC0]
00007ec99e3d0138  mov [rsp+0x20], eax
00007ec99e3d013c  mov eax, eax
00007ec99e3d013e  mov [r15+0xA0], rax
00007ec99e3d0145  mov eax, [r15+0x28]
00007ec99e3d0149  mov r14d, [r15+0x98]
00007ec99e3d0150  mov [rsp+0x30], r14d
00007ec99e3d0155  mov r14d, r14d
00007ec99e3d0158  mov [r15+0x28], r14
00007ec99e3d015c  mov r14d, [r15+0x38]
00007ec99e3d0160  mov [rsp+0x40], r14d
00007ec99e3d0165  mov r14d, r14d
00007ec99e3d0168  mov [r15+0x98], r14
00007ec99e3d016f  mov r14d, [r15+0xA8]
00007ec99e3d0176  mov [rsp+0x50], r14d
00007ec99e3d017b  mov r14d, r14d
00007ec99e3d017e  mov [r15+0x38], r14
00007ec99e3d0182  mov r14d, [rsp+0x10]
00007ec99e3d0187  mov r12d, [rsp+0x10]
00007ec99e3d018c  shrd r14d, r12d, 0x06
00007ec99e3d0191  mov r11d, [r15+0xC8]
00007ec99e3d0198  mov [rsp+0x10], r12d
00007ec99e3d019d  and r12d, r11d
00007ec99e3d01a0  mov r10d, [rsp+0x50]
00007ec99e3d01a5  mov r9d, [rsp+0x50]
00007ec99e3d01aa  shrd r10d, r9d, 0x02
00007ec99e3d01af  mov [rsp+0x50], r11d
00007ec99e3d01b4  mov r11d, r11d
00007ec99e3d01b7  mov [r15+0x20], r11
00007ec99e3d01bb  mov r11, [r15+0x88]
00007ec99e3d01c2  mov r8, [r15+0x50]
00007ec99e3d01c6  lea rbp, [r8+r11*1]
00007ec99e3d01ca  mov r8d, [r13+rbp*1]
00007ec99e3d01cf  mov ebp, [rsp+0x20]
00007ec99e3d01d3  mov edi, [rsp+0x10]
00007ec99e3d01d7  andn esi, edi, ebp
00007ec99e3d01dc  mov edx, [r15+0xB0]
00007ec99e3d01e3  lea ecx, [r12d+edx*1]
00007ec99e3d01e8  rorx r12d, edi, 0x0B
00007ec99e3d01ee  xor r14d, r12d
00007ec99e3d01f1  rorx r12d, r9d, 0x0D
00007ec99e3d01f7  xor r10d, r12d
00007ec99e3d01fa  lea r12d, [ecx+esi*1]
00007ec99e3d01ff  mov rsi, [r15+0x48]
00007ec99e3d0203  lea rdx, [rsi+r11*1]
00007ec99e3d0207  mov esi, [r13+rdx*1]
00007ec99e3d020c  mov edx, [rsp+0x30]
00007ec99e3d0210  mov ecx, [rsp+0x40]
00007ec99e3d0214  and edx, ecx
00007ec99e3d0216  mov [rsp+0x10], edx
00007ec99e3d021a  mov edx, edx
00007ec99e3d021c  mov [r15+0xD8], rdx
00007ec99e3d0223  lea edx, [r12d+r8d*1]
00007ec99e3d0228  mov r12d, [rsp+0x30]
00007ec99e3d022d  xor r12d, ecx
00007ec99e3d0230  rorx r8d, edi, 0x19
00007ec99e3d0236  xor r14d, r8d
00007ec99e3d0239  and r12d, r9d
00007ec99e3d023c  rorx r8d, r9d, 0x16
00007ec99e3d0242  xor r10d, r8d
00007ec99e3d0245  mov [rsp+0x20], r10d
00007ec99e3d024a  mov r10d, r10d
00007ec99e3d024d  mov [r15+0xD0], r10
00007ec99e3d0254  lea r10d, [edx+esi*1]
00007ec99e3d0259  mov r9d, [rsp+0x10]
00007ec99e3d025e  xor r12d, r9d
00007ec99e3d0261  lea r9d, [r10d+r14d*1]
00007ec99e3d0266  lea r14, [r11+0x04]
00007ec99e3d026a  mov [r15+0x88], r14
00007ec99e3d0271  mov r11d, [rsp+0x20]
00007ec99e3d0276  lea r10d, [r12d+r11d*1]
00007ec99e3d027b  lea r11d, [r9d+eax*1]
00007ec99e3d0280  mov r11d, r11d
00007ec99e3d0283  mov [r15+0xB8], r11
00007ec99e3d028a  xor eax, eax
00007ec99e3d028c  mov r12d, 0x100
00007ec99e3d0292  cmp r14, r12
00007ec99e3d0295  cmc
00007ec99e3d0296  lahf
00007ec99e3d0297  seto al
00007ec99e3d029a  mov [r15+0x108], eax
00007ec99e3d02a1  lea eax, [r10d+r9d*1]
00007ec99e3d02a6  mov eax, eax
00007ec99e3d02a8  mov [r15+0xA8], rax
00007ec99e3d02af  mov ebp, ebp
00007ec99e3d02b1  mov [r15+0xB0], rbp
00007ec99e3d02b8  mov eax, [rsp+0x50]
00007ec99e3d02bc  mov eax, eax
00007ec99e3d02be  mov [r15+0xC0], rax
00007ec99e3d02c5  mov edi, edi
00007ec99e3d02c7  mov [r15+0xC8], rdi
00007ec99e3d02ce  mov eax, [r15+0x108]
00007ec99e3d02d5  sahf
00007ec99e3d02d6  jnz 0x00007EC99E3D0308
00007ec99e3d02d8  cmp dword ptr [r15+0x318], 0x00
00007ec99e3d02e0  jz 0x00007EC99E3D0350
00007ec99e3d02e6  nop [rax+rax*1], ax
00007ec99e3d02ef  nop [rax+rax*1], eax
00007ec99e3d02f7  mov eax, 0x41055C
00007ec99e3d02fc  mov [r15+0x100], rax
00007ec99e3d0303  jmp 0x00007EC99E1FE110
00007ec99e3d0308  cmp dword ptr [r15+0x318], 0x00
00007ec99e3d0310  jz 0x00007EC99E3D0120
00007ec99e3d0316  nop [rax+rax*1], ax
00007ec99e3d031f  nop [rax+rax*1], eax
00007ec99e3d0327  mov eax, 0x4104D0
00007ec99e3d032c  mov [r15+0x100], rax
00007ec99e3d0333  jmp 0x00007EC99E1FE110
00007ec99e3d0338  int3
00007ec99e3d0339  call 0x00007EC99E249010
00007ec99e3d033e  jmp 0x00007EC99E3D01CF
00007ec99e3d0343  call 0x00007EC99E225930
00007ec99e3d0348  jmp 0x00007EC99E3D020C
00007ec99e3d034d  int3
00007ec99e3d034e  nop
00007ec99e3d0350  mov eax, [r15+0x98]
00007ec99e3d0357  mov r14d, [r15+0x70]
00007ec99e3d035b  lea r12d, [eax+r14d*1]
00007ec99e3d0360  mov eax, [r15+0x28]
00007ec99e3d0364  mov r14d, [r15+0x68]
00007ec99e3d0368  lea r11d, [eax+r14d*1]
00007ec99e3d036d  mov qword ptr [r15+0x88], 0x00
00007ec99e3d0378  mov eax, [r15+0xA8]
00007ec99e3d037f  mov r14d, [r15+0x78]
00007ec99e3d0383  lea r10d, [eax+r14d*1]
00007ec99e3d0388  mov [rsp+0x10], r10d
00007ec99e3d038d  mov r10d, r10d
00007ec99e3d0390  mov [r15+0x78], r10
00007ec99e3d0394  mov eax, [r15+0x38]
00007ec99e3d0398  mov r14d, [r15+0x80]
00007ec99e3d039f  lea r10d, [eax+r14d*1]
00007ec99e3d03a4  mov [rsp+0x20], r10d
00007ec99e3d03a9  mov r10d, r10d
00007ec99e3d03ac  mov [r15+0x80], r10
00007ec99e3d03b3  mov rax, [r15]
00007ec99e3d03b6  lea r14, [rax+0x08]
00007ec99e3d03ba  mov [r13+r14*1], r12d
00007ec99e3d03bf  lea r14, [rax+0x0C]
00007ec99e3d03c3  mov [r13+r14*1], r11d
00007ec99e3d03c8  mov r14d, [r15+0xB8]
00007ec99e3d03cf  mov r12d, [r15+0x18]
00007ec99e3d03d3  lea r11d, [r14d+r12d*1]
00007ec99e3d03d8  mov [rsp+0x30], r11d
00007ec99e3d03dd  mov r11d, r11d
00007ec99e3d03e0  mov [r15+0x68], r11
00007ec99e3d03e4  mov r14d, [r15+0x30]
00007ec99e3d03e8  mov r12d, [r15+0x90]
00007ec99e3d03ef  lea r11d, [r14d+r12d*1]
00007ec99e3d03f4  mov [rsp+0x40], r11d
00007ec99e3d03f9  mov r11d, r11d
00007ec99e3d03fc  mov [r15+0x70], r11
00007ec99e3d0400  mov r14d, [r15+0x20]
00007ec99e3d0404  mov r12d, [r15+0x58]
00007ec99e3d0408  lea r11d, [r14d+r12d*1]
00007ec99e3d040d  mov [rsp+0x50], r11d
00007ec99e3d0412  mov r11d, r11d
00007ec99e3d0415  mov [r15+0x58], r11
00007ec99e3d0419  mov r14d, [r15+0xA0]
00007ec99e3d0420  mov r12d, [r15+0x60]
00007ec99e3d0424  lea r11d, [r14d+r12d*1]
00007ec99e3d0429  mov [rsp+0x60], r11d
00007ec99e3d042e  mov r11d, r11d
00007ec99e3d0431  mov [r15+0x60], r11
00007ec99e3d0435  mov r14d, [rsp+0x10]
00007ec99e3d043a  mov [r13+rax*1], r14d
00007ec99e3d043f  lea r14, [rax+0x04]
00007ec99e3d0443  mov r12d, [rsp+0x20]
00007ec99e3d0448  mov [r13+r14*1], r12d
00007ec99e3d044d  lea r14, [rax+0x10]
00007ec99e3d0451  mov r12d, [rsp+0x30]
00007ec99e3d0456  mov [r13+r14*1], r12d
00007ec99e3d045b  lea r14, [rax+0x14]
00007ec99e3d045f  mov r12d, [rsp+0x40]
00007ec99e3d0464  mov [r13+r14*1], r12d
00007ec99e3d0469  lea r14, [rax+0x18]
00007ec99e3d046d  mov r12d, [rsp+0x50]
00007ec99e3d0472  mov [r13+r14*1], r12d
00007ec99e3d0477  lea r14, [rax+0x1C]
00007ec99e3d047b  mov r12d, [rsp+0x60]
00007ec99e3d0480  mov [r13+r14*1], r12d
00007ec99e3d0485  lea r14, [rax+0x68]
00007ec99e3d0489  xor eax, eax
00007ec99e3d048b  mov [r13+r14*1], rax
00007ec99e3d0490  cmp dword ptr [r15+0x318], 0x00
00007ec99e3d0498  jz 0x00007EC99E3CEF90
00007ec99e3d049e  nop [rax+rax*1], ax
00007ec99e3d04a7  nop [rax+rax*1], eax
00007ec99e3d04af  mov eax, 0x410378
00007ec99e3d04b4  mov [r15+0x100], rax
00007ec99e3d04bb  jmp 0x00007EC99E1FE110
00007ec99e3d04c0  int3
00007ec99e3d04c1  call 0x00007EC99E2E2BA0
00007ec99e3d04c6  jmp 0x00007EC99E3D03BF
00007ec99e3d04cb  call 0x00007EC99E2E1920
00007ec99e3d04d0  jmp 0x00007EC99E3D03C8
00007ec99e3d04d5  call 0x00007EC99E20DFE0
00007ec99e3d04da  jmp 0x00007EC99E3D043F
00007ec99e3d04df  call 0x00007EC99E2E2BA0
00007ec99e3d04e4  jmp 0x00007EC99E3D044D
00007ec99e3d04e9  call 0x00007EC99E2E2BA0
00007ec99e3d04ee  jmp 0x00007EC99E3D045B
00007ec99e3d04f3  call 0x00007EC99E2E2BA0
00007ec99e3d04f8  jmp 0x00007EC99E3D0469
00007ec99e3d04fd  call 0x00007EC99E2E2BA0
00007ec99e3d0502  jmp 0x00007EC99E3D0477
00007ec99e3d0507  call 0x00007EC99E2E2BA0
00007ec99e3d050c  jmp 0x00007EC99E3D0485
00007ec99e3d0511  call 0x00007EC99E2D5EB0
00007ec99e3d0516  jmp 0x00007EC99E3D0490
00007ec99e3d051b  int3
00007ec99e3d051c  nop [rax], eax
00007ec99e3d0520  mov rax, [r15+0xF8]
00007ec99e3d0527  lea r14, [rax+0x140]
00007ec99e3d052e  mov r12, [r13+r14*1]
00007ec99e3d0533  lea r14, [rax+0x148]
00007ec99e3d053a  mov r11, [r13+r14*1]
00007ec99e3d053f  mov [r15+0xA0], r12
00007ec99e3d0546  mov [r15+0x98], r11
00007ec99e3d054d  lea r14, [rax+0x130]
00007ec99e3d0554  mov r12, [r13+r14*1]
00007ec99e3d0559  lea r14, [rax+0x138]
00007ec99e3d0560  mov r11, [r13+r14*1]
00007ec99e3d0565  mov [r15+0xB0], r12
00007ec99e3d056c  mov [r15+0xA8], r11
00007ec99e3d0573  lea r14, [rax+0x120]
00007ec99e3d057a  mov r12, [r13+r14*1]
00007ec99e3d057f  lea r14, [rax+0x128]
00007ec99e3d0586  mov r11, [r13+r14*1]
00007ec99e3d058b  mov [r15+0xC0], r12
00007ec99e3d0592  mov [r15+0xB8], r11
00007ec99e3d0599  lea r14, [rax+0x110]
00007ec99e3d05a0  mov r12, [r13+r14*1]
00007ec99e3d05a5  lea r14, [rax+0x118]
00007ec99e3d05ac  mov r11, [r13+r14*1]
00007ec99e3d05b1  mov [r15+0xD0], r12
00007ec99e3d05b8  mov [r15+0xC8], r11
00007ec99e3d05bf  lea r14, [rax+0x100]
00007ec99e3d05c6  mov r12, [r13+r14*1]
00007ec99e3d05cb  lea r14, [rax+0x108]
00007ec99e3d05d2  mov r11, [r13+r14*1]
00007ec99e3d05d7  mov [r15+0xE8], r12
00007ec99e3d05de  mov [r15+0xD8], r11
00007ec99e3d05e5  lea r14, [rax+0x150]
00007ec99e3d05ec  mov [r15+0xF8], r14
00007ec99e3d05f3  mov rax, [r15+0xF0]
00007ec99e3d05fa  mov [r15+0x100], rax
00007ec99e3d0601  jmp 0x00007EC99E3CE5C0
00007ec99e3d0606  int3
00007ec99e3d0607  call 0x00007EC99E2E27E0
00007ec99e3d060c  jmp 0x00007EC99E3D0533
00007ec99e3d0611  call 0x00007EC99E2E1570
00007ec99e3d0616  jmp 0x00007EC99E3D053F
00007ec99e3d061b  call 0x00007EC99E2E27E0
00007ec99e3d0620  jmp 0x00007EC99E3D0559
00007ec99e3d0625  call 0x00007EC99E2E1570
00007ec99e3d062a  jmp 0x00007EC99E3D0565
00007ec99e3d062f  call 0x00007EC99E2E27E0
00007ec99e3d0634  jmp 0x00007EC99E3D057F
00007ec99e3d0639  call 0x00007EC99E2E1570
00007ec99e3d063e  jmp 0x00007EC99E3D058B
00007ec99e3d0643  call 0x00007EC99E2E27E0
00007ec99e3d0648  jmp 0x00007EC99E3D05A5
00007ec99e3d064d  call 0x00007EC99E2E1570
00007ec99e3d0652  jmp 0x00007EC99E3D05B1
00007ec99e3d0657  call 0x00007EC99E2E27E0
00007ec99e3d065c  jmp 0x00007EC99E3D05CB
00007ec99e3d0661  call 0x00007EC99E2E1570
00007ec99e3d0666  jmp 0x00007EC99E3D05D7
00007ec99e3d066b  int3
00007ec99e3d066c  nop [rax], eax
00007ec99e3d0670  mov eax, [r15+0xA0]
00007ec99e3d0677  mov [rsp+0x10], eax
00007ec99e3d067b  xor eax, eax
00007ec99e3d067d  mov r14d, [rsp+0x10]
00007ec99e3d0682  sub r14d, 0x01
00007ec99e3d0686  cmc
00007ec99e3d0687  lahf
00007ec99e3d0688  seto al
00007ec99e3d068b  mov [r15+0x108], eax
00007ec99e3d0692  mov r14d, r14d
00007ec99e3d0695  mov [r15+0xA0], r14
00007ec99e3d069c  mov eax, [r15+0x108]
00007ec99e3d06a3  sahf
00007ec99e3d06a4  jnz 0x00007EC99E3D06D6
00007ec99e3d06a6  cmp dword ptr [r15+0x318], 0x00
00007ec99e3d06ae  jz 0x00007EC99E3D07A0
00007ec99e3d06b4  nop [rax+rax*1], ax
00007ec99e3d06bd  nop [rax+rax*1], eax
00007ec99e3d06c5  mov eax, 0x41027C
00007ec99e3d06ca  mov [r15+0x100], rax
00007ec99e3d06d1  jmp 0x00007EC99E1FE110
00007ec99e3d06d6  cmp dword ptr [r15+0x318], 0x00
00007ec99e3d06de  jz 0x00007EC99E3D0710
00007ec99e3d06e4  nop [rax+rax*1], ax
00007ec99e3d06ed  nop [rax+rax*1], eax
00007ec99e3d06f5  mov eax, 0x410264
00007ec99e3d06fa  mov [r15+0x100], rax
00007ec99e3d0701  jmp 0x00007EC99E1FE110
00007ec99e3d0706  int3
00007ec99e3d0707  int3
00007ec99e3d0708  nop [rax+rax*1], eax
00007ec99e3d0710  mov rax, [r15+0xF8]
00007ec99e3d0717  mov [r15], rax
00007ec99e3d071a  mov rax, [r15+0x98]
00007ec99e3d0721  mov [r15+0x08], rax
00007ec99e3d0725  mov qword ptr [r15+0x10], 0x12C
00007ec99e3d072d  mov qword ptr [r15+0xF0], 0x410274
00007ec99e3d0738  mov r14d, [r15+0x320]
00007ec99e3d073f  mov eax, 0x410274
00007ec99e3d0744  mov rcx, 0x7EC99E3D0670
00007ec99e3d074e  mov [r15+r14*8+0x328], rax
00007ec99e3d0756  mov [r15+r14*8+0x368], rcx
00007ec99e3d075e  add r14d, 0x01
00007ec99e3d0762  and r14d, 0x07
00007ec99e3d0766  mov [r15+0x320], r14d
00007ec99e3d076d  cmp dword ptr [r15+0x318], 0x00
00007ec99e3d0775  jz 0x00007EC99E3CEC20
00007ec99e3d077b  nop [rax+rax*1], ax
00007ec99e3d0784  nop [rax+rax*1], eax
00007ec99e3d078c  mov eax, 0x410338
00007ec99e3d0791  mov [r15+0x100], rax
00007ec99e3d0798  jmp 0x00007EC99E1FE110
00007ec99e3d079d  int3
00007ec99e3d079e  int3
00007ec99e3d079f  nop
00007ec99e3d07a0  mov rax, [r15+0xF8]
00007ec99e3d07a7  lea r14, [rax+0x20]
00007ec99e3d07ab  mov r12, [r13+r14*1]
00007ec99e3d07b0  mov [r15+0x98], r12
00007ec99e3d07b7  mov qword ptr [r15+0x40], 0x80
00007ec99e3d07bf  mov [r15], rax
00007ec99e3d07c2  lea r14, [rax+0x8C]
00007ec99e3d07c9  mov [r15+0x08], r14
00007ec99e3d07cd  mov qword ptr [r15+0x10], 0x01
00007ec99e3d07d5  lea r14, [rax+0x8C]
00007ec99e3d07dc  mov eax, 0x80
00007ec99e3d07e1  mov [r13+r14*1], al
00007ec99e3d07e6  mov qword ptr [r15+0xF0], 0x410298
00007ec99e3d07f1  mov r14d, [r15+0x320]
00007ec99e3d07f8  mov eax, 0x410298
00007ec99e3d07fd  mov rcx, 0x7EC99E3D0870
00007ec99e3d0807  mov [r15+r14*8+0x328], rax
00007ec99e3d080f  mov [r15+r14*8+0x368], rcx
00007ec99e3d0817  add r14d, 0x01
00007ec99e3d081b  and r14d, 0x07
00007ec99e3d081f  mov [r15+0x320], r14d
00007ec99e3d0826  cmp dword ptr [r15+0x318], 0x00
00007ec99e3d082e  jz 0x00007EC99E3CEC20
00007ec99e3d0834  nop [rax+rax*1], ax
00007ec99e3d083d  nop [rax+rax*1], eax
00007ec99e3d0845  mov eax, 0x410338
00007ec99e3d084a  mov [r15+0x100], rax
00007ec99e3d0851  jmp 0x00007EC99E1FE110
00007ec99e3d0856  int3
00007ec99e3d0857  call 0x00007EC99E2E27E0
00007ec99e3d085c  jmp 0x00007EC99E3D07B0
00007ec99e3d0861  call 0x00007EC99E2D5AF0
00007ec99e3d0866  jmp 0x00007EC99E3D07E6
00007ec99e3d086b  int3
00007ec99e3d086c  nop [rax], eax
00007ec99e3d0870  mov rax, [r15+0xF8]
00007ec99e3d0877  lea r14, [rax+0x68]
00007ec99e3d087b  mov r12, [r13+r14*1]
00007ec99e3d0880  mov [r15+0x40], r12
00007ec99e3d0884  lea r14, [rax+0x88]
00007ec99e3d088b  xor eax, eax
00007ec99e3d088d  mov [r13+r14*1], al
00007ec99e3d0892  xor eax, eax
00007ec99e3d0894  mov r14d, 0x38
00007ec99e3d089a  cmp r12, r14
00007ec99e3d089d  cmc
00007ec99e3d089e  lahf
00007ec99e3d089f  seto al
00007ec99e3d08a2  mov [r15+0x108], eax
00007ec99e3d08a9  mov eax, [r15+0x108]
00007ec99e3d08b0  sahf
00007ec99e3d08b1  jz 0x00007EC99E3D08E3
00007ec99e3d08b3  cmp dword ptr [r15+0x318], 0x00
00007ec99e3d08bb  jz 0x00007EC99E3D0930
00007ec99e3d08c1  nop [rax+rax*1], ax
00007ec99e3d08ca  nop [rax+rax*1], eax
00007ec99e3d08d2  mov eax, 0x4102A8
00007ec99e3d08d7  mov [r15+0x100], rax
00007ec99e3d08de  jmp 0x00007EC99E1FE110
00007ec99e3d08e3  cmp dword ptr [r15+0x318], 0x00
00007ec99e3d08eb  jz 0x00007EC99E3D0A70
00007ec99e3d08f1  nop [rax+rax*1], ax
00007ec99e3d08fa  nop [rax+rax*1], eax
00007ec99e3d0902  mov eax, 0x4102C4
00007ec99e3d0907  mov [r15+0x100], rax
00007ec99e3d090e  jmp 0x00007EC99E1FE110
00007ec99e3d0913  int3
00007ec99e3d0914  call 0x00007EC99E2E27E0
00007ec99e3d0919  jmp 0x00007EC99E3D0880
00007ec99e3d091e  call 0x00007EC99E2D5AF0
00007ec99e3d0923  jmp 0x00007EC99E3D0892
00007ec99e3d0928  int3
00007ec99e3d0929  nop [rax], eax
00007ec99e3d0930  mov rax, [r15+0xF8]
00007ec99e3d0937  mov [r15], rax
00007ec99e3d093a  lea r14, [rax+0x88]
00007ec99e3d0941  mov [r15+0x08], r14
00007ec99e3d0945  mov qword ptr [r15+0x10], 0x01
00007ec99e3d094d  mov qword ptr [r15+0xF0], 0x4102B8
00007ec99e3d0958  mov r14d, [r15+0x320]
00007ec99e3d095f  mov eax, 0x4102B8
00007ec99e3d0964  mov rcx, 0x7EC99E3D09C0
00007ec99e3d096e  mov [r15+r14*8+0x328], rax
00007ec99e3d0976  mov [r15+r14*8+0x368], rcx
00007ec99e3d097e  add r14d, 0x01
00007ec99e3d0982  and r14d, 0x07
00007ec99e3d0986  mov [r15+0x320], r14d
00007ec99e3d098d  cmp dword ptr [r15+0x318], 0x00
00007ec99e3d0995  jz 0x00007EC99E3CEC20
00007ec99e3d099b  nop [rax+rax*1], ax
00007ec99e3d09a4  nop [rax+rax*1], eax
00007ec99e3d09ac  mov eax, 0x410338
00007ec99e3d09b1  mov [r15+0x100], rax
00007ec99e3d09b8  jmp 0x00007EC99E1FE110
00007ec99e3d09bd  int3
00007ec99e3d09be  int3
00007ec99e3d09bf  nop
00007ec99e3d09c0  mov rax, [r15+0xF8]
00007ec99e3d09c7  lea r14, [rax+0x68]
00007ec99e3d09cb  mov rax, [r13+r14*1]
00007ec99e3d09d0  mov [r15+0x40], rax
00007ec99e3d09d4  mov [rsp+0x10], rax
00007ec99e3d09d9  xor eax, eax
00007ec99e3d09db  mov r14, [rsp+0x10]
00007ec99e3d09e0  mov r12d, 0x38
00007ec99e3d09e6  cmp r14, r12
00007ec99e3d09e9  cmc
00007ec99e3d09ea  lahf
00007ec99e3d09eb  seto al
00007ec99e3d09ee  mov [r15+0x108], eax
00007ec99e3d09f5  mov eax, [r15+0x108]
00007ec99e3d09fc  sahf
00007ec99e3d09fd  jnz 0x00007EC99E3D0A2F
00007ec99e3d09ff  cmp dword ptr [r15+0x318], 0x00
00007ec99e3d0a07  jz 0x00007EC99E3D0A70
00007ec99e3d0a0d  nop [rax+rax*1], ax
00007ec99e3d0a16  nop [rax+rax*1], eax
00007ec99e3d0a1e  mov eax, 0x4102C4
00007ec99e3d0a23  mov [r15+0x100], rax
00007ec99e3d0a2a  jmp 0x00007EC99E1FE110
00007ec99e3d0a2f  cmp dword ptr [r15+0x318], 0x00
00007ec99e3d0a37  jz 0x00007EC99E3D0930
00007ec99e3d0a3d  nop [rax+rax*1], ax
00007ec99e3d0a46  nop [rax+rax*1], eax
00007ec99e3d0a4e  mov eax, 0x4102A8
00007ec99e3d0a53  mov [r15+0x100], rax
00007ec99e3d0a5a  jmp 0x00007EC99E1FE110
00007ec99e3d0a5f  int3
00007ec99e3d0a60  call 0x00007EC99E2D59C0
00007ec99e3d0a65  jmp 0x00007EC99E3D09D0
00007ec99e3d0a6a  int3
00007ec99e3d0a6b  nop [rax+rax*1], eax
00007ec99e3d0a70  mov rax, [r15+0x98]
00007ec99e3d0a77  rorx r14, rax, 0x3D
00007ec99e3d0a7d  and r14, 0xFFFFFFFFFFFFFFF8
00007ec99e3d0a81  mov rax, [r15+0xF8]
00007ec99e3d0a88  mov [r15], rax
00007ec99e3d0a8b  lea r12, [rax+0x78]
00007ec99e3d0a8f  mov [r15+0x08], r12
00007ec99e3d0a93  mov qword ptr [r15+0x10], 0x08
00007ec99e3d0a9b  bswap r14
00007ec99e3d0a9e  mov [r15+0x40], r14
00007ec99e3d0aa2  lea r12, [rax+0x78]
00007ec99e3d0aa6  mov [r13+r12*1], r14
00007ec99e3d0aab  mov qword ptr [r15+0xF0], 0x4102E0
00007ec99e3d0ab6  mov r14d, [r15+0x320]
00007ec99e3d0abd  mov eax, 0x4102E0
00007ec99e3d0ac2  mov rcx, 0x7EC99E3D0B30
00007ec99e3d0acc  mov [r15+r14*8+0x328], rax
00007ec99e3d0ad4  mov [r15+r14*8+0x368], rcx
00007ec99e3d0adc  add r14d, 0x01
00007ec99e3d0ae0  and r14d, 0x07
00007ec99e3d0ae4  mov [r15+0x320], r14d
00007ec99e3d0aeb  cmp dword ptr [r15+0x318], 0x00
00007ec99e3d0af3  jz 0x00007EC99E3CEC20
00007ec99e3d0af9  nop [rax+rax*1], ax
00007ec99e3d0b02  nop [rax+rax*1], eax
00007ec99e3d0b0a  mov eax, 0x410338
00007ec99e3d0b0f  mov [r15+0x100], rax
00007ec99e3d0b16  jmp 0x00007EC99E1FE110
00007ec99e3d0b1b  int3
00007ec99e3d0b1c  call 0x00007EC99E2C3FE0
00007ec99e3d0b21  jmp 0x00007EC99E3D0AAB
00007ec99e3d0b26  int3
00007ec99e3d0b27  nop [rax+rax*1], ax
00007ec99e3d0b30  mov rax, [r15+0xF8]
00007ec99e3d0b37  mov r14d, [r13+rax*1]
00007ec99e3d0b3c  lea r12, [rax+0x04]
00007ec99e3d0b40  mov r11d, [r13+r12*1]
00007ec99e3d0b45  lea r12, [rax+0x08]
00007ec99e3d0b49  mov r10d, [r13+r12*1]
00007ec99e3d0b4e  lea r12, [rax+0x0C]
00007ec99e3d0b52  mov r9d, [r13+r12*1]
00007ec99e3d0b57  mov qword ptr [r15+0x48], 0x430860
00007ec99e3d0b5f  lea r12, [rax+0x80]
00007ec99e3d0b66  mov r8, [r13+r12*1]
00007ec99e3d0b6b  mov [r15+0xF0], r8
00007ec99e3d0b72  bswap r14d
00007ec99e3d0b75  bswap r11d
00007ec99e3d0b78  mov r12d, 0x430860
00007ec99e3d0b7e  mov [r13+r12*1], r14d
00007ec99e3d0b83  mov r14d, 0x430864
00007ec99e3d0b89  mov [r13+r14*1], r11d
00007ec99e3d0b8e  bswap r10d
00007ec99e3d0b91  bswap r9d
00007ec99e3d0b94  lea r14, [rax+0x10]
00007ec99e3d0b98  mov r12d, [r13+r14*1]
00007ec99e3d0b9d  lea r14, [rax+0x14]
00007ec99e3d0ba1  mov r11d, [r13+r14*1]
00007ec99e3d0ba6  mov r14d, 0x430868
00007ec99e3d0bac  mov [r13+r14*1], r10d
00007ec99e3d0bb1  mov r14d, 0x43086C
00007ec99e3d0bb7  mov [r13+r14*1], r9d
00007ec99e3d0bbc  lea r14, [rax+0x90]
00007ec99e3d0bc3  mov r10, [r13+r14*1]
00007ec99e3d0bc8  lea r14, [rax+0x98]
00007ec99e3d0bcf  mov r9, [r13+r14*1]
00007ec99e3d0bd4  mov [r15+0xA0], r10
00007ec99e3d0bdb  mov [r15+0x98], r9
00007ec99e3d0be2  bswap r12d
00007ec99e3d0be5  bswap r11d
00007ec99e3d0be8  mov [rsp+0x10], r11d
00007ec99e3d0bed  mov r11d, r11d
00007ec99e3d0bf0  mov [r15+0x58], r11
00007ec99e3d0bf4  lea r14, [rax+0x18]
00007ec99e3d0bf8  mov r11d, [r13+r14*1]
00007ec99e3d0bfd  lea r14, [rax+0x1C]
00007ec99e3d0c01  mov r10d, [r13+r14*1]
00007ec99e3d0c06  mov [rsp+0x20], r10d
00007ec99e3d0c0b  mov r10d, r10d
00007ec99e3d0c0e  mov [r15+0x60], r10
00007ec99e3d0c12  mov r14d, 0x430870
00007ec99e3d0c18  mov [r13+r14*1], r12d
00007ec99e3d0c1d  mov r14d, 0x430874
00007ec99e3d0c23  mov r12d, [rsp+0x10]
00007ec99e3d0c28  mov [r13+r14*1], r12d
00007ec99e3d0c2d  bswap r11d
00007ec99e3d0c30  mov [rsp+0x10], r11d
00007ec99e3d0c35  mov r11d, r11d
00007ec99e3d0c38  mov [r15+0x40], r11
00007ec99e3d0c3c  mov r14d, [rsp+0x20]
00007ec99e3d0c41  bswap r14d
00007ec99e3d0c44  mov [rsp+0x20], r14d
00007ec99e3d0c49  mov r14d, r14d
00007ec99e3d0c4c  mov [r15+0x50], r14
00007ec99e3d0c50  mov r14d, 0x430878
00007ec99e3d0c56  mov r12d, [rsp+0x10]
00007ec99e3d0c5b  mov [r13+r14*1], r12d
00007ec99e3d0c60  mov r14d, 0x43087C
00007ec99e3d0c66  mov r12d, [rsp+0x20]
00007ec99e3d0c6b  mov [r13+r14*1], r12d
00007ec99e3d0c70  lea r14, [rax+0xA0]
00007ec99e3d0c77  mov [r15+0xF8], r14
00007ec99e3d0c7e  mov [r15+0x100], r8
00007ec99e3d0c85  jmp 0x00007EC99E3CE5C0
00007ec99e3d0c8a  int3
00007ec99e3d0c8b  call 0x00007EC99E20DAE0
00007ec99e3d0c90  jmp 0x00007EC99E3D0B3C
00007ec99e3d0c95  call 0x00007EC99E2C0230
00007ec99e3d0c9a  jmp 0x00007EC99E3D0B45
00007ec99e3d0c9f  call 0x00007EC99E2BEFC0
00007ec99e3d0ca4  jmp 0x00007EC99E3D0B4E
00007ec99e3d0ca9  call 0x00007EC99E2BDD50
00007ec99e3d0cae  jmp 0x00007EC99E3D0B57
00007ec99e3d0cb3  call 0x00007EC99E2BCC20
00007ec99e3d0cb8  jmp 0x00007EC99E3D0B6B
00007ec99e3d0cbd  call 0x00007EC99E2C3EA0
00007ec99e3d0cc2  jmp 0x00007EC99E3D0B83
00007ec99e3d0cc7  call 0x00007EC99E2E1920
00007ec99e3d0ccc  jmp 0x00007EC99E3D0B8E
00007ec99e3d0cd1  call 0x00007EC99E2E26A0
00007ec99e3d0cd6  jmp 0x00007EC99E3D0B9D
00007ec99e3d0cdb  call 0x00007EC99E2E1430
00007ec99e3d0ce0  jmp 0x00007EC99E3D0BA6
00007ec99e3d0ce5  call 0x00007EC99E2E06B0
00007ec99e3d0cea  jmp 0x00007EC99E3D0BB1
00007ec99e3d0cef  call 0x00007EC99E2DF440
00007ec99e3d0cf4  jmp 0x00007EC99E3D0BBC
00007ec99e3d0cf9  call 0x00007EC99E2E0300
00007ec99e3d0cfe  jmp 0x00007EC99E3D0BC8
00007ec99e3d0d03  call 0x00007EC99E2DF090
00007ec99e3d0d08  jmp 0x00007EC99E3D0BD4
00007ec99e3d0d0d  call 0x00007EC99E2E1430
00007ec99e3d0d12  jmp 0x00007EC99E3D0BFD
00007ec99e3d0d17  call 0x00007EC99E2E01C0
00007ec99e3d0d1c  jmp 0x00007EC99E3D0C06
00007ec99e3d0d21  call 0x00007EC99E2E2BA0
00007ec99e3d0d26  jmp 0x00007EC99E3D0C1D
00007ec99e3d0d2b  call 0x00007EC99E2E2BA0
00007ec99e3d0d30  jmp 0x00007EC99E3D0C2D
00007ec99e3d0d35  call 0x00007EC99E2E2BA0
00007ec99e3d0d3a  jmp 0x00007EC99E3D0C60
00007ec99e3d0d3f  call 0x00007EC99E2E2BA0
00007ec99e3d0d44  jmp 0x00007EC99E3D0C70
00007ec99e3d0d49  int3
00007ec99e3d0d4a  nop [rax+rax*1], ax
00007ec99e3d0d50  mov qword ptr [r15+0x100], 0x04
00007ec99e3d0d5b  mov esi, 0x00
00007ec99e3d0d60  mov edx, 0x09
00007ec99e3d0d65  mov rdi, 0x7FFFD7B1B2B0
00007ec99e3d0d6f  mov rax, 0x5BA5952F5970
00007ec99e3d0d79  call rax
00007ec99e3d0d7b  cmp dword ptr [r15+0x318], 0x00
00007ec99e3d0d83  jnz 0x00007EC99E1FE110
00007ec99e3d0d89  jmp 0x00007EC99E1FE0A0
00007ec99e3d0d8e  int3
00007ec99e3d0d8f  int3
