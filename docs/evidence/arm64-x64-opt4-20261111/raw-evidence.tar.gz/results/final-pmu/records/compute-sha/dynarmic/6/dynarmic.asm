00007f9c53bce69b  nop [rax+rax*1], eax
00007f9c53bce6a0  mov rax, [r15+0xF8]
00007f9c53bce6a7  lea r14, [rax-0xA0]
00007f9c53bce6ae  mov [r15+0xF8], r14
00007f9c53bce6b5  lea rax, [r14+0x90]
00007f9c53bce6bc  mov r12, [r15+0xA0]
00007f9c53bce6c3  mov r11, [r15+0x98]
00007f9c53bce6ca  mov [r13+rax*1], r12
00007f9c53bce6cf  lea rax, [r14+0x98]
00007f9c53bce6d6  mov [r13+rax*1], r11
00007f9c53bce6db  mov eax, 0x420670
00007f9c53bce6e0  movups xmm1, [r13+rax*1]
00007f9c53bce6e6  mov eax, 0x420610
00007f9c53bce6eb  movups xmm15, [r13+rax*1]
00007f9c53bce6f1  mov eax, 0x420690
00007f9c53bce6f6  movups xmm14, [r13+rax*1]
00007f9c53bce6fc  mov eax, 0x420630
00007f9c53bce701  movups xmm13, [r13+rax*1]
00007f9c53bce707  mov qword ptr [r15+0x98], 0x4308A0
00007f9c53bce712  mov eax, 0x4206A0
00007f9c53bce717  movups xmm12, [r13+rax*1]
00007f9c53bce71d  mov eax, 0x4308A0
00007f9c53bce722  movups [r13+rax*1], xmm1
00007f9c53bce728  mov eax, 0x4308B0
00007f9c53bce72d  movups [r13+rax*1], xmm15
00007f9c53bce733  mov eax, 0x4308C0
00007f9c53bce738  movups [r13+rax*1], xmm14
00007f9c53bce73e  mov eax, 0x4308D0
00007f9c53bce743  movups [r13+rax*1], xmm13
00007f9c53bce749  mov eax, 0x420600
00007f9c53bce74e  movups xmm14, [r13+rax*1]
00007f9c53bce754  mov eax, 0x4205F0
00007f9c53bce759  movups xmm13, [r13+rax*1]
00007f9c53bce75f  mov eax, 0x4309A0
00007f9c53bce764  movups [r13+rax*1], xmm1
00007f9c53bce76a  mov eax, 0x4309B0
00007f9c53bce76f  movups [r13+rax*1], xmm15
00007f9c53bce775  mov eax, 0x4308E0
00007f9c53bce77a  movups [r13+rax*1], xmm12
00007f9c53bce780  mov eax, 0x4308F0
00007f9c53bce785  movups [r13+rax*1], xmm14
00007f9c53bce78b  mov eax, 0x4205E0
00007f9c53bce790  movups xmm1, [r13+rax*1]
00007f9c53bce796  mov eax, 0x420640
00007f9c53bce79b  movups xmm15, [r13+rax*1]
00007f9c53bce7a1  mov eax, 0x430900
00007f9c53bce7a6  movups [r13+rax*1], xmm13
00007f9c53bce7ac  mov eax, 0x430910
00007f9c53bce7b1  movups [r13+rax*1], xmm1
00007f9c53bce7b7  mov eax, 0x420650
00007f9c53bce7bc  movups xmm1, [r13+rax*1]
00007f9c53bce7c2  mov eax, 0x420620
00007f9c53bce7c7  movups xmm14, [r13+rax*1]
00007f9c53bce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
00007f9c53bce7d5  mov eax, 0x430920
00007f9c53bce7da  movups [r13+rax*1], xmm15
00007f9c53bce7e0  mov eax, 0x430930
00007f9c53bce7e5  movups [r13+rax*1], xmm1
00007f9c53bce7eb  mov eax, 0x4206C0
00007f9c53bce7f0  movups xmm1, [r13+rax*1]
00007f9c53bce7f6  mov eax, 0x4206D0
00007f9c53bce7fb  movups xmm15, [r13+rax*1]
00007f9c53bce801  movaps [r15+0x150], xmm15
00007f9c53bce809  mov qword ptr [r15+0xA0], 0x3E8
00007f9c53bce814  mov eax, 0x430940
00007f9c53bce819  movups [r13+rax*1], xmm14
00007f9c53bce81f  mov eax, 0x430950
00007f9c53bce824  movups [r13+rax*1], xmm1
00007f9c53bce82a  mov eax, 0x4206B0
00007f9c53bce82f  movups xmm1, [r13+rax*1]
00007f9c53bce835  mov eax, 0x420660
00007f9c53bce83a  movups xmm14, [r13+rax*1]
00007f9c53bce840  movaps [r15+0x140], xmm14
00007f9c53bce848  lea rax, [r14+0x80]
00007f9c53bce84f  mov r12, [r15+0xF0]
00007f9c53bce856  mov [r13+rax*1], r12
00007f9c53bce85b  mov eax, 0x430960
00007f9c53bce860  movups [r13+rax*1], xmm15
00007f9c53bce866  mov eax, 0x430970
00007f9c53bce86b  movups [r13+rax*1], xmm1
00007f9c53bce871  mov eax, 0x420680
00007f9c53bce876  movups xmm1, [r13+rax*1]
00007f9c53bce87c  mov eax, 0x4206E0
00007f9c53bce881  mov r12, [r13+rax*1]
00007f9c53bce886  movq xmm15, r12
00007f9c53bce88b  mov qword ptr [r15+0x40], 0x4206E8
00007f9c53bce893  mov eax, 0x430980
00007f9c53bce898  movups [r13+rax*1], xmm14
00007f9c53bce89e  mov eax, 0x430990
00007f9c53bce8a3  movups [r13+rax*1], xmm1
00007f9c53bce8a9  mov eax, 0x420748
00007f9c53bce8ae  movups xmm1, [r13+rax*1]
00007f9c53bce8b4  movq rax, xmm15
00007f9c53bce8b9  mov r12d, 0x4309C0
00007f9c53bce8bf  mov [r13+r12*1], rax
00007f9c53bce8c4  mov eax, 0x420728
00007f9c53bce8c9  movups xmm15, [r13+rax*1]
00007f9c53bce8cf  mov eax, 0x420738
00007f9c53bce8d4  movups xmm14, [r13+rax*1]
00007f9c53bce8da  lea rax, [r14+0x60]
00007f9c53bce8de  movups [r13+rax*1], xmm1
00007f9c53bce8e4  mov eax, 0x4309C8
00007f9c53bce8e9  mov r12d, 0x421DF8D3
00007f9c53bce8ef  mov [r13+rax*1], r12d
00007f9c53bce8f4  lea rax, [r14+0x40]
00007f9c53bce8f8  movups [r13+rax*1], xmm15
00007f9c53bce8fe  lea rax, [r14+0x50]
00007f9c53bce902  movups [r13+rax*1], xmm14
00007f9c53bce908  mov eax, 0x4206E8
00007f9c53bce90d  movups xmm1, [r13+rax*1]
00007f9c53bce913  mov eax, 0x4206F8
00007f9c53bce918  movups xmm15, [r13+rax*1]
00007f9c53bce91e  movaps [r15+0x120], xmm15
00007f9c53bce926  movups [r13+r14*1], xmm1
00007f9c53bce92c  lea rax, [r14+0x10]
00007f9c53bce930  movups [r13+rax*1], xmm15
00007f9c53bce936  mov eax, 0x420708
00007f9c53bce93b  movups xmm1, [r13+rax*1]
00007f9c53bce941  mov eax, 0x420718
00007f9c53bce946  movups xmm15, [r13+rax*1]
00007f9c53bce94c  movaps [r15+0x110], xmm1
00007f9c53bce954  movaps [r15+0x130], xmm15
00007f9c53bce95c  lea rax, [r14+0x20]
00007f9c53bce960  movups [r13+rax*1], xmm1
00007f9c53bce966  lea rax, [r14+0x30]
00007f9c53bce96a  movups [r13+rax*1], xmm15
00007f9c53bce970  mov [r15], r14
00007f9c53bce973  mov qword ptr [r15+0x08], 0x4308A0
00007f9c53bce97b  mov qword ptr [r15+0x10], 0x12C
00007f9c53bce983  mov qword ptr [r15+0xF0], 0x410274
00007f9c53bce98e  mov r14d, [r15+0x320]
00007f9c53bce995  mov eax, 0x410274
00007f9c53bce99a  mov rcx, 0x7F9C53BD0670
00007f9c53bce9a4  mov [r15+r14*8+0x328], rax
00007f9c53bce9ac  mov [r15+r14*8+0x368], rcx
00007f9c53bce9b4  add r14d, 0x01
00007f9c53bce9b8  and r14d, 0x07
00007f9c53bce9bc  mov [r15+0x320], r14d
00007f9c53bce9c3  cmp dword ptr [r15+0x318], 0x00
00007f9c53bce9cb  jz 0x00007F9C53BCEC20
00007f9c53bce9d1  nop [rax+rax*1], ax
00007f9c53bce9da  nop [rax+rax*1], eax
00007f9c53bce9e2  mov eax, 0x410338
00007f9c53bce9e7  mov [r15+0x100], rax
00007f9c53bce9ee  jmp 0x00007F9C539FE110
00007f9c53bce9f3  int3
00007f9c53bce9f4  call 0x00007F9C53A0BC20
00007f9c53bce9f9  jmp 0x00007F9C53BCE6CF
00007f9c53bce9fe  call 0x00007F9C53A0A9A0
00007f9c53bcea03  jmp 0x00007F9C53BCE6DB
00007f9c53bcea08  call 0x00007F9C539FF430
00007f9c53bcea0d  jmp 0x00007F9C53BCE6E6
00007f9c53bcea12  call 0x00007F9C53A0E760
00007f9c53bcea17  jmp 0x00007F9C53BCE6F1
00007f9c53bcea1c  call 0x00007F9C53A0D4E0
00007f9c53bcea21  jmp 0x00007F9C53BCE6FC
00007f9c53bcea26  call 0x00007F9C53A0C260
00007f9c53bcea2b  jmp 0x00007F9C53BCE707
00007f9c53bcea30  call 0x00007F9C53A0AFE0
00007f9c53bcea35  jmp 0x00007F9C53BCE71D
00007f9c53bcea3a  call 0x00007F9C539FF540
00007f9c53bcea3f  jmp 0x00007F9C53BCE728
00007f9c53bcea44  call 0x00007F9C53A0E880
00007f9c53bcea49  jmp 0x00007F9C53BCE733
00007f9c53bcea4e  call 0x00007F9C53A0D600
00007f9c53bcea53  jmp 0x00007F9C53BCE73E
00007f9c53bcea58  call 0x00007F9C53A0C380
00007f9c53bcea5d  jmp 0x00007F9C53BCE749
00007f9c53bcea62  call 0x00007F9C53A0D4E0
00007f9c53bcea67  jmp 0x00007F9C53BCE754
00007f9c53bcea6c  call 0x00007F9C53A0C260
00007f9c53bcea71  jmp 0x00007F9C53BCE75F
00007f9c53bcea76  call 0x00007F9C539FF540
00007f9c53bcea7b  jmp 0x00007F9C53BCE76A
00007f9c53bcea80  call 0x00007F9C53A0E880
00007f9c53bcea85  jmp 0x00007F9C53BCE775
00007f9c53bcea8a  call 0x00007F9C53A0B100
00007f9c53bcea8f  jmp 0x00007F9C53BCE780
00007f9c53bcea94  call 0x00007F9C53A0D600
00007f9c53bcea99  jmp 0x00007F9C53BCE78B
00007f9c53bcea9e  call 0x00007F9C539FF430
00007f9c53bceaa3  jmp 0x00007F9C53BCE796
00007f9c53bceaa8  call 0x00007F9C53A0E760
00007f9c53bceaad  jmp 0x00007F9C53BCE7A1
00007f9c53bceab2  call 0x00007F9C53A0C380
00007f9c53bceab7  jmp 0x00007F9C53BCE7AC
00007f9c53bceabc  call 0x00007F9C539FF540
00007f9c53bceac1  jmp 0x00007F9C53BCE7B7
00007f9c53bceac6  call 0x00007F9C539FF430
00007f9c53bceacb  jmp 0x00007F9C53BCE7C2
00007f9c53bcead0  call 0x00007F9C53A0D4E0
00007f9c53bcead5  jmp 0x00007F9C53BCE7CD
00007f9c53bceada  call 0x00007F9C53A0E880
00007f9c53bceadf  jmp 0x00007F9C53BCE7E0
00007f9c53bceae4  call 0x00007F9C539FF540
00007f9c53bceae9  jmp 0x00007F9C53BCE7EB
00007f9c53bceaee  call 0x00007F9C539FF430
00007f9c53bceaf3  jmp 0x00007F9C53BCE7F6
00007f9c53bceaf8  call 0x00007F9C53A0E760
00007f9c53bceafd  jmp 0x00007F9C53BCE801
00007f9c53bceb02  call 0x00007F9C53A0D600
00007f9c53bceb07  jmp 0x00007F9C53BCE81F
00007f9c53bceb0c  call 0x00007F9C539FF540
00007f9c53bceb11  jmp 0x00007F9C53BCE82A
00007f9c53bceb16  call 0x00007F9C539FF430
00007f9c53bceb1b  jmp 0x00007F9C53BCE835
00007f9c53bceb20  call 0x00007F9C53A0D4E0
00007f9c53bceb25  jmp 0x00007F9C53BCE840
00007f9c53bceb2a  call 0x00007F9C53A0BC20
00007f9c53bceb2f  jmp 0x00007F9C53BCE85B
00007f9c53bceb34  call 0x00007F9C53A0E880
00007f9c53bceb39  jmp 0x00007F9C53BCE866
00007f9c53bceb3e  call 0x00007F9C539FF540
00007f9c53bceb43  jmp 0x00007F9C53BCE871
00007f9c53bceb48  call 0x00007F9C539FF430
00007f9c53bceb4d  jmp 0x00007F9C53BCE87C
00007f9c53bceb52  call 0x00007F9C53A0B720
00007f9c53bceb57  jmp 0x00007F9C53BCE886
00007f9c53bceb5c  call 0x00007F9C53A0D600
00007f9c53bceb61  jmp 0x00007F9C53BCE89E
00007f9c53bceb66  call 0x00007F9C539FF540
00007f9c53bceb6b  jmp 0x00007F9C53BCE8A9
00007f9c53bceb70  call 0x00007F9C539FF430
00007f9c53bceb75  jmp 0x00007F9C53BCE8B4
00007f9c53bceb7a  call 0x00007F9C53AB4CB0
00007f9c53bceb7f  jmp 0x00007F9C53BCE8C4
00007f9c53bceb84  call 0x00007F9C53A0E760
00007f9c53bceb89  jmp 0x00007F9C53BCE8CF
00007f9c53bceb8e  call 0x00007F9C53A0D4E0
00007f9c53bceb93  jmp 0x00007F9C53BCE8DA
00007f9c53bceb98  call 0x00007F9C539FF540
00007f9c53bceb9d  jmp 0x00007F9C53BCE8E4
00007f9c53bceba2  call 0x00007F9C53A0BAE0
00007f9c53bceba7  jmp 0x00007F9C53BCE8F4
00007f9c53bcebac  call 0x00007F9C53A0E880
00007f9c53bcebb1  jmp 0x00007F9C53BCE8FE
00007f9c53bcebb6  call 0x00007F9C53A0D600
00007f9c53bcebbb  jmp 0x00007F9C53BCE908
00007f9c53bcebc0  call 0x00007F9C539FF430
00007f9c53bcebc5  jmp 0x00007F9C53BCE913
00007f9c53bcebca  call 0x00007F9C53A0E760
00007f9c53bcebcf  jmp 0x00007F9C53BCE91E
00007f9c53bcebd4  call 0x00007F9C53AD6600
00007f9c53bcebd9  jmp 0x00007F9C53BCE92C
00007f9c53bcebde  call 0x00007F9C53A0E880
00007f9c53bcebe3  jmp 0x00007F9C53BCE936
00007f9c53bcebe8  call 0x00007F9C539FF430
00007f9c53bcebed  jmp 0x00007F9C53BCE941
00007f9c53bcebf2  call 0x00007F9C53A0E760
00007f9c53bcebf7  jmp 0x00007F9C53BCE94C
00007f9c53bcebfc  call 0x00007F9C539FF540
00007f9c53bcec01  jmp 0x00007F9C53BCE966
00007f9c53bcec06  call 0x00007F9C53A0E880
00007f9c53bcec0b  jmp 0x00007F9C53BCE970
00007f9c53bcec10  int3
00007f9c53bcec11  nop [rax+rax*1], ax
00007f9c53bcec1a  nop [rax+rax*1], ax
00007f9c53bcec20  mov rax, [r15]
00007f9c53bcec23  lea r14, [rax+0x20]
00007f9c53bcec27  mov r12, [r13+r14*1]
00007f9c53bcec2c  mov r14, [r15+0x10]
00007f9c53bcec30  lea r11, [r12+r14*1]
00007f9c53bcec34  mov [r15+0x40], r11
00007f9c53bcec38  lea r12, [rax+0x20]
00007f9c53bcec3c  mov [r13+r12*1], r11
00007f9c53bcec41  test r14, r14
00007f9c53bcec44  setz r14b
00007f9c53bcec48  movzx r14, r14b
00007f9c53bcec4c  mov [rsp+0x414], r14b
00007f9c53bcec54  cmp byte ptr [rsp+0x414], 0x00
00007f9c53bcec5c  jz 0x00007F9C53BCEC8E
00007f9c53bcec5e  cmp dword ptr [r15+0x318], 0x00
00007f9c53bcec66  mov eax, 0x4105B0
00007f9c53bcec6b  mov [r15+0x100], rax
00007f9c53bcec72  jz 0x00007F9C539FE0A0
00007f9c53bcec78  nop [rax+rax*1], eax
00007f9c53bcec7d  mov eax, 0x4105B0
00007f9c53bcec82  mov [r15+0x100], rax
00007f9c53bcec89  jmp 0x00007F9C539FE110
00007f9c53bcec8e  cmp dword ptr [r15+0x318], 0x00
00007f9c53bcec96  jz 0x00007F9C53BCECE0
00007f9c53bcec9c  nop [rax+rax*1], ax
00007f9c53bceca5  nop [rax+rax*1], eax
00007f9c53bcecad  mov eax, 0x410348
00007f9c53bcecb2  mov [r15+0x100], rax
00007f9c53bcecb9  jmp 0x00007F9C539FE110
00007f9c53bcecbe  int3
00007f9c53bcecbf  call 0x00007F9C53AE27E0
00007f9c53bcecc4  jmp 0x00007F9C53BCEC2C
00007f9c53bcecc9  call 0x00007F9C53AC0860
00007f9c53bcecce  jmp 0x00007F9C53BCEC41
00007f9c53bcecd3  int3
00007f9c53bcecd4  nop [rax+rax*1], ax
00007f9c53bcecdd  nop [rax], eax
00007f9c53bcece0  mov rax, [r15+0xF8]
00007f9c53bcece7  lea r14, [rax-0x150]
00007f9c53bcecee  mov [r15+0xF8], r14
00007f9c53bcecf5  mov rax, [r15]
00007f9c53bcecf8  lea r12, [rax+0x68]
00007f9c53bcecfc  mov r11, [r13+r12*1]
00007f9c53bced01  mov [r15+0x88], r11
00007f9c53bced08  lea r12, [rax+0x28]
00007f9c53bced0c  mov [r15+0x40], r12
00007f9c53bced10  mov [r15+0x48], r14
00007f9c53bced14  mov qword ptr [r15+0x50], 0x420758
00007f9c53bced1c  lea rax, [r14+0x100]
00007f9c53bced23  mov r12, [r15+0xE8]
00007f9c53bced2a  mov r11, [r15+0xD8]
00007f9c53bced31  mov [r13+rax*1], r12
00007f9c53bced36  lea rax, [r14+0x108]
00007f9c53bced3d  mov [r13+rax*1], r11
00007f9c53bced42  lea rax, [r14+0x110]
00007f9c53bced49  mov r12, [r15+0xD0]
00007f9c53bced50  mov r11, [r15+0xC8]
00007f9c53bced57  mov [r13+rax*1], r12
00007f9c53bced5c  lea rax, [r14+0x118]
00007f9c53bced63  mov [r13+rax*1], r11
00007f9c53bced68  lea rax, [r14+0x120]
00007f9c53bced6f  mov r12, [r15+0xC0]
00007f9c53bced76  mov r11, [r15+0xB8]
00007f9c53bced7d  mov [r13+rax*1], r12
00007f9c53bced82  lea rax, [r14+0x128]
00007f9c53bced89  mov [r13+rax*1], r11
00007f9c53bced8e  lea rax, [r14+0x130]
00007f9c53bced95  mov r12, [r15+0xB0]
00007f9c53bced9c  mov r11, [r15+0xA8]
00007f9c53bceda3  mov [r13+rax*1], r12
00007f9c53bceda8  lea rax, [r14+0x138]
00007f9c53bcedaf  mov [r13+rax*1], r11
00007f9c53bcedb4  lea rax, [r14+0x140]
00007f9c53bcedbb  mov r12, [r15+0xA0]
00007f9c53bcedc2  mov r11, [r15+0x98]
00007f9c53bcedc9  mov [r13+rax*1], r12
00007f9c53bcedce  lea rax, [r14+0x148]
00007f9c53bcedd5  mov [r13+rax*1], r11
00007f9c53bcedda  cmp dword ptr [r15+0x318], 0x00
00007f9c53bcede2  jz 0x00007F9C53BCEE80
00007f9c53bcede8  nop [rax+rax*1], ax
00007f9c53bcedf1  nop [rax+rax*1], eax
00007f9c53bcedf9  mov eax, 0x410380
00007f9c53bcedfe  mov [r15+0x100], rax
00007f9c53bcee05  jmp 0x00007F9C539FE110
00007f9c53bcee0a  int3
00007f9c53bcee0b  call 0x00007F9C53AC0370
00007f9c53bcee10  jmp 0x00007F9C53BCED01
00007f9c53bcee15  call 0x00007F9C53A0BC20
00007f9c53bcee1a  jmp 0x00007F9C53BCED36
00007f9c53bcee1f  call 0x00007F9C53A0A9A0
00007f9c53bcee24  jmp 0x00007F9C53BCED42
00007f9c53bcee29  call 0x00007F9C53A0BC20
00007f9c53bcee2e  jmp 0x00007F9C53BCED5C
00007f9c53bcee33  call 0x00007F9C53A0A9A0
00007f9c53bcee38  jmp 0x00007F9C53BCED68
00007f9c53bcee3d  call 0x00007F9C53A0BC20
00007f9c53bcee42  jmp 0x00007F9C53BCED82
00007f9c53bcee47  call 0x00007F9C53A0A9A0
00007f9c53bcee4c  jmp 0x00007F9C53BCED8E
00007f9c53bcee51  call 0x00007F9C53A0BC20
00007f9c53bcee56  jmp 0x00007F9C53BCEDA8
00007f9c53bcee5b  call 0x00007F9C53A0A9A0
00007f9c53bcee60  jmp 0x00007F9C53BCEDB4
00007f9c53bcee65  call 0x00007F9C53A0BC20
00007f9c53bcee6a  jmp 0x00007F9C53BCEDCE
00007f9c53bcee6f  call 0x00007F9C53A0A9A0
00007f9c53bcee74  jmp 0x00007F9C53BCEDDA
00007f9c53bcee79  int3
00007f9c53bcee7a  nop [rax+rax*1], ax
00007f9c53bcee80  mov rax, [r15+0x08]
00007f9c53bcee84  movzx r14d, byte ptr [r13+rax*1]
00007f9c53bcee8a  movzx r14d, r14b
00007f9c53bcee8e  mov [rsp+0x10], r14d
00007f9c53bcee93  mov r14d, r14d
00007f9c53bcee96  mov [r15+0x58], r14
00007f9c53bcee9a  lea r14, [rax+0x01]
00007f9c53bcee9e  mov [r15+0x08], r14
00007f9c53bceea2  mov rax, [r15+0x88]
00007f9c53bceea9  lea r14, [rax+0x01]
00007f9c53bceead  mov r12, [r15]
00007f9c53bceeb0  lea r11, [r12+0x68]
00007f9c53bceeb5  mov [r13+r11*1], r14
00007f9c53bceeba  lea r14, [r12+rax*1]
00007f9c53bceebe  mov [r15+0x60], r14
00007f9c53bceec2  lea rax, [r14+0x28]
00007f9c53bceec6  mov r11d, [rsp+0x10]
00007f9c53bceecb  movzx r14d, r11b
00007f9c53bceecf  mov [r13+rax*1], r14b
00007f9c53bceed4  lea rax, [r12+0x68]
00007f9c53bceed9  mov r14, [r13+rax*1]
00007f9c53bceede  mov [r15+0x88], r14
00007f9c53bceee5  xor eax, eax
00007f9c53bceee7  mov r12d, 0x40
00007f9c53bceeed  cmp r14, r12
00007f9c53bceef0  cmc
00007f9c53bceef1  lahf
00007f9c53bceef2  seto al
00007f9c53bceef5  mov [r15+0x108], eax
00007f9c53bceefc  mov eax, [r15+0x108]
00007f9c53bcef03  sahf
00007f9c53bcef04  jnz 0x00007F9C53BCEF36
00007f9c53bcef06  cmp dword ptr [r15+0x318], 0x00
00007f9c53bcef0e  jz 0x00007F9C53BCF020
00007f9c53bcef14  nop [rax+rax*1], ax
00007f9c53bcef1d  nop [rax+rax*1], eax
00007f9c53bcef25  mov eax, 0x4103A0
00007f9c53bcef2a  mov [r15+0x100], rax
00007f9c53bcef31  jmp 0x00007F9C539FE110
00007f9c53bcef36  cmp dword ptr [r15+0x318], 0x00
00007f9c53bcef3e  jz 0x00007F9C53BCEF90
00007f9c53bcef44  nop [rax+rax*1], ax
00007f9c53bcef4d  nop [rax+rax*1], eax
00007f9c53bcef55  mov eax, 0x410378
00007f9c53bcef5a  mov [r15+0x100], rax
00007f9c53bcef61  jmp 0x00007F9C539FE110
00007f9c53bcef66  int3
00007f9c53bcef67  call 0x00007F9C53A0D860
00007f9c53bcef6c  jmp 0x00007F9C53BCEE8A
00007f9c53bcef71  call 0x00007F9C53AB36E0
00007f9c53bcef76  jmp 0x00007F9C53BCEEBA
00007f9c53bcef7b  call 0x00007F9C53A0DD60
00007f9c53bcef80  jmp 0x00007F9C53BCEED4
00007f9c53bcef85  call 0x00007F9C53A0DC20
00007f9c53bcef8a  jmp 0x00007F9C53BCEEDE
00007f9c53bcef8f  int3
00007f9c53bcef90  mov rax, [r15+0x10]
00007f9c53bcef94  lea r14, [rax-0x01]
00007f9c53bcef98  mov [r15+0x10], r14
00007f9c53bcef9c  test r14, r14
00007f9c53bcef9f  setz r14b
00007f9c53bcefa3  movzx r14, r14b
00007f9c53bcefa7  mov [rsp+0x414], r14b
00007f9c53bcefaf  cmp byte ptr [rsp+0x414], 0x00
00007f9c53bcefb7  jz 0x00007F9C53BCEFE9
00007f9c53bcefb9  cmp dword ptr [r15+0x318], 0x00
00007f9c53bcefc1  jz 0x00007F9C53BD0520
00007f9c53bcefc7  nop [rax+rax*1], ax
00007f9c53bcefd0  nop [rax+rax*1], eax
00007f9c53bcefd8  mov eax, 0x410598
00007f9c53bcefdd  mov [r15+0x100], rax
00007f9c53bcefe4  jmp 0x00007F9C539FE110
00007f9c53bcefe9  cmp dword ptr [r15+0x318], 0x00
00007f9c53bceff1  jz 0x00007F9C53BCEE80
00007f9c53bceff7  nop [rax+rax*1], ax
00007f9c53bcf000  nop [rax+rax*1], eax
00007f9c53bcf008  mov eax, 0x410380
00007f9c53bcf00d  mov [r15+0x100], rax
00007f9c53bcf014  jmp 0x00007F9C539FE110
00007f9c53bcf019  int3
00007f9c53bcf01a  int3
00007f9c53bcf01b  nop [rax+rax*1], eax
00007f9c53bcf020  mov rax, [r15+0x40]
00007f9c53bcf024  movzx r14d, byte ptr [r13+rax*1]
00007f9c53bcf02a  movaps xmm1, [r15+0x110]
00007f9c53bcf032  pinsrb xmm1, r14d, 0x00
00007f9c53bcf039  lea r14, [rax+0x01]
00007f9c53bcf03d  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf043  movaps xmm15, [r15+0x120]
00007f9c53bcf04b  pinsrb xmm15, r12d, 0x00
00007f9c53bcf052  lea r14, [rax+0x02]
00007f9c53bcf056  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf05c  movaps xmm14, [r15+0x130]
00007f9c53bcf064  pinsrb xmm14, r12d, 0x00
00007f9c53bcf06b  lea r14, [rax+0x03]
00007f9c53bcf06f  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf075  movaps xmm13, [r15+0x140]
00007f9c53bcf07d  pinsrb xmm13, r12d, 0x00
00007f9c53bcf084  lea r14, [rax+0x04]
00007f9c53bcf088  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf08e  pinsrb xmm1, r12d, 0x01
00007f9c53bcf095  lea r14, [rax+0x05]
00007f9c53bcf099  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf09f  pinsrb xmm15, r12d, 0x01
00007f9c53bcf0a6  lea r14, [rax+0x06]
00007f9c53bcf0aa  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf0b0  pinsrb xmm14, r12d, 0x01
00007f9c53bcf0b7  lea r14, [rax+0x07]
00007f9c53bcf0bb  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf0c1  pinsrb xmm13, r12d, 0x01
00007f9c53bcf0c8  lea r14, [rax+0x08]
00007f9c53bcf0cc  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf0d2  pinsrb xmm1, r12d, 0x02
00007f9c53bcf0d9  lea r14, [rax+0x09]
00007f9c53bcf0dd  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf0e3  pinsrb xmm15, r12d, 0x02
00007f9c53bcf0ea  lea r14, [rax+0x0A]
00007f9c53bcf0ee  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf0f4  pinsrb xmm14, r12d, 0x02
00007f9c53bcf0fb  lea r14, [rax+0x0B]
00007f9c53bcf0ff  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf105  pinsrb xmm13, r12d, 0x02
00007f9c53bcf10c  lea r14, [rax+0x0C]
00007f9c53bcf110  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf116  pinsrb xmm1, r12d, 0x03
00007f9c53bcf11d  lea r14, [rax+0x0D]
00007f9c53bcf121  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf127  pinsrb xmm15, r12d, 0x03
00007f9c53bcf12e  lea r14, [rax+0x0E]
00007f9c53bcf132  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf138  pinsrb xmm14, r12d, 0x03
00007f9c53bcf13f  lea r14, [rax+0x0F]
00007f9c53bcf143  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf149  pinsrb xmm13, r12d, 0x03
00007f9c53bcf150  lea r14, [rax+0x10]
00007f9c53bcf154  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf15a  pinsrb xmm1, r12d, 0x04
00007f9c53bcf161  lea r14, [rax+0x11]
00007f9c53bcf165  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf16b  pinsrb xmm15, r12d, 0x04
00007f9c53bcf172  lea r14, [rax+0x12]
00007f9c53bcf176  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf17c  pinsrb xmm14, r12d, 0x04
00007f9c53bcf183  lea r14, [rax+0x13]
00007f9c53bcf187  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf18d  pinsrb xmm13, r12d, 0x04
00007f9c53bcf194  lea r14, [rax+0x14]
00007f9c53bcf198  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf19e  pinsrb xmm1, r12d, 0x05
00007f9c53bcf1a5  lea r14, [rax+0x15]
00007f9c53bcf1a9  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf1af  pinsrb xmm15, r12d, 0x05
00007f9c53bcf1b6  lea r14, [rax+0x16]
00007f9c53bcf1ba  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf1c0  pinsrb xmm14, r12d, 0x05
00007f9c53bcf1c7  lea r14, [rax+0x17]
00007f9c53bcf1cb  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf1d1  pinsrb xmm13, r12d, 0x05
00007f9c53bcf1d8  lea r14, [rax+0x18]
00007f9c53bcf1dc  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf1e2  pinsrb xmm1, r12d, 0x06
00007f9c53bcf1e9  lea r14, [rax+0x19]
00007f9c53bcf1ed  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf1f3  pinsrb xmm15, r12d, 0x06
00007f9c53bcf1fa  lea r14, [rax+0x1A]
00007f9c53bcf1fe  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf204  pinsrb xmm14, r12d, 0x06
00007f9c53bcf20b  lea r14, [rax+0x1B]
00007f9c53bcf20f  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf215  pinsrb xmm13, r12d, 0x06
00007f9c53bcf21c  lea r14, [rax+0x1C]
00007f9c53bcf220  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf226  pinsrb xmm1, r12d, 0x07
00007f9c53bcf22d  lea r14, [rax+0x1D]
00007f9c53bcf231  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf237  pinsrb xmm15, r12d, 0x07
00007f9c53bcf23e  lea r14, [rax+0x1E]
00007f9c53bcf242  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf248  pinsrb xmm14, r12d, 0x07
00007f9c53bcf24f  lea r14, [rax+0x1F]
00007f9c53bcf253  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf259  pinsrb xmm13, r12d, 0x07
00007f9c53bcf260  lea r14, [rax+0x20]
00007f9c53bcf264  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf26a  pinsrb xmm1, r12d, 0x08
00007f9c53bcf271  lea r14, [rax+0x21]
00007f9c53bcf275  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf27b  pinsrb xmm15, r12d, 0x08
00007f9c53bcf282  lea r14, [rax+0x22]
00007f9c53bcf286  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf28c  pinsrb xmm14, r12d, 0x08
00007f9c53bcf293  lea r14, [rax+0x23]
00007f9c53bcf297  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf29d  pinsrb xmm13, r12d, 0x08
00007f9c53bcf2a4  lea r14, [rax+0x24]
00007f9c53bcf2a8  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf2ae  pinsrb xmm1, r12d, 0x09
00007f9c53bcf2b5  lea r14, [rax+0x25]
00007f9c53bcf2b9  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf2bf  pinsrb xmm15, r12d, 0x09
00007f9c53bcf2c6  lea r14, [rax+0x26]
00007f9c53bcf2ca  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf2d0  pinsrb xmm14, r12d, 0x09
00007f9c53bcf2d7  lea r14, [rax+0x27]
00007f9c53bcf2db  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf2e1  pinsrb xmm13, r12d, 0x09
00007f9c53bcf2e8  lea r14, [rax+0x28]
00007f9c53bcf2ec  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf2f2  pinsrb xmm1, r12d, 0x0A
00007f9c53bcf2f9  lea r14, [rax+0x29]
00007f9c53bcf2fd  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf303  pinsrb xmm15, r12d, 0x0A
00007f9c53bcf30a  lea r14, [rax+0x2A]
00007f9c53bcf30e  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf314  pinsrb xmm14, r12d, 0x0A
00007f9c53bcf31b  lea r14, [rax+0x2B]
00007f9c53bcf31f  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf325  pinsrb xmm13, r12d, 0x0A
00007f9c53bcf32c  lea r14, [rax+0x2C]
00007f9c53bcf330  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf336  pinsrb xmm1, r12d, 0x0B
00007f9c53bcf33d  lea r14, [rax+0x2D]
00007f9c53bcf341  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf347  pinsrb xmm15, r12d, 0x0B
00007f9c53bcf34e  lea r14, [rax+0x2E]
00007f9c53bcf352  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf358  pinsrb xmm14, r12d, 0x0B
00007f9c53bcf35f  lea r14, [rax+0x2F]
00007f9c53bcf363  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf369  pinsrb xmm13, r12d, 0x0B
00007f9c53bcf370  lea r14, [rax+0x30]
00007f9c53bcf374  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf37a  pinsrb xmm1, r12d, 0x0C
00007f9c53bcf381  lea r14, [rax+0x31]
00007f9c53bcf385  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf38b  pinsrb xmm15, r12d, 0x0C
00007f9c53bcf392  lea r14, [rax+0x32]
00007f9c53bcf396  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf39c  pinsrb xmm14, r12d, 0x0C
00007f9c53bcf3a3  lea r14, [rax+0x33]
00007f9c53bcf3a7  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf3ad  pinsrb xmm13, r12d, 0x0C
00007f9c53bcf3b4  lea r14, [rax+0x34]
00007f9c53bcf3b8  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf3be  pinsrb xmm1, r12d, 0x0D
00007f9c53bcf3c5  lea r14, [rax+0x35]
00007f9c53bcf3c9  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf3cf  pinsrb xmm15, r12d, 0x0D
00007f9c53bcf3d6  lea r14, [rax+0x36]
00007f9c53bcf3da  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf3e0  pinsrb xmm14, r12d, 0x0D
00007f9c53bcf3e7  lea r14, [rax+0x37]
00007f9c53bcf3eb  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf3f1  pinsrb xmm13, r12d, 0x0D
00007f9c53bcf3f8  lea r14, [rax+0x38]
00007f9c53bcf3fc  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf402  pinsrb xmm1, r12d, 0x0E
00007f9c53bcf409  lea r14, [rax+0x39]
00007f9c53bcf40d  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf413  pinsrb xmm15, r12d, 0x0E
00007f9c53bcf41a  lea r14, [rax+0x3A]
00007f9c53bcf41e  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf424  pinsrb xmm14, r12d, 0x0E
00007f9c53bcf42b  lea r14, [rax+0x3B]
00007f9c53bcf42f  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf435  pinsrb xmm13, r12d, 0x0E
00007f9c53bcf43c  lea r14, [rax+0x3C]
00007f9c53bcf440  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf446  pinsrb xmm1, r12d, 0x0F
00007f9c53bcf44d  movaps [r15+0x110], xmm1
00007f9c53bcf455  lea r14, [rax+0x3D]
00007f9c53bcf459  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf45f  pinsrb xmm15, r12d, 0x0F
00007f9c53bcf466  movaps [r15+0x120], xmm15
00007f9c53bcf46e  lea r14, [rax+0x3E]
00007f9c53bcf472  movzx r12d, byte ptr [r13+r14*1]
00007f9c53bcf478  pinsrb xmm14, r12d, 0x0F
00007f9c53bcf47f  movaps [r15+0x130], xmm14
00007f9c53bcf487  lea r14, [rax+0x3F]
00007f9c53bcf48b  movzx eax, byte ptr [r13+r14*1]
00007f9c53bcf491  pinsrb xmm13, eax, 0x0F
00007f9c53bcf498  movaps [r15+0x140], xmm13
00007f9c53bcf4a0  movq xmm1, qword ptr [r15+0x120]
00007f9c53bcf4a9  pmovzxbw xmm1, xmm1
00007f9c53bcf4ae  psllw xmm1, 0x00
00007f9c53bcf4b3  movaps [r15+0x150], xmm1
00007f9c53bcf4bb  movq xmm1, qword ptr [r15+0x130]
00007f9c53bcf4c4  pmovzxbw xmm1, xmm1
00007f9c53bcf4c9  psllw xmm1, 0x00
00007f9c53bcf4ce  movaps [r15+0x160], xmm1
00007f9c53bcf4d6  movq xmm1, qword ptr [r15+0x110]
00007f9c53bcf4df  pmovzxbw xmm1, xmm1
00007f9c53bcf4e4  psllw xmm1, 0x00
00007f9c53bcf4e9  movaps [r15+0x170], xmm1
00007f9c53bcf4f1  movaps xmm15, [r15+0x110]
00007f9c53bcf4f9  pextrq rax, xmm15, 0x01
00007f9c53bcf500  movq xmm15, rax
00007f9c53bcf505  pmovzxbw xmm15, xmm15
00007f9c53bcf50b  psllw xmm15, 0x00
00007f9c53bcf511  movaps [r15+0x180], xmm15
00007f9c53bcf519  movaps xmm14, [r15+0x120]
00007f9c53bcf521  pextrq rax, xmm14, 0x01
00007f9c53bcf528  movq xmm14, rax
00007f9c53bcf52d  pmovzxbw xmm14, xmm14
00007f9c53bcf533  psllw xmm14, 0x00
00007f9c53bcf539  movaps [r15+0x210], xmm14
00007f9c53bcf541  movaps xmm13, [r15+0x130]
00007f9c53bcf549  pextrq rax, xmm13, 0x01
00007f9c53bcf550  movq xmm13, rax
00007f9c53bcf555  pmovzxbw xmm13, xmm13
00007f9c53bcf55b  psllw xmm13, 0x00
00007f9c53bcf561  movaps [r15+0x220], xmm13
00007f9c53bcf569  movq xmm12, qword ptr [r15+0x140]
00007f9c53bcf572  pmovzxbw xmm12, xmm12
00007f9c53bcf578  psllw xmm12, 0x00
00007f9c53bcf57e  movaps [r15+0x250], xmm12
00007f9c53bcf586  movaps xmm12, [r15+0x140]
00007f9c53bcf58e  pextrq rax, xmm12, 0x01
00007f9c53bcf595  movq xmm12, rax
00007f9c53bcf59a  pmovzxbw xmm12, xmm12
00007f9c53bcf5a0  psllw xmm12, 0x00
00007f9c53bcf5a6  movaps [r15+0x110], xmm12
00007f9c53bcf5ae  movq xmm11, qword ptr [r15+0x150]
00007f9c53bcf5b7  pmovzxwd xmm11, xmm11
00007f9c53bcf5bd  pslld xmm11, 0x10
00007f9c53bcf5c3  movq xmm10, qword ptr [r15+0x160]
00007f9c53bcf5cc  pmovzxwd xmm10, xmm10
00007f9c53bcf5d2  pslld xmm10, 0x08
00007f9c53bcf5d8  pextrq rax, xmm1, 0x01
00007f9c53bcf5df  movq xmm1, rax
00007f9c53bcf5e4  pmovzxwd xmm1, xmm1
00007f9c53bcf5e9  pslld xmm1, 0x00
00007f9c53bcf5ee  movaps [r15+0x260], xmm1
00007f9c53bcf5f6  pextrq rax, xmm15, 0x01
00007f9c53bcf5fd  movq xmm15, rax
00007f9c53bcf602  pmovzxwd xmm15, xmm15
00007f9c53bcf608  pslld xmm15, 0x00
00007f9c53bcf60e  movaps [r15+0x270], xmm15
00007f9c53bcf616  movq xmm9, qword ptr [r15+0x170]
00007f9c53bcf61f  pmovzxwd xmm9, xmm9
00007f9c53bcf625  pslld xmm9, 0x00
00007f9c53bcf62b  pextrq rax, xmm14, 0x01
00007f9c53bcf632  movq xmm14, rax
00007f9c53bcf637  pmovzxwd xmm14, xmm14
00007f9c53bcf63d  pslld xmm14, 0x10
00007f9c53bcf643  movaps [r15+0x280], xmm14
00007f9c53bcf64b  movq xmm8, qword ptr [r15+0x180]
00007f9c53bcf654  pmovzxwd xmm8, xmm8
00007f9c53bcf65a  pslld xmm8, 0x00
00007f9c53bcf660  movq xmm7, qword ptr [r15+0x210]
00007f9c53bcf669  pmovzxwd xmm7, xmm7
00007f9c53bcf66e  pslld xmm7, 0x10
00007f9c53bcf673  movaps xmm6, [r15+0x150]
00007f9c53bcf67b  pextrq rax, xmm6, 0x01
00007f9c53bcf682  movq xmm6, rax
00007f9c53bcf687  pmovzxwd xmm6, xmm6
00007f9c53bcf68c  pslld xmm6, 0x10
00007f9c53bcf691  por xmm11, xmm10
00007f9c53bcf696  movaps [r15+0x230], xmm11
00007f9c53bcf69e  pextrq rax, xmm13, 0x01
00007f9c53bcf6a5  movq xmm13, rax
00007f9c53bcf6aa  pmovzxwd xmm13, xmm13
00007f9c53bcf6b0  pslld xmm13, 0x08
00007f9c53bcf6b6  movaps [r15+0x240], xmm13
00007f9c53bcf6be  movq xmm10, qword ptr [r15+0x220]
00007f9c53bcf6c7  pmovzxwd xmm10, xmm10
00007f9c53bcf6cd  pslld xmm10, 0x08
00007f9c53bcf6d3  movaps xmm5, [r15+0x160]
00007f9c53bcf6db  pextrq rax, xmm5, 0x01
00007f9c53bcf6e2  movq xmm5, rax
00007f9c53bcf6e7  pmovzxwd xmm5, xmm5
00007f9c53bcf6ec  pslld xmm5, 0x08
00007f9c53bcf6f1  pslld xmm9, 0x18
00007f9c53bcf6f7  pslld xmm15, 0x18
00007f9c53bcf6fd  pslld xmm8, 0x18
00007f9c53bcf703  movq xmm4, qword ptr [r15+0x250]
00007f9c53bcf70c  pmovzxwd xmm4, xmm4
00007f9c53bcf711  pslld xmm4, 0x00
00007f9c53bcf716  por xmm14, xmm13
00007f9c53bcf71b  por xmm7, xmm10
00007f9c53bcf720  movaps [r15+0x210], xmm7
00007f9c53bcf728  pslld xmm1, 0x18
00007f9c53bcf72d  movaps [r15+0x220], xmm1
00007f9c53bcf735  por xmm6, xmm5
00007f9c53bcf739  por xmm11, xmm9
00007f9c53bcf73e  movaps [r15+0x160], xmm11
00007f9c53bcf746  pextrq rax, xmm12, 0x01
00007f9c53bcf74d  movq xmm13, rax
00007f9c53bcf752  pmovzxwd xmm13, xmm13
00007f9c53bcf758  pslld xmm13, 0x00
00007f9c53bcf75e  movaps [r15+0x170], xmm13
00007f9c53bcf766  movq xmm12, qword ptr [r15+0x110]
00007f9c53bcf76f  pmovzxwd xmm12, xmm12
00007f9c53bcf775  pslld xmm12, 0x00
00007f9c53bcf77b  por xmm14, xmm15
00007f9c53bcf780  por xmm7, xmm8
00007f9c53bcf785  movaps xmm15, [r15+0x250]
00007f9c53bcf78d  pextrq rax, xmm15, 0x01
00007f9c53bcf794  movq xmm15, rax
00007f9c53bcf799  pmovzxwd xmm15, xmm15
00007f9c53bcf79f  pslld xmm15, 0x00
00007f9c53bcf7a5  movaps [r15+0x180], xmm15
00007f9c53bcf7ad  por xmm6, xmm1
00007f9c53bcf7b1  movaps [r15+0x150], xmm6
00007f9c53bcf7b9  por xmm11, xmm4
00007f9c53bcf7be  movaps [r15+0x140], xmm11
00007f9c53bcf7c6  por xmm7, xmm12
00007f9c53bcf7cb  movaps [r15+0x110], xmm7
00007f9c53bcf7d3  por xmm14, xmm13
00007f9c53bcf7d8  movaps [r15+0x120], xmm14
00007f9c53bcf7e0  por xmm6, xmm15
00007f9c53bcf7e5  movaps [r15+0x130], xmm6
00007f9c53bcf7ed  mov rax, [r15+0xF8]
00007f9c53bcf7f4  lea r14, [rax+0x20]
00007f9c53bcf7f8  movups [r13+r14*1], xmm7
00007f9c53bcf7fe  lea r14, [rax+0x30]
00007f9c53bcf802  movups [r13+r14*1], xmm14
00007f9c53bcf808  movups [r13+rax*1], xmm11
00007f9c53bcf80e  lea r14, [rax+0x10]
00007f9c53bcf812  movups [r13+r14*1], xmm6
00007f9c53bcf818  mov r14d, [r13+rax*1]
00007f9c53bcf81d  mov rax, [r15+0x48]
00007f9c53bcf821  mov [r15+0x68], rax
00007f9c53bcf825  mov qword ptr [r15+0x58], 0x04
00007f9c53bcf82d  lea r12, [rax+0x04]
00007f9c53bcf831  mov r11d, [r13+r12*1]
00007f9c53bcf836  mov [rsp+0x10], r11d
00007f9c53bcf83b  mov r11d, r11d
00007f9c53bcf83e  mov [r15+0x70], r11
00007f9c53bcf842  lea r12, [rax+0x38]
00007f9c53bcf846  mov r11d, [r13+r12*1]
00007f9c53bcf84b  lea r12, [rax+0x24]
00007f9c53bcf84f  mov r10d, [r13+r12*1]
00007f9c53bcf854  mov [rsp+0x20], r10d
00007f9c53bcf859  mov r10d, r10d
00007f9c53bcf85c  mov [r15+0x90], r10
00007f9c53bcf863  mov [rsp+0x30], rax
00007f9c53bcf868  xor eax, eax
00007f9c53bcf86a  mov r12d, 0x04
00007f9c53bcf870  mov r10d, 0xC0
00007f9c53bcf876  cmp r12, r10
00007f9c53bcf879  cmc
00007f9c53bcf87a  lahf
00007f9c53bcf87b  seto al
00007f9c53bcf87e  mov [r15+0x108], eax
00007f9c53bcf885  mov eax, [rsp+0x10]
00007f9c53bcf889  mov r12d, [rsp+0x10]
00007f9c53bcf88e  shrd eax, r12d, 0x07
00007f9c53bcf893  mov [rsp+0x10], r11d
00007f9c53bcf898  mov r10d, [rsp+0x10]
00007f9c53bcf89d  shrd r11d, r10d, 0x11
00007f9c53bcf8a2  mov r9d, [rsp+0x20]
00007f9c53bcf8a7  lea r8d, [r9d+r14d*1]
00007f9c53bcf8ac  rorx r14d, r12d, 0x12
00007f9c53bcf8b2  xor eax, r14d
00007f9c53bcf8b5  rorx r14d, r10d, 0x13
00007f9c53bcf8bb  xor r11d, r14d
00007f9c53bcf8be  mov [rsp+0x10], r11d
00007f9c53bcf8c3  mov r11d, r11d
00007f9c53bcf8c6  mov [r15+0x88], r11
00007f9c53bcf8cd  mov [rsp+0x20], r12d
00007f9c53bcf8d2  shr r12d, 0x03
00007f9c53bcf8d6  xor eax, r12d
00007f9c53bcf8d9  mov [rsp+0x40], eax
00007f9c53bcf8dd  mov eax, eax
00007f9c53bcf8df  mov [r15+0x80], rax
00007f9c53bcf8e6  shr r10d, 0x0A
00007f9c53bcf8ea  mov eax, [rsp+0x10]
00007f9c53bcf8ee  xor eax, r10d
00007f9c53bcf8f1  mov [rsp+0x10], eax
00007f9c53bcf8f5  mov eax, eax
00007f9c53bcf8f7  mov [r15+0x78], rax
00007f9c53bcf8fb  mov eax, [rsp+0x40]
00007f9c53bcf8ff  lea r14d, [r8d+eax*1]
00007f9c53bcf904  mov eax, [rsp+0x10]
00007f9c53bcf908  lea r12d, [r14d+eax*1]
00007f9c53bcf90d  mov rax, [rsp+0x30]
00007f9c53bcf912  lea r14, [rax+0x40]
00007f9c53bcf916  mov [r13+r14*1], r12d
00007f9c53bcf91b  mov eax, [rsp+0x20]
00007f9c53bcf91f  mov eax, eax
00007f9c53bcf921  mov [r15+0x60], rax
00007f9c53bcf925  mov eax, [r15+0x108]
00007f9c53bcf92c  sahf
00007f9c53bcf92d  jnz 0x00007F9C53BCF95F
00007f9c53bcf92f  cmp dword ptr [r15+0x318], 0x00
00007f9c53bcf937  jz 0x00007F9C53BCFE20
00007f9c53bcf93d  nop [rax+rax*1], ax
00007f9c53bcf946  nop [rax+rax*1], eax
00007f9c53bcf94e  mov eax, 0x41049C
00007f9c53bcf953  mov [r15+0x100], rax
00007f9c53bcf95a  jmp 0x00007F9C539FE110
00007f9c53bcf95f  cmp dword ptr [r15+0x318], 0x00
00007f9c53bcf967  jz 0x00007F9C53BCFC70
00007f9c53bcf96d  nop [rax+rax*1], ax
00007f9c53bcf976  nop [rax+rax*1], eax
00007f9c53bcf97e  mov eax, 0x410454
00007f9c53bcf983  mov [r15+0x100], rax
00007f9c53bcf98a  jmp 0x00007F9C539FE110
00007f9c53bcf98f  int3
00007f9c53bcf990  call 0x00007F9C53A0D860
00007f9c53bcf995  jmp 0x00007F9C53BCF02A
00007f9c53bcf99a  call 0x00007F9C53AE2420
00007f9c53bcf99f  jmp 0x00007F9C53BCF043
00007f9c53bcf9a4  call 0x00007F9C53AE2420
00007f9c53bcf9a9  jmp 0x00007F9C53BCF05C
00007f9c53bcf9ae  call 0x00007F9C53AE2420
00007f9c53bcf9b3  jmp 0x00007F9C53BCF075
00007f9c53bcf9b8  call 0x00007F9C53AE2420
00007f9c53bcf9bd  jmp 0x00007F9C53BCF08E
00007f9c53bcf9c2  call 0x00007F9C53AE2420
00007f9c53bcf9c7  jmp 0x00007F9C53BCF09F
00007f9c53bcf9cc  call 0x00007F9C53AE2420
00007f9c53bcf9d1  jmp 0x00007F9C53BCF0B0
00007f9c53bcf9d6  call 0x00007F9C53AE2420
00007f9c53bcf9db  jmp 0x00007F9C53BCF0C1
00007f9c53bcf9e0  call 0x00007F9C53AE2420
00007f9c53bcf9e5  jmp 0x00007F9C53BCF0D2
00007f9c53bcf9ea  call 0x00007F9C53AE2420
00007f9c53bcf9ef  jmp 0x00007F9C53BCF0E3
00007f9c53bcf9f4  call 0x00007F9C53AE2420
00007f9c53bcf9f9  jmp 0x00007F9C53BCF0F4
00007f9c53bcf9fe  call 0x00007F9C53AE2420
00007f9c53bcfa03  jmp 0x00007F9C53BCF105
00007f9c53bcfa08  call 0x00007F9C53AE2420
00007f9c53bcfa0d  jmp 0x00007F9C53BCF116
00007f9c53bcfa12  call 0x00007F9C53AE2420
00007f9c53bcfa17  jmp 0x00007F9C53BCF127
00007f9c53bcfa1c  call 0x00007F9C53AE2420
00007f9c53bcfa21  jmp 0x00007F9C53BCF138
00007f9c53bcfa26  call 0x00007F9C53AE2420
00007f9c53bcfa2b  jmp 0x00007F9C53BCF149
00007f9c53bcfa30  call 0x00007F9C53AE2420
00007f9c53bcfa35  jmp 0x00007F9C53BCF15A
00007f9c53bcfa3a  call 0x00007F9C53AE2420
00007f9c53bcfa3f  jmp 0x00007F9C53BCF16B
00007f9c53bcfa44  call 0x00007F9C53AE2420
00007f9c53bcfa49  jmp 0x00007F9C53BCF17C
00007f9c53bcfa4e  call 0x00007F9C53AE2420
00007f9c53bcfa53  jmp 0x00007F9C53BCF18D
00007f9c53bcfa58  call 0x00007F9C53AE2420
00007f9c53bcfa5d  jmp 0x00007F9C53BCF19E
00007f9c53bcfa62  call 0x00007F9C53AE2420
00007f9c53bcfa67  jmp 0x00007F9C53BCF1AF
00007f9c53bcfa6c  call 0x00007F9C53AE2420
00007f9c53bcfa71  jmp 0x00007F9C53BCF1C0
00007f9c53bcfa76  call 0x00007F9C53AE2420
00007f9c53bcfa7b  jmp 0x00007F9C53BCF1D1
00007f9c53bcfa80  call 0x00007F9C53AE2420
00007f9c53bcfa85  jmp 0x00007F9C53BCF1E2
00007f9c53bcfa8a  call 0x00007F9C53AE2420
00007f9c53bcfa8f  jmp 0x00007F9C53BCF1F3
00007f9c53bcfa94  call 0x00007F9C53AE2420
00007f9c53bcfa99  jmp 0x00007F9C53BCF204
00007f9c53bcfa9e  call 0x00007F9C53AE2420
00007f9c53bcfaa3  jmp 0x00007F9C53BCF215
00007f9c53bcfaa8  call 0x00007F9C53AE2420
00007f9c53bcfaad  jmp 0x00007F9C53BCF226
00007f9c53bcfab2  call 0x00007F9C53AE2420
00007f9c53bcfab7  jmp 0x00007F9C53BCF237
00007f9c53bcfabc  call 0x00007F9C53AE2420
00007f9c53bcfac1  jmp 0x00007F9C53BCF248
00007f9c53bcfac6  call 0x00007F9C53AE2420
00007f9c53bcfacb  jmp 0x00007F9C53BCF259
00007f9c53bcfad0  call 0x00007F9C53AE2420
00007f9c53bcfad5  jmp 0x00007F9C53BCF26A
00007f9c53bcfada  call 0x00007F9C53AE2420
00007f9c53bcfadf  jmp 0x00007F9C53BCF27B
00007f9c53bcfae4  call 0x00007F9C53AE2420
00007f9c53bcfae9  jmp 0x00007F9C53BCF28C
00007f9c53bcfaee  call 0x00007F9C53AE2420
00007f9c53bcfaf3  jmp 0x00007F9C53BCF29D
00007f9c53bcfaf8  call 0x00007F9C53AE2420
00007f9c53bcfafd  jmp 0x00007F9C53BCF2AE
00007f9c53bcfb02  call 0x00007F9C53AE2420
00007f9c53bcfb07  jmp 0x00007F9C53BCF2BF
00007f9c53bcfb0c  call 0x00007F9C53AE2420
00007f9c53bcfb11  jmp 0x00007F9C53BCF2D0
00007f9c53bcfb16  call 0x00007F9C53AE2420
00007f9c53bcfb1b  jmp 0x00007F9C53BCF2E1
00007f9c53bcfb20  call 0x00007F9C53AE2420
00007f9c53bcfb25  jmp 0x00007F9C53BCF2F2
00007f9c53bcfb2a  call 0x00007F9C53AE2420
00007f9c53bcfb2f  jmp 0x00007F9C53BCF303
00007f9c53bcfb34  call 0x00007F9C53AE2420
00007f9c53bcfb39  jmp 0x00007F9C53BCF314
00007f9c53bcfb3e  call 0x00007F9C53AE2420
00007f9c53bcfb43  jmp 0x00007F9C53BCF325
00007f9c53bcfb48  call 0x00007F9C53AE2420
00007f9c53bcfb4d  jmp 0x00007F9C53BCF336
00007f9c53bcfb52  call 0x00007F9C53AE2420
00007f9c53bcfb57  jmp 0x00007F9C53BCF347
00007f9c53bcfb5c  call 0x00007F9C53AE2420
00007f9c53bcfb61  jmp 0x00007F9C53BCF358
00007f9c53bcfb66  call 0x00007F9C53AE2420
00007f9c53bcfb6b  jmp 0x00007F9C53BCF369
00007f9c53bcfb70  call 0x00007F9C53AE2420
00007f9c53bcfb75  jmp 0x00007F9C53BCF37A
00007f9c53bcfb7a  call 0x00007F9C53AE2420
00007f9c53bcfb7f  jmp 0x00007F9C53BCF38B
00007f9c53bcfb84  call 0x00007F9C53AE2420
00007f9c53bcfb89  jmp 0x00007F9C53BCF39C
00007f9c53bcfb8e  call 0x00007F9C53AE2420
00007f9c53bcfb93  jmp 0x00007F9C53BCF3AD
00007f9c53bcfb98  call 0x00007F9C53AE2420
00007f9c53bcfb9d  jmp 0x00007F9C53BCF3BE
00007f9c53bcfba2  call 0x00007F9C53AE2420
00007f9c53bcfba7  jmp 0x00007F9C53BCF3CF
00007f9c53bcfbac  call 0x00007F9C53AE2420
00007f9c53bcfbb1  jmp 0x00007F9C53BCF3E0
00007f9c53bcfbb6  call 0x00007F9C53AE2420
00007f9c53bcfbbb  jmp 0x00007F9C53BCF3F1
00007f9c53bcfbc0  call 0x00007F9C53AE2420
00007f9c53bcfbc5  jmp 0x00007F9C53BCF402
00007f9c53bcfbca  call 0x00007F9C53AE2420
00007f9c53bcfbcf  jmp 0x00007F9C53BCF413
00007f9c53bcfbd4  call 0x00007F9C53AE2420
00007f9c53bcfbd9  jmp 0x00007F9C53BCF424
00007f9c53bcfbde  call 0x00007F9C53AE2420
00007f9c53bcfbe3  jmp 0x00007F9C53BCF435
00007f9c53bcfbe8  call 0x00007F9C53AE2420
00007f9c53bcfbed  jmp 0x00007F9C53BCF446
00007f9c53bcfbf2  call 0x00007F9C53AE2420
00007f9c53bcfbf7  jmp 0x00007F9C53BCF45F
00007f9c53bcfbfc  call 0x00007F9C53AE2420
00007f9c53bcfc01  jmp 0x00007F9C53BCF478
00007f9c53bcfc06  call 0x00007F9C53AD5610
00007f9c53bcfc0b  jmp 0x00007F9C53BCF491
00007f9c53bcfc10  call 0x00007F9C53ADC580
00007f9c53bcfc15  jmp 0x00007F9C53BCF7FE
00007f9c53bcfc1a  call 0x00007F9C53AE46C0
00007f9c53bcfc1f  jmp 0x00007F9C53BCF808
00007f9c53bcfc24  call 0x00007F9C53A09E90
00007f9c53bcfc29  jmp 0x00007F9C53BCF80E
00007f9c53bcfc2e  call 0x00007F9C53ADB310
00007f9c53bcfc33  jmp 0x00007F9C53BCF818
00007f9c53bcfc38  call 0x00007F9C53A0DAE0
00007f9c53bcfc3d  jmp 0x00007F9C53BCF81D
00007f9c53bcfc42  call 0x00007F9C53AC0230
00007f9c53bcfc47  jmp 0x00007F9C53BCF836
00007f9c53bcfc4c  call 0x00007F9C53AC0230
00007f9c53bcfc51  jmp 0x00007F9C53BCF84B
00007f9c53bcfc56  call 0x00007F9C53ABEFC0
00007f9c53bcfc5b  jmp 0x00007F9C53BCF854
00007f9c53bcfc60  call 0x00007F9C53AE2BA0
00007f9c53bcfc65  jmp 0x00007F9C53BCF91B
00007f9c53bcfc6a  int3
00007f9c53bcfc6b  nop [rax+rax*1], eax
00007f9c53bcfc70  mov rax, [r15+0x48]
00007f9c53bcfc74  mov r14, [r15+0x58]
00007f9c53bcfc78  lea r12, [rax+r14*1]
00007f9c53bcfc7c  mov [r15+0x68], r12
00007f9c53bcfc80  lea rax, [r14+0x04]
00007f9c53bcfc84  mov [r15+0x58], rax
00007f9c53bcfc88  lea r14, [r12+0x04]
00007f9c53bcfc8d  mov r11d, [r13+r14*1]
00007f9c53bcfc92  mov [rsp+0x10], r11d
00007f9c53bcfc97  mov r11d, r11d
00007f9c53bcfc9a  mov [r15+0x70], r11
00007f9c53bcfc9e  lea r14, [r12+0x38]
00007f9c53bcfca3  mov r11d, [r13+r14*1]
00007f9c53bcfca8  lea r14, [r12+0x24]
00007f9c53bcfcad  mov r10d, [r13+r14*1]
00007f9c53bcfcb2  mov [rsp+0x20], r10d
00007f9c53bcfcb7  mov r10d, r10d
00007f9c53bcfcba  mov [r15+0x90], r10
00007f9c53bcfcc1  mov [rsp+0x30], rax
00007f9c53bcfcc6  xor eax, eax
00007f9c53bcfcc8  mov r14, [rsp+0x30]
00007f9c53bcfccd  mov r10d, 0xC0
00007f9c53bcfcd3  cmp r14, r10
00007f9c53bcfcd6  cmc
00007f9c53bcfcd7  lahf
00007f9c53bcfcd8  seto al
00007f9c53bcfcdb  mov [r15+0x108], eax
00007f9c53bcfce2  mov eax, [rsp+0x10]
00007f9c53bcfce6  mov r14d, [rsp+0x10]
00007f9c53bcfceb  shrd eax, r14d, 0x07
00007f9c53bcfcf0  mov [rsp+0x10], r11d
00007f9c53bcfcf5  mov r10d, [rsp+0x10]
00007f9c53bcfcfa  shrd r11d, r10d, 0x11
00007f9c53bcfcff  mov r9d, [r15+0x60]
00007f9c53bcfd03  mov r8d, [rsp+0x20]
00007f9c53bcfd08  lea ebp, [r8d+r9d*1]
00007f9c53bcfd0d  rorx r9d, r14d, 0x12
00007f9c53bcfd13  xor eax, r9d
00007f9c53bcfd16  rorx r9d, r10d, 0x13
00007f9c53bcfd1c  xor r11d, r9d
00007f9c53bcfd1f  mov [rsp+0x10], r11d
00007f9c53bcfd24  mov r11d, r11d
00007f9c53bcfd27  mov [r15+0x88], r11
00007f9c53bcfd2e  mov [rsp+0x20], r14d
00007f9c53bcfd33  shr r14d, 0x03
00007f9c53bcfd37  xor eax, r14d
00007f9c53bcfd3a  mov [rsp+0x30], eax
00007f9c53bcfd3e  mov eax, eax
00007f9c53bcfd40  mov [r15+0x80], rax
00007f9c53bcfd47  shr r10d, 0x0A
00007f9c53bcfd4b  mov eax, [rsp+0x10]
00007f9c53bcfd4f  xor eax, r10d
00007f9c53bcfd52  mov [rsp+0x10], eax
00007f9c53bcfd56  mov eax, eax
00007f9c53bcfd58  mov [r15+0x78], rax
00007f9c53bcfd5c  mov eax, [rsp+0x30]
00007f9c53bcfd60  lea r14d, [ebp+eax*1]
00007f9c53bcfd66  mov eax, [rsp+0x10]
00007f9c53bcfd6a  lea r11d, [r14d+eax*1]
00007f9c53bcfd6f  lea rax, [r12+0x40]
00007f9c53bcfd74  mov [r13+rax*1], r11d
00007f9c53bcfd79  mov eax, [rsp+0x20]
00007f9c53bcfd7d  mov eax, eax
00007f9c53bcfd7f  mov [r15+0x60], rax
00007f9c53bcfd83  mov eax, [r15+0x108]
00007f9c53bcfd8a  sahf
00007f9c53bcfd8b  jnz 0x00007F9C53BCFDBD
00007f9c53bcfd8d  cmp dword ptr [r15+0x318], 0x00
00007f9c53bcfd95  jz 0x00007F9C53BCFE20
00007f9c53bcfd9b  nop [rax+rax*1], ax
00007f9c53bcfda4  nop [rax+rax*1], eax
00007f9c53bcfdac  mov eax, 0x41049C
00007f9c53bcfdb1  mov [r15+0x100], rax
00007f9c53bcfdb8  jmp 0x00007F9C539FE110
00007f9c53bcfdbd  cmp dword ptr [r15+0x318], 0x00
00007f9c53bcfdc5  jz 0x00007F9C53BCFC70
00007f9c53bcfdcb  nop [rax+rax*1], ax
00007f9c53bcfdd4  nop [rax+rax*1], eax
00007f9c53bcfddc  mov eax, 0x410454
00007f9c53bcfde1  mov [r15+0x100], rax
00007f9c53bcfde8  jmp 0x00007F9C539FE110
00007f9c53bcfded  int3
00007f9c53bcfdee  call 0x00007F9C53AE1430
00007f9c53bcfdf3  jmp 0x00007F9C53BCFC92
00007f9c53bcfdf8  call 0x00007F9C53AE1430
00007f9c53bcfdfd  jmp 0x00007F9C53BCFCA8
00007f9c53bcfe02  call 0x00007F9C53AE01C0
00007f9c53bcfe07  jmp 0x00007F9C53BCFCB2
00007f9c53bcfe0c  call 0x00007F9C53A0A860
00007f9c53bcfe11  jmp 0x00007F9C53BCFD79
00007f9c53bcfe16  int3
00007f9c53bcfe17  nop [rax+rax*1], ax
00007f9c53bcfe20  mov rax, [r15]
00007f9c53bcfe23  mov r14d, [r13+rax*1]
00007f9c53bcfe28  lea r12, [rax+0x04]
00007f9c53bcfe2c  mov r11d, [r13+r12*1]
00007f9c53bcfe31  mov [rsp+0x10], r14d
00007f9c53bcfe36  mov r14d, r14d
00007f9c53bcfe39  mov [r15+0x78], r14
00007f9c53bcfe3d  mov [rsp+0x20], r11d
00007f9c53bcfe42  mov r11d, r11d
00007f9c53bcfe45  mov [r15+0x80], r11
00007f9c53bcfe4c  lea r14, [rax+0x08]
00007f9c53bcfe50  mov r12d, [r13+r14*1]
00007f9c53bcfe55  lea r14, [rax+0x0C]
00007f9c53bcfe59  mov r11d, [r13+r14*1]
00007f9c53bcfe5e  mov [rsp+0x30], r12d
00007f9c53bcfe63  mov r12d, r12d
00007f9c53bcfe66  mov [r15+0x70], r12
00007f9c53bcfe6a  mov [rsp+0x40], r11d
00007f9c53bcfe6f  mov r11d, r11d
00007f9c53bcfe72  mov [r15+0x68], r11
00007f9c53bcfe76  lea r14, [rax+0x18]
00007f9c53bcfe7a  mov r12d, [r13+r14*1]
00007f9c53bcfe7f  lea r14, [rax+0x1C]
00007f9c53bcfe83  mov r11d, [r13+r14*1]
00007f9c53bcfe88  mov [rsp+0x50], r12d
00007f9c53bcfe8d  mov r12d, r12d
00007f9c53bcfe90  mov [r15+0x58], r12
00007f9c53bcfe94  mov [rsp+0x60], r11d
00007f9c53bcfe99  mov r11d, r11d
00007f9c53bcfe9c  mov [r15+0x60], r11
00007f9c53bcfea0  lea r14, [rax+0x10]
00007f9c53bcfea4  mov r12d, [r13+r14*1]
00007f9c53bcfea9  lea r14, [rax+0x14]
00007f9c53bcfead  mov eax, [r13+r14*1]
00007f9c53bcfeb2  mov [rsp+0x70], r12d
00007f9c53bcfeb7  mov r12d, r12d
00007f9c53bcfeba  mov [r15+0x18], r12
00007f9c53bcfebe  mov [rsp+0x80], eax
00007f9c53bcfec5  mov eax, eax
00007f9c53bcfec7  mov [r15+0x90], rax
00007f9c53bcfece  mov eax, [rsp+0x70]
00007f9c53bcfed2  mov eax, eax
00007f9c53bcfed4  mov [r15+0x30], rax
00007f9c53bcfed8  mov eax, [rsp+0x50]
00007f9c53bcfedc  mov eax, eax
00007f9c53bcfede  mov [r15+0xA0], rax
00007f9c53bcfee5  mov eax, [rsp+0x30]
00007f9c53bcfee9  mov eax, eax
00007f9c53bcfeeb  mov [r15+0x28], rax
00007f9c53bcfeef  mov eax, [rsp+0x20]
00007f9c53bcfef3  mov eax, eax
00007f9c53bcfef5  mov [r15+0x98], rax
00007f9c53bcfefc  mov eax, [rsp+0x10]
00007f9c53bcff00  mov eax, eax
00007f9c53bcff02  mov [r15+0x38], rax
00007f9c53bcff06  mov eax, [rsp+0x70]
00007f9c53bcff0a  mov r14d, [rsp+0x70]
00007f9c53bcff0f  shrd eax, r14d, 0x06
00007f9c53bcff14  mov [rsp+0x70], r14d
00007f9c53bcff19  mov r12d, [rsp+0x80]
00007f9c53bcff21  and r14d, r12d
00007f9c53bcff24  mov r11d, [rsp+0x10]
00007f9c53bcff29  mov r10d, [rsp+0x10]
00007f9c53bcff2e  shrd r11d, r10d, 0x02
00007f9c53bcff33  mov [rsp+0x10], r12d
00007f9c53bcff38  mov r12d, r12d
00007f9c53bcff3b  mov [r15+0x20], r12
00007f9c53bcff3f  mov r12, [r15+0x50]
00007f9c53bcff43  mov r9d, [r13+r12*1]
00007f9c53bcff48  mov r12d, [rsp+0x50]
00007f9c53bcff4d  mov r8d, [rsp+0x70]
00007f9c53bcff52  andn ebp, r8d, r12d
00007f9c53bcff57  mov edi, [rsp+0x60]
00007f9c53bcff5b  lea esi, [r14d+edi*1]
00007f9c53bcff60  rorx r14d, r8d, 0x0B
00007f9c53bcff66  xor eax, r14d
00007f9c53bcff69  rorx r14d, r10d, 0x0D
00007f9c53bcff6f  xor r11d, r14d
00007f9c53bcff72  lea edi, [esi+ebp*1]
00007f9c53bcff76  mov r14, [r15+0x48]
00007f9c53bcff7a  mov ebp, [r13+r14*1]
00007f9c53bcff7f  mov r14d, [rsp+0x30]
00007f9c53bcff84  mov esi, [rsp+0x20]
00007f9c53bcff88  and r14d, esi
00007f9c53bcff8b  mov [rsp+0x20], r14d
00007f9c53bcff90  mov r14d, r14d
00007f9c53bcff93  mov [r15+0xD8], r14
00007f9c53bcff9a  lea r14d, [edi+r9d*1]
00007f9c53bcff9f  mov r9d, [rsp+0x30]
00007f9c53bcffa4  xor r9d, esi
00007f9c53bcffa7  rorx edi, r8d, 0x19
00007f9c53bcffad  xor eax, edi
00007f9c53bcffaf  and r9d, r10d
00007f9c53bcffb2  rorx edi, r10d, 0x16
00007f9c53bcffb8  xor r11d, edi
00007f9c53bcffbb  mov [rsp+0x30], r11d
00007f9c53bcffc0  mov r11d, r11d
00007f9c53bcffc3  mov [r15+0xD0], r11
00007f9c53bcffca  lea r11d, [r14d+ebp*1]
00007f9c53bcffcf  mov r10d, [rsp+0x20]
00007f9c53bcffd4  xor r9d, r10d
00007f9c53bcffd7  lea r14d, [r11d+eax*1]
00007f9c53bcffdc  mov qword ptr [r15+0x88], 0x04
00007f9c53bcffe7  mov eax, [rsp+0x30]
00007f9c53bcffeb  lea r11d, [r9d+eax*1]
00007f9c53bcfff0  mov eax, [rsp+0x40]
00007f9c53bcfff4  lea r10d, [r14d+eax*1]
00007f9c53bcfff9  mov r10d, r10d
00007f9c53bcfffc  mov [r15+0xB8], r10
00007f9c53bd0003  xor eax, eax
00007f9c53bd0005  mov r10d, 0x04
00007f9c53bd000b  mov r9d, 0x100
00007f9c53bd0011  cmp r10, r9
00007f9c53bd0014  cmc
00007f9c53bd0015  lahf
00007f9c53bd0016  seto al
00007f9c53bd0019  mov [r15+0x108], eax
00007f9c53bd0020  lea eax, [r11d+r14d*1]
00007f9c53bd0025  mov eax, eax
00007f9c53bd0027  mov [r15+0xA8], rax
00007f9c53bd002e  mov r12d, r12d
00007f9c53bd0031  mov [r15+0xB0], r12
00007f9c53bd0038  mov eax, [rsp+0x10]
00007f9c53bd003c  mov eax, eax
00007f9c53bd003e  mov [r15+0xC0], rax
00007f9c53bd0045  mov r8d, r8d
00007f9c53bd0048  mov [r15+0xC8], r8
00007f9c53bd004f  mov eax, [r15+0x108]
00007f9c53bd0056  sahf
00007f9c53bd0057  jnz 0x00007F9C53BD0089
00007f9c53bd0059  cmp dword ptr [r15+0x318], 0x00
00007f9c53bd0061  jz 0x00007F9C53BD0350
00007f9c53bd0067  nop [rax+rax*1], ax
00007f9c53bd0070  nop [rax+rax*1], eax
00007f9c53bd0078  mov eax, 0x41055C
00007f9c53bd007d  mov [r15+0x100], rax
00007f9c53bd0084  jmp 0x00007F9C539FE110
00007f9c53bd0089  cmp dword ptr [r15+0x318], 0x00
00007f9c53bd0091  jz 0x00007F9C53BD0120
00007f9c53bd0097  nop [rax+rax*1], ax
00007f9c53bd00a0  nop [rax+rax*1], eax
00007f9c53bd00a8  mov eax, 0x4104D0
00007f9c53bd00ad  mov [r15+0x100], rax
00007f9c53bd00b4  jmp 0x00007F9C539FE110
00007f9c53bd00b9  int3
00007f9c53bd00ba  call 0x00007F9C53A0DAE0
00007f9c53bd00bf  jmp 0x00007F9C53BCFE28
00007f9c53bd00c4  call 0x00007F9C53AC0230
00007f9c53bd00c9  jmp 0x00007F9C53BCFE31
00007f9c53bd00ce  call 0x00007F9C53AE26A0
00007f9c53bd00d3  jmp 0x00007F9C53BCFE55
00007f9c53bd00d8  call 0x00007F9C53AE1430
00007f9c53bd00dd  jmp 0x00007F9C53BCFE5E
00007f9c53bd00e2  call 0x00007F9C53AE26A0
00007f9c53bd00e7  jmp 0x00007F9C53BCFE7F
00007f9c53bd00ec  call 0x00007F9C53AE1430
00007f9c53bd00f1  jmp 0x00007F9C53BCFE88
00007f9c53bd00f6  call 0x00007F9C53AE26A0
00007f9c53bd00fb  jmp 0x00007F9C53BCFEA9
00007f9c53bd0100  call 0x00007F9C53AD5890
00007f9c53bd0105  jmp 0x00007F9C53BCFEB2
00007f9c53bd010a  call 0x00007F9C53ABDD50
00007f9c53bd010f  jmp 0x00007F9C53BCFF48
00007f9c53bd0114  call 0x00007F9C53ADA580
00007f9c53bd0119  jmp 0x00007F9C53BCFF7F
00007f9c53bd011e  int3
00007f9c53bd011f  nop
00007f9c53bd0120  mov eax, [r15+0xB8]
00007f9c53bd0127  mov [rsp+0x10], eax
00007f9c53bd012b  mov eax, eax
00007f9c53bd012d  mov [r15+0x30], rax
00007f9c53bd0131  mov eax, [r15+0xC0]
00007f9c53bd0138  mov [rsp+0x20], eax
00007f9c53bd013c  mov eax, eax
00007f9c53bd013e  mov [r15+0xA0], rax
00007f9c53bd0145  mov eax, [r15+0x28]
00007f9c53bd0149  mov r14d, [r15+0x98]
00007f9c53bd0150  mov [rsp+0x30], r14d
00007f9c53bd0155  mov r14d, r14d
00007f9c53bd0158  mov [r15+0x28], r14
00007f9c53bd015c  mov r14d, [r15+0x38]
00007f9c53bd0160  mov [rsp+0x40], r14d
00007f9c53bd0165  mov r14d, r14d
00007f9c53bd0168  mov [r15+0x98], r14
00007f9c53bd016f  mov r14d, [r15+0xA8]
00007f9c53bd0176  mov [rsp+0x50], r14d
00007f9c53bd017b  mov r14d, r14d
00007f9c53bd017e  mov [r15+0x38], r14
00007f9c53bd0182  mov r14d, [rsp+0x10]
00007f9c53bd0187  mov r12d, [rsp+0x10]
00007f9c53bd018c  shrd r14d, r12d, 0x06
00007f9c53bd0191  mov r11d, [r15+0xC8]
00007f9c53bd0198  mov [rsp+0x10], r12d
00007f9c53bd019d  and r12d, r11d
00007f9c53bd01a0  mov r10d, [rsp+0x50]
00007f9c53bd01a5  mov r9d, [rsp+0x50]
00007f9c53bd01aa  shrd r10d, r9d, 0x02
00007f9c53bd01af  mov [rsp+0x50], r11d
00007f9c53bd01b4  mov r11d, r11d
00007f9c53bd01b7  mov [r15+0x20], r11
00007f9c53bd01bb  mov r11, [r15+0x88]
00007f9c53bd01c2  mov r8, [r15+0x50]
00007f9c53bd01c6  lea rbp, [r8+r11*1]
00007f9c53bd01ca  mov r8d, [r13+rbp*1]
00007f9c53bd01cf  mov ebp, [rsp+0x20]
00007f9c53bd01d3  mov edi, [rsp+0x10]
00007f9c53bd01d7  andn esi, edi, ebp
00007f9c53bd01dc  mov edx, [r15+0xB0]
00007f9c53bd01e3  lea ecx, [r12d+edx*1]
00007f9c53bd01e8  rorx r12d, edi, 0x0B
00007f9c53bd01ee  xor r14d, r12d
00007f9c53bd01f1  rorx r12d, r9d, 0x0D
00007f9c53bd01f7  xor r10d, r12d
00007f9c53bd01fa  lea r12d, [ecx+esi*1]
00007f9c53bd01ff  mov rsi, [r15+0x48]
00007f9c53bd0203  lea rdx, [rsi+r11*1]
00007f9c53bd0207  mov esi, [r13+rdx*1]
00007f9c53bd020c  mov edx, [rsp+0x30]
00007f9c53bd0210  mov ecx, [rsp+0x40]
00007f9c53bd0214  and edx, ecx
00007f9c53bd0216  mov [rsp+0x10], edx
00007f9c53bd021a  mov edx, edx
00007f9c53bd021c  mov [r15+0xD8], rdx
00007f9c53bd0223  lea edx, [r12d+r8d*1]
00007f9c53bd0228  mov r12d, [rsp+0x30]
00007f9c53bd022d  xor r12d, ecx
00007f9c53bd0230  rorx r8d, edi, 0x19
00007f9c53bd0236  xor r14d, r8d
00007f9c53bd0239  and r12d, r9d
00007f9c53bd023c  rorx r8d, r9d, 0x16
00007f9c53bd0242  xor r10d, r8d
00007f9c53bd0245  mov [rsp+0x20], r10d
00007f9c53bd024a  mov r10d, r10d
00007f9c53bd024d  mov [r15+0xD0], r10
00007f9c53bd0254  lea r10d, [edx+esi*1]
00007f9c53bd0259  mov r9d, [rsp+0x10]
00007f9c53bd025e  xor r12d, r9d
00007f9c53bd0261  lea r9d, [r10d+r14d*1]
00007f9c53bd0266  lea r14, [r11+0x04]
00007f9c53bd026a  mov [r15+0x88], r14
00007f9c53bd0271  mov r11d, [rsp+0x20]
00007f9c53bd0276  lea r10d, [r12d+r11d*1]
00007f9c53bd027b  lea r11d, [r9d+eax*1]
00007f9c53bd0280  mov r11d, r11d
00007f9c53bd0283  mov [r15+0xB8], r11
00007f9c53bd028a  xor eax, eax
00007f9c53bd028c  mov r12d, 0x100
00007f9c53bd0292  cmp r14, r12
00007f9c53bd0295  cmc
00007f9c53bd0296  lahf
00007f9c53bd0297  seto al
00007f9c53bd029a  mov [r15+0x108], eax
00007f9c53bd02a1  lea eax, [r10d+r9d*1]
00007f9c53bd02a6  mov eax, eax
00007f9c53bd02a8  mov [r15+0xA8], rax
00007f9c53bd02af  mov ebp, ebp
00007f9c53bd02b1  mov [r15+0xB0], rbp
00007f9c53bd02b8  mov eax, [rsp+0x50]
00007f9c53bd02bc  mov eax, eax
00007f9c53bd02be  mov [r15+0xC0], rax
00007f9c53bd02c5  mov edi, edi
00007f9c53bd02c7  mov [r15+0xC8], rdi
00007f9c53bd02ce  mov eax, [r15+0x108]
00007f9c53bd02d5  sahf
00007f9c53bd02d6  jnz 0x00007F9C53BD0308
00007f9c53bd02d8  cmp dword ptr [r15+0x318], 0x00
00007f9c53bd02e0  jz 0x00007F9C53BD0350
00007f9c53bd02e6  nop [rax+rax*1], ax
00007f9c53bd02ef  nop [rax+rax*1], eax
00007f9c53bd02f7  mov eax, 0x41055C
00007f9c53bd02fc  mov [r15+0x100], rax
00007f9c53bd0303  jmp 0x00007F9C539FE110
00007f9c53bd0308  cmp dword ptr [r15+0x318], 0x00
00007f9c53bd0310  jz 0x00007F9C53BD0120
00007f9c53bd0316  nop [rax+rax*1], ax
00007f9c53bd031f  nop [rax+rax*1], eax
00007f9c53bd0327  mov eax, 0x4104D0
00007f9c53bd032c  mov [r15+0x100], rax
00007f9c53bd0333  jmp 0x00007F9C539FE110
00007f9c53bd0338  int3
00007f9c53bd0339  call 0x00007F9C53A49010
00007f9c53bd033e  jmp 0x00007F9C53BD01CF
00007f9c53bd0343  call 0x00007F9C53A25930
00007f9c53bd0348  jmp 0x00007F9C53BD020C
00007f9c53bd034d  int3
00007f9c53bd034e  nop
00007f9c53bd0350  mov eax, [r15+0x98]
00007f9c53bd0357  mov r14d, [r15+0x70]
00007f9c53bd035b  lea r12d, [eax+r14d*1]
00007f9c53bd0360  mov eax, [r15+0x28]
00007f9c53bd0364  mov r14d, [r15+0x68]
00007f9c53bd0368  lea r11d, [eax+r14d*1]
00007f9c53bd036d  mov qword ptr [r15+0x88], 0x00
00007f9c53bd0378  mov eax, [r15+0xA8]
00007f9c53bd037f  mov r14d, [r15+0x78]
00007f9c53bd0383  lea r10d, [eax+r14d*1]
00007f9c53bd0388  mov [rsp+0x10], r10d
00007f9c53bd038d  mov r10d, r10d
00007f9c53bd0390  mov [r15+0x78], r10
00007f9c53bd0394  mov eax, [r15+0x38]
00007f9c53bd0398  mov r14d, [r15+0x80]
00007f9c53bd039f  lea r10d, [eax+r14d*1]
00007f9c53bd03a4  mov [rsp+0x20], r10d
00007f9c53bd03a9  mov r10d, r10d
00007f9c53bd03ac  mov [r15+0x80], r10
00007f9c53bd03b3  mov rax, [r15]
00007f9c53bd03b6  lea r14, [rax+0x08]
00007f9c53bd03ba  mov [r13+r14*1], r12d
00007f9c53bd03bf  lea r14, [rax+0x0C]
00007f9c53bd03c3  mov [r13+r14*1], r11d
00007f9c53bd03c8  mov r14d, [r15+0xB8]
00007f9c53bd03cf  mov r12d, [r15+0x18]
00007f9c53bd03d3  lea r11d, [r14d+r12d*1]
00007f9c53bd03d8  mov [rsp+0x30], r11d
00007f9c53bd03dd  mov r11d, r11d
00007f9c53bd03e0  mov [r15+0x68], r11
00007f9c53bd03e4  mov r14d, [r15+0x30]
00007f9c53bd03e8  mov r12d, [r15+0x90]
00007f9c53bd03ef  lea r11d, [r14d+r12d*1]
00007f9c53bd03f4  mov [rsp+0x40], r11d
00007f9c53bd03f9  mov r11d, r11d
00007f9c53bd03fc  mov [r15+0x70], r11
00007f9c53bd0400  mov r14d, [r15+0x20]
00007f9c53bd0404  mov r12d, [r15+0x58]
00007f9c53bd0408  lea r11d, [r14d+r12d*1]
00007f9c53bd040d  mov [rsp+0x50], r11d
00007f9c53bd0412  mov r11d, r11d
00007f9c53bd0415  mov [r15+0x58], r11
00007f9c53bd0419  mov r14d, [r15+0xA0]
00007f9c53bd0420  mov r12d, [r15+0x60]
00007f9c53bd0424  lea r11d, [r14d+r12d*1]
00007f9c53bd0429  mov [rsp+0x60], r11d
00007f9c53bd042e  mov r11d, r11d
00007f9c53bd0431  mov [r15+0x60], r11
00007f9c53bd0435  mov r14d, [rsp+0x10]
00007f9c53bd043a  mov [r13+rax*1], r14d
00007f9c53bd043f  lea r14, [rax+0x04]
00007f9c53bd0443  mov r12d, [rsp+0x20]
00007f9c53bd0448  mov [r13+r14*1], r12d
00007f9c53bd044d  lea r14, [rax+0x10]
00007f9c53bd0451  mov r12d, [rsp+0x30]
00007f9c53bd0456  mov [r13+r14*1], r12d
00007f9c53bd045b  lea r14, [rax+0x14]
00007f9c53bd045f  mov r12d, [rsp+0x40]
00007f9c53bd0464  mov [r13+r14*1], r12d
00007f9c53bd0469  lea r14, [rax+0x18]
00007f9c53bd046d  mov r12d, [rsp+0x50]
00007f9c53bd0472  mov [r13+r14*1], r12d
00007f9c53bd0477  lea r14, [rax+0x1C]
00007f9c53bd047b  mov r12d, [rsp+0x60]
00007f9c53bd0480  mov [r13+r14*1], r12d
00007f9c53bd0485  lea r14, [rax+0x68]
00007f9c53bd0489  xor eax, eax
00007f9c53bd048b  mov [r13+r14*1], rax
00007f9c53bd0490  cmp dword ptr [r15+0x318], 0x00
00007f9c53bd0498  jz 0x00007F9C53BCEF90
00007f9c53bd049e  nop [rax+rax*1], ax
00007f9c53bd04a7  nop [rax+rax*1], eax
00007f9c53bd04af  mov eax, 0x410378
00007f9c53bd04b4  mov [r15+0x100], rax
00007f9c53bd04bb  jmp 0x00007F9C539FE110
00007f9c53bd04c0  int3
00007f9c53bd04c1  call 0x00007F9C53AE2BA0
00007f9c53bd04c6  jmp 0x00007F9C53BD03BF
00007f9c53bd04cb  call 0x00007F9C53AE1920
00007f9c53bd04d0  jmp 0x00007F9C53BD03C8
00007f9c53bd04d5  call 0x00007F9C53A0DFE0
00007f9c53bd04da  jmp 0x00007F9C53BD043F
00007f9c53bd04df  call 0x00007F9C53AE2BA0
00007f9c53bd04e4  jmp 0x00007F9C53BD044D
00007f9c53bd04e9  call 0x00007F9C53AE2BA0
00007f9c53bd04ee  jmp 0x00007F9C53BD045B
00007f9c53bd04f3  call 0x00007F9C53AE2BA0
00007f9c53bd04f8  jmp 0x00007F9C53BD0469
00007f9c53bd04fd  call 0x00007F9C53AE2BA0
00007f9c53bd0502  jmp 0x00007F9C53BD0477
00007f9c53bd0507  call 0x00007F9C53AE2BA0
00007f9c53bd050c  jmp 0x00007F9C53BD0485
00007f9c53bd0511  call 0x00007F9C53AD5EB0
00007f9c53bd0516  jmp 0x00007F9C53BD0490
00007f9c53bd051b  int3
00007f9c53bd051c  nop [rax], eax
00007f9c53bd0520  mov rax, [r15+0xF8]
00007f9c53bd0527  lea r14, [rax+0x140]
00007f9c53bd052e  mov r12, [r13+r14*1]
00007f9c53bd0533  lea r14, [rax+0x148]
00007f9c53bd053a  mov r11, [r13+r14*1]
00007f9c53bd053f  mov [r15+0xA0], r12
00007f9c53bd0546  mov [r15+0x98], r11
00007f9c53bd054d  lea r14, [rax+0x130]
00007f9c53bd0554  mov r12, [r13+r14*1]
00007f9c53bd0559  lea r14, [rax+0x138]
00007f9c53bd0560  mov r11, [r13+r14*1]
00007f9c53bd0565  mov [r15+0xB0], r12
00007f9c53bd056c  mov [r15+0xA8], r11
00007f9c53bd0573  lea r14, [rax+0x120]
00007f9c53bd057a  mov r12, [r13+r14*1]
00007f9c53bd057f  lea r14, [rax+0x128]
00007f9c53bd0586  mov r11, [r13+r14*1]
00007f9c53bd058b  mov [r15+0xC0], r12
00007f9c53bd0592  mov [r15+0xB8], r11
00007f9c53bd0599  lea r14, [rax+0x110]
00007f9c53bd05a0  mov r12, [r13+r14*1]
00007f9c53bd05a5  lea r14, [rax+0x118]
00007f9c53bd05ac  mov r11, [r13+r14*1]
00007f9c53bd05b1  mov [r15+0xD0], r12
00007f9c53bd05b8  mov [r15+0xC8], r11
00007f9c53bd05bf  lea r14, [rax+0x100]
00007f9c53bd05c6  mov r12, [r13+r14*1]
00007f9c53bd05cb  lea r14, [rax+0x108]
00007f9c53bd05d2  mov r11, [r13+r14*1]
00007f9c53bd05d7  mov [r15+0xE8], r12
00007f9c53bd05de  mov [r15+0xD8], r11
00007f9c53bd05e5  lea r14, [rax+0x150]
00007f9c53bd05ec  mov [r15+0xF8], r14
00007f9c53bd05f3  mov rax, [r15+0xF0]
00007f9c53bd05fa  mov [r15+0x100], rax
00007f9c53bd0601  jmp 0x00007F9C53BCE5C0
00007f9c53bd0606  int3
00007f9c53bd0607  call 0x00007F9C53AE27E0
00007f9c53bd060c  jmp 0x00007F9C53BD0533
00007f9c53bd0611  call 0x00007F9C53AE1570
00007f9c53bd0616  jmp 0x00007F9C53BD053F
00007f9c53bd061b  call 0x00007F9C53AE27E0
00007f9c53bd0620  jmp 0x00007F9C53BD0559
00007f9c53bd0625  call 0x00007F9C53AE1570
00007f9c53bd062a  jmp 0x00007F9C53BD0565
00007f9c53bd062f  call 0x00007F9C53AE27E0
00007f9c53bd0634  jmp 0x00007F9C53BD057F
00007f9c53bd0639  call 0x00007F9C53AE1570
00007f9c53bd063e  jmp 0x00007F9C53BD058B
00007f9c53bd0643  call 0x00007F9C53AE27E0
00007f9c53bd0648  jmp 0x00007F9C53BD05A5
00007f9c53bd064d  call 0x00007F9C53AE1570
00007f9c53bd0652  jmp 0x00007F9C53BD05B1
00007f9c53bd0657  call 0x00007F9C53AE27E0
00007f9c53bd065c  jmp 0x00007F9C53BD05CB
00007f9c53bd0661  call 0x00007F9C53AE1570
00007f9c53bd0666  jmp 0x00007F9C53BD05D7
00007f9c53bd066b  int3
00007f9c53bd066c  nop [rax], eax
00007f9c53bd0670  mov eax, [r15+0xA0]
00007f9c53bd0677  mov [rsp+0x10], eax
00007f9c53bd067b  xor eax, eax
00007f9c53bd067d  mov r14d, [rsp+0x10]
00007f9c53bd0682  sub r14d, 0x01
00007f9c53bd0686  cmc
00007f9c53bd0687  lahf
00007f9c53bd0688  seto al
00007f9c53bd068b  mov [r15+0x108], eax
00007f9c53bd0692  mov r14d, r14d
00007f9c53bd0695  mov [r15+0xA0], r14
00007f9c53bd069c  mov eax, [r15+0x108]
00007f9c53bd06a3  sahf
00007f9c53bd06a4  jnz 0x00007F9C53BD06D6
00007f9c53bd06a6  cmp dword ptr [r15+0x318], 0x00
00007f9c53bd06ae  jz 0x00007F9C53BD07A0
00007f9c53bd06b4  nop [rax+rax*1], ax
00007f9c53bd06bd  nop [rax+rax*1], eax
00007f9c53bd06c5  mov eax, 0x41027C
00007f9c53bd06ca  mov [r15+0x100], rax
00007f9c53bd06d1  jmp 0x00007F9C539FE110
00007f9c53bd06d6  cmp dword ptr [r15+0x318], 0x00
00007f9c53bd06de  jz 0x00007F9C53BD0710
00007f9c53bd06e4  nop [rax+rax*1], ax
00007f9c53bd06ed  nop [rax+rax*1], eax
00007f9c53bd06f5  mov eax, 0x410264
00007f9c53bd06fa  mov [r15+0x100], rax
00007f9c53bd0701  jmp 0x00007F9C539FE110
00007f9c53bd0706  int3
00007f9c53bd0707  int3
00007f9c53bd0708  nop [rax+rax*1], eax
00007f9c53bd0710  mov rax, [r15+0xF8]
00007f9c53bd0717  mov [r15], rax
00007f9c53bd071a  mov rax, [r15+0x98]
00007f9c53bd0721  mov [r15+0x08], rax
00007f9c53bd0725  mov qword ptr [r15+0x10], 0x12C
00007f9c53bd072d  mov qword ptr [r15+0xF0], 0x410274
00007f9c53bd0738  mov r14d, [r15+0x320]
00007f9c53bd073f  mov eax, 0x410274
00007f9c53bd0744  mov rcx, 0x7F9C53BD0670
00007f9c53bd074e  mov [r15+r14*8+0x328], rax
00007f9c53bd0756  mov [r15+r14*8+0x368], rcx
00007f9c53bd075e  add r14d, 0x01
00007f9c53bd0762  and r14d, 0x07
00007f9c53bd0766  mov [r15+0x320], r14d
00007f9c53bd076d  cmp dword ptr [r15+0x318], 0x00
00007f9c53bd0775  jz 0x00007F9C53BCEC20
00007f9c53bd077b  nop [rax+rax*1], ax
00007f9c53bd0784  nop [rax+rax*1], eax
00007f9c53bd078c  mov eax, 0x410338
00007f9c53bd0791  mov [r15+0x100], rax
00007f9c53bd0798  jmp 0x00007F9C539FE110
00007f9c53bd079d  int3
00007f9c53bd079e  int3
00007f9c53bd079f  nop
00007f9c53bd07a0  mov rax, [r15+0xF8]
00007f9c53bd07a7  lea r14, [rax+0x20]
00007f9c53bd07ab  mov r12, [r13+r14*1]
00007f9c53bd07b0  mov [r15+0x98], r12
00007f9c53bd07b7  mov qword ptr [r15+0x40], 0x80
00007f9c53bd07bf  mov [r15], rax
00007f9c53bd07c2  lea r14, [rax+0x8C]
00007f9c53bd07c9  mov [r15+0x08], r14
00007f9c53bd07cd  mov qword ptr [r15+0x10], 0x01
00007f9c53bd07d5  lea r14, [rax+0x8C]
00007f9c53bd07dc  mov eax, 0x80
00007f9c53bd07e1  mov [r13+r14*1], al
00007f9c53bd07e6  mov qword ptr [r15+0xF0], 0x410298
00007f9c53bd07f1  mov r14d, [r15+0x320]
00007f9c53bd07f8  mov eax, 0x410298
00007f9c53bd07fd  mov rcx, 0x7F9C53BD0870
00007f9c53bd0807  mov [r15+r14*8+0x328], rax
00007f9c53bd080f  mov [r15+r14*8+0x368], rcx
00007f9c53bd0817  add r14d, 0x01
00007f9c53bd081b  and r14d, 0x07
00007f9c53bd081f  mov [r15+0x320], r14d
00007f9c53bd0826  cmp dword ptr [r15+0x318], 0x00
00007f9c53bd082e  jz 0x00007F9C53BCEC20
00007f9c53bd0834  nop [rax+rax*1], ax
00007f9c53bd083d  nop [rax+rax*1], eax
00007f9c53bd0845  mov eax, 0x410338
00007f9c53bd084a  mov [r15+0x100], rax
00007f9c53bd0851  jmp 0x00007F9C539FE110
00007f9c53bd0856  int3
00007f9c53bd0857  call 0x00007F9C53AE27E0
00007f9c53bd085c  jmp 0x00007F9C53BD07B0
00007f9c53bd0861  call 0x00007F9C53AD5AF0
00007f9c53bd0866  jmp 0x00007F9C53BD07E6
00007f9c53bd086b  int3
00007f9c53bd086c  nop [rax], eax
00007f9c53bd0870  mov rax, [r15+0xF8]
00007f9c53bd0877  lea r14, [rax+0x68]
00007f9c53bd087b  mov r12, [r13+r14*1]
00007f9c53bd0880  mov [r15+0x40], r12
00007f9c53bd0884  lea r14, [rax+0x88]
00007f9c53bd088b  xor eax, eax
00007f9c53bd088d  mov [r13+r14*1], al
00007f9c53bd0892  xor eax, eax
00007f9c53bd0894  mov r14d, 0x38
00007f9c53bd089a  cmp r12, r14
00007f9c53bd089d  cmc
00007f9c53bd089e  lahf
00007f9c53bd089f  seto al
00007f9c53bd08a2  mov [r15+0x108], eax
00007f9c53bd08a9  mov eax, [r15+0x108]
00007f9c53bd08b0  sahf
00007f9c53bd08b1  jz 0x00007F9C53BD08E3
00007f9c53bd08b3  cmp dword ptr [r15+0x318], 0x00
00007f9c53bd08bb  jz 0x00007F9C53BD0930
00007f9c53bd08c1  nop [rax+rax*1], ax
00007f9c53bd08ca  nop [rax+rax*1], eax
00007f9c53bd08d2  mov eax, 0x4102A8
00007f9c53bd08d7  mov [r15+0x100], rax
00007f9c53bd08de  jmp 0x00007F9C539FE110
00007f9c53bd08e3  cmp dword ptr [r15+0x318], 0x00
00007f9c53bd08eb  jz 0x00007F9C53BD0A70
00007f9c53bd08f1  nop [rax+rax*1], ax
00007f9c53bd08fa  nop [rax+rax*1], eax
00007f9c53bd0902  mov eax, 0x4102C4
00007f9c53bd0907  mov [r15+0x100], rax
00007f9c53bd090e  jmp 0x00007F9C539FE110
00007f9c53bd0913  int3
00007f9c53bd0914  call 0x00007F9C53AE27E0
00007f9c53bd0919  jmp 0x00007F9C53BD0880
00007f9c53bd091e  call 0x00007F9C53AD5AF0
00007f9c53bd0923  jmp 0x00007F9C53BD0892
00007f9c53bd0928  int3
00007f9c53bd0929  nop [rax], eax
00007f9c53bd0930  mov rax, [r15+0xF8]
00007f9c53bd0937  mov [r15], rax
00007f9c53bd093a  lea r14, [rax+0x88]
00007f9c53bd0941  mov [r15+0x08], r14
00007f9c53bd0945  mov qword ptr [r15+0x10], 0x01
00007f9c53bd094d  mov qword ptr [r15+0xF0], 0x4102B8
00007f9c53bd0958  mov r14d, [r15+0x320]
00007f9c53bd095f  mov eax, 0x4102B8
00007f9c53bd0964  mov rcx, 0x7F9C53BD09C0
00007f9c53bd096e  mov [r15+r14*8+0x328], rax
00007f9c53bd0976  mov [r15+r14*8+0x368], rcx
00007f9c53bd097e  add r14d, 0x01
00007f9c53bd0982  and r14d, 0x07
00007f9c53bd0986  mov [r15+0x320], r14d
00007f9c53bd098d  cmp dword ptr [r15+0x318], 0x00
00007f9c53bd0995  jz 0x00007F9C53BCEC20
00007f9c53bd099b  nop [rax+rax*1], ax
00007f9c53bd09a4  nop [rax+rax*1], eax
00007f9c53bd09ac  mov eax, 0x410338
00007f9c53bd09b1  mov [r15+0x100], rax
00007f9c53bd09b8  jmp 0x00007F9C539FE110
00007f9c53bd09bd  int3
00007f9c53bd09be  int3
00007f9c53bd09bf  nop
00007f9c53bd09c0  mov rax, [r15+0xF8]
00007f9c53bd09c7  lea r14, [rax+0x68]
00007f9c53bd09cb  mov rax, [r13+r14*1]
00007f9c53bd09d0  mov [r15+0x40], rax
00007f9c53bd09d4  mov [rsp+0x10], rax
00007f9c53bd09d9  xor eax, eax
00007f9c53bd09db  mov r14, [rsp+0x10]
00007f9c53bd09e0  mov r12d, 0x38
00007f9c53bd09e6  cmp r14, r12
00007f9c53bd09e9  cmc
00007f9c53bd09ea  lahf
00007f9c53bd09eb  seto al
00007f9c53bd09ee  mov [r15+0x108], eax
00007f9c53bd09f5  mov eax, [r15+0x108]
00007f9c53bd09fc  sahf
00007f9c53bd09fd  jnz 0x00007F9C53BD0A2F
00007f9c53bd09ff  cmp dword ptr [r15+0x318], 0x00
00007f9c53bd0a07  jz 0x00007F9C53BD0A70
00007f9c53bd0a0d  nop [rax+rax*1], ax
00007f9c53bd0a16  nop [rax+rax*1], eax
00007f9c53bd0a1e  mov eax, 0x4102C4
00007f9c53bd0a23  mov [r15+0x100], rax
00007f9c53bd0a2a  jmp 0x00007F9C539FE110
00007f9c53bd0a2f  cmp dword ptr [r15+0x318], 0x00
00007f9c53bd0a37  jz 0x00007F9C53BD0930
00007f9c53bd0a3d  nop [rax+rax*1], ax
00007f9c53bd0a46  nop [rax+rax*1], eax
00007f9c53bd0a4e  mov eax, 0x4102A8
00007f9c53bd0a53  mov [r15+0x100], rax
00007f9c53bd0a5a  jmp 0x00007F9C539FE110
00007f9c53bd0a5f  int3
00007f9c53bd0a60  call 0x00007F9C53AD59C0
00007f9c53bd0a65  jmp 0x00007F9C53BD09D0
00007f9c53bd0a6a  int3
00007f9c53bd0a6b  nop [rax+rax*1], eax
00007f9c53bd0a70  mov rax, [r15+0x98]
00007f9c53bd0a77  rorx r14, rax, 0x3D
00007f9c53bd0a7d  and r14, 0xFFFFFFFFFFFFFFF8
00007f9c53bd0a81  mov rax, [r15+0xF8]
00007f9c53bd0a88  mov [r15], rax
00007f9c53bd0a8b  lea r12, [rax+0x78]
00007f9c53bd0a8f  mov [r15+0x08], r12
00007f9c53bd0a93  mov qword ptr [r15+0x10], 0x08
00007f9c53bd0a9b  bswap r14
00007f9c53bd0a9e  mov [r15+0x40], r14
00007f9c53bd0aa2  lea r12, [rax+0x78]
00007f9c53bd0aa6  mov [r13+r12*1], r14
00007f9c53bd0aab  mov qword ptr [r15+0xF0], 0x4102E0
00007f9c53bd0ab6  mov r14d, [r15+0x320]
00007f9c53bd0abd  mov eax, 0x4102E0
00007f9c53bd0ac2  mov rcx, 0x7F9C53BD0B30
00007f9c53bd0acc  mov [r15+r14*8+0x328], rax
00007f9c53bd0ad4  mov [r15+r14*8+0x368], rcx
00007f9c53bd0adc  add r14d, 0x01
00007f9c53bd0ae0  and r14d, 0x07
00007f9c53bd0ae4  mov [r15+0x320], r14d
00007f9c53bd0aeb  cmp dword ptr [r15+0x318], 0x00
00007f9c53bd0af3  jz 0x00007F9C53BCEC20
00007f9c53bd0af9  nop [rax+rax*1], ax
00007f9c53bd0b02  nop [rax+rax*1], eax
00007f9c53bd0b0a  mov eax, 0x410338
00007f9c53bd0b0f  mov [r15+0x100], rax
00007f9c53bd0b16  jmp 0x00007F9C539FE110
00007f9c53bd0b1b  int3
00007f9c53bd0b1c  call 0x00007F9C53AC3FE0
00007f9c53bd0b21  jmp 0x00007F9C53BD0AAB
00007f9c53bd0b26  int3
00007f9c53bd0b27  nop [rax+rax*1], ax
00007f9c53bd0b30  mov rax, [r15+0xF8]
00007f9c53bd0b37  mov r14d, [r13+rax*1]
00007f9c53bd0b3c  lea r12, [rax+0x04]
00007f9c53bd0b40  mov r11d, [r13+r12*1]
00007f9c53bd0b45  lea r12, [rax+0x08]
00007f9c53bd0b49  mov r10d, [r13+r12*1]
00007f9c53bd0b4e  lea r12, [rax+0x0C]
00007f9c53bd0b52  mov r9d, [r13+r12*1]
00007f9c53bd0b57  mov qword ptr [r15+0x48], 0x430860
00007f9c53bd0b5f  lea r12, [rax+0x80]
00007f9c53bd0b66  mov r8, [r13+r12*1]
00007f9c53bd0b6b  mov [r15+0xF0], r8
00007f9c53bd0b72  bswap r14d
00007f9c53bd0b75  bswap r11d
00007f9c53bd0b78  mov r12d, 0x430860
00007f9c53bd0b7e  mov [r13+r12*1], r14d
00007f9c53bd0b83  mov r14d, 0x430864
00007f9c53bd0b89  mov [r13+r14*1], r11d
00007f9c53bd0b8e  bswap r10d
00007f9c53bd0b91  bswap r9d
00007f9c53bd0b94  lea r14, [rax+0x10]
00007f9c53bd0b98  mov r12d, [r13+r14*1]
00007f9c53bd0b9d  lea r14, [rax+0x14]
00007f9c53bd0ba1  mov r11d, [r13+r14*1]
00007f9c53bd0ba6  mov r14d, 0x430868
00007f9c53bd0bac  mov [r13+r14*1], r10d
00007f9c53bd0bb1  mov r14d, 0x43086C
00007f9c53bd0bb7  mov [r13+r14*1], r9d
00007f9c53bd0bbc  lea r14, [rax+0x90]
00007f9c53bd0bc3  mov r10, [r13+r14*1]
00007f9c53bd0bc8  lea r14, [rax+0x98]
00007f9c53bd0bcf  mov r9, [r13+r14*1]
00007f9c53bd0bd4  mov [r15+0xA0], r10
00007f9c53bd0bdb  mov [r15+0x98], r9
00007f9c53bd0be2  bswap r12d
00007f9c53bd0be5  bswap r11d
00007f9c53bd0be8  mov [rsp+0x10], r11d
00007f9c53bd0bed  mov r11d, r11d
00007f9c53bd0bf0  mov [r15+0x58], r11
00007f9c53bd0bf4  lea r14, [rax+0x18]
00007f9c53bd0bf8  mov r11d, [r13+r14*1]
00007f9c53bd0bfd  lea r14, [rax+0x1C]
00007f9c53bd0c01  mov r10d, [r13+r14*1]
00007f9c53bd0c06  mov [rsp+0x20], r10d
00007f9c53bd0c0b  mov r10d, r10d
00007f9c53bd0c0e  mov [r15+0x60], r10
00007f9c53bd0c12  mov r14d, 0x430870
00007f9c53bd0c18  mov [r13+r14*1], r12d
00007f9c53bd0c1d  mov r14d, 0x430874
00007f9c53bd0c23  mov r12d, [rsp+0x10]
00007f9c53bd0c28  mov [r13+r14*1], r12d
00007f9c53bd0c2d  bswap r11d
00007f9c53bd0c30  mov [rsp+0x10], r11d
00007f9c53bd0c35  mov r11d, r11d
00007f9c53bd0c38  mov [r15+0x40], r11
00007f9c53bd0c3c  mov r14d, [rsp+0x20]
00007f9c53bd0c41  bswap r14d
00007f9c53bd0c44  mov [rsp+0x20], r14d
00007f9c53bd0c49  mov r14d, r14d
00007f9c53bd0c4c  mov [r15+0x50], r14
00007f9c53bd0c50  mov r14d, 0x430878
00007f9c53bd0c56  mov r12d, [rsp+0x10]
00007f9c53bd0c5b  mov [r13+r14*1], r12d
00007f9c53bd0c60  mov r14d, 0x43087C
00007f9c53bd0c66  mov r12d, [rsp+0x20]
00007f9c53bd0c6b  mov [r13+r14*1], r12d
00007f9c53bd0c70  lea r14, [rax+0xA0]
00007f9c53bd0c77  mov [r15+0xF8], r14
00007f9c53bd0c7e  mov [r15+0x100], r8
00007f9c53bd0c85  jmp 0x00007F9C53BCE5C0
00007f9c53bd0c8a  int3
00007f9c53bd0c8b  call 0x00007F9C53A0DAE0
00007f9c53bd0c90  jmp 0x00007F9C53BD0B3C
00007f9c53bd0c95  call 0x00007F9C53AC0230
00007f9c53bd0c9a  jmp 0x00007F9C53BD0B45
00007f9c53bd0c9f  call 0x00007F9C53ABEFC0
00007f9c53bd0ca4  jmp 0x00007F9C53BD0B4E
00007f9c53bd0ca9  call 0x00007F9C53ABDD50
00007f9c53bd0cae  jmp 0x00007F9C53BD0B57
00007f9c53bd0cb3  call 0x00007F9C53ABCC20
00007f9c53bd0cb8  jmp 0x00007F9C53BD0B6B
00007f9c53bd0cbd  call 0x00007F9C53AC3EA0
00007f9c53bd0cc2  jmp 0x00007F9C53BD0B83
00007f9c53bd0cc7  call 0x00007F9C53AE1920
00007f9c53bd0ccc  jmp 0x00007F9C53BD0B8E
00007f9c53bd0cd1  call 0x00007F9C53AE26A0
00007f9c53bd0cd6  jmp 0x00007F9C53BD0B9D
00007f9c53bd0cdb  call 0x00007F9C53AE1430
00007f9c53bd0ce0  jmp 0x00007F9C53BD0BA6
00007f9c53bd0ce5  call 0x00007F9C53AE06B0
00007f9c53bd0cea  jmp 0x00007F9C53BD0BB1
00007f9c53bd0cef  call 0x00007F9C53ADF440
00007f9c53bd0cf4  jmp 0x00007F9C53BD0BBC
00007f9c53bd0cf9  call 0x00007F9C53AE0300
00007f9c53bd0cfe  jmp 0x00007F9C53BD0BC8
00007f9c53bd0d03  call 0x00007F9C53ADF090
00007f9c53bd0d08  jmp 0x00007F9C53BD0BD4
00007f9c53bd0d0d  call 0x00007F9C53AE1430
00007f9c53bd0d12  jmp 0x00007F9C53BD0BFD
00007f9c53bd0d17  call 0x00007F9C53AE01C0
00007f9c53bd0d1c  jmp 0x00007F9C53BD0C06
00007f9c53bd0d21  call 0x00007F9C53AE2BA0
00007f9c53bd0d26  jmp 0x00007F9C53BD0C1D
00007f9c53bd0d2b  call 0x00007F9C53AE2BA0
00007f9c53bd0d30  jmp 0x00007F9C53BD0C2D
00007f9c53bd0d35  call 0x00007F9C53AE2BA0
00007f9c53bd0d3a  jmp 0x00007F9C53BD0C60
00007f9c53bd0d3f  call 0x00007F9C53AE2BA0
00007f9c53bd0d44  jmp 0x00007F9C53BD0C70
00007f9c53bd0d49  int3
00007f9c53bd0d4a  nop [rax+rax*1], ax
00007f9c53bd0d50  mov qword ptr [r15+0x100], 0x04
00007f9c53bd0d5b  mov esi, 0x00
00007f9c53bd0d60  mov edx, 0x09
00007f9c53bd0d65  mov rdi, 0x7FFC8FA02700
00007f9c53bd0d6f  mov rax, 0x5B93D7660970
00007f9c53bd0d79  call rax
00007f9c53bd0d7b  cmp dword ptr [r15+0x318], 0x00
00007f9c53bd0d83  jnz 0x00007F9C539FE110
00007f9c53bd0d89  jmp 0x00007F9C539FE0A0
00007f9c53bd0d8e  int3
00007f9c53bd0d8f  int3
