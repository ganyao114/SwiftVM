000070df2cbce69b  nop [rax+rax*1], eax
000070df2cbce6a0  mov qword ptr [r15+0x40], 0x4201C0
000070df2cbce6a8  mov qword ptr [r15+0x48], 0x4203C0
000070df2cbce6b0  mov qword ptr [r15+0x60], 0x01
000070df2cbce6b8  xorps xmm1, xmm1
000070df2cbce6bb  mov eax, 0x41
000070df2cbce6c0  vcvtusi2sd xmm1, xmm1, eax
000070df2cbce6c6  mulsd xmm1, [0x000070DF2C7FE010]
000070df2cbce6ce  movq xmm1, xmm1
000070df2cbce6d2  movaps [r15+0x120], xmm1
000070df2cbce6da  mov eax, [r15+0x60]
000070df2cbce6de  xorps xmm15, xmm15
000070df2cbce6e2  vcvtusi2sd xmm15, xmm15, eax
000070df2cbce6e8  mulsd xmm15, [0x000070DF2C7FE020]
000070df2cbce6f1  movq xmm15, xmm15
000070df2cbce6f6  movaps [r15+0x110], xmm15
000070df2cbce6fe  mov rax, [r15+0x60]
000070df2cbce702  mov [rsp+0x10], rax
000070df2cbce707  xor eax, eax
000070df2cbce709  mov r14, [rsp+0x10]
000070df2cbce70e  mov r12d, 0x40
000070df2cbce714  cmp r14, r12
000070df2cbce717  cmc
000070df2cbce718  lahf
000070df2cbce719  seto al
000070df2cbce71c  mov [r15+0x108], eax
000070df2cbce723  mov qword ptr [r15+0x50], 0x40
000070df2cbce72b  movq rax, xmm1
000070df2cbce730  mov r12d, 0x4203C0
000070df2cbce736  mov [r13+r12*1], rax
000070df2cbce73b  movq rax, xmm15
000070df2cbce740  mov r12d, 0x4201C0
000070df2cbce746  mov [r13+r12*1], rax
000070df2cbce74b  mov [r15+0x58], r14
000070df2cbce74f  mov eax, [r15+0x108]
000070df2cbce756  sahf
000070df2cbce757  jnz 0x000070DF2CBCE789
000070df2cbce759  cmp dword ptr [r15+0x318], 0x00
000070df2cbce761  jz 0x000070DF2CBCE910
000070df2cbce767  nop [rax+rax*1], ax
000070df2cbce770  nop [rax+rax*1], eax
000070df2cbce778  mov eax, 0x410074
000070df2cbce77d  mov [r15+0x100], rax
000070df2cbce784  jmp 0x000070DF2C9FE110
000070df2cbce789  cmp dword ptr [r15+0x318], 0x00
000070df2cbce791  jz 0x000070DF2CBCE7D0
000070df2cbce797  nop [rax+rax*1], ax
000070df2cbce7a0  nop [rax+rax*1], eax
000070df2cbce7a8  mov eax, 0x41004C
000070df2cbce7ad  mov [r15+0x100], rax
000070df2cbce7b4  jmp 0x000070DF2C9FE110
000070df2cbce7b9  int3
000070df2cbce7ba  call 0x000070DF2CAB4CB0
000070df2cbce7bf  jmp 0x000070DF2CBCE73B
000070df2cbce7c4  call 0x000070DF2CAB4CB0
000070df2cbce7c9  jmp 0x000070DF2CBCE74B
000070df2cbce7ce  int3
000070df2cbce7cf  nop
000070df2cbce7d0  mov rax, [r15+0x58]
000070df2cbce7d4  lea r14, [rax+0x01]
000070df2cbce7d8  mov [r15+0x60], r14
000070df2cbce7dc  mov r14d, [r15+0x50]
000070df2cbce7e0  xorps xmm1, xmm1
000070df2cbce7e3  vcvtusi2sd xmm1, xmm1, r14d
000070df2cbce7e9  mulsd xmm1, [0x000070DF2C7FE010]
000070df2cbce7f1  movq xmm1, xmm1
000070df2cbce7f5  movaps [r15+0x120], xmm1
000070df2cbce7fd  rorx r12, rax, 0x3D
000070df2cbce803  and r12, 0xFFFFFFFFFFFFFFF8
000070df2cbce807  mov eax, [r15+0x60]
000070df2cbce80b  xorps xmm15, xmm15
000070df2cbce80f  vcvtusi2sd xmm15, xmm15, eax
000070df2cbce815  mulsd xmm15, [0x000070DF2C7FE020]
000070df2cbce81e  movq xmm15, xmm15
000070df2cbce823  movaps [r15+0x110], xmm15
000070df2cbce82b  mov rax, [r15+0x60]
000070df2cbce82f  mov [rsp+0x10], rax
000070df2cbce834  xor eax, eax
000070df2cbce836  mov r11, [rsp+0x10]
000070df2cbce83b  mov r10d, 0x40
000070df2cbce841  cmp r11, r10
000070df2cbce844  cmc
000070df2cbce845  lahf
000070df2cbce846  seto al
000070df2cbce849  mov [r15+0x108], eax
000070df2cbce850  lea eax, [r14d-0x01]
000070df2cbce855  mov eax, eax
000070df2cbce857  mov [r15+0x50], rax
000070df2cbce85b  mov rax, [r15+0x48]
000070df2cbce85f  lea r14, [rax+r12*1]
000070df2cbce863  movq rax, xmm1
000070df2cbce868  mov [r13+r14*1], rax
000070df2cbce86d  mov rax, [r15+0x40]
000070df2cbce871  lea r14, [rax+r12*1]
000070df2cbce875  movq rax, xmm15
000070df2cbce87a  mov [r13+r14*1], rax
000070df2cbce87f  mov [r15+0x58], r11
000070df2cbce883  mov eax, [r15+0x108]
000070df2cbce88a  sahf
000070df2cbce88b  jnz 0x000070DF2CBCE8BD
000070df2cbce88d  cmp dword ptr [r15+0x318], 0x00
000070df2cbce895  jz 0x000070DF2CBCE910
000070df2cbce89b  nop [rax+rax*1], ax
000070df2cbce8a4  nop [rax+rax*1], eax
000070df2cbce8ac  mov eax, 0x410074
000070df2cbce8b1  mov [r15+0x100], rax
000070df2cbce8b8  jmp 0x000070DF2C9FE110
000070df2cbce8bd  cmp dword ptr [r15+0x318], 0x00
000070df2cbce8c5  jz 0x000070DF2CBCE7D0
000070df2cbce8cb  nop [rax+rax*1], ax
000070df2cbce8d4  nop [rax+rax*1], eax
000070df2cbce8dc  mov eax, 0x41004C
000070df2cbce8e1  mov [r15+0x100], rax
000070df2cbce8e8  jmp 0x000070DF2C9FE110
000070df2cbce8ed  int3
000070df2cbce8ee  call 0x000070DF2CAD5EB0
000070df2cbce8f3  jmp 0x000070DF2CBCE86D
000070df2cbce8f8  call 0x000070DF2CAD5EB0
000070df2cbce8fd  jmp 0x000070DF2CBCE87F
000070df2cbce902  int3
000070df2cbce903  nop [rax+rax*1], ax
000070df2cbce90c  nop [rax], eax
000070df2cbce910  vxorps xmm1, xmm1, xmm1
000070df2cbce914  movq xmm1, xmm1
000070df2cbce918  movaps [r15+0x110], xmm1
000070df2cbce920  mov qword ptr [r15+0x58], 0x00
000070df2cbce928  mov qword ptr [r15+0x50], 0x4205C0
000070df2cbce930  mov qword ptr [r15+0x60], 0x00
000070df2cbce938  mov qword ptr [r15+0x68], 0x4205C0
000070df2cbce940  mov rax, [r15+0x40]
000070df2cbce944  mov r14, [r13+rax*1]
000070df2cbce949  lea r12, [rax+0x08]
000070df2cbce94d  mov r11, [r13+r12*1]
000070df2cbce952  movq xmm15, r14
000070df2cbce957  movq xmm14, r11
000070df2cbce95c  movq xmm15, xmm15
000070df2cbce961  movq xmm15, xmm15
000070df2cbce966  movaps [r15+0x120], xmm15
000070df2cbce96e  movq xmm14, xmm14
000070df2cbce973  movq xmm14, xmm14
000070df2cbce978  movaps [r15+0x130], xmm14
000070df2cbce980  lea r14, [rax+0x10]
000070df2cbce984  mov r12, [r13+r14*1]
000070df2cbce989  lea r14, [rax+0x18]
000070df2cbce98d  mov r11, [r13+r14*1]
000070df2cbce992  movq xmm15, r12
000070df2cbce997  movq xmm14, r11
000070df2cbce99c  movq xmm15, xmm15
000070df2cbce9a1  movq xmm15, xmm15
000070df2cbce9a6  movaps [r15+0x140], xmm15
000070df2cbce9ae  movq xmm14, xmm14
000070df2cbce9b3  movq xmm14, xmm14
000070df2cbce9b8  movaps [r15+0x150], xmm14
000070df2cbce9c0  lea r14, [rax+0x20]
000070df2cbce9c4  mov r12, [r13+r14*1]
000070df2cbce9c9  lea r14, [rax+0x28]
000070df2cbce9cd  mov r11, [r13+r14*1]
000070df2cbce9d2  movq xmm15, r12
000070df2cbce9d7  movq xmm14, r11
000070df2cbce9dc  movq xmm15, xmm15
000070df2cbce9e1  movq xmm15, xmm15
000070df2cbce9e6  movaps [r15+0x160], xmm15
000070df2cbce9ee  movq xmm14, xmm14
000070df2cbce9f3  movq xmm14, xmm14
000070df2cbce9f8  movaps [r15+0x170], xmm14
000070df2cbcea00  lea r14, [rax+0x30]
000070df2cbcea04  mov r12, [r13+r14*1]
000070df2cbcea09  lea r14, [rax+0x38]
000070df2cbcea0d  mov rax, [r13+r14*1]
000070df2cbcea12  movq xmm15, r12
000070df2cbcea17  movq xmm14, rax
000070df2cbcea1c  movq xmm15, xmm15
000070df2cbcea21  movq xmm15, xmm15
000070df2cbcea26  movaps [r15+0x180], xmm15
000070df2cbcea2e  movq xmm14, xmm14
000070df2cbcea33  movq xmm14, xmm14
000070df2cbcea38  movaps [r15+0x210], xmm14
000070df2cbcea40  mov rax, [r15+0x48]
000070df2cbcea44  mov [r15+0x78], rax
000070df2cbcea48  mov r14, [r13+rax*1]
000070df2cbcea4d  movq xmm15, r14
000070df2cbcea52  lea r14, [rax+0x40]
000070df2cbcea56  mov r12, [r13+r14*1]
000070df2cbcea5b  movq xmm14, r12
000070df2cbcea60  lea r14, [rax+0x80]
000070df2cbcea67  mov r12, [r13+r14*1]
000070df2cbcea6c  movq xmm13, r12
000070df2cbcea71  movaps xmm12, [r15+0x120]
000070df2cbcea79  movq r14, xmm12
000070df2cbcea7e  movq r12, xmm15
000070df2cbcea83  vmovq xmm15, r14
000070df2cbcea88  vmovq xmm12, r12
000070df2cbcea8d  movaps xmm11, xmm15
000070df2cbcea91  mulsd xmm11, xmm12
000070df2cbcea96  ucomisd xmm11, xmm11
000070df2cbcea9b  jp 0x000070DF2CBCEEFC
000070df2cbceaa1  movq xmm11, xmm11
000070df2cbceaa6  movaps xmm15, [r15+0x130]
000070df2cbceaae  movq r14, xmm15
000070df2cbceab3  movq r12, xmm14
000070df2cbceab8  vmovq xmm15, r14
000070df2cbceabd  vmovq xmm14, r12
000070df2cbceac2  movaps xmm12, xmm15
000070df2cbceac6  mulsd xmm12, xmm14
000070df2cbceacb  ucomisd xmm12, xmm12
000070df2cbcead0  jp 0x000070DF2CBCEF48
000070df2cbcead6  movq xmm12, xmm12
000070df2cbceadb  movq r14, xmm11
000070df2cbceae0  movq r12, xmm1
000070df2cbceae5  vmovq xmm1, r14
000070df2cbceaea  vmovq xmm15, r12
000070df2cbceaef  movaps xmm14, xmm1
000070df2cbceaf3  addsd xmm14, xmm15
000070df2cbceaf8  ucomisd xmm14, xmm14
000070df2cbceafd  jp 0x000070DF2CBCEF94
000070df2cbceb03  movq xmm14, xmm14
000070df2cbceb08  movq r14, xmm14
000070df2cbceb0d  movq r12, xmm12
000070df2cbceb12  vmovq xmm1, r14
000070df2cbceb17  vmovq xmm15, r12
000070df2cbceb1c  movaps xmm14, xmm1
000070df2cbceb20  addsd xmm14, xmm15
000070df2cbceb25  ucomisd xmm14, xmm14
000070df2cbceb2a  jp 0x000070DF2CBCEFE0
000070df2cbceb30  movq xmm14, xmm14
000070df2cbceb35  movaps xmm1, [r15+0x140]
000070df2cbceb3d  movq r14, xmm1
000070df2cbceb42  movq r12, xmm13
000070df2cbceb47  vmovq xmm1, r14
000070df2cbceb4c  vmovq xmm15, r12
000070df2cbceb51  movaps xmm13, xmm1
000070df2cbceb55  mulsd xmm13, xmm15
000070df2cbceb5a  ucomisd xmm13, xmm13
000070df2cbceb5f  jp 0x000070DF2CBCF02C
000070df2cbceb65  movq xmm13, xmm13
000070df2cbceb6a  lea r14, [rax+0xC0]
000070df2cbceb71  mov r12, [r13+r14*1]
000070df2cbceb76  movq xmm1, r12
000070df2cbceb7b  movq r14, xmm14
000070df2cbceb80  movq r12, xmm13
000070df2cbceb85  vmovq xmm15, r14
000070df2cbceb8a  vmovq xmm14, r12
000070df2cbceb8f  movaps xmm13, xmm15
000070df2cbceb93  addsd xmm13, xmm14
000070df2cbceb98  ucomisd xmm13, xmm13
000070df2cbceb9d  jp 0x000070DF2CBCF082
000070df2cbceba3  movq xmm13, xmm13
000070df2cbceba8  movaps xmm15, [r15+0x150]
000070df2cbcebb0  movq r14, xmm15
000070df2cbcebb5  movq r12, xmm1
000070df2cbcebba  vmovq xmm1, r14
000070df2cbcebbf  vmovq xmm15, r12
000070df2cbcebc4  movaps xmm14, xmm1
000070df2cbcebc8  mulsd xmm14, xmm15
000070df2cbcebcd  ucomisd xmm14, xmm14
000070df2cbcebd2  jp 0x000070DF2CBCF0CE
000070df2cbcebd8  movq xmm14, xmm14
000070df2cbcebdd  lea r14, [rax+0x100]
000070df2cbcebe4  mov r12, [r13+r14*1]
000070df2cbcebe9  movq xmm1, r12
000070df2cbcebee  movq r14, xmm13
000070df2cbcebf3  movq r12, xmm14
000070df2cbcebf8  vmovq xmm15, r14
000070df2cbcebfd  vmovq xmm14, r12
000070df2cbcec02  movaps xmm13, xmm15
000070df2cbcec06  addsd xmm13, xmm14
000070df2cbcec0b  ucomisd xmm13, xmm13
000070df2cbcec10  jp 0x000070DF2CBCF124
000070df2cbcec16  movq xmm13, xmm13
000070df2cbcec1b  movaps xmm15, [r15+0x160]
000070df2cbcec23  movq r14, xmm15
000070df2cbcec28  movq r12, xmm1
000070df2cbcec2d  vmovq xmm1, r14
000070df2cbcec32  vmovq xmm15, r12
000070df2cbcec37  movaps xmm14, xmm1
000070df2cbcec3b  mulsd xmm14, xmm15
000070df2cbcec40  ucomisd xmm14, xmm14
000070df2cbcec45  jp 0x000070DF2CBCF170
000070df2cbcec4b  movq xmm14, xmm14
000070df2cbcec50  lea r14, [rax+0x140]
000070df2cbcec57  mov r12, [r13+r14*1]
000070df2cbcec5c  movq xmm1, r12
000070df2cbcec61  movq r14, xmm13
000070df2cbcec66  movq r12, xmm14
000070df2cbcec6b  vmovq xmm15, r14
000070df2cbcec70  vmovq xmm14, r12
000070df2cbcec75  movaps xmm13, xmm15
000070df2cbcec79  addsd xmm13, xmm14
000070df2cbcec7e  ucomisd xmm13, xmm13
000070df2cbcec83  jp 0x000070DF2CBCF1C6
000070df2cbcec89  movq xmm13, xmm13
000070df2cbcec8e  movaps xmm15, [r15+0x170]
000070df2cbcec96  movq r14, xmm15
000070df2cbcec9b  movq r12, xmm1
000070df2cbceca0  vmovq xmm1, r14
000070df2cbceca5  vmovq xmm15, r12
000070df2cbcecaa  movaps xmm14, xmm1
000070df2cbcecae  mulsd xmm14, xmm15
000070df2cbcecb3  ucomisd xmm14, xmm14
000070df2cbcecb8  jp 0x000070DF2CBCF212
000070df2cbcecbe  movq xmm14, xmm14
000070df2cbcecc3  lea r14, [rax+0x180]
000070df2cbcecca  mov r12, [r13+r14*1]
000070df2cbceccf  movq xmm1, r12
000070df2cbcecd4  movq r14, xmm13
000070df2cbcecd9  movq r12, xmm14
000070df2cbcecde  vmovq xmm15, r14
000070df2cbcece3  vmovq xmm14, r12
000070df2cbcece8  movaps xmm13, xmm15
000070df2cbcecec  addsd xmm13, xmm14
000070df2cbcecf1  ucomisd xmm13, xmm13
000070df2cbcecf6  jp 0x000070DF2CBCF268
000070df2cbcecfc  movq xmm13, xmm13
000070df2cbced01  movaps xmm15, [r15+0x180]
000070df2cbced09  movq r14, xmm15
000070df2cbced0e  movq r12, xmm1
000070df2cbced13  vmovq xmm1, r14
000070df2cbced18  vmovq xmm15, r12
000070df2cbced1d  movaps xmm14, xmm1
000070df2cbced21  mulsd xmm14, xmm15
000070df2cbced26  ucomisd xmm14, xmm14
000070df2cbced2b  jp 0x000070DF2CBCF2B4
000070df2cbced31  movq xmm14, xmm14
000070df2cbced36  lea r14, [rax+0x1C0]
000070df2cbced3d  mov rax, [r13+r14*1]
000070df2cbced42  movq xmm1, rax
000070df2cbced47  movaps [r15+0x240], xmm1
000070df2cbced4f  movq rax, xmm13
000070df2cbced54  movq r14, xmm14
000070df2cbced59  vmovq xmm15, rax
000070df2cbced5e  vmovq xmm14, r14
000070df2cbced63  movaps xmm13, xmm15
000070df2cbced67  addsd xmm13, xmm14
000070df2cbced6c  ucomisd xmm13, xmm13
000070df2cbced71  jp 0x000070DF2CBCF30A
000070df2cbced77  movq xmm13, xmm13
000070df2cbced7c  movaps xmm15, [r15+0x210]
000070df2cbced84  movq rax, xmm15
000070df2cbced89  movq r14, xmm1
000070df2cbced8e  vmovq xmm1, rax
000070df2cbced93  vmovq xmm15, r14
000070df2cbced98  movaps xmm14, xmm1
000070df2cbced9c  mulsd xmm14, xmm15
000070df2cbceda1  ucomisd xmm14, xmm14
000070df2cbceda6  jp 0x000070DF2CBCF352
000070df2cbcedac  movq xmm14, xmm14
000070df2cbcedb1  movaps [r15+0x230], xmm14
000070df2cbcedb9  movq rax, xmm13
000070df2cbcedbe  movq r14, xmm14
000070df2cbcedc3  vmovq xmm1, rax
000070df2cbcedc8  vmovq xmm15, r14
000070df2cbcedcd  movaps xmm14, xmm1
000070df2cbcedd1  addsd xmm14, xmm15
000070df2cbcedd6  ucomisd xmm14, xmm14
000070df2cbceddb  jp 0x000070DF2CBCF39A
000070df2cbcede1  movq xmm14, xmm14
000070df2cbcede6  movaps [r15+0x220], xmm14
000070df2cbcedee  movq rax, xmm14
000070df2cbcedf3  mov r14d, 0x4205C0
000070df2cbcedf9  mov [r13+r14*1], rax
000070df2cbcedfe  mov qword ptr [r15+0x70], 0x08
000070df2cbcee06  xor eax, eax
000070df2cbcee08  mov r14d, 0x08
000070df2cbcee0e  mov r12d, 0x40
000070df2cbcee14  cmp r14, r12
000070df2cbcee17  cmc
000070df2cbcee18  lahf
000070df2cbcee19  seto al
000070df2cbcee1c  mov [r15+0x108], eax
000070df2cbcee23  mov eax, [r15+0x108]
000070df2cbcee2a  sahf
000070df2cbcee2b  jnz 0x000070DF2CBCEE5D
000070df2cbcee2d  cmp dword ptr [r15+0x318], 0x00
000070df2cbcee35  jz 0x000070DF2CBCFD40
000070df2cbcee3b  nop [rax+rax*1], ax
000070df2cbcee44  nop [rax+rax*1], eax
000070df2cbcee4c  mov eax, 0x410118
000070df2cbcee51  mov [r15+0x100], rax
000070df2cbcee58  jmp 0x000070DF2C9FE110
000070df2cbcee5d  cmp dword ptr [r15+0x318], 0x00
000070df2cbcee65  jz 0x000070DF2CBCF3F0
000070df2cbcee6b  nop [rax+rax*1], ax
000070df2cbcee74  nop [rax+rax*1], eax
000070df2cbcee7c  mov eax, 0x4100A4
000070df2cbcee81  mov [r15+0x100], rax
000070df2cbcee88  jmp 0x000070DF2C9FE110
000070df2cbcee8d  int3
000070df2cbcee8e  call 0x000070DF2CA0DC20
000070df2cbcee93  jmp 0x000070DF2CBCE949
000070df2cbcee98  call 0x000070DF2CAC0370
000070df2cbcee9d  jmp 0x000070DF2CBCE952
000070df2cbceea2  call 0x000070DF2CAE27E0
000070df2cbceea7  jmp 0x000070DF2CBCE989
000070df2cbceeac  call 0x000070DF2CAE1570
000070df2cbceeb1  jmp 0x000070DF2CBCE992
000070df2cbceeb6  call 0x000070DF2CAE27E0
000070df2cbceebb  jmp 0x000070DF2CBCE9C9
000070df2cbceec0  call 0x000070DF2CAE1570
000070df2cbceec5  jmp 0x000070DF2CBCE9D2
000070df2cbceeca  call 0x000070DF2CAE27E0
000070df2cbceecf  jmp 0x000070DF2CBCEA09
000070df2cbceed4  call 0x000070DF2CAD59C0
000070df2cbceed9  jmp 0x000070DF2CBCEA12
000070df2cbceede  call 0x000070DF2CA0DC20
000070df2cbceee3  jmp 0x000070DF2CBCEA4D
000070df2cbceee8  call 0x000070DF2CAE27E0
000070df2cbceeed  jmp 0x000070DF2CBCEA5B
000070df2cbceef2  call 0x000070DF2CAE27E0
000070df2cbceef7  jmp 0x000070DF2CBCEA6C
000070df2cbceefc  ucomisd xmm15, xmm12
000070df2cbcef01  jp 0x000070DF2CBCEF10
000070df2cbcef03  movaps xmm11, [0x000070DF2C7FE030]
000070df2cbcef0b  jmp 0x000070DF2CBCEAA1
000070df2cbcef10  vxorps xmm0, xmm15, xmm12
000070df2cbcef15  pextrw r14d, xmm0, 0x03
000070df2cbcef1b  and r14d, 0x7FF8
000070df2cbcef22  cmp r14d, 0x08
000070df2cbcef26  jnz 0x000070DF2CBCEAA1
000070df2cbcef2c  movq r14, xmm12
000070df2cbcef31  shl r14, 0x0D
000070df2cbcef35  jbe 0x000070DF2CBCEAA1
000070df2cbcef3b  vorps xmm11, xmm12, [0x000070DF2C7FE040]
000070df2cbcef43  jmp 0x000070DF2CBCEAA1
000070df2cbcef48  ucomisd xmm15, xmm14
000070df2cbcef4d  jp 0x000070DF2CBCEF5C
000070df2cbcef4f  movaps xmm12, [0x000070DF2C7FE030]
000070df2cbcef57  jmp 0x000070DF2CBCEAD6
000070df2cbcef5c  vxorps xmm0, xmm15, xmm14
000070df2cbcef61  pextrw r14d, xmm0, 0x03
000070df2cbcef67  and r14d, 0x7FF8
000070df2cbcef6e  cmp r14d, 0x08
000070df2cbcef72  jnz 0x000070DF2CBCEAD6
000070df2cbcef78  movq r14, xmm14
000070df2cbcef7d  shl r14, 0x0D
000070df2cbcef81  jbe 0x000070DF2CBCEAD6
000070df2cbcef87  vorps xmm12, xmm14, [0x000070DF2C7FE040]
000070df2cbcef8f  jmp 0x000070DF2CBCEAD6
000070df2cbcef94  ucomisd xmm1, xmm15
000070df2cbcef99  jp 0x000070DF2CBCEFA8
000070df2cbcef9b  movaps xmm14, [0x000070DF2C7FE030]
000070df2cbcefa3  jmp 0x000070DF2CBCEB03
000070df2cbcefa8  vxorps xmm0, xmm1, xmm15
000070df2cbcefad  pextrw r14d, xmm0, 0x03
000070df2cbcefb3  and r14d, 0x7FF8
000070df2cbcefba  cmp r14d, 0x08
000070df2cbcefbe  jnz 0x000070DF2CBCEB03
000070df2cbcefc4  movq r14, xmm15
000070df2cbcefc9  shl r14, 0x0D
000070df2cbcefcd  jbe 0x000070DF2CBCEB03
000070df2cbcefd3  vorps xmm14, xmm15, [0x000070DF2C7FE040]
000070df2cbcefdb  jmp 0x000070DF2CBCEB03
000070df2cbcefe0  ucomisd xmm1, xmm15
000070df2cbcefe5  jp 0x000070DF2CBCEFF4
000070df2cbcefe7  movaps xmm14, [0x000070DF2C7FE030]
000070df2cbcefef  jmp 0x000070DF2CBCEB30
000070df2cbceff4  vxorps xmm0, xmm1, xmm15
000070df2cbceff9  pextrw r14d, xmm0, 0x03
000070df2cbcefff  and r14d, 0x7FF8
000070df2cbcf006  cmp r14d, 0x08
000070df2cbcf00a  jnz 0x000070DF2CBCEB30
000070df2cbcf010  movq r14, xmm15
000070df2cbcf015  shl r14, 0x0D
000070df2cbcf019  jbe 0x000070DF2CBCEB30
000070df2cbcf01f  vorps xmm14, xmm15, [0x000070DF2C7FE040]
000070df2cbcf027  jmp 0x000070DF2CBCEB30
000070df2cbcf02c  ucomisd xmm1, xmm15
000070df2cbcf031  jp 0x000070DF2CBCF040
000070df2cbcf033  movaps xmm13, [0x000070DF2C7FE030]
000070df2cbcf03b  jmp 0x000070DF2CBCEB65
000070df2cbcf040  vxorps xmm0, xmm1, xmm15
000070df2cbcf045  pextrw r14d, xmm0, 0x03
000070df2cbcf04b  and r14d, 0x7FF8
000070df2cbcf052  cmp r14d, 0x08
000070df2cbcf056  jnz 0x000070DF2CBCEB65
000070df2cbcf05c  movq r14, xmm15
000070df2cbcf061  shl r14, 0x0D
000070df2cbcf065  jbe 0x000070DF2CBCEB65
000070df2cbcf06b  vorps xmm13, xmm15, [0x000070DF2C7FE040]
000070df2cbcf073  jmp 0x000070DF2CBCEB65
000070df2cbcf078  call 0x000070DF2CAE27E0
000070df2cbcf07d  jmp 0x000070DF2CBCEB76
000070df2cbcf082  ucomisd xmm15, xmm14
000070df2cbcf087  jp 0x000070DF2CBCF096
000070df2cbcf089  movaps xmm13, [0x000070DF2C7FE030]
000070df2cbcf091  jmp 0x000070DF2CBCEBA3
000070df2cbcf096  vxorps xmm0, xmm15, xmm14
000070df2cbcf09b  pextrw r14d, xmm0, 0x03
000070df2cbcf0a1  and r14d, 0x7FF8
000070df2cbcf0a8  cmp r14d, 0x08
000070df2cbcf0ac  jnz 0x000070DF2CBCEBA3
000070df2cbcf0b2  movq r14, xmm14
000070df2cbcf0b7  shl r14, 0x0D
000070df2cbcf0bb  jbe 0x000070DF2CBCEBA3
000070df2cbcf0c1  vorps xmm13, xmm14, [0x000070DF2C7FE040]
000070df2cbcf0c9  jmp 0x000070DF2CBCEBA3
000070df2cbcf0ce  ucomisd xmm1, xmm15
000070df2cbcf0d3  jp 0x000070DF2CBCF0E2
000070df2cbcf0d5  movaps xmm14, [0x000070DF2C7FE030]
000070df2cbcf0dd  jmp 0x000070DF2CBCEBD8
000070df2cbcf0e2  vxorps xmm0, xmm1, xmm15
000070df2cbcf0e7  pextrw r14d, xmm0, 0x03
000070df2cbcf0ed  and r14d, 0x7FF8
000070df2cbcf0f4  cmp r14d, 0x08
000070df2cbcf0f8  jnz 0x000070DF2CBCEBD8
000070df2cbcf0fe  movq r14, xmm15
000070df2cbcf103  shl r14, 0x0D
000070df2cbcf107  jbe 0x000070DF2CBCEBD8
000070df2cbcf10d  vorps xmm14, xmm15, [0x000070DF2C7FE040]
000070df2cbcf115  jmp 0x000070DF2CBCEBD8
000070df2cbcf11a  call 0x000070DF2CAE27E0
000070df2cbcf11f  jmp 0x000070DF2CBCEBE9
000070df2cbcf124  ucomisd xmm15, xmm14
000070df2cbcf129  jp 0x000070DF2CBCF138
000070df2cbcf12b  movaps xmm13, [0x000070DF2C7FE030]
000070df2cbcf133  jmp 0x000070DF2CBCEC16
000070df2cbcf138  vxorps xmm0, xmm15, xmm14
000070df2cbcf13d  pextrw r14d, xmm0, 0x03
000070df2cbcf143  and r14d, 0x7FF8
000070df2cbcf14a  cmp r14d, 0x08
000070df2cbcf14e  jnz 0x000070DF2CBCEC16
000070df2cbcf154  movq r14, xmm14
000070df2cbcf159  shl r14, 0x0D
000070df2cbcf15d  jbe 0x000070DF2CBCEC16
000070df2cbcf163  vorps xmm13, xmm14, [0x000070DF2C7FE040]
000070df2cbcf16b  jmp 0x000070DF2CBCEC16
000070df2cbcf170  ucomisd xmm1, xmm15
000070df2cbcf175  jp 0x000070DF2CBCF184
000070df2cbcf177  movaps xmm14, [0x000070DF2C7FE030]
000070df2cbcf17f  jmp 0x000070DF2CBCEC4B
000070df2cbcf184  vxorps xmm0, xmm1, xmm15
000070df2cbcf189  pextrw r14d, xmm0, 0x03
000070df2cbcf18f  and r14d, 0x7FF8
000070df2cbcf196  cmp r14d, 0x08
000070df2cbcf19a  jnz 0x000070DF2CBCEC4B
000070df2cbcf1a0  movq r14, xmm15
000070df2cbcf1a5  shl r14, 0x0D
000070df2cbcf1a9  jbe 0x000070DF2CBCEC4B
000070df2cbcf1af  vorps xmm14, xmm15, [0x000070DF2C7FE040]
000070df2cbcf1b7  jmp 0x000070DF2CBCEC4B
000070df2cbcf1bc  call 0x000070DF2CAE27E0
000070df2cbcf1c1  jmp 0x000070DF2CBCEC5C
000070df2cbcf1c6  ucomisd xmm15, xmm14
000070df2cbcf1cb  jp 0x000070DF2CBCF1DA
000070df2cbcf1cd  movaps xmm13, [0x000070DF2C7FE030]
000070df2cbcf1d5  jmp 0x000070DF2CBCEC89
000070df2cbcf1da  vxorps xmm0, xmm15, xmm14
000070df2cbcf1df  pextrw r14d, xmm0, 0x03
000070df2cbcf1e5  and r14d, 0x7FF8
000070df2cbcf1ec  cmp r14d, 0x08
000070df2cbcf1f0  jnz 0x000070DF2CBCEC89
000070df2cbcf1f6  movq r14, xmm14
000070df2cbcf1fb  shl r14, 0x0D
000070df2cbcf1ff  jbe 0x000070DF2CBCEC89
000070df2cbcf205  vorps xmm13, xmm14, [0x000070DF2C7FE040]
000070df2cbcf20d  jmp 0x000070DF2CBCEC89
000070df2cbcf212  ucomisd xmm1, xmm15
000070df2cbcf217  jp 0x000070DF2CBCF226
000070df2cbcf219  movaps xmm14, [0x000070DF2C7FE030]
000070df2cbcf221  jmp 0x000070DF2CBCECBE
000070df2cbcf226  vxorps xmm0, xmm1, xmm15
000070df2cbcf22b  pextrw r14d, xmm0, 0x03
000070df2cbcf231  and r14d, 0x7FF8
000070df2cbcf238  cmp r14d, 0x08
000070df2cbcf23c  jnz 0x000070DF2CBCECBE
000070df2cbcf242  movq r14, xmm15
000070df2cbcf247  shl r14, 0x0D
000070df2cbcf24b  jbe 0x000070DF2CBCECBE
000070df2cbcf251  vorps xmm14, xmm15, [0x000070DF2C7FE040]
000070df2cbcf259  jmp 0x000070DF2CBCECBE
000070df2cbcf25e  call 0x000070DF2CAE27E0
000070df2cbcf263  jmp 0x000070DF2CBCECCF
000070df2cbcf268  ucomisd xmm15, xmm14
000070df2cbcf26d  jp 0x000070DF2CBCF27C
000070df2cbcf26f  movaps xmm13, [0x000070DF2C7FE030]
000070df2cbcf277  jmp 0x000070DF2CBCECFC
000070df2cbcf27c  vxorps xmm0, xmm15, xmm14
000070df2cbcf281  pextrw r14d, xmm0, 0x03
000070df2cbcf287  and r14d, 0x7FF8
000070df2cbcf28e  cmp r14d, 0x08
000070df2cbcf292  jnz 0x000070DF2CBCECFC
000070df2cbcf298  movq r14, xmm14
000070df2cbcf29d  shl r14, 0x0D
000070df2cbcf2a1  jbe 0x000070DF2CBCECFC
000070df2cbcf2a7  vorps xmm13, xmm14, [0x000070DF2C7FE040]
000070df2cbcf2af  jmp 0x000070DF2CBCECFC
000070df2cbcf2b4  ucomisd xmm1, xmm15
000070df2cbcf2b9  jp 0x000070DF2CBCF2C8
000070df2cbcf2bb  movaps xmm14, [0x000070DF2C7FE030]
000070df2cbcf2c3  jmp 0x000070DF2CBCED31
000070df2cbcf2c8  vxorps xmm0, xmm1, xmm15
000070df2cbcf2cd  pextrw r14d, xmm0, 0x03
000070df2cbcf2d3  and r14d, 0x7FF8
000070df2cbcf2da  cmp r14d, 0x08
000070df2cbcf2de  jnz 0x000070DF2CBCED31
000070df2cbcf2e4  movq r14, xmm15
000070df2cbcf2e9  shl r14, 0x0D
000070df2cbcf2ed  jbe 0x000070DF2CBCED31
000070df2cbcf2f3  vorps xmm14, xmm15, [0x000070DF2C7FE040]
000070df2cbcf2fb  jmp 0x000070DF2CBCED31
000070df2cbcf300  call 0x000070DF2CAD59C0
000070df2cbcf305  jmp 0x000070DF2CBCED42
000070df2cbcf30a  ucomisd xmm15, xmm14
000070df2cbcf30f  jp 0x000070DF2CBCF31E
000070df2cbcf311  movaps xmm13, [0x000070DF2C7FE030]
000070df2cbcf319  jmp 0x000070DF2CBCED77
000070df2cbcf31e  vxorps xmm0, xmm15, xmm14
000070df2cbcf323  pextrw eax, xmm0, 0x03
000070df2cbcf328  and eax, 0x7FF8
000070df2cbcf32d  cmp eax, 0x08
000070df2cbcf330  jnz 0x000070DF2CBCED77
000070df2cbcf336  movq rax, xmm14
000070df2cbcf33b  shl rax, 0x0D
000070df2cbcf33f  jbe 0x000070DF2CBCED77
000070df2cbcf345  vorps xmm13, xmm14, [0x000070DF2C7FE040]
000070df2cbcf34d  jmp 0x000070DF2CBCED77
000070df2cbcf352  ucomisd xmm1, xmm15
000070df2cbcf357  jp 0x000070DF2CBCF366
000070df2cbcf359  movaps xmm14, [0x000070DF2C7FE030]
000070df2cbcf361  jmp 0x000070DF2CBCEDAC
000070df2cbcf366  vxorps xmm0, xmm1, xmm15
000070df2cbcf36b  pextrw eax, xmm0, 0x03
000070df2cbcf370  and eax, 0x7FF8
000070df2cbcf375  cmp eax, 0x08
000070df2cbcf378  jnz 0x000070DF2CBCEDAC
000070df2cbcf37e  movq rax, xmm15
000070df2cbcf383  shl rax, 0x0D
000070df2cbcf387  jbe 0x000070DF2CBCEDAC
000070df2cbcf38d  vorps xmm14, xmm15, [0x000070DF2C7FE040]
000070df2cbcf395  jmp 0x000070DF2CBCEDAC
000070df2cbcf39a  ucomisd xmm1, xmm15
000070df2cbcf39f  jp 0x000070DF2CBCF3AE
000070df2cbcf3a1  movaps xmm14, [0x000070DF2C7FE030]
000070df2cbcf3a9  jmp 0x000070DF2CBCEDE1
000070df2cbcf3ae  vxorps xmm0, xmm1, xmm15
000070df2cbcf3b3  pextrw eax, xmm0, 0x03
000070df2cbcf3b8  and eax, 0x7FF8
000070df2cbcf3bd  cmp eax, 0x08
000070df2cbcf3c0  jnz 0x000070DF2CBCEDE1
000070df2cbcf3c6  movq rax, xmm15
000070df2cbcf3cb  shl rax, 0x0D
000070df2cbcf3cf  jbe 0x000070DF2CBCEDE1
000070df2cbcf3d5  vorps xmm14, xmm15, [0x000070DF2C7FE040]
000070df2cbcf3dd  jmp 0x000070DF2CBCEDE1
000070df2cbcf3e2  call 0x000070DF2CAD5EB0
000070df2cbcf3e7  jmp 0x000070DF2CBCEDFE
000070df2cbcf3ec  int3
000070df2cbcf3ed  nop [rax], eax
000070df2cbcf3f0  mov rax, [r15+0x48]
000070df2cbcf3f4  mov r14, [r15+0x70]
000070df2cbcf3f8  lea r12, [rax+r14*1]
000070df2cbcf3fc  mov [r15+0x78], r12
000070df2cbcf400  mov rax, [r13+r12*1]
000070df2cbcf405  movq xmm1, rax
000070df2cbcf40a  lea rax, [r12+0x40]
000070df2cbcf40f  mov r11, [r13+rax*1]
000070df2cbcf414  movq xmm15, r11
000070df2cbcf419  lea rax, [r12+0x80]
000070df2cbcf421  mov r11, [r13+rax*1]
000070df2cbcf426  movq xmm14, r11
000070df2cbcf42b  movaps xmm13, [r15+0x120]
000070df2cbcf433  movq rax, xmm13
000070df2cbcf438  movq r11, xmm1
000070df2cbcf43d  vmovq xmm1, rax
000070df2cbcf442  vmovq xmm13, r11
000070df2cbcf447  movaps xmm12, xmm1
000070df2cbcf44b  mulsd xmm12, xmm13
000070df2cbcf450  ucomisd xmm12, xmm12
000070df2cbcf455  jp 0x000070DF2CBCF879
000070df2cbcf45b  movq xmm12, xmm12
000070df2cbcf460  movaps xmm1, [r15+0x130]
000070df2cbcf468  movq rax, xmm1
000070df2cbcf46d  movq r11, xmm15
000070df2cbcf472  vmovq xmm1, rax
000070df2cbcf477  vmovq xmm15, r11
000070df2cbcf47c  movaps xmm13, xmm1
000070df2cbcf480  mulsd xmm13, xmm15
000070df2cbcf485  ucomisd xmm13, xmm13
000070df2cbcf48a  jp 0x000070DF2CBCF8C1
000070df2cbcf490  movq xmm13, xmm13
000070df2cbcf495  movq rax, xmm12
000070df2cbcf49a  movaps xmm1, [r15+0x110]
000070df2cbcf4a2  movq r11, xmm1
000070df2cbcf4a7  vmovq xmm1, rax
000070df2cbcf4ac  vmovq xmm15, r11
000070df2cbcf4b1  movaps xmm12, xmm1
000070df2cbcf4b5  addsd xmm12, xmm15
000070df2cbcf4ba  ucomisd xmm12, xmm12
000070df2cbcf4bf  jp 0x000070DF2CBCF909
000070df2cbcf4c5  movq xmm12, xmm12
000070df2cbcf4ca  movq rax, xmm12
000070df2cbcf4cf  movq r11, xmm13
000070df2cbcf4d4  vmovq xmm1, rax
000070df2cbcf4d9  vmovq xmm15, r11
000070df2cbcf4de  movaps xmm13, xmm1
000070df2cbcf4e2  addsd xmm13, xmm15
000070df2cbcf4e7  ucomisd xmm13, xmm13
000070df2cbcf4ec  jp 0x000070DF2CBCF951
000070df2cbcf4f2  movq xmm13, xmm13
000070df2cbcf4f7  movaps xmm1, [r15+0x140]
000070df2cbcf4ff  movq rax, xmm1
000070df2cbcf504  movq r11, xmm14
000070df2cbcf509  vmovq xmm1, rax
000070df2cbcf50e  vmovq xmm15, r11
000070df2cbcf513  movaps xmm14, xmm1
000070df2cbcf517  mulsd xmm14, xmm15
000070df2cbcf51c  ucomisd xmm14, xmm14
000070df2cbcf521  jp 0x000070DF2CBCF999
000070df2cbcf527  movq xmm14, xmm14
000070df2cbcf52c  lea rax, [r12+0xC0]
000070df2cbcf534  mov r11, [r13+rax*1]
000070df2cbcf539  movq xmm1, r11
000070df2cbcf53e  movq rax, xmm13
000070df2cbcf543  movq r11, xmm14
000070df2cbcf548  vmovq xmm15, rax
000070df2cbcf54d  vmovq xmm14, r11
000070df2cbcf552  movaps xmm13, xmm15
000070df2cbcf556  addsd xmm13, xmm14
000070df2cbcf55b  ucomisd xmm13, xmm13
000070df2cbcf560  jp 0x000070DF2CBCF9EB
000070df2cbcf566  movq xmm13, xmm13
000070df2cbcf56b  movaps xmm15, [r15+0x150]
000070df2cbcf573  movq rax, xmm15
000070df2cbcf578  movq r11, xmm1
000070df2cbcf57d  vmovq xmm1, rax
000070df2cbcf582  vmovq xmm15, r11
000070df2cbcf587  movaps xmm14, xmm1
000070df2cbcf58b  mulsd xmm14, xmm15
000070df2cbcf590  ucomisd xmm14, xmm14
000070df2cbcf595  jp 0x000070DF2CBCFA33
000070df2cbcf59b  movq xmm14, xmm14
000070df2cbcf5a0  lea rax, [r12+0x100]
000070df2cbcf5a8  mov r11, [r13+rax*1]
000070df2cbcf5ad  movq xmm1, r11
000070df2cbcf5b2  movq rax, xmm13
000070df2cbcf5b7  movq r11, xmm14
000070df2cbcf5bc  vmovq xmm15, rax
000070df2cbcf5c1  vmovq xmm14, r11
000070df2cbcf5c6  movaps xmm13, xmm15
000070df2cbcf5ca  addsd xmm13, xmm14
000070df2cbcf5cf  ucomisd xmm13, xmm13
000070df2cbcf5d4  jp 0x000070DF2CBCFA85
000070df2cbcf5da  movq xmm13, xmm13
000070df2cbcf5df  movaps xmm15, [r15+0x160]
000070df2cbcf5e7  movq rax, xmm15
000070df2cbcf5ec  movq r11, xmm1
000070df2cbcf5f1  vmovq xmm1, rax
000070df2cbcf5f6  vmovq xmm15, r11
000070df2cbcf5fb  movaps xmm14, xmm1
000070df2cbcf5ff  mulsd xmm14, xmm15
000070df2cbcf604  ucomisd xmm14, xmm14
000070df2cbcf609  jp 0x000070DF2CBCFACD
000070df2cbcf60f  movq xmm14, xmm14
000070df2cbcf614  lea rax, [r12+0x140]
000070df2cbcf61c  mov r11, [r13+rax*1]
000070df2cbcf621  movq xmm1, r11
000070df2cbcf626  movq rax, xmm13
000070df2cbcf62b  movq r11, xmm14
000070df2cbcf630  vmovq xmm15, rax
000070df2cbcf635  vmovq xmm14, r11
000070df2cbcf63a  movaps xmm13, xmm15
000070df2cbcf63e  addsd xmm13, xmm14
000070df2cbcf643  ucomisd xmm13, xmm13
000070df2cbcf648  jp 0x000070DF2CBCFB1F
000070df2cbcf64e  movq xmm13, xmm13
000070df2cbcf653  movaps xmm15, [r15+0x170]
000070df2cbcf65b  movq rax, xmm15
000070df2cbcf660  movq r11, xmm1
000070df2cbcf665  vmovq xmm1, rax
000070df2cbcf66a  vmovq xmm15, r11
000070df2cbcf66f  movaps xmm14, xmm1
000070df2cbcf673  mulsd xmm14, xmm15
000070df2cbcf678  ucomisd xmm14, xmm14
000070df2cbcf67d  jp 0x000070DF2CBCFB67
000070df2cbcf683  movq xmm14, xmm14
000070df2cbcf688  lea rax, [r12+0x180]
000070df2cbcf690  mov r11, [r13+rax*1]
000070df2cbcf695  movq xmm1, r11
000070df2cbcf69a  movq rax, xmm13
000070df2cbcf69f  movq r11, xmm14
000070df2cbcf6a4  vmovq xmm15, rax
000070df2cbcf6a9  vmovq xmm14, r11
000070df2cbcf6ae  movaps xmm13, xmm15
000070df2cbcf6b2  addsd xmm13, xmm14
000070df2cbcf6b7  ucomisd xmm13, xmm13
000070df2cbcf6bc  jp 0x000070DF2CBCFBB9
000070df2cbcf6c2  movq xmm13, xmm13
000070df2cbcf6c7  movaps xmm15, [r15+0x180]
000070df2cbcf6cf  movq rax, xmm15
000070df2cbcf6d4  movq r11, xmm1
000070df2cbcf6d9  vmovq xmm1, rax
000070df2cbcf6de  vmovq xmm15, r11
000070df2cbcf6e3  movaps xmm14, xmm1
000070df2cbcf6e7  mulsd xmm14, xmm15
000070df2cbcf6ec  ucomisd xmm14, xmm14
000070df2cbcf6f1  jp 0x000070DF2CBCFC01
000070df2cbcf6f7  movq xmm14, xmm14
000070df2cbcf6fc  lea rax, [r12+0x1C0]
000070df2cbcf704  mov r12, [r13+rax*1]
000070df2cbcf709  movq xmm1, r12
000070df2cbcf70e  movaps [r15+0x240], xmm1
000070df2cbcf716  movq rax, xmm13
000070df2cbcf71b  movq r12, xmm14
000070df2cbcf720  vmovq xmm15, rax
000070df2cbcf725  vmovq xmm14, r12
000070df2cbcf72a  movaps xmm13, xmm15
000070df2cbcf72e  addsd xmm13, xmm14
000070df2cbcf733  ucomisd xmm13, xmm13
000070df2cbcf738  jp 0x000070DF2CBCFC53
000070df2cbcf73e  movq xmm13, xmm13
000070df2cbcf743  movaps xmm15, [r15+0x210]
000070df2cbcf74b  movq rax, xmm15
000070df2cbcf750  movq r12, xmm1
000070df2cbcf755  vmovq xmm1, rax
000070df2cbcf75a  vmovq xmm15, r12
000070df2cbcf75f  movaps xmm14, xmm1
000070df2cbcf763  mulsd xmm14, xmm15
000070df2cbcf768  ucomisd xmm14, xmm14
000070df2cbcf76d  jp 0x000070DF2CBCFC9B
000070df2cbcf773  movq xmm14, xmm14
000070df2cbcf778  movaps [r15+0x230], xmm14
000070df2cbcf780  movq rax, xmm13
000070df2cbcf785  movq r12, xmm14
000070df2cbcf78a  vmovq xmm1, rax
000070df2cbcf78f  vmovq xmm15, r12
000070df2cbcf794  movaps xmm14, xmm1
000070df2cbcf798  addsd xmm14, xmm15
000070df2cbcf79d  ucomisd xmm14, xmm14
000070df2cbcf7a2  jp 0x000070DF2CBCFCE3
000070df2cbcf7a8  movq xmm14, xmm14
000070df2cbcf7ad  movaps [r15+0x220], xmm14
000070df2cbcf7b5  mov rax, [r15+0x68]
000070df2cbcf7b9  lea r12, [rax+r14*1]
000070df2cbcf7bd  movq rax, xmm14
000070df2cbcf7c2  mov [r13+r12*1], rax
000070df2cbcf7c7  lea rax, [r14+0x08]
000070df2cbcf7cb  mov [r15+0x70], rax
000070df2cbcf7cf  mov [rsp+0x10], rax
000070df2cbcf7d4  xor eax, eax
000070df2cbcf7d6  mov r14, [rsp+0x10]
000070df2cbcf7db  mov r12d, 0x40
000070df2cbcf7e1  cmp r14, r12
000070df2cbcf7e4  cmc
000070df2cbcf7e5  lahf
000070df2cbcf7e6  seto al
000070df2cbcf7e9  mov [r15+0x108], eax
000070df2cbcf7f0  mov eax, [r15+0x108]
000070df2cbcf7f7  sahf
000070df2cbcf7f8  jnz 0x000070DF2CBCF82A
000070df2cbcf7fa  cmp dword ptr [r15+0x318], 0x00
000070df2cbcf802  jz 0x000070DF2CBCFD40
000070df2cbcf808  nop [rax+rax*1], ax
000070df2cbcf811  nop [rax+rax*1], eax
000070df2cbcf819  mov eax, 0x410118
000070df2cbcf81e  mov [r15+0x100], rax
000070df2cbcf825  jmp 0x000070DF2C9FE110
000070df2cbcf82a  cmp dword ptr [r15+0x318], 0x00
000070df2cbcf832  jz 0x000070DF2CBCF3F0
000070df2cbcf838  nop [rax+rax*1], ax
000070df2cbcf841  nop [rax+rax*1], eax
000070df2cbcf849  mov eax, 0x4100A4
000070df2cbcf84e  mov [r15+0x100], rax
000070df2cbcf855  jmp 0x000070DF2C9FE110
000070df2cbcf85a  int3
000070df2cbcf85b  call 0x000070DF2CAB47C0
000070df2cbcf860  jmp 0x000070DF2CBCF405
000070df2cbcf865  call 0x000070DF2CA0A4B0
000070df2cbcf86a  jmp 0x000070DF2CBCF414
000070df2cbcf86f  call 0x000070DF2CA0A4B0
000070df2cbcf874  jmp 0x000070DF2CBCF426
000070df2cbcf879  ucomisd xmm1, xmm13
000070df2cbcf87e  jp 0x000070DF2CBCF88D
000070df2cbcf880  movaps xmm12, [0x000070DF2C7FE030]
000070df2cbcf888  jmp 0x000070DF2CBCF45B
000070df2cbcf88d  vxorps xmm0, xmm1, xmm13
000070df2cbcf892  pextrw eax, xmm0, 0x03
000070df2cbcf897  and eax, 0x7FF8
000070df2cbcf89c  cmp eax, 0x08
000070df2cbcf89f  jnz 0x000070DF2CBCF45B
000070df2cbcf8a5  movq rax, xmm13
000070df2cbcf8aa  shl rax, 0x0D
000070df2cbcf8ae  jbe 0x000070DF2CBCF45B
000070df2cbcf8b4  vorps xmm12, xmm13, [0x000070DF2C7FE040]
000070df2cbcf8bc  jmp 0x000070DF2CBCF45B
000070df2cbcf8c1  ucomisd xmm1, xmm15
000070df2cbcf8c6  jp 0x000070DF2CBCF8D5
000070df2cbcf8c8  movaps xmm13, [0x000070DF2C7FE030]
000070df2cbcf8d0  jmp 0x000070DF2CBCF490
000070df2cbcf8d5  vxorps xmm0, xmm1, xmm15
000070df2cbcf8da  pextrw eax, xmm0, 0x03
000070df2cbcf8df  and eax, 0x7FF8
000070df2cbcf8e4  cmp eax, 0x08
000070df2cbcf8e7  jnz 0x000070DF2CBCF490
000070df2cbcf8ed  movq rax, xmm15
000070df2cbcf8f2  shl rax, 0x0D
000070df2cbcf8f6  jbe 0x000070DF2CBCF490
000070df2cbcf8fc  vorps xmm13, xmm15, [0x000070DF2C7FE040]
000070df2cbcf904  jmp 0x000070DF2CBCF490
000070df2cbcf909  ucomisd xmm1, xmm15
000070df2cbcf90e  jp 0x000070DF2CBCF91D
000070df2cbcf910  movaps xmm12, [0x000070DF2C7FE030]
000070df2cbcf918  jmp 0x000070DF2CBCF4C5
000070df2cbcf91d  vxorps xmm0, xmm1, xmm15
000070df2cbcf922  pextrw eax, xmm0, 0x03
000070df2cbcf927  and eax, 0x7FF8
000070df2cbcf92c  cmp eax, 0x08
000070df2cbcf92f  jnz 0x000070DF2CBCF4C5
000070df2cbcf935  movq rax, xmm15
000070df2cbcf93a  shl rax, 0x0D
000070df2cbcf93e  jbe 0x000070DF2CBCF4C5
000070df2cbcf944  vorps xmm12, xmm15, [0x000070DF2C7FE040]
000070df2cbcf94c  jmp 0x000070DF2CBCF4C5
000070df2cbcf951  ucomisd xmm1, xmm15
000070df2cbcf956  jp 0x000070DF2CBCF965
000070df2cbcf958  movaps xmm13, [0x000070DF2C7FE030]
000070df2cbcf960  jmp 0x000070DF2CBCF4F2
000070df2cbcf965  vxorps xmm0, xmm1, xmm15
000070df2cbcf96a  pextrw eax, xmm0, 0x03
000070df2cbcf96f  and eax, 0x7FF8
000070df2cbcf974  cmp eax, 0x08
000070df2cbcf977  jnz 0x000070DF2CBCF4F2
000070df2cbcf97d  movq rax, xmm15
000070df2cbcf982  shl rax, 0x0D
000070df2cbcf986  jbe 0x000070DF2CBCF4F2
000070df2cbcf98c  vorps xmm13, xmm15, [0x000070DF2C7FE040]
000070df2cbcf994  jmp 0x000070DF2CBCF4F2
000070df2cbcf999  ucomisd xmm1, xmm15
000070df2cbcf99e  jp 0x000070DF2CBCF9AD
000070df2cbcf9a0  movaps xmm14, [0x000070DF2C7FE030]
000070df2cbcf9a8  jmp 0x000070DF2CBCF527
000070df2cbcf9ad  vxorps xmm0, xmm1, xmm15
000070df2cbcf9b2  pextrw eax, xmm0, 0x03
000070df2cbcf9b7  and eax, 0x7FF8
000070df2cbcf9bc  cmp eax, 0x08
000070df2cbcf9bf  jnz 0x000070DF2CBCF527
000070df2cbcf9c5  movq rax, xmm15
000070df2cbcf9ca  shl rax, 0x0D
000070df2cbcf9ce  jbe 0x000070DF2CBCF527
000070df2cbcf9d4  vorps xmm14, xmm15, [0x000070DF2C7FE040]
000070df2cbcf9dc  jmp 0x000070DF2CBCF527
000070df2cbcf9e1  call 0x000070DF2CA0A4B0
000070df2cbcf9e6  jmp 0x000070DF2CBCF539
000070df2cbcf9eb  ucomisd xmm15, xmm14
000070df2cbcf9f0  jp 0x000070DF2CBCF9FF
000070df2cbcf9f2  movaps xmm13, [0x000070DF2C7FE030]
000070df2cbcf9fa  jmp 0x000070DF2CBCF566
000070df2cbcf9ff  vxorps xmm0, xmm15, xmm14
000070df2cbcfa04  pextrw eax, xmm0, 0x03
000070df2cbcfa09  and eax, 0x7FF8
000070df2cbcfa0e  cmp eax, 0x08
000070df2cbcfa11  jnz 0x000070DF2CBCF566
000070df2cbcfa17  movq rax, xmm14
000070df2cbcfa1c  shl rax, 0x0D
000070df2cbcfa20  jbe 0x000070DF2CBCF566
000070df2cbcfa26  vorps xmm13, xmm14, [0x000070DF2C7FE040]
000070df2cbcfa2e  jmp 0x000070DF2CBCF566
000070df2cbcfa33  ucomisd xmm1, xmm15
000070df2cbcfa38  jp 0x000070DF2CBCFA47
000070df2cbcfa3a  movaps xmm14, [0x000070DF2C7FE030]
000070df2cbcfa42  jmp 0x000070DF2CBCF59B
000070df2cbcfa47  vxorps xmm0, xmm1, xmm15
000070df2cbcfa4c  pextrw eax, xmm0, 0x03
000070df2cbcfa51  and eax, 0x7FF8
000070df2cbcfa56  cmp eax, 0x08
000070df2cbcfa59  jnz 0x000070DF2CBCF59B
000070df2cbcfa5f  movq rax, xmm15
000070df2cbcfa64  shl rax, 0x0D
000070df2cbcfa68  jbe 0x000070DF2CBCF59B
000070df2cbcfa6e  vorps xmm14, xmm15, [0x000070DF2C7FE040]
000070df2cbcfa76  jmp 0x000070DF2CBCF59B
000070df2cbcfa7b  call 0x000070DF2CA0A4B0
000070df2cbcfa80  jmp 0x000070DF2CBCF5AD
000070df2cbcfa85  ucomisd xmm15, xmm14
000070df2cbcfa8a  jp 0x000070DF2CBCFA99
000070df2cbcfa8c  movaps xmm13, [0x000070DF2C7FE030]
000070df2cbcfa94  jmp 0x000070DF2CBCF5DA
000070df2cbcfa99  vxorps xmm0, xmm15, xmm14
000070df2cbcfa9e  pextrw eax, xmm0, 0x03
000070df2cbcfaa3  and eax, 0x7FF8
000070df2cbcfaa8  cmp eax, 0x08
000070df2cbcfaab  jnz 0x000070DF2CBCF5DA
000070df2cbcfab1  movq rax, xmm14
000070df2cbcfab6  shl rax, 0x0D
000070df2cbcfaba  jbe 0x000070DF2CBCF5DA
000070df2cbcfac0  vorps xmm13, xmm14, [0x000070DF2C7FE040]
000070df2cbcfac8  jmp 0x000070DF2CBCF5DA
000070df2cbcfacd  ucomisd xmm1, xmm15
000070df2cbcfad2  jp 0x000070DF2CBCFAE1
000070df2cbcfad4  movaps xmm14, [0x000070DF2C7FE030]
000070df2cbcfadc  jmp 0x000070DF2CBCF60F
000070df2cbcfae1  vxorps xmm0, xmm1, xmm15
000070df2cbcfae6  pextrw eax, xmm0, 0x03
000070df2cbcfaeb  and eax, 0x7FF8
000070df2cbcfaf0  cmp eax, 0x08
000070df2cbcfaf3  jnz 0x000070DF2CBCF60F
000070df2cbcfaf9  movq rax, xmm15
000070df2cbcfafe  shl rax, 0x0D
000070df2cbcfb02  jbe 0x000070DF2CBCF60F
000070df2cbcfb08  vorps xmm14, xmm15, [0x000070DF2C7FE040]
000070df2cbcfb10  jmp 0x000070DF2CBCF60F
000070df2cbcfb15  call 0x000070DF2CA0A4B0
000070df2cbcfb1a  jmp 0x000070DF2CBCF621
000070df2cbcfb1f  ucomisd xmm15, xmm14
000070df2cbcfb24  jp 0x000070DF2CBCFB33
000070df2cbcfb26  movaps xmm13, [0x000070DF2C7FE030]
000070df2cbcfb2e  jmp 0x000070DF2CBCF64E
000070df2cbcfb33  vxorps xmm0, xmm15, xmm14
000070df2cbcfb38  pextrw eax, xmm0, 0x03
000070df2cbcfb3d  and eax, 0x7FF8
000070df2cbcfb42  cmp eax, 0x08
000070df2cbcfb45  jnz 0x000070DF2CBCF64E
000070df2cbcfb4b  movq rax, xmm14
000070df2cbcfb50  shl rax, 0x0D
000070df2cbcfb54  jbe 0x000070DF2CBCF64E
000070df2cbcfb5a  vorps xmm13, xmm14, [0x000070DF2C7FE040]
000070df2cbcfb62  jmp 0x000070DF2CBCF64E
000070df2cbcfb67  ucomisd xmm1, xmm15
000070df2cbcfb6c  jp 0x000070DF2CBCFB7B
000070df2cbcfb6e  movaps xmm14, [0x000070DF2C7FE030]
000070df2cbcfb76  jmp 0x000070DF2CBCF683
000070df2cbcfb7b  vxorps xmm0, xmm1, xmm15
000070df2cbcfb80  pextrw eax, xmm0, 0x03
000070df2cbcfb85  and eax, 0x7FF8
000070df2cbcfb8a  cmp eax, 0x08
000070df2cbcfb8d  jnz 0x000070DF2CBCF683
000070df2cbcfb93  movq rax, xmm15
000070df2cbcfb98  shl rax, 0x0D
000070df2cbcfb9c  jbe 0x000070DF2CBCF683
000070df2cbcfba2  vorps xmm14, xmm15, [0x000070DF2C7FE040]
000070df2cbcfbaa  jmp 0x000070DF2CBCF683
000070df2cbcfbaf  call 0x000070DF2CA0A4B0
000070df2cbcfbb4  jmp 0x000070DF2CBCF695
000070df2cbcfbb9  ucomisd xmm15, xmm14
000070df2cbcfbbe  jp 0x000070DF2CBCFBCD
000070df2cbcfbc0  movaps xmm13, [0x000070DF2C7FE030]
000070df2cbcfbc8  jmp 0x000070DF2CBCF6C2
000070df2cbcfbcd  vxorps xmm0, xmm15, xmm14
000070df2cbcfbd2  pextrw eax, xmm0, 0x03
000070df2cbcfbd7  and eax, 0x7FF8
000070df2cbcfbdc  cmp eax, 0x08
000070df2cbcfbdf  jnz 0x000070DF2CBCF6C2
000070df2cbcfbe5  movq rax, xmm14
000070df2cbcfbea  shl rax, 0x0D
000070df2cbcfbee  jbe 0x000070DF2CBCF6C2
000070df2cbcfbf4  vorps xmm13, xmm14, [0x000070DF2C7FE040]
000070df2cbcfbfc  jmp 0x000070DF2CBCF6C2
000070df2cbcfc01  ucomisd xmm1, xmm15
000070df2cbcfc06  jp 0x000070DF2CBCFC15
000070df2cbcfc08  movaps xmm14, [0x000070DF2C7FE030]
000070df2cbcfc10  jmp 0x000070DF2CBCF6F7
000070df2cbcfc15  vxorps xmm0, xmm1, xmm15
000070df2cbcfc1a  pextrw eax, xmm0, 0x03
000070df2cbcfc1f  and eax, 0x7FF8
000070df2cbcfc24  cmp eax, 0x08
000070df2cbcfc27  jnz 0x000070DF2CBCF6F7
000070df2cbcfc2d  movq rax, xmm15
000070df2cbcfc32  shl rax, 0x0D
000070df2cbcfc36  jbe 0x000070DF2CBCF6F7
000070df2cbcfc3c  vorps xmm14, xmm15, [0x000070DF2C7FE040]
000070df2cbcfc44  jmp 0x000070DF2CBCF6F7
000070df2cbcfc49  call 0x000070DF2CA0B720
000070df2cbcfc4e  jmp 0x000070DF2CBCF709
000070df2cbcfc53  ucomisd xmm15, xmm14
000070df2cbcfc58  jp 0x000070DF2CBCFC67
000070df2cbcfc5a  movaps xmm13, [0x000070DF2C7FE030]
000070df2cbcfc62  jmp 0x000070DF2CBCF73E
000070df2cbcfc67  vxorps xmm0, xmm15, xmm14
000070df2cbcfc6c  pextrw eax, xmm0, 0x03
000070df2cbcfc71  and eax, 0x7FF8
000070df2cbcfc76  cmp eax, 0x08
000070df2cbcfc79  jnz 0x000070DF2CBCF73E
000070df2cbcfc7f  movq rax, xmm14
000070df2cbcfc84  shl rax, 0x0D
000070df2cbcfc88  jbe 0x000070DF2CBCF73E
000070df2cbcfc8e  vorps xmm13, xmm14, [0x000070DF2C7FE040]
000070df2cbcfc96  jmp 0x000070DF2CBCF73E
000070df2cbcfc9b  ucomisd xmm1, xmm15
000070df2cbcfca0  jp 0x000070DF2CBCFCAF
000070df2cbcfca2  movaps xmm14, [0x000070DF2C7FE030]
000070df2cbcfcaa  jmp 0x000070DF2CBCF773
000070df2cbcfcaf  vxorps xmm0, xmm1, xmm15
000070df2cbcfcb4  pextrw eax, xmm0, 0x03
000070df2cbcfcb9  and eax, 0x7FF8
000070df2cbcfcbe  cmp eax, 0x08
000070df2cbcfcc1  jnz 0x000070DF2CBCF773
000070df2cbcfcc7  movq rax, xmm15
000070df2cbcfccc  shl rax, 0x0D
000070df2cbcfcd0  jbe 0x000070DF2CBCF773
000070df2cbcfcd6  vorps xmm14, xmm15, [0x000070DF2C7FE040]
000070df2cbcfcde  jmp 0x000070DF2CBCF773
000070df2cbcfce3  ucomisd xmm1, xmm15
000070df2cbcfce8  jp 0x000070DF2CBCFCF7
000070df2cbcfcea  movaps xmm14, [0x000070DF2C7FE030]
000070df2cbcfcf2  jmp 0x000070DF2CBCF7A8
000070df2cbcfcf7  vxorps xmm0, xmm1, xmm15
000070df2cbcfcfc  pextrw eax, xmm0, 0x03
000070df2cbcfd01  and eax, 0x7FF8
000070df2cbcfd06  cmp eax, 0x08
000070df2cbcfd09  jnz 0x000070DF2CBCF7A8
000070df2cbcfd0f  movq rax, xmm15
000070df2cbcfd14  shl rax, 0x0D
000070df2cbcfd18  jbe 0x000070DF2CBCF7A8
000070df2cbcfd1e  vorps xmm14, xmm15, [0x000070DF2C7FE040]
000070df2cbcfd26  jmp 0x000070DF2CBCF7A8
000070df2cbcfd2b  call 0x000070DF2CAB4CB0
000070df2cbcfd30  jmp 0x000070DF2CBCF7C7
000070df2cbcfd35  int3
000070df2cbcfd36  nop [rax+rax*1], ax
000070df2cbcfd3f  nop
000070df2cbcfd40  mov rax, [r15+0x60]
000070df2cbcfd44  lea r14, [rax+0x01]
000070df2cbcfd48  mov [r15+0x60], r14
000070df2cbcfd4c  mov rax, [r15+0x68]
000070df2cbcfd50  lea r12, [rax+0x40]
000070df2cbcfd54  mov [r15+0x68], r12
000070df2cbcfd58  xor eax, eax
000070df2cbcfd5a  mov r12d, 0x08
000070df2cbcfd60  cmp r14, r12
000070df2cbcfd63  cmc
000070df2cbcfd64  lahf
000070df2cbcfd65  seto al
000070df2cbcfd68  mov [r15+0x108], eax
000070df2cbcfd6f  mov eax, [r15+0x108]
000070df2cbcfd76  sahf
000070df2cbcfd77  jnz 0x000070DF2CBCFDA9
000070df2cbcfd79  cmp dword ptr [r15+0x318], 0x00
000070df2cbcfd81  jz 0x000070DF2CBD08A0
000070df2cbcfd87  nop [rax+rax*1], ax
000070df2cbcfd90  nop [rax+rax*1], eax
000070df2cbcfd98  mov eax, 0x410128
000070df2cbcfd9d  mov [r15+0x100], rax
000070df2cbcfda4  jmp 0x000070DF2C9FE110
000070df2cbcfda9  cmp dword ptr [r15+0x318], 0x00
000070df2cbcfdb1  jz 0x000070DF2CBCFDE0
000070df2cbcfdb7  nop [rax+rax*1], ax
000070df2cbcfdc0  nop [rax+rax*1], eax
000070df2cbcfdc8  mov eax, 0x41008C
000070df2cbcfdcd  mov [r15+0x100], rax
000070df2cbcfdd4  jmp 0x000070DF2C9FE110
000070df2cbcfdd9  int3
000070df2cbcfdda  int3
000070df2cbcfddb  nop [rax+rax*1], eax
000070df2cbcfde0  mov rax, [r15+0x40]
000070df2cbcfde4  mov r14, [r15+0x60]
000070df2cbcfde8  shl r14, 0x06
000070df2cbcfdec  lea r12, [rax+r14*1]
000070df2cbcfdf0  mov rax, [r13+r12*1]
000070df2cbcfdf5  lea r14, [r12+0x08]
000070df2cbcfdfa  mov r11, [r13+r14*1]
000070df2cbcfdff  movq xmm1, rax
000070df2cbcfe04  movq xmm15, r11
000070df2cbcfe09  movq xmm1, xmm1
000070df2cbcfe0d  movq xmm1, xmm1
000070df2cbcfe11  movaps [r15+0x120], xmm1
000070df2cbcfe19  movq xmm15, xmm15
000070df2cbcfe1e  movq xmm15, xmm15
000070df2cbcfe23  movaps [r15+0x130], xmm15
000070df2cbcfe2b  lea rax, [r12+0x10]
000070df2cbcfe30  mov r14, [r13+rax*1]
000070df2cbcfe35  lea rax, [r12+0x18]
000070df2cbcfe3a  mov r11, [r13+rax*1]
000070df2cbcfe3f  movq xmm1, r14
000070df2cbcfe44  movq xmm15, r11
000070df2cbcfe49  movq xmm1, xmm1
000070df2cbcfe4d  movq xmm1, xmm1
000070df2cbcfe51  movaps [r15+0x140], xmm1
000070df2cbcfe59  movq xmm15, xmm15
000070df2cbcfe5e  movq xmm15, xmm15
000070df2cbcfe63  movaps [r15+0x150], xmm15
000070df2cbcfe6b  lea rax, [r12+0x20]
000070df2cbcfe70  mov r14, [r13+rax*1]
000070df2cbcfe75  lea rax, [r12+0x28]
000070df2cbcfe7a  mov r11, [r13+rax*1]
000070df2cbcfe7f  movq xmm1, r14
000070df2cbcfe84  movq xmm15, r11
000070df2cbcfe89  movq xmm1, xmm1
000070df2cbcfe8d  movq xmm1, xmm1
000070df2cbcfe91  movaps [r15+0x160], xmm1
000070df2cbcfe99  movq xmm15, xmm15
000070df2cbcfe9e  movq xmm15, xmm15
000070df2cbcfea3  movaps [r15+0x170], xmm15
000070df2cbcfeab  lea rax, [r12+0x30]
000070df2cbcfeb0  mov r14, [r13+rax*1]
000070df2cbcfeb5  lea rax, [r12+0x38]
000070df2cbcfeba  mov r12, [r13+rax*1]
000070df2cbcfebf  movq xmm1, r14
000070df2cbcfec4  movq xmm15, r12
000070df2cbcfec9  movq xmm1, xmm1
000070df2cbcfecd  movq xmm1, xmm1
000070df2cbcfed1  movaps [r15+0x180], xmm1
000070df2cbcfed9  movq xmm15, xmm15
000070df2cbcfede  movq xmm15, xmm15
000070df2cbcfee3  movaps [r15+0x210], xmm15
000070df2cbcfeeb  mov rax, [r15+0x48]
000070df2cbcfeef  mov [r15+0x78], rax
000070df2cbcfef3  mov r14, [r13+rax*1]
000070df2cbcfef8  movq xmm1, r14
000070df2cbcfefd  lea r14, [rax+0x40]
000070df2cbcff01  mov r12, [r13+r14*1]
000070df2cbcff06  movq xmm15, r12
000070df2cbcff0b  lea r14, [rax+0x80]
000070df2cbcff12  mov r12, [r13+r14*1]
000070df2cbcff17  movq xmm14, r12
000070df2cbcff1c  movaps xmm13, [r15+0x120]
000070df2cbcff24  movq r14, xmm13
000070df2cbcff29  movq r12, xmm1
000070df2cbcff2e  vmovq xmm1, r14
000070df2cbcff33  vmovq xmm13, r12
000070df2cbcff38  movaps xmm12, xmm1
000070df2cbcff3c  mulsd xmm12, xmm13
000070df2cbcff41  ucomisd xmm12, xmm12
000070df2cbcff46  jp 0x000070DF2CBD03AD
000070df2cbcff4c  movq xmm12, xmm12
000070df2cbcff51  movaps xmm1, [r15+0x130]
000070df2cbcff59  movq r14, xmm1
000070df2cbcff5e  movq r12, xmm15
000070df2cbcff63  vmovq xmm1, r14
000070df2cbcff68  vmovq xmm15, r12
000070df2cbcff6d  movaps xmm13, xmm1
000070df2cbcff71  mulsd xmm13, xmm15
000070df2cbcff76  ucomisd xmm13, xmm13
000070df2cbcff7b  jp 0x000070DF2CBD03F9
000070df2cbcff81  movq xmm13, xmm13
000070df2cbcff86  movq r14, xmm12
000070df2cbcff8b  movaps xmm1, [r15+0x110]
000070df2cbcff93  movq r12, xmm1
000070df2cbcff98  vmovq xmm1, r14
000070df2cbcff9d  vmovq xmm15, r12
000070df2cbcffa2  movaps xmm12, xmm1
000070df2cbcffa6  addsd xmm12, xmm15
000070df2cbcffab  ucomisd xmm12, xmm12
000070df2cbcffb0  jp 0x000070DF2CBD0445
000070df2cbcffb6  movq xmm12, xmm12
000070df2cbcffbb  movq r14, xmm12
000070df2cbcffc0  movq r12, xmm13
000070df2cbcffc5  vmovq xmm1, r14
000070df2cbcffca  vmovq xmm15, r12
000070df2cbcffcf  movaps xmm13, xmm1
000070df2cbcffd3  addsd xmm13, xmm15
000070df2cbcffd8  ucomisd xmm13, xmm13
000070df2cbcffdd  jp 0x000070DF2CBD0491
000070df2cbcffe3  movq xmm13, xmm13
000070df2cbcffe8  movaps xmm1, [r15+0x140]
000070df2cbcfff0  movq r14, xmm1
000070df2cbcfff5  movq r12, xmm14
000070df2cbcfffa  vmovq xmm1, r14
000070df2cbcffff  vmovq xmm15, r12
000070df2cbd0004  movaps xmm14, xmm1
000070df2cbd0008  mulsd xmm14, xmm15
000070df2cbd000d  ucomisd xmm14, xmm14
000070df2cbd0012  jp 0x000070DF2CBD04DD
000070df2cbd0018  movq xmm14, xmm14
000070df2cbd001d  lea r14, [rax+0xC0]
000070df2cbd0024  mov r12, [r13+r14*1]
000070df2cbd0029  movq xmm1, r12
000070df2cbd002e  movq r14, xmm13
000070df2cbd0033  movq r12, xmm14
000070df2cbd0038  vmovq xmm15, r14
000070df2cbd003d  vmovq xmm14, r12
000070df2cbd0042  movaps xmm13, xmm15
000070df2cbd0046  addsd xmm13, xmm14
000070df2cbd004b  ucomisd xmm13, xmm13
000070df2cbd0050  jp 0x000070DF2CBD0533
000070df2cbd0056  movq xmm13, xmm13
000070df2cbd005b  movaps xmm15, [r15+0x150]
000070df2cbd0063  movq r14, xmm15
000070df2cbd0068  movq r12, xmm1
000070df2cbd006d  vmovq xmm1, r14
000070df2cbd0072  vmovq xmm15, r12
000070df2cbd0077  movaps xmm14, xmm1
000070df2cbd007b  mulsd xmm14, xmm15
000070df2cbd0080  ucomisd xmm14, xmm14
000070df2cbd0085  jp 0x000070DF2CBD057F
000070df2cbd008b  movq xmm14, xmm14
000070df2cbd0090  lea r14, [rax+0x100]
000070df2cbd0097  mov r12, [r13+r14*1]
000070df2cbd009c  movq xmm1, r12
000070df2cbd00a1  movq r14, xmm13
000070df2cbd00a6  movq r12, xmm14
000070df2cbd00ab  vmovq xmm15, r14
000070df2cbd00b0  vmovq xmm14, r12
000070df2cbd00b5  movaps xmm13, xmm15
000070df2cbd00b9  addsd xmm13, xmm14
000070df2cbd00be  ucomisd xmm13, xmm13
000070df2cbd00c3  jp 0x000070DF2CBD05D5
000070df2cbd00c9  movq xmm13, xmm13
000070df2cbd00ce  movaps xmm15, [r15+0x160]
000070df2cbd00d6  movq r14, xmm15
000070df2cbd00db  movq r12, xmm1
000070df2cbd00e0  vmovq xmm1, r14
000070df2cbd00e5  vmovq xmm15, r12
000070df2cbd00ea  movaps xmm14, xmm1
000070df2cbd00ee  mulsd xmm14, xmm15
000070df2cbd00f3  ucomisd xmm14, xmm14
000070df2cbd00f8  jp 0x000070DF2CBD0621
000070df2cbd00fe  movq xmm14, xmm14
000070df2cbd0103  lea r14, [rax+0x140]
000070df2cbd010a  mov r12, [r13+r14*1]
000070df2cbd010f  movq xmm1, r12
000070df2cbd0114  movq r14, xmm13
000070df2cbd0119  movq r12, xmm14
000070df2cbd011e  vmovq xmm15, r14
000070df2cbd0123  vmovq xmm14, r12
000070df2cbd0128  movaps xmm13, xmm15
000070df2cbd012c  addsd xmm13, xmm14
000070df2cbd0131  ucomisd xmm13, xmm13
000070df2cbd0136  jp 0x000070DF2CBD0677
000070df2cbd013c  movq xmm13, xmm13
000070df2cbd0141  movaps xmm15, [r15+0x170]
000070df2cbd0149  movq r14, xmm15
000070df2cbd014e  movq r12, xmm1
000070df2cbd0153  vmovq xmm1, r14
000070df2cbd0158  vmovq xmm15, r12
000070df2cbd015d  movaps xmm14, xmm1
000070df2cbd0161  mulsd xmm14, xmm15
000070df2cbd0166  ucomisd xmm14, xmm14
000070df2cbd016b  jp 0x000070DF2CBD06C3
000070df2cbd0171  movq xmm14, xmm14
000070df2cbd0176  lea r14, [rax+0x180]
000070df2cbd017d  mov r12, [r13+r14*1]
000070df2cbd0182  movq xmm1, r12
000070df2cbd0187  movq r14, xmm13
000070df2cbd018c  movq r12, xmm14
000070df2cbd0191  vmovq xmm15, r14
000070df2cbd0196  vmovq xmm14, r12
000070df2cbd019b  movaps xmm13, xmm15
000070df2cbd019f  addsd xmm13, xmm14
000070df2cbd01a4  ucomisd xmm13, xmm13
000070df2cbd01a9  jp 0x000070DF2CBD0719
000070df2cbd01af  movq xmm13, xmm13
000070df2cbd01b4  movaps xmm15, [r15+0x180]
000070df2cbd01bc  movq r14, xmm15
000070df2cbd01c1  movq r12, xmm1
000070df2cbd01c6  vmovq xmm1, r14
000070df2cbd01cb  vmovq xmm15, r12
000070df2cbd01d0  movaps xmm14, xmm1
000070df2cbd01d4  mulsd xmm14, xmm15
000070df2cbd01d9  ucomisd xmm14, xmm14
000070df2cbd01de  jp 0x000070DF2CBD0765
000070df2cbd01e4  movq xmm14, xmm14
000070df2cbd01e9  lea r14, [rax+0x1C0]
000070df2cbd01f0  mov rax, [r13+r14*1]
000070df2cbd01f5  movq xmm1, rax
000070df2cbd01fa  movaps [r15+0x240], xmm1
000070df2cbd0202  movq rax, xmm13
000070df2cbd0207  movq r14, xmm14
000070df2cbd020c  vmovq xmm15, rax
000070df2cbd0211  vmovq xmm14, r14
000070df2cbd0216  movaps xmm13, xmm15
000070df2cbd021a  addsd xmm13, xmm14
000070df2cbd021f  ucomisd xmm13, xmm13
000070df2cbd0224  jp 0x000070DF2CBD07BB
000070df2cbd022a  movq xmm13, xmm13
000070df2cbd022f  movaps xmm15, [r15+0x210]
000070df2cbd0237  movq rax, xmm15
000070df2cbd023c  movq r14, xmm1
000070df2cbd0241  vmovq xmm1, rax
000070df2cbd0246  vmovq xmm15, r14
000070df2cbd024b  movaps xmm14, xmm1
000070df2cbd024f  mulsd xmm14, xmm15
000070df2cbd0254  ucomisd xmm14, xmm14
000070df2cbd0259  jp 0x000070DF2CBD0803
000070df2cbd025f  movq xmm14, xmm14
000070df2cbd0264  movaps [r15+0x230], xmm14
000070df2cbd026c  movq rax, xmm13
000070df2cbd0271  movq r14, xmm14
000070df2cbd0276  vmovq xmm1, rax
000070df2cbd027b  vmovq xmm15, r14
000070df2cbd0280  movaps xmm14, xmm1
000070df2cbd0284  addsd xmm14, xmm15
000070df2cbd0289  ucomisd xmm14, xmm14
000070df2cbd028e  jp 0x000070DF2CBD084B
000070df2cbd0294  movq xmm14, xmm14
000070df2cbd0299  movaps [r15+0x220], xmm14
000070df2cbd02a1  mov rax, [r15+0x68]
000070df2cbd02a5  movq r14, xmm14
000070df2cbd02aa  mov [r13+rax*1], r14
000070df2cbd02af  mov qword ptr [r15+0x70], 0x08
000070df2cbd02b7  xor eax, eax
000070df2cbd02b9  mov r14d, 0x08
000070df2cbd02bf  mov r12d, 0x40
000070df2cbd02c5  cmp r14, r12
000070df2cbd02c8  cmc
000070df2cbd02c9  lahf
000070df2cbd02ca  seto al
000070df2cbd02cd  mov [r15+0x108], eax
000070df2cbd02d4  mov eax, [r15+0x108]
000070df2cbd02db  sahf
000070df2cbd02dc  jnz 0x000070DF2CBD030E
000070df2cbd02de  cmp dword ptr [r15+0x318], 0x00
000070df2cbd02e6  jz 0x000070DF2CBCFD40
000070df2cbd02ec  nop [rax+rax*1], ax
000070df2cbd02f5  nop [rax+rax*1], eax
000070df2cbd02fd  mov eax, 0x410118
000070df2cbd0302  mov [r15+0x100], rax
000070df2cbd0309  jmp 0x000070DF2C9FE110
000070df2cbd030e  cmp dword ptr [r15+0x318], 0x00
000070df2cbd0316  jz 0x000070DF2CBCF3F0
000070df2cbd031c  nop [rax+rax*1], ax
000070df2cbd0325  nop [rax+rax*1], eax
000070df2cbd032d  mov eax, 0x4100A4
000070df2cbd0332  mov [r15+0x100], rax
000070df2cbd0339  jmp 0x000070DF2C9FE110
000070df2cbd033e  int3
000070df2cbd033f  call 0x000070DF2CAB47C0
000070df2cbd0344  jmp 0x000070DF2CBCFDF5
000070df2cbd0349  call 0x000070DF2CAE1570
000070df2cbd034e  jmp 0x000070DF2CBCFDFF
000070df2cbd0353  call 0x000070DF2CA0DC20
000070df2cbd0358  jmp 0x000070DF2CBCFE35
000070df2cbd035d  call 0x000070DF2CA0A4B0
000070df2cbd0362  jmp 0x000070DF2CBCFE3F
000070df2cbd0367  call 0x000070DF2CA0DC20
000070df2cbd036c  jmp 0x000070DF2CBCFE75
000070df2cbd0371  call 0x000070DF2CA0A4B0
000070df2cbd0376  jmp 0x000070DF2CBCFE7F
000070df2cbd037b  call 0x000070DF2CA0DC20
000070df2cbd0380  jmp 0x000070DF2CBCFEB5
000070df2cbd0385  call 0x000070DF2CA0B720
000070df2cbd038a  jmp 0x000070DF2CBCFEBF
000070df2cbd038f  call 0x000070DF2CA0DC20
000070df2cbd0394  jmp 0x000070DF2CBCFEF8
000070df2cbd0399  call 0x000070DF2CAE27E0
000070df2cbd039e  jmp 0x000070DF2CBCFF06
000070df2cbd03a3  call 0x000070DF2CAE27E0
000070df2cbd03a8  jmp 0x000070DF2CBCFF17
000070df2cbd03ad  ucomisd xmm1, xmm13
000070df2cbd03b2  jp 0x000070DF2CBD03C1
000070df2cbd03b4  movaps xmm12, [0x000070DF2C7FE030]
000070df2cbd03bc  jmp 0x000070DF2CBCFF4C
000070df2cbd03c1  vxorps xmm0, xmm1, xmm13
000070df2cbd03c6  pextrw r14d, xmm0, 0x03
000070df2cbd03cc  and r14d, 0x7FF8
000070df2cbd03d3  cmp r14d, 0x08
000070df2cbd03d7  jnz 0x000070DF2CBCFF4C
000070df2cbd03dd  movq r14, xmm13
000070df2cbd03e2  shl r14, 0x0D
000070df2cbd03e6  jbe 0x000070DF2CBCFF4C
000070df2cbd03ec  vorps xmm12, xmm13, [0x000070DF2C7FE040]
000070df2cbd03f4  jmp 0x000070DF2CBCFF4C
000070df2cbd03f9  ucomisd xmm1, xmm15
000070df2cbd03fe  jp 0x000070DF2CBD040D
000070df2cbd0400  movaps xmm13, [0x000070DF2C7FE030]
000070df2cbd0408  jmp 0x000070DF2CBCFF81
000070df2cbd040d  vxorps xmm0, xmm1, xmm15
000070df2cbd0412  pextrw r14d, xmm0, 0x03
000070df2cbd0418  and r14d, 0x7FF8
000070df2cbd041f  cmp r14d, 0x08
000070df2cbd0423  jnz 0x000070DF2CBCFF81
000070df2cbd0429  movq r14, xmm15
000070df2cbd042e  shl r14, 0x0D
000070df2cbd0432  jbe 0x000070DF2CBCFF81
000070df2cbd0438  vorps xmm13, xmm15, [0x000070DF2C7FE040]
000070df2cbd0440  jmp 0x000070DF2CBCFF81
000070df2cbd0445  ucomisd xmm1, xmm15
000070df2cbd044a  jp 0x000070DF2CBD0459
000070df2cbd044c  movaps xmm12, [0x000070DF2C7FE030]
000070df2cbd0454  jmp 0x000070DF2CBCFFB6
000070df2cbd0459  vxorps xmm0, xmm1, xmm15
000070df2cbd045e  pextrw r14d, xmm0, 0x03
000070df2cbd0464  and r14d, 0x7FF8
000070df2cbd046b  cmp r14d, 0x08
000070df2cbd046f  jnz 0x000070DF2CBCFFB6
000070df2cbd0475  movq r14, xmm15
000070df2cbd047a  shl r14, 0x0D
000070df2cbd047e  jbe 0x000070DF2CBCFFB6
000070df2cbd0484  vorps xmm12, xmm15, [0x000070DF2C7FE040]
000070df2cbd048c  jmp 0x000070DF2CBCFFB6
000070df2cbd0491  ucomisd xmm1, xmm15
000070df2cbd0496  jp 0x000070DF2CBD04A5
000070df2cbd0498  movaps xmm13, [0x000070DF2C7FE030]
000070df2cbd04a0  jmp 0x000070DF2CBCFFE3
000070df2cbd04a5  vxorps xmm0, xmm1, xmm15
000070df2cbd04aa  pextrw r14d, xmm0, 0x03
000070df2cbd04b0  and r14d, 0x7FF8
000070df2cbd04b7  cmp r14d, 0x08
000070df2cbd04bb  jnz 0x000070DF2CBCFFE3
000070df2cbd04c1  movq r14, xmm15
000070df2cbd04c6  shl r14, 0x0D
000070df2cbd04ca  jbe 0x000070DF2CBCFFE3
000070df2cbd04d0  vorps xmm13, xmm15, [0x000070DF2C7FE040]
000070df2cbd04d8  jmp 0x000070DF2CBCFFE3
000070df2cbd04dd  ucomisd xmm1, xmm15
000070df2cbd04e2  jp 0x000070DF2CBD04F1
000070df2cbd04e4  movaps xmm14, [0x000070DF2C7FE030]
000070df2cbd04ec  jmp 0x000070DF2CBD0018
000070df2cbd04f1  vxorps xmm0, xmm1, xmm15
000070df2cbd04f6  pextrw r14d, xmm0, 0x03
000070df2cbd04fc  and r14d, 0x7FF8
000070df2cbd0503  cmp r14d, 0x08
000070df2cbd0507  jnz 0x000070DF2CBD0018
000070df2cbd050d  movq r14, xmm15
000070df2cbd0512  shl r14, 0x0D
000070df2cbd0516  jbe 0x000070DF2CBD0018
000070df2cbd051c  vorps xmm14, xmm15, [0x000070DF2C7FE040]
000070df2cbd0524  jmp 0x000070DF2CBD0018
000070df2cbd0529  call 0x000070DF2CAE27E0
000070df2cbd052e  jmp 0x000070DF2CBD0029
000070df2cbd0533  ucomisd xmm15, xmm14
000070df2cbd0538  jp 0x000070DF2CBD0547
000070df2cbd053a  movaps xmm13, [0x000070DF2C7FE030]
000070df2cbd0542  jmp 0x000070DF2CBD0056
000070df2cbd0547  vxorps xmm0, xmm15, xmm14
000070df2cbd054c  pextrw r14d, xmm0, 0x03
000070df2cbd0552  and r14d, 0x7FF8
000070df2cbd0559  cmp r14d, 0x08
000070df2cbd055d  jnz 0x000070DF2CBD0056
000070df2cbd0563  movq r14, xmm14
000070df2cbd0568  shl r14, 0x0D
000070df2cbd056c  jbe 0x000070DF2CBD0056
000070df2cbd0572  vorps xmm13, xmm14, [0x000070DF2C7FE040]
000070df2cbd057a  jmp 0x000070DF2CBD0056
000070df2cbd057f  ucomisd xmm1, xmm15
000070df2cbd0584  jp 0x000070DF2CBD0593
000070df2cbd0586  movaps xmm14, [0x000070DF2C7FE030]
000070df2cbd058e  jmp 0x000070DF2CBD008B
000070df2cbd0593  vxorps xmm0, xmm1, xmm15
000070df2cbd0598  pextrw r14d, xmm0, 0x03
000070df2cbd059e  and r14d, 0x7FF8
000070df2cbd05a5  cmp r14d, 0x08
000070df2cbd05a9  jnz 0x000070DF2CBD008B
000070df2cbd05af  movq r14, xmm15
000070df2cbd05b4  shl r14, 0x0D
000070df2cbd05b8  jbe 0x000070DF2CBD008B
000070df2cbd05be  vorps xmm14, xmm15, [0x000070DF2C7FE040]
000070df2cbd05c6  jmp 0x000070DF2CBD008B
000070df2cbd05cb  call 0x000070DF2CAE27E0
000070df2cbd05d0  jmp 0x000070DF2CBD009C
000070df2cbd05d5  ucomisd xmm15, xmm14
000070df2cbd05da  jp 0x000070DF2CBD05E9
000070df2cbd05dc  movaps xmm13, [0x000070DF2C7FE030]
000070df2cbd05e4  jmp 0x000070DF2CBD00C9
000070df2cbd05e9  vxorps xmm0, xmm15, xmm14
000070df2cbd05ee  pextrw r14d, xmm0, 0x03
000070df2cbd05f4  and r14d, 0x7FF8
000070df2cbd05fb  cmp r14d, 0x08
000070df2cbd05ff  jnz 0x000070DF2CBD00C9
000070df2cbd0605  movq r14, xmm14
000070df2cbd060a  shl r14, 0x0D
000070df2cbd060e  jbe 0x000070DF2CBD00C9
000070df2cbd0614  vorps xmm13, xmm14, [0x000070DF2C7FE040]
000070df2cbd061c  jmp 0x000070DF2CBD00C9
000070df2cbd0621  ucomisd xmm1, xmm15
000070df2cbd0626  jp 0x000070DF2CBD0635
000070df2cbd0628  movaps xmm14, [0x000070DF2C7FE030]
000070df2cbd0630  jmp 0x000070DF2CBD00FE
000070df2cbd0635  vxorps xmm0, xmm1, xmm15
000070df2cbd063a  pextrw r14d, xmm0, 0x03
000070df2cbd0640  and r14d, 0x7FF8
000070df2cbd0647  cmp r14d, 0x08
000070df2cbd064b  jnz 0x000070DF2CBD00FE
000070df2cbd0651  movq r14, xmm15
000070df2cbd0656  shl r14, 0x0D
000070df2cbd065a  jbe 0x000070DF2CBD00FE
000070df2cbd0660  vorps xmm14, xmm15, [0x000070DF2C7FE040]
000070df2cbd0668  jmp 0x000070DF2CBD00FE
000070df2cbd066d  call 0x000070DF2CAE27E0
000070df2cbd0672  jmp 0x000070DF2CBD010F
000070df2cbd0677  ucomisd xmm15, xmm14
000070df2cbd067c  jp 0x000070DF2CBD068B
000070df2cbd067e  movaps xmm13, [0x000070DF2C7FE030]
000070df2cbd0686  jmp 0x000070DF2CBD013C
000070df2cbd068b  vxorps xmm0, xmm15, xmm14
000070df2cbd0690  pextrw r14d, xmm0, 0x03
000070df2cbd0696  and r14d, 0x7FF8
000070df2cbd069d  cmp r14d, 0x08
000070df2cbd06a1  jnz 0x000070DF2CBD013C
000070df2cbd06a7  movq r14, xmm14
000070df2cbd06ac  shl r14, 0x0D
000070df2cbd06b0  jbe 0x000070DF2CBD013C
000070df2cbd06b6  vorps xmm13, xmm14, [0x000070DF2C7FE040]
000070df2cbd06be  jmp 0x000070DF2CBD013C
000070df2cbd06c3  ucomisd xmm1, xmm15
000070df2cbd06c8  jp 0x000070DF2CBD06D7
000070df2cbd06ca  movaps xmm14, [0x000070DF2C7FE030]
000070df2cbd06d2  jmp 0x000070DF2CBD0171
000070df2cbd06d7  vxorps xmm0, xmm1, xmm15
000070df2cbd06dc  pextrw r14d, xmm0, 0x03
000070df2cbd06e2  and r14d, 0x7FF8
000070df2cbd06e9  cmp r14d, 0x08
000070df2cbd06ed  jnz 0x000070DF2CBD0171
000070df2cbd06f3  movq r14, xmm15
000070df2cbd06f8  shl r14, 0x0D
000070df2cbd06fc  jbe 0x000070DF2CBD0171
000070df2cbd0702  vorps xmm14, xmm15, [0x000070DF2C7FE040]
000070df2cbd070a  jmp 0x000070DF2CBD0171
000070df2cbd070f  call 0x000070DF2CAE27E0
000070df2cbd0714  jmp 0x000070DF2CBD0182
000070df2cbd0719  ucomisd xmm15, xmm14
000070df2cbd071e  jp 0x000070DF2CBD072D
000070df2cbd0720  movaps xmm13, [0x000070DF2C7FE030]
000070df2cbd0728  jmp 0x000070DF2CBD01AF
000070df2cbd072d  vxorps xmm0, xmm15, xmm14
000070df2cbd0732  pextrw r14d, xmm0, 0x03
000070df2cbd0738  and r14d, 0x7FF8
000070df2cbd073f  cmp r14d, 0x08
000070df2cbd0743  jnz 0x000070DF2CBD01AF
000070df2cbd0749  movq r14, xmm14
000070df2cbd074e  shl r14, 0x0D
000070df2cbd0752  jbe 0x000070DF2CBD01AF
000070df2cbd0758  vorps xmm13, xmm14, [0x000070DF2C7FE040]
000070df2cbd0760  jmp 0x000070DF2CBD01AF
000070df2cbd0765  ucomisd xmm1, xmm15
000070df2cbd076a  jp 0x000070DF2CBD0779
000070df2cbd076c  movaps xmm14, [0x000070DF2C7FE030]
000070df2cbd0774  jmp 0x000070DF2CBD01E4
000070df2cbd0779  vxorps xmm0, xmm1, xmm15
000070df2cbd077e  pextrw r14d, xmm0, 0x03
000070df2cbd0784  and r14d, 0x7FF8
000070df2cbd078b  cmp r14d, 0x08
000070df2cbd078f  jnz 0x000070DF2CBD01E4
000070df2cbd0795  movq r14, xmm15
000070df2cbd079a  shl r14, 0x0D
000070df2cbd079e  jbe 0x000070DF2CBD01E4
000070df2cbd07a4  vorps xmm14, xmm15, [0x000070DF2C7FE040]
000070df2cbd07ac  jmp 0x000070DF2CBD01E4
000070df2cbd07b1  call 0x000070DF2CAD59C0
000070df2cbd07b6  jmp 0x000070DF2CBD01F5
000070df2cbd07bb  ucomisd xmm15, xmm14
000070df2cbd07c0  jp 0x000070DF2CBD07CF
000070df2cbd07c2  movaps xmm13, [0x000070DF2C7FE030]
000070df2cbd07ca  jmp 0x000070DF2CBD022A
000070df2cbd07cf  vxorps xmm0, xmm15, xmm14
000070df2cbd07d4  pextrw eax, xmm0, 0x03
000070df2cbd07d9  and eax, 0x7FF8
000070df2cbd07de  cmp eax, 0x08
000070df2cbd07e1  jnz 0x000070DF2CBD022A
000070df2cbd07e7  movq rax, xmm14
000070df2cbd07ec  shl rax, 0x0D
000070df2cbd07f0  jbe 0x000070DF2CBD022A
000070df2cbd07f6  vorps xmm13, xmm14, [0x000070DF2C7FE040]
000070df2cbd07fe  jmp 0x000070DF2CBD022A
000070df2cbd0803  ucomisd xmm1, xmm15
000070df2cbd0808  jp 0x000070DF2CBD0817
000070df2cbd080a  movaps xmm14, [0x000070DF2C7FE030]
000070df2cbd0812  jmp 0x000070DF2CBD025F
000070df2cbd0817  vxorps xmm0, xmm1, xmm15
000070df2cbd081c  pextrw eax, xmm0, 0x03
000070df2cbd0821  and eax, 0x7FF8
000070df2cbd0826  cmp eax, 0x08
000070df2cbd0829  jnz 0x000070DF2CBD025F
000070df2cbd082f  movq rax, xmm15
000070df2cbd0834  shl rax, 0x0D
000070df2cbd0838  jbe 0x000070DF2CBD025F
000070df2cbd083e  vorps xmm14, xmm15, [0x000070DF2C7FE040]
000070df2cbd0846  jmp 0x000070DF2CBD025F
000070df2cbd084b  ucomisd xmm1, xmm15
000070df2cbd0850  jp 0x000070DF2CBD085F
000070df2cbd0852  movaps xmm14, [0x000070DF2C7FE030]
000070df2cbd085a  jmp 0x000070DF2CBD0294
000070df2cbd085f  vxorps xmm0, xmm1, xmm15
000070df2cbd0864  pextrw eax, xmm0, 0x03
000070df2cbd0869  and eax, 0x7FF8
000070df2cbd086e  cmp eax, 0x08
000070df2cbd0871  jnz 0x000070DF2CBD0294
000070df2cbd0877  movq rax, xmm15
000070df2cbd087c  shl rax, 0x0D
000070df2cbd0880  jbe 0x000070DF2CBD0294
000070df2cbd0886  vorps xmm14, xmm15, [0x000070DF2C7FE040]
000070df2cbd088e  jmp 0x000070DF2CBD0294
000070df2cbd0893  call 0x000070DF2CA0E120
000070df2cbd0898  jmp 0x000070DF2CBD02AF
000070df2cbd089d  int3
000070df2cbd089e  nop
000070df2cbd08a0  mov eax, [r15+0x58]
000070df2cbd08a4  lea r14d, [eax+0x01]
000070df2cbd08a9  mov [rsp+0x10], r14d
000070df2cbd08ae  mov r14d, r14d
000070df2cbd08b1  mov [r15+0x58], r14
000070df2cbd08b5  xor eax, eax
000070df2cbd08b7  mov r14d, [rsp+0x10]
000070df2cbd08bc  cmp r14d, 0x1F4
000070df2cbd08c3  cmc
000070df2cbd08c4  lahf
000070df2cbd08c5  seto al
000070df2cbd08c8  mov [r15+0x108], eax
000070df2cbd08cf  mov eax, [r15+0x108]
000070df2cbd08d6  sahf
000070df2cbd08d7  jnz 0x000070DF2CBD0909
000070df2cbd08d9  cmp dword ptr [r15+0x318], 0x00
000070df2cbd08e1  jz 0x000070DF2CBD1410
000070df2cbd08e7  nop [rax+rax*1], ax
000070df2cbd08f0  nop [rax+rax*1], eax
000070df2cbd08f8  mov eax, 0x410134
000070df2cbd08fd  mov [r15+0x100], rax
000070df2cbd0904  jmp 0x000070DF2C9FE110
000070df2cbd0909  cmp dword ptr [r15+0x318], 0x00
000070df2cbd0911  jz 0x000070DF2CBD0940
000070df2cbd0917  nop [rax+rax*1], ax
000070df2cbd0920  nop [rax+rax*1], eax
000070df2cbd0928  mov eax, 0x410084
000070df2cbd092d  mov [r15+0x100], rax
000070df2cbd0934  jmp 0x000070DF2C9FE110
000070df2cbd0939  int3
000070df2cbd093a  int3
000070df2cbd093b  nop [rax+rax*1], eax
000070df2cbd0940  mov qword ptr [r15+0x60], 0x00
000070df2cbd0948  mov rax, [r15+0x50]
000070df2cbd094c  mov [r15+0x68], rax
000070df2cbd0950  mov r14, [r15+0x40]
000070df2cbd0954  mov r12, [r13+r14*1]
000070df2cbd0959  lea r11, [r14+0x08]
000070df2cbd095d  mov r10, [r13+r11*1]
000070df2cbd0962  movq xmm1, r12
000070df2cbd0967  movq xmm15, r10
000070df2cbd096c  movq xmm1, xmm1
000070df2cbd0970  movq xmm1, xmm1
000070df2cbd0974  movaps [r15+0x120], xmm1
000070df2cbd097c  movq xmm15, xmm15
000070df2cbd0981  movq xmm15, xmm15
000070df2cbd0986  movaps [r15+0x130], xmm15
000070df2cbd098e  lea r12, [r14+0x10]
000070df2cbd0992  mov r11, [r13+r12*1]
000070df2cbd0997  lea r12, [r14+0x18]
000070df2cbd099b  mov r10, [r13+r12*1]
000070df2cbd09a0  movq xmm1, r11
000070df2cbd09a5  movq xmm15, r10
000070df2cbd09aa  movq xmm1, xmm1
000070df2cbd09ae  movq xmm1, xmm1
000070df2cbd09b2  movaps [r15+0x140], xmm1
000070df2cbd09ba  movq xmm15, xmm15
000070df2cbd09bf  movq xmm15, xmm15
000070df2cbd09c4  movaps [r15+0x150], xmm15
000070df2cbd09cc  lea r12, [r14+0x20]
000070df2cbd09d0  mov r11, [r13+r12*1]
000070df2cbd09d5  lea r12, [r14+0x28]
000070df2cbd09d9  mov r10, [r13+r12*1]
000070df2cbd09de  movq xmm1, r11
000070df2cbd09e3  movq xmm15, r10
000070df2cbd09e8  movq xmm1, xmm1
000070df2cbd09ec  movq xmm1, xmm1
000070df2cbd09f0  movaps [r15+0x160], xmm1
000070df2cbd09f8  movq xmm15, xmm15
000070df2cbd09fd  movq xmm15, xmm15
000070df2cbd0a02  movaps [r15+0x170], xmm15
000070df2cbd0a0a  lea r12, [r14+0x30]
000070df2cbd0a0e  mov r11, [r13+r12*1]
000070df2cbd0a13  lea r12, [r14+0x38]
000070df2cbd0a17  mov r14, [r13+r12*1]
000070df2cbd0a1c  movq xmm1, r11
000070df2cbd0a21  movq xmm15, r14
000070df2cbd0a26  movq xmm1, xmm1
000070df2cbd0a2a  movq xmm1, xmm1
000070df2cbd0a2e  movaps [r15+0x180], xmm1
000070df2cbd0a36  movq xmm15, xmm15
000070df2cbd0a3b  movq xmm15, xmm15
000070df2cbd0a40  movaps [r15+0x210], xmm15
000070df2cbd0a48  mov r14, [r15+0x48]
000070df2cbd0a4c  mov [r15+0x78], r14
000070df2cbd0a50  mov r12, [r13+r14*1]
000070df2cbd0a55  movq xmm1, r12
000070df2cbd0a5a  lea r12, [r14+0x40]
000070df2cbd0a5e  mov r11, [r13+r12*1]
000070df2cbd0a63  movq xmm15, r11
000070df2cbd0a68  lea r12, [r14+0x80]
000070df2cbd0a6f  mov r11, [r13+r12*1]
000070df2cbd0a74  movq xmm14, r11
000070df2cbd0a79  movaps xmm13, [r15+0x120]
000070df2cbd0a81  movq r12, xmm13
000070df2cbd0a86  movq r11, xmm1
000070df2cbd0a8b  vmovq xmm1, r12
000070df2cbd0a90  vmovq xmm13, r11
000070df2cbd0a95  movaps xmm12, xmm1
000070df2cbd0a99  mulsd xmm12, xmm13
000070df2cbd0a9e  ucomisd xmm12, xmm12
000070df2cbd0aa3  jp 0x000070DF2CBD0F06
000070df2cbd0aa9  movq xmm12, xmm12
000070df2cbd0aae  movaps xmm1, [r15+0x130]
000070df2cbd0ab6  movq r12, xmm1
000070df2cbd0abb  movq r11, xmm15
000070df2cbd0ac0  vmovq xmm1, r12
000070df2cbd0ac5  vmovq xmm15, r11
000070df2cbd0aca  movaps xmm13, xmm1
000070df2cbd0ace  mulsd xmm13, xmm15
000070df2cbd0ad3  ucomisd xmm13, xmm13
000070df2cbd0ad8  jp 0x000070DF2CBD0F52
000070df2cbd0ade  movq xmm13, xmm13
000070df2cbd0ae3  movq r12, xmm12
000070df2cbd0ae8  movaps xmm1, [r15+0x110]
000070df2cbd0af0  movq r11, xmm1
000070df2cbd0af5  vmovq xmm1, r12
000070df2cbd0afa  vmovq xmm15, r11
000070df2cbd0aff  movaps xmm12, xmm1
000070df2cbd0b03  addsd xmm12, xmm15
000070df2cbd0b08  ucomisd xmm12, xmm12
000070df2cbd0b0d  jp 0x000070DF2CBD0F9E
000070df2cbd0b13  movq xmm12, xmm12
000070df2cbd0b18  movq r12, xmm12
000070df2cbd0b1d  movq r11, xmm13
000070df2cbd0b22  vmovq xmm1, r12
000070df2cbd0b27  vmovq xmm15, r11
000070df2cbd0b2c  movaps xmm13, xmm1
000070df2cbd0b30  addsd xmm13, xmm15
000070df2cbd0b35  ucomisd xmm13, xmm13
000070df2cbd0b3a  jp 0x000070DF2CBD0FEA
000070df2cbd0b40  movq xmm13, xmm13
000070df2cbd0b45  movaps xmm1, [r15+0x140]
000070df2cbd0b4d  movq r12, xmm1
000070df2cbd0b52  movq r11, xmm14
000070df2cbd0b57  vmovq xmm1, r12
000070df2cbd0b5c  vmovq xmm15, r11
000070df2cbd0b61  movaps xmm14, xmm1
000070df2cbd0b65  mulsd xmm14, xmm15
000070df2cbd0b6a  ucomisd xmm14, xmm14
000070df2cbd0b6f  jp 0x000070DF2CBD1036
000070df2cbd0b75  movq xmm14, xmm14
000070df2cbd0b7a  lea r12, [r14+0xC0]
000070df2cbd0b81  mov r11, [r13+r12*1]
000070df2cbd0b86  movq xmm1, r11
000070df2cbd0b8b  movq r12, xmm13
000070df2cbd0b90  movq r11, xmm14
000070df2cbd0b95  vmovq xmm15, r12
000070df2cbd0b9a  vmovq xmm14, r11
000070df2cbd0b9f  movaps xmm13, xmm15
000070df2cbd0ba3  addsd xmm13, xmm14
000070df2cbd0ba8  ucomisd xmm13, xmm13
000070df2cbd0bad  jp 0x000070DF2CBD108C
000070df2cbd0bb3  movq xmm13, xmm13
000070df2cbd0bb8  movaps xmm15, [r15+0x150]
000070df2cbd0bc0  movq r12, xmm15
000070df2cbd0bc5  movq r11, xmm1
000070df2cbd0bca  vmovq xmm1, r12
000070df2cbd0bcf  vmovq xmm15, r11
000070df2cbd0bd4  movaps xmm14, xmm1
000070df2cbd0bd8  mulsd xmm14, xmm15
000070df2cbd0bdd  ucomisd xmm14, xmm14
000070df2cbd0be2  jp 0x000070DF2CBD10D8
000070df2cbd0be8  movq xmm14, xmm14
000070df2cbd0bed  lea r12, [r14+0x100]
000070df2cbd0bf4  mov r11, [r13+r12*1]
000070df2cbd0bf9  movq xmm1, r11
000070df2cbd0bfe  movq r12, xmm13
000070df2cbd0c03  movq r11, xmm14
000070df2cbd0c08  vmovq xmm15, r12
000070df2cbd0c0d  vmovq xmm14, r11
000070df2cbd0c12  movaps xmm13, xmm15
000070df2cbd0c16  addsd xmm13, xmm14
000070df2cbd0c1b  ucomisd xmm13, xmm13
000070df2cbd0c20  jp 0x000070DF2CBD112E
000070df2cbd0c26  movq xmm13, xmm13
000070df2cbd0c2b  movaps xmm15, [r15+0x160]
000070df2cbd0c33  movq r12, xmm15
000070df2cbd0c38  movq r11, xmm1
000070df2cbd0c3d  vmovq xmm1, r12
000070df2cbd0c42  vmovq xmm15, r11
000070df2cbd0c47  movaps xmm14, xmm1
000070df2cbd0c4b  mulsd xmm14, xmm15
000070df2cbd0c50  ucomisd xmm14, xmm14
000070df2cbd0c55  jp 0x000070DF2CBD117A
000070df2cbd0c5b  movq xmm14, xmm14
000070df2cbd0c60  lea r12, [r14+0x140]
000070df2cbd0c67  mov r11, [r13+r12*1]
000070df2cbd0c6c  movq xmm1, r11
000070df2cbd0c71  movq r12, xmm13
000070df2cbd0c76  movq r11, xmm14
000070df2cbd0c7b  vmovq xmm15, r12
000070df2cbd0c80  vmovq xmm14, r11
000070df2cbd0c85  movaps xmm13, xmm15
000070df2cbd0c89  addsd xmm13, xmm14
000070df2cbd0c8e  ucomisd xmm13, xmm13
000070df2cbd0c93  jp 0x000070DF2CBD11D0
000070df2cbd0c99  movq xmm13, xmm13
000070df2cbd0c9e  movaps xmm15, [r15+0x170]
000070df2cbd0ca6  movq r12, xmm15
000070df2cbd0cab  movq r11, xmm1
000070df2cbd0cb0  vmovq xmm1, r12
000070df2cbd0cb5  vmovq xmm15, r11
000070df2cbd0cba  movaps xmm14, xmm1
000070df2cbd0cbe  mulsd xmm14, xmm15
000070df2cbd0cc3  ucomisd xmm14, xmm14
000070df2cbd0cc8  jp 0x000070DF2CBD121C
000070df2cbd0cce  movq xmm14, xmm14
000070df2cbd0cd3  lea r12, [r14+0x180]
000070df2cbd0cda  mov r11, [r13+r12*1]
000070df2cbd0cdf  movq xmm1, r11
000070df2cbd0ce4  movq r12, xmm13
000070df2cbd0ce9  movq r11, xmm14
000070df2cbd0cee  vmovq xmm15, r12
000070df2cbd0cf3  vmovq xmm14, r11
000070df2cbd0cf8  movaps xmm13, xmm15
000070df2cbd0cfc  addsd xmm13, xmm14
000070df2cbd0d01  ucomisd xmm13, xmm13
000070df2cbd0d06  jp 0x000070DF2CBD1272
000070df2cbd0d0c  movq xmm13, xmm13
000070df2cbd0d11  movaps xmm15, [r15+0x180]
000070df2cbd0d19  movq r12, xmm15
000070df2cbd0d1e  movq r11, xmm1
000070df2cbd0d23  vmovq xmm1, r12
000070df2cbd0d28  vmovq xmm15, r11
000070df2cbd0d2d  movaps xmm14, xmm1
000070df2cbd0d31  mulsd xmm14, xmm15
000070df2cbd0d36  ucomisd xmm14, xmm14
000070df2cbd0d3b  jp 0x000070DF2CBD12BE
000070df2cbd0d41  movq xmm14, xmm14
000070df2cbd0d46  lea r12, [r14+0x1C0]
000070df2cbd0d4d  mov r14, [r13+r12*1]
000070df2cbd0d52  movq xmm1, r14
000070df2cbd0d57  movaps [r15+0x240], xmm1
000070df2cbd0d5f  movq r14, xmm13
000070df2cbd0d64  movq r12, xmm14
000070df2cbd0d69  vmovq xmm15, r14
000070df2cbd0d6e  vmovq xmm14, r12
000070df2cbd0d73  movaps xmm13, xmm15
000070df2cbd0d77  addsd xmm13, xmm14
000070df2cbd0d7c  ucomisd xmm13, xmm13
000070df2cbd0d81  jp 0x000070DF2CBD1314
000070df2cbd0d87  movq xmm13, xmm13
000070df2cbd0d8c  movaps xmm15, [r15+0x210]
000070df2cbd0d94  movq r14, xmm15
000070df2cbd0d99  movq r12, xmm1
000070df2cbd0d9e  vmovq xmm1, r14
000070df2cbd0da3  vmovq xmm15, r12
000070df2cbd0da8  movaps xmm14, xmm1
000070df2cbd0dac  mulsd xmm14, xmm15
000070df2cbd0db1  ucomisd xmm14, xmm14
000070df2cbd0db6  jp 0x000070DF2CBD1360
000070df2cbd0dbc  movq xmm14, xmm14
000070df2cbd0dc1  movaps [r15+0x230], xmm14
000070df2cbd0dc9  movq r14, xmm13
000070df2cbd0dce  movq r12, xmm14
000070df2cbd0dd3  vmovq xmm1, r14
000070df2cbd0dd8  vmovq xmm15, r12
000070df2cbd0ddd  movaps xmm14, xmm1
000070df2cbd0de1  addsd xmm14, xmm15
000070df2cbd0de6  ucomisd xmm14, xmm14
000070df2cbd0deb  jp 0x000070DF2CBD13AC
000070df2cbd0df1  movq xmm14, xmm14
000070df2cbd0df6  movaps [r15+0x220], xmm14
000070df2cbd0dfe  movq r14, xmm14
000070df2cbd0e03  mov [r13+rax*1], r14
000070df2cbd0e08  mov qword ptr [r15+0x70], 0x08
000070df2cbd0e10  xor eax, eax
000070df2cbd0e12  mov r14d, 0x08
000070df2cbd0e18  mov r12d, 0x40
000070df2cbd0e1e  cmp r14, r12
000070df2cbd0e21  cmc
000070df2cbd0e22  lahf
000070df2cbd0e23  seto al
000070df2cbd0e26  mov [r15+0x108], eax
000070df2cbd0e2d  mov eax, [r15+0x108]
000070df2cbd0e34  sahf
000070df2cbd0e35  jnz 0x000070DF2CBD0E67
000070df2cbd0e37  cmp dword ptr [r15+0x318], 0x00
000070df2cbd0e3f  jz 0x000070DF2CBCFD40
000070df2cbd0e45  nop [rax+rax*1], ax
000070df2cbd0e4e  nop [rax+rax*1], eax
000070df2cbd0e56  mov eax, 0x410118
000070df2cbd0e5b  mov [r15+0x100], rax
000070df2cbd0e62  jmp 0x000070DF2C9FE110
000070df2cbd0e67  cmp dword ptr [r15+0x318], 0x00
000070df2cbd0e6f  jz 0x000070DF2CBCF3F0
000070df2cbd0e75  nop [rax+rax*1], ax
000070df2cbd0e7e  nop [rax+rax*1], eax
000070df2cbd0e86  mov eax, 0x4100A4
000070df2cbd0e8b  mov [r15+0x100], rax
000070df2cbd0e92  jmp 0x000070DF2C9FE110
000070df2cbd0e97  int3
000070df2cbd0e98  call 0x000070DF2CAE27E0
000070df2cbd0e9d  jmp 0x000070DF2CBD0959
000070df2cbd0ea2  call 0x000070DF2CAAE800
000070df2cbd0ea7  jmp 0x000070DF2CBD0962
000070df2cbd0eac  call 0x000070DF2CAC0370
000070df2cbd0eb1  jmp 0x000070DF2CBD0997
000070df2cbd0eb6  call 0x000070DF2CABF100
000070df2cbd0ebb  jmp 0x000070DF2CBD09A0
000070df2cbd0ec0  call 0x000070DF2CAC0370
000070df2cbd0ec5  jmp 0x000070DF2CBD09D5
000070df2cbd0eca  call 0x000070DF2CABF100
000070df2cbd0ecf  jmp 0x000070DF2CBD09DE
000070df2cbd0ed4  call 0x000070DF2CAC0370
000070df2cbd0ed9  jmp 0x000070DF2CBD0A13
000070df2cbd0ede  call 0x000070DF2CAC3AE0
000070df2cbd0ee3  jmp 0x000070DF2CBD0A1C
000070df2cbd0ee8  call 0x000070DF2CAE27E0
000070df2cbd0eed  jmp 0x000070DF2CBD0A55
000070df2cbd0ef2  call 0x000070DF2CAC0370
000070df2cbd0ef7  jmp 0x000070DF2CBD0A63
000070df2cbd0efc  call 0x000070DF2CAC0370
000070df2cbd0f01  jmp 0x000070DF2CBD0A74
000070df2cbd0f06  ucomisd xmm1, xmm13
000070df2cbd0f0b  jp 0x000070DF2CBD0F1A
000070df2cbd0f0d  movaps xmm12, [0x000070DF2C7FE030]
000070df2cbd0f15  jmp 0x000070DF2CBD0AA9
000070df2cbd0f1a  vxorps xmm0, xmm1, xmm13
000070df2cbd0f1f  pextrw r12d, xmm0, 0x03
000070df2cbd0f25  and r12d, 0x7FF8
000070df2cbd0f2c  cmp r12d, 0x08
000070df2cbd0f30  jnz 0x000070DF2CBD0AA9
000070df2cbd0f36  movq r12, xmm13
000070df2cbd0f3b  shl r12, 0x0D
000070df2cbd0f3f  jbe 0x000070DF2CBD0AA9
000070df2cbd0f45  vorps xmm12, xmm13, [0x000070DF2C7FE040]
000070df2cbd0f4d  jmp 0x000070DF2CBD0AA9
000070df2cbd0f52  ucomisd xmm1, xmm15
000070df2cbd0f57  jp 0x000070DF2CBD0F66
000070df2cbd0f59  movaps xmm13, [0x000070DF2C7FE030]
000070df2cbd0f61  jmp 0x000070DF2CBD0ADE
000070df2cbd0f66  vxorps xmm0, xmm1, xmm15
000070df2cbd0f6b  pextrw r12d, xmm0, 0x03
000070df2cbd0f71  and r12d, 0x7FF8
000070df2cbd0f78  cmp r12d, 0x08
000070df2cbd0f7c  jnz 0x000070DF2CBD0ADE
000070df2cbd0f82  movq r12, xmm15
000070df2cbd0f87  shl r12, 0x0D
000070df2cbd0f8b  jbe 0x000070DF2CBD0ADE
000070df2cbd0f91  vorps xmm13, xmm15, [0x000070DF2C7FE040]
000070df2cbd0f99  jmp 0x000070DF2CBD0ADE
000070df2cbd0f9e  ucomisd xmm1, xmm15
000070df2cbd0fa3  jp 0x000070DF2CBD0FB2
000070df2cbd0fa5  movaps xmm12, [0x000070DF2C7FE030]
000070df2cbd0fad  jmp 0x000070DF2CBD0B13
000070df2cbd0fb2  vxorps xmm0, xmm1, xmm15
000070df2cbd0fb7  pextrw r12d, xmm0, 0x03
000070df2cbd0fbd  and r12d, 0x7FF8
000070df2cbd0fc4  cmp r12d, 0x08
000070df2cbd0fc8  jnz 0x000070DF2CBD0B13
000070df2cbd0fce  movq r12, xmm15
000070df2cbd0fd3  shl r12, 0x0D
000070df2cbd0fd7  jbe 0x000070DF2CBD0B13
000070df2cbd0fdd  vorps xmm12, xmm15, [0x000070DF2C7FE040]
000070df2cbd0fe5  jmp 0x000070DF2CBD0B13
000070df2cbd0fea  ucomisd xmm1, xmm15
000070df2cbd0fef  jp 0x000070DF2CBD0FFE
000070df2cbd0ff1  movaps xmm13, [0x000070DF2C7FE030]
000070df2cbd0ff9  jmp 0x000070DF2CBD0B40
000070df2cbd0ffe  vxorps xmm0, xmm1, xmm15
000070df2cbd1003  pextrw r12d, xmm0, 0x03
000070df2cbd1009  and r12d, 0x7FF8
000070df2cbd1010  cmp r12d, 0x08
000070df2cbd1014  jnz 0x000070DF2CBD0B40
000070df2cbd101a  movq r12, xmm15
000070df2cbd101f  shl r12, 0x0D
000070df2cbd1023  jbe 0x000070DF2CBD0B40
000070df2cbd1029  vorps xmm13, xmm15, [0x000070DF2C7FE040]
000070df2cbd1031  jmp 0x000070DF2CBD0B40
000070df2cbd1036  ucomisd xmm1, xmm15
000070df2cbd103b  jp 0x000070DF2CBD104A
000070df2cbd103d  movaps xmm14, [0x000070DF2C7FE030]
000070df2cbd1045  jmp 0x000070DF2CBD0B75
000070df2cbd104a  vxorps xmm0, xmm1, xmm15
000070df2cbd104f  pextrw r12d, xmm0, 0x03
000070df2cbd1055  and r12d, 0x7FF8
000070df2cbd105c  cmp r12d, 0x08
000070df2cbd1060  jnz 0x000070DF2CBD0B75
000070df2cbd1066  movq r12, xmm15
000070df2cbd106b  shl r12, 0x0D
000070df2cbd106f  jbe 0x000070DF2CBD0B75
000070df2cbd1075  vorps xmm14, xmm15, [0x000070DF2C7FE040]
000070df2cbd107d  jmp 0x000070DF2CBD0B75
000070df2cbd1082  call 0x000070DF2CAC0370
000070df2cbd1087  jmp 0x000070DF2CBD0B86
000070df2cbd108c  ucomisd xmm15, xmm14
000070df2cbd1091  jp 0x000070DF2CBD10A0
000070df2cbd1093  movaps xmm13, [0x000070DF2C7FE030]
000070df2cbd109b  jmp 0x000070DF2CBD0BB3
000070df2cbd10a0  vxorps xmm0, xmm15, xmm14
000070df2cbd10a5  pextrw r12d, xmm0, 0x03
000070df2cbd10ab  and r12d, 0x7FF8
000070df2cbd10b2  cmp r12d, 0x08
000070df2cbd10b6  jnz 0x000070DF2CBD0BB3
000070df2cbd10bc  movq r12, xmm14
000070df2cbd10c1  shl r12, 0x0D
000070df2cbd10c5  jbe 0x000070DF2CBD0BB3
000070df2cbd10cb  vorps xmm13, xmm14, [0x000070DF2C7FE040]
000070df2cbd10d3  jmp 0x000070DF2CBD0BB3
000070df2cbd10d8  ucomisd xmm1, xmm15
000070df2cbd10dd  jp 0x000070DF2CBD10EC
000070df2cbd10df  movaps xmm14, [0x000070DF2C7FE030]
000070df2cbd10e7  jmp 0x000070DF2CBD0BE8
000070df2cbd10ec  vxorps xmm0, xmm1, xmm15
000070df2cbd10f1  pextrw r12d, xmm0, 0x03
000070df2cbd10f7  and r12d, 0x7FF8
000070df2cbd10fe  cmp r12d, 0x08
000070df2cbd1102  jnz 0x000070DF2CBD0BE8
000070df2cbd1108  movq r12, xmm15
000070df2cbd110d  shl r12, 0x0D
000070df2cbd1111  jbe 0x000070DF2CBD0BE8
000070df2cbd1117  vorps xmm14, xmm15, [0x000070DF2C7FE040]
000070df2cbd111f  jmp 0x000070DF2CBD0BE8
000070df2cbd1124  call 0x000070DF2CAC0370
000070df2cbd1129  jmp 0x000070DF2CBD0BF9
000070df2cbd112e  ucomisd xmm15, xmm14
000070df2cbd1133  jp 0x000070DF2CBD1142
000070df2cbd1135  movaps xmm13, [0x000070DF2C7FE030]
000070df2cbd113d  jmp 0x000070DF2CBD0C26
000070df2cbd1142  vxorps xmm0, xmm15, xmm14
000070df2cbd1147  pextrw r12d, xmm0, 0x03
000070df2cbd114d  and r12d, 0x7FF8
000070df2cbd1154  cmp r12d, 0x08
000070df2cbd1158  jnz 0x000070DF2CBD0C26
000070df2cbd115e  movq r12, xmm14
000070df2cbd1163  shl r12, 0x0D
000070df2cbd1167  jbe 0x000070DF2CBD0C26
000070df2cbd116d  vorps xmm13, xmm14, [0x000070DF2C7FE040]
000070df2cbd1175  jmp 0x000070DF2CBD0C26
000070df2cbd117a  ucomisd xmm1, xmm15
000070df2cbd117f  jp 0x000070DF2CBD118E
000070df2cbd1181  movaps xmm14, [0x000070DF2C7FE030]
000070df2cbd1189  jmp 0x000070DF2CBD0C5B
000070df2cbd118e  vxorps xmm0, xmm1, xmm15
000070df2cbd1193  pextrw r12d, xmm0, 0x03
000070df2cbd1199  and r12d, 0x7FF8
000070df2cbd11a0  cmp r12d, 0x08
000070df2cbd11a4  jnz 0x000070DF2CBD0C5B
000070df2cbd11aa  movq r12, xmm15
000070df2cbd11af  shl r12, 0x0D
000070df2cbd11b3  jbe 0x000070DF2CBD0C5B
000070df2cbd11b9  vorps xmm14, xmm15, [0x000070DF2C7FE040]
000070df2cbd11c1  jmp 0x000070DF2CBD0C5B
000070df2cbd11c6  call 0x000070DF2CAC0370
000070df2cbd11cb  jmp 0x000070DF2CBD0C6C
000070df2cbd11d0  ucomisd xmm15, xmm14
000070df2cbd11d5  jp 0x000070DF2CBD11E4
000070df2cbd11d7  movaps xmm13, [0x000070DF2C7FE030]
000070df2cbd11df  jmp 0x000070DF2CBD0C99
000070df2cbd11e4  vxorps xmm0, xmm15, xmm14
000070df2cbd11e9  pextrw r12d, xmm0, 0x03
000070df2cbd11ef  and r12d, 0x7FF8
000070df2cbd11f6  cmp r12d, 0x08
000070df2cbd11fa  jnz 0x000070DF2CBD0C99
000070df2cbd1200  movq r12, xmm14
000070df2cbd1205  shl r12, 0x0D
000070df2cbd1209  jbe 0x000070DF2CBD0C99
000070df2cbd120f  vorps xmm13, xmm14, [0x000070DF2C7FE040]
000070df2cbd1217  jmp 0x000070DF2CBD0C99
000070df2cbd121c  ucomisd xmm1, xmm15
000070df2cbd1221  jp 0x000070DF2CBD1230
000070df2cbd1223  movaps xmm14, [0x000070DF2C7FE030]
000070df2cbd122b  jmp 0x000070DF2CBD0CCE
000070df2cbd1230  vxorps xmm0, xmm1, xmm15
000070df2cbd1235  pextrw r12d, xmm0, 0x03
000070df2cbd123b  and r12d, 0x7FF8
000070df2cbd1242  cmp r12d, 0x08
000070df2cbd1246  jnz 0x000070DF2CBD0CCE
000070df2cbd124c  movq r12, xmm15
000070df2cbd1251  shl r12, 0x0D
000070df2cbd1255  jbe 0x000070DF2CBD0CCE
000070df2cbd125b  vorps xmm14, xmm15, [0x000070DF2C7FE040]
000070df2cbd1263  jmp 0x000070DF2CBD0CCE
000070df2cbd1268  call 0x000070DF2CAC0370
000070df2cbd126d  jmp 0x000070DF2CBD0CDF
000070df2cbd1272  ucomisd xmm15, xmm14
000070df2cbd1277  jp 0x000070DF2CBD1286
000070df2cbd1279  movaps xmm13, [0x000070DF2C7FE030]
000070df2cbd1281  jmp 0x000070DF2CBD0D0C
000070df2cbd1286  vxorps xmm0, xmm15, xmm14
000070df2cbd128b  pextrw r12d, xmm0, 0x03
000070df2cbd1291  and r12d, 0x7FF8
000070df2cbd1298  cmp r12d, 0x08
000070df2cbd129c  jnz 0x000070DF2CBD0D0C
000070df2cbd12a2  movq r12, xmm14
000070df2cbd12a7  shl r12, 0x0D
000070df2cbd12ab  jbe 0x000070DF2CBD0D0C
000070df2cbd12b1  vorps xmm13, xmm14, [0x000070DF2C7FE040]
000070df2cbd12b9  jmp 0x000070DF2CBD0D0C
000070df2cbd12be  ucomisd xmm1, xmm15
000070df2cbd12c3  jp 0x000070DF2CBD12D2
000070df2cbd12c5  movaps xmm14, [0x000070DF2C7FE030]
000070df2cbd12cd  jmp 0x000070DF2CBD0D41
000070df2cbd12d2  vxorps xmm0, xmm1, xmm15
000070df2cbd12d7  pextrw r12d, xmm0, 0x03
000070df2cbd12dd  and r12d, 0x7FF8
000070df2cbd12e4  cmp r12d, 0x08
000070df2cbd12e8  jnz 0x000070DF2CBD0D41
000070df2cbd12ee  movq r12, xmm15
000070df2cbd12f3  shl r12, 0x0D
000070df2cbd12f7  jbe 0x000070DF2CBD0D41
000070df2cbd12fd  vorps xmm14, xmm15, [0x000070DF2C7FE040]
000070df2cbd1305  jmp 0x000070DF2CBD0D41
000070df2cbd130a  call 0x000070DF2CAC3AE0
000070df2cbd130f  jmp 0x000070DF2CBD0D52
000070df2cbd1314  ucomisd xmm15, xmm14
000070df2cbd1319  jp 0x000070DF2CBD1328
000070df2cbd131b  movaps xmm13, [0x000070DF2C7FE030]
000070df2cbd1323  jmp 0x000070DF2CBD0D87
000070df2cbd1328  vxorps xmm0, xmm15, xmm14
000070df2cbd132d  pextrw r14d, xmm0, 0x03
000070df2cbd1333  and r14d, 0x7FF8
000070df2cbd133a  cmp r14d, 0x08
000070df2cbd133e  jnz 0x000070DF2CBD0D87
000070df2cbd1344  movq r14, xmm14
000070df2cbd1349  shl r14, 0x0D
000070df2cbd134d  jbe 0x000070DF2CBD0D87
000070df2cbd1353  vorps xmm13, xmm14, [0x000070DF2C7FE040]
000070df2cbd135b  jmp 0x000070DF2CBD0D87
000070df2cbd1360  ucomisd xmm1, xmm15
000070df2cbd1365  jp 0x000070DF2CBD1374
000070df2cbd1367  movaps xmm14, [0x000070DF2C7FE030]
000070df2cbd136f  jmp 0x000070DF2CBD0DBC
000070df2cbd1374  vxorps xmm0, xmm1, xmm15
000070df2cbd1379  pextrw r14d, xmm0, 0x03
000070df2cbd137f  and r14d, 0x7FF8
000070df2cbd1386  cmp r14d, 0x08
000070df2cbd138a  jnz 0x000070DF2CBD0DBC
000070df2cbd1390  movq r14, xmm15
000070df2cbd1395  shl r14, 0x0D
000070df2cbd1399  jbe 0x000070DF2CBD0DBC
000070df2cbd139f  vorps xmm14, xmm15, [0x000070DF2C7FE040]
000070df2cbd13a7  jmp 0x000070DF2CBD0DBC
000070df2cbd13ac  ucomisd xmm1, xmm15
000070df2cbd13b1  jp 0x000070DF2CBD13C0
000070df2cbd13b3  movaps xmm14, [0x000070DF2C7FE030]
000070df2cbd13bb  jmp 0x000070DF2CBD0DF1
000070df2cbd13c0  vxorps xmm0, xmm1, xmm15
000070df2cbd13c5  pextrw r14d, xmm0, 0x03
000070df2cbd13cb  and r14d, 0x7FF8
000070df2cbd13d2  cmp r14d, 0x08
000070df2cbd13d6  jnz 0x000070DF2CBD0DF1
000070df2cbd13dc  movq r14, xmm15
000070df2cbd13e1  shl r14, 0x0D
000070df2cbd13e5  jbe 0x000070DF2CBD0DF1
000070df2cbd13eb  vorps xmm14, xmm15, [0x000070DF2C7FE040]
000070df2cbd13f3  jmp 0x000070DF2CBD0DF1
000070df2cbd13f8  call 0x000070DF2CA0E120
000070df2cbd13fd  jmp 0x000070DF2CBD0E08
000070df2cbd1402  int3
000070df2cbd1403  nop [rax+rax*1], ax
000070df2cbd140c  nop [rax], eax
000070df2cbd1410  mov qword ptr [r15+0x40], 0x420000
000070df2cbd1418  mov eax, 0x4201B8
000070df2cbd141d  mov r14, [r13+rax*1]
000070df2cbd1422  movq xmm1, r14
000070df2cbd1427  mov rax, [r15+0x50]
000070df2cbd142b  mov r14, [r13+rax*1]
000070df2cbd1430  movq xmm15, r14
000070df2cbd1435  movaps [r15+0x120], xmm15
000070df2cbd143d  mov qword ptr [r15+0x48], 0x08
000070df2cbd1445  xor eax, eax
000070df2cbd1447  mov r14d, 0x08
000070df2cbd144d  mov r12d, 0x200
000070df2cbd1453  cmp r14, r12
000070df2cbd1456  cmc
000070df2cbd1457  lahf
000070df2cbd1458  seto al
000070df2cbd145b  mov [r15+0x108], eax
000070df2cbd1462  movq rax, xmm1
000070df2cbd1467  movq r14, xmm15
000070df2cbd146c  vmovq xmm1, rax
000070df2cbd1471  vmovq xmm15, r14
000070df2cbd1476  movaps xmm14, xmm1
000070df2cbd147a  addsd xmm14, xmm15
000070df2cbd147f  ucomisd xmm14, xmm14
000070df2cbd1484  jp 0x000070DF2CBD1516
000070df2cbd148a  movq xmm14, xmm14
000070df2cbd148f  movaps [r15+0x110], xmm14
000070df2cbd1497  mov eax, [r15+0x108]
000070df2cbd149e  sahf
000070df2cbd149f  jnz 0x000070DF2CBD14D1
000070df2cbd14a1  cmp dword ptr [r15+0x318], 0x00
000070df2cbd14a9  jz 0x000070DF2CBD16A0
000070df2cbd14af  nop [rax+rax*1], ax
000070df2cbd14b8  nop [rax+rax*1], eax
000070df2cbd14c0  mov eax, 0x410154
000070df2cbd14c5  mov [r15+0x100], rax
000070df2cbd14cc  jmp 0x000070DF2C9FE110
000070df2cbd14d1  cmp dword ptr [r15+0x318], 0x00
000070df2cbd14d9  jz 0x000070DF2CBD1560
000070df2cbd14df  nop [rax+rax*1], ax
000070df2cbd14e8  nop [rax+rax*1], eax
000070df2cbd14f0  mov eax, 0x410140
000070df2cbd14f5  mov [r15+0x100], rax
000070df2cbd14fc  jmp 0x000070DF2C9FE110
000070df2cbd1501  int3
000070df2cbd1502  call 0x000070DF2CA0DC20
000070df2cbd1507  jmp 0x000070DF2CBD1422
000070df2cbd150c  call 0x000070DF2CA0DC20
000070df2cbd1511  jmp 0x000070DF2CBD1430
000070df2cbd1516  ucomisd xmm1, xmm15
000070df2cbd151b  jp 0x000070DF2CBD152A
000070df2cbd151d  movaps xmm14, [0x000070DF2C7FE030]
000070df2cbd1525  jmp 0x000070DF2CBD148A
000070df2cbd152a  vxorps xmm0, xmm1, xmm15
000070df2cbd152f  pextrw eax, xmm0, 0x03
000070df2cbd1534  and eax, 0x7FF8
000070df2cbd1539  cmp eax, 0x08
000070df2cbd153c  jnz 0x000070DF2CBD148A
000070df2cbd1542  movq rax, xmm15
000070df2cbd1547  shl rax, 0x0D
000070df2cbd154b  jbe 0x000070DF2CBD148A
000070df2cbd1551  vorps xmm14, xmm15, [0x000070DF2C7FE040]
000070df2cbd1559  jmp 0x000070DF2CBD148A
000070df2cbd155e  int3
000070df2cbd155f  nop
000070df2cbd1560  mov rax, [r15+0x48]
000070df2cbd1564  mov r14, [r15+0x50]
000070df2cbd1568  lea r12, [r14+rax*1]
000070df2cbd156c  mov r14, [r13+r12*1]
000070df2cbd1571  movq xmm1, r14
000070df2cbd1576  movaps [r15+0x120], xmm1
000070df2cbd157e  lea r14, [rax+0x08]
000070df2cbd1582  mov [r15+0x48], r14
000070df2cbd1586  xor eax, eax
000070df2cbd1588  mov r12d, 0x200
000070df2cbd158e  cmp r14, r12
000070df2cbd1591  cmc
000070df2cbd1592  lahf
000070df2cbd1593  seto al
000070df2cbd1596  mov [r15+0x108], eax
000070df2cbd159d  movaps xmm15, [r15+0x110]
000070df2cbd15a5  movq rax, xmm15
000070df2cbd15aa  movq r14, xmm1
000070df2cbd15af  vmovq xmm1, rax
000070df2cbd15b4  vmovq xmm15, r14
000070df2cbd15b9  movaps xmm14, xmm1
000070df2cbd15bd  addsd xmm14, xmm15
000070df2cbd15c2  ucomisd xmm14, xmm14
000070df2cbd15c7  jp 0x000070DF2CBD164F
000070df2cbd15cd  movq xmm14, xmm14
000070df2cbd15d2  movaps [r15+0x110], xmm14
000070df2cbd15da  mov eax, [r15+0x108]
000070df2cbd15e1  sahf
000070df2cbd15e2  jnz 0x000070DF2CBD1614
000070df2cbd15e4  cmp dword ptr [r15+0x318], 0x00
000070df2cbd15ec  jz 0x000070DF2CBD16A0
000070df2cbd15f2  nop [rax+rax*1], ax
000070df2cbd15fb  nop [rax+rax*1], eax
000070df2cbd1603  mov eax, 0x410154
000070df2cbd1608  mov [r15+0x100], rax
000070df2cbd160f  jmp 0x000070DF2C9FE110
000070df2cbd1614  cmp dword ptr [r15+0x318], 0x00
000070df2cbd161c  jz 0x000070DF2CBD1560
000070df2cbd1622  nop [rax+rax*1], ax
000070df2cbd162b  nop [rax+rax*1], eax
000070df2cbd1633  mov eax, 0x410140
000070df2cbd1638  mov [r15+0x100], rax
000070df2cbd163f  jmp 0x000070DF2C9FE110
000070df2cbd1644  int3
000070df2cbd1645  call 0x000070DF2CAC3AE0
000070df2cbd164a  jmp 0x000070DF2CBD1571
000070df2cbd164f  ucomisd xmm1, xmm15
000070df2cbd1654  jp 0x000070DF2CBD1663
000070df2cbd1656  movaps xmm14, [0x000070DF2C7FE030]
000070df2cbd165e  jmp 0x000070DF2CBD15CD
000070df2cbd1663  vxorps xmm0, xmm1, xmm15
000070df2cbd1668  pextrw eax, xmm0, 0x03
000070df2cbd166d  and eax, 0x7FF8
000070df2cbd1672  cmp eax, 0x08
000070df2cbd1675  jnz 0x000070DF2CBD15CD
000070df2cbd167b  movq rax, xmm15
000070df2cbd1680  shl rax, 0x0D
000070df2cbd1684  jbe 0x000070DF2CBD15CD
000070df2cbd168a  vorps xmm14, xmm15, [0x000070DF2C7FE040]
000070df2cbd1692  jmp 0x000070DF2CBD15CD
000070df2cbd1697  int3
000070df2cbd1698  nop [rax+rax*1], eax
000070df2cbd16a0  mov rax, [r15+0x40]
000070df2cbd16a4  lea r14, [rax+0x1B8]
000070df2cbd16ab  movaps xmm1, [r15+0x110]
000070df2cbd16b3  movq rax, xmm1
000070df2cbd16b8  mov [r13+r14*1], rax
000070df2cbd16bd  mov rax, [r15+0xF0]
000070df2cbd16c4  mov [r15+0x100], rax
000070df2cbd16cb  jmp 0x000070DF2CBCE5C0
000070df2cbd16d0  int3
000070df2cbd16d1  call 0x000070DF2CAD5EB0
000070df2cbd16d6  jmp 0x000070DF2CBD16BD
000070df2cbd16db  int3
000070df2cbd16dc  nop [rax], eax
000070df2cbd16e0  mov qword ptr [r15+0x100], 0x04
000070df2cbd16eb  mov esi, 0x00
000070df2cbd16f0  mov edx, 0x09
000070df2cbd16f5  mov rdi, 0x7FFCCD0DA870
000070df2cbd16ff  mov rax, 0x63A110FF6970
000070df2cbd1709  call rax
000070df2cbd170b  cmp dword ptr [r15+0x318], 0x00
000070df2cbd1713  jnz 0x000070DF2C9FE110
000070df2cbd1719  jmp 0x000070DF2C9FE0A0
000070df2cbd171e  int3
000070df2cbd171f  int3
