00007c081b1ce69b  nop [rax+rax*1], eax
00007c081b1ce6a0  mov qword ptr [r15+0x40], 0x4201C0
00007c081b1ce6a8  mov qword ptr [r15+0x48], 0x4203C0
00007c081b1ce6b0  mov qword ptr [r15+0x60], 0x01
00007c081b1ce6b8  xorps xmm1, xmm1
00007c081b1ce6bb  mov eax, 0x41
00007c081b1ce6c0  vcvtusi2sd xmm1, xmm1, eax
00007c081b1ce6c6  mulsd xmm1, [0x00007C081ADFE010]
00007c081b1ce6ce  movq xmm1, xmm1
00007c081b1ce6d2  movaps [r15+0x120], xmm1
00007c081b1ce6da  mov eax, [r15+0x60]
00007c081b1ce6de  xorps xmm15, xmm15
00007c081b1ce6e2  vcvtusi2sd xmm15, xmm15, eax
00007c081b1ce6e8  mulsd xmm15, [0x00007C081ADFE020]
00007c081b1ce6f1  movq xmm15, xmm15
00007c081b1ce6f6  movaps [r15+0x110], xmm15
00007c081b1ce6fe  mov rax, [r15+0x60]
00007c081b1ce702  mov [rsp+0x10], rax
00007c081b1ce707  xor eax, eax
00007c081b1ce709  mov r14, [rsp+0x10]
00007c081b1ce70e  mov r12d, 0x40
00007c081b1ce714  cmp r14, r12
00007c081b1ce717  cmc
00007c081b1ce718  lahf
00007c081b1ce719  seto al
00007c081b1ce71c  mov [r15+0x108], eax
00007c081b1ce723  mov qword ptr [r15+0x50], 0x40
00007c081b1ce72b  movq rax, xmm1
00007c081b1ce730  mov r12d, 0x4203C0
00007c081b1ce736  mov [r13+r12*1], rax
00007c081b1ce73b  movq rax, xmm15
00007c081b1ce740  mov r12d, 0x4201C0
00007c081b1ce746  mov [r13+r12*1], rax
00007c081b1ce74b  mov [r15+0x58], r14
00007c081b1ce74f  mov eax, [r15+0x108]
00007c081b1ce756  sahf
00007c081b1ce757  jnz 0x00007C081B1CE789
00007c081b1ce759  cmp dword ptr [r15+0x318], 0x00
00007c081b1ce761  jz 0x00007C081B1CE910
00007c081b1ce767  nop [rax+rax*1], ax
00007c081b1ce770  nop [rax+rax*1], eax
00007c081b1ce778  mov eax, 0x410074
00007c081b1ce77d  mov [r15+0x100], rax
00007c081b1ce784  jmp 0x00007C081AFFE110
00007c081b1ce789  cmp dword ptr [r15+0x318], 0x00
00007c081b1ce791  jz 0x00007C081B1CE7D0
00007c081b1ce797  nop [rax+rax*1], ax
00007c081b1ce7a0  nop [rax+rax*1], eax
00007c081b1ce7a8  mov eax, 0x41004C
00007c081b1ce7ad  mov [r15+0x100], rax
00007c081b1ce7b4  jmp 0x00007C081AFFE110
00007c081b1ce7b9  int3
00007c081b1ce7ba  call 0x00007C081B0B4CB0
00007c081b1ce7bf  jmp 0x00007C081B1CE73B
00007c081b1ce7c4  call 0x00007C081B0B4CB0
00007c081b1ce7c9  jmp 0x00007C081B1CE74B
00007c081b1ce7ce  int3
00007c081b1ce7cf  nop
00007c081b1ce7d0  mov rax, [r15+0x58]
00007c081b1ce7d4  lea r14, [rax+0x01]
00007c081b1ce7d8  mov [r15+0x60], r14
00007c081b1ce7dc  mov r14d, [r15+0x50]
00007c081b1ce7e0  xorps xmm1, xmm1
00007c081b1ce7e3  vcvtusi2sd xmm1, xmm1, r14d
00007c081b1ce7e9  mulsd xmm1, [0x00007C081ADFE010]
00007c081b1ce7f1  movq xmm1, xmm1
00007c081b1ce7f5  movaps [r15+0x120], xmm1
00007c081b1ce7fd  rorx r12, rax, 0x3D
00007c081b1ce803  and r12, 0xFFFFFFFFFFFFFFF8
00007c081b1ce807  mov eax, [r15+0x60]
00007c081b1ce80b  xorps xmm15, xmm15
00007c081b1ce80f  vcvtusi2sd xmm15, xmm15, eax
00007c081b1ce815  mulsd xmm15, [0x00007C081ADFE020]
00007c081b1ce81e  movq xmm15, xmm15
00007c081b1ce823  movaps [r15+0x110], xmm15
00007c081b1ce82b  mov rax, [r15+0x60]
00007c081b1ce82f  mov [rsp+0x10], rax
00007c081b1ce834  xor eax, eax
00007c081b1ce836  mov r11, [rsp+0x10]
00007c081b1ce83b  mov r10d, 0x40
00007c081b1ce841  cmp r11, r10
00007c081b1ce844  cmc
00007c081b1ce845  lahf
00007c081b1ce846  seto al
00007c081b1ce849  mov [r15+0x108], eax
00007c081b1ce850  lea eax, [r14d-0x01]
00007c081b1ce855  mov eax, eax
00007c081b1ce857  mov [r15+0x50], rax
00007c081b1ce85b  mov rax, [r15+0x48]
00007c081b1ce85f  lea r14, [rax+r12*1]
00007c081b1ce863  movq rax, xmm1
00007c081b1ce868  mov [r13+r14*1], rax
00007c081b1ce86d  mov rax, [r15+0x40]
00007c081b1ce871  lea r14, [rax+r12*1]
00007c081b1ce875  movq rax, xmm15
00007c081b1ce87a  mov [r13+r14*1], rax
00007c081b1ce87f  mov [r15+0x58], r11
00007c081b1ce883  mov eax, [r15+0x108]
00007c081b1ce88a  sahf
00007c081b1ce88b  jnz 0x00007C081B1CE8BD
00007c081b1ce88d  cmp dword ptr [r15+0x318], 0x00
00007c081b1ce895  jz 0x00007C081B1CE910
00007c081b1ce89b  nop [rax+rax*1], ax
00007c081b1ce8a4  nop [rax+rax*1], eax
00007c081b1ce8ac  mov eax, 0x410074
00007c081b1ce8b1  mov [r15+0x100], rax
00007c081b1ce8b8  jmp 0x00007C081AFFE110
00007c081b1ce8bd  cmp dword ptr [r15+0x318], 0x00
00007c081b1ce8c5  jz 0x00007C081B1CE7D0
00007c081b1ce8cb  nop [rax+rax*1], ax
00007c081b1ce8d4  nop [rax+rax*1], eax
00007c081b1ce8dc  mov eax, 0x41004C
00007c081b1ce8e1  mov [r15+0x100], rax
00007c081b1ce8e8  jmp 0x00007C081AFFE110
00007c081b1ce8ed  int3
00007c081b1ce8ee  call 0x00007C081B0D5EB0
00007c081b1ce8f3  jmp 0x00007C081B1CE86D
00007c081b1ce8f8  call 0x00007C081B0D5EB0
00007c081b1ce8fd  jmp 0x00007C081B1CE87F
00007c081b1ce902  int3
00007c081b1ce903  nop [rax+rax*1], ax
00007c081b1ce90c  nop [rax], eax
00007c081b1ce910  vxorps xmm1, xmm1, xmm1
00007c081b1ce914  movq xmm1, xmm1
00007c081b1ce918  movaps [r15+0x110], xmm1
00007c081b1ce920  mov qword ptr [r15+0x58], 0x00
00007c081b1ce928  mov qword ptr [r15+0x50], 0x4205C0
00007c081b1ce930  mov qword ptr [r15+0x60], 0x00
00007c081b1ce938  mov qword ptr [r15+0x68], 0x4205C0
00007c081b1ce940  mov rax, [r15+0x40]
00007c081b1ce944  mov r14, [r13+rax*1]
00007c081b1ce949  lea r12, [rax+0x08]
00007c081b1ce94d  mov r11, [r13+r12*1]
00007c081b1ce952  movq xmm15, r14
00007c081b1ce957  movq xmm14, r11
00007c081b1ce95c  movq xmm15, xmm15
00007c081b1ce961  movq xmm15, xmm15
00007c081b1ce966  movaps [r15+0x120], xmm15
00007c081b1ce96e  movq xmm14, xmm14
00007c081b1ce973  movq xmm14, xmm14
00007c081b1ce978  movaps [r15+0x130], xmm14
00007c081b1ce980  lea r14, [rax+0x10]
00007c081b1ce984  mov r12, [r13+r14*1]
00007c081b1ce989  lea r14, [rax+0x18]
00007c081b1ce98d  mov r11, [r13+r14*1]
00007c081b1ce992  movq xmm15, r12
00007c081b1ce997  movq xmm14, r11
00007c081b1ce99c  movq xmm15, xmm15
00007c081b1ce9a1  movq xmm15, xmm15
00007c081b1ce9a6  movaps [r15+0x140], xmm15
00007c081b1ce9ae  movq xmm14, xmm14
00007c081b1ce9b3  movq xmm14, xmm14
00007c081b1ce9b8  movaps [r15+0x150], xmm14
00007c081b1ce9c0  lea r14, [rax+0x20]
00007c081b1ce9c4  mov r12, [r13+r14*1]
00007c081b1ce9c9  lea r14, [rax+0x28]
00007c081b1ce9cd  mov r11, [r13+r14*1]
00007c081b1ce9d2  movq xmm15, r12
00007c081b1ce9d7  movq xmm14, r11
00007c081b1ce9dc  movq xmm15, xmm15
00007c081b1ce9e1  movq xmm15, xmm15
00007c081b1ce9e6  movaps [r15+0x160], xmm15
00007c081b1ce9ee  movq xmm14, xmm14
00007c081b1ce9f3  movq xmm14, xmm14
00007c081b1ce9f8  movaps [r15+0x170], xmm14
00007c081b1cea00  lea r14, [rax+0x30]
00007c081b1cea04  mov r12, [r13+r14*1]
00007c081b1cea09  lea r14, [rax+0x38]
00007c081b1cea0d  mov rax, [r13+r14*1]
00007c081b1cea12  movq xmm15, r12
00007c081b1cea17  movq xmm14, rax
00007c081b1cea1c  movq xmm15, xmm15
00007c081b1cea21  movq xmm15, xmm15
00007c081b1cea26  movaps [r15+0x180], xmm15
00007c081b1cea2e  movq xmm14, xmm14
00007c081b1cea33  movq xmm14, xmm14
00007c081b1cea38  movaps [r15+0x210], xmm14
00007c081b1cea40  mov rax, [r15+0x48]
00007c081b1cea44  mov [r15+0x78], rax
00007c081b1cea48  mov r14, [r13+rax*1]
00007c081b1cea4d  movq xmm15, r14
00007c081b1cea52  lea r14, [rax+0x40]
00007c081b1cea56  mov r12, [r13+r14*1]
00007c081b1cea5b  movq xmm14, r12
00007c081b1cea60  lea r14, [rax+0x80]
00007c081b1cea67  mov r12, [r13+r14*1]
00007c081b1cea6c  movq xmm13, r12
00007c081b1cea71  movaps xmm12, [r15+0x120]
00007c081b1cea79  movq r14, xmm12
00007c081b1cea7e  movq r12, xmm15
00007c081b1cea83  vmovq xmm15, r14
00007c081b1cea88  vmovq xmm12, r12
00007c081b1cea8d  movaps xmm11, xmm15
00007c081b1cea91  mulsd xmm11, xmm12
00007c081b1cea96  ucomisd xmm11, xmm11
00007c081b1cea9b  jp 0x00007C081B1CEEFC
00007c081b1ceaa1  movq xmm11, xmm11
00007c081b1ceaa6  movaps xmm15, [r15+0x130]
00007c081b1ceaae  movq r14, xmm15
00007c081b1ceab3  movq r12, xmm14
00007c081b1ceab8  vmovq xmm15, r14
00007c081b1ceabd  vmovq xmm14, r12
00007c081b1ceac2  movaps xmm12, xmm15
00007c081b1ceac6  mulsd xmm12, xmm14
00007c081b1ceacb  ucomisd xmm12, xmm12
00007c081b1cead0  jp 0x00007C081B1CEF48
00007c081b1cead6  movq xmm12, xmm12
00007c081b1ceadb  movq r14, xmm11
00007c081b1ceae0  movq r12, xmm1
00007c081b1ceae5  vmovq xmm1, r14
00007c081b1ceaea  vmovq xmm15, r12
00007c081b1ceaef  movaps xmm14, xmm1
00007c081b1ceaf3  addsd xmm14, xmm15
00007c081b1ceaf8  ucomisd xmm14, xmm14
00007c081b1ceafd  jp 0x00007C081B1CEF94
00007c081b1ceb03  movq xmm14, xmm14
00007c081b1ceb08  movq r14, xmm14
00007c081b1ceb0d  movq r12, xmm12
00007c081b1ceb12  vmovq xmm1, r14
00007c081b1ceb17  vmovq xmm15, r12
00007c081b1ceb1c  movaps xmm14, xmm1
00007c081b1ceb20  addsd xmm14, xmm15
00007c081b1ceb25  ucomisd xmm14, xmm14
00007c081b1ceb2a  jp 0x00007C081B1CEFE0
00007c081b1ceb30  movq xmm14, xmm14
00007c081b1ceb35  movaps xmm1, [r15+0x140]
00007c081b1ceb3d  movq r14, xmm1
00007c081b1ceb42  movq r12, xmm13
00007c081b1ceb47  vmovq xmm1, r14
00007c081b1ceb4c  vmovq xmm15, r12
00007c081b1ceb51  movaps xmm13, xmm1
00007c081b1ceb55  mulsd xmm13, xmm15
00007c081b1ceb5a  ucomisd xmm13, xmm13
00007c081b1ceb5f  jp 0x00007C081B1CF02C
00007c081b1ceb65  movq xmm13, xmm13
00007c081b1ceb6a  lea r14, [rax+0xC0]
00007c081b1ceb71  mov r12, [r13+r14*1]
00007c081b1ceb76  movq xmm1, r12
00007c081b1ceb7b  movq r14, xmm14
00007c081b1ceb80  movq r12, xmm13
00007c081b1ceb85  vmovq xmm15, r14
00007c081b1ceb8a  vmovq xmm14, r12
00007c081b1ceb8f  movaps xmm13, xmm15
00007c081b1ceb93  addsd xmm13, xmm14
00007c081b1ceb98  ucomisd xmm13, xmm13
00007c081b1ceb9d  jp 0x00007C081B1CF082
00007c081b1ceba3  movq xmm13, xmm13
00007c081b1ceba8  movaps xmm15, [r15+0x150]
00007c081b1cebb0  movq r14, xmm15
00007c081b1cebb5  movq r12, xmm1
00007c081b1cebba  vmovq xmm1, r14
00007c081b1cebbf  vmovq xmm15, r12
00007c081b1cebc4  movaps xmm14, xmm1
00007c081b1cebc8  mulsd xmm14, xmm15
00007c081b1cebcd  ucomisd xmm14, xmm14
00007c081b1cebd2  jp 0x00007C081B1CF0CE
00007c081b1cebd8  movq xmm14, xmm14
00007c081b1cebdd  lea r14, [rax+0x100]
00007c081b1cebe4  mov r12, [r13+r14*1]
00007c081b1cebe9  movq xmm1, r12
00007c081b1cebee  movq r14, xmm13
00007c081b1cebf3  movq r12, xmm14
00007c081b1cebf8  vmovq xmm15, r14
00007c081b1cebfd  vmovq xmm14, r12
00007c081b1cec02  movaps xmm13, xmm15
00007c081b1cec06  addsd xmm13, xmm14
00007c081b1cec0b  ucomisd xmm13, xmm13
00007c081b1cec10  jp 0x00007C081B1CF124
00007c081b1cec16  movq xmm13, xmm13
00007c081b1cec1b  movaps xmm15, [r15+0x160]
00007c081b1cec23  movq r14, xmm15
00007c081b1cec28  movq r12, xmm1
00007c081b1cec2d  vmovq xmm1, r14
00007c081b1cec32  vmovq xmm15, r12
00007c081b1cec37  movaps xmm14, xmm1
00007c081b1cec3b  mulsd xmm14, xmm15
00007c081b1cec40  ucomisd xmm14, xmm14
00007c081b1cec45  jp 0x00007C081B1CF170
00007c081b1cec4b  movq xmm14, xmm14
00007c081b1cec50  lea r14, [rax+0x140]
00007c081b1cec57  mov r12, [r13+r14*1]
00007c081b1cec5c  movq xmm1, r12
00007c081b1cec61  movq r14, xmm13
00007c081b1cec66  movq r12, xmm14
00007c081b1cec6b  vmovq xmm15, r14
00007c081b1cec70  vmovq xmm14, r12
00007c081b1cec75  movaps xmm13, xmm15
00007c081b1cec79  addsd xmm13, xmm14
00007c081b1cec7e  ucomisd xmm13, xmm13
00007c081b1cec83  jp 0x00007C081B1CF1C6
00007c081b1cec89  movq xmm13, xmm13
00007c081b1cec8e  movaps xmm15, [r15+0x170]
00007c081b1cec96  movq r14, xmm15
00007c081b1cec9b  movq r12, xmm1
00007c081b1ceca0  vmovq xmm1, r14
00007c081b1ceca5  vmovq xmm15, r12
00007c081b1cecaa  movaps xmm14, xmm1
00007c081b1cecae  mulsd xmm14, xmm15
00007c081b1cecb3  ucomisd xmm14, xmm14
00007c081b1cecb8  jp 0x00007C081B1CF212
00007c081b1cecbe  movq xmm14, xmm14
00007c081b1cecc3  lea r14, [rax+0x180]
00007c081b1cecca  mov r12, [r13+r14*1]
00007c081b1ceccf  movq xmm1, r12
00007c081b1cecd4  movq r14, xmm13
00007c081b1cecd9  movq r12, xmm14
00007c081b1cecde  vmovq xmm15, r14
00007c081b1cece3  vmovq xmm14, r12
00007c081b1cece8  movaps xmm13, xmm15
00007c081b1cecec  addsd xmm13, xmm14
00007c081b1cecf1  ucomisd xmm13, xmm13
00007c081b1cecf6  jp 0x00007C081B1CF268
00007c081b1cecfc  movq xmm13, xmm13
00007c081b1ced01  movaps xmm15, [r15+0x180]
00007c081b1ced09  movq r14, xmm15
00007c081b1ced0e  movq r12, xmm1
00007c081b1ced13  vmovq xmm1, r14
00007c081b1ced18  vmovq xmm15, r12
00007c081b1ced1d  movaps xmm14, xmm1
00007c081b1ced21  mulsd xmm14, xmm15
00007c081b1ced26  ucomisd xmm14, xmm14
00007c081b1ced2b  jp 0x00007C081B1CF2B4
00007c081b1ced31  movq xmm14, xmm14
00007c081b1ced36  lea r14, [rax+0x1C0]
00007c081b1ced3d  mov rax, [r13+r14*1]
00007c081b1ced42  movq xmm1, rax
00007c081b1ced47  movaps [r15+0x240], xmm1
00007c081b1ced4f  movq rax, xmm13
00007c081b1ced54  movq r14, xmm14
00007c081b1ced59  vmovq xmm15, rax
00007c081b1ced5e  vmovq xmm14, r14
00007c081b1ced63  movaps xmm13, xmm15
00007c081b1ced67  addsd xmm13, xmm14
00007c081b1ced6c  ucomisd xmm13, xmm13
00007c081b1ced71  jp 0x00007C081B1CF30A
00007c081b1ced77  movq xmm13, xmm13
00007c081b1ced7c  movaps xmm15, [r15+0x210]
00007c081b1ced84  movq rax, xmm15
00007c081b1ced89  movq r14, xmm1
00007c081b1ced8e  vmovq xmm1, rax
00007c081b1ced93  vmovq xmm15, r14
00007c081b1ced98  movaps xmm14, xmm1
00007c081b1ced9c  mulsd xmm14, xmm15
00007c081b1ceda1  ucomisd xmm14, xmm14
00007c081b1ceda6  jp 0x00007C081B1CF352
00007c081b1cedac  movq xmm14, xmm14
00007c081b1cedb1  movaps [r15+0x230], xmm14
00007c081b1cedb9  movq rax, xmm13
00007c081b1cedbe  movq r14, xmm14
00007c081b1cedc3  vmovq xmm1, rax
00007c081b1cedc8  vmovq xmm15, r14
00007c081b1cedcd  movaps xmm14, xmm1
00007c081b1cedd1  addsd xmm14, xmm15
00007c081b1cedd6  ucomisd xmm14, xmm14
00007c081b1ceddb  jp 0x00007C081B1CF39A
00007c081b1cede1  movq xmm14, xmm14
00007c081b1cede6  movaps [r15+0x220], xmm14
00007c081b1cedee  movq rax, xmm14
00007c081b1cedf3  mov r14d, 0x4205C0
00007c081b1cedf9  mov [r13+r14*1], rax
00007c081b1cedfe  mov qword ptr [r15+0x70], 0x08
00007c081b1cee06  xor eax, eax
00007c081b1cee08  mov r14d, 0x08
00007c081b1cee0e  mov r12d, 0x40
00007c081b1cee14  cmp r14, r12
00007c081b1cee17  cmc
00007c081b1cee18  lahf
00007c081b1cee19  seto al
00007c081b1cee1c  mov [r15+0x108], eax
00007c081b1cee23  mov eax, [r15+0x108]
00007c081b1cee2a  sahf
00007c081b1cee2b  jnz 0x00007C081B1CEE5D
00007c081b1cee2d  cmp dword ptr [r15+0x318], 0x00
00007c081b1cee35  jz 0x00007C081B1CFD40
00007c081b1cee3b  nop [rax+rax*1], ax
00007c081b1cee44  nop [rax+rax*1], eax
00007c081b1cee4c  mov eax, 0x410118
00007c081b1cee51  mov [r15+0x100], rax
00007c081b1cee58  jmp 0x00007C081AFFE110
00007c081b1cee5d  cmp dword ptr [r15+0x318], 0x00
00007c081b1cee65  jz 0x00007C081B1CF3F0
00007c081b1cee6b  nop [rax+rax*1], ax
00007c081b1cee74  nop [rax+rax*1], eax
00007c081b1cee7c  mov eax, 0x4100A4
00007c081b1cee81  mov [r15+0x100], rax
00007c081b1cee88  jmp 0x00007C081AFFE110
00007c081b1cee8d  int3
00007c081b1cee8e  call 0x00007C081B00DC20
00007c081b1cee93  jmp 0x00007C081B1CE949
00007c081b1cee98  call 0x00007C081B0C0370
00007c081b1cee9d  jmp 0x00007C081B1CE952
00007c081b1ceea2  call 0x00007C081B0E27E0
00007c081b1ceea7  jmp 0x00007C081B1CE989
00007c081b1ceeac  call 0x00007C081B0E1570
00007c081b1ceeb1  jmp 0x00007C081B1CE992
00007c081b1ceeb6  call 0x00007C081B0E27E0
00007c081b1ceebb  jmp 0x00007C081B1CE9C9
00007c081b1ceec0  call 0x00007C081B0E1570
00007c081b1ceec5  jmp 0x00007C081B1CE9D2
00007c081b1ceeca  call 0x00007C081B0E27E0
00007c081b1ceecf  jmp 0x00007C081B1CEA09
00007c081b1ceed4  call 0x00007C081B0D59C0
00007c081b1ceed9  jmp 0x00007C081B1CEA12
00007c081b1ceede  call 0x00007C081B00DC20
00007c081b1ceee3  jmp 0x00007C081B1CEA4D
00007c081b1ceee8  call 0x00007C081B0E27E0
00007c081b1ceeed  jmp 0x00007C081B1CEA5B
00007c081b1ceef2  call 0x00007C081B0E27E0
00007c081b1ceef7  jmp 0x00007C081B1CEA6C
00007c081b1ceefc  ucomisd xmm15, xmm12
00007c081b1cef01  jp 0x00007C081B1CEF10
00007c081b1cef03  movaps xmm11, [0x00007C081ADFE030]
00007c081b1cef0b  jmp 0x00007C081B1CEAA1
00007c081b1cef10  vxorps xmm0, xmm15, xmm12
00007c081b1cef15  pextrw r14d, xmm0, 0x03
00007c081b1cef1b  and r14d, 0x7FF8
00007c081b1cef22  cmp r14d, 0x08
00007c081b1cef26  jnz 0x00007C081B1CEAA1
00007c081b1cef2c  movq r14, xmm12
00007c081b1cef31  shl r14, 0x0D
00007c081b1cef35  jbe 0x00007C081B1CEAA1
00007c081b1cef3b  vorps xmm11, xmm12, [0x00007C081ADFE040]
00007c081b1cef43  jmp 0x00007C081B1CEAA1
00007c081b1cef48  ucomisd xmm15, xmm14
00007c081b1cef4d  jp 0x00007C081B1CEF5C
00007c081b1cef4f  movaps xmm12, [0x00007C081ADFE030]
00007c081b1cef57  jmp 0x00007C081B1CEAD6
00007c081b1cef5c  vxorps xmm0, xmm15, xmm14
00007c081b1cef61  pextrw r14d, xmm0, 0x03
00007c081b1cef67  and r14d, 0x7FF8
00007c081b1cef6e  cmp r14d, 0x08
00007c081b1cef72  jnz 0x00007C081B1CEAD6
00007c081b1cef78  movq r14, xmm14
00007c081b1cef7d  shl r14, 0x0D
00007c081b1cef81  jbe 0x00007C081B1CEAD6
00007c081b1cef87  vorps xmm12, xmm14, [0x00007C081ADFE040]
00007c081b1cef8f  jmp 0x00007C081B1CEAD6
00007c081b1cef94  ucomisd xmm1, xmm15
00007c081b1cef99  jp 0x00007C081B1CEFA8
00007c081b1cef9b  movaps xmm14, [0x00007C081ADFE030]
00007c081b1cefa3  jmp 0x00007C081B1CEB03
00007c081b1cefa8  vxorps xmm0, xmm1, xmm15
00007c081b1cefad  pextrw r14d, xmm0, 0x03
00007c081b1cefb3  and r14d, 0x7FF8
00007c081b1cefba  cmp r14d, 0x08
00007c081b1cefbe  jnz 0x00007C081B1CEB03
00007c081b1cefc4  movq r14, xmm15
00007c081b1cefc9  shl r14, 0x0D
00007c081b1cefcd  jbe 0x00007C081B1CEB03
00007c081b1cefd3  vorps xmm14, xmm15, [0x00007C081ADFE040]
00007c081b1cefdb  jmp 0x00007C081B1CEB03
00007c081b1cefe0  ucomisd xmm1, xmm15
00007c081b1cefe5  jp 0x00007C081B1CEFF4
00007c081b1cefe7  movaps xmm14, [0x00007C081ADFE030]
00007c081b1cefef  jmp 0x00007C081B1CEB30
00007c081b1ceff4  vxorps xmm0, xmm1, xmm15
00007c081b1ceff9  pextrw r14d, xmm0, 0x03
00007c081b1cefff  and r14d, 0x7FF8
00007c081b1cf006  cmp r14d, 0x08
00007c081b1cf00a  jnz 0x00007C081B1CEB30
00007c081b1cf010  movq r14, xmm15
00007c081b1cf015  shl r14, 0x0D
00007c081b1cf019  jbe 0x00007C081B1CEB30
00007c081b1cf01f  vorps xmm14, xmm15, [0x00007C081ADFE040]
00007c081b1cf027  jmp 0x00007C081B1CEB30
00007c081b1cf02c  ucomisd xmm1, xmm15
00007c081b1cf031  jp 0x00007C081B1CF040
00007c081b1cf033  movaps xmm13, [0x00007C081ADFE030]
00007c081b1cf03b  jmp 0x00007C081B1CEB65
00007c081b1cf040  vxorps xmm0, xmm1, xmm15
00007c081b1cf045  pextrw r14d, xmm0, 0x03
00007c081b1cf04b  and r14d, 0x7FF8
00007c081b1cf052  cmp r14d, 0x08
00007c081b1cf056  jnz 0x00007C081B1CEB65
00007c081b1cf05c  movq r14, xmm15
00007c081b1cf061  shl r14, 0x0D
00007c081b1cf065  jbe 0x00007C081B1CEB65
00007c081b1cf06b  vorps xmm13, xmm15, [0x00007C081ADFE040]
00007c081b1cf073  jmp 0x00007C081B1CEB65
00007c081b1cf078  call 0x00007C081B0E27E0
00007c081b1cf07d  jmp 0x00007C081B1CEB76
00007c081b1cf082  ucomisd xmm15, xmm14
00007c081b1cf087  jp 0x00007C081B1CF096
00007c081b1cf089  movaps xmm13, [0x00007C081ADFE030]
00007c081b1cf091  jmp 0x00007C081B1CEBA3
00007c081b1cf096  vxorps xmm0, xmm15, xmm14
00007c081b1cf09b  pextrw r14d, xmm0, 0x03
00007c081b1cf0a1  and r14d, 0x7FF8
00007c081b1cf0a8  cmp r14d, 0x08
00007c081b1cf0ac  jnz 0x00007C081B1CEBA3
00007c081b1cf0b2  movq r14, xmm14
00007c081b1cf0b7  shl r14, 0x0D
00007c081b1cf0bb  jbe 0x00007C081B1CEBA3
00007c081b1cf0c1  vorps xmm13, xmm14, [0x00007C081ADFE040]
00007c081b1cf0c9  jmp 0x00007C081B1CEBA3
00007c081b1cf0ce  ucomisd xmm1, xmm15
00007c081b1cf0d3  jp 0x00007C081B1CF0E2
00007c081b1cf0d5  movaps xmm14, [0x00007C081ADFE030]
00007c081b1cf0dd  jmp 0x00007C081B1CEBD8
00007c081b1cf0e2  vxorps xmm0, xmm1, xmm15
00007c081b1cf0e7  pextrw r14d, xmm0, 0x03
00007c081b1cf0ed  and r14d, 0x7FF8
00007c081b1cf0f4  cmp r14d, 0x08
00007c081b1cf0f8  jnz 0x00007C081B1CEBD8
00007c081b1cf0fe  movq r14, xmm15
00007c081b1cf103  shl r14, 0x0D
00007c081b1cf107  jbe 0x00007C081B1CEBD8
00007c081b1cf10d  vorps xmm14, xmm15, [0x00007C081ADFE040]
00007c081b1cf115  jmp 0x00007C081B1CEBD8
00007c081b1cf11a  call 0x00007C081B0E27E0
00007c081b1cf11f  jmp 0x00007C081B1CEBE9
00007c081b1cf124  ucomisd xmm15, xmm14
00007c081b1cf129  jp 0x00007C081B1CF138
00007c081b1cf12b  movaps xmm13, [0x00007C081ADFE030]
00007c081b1cf133  jmp 0x00007C081B1CEC16
00007c081b1cf138  vxorps xmm0, xmm15, xmm14
00007c081b1cf13d  pextrw r14d, xmm0, 0x03
00007c081b1cf143  and r14d, 0x7FF8
00007c081b1cf14a  cmp r14d, 0x08
00007c081b1cf14e  jnz 0x00007C081B1CEC16
00007c081b1cf154  movq r14, xmm14
00007c081b1cf159  shl r14, 0x0D
00007c081b1cf15d  jbe 0x00007C081B1CEC16
00007c081b1cf163  vorps xmm13, xmm14, [0x00007C081ADFE040]
00007c081b1cf16b  jmp 0x00007C081B1CEC16
00007c081b1cf170  ucomisd xmm1, xmm15
00007c081b1cf175  jp 0x00007C081B1CF184
00007c081b1cf177  movaps xmm14, [0x00007C081ADFE030]
00007c081b1cf17f  jmp 0x00007C081B1CEC4B
00007c081b1cf184  vxorps xmm0, xmm1, xmm15
00007c081b1cf189  pextrw r14d, xmm0, 0x03
00007c081b1cf18f  and r14d, 0x7FF8
00007c081b1cf196  cmp r14d, 0x08
00007c081b1cf19a  jnz 0x00007C081B1CEC4B
00007c081b1cf1a0  movq r14, xmm15
00007c081b1cf1a5  shl r14, 0x0D
00007c081b1cf1a9  jbe 0x00007C081B1CEC4B
00007c081b1cf1af  vorps xmm14, xmm15, [0x00007C081ADFE040]
00007c081b1cf1b7  jmp 0x00007C081B1CEC4B
00007c081b1cf1bc  call 0x00007C081B0E27E0
00007c081b1cf1c1  jmp 0x00007C081B1CEC5C
00007c081b1cf1c6  ucomisd xmm15, xmm14
00007c081b1cf1cb  jp 0x00007C081B1CF1DA
00007c081b1cf1cd  movaps xmm13, [0x00007C081ADFE030]
00007c081b1cf1d5  jmp 0x00007C081B1CEC89
00007c081b1cf1da  vxorps xmm0, xmm15, xmm14
00007c081b1cf1df  pextrw r14d, xmm0, 0x03
00007c081b1cf1e5  and r14d, 0x7FF8
00007c081b1cf1ec  cmp r14d, 0x08
00007c081b1cf1f0  jnz 0x00007C081B1CEC89
00007c081b1cf1f6  movq r14, xmm14
00007c081b1cf1fb  shl r14, 0x0D
00007c081b1cf1ff  jbe 0x00007C081B1CEC89
00007c081b1cf205  vorps xmm13, xmm14, [0x00007C081ADFE040]
00007c081b1cf20d  jmp 0x00007C081B1CEC89
00007c081b1cf212  ucomisd xmm1, xmm15
00007c081b1cf217  jp 0x00007C081B1CF226
00007c081b1cf219  movaps xmm14, [0x00007C081ADFE030]
00007c081b1cf221  jmp 0x00007C081B1CECBE
00007c081b1cf226  vxorps xmm0, xmm1, xmm15
00007c081b1cf22b  pextrw r14d, xmm0, 0x03
00007c081b1cf231  and r14d, 0x7FF8
00007c081b1cf238  cmp r14d, 0x08
00007c081b1cf23c  jnz 0x00007C081B1CECBE
00007c081b1cf242  movq r14, xmm15
00007c081b1cf247  shl r14, 0x0D
00007c081b1cf24b  jbe 0x00007C081B1CECBE
00007c081b1cf251  vorps xmm14, xmm15, [0x00007C081ADFE040]
00007c081b1cf259  jmp 0x00007C081B1CECBE
00007c081b1cf25e  call 0x00007C081B0E27E0
00007c081b1cf263  jmp 0x00007C081B1CECCF
00007c081b1cf268  ucomisd xmm15, xmm14
00007c081b1cf26d  jp 0x00007C081B1CF27C
00007c081b1cf26f  movaps xmm13, [0x00007C081ADFE030]
00007c081b1cf277  jmp 0x00007C081B1CECFC
00007c081b1cf27c  vxorps xmm0, xmm15, xmm14
00007c081b1cf281  pextrw r14d, xmm0, 0x03
00007c081b1cf287  and r14d, 0x7FF8
00007c081b1cf28e  cmp r14d, 0x08
00007c081b1cf292  jnz 0x00007C081B1CECFC
00007c081b1cf298  movq r14, xmm14
00007c081b1cf29d  shl r14, 0x0D
00007c081b1cf2a1  jbe 0x00007C081B1CECFC
00007c081b1cf2a7  vorps xmm13, xmm14, [0x00007C081ADFE040]
00007c081b1cf2af  jmp 0x00007C081B1CECFC
00007c081b1cf2b4  ucomisd xmm1, xmm15
00007c081b1cf2b9  jp 0x00007C081B1CF2C8
00007c081b1cf2bb  movaps xmm14, [0x00007C081ADFE030]
00007c081b1cf2c3  jmp 0x00007C081B1CED31
00007c081b1cf2c8  vxorps xmm0, xmm1, xmm15
00007c081b1cf2cd  pextrw r14d, xmm0, 0x03
00007c081b1cf2d3  and r14d, 0x7FF8
00007c081b1cf2da  cmp r14d, 0x08
00007c081b1cf2de  jnz 0x00007C081B1CED31
00007c081b1cf2e4  movq r14, xmm15
00007c081b1cf2e9  shl r14, 0x0D
00007c081b1cf2ed  jbe 0x00007C081B1CED31
00007c081b1cf2f3  vorps xmm14, xmm15, [0x00007C081ADFE040]
00007c081b1cf2fb  jmp 0x00007C081B1CED31
00007c081b1cf300  call 0x00007C081B0D59C0
00007c081b1cf305  jmp 0x00007C081B1CED42
00007c081b1cf30a  ucomisd xmm15, xmm14
00007c081b1cf30f  jp 0x00007C081B1CF31E
00007c081b1cf311  movaps xmm13, [0x00007C081ADFE030]
00007c081b1cf319  jmp 0x00007C081B1CED77
00007c081b1cf31e  vxorps xmm0, xmm15, xmm14
00007c081b1cf323  pextrw eax, xmm0, 0x03
00007c081b1cf328  and eax, 0x7FF8
00007c081b1cf32d  cmp eax, 0x08
00007c081b1cf330  jnz 0x00007C081B1CED77
00007c081b1cf336  movq rax, xmm14
00007c081b1cf33b  shl rax, 0x0D
00007c081b1cf33f  jbe 0x00007C081B1CED77
00007c081b1cf345  vorps xmm13, xmm14, [0x00007C081ADFE040]
00007c081b1cf34d  jmp 0x00007C081B1CED77
00007c081b1cf352  ucomisd xmm1, xmm15
00007c081b1cf357  jp 0x00007C081B1CF366
00007c081b1cf359  movaps xmm14, [0x00007C081ADFE030]
00007c081b1cf361  jmp 0x00007C081B1CEDAC
00007c081b1cf366  vxorps xmm0, xmm1, xmm15
00007c081b1cf36b  pextrw eax, xmm0, 0x03
00007c081b1cf370  and eax, 0x7FF8
00007c081b1cf375  cmp eax, 0x08
00007c081b1cf378  jnz 0x00007C081B1CEDAC
00007c081b1cf37e  movq rax, xmm15
00007c081b1cf383  shl rax, 0x0D
00007c081b1cf387  jbe 0x00007C081B1CEDAC
00007c081b1cf38d  vorps xmm14, xmm15, [0x00007C081ADFE040]
00007c081b1cf395  jmp 0x00007C081B1CEDAC
00007c081b1cf39a  ucomisd xmm1, xmm15
00007c081b1cf39f  jp 0x00007C081B1CF3AE
00007c081b1cf3a1  movaps xmm14, [0x00007C081ADFE030]
00007c081b1cf3a9  jmp 0x00007C081B1CEDE1
00007c081b1cf3ae  vxorps xmm0, xmm1, xmm15
00007c081b1cf3b3  pextrw eax, xmm0, 0x03
00007c081b1cf3b8  and eax, 0x7FF8
00007c081b1cf3bd  cmp eax, 0x08
00007c081b1cf3c0  jnz 0x00007C081B1CEDE1
00007c081b1cf3c6  movq rax, xmm15
00007c081b1cf3cb  shl rax, 0x0D
00007c081b1cf3cf  jbe 0x00007C081B1CEDE1
00007c081b1cf3d5  vorps xmm14, xmm15, [0x00007C081ADFE040]
00007c081b1cf3dd  jmp 0x00007C081B1CEDE1
00007c081b1cf3e2  call 0x00007C081B0D5EB0
00007c081b1cf3e7  jmp 0x00007C081B1CEDFE
00007c081b1cf3ec  int3
00007c081b1cf3ed  nop [rax], eax
00007c081b1cf3f0  mov rax, [r15+0x48]
00007c081b1cf3f4  mov r14, [r15+0x70]
00007c081b1cf3f8  lea r12, [rax+r14*1]
00007c081b1cf3fc  mov [r15+0x78], r12
00007c081b1cf400  mov rax, [r13+r12*1]
00007c081b1cf405  movq xmm1, rax
00007c081b1cf40a  lea rax, [r12+0x40]
00007c081b1cf40f  mov r11, [r13+rax*1]
00007c081b1cf414  movq xmm15, r11
00007c081b1cf419  lea rax, [r12+0x80]
00007c081b1cf421  mov r11, [r13+rax*1]
00007c081b1cf426  movq xmm14, r11
00007c081b1cf42b  movaps xmm13, [r15+0x120]
00007c081b1cf433  movq rax, xmm13
00007c081b1cf438  movq r11, xmm1
00007c081b1cf43d  vmovq xmm1, rax
00007c081b1cf442  vmovq xmm13, r11
00007c081b1cf447  movaps xmm12, xmm1
00007c081b1cf44b  mulsd xmm12, xmm13
00007c081b1cf450  ucomisd xmm12, xmm12
00007c081b1cf455  jp 0x00007C081B1CF879
00007c081b1cf45b  movq xmm12, xmm12
00007c081b1cf460  movaps xmm1, [r15+0x130]
00007c081b1cf468  movq rax, xmm1
00007c081b1cf46d  movq r11, xmm15
00007c081b1cf472  vmovq xmm1, rax
00007c081b1cf477  vmovq xmm15, r11
00007c081b1cf47c  movaps xmm13, xmm1
00007c081b1cf480  mulsd xmm13, xmm15
00007c081b1cf485  ucomisd xmm13, xmm13
00007c081b1cf48a  jp 0x00007C081B1CF8C1
00007c081b1cf490  movq xmm13, xmm13
00007c081b1cf495  movq rax, xmm12
00007c081b1cf49a  movaps xmm1, [r15+0x110]
00007c081b1cf4a2  movq r11, xmm1
00007c081b1cf4a7  vmovq xmm1, rax
00007c081b1cf4ac  vmovq xmm15, r11
00007c081b1cf4b1  movaps xmm12, xmm1
00007c081b1cf4b5  addsd xmm12, xmm15
00007c081b1cf4ba  ucomisd xmm12, xmm12
00007c081b1cf4bf  jp 0x00007C081B1CF909
00007c081b1cf4c5  movq xmm12, xmm12
00007c081b1cf4ca  movq rax, xmm12
00007c081b1cf4cf  movq r11, xmm13
00007c081b1cf4d4  vmovq xmm1, rax
00007c081b1cf4d9  vmovq xmm15, r11
00007c081b1cf4de  movaps xmm13, xmm1
00007c081b1cf4e2  addsd xmm13, xmm15
00007c081b1cf4e7  ucomisd xmm13, xmm13
00007c081b1cf4ec  jp 0x00007C081B1CF951
00007c081b1cf4f2  movq xmm13, xmm13
00007c081b1cf4f7  movaps xmm1, [r15+0x140]
00007c081b1cf4ff  movq rax, xmm1
00007c081b1cf504  movq r11, xmm14
00007c081b1cf509  vmovq xmm1, rax
00007c081b1cf50e  vmovq xmm15, r11
00007c081b1cf513  movaps xmm14, xmm1
00007c081b1cf517  mulsd xmm14, xmm15
00007c081b1cf51c  ucomisd xmm14, xmm14
00007c081b1cf521  jp 0x00007C081B1CF999
00007c081b1cf527  movq xmm14, xmm14
00007c081b1cf52c  lea rax, [r12+0xC0]
00007c081b1cf534  mov r11, [r13+rax*1]
00007c081b1cf539  movq xmm1, r11
00007c081b1cf53e  movq rax, xmm13
00007c081b1cf543  movq r11, xmm14
00007c081b1cf548  vmovq xmm15, rax
00007c081b1cf54d  vmovq xmm14, r11
00007c081b1cf552  movaps xmm13, xmm15
00007c081b1cf556  addsd xmm13, xmm14
00007c081b1cf55b  ucomisd xmm13, xmm13
00007c081b1cf560  jp 0x00007C081B1CF9EB
00007c081b1cf566  movq xmm13, xmm13
00007c081b1cf56b  movaps xmm15, [r15+0x150]
00007c081b1cf573  movq rax, xmm15
00007c081b1cf578  movq r11, xmm1
00007c081b1cf57d  vmovq xmm1, rax
00007c081b1cf582  vmovq xmm15, r11
00007c081b1cf587  movaps xmm14, xmm1
00007c081b1cf58b  mulsd xmm14, xmm15
00007c081b1cf590  ucomisd xmm14, xmm14
00007c081b1cf595  jp 0x00007C081B1CFA33
00007c081b1cf59b  movq xmm14, xmm14
00007c081b1cf5a0  lea rax, [r12+0x100]
00007c081b1cf5a8  mov r11, [r13+rax*1]
00007c081b1cf5ad  movq xmm1, r11
00007c081b1cf5b2  movq rax, xmm13
00007c081b1cf5b7  movq r11, xmm14
00007c081b1cf5bc  vmovq xmm15, rax
00007c081b1cf5c1  vmovq xmm14, r11
00007c081b1cf5c6  movaps xmm13, xmm15
00007c081b1cf5ca  addsd xmm13, xmm14
00007c081b1cf5cf  ucomisd xmm13, xmm13
00007c081b1cf5d4  jp 0x00007C081B1CFA85
00007c081b1cf5da  movq xmm13, xmm13
00007c081b1cf5df  movaps xmm15, [r15+0x160]
00007c081b1cf5e7  movq rax, xmm15
00007c081b1cf5ec  movq r11, xmm1
00007c081b1cf5f1  vmovq xmm1, rax
00007c081b1cf5f6  vmovq xmm15, r11
00007c081b1cf5fb  movaps xmm14, xmm1
00007c081b1cf5ff  mulsd xmm14, xmm15
00007c081b1cf604  ucomisd xmm14, xmm14
00007c081b1cf609  jp 0x00007C081B1CFACD
00007c081b1cf60f  movq xmm14, xmm14
00007c081b1cf614  lea rax, [r12+0x140]
00007c081b1cf61c  mov r11, [r13+rax*1]
00007c081b1cf621  movq xmm1, r11
00007c081b1cf626  movq rax, xmm13
00007c081b1cf62b  movq r11, xmm14
00007c081b1cf630  vmovq xmm15, rax
00007c081b1cf635  vmovq xmm14, r11
00007c081b1cf63a  movaps xmm13, xmm15
00007c081b1cf63e  addsd xmm13, xmm14
00007c081b1cf643  ucomisd xmm13, xmm13
00007c081b1cf648  jp 0x00007C081B1CFB1F
00007c081b1cf64e  movq xmm13, xmm13
00007c081b1cf653  movaps xmm15, [r15+0x170]
00007c081b1cf65b  movq rax, xmm15
00007c081b1cf660  movq r11, xmm1
00007c081b1cf665  vmovq xmm1, rax
00007c081b1cf66a  vmovq xmm15, r11
00007c081b1cf66f  movaps xmm14, xmm1
00007c081b1cf673  mulsd xmm14, xmm15
00007c081b1cf678  ucomisd xmm14, xmm14
00007c081b1cf67d  jp 0x00007C081B1CFB67
00007c081b1cf683  movq xmm14, xmm14
00007c081b1cf688  lea rax, [r12+0x180]
00007c081b1cf690  mov r11, [r13+rax*1]
00007c081b1cf695  movq xmm1, r11
00007c081b1cf69a  movq rax, xmm13
00007c081b1cf69f  movq r11, xmm14
00007c081b1cf6a4  vmovq xmm15, rax
00007c081b1cf6a9  vmovq xmm14, r11
00007c081b1cf6ae  movaps xmm13, xmm15
00007c081b1cf6b2  addsd xmm13, xmm14
00007c081b1cf6b7  ucomisd xmm13, xmm13
00007c081b1cf6bc  jp 0x00007C081B1CFBB9
00007c081b1cf6c2  movq xmm13, xmm13
00007c081b1cf6c7  movaps xmm15, [r15+0x180]
00007c081b1cf6cf  movq rax, xmm15
00007c081b1cf6d4  movq r11, xmm1
00007c081b1cf6d9  vmovq xmm1, rax
00007c081b1cf6de  vmovq xmm15, r11
00007c081b1cf6e3  movaps xmm14, xmm1
00007c081b1cf6e7  mulsd xmm14, xmm15
00007c081b1cf6ec  ucomisd xmm14, xmm14
00007c081b1cf6f1  jp 0x00007C081B1CFC01
00007c081b1cf6f7  movq xmm14, xmm14
00007c081b1cf6fc  lea rax, [r12+0x1C0]
00007c081b1cf704  mov r12, [r13+rax*1]
00007c081b1cf709  movq xmm1, r12
00007c081b1cf70e  movaps [r15+0x240], xmm1
00007c081b1cf716  movq rax, xmm13
00007c081b1cf71b  movq r12, xmm14
00007c081b1cf720  vmovq xmm15, rax
00007c081b1cf725  vmovq xmm14, r12
00007c081b1cf72a  movaps xmm13, xmm15
00007c081b1cf72e  addsd xmm13, xmm14
00007c081b1cf733  ucomisd xmm13, xmm13
00007c081b1cf738  jp 0x00007C081B1CFC53
00007c081b1cf73e  movq xmm13, xmm13
00007c081b1cf743  movaps xmm15, [r15+0x210]
00007c081b1cf74b  movq rax, xmm15
00007c081b1cf750  movq r12, xmm1
00007c081b1cf755  vmovq xmm1, rax
00007c081b1cf75a  vmovq xmm15, r12
00007c081b1cf75f  movaps xmm14, xmm1
00007c081b1cf763  mulsd xmm14, xmm15
00007c081b1cf768  ucomisd xmm14, xmm14
00007c081b1cf76d  jp 0x00007C081B1CFC9B
00007c081b1cf773  movq xmm14, xmm14
00007c081b1cf778  movaps [r15+0x230], xmm14
00007c081b1cf780  movq rax, xmm13
00007c081b1cf785  movq r12, xmm14
00007c081b1cf78a  vmovq xmm1, rax
00007c081b1cf78f  vmovq xmm15, r12
00007c081b1cf794  movaps xmm14, xmm1
00007c081b1cf798  addsd xmm14, xmm15
00007c081b1cf79d  ucomisd xmm14, xmm14
00007c081b1cf7a2  jp 0x00007C081B1CFCE3
00007c081b1cf7a8  movq xmm14, xmm14
00007c081b1cf7ad  movaps [r15+0x220], xmm14
00007c081b1cf7b5  mov rax, [r15+0x68]
00007c081b1cf7b9  lea r12, [rax+r14*1]
00007c081b1cf7bd  movq rax, xmm14
00007c081b1cf7c2  mov [r13+r12*1], rax
00007c081b1cf7c7  lea rax, [r14+0x08]
00007c081b1cf7cb  mov [r15+0x70], rax
00007c081b1cf7cf  mov [rsp+0x10], rax
00007c081b1cf7d4  xor eax, eax
00007c081b1cf7d6  mov r14, [rsp+0x10]
00007c081b1cf7db  mov r12d, 0x40
00007c081b1cf7e1  cmp r14, r12
00007c081b1cf7e4  cmc
00007c081b1cf7e5  lahf
00007c081b1cf7e6  seto al
00007c081b1cf7e9  mov [r15+0x108], eax
00007c081b1cf7f0  mov eax, [r15+0x108]
00007c081b1cf7f7  sahf
00007c081b1cf7f8  jnz 0x00007C081B1CF82A
00007c081b1cf7fa  cmp dword ptr [r15+0x318], 0x00
00007c081b1cf802  jz 0x00007C081B1CFD40
00007c081b1cf808  nop [rax+rax*1], ax
00007c081b1cf811  nop [rax+rax*1], eax
00007c081b1cf819  mov eax, 0x410118
00007c081b1cf81e  mov [r15+0x100], rax
00007c081b1cf825  jmp 0x00007C081AFFE110
00007c081b1cf82a  cmp dword ptr [r15+0x318], 0x00
00007c081b1cf832  jz 0x00007C081B1CF3F0
00007c081b1cf838  nop [rax+rax*1], ax
00007c081b1cf841  nop [rax+rax*1], eax
00007c081b1cf849  mov eax, 0x4100A4
00007c081b1cf84e  mov [r15+0x100], rax
00007c081b1cf855  jmp 0x00007C081AFFE110
00007c081b1cf85a  int3
00007c081b1cf85b  call 0x00007C081B0B47C0
00007c081b1cf860  jmp 0x00007C081B1CF405
00007c081b1cf865  call 0x00007C081B00A4B0
00007c081b1cf86a  jmp 0x00007C081B1CF414
00007c081b1cf86f  call 0x00007C081B00A4B0
00007c081b1cf874  jmp 0x00007C081B1CF426
00007c081b1cf879  ucomisd xmm1, xmm13
00007c081b1cf87e  jp 0x00007C081B1CF88D
00007c081b1cf880  movaps xmm12, [0x00007C081ADFE030]
00007c081b1cf888  jmp 0x00007C081B1CF45B
00007c081b1cf88d  vxorps xmm0, xmm1, xmm13
00007c081b1cf892  pextrw eax, xmm0, 0x03
00007c081b1cf897  and eax, 0x7FF8
00007c081b1cf89c  cmp eax, 0x08
00007c081b1cf89f  jnz 0x00007C081B1CF45B
00007c081b1cf8a5  movq rax, xmm13
00007c081b1cf8aa  shl rax, 0x0D
00007c081b1cf8ae  jbe 0x00007C081B1CF45B
00007c081b1cf8b4  vorps xmm12, xmm13, [0x00007C081ADFE040]
00007c081b1cf8bc  jmp 0x00007C081B1CF45B
00007c081b1cf8c1  ucomisd xmm1, xmm15
00007c081b1cf8c6  jp 0x00007C081B1CF8D5
00007c081b1cf8c8  movaps xmm13, [0x00007C081ADFE030]
00007c081b1cf8d0  jmp 0x00007C081B1CF490
00007c081b1cf8d5  vxorps xmm0, xmm1, xmm15
00007c081b1cf8da  pextrw eax, xmm0, 0x03
00007c081b1cf8df  and eax, 0x7FF8
00007c081b1cf8e4  cmp eax, 0x08
00007c081b1cf8e7  jnz 0x00007C081B1CF490
00007c081b1cf8ed  movq rax, xmm15
00007c081b1cf8f2  shl rax, 0x0D
00007c081b1cf8f6  jbe 0x00007C081B1CF490
00007c081b1cf8fc  vorps xmm13, xmm15, [0x00007C081ADFE040]
00007c081b1cf904  jmp 0x00007C081B1CF490
00007c081b1cf909  ucomisd xmm1, xmm15
00007c081b1cf90e  jp 0x00007C081B1CF91D
00007c081b1cf910  movaps xmm12, [0x00007C081ADFE030]
00007c081b1cf918  jmp 0x00007C081B1CF4C5
00007c081b1cf91d  vxorps xmm0, xmm1, xmm15
00007c081b1cf922  pextrw eax, xmm0, 0x03
00007c081b1cf927  and eax, 0x7FF8
00007c081b1cf92c  cmp eax, 0x08
00007c081b1cf92f  jnz 0x00007C081B1CF4C5
00007c081b1cf935  movq rax, xmm15
00007c081b1cf93a  shl rax, 0x0D
00007c081b1cf93e  jbe 0x00007C081B1CF4C5
00007c081b1cf944  vorps xmm12, xmm15, [0x00007C081ADFE040]
00007c081b1cf94c  jmp 0x00007C081B1CF4C5
00007c081b1cf951  ucomisd xmm1, xmm15
00007c081b1cf956  jp 0x00007C081B1CF965
00007c081b1cf958  movaps xmm13, [0x00007C081ADFE030]
00007c081b1cf960  jmp 0x00007C081B1CF4F2
00007c081b1cf965  vxorps xmm0, xmm1, xmm15
00007c081b1cf96a  pextrw eax, xmm0, 0x03
00007c081b1cf96f  and eax, 0x7FF8
00007c081b1cf974  cmp eax, 0x08
00007c081b1cf977  jnz 0x00007C081B1CF4F2
00007c081b1cf97d  movq rax, xmm15
00007c081b1cf982  shl rax, 0x0D
00007c081b1cf986  jbe 0x00007C081B1CF4F2
00007c081b1cf98c  vorps xmm13, xmm15, [0x00007C081ADFE040]
00007c081b1cf994  jmp 0x00007C081B1CF4F2
00007c081b1cf999  ucomisd xmm1, xmm15
00007c081b1cf99e  jp 0x00007C081B1CF9AD
00007c081b1cf9a0  movaps xmm14, [0x00007C081ADFE030]
00007c081b1cf9a8  jmp 0x00007C081B1CF527
00007c081b1cf9ad  vxorps xmm0, xmm1, xmm15
00007c081b1cf9b2  pextrw eax, xmm0, 0x03
00007c081b1cf9b7  and eax, 0x7FF8
00007c081b1cf9bc  cmp eax, 0x08
00007c081b1cf9bf  jnz 0x00007C081B1CF527
00007c081b1cf9c5  movq rax, xmm15
00007c081b1cf9ca  shl rax, 0x0D
00007c081b1cf9ce  jbe 0x00007C081B1CF527
00007c081b1cf9d4  vorps xmm14, xmm15, [0x00007C081ADFE040]
00007c081b1cf9dc  jmp 0x00007C081B1CF527
00007c081b1cf9e1  call 0x00007C081B00A4B0
00007c081b1cf9e6  jmp 0x00007C081B1CF539
00007c081b1cf9eb  ucomisd xmm15, xmm14
00007c081b1cf9f0  jp 0x00007C081B1CF9FF
00007c081b1cf9f2  movaps xmm13, [0x00007C081ADFE030]
00007c081b1cf9fa  jmp 0x00007C081B1CF566
00007c081b1cf9ff  vxorps xmm0, xmm15, xmm14
00007c081b1cfa04  pextrw eax, xmm0, 0x03
00007c081b1cfa09  and eax, 0x7FF8
00007c081b1cfa0e  cmp eax, 0x08
00007c081b1cfa11  jnz 0x00007C081B1CF566
00007c081b1cfa17  movq rax, xmm14
00007c081b1cfa1c  shl rax, 0x0D
00007c081b1cfa20  jbe 0x00007C081B1CF566
00007c081b1cfa26  vorps xmm13, xmm14, [0x00007C081ADFE040]
00007c081b1cfa2e  jmp 0x00007C081B1CF566
00007c081b1cfa33  ucomisd xmm1, xmm15
00007c081b1cfa38  jp 0x00007C081B1CFA47
00007c081b1cfa3a  movaps xmm14, [0x00007C081ADFE030]
00007c081b1cfa42  jmp 0x00007C081B1CF59B
00007c081b1cfa47  vxorps xmm0, xmm1, xmm15
00007c081b1cfa4c  pextrw eax, xmm0, 0x03
00007c081b1cfa51  and eax, 0x7FF8
00007c081b1cfa56  cmp eax, 0x08
00007c081b1cfa59  jnz 0x00007C081B1CF59B
00007c081b1cfa5f  movq rax, xmm15
00007c081b1cfa64  shl rax, 0x0D
00007c081b1cfa68  jbe 0x00007C081B1CF59B
00007c081b1cfa6e  vorps xmm14, xmm15, [0x00007C081ADFE040]
00007c081b1cfa76  jmp 0x00007C081B1CF59B
00007c081b1cfa7b  call 0x00007C081B00A4B0
00007c081b1cfa80  jmp 0x00007C081B1CF5AD
00007c081b1cfa85  ucomisd xmm15, xmm14
00007c081b1cfa8a  jp 0x00007C081B1CFA99
00007c081b1cfa8c  movaps xmm13, [0x00007C081ADFE030]
00007c081b1cfa94  jmp 0x00007C081B1CF5DA
00007c081b1cfa99  vxorps xmm0, xmm15, xmm14
00007c081b1cfa9e  pextrw eax, xmm0, 0x03
00007c081b1cfaa3  and eax, 0x7FF8
00007c081b1cfaa8  cmp eax, 0x08
00007c081b1cfaab  jnz 0x00007C081B1CF5DA
00007c081b1cfab1  movq rax, xmm14
00007c081b1cfab6  shl rax, 0x0D
00007c081b1cfaba  jbe 0x00007C081B1CF5DA
00007c081b1cfac0  vorps xmm13, xmm14, [0x00007C081ADFE040]
00007c081b1cfac8  jmp 0x00007C081B1CF5DA
00007c081b1cfacd  ucomisd xmm1, xmm15
00007c081b1cfad2  jp 0x00007C081B1CFAE1
00007c081b1cfad4  movaps xmm14, [0x00007C081ADFE030]
00007c081b1cfadc  jmp 0x00007C081B1CF60F
00007c081b1cfae1  vxorps xmm0, xmm1, xmm15
00007c081b1cfae6  pextrw eax, xmm0, 0x03
00007c081b1cfaeb  and eax, 0x7FF8
00007c081b1cfaf0  cmp eax, 0x08
00007c081b1cfaf3  jnz 0x00007C081B1CF60F
00007c081b1cfaf9  movq rax, xmm15
00007c081b1cfafe  shl rax, 0x0D
00007c081b1cfb02  jbe 0x00007C081B1CF60F
00007c081b1cfb08  vorps xmm14, xmm15, [0x00007C081ADFE040]
00007c081b1cfb10  jmp 0x00007C081B1CF60F
00007c081b1cfb15  call 0x00007C081B00A4B0
00007c081b1cfb1a  jmp 0x00007C081B1CF621
00007c081b1cfb1f  ucomisd xmm15, xmm14
00007c081b1cfb24  jp 0x00007C081B1CFB33
00007c081b1cfb26  movaps xmm13, [0x00007C081ADFE030]
00007c081b1cfb2e  jmp 0x00007C081B1CF64E
00007c081b1cfb33  vxorps xmm0, xmm15, xmm14
00007c081b1cfb38  pextrw eax, xmm0, 0x03
00007c081b1cfb3d  and eax, 0x7FF8
00007c081b1cfb42  cmp eax, 0x08
00007c081b1cfb45  jnz 0x00007C081B1CF64E
00007c081b1cfb4b  movq rax, xmm14
00007c081b1cfb50  shl rax, 0x0D
00007c081b1cfb54  jbe 0x00007C081B1CF64E
00007c081b1cfb5a  vorps xmm13, xmm14, [0x00007C081ADFE040]
00007c081b1cfb62  jmp 0x00007C081B1CF64E
00007c081b1cfb67  ucomisd xmm1, xmm15
00007c081b1cfb6c  jp 0x00007C081B1CFB7B
00007c081b1cfb6e  movaps xmm14, [0x00007C081ADFE030]
00007c081b1cfb76  jmp 0x00007C081B1CF683
00007c081b1cfb7b  vxorps xmm0, xmm1, xmm15
00007c081b1cfb80  pextrw eax, xmm0, 0x03
00007c081b1cfb85  and eax, 0x7FF8
00007c081b1cfb8a  cmp eax, 0x08
00007c081b1cfb8d  jnz 0x00007C081B1CF683
00007c081b1cfb93  movq rax, xmm15
00007c081b1cfb98  shl rax, 0x0D
00007c081b1cfb9c  jbe 0x00007C081B1CF683
00007c081b1cfba2  vorps xmm14, xmm15, [0x00007C081ADFE040]
00007c081b1cfbaa  jmp 0x00007C081B1CF683
00007c081b1cfbaf  call 0x00007C081B00A4B0
00007c081b1cfbb4  jmp 0x00007C081B1CF695
00007c081b1cfbb9  ucomisd xmm15, xmm14
00007c081b1cfbbe  jp 0x00007C081B1CFBCD
00007c081b1cfbc0  movaps xmm13, [0x00007C081ADFE030]
00007c081b1cfbc8  jmp 0x00007C081B1CF6C2
00007c081b1cfbcd  vxorps xmm0, xmm15, xmm14
00007c081b1cfbd2  pextrw eax, xmm0, 0x03
00007c081b1cfbd7  and eax, 0x7FF8
00007c081b1cfbdc  cmp eax, 0x08
00007c081b1cfbdf  jnz 0x00007C081B1CF6C2
00007c081b1cfbe5  movq rax, xmm14
00007c081b1cfbea  shl rax, 0x0D
00007c081b1cfbee  jbe 0x00007C081B1CF6C2
00007c081b1cfbf4  vorps xmm13, xmm14, [0x00007C081ADFE040]
00007c081b1cfbfc  jmp 0x00007C081B1CF6C2
00007c081b1cfc01  ucomisd xmm1, xmm15
00007c081b1cfc06  jp 0x00007C081B1CFC15
00007c081b1cfc08  movaps xmm14, [0x00007C081ADFE030]
00007c081b1cfc10  jmp 0x00007C081B1CF6F7
00007c081b1cfc15  vxorps xmm0, xmm1, xmm15
00007c081b1cfc1a  pextrw eax, xmm0, 0x03
00007c081b1cfc1f  and eax, 0x7FF8
00007c081b1cfc24  cmp eax, 0x08
00007c081b1cfc27  jnz 0x00007C081B1CF6F7
00007c081b1cfc2d  movq rax, xmm15
00007c081b1cfc32  shl rax, 0x0D
00007c081b1cfc36  jbe 0x00007C081B1CF6F7
00007c081b1cfc3c  vorps xmm14, xmm15, [0x00007C081ADFE040]
00007c081b1cfc44  jmp 0x00007C081B1CF6F7
00007c081b1cfc49  call 0x00007C081B00B720
00007c081b1cfc4e  jmp 0x00007C081B1CF709
00007c081b1cfc53  ucomisd xmm15, xmm14
00007c081b1cfc58  jp 0x00007C081B1CFC67
00007c081b1cfc5a  movaps xmm13, [0x00007C081ADFE030]
00007c081b1cfc62  jmp 0x00007C081B1CF73E
00007c081b1cfc67  vxorps xmm0, xmm15, xmm14
00007c081b1cfc6c  pextrw eax, xmm0, 0x03
00007c081b1cfc71  and eax, 0x7FF8
00007c081b1cfc76  cmp eax, 0x08
00007c081b1cfc79  jnz 0x00007C081B1CF73E
00007c081b1cfc7f  movq rax, xmm14
00007c081b1cfc84  shl rax, 0x0D
00007c081b1cfc88  jbe 0x00007C081B1CF73E
00007c081b1cfc8e  vorps xmm13, xmm14, [0x00007C081ADFE040]
00007c081b1cfc96  jmp 0x00007C081B1CF73E
00007c081b1cfc9b  ucomisd xmm1, xmm15
00007c081b1cfca0  jp 0x00007C081B1CFCAF
00007c081b1cfca2  movaps xmm14, [0x00007C081ADFE030]
00007c081b1cfcaa  jmp 0x00007C081B1CF773
00007c081b1cfcaf  vxorps xmm0, xmm1, xmm15
00007c081b1cfcb4  pextrw eax, xmm0, 0x03
00007c081b1cfcb9  and eax, 0x7FF8
00007c081b1cfcbe  cmp eax, 0x08
00007c081b1cfcc1  jnz 0x00007C081B1CF773
00007c081b1cfcc7  movq rax, xmm15
00007c081b1cfccc  shl rax, 0x0D
00007c081b1cfcd0  jbe 0x00007C081B1CF773
00007c081b1cfcd6  vorps xmm14, xmm15, [0x00007C081ADFE040]
00007c081b1cfcde  jmp 0x00007C081B1CF773
00007c081b1cfce3  ucomisd xmm1, xmm15
00007c081b1cfce8  jp 0x00007C081B1CFCF7
00007c081b1cfcea  movaps xmm14, [0x00007C081ADFE030]
00007c081b1cfcf2  jmp 0x00007C081B1CF7A8
00007c081b1cfcf7  vxorps xmm0, xmm1, xmm15
00007c081b1cfcfc  pextrw eax, xmm0, 0x03
00007c081b1cfd01  and eax, 0x7FF8
00007c081b1cfd06  cmp eax, 0x08
00007c081b1cfd09  jnz 0x00007C081B1CF7A8
00007c081b1cfd0f  movq rax, xmm15
00007c081b1cfd14  shl rax, 0x0D
00007c081b1cfd18  jbe 0x00007C081B1CF7A8
00007c081b1cfd1e  vorps xmm14, xmm15, [0x00007C081ADFE040]
00007c081b1cfd26  jmp 0x00007C081B1CF7A8
00007c081b1cfd2b  call 0x00007C081B0B4CB0
00007c081b1cfd30  jmp 0x00007C081B1CF7C7
00007c081b1cfd35  int3
00007c081b1cfd36  nop [rax+rax*1], ax
00007c081b1cfd3f  nop
00007c081b1cfd40  mov rax, [r15+0x60]
00007c081b1cfd44  lea r14, [rax+0x01]
00007c081b1cfd48  mov [r15+0x60], r14
00007c081b1cfd4c  mov rax, [r15+0x68]
00007c081b1cfd50  lea r12, [rax+0x40]
00007c081b1cfd54  mov [r15+0x68], r12
00007c081b1cfd58  xor eax, eax
00007c081b1cfd5a  mov r12d, 0x08
00007c081b1cfd60  cmp r14, r12
00007c081b1cfd63  cmc
00007c081b1cfd64  lahf
00007c081b1cfd65  seto al
00007c081b1cfd68  mov [r15+0x108], eax
00007c081b1cfd6f  mov eax, [r15+0x108]
00007c081b1cfd76  sahf
00007c081b1cfd77  jnz 0x00007C081B1CFDA9
00007c081b1cfd79  cmp dword ptr [r15+0x318], 0x00
00007c081b1cfd81  jz 0x00007C081B1D08A0
00007c081b1cfd87  nop [rax+rax*1], ax
00007c081b1cfd90  nop [rax+rax*1], eax
00007c081b1cfd98  mov eax, 0x410128
00007c081b1cfd9d  mov [r15+0x100], rax
00007c081b1cfda4  jmp 0x00007C081AFFE110
00007c081b1cfda9  cmp dword ptr [r15+0x318], 0x00
00007c081b1cfdb1  jz 0x00007C081B1CFDE0
00007c081b1cfdb7  nop [rax+rax*1], ax
00007c081b1cfdc0  nop [rax+rax*1], eax
00007c081b1cfdc8  mov eax, 0x41008C
00007c081b1cfdcd  mov [r15+0x100], rax
00007c081b1cfdd4  jmp 0x00007C081AFFE110
00007c081b1cfdd9  int3
00007c081b1cfdda  int3
00007c081b1cfddb  nop [rax+rax*1], eax
00007c081b1cfde0  mov rax, [r15+0x40]
00007c081b1cfde4  mov r14, [r15+0x60]
00007c081b1cfde8  shl r14, 0x06
00007c081b1cfdec  lea r12, [rax+r14*1]
00007c081b1cfdf0  mov rax, [r13+r12*1]
00007c081b1cfdf5  lea r14, [r12+0x08]
00007c081b1cfdfa  mov r11, [r13+r14*1]
00007c081b1cfdff  movq xmm1, rax
00007c081b1cfe04  movq xmm15, r11
00007c081b1cfe09  movq xmm1, xmm1
00007c081b1cfe0d  movq xmm1, xmm1
00007c081b1cfe11  movaps [r15+0x120], xmm1
00007c081b1cfe19  movq xmm15, xmm15
00007c081b1cfe1e  movq xmm15, xmm15
00007c081b1cfe23  movaps [r15+0x130], xmm15
00007c081b1cfe2b  lea rax, [r12+0x10]
00007c081b1cfe30  mov r14, [r13+rax*1]
00007c081b1cfe35  lea rax, [r12+0x18]
00007c081b1cfe3a  mov r11, [r13+rax*1]
00007c081b1cfe3f  movq xmm1, r14
00007c081b1cfe44  movq xmm15, r11
00007c081b1cfe49  movq xmm1, xmm1
00007c081b1cfe4d  movq xmm1, xmm1
00007c081b1cfe51  movaps [r15+0x140], xmm1
00007c081b1cfe59  movq xmm15, xmm15
00007c081b1cfe5e  movq xmm15, xmm15
00007c081b1cfe63  movaps [r15+0x150], xmm15
00007c081b1cfe6b  lea rax, [r12+0x20]
00007c081b1cfe70  mov r14, [r13+rax*1]
00007c081b1cfe75  lea rax, [r12+0x28]
00007c081b1cfe7a  mov r11, [r13+rax*1]
00007c081b1cfe7f  movq xmm1, r14
00007c081b1cfe84  movq xmm15, r11
00007c081b1cfe89  movq xmm1, xmm1
00007c081b1cfe8d  movq xmm1, xmm1
00007c081b1cfe91  movaps [r15+0x160], xmm1
00007c081b1cfe99  movq xmm15, xmm15
00007c081b1cfe9e  movq xmm15, xmm15
00007c081b1cfea3  movaps [r15+0x170], xmm15
00007c081b1cfeab  lea rax, [r12+0x30]
00007c081b1cfeb0  mov r14, [r13+rax*1]
00007c081b1cfeb5  lea rax, [r12+0x38]
00007c081b1cfeba  mov r12, [r13+rax*1]
00007c081b1cfebf  movq xmm1, r14
00007c081b1cfec4  movq xmm15, r12
00007c081b1cfec9  movq xmm1, xmm1
00007c081b1cfecd  movq xmm1, xmm1
00007c081b1cfed1  movaps [r15+0x180], xmm1
00007c081b1cfed9  movq xmm15, xmm15
00007c081b1cfede  movq xmm15, xmm15
00007c081b1cfee3  movaps [r15+0x210], xmm15
00007c081b1cfeeb  mov rax, [r15+0x48]
00007c081b1cfeef  mov [r15+0x78], rax
00007c081b1cfef3  mov r14, [r13+rax*1]
00007c081b1cfef8  movq xmm1, r14
00007c081b1cfefd  lea r14, [rax+0x40]
00007c081b1cff01  mov r12, [r13+r14*1]
00007c081b1cff06  movq xmm15, r12
00007c081b1cff0b  lea r14, [rax+0x80]
00007c081b1cff12  mov r12, [r13+r14*1]
00007c081b1cff17  movq xmm14, r12
00007c081b1cff1c  movaps xmm13, [r15+0x120]
00007c081b1cff24  movq r14, xmm13
00007c081b1cff29  movq r12, xmm1
00007c081b1cff2e  vmovq xmm1, r14
00007c081b1cff33  vmovq xmm13, r12
00007c081b1cff38  movaps xmm12, xmm1
00007c081b1cff3c  mulsd xmm12, xmm13
00007c081b1cff41  ucomisd xmm12, xmm12
00007c081b1cff46  jp 0x00007C081B1D03AD
00007c081b1cff4c  movq xmm12, xmm12
00007c081b1cff51  movaps xmm1, [r15+0x130]
00007c081b1cff59  movq r14, xmm1
00007c081b1cff5e  movq r12, xmm15
00007c081b1cff63  vmovq xmm1, r14
00007c081b1cff68  vmovq xmm15, r12
00007c081b1cff6d  movaps xmm13, xmm1
00007c081b1cff71  mulsd xmm13, xmm15
00007c081b1cff76  ucomisd xmm13, xmm13
00007c081b1cff7b  jp 0x00007C081B1D03F9
00007c081b1cff81  movq xmm13, xmm13
00007c081b1cff86  movq r14, xmm12
00007c081b1cff8b  movaps xmm1, [r15+0x110]
00007c081b1cff93  movq r12, xmm1
00007c081b1cff98  vmovq xmm1, r14
00007c081b1cff9d  vmovq xmm15, r12
00007c081b1cffa2  movaps xmm12, xmm1
00007c081b1cffa6  addsd xmm12, xmm15
00007c081b1cffab  ucomisd xmm12, xmm12
00007c081b1cffb0  jp 0x00007C081B1D0445
00007c081b1cffb6  movq xmm12, xmm12
00007c081b1cffbb  movq r14, xmm12
00007c081b1cffc0  movq r12, xmm13
00007c081b1cffc5  vmovq xmm1, r14
00007c081b1cffca  vmovq xmm15, r12
00007c081b1cffcf  movaps xmm13, xmm1
00007c081b1cffd3  addsd xmm13, xmm15
00007c081b1cffd8  ucomisd xmm13, xmm13
00007c081b1cffdd  jp 0x00007C081B1D0491
00007c081b1cffe3  movq xmm13, xmm13
00007c081b1cffe8  movaps xmm1, [r15+0x140]
00007c081b1cfff0  movq r14, xmm1
00007c081b1cfff5  movq r12, xmm14
00007c081b1cfffa  vmovq xmm1, r14
00007c081b1cffff  vmovq xmm15, r12
00007c081b1d0004  movaps xmm14, xmm1
00007c081b1d0008  mulsd xmm14, xmm15
00007c081b1d000d  ucomisd xmm14, xmm14
00007c081b1d0012  jp 0x00007C081B1D04DD
00007c081b1d0018  movq xmm14, xmm14
00007c081b1d001d  lea r14, [rax+0xC0]
00007c081b1d0024  mov r12, [r13+r14*1]
00007c081b1d0029  movq xmm1, r12
00007c081b1d002e  movq r14, xmm13
00007c081b1d0033  movq r12, xmm14
00007c081b1d0038  vmovq xmm15, r14
00007c081b1d003d  vmovq xmm14, r12
00007c081b1d0042  movaps xmm13, xmm15
00007c081b1d0046  addsd xmm13, xmm14
00007c081b1d004b  ucomisd xmm13, xmm13
00007c081b1d0050  jp 0x00007C081B1D0533
00007c081b1d0056  movq xmm13, xmm13
00007c081b1d005b  movaps xmm15, [r15+0x150]
00007c081b1d0063  movq r14, xmm15
00007c081b1d0068  movq r12, xmm1
00007c081b1d006d  vmovq xmm1, r14
00007c081b1d0072  vmovq xmm15, r12
00007c081b1d0077  movaps xmm14, xmm1
00007c081b1d007b  mulsd xmm14, xmm15
00007c081b1d0080  ucomisd xmm14, xmm14
00007c081b1d0085  jp 0x00007C081B1D057F
00007c081b1d008b  movq xmm14, xmm14
00007c081b1d0090  lea r14, [rax+0x100]
00007c081b1d0097  mov r12, [r13+r14*1]
00007c081b1d009c  movq xmm1, r12
00007c081b1d00a1  movq r14, xmm13
00007c081b1d00a6  movq r12, xmm14
00007c081b1d00ab  vmovq xmm15, r14
00007c081b1d00b0  vmovq xmm14, r12
00007c081b1d00b5  movaps xmm13, xmm15
00007c081b1d00b9  addsd xmm13, xmm14
00007c081b1d00be  ucomisd xmm13, xmm13
00007c081b1d00c3  jp 0x00007C081B1D05D5
00007c081b1d00c9  movq xmm13, xmm13
00007c081b1d00ce  movaps xmm15, [r15+0x160]
00007c081b1d00d6  movq r14, xmm15
00007c081b1d00db  movq r12, xmm1
00007c081b1d00e0  vmovq xmm1, r14
00007c081b1d00e5  vmovq xmm15, r12
00007c081b1d00ea  movaps xmm14, xmm1
00007c081b1d00ee  mulsd xmm14, xmm15
00007c081b1d00f3  ucomisd xmm14, xmm14
00007c081b1d00f8  jp 0x00007C081B1D0621
00007c081b1d00fe  movq xmm14, xmm14
00007c081b1d0103  lea r14, [rax+0x140]
00007c081b1d010a  mov r12, [r13+r14*1]
00007c081b1d010f  movq xmm1, r12
00007c081b1d0114  movq r14, xmm13
00007c081b1d0119  movq r12, xmm14
00007c081b1d011e  vmovq xmm15, r14
00007c081b1d0123  vmovq xmm14, r12
00007c081b1d0128  movaps xmm13, xmm15
00007c081b1d012c  addsd xmm13, xmm14
00007c081b1d0131  ucomisd xmm13, xmm13
00007c081b1d0136  jp 0x00007C081B1D0677
00007c081b1d013c  movq xmm13, xmm13
00007c081b1d0141  movaps xmm15, [r15+0x170]
00007c081b1d0149  movq r14, xmm15
00007c081b1d014e  movq r12, xmm1
00007c081b1d0153  vmovq xmm1, r14
00007c081b1d0158  vmovq xmm15, r12
00007c081b1d015d  movaps xmm14, xmm1
00007c081b1d0161  mulsd xmm14, xmm15
00007c081b1d0166  ucomisd xmm14, xmm14
00007c081b1d016b  jp 0x00007C081B1D06C3
00007c081b1d0171  movq xmm14, xmm14
00007c081b1d0176  lea r14, [rax+0x180]
00007c081b1d017d  mov r12, [r13+r14*1]
00007c081b1d0182  movq xmm1, r12
00007c081b1d0187  movq r14, xmm13
00007c081b1d018c  movq r12, xmm14
00007c081b1d0191  vmovq xmm15, r14
00007c081b1d0196  vmovq xmm14, r12
00007c081b1d019b  movaps xmm13, xmm15
00007c081b1d019f  addsd xmm13, xmm14
00007c081b1d01a4  ucomisd xmm13, xmm13
00007c081b1d01a9  jp 0x00007C081B1D0719
00007c081b1d01af  movq xmm13, xmm13
00007c081b1d01b4  movaps xmm15, [r15+0x180]
00007c081b1d01bc  movq r14, xmm15
00007c081b1d01c1  movq r12, xmm1
00007c081b1d01c6  vmovq xmm1, r14
00007c081b1d01cb  vmovq xmm15, r12
00007c081b1d01d0  movaps xmm14, xmm1
00007c081b1d01d4  mulsd xmm14, xmm15
00007c081b1d01d9  ucomisd xmm14, xmm14
00007c081b1d01de  jp 0x00007C081B1D0765
00007c081b1d01e4  movq xmm14, xmm14
00007c081b1d01e9  lea r14, [rax+0x1C0]
00007c081b1d01f0  mov rax, [r13+r14*1]
00007c081b1d01f5  movq xmm1, rax
00007c081b1d01fa  movaps [r15+0x240], xmm1
00007c081b1d0202  movq rax, xmm13
00007c081b1d0207  movq r14, xmm14
00007c081b1d020c  vmovq xmm15, rax
00007c081b1d0211  vmovq xmm14, r14
00007c081b1d0216  movaps xmm13, xmm15
00007c081b1d021a  addsd xmm13, xmm14
00007c081b1d021f  ucomisd xmm13, xmm13
00007c081b1d0224  jp 0x00007C081B1D07BB
00007c081b1d022a  movq xmm13, xmm13
00007c081b1d022f  movaps xmm15, [r15+0x210]
00007c081b1d0237  movq rax, xmm15
00007c081b1d023c  movq r14, xmm1
00007c081b1d0241  vmovq xmm1, rax
00007c081b1d0246  vmovq xmm15, r14
00007c081b1d024b  movaps xmm14, xmm1
00007c081b1d024f  mulsd xmm14, xmm15
00007c081b1d0254  ucomisd xmm14, xmm14
00007c081b1d0259  jp 0x00007C081B1D0803
00007c081b1d025f  movq xmm14, xmm14
00007c081b1d0264  movaps [r15+0x230], xmm14
00007c081b1d026c  movq rax, xmm13
00007c081b1d0271  movq r14, xmm14
00007c081b1d0276  vmovq xmm1, rax
00007c081b1d027b  vmovq xmm15, r14
00007c081b1d0280  movaps xmm14, xmm1
00007c081b1d0284  addsd xmm14, xmm15
00007c081b1d0289  ucomisd xmm14, xmm14
00007c081b1d028e  jp 0x00007C081B1D084B
00007c081b1d0294  movq xmm14, xmm14
00007c081b1d0299  movaps [r15+0x220], xmm14
00007c081b1d02a1  mov rax, [r15+0x68]
00007c081b1d02a5  movq r14, xmm14
00007c081b1d02aa  mov [r13+rax*1], r14
00007c081b1d02af  mov qword ptr [r15+0x70], 0x08
00007c081b1d02b7  xor eax, eax
00007c081b1d02b9  mov r14d, 0x08
00007c081b1d02bf  mov r12d, 0x40
00007c081b1d02c5  cmp r14, r12
00007c081b1d02c8  cmc
00007c081b1d02c9  lahf
00007c081b1d02ca  seto al
00007c081b1d02cd  mov [r15+0x108], eax
00007c081b1d02d4  mov eax, [r15+0x108]
00007c081b1d02db  sahf
00007c081b1d02dc  jnz 0x00007C081B1D030E
00007c081b1d02de  cmp dword ptr [r15+0x318], 0x00
00007c081b1d02e6  jz 0x00007C081B1CFD40
00007c081b1d02ec  nop [rax+rax*1], ax
00007c081b1d02f5  nop [rax+rax*1], eax
00007c081b1d02fd  mov eax, 0x410118
00007c081b1d0302  mov [r15+0x100], rax
00007c081b1d0309  jmp 0x00007C081AFFE110
00007c081b1d030e  cmp dword ptr [r15+0x318], 0x00
00007c081b1d0316  jz 0x00007C081B1CF3F0
00007c081b1d031c  nop [rax+rax*1], ax
00007c081b1d0325  nop [rax+rax*1], eax
00007c081b1d032d  mov eax, 0x4100A4
00007c081b1d0332  mov [r15+0x100], rax
00007c081b1d0339  jmp 0x00007C081AFFE110
00007c081b1d033e  int3
00007c081b1d033f  call 0x00007C081B0B47C0
00007c081b1d0344  jmp 0x00007C081B1CFDF5
00007c081b1d0349  call 0x00007C081B0E1570
00007c081b1d034e  jmp 0x00007C081B1CFDFF
00007c081b1d0353  call 0x00007C081B00DC20
00007c081b1d0358  jmp 0x00007C081B1CFE35
00007c081b1d035d  call 0x00007C081B00A4B0
00007c081b1d0362  jmp 0x00007C081B1CFE3F
00007c081b1d0367  call 0x00007C081B00DC20
00007c081b1d036c  jmp 0x00007C081B1CFE75
00007c081b1d0371  call 0x00007C081B00A4B0
00007c081b1d0376  jmp 0x00007C081B1CFE7F
00007c081b1d037b  call 0x00007C081B00DC20
00007c081b1d0380  jmp 0x00007C081B1CFEB5
00007c081b1d0385  call 0x00007C081B00B720
00007c081b1d038a  jmp 0x00007C081B1CFEBF
00007c081b1d038f  call 0x00007C081B00DC20
00007c081b1d0394  jmp 0x00007C081B1CFEF8
00007c081b1d0399  call 0x00007C081B0E27E0
00007c081b1d039e  jmp 0x00007C081B1CFF06
00007c081b1d03a3  call 0x00007C081B0E27E0
00007c081b1d03a8  jmp 0x00007C081B1CFF17
00007c081b1d03ad  ucomisd xmm1, xmm13
00007c081b1d03b2  jp 0x00007C081B1D03C1
00007c081b1d03b4  movaps xmm12, [0x00007C081ADFE030]
00007c081b1d03bc  jmp 0x00007C081B1CFF4C
00007c081b1d03c1  vxorps xmm0, xmm1, xmm13
00007c081b1d03c6  pextrw r14d, xmm0, 0x03
00007c081b1d03cc  and r14d, 0x7FF8
00007c081b1d03d3  cmp r14d, 0x08
00007c081b1d03d7  jnz 0x00007C081B1CFF4C
00007c081b1d03dd  movq r14, xmm13
00007c081b1d03e2  shl r14, 0x0D
00007c081b1d03e6  jbe 0x00007C081B1CFF4C
00007c081b1d03ec  vorps xmm12, xmm13, [0x00007C081ADFE040]
00007c081b1d03f4  jmp 0x00007C081B1CFF4C
00007c081b1d03f9  ucomisd xmm1, xmm15
00007c081b1d03fe  jp 0x00007C081B1D040D
00007c081b1d0400  movaps xmm13, [0x00007C081ADFE030]
00007c081b1d0408  jmp 0x00007C081B1CFF81
00007c081b1d040d  vxorps xmm0, xmm1, xmm15
00007c081b1d0412  pextrw r14d, xmm0, 0x03
00007c081b1d0418  and r14d, 0x7FF8
00007c081b1d041f  cmp r14d, 0x08
00007c081b1d0423  jnz 0x00007C081B1CFF81
00007c081b1d0429  movq r14, xmm15
00007c081b1d042e  shl r14, 0x0D
00007c081b1d0432  jbe 0x00007C081B1CFF81
00007c081b1d0438  vorps xmm13, xmm15, [0x00007C081ADFE040]
00007c081b1d0440  jmp 0x00007C081B1CFF81
00007c081b1d0445  ucomisd xmm1, xmm15
00007c081b1d044a  jp 0x00007C081B1D0459
00007c081b1d044c  movaps xmm12, [0x00007C081ADFE030]
00007c081b1d0454  jmp 0x00007C081B1CFFB6
00007c081b1d0459  vxorps xmm0, xmm1, xmm15
00007c081b1d045e  pextrw r14d, xmm0, 0x03
00007c081b1d0464  and r14d, 0x7FF8
00007c081b1d046b  cmp r14d, 0x08
00007c081b1d046f  jnz 0x00007C081B1CFFB6
00007c081b1d0475  movq r14, xmm15
00007c081b1d047a  shl r14, 0x0D
00007c081b1d047e  jbe 0x00007C081B1CFFB6
00007c081b1d0484  vorps xmm12, xmm15, [0x00007C081ADFE040]
00007c081b1d048c  jmp 0x00007C081B1CFFB6
00007c081b1d0491  ucomisd xmm1, xmm15
00007c081b1d0496  jp 0x00007C081B1D04A5
00007c081b1d0498  movaps xmm13, [0x00007C081ADFE030]
00007c081b1d04a0  jmp 0x00007C081B1CFFE3
00007c081b1d04a5  vxorps xmm0, xmm1, xmm15
00007c081b1d04aa  pextrw r14d, xmm0, 0x03
00007c081b1d04b0  and r14d, 0x7FF8
00007c081b1d04b7  cmp r14d, 0x08
00007c081b1d04bb  jnz 0x00007C081B1CFFE3
00007c081b1d04c1  movq r14, xmm15
00007c081b1d04c6  shl r14, 0x0D
00007c081b1d04ca  jbe 0x00007C081B1CFFE3
00007c081b1d04d0  vorps xmm13, xmm15, [0x00007C081ADFE040]
00007c081b1d04d8  jmp 0x00007C081B1CFFE3
00007c081b1d04dd  ucomisd xmm1, xmm15
00007c081b1d04e2  jp 0x00007C081B1D04F1
00007c081b1d04e4  movaps xmm14, [0x00007C081ADFE030]
00007c081b1d04ec  jmp 0x00007C081B1D0018
00007c081b1d04f1  vxorps xmm0, xmm1, xmm15
00007c081b1d04f6  pextrw r14d, xmm0, 0x03
00007c081b1d04fc  and r14d, 0x7FF8
00007c081b1d0503  cmp r14d, 0x08
00007c081b1d0507  jnz 0x00007C081B1D0018
00007c081b1d050d  movq r14, xmm15
00007c081b1d0512  shl r14, 0x0D
00007c081b1d0516  jbe 0x00007C081B1D0018
00007c081b1d051c  vorps xmm14, xmm15, [0x00007C081ADFE040]
00007c081b1d0524  jmp 0x00007C081B1D0018
00007c081b1d0529  call 0x00007C081B0E27E0
00007c081b1d052e  jmp 0x00007C081B1D0029
00007c081b1d0533  ucomisd xmm15, xmm14
00007c081b1d0538  jp 0x00007C081B1D0547
00007c081b1d053a  movaps xmm13, [0x00007C081ADFE030]
00007c081b1d0542  jmp 0x00007C081B1D0056
00007c081b1d0547  vxorps xmm0, xmm15, xmm14
00007c081b1d054c  pextrw r14d, xmm0, 0x03
00007c081b1d0552  and r14d, 0x7FF8
00007c081b1d0559  cmp r14d, 0x08
00007c081b1d055d  jnz 0x00007C081B1D0056
00007c081b1d0563  movq r14, xmm14
00007c081b1d0568  shl r14, 0x0D
00007c081b1d056c  jbe 0x00007C081B1D0056
00007c081b1d0572  vorps xmm13, xmm14, [0x00007C081ADFE040]
00007c081b1d057a  jmp 0x00007C081B1D0056
00007c081b1d057f  ucomisd xmm1, xmm15
00007c081b1d0584  jp 0x00007C081B1D0593
00007c081b1d0586  movaps xmm14, [0x00007C081ADFE030]
00007c081b1d058e  jmp 0x00007C081B1D008B
00007c081b1d0593  vxorps xmm0, xmm1, xmm15
00007c081b1d0598  pextrw r14d, xmm0, 0x03
00007c081b1d059e  and r14d, 0x7FF8
00007c081b1d05a5  cmp r14d, 0x08
00007c081b1d05a9  jnz 0x00007C081B1D008B
00007c081b1d05af  movq r14, xmm15
00007c081b1d05b4  shl r14, 0x0D
00007c081b1d05b8  jbe 0x00007C081B1D008B
00007c081b1d05be  vorps xmm14, xmm15, [0x00007C081ADFE040]
00007c081b1d05c6  jmp 0x00007C081B1D008B
00007c081b1d05cb  call 0x00007C081B0E27E0
00007c081b1d05d0  jmp 0x00007C081B1D009C
00007c081b1d05d5  ucomisd xmm15, xmm14
00007c081b1d05da  jp 0x00007C081B1D05E9
00007c081b1d05dc  movaps xmm13, [0x00007C081ADFE030]
00007c081b1d05e4  jmp 0x00007C081B1D00C9
00007c081b1d05e9  vxorps xmm0, xmm15, xmm14
00007c081b1d05ee  pextrw r14d, xmm0, 0x03
00007c081b1d05f4  and r14d, 0x7FF8
00007c081b1d05fb  cmp r14d, 0x08
00007c081b1d05ff  jnz 0x00007C081B1D00C9
00007c081b1d0605  movq r14, xmm14
00007c081b1d060a  shl r14, 0x0D
00007c081b1d060e  jbe 0x00007C081B1D00C9
00007c081b1d0614  vorps xmm13, xmm14, [0x00007C081ADFE040]
00007c081b1d061c  jmp 0x00007C081B1D00C9
00007c081b1d0621  ucomisd xmm1, xmm15
00007c081b1d0626  jp 0x00007C081B1D0635
00007c081b1d0628  movaps xmm14, [0x00007C081ADFE030]
00007c081b1d0630  jmp 0x00007C081B1D00FE
00007c081b1d0635  vxorps xmm0, xmm1, xmm15
00007c081b1d063a  pextrw r14d, xmm0, 0x03
00007c081b1d0640  and r14d, 0x7FF8
00007c081b1d0647  cmp r14d, 0x08
00007c081b1d064b  jnz 0x00007C081B1D00FE
00007c081b1d0651  movq r14, xmm15
00007c081b1d0656  shl r14, 0x0D
00007c081b1d065a  jbe 0x00007C081B1D00FE
00007c081b1d0660  vorps xmm14, xmm15, [0x00007C081ADFE040]
00007c081b1d0668  jmp 0x00007C081B1D00FE
00007c081b1d066d  call 0x00007C081B0E27E0
00007c081b1d0672  jmp 0x00007C081B1D010F
00007c081b1d0677  ucomisd xmm15, xmm14
00007c081b1d067c  jp 0x00007C081B1D068B
00007c081b1d067e  movaps xmm13, [0x00007C081ADFE030]
00007c081b1d0686  jmp 0x00007C081B1D013C
00007c081b1d068b  vxorps xmm0, xmm15, xmm14
00007c081b1d0690  pextrw r14d, xmm0, 0x03
00007c081b1d0696  and r14d, 0x7FF8
00007c081b1d069d  cmp r14d, 0x08
00007c081b1d06a1  jnz 0x00007C081B1D013C
00007c081b1d06a7  movq r14, xmm14
00007c081b1d06ac  shl r14, 0x0D
00007c081b1d06b0  jbe 0x00007C081B1D013C
00007c081b1d06b6  vorps xmm13, xmm14, [0x00007C081ADFE040]
00007c081b1d06be  jmp 0x00007C081B1D013C
00007c081b1d06c3  ucomisd xmm1, xmm15
00007c081b1d06c8  jp 0x00007C081B1D06D7
00007c081b1d06ca  movaps xmm14, [0x00007C081ADFE030]
00007c081b1d06d2  jmp 0x00007C081B1D0171
00007c081b1d06d7  vxorps xmm0, xmm1, xmm15
00007c081b1d06dc  pextrw r14d, xmm0, 0x03
00007c081b1d06e2  and r14d, 0x7FF8
00007c081b1d06e9  cmp r14d, 0x08
00007c081b1d06ed  jnz 0x00007C081B1D0171
00007c081b1d06f3  movq r14, xmm15
00007c081b1d06f8  shl r14, 0x0D
00007c081b1d06fc  jbe 0x00007C081B1D0171
00007c081b1d0702  vorps xmm14, xmm15, [0x00007C081ADFE040]
00007c081b1d070a  jmp 0x00007C081B1D0171
00007c081b1d070f  call 0x00007C081B0E27E0
00007c081b1d0714  jmp 0x00007C081B1D0182
00007c081b1d0719  ucomisd xmm15, xmm14
00007c081b1d071e  jp 0x00007C081B1D072D
00007c081b1d0720  movaps xmm13, [0x00007C081ADFE030]
00007c081b1d0728  jmp 0x00007C081B1D01AF
00007c081b1d072d  vxorps xmm0, xmm15, xmm14
00007c081b1d0732  pextrw r14d, xmm0, 0x03
00007c081b1d0738  and r14d, 0x7FF8
00007c081b1d073f  cmp r14d, 0x08
00007c081b1d0743  jnz 0x00007C081B1D01AF
00007c081b1d0749  movq r14, xmm14
00007c081b1d074e  shl r14, 0x0D
00007c081b1d0752  jbe 0x00007C081B1D01AF
00007c081b1d0758  vorps xmm13, xmm14, [0x00007C081ADFE040]
00007c081b1d0760  jmp 0x00007C081B1D01AF
00007c081b1d0765  ucomisd xmm1, xmm15
00007c081b1d076a  jp 0x00007C081B1D0779
00007c081b1d076c  movaps xmm14, [0x00007C081ADFE030]
00007c081b1d0774  jmp 0x00007C081B1D01E4
00007c081b1d0779  vxorps xmm0, xmm1, xmm15
00007c081b1d077e  pextrw r14d, xmm0, 0x03
00007c081b1d0784  and r14d, 0x7FF8
00007c081b1d078b  cmp r14d, 0x08
00007c081b1d078f  jnz 0x00007C081B1D01E4
00007c081b1d0795  movq r14, xmm15
00007c081b1d079a  shl r14, 0x0D
00007c081b1d079e  jbe 0x00007C081B1D01E4
00007c081b1d07a4  vorps xmm14, xmm15, [0x00007C081ADFE040]
00007c081b1d07ac  jmp 0x00007C081B1D01E4
00007c081b1d07b1  call 0x00007C081B0D59C0
00007c081b1d07b6  jmp 0x00007C081B1D01F5
00007c081b1d07bb  ucomisd xmm15, xmm14
00007c081b1d07c0  jp 0x00007C081B1D07CF
00007c081b1d07c2  movaps xmm13, [0x00007C081ADFE030]
00007c081b1d07ca  jmp 0x00007C081B1D022A
00007c081b1d07cf  vxorps xmm0, xmm15, xmm14
00007c081b1d07d4  pextrw eax, xmm0, 0x03
00007c081b1d07d9  and eax, 0x7FF8
00007c081b1d07de  cmp eax, 0x08
00007c081b1d07e1  jnz 0x00007C081B1D022A
00007c081b1d07e7  movq rax, xmm14
00007c081b1d07ec  shl rax, 0x0D
00007c081b1d07f0  jbe 0x00007C081B1D022A
00007c081b1d07f6  vorps xmm13, xmm14, [0x00007C081ADFE040]
00007c081b1d07fe  jmp 0x00007C081B1D022A
00007c081b1d0803  ucomisd xmm1, xmm15
00007c081b1d0808  jp 0x00007C081B1D0817
00007c081b1d080a  movaps xmm14, [0x00007C081ADFE030]
00007c081b1d0812  jmp 0x00007C081B1D025F
00007c081b1d0817  vxorps xmm0, xmm1, xmm15
00007c081b1d081c  pextrw eax, xmm0, 0x03
00007c081b1d0821  and eax, 0x7FF8
00007c081b1d0826  cmp eax, 0x08
00007c081b1d0829  jnz 0x00007C081B1D025F
00007c081b1d082f  movq rax, xmm15
00007c081b1d0834  shl rax, 0x0D
00007c081b1d0838  jbe 0x00007C081B1D025F
00007c081b1d083e  vorps xmm14, xmm15, [0x00007C081ADFE040]
00007c081b1d0846  jmp 0x00007C081B1D025F
00007c081b1d084b  ucomisd xmm1, xmm15
00007c081b1d0850  jp 0x00007C081B1D085F
00007c081b1d0852  movaps xmm14, [0x00007C081ADFE030]
00007c081b1d085a  jmp 0x00007C081B1D0294
00007c081b1d085f  vxorps xmm0, xmm1, xmm15
00007c081b1d0864  pextrw eax, xmm0, 0x03
00007c081b1d0869  and eax, 0x7FF8
00007c081b1d086e  cmp eax, 0x08
00007c081b1d0871  jnz 0x00007C081B1D0294
00007c081b1d0877  movq rax, xmm15
00007c081b1d087c  shl rax, 0x0D
00007c081b1d0880  jbe 0x00007C081B1D0294
00007c081b1d0886  vorps xmm14, xmm15, [0x00007C081ADFE040]
00007c081b1d088e  jmp 0x00007C081B1D0294
00007c081b1d0893  call 0x00007C081B00E120
00007c081b1d0898  jmp 0x00007C081B1D02AF
00007c081b1d089d  int3
00007c081b1d089e  nop
00007c081b1d08a0  mov eax, [r15+0x58]
00007c081b1d08a4  lea r14d, [eax+0x01]
00007c081b1d08a9  mov [rsp+0x10], r14d
00007c081b1d08ae  mov r14d, r14d
00007c081b1d08b1  mov [r15+0x58], r14
00007c081b1d08b5  xor eax, eax
00007c081b1d08b7  mov r14d, [rsp+0x10]
00007c081b1d08bc  cmp r14d, 0x1F4
00007c081b1d08c3  cmc
00007c081b1d08c4  lahf
00007c081b1d08c5  seto al
00007c081b1d08c8  mov [r15+0x108], eax
00007c081b1d08cf  mov eax, [r15+0x108]
00007c081b1d08d6  sahf
00007c081b1d08d7  jnz 0x00007C081B1D0909
00007c081b1d08d9  cmp dword ptr [r15+0x318], 0x00
00007c081b1d08e1  jz 0x00007C081B1D1410
00007c081b1d08e7  nop [rax+rax*1], ax
00007c081b1d08f0  nop [rax+rax*1], eax
00007c081b1d08f8  mov eax, 0x410134
00007c081b1d08fd  mov [r15+0x100], rax
00007c081b1d0904  jmp 0x00007C081AFFE110
00007c081b1d0909  cmp dword ptr [r15+0x318], 0x00
00007c081b1d0911  jz 0x00007C081B1D0940
00007c081b1d0917  nop [rax+rax*1], ax
00007c081b1d0920  nop [rax+rax*1], eax
00007c081b1d0928  mov eax, 0x410084
00007c081b1d092d  mov [r15+0x100], rax
00007c081b1d0934  jmp 0x00007C081AFFE110
00007c081b1d0939  int3
00007c081b1d093a  int3
00007c081b1d093b  nop [rax+rax*1], eax
00007c081b1d0940  mov qword ptr [r15+0x60], 0x00
00007c081b1d0948  mov rax, [r15+0x50]
00007c081b1d094c  mov [r15+0x68], rax
00007c081b1d0950  mov r14, [r15+0x40]
00007c081b1d0954  mov r12, [r13+r14*1]
00007c081b1d0959  lea r11, [r14+0x08]
00007c081b1d095d  mov r10, [r13+r11*1]
00007c081b1d0962  movq xmm1, r12
00007c081b1d0967  movq xmm15, r10
00007c081b1d096c  movq xmm1, xmm1
00007c081b1d0970  movq xmm1, xmm1
00007c081b1d0974  movaps [r15+0x120], xmm1
00007c081b1d097c  movq xmm15, xmm15
00007c081b1d0981  movq xmm15, xmm15
00007c081b1d0986  movaps [r15+0x130], xmm15
00007c081b1d098e  lea r12, [r14+0x10]
00007c081b1d0992  mov r11, [r13+r12*1]
00007c081b1d0997  lea r12, [r14+0x18]
00007c081b1d099b  mov r10, [r13+r12*1]
00007c081b1d09a0  movq xmm1, r11
00007c081b1d09a5  movq xmm15, r10
00007c081b1d09aa  movq xmm1, xmm1
00007c081b1d09ae  movq xmm1, xmm1
00007c081b1d09b2  movaps [r15+0x140], xmm1
00007c081b1d09ba  movq xmm15, xmm15
00007c081b1d09bf  movq xmm15, xmm15
00007c081b1d09c4  movaps [r15+0x150], xmm15
00007c081b1d09cc  lea r12, [r14+0x20]
00007c081b1d09d0  mov r11, [r13+r12*1]
00007c081b1d09d5  lea r12, [r14+0x28]
00007c081b1d09d9  mov r10, [r13+r12*1]
00007c081b1d09de  movq xmm1, r11
00007c081b1d09e3  movq xmm15, r10
00007c081b1d09e8  movq xmm1, xmm1
00007c081b1d09ec  movq xmm1, xmm1
00007c081b1d09f0  movaps [r15+0x160], xmm1
00007c081b1d09f8  movq xmm15, xmm15
00007c081b1d09fd  movq xmm15, xmm15
00007c081b1d0a02  movaps [r15+0x170], xmm15
00007c081b1d0a0a  lea r12, [r14+0x30]
00007c081b1d0a0e  mov r11, [r13+r12*1]
00007c081b1d0a13  lea r12, [r14+0x38]
00007c081b1d0a17  mov r14, [r13+r12*1]
00007c081b1d0a1c  movq xmm1, r11
00007c081b1d0a21  movq xmm15, r14
00007c081b1d0a26  movq xmm1, xmm1
00007c081b1d0a2a  movq xmm1, xmm1
00007c081b1d0a2e  movaps [r15+0x180], xmm1
00007c081b1d0a36  movq xmm15, xmm15
00007c081b1d0a3b  movq xmm15, xmm15
00007c081b1d0a40  movaps [r15+0x210], xmm15
00007c081b1d0a48  mov r14, [r15+0x48]
00007c081b1d0a4c  mov [r15+0x78], r14
00007c081b1d0a50  mov r12, [r13+r14*1]
00007c081b1d0a55  movq xmm1, r12
00007c081b1d0a5a  lea r12, [r14+0x40]
00007c081b1d0a5e  mov r11, [r13+r12*1]
00007c081b1d0a63  movq xmm15, r11
00007c081b1d0a68  lea r12, [r14+0x80]
00007c081b1d0a6f  mov r11, [r13+r12*1]
00007c081b1d0a74  movq xmm14, r11
00007c081b1d0a79  movaps xmm13, [r15+0x120]
00007c081b1d0a81  movq r12, xmm13
00007c081b1d0a86  movq r11, xmm1
00007c081b1d0a8b  vmovq xmm1, r12
00007c081b1d0a90  vmovq xmm13, r11
00007c081b1d0a95  movaps xmm12, xmm1
00007c081b1d0a99  mulsd xmm12, xmm13
00007c081b1d0a9e  ucomisd xmm12, xmm12
00007c081b1d0aa3  jp 0x00007C081B1D0F06
00007c081b1d0aa9  movq xmm12, xmm12
00007c081b1d0aae  movaps xmm1, [r15+0x130]
00007c081b1d0ab6  movq r12, xmm1
00007c081b1d0abb  movq r11, xmm15
00007c081b1d0ac0  vmovq xmm1, r12
00007c081b1d0ac5  vmovq xmm15, r11
00007c081b1d0aca  movaps xmm13, xmm1
00007c081b1d0ace  mulsd xmm13, xmm15
00007c081b1d0ad3  ucomisd xmm13, xmm13
00007c081b1d0ad8  jp 0x00007C081B1D0F52
00007c081b1d0ade  movq xmm13, xmm13
00007c081b1d0ae3  movq r12, xmm12
00007c081b1d0ae8  movaps xmm1, [r15+0x110]
00007c081b1d0af0  movq r11, xmm1
00007c081b1d0af5  vmovq xmm1, r12
00007c081b1d0afa  vmovq xmm15, r11
00007c081b1d0aff  movaps xmm12, xmm1
00007c081b1d0b03  addsd xmm12, xmm15
00007c081b1d0b08  ucomisd xmm12, xmm12
00007c081b1d0b0d  jp 0x00007C081B1D0F9E
00007c081b1d0b13  movq xmm12, xmm12
00007c081b1d0b18  movq r12, xmm12
00007c081b1d0b1d  movq r11, xmm13
00007c081b1d0b22  vmovq xmm1, r12
00007c081b1d0b27  vmovq xmm15, r11
00007c081b1d0b2c  movaps xmm13, xmm1
00007c081b1d0b30  addsd xmm13, xmm15
00007c081b1d0b35  ucomisd xmm13, xmm13
00007c081b1d0b3a  jp 0x00007C081B1D0FEA
00007c081b1d0b40  movq xmm13, xmm13
00007c081b1d0b45  movaps xmm1, [r15+0x140]
00007c081b1d0b4d  movq r12, xmm1
00007c081b1d0b52  movq r11, xmm14
00007c081b1d0b57  vmovq xmm1, r12
00007c081b1d0b5c  vmovq xmm15, r11
00007c081b1d0b61  movaps xmm14, xmm1
00007c081b1d0b65  mulsd xmm14, xmm15
00007c081b1d0b6a  ucomisd xmm14, xmm14
00007c081b1d0b6f  jp 0x00007C081B1D1036
00007c081b1d0b75  movq xmm14, xmm14
00007c081b1d0b7a  lea r12, [r14+0xC0]
00007c081b1d0b81  mov r11, [r13+r12*1]
00007c081b1d0b86  movq xmm1, r11
00007c081b1d0b8b  movq r12, xmm13
00007c081b1d0b90  movq r11, xmm14
00007c081b1d0b95  vmovq xmm15, r12
00007c081b1d0b9a  vmovq xmm14, r11
00007c081b1d0b9f  movaps xmm13, xmm15
00007c081b1d0ba3  addsd xmm13, xmm14
00007c081b1d0ba8  ucomisd xmm13, xmm13
00007c081b1d0bad  jp 0x00007C081B1D108C
00007c081b1d0bb3  movq xmm13, xmm13
00007c081b1d0bb8  movaps xmm15, [r15+0x150]
00007c081b1d0bc0  movq r12, xmm15
00007c081b1d0bc5  movq r11, xmm1
00007c081b1d0bca  vmovq xmm1, r12
00007c081b1d0bcf  vmovq xmm15, r11
00007c081b1d0bd4  movaps xmm14, xmm1
00007c081b1d0bd8  mulsd xmm14, xmm15
00007c081b1d0bdd  ucomisd xmm14, xmm14
00007c081b1d0be2  jp 0x00007C081B1D10D8
00007c081b1d0be8  movq xmm14, xmm14
00007c081b1d0bed  lea r12, [r14+0x100]
00007c081b1d0bf4  mov r11, [r13+r12*1]
00007c081b1d0bf9  movq xmm1, r11
00007c081b1d0bfe  movq r12, xmm13
00007c081b1d0c03  movq r11, xmm14
00007c081b1d0c08  vmovq xmm15, r12
00007c081b1d0c0d  vmovq xmm14, r11
00007c081b1d0c12  movaps xmm13, xmm15
00007c081b1d0c16  addsd xmm13, xmm14
00007c081b1d0c1b  ucomisd xmm13, xmm13
00007c081b1d0c20  jp 0x00007C081B1D112E
00007c081b1d0c26  movq xmm13, xmm13
00007c081b1d0c2b  movaps xmm15, [r15+0x160]
00007c081b1d0c33  movq r12, xmm15
00007c081b1d0c38  movq r11, xmm1
00007c081b1d0c3d  vmovq xmm1, r12
00007c081b1d0c42  vmovq xmm15, r11
00007c081b1d0c47  movaps xmm14, xmm1
00007c081b1d0c4b  mulsd xmm14, xmm15
00007c081b1d0c50  ucomisd xmm14, xmm14
00007c081b1d0c55  jp 0x00007C081B1D117A
00007c081b1d0c5b  movq xmm14, xmm14
00007c081b1d0c60  lea r12, [r14+0x140]
00007c081b1d0c67  mov r11, [r13+r12*1]
00007c081b1d0c6c  movq xmm1, r11
00007c081b1d0c71  movq r12, xmm13
00007c081b1d0c76  movq r11, xmm14
00007c081b1d0c7b  vmovq xmm15, r12
00007c081b1d0c80  vmovq xmm14, r11
00007c081b1d0c85  movaps xmm13, xmm15
00007c081b1d0c89  addsd xmm13, xmm14
00007c081b1d0c8e  ucomisd xmm13, xmm13
00007c081b1d0c93  jp 0x00007C081B1D11D0
00007c081b1d0c99  movq xmm13, xmm13
00007c081b1d0c9e  movaps xmm15, [r15+0x170]
00007c081b1d0ca6  movq r12, xmm15
00007c081b1d0cab  movq r11, xmm1
00007c081b1d0cb0  vmovq xmm1, r12
00007c081b1d0cb5  vmovq xmm15, r11
00007c081b1d0cba  movaps xmm14, xmm1
00007c081b1d0cbe  mulsd xmm14, xmm15
00007c081b1d0cc3  ucomisd xmm14, xmm14
00007c081b1d0cc8  jp 0x00007C081B1D121C
00007c081b1d0cce  movq xmm14, xmm14
00007c081b1d0cd3  lea r12, [r14+0x180]
00007c081b1d0cda  mov r11, [r13+r12*1]
00007c081b1d0cdf  movq xmm1, r11
00007c081b1d0ce4  movq r12, xmm13
00007c081b1d0ce9  movq r11, xmm14
00007c081b1d0cee  vmovq xmm15, r12
00007c081b1d0cf3  vmovq xmm14, r11
00007c081b1d0cf8  movaps xmm13, xmm15
00007c081b1d0cfc  addsd xmm13, xmm14
00007c081b1d0d01  ucomisd xmm13, xmm13
00007c081b1d0d06  jp 0x00007C081B1D1272
00007c081b1d0d0c  movq xmm13, xmm13
00007c081b1d0d11  movaps xmm15, [r15+0x180]
00007c081b1d0d19  movq r12, xmm15
00007c081b1d0d1e  movq r11, xmm1
00007c081b1d0d23  vmovq xmm1, r12
00007c081b1d0d28  vmovq xmm15, r11
00007c081b1d0d2d  movaps xmm14, xmm1
00007c081b1d0d31  mulsd xmm14, xmm15
00007c081b1d0d36  ucomisd xmm14, xmm14
00007c081b1d0d3b  jp 0x00007C081B1D12BE
00007c081b1d0d41  movq xmm14, xmm14
00007c081b1d0d46  lea r12, [r14+0x1C0]
00007c081b1d0d4d  mov r14, [r13+r12*1]
00007c081b1d0d52  movq xmm1, r14
00007c081b1d0d57  movaps [r15+0x240], xmm1
00007c081b1d0d5f  movq r14, xmm13
00007c081b1d0d64  movq r12, xmm14
00007c081b1d0d69  vmovq xmm15, r14
00007c081b1d0d6e  vmovq xmm14, r12
00007c081b1d0d73  movaps xmm13, xmm15
00007c081b1d0d77  addsd xmm13, xmm14
00007c081b1d0d7c  ucomisd xmm13, xmm13
00007c081b1d0d81  jp 0x00007C081B1D1314
00007c081b1d0d87  movq xmm13, xmm13
00007c081b1d0d8c  movaps xmm15, [r15+0x210]
00007c081b1d0d94  movq r14, xmm15
00007c081b1d0d99  movq r12, xmm1
00007c081b1d0d9e  vmovq xmm1, r14
00007c081b1d0da3  vmovq xmm15, r12
00007c081b1d0da8  movaps xmm14, xmm1
00007c081b1d0dac  mulsd xmm14, xmm15
00007c081b1d0db1  ucomisd xmm14, xmm14
00007c081b1d0db6  jp 0x00007C081B1D1360
00007c081b1d0dbc  movq xmm14, xmm14
00007c081b1d0dc1  movaps [r15+0x230], xmm14
00007c081b1d0dc9  movq r14, xmm13
00007c081b1d0dce  movq r12, xmm14
00007c081b1d0dd3  vmovq xmm1, r14
00007c081b1d0dd8  vmovq xmm15, r12
00007c081b1d0ddd  movaps xmm14, xmm1
00007c081b1d0de1  addsd xmm14, xmm15
00007c081b1d0de6  ucomisd xmm14, xmm14
00007c081b1d0deb  jp 0x00007C081B1D13AC
00007c081b1d0df1  movq xmm14, xmm14
00007c081b1d0df6  movaps [r15+0x220], xmm14
00007c081b1d0dfe  movq r14, xmm14
00007c081b1d0e03  mov [r13+rax*1], r14
00007c081b1d0e08  mov qword ptr [r15+0x70], 0x08
00007c081b1d0e10  xor eax, eax
00007c081b1d0e12  mov r14d, 0x08
00007c081b1d0e18  mov r12d, 0x40
00007c081b1d0e1e  cmp r14, r12
00007c081b1d0e21  cmc
00007c081b1d0e22  lahf
00007c081b1d0e23  seto al
00007c081b1d0e26  mov [r15+0x108], eax
00007c081b1d0e2d  mov eax, [r15+0x108]
00007c081b1d0e34  sahf
00007c081b1d0e35  jnz 0x00007C081B1D0E67
00007c081b1d0e37  cmp dword ptr [r15+0x318], 0x00
00007c081b1d0e3f  jz 0x00007C081B1CFD40
00007c081b1d0e45  nop [rax+rax*1], ax
00007c081b1d0e4e  nop [rax+rax*1], eax
00007c081b1d0e56  mov eax, 0x410118
00007c081b1d0e5b  mov [r15+0x100], rax
00007c081b1d0e62  jmp 0x00007C081AFFE110
00007c081b1d0e67  cmp dword ptr [r15+0x318], 0x00
00007c081b1d0e6f  jz 0x00007C081B1CF3F0
00007c081b1d0e75  nop [rax+rax*1], ax
00007c081b1d0e7e  nop [rax+rax*1], eax
00007c081b1d0e86  mov eax, 0x4100A4
00007c081b1d0e8b  mov [r15+0x100], rax
00007c081b1d0e92  jmp 0x00007C081AFFE110
00007c081b1d0e97  int3
00007c081b1d0e98  call 0x00007C081B0E27E0
00007c081b1d0e9d  jmp 0x00007C081B1D0959
00007c081b1d0ea2  call 0x00007C081B0AE800
00007c081b1d0ea7  jmp 0x00007C081B1D0962
00007c081b1d0eac  call 0x00007C081B0C0370
00007c081b1d0eb1  jmp 0x00007C081B1D0997
00007c081b1d0eb6  call 0x00007C081B0BF100
00007c081b1d0ebb  jmp 0x00007C081B1D09A0
00007c081b1d0ec0  call 0x00007C081B0C0370
00007c081b1d0ec5  jmp 0x00007C081B1D09D5
00007c081b1d0eca  call 0x00007C081B0BF100
00007c081b1d0ecf  jmp 0x00007C081B1D09DE
00007c081b1d0ed4  call 0x00007C081B0C0370
00007c081b1d0ed9  jmp 0x00007C081B1D0A13
00007c081b1d0ede  call 0x00007C081B0C3AE0
00007c081b1d0ee3  jmp 0x00007C081B1D0A1C
00007c081b1d0ee8  call 0x00007C081B0E27E0
00007c081b1d0eed  jmp 0x00007C081B1D0A55
00007c081b1d0ef2  call 0x00007C081B0C0370
00007c081b1d0ef7  jmp 0x00007C081B1D0A63
00007c081b1d0efc  call 0x00007C081B0C0370
00007c081b1d0f01  jmp 0x00007C081B1D0A74
00007c081b1d0f06  ucomisd xmm1, xmm13
00007c081b1d0f0b  jp 0x00007C081B1D0F1A
00007c081b1d0f0d  movaps xmm12, [0x00007C081ADFE030]
00007c081b1d0f15  jmp 0x00007C081B1D0AA9
00007c081b1d0f1a  vxorps xmm0, xmm1, xmm13
00007c081b1d0f1f  pextrw r12d, xmm0, 0x03
00007c081b1d0f25  and r12d, 0x7FF8
00007c081b1d0f2c  cmp r12d, 0x08
00007c081b1d0f30  jnz 0x00007C081B1D0AA9
00007c081b1d0f36  movq r12, xmm13
00007c081b1d0f3b  shl r12, 0x0D
00007c081b1d0f3f  jbe 0x00007C081B1D0AA9
00007c081b1d0f45  vorps xmm12, xmm13, [0x00007C081ADFE040]
00007c081b1d0f4d  jmp 0x00007C081B1D0AA9
00007c081b1d0f52  ucomisd xmm1, xmm15
00007c081b1d0f57  jp 0x00007C081B1D0F66
00007c081b1d0f59  movaps xmm13, [0x00007C081ADFE030]
00007c081b1d0f61  jmp 0x00007C081B1D0ADE
00007c081b1d0f66  vxorps xmm0, xmm1, xmm15
00007c081b1d0f6b  pextrw r12d, xmm0, 0x03
00007c081b1d0f71  and r12d, 0x7FF8
00007c081b1d0f78  cmp r12d, 0x08
00007c081b1d0f7c  jnz 0x00007C081B1D0ADE
00007c081b1d0f82  movq r12, xmm15
00007c081b1d0f87  shl r12, 0x0D
00007c081b1d0f8b  jbe 0x00007C081B1D0ADE
00007c081b1d0f91  vorps xmm13, xmm15, [0x00007C081ADFE040]
00007c081b1d0f99  jmp 0x00007C081B1D0ADE
00007c081b1d0f9e  ucomisd xmm1, xmm15
00007c081b1d0fa3  jp 0x00007C081B1D0FB2
00007c081b1d0fa5  movaps xmm12, [0x00007C081ADFE030]
00007c081b1d0fad  jmp 0x00007C081B1D0B13
00007c081b1d0fb2  vxorps xmm0, xmm1, xmm15
00007c081b1d0fb7  pextrw r12d, xmm0, 0x03
00007c081b1d0fbd  and r12d, 0x7FF8
00007c081b1d0fc4  cmp r12d, 0x08
00007c081b1d0fc8  jnz 0x00007C081B1D0B13
00007c081b1d0fce  movq r12, xmm15
00007c081b1d0fd3  shl r12, 0x0D
00007c081b1d0fd7  jbe 0x00007C081B1D0B13
00007c081b1d0fdd  vorps xmm12, xmm15, [0x00007C081ADFE040]
00007c081b1d0fe5  jmp 0x00007C081B1D0B13
00007c081b1d0fea  ucomisd xmm1, xmm15
00007c081b1d0fef  jp 0x00007C081B1D0FFE
00007c081b1d0ff1  movaps xmm13, [0x00007C081ADFE030]
00007c081b1d0ff9  jmp 0x00007C081B1D0B40
00007c081b1d0ffe  vxorps xmm0, xmm1, xmm15
00007c081b1d1003  pextrw r12d, xmm0, 0x03
00007c081b1d1009  and r12d, 0x7FF8
00007c081b1d1010  cmp r12d, 0x08
00007c081b1d1014  jnz 0x00007C081B1D0B40
00007c081b1d101a  movq r12, xmm15
00007c081b1d101f  shl r12, 0x0D
00007c081b1d1023  jbe 0x00007C081B1D0B40
00007c081b1d1029  vorps xmm13, xmm15, [0x00007C081ADFE040]
00007c081b1d1031  jmp 0x00007C081B1D0B40
00007c081b1d1036  ucomisd xmm1, xmm15
00007c081b1d103b  jp 0x00007C081B1D104A
00007c081b1d103d  movaps xmm14, [0x00007C081ADFE030]
00007c081b1d1045  jmp 0x00007C081B1D0B75
00007c081b1d104a  vxorps xmm0, xmm1, xmm15
00007c081b1d104f  pextrw r12d, xmm0, 0x03
00007c081b1d1055  and r12d, 0x7FF8
00007c081b1d105c  cmp r12d, 0x08
00007c081b1d1060  jnz 0x00007C081B1D0B75
00007c081b1d1066  movq r12, xmm15
00007c081b1d106b  shl r12, 0x0D
00007c081b1d106f  jbe 0x00007C081B1D0B75
00007c081b1d1075  vorps xmm14, xmm15, [0x00007C081ADFE040]
00007c081b1d107d  jmp 0x00007C081B1D0B75
00007c081b1d1082  call 0x00007C081B0C0370
00007c081b1d1087  jmp 0x00007C081B1D0B86
00007c081b1d108c  ucomisd xmm15, xmm14
00007c081b1d1091  jp 0x00007C081B1D10A0
00007c081b1d1093  movaps xmm13, [0x00007C081ADFE030]
00007c081b1d109b  jmp 0x00007C081B1D0BB3
00007c081b1d10a0  vxorps xmm0, xmm15, xmm14
00007c081b1d10a5  pextrw r12d, xmm0, 0x03
00007c081b1d10ab  and r12d, 0x7FF8
00007c081b1d10b2  cmp r12d, 0x08
00007c081b1d10b6  jnz 0x00007C081B1D0BB3
00007c081b1d10bc  movq r12, xmm14
00007c081b1d10c1  shl r12, 0x0D
00007c081b1d10c5  jbe 0x00007C081B1D0BB3
00007c081b1d10cb  vorps xmm13, xmm14, [0x00007C081ADFE040]
00007c081b1d10d3  jmp 0x00007C081B1D0BB3
00007c081b1d10d8  ucomisd xmm1, xmm15
00007c081b1d10dd  jp 0x00007C081B1D10EC
00007c081b1d10df  movaps xmm14, [0x00007C081ADFE030]
00007c081b1d10e7  jmp 0x00007C081B1D0BE8
00007c081b1d10ec  vxorps xmm0, xmm1, xmm15
00007c081b1d10f1  pextrw r12d, xmm0, 0x03
00007c081b1d10f7  and r12d, 0x7FF8
00007c081b1d10fe  cmp r12d, 0x08
00007c081b1d1102  jnz 0x00007C081B1D0BE8
00007c081b1d1108  movq r12, xmm15
00007c081b1d110d  shl r12, 0x0D
00007c081b1d1111  jbe 0x00007C081B1D0BE8
00007c081b1d1117  vorps xmm14, xmm15, [0x00007C081ADFE040]
00007c081b1d111f  jmp 0x00007C081B1D0BE8
00007c081b1d1124  call 0x00007C081B0C0370
00007c081b1d1129  jmp 0x00007C081B1D0BF9
00007c081b1d112e  ucomisd xmm15, xmm14
00007c081b1d1133  jp 0x00007C081B1D1142
00007c081b1d1135  movaps xmm13, [0x00007C081ADFE030]
00007c081b1d113d  jmp 0x00007C081B1D0C26
00007c081b1d1142  vxorps xmm0, xmm15, xmm14
00007c081b1d1147  pextrw r12d, xmm0, 0x03
00007c081b1d114d  and r12d, 0x7FF8
00007c081b1d1154  cmp r12d, 0x08
00007c081b1d1158  jnz 0x00007C081B1D0C26
00007c081b1d115e  movq r12, xmm14
00007c081b1d1163  shl r12, 0x0D
00007c081b1d1167  jbe 0x00007C081B1D0C26
00007c081b1d116d  vorps xmm13, xmm14, [0x00007C081ADFE040]
00007c081b1d1175  jmp 0x00007C081B1D0C26
00007c081b1d117a  ucomisd xmm1, xmm15
00007c081b1d117f  jp 0x00007C081B1D118E
00007c081b1d1181  movaps xmm14, [0x00007C081ADFE030]
00007c081b1d1189  jmp 0x00007C081B1D0C5B
00007c081b1d118e  vxorps xmm0, xmm1, xmm15
00007c081b1d1193  pextrw r12d, xmm0, 0x03
00007c081b1d1199  and r12d, 0x7FF8
00007c081b1d11a0  cmp r12d, 0x08
00007c081b1d11a4  jnz 0x00007C081B1D0C5B
00007c081b1d11aa  movq r12, xmm15
00007c081b1d11af  shl r12, 0x0D
00007c081b1d11b3  jbe 0x00007C081B1D0C5B
00007c081b1d11b9  vorps xmm14, xmm15, [0x00007C081ADFE040]
00007c081b1d11c1  jmp 0x00007C081B1D0C5B
00007c081b1d11c6  call 0x00007C081B0C0370
00007c081b1d11cb  jmp 0x00007C081B1D0C6C
00007c081b1d11d0  ucomisd xmm15, xmm14
00007c081b1d11d5  jp 0x00007C081B1D11E4
00007c081b1d11d7  movaps xmm13, [0x00007C081ADFE030]
00007c081b1d11df  jmp 0x00007C081B1D0C99
00007c081b1d11e4  vxorps xmm0, xmm15, xmm14
00007c081b1d11e9  pextrw r12d, xmm0, 0x03
00007c081b1d11ef  and r12d, 0x7FF8
00007c081b1d11f6  cmp r12d, 0x08
00007c081b1d11fa  jnz 0x00007C081B1D0C99
00007c081b1d1200  movq r12, xmm14
00007c081b1d1205  shl r12, 0x0D
00007c081b1d1209  jbe 0x00007C081B1D0C99
00007c081b1d120f  vorps xmm13, xmm14, [0x00007C081ADFE040]
00007c081b1d1217  jmp 0x00007C081B1D0C99
00007c081b1d121c  ucomisd xmm1, xmm15
00007c081b1d1221  jp 0x00007C081B1D1230
00007c081b1d1223  movaps xmm14, [0x00007C081ADFE030]
00007c081b1d122b  jmp 0x00007C081B1D0CCE
00007c081b1d1230  vxorps xmm0, xmm1, xmm15
00007c081b1d1235  pextrw r12d, xmm0, 0x03
00007c081b1d123b  and r12d, 0x7FF8
00007c081b1d1242  cmp r12d, 0x08
00007c081b1d1246  jnz 0x00007C081B1D0CCE
00007c081b1d124c  movq r12, xmm15
00007c081b1d1251  shl r12, 0x0D
00007c081b1d1255  jbe 0x00007C081B1D0CCE
00007c081b1d125b  vorps xmm14, xmm15, [0x00007C081ADFE040]
00007c081b1d1263  jmp 0x00007C081B1D0CCE
00007c081b1d1268  call 0x00007C081B0C0370
00007c081b1d126d  jmp 0x00007C081B1D0CDF
00007c081b1d1272  ucomisd xmm15, xmm14
00007c081b1d1277  jp 0x00007C081B1D1286
00007c081b1d1279  movaps xmm13, [0x00007C081ADFE030]
00007c081b1d1281  jmp 0x00007C081B1D0D0C
00007c081b1d1286  vxorps xmm0, xmm15, xmm14
00007c081b1d128b  pextrw r12d, xmm0, 0x03
00007c081b1d1291  and r12d, 0x7FF8
00007c081b1d1298  cmp r12d, 0x08
00007c081b1d129c  jnz 0x00007C081B1D0D0C
00007c081b1d12a2  movq r12, xmm14
00007c081b1d12a7  shl r12, 0x0D
00007c081b1d12ab  jbe 0x00007C081B1D0D0C
00007c081b1d12b1  vorps xmm13, xmm14, [0x00007C081ADFE040]
00007c081b1d12b9  jmp 0x00007C081B1D0D0C
00007c081b1d12be  ucomisd xmm1, xmm15
00007c081b1d12c3  jp 0x00007C081B1D12D2
00007c081b1d12c5  movaps xmm14, [0x00007C081ADFE030]
00007c081b1d12cd  jmp 0x00007C081B1D0D41
00007c081b1d12d2  vxorps xmm0, xmm1, xmm15
00007c081b1d12d7  pextrw r12d, xmm0, 0x03
00007c081b1d12dd  and r12d, 0x7FF8
00007c081b1d12e4  cmp r12d, 0x08
00007c081b1d12e8  jnz 0x00007C081B1D0D41
00007c081b1d12ee  movq r12, xmm15
00007c081b1d12f3  shl r12, 0x0D
00007c081b1d12f7  jbe 0x00007C081B1D0D41
00007c081b1d12fd  vorps xmm14, xmm15, [0x00007C081ADFE040]
00007c081b1d1305  jmp 0x00007C081B1D0D41
00007c081b1d130a  call 0x00007C081B0C3AE0
00007c081b1d130f  jmp 0x00007C081B1D0D52
00007c081b1d1314  ucomisd xmm15, xmm14
00007c081b1d1319  jp 0x00007C081B1D1328
00007c081b1d131b  movaps xmm13, [0x00007C081ADFE030]
00007c081b1d1323  jmp 0x00007C081B1D0D87
00007c081b1d1328  vxorps xmm0, xmm15, xmm14
00007c081b1d132d  pextrw r14d, xmm0, 0x03
00007c081b1d1333  and r14d, 0x7FF8
00007c081b1d133a  cmp r14d, 0x08
00007c081b1d133e  jnz 0x00007C081B1D0D87
00007c081b1d1344  movq r14, xmm14
00007c081b1d1349  shl r14, 0x0D
00007c081b1d134d  jbe 0x00007C081B1D0D87
00007c081b1d1353  vorps xmm13, xmm14, [0x00007C081ADFE040]
00007c081b1d135b  jmp 0x00007C081B1D0D87
00007c081b1d1360  ucomisd xmm1, xmm15
00007c081b1d1365  jp 0x00007C081B1D1374
00007c081b1d1367  movaps xmm14, [0x00007C081ADFE030]
00007c081b1d136f  jmp 0x00007C081B1D0DBC
00007c081b1d1374  vxorps xmm0, xmm1, xmm15
00007c081b1d1379  pextrw r14d, xmm0, 0x03
00007c081b1d137f  and r14d, 0x7FF8
00007c081b1d1386  cmp r14d, 0x08
00007c081b1d138a  jnz 0x00007C081B1D0DBC
00007c081b1d1390  movq r14, xmm15
00007c081b1d1395  shl r14, 0x0D
00007c081b1d1399  jbe 0x00007C081B1D0DBC
00007c081b1d139f  vorps xmm14, xmm15, [0x00007C081ADFE040]
00007c081b1d13a7  jmp 0x00007C081B1D0DBC
00007c081b1d13ac  ucomisd xmm1, xmm15
00007c081b1d13b1  jp 0x00007C081B1D13C0
00007c081b1d13b3  movaps xmm14, [0x00007C081ADFE030]
00007c081b1d13bb  jmp 0x00007C081B1D0DF1
00007c081b1d13c0  vxorps xmm0, xmm1, xmm15
00007c081b1d13c5  pextrw r14d, xmm0, 0x03
00007c081b1d13cb  and r14d, 0x7FF8
00007c081b1d13d2  cmp r14d, 0x08
00007c081b1d13d6  jnz 0x00007C081B1D0DF1
00007c081b1d13dc  movq r14, xmm15
00007c081b1d13e1  shl r14, 0x0D
00007c081b1d13e5  jbe 0x00007C081B1D0DF1
00007c081b1d13eb  vorps xmm14, xmm15, [0x00007C081ADFE040]
00007c081b1d13f3  jmp 0x00007C081B1D0DF1
00007c081b1d13f8  call 0x00007C081B00E120
00007c081b1d13fd  jmp 0x00007C081B1D0E08
00007c081b1d1402  int3
00007c081b1d1403  nop [rax+rax*1], ax
00007c081b1d140c  nop [rax], eax
00007c081b1d1410  mov qword ptr [r15+0x40], 0x420000
00007c081b1d1418  mov eax, 0x4201B8
00007c081b1d141d  mov r14, [r13+rax*1]
00007c081b1d1422  movq xmm1, r14
00007c081b1d1427  mov rax, [r15+0x50]
00007c081b1d142b  mov r14, [r13+rax*1]
00007c081b1d1430  movq xmm15, r14
00007c081b1d1435  movaps [r15+0x120], xmm15
00007c081b1d143d  mov qword ptr [r15+0x48], 0x08
00007c081b1d1445  xor eax, eax
00007c081b1d1447  mov r14d, 0x08
00007c081b1d144d  mov r12d, 0x200
00007c081b1d1453  cmp r14, r12
00007c081b1d1456  cmc
00007c081b1d1457  lahf
00007c081b1d1458  seto al
00007c081b1d145b  mov [r15+0x108], eax
00007c081b1d1462  movq rax, xmm1
00007c081b1d1467  movq r14, xmm15
00007c081b1d146c  vmovq xmm1, rax
00007c081b1d1471  vmovq xmm15, r14
00007c081b1d1476  movaps xmm14, xmm1
00007c081b1d147a  addsd xmm14, xmm15
00007c081b1d147f  ucomisd xmm14, xmm14
00007c081b1d1484  jp 0x00007C081B1D1516
00007c081b1d148a  movq xmm14, xmm14
00007c081b1d148f  movaps [r15+0x110], xmm14
00007c081b1d1497  mov eax, [r15+0x108]
00007c081b1d149e  sahf
00007c081b1d149f  jnz 0x00007C081B1D14D1
00007c081b1d14a1  cmp dword ptr [r15+0x318], 0x00
00007c081b1d14a9  jz 0x00007C081B1D16A0
00007c081b1d14af  nop [rax+rax*1], ax
00007c081b1d14b8  nop [rax+rax*1], eax
00007c081b1d14c0  mov eax, 0x410154
00007c081b1d14c5  mov [r15+0x100], rax
00007c081b1d14cc  jmp 0x00007C081AFFE110
00007c081b1d14d1  cmp dword ptr [r15+0x318], 0x00
00007c081b1d14d9  jz 0x00007C081B1D1560
00007c081b1d14df  nop [rax+rax*1], ax
00007c081b1d14e8  nop [rax+rax*1], eax
00007c081b1d14f0  mov eax, 0x410140
00007c081b1d14f5  mov [r15+0x100], rax
00007c081b1d14fc  jmp 0x00007C081AFFE110
00007c081b1d1501  int3
00007c081b1d1502  call 0x00007C081B00DC20
00007c081b1d1507  jmp 0x00007C081B1D1422
00007c081b1d150c  call 0x00007C081B00DC20
00007c081b1d1511  jmp 0x00007C081B1D1430
00007c081b1d1516  ucomisd xmm1, xmm15
00007c081b1d151b  jp 0x00007C081B1D152A
00007c081b1d151d  movaps xmm14, [0x00007C081ADFE030]
00007c081b1d1525  jmp 0x00007C081B1D148A
00007c081b1d152a  vxorps xmm0, xmm1, xmm15
00007c081b1d152f  pextrw eax, xmm0, 0x03
00007c081b1d1534  and eax, 0x7FF8
00007c081b1d1539  cmp eax, 0x08
00007c081b1d153c  jnz 0x00007C081B1D148A
00007c081b1d1542  movq rax, xmm15
00007c081b1d1547  shl rax, 0x0D
00007c081b1d154b  jbe 0x00007C081B1D148A
00007c081b1d1551  vorps xmm14, xmm15, [0x00007C081ADFE040]
00007c081b1d1559  jmp 0x00007C081B1D148A
00007c081b1d155e  int3
00007c081b1d155f  nop
00007c081b1d1560  mov rax, [r15+0x48]
00007c081b1d1564  mov r14, [r15+0x50]
00007c081b1d1568  lea r12, [r14+rax*1]
00007c081b1d156c  mov r14, [r13+r12*1]
00007c081b1d1571  movq xmm1, r14
00007c081b1d1576  movaps [r15+0x120], xmm1
00007c081b1d157e  lea r14, [rax+0x08]
00007c081b1d1582  mov [r15+0x48], r14
00007c081b1d1586  xor eax, eax
00007c081b1d1588  mov r12d, 0x200
00007c081b1d158e  cmp r14, r12
00007c081b1d1591  cmc
00007c081b1d1592  lahf
00007c081b1d1593  seto al
00007c081b1d1596  mov [r15+0x108], eax
00007c081b1d159d  movaps xmm15, [r15+0x110]
00007c081b1d15a5  movq rax, xmm15
00007c081b1d15aa  movq r14, xmm1
00007c081b1d15af  vmovq xmm1, rax
00007c081b1d15b4  vmovq xmm15, r14
00007c081b1d15b9  movaps xmm14, xmm1
00007c081b1d15bd  addsd xmm14, xmm15
00007c081b1d15c2  ucomisd xmm14, xmm14
00007c081b1d15c7  jp 0x00007C081B1D164F
00007c081b1d15cd  movq xmm14, xmm14
00007c081b1d15d2  movaps [r15+0x110], xmm14
00007c081b1d15da  mov eax, [r15+0x108]
00007c081b1d15e1  sahf
00007c081b1d15e2  jnz 0x00007C081B1D1614
00007c081b1d15e4  cmp dword ptr [r15+0x318], 0x00
00007c081b1d15ec  jz 0x00007C081B1D16A0
00007c081b1d15f2  nop [rax+rax*1], ax
00007c081b1d15fb  nop [rax+rax*1], eax
00007c081b1d1603  mov eax, 0x410154
00007c081b1d1608  mov [r15+0x100], rax
00007c081b1d160f  jmp 0x00007C081AFFE110
00007c081b1d1614  cmp dword ptr [r15+0x318], 0x00
00007c081b1d161c  jz 0x00007C081B1D1560
00007c081b1d1622  nop [rax+rax*1], ax
00007c081b1d162b  nop [rax+rax*1], eax
00007c081b1d1633  mov eax, 0x410140
00007c081b1d1638  mov [r15+0x100], rax
00007c081b1d163f  jmp 0x00007C081AFFE110
00007c081b1d1644  int3
00007c081b1d1645  call 0x00007C081B0C3AE0
00007c081b1d164a  jmp 0x00007C081B1D1571
00007c081b1d164f  ucomisd xmm1, xmm15
00007c081b1d1654  jp 0x00007C081B1D1663
00007c081b1d1656  movaps xmm14, [0x00007C081ADFE030]
00007c081b1d165e  jmp 0x00007C081B1D15CD
00007c081b1d1663  vxorps xmm0, xmm1, xmm15
00007c081b1d1668  pextrw eax, xmm0, 0x03
00007c081b1d166d  and eax, 0x7FF8
00007c081b1d1672  cmp eax, 0x08
00007c081b1d1675  jnz 0x00007C081B1D15CD
00007c081b1d167b  movq rax, xmm15
00007c081b1d1680  shl rax, 0x0D
00007c081b1d1684  jbe 0x00007C081B1D15CD
00007c081b1d168a  vorps xmm14, xmm15, [0x00007C081ADFE040]
00007c081b1d1692  jmp 0x00007C081B1D15CD
00007c081b1d1697  int3
00007c081b1d1698  nop [rax+rax*1], eax
00007c081b1d16a0  mov rax, [r15+0x40]
00007c081b1d16a4  lea r14, [rax+0x1B8]
00007c081b1d16ab  movaps xmm1, [r15+0x110]
00007c081b1d16b3  movq rax, xmm1
00007c081b1d16b8  mov [r13+r14*1], rax
00007c081b1d16bd  mov rax, [r15+0xF0]
00007c081b1d16c4  mov [r15+0x100], rax
00007c081b1d16cb  jmp 0x00007C081B1CE5C0
00007c081b1d16d0  int3
00007c081b1d16d1  call 0x00007C081B0D5EB0
00007c081b1d16d6  jmp 0x00007C081B1D16BD
00007c081b1d16db  int3
00007c081b1d16dc  nop [rax], eax
00007c081b1d16e0  mov qword ptr [r15+0x100], 0x04
00007c081b1d16eb  mov esi, 0x00
00007c081b1d16f0  mov edx, 0x09
00007c081b1d16f5  mov rdi, 0x7FFE548E2E30
00007c081b1d16ff  mov rax, 0x579C9AD01970
00007c081b1d1709  call rax
00007c081b1d170b  cmp dword ptr [r15+0x318], 0x00
00007c081b1d1713  jnz 0x00007C081AFFE110
00007c081b1d1719  jmp 0x00007C081AFFE0A0
00007c081b1d171e  int3
00007c081b1d171f  int3
