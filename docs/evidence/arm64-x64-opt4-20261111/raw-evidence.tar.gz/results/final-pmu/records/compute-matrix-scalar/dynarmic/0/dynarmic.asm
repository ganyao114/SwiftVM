000078c0f8fce69b  nop [rax+rax*1], eax
000078c0f8fce6a0  mov qword ptr [r15+0x40], 0x4201C0
000078c0f8fce6a8  mov qword ptr [r15+0x48], 0x4203C0
000078c0f8fce6b0  mov qword ptr [r15+0x60], 0x01
000078c0f8fce6b8  xorps xmm1, xmm1
000078c0f8fce6bb  mov eax, 0x41
000078c0f8fce6c0  vcvtusi2sd xmm1, xmm1, eax
000078c0f8fce6c6  mulsd xmm1, [0x000078C0F8BFE010]
000078c0f8fce6ce  movq xmm1, xmm1
000078c0f8fce6d2  movaps [r15+0x120], xmm1
000078c0f8fce6da  mov eax, [r15+0x60]
000078c0f8fce6de  xorps xmm15, xmm15
000078c0f8fce6e2  vcvtusi2sd xmm15, xmm15, eax
000078c0f8fce6e8  mulsd xmm15, [0x000078C0F8BFE020]
000078c0f8fce6f1  movq xmm15, xmm15
000078c0f8fce6f6  movaps [r15+0x110], xmm15
000078c0f8fce6fe  mov rax, [r15+0x60]
000078c0f8fce702  mov [rsp+0x10], rax
000078c0f8fce707  xor eax, eax
000078c0f8fce709  mov r14, [rsp+0x10]
000078c0f8fce70e  mov r12d, 0x40
000078c0f8fce714  cmp r14, r12
000078c0f8fce717  cmc
000078c0f8fce718  lahf
000078c0f8fce719  seto al
000078c0f8fce71c  mov [r15+0x108], eax
000078c0f8fce723  mov qword ptr [r15+0x50], 0x40
000078c0f8fce72b  movq rax, xmm1
000078c0f8fce730  mov r12d, 0x4203C0
000078c0f8fce736  mov [r13+r12*1], rax
000078c0f8fce73b  movq rax, xmm15
000078c0f8fce740  mov r12d, 0x4201C0
000078c0f8fce746  mov [r13+r12*1], rax
000078c0f8fce74b  mov [r15+0x58], r14
000078c0f8fce74f  mov eax, [r15+0x108]
000078c0f8fce756  sahf
000078c0f8fce757  jnz 0x000078C0F8FCE789
000078c0f8fce759  cmp dword ptr [r15+0x318], 0x00
000078c0f8fce761  jz 0x000078C0F8FCE910
000078c0f8fce767  nop [rax+rax*1], ax
000078c0f8fce770  nop [rax+rax*1], eax
000078c0f8fce778  mov eax, 0x410074
000078c0f8fce77d  mov [r15+0x100], rax
000078c0f8fce784  jmp 0x000078C0F8DFE110
000078c0f8fce789  cmp dword ptr [r15+0x318], 0x00
000078c0f8fce791  jz 0x000078C0F8FCE7D0
000078c0f8fce797  nop [rax+rax*1], ax
000078c0f8fce7a0  nop [rax+rax*1], eax
000078c0f8fce7a8  mov eax, 0x41004C
000078c0f8fce7ad  mov [r15+0x100], rax
000078c0f8fce7b4  jmp 0x000078C0F8DFE110
000078c0f8fce7b9  int3
000078c0f8fce7ba  call 0x000078C0F8EB4CB0
000078c0f8fce7bf  jmp 0x000078C0F8FCE73B
000078c0f8fce7c4  call 0x000078C0F8EB4CB0
000078c0f8fce7c9  jmp 0x000078C0F8FCE74B
000078c0f8fce7ce  int3
000078c0f8fce7cf  nop
000078c0f8fce7d0  mov rax, [r15+0x58]
000078c0f8fce7d4  lea r14, [rax+0x01]
000078c0f8fce7d8  mov [r15+0x60], r14
000078c0f8fce7dc  mov r14d, [r15+0x50]
000078c0f8fce7e0  xorps xmm1, xmm1
000078c0f8fce7e3  vcvtusi2sd xmm1, xmm1, r14d
000078c0f8fce7e9  mulsd xmm1, [0x000078C0F8BFE010]
000078c0f8fce7f1  movq xmm1, xmm1
000078c0f8fce7f5  movaps [r15+0x120], xmm1
000078c0f8fce7fd  rorx r12, rax, 0x3D
000078c0f8fce803  and r12, 0xFFFFFFFFFFFFFFF8
000078c0f8fce807  mov eax, [r15+0x60]
000078c0f8fce80b  xorps xmm15, xmm15
000078c0f8fce80f  vcvtusi2sd xmm15, xmm15, eax
000078c0f8fce815  mulsd xmm15, [0x000078C0F8BFE020]
000078c0f8fce81e  movq xmm15, xmm15
000078c0f8fce823  movaps [r15+0x110], xmm15
000078c0f8fce82b  mov rax, [r15+0x60]
000078c0f8fce82f  mov [rsp+0x10], rax
000078c0f8fce834  xor eax, eax
000078c0f8fce836  mov r11, [rsp+0x10]
000078c0f8fce83b  mov r10d, 0x40
000078c0f8fce841  cmp r11, r10
000078c0f8fce844  cmc
000078c0f8fce845  lahf
000078c0f8fce846  seto al
000078c0f8fce849  mov [r15+0x108], eax
000078c0f8fce850  lea eax, [r14d-0x01]
000078c0f8fce855  mov eax, eax
000078c0f8fce857  mov [r15+0x50], rax
000078c0f8fce85b  mov rax, [r15+0x48]
000078c0f8fce85f  lea r14, [rax+r12*1]
000078c0f8fce863  movq rax, xmm1
000078c0f8fce868  mov [r13+r14*1], rax
000078c0f8fce86d  mov rax, [r15+0x40]
000078c0f8fce871  lea r14, [rax+r12*1]
000078c0f8fce875  movq rax, xmm15
000078c0f8fce87a  mov [r13+r14*1], rax
000078c0f8fce87f  mov [r15+0x58], r11
000078c0f8fce883  mov eax, [r15+0x108]
000078c0f8fce88a  sahf
000078c0f8fce88b  jnz 0x000078C0F8FCE8BD
000078c0f8fce88d  cmp dword ptr [r15+0x318], 0x00
000078c0f8fce895  jz 0x000078C0F8FCE910
000078c0f8fce89b  nop [rax+rax*1], ax
000078c0f8fce8a4  nop [rax+rax*1], eax
000078c0f8fce8ac  mov eax, 0x410074
000078c0f8fce8b1  mov [r15+0x100], rax
000078c0f8fce8b8  jmp 0x000078C0F8DFE110
000078c0f8fce8bd  cmp dword ptr [r15+0x318], 0x00
000078c0f8fce8c5  jz 0x000078C0F8FCE7D0
000078c0f8fce8cb  nop [rax+rax*1], ax
000078c0f8fce8d4  nop [rax+rax*1], eax
000078c0f8fce8dc  mov eax, 0x41004C
000078c0f8fce8e1  mov [r15+0x100], rax
000078c0f8fce8e8  jmp 0x000078C0F8DFE110
000078c0f8fce8ed  int3
000078c0f8fce8ee  call 0x000078C0F8ED5EB0
000078c0f8fce8f3  jmp 0x000078C0F8FCE86D
000078c0f8fce8f8  call 0x000078C0F8ED5EB0
000078c0f8fce8fd  jmp 0x000078C0F8FCE87F
000078c0f8fce902  int3
000078c0f8fce903  nop [rax+rax*1], ax
000078c0f8fce90c  nop [rax], eax
000078c0f8fce910  vxorps xmm1, xmm1, xmm1
000078c0f8fce914  movq xmm1, xmm1
000078c0f8fce918  movaps [r15+0x110], xmm1
000078c0f8fce920  mov qword ptr [r15+0x58], 0x00
000078c0f8fce928  mov qword ptr [r15+0x50], 0x4205C0
000078c0f8fce930  mov qword ptr [r15+0x60], 0x00
000078c0f8fce938  mov qword ptr [r15+0x68], 0x4205C0
000078c0f8fce940  mov rax, [r15+0x40]
000078c0f8fce944  mov r14, [r13+rax*1]
000078c0f8fce949  lea r12, [rax+0x08]
000078c0f8fce94d  mov r11, [r13+r12*1]
000078c0f8fce952  movq xmm15, r14
000078c0f8fce957  movq xmm14, r11
000078c0f8fce95c  movq xmm15, xmm15
000078c0f8fce961  movq xmm15, xmm15
000078c0f8fce966  movaps [r15+0x120], xmm15
000078c0f8fce96e  movq xmm14, xmm14
000078c0f8fce973  movq xmm14, xmm14
000078c0f8fce978  movaps [r15+0x130], xmm14
000078c0f8fce980  lea r14, [rax+0x10]
000078c0f8fce984  mov r12, [r13+r14*1]
000078c0f8fce989  lea r14, [rax+0x18]
000078c0f8fce98d  mov r11, [r13+r14*1]
000078c0f8fce992  movq xmm15, r12
000078c0f8fce997  movq xmm14, r11
000078c0f8fce99c  movq xmm15, xmm15
000078c0f8fce9a1  movq xmm15, xmm15
000078c0f8fce9a6  movaps [r15+0x140], xmm15
000078c0f8fce9ae  movq xmm14, xmm14
000078c0f8fce9b3  movq xmm14, xmm14
000078c0f8fce9b8  movaps [r15+0x150], xmm14
000078c0f8fce9c0  lea r14, [rax+0x20]
000078c0f8fce9c4  mov r12, [r13+r14*1]
000078c0f8fce9c9  lea r14, [rax+0x28]
000078c0f8fce9cd  mov r11, [r13+r14*1]
000078c0f8fce9d2  movq xmm15, r12
000078c0f8fce9d7  movq xmm14, r11
000078c0f8fce9dc  movq xmm15, xmm15
000078c0f8fce9e1  movq xmm15, xmm15
000078c0f8fce9e6  movaps [r15+0x160], xmm15
000078c0f8fce9ee  movq xmm14, xmm14
000078c0f8fce9f3  movq xmm14, xmm14
000078c0f8fce9f8  movaps [r15+0x170], xmm14
000078c0f8fcea00  lea r14, [rax+0x30]
000078c0f8fcea04  mov r12, [r13+r14*1]
000078c0f8fcea09  lea r14, [rax+0x38]
000078c0f8fcea0d  mov rax, [r13+r14*1]
000078c0f8fcea12  movq xmm15, r12
000078c0f8fcea17  movq xmm14, rax
000078c0f8fcea1c  movq xmm15, xmm15
000078c0f8fcea21  movq xmm15, xmm15
000078c0f8fcea26  movaps [r15+0x180], xmm15
000078c0f8fcea2e  movq xmm14, xmm14
000078c0f8fcea33  movq xmm14, xmm14
000078c0f8fcea38  movaps [r15+0x210], xmm14
000078c0f8fcea40  mov rax, [r15+0x48]
000078c0f8fcea44  mov [r15+0x78], rax
000078c0f8fcea48  mov r14, [r13+rax*1]
000078c0f8fcea4d  movq xmm15, r14
000078c0f8fcea52  lea r14, [rax+0x40]
000078c0f8fcea56  mov r12, [r13+r14*1]
000078c0f8fcea5b  movq xmm14, r12
000078c0f8fcea60  lea r14, [rax+0x80]
000078c0f8fcea67  mov r12, [r13+r14*1]
000078c0f8fcea6c  movq xmm13, r12
000078c0f8fcea71  movaps xmm12, [r15+0x120]
000078c0f8fcea79  movq r14, xmm12
000078c0f8fcea7e  movq r12, xmm15
000078c0f8fcea83  vmovq xmm15, r14
000078c0f8fcea88  vmovq xmm12, r12
000078c0f8fcea8d  movaps xmm11, xmm15
000078c0f8fcea91  mulsd xmm11, xmm12
000078c0f8fcea96  ucomisd xmm11, xmm11
000078c0f8fcea9b  jp 0x000078C0F8FCEEFC
000078c0f8fceaa1  movq xmm11, xmm11
000078c0f8fceaa6  movaps xmm15, [r15+0x130]
000078c0f8fceaae  movq r14, xmm15
000078c0f8fceab3  movq r12, xmm14
000078c0f8fceab8  vmovq xmm15, r14
000078c0f8fceabd  vmovq xmm14, r12
000078c0f8fceac2  movaps xmm12, xmm15
000078c0f8fceac6  mulsd xmm12, xmm14
000078c0f8fceacb  ucomisd xmm12, xmm12
000078c0f8fcead0  jp 0x000078C0F8FCEF48
000078c0f8fcead6  movq xmm12, xmm12
000078c0f8fceadb  movq r14, xmm11
000078c0f8fceae0  movq r12, xmm1
000078c0f8fceae5  vmovq xmm1, r14
000078c0f8fceaea  vmovq xmm15, r12
000078c0f8fceaef  movaps xmm14, xmm1
000078c0f8fceaf3  addsd xmm14, xmm15
000078c0f8fceaf8  ucomisd xmm14, xmm14
000078c0f8fceafd  jp 0x000078C0F8FCEF94
000078c0f8fceb03  movq xmm14, xmm14
000078c0f8fceb08  movq r14, xmm14
000078c0f8fceb0d  movq r12, xmm12
000078c0f8fceb12  vmovq xmm1, r14
000078c0f8fceb17  vmovq xmm15, r12
000078c0f8fceb1c  movaps xmm14, xmm1
000078c0f8fceb20  addsd xmm14, xmm15
000078c0f8fceb25  ucomisd xmm14, xmm14
000078c0f8fceb2a  jp 0x000078C0F8FCEFE0
000078c0f8fceb30  movq xmm14, xmm14
000078c0f8fceb35  movaps xmm1, [r15+0x140]
000078c0f8fceb3d  movq r14, xmm1
000078c0f8fceb42  movq r12, xmm13
000078c0f8fceb47  vmovq xmm1, r14
000078c0f8fceb4c  vmovq xmm15, r12
000078c0f8fceb51  movaps xmm13, xmm1
000078c0f8fceb55  mulsd xmm13, xmm15
000078c0f8fceb5a  ucomisd xmm13, xmm13
000078c0f8fceb5f  jp 0x000078C0F8FCF02C
000078c0f8fceb65  movq xmm13, xmm13
000078c0f8fceb6a  lea r14, [rax+0xC0]
000078c0f8fceb71  mov r12, [r13+r14*1]
000078c0f8fceb76  movq xmm1, r12
000078c0f8fceb7b  movq r14, xmm14
000078c0f8fceb80  movq r12, xmm13
000078c0f8fceb85  vmovq xmm15, r14
000078c0f8fceb8a  vmovq xmm14, r12
000078c0f8fceb8f  movaps xmm13, xmm15
000078c0f8fceb93  addsd xmm13, xmm14
000078c0f8fceb98  ucomisd xmm13, xmm13
000078c0f8fceb9d  jp 0x000078C0F8FCF082
000078c0f8fceba3  movq xmm13, xmm13
000078c0f8fceba8  movaps xmm15, [r15+0x150]
000078c0f8fcebb0  movq r14, xmm15
000078c0f8fcebb5  movq r12, xmm1
000078c0f8fcebba  vmovq xmm1, r14
000078c0f8fcebbf  vmovq xmm15, r12
000078c0f8fcebc4  movaps xmm14, xmm1
000078c0f8fcebc8  mulsd xmm14, xmm15
000078c0f8fcebcd  ucomisd xmm14, xmm14
000078c0f8fcebd2  jp 0x000078C0F8FCF0CE
000078c0f8fcebd8  movq xmm14, xmm14
000078c0f8fcebdd  lea r14, [rax+0x100]
000078c0f8fcebe4  mov r12, [r13+r14*1]
000078c0f8fcebe9  movq xmm1, r12
000078c0f8fcebee  movq r14, xmm13
000078c0f8fcebf3  movq r12, xmm14
000078c0f8fcebf8  vmovq xmm15, r14
000078c0f8fcebfd  vmovq xmm14, r12
000078c0f8fcec02  movaps xmm13, xmm15
000078c0f8fcec06  addsd xmm13, xmm14
000078c0f8fcec0b  ucomisd xmm13, xmm13
000078c0f8fcec10  jp 0x000078C0F8FCF124
000078c0f8fcec16  movq xmm13, xmm13
000078c0f8fcec1b  movaps xmm15, [r15+0x160]
000078c0f8fcec23  movq r14, xmm15
000078c0f8fcec28  movq r12, xmm1
000078c0f8fcec2d  vmovq xmm1, r14
000078c0f8fcec32  vmovq xmm15, r12
000078c0f8fcec37  movaps xmm14, xmm1
000078c0f8fcec3b  mulsd xmm14, xmm15
000078c0f8fcec40  ucomisd xmm14, xmm14
000078c0f8fcec45  jp 0x000078C0F8FCF170
000078c0f8fcec4b  movq xmm14, xmm14
000078c0f8fcec50  lea r14, [rax+0x140]
000078c0f8fcec57  mov r12, [r13+r14*1]
000078c0f8fcec5c  movq xmm1, r12
000078c0f8fcec61  movq r14, xmm13
000078c0f8fcec66  movq r12, xmm14
000078c0f8fcec6b  vmovq xmm15, r14
000078c0f8fcec70  vmovq xmm14, r12
000078c0f8fcec75  movaps xmm13, xmm15
000078c0f8fcec79  addsd xmm13, xmm14
000078c0f8fcec7e  ucomisd xmm13, xmm13
000078c0f8fcec83  jp 0x000078C0F8FCF1C6
000078c0f8fcec89  movq xmm13, xmm13
000078c0f8fcec8e  movaps xmm15, [r15+0x170]
000078c0f8fcec96  movq r14, xmm15
000078c0f8fcec9b  movq r12, xmm1
000078c0f8fceca0  vmovq xmm1, r14
000078c0f8fceca5  vmovq xmm15, r12
000078c0f8fcecaa  movaps xmm14, xmm1
000078c0f8fcecae  mulsd xmm14, xmm15
000078c0f8fcecb3  ucomisd xmm14, xmm14
000078c0f8fcecb8  jp 0x000078C0F8FCF212
000078c0f8fcecbe  movq xmm14, xmm14
000078c0f8fcecc3  lea r14, [rax+0x180]
000078c0f8fcecca  mov r12, [r13+r14*1]
000078c0f8fceccf  movq xmm1, r12
000078c0f8fcecd4  movq r14, xmm13
000078c0f8fcecd9  movq r12, xmm14
000078c0f8fcecde  vmovq xmm15, r14
000078c0f8fcece3  vmovq xmm14, r12
000078c0f8fcece8  movaps xmm13, xmm15
000078c0f8fcecec  addsd xmm13, xmm14
000078c0f8fcecf1  ucomisd xmm13, xmm13
000078c0f8fcecf6  jp 0x000078C0F8FCF268
000078c0f8fcecfc  movq xmm13, xmm13
000078c0f8fced01  movaps xmm15, [r15+0x180]
000078c0f8fced09  movq r14, xmm15
000078c0f8fced0e  movq r12, xmm1
000078c0f8fced13  vmovq xmm1, r14
000078c0f8fced18  vmovq xmm15, r12
000078c0f8fced1d  movaps xmm14, xmm1
000078c0f8fced21  mulsd xmm14, xmm15
000078c0f8fced26  ucomisd xmm14, xmm14
000078c0f8fced2b  jp 0x000078C0F8FCF2B4
000078c0f8fced31  movq xmm14, xmm14
000078c0f8fced36  lea r14, [rax+0x1C0]
000078c0f8fced3d  mov rax, [r13+r14*1]
000078c0f8fced42  movq xmm1, rax
000078c0f8fced47  movaps [r15+0x240], xmm1
000078c0f8fced4f  movq rax, xmm13
000078c0f8fced54  movq r14, xmm14
000078c0f8fced59  vmovq xmm15, rax
000078c0f8fced5e  vmovq xmm14, r14
000078c0f8fced63  movaps xmm13, xmm15
000078c0f8fced67  addsd xmm13, xmm14
000078c0f8fced6c  ucomisd xmm13, xmm13
000078c0f8fced71  jp 0x000078C0F8FCF30A
000078c0f8fced77  movq xmm13, xmm13
000078c0f8fced7c  movaps xmm15, [r15+0x210]
000078c0f8fced84  movq rax, xmm15
000078c0f8fced89  movq r14, xmm1
000078c0f8fced8e  vmovq xmm1, rax
000078c0f8fced93  vmovq xmm15, r14
000078c0f8fced98  movaps xmm14, xmm1
000078c0f8fced9c  mulsd xmm14, xmm15
000078c0f8fceda1  ucomisd xmm14, xmm14
000078c0f8fceda6  jp 0x000078C0F8FCF352
000078c0f8fcedac  movq xmm14, xmm14
000078c0f8fcedb1  movaps [r15+0x230], xmm14
000078c0f8fcedb9  movq rax, xmm13
000078c0f8fcedbe  movq r14, xmm14
000078c0f8fcedc3  vmovq xmm1, rax
000078c0f8fcedc8  vmovq xmm15, r14
000078c0f8fcedcd  movaps xmm14, xmm1
000078c0f8fcedd1  addsd xmm14, xmm15
000078c0f8fcedd6  ucomisd xmm14, xmm14
000078c0f8fceddb  jp 0x000078C0F8FCF39A
000078c0f8fcede1  movq xmm14, xmm14
000078c0f8fcede6  movaps [r15+0x220], xmm14
000078c0f8fcedee  movq rax, xmm14
000078c0f8fcedf3  mov r14d, 0x4205C0
000078c0f8fcedf9  mov [r13+r14*1], rax
000078c0f8fcedfe  mov qword ptr [r15+0x70], 0x08
000078c0f8fcee06  xor eax, eax
000078c0f8fcee08  mov r14d, 0x08
000078c0f8fcee0e  mov r12d, 0x40
000078c0f8fcee14  cmp r14, r12
000078c0f8fcee17  cmc
000078c0f8fcee18  lahf
000078c0f8fcee19  seto al
000078c0f8fcee1c  mov [r15+0x108], eax
000078c0f8fcee23  mov eax, [r15+0x108]
000078c0f8fcee2a  sahf
000078c0f8fcee2b  jnz 0x000078C0F8FCEE5D
000078c0f8fcee2d  cmp dword ptr [r15+0x318], 0x00
000078c0f8fcee35  jz 0x000078C0F8FCFD40
000078c0f8fcee3b  nop [rax+rax*1], ax
000078c0f8fcee44  nop [rax+rax*1], eax
000078c0f8fcee4c  mov eax, 0x410118
000078c0f8fcee51  mov [r15+0x100], rax
000078c0f8fcee58  jmp 0x000078C0F8DFE110
000078c0f8fcee5d  cmp dword ptr [r15+0x318], 0x00
000078c0f8fcee65  jz 0x000078C0F8FCF3F0
000078c0f8fcee6b  nop [rax+rax*1], ax
000078c0f8fcee74  nop [rax+rax*1], eax
000078c0f8fcee7c  mov eax, 0x4100A4
000078c0f8fcee81  mov [r15+0x100], rax
000078c0f8fcee88  jmp 0x000078C0F8DFE110
000078c0f8fcee8d  int3
000078c0f8fcee8e  call 0x000078C0F8E0DC20
000078c0f8fcee93  jmp 0x000078C0F8FCE949
000078c0f8fcee98  call 0x000078C0F8EC0370
000078c0f8fcee9d  jmp 0x000078C0F8FCE952
000078c0f8fceea2  call 0x000078C0F8EE27E0
000078c0f8fceea7  jmp 0x000078C0F8FCE989
000078c0f8fceeac  call 0x000078C0F8EE1570
000078c0f8fceeb1  jmp 0x000078C0F8FCE992
000078c0f8fceeb6  call 0x000078C0F8EE27E0
000078c0f8fceebb  jmp 0x000078C0F8FCE9C9
000078c0f8fceec0  call 0x000078C0F8EE1570
000078c0f8fceec5  jmp 0x000078C0F8FCE9D2
000078c0f8fceeca  call 0x000078C0F8EE27E0
000078c0f8fceecf  jmp 0x000078C0F8FCEA09
000078c0f8fceed4  call 0x000078C0F8ED59C0
000078c0f8fceed9  jmp 0x000078C0F8FCEA12
000078c0f8fceede  call 0x000078C0F8E0DC20
000078c0f8fceee3  jmp 0x000078C0F8FCEA4D
000078c0f8fceee8  call 0x000078C0F8EE27E0
000078c0f8fceeed  jmp 0x000078C0F8FCEA5B
000078c0f8fceef2  call 0x000078C0F8EE27E0
000078c0f8fceef7  jmp 0x000078C0F8FCEA6C
000078c0f8fceefc  ucomisd xmm15, xmm12
000078c0f8fcef01  jp 0x000078C0F8FCEF10
000078c0f8fcef03  movaps xmm11, [0x000078C0F8BFE030]
000078c0f8fcef0b  jmp 0x000078C0F8FCEAA1
000078c0f8fcef10  vxorps xmm0, xmm15, xmm12
000078c0f8fcef15  pextrw r14d, xmm0, 0x03
000078c0f8fcef1b  and r14d, 0x7FF8
000078c0f8fcef22  cmp r14d, 0x08
000078c0f8fcef26  jnz 0x000078C0F8FCEAA1
000078c0f8fcef2c  movq r14, xmm12
000078c0f8fcef31  shl r14, 0x0D
000078c0f8fcef35  jbe 0x000078C0F8FCEAA1
000078c0f8fcef3b  vorps xmm11, xmm12, [0x000078C0F8BFE040]
000078c0f8fcef43  jmp 0x000078C0F8FCEAA1
000078c0f8fcef48  ucomisd xmm15, xmm14
000078c0f8fcef4d  jp 0x000078C0F8FCEF5C
000078c0f8fcef4f  movaps xmm12, [0x000078C0F8BFE030]
000078c0f8fcef57  jmp 0x000078C0F8FCEAD6
000078c0f8fcef5c  vxorps xmm0, xmm15, xmm14
000078c0f8fcef61  pextrw r14d, xmm0, 0x03
000078c0f8fcef67  and r14d, 0x7FF8
000078c0f8fcef6e  cmp r14d, 0x08
000078c0f8fcef72  jnz 0x000078C0F8FCEAD6
000078c0f8fcef78  movq r14, xmm14
000078c0f8fcef7d  shl r14, 0x0D
000078c0f8fcef81  jbe 0x000078C0F8FCEAD6
000078c0f8fcef87  vorps xmm12, xmm14, [0x000078C0F8BFE040]
000078c0f8fcef8f  jmp 0x000078C0F8FCEAD6
000078c0f8fcef94  ucomisd xmm1, xmm15
000078c0f8fcef99  jp 0x000078C0F8FCEFA8
000078c0f8fcef9b  movaps xmm14, [0x000078C0F8BFE030]
000078c0f8fcefa3  jmp 0x000078C0F8FCEB03
000078c0f8fcefa8  vxorps xmm0, xmm1, xmm15
000078c0f8fcefad  pextrw r14d, xmm0, 0x03
000078c0f8fcefb3  and r14d, 0x7FF8
000078c0f8fcefba  cmp r14d, 0x08
000078c0f8fcefbe  jnz 0x000078C0F8FCEB03
000078c0f8fcefc4  movq r14, xmm15
000078c0f8fcefc9  shl r14, 0x0D
000078c0f8fcefcd  jbe 0x000078C0F8FCEB03
000078c0f8fcefd3  vorps xmm14, xmm15, [0x000078C0F8BFE040]
000078c0f8fcefdb  jmp 0x000078C0F8FCEB03
000078c0f8fcefe0  ucomisd xmm1, xmm15
000078c0f8fcefe5  jp 0x000078C0F8FCEFF4
000078c0f8fcefe7  movaps xmm14, [0x000078C0F8BFE030]
000078c0f8fcefef  jmp 0x000078C0F8FCEB30
000078c0f8fceff4  vxorps xmm0, xmm1, xmm15
000078c0f8fceff9  pextrw r14d, xmm0, 0x03
000078c0f8fcefff  and r14d, 0x7FF8
000078c0f8fcf006  cmp r14d, 0x08
000078c0f8fcf00a  jnz 0x000078C0F8FCEB30
000078c0f8fcf010  movq r14, xmm15
000078c0f8fcf015  shl r14, 0x0D
000078c0f8fcf019  jbe 0x000078C0F8FCEB30
000078c0f8fcf01f  vorps xmm14, xmm15, [0x000078C0F8BFE040]
000078c0f8fcf027  jmp 0x000078C0F8FCEB30
000078c0f8fcf02c  ucomisd xmm1, xmm15
000078c0f8fcf031  jp 0x000078C0F8FCF040
000078c0f8fcf033  movaps xmm13, [0x000078C0F8BFE030]
000078c0f8fcf03b  jmp 0x000078C0F8FCEB65
000078c0f8fcf040  vxorps xmm0, xmm1, xmm15
000078c0f8fcf045  pextrw r14d, xmm0, 0x03
000078c0f8fcf04b  and r14d, 0x7FF8
000078c0f8fcf052  cmp r14d, 0x08
000078c0f8fcf056  jnz 0x000078C0F8FCEB65
000078c0f8fcf05c  movq r14, xmm15
000078c0f8fcf061  shl r14, 0x0D
000078c0f8fcf065  jbe 0x000078C0F8FCEB65
000078c0f8fcf06b  vorps xmm13, xmm15, [0x000078C0F8BFE040]
000078c0f8fcf073  jmp 0x000078C0F8FCEB65
000078c0f8fcf078  call 0x000078C0F8EE27E0
000078c0f8fcf07d  jmp 0x000078C0F8FCEB76
000078c0f8fcf082  ucomisd xmm15, xmm14
000078c0f8fcf087  jp 0x000078C0F8FCF096
000078c0f8fcf089  movaps xmm13, [0x000078C0F8BFE030]
000078c0f8fcf091  jmp 0x000078C0F8FCEBA3
000078c0f8fcf096  vxorps xmm0, xmm15, xmm14
000078c0f8fcf09b  pextrw r14d, xmm0, 0x03
000078c0f8fcf0a1  and r14d, 0x7FF8
000078c0f8fcf0a8  cmp r14d, 0x08
000078c0f8fcf0ac  jnz 0x000078C0F8FCEBA3
000078c0f8fcf0b2  movq r14, xmm14
000078c0f8fcf0b7  shl r14, 0x0D
000078c0f8fcf0bb  jbe 0x000078C0F8FCEBA3
000078c0f8fcf0c1  vorps xmm13, xmm14, [0x000078C0F8BFE040]
000078c0f8fcf0c9  jmp 0x000078C0F8FCEBA3
000078c0f8fcf0ce  ucomisd xmm1, xmm15
000078c0f8fcf0d3  jp 0x000078C0F8FCF0E2
000078c0f8fcf0d5  movaps xmm14, [0x000078C0F8BFE030]
000078c0f8fcf0dd  jmp 0x000078C0F8FCEBD8
000078c0f8fcf0e2  vxorps xmm0, xmm1, xmm15
000078c0f8fcf0e7  pextrw r14d, xmm0, 0x03
000078c0f8fcf0ed  and r14d, 0x7FF8
000078c0f8fcf0f4  cmp r14d, 0x08
000078c0f8fcf0f8  jnz 0x000078C0F8FCEBD8
000078c0f8fcf0fe  movq r14, xmm15
000078c0f8fcf103  shl r14, 0x0D
000078c0f8fcf107  jbe 0x000078C0F8FCEBD8
000078c0f8fcf10d  vorps xmm14, xmm15, [0x000078C0F8BFE040]
000078c0f8fcf115  jmp 0x000078C0F8FCEBD8
000078c0f8fcf11a  call 0x000078C0F8EE27E0
000078c0f8fcf11f  jmp 0x000078C0F8FCEBE9
000078c0f8fcf124  ucomisd xmm15, xmm14
000078c0f8fcf129  jp 0x000078C0F8FCF138
000078c0f8fcf12b  movaps xmm13, [0x000078C0F8BFE030]
000078c0f8fcf133  jmp 0x000078C0F8FCEC16
000078c0f8fcf138  vxorps xmm0, xmm15, xmm14
000078c0f8fcf13d  pextrw r14d, xmm0, 0x03
000078c0f8fcf143  and r14d, 0x7FF8
000078c0f8fcf14a  cmp r14d, 0x08
000078c0f8fcf14e  jnz 0x000078C0F8FCEC16
000078c0f8fcf154  movq r14, xmm14
000078c0f8fcf159  shl r14, 0x0D
000078c0f8fcf15d  jbe 0x000078C0F8FCEC16
000078c0f8fcf163  vorps xmm13, xmm14, [0x000078C0F8BFE040]
000078c0f8fcf16b  jmp 0x000078C0F8FCEC16
000078c0f8fcf170  ucomisd xmm1, xmm15
000078c0f8fcf175  jp 0x000078C0F8FCF184
000078c0f8fcf177  movaps xmm14, [0x000078C0F8BFE030]
000078c0f8fcf17f  jmp 0x000078C0F8FCEC4B
000078c0f8fcf184  vxorps xmm0, xmm1, xmm15
000078c0f8fcf189  pextrw r14d, xmm0, 0x03
000078c0f8fcf18f  and r14d, 0x7FF8
000078c0f8fcf196  cmp r14d, 0x08
000078c0f8fcf19a  jnz 0x000078C0F8FCEC4B
000078c0f8fcf1a0  movq r14, xmm15
000078c0f8fcf1a5  shl r14, 0x0D
000078c0f8fcf1a9  jbe 0x000078C0F8FCEC4B
000078c0f8fcf1af  vorps xmm14, xmm15, [0x000078C0F8BFE040]
000078c0f8fcf1b7  jmp 0x000078C0F8FCEC4B
000078c0f8fcf1bc  call 0x000078C0F8EE27E0
000078c0f8fcf1c1  jmp 0x000078C0F8FCEC5C
000078c0f8fcf1c6  ucomisd xmm15, xmm14
000078c0f8fcf1cb  jp 0x000078C0F8FCF1DA
000078c0f8fcf1cd  movaps xmm13, [0x000078C0F8BFE030]
000078c0f8fcf1d5  jmp 0x000078C0F8FCEC89
000078c0f8fcf1da  vxorps xmm0, xmm15, xmm14
000078c0f8fcf1df  pextrw r14d, xmm0, 0x03
000078c0f8fcf1e5  and r14d, 0x7FF8
000078c0f8fcf1ec  cmp r14d, 0x08
000078c0f8fcf1f0  jnz 0x000078C0F8FCEC89
000078c0f8fcf1f6  movq r14, xmm14
000078c0f8fcf1fb  shl r14, 0x0D
000078c0f8fcf1ff  jbe 0x000078C0F8FCEC89
000078c0f8fcf205  vorps xmm13, xmm14, [0x000078C0F8BFE040]
000078c0f8fcf20d  jmp 0x000078C0F8FCEC89
000078c0f8fcf212  ucomisd xmm1, xmm15
000078c0f8fcf217  jp 0x000078C0F8FCF226
000078c0f8fcf219  movaps xmm14, [0x000078C0F8BFE030]
000078c0f8fcf221  jmp 0x000078C0F8FCECBE
000078c0f8fcf226  vxorps xmm0, xmm1, xmm15
000078c0f8fcf22b  pextrw r14d, xmm0, 0x03
000078c0f8fcf231  and r14d, 0x7FF8
000078c0f8fcf238  cmp r14d, 0x08
000078c0f8fcf23c  jnz 0x000078C0F8FCECBE
000078c0f8fcf242  movq r14, xmm15
000078c0f8fcf247  shl r14, 0x0D
000078c0f8fcf24b  jbe 0x000078C0F8FCECBE
000078c0f8fcf251  vorps xmm14, xmm15, [0x000078C0F8BFE040]
000078c0f8fcf259  jmp 0x000078C0F8FCECBE
000078c0f8fcf25e  call 0x000078C0F8EE27E0
000078c0f8fcf263  jmp 0x000078C0F8FCECCF
000078c0f8fcf268  ucomisd xmm15, xmm14
000078c0f8fcf26d  jp 0x000078C0F8FCF27C
000078c0f8fcf26f  movaps xmm13, [0x000078C0F8BFE030]
000078c0f8fcf277  jmp 0x000078C0F8FCECFC
000078c0f8fcf27c  vxorps xmm0, xmm15, xmm14
000078c0f8fcf281  pextrw r14d, xmm0, 0x03
000078c0f8fcf287  and r14d, 0x7FF8
000078c0f8fcf28e  cmp r14d, 0x08
000078c0f8fcf292  jnz 0x000078C0F8FCECFC
000078c0f8fcf298  movq r14, xmm14
000078c0f8fcf29d  shl r14, 0x0D
000078c0f8fcf2a1  jbe 0x000078C0F8FCECFC
000078c0f8fcf2a7  vorps xmm13, xmm14, [0x000078C0F8BFE040]
000078c0f8fcf2af  jmp 0x000078C0F8FCECFC
000078c0f8fcf2b4  ucomisd xmm1, xmm15
000078c0f8fcf2b9  jp 0x000078C0F8FCF2C8
000078c0f8fcf2bb  movaps xmm14, [0x000078C0F8BFE030]
000078c0f8fcf2c3  jmp 0x000078C0F8FCED31
000078c0f8fcf2c8  vxorps xmm0, xmm1, xmm15
000078c0f8fcf2cd  pextrw r14d, xmm0, 0x03
000078c0f8fcf2d3  and r14d, 0x7FF8
000078c0f8fcf2da  cmp r14d, 0x08
000078c0f8fcf2de  jnz 0x000078C0F8FCED31
000078c0f8fcf2e4  movq r14, xmm15
000078c0f8fcf2e9  shl r14, 0x0D
000078c0f8fcf2ed  jbe 0x000078C0F8FCED31
000078c0f8fcf2f3  vorps xmm14, xmm15, [0x000078C0F8BFE040]
000078c0f8fcf2fb  jmp 0x000078C0F8FCED31
000078c0f8fcf300  call 0x000078C0F8ED59C0
000078c0f8fcf305  jmp 0x000078C0F8FCED42
000078c0f8fcf30a  ucomisd xmm15, xmm14
000078c0f8fcf30f  jp 0x000078C0F8FCF31E
000078c0f8fcf311  movaps xmm13, [0x000078C0F8BFE030]
000078c0f8fcf319  jmp 0x000078C0F8FCED77
000078c0f8fcf31e  vxorps xmm0, xmm15, xmm14
000078c0f8fcf323  pextrw eax, xmm0, 0x03
000078c0f8fcf328  and eax, 0x7FF8
000078c0f8fcf32d  cmp eax, 0x08
000078c0f8fcf330  jnz 0x000078C0F8FCED77
000078c0f8fcf336  movq rax, xmm14
000078c0f8fcf33b  shl rax, 0x0D
000078c0f8fcf33f  jbe 0x000078C0F8FCED77
000078c0f8fcf345  vorps xmm13, xmm14, [0x000078C0F8BFE040]
000078c0f8fcf34d  jmp 0x000078C0F8FCED77
000078c0f8fcf352  ucomisd xmm1, xmm15
000078c0f8fcf357  jp 0x000078C0F8FCF366
000078c0f8fcf359  movaps xmm14, [0x000078C0F8BFE030]
000078c0f8fcf361  jmp 0x000078C0F8FCEDAC
000078c0f8fcf366  vxorps xmm0, xmm1, xmm15
000078c0f8fcf36b  pextrw eax, xmm0, 0x03
000078c0f8fcf370  and eax, 0x7FF8
000078c0f8fcf375  cmp eax, 0x08
000078c0f8fcf378  jnz 0x000078C0F8FCEDAC
000078c0f8fcf37e  movq rax, xmm15
000078c0f8fcf383  shl rax, 0x0D
000078c0f8fcf387  jbe 0x000078C0F8FCEDAC
000078c0f8fcf38d  vorps xmm14, xmm15, [0x000078C0F8BFE040]
000078c0f8fcf395  jmp 0x000078C0F8FCEDAC
000078c0f8fcf39a  ucomisd xmm1, xmm15
000078c0f8fcf39f  jp 0x000078C0F8FCF3AE
000078c0f8fcf3a1  movaps xmm14, [0x000078C0F8BFE030]
000078c0f8fcf3a9  jmp 0x000078C0F8FCEDE1
000078c0f8fcf3ae  vxorps xmm0, xmm1, xmm15
000078c0f8fcf3b3  pextrw eax, xmm0, 0x03
000078c0f8fcf3b8  and eax, 0x7FF8
000078c0f8fcf3bd  cmp eax, 0x08
000078c0f8fcf3c0  jnz 0x000078C0F8FCEDE1
000078c0f8fcf3c6  movq rax, xmm15
000078c0f8fcf3cb  shl rax, 0x0D
000078c0f8fcf3cf  jbe 0x000078C0F8FCEDE1
000078c0f8fcf3d5  vorps xmm14, xmm15, [0x000078C0F8BFE040]
000078c0f8fcf3dd  jmp 0x000078C0F8FCEDE1
000078c0f8fcf3e2  call 0x000078C0F8ED5EB0
000078c0f8fcf3e7  jmp 0x000078C0F8FCEDFE
000078c0f8fcf3ec  int3
000078c0f8fcf3ed  nop [rax], eax
000078c0f8fcf3f0  mov rax, [r15+0x48]
000078c0f8fcf3f4  mov r14, [r15+0x70]
000078c0f8fcf3f8  lea r12, [rax+r14*1]
000078c0f8fcf3fc  mov [r15+0x78], r12
000078c0f8fcf400  mov rax, [r13+r12*1]
000078c0f8fcf405  movq xmm1, rax
000078c0f8fcf40a  lea rax, [r12+0x40]
000078c0f8fcf40f  mov r11, [r13+rax*1]
000078c0f8fcf414  movq xmm15, r11
000078c0f8fcf419  lea rax, [r12+0x80]
000078c0f8fcf421  mov r11, [r13+rax*1]
000078c0f8fcf426  movq xmm14, r11
000078c0f8fcf42b  movaps xmm13, [r15+0x120]
000078c0f8fcf433  movq rax, xmm13
000078c0f8fcf438  movq r11, xmm1
000078c0f8fcf43d  vmovq xmm1, rax
000078c0f8fcf442  vmovq xmm13, r11
000078c0f8fcf447  movaps xmm12, xmm1
000078c0f8fcf44b  mulsd xmm12, xmm13
000078c0f8fcf450  ucomisd xmm12, xmm12
000078c0f8fcf455  jp 0x000078C0F8FCF879
000078c0f8fcf45b  movq xmm12, xmm12
000078c0f8fcf460  movaps xmm1, [r15+0x130]
000078c0f8fcf468  movq rax, xmm1
000078c0f8fcf46d  movq r11, xmm15
000078c0f8fcf472  vmovq xmm1, rax
000078c0f8fcf477  vmovq xmm15, r11
000078c0f8fcf47c  movaps xmm13, xmm1
000078c0f8fcf480  mulsd xmm13, xmm15
000078c0f8fcf485  ucomisd xmm13, xmm13
000078c0f8fcf48a  jp 0x000078C0F8FCF8C1
000078c0f8fcf490  movq xmm13, xmm13
000078c0f8fcf495  movq rax, xmm12
000078c0f8fcf49a  movaps xmm1, [r15+0x110]
000078c0f8fcf4a2  movq r11, xmm1
000078c0f8fcf4a7  vmovq xmm1, rax
000078c0f8fcf4ac  vmovq xmm15, r11
000078c0f8fcf4b1  movaps xmm12, xmm1
000078c0f8fcf4b5  addsd xmm12, xmm15
000078c0f8fcf4ba  ucomisd xmm12, xmm12
000078c0f8fcf4bf  jp 0x000078C0F8FCF909
000078c0f8fcf4c5  movq xmm12, xmm12
000078c0f8fcf4ca  movq rax, xmm12
000078c0f8fcf4cf  movq r11, xmm13
000078c0f8fcf4d4  vmovq xmm1, rax
000078c0f8fcf4d9  vmovq xmm15, r11
000078c0f8fcf4de  movaps xmm13, xmm1
000078c0f8fcf4e2  addsd xmm13, xmm15
000078c0f8fcf4e7  ucomisd xmm13, xmm13
000078c0f8fcf4ec  jp 0x000078C0F8FCF951
000078c0f8fcf4f2  movq xmm13, xmm13
000078c0f8fcf4f7  movaps xmm1, [r15+0x140]
000078c0f8fcf4ff  movq rax, xmm1
000078c0f8fcf504  movq r11, xmm14
000078c0f8fcf509  vmovq xmm1, rax
000078c0f8fcf50e  vmovq xmm15, r11
000078c0f8fcf513  movaps xmm14, xmm1
000078c0f8fcf517  mulsd xmm14, xmm15
000078c0f8fcf51c  ucomisd xmm14, xmm14
000078c0f8fcf521  jp 0x000078C0F8FCF999
000078c0f8fcf527  movq xmm14, xmm14
000078c0f8fcf52c  lea rax, [r12+0xC0]
000078c0f8fcf534  mov r11, [r13+rax*1]
000078c0f8fcf539  movq xmm1, r11
000078c0f8fcf53e  movq rax, xmm13
000078c0f8fcf543  movq r11, xmm14
000078c0f8fcf548  vmovq xmm15, rax
000078c0f8fcf54d  vmovq xmm14, r11
000078c0f8fcf552  movaps xmm13, xmm15
000078c0f8fcf556  addsd xmm13, xmm14
000078c0f8fcf55b  ucomisd xmm13, xmm13
000078c0f8fcf560  jp 0x000078C0F8FCF9EB
000078c0f8fcf566  movq xmm13, xmm13
000078c0f8fcf56b  movaps xmm15, [r15+0x150]
000078c0f8fcf573  movq rax, xmm15
000078c0f8fcf578  movq r11, xmm1
000078c0f8fcf57d  vmovq xmm1, rax
000078c0f8fcf582  vmovq xmm15, r11
000078c0f8fcf587  movaps xmm14, xmm1
000078c0f8fcf58b  mulsd xmm14, xmm15
000078c0f8fcf590  ucomisd xmm14, xmm14
000078c0f8fcf595  jp 0x000078C0F8FCFA33
000078c0f8fcf59b  movq xmm14, xmm14
000078c0f8fcf5a0  lea rax, [r12+0x100]
000078c0f8fcf5a8  mov r11, [r13+rax*1]
000078c0f8fcf5ad  movq xmm1, r11
000078c0f8fcf5b2  movq rax, xmm13
000078c0f8fcf5b7  movq r11, xmm14
000078c0f8fcf5bc  vmovq xmm15, rax
000078c0f8fcf5c1  vmovq xmm14, r11
000078c0f8fcf5c6  movaps xmm13, xmm15
000078c0f8fcf5ca  addsd xmm13, xmm14
000078c0f8fcf5cf  ucomisd xmm13, xmm13
000078c0f8fcf5d4  jp 0x000078C0F8FCFA85
000078c0f8fcf5da  movq xmm13, xmm13
000078c0f8fcf5df  movaps xmm15, [r15+0x160]
000078c0f8fcf5e7  movq rax, xmm15
000078c0f8fcf5ec  movq r11, xmm1
000078c0f8fcf5f1  vmovq xmm1, rax
000078c0f8fcf5f6  vmovq xmm15, r11
000078c0f8fcf5fb  movaps xmm14, xmm1
000078c0f8fcf5ff  mulsd xmm14, xmm15
000078c0f8fcf604  ucomisd xmm14, xmm14
000078c0f8fcf609  jp 0x000078C0F8FCFACD
000078c0f8fcf60f  movq xmm14, xmm14
000078c0f8fcf614  lea rax, [r12+0x140]
000078c0f8fcf61c  mov r11, [r13+rax*1]
000078c0f8fcf621  movq xmm1, r11
000078c0f8fcf626  movq rax, xmm13
000078c0f8fcf62b  movq r11, xmm14
000078c0f8fcf630  vmovq xmm15, rax
000078c0f8fcf635  vmovq xmm14, r11
000078c0f8fcf63a  movaps xmm13, xmm15
000078c0f8fcf63e  addsd xmm13, xmm14
000078c0f8fcf643  ucomisd xmm13, xmm13
000078c0f8fcf648  jp 0x000078C0F8FCFB1F
000078c0f8fcf64e  movq xmm13, xmm13
000078c0f8fcf653  movaps xmm15, [r15+0x170]
000078c0f8fcf65b  movq rax, xmm15
000078c0f8fcf660  movq r11, xmm1
000078c0f8fcf665  vmovq xmm1, rax
000078c0f8fcf66a  vmovq xmm15, r11
000078c0f8fcf66f  movaps xmm14, xmm1
000078c0f8fcf673  mulsd xmm14, xmm15
000078c0f8fcf678  ucomisd xmm14, xmm14
000078c0f8fcf67d  jp 0x000078C0F8FCFB67
000078c0f8fcf683  movq xmm14, xmm14
000078c0f8fcf688  lea rax, [r12+0x180]
000078c0f8fcf690  mov r11, [r13+rax*1]
000078c0f8fcf695  movq xmm1, r11
000078c0f8fcf69a  movq rax, xmm13
000078c0f8fcf69f  movq r11, xmm14
000078c0f8fcf6a4  vmovq xmm15, rax
000078c0f8fcf6a9  vmovq xmm14, r11
000078c0f8fcf6ae  movaps xmm13, xmm15
000078c0f8fcf6b2  addsd xmm13, xmm14
000078c0f8fcf6b7  ucomisd xmm13, xmm13
000078c0f8fcf6bc  jp 0x000078C0F8FCFBB9
000078c0f8fcf6c2  movq xmm13, xmm13
000078c0f8fcf6c7  movaps xmm15, [r15+0x180]
000078c0f8fcf6cf  movq rax, xmm15
000078c0f8fcf6d4  movq r11, xmm1
000078c0f8fcf6d9  vmovq xmm1, rax
000078c0f8fcf6de  vmovq xmm15, r11
000078c0f8fcf6e3  movaps xmm14, xmm1
000078c0f8fcf6e7  mulsd xmm14, xmm15
000078c0f8fcf6ec  ucomisd xmm14, xmm14
000078c0f8fcf6f1  jp 0x000078C0F8FCFC01
000078c0f8fcf6f7  movq xmm14, xmm14
000078c0f8fcf6fc  lea rax, [r12+0x1C0]
000078c0f8fcf704  mov r12, [r13+rax*1]
000078c0f8fcf709  movq xmm1, r12
000078c0f8fcf70e  movaps [r15+0x240], xmm1
000078c0f8fcf716  movq rax, xmm13
000078c0f8fcf71b  movq r12, xmm14
000078c0f8fcf720  vmovq xmm15, rax
000078c0f8fcf725  vmovq xmm14, r12
000078c0f8fcf72a  movaps xmm13, xmm15
000078c0f8fcf72e  addsd xmm13, xmm14
000078c0f8fcf733  ucomisd xmm13, xmm13
000078c0f8fcf738  jp 0x000078C0F8FCFC53
000078c0f8fcf73e  movq xmm13, xmm13
000078c0f8fcf743  movaps xmm15, [r15+0x210]
000078c0f8fcf74b  movq rax, xmm15
000078c0f8fcf750  movq r12, xmm1
000078c0f8fcf755  vmovq xmm1, rax
000078c0f8fcf75a  vmovq xmm15, r12
000078c0f8fcf75f  movaps xmm14, xmm1
000078c0f8fcf763  mulsd xmm14, xmm15
000078c0f8fcf768  ucomisd xmm14, xmm14
000078c0f8fcf76d  jp 0x000078C0F8FCFC9B
000078c0f8fcf773  movq xmm14, xmm14
000078c0f8fcf778  movaps [r15+0x230], xmm14
000078c0f8fcf780  movq rax, xmm13
000078c0f8fcf785  movq r12, xmm14
000078c0f8fcf78a  vmovq xmm1, rax
000078c0f8fcf78f  vmovq xmm15, r12
000078c0f8fcf794  movaps xmm14, xmm1
000078c0f8fcf798  addsd xmm14, xmm15
000078c0f8fcf79d  ucomisd xmm14, xmm14
000078c0f8fcf7a2  jp 0x000078C0F8FCFCE3
000078c0f8fcf7a8  movq xmm14, xmm14
000078c0f8fcf7ad  movaps [r15+0x220], xmm14
000078c0f8fcf7b5  mov rax, [r15+0x68]
000078c0f8fcf7b9  lea r12, [rax+r14*1]
000078c0f8fcf7bd  movq rax, xmm14
000078c0f8fcf7c2  mov [r13+r12*1], rax
000078c0f8fcf7c7  lea rax, [r14+0x08]
000078c0f8fcf7cb  mov [r15+0x70], rax
000078c0f8fcf7cf  mov [rsp+0x10], rax
000078c0f8fcf7d4  xor eax, eax
000078c0f8fcf7d6  mov r14, [rsp+0x10]
000078c0f8fcf7db  mov r12d, 0x40
000078c0f8fcf7e1  cmp r14, r12
000078c0f8fcf7e4  cmc
000078c0f8fcf7e5  lahf
000078c0f8fcf7e6  seto al
000078c0f8fcf7e9  mov [r15+0x108], eax
000078c0f8fcf7f0  mov eax, [r15+0x108]
000078c0f8fcf7f7  sahf
000078c0f8fcf7f8  jnz 0x000078C0F8FCF82A
000078c0f8fcf7fa  cmp dword ptr [r15+0x318], 0x00
000078c0f8fcf802  jz 0x000078C0F8FCFD40
000078c0f8fcf808  nop [rax+rax*1], ax
000078c0f8fcf811  nop [rax+rax*1], eax
000078c0f8fcf819  mov eax, 0x410118
000078c0f8fcf81e  mov [r15+0x100], rax
000078c0f8fcf825  jmp 0x000078C0F8DFE110
000078c0f8fcf82a  cmp dword ptr [r15+0x318], 0x00
000078c0f8fcf832  jz 0x000078C0F8FCF3F0
000078c0f8fcf838  nop [rax+rax*1], ax
000078c0f8fcf841  nop [rax+rax*1], eax
000078c0f8fcf849  mov eax, 0x4100A4
000078c0f8fcf84e  mov [r15+0x100], rax
000078c0f8fcf855  jmp 0x000078C0F8DFE110
000078c0f8fcf85a  int3
000078c0f8fcf85b  call 0x000078C0F8EB47C0
000078c0f8fcf860  jmp 0x000078C0F8FCF405
000078c0f8fcf865  call 0x000078C0F8E0A4B0
000078c0f8fcf86a  jmp 0x000078C0F8FCF414
000078c0f8fcf86f  call 0x000078C0F8E0A4B0
000078c0f8fcf874  jmp 0x000078C0F8FCF426
000078c0f8fcf879  ucomisd xmm1, xmm13
000078c0f8fcf87e  jp 0x000078C0F8FCF88D
000078c0f8fcf880  movaps xmm12, [0x000078C0F8BFE030]
000078c0f8fcf888  jmp 0x000078C0F8FCF45B
000078c0f8fcf88d  vxorps xmm0, xmm1, xmm13
000078c0f8fcf892  pextrw eax, xmm0, 0x03
000078c0f8fcf897  and eax, 0x7FF8
000078c0f8fcf89c  cmp eax, 0x08
000078c0f8fcf89f  jnz 0x000078C0F8FCF45B
000078c0f8fcf8a5  movq rax, xmm13
000078c0f8fcf8aa  shl rax, 0x0D
000078c0f8fcf8ae  jbe 0x000078C0F8FCF45B
000078c0f8fcf8b4  vorps xmm12, xmm13, [0x000078C0F8BFE040]
000078c0f8fcf8bc  jmp 0x000078C0F8FCF45B
000078c0f8fcf8c1  ucomisd xmm1, xmm15
000078c0f8fcf8c6  jp 0x000078C0F8FCF8D5
000078c0f8fcf8c8  movaps xmm13, [0x000078C0F8BFE030]
000078c0f8fcf8d0  jmp 0x000078C0F8FCF490
000078c0f8fcf8d5  vxorps xmm0, xmm1, xmm15
000078c0f8fcf8da  pextrw eax, xmm0, 0x03
000078c0f8fcf8df  and eax, 0x7FF8
000078c0f8fcf8e4  cmp eax, 0x08
000078c0f8fcf8e7  jnz 0x000078C0F8FCF490
000078c0f8fcf8ed  movq rax, xmm15
000078c0f8fcf8f2  shl rax, 0x0D
000078c0f8fcf8f6  jbe 0x000078C0F8FCF490
000078c0f8fcf8fc  vorps xmm13, xmm15, [0x000078C0F8BFE040]
000078c0f8fcf904  jmp 0x000078C0F8FCF490
000078c0f8fcf909  ucomisd xmm1, xmm15
000078c0f8fcf90e  jp 0x000078C0F8FCF91D
000078c0f8fcf910  movaps xmm12, [0x000078C0F8BFE030]
000078c0f8fcf918  jmp 0x000078C0F8FCF4C5
000078c0f8fcf91d  vxorps xmm0, xmm1, xmm15
000078c0f8fcf922  pextrw eax, xmm0, 0x03
000078c0f8fcf927  and eax, 0x7FF8
000078c0f8fcf92c  cmp eax, 0x08
000078c0f8fcf92f  jnz 0x000078C0F8FCF4C5
000078c0f8fcf935  movq rax, xmm15
000078c0f8fcf93a  shl rax, 0x0D
000078c0f8fcf93e  jbe 0x000078C0F8FCF4C5
000078c0f8fcf944  vorps xmm12, xmm15, [0x000078C0F8BFE040]
000078c0f8fcf94c  jmp 0x000078C0F8FCF4C5
000078c0f8fcf951  ucomisd xmm1, xmm15
000078c0f8fcf956  jp 0x000078C0F8FCF965
000078c0f8fcf958  movaps xmm13, [0x000078C0F8BFE030]
000078c0f8fcf960  jmp 0x000078C0F8FCF4F2
000078c0f8fcf965  vxorps xmm0, xmm1, xmm15
000078c0f8fcf96a  pextrw eax, xmm0, 0x03
000078c0f8fcf96f  and eax, 0x7FF8
000078c0f8fcf974  cmp eax, 0x08
000078c0f8fcf977  jnz 0x000078C0F8FCF4F2
000078c0f8fcf97d  movq rax, xmm15
000078c0f8fcf982  shl rax, 0x0D
000078c0f8fcf986  jbe 0x000078C0F8FCF4F2
000078c0f8fcf98c  vorps xmm13, xmm15, [0x000078C0F8BFE040]
000078c0f8fcf994  jmp 0x000078C0F8FCF4F2
000078c0f8fcf999  ucomisd xmm1, xmm15
000078c0f8fcf99e  jp 0x000078C0F8FCF9AD
000078c0f8fcf9a0  movaps xmm14, [0x000078C0F8BFE030]
000078c0f8fcf9a8  jmp 0x000078C0F8FCF527
000078c0f8fcf9ad  vxorps xmm0, xmm1, xmm15
000078c0f8fcf9b2  pextrw eax, xmm0, 0x03
000078c0f8fcf9b7  and eax, 0x7FF8
000078c0f8fcf9bc  cmp eax, 0x08
000078c0f8fcf9bf  jnz 0x000078C0F8FCF527
000078c0f8fcf9c5  movq rax, xmm15
000078c0f8fcf9ca  shl rax, 0x0D
000078c0f8fcf9ce  jbe 0x000078C0F8FCF527
000078c0f8fcf9d4  vorps xmm14, xmm15, [0x000078C0F8BFE040]
000078c0f8fcf9dc  jmp 0x000078C0F8FCF527
000078c0f8fcf9e1  call 0x000078C0F8E0A4B0
000078c0f8fcf9e6  jmp 0x000078C0F8FCF539
000078c0f8fcf9eb  ucomisd xmm15, xmm14
000078c0f8fcf9f0  jp 0x000078C0F8FCF9FF
000078c0f8fcf9f2  movaps xmm13, [0x000078C0F8BFE030]
000078c0f8fcf9fa  jmp 0x000078C0F8FCF566
000078c0f8fcf9ff  vxorps xmm0, xmm15, xmm14
000078c0f8fcfa04  pextrw eax, xmm0, 0x03
000078c0f8fcfa09  and eax, 0x7FF8
000078c0f8fcfa0e  cmp eax, 0x08
000078c0f8fcfa11  jnz 0x000078C0F8FCF566
000078c0f8fcfa17  movq rax, xmm14
000078c0f8fcfa1c  shl rax, 0x0D
000078c0f8fcfa20  jbe 0x000078C0F8FCF566
000078c0f8fcfa26  vorps xmm13, xmm14, [0x000078C0F8BFE040]
000078c0f8fcfa2e  jmp 0x000078C0F8FCF566
000078c0f8fcfa33  ucomisd xmm1, xmm15
000078c0f8fcfa38  jp 0x000078C0F8FCFA47
000078c0f8fcfa3a  movaps xmm14, [0x000078C0F8BFE030]
000078c0f8fcfa42  jmp 0x000078C0F8FCF59B
000078c0f8fcfa47  vxorps xmm0, xmm1, xmm15
000078c0f8fcfa4c  pextrw eax, xmm0, 0x03
000078c0f8fcfa51  and eax, 0x7FF8
000078c0f8fcfa56  cmp eax, 0x08
000078c0f8fcfa59  jnz 0x000078C0F8FCF59B
000078c0f8fcfa5f  movq rax, xmm15
000078c0f8fcfa64  shl rax, 0x0D
000078c0f8fcfa68  jbe 0x000078C0F8FCF59B
000078c0f8fcfa6e  vorps xmm14, xmm15, [0x000078C0F8BFE040]
000078c0f8fcfa76  jmp 0x000078C0F8FCF59B
000078c0f8fcfa7b  call 0x000078C0F8E0A4B0
000078c0f8fcfa80  jmp 0x000078C0F8FCF5AD
000078c0f8fcfa85  ucomisd xmm15, xmm14
000078c0f8fcfa8a  jp 0x000078C0F8FCFA99
000078c0f8fcfa8c  movaps xmm13, [0x000078C0F8BFE030]
000078c0f8fcfa94  jmp 0x000078C0F8FCF5DA
000078c0f8fcfa99  vxorps xmm0, xmm15, xmm14
000078c0f8fcfa9e  pextrw eax, xmm0, 0x03
000078c0f8fcfaa3  and eax, 0x7FF8
000078c0f8fcfaa8  cmp eax, 0x08
000078c0f8fcfaab  jnz 0x000078C0F8FCF5DA
000078c0f8fcfab1  movq rax, xmm14
000078c0f8fcfab6  shl rax, 0x0D
000078c0f8fcfaba  jbe 0x000078C0F8FCF5DA
000078c0f8fcfac0  vorps xmm13, xmm14, [0x000078C0F8BFE040]
000078c0f8fcfac8  jmp 0x000078C0F8FCF5DA
000078c0f8fcfacd  ucomisd xmm1, xmm15
000078c0f8fcfad2  jp 0x000078C0F8FCFAE1
000078c0f8fcfad4  movaps xmm14, [0x000078C0F8BFE030]
000078c0f8fcfadc  jmp 0x000078C0F8FCF60F
000078c0f8fcfae1  vxorps xmm0, xmm1, xmm15
000078c0f8fcfae6  pextrw eax, xmm0, 0x03
000078c0f8fcfaeb  and eax, 0x7FF8
000078c0f8fcfaf0  cmp eax, 0x08
000078c0f8fcfaf3  jnz 0x000078C0F8FCF60F
000078c0f8fcfaf9  movq rax, xmm15
000078c0f8fcfafe  shl rax, 0x0D
000078c0f8fcfb02  jbe 0x000078C0F8FCF60F
000078c0f8fcfb08  vorps xmm14, xmm15, [0x000078C0F8BFE040]
000078c0f8fcfb10  jmp 0x000078C0F8FCF60F
000078c0f8fcfb15  call 0x000078C0F8E0A4B0
000078c0f8fcfb1a  jmp 0x000078C0F8FCF621
000078c0f8fcfb1f  ucomisd xmm15, xmm14
000078c0f8fcfb24  jp 0x000078C0F8FCFB33
000078c0f8fcfb26  movaps xmm13, [0x000078C0F8BFE030]
000078c0f8fcfb2e  jmp 0x000078C0F8FCF64E
000078c0f8fcfb33  vxorps xmm0, xmm15, xmm14
000078c0f8fcfb38  pextrw eax, xmm0, 0x03
000078c0f8fcfb3d  and eax, 0x7FF8
000078c0f8fcfb42  cmp eax, 0x08
000078c0f8fcfb45  jnz 0x000078C0F8FCF64E
000078c0f8fcfb4b  movq rax, xmm14
000078c0f8fcfb50  shl rax, 0x0D
000078c0f8fcfb54  jbe 0x000078C0F8FCF64E
000078c0f8fcfb5a  vorps xmm13, xmm14, [0x000078C0F8BFE040]
000078c0f8fcfb62  jmp 0x000078C0F8FCF64E
000078c0f8fcfb67  ucomisd xmm1, xmm15
000078c0f8fcfb6c  jp 0x000078C0F8FCFB7B
000078c0f8fcfb6e  movaps xmm14, [0x000078C0F8BFE030]
000078c0f8fcfb76  jmp 0x000078C0F8FCF683
000078c0f8fcfb7b  vxorps xmm0, xmm1, xmm15
000078c0f8fcfb80  pextrw eax, xmm0, 0x03
000078c0f8fcfb85  and eax, 0x7FF8
000078c0f8fcfb8a  cmp eax, 0x08
000078c0f8fcfb8d  jnz 0x000078C0F8FCF683
000078c0f8fcfb93  movq rax, xmm15
000078c0f8fcfb98  shl rax, 0x0D
000078c0f8fcfb9c  jbe 0x000078C0F8FCF683
000078c0f8fcfba2  vorps xmm14, xmm15, [0x000078C0F8BFE040]
000078c0f8fcfbaa  jmp 0x000078C0F8FCF683
000078c0f8fcfbaf  call 0x000078C0F8E0A4B0
000078c0f8fcfbb4  jmp 0x000078C0F8FCF695
000078c0f8fcfbb9  ucomisd xmm15, xmm14
000078c0f8fcfbbe  jp 0x000078C0F8FCFBCD
000078c0f8fcfbc0  movaps xmm13, [0x000078C0F8BFE030]
000078c0f8fcfbc8  jmp 0x000078C0F8FCF6C2
000078c0f8fcfbcd  vxorps xmm0, xmm15, xmm14
000078c0f8fcfbd2  pextrw eax, xmm0, 0x03
000078c0f8fcfbd7  and eax, 0x7FF8
000078c0f8fcfbdc  cmp eax, 0x08
000078c0f8fcfbdf  jnz 0x000078C0F8FCF6C2
000078c0f8fcfbe5  movq rax, xmm14
000078c0f8fcfbea  shl rax, 0x0D
000078c0f8fcfbee  jbe 0x000078C0F8FCF6C2
000078c0f8fcfbf4  vorps xmm13, xmm14, [0x000078C0F8BFE040]
000078c0f8fcfbfc  jmp 0x000078C0F8FCF6C2
000078c0f8fcfc01  ucomisd xmm1, xmm15
000078c0f8fcfc06  jp 0x000078C0F8FCFC15
000078c0f8fcfc08  movaps xmm14, [0x000078C0F8BFE030]
000078c0f8fcfc10  jmp 0x000078C0F8FCF6F7
000078c0f8fcfc15  vxorps xmm0, xmm1, xmm15
000078c0f8fcfc1a  pextrw eax, xmm0, 0x03
000078c0f8fcfc1f  and eax, 0x7FF8
000078c0f8fcfc24  cmp eax, 0x08
000078c0f8fcfc27  jnz 0x000078C0F8FCF6F7
000078c0f8fcfc2d  movq rax, xmm15
000078c0f8fcfc32  shl rax, 0x0D
000078c0f8fcfc36  jbe 0x000078C0F8FCF6F7
000078c0f8fcfc3c  vorps xmm14, xmm15, [0x000078C0F8BFE040]
000078c0f8fcfc44  jmp 0x000078C0F8FCF6F7
000078c0f8fcfc49  call 0x000078C0F8E0B720
000078c0f8fcfc4e  jmp 0x000078C0F8FCF709
000078c0f8fcfc53  ucomisd xmm15, xmm14
000078c0f8fcfc58  jp 0x000078C0F8FCFC67
000078c0f8fcfc5a  movaps xmm13, [0x000078C0F8BFE030]
000078c0f8fcfc62  jmp 0x000078C0F8FCF73E
000078c0f8fcfc67  vxorps xmm0, xmm15, xmm14
000078c0f8fcfc6c  pextrw eax, xmm0, 0x03
000078c0f8fcfc71  and eax, 0x7FF8
000078c0f8fcfc76  cmp eax, 0x08
000078c0f8fcfc79  jnz 0x000078C0F8FCF73E
000078c0f8fcfc7f  movq rax, xmm14
000078c0f8fcfc84  shl rax, 0x0D
000078c0f8fcfc88  jbe 0x000078C0F8FCF73E
000078c0f8fcfc8e  vorps xmm13, xmm14, [0x000078C0F8BFE040]
000078c0f8fcfc96  jmp 0x000078C0F8FCF73E
000078c0f8fcfc9b  ucomisd xmm1, xmm15
000078c0f8fcfca0  jp 0x000078C0F8FCFCAF
000078c0f8fcfca2  movaps xmm14, [0x000078C0F8BFE030]
000078c0f8fcfcaa  jmp 0x000078C0F8FCF773
000078c0f8fcfcaf  vxorps xmm0, xmm1, xmm15
000078c0f8fcfcb4  pextrw eax, xmm0, 0x03
000078c0f8fcfcb9  and eax, 0x7FF8
000078c0f8fcfcbe  cmp eax, 0x08
000078c0f8fcfcc1  jnz 0x000078C0F8FCF773
000078c0f8fcfcc7  movq rax, xmm15
000078c0f8fcfccc  shl rax, 0x0D
000078c0f8fcfcd0  jbe 0x000078C0F8FCF773
000078c0f8fcfcd6  vorps xmm14, xmm15, [0x000078C0F8BFE040]
000078c0f8fcfcde  jmp 0x000078C0F8FCF773
000078c0f8fcfce3  ucomisd xmm1, xmm15
000078c0f8fcfce8  jp 0x000078C0F8FCFCF7
000078c0f8fcfcea  movaps xmm14, [0x000078C0F8BFE030]
000078c0f8fcfcf2  jmp 0x000078C0F8FCF7A8
000078c0f8fcfcf7  vxorps xmm0, xmm1, xmm15
000078c0f8fcfcfc  pextrw eax, xmm0, 0x03
000078c0f8fcfd01  and eax, 0x7FF8
000078c0f8fcfd06  cmp eax, 0x08
000078c0f8fcfd09  jnz 0x000078C0F8FCF7A8
000078c0f8fcfd0f  movq rax, xmm15
000078c0f8fcfd14  shl rax, 0x0D
000078c0f8fcfd18  jbe 0x000078C0F8FCF7A8
000078c0f8fcfd1e  vorps xmm14, xmm15, [0x000078C0F8BFE040]
000078c0f8fcfd26  jmp 0x000078C0F8FCF7A8
000078c0f8fcfd2b  call 0x000078C0F8EB4CB0
000078c0f8fcfd30  jmp 0x000078C0F8FCF7C7
000078c0f8fcfd35  int3
000078c0f8fcfd36  nop [rax+rax*1], ax
000078c0f8fcfd3f  nop
000078c0f8fcfd40  mov rax, [r15+0x60]
000078c0f8fcfd44  lea r14, [rax+0x01]
000078c0f8fcfd48  mov [r15+0x60], r14
000078c0f8fcfd4c  mov rax, [r15+0x68]
000078c0f8fcfd50  lea r12, [rax+0x40]
000078c0f8fcfd54  mov [r15+0x68], r12
000078c0f8fcfd58  xor eax, eax
000078c0f8fcfd5a  mov r12d, 0x08
000078c0f8fcfd60  cmp r14, r12
000078c0f8fcfd63  cmc
000078c0f8fcfd64  lahf
000078c0f8fcfd65  seto al
000078c0f8fcfd68  mov [r15+0x108], eax
000078c0f8fcfd6f  mov eax, [r15+0x108]
000078c0f8fcfd76  sahf
000078c0f8fcfd77  jnz 0x000078C0F8FCFDA9
000078c0f8fcfd79  cmp dword ptr [r15+0x318], 0x00
000078c0f8fcfd81  jz 0x000078C0F8FD08A0
000078c0f8fcfd87  nop [rax+rax*1], ax
000078c0f8fcfd90  nop [rax+rax*1], eax
000078c0f8fcfd98  mov eax, 0x410128
000078c0f8fcfd9d  mov [r15+0x100], rax
000078c0f8fcfda4  jmp 0x000078C0F8DFE110
000078c0f8fcfda9  cmp dword ptr [r15+0x318], 0x00
000078c0f8fcfdb1  jz 0x000078C0F8FCFDE0
000078c0f8fcfdb7  nop [rax+rax*1], ax
000078c0f8fcfdc0  nop [rax+rax*1], eax
000078c0f8fcfdc8  mov eax, 0x41008C
000078c0f8fcfdcd  mov [r15+0x100], rax
000078c0f8fcfdd4  jmp 0x000078C0F8DFE110
000078c0f8fcfdd9  int3
000078c0f8fcfdda  int3
000078c0f8fcfddb  nop [rax+rax*1], eax
000078c0f8fcfde0  mov rax, [r15+0x40]
000078c0f8fcfde4  mov r14, [r15+0x60]
000078c0f8fcfde8  shl r14, 0x06
000078c0f8fcfdec  lea r12, [rax+r14*1]
000078c0f8fcfdf0  mov rax, [r13+r12*1]
000078c0f8fcfdf5  lea r14, [r12+0x08]
000078c0f8fcfdfa  mov r11, [r13+r14*1]
000078c0f8fcfdff  movq xmm1, rax
000078c0f8fcfe04  movq xmm15, r11
000078c0f8fcfe09  movq xmm1, xmm1
000078c0f8fcfe0d  movq xmm1, xmm1
000078c0f8fcfe11  movaps [r15+0x120], xmm1
000078c0f8fcfe19  movq xmm15, xmm15
000078c0f8fcfe1e  movq xmm15, xmm15
000078c0f8fcfe23  movaps [r15+0x130], xmm15
000078c0f8fcfe2b  lea rax, [r12+0x10]
000078c0f8fcfe30  mov r14, [r13+rax*1]
000078c0f8fcfe35  lea rax, [r12+0x18]
000078c0f8fcfe3a  mov r11, [r13+rax*1]
000078c0f8fcfe3f  movq xmm1, r14
000078c0f8fcfe44  movq xmm15, r11
000078c0f8fcfe49  movq xmm1, xmm1
000078c0f8fcfe4d  movq xmm1, xmm1
000078c0f8fcfe51  movaps [r15+0x140], xmm1
000078c0f8fcfe59  movq xmm15, xmm15
000078c0f8fcfe5e  movq xmm15, xmm15
000078c0f8fcfe63  movaps [r15+0x150], xmm15
000078c0f8fcfe6b  lea rax, [r12+0x20]
000078c0f8fcfe70  mov r14, [r13+rax*1]
000078c0f8fcfe75  lea rax, [r12+0x28]
000078c0f8fcfe7a  mov r11, [r13+rax*1]
000078c0f8fcfe7f  movq xmm1, r14
000078c0f8fcfe84  movq xmm15, r11
000078c0f8fcfe89  movq xmm1, xmm1
000078c0f8fcfe8d  movq xmm1, xmm1
000078c0f8fcfe91  movaps [r15+0x160], xmm1
000078c0f8fcfe99  movq xmm15, xmm15
000078c0f8fcfe9e  movq xmm15, xmm15
000078c0f8fcfea3  movaps [r15+0x170], xmm15
000078c0f8fcfeab  lea rax, [r12+0x30]
000078c0f8fcfeb0  mov r14, [r13+rax*1]
000078c0f8fcfeb5  lea rax, [r12+0x38]
000078c0f8fcfeba  mov r12, [r13+rax*1]
000078c0f8fcfebf  movq xmm1, r14
000078c0f8fcfec4  movq xmm15, r12
000078c0f8fcfec9  movq xmm1, xmm1
000078c0f8fcfecd  movq xmm1, xmm1
000078c0f8fcfed1  movaps [r15+0x180], xmm1
000078c0f8fcfed9  movq xmm15, xmm15
000078c0f8fcfede  movq xmm15, xmm15
000078c0f8fcfee3  movaps [r15+0x210], xmm15
000078c0f8fcfeeb  mov rax, [r15+0x48]
000078c0f8fcfeef  mov [r15+0x78], rax
000078c0f8fcfef3  mov r14, [r13+rax*1]
000078c0f8fcfef8  movq xmm1, r14
000078c0f8fcfefd  lea r14, [rax+0x40]
000078c0f8fcff01  mov r12, [r13+r14*1]
000078c0f8fcff06  movq xmm15, r12
000078c0f8fcff0b  lea r14, [rax+0x80]
000078c0f8fcff12  mov r12, [r13+r14*1]
000078c0f8fcff17  movq xmm14, r12
000078c0f8fcff1c  movaps xmm13, [r15+0x120]
000078c0f8fcff24  movq r14, xmm13
000078c0f8fcff29  movq r12, xmm1
000078c0f8fcff2e  vmovq xmm1, r14
000078c0f8fcff33  vmovq xmm13, r12
000078c0f8fcff38  movaps xmm12, xmm1
000078c0f8fcff3c  mulsd xmm12, xmm13
000078c0f8fcff41  ucomisd xmm12, xmm12
000078c0f8fcff46  jp 0x000078C0F8FD03AD
000078c0f8fcff4c  movq xmm12, xmm12
000078c0f8fcff51  movaps xmm1, [r15+0x130]
000078c0f8fcff59  movq r14, xmm1
000078c0f8fcff5e  movq r12, xmm15
000078c0f8fcff63  vmovq xmm1, r14
000078c0f8fcff68  vmovq xmm15, r12
000078c0f8fcff6d  movaps xmm13, xmm1
000078c0f8fcff71  mulsd xmm13, xmm15
000078c0f8fcff76  ucomisd xmm13, xmm13
000078c0f8fcff7b  jp 0x000078C0F8FD03F9
000078c0f8fcff81  movq xmm13, xmm13
000078c0f8fcff86  movq r14, xmm12
000078c0f8fcff8b  movaps xmm1, [r15+0x110]
000078c0f8fcff93  movq r12, xmm1
000078c0f8fcff98  vmovq xmm1, r14
000078c0f8fcff9d  vmovq xmm15, r12
000078c0f8fcffa2  movaps xmm12, xmm1
000078c0f8fcffa6  addsd xmm12, xmm15
000078c0f8fcffab  ucomisd xmm12, xmm12
000078c0f8fcffb0  jp 0x000078C0F8FD0445
000078c0f8fcffb6  movq xmm12, xmm12
000078c0f8fcffbb  movq r14, xmm12
000078c0f8fcffc0  movq r12, xmm13
000078c0f8fcffc5  vmovq xmm1, r14
000078c0f8fcffca  vmovq xmm15, r12
000078c0f8fcffcf  movaps xmm13, xmm1
000078c0f8fcffd3  addsd xmm13, xmm15
000078c0f8fcffd8  ucomisd xmm13, xmm13
000078c0f8fcffdd  jp 0x000078C0F8FD0491
000078c0f8fcffe3  movq xmm13, xmm13
000078c0f8fcffe8  movaps xmm1, [r15+0x140]
000078c0f8fcfff0  movq r14, xmm1
000078c0f8fcfff5  movq r12, xmm14
000078c0f8fcfffa  vmovq xmm1, r14
000078c0f8fcffff  vmovq xmm15, r12
000078c0f8fd0004  movaps xmm14, xmm1
000078c0f8fd0008  mulsd xmm14, xmm15
000078c0f8fd000d  ucomisd xmm14, xmm14
000078c0f8fd0012  jp 0x000078C0F8FD04DD
000078c0f8fd0018  movq xmm14, xmm14
000078c0f8fd001d  lea r14, [rax+0xC0]
000078c0f8fd0024  mov r12, [r13+r14*1]
000078c0f8fd0029  movq xmm1, r12
000078c0f8fd002e  movq r14, xmm13
000078c0f8fd0033  movq r12, xmm14
000078c0f8fd0038  vmovq xmm15, r14
000078c0f8fd003d  vmovq xmm14, r12
000078c0f8fd0042  movaps xmm13, xmm15
000078c0f8fd0046  addsd xmm13, xmm14
000078c0f8fd004b  ucomisd xmm13, xmm13
000078c0f8fd0050  jp 0x000078C0F8FD0533
000078c0f8fd0056  movq xmm13, xmm13
000078c0f8fd005b  movaps xmm15, [r15+0x150]
000078c0f8fd0063  movq r14, xmm15
000078c0f8fd0068  movq r12, xmm1
000078c0f8fd006d  vmovq xmm1, r14
000078c0f8fd0072  vmovq xmm15, r12
000078c0f8fd0077  movaps xmm14, xmm1
000078c0f8fd007b  mulsd xmm14, xmm15
000078c0f8fd0080  ucomisd xmm14, xmm14
000078c0f8fd0085  jp 0x000078C0F8FD057F
000078c0f8fd008b  movq xmm14, xmm14
000078c0f8fd0090  lea r14, [rax+0x100]
000078c0f8fd0097  mov r12, [r13+r14*1]
000078c0f8fd009c  movq xmm1, r12
000078c0f8fd00a1  movq r14, xmm13
000078c0f8fd00a6  movq r12, xmm14
000078c0f8fd00ab  vmovq xmm15, r14
000078c0f8fd00b0  vmovq xmm14, r12
000078c0f8fd00b5  movaps xmm13, xmm15
000078c0f8fd00b9  addsd xmm13, xmm14
000078c0f8fd00be  ucomisd xmm13, xmm13
000078c0f8fd00c3  jp 0x000078C0F8FD05D5
000078c0f8fd00c9  movq xmm13, xmm13
000078c0f8fd00ce  movaps xmm15, [r15+0x160]
000078c0f8fd00d6  movq r14, xmm15
000078c0f8fd00db  movq r12, xmm1
000078c0f8fd00e0  vmovq xmm1, r14
000078c0f8fd00e5  vmovq xmm15, r12
000078c0f8fd00ea  movaps xmm14, xmm1
000078c0f8fd00ee  mulsd xmm14, xmm15
000078c0f8fd00f3  ucomisd xmm14, xmm14
000078c0f8fd00f8  jp 0x000078C0F8FD0621
000078c0f8fd00fe  movq xmm14, xmm14
000078c0f8fd0103  lea r14, [rax+0x140]
000078c0f8fd010a  mov r12, [r13+r14*1]
000078c0f8fd010f  movq xmm1, r12
000078c0f8fd0114  movq r14, xmm13
000078c0f8fd0119  movq r12, xmm14
000078c0f8fd011e  vmovq xmm15, r14
000078c0f8fd0123  vmovq xmm14, r12
000078c0f8fd0128  movaps xmm13, xmm15
000078c0f8fd012c  addsd xmm13, xmm14
000078c0f8fd0131  ucomisd xmm13, xmm13
000078c0f8fd0136  jp 0x000078C0F8FD0677
000078c0f8fd013c  movq xmm13, xmm13
000078c0f8fd0141  movaps xmm15, [r15+0x170]
000078c0f8fd0149  movq r14, xmm15
000078c0f8fd014e  movq r12, xmm1
000078c0f8fd0153  vmovq xmm1, r14
000078c0f8fd0158  vmovq xmm15, r12
000078c0f8fd015d  movaps xmm14, xmm1
000078c0f8fd0161  mulsd xmm14, xmm15
000078c0f8fd0166  ucomisd xmm14, xmm14
000078c0f8fd016b  jp 0x000078C0F8FD06C3
000078c0f8fd0171  movq xmm14, xmm14
000078c0f8fd0176  lea r14, [rax+0x180]
000078c0f8fd017d  mov r12, [r13+r14*1]
000078c0f8fd0182  movq xmm1, r12
000078c0f8fd0187  movq r14, xmm13
000078c0f8fd018c  movq r12, xmm14
000078c0f8fd0191  vmovq xmm15, r14
000078c0f8fd0196  vmovq xmm14, r12
000078c0f8fd019b  movaps xmm13, xmm15
000078c0f8fd019f  addsd xmm13, xmm14
000078c0f8fd01a4  ucomisd xmm13, xmm13
000078c0f8fd01a9  jp 0x000078C0F8FD0719
000078c0f8fd01af  movq xmm13, xmm13
000078c0f8fd01b4  movaps xmm15, [r15+0x180]
000078c0f8fd01bc  movq r14, xmm15
000078c0f8fd01c1  movq r12, xmm1
000078c0f8fd01c6  vmovq xmm1, r14
000078c0f8fd01cb  vmovq xmm15, r12
000078c0f8fd01d0  movaps xmm14, xmm1
000078c0f8fd01d4  mulsd xmm14, xmm15
000078c0f8fd01d9  ucomisd xmm14, xmm14
000078c0f8fd01de  jp 0x000078C0F8FD0765
000078c0f8fd01e4  movq xmm14, xmm14
000078c0f8fd01e9  lea r14, [rax+0x1C0]
000078c0f8fd01f0  mov rax, [r13+r14*1]
000078c0f8fd01f5  movq xmm1, rax
000078c0f8fd01fa  movaps [r15+0x240], xmm1
000078c0f8fd0202  movq rax, xmm13
000078c0f8fd0207  movq r14, xmm14
000078c0f8fd020c  vmovq xmm15, rax
000078c0f8fd0211  vmovq xmm14, r14
000078c0f8fd0216  movaps xmm13, xmm15
000078c0f8fd021a  addsd xmm13, xmm14
000078c0f8fd021f  ucomisd xmm13, xmm13
000078c0f8fd0224  jp 0x000078C0F8FD07BB
000078c0f8fd022a  movq xmm13, xmm13
000078c0f8fd022f  movaps xmm15, [r15+0x210]
000078c0f8fd0237  movq rax, xmm15
000078c0f8fd023c  movq r14, xmm1
000078c0f8fd0241  vmovq xmm1, rax
000078c0f8fd0246  vmovq xmm15, r14
000078c0f8fd024b  movaps xmm14, xmm1
000078c0f8fd024f  mulsd xmm14, xmm15
000078c0f8fd0254  ucomisd xmm14, xmm14
000078c0f8fd0259  jp 0x000078C0F8FD0803
000078c0f8fd025f  movq xmm14, xmm14
000078c0f8fd0264  movaps [r15+0x230], xmm14
000078c0f8fd026c  movq rax, xmm13
000078c0f8fd0271  movq r14, xmm14
000078c0f8fd0276  vmovq xmm1, rax
000078c0f8fd027b  vmovq xmm15, r14
000078c0f8fd0280  movaps xmm14, xmm1
000078c0f8fd0284  addsd xmm14, xmm15
000078c0f8fd0289  ucomisd xmm14, xmm14
000078c0f8fd028e  jp 0x000078C0F8FD084B
000078c0f8fd0294  movq xmm14, xmm14
000078c0f8fd0299  movaps [r15+0x220], xmm14
000078c0f8fd02a1  mov rax, [r15+0x68]
000078c0f8fd02a5  movq r14, xmm14
000078c0f8fd02aa  mov [r13+rax*1], r14
000078c0f8fd02af  mov qword ptr [r15+0x70], 0x08
000078c0f8fd02b7  xor eax, eax
000078c0f8fd02b9  mov r14d, 0x08
000078c0f8fd02bf  mov r12d, 0x40
000078c0f8fd02c5  cmp r14, r12
000078c0f8fd02c8  cmc
000078c0f8fd02c9  lahf
000078c0f8fd02ca  seto al
000078c0f8fd02cd  mov [r15+0x108], eax
000078c0f8fd02d4  mov eax, [r15+0x108]
000078c0f8fd02db  sahf
000078c0f8fd02dc  jnz 0x000078C0F8FD030E
000078c0f8fd02de  cmp dword ptr [r15+0x318], 0x00
000078c0f8fd02e6  jz 0x000078C0F8FCFD40
000078c0f8fd02ec  nop [rax+rax*1], ax
000078c0f8fd02f5  nop [rax+rax*1], eax
000078c0f8fd02fd  mov eax, 0x410118
000078c0f8fd0302  mov [r15+0x100], rax
000078c0f8fd0309  jmp 0x000078C0F8DFE110
000078c0f8fd030e  cmp dword ptr [r15+0x318], 0x00
000078c0f8fd0316  jz 0x000078C0F8FCF3F0
000078c0f8fd031c  nop [rax+rax*1], ax
000078c0f8fd0325  nop [rax+rax*1], eax
000078c0f8fd032d  mov eax, 0x4100A4
000078c0f8fd0332  mov [r15+0x100], rax
000078c0f8fd0339  jmp 0x000078C0F8DFE110
000078c0f8fd033e  int3
000078c0f8fd033f  call 0x000078C0F8EB47C0
000078c0f8fd0344  jmp 0x000078C0F8FCFDF5
000078c0f8fd0349  call 0x000078C0F8EE1570
000078c0f8fd034e  jmp 0x000078C0F8FCFDFF
000078c0f8fd0353  call 0x000078C0F8E0DC20
000078c0f8fd0358  jmp 0x000078C0F8FCFE35
000078c0f8fd035d  call 0x000078C0F8E0A4B0
000078c0f8fd0362  jmp 0x000078C0F8FCFE3F
000078c0f8fd0367  call 0x000078C0F8E0DC20
000078c0f8fd036c  jmp 0x000078C0F8FCFE75
000078c0f8fd0371  call 0x000078C0F8E0A4B0
000078c0f8fd0376  jmp 0x000078C0F8FCFE7F
000078c0f8fd037b  call 0x000078C0F8E0DC20
000078c0f8fd0380  jmp 0x000078C0F8FCFEB5
000078c0f8fd0385  call 0x000078C0F8E0B720
000078c0f8fd038a  jmp 0x000078C0F8FCFEBF
000078c0f8fd038f  call 0x000078C0F8E0DC20
000078c0f8fd0394  jmp 0x000078C0F8FCFEF8
000078c0f8fd0399  call 0x000078C0F8EE27E0
000078c0f8fd039e  jmp 0x000078C0F8FCFF06
000078c0f8fd03a3  call 0x000078C0F8EE27E0
000078c0f8fd03a8  jmp 0x000078C0F8FCFF17
000078c0f8fd03ad  ucomisd xmm1, xmm13
000078c0f8fd03b2  jp 0x000078C0F8FD03C1
000078c0f8fd03b4  movaps xmm12, [0x000078C0F8BFE030]
000078c0f8fd03bc  jmp 0x000078C0F8FCFF4C
000078c0f8fd03c1  vxorps xmm0, xmm1, xmm13
000078c0f8fd03c6  pextrw r14d, xmm0, 0x03
000078c0f8fd03cc  and r14d, 0x7FF8
000078c0f8fd03d3  cmp r14d, 0x08
000078c0f8fd03d7  jnz 0x000078C0F8FCFF4C
000078c0f8fd03dd  movq r14, xmm13
000078c0f8fd03e2  shl r14, 0x0D
000078c0f8fd03e6  jbe 0x000078C0F8FCFF4C
000078c0f8fd03ec  vorps xmm12, xmm13, [0x000078C0F8BFE040]
000078c0f8fd03f4  jmp 0x000078C0F8FCFF4C
000078c0f8fd03f9  ucomisd xmm1, xmm15
000078c0f8fd03fe  jp 0x000078C0F8FD040D
000078c0f8fd0400  movaps xmm13, [0x000078C0F8BFE030]
000078c0f8fd0408  jmp 0x000078C0F8FCFF81
000078c0f8fd040d  vxorps xmm0, xmm1, xmm15
000078c0f8fd0412  pextrw r14d, xmm0, 0x03
000078c0f8fd0418  and r14d, 0x7FF8
000078c0f8fd041f  cmp r14d, 0x08
000078c0f8fd0423  jnz 0x000078C0F8FCFF81
000078c0f8fd0429  movq r14, xmm15
000078c0f8fd042e  shl r14, 0x0D
000078c0f8fd0432  jbe 0x000078C0F8FCFF81
000078c0f8fd0438  vorps xmm13, xmm15, [0x000078C0F8BFE040]
000078c0f8fd0440  jmp 0x000078C0F8FCFF81
000078c0f8fd0445  ucomisd xmm1, xmm15
000078c0f8fd044a  jp 0x000078C0F8FD0459
000078c0f8fd044c  movaps xmm12, [0x000078C0F8BFE030]
000078c0f8fd0454  jmp 0x000078C0F8FCFFB6
000078c0f8fd0459  vxorps xmm0, xmm1, xmm15
000078c0f8fd045e  pextrw r14d, xmm0, 0x03
000078c0f8fd0464  and r14d, 0x7FF8
000078c0f8fd046b  cmp r14d, 0x08
000078c0f8fd046f  jnz 0x000078C0F8FCFFB6
000078c0f8fd0475  movq r14, xmm15
000078c0f8fd047a  shl r14, 0x0D
000078c0f8fd047e  jbe 0x000078C0F8FCFFB6
000078c0f8fd0484  vorps xmm12, xmm15, [0x000078C0F8BFE040]
000078c0f8fd048c  jmp 0x000078C0F8FCFFB6
000078c0f8fd0491  ucomisd xmm1, xmm15
000078c0f8fd0496  jp 0x000078C0F8FD04A5
000078c0f8fd0498  movaps xmm13, [0x000078C0F8BFE030]
000078c0f8fd04a0  jmp 0x000078C0F8FCFFE3
000078c0f8fd04a5  vxorps xmm0, xmm1, xmm15
000078c0f8fd04aa  pextrw r14d, xmm0, 0x03
000078c0f8fd04b0  and r14d, 0x7FF8
000078c0f8fd04b7  cmp r14d, 0x08
000078c0f8fd04bb  jnz 0x000078C0F8FCFFE3
000078c0f8fd04c1  movq r14, xmm15
000078c0f8fd04c6  shl r14, 0x0D
000078c0f8fd04ca  jbe 0x000078C0F8FCFFE3
000078c0f8fd04d0  vorps xmm13, xmm15, [0x000078C0F8BFE040]
000078c0f8fd04d8  jmp 0x000078C0F8FCFFE3
000078c0f8fd04dd  ucomisd xmm1, xmm15
000078c0f8fd04e2  jp 0x000078C0F8FD04F1
000078c0f8fd04e4  movaps xmm14, [0x000078C0F8BFE030]
000078c0f8fd04ec  jmp 0x000078C0F8FD0018
000078c0f8fd04f1  vxorps xmm0, xmm1, xmm15
000078c0f8fd04f6  pextrw r14d, xmm0, 0x03
000078c0f8fd04fc  and r14d, 0x7FF8
000078c0f8fd0503  cmp r14d, 0x08
000078c0f8fd0507  jnz 0x000078C0F8FD0018
000078c0f8fd050d  movq r14, xmm15
000078c0f8fd0512  shl r14, 0x0D
000078c0f8fd0516  jbe 0x000078C0F8FD0018
000078c0f8fd051c  vorps xmm14, xmm15, [0x000078C0F8BFE040]
000078c0f8fd0524  jmp 0x000078C0F8FD0018
000078c0f8fd0529  call 0x000078C0F8EE27E0
000078c0f8fd052e  jmp 0x000078C0F8FD0029
000078c0f8fd0533  ucomisd xmm15, xmm14
000078c0f8fd0538  jp 0x000078C0F8FD0547
000078c0f8fd053a  movaps xmm13, [0x000078C0F8BFE030]
000078c0f8fd0542  jmp 0x000078C0F8FD0056
000078c0f8fd0547  vxorps xmm0, xmm15, xmm14
000078c0f8fd054c  pextrw r14d, xmm0, 0x03
000078c0f8fd0552  and r14d, 0x7FF8
000078c0f8fd0559  cmp r14d, 0x08
000078c0f8fd055d  jnz 0x000078C0F8FD0056
000078c0f8fd0563  movq r14, xmm14
000078c0f8fd0568  shl r14, 0x0D
000078c0f8fd056c  jbe 0x000078C0F8FD0056
000078c0f8fd0572  vorps xmm13, xmm14, [0x000078C0F8BFE040]
000078c0f8fd057a  jmp 0x000078C0F8FD0056
000078c0f8fd057f  ucomisd xmm1, xmm15
000078c0f8fd0584  jp 0x000078C0F8FD0593
000078c0f8fd0586  movaps xmm14, [0x000078C0F8BFE030]
000078c0f8fd058e  jmp 0x000078C0F8FD008B
000078c0f8fd0593  vxorps xmm0, xmm1, xmm15
000078c0f8fd0598  pextrw r14d, xmm0, 0x03
000078c0f8fd059e  and r14d, 0x7FF8
000078c0f8fd05a5  cmp r14d, 0x08
000078c0f8fd05a9  jnz 0x000078C0F8FD008B
000078c0f8fd05af  movq r14, xmm15
000078c0f8fd05b4  shl r14, 0x0D
000078c0f8fd05b8  jbe 0x000078C0F8FD008B
000078c0f8fd05be  vorps xmm14, xmm15, [0x000078C0F8BFE040]
000078c0f8fd05c6  jmp 0x000078C0F8FD008B
000078c0f8fd05cb  call 0x000078C0F8EE27E0
000078c0f8fd05d0  jmp 0x000078C0F8FD009C
000078c0f8fd05d5  ucomisd xmm15, xmm14
000078c0f8fd05da  jp 0x000078C0F8FD05E9
000078c0f8fd05dc  movaps xmm13, [0x000078C0F8BFE030]
000078c0f8fd05e4  jmp 0x000078C0F8FD00C9
000078c0f8fd05e9  vxorps xmm0, xmm15, xmm14
000078c0f8fd05ee  pextrw r14d, xmm0, 0x03
000078c0f8fd05f4  and r14d, 0x7FF8
000078c0f8fd05fb  cmp r14d, 0x08
000078c0f8fd05ff  jnz 0x000078C0F8FD00C9
000078c0f8fd0605  movq r14, xmm14
000078c0f8fd060a  shl r14, 0x0D
000078c0f8fd060e  jbe 0x000078C0F8FD00C9
000078c0f8fd0614  vorps xmm13, xmm14, [0x000078C0F8BFE040]
000078c0f8fd061c  jmp 0x000078C0F8FD00C9
000078c0f8fd0621  ucomisd xmm1, xmm15
000078c0f8fd0626  jp 0x000078C0F8FD0635
000078c0f8fd0628  movaps xmm14, [0x000078C0F8BFE030]
000078c0f8fd0630  jmp 0x000078C0F8FD00FE
000078c0f8fd0635  vxorps xmm0, xmm1, xmm15
000078c0f8fd063a  pextrw r14d, xmm0, 0x03
000078c0f8fd0640  and r14d, 0x7FF8
000078c0f8fd0647  cmp r14d, 0x08
000078c0f8fd064b  jnz 0x000078C0F8FD00FE
000078c0f8fd0651  movq r14, xmm15
000078c0f8fd0656  shl r14, 0x0D
000078c0f8fd065a  jbe 0x000078C0F8FD00FE
000078c0f8fd0660  vorps xmm14, xmm15, [0x000078C0F8BFE040]
000078c0f8fd0668  jmp 0x000078C0F8FD00FE
000078c0f8fd066d  call 0x000078C0F8EE27E0
000078c0f8fd0672  jmp 0x000078C0F8FD010F
000078c0f8fd0677  ucomisd xmm15, xmm14
000078c0f8fd067c  jp 0x000078C0F8FD068B
000078c0f8fd067e  movaps xmm13, [0x000078C0F8BFE030]
000078c0f8fd0686  jmp 0x000078C0F8FD013C
000078c0f8fd068b  vxorps xmm0, xmm15, xmm14
000078c0f8fd0690  pextrw r14d, xmm0, 0x03
000078c0f8fd0696  and r14d, 0x7FF8
000078c0f8fd069d  cmp r14d, 0x08
000078c0f8fd06a1  jnz 0x000078C0F8FD013C
000078c0f8fd06a7  movq r14, xmm14
000078c0f8fd06ac  shl r14, 0x0D
000078c0f8fd06b0  jbe 0x000078C0F8FD013C
000078c0f8fd06b6  vorps xmm13, xmm14, [0x000078C0F8BFE040]
000078c0f8fd06be  jmp 0x000078C0F8FD013C
000078c0f8fd06c3  ucomisd xmm1, xmm15
000078c0f8fd06c8  jp 0x000078C0F8FD06D7
000078c0f8fd06ca  movaps xmm14, [0x000078C0F8BFE030]
000078c0f8fd06d2  jmp 0x000078C0F8FD0171
000078c0f8fd06d7  vxorps xmm0, xmm1, xmm15
000078c0f8fd06dc  pextrw r14d, xmm0, 0x03
000078c0f8fd06e2  and r14d, 0x7FF8
000078c0f8fd06e9  cmp r14d, 0x08
000078c0f8fd06ed  jnz 0x000078C0F8FD0171
000078c0f8fd06f3  movq r14, xmm15
000078c0f8fd06f8  shl r14, 0x0D
000078c0f8fd06fc  jbe 0x000078C0F8FD0171
000078c0f8fd0702  vorps xmm14, xmm15, [0x000078C0F8BFE040]
000078c0f8fd070a  jmp 0x000078C0F8FD0171
000078c0f8fd070f  call 0x000078C0F8EE27E0
000078c0f8fd0714  jmp 0x000078C0F8FD0182
000078c0f8fd0719  ucomisd xmm15, xmm14
000078c0f8fd071e  jp 0x000078C0F8FD072D
000078c0f8fd0720  movaps xmm13, [0x000078C0F8BFE030]
000078c0f8fd0728  jmp 0x000078C0F8FD01AF
000078c0f8fd072d  vxorps xmm0, xmm15, xmm14
000078c0f8fd0732  pextrw r14d, xmm0, 0x03
000078c0f8fd0738  and r14d, 0x7FF8
000078c0f8fd073f  cmp r14d, 0x08
000078c0f8fd0743  jnz 0x000078C0F8FD01AF
000078c0f8fd0749  movq r14, xmm14
000078c0f8fd074e  shl r14, 0x0D
000078c0f8fd0752  jbe 0x000078C0F8FD01AF
000078c0f8fd0758  vorps xmm13, xmm14, [0x000078C0F8BFE040]
000078c0f8fd0760  jmp 0x000078C0F8FD01AF
000078c0f8fd0765  ucomisd xmm1, xmm15
000078c0f8fd076a  jp 0x000078C0F8FD0779
000078c0f8fd076c  movaps xmm14, [0x000078C0F8BFE030]
000078c0f8fd0774  jmp 0x000078C0F8FD01E4
000078c0f8fd0779  vxorps xmm0, xmm1, xmm15
000078c0f8fd077e  pextrw r14d, xmm0, 0x03
000078c0f8fd0784  and r14d, 0x7FF8
000078c0f8fd078b  cmp r14d, 0x08
000078c0f8fd078f  jnz 0x000078C0F8FD01E4
000078c0f8fd0795  movq r14, xmm15
000078c0f8fd079a  shl r14, 0x0D
000078c0f8fd079e  jbe 0x000078C0F8FD01E4
000078c0f8fd07a4  vorps xmm14, xmm15, [0x000078C0F8BFE040]
000078c0f8fd07ac  jmp 0x000078C0F8FD01E4
000078c0f8fd07b1  call 0x000078C0F8ED59C0
000078c0f8fd07b6  jmp 0x000078C0F8FD01F5
000078c0f8fd07bb  ucomisd xmm15, xmm14
000078c0f8fd07c0  jp 0x000078C0F8FD07CF
000078c0f8fd07c2  movaps xmm13, [0x000078C0F8BFE030]
000078c0f8fd07ca  jmp 0x000078C0F8FD022A
000078c0f8fd07cf  vxorps xmm0, xmm15, xmm14
000078c0f8fd07d4  pextrw eax, xmm0, 0x03
000078c0f8fd07d9  and eax, 0x7FF8
000078c0f8fd07de  cmp eax, 0x08
000078c0f8fd07e1  jnz 0x000078C0F8FD022A
000078c0f8fd07e7  movq rax, xmm14
000078c0f8fd07ec  shl rax, 0x0D
000078c0f8fd07f0  jbe 0x000078C0F8FD022A
000078c0f8fd07f6  vorps xmm13, xmm14, [0x000078C0F8BFE040]
000078c0f8fd07fe  jmp 0x000078C0F8FD022A
000078c0f8fd0803  ucomisd xmm1, xmm15
000078c0f8fd0808  jp 0x000078C0F8FD0817
000078c0f8fd080a  movaps xmm14, [0x000078C0F8BFE030]
000078c0f8fd0812  jmp 0x000078C0F8FD025F
000078c0f8fd0817  vxorps xmm0, xmm1, xmm15
000078c0f8fd081c  pextrw eax, xmm0, 0x03
000078c0f8fd0821  and eax, 0x7FF8
000078c0f8fd0826  cmp eax, 0x08
000078c0f8fd0829  jnz 0x000078C0F8FD025F
000078c0f8fd082f  movq rax, xmm15
000078c0f8fd0834  shl rax, 0x0D
000078c0f8fd0838  jbe 0x000078C0F8FD025F
000078c0f8fd083e  vorps xmm14, xmm15, [0x000078C0F8BFE040]
000078c0f8fd0846  jmp 0x000078C0F8FD025F
000078c0f8fd084b  ucomisd xmm1, xmm15
000078c0f8fd0850  jp 0x000078C0F8FD085F
000078c0f8fd0852  movaps xmm14, [0x000078C0F8BFE030]
000078c0f8fd085a  jmp 0x000078C0F8FD0294
000078c0f8fd085f  vxorps xmm0, xmm1, xmm15
000078c0f8fd0864  pextrw eax, xmm0, 0x03
000078c0f8fd0869  and eax, 0x7FF8
000078c0f8fd086e  cmp eax, 0x08
000078c0f8fd0871  jnz 0x000078C0F8FD0294
000078c0f8fd0877  movq rax, xmm15
000078c0f8fd087c  shl rax, 0x0D
000078c0f8fd0880  jbe 0x000078C0F8FD0294
000078c0f8fd0886  vorps xmm14, xmm15, [0x000078C0F8BFE040]
000078c0f8fd088e  jmp 0x000078C0F8FD0294
000078c0f8fd0893  call 0x000078C0F8E0E120
000078c0f8fd0898  jmp 0x000078C0F8FD02AF
000078c0f8fd089d  int3
000078c0f8fd089e  nop
000078c0f8fd08a0  mov eax, [r15+0x58]
000078c0f8fd08a4  lea r14d, [eax+0x01]
000078c0f8fd08a9  mov [rsp+0x10], r14d
000078c0f8fd08ae  mov r14d, r14d
000078c0f8fd08b1  mov [r15+0x58], r14
000078c0f8fd08b5  xor eax, eax
000078c0f8fd08b7  mov r14d, [rsp+0x10]
000078c0f8fd08bc  cmp r14d, 0x1F4
000078c0f8fd08c3  cmc
000078c0f8fd08c4  lahf
000078c0f8fd08c5  seto al
000078c0f8fd08c8  mov [r15+0x108], eax
000078c0f8fd08cf  mov eax, [r15+0x108]
000078c0f8fd08d6  sahf
000078c0f8fd08d7  jnz 0x000078C0F8FD0909
000078c0f8fd08d9  cmp dword ptr [r15+0x318], 0x00
000078c0f8fd08e1  jz 0x000078C0F8FD1410
000078c0f8fd08e7  nop [rax+rax*1], ax
000078c0f8fd08f0  nop [rax+rax*1], eax
000078c0f8fd08f8  mov eax, 0x410134
000078c0f8fd08fd  mov [r15+0x100], rax
000078c0f8fd0904  jmp 0x000078C0F8DFE110
000078c0f8fd0909  cmp dword ptr [r15+0x318], 0x00
000078c0f8fd0911  jz 0x000078C0F8FD0940
000078c0f8fd0917  nop [rax+rax*1], ax
000078c0f8fd0920  nop [rax+rax*1], eax
000078c0f8fd0928  mov eax, 0x410084
000078c0f8fd092d  mov [r15+0x100], rax
000078c0f8fd0934  jmp 0x000078C0F8DFE110
000078c0f8fd0939  int3
000078c0f8fd093a  int3
000078c0f8fd093b  nop [rax+rax*1], eax
000078c0f8fd0940  mov qword ptr [r15+0x60], 0x00
000078c0f8fd0948  mov rax, [r15+0x50]
000078c0f8fd094c  mov [r15+0x68], rax
000078c0f8fd0950  mov r14, [r15+0x40]
000078c0f8fd0954  mov r12, [r13+r14*1]
000078c0f8fd0959  lea r11, [r14+0x08]
000078c0f8fd095d  mov r10, [r13+r11*1]
000078c0f8fd0962  movq xmm1, r12
000078c0f8fd0967  movq xmm15, r10
000078c0f8fd096c  movq xmm1, xmm1
000078c0f8fd0970  movq xmm1, xmm1
000078c0f8fd0974  movaps [r15+0x120], xmm1
000078c0f8fd097c  movq xmm15, xmm15
000078c0f8fd0981  movq xmm15, xmm15
000078c0f8fd0986  movaps [r15+0x130], xmm15
000078c0f8fd098e  lea r12, [r14+0x10]
000078c0f8fd0992  mov r11, [r13+r12*1]
000078c0f8fd0997  lea r12, [r14+0x18]
000078c0f8fd099b  mov r10, [r13+r12*1]
000078c0f8fd09a0  movq xmm1, r11
000078c0f8fd09a5  movq xmm15, r10
000078c0f8fd09aa  movq xmm1, xmm1
000078c0f8fd09ae  movq xmm1, xmm1
000078c0f8fd09b2  movaps [r15+0x140], xmm1
000078c0f8fd09ba  movq xmm15, xmm15
000078c0f8fd09bf  movq xmm15, xmm15
000078c0f8fd09c4  movaps [r15+0x150], xmm15
000078c0f8fd09cc  lea r12, [r14+0x20]
000078c0f8fd09d0  mov r11, [r13+r12*1]
000078c0f8fd09d5  lea r12, [r14+0x28]
000078c0f8fd09d9  mov r10, [r13+r12*1]
000078c0f8fd09de  movq xmm1, r11
000078c0f8fd09e3  movq xmm15, r10
000078c0f8fd09e8  movq xmm1, xmm1
000078c0f8fd09ec  movq xmm1, xmm1
000078c0f8fd09f0  movaps [r15+0x160], xmm1
000078c0f8fd09f8  movq xmm15, xmm15
000078c0f8fd09fd  movq xmm15, xmm15
000078c0f8fd0a02  movaps [r15+0x170], xmm15
000078c0f8fd0a0a  lea r12, [r14+0x30]
000078c0f8fd0a0e  mov r11, [r13+r12*1]
000078c0f8fd0a13  lea r12, [r14+0x38]
000078c0f8fd0a17  mov r14, [r13+r12*1]
000078c0f8fd0a1c  movq xmm1, r11
000078c0f8fd0a21  movq xmm15, r14
000078c0f8fd0a26  movq xmm1, xmm1
000078c0f8fd0a2a  movq xmm1, xmm1
000078c0f8fd0a2e  movaps [r15+0x180], xmm1
000078c0f8fd0a36  movq xmm15, xmm15
000078c0f8fd0a3b  movq xmm15, xmm15
000078c0f8fd0a40  movaps [r15+0x210], xmm15
000078c0f8fd0a48  mov r14, [r15+0x48]
000078c0f8fd0a4c  mov [r15+0x78], r14
000078c0f8fd0a50  mov r12, [r13+r14*1]
000078c0f8fd0a55  movq xmm1, r12
000078c0f8fd0a5a  lea r12, [r14+0x40]
000078c0f8fd0a5e  mov r11, [r13+r12*1]
000078c0f8fd0a63  movq xmm15, r11
000078c0f8fd0a68  lea r12, [r14+0x80]
000078c0f8fd0a6f  mov r11, [r13+r12*1]
000078c0f8fd0a74  movq xmm14, r11
000078c0f8fd0a79  movaps xmm13, [r15+0x120]
000078c0f8fd0a81  movq r12, xmm13
000078c0f8fd0a86  movq r11, xmm1
000078c0f8fd0a8b  vmovq xmm1, r12
000078c0f8fd0a90  vmovq xmm13, r11
000078c0f8fd0a95  movaps xmm12, xmm1
000078c0f8fd0a99  mulsd xmm12, xmm13
000078c0f8fd0a9e  ucomisd xmm12, xmm12
000078c0f8fd0aa3  jp 0x000078C0F8FD0F06
000078c0f8fd0aa9  movq xmm12, xmm12
000078c0f8fd0aae  movaps xmm1, [r15+0x130]
000078c0f8fd0ab6  movq r12, xmm1
000078c0f8fd0abb  movq r11, xmm15
000078c0f8fd0ac0  vmovq xmm1, r12
000078c0f8fd0ac5  vmovq xmm15, r11
000078c0f8fd0aca  movaps xmm13, xmm1
000078c0f8fd0ace  mulsd xmm13, xmm15
000078c0f8fd0ad3  ucomisd xmm13, xmm13
000078c0f8fd0ad8  jp 0x000078C0F8FD0F52
000078c0f8fd0ade  movq xmm13, xmm13
000078c0f8fd0ae3  movq r12, xmm12
000078c0f8fd0ae8  movaps xmm1, [r15+0x110]
000078c0f8fd0af0  movq r11, xmm1
000078c0f8fd0af5  vmovq xmm1, r12
000078c0f8fd0afa  vmovq xmm15, r11
000078c0f8fd0aff  movaps xmm12, xmm1
000078c0f8fd0b03  addsd xmm12, xmm15
000078c0f8fd0b08  ucomisd xmm12, xmm12
000078c0f8fd0b0d  jp 0x000078C0F8FD0F9E
000078c0f8fd0b13  movq xmm12, xmm12
000078c0f8fd0b18  movq r12, xmm12
000078c0f8fd0b1d  movq r11, xmm13
000078c0f8fd0b22  vmovq xmm1, r12
000078c0f8fd0b27  vmovq xmm15, r11
000078c0f8fd0b2c  movaps xmm13, xmm1
000078c0f8fd0b30  addsd xmm13, xmm15
000078c0f8fd0b35  ucomisd xmm13, xmm13
000078c0f8fd0b3a  jp 0x000078C0F8FD0FEA
000078c0f8fd0b40  movq xmm13, xmm13
000078c0f8fd0b45  movaps xmm1, [r15+0x140]
000078c0f8fd0b4d  movq r12, xmm1
000078c0f8fd0b52  movq r11, xmm14
000078c0f8fd0b57  vmovq xmm1, r12
000078c0f8fd0b5c  vmovq xmm15, r11
000078c0f8fd0b61  movaps xmm14, xmm1
000078c0f8fd0b65  mulsd xmm14, xmm15
000078c0f8fd0b6a  ucomisd xmm14, xmm14
000078c0f8fd0b6f  jp 0x000078C0F8FD1036
000078c0f8fd0b75  movq xmm14, xmm14
000078c0f8fd0b7a  lea r12, [r14+0xC0]
000078c0f8fd0b81  mov r11, [r13+r12*1]
000078c0f8fd0b86  movq xmm1, r11
000078c0f8fd0b8b  movq r12, xmm13
000078c0f8fd0b90  movq r11, xmm14
000078c0f8fd0b95  vmovq xmm15, r12
000078c0f8fd0b9a  vmovq xmm14, r11
000078c0f8fd0b9f  movaps xmm13, xmm15
000078c0f8fd0ba3  addsd xmm13, xmm14
000078c0f8fd0ba8  ucomisd xmm13, xmm13
000078c0f8fd0bad  jp 0x000078C0F8FD108C
000078c0f8fd0bb3  movq xmm13, xmm13
000078c0f8fd0bb8  movaps xmm15, [r15+0x150]
000078c0f8fd0bc0  movq r12, xmm15
000078c0f8fd0bc5  movq r11, xmm1
000078c0f8fd0bca  vmovq xmm1, r12
000078c0f8fd0bcf  vmovq xmm15, r11
000078c0f8fd0bd4  movaps xmm14, xmm1
000078c0f8fd0bd8  mulsd xmm14, xmm15
000078c0f8fd0bdd  ucomisd xmm14, xmm14
000078c0f8fd0be2  jp 0x000078C0F8FD10D8
000078c0f8fd0be8  movq xmm14, xmm14
000078c0f8fd0bed  lea r12, [r14+0x100]
000078c0f8fd0bf4  mov r11, [r13+r12*1]
000078c0f8fd0bf9  movq xmm1, r11
000078c0f8fd0bfe  movq r12, xmm13
000078c0f8fd0c03  movq r11, xmm14
000078c0f8fd0c08  vmovq xmm15, r12
000078c0f8fd0c0d  vmovq xmm14, r11
000078c0f8fd0c12  movaps xmm13, xmm15
000078c0f8fd0c16  addsd xmm13, xmm14
000078c0f8fd0c1b  ucomisd xmm13, xmm13
000078c0f8fd0c20  jp 0x000078C0F8FD112E
000078c0f8fd0c26  movq xmm13, xmm13
000078c0f8fd0c2b  movaps xmm15, [r15+0x160]
000078c0f8fd0c33  movq r12, xmm15
000078c0f8fd0c38  movq r11, xmm1
000078c0f8fd0c3d  vmovq xmm1, r12
000078c0f8fd0c42  vmovq xmm15, r11
000078c0f8fd0c47  movaps xmm14, xmm1
000078c0f8fd0c4b  mulsd xmm14, xmm15
000078c0f8fd0c50  ucomisd xmm14, xmm14
000078c0f8fd0c55  jp 0x000078C0F8FD117A
000078c0f8fd0c5b  movq xmm14, xmm14
000078c0f8fd0c60  lea r12, [r14+0x140]
000078c0f8fd0c67  mov r11, [r13+r12*1]
000078c0f8fd0c6c  movq xmm1, r11
000078c0f8fd0c71  movq r12, xmm13
000078c0f8fd0c76  movq r11, xmm14
000078c0f8fd0c7b  vmovq xmm15, r12
000078c0f8fd0c80  vmovq xmm14, r11
000078c0f8fd0c85  movaps xmm13, xmm15
000078c0f8fd0c89  addsd xmm13, xmm14
000078c0f8fd0c8e  ucomisd xmm13, xmm13
000078c0f8fd0c93  jp 0x000078C0F8FD11D0
000078c0f8fd0c99  movq xmm13, xmm13
000078c0f8fd0c9e  movaps xmm15, [r15+0x170]
000078c0f8fd0ca6  movq r12, xmm15
000078c0f8fd0cab  movq r11, xmm1
000078c0f8fd0cb0  vmovq xmm1, r12
000078c0f8fd0cb5  vmovq xmm15, r11
000078c0f8fd0cba  movaps xmm14, xmm1
000078c0f8fd0cbe  mulsd xmm14, xmm15
000078c0f8fd0cc3  ucomisd xmm14, xmm14
000078c0f8fd0cc8  jp 0x000078C0F8FD121C
000078c0f8fd0cce  movq xmm14, xmm14
000078c0f8fd0cd3  lea r12, [r14+0x180]
000078c0f8fd0cda  mov r11, [r13+r12*1]
000078c0f8fd0cdf  movq xmm1, r11
000078c0f8fd0ce4  movq r12, xmm13
000078c0f8fd0ce9  movq r11, xmm14
000078c0f8fd0cee  vmovq xmm15, r12
000078c0f8fd0cf3  vmovq xmm14, r11
000078c0f8fd0cf8  movaps xmm13, xmm15
000078c0f8fd0cfc  addsd xmm13, xmm14
000078c0f8fd0d01  ucomisd xmm13, xmm13
000078c0f8fd0d06  jp 0x000078C0F8FD1272
000078c0f8fd0d0c  movq xmm13, xmm13
000078c0f8fd0d11  movaps xmm15, [r15+0x180]
000078c0f8fd0d19  movq r12, xmm15
000078c0f8fd0d1e  movq r11, xmm1
000078c0f8fd0d23  vmovq xmm1, r12
000078c0f8fd0d28  vmovq xmm15, r11
000078c0f8fd0d2d  movaps xmm14, xmm1
000078c0f8fd0d31  mulsd xmm14, xmm15
000078c0f8fd0d36  ucomisd xmm14, xmm14
000078c0f8fd0d3b  jp 0x000078C0F8FD12BE
000078c0f8fd0d41  movq xmm14, xmm14
000078c0f8fd0d46  lea r12, [r14+0x1C0]
000078c0f8fd0d4d  mov r14, [r13+r12*1]
000078c0f8fd0d52  movq xmm1, r14
000078c0f8fd0d57  movaps [r15+0x240], xmm1
000078c0f8fd0d5f  movq r14, xmm13
000078c0f8fd0d64  movq r12, xmm14
000078c0f8fd0d69  vmovq xmm15, r14
000078c0f8fd0d6e  vmovq xmm14, r12
000078c0f8fd0d73  movaps xmm13, xmm15
000078c0f8fd0d77  addsd xmm13, xmm14
000078c0f8fd0d7c  ucomisd xmm13, xmm13
000078c0f8fd0d81  jp 0x000078C0F8FD1314
000078c0f8fd0d87  movq xmm13, xmm13
000078c0f8fd0d8c  movaps xmm15, [r15+0x210]
000078c0f8fd0d94  movq r14, xmm15
000078c0f8fd0d99  movq r12, xmm1
000078c0f8fd0d9e  vmovq xmm1, r14
000078c0f8fd0da3  vmovq xmm15, r12
000078c0f8fd0da8  movaps xmm14, xmm1
000078c0f8fd0dac  mulsd xmm14, xmm15
000078c0f8fd0db1  ucomisd xmm14, xmm14
000078c0f8fd0db6  jp 0x000078C0F8FD1360
000078c0f8fd0dbc  movq xmm14, xmm14
000078c0f8fd0dc1  movaps [r15+0x230], xmm14
000078c0f8fd0dc9  movq r14, xmm13
000078c0f8fd0dce  movq r12, xmm14
000078c0f8fd0dd3  vmovq xmm1, r14
000078c0f8fd0dd8  vmovq xmm15, r12
000078c0f8fd0ddd  movaps xmm14, xmm1
000078c0f8fd0de1  addsd xmm14, xmm15
000078c0f8fd0de6  ucomisd xmm14, xmm14
000078c0f8fd0deb  jp 0x000078C0F8FD13AC
000078c0f8fd0df1  movq xmm14, xmm14
000078c0f8fd0df6  movaps [r15+0x220], xmm14
000078c0f8fd0dfe  movq r14, xmm14
000078c0f8fd0e03  mov [r13+rax*1], r14
000078c0f8fd0e08  mov qword ptr [r15+0x70], 0x08
000078c0f8fd0e10  xor eax, eax
000078c0f8fd0e12  mov r14d, 0x08
000078c0f8fd0e18  mov r12d, 0x40
000078c0f8fd0e1e  cmp r14, r12
000078c0f8fd0e21  cmc
000078c0f8fd0e22  lahf
000078c0f8fd0e23  seto al
000078c0f8fd0e26  mov [r15+0x108], eax
000078c0f8fd0e2d  mov eax, [r15+0x108]
000078c0f8fd0e34  sahf
000078c0f8fd0e35  jnz 0x000078C0F8FD0E67
000078c0f8fd0e37  cmp dword ptr [r15+0x318], 0x00
000078c0f8fd0e3f  jz 0x000078C0F8FCFD40
000078c0f8fd0e45  nop [rax+rax*1], ax
000078c0f8fd0e4e  nop [rax+rax*1], eax
000078c0f8fd0e56  mov eax, 0x410118
000078c0f8fd0e5b  mov [r15+0x100], rax
000078c0f8fd0e62  jmp 0x000078C0F8DFE110
000078c0f8fd0e67  cmp dword ptr [r15+0x318], 0x00
000078c0f8fd0e6f  jz 0x000078C0F8FCF3F0
000078c0f8fd0e75  nop [rax+rax*1], ax
000078c0f8fd0e7e  nop [rax+rax*1], eax
000078c0f8fd0e86  mov eax, 0x4100A4
000078c0f8fd0e8b  mov [r15+0x100], rax
000078c0f8fd0e92  jmp 0x000078C0F8DFE110
000078c0f8fd0e97  int3
000078c0f8fd0e98  call 0x000078C0F8EE27E0
000078c0f8fd0e9d  jmp 0x000078C0F8FD0959
000078c0f8fd0ea2  call 0x000078C0F8EAE800
000078c0f8fd0ea7  jmp 0x000078C0F8FD0962
000078c0f8fd0eac  call 0x000078C0F8EC0370
000078c0f8fd0eb1  jmp 0x000078C0F8FD0997
000078c0f8fd0eb6  call 0x000078C0F8EBF100
000078c0f8fd0ebb  jmp 0x000078C0F8FD09A0
000078c0f8fd0ec0  call 0x000078C0F8EC0370
000078c0f8fd0ec5  jmp 0x000078C0F8FD09D5
000078c0f8fd0eca  call 0x000078C0F8EBF100
000078c0f8fd0ecf  jmp 0x000078C0F8FD09DE
000078c0f8fd0ed4  call 0x000078C0F8EC0370
000078c0f8fd0ed9  jmp 0x000078C0F8FD0A13
000078c0f8fd0ede  call 0x000078C0F8EC3AE0
000078c0f8fd0ee3  jmp 0x000078C0F8FD0A1C
000078c0f8fd0ee8  call 0x000078C0F8EE27E0
000078c0f8fd0eed  jmp 0x000078C0F8FD0A55
000078c0f8fd0ef2  call 0x000078C0F8EC0370
000078c0f8fd0ef7  jmp 0x000078C0F8FD0A63
000078c0f8fd0efc  call 0x000078C0F8EC0370
000078c0f8fd0f01  jmp 0x000078C0F8FD0A74
000078c0f8fd0f06  ucomisd xmm1, xmm13
000078c0f8fd0f0b  jp 0x000078C0F8FD0F1A
000078c0f8fd0f0d  movaps xmm12, [0x000078C0F8BFE030]
000078c0f8fd0f15  jmp 0x000078C0F8FD0AA9
000078c0f8fd0f1a  vxorps xmm0, xmm1, xmm13
000078c0f8fd0f1f  pextrw r12d, xmm0, 0x03
000078c0f8fd0f25  and r12d, 0x7FF8
000078c0f8fd0f2c  cmp r12d, 0x08
000078c0f8fd0f30  jnz 0x000078C0F8FD0AA9
000078c0f8fd0f36  movq r12, xmm13
000078c0f8fd0f3b  shl r12, 0x0D
000078c0f8fd0f3f  jbe 0x000078C0F8FD0AA9
000078c0f8fd0f45  vorps xmm12, xmm13, [0x000078C0F8BFE040]
000078c0f8fd0f4d  jmp 0x000078C0F8FD0AA9
000078c0f8fd0f52  ucomisd xmm1, xmm15
000078c0f8fd0f57  jp 0x000078C0F8FD0F66
000078c0f8fd0f59  movaps xmm13, [0x000078C0F8BFE030]
000078c0f8fd0f61  jmp 0x000078C0F8FD0ADE
000078c0f8fd0f66  vxorps xmm0, xmm1, xmm15
000078c0f8fd0f6b  pextrw r12d, xmm0, 0x03
000078c0f8fd0f71  and r12d, 0x7FF8
000078c0f8fd0f78  cmp r12d, 0x08
000078c0f8fd0f7c  jnz 0x000078C0F8FD0ADE
000078c0f8fd0f82  movq r12, xmm15
000078c0f8fd0f87  shl r12, 0x0D
000078c0f8fd0f8b  jbe 0x000078C0F8FD0ADE
000078c0f8fd0f91  vorps xmm13, xmm15, [0x000078C0F8BFE040]
000078c0f8fd0f99  jmp 0x000078C0F8FD0ADE
000078c0f8fd0f9e  ucomisd xmm1, xmm15
000078c0f8fd0fa3  jp 0x000078C0F8FD0FB2
000078c0f8fd0fa5  movaps xmm12, [0x000078C0F8BFE030]
000078c0f8fd0fad  jmp 0x000078C0F8FD0B13
000078c0f8fd0fb2  vxorps xmm0, xmm1, xmm15
000078c0f8fd0fb7  pextrw r12d, xmm0, 0x03
000078c0f8fd0fbd  and r12d, 0x7FF8
000078c0f8fd0fc4  cmp r12d, 0x08
000078c0f8fd0fc8  jnz 0x000078C0F8FD0B13
000078c0f8fd0fce  movq r12, xmm15
000078c0f8fd0fd3  shl r12, 0x0D
000078c0f8fd0fd7  jbe 0x000078C0F8FD0B13
000078c0f8fd0fdd  vorps xmm12, xmm15, [0x000078C0F8BFE040]
000078c0f8fd0fe5  jmp 0x000078C0F8FD0B13
000078c0f8fd0fea  ucomisd xmm1, xmm15
000078c0f8fd0fef  jp 0x000078C0F8FD0FFE
000078c0f8fd0ff1  movaps xmm13, [0x000078C0F8BFE030]
000078c0f8fd0ff9  jmp 0x000078C0F8FD0B40
000078c0f8fd0ffe  vxorps xmm0, xmm1, xmm15
000078c0f8fd1003  pextrw r12d, xmm0, 0x03
000078c0f8fd1009  and r12d, 0x7FF8
000078c0f8fd1010  cmp r12d, 0x08
000078c0f8fd1014  jnz 0x000078C0F8FD0B40
000078c0f8fd101a  movq r12, xmm15
000078c0f8fd101f  shl r12, 0x0D
000078c0f8fd1023  jbe 0x000078C0F8FD0B40
000078c0f8fd1029  vorps xmm13, xmm15, [0x000078C0F8BFE040]
000078c0f8fd1031  jmp 0x000078C0F8FD0B40
000078c0f8fd1036  ucomisd xmm1, xmm15
000078c0f8fd103b  jp 0x000078C0F8FD104A
000078c0f8fd103d  movaps xmm14, [0x000078C0F8BFE030]
000078c0f8fd1045  jmp 0x000078C0F8FD0B75
000078c0f8fd104a  vxorps xmm0, xmm1, xmm15
000078c0f8fd104f  pextrw r12d, xmm0, 0x03
000078c0f8fd1055  and r12d, 0x7FF8
000078c0f8fd105c  cmp r12d, 0x08
000078c0f8fd1060  jnz 0x000078C0F8FD0B75
000078c0f8fd1066  movq r12, xmm15
000078c0f8fd106b  shl r12, 0x0D
000078c0f8fd106f  jbe 0x000078C0F8FD0B75
000078c0f8fd1075  vorps xmm14, xmm15, [0x000078C0F8BFE040]
000078c0f8fd107d  jmp 0x000078C0F8FD0B75
000078c0f8fd1082  call 0x000078C0F8EC0370
000078c0f8fd1087  jmp 0x000078C0F8FD0B86
000078c0f8fd108c  ucomisd xmm15, xmm14
000078c0f8fd1091  jp 0x000078C0F8FD10A0
000078c0f8fd1093  movaps xmm13, [0x000078C0F8BFE030]
000078c0f8fd109b  jmp 0x000078C0F8FD0BB3
000078c0f8fd10a0  vxorps xmm0, xmm15, xmm14
000078c0f8fd10a5  pextrw r12d, xmm0, 0x03
000078c0f8fd10ab  and r12d, 0x7FF8
000078c0f8fd10b2  cmp r12d, 0x08
000078c0f8fd10b6  jnz 0x000078C0F8FD0BB3
000078c0f8fd10bc  movq r12, xmm14
000078c0f8fd10c1  shl r12, 0x0D
000078c0f8fd10c5  jbe 0x000078C0F8FD0BB3
000078c0f8fd10cb  vorps xmm13, xmm14, [0x000078C0F8BFE040]
000078c0f8fd10d3  jmp 0x000078C0F8FD0BB3
000078c0f8fd10d8  ucomisd xmm1, xmm15
000078c0f8fd10dd  jp 0x000078C0F8FD10EC
000078c0f8fd10df  movaps xmm14, [0x000078C0F8BFE030]
000078c0f8fd10e7  jmp 0x000078C0F8FD0BE8
000078c0f8fd10ec  vxorps xmm0, xmm1, xmm15
000078c0f8fd10f1  pextrw r12d, xmm0, 0x03
000078c0f8fd10f7  and r12d, 0x7FF8
000078c0f8fd10fe  cmp r12d, 0x08
000078c0f8fd1102  jnz 0x000078C0F8FD0BE8
000078c0f8fd1108  movq r12, xmm15
000078c0f8fd110d  shl r12, 0x0D
000078c0f8fd1111  jbe 0x000078C0F8FD0BE8
000078c0f8fd1117  vorps xmm14, xmm15, [0x000078C0F8BFE040]
000078c0f8fd111f  jmp 0x000078C0F8FD0BE8
000078c0f8fd1124  call 0x000078C0F8EC0370
000078c0f8fd1129  jmp 0x000078C0F8FD0BF9
000078c0f8fd112e  ucomisd xmm15, xmm14
000078c0f8fd1133  jp 0x000078C0F8FD1142
000078c0f8fd1135  movaps xmm13, [0x000078C0F8BFE030]
000078c0f8fd113d  jmp 0x000078C0F8FD0C26
000078c0f8fd1142  vxorps xmm0, xmm15, xmm14
000078c0f8fd1147  pextrw r12d, xmm0, 0x03
000078c0f8fd114d  and r12d, 0x7FF8
000078c0f8fd1154  cmp r12d, 0x08
000078c0f8fd1158  jnz 0x000078C0F8FD0C26
000078c0f8fd115e  movq r12, xmm14
000078c0f8fd1163  shl r12, 0x0D
000078c0f8fd1167  jbe 0x000078C0F8FD0C26
000078c0f8fd116d  vorps xmm13, xmm14, [0x000078C0F8BFE040]
000078c0f8fd1175  jmp 0x000078C0F8FD0C26
000078c0f8fd117a  ucomisd xmm1, xmm15
000078c0f8fd117f  jp 0x000078C0F8FD118E
000078c0f8fd1181  movaps xmm14, [0x000078C0F8BFE030]
000078c0f8fd1189  jmp 0x000078C0F8FD0C5B
000078c0f8fd118e  vxorps xmm0, xmm1, xmm15
000078c0f8fd1193  pextrw r12d, xmm0, 0x03
000078c0f8fd1199  and r12d, 0x7FF8
000078c0f8fd11a0  cmp r12d, 0x08
000078c0f8fd11a4  jnz 0x000078C0F8FD0C5B
000078c0f8fd11aa  movq r12, xmm15
000078c0f8fd11af  shl r12, 0x0D
000078c0f8fd11b3  jbe 0x000078C0F8FD0C5B
000078c0f8fd11b9  vorps xmm14, xmm15, [0x000078C0F8BFE040]
000078c0f8fd11c1  jmp 0x000078C0F8FD0C5B
000078c0f8fd11c6  call 0x000078C0F8EC0370
000078c0f8fd11cb  jmp 0x000078C0F8FD0C6C
000078c0f8fd11d0  ucomisd xmm15, xmm14
000078c0f8fd11d5  jp 0x000078C0F8FD11E4
000078c0f8fd11d7  movaps xmm13, [0x000078C0F8BFE030]
000078c0f8fd11df  jmp 0x000078C0F8FD0C99
000078c0f8fd11e4  vxorps xmm0, xmm15, xmm14
000078c0f8fd11e9  pextrw r12d, xmm0, 0x03
000078c0f8fd11ef  and r12d, 0x7FF8
000078c0f8fd11f6  cmp r12d, 0x08
000078c0f8fd11fa  jnz 0x000078C0F8FD0C99
000078c0f8fd1200  movq r12, xmm14
000078c0f8fd1205  shl r12, 0x0D
000078c0f8fd1209  jbe 0x000078C0F8FD0C99
000078c0f8fd120f  vorps xmm13, xmm14, [0x000078C0F8BFE040]
000078c0f8fd1217  jmp 0x000078C0F8FD0C99
000078c0f8fd121c  ucomisd xmm1, xmm15
000078c0f8fd1221  jp 0x000078C0F8FD1230
000078c0f8fd1223  movaps xmm14, [0x000078C0F8BFE030]
000078c0f8fd122b  jmp 0x000078C0F8FD0CCE
000078c0f8fd1230  vxorps xmm0, xmm1, xmm15
000078c0f8fd1235  pextrw r12d, xmm0, 0x03
000078c0f8fd123b  and r12d, 0x7FF8
000078c0f8fd1242  cmp r12d, 0x08
000078c0f8fd1246  jnz 0x000078C0F8FD0CCE
000078c0f8fd124c  movq r12, xmm15
000078c0f8fd1251  shl r12, 0x0D
000078c0f8fd1255  jbe 0x000078C0F8FD0CCE
000078c0f8fd125b  vorps xmm14, xmm15, [0x000078C0F8BFE040]
000078c0f8fd1263  jmp 0x000078C0F8FD0CCE
000078c0f8fd1268  call 0x000078C0F8EC0370
000078c0f8fd126d  jmp 0x000078C0F8FD0CDF
000078c0f8fd1272  ucomisd xmm15, xmm14
000078c0f8fd1277  jp 0x000078C0F8FD1286
000078c0f8fd1279  movaps xmm13, [0x000078C0F8BFE030]
000078c0f8fd1281  jmp 0x000078C0F8FD0D0C
000078c0f8fd1286  vxorps xmm0, xmm15, xmm14
000078c0f8fd128b  pextrw r12d, xmm0, 0x03
000078c0f8fd1291  and r12d, 0x7FF8
000078c0f8fd1298  cmp r12d, 0x08
000078c0f8fd129c  jnz 0x000078C0F8FD0D0C
000078c0f8fd12a2  movq r12, xmm14
000078c0f8fd12a7  shl r12, 0x0D
000078c0f8fd12ab  jbe 0x000078C0F8FD0D0C
000078c0f8fd12b1  vorps xmm13, xmm14, [0x000078C0F8BFE040]
000078c0f8fd12b9  jmp 0x000078C0F8FD0D0C
000078c0f8fd12be  ucomisd xmm1, xmm15
000078c0f8fd12c3  jp 0x000078C0F8FD12D2
000078c0f8fd12c5  movaps xmm14, [0x000078C0F8BFE030]
000078c0f8fd12cd  jmp 0x000078C0F8FD0D41
000078c0f8fd12d2  vxorps xmm0, xmm1, xmm15
000078c0f8fd12d7  pextrw r12d, xmm0, 0x03
000078c0f8fd12dd  and r12d, 0x7FF8
000078c0f8fd12e4  cmp r12d, 0x08
000078c0f8fd12e8  jnz 0x000078C0F8FD0D41
000078c0f8fd12ee  movq r12, xmm15
000078c0f8fd12f3  shl r12, 0x0D
000078c0f8fd12f7  jbe 0x000078C0F8FD0D41
000078c0f8fd12fd  vorps xmm14, xmm15, [0x000078C0F8BFE040]
000078c0f8fd1305  jmp 0x000078C0F8FD0D41
000078c0f8fd130a  call 0x000078C0F8EC3AE0
000078c0f8fd130f  jmp 0x000078C0F8FD0D52
000078c0f8fd1314  ucomisd xmm15, xmm14
000078c0f8fd1319  jp 0x000078C0F8FD1328
000078c0f8fd131b  movaps xmm13, [0x000078C0F8BFE030]
000078c0f8fd1323  jmp 0x000078C0F8FD0D87
000078c0f8fd1328  vxorps xmm0, xmm15, xmm14
000078c0f8fd132d  pextrw r14d, xmm0, 0x03
000078c0f8fd1333  and r14d, 0x7FF8
000078c0f8fd133a  cmp r14d, 0x08
000078c0f8fd133e  jnz 0x000078C0F8FD0D87
000078c0f8fd1344  movq r14, xmm14
000078c0f8fd1349  shl r14, 0x0D
000078c0f8fd134d  jbe 0x000078C0F8FD0D87
000078c0f8fd1353  vorps xmm13, xmm14, [0x000078C0F8BFE040]
000078c0f8fd135b  jmp 0x000078C0F8FD0D87
000078c0f8fd1360  ucomisd xmm1, xmm15
000078c0f8fd1365  jp 0x000078C0F8FD1374
000078c0f8fd1367  movaps xmm14, [0x000078C0F8BFE030]
000078c0f8fd136f  jmp 0x000078C0F8FD0DBC
000078c0f8fd1374  vxorps xmm0, xmm1, xmm15
000078c0f8fd1379  pextrw r14d, xmm0, 0x03
000078c0f8fd137f  and r14d, 0x7FF8
000078c0f8fd1386  cmp r14d, 0x08
000078c0f8fd138a  jnz 0x000078C0F8FD0DBC
000078c0f8fd1390  movq r14, xmm15
000078c0f8fd1395  shl r14, 0x0D
000078c0f8fd1399  jbe 0x000078C0F8FD0DBC
000078c0f8fd139f  vorps xmm14, xmm15, [0x000078C0F8BFE040]
000078c0f8fd13a7  jmp 0x000078C0F8FD0DBC
000078c0f8fd13ac  ucomisd xmm1, xmm15
000078c0f8fd13b1  jp 0x000078C0F8FD13C0
000078c0f8fd13b3  movaps xmm14, [0x000078C0F8BFE030]
000078c0f8fd13bb  jmp 0x000078C0F8FD0DF1
000078c0f8fd13c0  vxorps xmm0, xmm1, xmm15
000078c0f8fd13c5  pextrw r14d, xmm0, 0x03
000078c0f8fd13cb  and r14d, 0x7FF8
000078c0f8fd13d2  cmp r14d, 0x08
000078c0f8fd13d6  jnz 0x000078C0F8FD0DF1
000078c0f8fd13dc  movq r14, xmm15
000078c0f8fd13e1  shl r14, 0x0D
000078c0f8fd13e5  jbe 0x000078C0F8FD0DF1
000078c0f8fd13eb  vorps xmm14, xmm15, [0x000078C0F8BFE040]
000078c0f8fd13f3  jmp 0x000078C0F8FD0DF1
000078c0f8fd13f8  call 0x000078C0F8E0E120
000078c0f8fd13fd  jmp 0x000078C0F8FD0E08
000078c0f8fd1402  int3
000078c0f8fd1403  nop [rax+rax*1], ax
000078c0f8fd140c  nop [rax], eax
000078c0f8fd1410  mov qword ptr [r15+0x40], 0x420000
000078c0f8fd1418  mov eax, 0x4201B8
000078c0f8fd141d  mov r14, [r13+rax*1]
000078c0f8fd1422  movq xmm1, r14
000078c0f8fd1427  mov rax, [r15+0x50]
000078c0f8fd142b  mov r14, [r13+rax*1]
000078c0f8fd1430  movq xmm15, r14
000078c0f8fd1435  movaps [r15+0x120], xmm15
000078c0f8fd143d  mov qword ptr [r15+0x48], 0x08
000078c0f8fd1445  xor eax, eax
000078c0f8fd1447  mov r14d, 0x08
000078c0f8fd144d  mov r12d, 0x200
000078c0f8fd1453  cmp r14, r12
000078c0f8fd1456  cmc
000078c0f8fd1457  lahf
000078c0f8fd1458  seto al
000078c0f8fd145b  mov [r15+0x108], eax
000078c0f8fd1462  movq rax, xmm1
000078c0f8fd1467  movq r14, xmm15
000078c0f8fd146c  vmovq xmm1, rax
000078c0f8fd1471  vmovq xmm15, r14
000078c0f8fd1476  movaps xmm14, xmm1
000078c0f8fd147a  addsd xmm14, xmm15
000078c0f8fd147f  ucomisd xmm14, xmm14
000078c0f8fd1484  jp 0x000078C0F8FD1516
000078c0f8fd148a  movq xmm14, xmm14
000078c0f8fd148f  movaps [r15+0x110], xmm14
000078c0f8fd1497  mov eax, [r15+0x108]
000078c0f8fd149e  sahf
000078c0f8fd149f  jnz 0x000078C0F8FD14D1
000078c0f8fd14a1  cmp dword ptr [r15+0x318], 0x00
000078c0f8fd14a9  jz 0x000078C0F8FD16A0
000078c0f8fd14af  nop [rax+rax*1], ax
000078c0f8fd14b8  nop [rax+rax*1], eax
000078c0f8fd14c0  mov eax, 0x410154
000078c0f8fd14c5  mov [r15+0x100], rax
000078c0f8fd14cc  jmp 0x000078C0F8DFE110
000078c0f8fd14d1  cmp dword ptr [r15+0x318], 0x00
000078c0f8fd14d9  jz 0x000078C0F8FD1560
000078c0f8fd14df  nop [rax+rax*1], ax
000078c0f8fd14e8  nop [rax+rax*1], eax
000078c0f8fd14f0  mov eax, 0x410140
000078c0f8fd14f5  mov [r15+0x100], rax
000078c0f8fd14fc  jmp 0x000078C0F8DFE110
000078c0f8fd1501  int3
000078c0f8fd1502  call 0x000078C0F8E0DC20
000078c0f8fd1507  jmp 0x000078C0F8FD1422
000078c0f8fd150c  call 0x000078C0F8E0DC20
000078c0f8fd1511  jmp 0x000078C0F8FD1430
000078c0f8fd1516  ucomisd xmm1, xmm15
000078c0f8fd151b  jp 0x000078C0F8FD152A
000078c0f8fd151d  movaps xmm14, [0x000078C0F8BFE030]
000078c0f8fd1525  jmp 0x000078C0F8FD148A
000078c0f8fd152a  vxorps xmm0, xmm1, xmm15
000078c0f8fd152f  pextrw eax, xmm0, 0x03
000078c0f8fd1534  and eax, 0x7FF8
000078c0f8fd1539  cmp eax, 0x08
000078c0f8fd153c  jnz 0x000078C0F8FD148A
000078c0f8fd1542  movq rax, xmm15
000078c0f8fd1547  shl rax, 0x0D
000078c0f8fd154b  jbe 0x000078C0F8FD148A
000078c0f8fd1551  vorps xmm14, xmm15, [0x000078C0F8BFE040]
000078c0f8fd1559  jmp 0x000078C0F8FD148A
000078c0f8fd155e  int3
000078c0f8fd155f  nop
000078c0f8fd1560  mov rax, [r15+0x48]
000078c0f8fd1564  mov r14, [r15+0x50]
000078c0f8fd1568  lea r12, [r14+rax*1]
000078c0f8fd156c  mov r14, [r13+r12*1]
000078c0f8fd1571  movq xmm1, r14
000078c0f8fd1576  movaps [r15+0x120], xmm1
000078c0f8fd157e  lea r14, [rax+0x08]
000078c0f8fd1582  mov [r15+0x48], r14
000078c0f8fd1586  xor eax, eax
000078c0f8fd1588  mov r12d, 0x200
000078c0f8fd158e  cmp r14, r12
000078c0f8fd1591  cmc
000078c0f8fd1592  lahf
000078c0f8fd1593  seto al
000078c0f8fd1596  mov [r15+0x108], eax
000078c0f8fd159d  movaps xmm15, [r15+0x110]
000078c0f8fd15a5  movq rax, xmm15
000078c0f8fd15aa  movq r14, xmm1
000078c0f8fd15af  vmovq xmm1, rax
000078c0f8fd15b4  vmovq xmm15, r14
000078c0f8fd15b9  movaps xmm14, xmm1
000078c0f8fd15bd  addsd xmm14, xmm15
000078c0f8fd15c2  ucomisd xmm14, xmm14
000078c0f8fd15c7  jp 0x000078C0F8FD164F
000078c0f8fd15cd  movq xmm14, xmm14
000078c0f8fd15d2  movaps [r15+0x110], xmm14
000078c0f8fd15da  mov eax, [r15+0x108]
000078c0f8fd15e1  sahf
000078c0f8fd15e2  jnz 0x000078C0F8FD1614
000078c0f8fd15e4  cmp dword ptr [r15+0x318], 0x00
000078c0f8fd15ec  jz 0x000078C0F8FD16A0
000078c0f8fd15f2  nop [rax+rax*1], ax
000078c0f8fd15fb  nop [rax+rax*1], eax
000078c0f8fd1603  mov eax, 0x410154
000078c0f8fd1608  mov [r15+0x100], rax
000078c0f8fd160f  jmp 0x000078C0F8DFE110
000078c0f8fd1614  cmp dword ptr [r15+0x318], 0x00
000078c0f8fd161c  jz 0x000078C0F8FD1560
000078c0f8fd1622  nop [rax+rax*1], ax
000078c0f8fd162b  nop [rax+rax*1], eax
000078c0f8fd1633  mov eax, 0x410140
000078c0f8fd1638  mov [r15+0x100], rax
000078c0f8fd163f  jmp 0x000078C0F8DFE110
000078c0f8fd1644  int3
000078c0f8fd1645  call 0x000078C0F8EC3AE0
000078c0f8fd164a  jmp 0x000078C0F8FD1571
000078c0f8fd164f  ucomisd xmm1, xmm15
000078c0f8fd1654  jp 0x000078C0F8FD1663
000078c0f8fd1656  movaps xmm14, [0x000078C0F8BFE030]
000078c0f8fd165e  jmp 0x000078C0F8FD15CD
000078c0f8fd1663  vxorps xmm0, xmm1, xmm15
000078c0f8fd1668  pextrw eax, xmm0, 0x03
000078c0f8fd166d  and eax, 0x7FF8
000078c0f8fd1672  cmp eax, 0x08
000078c0f8fd1675  jnz 0x000078C0F8FD15CD
000078c0f8fd167b  movq rax, xmm15
000078c0f8fd1680  shl rax, 0x0D
000078c0f8fd1684  jbe 0x000078C0F8FD15CD
000078c0f8fd168a  vorps xmm14, xmm15, [0x000078C0F8BFE040]
000078c0f8fd1692  jmp 0x000078C0F8FD15CD
000078c0f8fd1697  int3
000078c0f8fd1698  nop [rax+rax*1], eax
000078c0f8fd16a0  mov rax, [r15+0x40]
000078c0f8fd16a4  lea r14, [rax+0x1B8]
000078c0f8fd16ab  movaps xmm1, [r15+0x110]
000078c0f8fd16b3  movq rax, xmm1
000078c0f8fd16b8  mov [r13+r14*1], rax
000078c0f8fd16bd  mov rax, [r15+0xF0]
000078c0f8fd16c4  mov [r15+0x100], rax
000078c0f8fd16cb  jmp 0x000078C0F8FCE5C0
000078c0f8fd16d0  int3
000078c0f8fd16d1  call 0x000078C0F8ED5EB0
000078c0f8fd16d6  jmp 0x000078C0F8FD16BD
000078c0f8fd16db  int3
000078c0f8fd16dc  nop [rax], eax
000078c0f8fd16e0  mov qword ptr [r15+0x100], 0x04
000078c0f8fd16eb  mov esi, 0x00
000078c0f8fd16f0  mov edx, 0x09
000078c0f8fd16f5  mov rdi, 0x7FFC67CB1A60
000078c0f8fd16ff  mov rax, 0x56241A4CC970
000078c0f8fd1709  call rax
000078c0f8fd170b  cmp dword ptr [r15+0x318], 0x00
000078c0f8fd1713  jnz 0x000078C0F8DFE110
000078c0f8fd1719  jmp 0x000078C0F8DFE0A0
000078c0f8fd171e  int3
000078c0f8fd171f  int3
