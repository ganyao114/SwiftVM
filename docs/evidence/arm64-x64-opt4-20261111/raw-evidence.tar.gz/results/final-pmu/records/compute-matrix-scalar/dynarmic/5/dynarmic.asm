00007e05fe7ce69b  nop [rax+rax*1], eax
00007e05fe7ce6a0  mov qword ptr [r15+0x40], 0x4201C0
00007e05fe7ce6a8  mov qword ptr [r15+0x48], 0x4203C0
00007e05fe7ce6b0  mov qword ptr [r15+0x60], 0x01
00007e05fe7ce6b8  xorps xmm1, xmm1
00007e05fe7ce6bb  mov eax, 0x41
00007e05fe7ce6c0  vcvtusi2sd xmm1, xmm1, eax
00007e05fe7ce6c6  mulsd xmm1, [0x00007E05FE3FE010]
00007e05fe7ce6ce  movq xmm1, xmm1
00007e05fe7ce6d2  movaps [r15+0x120], xmm1
00007e05fe7ce6da  mov eax, [r15+0x60]
00007e05fe7ce6de  xorps xmm15, xmm15
00007e05fe7ce6e2  vcvtusi2sd xmm15, xmm15, eax
00007e05fe7ce6e8  mulsd xmm15, [0x00007E05FE3FE020]
00007e05fe7ce6f1  movq xmm15, xmm15
00007e05fe7ce6f6  movaps [r15+0x110], xmm15
00007e05fe7ce6fe  mov rax, [r15+0x60]
00007e05fe7ce702  mov [rsp+0x10], rax
00007e05fe7ce707  xor eax, eax
00007e05fe7ce709  mov r14, [rsp+0x10]
00007e05fe7ce70e  mov r12d, 0x40
00007e05fe7ce714  cmp r14, r12
00007e05fe7ce717  cmc
00007e05fe7ce718  lahf
00007e05fe7ce719  seto al
00007e05fe7ce71c  mov [r15+0x108], eax
00007e05fe7ce723  mov qword ptr [r15+0x50], 0x40
00007e05fe7ce72b  movq rax, xmm1
00007e05fe7ce730  mov r12d, 0x4203C0
00007e05fe7ce736  mov [r13+r12*1], rax
00007e05fe7ce73b  movq rax, xmm15
00007e05fe7ce740  mov r12d, 0x4201C0
00007e05fe7ce746  mov [r13+r12*1], rax
00007e05fe7ce74b  mov [r15+0x58], r14
00007e05fe7ce74f  mov eax, [r15+0x108]
00007e05fe7ce756  sahf
00007e05fe7ce757  jnz 0x00007E05FE7CE789
00007e05fe7ce759  cmp dword ptr [r15+0x318], 0x00
00007e05fe7ce761  jz 0x00007E05FE7CE910
00007e05fe7ce767  nop [rax+rax*1], ax
00007e05fe7ce770  nop [rax+rax*1], eax
00007e05fe7ce778  mov eax, 0x410074
00007e05fe7ce77d  mov [r15+0x100], rax
00007e05fe7ce784  jmp 0x00007E05FE5FE110
00007e05fe7ce789  cmp dword ptr [r15+0x318], 0x00
00007e05fe7ce791  jz 0x00007E05FE7CE7D0
00007e05fe7ce797  nop [rax+rax*1], ax
00007e05fe7ce7a0  nop [rax+rax*1], eax
00007e05fe7ce7a8  mov eax, 0x41004C
00007e05fe7ce7ad  mov [r15+0x100], rax
00007e05fe7ce7b4  jmp 0x00007E05FE5FE110
00007e05fe7ce7b9  int3
00007e05fe7ce7ba  call 0x00007E05FE6B4CB0
00007e05fe7ce7bf  jmp 0x00007E05FE7CE73B
00007e05fe7ce7c4  call 0x00007E05FE6B4CB0
00007e05fe7ce7c9  jmp 0x00007E05FE7CE74B
00007e05fe7ce7ce  int3
00007e05fe7ce7cf  nop
00007e05fe7ce7d0  mov rax, [r15+0x58]
00007e05fe7ce7d4  lea r14, [rax+0x01]
00007e05fe7ce7d8  mov [r15+0x60], r14
00007e05fe7ce7dc  mov r14d, [r15+0x50]
00007e05fe7ce7e0  xorps xmm1, xmm1
00007e05fe7ce7e3  vcvtusi2sd xmm1, xmm1, r14d
00007e05fe7ce7e9  mulsd xmm1, [0x00007E05FE3FE010]
00007e05fe7ce7f1  movq xmm1, xmm1
00007e05fe7ce7f5  movaps [r15+0x120], xmm1
00007e05fe7ce7fd  rorx r12, rax, 0x3D
00007e05fe7ce803  and r12, 0xFFFFFFFFFFFFFFF8
00007e05fe7ce807  mov eax, [r15+0x60]
00007e05fe7ce80b  xorps xmm15, xmm15
00007e05fe7ce80f  vcvtusi2sd xmm15, xmm15, eax
00007e05fe7ce815  mulsd xmm15, [0x00007E05FE3FE020]
00007e05fe7ce81e  movq xmm15, xmm15
00007e05fe7ce823  movaps [r15+0x110], xmm15
00007e05fe7ce82b  mov rax, [r15+0x60]
00007e05fe7ce82f  mov [rsp+0x10], rax
00007e05fe7ce834  xor eax, eax
00007e05fe7ce836  mov r11, [rsp+0x10]
00007e05fe7ce83b  mov r10d, 0x40
00007e05fe7ce841  cmp r11, r10
00007e05fe7ce844  cmc
00007e05fe7ce845  lahf
00007e05fe7ce846  seto al
00007e05fe7ce849  mov [r15+0x108], eax
00007e05fe7ce850  lea eax, [r14d-0x01]
00007e05fe7ce855  mov eax, eax
00007e05fe7ce857  mov [r15+0x50], rax
00007e05fe7ce85b  mov rax, [r15+0x48]
00007e05fe7ce85f  lea r14, [rax+r12*1]
00007e05fe7ce863  movq rax, xmm1
00007e05fe7ce868  mov [r13+r14*1], rax
00007e05fe7ce86d  mov rax, [r15+0x40]
00007e05fe7ce871  lea r14, [rax+r12*1]
00007e05fe7ce875  movq rax, xmm15
00007e05fe7ce87a  mov [r13+r14*1], rax
00007e05fe7ce87f  mov [r15+0x58], r11
00007e05fe7ce883  mov eax, [r15+0x108]
00007e05fe7ce88a  sahf
00007e05fe7ce88b  jnz 0x00007E05FE7CE8BD
00007e05fe7ce88d  cmp dword ptr [r15+0x318], 0x00
00007e05fe7ce895  jz 0x00007E05FE7CE910
00007e05fe7ce89b  nop [rax+rax*1], ax
00007e05fe7ce8a4  nop [rax+rax*1], eax
00007e05fe7ce8ac  mov eax, 0x410074
00007e05fe7ce8b1  mov [r15+0x100], rax
00007e05fe7ce8b8  jmp 0x00007E05FE5FE110
00007e05fe7ce8bd  cmp dword ptr [r15+0x318], 0x00
00007e05fe7ce8c5  jz 0x00007E05FE7CE7D0
00007e05fe7ce8cb  nop [rax+rax*1], ax
00007e05fe7ce8d4  nop [rax+rax*1], eax
00007e05fe7ce8dc  mov eax, 0x41004C
00007e05fe7ce8e1  mov [r15+0x100], rax
00007e05fe7ce8e8  jmp 0x00007E05FE5FE110
00007e05fe7ce8ed  int3
00007e05fe7ce8ee  call 0x00007E05FE6D5EB0
00007e05fe7ce8f3  jmp 0x00007E05FE7CE86D
00007e05fe7ce8f8  call 0x00007E05FE6D5EB0
00007e05fe7ce8fd  jmp 0x00007E05FE7CE87F
00007e05fe7ce902  int3
00007e05fe7ce903  nop [rax+rax*1], ax
00007e05fe7ce90c  nop [rax], eax
00007e05fe7ce910  vxorps xmm1, xmm1, xmm1
00007e05fe7ce914  movq xmm1, xmm1
00007e05fe7ce918  movaps [r15+0x110], xmm1
00007e05fe7ce920  mov qword ptr [r15+0x58], 0x00
00007e05fe7ce928  mov qword ptr [r15+0x50], 0x4205C0
00007e05fe7ce930  mov qword ptr [r15+0x60], 0x00
00007e05fe7ce938  mov qword ptr [r15+0x68], 0x4205C0
00007e05fe7ce940  mov rax, [r15+0x40]
00007e05fe7ce944  mov r14, [r13+rax*1]
00007e05fe7ce949  lea r12, [rax+0x08]
00007e05fe7ce94d  mov r11, [r13+r12*1]
00007e05fe7ce952  movq xmm15, r14
00007e05fe7ce957  movq xmm14, r11
00007e05fe7ce95c  movq xmm15, xmm15
00007e05fe7ce961  movq xmm15, xmm15
00007e05fe7ce966  movaps [r15+0x120], xmm15
00007e05fe7ce96e  movq xmm14, xmm14
00007e05fe7ce973  movq xmm14, xmm14
00007e05fe7ce978  movaps [r15+0x130], xmm14
00007e05fe7ce980  lea r14, [rax+0x10]
00007e05fe7ce984  mov r12, [r13+r14*1]
00007e05fe7ce989  lea r14, [rax+0x18]
00007e05fe7ce98d  mov r11, [r13+r14*1]
00007e05fe7ce992  movq xmm15, r12
00007e05fe7ce997  movq xmm14, r11
00007e05fe7ce99c  movq xmm15, xmm15
00007e05fe7ce9a1  movq xmm15, xmm15
00007e05fe7ce9a6  movaps [r15+0x140], xmm15
00007e05fe7ce9ae  movq xmm14, xmm14
00007e05fe7ce9b3  movq xmm14, xmm14
00007e05fe7ce9b8  movaps [r15+0x150], xmm14
00007e05fe7ce9c0  lea r14, [rax+0x20]
00007e05fe7ce9c4  mov r12, [r13+r14*1]
00007e05fe7ce9c9  lea r14, [rax+0x28]
00007e05fe7ce9cd  mov r11, [r13+r14*1]
00007e05fe7ce9d2  movq xmm15, r12
00007e05fe7ce9d7  movq xmm14, r11
00007e05fe7ce9dc  movq xmm15, xmm15
00007e05fe7ce9e1  movq xmm15, xmm15
00007e05fe7ce9e6  movaps [r15+0x160], xmm15
00007e05fe7ce9ee  movq xmm14, xmm14
00007e05fe7ce9f3  movq xmm14, xmm14
00007e05fe7ce9f8  movaps [r15+0x170], xmm14
00007e05fe7cea00  lea r14, [rax+0x30]
00007e05fe7cea04  mov r12, [r13+r14*1]
00007e05fe7cea09  lea r14, [rax+0x38]
00007e05fe7cea0d  mov rax, [r13+r14*1]
00007e05fe7cea12  movq xmm15, r12
00007e05fe7cea17  movq xmm14, rax
00007e05fe7cea1c  movq xmm15, xmm15
00007e05fe7cea21  movq xmm15, xmm15
00007e05fe7cea26  movaps [r15+0x180], xmm15
00007e05fe7cea2e  movq xmm14, xmm14
00007e05fe7cea33  movq xmm14, xmm14
00007e05fe7cea38  movaps [r15+0x210], xmm14
00007e05fe7cea40  mov rax, [r15+0x48]
00007e05fe7cea44  mov [r15+0x78], rax
00007e05fe7cea48  mov r14, [r13+rax*1]
00007e05fe7cea4d  movq xmm15, r14
00007e05fe7cea52  lea r14, [rax+0x40]
00007e05fe7cea56  mov r12, [r13+r14*1]
00007e05fe7cea5b  movq xmm14, r12
00007e05fe7cea60  lea r14, [rax+0x80]
00007e05fe7cea67  mov r12, [r13+r14*1]
00007e05fe7cea6c  movq xmm13, r12
00007e05fe7cea71  movaps xmm12, [r15+0x120]
00007e05fe7cea79  movq r14, xmm12
00007e05fe7cea7e  movq r12, xmm15
00007e05fe7cea83  vmovq xmm15, r14
00007e05fe7cea88  vmovq xmm12, r12
00007e05fe7cea8d  movaps xmm11, xmm15
00007e05fe7cea91  mulsd xmm11, xmm12
00007e05fe7cea96  ucomisd xmm11, xmm11
00007e05fe7cea9b  jp 0x00007E05FE7CEEFC
00007e05fe7ceaa1  movq xmm11, xmm11
00007e05fe7ceaa6  movaps xmm15, [r15+0x130]
00007e05fe7ceaae  movq r14, xmm15
00007e05fe7ceab3  movq r12, xmm14
00007e05fe7ceab8  vmovq xmm15, r14
00007e05fe7ceabd  vmovq xmm14, r12
00007e05fe7ceac2  movaps xmm12, xmm15
00007e05fe7ceac6  mulsd xmm12, xmm14
00007e05fe7ceacb  ucomisd xmm12, xmm12
00007e05fe7cead0  jp 0x00007E05FE7CEF48
00007e05fe7cead6  movq xmm12, xmm12
00007e05fe7ceadb  movq r14, xmm11
00007e05fe7ceae0  movq r12, xmm1
00007e05fe7ceae5  vmovq xmm1, r14
00007e05fe7ceaea  vmovq xmm15, r12
00007e05fe7ceaef  movaps xmm14, xmm1
00007e05fe7ceaf3  addsd xmm14, xmm15
00007e05fe7ceaf8  ucomisd xmm14, xmm14
00007e05fe7ceafd  jp 0x00007E05FE7CEF94
00007e05fe7ceb03  movq xmm14, xmm14
00007e05fe7ceb08  movq r14, xmm14
00007e05fe7ceb0d  movq r12, xmm12
00007e05fe7ceb12  vmovq xmm1, r14
00007e05fe7ceb17  vmovq xmm15, r12
00007e05fe7ceb1c  movaps xmm14, xmm1
00007e05fe7ceb20  addsd xmm14, xmm15
00007e05fe7ceb25  ucomisd xmm14, xmm14
00007e05fe7ceb2a  jp 0x00007E05FE7CEFE0
00007e05fe7ceb30  movq xmm14, xmm14
00007e05fe7ceb35  movaps xmm1, [r15+0x140]
00007e05fe7ceb3d  movq r14, xmm1
00007e05fe7ceb42  movq r12, xmm13
00007e05fe7ceb47  vmovq xmm1, r14
00007e05fe7ceb4c  vmovq xmm15, r12
00007e05fe7ceb51  movaps xmm13, xmm1
00007e05fe7ceb55  mulsd xmm13, xmm15
00007e05fe7ceb5a  ucomisd xmm13, xmm13
00007e05fe7ceb5f  jp 0x00007E05FE7CF02C
00007e05fe7ceb65  movq xmm13, xmm13
00007e05fe7ceb6a  lea r14, [rax+0xC0]
00007e05fe7ceb71  mov r12, [r13+r14*1]
00007e05fe7ceb76  movq xmm1, r12
00007e05fe7ceb7b  movq r14, xmm14
00007e05fe7ceb80  movq r12, xmm13
00007e05fe7ceb85  vmovq xmm15, r14
00007e05fe7ceb8a  vmovq xmm14, r12
00007e05fe7ceb8f  movaps xmm13, xmm15
00007e05fe7ceb93  addsd xmm13, xmm14
00007e05fe7ceb98  ucomisd xmm13, xmm13
00007e05fe7ceb9d  jp 0x00007E05FE7CF082
00007e05fe7ceba3  movq xmm13, xmm13
00007e05fe7ceba8  movaps xmm15, [r15+0x150]
00007e05fe7cebb0  movq r14, xmm15
00007e05fe7cebb5  movq r12, xmm1
00007e05fe7cebba  vmovq xmm1, r14
00007e05fe7cebbf  vmovq xmm15, r12
00007e05fe7cebc4  movaps xmm14, xmm1
00007e05fe7cebc8  mulsd xmm14, xmm15
00007e05fe7cebcd  ucomisd xmm14, xmm14
00007e05fe7cebd2  jp 0x00007E05FE7CF0CE
00007e05fe7cebd8  movq xmm14, xmm14
00007e05fe7cebdd  lea r14, [rax+0x100]
00007e05fe7cebe4  mov r12, [r13+r14*1]
00007e05fe7cebe9  movq xmm1, r12
00007e05fe7cebee  movq r14, xmm13
00007e05fe7cebf3  movq r12, xmm14
00007e05fe7cebf8  vmovq xmm15, r14
00007e05fe7cebfd  vmovq xmm14, r12
00007e05fe7cec02  movaps xmm13, xmm15
00007e05fe7cec06  addsd xmm13, xmm14
00007e05fe7cec0b  ucomisd xmm13, xmm13
00007e05fe7cec10  jp 0x00007E05FE7CF124
00007e05fe7cec16  movq xmm13, xmm13
00007e05fe7cec1b  movaps xmm15, [r15+0x160]
00007e05fe7cec23  movq r14, xmm15
00007e05fe7cec28  movq r12, xmm1
00007e05fe7cec2d  vmovq xmm1, r14
00007e05fe7cec32  vmovq xmm15, r12
00007e05fe7cec37  movaps xmm14, xmm1
00007e05fe7cec3b  mulsd xmm14, xmm15
00007e05fe7cec40  ucomisd xmm14, xmm14
00007e05fe7cec45  jp 0x00007E05FE7CF170
00007e05fe7cec4b  movq xmm14, xmm14
00007e05fe7cec50  lea r14, [rax+0x140]
00007e05fe7cec57  mov r12, [r13+r14*1]
00007e05fe7cec5c  movq xmm1, r12
00007e05fe7cec61  movq r14, xmm13
00007e05fe7cec66  movq r12, xmm14
00007e05fe7cec6b  vmovq xmm15, r14
00007e05fe7cec70  vmovq xmm14, r12
00007e05fe7cec75  movaps xmm13, xmm15
00007e05fe7cec79  addsd xmm13, xmm14
00007e05fe7cec7e  ucomisd xmm13, xmm13
00007e05fe7cec83  jp 0x00007E05FE7CF1C6
00007e05fe7cec89  movq xmm13, xmm13
00007e05fe7cec8e  movaps xmm15, [r15+0x170]
00007e05fe7cec96  movq r14, xmm15
00007e05fe7cec9b  movq r12, xmm1
00007e05fe7ceca0  vmovq xmm1, r14
00007e05fe7ceca5  vmovq xmm15, r12
00007e05fe7cecaa  movaps xmm14, xmm1
00007e05fe7cecae  mulsd xmm14, xmm15
00007e05fe7cecb3  ucomisd xmm14, xmm14
00007e05fe7cecb8  jp 0x00007E05FE7CF212
00007e05fe7cecbe  movq xmm14, xmm14
00007e05fe7cecc3  lea r14, [rax+0x180]
00007e05fe7cecca  mov r12, [r13+r14*1]
00007e05fe7ceccf  movq xmm1, r12
00007e05fe7cecd4  movq r14, xmm13
00007e05fe7cecd9  movq r12, xmm14
00007e05fe7cecde  vmovq xmm15, r14
00007e05fe7cece3  vmovq xmm14, r12
00007e05fe7cece8  movaps xmm13, xmm15
00007e05fe7cecec  addsd xmm13, xmm14
00007e05fe7cecf1  ucomisd xmm13, xmm13
00007e05fe7cecf6  jp 0x00007E05FE7CF268
00007e05fe7cecfc  movq xmm13, xmm13
00007e05fe7ced01  movaps xmm15, [r15+0x180]
00007e05fe7ced09  movq r14, xmm15
00007e05fe7ced0e  movq r12, xmm1
00007e05fe7ced13  vmovq xmm1, r14
00007e05fe7ced18  vmovq xmm15, r12
00007e05fe7ced1d  movaps xmm14, xmm1
00007e05fe7ced21  mulsd xmm14, xmm15
00007e05fe7ced26  ucomisd xmm14, xmm14
00007e05fe7ced2b  jp 0x00007E05FE7CF2B4
00007e05fe7ced31  movq xmm14, xmm14
00007e05fe7ced36  lea r14, [rax+0x1C0]
00007e05fe7ced3d  mov rax, [r13+r14*1]
00007e05fe7ced42  movq xmm1, rax
00007e05fe7ced47  movaps [r15+0x240], xmm1
00007e05fe7ced4f  movq rax, xmm13
00007e05fe7ced54  movq r14, xmm14
00007e05fe7ced59  vmovq xmm15, rax
00007e05fe7ced5e  vmovq xmm14, r14
00007e05fe7ced63  movaps xmm13, xmm15
00007e05fe7ced67  addsd xmm13, xmm14
00007e05fe7ced6c  ucomisd xmm13, xmm13
00007e05fe7ced71  jp 0x00007E05FE7CF30A
00007e05fe7ced77  movq xmm13, xmm13
00007e05fe7ced7c  movaps xmm15, [r15+0x210]
00007e05fe7ced84  movq rax, xmm15
00007e05fe7ced89  movq r14, xmm1
00007e05fe7ced8e  vmovq xmm1, rax
00007e05fe7ced93  vmovq xmm15, r14
00007e05fe7ced98  movaps xmm14, xmm1
00007e05fe7ced9c  mulsd xmm14, xmm15
00007e05fe7ceda1  ucomisd xmm14, xmm14
00007e05fe7ceda6  jp 0x00007E05FE7CF352
00007e05fe7cedac  movq xmm14, xmm14
00007e05fe7cedb1  movaps [r15+0x230], xmm14
00007e05fe7cedb9  movq rax, xmm13
00007e05fe7cedbe  movq r14, xmm14
00007e05fe7cedc3  vmovq xmm1, rax
00007e05fe7cedc8  vmovq xmm15, r14
00007e05fe7cedcd  movaps xmm14, xmm1
00007e05fe7cedd1  addsd xmm14, xmm15
00007e05fe7cedd6  ucomisd xmm14, xmm14
00007e05fe7ceddb  jp 0x00007E05FE7CF39A
00007e05fe7cede1  movq xmm14, xmm14
00007e05fe7cede6  movaps [r15+0x220], xmm14
00007e05fe7cedee  movq rax, xmm14
00007e05fe7cedf3  mov r14d, 0x4205C0
00007e05fe7cedf9  mov [r13+r14*1], rax
00007e05fe7cedfe  mov qword ptr [r15+0x70], 0x08
00007e05fe7cee06  xor eax, eax
00007e05fe7cee08  mov r14d, 0x08
00007e05fe7cee0e  mov r12d, 0x40
00007e05fe7cee14  cmp r14, r12
00007e05fe7cee17  cmc
00007e05fe7cee18  lahf
00007e05fe7cee19  seto al
00007e05fe7cee1c  mov [r15+0x108], eax
00007e05fe7cee23  mov eax, [r15+0x108]
00007e05fe7cee2a  sahf
00007e05fe7cee2b  jnz 0x00007E05FE7CEE5D
00007e05fe7cee2d  cmp dword ptr [r15+0x318], 0x00
00007e05fe7cee35  jz 0x00007E05FE7CFD40
00007e05fe7cee3b  nop [rax+rax*1], ax
00007e05fe7cee44  nop [rax+rax*1], eax
00007e05fe7cee4c  mov eax, 0x410118
00007e05fe7cee51  mov [r15+0x100], rax
00007e05fe7cee58  jmp 0x00007E05FE5FE110
00007e05fe7cee5d  cmp dword ptr [r15+0x318], 0x00
00007e05fe7cee65  jz 0x00007E05FE7CF3F0
00007e05fe7cee6b  nop [rax+rax*1], ax
00007e05fe7cee74  nop [rax+rax*1], eax
00007e05fe7cee7c  mov eax, 0x4100A4
00007e05fe7cee81  mov [r15+0x100], rax
00007e05fe7cee88  jmp 0x00007E05FE5FE110
00007e05fe7cee8d  int3
00007e05fe7cee8e  call 0x00007E05FE60DC20
00007e05fe7cee93  jmp 0x00007E05FE7CE949
00007e05fe7cee98  call 0x00007E05FE6C0370
00007e05fe7cee9d  jmp 0x00007E05FE7CE952
00007e05fe7ceea2  call 0x00007E05FE6E27E0
00007e05fe7ceea7  jmp 0x00007E05FE7CE989
00007e05fe7ceeac  call 0x00007E05FE6E1570
00007e05fe7ceeb1  jmp 0x00007E05FE7CE992
00007e05fe7ceeb6  call 0x00007E05FE6E27E0
00007e05fe7ceebb  jmp 0x00007E05FE7CE9C9
00007e05fe7ceec0  call 0x00007E05FE6E1570
00007e05fe7ceec5  jmp 0x00007E05FE7CE9D2
00007e05fe7ceeca  call 0x00007E05FE6E27E0
00007e05fe7ceecf  jmp 0x00007E05FE7CEA09
00007e05fe7ceed4  call 0x00007E05FE6D59C0
00007e05fe7ceed9  jmp 0x00007E05FE7CEA12
00007e05fe7ceede  call 0x00007E05FE60DC20
00007e05fe7ceee3  jmp 0x00007E05FE7CEA4D
00007e05fe7ceee8  call 0x00007E05FE6E27E0
00007e05fe7ceeed  jmp 0x00007E05FE7CEA5B
00007e05fe7ceef2  call 0x00007E05FE6E27E0
00007e05fe7ceef7  jmp 0x00007E05FE7CEA6C
00007e05fe7ceefc  ucomisd xmm15, xmm12
00007e05fe7cef01  jp 0x00007E05FE7CEF10
00007e05fe7cef03  movaps xmm11, [0x00007E05FE3FE030]
00007e05fe7cef0b  jmp 0x00007E05FE7CEAA1
00007e05fe7cef10  vxorps xmm0, xmm15, xmm12
00007e05fe7cef15  pextrw r14d, xmm0, 0x03
00007e05fe7cef1b  and r14d, 0x7FF8
00007e05fe7cef22  cmp r14d, 0x08
00007e05fe7cef26  jnz 0x00007E05FE7CEAA1
00007e05fe7cef2c  movq r14, xmm12
00007e05fe7cef31  shl r14, 0x0D
00007e05fe7cef35  jbe 0x00007E05FE7CEAA1
00007e05fe7cef3b  vorps xmm11, xmm12, [0x00007E05FE3FE040]
00007e05fe7cef43  jmp 0x00007E05FE7CEAA1
00007e05fe7cef48  ucomisd xmm15, xmm14
00007e05fe7cef4d  jp 0x00007E05FE7CEF5C
00007e05fe7cef4f  movaps xmm12, [0x00007E05FE3FE030]
00007e05fe7cef57  jmp 0x00007E05FE7CEAD6
00007e05fe7cef5c  vxorps xmm0, xmm15, xmm14
00007e05fe7cef61  pextrw r14d, xmm0, 0x03
00007e05fe7cef67  and r14d, 0x7FF8
00007e05fe7cef6e  cmp r14d, 0x08
00007e05fe7cef72  jnz 0x00007E05FE7CEAD6
00007e05fe7cef78  movq r14, xmm14
00007e05fe7cef7d  shl r14, 0x0D
00007e05fe7cef81  jbe 0x00007E05FE7CEAD6
00007e05fe7cef87  vorps xmm12, xmm14, [0x00007E05FE3FE040]
00007e05fe7cef8f  jmp 0x00007E05FE7CEAD6
00007e05fe7cef94  ucomisd xmm1, xmm15
00007e05fe7cef99  jp 0x00007E05FE7CEFA8
00007e05fe7cef9b  movaps xmm14, [0x00007E05FE3FE030]
00007e05fe7cefa3  jmp 0x00007E05FE7CEB03
00007e05fe7cefa8  vxorps xmm0, xmm1, xmm15
00007e05fe7cefad  pextrw r14d, xmm0, 0x03
00007e05fe7cefb3  and r14d, 0x7FF8
00007e05fe7cefba  cmp r14d, 0x08
00007e05fe7cefbe  jnz 0x00007E05FE7CEB03
00007e05fe7cefc4  movq r14, xmm15
00007e05fe7cefc9  shl r14, 0x0D
00007e05fe7cefcd  jbe 0x00007E05FE7CEB03
00007e05fe7cefd3  vorps xmm14, xmm15, [0x00007E05FE3FE040]
00007e05fe7cefdb  jmp 0x00007E05FE7CEB03
00007e05fe7cefe0  ucomisd xmm1, xmm15
00007e05fe7cefe5  jp 0x00007E05FE7CEFF4
00007e05fe7cefe7  movaps xmm14, [0x00007E05FE3FE030]
00007e05fe7cefef  jmp 0x00007E05FE7CEB30
00007e05fe7ceff4  vxorps xmm0, xmm1, xmm15
00007e05fe7ceff9  pextrw r14d, xmm0, 0x03
00007e05fe7cefff  and r14d, 0x7FF8
00007e05fe7cf006  cmp r14d, 0x08
00007e05fe7cf00a  jnz 0x00007E05FE7CEB30
00007e05fe7cf010  movq r14, xmm15
00007e05fe7cf015  shl r14, 0x0D
00007e05fe7cf019  jbe 0x00007E05FE7CEB30
00007e05fe7cf01f  vorps xmm14, xmm15, [0x00007E05FE3FE040]
00007e05fe7cf027  jmp 0x00007E05FE7CEB30
00007e05fe7cf02c  ucomisd xmm1, xmm15
00007e05fe7cf031  jp 0x00007E05FE7CF040
00007e05fe7cf033  movaps xmm13, [0x00007E05FE3FE030]
00007e05fe7cf03b  jmp 0x00007E05FE7CEB65
00007e05fe7cf040  vxorps xmm0, xmm1, xmm15
00007e05fe7cf045  pextrw r14d, xmm0, 0x03
00007e05fe7cf04b  and r14d, 0x7FF8
00007e05fe7cf052  cmp r14d, 0x08
00007e05fe7cf056  jnz 0x00007E05FE7CEB65
00007e05fe7cf05c  movq r14, xmm15
00007e05fe7cf061  shl r14, 0x0D
00007e05fe7cf065  jbe 0x00007E05FE7CEB65
00007e05fe7cf06b  vorps xmm13, xmm15, [0x00007E05FE3FE040]
00007e05fe7cf073  jmp 0x00007E05FE7CEB65
00007e05fe7cf078  call 0x00007E05FE6E27E0
00007e05fe7cf07d  jmp 0x00007E05FE7CEB76
00007e05fe7cf082  ucomisd xmm15, xmm14
00007e05fe7cf087  jp 0x00007E05FE7CF096
00007e05fe7cf089  movaps xmm13, [0x00007E05FE3FE030]
00007e05fe7cf091  jmp 0x00007E05FE7CEBA3
00007e05fe7cf096  vxorps xmm0, xmm15, xmm14
00007e05fe7cf09b  pextrw r14d, xmm0, 0x03
00007e05fe7cf0a1  and r14d, 0x7FF8
00007e05fe7cf0a8  cmp r14d, 0x08
00007e05fe7cf0ac  jnz 0x00007E05FE7CEBA3
00007e05fe7cf0b2  movq r14, xmm14
00007e05fe7cf0b7  shl r14, 0x0D
00007e05fe7cf0bb  jbe 0x00007E05FE7CEBA3
00007e05fe7cf0c1  vorps xmm13, xmm14, [0x00007E05FE3FE040]
00007e05fe7cf0c9  jmp 0x00007E05FE7CEBA3
00007e05fe7cf0ce  ucomisd xmm1, xmm15
00007e05fe7cf0d3  jp 0x00007E05FE7CF0E2
00007e05fe7cf0d5  movaps xmm14, [0x00007E05FE3FE030]
00007e05fe7cf0dd  jmp 0x00007E05FE7CEBD8
00007e05fe7cf0e2  vxorps xmm0, xmm1, xmm15
00007e05fe7cf0e7  pextrw r14d, xmm0, 0x03
00007e05fe7cf0ed  and r14d, 0x7FF8
00007e05fe7cf0f4  cmp r14d, 0x08
00007e05fe7cf0f8  jnz 0x00007E05FE7CEBD8
00007e05fe7cf0fe  movq r14, xmm15
00007e05fe7cf103  shl r14, 0x0D
00007e05fe7cf107  jbe 0x00007E05FE7CEBD8
00007e05fe7cf10d  vorps xmm14, xmm15, [0x00007E05FE3FE040]
00007e05fe7cf115  jmp 0x00007E05FE7CEBD8
00007e05fe7cf11a  call 0x00007E05FE6E27E0
00007e05fe7cf11f  jmp 0x00007E05FE7CEBE9
00007e05fe7cf124  ucomisd xmm15, xmm14
00007e05fe7cf129  jp 0x00007E05FE7CF138
00007e05fe7cf12b  movaps xmm13, [0x00007E05FE3FE030]
00007e05fe7cf133  jmp 0x00007E05FE7CEC16
00007e05fe7cf138  vxorps xmm0, xmm15, xmm14
00007e05fe7cf13d  pextrw r14d, xmm0, 0x03
00007e05fe7cf143  and r14d, 0x7FF8
00007e05fe7cf14a  cmp r14d, 0x08
00007e05fe7cf14e  jnz 0x00007E05FE7CEC16
00007e05fe7cf154  movq r14, xmm14
00007e05fe7cf159  shl r14, 0x0D
00007e05fe7cf15d  jbe 0x00007E05FE7CEC16
00007e05fe7cf163  vorps xmm13, xmm14, [0x00007E05FE3FE040]
00007e05fe7cf16b  jmp 0x00007E05FE7CEC16
00007e05fe7cf170  ucomisd xmm1, xmm15
00007e05fe7cf175  jp 0x00007E05FE7CF184
00007e05fe7cf177  movaps xmm14, [0x00007E05FE3FE030]
00007e05fe7cf17f  jmp 0x00007E05FE7CEC4B
00007e05fe7cf184  vxorps xmm0, xmm1, xmm15
00007e05fe7cf189  pextrw r14d, xmm0, 0x03
00007e05fe7cf18f  and r14d, 0x7FF8
00007e05fe7cf196  cmp r14d, 0x08
00007e05fe7cf19a  jnz 0x00007E05FE7CEC4B
00007e05fe7cf1a0  movq r14, xmm15
00007e05fe7cf1a5  shl r14, 0x0D
00007e05fe7cf1a9  jbe 0x00007E05FE7CEC4B
00007e05fe7cf1af  vorps xmm14, xmm15, [0x00007E05FE3FE040]
00007e05fe7cf1b7  jmp 0x00007E05FE7CEC4B
00007e05fe7cf1bc  call 0x00007E05FE6E27E0
00007e05fe7cf1c1  jmp 0x00007E05FE7CEC5C
00007e05fe7cf1c6  ucomisd xmm15, xmm14
00007e05fe7cf1cb  jp 0x00007E05FE7CF1DA
00007e05fe7cf1cd  movaps xmm13, [0x00007E05FE3FE030]
00007e05fe7cf1d5  jmp 0x00007E05FE7CEC89
00007e05fe7cf1da  vxorps xmm0, xmm15, xmm14
00007e05fe7cf1df  pextrw r14d, xmm0, 0x03
00007e05fe7cf1e5  and r14d, 0x7FF8
00007e05fe7cf1ec  cmp r14d, 0x08
00007e05fe7cf1f0  jnz 0x00007E05FE7CEC89
00007e05fe7cf1f6  movq r14, xmm14
00007e05fe7cf1fb  shl r14, 0x0D
00007e05fe7cf1ff  jbe 0x00007E05FE7CEC89
00007e05fe7cf205  vorps xmm13, xmm14, [0x00007E05FE3FE040]
00007e05fe7cf20d  jmp 0x00007E05FE7CEC89
00007e05fe7cf212  ucomisd xmm1, xmm15
00007e05fe7cf217  jp 0x00007E05FE7CF226
00007e05fe7cf219  movaps xmm14, [0x00007E05FE3FE030]
00007e05fe7cf221  jmp 0x00007E05FE7CECBE
00007e05fe7cf226  vxorps xmm0, xmm1, xmm15
00007e05fe7cf22b  pextrw r14d, xmm0, 0x03
00007e05fe7cf231  and r14d, 0x7FF8
00007e05fe7cf238  cmp r14d, 0x08
00007e05fe7cf23c  jnz 0x00007E05FE7CECBE
00007e05fe7cf242  movq r14, xmm15
00007e05fe7cf247  shl r14, 0x0D
00007e05fe7cf24b  jbe 0x00007E05FE7CECBE
00007e05fe7cf251  vorps xmm14, xmm15, [0x00007E05FE3FE040]
00007e05fe7cf259  jmp 0x00007E05FE7CECBE
00007e05fe7cf25e  call 0x00007E05FE6E27E0
00007e05fe7cf263  jmp 0x00007E05FE7CECCF
00007e05fe7cf268  ucomisd xmm15, xmm14
00007e05fe7cf26d  jp 0x00007E05FE7CF27C
00007e05fe7cf26f  movaps xmm13, [0x00007E05FE3FE030]
00007e05fe7cf277  jmp 0x00007E05FE7CECFC
00007e05fe7cf27c  vxorps xmm0, xmm15, xmm14
00007e05fe7cf281  pextrw r14d, xmm0, 0x03
00007e05fe7cf287  and r14d, 0x7FF8
00007e05fe7cf28e  cmp r14d, 0x08
00007e05fe7cf292  jnz 0x00007E05FE7CECFC
00007e05fe7cf298  movq r14, xmm14
00007e05fe7cf29d  shl r14, 0x0D
00007e05fe7cf2a1  jbe 0x00007E05FE7CECFC
00007e05fe7cf2a7  vorps xmm13, xmm14, [0x00007E05FE3FE040]
00007e05fe7cf2af  jmp 0x00007E05FE7CECFC
00007e05fe7cf2b4  ucomisd xmm1, xmm15
00007e05fe7cf2b9  jp 0x00007E05FE7CF2C8
00007e05fe7cf2bb  movaps xmm14, [0x00007E05FE3FE030]
00007e05fe7cf2c3  jmp 0x00007E05FE7CED31
00007e05fe7cf2c8  vxorps xmm0, xmm1, xmm15
00007e05fe7cf2cd  pextrw r14d, xmm0, 0x03
00007e05fe7cf2d3  and r14d, 0x7FF8
00007e05fe7cf2da  cmp r14d, 0x08
00007e05fe7cf2de  jnz 0x00007E05FE7CED31
00007e05fe7cf2e4  movq r14, xmm15
00007e05fe7cf2e9  shl r14, 0x0D
00007e05fe7cf2ed  jbe 0x00007E05FE7CED31
00007e05fe7cf2f3  vorps xmm14, xmm15, [0x00007E05FE3FE040]
00007e05fe7cf2fb  jmp 0x00007E05FE7CED31
00007e05fe7cf300  call 0x00007E05FE6D59C0
00007e05fe7cf305  jmp 0x00007E05FE7CED42
00007e05fe7cf30a  ucomisd xmm15, xmm14
00007e05fe7cf30f  jp 0x00007E05FE7CF31E
00007e05fe7cf311  movaps xmm13, [0x00007E05FE3FE030]
00007e05fe7cf319  jmp 0x00007E05FE7CED77
00007e05fe7cf31e  vxorps xmm0, xmm15, xmm14
00007e05fe7cf323  pextrw eax, xmm0, 0x03
00007e05fe7cf328  and eax, 0x7FF8
00007e05fe7cf32d  cmp eax, 0x08
00007e05fe7cf330  jnz 0x00007E05FE7CED77
00007e05fe7cf336  movq rax, xmm14
00007e05fe7cf33b  shl rax, 0x0D
00007e05fe7cf33f  jbe 0x00007E05FE7CED77
00007e05fe7cf345  vorps xmm13, xmm14, [0x00007E05FE3FE040]
00007e05fe7cf34d  jmp 0x00007E05FE7CED77
00007e05fe7cf352  ucomisd xmm1, xmm15
00007e05fe7cf357  jp 0x00007E05FE7CF366
00007e05fe7cf359  movaps xmm14, [0x00007E05FE3FE030]
00007e05fe7cf361  jmp 0x00007E05FE7CEDAC
00007e05fe7cf366  vxorps xmm0, xmm1, xmm15
00007e05fe7cf36b  pextrw eax, xmm0, 0x03
00007e05fe7cf370  and eax, 0x7FF8
00007e05fe7cf375  cmp eax, 0x08
00007e05fe7cf378  jnz 0x00007E05FE7CEDAC
00007e05fe7cf37e  movq rax, xmm15
00007e05fe7cf383  shl rax, 0x0D
00007e05fe7cf387  jbe 0x00007E05FE7CEDAC
00007e05fe7cf38d  vorps xmm14, xmm15, [0x00007E05FE3FE040]
00007e05fe7cf395  jmp 0x00007E05FE7CEDAC
00007e05fe7cf39a  ucomisd xmm1, xmm15
00007e05fe7cf39f  jp 0x00007E05FE7CF3AE
00007e05fe7cf3a1  movaps xmm14, [0x00007E05FE3FE030]
00007e05fe7cf3a9  jmp 0x00007E05FE7CEDE1
00007e05fe7cf3ae  vxorps xmm0, xmm1, xmm15
00007e05fe7cf3b3  pextrw eax, xmm0, 0x03
00007e05fe7cf3b8  and eax, 0x7FF8
00007e05fe7cf3bd  cmp eax, 0x08
00007e05fe7cf3c0  jnz 0x00007E05FE7CEDE1
00007e05fe7cf3c6  movq rax, xmm15
00007e05fe7cf3cb  shl rax, 0x0D
00007e05fe7cf3cf  jbe 0x00007E05FE7CEDE1
00007e05fe7cf3d5  vorps xmm14, xmm15, [0x00007E05FE3FE040]
00007e05fe7cf3dd  jmp 0x00007E05FE7CEDE1
00007e05fe7cf3e2  call 0x00007E05FE6D5EB0
00007e05fe7cf3e7  jmp 0x00007E05FE7CEDFE
00007e05fe7cf3ec  int3
00007e05fe7cf3ed  nop [rax], eax
00007e05fe7cf3f0  mov rax, [r15+0x48]
00007e05fe7cf3f4  mov r14, [r15+0x70]
00007e05fe7cf3f8  lea r12, [rax+r14*1]
00007e05fe7cf3fc  mov [r15+0x78], r12
00007e05fe7cf400  mov rax, [r13+r12*1]
00007e05fe7cf405  movq xmm1, rax
00007e05fe7cf40a  lea rax, [r12+0x40]
00007e05fe7cf40f  mov r11, [r13+rax*1]
00007e05fe7cf414  movq xmm15, r11
00007e05fe7cf419  lea rax, [r12+0x80]
00007e05fe7cf421  mov r11, [r13+rax*1]
00007e05fe7cf426  movq xmm14, r11
00007e05fe7cf42b  movaps xmm13, [r15+0x120]
00007e05fe7cf433  movq rax, xmm13
00007e05fe7cf438  movq r11, xmm1
00007e05fe7cf43d  vmovq xmm1, rax
00007e05fe7cf442  vmovq xmm13, r11
00007e05fe7cf447  movaps xmm12, xmm1
00007e05fe7cf44b  mulsd xmm12, xmm13
00007e05fe7cf450  ucomisd xmm12, xmm12
00007e05fe7cf455  jp 0x00007E05FE7CF879
00007e05fe7cf45b  movq xmm12, xmm12
00007e05fe7cf460  movaps xmm1, [r15+0x130]
00007e05fe7cf468  movq rax, xmm1
00007e05fe7cf46d  movq r11, xmm15
00007e05fe7cf472  vmovq xmm1, rax
00007e05fe7cf477  vmovq xmm15, r11
00007e05fe7cf47c  movaps xmm13, xmm1
00007e05fe7cf480  mulsd xmm13, xmm15
00007e05fe7cf485  ucomisd xmm13, xmm13
00007e05fe7cf48a  jp 0x00007E05FE7CF8C1
00007e05fe7cf490  movq xmm13, xmm13
00007e05fe7cf495  movq rax, xmm12
00007e05fe7cf49a  movaps xmm1, [r15+0x110]
00007e05fe7cf4a2  movq r11, xmm1
00007e05fe7cf4a7  vmovq xmm1, rax
00007e05fe7cf4ac  vmovq xmm15, r11
00007e05fe7cf4b1  movaps xmm12, xmm1
00007e05fe7cf4b5  addsd xmm12, xmm15
00007e05fe7cf4ba  ucomisd xmm12, xmm12
00007e05fe7cf4bf  jp 0x00007E05FE7CF909
00007e05fe7cf4c5  movq xmm12, xmm12
00007e05fe7cf4ca  movq rax, xmm12
00007e05fe7cf4cf  movq r11, xmm13
00007e05fe7cf4d4  vmovq xmm1, rax
00007e05fe7cf4d9  vmovq xmm15, r11
00007e05fe7cf4de  movaps xmm13, xmm1
00007e05fe7cf4e2  addsd xmm13, xmm15
00007e05fe7cf4e7  ucomisd xmm13, xmm13
00007e05fe7cf4ec  jp 0x00007E05FE7CF951
00007e05fe7cf4f2  movq xmm13, xmm13
00007e05fe7cf4f7  movaps xmm1, [r15+0x140]
00007e05fe7cf4ff  movq rax, xmm1
00007e05fe7cf504  movq r11, xmm14
00007e05fe7cf509  vmovq xmm1, rax
00007e05fe7cf50e  vmovq xmm15, r11
00007e05fe7cf513  movaps xmm14, xmm1
00007e05fe7cf517  mulsd xmm14, xmm15
00007e05fe7cf51c  ucomisd xmm14, xmm14
00007e05fe7cf521  jp 0x00007E05FE7CF999
00007e05fe7cf527  movq xmm14, xmm14
00007e05fe7cf52c  lea rax, [r12+0xC0]
00007e05fe7cf534  mov r11, [r13+rax*1]
00007e05fe7cf539  movq xmm1, r11
00007e05fe7cf53e  movq rax, xmm13
00007e05fe7cf543  movq r11, xmm14
00007e05fe7cf548  vmovq xmm15, rax
00007e05fe7cf54d  vmovq xmm14, r11
00007e05fe7cf552  movaps xmm13, xmm15
00007e05fe7cf556  addsd xmm13, xmm14
00007e05fe7cf55b  ucomisd xmm13, xmm13
00007e05fe7cf560  jp 0x00007E05FE7CF9EB
00007e05fe7cf566  movq xmm13, xmm13
00007e05fe7cf56b  movaps xmm15, [r15+0x150]
00007e05fe7cf573  movq rax, xmm15
00007e05fe7cf578  movq r11, xmm1
00007e05fe7cf57d  vmovq xmm1, rax
00007e05fe7cf582  vmovq xmm15, r11
00007e05fe7cf587  movaps xmm14, xmm1
00007e05fe7cf58b  mulsd xmm14, xmm15
00007e05fe7cf590  ucomisd xmm14, xmm14
00007e05fe7cf595  jp 0x00007E05FE7CFA33
00007e05fe7cf59b  movq xmm14, xmm14
00007e05fe7cf5a0  lea rax, [r12+0x100]
00007e05fe7cf5a8  mov r11, [r13+rax*1]
00007e05fe7cf5ad  movq xmm1, r11
00007e05fe7cf5b2  movq rax, xmm13
00007e05fe7cf5b7  movq r11, xmm14
00007e05fe7cf5bc  vmovq xmm15, rax
00007e05fe7cf5c1  vmovq xmm14, r11
00007e05fe7cf5c6  movaps xmm13, xmm15
00007e05fe7cf5ca  addsd xmm13, xmm14
00007e05fe7cf5cf  ucomisd xmm13, xmm13
00007e05fe7cf5d4  jp 0x00007E05FE7CFA85
00007e05fe7cf5da  movq xmm13, xmm13
00007e05fe7cf5df  movaps xmm15, [r15+0x160]
00007e05fe7cf5e7  movq rax, xmm15
00007e05fe7cf5ec  movq r11, xmm1
00007e05fe7cf5f1  vmovq xmm1, rax
00007e05fe7cf5f6  vmovq xmm15, r11
00007e05fe7cf5fb  movaps xmm14, xmm1
00007e05fe7cf5ff  mulsd xmm14, xmm15
00007e05fe7cf604  ucomisd xmm14, xmm14
00007e05fe7cf609  jp 0x00007E05FE7CFACD
00007e05fe7cf60f  movq xmm14, xmm14
00007e05fe7cf614  lea rax, [r12+0x140]
00007e05fe7cf61c  mov r11, [r13+rax*1]
00007e05fe7cf621  movq xmm1, r11
00007e05fe7cf626  movq rax, xmm13
00007e05fe7cf62b  movq r11, xmm14
00007e05fe7cf630  vmovq xmm15, rax
00007e05fe7cf635  vmovq xmm14, r11
00007e05fe7cf63a  movaps xmm13, xmm15
00007e05fe7cf63e  addsd xmm13, xmm14
00007e05fe7cf643  ucomisd xmm13, xmm13
00007e05fe7cf648  jp 0x00007E05FE7CFB1F
00007e05fe7cf64e  movq xmm13, xmm13
00007e05fe7cf653  movaps xmm15, [r15+0x170]
00007e05fe7cf65b  movq rax, xmm15
00007e05fe7cf660  movq r11, xmm1
00007e05fe7cf665  vmovq xmm1, rax
00007e05fe7cf66a  vmovq xmm15, r11
00007e05fe7cf66f  movaps xmm14, xmm1
00007e05fe7cf673  mulsd xmm14, xmm15
00007e05fe7cf678  ucomisd xmm14, xmm14
00007e05fe7cf67d  jp 0x00007E05FE7CFB67
00007e05fe7cf683  movq xmm14, xmm14
00007e05fe7cf688  lea rax, [r12+0x180]
00007e05fe7cf690  mov r11, [r13+rax*1]
00007e05fe7cf695  movq xmm1, r11
00007e05fe7cf69a  movq rax, xmm13
00007e05fe7cf69f  movq r11, xmm14
00007e05fe7cf6a4  vmovq xmm15, rax
00007e05fe7cf6a9  vmovq xmm14, r11
00007e05fe7cf6ae  movaps xmm13, xmm15
00007e05fe7cf6b2  addsd xmm13, xmm14
00007e05fe7cf6b7  ucomisd xmm13, xmm13
00007e05fe7cf6bc  jp 0x00007E05FE7CFBB9
00007e05fe7cf6c2  movq xmm13, xmm13
00007e05fe7cf6c7  movaps xmm15, [r15+0x180]
00007e05fe7cf6cf  movq rax, xmm15
00007e05fe7cf6d4  movq r11, xmm1
00007e05fe7cf6d9  vmovq xmm1, rax
00007e05fe7cf6de  vmovq xmm15, r11
00007e05fe7cf6e3  movaps xmm14, xmm1
00007e05fe7cf6e7  mulsd xmm14, xmm15
00007e05fe7cf6ec  ucomisd xmm14, xmm14
00007e05fe7cf6f1  jp 0x00007E05FE7CFC01
00007e05fe7cf6f7  movq xmm14, xmm14
00007e05fe7cf6fc  lea rax, [r12+0x1C0]
00007e05fe7cf704  mov r12, [r13+rax*1]
00007e05fe7cf709  movq xmm1, r12
00007e05fe7cf70e  movaps [r15+0x240], xmm1
00007e05fe7cf716  movq rax, xmm13
00007e05fe7cf71b  movq r12, xmm14
00007e05fe7cf720  vmovq xmm15, rax
00007e05fe7cf725  vmovq xmm14, r12
00007e05fe7cf72a  movaps xmm13, xmm15
00007e05fe7cf72e  addsd xmm13, xmm14
00007e05fe7cf733  ucomisd xmm13, xmm13
00007e05fe7cf738  jp 0x00007E05FE7CFC53
00007e05fe7cf73e  movq xmm13, xmm13
00007e05fe7cf743  movaps xmm15, [r15+0x210]
00007e05fe7cf74b  movq rax, xmm15
00007e05fe7cf750  movq r12, xmm1
00007e05fe7cf755  vmovq xmm1, rax
00007e05fe7cf75a  vmovq xmm15, r12
00007e05fe7cf75f  movaps xmm14, xmm1
00007e05fe7cf763  mulsd xmm14, xmm15
00007e05fe7cf768  ucomisd xmm14, xmm14
00007e05fe7cf76d  jp 0x00007E05FE7CFC9B
00007e05fe7cf773  movq xmm14, xmm14
00007e05fe7cf778  movaps [r15+0x230], xmm14
00007e05fe7cf780  movq rax, xmm13
00007e05fe7cf785  movq r12, xmm14
00007e05fe7cf78a  vmovq xmm1, rax
00007e05fe7cf78f  vmovq xmm15, r12
00007e05fe7cf794  movaps xmm14, xmm1
00007e05fe7cf798  addsd xmm14, xmm15
00007e05fe7cf79d  ucomisd xmm14, xmm14
00007e05fe7cf7a2  jp 0x00007E05FE7CFCE3
00007e05fe7cf7a8  movq xmm14, xmm14
00007e05fe7cf7ad  movaps [r15+0x220], xmm14
00007e05fe7cf7b5  mov rax, [r15+0x68]
00007e05fe7cf7b9  lea r12, [rax+r14*1]
00007e05fe7cf7bd  movq rax, xmm14
00007e05fe7cf7c2  mov [r13+r12*1], rax
00007e05fe7cf7c7  lea rax, [r14+0x08]
00007e05fe7cf7cb  mov [r15+0x70], rax
00007e05fe7cf7cf  mov [rsp+0x10], rax
00007e05fe7cf7d4  xor eax, eax
00007e05fe7cf7d6  mov r14, [rsp+0x10]
00007e05fe7cf7db  mov r12d, 0x40
00007e05fe7cf7e1  cmp r14, r12
00007e05fe7cf7e4  cmc
00007e05fe7cf7e5  lahf
00007e05fe7cf7e6  seto al
00007e05fe7cf7e9  mov [r15+0x108], eax
00007e05fe7cf7f0  mov eax, [r15+0x108]
00007e05fe7cf7f7  sahf
00007e05fe7cf7f8  jnz 0x00007E05FE7CF82A
00007e05fe7cf7fa  cmp dword ptr [r15+0x318], 0x00
00007e05fe7cf802  jz 0x00007E05FE7CFD40
00007e05fe7cf808  nop [rax+rax*1], ax
00007e05fe7cf811  nop [rax+rax*1], eax
00007e05fe7cf819  mov eax, 0x410118
00007e05fe7cf81e  mov [r15+0x100], rax
00007e05fe7cf825  jmp 0x00007E05FE5FE110
00007e05fe7cf82a  cmp dword ptr [r15+0x318], 0x00
00007e05fe7cf832  jz 0x00007E05FE7CF3F0
00007e05fe7cf838  nop [rax+rax*1], ax
00007e05fe7cf841  nop [rax+rax*1], eax
00007e05fe7cf849  mov eax, 0x4100A4
00007e05fe7cf84e  mov [r15+0x100], rax
00007e05fe7cf855  jmp 0x00007E05FE5FE110
00007e05fe7cf85a  int3
00007e05fe7cf85b  call 0x00007E05FE6B47C0
00007e05fe7cf860  jmp 0x00007E05FE7CF405
00007e05fe7cf865  call 0x00007E05FE60A4B0
00007e05fe7cf86a  jmp 0x00007E05FE7CF414
00007e05fe7cf86f  call 0x00007E05FE60A4B0
00007e05fe7cf874  jmp 0x00007E05FE7CF426
00007e05fe7cf879  ucomisd xmm1, xmm13
00007e05fe7cf87e  jp 0x00007E05FE7CF88D
00007e05fe7cf880  movaps xmm12, [0x00007E05FE3FE030]
00007e05fe7cf888  jmp 0x00007E05FE7CF45B
00007e05fe7cf88d  vxorps xmm0, xmm1, xmm13
00007e05fe7cf892  pextrw eax, xmm0, 0x03
00007e05fe7cf897  and eax, 0x7FF8
00007e05fe7cf89c  cmp eax, 0x08
00007e05fe7cf89f  jnz 0x00007E05FE7CF45B
00007e05fe7cf8a5  movq rax, xmm13
00007e05fe7cf8aa  shl rax, 0x0D
00007e05fe7cf8ae  jbe 0x00007E05FE7CF45B
00007e05fe7cf8b4  vorps xmm12, xmm13, [0x00007E05FE3FE040]
00007e05fe7cf8bc  jmp 0x00007E05FE7CF45B
00007e05fe7cf8c1  ucomisd xmm1, xmm15
00007e05fe7cf8c6  jp 0x00007E05FE7CF8D5
00007e05fe7cf8c8  movaps xmm13, [0x00007E05FE3FE030]
00007e05fe7cf8d0  jmp 0x00007E05FE7CF490
00007e05fe7cf8d5  vxorps xmm0, xmm1, xmm15
00007e05fe7cf8da  pextrw eax, xmm0, 0x03
00007e05fe7cf8df  and eax, 0x7FF8
00007e05fe7cf8e4  cmp eax, 0x08
00007e05fe7cf8e7  jnz 0x00007E05FE7CF490
00007e05fe7cf8ed  movq rax, xmm15
00007e05fe7cf8f2  shl rax, 0x0D
00007e05fe7cf8f6  jbe 0x00007E05FE7CF490
00007e05fe7cf8fc  vorps xmm13, xmm15, [0x00007E05FE3FE040]
00007e05fe7cf904  jmp 0x00007E05FE7CF490
00007e05fe7cf909  ucomisd xmm1, xmm15
00007e05fe7cf90e  jp 0x00007E05FE7CF91D
00007e05fe7cf910  movaps xmm12, [0x00007E05FE3FE030]
00007e05fe7cf918  jmp 0x00007E05FE7CF4C5
00007e05fe7cf91d  vxorps xmm0, xmm1, xmm15
00007e05fe7cf922  pextrw eax, xmm0, 0x03
00007e05fe7cf927  and eax, 0x7FF8
00007e05fe7cf92c  cmp eax, 0x08
00007e05fe7cf92f  jnz 0x00007E05FE7CF4C5
00007e05fe7cf935  movq rax, xmm15
00007e05fe7cf93a  shl rax, 0x0D
00007e05fe7cf93e  jbe 0x00007E05FE7CF4C5
00007e05fe7cf944  vorps xmm12, xmm15, [0x00007E05FE3FE040]
00007e05fe7cf94c  jmp 0x00007E05FE7CF4C5
00007e05fe7cf951  ucomisd xmm1, xmm15
00007e05fe7cf956  jp 0x00007E05FE7CF965
00007e05fe7cf958  movaps xmm13, [0x00007E05FE3FE030]
00007e05fe7cf960  jmp 0x00007E05FE7CF4F2
00007e05fe7cf965  vxorps xmm0, xmm1, xmm15
00007e05fe7cf96a  pextrw eax, xmm0, 0x03
00007e05fe7cf96f  and eax, 0x7FF8
00007e05fe7cf974  cmp eax, 0x08
00007e05fe7cf977  jnz 0x00007E05FE7CF4F2
00007e05fe7cf97d  movq rax, xmm15
00007e05fe7cf982  shl rax, 0x0D
00007e05fe7cf986  jbe 0x00007E05FE7CF4F2
00007e05fe7cf98c  vorps xmm13, xmm15, [0x00007E05FE3FE040]
00007e05fe7cf994  jmp 0x00007E05FE7CF4F2
00007e05fe7cf999  ucomisd xmm1, xmm15
00007e05fe7cf99e  jp 0x00007E05FE7CF9AD
00007e05fe7cf9a0  movaps xmm14, [0x00007E05FE3FE030]
00007e05fe7cf9a8  jmp 0x00007E05FE7CF527
00007e05fe7cf9ad  vxorps xmm0, xmm1, xmm15
00007e05fe7cf9b2  pextrw eax, xmm0, 0x03
00007e05fe7cf9b7  and eax, 0x7FF8
00007e05fe7cf9bc  cmp eax, 0x08
00007e05fe7cf9bf  jnz 0x00007E05FE7CF527
00007e05fe7cf9c5  movq rax, xmm15
00007e05fe7cf9ca  shl rax, 0x0D
00007e05fe7cf9ce  jbe 0x00007E05FE7CF527
00007e05fe7cf9d4  vorps xmm14, xmm15, [0x00007E05FE3FE040]
00007e05fe7cf9dc  jmp 0x00007E05FE7CF527
00007e05fe7cf9e1  call 0x00007E05FE60A4B0
00007e05fe7cf9e6  jmp 0x00007E05FE7CF539
00007e05fe7cf9eb  ucomisd xmm15, xmm14
00007e05fe7cf9f0  jp 0x00007E05FE7CF9FF
00007e05fe7cf9f2  movaps xmm13, [0x00007E05FE3FE030]
00007e05fe7cf9fa  jmp 0x00007E05FE7CF566
00007e05fe7cf9ff  vxorps xmm0, xmm15, xmm14
00007e05fe7cfa04  pextrw eax, xmm0, 0x03
00007e05fe7cfa09  and eax, 0x7FF8
00007e05fe7cfa0e  cmp eax, 0x08
00007e05fe7cfa11  jnz 0x00007E05FE7CF566
00007e05fe7cfa17  movq rax, xmm14
00007e05fe7cfa1c  shl rax, 0x0D
00007e05fe7cfa20  jbe 0x00007E05FE7CF566
00007e05fe7cfa26  vorps xmm13, xmm14, [0x00007E05FE3FE040]
00007e05fe7cfa2e  jmp 0x00007E05FE7CF566
00007e05fe7cfa33  ucomisd xmm1, xmm15
00007e05fe7cfa38  jp 0x00007E05FE7CFA47
00007e05fe7cfa3a  movaps xmm14, [0x00007E05FE3FE030]
00007e05fe7cfa42  jmp 0x00007E05FE7CF59B
00007e05fe7cfa47  vxorps xmm0, xmm1, xmm15
00007e05fe7cfa4c  pextrw eax, xmm0, 0x03
00007e05fe7cfa51  and eax, 0x7FF8
00007e05fe7cfa56  cmp eax, 0x08
00007e05fe7cfa59  jnz 0x00007E05FE7CF59B
00007e05fe7cfa5f  movq rax, xmm15
00007e05fe7cfa64  shl rax, 0x0D
00007e05fe7cfa68  jbe 0x00007E05FE7CF59B
00007e05fe7cfa6e  vorps xmm14, xmm15, [0x00007E05FE3FE040]
00007e05fe7cfa76  jmp 0x00007E05FE7CF59B
00007e05fe7cfa7b  call 0x00007E05FE60A4B0
00007e05fe7cfa80  jmp 0x00007E05FE7CF5AD
00007e05fe7cfa85  ucomisd xmm15, xmm14
00007e05fe7cfa8a  jp 0x00007E05FE7CFA99
00007e05fe7cfa8c  movaps xmm13, [0x00007E05FE3FE030]
00007e05fe7cfa94  jmp 0x00007E05FE7CF5DA
00007e05fe7cfa99  vxorps xmm0, xmm15, xmm14
00007e05fe7cfa9e  pextrw eax, xmm0, 0x03
00007e05fe7cfaa3  and eax, 0x7FF8
00007e05fe7cfaa8  cmp eax, 0x08
00007e05fe7cfaab  jnz 0x00007E05FE7CF5DA
00007e05fe7cfab1  movq rax, xmm14
00007e05fe7cfab6  shl rax, 0x0D
00007e05fe7cfaba  jbe 0x00007E05FE7CF5DA
00007e05fe7cfac0  vorps xmm13, xmm14, [0x00007E05FE3FE040]
00007e05fe7cfac8  jmp 0x00007E05FE7CF5DA
00007e05fe7cfacd  ucomisd xmm1, xmm15
00007e05fe7cfad2  jp 0x00007E05FE7CFAE1
00007e05fe7cfad4  movaps xmm14, [0x00007E05FE3FE030]
00007e05fe7cfadc  jmp 0x00007E05FE7CF60F
00007e05fe7cfae1  vxorps xmm0, xmm1, xmm15
00007e05fe7cfae6  pextrw eax, xmm0, 0x03
00007e05fe7cfaeb  and eax, 0x7FF8
00007e05fe7cfaf0  cmp eax, 0x08
00007e05fe7cfaf3  jnz 0x00007E05FE7CF60F
00007e05fe7cfaf9  movq rax, xmm15
00007e05fe7cfafe  shl rax, 0x0D
00007e05fe7cfb02  jbe 0x00007E05FE7CF60F
00007e05fe7cfb08  vorps xmm14, xmm15, [0x00007E05FE3FE040]
00007e05fe7cfb10  jmp 0x00007E05FE7CF60F
00007e05fe7cfb15  call 0x00007E05FE60A4B0
00007e05fe7cfb1a  jmp 0x00007E05FE7CF621
00007e05fe7cfb1f  ucomisd xmm15, xmm14
00007e05fe7cfb24  jp 0x00007E05FE7CFB33
00007e05fe7cfb26  movaps xmm13, [0x00007E05FE3FE030]
00007e05fe7cfb2e  jmp 0x00007E05FE7CF64E
00007e05fe7cfb33  vxorps xmm0, xmm15, xmm14
00007e05fe7cfb38  pextrw eax, xmm0, 0x03
00007e05fe7cfb3d  and eax, 0x7FF8
00007e05fe7cfb42  cmp eax, 0x08
00007e05fe7cfb45  jnz 0x00007E05FE7CF64E
00007e05fe7cfb4b  movq rax, xmm14
00007e05fe7cfb50  shl rax, 0x0D
00007e05fe7cfb54  jbe 0x00007E05FE7CF64E
00007e05fe7cfb5a  vorps xmm13, xmm14, [0x00007E05FE3FE040]
00007e05fe7cfb62  jmp 0x00007E05FE7CF64E
00007e05fe7cfb67  ucomisd xmm1, xmm15
00007e05fe7cfb6c  jp 0x00007E05FE7CFB7B
00007e05fe7cfb6e  movaps xmm14, [0x00007E05FE3FE030]
00007e05fe7cfb76  jmp 0x00007E05FE7CF683
00007e05fe7cfb7b  vxorps xmm0, xmm1, xmm15
00007e05fe7cfb80  pextrw eax, xmm0, 0x03
00007e05fe7cfb85  and eax, 0x7FF8
00007e05fe7cfb8a  cmp eax, 0x08
00007e05fe7cfb8d  jnz 0x00007E05FE7CF683
00007e05fe7cfb93  movq rax, xmm15
00007e05fe7cfb98  shl rax, 0x0D
00007e05fe7cfb9c  jbe 0x00007E05FE7CF683
00007e05fe7cfba2  vorps xmm14, xmm15, [0x00007E05FE3FE040]
00007e05fe7cfbaa  jmp 0x00007E05FE7CF683
00007e05fe7cfbaf  call 0x00007E05FE60A4B0
00007e05fe7cfbb4  jmp 0x00007E05FE7CF695
00007e05fe7cfbb9  ucomisd xmm15, xmm14
00007e05fe7cfbbe  jp 0x00007E05FE7CFBCD
00007e05fe7cfbc0  movaps xmm13, [0x00007E05FE3FE030]
00007e05fe7cfbc8  jmp 0x00007E05FE7CF6C2
00007e05fe7cfbcd  vxorps xmm0, xmm15, xmm14
00007e05fe7cfbd2  pextrw eax, xmm0, 0x03
00007e05fe7cfbd7  and eax, 0x7FF8
00007e05fe7cfbdc  cmp eax, 0x08
00007e05fe7cfbdf  jnz 0x00007E05FE7CF6C2
00007e05fe7cfbe5  movq rax, xmm14
00007e05fe7cfbea  shl rax, 0x0D
00007e05fe7cfbee  jbe 0x00007E05FE7CF6C2
00007e05fe7cfbf4  vorps xmm13, xmm14, [0x00007E05FE3FE040]
00007e05fe7cfbfc  jmp 0x00007E05FE7CF6C2
00007e05fe7cfc01  ucomisd xmm1, xmm15
00007e05fe7cfc06  jp 0x00007E05FE7CFC15
00007e05fe7cfc08  movaps xmm14, [0x00007E05FE3FE030]
00007e05fe7cfc10  jmp 0x00007E05FE7CF6F7
00007e05fe7cfc15  vxorps xmm0, xmm1, xmm15
00007e05fe7cfc1a  pextrw eax, xmm0, 0x03
00007e05fe7cfc1f  and eax, 0x7FF8
00007e05fe7cfc24  cmp eax, 0x08
00007e05fe7cfc27  jnz 0x00007E05FE7CF6F7
00007e05fe7cfc2d  movq rax, xmm15
00007e05fe7cfc32  shl rax, 0x0D
00007e05fe7cfc36  jbe 0x00007E05FE7CF6F7
00007e05fe7cfc3c  vorps xmm14, xmm15, [0x00007E05FE3FE040]
00007e05fe7cfc44  jmp 0x00007E05FE7CF6F7
00007e05fe7cfc49  call 0x00007E05FE60B720
00007e05fe7cfc4e  jmp 0x00007E05FE7CF709
00007e05fe7cfc53  ucomisd xmm15, xmm14
00007e05fe7cfc58  jp 0x00007E05FE7CFC67
00007e05fe7cfc5a  movaps xmm13, [0x00007E05FE3FE030]
00007e05fe7cfc62  jmp 0x00007E05FE7CF73E
00007e05fe7cfc67  vxorps xmm0, xmm15, xmm14
00007e05fe7cfc6c  pextrw eax, xmm0, 0x03
00007e05fe7cfc71  and eax, 0x7FF8
00007e05fe7cfc76  cmp eax, 0x08
00007e05fe7cfc79  jnz 0x00007E05FE7CF73E
00007e05fe7cfc7f  movq rax, xmm14
00007e05fe7cfc84  shl rax, 0x0D
00007e05fe7cfc88  jbe 0x00007E05FE7CF73E
00007e05fe7cfc8e  vorps xmm13, xmm14, [0x00007E05FE3FE040]
00007e05fe7cfc96  jmp 0x00007E05FE7CF73E
00007e05fe7cfc9b  ucomisd xmm1, xmm15
00007e05fe7cfca0  jp 0x00007E05FE7CFCAF
00007e05fe7cfca2  movaps xmm14, [0x00007E05FE3FE030]
00007e05fe7cfcaa  jmp 0x00007E05FE7CF773
00007e05fe7cfcaf  vxorps xmm0, xmm1, xmm15
00007e05fe7cfcb4  pextrw eax, xmm0, 0x03
00007e05fe7cfcb9  and eax, 0x7FF8
00007e05fe7cfcbe  cmp eax, 0x08
00007e05fe7cfcc1  jnz 0x00007E05FE7CF773
00007e05fe7cfcc7  movq rax, xmm15
00007e05fe7cfccc  shl rax, 0x0D
00007e05fe7cfcd0  jbe 0x00007E05FE7CF773
00007e05fe7cfcd6  vorps xmm14, xmm15, [0x00007E05FE3FE040]
00007e05fe7cfcde  jmp 0x00007E05FE7CF773
00007e05fe7cfce3  ucomisd xmm1, xmm15
00007e05fe7cfce8  jp 0x00007E05FE7CFCF7
00007e05fe7cfcea  movaps xmm14, [0x00007E05FE3FE030]
00007e05fe7cfcf2  jmp 0x00007E05FE7CF7A8
00007e05fe7cfcf7  vxorps xmm0, xmm1, xmm15
00007e05fe7cfcfc  pextrw eax, xmm0, 0x03
00007e05fe7cfd01  and eax, 0x7FF8
00007e05fe7cfd06  cmp eax, 0x08
00007e05fe7cfd09  jnz 0x00007E05FE7CF7A8
00007e05fe7cfd0f  movq rax, xmm15
00007e05fe7cfd14  shl rax, 0x0D
00007e05fe7cfd18  jbe 0x00007E05FE7CF7A8
00007e05fe7cfd1e  vorps xmm14, xmm15, [0x00007E05FE3FE040]
00007e05fe7cfd26  jmp 0x00007E05FE7CF7A8
00007e05fe7cfd2b  call 0x00007E05FE6B4CB0
00007e05fe7cfd30  jmp 0x00007E05FE7CF7C7
00007e05fe7cfd35  int3
00007e05fe7cfd36  nop [rax+rax*1], ax
00007e05fe7cfd3f  nop
00007e05fe7cfd40  mov rax, [r15+0x60]
00007e05fe7cfd44  lea r14, [rax+0x01]
00007e05fe7cfd48  mov [r15+0x60], r14
00007e05fe7cfd4c  mov rax, [r15+0x68]
00007e05fe7cfd50  lea r12, [rax+0x40]
00007e05fe7cfd54  mov [r15+0x68], r12
00007e05fe7cfd58  xor eax, eax
00007e05fe7cfd5a  mov r12d, 0x08
00007e05fe7cfd60  cmp r14, r12
00007e05fe7cfd63  cmc
00007e05fe7cfd64  lahf
00007e05fe7cfd65  seto al
00007e05fe7cfd68  mov [r15+0x108], eax
00007e05fe7cfd6f  mov eax, [r15+0x108]
00007e05fe7cfd76  sahf
00007e05fe7cfd77  jnz 0x00007E05FE7CFDA9
00007e05fe7cfd79  cmp dword ptr [r15+0x318], 0x00
00007e05fe7cfd81  jz 0x00007E05FE7D08A0
00007e05fe7cfd87  nop [rax+rax*1], ax
00007e05fe7cfd90  nop [rax+rax*1], eax
00007e05fe7cfd98  mov eax, 0x410128
00007e05fe7cfd9d  mov [r15+0x100], rax
00007e05fe7cfda4  jmp 0x00007E05FE5FE110
00007e05fe7cfda9  cmp dword ptr [r15+0x318], 0x00
00007e05fe7cfdb1  jz 0x00007E05FE7CFDE0
00007e05fe7cfdb7  nop [rax+rax*1], ax
00007e05fe7cfdc0  nop [rax+rax*1], eax
00007e05fe7cfdc8  mov eax, 0x41008C
00007e05fe7cfdcd  mov [r15+0x100], rax
00007e05fe7cfdd4  jmp 0x00007E05FE5FE110
00007e05fe7cfdd9  int3
00007e05fe7cfdda  int3
00007e05fe7cfddb  nop [rax+rax*1], eax
00007e05fe7cfde0  mov rax, [r15+0x40]
00007e05fe7cfde4  mov r14, [r15+0x60]
00007e05fe7cfde8  shl r14, 0x06
00007e05fe7cfdec  lea r12, [rax+r14*1]
00007e05fe7cfdf0  mov rax, [r13+r12*1]
00007e05fe7cfdf5  lea r14, [r12+0x08]
00007e05fe7cfdfa  mov r11, [r13+r14*1]
00007e05fe7cfdff  movq xmm1, rax
00007e05fe7cfe04  movq xmm15, r11
00007e05fe7cfe09  movq xmm1, xmm1
00007e05fe7cfe0d  movq xmm1, xmm1
00007e05fe7cfe11  movaps [r15+0x120], xmm1
00007e05fe7cfe19  movq xmm15, xmm15
00007e05fe7cfe1e  movq xmm15, xmm15
00007e05fe7cfe23  movaps [r15+0x130], xmm15
00007e05fe7cfe2b  lea rax, [r12+0x10]
00007e05fe7cfe30  mov r14, [r13+rax*1]
00007e05fe7cfe35  lea rax, [r12+0x18]
00007e05fe7cfe3a  mov r11, [r13+rax*1]
00007e05fe7cfe3f  movq xmm1, r14
00007e05fe7cfe44  movq xmm15, r11
00007e05fe7cfe49  movq xmm1, xmm1
00007e05fe7cfe4d  movq xmm1, xmm1
00007e05fe7cfe51  movaps [r15+0x140], xmm1
00007e05fe7cfe59  movq xmm15, xmm15
00007e05fe7cfe5e  movq xmm15, xmm15
00007e05fe7cfe63  movaps [r15+0x150], xmm15
00007e05fe7cfe6b  lea rax, [r12+0x20]
00007e05fe7cfe70  mov r14, [r13+rax*1]
00007e05fe7cfe75  lea rax, [r12+0x28]
00007e05fe7cfe7a  mov r11, [r13+rax*1]
00007e05fe7cfe7f  movq xmm1, r14
00007e05fe7cfe84  movq xmm15, r11
00007e05fe7cfe89  movq xmm1, xmm1
00007e05fe7cfe8d  movq xmm1, xmm1
00007e05fe7cfe91  movaps [r15+0x160], xmm1
00007e05fe7cfe99  movq xmm15, xmm15
00007e05fe7cfe9e  movq xmm15, xmm15
00007e05fe7cfea3  movaps [r15+0x170], xmm15
00007e05fe7cfeab  lea rax, [r12+0x30]
00007e05fe7cfeb0  mov r14, [r13+rax*1]
00007e05fe7cfeb5  lea rax, [r12+0x38]
00007e05fe7cfeba  mov r12, [r13+rax*1]
00007e05fe7cfebf  movq xmm1, r14
00007e05fe7cfec4  movq xmm15, r12
00007e05fe7cfec9  movq xmm1, xmm1
00007e05fe7cfecd  movq xmm1, xmm1
00007e05fe7cfed1  movaps [r15+0x180], xmm1
00007e05fe7cfed9  movq xmm15, xmm15
00007e05fe7cfede  movq xmm15, xmm15
00007e05fe7cfee3  movaps [r15+0x210], xmm15
00007e05fe7cfeeb  mov rax, [r15+0x48]
00007e05fe7cfeef  mov [r15+0x78], rax
00007e05fe7cfef3  mov r14, [r13+rax*1]
00007e05fe7cfef8  movq xmm1, r14
00007e05fe7cfefd  lea r14, [rax+0x40]
00007e05fe7cff01  mov r12, [r13+r14*1]
00007e05fe7cff06  movq xmm15, r12
00007e05fe7cff0b  lea r14, [rax+0x80]
00007e05fe7cff12  mov r12, [r13+r14*1]
00007e05fe7cff17  movq xmm14, r12
00007e05fe7cff1c  movaps xmm13, [r15+0x120]
00007e05fe7cff24  movq r14, xmm13
00007e05fe7cff29  movq r12, xmm1
00007e05fe7cff2e  vmovq xmm1, r14
00007e05fe7cff33  vmovq xmm13, r12
00007e05fe7cff38  movaps xmm12, xmm1
00007e05fe7cff3c  mulsd xmm12, xmm13
00007e05fe7cff41  ucomisd xmm12, xmm12
00007e05fe7cff46  jp 0x00007E05FE7D03AD
00007e05fe7cff4c  movq xmm12, xmm12
00007e05fe7cff51  movaps xmm1, [r15+0x130]
00007e05fe7cff59  movq r14, xmm1
00007e05fe7cff5e  movq r12, xmm15
00007e05fe7cff63  vmovq xmm1, r14
00007e05fe7cff68  vmovq xmm15, r12
00007e05fe7cff6d  movaps xmm13, xmm1
00007e05fe7cff71  mulsd xmm13, xmm15
00007e05fe7cff76  ucomisd xmm13, xmm13
00007e05fe7cff7b  jp 0x00007E05FE7D03F9
00007e05fe7cff81  movq xmm13, xmm13
00007e05fe7cff86  movq r14, xmm12
00007e05fe7cff8b  movaps xmm1, [r15+0x110]
00007e05fe7cff93  movq r12, xmm1
00007e05fe7cff98  vmovq xmm1, r14
00007e05fe7cff9d  vmovq xmm15, r12
00007e05fe7cffa2  movaps xmm12, xmm1
00007e05fe7cffa6  addsd xmm12, xmm15
00007e05fe7cffab  ucomisd xmm12, xmm12
00007e05fe7cffb0  jp 0x00007E05FE7D0445
00007e05fe7cffb6  movq xmm12, xmm12
00007e05fe7cffbb  movq r14, xmm12
00007e05fe7cffc0  movq r12, xmm13
00007e05fe7cffc5  vmovq xmm1, r14
00007e05fe7cffca  vmovq xmm15, r12
00007e05fe7cffcf  movaps xmm13, xmm1
00007e05fe7cffd3  addsd xmm13, xmm15
00007e05fe7cffd8  ucomisd xmm13, xmm13
00007e05fe7cffdd  jp 0x00007E05FE7D0491
00007e05fe7cffe3  movq xmm13, xmm13
00007e05fe7cffe8  movaps xmm1, [r15+0x140]
00007e05fe7cfff0  movq r14, xmm1
00007e05fe7cfff5  movq r12, xmm14
00007e05fe7cfffa  vmovq xmm1, r14
00007e05fe7cffff  vmovq xmm15, r12
00007e05fe7d0004  movaps xmm14, xmm1
00007e05fe7d0008  mulsd xmm14, xmm15
00007e05fe7d000d  ucomisd xmm14, xmm14
00007e05fe7d0012  jp 0x00007E05FE7D04DD
00007e05fe7d0018  movq xmm14, xmm14
00007e05fe7d001d  lea r14, [rax+0xC0]
00007e05fe7d0024  mov r12, [r13+r14*1]
00007e05fe7d0029  movq xmm1, r12
00007e05fe7d002e  movq r14, xmm13
00007e05fe7d0033  movq r12, xmm14
00007e05fe7d0038  vmovq xmm15, r14
00007e05fe7d003d  vmovq xmm14, r12
00007e05fe7d0042  movaps xmm13, xmm15
00007e05fe7d0046  addsd xmm13, xmm14
00007e05fe7d004b  ucomisd xmm13, xmm13
00007e05fe7d0050  jp 0x00007E05FE7D0533
00007e05fe7d0056  movq xmm13, xmm13
00007e05fe7d005b  movaps xmm15, [r15+0x150]
00007e05fe7d0063  movq r14, xmm15
00007e05fe7d0068  movq r12, xmm1
00007e05fe7d006d  vmovq xmm1, r14
00007e05fe7d0072  vmovq xmm15, r12
00007e05fe7d0077  movaps xmm14, xmm1
00007e05fe7d007b  mulsd xmm14, xmm15
00007e05fe7d0080  ucomisd xmm14, xmm14
00007e05fe7d0085  jp 0x00007E05FE7D057F
00007e05fe7d008b  movq xmm14, xmm14
00007e05fe7d0090  lea r14, [rax+0x100]
00007e05fe7d0097  mov r12, [r13+r14*1]
00007e05fe7d009c  movq xmm1, r12
00007e05fe7d00a1  movq r14, xmm13
00007e05fe7d00a6  movq r12, xmm14
00007e05fe7d00ab  vmovq xmm15, r14
00007e05fe7d00b0  vmovq xmm14, r12
00007e05fe7d00b5  movaps xmm13, xmm15
00007e05fe7d00b9  addsd xmm13, xmm14
00007e05fe7d00be  ucomisd xmm13, xmm13
00007e05fe7d00c3  jp 0x00007E05FE7D05D5
00007e05fe7d00c9  movq xmm13, xmm13
00007e05fe7d00ce  movaps xmm15, [r15+0x160]
00007e05fe7d00d6  movq r14, xmm15
00007e05fe7d00db  movq r12, xmm1
00007e05fe7d00e0  vmovq xmm1, r14
00007e05fe7d00e5  vmovq xmm15, r12
00007e05fe7d00ea  movaps xmm14, xmm1
00007e05fe7d00ee  mulsd xmm14, xmm15
00007e05fe7d00f3  ucomisd xmm14, xmm14
00007e05fe7d00f8  jp 0x00007E05FE7D0621
00007e05fe7d00fe  movq xmm14, xmm14
00007e05fe7d0103  lea r14, [rax+0x140]
00007e05fe7d010a  mov r12, [r13+r14*1]
00007e05fe7d010f  movq xmm1, r12
00007e05fe7d0114  movq r14, xmm13
00007e05fe7d0119  movq r12, xmm14
00007e05fe7d011e  vmovq xmm15, r14
00007e05fe7d0123  vmovq xmm14, r12
00007e05fe7d0128  movaps xmm13, xmm15
00007e05fe7d012c  addsd xmm13, xmm14
00007e05fe7d0131  ucomisd xmm13, xmm13
00007e05fe7d0136  jp 0x00007E05FE7D0677
00007e05fe7d013c  movq xmm13, xmm13
00007e05fe7d0141  movaps xmm15, [r15+0x170]
00007e05fe7d0149  movq r14, xmm15
00007e05fe7d014e  movq r12, xmm1
00007e05fe7d0153  vmovq xmm1, r14
00007e05fe7d0158  vmovq xmm15, r12
00007e05fe7d015d  movaps xmm14, xmm1
00007e05fe7d0161  mulsd xmm14, xmm15
00007e05fe7d0166  ucomisd xmm14, xmm14
00007e05fe7d016b  jp 0x00007E05FE7D06C3
00007e05fe7d0171  movq xmm14, xmm14
00007e05fe7d0176  lea r14, [rax+0x180]
00007e05fe7d017d  mov r12, [r13+r14*1]
00007e05fe7d0182  movq xmm1, r12
00007e05fe7d0187  movq r14, xmm13
00007e05fe7d018c  movq r12, xmm14
00007e05fe7d0191  vmovq xmm15, r14
00007e05fe7d0196  vmovq xmm14, r12
00007e05fe7d019b  movaps xmm13, xmm15
00007e05fe7d019f  addsd xmm13, xmm14
00007e05fe7d01a4  ucomisd xmm13, xmm13
00007e05fe7d01a9  jp 0x00007E05FE7D0719
00007e05fe7d01af  movq xmm13, xmm13
00007e05fe7d01b4  movaps xmm15, [r15+0x180]
00007e05fe7d01bc  movq r14, xmm15
00007e05fe7d01c1  movq r12, xmm1
00007e05fe7d01c6  vmovq xmm1, r14
00007e05fe7d01cb  vmovq xmm15, r12
00007e05fe7d01d0  movaps xmm14, xmm1
00007e05fe7d01d4  mulsd xmm14, xmm15
00007e05fe7d01d9  ucomisd xmm14, xmm14
00007e05fe7d01de  jp 0x00007E05FE7D0765
00007e05fe7d01e4  movq xmm14, xmm14
00007e05fe7d01e9  lea r14, [rax+0x1C0]
00007e05fe7d01f0  mov rax, [r13+r14*1]
00007e05fe7d01f5  movq xmm1, rax
00007e05fe7d01fa  movaps [r15+0x240], xmm1
00007e05fe7d0202  movq rax, xmm13
00007e05fe7d0207  movq r14, xmm14
00007e05fe7d020c  vmovq xmm15, rax
00007e05fe7d0211  vmovq xmm14, r14
00007e05fe7d0216  movaps xmm13, xmm15
00007e05fe7d021a  addsd xmm13, xmm14
00007e05fe7d021f  ucomisd xmm13, xmm13
00007e05fe7d0224  jp 0x00007E05FE7D07BB
00007e05fe7d022a  movq xmm13, xmm13
00007e05fe7d022f  movaps xmm15, [r15+0x210]
00007e05fe7d0237  movq rax, xmm15
00007e05fe7d023c  movq r14, xmm1
00007e05fe7d0241  vmovq xmm1, rax
00007e05fe7d0246  vmovq xmm15, r14
00007e05fe7d024b  movaps xmm14, xmm1
00007e05fe7d024f  mulsd xmm14, xmm15
00007e05fe7d0254  ucomisd xmm14, xmm14
00007e05fe7d0259  jp 0x00007E05FE7D0803
00007e05fe7d025f  movq xmm14, xmm14
00007e05fe7d0264  movaps [r15+0x230], xmm14
00007e05fe7d026c  movq rax, xmm13
00007e05fe7d0271  movq r14, xmm14
00007e05fe7d0276  vmovq xmm1, rax
00007e05fe7d027b  vmovq xmm15, r14
00007e05fe7d0280  movaps xmm14, xmm1
00007e05fe7d0284  addsd xmm14, xmm15
00007e05fe7d0289  ucomisd xmm14, xmm14
00007e05fe7d028e  jp 0x00007E05FE7D084B
00007e05fe7d0294  movq xmm14, xmm14
00007e05fe7d0299  movaps [r15+0x220], xmm14
00007e05fe7d02a1  mov rax, [r15+0x68]
00007e05fe7d02a5  movq r14, xmm14
00007e05fe7d02aa  mov [r13+rax*1], r14
00007e05fe7d02af  mov qword ptr [r15+0x70], 0x08
00007e05fe7d02b7  xor eax, eax
00007e05fe7d02b9  mov r14d, 0x08
00007e05fe7d02bf  mov r12d, 0x40
00007e05fe7d02c5  cmp r14, r12
00007e05fe7d02c8  cmc
00007e05fe7d02c9  lahf
00007e05fe7d02ca  seto al
00007e05fe7d02cd  mov [r15+0x108], eax
00007e05fe7d02d4  mov eax, [r15+0x108]
00007e05fe7d02db  sahf
00007e05fe7d02dc  jnz 0x00007E05FE7D030E
00007e05fe7d02de  cmp dword ptr [r15+0x318], 0x00
00007e05fe7d02e6  jz 0x00007E05FE7CFD40
00007e05fe7d02ec  nop [rax+rax*1], ax
00007e05fe7d02f5  nop [rax+rax*1], eax
00007e05fe7d02fd  mov eax, 0x410118
00007e05fe7d0302  mov [r15+0x100], rax
00007e05fe7d0309  jmp 0x00007E05FE5FE110
00007e05fe7d030e  cmp dword ptr [r15+0x318], 0x00
00007e05fe7d0316  jz 0x00007E05FE7CF3F0
00007e05fe7d031c  nop [rax+rax*1], ax
00007e05fe7d0325  nop [rax+rax*1], eax
00007e05fe7d032d  mov eax, 0x4100A4
00007e05fe7d0332  mov [r15+0x100], rax
00007e05fe7d0339  jmp 0x00007E05FE5FE110
00007e05fe7d033e  int3
00007e05fe7d033f  call 0x00007E05FE6B47C0
00007e05fe7d0344  jmp 0x00007E05FE7CFDF5
00007e05fe7d0349  call 0x00007E05FE6E1570
00007e05fe7d034e  jmp 0x00007E05FE7CFDFF
00007e05fe7d0353  call 0x00007E05FE60DC20
00007e05fe7d0358  jmp 0x00007E05FE7CFE35
00007e05fe7d035d  call 0x00007E05FE60A4B0
00007e05fe7d0362  jmp 0x00007E05FE7CFE3F
00007e05fe7d0367  call 0x00007E05FE60DC20
00007e05fe7d036c  jmp 0x00007E05FE7CFE75
00007e05fe7d0371  call 0x00007E05FE60A4B0
00007e05fe7d0376  jmp 0x00007E05FE7CFE7F
00007e05fe7d037b  call 0x00007E05FE60DC20
00007e05fe7d0380  jmp 0x00007E05FE7CFEB5
00007e05fe7d0385  call 0x00007E05FE60B720
00007e05fe7d038a  jmp 0x00007E05FE7CFEBF
00007e05fe7d038f  call 0x00007E05FE60DC20
00007e05fe7d0394  jmp 0x00007E05FE7CFEF8
00007e05fe7d0399  call 0x00007E05FE6E27E0
00007e05fe7d039e  jmp 0x00007E05FE7CFF06
00007e05fe7d03a3  call 0x00007E05FE6E27E0
00007e05fe7d03a8  jmp 0x00007E05FE7CFF17
00007e05fe7d03ad  ucomisd xmm1, xmm13
00007e05fe7d03b2  jp 0x00007E05FE7D03C1
00007e05fe7d03b4  movaps xmm12, [0x00007E05FE3FE030]
00007e05fe7d03bc  jmp 0x00007E05FE7CFF4C
00007e05fe7d03c1  vxorps xmm0, xmm1, xmm13
00007e05fe7d03c6  pextrw r14d, xmm0, 0x03
00007e05fe7d03cc  and r14d, 0x7FF8
00007e05fe7d03d3  cmp r14d, 0x08
00007e05fe7d03d7  jnz 0x00007E05FE7CFF4C
00007e05fe7d03dd  movq r14, xmm13
00007e05fe7d03e2  shl r14, 0x0D
00007e05fe7d03e6  jbe 0x00007E05FE7CFF4C
00007e05fe7d03ec  vorps xmm12, xmm13, [0x00007E05FE3FE040]
00007e05fe7d03f4  jmp 0x00007E05FE7CFF4C
00007e05fe7d03f9  ucomisd xmm1, xmm15
00007e05fe7d03fe  jp 0x00007E05FE7D040D
00007e05fe7d0400  movaps xmm13, [0x00007E05FE3FE030]
00007e05fe7d0408  jmp 0x00007E05FE7CFF81
00007e05fe7d040d  vxorps xmm0, xmm1, xmm15
00007e05fe7d0412  pextrw r14d, xmm0, 0x03
00007e05fe7d0418  and r14d, 0x7FF8
00007e05fe7d041f  cmp r14d, 0x08
00007e05fe7d0423  jnz 0x00007E05FE7CFF81
00007e05fe7d0429  movq r14, xmm15
00007e05fe7d042e  shl r14, 0x0D
00007e05fe7d0432  jbe 0x00007E05FE7CFF81
00007e05fe7d0438  vorps xmm13, xmm15, [0x00007E05FE3FE040]
00007e05fe7d0440  jmp 0x00007E05FE7CFF81
00007e05fe7d0445  ucomisd xmm1, xmm15
00007e05fe7d044a  jp 0x00007E05FE7D0459
00007e05fe7d044c  movaps xmm12, [0x00007E05FE3FE030]
00007e05fe7d0454  jmp 0x00007E05FE7CFFB6
00007e05fe7d0459  vxorps xmm0, xmm1, xmm15
00007e05fe7d045e  pextrw r14d, xmm0, 0x03
00007e05fe7d0464  and r14d, 0x7FF8
00007e05fe7d046b  cmp r14d, 0x08
00007e05fe7d046f  jnz 0x00007E05FE7CFFB6
00007e05fe7d0475  movq r14, xmm15
00007e05fe7d047a  shl r14, 0x0D
00007e05fe7d047e  jbe 0x00007E05FE7CFFB6
00007e05fe7d0484  vorps xmm12, xmm15, [0x00007E05FE3FE040]
00007e05fe7d048c  jmp 0x00007E05FE7CFFB6
00007e05fe7d0491  ucomisd xmm1, xmm15
00007e05fe7d0496  jp 0x00007E05FE7D04A5
00007e05fe7d0498  movaps xmm13, [0x00007E05FE3FE030]
00007e05fe7d04a0  jmp 0x00007E05FE7CFFE3
00007e05fe7d04a5  vxorps xmm0, xmm1, xmm15
00007e05fe7d04aa  pextrw r14d, xmm0, 0x03
00007e05fe7d04b0  and r14d, 0x7FF8
00007e05fe7d04b7  cmp r14d, 0x08
00007e05fe7d04bb  jnz 0x00007E05FE7CFFE3
00007e05fe7d04c1  movq r14, xmm15
00007e05fe7d04c6  shl r14, 0x0D
00007e05fe7d04ca  jbe 0x00007E05FE7CFFE3
00007e05fe7d04d0  vorps xmm13, xmm15, [0x00007E05FE3FE040]
00007e05fe7d04d8  jmp 0x00007E05FE7CFFE3
00007e05fe7d04dd  ucomisd xmm1, xmm15
00007e05fe7d04e2  jp 0x00007E05FE7D04F1
00007e05fe7d04e4  movaps xmm14, [0x00007E05FE3FE030]
00007e05fe7d04ec  jmp 0x00007E05FE7D0018
00007e05fe7d04f1  vxorps xmm0, xmm1, xmm15
00007e05fe7d04f6  pextrw r14d, xmm0, 0x03
00007e05fe7d04fc  and r14d, 0x7FF8
00007e05fe7d0503  cmp r14d, 0x08
00007e05fe7d0507  jnz 0x00007E05FE7D0018
00007e05fe7d050d  movq r14, xmm15
00007e05fe7d0512  shl r14, 0x0D
00007e05fe7d0516  jbe 0x00007E05FE7D0018
00007e05fe7d051c  vorps xmm14, xmm15, [0x00007E05FE3FE040]
00007e05fe7d0524  jmp 0x00007E05FE7D0018
00007e05fe7d0529  call 0x00007E05FE6E27E0
00007e05fe7d052e  jmp 0x00007E05FE7D0029
00007e05fe7d0533  ucomisd xmm15, xmm14
00007e05fe7d0538  jp 0x00007E05FE7D0547
00007e05fe7d053a  movaps xmm13, [0x00007E05FE3FE030]
00007e05fe7d0542  jmp 0x00007E05FE7D0056
00007e05fe7d0547  vxorps xmm0, xmm15, xmm14
00007e05fe7d054c  pextrw r14d, xmm0, 0x03
00007e05fe7d0552  and r14d, 0x7FF8
00007e05fe7d0559  cmp r14d, 0x08
00007e05fe7d055d  jnz 0x00007E05FE7D0056
00007e05fe7d0563  movq r14, xmm14
00007e05fe7d0568  shl r14, 0x0D
00007e05fe7d056c  jbe 0x00007E05FE7D0056
00007e05fe7d0572  vorps xmm13, xmm14, [0x00007E05FE3FE040]
00007e05fe7d057a  jmp 0x00007E05FE7D0056
00007e05fe7d057f  ucomisd xmm1, xmm15
00007e05fe7d0584  jp 0x00007E05FE7D0593
00007e05fe7d0586  movaps xmm14, [0x00007E05FE3FE030]
00007e05fe7d058e  jmp 0x00007E05FE7D008B
00007e05fe7d0593  vxorps xmm0, xmm1, xmm15
00007e05fe7d0598  pextrw r14d, xmm0, 0x03
00007e05fe7d059e  and r14d, 0x7FF8
00007e05fe7d05a5  cmp r14d, 0x08
00007e05fe7d05a9  jnz 0x00007E05FE7D008B
00007e05fe7d05af  movq r14, xmm15
00007e05fe7d05b4  shl r14, 0x0D
00007e05fe7d05b8  jbe 0x00007E05FE7D008B
00007e05fe7d05be  vorps xmm14, xmm15, [0x00007E05FE3FE040]
00007e05fe7d05c6  jmp 0x00007E05FE7D008B
00007e05fe7d05cb  call 0x00007E05FE6E27E0
00007e05fe7d05d0  jmp 0x00007E05FE7D009C
00007e05fe7d05d5  ucomisd xmm15, xmm14
00007e05fe7d05da  jp 0x00007E05FE7D05E9
00007e05fe7d05dc  movaps xmm13, [0x00007E05FE3FE030]
00007e05fe7d05e4  jmp 0x00007E05FE7D00C9
00007e05fe7d05e9  vxorps xmm0, xmm15, xmm14
00007e05fe7d05ee  pextrw r14d, xmm0, 0x03
00007e05fe7d05f4  and r14d, 0x7FF8
00007e05fe7d05fb  cmp r14d, 0x08
00007e05fe7d05ff  jnz 0x00007E05FE7D00C9
00007e05fe7d0605  movq r14, xmm14
00007e05fe7d060a  shl r14, 0x0D
00007e05fe7d060e  jbe 0x00007E05FE7D00C9
00007e05fe7d0614  vorps xmm13, xmm14, [0x00007E05FE3FE040]
00007e05fe7d061c  jmp 0x00007E05FE7D00C9
00007e05fe7d0621  ucomisd xmm1, xmm15
00007e05fe7d0626  jp 0x00007E05FE7D0635
00007e05fe7d0628  movaps xmm14, [0x00007E05FE3FE030]
00007e05fe7d0630  jmp 0x00007E05FE7D00FE
00007e05fe7d0635  vxorps xmm0, xmm1, xmm15
00007e05fe7d063a  pextrw r14d, xmm0, 0x03
00007e05fe7d0640  and r14d, 0x7FF8
00007e05fe7d0647  cmp r14d, 0x08
00007e05fe7d064b  jnz 0x00007E05FE7D00FE
00007e05fe7d0651  movq r14, xmm15
00007e05fe7d0656  shl r14, 0x0D
00007e05fe7d065a  jbe 0x00007E05FE7D00FE
00007e05fe7d0660  vorps xmm14, xmm15, [0x00007E05FE3FE040]
00007e05fe7d0668  jmp 0x00007E05FE7D00FE
00007e05fe7d066d  call 0x00007E05FE6E27E0
00007e05fe7d0672  jmp 0x00007E05FE7D010F
00007e05fe7d0677  ucomisd xmm15, xmm14
00007e05fe7d067c  jp 0x00007E05FE7D068B
00007e05fe7d067e  movaps xmm13, [0x00007E05FE3FE030]
00007e05fe7d0686  jmp 0x00007E05FE7D013C
00007e05fe7d068b  vxorps xmm0, xmm15, xmm14
00007e05fe7d0690  pextrw r14d, xmm0, 0x03
00007e05fe7d0696  and r14d, 0x7FF8
00007e05fe7d069d  cmp r14d, 0x08
00007e05fe7d06a1  jnz 0x00007E05FE7D013C
00007e05fe7d06a7  movq r14, xmm14
00007e05fe7d06ac  shl r14, 0x0D
00007e05fe7d06b0  jbe 0x00007E05FE7D013C
00007e05fe7d06b6  vorps xmm13, xmm14, [0x00007E05FE3FE040]
00007e05fe7d06be  jmp 0x00007E05FE7D013C
00007e05fe7d06c3  ucomisd xmm1, xmm15
00007e05fe7d06c8  jp 0x00007E05FE7D06D7
00007e05fe7d06ca  movaps xmm14, [0x00007E05FE3FE030]
00007e05fe7d06d2  jmp 0x00007E05FE7D0171
00007e05fe7d06d7  vxorps xmm0, xmm1, xmm15
00007e05fe7d06dc  pextrw r14d, xmm0, 0x03
00007e05fe7d06e2  and r14d, 0x7FF8
00007e05fe7d06e9  cmp r14d, 0x08
00007e05fe7d06ed  jnz 0x00007E05FE7D0171
00007e05fe7d06f3  movq r14, xmm15
00007e05fe7d06f8  shl r14, 0x0D
00007e05fe7d06fc  jbe 0x00007E05FE7D0171
00007e05fe7d0702  vorps xmm14, xmm15, [0x00007E05FE3FE040]
00007e05fe7d070a  jmp 0x00007E05FE7D0171
00007e05fe7d070f  call 0x00007E05FE6E27E0
00007e05fe7d0714  jmp 0x00007E05FE7D0182
00007e05fe7d0719  ucomisd xmm15, xmm14
00007e05fe7d071e  jp 0x00007E05FE7D072D
00007e05fe7d0720  movaps xmm13, [0x00007E05FE3FE030]
00007e05fe7d0728  jmp 0x00007E05FE7D01AF
00007e05fe7d072d  vxorps xmm0, xmm15, xmm14
00007e05fe7d0732  pextrw r14d, xmm0, 0x03
00007e05fe7d0738  and r14d, 0x7FF8
00007e05fe7d073f  cmp r14d, 0x08
00007e05fe7d0743  jnz 0x00007E05FE7D01AF
00007e05fe7d0749  movq r14, xmm14
00007e05fe7d074e  shl r14, 0x0D
00007e05fe7d0752  jbe 0x00007E05FE7D01AF
00007e05fe7d0758  vorps xmm13, xmm14, [0x00007E05FE3FE040]
00007e05fe7d0760  jmp 0x00007E05FE7D01AF
00007e05fe7d0765  ucomisd xmm1, xmm15
00007e05fe7d076a  jp 0x00007E05FE7D0779
00007e05fe7d076c  movaps xmm14, [0x00007E05FE3FE030]
00007e05fe7d0774  jmp 0x00007E05FE7D01E4
00007e05fe7d0779  vxorps xmm0, xmm1, xmm15
00007e05fe7d077e  pextrw r14d, xmm0, 0x03
00007e05fe7d0784  and r14d, 0x7FF8
00007e05fe7d078b  cmp r14d, 0x08
00007e05fe7d078f  jnz 0x00007E05FE7D01E4
00007e05fe7d0795  movq r14, xmm15
00007e05fe7d079a  shl r14, 0x0D
00007e05fe7d079e  jbe 0x00007E05FE7D01E4
00007e05fe7d07a4  vorps xmm14, xmm15, [0x00007E05FE3FE040]
00007e05fe7d07ac  jmp 0x00007E05FE7D01E4
00007e05fe7d07b1  call 0x00007E05FE6D59C0
00007e05fe7d07b6  jmp 0x00007E05FE7D01F5
00007e05fe7d07bb  ucomisd xmm15, xmm14
00007e05fe7d07c0  jp 0x00007E05FE7D07CF
00007e05fe7d07c2  movaps xmm13, [0x00007E05FE3FE030]
00007e05fe7d07ca  jmp 0x00007E05FE7D022A
00007e05fe7d07cf  vxorps xmm0, xmm15, xmm14
00007e05fe7d07d4  pextrw eax, xmm0, 0x03
00007e05fe7d07d9  and eax, 0x7FF8
00007e05fe7d07de  cmp eax, 0x08
00007e05fe7d07e1  jnz 0x00007E05FE7D022A
00007e05fe7d07e7  movq rax, xmm14
00007e05fe7d07ec  shl rax, 0x0D
00007e05fe7d07f0  jbe 0x00007E05FE7D022A
00007e05fe7d07f6  vorps xmm13, xmm14, [0x00007E05FE3FE040]
00007e05fe7d07fe  jmp 0x00007E05FE7D022A
00007e05fe7d0803  ucomisd xmm1, xmm15
00007e05fe7d0808  jp 0x00007E05FE7D0817
00007e05fe7d080a  movaps xmm14, [0x00007E05FE3FE030]
00007e05fe7d0812  jmp 0x00007E05FE7D025F
00007e05fe7d0817  vxorps xmm0, xmm1, xmm15
00007e05fe7d081c  pextrw eax, xmm0, 0x03
00007e05fe7d0821  and eax, 0x7FF8
00007e05fe7d0826  cmp eax, 0x08
00007e05fe7d0829  jnz 0x00007E05FE7D025F
00007e05fe7d082f  movq rax, xmm15
00007e05fe7d0834  shl rax, 0x0D
00007e05fe7d0838  jbe 0x00007E05FE7D025F
00007e05fe7d083e  vorps xmm14, xmm15, [0x00007E05FE3FE040]
00007e05fe7d0846  jmp 0x00007E05FE7D025F
00007e05fe7d084b  ucomisd xmm1, xmm15
00007e05fe7d0850  jp 0x00007E05FE7D085F
00007e05fe7d0852  movaps xmm14, [0x00007E05FE3FE030]
00007e05fe7d085a  jmp 0x00007E05FE7D0294
00007e05fe7d085f  vxorps xmm0, xmm1, xmm15
00007e05fe7d0864  pextrw eax, xmm0, 0x03
00007e05fe7d0869  and eax, 0x7FF8
00007e05fe7d086e  cmp eax, 0x08
00007e05fe7d0871  jnz 0x00007E05FE7D0294
00007e05fe7d0877  movq rax, xmm15
00007e05fe7d087c  shl rax, 0x0D
00007e05fe7d0880  jbe 0x00007E05FE7D0294
00007e05fe7d0886  vorps xmm14, xmm15, [0x00007E05FE3FE040]
00007e05fe7d088e  jmp 0x00007E05FE7D0294
00007e05fe7d0893  call 0x00007E05FE60E120
00007e05fe7d0898  jmp 0x00007E05FE7D02AF
00007e05fe7d089d  int3
00007e05fe7d089e  nop
00007e05fe7d08a0  mov eax, [r15+0x58]
00007e05fe7d08a4  lea r14d, [eax+0x01]
00007e05fe7d08a9  mov [rsp+0x10], r14d
00007e05fe7d08ae  mov r14d, r14d
00007e05fe7d08b1  mov [r15+0x58], r14
00007e05fe7d08b5  xor eax, eax
00007e05fe7d08b7  mov r14d, [rsp+0x10]
00007e05fe7d08bc  cmp r14d, 0x1F4
00007e05fe7d08c3  cmc
00007e05fe7d08c4  lahf
00007e05fe7d08c5  seto al
00007e05fe7d08c8  mov [r15+0x108], eax
00007e05fe7d08cf  mov eax, [r15+0x108]
00007e05fe7d08d6  sahf
00007e05fe7d08d7  jnz 0x00007E05FE7D0909
00007e05fe7d08d9  cmp dword ptr [r15+0x318], 0x00
00007e05fe7d08e1  jz 0x00007E05FE7D1410
00007e05fe7d08e7  nop [rax+rax*1], ax
00007e05fe7d08f0  nop [rax+rax*1], eax
00007e05fe7d08f8  mov eax, 0x410134
00007e05fe7d08fd  mov [r15+0x100], rax
00007e05fe7d0904  jmp 0x00007E05FE5FE110
00007e05fe7d0909  cmp dword ptr [r15+0x318], 0x00
00007e05fe7d0911  jz 0x00007E05FE7D0940
00007e05fe7d0917  nop [rax+rax*1], ax
00007e05fe7d0920  nop [rax+rax*1], eax
00007e05fe7d0928  mov eax, 0x410084
00007e05fe7d092d  mov [r15+0x100], rax
00007e05fe7d0934  jmp 0x00007E05FE5FE110
00007e05fe7d0939  int3
00007e05fe7d093a  int3
00007e05fe7d093b  nop [rax+rax*1], eax
00007e05fe7d0940  mov qword ptr [r15+0x60], 0x00
00007e05fe7d0948  mov rax, [r15+0x50]
00007e05fe7d094c  mov [r15+0x68], rax
00007e05fe7d0950  mov r14, [r15+0x40]
00007e05fe7d0954  mov r12, [r13+r14*1]
00007e05fe7d0959  lea r11, [r14+0x08]
00007e05fe7d095d  mov r10, [r13+r11*1]
00007e05fe7d0962  movq xmm1, r12
00007e05fe7d0967  movq xmm15, r10
00007e05fe7d096c  movq xmm1, xmm1
00007e05fe7d0970  movq xmm1, xmm1
00007e05fe7d0974  movaps [r15+0x120], xmm1
00007e05fe7d097c  movq xmm15, xmm15
00007e05fe7d0981  movq xmm15, xmm15
00007e05fe7d0986  movaps [r15+0x130], xmm15
00007e05fe7d098e  lea r12, [r14+0x10]
00007e05fe7d0992  mov r11, [r13+r12*1]
00007e05fe7d0997  lea r12, [r14+0x18]
00007e05fe7d099b  mov r10, [r13+r12*1]
00007e05fe7d09a0  movq xmm1, r11
00007e05fe7d09a5  movq xmm15, r10
00007e05fe7d09aa  movq xmm1, xmm1
00007e05fe7d09ae  movq xmm1, xmm1
00007e05fe7d09b2  movaps [r15+0x140], xmm1
00007e05fe7d09ba  movq xmm15, xmm15
00007e05fe7d09bf  movq xmm15, xmm15
00007e05fe7d09c4  movaps [r15+0x150], xmm15
00007e05fe7d09cc  lea r12, [r14+0x20]
00007e05fe7d09d0  mov r11, [r13+r12*1]
00007e05fe7d09d5  lea r12, [r14+0x28]
00007e05fe7d09d9  mov r10, [r13+r12*1]
00007e05fe7d09de  movq xmm1, r11
00007e05fe7d09e3  movq xmm15, r10
00007e05fe7d09e8  movq xmm1, xmm1
00007e05fe7d09ec  movq xmm1, xmm1
00007e05fe7d09f0  movaps [r15+0x160], xmm1
00007e05fe7d09f8  movq xmm15, xmm15
00007e05fe7d09fd  movq xmm15, xmm15
00007e05fe7d0a02  movaps [r15+0x170], xmm15
00007e05fe7d0a0a  lea r12, [r14+0x30]
00007e05fe7d0a0e  mov r11, [r13+r12*1]
00007e05fe7d0a13  lea r12, [r14+0x38]
00007e05fe7d0a17  mov r14, [r13+r12*1]
00007e05fe7d0a1c  movq xmm1, r11
00007e05fe7d0a21  movq xmm15, r14
00007e05fe7d0a26  movq xmm1, xmm1
00007e05fe7d0a2a  movq xmm1, xmm1
00007e05fe7d0a2e  movaps [r15+0x180], xmm1
00007e05fe7d0a36  movq xmm15, xmm15
00007e05fe7d0a3b  movq xmm15, xmm15
00007e05fe7d0a40  movaps [r15+0x210], xmm15
00007e05fe7d0a48  mov r14, [r15+0x48]
00007e05fe7d0a4c  mov [r15+0x78], r14
00007e05fe7d0a50  mov r12, [r13+r14*1]
00007e05fe7d0a55  movq xmm1, r12
00007e05fe7d0a5a  lea r12, [r14+0x40]
00007e05fe7d0a5e  mov r11, [r13+r12*1]
00007e05fe7d0a63  movq xmm15, r11
00007e05fe7d0a68  lea r12, [r14+0x80]
00007e05fe7d0a6f  mov r11, [r13+r12*1]
00007e05fe7d0a74  movq xmm14, r11
00007e05fe7d0a79  movaps xmm13, [r15+0x120]
00007e05fe7d0a81  movq r12, xmm13
00007e05fe7d0a86  movq r11, xmm1
00007e05fe7d0a8b  vmovq xmm1, r12
00007e05fe7d0a90  vmovq xmm13, r11
00007e05fe7d0a95  movaps xmm12, xmm1
00007e05fe7d0a99  mulsd xmm12, xmm13
00007e05fe7d0a9e  ucomisd xmm12, xmm12
00007e05fe7d0aa3  jp 0x00007E05FE7D0F06
00007e05fe7d0aa9  movq xmm12, xmm12
00007e05fe7d0aae  movaps xmm1, [r15+0x130]
00007e05fe7d0ab6  movq r12, xmm1
00007e05fe7d0abb  movq r11, xmm15
00007e05fe7d0ac0  vmovq xmm1, r12
00007e05fe7d0ac5  vmovq xmm15, r11
00007e05fe7d0aca  movaps xmm13, xmm1
00007e05fe7d0ace  mulsd xmm13, xmm15
00007e05fe7d0ad3  ucomisd xmm13, xmm13
00007e05fe7d0ad8  jp 0x00007E05FE7D0F52
00007e05fe7d0ade  movq xmm13, xmm13
00007e05fe7d0ae3  movq r12, xmm12
00007e05fe7d0ae8  movaps xmm1, [r15+0x110]
00007e05fe7d0af0  movq r11, xmm1
00007e05fe7d0af5  vmovq xmm1, r12
00007e05fe7d0afa  vmovq xmm15, r11
00007e05fe7d0aff  movaps xmm12, xmm1
00007e05fe7d0b03  addsd xmm12, xmm15
00007e05fe7d0b08  ucomisd xmm12, xmm12
00007e05fe7d0b0d  jp 0x00007E05FE7D0F9E
00007e05fe7d0b13  movq xmm12, xmm12
00007e05fe7d0b18  movq r12, xmm12
00007e05fe7d0b1d  movq r11, xmm13
00007e05fe7d0b22  vmovq xmm1, r12
00007e05fe7d0b27  vmovq xmm15, r11
00007e05fe7d0b2c  movaps xmm13, xmm1
00007e05fe7d0b30  addsd xmm13, xmm15
00007e05fe7d0b35  ucomisd xmm13, xmm13
00007e05fe7d0b3a  jp 0x00007E05FE7D0FEA
00007e05fe7d0b40  movq xmm13, xmm13
00007e05fe7d0b45  movaps xmm1, [r15+0x140]
00007e05fe7d0b4d  movq r12, xmm1
00007e05fe7d0b52  movq r11, xmm14
00007e05fe7d0b57  vmovq xmm1, r12
00007e05fe7d0b5c  vmovq xmm15, r11
00007e05fe7d0b61  movaps xmm14, xmm1
00007e05fe7d0b65  mulsd xmm14, xmm15
00007e05fe7d0b6a  ucomisd xmm14, xmm14
00007e05fe7d0b6f  jp 0x00007E05FE7D1036
00007e05fe7d0b75  movq xmm14, xmm14
00007e05fe7d0b7a  lea r12, [r14+0xC0]
00007e05fe7d0b81  mov r11, [r13+r12*1]
00007e05fe7d0b86  movq xmm1, r11
00007e05fe7d0b8b  movq r12, xmm13
00007e05fe7d0b90  movq r11, xmm14
00007e05fe7d0b95  vmovq xmm15, r12
00007e05fe7d0b9a  vmovq xmm14, r11
00007e05fe7d0b9f  movaps xmm13, xmm15
00007e05fe7d0ba3  addsd xmm13, xmm14
00007e05fe7d0ba8  ucomisd xmm13, xmm13
00007e05fe7d0bad  jp 0x00007E05FE7D108C
00007e05fe7d0bb3  movq xmm13, xmm13
00007e05fe7d0bb8  movaps xmm15, [r15+0x150]
00007e05fe7d0bc0  movq r12, xmm15
00007e05fe7d0bc5  movq r11, xmm1
00007e05fe7d0bca  vmovq xmm1, r12
00007e05fe7d0bcf  vmovq xmm15, r11
00007e05fe7d0bd4  movaps xmm14, xmm1
00007e05fe7d0bd8  mulsd xmm14, xmm15
00007e05fe7d0bdd  ucomisd xmm14, xmm14
00007e05fe7d0be2  jp 0x00007E05FE7D10D8
00007e05fe7d0be8  movq xmm14, xmm14
00007e05fe7d0bed  lea r12, [r14+0x100]
00007e05fe7d0bf4  mov r11, [r13+r12*1]
00007e05fe7d0bf9  movq xmm1, r11
00007e05fe7d0bfe  movq r12, xmm13
00007e05fe7d0c03  movq r11, xmm14
00007e05fe7d0c08  vmovq xmm15, r12
00007e05fe7d0c0d  vmovq xmm14, r11
00007e05fe7d0c12  movaps xmm13, xmm15
00007e05fe7d0c16  addsd xmm13, xmm14
00007e05fe7d0c1b  ucomisd xmm13, xmm13
00007e05fe7d0c20  jp 0x00007E05FE7D112E
00007e05fe7d0c26  movq xmm13, xmm13
00007e05fe7d0c2b  movaps xmm15, [r15+0x160]
00007e05fe7d0c33  movq r12, xmm15
00007e05fe7d0c38  movq r11, xmm1
00007e05fe7d0c3d  vmovq xmm1, r12
00007e05fe7d0c42  vmovq xmm15, r11
00007e05fe7d0c47  movaps xmm14, xmm1
00007e05fe7d0c4b  mulsd xmm14, xmm15
00007e05fe7d0c50  ucomisd xmm14, xmm14
00007e05fe7d0c55  jp 0x00007E05FE7D117A
00007e05fe7d0c5b  movq xmm14, xmm14
00007e05fe7d0c60  lea r12, [r14+0x140]
00007e05fe7d0c67  mov r11, [r13+r12*1]
00007e05fe7d0c6c  movq xmm1, r11
00007e05fe7d0c71  movq r12, xmm13
00007e05fe7d0c76  movq r11, xmm14
00007e05fe7d0c7b  vmovq xmm15, r12
00007e05fe7d0c80  vmovq xmm14, r11
00007e05fe7d0c85  movaps xmm13, xmm15
00007e05fe7d0c89  addsd xmm13, xmm14
00007e05fe7d0c8e  ucomisd xmm13, xmm13
00007e05fe7d0c93  jp 0x00007E05FE7D11D0
00007e05fe7d0c99  movq xmm13, xmm13
00007e05fe7d0c9e  movaps xmm15, [r15+0x170]
00007e05fe7d0ca6  movq r12, xmm15
00007e05fe7d0cab  movq r11, xmm1
00007e05fe7d0cb0  vmovq xmm1, r12
00007e05fe7d0cb5  vmovq xmm15, r11
00007e05fe7d0cba  movaps xmm14, xmm1
00007e05fe7d0cbe  mulsd xmm14, xmm15
00007e05fe7d0cc3  ucomisd xmm14, xmm14
00007e05fe7d0cc8  jp 0x00007E05FE7D121C
00007e05fe7d0cce  movq xmm14, xmm14
00007e05fe7d0cd3  lea r12, [r14+0x180]
00007e05fe7d0cda  mov r11, [r13+r12*1]
00007e05fe7d0cdf  movq xmm1, r11
00007e05fe7d0ce4  movq r12, xmm13
00007e05fe7d0ce9  movq r11, xmm14
00007e05fe7d0cee  vmovq xmm15, r12
00007e05fe7d0cf3  vmovq xmm14, r11
00007e05fe7d0cf8  movaps xmm13, xmm15
00007e05fe7d0cfc  addsd xmm13, xmm14
00007e05fe7d0d01  ucomisd xmm13, xmm13
00007e05fe7d0d06  jp 0x00007E05FE7D1272
00007e05fe7d0d0c  movq xmm13, xmm13
00007e05fe7d0d11  movaps xmm15, [r15+0x180]
00007e05fe7d0d19  movq r12, xmm15
00007e05fe7d0d1e  movq r11, xmm1
00007e05fe7d0d23  vmovq xmm1, r12
00007e05fe7d0d28  vmovq xmm15, r11
00007e05fe7d0d2d  movaps xmm14, xmm1
00007e05fe7d0d31  mulsd xmm14, xmm15
00007e05fe7d0d36  ucomisd xmm14, xmm14
00007e05fe7d0d3b  jp 0x00007E05FE7D12BE
00007e05fe7d0d41  movq xmm14, xmm14
00007e05fe7d0d46  lea r12, [r14+0x1C0]
00007e05fe7d0d4d  mov r14, [r13+r12*1]
00007e05fe7d0d52  movq xmm1, r14
00007e05fe7d0d57  movaps [r15+0x240], xmm1
00007e05fe7d0d5f  movq r14, xmm13
00007e05fe7d0d64  movq r12, xmm14
00007e05fe7d0d69  vmovq xmm15, r14
00007e05fe7d0d6e  vmovq xmm14, r12
00007e05fe7d0d73  movaps xmm13, xmm15
00007e05fe7d0d77  addsd xmm13, xmm14
00007e05fe7d0d7c  ucomisd xmm13, xmm13
00007e05fe7d0d81  jp 0x00007E05FE7D1314
00007e05fe7d0d87  movq xmm13, xmm13
00007e05fe7d0d8c  movaps xmm15, [r15+0x210]
00007e05fe7d0d94  movq r14, xmm15
00007e05fe7d0d99  movq r12, xmm1
00007e05fe7d0d9e  vmovq xmm1, r14
00007e05fe7d0da3  vmovq xmm15, r12
00007e05fe7d0da8  movaps xmm14, xmm1
00007e05fe7d0dac  mulsd xmm14, xmm15
00007e05fe7d0db1  ucomisd xmm14, xmm14
00007e05fe7d0db6  jp 0x00007E05FE7D1360
00007e05fe7d0dbc  movq xmm14, xmm14
00007e05fe7d0dc1  movaps [r15+0x230], xmm14
00007e05fe7d0dc9  movq r14, xmm13
00007e05fe7d0dce  movq r12, xmm14
00007e05fe7d0dd3  vmovq xmm1, r14
00007e05fe7d0dd8  vmovq xmm15, r12
00007e05fe7d0ddd  movaps xmm14, xmm1
00007e05fe7d0de1  addsd xmm14, xmm15
00007e05fe7d0de6  ucomisd xmm14, xmm14
00007e05fe7d0deb  jp 0x00007E05FE7D13AC
00007e05fe7d0df1  movq xmm14, xmm14
00007e05fe7d0df6  movaps [r15+0x220], xmm14
00007e05fe7d0dfe  movq r14, xmm14
00007e05fe7d0e03  mov [r13+rax*1], r14
00007e05fe7d0e08  mov qword ptr [r15+0x70], 0x08
00007e05fe7d0e10  xor eax, eax
00007e05fe7d0e12  mov r14d, 0x08
00007e05fe7d0e18  mov r12d, 0x40
00007e05fe7d0e1e  cmp r14, r12
00007e05fe7d0e21  cmc
00007e05fe7d0e22  lahf
00007e05fe7d0e23  seto al
00007e05fe7d0e26  mov [r15+0x108], eax
00007e05fe7d0e2d  mov eax, [r15+0x108]
00007e05fe7d0e34  sahf
00007e05fe7d0e35  jnz 0x00007E05FE7D0E67
00007e05fe7d0e37  cmp dword ptr [r15+0x318], 0x00
00007e05fe7d0e3f  jz 0x00007E05FE7CFD40
00007e05fe7d0e45  nop [rax+rax*1], ax
00007e05fe7d0e4e  nop [rax+rax*1], eax
00007e05fe7d0e56  mov eax, 0x410118
00007e05fe7d0e5b  mov [r15+0x100], rax
00007e05fe7d0e62  jmp 0x00007E05FE5FE110
00007e05fe7d0e67  cmp dword ptr [r15+0x318], 0x00
00007e05fe7d0e6f  jz 0x00007E05FE7CF3F0
00007e05fe7d0e75  nop [rax+rax*1], ax
00007e05fe7d0e7e  nop [rax+rax*1], eax
00007e05fe7d0e86  mov eax, 0x4100A4
00007e05fe7d0e8b  mov [r15+0x100], rax
00007e05fe7d0e92  jmp 0x00007E05FE5FE110
00007e05fe7d0e97  int3
00007e05fe7d0e98  call 0x00007E05FE6E27E0
00007e05fe7d0e9d  jmp 0x00007E05FE7D0959
00007e05fe7d0ea2  call 0x00007E05FE6AE800
00007e05fe7d0ea7  jmp 0x00007E05FE7D0962
00007e05fe7d0eac  call 0x00007E05FE6C0370
00007e05fe7d0eb1  jmp 0x00007E05FE7D0997
00007e05fe7d0eb6  call 0x00007E05FE6BF100
00007e05fe7d0ebb  jmp 0x00007E05FE7D09A0
00007e05fe7d0ec0  call 0x00007E05FE6C0370
00007e05fe7d0ec5  jmp 0x00007E05FE7D09D5
00007e05fe7d0eca  call 0x00007E05FE6BF100
00007e05fe7d0ecf  jmp 0x00007E05FE7D09DE
00007e05fe7d0ed4  call 0x00007E05FE6C0370
00007e05fe7d0ed9  jmp 0x00007E05FE7D0A13
00007e05fe7d0ede  call 0x00007E05FE6C3AE0
00007e05fe7d0ee3  jmp 0x00007E05FE7D0A1C
00007e05fe7d0ee8  call 0x00007E05FE6E27E0
00007e05fe7d0eed  jmp 0x00007E05FE7D0A55
00007e05fe7d0ef2  call 0x00007E05FE6C0370
00007e05fe7d0ef7  jmp 0x00007E05FE7D0A63
00007e05fe7d0efc  call 0x00007E05FE6C0370
00007e05fe7d0f01  jmp 0x00007E05FE7D0A74
00007e05fe7d0f06  ucomisd xmm1, xmm13
00007e05fe7d0f0b  jp 0x00007E05FE7D0F1A
00007e05fe7d0f0d  movaps xmm12, [0x00007E05FE3FE030]
00007e05fe7d0f15  jmp 0x00007E05FE7D0AA9
00007e05fe7d0f1a  vxorps xmm0, xmm1, xmm13
00007e05fe7d0f1f  pextrw r12d, xmm0, 0x03
00007e05fe7d0f25  and r12d, 0x7FF8
00007e05fe7d0f2c  cmp r12d, 0x08
00007e05fe7d0f30  jnz 0x00007E05FE7D0AA9
00007e05fe7d0f36  movq r12, xmm13
00007e05fe7d0f3b  shl r12, 0x0D
00007e05fe7d0f3f  jbe 0x00007E05FE7D0AA9
00007e05fe7d0f45  vorps xmm12, xmm13, [0x00007E05FE3FE040]
00007e05fe7d0f4d  jmp 0x00007E05FE7D0AA9
00007e05fe7d0f52  ucomisd xmm1, xmm15
00007e05fe7d0f57  jp 0x00007E05FE7D0F66
00007e05fe7d0f59  movaps xmm13, [0x00007E05FE3FE030]
00007e05fe7d0f61  jmp 0x00007E05FE7D0ADE
00007e05fe7d0f66  vxorps xmm0, xmm1, xmm15
00007e05fe7d0f6b  pextrw r12d, xmm0, 0x03
00007e05fe7d0f71  and r12d, 0x7FF8
00007e05fe7d0f78  cmp r12d, 0x08
00007e05fe7d0f7c  jnz 0x00007E05FE7D0ADE
00007e05fe7d0f82  movq r12, xmm15
00007e05fe7d0f87  shl r12, 0x0D
00007e05fe7d0f8b  jbe 0x00007E05FE7D0ADE
00007e05fe7d0f91  vorps xmm13, xmm15, [0x00007E05FE3FE040]
00007e05fe7d0f99  jmp 0x00007E05FE7D0ADE
00007e05fe7d0f9e  ucomisd xmm1, xmm15
00007e05fe7d0fa3  jp 0x00007E05FE7D0FB2
00007e05fe7d0fa5  movaps xmm12, [0x00007E05FE3FE030]
00007e05fe7d0fad  jmp 0x00007E05FE7D0B13
00007e05fe7d0fb2  vxorps xmm0, xmm1, xmm15
00007e05fe7d0fb7  pextrw r12d, xmm0, 0x03
00007e05fe7d0fbd  and r12d, 0x7FF8
00007e05fe7d0fc4  cmp r12d, 0x08
00007e05fe7d0fc8  jnz 0x00007E05FE7D0B13
00007e05fe7d0fce  movq r12, xmm15
00007e05fe7d0fd3  shl r12, 0x0D
00007e05fe7d0fd7  jbe 0x00007E05FE7D0B13
00007e05fe7d0fdd  vorps xmm12, xmm15, [0x00007E05FE3FE040]
00007e05fe7d0fe5  jmp 0x00007E05FE7D0B13
00007e05fe7d0fea  ucomisd xmm1, xmm15
00007e05fe7d0fef  jp 0x00007E05FE7D0FFE
00007e05fe7d0ff1  movaps xmm13, [0x00007E05FE3FE030]
00007e05fe7d0ff9  jmp 0x00007E05FE7D0B40
00007e05fe7d0ffe  vxorps xmm0, xmm1, xmm15
00007e05fe7d1003  pextrw r12d, xmm0, 0x03
00007e05fe7d1009  and r12d, 0x7FF8
00007e05fe7d1010  cmp r12d, 0x08
00007e05fe7d1014  jnz 0x00007E05FE7D0B40
00007e05fe7d101a  movq r12, xmm15
00007e05fe7d101f  shl r12, 0x0D
00007e05fe7d1023  jbe 0x00007E05FE7D0B40
00007e05fe7d1029  vorps xmm13, xmm15, [0x00007E05FE3FE040]
00007e05fe7d1031  jmp 0x00007E05FE7D0B40
00007e05fe7d1036  ucomisd xmm1, xmm15
00007e05fe7d103b  jp 0x00007E05FE7D104A
00007e05fe7d103d  movaps xmm14, [0x00007E05FE3FE030]
00007e05fe7d1045  jmp 0x00007E05FE7D0B75
00007e05fe7d104a  vxorps xmm0, xmm1, xmm15
00007e05fe7d104f  pextrw r12d, xmm0, 0x03
00007e05fe7d1055  and r12d, 0x7FF8
00007e05fe7d105c  cmp r12d, 0x08
00007e05fe7d1060  jnz 0x00007E05FE7D0B75
00007e05fe7d1066  movq r12, xmm15
00007e05fe7d106b  shl r12, 0x0D
00007e05fe7d106f  jbe 0x00007E05FE7D0B75
00007e05fe7d1075  vorps xmm14, xmm15, [0x00007E05FE3FE040]
00007e05fe7d107d  jmp 0x00007E05FE7D0B75
00007e05fe7d1082  call 0x00007E05FE6C0370
00007e05fe7d1087  jmp 0x00007E05FE7D0B86
00007e05fe7d108c  ucomisd xmm15, xmm14
00007e05fe7d1091  jp 0x00007E05FE7D10A0
00007e05fe7d1093  movaps xmm13, [0x00007E05FE3FE030]
00007e05fe7d109b  jmp 0x00007E05FE7D0BB3
00007e05fe7d10a0  vxorps xmm0, xmm15, xmm14
00007e05fe7d10a5  pextrw r12d, xmm0, 0x03
00007e05fe7d10ab  and r12d, 0x7FF8
00007e05fe7d10b2  cmp r12d, 0x08
00007e05fe7d10b6  jnz 0x00007E05FE7D0BB3
00007e05fe7d10bc  movq r12, xmm14
00007e05fe7d10c1  shl r12, 0x0D
00007e05fe7d10c5  jbe 0x00007E05FE7D0BB3
00007e05fe7d10cb  vorps xmm13, xmm14, [0x00007E05FE3FE040]
00007e05fe7d10d3  jmp 0x00007E05FE7D0BB3
00007e05fe7d10d8  ucomisd xmm1, xmm15
00007e05fe7d10dd  jp 0x00007E05FE7D10EC
00007e05fe7d10df  movaps xmm14, [0x00007E05FE3FE030]
00007e05fe7d10e7  jmp 0x00007E05FE7D0BE8
00007e05fe7d10ec  vxorps xmm0, xmm1, xmm15
00007e05fe7d10f1  pextrw r12d, xmm0, 0x03
00007e05fe7d10f7  and r12d, 0x7FF8
00007e05fe7d10fe  cmp r12d, 0x08
00007e05fe7d1102  jnz 0x00007E05FE7D0BE8
00007e05fe7d1108  movq r12, xmm15
00007e05fe7d110d  shl r12, 0x0D
00007e05fe7d1111  jbe 0x00007E05FE7D0BE8
00007e05fe7d1117  vorps xmm14, xmm15, [0x00007E05FE3FE040]
00007e05fe7d111f  jmp 0x00007E05FE7D0BE8
00007e05fe7d1124  call 0x00007E05FE6C0370
00007e05fe7d1129  jmp 0x00007E05FE7D0BF9
00007e05fe7d112e  ucomisd xmm15, xmm14
00007e05fe7d1133  jp 0x00007E05FE7D1142
00007e05fe7d1135  movaps xmm13, [0x00007E05FE3FE030]
00007e05fe7d113d  jmp 0x00007E05FE7D0C26
00007e05fe7d1142  vxorps xmm0, xmm15, xmm14
00007e05fe7d1147  pextrw r12d, xmm0, 0x03
00007e05fe7d114d  and r12d, 0x7FF8
00007e05fe7d1154  cmp r12d, 0x08
00007e05fe7d1158  jnz 0x00007E05FE7D0C26
00007e05fe7d115e  movq r12, xmm14
00007e05fe7d1163  shl r12, 0x0D
00007e05fe7d1167  jbe 0x00007E05FE7D0C26
00007e05fe7d116d  vorps xmm13, xmm14, [0x00007E05FE3FE040]
00007e05fe7d1175  jmp 0x00007E05FE7D0C26
00007e05fe7d117a  ucomisd xmm1, xmm15
00007e05fe7d117f  jp 0x00007E05FE7D118E
00007e05fe7d1181  movaps xmm14, [0x00007E05FE3FE030]
00007e05fe7d1189  jmp 0x00007E05FE7D0C5B
00007e05fe7d118e  vxorps xmm0, xmm1, xmm15
00007e05fe7d1193  pextrw r12d, xmm0, 0x03
00007e05fe7d1199  and r12d, 0x7FF8
00007e05fe7d11a0  cmp r12d, 0x08
00007e05fe7d11a4  jnz 0x00007E05FE7D0C5B
00007e05fe7d11aa  movq r12, xmm15
00007e05fe7d11af  shl r12, 0x0D
00007e05fe7d11b3  jbe 0x00007E05FE7D0C5B
00007e05fe7d11b9  vorps xmm14, xmm15, [0x00007E05FE3FE040]
00007e05fe7d11c1  jmp 0x00007E05FE7D0C5B
00007e05fe7d11c6  call 0x00007E05FE6C0370
00007e05fe7d11cb  jmp 0x00007E05FE7D0C6C
00007e05fe7d11d0  ucomisd xmm15, xmm14
00007e05fe7d11d5  jp 0x00007E05FE7D11E4
00007e05fe7d11d7  movaps xmm13, [0x00007E05FE3FE030]
00007e05fe7d11df  jmp 0x00007E05FE7D0C99
00007e05fe7d11e4  vxorps xmm0, xmm15, xmm14
00007e05fe7d11e9  pextrw r12d, xmm0, 0x03
00007e05fe7d11ef  and r12d, 0x7FF8
00007e05fe7d11f6  cmp r12d, 0x08
00007e05fe7d11fa  jnz 0x00007E05FE7D0C99
00007e05fe7d1200  movq r12, xmm14
00007e05fe7d1205  shl r12, 0x0D
00007e05fe7d1209  jbe 0x00007E05FE7D0C99
00007e05fe7d120f  vorps xmm13, xmm14, [0x00007E05FE3FE040]
00007e05fe7d1217  jmp 0x00007E05FE7D0C99
00007e05fe7d121c  ucomisd xmm1, xmm15
00007e05fe7d1221  jp 0x00007E05FE7D1230
00007e05fe7d1223  movaps xmm14, [0x00007E05FE3FE030]
00007e05fe7d122b  jmp 0x00007E05FE7D0CCE
00007e05fe7d1230  vxorps xmm0, xmm1, xmm15
00007e05fe7d1235  pextrw r12d, xmm0, 0x03
00007e05fe7d123b  and r12d, 0x7FF8
00007e05fe7d1242  cmp r12d, 0x08
00007e05fe7d1246  jnz 0x00007E05FE7D0CCE
00007e05fe7d124c  movq r12, xmm15
00007e05fe7d1251  shl r12, 0x0D
00007e05fe7d1255  jbe 0x00007E05FE7D0CCE
00007e05fe7d125b  vorps xmm14, xmm15, [0x00007E05FE3FE040]
00007e05fe7d1263  jmp 0x00007E05FE7D0CCE
00007e05fe7d1268  call 0x00007E05FE6C0370
00007e05fe7d126d  jmp 0x00007E05FE7D0CDF
00007e05fe7d1272  ucomisd xmm15, xmm14
00007e05fe7d1277  jp 0x00007E05FE7D1286
00007e05fe7d1279  movaps xmm13, [0x00007E05FE3FE030]
00007e05fe7d1281  jmp 0x00007E05FE7D0D0C
00007e05fe7d1286  vxorps xmm0, xmm15, xmm14
00007e05fe7d128b  pextrw r12d, xmm0, 0x03
00007e05fe7d1291  and r12d, 0x7FF8
00007e05fe7d1298  cmp r12d, 0x08
00007e05fe7d129c  jnz 0x00007E05FE7D0D0C
00007e05fe7d12a2  movq r12, xmm14
00007e05fe7d12a7  shl r12, 0x0D
00007e05fe7d12ab  jbe 0x00007E05FE7D0D0C
00007e05fe7d12b1  vorps xmm13, xmm14, [0x00007E05FE3FE040]
00007e05fe7d12b9  jmp 0x00007E05FE7D0D0C
00007e05fe7d12be  ucomisd xmm1, xmm15
00007e05fe7d12c3  jp 0x00007E05FE7D12D2
00007e05fe7d12c5  movaps xmm14, [0x00007E05FE3FE030]
00007e05fe7d12cd  jmp 0x00007E05FE7D0D41
00007e05fe7d12d2  vxorps xmm0, xmm1, xmm15
00007e05fe7d12d7  pextrw r12d, xmm0, 0x03
00007e05fe7d12dd  and r12d, 0x7FF8
00007e05fe7d12e4  cmp r12d, 0x08
00007e05fe7d12e8  jnz 0x00007E05FE7D0D41
00007e05fe7d12ee  movq r12, xmm15
00007e05fe7d12f3  shl r12, 0x0D
00007e05fe7d12f7  jbe 0x00007E05FE7D0D41
00007e05fe7d12fd  vorps xmm14, xmm15, [0x00007E05FE3FE040]
00007e05fe7d1305  jmp 0x00007E05FE7D0D41
00007e05fe7d130a  call 0x00007E05FE6C3AE0
00007e05fe7d130f  jmp 0x00007E05FE7D0D52
00007e05fe7d1314  ucomisd xmm15, xmm14
00007e05fe7d1319  jp 0x00007E05FE7D1328
00007e05fe7d131b  movaps xmm13, [0x00007E05FE3FE030]
00007e05fe7d1323  jmp 0x00007E05FE7D0D87
00007e05fe7d1328  vxorps xmm0, xmm15, xmm14
00007e05fe7d132d  pextrw r14d, xmm0, 0x03
00007e05fe7d1333  and r14d, 0x7FF8
00007e05fe7d133a  cmp r14d, 0x08
00007e05fe7d133e  jnz 0x00007E05FE7D0D87
00007e05fe7d1344  movq r14, xmm14
00007e05fe7d1349  shl r14, 0x0D
00007e05fe7d134d  jbe 0x00007E05FE7D0D87
00007e05fe7d1353  vorps xmm13, xmm14, [0x00007E05FE3FE040]
00007e05fe7d135b  jmp 0x00007E05FE7D0D87
00007e05fe7d1360  ucomisd xmm1, xmm15
00007e05fe7d1365  jp 0x00007E05FE7D1374
00007e05fe7d1367  movaps xmm14, [0x00007E05FE3FE030]
00007e05fe7d136f  jmp 0x00007E05FE7D0DBC
00007e05fe7d1374  vxorps xmm0, xmm1, xmm15
00007e05fe7d1379  pextrw r14d, xmm0, 0x03
00007e05fe7d137f  and r14d, 0x7FF8
00007e05fe7d1386  cmp r14d, 0x08
00007e05fe7d138a  jnz 0x00007E05FE7D0DBC
00007e05fe7d1390  movq r14, xmm15
00007e05fe7d1395  shl r14, 0x0D
00007e05fe7d1399  jbe 0x00007E05FE7D0DBC
00007e05fe7d139f  vorps xmm14, xmm15, [0x00007E05FE3FE040]
00007e05fe7d13a7  jmp 0x00007E05FE7D0DBC
00007e05fe7d13ac  ucomisd xmm1, xmm15
00007e05fe7d13b1  jp 0x00007E05FE7D13C0
00007e05fe7d13b3  movaps xmm14, [0x00007E05FE3FE030]
00007e05fe7d13bb  jmp 0x00007E05FE7D0DF1
00007e05fe7d13c0  vxorps xmm0, xmm1, xmm15
00007e05fe7d13c5  pextrw r14d, xmm0, 0x03
00007e05fe7d13cb  and r14d, 0x7FF8
00007e05fe7d13d2  cmp r14d, 0x08
00007e05fe7d13d6  jnz 0x00007E05FE7D0DF1
00007e05fe7d13dc  movq r14, xmm15
00007e05fe7d13e1  shl r14, 0x0D
00007e05fe7d13e5  jbe 0x00007E05FE7D0DF1
00007e05fe7d13eb  vorps xmm14, xmm15, [0x00007E05FE3FE040]
00007e05fe7d13f3  jmp 0x00007E05FE7D0DF1
00007e05fe7d13f8  call 0x00007E05FE60E120
00007e05fe7d13fd  jmp 0x00007E05FE7D0E08
00007e05fe7d1402  int3
00007e05fe7d1403  nop [rax+rax*1], ax
00007e05fe7d140c  nop [rax], eax
00007e05fe7d1410  mov qword ptr [r15+0x40], 0x420000
00007e05fe7d1418  mov eax, 0x4201B8
00007e05fe7d141d  mov r14, [r13+rax*1]
00007e05fe7d1422  movq xmm1, r14
00007e05fe7d1427  mov rax, [r15+0x50]
00007e05fe7d142b  mov r14, [r13+rax*1]
00007e05fe7d1430  movq xmm15, r14
00007e05fe7d1435  movaps [r15+0x120], xmm15
00007e05fe7d143d  mov qword ptr [r15+0x48], 0x08
00007e05fe7d1445  xor eax, eax
00007e05fe7d1447  mov r14d, 0x08
00007e05fe7d144d  mov r12d, 0x200
00007e05fe7d1453  cmp r14, r12
00007e05fe7d1456  cmc
00007e05fe7d1457  lahf
00007e05fe7d1458  seto al
00007e05fe7d145b  mov [r15+0x108], eax
00007e05fe7d1462  movq rax, xmm1
00007e05fe7d1467  movq r14, xmm15
00007e05fe7d146c  vmovq xmm1, rax
00007e05fe7d1471  vmovq xmm15, r14
00007e05fe7d1476  movaps xmm14, xmm1
00007e05fe7d147a  addsd xmm14, xmm15
00007e05fe7d147f  ucomisd xmm14, xmm14
00007e05fe7d1484  jp 0x00007E05FE7D1516
00007e05fe7d148a  movq xmm14, xmm14
00007e05fe7d148f  movaps [r15+0x110], xmm14
00007e05fe7d1497  mov eax, [r15+0x108]
00007e05fe7d149e  sahf
00007e05fe7d149f  jnz 0x00007E05FE7D14D1
00007e05fe7d14a1  cmp dword ptr [r15+0x318], 0x00
00007e05fe7d14a9  jz 0x00007E05FE7D16A0
00007e05fe7d14af  nop [rax+rax*1], ax
00007e05fe7d14b8  nop [rax+rax*1], eax
00007e05fe7d14c0  mov eax, 0x410154
00007e05fe7d14c5  mov [r15+0x100], rax
00007e05fe7d14cc  jmp 0x00007E05FE5FE110
00007e05fe7d14d1  cmp dword ptr [r15+0x318], 0x00
00007e05fe7d14d9  jz 0x00007E05FE7D1560
00007e05fe7d14df  nop [rax+rax*1], ax
00007e05fe7d14e8  nop [rax+rax*1], eax
00007e05fe7d14f0  mov eax, 0x410140
00007e05fe7d14f5  mov [r15+0x100], rax
00007e05fe7d14fc  jmp 0x00007E05FE5FE110
00007e05fe7d1501  int3
00007e05fe7d1502  call 0x00007E05FE60DC20
00007e05fe7d1507  jmp 0x00007E05FE7D1422
00007e05fe7d150c  call 0x00007E05FE60DC20
00007e05fe7d1511  jmp 0x00007E05FE7D1430
00007e05fe7d1516  ucomisd xmm1, xmm15
00007e05fe7d151b  jp 0x00007E05FE7D152A
00007e05fe7d151d  movaps xmm14, [0x00007E05FE3FE030]
00007e05fe7d1525  jmp 0x00007E05FE7D148A
00007e05fe7d152a  vxorps xmm0, xmm1, xmm15
00007e05fe7d152f  pextrw eax, xmm0, 0x03
00007e05fe7d1534  and eax, 0x7FF8
00007e05fe7d1539  cmp eax, 0x08
00007e05fe7d153c  jnz 0x00007E05FE7D148A
00007e05fe7d1542  movq rax, xmm15
00007e05fe7d1547  shl rax, 0x0D
00007e05fe7d154b  jbe 0x00007E05FE7D148A
00007e05fe7d1551  vorps xmm14, xmm15, [0x00007E05FE3FE040]
00007e05fe7d1559  jmp 0x00007E05FE7D148A
00007e05fe7d155e  int3
00007e05fe7d155f  nop
00007e05fe7d1560  mov rax, [r15+0x48]
00007e05fe7d1564  mov r14, [r15+0x50]
00007e05fe7d1568  lea r12, [r14+rax*1]
00007e05fe7d156c  mov r14, [r13+r12*1]
00007e05fe7d1571  movq xmm1, r14
00007e05fe7d1576  movaps [r15+0x120], xmm1
00007e05fe7d157e  lea r14, [rax+0x08]
00007e05fe7d1582  mov [r15+0x48], r14
00007e05fe7d1586  xor eax, eax
00007e05fe7d1588  mov r12d, 0x200
00007e05fe7d158e  cmp r14, r12
00007e05fe7d1591  cmc
00007e05fe7d1592  lahf
00007e05fe7d1593  seto al
00007e05fe7d1596  mov [r15+0x108], eax
00007e05fe7d159d  movaps xmm15, [r15+0x110]
00007e05fe7d15a5  movq rax, xmm15
00007e05fe7d15aa  movq r14, xmm1
00007e05fe7d15af  vmovq xmm1, rax
00007e05fe7d15b4  vmovq xmm15, r14
00007e05fe7d15b9  movaps xmm14, xmm1
00007e05fe7d15bd  addsd xmm14, xmm15
00007e05fe7d15c2  ucomisd xmm14, xmm14
00007e05fe7d15c7  jp 0x00007E05FE7D164F
00007e05fe7d15cd  movq xmm14, xmm14
00007e05fe7d15d2  movaps [r15+0x110], xmm14
00007e05fe7d15da  mov eax, [r15+0x108]
00007e05fe7d15e1  sahf
00007e05fe7d15e2  jnz 0x00007E05FE7D1614
00007e05fe7d15e4  cmp dword ptr [r15+0x318], 0x00
00007e05fe7d15ec  jz 0x00007E05FE7D16A0
00007e05fe7d15f2  nop [rax+rax*1], ax
00007e05fe7d15fb  nop [rax+rax*1], eax
00007e05fe7d1603  mov eax, 0x410154
00007e05fe7d1608  mov [r15+0x100], rax
00007e05fe7d160f  jmp 0x00007E05FE5FE110
00007e05fe7d1614  cmp dword ptr [r15+0x318], 0x00
00007e05fe7d161c  jz 0x00007E05FE7D1560
00007e05fe7d1622  nop [rax+rax*1], ax
00007e05fe7d162b  nop [rax+rax*1], eax
00007e05fe7d1633  mov eax, 0x410140
00007e05fe7d1638  mov [r15+0x100], rax
00007e05fe7d163f  jmp 0x00007E05FE5FE110
00007e05fe7d1644  int3
00007e05fe7d1645  call 0x00007E05FE6C3AE0
00007e05fe7d164a  jmp 0x00007E05FE7D1571
00007e05fe7d164f  ucomisd xmm1, xmm15
00007e05fe7d1654  jp 0x00007E05FE7D1663
00007e05fe7d1656  movaps xmm14, [0x00007E05FE3FE030]
00007e05fe7d165e  jmp 0x00007E05FE7D15CD
00007e05fe7d1663  vxorps xmm0, xmm1, xmm15
00007e05fe7d1668  pextrw eax, xmm0, 0x03
00007e05fe7d166d  and eax, 0x7FF8
00007e05fe7d1672  cmp eax, 0x08
00007e05fe7d1675  jnz 0x00007E05FE7D15CD
00007e05fe7d167b  movq rax, xmm15
00007e05fe7d1680  shl rax, 0x0D
00007e05fe7d1684  jbe 0x00007E05FE7D15CD
00007e05fe7d168a  vorps xmm14, xmm15, [0x00007E05FE3FE040]
00007e05fe7d1692  jmp 0x00007E05FE7D15CD
00007e05fe7d1697  int3
00007e05fe7d1698  nop [rax+rax*1], eax
00007e05fe7d16a0  mov rax, [r15+0x40]
00007e05fe7d16a4  lea r14, [rax+0x1B8]
00007e05fe7d16ab  movaps xmm1, [r15+0x110]
00007e05fe7d16b3  movq rax, xmm1
00007e05fe7d16b8  mov [r13+r14*1], rax
00007e05fe7d16bd  mov rax, [r15+0xF0]
00007e05fe7d16c4  mov [r15+0x100], rax
00007e05fe7d16cb  jmp 0x00007E05FE7CE5C0
00007e05fe7d16d0  int3
00007e05fe7d16d1  call 0x00007E05FE6D5EB0
00007e05fe7d16d6  jmp 0x00007E05FE7D16BD
00007e05fe7d16db  int3
00007e05fe7d16dc  nop [rax], eax
00007e05fe7d16e0  mov qword ptr [r15+0x100], 0x04
00007e05fe7d16eb  mov esi, 0x00
00007e05fe7d16f0  mov edx, 0x09
00007e05fe7d16f5  mov rdi, 0x7FFD48856CC0
00007e05fe7d16ff  mov rax, 0x5875A710A970
00007e05fe7d1709  call rax
00007e05fe7d170b  cmp dword ptr [r15+0x318], 0x00
00007e05fe7d1713  jnz 0x00007E05FE5FE110
00007e05fe7d1719  jmp 0x00007E05FE5FE0A0
00007e05fe7d171e  int3
00007e05fe7d171f  int3
