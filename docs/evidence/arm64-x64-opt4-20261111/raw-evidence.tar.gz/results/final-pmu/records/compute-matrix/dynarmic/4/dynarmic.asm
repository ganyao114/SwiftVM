00007eafdc3ce69b  nop [rax+rax*1], eax
00007eafdc3ce6a0  vmovaps xmm1, [0x00007EAFDBFFE010]
00007eafdc3ce6a8  movq xmm1, xmm1
00007eafdc3ce6ac  movaps [r15+0x110], xmm1
00007eafdc3ce6b4  vmovaps xmm1, [0x00007EAFDBFFE020]
00007eafdc3ce6bc  movq xmm1, xmm1
00007eafdc3ce6c0  movaps [r15+0x120], xmm1
00007eafdc3ce6c8  mov eax, 0x4204C0
00007eafdc3ce6cd  mov r14, [r13+rax*1]
00007eafdc3ce6d2  movq xmm1, r14
00007eafdc3ce6d7  movaps [r15+0x130], xmm1
00007eafdc3ce6df  vmovaps xmm1, [0x00007EAFDBFFE030]
00007eafdc3ce6e7  vpbroadcastq xmm1, xmm1
00007eafdc3ce6ec  movaps [r15+0x140], xmm1
00007eafdc3ce6f4  mov qword ptr [r15+0x40], 0x02
00007eafdc3ce6fc  vmovaps xmm15, [0x00007EAFDBFFE040]
00007eafdc3ce704  movq xmm15, xmm15
00007eafdc3ce709  movaps [r15+0x150], xmm15
00007eafdc3ce711  mov qword ptr [r15+0x58], 0x420000
00007eafdc3ce719  vmovaps xmm15, [0x00007EAFDBFFE050]
00007eafdc3ce721  vpbroadcastq xmm15, xmm15
00007eafdc3ce726  movaps [r15+0x160], xmm15
00007eafdc3ce72e  mov rax, [r15+0x40]
00007eafdc3ce732  vmovq xmm14, rax
00007eafdc3ce737  vpbroadcastq xmm14, xmm14
00007eafdc3ce73c  movaps [r15+0x170], xmm14
00007eafdc3ce744  mov eax, 0x4204D0
00007eafdc3ce749  movups xmm13, [r13+rax*1]
00007eafdc3ce74f  mov qword ptr [r15+0x40], 0x430518
00007eafdc3ce757  mov qword ptr [r15+0x50], 0x430720
00007eafdc3ce75f  vpmovqd xmm12, xmm13
00007eafdc3ce765  pxor xmm11, xmm11
00007eafdc3ce76a  punpcklqdq xmm12, xmm11
00007eafdc3ce76f  movaps [r15+0x210], xmm12
00007eafdc3ce777  movq xmm12, qword ptr [r15+0x120]
00007eafdc3ce780  movq xmm11, qword ptr [r15+0x130]
00007eafdc3ce789  psubd xmm12, xmm11
00007eafdc3ce78e  movq xmm12, xmm12
00007eafdc3ce793  paddq xmm13, xmm14
00007eafdc3ce798  movaps [r15+0x180], xmm13
00007eafdc3ce7a0  movq xmm14, qword ptr [r15+0x150]
00007eafdc3ce7a9  paddd xmm11, xmm14
00007eafdc3ce7ae  movq xmm11, xmm11
00007eafdc3ce7b3  movq xmm11, xmm11
00007eafdc3ce7b8  movaps [r15+0x130], xmm11
00007eafdc3ce7c0  pmovzxdq xmm12, xmm12
00007eafdc3ce7c6  psllq xmm12, 0x00
00007eafdc3ce7cc  movq xmm14, qword ptr [r15+0x210]
00007eafdc3ce7d5  movq xmm13, qword ptr [r15+0x110]
00007eafdc3ce7de  paddd xmm14, xmm13
00007eafdc3ce7e3  movq xmm14, xmm14
00007eafdc3ce7e8  vcvtuqq2pd xmm12, xmm12
00007eafdc3ce7ee  pmovzxdq xmm14, xmm14
00007eafdc3ce7f4  psllq xmm14, 0x00
00007eafdc3ce7fa  vcvtuqq2pd xmm14, xmm14
00007eafdc3ce800  movaps xmm13, xmm12
00007eafdc3ce804  mulpd xmm13, xmm1
00007eafdc3ce809  vcmppd xmm11, xmm13, xmm13, 0x03
00007eafdc3ce80f  ptest xmm11, xmm11
00007eafdc3ce815  jnz 0x00007EAFDC3CE8FF
00007eafdc3ce81b  movaps [r15+0x220], xmm13
00007eafdc3ce823  mov eax, 0x430720
00007eafdc3ce828  movups [r13+rax*1], xmm13
00007eafdc3ce82e  movaps xmm1, xmm14
00007eafdc3ce832  mulpd xmm1, xmm15
00007eafdc3ce837  vcmppd xmm13, xmm1, xmm1, 0x03
00007eafdc3ce83c  ptest xmm13, xmm13
00007eafdc3ce842  jnz 0x00007EAFDC3CEA4C
00007eafdc3ce848  movaps [r15+0x210], xmm1
00007eafdc3ce850  mov eax, 0x430518
00007eafdc3ce855  movups [r13+rax*1], xmm1
00007eafdc3ce85b  mov qword ptr [r15+0x48], 0x10
00007eafdc3ce863  xor eax, eax
00007eafdc3ce865  mov r14d, 0x10
00007eafdc3ce86b  mov r12d, 0x200
00007eafdc3ce871  cmp r14, r12
00007eafdc3ce874  cmc
00007eafdc3ce875  lahf
00007eafdc3ce876  seto al
00007eafdc3ce879  mov [r15+0x108], eax
00007eafdc3ce880  mov eax, [r15+0x108]
00007eafdc3ce887  sahf
00007eafdc3ce888  jnz 0x00007EAFDC3CE8BA
00007eafdc3ce88a  cmp dword ptr [r15+0x318], 0x00
00007eafdc3ce892  jz 0x00007EAFDC3CEFF0
00007eafdc3ce898  nop [rax+rax*1], ax
00007eafdc3ce8a1  nop [rax+rax*1], eax
00007eafdc3ce8a9  mov eax, 0x4101EC
00007eafdc3ce8ae  mov [r15+0x100], rax
00007eafdc3ce8b5  jmp 0x00007EAFDC1FE110
00007eafdc3ce8ba  cmp dword ptr [r15+0x318], 0x00
00007eafdc3ce8c2  jz 0x00007EAFDC3CEBA0
00007eafdc3ce8c8  nop [rax+rax*1], ax
00007eafdc3ce8d1  nop [rax+rax*1], eax
00007eafdc3ce8d9  mov eax, 0x4101AC
00007eafdc3ce8de  mov [r15+0x100], rax
00007eafdc3ce8e5  jmp 0x00007EAFDC1FE110
00007eafdc3ce8ea  int3
00007eafdc3ce8eb  call 0x00007EAFDC20DC20
00007eafdc3ce8f0  jmp 0x00007EAFDC3CE6D2
00007eafdc3ce8f5  call 0x00007EAFDC20C260
00007eafdc3ce8fa  jmp 0x00007EAFDC3CE74F
00007eafdc3ce8ff  sub rsp, 0x08
00007eafdc3ce903  push rax
00007eafdc3ce904  push rcx
00007eafdc3ce905  push rdx
00007eafdc3ce906  push rdi
00007eafdc3ce907  push rsi
00007eafdc3ce908  push r8
00007eafdc3ce90a  push r9
00007eafdc3ce90c  push r10
00007eafdc3ce90e  push r11
00007eafdc3ce910  sub rsp, 0xF0
00007eafdc3ce917  vmovaps [rsp], xmm0
00007eafdc3ce91c  vmovaps [rsp+0x10], xmm1
00007eafdc3ce922  vmovaps [rsp+0x20], xmm2
00007eafdc3ce928  vmovaps [rsp+0x30], xmm3
00007eafdc3ce92e  vmovaps [rsp+0x40], xmm4
00007eafdc3ce934  vmovaps [rsp+0x50], xmm5
00007eafdc3ce93a  vmovaps [rsp+0x60], xmm6
00007eafdc3ce940  vmovaps [rsp+0x70], xmm7
00007eafdc3ce946  vmovaps [rsp+0x80], xmm8
00007eafdc3ce94f  vmovaps [rsp+0x90], xmm9
00007eafdc3ce958  vmovaps [rsp+0xA0], xmm10
00007eafdc3ce961  vmovaps [rsp+0xB0], xmm11
00007eafdc3ce96a  vmovaps [rsp+0xC0], xmm12
00007eafdc3ce973  vmovaps [rsp+0xD0], xmm14
00007eafdc3ce97c  vmovaps [rsp+0xE0], xmm15
00007eafdc3ce985  sub rsp, 0x30
00007eafdc3ce989  movaps [rsp], xmm13
00007eafdc3ce98e  movaps [rsp+0x10], xmm12
00007eafdc3ce994  movaps [rsp+0x20], xmm1
00007eafdc3ce999  lea rdi, [rsp]
00007eafdc3ce99d  mov esi, 0x00
00007eafdc3ce9a2  mov rax, 0x645891675530
00007eafdc3ce9ac  call rax
00007eafdc3ce9ae  movaps xmm13, [rsp]
00007eafdc3ce9b3  add rsp, 0x30
00007eafdc3ce9b7  vmovaps xmm0, [rsp]
00007eafdc3ce9bc  vmovaps xmm1, [rsp+0x10]
00007eafdc3ce9c2  vmovaps xmm2, [rsp+0x20]
00007eafdc3ce9c8  vmovaps xmm3, [rsp+0x30]
00007eafdc3ce9ce  vmovaps xmm4, [rsp+0x40]
00007eafdc3ce9d4  vmovaps xmm5, [rsp+0x50]
00007eafdc3ce9da  vmovaps xmm6, [rsp+0x60]
00007eafdc3ce9e0  vmovaps xmm7, [rsp+0x70]
00007eafdc3ce9e6  vmovaps xmm8, [rsp+0x80]
00007eafdc3ce9ef  vmovaps xmm9, [rsp+0x90]
00007eafdc3ce9f8  vmovaps xmm10, [rsp+0xA0]
00007eafdc3cea01  vmovaps xmm11, [rsp+0xB0]
00007eafdc3cea0a  vmovaps xmm12, [rsp+0xC0]
00007eafdc3cea13  vmovaps xmm14, [rsp+0xD0]
00007eafdc3cea1c  vmovaps xmm15, [rsp+0xE0]
00007eafdc3cea25  add rsp, 0xF0
00007eafdc3cea2c  pop r11
00007eafdc3cea2e  pop r10
00007eafdc3cea30  pop r9
00007eafdc3cea32  pop r8
00007eafdc3cea34  pop rsi
00007eafdc3cea35  pop rdi
00007eafdc3cea36  pop rdx
00007eafdc3cea37  pop rcx
00007eafdc3cea38  pop rax
00007eafdc3cea39  add rsp, 0x08
00007eafdc3cea3d  jmp 0x00007EAFDC3CE81B
00007eafdc3cea42  call 0x00007EAFDC20C380
00007eafdc3cea47  jmp 0x00007EAFDC3CE82E
00007eafdc3cea4c  sub rsp, 0x08
00007eafdc3cea50  push rax
00007eafdc3cea51  push rcx
00007eafdc3cea52  push rdx
00007eafdc3cea53  push rdi
00007eafdc3cea54  push rsi
00007eafdc3cea55  push r8
00007eafdc3cea57  push r9
00007eafdc3cea59  push r10
00007eafdc3cea5b  push r11
00007eafdc3cea5d  sub rsp, 0xF0
00007eafdc3cea64  vmovaps [rsp], xmm0
00007eafdc3cea69  vmovaps [rsp+0x10], xmm2
00007eafdc3cea6f  vmovaps [rsp+0x20], xmm3
00007eafdc3cea75  vmovaps [rsp+0x30], xmm4
00007eafdc3cea7b  vmovaps [rsp+0x40], xmm5
00007eafdc3cea81  vmovaps [rsp+0x50], xmm6
00007eafdc3cea87  vmovaps [rsp+0x60], xmm7
00007eafdc3cea8d  vmovaps [rsp+0x70], xmm8
00007eafdc3cea93  vmovaps [rsp+0x80], xmm9
00007eafdc3cea9c  vmovaps [rsp+0x90], xmm10
00007eafdc3ceaa5  vmovaps [rsp+0xA0], xmm11
00007eafdc3ceaae  vmovaps [rsp+0xB0], xmm12
00007eafdc3ceab7  vmovaps [rsp+0xC0], xmm13
00007eafdc3ceac0  vmovaps [rsp+0xD0], xmm14
00007eafdc3ceac9  vmovaps [rsp+0xE0], xmm15
00007eafdc3cead2  sub rsp, 0x30
00007eafdc3cead6  movaps [rsp], xmm1
00007eafdc3ceada  movaps [rsp+0x10], xmm14
00007eafdc3ceae0  movaps [rsp+0x20], xmm15
00007eafdc3ceae6  lea rdi, [rsp]
00007eafdc3ceaea  mov esi, 0x00
00007eafdc3ceaef  mov rax, 0x645891675530
00007eafdc3ceaf9  call rax
00007eafdc3ceafb  movaps xmm1, [rsp]
00007eafdc3ceaff  add rsp, 0x30
00007eafdc3ceb03  vmovaps xmm0, [rsp]
00007eafdc3ceb08  vmovaps xmm2, [rsp+0x10]
00007eafdc3ceb0e  vmovaps xmm3, [rsp+0x20]
00007eafdc3ceb14  vmovaps xmm4, [rsp+0x30]
00007eafdc3ceb1a  vmovaps xmm5, [rsp+0x40]
00007eafdc3ceb20  vmovaps xmm6, [rsp+0x50]
00007eafdc3ceb26  vmovaps xmm7, [rsp+0x60]
00007eafdc3ceb2c  vmovaps xmm8, [rsp+0x70]
00007eafdc3ceb32  vmovaps xmm9, [rsp+0x80]
00007eafdc3ceb3b  vmovaps xmm10, [rsp+0x90]
00007eafdc3ceb44  vmovaps xmm11, [rsp+0xA0]
00007eafdc3ceb4d  vmovaps xmm12, [rsp+0xB0]
00007eafdc3ceb56  vmovaps xmm13, [rsp+0xC0]
00007eafdc3ceb5f  vmovaps xmm14, [rsp+0xD0]
00007eafdc3ceb68  vmovaps xmm15, [rsp+0xE0]
00007eafdc3ceb71  add rsp, 0xF0
00007eafdc3ceb78  pop r11
00007eafdc3ceb7a  pop r10
00007eafdc3ceb7c  pop r9
00007eafdc3ceb7e  pop r8
00007eafdc3ceb80  pop rsi
00007eafdc3ceb81  pop rdi
00007eafdc3ceb82  pop rdx
00007eafdc3ceb83  pop rcx
00007eafdc3ceb84  pop rax
00007eafdc3ceb85  add rsp, 0x08
00007eafdc3ceb89  jmp 0x00007EAFDC3CE848
00007eafdc3ceb8e  call 0x00007EAFDC1FF540
00007eafdc3ceb93  jmp 0x00007EAFDC3CE85B
00007eafdc3ceb98  int3
00007eafdc3ceb99  nop [rax], eax
00007eafdc3ceba0  movaps xmm1, [r15+0x180]
00007eafdc3ceba8  vpmovqd xmm15, xmm1
00007eafdc3cebae  pxor xmm14, xmm14
00007eafdc3cebb3  punpcklqdq xmm15, xmm14
00007eafdc3cebb8  movaps [r15+0x210], xmm15
00007eafdc3cebc0  movq xmm15, qword ptr [r15+0x120]
00007eafdc3cebc9  movq xmm14, qword ptr [r15+0x130]
00007eafdc3cebd2  psubd xmm15, xmm14
00007eafdc3cebd7  movq xmm15, xmm15
00007eafdc3cebdc  movaps xmm13, [r15+0x170]
00007eafdc3cebe4  paddq xmm1, xmm13
00007eafdc3cebe9  movaps [r15+0x180], xmm1
00007eafdc3cebf1  movq xmm1, qword ptr [r15+0x150]
00007eafdc3cebfa  paddd xmm14, xmm1
00007eafdc3cebff  movq xmm14, xmm14
00007eafdc3cec04  movq xmm14, xmm14
00007eafdc3cec09  movaps [r15+0x130], xmm14
00007eafdc3cec11  pmovzxdq xmm15, xmm15
00007eafdc3cec17  psllq xmm15, 0x00
00007eafdc3cec1d  movq xmm1, qword ptr [r15+0x210]
00007eafdc3cec26  movq xmm14, qword ptr [r15+0x110]
00007eafdc3cec2f  paddd xmm1, xmm14
00007eafdc3cec34  movq xmm1, xmm1
00007eafdc3cec38  vcvtuqq2pd xmm15, xmm15
00007eafdc3cec3e  pmovzxdq xmm1, xmm1
00007eafdc3cec43  psllq xmm1, 0x00
00007eafdc3cec48  vcvtuqq2pd xmm1, xmm1
00007eafdc3cec4e  movaps xmm14, [r15+0x140]
00007eafdc3cec56  movaps xmm13, xmm15
00007eafdc3cec5a  mulpd xmm13, xmm14
00007eafdc3cec5f  vcmppd xmm12, xmm13, xmm13, 0x03
00007eafdc3cec65  ptest xmm12, xmm12
00007eafdc3cec6b  jnz 0x00007EAFDC3CED4E
00007eafdc3cec71  movaps [r15+0x220], xmm13
00007eafdc3cec79  mov rax, [r15+0x48]
00007eafdc3cec7d  mov r14, [r15+0x50]
00007eafdc3cec81  lea r12, [r14+rax*1]
00007eafdc3cec85  movups [r13+r12*1], xmm13
00007eafdc3cec8b  movaps xmm15, [r15+0x160]
00007eafdc3cec93  movaps xmm14, xmm1
00007eafdc3cec97  mulpd xmm14, xmm15
00007eafdc3cec9c  vcmppd xmm13, xmm14, xmm14, 0x03
00007eafdc3ceca2  ptest xmm13, xmm13
00007eafdc3ceca8  jnz 0x00007EAFDC3CEE9C
00007eafdc3cecae  movaps [r15+0x210], xmm14
00007eafdc3cecb6  mov r14, [r15+0x40]
00007eafdc3cecba  lea r12, [r14+rax*1]
00007eafdc3cecbe  movups [r13+r12*1], xmm14
00007eafdc3cecc4  lea r14, [rax+0x10]
00007eafdc3cecc8  mov [r15+0x48], r14
00007eafdc3ceccc  xor eax, eax
00007eafdc3cecce  mov r12d, 0x200
00007eafdc3cecd4  cmp r14, r12
00007eafdc3cecd7  cmc
00007eafdc3cecd8  lahf
00007eafdc3cecd9  seto al
00007eafdc3cecdc  mov [r15+0x108], eax
00007eafdc3cece3  mov eax, [r15+0x108]
00007eafdc3cecea  sahf
00007eafdc3ceceb  jnz 0x00007EAFDC3CED1D
00007eafdc3ceced  cmp dword ptr [r15+0x318], 0x00
00007eafdc3cecf5  jz 0x00007EAFDC3CEFF0
00007eafdc3cecfb  nop [rax+rax*1], ax
00007eafdc3ced04  nop [rax+rax*1], eax
00007eafdc3ced0c  mov eax, 0x4101EC
00007eafdc3ced11  mov [r15+0x100], rax
00007eafdc3ced18  jmp 0x00007EAFDC1FE110
00007eafdc3ced1d  cmp dword ptr [r15+0x318], 0x00
00007eafdc3ced25  jz 0x00007EAFDC3CEBA0
00007eafdc3ced2b  nop [rax+rax*1], ax
00007eafdc3ced34  nop [rax+rax*1], eax
00007eafdc3ced3c  mov eax, 0x4101AC
00007eafdc3ced41  mov [r15+0x100], rax
00007eafdc3ced48  jmp 0x00007EAFDC1FE110
00007eafdc3ced4d  int3
00007eafdc3ced4e  sub rsp, 0x08
00007eafdc3ced52  push rax
00007eafdc3ced53  push rcx
00007eafdc3ced54  push rdx
00007eafdc3ced55  push rdi
00007eafdc3ced56  push rsi
00007eafdc3ced57  push r8
00007eafdc3ced59  push r9
00007eafdc3ced5b  push r10
00007eafdc3ced5d  push r11
00007eafdc3ced5f  sub rsp, 0xF0
00007eafdc3ced66  vmovaps [rsp], xmm0
00007eafdc3ced6b  vmovaps [rsp+0x10], xmm1
00007eafdc3ced71  vmovaps [rsp+0x20], xmm2
00007eafdc3ced77  vmovaps [rsp+0x30], xmm3
00007eafdc3ced7d  vmovaps [rsp+0x40], xmm4
00007eafdc3ced83  vmovaps [rsp+0x50], xmm5
00007eafdc3ced89  vmovaps [rsp+0x60], xmm6
00007eafdc3ced8f  vmovaps [rsp+0x70], xmm7
00007eafdc3ced95  vmovaps [rsp+0x80], xmm8
00007eafdc3ced9e  vmovaps [rsp+0x90], xmm9
00007eafdc3ceda7  vmovaps [rsp+0xA0], xmm10
00007eafdc3cedb0  vmovaps [rsp+0xB0], xmm11
00007eafdc3cedb9  vmovaps [rsp+0xC0], xmm12
00007eafdc3cedc2  vmovaps [rsp+0xD0], xmm14
00007eafdc3cedcb  vmovaps [rsp+0xE0], xmm15
00007eafdc3cedd4  sub rsp, 0x30
00007eafdc3cedd8  movaps [rsp], xmm13
00007eafdc3ceddd  movaps [rsp+0x10], xmm15
00007eafdc3cede3  movaps [rsp+0x20], xmm14
00007eafdc3cede9  lea rdi, [rsp]
00007eafdc3ceded  mov esi, 0x00
00007eafdc3cedf2  mov rax, 0x645891675530
00007eafdc3cedfc  call rax
00007eafdc3cedfe  movaps xmm13, [rsp]
00007eafdc3cee03  add rsp, 0x30
00007eafdc3cee07  vmovaps xmm0, [rsp]
00007eafdc3cee0c  vmovaps xmm1, [rsp+0x10]
00007eafdc3cee12  vmovaps xmm2, [rsp+0x20]
00007eafdc3cee18  vmovaps xmm3, [rsp+0x30]
00007eafdc3cee1e  vmovaps xmm4, [rsp+0x40]
00007eafdc3cee24  vmovaps xmm5, [rsp+0x50]
00007eafdc3cee2a  vmovaps xmm6, [rsp+0x60]
00007eafdc3cee30  vmovaps xmm7, [rsp+0x70]
00007eafdc3cee36  vmovaps xmm8, [rsp+0x80]
00007eafdc3cee3f  vmovaps xmm9, [rsp+0x90]
00007eafdc3cee48  vmovaps xmm10, [rsp+0xA0]
00007eafdc3cee51  vmovaps xmm11, [rsp+0xB0]
00007eafdc3cee5a  vmovaps xmm12, [rsp+0xC0]
00007eafdc3cee63  vmovaps xmm14, [rsp+0xD0]
00007eafdc3cee6c  vmovaps xmm15, [rsp+0xE0]
00007eafdc3cee75  add rsp, 0xF0
00007eafdc3cee7c  pop r11
00007eafdc3cee7e  pop r10
00007eafdc3cee80  pop r9
00007eafdc3cee82  pop r8
00007eafdc3cee84  pop rsi
00007eafdc3cee85  pop rdi
00007eafdc3cee86  pop rdx
00007eafdc3cee87  pop rcx
00007eafdc3cee88  pop rax
00007eafdc3cee89  add rsp, 0x08
00007eafdc3cee8d  jmp 0x00007EAFDC3CEC71
00007eafdc3cee92  call 0x00007EAFDC2C2240
00007eafdc3cee97  jmp 0x00007EAFDC3CEC8B
00007eafdc3cee9c  sub rsp, 0x08
00007eafdc3ceea0  push rax
00007eafdc3ceea1  push rcx
00007eafdc3ceea2  push rdx
00007eafdc3ceea3  push rdi
00007eafdc3ceea4  push rsi
00007eafdc3ceea5  push r8
00007eafdc3ceea7  push r9
00007eafdc3ceea9  push r10
00007eafdc3ceeab  push r11
00007eafdc3ceead  sub rsp, 0xF0
00007eafdc3ceeb4  vmovaps [rsp], xmm0
00007eafdc3ceeb9  vmovaps [rsp+0x10], xmm1
00007eafdc3ceebf  vmovaps [rsp+0x20], xmm2
00007eafdc3ceec5  vmovaps [rsp+0x30], xmm3
00007eafdc3ceecb  vmovaps [rsp+0x40], xmm4
00007eafdc3ceed1  vmovaps [rsp+0x50], xmm5
00007eafdc3ceed7  vmovaps [rsp+0x60], xmm6
00007eafdc3ceedd  vmovaps [rsp+0x70], xmm7
00007eafdc3ceee3  vmovaps [rsp+0x80], xmm8
00007eafdc3ceeec  vmovaps [rsp+0x90], xmm9
00007eafdc3ceef5  vmovaps [rsp+0xA0], xmm10
00007eafdc3ceefe  vmovaps [rsp+0xB0], xmm11
00007eafdc3cef07  vmovaps [rsp+0xC0], xmm12
00007eafdc3cef10  vmovaps [rsp+0xD0], xmm13
00007eafdc3cef19  vmovaps [rsp+0xE0], xmm15
00007eafdc3cef22  sub rsp, 0x30
00007eafdc3cef26  movaps [rsp], xmm14
00007eafdc3cef2b  movaps [rsp+0x10], xmm1
00007eafdc3cef30  movaps [rsp+0x20], xmm15
00007eafdc3cef36  lea rdi, [rsp]
00007eafdc3cef3a  mov esi, 0x00
00007eafdc3cef3f  mov rax, 0x645891675530
00007eafdc3cef49  call rax
00007eafdc3cef4b  movaps xmm14, [rsp]
00007eafdc3cef50  add rsp, 0x30
00007eafdc3cef54  vmovaps xmm0, [rsp]
00007eafdc3cef59  vmovaps xmm1, [rsp+0x10]
00007eafdc3cef5f  vmovaps xmm2, [rsp+0x20]
00007eafdc3cef65  vmovaps xmm3, [rsp+0x30]
00007eafdc3cef6b  vmovaps xmm4, [rsp+0x40]
00007eafdc3cef71  vmovaps xmm5, [rsp+0x50]
00007eafdc3cef77  vmovaps xmm6, [rsp+0x60]
00007eafdc3cef7d  vmovaps xmm7, [rsp+0x70]
00007eafdc3cef83  vmovaps xmm8, [rsp+0x80]
00007eafdc3cef8c  vmovaps xmm9, [rsp+0x90]
00007eafdc3cef95  vmovaps xmm10, [rsp+0xA0]
00007eafdc3cef9e  vmovaps xmm11, [rsp+0xB0]
00007eafdc3cefa7  vmovaps xmm12, [rsp+0xC0]
00007eafdc3cefb0  vmovaps xmm13, [rsp+0xD0]
00007eafdc3cefb9  vmovaps xmm15, [rsp+0xE0]
00007eafdc3cefc2  add rsp, 0xF0
00007eafdc3cefc9  pop r11
00007eafdc3cefcb  pop r10
00007eafdc3cefcd  pop r9
00007eafdc3cefcf  pop r8
00007eafdc3cefd1  pop rsi
00007eafdc3cefd2  pop rdi
00007eafdc3cefd3  pop rdx
00007eafdc3cefd4  pop rcx
00007eafdc3cefd5  pop rax
00007eafdc3cefd6  add rsp, 0x08
00007eafdc3cefda  jmp 0x00007EAFDC3CECAE
00007eafdc3cefdf  call 0x00007EAFDC2C34C0
00007eafdc3cefe4  jmp 0x00007EAFDC3CECC4
00007eafdc3cefe9  int3
00007eafdc3cefea  nop [rax+rax*1], ax
00007eafdc3ceff0  mov rax, [r15+0xF8]
00007eafdc3ceff7  lea r14, [rax-0x150]
00007eafdc3ceffe  mov [r15+0xF8], r14
00007eafdc3cf005  mov rax, [r15+0x50]
00007eafdc3cf009  lea r12, [rax+0x80]
00007eafdc3cf010  movups xmm1, [r13+r12*1]
00007eafdc3cf016  lea r12, [rax+0x90]
00007eafdc3cf01d  movups xmm15, [r13+r12*1]
00007eafdc3cf023  mov qword ptr [r15+0x48], 0x00
00007eafdc3cf02b  lea r12, [rax+0x40]
00007eafdc3cf02f  movups xmm14, [r13+r12*1]
00007eafdc3cf035  lea r12, [rax+0x50]
00007eafdc3cf039  movups xmm13, [r13+r12*1]
00007eafdc3cf03f  lea r12, [r14+0x120]
00007eafdc3cf046  movq xmm12, qword ptr [r15+0x1C0]
00007eafdc3cf04f  movq xmm11, qword ptr [r15+0x1B0]
00007eafdc3cf058  movq r11, xmm12
00007eafdc3cf05d  movq r10, xmm11
00007eafdc3cf062  mov [r13+r12*1], r11
00007eafdc3cf067  lea r12, [r14+0x128]
00007eafdc3cf06e  mov [r13+r12*1], r10
00007eafdc3cf073  vxorps xmm12, xmm12, xmm12
00007eafdc3cf078  vpbroadcastq xmm12, xmm12
00007eafdc3cf07d  lea r12, [r14+0x100]
00007eafdc3cf084  movq xmm11, qword ptr [r15+0x200]
00007eafdc3cf08d  movq xmm10, qword ptr [r15+0x1F0]
00007eafdc3cf096  movq r11, xmm11
00007eafdc3cf09b  movq r10, xmm10
00007eafdc3cf0a0  mov [r13+r12*1], r11
00007eafdc3cf0a5  lea r12, [r14+0x108]
00007eafdc3cf0ac  mov [r13+r12*1], r10
00007eafdc3cf0b1  lea r12, [r14+0xE0]
00007eafdc3cf0b8  movups [r13+r12*1], xmm15
00007eafdc3cf0be  lea r12, [r14+0xF0]
00007eafdc3cf0c5  movups [r13+r12*1], xmm1
00007eafdc3cf0cb  lea r12, [rax+0xC0]
00007eafdc3cf0d2  movups xmm1, [r13+r12*1]
00007eafdc3cf0d8  lea r12, [rax+0xD0]
00007eafdc3cf0df  movups xmm15, [r13+r12*1]
00007eafdc3cf0e5  lea r12, [r14+0x110]
00007eafdc3cf0ec  movq xmm11, qword ptr [r15+0x1E0]
00007eafdc3cf0f5  movq xmm10, qword ptr [r15+0x1D0]
00007eafdc3cf0fe  movq r11, xmm11
00007eafdc3cf103  movq r10, xmm10
00007eafdc3cf108  mov [r13+r12*1], r11
00007eafdc3cf10d  lea r12, [r14+0x118]
00007eafdc3cf114  mov [r13+r12*1], r10
00007eafdc3cf119  movups xmm11, [r13+rax*1]
00007eafdc3cf11f  lea r12, [rax+0x10]
00007eafdc3cf123  movups xmm10, [r13+r12*1]
00007eafdc3cf129  lea r12, [r14+0x130]
00007eafdc3cf130  movq xmm9, qword ptr [r15+0x1A0]
00007eafdc3cf139  movq xmm8, qword ptr [r15+0x190]
00007eafdc3cf142  movq r11, xmm9
00007eafdc3cf147  movq r10, xmm8
00007eafdc3cf14c  mov [r13+r12*1], r11
00007eafdc3cf151  lea r12, [r14+0x138]
00007eafdc3cf158  mov [r13+r12*1], r10
00007eafdc3cf15d  lea r12, [rax+0x140]
00007eafdc3cf164  movups xmm9, [r13+r12*1]
00007eafdc3cf16a  lea r12, [rax+0x150]
00007eafdc3cf171  movups xmm8, [r13+r12*1]
00007eafdc3cf177  lea r12, [r14+0xC0]
00007eafdc3cf17e  movups [r13+r12*1], xmm15
00007eafdc3cf184  lea r12, [r14+0xD0]
00007eafdc3cf18b  movups [r13+r12*1], xmm1
00007eafdc3cf191  lea r12, [rax+0x100]
00007eafdc3cf198  movups xmm1, [r13+r12*1]
00007eafdc3cf19e  lea r12, [rax+0x110]
00007eafdc3cf1a5  movups xmm15, [r13+r12*1]
00007eafdc3cf1ab  lea r12, [r14+0x140]
00007eafdc3cf1b2  mov r11, [r15+0xE8]
00007eafdc3cf1b9  mov [r13+r12*1], r11
00007eafdc3cf1be  lea r12, [rax+0x180]
00007eafdc3cf1c5  movups xmm7, [r13+r12*1]
00007eafdc3cf1cb  lea r12, [rax+0x190]
00007eafdc3cf1d2  movups xmm6, [r13+r12*1]
00007eafdc3cf1d8  lea r12, [rax+0x1C0]
00007eafdc3cf1df  movups xmm5, [r13+r12*1]
00007eafdc3cf1e5  lea r12, [rax+0x1D0]
00007eafdc3cf1ec  movups xmm4, [r13+r12*1]
00007eafdc3cf1f2  lea r12, [r14+0x20]
00007eafdc3cf1f6  movups [r13+r12*1], xmm1
00007eafdc3cf1fc  lea r12, [r14+0x30]
00007eafdc3cf200  movups [r13+r12*1], xmm13
00007eafdc3cf206  lea r12, [rax+0x60]
00007eafdc3cf20a  movups xmm1, [r13+r12*1]
00007eafdc3cf210  lea r12, [rax+0x70]
00007eafdc3cf214  movups xmm13, [r13+r12*1]
00007eafdc3cf21a  lea r12, [rax+0x20]
00007eafdc3cf21e  movups xmm3, [r13+r12*1]
00007eafdc3cf224  lea r12, [rax+0x30]
00007eafdc3cf228  movups xmm2, [r13+r12*1]
00007eafdc3cf22e  movaps [r15+0x1F0], xmm2
00007eafdc3cf236  lea r12, [r14+0x60]
00007eafdc3cf23a  movups [r13+r12*1], xmm11
00007eafdc3cf240  lea r12, [r14+0x70]
00007eafdc3cf244  movups [r13+r12*1], xmm5
00007eafdc3cf24a  lea r12, [rax+0xE0]
00007eafdc3cf251  movups xmm11, [r13+r12*1]
00007eafdc3cf257  lea r12, [rax+0xF0]
00007eafdc3cf25e  movups xmm5, [r13+r12*1]
00007eafdc3cf264  lea r12, [r14+0xA0]
00007eafdc3cf26b  movups [r13+r12*1], xmm13
00007eafdc3cf271  lea r12, [r14+0xB0]
00007eafdc3cf278  movups [r13+r12*1], xmm1
00007eafdc3cf27e  lea r12, [rax+0xA0]
00007eafdc3cf285  movups xmm1, [r13+r12*1]
00007eafdc3cf28b  lea r12, [rax+0xB0]
00007eafdc3cf292  movups xmm13, [r13+r12*1]
00007eafdc3cf298  lea r12, [rax+0x120]
00007eafdc3cf29f  vmovaps [rsp+0x10], xmm1
00007eafdc3cf2a5  movups xmm1, [r13+r12*1]
00007eafdc3cf2ab  lea r12, [rax+0x130]
00007eafdc3cf2b2  vmovaps [rsp+0x20], xmm1
00007eafdc3cf2b8  movups xmm1, [r13+r12*1]
00007eafdc3cf2be  lea r12, [rax+0x160]
00007eafdc3cf2c5  vmovaps [rsp+0x30], xmm1
00007eafdc3cf2cb  movups xmm1, [r13+r12*1]
00007eafdc3cf2d1  lea r12, [rax+0x170]
00007eafdc3cf2d8  vmovaps [rsp+0x40], xmm1
00007eafdc3cf2de  movups xmm1, [r13+r12*1]
00007eafdc3cf2e4  movaps [r15+0x2B0], xmm1
00007eafdc3cf2ec  lea r12, [r14+0x80]
00007eafdc3cf2f3  movups [r13+r12*1], xmm13
00007eafdc3cf2f9  lea r12, [r14+0x90]
00007eafdc3cf300  vmovaps xmm13, [rsp+0x10]
00007eafdc3cf306  movups [r13+r12*1], xmm13
00007eafdc3cf30c  lea r12, [rax+0x1A0]
00007eafdc3cf313  movups xmm13, [r13+r12*1]
00007eafdc3cf319  lea r12, [rax+0x1B0]
00007eafdc3cf320  vmovaps [rsp+0x10], xmm1
00007eafdc3cf326  movups xmm1, [r13+r12*1]
00007eafdc3cf32c  movaps [r15+0x290], xmm13
00007eafdc3cf334  movaps [r15+0x1E0], xmm1
00007eafdc3cf33c  lea r12, [rax+0x1E0]
00007eafdc3cf343  vmovaps [rsp+0x50], xmm1
00007eafdc3cf349  movups xmm1, [r13+r12*1]
00007eafdc3cf34f  lea r12, [rax+0x1F0]
00007eafdc3cf356  vmovaps [rsp+0x60], xmm1
00007eafdc3cf35c  movups xmm1, [r13+r12*1]
00007eafdc3cf362  mov qword ptr [r15+0x50], 0x430920
00007eafdc3cf36a  lea rax, [r14+0x40]
00007eafdc3cf36e  vmovaps [rsp+0x70], xmm1
00007eafdc3cf374  vmovaps xmm1, [rsp+0x40]
00007eafdc3cf37a  movups [r13+rax*1], xmm1
00007eafdc3cf380  lea rax, [r14+0x50]
00007eafdc3cf384  movups [r13+rax*1], xmm10
00007eafdc3cf38a  vmovaps xmm1, [rsp+0x70]
00007eafdc3cf390  movups [r13+r14*1], xmm1
00007eafdc3cf396  lea rax, [r14+0x10]
00007eafdc3cf39a  vmovaps xmm1, [rsp+0x60]
00007eafdc3cf3a0  movups [r13+rax*1], xmm1
00007eafdc3cf3a6  mov rax, [r15+0x40]
00007eafdc3cf3aa  vmovaps [rsp+0x40], xmm3
00007eafdc3cf3b0  vmovaps xmm1, [rsp+0x40]
00007eafdc3cf3b6  por xmm3, xmm1
00007eafdc3cf3ba  vmovaps [rsp+0x40], xmm6
00007eafdc3cf3c0  vmovaps xmm10, [rsp+0x40]
00007eafdc3cf3c6  por xmm6, xmm10
00007eafdc3cf3cb  lea r12, [rax+0x30]
00007eafdc3cf3cf  mov r11, [r13+r12*1]
00007eafdc3cf3d4  lea r12, [rax+0x38]
00007eafdc3cf3d8  mov r10, [r13+r12*1]
00007eafdc3cf3dd  movq xmm10, r11
00007eafdc3cf3e2  vmovaps [rsp+0x40], xmm1
00007eafdc3cf3e8  movq xmm1, r10
00007eafdc3cf3ed  movq xmm10, xmm10
00007eafdc3cf3f2  vmovaps [rsp+0x60], xmm10
00007eafdc3cf3f8  movq xmm10, xmm10
00007eafdc3cf3fd  movaps [r15+0x130], xmm10
00007eafdc3cf405  movq xmm1, xmm1
00007eafdc3cf409  vmovaps [rsp+0x70], xmm1
00007eafdc3cf40f  movq xmm1, xmm1
00007eafdc3cf413  movaps [r15+0x280], xmm1
00007eafdc3cf41b  vmovaps [rsp+0x80], xmm9
00007eafdc3cf424  vmovaps xmm1, [rsp+0x80]
00007eafdc3cf42d  por xmm9, xmm1
00007eafdc3cf432  lea r12, [rax+0x20]
00007eafdc3cf436  mov r11, [r13+r12*1]
00007eafdc3cf43b  lea r12, [rax+0x28]
00007eafdc3cf43f  mov r10, [r13+r12*1]
00007eafdc3cf444  movq xmm1, r11
00007eafdc3cf449  movq xmm10, r10
00007eafdc3cf44e  movq xmm1, xmm1
00007eafdc3cf452  vmovaps [rsp+0x80], xmm1
00007eafdc3cf45b  movq xmm1, xmm1
00007eafdc3cf45f  movaps [r15+0x150], xmm1
00007eafdc3cf467  movq xmm10, xmm10
00007eafdc3cf46c  vmovaps [rsp+0x90], xmm10
00007eafdc3cf475  movq xmm10, xmm10
00007eafdc3cf47a  movaps [r15+0x140], xmm10
00007eafdc3cf482  lea r12, [rax+0x10]
00007eafdc3cf486  mov r11, [r13+r12*1]
00007eafdc3cf48b  lea r12, [rax+0x18]
00007eafdc3cf48f  mov r10, [r13+r12*1]
00007eafdc3cf494  movq xmm1, r11
00007eafdc3cf499  movq xmm10, r10
00007eafdc3cf49e  movq xmm1, xmm1
00007eafdc3cf4a2  vmovaps [rsp+0xA0], xmm1
00007eafdc3cf4ab  movq xmm1, xmm1
00007eafdc3cf4af  movaps [r15+0x170], xmm1
00007eafdc3cf4b7  movq xmm10, xmm10
00007eafdc3cf4bc  vmovaps [rsp+0xB0], xmm10
00007eafdc3cf4c5  movq xmm10, xmm10
00007eafdc3cf4ca  movaps [r15+0x160], xmm10
00007eafdc3cf4d2  mov r12, [r13+rax*1]
00007eafdc3cf4d7  vmovq xmm1, r12
00007eafdc3cf4dc  vpbroadcastq xmm1, xmm1
00007eafdc3cf4e1  lea r12, [rax+0x08]
00007eafdc3cf4e5  mov rax, [r13+r12*1]
00007eafdc3cf4ea  movq xmm10, rax
00007eafdc3cf4ef  movaps [r15+0x230], xmm10
00007eafdc3cf4f7  lea rax, [r14+0x50]
00007eafdc3cf4fb  movups xmm10, [r13+rax*1]
00007eafdc3cf501  lea rax, [r14+0x60]
00007eafdc3cf505  vmovaps [rsp+0xC0], xmm1
00007eafdc3cf50e  movups xmm1, [r13+rax*1]
00007eafdc3cf514  lea rax, [r14+0x30]
00007eafdc3cf518  vmovaps [rsp+0xD0], xmm1
00007eafdc3cf521  movups xmm1, [r13+rax*1]
00007eafdc3cf527  mov qword ptr [r15+0x60], 0x430920
00007eafdc3cf52f  mov qword ptr [r15+0x58], 0x40
00007eafdc3cf537  vmovaps [rsp+0xE0], xmm1
00007eafdc3cf540  vmovaps [rsp+0xF0], xmm15
00007eafdc3cf549  vmovaps xmm15, [rsp+0xC0]
00007eafdc3cf552  vmovaps [rsp+0xC0], xmm14
00007eafdc3cf55b  vmovaps xmm14, [rsp+0x40]
00007eafdc3cf561  vmovaps [rsp+0x40], xmm13
00007eafdc3cf567  movaps xmm1, xmm15
00007eafdc3cf56b  mulpd xmm1, xmm14
00007eafdc3cf570  vcmppd xmm13, xmm1, xmm1, 0x03
00007eafdc3cf575  ptest xmm13, xmm13
00007eafdc3cf57b  jnz 0x00007EAFDC3D0682
00007eafdc3cf581  movq xmm14, qword ptr [r15+0x230]
00007eafdc3cf58a  vmovaps [rsp+0x100], xmm14
00007eafdc3cf593  vpermilpd xmm14, xmm14, 0x00
00007eafdc3cf599  vmovaps [rsp+0x110], xmm1
00007eafdc3cf5a2  vmovaps xmm1, [rsp+0xE0]
00007eafdc3cf5ab  vmovaps [rsp+0xE0], xmm15
00007eafdc3cf5b4  movaps xmm13, xmm1
00007eafdc3cf5b8  mulpd xmm13, xmm14
00007eafdc3cf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
00007eafdc3cf5c3  ptest xmm15, xmm15
00007eafdc3cf5c9  jnz 0x00007EAFDC3D07C4
00007eafdc3cf5cf  vxorps xmm1, xmm1, xmm1
00007eafdc3cf5d3  vpbroadcastq xmm1, xmm1
00007eafdc3cf5d8  vmovaps xmm14, [rsp+0xE0]
00007eafdc3cf5e1  vmovaps [rsp+0xE0], xmm1
00007eafdc3cf5ea  vmovaps xmm1, [rsp+0xD0]
00007eafdc3cf5f3  vmovaps [rsp+0xD0], xmm13
00007eafdc3cf5fc  movaps xmm15, xmm14
00007eafdc3cf600  mulpd xmm15, xmm1
00007eafdc3cf605  vcmppd xmm13, xmm15, xmm15, 0x03
00007eafdc3cf60b  ptest xmm13, xmm13
00007eafdc3cf611  jnz 0x00007EAFDC3D0907
00007eafdc3cf617  movaps xmm1, xmm14
00007eafdc3cf61b  mulpd xmm1, xmm10
00007eafdc3cf620  vcmppd xmm13, xmm1, xmm1, 0x03
00007eafdc3cf625  ptest xmm13, xmm13
00007eafdc3cf62b  jnz 0x00007EAFDC3D0A4A
00007eafdc3cf631  movaps xmm13, xmm14
00007eafdc3cf635  mulpd xmm13, xmm2
00007eafdc3cf63a  vcmppd xmm10, xmm13, xmm13, 0x03
00007eafdc3cf640  ptest xmm10, xmm10
00007eafdc3cf646  jnz 0x00007EAFDC3D0B8C
00007eafdc3cf64c  vmovaps [rsp+0x120], xmm7
00007eafdc3cf655  vmovaps xmm14, [rsp+0x120]
00007eafdc3cf65e  por xmm7, xmm14
00007eafdc3cf663  vmovaps xmm14, [rsp+0xC0]
00007eafdc3cf66c  vmovaps xmm10, [rsp+0xC0]
00007eafdc3cf675  por xmm14, xmm10
00007eafdc3cf67a  vmovaps xmm2, [rsp+0x100]
00007eafdc3cf683  vpermilpd xmm2, xmm2, 0x00
00007eafdc3cf689  vmovaps [rsp+0xC0], xmm1
00007eafdc3cf692  vmovaps [rsp+0x120], xmm15
00007eafdc3cf69b  movaps xmm1, xmm10
00007eafdc3cf69f  mulpd xmm1, xmm2
00007eafdc3cf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
00007eafdc3cf6a8  ptest xmm15, xmm15
00007eafdc3cf6ae  jnz 0x00007EAFDC3D0CCF
00007eafdc3cf6b4  xor eax, eax
00007eafdc3cf6b6  mov r12d, 0x40
00007eafdc3cf6bc  mov r11d, 0x200
00007eafdc3cf6c2  cmp r12, r11
00007eafdc3cf6c5  cmc
00007eafdc3cf6c6  lahf
00007eafdc3cf6c7  seto al
00007eafdc3cf6ca  mov [r15+0x108], eax
00007eafdc3cf6d1  vmovaps xmm10, [rsp+0x110]
00007eafdc3cf6da  vmovaps xmm2, [rsp+0xE0]
00007eafdc3cf6e3  vmovaps [rsp+0xE0], xmm1
00007eafdc3cf6ec  movaps xmm15, xmm10
00007eafdc3cf6f0  addpd xmm15, xmm2
00007eafdc3cf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
00007eafdc3cf6fb  ptest xmm1, xmm1
00007eafdc3cf700  jnz 0x00007EAFDC3D0E10
00007eafdc3cf706  vmovaps xmm10, [rsp+0x120]
00007eafdc3cf70f  vmovaps [rsp+0x110], xmm15
00007eafdc3cf718  movaps xmm1, xmm10
00007eafdc3cf71c  addpd xmm1, xmm12
00007eafdc3cf721  vcmppd xmm15, xmm1, xmm1, 0x03
00007eafdc3cf726  ptest xmm15, xmm15
00007eafdc3cf72c  jnz 0x00007EAFDC3D0F53
00007eafdc3cf732  vmovaps xmm10, [rsp+0xC0]
00007eafdc3cf73b  vmovaps [rsp+0xC0], xmm1
00007eafdc3cf744  movaps xmm15, xmm10
00007eafdc3cf748  addpd xmm15, xmm12
00007eafdc3cf74d  vcmppd xmm1, xmm15, xmm15, 0x03
00007eafdc3cf753  ptest xmm1, xmm1
00007eafdc3cf758  jnz 0x00007EAFDC3D1095
00007eafdc3cf75e  vmovaps xmm1, [rsp+0x30]
00007eafdc3cf764  vmovaps xmm12, [rsp+0x30]
00007eafdc3cf76a  por xmm1, xmm12
00007eafdc3cf76f  vmovaps xmm12, [rsp+0x20]
00007eafdc3cf775  vmovaps xmm10, [rsp+0x20]
00007eafdc3cf77b  por xmm12, xmm10
00007eafdc3cf780  vmovaps [rsp+0x20], xmm5
00007eafdc3cf786  vmovaps xmm10, [rsp+0x20]
00007eafdc3cf78c  por xmm5, xmm10
00007eafdc3cf791  vmovaps [rsp+0x20], xmm11
00007eafdc3cf797  vmovaps xmm10, [rsp+0x20]
00007eafdc3cf79d  por xmm11, xmm10
00007eafdc3cf7a2  vmovaps [rsp+0x20], xmm4
00007eafdc3cf7a8  vmovaps xmm10, [rsp+0x20]
00007eafdc3cf7ae  por xmm4, xmm10
00007eafdc3cf7b3  vmovaps [rsp+0x20], xmm8
00007eafdc3cf7b9  vmovaps xmm10, [rsp+0x20]
00007eafdc3cf7bf  por xmm8, xmm10
00007eafdc3cf7c4  vmovaps xmm10, [rsp+0xF0]
00007eafdc3cf7cd  vmovaps [rsp+0x20], xmm1
00007eafdc3cf7d3  vmovaps xmm1, [rsp+0xF0]
00007eafdc3cf7dc  por xmm10, xmm1
00007eafdc3cf7e1  lea rax, [r14+0xA0]
00007eafdc3cf7e8  movups xmm1, [r13+rax*1]
00007eafdc3cf7ee  lea rax, [r14+0xB0]
00007eafdc3cf7f5  vmovaps [rsp+0x30], xmm1
00007eafdc3cf7fb  movups xmm1, [r13+rax*1]
00007eafdc3cf801  vmovaps [rsp+0xF0], xmm1
00007eafdc3cf80a  vmovaps [rsp+0x120], xmm15
00007eafdc3cf813  movaps xmm1, xmm13
00007eafdc3cf817  addpd xmm1, xmm2
00007eafdc3cf81b  vcmppd xmm15, xmm1, xmm1, 0x03
00007eafdc3cf820  ptest xmm15, xmm15
00007eafdc3cf826  jnz 0x00007EAFDC3D11ED
00007eafdc3cf82c  lea rax, [r14+0xF0]
00007eafdc3cf833  movups xmm15, [r13+rax*1]
00007eafdc3cf839  vmovaps xmm2, [rsp+0xC0]
00007eafdc3cf842  vmovaps [rsp+0xC0], xmm1
00007eafdc3cf84b  vmovaps xmm1, [rsp+0xE0]
00007eafdc3cf854  vmovaps [rsp+0xE0], xmm15
00007eafdc3cf85d  movaps xmm13, xmm2
00007eafdc3cf861  addpd xmm13, xmm1
00007eafdc3cf866  vcmppd xmm15, xmm13, xmm13, 0x03
00007eafdc3cf86c  ptest xmm15, xmm15
00007eafdc3cf872  jnz 0x00007EAFDC3D1338
00007eafdc3cf878  vmovaps xmm15, [rsp+0x120]
00007eafdc3cf881  vmovaps xmm2, [rsp+0xD0]
00007eafdc3cf88a  vmovaps [rsp+0xD0], xmm14
00007eafdc3cf893  movaps xmm1, xmm15
00007eafdc3cf897  addpd xmm1, xmm2
00007eafdc3cf89b  vcmppd xmm14, xmm1, xmm1, 0x03
00007eafdc3cf8a0  ptest xmm14, xmm14
00007eafdc3cf8a6  jnz 0x00007EAFDC3D147A
00007eafdc3cf8ac  vmovaps xmm15, [rsp+0x100]
00007eafdc3cf8b5  vpermilpd xmm15, xmm15, 0x00
00007eafdc3cf8bb  vmovaps xmm2, [rsp+0xF0]
00007eafdc3cf8c4  vmovaps [rsp+0xF0], xmm1
00007eafdc3cf8cd  movaps xmm14, xmm2
00007eafdc3cf8d1  mulpd xmm14, xmm15
00007eafdc3cf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
00007eafdc3cf8dc  ptest xmm1, xmm1
00007eafdc3cf8e1  jnz 0x00007EAFDC3D15BB
00007eafdc3cf8e7  vmovaps xmm1, [rsp+0xA0]
00007eafdc3cf8f0  vpermilpd xmm1, xmm1, 0x00
00007eafdc3cf8f6  vmovaps xmm2, [rsp+0xE0]
00007eafdc3cf8ff  vmovaps [rsp+0xE0], xmm14
00007eafdc3cf908  movaps xmm15, xmm2
00007eafdc3cf90c  mulpd xmm15, xmm1
00007eafdc3cf911  vcmppd xmm14, xmm15, xmm15, 0x03
00007eafdc3cf917  ptest xmm14, xmm14
00007eafdc3cf91d  jnz 0x00007EAFDC3D16FE
00007eafdc3cf923  lea rax, [r14+0xE0]
00007eafdc3cf92a  movups xmm1, [r13+rax*1]
00007eafdc3cf930  vmovaps xmm14, [rsp+0x100]
00007eafdc3cf939  vpermilpd xmm14, xmm14, 0x00
00007eafdc3cf93f  vmovaps [rsp+0x100], xmm1
00007eafdc3cf948  vmovaps xmm1, [rsp+0x30]
00007eafdc3cf94e  vmovaps [rsp+0x30], xmm15
00007eafdc3cf954  movaps xmm2, xmm1
00007eafdc3cf957  mulpd xmm2, xmm14
00007eafdc3cf95c  vcmppd xmm15, xmm2, xmm2, 0x03
00007eafdc3cf961  ptest xmm15, xmm15
00007eafdc3cf967  jnz 0x00007EAFDC3D184A
00007eafdc3cf96d  vmovaps [rsp+0x120], xmm10
00007eafdc3cf976  vmovaps xmm1, [rsp+0x120]
00007eafdc3cf97f  por xmm10, xmm1
00007eafdc3cf984  movaps [r15+0x300], xmm10
00007eafdc3cf98c  vmovaps [rsp+0x120], xmm8
00007eafdc3cf995  vmovaps xmm1, [rsp+0x120]
00007eafdc3cf99e  por xmm8, xmm1
00007eafdc3cf9a3  movaps [r15+0x190], xmm8
00007eafdc3cf9ab  vmovaps xmm1, [rsp+0xA0]
00007eafdc3cf9b4  vpermilpd xmm1, xmm1, 0x00
00007eafdc3cf9ba  vmovaps xmm14, [rsp+0x100]
00007eafdc3cf9c3  vmovaps [rsp+0x100], xmm13
00007eafdc3cf9cc  movaps xmm15, xmm14
00007eafdc3cf9d0  mulpd xmm15, xmm1
00007eafdc3cf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
00007eafdc3cf9db  ptest xmm13, xmm13
00007eafdc3cf9e1  jnz 0x00007EAFDC3D198B
00007eafdc3cf9e7  lea rax, [r14+0x90]
00007eafdc3cf9ee  movups xmm1, [r13+rax*1]
00007eafdc3cf9f4  vmovaps [rsp+0x120], xmm4
00007eafdc3cf9fd  vmovaps xmm14, [rsp+0x120]
00007eafdc3cfa06  por xmm4, xmm14
00007eafdc3cfa0b  movaps [r15+0x1C0], xmm4
00007eafdc3cfa13  vmovaps [rsp+0x120], xmm11
00007eafdc3cfa1c  vmovaps xmm14, [rsp+0x120]
00007eafdc3cfa25  por xmm11, xmm14
00007eafdc3cfa2a  movaps [r15+0x200], xmm11
00007eafdc3cfa32  vmovaps [rsp+0x120], xmm5
00007eafdc3cfa3b  vmovaps xmm14, [rsp+0x120]
00007eafdc3cfa44  por xmm5, xmm14
00007eafdc3cfa49  movaps [r15+0x2D0], xmm5
00007eafdc3cfa51  vmovaps [rsp+0x120], xmm12
00007eafdc3cfa5a  vmovaps xmm14, [rsp+0x120]
00007eafdc3cfa63  por xmm12, xmm14
00007eafdc3cfa68  movaps [r15+0x2E0], xmm12
00007eafdc3cfa70  vmovaps xmm13, [rsp+0x110]
00007eafdc3cfa79  vmovaps [rsp+0x110], xmm1
00007eafdc3cfa82  vmovaps xmm1, [rsp+0xE0]
00007eafdc3cfa8b  vmovaps [rsp+0xE0], xmm15
00007eafdc3cfa94  movaps xmm14, xmm13
00007eafdc3cfa98  addpd xmm14, xmm1
00007eafdc3cfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
00007eafdc3cfaa3  ptest xmm15, xmm15
00007eafdc3cfaa9  jnz 0x00007EAFDC3D1AD8
00007eafdc3cfaaf  vmovaps xmm1, [rsp+0xA0]
00007eafdc3cfab8  vpermilpd xmm1, xmm1, 0x00
00007eafdc3cfabe  vmovaps xmm13, [rsp+0x110]
00007eafdc3cfac7  vmovaps [rsp+0x110], xmm14
00007eafdc3cfad0  movaps xmm15, xmm13
00007eafdc3cfad4  mulpd xmm15, xmm1
00007eafdc3cfad9  vcmppd xmm14, xmm15, xmm15, 0x03
00007eafdc3cfadf  ptest xmm14, xmm14
00007eafdc3cfae5  jnz 0x00007EAFDC3D1C1B
00007eafdc3cfaeb  lea rax, [r14+0x80]
00007eafdc3cfaf2  movups xmm1, [r13+rax*1]
00007eafdc3cfaf8  vmovaps xmm13, [rsp+0xC0]
00007eafdc3cfb01  vmovaps [rsp+0xC0], xmm1
00007eafdc3cfb0a  movaps xmm14, xmm13
00007eafdc3cfb0e  addpd xmm14, xmm2
00007eafdc3cfb13  vcmppd xmm1, xmm14, xmm14, 0x03
00007eafdc3cfb19  ptest xmm1, xmm1
00007eafdc3cfb1e  jnz 0x00007EAFDC3D1D68
00007eafdc3cfb24  vmovaps xmm13, [rsp+0x100]
00007eafdc3cfb2d  vmovaps xmm2, [rsp+0x30]
00007eafdc3cfb33  vmovaps [rsp+0x30], xmm15
00007eafdc3cfb39  movaps xmm1, xmm13
00007eafdc3cfb3d  addpd xmm1, xmm2
00007eafdc3cfb41  vcmppd xmm15, xmm1, xmm1, 0x03
00007eafdc3cfb46  ptest xmm15, xmm15
00007eafdc3cfb4c  jnz 0x00007EAFDC3D1EAB
00007eafdc3cfb52  vmovaps xmm15, [rsp+0x20]
00007eafdc3cfb58  vmovaps xmm13, [rsp+0x20]
00007eafdc3cfb5e  por xmm15, xmm13
00007eafdc3cfb63  movaps [r15+0x2F0], xmm15
00007eafdc3cfb6b  vmovaps xmm13, [rsp+0xA0]
00007eafdc3cfb74  vpermilpd xmm13, xmm13, 0x00
00007eafdc3cfb7a  vmovaps [rsp+0x20], xmm1
00007eafdc3cfb80  vmovaps xmm1, [rsp+0xC0]
00007eafdc3cfb89  vmovaps [rsp+0xA0], xmm15
00007eafdc3cfb92  movaps xmm2, xmm1
00007eafdc3cfb95  mulpd xmm2, xmm13
00007eafdc3cfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
00007eafdc3cfb9f  ptest xmm15, xmm15
00007eafdc3cfba5  jnz 0x00007EAFDC3D1FEC
00007eafdc3cfbab  lea rax, [r14+0xD0]
00007eafdc3cfbb2  movups xmm1, [r13+rax*1]
00007eafdc3cfbb8  vmovaps xmm13, [rsp+0xF0]
00007eafdc3cfbc1  vmovaps [rsp+0xC0], xmm1
00007eafdc3cfbca  vmovaps xmm1, [rsp+0xE0]
00007eafdc3cfbd3  vmovaps [rsp+0xE0], xmm14
00007eafdc3cfbdc  movaps xmm15, xmm13
00007eafdc3cfbe0  addpd xmm15, xmm1
00007eafdc3cfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
00007eafdc3cfbeb  ptest xmm14, xmm14
00007eafdc3cfbf1  jnz 0x00007EAFDC3D2137
00007eafdc3cfbf7  vmovaps xmm1, [rsp+0xB0]
00007eafdc3cfc00  vpermilpd xmm1, xmm1, 0x00
00007eafdc3cfc06  movaps xmm14, xmm11
00007eafdc3cfc0a  mulpd xmm14, xmm1
00007eafdc3cfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
00007eafdc3cfc15  ptest xmm13, xmm13
00007eafdc3cfc1b  jnz 0x00007EAFDC3D227A
00007eafdc3cfc21  movaps [r15+0x260], xmm14
00007eafdc3cfc29  vxorps xmm1, xmm1, xmm1
00007eafdc3cfc2d  vpbroadcastq xmm1, xmm1
00007eafdc3cfc32  movaps [r15+0x1B0], xmm1
00007eafdc3cfc3a  vmovaps xmm1, [rsp+0xB0]
00007eafdc3cfc43  vpermilpd xmm1, xmm1, 0x00
00007eafdc3cfc49  vmovaps xmm11, [rsp+0xC0]
00007eafdc3cfc52  vmovaps [rsp+0xC0], xmm15
00007eafdc3cfc5b  movaps xmm13, xmm11
00007eafdc3cfc5f  mulpd xmm13, xmm1
00007eafdc3cfc64  vcmppd xmm15, xmm13, xmm13, 0x03
00007eafdc3cfc6a  ptest xmm15, xmm15
00007eafdc3cfc70  jnz 0x00007EAFDC3D23BD
00007eafdc3cfc76  lea rax, [r14+0xC0]
00007eafdc3cfc7d  movups xmm1, [r13+rax*1]
00007eafdc3cfc83  vmovaps xmm11, [rsp+0x110]
00007eafdc3cfc8c  vmovaps [rsp+0xF0], xmm1
00007eafdc3cfc95  vmovaps xmm1, [rsp+0x30]
00007eafdc3cfc9b  vmovaps [rsp+0x30], xmm14
00007eafdc3cfca1  movaps xmm15, xmm11
00007eafdc3cfca5  addpd xmm15, xmm1
00007eafdc3cfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
00007eafdc3cfcb0  ptest xmm14, xmm14
00007eafdc3cfcb6  jnz 0x00007EAFDC3D250A
00007eafdc3cfcbc  vmovaps [rsp+0x100], xmm9
00007eafdc3cfcc5  vmovaps xmm1, [rsp+0x100]
00007eafdc3cfcce  por xmm9, xmm1
00007eafdc3cfcd3  movaps [r15+0x270], xmm9
00007eafdc3cfcdb  vmovaps [rsp+0x100], xmm6
00007eafdc3cfce4  vmovaps xmm1, [rsp+0x100]
00007eafdc3cfced  por xmm6, xmm1
00007eafdc3cfcf1  movaps [r15+0x1A0], xmm6
00007eafdc3cfcf9  vmovaps xmm14, [rsp+0xB0]
00007eafdc3cfd02  vpermilpd xmm14, xmm14, 0x00
00007eafdc3cfd08  vmovaps xmm6, [rsp+0xF0]
00007eafdc3cfd11  vmovaps [rsp+0xF0], xmm1
00007eafdc3cfd1a  movaps xmm11, xmm6
00007eafdc3cfd1e  mulpd xmm11, xmm14
00007eafdc3cfd23  vcmppd xmm1, xmm11, xmm11, 0x03
00007eafdc3cfd29  ptest xmm1, xmm1
00007eafdc3cfd2e  jnz 0x00007EAFDC3D264D
00007eafdc3cfd34  lea rax, [r14+0x20]
00007eafdc3cfd38  movups xmm1, [r13+rax*1]
00007eafdc3cfd3e  movaps [r15+0x110], xmm1
00007eafdc3cfd46  vmovaps xmm6, [rsp+0xE0]
00007eafdc3cfd4f  vmovaps [rsp+0xE0], xmm1
00007eafdc3cfd58  movaps xmm14, xmm6
00007eafdc3cfd5c  addpd xmm14, xmm2
00007eafdc3cfd61  vcmppd xmm1, xmm14, xmm14, 0x03
00007eafdc3cfd67  ptest xmm1, xmm1
00007eafdc3cfd6c  jnz 0x00007EAFDC3D279A
00007eafdc3cfd72  vmovaps xmm1, [rsp+0xB0]
00007eafdc3cfd7b  vpermilpd xmm1, xmm1, 0x00
00007eafdc3cfd81  movaps xmm6, xmm5
00007eafdc3cfd84  mulpd xmm6, xmm1
00007eafdc3cfd88  vcmppd xmm2, xmm6, xmm6, 0x03
00007eafdc3cfd8d  ptest xmm2, xmm2
00007eafdc3cfd92  jnz 0x00007EAFDC3D28DC
00007eafdc3cfd98  vmovaps xmm5, [rsp+0x20]
00007eafdc3cfd9e  movaps xmm1, xmm5
00007eafdc3cfda1  addpd xmm1, xmm13
00007eafdc3cfda6  vcmppd xmm2, xmm1, xmm1, 0x03
00007eafdc3cfdab  ptest xmm2, xmm2
00007eafdc3cfdb0  jnz 0x00007EAFDC3D2A1C
00007eafdc3cfdb6  vmovaps xmm13, [rsp+0x80]
00007eafdc3cfdbf  vpermilpd xmm13, xmm13, 0x00
00007eafdc3cfdc5  vmovaps xmm2, [rsp+0xE0]
00007eafdc3cfdce  vmovaps [rsp+0x20], xmm1
00007eafdc3cfdd4  movaps xmm5, xmm2
00007eafdc3cfdd7  mulpd xmm5, xmm13
00007eafdc3cfddc  vcmppd xmm1, xmm5, xmm5, 0x03
00007eafdc3cfde1  ptest xmm1, xmm1
00007eafdc3cfde6  jnz 0x00007EAFDC3D2B5D
00007eafdc3cfdec  vmovaps xmm1, [rsp+0x80]
00007eafdc3cfdf5  vpermilpd xmm1, xmm1, 0x00
00007eafdc3cfdfb  movaps xmm13, xmm10
00007eafdc3cfdff  mulpd xmm13, xmm1
00007eafdc3cfe04  vcmppd xmm2, xmm13, xmm13, 0x03
00007eafdc3cfe0a  ptest xmm2, xmm2
00007eafdc3cfe0f  jnz 0x00007EAFDC3D2C9E
00007eafdc3cfe15  vmovaps xmm10, [rsp+0x30]
00007eafdc3cfe1b  movaps xmm1, xmm15
00007eafdc3cfe1f  addpd xmm1, xmm10
00007eafdc3cfe24  vcmppd xmm2, xmm1, xmm1, 0x03
00007eafdc3cfe29  ptest xmm2, xmm2
00007eafdc3cfe2e  jnz 0x00007EAFDC3D2DE1
00007eafdc3cfe34  vmovaps xmm10, [rsp+0xC0]
00007eafdc3cfe3d  movaps xmm15, xmm10
00007eafdc3cfe41  addpd xmm15, xmm11
00007eafdc3cfe46  vcmppd xmm2, xmm15, xmm15, 0x03
00007eafdc3cfe4c  ptest xmm2, xmm2
00007eafdc3cfe51  jnz 0x00007EAFDC3D2F23
00007eafdc3cfe57  vmovaps xmm11, [rsp+0x80]
00007eafdc3cfe60  vpermilpd xmm11, xmm11, 0x00
00007eafdc3cfe66  movaps xmm10, xmm12
00007eafdc3cfe6a  mulpd xmm10, xmm11
00007eafdc3cfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
00007eafdc3cfe75  ptest xmm2, xmm2
00007eafdc3cfe7a  jnz 0x00007EAFDC3D3067
00007eafdc3cfe80  vmovaps xmm12, [rsp+0x80]
00007eafdc3cfe89  vpermilpd xmm12, xmm12, 0x00
00007eafdc3cfe8f  vmovaps xmm2, [rsp+0xA0]
00007eafdc3cfe98  vmovaps [rsp+0x30], xmm1
00007eafdc3cfe9e  movaps xmm11, xmm2
00007eafdc3cfea2  mulpd xmm11, xmm12
00007eafdc3cfea7  vcmppd xmm1, xmm11, xmm11, 0x03
00007eafdc3cfead  ptest xmm1, xmm1
00007eafdc3cfeb2  jnz 0x00007EAFDC3D31AB
00007eafdc3cfeb8  movaps xmm1, xmm14
00007eafdc3cfebc  addpd xmm1, xmm6
00007eafdc3cfec0  vcmppd xmm12, xmm1, xmm1, 0x03
00007eafdc3cfec5  ptest xmm12, xmm12
00007eafdc3cfecb  jnz 0x00007EAFDC3D32EE
00007eafdc3cfed1  vmovaps xmm12, [rsp+0x20]
00007eafdc3cfed7  movaps xmm14, xmm12
00007eafdc3cfedb  addpd xmm14, xmm5
00007eafdc3cfee0  vcmppd xmm6, xmm14, xmm14, 0x03
00007eafdc3cfee6  ptest xmm6, xmm6
00007eafdc3cfeeb  jnz 0x00007EAFDC3D342F
00007eafdc3cfef1  vmovaps xmm12, [rsp+0x90]
00007eafdc3cfefa  vpermilpd xmm12, xmm12, 0x00
00007eafdc3cff00  movaps xmm6, xmm9
00007eafdc3cff04  mulpd xmm6, xmm12
00007eafdc3cff09  vcmppd xmm5, xmm6, xmm6, 0x03
00007eafdc3cff0e  ptest xmm5, xmm5
00007eafdc3cff13  jnz 0x00007EAFDC3D3572
00007eafdc3cff19  movaps xmm12, xmm15
00007eafdc3cff1d  addpd xmm12, xmm13
00007eafdc3cff22  vcmppd xmm9, xmm12, xmm12, 0x03
00007eafdc3cff28  ptest xmm9, xmm9
00007eafdc3cff2e  jnz 0x00007EAFDC3D36B4
00007eafdc3cff34  vmovaps xmm13, [rsp+0x30]
00007eafdc3cff3a  movaps xmm15, xmm13
00007eafdc3cff3e  addpd xmm15, xmm10
00007eafdc3cff43  vcmppd xmm9, xmm15, xmm15, 0x03
00007eafdc3cff49  ptest xmm9, xmm9
00007eafdc3cff4f  jnz 0x00007EAFDC3D37F8
00007eafdc3cff55  vmovaps xmm13, [rsp+0xD0]
00007eafdc3cff5e  vmovaps xmm10, [rsp+0xD0]
00007eafdc3cff67  por xmm13, xmm10
00007eafdc3cff6c  movaps [r15+0x250], xmm13
00007eafdc3cff74  vmovaps [rsp+0x20], xmm7
00007eafdc3cff7a  vmovaps xmm13, [rsp+0x20]
00007eafdc3cff80  por xmm7, xmm13
00007eafdc3cff85  movaps [r15+0x2A0], xmm7
00007eafdc3cff8d  vmovaps [rsp+0x20], xmm3
00007eafdc3cff93  vmovaps xmm13, [rsp+0x20]
00007eafdc3cff99  por xmm3, xmm13
00007eafdc3cff9e  movaps [r15+0x1D0], xmm3
00007eafdc3cffa6  lea rax, [r14+0x40]
00007eafdc3cffaa  movups xmm13, [r13+rax*1]
00007eafdc3cffb0  movaps [r15+0x2C0], xmm13
00007eafdc3cffb8  vmovaps xmm10, [rsp+0x90]
00007eafdc3cffc1  vpermilpd xmm10, xmm10, 0x00
00007eafdc3cffc7  movaps xmm9, xmm8
00007eafdc3cffcb  mulpd xmm9, xmm10
00007eafdc3cffd0  vcmppd xmm5, xmm9, xmm9, 0x03
00007eafdc3cffd6  ptest xmm5, xmm5
00007eafdc3cffdb  jnz 0x00007EAFDC3D3946
00007eafdc3cffe1  movaps xmm10, xmm1
00007eafdc3cffe5  addpd xmm10, xmm11
00007eafdc3cffea  vcmppd xmm8, xmm10, xmm10, 0x03
00007eafdc3cfff0  ptest xmm8, xmm8
00007eafdc3cfff6  jnz 0x00007EAFDC3D3A8A
00007eafdc3cfffc  movaps xmm1, xmm14
00007eafdc3d0000  addpd xmm1, xmm6
00007eafdc3d0004  vcmppd xmm11, xmm1, xmm1, 0x03
00007eafdc3d0009  ptest xmm11, xmm11
00007eafdc3d000f  jnz 0x00007EAFDC3D3BCD
00007eafdc3d0015  vmovaps xmm14, [rsp+0x90]
00007eafdc3d001e  vpermilpd xmm14, xmm14, 0x00
00007eafdc3d0024  movaps xmm11, xmm13
00007eafdc3d0028  mulpd xmm11, xmm14
00007eafdc3d002d  vcmppd xmm8, xmm11, xmm11, 0x03
00007eafdc3d0033  ptest xmm8, xmm8
00007eafdc3d0039  jnz 0x00007EAFDC3D3D0E
00007eafdc3d003f  vmovaps xmm14, [rsp+0x90]
00007eafdc3d0048  vpermilpd xmm14, xmm14, 0x00
00007eafdc3d004e  vmovaps xmm8, [rsp+0x10]
00007eafdc3d0054  movaps xmm13, xmm8
00007eafdc3d0058  mulpd xmm13, xmm14
00007eafdc3d005d  vcmppd xmm6, xmm13, xmm13, 0x03
00007eafdc3d0063  ptest xmm6, xmm6
00007eafdc3d0068  jnz 0x00007EAFDC3D3E52
00007eafdc3d006e  vmovaps xmm14, [rsp+0x60]
00007eafdc3d0074  vpermilpd xmm14, xmm14, 0x00
00007eafdc3d007a  movaps xmm8, xmm7
00007eafdc3d007e  mulpd xmm8, xmm14
00007eafdc3d0083  vcmppd xmm6, xmm8, xmm8, 0x03
00007eafdc3d0089  ptest xmm6, xmm6
00007eafdc3d008e  jnz 0x00007EAFDC3D3F96
00007eafdc3d0094  movaps xmm14, xmm12
00007eafdc3d0098  addpd xmm14, xmm9
00007eafdc3d009d  vcmppd xmm7, xmm14, xmm14, 0x03
00007eafdc3d00a3  ptest xmm7, xmm7
00007eafdc3d00a8  jnz 0x00007EAFDC3D40D9
00007eafdc3d00ae  vmovaps xmm12, [rsp+0x60]
00007eafdc3d00b4  vpermilpd xmm12, xmm12, 0x00
00007eafdc3d00ba  vmovaps xmm7, [rsp+0xF0]
00007eafdc3d00c3  movaps xmm9, xmm7
00007eafdc3d00c7  mulpd xmm9, xmm12
00007eafdc3d00cc  vcmppd xmm6, xmm9, xmm9, 0x03
00007eafdc3d00d2  ptest xmm6, xmm6
00007eafdc3d00d7  jnz 0x00007EAFDC3D421D
00007eafdc3d00dd  movaps xmm12, xmm15
00007eafdc3d00e1  addpd xmm12, xmm11
00007eafdc3d00e6  vcmppd xmm7, xmm12, xmm12, 0x03
00007eafdc3d00ec  ptest xmm7, xmm7
00007eafdc3d00f1  jnz 0x00007EAFDC3D4360
00007eafdc3d00f7  vmovaps xmm15, [rsp+0x60]
00007eafdc3d00fd  vpermilpd xmm15, xmm15, 0x00
00007eafdc3d0103  vmovaps xmm7, [rsp+0x40]
00007eafdc3d0109  movaps xmm11, xmm7
00007eafdc3d010d  mulpd xmm11, xmm15
00007eafdc3d0112  vcmppd xmm6, xmm11, xmm11, 0x03
00007eafdc3d0118  ptest xmm6, xmm6
00007eafdc3d011d  jnz 0x00007EAFDC3D44A4
00007eafdc3d0123  movaps xmm15, xmm10
00007eafdc3d0127  addpd xmm15, xmm13
00007eafdc3d012c  vcmppd xmm7, xmm15, xmm15, 0x03
00007eafdc3d0132  ptest xmm7, xmm7
00007eafdc3d0137  jnz 0x00007EAFDC3D45E7
00007eafdc3d013d  vmovaps xmm13, [rsp+0x60]
00007eafdc3d0143  vpermilpd xmm13, xmm13, 0x00
00007eafdc3d0149  vmovaps xmm7, [rsp+0x50]
00007eafdc3d014f  movaps xmm10, xmm7
00007eafdc3d0153  mulpd xmm10, xmm13
00007eafdc3d0158  vcmppd xmm6, xmm10, xmm10, 0x03
00007eafdc3d015e  ptest xmm6, xmm6
00007eafdc3d0163  jnz 0x00007EAFDC3D472B
00007eafdc3d0169  movaps xmm13, xmm1
00007eafdc3d016d  addpd xmm13, xmm8
00007eafdc3d0172  vcmppd xmm7, xmm13, xmm13, 0x03
00007eafdc3d0178  ptest xmm7, xmm7
00007eafdc3d017d  jnz 0x00007EAFDC3D486E
00007eafdc3d0183  lea rax, [r14+0x70]
00007eafdc3d0187  movups xmm1, [r13+rax*1]
00007eafdc3d018d  movaps [r15+0x240], xmm1
00007eafdc3d0195  movaps xmm8, xmm14
00007eafdc3d0199  addpd xmm8, xmm9
00007eafdc3d019e  vcmppd xmm7, xmm8, xmm8, 0x03
00007eafdc3d01a4  ptest xmm7, xmm7
00007eafdc3d01a9  jnz 0x00007EAFDC3D49BB
00007eafdc3d01af  movaps [r15+0x170], xmm8
00007eafdc3d01b7  vmovaps xmm14, [rsp+0x70]
00007eafdc3d01bd  vpermilpd xmm14, xmm14, 0x00
00007eafdc3d01c3  movaps xmm9, xmm1
00007eafdc3d01c7  mulpd xmm9, xmm14
00007eafdc3d01cc  vcmppd xmm7, xmm9, xmm9, 0x03
00007eafdc3d01d2  ptest xmm7, xmm7
00007eafdc3d01d7  jnz 0x00007EAFDC3D4AFF
00007eafdc3d01dd  vmovaps xmm1, [rsp+0x70]
00007eafdc3d01e3  vpermilpd xmm1, xmm1, 0x00
00007eafdc3d01e9  movaps xmm14, xmm4
00007eafdc3d01ed  mulpd xmm14, xmm1
00007eafdc3d01f2  vcmppd xmm7, xmm14, xmm14, 0x03
00007eafdc3d01f8  ptest xmm7, xmm7
00007eafdc3d01fd  jnz 0x00007EAFDC3D4C42
00007eafdc3d0203  movaps [r15+0x180], xmm14
00007eafdc3d020b  movaps xmm1, xmm12
00007eafdc3d020f  addpd xmm1, xmm11
00007eafdc3d0214  vcmppd xmm7, xmm1, xmm1, 0x03
00007eafdc3d0219  ptest xmm7, xmm7
00007eafdc3d021e  jnz 0x00007EAFDC3D4D84
00007eafdc3d0224  movaps [r15+0x210], xmm1
00007eafdc3d022c  movups xmm12, [r13+r14*1]
00007eafdc3d0232  lea rax, [r14+0x10]
00007eafdc3d0236  movups xmm11, [r13+rax*1]
00007eafdc3d023c  movaps [r15+0x230], xmm11
00007eafdc3d0244  movaps xmm7, xmm15
00007eafdc3d0248  addpd xmm7, xmm10
00007eafdc3d024d  vcmppd xmm6, xmm7, xmm7, 0x03
00007eafdc3d0252  ptest xmm6, xmm6
00007eafdc3d0257  jnz 0x00007EAFDC3D4EDA
00007eafdc3d025d  movaps [r15+0x130], xmm7
00007eafdc3d0265  vmovaps xmm15, [rsp+0x70]
00007eafdc3d026b  vpermilpd xmm15, xmm15, 0x00
00007eafdc3d0271  movaps xmm10, xmm11
00007eafdc3d0275  mulpd xmm10, xmm15
00007eafdc3d027a  vcmppd xmm6, xmm10, xmm10, 0x03
00007eafdc3d0280  ptest xmm6, xmm6
00007eafdc3d0285  jnz 0x00007EAFDC3D501C
00007eafdc3d028b  movaps [r15+0x220], xmm10
00007eafdc3d0293  vmovaps xmm15, [rsp+0x70]
00007eafdc3d0299  vpermilpd xmm15, xmm15, 0x00
00007eafdc3d029f  movaps xmm11, xmm12
00007eafdc3d02a3  mulpd xmm11, xmm15
00007eafdc3d02a8  vcmppd xmm6, xmm11, xmm11, 0x03
00007eafdc3d02ae  ptest xmm6, xmm6
00007eafdc3d02b3  jnz 0x00007EAFDC3D5160
00007eafdc3d02b9  movaps xmm15, xmm13
00007eafdc3d02bd  addpd xmm15, xmm9
00007eafdc3d02c2  vcmppd xmm12, xmm15, xmm15, 0x03
00007eafdc3d02c8  ptest xmm12, xmm12
00007eafdc3d02ce  jnz 0x00007EAFDC3D52A4
00007eafdc3d02d4  movaps [r15+0x140], xmm15
00007eafdc3d02dc  movaps xmm13, xmm8
00007eafdc3d02e0  addpd xmm13, xmm14
00007eafdc3d02e5  vcmppd xmm12, xmm13, xmm13, 0x03
00007eafdc3d02eb  ptest xmm12, xmm12
00007eafdc3d02f1  jnz 0x00007EAFDC3D53E8
00007eafdc3d02f7  movaps [r15+0x150], xmm13
00007eafdc3d02ff  movaps xmm14, xmm1
00007eafdc3d0303  addpd xmm14, xmm10
00007eafdc3d0308  vcmppd xmm12, xmm14, xmm14, 0x03
00007eafdc3d030e  ptest xmm12, xmm12
00007eafdc3d0314  jnz 0x00007EAFDC3D552C
00007eafdc3d031a  movaps [r15+0x160], xmm14
00007eafdc3d0322  movaps xmm1, xmm7
00007eafdc3d0325  addpd xmm1, xmm11
00007eafdc3d032a  vcmppd xmm12, xmm1, xmm1, 0x03
00007eafdc3d032f  ptest xmm12, xmm12
00007eafdc3d0335  jnz 0x00007EAFDC3D566F
00007eafdc3d033b  movaps [r15+0x120], xmm1
00007eafdc3d0343  mov eax, 0x430920
00007eafdc3d0348  movups [r13+rax*1], xmm15
00007eafdc3d034e  mov eax, 0x430930
00007eafdc3d0353  movups [r13+rax*1], xmm13
00007eafdc3d0359  mov eax, 0x430940
00007eafdc3d035e  movups [r13+rax*1], xmm14
00007eafdc3d0364  mov eax, 0x430950
00007eafdc3d0369  movups [r13+rax*1], xmm1
00007eafdc3d036f  mov eax, [r15+0x108]
00007eafdc3d0376  sahf
00007eafdc3d0377  jnz 0x00007EAFDC3D03A9
00007eafdc3d0379  cmp dword ptr [r15+0x318], 0x00
00007eafdc3d0381  jz 0x00007EAFDC3DB900
00007eafdc3d0387  nop [rax+rax*1], ax
00007eafdc3d0390  nop [rax+rax*1], eax
00007eafdc3d0398  mov eax, 0x410444
00007eafdc3d039d  mov [r15+0x100], rax
00007eafdc3d03a4  jmp 0x00007EAFDC1FE110
00007eafdc3d03a9  cmp dword ptr [r15+0x318], 0x00
00007eafdc3d03b1  jz 0x00007EAFDC3D57E0
00007eafdc3d03b7  nop [rax+rax*1], ax
00007eafdc3d03c0  nop [rax+rax*1], eax
00007eafdc3d03c8  mov eax, 0x410278
00007eafdc3d03cd  mov [r15+0x100], rax
00007eafdc3d03d4  jmp 0x00007EAFDC1FE110
00007eafdc3d03d9  int3
00007eafdc3d03da  call 0x00007EAFDC2B52F0
00007eafdc3d03df  jmp 0x00007EAFDC3CF016
00007eafdc3d03e4  call 0x00007EAFDC2C4620
00007eafdc3d03e9  jmp 0x00007EAFDC3CF023
00007eafdc3d03ee  call 0x00007EAFDC2C33A0
00007eafdc3d03f3  jmp 0x00007EAFDC3CF035
00007eafdc3d03f8  call 0x00007EAFDC2C2120
00007eafdc3d03fd  jmp 0x00007EAFDC3CF03F
00007eafdc3d0402  call 0x00007EAFDC2C0860
00007eafdc3d0407  jmp 0x00007EAFDC3CF067
00007eafdc3d040c  call 0x00007EAFDC2BF5F0
00007eafdc3d0411  jmp 0x00007EAFDC3CF073
00007eafdc3d0416  call 0x00007EAFDC2C0860
00007eafdc3d041b  jmp 0x00007EAFDC3CF0A5
00007eafdc3d0420  call 0x00007EAFDC2BF5F0
00007eafdc3d0425  jmp 0x00007EAFDC3CF0B1
00007eafdc3d042a  call 0x00007EAFDC2C4740
00007eafdc3d042f  jmp 0x00007EAFDC3CF0BE
00007eafdc3d0434  call 0x00007EAFDC2B5400
00007eafdc3d0439  jmp 0x00007EAFDC3CF0CB
00007eafdc3d043e  call 0x00007EAFDC2B52F0
00007eafdc3d0443  jmp 0x00007EAFDC3CF0D8
00007eafdc3d0448  call 0x00007EAFDC2C4620
00007eafdc3d044d  jmp 0x00007EAFDC3CF0E5
00007eafdc3d0452  call 0x00007EAFDC2C0860
00007eafdc3d0457  jmp 0x00007EAFDC3CF10D
00007eafdc3d045c  call 0x00007EAFDC2BF5F0
00007eafdc3d0461  jmp 0x00007EAFDC3CF119
00007eafdc3d0466  call 0x00007EAFDC209D70
00007eafdc3d046b  jmp 0x00007EAFDC3CF11F
00007eafdc3d0470  call 0x00007EAFDC2BE9C0
00007eafdc3d0475  jmp 0x00007EAFDC3CF129
00007eafdc3d047a  call 0x00007EAFDC2C0860
00007eafdc3d047f  jmp 0x00007EAFDC3CF151
00007eafdc3d0484  call 0x00007EAFDC2BF5F0
00007eafdc3d0489  jmp 0x00007EAFDC3CF15D
00007eafdc3d048e  call 0x00007EAFDC2BD750
00007eafdc3d0493  jmp 0x00007EAFDC3CF16A
00007eafdc3d0498  call 0x00007EAFDC2BC4E0
00007eafdc3d049d  jmp 0x00007EAFDC3CF177
00007eafdc3d04a2  call 0x00007EAFDC2C4740
00007eafdc3d04a7  jmp 0x00007EAFDC3CF184
00007eafdc3d04ac  call 0x00007EAFDC2B5400
00007eafdc3d04b1  jmp 0x00007EAFDC3CF191
00007eafdc3d04b6  call 0x00007EAFDC2B52F0
00007eafdc3d04bb  jmp 0x00007EAFDC3CF19E
00007eafdc3d04c0  call 0x00007EAFDC2C4620
00007eafdc3d04c5  jmp 0x00007EAFDC3CF1AB
00007eafdc3d04ca  call 0x00007EAFDC2C0860
00007eafdc3d04cf  jmp 0x00007EAFDC3CF1BE
00007eafdc3d04d4  call 0x00007EAFDC2BB270
00007eafdc3d04d9  jmp 0x00007EAFDC3CF1CB
00007eafdc3d04de  call 0x00007EAFDC2BA000
00007eafdc3d04e3  jmp 0x00007EAFDC3CF1D8
00007eafdc3d04e8  call 0x00007EAFDC2B8D90
00007eafdc3d04ed  jmp 0x00007EAFDC3CF1E5
00007eafdc3d04f2  call 0x00007EAFDC2B8A20
00007eafdc3d04f7  jmp 0x00007EAFDC3CF1F2
00007eafdc3d04fc  call 0x00007EAFDC2B5400
00007eafdc3d0501  jmp 0x00007EAFDC3CF1FC
00007eafdc3d0506  call 0x00007EAFDC2C2240
00007eafdc3d050b  jmp 0x00007EAFDC3CF206
00007eafdc3d0510  call 0x00007EAFDC2B52F0
00007eafdc3d0515  jmp 0x00007EAFDC3CF210
00007eafdc3d051a  call 0x00007EAFDC2C2120
00007eafdc3d051f  jmp 0x00007EAFDC3CF21A
00007eafdc3d0524  call 0x00007EAFDC2B77B0
00007eafdc3d0529  jmp 0x00007EAFDC3CF224
00007eafdc3d052e  call 0x00007EAFDC2B6550
00007eafdc3d0533  jmp 0x00007EAFDC3CF22E
00007eafdc3d0538  call 0x00007EAFDC2BFD50
00007eafdc3d053d  jmp 0x00007EAFDC3CF240
00007eafdc3d0542  call 0x00007EAFDC2B8EA0
00007eafdc3d0547  jmp 0x00007EAFDC3CF24A
00007eafdc3d054c  call 0x00007EAFDC2BFC30
00007eafdc3d0551  jmp 0x00007EAFDC3CF257
00007eafdc3d0556  call 0x00007EAFDC2B8D90
00007eafdc3d055b  jmp 0x00007EAFDC3CF264
00007eafdc3d0560  call 0x00007EAFDC2C2240
00007eafdc3d0565  jmp 0x00007EAFDC3CF271
00007eafdc3d056a  call 0x00007EAFDC2B5400
00007eafdc3d056f  jmp 0x00007EAFDC3CF27E
00007eafdc3d0574  call 0x00007EAFDC2B52F0
00007eafdc3d0579  jmp 0x00007EAFDC3CF28B
00007eafdc3d057e  call 0x00007EAFDC2C2120
00007eafdc3d0583  jmp 0x00007EAFDC3CF298
00007eafdc3d0588  call 0x00007EAFDC2B52F0
00007eafdc3d058d  jmp 0x00007EAFDC3CF2AB
00007eafdc3d0592  call 0x00007EAFDC2B52F0
00007eafdc3d0597  jmp 0x00007EAFDC3CF2BE
00007eafdc3d059c  call 0x00007EAFDC2B52F0
00007eafdc3d05a1  jmp 0x00007EAFDC3CF2D1
00007eafdc3d05a6  call 0x00007EAFDC2B52F0
00007eafdc3d05ab  jmp 0x00007EAFDC3CF2E4
00007eafdc3d05b0  call 0x00007EAFDC2C2240
00007eafdc3d05b5  jmp 0x00007EAFDC3CF2F9
00007eafdc3d05ba  call 0x00007EAFDC2C2240
00007eafdc3d05bf  jmp 0x00007EAFDC3CF30C
00007eafdc3d05c4  call 0x00007EAFDC2C2120
00007eafdc3d05c9  jmp 0x00007EAFDC3CF319
00007eafdc3d05ce  call 0x00007EAFDC2B52F0
00007eafdc3d05d3  jmp 0x00007EAFDC3CF32C
00007eafdc3d05d8  call 0x00007EAFDC2B52F0
00007eafdc3d05dd  jmp 0x00007EAFDC3CF34F
00007eafdc3d05e2  call 0x00007EAFDC2B52F0
00007eafdc3d05e7  jmp 0x00007EAFDC3CF362
00007eafdc3d05ec  call 0x00007EAFDC1FF540
00007eafdc3d05f1  jmp 0x00007EAFDC3CF380
00007eafdc3d05f6  call 0x00007EAFDC208C20
00007eafdc3d05fb  jmp 0x00007EAFDC3CF38A
00007eafdc3d0600  call 0x00007EAFDC2D6600
00007eafdc3d0605  jmp 0x00007EAFDC3CF396
00007eafdc3d060a  call 0x00007EAFDC1FF540
00007eafdc3d060f  jmp 0x00007EAFDC3CF3A6
00007eafdc3d0614  call 0x00007EAFDC2C0370
00007eafdc3d0619  jmp 0x00007EAFDC3CF3D4
00007eafdc3d061e  call 0x00007EAFDC2BF100
00007eafdc3d0623  jmp 0x00007EAFDC3CF3DD
00007eafdc3d0628  call 0x00007EAFDC2C0370
00007eafdc3d062d  jmp 0x00007EAFDC3CF43B
00007eafdc3d0632  call 0x00007EAFDC2BF100
00007eafdc3d0637  jmp 0x00007EAFDC3CF444
00007eafdc3d063c  call 0x00007EAFDC2C0370
00007eafdc3d0641  jmp 0x00007EAFDC3CF48B
00007eafdc3d0646  call 0x00007EAFDC2BF100
00007eafdc3d064b  jmp 0x00007EAFDC3CF494
00007eafdc3d0650  call 0x00007EAFDC20B720
00007eafdc3d0655  jmp 0x00007EAFDC3CF4D7
00007eafdc3d065a  call 0x00007EAFDC2B47C0
00007eafdc3d065f  jmp 0x00007EAFDC3CF4EA
00007eafdc3d0664  call 0x00007EAFDC208B00
00007eafdc3d0669  jmp 0x00007EAFDC3CF501
00007eafdc3d066e  call 0x00007EAFDC1FF430
00007eafdc3d0673  jmp 0x00007EAFDC3CF514
00007eafdc3d0678  call 0x00007EAFDC1FF430
00007eafdc3d067d  jmp 0x00007EAFDC3CF527
00007eafdc3d0682  sub rsp, 0x08
00007eafdc3d0686  push rax
00007eafdc3d0687  push rcx
00007eafdc3d0688  push rdx
00007eafdc3d0689  push rdi
00007eafdc3d068a  push rsi
00007eafdc3d068b  push r8
00007eafdc3d068d  push r9
00007eafdc3d068f  push r10
00007eafdc3d0691  push r11
00007eafdc3d0693  sub rsp, 0xF0
00007eafdc3d069a  vmovaps [rsp], xmm0
00007eafdc3d069f  vmovaps [rsp+0x10], xmm2
00007eafdc3d06a5  vmovaps [rsp+0x20], xmm3
00007eafdc3d06ab  vmovaps [rsp+0x30], xmm4
00007eafdc3d06b1  vmovaps [rsp+0x40], xmm5
00007eafdc3d06b7  vmovaps [rsp+0x50], xmm6
00007eafdc3d06bd  vmovaps [rsp+0x60], xmm7
00007eafdc3d06c3  vmovaps [rsp+0x70], xmm8
00007eafdc3d06c9  vmovaps [rsp+0x80], xmm9
00007eafdc3d06d2  vmovaps [rsp+0x90], xmm10
00007eafdc3d06db  vmovaps [rsp+0xA0], xmm11
00007eafdc3d06e4  vmovaps [rsp+0xB0], xmm12
00007eafdc3d06ed  vmovaps [rsp+0xC0], xmm13
00007eafdc3d06f6  vmovaps [rsp+0xD0], xmm14
00007eafdc3d06ff  vmovaps [rsp+0xE0], xmm15
00007eafdc3d0708  sub rsp, 0x30
00007eafdc3d070c  movaps [rsp], xmm1
00007eafdc3d0710  movaps [rsp+0x10], xmm15
00007eafdc3d0716  movaps [rsp+0x20], xmm14
00007eafdc3d071c  lea rdi, [rsp]
00007eafdc3d0720  mov esi, 0x00
00007eafdc3d0725  mov rax, 0x645891675530
00007eafdc3d072f  call rax
00007eafdc3d0731  movaps xmm1, [rsp]
00007eafdc3d0735  add rsp, 0x30
00007eafdc3d0739  vmovaps xmm0, [rsp]
00007eafdc3d073e  vmovaps xmm2, [rsp+0x10]
00007eafdc3d0744  vmovaps xmm3, [rsp+0x20]
00007eafdc3d074a  vmovaps xmm4, [rsp+0x30]
00007eafdc3d0750  vmovaps xmm5, [rsp+0x40]
00007eafdc3d0756  vmovaps xmm6, [rsp+0x50]
00007eafdc3d075c  vmovaps xmm7, [rsp+0x60]
00007eafdc3d0762  vmovaps xmm8, [rsp+0x70]
00007eafdc3d0768  vmovaps xmm9, [rsp+0x80]
00007eafdc3d0771  vmovaps xmm10, [rsp+0x90]
00007eafdc3d077a  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d0783  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d078c  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d0795  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d079e  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d07a7  add rsp, 0xF0
00007eafdc3d07ae  pop r11
00007eafdc3d07b0  pop r10
00007eafdc3d07b2  pop r9
00007eafdc3d07b4  pop r8
00007eafdc3d07b6  pop rsi
00007eafdc3d07b7  pop rdi
00007eafdc3d07b8  pop rdx
00007eafdc3d07b9  pop rcx
00007eafdc3d07ba  pop rax
00007eafdc3d07bb  add rsp, 0x08
00007eafdc3d07bf  jmp 0x00007EAFDC3CF581
00007eafdc3d07c4  sub rsp, 0x08
00007eafdc3d07c8  push rax
00007eafdc3d07c9  push rcx
00007eafdc3d07ca  push rdx
00007eafdc3d07cb  push rdi
00007eafdc3d07cc  push rsi
00007eafdc3d07cd  push r8
00007eafdc3d07cf  push r9
00007eafdc3d07d1  push r10
00007eafdc3d07d3  push r11
00007eafdc3d07d5  sub rsp, 0xF0
00007eafdc3d07dc  vmovaps [rsp], xmm0
00007eafdc3d07e1  vmovaps [rsp+0x10], xmm1
00007eafdc3d07e7  vmovaps [rsp+0x20], xmm2
00007eafdc3d07ed  vmovaps [rsp+0x30], xmm3
00007eafdc3d07f3  vmovaps [rsp+0x40], xmm4
00007eafdc3d07f9  vmovaps [rsp+0x50], xmm5
00007eafdc3d07ff  vmovaps [rsp+0x60], xmm6
00007eafdc3d0805  vmovaps [rsp+0x70], xmm7
00007eafdc3d080b  vmovaps [rsp+0x80], xmm8
00007eafdc3d0814  vmovaps [rsp+0x90], xmm9
00007eafdc3d081d  vmovaps [rsp+0xA0], xmm10
00007eafdc3d0826  vmovaps [rsp+0xB0], xmm11
00007eafdc3d082f  vmovaps [rsp+0xC0], xmm12
00007eafdc3d0838  vmovaps [rsp+0xD0], xmm14
00007eafdc3d0841  vmovaps [rsp+0xE0], xmm15
00007eafdc3d084a  sub rsp, 0x30
00007eafdc3d084e  movaps [rsp], xmm13
00007eafdc3d0853  movaps [rsp+0x10], xmm1
00007eafdc3d0858  movaps [rsp+0x20], xmm14
00007eafdc3d085e  lea rdi, [rsp]
00007eafdc3d0862  mov esi, 0x00
00007eafdc3d0867  mov rax, 0x645891675530
00007eafdc3d0871  call rax
00007eafdc3d0873  movaps xmm13, [rsp]
00007eafdc3d0878  add rsp, 0x30
00007eafdc3d087c  vmovaps xmm0, [rsp]
00007eafdc3d0881  vmovaps xmm1, [rsp+0x10]
00007eafdc3d0887  vmovaps xmm2, [rsp+0x20]
00007eafdc3d088d  vmovaps xmm3, [rsp+0x30]
00007eafdc3d0893  vmovaps xmm4, [rsp+0x40]
00007eafdc3d0899  vmovaps xmm5, [rsp+0x50]
00007eafdc3d089f  vmovaps xmm6, [rsp+0x60]
00007eafdc3d08a5  vmovaps xmm7, [rsp+0x70]
00007eafdc3d08ab  vmovaps xmm8, [rsp+0x80]
00007eafdc3d08b4  vmovaps xmm9, [rsp+0x90]
00007eafdc3d08bd  vmovaps xmm10, [rsp+0xA0]
00007eafdc3d08c6  vmovaps xmm11, [rsp+0xB0]
00007eafdc3d08cf  vmovaps xmm12, [rsp+0xC0]
00007eafdc3d08d8  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d08e1  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d08ea  add rsp, 0xF0
00007eafdc3d08f1  pop r11
00007eafdc3d08f3  pop r10
00007eafdc3d08f5  pop r9
00007eafdc3d08f7  pop r8
00007eafdc3d08f9  pop rsi
00007eafdc3d08fa  pop rdi
00007eafdc3d08fb  pop rdx
00007eafdc3d08fc  pop rcx
00007eafdc3d08fd  pop rax
00007eafdc3d08fe  add rsp, 0x08
00007eafdc3d0902  jmp 0x00007EAFDC3CF5CF
00007eafdc3d0907  sub rsp, 0x08
00007eafdc3d090b  push rax
00007eafdc3d090c  push rcx
00007eafdc3d090d  push rdx
00007eafdc3d090e  push rdi
00007eafdc3d090f  push rsi
00007eafdc3d0910  push r8
00007eafdc3d0912  push r9
00007eafdc3d0914  push r10
00007eafdc3d0916  push r11
00007eafdc3d0918  sub rsp, 0xF0
00007eafdc3d091f  vmovaps [rsp], xmm0
00007eafdc3d0924  vmovaps [rsp+0x10], xmm1
00007eafdc3d092a  vmovaps [rsp+0x20], xmm2
00007eafdc3d0930  vmovaps [rsp+0x30], xmm3
00007eafdc3d0936  vmovaps [rsp+0x40], xmm4
00007eafdc3d093c  vmovaps [rsp+0x50], xmm5
00007eafdc3d0942  vmovaps [rsp+0x60], xmm6
00007eafdc3d0948  vmovaps [rsp+0x70], xmm7
00007eafdc3d094e  vmovaps [rsp+0x80], xmm8
00007eafdc3d0957  vmovaps [rsp+0x90], xmm9
00007eafdc3d0960  vmovaps [rsp+0xA0], xmm10
00007eafdc3d0969  vmovaps [rsp+0xB0], xmm11
00007eafdc3d0972  vmovaps [rsp+0xC0], xmm12
00007eafdc3d097b  vmovaps [rsp+0xD0], xmm13
00007eafdc3d0984  vmovaps [rsp+0xE0], xmm14
00007eafdc3d098d  sub rsp, 0x30
00007eafdc3d0991  movaps [rsp], xmm15
00007eafdc3d0996  movaps [rsp+0x10], xmm14
00007eafdc3d099c  movaps [rsp+0x20], xmm1
00007eafdc3d09a1  lea rdi, [rsp]
00007eafdc3d09a5  mov esi, 0x00
00007eafdc3d09aa  mov rax, 0x645891675530
00007eafdc3d09b4  call rax
00007eafdc3d09b6  movaps xmm15, [rsp]
00007eafdc3d09bb  add rsp, 0x30
00007eafdc3d09bf  vmovaps xmm0, [rsp]
00007eafdc3d09c4  vmovaps xmm1, [rsp+0x10]
00007eafdc3d09ca  vmovaps xmm2, [rsp+0x20]
00007eafdc3d09d0  vmovaps xmm3, [rsp+0x30]
00007eafdc3d09d6  vmovaps xmm4, [rsp+0x40]
00007eafdc3d09dc  vmovaps xmm5, [rsp+0x50]
00007eafdc3d09e2  vmovaps xmm6, [rsp+0x60]
00007eafdc3d09e8  vmovaps xmm7, [rsp+0x70]
00007eafdc3d09ee  vmovaps xmm8, [rsp+0x80]
00007eafdc3d09f7  vmovaps xmm9, [rsp+0x90]
00007eafdc3d0a00  vmovaps xmm10, [rsp+0xA0]
00007eafdc3d0a09  vmovaps xmm11, [rsp+0xB0]
00007eafdc3d0a12  vmovaps xmm12, [rsp+0xC0]
00007eafdc3d0a1b  vmovaps xmm13, [rsp+0xD0]
00007eafdc3d0a24  vmovaps xmm14, [rsp+0xE0]
00007eafdc3d0a2d  add rsp, 0xF0
00007eafdc3d0a34  pop r11
00007eafdc3d0a36  pop r10
00007eafdc3d0a38  pop r9
00007eafdc3d0a3a  pop r8
00007eafdc3d0a3c  pop rsi
00007eafdc3d0a3d  pop rdi
00007eafdc3d0a3e  pop rdx
00007eafdc3d0a3f  pop rcx
00007eafdc3d0a40  pop rax
00007eafdc3d0a41  add rsp, 0x08
00007eafdc3d0a45  jmp 0x00007EAFDC3CF617
00007eafdc3d0a4a  sub rsp, 0x08
00007eafdc3d0a4e  push rax
00007eafdc3d0a4f  push rcx
00007eafdc3d0a50  push rdx
00007eafdc3d0a51  push rdi
00007eafdc3d0a52  push rsi
00007eafdc3d0a53  push r8
00007eafdc3d0a55  push r9
00007eafdc3d0a57  push r10
00007eafdc3d0a59  push r11
00007eafdc3d0a5b  sub rsp, 0xF0
00007eafdc3d0a62  vmovaps [rsp], xmm0
00007eafdc3d0a67  vmovaps [rsp+0x10], xmm2
00007eafdc3d0a6d  vmovaps [rsp+0x20], xmm3
00007eafdc3d0a73  vmovaps [rsp+0x30], xmm4
00007eafdc3d0a79  vmovaps [rsp+0x40], xmm5
00007eafdc3d0a7f  vmovaps [rsp+0x50], xmm6
00007eafdc3d0a85  vmovaps [rsp+0x60], xmm7
00007eafdc3d0a8b  vmovaps [rsp+0x70], xmm8
00007eafdc3d0a91  vmovaps [rsp+0x80], xmm9
00007eafdc3d0a9a  vmovaps [rsp+0x90], xmm10
00007eafdc3d0aa3  vmovaps [rsp+0xA0], xmm11
00007eafdc3d0aac  vmovaps [rsp+0xB0], xmm12
00007eafdc3d0ab5  vmovaps [rsp+0xC0], xmm13
00007eafdc3d0abe  vmovaps [rsp+0xD0], xmm14
00007eafdc3d0ac7  vmovaps [rsp+0xE0], xmm15
00007eafdc3d0ad0  sub rsp, 0x30
00007eafdc3d0ad4  movaps [rsp], xmm1
00007eafdc3d0ad8  movaps [rsp+0x10], xmm14
00007eafdc3d0ade  movaps [rsp+0x20], xmm10
00007eafdc3d0ae4  lea rdi, [rsp]
00007eafdc3d0ae8  mov esi, 0x00
00007eafdc3d0aed  mov rax, 0x645891675530
00007eafdc3d0af7  call rax
00007eafdc3d0af9  movaps xmm1, [rsp]
00007eafdc3d0afd  add rsp, 0x30
00007eafdc3d0b01  vmovaps xmm0, [rsp]
00007eafdc3d0b06  vmovaps xmm2, [rsp+0x10]
00007eafdc3d0b0c  vmovaps xmm3, [rsp+0x20]
00007eafdc3d0b12  vmovaps xmm4, [rsp+0x30]
00007eafdc3d0b18  vmovaps xmm5, [rsp+0x40]
00007eafdc3d0b1e  vmovaps xmm6, [rsp+0x50]
00007eafdc3d0b24  vmovaps xmm7, [rsp+0x60]
00007eafdc3d0b2a  vmovaps xmm8, [rsp+0x70]
00007eafdc3d0b30  vmovaps xmm9, [rsp+0x80]
00007eafdc3d0b39  vmovaps xmm10, [rsp+0x90]
00007eafdc3d0b42  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d0b4b  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d0b54  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d0b5d  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d0b66  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d0b6f  add rsp, 0xF0
00007eafdc3d0b76  pop r11
00007eafdc3d0b78  pop r10
00007eafdc3d0b7a  pop r9
00007eafdc3d0b7c  pop r8
00007eafdc3d0b7e  pop rsi
00007eafdc3d0b7f  pop rdi
00007eafdc3d0b80  pop rdx
00007eafdc3d0b81  pop rcx
00007eafdc3d0b82  pop rax
00007eafdc3d0b83  add rsp, 0x08
00007eafdc3d0b87  jmp 0x00007EAFDC3CF631
00007eafdc3d0b8c  sub rsp, 0x08
00007eafdc3d0b90  push rax
00007eafdc3d0b91  push rcx
00007eafdc3d0b92  push rdx
00007eafdc3d0b93  push rdi
00007eafdc3d0b94  push rsi
00007eafdc3d0b95  push r8
00007eafdc3d0b97  push r9
00007eafdc3d0b99  push r10
00007eafdc3d0b9b  push r11
00007eafdc3d0b9d  sub rsp, 0xF0
00007eafdc3d0ba4  vmovaps [rsp], xmm0
00007eafdc3d0ba9  vmovaps [rsp+0x10], xmm1
00007eafdc3d0baf  vmovaps [rsp+0x20], xmm2
00007eafdc3d0bb5  vmovaps [rsp+0x30], xmm3
00007eafdc3d0bbb  vmovaps [rsp+0x40], xmm4
00007eafdc3d0bc1  vmovaps [rsp+0x50], xmm5
00007eafdc3d0bc7  vmovaps [rsp+0x60], xmm6
00007eafdc3d0bcd  vmovaps [rsp+0x70], xmm7
00007eafdc3d0bd3  vmovaps [rsp+0x80], xmm8
00007eafdc3d0bdc  vmovaps [rsp+0x90], xmm9
00007eafdc3d0be5  vmovaps [rsp+0xA0], xmm10
00007eafdc3d0bee  vmovaps [rsp+0xB0], xmm11
00007eafdc3d0bf7  vmovaps [rsp+0xC0], xmm12
00007eafdc3d0c00  vmovaps [rsp+0xD0], xmm14
00007eafdc3d0c09  vmovaps [rsp+0xE0], xmm15
00007eafdc3d0c12  sub rsp, 0x30
00007eafdc3d0c16  movaps [rsp], xmm13
00007eafdc3d0c1b  movaps [rsp+0x10], xmm14
00007eafdc3d0c21  movaps [rsp+0x20], xmm2
00007eafdc3d0c26  lea rdi, [rsp]
00007eafdc3d0c2a  mov esi, 0x00
00007eafdc3d0c2f  mov rax, 0x645891675530
00007eafdc3d0c39  call rax
00007eafdc3d0c3b  movaps xmm13, [rsp]
00007eafdc3d0c40  add rsp, 0x30
00007eafdc3d0c44  vmovaps xmm0, [rsp]
00007eafdc3d0c49  vmovaps xmm1, [rsp+0x10]
00007eafdc3d0c4f  vmovaps xmm2, [rsp+0x20]
00007eafdc3d0c55  vmovaps xmm3, [rsp+0x30]
00007eafdc3d0c5b  vmovaps xmm4, [rsp+0x40]
00007eafdc3d0c61  vmovaps xmm5, [rsp+0x50]
00007eafdc3d0c67  vmovaps xmm6, [rsp+0x60]
00007eafdc3d0c6d  vmovaps xmm7, [rsp+0x70]
00007eafdc3d0c73  vmovaps xmm8, [rsp+0x80]
00007eafdc3d0c7c  vmovaps xmm9, [rsp+0x90]
00007eafdc3d0c85  vmovaps xmm10, [rsp+0xA0]
00007eafdc3d0c8e  vmovaps xmm11, [rsp+0xB0]
00007eafdc3d0c97  vmovaps xmm12, [rsp+0xC0]
00007eafdc3d0ca0  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d0ca9  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d0cb2  add rsp, 0xF0
00007eafdc3d0cb9  pop r11
00007eafdc3d0cbb  pop r10
00007eafdc3d0cbd  pop r9
00007eafdc3d0cbf  pop r8
00007eafdc3d0cc1  pop rsi
00007eafdc3d0cc2  pop rdi
00007eafdc3d0cc3  pop rdx
00007eafdc3d0cc4  pop rcx
00007eafdc3d0cc5  pop rax
00007eafdc3d0cc6  add rsp, 0x08
00007eafdc3d0cca  jmp 0x00007EAFDC3CF64C
00007eafdc3d0ccf  sub rsp, 0x08
00007eafdc3d0cd3  push rax
00007eafdc3d0cd4  push rcx
00007eafdc3d0cd5  push rdx
00007eafdc3d0cd6  push rdi
00007eafdc3d0cd7  push rsi
00007eafdc3d0cd8  push r8
00007eafdc3d0cda  push r9
00007eafdc3d0cdc  push r10
00007eafdc3d0cde  push r11
00007eafdc3d0ce0  sub rsp, 0xF0
00007eafdc3d0ce7  vmovaps [rsp], xmm0
00007eafdc3d0cec  vmovaps [rsp+0x10], xmm2
00007eafdc3d0cf2  vmovaps [rsp+0x20], xmm3
00007eafdc3d0cf8  vmovaps [rsp+0x30], xmm4
00007eafdc3d0cfe  vmovaps [rsp+0x40], xmm5
00007eafdc3d0d04  vmovaps [rsp+0x50], xmm6
00007eafdc3d0d0a  vmovaps [rsp+0x60], xmm7
00007eafdc3d0d10  vmovaps [rsp+0x70], xmm8
00007eafdc3d0d16  vmovaps [rsp+0x80], xmm9
00007eafdc3d0d1f  vmovaps [rsp+0x90], xmm10
00007eafdc3d0d28  vmovaps [rsp+0xA0], xmm11
00007eafdc3d0d31  vmovaps [rsp+0xB0], xmm12
00007eafdc3d0d3a  vmovaps [rsp+0xC0], xmm13
00007eafdc3d0d43  vmovaps [rsp+0xD0], xmm14
00007eafdc3d0d4c  vmovaps [rsp+0xE0], xmm15
00007eafdc3d0d55  sub rsp, 0x30
00007eafdc3d0d59  movaps [rsp], xmm1
00007eafdc3d0d5d  movaps [rsp+0x10], xmm10
00007eafdc3d0d63  movaps [rsp+0x20], xmm2
00007eafdc3d0d68  lea rdi, [rsp]
00007eafdc3d0d6c  mov esi, 0x00
00007eafdc3d0d71  mov rax, 0x645891675530
00007eafdc3d0d7b  call rax
00007eafdc3d0d7d  movaps xmm1, [rsp]
00007eafdc3d0d81  add rsp, 0x30
00007eafdc3d0d85  vmovaps xmm0, [rsp]
00007eafdc3d0d8a  vmovaps xmm2, [rsp+0x10]
00007eafdc3d0d90  vmovaps xmm3, [rsp+0x20]
00007eafdc3d0d96  vmovaps xmm4, [rsp+0x30]
00007eafdc3d0d9c  vmovaps xmm5, [rsp+0x40]
00007eafdc3d0da2  vmovaps xmm6, [rsp+0x50]
00007eafdc3d0da8  vmovaps xmm7, [rsp+0x60]
00007eafdc3d0dae  vmovaps xmm8, [rsp+0x70]
00007eafdc3d0db4  vmovaps xmm9, [rsp+0x80]
00007eafdc3d0dbd  vmovaps xmm10, [rsp+0x90]
00007eafdc3d0dc6  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d0dcf  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d0dd8  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d0de1  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d0dea  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d0df3  add rsp, 0xF0
00007eafdc3d0dfa  pop r11
00007eafdc3d0dfc  pop r10
00007eafdc3d0dfe  pop r9
00007eafdc3d0e00  pop r8
00007eafdc3d0e02  pop rsi
00007eafdc3d0e03  pop rdi
00007eafdc3d0e04  pop rdx
00007eafdc3d0e05  pop rcx
00007eafdc3d0e06  pop rax
00007eafdc3d0e07  add rsp, 0x08
00007eafdc3d0e0b  jmp 0x00007EAFDC3CF6B4
00007eafdc3d0e10  sub rsp, 0x08
00007eafdc3d0e14  push rax
00007eafdc3d0e15  push rcx
00007eafdc3d0e16  push rdx
00007eafdc3d0e17  push rdi
00007eafdc3d0e18  push rsi
00007eafdc3d0e19  push r8
00007eafdc3d0e1b  push r9
00007eafdc3d0e1d  push r10
00007eafdc3d0e1f  push r11
00007eafdc3d0e21  sub rsp, 0xF0
00007eafdc3d0e28  vmovaps [rsp], xmm0
00007eafdc3d0e2d  vmovaps [rsp+0x10], xmm1
00007eafdc3d0e33  vmovaps [rsp+0x20], xmm2
00007eafdc3d0e39  vmovaps [rsp+0x30], xmm3
00007eafdc3d0e3f  vmovaps [rsp+0x40], xmm4
00007eafdc3d0e45  vmovaps [rsp+0x50], xmm5
00007eafdc3d0e4b  vmovaps [rsp+0x60], xmm6
00007eafdc3d0e51  vmovaps [rsp+0x70], xmm7
00007eafdc3d0e57  vmovaps [rsp+0x80], xmm8
00007eafdc3d0e60  vmovaps [rsp+0x90], xmm9
00007eafdc3d0e69  vmovaps [rsp+0xA0], xmm10
00007eafdc3d0e72  vmovaps [rsp+0xB0], xmm11
00007eafdc3d0e7b  vmovaps [rsp+0xC0], xmm12
00007eafdc3d0e84  vmovaps [rsp+0xD0], xmm13
00007eafdc3d0e8d  vmovaps [rsp+0xE0], xmm14
00007eafdc3d0e96  sub rsp, 0x30
00007eafdc3d0e9a  movaps [rsp], xmm15
00007eafdc3d0e9f  movaps [rsp+0x10], xmm10
00007eafdc3d0ea5  movaps [rsp+0x20], xmm2
00007eafdc3d0eaa  lea rdi, [rsp]
00007eafdc3d0eae  mov esi, 0x00
00007eafdc3d0eb3  mov rax, 0x645891675530
00007eafdc3d0ebd  call rax
00007eafdc3d0ebf  movaps xmm15, [rsp]
00007eafdc3d0ec4  add rsp, 0x30
00007eafdc3d0ec8  vmovaps xmm0, [rsp]
00007eafdc3d0ecd  vmovaps xmm1, [rsp+0x10]
00007eafdc3d0ed3  vmovaps xmm2, [rsp+0x20]
00007eafdc3d0ed9  vmovaps xmm3, [rsp+0x30]
00007eafdc3d0edf  vmovaps xmm4, [rsp+0x40]
00007eafdc3d0ee5  vmovaps xmm5, [rsp+0x50]
00007eafdc3d0eeb  vmovaps xmm6, [rsp+0x60]
00007eafdc3d0ef1  vmovaps xmm7, [rsp+0x70]
00007eafdc3d0ef7  vmovaps xmm8, [rsp+0x80]
00007eafdc3d0f00  vmovaps xmm9, [rsp+0x90]
00007eafdc3d0f09  vmovaps xmm10, [rsp+0xA0]
00007eafdc3d0f12  vmovaps xmm11, [rsp+0xB0]
00007eafdc3d0f1b  vmovaps xmm12, [rsp+0xC0]
00007eafdc3d0f24  vmovaps xmm13, [rsp+0xD0]
00007eafdc3d0f2d  vmovaps xmm14, [rsp+0xE0]
00007eafdc3d0f36  add rsp, 0xF0
00007eafdc3d0f3d  pop r11
00007eafdc3d0f3f  pop r10
00007eafdc3d0f41  pop r9
00007eafdc3d0f43  pop r8
00007eafdc3d0f45  pop rsi
00007eafdc3d0f46  pop rdi
00007eafdc3d0f47  pop rdx
00007eafdc3d0f48  pop rcx
00007eafdc3d0f49  pop rax
00007eafdc3d0f4a  add rsp, 0x08
00007eafdc3d0f4e  jmp 0x00007EAFDC3CF706
00007eafdc3d0f53  sub rsp, 0x08
00007eafdc3d0f57  push rax
00007eafdc3d0f58  push rcx
00007eafdc3d0f59  push rdx
00007eafdc3d0f5a  push rdi
00007eafdc3d0f5b  push rsi
00007eafdc3d0f5c  push r8
00007eafdc3d0f5e  push r9
00007eafdc3d0f60  push r10
00007eafdc3d0f62  push r11
00007eafdc3d0f64  sub rsp, 0xF0
00007eafdc3d0f6b  vmovaps [rsp], xmm0
00007eafdc3d0f70  vmovaps [rsp+0x10], xmm2
00007eafdc3d0f76  vmovaps [rsp+0x20], xmm3
00007eafdc3d0f7c  vmovaps [rsp+0x30], xmm4
00007eafdc3d0f82  vmovaps [rsp+0x40], xmm5
00007eafdc3d0f88  vmovaps [rsp+0x50], xmm6
00007eafdc3d0f8e  vmovaps [rsp+0x60], xmm7
00007eafdc3d0f94  vmovaps [rsp+0x70], xmm8
00007eafdc3d0f9a  vmovaps [rsp+0x80], xmm9
00007eafdc3d0fa3  vmovaps [rsp+0x90], xmm10
00007eafdc3d0fac  vmovaps [rsp+0xA0], xmm11
00007eafdc3d0fb5  vmovaps [rsp+0xB0], xmm12
00007eafdc3d0fbe  vmovaps [rsp+0xC0], xmm13
00007eafdc3d0fc7  vmovaps [rsp+0xD0], xmm14
00007eafdc3d0fd0  vmovaps [rsp+0xE0], xmm15
00007eafdc3d0fd9  sub rsp, 0x30
00007eafdc3d0fdd  movaps [rsp], xmm1
00007eafdc3d0fe1  movaps [rsp+0x10], xmm10
00007eafdc3d0fe7  movaps [rsp+0x20], xmm12
00007eafdc3d0fed  lea rdi, [rsp]
00007eafdc3d0ff1  mov esi, 0x00
00007eafdc3d0ff6  mov rax, 0x645891675530
00007eafdc3d1000  call rax
00007eafdc3d1002  movaps xmm1, [rsp]
00007eafdc3d1006  add rsp, 0x30
00007eafdc3d100a  vmovaps xmm0, [rsp]
00007eafdc3d100f  vmovaps xmm2, [rsp+0x10]
00007eafdc3d1015  vmovaps xmm3, [rsp+0x20]
00007eafdc3d101b  vmovaps xmm4, [rsp+0x30]
00007eafdc3d1021  vmovaps xmm5, [rsp+0x40]
00007eafdc3d1027  vmovaps xmm6, [rsp+0x50]
00007eafdc3d102d  vmovaps xmm7, [rsp+0x60]
00007eafdc3d1033  vmovaps xmm8, [rsp+0x70]
00007eafdc3d1039  vmovaps xmm9, [rsp+0x80]
00007eafdc3d1042  vmovaps xmm10, [rsp+0x90]
00007eafdc3d104b  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d1054  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d105d  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d1066  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d106f  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d1078  add rsp, 0xF0
00007eafdc3d107f  pop r11
00007eafdc3d1081  pop r10
00007eafdc3d1083  pop r9
00007eafdc3d1085  pop r8
00007eafdc3d1087  pop rsi
00007eafdc3d1088  pop rdi
00007eafdc3d1089  pop rdx
00007eafdc3d108a  pop rcx
00007eafdc3d108b  pop rax
00007eafdc3d108c  add rsp, 0x08
00007eafdc3d1090  jmp 0x00007EAFDC3CF732
00007eafdc3d1095  sub rsp, 0x08
00007eafdc3d1099  push rax
00007eafdc3d109a  push rcx
00007eafdc3d109b  push rdx
00007eafdc3d109c  push rdi
00007eafdc3d109d  push rsi
00007eafdc3d109e  push r8
00007eafdc3d10a0  push r9
00007eafdc3d10a2  push r10
00007eafdc3d10a4  push r11
00007eafdc3d10a6  sub rsp, 0xF0
00007eafdc3d10ad  vmovaps [rsp], xmm0
00007eafdc3d10b2  vmovaps [rsp+0x10], xmm1
00007eafdc3d10b8  vmovaps [rsp+0x20], xmm2
00007eafdc3d10be  vmovaps [rsp+0x30], xmm3
00007eafdc3d10c4  vmovaps [rsp+0x40], xmm4
00007eafdc3d10ca  vmovaps [rsp+0x50], xmm5
00007eafdc3d10d0  vmovaps [rsp+0x60], xmm6
00007eafdc3d10d6  vmovaps [rsp+0x70], xmm7
00007eafdc3d10dc  vmovaps [rsp+0x80], xmm8
00007eafdc3d10e5  vmovaps [rsp+0x90], xmm9
00007eafdc3d10ee  vmovaps [rsp+0xA0], xmm10
00007eafdc3d10f7  vmovaps [rsp+0xB0], xmm11
00007eafdc3d1100  vmovaps [rsp+0xC0], xmm12
00007eafdc3d1109  vmovaps [rsp+0xD0], xmm13
00007eafdc3d1112  vmovaps [rsp+0xE0], xmm14
00007eafdc3d111b  sub rsp, 0x30
00007eafdc3d111f  movaps [rsp], xmm15
00007eafdc3d1124  movaps [rsp+0x10], xmm10
00007eafdc3d112a  movaps [rsp+0x20], xmm12
00007eafdc3d1130  lea rdi, [rsp]
00007eafdc3d1134  mov esi, 0x00
00007eafdc3d1139  mov rax, 0x645891675530
00007eafdc3d1143  call rax
00007eafdc3d1145  movaps xmm15, [rsp]
00007eafdc3d114a  add rsp, 0x30
00007eafdc3d114e  vmovaps xmm0, [rsp]
00007eafdc3d1153  vmovaps xmm1, [rsp+0x10]
00007eafdc3d1159  vmovaps xmm2, [rsp+0x20]
00007eafdc3d115f  vmovaps xmm3, [rsp+0x30]
00007eafdc3d1165  vmovaps xmm4, [rsp+0x40]
00007eafdc3d116b  vmovaps xmm5, [rsp+0x50]
00007eafdc3d1171  vmovaps xmm6, [rsp+0x60]
00007eafdc3d1177  vmovaps xmm7, [rsp+0x70]
00007eafdc3d117d  vmovaps xmm8, [rsp+0x80]
00007eafdc3d1186  vmovaps xmm9, [rsp+0x90]
00007eafdc3d118f  vmovaps xmm10, [rsp+0xA0]
00007eafdc3d1198  vmovaps xmm11, [rsp+0xB0]
00007eafdc3d11a1  vmovaps xmm12, [rsp+0xC0]
00007eafdc3d11aa  vmovaps xmm13, [rsp+0xD0]
00007eafdc3d11b3  vmovaps xmm14, [rsp+0xE0]
00007eafdc3d11bc  add rsp, 0xF0
00007eafdc3d11c3  pop r11
00007eafdc3d11c5  pop r10
00007eafdc3d11c7  pop r9
00007eafdc3d11c9  pop r8
00007eafdc3d11cb  pop rsi
00007eafdc3d11cc  pop rdi
00007eafdc3d11cd  pop rdx
00007eafdc3d11ce  pop rcx
00007eafdc3d11cf  pop rax
00007eafdc3d11d0  add rsp, 0x08
00007eafdc3d11d4  jmp 0x00007EAFDC3CF75E
00007eafdc3d11d9  call 0x00007EAFDC1FF430
00007eafdc3d11de  jmp 0x00007EAFDC3CF7EE
00007eafdc3d11e3  call 0x00007EAFDC1FF430
00007eafdc3d11e8  jmp 0x00007EAFDC3CF801
00007eafdc3d11ed  sub rsp, 0x08
00007eafdc3d11f1  push rax
00007eafdc3d11f2  push rcx
00007eafdc3d11f3  push rdx
00007eafdc3d11f4  push rdi
00007eafdc3d11f5  push rsi
00007eafdc3d11f6  push r8
00007eafdc3d11f8  push r9
00007eafdc3d11fa  push r10
00007eafdc3d11fc  push r11
00007eafdc3d11fe  sub rsp, 0xF0
00007eafdc3d1205  vmovaps [rsp], xmm0
00007eafdc3d120a  vmovaps [rsp+0x10], xmm2
00007eafdc3d1210  vmovaps [rsp+0x20], xmm3
00007eafdc3d1216  vmovaps [rsp+0x30], xmm4
00007eafdc3d121c  vmovaps [rsp+0x40], xmm5
00007eafdc3d1222  vmovaps [rsp+0x50], xmm6
00007eafdc3d1228  vmovaps [rsp+0x60], xmm7
00007eafdc3d122e  vmovaps [rsp+0x70], xmm8
00007eafdc3d1234  vmovaps [rsp+0x80], xmm9
00007eafdc3d123d  vmovaps [rsp+0x90], xmm10
00007eafdc3d1246  vmovaps [rsp+0xA0], xmm11
00007eafdc3d124f  vmovaps [rsp+0xB0], xmm12
00007eafdc3d1258  vmovaps [rsp+0xC0], xmm13
00007eafdc3d1261  vmovaps [rsp+0xD0], xmm14
00007eafdc3d126a  vmovaps [rsp+0xE0], xmm15
00007eafdc3d1273  sub rsp, 0x30
00007eafdc3d1277  movaps [rsp], xmm1
00007eafdc3d127b  movaps [rsp+0x10], xmm13
00007eafdc3d1281  movaps [rsp+0x20], xmm2
00007eafdc3d1286  lea rdi, [rsp]
00007eafdc3d128a  mov esi, 0x00
00007eafdc3d128f  mov rax, 0x645891675530
00007eafdc3d1299  call rax
00007eafdc3d129b  movaps xmm1, [rsp]
00007eafdc3d129f  add rsp, 0x30
00007eafdc3d12a3  vmovaps xmm0, [rsp]
00007eafdc3d12a8  vmovaps xmm2, [rsp+0x10]
00007eafdc3d12ae  vmovaps xmm3, [rsp+0x20]
00007eafdc3d12b4  vmovaps xmm4, [rsp+0x30]
00007eafdc3d12ba  vmovaps xmm5, [rsp+0x40]
00007eafdc3d12c0  vmovaps xmm6, [rsp+0x50]
00007eafdc3d12c6  vmovaps xmm7, [rsp+0x60]
00007eafdc3d12cc  vmovaps xmm8, [rsp+0x70]
00007eafdc3d12d2  vmovaps xmm9, [rsp+0x80]
00007eafdc3d12db  vmovaps xmm10, [rsp+0x90]
00007eafdc3d12e4  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d12ed  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d12f6  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d12ff  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d1308  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d1311  add rsp, 0xF0
00007eafdc3d1318  pop r11
00007eafdc3d131a  pop r10
00007eafdc3d131c  pop r9
00007eafdc3d131e  pop r8
00007eafdc3d1320  pop rsi
00007eafdc3d1321  pop rdi
00007eafdc3d1322  pop rdx
00007eafdc3d1323  pop rcx
00007eafdc3d1324  pop rax
00007eafdc3d1325  add rsp, 0x08
00007eafdc3d1329  jmp 0x00007EAFDC3CF82C
00007eafdc3d132e  call 0x00007EAFDC20E760
00007eafdc3d1333  jmp 0x00007EAFDC3CF839
00007eafdc3d1338  sub rsp, 0x08
00007eafdc3d133c  push rax
00007eafdc3d133d  push rcx
00007eafdc3d133e  push rdx
00007eafdc3d133f  push rdi
00007eafdc3d1340  push rsi
00007eafdc3d1341  push r8
00007eafdc3d1343  push r9
00007eafdc3d1345  push r10
00007eafdc3d1347  push r11
00007eafdc3d1349  sub rsp, 0xF0
00007eafdc3d1350  vmovaps [rsp], xmm0
00007eafdc3d1355  vmovaps [rsp+0x10], xmm1
00007eafdc3d135b  vmovaps [rsp+0x20], xmm2
00007eafdc3d1361  vmovaps [rsp+0x30], xmm3
00007eafdc3d1367  vmovaps [rsp+0x40], xmm4
00007eafdc3d136d  vmovaps [rsp+0x50], xmm5
00007eafdc3d1373  vmovaps [rsp+0x60], xmm6
00007eafdc3d1379  vmovaps [rsp+0x70], xmm7
00007eafdc3d137f  vmovaps [rsp+0x80], xmm8
00007eafdc3d1388  vmovaps [rsp+0x90], xmm9
00007eafdc3d1391  vmovaps [rsp+0xA0], xmm10
00007eafdc3d139a  vmovaps [rsp+0xB0], xmm11
00007eafdc3d13a3  vmovaps [rsp+0xC0], xmm12
00007eafdc3d13ac  vmovaps [rsp+0xD0], xmm14
00007eafdc3d13b5  vmovaps [rsp+0xE0], xmm15
00007eafdc3d13be  sub rsp, 0x30
00007eafdc3d13c2  movaps [rsp], xmm13
00007eafdc3d13c7  movaps [rsp+0x10], xmm2
00007eafdc3d13cc  movaps [rsp+0x20], xmm1
00007eafdc3d13d1  lea rdi, [rsp]
00007eafdc3d13d5  mov esi, 0x00
00007eafdc3d13da  mov rax, 0x645891675530
00007eafdc3d13e4  call rax
00007eafdc3d13e6  movaps xmm13, [rsp]
00007eafdc3d13eb  add rsp, 0x30
00007eafdc3d13ef  vmovaps xmm0, [rsp]
00007eafdc3d13f4  vmovaps xmm1, [rsp+0x10]
00007eafdc3d13fa  vmovaps xmm2, [rsp+0x20]
00007eafdc3d1400  vmovaps xmm3, [rsp+0x30]
00007eafdc3d1406  vmovaps xmm4, [rsp+0x40]
00007eafdc3d140c  vmovaps xmm5, [rsp+0x50]
00007eafdc3d1412  vmovaps xmm6, [rsp+0x60]
00007eafdc3d1418  vmovaps xmm7, [rsp+0x70]
00007eafdc3d141e  vmovaps xmm8, [rsp+0x80]
00007eafdc3d1427  vmovaps xmm9, [rsp+0x90]
00007eafdc3d1430  vmovaps xmm10, [rsp+0xA0]
00007eafdc3d1439  vmovaps xmm11, [rsp+0xB0]
00007eafdc3d1442  vmovaps xmm12, [rsp+0xC0]
00007eafdc3d144b  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d1454  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d145d  add rsp, 0xF0
00007eafdc3d1464  pop r11
00007eafdc3d1466  pop r10
00007eafdc3d1468  pop r9
00007eafdc3d146a  pop r8
00007eafdc3d146c  pop rsi
00007eafdc3d146d  pop rdi
00007eafdc3d146e  pop rdx
00007eafdc3d146f  pop rcx
00007eafdc3d1470  pop rax
00007eafdc3d1471  add rsp, 0x08
00007eafdc3d1475  jmp 0x00007EAFDC3CF878
00007eafdc3d147a  sub rsp, 0x08
00007eafdc3d147e  push rax
00007eafdc3d147f  push rcx
00007eafdc3d1480  push rdx
00007eafdc3d1481  push rdi
00007eafdc3d1482  push rsi
00007eafdc3d1483  push r8
00007eafdc3d1485  push r9
00007eafdc3d1487  push r10
00007eafdc3d1489  push r11
00007eafdc3d148b  sub rsp, 0xF0
00007eafdc3d1492  vmovaps [rsp], xmm0
00007eafdc3d1497  vmovaps [rsp+0x10], xmm2
00007eafdc3d149d  vmovaps [rsp+0x20], xmm3
00007eafdc3d14a3  vmovaps [rsp+0x30], xmm4
00007eafdc3d14a9  vmovaps [rsp+0x40], xmm5
00007eafdc3d14af  vmovaps [rsp+0x50], xmm6
00007eafdc3d14b5  vmovaps [rsp+0x60], xmm7
00007eafdc3d14bb  vmovaps [rsp+0x70], xmm8
00007eafdc3d14c1  vmovaps [rsp+0x80], xmm9
00007eafdc3d14ca  vmovaps [rsp+0x90], xmm10
00007eafdc3d14d3  vmovaps [rsp+0xA0], xmm11
00007eafdc3d14dc  vmovaps [rsp+0xB0], xmm12
00007eafdc3d14e5  vmovaps [rsp+0xC0], xmm13
00007eafdc3d14ee  vmovaps [rsp+0xD0], xmm14
00007eafdc3d14f7  vmovaps [rsp+0xE0], xmm15
00007eafdc3d1500  sub rsp, 0x30
00007eafdc3d1504  movaps [rsp], xmm1
00007eafdc3d1508  movaps [rsp+0x10], xmm15
00007eafdc3d150e  movaps [rsp+0x20], xmm2
00007eafdc3d1513  lea rdi, [rsp]
00007eafdc3d1517  mov esi, 0x00
00007eafdc3d151c  mov rax, 0x645891675530
00007eafdc3d1526  call rax
00007eafdc3d1528  movaps xmm1, [rsp]
00007eafdc3d152c  add rsp, 0x30
00007eafdc3d1530  vmovaps xmm0, [rsp]
00007eafdc3d1535  vmovaps xmm2, [rsp+0x10]
00007eafdc3d153b  vmovaps xmm3, [rsp+0x20]
00007eafdc3d1541  vmovaps xmm4, [rsp+0x30]
00007eafdc3d1547  vmovaps xmm5, [rsp+0x40]
00007eafdc3d154d  vmovaps xmm6, [rsp+0x50]
00007eafdc3d1553  vmovaps xmm7, [rsp+0x60]
00007eafdc3d1559  vmovaps xmm8, [rsp+0x70]
00007eafdc3d155f  vmovaps xmm9, [rsp+0x80]
00007eafdc3d1568  vmovaps xmm10, [rsp+0x90]
00007eafdc3d1571  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d157a  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d1583  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d158c  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d1595  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d159e  add rsp, 0xF0
00007eafdc3d15a5  pop r11
00007eafdc3d15a7  pop r10
00007eafdc3d15a9  pop r9
00007eafdc3d15ab  pop r8
00007eafdc3d15ad  pop rsi
00007eafdc3d15ae  pop rdi
00007eafdc3d15af  pop rdx
00007eafdc3d15b0  pop rcx
00007eafdc3d15b1  pop rax
00007eafdc3d15b2  add rsp, 0x08
00007eafdc3d15b6  jmp 0x00007EAFDC3CF8AC
00007eafdc3d15bb  sub rsp, 0x08
00007eafdc3d15bf  push rax
00007eafdc3d15c0  push rcx
00007eafdc3d15c1  push rdx
00007eafdc3d15c2  push rdi
00007eafdc3d15c3  push rsi
00007eafdc3d15c4  push r8
00007eafdc3d15c6  push r9
00007eafdc3d15c8  push r10
00007eafdc3d15ca  push r11
00007eafdc3d15cc  sub rsp, 0xF0
00007eafdc3d15d3  vmovaps [rsp], xmm0
00007eafdc3d15d8  vmovaps [rsp+0x10], xmm1
00007eafdc3d15de  vmovaps [rsp+0x20], xmm2
00007eafdc3d15e4  vmovaps [rsp+0x30], xmm3
00007eafdc3d15ea  vmovaps [rsp+0x40], xmm4
00007eafdc3d15f0  vmovaps [rsp+0x50], xmm5
00007eafdc3d15f6  vmovaps [rsp+0x60], xmm6
00007eafdc3d15fc  vmovaps [rsp+0x70], xmm7
00007eafdc3d1602  vmovaps [rsp+0x80], xmm8
00007eafdc3d160b  vmovaps [rsp+0x90], xmm9
00007eafdc3d1614  vmovaps [rsp+0xA0], xmm10
00007eafdc3d161d  vmovaps [rsp+0xB0], xmm11
00007eafdc3d1626  vmovaps [rsp+0xC0], xmm12
00007eafdc3d162f  vmovaps [rsp+0xD0], xmm13
00007eafdc3d1638  vmovaps [rsp+0xE0], xmm15
00007eafdc3d1641  sub rsp, 0x30
00007eafdc3d1645  movaps [rsp], xmm14
00007eafdc3d164a  movaps [rsp+0x10], xmm2
00007eafdc3d164f  movaps [rsp+0x20], xmm15
00007eafdc3d1655  lea rdi, [rsp]
00007eafdc3d1659  mov esi, 0x00
00007eafdc3d165e  mov rax, 0x645891675530
00007eafdc3d1668  call rax
00007eafdc3d166a  movaps xmm14, [rsp]
00007eafdc3d166f  add rsp, 0x30
00007eafdc3d1673  vmovaps xmm0, [rsp]
00007eafdc3d1678  vmovaps xmm1, [rsp+0x10]
00007eafdc3d167e  vmovaps xmm2, [rsp+0x20]
00007eafdc3d1684  vmovaps xmm3, [rsp+0x30]
00007eafdc3d168a  vmovaps xmm4, [rsp+0x40]
00007eafdc3d1690  vmovaps xmm5, [rsp+0x50]
00007eafdc3d1696  vmovaps xmm6, [rsp+0x60]
00007eafdc3d169c  vmovaps xmm7, [rsp+0x70]
00007eafdc3d16a2  vmovaps xmm8, [rsp+0x80]
00007eafdc3d16ab  vmovaps xmm9, [rsp+0x90]
00007eafdc3d16b4  vmovaps xmm10, [rsp+0xA0]
00007eafdc3d16bd  vmovaps xmm11, [rsp+0xB0]
00007eafdc3d16c6  vmovaps xmm12, [rsp+0xC0]
00007eafdc3d16cf  vmovaps xmm13, [rsp+0xD0]
00007eafdc3d16d8  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d16e1  add rsp, 0xF0
00007eafdc3d16e8  pop r11
00007eafdc3d16ea  pop r10
00007eafdc3d16ec  pop r9
00007eafdc3d16ee  pop r8
00007eafdc3d16f0  pop rsi
00007eafdc3d16f1  pop rdi
00007eafdc3d16f2  pop rdx
00007eafdc3d16f3  pop rcx
00007eafdc3d16f4  pop rax
00007eafdc3d16f5  add rsp, 0x08
00007eafdc3d16f9  jmp 0x00007EAFDC3CF8E7
00007eafdc3d16fe  sub rsp, 0x08
00007eafdc3d1702  push rax
00007eafdc3d1703  push rcx
00007eafdc3d1704  push rdx
00007eafdc3d1705  push rdi
00007eafdc3d1706  push rsi
00007eafdc3d1707  push r8
00007eafdc3d1709  push r9
00007eafdc3d170b  push r10
00007eafdc3d170d  push r11
00007eafdc3d170f  sub rsp, 0xF0
00007eafdc3d1716  vmovaps [rsp], xmm0
00007eafdc3d171b  vmovaps [rsp+0x10], xmm1
00007eafdc3d1721  vmovaps [rsp+0x20], xmm2
00007eafdc3d1727  vmovaps [rsp+0x30], xmm3
00007eafdc3d172d  vmovaps [rsp+0x40], xmm4
00007eafdc3d1733  vmovaps [rsp+0x50], xmm5
00007eafdc3d1739  vmovaps [rsp+0x60], xmm6
00007eafdc3d173f  vmovaps [rsp+0x70], xmm7
00007eafdc3d1745  vmovaps [rsp+0x80], xmm8
00007eafdc3d174e  vmovaps [rsp+0x90], xmm9
00007eafdc3d1757  vmovaps [rsp+0xA0], xmm10
00007eafdc3d1760  vmovaps [rsp+0xB0], xmm11
00007eafdc3d1769  vmovaps [rsp+0xC0], xmm12
00007eafdc3d1772  vmovaps [rsp+0xD0], xmm13
00007eafdc3d177b  vmovaps [rsp+0xE0], xmm14
00007eafdc3d1784  sub rsp, 0x30
00007eafdc3d1788  movaps [rsp], xmm15
00007eafdc3d178d  movaps [rsp+0x10], xmm2
00007eafdc3d1792  movaps [rsp+0x20], xmm1
00007eafdc3d1797  lea rdi, [rsp]
00007eafdc3d179b  mov esi, 0x00
00007eafdc3d17a0  mov rax, 0x645891675530
00007eafdc3d17aa  call rax
00007eafdc3d17ac  movaps xmm15, [rsp]
00007eafdc3d17b1  add rsp, 0x30
00007eafdc3d17b5  vmovaps xmm0, [rsp]
00007eafdc3d17ba  vmovaps xmm1, [rsp+0x10]
00007eafdc3d17c0  vmovaps xmm2, [rsp+0x20]
00007eafdc3d17c6  vmovaps xmm3, [rsp+0x30]
00007eafdc3d17cc  vmovaps xmm4, [rsp+0x40]
00007eafdc3d17d2  vmovaps xmm5, [rsp+0x50]
00007eafdc3d17d8  vmovaps xmm6, [rsp+0x60]
00007eafdc3d17de  vmovaps xmm7, [rsp+0x70]
00007eafdc3d17e4  vmovaps xmm8, [rsp+0x80]
00007eafdc3d17ed  vmovaps xmm9, [rsp+0x90]
00007eafdc3d17f6  vmovaps xmm10, [rsp+0xA0]
00007eafdc3d17ff  vmovaps xmm11, [rsp+0xB0]
00007eafdc3d1808  vmovaps xmm12, [rsp+0xC0]
00007eafdc3d1811  vmovaps xmm13, [rsp+0xD0]
00007eafdc3d181a  vmovaps xmm14, [rsp+0xE0]
00007eafdc3d1823  add rsp, 0xF0
00007eafdc3d182a  pop r11
00007eafdc3d182c  pop r10
00007eafdc3d182e  pop r9
00007eafdc3d1830  pop r8
00007eafdc3d1832  pop rsi
00007eafdc3d1833  pop rdi
00007eafdc3d1834  pop rdx
00007eafdc3d1835  pop rcx
00007eafdc3d1836  pop rax
00007eafdc3d1837  add rsp, 0x08
00007eafdc3d183b  jmp 0x00007EAFDC3CF923
00007eafdc3d1840  call 0x00007EAFDC1FF430
00007eafdc3d1845  jmp 0x00007EAFDC3CF930
00007eafdc3d184a  sub rsp, 0x08
00007eafdc3d184e  push rax
00007eafdc3d184f  push rcx
00007eafdc3d1850  push rdx
00007eafdc3d1851  push rdi
00007eafdc3d1852  push rsi
00007eafdc3d1853  push r8
00007eafdc3d1855  push r9
00007eafdc3d1857  push r10
00007eafdc3d1859  push r11
00007eafdc3d185b  sub rsp, 0xF0
00007eafdc3d1862  vmovaps [rsp], xmm0
00007eafdc3d1867  vmovaps [rsp+0x10], xmm1
00007eafdc3d186d  vmovaps [rsp+0x20], xmm3
00007eafdc3d1873  vmovaps [rsp+0x30], xmm4
00007eafdc3d1879  vmovaps [rsp+0x40], xmm5
00007eafdc3d187f  vmovaps [rsp+0x50], xmm6
00007eafdc3d1885  vmovaps [rsp+0x60], xmm7
00007eafdc3d188b  vmovaps [rsp+0x70], xmm8
00007eafdc3d1891  vmovaps [rsp+0x80], xmm9
00007eafdc3d189a  vmovaps [rsp+0x90], xmm10
00007eafdc3d18a3  vmovaps [rsp+0xA0], xmm11
00007eafdc3d18ac  vmovaps [rsp+0xB0], xmm12
00007eafdc3d18b5  vmovaps [rsp+0xC0], xmm13
00007eafdc3d18be  vmovaps [rsp+0xD0], xmm14
00007eafdc3d18c7  vmovaps [rsp+0xE0], xmm15
00007eafdc3d18d0  sub rsp, 0x30
00007eafdc3d18d4  movaps [rsp], xmm2
00007eafdc3d18d8  movaps [rsp+0x10], xmm1
00007eafdc3d18dd  movaps [rsp+0x20], xmm14
00007eafdc3d18e3  lea rdi, [rsp]
00007eafdc3d18e7  mov esi, 0x00
00007eafdc3d18ec  mov rax, 0x645891675530
00007eafdc3d18f6  call rax
00007eafdc3d18f8  movaps xmm2, [rsp]
00007eafdc3d18fc  add rsp, 0x30
00007eafdc3d1900  vmovaps xmm0, [rsp]
00007eafdc3d1905  vmovaps xmm1, [rsp+0x10]
00007eafdc3d190b  vmovaps xmm3, [rsp+0x20]
00007eafdc3d1911  vmovaps xmm4, [rsp+0x30]
00007eafdc3d1917  vmovaps xmm5, [rsp+0x40]
00007eafdc3d191d  vmovaps xmm6, [rsp+0x50]
00007eafdc3d1923  vmovaps xmm7, [rsp+0x60]
00007eafdc3d1929  vmovaps xmm8, [rsp+0x70]
00007eafdc3d192f  vmovaps xmm9, [rsp+0x80]
00007eafdc3d1938  vmovaps xmm10, [rsp+0x90]
00007eafdc3d1941  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d194a  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d1953  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d195c  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d1965  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d196e  add rsp, 0xF0
00007eafdc3d1975  pop r11
00007eafdc3d1977  pop r10
00007eafdc3d1979  pop r9
00007eafdc3d197b  pop r8
00007eafdc3d197d  pop rsi
00007eafdc3d197e  pop rdi
00007eafdc3d197f  pop rdx
00007eafdc3d1980  pop rcx
00007eafdc3d1981  pop rax
00007eafdc3d1982  add rsp, 0x08
00007eafdc3d1986  jmp 0x00007EAFDC3CF96D
00007eafdc3d198b  sub rsp, 0x08
00007eafdc3d198f  push rax
00007eafdc3d1990  push rcx
00007eafdc3d1991  push rdx
00007eafdc3d1992  push rdi
00007eafdc3d1993  push rsi
00007eafdc3d1994  push r8
00007eafdc3d1996  push r9
00007eafdc3d1998  push r10
00007eafdc3d199a  push r11
00007eafdc3d199c  sub rsp, 0xF0
00007eafdc3d19a3  vmovaps [rsp], xmm0
00007eafdc3d19a8  vmovaps [rsp+0x10], xmm1
00007eafdc3d19ae  vmovaps [rsp+0x20], xmm2
00007eafdc3d19b4  vmovaps [rsp+0x30], xmm3
00007eafdc3d19ba  vmovaps [rsp+0x40], xmm4
00007eafdc3d19c0  vmovaps [rsp+0x50], xmm5
00007eafdc3d19c6  vmovaps [rsp+0x60], xmm6
00007eafdc3d19cc  vmovaps [rsp+0x70], xmm7
00007eafdc3d19d2  vmovaps [rsp+0x80], xmm8
00007eafdc3d19db  vmovaps [rsp+0x90], xmm9
00007eafdc3d19e4  vmovaps [rsp+0xA0], xmm10
00007eafdc3d19ed  vmovaps [rsp+0xB0], xmm11
00007eafdc3d19f6  vmovaps [rsp+0xC0], xmm12
00007eafdc3d19ff  vmovaps [rsp+0xD0], xmm13
00007eafdc3d1a08  vmovaps [rsp+0xE0], xmm14
00007eafdc3d1a11  sub rsp, 0x30
00007eafdc3d1a15  movaps [rsp], xmm15
00007eafdc3d1a1a  movaps [rsp+0x10], xmm14
00007eafdc3d1a20  movaps [rsp+0x20], xmm1
00007eafdc3d1a25  lea rdi, [rsp]
00007eafdc3d1a29  mov esi, 0x00
00007eafdc3d1a2e  mov rax, 0x645891675530
00007eafdc3d1a38  call rax
00007eafdc3d1a3a  movaps xmm15, [rsp]
00007eafdc3d1a3f  add rsp, 0x30
00007eafdc3d1a43  vmovaps xmm0, [rsp]
00007eafdc3d1a48  vmovaps xmm1, [rsp+0x10]
00007eafdc3d1a4e  vmovaps xmm2, [rsp+0x20]
00007eafdc3d1a54  vmovaps xmm3, [rsp+0x30]
00007eafdc3d1a5a  vmovaps xmm4, [rsp+0x40]
00007eafdc3d1a60  vmovaps xmm5, [rsp+0x50]
00007eafdc3d1a66  vmovaps xmm6, [rsp+0x60]
00007eafdc3d1a6c  vmovaps xmm7, [rsp+0x70]
00007eafdc3d1a72  vmovaps xmm8, [rsp+0x80]
00007eafdc3d1a7b  vmovaps xmm9, [rsp+0x90]
00007eafdc3d1a84  vmovaps xmm10, [rsp+0xA0]
00007eafdc3d1a8d  vmovaps xmm11, [rsp+0xB0]
00007eafdc3d1a96  vmovaps xmm12, [rsp+0xC0]
00007eafdc3d1a9f  vmovaps xmm13, [rsp+0xD0]
00007eafdc3d1aa8  vmovaps xmm14, [rsp+0xE0]
00007eafdc3d1ab1  add rsp, 0xF0
00007eafdc3d1ab8  pop r11
00007eafdc3d1aba  pop r10
00007eafdc3d1abc  pop r9
00007eafdc3d1abe  pop r8
00007eafdc3d1ac0  pop rsi
00007eafdc3d1ac1  pop rdi
00007eafdc3d1ac2  pop rdx
00007eafdc3d1ac3  pop rcx
00007eafdc3d1ac4  pop rax
00007eafdc3d1ac5  add rsp, 0x08
00007eafdc3d1ac9  jmp 0x00007EAFDC3CF9E7
00007eafdc3d1ace  call 0x00007EAFDC1FF430
00007eafdc3d1ad3  jmp 0x00007EAFDC3CF9F4
00007eafdc3d1ad8  sub rsp, 0x08
00007eafdc3d1adc  push rax
00007eafdc3d1add  push rcx
00007eafdc3d1ade  push rdx
00007eafdc3d1adf  push rdi
00007eafdc3d1ae0  push rsi
00007eafdc3d1ae1  push r8
00007eafdc3d1ae3  push r9
00007eafdc3d1ae5  push r10
00007eafdc3d1ae7  push r11
00007eafdc3d1ae9  sub rsp, 0xF0
00007eafdc3d1af0  vmovaps [rsp], xmm0
00007eafdc3d1af5  vmovaps [rsp+0x10], xmm1
00007eafdc3d1afb  vmovaps [rsp+0x20], xmm2
00007eafdc3d1b01  vmovaps [rsp+0x30], xmm3
00007eafdc3d1b07  vmovaps [rsp+0x40], xmm4
00007eafdc3d1b0d  vmovaps [rsp+0x50], xmm5
00007eafdc3d1b13  vmovaps [rsp+0x60], xmm6
00007eafdc3d1b19  vmovaps [rsp+0x70], xmm7
00007eafdc3d1b1f  vmovaps [rsp+0x80], xmm8
00007eafdc3d1b28  vmovaps [rsp+0x90], xmm9
00007eafdc3d1b31  vmovaps [rsp+0xA0], xmm10
00007eafdc3d1b3a  vmovaps [rsp+0xB0], xmm11
00007eafdc3d1b43  vmovaps [rsp+0xC0], xmm12
00007eafdc3d1b4c  vmovaps [rsp+0xD0], xmm13
00007eafdc3d1b55  vmovaps [rsp+0xE0], xmm15
00007eafdc3d1b5e  sub rsp, 0x30
00007eafdc3d1b62  movaps [rsp], xmm14
00007eafdc3d1b67  movaps [rsp+0x10], xmm13
00007eafdc3d1b6d  movaps [rsp+0x20], xmm1
00007eafdc3d1b72  lea rdi, [rsp]
00007eafdc3d1b76  mov esi, 0x00
00007eafdc3d1b7b  mov rax, 0x645891675530
00007eafdc3d1b85  call rax
00007eafdc3d1b87  movaps xmm14, [rsp]
00007eafdc3d1b8c  add rsp, 0x30
00007eafdc3d1b90  vmovaps xmm0, [rsp]
00007eafdc3d1b95  vmovaps xmm1, [rsp+0x10]
00007eafdc3d1b9b  vmovaps xmm2, [rsp+0x20]
00007eafdc3d1ba1  vmovaps xmm3, [rsp+0x30]
00007eafdc3d1ba7  vmovaps xmm4, [rsp+0x40]
00007eafdc3d1bad  vmovaps xmm5, [rsp+0x50]
00007eafdc3d1bb3  vmovaps xmm6, [rsp+0x60]
00007eafdc3d1bb9  vmovaps xmm7, [rsp+0x70]
00007eafdc3d1bbf  vmovaps xmm8, [rsp+0x80]
00007eafdc3d1bc8  vmovaps xmm9, [rsp+0x90]
00007eafdc3d1bd1  vmovaps xmm10, [rsp+0xA0]
00007eafdc3d1bda  vmovaps xmm11, [rsp+0xB0]
00007eafdc3d1be3  vmovaps xmm12, [rsp+0xC0]
00007eafdc3d1bec  vmovaps xmm13, [rsp+0xD0]
00007eafdc3d1bf5  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d1bfe  add rsp, 0xF0
00007eafdc3d1c05  pop r11
00007eafdc3d1c07  pop r10
00007eafdc3d1c09  pop r9
00007eafdc3d1c0b  pop r8
00007eafdc3d1c0d  pop rsi
00007eafdc3d1c0e  pop rdi
00007eafdc3d1c0f  pop rdx
00007eafdc3d1c10  pop rcx
00007eafdc3d1c11  pop rax
00007eafdc3d1c12  add rsp, 0x08
00007eafdc3d1c16  jmp 0x00007EAFDC3CFAAF
00007eafdc3d1c1b  sub rsp, 0x08
00007eafdc3d1c1f  push rax
00007eafdc3d1c20  push rcx
00007eafdc3d1c21  push rdx
00007eafdc3d1c22  push rdi
00007eafdc3d1c23  push rsi
00007eafdc3d1c24  push r8
00007eafdc3d1c26  push r9
00007eafdc3d1c28  push r10
00007eafdc3d1c2a  push r11
00007eafdc3d1c2c  sub rsp, 0xF0
00007eafdc3d1c33  vmovaps [rsp], xmm0
00007eafdc3d1c38  vmovaps [rsp+0x10], xmm1
00007eafdc3d1c3e  vmovaps [rsp+0x20], xmm2
00007eafdc3d1c44  vmovaps [rsp+0x30], xmm3
00007eafdc3d1c4a  vmovaps [rsp+0x40], xmm4
00007eafdc3d1c50  vmovaps [rsp+0x50], xmm5
00007eafdc3d1c56  vmovaps [rsp+0x60], xmm6
00007eafdc3d1c5c  vmovaps [rsp+0x70], xmm7
00007eafdc3d1c62  vmovaps [rsp+0x80], xmm8
00007eafdc3d1c6b  vmovaps [rsp+0x90], xmm9
00007eafdc3d1c74  vmovaps [rsp+0xA0], xmm10
00007eafdc3d1c7d  vmovaps [rsp+0xB0], xmm11
00007eafdc3d1c86  vmovaps [rsp+0xC0], xmm12
00007eafdc3d1c8f  vmovaps [rsp+0xD0], xmm13
00007eafdc3d1c98  vmovaps [rsp+0xE0], xmm14
00007eafdc3d1ca1  sub rsp, 0x30
00007eafdc3d1ca5  movaps [rsp], xmm15
00007eafdc3d1caa  movaps [rsp+0x10], xmm13
00007eafdc3d1cb0  movaps [rsp+0x20], xmm1
00007eafdc3d1cb5  lea rdi, [rsp]
00007eafdc3d1cb9  mov esi, 0x00
00007eafdc3d1cbe  mov rax, 0x645891675530
00007eafdc3d1cc8  call rax
00007eafdc3d1cca  movaps xmm15, [rsp]
00007eafdc3d1ccf  add rsp, 0x30
00007eafdc3d1cd3  vmovaps xmm0, [rsp]
00007eafdc3d1cd8  vmovaps xmm1, [rsp+0x10]
00007eafdc3d1cde  vmovaps xmm2, [rsp+0x20]
00007eafdc3d1ce4  vmovaps xmm3, [rsp+0x30]
00007eafdc3d1cea  vmovaps xmm4, [rsp+0x40]
00007eafdc3d1cf0  vmovaps xmm5, [rsp+0x50]
00007eafdc3d1cf6  vmovaps xmm6, [rsp+0x60]
00007eafdc3d1cfc  vmovaps xmm7, [rsp+0x70]
00007eafdc3d1d02  vmovaps xmm8, [rsp+0x80]
00007eafdc3d1d0b  vmovaps xmm9, [rsp+0x90]
00007eafdc3d1d14  vmovaps xmm10, [rsp+0xA0]
00007eafdc3d1d1d  vmovaps xmm11, [rsp+0xB0]
00007eafdc3d1d26  vmovaps xmm12, [rsp+0xC0]
00007eafdc3d1d2f  vmovaps xmm13, [rsp+0xD0]
00007eafdc3d1d38  vmovaps xmm14, [rsp+0xE0]
00007eafdc3d1d41  add rsp, 0xF0
00007eafdc3d1d48  pop r11
00007eafdc3d1d4a  pop r10
00007eafdc3d1d4c  pop r9
00007eafdc3d1d4e  pop r8
00007eafdc3d1d50  pop rsi
00007eafdc3d1d51  pop rdi
00007eafdc3d1d52  pop rdx
00007eafdc3d1d53  pop rcx
00007eafdc3d1d54  pop rax
00007eafdc3d1d55  add rsp, 0x08
00007eafdc3d1d59  jmp 0x00007EAFDC3CFAEB
00007eafdc3d1d5e  call 0x00007EAFDC1FF430
00007eafdc3d1d63  jmp 0x00007EAFDC3CFAF8
00007eafdc3d1d68  sub rsp, 0x08
00007eafdc3d1d6c  push rax
00007eafdc3d1d6d  push rcx
00007eafdc3d1d6e  push rdx
00007eafdc3d1d6f  push rdi
00007eafdc3d1d70  push rsi
00007eafdc3d1d71  push r8
00007eafdc3d1d73  push r9
00007eafdc3d1d75  push r10
00007eafdc3d1d77  push r11
00007eafdc3d1d79  sub rsp, 0xF0
00007eafdc3d1d80  vmovaps [rsp], xmm0
00007eafdc3d1d85  vmovaps [rsp+0x10], xmm1
00007eafdc3d1d8b  vmovaps [rsp+0x20], xmm2
00007eafdc3d1d91  vmovaps [rsp+0x30], xmm3
00007eafdc3d1d97  vmovaps [rsp+0x40], xmm4
00007eafdc3d1d9d  vmovaps [rsp+0x50], xmm5
00007eafdc3d1da3  vmovaps [rsp+0x60], xmm6
00007eafdc3d1da9  vmovaps [rsp+0x70], xmm7
00007eafdc3d1daf  vmovaps [rsp+0x80], xmm8
00007eafdc3d1db8  vmovaps [rsp+0x90], xmm9
00007eafdc3d1dc1  vmovaps [rsp+0xA0], xmm10
00007eafdc3d1dca  vmovaps [rsp+0xB0], xmm11
00007eafdc3d1dd3  vmovaps [rsp+0xC0], xmm12
00007eafdc3d1ddc  vmovaps [rsp+0xD0], xmm13
00007eafdc3d1de5  vmovaps [rsp+0xE0], xmm15
00007eafdc3d1dee  sub rsp, 0x30
00007eafdc3d1df2  movaps [rsp], xmm14
00007eafdc3d1df7  movaps [rsp+0x10], xmm13
00007eafdc3d1dfd  movaps [rsp+0x20], xmm2
00007eafdc3d1e02  lea rdi, [rsp]
00007eafdc3d1e06  mov esi, 0x00
00007eafdc3d1e0b  mov rax, 0x645891675530
00007eafdc3d1e15  call rax
00007eafdc3d1e17  movaps xmm14, [rsp]
00007eafdc3d1e1c  add rsp, 0x30
00007eafdc3d1e20  vmovaps xmm0, [rsp]
00007eafdc3d1e25  vmovaps xmm1, [rsp+0x10]
00007eafdc3d1e2b  vmovaps xmm2, [rsp+0x20]
00007eafdc3d1e31  vmovaps xmm3, [rsp+0x30]
00007eafdc3d1e37  vmovaps xmm4, [rsp+0x40]
00007eafdc3d1e3d  vmovaps xmm5, [rsp+0x50]
00007eafdc3d1e43  vmovaps xmm6, [rsp+0x60]
00007eafdc3d1e49  vmovaps xmm7, [rsp+0x70]
00007eafdc3d1e4f  vmovaps xmm8, [rsp+0x80]
00007eafdc3d1e58  vmovaps xmm9, [rsp+0x90]
00007eafdc3d1e61  vmovaps xmm10, [rsp+0xA0]
00007eafdc3d1e6a  vmovaps xmm11, [rsp+0xB0]
00007eafdc3d1e73  vmovaps xmm12, [rsp+0xC0]
00007eafdc3d1e7c  vmovaps xmm13, [rsp+0xD0]
00007eafdc3d1e85  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d1e8e  add rsp, 0xF0
00007eafdc3d1e95  pop r11
00007eafdc3d1e97  pop r10
00007eafdc3d1e99  pop r9
00007eafdc3d1e9b  pop r8
00007eafdc3d1e9d  pop rsi
00007eafdc3d1e9e  pop rdi
00007eafdc3d1e9f  pop rdx
00007eafdc3d1ea0  pop rcx
00007eafdc3d1ea1  pop rax
00007eafdc3d1ea2  add rsp, 0x08
00007eafdc3d1ea6  jmp 0x00007EAFDC3CFB24
00007eafdc3d1eab  sub rsp, 0x08
00007eafdc3d1eaf  push rax
00007eafdc3d1eb0  push rcx
00007eafdc3d1eb1  push rdx
00007eafdc3d1eb2  push rdi
00007eafdc3d1eb3  push rsi
00007eafdc3d1eb4  push r8
00007eafdc3d1eb6  push r9
00007eafdc3d1eb8  push r10
00007eafdc3d1eba  push r11
00007eafdc3d1ebc  sub rsp, 0xF0
00007eafdc3d1ec3  vmovaps [rsp], xmm0
00007eafdc3d1ec8  vmovaps [rsp+0x10], xmm2
00007eafdc3d1ece  vmovaps [rsp+0x20], xmm3
00007eafdc3d1ed4  vmovaps [rsp+0x30], xmm4
00007eafdc3d1eda  vmovaps [rsp+0x40], xmm5
00007eafdc3d1ee0  vmovaps [rsp+0x50], xmm6
00007eafdc3d1ee6  vmovaps [rsp+0x60], xmm7
00007eafdc3d1eec  vmovaps [rsp+0x70], xmm8
00007eafdc3d1ef2  vmovaps [rsp+0x80], xmm9
00007eafdc3d1efb  vmovaps [rsp+0x90], xmm10
00007eafdc3d1f04  vmovaps [rsp+0xA0], xmm11
00007eafdc3d1f0d  vmovaps [rsp+0xB0], xmm12
00007eafdc3d1f16  vmovaps [rsp+0xC0], xmm13
00007eafdc3d1f1f  vmovaps [rsp+0xD0], xmm14
00007eafdc3d1f28  vmovaps [rsp+0xE0], xmm15
00007eafdc3d1f31  sub rsp, 0x30
00007eafdc3d1f35  movaps [rsp], xmm1
00007eafdc3d1f39  movaps [rsp+0x10], xmm13
00007eafdc3d1f3f  movaps [rsp+0x20], xmm2
00007eafdc3d1f44  lea rdi, [rsp]
00007eafdc3d1f48  mov esi, 0x00
00007eafdc3d1f4d  mov rax, 0x645891675530
00007eafdc3d1f57  call rax
00007eafdc3d1f59  movaps xmm1, [rsp]
00007eafdc3d1f5d  add rsp, 0x30
00007eafdc3d1f61  vmovaps xmm0, [rsp]
00007eafdc3d1f66  vmovaps xmm2, [rsp+0x10]
00007eafdc3d1f6c  vmovaps xmm3, [rsp+0x20]
00007eafdc3d1f72  vmovaps xmm4, [rsp+0x30]
00007eafdc3d1f78  vmovaps xmm5, [rsp+0x40]
00007eafdc3d1f7e  vmovaps xmm6, [rsp+0x50]
00007eafdc3d1f84  vmovaps xmm7, [rsp+0x60]
00007eafdc3d1f8a  vmovaps xmm8, [rsp+0x70]
00007eafdc3d1f90  vmovaps xmm9, [rsp+0x80]
00007eafdc3d1f99  vmovaps xmm10, [rsp+0x90]
00007eafdc3d1fa2  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d1fab  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d1fb4  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d1fbd  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d1fc6  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d1fcf  add rsp, 0xF0
00007eafdc3d1fd6  pop r11
00007eafdc3d1fd8  pop r10
00007eafdc3d1fda  pop r9
00007eafdc3d1fdc  pop r8
00007eafdc3d1fde  pop rsi
00007eafdc3d1fdf  pop rdi
00007eafdc3d1fe0  pop rdx
00007eafdc3d1fe1  pop rcx
00007eafdc3d1fe2  pop rax
00007eafdc3d1fe3  add rsp, 0x08
00007eafdc3d1fe7  jmp 0x00007EAFDC3CFB52
00007eafdc3d1fec  sub rsp, 0x08
00007eafdc3d1ff0  push rax
00007eafdc3d1ff1  push rcx
00007eafdc3d1ff2  push rdx
00007eafdc3d1ff3  push rdi
00007eafdc3d1ff4  push rsi
00007eafdc3d1ff5  push r8
00007eafdc3d1ff7  push r9
00007eafdc3d1ff9  push r10
00007eafdc3d1ffb  push r11
00007eafdc3d1ffd  sub rsp, 0xF0
00007eafdc3d2004  vmovaps [rsp], xmm0
00007eafdc3d2009  vmovaps [rsp+0x10], xmm1
00007eafdc3d200f  vmovaps [rsp+0x20], xmm3
00007eafdc3d2015  vmovaps [rsp+0x30], xmm4
00007eafdc3d201b  vmovaps [rsp+0x40], xmm5
00007eafdc3d2021  vmovaps [rsp+0x50], xmm6
00007eafdc3d2027  vmovaps [rsp+0x60], xmm7
00007eafdc3d202d  vmovaps [rsp+0x70], xmm8
00007eafdc3d2033  vmovaps [rsp+0x80], xmm9
00007eafdc3d203c  vmovaps [rsp+0x90], xmm10
00007eafdc3d2045  vmovaps [rsp+0xA0], xmm11
00007eafdc3d204e  vmovaps [rsp+0xB0], xmm12
00007eafdc3d2057  vmovaps [rsp+0xC0], xmm13
00007eafdc3d2060  vmovaps [rsp+0xD0], xmm14
00007eafdc3d2069  vmovaps [rsp+0xE0], xmm15
00007eafdc3d2072  sub rsp, 0x30
00007eafdc3d2076  movaps [rsp], xmm2
00007eafdc3d207a  movaps [rsp+0x10], xmm1
00007eafdc3d207f  movaps [rsp+0x20], xmm13
00007eafdc3d2085  lea rdi, [rsp]
00007eafdc3d2089  mov esi, 0x00
00007eafdc3d208e  mov rax, 0x645891675530
00007eafdc3d2098  call rax
00007eafdc3d209a  movaps xmm2, [rsp]
00007eafdc3d209e  add rsp, 0x30
00007eafdc3d20a2  vmovaps xmm0, [rsp]
00007eafdc3d20a7  vmovaps xmm1, [rsp+0x10]
00007eafdc3d20ad  vmovaps xmm3, [rsp+0x20]
00007eafdc3d20b3  vmovaps xmm4, [rsp+0x30]
00007eafdc3d20b9  vmovaps xmm5, [rsp+0x40]
00007eafdc3d20bf  vmovaps xmm6, [rsp+0x50]
00007eafdc3d20c5  vmovaps xmm7, [rsp+0x60]
00007eafdc3d20cb  vmovaps xmm8, [rsp+0x70]
00007eafdc3d20d1  vmovaps xmm9, [rsp+0x80]
00007eafdc3d20da  vmovaps xmm10, [rsp+0x90]
00007eafdc3d20e3  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d20ec  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d20f5  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d20fe  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d2107  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d2110  add rsp, 0xF0
00007eafdc3d2117  pop r11
00007eafdc3d2119  pop r10
00007eafdc3d211b  pop r9
00007eafdc3d211d  pop r8
00007eafdc3d211f  pop rsi
00007eafdc3d2120  pop rdi
00007eafdc3d2121  pop rdx
00007eafdc3d2122  pop rcx
00007eafdc3d2123  pop rax
00007eafdc3d2124  add rsp, 0x08
00007eafdc3d2128  jmp 0x00007EAFDC3CFBAB
00007eafdc3d212d  call 0x00007EAFDC1FF430
00007eafdc3d2132  jmp 0x00007EAFDC3CFBB8
00007eafdc3d2137  sub rsp, 0x08
00007eafdc3d213b  push rax
00007eafdc3d213c  push rcx
00007eafdc3d213d  push rdx
00007eafdc3d213e  push rdi
00007eafdc3d213f  push rsi
00007eafdc3d2140  push r8
00007eafdc3d2142  push r9
00007eafdc3d2144  push r10
00007eafdc3d2146  push r11
00007eafdc3d2148  sub rsp, 0xF0
00007eafdc3d214f  vmovaps [rsp], xmm0
00007eafdc3d2154  vmovaps [rsp+0x10], xmm1
00007eafdc3d215a  vmovaps [rsp+0x20], xmm2
00007eafdc3d2160  vmovaps [rsp+0x30], xmm3
00007eafdc3d2166  vmovaps [rsp+0x40], xmm4
00007eafdc3d216c  vmovaps [rsp+0x50], xmm5
00007eafdc3d2172  vmovaps [rsp+0x60], xmm6
00007eafdc3d2178  vmovaps [rsp+0x70], xmm7
00007eafdc3d217e  vmovaps [rsp+0x80], xmm8
00007eafdc3d2187  vmovaps [rsp+0x90], xmm9
00007eafdc3d2190  vmovaps [rsp+0xA0], xmm10
00007eafdc3d2199  vmovaps [rsp+0xB0], xmm11
00007eafdc3d21a2  vmovaps [rsp+0xC0], xmm12
00007eafdc3d21ab  vmovaps [rsp+0xD0], xmm13
00007eafdc3d21b4  vmovaps [rsp+0xE0], xmm14
00007eafdc3d21bd  sub rsp, 0x30
00007eafdc3d21c1  movaps [rsp], xmm15
00007eafdc3d21c6  movaps [rsp+0x10], xmm13
00007eafdc3d21cc  movaps [rsp+0x20], xmm1
00007eafdc3d21d1  lea rdi, [rsp]
00007eafdc3d21d5  mov esi, 0x00
00007eafdc3d21da  mov rax, 0x645891675530
00007eafdc3d21e4  call rax
00007eafdc3d21e6  movaps xmm15, [rsp]
00007eafdc3d21eb  add rsp, 0x30
00007eafdc3d21ef  vmovaps xmm0, [rsp]
00007eafdc3d21f4  vmovaps xmm1, [rsp+0x10]
00007eafdc3d21fa  vmovaps xmm2, [rsp+0x20]
00007eafdc3d2200  vmovaps xmm3, [rsp+0x30]
00007eafdc3d2206  vmovaps xmm4, [rsp+0x40]
00007eafdc3d220c  vmovaps xmm5, [rsp+0x50]
00007eafdc3d2212  vmovaps xmm6, [rsp+0x60]
00007eafdc3d2218  vmovaps xmm7, [rsp+0x70]
00007eafdc3d221e  vmovaps xmm8, [rsp+0x80]
00007eafdc3d2227  vmovaps xmm9, [rsp+0x90]
00007eafdc3d2230  vmovaps xmm10, [rsp+0xA0]
00007eafdc3d2239  vmovaps xmm11, [rsp+0xB0]
00007eafdc3d2242  vmovaps xmm12, [rsp+0xC0]
00007eafdc3d224b  vmovaps xmm13, [rsp+0xD0]
00007eafdc3d2254  vmovaps xmm14, [rsp+0xE0]
00007eafdc3d225d  add rsp, 0xF0
00007eafdc3d2264  pop r11
00007eafdc3d2266  pop r10
00007eafdc3d2268  pop r9
00007eafdc3d226a  pop r8
00007eafdc3d226c  pop rsi
00007eafdc3d226d  pop rdi
00007eafdc3d226e  pop rdx
00007eafdc3d226f  pop rcx
00007eafdc3d2270  pop rax
00007eafdc3d2271  add rsp, 0x08
00007eafdc3d2275  jmp 0x00007EAFDC3CFBF7
00007eafdc3d227a  sub rsp, 0x08
00007eafdc3d227e  push rax
00007eafdc3d227f  push rcx
00007eafdc3d2280  push rdx
00007eafdc3d2281  push rdi
00007eafdc3d2282  push rsi
00007eafdc3d2283  push r8
00007eafdc3d2285  push r9
00007eafdc3d2287  push r10
00007eafdc3d2289  push r11
00007eafdc3d228b  sub rsp, 0xF0
00007eafdc3d2292  vmovaps [rsp], xmm0
00007eafdc3d2297  vmovaps [rsp+0x10], xmm1
00007eafdc3d229d  vmovaps [rsp+0x20], xmm2
00007eafdc3d22a3  vmovaps [rsp+0x30], xmm3
00007eafdc3d22a9  vmovaps [rsp+0x40], xmm4
00007eafdc3d22af  vmovaps [rsp+0x50], xmm5
00007eafdc3d22b5  vmovaps [rsp+0x60], xmm6
00007eafdc3d22bb  vmovaps [rsp+0x70], xmm7
00007eafdc3d22c1  vmovaps [rsp+0x80], xmm8
00007eafdc3d22ca  vmovaps [rsp+0x90], xmm9
00007eafdc3d22d3  vmovaps [rsp+0xA0], xmm10
00007eafdc3d22dc  vmovaps [rsp+0xB0], xmm11
00007eafdc3d22e5  vmovaps [rsp+0xC0], xmm12
00007eafdc3d22ee  vmovaps [rsp+0xD0], xmm13
00007eafdc3d22f7  vmovaps [rsp+0xE0], xmm15
00007eafdc3d2300  sub rsp, 0x30
00007eafdc3d2304  movaps [rsp], xmm14
00007eafdc3d2309  movaps [rsp+0x10], xmm11
00007eafdc3d230f  movaps [rsp+0x20], xmm1
00007eafdc3d2314  lea rdi, [rsp]
00007eafdc3d2318  mov esi, 0x00
00007eafdc3d231d  mov rax, 0x645891675530
00007eafdc3d2327  call rax
00007eafdc3d2329  movaps xmm14, [rsp]
00007eafdc3d232e  add rsp, 0x30
00007eafdc3d2332  vmovaps xmm0, [rsp]
00007eafdc3d2337  vmovaps xmm1, [rsp+0x10]
00007eafdc3d233d  vmovaps xmm2, [rsp+0x20]
00007eafdc3d2343  vmovaps xmm3, [rsp+0x30]
00007eafdc3d2349  vmovaps xmm4, [rsp+0x40]
00007eafdc3d234f  vmovaps xmm5, [rsp+0x50]
00007eafdc3d2355  vmovaps xmm6, [rsp+0x60]
00007eafdc3d235b  vmovaps xmm7, [rsp+0x70]
00007eafdc3d2361  vmovaps xmm8, [rsp+0x80]
00007eafdc3d236a  vmovaps xmm9, [rsp+0x90]
00007eafdc3d2373  vmovaps xmm10, [rsp+0xA0]
00007eafdc3d237c  vmovaps xmm11, [rsp+0xB0]
00007eafdc3d2385  vmovaps xmm12, [rsp+0xC0]
00007eafdc3d238e  vmovaps xmm13, [rsp+0xD0]
00007eafdc3d2397  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d23a0  add rsp, 0xF0
00007eafdc3d23a7  pop r11
00007eafdc3d23a9  pop r10
00007eafdc3d23ab  pop r9
00007eafdc3d23ad  pop r8
00007eafdc3d23af  pop rsi
00007eafdc3d23b0  pop rdi
00007eafdc3d23b1  pop rdx
00007eafdc3d23b2  pop rcx
00007eafdc3d23b3  pop rax
00007eafdc3d23b4  add rsp, 0x08
00007eafdc3d23b8  jmp 0x00007EAFDC3CFC21
00007eafdc3d23bd  sub rsp, 0x08
00007eafdc3d23c1  push rax
00007eafdc3d23c2  push rcx
00007eafdc3d23c3  push rdx
00007eafdc3d23c4  push rdi
00007eafdc3d23c5  push rsi
00007eafdc3d23c6  push r8
00007eafdc3d23c8  push r9
00007eafdc3d23ca  push r10
00007eafdc3d23cc  push r11
00007eafdc3d23ce  sub rsp, 0xF0
00007eafdc3d23d5  vmovaps [rsp], xmm0
00007eafdc3d23da  vmovaps [rsp+0x10], xmm1
00007eafdc3d23e0  vmovaps [rsp+0x20], xmm2
00007eafdc3d23e6  vmovaps [rsp+0x30], xmm3
00007eafdc3d23ec  vmovaps [rsp+0x40], xmm4
00007eafdc3d23f2  vmovaps [rsp+0x50], xmm5
00007eafdc3d23f8  vmovaps [rsp+0x60], xmm6
00007eafdc3d23fe  vmovaps [rsp+0x70], xmm7
00007eafdc3d2404  vmovaps [rsp+0x80], xmm8
00007eafdc3d240d  vmovaps [rsp+0x90], xmm9
00007eafdc3d2416  vmovaps [rsp+0xA0], xmm10
00007eafdc3d241f  vmovaps [rsp+0xB0], xmm11
00007eafdc3d2428  vmovaps [rsp+0xC0], xmm12
00007eafdc3d2431  vmovaps [rsp+0xD0], xmm14
00007eafdc3d243a  vmovaps [rsp+0xE0], xmm15
00007eafdc3d2443  sub rsp, 0x30
00007eafdc3d2447  movaps [rsp], xmm13
00007eafdc3d244c  movaps [rsp+0x10], xmm11
00007eafdc3d2452  movaps [rsp+0x20], xmm1
00007eafdc3d2457  lea rdi, [rsp]
00007eafdc3d245b  mov esi, 0x00
00007eafdc3d2460  mov rax, 0x645891675530
00007eafdc3d246a  call rax
00007eafdc3d246c  movaps xmm13, [rsp]
00007eafdc3d2471  add rsp, 0x30
00007eafdc3d2475  vmovaps xmm0, [rsp]
00007eafdc3d247a  vmovaps xmm1, [rsp+0x10]
00007eafdc3d2480  vmovaps xmm2, [rsp+0x20]
00007eafdc3d2486  vmovaps xmm3, [rsp+0x30]
00007eafdc3d248c  vmovaps xmm4, [rsp+0x40]
00007eafdc3d2492  vmovaps xmm5, [rsp+0x50]
00007eafdc3d2498  vmovaps xmm6, [rsp+0x60]
00007eafdc3d249e  vmovaps xmm7, [rsp+0x70]
00007eafdc3d24a4  vmovaps xmm8, [rsp+0x80]
00007eafdc3d24ad  vmovaps xmm9, [rsp+0x90]
00007eafdc3d24b6  vmovaps xmm10, [rsp+0xA0]
00007eafdc3d24bf  vmovaps xmm11, [rsp+0xB0]
00007eafdc3d24c8  vmovaps xmm12, [rsp+0xC0]
00007eafdc3d24d1  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d24da  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d24e3  add rsp, 0xF0
00007eafdc3d24ea  pop r11
00007eafdc3d24ec  pop r10
00007eafdc3d24ee  pop r9
00007eafdc3d24f0  pop r8
00007eafdc3d24f2  pop rsi
00007eafdc3d24f3  pop rdi
00007eafdc3d24f4  pop rdx
00007eafdc3d24f5  pop rcx
00007eafdc3d24f6  pop rax
00007eafdc3d24f7  add rsp, 0x08
00007eafdc3d24fb  jmp 0x00007EAFDC3CFC76
00007eafdc3d2500  call 0x00007EAFDC1FF430
00007eafdc3d2505  jmp 0x00007EAFDC3CFC83
00007eafdc3d250a  sub rsp, 0x08
00007eafdc3d250e  push rax
00007eafdc3d250f  push rcx
00007eafdc3d2510  push rdx
00007eafdc3d2511  push rdi
00007eafdc3d2512  push rsi
00007eafdc3d2513  push r8
00007eafdc3d2515  push r9
00007eafdc3d2517  push r10
00007eafdc3d2519  push r11
00007eafdc3d251b  sub rsp, 0xF0
00007eafdc3d2522  vmovaps [rsp], xmm0
00007eafdc3d2527  vmovaps [rsp+0x10], xmm1
00007eafdc3d252d  vmovaps [rsp+0x20], xmm2
00007eafdc3d2533  vmovaps [rsp+0x30], xmm3
00007eafdc3d2539  vmovaps [rsp+0x40], xmm4
00007eafdc3d253f  vmovaps [rsp+0x50], xmm5
00007eafdc3d2545  vmovaps [rsp+0x60], xmm6
00007eafdc3d254b  vmovaps [rsp+0x70], xmm7
00007eafdc3d2551  vmovaps [rsp+0x80], xmm8
00007eafdc3d255a  vmovaps [rsp+0x90], xmm9
00007eafdc3d2563  vmovaps [rsp+0xA0], xmm10
00007eafdc3d256c  vmovaps [rsp+0xB0], xmm11
00007eafdc3d2575  vmovaps [rsp+0xC0], xmm12
00007eafdc3d257e  vmovaps [rsp+0xD0], xmm13
00007eafdc3d2587  vmovaps [rsp+0xE0], xmm14
00007eafdc3d2590  sub rsp, 0x30
00007eafdc3d2594  movaps [rsp], xmm15
00007eafdc3d2599  movaps [rsp+0x10], xmm11
00007eafdc3d259f  movaps [rsp+0x20], xmm1
00007eafdc3d25a4  lea rdi, [rsp]
00007eafdc3d25a8  mov esi, 0x00
00007eafdc3d25ad  mov rax, 0x645891675530
00007eafdc3d25b7  call rax
00007eafdc3d25b9  movaps xmm15, [rsp]
00007eafdc3d25be  add rsp, 0x30
00007eafdc3d25c2  vmovaps xmm0, [rsp]
00007eafdc3d25c7  vmovaps xmm1, [rsp+0x10]
00007eafdc3d25cd  vmovaps xmm2, [rsp+0x20]
00007eafdc3d25d3  vmovaps xmm3, [rsp+0x30]
00007eafdc3d25d9  vmovaps xmm4, [rsp+0x40]
00007eafdc3d25df  vmovaps xmm5, [rsp+0x50]
00007eafdc3d25e5  vmovaps xmm6, [rsp+0x60]
00007eafdc3d25eb  vmovaps xmm7, [rsp+0x70]
00007eafdc3d25f1  vmovaps xmm8, [rsp+0x80]
00007eafdc3d25fa  vmovaps xmm9, [rsp+0x90]
00007eafdc3d2603  vmovaps xmm10, [rsp+0xA0]
00007eafdc3d260c  vmovaps xmm11, [rsp+0xB0]
00007eafdc3d2615  vmovaps xmm12, [rsp+0xC0]
00007eafdc3d261e  vmovaps xmm13, [rsp+0xD0]
00007eafdc3d2627  vmovaps xmm14, [rsp+0xE0]
00007eafdc3d2630  add rsp, 0xF0
00007eafdc3d2637  pop r11
00007eafdc3d2639  pop r10
00007eafdc3d263b  pop r9
00007eafdc3d263d  pop r8
00007eafdc3d263f  pop rsi
00007eafdc3d2640  pop rdi
00007eafdc3d2641  pop rdx
00007eafdc3d2642  pop rcx
00007eafdc3d2643  pop rax
00007eafdc3d2644  add rsp, 0x08
00007eafdc3d2648  jmp 0x00007EAFDC3CFCBC
00007eafdc3d264d  sub rsp, 0x08
00007eafdc3d2651  push rax
00007eafdc3d2652  push rcx
00007eafdc3d2653  push rdx
00007eafdc3d2654  push rdi
00007eafdc3d2655  push rsi
00007eafdc3d2656  push r8
00007eafdc3d2658  push r9
00007eafdc3d265a  push r10
00007eafdc3d265c  push r11
00007eafdc3d265e  sub rsp, 0xF0
00007eafdc3d2665  vmovaps [rsp], xmm0
00007eafdc3d266a  vmovaps [rsp+0x10], xmm1
00007eafdc3d2670  vmovaps [rsp+0x20], xmm2
00007eafdc3d2676  vmovaps [rsp+0x30], xmm3
00007eafdc3d267c  vmovaps [rsp+0x40], xmm4
00007eafdc3d2682  vmovaps [rsp+0x50], xmm5
00007eafdc3d2688  vmovaps [rsp+0x60], xmm6
00007eafdc3d268e  vmovaps [rsp+0x70], xmm7
00007eafdc3d2694  vmovaps [rsp+0x80], xmm8
00007eafdc3d269d  vmovaps [rsp+0x90], xmm9
00007eafdc3d26a6  vmovaps [rsp+0xA0], xmm10
00007eafdc3d26af  vmovaps [rsp+0xB0], xmm12
00007eafdc3d26b8  vmovaps [rsp+0xC0], xmm13
00007eafdc3d26c1  vmovaps [rsp+0xD0], xmm14
00007eafdc3d26ca  vmovaps [rsp+0xE0], xmm15
00007eafdc3d26d3  sub rsp, 0x30
00007eafdc3d26d7  movaps [rsp], xmm11
00007eafdc3d26dc  movaps [rsp+0x10], xmm6
00007eafdc3d26e1  movaps [rsp+0x20], xmm14
00007eafdc3d26e7  lea rdi, [rsp]
00007eafdc3d26eb  mov esi, 0x00
00007eafdc3d26f0  mov rax, 0x645891675530
00007eafdc3d26fa  call rax
00007eafdc3d26fc  movaps xmm11, [rsp]
00007eafdc3d2701  add rsp, 0x30
00007eafdc3d2705  vmovaps xmm0, [rsp]
00007eafdc3d270a  vmovaps xmm1, [rsp+0x10]
00007eafdc3d2710  vmovaps xmm2, [rsp+0x20]
00007eafdc3d2716  vmovaps xmm3, [rsp+0x30]
00007eafdc3d271c  vmovaps xmm4, [rsp+0x40]
00007eafdc3d2722  vmovaps xmm5, [rsp+0x50]
00007eafdc3d2728  vmovaps xmm6, [rsp+0x60]
00007eafdc3d272e  vmovaps xmm7, [rsp+0x70]
00007eafdc3d2734  vmovaps xmm8, [rsp+0x80]
00007eafdc3d273d  vmovaps xmm9, [rsp+0x90]
00007eafdc3d2746  vmovaps xmm10, [rsp+0xA0]
00007eafdc3d274f  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d2758  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d2761  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d276a  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d2773  add rsp, 0xF0
00007eafdc3d277a  pop r11
00007eafdc3d277c  pop r10
00007eafdc3d277e  pop r9
00007eafdc3d2780  pop r8
00007eafdc3d2782  pop rsi
00007eafdc3d2783  pop rdi
00007eafdc3d2784  pop rdx
00007eafdc3d2785  pop rcx
00007eafdc3d2786  pop rax
00007eafdc3d2787  add rsp, 0x08
00007eafdc3d278b  jmp 0x00007EAFDC3CFD34
00007eafdc3d2790  call 0x00007EAFDC1FF430
00007eafdc3d2795  jmp 0x00007EAFDC3CFD3E
00007eafdc3d279a  sub rsp, 0x08
00007eafdc3d279e  push rax
00007eafdc3d279f  push rcx
00007eafdc3d27a0  push rdx
00007eafdc3d27a1  push rdi
00007eafdc3d27a2  push rsi
00007eafdc3d27a3  push r8
00007eafdc3d27a5  push r9
00007eafdc3d27a7  push r10
00007eafdc3d27a9  push r11
00007eafdc3d27ab  sub rsp, 0xF0
00007eafdc3d27b2  vmovaps [rsp], xmm0
00007eafdc3d27b7  vmovaps [rsp+0x10], xmm1
00007eafdc3d27bd  vmovaps [rsp+0x20], xmm2
00007eafdc3d27c3  vmovaps [rsp+0x30], xmm3
00007eafdc3d27c9  vmovaps [rsp+0x40], xmm4
00007eafdc3d27cf  vmovaps [rsp+0x50], xmm5
00007eafdc3d27d5  vmovaps [rsp+0x60], xmm6
00007eafdc3d27db  vmovaps [rsp+0x70], xmm7
00007eafdc3d27e1  vmovaps [rsp+0x80], xmm8
00007eafdc3d27ea  vmovaps [rsp+0x90], xmm9
00007eafdc3d27f3  vmovaps [rsp+0xA0], xmm10
00007eafdc3d27fc  vmovaps [rsp+0xB0], xmm11
00007eafdc3d2805  vmovaps [rsp+0xC0], xmm12
00007eafdc3d280e  vmovaps [rsp+0xD0], xmm13
00007eafdc3d2817  vmovaps [rsp+0xE0], xmm15
00007eafdc3d2820  sub rsp, 0x30
00007eafdc3d2824  movaps [rsp], xmm14
00007eafdc3d2829  movaps [rsp+0x10], xmm6
00007eafdc3d282e  movaps [rsp+0x20], xmm2
00007eafdc3d2833  lea rdi, [rsp]
00007eafdc3d2837  mov esi, 0x00
00007eafdc3d283c  mov rax, 0x645891675530
00007eafdc3d2846  call rax
00007eafdc3d2848  movaps xmm14, [rsp]
00007eafdc3d284d  add rsp, 0x30
00007eafdc3d2851  vmovaps xmm0, [rsp]
00007eafdc3d2856  vmovaps xmm1, [rsp+0x10]
00007eafdc3d285c  vmovaps xmm2, [rsp+0x20]
00007eafdc3d2862  vmovaps xmm3, [rsp+0x30]
00007eafdc3d2868  vmovaps xmm4, [rsp+0x40]
00007eafdc3d286e  vmovaps xmm5, [rsp+0x50]
00007eafdc3d2874  vmovaps xmm6, [rsp+0x60]
00007eafdc3d287a  vmovaps xmm7, [rsp+0x70]
00007eafdc3d2880  vmovaps xmm8, [rsp+0x80]
00007eafdc3d2889  vmovaps xmm9, [rsp+0x90]
00007eafdc3d2892  vmovaps xmm10, [rsp+0xA0]
00007eafdc3d289b  vmovaps xmm11, [rsp+0xB0]
00007eafdc3d28a4  vmovaps xmm12, [rsp+0xC0]
00007eafdc3d28ad  vmovaps xmm13, [rsp+0xD0]
00007eafdc3d28b6  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d28bf  add rsp, 0xF0
00007eafdc3d28c6  pop r11
00007eafdc3d28c8  pop r10
00007eafdc3d28ca  pop r9
00007eafdc3d28cc  pop r8
00007eafdc3d28ce  pop rsi
00007eafdc3d28cf  pop rdi
00007eafdc3d28d0  pop rdx
00007eafdc3d28d1  pop rcx
00007eafdc3d28d2  pop rax
00007eafdc3d28d3  add rsp, 0x08
00007eafdc3d28d7  jmp 0x00007EAFDC3CFD72
00007eafdc3d28dc  sub rsp, 0x08
00007eafdc3d28e0  push rax
00007eafdc3d28e1  push rcx
00007eafdc3d28e2  push rdx
00007eafdc3d28e3  push rdi
00007eafdc3d28e4  push rsi
00007eafdc3d28e5  push r8
00007eafdc3d28e7  push r9
00007eafdc3d28e9  push r10
00007eafdc3d28eb  push r11
00007eafdc3d28ed  sub rsp, 0xF0
00007eafdc3d28f4  vmovaps [rsp], xmm0
00007eafdc3d28f9  vmovaps [rsp+0x10], xmm1
00007eafdc3d28ff  vmovaps [rsp+0x20], xmm2
00007eafdc3d2905  vmovaps [rsp+0x30], xmm3
00007eafdc3d290b  vmovaps [rsp+0x40], xmm4
00007eafdc3d2911  vmovaps [rsp+0x50], xmm5
00007eafdc3d2917  vmovaps [rsp+0x60], xmm7
00007eafdc3d291d  vmovaps [rsp+0x70], xmm8
00007eafdc3d2923  vmovaps [rsp+0x80], xmm9
00007eafdc3d292c  vmovaps [rsp+0x90], xmm10
00007eafdc3d2935  vmovaps [rsp+0xA0], xmm11
00007eafdc3d293e  vmovaps [rsp+0xB0], xmm12
00007eafdc3d2947  vmovaps [rsp+0xC0], xmm13
00007eafdc3d2950  vmovaps [rsp+0xD0], xmm14
00007eafdc3d2959  vmovaps [rsp+0xE0], xmm15
00007eafdc3d2962  sub rsp, 0x30
00007eafdc3d2966  movaps [rsp], xmm6
00007eafdc3d296a  movaps [rsp+0x10], xmm5
00007eafdc3d296f  movaps [rsp+0x20], xmm1
00007eafdc3d2974  lea rdi, [rsp]
00007eafdc3d2978  mov esi, 0x00
00007eafdc3d297d  mov rax, 0x645891675530
00007eafdc3d2987  call rax
00007eafdc3d2989  movaps xmm6, [rsp]
00007eafdc3d298d  add rsp, 0x30
00007eafdc3d2991  vmovaps xmm0, [rsp]
00007eafdc3d2996  vmovaps xmm1, [rsp+0x10]
00007eafdc3d299c  vmovaps xmm2, [rsp+0x20]
00007eafdc3d29a2  vmovaps xmm3, [rsp+0x30]
00007eafdc3d29a8  vmovaps xmm4, [rsp+0x40]
00007eafdc3d29ae  vmovaps xmm5, [rsp+0x50]
00007eafdc3d29b4  vmovaps xmm7, [rsp+0x60]
00007eafdc3d29ba  vmovaps xmm8, [rsp+0x70]
00007eafdc3d29c0  vmovaps xmm9, [rsp+0x80]
00007eafdc3d29c9  vmovaps xmm10, [rsp+0x90]
00007eafdc3d29d2  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d29db  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d29e4  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d29ed  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d29f6  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d29ff  add rsp, 0xF0
00007eafdc3d2a06  pop r11
00007eafdc3d2a08  pop r10
00007eafdc3d2a0a  pop r9
00007eafdc3d2a0c  pop r8
00007eafdc3d2a0e  pop rsi
00007eafdc3d2a0f  pop rdi
00007eafdc3d2a10  pop rdx
00007eafdc3d2a11  pop rcx
00007eafdc3d2a12  pop rax
00007eafdc3d2a13  add rsp, 0x08
00007eafdc3d2a17  jmp 0x00007EAFDC3CFD98
00007eafdc3d2a1c  sub rsp, 0x08
00007eafdc3d2a20  push rax
00007eafdc3d2a21  push rcx
00007eafdc3d2a22  push rdx
00007eafdc3d2a23  push rdi
00007eafdc3d2a24  push rsi
00007eafdc3d2a25  push r8
00007eafdc3d2a27  push r9
00007eafdc3d2a29  push r10
00007eafdc3d2a2b  push r11
00007eafdc3d2a2d  sub rsp, 0xF0
00007eafdc3d2a34  vmovaps [rsp], xmm0
00007eafdc3d2a39  vmovaps [rsp+0x10], xmm2
00007eafdc3d2a3f  vmovaps [rsp+0x20], xmm3
00007eafdc3d2a45  vmovaps [rsp+0x30], xmm4
00007eafdc3d2a4b  vmovaps [rsp+0x40], xmm5
00007eafdc3d2a51  vmovaps [rsp+0x50], xmm6
00007eafdc3d2a57  vmovaps [rsp+0x60], xmm7
00007eafdc3d2a5d  vmovaps [rsp+0x70], xmm8
00007eafdc3d2a63  vmovaps [rsp+0x80], xmm9
00007eafdc3d2a6c  vmovaps [rsp+0x90], xmm10
00007eafdc3d2a75  vmovaps [rsp+0xA0], xmm11
00007eafdc3d2a7e  vmovaps [rsp+0xB0], xmm12
00007eafdc3d2a87  vmovaps [rsp+0xC0], xmm13
00007eafdc3d2a90  vmovaps [rsp+0xD0], xmm14
00007eafdc3d2a99  vmovaps [rsp+0xE0], xmm15
00007eafdc3d2aa2  sub rsp, 0x30
00007eafdc3d2aa6  movaps [rsp], xmm1
00007eafdc3d2aaa  movaps [rsp+0x10], xmm5
00007eafdc3d2aaf  movaps [rsp+0x20], xmm13
00007eafdc3d2ab5  lea rdi, [rsp]
00007eafdc3d2ab9  mov esi, 0x00
00007eafdc3d2abe  mov rax, 0x645891675530
00007eafdc3d2ac8  call rax
00007eafdc3d2aca  movaps xmm1, [rsp]
00007eafdc3d2ace  add rsp, 0x30
00007eafdc3d2ad2  vmovaps xmm0, [rsp]
00007eafdc3d2ad7  vmovaps xmm2, [rsp+0x10]
00007eafdc3d2add  vmovaps xmm3, [rsp+0x20]
00007eafdc3d2ae3  vmovaps xmm4, [rsp+0x30]
00007eafdc3d2ae9  vmovaps xmm5, [rsp+0x40]
00007eafdc3d2aef  vmovaps xmm6, [rsp+0x50]
00007eafdc3d2af5  vmovaps xmm7, [rsp+0x60]
00007eafdc3d2afb  vmovaps xmm8, [rsp+0x70]
00007eafdc3d2b01  vmovaps xmm9, [rsp+0x80]
00007eafdc3d2b0a  vmovaps xmm10, [rsp+0x90]
00007eafdc3d2b13  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d2b1c  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d2b25  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d2b2e  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d2b37  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d2b40  add rsp, 0xF0
00007eafdc3d2b47  pop r11
00007eafdc3d2b49  pop r10
00007eafdc3d2b4b  pop r9
00007eafdc3d2b4d  pop r8
00007eafdc3d2b4f  pop rsi
00007eafdc3d2b50  pop rdi
00007eafdc3d2b51  pop rdx
00007eafdc3d2b52  pop rcx
00007eafdc3d2b53  pop rax
00007eafdc3d2b54  add rsp, 0x08
00007eafdc3d2b58  jmp 0x00007EAFDC3CFDB6
00007eafdc3d2b5d  sub rsp, 0x08
00007eafdc3d2b61  push rax
00007eafdc3d2b62  push rcx
00007eafdc3d2b63  push rdx
00007eafdc3d2b64  push rdi
00007eafdc3d2b65  push rsi
00007eafdc3d2b66  push r8
00007eafdc3d2b68  push r9
00007eafdc3d2b6a  push r10
00007eafdc3d2b6c  push r11
00007eafdc3d2b6e  sub rsp, 0xF0
00007eafdc3d2b75  vmovaps [rsp], xmm0
00007eafdc3d2b7a  vmovaps [rsp+0x10], xmm1
00007eafdc3d2b80  vmovaps [rsp+0x20], xmm2
00007eafdc3d2b86  vmovaps [rsp+0x30], xmm3
00007eafdc3d2b8c  vmovaps [rsp+0x40], xmm4
00007eafdc3d2b92  vmovaps [rsp+0x50], xmm6
00007eafdc3d2b98  vmovaps [rsp+0x60], xmm7
00007eafdc3d2b9e  vmovaps [rsp+0x70], xmm8
00007eafdc3d2ba4  vmovaps [rsp+0x80], xmm9
00007eafdc3d2bad  vmovaps [rsp+0x90], xmm10
00007eafdc3d2bb6  vmovaps [rsp+0xA0], xmm11
00007eafdc3d2bbf  vmovaps [rsp+0xB0], xmm12
00007eafdc3d2bc8  vmovaps [rsp+0xC0], xmm13
00007eafdc3d2bd1  vmovaps [rsp+0xD0], xmm14
00007eafdc3d2bda  vmovaps [rsp+0xE0], xmm15
00007eafdc3d2be3  sub rsp, 0x30
00007eafdc3d2be7  movaps [rsp], xmm5
00007eafdc3d2beb  movaps [rsp+0x10], xmm2
00007eafdc3d2bf0  movaps [rsp+0x20], xmm13
00007eafdc3d2bf6  lea rdi, [rsp]
00007eafdc3d2bfa  mov esi, 0x00
00007eafdc3d2bff  mov rax, 0x645891675530
00007eafdc3d2c09  call rax
00007eafdc3d2c0b  movaps xmm5, [rsp]
00007eafdc3d2c0f  add rsp, 0x30
00007eafdc3d2c13  vmovaps xmm0, [rsp]
00007eafdc3d2c18  vmovaps xmm1, [rsp+0x10]
00007eafdc3d2c1e  vmovaps xmm2, [rsp+0x20]
00007eafdc3d2c24  vmovaps xmm3, [rsp+0x30]
00007eafdc3d2c2a  vmovaps xmm4, [rsp+0x40]
00007eafdc3d2c30  vmovaps xmm6, [rsp+0x50]
00007eafdc3d2c36  vmovaps xmm7, [rsp+0x60]
00007eafdc3d2c3c  vmovaps xmm8, [rsp+0x70]
00007eafdc3d2c42  vmovaps xmm9, [rsp+0x80]
00007eafdc3d2c4b  vmovaps xmm10, [rsp+0x90]
00007eafdc3d2c54  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d2c5d  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d2c66  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d2c6f  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d2c78  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d2c81  add rsp, 0xF0
00007eafdc3d2c88  pop r11
00007eafdc3d2c8a  pop r10
00007eafdc3d2c8c  pop r9
00007eafdc3d2c8e  pop r8
00007eafdc3d2c90  pop rsi
00007eafdc3d2c91  pop rdi
00007eafdc3d2c92  pop rdx
00007eafdc3d2c93  pop rcx
00007eafdc3d2c94  pop rax
00007eafdc3d2c95  add rsp, 0x08
00007eafdc3d2c99  jmp 0x00007EAFDC3CFDEC
00007eafdc3d2c9e  sub rsp, 0x08
00007eafdc3d2ca2  push rax
00007eafdc3d2ca3  push rcx
00007eafdc3d2ca4  push rdx
00007eafdc3d2ca5  push rdi
00007eafdc3d2ca6  push rsi
00007eafdc3d2ca7  push r8
00007eafdc3d2ca9  push r9
00007eafdc3d2cab  push r10
00007eafdc3d2cad  push r11
00007eafdc3d2caf  sub rsp, 0xF0
00007eafdc3d2cb6  vmovaps [rsp], xmm0
00007eafdc3d2cbb  vmovaps [rsp+0x10], xmm1
00007eafdc3d2cc1  vmovaps [rsp+0x20], xmm2
00007eafdc3d2cc7  vmovaps [rsp+0x30], xmm3
00007eafdc3d2ccd  vmovaps [rsp+0x40], xmm4
00007eafdc3d2cd3  vmovaps [rsp+0x50], xmm5
00007eafdc3d2cd9  vmovaps [rsp+0x60], xmm6
00007eafdc3d2cdf  vmovaps [rsp+0x70], xmm7
00007eafdc3d2ce5  vmovaps [rsp+0x80], xmm8
00007eafdc3d2cee  vmovaps [rsp+0x90], xmm9
00007eafdc3d2cf7  vmovaps [rsp+0xA0], xmm10
00007eafdc3d2d00  vmovaps [rsp+0xB0], xmm11
00007eafdc3d2d09  vmovaps [rsp+0xC0], xmm12
00007eafdc3d2d12  vmovaps [rsp+0xD0], xmm14
00007eafdc3d2d1b  vmovaps [rsp+0xE0], xmm15
00007eafdc3d2d24  sub rsp, 0x30
00007eafdc3d2d28  movaps [rsp], xmm13
00007eafdc3d2d2d  movaps [rsp+0x10], xmm10
00007eafdc3d2d33  movaps [rsp+0x20], xmm1
00007eafdc3d2d38  lea rdi, [rsp]
00007eafdc3d2d3c  mov esi, 0x00
00007eafdc3d2d41  mov rax, 0x645891675530
00007eafdc3d2d4b  call rax
00007eafdc3d2d4d  movaps xmm13, [rsp]
00007eafdc3d2d52  add rsp, 0x30
00007eafdc3d2d56  vmovaps xmm0, [rsp]
00007eafdc3d2d5b  vmovaps xmm1, [rsp+0x10]
00007eafdc3d2d61  vmovaps xmm2, [rsp+0x20]
00007eafdc3d2d67  vmovaps xmm3, [rsp+0x30]
00007eafdc3d2d6d  vmovaps xmm4, [rsp+0x40]
00007eafdc3d2d73  vmovaps xmm5, [rsp+0x50]
00007eafdc3d2d79  vmovaps xmm6, [rsp+0x60]
00007eafdc3d2d7f  vmovaps xmm7, [rsp+0x70]
00007eafdc3d2d85  vmovaps xmm8, [rsp+0x80]
00007eafdc3d2d8e  vmovaps xmm9, [rsp+0x90]
00007eafdc3d2d97  vmovaps xmm10, [rsp+0xA0]
00007eafdc3d2da0  vmovaps xmm11, [rsp+0xB0]
00007eafdc3d2da9  vmovaps xmm12, [rsp+0xC0]
00007eafdc3d2db2  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d2dbb  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d2dc4  add rsp, 0xF0
00007eafdc3d2dcb  pop r11
00007eafdc3d2dcd  pop r10
00007eafdc3d2dcf  pop r9
00007eafdc3d2dd1  pop r8
00007eafdc3d2dd3  pop rsi
00007eafdc3d2dd4  pop rdi
00007eafdc3d2dd5  pop rdx
00007eafdc3d2dd6  pop rcx
00007eafdc3d2dd7  pop rax
00007eafdc3d2dd8  add rsp, 0x08
00007eafdc3d2ddc  jmp 0x00007EAFDC3CFE15
00007eafdc3d2de1  sub rsp, 0x08
00007eafdc3d2de5  push rax
00007eafdc3d2de6  push rcx
00007eafdc3d2de7  push rdx
00007eafdc3d2de8  push rdi
00007eafdc3d2de9  push rsi
00007eafdc3d2dea  push r8
00007eafdc3d2dec  push r9
00007eafdc3d2dee  push r10
00007eafdc3d2df0  push r11
00007eafdc3d2df2  sub rsp, 0xF0
00007eafdc3d2df9  vmovaps [rsp], xmm0
00007eafdc3d2dfe  vmovaps [rsp+0x10], xmm2
00007eafdc3d2e04  vmovaps [rsp+0x20], xmm3
00007eafdc3d2e0a  vmovaps [rsp+0x30], xmm4
00007eafdc3d2e10  vmovaps [rsp+0x40], xmm5
00007eafdc3d2e16  vmovaps [rsp+0x50], xmm6
00007eafdc3d2e1c  vmovaps [rsp+0x60], xmm7
00007eafdc3d2e22  vmovaps [rsp+0x70], xmm8
00007eafdc3d2e28  vmovaps [rsp+0x80], xmm9
00007eafdc3d2e31  vmovaps [rsp+0x90], xmm10
00007eafdc3d2e3a  vmovaps [rsp+0xA0], xmm11
00007eafdc3d2e43  vmovaps [rsp+0xB0], xmm12
00007eafdc3d2e4c  vmovaps [rsp+0xC0], xmm13
00007eafdc3d2e55  vmovaps [rsp+0xD0], xmm14
00007eafdc3d2e5e  vmovaps [rsp+0xE0], xmm15
00007eafdc3d2e67  sub rsp, 0x30
00007eafdc3d2e6b  movaps [rsp], xmm1
00007eafdc3d2e6f  movaps [rsp+0x10], xmm15
00007eafdc3d2e75  movaps [rsp+0x20], xmm10
00007eafdc3d2e7b  lea rdi, [rsp]
00007eafdc3d2e7f  mov esi, 0x00
00007eafdc3d2e84  mov rax, 0x645891675530
00007eafdc3d2e8e  call rax
00007eafdc3d2e90  movaps xmm1, [rsp]
00007eafdc3d2e94  add rsp, 0x30
00007eafdc3d2e98  vmovaps xmm0, [rsp]
00007eafdc3d2e9d  vmovaps xmm2, [rsp+0x10]
00007eafdc3d2ea3  vmovaps xmm3, [rsp+0x20]
00007eafdc3d2ea9  vmovaps xmm4, [rsp+0x30]
00007eafdc3d2eaf  vmovaps xmm5, [rsp+0x40]
00007eafdc3d2eb5  vmovaps xmm6, [rsp+0x50]
00007eafdc3d2ebb  vmovaps xmm7, [rsp+0x60]
00007eafdc3d2ec1  vmovaps xmm8, [rsp+0x70]
00007eafdc3d2ec7  vmovaps xmm9, [rsp+0x80]
00007eafdc3d2ed0  vmovaps xmm10, [rsp+0x90]
00007eafdc3d2ed9  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d2ee2  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d2eeb  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d2ef4  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d2efd  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d2f06  add rsp, 0xF0
00007eafdc3d2f0d  pop r11
00007eafdc3d2f0f  pop r10
00007eafdc3d2f11  pop r9
00007eafdc3d2f13  pop r8
00007eafdc3d2f15  pop rsi
00007eafdc3d2f16  pop rdi
00007eafdc3d2f17  pop rdx
00007eafdc3d2f18  pop rcx
00007eafdc3d2f19  pop rax
00007eafdc3d2f1a  add rsp, 0x08
00007eafdc3d2f1e  jmp 0x00007EAFDC3CFE34
00007eafdc3d2f23  sub rsp, 0x08
00007eafdc3d2f27  push rax
00007eafdc3d2f28  push rcx
00007eafdc3d2f29  push rdx
00007eafdc3d2f2a  push rdi
00007eafdc3d2f2b  push rsi
00007eafdc3d2f2c  push r8
00007eafdc3d2f2e  push r9
00007eafdc3d2f30  push r10
00007eafdc3d2f32  push r11
00007eafdc3d2f34  sub rsp, 0xF0
00007eafdc3d2f3b  vmovaps [rsp], xmm0
00007eafdc3d2f40  vmovaps [rsp+0x10], xmm1
00007eafdc3d2f46  vmovaps [rsp+0x20], xmm2
00007eafdc3d2f4c  vmovaps [rsp+0x30], xmm3
00007eafdc3d2f52  vmovaps [rsp+0x40], xmm4
00007eafdc3d2f58  vmovaps [rsp+0x50], xmm5
00007eafdc3d2f5e  vmovaps [rsp+0x60], xmm6
00007eafdc3d2f64  vmovaps [rsp+0x70], xmm7
00007eafdc3d2f6a  vmovaps [rsp+0x80], xmm8
00007eafdc3d2f73  vmovaps [rsp+0x90], xmm9
00007eafdc3d2f7c  vmovaps [rsp+0xA0], xmm10
00007eafdc3d2f85  vmovaps [rsp+0xB0], xmm11
00007eafdc3d2f8e  vmovaps [rsp+0xC0], xmm12
00007eafdc3d2f97  vmovaps [rsp+0xD0], xmm13
00007eafdc3d2fa0  vmovaps [rsp+0xE0], xmm14
00007eafdc3d2fa9  sub rsp, 0x30
00007eafdc3d2fad  movaps [rsp], xmm15
00007eafdc3d2fb2  movaps [rsp+0x10], xmm10
00007eafdc3d2fb8  movaps [rsp+0x20], xmm11
00007eafdc3d2fbe  lea rdi, [rsp]
00007eafdc3d2fc2  mov esi, 0x00
00007eafdc3d2fc7  mov rax, 0x645891675530
00007eafdc3d2fd1  call rax
00007eafdc3d2fd3  movaps xmm15, [rsp]
00007eafdc3d2fd8  add rsp, 0x30
00007eafdc3d2fdc  vmovaps xmm0, [rsp]
00007eafdc3d2fe1  vmovaps xmm1, [rsp+0x10]
00007eafdc3d2fe7  vmovaps xmm2, [rsp+0x20]
00007eafdc3d2fed  vmovaps xmm3, [rsp+0x30]
00007eafdc3d2ff3  vmovaps xmm4, [rsp+0x40]
00007eafdc3d2ff9  vmovaps xmm5, [rsp+0x50]
00007eafdc3d2fff  vmovaps xmm6, [rsp+0x60]
00007eafdc3d3005  vmovaps xmm7, [rsp+0x70]
00007eafdc3d300b  vmovaps xmm8, [rsp+0x80]
00007eafdc3d3014  vmovaps xmm9, [rsp+0x90]
00007eafdc3d301d  vmovaps xmm10, [rsp+0xA0]
00007eafdc3d3026  vmovaps xmm11, [rsp+0xB0]
00007eafdc3d302f  vmovaps xmm12, [rsp+0xC0]
00007eafdc3d3038  vmovaps xmm13, [rsp+0xD0]
00007eafdc3d3041  vmovaps xmm14, [rsp+0xE0]
00007eafdc3d304a  add rsp, 0xF0
00007eafdc3d3051  pop r11
00007eafdc3d3053  pop r10
00007eafdc3d3055  pop r9
00007eafdc3d3057  pop r8
00007eafdc3d3059  pop rsi
00007eafdc3d305a  pop rdi
00007eafdc3d305b  pop rdx
00007eafdc3d305c  pop rcx
00007eafdc3d305d  pop rax
00007eafdc3d305e  add rsp, 0x08
00007eafdc3d3062  jmp 0x00007EAFDC3CFE57
00007eafdc3d3067  sub rsp, 0x08
00007eafdc3d306b  push rax
00007eafdc3d306c  push rcx
00007eafdc3d306d  push rdx
00007eafdc3d306e  push rdi
00007eafdc3d306f  push rsi
00007eafdc3d3070  push r8
00007eafdc3d3072  push r9
00007eafdc3d3074  push r10
00007eafdc3d3076  push r11
00007eafdc3d3078  sub rsp, 0xF0
00007eafdc3d307f  vmovaps [rsp], xmm0
00007eafdc3d3084  vmovaps [rsp+0x10], xmm1
00007eafdc3d308a  vmovaps [rsp+0x20], xmm2
00007eafdc3d3090  vmovaps [rsp+0x30], xmm3
00007eafdc3d3096  vmovaps [rsp+0x40], xmm4
00007eafdc3d309c  vmovaps [rsp+0x50], xmm5
00007eafdc3d30a2  vmovaps [rsp+0x60], xmm6
00007eafdc3d30a8  vmovaps [rsp+0x70], xmm7
00007eafdc3d30ae  vmovaps [rsp+0x80], xmm8
00007eafdc3d30b7  vmovaps [rsp+0x90], xmm9
00007eafdc3d30c0  vmovaps [rsp+0xA0], xmm11
00007eafdc3d30c9  vmovaps [rsp+0xB0], xmm12
00007eafdc3d30d2  vmovaps [rsp+0xC0], xmm13
00007eafdc3d30db  vmovaps [rsp+0xD0], xmm14
00007eafdc3d30e4  vmovaps [rsp+0xE0], xmm15
00007eafdc3d30ed  sub rsp, 0x30
00007eafdc3d30f1  movaps [rsp], xmm10
00007eafdc3d30f6  movaps [rsp+0x10], xmm12
00007eafdc3d30fc  movaps [rsp+0x20], xmm11
00007eafdc3d3102  lea rdi, [rsp]
00007eafdc3d3106  mov esi, 0x00
00007eafdc3d310b  mov rax, 0x645891675530
00007eafdc3d3115  call rax
00007eafdc3d3117  movaps xmm10, [rsp]
00007eafdc3d311c  add rsp, 0x30
00007eafdc3d3120  vmovaps xmm0, [rsp]
00007eafdc3d3125  vmovaps xmm1, [rsp+0x10]
00007eafdc3d312b  vmovaps xmm2, [rsp+0x20]
00007eafdc3d3131  vmovaps xmm3, [rsp+0x30]
00007eafdc3d3137  vmovaps xmm4, [rsp+0x40]
00007eafdc3d313d  vmovaps xmm5, [rsp+0x50]
00007eafdc3d3143  vmovaps xmm6, [rsp+0x60]
00007eafdc3d3149  vmovaps xmm7, [rsp+0x70]
00007eafdc3d314f  vmovaps xmm8, [rsp+0x80]
00007eafdc3d3158  vmovaps xmm9, [rsp+0x90]
00007eafdc3d3161  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d316a  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d3173  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d317c  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d3185  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d318e  add rsp, 0xF0
00007eafdc3d3195  pop r11
00007eafdc3d3197  pop r10
00007eafdc3d3199  pop r9
00007eafdc3d319b  pop r8
00007eafdc3d319d  pop rsi
00007eafdc3d319e  pop rdi
00007eafdc3d319f  pop rdx
00007eafdc3d31a0  pop rcx
00007eafdc3d31a1  pop rax
00007eafdc3d31a2  add rsp, 0x08
00007eafdc3d31a6  jmp 0x00007EAFDC3CFE80
00007eafdc3d31ab  sub rsp, 0x08
00007eafdc3d31af  push rax
00007eafdc3d31b0  push rcx
00007eafdc3d31b1  push rdx
00007eafdc3d31b2  push rdi
00007eafdc3d31b3  push rsi
00007eafdc3d31b4  push r8
00007eafdc3d31b6  push r9
00007eafdc3d31b8  push r10
00007eafdc3d31ba  push r11
00007eafdc3d31bc  sub rsp, 0xF0
00007eafdc3d31c3  vmovaps [rsp], xmm0
00007eafdc3d31c8  vmovaps [rsp+0x10], xmm1
00007eafdc3d31ce  vmovaps [rsp+0x20], xmm2
00007eafdc3d31d4  vmovaps [rsp+0x30], xmm3
00007eafdc3d31da  vmovaps [rsp+0x40], xmm4
00007eafdc3d31e0  vmovaps [rsp+0x50], xmm5
00007eafdc3d31e6  vmovaps [rsp+0x60], xmm6
00007eafdc3d31ec  vmovaps [rsp+0x70], xmm7
00007eafdc3d31f2  vmovaps [rsp+0x80], xmm8
00007eafdc3d31fb  vmovaps [rsp+0x90], xmm9
00007eafdc3d3204  vmovaps [rsp+0xA0], xmm10
00007eafdc3d320d  vmovaps [rsp+0xB0], xmm12
00007eafdc3d3216  vmovaps [rsp+0xC0], xmm13
00007eafdc3d321f  vmovaps [rsp+0xD0], xmm14
00007eafdc3d3228  vmovaps [rsp+0xE0], xmm15
00007eafdc3d3231  sub rsp, 0x30
00007eafdc3d3235  movaps [rsp], xmm11
00007eafdc3d323a  movaps [rsp+0x10], xmm2
00007eafdc3d323f  movaps [rsp+0x20], xmm12
00007eafdc3d3245  lea rdi, [rsp]
00007eafdc3d3249  mov esi, 0x00
00007eafdc3d324e  mov rax, 0x645891675530
00007eafdc3d3258  call rax
00007eafdc3d325a  movaps xmm11, [rsp]
00007eafdc3d325f  add rsp, 0x30
00007eafdc3d3263  vmovaps xmm0, [rsp]
00007eafdc3d3268  vmovaps xmm1, [rsp+0x10]
00007eafdc3d326e  vmovaps xmm2, [rsp+0x20]
00007eafdc3d3274  vmovaps xmm3, [rsp+0x30]
00007eafdc3d327a  vmovaps xmm4, [rsp+0x40]
00007eafdc3d3280  vmovaps xmm5, [rsp+0x50]
00007eafdc3d3286  vmovaps xmm6, [rsp+0x60]
00007eafdc3d328c  vmovaps xmm7, [rsp+0x70]
00007eafdc3d3292  vmovaps xmm8, [rsp+0x80]
00007eafdc3d329b  vmovaps xmm9, [rsp+0x90]
00007eafdc3d32a4  vmovaps xmm10, [rsp+0xA0]
00007eafdc3d32ad  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d32b6  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d32bf  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d32c8  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d32d1  add rsp, 0xF0
00007eafdc3d32d8  pop r11
00007eafdc3d32da  pop r10
00007eafdc3d32dc  pop r9
00007eafdc3d32de  pop r8
00007eafdc3d32e0  pop rsi
00007eafdc3d32e1  pop rdi
00007eafdc3d32e2  pop rdx
00007eafdc3d32e3  pop rcx
00007eafdc3d32e4  pop rax
00007eafdc3d32e5  add rsp, 0x08
00007eafdc3d32e9  jmp 0x00007EAFDC3CFEB8
00007eafdc3d32ee  sub rsp, 0x08
00007eafdc3d32f2  push rax
00007eafdc3d32f3  push rcx
00007eafdc3d32f4  push rdx
00007eafdc3d32f5  push rdi
00007eafdc3d32f6  push rsi
00007eafdc3d32f7  push r8
00007eafdc3d32f9  push r9
00007eafdc3d32fb  push r10
00007eafdc3d32fd  push r11
00007eafdc3d32ff  sub rsp, 0xF0
00007eafdc3d3306  vmovaps [rsp], xmm0
00007eafdc3d330b  vmovaps [rsp+0x10], xmm2
00007eafdc3d3311  vmovaps [rsp+0x20], xmm3
00007eafdc3d3317  vmovaps [rsp+0x30], xmm4
00007eafdc3d331d  vmovaps [rsp+0x40], xmm5
00007eafdc3d3323  vmovaps [rsp+0x50], xmm6
00007eafdc3d3329  vmovaps [rsp+0x60], xmm7
00007eafdc3d332f  vmovaps [rsp+0x70], xmm8
00007eafdc3d3335  vmovaps [rsp+0x80], xmm9
00007eafdc3d333e  vmovaps [rsp+0x90], xmm10
00007eafdc3d3347  vmovaps [rsp+0xA0], xmm11
00007eafdc3d3350  vmovaps [rsp+0xB0], xmm12
00007eafdc3d3359  vmovaps [rsp+0xC0], xmm13
00007eafdc3d3362  vmovaps [rsp+0xD0], xmm14
00007eafdc3d336b  vmovaps [rsp+0xE0], xmm15
00007eafdc3d3374  sub rsp, 0x30
00007eafdc3d3378  movaps [rsp], xmm1
00007eafdc3d337c  movaps [rsp+0x10], xmm14
00007eafdc3d3382  movaps [rsp+0x20], xmm6
00007eafdc3d3387  lea rdi, [rsp]
00007eafdc3d338b  mov esi, 0x00
00007eafdc3d3390  mov rax, 0x645891675530
00007eafdc3d339a  call rax
00007eafdc3d339c  movaps xmm1, [rsp]
00007eafdc3d33a0  add rsp, 0x30
00007eafdc3d33a4  vmovaps xmm0, [rsp]
00007eafdc3d33a9  vmovaps xmm2, [rsp+0x10]
00007eafdc3d33af  vmovaps xmm3, [rsp+0x20]
00007eafdc3d33b5  vmovaps xmm4, [rsp+0x30]
00007eafdc3d33bb  vmovaps xmm5, [rsp+0x40]
00007eafdc3d33c1  vmovaps xmm6, [rsp+0x50]
00007eafdc3d33c7  vmovaps xmm7, [rsp+0x60]
00007eafdc3d33cd  vmovaps xmm8, [rsp+0x70]
00007eafdc3d33d3  vmovaps xmm9, [rsp+0x80]
00007eafdc3d33dc  vmovaps xmm10, [rsp+0x90]
00007eafdc3d33e5  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d33ee  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d33f7  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d3400  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d3409  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d3412  add rsp, 0xF0
00007eafdc3d3419  pop r11
00007eafdc3d341b  pop r10
00007eafdc3d341d  pop r9
00007eafdc3d341f  pop r8
00007eafdc3d3421  pop rsi
00007eafdc3d3422  pop rdi
00007eafdc3d3423  pop rdx
00007eafdc3d3424  pop rcx
00007eafdc3d3425  pop rax
00007eafdc3d3426  add rsp, 0x08
00007eafdc3d342a  jmp 0x00007EAFDC3CFED1
00007eafdc3d342f  sub rsp, 0x08
00007eafdc3d3433  push rax
00007eafdc3d3434  push rcx
00007eafdc3d3435  push rdx
00007eafdc3d3436  push rdi
00007eafdc3d3437  push rsi
00007eafdc3d3438  push r8
00007eafdc3d343a  push r9
00007eafdc3d343c  push r10
00007eafdc3d343e  push r11
00007eafdc3d3440  sub rsp, 0xF0
00007eafdc3d3447  vmovaps [rsp], xmm0
00007eafdc3d344c  vmovaps [rsp+0x10], xmm1
00007eafdc3d3452  vmovaps [rsp+0x20], xmm2
00007eafdc3d3458  vmovaps [rsp+0x30], xmm3
00007eafdc3d345e  vmovaps [rsp+0x40], xmm4
00007eafdc3d3464  vmovaps [rsp+0x50], xmm5
00007eafdc3d346a  vmovaps [rsp+0x60], xmm6
00007eafdc3d3470  vmovaps [rsp+0x70], xmm7
00007eafdc3d3476  vmovaps [rsp+0x80], xmm8
00007eafdc3d347f  vmovaps [rsp+0x90], xmm9
00007eafdc3d3488  vmovaps [rsp+0xA0], xmm10
00007eafdc3d3491  vmovaps [rsp+0xB0], xmm11
00007eafdc3d349a  vmovaps [rsp+0xC0], xmm12
00007eafdc3d34a3  vmovaps [rsp+0xD0], xmm13
00007eafdc3d34ac  vmovaps [rsp+0xE0], xmm15
00007eafdc3d34b5  sub rsp, 0x30
00007eafdc3d34b9  movaps [rsp], xmm14
00007eafdc3d34be  movaps [rsp+0x10], xmm12
00007eafdc3d34c4  movaps [rsp+0x20], xmm5
00007eafdc3d34c9  lea rdi, [rsp]
00007eafdc3d34cd  mov esi, 0x00
00007eafdc3d34d2  mov rax, 0x645891675530
00007eafdc3d34dc  call rax
00007eafdc3d34de  movaps xmm14, [rsp]
00007eafdc3d34e3  add rsp, 0x30
00007eafdc3d34e7  vmovaps xmm0, [rsp]
00007eafdc3d34ec  vmovaps xmm1, [rsp+0x10]
00007eafdc3d34f2  vmovaps xmm2, [rsp+0x20]
00007eafdc3d34f8  vmovaps xmm3, [rsp+0x30]
00007eafdc3d34fe  vmovaps xmm4, [rsp+0x40]
00007eafdc3d3504  vmovaps xmm5, [rsp+0x50]
00007eafdc3d350a  vmovaps xmm6, [rsp+0x60]
00007eafdc3d3510  vmovaps xmm7, [rsp+0x70]
00007eafdc3d3516  vmovaps xmm8, [rsp+0x80]
00007eafdc3d351f  vmovaps xmm9, [rsp+0x90]
00007eafdc3d3528  vmovaps xmm10, [rsp+0xA0]
00007eafdc3d3531  vmovaps xmm11, [rsp+0xB0]
00007eafdc3d353a  vmovaps xmm12, [rsp+0xC0]
00007eafdc3d3543  vmovaps xmm13, [rsp+0xD0]
00007eafdc3d354c  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d3555  add rsp, 0xF0
00007eafdc3d355c  pop r11
00007eafdc3d355e  pop r10
00007eafdc3d3560  pop r9
00007eafdc3d3562  pop r8
00007eafdc3d3564  pop rsi
00007eafdc3d3565  pop rdi
00007eafdc3d3566  pop rdx
00007eafdc3d3567  pop rcx
00007eafdc3d3568  pop rax
00007eafdc3d3569  add rsp, 0x08
00007eafdc3d356d  jmp 0x00007EAFDC3CFEF1
00007eafdc3d3572  sub rsp, 0x08
00007eafdc3d3576  push rax
00007eafdc3d3577  push rcx
00007eafdc3d3578  push rdx
00007eafdc3d3579  push rdi
00007eafdc3d357a  push rsi
00007eafdc3d357b  push r8
00007eafdc3d357d  push r9
00007eafdc3d357f  push r10
00007eafdc3d3581  push r11
00007eafdc3d3583  sub rsp, 0xF0
00007eafdc3d358a  vmovaps [rsp], xmm0
00007eafdc3d358f  vmovaps [rsp+0x10], xmm1
00007eafdc3d3595  vmovaps [rsp+0x20], xmm2
00007eafdc3d359b  vmovaps [rsp+0x30], xmm3
00007eafdc3d35a1  vmovaps [rsp+0x40], xmm4
00007eafdc3d35a7  vmovaps [rsp+0x50], xmm5
00007eafdc3d35ad  vmovaps [rsp+0x60], xmm7
00007eafdc3d35b3  vmovaps [rsp+0x70], xmm8
00007eafdc3d35b9  vmovaps [rsp+0x80], xmm9
00007eafdc3d35c2  vmovaps [rsp+0x90], xmm10
00007eafdc3d35cb  vmovaps [rsp+0xA0], xmm11
00007eafdc3d35d4  vmovaps [rsp+0xB0], xmm12
00007eafdc3d35dd  vmovaps [rsp+0xC0], xmm13
00007eafdc3d35e6  vmovaps [rsp+0xD0], xmm14
00007eafdc3d35ef  vmovaps [rsp+0xE0], xmm15
00007eafdc3d35f8  sub rsp, 0x30
00007eafdc3d35fc  movaps [rsp], xmm6
00007eafdc3d3600  movaps [rsp+0x10], xmm9
00007eafdc3d3606  movaps [rsp+0x20], xmm12
00007eafdc3d360c  lea rdi, [rsp]
00007eafdc3d3610  mov esi, 0x00
00007eafdc3d3615  mov rax, 0x645891675530
00007eafdc3d361f  call rax
00007eafdc3d3621  movaps xmm6, [rsp]
00007eafdc3d3625  add rsp, 0x30
00007eafdc3d3629  vmovaps xmm0, [rsp]
00007eafdc3d362e  vmovaps xmm1, [rsp+0x10]
00007eafdc3d3634  vmovaps xmm2, [rsp+0x20]
00007eafdc3d363a  vmovaps xmm3, [rsp+0x30]
00007eafdc3d3640  vmovaps xmm4, [rsp+0x40]
00007eafdc3d3646  vmovaps xmm5, [rsp+0x50]
00007eafdc3d364c  vmovaps xmm7, [rsp+0x60]
00007eafdc3d3652  vmovaps xmm8, [rsp+0x70]
00007eafdc3d3658  vmovaps xmm9, [rsp+0x80]
00007eafdc3d3661  vmovaps xmm10, [rsp+0x90]
00007eafdc3d366a  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d3673  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d367c  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d3685  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d368e  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d3697  add rsp, 0xF0
00007eafdc3d369e  pop r11
00007eafdc3d36a0  pop r10
00007eafdc3d36a2  pop r9
00007eafdc3d36a4  pop r8
00007eafdc3d36a6  pop rsi
00007eafdc3d36a7  pop rdi
00007eafdc3d36a8  pop rdx
00007eafdc3d36a9  pop rcx
00007eafdc3d36aa  pop rax
00007eafdc3d36ab  add rsp, 0x08
00007eafdc3d36af  jmp 0x00007EAFDC3CFF19
00007eafdc3d36b4  sub rsp, 0x08
00007eafdc3d36b8  push rax
00007eafdc3d36b9  push rcx
00007eafdc3d36ba  push rdx
00007eafdc3d36bb  push rdi
00007eafdc3d36bc  push rsi
00007eafdc3d36bd  push r8
00007eafdc3d36bf  push r9
00007eafdc3d36c1  push r10
00007eafdc3d36c3  push r11
00007eafdc3d36c5  sub rsp, 0xF0
00007eafdc3d36cc  vmovaps [rsp], xmm0
00007eafdc3d36d1  vmovaps [rsp+0x10], xmm1
00007eafdc3d36d7  vmovaps [rsp+0x20], xmm2
00007eafdc3d36dd  vmovaps [rsp+0x30], xmm3
00007eafdc3d36e3  vmovaps [rsp+0x40], xmm4
00007eafdc3d36e9  vmovaps [rsp+0x50], xmm5
00007eafdc3d36ef  vmovaps [rsp+0x60], xmm6
00007eafdc3d36f5  vmovaps [rsp+0x70], xmm7
00007eafdc3d36fb  vmovaps [rsp+0x80], xmm8
00007eafdc3d3704  vmovaps [rsp+0x90], xmm9
00007eafdc3d370d  vmovaps [rsp+0xA0], xmm10
00007eafdc3d3716  vmovaps [rsp+0xB0], xmm11
00007eafdc3d371f  vmovaps [rsp+0xC0], xmm13
00007eafdc3d3728  vmovaps [rsp+0xD0], xmm14
00007eafdc3d3731  vmovaps [rsp+0xE0], xmm15
00007eafdc3d373a  sub rsp, 0x30
00007eafdc3d373e  movaps [rsp], xmm12
00007eafdc3d3743  movaps [rsp+0x10], xmm15
00007eafdc3d3749  movaps [rsp+0x20], xmm13
00007eafdc3d374f  lea rdi, [rsp]
00007eafdc3d3753  mov esi, 0x00
00007eafdc3d3758  mov rax, 0x645891675530
00007eafdc3d3762  call rax
00007eafdc3d3764  movaps xmm12, [rsp]
00007eafdc3d3769  add rsp, 0x30
00007eafdc3d376d  vmovaps xmm0, [rsp]
00007eafdc3d3772  vmovaps xmm1, [rsp+0x10]
00007eafdc3d3778  vmovaps xmm2, [rsp+0x20]
00007eafdc3d377e  vmovaps xmm3, [rsp+0x30]
00007eafdc3d3784  vmovaps xmm4, [rsp+0x40]
00007eafdc3d378a  vmovaps xmm5, [rsp+0x50]
00007eafdc3d3790  vmovaps xmm6, [rsp+0x60]
00007eafdc3d3796  vmovaps xmm7, [rsp+0x70]
00007eafdc3d379c  vmovaps xmm8, [rsp+0x80]
00007eafdc3d37a5  vmovaps xmm9, [rsp+0x90]
00007eafdc3d37ae  vmovaps xmm10, [rsp+0xA0]
00007eafdc3d37b7  vmovaps xmm11, [rsp+0xB0]
00007eafdc3d37c0  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d37c9  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d37d2  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d37db  add rsp, 0xF0
00007eafdc3d37e2  pop r11
00007eafdc3d37e4  pop r10
00007eafdc3d37e6  pop r9
00007eafdc3d37e8  pop r8
00007eafdc3d37ea  pop rsi
00007eafdc3d37eb  pop rdi
00007eafdc3d37ec  pop rdx
00007eafdc3d37ed  pop rcx
00007eafdc3d37ee  pop rax
00007eafdc3d37ef  add rsp, 0x08
00007eafdc3d37f3  jmp 0x00007EAFDC3CFF34
00007eafdc3d37f8  sub rsp, 0x08
00007eafdc3d37fc  push rax
00007eafdc3d37fd  push rcx
00007eafdc3d37fe  push rdx
00007eafdc3d37ff  push rdi
00007eafdc3d3800  push rsi
00007eafdc3d3801  push r8
00007eafdc3d3803  push r9
00007eafdc3d3805  push r10
00007eafdc3d3807  push r11
00007eafdc3d3809  sub rsp, 0xF0
00007eafdc3d3810  vmovaps [rsp], xmm0
00007eafdc3d3815  vmovaps [rsp+0x10], xmm1
00007eafdc3d381b  vmovaps [rsp+0x20], xmm2
00007eafdc3d3821  vmovaps [rsp+0x30], xmm3
00007eafdc3d3827  vmovaps [rsp+0x40], xmm4
00007eafdc3d382d  vmovaps [rsp+0x50], xmm5
00007eafdc3d3833  vmovaps [rsp+0x60], xmm6
00007eafdc3d3839  vmovaps [rsp+0x70], xmm7
00007eafdc3d383f  vmovaps [rsp+0x80], xmm8
00007eafdc3d3848  vmovaps [rsp+0x90], xmm9
00007eafdc3d3851  vmovaps [rsp+0xA0], xmm10
00007eafdc3d385a  vmovaps [rsp+0xB0], xmm11
00007eafdc3d3863  vmovaps [rsp+0xC0], xmm12
00007eafdc3d386c  vmovaps [rsp+0xD0], xmm13
00007eafdc3d3875  vmovaps [rsp+0xE0], xmm14
00007eafdc3d387e  sub rsp, 0x30
00007eafdc3d3882  movaps [rsp], xmm15
00007eafdc3d3887  movaps [rsp+0x10], xmm13
00007eafdc3d388d  movaps [rsp+0x20], xmm10
00007eafdc3d3893  lea rdi, [rsp]
00007eafdc3d3897  mov esi, 0x00
00007eafdc3d389c  mov rax, 0x645891675530
00007eafdc3d38a6  call rax
00007eafdc3d38a8  movaps xmm15, [rsp]
00007eafdc3d38ad  add rsp, 0x30
00007eafdc3d38b1  vmovaps xmm0, [rsp]
00007eafdc3d38b6  vmovaps xmm1, [rsp+0x10]
00007eafdc3d38bc  vmovaps xmm2, [rsp+0x20]
00007eafdc3d38c2  vmovaps xmm3, [rsp+0x30]
00007eafdc3d38c8  vmovaps xmm4, [rsp+0x40]
00007eafdc3d38ce  vmovaps xmm5, [rsp+0x50]
00007eafdc3d38d4  vmovaps xmm6, [rsp+0x60]
00007eafdc3d38da  vmovaps xmm7, [rsp+0x70]
00007eafdc3d38e0  vmovaps xmm8, [rsp+0x80]
00007eafdc3d38e9  vmovaps xmm9, [rsp+0x90]
00007eafdc3d38f2  vmovaps xmm10, [rsp+0xA0]
00007eafdc3d38fb  vmovaps xmm11, [rsp+0xB0]
00007eafdc3d3904  vmovaps xmm12, [rsp+0xC0]
00007eafdc3d390d  vmovaps xmm13, [rsp+0xD0]
00007eafdc3d3916  vmovaps xmm14, [rsp+0xE0]
00007eafdc3d391f  add rsp, 0xF0
00007eafdc3d3926  pop r11
00007eafdc3d3928  pop r10
00007eafdc3d392a  pop r9
00007eafdc3d392c  pop r8
00007eafdc3d392e  pop rsi
00007eafdc3d392f  pop rdi
00007eafdc3d3930  pop rdx
00007eafdc3d3931  pop rcx
00007eafdc3d3932  pop rax
00007eafdc3d3933  add rsp, 0x08
00007eafdc3d3937  jmp 0x00007EAFDC3CFF55
00007eafdc3d393c  call 0x00007EAFDC20C260
00007eafdc3d3941  jmp 0x00007EAFDC3CFFB0
00007eafdc3d3946  sub rsp, 0x08
00007eafdc3d394a  push rax
00007eafdc3d394b  push rcx
00007eafdc3d394c  push rdx
00007eafdc3d394d  push rdi
00007eafdc3d394e  push rsi
00007eafdc3d394f  push r8
00007eafdc3d3951  push r9
00007eafdc3d3953  push r10
00007eafdc3d3955  push r11
00007eafdc3d3957  sub rsp, 0xF0
00007eafdc3d395e  vmovaps [rsp], xmm0
00007eafdc3d3963  vmovaps [rsp+0x10], xmm1
00007eafdc3d3969  vmovaps [rsp+0x20], xmm2
00007eafdc3d396f  vmovaps [rsp+0x30], xmm3
00007eafdc3d3975  vmovaps [rsp+0x40], xmm4
00007eafdc3d397b  vmovaps [rsp+0x50], xmm5
00007eafdc3d3981  vmovaps [rsp+0x60], xmm6
00007eafdc3d3987  vmovaps [rsp+0x70], xmm7
00007eafdc3d398d  vmovaps [rsp+0x80], xmm8
00007eafdc3d3996  vmovaps [rsp+0x90], xmm10
00007eafdc3d399f  vmovaps [rsp+0xA0], xmm11
00007eafdc3d39a8  vmovaps [rsp+0xB0], xmm12
00007eafdc3d39b1  vmovaps [rsp+0xC0], xmm13
00007eafdc3d39ba  vmovaps [rsp+0xD0], xmm14
00007eafdc3d39c3  vmovaps [rsp+0xE0], xmm15
00007eafdc3d39cc  sub rsp, 0x30
00007eafdc3d39d0  movaps [rsp], xmm9
00007eafdc3d39d5  movaps [rsp+0x10], xmm8
00007eafdc3d39db  movaps [rsp+0x20], xmm10
00007eafdc3d39e1  lea rdi, [rsp]
00007eafdc3d39e5  mov esi, 0x00
00007eafdc3d39ea  mov rax, 0x645891675530
00007eafdc3d39f4  call rax
00007eafdc3d39f6  movaps xmm9, [rsp]
00007eafdc3d39fb  add rsp, 0x30
00007eafdc3d39ff  vmovaps xmm0, [rsp]
00007eafdc3d3a04  vmovaps xmm1, [rsp+0x10]
00007eafdc3d3a0a  vmovaps xmm2, [rsp+0x20]
00007eafdc3d3a10  vmovaps xmm3, [rsp+0x30]
00007eafdc3d3a16  vmovaps xmm4, [rsp+0x40]
00007eafdc3d3a1c  vmovaps xmm5, [rsp+0x50]
00007eafdc3d3a22  vmovaps xmm6, [rsp+0x60]
00007eafdc3d3a28  vmovaps xmm7, [rsp+0x70]
00007eafdc3d3a2e  vmovaps xmm8, [rsp+0x80]
00007eafdc3d3a37  vmovaps xmm10, [rsp+0x90]
00007eafdc3d3a40  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d3a49  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d3a52  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d3a5b  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d3a64  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d3a6d  add rsp, 0xF0
00007eafdc3d3a74  pop r11
00007eafdc3d3a76  pop r10
00007eafdc3d3a78  pop r9
00007eafdc3d3a7a  pop r8
00007eafdc3d3a7c  pop rsi
00007eafdc3d3a7d  pop rdi
00007eafdc3d3a7e  pop rdx
00007eafdc3d3a7f  pop rcx
00007eafdc3d3a80  pop rax
00007eafdc3d3a81  add rsp, 0x08
00007eafdc3d3a85  jmp 0x00007EAFDC3CFFE1
00007eafdc3d3a8a  sub rsp, 0x08
00007eafdc3d3a8e  push rax
00007eafdc3d3a8f  push rcx
00007eafdc3d3a90  push rdx
00007eafdc3d3a91  push rdi
00007eafdc3d3a92  push rsi
00007eafdc3d3a93  push r8
00007eafdc3d3a95  push r9
00007eafdc3d3a97  push r10
00007eafdc3d3a99  push r11
00007eafdc3d3a9b  sub rsp, 0xF0
00007eafdc3d3aa2  vmovaps [rsp], xmm0
00007eafdc3d3aa7  vmovaps [rsp+0x10], xmm1
00007eafdc3d3aad  vmovaps [rsp+0x20], xmm2
00007eafdc3d3ab3  vmovaps [rsp+0x30], xmm3
00007eafdc3d3ab9  vmovaps [rsp+0x40], xmm4
00007eafdc3d3abf  vmovaps [rsp+0x50], xmm5
00007eafdc3d3ac5  vmovaps [rsp+0x60], xmm6
00007eafdc3d3acb  vmovaps [rsp+0x70], xmm7
00007eafdc3d3ad1  vmovaps [rsp+0x80], xmm8
00007eafdc3d3ada  vmovaps [rsp+0x90], xmm9
00007eafdc3d3ae3  vmovaps [rsp+0xA0], xmm11
00007eafdc3d3aec  vmovaps [rsp+0xB0], xmm12
00007eafdc3d3af5  vmovaps [rsp+0xC0], xmm13
00007eafdc3d3afe  vmovaps [rsp+0xD0], xmm14
00007eafdc3d3b07  vmovaps [rsp+0xE0], xmm15
00007eafdc3d3b10  sub rsp, 0x30
00007eafdc3d3b14  movaps [rsp], xmm10
00007eafdc3d3b19  movaps [rsp+0x10], xmm1
00007eafdc3d3b1e  movaps [rsp+0x20], xmm11
00007eafdc3d3b24  lea rdi, [rsp]
00007eafdc3d3b28  mov esi, 0x00
00007eafdc3d3b2d  mov rax, 0x645891675530
00007eafdc3d3b37  call rax
00007eafdc3d3b39  movaps xmm10, [rsp]
00007eafdc3d3b3e  add rsp, 0x30
00007eafdc3d3b42  vmovaps xmm0, [rsp]
00007eafdc3d3b47  vmovaps xmm1, [rsp+0x10]
00007eafdc3d3b4d  vmovaps xmm2, [rsp+0x20]
00007eafdc3d3b53  vmovaps xmm3, [rsp+0x30]
00007eafdc3d3b59  vmovaps xmm4, [rsp+0x40]
00007eafdc3d3b5f  vmovaps xmm5, [rsp+0x50]
00007eafdc3d3b65  vmovaps xmm6, [rsp+0x60]
00007eafdc3d3b6b  vmovaps xmm7, [rsp+0x70]
00007eafdc3d3b71  vmovaps xmm8, [rsp+0x80]
00007eafdc3d3b7a  vmovaps xmm9, [rsp+0x90]
00007eafdc3d3b83  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d3b8c  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d3b95  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d3b9e  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d3ba7  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d3bb0  add rsp, 0xF0
00007eafdc3d3bb7  pop r11
00007eafdc3d3bb9  pop r10
00007eafdc3d3bbb  pop r9
00007eafdc3d3bbd  pop r8
00007eafdc3d3bbf  pop rsi
00007eafdc3d3bc0  pop rdi
00007eafdc3d3bc1  pop rdx
00007eafdc3d3bc2  pop rcx
00007eafdc3d3bc3  pop rax
00007eafdc3d3bc4  add rsp, 0x08
00007eafdc3d3bc8  jmp 0x00007EAFDC3CFFFC
00007eafdc3d3bcd  sub rsp, 0x08
00007eafdc3d3bd1  push rax
00007eafdc3d3bd2  push rcx
00007eafdc3d3bd3  push rdx
00007eafdc3d3bd4  push rdi
00007eafdc3d3bd5  push rsi
00007eafdc3d3bd6  push r8
00007eafdc3d3bd8  push r9
00007eafdc3d3bda  push r10
00007eafdc3d3bdc  push r11
00007eafdc3d3bde  sub rsp, 0xF0
00007eafdc3d3be5  vmovaps [rsp], xmm0
00007eafdc3d3bea  vmovaps [rsp+0x10], xmm2
00007eafdc3d3bf0  vmovaps [rsp+0x20], xmm3
00007eafdc3d3bf6  vmovaps [rsp+0x30], xmm4
00007eafdc3d3bfc  vmovaps [rsp+0x40], xmm5
00007eafdc3d3c02  vmovaps [rsp+0x50], xmm6
00007eafdc3d3c08  vmovaps [rsp+0x60], xmm7
00007eafdc3d3c0e  vmovaps [rsp+0x70], xmm8
00007eafdc3d3c14  vmovaps [rsp+0x80], xmm9
00007eafdc3d3c1d  vmovaps [rsp+0x90], xmm10
00007eafdc3d3c26  vmovaps [rsp+0xA0], xmm11
00007eafdc3d3c2f  vmovaps [rsp+0xB0], xmm12
00007eafdc3d3c38  vmovaps [rsp+0xC0], xmm13
00007eafdc3d3c41  vmovaps [rsp+0xD0], xmm14
00007eafdc3d3c4a  vmovaps [rsp+0xE0], xmm15
00007eafdc3d3c53  sub rsp, 0x30
00007eafdc3d3c57  movaps [rsp], xmm1
00007eafdc3d3c5b  movaps [rsp+0x10], xmm14
00007eafdc3d3c61  movaps [rsp+0x20], xmm6
00007eafdc3d3c66  lea rdi, [rsp]
00007eafdc3d3c6a  mov esi, 0x00
00007eafdc3d3c6f  mov rax, 0x645891675530
00007eafdc3d3c79  call rax
00007eafdc3d3c7b  movaps xmm1, [rsp]
00007eafdc3d3c7f  add rsp, 0x30
00007eafdc3d3c83  vmovaps xmm0, [rsp]
00007eafdc3d3c88  vmovaps xmm2, [rsp+0x10]
00007eafdc3d3c8e  vmovaps xmm3, [rsp+0x20]
00007eafdc3d3c94  vmovaps xmm4, [rsp+0x30]
00007eafdc3d3c9a  vmovaps xmm5, [rsp+0x40]
00007eafdc3d3ca0  vmovaps xmm6, [rsp+0x50]
00007eafdc3d3ca6  vmovaps xmm7, [rsp+0x60]
00007eafdc3d3cac  vmovaps xmm8, [rsp+0x70]
00007eafdc3d3cb2  vmovaps xmm9, [rsp+0x80]
00007eafdc3d3cbb  vmovaps xmm10, [rsp+0x90]
00007eafdc3d3cc4  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d3ccd  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d3cd6  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d3cdf  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d3ce8  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d3cf1  add rsp, 0xF0
00007eafdc3d3cf8  pop r11
00007eafdc3d3cfa  pop r10
00007eafdc3d3cfc  pop r9
00007eafdc3d3cfe  pop r8
00007eafdc3d3d00  pop rsi
00007eafdc3d3d01  pop rdi
00007eafdc3d3d02  pop rdx
00007eafdc3d3d03  pop rcx
00007eafdc3d3d04  pop rax
00007eafdc3d3d05  add rsp, 0x08
00007eafdc3d3d09  jmp 0x00007EAFDC3D0015
00007eafdc3d3d0e  sub rsp, 0x08
00007eafdc3d3d12  push rax
00007eafdc3d3d13  push rcx
00007eafdc3d3d14  push rdx
00007eafdc3d3d15  push rdi
00007eafdc3d3d16  push rsi
00007eafdc3d3d17  push r8
00007eafdc3d3d19  push r9
00007eafdc3d3d1b  push r10
00007eafdc3d3d1d  push r11
00007eafdc3d3d1f  sub rsp, 0xF0
00007eafdc3d3d26  vmovaps [rsp], xmm0
00007eafdc3d3d2b  vmovaps [rsp+0x10], xmm1
00007eafdc3d3d31  vmovaps [rsp+0x20], xmm2
00007eafdc3d3d37  vmovaps [rsp+0x30], xmm3
00007eafdc3d3d3d  vmovaps [rsp+0x40], xmm4
00007eafdc3d3d43  vmovaps [rsp+0x50], xmm5
00007eafdc3d3d49  vmovaps [rsp+0x60], xmm6
00007eafdc3d3d4f  vmovaps [rsp+0x70], xmm7
00007eafdc3d3d55  vmovaps [rsp+0x80], xmm8
00007eafdc3d3d5e  vmovaps [rsp+0x90], xmm9
00007eafdc3d3d67  vmovaps [rsp+0xA0], xmm10
00007eafdc3d3d70  vmovaps [rsp+0xB0], xmm12
00007eafdc3d3d79  vmovaps [rsp+0xC0], xmm13
00007eafdc3d3d82  vmovaps [rsp+0xD0], xmm14
00007eafdc3d3d8b  vmovaps [rsp+0xE0], xmm15
00007eafdc3d3d94  sub rsp, 0x30
00007eafdc3d3d98  movaps [rsp], xmm11
00007eafdc3d3d9d  movaps [rsp+0x10], xmm13
00007eafdc3d3da3  movaps [rsp+0x20], xmm14
00007eafdc3d3da9  lea rdi, [rsp]
00007eafdc3d3dad  mov esi, 0x00
00007eafdc3d3db2  mov rax, 0x645891675530
00007eafdc3d3dbc  call rax
00007eafdc3d3dbe  movaps xmm11, [rsp]
00007eafdc3d3dc3  add rsp, 0x30
00007eafdc3d3dc7  vmovaps xmm0, [rsp]
00007eafdc3d3dcc  vmovaps xmm1, [rsp+0x10]
00007eafdc3d3dd2  vmovaps xmm2, [rsp+0x20]
00007eafdc3d3dd8  vmovaps xmm3, [rsp+0x30]
00007eafdc3d3dde  vmovaps xmm4, [rsp+0x40]
00007eafdc3d3de4  vmovaps xmm5, [rsp+0x50]
00007eafdc3d3dea  vmovaps xmm6, [rsp+0x60]
00007eafdc3d3df0  vmovaps xmm7, [rsp+0x70]
00007eafdc3d3df6  vmovaps xmm8, [rsp+0x80]
00007eafdc3d3dff  vmovaps xmm9, [rsp+0x90]
00007eafdc3d3e08  vmovaps xmm10, [rsp+0xA0]
00007eafdc3d3e11  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d3e1a  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d3e23  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d3e2c  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d3e35  add rsp, 0xF0
00007eafdc3d3e3c  pop r11
00007eafdc3d3e3e  pop r10
00007eafdc3d3e40  pop r9
00007eafdc3d3e42  pop r8
00007eafdc3d3e44  pop rsi
00007eafdc3d3e45  pop rdi
00007eafdc3d3e46  pop rdx
00007eafdc3d3e47  pop rcx
00007eafdc3d3e48  pop rax
00007eafdc3d3e49  add rsp, 0x08
00007eafdc3d3e4d  jmp 0x00007EAFDC3D003F
00007eafdc3d3e52  sub rsp, 0x08
00007eafdc3d3e56  push rax
00007eafdc3d3e57  push rcx
00007eafdc3d3e58  push rdx
00007eafdc3d3e59  push rdi
00007eafdc3d3e5a  push rsi
00007eafdc3d3e5b  push r8
00007eafdc3d3e5d  push r9
00007eafdc3d3e5f  push r10
00007eafdc3d3e61  push r11
00007eafdc3d3e63  sub rsp, 0xF0
00007eafdc3d3e6a  vmovaps [rsp], xmm0
00007eafdc3d3e6f  vmovaps [rsp+0x10], xmm1
00007eafdc3d3e75  vmovaps [rsp+0x20], xmm2
00007eafdc3d3e7b  vmovaps [rsp+0x30], xmm3
00007eafdc3d3e81  vmovaps [rsp+0x40], xmm4
00007eafdc3d3e87  vmovaps [rsp+0x50], xmm5
00007eafdc3d3e8d  vmovaps [rsp+0x60], xmm6
00007eafdc3d3e93  vmovaps [rsp+0x70], xmm7
00007eafdc3d3e99  vmovaps [rsp+0x80], xmm8
00007eafdc3d3ea2  vmovaps [rsp+0x90], xmm9
00007eafdc3d3eab  vmovaps [rsp+0xA0], xmm10
00007eafdc3d3eb4  vmovaps [rsp+0xB0], xmm11
00007eafdc3d3ebd  vmovaps [rsp+0xC0], xmm12
00007eafdc3d3ec6  vmovaps [rsp+0xD0], xmm14
00007eafdc3d3ecf  vmovaps [rsp+0xE0], xmm15
00007eafdc3d3ed8  sub rsp, 0x30
00007eafdc3d3edc  movaps [rsp], xmm13
00007eafdc3d3ee1  movaps [rsp+0x10], xmm8
00007eafdc3d3ee7  movaps [rsp+0x20], xmm14
00007eafdc3d3eed  lea rdi, [rsp]
00007eafdc3d3ef1  mov esi, 0x00
00007eafdc3d3ef6  mov rax, 0x645891675530
00007eafdc3d3f00  call rax
00007eafdc3d3f02  movaps xmm13, [rsp]
00007eafdc3d3f07  add rsp, 0x30
00007eafdc3d3f0b  vmovaps xmm0, [rsp]
00007eafdc3d3f10  vmovaps xmm1, [rsp+0x10]
00007eafdc3d3f16  vmovaps xmm2, [rsp+0x20]
00007eafdc3d3f1c  vmovaps xmm3, [rsp+0x30]
00007eafdc3d3f22  vmovaps xmm4, [rsp+0x40]
00007eafdc3d3f28  vmovaps xmm5, [rsp+0x50]
00007eafdc3d3f2e  vmovaps xmm6, [rsp+0x60]
00007eafdc3d3f34  vmovaps xmm7, [rsp+0x70]
00007eafdc3d3f3a  vmovaps xmm8, [rsp+0x80]
00007eafdc3d3f43  vmovaps xmm9, [rsp+0x90]
00007eafdc3d3f4c  vmovaps xmm10, [rsp+0xA0]
00007eafdc3d3f55  vmovaps xmm11, [rsp+0xB0]
00007eafdc3d3f5e  vmovaps xmm12, [rsp+0xC0]
00007eafdc3d3f67  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d3f70  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d3f79  add rsp, 0xF0
00007eafdc3d3f80  pop r11
00007eafdc3d3f82  pop r10
00007eafdc3d3f84  pop r9
00007eafdc3d3f86  pop r8
00007eafdc3d3f88  pop rsi
00007eafdc3d3f89  pop rdi
00007eafdc3d3f8a  pop rdx
00007eafdc3d3f8b  pop rcx
00007eafdc3d3f8c  pop rax
00007eafdc3d3f8d  add rsp, 0x08
00007eafdc3d3f91  jmp 0x00007EAFDC3D006E
00007eafdc3d3f96  sub rsp, 0x08
00007eafdc3d3f9a  push rax
00007eafdc3d3f9b  push rcx
00007eafdc3d3f9c  push rdx
00007eafdc3d3f9d  push rdi
00007eafdc3d3f9e  push rsi
00007eafdc3d3f9f  push r8
00007eafdc3d3fa1  push r9
00007eafdc3d3fa3  push r10
00007eafdc3d3fa5  push r11
00007eafdc3d3fa7  sub rsp, 0xF0
00007eafdc3d3fae  vmovaps [rsp], xmm0
00007eafdc3d3fb3  vmovaps [rsp+0x10], xmm1
00007eafdc3d3fb9  vmovaps [rsp+0x20], xmm2
00007eafdc3d3fbf  vmovaps [rsp+0x30], xmm3
00007eafdc3d3fc5  vmovaps [rsp+0x40], xmm4
00007eafdc3d3fcb  vmovaps [rsp+0x50], xmm5
00007eafdc3d3fd1  vmovaps [rsp+0x60], xmm6
00007eafdc3d3fd7  vmovaps [rsp+0x70], xmm7
00007eafdc3d3fdd  vmovaps [rsp+0x80], xmm9
00007eafdc3d3fe6  vmovaps [rsp+0x90], xmm10
00007eafdc3d3fef  vmovaps [rsp+0xA0], xmm11
00007eafdc3d3ff8  vmovaps [rsp+0xB0], xmm12
00007eafdc3d4001  vmovaps [rsp+0xC0], xmm13
00007eafdc3d400a  vmovaps [rsp+0xD0], xmm14
00007eafdc3d4013  vmovaps [rsp+0xE0], xmm15
00007eafdc3d401c  sub rsp, 0x30
00007eafdc3d4020  movaps [rsp], xmm8
00007eafdc3d4025  movaps [rsp+0x10], xmm7
00007eafdc3d402a  movaps [rsp+0x20], xmm14
00007eafdc3d4030  lea rdi, [rsp]
00007eafdc3d4034  mov esi, 0x00
00007eafdc3d4039  mov rax, 0x645891675530
00007eafdc3d4043  call rax
00007eafdc3d4045  movaps xmm8, [rsp]
00007eafdc3d404a  add rsp, 0x30
00007eafdc3d404e  vmovaps xmm0, [rsp]
00007eafdc3d4053  vmovaps xmm1, [rsp+0x10]
00007eafdc3d4059  vmovaps xmm2, [rsp+0x20]
00007eafdc3d405f  vmovaps xmm3, [rsp+0x30]
00007eafdc3d4065  vmovaps xmm4, [rsp+0x40]
00007eafdc3d406b  vmovaps xmm5, [rsp+0x50]
00007eafdc3d4071  vmovaps xmm6, [rsp+0x60]
00007eafdc3d4077  vmovaps xmm7, [rsp+0x70]
00007eafdc3d407d  vmovaps xmm9, [rsp+0x80]
00007eafdc3d4086  vmovaps xmm10, [rsp+0x90]
00007eafdc3d408f  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d4098  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d40a1  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d40aa  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d40b3  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d40bc  add rsp, 0xF0
00007eafdc3d40c3  pop r11
00007eafdc3d40c5  pop r10
00007eafdc3d40c7  pop r9
00007eafdc3d40c9  pop r8
00007eafdc3d40cb  pop rsi
00007eafdc3d40cc  pop rdi
00007eafdc3d40cd  pop rdx
00007eafdc3d40ce  pop rcx
00007eafdc3d40cf  pop rax
00007eafdc3d40d0  add rsp, 0x08
00007eafdc3d40d4  jmp 0x00007EAFDC3D0094
00007eafdc3d40d9  sub rsp, 0x08
00007eafdc3d40dd  push rax
00007eafdc3d40de  push rcx
00007eafdc3d40df  push rdx
00007eafdc3d40e0  push rdi
00007eafdc3d40e1  push rsi
00007eafdc3d40e2  push r8
00007eafdc3d40e4  push r9
00007eafdc3d40e6  push r10
00007eafdc3d40e8  push r11
00007eafdc3d40ea  sub rsp, 0xF0
00007eafdc3d40f1  vmovaps [rsp], xmm0
00007eafdc3d40f6  vmovaps [rsp+0x10], xmm1
00007eafdc3d40fc  vmovaps [rsp+0x20], xmm2
00007eafdc3d4102  vmovaps [rsp+0x30], xmm3
00007eafdc3d4108  vmovaps [rsp+0x40], xmm4
00007eafdc3d410e  vmovaps [rsp+0x50], xmm5
00007eafdc3d4114  vmovaps [rsp+0x60], xmm6
00007eafdc3d411a  vmovaps [rsp+0x70], xmm7
00007eafdc3d4120  vmovaps [rsp+0x80], xmm8
00007eafdc3d4129  vmovaps [rsp+0x90], xmm9
00007eafdc3d4132  vmovaps [rsp+0xA0], xmm10
00007eafdc3d413b  vmovaps [rsp+0xB0], xmm11
00007eafdc3d4144  vmovaps [rsp+0xC0], xmm12
00007eafdc3d414d  vmovaps [rsp+0xD0], xmm13
00007eafdc3d4156  vmovaps [rsp+0xE0], xmm15
00007eafdc3d415f  sub rsp, 0x30
00007eafdc3d4163  movaps [rsp], xmm14
00007eafdc3d4168  movaps [rsp+0x10], xmm12
00007eafdc3d416e  movaps [rsp+0x20], xmm9
00007eafdc3d4174  lea rdi, [rsp]
00007eafdc3d4178  mov esi, 0x00
00007eafdc3d417d  mov rax, 0x645891675530
00007eafdc3d4187  call rax
00007eafdc3d4189  movaps xmm14, [rsp]
00007eafdc3d418e  add rsp, 0x30
00007eafdc3d4192  vmovaps xmm0, [rsp]
00007eafdc3d4197  vmovaps xmm1, [rsp+0x10]
00007eafdc3d419d  vmovaps xmm2, [rsp+0x20]
00007eafdc3d41a3  vmovaps xmm3, [rsp+0x30]
00007eafdc3d41a9  vmovaps xmm4, [rsp+0x40]
00007eafdc3d41af  vmovaps xmm5, [rsp+0x50]
00007eafdc3d41b5  vmovaps xmm6, [rsp+0x60]
00007eafdc3d41bb  vmovaps xmm7, [rsp+0x70]
00007eafdc3d41c1  vmovaps xmm8, [rsp+0x80]
00007eafdc3d41ca  vmovaps xmm9, [rsp+0x90]
00007eafdc3d41d3  vmovaps xmm10, [rsp+0xA0]
00007eafdc3d41dc  vmovaps xmm11, [rsp+0xB0]
00007eafdc3d41e5  vmovaps xmm12, [rsp+0xC0]
00007eafdc3d41ee  vmovaps xmm13, [rsp+0xD0]
00007eafdc3d41f7  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d4200  add rsp, 0xF0
00007eafdc3d4207  pop r11
00007eafdc3d4209  pop r10
00007eafdc3d420b  pop r9
00007eafdc3d420d  pop r8
00007eafdc3d420f  pop rsi
00007eafdc3d4210  pop rdi
00007eafdc3d4211  pop rdx
00007eafdc3d4212  pop rcx
00007eafdc3d4213  pop rax
00007eafdc3d4214  add rsp, 0x08
00007eafdc3d4218  jmp 0x00007EAFDC3D00AE
00007eafdc3d421d  sub rsp, 0x08
00007eafdc3d4221  push rax
00007eafdc3d4222  push rcx
00007eafdc3d4223  push rdx
00007eafdc3d4224  push rdi
00007eafdc3d4225  push rsi
00007eafdc3d4226  push r8
00007eafdc3d4228  push r9
00007eafdc3d422a  push r10
00007eafdc3d422c  push r11
00007eafdc3d422e  sub rsp, 0xF0
00007eafdc3d4235  vmovaps [rsp], xmm0
00007eafdc3d423a  vmovaps [rsp+0x10], xmm1
00007eafdc3d4240  vmovaps [rsp+0x20], xmm2
00007eafdc3d4246  vmovaps [rsp+0x30], xmm3
00007eafdc3d424c  vmovaps [rsp+0x40], xmm4
00007eafdc3d4252  vmovaps [rsp+0x50], xmm5
00007eafdc3d4258  vmovaps [rsp+0x60], xmm6
00007eafdc3d425e  vmovaps [rsp+0x70], xmm7
00007eafdc3d4264  vmovaps [rsp+0x80], xmm8
00007eafdc3d426d  vmovaps [rsp+0x90], xmm10
00007eafdc3d4276  vmovaps [rsp+0xA0], xmm11
00007eafdc3d427f  vmovaps [rsp+0xB0], xmm12
00007eafdc3d4288  vmovaps [rsp+0xC0], xmm13
00007eafdc3d4291  vmovaps [rsp+0xD0], xmm14
00007eafdc3d429a  vmovaps [rsp+0xE0], xmm15
00007eafdc3d42a3  sub rsp, 0x30
00007eafdc3d42a7  movaps [rsp], xmm9
00007eafdc3d42ac  movaps [rsp+0x10], xmm7
00007eafdc3d42b1  movaps [rsp+0x20], xmm12
00007eafdc3d42b7  lea rdi, [rsp]
00007eafdc3d42bb  mov esi, 0x00
00007eafdc3d42c0  mov rax, 0x645891675530
00007eafdc3d42ca  call rax
00007eafdc3d42cc  movaps xmm9, [rsp]
00007eafdc3d42d1  add rsp, 0x30
00007eafdc3d42d5  vmovaps xmm0, [rsp]
00007eafdc3d42da  vmovaps xmm1, [rsp+0x10]
00007eafdc3d42e0  vmovaps xmm2, [rsp+0x20]
00007eafdc3d42e6  vmovaps xmm3, [rsp+0x30]
00007eafdc3d42ec  vmovaps xmm4, [rsp+0x40]
00007eafdc3d42f2  vmovaps xmm5, [rsp+0x50]
00007eafdc3d42f8  vmovaps xmm6, [rsp+0x60]
00007eafdc3d42fe  vmovaps xmm7, [rsp+0x70]
00007eafdc3d4304  vmovaps xmm8, [rsp+0x80]
00007eafdc3d430d  vmovaps xmm10, [rsp+0x90]
00007eafdc3d4316  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d431f  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d4328  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d4331  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d433a  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d4343  add rsp, 0xF0
00007eafdc3d434a  pop r11
00007eafdc3d434c  pop r10
00007eafdc3d434e  pop r9
00007eafdc3d4350  pop r8
00007eafdc3d4352  pop rsi
00007eafdc3d4353  pop rdi
00007eafdc3d4354  pop rdx
00007eafdc3d4355  pop rcx
00007eafdc3d4356  pop rax
00007eafdc3d4357  add rsp, 0x08
00007eafdc3d435b  jmp 0x00007EAFDC3D00DD
00007eafdc3d4360  sub rsp, 0x08
00007eafdc3d4364  push rax
00007eafdc3d4365  push rcx
00007eafdc3d4366  push rdx
00007eafdc3d4367  push rdi
00007eafdc3d4368  push rsi
00007eafdc3d4369  push r8
00007eafdc3d436b  push r9
00007eafdc3d436d  push r10
00007eafdc3d436f  push r11
00007eafdc3d4371  sub rsp, 0xF0
00007eafdc3d4378  vmovaps [rsp], xmm0
00007eafdc3d437d  vmovaps [rsp+0x10], xmm1
00007eafdc3d4383  vmovaps [rsp+0x20], xmm2
00007eafdc3d4389  vmovaps [rsp+0x30], xmm3
00007eafdc3d438f  vmovaps [rsp+0x40], xmm4
00007eafdc3d4395  vmovaps [rsp+0x50], xmm5
00007eafdc3d439b  vmovaps [rsp+0x60], xmm6
00007eafdc3d43a1  vmovaps [rsp+0x70], xmm7
00007eafdc3d43a7  vmovaps [rsp+0x80], xmm8
00007eafdc3d43b0  vmovaps [rsp+0x90], xmm9
00007eafdc3d43b9  vmovaps [rsp+0xA0], xmm10
00007eafdc3d43c2  vmovaps [rsp+0xB0], xmm11
00007eafdc3d43cb  vmovaps [rsp+0xC0], xmm13
00007eafdc3d43d4  vmovaps [rsp+0xD0], xmm14
00007eafdc3d43dd  vmovaps [rsp+0xE0], xmm15
00007eafdc3d43e6  sub rsp, 0x30
00007eafdc3d43ea  movaps [rsp], xmm12
00007eafdc3d43ef  movaps [rsp+0x10], xmm15
00007eafdc3d43f5  movaps [rsp+0x20], xmm11
00007eafdc3d43fb  lea rdi, [rsp]
00007eafdc3d43ff  mov esi, 0x00
00007eafdc3d4404  mov rax, 0x645891675530
00007eafdc3d440e  call rax
00007eafdc3d4410  movaps xmm12, [rsp]
00007eafdc3d4415  add rsp, 0x30
00007eafdc3d4419  vmovaps xmm0, [rsp]
00007eafdc3d441e  vmovaps xmm1, [rsp+0x10]
00007eafdc3d4424  vmovaps xmm2, [rsp+0x20]
00007eafdc3d442a  vmovaps xmm3, [rsp+0x30]
00007eafdc3d4430  vmovaps xmm4, [rsp+0x40]
00007eafdc3d4436  vmovaps xmm5, [rsp+0x50]
00007eafdc3d443c  vmovaps xmm6, [rsp+0x60]
00007eafdc3d4442  vmovaps xmm7, [rsp+0x70]
00007eafdc3d4448  vmovaps xmm8, [rsp+0x80]
00007eafdc3d4451  vmovaps xmm9, [rsp+0x90]
00007eafdc3d445a  vmovaps xmm10, [rsp+0xA0]
00007eafdc3d4463  vmovaps xmm11, [rsp+0xB0]
00007eafdc3d446c  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d4475  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d447e  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d4487  add rsp, 0xF0
00007eafdc3d448e  pop r11
00007eafdc3d4490  pop r10
00007eafdc3d4492  pop r9
00007eafdc3d4494  pop r8
00007eafdc3d4496  pop rsi
00007eafdc3d4497  pop rdi
00007eafdc3d4498  pop rdx
00007eafdc3d4499  pop rcx
00007eafdc3d449a  pop rax
00007eafdc3d449b  add rsp, 0x08
00007eafdc3d449f  jmp 0x00007EAFDC3D00F7
00007eafdc3d44a4  sub rsp, 0x08
00007eafdc3d44a8  push rax
00007eafdc3d44a9  push rcx
00007eafdc3d44aa  push rdx
00007eafdc3d44ab  push rdi
00007eafdc3d44ac  push rsi
00007eafdc3d44ad  push r8
00007eafdc3d44af  push r9
00007eafdc3d44b1  push r10
00007eafdc3d44b3  push r11
00007eafdc3d44b5  sub rsp, 0xF0
00007eafdc3d44bc  vmovaps [rsp], xmm0
00007eafdc3d44c1  vmovaps [rsp+0x10], xmm1
00007eafdc3d44c7  vmovaps [rsp+0x20], xmm2
00007eafdc3d44cd  vmovaps [rsp+0x30], xmm3
00007eafdc3d44d3  vmovaps [rsp+0x40], xmm4
00007eafdc3d44d9  vmovaps [rsp+0x50], xmm5
00007eafdc3d44df  vmovaps [rsp+0x60], xmm6
00007eafdc3d44e5  vmovaps [rsp+0x70], xmm7
00007eafdc3d44eb  vmovaps [rsp+0x80], xmm8
00007eafdc3d44f4  vmovaps [rsp+0x90], xmm9
00007eafdc3d44fd  vmovaps [rsp+0xA0], xmm10
00007eafdc3d4506  vmovaps [rsp+0xB0], xmm12
00007eafdc3d450f  vmovaps [rsp+0xC0], xmm13
00007eafdc3d4518  vmovaps [rsp+0xD0], xmm14
00007eafdc3d4521  vmovaps [rsp+0xE0], xmm15
00007eafdc3d452a  sub rsp, 0x30
00007eafdc3d452e  movaps [rsp], xmm11
00007eafdc3d4533  movaps [rsp+0x10], xmm7
00007eafdc3d4538  movaps [rsp+0x20], xmm15
00007eafdc3d453e  lea rdi, [rsp]
00007eafdc3d4542  mov esi, 0x00
00007eafdc3d4547  mov rax, 0x645891675530
00007eafdc3d4551  call rax
00007eafdc3d4553  movaps xmm11, [rsp]
00007eafdc3d4558  add rsp, 0x30
00007eafdc3d455c  vmovaps xmm0, [rsp]
00007eafdc3d4561  vmovaps xmm1, [rsp+0x10]
00007eafdc3d4567  vmovaps xmm2, [rsp+0x20]
00007eafdc3d456d  vmovaps xmm3, [rsp+0x30]
00007eafdc3d4573  vmovaps xmm4, [rsp+0x40]
00007eafdc3d4579  vmovaps xmm5, [rsp+0x50]
00007eafdc3d457f  vmovaps xmm6, [rsp+0x60]
00007eafdc3d4585  vmovaps xmm7, [rsp+0x70]
00007eafdc3d458b  vmovaps xmm8, [rsp+0x80]
00007eafdc3d4594  vmovaps xmm9, [rsp+0x90]
00007eafdc3d459d  vmovaps xmm10, [rsp+0xA0]
00007eafdc3d45a6  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d45af  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d45b8  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d45c1  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d45ca  add rsp, 0xF0
00007eafdc3d45d1  pop r11
00007eafdc3d45d3  pop r10
00007eafdc3d45d5  pop r9
00007eafdc3d45d7  pop r8
00007eafdc3d45d9  pop rsi
00007eafdc3d45da  pop rdi
00007eafdc3d45db  pop rdx
00007eafdc3d45dc  pop rcx
00007eafdc3d45dd  pop rax
00007eafdc3d45de  add rsp, 0x08
00007eafdc3d45e2  jmp 0x00007EAFDC3D0123
00007eafdc3d45e7  sub rsp, 0x08
00007eafdc3d45eb  push rax
00007eafdc3d45ec  push rcx
00007eafdc3d45ed  push rdx
00007eafdc3d45ee  push rdi
00007eafdc3d45ef  push rsi
00007eafdc3d45f0  push r8
00007eafdc3d45f2  push r9
00007eafdc3d45f4  push r10
00007eafdc3d45f6  push r11
00007eafdc3d45f8  sub rsp, 0xF0
00007eafdc3d45ff  vmovaps [rsp], xmm0
00007eafdc3d4604  vmovaps [rsp+0x10], xmm1
00007eafdc3d460a  vmovaps [rsp+0x20], xmm2
00007eafdc3d4610  vmovaps [rsp+0x30], xmm3
00007eafdc3d4616  vmovaps [rsp+0x40], xmm4
00007eafdc3d461c  vmovaps [rsp+0x50], xmm5
00007eafdc3d4622  vmovaps [rsp+0x60], xmm6
00007eafdc3d4628  vmovaps [rsp+0x70], xmm7
00007eafdc3d462e  vmovaps [rsp+0x80], xmm8
00007eafdc3d4637  vmovaps [rsp+0x90], xmm9
00007eafdc3d4640  vmovaps [rsp+0xA0], xmm10
00007eafdc3d4649  vmovaps [rsp+0xB0], xmm11
00007eafdc3d4652  vmovaps [rsp+0xC0], xmm12
00007eafdc3d465b  vmovaps [rsp+0xD0], xmm13
00007eafdc3d4664  vmovaps [rsp+0xE0], xmm14
00007eafdc3d466d  sub rsp, 0x30
00007eafdc3d4671  movaps [rsp], xmm15
00007eafdc3d4676  movaps [rsp+0x10], xmm10
00007eafdc3d467c  movaps [rsp+0x20], xmm13
00007eafdc3d4682  lea rdi, [rsp]
00007eafdc3d4686  mov esi, 0x00
00007eafdc3d468b  mov rax, 0x645891675530
00007eafdc3d4695  call rax
00007eafdc3d4697  movaps xmm15, [rsp]
00007eafdc3d469c  add rsp, 0x30
00007eafdc3d46a0  vmovaps xmm0, [rsp]
00007eafdc3d46a5  vmovaps xmm1, [rsp+0x10]
00007eafdc3d46ab  vmovaps xmm2, [rsp+0x20]
00007eafdc3d46b1  vmovaps xmm3, [rsp+0x30]
00007eafdc3d46b7  vmovaps xmm4, [rsp+0x40]
00007eafdc3d46bd  vmovaps xmm5, [rsp+0x50]
00007eafdc3d46c3  vmovaps xmm6, [rsp+0x60]
00007eafdc3d46c9  vmovaps xmm7, [rsp+0x70]
00007eafdc3d46cf  vmovaps xmm8, [rsp+0x80]
00007eafdc3d46d8  vmovaps xmm9, [rsp+0x90]
00007eafdc3d46e1  vmovaps xmm10, [rsp+0xA0]
00007eafdc3d46ea  vmovaps xmm11, [rsp+0xB0]
00007eafdc3d46f3  vmovaps xmm12, [rsp+0xC0]
00007eafdc3d46fc  vmovaps xmm13, [rsp+0xD0]
00007eafdc3d4705  vmovaps xmm14, [rsp+0xE0]
00007eafdc3d470e  add rsp, 0xF0
00007eafdc3d4715  pop r11
00007eafdc3d4717  pop r10
00007eafdc3d4719  pop r9
00007eafdc3d471b  pop r8
00007eafdc3d471d  pop rsi
00007eafdc3d471e  pop rdi
00007eafdc3d471f  pop rdx
00007eafdc3d4720  pop rcx
00007eafdc3d4721  pop rax
00007eafdc3d4722  add rsp, 0x08
00007eafdc3d4726  jmp 0x00007EAFDC3D013D
00007eafdc3d472b  sub rsp, 0x08
00007eafdc3d472f  push rax
00007eafdc3d4730  push rcx
00007eafdc3d4731  push rdx
00007eafdc3d4732  push rdi
00007eafdc3d4733  push rsi
00007eafdc3d4734  push r8
00007eafdc3d4736  push r9
00007eafdc3d4738  push r10
00007eafdc3d473a  push r11
00007eafdc3d473c  sub rsp, 0xF0
00007eafdc3d4743  vmovaps [rsp], xmm0
00007eafdc3d4748  vmovaps [rsp+0x10], xmm1
00007eafdc3d474e  vmovaps [rsp+0x20], xmm2
00007eafdc3d4754  vmovaps [rsp+0x30], xmm3
00007eafdc3d475a  vmovaps [rsp+0x40], xmm4
00007eafdc3d4760  vmovaps [rsp+0x50], xmm5
00007eafdc3d4766  vmovaps [rsp+0x60], xmm6
00007eafdc3d476c  vmovaps [rsp+0x70], xmm7
00007eafdc3d4772  vmovaps [rsp+0x80], xmm8
00007eafdc3d477b  vmovaps [rsp+0x90], xmm9
00007eafdc3d4784  vmovaps [rsp+0xA0], xmm11
00007eafdc3d478d  vmovaps [rsp+0xB0], xmm12
00007eafdc3d4796  vmovaps [rsp+0xC0], xmm13
00007eafdc3d479f  vmovaps [rsp+0xD0], xmm14
00007eafdc3d47a8  vmovaps [rsp+0xE0], xmm15
00007eafdc3d47b1  sub rsp, 0x30
00007eafdc3d47b5  movaps [rsp], xmm10
00007eafdc3d47ba  movaps [rsp+0x10], xmm7
00007eafdc3d47bf  movaps [rsp+0x20], xmm13
00007eafdc3d47c5  lea rdi, [rsp]
00007eafdc3d47c9  mov esi, 0x00
00007eafdc3d47ce  mov rax, 0x645891675530
00007eafdc3d47d8  call rax
00007eafdc3d47da  movaps xmm10, [rsp]
00007eafdc3d47df  add rsp, 0x30
00007eafdc3d47e3  vmovaps xmm0, [rsp]
00007eafdc3d47e8  vmovaps xmm1, [rsp+0x10]
00007eafdc3d47ee  vmovaps xmm2, [rsp+0x20]
00007eafdc3d47f4  vmovaps xmm3, [rsp+0x30]
00007eafdc3d47fa  vmovaps xmm4, [rsp+0x40]
00007eafdc3d4800  vmovaps xmm5, [rsp+0x50]
00007eafdc3d4806  vmovaps xmm6, [rsp+0x60]
00007eafdc3d480c  vmovaps xmm7, [rsp+0x70]
00007eafdc3d4812  vmovaps xmm8, [rsp+0x80]
00007eafdc3d481b  vmovaps xmm9, [rsp+0x90]
00007eafdc3d4824  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d482d  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d4836  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d483f  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d4848  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d4851  add rsp, 0xF0
00007eafdc3d4858  pop r11
00007eafdc3d485a  pop r10
00007eafdc3d485c  pop r9
00007eafdc3d485e  pop r8
00007eafdc3d4860  pop rsi
00007eafdc3d4861  pop rdi
00007eafdc3d4862  pop rdx
00007eafdc3d4863  pop rcx
00007eafdc3d4864  pop rax
00007eafdc3d4865  add rsp, 0x08
00007eafdc3d4869  jmp 0x00007EAFDC3D0169
00007eafdc3d486e  sub rsp, 0x08
00007eafdc3d4872  push rax
00007eafdc3d4873  push rcx
00007eafdc3d4874  push rdx
00007eafdc3d4875  push rdi
00007eafdc3d4876  push rsi
00007eafdc3d4877  push r8
00007eafdc3d4879  push r9
00007eafdc3d487b  push r10
00007eafdc3d487d  push r11
00007eafdc3d487f  sub rsp, 0xF0
00007eafdc3d4886  vmovaps [rsp], xmm0
00007eafdc3d488b  vmovaps [rsp+0x10], xmm1
00007eafdc3d4891  vmovaps [rsp+0x20], xmm2
00007eafdc3d4897  vmovaps [rsp+0x30], xmm3
00007eafdc3d489d  vmovaps [rsp+0x40], xmm4
00007eafdc3d48a3  vmovaps [rsp+0x50], xmm5
00007eafdc3d48a9  vmovaps [rsp+0x60], xmm6
00007eafdc3d48af  vmovaps [rsp+0x70], xmm7
00007eafdc3d48b5  vmovaps [rsp+0x80], xmm8
00007eafdc3d48be  vmovaps [rsp+0x90], xmm9
00007eafdc3d48c7  vmovaps [rsp+0xA0], xmm10
00007eafdc3d48d0  vmovaps [rsp+0xB0], xmm11
00007eafdc3d48d9  vmovaps [rsp+0xC0], xmm12
00007eafdc3d48e2  vmovaps [rsp+0xD0], xmm14
00007eafdc3d48eb  vmovaps [rsp+0xE0], xmm15
00007eafdc3d48f4  sub rsp, 0x30
00007eafdc3d48f8  movaps [rsp], xmm13
00007eafdc3d48fd  movaps [rsp+0x10], xmm1
00007eafdc3d4902  movaps [rsp+0x20], xmm8
00007eafdc3d4908  lea rdi, [rsp]
00007eafdc3d490c  mov esi, 0x00
00007eafdc3d4911  mov rax, 0x645891675530
00007eafdc3d491b  call rax
00007eafdc3d491d  movaps xmm13, [rsp]
00007eafdc3d4922  add rsp, 0x30
00007eafdc3d4926  vmovaps xmm0, [rsp]
00007eafdc3d492b  vmovaps xmm1, [rsp+0x10]
00007eafdc3d4931  vmovaps xmm2, [rsp+0x20]
00007eafdc3d4937  vmovaps xmm3, [rsp+0x30]
00007eafdc3d493d  vmovaps xmm4, [rsp+0x40]
00007eafdc3d4943  vmovaps xmm5, [rsp+0x50]
00007eafdc3d4949  vmovaps xmm6, [rsp+0x60]
00007eafdc3d494f  vmovaps xmm7, [rsp+0x70]
00007eafdc3d4955  vmovaps xmm8, [rsp+0x80]
00007eafdc3d495e  vmovaps xmm9, [rsp+0x90]
00007eafdc3d4967  vmovaps xmm10, [rsp+0xA0]
00007eafdc3d4970  vmovaps xmm11, [rsp+0xB0]
00007eafdc3d4979  vmovaps xmm12, [rsp+0xC0]
00007eafdc3d4982  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d498b  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d4994  add rsp, 0xF0
00007eafdc3d499b  pop r11
00007eafdc3d499d  pop r10
00007eafdc3d499f  pop r9
00007eafdc3d49a1  pop r8
00007eafdc3d49a3  pop rsi
00007eafdc3d49a4  pop rdi
00007eafdc3d49a5  pop rdx
00007eafdc3d49a6  pop rcx
00007eafdc3d49a7  pop rax
00007eafdc3d49a8  add rsp, 0x08
00007eafdc3d49ac  jmp 0x00007EAFDC3D0183
00007eafdc3d49b1  call 0x00007EAFDC1FF430
00007eafdc3d49b6  jmp 0x00007EAFDC3D018D
00007eafdc3d49bb  sub rsp, 0x08
00007eafdc3d49bf  push rax
00007eafdc3d49c0  push rcx
00007eafdc3d49c1  push rdx
00007eafdc3d49c2  push rdi
00007eafdc3d49c3  push rsi
00007eafdc3d49c4  push r8
00007eafdc3d49c6  push r9
00007eafdc3d49c8  push r10
00007eafdc3d49ca  push r11
00007eafdc3d49cc  sub rsp, 0xF0
00007eafdc3d49d3  vmovaps [rsp], xmm0
00007eafdc3d49d8  vmovaps [rsp+0x10], xmm1
00007eafdc3d49de  vmovaps [rsp+0x20], xmm2
00007eafdc3d49e4  vmovaps [rsp+0x30], xmm3
00007eafdc3d49ea  vmovaps [rsp+0x40], xmm4
00007eafdc3d49f0  vmovaps [rsp+0x50], xmm5
00007eafdc3d49f6  vmovaps [rsp+0x60], xmm6
00007eafdc3d49fc  vmovaps [rsp+0x70], xmm7
00007eafdc3d4a02  vmovaps [rsp+0x80], xmm9
00007eafdc3d4a0b  vmovaps [rsp+0x90], xmm10
00007eafdc3d4a14  vmovaps [rsp+0xA0], xmm11
00007eafdc3d4a1d  vmovaps [rsp+0xB0], xmm12
00007eafdc3d4a26  vmovaps [rsp+0xC0], xmm13
00007eafdc3d4a2f  vmovaps [rsp+0xD0], xmm14
00007eafdc3d4a38  vmovaps [rsp+0xE0], xmm15
00007eafdc3d4a41  sub rsp, 0x30
00007eafdc3d4a45  movaps [rsp], xmm8
00007eafdc3d4a4a  movaps [rsp+0x10], xmm14
00007eafdc3d4a50  movaps [rsp+0x20], xmm9
00007eafdc3d4a56  lea rdi, [rsp]
00007eafdc3d4a5a  mov esi, 0x00
00007eafdc3d4a5f  mov rax, 0x645891675530
00007eafdc3d4a69  call rax
00007eafdc3d4a6b  movaps xmm8, [rsp]
00007eafdc3d4a70  add rsp, 0x30
00007eafdc3d4a74  vmovaps xmm0, [rsp]
00007eafdc3d4a79  vmovaps xmm1, [rsp+0x10]
00007eafdc3d4a7f  vmovaps xmm2, [rsp+0x20]
00007eafdc3d4a85  vmovaps xmm3, [rsp+0x30]
00007eafdc3d4a8b  vmovaps xmm4, [rsp+0x40]
00007eafdc3d4a91  vmovaps xmm5, [rsp+0x50]
00007eafdc3d4a97  vmovaps xmm6, [rsp+0x60]
00007eafdc3d4a9d  vmovaps xmm7, [rsp+0x70]
00007eafdc3d4aa3  vmovaps xmm9, [rsp+0x80]
00007eafdc3d4aac  vmovaps xmm10, [rsp+0x90]
00007eafdc3d4ab5  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d4abe  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d4ac7  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d4ad0  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d4ad9  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d4ae2  add rsp, 0xF0
00007eafdc3d4ae9  pop r11
00007eafdc3d4aeb  pop r10
00007eafdc3d4aed  pop r9
00007eafdc3d4aef  pop r8
00007eafdc3d4af1  pop rsi
00007eafdc3d4af2  pop rdi
00007eafdc3d4af3  pop rdx
00007eafdc3d4af4  pop rcx
00007eafdc3d4af5  pop rax
00007eafdc3d4af6  add rsp, 0x08
00007eafdc3d4afa  jmp 0x00007EAFDC3D01AF
00007eafdc3d4aff  sub rsp, 0x08
00007eafdc3d4b03  push rax
00007eafdc3d4b04  push rcx
00007eafdc3d4b05  push rdx
00007eafdc3d4b06  push rdi
00007eafdc3d4b07  push rsi
00007eafdc3d4b08  push r8
00007eafdc3d4b0a  push r9
00007eafdc3d4b0c  push r10
00007eafdc3d4b0e  push r11
00007eafdc3d4b10  sub rsp, 0xF0
00007eafdc3d4b17  vmovaps [rsp], xmm0
00007eafdc3d4b1c  vmovaps [rsp+0x10], xmm1
00007eafdc3d4b22  vmovaps [rsp+0x20], xmm2
00007eafdc3d4b28  vmovaps [rsp+0x30], xmm3
00007eafdc3d4b2e  vmovaps [rsp+0x40], xmm4
00007eafdc3d4b34  vmovaps [rsp+0x50], xmm5
00007eafdc3d4b3a  vmovaps [rsp+0x60], xmm6
00007eafdc3d4b40  vmovaps [rsp+0x70], xmm7
00007eafdc3d4b46  vmovaps [rsp+0x80], xmm8
00007eafdc3d4b4f  vmovaps [rsp+0x90], xmm10
00007eafdc3d4b58  vmovaps [rsp+0xA0], xmm11
00007eafdc3d4b61  vmovaps [rsp+0xB0], xmm12
00007eafdc3d4b6a  vmovaps [rsp+0xC0], xmm13
00007eafdc3d4b73  vmovaps [rsp+0xD0], xmm14
00007eafdc3d4b7c  vmovaps [rsp+0xE0], xmm15
00007eafdc3d4b85  sub rsp, 0x30
00007eafdc3d4b89  movaps [rsp], xmm9
00007eafdc3d4b8e  movaps [rsp+0x10], xmm1
00007eafdc3d4b93  movaps [rsp+0x20], xmm14
00007eafdc3d4b99  lea rdi, [rsp]
00007eafdc3d4b9d  mov esi, 0x00
00007eafdc3d4ba2  mov rax, 0x645891675530
00007eafdc3d4bac  call rax
00007eafdc3d4bae  movaps xmm9, [rsp]
00007eafdc3d4bb3  add rsp, 0x30
00007eafdc3d4bb7  vmovaps xmm0, [rsp]
00007eafdc3d4bbc  vmovaps xmm1, [rsp+0x10]
00007eafdc3d4bc2  vmovaps xmm2, [rsp+0x20]
00007eafdc3d4bc8  vmovaps xmm3, [rsp+0x30]
00007eafdc3d4bce  vmovaps xmm4, [rsp+0x40]
00007eafdc3d4bd4  vmovaps xmm5, [rsp+0x50]
00007eafdc3d4bda  vmovaps xmm6, [rsp+0x60]
00007eafdc3d4be0  vmovaps xmm7, [rsp+0x70]
00007eafdc3d4be6  vmovaps xmm8, [rsp+0x80]
00007eafdc3d4bef  vmovaps xmm10, [rsp+0x90]
00007eafdc3d4bf8  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d4c01  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d4c0a  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d4c13  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d4c1c  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d4c25  add rsp, 0xF0
00007eafdc3d4c2c  pop r11
00007eafdc3d4c2e  pop r10
00007eafdc3d4c30  pop r9
00007eafdc3d4c32  pop r8
00007eafdc3d4c34  pop rsi
00007eafdc3d4c35  pop rdi
00007eafdc3d4c36  pop rdx
00007eafdc3d4c37  pop rcx
00007eafdc3d4c38  pop rax
00007eafdc3d4c39  add rsp, 0x08
00007eafdc3d4c3d  jmp 0x00007EAFDC3D01DD
00007eafdc3d4c42  sub rsp, 0x08
00007eafdc3d4c46  push rax
00007eafdc3d4c47  push rcx
00007eafdc3d4c48  push rdx
00007eafdc3d4c49  push rdi
00007eafdc3d4c4a  push rsi
00007eafdc3d4c4b  push r8
00007eafdc3d4c4d  push r9
00007eafdc3d4c4f  push r10
00007eafdc3d4c51  push r11
00007eafdc3d4c53  sub rsp, 0xF0
00007eafdc3d4c5a  vmovaps [rsp], xmm0
00007eafdc3d4c5f  vmovaps [rsp+0x10], xmm1
00007eafdc3d4c65  vmovaps [rsp+0x20], xmm2
00007eafdc3d4c6b  vmovaps [rsp+0x30], xmm3
00007eafdc3d4c71  vmovaps [rsp+0x40], xmm4
00007eafdc3d4c77  vmovaps [rsp+0x50], xmm5
00007eafdc3d4c7d  vmovaps [rsp+0x60], xmm6
00007eafdc3d4c83  vmovaps [rsp+0x70], xmm7
00007eafdc3d4c89  vmovaps [rsp+0x80], xmm8
00007eafdc3d4c92  vmovaps [rsp+0x90], xmm9
00007eafdc3d4c9b  vmovaps [rsp+0xA0], xmm10
00007eafdc3d4ca4  vmovaps [rsp+0xB0], xmm11
00007eafdc3d4cad  vmovaps [rsp+0xC0], xmm12
00007eafdc3d4cb6  vmovaps [rsp+0xD0], xmm13
00007eafdc3d4cbf  vmovaps [rsp+0xE0], xmm15
00007eafdc3d4cc8  sub rsp, 0x30
00007eafdc3d4ccc  movaps [rsp], xmm14
00007eafdc3d4cd1  movaps [rsp+0x10], xmm4
00007eafdc3d4cd6  movaps [rsp+0x20], xmm1
00007eafdc3d4cdb  lea rdi, [rsp]
00007eafdc3d4cdf  mov esi, 0x00
00007eafdc3d4ce4  mov rax, 0x645891675530
00007eafdc3d4cee  call rax
00007eafdc3d4cf0  movaps xmm14, [rsp]
00007eafdc3d4cf5  add rsp, 0x30
00007eafdc3d4cf9  vmovaps xmm0, [rsp]
00007eafdc3d4cfe  vmovaps xmm1, [rsp+0x10]
00007eafdc3d4d04  vmovaps xmm2, [rsp+0x20]
00007eafdc3d4d0a  vmovaps xmm3, [rsp+0x30]
00007eafdc3d4d10  vmovaps xmm4, [rsp+0x40]
00007eafdc3d4d16  vmovaps xmm5, [rsp+0x50]
00007eafdc3d4d1c  vmovaps xmm6, [rsp+0x60]
00007eafdc3d4d22  vmovaps xmm7, [rsp+0x70]
00007eafdc3d4d28  vmovaps xmm8, [rsp+0x80]
00007eafdc3d4d31  vmovaps xmm9, [rsp+0x90]
00007eafdc3d4d3a  vmovaps xmm10, [rsp+0xA0]
00007eafdc3d4d43  vmovaps xmm11, [rsp+0xB0]
00007eafdc3d4d4c  vmovaps xmm12, [rsp+0xC0]
00007eafdc3d4d55  vmovaps xmm13, [rsp+0xD0]
00007eafdc3d4d5e  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d4d67  add rsp, 0xF0
00007eafdc3d4d6e  pop r11
00007eafdc3d4d70  pop r10
00007eafdc3d4d72  pop r9
00007eafdc3d4d74  pop r8
00007eafdc3d4d76  pop rsi
00007eafdc3d4d77  pop rdi
00007eafdc3d4d78  pop rdx
00007eafdc3d4d79  pop rcx
00007eafdc3d4d7a  pop rax
00007eafdc3d4d7b  add rsp, 0x08
00007eafdc3d4d7f  jmp 0x00007EAFDC3D0203
00007eafdc3d4d84  sub rsp, 0x08
00007eafdc3d4d88  push rax
00007eafdc3d4d89  push rcx
00007eafdc3d4d8a  push rdx
00007eafdc3d4d8b  push rdi
00007eafdc3d4d8c  push rsi
00007eafdc3d4d8d  push r8
00007eafdc3d4d8f  push r9
00007eafdc3d4d91  push r10
00007eafdc3d4d93  push r11
00007eafdc3d4d95  sub rsp, 0xF0
00007eafdc3d4d9c  vmovaps [rsp], xmm0
00007eafdc3d4da1  vmovaps [rsp+0x10], xmm2
00007eafdc3d4da7  vmovaps [rsp+0x20], xmm3
00007eafdc3d4dad  vmovaps [rsp+0x30], xmm4
00007eafdc3d4db3  vmovaps [rsp+0x40], xmm5
00007eafdc3d4db9  vmovaps [rsp+0x50], xmm6
00007eafdc3d4dbf  vmovaps [rsp+0x60], xmm7
00007eafdc3d4dc5  vmovaps [rsp+0x70], xmm8
00007eafdc3d4dcb  vmovaps [rsp+0x80], xmm9
00007eafdc3d4dd4  vmovaps [rsp+0x90], xmm10
00007eafdc3d4ddd  vmovaps [rsp+0xA0], xmm11
00007eafdc3d4de6  vmovaps [rsp+0xB0], xmm12
00007eafdc3d4def  vmovaps [rsp+0xC0], xmm13
00007eafdc3d4df8  vmovaps [rsp+0xD0], xmm14
00007eafdc3d4e01  vmovaps [rsp+0xE0], xmm15
00007eafdc3d4e0a  sub rsp, 0x30
00007eafdc3d4e0e  movaps [rsp], xmm1
00007eafdc3d4e12  movaps [rsp+0x10], xmm12
00007eafdc3d4e18  movaps [rsp+0x20], xmm11
00007eafdc3d4e1e  lea rdi, [rsp]
00007eafdc3d4e22  mov esi, 0x00
00007eafdc3d4e27  mov rax, 0x645891675530
00007eafdc3d4e31  call rax
00007eafdc3d4e33  movaps xmm1, [rsp]
00007eafdc3d4e37  add rsp, 0x30
00007eafdc3d4e3b  vmovaps xmm0, [rsp]
00007eafdc3d4e40  vmovaps xmm2, [rsp+0x10]
00007eafdc3d4e46  vmovaps xmm3, [rsp+0x20]
00007eafdc3d4e4c  vmovaps xmm4, [rsp+0x30]
00007eafdc3d4e52  vmovaps xmm5, [rsp+0x40]
00007eafdc3d4e58  vmovaps xmm6, [rsp+0x50]
00007eafdc3d4e5e  vmovaps xmm7, [rsp+0x60]
00007eafdc3d4e64  vmovaps xmm8, [rsp+0x70]
00007eafdc3d4e6a  vmovaps xmm9, [rsp+0x80]
00007eafdc3d4e73  vmovaps xmm10, [rsp+0x90]
00007eafdc3d4e7c  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d4e85  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d4e8e  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d4e97  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d4ea0  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d4ea9  add rsp, 0xF0
00007eafdc3d4eb0  pop r11
00007eafdc3d4eb2  pop r10
00007eafdc3d4eb4  pop r9
00007eafdc3d4eb6  pop r8
00007eafdc3d4eb8  pop rsi
00007eafdc3d4eb9  pop rdi
00007eafdc3d4eba  pop rdx
00007eafdc3d4ebb  pop rcx
00007eafdc3d4ebc  pop rax
00007eafdc3d4ebd  add rsp, 0x08
00007eafdc3d4ec1  jmp 0x00007EAFDC3D0224
00007eafdc3d4ec6  call 0x00007EAFDC2E20A0
00007eafdc3d4ecb  jmp 0x00007EAFDC3D0232
00007eafdc3d4ed0  call 0x00007EAFDC209D70
00007eafdc3d4ed5  jmp 0x00007EAFDC3D023C
00007eafdc3d4eda  sub rsp, 0x08
00007eafdc3d4ede  push rax
00007eafdc3d4edf  push rcx
00007eafdc3d4ee0  push rdx
00007eafdc3d4ee1  push rdi
00007eafdc3d4ee2  push rsi
00007eafdc3d4ee3  push r8
00007eafdc3d4ee5  push r9
00007eafdc3d4ee7  push r10
00007eafdc3d4ee9  push r11
00007eafdc3d4eeb  sub rsp, 0xF0
00007eafdc3d4ef2  vmovaps [rsp], xmm0
00007eafdc3d4ef7  vmovaps [rsp+0x10], xmm1
00007eafdc3d4efd  vmovaps [rsp+0x20], xmm2
00007eafdc3d4f03  vmovaps [rsp+0x30], xmm3
00007eafdc3d4f09  vmovaps [rsp+0x40], xmm4
00007eafdc3d4f0f  vmovaps [rsp+0x50], xmm5
00007eafdc3d4f15  vmovaps [rsp+0x60], xmm6
00007eafdc3d4f1b  vmovaps [rsp+0x70], xmm8
00007eafdc3d4f21  vmovaps [rsp+0x80], xmm9
00007eafdc3d4f2a  vmovaps [rsp+0x90], xmm10
00007eafdc3d4f33  vmovaps [rsp+0xA0], xmm11
00007eafdc3d4f3c  vmovaps [rsp+0xB0], xmm12
00007eafdc3d4f45  vmovaps [rsp+0xC0], xmm13
00007eafdc3d4f4e  vmovaps [rsp+0xD0], xmm14
00007eafdc3d4f57  vmovaps [rsp+0xE0], xmm15
00007eafdc3d4f60  sub rsp, 0x30
00007eafdc3d4f64  movaps [rsp], xmm7
00007eafdc3d4f68  movaps [rsp+0x10], xmm15
00007eafdc3d4f6e  movaps [rsp+0x20], xmm10
00007eafdc3d4f74  lea rdi, [rsp]
00007eafdc3d4f78  mov esi, 0x00
00007eafdc3d4f7d  mov rax, 0x645891675530
00007eafdc3d4f87  call rax
00007eafdc3d4f89  movaps xmm7, [rsp]
00007eafdc3d4f8d  add rsp, 0x30
00007eafdc3d4f91  vmovaps xmm0, [rsp]
00007eafdc3d4f96  vmovaps xmm1, [rsp+0x10]
00007eafdc3d4f9c  vmovaps xmm2, [rsp+0x20]
00007eafdc3d4fa2  vmovaps xmm3, [rsp+0x30]
00007eafdc3d4fa8  vmovaps xmm4, [rsp+0x40]
00007eafdc3d4fae  vmovaps xmm5, [rsp+0x50]
00007eafdc3d4fb4  vmovaps xmm6, [rsp+0x60]
00007eafdc3d4fba  vmovaps xmm8, [rsp+0x70]
00007eafdc3d4fc0  vmovaps xmm9, [rsp+0x80]
00007eafdc3d4fc9  vmovaps xmm10, [rsp+0x90]
00007eafdc3d4fd2  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d4fdb  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d4fe4  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d4fed  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d4ff6  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d4fff  add rsp, 0xF0
00007eafdc3d5006  pop r11
00007eafdc3d5008  pop r10
00007eafdc3d500a  pop r9
00007eafdc3d500c  pop r8
00007eafdc3d500e  pop rsi
00007eafdc3d500f  pop rdi
00007eafdc3d5010  pop rdx
00007eafdc3d5011  pop rcx
00007eafdc3d5012  pop rax
00007eafdc3d5013  add rsp, 0x08
00007eafdc3d5017  jmp 0x00007EAFDC3D025D
00007eafdc3d501c  sub rsp, 0x08
00007eafdc3d5020  push rax
00007eafdc3d5021  push rcx
00007eafdc3d5022  push rdx
00007eafdc3d5023  push rdi
00007eafdc3d5024  push rsi
00007eafdc3d5025  push r8
00007eafdc3d5027  push r9
00007eafdc3d5029  push r10
00007eafdc3d502b  push r11
00007eafdc3d502d  sub rsp, 0xF0
00007eafdc3d5034  vmovaps [rsp], xmm0
00007eafdc3d5039  vmovaps [rsp+0x10], xmm1
00007eafdc3d503f  vmovaps [rsp+0x20], xmm2
00007eafdc3d5045  vmovaps [rsp+0x30], xmm3
00007eafdc3d504b  vmovaps [rsp+0x40], xmm4
00007eafdc3d5051  vmovaps [rsp+0x50], xmm5
00007eafdc3d5057  vmovaps [rsp+0x60], xmm6
00007eafdc3d505d  vmovaps [rsp+0x70], xmm7
00007eafdc3d5063  vmovaps [rsp+0x80], xmm8
00007eafdc3d506c  vmovaps [rsp+0x90], xmm9
00007eafdc3d5075  vmovaps [rsp+0xA0], xmm11
00007eafdc3d507e  vmovaps [rsp+0xB0], xmm12
00007eafdc3d5087  vmovaps [rsp+0xC0], xmm13
00007eafdc3d5090  vmovaps [rsp+0xD0], xmm14
00007eafdc3d5099  vmovaps [rsp+0xE0], xmm15
00007eafdc3d50a2  sub rsp, 0x30
00007eafdc3d50a6  movaps [rsp], xmm10
00007eafdc3d50ab  movaps [rsp+0x10], xmm11
00007eafdc3d50b1  movaps [rsp+0x20], xmm15
00007eafdc3d50b7  lea rdi, [rsp]
00007eafdc3d50bb  mov esi, 0x00
00007eafdc3d50c0  mov rax, 0x645891675530
00007eafdc3d50ca  call rax
00007eafdc3d50cc  movaps xmm10, [rsp]
00007eafdc3d50d1  add rsp, 0x30
00007eafdc3d50d5  vmovaps xmm0, [rsp]
00007eafdc3d50da  vmovaps xmm1, [rsp+0x10]
00007eafdc3d50e0  vmovaps xmm2, [rsp+0x20]
00007eafdc3d50e6  vmovaps xmm3, [rsp+0x30]
00007eafdc3d50ec  vmovaps xmm4, [rsp+0x40]
00007eafdc3d50f2  vmovaps xmm5, [rsp+0x50]
00007eafdc3d50f8  vmovaps xmm6, [rsp+0x60]
00007eafdc3d50fe  vmovaps xmm7, [rsp+0x70]
00007eafdc3d5104  vmovaps xmm8, [rsp+0x80]
00007eafdc3d510d  vmovaps xmm9, [rsp+0x90]
00007eafdc3d5116  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d511f  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d5128  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d5131  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d513a  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d5143  add rsp, 0xF0
00007eafdc3d514a  pop r11
00007eafdc3d514c  pop r10
00007eafdc3d514e  pop r9
00007eafdc3d5150  pop r8
00007eafdc3d5152  pop rsi
00007eafdc3d5153  pop rdi
00007eafdc3d5154  pop rdx
00007eafdc3d5155  pop rcx
00007eafdc3d5156  pop rax
00007eafdc3d5157  add rsp, 0x08
00007eafdc3d515b  jmp 0x00007EAFDC3D028B
00007eafdc3d5160  sub rsp, 0x08
00007eafdc3d5164  push rax
00007eafdc3d5165  push rcx
00007eafdc3d5166  push rdx
00007eafdc3d5167  push rdi
00007eafdc3d5168  push rsi
00007eafdc3d5169  push r8
00007eafdc3d516b  push r9
00007eafdc3d516d  push r10
00007eafdc3d516f  push r11
00007eafdc3d5171  sub rsp, 0xF0
00007eafdc3d5178  vmovaps [rsp], xmm0
00007eafdc3d517d  vmovaps [rsp+0x10], xmm1
00007eafdc3d5183  vmovaps [rsp+0x20], xmm2
00007eafdc3d5189  vmovaps [rsp+0x30], xmm3
00007eafdc3d518f  vmovaps [rsp+0x40], xmm4
00007eafdc3d5195  vmovaps [rsp+0x50], xmm5
00007eafdc3d519b  vmovaps [rsp+0x60], xmm6
00007eafdc3d51a1  vmovaps [rsp+0x70], xmm7
00007eafdc3d51a7  vmovaps [rsp+0x80], xmm8
00007eafdc3d51b0  vmovaps [rsp+0x90], xmm9
00007eafdc3d51b9  vmovaps [rsp+0xA0], xmm10
00007eafdc3d51c2  vmovaps [rsp+0xB0], xmm12
00007eafdc3d51cb  vmovaps [rsp+0xC0], xmm13
00007eafdc3d51d4  vmovaps [rsp+0xD0], xmm14
00007eafdc3d51dd  vmovaps [rsp+0xE0], xmm15
00007eafdc3d51e6  sub rsp, 0x30
00007eafdc3d51ea  movaps [rsp], xmm11
00007eafdc3d51ef  movaps [rsp+0x10], xmm12
00007eafdc3d51f5  movaps [rsp+0x20], xmm15
00007eafdc3d51fb  lea rdi, [rsp]
00007eafdc3d51ff  mov esi, 0x00
00007eafdc3d5204  mov rax, 0x645891675530
00007eafdc3d520e  call rax
00007eafdc3d5210  movaps xmm11, [rsp]
00007eafdc3d5215  add rsp, 0x30
00007eafdc3d5219  vmovaps xmm0, [rsp]
00007eafdc3d521e  vmovaps xmm1, [rsp+0x10]
00007eafdc3d5224  vmovaps xmm2, [rsp+0x20]
00007eafdc3d522a  vmovaps xmm3, [rsp+0x30]
00007eafdc3d5230  vmovaps xmm4, [rsp+0x40]
00007eafdc3d5236  vmovaps xmm5, [rsp+0x50]
00007eafdc3d523c  vmovaps xmm6, [rsp+0x60]
00007eafdc3d5242  vmovaps xmm7, [rsp+0x70]
00007eafdc3d5248  vmovaps xmm8, [rsp+0x80]
00007eafdc3d5251  vmovaps xmm9, [rsp+0x90]
00007eafdc3d525a  vmovaps xmm10, [rsp+0xA0]
00007eafdc3d5263  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d526c  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d5275  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d527e  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d5287  add rsp, 0xF0
00007eafdc3d528e  pop r11
00007eafdc3d5290  pop r10
00007eafdc3d5292  pop r9
00007eafdc3d5294  pop r8
00007eafdc3d5296  pop rsi
00007eafdc3d5297  pop rdi
00007eafdc3d5298  pop rdx
00007eafdc3d5299  pop rcx
00007eafdc3d529a  pop rax
00007eafdc3d529b  add rsp, 0x08
00007eafdc3d529f  jmp 0x00007EAFDC3D02B9
00007eafdc3d52a4  sub rsp, 0x08
00007eafdc3d52a8  push rax
00007eafdc3d52a9  push rcx
00007eafdc3d52aa  push rdx
00007eafdc3d52ab  push rdi
00007eafdc3d52ac  push rsi
00007eafdc3d52ad  push r8
00007eafdc3d52af  push r9
00007eafdc3d52b1  push r10
00007eafdc3d52b3  push r11
00007eafdc3d52b5  sub rsp, 0xF0
00007eafdc3d52bc  vmovaps [rsp], xmm0
00007eafdc3d52c1  vmovaps [rsp+0x10], xmm1
00007eafdc3d52c7  vmovaps [rsp+0x20], xmm2
00007eafdc3d52cd  vmovaps [rsp+0x30], xmm3
00007eafdc3d52d3  vmovaps [rsp+0x40], xmm4
00007eafdc3d52d9  vmovaps [rsp+0x50], xmm5
00007eafdc3d52df  vmovaps [rsp+0x60], xmm6
00007eafdc3d52e5  vmovaps [rsp+0x70], xmm7
00007eafdc3d52eb  vmovaps [rsp+0x80], xmm8
00007eafdc3d52f4  vmovaps [rsp+0x90], xmm9
00007eafdc3d52fd  vmovaps [rsp+0xA0], xmm10
00007eafdc3d5306  vmovaps [rsp+0xB0], xmm11
00007eafdc3d530f  vmovaps [rsp+0xC0], xmm12
00007eafdc3d5318  vmovaps [rsp+0xD0], xmm13
00007eafdc3d5321  vmovaps [rsp+0xE0], xmm14
00007eafdc3d532a  sub rsp, 0x30
00007eafdc3d532e  movaps [rsp], xmm15
00007eafdc3d5333  movaps [rsp+0x10], xmm13
00007eafdc3d5339  movaps [rsp+0x20], xmm9
00007eafdc3d533f  lea rdi, [rsp]
00007eafdc3d5343  mov esi, 0x00
00007eafdc3d5348  mov rax, 0x645891675530
00007eafdc3d5352  call rax
00007eafdc3d5354  movaps xmm15, [rsp]
00007eafdc3d5359  add rsp, 0x30
00007eafdc3d535d  vmovaps xmm0, [rsp]
00007eafdc3d5362  vmovaps xmm1, [rsp+0x10]
00007eafdc3d5368  vmovaps xmm2, [rsp+0x20]
00007eafdc3d536e  vmovaps xmm3, [rsp+0x30]
00007eafdc3d5374  vmovaps xmm4, [rsp+0x40]
00007eafdc3d537a  vmovaps xmm5, [rsp+0x50]
00007eafdc3d5380  vmovaps xmm6, [rsp+0x60]
00007eafdc3d5386  vmovaps xmm7, [rsp+0x70]
00007eafdc3d538c  vmovaps xmm8, [rsp+0x80]
00007eafdc3d5395  vmovaps xmm9, [rsp+0x90]
00007eafdc3d539e  vmovaps xmm10, [rsp+0xA0]
00007eafdc3d53a7  vmovaps xmm11, [rsp+0xB0]
00007eafdc3d53b0  vmovaps xmm12, [rsp+0xC0]
00007eafdc3d53b9  vmovaps xmm13, [rsp+0xD0]
00007eafdc3d53c2  vmovaps xmm14, [rsp+0xE0]
00007eafdc3d53cb  add rsp, 0xF0
00007eafdc3d53d2  pop r11
00007eafdc3d53d4  pop r10
00007eafdc3d53d6  pop r9
00007eafdc3d53d8  pop r8
00007eafdc3d53da  pop rsi
00007eafdc3d53db  pop rdi
00007eafdc3d53dc  pop rdx
00007eafdc3d53dd  pop rcx
00007eafdc3d53de  pop rax
00007eafdc3d53df  add rsp, 0x08
00007eafdc3d53e3  jmp 0x00007EAFDC3D02D4
00007eafdc3d53e8  sub rsp, 0x08
00007eafdc3d53ec  push rax
00007eafdc3d53ed  push rcx
00007eafdc3d53ee  push rdx
00007eafdc3d53ef  push rdi
00007eafdc3d53f0  push rsi
00007eafdc3d53f1  push r8
00007eafdc3d53f3  push r9
00007eafdc3d53f5  push r10
00007eafdc3d53f7  push r11
00007eafdc3d53f9  sub rsp, 0xF0
00007eafdc3d5400  vmovaps [rsp], xmm0
00007eafdc3d5405  vmovaps [rsp+0x10], xmm1
00007eafdc3d540b  vmovaps [rsp+0x20], xmm2
00007eafdc3d5411  vmovaps [rsp+0x30], xmm3
00007eafdc3d5417  vmovaps [rsp+0x40], xmm4
00007eafdc3d541d  vmovaps [rsp+0x50], xmm5
00007eafdc3d5423  vmovaps [rsp+0x60], xmm6
00007eafdc3d5429  vmovaps [rsp+0x70], xmm7
00007eafdc3d542f  vmovaps [rsp+0x80], xmm8
00007eafdc3d5438  vmovaps [rsp+0x90], xmm9
00007eafdc3d5441  vmovaps [rsp+0xA0], xmm10
00007eafdc3d544a  vmovaps [rsp+0xB0], xmm11
00007eafdc3d5453  vmovaps [rsp+0xC0], xmm12
00007eafdc3d545c  vmovaps [rsp+0xD0], xmm14
00007eafdc3d5465  vmovaps [rsp+0xE0], xmm15
00007eafdc3d546e  sub rsp, 0x30
00007eafdc3d5472  movaps [rsp], xmm13
00007eafdc3d5477  movaps [rsp+0x10], xmm8
00007eafdc3d547d  movaps [rsp+0x20], xmm14
00007eafdc3d5483  lea rdi, [rsp]
00007eafdc3d5487  mov esi, 0x00
00007eafdc3d548c  mov rax, 0x645891675530
00007eafdc3d5496  call rax
00007eafdc3d5498  movaps xmm13, [rsp]
00007eafdc3d549d  add rsp, 0x30
00007eafdc3d54a1  vmovaps xmm0, [rsp]
00007eafdc3d54a6  vmovaps xmm1, [rsp+0x10]
00007eafdc3d54ac  vmovaps xmm2, [rsp+0x20]
00007eafdc3d54b2  vmovaps xmm3, [rsp+0x30]
00007eafdc3d54b8  vmovaps xmm4, [rsp+0x40]
00007eafdc3d54be  vmovaps xmm5, [rsp+0x50]
00007eafdc3d54c4  vmovaps xmm6, [rsp+0x60]
00007eafdc3d54ca  vmovaps xmm7, [rsp+0x70]
00007eafdc3d54d0  vmovaps xmm8, [rsp+0x80]
00007eafdc3d54d9  vmovaps xmm9, [rsp+0x90]
00007eafdc3d54e2  vmovaps xmm10, [rsp+0xA0]
00007eafdc3d54eb  vmovaps xmm11, [rsp+0xB0]
00007eafdc3d54f4  vmovaps xmm12, [rsp+0xC0]
00007eafdc3d54fd  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d5506  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d550f  add rsp, 0xF0
00007eafdc3d5516  pop r11
00007eafdc3d5518  pop r10
00007eafdc3d551a  pop r9
00007eafdc3d551c  pop r8
00007eafdc3d551e  pop rsi
00007eafdc3d551f  pop rdi
00007eafdc3d5520  pop rdx
00007eafdc3d5521  pop rcx
00007eafdc3d5522  pop rax
00007eafdc3d5523  add rsp, 0x08
00007eafdc3d5527  jmp 0x00007EAFDC3D02F7
00007eafdc3d552c  sub rsp, 0x08
00007eafdc3d5530  push rax
00007eafdc3d5531  push rcx
00007eafdc3d5532  push rdx
00007eafdc3d5533  push rdi
00007eafdc3d5534  push rsi
00007eafdc3d5535  push r8
00007eafdc3d5537  push r9
00007eafdc3d5539  push r10
00007eafdc3d553b  push r11
00007eafdc3d553d  sub rsp, 0xF0
00007eafdc3d5544  vmovaps [rsp], xmm0
00007eafdc3d5549  vmovaps [rsp+0x10], xmm1
00007eafdc3d554f  vmovaps [rsp+0x20], xmm2
00007eafdc3d5555  vmovaps [rsp+0x30], xmm3
00007eafdc3d555b  vmovaps [rsp+0x40], xmm4
00007eafdc3d5561  vmovaps [rsp+0x50], xmm5
00007eafdc3d5567  vmovaps [rsp+0x60], xmm6
00007eafdc3d556d  vmovaps [rsp+0x70], xmm7
00007eafdc3d5573  vmovaps [rsp+0x80], xmm8
00007eafdc3d557c  vmovaps [rsp+0x90], xmm9
00007eafdc3d5585  vmovaps [rsp+0xA0], xmm10
00007eafdc3d558e  vmovaps [rsp+0xB0], xmm11
00007eafdc3d5597  vmovaps [rsp+0xC0], xmm12
00007eafdc3d55a0  vmovaps [rsp+0xD0], xmm13
00007eafdc3d55a9  vmovaps [rsp+0xE0], xmm15
00007eafdc3d55b2  sub rsp, 0x30
00007eafdc3d55b6  movaps [rsp], xmm14
00007eafdc3d55bb  movaps [rsp+0x10], xmm1
00007eafdc3d55c0  movaps [rsp+0x20], xmm10
00007eafdc3d55c6  lea rdi, [rsp]
00007eafdc3d55ca  mov esi, 0x00
00007eafdc3d55cf  mov rax, 0x645891675530
00007eafdc3d55d9  call rax
00007eafdc3d55db  movaps xmm14, [rsp]
00007eafdc3d55e0  add rsp, 0x30
00007eafdc3d55e4  vmovaps xmm0, [rsp]
00007eafdc3d55e9  vmovaps xmm1, [rsp+0x10]
00007eafdc3d55ef  vmovaps xmm2, [rsp+0x20]
00007eafdc3d55f5  vmovaps xmm3, [rsp+0x30]
00007eafdc3d55fb  vmovaps xmm4, [rsp+0x40]
00007eafdc3d5601  vmovaps xmm5, [rsp+0x50]
00007eafdc3d5607  vmovaps xmm6, [rsp+0x60]
00007eafdc3d560d  vmovaps xmm7, [rsp+0x70]
00007eafdc3d5613  vmovaps xmm8, [rsp+0x80]
00007eafdc3d561c  vmovaps xmm9, [rsp+0x90]
00007eafdc3d5625  vmovaps xmm10, [rsp+0xA0]
00007eafdc3d562e  vmovaps xmm11, [rsp+0xB0]
00007eafdc3d5637  vmovaps xmm12, [rsp+0xC0]
00007eafdc3d5640  vmovaps xmm13, [rsp+0xD0]
00007eafdc3d5649  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d5652  add rsp, 0xF0
00007eafdc3d5659  pop r11
00007eafdc3d565b  pop r10
00007eafdc3d565d  pop r9
00007eafdc3d565f  pop r8
00007eafdc3d5661  pop rsi
00007eafdc3d5662  pop rdi
00007eafdc3d5663  pop rdx
00007eafdc3d5664  pop rcx
00007eafdc3d5665  pop rax
00007eafdc3d5666  add rsp, 0x08
00007eafdc3d566a  jmp 0x00007EAFDC3D031A
00007eafdc3d566f  sub rsp, 0x08
00007eafdc3d5673  push rax
00007eafdc3d5674  push rcx
00007eafdc3d5675  push rdx
00007eafdc3d5676  push rdi
00007eafdc3d5677  push rsi
00007eafdc3d5678  push r8
00007eafdc3d567a  push r9
00007eafdc3d567c  push r10
00007eafdc3d567e  push r11
00007eafdc3d5680  sub rsp, 0xF0
00007eafdc3d5687  vmovaps [rsp], xmm0
00007eafdc3d568c  vmovaps [rsp+0x10], xmm2
00007eafdc3d5692  vmovaps [rsp+0x20], xmm3
00007eafdc3d5698  vmovaps [rsp+0x30], xmm4
00007eafdc3d569e  vmovaps [rsp+0x40], xmm5
00007eafdc3d56a4  vmovaps [rsp+0x50], xmm6
00007eafdc3d56aa  vmovaps [rsp+0x60], xmm7
00007eafdc3d56b0  vmovaps [rsp+0x70], xmm8
00007eafdc3d56b6  vmovaps [rsp+0x80], xmm9
00007eafdc3d56bf  vmovaps [rsp+0x90], xmm10
00007eafdc3d56c8  vmovaps [rsp+0xA0], xmm11
00007eafdc3d56d1  vmovaps [rsp+0xB0], xmm12
00007eafdc3d56da  vmovaps [rsp+0xC0], xmm13
00007eafdc3d56e3  vmovaps [rsp+0xD0], xmm14
00007eafdc3d56ec  vmovaps [rsp+0xE0], xmm15
00007eafdc3d56f5  sub rsp, 0x30
00007eafdc3d56f9  movaps [rsp], xmm1
00007eafdc3d56fd  movaps [rsp+0x10], xmm7
00007eafdc3d5702  movaps [rsp+0x20], xmm11
00007eafdc3d5708  lea rdi, [rsp]
00007eafdc3d570c  mov esi, 0x00
00007eafdc3d5711  mov rax, 0x645891675530
00007eafdc3d571b  call rax
00007eafdc3d571d  movaps xmm1, [rsp]
00007eafdc3d5721  add rsp, 0x30
00007eafdc3d5725  vmovaps xmm0, [rsp]
00007eafdc3d572a  vmovaps xmm2, [rsp+0x10]
00007eafdc3d5730  vmovaps xmm3, [rsp+0x20]
00007eafdc3d5736  vmovaps xmm4, [rsp+0x30]
00007eafdc3d573c  vmovaps xmm5, [rsp+0x40]
00007eafdc3d5742  vmovaps xmm6, [rsp+0x50]
00007eafdc3d5748  vmovaps xmm7, [rsp+0x60]
00007eafdc3d574e  vmovaps xmm8, [rsp+0x70]
00007eafdc3d5754  vmovaps xmm9, [rsp+0x80]
00007eafdc3d575d  vmovaps xmm10, [rsp+0x90]
00007eafdc3d5766  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d576f  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d5778  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d5781  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d578a  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d5793  add rsp, 0xF0
00007eafdc3d579a  pop r11
00007eafdc3d579c  pop r10
00007eafdc3d579e  pop r9
00007eafdc3d57a0  pop r8
00007eafdc3d57a2  pop rsi
00007eafdc3d57a3  pop rdi
00007eafdc3d57a4  pop rdx
00007eafdc3d57a5  pop rcx
00007eafdc3d57a6  pop rax
00007eafdc3d57a7  add rsp, 0x08
00007eafdc3d57ab  jmp 0x00007EAFDC3D033B
00007eafdc3d57b0  call 0x00007EAFDC20E880
00007eafdc3d57b5  jmp 0x00007EAFDC3D034E
00007eafdc3d57ba  call 0x00007EAFDC20C380
00007eafdc3d57bf  jmp 0x00007EAFDC3D0359
00007eafdc3d57c4  call 0x00007EAFDC20D600
00007eafdc3d57c9  jmp 0x00007EAFDC3D0364
00007eafdc3d57ce  call 0x00007EAFDC1FF540
00007eafdc3d57d3  jmp 0x00007EAFDC3D036F
00007eafdc3d57d8  int3
00007eafdc3d57d9  nop [rax], eax
00007eafdc3d57e0  mov rax, [r15+0x40]
00007eafdc3d57e4  mov r14, [r15+0x58]
00007eafdc3d57e8  lea r12, [rax+r14*1]
00007eafdc3d57ec  movaps xmm1, [r15+0x1D0]
00007eafdc3d57f4  vmovaps [rsp+0x10], xmm1
00007eafdc3d57fa  vmovaps xmm15, [rsp+0x10]
00007eafdc3d5800  por xmm1, xmm15
00007eafdc3d5805  movaps xmm14, [r15+0x1A0]
00007eafdc3d580d  vmovaps [rsp+0x10], xmm14
00007eafdc3d5813  vmovaps xmm13, [rsp+0x10]
00007eafdc3d5819  por xmm14, xmm13
00007eafdc3d581e  lea rax, [r12+0x30]
00007eafdc3d5823  mov r11, [r13+rax*1]
00007eafdc3d5828  lea rax, [r12+0x38]
00007eafdc3d582d  mov r10, [r13+rax*1]
00007eafdc3d5832  movq xmm13, r11
00007eafdc3d5837  movq xmm12, r10
00007eafdc3d583c  movq xmm13, xmm13
00007eafdc3d5841  vmovaps [rsp+0x10], xmm13
00007eafdc3d5847  movq xmm13, xmm13
00007eafdc3d584c  movaps [r15+0x130], xmm13
00007eafdc3d5854  movq xmm12, xmm12
00007eafdc3d5859  vmovaps [rsp+0x20], xmm12
00007eafdc3d585f  movq xmm12, xmm12
00007eafdc3d5864  movaps [r15+0x280], xmm12
00007eafdc3d586c  movaps xmm13, [r15+0x270]
00007eafdc3d5874  vmovaps [rsp+0x30], xmm13
00007eafdc3d587a  vmovaps xmm12, [rsp+0x30]
00007eafdc3d5880  por xmm13, xmm12
00007eafdc3d5885  lea rax, [r12+0x20]
00007eafdc3d588a  mov r11, [r13+rax*1]
00007eafdc3d588f  lea rax, [r12+0x28]
00007eafdc3d5894  mov r10, [r13+rax*1]
00007eafdc3d5899  movq xmm12, r11
00007eafdc3d589e  movq xmm11, r10
00007eafdc3d58a3  movq xmm12, xmm12
00007eafdc3d58a8  vmovaps [rsp+0x30], xmm12
00007eafdc3d58ae  movq xmm12, xmm12
00007eafdc3d58b3  movaps [r15+0x150], xmm12
00007eafdc3d58bb  movq xmm11, xmm11
00007eafdc3d58c0  vmovaps [rsp+0x40], xmm11
00007eafdc3d58c6  movq xmm11, xmm11
00007eafdc3d58cb  movaps [r15+0x140], xmm11
00007eafdc3d58d3  lea rax, [r12+0x10]
00007eafdc3d58d8  mov r11, [r13+rax*1]
00007eafdc3d58dd  lea rax, [r12+0x18]
00007eafdc3d58e2  mov r10, [r13+rax*1]
00007eafdc3d58e7  movq xmm12, r11
00007eafdc3d58ec  movq xmm11, r10
00007eafdc3d58f1  movq xmm12, xmm12
00007eafdc3d58f6  vmovaps [rsp+0x50], xmm12
00007eafdc3d58fc  movq xmm12, xmm12
00007eafdc3d5901  movaps [r15+0x170], xmm12
00007eafdc3d5909  movq xmm11, xmm11
00007eafdc3d590e  vmovaps [rsp+0x60], xmm11
00007eafdc3d5914  movq xmm11, xmm11
00007eafdc3d5919  movaps [r15+0x160], xmm11
00007eafdc3d5921  mov rax, [r13+r12*1]
00007eafdc3d5926  vmovq xmm12, rax
00007eafdc3d592b  vpbroadcastq xmm12, xmm12
00007eafdc3d5930  lea rax, [r12+0x08]
00007eafdc3d5935  mov r12, [r13+rax*1]
00007eafdc3d593a  movq xmm11, r12
00007eafdc3d593f  movaps [r15+0x230], xmm11
00007eafdc3d5947  mov rax, [r15+0xF8]
00007eafdc3d594e  lea r12, [rax+0x50]
00007eafdc3d5952  movups xmm11, [r13+r12*1]
00007eafdc3d5958  lea r12, [rax+0x60]
00007eafdc3d595c  movups xmm10, [r13+r12*1]
00007eafdc3d5962  lea r12, [rax+0x30]
00007eafdc3d5966  movups xmm9, [r13+r12*1]
00007eafdc3d596c  mov r12, [r15+0x50]
00007eafdc3d5970  lea r11, [r12+r14*1]
00007eafdc3d5974  mov [r15+0x60], r11
00007eafdc3d5978  lea r12, [r14+0x40]
00007eafdc3d597c  mov [r15+0x58], r12
00007eafdc3d5980  movaps xmm8, xmm12
00007eafdc3d5984  mulpd xmm8, xmm15
00007eafdc3d5989  vcmppd xmm7, xmm8, xmm8, 0x03
00007eafdc3d598f  ptest xmm7, xmm7
00007eafdc3d5994  jnz 0x00007EAFDC3D67B7
00007eafdc3d599a  movq xmm15, qword ptr [r15+0x230]
00007eafdc3d59a3  vmovaps [rsp+0x70], xmm15
00007eafdc3d59a9  vpermilpd xmm15, xmm15, 0x00
00007eafdc3d59af  movaps xmm7, xmm9
00007eafdc3d59b3  mulpd xmm7, xmm15
00007eafdc3d59b8  vcmppd xmm6, xmm7, xmm7, 0x03
00007eafdc3d59bd  ptest xmm6, xmm6
00007eafdc3d59c2  jnz 0x00007EAFDC3D68FB
00007eafdc3d59c8  vxorps xmm15, xmm15, xmm15
00007eafdc3d59cd  vpbroadcastq xmm15, xmm15
00007eafdc3d59d2  movaps xmm9, xmm12
00007eafdc3d59d6  mulpd xmm9, xmm10
00007eafdc3d59db  vcmppd xmm6, xmm9, xmm9, 0x03
00007eafdc3d59e1  ptest xmm6, xmm6
00007eafdc3d59e6  jnz 0x00007EAFDC3D6A3D
00007eafdc3d59ec  movaps xmm10, xmm12
00007eafdc3d59f0  mulpd xmm10, xmm11
00007eafdc3d59f5  vcmppd xmm6, xmm10, xmm10, 0x03
00007eafdc3d59fb  ptest xmm6, xmm6
00007eafdc3d5a00  jnz 0x00007EAFDC3D6B81
00007eafdc3d5a06  movaps xmm11, [r15+0x1F0]
00007eafdc3d5a0e  movaps xmm6, xmm12
00007eafdc3d5a12  mulpd xmm6, xmm11
00007eafdc3d5a17  vcmppd xmm5, xmm6, xmm6, 0x03
00007eafdc3d5a1c  ptest xmm5, xmm5
00007eafdc3d5a21  jnz 0x00007EAFDC3D6CC5
00007eafdc3d5a27  movaps xmm12, [r15+0x2A0]
00007eafdc3d5a2f  vmovaps [rsp+0x80], xmm12
00007eafdc3d5a38  vmovaps xmm11, [rsp+0x80]
00007eafdc3d5a41  por xmm12, xmm11
00007eafdc3d5a46  movaps xmm11, [r15+0x250]
00007eafdc3d5a4e  vmovaps [rsp+0x80], xmm11
00007eafdc3d5a57  vmovaps xmm5, [rsp+0x80]
00007eafdc3d5a60  por xmm11, xmm5
00007eafdc3d5a65  vmovaps xmm4, [rsp+0x70]
00007eafdc3d5a6b  vpermilpd xmm4, xmm4, 0x00
00007eafdc3d5a71  movaps xmm3, xmm5
00007eafdc3d5a74  mulpd xmm3, xmm4
00007eafdc3d5a78  vcmppd xmm2, xmm3, xmm3, 0x03
00007eafdc3d5a7d  ptest xmm2, xmm2
00007eafdc3d5a82  jnz 0x00007EAFDC3D6E07
00007eafdc3d5a88  mov [rsp+0x80], rax
00007eafdc3d5a90  xor eax, eax
00007eafdc3d5a92  mov r14d, 0x200
00007eafdc3d5a98  cmp r12, r14
00007eafdc3d5a9b  cmc
00007eafdc3d5a9c  lahf
00007eafdc3d5a9d  seto al
00007eafdc3d5aa0  mov [r15+0x108], eax
00007eafdc3d5aa7  movaps xmm5, xmm8
00007eafdc3d5aab  addpd xmm5, xmm15
00007eafdc3d5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
00007eafdc3d5ab5  ptest xmm4, xmm4
00007eafdc3d5aba  jnz 0x00007EAFDC3D6F47
00007eafdc3d5ac0  movaps xmm8, [r15+0x1B0]
00007eafdc3d5ac8  movaps xmm4, xmm9
00007eafdc3d5acc  addpd xmm4, xmm8
00007eafdc3d5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
00007eafdc3d5ad6  ptest xmm2, xmm2
00007eafdc3d5adb  jnz 0x00007EAFDC3D7089
00007eafdc3d5ae1  movaps xmm9, xmm10
00007eafdc3d5ae5  addpd xmm9, xmm8
00007eafdc3d5aea  vcmppd xmm2, xmm9, xmm9, 0x03
00007eafdc3d5af0  ptest xmm2, xmm2
00007eafdc3d5af5  jnz 0x00007EAFDC3D71CB
00007eafdc3d5afb  movaps xmm10, [r15+0x2F0]
00007eafdc3d5b03  vmovaps [rsp+0x90], xmm10
00007eafdc3d5b0c  vmovaps xmm8, [rsp+0x90]
00007eafdc3d5b15  por xmm10, xmm8
00007eafdc3d5b1a  movaps xmm8, [r15+0x2E0]
00007eafdc3d5b22  vmovaps [rsp+0x90], xmm8
00007eafdc3d5b2b  vmovaps xmm2, [rsp+0x90]
00007eafdc3d5b34  por xmm8, xmm2
00007eafdc3d5b39  movaps xmm2, [r15+0x2D0]
00007eafdc3d5b41  vmovaps [rsp+0x90], xmm2
00007eafdc3d5b4a  vmovaps [rsp+0xA0], xmm1
00007eafdc3d5b53  vmovaps xmm1, [rsp+0x90]
00007eafdc3d5b5c  por xmm2, xmm1
00007eafdc3d5b60  movaps xmm1, [r15+0x200]
00007eafdc3d5b68  vmovaps [rsp+0x90], xmm1
00007eafdc3d5b71  vmovaps [rsp+0xB0], xmm15
00007eafdc3d5b7a  vmovaps xmm15, [rsp+0x90]
00007eafdc3d5b83  por xmm1, xmm15
00007eafdc3d5b88  movaps xmm15, [r15+0x1C0]
00007eafdc3d5b90  vmovaps [rsp+0x90], xmm15
00007eafdc3d5b99  vmovaps [rsp+0xC0], xmm1
00007eafdc3d5ba2  vmovaps xmm1, [rsp+0x90]
00007eafdc3d5bab  por xmm15, xmm1
00007eafdc3d5bb0  movaps xmm1, [r15+0x190]
00007eafdc3d5bb8  vmovaps [rsp+0x90], xmm1
00007eafdc3d5bc1  vmovaps [rsp+0xD0], xmm15
00007eafdc3d5bca  vmovaps xmm15, [rsp+0x90]
00007eafdc3d5bd3  por xmm1, xmm15
00007eafdc3d5bd8  movaps xmm15, [r15+0x300]
00007eafdc3d5be0  vmovaps [rsp+0x90], xmm15
00007eafdc3d5be9  vmovaps [rsp+0xE0], xmm1
00007eafdc3d5bf2  vmovaps xmm1, [rsp+0x90]
00007eafdc3d5bfb  por xmm15, xmm1
00007eafdc3d5c00  mov rax, [rsp+0x80]
00007eafdc3d5c08  lea r14, [rax+0xA0]
00007eafdc3d5c0f  movups xmm1, [r13+r14*1]
00007eafdc3d5c15  lea r14, [rax+0xB0]
00007eafdc3d5c1c  vmovaps [rsp+0x80], xmm1
00007eafdc3d5c25  movups xmm1, [r13+r14*1]
00007eafdc3d5c2b  vmovaps [rsp+0x90], xmm1
00007eafdc3d5c34  vmovaps [rsp+0xF0], xmm15
00007eafdc3d5c3d  vmovaps xmm15, [rsp+0xB0]
00007eafdc3d5c46  vmovaps [rsp+0xB0], xmm14
00007eafdc3d5c4f  movaps xmm1, xmm6
00007eafdc3d5c52  addpd xmm1, xmm15
00007eafdc3d5c57  vcmppd xmm14, xmm1, xmm1, 0x03
00007eafdc3d5c5c  ptest xmm14, xmm14
00007eafdc3d5c62  jnz 0x00007EAFDC3D7323
00007eafdc3d5c68  lea r14, [rax+0xF0]
00007eafdc3d5c6f  movups xmm15, [r13+r14*1]
00007eafdc3d5c75  movaps xmm14, xmm4
00007eafdc3d5c79  addpd xmm14, xmm3
00007eafdc3d5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
00007eafdc3d5c84  ptest xmm6, xmm6
00007eafdc3d5c89  jnz 0x00007EAFDC3D746E
00007eafdc3d5c8f  movaps xmm6, xmm9
00007eafdc3d5c93  addpd xmm6, xmm7
00007eafdc3d5c97  vcmppd xmm4, xmm6, xmm6, 0x03
00007eafdc3d5c9c  ptest xmm4, xmm4
00007eafdc3d5ca1  jnz 0x00007EAFDC3D75B0
00007eafdc3d5ca7  vmovaps xmm9, [rsp+0x70]
00007eafdc3d5cad  vpermilpd xmm9, xmm9, 0x00
00007eafdc3d5cb3  vmovaps xmm4, [rsp+0x90]
00007eafdc3d5cbc  movaps xmm7, xmm4
00007eafdc3d5cbf  mulpd xmm7, xmm9
00007eafdc3d5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
00007eafdc3d5cc9  ptest xmm3, xmm3
00007eafdc3d5cce  jnz 0x00007EAFDC3D76F1
00007eafdc3d5cd4  vmovaps xmm9, [rsp+0x50]
00007eafdc3d5cda  vpermilpd xmm9, xmm9, 0x00
00007eafdc3d5ce0  movaps xmm4, xmm15
00007eafdc3d5ce4  mulpd xmm4, xmm9
00007eafdc3d5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
00007eafdc3d5cee  ptest xmm3, xmm3
00007eafdc3d5cf3  jnz 0x00007EAFDC3D7832
00007eafdc3d5cf9  lea r14, [rax+0xE0]
00007eafdc3d5d00  movups xmm15, [r13+r14*1]
00007eafdc3d5d06  vmovaps xmm9, [rsp+0x70]
00007eafdc3d5d0c  vpermilpd xmm9, xmm9, 0x00
00007eafdc3d5d12  vmovaps [rsp+0x70], xmm1
00007eafdc3d5d18  vmovaps xmm1, [rsp+0x80]
00007eafdc3d5d21  vmovaps [rsp+0x80], xmm15
00007eafdc3d5d2a  movaps xmm3, xmm1
00007eafdc3d5d2d  mulpd xmm3, xmm9
00007eafdc3d5d32  vcmppd xmm15, xmm3, xmm3, 0x03
00007eafdc3d5d37  ptest xmm15, xmm15
00007eafdc3d5d3d  jnz 0x00007EAFDC3D797E
00007eafdc3d5d43  vmovaps xmm1, [rsp+0xF0]
00007eafdc3d5d4c  vmovaps xmm15, [rsp+0xF0]
00007eafdc3d5d55  por xmm1, xmm15
00007eafdc3d5d5a  movaps [r15+0x300], xmm1
00007eafdc3d5d62  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d5d6b  vmovaps xmm9, [rsp+0xE0]
00007eafdc3d5d74  por xmm15, xmm9
00007eafdc3d5d79  movaps [r15+0x190], xmm15
00007eafdc3d5d81  vmovaps xmm9, [rsp+0x50]
00007eafdc3d5d87  vpermilpd xmm9, xmm9, 0x00
00007eafdc3d5d8d  vmovaps [rsp+0x90], xmm1
00007eafdc3d5d96  vmovaps [rsp+0xE0], xmm15
00007eafdc3d5d9f  vmovaps xmm15, [rsp+0x80]
00007eafdc3d5da8  vmovaps [rsp+0x80], xmm14
00007eafdc3d5db1  movaps xmm1, xmm15
00007eafdc3d5db5  mulpd xmm1, xmm9
00007eafdc3d5dba  vcmppd xmm14, xmm1, xmm1, 0x03
00007eafdc3d5dbf  ptest xmm14, xmm14
00007eafdc3d5dc5  jnz 0x00007EAFDC3D7ABF
00007eafdc3d5dcb  lea r14, [rax+0x90]
00007eafdc3d5dd2  movups xmm15, [r13+r14*1]
00007eafdc3d5dd8  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d5de1  vmovaps xmm9, [rsp+0xD0]
00007eafdc3d5dea  por xmm14, xmm9
00007eafdc3d5def  movaps [r15+0x1C0], xmm14
00007eafdc3d5df7  vmovaps xmm9, [rsp+0xC0]
00007eafdc3d5e00  vmovaps [rsp+0xD0], xmm1
00007eafdc3d5e09  vmovaps xmm1, [rsp+0xC0]
00007eafdc3d5e12  por xmm9, xmm1
00007eafdc3d5e17  movaps [r15+0x200], xmm9
00007eafdc3d5e1f  vmovaps [rsp+0xC0], xmm2
00007eafdc3d5e28  vmovaps xmm1, [rsp+0xC0]
00007eafdc3d5e31  por xmm2, xmm1
00007eafdc3d5e35  movaps [r15+0x2D0], xmm2
00007eafdc3d5e3d  vmovaps [rsp+0xC0], xmm8
00007eafdc3d5e46  vmovaps xmm1, [rsp+0xC0]
00007eafdc3d5e4f  por xmm8, xmm1
00007eafdc3d5e54  movaps [r15+0x2E0], xmm8
00007eafdc3d5e5c  vmovaps [rsp+0xC0], xmm15
00007eafdc3d5e65  movaps xmm1, xmm5
00007eafdc3d5e68  addpd xmm1, xmm7
00007eafdc3d5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
00007eafdc3d5e71  ptest xmm15, xmm15
00007eafdc3d5e77  jnz 0x00007EAFDC3D7C0B
00007eafdc3d5e7d  vmovaps xmm15, [rsp+0x50]
00007eafdc3d5e83  vpermilpd xmm15, xmm15, 0x00
00007eafdc3d5e89  vmovaps xmm5, [rsp+0xC0]
00007eafdc3d5e92  vmovaps [rsp+0xC0], xmm1
00007eafdc3d5e9b  movaps xmm7, xmm5
00007eafdc3d5e9e  mulpd xmm7, xmm15
00007eafdc3d5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
00007eafdc3d5ea8  ptest xmm1, xmm1
00007eafdc3d5ead  jnz 0x00007EAFDC3D7D4B
00007eafdc3d5eb3  lea r14, [rax+0x80]
00007eafdc3d5eba  movups xmm1, [r13+r14*1]
00007eafdc3d5ec0  vmovaps xmm5, [rsp+0x70]
00007eafdc3d5ec6  vmovaps [rsp+0x70], xmm1
00007eafdc3d5ecc  movaps xmm15, xmm5
00007eafdc3d5ed0  addpd xmm15, xmm3
00007eafdc3d5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
00007eafdc3d5edb  ptest xmm1, xmm1
00007eafdc3d5ee0  jnz 0x00007EAFDC3D7E96
00007eafdc3d5ee6  vmovaps xmm5, [rsp+0x80]
00007eafdc3d5eef  movaps xmm1, xmm5
00007eafdc3d5ef2  addpd xmm1, xmm4
00007eafdc3d5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
00007eafdc3d5efb  ptest xmm3, xmm3
00007eafdc3d5f00  jnz 0x00007EAFDC3D7FD8
00007eafdc3d5f06  vmovaps [rsp+0x80], xmm10
00007eafdc3d5f0f  vmovaps xmm5, [rsp+0x80]
00007eafdc3d5f18  por xmm10, xmm5
00007eafdc3d5f1d  movaps [r15+0x2F0], xmm10
00007eafdc3d5f25  vmovaps xmm5, [rsp+0x50]
00007eafdc3d5f2b  vpermilpd xmm5, xmm5, 0x00
00007eafdc3d5f31  vmovaps xmm3, [rsp+0x70]
00007eafdc3d5f37  vmovaps [rsp+0x50], xmm1
00007eafdc3d5f3d  movaps xmm4, xmm3
00007eafdc3d5f40  mulpd xmm4, xmm5
00007eafdc3d5f44  vcmppd xmm1, xmm4, xmm4, 0x03
00007eafdc3d5f49  ptest xmm1, xmm1
00007eafdc3d5f4e  jnz 0x00007EAFDC3D8118
00007eafdc3d5f54  lea r14, [rax+0xD0]
00007eafdc3d5f5b  movups xmm1, [r13+r14*1]
00007eafdc3d5f61  vmovaps xmm3, [rsp+0xD0]
00007eafdc3d5f6a  vmovaps [rsp+0x70], xmm1
00007eafdc3d5f70  movaps xmm5, xmm6
00007eafdc3d5f73  addpd xmm5, xmm3
00007eafdc3d5f77  vcmppd xmm1, xmm5, xmm5, 0x03
00007eafdc3d5f7c  ptest xmm1, xmm1
00007eafdc3d5f81  jnz 0x00007EAFDC3D8262
00007eafdc3d5f87  vmovaps xmm1, [rsp+0x60]
00007eafdc3d5f8d  vpermilpd xmm1, xmm1, 0x00
00007eafdc3d5f93  movaps xmm6, xmm9
00007eafdc3d5f97  mulpd xmm6, xmm1
00007eafdc3d5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
00007eafdc3d5fa0  ptest xmm3, xmm3
00007eafdc3d5fa5  jnz 0x00007EAFDC3D83A2
00007eafdc3d5fab  movaps [r15+0x260], xmm6
00007eafdc3d5fb3  vxorps xmm1, xmm1, xmm1
00007eafdc3d5fb7  vpbroadcastq xmm1, xmm1
00007eafdc3d5fbc  movaps [r15+0x1B0], xmm1
00007eafdc3d5fc4  vmovaps xmm1, [rsp+0x60]
00007eafdc3d5fca  vpermilpd xmm1, xmm1, 0x00
00007eafdc3d5fd0  vmovaps xmm3, [rsp+0x70]
00007eafdc3d5fd6  vmovaps [rsp+0x70], xmm15
00007eafdc3d5fdc  movaps xmm9, xmm3
00007eafdc3d5fe0  mulpd xmm9, xmm1
00007eafdc3d5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
00007eafdc3d5feb  ptest xmm15, xmm15
00007eafdc3d5ff1  jnz 0x00007EAFDC3D84E3
00007eafdc3d5ff7  lea r14, [rax+0xC0]
00007eafdc3d5ffe  movups xmm1, [r13+r14*1]
00007eafdc3d6004  vmovaps xmm3, [rsp+0xC0]
00007eafdc3d600d  vmovaps [rsp+0x80], xmm1
00007eafdc3d6016  movaps xmm15, xmm3
00007eafdc3d601a  addpd xmm15, xmm7
00007eafdc3d601f  vcmppd xmm1, xmm15, xmm15, 0x03
00007eafdc3d6025  ptest xmm1, xmm1
00007eafdc3d602a  jnz 0x00007EAFDC3D862F
00007eafdc3d6030  vmovaps [rsp+0xC0], xmm13
00007eafdc3d6039  vmovaps xmm1, [rsp+0xC0]
00007eafdc3d6042  por xmm13, xmm1
00007eafdc3d6047  movaps [r15+0x270], xmm13
00007eafdc3d604f  vmovaps xmm1, [rsp+0xB0]
00007eafdc3d6058  vmovaps xmm7, [rsp+0xB0]
00007eafdc3d6061  por xmm1, xmm7
00007eafdc3d6065  movaps [r15+0x1A0], xmm1
00007eafdc3d606d  vmovaps xmm1, [rsp+0x60]
00007eafdc3d6073  vpermilpd xmm1, xmm1, 0x00
00007eafdc3d6079  vmovaps [rsp+0xB0], xmm1
00007eafdc3d6082  vmovaps xmm1, [rsp+0x80]
00007eafdc3d608b  vmovaps [rsp+0x80], xmm15
00007eafdc3d6094  vmovaps xmm15, [rsp+0xB0]
00007eafdc3d609d  vmovaps [rsp+0xB0], xmm14
00007eafdc3d60a6  movaps xmm3, xmm1
00007eafdc3d60a9  mulpd xmm3, xmm15
00007eafdc3d60ae  vcmppd xmm14, xmm3, xmm3, 0x03
00007eafdc3d60b3  ptest xmm14, xmm14
00007eafdc3d60b9  jnz 0x00007EAFDC3D8771
00007eafdc3d60bf  lea r14, [rax+0x20]
00007eafdc3d60c3  movups xmm1, [r13+r14*1]
00007eafdc3d60c9  movaps [r15+0x110], xmm1
00007eafdc3d60d1  vmovaps xmm14, [rsp+0x70]
00007eafdc3d60d7  vmovaps [rsp+0x70], xmm1
00007eafdc3d60dd  movaps xmm15, xmm14
00007eafdc3d60e1  addpd xmm15, xmm4
00007eafdc3d60e6  vcmppd xmm1, xmm15, xmm15, 0x03
00007eafdc3d60ec  ptest xmm1, xmm1
00007eafdc3d60f1  jnz 0x00007EAFDC3D88BC
00007eafdc3d60f7  vmovaps xmm1, [rsp+0x60]
00007eafdc3d60fd  vpermilpd xmm1, xmm1, 0x00
00007eafdc3d6103  movaps xmm14, xmm2
00007eafdc3d6107  mulpd xmm14, xmm1
00007eafdc3d610c  vcmppd xmm4, xmm14, xmm14, 0x03
00007eafdc3d6112  ptest xmm4, xmm4
00007eafdc3d6117  jnz 0x00007EAFDC3D89FF
00007eafdc3d611d  vmovaps xmm4, [rsp+0x50]
00007eafdc3d6123  movaps xmm1, xmm4
00007eafdc3d6126  addpd xmm1, xmm9
00007eafdc3d612b  vcmppd xmm2, xmm1, xmm1, 0x03
00007eafdc3d6130  ptest xmm2, xmm2
00007eafdc3d6135  jnz 0x00007EAFDC3D8B41
00007eafdc3d613b  vmovaps xmm9, [rsp+0x30]
00007eafdc3d6141  vpermilpd xmm9, xmm9, 0x00
00007eafdc3d6147  vmovaps xmm2, [rsp+0x70]
00007eafdc3d614d  vmovaps [rsp+0x50], xmm1
00007eafdc3d6153  movaps xmm4, xmm2
00007eafdc3d6156  mulpd xmm4, xmm9
00007eafdc3d615b  vcmppd xmm1, xmm4, xmm4, 0x03
00007eafdc3d6160  ptest xmm1, xmm1
00007eafdc3d6165  jnz 0x00007EAFDC3D8C82
00007eafdc3d616b  vmovaps xmm1, [rsp+0x30]
00007eafdc3d6171  vpermilpd xmm1, xmm1, 0x00
00007eafdc3d6177  vmovaps xmm2, [rsp+0x90]
00007eafdc3d6180  vmovaps [rsp+0x60], xmm15
00007eafdc3d6186  movaps xmm9, xmm2
00007eafdc3d618a  mulpd xmm9, xmm1
00007eafdc3d618f  vcmppd xmm15, xmm9, xmm9, 0x03
00007eafdc3d6195  ptest xmm15, xmm15
00007eafdc3d619b  jnz 0x00007EAFDC3D8DC3
00007eafdc3d61a1  vmovaps xmm15, [rsp+0x80]
00007eafdc3d61aa  movaps xmm1, xmm15
00007eafdc3d61ae  addpd xmm1, xmm6
00007eafdc3d61b2  vcmppd xmm2, xmm1, xmm1, 0x03
00007eafdc3d61b7  ptest xmm2, xmm2
00007eafdc3d61bc  jnz 0x00007EAFDC3D8F05
00007eafdc3d61c2  movaps xmm15, xmm5
00007eafdc3d61c6  addpd xmm15, xmm3
00007eafdc3d61cb  vcmppd xmm6, xmm15, xmm15, 0x03
00007eafdc3d61d1  ptest xmm6, xmm6
00007eafdc3d61d6  jnz 0x00007EAFDC3D9046
00007eafdc3d61dc  vmovaps xmm6, [rsp+0x30]
00007eafdc3d61e2  vpermilpd xmm6, xmm6, 0x00
00007eafdc3d61e8  movaps xmm5, xmm8
00007eafdc3d61ec  mulpd xmm5, xmm6
00007eafdc3d61f0  vcmppd xmm3, xmm5, xmm5, 0x03
00007eafdc3d61f5  ptest xmm3, xmm3
00007eafdc3d61fa  jnz 0x00007EAFDC3D9188
00007eafdc3d6200  vmovaps xmm8, [rsp+0x30]
00007eafdc3d6206  vpermilpd xmm8, xmm8, 0x00
00007eafdc3d620c  movaps xmm6, xmm10
00007eafdc3d6210  mulpd xmm6, xmm8
00007eafdc3d6215  vcmppd xmm3, xmm6, xmm6, 0x03
00007eafdc3d621a  ptest xmm3, xmm3
00007eafdc3d621f  jnz 0x00007EAFDC3D92C9
00007eafdc3d6225  vmovaps xmm8, [rsp+0x60]
00007eafdc3d622b  movaps xmm10, xmm8
00007eafdc3d622f  addpd xmm10, xmm14
00007eafdc3d6234  vcmppd xmm3, xmm10, xmm10, 0x03
00007eafdc3d623a  ptest xmm3, xmm3
00007eafdc3d623f  jnz 0x00007EAFDC3D940B
00007eafdc3d6245  vmovaps xmm8, [rsp+0x50]
00007eafdc3d624b  movaps xmm14, xmm8
00007eafdc3d624f  addpd xmm14, xmm4
00007eafdc3d6254  vcmppd xmm3, xmm14, xmm14, 0x03
00007eafdc3d625a  ptest xmm3, xmm3
00007eafdc3d625f  jnz 0x00007EAFDC3D954F
00007eafdc3d6265  vmovaps xmm8, [rsp+0x40]
00007eafdc3d626b  vpermilpd xmm8, xmm8, 0x00
00007eafdc3d6271  movaps xmm4, xmm13
00007eafdc3d6275  mulpd xmm4, xmm8
00007eafdc3d627a  vcmppd xmm3, xmm4, xmm4, 0x03
00007eafdc3d627f  ptest xmm3, xmm3
00007eafdc3d6284  jnz 0x00007EAFDC3D9692
00007eafdc3d628a  movaps xmm13, xmm15
00007eafdc3d628e  addpd xmm13, xmm9
00007eafdc3d6293  vcmppd xmm8, xmm13, xmm13, 0x03
00007eafdc3d6299  ptest xmm8, xmm8
00007eafdc3d629f  jnz 0x00007EAFDC3D97D4
00007eafdc3d62a5  movaps xmm15, xmm1
00007eafdc3d62a9  addpd xmm15, xmm5
00007eafdc3d62ae  vcmppd xmm9, xmm15, xmm15, 0x03
00007eafdc3d62b4  ptest xmm9, xmm9
00007eafdc3d62ba  jnz 0x00007EAFDC3D9918
00007eafdc3d62c0  vmovaps [rsp+0x30], xmm11
00007eafdc3d62c6  vmovaps xmm1, [rsp+0x30]
00007eafdc3d62cc  por xmm11, xmm1
00007eafdc3d62d1  movaps [r15+0x250], xmm11
00007eafdc3d62d9  vmovaps [rsp+0x30], xmm12
00007eafdc3d62df  vmovaps xmm1, [rsp+0x30]
00007eafdc3d62e5  por xmm12, xmm1
00007eafdc3d62ea  movaps [r15+0x2A0], xmm12
00007eafdc3d62f2  vmovaps xmm1, [rsp+0xA0]
00007eafdc3d62fb  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d6304  por xmm1, xmm11
00007eafdc3d6309  movaps [r15+0x1D0], xmm1
00007eafdc3d6311  lea r14, [rax+0x40]
00007eafdc3d6315  movups xmm1, [r13+r14*1]
00007eafdc3d631b  movaps [r15+0x2C0], xmm1
00007eafdc3d6323  vmovaps xmm11, [rsp+0x40]
00007eafdc3d6329  vpermilpd xmm11, xmm11, 0x00
00007eafdc3d632f  vmovaps xmm8, [rsp+0xE0]
00007eafdc3d6338  movaps xmm9, xmm8
00007eafdc3d633c  mulpd xmm9, xmm11
00007eafdc3d6341  vcmppd xmm5, xmm9, xmm9, 0x03
00007eafdc3d6347  ptest xmm5, xmm5
00007eafdc3d634c  jnz 0x00007EAFDC3D9A64
00007eafdc3d6352  movaps xmm11, xmm10
00007eafdc3d6356  addpd xmm11, xmm6
00007eafdc3d635b  vcmppd xmm8, xmm11, xmm11, 0x03
00007eafdc3d6361  ptest xmm8, xmm8
00007eafdc3d6367  jnz 0x00007EAFDC3D9BA8
00007eafdc3d636d  movaps xmm10, xmm14
00007eafdc3d6371  addpd xmm10, xmm4
00007eafdc3d6376  vcmppd xmm8, xmm10, xmm10, 0x03
00007eafdc3d637c  ptest xmm8, xmm8
00007eafdc3d6382  jnz 0x00007EAFDC3D9CEB
00007eafdc3d6388  vmovaps xmm14, [rsp+0x40]
00007eafdc3d638e  vpermilpd xmm14, xmm14, 0x00
00007eafdc3d6394  movaps xmm8, xmm1
00007eafdc3d6398  mulpd xmm8, xmm14
00007eafdc3d639d  vcmppd xmm6, xmm8, xmm8, 0x03
00007eafdc3d63a3  ptest xmm6, xmm6
00007eafdc3d63a8  jnz 0x00007EAFDC3D9E2E
00007eafdc3d63ae  movaps xmm1, [r15+0x2B0]
00007eafdc3d63b6  vmovaps xmm14, [rsp+0x40]
00007eafdc3d63bc  vpermilpd xmm14, xmm14, 0x00
00007eafdc3d63c2  movaps xmm6, xmm1
00007eafdc3d63c5  mulpd xmm6, xmm14
00007eafdc3d63ca  vcmppd xmm5, xmm6, xmm6, 0x03
00007eafdc3d63cf  ptest xmm5, xmm5
00007eafdc3d63d4  jnz 0x00007EAFDC3D9F71
00007eafdc3d63da  vmovaps xmm1, [rsp+0x10]
00007eafdc3d63e0  vpermilpd xmm1, xmm1, 0x00
00007eafdc3d63e6  movaps xmm14, xmm12
00007eafdc3d63ea  mulpd xmm14, xmm1
00007eafdc3d63ef  vcmppd xmm5, xmm14, xmm14, 0x03
00007eafdc3d63f5  ptest xmm5, xmm5
00007eafdc3d63fa  jnz 0x00007EAFDC3DA0B2
00007eafdc3d6400  movaps xmm1, xmm13
00007eafdc3d6404  addpd xmm1, xmm9
00007eafdc3d6409  vcmppd xmm12, xmm1, xmm1, 0x03
00007eafdc3d640e  ptest xmm12, xmm12
00007eafdc3d6414  jnz 0x00007EAFDC3DA1F5
00007eafdc3d641a  vmovaps xmm13, [rsp+0x10]
00007eafdc3d6420  vpermilpd xmm13, xmm13, 0x00
00007eafdc3d6426  movaps xmm12, xmm7
00007eafdc3d642a  mulpd xmm12, xmm13
00007eafdc3d642f  vcmppd xmm9, xmm12, xmm12, 0x03
00007eafdc3d6435  ptest xmm9, xmm9
00007eafdc3d643b  jnz 0x00007EAFDC3DA337
00007eafdc3d6441  movaps xmm13, xmm15
00007eafdc3d6445  addpd xmm13, xmm8
00007eafdc3d644a  vcmppd xmm9, xmm13, xmm13, 0x03
00007eafdc3d6450  ptest xmm9, xmm9
00007eafdc3d6456  jnz 0x00007EAFDC3DA47A
00007eafdc3d645c  movaps xmm15, [r15+0x290]
00007eafdc3d6464  vmovaps xmm9, [rsp+0x10]
00007eafdc3d646a  vpermilpd xmm9, xmm9, 0x00
00007eafdc3d6470  movaps xmm8, xmm15
00007eafdc3d6474  mulpd xmm8, xmm9
00007eafdc3d6479  vcmppd xmm7, xmm8, xmm8, 0x03
00007eafdc3d647f  ptest xmm7, xmm7
00007eafdc3d6484  jnz 0x00007EAFDC3DA5BE
00007eafdc3d648a  movaps xmm15, xmm11
00007eafdc3d648e  addpd xmm15, xmm6
00007eafdc3d6493  vcmppd xmm9, xmm15, xmm15, 0x03
00007eafdc3d6499  ptest xmm9, xmm9
00007eafdc3d649f  jnz 0x00007EAFDC3DA702
00007eafdc3d64a5  movaps xmm11, [r15+0x1E0]
00007eafdc3d64ad  vmovaps xmm9, [rsp+0x10]
00007eafdc3d64b3  vpermilpd xmm9, xmm9, 0x00
00007eafdc3d64b9  movaps xmm7, xmm11
00007eafdc3d64bd  mulpd xmm7, xmm9
00007eafdc3d64c2  vcmppd xmm6, xmm7, xmm7, 0x03
00007eafdc3d64c7  ptest xmm6, xmm6
00007eafdc3d64cc  jnz 0x00007EAFDC3DA845
00007eafdc3d64d2  movaps xmm11, xmm10
00007eafdc3d64d6  addpd xmm11, xmm14
00007eafdc3d64db  vcmppd xmm9, xmm11, xmm11, 0x03
00007eafdc3d64e1  ptest xmm9, xmm9
00007eafdc3d64e7  jnz 0x00007EAFDC3DA987
00007eafdc3d64ed  lea r14, [rax+0x70]
00007eafdc3d64f1  movups xmm14, [r13+r14*1]
00007eafdc3d64f7  movaps [r15+0x240], xmm14
00007eafdc3d64ff  movaps xmm10, xmm1
00007eafdc3d6503  addpd xmm10, xmm12
00007eafdc3d6508  vcmppd xmm9, xmm10, xmm10, 0x03
00007eafdc3d650e  ptest xmm9, xmm9
00007eafdc3d6514  jnz 0x00007EAFDC3DAAD5
00007eafdc3d651a  movaps [r15+0x170], xmm10
00007eafdc3d6522  vmovaps xmm1, [rsp+0x20]
00007eafdc3d6528  vpermilpd xmm1, xmm1, 0x00
00007eafdc3d652e  movaps xmm12, xmm14
00007eafdc3d6532  mulpd xmm12, xmm1
00007eafdc3d6537  vcmppd xmm9, xmm12, xmm12, 0x03
00007eafdc3d653d  ptest xmm9, xmm9
00007eafdc3d6543  jnz 0x00007EAFDC3DAC18
00007eafdc3d6549  vmovaps xmm1, [rsp+0x20]
00007eafdc3d654f  vpermilpd xmm1, xmm1, 0x00
00007eafdc3d6555  vmovaps xmm9, [rsp+0xB0]
00007eafdc3d655e  movaps xmm14, xmm9
00007eafdc3d6562  mulpd xmm14, xmm1
00007eafdc3d6567  vcmppd xmm6, xmm14, xmm14, 0x03
00007eafdc3d656d  ptest xmm6, xmm6
00007eafdc3d6572  jnz 0x00007EAFDC3DAD5B
00007eafdc3d6578  movaps [r15+0x180], xmm14
00007eafdc3d6580  movaps xmm1, xmm13
00007eafdc3d6584  addpd xmm1, xmm8
00007eafdc3d6589  vcmppd xmm9, xmm1, xmm1, 0x03
00007eafdc3d658e  ptest xmm9, xmm9
00007eafdc3d6594  jnz 0x00007EAFDC3DAE9E
00007eafdc3d659a  movaps [r15+0x210], xmm1
00007eafdc3d65a2  movups xmm13, [r13+rax*1]
00007eafdc3d65a8  lea r14, [rax+0x10]
00007eafdc3d65ac  movups xmm9, [r13+r14*1]
00007eafdc3d65b2  movaps [r15+0x230], xmm9
00007eafdc3d65ba  movaps xmm8, xmm15
00007eafdc3d65be  addpd xmm8, xmm7
00007eafdc3d65c3  vcmppd xmm6, xmm8, xmm8, 0x03
00007eafdc3d65c9  ptest xmm6, xmm6
00007eafdc3d65ce  jnz 0x00007EAFDC3DAFF4
00007eafdc3d65d4  movaps [r15+0x130], xmm8
00007eafdc3d65dc  vmovaps xmm15, [rsp+0x20]
00007eafdc3d65e2  vpermilpd xmm15, xmm15, 0x00
00007eafdc3d65e8  movaps xmm7, xmm9
00007eafdc3d65ec  mulpd xmm7, xmm15
00007eafdc3d65f1  vcmppd xmm6, xmm7, xmm7, 0x03
00007eafdc3d65f6  ptest xmm6, xmm6
00007eafdc3d65fb  jnz 0x00007EAFDC3DB137
00007eafdc3d6601  movaps [r15+0x220], xmm7
00007eafdc3d6609  vmovaps xmm15, [rsp+0x20]
00007eafdc3d660f  vpermilpd xmm15, xmm15, 0x00
00007eafdc3d6615  movaps xmm9, xmm13
00007eafdc3d6619  mulpd xmm9, xmm15
00007eafdc3d661e  vcmppd xmm6, xmm9, xmm9, 0x03
00007eafdc3d6624  ptest xmm6, xmm6
00007eafdc3d6629  jnz 0x00007EAFDC3DB279
00007eafdc3d662f  movaps xmm15, xmm11
00007eafdc3d6633  addpd xmm15, xmm12
00007eafdc3d6638  vcmppd xmm13, xmm15, xmm15, 0x03
00007eafdc3d663e  ptest xmm13, xmm13
00007eafdc3d6644  jnz 0x00007EAFDC3DB3BD
00007eafdc3d664a  movaps [r15+0x140], xmm15
00007eafdc3d6652  movaps xmm13, xmm10
00007eafdc3d6656  addpd xmm13, xmm14
00007eafdc3d665b  vcmppd xmm12, xmm13, xmm13, 0x03
00007eafdc3d6661  ptest xmm12, xmm12
00007eafdc3d6667  jnz 0x00007EAFDC3DB501
00007eafdc3d666d  movaps [r15+0x150], xmm13
00007eafdc3d6675  movaps xmm14, xmm1
00007eafdc3d6679  addpd xmm14, xmm7
00007eafdc3d667e  vcmppd xmm12, xmm14, xmm14, 0x03
00007eafdc3d6684  ptest xmm12, xmm12
00007eafdc3d668a  jnz 0x00007EAFDC3DB645
00007eafdc3d6690  movaps [r15+0x160], xmm14
00007eafdc3d6698  movaps xmm1, xmm8
00007eafdc3d669c  addpd xmm1, xmm9
00007eafdc3d66a1  vcmppd xmm12, xmm1, xmm1, 0x03
00007eafdc3d66a6  ptest xmm12, xmm12
00007eafdc3d66ac  jnz 0x00007EAFDC3DB787
00007eafdc3d66b2  movaps [r15+0x120], xmm1
00007eafdc3d66ba  movups [r13+r11*1], xmm15
00007eafdc3d66c0  lea rax, [r11+0x10]
00007eafdc3d66c4  movups [r13+rax*1], xmm13
00007eafdc3d66ca  lea rax, [r11+0x20]
00007eafdc3d66ce  movups [r13+rax*1], xmm14
00007eafdc3d66d4  lea rax, [r11+0x30]
00007eafdc3d66d8  movups [r13+rax*1], xmm1
00007eafdc3d66de  mov eax, [r15+0x108]
00007eafdc3d66e5  sahf
00007eafdc3d66e6  jnz 0x00007EAFDC3D6718
00007eafdc3d66e8  cmp dword ptr [r15+0x318], 0x00
00007eafdc3d66f0  jz 0x00007EAFDC3DB900
00007eafdc3d66f6  nop [rax+rax*1], ax
00007eafdc3d66ff  nop [rax+rax*1], eax
00007eafdc3d6707  mov eax, 0x410444
00007eafdc3d670c  mov [r15+0x100], rax
00007eafdc3d6713  jmp 0x00007EAFDC1FE110
00007eafdc3d6718  cmp dword ptr [r15+0x318], 0x00
00007eafdc3d6720  jz 0x00007EAFDC3D57E0
00007eafdc3d6726  nop [rax+rax*1], ax
00007eafdc3d672f  nop [rax+rax*1], eax
00007eafdc3d6737  mov eax, 0x410278
00007eafdc3d673c  mov [r15+0x100], rax
00007eafdc3d6743  jmp 0x00007EAFDC1FE110
00007eafdc3d6748  int3
00007eafdc3d6749  call 0x00007EAFDC20A4B0
00007eafdc3d674e  jmp 0x00007EAFDC3D5828
00007eafdc3d6753  call 0x00007EAFDC209240
00007eafdc3d6758  jmp 0x00007EAFDC3D5832
00007eafdc3d675d  call 0x00007EAFDC20A4B0
00007eafdc3d6762  jmp 0x00007EAFDC3D588F
00007eafdc3d6767  call 0x00007EAFDC209240
00007eafdc3d676c  jmp 0x00007EAFDC3D5899
00007eafdc3d6771  call 0x00007EAFDC20A4B0
00007eafdc3d6776  jmp 0x00007EAFDC3D58DD
00007eafdc3d677b  call 0x00007EAFDC209240
00007eafdc3d6780  jmp 0x00007EAFDC3D58E7
00007eafdc3d6785  call 0x00007EAFDC2B47C0
00007eafdc3d678a  jmp 0x00007EAFDC3D5926
00007eafdc3d678f  call 0x00007EAFDC20B720
00007eafdc3d6794  jmp 0x00007EAFDC3D593A
00007eafdc3d6799  call 0x00007EAFDC2BFC30
00007eafdc3d679e  jmp 0x00007EAFDC3D5958
00007eafdc3d67a3  call 0x00007EAFDC2BE9C0
00007eafdc3d67a8  jmp 0x00007EAFDC3D5962
00007eafdc3d67ad  call 0x00007EAFDC2BD750
00007eafdc3d67b2  jmp 0x00007EAFDC3D596C
00007eafdc3d67b7  sub rsp, 0x08
00007eafdc3d67bb  push rax
00007eafdc3d67bc  push rcx
00007eafdc3d67bd  push rdx
00007eafdc3d67be  push rdi
00007eafdc3d67bf  push rsi
00007eafdc3d67c0  push r8
00007eafdc3d67c2  push r9
00007eafdc3d67c4  push r10
00007eafdc3d67c6  push r11
00007eafdc3d67c8  sub rsp, 0xF0
00007eafdc3d67cf  vmovaps [rsp], xmm0
00007eafdc3d67d4  vmovaps [rsp+0x10], xmm1
00007eafdc3d67da  vmovaps [rsp+0x20], xmm2
00007eafdc3d67e0  vmovaps [rsp+0x30], xmm3
00007eafdc3d67e6  vmovaps [rsp+0x40], xmm4
00007eafdc3d67ec  vmovaps [rsp+0x50], xmm5
00007eafdc3d67f2  vmovaps [rsp+0x60], xmm6
00007eafdc3d67f8  vmovaps [rsp+0x70], xmm7
00007eafdc3d67fe  vmovaps [rsp+0x80], xmm9
00007eafdc3d6807  vmovaps [rsp+0x90], xmm10
00007eafdc3d6810  vmovaps [rsp+0xA0], xmm11
00007eafdc3d6819  vmovaps [rsp+0xB0], xmm12
00007eafdc3d6822  vmovaps [rsp+0xC0], xmm13
00007eafdc3d682b  vmovaps [rsp+0xD0], xmm14
00007eafdc3d6834  vmovaps [rsp+0xE0], xmm15
00007eafdc3d683d  sub rsp, 0x30
00007eafdc3d6841  movaps [rsp], xmm8
00007eafdc3d6846  movaps [rsp+0x10], xmm12
00007eafdc3d684c  movaps [rsp+0x20], xmm15
00007eafdc3d6852  lea rdi, [rsp]
00007eafdc3d6856  mov esi, 0x00
00007eafdc3d685b  mov rax, 0x645891675530
00007eafdc3d6865  call rax
00007eafdc3d6867  movaps xmm8, [rsp]
00007eafdc3d686c  add rsp, 0x30
00007eafdc3d6870  vmovaps xmm0, [rsp]
00007eafdc3d6875  vmovaps xmm1, [rsp+0x10]
00007eafdc3d687b  vmovaps xmm2, [rsp+0x20]
00007eafdc3d6881  vmovaps xmm3, [rsp+0x30]
00007eafdc3d6887  vmovaps xmm4, [rsp+0x40]
00007eafdc3d688d  vmovaps xmm5, [rsp+0x50]
00007eafdc3d6893  vmovaps xmm6, [rsp+0x60]
00007eafdc3d6899  vmovaps xmm7, [rsp+0x70]
00007eafdc3d689f  vmovaps xmm9, [rsp+0x80]
00007eafdc3d68a8  vmovaps xmm10, [rsp+0x90]
00007eafdc3d68b1  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d68ba  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d68c3  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d68cc  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d68d5  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d68de  add rsp, 0xF0
00007eafdc3d68e5  pop r11
00007eafdc3d68e7  pop r10
00007eafdc3d68e9  pop r9
00007eafdc3d68eb  pop r8
00007eafdc3d68ed  pop rsi
00007eafdc3d68ee  pop rdi
00007eafdc3d68ef  pop rdx
00007eafdc3d68f0  pop rcx
00007eafdc3d68f1  pop rax
00007eafdc3d68f2  add rsp, 0x08
00007eafdc3d68f6  jmp 0x00007EAFDC3D599A
00007eafdc3d68fb  sub rsp, 0x08
00007eafdc3d68ff  push rax
00007eafdc3d6900  push rcx
00007eafdc3d6901  push rdx
00007eafdc3d6902  push rdi
00007eafdc3d6903  push rsi
00007eafdc3d6904  push r8
00007eafdc3d6906  push r9
00007eafdc3d6908  push r10
00007eafdc3d690a  push r11
00007eafdc3d690c  sub rsp, 0xF0
00007eafdc3d6913  vmovaps [rsp], xmm0
00007eafdc3d6918  vmovaps [rsp+0x10], xmm1
00007eafdc3d691e  vmovaps [rsp+0x20], xmm2
00007eafdc3d6924  vmovaps [rsp+0x30], xmm3
00007eafdc3d692a  vmovaps [rsp+0x40], xmm4
00007eafdc3d6930  vmovaps [rsp+0x50], xmm5
00007eafdc3d6936  vmovaps [rsp+0x60], xmm6
00007eafdc3d693c  vmovaps [rsp+0x70], xmm8
00007eafdc3d6942  vmovaps [rsp+0x80], xmm9
00007eafdc3d694b  vmovaps [rsp+0x90], xmm10
00007eafdc3d6954  vmovaps [rsp+0xA0], xmm11
00007eafdc3d695d  vmovaps [rsp+0xB0], xmm12
00007eafdc3d6966  vmovaps [rsp+0xC0], xmm13
00007eafdc3d696f  vmovaps [rsp+0xD0], xmm14
00007eafdc3d6978  vmovaps [rsp+0xE0], xmm15
00007eafdc3d6981  sub rsp, 0x30
00007eafdc3d6985  movaps [rsp], xmm7
00007eafdc3d6989  movaps [rsp+0x10], xmm9
00007eafdc3d698f  movaps [rsp+0x20], xmm15
00007eafdc3d6995  lea rdi, [rsp]
00007eafdc3d6999  mov esi, 0x00
00007eafdc3d699e  mov rax, 0x645891675530
00007eafdc3d69a8  call rax
00007eafdc3d69aa  movaps xmm7, [rsp]
00007eafdc3d69ae  add rsp, 0x30
00007eafdc3d69b2  vmovaps xmm0, [rsp]
00007eafdc3d69b7  vmovaps xmm1, [rsp+0x10]
00007eafdc3d69bd  vmovaps xmm2, [rsp+0x20]
00007eafdc3d69c3  vmovaps xmm3, [rsp+0x30]
00007eafdc3d69c9  vmovaps xmm4, [rsp+0x40]
00007eafdc3d69cf  vmovaps xmm5, [rsp+0x50]
00007eafdc3d69d5  vmovaps xmm6, [rsp+0x60]
00007eafdc3d69db  vmovaps xmm8, [rsp+0x70]
00007eafdc3d69e1  vmovaps xmm9, [rsp+0x80]
00007eafdc3d69ea  vmovaps xmm10, [rsp+0x90]
00007eafdc3d69f3  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d69fc  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d6a05  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d6a0e  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d6a17  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d6a20  add rsp, 0xF0
00007eafdc3d6a27  pop r11
00007eafdc3d6a29  pop r10
00007eafdc3d6a2b  pop r9
00007eafdc3d6a2d  pop r8
00007eafdc3d6a2f  pop rsi
00007eafdc3d6a30  pop rdi
00007eafdc3d6a31  pop rdx
00007eafdc3d6a32  pop rcx
00007eafdc3d6a33  pop rax
00007eafdc3d6a34  add rsp, 0x08
00007eafdc3d6a38  jmp 0x00007EAFDC3D59C8
00007eafdc3d6a3d  sub rsp, 0x08
00007eafdc3d6a41  push rax
00007eafdc3d6a42  push rcx
00007eafdc3d6a43  push rdx
00007eafdc3d6a44  push rdi
00007eafdc3d6a45  push rsi
00007eafdc3d6a46  push r8
00007eafdc3d6a48  push r9
00007eafdc3d6a4a  push r10
00007eafdc3d6a4c  push r11
00007eafdc3d6a4e  sub rsp, 0xF0
00007eafdc3d6a55  vmovaps [rsp], xmm0
00007eafdc3d6a5a  vmovaps [rsp+0x10], xmm1
00007eafdc3d6a60  vmovaps [rsp+0x20], xmm2
00007eafdc3d6a66  vmovaps [rsp+0x30], xmm3
00007eafdc3d6a6c  vmovaps [rsp+0x40], xmm4
00007eafdc3d6a72  vmovaps [rsp+0x50], xmm5
00007eafdc3d6a78  vmovaps [rsp+0x60], xmm6
00007eafdc3d6a7e  vmovaps [rsp+0x70], xmm7
00007eafdc3d6a84  vmovaps [rsp+0x80], xmm8
00007eafdc3d6a8d  vmovaps [rsp+0x90], xmm10
00007eafdc3d6a96  vmovaps [rsp+0xA0], xmm11
00007eafdc3d6a9f  vmovaps [rsp+0xB0], xmm12
00007eafdc3d6aa8  vmovaps [rsp+0xC0], xmm13
00007eafdc3d6ab1  vmovaps [rsp+0xD0], xmm14
00007eafdc3d6aba  vmovaps [rsp+0xE0], xmm15
00007eafdc3d6ac3  sub rsp, 0x30
00007eafdc3d6ac7  movaps [rsp], xmm9
00007eafdc3d6acc  movaps [rsp+0x10], xmm12
00007eafdc3d6ad2  movaps [rsp+0x20], xmm10
00007eafdc3d6ad8  lea rdi, [rsp]
00007eafdc3d6adc  mov esi, 0x00
00007eafdc3d6ae1  mov rax, 0x645891675530
00007eafdc3d6aeb  call rax
00007eafdc3d6aed  movaps xmm9, [rsp]
00007eafdc3d6af2  add rsp, 0x30
00007eafdc3d6af6  vmovaps xmm0, [rsp]
00007eafdc3d6afb  vmovaps xmm1, [rsp+0x10]
00007eafdc3d6b01  vmovaps xmm2, [rsp+0x20]
00007eafdc3d6b07  vmovaps xmm3, [rsp+0x30]
00007eafdc3d6b0d  vmovaps xmm4, [rsp+0x40]
00007eafdc3d6b13  vmovaps xmm5, [rsp+0x50]
00007eafdc3d6b19  vmovaps xmm6, [rsp+0x60]
00007eafdc3d6b1f  vmovaps xmm7, [rsp+0x70]
00007eafdc3d6b25  vmovaps xmm8, [rsp+0x80]
00007eafdc3d6b2e  vmovaps xmm10, [rsp+0x90]
00007eafdc3d6b37  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d6b40  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d6b49  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d6b52  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d6b5b  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d6b64  add rsp, 0xF0
00007eafdc3d6b6b  pop r11
00007eafdc3d6b6d  pop r10
00007eafdc3d6b6f  pop r9
00007eafdc3d6b71  pop r8
00007eafdc3d6b73  pop rsi
00007eafdc3d6b74  pop rdi
00007eafdc3d6b75  pop rdx
00007eafdc3d6b76  pop rcx
00007eafdc3d6b77  pop rax
00007eafdc3d6b78  add rsp, 0x08
00007eafdc3d6b7c  jmp 0x00007EAFDC3D59EC
00007eafdc3d6b81  sub rsp, 0x08
00007eafdc3d6b85  push rax
00007eafdc3d6b86  push rcx
00007eafdc3d6b87  push rdx
00007eafdc3d6b88  push rdi
00007eafdc3d6b89  push rsi
00007eafdc3d6b8a  push r8
00007eafdc3d6b8c  push r9
00007eafdc3d6b8e  push r10
00007eafdc3d6b90  push r11
00007eafdc3d6b92  sub rsp, 0xF0
00007eafdc3d6b99  vmovaps [rsp], xmm0
00007eafdc3d6b9e  vmovaps [rsp+0x10], xmm1
00007eafdc3d6ba4  vmovaps [rsp+0x20], xmm2
00007eafdc3d6baa  vmovaps [rsp+0x30], xmm3
00007eafdc3d6bb0  vmovaps [rsp+0x40], xmm4
00007eafdc3d6bb6  vmovaps [rsp+0x50], xmm5
00007eafdc3d6bbc  vmovaps [rsp+0x60], xmm6
00007eafdc3d6bc2  vmovaps [rsp+0x70], xmm7
00007eafdc3d6bc8  vmovaps [rsp+0x80], xmm8
00007eafdc3d6bd1  vmovaps [rsp+0x90], xmm9
00007eafdc3d6bda  vmovaps [rsp+0xA0], xmm11
00007eafdc3d6be3  vmovaps [rsp+0xB0], xmm12
00007eafdc3d6bec  vmovaps [rsp+0xC0], xmm13
00007eafdc3d6bf5  vmovaps [rsp+0xD0], xmm14
00007eafdc3d6bfe  vmovaps [rsp+0xE0], xmm15
00007eafdc3d6c07  sub rsp, 0x30
00007eafdc3d6c0b  movaps [rsp], xmm10
00007eafdc3d6c10  movaps [rsp+0x10], xmm12
00007eafdc3d6c16  movaps [rsp+0x20], xmm11
00007eafdc3d6c1c  lea rdi, [rsp]
00007eafdc3d6c20  mov esi, 0x00
00007eafdc3d6c25  mov rax, 0x645891675530
00007eafdc3d6c2f  call rax
00007eafdc3d6c31  movaps xmm10, [rsp]
00007eafdc3d6c36  add rsp, 0x30
00007eafdc3d6c3a  vmovaps xmm0, [rsp]
00007eafdc3d6c3f  vmovaps xmm1, [rsp+0x10]
00007eafdc3d6c45  vmovaps xmm2, [rsp+0x20]
00007eafdc3d6c4b  vmovaps xmm3, [rsp+0x30]
00007eafdc3d6c51  vmovaps xmm4, [rsp+0x40]
00007eafdc3d6c57  vmovaps xmm5, [rsp+0x50]
00007eafdc3d6c5d  vmovaps xmm6, [rsp+0x60]
00007eafdc3d6c63  vmovaps xmm7, [rsp+0x70]
00007eafdc3d6c69  vmovaps xmm8, [rsp+0x80]
00007eafdc3d6c72  vmovaps xmm9, [rsp+0x90]
00007eafdc3d6c7b  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d6c84  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d6c8d  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d6c96  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d6c9f  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d6ca8  add rsp, 0xF0
00007eafdc3d6caf  pop r11
00007eafdc3d6cb1  pop r10
00007eafdc3d6cb3  pop r9
00007eafdc3d6cb5  pop r8
00007eafdc3d6cb7  pop rsi
00007eafdc3d6cb8  pop rdi
00007eafdc3d6cb9  pop rdx
00007eafdc3d6cba  pop rcx
00007eafdc3d6cbb  pop rax
00007eafdc3d6cbc  add rsp, 0x08
00007eafdc3d6cc0  jmp 0x00007EAFDC3D5A06
00007eafdc3d6cc5  sub rsp, 0x08
00007eafdc3d6cc9  push rax
00007eafdc3d6cca  push rcx
00007eafdc3d6ccb  push rdx
00007eafdc3d6ccc  push rdi
00007eafdc3d6ccd  push rsi
00007eafdc3d6cce  push r8
00007eafdc3d6cd0  push r9
00007eafdc3d6cd2  push r10
00007eafdc3d6cd4  push r11
00007eafdc3d6cd6  sub rsp, 0xF0
00007eafdc3d6cdd  vmovaps [rsp], xmm0
00007eafdc3d6ce2  vmovaps [rsp+0x10], xmm1
00007eafdc3d6ce8  vmovaps [rsp+0x20], xmm2
00007eafdc3d6cee  vmovaps [rsp+0x30], xmm3
00007eafdc3d6cf4  vmovaps [rsp+0x40], xmm4
00007eafdc3d6cfa  vmovaps [rsp+0x50], xmm5
00007eafdc3d6d00  vmovaps [rsp+0x60], xmm7
00007eafdc3d6d06  vmovaps [rsp+0x70], xmm8
00007eafdc3d6d0c  vmovaps [rsp+0x80], xmm9
00007eafdc3d6d15  vmovaps [rsp+0x90], xmm10
00007eafdc3d6d1e  vmovaps [rsp+0xA0], xmm11
00007eafdc3d6d27  vmovaps [rsp+0xB0], xmm12
00007eafdc3d6d30  vmovaps [rsp+0xC0], xmm13
00007eafdc3d6d39  vmovaps [rsp+0xD0], xmm14
00007eafdc3d6d42  vmovaps [rsp+0xE0], xmm15
00007eafdc3d6d4b  sub rsp, 0x30
00007eafdc3d6d4f  movaps [rsp], xmm6
00007eafdc3d6d53  movaps [rsp+0x10], xmm12
00007eafdc3d6d59  movaps [rsp+0x20], xmm11
00007eafdc3d6d5f  lea rdi, [rsp]
00007eafdc3d6d63  mov esi, 0x00
00007eafdc3d6d68  mov rax, 0x645891675530
00007eafdc3d6d72  call rax
00007eafdc3d6d74  movaps xmm6, [rsp]
00007eafdc3d6d78  add rsp, 0x30
00007eafdc3d6d7c  vmovaps xmm0, [rsp]
00007eafdc3d6d81  vmovaps xmm1, [rsp+0x10]
00007eafdc3d6d87  vmovaps xmm2, [rsp+0x20]
00007eafdc3d6d8d  vmovaps xmm3, [rsp+0x30]
00007eafdc3d6d93  vmovaps xmm4, [rsp+0x40]
00007eafdc3d6d99  vmovaps xmm5, [rsp+0x50]
00007eafdc3d6d9f  vmovaps xmm7, [rsp+0x60]
00007eafdc3d6da5  vmovaps xmm8, [rsp+0x70]
00007eafdc3d6dab  vmovaps xmm9, [rsp+0x80]
00007eafdc3d6db4  vmovaps xmm10, [rsp+0x90]
00007eafdc3d6dbd  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d6dc6  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d6dcf  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d6dd8  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d6de1  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d6dea  add rsp, 0xF0
00007eafdc3d6df1  pop r11
00007eafdc3d6df3  pop r10
00007eafdc3d6df5  pop r9
00007eafdc3d6df7  pop r8
00007eafdc3d6df9  pop rsi
00007eafdc3d6dfa  pop rdi
00007eafdc3d6dfb  pop rdx
00007eafdc3d6dfc  pop rcx
00007eafdc3d6dfd  pop rax
00007eafdc3d6dfe  add rsp, 0x08
00007eafdc3d6e02  jmp 0x00007EAFDC3D5A27
00007eafdc3d6e07  sub rsp, 0x08
00007eafdc3d6e0b  push rax
00007eafdc3d6e0c  push rcx
00007eafdc3d6e0d  push rdx
00007eafdc3d6e0e  push rdi
00007eafdc3d6e0f  push rsi
00007eafdc3d6e10  push r8
00007eafdc3d6e12  push r9
00007eafdc3d6e14  push r10
00007eafdc3d6e16  push r11
00007eafdc3d6e18  sub rsp, 0xF0
00007eafdc3d6e1f  vmovaps [rsp], xmm0
00007eafdc3d6e24  vmovaps [rsp+0x10], xmm1
00007eafdc3d6e2a  vmovaps [rsp+0x20], xmm2
00007eafdc3d6e30  vmovaps [rsp+0x30], xmm4
00007eafdc3d6e36  vmovaps [rsp+0x40], xmm5
00007eafdc3d6e3c  vmovaps [rsp+0x50], xmm6
00007eafdc3d6e42  vmovaps [rsp+0x60], xmm7
00007eafdc3d6e48  vmovaps [rsp+0x70], xmm8
00007eafdc3d6e4e  vmovaps [rsp+0x80], xmm9
00007eafdc3d6e57  vmovaps [rsp+0x90], xmm10
00007eafdc3d6e60  vmovaps [rsp+0xA0], xmm11
00007eafdc3d6e69  vmovaps [rsp+0xB0], xmm12
00007eafdc3d6e72  vmovaps [rsp+0xC0], xmm13
00007eafdc3d6e7b  vmovaps [rsp+0xD0], xmm14
00007eafdc3d6e84  vmovaps [rsp+0xE0], xmm15
00007eafdc3d6e8d  sub rsp, 0x30
00007eafdc3d6e91  movaps [rsp], xmm3
00007eafdc3d6e95  movaps [rsp+0x10], xmm5
00007eafdc3d6e9a  movaps [rsp+0x20], xmm4
00007eafdc3d6e9f  lea rdi, [rsp]
00007eafdc3d6ea3  mov esi, 0x00
00007eafdc3d6ea8  mov rax, 0x645891675530
00007eafdc3d6eb2  call rax
00007eafdc3d6eb4  movaps xmm3, [rsp]
00007eafdc3d6eb8  add rsp, 0x30
00007eafdc3d6ebc  vmovaps xmm0, [rsp]
00007eafdc3d6ec1  vmovaps xmm1, [rsp+0x10]
00007eafdc3d6ec7  vmovaps xmm2, [rsp+0x20]
00007eafdc3d6ecd  vmovaps xmm4, [rsp+0x30]
00007eafdc3d6ed3  vmovaps xmm5, [rsp+0x40]
00007eafdc3d6ed9  vmovaps xmm6, [rsp+0x50]
00007eafdc3d6edf  vmovaps xmm7, [rsp+0x60]
00007eafdc3d6ee5  vmovaps xmm8, [rsp+0x70]
00007eafdc3d6eeb  vmovaps xmm9, [rsp+0x80]
00007eafdc3d6ef4  vmovaps xmm10, [rsp+0x90]
00007eafdc3d6efd  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d6f06  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d6f0f  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d6f18  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d6f21  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d6f2a  add rsp, 0xF0
00007eafdc3d6f31  pop r11
00007eafdc3d6f33  pop r10
00007eafdc3d6f35  pop r9
00007eafdc3d6f37  pop r8
00007eafdc3d6f39  pop rsi
00007eafdc3d6f3a  pop rdi
00007eafdc3d6f3b  pop rdx
00007eafdc3d6f3c  pop rcx
00007eafdc3d6f3d  pop rax
00007eafdc3d6f3e  add rsp, 0x08
00007eafdc3d6f42  jmp 0x00007EAFDC3D5A88
00007eafdc3d6f47  sub rsp, 0x08
00007eafdc3d6f4b  push rax
00007eafdc3d6f4c  push rcx
00007eafdc3d6f4d  push rdx
00007eafdc3d6f4e  push rdi
00007eafdc3d6f4f  push rsi
00007eafdc3d6f50  push r8
00007eafdc3d6f52  push r9
00007eafdc3d6f54  push r10
00007eafdc3d6f56  push r11
00007eafdc3d6f58  sub rsp, 0xF0
00007eafdc3d6f5f  vmovaps [rsp], xmm0
00007eafdc3d6f64  vmovaps [rsp+0x10], xmm1
00007eafdc3d6f6a  vmovaps [rsp+0x20], xmm2
00007eafdc3d6f70  vmovaps [rsp+0x30], xmm3
00007eafdc3d6f76  vmovaps [rsp+0x40], xmm4
00007eafdc3d6f7c  vmovaps [rsp+0x50], xmm6
00007eafdc3d6f82  vmovaps [rsp+0x60], xmm7
00007eafdc3d6f88  vmovaps [rsp+0x70], xmm8
00007eafdc3d6f8e  vmovaps [rsp+0x80], xmm9
00007eafdc3d6f97  vmovaps [rsp+0x90], xmm10
00007eafdc3d6fa0  vmovaps [rsp+0xA0], xmm11
00007eafdc3d6fa9  vmovaps [rsp+0xB0], xmm12
00007eafdc3d6fb2  vmovaps [rsp+0xC0], xmm13
00007eafdc3d6fbb  vmovaps [rsp+0xD0], xmm14
00007eafdc3d6fc4  vmovaps [rsp+0xE0], xmm15
00007eafdc3d6fcd  sub rsp, 0x30
00007eafdc3d6fd1  movaps [rsp], xmm5
00007eafdc3d6fd5  movaps [rsp+0x10], xmm8
00007eafdc3d6fdb  movaps [rsp+0x20], xmm15
00007eafdc3d6fe1  lea rdi, [rsp]
00007eafdc3d6fe5  mov esi, 0x00
00007eafdc3d6fea  mov rax, 0x645891675530
00007eafdc3d6ff4  call rax
00007eafdc3d6ff6  movaps xmm5, [rsp]
00007eafdc3d6ffa  add rsp, 0x30
00007eafdc3d6ffe  vmovaps xmm0, [rsp]
00007eafdc3d7003  vmovaps xmm1, [rsp+0x10]
00007eafdc3d7009  vmovaps xmm2, [rsp+0x20]
00007eafdc3d700f  vmovaps xmm3, [rsp+0x30]
00007eafdc3d7015  vmovaps xmm4, [rsp+0x40]
00007eafdc3d701b  vmovaps xmm6, [rsp+0x50]
00007eafdc3d7021  vmovaps xmm7, [rsp+0x60]
00007eafdc3d7027  vmovaps xmm8, [rsp+0x70]
00007eafdc3d702d  vmovaps xmm9, [rsp+0x80]
00007eafdc3d7036  vmovaps xmm10, [rsp+0x90]
00007eafdc3d703f  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d7048  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d7051  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d705a  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d7063  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d706c  add rsp, 0xF0
00007eafdc3d7073  pop r11
00007eafdc3d7075  pop r10
00007eafdc3d7077  pop r9
00007eafdc3d7079  pop r8
00007eafdc3d707b  pop rsi
00007eafdc3d707c  pop rdi
00007eafdc3d707d  pop rdx
00007eafdc3d707e  pop rcx
00007eafdc3d707f  pop rax
00007eafdc3d7080  add rsp, 0x08
00007eafdc3d7084  jmp 0x00007EAFDC3D5AC0
00007eafdc3d7089  sub rsp, 0x08
00007eafdc3d708d  push rax
00007eafdc3d708e  push rcx
00007eafdc3d708f  push rdx
00007eafdc3d7090  push rdi
00007eafdc3d7091  push rsi
00007eafdc3d7092  push r8
00007eafdc3d7094  push r9
00007eafdc3d7096  push r10
00007eafdc3d7098  push r11
00007eafdc3d709a  sub rsp, 0xF0
00007eafdc3d70a1  vmovaps [rsp], xmm0
00007eafdc3d70a6  vmovaps [rsp+0x10], xmm1
00007eafdc3d70ac  vmovaps [rsp+0x20], xmm2
00007eafdc3d70b2  vmovaps [rsp+0x30], xmm3
00007eafdc3d70b8  vmovaps [rsp+0x40], xmm5
00007eafdc3d70be  vmovaps [rsp+0x50], xmm6
00007eafdc3d70c4  vmovaps [rsp+0x60], xmm7
00007eafdc3d70ca  vmovaps [rsp+0x70], xmm8
00007eafdc3d70d0  vmovaps [rsp+0x80], xmm9
00007eafdc3d70d9  vmovaps [rsp+0x90], xmm10
00007eafdc3d70e2  vmovaps [rsp+0xA0], xmm11
00007eafdc3d70eb  vmovaps [rsp+0xB0], xmm12
00007eafdc3d70f4  vmovaps [rsp+0xC0], xmm13
00007eafdc3d70fd  vmovaps [rsp+0xD0], xmm14
00007eafdc3d7106  vmovaps [rsp+0xE0], xmm15
00007eafdc3d710f  sub rsp, 0x30
00007eafdc3d7113  movaps [rsp], xmm4
00007eafdc3d7117  movaps [rsp+0x10], xmm9
00007eafdc3d711d  movaps [rsp+0x20], xmm8
00007eafdc3d7123  lea rdi, [rsp]
00007eafdc3d7127  mov esi, 0x00
00007eafdc3d712c  mov rax, 0x645891675530
00007eafdc3d7136  call rax
00007eafdc3d7138  movaps xmm4, [rsp]
00007eafdc3d713c  add rsp, 0x30
00007eafdc3d7140  vmovaps xmm0, [rsp]
00007eafdc3d7145  vmovaps xmm1, [rsp+0x10]
00007eafdc3d714b  vmovaps xmm2, [rsp+0x20]
00007eafdc3d7151  vmovaps xmm3, [rsp+0x30]
00007eafdc3d7157  vmovaps xmm5, [rsp+0x40]
00007eafdc3d715d  vmovaps xmm6, [rsp+0x50]
00007eafdc3d7163  vmovaps xmm7, [rsp+0x60]
00007eafdc3d7169  vmovaps xmm8, [rsp+0x70]
00007eafdc3d716f  vmovaps xmm9, [rsp+0x80]
00007eafdc3d7178  vmovaps xmm10, [rsp+0x90]
00007eafdc3d7181  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d718a  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d7193  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d719c  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d71a5  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d71ae  add rsp, 0xF0
00007eafdc3d71b5  pop r11
00007eafdc3d71b7  pop r10
00007eafdc3d71b9  pop r9
00007eafdc3d71bb  pop r8
00007eafdc3d71bd  pop rsi
00007eafdc3d71be  pop rdi
00007eafdc3d71bf  pop rdx
00007eafdc3d71c0  pop rcx
00007eafdc3d71c1  pop rax
00007eafdc3d71c2  add rsp, 0x08
00007eafdc3d71c6  jmp 0x00007EAFDC3D5AE1
00007eafdc3d71cb  sub rsp, 0x08
00007eafdc3d71cf  push rax
00007eafdc3d71d0  push rcx
00007eafdc3d71d1  push rdx
00007eafdc3d71d2  push rdi
00007eafdc3d71d3  push rsi
00007eafdc3d71d4  push r8
00007eafdc3d71d6  push r9
00007eafdc3d71d8  push r10
00007eafdc3d71da  push r11
00007eafdc3d71dc  sub rsp, 0xF0
00007eafdc3d71e3  vmovaps [rsp], xmm0
00007eafdc3d71e8  vmovaps [rsp+0x10], xmm1
00007eafdc3d71ee  vmovaps [rsp+0x20], xmm2
00007eafdc3d71f4  vmovaps [rsp+0x30], xmm3
00007eafdc3d71fa  vmovaps [rsp+0x40], xmm4
00007eafdc3d7200  vmovaps [rsp+0x50], xmm5
00007eafdc3d7206  vmovaps [rsp+0x60], xmm6
00007eafdc3d720c  vmovaps [rsp+0x70], xmm7
00007eafdc3d7212  vmovaps [rsp+0x80], xmm8
00007eafdc3d721b  vmovaps [rsp+0x90], xmm10
00007eafdc3d7224  vmovaps [rsp+0xA0], xmm11
00007eafdc3d722d  vmovaps [rsp+0xB0], xmm12
00007eafdc3d7236  vmovaps [rsp+0xC0], xmm13
00007eafdc3d723f  vmovaps [rsp+0xD0], xmm14
00007eafdc3d7248  vmovaps [rsp+0xE0], xmm15
00007eafdc3d7251  sub rsp, 0x30
00007eafdc3d7255  movaps [rsp], xmm9
00007eafdc3d725a  movaps [rsp+0x10], xmm10
00007eafdc3d7260  movaps [rsp+0x20], xmm8
00007eafdc3d7266  lea rdi, [rsp]
00007eafdc3d726a  mov esi, 0x00
00007eafdc3d726f  mov rax, 0x645891675530
00007eafdc3d7279  call rax
00007eafdc3d727b  movaps xmm9, [rsp]
00007eafdc3d7280  add rsp, 0x30
00007eafdc3d7284  vmovaps xmm0, [rsp]
00007eafdc3d7289  vmovaps xmm1, [rsp+0x10]
00007eafdc3d728f  vmovaps xmm2, [rsp+0x20]
00007eafdc3d7295  vmovaps xmm3, [rsp+0x30]
00007eafdc3d729b  vmovaps xmm4, [rsp+0x40]
00007eafdc3d72a1  vmovaps xmm5, [rsp+0x50]
00007eafdc3d72a7  vmovaps xmm6, [rsp+0x60]
00007eafdc3d72ad  vmovaps xmm7, [rsp+0x70]
00007eafdc3d72b3  vmovaps xmm8, [rsp+0x80]
00007eafdc3d72bc  vmovaps xmm10, [rsp+0x90]
00007eafdc3d72c5  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d72ce  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d72d7  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d72e0  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d72e9  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d72f2  add rsp, 0xF0
00007eafdc3d72f9  pop r11
00007eafdc3d72fb  pop r10
00007eafdc3d72fd  pop r9
00007eafdc3d72ff  pop r8
00007eafdc3d7301  pop rsi
00007eafdc3d7302  pop rdi
00007eafdc3d7303  pop rdx
00007eafdc3d7304  pop rcx
00007eafdc3d7305  pop rax
00007eafdc3d7306  add rsp, 0x08
00007eafdc3d730a  jmp 0x00007EAFDC3D5AFB
00007eafdc3d730f  call 0x00007EAFDC2D64F0
00007eafdc3d7314  jmp 0x00007EAFDC3D5C15
00007eafdc3d7319  call 0x00007EAFDC2D64F0
00007eafdc3d731e  jmp 0x00007EAFDC3D5C2B
00007eafdc3d7323  sub rsp, 0x08
00007eafdc3d7327  push rax
00007eafdc3d7328  push rcx
00007eafdc3d7329  push rdx
00007eafdc3d732a  push rdi
00007eafdc3d732b  push rsi
00007eafdc3d732c  push r8
00007eafdc3d732e  push r9
00007eafdc3d7330  push r10
00007eafdc3d7332  push r11
00007eafdc3d7334  sub rsp, 0xF0
00007eafdc3d733b  vmovaps [rsp], xmm0
00007eafdc3d7340  vmovaps [rsp+0x10], xmm2
00007eafdc3d7346  vmovaps [rsp+0x20], xmm3
00007eafdc3d734c  vmovaps [rsp+0x30], xmm4
00007eafdc3d7352  vmovaps [rsp+0x40], xmm5
00007eafdc3d7358  vmovaps [rsp+0x50], xmm6
00007eafdc3d735e  vmovaps [rsp+0x60], xmm7
00007eafdc3d7364  vmovaps [rsp+0x70], xmm8
00007eafdc3d736a  vmovaps [rsp+0x80], xmm9
00007eafdc3d7373  vmovaps [rsp+0x90], xmm10
00007eafdc3d737c  vmovaps [rsp+0xA0], xmm11
00007eafdc3d7385  vmovaps [rsp+0xB0], xmm12
00007eafdc3d738e  vmovaps [rsp+0xC0], xmm13
00007eafdc3d7397  vmovaps [rsp+0xD0], xmm14
00007eafdc3d73a0  vmovaps [rsp+0xE0], xmm15
00007eafdc3d73a9  sub rsp, 0x30
00007eafdc3d73ad  movaps [rsp], xmm1
00007eafdc3d73b1  movaps [rsp+0x10], xmm6
00007eafdc3d73b6  movaps [rsp+0x20], xmm15
00007eafdc3d73bc  lea rdi, [rsp]
00007eafdc3d73c0  mov esi, 0x00
00007eafdc3d73c5  mov rax, 0x645891675530
00007eafdc3d73cf  call rax
00007eafdc3d73d1  movaps xmm1, [rsp]
00007eafdc3d73d5  add rsp, 0x30
00007eafdc3d73d9  vmovaps xmm0, [rsp]
00007eafdc3d73de  vmovaps xmm2, [rsp+0x10]
00007eafdc3d73e4  vmovaps xmm3, [rsp+0x20]
00007eafdc3d73ea  vmovaps xmm4, [rsp+0x30]
00007eafdc3d73f0  vmovaps xmm5, [rsp+0x40]
00007eafdc3d73f6  vmovaps xmm6, [rsp+0x50]
00007eafdc3d73fc  vmovaps xmm7, [rsp+0x60]
00007eafdc3d7402  vmovaps xmm8, [rsp+0x70]
00007eafdc3d7408  vmovaps xmm9, [rsp+0x80]
00007eafdc3d7411  vmovaps xmm10, [rsp+0x90]
00007eafdc3d741a  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d7423  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d742c  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d7435  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d743e  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d7447  add rsp, 0xF0
00007eafdc3d744e  pop r11
00007eafdc3d7450  pop r10
00007eafdc3d7452  pop r9
00007eafdc3d7454  pop r8
00007eafdc3d7456  pop rsi
00007eafdc3d7457  pop rdi
00007eafdc3d7458  pop rdx
00007eafdc3d7459  pop rcx
00007eafdc3d745a  pop rax
00007eafdc3d745b  add rsp, 0x08
00007eafdc3d745f  jmp 0x00007EAFDC3D5C68
00007eafdc3d7464  call 0x00007EAFDC2E5820
00007eafdc3d7469  jmp 0x00007EAFDC3D5C75
00007eafdc3d746e  sub rsp, 0x08
00007eafdc3d7472  push rax
00007eafdc3d7473  push rcx
00007eafdc3d7474  push rdx
00007eafdc3d7475  push rdi
00007eafdc3d7476  push rsi
00007eafdc3d7477  push r8
00007eafdc3d7479  push r9
00007eafdc3d747b  push r10
00007eafdc3d747d  push r11
00007eafdc3d747f  sub rsp, 0xF0
00007eafdc3d7486  vmovaps [rsp], xmm0
00007eafdc3d748b  vmovaps [rsp+0x10], xmm1
00007eafdc3d7491  vmovaps [rsp+0x20], xmm2
00007eafdc3d7497  vmovaps [rsp+0x30], xmm3
00007eafdc3d749d  vmovaps [rsp+0x40], xmm4
00007eafdc3d74a3  vmovaps [rsp+0x50], xmm5
00007eafdc3d74a9  vmovaps [rsp+0x60], xmm6
00007eafdc3d74af  vmovaps [rsp+0x70], xmm7
00007eafdc3d74b5  vmovaps [rsp+0x80], xmm8
00007eafdc3d74be  vmovaps [rsp+0x90], xmm9
00007eafdc3d74c7  vmovaps [rsp+0xA0], xmm10
00007eafdc3d74d0  vmovaps [rsp+0xB0], xmm11
00007eafdc3d74d9  vmovaps [rsp+0xC0], xmm12
00007eafdc3d74e2  vmovaps [rsp+0xD0], xmm13
00007eafdc3d74eb  vmovaps [rsp+0xE0], xmm15
00007eafdc3d74f4  sub rsp, 0x30
00007eafdc3d74f8  movaps [rsp], xmm14
00007eafdc3d74fd  movaps [rsp+0x10], xmm4
00007eafdc3d7502  movaps [rsp+0x20], xmm3
00007eafdc3d7507  lea rdi, [rsp]
00007eafdc3d750b  mov esi, 0x00
00007eafdc3d7510  mov rax, 0x645891675530
00007eafdc3d751a  call rax
00007eafdc3d751c  movaps xmm14, [rsp]
00007eafdc3d7521  add rsp, 0x30
00007eafdc3d7525  vmovaps xmm0, [rsp]
00007eafdc3d752a  vmovaps xmm1, [rsp+0x10]
00007eafdc3d7530  vmovaps xmm2, [rsp+0x20]
00007eafdc3d7536  vmovaps xmm3, [rsp+0x30]
00007eafdc3d753c  vmovaps xmm4, [rsp+0x40]
00007eafdc3d7542  vmovaps xmm5, [rsp+0x50]
00007eafdc3d7548  vmovaps xmm6, [rsp+0x60]
00007eafdc3d754e  vmovaps xmm7, [rsp+0x70]
00007eafdc3d7554  vmovaps xmm8, [rsp+0x80]
00007eafdc3d755d  vmovaps xmm9, [rsp+0x90]
00007eafdc3d7566  vmovaps xmm10, [rsp+0xA0]
00007eafdc3d756f  vmovaps xmm11, [rsp+0xB0]
00007eafdc3d7578  vmovaps xmm12, [rsp+0xC0]
00007eafdc3d7581  vmovaps xmm13, [rsp+0xD0]
00007eafdc3d758a  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d7593  add rsp, 0xF0
00007eafdc3d759a  pop r11
00007eafdc3d759c  pop r10
00007eafdc3d759e  pop r9
00007eafdc3d75a0  pop r8
00007eafdc3d75a2  pop rsi
00007eafdc3d75a3  pop rdi
00007eafdc3d75a4  pop rdx
00007eafdc3d75a5  pop rcx
00007eafdc3d75a6  pop rax
00007eafdc3d75a7  add rsp, 0x08
00007eafdc3d75ab  jmp 0x00007EAFDC3D5C8F
00007eafdc3d75b0  sub rsp, 0x08
00007eafdc3d75b4  push rax
00007eafdc3d75b5  push rcx
00007eafdc3d75b6  push rdx
00007eafdc3d75b7  push rdi
00007eafdc3d75b8  push rsi
00007eafdc3d75b9  push r8
00007eafdc3d75bb  push r9
00007eafdc3d75bd  push r10
00007eafdc3d75bf  push r11
00007eafdc3d75c1  sub rsp, 0xF0
00007eafdc3d75c8  vmovaps [rsp], xmm0
00007eafdc3d75cd  vmovaps [rsp+0x10], xmm1
00007eafdc3d75d3  vmovaps [rsp+0x20], xmm2
00007eafdc3d75d9  vmovaps [rsp+0x30], xmm3
00007eafdc3d75df  vmovaps [rsp+0x40], xmm4
00007eafdc3d75e5  vmovaps [rsp+0x50], xmm5
00007eafdc3d75eb  vmovaps [rsp+0x60], xmm7
00007eafdc3d75f1  vmovaps [rsp+0x70], xmm8
00007eafdc3d75f7  vmovaps [rsp+0x80], xmm9
00007eafdc3d7600  vmovaps [rsp+0x90], xmm10
00007eafdc3d7609  vmovaps [rsp+0xA0], xmm11
00007eafdc3d7612  vmovaps [rsp+0xB0], xmm12
00007eafdc3d761b  vmovaps [rsp+0xC0], xmm13
00007eafdc3d7624  vmovaps [rsp+0xD0], xmm14
00007eafdc3d762d  vmovaps [rsp+0xE0], xmm15
00007eafdc3d7636  sub rsp, 0x30
00007eafdc3d763a  movaps [rsp], xmm6
00007eafdc3d763e  movaps [rsp+0x10], xmm9
00007eafdc3d7644  movaps [rsp+0x20], xmm7
00007eafdc3d7649  lea rdi, [rsp]
00007eafdc3d764d  mov esi, 0x00
00007eafdc3d7652  mov rax, 0x645891675530
00007eafdc3d765c  call rax
00007eafdc3d765e  movaps xmm6, [rsp]
00007eafdc3d7662  add rsp, 0x30
00007eafdc3d7666  vmovaps xmm0, [rsp]
00007eafdc3d766b  vmovaps xmm1, [rsp+0x10]
00007eafdc3d7671  vmovaps xmm2, [rsp+0x20]
00007eafdc3d7677  vmovaps xmm3, [rsp+0x30]
00007eafdc3d767d  vmovaps xmm4, [rsp+0x40]
00007eafdc3d7683  vmovaps xmm5, [rsp+0x50]
00007eafdc3d7689  vmovaps xmm7, [rsp+0x60]
00007eafdc3d768f  vmovaps xmm8, [rsp+0x70]
00007eafdc3d7695  vmovaps xmm9, [rsp+0x80]
00007eafdc3d769e  vmovaps xmm10, [rsp+0x90]
00007eafdc3d76a7  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d76b0  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d76b9  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d76c2  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d76cb  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d76d4  add rsp, 0xF0
00007eafdc3d76db  pop r11
00007eafdc3d76dd  pop r10
00007eafdc3d76df  pop r9
00007eafdc3d76e1  pop r8
00007eafdc3d76e3  pop rsi
00007eafdc3d76e4  pop rdi
00007eafdc3d76e5  pop rdx
00007eafdc3d76e6  pop rcx
00007eafdc3d76e7  pop rax
00007eafdc3d76e8  add rsp, 0x08
00007eafdc3d76ec  jmp 0x00007EAFDC3D5CA7
00007eafdc3d76f1  sub rsp, 0x08
00007eafdc3d76f5  push rax
00007eafdc3d76f6  push rcx
00007eafdc3d76f7  push rdx
00007eafdc3d76f8  push rdi
00007eafdc3d76f9  push rsi
00007eafdc3d76fa  push r8
00007eafdc3d76fc  push r9
00007eafdc3d76fe  push r10
00007eafdc3d7700  push r11
00007eafdc3d7702  sub rsp, 0xF0
00007eafdc3d7709  vmovaps [rsp], xmm0
00007eafdc3d770e  vmovaps [rsp+0x10], xmm1
00007eafdc3d7714  vmovaps [rsp+0x20], xmm2
00007eafdc3d771a  vmovaps [rsp+0x30], xmm3
00007eafdc3d7720  vmovaps [rsp+0x40], xmm4
00007eafdc3d7726  vmovaps [rsp+0x50], xmm5
00007eafdc3d772c  vmovaps [rsp+0x60], xmm6
00007eafdc3d7732  vmovaps [rsp+0x70], xmm8
00007eafdc3d7738  vmovaps [rsp+0x80], xmm9
00007eafdc3d7741  vmovaps [rsp+0x90], xmm10
00007eafdc3d774a  vmovaps [rsp+0xA0], xmm11
00007eafdc3d7753  vmovaps [rsp+0xB0], xmm12
00007eafdc3d775c  vmovaps [rsp+0xC0], xmm13
00007eafdc3d7765  vmovaps [rsp+0xD0], xmm14
00007eafdc3d776e  vmovaps [rsp+0xE0], xmm15
00007eafdc3d7777  sub rsp, 0x30
00007eafdc3d777b  movaps [rsp], xmm7
00007eafdc3d777f  movaps [rsp+0x10], xmm4
00007eafdc3d7784  movaps [rsp+0x20], xmm9
00007eafdc3d778a  lea rdi, [rsp]
00007eafdc3d778e  mov esi, 0x00
00007eafdc3d7793  mov rax, 0x645891675530
00007eafdc3d779d  call rax
00007eafdc3d779f  movaps xmm7, [rsp]
00007eafdc3d77a3  add rsp, 0x30
00007eafdc3d77a7  vmovaps xmm0, [rsp]
00007eafdc3d77ac  vmovaps xmm1, [rsp+0x10]
00007eafdc3d77b2  vmovaps xmm2, [rsp+0x20]
00007eafdc3d77b8  vmovaps xmm3, [rsp+0x30]
00007eafdc3d77be  vmovaps xmm4, [rsp+0x40]
00007eafdc3d77c4  vmovaps xmm5, [rsp+0x50]
00007eafdc3d77ca  vmovaps xmm6, [rsp+0x60]
00007eafdc3d77d0  vmovaps xmm8, [rsp+0x70]
00007eafdc3d77d6  vmovaps xmm9, [rsp+0x80]
00007eafdc3d77df  vmovaps xmm10, [rsp+0x90]
00007eafdc3d77e8  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d77f1  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d77fa  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d7803  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d780c  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d7815  add rsp, 0xF0
00007eafdc3d781c  pop r11
00007eafdc3d781e  pop r10
00007eafdc3d7820  pop r9
00007eafdc3d7822  pop r8
00007eafdc3d7824  pop rsi
00007eafdc3d7825  pop rdi
00007eafdc3d7826  pop rdx
00007eafdc3d7827  pop rcx
00007eafdc3d7828  pop rax
00007eafdc3d7829  add rsp, 0x08
00007eafdc3d782d  jmp 0x00007EAFDC3D5CD4
00007eafdc3d7832  sub rsp, 0x08
00007eafdc3d7836  push rax
00007eafdc3d7837  push rcx
00007eafdc3d7838  push rdx
00007eafdc3d7839  push rdi
00007eafdc3d783a  push rsi
00007eafdc3d783b  push r8
00007eafdc3d783d  push r9
00007eafdc3d783f  push r10
00007eafdc3d7841  push r11
00007eafdc3d7843  sub rsp, 0xF0
00007eafdc3d784a  vmovaps [rsp], xmm0
00007eafdc3d784f  vmovaps [rsp+0x10], xmm1
00007eafdc3d7855  vmovaps [rsp+0x20], xmm2
00007eafdc3d785b  vmovaps [rsp+0x30], xmm3
00007eafdc3d7861  vmovaps [rsp+0x40], xmm5
00007eafdc3d7867  vmovaps [rsp+0x50], xmm6
00007eafdc3d786d  vmovaps [rsp+0x60], xmm7
00007eafdc3d7873  vmovaps [rsp+0x70], xmm8
00007eafdc3d7879  vmovaps [rsp+0x80], xmm9
00007eafdc3d7882  vmovaps [rsp+0x90], xmm10
00007eafdc3d788b  vmovaps [rsp+0xA0], xmm11
00007eafdc3d7894  vmovaps [rsp+0xB0], xmm12
00007eafdc3d789d  vmovaps [rsp+0xC0], xmm13
00007eafdc3d78a6  vmovaps [rsp+0xD0], xmm14
00007eafdc3d78af  vmovaps [rsp+0xE0], xmm15
00007eafdc3d78b8  sub rsp, 0x30
00007eafdc3d78bc  movaps [rsp], xmm4
00007eafdc3d78c0  movaps [rsp+0x10], xmm15
00007eafdc3d78c6  movaps [rsp+0x20], xmm9
00007eafdc3d78cc  lea rdi, [rsp]
00007eafdc3d78d0  mov esi, 0x00
00007eafdc3d78d5  mov rax, 0x645891675530
00007eafdc3d78df  call rax
00007eafdc3d78e1  movaps xmm4, [rsp]
00007eafdc3d78e5  add rsp, 0x30
00007eafdc3d78e9  vmovaps xmm0, [rsp]
00007eafdc3d78ee  vmovaps xmm1, [rsp+0x10]
00007eafdc3d78f4  vmovaps xmm2, [rsp+0x20]
00007eafdc3d78fa  vmovaps xmm3, [rsp+0x30]
00007eafdc3d7900  vmovaps xmm5, [rsp+0x40]
00007eafdc3d7906  vmovaps xmm6, [rsp+0x50]
00007eafdc3d790c  vmovaps xmm7, [rsp+0x60]
00007eafdc3d7912  vmovaps xmm8, [rsp+0x70]
00007eafdc3d7918  vmovaps xmm9, [rsp+0x80]
00007eafdc3d7921  vmovaps xmm10, [rsp+0x90]
00007eafdc3d792a  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d7933  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d793c  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d7945  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d794e  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d7957  add rsp, 0xF0
00007eafdc3d795e  pop r11
00007eafdc3d7960  pop r10
00007eafdc3d7962  pop r9
00007eafdc3d7964  pop r8
00007eafdc3d7966  pop rsi
00007eafdc3d7967  pop rdi
00007eafdc3d7968  pop rdx
00007eafdc3d7969  pop rcx
00007eafdc3d796a  pop rax
00007eafdc3d796b  add rsp, 0x08
00007eafdc3d796f  jmp 0x00007EAFDC3D5CF9
00007eafdc3d7974  call 0x00007EAFDC2E5820
00007eafdc3d7979  jmp 0x00007EAFDC3D5D06
00007eafdc3d797e  sub rsp, 0x08
00007eafdc3d7982  push rax
00007eafdc3d7983  push rcx
00007eafdc3d7984  push rdx
00007eafdc3d7985  push rdi
00007eafdc3d7986  push rsi
00007eafdc3d7987  push r8
00007eafdc3d7989  push r9
00007eafdc3d798b  push r10
00007eafdc3d798d  push r11
00007eafdc3d798f  sub rsp, 0xF0
00007eafdc3d7996  vmovaps [rsp], xmm0
00007eafdc3d799b  vmovaps [rsp+0x10], xmm1
00007eafdc3d79a1  vmovaps [rsp+0x20], xmm2
00007eafdc3d79a7  vmovaps [rsp+0x30], xmm4
00007eafdc3d79ad  vmovaps [rsp+0x40], xmm5
00007eafdc3d79b3  vmovaps [rsp+0x50], xmm6
00007eafdc3d79b9  vmovaps [rsp+0x60], xmm7
00007eafdc3d79bf  vmovaps [rsp+0x70], xmm8
00007eafdc3d79c5  vmovaps [rsp+0x80], xmm9
00007eafdc3d79ce  vmovaps [rsp+0x90], xmm10
00007eafdc3d79d7  vmovaps [rsp+0xA0], xmm11
00007eafdc3d79e0  vmovaps [rsp+0xB0], xmm12
00007eafdc3d79e9  vmovaps [rsp+0xC0], xmm13
00007eafdc3d79f2  vmovaps [rsp+0xD0], xmm14
00007eafdc3d79fb  vmovaps [rsp+0xE0], xmm15
00007eafdc3d7a04  sub rsp, 0x30
00007eafdc3d7a08  movaps [rsp], xmm3
00007eafdc3d7a0c  movaps [rsp+0x10], xmm1
00007eafdc3d7a11  movaps [rsp+0x20], xmm9
00007eafdc3d7a17  lea rdi, [rsp]
00007eafdc3d7a1b  mov esi, 0x00
00007eafdc3d7a20  mov rax, 0x645891675530
00007eafdc3d7a2a  call rax
00007eafdc3d7a2c  movaps xmm3, [rsp]
00007eafdc3d7a30  add rsp, 0x30
00007eafdc3d7a34  vmovaps xmm0, [rsp]
00007eafdc3d7a39  vmovaps xmm1, [rsp+0x10]
00007eafdc3d7a3f  vmovaps xmm2, [rsp+0x20]
00007eafdc3d7a45  vmovaps xmm4, [rsp+0x30]
00007eafdc3d7a4b  vmovaps xmm5, [rsp+0x40]
00007eafdc3d7a51  vmovaps xmm6, [rsp+0x50]
00007eafdc3d7a57  vmovaps xmm7, [rsp+0x60]
00007eafdc3d7a5d  vmovaps xmm8, [rsp+0x70]
00007eafdc3d7a63  vmovaps xmm9, [rsp+0x80]
00007eafdc3d7a6c  vmovaps xmm10, [rsp+0x90]
00007eafdc3d7a75  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d7a7e  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d7a87  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d7a90  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d7a99  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d7aa2  add rsp, 0xF0
00007eafdc3d7aa9  pop r11
00007eafdc3d7aab  pop r10
00007eafdc3d7aad  pop r9
00007eafdc3d7aaf  pop r8
00007eafdc3d7ab1  pop rsi
00007eafdc3d7ab2  pop rdi
00007eafdc3d7ab3  pop rdx
00007eafdc3d7ab4  pop rcx
00007eafdc3d7ab5  pop rax
00007eafdc3d7ab6  add rsp, 0x08
00007eafdc3d7aba  jmp 0x00007EAFDC3D5D43
00007eafdc3d7abf  sub rsp, 0x08
00007eafdc3d7ac3  push rax
00007eafdc3d7ac4  push rcx
00007eafdc3d7ac5  push rdx
00007eafdc3d7ac6  push rdi
00007eafdc3d7ac7  push rsi
00007eafdc3d7ac8  push r8
00007eafdc3d7aca  push r9
00007eafdc3d7acc  push r10
00007eafdc3d7ace  push r11
00007eafdc3d7ad0  sub rsp, 0xF0
00007eafdc3d7ad7  vmovaps [rsp], xmm0
00007eafdc3d7adc  vmovaps [rsp+0x10], xmm2
00007eafdc3d7ae2  vmovaps [rsp+0x20], xmm3
00007eafdc3d7ae8  vmovaps [rsp+0x30], xmm4
00007eafdc3d7aee  vmovaps [rsp+0x40], xmm5
00007eafdc3d7af4  vmovaps [rsp+0x50], xmm6
00007eafdc3d7afa  vmovaps [rsp+0x60], xmm7
00007eafdc3d7b00  vmovaps [rsp+0x70], xmm8
00007eafdc3d7b06  vmovaps [rsp+0x80], xmm9
00007eafdc3d7b0f  vmovaps [rsp+0x90], xmm10
00007eafdc3d7b18  vmovaps [rsp+0xA0], xmm11
00007eafdc3d7b21  vmovaps [rsp+0xB0], xmm12
00007eafdc3d7b2a  vmovaps [rsp+0xC0], xmm13
00007eafdc3d7b33  vmovaps [rsp+0xD0], xmm14
00007eafdc3d7b3c  vmovaps [rsp+0xE0], xmm15
00007eafdc3d7b45  sub rsp, 0x30
00007eafdc3d7b49  movaps [rsp], xmm1
00007eafdc3d7b4d  movaps [rsp+0x10], xmm15
00007eafdc3d7b53  movaps [rsp+0x20], xmm9
00007eafdc3d7b59  lea rdi, [rsp]
00007eafdc3d7b5d  mov esi, 0x00
00007eafdc3d7b62  mov rax, 0x645891675530
00007eafdc3d7b6c  call rax
00007eafdc3d7b6e  movaps xmm1, [rsp]
00007eafdc3d7b72  add rsp, 0x30
00007eafdc3d7b76  vmovaps xmm0, [rsp]
00007eafdc3d7b7b  vmovaps xmm2, [rsp+0x10]
00007eafdc3d7b81  vmovaps xmm3, [rsp+0x20]
00007eafdc3d7b87  vmovaps xmm4, [rsp+0x30]
00007eafdc3d7b8d  vmovaps xmm5, [rsp+0x40]
00007eafdc3d7b93  vmovaps xmm6, [rsp+0x50]
00007eafdc3d7b99  vmovaps xmm7, [rsp+0x60]
00007eafdc3d7b9f  vmovaps xmm8, [rsp+0x70]
00007eafdc3d7ba5  vmovaps xmm9, [rsp+0x80]
00007eafdc3d7bae  vmovaps xmm10, [rsp+0x90]
00007eafdc3d7bb7  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d7bc0  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d7bc9  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d7bd2  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d7bdb  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d7be4  add rsp, 0xF0
00007eafdc3d7beb  pop r11
00007eafdc3d7bed  pop r10
00007eafdc3d7bef  pop r9
00007eafdc3d7bf1  pop r8
00007eafdc3d7bf3  pop rsi
00007eafdc3d7bf4  pop rdi
00007eafdc3d7bf5  pop rdx
00007eafdc3d7bf6  pop rcx
00007eafdc3d7bf7  pop rax
00007eafdc3d7bf8  add rsp, 0x08
00007eafdc3d7bfc  jmp 0x00007EAFDC3D5DCB
00007eafdc3d7c01  call 0x00007EAFDC2E5820
00007eafdc3d7c06  jmp 0x00007EAFDC3D5DD8
00007eafdc3d7c0b  sub rsp, 0x08
00007eafdc3d7c0f  push rax
00007eafdc3d7c10  push rcx
00007eafdc3d7c11  push rdx
00007eafdc3d7c12  push rdi
00007eafdc3d7c13  push rsi
00007eafdc3d7c14  push r8
00007eafdc3d7c16  push r9
00007eafdc3d7c18  push r10
00007eafdc3d7c1a  push r11
00007eafdc3d7c1c  sub rsp, 0xF0
00007eafdc3d7c23  vmovaps [rsp], xmm0
00007eafdc3d7c28  vmovaps [rsp+0x10], xmm2
00007eafdc3d7c2e  vmovaps [rsp+0x20], xmm3
00007eafdc3d7c34  vmovaps [rsp+0x30], xmm4
00007eafdc3d7c3a  vmovaps [rsp+0x40], xmm5
00007eafdc3d7c40  vmovaps [rsp+0x50], xmm6
00007eafdc3d7c46  vmovaps [rsp+0x60], xmm7
00007eafdc3d7c4c  vmovaps [rsp+0x70], xmm8
00007eafdc3d7c52  vmovaps [rsp+0x80], xmm9
00007eafdc3d7c5b  vmovaps [rsp+0x90], xmm10
00007eafdc3d7c64  vmovaps [rsp+0xA0], xmm11
00007eafdc3d7c6d  vmovaps [rsp+0xB0], xmm12
00007eafdc3d7c76  vmovaps [rsp+0xC0], xmm13
00007eafdc3d7c7f  vmovaps [rsp+0xD0], xmm14
00007eafdc3d7c88  vmovaps [rsp+0xE0], xmm15
00007eafdc3d7c91  sub rsp, 0x30
00007eafdc3d7c95  movaps [rsp], xmm1
00007eafdc3d7c99  movaps [rsp+0x10], xmm5
00007eafdc3d7c9e  movaps [rsp+0x20], xmm7
00007eafdc3d7ca3  lea rdi, [rsp]
00007eafdc3d7ca7  mov esi, 0x00
00007eafdc3d7cac  mov rax, 0x645891675530
00007eafdc3d7cb6  call rax
00007eafdc3d7cb8  movaps xmm1, [rsp]
00007eafdc3d7cbc  add rsp, 0x30
00007eafdc3d7cc0  vmovaps xmm0, [rsp]
00007eafdc3d7cc5  vmovaps xmm2, [rsp+0x10]
00007eafdc3d7ccb  vmovaps xmm3, [rsp+0x20]
00007eafdc3d7cd1  vmovaps xmm4, [rsp+0x30]
00007eafdc3d7cd7  vmovaps xmm5, [rsp+0x40]
00007eafdc3d7cdd  vmovaps xmm6, [rsp+0x50]
00007eafdc3d7ce3  vmovaps xmm7, [rsp+0x60]
00007eafdc3d7ce9  vmovaps xmm8, [rsp+0x70]
00007eafdc3d7cef  vmovaps xmm9, [rsp+0x80]
00007eafdc3d7cf8  vmovaps xmm10, [rsp+0x90]
00007eafdc3d7d01  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d7d0a  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d7d13  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d7d1c  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d7d25  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d7d2e  add rsp, 0xF0
00007eafdc3d7d35  pop r11
00007eafdc3d7d37  pop r10
00007eafdc3d7d39  pop r9
00007eafdc3d7d3b  pop r8
00007eafdc3d7d3d  pop rsi
00007eafdc3d7d3e  pop rdi
00007eafdc3d7d3f  pop rdx
00007eafdc3d7d40  pop rcx
00007eafdc3d7d41  pop rax
00007eafdc3d7d42  add rsp, 0x08
00007eafdc3d7d46  jmp 0x00007EAFDC3D5E7D
00007eafdc3d7d4b  sub rsp, 0x08
00007eafdc3d7d4f  push rax
00007eafdc3d7d50  push rcx
00007eafdc3d7d51  push rdx
00007eafdc3d7d52  push rdi
00007eafdc3d7d53  push rsi
00007eafdc3d7d54  push r8
00007eafdc3d7d56  push r9
00007eafdc3d7d58  push r10
00007eafdc3d7d5a  push r11
00007eafdc3d7d5c  sub rsp, 0xF0
00007eafdc3d7d63  vmovaps [rsp], xmm0
00007eafdc3d7d68  vmovaps [rsp+0x10], xmm1
00007eafdc3d7d6e  vmovaps [rsp+0x20], xmm2
00007eafdc3d7d74  vmovaps [rsp+0x30], xmm3
00007eafdc3d7d7a  vmovaps [rsp+0x40], xmm4
00007eafdc3d7d80  vmovaps [rsp+0x50], xmm5
00007eafdc3d7d86  vmovaps [rsp+0x60], xmm6
00007eafdc3d7d8c  vmovaps [rsp+0x70], xmm8
00007eafdc3d7d92  vmovaps [rsp+0x80], xmm9
00007eafdc3d7d9b  vmovaps [rsp+0x90], xmm10
00007eafdc3d7da4  vmovaps [rsp+0xA0], xmm11
00007eafdc3d7dad  vmovaps [rsp+0xB0], xmm12
00007eafdc3d7db6  vmovaps [rsp+0xC0], xmm13
00007eafdc3d7dbf  vmovaps [rsp+0xD0], xmm14
00007eafdc3d7dc8  vmovaps [rsp+0xE0], xmm15
00007eafdc3d7dd1  sub rsp, 0x30
00007eafdc3d7dd5  movaps [rsp], xmm7
00007eafdc3d7dd9  movaps [rsp+0x10], xmm5
00007eafdc3d7dde  movaps [rsp+0x20], xmm15
00007eafdc3d7de4  lea rdi, [rsp]
00007eafdc3d7de8  mov esi, 0x00
00007eafdc3d7ded  mov rax, 0x645891675530
00007eafdc3d7df7  call rax
00007eafdc3d7df9  movaps xmm7, [rsp]
00007eafdc3d7dfd  add rsp, 0x30
00007eafdc3d7e01  vmovaps xmm0, [rsp]
00007eafdc3d7e06  vmovaps xmm1, [rsp+0x10]
00007eafdc3d7e0c  vmovaps xmm2, [rsp+0x20]
00007eafdc3d7e12  vmovaps xmm3, [rsp+0x30]
00007eafdc3d7e18  vmovaps xmm4, [rsp+0x40]
00007eafdc3d7e1e  vmovaps xmm5, [rsp+0x50]
00007eafdc3d7e24  vmovaps xmm6, [rsp+0x60]
00007eafdc3d7e2a  vmovaps xmm8, [rsp+0x70]
00007eafdc3d7e30  vmovaps xmm9, [rsp+0x80]
00007eafdc3d7e39  vmovaps xmm10, [rsp+0x90]
00007eafdc3d7e42  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d7e4b  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d7e54  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d7e5d  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d7e66  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d7e6f  add rsp, 0xF0
00007eafdc3d7e76  pop r11
00007eafdc3d7e78  pop r10
00007eafdc3d7e7a  pop r9
00007eafdc3d7e7c  pop r8
00007eafdc3d7e7e  pop rsi
00007eafdc3d7e7f  pop rdi
00007eafdc3d7e80  pop rdx
00007eafdc3d7e81  pop rcx
00007eafdc3d7e82  pop rax
00007eafdc3d7e83  add rsp, 0x08
00007eafdc3d7e87  jmp 0x00007EAFDC3D5EB3
00007eafdc3d7e8c  call 0x00007EAFDC2D64F0
00007eafdc3d7e91  jmp 0x00007EAFDC3D5EC0
00007eafdc3d7e96  sub rsp, 0x08
00007eafdc3d7e9a  push rax
00007eafdc3d7e9b  push rcx
00007eafdc3d7e9c  push rdx
00007eafdc3d7e9d  push rdi
00007eafdc3d7e9e  push rsi
00007eafdc3d7e9f  push r8
00007eafdc3d7ea1  push r9
00007eafdc3d7ea3  push r10
00007eafdc3d7ea5  push r11
00007eafdc3d7ea7  sub rsp, 0xF0
00007eafdc3d7eae  vmovaps [rsp], xmm0
00007eafdc3d7eb3  vmovaps [rsp+0x10], xmm1
00007eafdc3d7eb9  vmovaps [rsp+0x20], xmm2
00007eafdc3d7ebf  vmovaps [rsp+0x30], xmm3
00007eafdc3d7ec5  vmovaps [rsp+0x40], xmm4
00007eafdc3d7ecb  vmovaps [rsp+0x50], xmm5
00007eafdc3d7ed1  vmovaps [rsp+0x60], xmm6
00007eafdc3d7ed7  vmovaps [rsp+0x70], xmm7
00007eafdc3d7edd  vmovaps [rsp+0x80], xmm8
00007eafdc3d7ee6  vmovaps [rsp+0x90], xmm9
00007eafdc3d7eef  vmovaps [rsp+0xA0], xmm10
00007eafdc3d7ef8  vmovaps [rsp+0xB0], xmm11
00007eafdc3d7f01  vmovaps [rsp+0xC0], xmm12
00007eafdc3d7f0a  vmovaps [rsp+0xD0], xmm13
00007eafdc3d7f13  vmovaps [rsp+0xE0], xmm14
00007eafdc3d7f1c  sub rsp, 0x30
00007eafdc3d7f20  movaps [rsp], xmm15
00007eafdc3d7f25  movaps [rsp+0x10], xmm5
00007eafdc3d7f2a  movaps [rsp+0x20], xmm3
00007eafdc3d7f2f  lea rdi, [rsp]
00007eafdc3d7f33  mov esi, 0x00
00007eafdc3d7f38  mov rax, 0x645891675530
00007eafdc3d7f42  call rax
00007eafdc3d7f44  movaps xmm15, [rsp]
00007eafdc3d7f49  add rsp, 0x30
00007eafdc3d7f4d  vmovaps xmm0, [rsp]
00007eafdc3d7f52  vmovaps xmm1, [rsp+0x10]
00007eafdc3d7f58  vmovaps xmm2, [rsp+0x20]
00007eafdc3d7f5e  vmovaps xmm3, [rsp+0x30]
00007eafdc3d7f64  vmovaps xmm4, [rsp+0x40]
00007eafdc3d7f6a  vmovaps xmm5, [rsp+0x50]
00007eafdc3d7f70  vmovaps xmm6, [rsp+0x60]
00007eafdc3d7f76  vmovaps xmm7, [rsp+0x70]
00007eafdc3d7f7c  vmovaps xmm8, [rsp+0x80]
00007eafdc3d7f85  vmovaps xmm9, [rsp+0x90]
00007eafdc3d7f8e  vmovaps xmm10, [rsp+0xA0]
00007eafdc3d7f97  vmovaps xmm11, [rsp+0xB0]
00007eafdc3d7fa0  vmovaps xmm12, [rsp+0xC0]
00007eafdc3d7fa9  vmovaps xmm13, [rsp+0xD0]
00007eafdc3d7fb2  vmovaps xmm14, [rsp+0xE0]
00007eafdc3d7fbb  add rsp, 0xF0
00007eafdc3d7fc2  pop r11
00007eafdc3d7fc4  pop r10
00007eafdc3d7fc6  pop r9
00007eafdc3d7fc8  pop r8
00007eafdc3d7fca  pop rsi
00007eafdc3d7fcb  pop rdi
00007eafdc3d7fcc  pop rdx
00007eafdc3d7fcd  pop rcx
00007eafdc3d7fce  pop rax
00007eafdc3d7fcf  add rsp, 0x08
00007eafdc3d7fd3  jmp 0x00007EAFDC3D5EE6
00007eafdc3d7fd8  sub rsp, 0x08
00007eafdc3d7fdc  push rax
00007eafdc3d7fdd  push rcx
00007eafdc3d7fde  push rdx
00007eafdc3d7fdf  push rdi
00007eafdc3d7fe0  push rsi
00007eafdc3d7fe1  push r8
00007eafdc3d7fe3  push r9
00007eafdc3d7fe5  push r10
00007eafdc3d7fe7  push r11
00007eafdc3d7fe9  sub rsp, 0xF0
00007eafdc3d7ff0  vmovaps [rsp], xmm0
00007eafdc3d7ff5  vmovaps [rsp+0x10], xmm2
00007eafdc3d7ffb  vmovaps [rsp+0x20], xmm3
00007eafdc3d8001  vmovaps [rsp+0x30], xmm4
00007eafdc3d8007  vmovaps [rsp+0x40], xmm5
00007eafdc3d800d  vmovaps [rsp+0x50], xmm6
00007eafdc3d8013  vmovaps [rsp+0x60], xmm7
00007eafdc3d8019  vmovaps [rsp+0x70], xmm8
00007eafdc3d801f  vmovaps [rsp+0x80], xmm9
00007eafdc3d8028  vmovaps [rsp+0x90], xmm10
00007eafdc3d8031  vmovaps [rsp+0xA0], xmm11
00007eafdc3d803a  vmovaps [rsp+0xB0], xmm12
00007eafdc3d8043  vmovaps [rsp+0xC0], xmm13
00007eafdc3d804c  vmovaps [rsp+0xD0], xmm14
00007eafdc3d8055  vmovaps [rsp+0xE0], xmm15
00007eafdc3d805e  sub rsp, 0x30
00007eafdc3d8062  movaps [rsp], xmm1
00007eafdc3d8066  movaps [rsp+0x10], xmm5
00007eafdc3d806b  movaps [rsp+0x20], xmm4
00007eafdc3d8070  lea rdi, [rsp]
00007eafdc3d8074  mov esi, 0x00
00007eafdc3d8079  mov rax, 0x645891675530
00007eafdc3d8083  call rax
00007eafdc3d8085  movaps xmm1, [rsp]
00007eafdc3d8089  add rsp, 0x30
00007eafdc3d808d  vmovaps xmm0, [rsp]
00007eafdc3d8092  vmovaps xmm2, [rsp+0x10]
00007eafdc3d8098  vmovaps xmm3, [rsp+0x20]
00007eafdc3d809e  vmovaps xmm4, [rsp+0x30]
00007eafdc3d80a4  vmovaps xmm5, [rsp+0x40]
00007eafdc3d80aa  vmovaps xmm6, [rsp+0x50]
00007eafdc3d80b0  vmovaps xmm7, [rsp+0x60]
00007eafdc3d80b6  vmovaps xmm8, [rsp+0x70]
00007eafdc3d80bc  vmovaps xmm9, [rsp+0x80]
00007eafdc3d80c5  vmovaps xmm10, [rsp+0x90]
00007eafdc3d80ce  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d80d7  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d80e0  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d80e9  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d80f2  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d80fb  add rsp, 0xF0
00007eafdc3d8102  pop r11
00007eafdc3d8104  pop r10
00007eafdc3d8106  pop r9
00007eafdc3d8108  pop r8
00007eafdc3d810a  pop rsi
00007eafdc3d810b  pop rdi
00007eafdc3d810c  pop rdx
00007eafdc3d810d  pop rcx
00007eafdc3d810e  pop rax
00007eafdc3d810f  add rsp, 0x08
00007eafdc3d8113  jmp 0x00007EAFDC3D5F06
00007eafdc3d8118  sub rsp, 0x08
00007eafdc3d811c  push rax
00007eafdc3d811d  push rcx
00007eafdc3d811e  push rdx
00007eafdc3d811f  push rdi
00007eafdc3d8120  push rsi
00007eafdc3d8121  push r8
00007eafdc3d8123  push r9
00007eafdc3d8125  push r10
00007eafdc3d8127  push r11
00007eafdc3d8129  sub rsp, 0xF0
00007eafdc3d8130  vmovaps [rsp], xmm0
00007eafdc3d8135  vmovaps [rsp+0x10], xmm1
00007eafdc3d813b  vmovaps [rsp+0x20], xmm2
00007eafdc3d8141  vmovaps [rsp+0x30], xmm3
00007eafdc3d8147  vmovaps [rsp+0x40], xmm5
00007eafdc3d814d  vmovaps [rsp+0x50], xmm6
00007eafdc3d8153  vmovaps [rsp+0x60], xmm7
00007eafdc3d8159  vmovaps [rsp+0x70], xmm8
00007eafdc3d815f  vmovaps [rsp+0x80], xmm9
00007eafdc3d8168  vmovaps [rsp+0x90], xmm10
00007eafdc3d8171  vmovaps [rsp+0xA0], xmm11
00007eafdc3d817a  vmovaps [rsp+0xB0], xmm12
00007eafdc3d8183  vmovaps [rsp+0xC0], xmm13
00007eafdc3d818c  vmovaps [rsp+0xD0], xmm14
00007eafdc3d8195  vmovaps [rsp+0xE0], xmm15
00007eafdc3d819e  sub rsp, 0x30
00007eafdc3d81a2  movaps [rsp], xmm4
00007eafdc3d81a6  movaps [rsp+0x10], xmm3
00007eafdc3d81ab  movaps [rsp+0x20], xmm5
00007eafdc3d81b0  lea rdi, [rsp]
00007eafdc3d81b4  mov esi, 0x00
00007eafdc3d81b9  mov rax, 0x645891675530
00007eafdc3d81c3  call rax
00007eafdc3d81c5  movaps xmm4, [rsp]
00007eafdc3d81c9  add rsp, 0x30
00007eafdc3d81cd  vmovaps xmm0, [rsp]
00007eafdc3d81d2  vmovaps xmm1, [rsp+0x10]
00007eafdc3d81d8  vmovaps xmm2, [rsp+0x20]
00007eafdc3d81de  vmovaps xmm3, [rsp+0x30]
00007eafdc3d81e4  vmovaps xmm5, [rsp+0x40]
00007eafdc3d81ea  vmovaps xmm6, [rsp+0x50]
00007eafdc3d81f0  vmovaps xmm7, [rsp+0x60]
00007eafdc3d81f6  vmovaps xmm8, [rsp+0x70]
00007eafdc3d81fc  vmovaps xmm9, [rsp+0x80]
00007eafdc3d8205  vmovaps xmm10, [rsp+0x90]
00007eafdc3d820e  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d8217  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d8220  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d8229  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d8232  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d823b  add rsp, 0xF0
00007eafdc3d8242  pop r11
00007eafdc3d8244  pop r10
00007eafdc3d8246  pop r9
00007eafdc3d8248  pop r8
00007eafdc3d824a  pop rsi
00007eafdc3d824b  pop rdi
00007eafdc3d824c  pop rdx
00007eafdc3d824d  pop rcx
00007eafdc3d824e  pop rax
00007eafdc3d824f  add rsp, 0x08
00007eafdc3d8253  jmp 0x00007EAFDC3D5F54
00007eafdc3d8258  call 0x00007EAFDC2D64F0
00007eafdc3d825d  jmp 0x00007EAFDC3D5F61
00007eafdc3d8262  sub rsp, 0x08
00007eafdc3d8266  push rax
00007eafdc3d8267  push rcx
00007eafdc3d8268  push rdx
00007eafdc3d8269  push rdi
00007eafdc3d826a  push rsi
00007eafdc3d826b  push r8
00007eafdc3d826d  push r9
00007eafdc3d826f  push r10
00007eafdc3d8271  push r11
00007eafdc3d8273  sub rsp, 0xF0
00007eafdc3d827a  vmovaps [rsp], xmm0
00007eafdc3d827f  vmovaps [rsp+0x10], xmm1
00007eafdc3d8285  vmovaps [rsp+0x20], xmm2
00007eafdc3d828b  vmovaps [rsp+0x30], xmm3
00007eafdc3d8291  vmovaps [rsp+0x40], xmm4
00007eafdc3d8297  vmovaps [rsp+0x50], xmm6
00007eafdc3d829d  vmovaps [rsp+0x60], xmm7
00007eafdc3d82a3  vmovaps [rsp+0x70], xmm8
00007eafdc3d82a9  vmovaps [rsp+0x80], xmm9
00007eafdc3d82b2  vmovaps [rsp+0x90], xmm10
00007eafdc3d82bb  vmovaps [rsp+0xA0], xmm11
00007eafdc3d82c4  vmovaps [rsp+0xB0], xmm12
00007eafdc3d82cd  vmovaps [rsp+0xC0], xmm13
00007eafdc3d82d6  vmovaps [rsp+0xD0], xmm14
00007eafdc3d82df  vmovaps [rsp+0xE0], xmm15
00007eafdc3d82e8  sub rsp, 0x30
00007eafdc3d82ec  movaps [rsp], xmm5
00007eafdc3d82f0  movaps [rsp+0x10], xmm6
00007eafdc3d82f5  movaps [rsp+0x20], xmm3
00007eafdc3d82fa  lea rdi, [rsp]
00007eafdc3d82fe  mov esi, 0x00
00007eafdc3d8303  mov rax, 0x645891675530
00007eafdc3d830d  call rax
00007eafdc3d830f  movaps xmm5, [rsp]
00007eafdc3d8313  add rsp, 0x30
00007eafdc3d8317  vmovaps xmm0, [rsp]
00007eafdc3d831c  vmovaps xmm1, [rsp+0x10]
00007eafdc3d8322  vmovaps xmm2, [rsp+0x20]
00007eafdc3d8328  vmovaps xmm3, [rsp+0x30]
00007eafdc3d832e  vmovaps xmm4, [rsp+0x40]
00007eafdc3d8334  vmovaps xmm6, [rsp+0x50]
00007eafdc3d833a  vmovaps xmm7, [rsp+0x60]
00007eafdc3d8340  vmovaps xmm8, [rsp+0x70]
00007eafdc3d8346  vmovaps xmm9, [rsp+0x80]
00007eafdc3d834f  vmovaps xmm10, [rsp+0x90]
00007eafdc3d8358  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d8361  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d836a  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d8373  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d837c  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d8385  add rsp, 0xF0
00007eafdc3d838c  pop r11
00007eafdc3d838e  pop r10
00007eafdc3d8390  pop r9
00007eafdc3d8392  pop r8
00007eafdc3d8394  pop rsi
00007eafdc3d8395  pop rdi
00007eafdc3d8396  pop rdx
00007eafdc3d8397  pop rcx
00007eafdc3d8398  pop rax
00007eafdc3d8399  add rsp, 0x08
00007eafdc3d839d  jmp 0x00007EAFDC3D5F87
00007eafdc3d83a2  sub rsp, 0x08
00007eafdc3d83a6  push rax
00007eafdc3d83a7  push rcx
00007eafdc3d83a8  push rdx
00007eafdc3d83a9  push rdi
00007eafdc3d83aa  push rsi
00007eafdc3d83ab  push r8
00007eafdc3d83ad  push r9
00007eafdc3d83af  push r10
00007eafdc3d83b1  push r11
00007eafdc3d83b3  sub rsp, 0xF0
00007eafdc3d83ba  vmovaps [rsp], xmm0
00007eafdc3d83bf  vmovaps [rsp+0x10], xmm1
00007eafdc3d83c5  vmovaps [rsp+0x20], xmm2
00007eafdc3d83cb  vmovaps [rsp+0x30], xmm3
00007eafdc3d83d1  vmovaps [rsp+0x40], xmm4
00007eafdc3d83d7  vmovaps [rsp+0x50], xmm5
00007eafdc3d83dd  vmovaps [rsp+0x60], xmm7
00007eafdc3d83e3  vmovaps [rsp+0x70], xmm8
00007eafdc3d83e9  vmovaps [rsp+0x80], xmm9
00007eafdc3d83f2  vmovaps [rsp+0x90], xmm10
00007eafdc3d83fb  vmovaps [rsp+0xA0], xmm11
00007eafdc3d8404  vmovaps [rsp+0xB0], xmm12
00007eafdc3d840d  vmovaps [rsp+0xC0], xmm13
00007eafdc3d8416  vmovaps [rsp+0xD0], xmm14
00007eafdc3d841f  vmovaps [rsp+0xE0], xmm15
00007eafdc3d8428  sub rsp, 0x30
00007eafdc3d842c  movaps [rsp], xmm6
00007eafdc3d8430  movaps [rsp+0x10], xmm9
00007eafdc3d8436  movaps [rsp+0x20], xmm1
00007eafdc3d843b  lea rdi, [rsp]
00007eafdc3d843f  mov esi, 0x00
00007eafdc3d8444  mov rax, 0x645891675530
00007eafdc3d844e  call rax
00007eafdc3d8450  movaps xmm6, [rsp]
00007eafdc3d8454  add rsp, 0x30
00007eafdc3d8458  vmovaps xmm0, [rsp]
00007eafdc3d845d  vmovaps xmm1, [rsp+0x10]
00007eafdc3d8463  vmovaps xmm2, [rsp+0x20]
00007eafdc3d8469  vmovaps xmm3, [rsp+0x30]
00007eafdc3d846f  vmovaps xmm4, [rsp+0x40]
00007eafdc3d8475  vmovaps xmm5, [rsp+0x50]
00007eafdc3d847b  vmovaps xmm7, [rsp+0x60]
00007eafdc3d8481  vmovaps xmm8, [rsp+0x70]
00007eafdc3d8487  vmovaps xmm9, [rsp+0x80]
00007eafdc3d8490  vmovaps xmm10, [rsp+0x90]
00007eafdc3d8499  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d84a2  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d84ab  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d84b4  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d84bd  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d84c6  add rsp, 0xF0
00007eafdc3d84cd  pop r11
00007eafdc3d84cf  pop r10
00007eafdc3d84d1  pop r9
00007eafdc3d84d3  pop r8
00007eafdc3d84d5  pop rsi
00007eafdc3d84d6  pop rdi
00007eafdc3d84d7  pop rdx
00007eafdc3d84d8  pop rcx
00007eafdc3d84d9  pop rax
00007eafdc3d84da  add rsp, 0x08
00007eafdc3d84de  jmp 0x00007EAFDC3D5FAB
00007eafdc3d84e3  sub rsp, 0x08
00007eafdc3d84e7  push rax
00007eafdc3d84e8  push rcx
00007eafdc3d84e9  push rdx
00007eafdc3d84ea  push rdi
00007eafdc3d84eb  push rsi
00007eafdc3d84ec  push r8
00007eafdc3d84ee  push r9
00007eafdc3d84f0  push r10
00007eafdc3d84f2  push r11
00007eafdc3d84f4  sub rsp, 0xF0
00007eafdc3d84fb  vmovaps [rsp], xmm0
00007eafdc3d8500  vmovaps [rsp+0x10], xmm1
00007eafdc3d8506  vmovaps [rsp+0x20], xmm2
00007eafdc3d850c  vmovaps [rsp+0x30], xmm3
00007eafdc3d8512  vmovaps [rsp+0x40], xmm4
00007eafdc3d8518  vmovaps [rsp+0x50], xmm5
00007eafdc3d851e  vmovaps [rsp+0x60], xmm6
00007eafdc3d8524  vmovaps [rsp+0x70], xmm7
00007eafdc3d852a  vmovaps [rsp+0x80], xmm8
00007eafdc3d8533  vmovaps [rsp+0x90], xmm10
00007eafdc3d853c  vmovaps [rsp+0xA0], xmm11
00007eafdc3d8545  vmovaps [rsp+0xB0], xmm12
00007eafdc3d854e  vmovaps [rsp+0xC0], xmm13
00007eafdc3d8557  vmovaps [rsp+0xD0], xmm14
00007eafdc3d8560  vmovaps [rsp+0xE0], xmm15
00007eafdc3d8569  sub rsp, 0x30
00007eafdc3d856d  movaps [rsp], xmm9
00007eafdc3d8572  movaps [rsp+0x10], xmm3
00007eafdc3d8577  movaps [rsp+0x20], xmm1
00007eafdc3d857c  lea rdi, [rsp]
00007eafdc3d8580  mov esi, 0x00
00007eafdc3d8585  mov rax, 0x645891675530
00007eafdc3d858f  call rax
00007eafdc3d8591  movaps xmm9, [rsp]
00007eafdc3d8596  add rsp, 0x30
00007eafdc3d859a  vmovaps xmm0, [rsp]
00007eafdc3d859f  vmovaps xmm1, [rsp+0x10]
00007eafdc3d85a5  vmovaps xmm2, [rsp+0x20]
00007eafdc3d85ab  vmovaps xmm3, [rsp+0x30]
00007eafdc3d85b1  vmovaps xmm4, [rsp+0x40]
00007eafdc3d85b7  vmovaps xmm5, [rsp+0x50]
00007eafdc3d85bd  vmovaps xmm6, [rsp+0x60]
00007eafdc3d85c3  vmovaps xmm7, [rsp+0x70]
00007eafdc3d85c9  vmovaps xmm8, [rsp+0x80]
00007eafdc3d85d2  vmovaps xmm10, [rsp+0x90]
00007eafdc3d85db  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d85e4  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d85ed  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d85f6  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d85ff  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d8608  add rsp, 0xF0
00007eafdc3d860f  pop r11
00007eafdc3d8611  pop r10
00007eafdc3d8613  pop r9
00007eafdc3d8615  pop r8
00007eafdc3d8617  pop rsi
00007eafdc3d8618  pop rdi
00007eafdc3d8619  pop rdx
00007eafdc3d861a  pop rcx
00007eafdc3d861b  pop rax
00007eafdc3d861c  add rsp, 0x08
00007eafdc3d8620  jmp 0x00007EAFDC3D5FF7
00007eafdc3d8625  call 0x00007EAFDC2D64F0
00007eafdc3d862a  jmp 0x00007EAFDC3D6004
00007eafdc3d862f  sub rsp, 0x08
00007eafdc3d8633  push rax
00007eafdc3d8634  push rcx
00007eafdc3d8635  push rdx
00007eafdc3d8636  push rdi
00007eafdc3d8637  push rsi
00007eafdc3d8638  push r8
00007eafdc3d863a  push r9
00007eafdc3d863c  push r10
00007eafdc3d863e  push r11
00007eafdc3d8640  sub rsp, 0xF0
00007eafdc3d8647  vmovaps [rsp], xmm0
00007eafdc3d864c  vmovaps [rsp+0x10], xmm1
00007eafdc3d8652  vmovaps [rsp+0x20], xmm2
00007eafdc3d8658  vmovaps [rsp+0x30], xmm3
00007eafdc3d865e  vmovaps [rsp+0x40], xmm4
00007eafdc3d8664  vmovaps [rsp+0x50], xmm5
00007eafdc3d866a  vmovaps [rsp+0x60], xmm6
00007eafdc3d8670  vmovaps [rsp+0x70], xmm7
00007eafdc3d8676  vmovaps [rsp+0x80], xmm8
00007eafdc3d867f  vmovaps [rsp+0x90], xmm9
00007eafdc3d8688  vmovaps [rsp+0xA0], xmm10
00007eafdc3d8691  vmovaps [rsp+0xB0], xmm11
00007eafdc3d869a  vmovaps [rsp+0xC0], xmm12
00007eafdc3d86a3  vmovaps [rsp+0xD0], xmm13
00007eafdc3d86ac  vmovaps [rsp+0xE0], xmm14
00007eafdc3d86b5  sub rsp, 0x30
00007eafdc3d86b9  movaps [rsp], xmm15
00007eafdc3d86be  movaps [rsp+0x10], xmm3
00007eafdc3d86c3  movaps [rsp+0x20], xmm7
00007eafdc3d86c8  lea rdi, [rsp]
00007eafdc3d86cc  mov esi, 0x00
00007eafdc3d86d1  mov rax, 0x645891675530
00007eafdc3d86db  call rax
00007eafdc3d86dd  movaps xmm15, [rsp]
00007eafdc3d86e2  add rsp, 0x30
00007eafdc3d86e6  vmovaps xmm0, [rsp]
00007eafdc3d86eb  vmovaps xmm1, [rsp+0x10]
00007eafdc3d86f1  vmovaps xmm2, [rsp+0x20]
00007eafdc3d86f7  vmovaps xmm3, [rsp+0x30]
00007eafdc3d86fd  vmovaps xmm4, [rsp+0x40]
00007eafdc3d8703  vmovaps xmm5, [rsp+0x50]
00007eafdc3d8709  vmovaps xmm6, [rsp+0x60]
00007eafdc3d870f  vmovaps xmm7, [rsp+0x70]
00007eafdc3d8715  vmovaps xmm8, [rsp+0x80]
00007eafdc3d871e  vmovaps xmm9, [rsp+0x90]
00007eafdc3d8727  vmovaps xmm10, [rsp+0xA0]
00007eafdc3d8730  vmovaps xmm11, [rsp+0xB0]
00007eafdc3d8739  vmovaps xmm12, [rsp+0xC0]
00007eafdc3d8742  vmovaps xmm13, [rsp+0xD0]
00007eafdc3d874b  vmovaps xmm14, [rsp+0xE0]
00007eafdc3d8754  add rsp, 0xF0
00007eafdc3d875b  pop r11
00007eafdc3d875d  pop r10
00007eafdc3d875f  pop r9
00007eafdc3d8761  pop r8
00007eafdc3d8763  pop rsi
00007eafdc3d8764  pop rdi
00007eafdc3d8765  pop rdx
00007eafdc3d8766  pop rcx
00007eafdc3d8767  pop rax
00007eafdc3d8768  add rsp, 0x08
00007eafdc3d876c  jmp 0x00007EAFDC3D6030
00007eafdc3d8771  sub rsp, 0x08
00007eafdc3d8775  push rax
00007eafdc3d8776  push rcx
00007eafdc3d8777  push rdx
00007eafdc3d8778  push rdi
00007eafdc3d8779  push rsi
00007eafdc3d877a  push r8
00007eafdc3d877c  push r9
00007eafdc3d877e  push r10
00007eafdc3d8780  push r11
00007eafdc3d8782  sub rsp, 0xF0
00007eafdc3d8789  vmovaps [rsp], xmm0
00007eafdc3d878e  vmovaps [rsp+0x10], xmm1
00007eafdc3d8794  vmovaps [rsp+0x20], xmm2
00007eafdc3d879a  vmovaps [rsp+0x30], xmm4
00007eafdc3d87a0  vmovaps [rsp+0x40], xmm5
00007eafdc3d87a6  vmovaps [rsp+0x50], xmm6
00007eafdc3d87ac  vmovaps [rsp+0x60], xmm7
00007eafdc3d87b2  vmovaps [rsp+0x70], xmm8
00007eafdc3d87b8  vmovaps [rsp+0x80], xmm9
00007eafdc3d87c1  vmovaps [rsp+0x90], xmm10
00007eafdc3d87ca  vmovaps [rsp+0xA0], xmm11
00007eafdc3d87d3  vmovaps [rsp+0xB0], xmm12
00007eafdc3d87dc  vmovaps [rsp+0xC0], xmm13
00007eafdc3d87e5  vmovaps [rsp+0xD0], xmm14
00007eafdc3d87ee  vmovaps [rsp+0xE0], xmm15
00007eafdc3d87f7  sub rsp, 0x30
00007eafdc3d87fb  movaps [rsp], xmm3
00007eafdc3d87ff  movaps [rsp+0x10], xmm1
00007eafdc3d8804  movaps [rsp+0x20], xmm15
00007eafdc3d880a  lea rdi, [rsp]
00007eafdc3d880e  mov esi, 0x00
00007eafdc3d8813  mov rax, 0x645891675530
00007eafdc3d881d  call rax
00007eafdc3d881f  movaps xmm3, [rsp]
00007eafdc3d8823  add rsp, 0x30
00007eafdc3d8827  vmovaps xmm0, [rsp]
00007eafdc3d882c  vmovaps xmm1, [rsp+0x10]
00007eafdc3d8832  vmovaps xmm2, [rsp+0x20]
00007eafdc3d8838  vmovaps xmm4, [rsp+0x30]
00007eafdc3d883e  vmovaps xmm5, [rsp+0x40]
00007eafdc3d8844  vmovaps xmm6, [rsp+0x50]
00007eafdc3d884a  vmovaps xmm7, [rsp+0x60]
00007eafdc3d8850  vmovaps xmm8, [rsp+0x70]
00007eafdc3d8856  vmovaps xmm9, [rsp+0x80]
00007eafdc3d885f  vmovaps xmm10, [rsp+0x90]
00007eafdc3d8868  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d8871  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d887a  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d8883  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d888c  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d8895  add rsp, 0xF0
00007eafdc3d889c  pop r11
00007eafdc3d889e  pop r10
00007eafdc3d88a0  pop r9
00007eafdc3d88a2  pop r8
00007eafdc3d88a4  pop rsi
00007eafdc3d88a5  pop rdi
00007eafdc3d88a6  pop rdx
00007eafdc3d88a7  pop rcx
00007eafdc3d88a8  pop rax
00007eafdc3d88a9  add rsp, 0x08
00007eafdc3d88ad  jmp 0x00007EAFDC3D60BF
00007eafdc3d88b2  call 0x00007EAFDC2D64F0
00007eafdc3d88b7  jmp 0x00007EAFDC3D60C9
00007eafdc3d88bc  sub rsp, 0x08
00007eafdc3d88c0  push rax
00007eafdc3d88c1  push rcx
00007eafdc3d88c2  push rdx
00007eafdc3d88c3  push rdi
00007eafdc3d88c4  push rsi
00007eafdc3d88c5  push r8
00007eafdc3d88c7  push r9
00007eafdc3d88c9  push r10
00007eafdc3d88cb  push r11
00007eafdc3d88cd  sub rsp, 0xF0
00007eafdc3d88d4  vmovaps [rsp], xmm0
00007eafdc3d88d9  vmovaps [rsp+0x10], xmm1
00007eafdc3d88df  vmovaps [rsp+0x20], xmm2
00007eafdc3d88e5  vmovaps [rsp+0x30], xmm3
00007eafdc3d88eb  vmovaps [rsp+0x40], xmm4
00007eafdc3d88f1  vmovaps [rsp+0x50], xmm5
00007eafdc3d88f7  vmovaps [rsp+0x60], xmm6
00007eafdc3d88fd  vmovaps [rsp+0x70], xmm7
00007eafdc3d8903  vmovaps [rsp+0x80], xmm8
00007eafdc3d890c  vmovaps [rsp+0x90], xmm9
00007eafdc3d8915  vmovaps [rsp+0xA0], xmm10
00007eafdc3d891e  vmovaps [rsp+0xB0], xmm11
00007eafdc3d8927  vmovaps [rsp+0xC0], xmm12
00007eafdc3d8930  vmovaps [rsp+0xD0], xmm13
00007eafdc3d8939  vmovaps [rsp+0xE0], xmm14
00007eafdc3d8942  sub rsp, 0x30
00007eafdc3d8946  movaps [rsp], xmm15
00007eafdc3d894b  movaps [rsp+0x10], xmm14
00007eafdc3d8951  movaps [rsp+0x20], xmm4
00007eafdc3d8956  lea rdi, [rsp]
00007eafdc3d895a  mov esi, 0x00
00007eafdc3d895f  mov rax, 0x645891675530
00007eafdc3d8969  call rax
00007eafdc3d896b  movaps xmm15, [rsp]
00007eafdc3d8970  add rsp, 0x30
00007eafdc3d8974  vmovaps xmm0, [rsp]
00007eafdc3d8979  vmovaps xmm1, [rsp+0x10]
00007eafdc3d897f  vmovaps xmm2, [rsp+0x20]
00007eafdc3d8985  vmovaps xmm3, [rsp+0x30]
00007eafdc3d898b  vmovaps xmm4, [rsp+0x40]
00007eafdc3d8991  vmovaps xmm5, [rsp+0x50]
00007eafdc3d8997  vmovaps xmm6, [rsp+0x60]
00007eafdc3d899d  vmovaps xmm7, [rsp+0x70]
00007eafdc3d89a3  vmovaps xmm8, [rsp+0x80]
00007eafdc3d89ac  vmovaps xmm9, [rsp+0x90]
00007eafdc3d89b5  vmovaps xmm10, [rsp+0xA0]
00007eafdc3d89be  vmovaps xmm11, [rsp+0xB0]
00007eafdc3d89c7  vmovaps xmm12, [rsp+0xC0]
00007eafdc3d89d0  vmovaps xmm13, [rsp+0xD0]
00007eafdc3d89d9  vmovaps xmm14, [rsp+0xE0]
00007eafdc3d89e2  add rsp, 0xF0
00007eafdc3d89e9  pop r11
00007eafdc3d89eb  pop r10
00007eafdc3d89ed  pop r9
00007eafdc3d89ef  pop r8
00007eafdc3d89f1  pop rsi
00007eafdc3d89f2  pop rdi
00007eafdc3d89f3  pop rdx
00007eafdc3d89f4  pop rcx
00007eafdc3d89f5  pop rax
00007eafdc3d89f6  add rsp, 0x08
00007eafdc3d89fa  jmp 0x00007EAFDC3D60F7
00007eafdc3d89ff  sub rsp, 0x08
00007eafdc3d8a03  push rax
00007eafdc3d8a04  push rcx
00007eafdc3d8a05  push rdx
00007eafdc3d8a06  push rdi
00007eafdc3d8a07  push rsi
00007eafdc3d8a08  push r8
00007eafdc3d8a0a  push r9
00007eafdc3d8a0c  push r10
00007eafdc3d8a0e  push r11
00007eafdc3d8a10  sub rsp, 0xF0
00007eafdc3d8a17  vmovaps [rsp], xmm0
00007eafdc3d8a1c  vmovaps [rsp+0x10], xmm1
00007eafdc3d8a22  vmovaps [rsp+0x20], xmm2
00007eafdc3d8a28  vmovaps [rsp+0x30], xmm3
00007eafdc3d8a2e  vmovaps [rsp+0x40], xmm4
00007eafdc3d8a34  vmovaps [rsp+0x50], xmm5
00007eafdc3d8a3a  vmovaps [rsp+0x60], xmm6
00007eafdc3d8a40  vmovaps [rsp+0x70], xmm7
00007eafdc3d8a46  vmovaps [rsp+0x80], xmm8
00007eafdc3d8a4f  vmovaps [rsp+0x90], xmm9
00007eafdc3d8a58  vmovaps [rsp+0xA0], xmm10
00007eafdc3d8a61  vmovaps [rsp+0xB0], xmm11
00007eafdc3d8a6a  vmovaps [rsp+0xC0], xmm12
00007eafdc3d8a73  vmovaps [rsp+0xD0], xmm13
00007eafdc3d8a7c  vmovaps [rsp+0xE0], xmm15
00007eafdc3d8a85  sub rsp, 0x30
00007eafdc3d8a89  movaps [rsp], xmm14
00007eafdc3d8a8e  movaps [rsp+0x10], xmm2
00007eafdc3d8a93  movaps [rsp+0x20], xmm1
00007eafdc3d8a98  lea rdi, [rsp]
00007eafdc3d8a9c  mov esi, 0x00
00007eafdc3d8aa1  mov rax, 0x645891675530
00007eafdc3d8aab  call rax
00007eafdc3d8aad  movaps xmm14, [rsp]
00007eafdc3d8ab2  add rsp, 0x30
00007eafdc3d8ab6  vmovaps xmm0, [rsp]
00007eafdc3d8abb  vmovaps xmm1, [rsp+0x10]
00007eafdc3d8ac1  vmovaps xmm2, [rsp+0x20]
00007eafdc3d8ac7  vmovaps xmm3, [rsp+0x30]
00007eafdc3d8acd  vmovaps xmm4, [rsp+0x40]
00007eafdc3d8ad3  vmovaps xmm5, [rsp+0x50]
00007eafdc3d8ad9  vmovaps xmm6, [rsp+0x60]
00007eafdc3d8adf  vmovaps xmm7, [rsp+0x70]
00007eafdc3d8ae5  vmovaps xmm8, [rsp+0x80]
00007eafdc3d8aee  vmovaps xmm9, [rsp+0x90]
00007eafdc3d8af7  vmovaps xmm10, [rsp+0xA0]
00007eafdc3d8b00  vmovaps xmm11, [rsp+0xB0]
00007eafdc3d8b09  vmovaps xmm12, [rsp+0xC0]
00007eafdc3d8b12  vmovaps xmm13, [rsp+0xD0]
00007eafdc3d8b1b  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d8b24  add rsp, 0xF0
00007eafdc3d8b2b  pop r11
00007eafdc3d8b2d  pop r10
00007eafdc3d8b2f  pop r9
00007eafdc3d8b31  pop r8
00007eafdc3d8b33  pop rsi
00007eafdc3d8b34  pop rdi
00007eafdc3d8b35  pop rdx
00007eafdc3d8b36  pop rcx
00007eafdc3d8b37  pop rax
00007eafdc3d8b38  add rsp, 0x08
00007eafdc3d8b3c  jmp 0x00007EAFDC3D611D
00007eafdc3d8b41  sub rsp, 0x08
00007eafdc3d8b45  push rax
00007eafdc3d8b46  push rcx
00007eafdc3d8b47  push rdx
00007eafdc3d8b48  push rdi
00007eafdc3d8b49  push rsi
00007eafdc3d8b4a  push r8
00007eafdc3d8b4c  push r9
00007eafdc3d8b4e  push r10
00007eafdc3d8b50  push r11
00007eafdc3d8b52  sub rsp, 0xF0
00007eafdc3d8b59  vmovaps [rsp], xmm0
00007eafdc3d8b5e  vmovaps [rsp+0x10], xmm2
00007eafdc3d8b64  vmovaps [rsp+0x20], xmm3
00007eafdc3d8b6a  vmovaps [rsp+0x30], xmm4
00007eafdc3d8b70  vmovaps [rsp+0x40], xmm5
00007eafdc3d8b76  vmovaps [rsp+0x50], xmm6
00007eafdc3d8b7c  vmovaps [rsp+0x60], xmm7
00007eafdc3d8b82  vmovaps [rsp+0x70], xmm8
00007eafdc3d8b88  vmovaps [rsp+0x80], xmm9
00007eafdc3d8b91  vmovaps [rsp+0x90], xmm10
00007eafdc3d8b9a  vmovaps [rsp+0xA0], xmm11
00007eafdc3d8ba3  vmovaps [rsp+0xB0], xmm12
00007eafdc3d8bac  vmovaps [rsp+0xC0], xmm13
00007eafdc3d8bb5  vmovaps [rsp+0xD0], xmm14
00007eafdc3d8bbe  vmovaps [rsp+0xE0], xmm15
00007eafdc3d8bc7  sub rsp, 0x30
00007eafdc3d8bcb  movaps [rsp], xmm1
00007eafdc3d8bcf  movaps [rsp+0x10], xmm4
00007eafdc3d8bd4  movaps [rsp+0x20], xmm9
00007eafdc3d8bda  lea rdi, [rsp]
00007eafdc3d8bde  mov esi, 0x00
00007eafdc3d8be3  mov rax, 0x645891675530
00007eafdc3d8bed  call rax
00007eafdc3d8bef  movaps xmm1, [rsp]
00007eafdc3d8bf3  add rsp, 0x30
00007eafdc3d8bf7  vmovaps xmm0, [rsp]
00007eafdc3d8bfc  vmovaps xmm2, [rsp+0x10]
00007eafdc3d8c02  vmovaps xmm3, [rsp+0x20]
00007eafdc3d8c08  vmovaps xmm4, [rsp+0x30]
00007eafdc3d8c0e  vmovaps xmm5, [rsp+0x40]
00007eafdc3d8c14  vmovaps xmm6, [rsp+0x50]
00007eafdc3d8c1a  vmovaps xmm7, [rsp+0x60]
00007eafdc3d8c20  vmovaps xmm8, [rsp+0x70]
00007eafdc3d8c26  vmovaps xmm9, [rsp+0x80]
00007eafdc3d8c2f  vmovaps xmm10, [rsp+0x90]
00007eafdc3d8c38  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d8c41  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d8c4a  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d8c53  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d8c5c  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d8c65  add rsp, 0xF0
00007eafdc3d8c6c  pop r11
00007eafdc3d8c6e  pop r10
00007eafdc3d8c70  pop r9
00007eafdc3d8c72  pop r8
00007eafdc3d8c74  pop rsi
00007eafdc3d8c75  pop rdi
00007eafdc3d8c76  pop rdx
00007eafdc3d8c77  pop rcx
00007eafdc3d8c78  pop rax
00007eafdc3d8c79  add rsp, 0x08
00007eafdc3d8c7d  jmp 0x00007EAFDC3D613B
00007eafdc3d8c82  sub rsp, 0x08
00007eafdc3d8c86  push rax
00007eafdc3d8c87  push rcx
00007eafdc3d8c88  push rdx
00007eafdc3d8c89  push rdi
00007eafdc3d8c8a  push rsi
00007eafdc3d8c8b  push r8
00007eafdc3d8c8d  push r9
00007eafdc3d8c8f  push r10
00007eafdc3d8c91  push r11
00007eafdc3d8c93  sub rsp, 0xF0
00007eafdc3d8c9a  vmovaps [rsp], xmm0
00007eafdc3d8c9f  vmovaps [rsp+0x10], xmm1
00007eafdc3d8ca5  vmovaps [rsp+0x20], xmm2
00007eafdc3d8cab  vmovaps [rsp+0x30], xmm3
00007eafdc3d8cb1  vmovaps [rsp+0x40], xmm5
00007eafdc3d8cb7  vmovaps [rsp+0x50], xmm6
00007eafdc3d8cbd  vmovaps [rsp+0x60], xmm7
00007eafdc3d8cc3  vmovaps [rsp+0x70], xmm8
00007eafdc3d8cc9  vmovaps [rsp+0x80], xmm9
00007eafdc3d8cd2  vmovaps [rsp+0x90], xmm10
00007eafdc3d8cdb  vmovaps [rsp+0xA0], xmm11
00007eafdc3d8ce4  vmovaps [rsp+0xB0], xmm12
00007eafdc3d8ced  vmovaps [rsp+0xC0], xmm13
00007eafdc3d8cf6  vmovaps [rsp+0xD0], xmm14
00007eafdc3d8cff  vmovaps [rsp+0xE0], xmm15
00007eafdc3d8d08  sub rsp, 0x30
00007eafdc3d8d0c  movaps [rsp], xmm4
00007eafdc3d8d10  movaps [rsp+0x10], xmm2
00007eafdc3d8d15  movaps [rsp+0x20], xmm9
00007eafdc3d8d1b  lea rdi, [rsp]
00007eafdc3d8d1f  mov esi, 0x00
00007eafdc3d8d24  mov rax, 0x645891675530
00007eafdc3d8d2e  call rax
00007eafdc3d8d30  movaps xmm4, [rsp]
00007eafdc3d8d34  add rsp, 0x30
00007eafdc3d8d38  vmovaps xmm0, [rsp]
00007eafdc3d8d3d  vmovaps xmm1, [rsp+0x10]
00007eafdc3d8d43  vmovaps xmm2, [rsp+0x20]
00007eafdc3d8d49  vmovaps xmm3, [rsp+0x30]
00007eafdc3d8d4f  vmovaps xmm5, [rsp+0x40]
00007eafdc3d8d55  vmovaps xmm6, [rsp+0x50]
00007eafdc3d8d5b  vmovaps xmm7, [rsp+0x60]
00007eafdc3d8d61  vmovaps xmm8, [rsp+0x70]
00007eafdc3d8d67  vmovaps xmm9, [rsp+0x80]
00007eafdc3d8d70  vmovaps xmm10, [rsp+0x90]
00007eafdc3d8d79  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d8d82  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d8d8b  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d8d94  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d8d9d  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d8da6  add rsp, 0xF0
00007eafdc3d8dad  pop r11
00007eafdc3d8daf  pop r10
00007eafdc3d8db1  pop r9
00007eafdc3d8db3  pop r8
00007eafdc3d8db5  pop rsi
00007eafdc3d8db6  pop rdi
00007eafdc3d8db7  pop rdx
00007eafdc3d8db8  pop rcx
00007eafdc3d8db9  pop rax
00007eafdc3d8dba  add rsp, 0x08
00007eafdc3d8dbe  jmp 0x00007EAFDC3D616B
00007eafdc3d8dc3  sub rsp, 0x08
00007eafdc3d8dc7  push rax
00007eafdc3d8dc8  push rcx
00007eafdc3d8dc9  push rdx
00007eafdc3d8dca  push rdi
00007eafdc3d8dcb  push rsi
00007eafdc3d8dcc  push r8
00007eafdc3d8dce  push r9
00007eafdc3d8dd0  push r10
00007eafdc3d8dd2  push r11
00007eafdc3d8dd4  sub rsp, 0xF0
00007eafdc3d8ddb  vmovaps [rsp], xmm0
00007eafdc3d8de0  vmovaps [rsp+0x10], xmm1
00007eafdc3d8de6  vmovaps [rsp+0x20], xmm2
00007eafdc3d8dec  vmovaps [rsp+0x30], xmm3
00007eafdc3d8df2  vmovaps [rsp+0x40], xmm4
00007eafdc3d8df8  vmovaps [rsp+0x50], xmm5
00007eafdc3d8dfe  vmovaps [rsp+0x60], xmm6
00007eafdc3d8e04  vmovaps [rsp+0x70], xmm7
00007eafdc3d8e0a  vmovaps [rsp+0x80], xmm8
00007eafdc3d8e13  vmovaps [rsp+0x90], xmm10
00007eafdc3d8e1c  vmovaps [rsp+0xA0], xmm11
00007eafdc3d8e25  vmovaps [rsp+0xB0], xmm12
00007eafdc3d8e2e  vmovaps [rsp+0xC0], xmm13
00007eafdc3d8e37  vmovaps [rsp+0xD0], xmm14
00007eafdc3d8e40  vmovaps [rsp+0xE0], xmm15
00007eafdc3d8e49  sub rsp, 0x30
00007eafdc3d8e4d  movaps [rsp], xmm9
00007eafdc3d8e52  movaps [rsp+0x10], xmm2
00007eafdc3d8e57  movaps [rsp+0x20], xmm1
00007eafdc3d8e5c  lea rdi, [rsp]
00007eafdc3d8e60  mov esi, 0x00
00007eafdc3d8e65  mov rax, 0x645891675530
00007eafdc3d8e6f  call rax
00007eafdc3d8e71  movaps xmm9, [rsp]
00007eafdc3d8e76  add rsp, 0x30
00007eafdc3d8e7a  vmovaps xmm0, [rsp]
00007eafdc3d8e7f  vmovaps xmm1, [rsp+0x10]
00007eafdc3d8e85  vmovaps xmm2, [rsp+0x20]
00007eafdc3d8e8b  vmovaps xmm3, [rsp+0x30]
00007eafdc3d8e91  vmovaps xmm4, [rsp+0x40]
00007eafdc3d8e97  vmovaps xmm5, [rsp+0x50]
00007eafdc3d8e9d  vmovaps xmm6, [rsp+0x60]
00007eafdc3d8ea3  vmovaps xmm7, [rsp+0x70]
00007eafdc3d8ea9  vmovaps xmm8, [rsp+0x80]
00007eafdc3d8eb2  vmovaps xmm10, [rsp+0x90]
00007eafdc3d8ebb  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d8ec4  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d8ecd  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d8ed6  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d8edf  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d8ee8  add rsp, 0xF0
00007eafdc3d8eef  pop r11
00007eafdc3d8ef1  pop r10
00007eafdc3d8ef3  pop r9
00007eafdc3d8ef5  pop r8
00007eafdc3d8ef7  pop rsi
00007eafdc3d8ef8  pop rdi
00007eafdc3d8ef9  pop rdx
00007eafdc3d8efa  pop rcx
00007eafdc3d8efb  pop rax
00007eafdc3d8efc  add rsp, 0x08
00007eafdc3d8f00  jmp 0x00007EAFDC3D61A1
00007eafdc3d8f05  sub rsp, 0x08
00007eafdc3d8f09  push rax
00007eafdc3d8f0a  push rcx
00007eafdc3d8f0b  push rdx
00007eafdc3d8f0c  push rdi
00007eafdc3d8f0d  push rsi
00007eafdc3d8f0e  push r8
00007eafdc3d8f10  push r9
00007eafdc3d8f12  push r10
00007eafdc3d8f14  push r11
00007eafdc3d8f16  sub rsp, 0xF0
00007eafdc3d8f1d  vmovaps [rsp], xmm0
00007eafdc3d8f22  vmovaps [rsp+0x10], xmm2
00007eafdc3d8f28  vmovaps [rsp+0x20], xmm3
00007eafdc3d8f2e  vmovaps [rsp+0x30], xmm4
00007eafdc3d8f34  vmovaps [rsp+0x40], xmm5
00007eafdc3d8f3a  vmovaps [rsp+0x50], xmm6
00007eafdc3d8f40  vmovaps [rsp+0x60], xmm7
00007eafdc3d8f46  vmovaps [rsp+0x70], xmm8
00007eafdc3d8f4c  vmovaps [rsp+0x80], xmm9
00007eafdc3d8f55  vmovaps [rsp+0x90], xmm10
00007eafdc3d8f5e  vmovaps [rsp+0xA0], xmm11
00007eafdc3d8f67  vmovaps [rsp+0xB0], xmm12
00007eafdc3d8f70  vmovaps [rsp+0xC0], xmm13
00007eafdc3d8f79  vmovaps [rsp+0xD0], xmm14
00007eafdc3d8f82  vmovaps [rsp+0xE0], xmm15
00007eafdc3d8f8b  sub rsp, 0x30
00007eafdc3d8f8f  movaps [rsp], xmm1
00007eafdc3d8f93  movaps [rsp+0x10], xmm15
00007eafdc3d8f99  movaps [rsp+0x20], xmm6
00007eafdc3d8f9e  lea rdi, [rsp]
00007eafdc3d8fa2  mov esi, 0x00
00007eafdc3d8fa7  mov rax, 0x645891675530
00007eafdc3d8fb1  call rax
00007eafdc3d8fb3  movaps xmm1, [rsp]
00007eafdc3d8fb7  add rsp, 0x30
00007eafdc3d8fbb  vmovaps xmm0, [rsp]
00007eafdc3d8fc0  vmovaps xmm2, [rsp+0x10]
00007eafdc3d8fc6  vmovaps xmm3, [rsp+0x20]
00007eafdc3d8fcc  vmovaps xmm4, [rsp+0x30]
00007eafdc3d8fd2  vmovaps xmm5, [rsp+0x40]
00007eafdc3d8fd8  vmovaps xmm6, [rsp+0x50]
00007eafdc3d8fde  vmovaps xmm7, [rsp+0x60]
00007eafdc3d8fe4  vmovaps xmm8, [rsp+0x70]
00007eafdc3d8fea  vmovaps xmm9, [rsp+0x80]
00007eafdc3d8ff3  vmovaps xmm10, [rsp+0x90]
00007eafdc3d8ffc  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d9005  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d900e  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d9017  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d9020  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d9029  add rsp, 0xF0
00007eafdc3d9030  pop r11
00007eafdc3d9032  pop r10
00007eafdc3d9034  pop r9
00007eafdc3d9036  pop r8
00007eafdc3d9038  pop rsi
00007eafdc3d9039  pop rdi
00007eafdc3d903a  pop rdx
00007eafdc3d903b  pop rcx
00007eafdc3d903c  pop rax
00007eafdc3d903d  add rsp, 0x08
00007eafdc3d9041  jmp 0x00007EAFDC3D61C2
00007eafdc3d9046  sub rsp, 0x08
00007eafdc3d904a  push rax
00007eafdc3d904b  push rcx
00007eafdc3d904c  push rdx
00007eafdc3d904d  push rdi
00007eafdc3d904e  push rsi
00007eafdc3d904f  push r8
00007eafdc3d9051  push r9
00007eafdc3d9053  push r10
00007eafdc3d9055  push r11
00007eafdc3d9057  sub rsp, 0xF0
00007eafdc3d905e  vmovaps [rsp], xmm0
00007eafdc3d9063  vmovaps [rsp+0x10], xmm1
00007eafdc3d9069  vmovaps [rsp+0x20], xmm2
00007eafdc3d906f  vmovaps [rsp+0x30], xmm3
00007eafdc3d9075  vmovaps [rsp+0x40], xmm4
00007eafdc3d907b  vmovaps [rsp+0x50], xmm5
00007eafdc3d9081  vmovaps [rsp+0x60], xmm6
00007eafdc3d9087  vmovaps [rsp+0x70], xmm7
00007eafdc3d908d  vmovaps [rsp+0x80], xmm8
00007eafdc3d9096  vmovaps [rsp+0x90], xmm9
00007eafdc3d909f  vmovaps [rsp+0xA0], xmm10
00007eafdc3d90a8  vmovaps [rsp+0xB0], xmm11
00007eafdc3d90b1  vmovaps [rsp+0xC0], xmm12
00007eafdc3d90ba  vmovaps [rsp+0xD0], xmm13
00007eafdc3d90c3  vmovaps [rsp+0xE0], xmm14
00007eafdc3d90cc  sub rsp, 0x30
00007eafdc3d90d0  movaps [rsp], xmm15
00007eafdc3d90d5  movaps [rsp+0x10], xmm5
00007eafdc3d90da  movaps [rsp+0x20], xmm3
00007eafdc3d90df  lea rdi, [rsp]
00007eafdc3d90e3  mov esi, 0x00
00007eafdc3d90e8  mov rax, 0x645891675530
00007eafdc3d90f2  call rax
00007eafdc3d90f4  movaps xmm15, [rsp]
00007eafdc3d90f9  add rsp, 0x30
00007eafdc3d90fd  vmovaps xmm0, [rsp]
00007eafdc3d9102  vmovaps xmm1, [rsp+0x10]
00007eafdc3d9108  vmovaps xmm2, [rsp+0x20]
00007eafdc3d910e  vmovaps xmm3, [rsp+0x30]
00007eafdc3d9114  vmovaps xmm4, [rsp+0x40]
00007eafdc3d911a  vmovaps xmm5, [rsp+0x50]
00007eafdc3d9120  vmovaps xmm6, [rsp+0x60]
00007eafdc3d9126  vmovaps xmm7, [rsp+0x70]
00007eafdc3d912c  vmovaps xmm8, [rsp+0x80]
00007eafdc3d9135  vmovaps xmm9, [rsp+0x90]
00007eafdc3d913e  vmovaps xmm10, [rsp+0xA0]
00007eafdc3d9147  vmovaps xmm11, [rsp+0xB0]
00007eafdc3d9150  vmovaps xmm12, [rsp+0xC0]
00007eafdc3d9159  vmovaps xmm13, [rsp+0xD0]
00007eafdc3d9162  vmovaps xmm14, [rsp+0xE0]
00007eafdc3d916b  add rsp, 0xF0
00007eafdc3d9172  pop r11
00007eafdc3d9174  pop r10
00007eafdc3d9176  pop r9
00007eafdc3d9178  pop r8
00007eafdc3d917a  pop rsi
00007eafdc3d917b  pop rdi
00007eafdc3d917c  pop rdx
00007eafdc3d917d  pop rcx
00007eafdc3d917e  pop rax
00007eafdc3d917f  add rsp, 0x08
00007eafdc3d9183  jmp 0x00007EAFDC3D61DC
00007eafdc3d9188  sub rsp, 0x08
00007eafdc3d918c  push rax
00007eafdc3d918d  push rcx
00007eafdc3d918e  push rdx
00007eafdc3d918f  push rdi
00007eafdc3d9190  push rsi
00007eafdc3d9191  push r8
00007eafdc3d9193  push r9
00007eafdc3d9195  push r10
00007eafdc3d9197  push r11
00007eafdc3d9199  sub rsp, 0xF0
00007eafdc3d91a0  vmovaps [rsp], xmm0
00007eafdc3d91a5  vmovaps [rsp+0x10], xmm1
00007eafdc3d91ab  vmovaps [rsp+0x20], xmm2
00007eafdc3d91b1  vmovaps [rsp+0x30], xmm3
00007eafdc3d91b7  vmovaps [rsp+0x40], xmm4
00007eafdc3d91bd  vmovaps [rsp+0x50], xmm6
00007eafdc3d91c3  vmovaps [rsp+0x60], xmm7
00007eafdc3d91c9  vmovaps [rsp+0x70], xmm8
00007eafdc3d91cf  vmovaps [rsp+0x80], xmm9
00007eafdc3d91d8  vmovaps [rsp+0x90], xmm10
00007eafdc3d91e1  vmovaps [rsp+0xA0], xmm11
00007eafdc3d91ea  vmovaps [rsp+0xB0], xmm12
00007eafdc3d91f3  vmovaps [rsp+0xC0], xmm13
00007eafdc3d91fc  vmovaps [rsp+0xD0], xmm14
00007eafdc3d9205  vmovaps [rsp+0xE0], xmm15
00007eafdc3d920e  sub rsp, 0x30
00007eafdc3d9212  movaps [rsp], xmm5
00007eafdc3d9216  movaps [rsp+0x10], xmm8
00007eafdc3d921c  movaps [rsp+0x20], xmm6
00007eafdc3d9221  lea rdi, [rsp]
00007eafdc3d9225  mov esi, 0x00
00007eafdc3d922a  mov rax, 0x645891675530
00007eafdc3d9234  call rax
00007eafdc3d9236  movaps xmm5, [rsp]
00007eafdc3d923a  add rsp, 0x30
00007eafdc3d923e  vmovaps xmm0, [rsp]
00007eafdc3d9243  vmovaps xmm1, [rsp+0x10]
00007eafdc3d9249  vmovaps xmm2, [rsp+0x20]
00007eafdc3d924f  vmovaps xmm3, [rsp+0x30]
00007eafdc3d9255  vmovaps xmm4, [rsp+0x40]
00007eafdc3d925b  vmovaps xmm6, [rsp+0x50]
00007eafdc3d9261  vmovaps xmm7, [rsp+0x60]
00007eafdc3d9267  vmovaps xmm8, [rsp+0x70]
00007eafdc3d926d  vmovaps xmm9, [rsp+0x80]
00007eafdc3d9276  vmovaps xmm10, [rsp+0x90]
00007eafdc3d927f  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d9288  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d9291  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d929a  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d92a3  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d92ac  add rsp, 0xF0
00007eafdc3d92b3  pop r11
00007eafdc3d92b5  pop r10
00007eafdc3d92b7  pop r9
00007eafdc3d92b9  pop r8
00007eafdc3d92bb  pop rsi
00007eafdc3d92bc  pop rdi
00007eafdc3d92bd  pop rdx
00007eafdc3d92be  pop rcx
00007eafdc3d92bf  pop rax
00007eafdc3d92c0  add rsp, 0x08
00007eafdc3d92c4  jmp 0x00007EAFDC3D6200
00007eafdc3d92c9  sub rsp, 0x08
00007eafdc3d92cd  push rax
00007eafdc3d92ce  push rcx
00007eafdc3d92cf  push rdx
00007eafdc3d92d0  push rdi
00007eafdc3d92d1  push rsi
00007eafdc3d92d2  push r8
00007eafdc3d92d4  push r9
00007eafdc3d92d6  push r10
00007eafdc3d92d8  push r11
00007eafdc3d92da  sub rsp, 0xF0
00007eafdc3d92e1  vmovaps [rsp], xmm0
00007eafdc3d92e6  vmovaps [rsp+0x10], xmm1
00007eafdc3d92ec  vmovaps [rsp+0x20], xmm2
00007eafdc3d92f2  vmovaps [rsp+0x30], xmm3
00007eafdc3d92f8  vmovaps [rsp+0x40], xmm4
00007eafdc3d92fe  vmovaps [rsp+0x50], xmm5
00007eafdc3d9304  vmovaps [rsp+0x60], xmm7
00007eafdc3d930a  vmovaps [rsp+0x70], xmm8
00007eafdc3d9310  vmovaps [rsp+0x80], xmm9
00007eafdc3d9319  vmovaps [rsp+0x90], xmm10
00007eafdc3d9322  vmovaps [rsp+0xA0], xmm11
00007eafdc3d932b  vmovaps [rsp+0xB0], xmm12
00007eafdc3d9334  vmovaps [rsp+0xC0], xmm13
00007eafdc3d933d  vmovaps [rsp+0xD0], xmm14
00007eafdc3d9346  vmovaps [rsp+0xE0], xmm15
00007eafdc3d934f  sub rsp, 0x30
00007eafdc3d9353  movaps [rsp], xmm6
00007eafdc3d9357  movaps [rsp+0x10], xmm10
00007eafdc3d935d  movaps [rsp+0x20], xmm8
00007eafdc3d9363  lea rdi, [rsp]
00007eafdc3d9367  mov esi, 0x00
00007eafdc3d936c  mov rax, 0x645891675530
00007eafdc3d9376  call rax
00007eafdc3d9378  movaps xmm6, [rsp]
00007eafdc3d937c  add rsp, 0x30
00007eafdc3d9380  vmovaps xmm0, [rsp]
00007eafdc3d9385  vmovaps xmm1, [rsp+0x10]
00007eafdc3d938b  vmovaps xmm2, [rsp+0x20]
00007eafdc3d9391  vmovaps xmm3, [rsp+0x30]
00007eafdc3d9397  vmovaps xmm4, [rsp+0x40]
00007eafdc3d939d  vmovaps xmm5, [rsp+0x50]
00007eafdc3d93a3  vmovaps xmm7, [rsp+0x60]
00007eafdc3d93a9  vmovaps xmm8, [rsp+0x70]
00007eafdc3d93af  vmovaps xmm9, [rsp+0x80]
00007eafdc3d93b8  vmovaps xmm10, [rsp+0x90]
00007eafdc3d93c1  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d93ca  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d93d3  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d93dc  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d93e5  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d93ee  add rsp, 0xF0
00007eafdc3d93f5  pop r11
00007eafdc3d93f7  pop r10
00007eafdc3d93f9  pop r9
00007eafdc3d93fb  pop r8
00007eafdc3d93fd  pop rsi
00007eafdc3d93fe  pop rdi
00007eafdc3d93ff  pop rdx
00007eafdc3d9400  pop rcx
00007eafdc3d9401  pop rax
00007eafdc3d9402  add rsp, 0x08
00007eafdc3d9406  jmp 0x00007EAFDC3D6225
00007eafdc3d940b  sub rsp, 0x08
00007eafdc3d940f  push rax
00007eafdc3d9410  push rcx
00007eafdc3d9411  push rdx
00007eafdc3d9412  push rdi
00007eafdc3d9413  push rsi
00007eafdc3d9414  push r8
00007eafdc3d9416  push r9
00007eafdc3d9418  push r10
00007eafdc3d941a  push r11
00007eafdc3d941c  sub rsp, 0xF0
00007eafdc3d9423  vmovaps [rsp], xmm0
00007eafdc3d9428  vmovaps [rsp+0x10], xmm1
00007eafdc3d942e  vmovaps [rsp+0x20], xmm2
00007eafdc3d9434  vmovaps [rsp+0x30], xmm3
00007eafdc3d943a  vmovaps [rsp+0x40], xmm4
00007eafdc3d9440  vmovaps [rsp+0x50], xmm5
00007eafdc3d9446  vmovaps [rsp+0x60], xmm6
00007eafdc3d944c  vmovaps [rsp+0x70], xmm7
00007eafdc3d9452  vmovaps [rsp+0x80], xmm8
00007eafdc3d945b  vmovaps [rsp+0x90], xmm9
00007eafdc3d9464  vmovaps [rsp+0xA0], xmm11
00007eafdc3d946d  vmovaps [rsp+0xB0], xmm12
00007eafdc3d9476  vmovaps [rsp+0xC0], xmm13
00007eafdc3d947f  vmovaps [rsp+0xD0], xmm14
00007eafdc3d9488  vmovaps [rsp+0xE0], xmm15
00007eafdc3d9491  sub rsp, 0x30
00007eafdc3d9495  movaps [rsp], xmm10
00007eafdc3d949a  movaps [rsp+0x10], xmm8
00007eafdc3d94a0  movaps [rsp+0x20], xmm14
00007eafdc3d94a6  lea rdi, [rsp]
00007eafdc3d94aa  mov esi, 0x00
00007eafdc3d94af  mov rax, 0x645891675530
00007eafdc3d94b9  call rax
00007eafdc3d94bb  movaps xmm10, [rsp]
00007eafdc3d94c0  add rsp, 0x30
00007eafdc3d94c4  vmovaps xmm0, [rsp]
00007eafdc3d94c9  vmovaps xmm1, [rsp+0x10]
00007eafdc3d94cf  vmovaps xmm2, [rsp+0x20]
00007eafdc3d94d5  vmovaps xmm3, [rsp+0x30]
00007eafdc3d94db  vmovaps xmm4, [rsp+0x40]
00007eafdc3d94e1  vmovaps xmm5, [rsp+0x50]
00007eafdc3d94e7  vmovaps xmm6, [rsp+0x60]
00007eafdc3d94ed  vmovaps xmm7, [rsp+0x70]
00007eafdc3d94f3  vmovaps xmm8, [rsp+0x80]
00007eafdc3d94fc  vmovaps xmm9, [rsp+0x90]
00007eafdc3d9505  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d950e  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d9517  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d9520  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d9529  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d9532  add rsp, 0xF0
00007eafdc3d9539  pop r11
00007eafdc3d953b  pop r10
00007eafdc3d953d  pop r9
00007eafdc3d953f  pop r8
00007eafdc3d9541  pop rsi
00007eafdc3d9542  pop rdi
00007eafdc3d9543  pop rdx
00007eafdc3d9544  pop rcx
00007eafdc3d9545  pop rax
00007eafdc3d9546  add rsp, 0x08
00007eafdc3d954a  jmp 0x00007EAFDC3D6245
00007eafdc3d954f  sub rsp, 0x08
00007eafdc3d9553  push rax
00007eafdc3d9554  push rcx
00007eafdc3d9555  push rdx
00007eafdc3d9556  push rdi
00007eafdc3d9557  push rsi
00007eafdc3d9558  push r8
00007eafdc3d955a  push r9
00007eafdc3d955c  push r10
00007eafdc3d955e  push r11
00007eafdc3d9560  sub rsp, 0xF0
00007eafdc3d9567  vmovaps [rsp], xmm0
00007eafdc3d956c  vmovaps [rsp+0x10], xmm1
00007eafdc3d9572  vmovaps [rsp+0x20], xmm2
00007eafdc3d9578  vmovaps [rsp+0x30], xmm3
00007eafdc3d957e  vmovaps [rsp+0x40], xmm4
00007eafdc3d9584  vmovaps [rsp+0x50], xmm5
00007eafdc3d958a  vmovaps [rsp+0x60], xmm6
00007eafdc3d9590  vmovaps [rsp+0x70], xmm7
00007eafdc3d9596  vmovaps [rsp+0x80], xmm8
00007eafdc3d959f  vmovaps [rsp+0x90], xmm9
00007eafdc3d95a8  vmovaps [rsp+0xA0], xmm10
00007eafdc3d95b1  vmovaps [rsp+0xB0], xmm11
00007eafdc3d95ba  vmovaps [rsp+0xC0], xmm12
00007eafdc3d95c3  vmovaps [rsp+0xD0], xmm13
00007eafdc3d95cc  vmovaps [rsp+0xE0], xmm15
00007eafdc3d95d5  sub rsp, 0x30
00007eafdc3d95d9  movaps [rsp], xmm14
00007eafdc3d95de  movaps [rsp+0x10], xmm8
00007eafdc3d95e4  movaps [rsp+0x20], xmm4
00007eafdc3d95e9  lea rdi, [rsp]
00007eafdc3d95ed  mov esi, 0x00
00007eafdc3d95f2  mov rax, 0x645891675530
00007eafdc3d95fc  call rax
00007eafdc3d95fe  movaps xmm14, [rsp]
00007eafdc3d9603  add rsp, 0x30
00007eafdc3d9607  vmovaps xmm0, [rsp]
00007eafdc3d960c  vmovaps xmm1, [rsp+0x10]
00007eafdc3d9612  vmovaps xmm2, [rsp+0x20]
00007eafdc3d9618  vmovaps xmm3, [rsp+0x30]
00007eafdc3d961e  vmovaps xmm4, [rsp+0x40]
00007eafdc3d9624  vmovaps xmm5, [rsp+0x50]
00007eafdc3d962a  vmovaps xmm6, [rsp+0x60]
00007eafdc3d9630  vmovaps xmm7, [rsp+0x70]
00007eafdc3d9636  vmovaps xmm8, [rsp+0x80]
00007eafdc3d963f  vmovaps xmm9, [rsp+0x90]
00007eafdc3d9648  vmovaps xmm10, [rsp+0xA0]
00007eafdc3d9651  vmovaps xmm11, [rsp+0xB0]
00007eafdc3d965a  vmovaps xmm12, [rsp+0xC0]
00007eafdc3d9663  vmovaps xmm13, [rsp+0xD0]
00007eafdc3d966c  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d9675  add rsp, 0xF0
00007eafdc3d967c  pop r11
00007eafdc3d967e  pop r10
00007eafdc3d9680  pop r9
00007eafdc3d9682  pop r8
00007eafdc3d9684  pop rsi
00007eafdc3d9685  pop rdi
00007eafdc3d9686  pop rdx
00007eafdc3d9687  pop rcx
00007eafdc3d9688  pop rax
00007eafdc3d9689  add rsp, 0x08
00007eafdc3d968d  jmp 0x00007EAFDC3D6265
00007eafdc3d9692  sub rsp, 0x08
00007eafdc3d9696  push rax
00007eafdc3d9697  push rcx
00007eafdc3d9698  push rdx
00007eafdc3d9699  push rdi
00007eafdc3d969a  push rsi
00007eafdc3d969b  push r8
00007eafdc3d969d  push r9
00007eafdc3d969f  push r10
00007eafdc3d96a1  push r11
00007eafdc3d96a3  sub rsp, 0xF0
00007eafdc3d96aa  vmovaps [rsp], xmm0
00007eafdc3d96af  vmovaps [rsp+0x10], xmm1
00007eafdc3d96b5  vmovaps [rsp+0x20], xmm2
00007eafdc3d96bb  vmovaps [rsp+0x30], xmm3
00007eafdc3d96c1  vmovaps [rsp+0x40], xmm5
00007eafdc3d96c7  vmovaps [rsp+0x50], xmm6
00007eafdc3d96cd  vmovaps [rsp+0x60], xmm7
00007eafdc3d96d3  vmovaps [rsp+0x70], xmm8
00007eafdc3d96d9  vmovaps [rsp+0x80], xmm9
00007eafdc3d96e2  vmovaps [rsp+0x90], xmm10
00007eafdc3d96eb  vmovaps [rsp+0xA0], xmm11
00007eafdc3d96f4  vmovaps [rsp+0xB0], xmm12
00007eafdc3d96fd  vmovaps [rsp+0xC0], xmm13
00007eafdc3d9706  vmovaps [rsp+0xD0], xmm14
00007eafdc3d970f  vmovaps [rsp+0xE0], xmm15
00007eafdc3d9718  sub rsp, 0x30
00007eafdc3d971c  movaps [rsp], xmm4
00007eafdc3d9720  movaps [rsp+0x10], xmm13
00007eafdc3d9726  movaps [rsp+0x20], xmm8
00007eafdc3d972c  lea rdi, [rsp]
00007eafdc3d9730  mov esi, 0x00
00007eafdc3d9735  mov rax, 0x645891675530
00007eafdc3d973f  call rax
00007eafdc3d9741  movaps xmm4, [rsp]
00007eafdc3d9745  add rsp, 0x30
00007eafdc3d9749  vmovaps xmm0, [rsp]
00007eafdc3d974e  vmovaps xmm1, [rsp+0x10]
00007eafdc3d9754  vmovaps xmm2, [rsp+0x20]
00007eafdc3d975a  vmovaps xmm3, [rsp+0x30]
00007eafdc3d9760  vmovaps xmm5, [rsp+0x40]
00007eafdc3d9766  vmovaps xmm6, [rsp+0x50]
00007eafdc3d976c  vmovaps xmm7, [rsp+0x60]
00007eafdc3d9772  vmovaps xmm8, [rsp+0x70]
00007eafdc3d9778  vmovaps xmm9, [rsp+0x80]
00007eafdc3d9781  vmovaps xmm10, [rsp+0x90]
00007eafdc3d978a  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d9793  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d979c  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d97a5  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d97ae  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d97b7  add rsp, 0xF0
00007eafdc3d97be  pop r11
00007eafdc3d97c0  pop r10
00007eafdc3d97c2  pop r9
00007eafdc3d97c4  pop r8
00007eafdc3d97c6  pop rsi
00007eafdc3d97c7  pop rdi
00007eafdc3d97c8  pop rdx
00007eafdc3d97c9  pop rcx
00007eafdc3d97ca  pop rax
00007eafdc3d97cb  add rsp, 0x08
00007eafdc3d97cf  jmp 0x00007EAFDC3D628A
00007eafdc3d97d4  sub rsp, 0x08
00007eafdc3d97d8  push rax
00007eafdc3d97d9  push rcx
00007eafdc3d97da  push rdx
00007eafdc3d97db  push rdi
00007eafdc3d97dc  push rsi
00007eafdc3d97dd  push r8
00007eafdc3d97df  push r9
00007eafdc3d97e1  push r10
00007eafdc3d97e3  push r11
00007eafdc3d97e5  sub rsp, 0xF0
00007eafdc3d97ec  vmovaps [rsp], xmm0
00007eafdc3d97f1  vmovaps [rsp+0x10], xmm1
00007eafdc3d97f7  vmovaps [rsp+0x20], xmm2
00007eafdc3d97fd  vmovaps [rsp+0x30], xmm3
00007eafdc3d9803  vmovaps [rsp+0x40], xmm4
00007eafdc3d9809  vmovaps [rsp+0x50], xmm5
00007eafdc3d980f  vmovaps [rsp+0x60], xmm6
00007eafdc3d9815  vmovaps [rsp+0x70], xmm7
00007eafdc3d981b  vmovaps [rsp+0x80], xmm8
00007eafdc3d9824  vmovaps [rsp+0x90], xmm9
00007eafdc3d982d  vmovaps [rsp+0xA0], xmm10
00007eafdc3d9836  vmovaps [rsp+0xB0], xmm11
00007eafdc3d983f  vmovaps [rsp+0xC0], xmm12
00007eafdc3d9848  vmovaps [rsp+0xD0], xmm14
00007eafdc3d9851  vmovaps [rsp+0xE0], xmm15
00007eafdc3d985a  sub rsp, 0x30
00007eafdc3d985e  movaps [rsp], xmm13
00007eafdc3d9863  movaps [rsp+0x10], xmm15
00007eafdc3d9869  movaps [rsp+0x20], xmm9
00007eafdc3d986f  lea rdi, [rsp]
00007eafdc3d9873  mov esi, 0x00
00007eafdc3d9878  mov rax, 0x645891675530
00007eafdc3d9882  call rax
00007eafdc3d9884  movaps xmm13, [rsp]
00007eafdc3d9889  add rsp, 0x30
00007eafdc3d988d  vmovaps xmm0, [rsp]
00007eafdc3d9892  vmovaps xmm1, [rsp+0x10]
00007eafdc3d9898  vmovaps xmm2, [rsp+0x20]
00007eafdc3d989e  vmovaps xmm3, [rsp+0x30]
00007eafdc3d98a4  vmovaps xmm4, [rsp+0x40]
00007eafdc3d98aa  vmovaps xmm5, [rsp+0x50]
00007eafdc3d98b0  vmovaps xmm6, [rsp+0x60]
00007eafdc3d98b6  vmovaps xmm7, [rsp+0x70]
00007eafdc3d98bc  vmovaps xmm8, [rsp+0x80]
00007eafdc3d98c5  vmovaps xmm9, [rsp+0x90]
00007eafdc3d98ce  vmovaps xmm10, [rsp+0xA0]
00007eafdc3d98d7  vmovaps xmm11, [rsp+0xB0]
00007eafdc3d98e0  vmovaps xmm12, [rsp+0xC0]
00007eafdc3d98e9  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d98f2  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d98fb  add rsp, 0xF0
00007eafdc3d9902  pop r11
00007eafdc3d9904  pop r10
00007eafdc3d9906  pop r9
00007eafdc3d9908  pop r8
00007eafdc3d990a  pop rsi
00007eafdc3d990b  pop rdi
00007eafdc3d990c  pop rdx
00007eafdc3d990d  pop rcx
00007eafdc3d990e  pop rax
00007eafdc3d990f  add rsp, 0x08
00007eafdc3d9913  jmp 0x00007EAFDC3D62A5
00007eafdc3d9918  sub rsp, 0x08
00007eafdc3d991c  push rax
00007eafdc3d991d  push rcx
00007eafdc3d991e  push rdx
00007eafdc3d991f  push rdi
00007eafdc3d9920  push rsi
00007eafdc3d9921  push r8
00007eafdc3d9923  push r9
00007eafdc3d9925  push r10
00007eafdc3d9927  push r11
00007eafdc3d9929  sub rsp, 0xF0
00007eafdc3d9930  vmovaps [rsp], xmm0
00007eafdc3d9935  vmovaps [rsp+0x10], xmm1
00007eafdc3d993b  vmovaps [rsp+0x20], xmm2
00007eafdc3d9941  vmovaps [rsp+0x30], xmm3
00007eafdc3d9947  vmovaps [rsp+0x40], xmm4
00007eafdc3d994d  vmovaps [rsp+0x50], xmm5
00007eafdc3d9953  vmovaps [rsp+0x60], xmm6
00007eafdc3d9959  vmovaps [rsp+0x70], xmm7
00007eafdc3d995f  vmovaps [rsp+0x80], xmm8
00007eafdc3d9968  vmovaps [rsp+0x90], xmm9
00007eafdc3d9971  vmovaps [rsp+0xA0], xmm10
00007eafdc3d997a  vmovaps [rsp+0xB0], xmm11
00007eafdc3d9983  vmovaps [rsp+0xC0], xmm12
00007eafdc3d998c  vmovaps [rsp+0xD0], xmm13
00007eafdc3d9995  vmovaps [rsp+0xE0], xmm14
00007eafdc3d999e  sub rsp, 0x30
00007eafdc3d99a2  movaps [rsp], xmm15
00007eafdc3d99a7  movaps [rsp+0x10], xmm1
00007eafdc3d99ac  movaps [rsp+0x20], xmm5
00007eafdc3d99b1  lea rdi, [rsp]
00007eafdc3d99b5  mov esi, 0x00
00007eafdc3d99ba  mov rax, 0x645891675530
00007eafdc3d99c4  call rax
00007eafdc3d99c6  movaps xmm15, [rsp]
00007eafdc3d99cb  add rsp, 0x30
00007eafdc3d99cf  vmovaps xmm0, [rsp]
00007eafdc3d99d4  vmovaps xmm1, [rsp+0x10]
00007eafdc3d99da  vmovaps xmm2, [rsp+0x20]
00007eafdc3d99e0  vmovaps xmm3, [rsp+0x30]
00007eafdc3d99e6  vmovaps xmm4, [rsp+0x40]
00007eafdc3d99ec  vmovaps xmm5, [rsp+0x50]
00007eafdc3d99f2  vmovaps xmm6, [rsp+0x60]
00007eafdc3d99f8  vmovaps xmm7, [rsp+0x70]
00007eafdc3d99fe  vmovaps xmm8, [rsp+0x80]
00007eafdc3d9a07  vmovaps xmm9, [rsp+0x90]
00007eafdc3d9a10  vmovaps xmm10, [rsp+0xA0]
00007eafdc3d9a19  vmovaps xmm11, [rsp+0xB0]
00007eafdc3d9a22  vmovaps xmm12, [rsp+0xC0]
00007eafdc3d9a2b  vmovaps xmm13, [rsp+0xD0]
00007eafdc3d9a34  vmovaps xmm14, [rsp+0xE0]
00007eafdc3d9a3d  add rsp, 0xF0
00007eafdc3d9a44  pop r11
00007eafdc3d9a46  pop r10
00007eafdc3d9a48  pop r9
00007eafdc3d9a4a  pop r8
00007eafdc3d9a4c  pop rsi
00007eafdc3d9a4d  pop rdi
00007eafdc3d9a4e  pop rdx
00007eafdc3d9a4f  pop rcx
00007eafdc3d9a50  pop rax
00007eafdc3d9a51  add rsp, 0x08
00007eafdc3d9a55  jmp 0x00007EAFDC3D62C0
00007eafdc3d9a5a  call 0x00007EAFDC2D64F0
00007eafdc3d9a5f  jmp 0x00007EAFDC3D631B
00007eafdc3d9a64  sub rsp, 0x08
00007eafdc3d9a68  push rax
00007eafdc3d9a69  push rcx
00007eafdc3d9a6a  push rdx
00007eafdc3d9a6b  push rdi
00007eafdc3d9a6c  push rsi
00007eafdc3d9a6d  push r8
00007eafdc3d9a6f  push r9
00007eafdc3d9a71  push r10
00007eafdc3d9a73  push r11
00007eafdc3d9a75  sub rsp, 0xF0
00007eafdc3d9a7c  vmovaps [rsp], xmm0
00007eafdc3d9a81  vmovaps [rsp+0x10], xmm1
00007eafdc3d9a87  vmovaps [rsp+0x20], xmm2
00007eafdc3d9a8d  vmovaps [rsp+0x30], xmm3
00007eafdc3d9a93  vmovaps [rsp+0x40], xmm4
00007eafdc3d9a99  vmovaps [rsp+0x50], xmm5
00007eafdc3d9a9f  vmovaps [rsp+0x60], xmm6
00007eafdc3d9aa5  vmovaps [rsp+0x70], xmm7
00007eafdc3d9aab  vmovaps [rsp+0x80], xmm8
00007eafdc3d9ab4  vmovaps [rsp+0x90], xmm10
00007eafdc3d9abd  vmovaps [rsp+0xA0], xmm11
00007eafdc3d9ac6  vmovaps [rsp+0xB0], xmm12
00007eafdc3d9acf  vmovaps [rsp+0xC0], xmm13
00007eafdc3d9ad8  vmovaps [rsp+0xD0], xmm14
00007eafdc3d9ae1  vmovaps [rsp+0xE0], xmm15
00007eafdc3d9aea  sub rsp, 0x30
00007eafdc3d9aee  movaps [rsp], xmm9
00007eafdc3d9af3  movaps [rsp+0x10], xmm8
00007eafdc3d9af9  movaps [rsp+0x20], xmm11
00007eafdc3d9aff  lea rdi, [rsp]
00007eafdc3d9b03  mov esi, 0x00
00007eafdc3d9b08  mov rax, 0x645891675530
00007eafdc3d9b12  call rax
00007eafdc3d9b14  movaps xmm9, [rsp]
00007eafdc3d9b19  add rsp, 0x30
00007eafdc3d9b1d  vmovaps xmm0, [rsp]
00007eafdc3d9b22  vmovaps xmm1, [rsp+0x10]
00007eafdc3d9b28  vmovaps xmm2, [rsp+0x20]
00007eafdc3d9b2e  vmovaps xmm3, [rsp+0x30]
00007eafdc3d9b34  vmovaps xmm4, [rsp+0x40]
00007eafdc3d9b3a  vmovaps xmm5, [rsp+0x50]
00007eafdc3d9b40  vmovaps xmm6, [rsp+0x60]
00007eafdc3d9b46  vmovaps xmm7, [rsp+0x70]
00007eafdc3d9b4c  vmovaps xmm8, [rsp+0x80]
00007eafdc3d9b55  vmovaps xmm10, [rsp+0x90]
00007eafdc3d9b5e  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d9b67  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d9b70  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d9b79  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d9b82  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d9b8b  add rsp, 0xF0
00007eafdc3d9b92  pop r11
00007eafdc3d9b94  pop r10
00007eafdc3d9b96  pop r9
00007eafdc3d9b98  pop r8
00007eafdc3d9b9a  pop rsi
00007eafdc3d9b9b  pop rdi
00007eafdc3d9b9c  pop rdx
00007eafdc3d9b9d  pop rcx
00007eafdc3d9b9e  pop rax
00007eafdc3d9b9f  add rsp, 0x08
00007eafdc3d9ba3  jmp 0x00007EAFDC3D6352
00007eafdc3d9ba8  sub rsp, 0x08
00007eafdc3d9bac  push rax
00007eafdc3d9bad  push rcx
00007eafdc3d9bae  push rdx
00007eafdc3d9baf  push rdi
00007eafdc3d9bb0  push rsi
00007eafdc3d9bb1  push r8
00007eafdc3d9bb3  push r9
00007eafdc3d9bb5  push r10
00007eafdc3d9bb7  push r11
00007eafdc3d9bb9  sub rsp, 0xF0
00007eafdc3d9bc0  vmovaps [rsp], xmm0
00007eafdc3d9bc5  vmovaps [rsp+0x10], xmm1
00007eafdc3d9bcb  vmovaps [rsp+0x20], xmm2
00007eafdc3d9bd1  vmovaps [rsp+0x30], xmm3
00007eafdc3d9bd7  vmovaps [rsp+0x40], xmm4
00007eafdc3d9bdd  vmovaps [rsp+0x50], xmm5
00007eafdc3d9be3  vmovaps [rsp+0x60], xmm6
00007eafdc3d9be9  vmovaps [rsp+0x70], xmm7
00007eafdc3d9bef  vmovaps [rsp+0x80], xmm8
00007eafdc3d9bf8  vmovaps [rsp+0x90], xmm9
00007eafdc3d9c01  vmovaps [rsp+0xA0], xmm10
00007eafdc3d9c0a  vmovaps [rsp+0xB0], xmm12
00007eafdc3d9c13  vmovaps [rsp+0xC0], xmm13
00007eafdc3d9c1c  vmovaps [rsp+0xD0], xmm14
00007eafdc3d9c25  vmovaps [rsp+0xE0], xmm15
00007eafdc3d9c2e  sub rsp, 0x30
00007eafdc3d9c32  movaps [rsp], xmm11
00007eafdc3d9c37  movaps [rsp+0x10], xmm10
00007eafdc3d9c3d  movaps [rsp+0x20], xmm6
00007eafdc3d9c42  lea rdi, [rsp]
00007eafdc3d9c46  mov esi, 0x00
00007eafdc3d9c4b  mov rax, 0x645891675530
00007eafdc3d9c55  call rax
00007eafdc3d9c57  movaps xmm11, [rsp]
00007eafdc3d9c5c  add rsp, 0x30
00007eafdc3d9c60  vmovaps xmm0, [rsp]
00007eafdc3d9c65  vmovaps xmm1, [rsp+0x10]
00007eafdc3d9c6b  vmovaps xmm2, [rsp+0x20]
00007eafdc3d9c71  vmovaps xmm3, [rsp+0x30]
00007eafdc3d9c77  vmovaps xmm4, [rsp+0x40]
00007eafdc3d9c7d  vmovaps xmm5, [rsp+0x50]
00007eafdc3d9c83  vmovaps xmm6, [rsp+0x60]
00007eafdc3d9c89  vmovaps xmm7, [rsp+0x70]
00007eafdc3d9c8f  vmovaps xmm8, [rsp+0x80]
00007eafdc3d9c98  vmovaps xmm9, [rsp+0x90]
00007eafdc3d9ca1  vmovaps xmm10, [rsp+0xA0]
00007eafdc3d9caa  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d9cb3  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d9cbc  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d9cc5  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d9cce  add rsp, 0xF0
00007eafdc3d9cd5  pop r11
00007eafdc3d9cd7  pop r10
00007eafdc3d9cd9  pop r9
00007eafdc3d9cdb  pop r8
00007eafdc3d9cdd  pop rsi
00007eafdc3d9cde  pop rdi
00007eafdc3d9cdf  pop rdx
00007eafdc3d9ce0  pop rcx
00007eafdc3d9ce1  pop rax
00007eafdc3d9ce2  add rsp, 0x08
00007eafdc3d9ce6  jmp 0x00007EAFDC3D636D
00007eafdc3d9ceb  sub rsp, 0x08
00007eafdc3d9cef  push rax
00007eafdc3d9cf0  push rcx
00007eafdc3d9cf1  push rdx
00007eafdc3d9cf2  push rdi
00007eafdc3d9cf3  push rsi
00007eafdc3d9cf4  push r8
00007eafdc3d9cf6  push r9
00007eafdc3d9cf8  push r10
00007eafdc3d9cfa  push r11
00007eafdc3d9cfc  sub rsp, 0xF0
00007eafdc3d9d03  vmovaps [rsp], xmm0
00007eafdc3d9d08  vmovaps [rsp+0x10], xmm1
00007eafdc3d9d0e  vmovaps [rsp+0x20], xmm2
00007eafdc3d9d14  vmovaps [rsp+0x30], xmm3
00007eafdc3d9d1a  vmovaps [rsp+0x40], xmm4
00007eafdc3d9d20  vmovaps [rsp+0x50], xmm5
00007eafdc3d9d26  vmovaps [rsp+0x60], xmm6
00007eafdc3d9d2c  vmovaps [rsp+0x70], xmm7
00007eafdc3d9d32  vmovaps [rsp+0x80], xmm8
00007eafdc3d9d3b  vmovaps [rsp+0x90], xmm9
00007eafdc3d9d44  vmovaps [rsp+0xA0], xmm11
00007eafdc3d9d4d  vmovaps [rsp+0xB0], xmm12
00007eafdc3d9d56  vmovaps [rsp+0xC0], xmm13
00007eafdc3d9d5f  vmovaps [rsp+0xD0], xmm14
00007eafdc3d9d68  vmovaps [rsp+0xE0], xmm15
00007eafdc3d9d71  sub rsp, 0x30
00007eafdc3d9d75  movaps [rsp], xmm10
00007eafdc3d9d7a  movaps [rsp+0x10], xmm14
00007eafdc3d9d80  movaps [rsp+0x20], xmm4
00007eafdc3d9d85  lea rdi, [rsp]
00007eafdc3d9d89  mov esi, 0x00
00007eafdc3d9d8e  mov rax, 0x645891675530
00007eafdc3d9d98  call rax
00007eafdc3d9d9a  movaps xmm10, [rsp]
00007eafdc3d9d9f  add rsp, 0x30
00007eafdc3d9da3  vmovaps xmm0, [rsp]
00007eafdc3d9da8  vmovaps xmm1, [rsp+0x10]
00007eafdc3d9dae  vmovaps xmm2, [rsp+0x20]
00007eafdc3d9db4  vmovaps xmm3, [rsp+0x30]
00007eafdc3d9dba  vmovaps xmm4, [rsp+0x40]
00007eafdc3d9dc0  vmovaps xmm5, [rsp+0x50]
00007eafdc3d9dc6  vmovaps xmm6, [rsp+0x60]
00007eafdc3d9dcc  vmovaps xmm7, [rsp+0x70]
00007eafdc3d9dd2  vmovaps xmm8, [rsp+0x80]
00007eafdc3d9ddb  vmovaps xmm9, [rsp+0x90]
00007eafdc3d9de4  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d9ded  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d9df6  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d9dff  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d9e08  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d9e11  add rsp, 0xF0
00007eafdc3d9e18  pop r11
00007eafdc3d9e1a  pop r10
00007eafdc3d9e1c  pop r9
00007eafdc3d9e1e  pop r8
00007eafdc3d9e20  pop rsi
00007eafdc3d9e21  pop rdi
00007eafdc3d9e22  pop rdx
00007eafdc3d9e23  pop rcx
00007eafdc3d9e24  pop rax
00007eafdc3d9e25  add rsp, 0x08
00007eafdc3d9e29  jmp 0x00007EAFDC3D6388
00007eafdc3d9e2e  sub rsp, 0x08
00007eafdc3d9e32  push rax
00007eafdc3d9e33  push rcx
00007eafdc3d9e34  push rdx
00007eafdc3d9e35  push rdi
00007eafdc3d9e36  push rsi
00007eafdc3d9e37  push r8
00007eafdc3d9e39  push r9
00007eafdc3d9e3b  push r10
00007eafdc3d9e3d  push r11
00007eafdc3d9e3f  sub rsp, 0xF0
00007eafdc3d9e46  vmovaps [rsp], xmm0
00007eafdc3d9e4b  vmovaps [rsp+0x10], xmm1
00007eafdc3d9e51  vmovaps [rsp+0x20], xmm2
00007eafdc3d9e57  vmovaps [rsp+0x30], xmm3
00007eafdc3d9e5d  vmovaps [rsp+0x40], xmm4
00007eafdc3d9e63  vmovaps [rsp+0x50], xmm5
00007eafdc3d9e69  vmovaps [rsp+0x60], xmm6
00007eafdc3d9e6f  vmovaps [rsp+0x70], xmm7
00007eafdc3d9e75  vmovaps [rsp+0x80], xmm9
00007eafdc3d9e7e  vmovaps [rsp+0x90], xmm10
00007eafdc3d9e87  vmovaps [rsp+0xA0], xmm11
00007eafdc3d9e90  vmovaps [rsp+0xB0], xmm12
00007eafdc3d9e99  vmovaps [rsp+0xC0], xmm13
00007eafdc3d9ea2  vmovaps [rsp+0xD0], xmm14
00007eafdc3d9eab  vmovaps [rsp+0xE0], xmm15
00007eafdc3d9eb4  sub rsp, 0x30
00007eafdc3d9eb8  movaps [rsp], xmm8
00007eafdc3d9ebd  movaps [rsp+0x10], xmm1
00007eafdc3d9ec2  movaps [rsp+0x20], xmm14
00007eafdc3d9ec8  lea rdi, [rsp]
00007eafdc3d9ecc  mov esi, 0x00
00007eafdc3d9ed1  mov rax, 0x645891675530
00007eafdc3d9edb  call rax
00007eafdc3d9edd  movaps xmm8, [rsp]
00007eafdc3d9ee2  add rsp, 0x30
00007eafdc3d9ee6  vmovaps xmm0, [rsp]
00007eafdc3d9eeb  vmovaps xmm1, [rsp+0x10]
00007eafdc3d9ef1  vmovaps xmm2, [rsp+0x20]
00007eafdc3d9ef7  vmovaps xmm3, [rsp+0x30]
00007eafdc3d9efd  vmovaps xmm4, [rsp+0x40]
00007eafdc3d9f03  vmovaps xmm5, [rsp+0x50]
00007eafdc3d9f09  vmovaps xmm6, [rsp+0x60]
00007eafdc3d9f0f  vmovaps xmm7, [rsp+0x70]
00007eafdc3d9f15  vmovaps xmm9, [rsp+0x80]
00007eafdc3d9f1e  vmovaps xmm10, [rsp+0x90]
00007eafdc3d9f27  vmovaps xmm11, [rsp+0xA0]
00007eafdc3d9f30  vmovaps xmm12, [rsp+0xB0]
00007eafdc3d9f39  vmovaps xmm13, [rsp+0xC0]
00007eafdc3d9f42  vmovaps xmm14, [rsp+0xD0]
00007eafdc3d9f4b  vmovaps xmm15, [rsp+0xE0]
00007eafdc3d9f54  add rsp, 0xF0
00007eafdc3d9f5b  pop r11
00007eafdc3d9f5d  pop r10
00007eafdc3d9f5f  pop r9
00007eafdc3d9f61  pop r8
00007eafdc3d9f63  pop rsi
00007eafdc3d9f64  pop rdi
00007eafdc3d9f65  pop rdx
00007eafdc3d9f66  pop rcx
00007eafdc3d9f67  pop rax
00007eafdc3d9f68  add rsp, 0x08
00007eafdc3d9f6c  jmp 0x00007EAFDC3D63AE
00007eafdc3d9f71  sub rsp, 0x08
00007eafdc3d9f75  push rax
00007eafdc3d9f76  push rcx
00007eafdc3d9f77  push rdx
00007eafdc3d9f78  push rdi
00007eafdc3d9f79  push rsi
00007eafdc3d9f7a  push r8
00007eafdc3d9f7c  push r9
00007eafdc3d9f7e  push r10
00007eafdc3d9f80  push r11
00007eafdc3d9f82  sub rsp, 0xF0
00007eafdc3d9f89  vmovaps [rsp], xmm0
00007eafdc3d9f8e  vmovaps [rsp+0x10], xmm1
00007eafdc3d9f94  vmovaps [rsp+0x20], xmm2
00007eafdc3d9f9a  vmovaps [rsp+0x30], xmm3
00007eafdc3d9fa0  vmovaps [rsp+0x40], xmm4
00007eafdc3d9fa6  vmovaps [rsp+0x50], xmm5
00007eafdc3d9fac  vmovaps [rsp+0x60], xmm7
00007eafdc3d9fb2  vmovaps [rsp+0x70], xmm8
00007eafdc3d9fb8  vmovaps [rsp+0x80], xmm9
00007eafdc3d9fc1  vmovaps [rsp+0x90], xmm10
00007eafdc3d9fca  vmovaps [rsp+0xA0], xmm11
00007eafdc3d9fd3  vmovaps [rsp+0xB0], xmm12
00007eafdc3d9fdc  vmovaps [rsp+0xC0], xmm13
00007eafdc3d9fe5  vmovaps [rsp+0xD0], xmm14
00007eafdc3d9fee  vmovaps [rsp+0xE0], xmm15
00007eafdc3d9ff7  sub rsp, 0x30
00007eafdc3d9ffb  movaps [rsp], xmm6
00007eafdc3d9fff  movaps [rsp+0x10], xmm1
00007eafdc3da004  movaps [rsp+0x20], xmm14
00007eafdc3da00a  lea rdi, [rsp]
00007eafdc3da00e  mov esi, 0x00
00007eafdc3da013  mov rax, 0x645891675530
00007eafdc3da01d  call rax
00007eafdc3da01f  movaps xmm6, [rsp]
00007eafdc3da023  add rsp, 0x30
00007eafdc3da027  vmovaps xmm0, [rsp]
00007eafdc3da02c  vmovaps xmm1, [rsp+0x10]
00007eafdc3da032  vmovaps xmm2, [rsp+0x20]
00007eafdc3da038  vmovaps xmm3, [rsp+0x30]
00007eafdc3da03e  vmovaps xmm4, [rsp+0x40]
00007eafdc3da044  vmovaps xmm5, [rsp+0x50]
00007eafdc3da04a  vmovaps xmm7, [rsp+0x60]
00007eafdc3da050  vmovaps xmm8, [rsp+0x70]
00007eafdc3da056  vmovaps xmm9, [rsp+0x80]
00007eafdc3da05f  vmovaps xmm10, [rsp+0x90]
00007eafdc3da068  vmovaps xmm11, [rsp+0xA0]
00007eafdc3da071  vmovaps xmm12, [rsp+0xB0]
00007eafdc3da07a  vmovaps xmm13, [rsp+0xC0]
00007eafdc3da083  vmovaps xmm14, [rsp+0xD0]
00007eafdc3da08c  vmovaps xmm15, [rsp+0xE0]
00007eafdc3da095  add rsp, 0xF0
00007eafdc3da09c  pop r11
00007eafdc3da09e  pop r10
00007eafdc3da0a0  pop r9
00007eafdc3da0a2  pop r8
00007eafdc3da0a4  pop rsi
00007eafdc3da0a5  pop rdi
00007eafdc3da0a6  pop rdx
00007eafdc3da0a7  pop rcx
00007eafdc3da0a8  pop rax
00007eafdc3da0a9  add rsp, 0x08
00007eafdc3da0ad  jmp 0x00007EAFDC3D63DA
00007eafdc3da0b2  sub rsp, 0x08
00007eafdc3da0b6  push rax
00007eafdc3da0b7  push rcx
00007eafdc3da0b8  push rdx
00007eafdc3da0b9  push rdi
00007eafdc3da0ba  push rsi
00007eafdc3da0bb  push r8
00007eafdc3da0bd  push r9
00007eafdc3da0bf  push r10
00007eafdc3da0c1  push r11
00007eafdc3da0c3  sub rsp, 0xF0
00007eafdc3da0ca  vmovaps [rsp], xmm0
00007eafdc3da0cf  vmovaps [rsp+0x10], xmm1
00007eafdc3da0d5  vmovaps [rsp+0x20], xmm2
00007eafdc3da0db  vmovaps [rsp+0x30], xmm3
00007eafdc3da0e1  vmovaps [rsp+0x40], xmm4
00007eafdc3da0e7  vmovaps [rsp+0x50], xmm5
00007eafdc3da0ed  vmovaps [rsp+0x60], xmm6
00007eafdc3da0f3  vmovaps [rsp+0x70], xmm7
00007eafdc3da0f9  vmovaps [rsp+0x80], xmm8
00007eafdc3da102  vmovaps [rsp+0x90], xmm9
00007eafdc3da10b  vmovaps [rsp+0xA0], xmm10
00007eafdc3da114  vmovaps [rsp+0xB0], xmm11
00007eafdc3da11d  vmovaps [rsp+0xC0], xmm12
00007eafdc3da126  vmovaps [rsp+0xD0], xmm13
00007eafdc3da12f  vmovaps [rsp+0xE0], xmm15
00007eafdc3da138  sub rsp, 0x30
00007eafdc3da13c  movaps [rsp], xmm14
00007eafdc3da141  movaps [rsp+0x10], xmm12
00007eafdc3da147  movaps [rsp+0x20], xmm1
00007eafdc3da14c  lea rdi, [rsp]
00007eafdc3da150  mov esi, 0x00
00007eafdc3da155  mov rax, 0x645891675530
00007eafdc3da15f  call rax
00007eafdc3da161  movaps xmm14, [rsp]
00007eafdc3da166  add rsp, 0x30
00007eafdc3da16a  vmovaps xmm0, [rsp]
00007eafdc3da16f  vmovaps xmm1, [rsp+0x10]
00007eafdc3da175  vmovaps xmm2, [rsp+0x20]
00007eafdc3da17b  vmovaps xmm3, [rsp+0x30]
00007eafdc3da181  vmovaps xmm4, [rsp+0x40]
00007eafdc3da187  vmovaps xmm5, [rsp+0x50]
00007eafdc3da18d  vmovaps xmm6, [rsp+0x60]
00007eafdc3da193  vmovaps xmm7, [rsp+0x70]
00007eafdc3da199  vmovaps xmm8, [rsp+0x80]
00007eafdc3da1a2  vmovaps xmm9, [rsp+0x90]
00007eafdc3da1ab  vmovaps xmm10, [rsp+0xA0]
00007eafdc3da1b4  vmovaps xmm11, [rsp+0xB0]
00007eafdc3da1bd  vmovaps xmm12, [rsp+0xC0]
00007eafdc3da1c6  vmovaps xmm13, [rsp+0xD0]
00007eafdc3da1cf  vmovaps xmm15, [rsp+0xE0]
00007eafdc3da1d8  add rsp, 0xF0
00007eafdc3da1df  pop r11
00007eafdc3da1e1  pop r10
00007eafdc3da1e3  pop r9
00007eafdc3da1e5  pop r8
00007eafdc3da1e7  pop rsi
00007eafdc3da1e8  pop rdi
00007eafdc3da1e9  pop rdx
00007eafdc3da1ea  pop rcx
00007eafdc3da1eb  pop rax
00007eafdc3da1ec  add rsp, 0x08
00007eafdc3da1f0  jmp 0x00007EAFDC3D6400
00007eafdc3da1f5  sub rsp, 0x08
00007eafdc3da1f9  push rax
00007eafdc3da1fa  push rcx
00007eafdc3da1fb  push rdx
00007eafdc3da1fc  push rdi
00007eafdc3da1fd  push rsi
00007eafdc3da1fe  push r8
00007eafdc3da200  push r9
00007eafdc3da202  push r10
00007eafdc3da204  push r11
00007eafdc3da206  sub rsp, 0xF0
00007eafdc3da20d  vmovaps [rsp], xmm0
00007eafdc3da212  vmovaps [rsp+0x10], xmm2
00007eafdc3da218  vmovaps [rsp+0x20], xmm3
00007eafdc3da21e  vmovaps [rsp+0x30], xmm4
00007eafdc3da224  vmovaps [rsp+0x40], xmm5
00007eafdc3da22a  vmovaps [rsp+0x50], xmm6
00007eafdc3da230  vmovaps [rsp+0x60], xmm7
00007eafdc3da236  vmovaps [rsp+0x70], xmm8
00007eafdc3da23c  vmovaps [rsp+0x80], xmm9
00007eafdc3da245  vmovaps [rsp+0x90], xmm10
00007eafdc3da24e  vmovaps [rsp+0xA0], xmm11
00007eafdc3da257  vmovaps [rsp+0xB0], xmm12
00007eafdc3da260  vmovaps [rsp+0xC0], xmm13
00007eafdc3da269  vmovaps [rsp+0xD0], xmm14
00007eafdc3da272  vmovaps [rsp+0xE0], xmm15
00007eafdc3da27b  sub rsp, 0x30
00007eafdc3da27f  movaps [rsp], xmm1
00007eafdc3da283  movaps [rsp+0x10], xmm13
00007eafdc3da289  movaps [rsp+0x20], xmm9
00007eafdc3da28f  lea rdi, [rsp]
00007eafdc3da293  mov esi, 0x00
00007eafdc3da298  mov rax, 0x645891675530
00007eafdc3da2a2  call rax
00007eafdc3da2a4  movaps xmm1, [rsp]
00007eafdc3da2a8  add rsp, 0x30
00007eafdc3da2ac  vmovaps xmm0, [rsp]
00007eafdc3da2b1  vmovaps xmm2, [rsp+0x10]
00007eafdc3da2b7  vmovaps xmm3, [rsp+0x20]
00007eafdc3da2bd  vmovaps xmm4, [rsp+0x30]
00007eafdc3da2c3  vmovaps xmm5, [rsp+0x40]
00007eafdc3da2c9  vmovaps xmm6, [rsp+0x50]
00007eafdc3da2cf  vmovaps xmm7, [rsp+0x60]
00007eafdc3da2d5  vmovaps xmm8, [rsp+0x70]
00007eafdc3da2db  vmovaps xmm9, [rsp+0x80]
00007eafdc3da2e4  vmovaps xmm10, [rsp+0x90]
00007eafdc3da2ed  vmovaps xmm11, [rsp+0xA0]
00007eafdc3da2f6  vmovaps xmm12, [rsp+0xB0]
00007eafdc3da2ff  vmovaps xmm13, [rsp+0xC0]
00007eafdc3da308  vmovaps xmm14, [rsp+0xD0]
00007eafdc3da311  vmovaps xmm15, [rsp+0xE0]
00007eafdc3da31a  add rsp, 0xF0
00007eafdc3da321  pop r11
00007eafdc3da323  pop r10
00007eafdc3da325  pop r9
00007eafdc3da327  pop r8
00007eafdc3da329  pop rsi
00007eafdc3da32a  pop rdi
00007eafdc3da32b  pop rdx
00007eafdc3da32c  pop rcx
00007eafdc3da32d  pop rax
00007eafdc3da32e  add rsp, 0x08
00007eafdc3da332  jmp 0x00007EAFDC3D641A
00007eafdc3da337  sub rsp, 0x08
00007eafdc3da33b  push rax
00007eafdc3da33c  push rcx
00007eafdc3da33d  push rdx
00007eafdc3da33e  push rdi
00007eafdc3da33f  push rsi
00007eafdc3da340  push r8
00007eafdc3da342  push r9
00007eafdc3da344  push r10
00007eafdc3da346  push r11
00007eafdc3da348  sub rsp, 0xF0
00007eafdc3da34f  vmovaps [rsp], xmm0
00007eafdc3da354  vmovaps [rsp+0x10], xmm1
00007eafdc3da35a  vmovaps [rsp+0x20], xmm2
00007eafdc3da360  vmovaps [rsp+0x30], xmm3
00007eafdc3da366  vmovaps [rsp+0x40], xmm4
00007eafdc3da36c  vmovaps [rsp+0x50], xmm5
00007eafdc3da372  vmovaps [rsp+0x60], xmm6
00007eafdc3da378  vmovaps [rsp+0x70], xmm7
00007eafdc3da37e  vmovaps [rsp+0x80], xmm8
00007eafdc3da387  vmovaps [rsp+0x90], xmm9
00007eafdc3da390  vmovaps [rsp+0xA0], xmm10
00007eafdc3da399  vmovaps [rsp+0xB0], xmm11
00007eafdc3da3a2  vmovaps [rsp+0xC0], xmm13
00007eafdc3da3ab  vmovaps [rsp+0xD0], xmm14
00007eafdc3da3b4  vmovaps [rsp+0xE0], xmm15
00007eafdc3da3bd  sub rsp, 0x30
00007eafdc3da3c1  movaps [rsp], xmm12
00007eafdc3da3c6  movaps [rsp+0x10], xmm7
00007eafdc3da3cb  movaps [rsp+0x20], xmm13
00007eafdc3da3d1  lea rdi, [rsp]
00007eafdc3da3d5  mov esi, 0x00
00007eafdc3da3da  mov rax, 0x645891675530
00007eafdc3da3e4  call rax
00007eafdc3da3e6  movaps xmm12, [rsp]
00007eafdc3da3eb  add rsp, 0x30
00007eafdc3da3ef  vmovaps xmm0, [rsp]
00007eafdc3da3f4  vmovaps xmm1, [rsp+0x10]
00007eafdc3da3fa  vmovaps xmm2, [rsp+0x20]
00007eafdc3da400  vmovaps xmm3, [rsp+0x30]
00007eafdc3da406  vmovaps xmm4, [rsp+0x40]
00007eafdc3da40c  vmovaps xmm5, [rsp+0x50]
00007eafdc3da412  vmovaps xmm6, [rsp+0x60]
00007eafdc3da418  vmovaps xmm7, [rsp+0x70]
00007eafdc3da41e  vmovaps xmm8, [rsp+0x80]
00007eafdc3da427  vmovaps xmm9, [rsp+0x90]
00007eafdc3da430  vmovaps xmm10, [rsp+0xA0]
00007eafdc3da439  vmovaps xmm11, [rsp+0xB0]
00007eafdc3da442  vmovaps xmm13, [rsp+0xC0]
00007eafdc3da44b  vmovaps xmm14, [rsp+0xD0]
00007eafdc3da454  vmovaps xmm15, [rsp+0xE0]
00007eafdc3da45d  add rsp, 0xF0
00007eafdc3da464  pop r11
00007eafdc3da466  pop r10
00007eafdc3da468  pop r9
00007eafdc3da46a  pop r8
00007eafdc3da46c  pop rsi
00007eafdc3da46d  pop rdi
00007eafdc3da46e  pop rdx
00007eafdc3da46f  pop rcx
00007eafdc3da470  pop rax
00007eafdc3da471  add rsp, 0x08
00007eafdc3da475  jmp 0x00007EAFDC3D6441
00007eafdc3da47a  sub rsp, 0x08
00007eafdc3da47e  push rax
00007eafdc3da47f  push rcx
00007eafdc3da480  push rdx
00007eafdc3da481  push rdi
00007eafdc3da482  push rsi
00007eafdc3da483  push r8
00007eafdc3da485  push r9
00007eafdc3da487  push r10
00007eafdc3da489  push r11
00007eafdc3da48b  sub rsp, 0xF0
00007eafdc3da492  vmovaps [rsp], xmm0
00007eafdc3da497  vmovaps [rsp+0x10], xmm1
00007eafdc3da49d  vmovaps [rsp+0x20], xmm2
00007eafdc3da4a3  vmovaps [rsp+0x30], xmm3
00007eafdc3da4a9  vmovaps [rsp+0x40], xmm4
00007eafdc3da4af  vmovaps [rsp+0x50], xmm5
00007eafdc3da4b5  vmovaps [rsp+0x60], xmm6
00007eafdc3da4bb  vmovaps [rsp+0x70], xmm7
00007eafdc3da4c1  vmovaps [rsp+0x80], xmm8
00007eafdc3da4ca  vmovaps [rsp+0x90], xmm9
00007eafdc3da4d3  vmovaps [rsp+0xA0], xmm10
00007eafdc3da4dc  vmovaps [rsp+0xB0], xmm11
00007eafdc3da4e5  vmovaps [rsp+0xC0], xmm12
00007eafdc3da4ee  vmovaps [rsp+0xD0], xmm14
00007eafdc3da4f7  vmovaps [rsp+0xE0], xmm15
00007eafdc3da500  sub rsp, 0x30
00007eafdc3da504  movaps [rsp], xmm13
00007eafdc3da509  movaps [rsp+0x10], xmm15
00007eafdc3da50f  movaps [rsp+0x20], xmm8
00007eafdc3da515  lea rdi, [rsp]
00007eafdc3da519  mov esi, 0x00
00007eafdc3da51e  mov rax, 0x645891675530
00007eafdc3da528  call rax
00007eafdc3da52a  movaps xmm13, [rsp]
00007eafdc3da52f  add rsp, 0x30
00007eafdc3da533  vmovaps xmm0, [rsp]
00007eafdc3da538  vmovaps xmm1, [rsp+0x10]
00007eafdc3da53e  vmovaps xmm2, [rsp+0x20]
00007eafdc3da544  vmovaps xmm3, [rsp+0x30]
00007eafdc3da54a  vmovaps xmm4, [rsp+0x40]
00007eafdc3da550  vmovaps xmm5, [rsp+0x50]
00007eafdc3da556  vmovaps xmm6, [rsp+0x60]
00007eafdc3da55c  vmovaps xmm7, [rsp+0x70]
00007eafdc3da562  vmovaps xmm8, [rsp+0x80]
00007eafdc3da56b  vmovaps xmm9, [rsp+0x90]
00007eafdc3da574  vmovaps xmm10, [rsp+0xA0]
00007eafdc3da57d  vmovaps xmm11, [rsp+0xB0]
00007eafdc3da586  vmovaps xmm12, [rsp+0xC0]
00007eafdc3da58f  vmovaps xmm14, [rsp+0xD0]
00007eafdc3da598  vmovaps xmm15, [rsp+0xE0]
00007eafdc3da5a1  add rsp, 0xF0
00007eafdc3da5a8  pop r11
00007eafdc3da5aa  pop r10
00007eafdc3da5ac  pop r9
00007eafdc3da5ae  pop r8
00007eafdc3da5b0  pop rsi
00007eafdc3da5b1  pop rdi
00007eafdc3da5b2  pop rdx
00007eafdc3da5b3  pop rcx
00007eafdc3da5b4  pop rax
00007eafdc3da5b5  add rsp, 0x08
00007eafdc3da5b9  jmp 0x00007EAFDC3D645C
00007eafdc3da5be  sub rsp, 0x08
00007eafdc3da5c2  push rax
00007eafdc3da5c3  push rcx
00007eafdc3da5c4  push rdx
00007eafdc3da5c5  push rdi
00007eafdc3da5c6  push rsi
00007eafdc3da5c7  push r8
00007eafdc3da5c9  push r9
00007eafdc3da5cb  push r10
00007eafdc3da5cd  push r11
00007eafdc3da5cf  sub rsp, 0xF0
00007eafdc3da5d6  vmovaps [rsp], xmm0
00007eafdc3da5db  vmovaps [rsp+0x10], xmm1
00007eafdc3da5e1  vmovaps [rsp+0x20], xmm2
00007eafdc3da5e7  vmovaps [rsp+0x30], xmm3
00007eafdc3da5ed  vmovaps [rsp+0x40], xmm4
00007eafdc3da5f3  vmovaps [rsp+0x50], xmm5
00007eafdc3da5f9  vmovaps [rsp+0x60], xmm6
00007eafdc3da5ff  vmovaps [rsp+0x70], xmm7
00007eafdc3da605  vmovaps [rsp+0x80], xmm9
00007eafdc3da60e  vmovaps [rsp+0x90], xmm10
00007eafdc3da617  vmovaps [rsp+0xA0], xmm11
00007eafdc3da620  vmovaps [rsp+0xB0], xmm12
00007eafdc3da629  vmovaps [rsp+0xC0], xmm13
00007eafdc3da632  vmovaps [rsp+0xD0], xmm14
00007eafdc3da63b  vmovaps [rsp+0xE0], xmm15
00007eafdc3da644  sub rsp, 0x30
00007eafdc3da648  movaps [rsp], xmm8
00007eafdc3da64d  movaps [rsp+0x10], xmm15
00007eafdc3da653  movaps [rsp+0x20], xmm9
00007eafdc3da659  lea rdi, [rsp]
00007eafdc3da65d  mov esi, 0x00
00007eafdc3da662  mov rax, 0x645891675530
00007eafdc3da66c  call rax
00007eafdc3da66e  movaps xmm8, [rsp]
00007eafdc3da673  add rsp, 0x30
00007eafdc3da677  vmovaps xmm0, [rsp]
00007eafdc3da67c  vmovaps xmm1, [rsp+0x10]
00007eafdc3da682  vmovaps xmm2, [rsp+0x20]
00007eafdc3da688  vmovaps xmm3, [rsp+0x30]
00007eafdc3da68e  vmovaps xmm4, [rsp+0x40]
00007eafdc3da694  vmovaps xmm5, [rsp+0x50]
00007eafdc3da69a  vmovaps xmm6, [rsp+0x60]
00007eafdc3da6a0  vmovaps xmm7, [rsp+0x70]
00007eafdc3da6a6  vmovaps xmm9, [rsp+0x80]
00007eafdc3da6af  vmovaps xmm10, [rsp+0x90]
00007eafdc3da6b8  vmovaps xmm11, [rsp+0xA0]
00007eafdc3da6c1  vmovaps xmm12, [rsp+0xB0]
00007eafdc3da6ca  vmovaps xmm13, [rsp+0xC0]
00007eafdc3da6d3  vmovaps xmm14, [rsp+0xD0]
00007eafdc3da6dc  vmovaps xmm15, [rsp+0xE0]
00007eafdc3da6e5  add rsp, 0xF0
00007eafdc3da6ec  pop r11
00007eafdc3da6ee  pop r10
00007eafdc3da6f0  pop r9
00007eafdc3da6f2  pop r8
00007eafdc3da6f4  pop rsi
00007eafdc3da6f5  pop rdi
00007eafdc3da6f6  pop rdx
00007eafdc3da6f7  pop rcx
00007eafdc3da6f8  pop rax
00007eafdc3da6f9  add rsp, 0x08
00007eafdc3da6fd  jmp 0x00007EAFDC3D648A
00007eafdc3da702  sub rsp, 0x08
00007eafdc3da706  push rax
00007eafdc3da707  push rcx
00007eafdc3da708  push rdx
00007eafdc3da709  push rdi
00007eafdc3da70a  push rsi
00007eafdc3da70b  push r8
00007eafdc3da70d  push r9
00007eafdc3da70f  push r10
00007eafdc3da711  push r11
00007eafdc3da713  sub rsp, 0xF0
00007eafdc3da71a  vmovaps [rsp], xmm0
00007eafdc3da71f  vmovaps [rsp+0x10], xmm1
00007eafdc3da725  vmovaps [rsp+0x20], xmm2
00007eafdc3da72b  vmovaps [rsp+0x30], xmm3
00007eafdc3da731  vmovaps [rsp+0x40], xmm4
00007eafdc3da737  vmovaps [rsp+0x50], xmm5
00007eafdc3da73d  vmovaps [rsp+0x60], xmm6
00007eafdc3da743  vmovaps [rsp+0x70], xmm7
00007eafdc3da749  vmovaps [rsp+0x80], xmm8
00007eafdc3da752  vmovaps [rsp+0x90], xmm9
00007eafdc3da75b  vmovaps [rsp+0xA0], xmm10
00007eafdc3da764  vmovaps [rsp+0xB0], xmm11
00007eafdc3da76d  vmovaps [rsp+0xC0], xmm12
00007eafdc3da776  vmovaps [rsp+0xD0], xmm13
00007eafdc3da77f  vmovaps [rsp+0xE0], xmm14
00007eafdc3da788  sub rsp, 0x30
00007eafdc3da78c  movaps [rsp], xmm15
00007eafdc3da791  movaps [rsp+0x10], xmm11
00007eafdc3da797  movaps [rsp+0x20], xmm6
00007eafdc3da79c  lea rdi, [rsp]
00007eafdc3da7a0  mov esi, 0x00
00007eafdc3da7a5  mov rax, 0x645891675530
00007eafdc3da7af  call rax
00007eafdc3da7b1  movaps xmm15, [rsp]
00007eafdc3da7b6  add rsp, 0x30
00007eafdc3da7ba  vmovaps xmm0, [rsp]
00007eafdc3da7bf  vmovaps xmm1, [rsp+0x10]
00007eafdc3da7c5  vmovaps xmm2, [rsp+0x20]
00007eafdc3da7cb  vmovaps xmm3, [rsp+0x30]
00007eafdc3da7d1  vmovaps xmm4, [rsp+0x40]
00007eafdc3da7d7  vmovaps xmm5, [rsp+0x50]
00007eafdc3da7dd  vmovaps xmm6, [rsp+0x60]
00007eafdc3da7e3  vmovaps xmm7, [rsp+0x70]
00007eafdc3da7e9  vmovaps xmm8, [rsp+0x80]
00007eafdc3da7f2  vmovaps xmm9, [rsp+0x90]
00007eafdc3da7fb  vmovaps xmm10, [rsp+0xA0]
00007eafdc3da804  vmovaps xmm11, [rsp+0xB0]
00007eafdc3da80d  vmovaps xmm12, [rsp+0xC0]
00007eafdc3da816  vmovaps xmm13, [rsp+0xD0]
00007eafdc3da81f  vmovaps xmm14, [rsp+0xE0]
00007eafdc3da828  add rsp, 0xF0
00007eafdc3da82f  pop r11
00007eafdc3da831  pop r10
00007eafdc3da833  pop r9
00007eafdc3da835  pop r8
00007eafdc3da837  pop rsi
00007eafdc3da838  pop rdi
00007eafdc3da839  pop rdx
00007eafdc3da83a  pop rcx
00007eafdc3da83b  pop rax
00007eafdc3da83c  add rsp, 0x08
00007eafdc3da840  jmp 0x00007EAFDC3D64A5
00007eafdc3da845  sub rsp, 0x08
00007eafdc3da849  push rax
00007eafdc3da84a  push rcx
00007eafdc3da84b  push rdx
00007eafdc3da84c  push rdi
00007eafdc3da84d  push rsi
00007eafdc3da84e  push r8
00007eafdc3da850  push r9
00007eafdc3da852  push r10
00007eafdc3da854  push r11
00007eafdc3da856  sub rsp, 0xF0
00007eafdc3da85d  vmovaps [rsp], xmm0
00007eafdc3da862  vmovaps [rsp+0x10], xmm1
00007eafdc3da868  vmovaps [rsp+0x20], xmm2
00007eafdc3da86e  vmovaps [rsp+0x30], xmm3
00007eafdc3da874  vmovaps [rsp+0x40], xmm4
00007eafdc3da87a  vmovaps [rsp+0x50], xmm5
00007eafdc3da880  vmovaps [rsp+0x60], xmm6
00007eafdc3da886  vmovaps [rsp+0x70], xmm8
00007eafdc3da88c  vmovaps [rsp+0x80], xmm9
00007eafdc3da895  vmovaps [rsp+0x90], xmm10
00007eafdc3da89e  vmovaps [rsp+0xA0], xmm11
00007eafdc3da8a7  vmovaps [rsp+0xB0], xmm12
00007eafdc3da8b0  vmovaps [rsp+0xC0], xmm13
00007eafdc3da8b9  vmovaps [rsp+0xD0], xmm14
00007eafdc3da8c2  vmovaps [rsp+0xE0], xmm15
00007eafdc3da8cb  sub rsp, 0x30
00007eafdc3da8cf  movaps [rsp], xmm7
00007eafdc3da8d3  movaps [rsp+0x10], xmm11
00007eafdc3da8d9  movaps [rsp+0x20], xmm9
00007eafdc3da8df  lea rdi, [rsp]
00007eafdc3da8e3  mov esi, 0x00
00007eafdc3da8e8  mov rax, 0x645891675530
00007eafdc3da8f2  call rax
00007eafdc3da8f4  movaps xmm7, [rsp]
00007eafdc3da8f8  add rsp, 0x30
00007eafdc3da8fc  vmovaps xmm0, [rsp]
00007eafdc3da901  vmovaps xmm1, [rsp+0x10]
00007eafdc3da907  vmovaps xmm2, [rsp+0x20]
00007eafdc3da90d  vmovaps xmm3, [rsp+0x30]
00007eafdc3da913  vmovaps xmm4, [rsp+0x40]
00007eafdc3da919  vmovaps xmm5, [rsp+0x50]
00007eafdc3da91f  vmovaps xmm6, [rsp+0x60]
00007eafdc3da925  vmovaps xmm8, [rsp+0x70]
00007eafdc3da92b  vmovaps xmm9, [rsp+0x80]
00007eafdc3da934  vmovaps xmm10, [rsp+0x90]
00007eafdc3da93d  vmovaps xmm11, [rsp+0xA0]
00007eafdc3da946  vmovaps xmm12, [rsp+0xB0]
00007eafdc3da94f  vmovaps xmm13, [rsp+0xC0]
00007eafdc3da958  vmovaps xmm14, [rsp+0xD0]
00007eafdc3da961  vmovaps xmm15, [rsp+0xE0]
00007eafdc3da96a  add rsp, 0xF0
00007eafdc3da971  pop r11
00007eafdc3da973  pop r10
00007eafdc3da975  pop r9
00007eafdc3da977  pop r8
00007eafdc3da979  pop rsi
00007eafdc3da97a  pop rdi
00007eafdc3da97b  pop rdx
00007eafdc3da97c  pop rcx
00007eafdc3da97d  pop rax
00007eafdc3da97e  add rsp, 0x08
00007eafdc3da982  jmp 0x00007EAFDC3D64D2
00007eafdc3da987  sub rsp, 0x08
00007eafdc3da98b  push rax
00007eafdc3da98c  push rcx
00007eafdc3da98d  push rdx
00007eafdc3da98e  push rdi
00007eafdc3da98f  push rsi
00007eafdc3da990  push r8
00007eafdc3da992  push r9
00007eafdc3da994  push r10
00007eafdc3da996  push r11
00007eafdc3da998  sub rsp, 0xF0
00007eafdc3da99f  vmovaps [rsp], xmm0
00007eafdc3da9a4  vmovaps [rsp+0x10], xmm1
00007eafdc3da9aa  vmovaps [rsp+0x20], xmm2
00007eafdc3da9b0  vmovaps [rsp+0x30], xmm3
00007eafdc3da9b6  vmovaps [rsp+0x40], xmm4
00007eafdc3da9bc  vmovaps [rsp+0x50], xmm5
00007eafdc3da9c2  vmovaps [rsp+0x60], xmm6
00007eafdc3da9c8  vmovaps [rsp+0x70], xmm7
00007eafdc3da9ce  vmovaps [rsp+0x80], xmm8
00007eafdc3da9d7  vmovaps [rsp+0x90], xmm9
00007eafdc3da9e0  vmovaps [rsp+0xA0], xmm10
00007eafdc3da9e9  vmovaps [rsp+0xB0], xmm12
00007eafdc3da9f2  vmovaps [rsp+0xC0], xmm13
00007eafdc3da9fb  vmovaps [rsp+0xD0], xmm14
00007eafdc3daa04  vmovaps [rsp+0xE0], xmm15
00007eafdc3daa0d  sub rsp, 0x30
00007eafdc3daa11  movaps [rsp], xmm11
00007eafdc3daa16  movaps [rsp+0x10], xmm10
00007eafdc3daa1c  movaps [rsp+0x20], xmm14
00007eafdc3daa22  lea rdi, [rsp]
00007eafdc3daa26  mov esi, 0x00
00007eafdc3daa2b  mov rax, 0x645891675530
00007eafdc3daa35  call rax
00007eafdc3daa37  movaps xmm11, [rsp]
00007eafdc3daa3c  add rsp, 0x30
00007eafdc3daa40  vmovaps xmm0, [rsp]
00007eafdc3daa45  vmovaps xmm1, [rsp+0x10]
00007eafdc3daa4b  vmovaps xmm2, [rsp+0x20]
00007eafdc3daa51  vmovaps xmm3, [rsp+0x30]
00007eafdc3daa57  vmovaps xmm4, [rsp+0x40]
00007eafdc3daa5d  vmovaps xmm5, [rsp+0x50]
00007eafdc3daa63  vmovaps xmm6, [rsp+0x60]
00007eafdc3daa69  vmovaps xmm7, [rsp+0x70]
00007eafdc3daa6f  vmovaps xmm8, [rsp+0x80]
00007eafdc3daa78  vmovaps xmm9, [rsp+0x90]
00007eafdc3daa81  vmovaps xmm10, [rsp+0xA0]
00007eafdc3daa8a  vmovaps xmm12, [rsp+0xB0]
00007eafdc3daa93  vmovaps xmm13, [rsp+0xC0]
00007eafdc3daa9c  vmovaps xmm14, [rsp+0xD0]
00007eafdc3daaa5  vmovaps xmm15, [rsp+0xE0]
00007eafdc3daaae  add rsp, 0xF0
00007eafdc3daab5  pop r11
00007eafdc3daab7  pop r10
00007eafdc3daab9  pop r9
00007eafdc3daabb  pop r8
00007eafdc3daabd  pop rsi
00007eafdc3daabe  pop rdi
00007eafdc3daabf  pop rdx
00007eafdc3daac0  pop rcx
00007eafdc3daac1  pop rax
00007eafdc3daac2  add rsp, 0x08
00007eafdc3daac6  jmp 0x00007EAFDC3D64ED
00007eafdc3daacb  call 0x00007EAFDC2E45A0
00007eafdc3daad0  jmp 0x00007EAFDC3D64F7
00007eafdc3daad5  sub rsp, 0x08
00007eafdc3daad9  push rax
00007eafdc3daada  push rcx
00007eafdc3daadb  push rdx
00007eafdc3daadc  push rdi
00007eafdc3daadd  push rsi
00007eafdc3daade  push r8
00007eafdc3daae0  push r9
00007eafdc3daae2  push r10
00007eafdc3daae4  push r11
00007eafdc3daae6  sub rsp, 0xF0
00007eafdc3daaed  vmovaps [rsp], xmm0
00007eafdc3daaf2  vmovaps [rsp+0x10], xmm1
00007eafdc3daaf8  vmovaps [rsp+0x20], xmm2
00007eafdc3daafe  vmovaps [rsp+0x30], xmm3
00007eafdc3dab04  vmovaps [rsp+0x40], xmm4
00007eafdc3dab0a  vmovaps [rsp+0x50], xmm5
00007eafdc3dab10  vmovaps [rsp+0x60], xmm6
00007eafdc3dab16  vmovaps [rsp+0x70], xmm7
00007eafdc3dab1c  vmovaps [rsp+0x80], xmm8
00007eafdc3dab25  vmovaps [rsp+0x90], xmm9
00007eafdc3dab2e  vmovaps [rsp+0xA0], xmm11
00007eafdc3dab37  vmovaps [rsp+0xB0], xmm12
00007eafdc3dab40  vmovaps [rsp+0xC0], xmm13
00007eafdc3dab49  vmovaps [rsp+0xD0], xmm14
00007eafdc3dab52  vmovaps [rsp+0xE0], xmm15
00007eafdc3dab5b  sub rsp, 0x30
00007eafdc3dab5f  movaps [rsp], xmm10
00007eafdc3dab64  movaps [rsp+0x10], xmm1
00007eafdc3dab69  movaps [rsp+0x20], xmm12
00007eafdc3dab6f  lea rdi, [rsp]
00007eafdc3dab73  mov esi, 0x00
00007eafdc3dab78  mov rax, 0x645891675530
00007eafdc3dab82  call rax
00007eafdc3dab84  movaps xmm10, [rsp]
00007eafdc3dab89  add rsp, 0x30
00007eafdc3dab8d  vmovaps xmm0, [rsp]
00007eafdc3dab92  vmovaps xmm1, [rsp+0x10]
00007eafdc3dab98  vmovaps xmm2, [rsp+0x20]
00007eafdc3dab9e  vmovaps xmm3, [rsp+0x30]
00007eafdc3daba4  vmovaps xmm4, [rsp+0x40]
00007eafdc3dabaa  vmovaps xmm5, [rsp+0x50]
00007eafdc3dabb0  vmovaps xmm6, [rsp+0x60]
00007eafdc3dabb6  vmovaps xmm7, [rsp+0x70]
00007eafdc3dabbc  vmovaps xmm8, [rsp+0x80]
00007eafdc3dabc5  vmovaps xmm9, [rsp+0x90]
00007eafdc3dabce  vmovaps xmm11, [rsp+0xA0]
00007eafdc3dabd7  vmovaps xmm12, [rsp+0xB0]
00007eafdc3dabe0  vmovaps xmm13, [rsp+0xC0]
00007eafdc3dabe9  vmovaps xmm14, [rsp+0xD0]
00007eafdc3dabf2  vmovaps xmm15, [rsp+0xE0]
00007eafdc3dabfb  add rsp, 0xF0
00007eafdc3dac02  pop r11
00007eafdc3dac04  pop r10
00007eafdc3dac06  pop r9
00007eafdc3dac08  pop r8
00007eafdc3dac0a  pop rsi
00007eafdc3dac0b  pop rdi
00007eafdc3dac0c  pop rdx
00007eafdc3dac0d  pop rcx
00007eafdc3dac0e  pop rax
00007eafdc3dac0f  add rsp, 0x08
00007eafdc3dac13  jmp 0x00007EAFDC3D651A
00007eafdc3dac18  sub rsp, 0x08
00007eafdc3dac1c  push rax
00007eafdc3dac1d  push rcx
00007eafdc3dac1e  push rdx
00007eafdc3dac1f  push rdi
00007eafdc3dac20  push rsi
00007eafdc3dac21  push r8
00007eafdc3dac23  push r9
00007eafdc3dac25  push r10
00007eafdc3dac27  push r11
00007eafdc3dac29  sub rsp, 0xF0
00007eafdc3dac30  vmovaps [rsp], xmm0
00007eafdc3dac35  vmovaps [rsp+0x10], xmm1
00007eafdc3dac3b  vmovaps [rsp+0x20], xmm2
00007eafdc3dac41  vmovaps [rsp+0x30], xmm3
00007eafdc3dac47  vmovaps [rsp+0x40], xmm4
00007eafdc3dac4d  vmovaps [rsp+0x50], xmm5
00007eafdc3dac53  vmovaps [rsp+0x60], xmm6
00007eafdc3dac59  vmovaps [rsp+0x70], xmm7
00007eafdc3dac5f  vmovaps [rsp+0x80], xmm8
00007eafdc3dac68  vmovaps [rsp+0x90], xmm9
00007eafdc3dac71  vmovaps [rsp+0xA0], xmm10
00007eafdc3dac7a  vmovaps [rsp+0xB0], xmm11
00007eafdc3dac83  vmovaps [rsp+0xC0], xmm13
00007eafdc3dac8c  vmovaps [rsp+0xD0], xmm14
00007eafdc3dac95  vmovaps [rsp+0xE0], xmm15
00007eafdc3dac9e  sub rsp, 0x30
00007eafdc3daca2  movaps [rsp], xmm12
00007eafdc3daca7  movaps [rsp+0x10], xmm14
00007eafdc3dacad  movaps [rsp+0x20], xmm1
00007eafdc3dacb2  lea rdi, [rsp]
00007eafdc3dacb6  mov esi, 0x00
00007eafdc3dacbb  mov rax, 0x645891675530
00007eafdc3dacc5  call rax
00007eafdc3dacc7  movaps xmm12, [rsp]
00007eafdc3daccc  add rsp, 0x30
00007eafdc3dacd0  vmovaps xmm0, [rsp]
00007eafdc3dacd5  vmovaps xmm1, [rsp+0x10]
00007eafdc3dacdb  vmovaps xmm2, [rsp+0x20]
00007eafdc3dace1  vmovaps xmm3, [rsp+0x30]
00007eafdc3dace7  vmovaps xmm4, [rsp+0x40]
00007eafdc3daced  vmovaps xmm5, [rsp+0x50]
00007eafdc3dacf3  vmovaps xmm6, [rsp+0x60]
00007eafdc3dacf9  vmovaps xmm7, [rsp+0x70]
00007eafdc3dacff  vmovaps xmm8, [rsp+0x80]
00007eafdc3dad08  vmovaps xmm9, [rsp+0x90]
00007eafdc3dad11  vmovaps xmm10, [rsp+0xA0]
00007eafdc3dad1a  vmovaps xmm11, [rsp+0xB0]
00007eafdc3dad23  vmovaps xmm13, [rsp+0xC0]
00007eafdc3dad2c  vmovaps xmm14, [rsp+0xD0]
00007eafdc3dad35  vmovaps xmm15, [rsp+0xE0]
00007eafdc3dad3e  add rsp, 0xF0
00007eafdc3dad45  pop r11
00007eafdc3dad47  pop r10
00007eafdc3dad49  pop r9
00007eafdc3dad4b  pop r8
00007eafdc3dad4d  pop rsi
00007eafdc3dad4e  pop rdi
00007eafdc3dad4f  pop rdx
00007eafdc3dad50  pop rcx
00007eafdc3dad51  pop rax
00007eafdc3dad52  add rsp, 0x08
00007eafdc3dad56  jmp 0x00007EAFDC3D6549
00007eafdc3dad5b  sub rsp, 0x08
00007eafdc3dad5f  push rax
00007eafdc3dad60  push rcx
00007eafdc3dad61  push rdx
00007eafdc3dad62  push rdi
00007eafdc3dad63  push rsi
00007eafdc3dad64  push r8
00007eafdc3dad66  push r9
00007eafdc3dad68  push r10
00007eafdc3dad6a  push r11
00007eafdc3dad6c  sub rsp, 0xF0
00007eafdc3dad73  vmovaps [rsp], xmm0
00007eafdc3dad78  vmovaps [rsp+0x10], xmm1
00007eafdc3dad7e  vmovaps [rsp+0x20], xmm2
00007eafdc3dad84  vmovaps [rsp+0x30], xmm3
00007eafdc3dad8a  vmovaps [rsp+0x40], xmm4
00007eafdc3dad90  vmovaps [rsp+0x50], xmm5
00007eafdc3dad96  vmovaps [rsp+0x60], xmm6
00007eafdc3dad9c  vmovaps [rsp+0x70], xmm7
00007eafdc3dada2  vmovaps [rsp+0x80], xmm8
00007eafdc3dadab  vmovaps [rsp+0x90], xmm9
00007eafdc3dadb4  vmovaps [rsp+0xA0], xmm10
00007eafdc3dadbd  vmovaps [rsp+0xB0], xmm11
00007eafdc3dadc6  vmovaps [rsp+0xC0], xmm12
00007eafdc3dadcf  vmovaps [rsp+0xD0], xmm13
00007eafdc3dadd8  vmovaps [rsp+0xE0], xmm15
00007eafdc3dade1  sub rsp, 0x30
00007eafdc3dade5  movaps [rsp], xmm14
00007eafdc3dadea  movaps [rsp+0x10], xmm9
00007eafdc3dadf0  movaps [rsp+0x20], xmm1
00007eafdc3dadf5  lea rdi, [rsp]
00007eafdc3dadf9  mov esi, 0x00
00007eafdc3dadfe  mov rax, 0x645891675530
00007eafdc3dae08  call rax
00007eafdc3dae0a  movaps xmm14, [rsp]
00007eafdc3dae0f  add rsp, 0x30
00007eafdc3dae13  vmovaps xmm0, [rsp]
00007eafdc3dae18  vmovaps xmm1, [rsp+0x10]
00007eafdc3dae1e  vmovaps xmm2, [rsp+0x20]
00007eafdc3dae24  vmovaps xmm3, [rsp+0x30]
00007eafdc3dae2a  vmovaps xmm4, [rsp+0x40]
00007eafdc3dae30  vmovaps xmm5, [rsp+0x50]
00007eafdc3dae36  vmovaps xmm6, [rsp+0x60]
00007eafdc3dae3c  vmovaps xmm7, [rsp+0x70]
00007eafdc3dae42  vmovaps xmm8, [rsp+0x80]
00007eafdc3dae4b  vmovaps xmm9, [rsp+0x90]
00007eafdc3dae54  vmovaps xmm10, [rsp+0xA0]
00007eafdc3dae5d  vmovaps xmm11, [rsp+0xB0]
00007eafdc3dae66  vmovaps xmm12, [rsp+0xC0]
00007eafdc3dae6f  vmovaps xmm13, [rsp+0xD0]
00007eafdc3dae78  vmovaps xmm15, [rsp+0xE0]
00007eafdc3dae81  add rsp, 0xF0
00007eafdc3dae88  pop r11
00007eafdc3dae8a  pop r10
00007eafdc3dae8c  pop r9
00007eafdc3dae8e  pop r8
00007eafdc3dae90  pop rsi
00007eafdc3dae91  pop rdi
00007eafdc3dae92  pop rdx
00007eafdc3dae93  pop rcx
00007eafdc3dae94  pop rax
00007eafdc3dae95  add rsp, 0x08
00007eafdc3dae99  jmp 0x00007EAFDC3D6578
00007eafdc3dae9e  sub rsp, 0x08
00007eafdc3daea2  push rax
00007eafdc3daea3  push rcx
00007eafdc3daea4  push rdx
00007eafdc3daea5  push rdi
00007eafdc3daea6  push rsi
00007eafdc3daea7  push r8
00007eafdc3daea9  push r9
00007eafdc3daeab  push r10
00007eafdc3daead  push r11
00007eafdc3daeaf  sub rsp, 0xF0
00007eafdc3daeb6  vmovaps [rsp], xmm0
00007eafdc3daebb  vmovaps [rsp+0x10], xmm2
00007eafdc3daec1  vmovaps [rsp+0x20], xmm3
00007eafdc3daec7  vmovaps [rsp+0x30], xmm4
00007eafdc3daecd  vmovaps [rsp+0x40], xmm5
00007eafdc3daed3  vmovaps [rsp+0x50], xmm6
00007eafdc3daed9  vmovaps [rsp+0x60], xmm7
00007eafdc3daedf  vmovaps [rsp+0x70], xmm8
00007eafdc3daee5  vmovaps [rsp+0x80], xmm9
00007eafdc3daeee  vmovaps [rsp+0x90], xmm10
00007eafdc3daef7  vmovaps [rsp+0xA0], xmm11
00007eafdc3daf00  vmovaps [rsp+0xB0], xmm12
00007eafdc3daf09  vmovaps [rsp+0xC0], xmm13
00007eafdc3daf12  vmovaps [rsp+0xD0], xmm14
00007eafdc3daf1b  vmovaps [rsp+0xE0], xmm15
00007eafdc3daf24  sub rsp, 0x30
00007eafdc3daf28  movaps [rsp], xmm1
00007eafdc3daf2c  movaps [rsp+0x10], xmm13
00007eafdc3daf32  movaps [rsp+0x20], xmm8
00007eafdc3daf38  lea rdi, [rsp]
00007eafdc3daf3c  mov esi, 0x00
00007eafdc3daf41  mov rax, 0x645891675530
00007eafdc3daf4b  call rax
00007eafdc3daf4d  movaps xmm1, [rsp]
00007eafdc3daf51  add rsp, 0x30
00007eafdc3daf55  vmovaps xmm0, [rsp]
00007eafdc3daf5a  vmovaps xmm2, [rsp+0x10]
00007eafdc3daf60  vmovaps xmm3, [rsp+0x20]
00007eafdc3daf66  vmovaps xmm4, [rsp+0x30]
00007eafdc3daf6c  vmovaps xmm5, [rsp+0x40]
00007eafdc3daf72  vmovaps xmm6, [rsp+0x50]
00007eafdc3daf78  vmovaps xmm7, [rsp+0x60]
00007eafdc3daf7e  vmovaps xmm8, [rsp+0x70]
00007eafdc3daf84  vmovaps xmm9, [rsp+0x80]
00007eafdc3daf8d  vmovaps xmm10, [rsp+0x90]
00007eafdc3daf96  vmovaps xmm11, [rsp+0xA0]
00007eafdc3daf9f  vmovaps xmm12, [rsp+0xB0]
00007eafdc3dafa8  vmovaps xmm13, [rsp+0xC0]
00007eafdc3dafb1  vmovaps xmm14, [rsp+0xD0]
00007eafdc3dafba  vmovaps xmm15, [rsp+0xE0]
00007eafdc3dafc3  add rsp, 0xF0
00007eafdc3dafca  pop r11
00007eafdc3dafcc  pop r10
00007eafdc3dafce  pop r9
00007eafdc3dafd0  pop r8
00007eafdc3dafd2  pop rsi
00007eafdc3dafd3  pop rdi
00007eafdc3dafd4  pop rdx
00007eafdc3dafd5  pop rcx
00007eafdc3dafd6  pop rax
00007eafdc3dafd7  add rsp, 0x08
00007eafdc3dafdb  jmp 0x00007EAFDC3D659A
00007eafdc3dafe0  call 0x00007EAFDC20C260
00007eafdc3dafe5  jmp 0x00007EAFDC3D65A8
00007eafdc3dafea  call 0x00007EAFDC2DE950
00007eafdc3dafef  jmp 0x00007EAFDC3D65B2
00007eafdc3daff4  sub rsp, 0x08
00007eafdc3daff8  push rax
00007eafdc3daff9  push rcx
00007eafdc3daffa  push rdx
00007eafdc3daffb  push rdi
00007eafdc3daffc  push rsi
00007eafdc3daffd  push r8
00007eafdc3dafff  push r9
00007eafdc3db001  push r10
00007eafdc3db003  push r11
00007eafdc3db005  sub rsp, 0xF0
00007eafdc3db00c  vmovaps [rsp], xmm0
00007eafdc3db011  vmovaps [rsp+0x10], xmm1
00007eafdc3db017  vmovaps [rsp+0x20], xmm2
00007eafdc3db01d  vmovaps [rsp+0x30], xmm3
00007eafdc3db023  vmovaps [rsp+0x40], xmm4
00007eafdc3db029  vmovaps [rsp+0x50], xmm5
00007eafdc3db02f  vmovaps [rsp+0x60], xmm6
00007eafdc3db035  vmovaps [rsp+0x70], xmm7
00007eafdc3db03b  vmovaps [rsp+0x80], xmm9
00007eafdc3db044  vmovaps [rsp+0x90], xmm10
00007eafdc3db04d  vmovaps [rsp+0xA0], xmm11
00007eafdc3db056  vmovaps [rsp+0xB0], xmm12
00007eafdc3db05f  vmovaps [rsp+0xC0], xmm13
00007eafdc3db068  vmovaps [rsp+0xD0], xmm14
00007eafdc3db071  vmovaps [rsp+0xE0], xmm15
00007eafdc3db07a  sub rsp, 0x30
00007eafdc3db07e  movaps [rsp], xmm8
00007eafdc3db083  movaps [rsp+0x10], xmm15
00007eafdc3db089  movaps [rsp+0x20], xmm7
00007eafdc3db08e  lea rdi, [rsp]
00007eafdc3db092  mov esi, 0x00
00007eafdc3db097  mov rax, 0x645891675530
00007eafdc3db0a1  call rax
00007eafdc3db0a3  movaps xmm8, [rsp]
00007eafdc3db0a8  add rsp, 0x30
00007eafdc3db0ac  vmovaps xmm0, [rsp]
00007eafdc3db0b1  vmovaps xmm1, [rsp+0x10]
00007eafdc3db0b7  vmovaps xmm2, [rsp+0x20]
00007eafdc3db0bd  vmovaps xmm3, [rsp+0x30]
00007eafdc3db0c3  vmovaps xmm4, [rsp+0x40]
00007eafdc3db0c9  vmovaps xmm5, [rsp+0x50]
00007eafdc3db0cf  vmovaps xmm6, [rsp+0x60]
00007eafdc3db0d5  vmovaps xmm7, [rsp+0x70]
00007eafdc3db0db  vmovaps xmm9, [rsp+0x80]
00007eafdc3db0e4  vmovaps xmm10, [rsp+0x90]
00007eafdc3db0ed  vmovaps xmm11, [rsp+0xA0]
00007eafdc3db0f6  vmovaps xmm12, [rsp+0xB0]
00007eafdc3db0ff  vmovaps xmm13, [rsp+0xC0]
00007eafdc3db108  vmovaps xmm14, [rsp+0xD0]
00007eafdc3db111  vmovaps xmm15, [rsp+0xE0]
00007eafdc3db11a  add rsp, 0xF0
00007eafdc3db121  pop r11
00007eafdc3db123  pop r10
00007eafdc3db125  pop r9
00007eafdc3db127  pop r8
00007eafdc3db129  pop rsi
00007eafdc3db12a  pop rdi
00007eafdc3db12b  pop rdx
00007eafdc3db12c  pop rcx
00007eafdc3db12d  pop rax
00007eafdc3db12e  add rsp, 0x08
00007eafdc3db132  jmp 0x00007EAFDC3D65D4
00007eafdc3db137  sub rsp, 0x08
00007eafdc3db13b  push rax
00007eafdc3db13c  push rcx
00007eafdc3db13d  push rdx
00007eafdc3db13e  push rdi
00007eafdc3db13f  push rsi
00007eafdc3db140  push r8
00007eafdc3db142  push r9
00007eafdc3db144  push r10
00007eafdc3db146  push r11
00007eafdc3db148  sub rsp, 0xF0
00007eafdc3db14f  vmovaps [rsp], xmm0
00007eafdc3db154  vmovaps [rsp+0x10], xmm1
00007eafdc3db15a  vmovaps [rsp+0x20], xmm2
00007eafdc3db160  vmovaps [rsp+0x30], xmm3
00007eafdc3db166  vmovaps [rsp+0x40], xmm4
00007eafdc3db16c  vmovaps [rsp+0x50], xmm5
00007eafdc3db172  vmovaps [rsp+0x60], xmm6
00007eafdc3db178  vmovaps [rsp+0x70], xmm8
00007eafdc3db17e  vmovaps [rsp+0x80], xmm9
00007eafdc3db187  vmovaps [rsp+0x90], xmm10
00007eafdc3db190  vmovaps [rsp+0xA0], xmm11
00007eafdc3db199  vmovaps [rsp+0xB0], xmm12
00007eafdc3db1a2  vmovaps [rsp+0xC0], xmm13
00007eafdc3db1ab  vmovaps [rsp+0xD0], xmm14
00007eafdc3db1b4  vmovaps [rsp+0xE0], xmm15
00007eafdc3db1bd  sub rsp, 0x30
00007eafdc3db1c1  movaps [rsp], xmm7
00007eafdc3db1c5  movaps [rsp+0x10], xmm9
00007eafdc3db1cb  movaps [rsp+0x20], xmm15
00007eafdc3db1d1  lea rdi, [rsp]
00007eafdc3db1d5  mov esi, 0x00
00007eafdc3db1da  mov rax, 0x645891675530
00007eafdc3db1e4  call rax
00007eafdc3db1e6  movaps xmm7, [rsp]
00007eafdc3db1ea  add rsp, 0x30
00007eafdc3db1ee  vmovaps xmm0, [rsp]
00007eafdc3db1f3  vmovaps xmm1, [rsp+0x10]
00007eafdc3db1f9  vmovaps xmm2, [rsp+0x20]
00007eafdc3db1ff  vmovaps xmm3, [rsp+0x30]
00007eafdc3db205  vmovaps xmm4, [rsp+0x40]
00007eafdc3db20b  vmovaps xmm5, [rsp+0x50]
00007eafdc3db211  vmovaps xmm6, [rsp+0x60]
00007eafdc3db217  vmovaps xmm8, [rsp+0x70]
00007eafdc3db21d  vmovaps xmm9, [rsp+0x80]
00007eafdc3db226  vmovaps xmm10, [rsp+0x90]
00007eafdc3db22f  vmovaps xmm11, [rsp+0xA0]
00007eafdc3db238  vmovaps xmm12, [rsp+0xB0]
00007eafdc3db241  vmovaps xmm13, [rsp+0xC0]
00007eafdc3db24a  vmovaps xmm14, [rsp+0xD0]
00007eafdc3db253  vmovaps xmm15, [rsp+0xE0]
00007eafdc3db25c  add rsp, 0xF0
00007eafdc3db263  pop r11
00007eafdc3db265  pop r10
00007eafdc3db267  pop r9
00007eafdc3db269  pop r8
00007eafdc3db26b  pop rsi
00007eafdc3db26c  pop rdi
00007eafdc3db26d  pop rdx
00007eafdc3db26e  pop rcx
00007eafdc3db26f  pop rax
00007eafdc3db270  add rsp, 0x08
00007eafdc3db274  jmp 0x00007EAFDC3D6601
00007eafdc3db279  sub rsp, 0x08
00007eafdc3db27d  push rax
00007eafdc3db27e  push rcx
00007eafdc3db27f  push rdx
00007eafdc3db280  push rdi
00007eafdc3db281  push rsi
00007eafdc3db282  push r8
00007eafdc3db284  push r9
00007eafdc3db286  push r10
00007eafdc3db288  push r11
00007eafdc3db28a  sub rsp, 0xF0
00007eafdc3db291  vmovaps [rsp], xmm0
00007eafdc3db296  vmovaps [rsp+0x10], xmm1
00007eafdc3db29c  vmovaps [rsp+0x20], xmm2
00007eafdc3db2a2  vmovaps [rsp+0x30], xmm3
00007eafdc3db2a8  vmovaps [rsp+0x40], xmm4
00007eafdc3db2ae  vmovaps [rsp+0x50], xmm5
00007eafdc3db2b4  vmovaps [rsp+0x60], xmm6
00007eafdc3db2ba  vmovaps [rsp+0x70], xmm7
00007eafdc3db2c0  vmovaps [rsp+0x80], xmm8
00007eafdc3db2c9  vmovaps [rsp+0x90], xmm10
00007eafdc3db2d2  vmovaps [rsp+0xA0], xmm11
00007eafdc3db2db  vmovaps [rsp+0xB0], xmm12
00007eafdc3db2e4  vmovaps [rsp+0xC0], xmm13
00007eafdc3db2ed  vmovaps [rsp+0xD0], xmm14
00007eafdc3db2f6  vmovaps [rsp+0xE0], xmm15
00007eafdc3db2ff  sub rsp, 0x30
00007eafdc3db303  movaps [rsp], xmm9
00007eafdc3db308  movaps [rsp+0x10], xmm13
00007eafdc3db30e  movaps [rsp+0x20], xmm15
00007eafdc3db314  lea rdi, [rsp]
00007eafdc3db318  mov esi, 0x00
00007eafdc3db31d  mov rax, 0x645891675530
00007eafdc3db327  call rax
00007eafdc3db329  movaps xmm9, [rsp]
00007eafdc3db32e  add rsp, 0x30
00007eafdc3db332  vmovaps xmm0, [rsp]
00007eafdc3db337  vmovaps xmm1, [rsp+0x10]
00007eafdc3db33d  vmovaps xmm2, [rsp+0x20]
00007eafdc3db343  vmovaps xmm3, [rsp+0x30]
00007eafdc3db349  vmovaps xmm4, [rsp+0x40]
00007eafdc3db34f  vmovaps xmm5, [rsp+0x50]
00007eafdc3db355  vmovaps xmm6, [rsp+0x60]
00007eafdc3db35b  vmovaps xmm7, [rsp+0x70]
00007eafdc3db361  vmovaps xmm8, [rsp+0x80]
00007eafdc3db36a  vmovaps xmm10, [rsp+0x90]
00007eafdc3db373  vmovaps xmm11, [rsp+0xA0]
00007eafdc3db37c  vmovaps xmm12, [rsp+0xB0]
00007eafdc3db385  vmovaps xmm13, [rsp+0xC0]
00007eafdc3db38e  vmovaps xmm14, [rsp+0xD0]
00007eafdc3db397  vmovaps xmm15, [rsp+0xE0]
00007eafdc3db3a0  add rsp, 0xF0
00007eafdc3db3a7  pop r11
00007eafdc3db3a9  pop r10
00007eafdc3db3ab  pop r9
00007eafdc3db3ad  pop r8
00007eafdc3db3af  pop rsi
00007eafdc3db3b0  pop rdi
00007eafdc3db3b1  pop rdx
00007eafdc3db3b2  pop rcx
00007eafdc3db3b3  pop rax
00007eafdc3db3b4  add rsp, 0x08
00007eafdc3db3b8  jmp 0x00007EAFDC3D662F
00007eafdc3db3bd  sub rsp, 0x08
00007eafdc3db3c1  push rax
00007eafdc3db3c2  push rcx
00007eafdc3db3c3  push rdx
00007eafdc3db3c4  push rdi
00007eafdc3db3c5  push rsi
00007eafdc3db3c6  push r8
00007eafdc3db3c8  push r9
00007eafdc3db3ca  push r10
00007eafdc3db3cc  push r11
00007eafdc3db3ce  sub rsp, 0xF0
00007eafdc3db3d5  vmovaps [rsp], xmm0
00007eafdc3db3da  vmovaps [rsp+0x10], xmm1
00007eafdc3db3e0  vmovaps [rsp+0x20], xmm2
00007eafdc3db3e6  vmovaps [rsp+0x30], xmm3
00007eafdc3db3ec  vmovaps [rsp+0x40], xmm4
00007eafdc3db3f2  vmovaps [rsp+0x50], xmm5
00007eafdc3db3f8  vmovaps [rsp+0x60], xmm6
00007eafdc3db3fe  vmovaps [rsp+0x70], xmm7
00007eafdc3db404  vmovaps [rsp+0x80], xmm8
00007eafdc3db40d  vmovaps [rsp+0x90], xmm9
00007eafdc3db416  vmovaps [rsp+0xA0], xmm10
00007eafdc3db41f  vmovaps [rsp+0xB0], xmm11
00007eafdc3db428  vmovaps [rsp+0xC0], xmm12
00007eafdc3db431  vmovaps [rsp+0xD0], xmm13
00007eafdc3db43a  vmovaps [rsp+0xE0], xmm14
00007eafdc3db443  sub rsp, 0x30
00007eafdc3db447  movaps [rsp], xmm15
00007eafdc3db44c  movaps [rsp+0x10], xmm11
00007eafdc3db452  movaps [rsp+0x20], xmm12
00007eafdc3db458  lea rdi, [rsp]
00007eafdc3db45c  mov esi, 0x00
00007eafdc3db461  mov rax, 0x645891675530
00007eafdc3db46b  call rax
00007eafdc3db46d  movaps xmm15, [rsp]
00007eafdc3db472  add rsp, 0x30
00007eafdc3db476  vmovaps xmm0, [rsp]
00007eafdc3db47b  vmovaps xmm1, [rsp+0x10]
00007eafdc3db481  vmovaps xmm2, [rsp+0x20]
00007eafdc3db487  vmovaps xmm3, [rsp+0x30]
00007eafdc3db48d  vmovaps xmm4, [rsp+0x40]
00007eafdc3db493  vmovaps xmm5, [rsp+0x50]
00007eafdc3db499  vmovaps xmm6, [rsp+0x60]
00007eafdc3db49f  vmovaps xmm7, [rsp+0x70]
00007eafdc3db4a5  vmovaps xmm8, [rsp+0x80]
00007eafdc3db4ae  vmovaps xmm9, [rsp+0x90]
00007eafdc3db4b7  vmovaps xmm10, [rsp+0xA0]
00007eafdc3db4c0  vmovaps xmm11, [rsp+0xB0]
00007eafdc3db4c9  vmovaps xmm12, [rsp+0xC0]
00007eafdc3db4d2  vmovaps xmm13, [rsp+0xD0]
00007eafdc3db4db  vmovaps xmm14, [rsp+0xE0]
00007eafdc3db4e4  add rsp, 0xF0
00007eafdc3db4eb  pop r11
00007eafdc3db4ed  pop r10
00007eafdc3db4ef  pop r9
00007eafdc3db4f1  pop r8
00007eafdc3db4f3  pop rsi
00007eafdc3db4f4  pop rdi
00007eafdc3db4f5  pop rdx
00007eafdc3db4f6  pop rcx
00007eafdc3db4f7  pop rax
00007eafdc3db4f8  add rsp, 0x08
00007eafdc3db4fc  jmp 0x00007EAFDC3D664A
00007eafdc3db501  sub rsp, 0x08
00007eafdc3db505  push rax
00007eafdc3db506  push rcx
00007eafdc3db507  push rdx
00007eafdc3db508  push rdi
00007eafdc3db509  push rsi
00007eafdc3db50a  push r8
00007eafdc3db50c  push r9
00007eafdc3db50e  push r10
00007eafdc3db510  push r11
00007eafdc3db512  sub rsp, 0xF0
00007eafdc3db519  vmovaps [rsp], xmm0
00007eafdc3db51e  vmovaps [rsp+0x10], xmm1
00007eafdc3db524  vmovaps [rsp+0x20], xmm2
00007eafdc3db52a  vmovaps [rsp+0x30], xmm3
00007eafdc3db530  vmovaps [rsp+0x40], xmm4
00007eafdc3db536  vmovaps [rsp+0x50], xmm5
00007eafdc3db53c  vmovaps [rsp+0x60], xmm6
00007eafdc3db542  vmovaps [rsp+0x70], xmm7
00007eafdc3db548  vmovaps [rsp+0x80], xmm8
00007eafdc3db551  vmovaps [rsp+0x90], xmm9
00007eafdc3db55a  vmovaps [rsp+0xA0], xmm10
00007eafdc3db563  vmovaps [rsp+0xB0], xmm11
00007eafdc3db56c  vmovaps [rsp+0xC0], xmm12
00007eafdc3db575  vmovaps [rsp+0xD0], xmm14
00007eafdc3db57e  vmovaps [rsp+0xE0], xmm15
00007eafdc3db587  sub rsp, 0x30
00007eafdc3db58b  movaps [rsp], xmm13
00007eafdc3db590  movaps [rsp+0x10], xmm10
00007eafdc3db596  movaps [rsp+0x20], xmm14
00007eafdc3db59c  lea rdi, [rsp]
00007eafdc3db5a0  mov esi, 0x00
00007eafdc3db5a5  mov rax, 0x645891675530
00007eafdc3db5af  call rax
00007eafdc3db5b1  movaps xmm13, [rsp]
00007eafdc3db5b6  add rsp, 0x30
00007eafdc3db5ba  vmovaps xmm0, [rsp]
00007eafdc3db5bf  vmovaps xmm1, [rsp+0x10]
00007eafdc3db5c5  vmovaps xmm2, [rsp+0x20]
00007eafdc3db5cb  vmovaps xmm3, [rsp+0x30]
00007eafdc3db5d1  vmovaps xmm4, [rsp+0x40]
00007eafdc3db5d7  vmovaps xmm5, [rsp+0x50]
00007eafdc3db5dd  vmovaps xmm6, [rsp+0x60]
00007eafdc3db5e3  vmovaps xmm7, [rsp+0x70]
00007eafdc3db5e9  vmovaps xmm8, [rsp+0x80]
00007eafdc3db5f2  vmovaps xmm9, [rsp+0x90]
00007eafdc3db5fb  vmovaps xmm10, [rsp+0xA0]
00007eafdc3db604  vmovaps xmm11, [rsp+0xB0]
00007eafdc3db60d  vmovaps xmm12, [rsp+0xC0]
00007eafdc3db616  vmovaps xmm14, [rsp+0xD0]
00007eafdc3db61f  vmovaps xmm15, [rsp+0xE0]
00007eafdc3db628  add rsp, 0xF0
00007eafdc3db62f  pop r11
00007eafdc3db631  pop r10
00007eafdc3db633  pop r9
00007eafdc3db635  pop r8
00007eafdc3db637  pop rsi
00007eafdc3db638  pop rdi
00007eafdc3db639  pop rdx
00007eafdc3db63a  pop rcx
00007eafdc3db63b  pop rax
00007eafdc3db63c  add rsp, 0x08
00007eafdc3db640  jmp 0x00007EAFDC3D666D
00007eafdc3db645  sub rsp, 0x08
00007eafdc3db649  push rax
00007eafdc3db64a  push rcx
00007eafdc3db64b  push rdx
00007eafdc3db64c  push rdi
00007eafdc3db64d  push rsi
00007eafdc3db64e  push r8
00007eafdc3db650  push r9
00007eafdc3db652  push r10
00007eafdc3db654  push r11
00007eafdc3db656  sub rsp, 0xF0
00007eafdc3db65d  vmovaps [rsp], xmm0
00007eafdc3db662  vmovaps [rsp+0x10], xmm1
00007eafdc3db668  vmovaps [rsp+0x20], xmm2
00007eafdc3db66e  vmovaps [rsp+0x30], xmm3
00007eafdc3db674  vmovaps [rsp+0x40], xmm4
00007eafdc3db67a  vmovaps [rsp+0x50], xmm5
00007eafdc3db680  vmovaps [rsp+0x60], xmm6
00007eafdc3db686  vmovaps [rsp+0x70], xmm7
00007eafdc3db68c  vmovaps [rsp+0x80], xmm8
00007eafdc3db695  vmovaps [rsp+0x90], xmm9
00007eafdc3db69e  vmovaps [rsp+0xA0], xmm10
00007eafdc3db6a7  vmovaps [rsp+0xB0], xmm11
00007eafdc3db6b0  vmovaps [rsp+0xC0], xmm12
00007eafdc3db6b9  vmovaps [rsp+0xD0], xmm13
00007eafdc3db6c2  vmovaps [rsp+0xE0], xmm15
00007eafdc3db6cb  sub rsp, 0x30
00007eafdc3db6cf  movaps [rsp], xmm14
00007eafdc3db6d4  movaps [rsp+0x10], xmm1
00007eafdc3db6d9  movaps [rsp+0x20], xmm7
00007eafdc3db6de  lea rdi, [rsp]
00007eafdc3db6e2  mov esi, 0x00
00007eafdc3db6e7  mov rax, 0x645891675530
00007eafdc3db6f1  call rax
00007eafdc3db6f3  movaps xmm14, [rsp]
00007eafdc3db6f8  add rsp, 0x30
00007eafdc3db6fc  vmovaps xmm0, [rsp]
00007eafdc3db701  vmovaps xmm1, [rsp+0x10]
00007eafdc3db707  vmovaps xmm2, [rsp+0x20]
00007eafdc3db70d  vmovaps xmm3, [rsp+0x30]
00007eafdc3db713  vmovaps xmm4, [rsp+0x40]
00007eafdc3db719  vmovaps xmm5, [rsp+0x50]
00007eafdc3db71f  vmovaps xmm6, [rsp+0x60]
00007eafdc3db725  vmovaps xmm7, [rsp+0x70]
00007eafdc3db72b  vmovaps xmm8, [rsp+0x80]
00007eafdc3db734  vmovaps xmm9, [rsp+0x90]
00007eafdc3db73d  vmovaps xmm10, [rsp+0xA0]
00007eafdc3db746  vmovaps xmm11, [rsp+0xB0]
00007eafdc3db74f  vmovaps xmm12, [rsp+0xC0]
00007eafdc3db758  vmovaps xmm13, [rsp+0xD0]
00007eafdc3db761  vmovaps xmm15, [rsp+0xE0]
00007eafdc3db76a  add rsp, 0xF0
00007eafdc3db771  pop r11
00007eafdc3db773  pop r10
00007eafdc3db775  pop r9
00007eafdc3db777  pop r8
00007eafdc3db779  pop rsi
00007eafdc3db77a  pop rdi
00007eafdc3db77b  pop rdx
00007eafdc3db77c  pop rcx
00007eafdc3db77d  pop rax
00007eafdc3db77e  add rsp, 0x08
00007eafdc3db782  jmp 0x00007EAFDC3D6690
00007eafdc3db787  sub rsp, 0x08
00007eafdc3db78b  push rax
00007eafdc3db78c  push rcx
00007eafdc3db78d  push rdx
00007eafdc3db78e  push rdi
00007eafdc3db78f  push rsi
00007eafdc3db790  push r8
00007eafdc3db792  push r9
00007eafdc3db794  push r10
00007eafdc3db796  push r11
00007eafdc3db798  sub rsp, 0xF0
00007eafdc3db79f  vmovaps [rsp], xmm0
00007eafdc3db7a4  vmovaps [rsp+0x10], xmm2
00007eafdc3db7aa  vmovaps [rsp+0x20], xmm3
00007eafdc3db7b0  vmovaps [rsp+0x30], xmm4
00007eafdc3db7b6  vmovaps [rsp+0x40], xmm5
00007eafdc3db7bc  vmovaps [rsp+0x50], xmm6
00007eafdc3db7c2  vmovaps [rsp+0x60], xmm7
00007eafdc3db7c8  vmovaps [rsp+0x70], xmm8
00007eafdc3db7ce  vmovaps [rsp+0x80], xmm9
00007eafdc3db7d7  vmovaps [rsp+0x90], xmm10
00007eafdc3db7e0  vmovaps [rsp+0xA0], xmm11
00007eafdc3db7e9  vmovaps [rsp+0xB0], xmm12
00007eafdc3db7f2  vmovaps [rsp+0xC0], xmm13
00007eafdc3db7fb  vmovaps [rsp+0xD0], xmm14
00007eafdc3db804  vmovaps [rsp+0xE0], xmm15
00007eafdc3db80d  sub rsp, 0x30
00007eafdc3db811  movaps [rsp], xmm1
00007eafdc3db815  movaps [rsp+0x10], xmm8
00007eafdc3db81b  movaps [rsp+0x20], xmm9
00007eafdc3db821  lea rdi, [rsp]
00007eafdc3db825  mov esi, 0x00
00007eafdc3db82a  mov rax, 0x645891675530
00007eafdc3db834  call rax
00007eafdc3db836  movaps xmm1, [rsp]
00007eafdc3db83a  add rsp, 0x30
00007eafdc3db83e  vmovaps xmm0, [rsp]
00007eafdc3db843  vmovaps xmm2, [rsp+0x10]
00007eafdc3db849  vmovaps xmm3, [rsp+0x20]
00007eafdc3db84f  vmovaps xmm4, [rsp+0x30]
00007eafdc3db855  vmovaps xmm5, [rsp+0x40]
00007eafdc3db85b  vmovaps xmm6, [rsp+0x50]
00007eafdc3db861  vmovaps xmm7, [rsp+0x60]
00007eafdc3db867  vmovaps xmm8, [rsp+0x70]
00007eafdc3db86d  vmovaps xmm9, [rsp+0x80]
00007eafdc3db876  vmovaps xmm10, [rsp+0x90]
00007eafdc3db87f  vmovaps xmm11, [rsp+0xA0]
00007eafdc3db888  vmovaps xmm12, [rsp+0xB0]
00007eafdc3db891  vmovaps xmm13, [rsp+0xC0]
00007eafdc3db89a  vmovaps xmm14, [rsp+0xD0]
00007eafdc3db8a3  vmovaps xmm15, [rsp+0xE0]
00007eafdc3db8ac  add rsp, 0xF0
00007eafdc3db8b3  pop r11
00007eafdc3db8b5  pop r10
00007eafdc3db8b7  pop r9
00007eafdc3db8b9  pop r8
00007eafdc3db8bb  pop rsi
00007eafdc3db8bc  pop rdi
00007eafdc3db8bd  pop rdx
00007eafdc3db8be  pop rcx
00007eafdc3db8bf  pop rax
00007eafdc3db8c0  add rsp, 0x08
00007eafdc3db8c4  jmp 0x00007EAFDC3D66B2
00007eafdc3db8c9  call 0x00007EAFDC2B3E40
00007eafdc3db8ce  jmp 0x00007EAFDC3D66C0
00007eafdc3db8d3  call 0x00007EAFDC20C380
00007eafdc3db8d8  jmp 0x00007EAFDC3D66CA
00007eafdc3db8dd  call 0x00007EAFDC20D600
00007eafdc3db8e2  jmp 0x00007EAFDC3D66D4
00007eafdc3db8e7  call 0x00007EAFDC1FF540
00007eafdc3db8ec  jmp 0x00007EAFDC3D66DE
00007eafdc3db8f1  int3
00007eafdc3db8f2  nop [rax+rax*1], ax
00007eafdc3db8fb  nop [rax+rax*1], eax
00007eafdc3db900  mov eax, [r15+0x48]
00007eafdc3db904  lea r14d, [eax+0x01]
00007eafdc3db909  mov [rsp+0x10], r14d
00007eafdc3db90e  mov r14d, r14d
00007eafdc3db911  mov [r15+0x48], r14
00007eafdc3db915  xor eax, eax
00007eafdc3db917  mov r14d, [rsp+0x10]
00007eafdc3db91c  cmp r14d, 0x1F4
00007eafdc3db923  cmc
00007eafdc3db924  lahf
00007eafdc3db925  seto al
00007eafdc3db928  mov [r15+0x108], eax
00007eafdc3db92f  mov eax, [r15+0x108]
00007eafdc3db936  sahf
00007eafdc3db937  jnz 0x00007EAFDC3DB969
00007eafdc3db939  cmp dword ptr [r15+0x318], 0x00
00007eafdc3db941  jz 0x00007EAFDC3E1AB0
00007eafdc3db947  nop [rax+rax*1], ax
00007eafdc3db950  nop [rax+rax*1], eax
00007eafdc3db958  mov eax, 0x410450
00007eafdc3db95d  mov [r15+0x100], rax
00007eafdc3db964  jmp 0x00007EAFDC1FE110
00007eafdc3db969  cmp dword ptr [r15+0x318], 0x00
00007eafdc3db971  jz 0x00007EAFDC3DB9A0
00007eafdc3db977  nop [rax+rax*1], ax
00007eafdc3db980  nop [rax+rax*1], eax
00007eafdc3db988  mov eax, 0x410274
00007eafdc3db98d  mov [r15+0x100], rax
00007eafdc3db994  jmp 0x00007EAFDC1FE110
00007eafdc3db999  int3
00007eafdc3db99a  int3
00007eafdc3db99b  nop [rax+rax*1], eax
00007eafdc3db9a0  mov rax, [r15+0x40]
00007eafdc3db9a4  movaps xmm1, [r15+0x1D0]
00007eafdc3db9ac  vmovaps [rsp+0x10], xmm1
00007eafdc3db9b2  vmovaps xmm15, [rsp+0x10]
00007eafdc3db9b8  por xmm1, xmm15
00007eafdc3db9bd  movaps xmm14, [r15+0x1A0]
00007eafdc3db9c5  vmovaps [rsp+0x10], xmm14
00007eafdc3db9cb  vmovaps xmm13, [rsp+0x10]
00007eafdc3db9d1  por xmm14, xmm13
00007eafdc3db9d6  lea r14, [rax+0x30]
00007eafdc3db9da  mov r12, [r13+r14*1]
00007eafdc3db9df  lea r14, [rax+0x38]
00007eafdc3db9e3  mov r11, [r13+r14*1]
00007eafdc3db9e8  movq xmm13, r12
00007eafdc3db9ed  movq xmm12, r11
00007eafdc3db9f2  movq xmm13, xmm13
00007eafdc3db9f7  vmovaps [rsp+0x10], xmm13
00007eafdc3db9fd  movq xmm13, xmm13
00007eafdc3dba02  movaps [r15+0x130], xmm13
00007eafdc3dba0a  movq xmm12, xmm12
00007eafdc3dba0f  vmovaps [rsp+0x20], xmm12
00007eafdc3dba15  movq xmm12, xmm12
00007eafdc3dba1a  movaps [r15+0x280], xmm12
00007eafdc3dba22  movaps xmm13, [r15+0x270]
00007eafdc3dba2a  vmovaps [rsp+0x30], xmm13
00007eafdc3dba30  vmovaps xmm12, [rsp+0x30]
00007eafdc3dba36  por xmm13, xmm12
00007eafdc3dba3b  lea r14, [rax+0x20]
00007eafdc3dba3f  mov r12, [r13+r14*1]
00007eafdc3dba44  lea r14, [rax+0x28]
00007eafdc3dba48  mov r11, [r13+r14*1]
00007eafdc3dba4d  movq xmm12, r12
00007eafdc3dba52  movq xmm11, r11
00007eafdc3dba57  movq xmm12, xmm12
00007eafdc3dba5c  vmovaps [rsp+0x30], xmm12
00007eafdc3dba62  movq xmm12, xmm12
00007eafdc3dba67  movaps [r15+0x150], xmm12
00007eafdc3dba6f  movq xmm11, xmm11
00007eafdc3dba74  vmovaps [rsp+0x40], xmm11
00007eafdc3dba7a  movq xmm11, xmm11
00007eafdc3dba7f  movaps [r15+0x140], xmm11
00007eafdc3dba87  lea r14, [rax+0x10]
00007eafdc3dba8b  mov r12, [r13+r14*1]
00007eafdc3dba90  lea r14, [rax+0x18]
00007eafdc3dba94  mov r11, [r13+r14*1]
00007eafdc3dba99  movq xmm12, r12
00007eafdc3dba9e  movq xmm11, r11
00007eafdc3dbaa3  movq xmm12, xmm12
00007eafdc3dbaa8  vmovaps [rsp+0x50], xmm12
00007eafdc3dbaae  movq xmm12, xmm12
00007eafdc3dbab3  movaps [r15+0x170], xmm12
00007eafdc3dbabb  movq xmm11, xmm11
00007eafdc3dbac0  vmovaps [rsp+0x60], xmm11
00007eafdc3dbac6  movq xmm11, xmm11
00007eafdc3dbacb  movaps [r15+0x160], xmm11
00007eafdc3dbad3  mov r14, [r13+rax*1]
00007eafdc3dbad8  vmovq xmm12, r14
00007eafdc3dbadd  vpbroadcastq xmm12, xmm12
00007eafdc3dbae2  lea r14, [rax+0x08]
00007eafdc3dbae6  mov rax, [r13+r14*1]
00007eafdc3dbaeb  movq xmm11, rax
00007eafdc3dbaf0  movaps [r15+0x230], xmm11
00007eafdc3dbaf8  mov rax, [r15+0xF8]
00007eafdc3dbaff  lea r14, [rax+0x50]
00007eafdc3dbb03  movups xmm11, [r13+r14*1]
00007eafdc3dbb09  lea r14, [rax+0x60]
00007eafdc3dbb0d  movups xmm10, [r13+r14*1]
00007eafdc3dbb13  lea r14, [rax+0x30]
00007eafdc3dbb17  movups xmm9, [r13+r14*1]
00007eafdc3dbb1d  mov r14, [r15+0x50]
00007eafdc3dbb21  mov [r15+0x60], r14
00007eafdc3dbb25  mov qword ptr [r15+0x58], 0x40
00007eafdc3dbb2d  movaps xmm8, xmm12
00007eafdc3dbb31  mulpd xmm8, xmm15
00007eafdc3dbb36  vcmppd xmm7, xmm8, xmm8, 0x03
00007eafdc3dbb3c  ptest xmm7, xmm7
00007eafdc3dbb41  jnz 0x00007EAFDC3DC96A
00007eafdc3dbb47  movq xmm15, qword ptr [r15+0x230]
00007eafdc3dbb50  vmovaps [rsp+0x70], xmm15
00007eafdc3dbb56  vpermilpd xmm15, xmm15, 0x00
00007eafdc3dbb5c  movaps xmm7, xmm9
00007eafdc3dbb60  mulpd xmm7, xmm15
00007eafdc3dbb65  vcmppd xmm6, xmm7, xmm7, 0x03
00007eafdc3dbb6a  ptest xmm6, xmm6
00007eafdc3dbb6f  jnz 0x00007EAFDC3DCAAE
00007eafdc3dbb75  vxorps xmm15, xmm15, xmm15
00007eafdc3dbb7a  vpbroadcastq xmm15, xmm15
00007eafdc3dbb7f  movaps xmm9, xmm12
00007eafdc3dbb83  mulpd xmm9, xmm10
00007eafdc3dbb88  vcmppd xmm6, xmm9, xmm9, 0x03
00007eafdc3dbb8e  ptest xmm6, xmm6
00007eafdc3dbb93  jnz 0x00007EAFDC3DCBF0
00007eafdc3dbb99  movaps xmm10, xmm12
00007eafdc3dbb9d  mulpd xmm10, xmm11
00007eafdc3dbba2  vcmppd xmm6, xmm10, xmm10, 0x03
00007eafdc3dbba8  ptest xmm6, xmm6
00007eafdc3dbbad  jnz 0x00007EAFDC3DCD34
00007eafdc3dbbb3  movaps xmm11, [r15+0x1F0]
00007eafdc3dbbbb  movaps xmm6, xmm12
00007eafdc3dbbbf  mulpd xmm6, xmm11
00007eafdc3dbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
00007eafdc3dbbc9  ptest xmm5, xmm5
00007eafdc3dbbce  jnz 0x00007EAFDC3DCE78
00007eafdc3dbbd4  movaps xmm12, [r15+0x2A0]
00007eafdc3dbbdc  vmovaps [rsp+0x80], xmm12
00007eafdc3dbbe5  vmovaps xmm11, [rsp+0x80]
00007eafdc3dbbee  por xmm12, xmm11
00007eafdc3dbbf3  movaps xmm11, [r15+0x250]
00007eafdc3dbbfb  vmovaps [rsp+0x80], xmm11
00007eafdc3dbc04  vmovaps xmm5, [rsp+0x80]
00007eafdc3dbc0d  por xmm11, xmm5
00007eafdc3dbc12  vmovaps xmm4, [rsp+0x70]
00007eafdc3dbc18  vpermilpd xmm4, xmm4, 0x00
00007eafdc3dbc1e  movaps xmm3, xmm5
00007eafdc3dbc21  mulpd xmm3, xmm4
00007eafdc3dbc25  vcmppd xmm2, xmm3, xmm3, 0x03
00007eafdc3dbc2a  ptest xmm2, xmm2
00007eafdc3dbc2f  jnz 0x00007EAFDC3DCFBA
00007eafdc3dbc35  mov [rsp+0x80], rax
00007eafdc3dbc3d  xor eax, eax
00007eafdc3dbc3f  mov r12d, 0x40
00007eafdc3dbc45  mov r11d, 0x200
00007eafdc3dbc4b  cmp r12, r11
00007eafdc3dbc4e  cmc
00007eafdc3dbc4f  lahf
00007eafdc3dbc50  seto al
00007eafdc3dbc53  mov [r15+0x108], eax
00007eafdc3dbc5a  movaps xmm5, xmm8
00007eafdc3dbc5e  addpd xmm5, xmm15
00007eafdc3dbc63  vcmppd xmm4, xmm5, xmm5, 0x03
00007eafdc3dbc68  ptest xmm4, xmm4
00007eafdc3dbc6d  jnz 0x00007EAFDC3DD0FA
00007eafdc3dbc73  movaps xmm8, [r15+0x1B0]
00007eafdc3dbc7b  movaps xmm4, xmm9
00007eafdc3dbc7f  addpd xmm4, xmm8
00007eafdc3dbc84  vcmppd xmm2, xmm4, xmm4, 0x03
00007eafdc3dbc89  ptest xmm2, xmm2
00007eafdc3dbc8e  jnz 0x00007EAFDC3DD23C
00007eafdc3dbc94  movaps xmm9, xmm10
00007eafdc3dbc98  addpd xmm9, xmm8
00007eafdc3dbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
00007eafdc3dbca3  ptest xmm2, xmm2
00007eafdc3dbca8  jnz 0x00007EAFDC3DD37E
00007eafdc3dbcae  movaps xmm10, [r15+0x2F0]
00007eafdc3dbcb6  vmovaps [rsp+0x90], xmm10
00007eafdc3dbcbf  vmovaps xmm8, [rsp+0x90]
00007eafdc3dbcc8  por xmm10, xmm8
00007eafdc3dbccd  movaps xmm8, [r15+0x2E0]
00007eafdc3dbcd5  vmovaps [rsp+0x90], xmm8
00007eafdc3dbcde  vmovaps xmm2, [rsp+0x90]
00007eafdc3dbce7  por xmm8, xmm2
00007eafdc3dbcec  movaps xmm2, [r15+0x2D0]
00007eafdc3dbcf4  vmovaps [rsp+0x90], xmm2
00007eafdc3dbcfd  vmovaps [rsp+0xA0], xmm1
00007eafdc3dbd06  vmovaps xmm1, [rsp+0x90]
00007eafdc3dbd0f  por xmm2, xmm1
00007eafdc3dbd13  movaps xmm1, [r15+0x200]
00007eafdc3dbd1b  vmovaps [rsp+0x90], xmm1
00007eafdc3dbd24  vmovaps [rsp+0xB0], xmm15
00007eafdc3dbd2d  vmovaps xmm15, [rsp+0x90]
00007eafdc3dbd36  por xmm1, xmm15
00007eafdc3dbd3b  movaps xmm15, [r15+0x1C0]
00007eafdc3dbd43  vmovaps [rsp+0x90], xmm15
00007eafdc3dbd4c  vmovaps [rsp+0xC0], xmm1
00007eafdc3dbd55  vmovaps xmm1, [rsp+0x90]
00007eafdc3dbd5e  por xmm15, xmm1
00007eafdc3dbd63  movaps xmm1, [r15+0x190]
00007eafdc3dbd6b  vmovaps [rsp+0x90], xmm1
00007eafdc3dbd74  vmovaps [rsp+0xD0], xmm15
00007eafdc3dbd7d  vmovaps xmm15, [rsp+0x90]
00007eafdc3dbd86  por xmm1, xmm15
00007eafdc3dbd8b  movaps xmm15, [r15+0x300]
00007eafdc3dbd93  vmovaps [rsp+0x90], xmm15
00007eafdc3dbd9c  vmovaps [rsp+0xE0], xmm1
00007eafdc3dbda5  vmovaps xmm1, [rsp+0x90]
00007eafdc3dbdae  por xmm15, xmm1
00007eafdc3dbdb3  mov rax, [rsp+0x80]
00007eafdc3dbdbb  lea r12, [rax+0xA0]
00007eafdc3dbdc2  movups xmm1, [r13+r12*1]
00007eafdc3dbdc8  lea r12, [rax+0xB0]
00007eafdc3dbdcf  vmovaps [rsp+0x80], xmm1
00007eafdc3dbdd8  movups xmm1, [r13+r12*1]
00007eafdc3dbdde  vmovaps [rsp+0x90], xmm1
00007eafdc3dbde7  vmovaps [rsp+0xF0], xmm15
00007eafdc3dbdf0  vmovaps xmm15, [rsp+0xB0]
00007eafdc3dbdf9  vmovaps [rsp+0xB0], xmm14
00007eafdc3dbe02  movaps xmm1, xmm6
00007eafdc3dbe05  addpd xmm1, xmm15
00007eafdc3dbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
00007eafdc3dbe0f  ptest xmm14, xmm14
00007eafdc3dbe15  jnz 0x00007EAFDC3DD4D6
00007eafdc3dbe1b  lea r12, [rax+0xF0]
00007eafdc3dbe22  movups xmm15, [r13+r12*1]
00007eafdc3dbe28  movaps xmm14, xmm4
00007eafdc3dbe2c  addpd xmm14, xmm3
00007eafdc3dbe31  vcmppd xmm6, xmm14, xmm14, 0x03
00007eafdc3dbe37  ptest xmm6, xmm6
00007eafdc3dbe3c  jnz 0x00007EAFDC3DD621
00007eafdc3dbe42  movaps xmm6, xmm9
00007eafdc3dbe46  addpd xmm6, xmm7
00007eafdc3dbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
00007eafdc3dbe4f  ptest xmm4, xmm4
00007eafdc3dbe54  jnz 0x00007EAFDC3DD763
00007eafdc3dbe5a  vmovaps xmm9, [rsp+0x70]
00007eafdc3dbe60  vpermilpd xmm9, xmm9, 0x00
00007eafdc3dbe66  vmovaps xmm4, [rsp+0x90]
00007eafdc3dbe6f  movaps xmm7, xmm4
00007eafdc3dbe72  mulpd xmm7, xmm9
00007eafdc3dbe77  vcmppd xmm3, xmm7, xmm7, 0x03
00007eafdc3dbe7c  ptest xmm3, xmm3
00007eafdc3dbe81  jnz 0x00007EAFDC3DD8A4
00007eafdc3dbe87  vmovaps xmm9, [rsp+0x50]
00007eafdc3dbe8d  vpermilpd xmm9, xmm9, 0x00
00007eafdc3dbe93  movaps xmm4, xmm15
00007eafdc3dbe97  mulpd xmm4, xmm9
00007eafdc3dbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
00007eafdc3dbea1  ptest xmm3, xmm3
00007eafdc3dbea6  jnz 0x00007EAFDC3DD9E5
00007eafdc3dbeac  lea r12, [rax+0xE0]
00007eafdc3dbeb3  movups xmm15, [r13+r12*1]
00007eafdc3dbeb9  vmovaps xmm9, [rsp+0x70]
00007eafdc3dbebf  vpermilpd xmm9, xmm9, 0x00
00007eafdc3dbec5  vmovaps [rsp+0x70], xmm1
00007eafdc3dbecb  vmovaps xmm1, [rsp+0x80]
00007eafdc3dbed4  vmovaps [rsp+0x80], xmm15
00007eafdc3dbedd  movaps xmm3, xmm1
00007eafdc3dbee0  mulpd xmm3, xmm9
00007eafdc3dbee5  vcmppd xmm15, xmm3, xmm3, 0x03
00007eafdc3dbeea  ptest xmm15, xmm15
00007eafdc3dbef0  jnz 0x00007EAFDC3DDB31
00007eafdc3dbef6  vmovaps xmm1, [rsp+0xF0]
00007eafdc3dbeff  vmovaps xmm15, [rsp+0xF0]
00007eafdc3dbf08  por xmm1, xmm15
00007eafdc3dbf0d  movaps [r15+0x300], xmm1
00007eafdc3dbf15  vmovaps xmm15, [rsp+0xE0]
00007eafdc3dbf1e  vmovaps xmm9, [rsp+0xE0]
00007eafdc3dbf27  por xmm15, xmm9
00007eafdc3dbf2c  movaps [r15+0x190], xmm15
00007eafdc3dbf34  vmovaps xmm9, [rsp+0x50]
00007eafdc3dbf3a  vpermilpd xmm9, xmm9, 0x00
00007eafdc3dbf40  vmovaps [rsp+0x90], xmm1
00007eafdc3dbf49  vmovaps [rsp+0xE0], xmm15
00007eafdc3dbf52  vmovaps xmm15, [rsp+0x80]
00007eafdc3dbf5b  vmovaps [rsp+0x80], xmm14
00007eafdc3dbf64  movaps xmm1, xmm15
00007eafdc3dbf68  mulpd xmm1, xmm9
00007eafdc3dbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
00007eafdc3dbf72  ptest xmm14, xmm14
00007eafdc3dbf78  jnz 0x00007EAFDC3DDC72
00007eafdc3dbf7e  lea r12, [rax+0x90]
00007eafdc3dbf85  movups xmm15, [r13+r12*1]
00007eafdc3dbf8b  vmovaps xmm14, [rsp+0xD0]
00007eafdc3dbf94  vmovaps xmm9, [rsp+0xD0]
00007eafdc3dbf9d  por xmm14, xmm9
00007eafdc3dbfa2  movaps [r15+0x1C0], xmm14
00007eafdc3dbfaa  vmovaps xmm9, [rsp+0xC0]
00007eafdc3dbfb3  vmovaps [rsp+0xD0], xmm1
00007eafdc3dbfbc  vmovaps xmm1, [rsp+0xC0]
00007eafdc3dbfc5  por xmm9, xmm1
00007eafdc3dbfca  movaps [r15+0x200], xmm9
00007eafdc3dbfd2  vmovaps [rsp+0xC0], xmm2
00007eafdc3dbfdb  vmovaps xmm1, [rsp+0xC0]
00007eafdc3dbfe4  por xmm2, xmm1
00007eafdc3dbfe8  movaps [r15+0x2D0], xmm2
00007eafdc3dbff0  vmovaps [rsp+0xC0], xmm8
00007eafdc3dbff9  vmovaps xmm1, [rsp+0xC0]
00007eafdc3dc002  por xmm8, xmm1
00007eafdc3dc007  movaps [r15+0x2E0], xmm8
00007eafdc3dc00f  vmovaps [rsp+0xC0], xmm15
00007eafdc3dc018  movaps xmm1, xmm5
00007eafdc3dc01b  addpd xmm1, xmm7
00007eafdc3dc01f  vcmppd xmm15, xmm1, xmm1, 0x03
00007eafdc3dc024  ptest xmm15, xmm15
00007eafdc3dc02a  jnz 0x00007EAFDC3DDDBE
00007eafdc3dc030  vmovaps xmm15, [rsp+0x50]
00007eafdc3dc036  vpermilpd xmm15, xmm15, 0x00
00007eafdc3dc03c  vmovaps xmm5, [rsp+0xC0]
00007eafdc3dc045  vmovaps [rsp+0xC0], xmm1
00007eafdc3dc04e  movaps xmm7, xmm5
00007eafdc3dc051  mulpd xmm7, xmm15
00007eafdc3dc056  vcmppd xmm1, xmm7, xmm7, 0x03
00007eafdc3dc05b  ptest xmm1, xmm1
00007eafdc3dc060  jnz 0x00007EAFDC3DDEFE
00007eafdc3dc066  lea r12, [rax+0x80]
00007eafdc3dc06d  movups xmm1, [r13+r12*1]
00007eafdc3dc073  vmovaps xmm5, [rsp+0x70]
00007eafdc3dc079  vmovaps [rsp+0x70], xmm1
00007eafdc3dc07f  movaps xmm15, xmm5
00007eafdc3dc083  addpd xmm15, xmm3
00007eafdc3dc088  vcmppd xmm1, xmm15, xmm15, 0x03
00007eafdc3dc08e  ptest xmm1, xmm1
00007eafdc3dc093  jnz 0x00007EAFDC3DE049
00007eafdc3dc099  vmovaps xmm5, [rsp+0x80]
00007eafdc3dc0a2  movaps xmm1, xmm5
00007eafdc3dc0a5  addpd xmm1, xmm4
00007eafdc3dc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
00007eafdc3dc0ae  ptest xmm3, xmm3
00007eafdc3dc0b3  jnz 0x00007EAFDC3DE18B
00007eafdc3dc0b9  vmovaps [rsp+0x80], xmm10
00007eafdc3dc0c2  vmovaps xmm5, [rsp+0x80]
00007eafdc3dc0cb  por xmm10, xmm5
00007eafdc3dc0d0  movaps [r15+0x2F0], xmm10
00007eafdc3dc0d8  vmovaps xmm5, [rsp+0x50]
00007eafdc3dc0de  vpermilpd xmm5, xmm5, 0x00
00007eafdc3dc0e4  vmovaps xmm3, [rsp+0x70]
00007eafdc3dc0ea  vmovaps [rsp+0x50], xmm1
00007eafdc3dc0f0  movaps xmm4, xmm3
00007eafdc3dc0f3  mulpd xmm4, xmm5
00007eafdc3dc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
00007eafdc3dc0fc  ptest xmm1, xmm1
00007eafdc3dc101  jnz 0x00007EAFDC3DE2CB
00007eafdc3dc107  lea r12, [rax+0xD0]
00007eafdc3dc10e  movups xmm1, [r13+r12*1]
00007eafdc3dc114  vmovaps xmm3, [rsp+0xD0]
00007eafdc3dc11d  vmovaps [rsp+0x70], xmm1
00007eafdc3dc123  movaps xmm5, xmm6
00007eafdc3dc126  addpd xmm5, xmm3
00007eafdc3dc12a  vcmppd xmm1, xmm5, xmm5, 0x03
00007eafdc3dc12f  ptest xmm1, xmm1
00007eafdc3dc134  jnz 0x00007EAFDC3DE415
00007eafdc3dc13a  vmovaps xmm1, [rsp+0x60]
00007eafdc3dc140  vpermilpd xmm1, xmm1, 0x00
00007eafdc3dc146  movaps xmm6, xmm9
00007eafdc3dc14a  mulpd xmm6, xmm1
00007eafdc3dc14e  vcmppd xmm3, xmm6, xmm6, 0x03
00007eafdc3dc153  ptest xmm3, xmm3
00007eafdc3dc158  jnz 0x00007EAFDC3DE555
00007eafdc3dc15e  movaps [r15+0x260], xmm6
00007eafdc3dc166  vxorps xmm1, xmm1, xmm1
00007eafdc3dc16a  vpbroadcastq xmm1, xmm1
00007eafdc3dc16f  movaps [r15+0x1B0], xmm1
00007eafdc3dc177  vmovaps xmm1, [rsp+0x60]
00007eafdc3dc17d  vpermilpd xmm1, xmm1, 0x00
00007eafdc3dc183  vmovaps xmm3, [rsp+0x70]
00007eafdc3dc189  vmovaps [rsp+0x70], xmm15
00007eafdc3dc18f  movaps xmm9, xmm3
00007eafdc3dc193  mulpd xmm9, xmm1
00007eafdc3dc198  vcmppd xmm15, xmm9, xmm9, 0x03
00007eafdc3dc19e  ptest xmm15, xmm15
00007eafdc3dc1a4  jnz 0x00007EAFDC3DE696
00007eafdc3dc1aa  lea r12, [rax+0xC0]
00007eafdc3dc1b1  movups xmm1, [r13+r12*1]
00007eafdc3dc1b7  vmovaps xmm3, [rsp+0xC0]
00007eafdc3dc1c0  vmovaps [rsp+0x80], xmm1
00007eafdc3dc1c9  movaps xmm15, xmm3
00007eafdc3dc1cd  addpd xmm15, xmm7
00007eafdc3dc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
00007eafdc3dc1d8  ptest xmm1, xmm1
00007eafdc3dc1dd  jnz 0x00007EAFDC3DE7E2
00007eafdc3dc1e3  vmovaps [rsp+0xC0], xmm13
00007eafdc3dc1ec  vmovaps xmm1, [rsp+0xC0]
00007eafdc3dc1f5  por xmm13, xmm1
00007eafdc3dc1fa  movaps [r15+0x270], xmm13
00007eafdc3dc202  vmovaps xmm1, [rsp+0xB0]
00007eafdc3dc20b  vmovaps xmm7, [rsp+0xB0]
00007eafdc3dc214  por xmm1, xmm7
00007eafdc3dc218  movaps [r15+0x1A0], xmm1
00007eafdc3dc220  vmovaps xmm1, [rsp+0x60]
00007eafdc3dc226  vpermilpd xmm1, xmm1, 0x00
00007eafdc3dc22c  vmovaps [rsp+0xB0], xmm1
00007eafdc3dc235  vmovaps xmm1, [rsp+0x80]
00007eafdc3dc23e  vmovaps [rsp+0x80], xmm15
00007eafdc3dc247  vmovaps xmm15, [rsp+0xB0]
00007eafdc3dc250  vmovaps [rsp+0xB0], xmm14
00007eafdc3dc259  movaps xmm3, xmm1
00007eafdc3dc25c  mulpd xmm3, xmm15
00007eafdc3dc261  vcmppd xmm14, xmm3, xmm3, 0x03
00007eafdc3dc266  ptest xmm14, xmm14
00007eafdc3dc26c  jnz 0x00007EAFDC3DE924
00007eafdc3dc272  lea r12, [rax+0x20]
00007eafdc3dc276  movups xmm1, [r13+r12*1]
00007eafdc3dc27c  movaps [r15+0x110], xmm1
00007eafdc3dc284  vmovaps xmm14, [rsp+0x70]
00007eafdc3dc28a  vmovaps [rsp+0x70], xmm1
00007eafdc3dc290  movaps xmm15, xmm14
00007eafdc3dc294  addpd xmm15, xmm4
00007eafdc3dc299  vcmppd xmm1, xmm15, xmm15, 0x03
00007eafdc3dc29f  ptest xmm1, xmm1
00007eafdc3dc2a4  jnz 0x00007EAFDC3DEA6F
00007eafdc3dc2aa  vmovaps xmm1, [rsp+0x60]
00007eafdc3dc2b0  vpermilpd xmm1, xmm1, 0x00
00007eafdc3dc2b6  movaps xmm14, xmm2
00007eafdc3dc2ba  mulpd xmm14, xmm1
00007eafdc3dc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
00007eafdc3dc2c5  ptest xmm4, xmm4
00007eafdc3dc2ca  jnz 0x00007EAFDC3DEBB2
00007eafdc3dc2d0  vmovaps xmm4, [rsp+0x50]
00007eafdc3dc2d6  movaps xmm1, xmm4
00007eafdc3dc2d9  addpd xmm1, xmm9
00007eafdc3dc2de  vcmppd xmm2, xmm1, xmm1, 0x03
00007eafdc3dc2e3  ptest xmm2, xmm2
00007eafdc3dc2e8  jnz 0x00007EAFDC3DECF4
00007eafdc3dc2ee  vmovaps xmm9, [rsp+0x30]
00007eafdc3dc2f4  vpermilpd xmm9, xmm9, 0x00
00007eafdc3dc2fa  vmovaps xmm2, [rsp+0x70]
00007eafdc3dc300  vmovaps [rsp+0x50], xmm1
00007eafdc3dc306  movaps xmm4, xmm2
00007eafdc3dc309  mulpd xmm4, xmm9
00007eafdc3dc30e  vcmppd xmm1, xmm4, xmm4, 0x03
00007eafdc3dc313  ptest xmm1, xmm1
00007eafdc3dc318  jnz 0x00007EAFDC3DEE35
00007eafdc3dc31e  vmovaps xmm1, [rsp+0x30]
00007eafdc3dc324  vpermilpd xmm1, xmm1, 0x00
00007eafdc3dc32a  vmovaps xmm2, [rsp+0x90]
00007eafdc3dc333  vmovaps [rsp+0x60], xmm15
00007eafdc3dc339  movaps xmm9, xmm2
00007eafdc3dc33d  mulpd xmm9, xmm1
00007eafdc3dc342  vcmppd xmm15, xmm9, xmm9, 0x03
00007eafdc3dc348  ptest xmm15, xmm15
00007eafdc3dc34e  jnz 0x00007EAFDC3DEF76
00007eafdc3dc354  vmovaps xmm15, [rsp+0x80]
00007eafdc3dc35d  movaps xmm1, xmm15
00007eafdc3dc361  addpd xmm1, xmm6
00007eafdc3dc365  vcmppd xmm2, xmm1, xmm1, 0x03
00007eafdc3dc36a  ptest xmm2, xmm2
00007eafdc3dc36f  jnz 0x00007EAFDC3DF0B8
00007eafdc3dc375  movaps xmm15, xmm5
00007eafdc3dc379  addpd xmm15, xmm3
00007eafdc3dc37e  vcmppd xmm6, xmm15, xmm15, 0x03
00007eafdc3dc384  ptest xmm6, xmm6
00007eafdc3dc389  jnz 0x00007EAFDC3DF1F9
00007eafdc3dc38f  vmovaps xmm6, [rsp+0x30]
00007eafdc3dc395  vpermilpd xmm6, xmm6, 0x00
00007eafdc3dc39b  movaps xmm5, xmm8
00007eafdc3dc39f  mulpd xmm5, xmm6
00007eafdc3dc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
00007eafdc3dc3a8  ptest xmm3, xmm3
00007eafdc3dc3ad  jnz 0x00007EAFDC3DF33B
00007eafdc3dc3b3  vmovaps xmm8, [rsp+0x30]
00007eafdc3dc3b9  vpermilpd xmm8, xmm8, 0x00
00007eafdc3dc3bf  movaps xmm6, xmm10
00007eafdc3dc3c3  mulpd xmm6, xmm8
00007eafdc3dc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
00007eafdc3dc3cd  ptest xmm3, xmm3
00007eafdc3dc3d2  jnz 0x00007EAFDC3DF47C
00007eafdc3dc3d8  vmovaps xmm8, [rsp+0x60]
00007eafdc3dc3de  movaps xmm10, xmm8
00007eafdc3dc3e2  addpd xmm10, xmm14
00007eafdc3dc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
00007eafdc3dc3ed  ptest xmm3, xmm3
00007eafdc3dc3f2  jnz 0x00007EAFDC3DF5BE
00007eafdc3dc3f8  vmovaps xmm8, [rsp+0x50]
00007eafdc3dc3fe  movaps xmm14, xmm8
00007eafdc3dc402  addpd xmm14, xmm4
00007eafdc3dc407  vcmppd xmm3, xmm14, xmm14, 0x03
00007eafdc3dc40d  ptest xmm3, xmm3
00007eafdc3dc412  jnz 0x00007EAFDC3DF702
00007eafdc3dc418  vmovaps xmm8, [rsp+0x40]
00007eafdc3dc41e  vpermilpd xmm8, xmm8, 0x00
00007eafdc3dc424  movaps xmm4, xmm13
00007eafdc3dc428  mulpd xmm4, xmm8
00007eafdc3dc42d  vcmppd xmm3, xmm4, xmm4, 0x03
00007eafdc3dc432  ptest xmm3, xmm3
00007eafdc3dc437  jnz 0x00007EAFDC3DF845
00007eafdc3dc43d  movaps xmm13, xmm15
00007eafdc3dc441  addpd xmm13, xmm9
00007eafdc3dc446  vcmppd xmm8, xmm13, xmm13, 0x03
00007eafdc3dc44c  ptest xmm8, xmm8
00007eafdc3dc452  jnz 0x00007EAFDC3DF987
00007eafdc3dc458  movaps xmm15, xmm1
00007eafdc3dc45c  addpd xmm15, xmm5
00007eafdc3dc461  vcmppd xmm9, xmm15, xmm15, 0x03
00007eafdc3dc467  ptest xmm9, xmm9
00007eafdc3dc46d  jnz 0x00007EAFDC3DFACB
00007eafdc3dc473  vmovaps [rsp+0x30], xmm11
00007eafdc3dc479  vmovaps xmm1, [rsp+0x30]
00007eafdc3dc47f  por xmm11, xmm1
00007eafdc3dc484  movaps [r15+0x250], xmm11
00007eafdc3dc48c  vmovaps [rsp+0x30], xmm12
00007eafdc3dc492  vmovaps xmm1, [rsp+0x30]
00007eafdc3dc498  por xmm12, xmm1
00007eafdc3dc49d  movaps [r15+0x2A0], xmm12
00007eafdc3dc4a5  vmovaps xmm1, [rsp+0xA0]
00007eafdc3dc4ae  vmovaps xmm11, [rsp+0xA0]
00007eafdc3dc4b7  por xmm1, xmm11
00007eafdc3dc4bc  movaps [r15+0x1D0], xmm1
00007eafdc3dc4c4  lea r12, [rax+0x40]
00007eafdc3dc4c8  movups xmm1, [r13+r12*1]
00007eafdc3dc4ce  movaps [r15+0x2C0], xmm1
00007eafdc3dc4d6  vmovaps xmm11, [rsp+0x40]
00007eafdc3dc4dc  vpermilpd xmm11, xmm11, 0x00
00007eafdc3dc4e2  vmovaps xmm8, [rsp+0xE0]
00007eafdc3dc4eb  movaps xmm9, xmm8
00007eafdc3dc4ef  mulpd xmm9, xmm11
00007eafdc3dc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
00007eafdc3dc4fa  ptest xmm5, xmm5
00007eafdc3dc4ff  jnz 0x00007EAFDC3DFC17
00007eafdc3dc505  movaps xmm11, xmm10
00007eafdc3dc509  addpd xmm11, xmm6
00007eafdc3dc50e  vcmppd xmm8, xmm11, xmm11, 0x03
00007eafdc3dc514  ptest xmm8, xmm8
00007eafdc3dc51a  jnz 0x00007EAFDC3DFD5B
00007eafdc3dc520  movaps xmm10, xmm14
00007eafdc3dc524  addpd xmm10, xmm4
00007eafdc3dc529  vcmppd xmm8, xmm10, xmm10, 0x03
00007eafdc3dc52f  ptest xmm8, xmm8
00007eafdc3dc535  jnz 0x00007EAFDC3DFE9E
00007eafdc3dc53b  vmovaps xmm14, [rsp+0x40]
00007eafdc3dc541  vpermilpd xmm14, xmm14, 0x00
00007eafdc3dc547  movaps xmm8, xmm1
00007eafdc3dc54b  mulpd xmm8, xmm14
00007eafdc3dc550  vcmppd xmm6, xmm8, xmm8, 0x03
00007eafdc3dc556  ptest xmm6, xmm6
00007eafdc3dc55b  jnz 0x00007EAFDC3DFFE1
00007eafdc3dc561  movaps xmm1, [r15+0x2B0]
00007eafdc3dc569  vmovaps xmm14, [rsp+0x40]
00007eafdc3dc56f  vpermilpd xmm14, xmm14, 0x00
00007eafdc3dc575  movaps xmm6, xmm1
00007eafdc3dc578  mulpd xmm6, xmm14
00007eafdc3dc57d  vcmppd xmm5, xmm6, xmm6, 0x03
00007eafdc3dc582  ptest xmm5, xmm5
00007eafdc3dc587  jnz 0x00007EAFDC3E0124
00007eafdc3dc58d  vmovaps xmm1, [rsp+0x10]
00007eafdc3dc593  vpermilpd xmm1, xmm1, 0x00
00007eafdc3dc599  movaps xmm14, xmm12
00007eafdc3dc59d  mulpd xmm14, xmm1
00007eafdc3dc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
00007eafdc3dc5a8  ptest xmm5, xmm5
00007eafdc3dc5ad  jnz 0x00007EAFDC3E0265
00007eafdc3dc5b3  movaps xmm1, xmm13
00007eafdc3dc5b7  addpd xmm1, xmm9
00007eafdc3dc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
00007eafdc3dc5c1  ptest xmm12, xmm12
00007eafdc3dc5c7  jnz 0x00007EAFDC3E03A8
00007eafdc3dc5cd  vmovaps xmm13, [rsp+0x10]
00007eafdc3dc5d3  vpermilpd xmm13, xmm13, 0x00
00007eafdc3dc5d9  movaps xmm12, xmm7
00007eafdc3dc5dd  mulpd xmm12, xmm13
00007eafdc3dc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
00007eafdc3dc5e8  ptest xmm9, xmm9
00007eafdc3dc5ee  jnz 0x00007EAFDC3E04EA
00007eafdc3dc5f4  movaps xmm13, xmm15
00007eafdc3dc5f8  addpd xmm13, xmm8
00007eafdc3dc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
00007eafdc3dc603  ptest xmm9, xmm9
00007eafdc3dc609  jnz 0x00007EAFDC3E062D
00007eafdc3dc60f  movaps xmm15, [r15+0x290]
00007eafdc3dc617  vmovaps xmm9, [rsp+0x10]
00007eafdc3dc61d  vpermilpd xmm9, xmm9, 0x00
00007eafdc3dc623  movaps xmm8, xmm15
00007eafdc3dc627  mulpd xmm8, xmm9
00007eafdc3dc62c  vcmppd xmm7, xmm8, xmm8, 0x03
00007eafdc3dc632  ptest xmm7, xmm7
00007eafdc3dc637  jnz 0x00007EAFDC3E0771
00007eafdc3dc63d  movaps xmm15, xmm11
00007eafdc3dc641  addpd xmm15, xmm6
00007eafdc3dc646  vcmppd xmm9, xmm15, xmm15, 0x03
00007eafdc3dc64c  ptest xmm9, xmm9
00007eafdc3dc652  jnz 0x00007EAFDC3E08B5
00007eafdc3dc658  movaps xmm11, [r15+0x1E0]
00007eafdc3dc660  vmovaps xmm9, [rsp+0x10]
00007eafdc3dc666  vpermilpd xmm9, xmm9, 0x00
00007eafdc3dc66c  movaps xmm7, xmm11
00007eafdc3dc670  mulpd xmm7, xmm9
00007eafdc3dc675  vcmppd xmm6, xmm7, xmm7, 0x03
00007eafdc3dc67a  ptest xmm6, xmm6
00007eafdc3dc67f  jnz 0x00007EAFDC3E09F8
00007eafdc3dc685  movaps xmm11, xmm10
00007eafdc3dc689  addpd xmm11, xmm14
00007eafdc3dc68e  vcmppd xmm9, xmm11, xmm11, 0x03
00007eafdc3dc694  ptest xmm9, xmm9
00007eafdc3dc69a  jnz 0x00007EAFDC3E0B3A
00007eafdc3dc6a0  lea r12, [rax+0x70]
00007eafdc3dc6a4  movups xmm14, [r13+r12*1]
00007eafdc3dc6aa  movaps [r15+0x240], xmm14
00007eafdc3dc6b2  movaps xmm10, xmm1
00007eafdc3dc6b6  addpd xmm10, xmm12
00007eafdc3dc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
00007eafdc3dc6c1  ptest xmm9, xmm9
00007eafdc3dc6c7  jnz 0x00007EAFDC3E0C88
00007eafdc3dc6cd  movaps [r15+0x170], xmm10
00007eafdc3dc6d5  vmovaps xmm1, [rsp+0x20]
00007eafdc3dc6db  vpermilpd xmm1, xmm1, 0x00
00007eafdc3dc6e1  movaps xmm12, xmm14
00007eafdc3dc6e5  mulpd xmm12, xmm1
00007eafdc3dc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
00007eafdc3dc6f0  ptest xmm9, xmm9
00007eafdc3dc6f6  jnz 0x00007EAFDC3E0DCB
00007eafdc3dc6fc  vmovaps xmm1, [rsp+0x20]
00007eafdc3dc702  vpermilpd xmm1, xmm1, 0x00
00007eafdc3dc708  vmovaps xmm9, [rsp+0xB0]
00007eafdc3dc711  movaps xmm14, xmm9
00007eafdc3dc715  mulpd xmm14, xmm1
00007eafdc3dc71a  vcmppd xmm6, xmm14, xmm14, 0x03
00007eafdc3dc720  ptest xmm6, xmm6
00007eafdc3dc725  jnz 0x00007EAFDC3E0F0E
00007eafdc3dc72b  movaps [r15+0x180], xmm14
00007eafdc3dc733  movaps xmm1, xmm13
00007eafdc3dc737  addpd xmm1, xmm8
00007eafdc3dc73c  vcmppd xmm9, xmm1, xmm1, 0x03
00007eafdc3dc741  ptest xmm9, xmm9
00007eafdc3dc747  jnz 0x00007EAFDC3E1051
00007eafdc3dc74d  movaps [r15+0x210], xmm1
00007eafdc3dc755  movups xmm13, [r13+rax*1]
00007eafdc3dc75b  lea r12, [rax+0x10]
00007eafdc3dc75f  movups xmm9, [r13+r12*1]
00007eafdc3dc765  movaps [r15+0x230], xmm9
00007eafdc3dc76d  movaps xmm8, xmm15
00007eafdc3dc771  addpd xmm8, xmm7
00007eafdc3dc776  vcmppd xmm6, xmm8, xmm8, 0x03
00007eafdc3dc77c  ptest xmm6, xmm6
00007eafdc3dc781  jnz 0x00007EAFDC3E11A7
00007eafdc3dc787  movaps [r15+0x130], xmm8
00007eafdc3dc78f  vmovaps xmm15, [rsp+0x20]
00007eafdc3dc795  vpermilpd xmm15, xmm15, 0x00
00007eafdc3dc79b  movaps xmm7, xmm9
00007eafdc3dc79f  mulpd xmm7, xmm15
00007eafdc3dc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
00007eafdc3dc7a9  ptest xmm6, xmm6
00007eafdc3dc7ae  jnz 0x00007EAFDC3E12EA
00007eafdc3dc7b4  movaps [r15+0x220], xmm7
00007eafdc3dc7bc  vmovaps xmm15, [rsp+0x20]
00007eafdc3dc7c2  vpermilpd xmm15, xmm15, 0x00
00007eafdc3dc7c8  movaps xmm9, xmm13
00007eafdc3dc7cc  mulpd xmm9, xmm15
00007eafdc3dc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
00007eafdc3dc7d7  ptest xmm6, xmm6
00007eafdc3dc7dc  jnz 0x00007EAFDC3E142C
00007eafdc3dc7e2  movaps xmm15, xmm11
00007eafdc3dc7e6  addpd xmm15, xmm12
00007eafdc3dc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
00007eafdc3dc7f1  ptest xmm13, xmm13
00007eafdc3dc7f7  jnz 0x00007EAFDC3E1570
00007eafdc3dc7fd  movaps [r15+0x140], xmm15
00007eafdc3dc805  movaps xmm13, xmm10
00007eafdc3dc809  addpd xmm13, xmm14
00007eafdc3dc80e  vcmppd xmm12, xmm13, xmm13, 0x03
00007eafdc3dc814  ptest xmm12, xmm12
00007eafdc3dc81a  jnz 0x00007EAFDC3E16B4
00007eafdc3dc820  movaps [r15+0x150], xmm13
00007eafdc3dc828  movaps xmm14, xmm1
00007eafdc3dc82c  addpd xmm14, xmm7
00007eafdc3dc831  vcmppd xmm12, xmm14, xmm14, 0x03
00007eafdc3dc837  ptest xmm12, xmm12
00007eafdc3dc83d  jnz 0x00007EAFDC3E17F8
00007eafdc3dc843  movaps [r15+0x160], xmm14
00007eafdc3dc84b  movaps xmm1, xmm8
00007eafdc3dc84f  addpd xmm1, xmm9
00007eafdc3dc854  vcmppd xmm12, xmm1, xmm1, 0x03
00007eafdc3dc859  ptest xmm12, xmm12
00007eafdc3dc85f  jnz 0x00007EAFDC3E193A
00007eafdc3dc865  movaps [r15+0x120], xmm1
00007eafdc3dc86d  movups [r13+r14*1], xmm15
00007eafdc3dc873  lea rax, [r14+0x10]
00007eafdc3dc877  movups [r13+rax*1], xmm13
00007eafdc3dc87d  lea rax, [r14+0x20]
00007eafdc3dc881  movups [r13+rax*1], xmm14
00007eafdc3dc887  lea rax, [r14+0x30]
00007eafdc3dc88b  movups [r13+rax*1], xmm1
00007eafdc3dc891  mov eax, [r15+0x108]
00007eafdc3dc898  sahf
00007eafdc3dc899  jnz 0x00007EAFDC3DC8CB
00007eafdc3dc89b  cmp dword ptr [r15+0x318], 0x00
00007eafdc3dc8a3  jz 0x00007EAFDC3DB900
00007eafdc3dc8a9  nop [rax+rax*1], ax
00007eafdc3dc8b2  nop [rax+rax*1], eax
00007eafdc3dc8ba  mov eax, 0x410444
00007eafdc3dc8bf  mov [r15+0x100], rax
00007eafdc3dc8c6  jmp 0x00007EAFDC1FE110
00007eafdc3dc8cb  cmp dword ptr [r15+0x318], 0x00
00007eafdc3dc8d3  jz 0x00007EAFDC3D57E0
00007eafdc3dc8d9  nop [rax+rax*1], ax
00007eafdc3dc8e2  nop [rax+rax*1], eax
00007eafdc3dc8ea  mov eax, 0x410278
00007eafdc3dc8ef  mov [r15+0x100], rax
00007eafdc3dc8f6  jmp 0x00007EAFDC1FE110
00007eafdc3dc8fb  int3
00007eafdc3dc8fc  call 0x00007EAFDC2E27E0
00007eafdc3dc901  jmp 0x00007EAFDC3DB9DF
00007eafdc3dc906  call 0x00007EAFDC2E1570
00007eafdc3dc90b  jmp 0x00007EAFDC3DB9E8
00007eafdc3dc910  call 0x00007EAFDC2E27E0
00007eafdc3dc915  jmp 0x00007EAFDC3DBA44
00007eafdc3dc91a  call 0x00007EAFDC2E1570
00007eafdc3dc91f  jmp 0x00007EAFDC3DBA4D
00007eafdc3dc924  call 0x00007EAFDC2E27E0
00007eafdc3dc929  jmp 0x00007EAFDC3DBA90
00007eafdc3dc92e  call 0x00007EAFDC2E1570
00007eafdc3dc933  jmp 0x00007EAFDC3DBA99
00007eafdc3dc938  call 0x00007EAFDC20DC20
00007eafdc3dc93d  jmp 0x00007EAFDC3DBAD8
00007eafdc3dc942  call 0x00007EAFDC2D59C0
00007eafdc3dc947  jmp 0x00007EAFDC3DBAEB
00007eafdc3dc94c  call 0x00007EAFDC2E0E30
00007eafdc3dc951  jmp 0x00007EAFDC3DBB09
00007eafdc3dc956  call 0x00007EAFDC2DFBC0
00007eafdc3dc95b  jmp 0x00007EAFDC3DBB13
00007eafdc3dc960  call 0x00007EAFDC2DE950
00007eafdc3dc965  jmp 0x00007EAFDC3DBB1D
00007eafdc3dc96a  sub rsp, 0x08
00007eafdc3dc96e  push rax
00007eafdc3dc96f  push rcx
00007eafdc3dc970  push rdx
00007eafdc3dc971  push rdi
00007eafdc3dc972  push rsi
00007eafdc3dc973  push r8
00007eafdc3dc975  push r9
00007eafdc3dc977  push r10
00007eafdc3dc979  push r11
00007eafdc3dc97b  sub rsp, 0xF0
00007eafdc3dc982  vmovaps [rsp], xmm0
00007eafdc3dc987  vmovaps [rsp+0x10], xmm1
00007eafdc3dc98d  vmovaps [rsp+0x20], xmm2
00007eafdc3dc993  vmovaps [rsp+0x30], xmm3
00007eafdc3dc999  vmovaps [rsp+0x40], xmm4
00007eafdc3dc99f  vmovaps [rsp+0x50], xmm5
00007eafdc3dc9a5  vmovaps [rsp+0x60], xmm6
00007eafdc3dc9ab  vmovaps [rsp+0x70], xmm7
00007eafdc3dc9b1  vmovaps [rsp+0x80], xmm9
00007eafdc3dc9ba  vmovaps [rsp+0x90], xmm10
00007eafdc3dc9c3  vmovaps [rsp+0xA0], xmm11
00007eafdc3dc9cc  vmovaps [rsp+0xB0], xmm12
00007eafdc3dc9d5  vmovaps [rsp+0xC0], xmm13
00007eafdc3dc9de  vmovaps [rsp+0xD0], xmm14
00007eafdc3dc9e7  vmovaps [rsp+0xE0], xmm15
00007eafdc3dc9f0  sub rsp, 0x30
00007eafdc3dc9f4  movaps [rsp], xmm8
00007eafdc3dc9f9  movaps [rsp+0x10], xmm12
00007eafdc3dc9ff  movaps [rsp+0x20], xmm15
00007eafdc3dca05  lea rdi, [rsp]
00007eafdc3dca09  mov esi, 0x00
00007eafdc3dca0e  mov rax, 0x645891675530
00007eafdc3dca18  call rax
00007eafdc3dca1a  movaps xmm8, [rsp]
00007eafdc3dca1f  add rsp, 0x30
00007eafdc3dca23  vmovaps xmm0, [rsp]
00007eafdc3dca28  vmovaps xmm1, [rsp+0x10]
00007eafdc3dca2e  vmovaps xmm2, [rsp+0x20]
00007eafdc3dca34  vmovaps xmm3, [rsp+0x30]
00007eafdc3dca3a  vmovaps xmm4, [rsp+0x40]
00007eafdc3dca40  vmovaps xmm5, [rsp+0x50]
00007eafdc3dca46  vmovaps xmm6, [rsp+0x60]
00007eafdc3dca4c  vmovaps xmm7, [rsp+0x70]
00007eafdc3dca52  vmovaps xmm9, [rsp+0x80]
00007eafdc3dca5b  vmovaps xmm10, [rsp+0x90]
00007eafdc3dca64  vmovaps xmm11, [rsp+0xA0]
00007eafdc3dca6d  vmovaps xmm12, [rsp+0xB0]
00007eafdc3dca76  vmovaps xmm13, [rsp+0xC0]
00007eafdc3dca7f  vmovaps xmm14, [rsp+0xD0]
00007eafdc3dca88  vmovaps xmm15, [rsp+0xE0]
00007eafdc3dca91  add rsp, 0xF0
00007eafdc3dca98  pop r11
00007eafdc3dca9a  pop r10
00007eafdc3dca9c  pop r9
00007eafdc3dca9e  pop r8
00007eafdc3dcaa0  pop rsi
00007eafdc3dcaa1  pop rdi
00007eafdc3dcaa2  pop rdx
00007eafdc3dcaa3  pop rcx
00007eafdc3dcaa4  pop rax
00007eafdc3dcaa5  add rsp, 0x08
00007eafdc3dcaa9  jmp 0x00007EAFDC3DBB47
00007eafdc3dcaae  sub rsp, 0x08
00007eafdc3dcab2  push rax
00007eafdc3dcab3  push rcx
00007eafdc3dcab4  push rdx
00007eafdc3dcab5  push rdi
00007eafdc3dcab6  push rsi
00007eafdc3dcab7  push r8
00007eafdc3dcab9  push r9
00007eafdc3dcabb  push r10
00007eafdc3dcabd  push r11
00007eafdc3dcabf  sub rsp, 0xF0
00007eafdc3dcac6  vmovaps [rsp], xmm0
00007eafdc3dcacb  vmovaps [rsp+0x10], xmm1
00007eafdc3dcad1  vmovaps [rsp+0x20], xmm2
00007eafdc3dcad7  vmovaps [rsp+0x30], xmm3
00007eafdc3dcadd  vmovaps [rsp+0x40], xmm4
00007eafdc3dcae3  vmovaps [rsp+0x50], xmm5
00007eafdc3dcae9  vmovaps [rsp+0x60], xmm6
00007eafdc3dcaef  vmovaps [rsp+0x70], xmm8
00007eafdc3dcaf5  vmovaps [rsp+0x80], xmm9
00007eafdc3dcafe  vmovaps [rsp+0x90], xmm10
00007eafdc3dcb07  vmovaps [rsp+0xA0], xmm11
00007eafdc3dcb10  vmovaps [rsp+0xB0], xmm12
00007eafdc3dcb19  vmovaps [rsp+0xC0], xmm13
00007eafdc3dcb22  vmovaps [rsp+0xD0], xmm14
00007eafdc3dcb2b  vmovaps [rsp+0xE0], xmm15
00007eafdc3dcb34  sub rsp, 0x30
00007eafdc3dcb38  movaps [rsp], xmm7
00007eafdc3dcb3c  movaps [rsp+0x10], xmm9
00007eafdc3dcb42  movaps [rsp+0x20], xmm15
00007eafdc3dcb48  lea rdi, [rsp]
00007eafdc3dcb4c  mov esi, 0x00
00007eafdc3dcb51  mov rax, 0x645891675530
00007eafdc3dcb5b  call rax
00007eafdc3dcb5d  movaps xmm7, [rsp]
00007eafdc3dcb61  add rsp, 0x30
00007eafdc3dcb65  vmovaps xmm0, [rsp]
00007eafdc3dcb6a  vmovaps xmm1, [rsp+0x10]
00007eafdc3dcb70  vmovaps xmm2, [rsp+0x20]
00007eafdc3dcb76  vmovaps xmm3, [rsp+0x30]
00007eafdc3dcb7c  vmovaps xmm4, [rsp+0x40]
00007eafdc3dcb82  vmovaps xmm5, [rsp+0x50]
00007eafdc3dcb88  vmovaps xmm6, [rsp+0x60]
00007eafdc3dcb8e  vmovaps xmm8, [rsp+0x70]
00007eafdc3dcb94  vmovaps xmm9, [rsp+0x80]
00007eafdc3dcb9d  vmovaps xmm10, [rsp+0x90]
00007eafdc3dcba6  vmovaps xmm11, [rsp+0xA0]
00007eafdc3dcbaf  vmovaps xmm12, [rsp+0xB0]
00007eafdc3dcbb8  vmovaps xmm13, [rsp+0xC0]
00007eafdc3dcbc1  vmovaps xmm14, [rsp+0xD0]
00007eafdc3dcbca  vmovaps xmm15, [rsp+0xE0]
00007eafdc3dcbd3  add rsp, 0xF0
00007eafdc3dcbda  pop r11
00007eafdc3dcbdc  pop r10
00007eafdc3dcbde  pop r9
00007eafdc3dcbe0  pop r8
00007eafdc3dcbe2  pop rsi
00007eafdc3dcbe3  pop rdi
00007eafdc3dcbe4  pop rdx
00007eafdc3dcbe5  pop rcx
00007eafdc3dcbe6  pop rax
00007eafdc3dcbe7  add rsp, 0x08
00007eafdc3dcbeb  jmp 0x00007EAFDC3DBB75
00007eafdc3dcbf0  sub rsp, 0x08
00007eafdc3dcbf4  push rax
00007eafdc3dcbf5  push rcx
00007eafdc3dcbf6  push rdx
00007eafdc3dcbf7  push rdi
00007eafdc3dcbf8  push rsi
00007eafdc3dcbf9  push r8
00007eafdc3dcbfb  push r9
00007eafdc3dcbfd  push r10
00007eafdc3dcbff  push r11
00007eafdc3dcc01  sub rsp, 0xF0
00007eafdc3dcc08  vmovaps [rsp], xmm0
00007eafdc3dcc0d  vmovaps [rsp+0x10], xmm1
00007eafdc3dcc13  vmovaps [rsp+0x20], xmm2
00007eafdc3dcc19  vmovaps [rsp+0x30], xmm3
00007eafdc3dcc1f  vmovaps [rsp+0x40], xmm4
00007eafdc3dcc25  vmovaps [rsp+0x50], xmm5
00007eafdc3dcc2b  vmovaps [rsp+0x60], xmm6
00007eafdc3dcc31  vmovaps [rsp+0x70], xmm7
00007eafdc3dcc37  vmovaps [rsp+0x80], xmm8
00007eafdc3dcc40  vmovaps [rsp+0x90], xmm10
00007eafdc3dcc49  vmovaps [rsp+0xA0], xmm11
00007eafdc3dcc52  vmovaps [rsp+0xB0], xmm12
00007eafdc3dcc5b  vmovaps [rsp+0xC0], xmm13
00007eafdc3dcc64  vmovaps [rsp+0xD0], xmm14
00007eafdc3dcc6d  vmovaps [rsp+0xE0], xmm15
00007eafdc3dcc76  sub rsp, 0x30
00007eafdc3dcc7a  movaps [rsp], xmm9
00007eafdc3dcc7f  movaps [rsp+0x10], xmm12
00007eafdc3dcc85  movaps [rsp+0x20], xmm10
00007eafdc3dcc8b  lea rdi, [rsp]
00007eafdc3dcc8f  mov esi, 0x00
00007eafdc3dcc94  mov rax, 0x645891675530
00007eafdc3dcc9e  call rax
00007eafdc3dcca0  movaps xmm9, [rsp]
00007eafdc3dcca5  add rsp, 0x30
00007eafdc3dcca9  vmovaps xmm0, [rsp]
00007eafdc3dccae  vmovaps xmm1, [rsp+0x10]
00007eafdc3dccb4  vmovaps xmm2, [rsp+0x20]
00007eafdc3dccba  vmovaps xmm3, [rsp+0x30]
00007eafdc3dccc0  vmovaps xmm4, [rsp+0x40]
00007eafdc3dccc6  vmovaps xmm5, [rsp+0x50]
00007eafdc3dcccc  vmovaps xmm6, [rsp+0x60]
00007eafdc3dccd2  vmovaps xmm7, [rsp+0x70]
00007eafdc3dccd8  vmovaps xmm8, [rsp+0x80]
00007eafdc3dcce1  vmovaps xmm10, [rsp+0x90]
00007eafdc3dccea  vmovaps xmm11, [rsp+0xA0]
00007eafdc3dccf3  vmovaps xmm12, [rsp+0xB0]
00007eafdc3dccfc  vmovaps xmm13, [rsp+0xC0]
00007eafdc3dcd05  vmovaps xmm14, [rsp+0xD0]
00007eafdc3dcd0e  vmovaps xmm15, [rsp+0xE0]
00007eafdc3dcd17  add rsp, 0xF0
00007eafdc3dcd1e  pop r11
00007eafdc3dcd20  pop r10
00007eafdc3dcd22  pop r9
00007eafdc3dcd24  pop r8
00007eafdc3dcd26  pop rsi
00007eafdc3dcd27  pop rdi
00007eafdc3dcd28  pop rdx
00007eafdc3dcd29  pop rcx
00007eafdc3dcd2a  pop rax
00007eafdc3dcd2b  add rsp, 0x08
00007eafdc3dcd2f  jmp 0x00007EAFDC3DBB99
00007eafdc3dcd34  sub rsp, 0x08
00007eafdc3dcd38  push rax
00007eafdc3dcd39  push rcx
00007eafdc3dcd3a  push rdx
00007eafdc3dcd3b  push rdi
00007eafdc3dcd3c  push rsi
00007eafdc3dcd3d  push r8
00007eafdc3dcd3f  push r9
00007eafdc3dcd41  push r10
00007eafdc3dcd43  push r11
00007eafdc3dcd45  sub rsp, 0xF0
00007eafdc3dcd4c  vmovaps [rsp], xmm0
00007eafdc3dcd51  vmovaps [rsp+0x10], xmm1
00007eafdc3dcd57  vmovaps [rsp+0x20], xmm2
00007eafdc3dcd5d  vmovaps [rsp+0x30], xmm3
00007eafdc3dcd63  vmovaps [rsp+0x40], xmm4
00007eafdc3dcd69  vmovaps [rsp+0x50], xmm5
00007eafdc3dcd6f  vmovaps [rsp+0x60], xmm6
00007eafdc3dcd75  vmovaps [rsp+0x70], xmm7
00007eafdc3dcd7b  vmovaps [rsp+0x80], xmm8
00007eafdc3dcd84  vmovaps [rsp+0x90], xmm9
00007eafdc3dcd8d  vmovaps [rsp+0xA0], xmm11
00007eafdc3dcd96  vmovaps [rsp+0xB0], xmm12
00007eafdc3dcd9f  vmovaps [rsp+0xC0], xmm13
00007eafdc3dcda8  vmovaps [rsp+0xD0], xmm14
00007eafdc3dcdb1  vmovaps [rsp+0xE0], xmm15
00007eafdc3dcdba  sub rsp, 0x30
00007eafdc3dcdbe  movaps [rsp], xmm10
00007eafdc3dcdc3  movaps [rsp+0x10], xmm12
00007eafdc3dcdc9  movaps [rsp+0x20], xmm11
00007eafdc3dcdcf  lea rdi, [rsp]
00007eafdc3dcdd3  mov esi, 0x00
00007eafdc3dcdd8  mov rax, 0x645891675530
00007eafdc3dcde2  call rax
00007eafdc3dcde4  movaps xmm10, [rsp]
00007eafdc3dcde9  add rsp, 0x30
00007eafdc3dcded  vmovaps xmm0, [rsp]
00007eafdc3dcdf2  vmovaps xmm1, [rsp+0x10]
00007eafdc3dcdf8  vmovaps xmm2, [rsp+0x20]
00007eafdc3dcdfe  vmovaps xmm3, [rsp+0x30]
00007eafdc3dce04  vmovaps xmm4, [rsp+0x40]
00007eafdc3dce0a  vmovaps xmm5, [rsp+0x50]
00007eafdc3dce10  vmovaps xmm6, [rsp+0x60]
00007eafdc3dce16  vmovaps xmm7, [rsp+0x70]
00007eafdc3dce1c  vmovaps xmm8, [rsp+0x80]
00007eafdc3dce25  vmovaps xmm9, [rsp+0x90]
00007eafdc3dce2e  vmovaps xmm11, [rsp+0xA0]
00007eafdc3dce37  vmovaps xmm12, [rsp+0xB0]
00007eafdc3dce40  vmovaps xmm13, [rsp+0xC0]
00007eafdc3dce49  vmovaps xmm14, [rsp+0xD0]
00007eafdc3dce52  vmovaps xmm15, [rsp+0xE0]
00007eafdc3dce5b  add rsp, 0xF0
00007eafdc3dce62  pop r11
00007eafdc3dce64  pop r10
00007eafdc3dce66  pop r9
00007eafdc3dce68  pop r8
00007eafdc3dce6a  pop rsi
00007eafdc3dce6b  pop rdi
00007eafdc3dce6c  pop rdx
00007eafdc3dce6d  pop rcx
00007eafdc3dce6e  pop rax
00007eafdc3dce6f  add rsp, 0x08
00007eafdc3dce73  jmp 0x00007EAFDC3DBBB3
00007eafdc3dce78  sub rsp, 0x08
00007eafdc3dce7c  push rax
00007eafdc3dce7d  push rcx
00007eafdc3dce7e  push rdx
00007eafdc3dce7f  push rdi
00007eafdc3dce80  push rsi
00007eafdc3dce81  push r8
00007eafdc3dce83  push r9
00007eafdc3dce85  push r10
00007eafdc3dce87  push r11
00007eafdc3dce89  sub rsp, 0xF0
00007eafdc3dce90  vmovaps [rsp], xmm0
00007eafdc3dce95  vmovaps [rsp+0x10], xmm1
00007eafdc3dce9b  vmovaps [rsp+0x20], xmm2
00007eafdc3dcea1  vmovaps [rsp+0x30], xmm3
00007eafdc3dcea7  vmovaps [rsp+0x40], xmm4
00007eafdc3dcead  vmovaps [rsp+0x50], xmm5
00007eafdc3dceb3  vmovaps [rsp+0x60], xmm7
00007eafdc3dceb9  vmovaps [rsp+0x70], xmm8
00007eafdc3dcebf  vmovaps [rsp+0x80], xmm9
00007eafdc3dcec8  vmovaps [rsp+0x90], xmm10
00007eafdc3dced1  vmovaps [rsp+0xA0], xmm11
00007eafdc3dceda  vmovaps [rsp+0xB0], xmm12
00007eafdc3dcee3  vmovaps [rsp+0xC0], xmm13
00007eafdc3dceec  vmovaps [rsp+0xD0], xmm14
00007eafdc3dcef5  vmovaps [rsp+0xE0], xmm15
00007eafdc3dcefe  sub rsp, 0x30
00007eafdc3dcf02  movaps [rsp], xmm6
00007eafdc3dcf06  movaps [rsp+0x10], xmm12
00007eafdc3dcf0c  movaps [rsp+0x20], xmm11
00007eafdc3dcf12  lea rdi, [rsp]
00007eafdc3dcf16  mov esi, 0x00
00007eafdc3dcf1b  mov rax, 0x645891675530
00007eafdc3dcf25  call rax
00007eafdc3dcf27  movaps xmm6, [rsp]
00007eafdc3dcf2b  add rsp, 0x30
00007eafdc3dcf2f  vmovaps xmm0, [rsp]
00007eafdc3dcf34  vmovaps xmm1, [rsp+0x10]
00007eafdc3dcf3a  vmovaps xmm2, [rsp+0x20]
00007eafdc3dcf40  vmovaps xmm3, [rsp+0x30]
00007eafdc3dcf46  vmovaps xmm4, [rsp+0x40]
00007eafdc3dcf4c  vmovaps xmm5, [rsp+0x50]
00007eafdc3dcf52  vmovaps xmm7, [rsp+0x60]
00007eafdc3dcf58  vmovaps xmm8, [rsp+0x70]
00007eafdc3dcf5e  vmovaps xmm9, [rsp+0x80]
00007eafdc3dcf67  vmovaps xmm10, [rsp+0x90]
00007eafdc3dcf70  vmovaps xmm11, [rsp+0xA0]
00007eafdc3dcf79  vmovaps xmm12, [rsp+0xB0]
00007eafdc3dcf82  vmovaps xmm13, [rsp+0xC0]
00007eafdc3dcf8b  vmovaps xmm14, [rsp+0xD0]
00007eafdc3dcf94  vmovaps xmm15, [rsp+0xE0]
00007eafdc3dcf9d  add rsp, 0xF0
00007eafdc3dcfa4  pop r11
00007eafdc3dcfa6  pop r10
00007eafdc3dcfa8  pop r9
00007eafdc3dcfaa  pop r8
00007eafdc3dcfac  pop rsi
00007eafdc3dcfad  pop rdi
00007eafdc3dcfae  pop rdx
00007eafdc3dcfaf  pop rcx
00007eafdc3dcfb0  pop rax
00007eafdc3dcfb1  add rsp, 0x08
00007eafdc3dcfb5  jmp 0x00007EAFDC3DBBD4
00007eafdc3dcfba  sub rsp, 0x08
00007eafdc3dcfbe  push rax
00007eafdc3dcfbf  push rcx
00007eafdc3dcfc0  push rdx
00007eafdc3dcfc1  push rdi
00007eafdc3dcfc2  push rsi
00007eafdc3dcfc3  push r8
00007eafdc3dcfc5  push r9
00007eafdc3dcfc7  push r10
00007eafdc3dcfc9  push r11
00007eafdc3dcfcb  sub rsp, 0xF0
00007eafdc3dcfd2  vmovaps [rsp], xmm0
00007eafdc3dcfd7  vmovaps [rsp+0x10], xmm1
00007eafdc3dcfdd  vmovaps [rsp+0x20], xmm2
00007eafdc3dcfe3  vmovaps [rsp+0x30], xmm4
00007eafdc3dcfe9  vmovaps [rsp+0x40], xmm5
00007eafdc3dcfef  vmovaps [rsp+0x50], xmm6
00007eafdc3dcff5  vmovaps [rsp+0x60], xmm7
00007eafdc3dcffb  vmovaps [rsp+0x70], xmm8
00007eafdc3dd001  vmovaps [rsp+0x80], xmm9
00007eafdc3dd00a  vmovaps [rsp+0x90], xmm10
00007eafdc3dd013  vmovaps [rsp+0xA0], xmm11
00007eafdc3dd01c  vmovaps [rsp+0xB0], xmm12
00007eafdc3dd025  vmovaps [rsp+0xC0], xmm13
00007eafdc3dd02e  vmovaps [rsp+0xD0], xmm14
00007eafdc3dd037  vmovaps [rsp+0xE0], xmm15
00007eafdc3dd040  sub rsp, 0x30
00007eafdc3dd044  movaps [rsp], xmm3
00007eafdc3dd048  movaps [rsp+0x10], xmm5
00007eafdc3dd04d  movaps [rsp+0x20], xmm4
00007eafdc3dd052  lea rdi, [rsp]
00007eafdc3dd056  mov esi, 0x00
00007eafdc3dd05b  mov rax, 0x645891675530
00007eafdc3dd065  call rax
00007eafdc3dd067  movaps xmm3, [rsp]
00007eafdc3dd06b  add rsp, 0x30
00007eafdc3dd06f  vmovaps xmm0, [rsp]
00007eafdc3dd074  vmovaps xmm1, [rsp+0x10]
00007eafdc3dd07a  vmovaps xmm2, [rsp+0x20]
00007eafdc3dd080  vmovaps xmm4, [rsp+0x30]
00007eafdc3dd086  vmovaps xmm5, [rsp+0x40]
00007eafdc3dd08c  vmovaps xmm6, [rsp+0x50]
00007eafdc3dd092  vmovaps xmm7, [rsp+0x60]
00007eafdc3dd098  vmovaps xmm8, [rsp+0x70]
00007eafdc3dd09e  vmovaps xmm9, [rsp+0x80]
00007eafdc3dd0a7  vmovaps xmm10, [rsp+0x90]
00007eafdc3dd0b0  vmovaps xmm11, [rsp+0xA0]
00007eafdc3dd0b9  vmovaps xmm12, [rsp+0xB0]
00007eafdc3dd0c2  vmovaps xmm13, [rsp+0xC0]
00007eafdc3dd0cb  vmovaps xmm14, [rsp+0xD0]
00007eafdc3dd0d4  vmovaps xmm15, [rsp+0xE0]
00007eafdc3dd0dd  add rsp, 0xF0
00007eafdc3dd0e4  pop r11
00007eafdc3dd0e6  pop r10
00007eafdc3dd0e8  pop r9
00007eafdc3dd0ea  pop r8
00007eafdc3dd0ec  pop rsi
00007eafdc3dd0ed  pop rdi
00007eafdc3dd0ee  pop rdx
00007eafdc3dd0ef  pop rcx
00007eafdc3dd0f0  pop rax
00007eafdc3dd0f1  add rsp, 0x08
00007eafdc3dd0f5  jmp 0x00007EAFDC3DBC35
00007eafdc3dd0fa  sub rsp, 0x08
00007eafdc3dd0fe  push rax
00007eafdc3dd0ff  push rcx
00007eafdc3dd100  push rdx
00007eafdc3dd101  push rdi
00007eafdc3dd102  push rsi
00007eafdc3dd103  push r8
00007eafdc3dd105  push r9
00007eafdc3dd107  push r10
00007eafdc3dd109  push r11
00007eafdc3dd10b  sub rsp, 0xF0
00007eafdc3dd112  vmovaps [rsp], xmm0
00007eafdc3dd117  vmovaps [rsp+0x10], xmm1
00007eafdc3dd11d  vmovaps [rsp+0x20], xmm2
00007eafdc3dd123  vmovaps [rsp+0x30], xmm3
00007eafdc3dd129  vmovaps [rsp+0x40], xmm4
00007eafdc3dd12f  vmovaps [rsp+0x50], xmm6
00007eafdc3dd135  vmovaps [rsp+0x60], xmm7
00007eafdc3dd13b  vmovaps [rsp+0x70], xmm8
00007eafdc3dd141  vmovaps [rsp+0x80], xmm9
00007eafdc3dd14a  vmovaps [rsp+0x90], xmm10
00007eafdc3dd153  vmovaps [rsp+0xA0], xmm11
00007eafdc3dd15c  vmovaps [rsp+0xB0], xmm12
00007eafdc3dd165  vmovaps [rsp+0xC0], xmm13
00007eafdc3dd16e  vmovaps [rsp+0xD0], xmm14
00007eafdc3dd177  vmovaps [rsp+0xE0], xmm15
00007eafdc3dd180  sub rsp, 0x30
00007eafdc3dd184  movaps [rsp], xmm5
00007eafdc3dd188  movaps [rsp+0x10], xmm8
00007eafdc3dd18e  movaps [rsp+0x20], xmm15
00007eafdc3dd194  lea rdi, [rsp]
00007eafdc3dd198  mov esi, 0x00
00007eafdc3dd19d  mov rax, 0x645891675530
00007eafdc3dd1a7  call rax
00007eafdc3dd1a9  movaps xmm5, [rsp]
00007eafdc3dd1ad  add rsp, 0x30
00007eafdc3dd1b1  vmovaps xmm0, [rsp]
00007eafdc3dd1b6  vmovaps xmm1, [rsp+0x10]
00007eafdc3dd1bc  vmovaps xmm2, [rsp+0x20]
00007eafdc3dd1c2  vmovaps xmm3, [rsp+0x30]
00007eafdc3dd1c8  vmovaps xmm4, [rsp+0x40]
00007eafdc3dd1ce  vmovaps xmm6, [rsp+0x50]
00007eafdc3dd1d4  vmovaps xmm7, [rsp+0x60]
00007eafdc3dd1da  vmovaps xmm8, [rsp+0x70]
00007eafdc3dd1e0  vmovaps xmm9, [rsp+0x80]
00007eafdc3dd1e9  vmovaps xmm10, [rsp+0x90]
00007eafdc3dd1f2  vmovaps xmm11, [rsp+0xA0]
00007eafdc3dd1fb  vmovaps xmm12, [rsp+0xB0]
00007eafdc3dd204  vmovaps xmm13, [rsp+0xC0]
00007eafdc3dd20d  vmovaps xmm14, [rsp+0xD0]
00007eafdc3dd216  vmovaps xmm15, [rsp+0xE0]
00007eafdc3dd21f  add rsp, 0xF0
00007eafdc3dd226  pop r11
00007eafdc3dd228  pop r10
00007eafdc3dd22a  pop r9
00007eafdc3dd22c  pop r8
00007eafdc3dd22e  pop rsi
00007eafdc3dd22f  pop rdi
00007eafdc3dd230  pop rdx
00007eafdc3dd231  pop rcx
00007eafdc3dd232  pop rax
00007eafdc3dd233  add rsp, 0x08
00007eafdc3dd237  jmp 0x00007EAFDC3DBC73
00007eafdc3dd23c  sub rsp, 0x08
00007eafdc3dd240  push rax
00007eafdc3dd241  push rcx
00007eafdc3dd242  push rdx
00007eafdc3dd243  push rdi
00007eafdc3dd244  push rsi
00007eafdc3dd245  push r8
00007eafdc3dd247  push r9
00007eafdc3dd249  push r10
00007eafdc3dd24b  push r11
00007eafdc3dd24d  sub rsp, 0xF0
00007eafdc3dd254  vmovaps [rsp], xmm0
00007eafdc3dd259  vmovaps [rsp+0x10], xmm1
00007eafdc3dd25f  vmovaps [rsp+0x20], xmm2
00007eafdc3dd265  vmovaps [rsp+0x30], xmm3
00007eafdc3dd26b  vmovaps [rsp+0x40], xmm5
00007eafdc3dd271  vmovaps [rsp+0x50], xmm6
00007eafdc3dd277  vmovaps [rsp+0x60], xmm7
00007eafdc3dd27d  vmovaps [rsp+0x70], xmm8
00007eafdc3dd283  vmovaps [rsp+0x80], xmm9
00007eafdc3dd28c  vmovaps [rsp+0x90], xmm10
00007eafdc3dd295  vmovaps [rsp+0xA0], xmm11
00007eafdc3dd29e  vmovaps [rsp+0xB0], xmm12
00007eafdc3dd2a7  vmovaps [rsp+0xC0], xmm13
00007eafdc3dd2b0  vmovaps [rsp+0xD0], xmm14
00007eafdc3dd2b9  vmovaps [rsp+0xE0], xmm15
00007eafdc3dd2c2  sub rsp, 0x30
00007eafdc3dd2c6  movaps [rsp], xmm4
00007eafdc3dd2ca  movaps [rsp+0x10], xmm9
00007eafdc3dd2d0  movaps [rsp+0x20], xmm8
00007eafdc3dd2d6  lea rdi, [rsp]
00007eafdc3dd2da  mov esi, 0x00
00007eafdc3dd2df  mov rax, 0x645891675530
00007eafdc3dd2e9  call rax
00007eafdc3dd2eb  movaps xmm4, [rsp]
00007eafdc3dd2ef  add rsp, 0x30
00007eafdc3dd2f3  vmovaps xmm0, [rsp]
00007eafdc3dd2f8  vmovaps xmm1, [rsp+0x10]
00007eafdc3dd2fe  vmovaps xmm2, [rsp+0x20]
00007eafdc3dd304  vmovaps xmm3, [rsp+0x30]
00007eafdc3dd30a  vmovaps xmm5, [rsp+0x40]
00007eafdc3dd310  vmovaps xmm6, [rsp+0x50]
00007eafdc3dd316  vmovaps xmm7, [rsp+0x60]
00007eafdc3dd31c  vmovaps xmm8, [rsp+0x70]
00007eafdc3dd322  vmovaps xmm9, [rsp+0x80]
00007eafdc3dd32b  vmovaps xmm10, [rsp+0x90]
00007eafdc3dd334  vmovaps xmm11, [rsp+0xA0]
00007eafdc3dd33d  vmovaps xmm12, [rsp+0xB0]
00007eafdc3dd346  vmovaps xmm13, [rsp+0xC0]
00007eafdc3dd34f  vmovaps xmm14, [rsp+0xD0]
00007eafdc3dd358  vmovaps xmm15, [rsp+0xE0]
00007eafdc3dd361  add rsp, 0xF0
00007eafdc3dd368  pop r11
00007eafdc3dd36a  pop r10
00007eafdc3dd36c  pop r9
00007eafdc3dd36e  pop r8
00007eafdc3dd370  pop rsi
00007eafdc3dd371  pop rdi
00007eafdc3dd372  pop rdx
00007eafdc3dd373  pop rcx
00007eafdc3dd374  pop rax
00007eafdc3dd375  add rsp, 0x08
00007eafdc3dd379  jmp 0x00007EAFDC3DBC94
00007eafdc3dd37e  sub rsp, 0x08
00007eafdc3dd382  push rax
00007eafdc3dd383  push rcx
00007eafdc3dd384  push rdx
00007eafdc3dd385  push rdi
00007eafdc3dd386  push rsi
00007eafdc3dd387  push r8
00007eafdc3dd389  push r9
00007eafdc3dd38b  push r10
00007eafdc3dd38d  push r11
00007eafdc3dd38f  sub rsp, 0xF0
00007eafdc3dd396  vmovaps [rsp], xmm0
00007eafdc3dd39b  vmovaps [rsp+0x10], xmm1
00007eafdc3dd3a1  vmovaps [rsp+0x20], xmm2
00007eafdc3dd3a7  vmovaps [rsp+0x30], xmm3
00007eafdc3dd3ad  vmovaps [rsp+0x40], xmm4
00007eafdc3dd3b3  vmovaps [rsp+0x50], xmm5
00007eafdc3dd3b9  vmovaps [rsp+0x60], xmm6
00007eafdc3dd3bf  vmovaps [rsp+0x70], xmm7
00007eafdc3dd3c5  vmovaps [rsp+0x80], xmm8
00007eafdc3dd3ce  vmovaps [rsp+0x90], xmm10
00007eafdc3dd3d7  vmovaps [rsp+0xA0], xmm11
00007eafdc3dd3e0  vmovaps [rsp+0xB0], xmm12
00007eafdc3dd3e9  vmovaps [rsp+0xC0], xmm13
00007eafdc3dd3f2  vmovaps [rsp+0xD0], xmm14
00007eafdc3dd3fb  vmovaps [rsp+0xE0], xmm15
00007eafdc3dd404  sub rsp, 0x30
00007eafdc3dd408  movaps [rsp], xmm9
00007eafdc3dd40d  movaps [rsp+0x10], xmm10
00007eafdc3dd413  movaps [rsp+0x20], xmm8
00007eafdc3dd419  lea rdi, [rsp]
00007eafdc3dd41d  mov esi, 0x00
00007eafdc3dd422  mov rax, 0x645891675530
00007eafdc3dd42c  call rax
00007eafdc3dd42e  movaps xmm9, [rsp]
00007eafdc3dd433  add rsp, 0x30
00007eafdc3dd437  vmovaps xmm0, [rsp]
00007eafdc3dd43c  vmovaps xmm1, [rsp+0x10]
00007eafdc3dd442  vmovaps xmm2, [rsp+0x20]
00007eafdc3dd448  vmovaps xmm3, [rsp+0x30]
00007eafdc3dd44e  vmovaps xmm4, [rsp+0x40]
00007eafdc3dd454  vmovaps xmm5, [rsp+0x50]
00007eafdc3dd45a  vmovaps xmm6, [rsp+0x60]
00007eafdc3dd460  vmovaps xmm7, [rsp+0x70]
00007eafdc3dd466  vmovaps xmm8, [rsp+0x80]
00007eafdc3dd46f  vmovaps xmm10, [rsp+0x90]
00007eafdc3dd478  vmovaps xmm11, [rsp+0xA0]
00007eafdc3dd481  vmovaps xmm12, [rsp+0xB0]
00007eafdc3dd48a  vmovaps xmm13, [rsp+0xC0]
00007eafdc3dd493  vmovaps xmm14, [rsp+0xD0]
00007eafdc3dd49c  vmovaps xmm15, [rsp+0xE0]
00007eafdc3dd4a5  add rsp, 0xF0
00007eafdc3dd4ac  pop r11
00007eafdc3dd4ae  pop r10
00007eafdc3dd4b0  pop r9
00007eafdc3dd4b2  pop r8
00007eafdc3dd4b4  pop rsi
00007eafdc3dd4b5  pop rdi
00007eafdc3dd4b6  pop rdx
00007eafdc3dd4b7  pop rcx
00007eafdc3dd4b8  pop rax
00007eafdc3dd4b9  add rsp, 0x08
00007eafdc3dd4bd  jmp 0x00007EAFDC3DBCAE
00007eafdc3dd4c2  call 0x00007EAFDC2B52F0
00007eafdc3dd4c7  jmp 0x00007EAFDC3DBDC8
00007eafdc3dd4cc  call 0x00007EAFDC2B52F0
00007eafdc3dd4d1  jmp 0x00007EAFDC3DBDDE
00007eafdc3dd4d6  sub rsp, 0x08
00007eafdc3dd4da  push rax
00007eafdc3dd4db  push rcx
00007eafdc3dd4dc  push rdx
00007eafdc3dd4dd  push rdi
00007eafdc3dd4de  push rsi
00007eafdc3dd4df  push r8
00007eafdc3dd4e1  push r9
00007eafdc3dd4e3  push r10
00007eafdc3dd4e5  push r11
00007eafdc3dd4e7  sub rsp, 0xF0
00007eafdc3dd4ee  vmovaps [rsp], xmm0
00007eafdc3dd4f3  vmovaps [rsp+0x10], xmm2
00007eafdc3dd4f9  vmovaps [rsp+0x20], xmm3
00007eafdc3dd4ff  vmovaps [rsp+0x30], xmm4
00007eafdc3dd505  vmovaps [rsp+0x40], xmm5
00007eafdc3dd50b  vmovaps [rsp+0x50], xmm6
00007eafdc3dd511  vmovaps [rsp+0x60], xmm7
00007eafdc3dd517  vmovaps [rsp+0x70], xmm8
00007eafdc3dd51d  vmovaps [rsp+0x80], xmm9
00007eafdc3dd526  vmovaps [rsp+0x90], xmm10
00007eafdc3dd52f  vmovaps [rsp+0xA0], xmm11
00007eafdc3dd538  vmovaps [rsp+0xB0], xmm12
00007eafdc3dd541  vmovaps [rsp+0xC0], xmm13
00007eafdc3dd54a  vmovaps [rsp+0xD0], xmm14
00007eafdc3dd553  vmovaps [rsp+0xE0], xmm15
00007eafdc3dd55c  sub rsp, 0x30
00007eafdc3dd560  movaps [rsp], xmm1
00007eafdc3dd564  movaps [rsp+0x10], xmm6
00007eafdc3dd569  movaps [rsp+0x20], xmm15
00007eafdc3dd56f  lea rdi, [rsp]
00007eafdc3dd573  mov esi, 0x00
00007eafdc3dd578  mov rax, 0x645891675530
00007eafdc3dd582  call rax
00007eafdc3dd584  movaps xmm1, [rsp]
00007eafdc3dd588  add rsp, 0x30
00007eafdc3dd58c  vmovaps xmm0, [rsp]
00007eafdc3dd591  vmovaps xmm2, [rsp+0x10]
00007eafdc3dd597  vmovaps xmm3, [rsp+0x20]
00007eafdc3dd59d  vmovaps xmm4, [rsp+0x30]
00007eafdc3dd5a3  vmovaps xmm5, [rsp+0x40]
00007eafdc3dd5a9  vmovaps xmm6, [rsp+0x50]
00007eafdc3dd5af  vmovaps xmm7, [rsp+0x60]
00007eafdc3dd5b5  vmovaps xmm8, [rsp+0x70]
00007eafdc3dd5bb  vmovaps xmm9, [rsp+0x80]
00007eafdc3dd5c4  vmovaps xmm10, [rsp+0x90]
00007eafdc3dd5cd  vmovaps xmm11, [rsp+0xA0]
00007eafdc3dd5d6  vmovaps xmm12, [rsp+0xB0]
00007eafdc3dd5df  vmovaps xmm13, [rsp+0xC0]
00007eafdc3dd5e8  vmovaps xmm14, [rsp+0xD0]
00007eafdc3dd5f1  vmovaps xmm15, [rsp+0xE0]
00007eafdc3dd5fa  add rsp, 0xF0
00007eafdc3dd601  pop r11
00007eafdc3dd603  pop r10
00007eafdc3dd605  pop r9
00007eafdc3dd607  pop r8
00007eafdc3dd609  pop rsi
00007eafdc3dd60a  pop rdi
00007eafdc3dd60b  pop rdx
00007eafdc3dd60c  pop rcx
00007eafdc3dd60d  pop rax
00007eafdc3dd60e  add rsp, 0x08
00007eafdc3dd612  jmp 0x00007EAFDC3DBE1B
00007eafdc3dd617  call 0x00007EAFDC2C4620
00007eafdc3dd61c  jmp 0x00007EAFDC3DBE28
00007eafdc3dd621  sub rsp, 0x08
00007eafdc3dd625  push rax
00007eafdc3dd626  push rcx
00007eafdc3dd627  push rdx
00007eafdc3dd628  push rdi
00007eafdc3dd629  push rsi
00007eafdc3dd62a  push r8
00007eafdc3dd62c  push r9
00007eafdc3dd62e  push r10
00007eafdc3dd630  push r11
00007eafdc3dd632  sub rsp, 0xF0
00007eafdc3dd639  vmovaps [rsp], xmm0
00007eafdc3dd63e  vmovaps [rsp+0x10], xmm1
00007eafdc3dd644  vmovaps [rsp+0x20], xmm2
00007eafdc3dd64a  vmovaps [rsp+0x30], xmm3
00007eafdc3dd650  vmovaps [rsp+0x40], xmm4
00007eafdc3dd656  vmovaps [rsp+0x50], xmm5
00007eafdc3dd65c  vmovaps [rsp+0x60], xmm6
00007eafdc3dd662  vmovaps [rsp+0x70], xmm7
00007eafdc3dd668  vmovaps [rsp+0x80], xmm8
00007eafdc3dd671  vmovaps [rsp+0x90], xmm9
00007eafdc3dd67a  vmovaps [rsp+0xA0], xmm10
00007eafdc3dd683  vmovaps [rsp+0xB0], xmm11
00007eafdc3dd68c  vmovaps [rsp+0xC0], xmm12
00007eafdc3dd695  vmovaps [rsp+0xD0], xmm13
00007eafdc3dd69e  vmovaps [rsp+0xE0], xmm15
00007eafdc3dd6a7  sub rsp, 0x30
00007eafdc3dd6ab  movaps [rsp], xmm14
00007eafdc3dd6b0  movaps [rsp+0x10], xmm4
00007eafdc3dd6b5  movaps [rsp+0x20], xmm3
00007eafdc3dd6ba  lea rdi, [rsp]
00007eafdc3dd6be  mov esi, 0x00
00007eafdc3dd6c3  mov rax, 0x645891675530
00007eafdc3dd6cd  call rax
00007eafdc3dd6cf  movaps xmm14, [rsp]
00007eafdc3dd6d4  add rsp, 0x30
00007eafdc3dd6d8  vmovaps xmm0, [rsp]
00007eafdc3dd6dd  vmovaps xmm1, [rsp+0x10]
00007eafdc3dd6e3  vmovaps xmm2, [rsp+0x20]
00007eafdc3dd6e9  vmovaps xmm3, [rsp+0x30]
00007eafdc3dd6ef  vmovaps xmm4, [rsp+0x40]
00007eafdc3dd6f5  vmovaps xmm5, [rsp+0x50]
00007eafdc3dd6fb  vmovaps xmm6, [rsp+0x60]
00007eafdc3dd701  vmovaps xmm7, [rsp+0x70]
00007eafdc3dd707  vmovaps xmm8, [rsp+0x80]
00007eafdc3dd710  vmovaps xmm9, [rsp+0x90]
00007eafdc3dd719  vmovaps xmm10, [rsp+0xA0]
00007eafdc3dd722  vmovaps xmm11, [rsp+0xB0]
00007eafdc3dd72b  vmovaps xmm12, [rsp+0xC0]
00007eafdc3dd734  vmovaps xmm13, [rsp+0xD0]
00007eafdc3dd73d  vmovaps xmm15, [rsp+0xE0]
00007eafdc3dd746  add rsp, 0xF0
00007eafdc3dd74d  pop r11
00007eafdc3dd74f  pop r10
00007eafdc3dd751  pop r9
00007eafdc3dd753  pop r8
00007eafdc3dd755  pop rsi
00007eafdc3dd756  pop rdi
00007eafdc3dd757  pop rdx
00007eafdc3dd758  pop rcx
00007eafdc3dd759  pop rax
00007eafdc3dd75a  add rsp, 0x08
00007eafdc3dd75e  jmp 0x00007EAFDC3DBE42
00007eafdc3dd763  sub rsp, 0x08
00007eafdc3dd767  push rax
00007eafdc3dd768  push rcx
00007eafdc3dd769  push rdx
00007eafdc3dd76a  push rdi
00007eafdc3dd76b  push rsi
00007eafdc3dd76c  push r8
00007eafdc3dd76e  push r9
00007eafdc3dd770  push r10
00007eafdc3dd772  push r11
00007eafdc3dd774  sub rsp, 0xF0
00007eafdc3dd77b  vmovaps [rsp], xmm0
00007eafdc3dd780  vmovaps [rsp+0x10], xmm1
00007eafdc3dd786  vmovaps [rsp+0x20], xmm2
00007eafdc3dd78c  vmovaps [rsp+0x30], xmm3
00007eafdc3dd792  vmovaps [rsp+0x40], xmm4
00007eafdc3dd798  vmovaps [rsp+0x50], xmm5
00007eafdc3dd79e  vmovaps [rsp+0x60], xmm7
00007eafdc3dd7a4  vmovaps [rsp+0x70], xmm8
00007eafdc3dd7aa  vmovaps [rsp+0x80], xmm9
00007eafdc3dd7b3  vmovaps [rsp+0x90], xmm10
00007eafdc3dd7bc  vmovaps [rsp+0xA0], xmm11
00007eafdc3dd7c5  vmovaps [rsp+0xB0], xmm12
00007eafdc3dd7ce  vmovaps [rsp+0xC0], xmm13
00007eafdc3dd7d7  vmovaps [rsp+0xD0], xmm14
00007eafdc3dd7e0  vmovaps [rsp+0xE0], xmm15
00007eafdc3dd7e9  sub rsp, 0x30
00007eafdc3dd7ed  movaps [rsp], xmm6
00007eafdc3dd7f1  movaps [rsp+0x10], xmm9
00007eafdc3dd7f7  movaps [rsp+0x20], xmm7
00007eafdc3dd7fc  lea rdi, [rsp]
00007eafdc3dd800  mov esi, 0x00
00007eafdc3dd805  mov rax, 0x645891675530
00007eafdc3dd80f  call rax
00007eafdc3dd811  movaps xmm6, [rsp]
00007eafdc3dd815  add rsp, 0x30
00007eafdc3dd819  vmovaps xmm0, [rsp]
00007eafdc3dd81e  vmovaps xmm1, [rsp+0x10]
00007eafdc3dd824  vmovaps xmm2, [rsp+0x20]
00007eafdc3dd82a  vmovaps xmm3, [rsp+0x30]
00007eafdc3dd830  vmovaps xmm4, [rsp+0x40]
00007eafdc3dd836  vmovaps xmm5, [rsp+0x50]
00007eafdc3dd83c  vmovaps xmm7, [rsp+0x60]
00007eafdc3dd842  vmovaps xmm8, [rsp+0x70]
00007eafdc3dd848  vmovaps xmm9, [rsp+0x80]
00007eafdc3dd851  vmovaps xmm10, [rsp+0x90]
00007eafdc3dd85a  vmovaps xmm11, [rsp+0xA0]
00007eafdc3dd863  vmovaps xmm12, [rsp+0xB0]
00007eafdc3dd86c  vmovaps xmm13, [rsp+0xC0]
00007eafdc3dd875  vmovaps xmm14, [rsp+0xD0]
00007eafdc3dd87e  vmovaps xmm15, [rsp+0xE0]
00007eafdc3dd887  add rsp, 0xF0
00007eafdc3dd88e  pop r11
00007eafdc3dd890  pop r10
00007eafdc3dd892  pop r9
00007eafdc3dd894  pop r8
00007eafdc3dd896  pop rsi
00007eafdc3dd897  pop rdi
00007eafdc3dd898  pop rdx
00007eafdc3dd899  pop rcx
00007eafdc3dd89a  pop rax
00007eafdc3dd89b  add rsp, 0x08
00007eafdc3dd89f  jmp 0x00007EAFDC3DBE5A
00007eafdc3dd8a4  sub rsp, 0x08
00007eafdc3dd8a8  push rax
00007eafdc3dd8a9  push rcx
00007eafdc3dd8aa  push rdx
00007eafdc3dd8ab  push rdi
00007eafdc3dd8ac  push rsi
00007eafdc3dd8ad  push r8
00007eafdc3dd8af  push r9
00007eafdc3dd8b1  push r10
00007eafdc3dd8b3  push r11
00007eafdc3dd8b5  sub rsp, 0xF0
00007eafdc3dd8bc  vmovaps [rsp], xmm0
00007eafdc3dd8c1  vmovaps [rsp+0x10], xmm1
00007eafdc3dd8c7  vmovaps [rsp+0x20], xmm2
00007eafdc3dd8cd  vmovaps [rsp+0x30], xmm3
00007eafdc3dd8d3  vmovaps [rsp+0x40], xmm4
00007eafdc3dd8d9  vmovaps [rsp+0x50], xmm5
00007eafdc3dd8df  vmovaps [rsp+0x60], xmm6
00007eafdc3dd8e5  vmovaps [rsp+0x70], xmm8
00007eafdc3dd8eb  vmovaps [rsp+0x80], xmm9
00007eafdc3dd8f4  vmovaps [rsp+0x90], xmm10
00007eafdc3dd8fd  vmovaps [rsp+0xA0], xmm11
00007eafdc3dd906  vmovaps [rsp+0xB0], xmm12
00007eafdc3dd90f  vmovaps [rsp+0xC0], xmm13
00007eafdc3dd918  vmovaps [rsp+0xD0], xmm14
00007eafdc3dd921  vmovaps [rsp+0xE0], xmm15
00007eafdc3dd92a  sub rsp, 0x30
00007eafdc3dd92e  movaps [rsp], xmm7
00007eafdc3dd932  movaps [rsp+0x10], xmm4
00007eafdc3dd937  movaps [rsp+0x20], xmm9
00007eafdc3dd93d  lea rdi, [rsp]
00007eafdc3dd941  mov esi, 0x00
00007eafdc3dd946  mov rax, 0x645891675530
00007eafdc3dd950  call rax
00007eafdc3dd952  movaps xmm7, [rsp]
00007eafdc3dd956  add rsp, 0x30
00007eafdc3dd95a  vmovaps xmm0, [rsp]
00007eafdc3dd95f  vmovaps xmm1, [rsp+0x10]
00007eafdc3dd965  vmovaps xmm2, [rsp+0x20]
00007eafdc3dd96b  vmovaps xmm3, [rsp+0x30]
00007eafdc3dd971  vmovaps xmm4, [rsp+0x40]
00007eafdc3dd977  vmovaps xmm5, [rsp+0x50]
00007eafdc3dd97d  vmovaps xmm6, [rsp+0x60]
00007eafdc3dd983  vmovaps xmm8, [rsp+0x70]
00007eafdc3dd989  vmovaps xmm9, [rsp+0x80]
00007eafdc3dd992  vmovaps xmm10, [rsp+0x90]
00007eafdc3dd99b  vmovaps xmm11, [rsp+0xA0]
00007eafdc3dd9a4  vmovaps xmm12, [rsp+0xB0]
00007eafdc3dd9ad  vmovaps xmm13, [rsp+0xC0]
00007eafdc3dd9b6  vmovaps xmm14, [rsp+0xD0]
00007eafdc3dd9bf  vmovaps xmm15, [rsp+0xE0]
00007eafdc3dd9c8  add rsp, 0xF0
00007eafdc3dd9cf  pop r11
00007eafdc3dd9d1  pop r10
00007eafdc3dd9d3  pop r9
00007eafdc3dd9d5  pop r8
00007eafdc3dd9d7  pop rsi
00007eafdc3dd9d8  pop rdi
00007eafdc3dd9d9  pop rdx
00007eafdc3dd9da  pop rcx
00007eafdc3dd9db  pop rax
00007eafdc3dd9dc  add rsp, 0x08
00007eafdc3dd9e0  jmp 0x00007EAFDC3DBE87
00007eafdc3dd9e5  sub rsp, 0x08
00007eafdc3dd9e9  push rax
00007eafdc3dd9ea  push rcx
00007eafdc3dd9eb  push rdx
00007eafdc3dd9ec  push rdi
00007eafdc3dd9ed  push rsi
00007eafdc3dd9ee  push r8
00007eafdc3dd9f0  push r9
00007eafdc3dd9f2  push r10
00007eafdc3dd9f4  push r11
00007eafdc3dd9f6  sub rsp, 0xF0
00007eafdc3dd9fd  vmovaps [rsp], xmm0
00007eafdc3dda02  vmovaps [rsp+0x10], xmm1
00007eafdc3dda08  vmovaps [rsp+0x20], xmm2
00007eafdc3dda0e  vmovaps [rsp+0x30], xmm3
00007eafdc3dda14  vmovaps [rsp+0x40], xmm5
00007eafdc3dda1a  vmovaps [rsp+0x50], xmm6
00007eafdc3dda20  vmovaps [rsp+0x60], xmm7
00007eafdc3dda26  vmovaps [rsp+0x70], xmm8
00007eafdc3dda2c  vmovaps [rsp+0x80], xmm9
00007eafdc3dda35  vmovaps [rsp+0x90], xmm10
00007eafdc3dda3e  vmovaps [rsp+0xA0], xmm11
00007eafdc3dda47  vmovaps [rsp+0xB0], xmm12
00007eafdc3dda50  vmovaps [rsp+0xC0], xmm13
00007eafdc3dda59  vmovaps [rsp+0xD0], xmm14
00007eafdc3dda62  vmovaps [rsp+0xE0], xmm15
00007eafdc3dda6b  sub rsp, 0x30
00007eafdc3dda6f  movaps [rsp], xmm4
00007eafdc3dda73  movaps [rsp+0x10], xmm15
00007eafdc3dda79  movaps [rsp+0x20], xmm9
00007eafdc3dda7f  lea rdi, [rsp]
00007eafdc3dda83  mov esi, 0x00
00007eafdc3dda88  mov rax, 0x645891675530
00007eafdc3dda92  call rax
00007eafdc3dda94  movaps xmm4, [rsp]
00007eafdc3dda98  add rsp, 0x30
00007eafdc3dda9c  vmovaps xmm0, [rsp]
00007eafdc3ddaa1  vmovaps xmm1, [rsp+0x10]
00007eafdc3ddaa7  vmovaps xmm2, [rsp+0x20]
00007eafdc3ddaad  vmovaps xmm3, [rsp+0x30]
00007eafdc3ddab3  vmovaps xmm5, [rsp+0x40]
00007eafdc3ddab9  vmovaps xmm6, [rsp+0x50]
00007eafdc3ddabf  vmovaps xmm7, [rsp+0x60]
00007eafdc3ddac5  vmovaps xmm8, [rsp+0x70]
00007eafdc3ddacb  vmovaps xmm9, [rsp+0x80]
00007eafdc3ddad4  vmovaps xmm10, [rsp+0x90]
00007eafdc3ddadd  vmovaps xmm11, [rsp+0xA0]
00007eafdc3ddae6  vmovaps xmm12, [rsp+0xB0]
00007eafdc3ddaef  vmovaps xmm13, [rsp+0xC0]
00007eafdc3ddaf8  vmovaps xmm14, [rsp+0xD0]
00007eafdc3ddb01  vmovaps xmm15, [rsp+0xE0]
00007eafdc3ddb0a  add rsp, 0xF0
00007eafdc3ddb11  pop r11
00007eafdc3ddb13  pop r10
00007eafdc3ddb15  pop r9
00007eafdc3ddb17  pop r8
00007eafdc3ddb19  pop rsi
00007eafdc3ddb1a  pop rdi
00007eafdc3ddb1b  pop rdx
00007eafdc3ddb1c  pop rcx
00007eafdc3ddb1d  pop rax
00007eafdc3ddb1e  add rsp, 0x08
00007eafdc3ddb22  jmp 0x00007EAFDC3DBEAC
00007eafdc3ddb27  call 0x00007EAFDC2C4620
00007eafdc3ddb2c  jmp 0x00007EAFDC3DBEB9
00007eafdc3ddb31  sub rsp, 0x08
00007eafdc3ddb35  push rax
00007eafdc3ddb36  push rcx
00007eafdc3ddb37  push rdx
00007eafdc3ddb38  push rdi
00007eafdc3ddb39  push rsi
00007eafdc3ddb3a  push r8
00007eafdc3ddb3c  push r9
00007eafdc3ddb3e  push r10
00007eafdc3ddb40  push r11
00007eafdc3ddb42  sub rsp, 0xF0
00007eafdc3ddb49  vmovaps [rsp], xmm0
00007eafdc3ddb4e  vmovaps [rsp+0x10], xmm1
00007eafdc3ddb54  vmovaps [rsp+0x20], xmm2
00007eafdc3ddb5a  vmovaps [rsp+0x30], xmm4
00007eafdc3ddb60  vmovaps [rsp+0x40], xmm5
00007eafdc3ddb66  vmovaps [rsp+0x50], xmm6
00007eafdc3ddb6c  vmovaps [rsp+0x60], xmm7
00007eafdc3ddb72  vmovaps [rsp+0x70], xmm8
00007eafdc3ddb78  vmovaps [rsp+0x80], xmm9
00007eafdc3ddb81  vmovaps [rsp+0x90], xmm10
00007eafdc3ddb8a  vmovaps [rsp+0xA0], xmm11
00007eafdc3ddb93  vmovaps [rsp+0xB0], xmm12
00007eafdc3ddb9c  vmovaps [rsp+0xC0], xmm13
00007eafdc3ddba5  vmovaps [rsp+0xD0], xmm14
00007eafdc3ddbae  vmovaps [rsp+0xE0], xmm15
00007eafdc3ddbb7  sub rsp, 0x30
00007eafdc3ddbbb  movaps [rsp], xmm3
00007eafdc3ddbbf  movaps [rsp+0x10], xmm1
00007eafdc3ddbc4  movaps [rsp+0x20], xmm9
00007eafdc3ddbca  lea rdi, [rsp]
00007eafdc3ddbce  mov esi, 0x00
00007eafdc3ddbd3  mov rax, 0x645891675530
00007eafdc3ddbdd  call rax
00007eafdc3ddbdf  movaps xmm3, [rsp]
00007eafdc3ddbe3  add rsp, 0x30
00007eafdc3ddbe7  vmovaps xmm0, [rsp]
00007eafdc3ddbec  vmovaps xmm1, [rsp+0x10]
00007eafdc3ddbf2  vmovaps xmm2, [rsp+0x20]
00007eafdc3ddbf8  vmovaps xmm4, [rsp+0x30]
00007eafdc3ddbfe  vmovaps xmm5, [rsp+0x40]
00007eafdc3ddc04  vmovaps xmm6, [rsp+0x50]
00007eafdc3ddc0a  vmovaps xmm7, [rsp+0x60]
00007eafdc3ddc10  vmovaps xmm8, [rsp+0x70]
00007eafdc3ddc16  vmovaps xmm9, [rsp+0x80]
00007eafdc3ddc1f  vmovaps xmm10, [rsp+0x90]
00007eafdc3ddc28  vmovaps xmm11, [rsp+0xA0]
00007eafdc3ddc31  vmovaps xmm12, [rsp+0xB0]
00007eafdc3ddc3a  vmovaps xmm13, [rsp+0xC0]
00007eafdc3ddc43  vmovaps xmm14, [rsp+0xD0]
00007eafdc3ddc4c  vmovaps xmm15, [rsp+0xE0]
00007eafdc3ddc55  add rsp, 0xF0
00007eafdc3ddc5c  pop r11
00007eafdc3ddc5e  pop r10
00007eafdc3ddc60  pop r9
00007eafdc3ddc62  pop r8
00007eafdc3ddc64  pop rsi
00007eafdc3ddc65  pop rdi
00007eafdc3ddc66  pop rdx
00007eafdc3ddc67  pop rcx
00007eafdc3ddc68  pop rax
00007eafdc3ddc69  add rsp, 0x08
00007eafdc3ddc6d  jmp 0x00007EAFDC3DBEF6
00007eafdc3ddc72  sub rsp, 0x08
00007eafdc3ddc76  push rax
00007eafdc3ddc77  push rcx
00007eafdc3ddc78  push rdx
00007eafdc3ddc79  push rdi
00007eafdc3ddc7a  push rsi
00007eafdc3ddc7b  push r8
00007eafdc3ddc7d  push r9
00007eafdc3ddc7f  push r10
00007eafdc3ddc81  push r11
00007eafdc3ddc83  sub rsp, 0xF0
00007eafdc3ddc8a  vmovaps [rsp], xmm0
00007eafdc3ddc8f  vmovaps [rsp+0x10], xmm2
00007eafdc3ddc95  vmovaps [rsp+0x20], xmm3
00007eafdc3ddc9b  vmovaps [rsp+0x30], xmm4
00007eafdc3ddca1  vmovaps [rsp+0x40], xmm5
00007eafdc3ddca7  vmovaps [rsp+0x50], xmm6
00007eafdc3ddcad  vmovaps [rsp+0x60], xmm7
00007eafdc3ddcb3  vmovaps [rsp+0x70], xmm8
00007eafdc3ddcb9  vmovaps [rsp+0x80], xmm9
00007eafdc3ddcc2  vmovaps [rsp+0x90], xmm10
00007eafdc3ddccb  vmovaps [rsp+0xA0], xmm11
00007eafdc3ddcd4  vmovaps [rsp+0xB0], xmm12
00007eafdc3ddcdd  vmovaps [rsp+0xC0], xmm13
00007eafdc3ddce6  vmovaps [rsp+0xD0], xmm14
00007eafdc3ddcef  vmovaps [rsp+0xE0], xmm15
00007eafdc3ddcf8  sub rsp, 0x30
00007eafdc3ddcfc  movaps [rsp], xmm1
00007eafdc3ddd00  movaps [rsp+0x10], xmm15
00007eafdc3ddd06  movaps [rsp+0x20], xmm9
00007eafdc3ddd0c  lea rdi, [rsp]
00007eafdc3ddd10  mov esi, 0x00
00007eafdc3ddd15  mov rax, 0x645891675530
00007eafdc3ddd1f  call rax
00007eafdc3ddd21  movaps xmm1, [rsp]
00007eafdc3ddd25  add rsp, 0x30
00007eafdc3ddd29  vmovaps xmm0, [rsp]
00007eafdc3ddd2e  vmovaps xmm2, [rsp+0x10]
00007eafdc3ddd34  vmovaps xmm3, [rsp+0x20]
00007eafdc3ddd3a  vmovaps xmm4, [rsp+0x30]
00007eafdc3ddd40  vmovaps xmm5, [rsp+0x40]
00007eafdc3ddd46  vmovaps xmm6, [rsp+0x50]
00007eafdc3ddd4c  vmovaps xmm7, [rsp+0x60]
00007eafdc3ddd52  vmovaps xmm8, [rsp+0x70]
00007eafdc3ddd58  vmovaps xmm9, [rsp+0x80]
00007eafdc3ddd61  vmovaps xmm10, [rsp+0x90]
00007eafdc3ddd6a  vmovaps xmm11, [rsp+0xA0]
00007eafdc3ddd73  vmovaps xmm12, [rsp+0xB0]
00007eafdc3ddd7c  vmovaps xmm13, [rsp+0xC0]
00007eafdc3ddd85  vmovaps xmm14, [rsp+0xD0]
00007eafdc3ddd8e  vmovaps xmm15, [rsp+0xE0]
00007eafdc3ddd97  add rsp, 0xF0
00007eafdc3ddd9e  pop r11
00007eafdc3ddda0  pop r10
00007eafdc3ddda2  pop r9
00007eafdc3ddda4  pop r8
00007eafdc3ddda6  pop rsi
00007eafdc3ddda7  pop rdi
00007eafdc3ddda8  pop rdx
00007eafdc3ddda9  pop rcx
00007eafdc3dddaa  pop rax
00007eafdc3dddab  add rsp, 0x08
00007eafdc3dddaf  jmp 0x00007EAFDC3DBF7E
00007eafdc3dddb4  call 0x00007EAFDC2C4620
00007eafdc3dddb9  jmp 0x00007EAFDC3DBF8B
00007eafdc3dddbe  sub rsp, 0x08
00007eafdc3dddc2  push rax
00007eafdc3dddc3  push rcx
00007eafdc3dddc4  push rdx
00007eafdc3dddc5  push rdi
00007eafdc3dddc6  push rsi
00007eafdc3dddc7  push r8
00007eafdc3dddc9  push r9
00007eafdc3dddcb  push r10
00007eafdc3dddcd  push r11
00007eafdc3dddcf  sub rsp, 0xF0
00007eafdc3dddd6  vmovaps [rsp], xmm0
00007eafdc3ddddb  vmovaps [rsp+0x10], xmm2
00007eafdc3ddde1  vmovaps [rsp+0x20], xmm3
00007eafdc3ddde7  vmovaps [rsp+0x30], xmm4
00007eafdc3ddded  vmovaps [rsp+0x40], xmm5
00007eafdc3dddf3  vmovaps [rsp+0x50], xmm6
00007eafdc3dddf9  vmovaps [rsp+0x60], xmm7
00007eafdc3dddff  vmovaps [rsp+0x70], xmm8
00007eafdc3dde05  vmovaps [rsp+0x80], xmm9
00007eafdc3dde0e  vmovaps [rsp+0x90], xmm10
00007eafdc3dde17  vmovaps [rsp+0xA0], xmm11
00007eafdc3dde20  vmovaps [rsp+0xB0], xmm12
00007eafdc3dde29  vmovaps [rsp+0xC0], xmm13
00007eafdc3dde32  vmovaps [rsp+0xD0], xmm14
00007eafdc3dde3b  vmovaps [rsp+0xE0], xmm15
00007eafdc3dde44  sub rsp, 0x30
00007eafdc3dde48  movaps [rsp], xmm1
00007eafdc3dde4c  movaps [rsp+0x10], xmm5
00007eafdc3dde51  movaps [rsp+0x20], xmm7
00007eafdc3dde56  lea rdi, [rsp]
00007eafdc3dde5a  mov esi, 0x00
00007eafdc3dde5f  mov rax, 0x645891675530
00007eafdc3dde69  call rax
00007eafdc3dde6b  movaps xmm1, [rsp]
00007eafdc3dde6f  add rsp, 0x30
00007eafdc3dde73  vmovaps xmm0, [rsp]
00007eafdc3dde78  vmovaps xmm2, [rsp+0x10]
00007eafdc3dde7e  vmovaps xmm3, [rsp+0x20]
00007eafdc3dde84  vmovaps xmm4, [rsp+0x30]
00007eafdc3dde8a  vmovaps xmm5, [rsp+0x40]
00007eafdc3dde90  vmovaps xmm6, [rsp+0x50]
00007eafdc3dde96  vmovaps xmm7, [rsp+0x60]
00007eafdc3dde9c  vmovaps xmm8, [rsp+0x70]
00007eafdc3ddea2  vmovaps xmm9, [rsp+0x80]
00007eafdc3ddeab  vmovaps xmm10, [rsp+0x90]
00007eafdc3ddeb4  vmovaps xmm11, [rsp+0xA0]
00007eafdc3ddebd  vmovaps xmm12, [rsp+0xB0]
00007eafdc3ddec6  vmovaps xmm13, [rsp+0xC0]
00007eafdc3ddecf  vmovaps xmm14, [rsp+0xD0]
00007eafdc3dded8  vmovaps xmm15, [rsp+0xE0]
00007eafdc3ddee1  add rsp, 0xF0
00007eafdc3ddee8  pop r11
00007eafdc3ddeea  pop r10
00007eafdc3ddeec  pop r9
00007eafdc3ddeee  pop r8
00007eafdc3ddef0  pop rsi
00007eafdc3ddef1  pop rdi
00007eafdc3ddef2  pop rdx
00007eafdc3ddef3  pop rcx
00007eafdc3ddef4  pop rax
00007eafdc3ddef5  add rsp, 0x08
00007eafdc3ddef9  jmp 0x00007EAFDC3DC030
00007eafdc3ddefe  sub rsp, 0x08
00007eafdc3ddf02  push rax
00007eafdc3ddf03  push rcx
00007eafdc3ddf04  push rdx
00007eafdc3ddf05  push rdi
00007eafdc3ddf06  push rsi
00007eafdc3ddf07  push r8
00007eafdc3ddf09  push r9
00007eafdc3ddf0b  push r10
00007eafdc3ddf0d  push r11
00007eafdc3ddf0f  sub rsp, 0xF0
00007eafdc3ddf16  vmovaps [rsp], xmm0
00007eafdc3ddf1b  vmovaps [rsp+0x10], xmm1
00007eafdc3ddf21  vmovaps [rsp+0x20], xmm2
00007eafdc3ddf27  vmovaps [rsp+0x30], xmm3
00007eafdc3ddf2d  vmovaps [rsp+0x40], xmm4
00007eafdc3ddf33  vmovaps [rsp+0x50], xmm5
00007eafdc3ddf39  vmovaps [rsp+0x60], xmm6
00007eafdc3ddf3f  vmovaps [rsp+0x70], xmm8
00007eafdc3ddf45  vmovaps [rsp+0x80], xmm9
00007eafdc3ddf4e  vmovaps [rsp+0x90], xmm10
00007eafdc3ddf57  vmovaps [rsp+0xA0], xmm11
00007eafdc3ddf60  vmovaps [rsp+0xB0], xmm12
00007eafdc3ddf69  vmovaps [rsp+0xC0], xmm13
00007eafdc3ddf72  vmovaps [rsp+0xD0], xmm14
00007eafdc3ddf7b  vmovaps [rsp+0xE0], xmm15
00007eafdc3ddf84  sub rsp, 0x30
00007eafdc3ddf88  movaps [rsp], xmm7
00007eafdc3ddf8c  movaps [rsp+0x10], xmm5
00007eafdc3ddf91  movaps [rsp+0x20], xmm15
00007eafdc3ddf97  lea rdi, [rsp]
00007eafdc3ddf9b  mov esi, 0x00
00007eafdc3ddfa0  mov rax, 0x645891675530
00007eafdc3ddfaa  call rax
00007eafdc3ddfac  movaps xmm7, [rsp]
00007eafdc3ddfb0  add rsp, 0x30
00007eafdc3ddfb4  vmovaps xmm0, [rsp]
00007eafdc3ddfb9  vmovaps xmm1, [rsp+0x10]
00007eafdc3ddfbf  vmovaps xmm2, [rsp+0x20]
00007eafdc3ddfc5  vmovaps xmm3, [rsp+0x30]
00007eafdc3ddfcb  vmovaps xmm4, [rsp+0x40]
00007eafdc3ddfd1  vmovaps xmm5, [rsp+0x50]
00007eafdc3ddfd7  vmovaps xmm6, [rsp+0x60]
00007eafdc3ddfdd  vmovaps xmm8, [rsp+0x70]
00007eafdc3ddfe3  vmovaps xmm9, [rsp+0x80]
00007eafdc3ddfec  vmovaps xmm10, [rsp+0x90]
00007eafdc3ddff5  vmovaps xmm11, [rsp+0xA0]
00007eafdc3ddffe  vmovaps xmm12, [rsp+0xB0]
00007eafdc3de007  vmovaps xmm13, [rsp+0xC0]
00007eafdc3de010  vmovaps xmm14, [rsp+0xD0]
00007eafdc3de019  vmovaps xmm15, [rsp+0xE0]
00007eafdc3de022  add rsp, 0xF0
00007eafdc3de029  pop r11
00007eafdc3de02b  pop r10
00007eafdc3de02d  pop r9
00007eafdc3de02f  pop r8
00007eafdc3de031  pop rsi
00007eafdc3de032  pop rdi
00007eafdc3de033  pop rdx
00007eafdc3de034  pop rcx
00007eafdc3de035  pop rax
00007eafdc3de036  add rsp, 0x08
00007eafdc3de03a  jmp 0x00007EAFDC3DC066
00007eafdc3de03f  call 0x00007EAFDC2B52F0
00007eafdc3de044  jmp 0x00007EAFDC3DC073
00007eafdc3de049  sub rsp, 0x08
00007eafdc3de04d  push rax
00007eafdc3de04e  push rcx
00007eafdc3de04f  push rdx
00007eafdc3de050  push rdi
00007eafdc3de051  push rsi
00007eafdc3de052  push r8
00007eafdc3de054  push r9
00007eafdc3de056  push r10
00007eafdc3de058  push r11
00007eafdc3de05a  sub rsp, 0xF0
00007eafdc3de061  vmovaps [rsp], xmm0
00007eafdc3de066  vmovaps [rsp+0x10], xmm1
00007eafdc3de06c  vmovaps [rsp+0x20], xmm2
00007eafdc3de072  vmovaps [rsp+0x30], xmm3
00007eafdc3de078  vmovaps [rsp+0x40], xmm4
00007eafdc3de07e  vmovaps [rsp+0x50], xmm5
00007eafdc3de084  vmovaps [rsp+0x60], xmm6
00007eafdc3de08a  vmovaps [rsp+0x70], xmm7
00007eafdc3de090  vmovaps [rsp+0x80], xmm8
00007eafdc3de099  vmovaps [rsp+0x90], xmm9
00007eafdc3de0a2  vmovaps [rsp+0xA0], xmm10
00007eafdc3de0ab  vmovaps [rsp+0xB0], xmm11
00007eafdc3de0b4  vmovaps [rsp+0xC0], xmm12
00007eafdc3de0bd  vmovaps [rsp+0xD0], xmm13
00007eafdc3de0c6  vmovaps [rsp+0xE0], xmm14
00007eafdc3de0cf  sub rsp, 0x30
00007eafdc3de0d3  movaps [rsp], xmm15
00007eafdc3de0d8  movaps [rsp+0x10], xmm5
00007eafdc3de0dd  movaps [rsp+0x20], xmm3
00007eafdc3de0e2  lea rdi, [rsp]
00007eafdc3de0e6  mov esi, 0x00
00007eafdc3de0eb  mov rax, 0x645891675530
00007eafdc3de0f5  call rax
00007eafdc3de0f7  movaps xmm15, [rsp]
00007eafdc3de0fc  add rsp, 0x30
00007eafdc3de100  vmovaps xmm0, [rsp]
00007eafdc3de105  vmovaps xmm1, [rsp+0x10]
00007eafdc3de10b  vmovaps xmm2, [rsp+0x20]
00007eafdc3de111  vmovaps xmm3, [rsp+0x30]
00007eafdc3de117  vmovaps xmm4, [rsp+0x40]
00007eafdc3de11d  vmovaps xmm5, [rsp+0x50]
00007eafdc3de123  vmovaps xmm6, [rsp+0x60]
00007eafdc3de129  vmovaps xmm7, [rsp+0x70]
00007eafdc3de12f  vmovaps xmm8, [rsp+0x80]
00007eafdc3de138  vmovaps xmm9, [rsp+0x90]
00007eafdc3de141  vmovaps xmm10, [rsp+0xA0]
00007eafdc3de14a  vmovaps xmm11, [rsp+0xB0]
00007eafdc3de153  vmovaps xmm12, [rsp+0xC0]
00007eafdc3de15c  vmovaps xmm13, [rsp+0xD0]
00007eafdc3de165  vmovaps xmm14, [rsp+0xE0]
00007eafdc3de16e  add rsp, 0xF0
00007eafdc3de175  pop r11
00007eafdc3de177  pop r10
00007eafdc3de179  pop r9
00007eafdc3de17b  pop r8
00007eafdc3de17d  pop rsi
00007eafdc3de17e  pop rdi
00007eafdc3de17f  pop rdx
00007eafdc3de180  pop rcx
00007eafdc3de181  pop rax
00007eafdc3de182  add rsp, 0x08
00007eafdc3de186  jmp 0x00007EAFDC3DC099
00007eafdc3de18b  sub rsp, 0x08
00007eafdc3de18f  push rax
00007eafdc3de190  push rcx
00007eafdc3de191  push rdx
00007eafdc3de192  push rdi
00007eafdc3de193  push rsi
00007eafdc3de194  push r8
00007eafdc3de196  push r9
00007eafdc3de198  push r10
00007eafdc3de19a  push r11
00007eafdc3de19c  sub rsp, 0xF0
00007eafdc3de1a3  vmovaps [rsp], xmm0
00007eafdc3de1a8  vmovaps [rsp+0x10], xmm2
00007eafdc3de1ae  vmovaps [rsp+0x20], xmm3
00007eafdc3de1b4  vmovaps [rsp+0x30], xmm4
00007eafdc3de1ba  vmovaps [rsp+0x40], xmm5
00007eafdc3de1c0  vmovaps [rsp+0x50], xmm6
00007eafdc3de1c6  vmovaps [rsp+0x60], xmm7
00007eafdc3de1cc  vmovaps [rsp+0x70], xmm8
00007eafdc3de1d2  vmovaps [rsp+0x80], xmm9
00007eafdc3de1db  vmovaps [rsp+0x90], xmm10
00007eafdc3de1e4  vmovaps [rsp+0xA0], xmm11
00007eafdc3de1ed  vmovaps [rsp+0xB0], xmm12
00007eafdc3de1f6  vmovaps [rsp+0xC0], xmm13
00007eafdc3de1ff  vmovaps [rsp+0xD0], xmm14
00007eafdc3de208  vmovaps [rsp+0xE0], xmm15
00007eafdc3de211  sub rsp, 0x30
00007eafdc3de215  movaps [rsp], xmm1
00007eafdc3de219  movaps [rsp+0x10], xmm5
00007eafdc3de21e  movaps [rsp+0x20], xmm4
00007eafdc3de223  lea rdi, [rsp]
00007eafdc3de227  mov esi, 0x00
00007eafdc3de22c  mov rax, 0x645891675530
00007eafdc3de236  call rax
00007eafdc3de238  movaps xmm1, [rsp]
00007eafdc3de23c  add rsp, 0x30
00007eafdc3de240  vmovaps xmm0, [rsp]
00007eafdc3de245  vmovaps xmm2, [rsp+0x10]
00007eafdc3de24b  vmovaps xmm3, [rsp+0x20]
00007eafdc3de251  vmovaps xmm4, [rsp+0x30]
00007eafdc3de257  vmovaps xmm5, [rsp+0x40]
00007eafdc3de25d  vmovaps xmm6, [rsp+0x50]
00007eafdc3de263  vmovaps xmm7, [rsp+0x60]
00007eafdc3de269  vmovaps xmm8, [rsp+0x70]
00007eafdc3de26f  vmovaps xmm9, [rsp+0x80]
00007eafdc3de278  vmovaps xmm10, [rsp+0x90]
00007eafdc3de281  vmovaps xmm11, [rsp+0xA0]
00007eafdc3de28a  vmovaps xmm12, [rsp+0xB0]
00007eafdc3de293  vmovaps xmm13, [rsp+0xC0]
00007eafdc3de29c  vmovaps xmm14, [rsp+0xD0]
00007eafdc3de2a5  vmovaps xmm15, [rsp+0xE0]
00007eafdc3de2ae  add rsp, 0xF0
00007eafdc3de2b5  pop r11
00007eafdc3de2b7  pop r10
00007eafdc3de2b9  pop r9
00007eafdc3de2bb  pop r8
00007eafdc3de2bd  pop rsi
00007eafdc3de2be  pop rdi
00007eafdc3de2bf  pop rdx
00007eafdc3de2c0  pop rcx
00007eafdc3de2c1  pop rax
00007eafdc3de2c2  add rsp, 0x08
00007eafdc3de2c6  jmp 0x00007EAFDC3DC0B9
00007eafdc3de2cb  sub rsp, 0x08
00007eafdc3de2cf  push rax
00007eafdc3de2d0  push rcx
00007eafdc3de2d1  push rdx
00007eafdc3de2d2  push rdi
00007eafdc3de2d3  push rsi
00007eafdc3de2d4  push r8
00007eafdc3de2d6  push r9
00007eafdc3de2d8  push r10
00007eafdc3de2da  push r11
00007eafdc3de2dc  sub rsp, 0xF0
00007eafdc3de2e3  vmovaps [rsp], xmm0
00007eafdc3de2e8  vmovaps [rsp+0x10], xmm1
00007eafdc3de2ee  vmovaps [rsp+0x20], xmm2
00007eafdc3de2f4  vmovaps [rsp+0x30], xmm3
00007eafdc3de2fa  vmovaps [rsp+0x40], xmm5
00007eafdc3de300  vmovaps [rsp+0x50], xmm6
00007eafdc3de306  vmovaps [rsp+0x60], xmm7
00007eafdc3de30c  vmovaps [rsp+0x70], xmm8
00007eafdc3de312  vmovaps [rsp+0x80], xmm9
00007eafdc3de31b  vmovaps [rsp+0x90], xmm10
00007eafdc3de324  vmovaps [rsp+0xA0], xmm11
00007eafdc3de32d  vmovaps [rsp+0xB0], xmm12
00007eafdc3de336  vmovaps [rsp+0xC0], xmm13
00007eafdc3de33f  vmovaps [rsp+0xD0], xmm14
00007eafdc3de348  vmovaps [rsp+0xE0], xmm15
00007eafdc3de351  sub rsp, 0x30
00007eafdc3de355  movaps [rsp], xmm4
00007eafdc3de359  movaps [rsp+0x10], xmm3
00007eafdc3de35e  movaps [rsp+0x20], xmm5
00007eafdc3de363  lea rdi, [rsp]
00007eafdc3de367  mov esi, 0x00
00007eafdc3de36c  mov rax, 0x645891675530
00007eafdc3de376  call rax
00007eafdc3de378  movaps xmm4, [rsp]
00007eafdc3de37c  add rsp, 0x30
00007eafdc3de380  vmovaps xmm0, [rsp]
00007eafdc3de385  vmovaps xmm1, [rsp+0x10]
00007eafdc3de38b  vmovaps xmm2, [rsp+0x20]
00007eafdc3de391  vmovaps xmm3, [rsp+0x30]
00007eafdc3de397  vmovaps xmm5, [rsp+0x40]
00007eafdc3de39d  vmovaps xmm6, [rsp+0x50]
00007eafdc3de3a3  vmovaps xmm7, [rsp+0x60]
00007eafdc3de3a9  vmovaps xmm8, [rsp+0x70]
00007eafdc3de3af  vmovaps xmm9, [rsp+0x80]
00007eafdc3de3b8  vmovaps xmm10, [rsp+0x90]
00007eafdc3de3c1  vmovaps xmm11, [rsp+0xA0]
00007eafdc3de3ca  vmovaps xmm12, [rsp+0xB0]
00007eafdc3de3d3  vmovaps xmm13, [rsp+0xC0]
00007eafdc3de3dc  vmovaps xmm14, [rsp+0xD0]
00007eafdc3de3e5  vmovaps xmm15, [rsp+0xE0]
00007eafdc3de3ee  add rsp, 0xF0
00007eafdc3de3f5  pop r11
00007eafdc3de3f7  pop r10
00007eafdc3de3f9  pop r9
00007eafdc3de3fb  pop r8
00007eafdc3de3fd  pop rsi
00007eafdc3de3fe  pop rdi
00007eafdc3de3ff  pop rdx
00007eafdc3de400  pop rcx
00007eafdc3de401  pop rax
00007eafdc3de402  add rsp, 0x08
00007eafdc3de406  jmp 0x00007EAFDC3DC107
00007eafdc3de40b  call 0x00007EAFDC2B52F0
00007eafdc3de410  jmp 0x00007EAFDC3DC114
00007eafdc3de415  sub rsp, 0x08
00007eafdc3de419  push rax
00007eafdc3de41a  push rcx
00007eafdc3de41b  push rdx
00007eafdc3de41c  push rdi
00007eafdc3de41d  push rsi
00007eafdc3de41e  push r8
00007eafdc3de420  push r9
00007eafdc3de422  push r10
00007eafdc3de424  push r11
00007eafdc3de426  sub rsp, 0xF0
00007eafdc3de42d  vmovaps [rsp], xmm0
00007eafdc3de432  vmovaps [rsp+0x10], xmm1
00007eafdc3de438  vmovaps [rsp+0x20], xmm2
00007eafdc3de43e  vmovaps [rsp+0x30], xmm3
00007eafdc3de444  vmovaps [rsp+0x40], xmm4
00007eafdc3de44a  vmovaps [rsp+0x50], xmm6
00007eafdc3de450  vmovaps [rsp+0x60], xmm7
00007eafdc3de456  vmovaps [rsp+0x70], xmm8
00007eafdc3de45c  vmovaps [rsp+0x80], xmm9
00007eafdc3de465  vmovaps [rsp+0x90], xmm10
00007eafdc3de46e  vmovaps [rsp+0xA0], xmm11
00007eafdc3de477  vmovaps [rsp+0xB0], xmm12
00007eafdc3de480  vmovaps [rsp+0xC0], xmm13
00007eafdc3de489  vmovaps [rsp+0xD0], xmm14
00007eafdc3de492  vmovaps [rsp+0xE0], xmm15
00007eafdc3de49b  sub rsp, 0x30
00007eafdc3de49f  movaps [rsp], xmm5
00007eafdc3de4a3  movaps [rsp+0x10], xmm6
00007eafdc3de4a8  movaps [rsp+0x20], xmm3
00007eafdc3de4ad  lea rdi, [rsp]
00007eafdc3de4b1  mov esi, 0x00
00007eafdc3de4b6  mov rax, 0x645891675530
00007eafdc3de4c0  call rax
00007eafdc3de4c2  movaps xmm5, [rsp]
00007eafdc3de4c6  add rsp, 0x30
00007eafdc3de4ca  vmovaps xmm0, [rsp]
00007eafdc3de4cf  vmovaps xmm1, [rsp+0x10]
00007eafdc3de4d5  vmovaps xmm2, [rsp+0x20]
00007eafdc3de4db  vmovaps xmm3, [rsp+0x30]
00007eafdc3de4e1  vmovaps xmm4, [rsp+0x40]
00007eafdc3de4e7  vmovaps xmm6, [rsp+0x50]
00007eafdc3de4ed  vmovaps xmm7, [rsp+0x60]
00007eafdc3de4f3  vmovaps xmm8, [rsp+0x70]
00007eafdc3de4f9  vmovaps xmm9, [rsp+0x80]
00007eafdc3de502  vmovaps xmm10, [rsp+0x90]
00007eafdc3de50b  vmovaps xmm11, [rsp+0xA0]
00007eafdc3de514  vmovaps xmm12, [rsp+0xB0]
00007eafdc3de51d  vmovaps xmm13, [rsp+0xC0]
00007eafdc3de526  vmovaps xmm14, [rsp+0xD0]
00007eafdc3de52f  vmovaps xmm15, [rsp+0xE0]
00007eafdc3de538  add rsp, 0xF0
00007eafdc3de53f  pop r11
00007eafdc3de541  pop r10
00007eafdc3de543  pop r9
00007eafdc3de545  pop r8
00007eafdc3de547  pop rsi
00007eafdc3de548  pop rdi
00007eafdc3de549  pop rdx
00007eafdc3de54a  pop rcx
00007eafdc3de54b  pop rax
00007eafdc3de54c  add rsp, 0x08
00007eafdc3de550  jmp 0x00007EAFDC3DC13A
00007eafdc3de555  sub rsp, 0x08
00007eafdc3de559  push rax
00007eafdc3de55a  push rcx
00007eafdc3de55b  push rdx
00007eafdc3de55c  push rdi
00007eafdc3de55d  push rsi
00007eafdc3de55e  push r8
00007eafdc3de560  push r9
00007eafdc3de562  push r10
00007eafdc3de564  push r11
00007eafdc3de566  sub rsp, 0xF0
00007eafdc3de56d  vmovaps [rsp], xmm0
00007eafdc3de572  vmovaps [rsp+0x10], xmm1
00007eafdc3de578  vmovaps [rsp+0x20], xmm2
00007eafdc3de57e  vmovaps [rsp+0x30], xmm3
00007eafdc3de584  vmovaps [rsp+0x40], xmm4
00007eafdc3de58a  vmovaps [rsp+0x50], xmm5
00007eafdc3de590  vmovaps [rsp+0x60], xmm7
00007eafdc3de596  vmovaps [rsp+0x70], xmm8
00007eafdc3de59c  vmovaps [rsp+0x80], xmm9
00007eafdc3de5a5  vmovaps [rsp+0x90], xmm10
00007eafdc3de5ae  vmovaps [rsp+0xA0], xmm11
00007eafdc3de5b7  vmovaps [rsp+0xB0], xmm12
00007eafdc3de5c0  vmovaps [rsp+0xC0], xmm13
00007eafdc3de5c9  vmovaps [rsp+0xD0], xmm14
00007eafdc3de5d2  vmovaps [rsp+0xE0], xmm15
00007eafdc3de5db  sub rsp, 0x30
00007eafdc3de5df  movaps [rsp], xmm6
00007eafdc3de5e3  movaps [rsp+0x10], xmm9
00007eafdc3de5e9  movaps [rsp+0x20], xmm1
00007eafdc3de5ee  lea rdi, [rsp]
00007eafdc3de5f2  mov esi, 0x00
00007eafdc3de5f7  mov rax, 0x645891675530
00007eafdc3de601  call rax
00007eafdc3de603  movaps xmm6, [rsp]
00007eafdc3de607  add rsp, 0x30
00007eafdc3de60b  vmovaps xmm0, [rsp]
00007eafdc3de610  vmovaps xmm1, [rsp+0x10]
00007eafdc3de616  vmovaps xmm2, [rsp+0x20]
00007eafdc3de61c  vmovaps xmm3, [rsp+0x30]
00007eafdc3de622  vmovaps xmm4, [rsp+0x40]
00007eafdc3de628  vmovaps xmm5, [rsp+0x50]
00007eafdc3de62e  vmovaps xmm7, [rsp+0x60]
00007eafdc3de634  vmovaps xmm8, [rsp+0x70]
00007eafdc3de63a  vmovaps xmm9, [rsp+0x80]
00007eafdc3de643  vmovaps xmm10, [rsp+0x90]
00007eafdc3de64c  vmovaps xmm11, [rsp+0xA0]
00007eafdc3de655  vmovaps xmm12, [rsp+0xB0]
00007eafdc3de65e  vmovaps xmm13, [rsp+0xC0]
00007eafdc3de667  vmovaps xmm14, [rsp+0xD0]
00007eafdc3de670  vmovaps xmm15, [rsp+0xE0]
00007eafdc3de679  add rsp, 0xF0
00007eafdc3de680  pop r11
00007eafdc3de682  pop r10
00007eafdc3de684  pop r9
00007eafdc3de686  pop r8
00007eafdc3de688  pop rsi
00007eafdc3de689  pop rdi
00007eafdc3de68a  pop rdx
00007eafdc3de68b  pop rcx
00007eafdc3de68c  pop rax
00007eafdc3de68d  add rsp, 0x08
00007eafdc3de691  jmp 0x00007EAFDC3DC15E
00007eafdc3de696  sub rsp, 0x08
00007eafdc3de69a  push rax
00007eafdc3de69b  push rcx
00007eafdc3de69c  push rdx
00007eafdc3de69d  push rdi
00007eafdc3de69e  push rsi
00007eafdc3de69f  push r8
00007eafdc3de6a1  push r9
00007eafdc3de6a3  push r10
00007eafdc3de6a5  push r11
00007eafdc3de6a7  sub rsp, 0xF0
00007eafdc3de6ae  vmovaps [rsp], xmm0
00007eafdc3de6b3  vmovaps [rsp+0x10], xmm1
00007eafdc3de6b9  vmovaps [rsp+0x20], xmm2
00007eafdc3de6bf  vmovaps [rsp+0x30], xmm3
00007eafdc3de6c5  vmovaps [rsp+0x40], xmm4
00007eafdc3de6cb  vmovaps [rsp+0x50], xmm5
00007eafdc3de6d1  vmovaps [rsp+0x60], xmm6
00007eafdc3de6d7  vmovaps [rsp+0x70], xmm7
00007eafdc3de6dd  vmovaps [rsp+0x80], xmm8
00007eafdc3de6e6  vmovaps [rsp+0x90], xmm10
00007eafdc3de6ef  vmovaps [rsp+0xA0], xmm11
00007eafdc3de6f8  vmovaps [rsp+0xB0], xmm12
00007eafdc3de701  vmovaps [rsp+0xC0], xmm13
00007eafdc3de70a  vmovaps [rsp+0xD0], xmm14
00007eafdc3de713  vmovaps [rsp+0xE0], xmm15
00007eafdc3de71c  sub rsp, 0x30
00007eafdc3de720  movaps [rsp], xmm9
00007eafdc3de725  movaps [rsp+0x10], xmm3
00007eafdc3de72a  movaps [rsp+0x20], xmm1
00007eafdc3de72f  lea rdi, [rsp]
00007eafdc3de733  mov esi, 0x00
00007eafdc3de738  mov rax, 0x645891675530
00007eafdc3de742  call rax
00007eafdc3de744  movaps xmm9, [rsp]
00007eafdc3de749  add rsp, 0x30
00007eafdc3de74d  vmovaps xmm0, [rsp]
00007eafdc3de752  vmovaps xmm1, [rsp+0x10]
00007eafdc3de758  vmovaps xmm2, [rsp+0x20]
00007eafdc3de75e  vmovaps xmm3, [rsp+0x30]
00007eafdc3de764  vmovaps xmm4, [rsp+0x40]
00007eafdc3de76a  vmovaps xmm5, [rsp+0x50]
00007eafdc3de770  vmovaps xmm6, [rsp+0x60]
00007eafdc3de776  vmovaps xmm7, [rsp+0x70]
00007eafdc3de77c  vmovaps xmm8, [rsp+0x80]
00007eafdc3de785  vmovaps xmm10, [rsp+0x90]
00007eafdc3de78e  vmovaps xmm11, [rsp+0xA0]
00007eafdc3de797  vmovaps xmm12, [rsp+0xB0]
00007eafdc3de7a0  vmovaps xmm13, [rsp+0xC0]
00007eafdc3de7a9  vmovaps xmm14, [rsp+0xD0]
00007eafdc3de7b2  vmovaps xmm15, [rsp+0xE0]
00007eafdc3de7bb  add rsp, 0xF0
00007eafdc3de7c2  pop r11
00007eafdc3de7c4  pop r10
00007eafdc3de7c6  pop r9
00007eafdc3de7c8  pop r8
00007eafdc3de7ca  pop rsi
00007eafdc3de7cb  pop rdi
00007eafdc3de7cc  pop rdx
00007eafdc3de7cd  pop rcx
00007eafdc3de7ce  pop rax
00007eafdc3de7cf  add rsp, 0x08
00007eafdc3de7d3  jmp 0x00007EAFDC3DC1AA
00007eafdc3de7d8  call 0x00007EAFDC2B52F0
00007eafdc3de7dd  jmp 0x00007EAFDC3DC1B7
00007eafdc3de7e2  sub rsp, 0x08
00007eafdc3de7e6  push rax
00007eafdc3de7e7  push rcx
00007eafdc3de7e8  push rdx
00007eafdc3de7e9  push rdi
00007eafdc3de7ea  push rsi
00007eafdc3de7eb  push r8
00007eafdc3de7ed  push r9
00007eafdc3de7ef  push r10
00007eafdc3de7f1  push r11
00007eafdc3de7f3  sub rsp, 0xF0
00007eafdc3de7fa  vmovaps [rsp], xmm0
00007eafdc3de7ff  vmovaps [rsp+0x10], xmm1
00007eafdc3de805  vmovaps [rsp+0x20], xmm2
00007eafdc3de80b  vmovaps [rsp+0x30], xmm3
00007eafdc3de811  vmovaps [rsp+0x40], xmm4
00007eafdc3de817  vmovaps [rsp+0x50], xmm5
00007eafdc3de81d  vmovaps [rsp+0x60], xmm6
00007eafdc3de823  vmovaps [rsp+0x70], xmm7
00007eafdc3de829  vmovaps [rsp+0x80], xmm8
00007eafdc3de832  vmovaps [rsp+0x90], xmm9
00007eafdc3de83b  vmovaps [rsp+0xA0], xmm10
00007eafdc3de844  vmovaps [rsp+0xB0], xmm11
00007eafdc3de84d  vmovaps [rsp+0xC0], xmm12
00007eafdc3de856  vmovaps [rsp+0xD0], xmm13
00007eafdc3de85f  vmovaps [rsp+0xE0], xmm14
00007eafdc3de868  sub rsp, 0x30
00007eafdc3de86c  movaps [rsp], xmm15
00007eafdc3de871  movaps [rsp+0x10], xmm3
00007eafdc3de876  movaps [rsp+0x20], xmm7
00007eafdc3de87b  lea rdi, [rsp]
00007eafdc3de87f  mov esi, 0x00
00007eafdc3de884  mov rax, 0x645891675530
00007eafdc3de88e  call rax
00007eafdc3de890  movaps xmm15, [rsp]
00007eafdc3de895  add rsp, 0x30
00007eafdc3de899  vmovaps xmm0, [rsp]
00007eafdc3de89e  vmovaps xmm1, [rsp+0x10]
00007eafdc3de8a4  vmovaps xmm2, [rsp+0x20]
00007eafdc3de8aa  vmovaps xmm3, [rsp+0x30]
00007eafdc3de8b0  vmovaps xmm4, [rsp+0x40]
00007eafdc3de8b6  vmovaps xmm5, [rsp+0x50]
00007eafdc3de8bc  vmovaps xmm6, [rsp+0x60]
00007eafdc3de8c2  vmovaps xmm7, [rsp+0x70]
00007eafdc3de8c8  vmovaps xmm8, [rsp+0x80]
00007eafdc3de8d1  vmovaps xmm9, [rsp+0x90]
00007eafdc3de8da  vmovaps xmm10, [rsp+0xA0]
00007eafdc3de8e3  vmovaps xmm11, [rsp+0xB0]
00007eafdc3de8ec  vmovaps xmm12, [rsp+0xC0]
00007eafdc3de8f5  vmovaps xmm13, [rsp+0xD0]
00007eafdc3de8fe  vmovaps xmm14, [rsp+0xE0]
00007eafdc3de907  add rsp, 0xF0
00007eafdc3de90e  pop r11
00007eafdc3de910  pop r10
00007eafdc3de912  pop r9
00007eafdc3de914  pop r8
00007eafdc3de916  pop rsi
00007eafdc3de917  pop rdi
00007eafdc3de918  pop rdx
00007eafdc3de919  pop rcx
00007eafdc3de91a  pop rax
00007eafdc3de91b  add rsp, 0x08
00007eafdc3de91f  jmp 0x00007EAFDC3DC1E3
00007eafdc3de924  sub rsp, 0x08
00007eafdc3de928  push rax
00007eafdc3de929  push rcx
00007eafdc3de92a  push rdx
00007eafdc3de92b  push rdi
00007eafdc3de92c  push rsi
00007eafdc3de92d  push r8
00007eafdc3de92f  push r9
00007eafdc3de931  push r10
00007eafdc3de933  push r11
00007eafdc3de935  sub rsp, 0xF0
00007eafdc3de93c  vmovaps [rsp], xmm0
00007eafdc3de941  vmovaps [rsp+0x10], xmm1
00007eafdc3de947  vmovaps [rsp+0x20], xmm2
00007eafdc3de94d  vmovaps [rsp+0x30], xmm4
00007eafdc3de953  vmovaps [rsp+0x40], xmm5
00007eafdc3de959  vmovaps [rsp+0x50], xmm6
00007eafdc3de95f  vmovaps [rsp+0x60], xmm7
00007eafdc3de965  vmovaps [rsp+0x70], xmm8
00007eafdc3de96b  vmovaps [rsp+0x80], xmm9
00007eafdc3de974  vmovaps [rsp+0x90], xmm10
00007eafdc3de97d  vmovaps [rsp+0xA0], xmm11
00007eafdc3de986  vmovaps [rsp+0xB0], xmm12
00007eafdc3de98f  vmovaps [rsp+0xC0], xmm13
00007eafdc3de998  vmovaps [rsp+0xD0], xmm14
00007eafdc3de9a1  vmovaps [rsp+0xE0], xmm15
00007eafdc3de9aa  sub rsp, 0x30
00007eafdc3de9ae  movaps [rsp], xmm3
00007eafdc3de9b2  movaps [rsp+0x10], xmm1
00007eafdc3de9b7  movaps [rsp+0x20], xmm15
00007eafdc3de9bd  lea rdi, [rsp]
00007eafdc3de9c1  mov esi, 0x00
00007eafdc3de9c6  mov rax, 0x645891675530
00007eafdc3de9d0  call rax
00007eafdc3de9d2  movaps xmm3, [rsp]
00007eafdc3de9d6  add rsp, 0x30
00007eafdc3de9da  vmovaps xmm0, [rsp]
00007eafdc3de9df  vmovaps xmm1, [rsp+0x10]
00007eafdc3de9e5  vmovaps xmm2, [rsp+0x20]
00007eafdc3de9eb  vmovaps xmm4, [rsp+0x30]
00007eafdc3de9f1  vmovaps xmm5, [rsp+0x40]
00007eafdc3de9f7  vmovaps xmm6, [rsp+0x50]
00007eafdc3de9fd  vmovaps xmm7, [rsp+0x60]
00007eafdc3dea03  vmovaps xmm8, [rsp+0x70]
00007eafdc3dea09  vmovaps xmm9, [rsp+0x80]
00007eafdc3dea12  vmovaps xmm10, [rsp+0x90]
00007eafdc3dea1b  vmovaps xmm11, [rsp+0xA0]
00007eafdc3dea24  vmovaps xmm12, [rsp+0xB0]
00007eafdc3dea2d  vmovaps xmm13, [rsp+0xC0]
00007eafdc3dea36  vmovaps xmm14, [rsp+0xD0]
00007eafdc3dea3f  vmovaps xmm15, [rsp+0xE0]
00007eafdc3dea48  add rsp, 0xF0
00007eafdc3dea4f  pop r11
00007eafdc3dea51  pop r10
00007eafdc3dea53  pop r9
00007eafdc3dea55  pop r8
00007eafdc3dea57  pop rsi
00007eafdc3dea58  pop rdi
00007eafdc3dea59  pop rdx
00007eafdc3dea5a  pop rcx
00007eafdc3dea5b  pop rax
00007eafdc3dea5c  add rsp, 0x08
00007eafdc3dea60  jmp 0x00007EAFDC3DC272
00007eafdc3dea65  call 0x00007EAFDC2B52F0
00007eafdc3dea6a  jmp 0x00007EAFDC3DC27C
00007eafdc3dea6f  sub rsp, 0x08
00007eafdc3dea73  push rax
00007eafdc3dea74  push rcx
00007eafdc3dea75  push rdx
00007eafdc3dea76  push rdi
00007eafdc3dea77  push rsi
00007eafdc3dea78  push r8
00007eafdc3dea7a  push r9
00007eafdc3dea7c  push r10
00007eafdc3dea7e  push r11
00007eafdc3dea80  sub rsp, 0xF0
00007eafdc3dea87  vmovaps [rsp], xmm0
00007eafdc3dea8c  vmovaps [rsp+0x10], xmm1
00007eafdc3dea92  vmovaps [rsp+0x20], xmm2
00007eafdc3dea98  vmovaps [rsp+0x30], xmm3
00007eafdc3dea9e  vmovaps [rsp+0x40], xmm4
00007eafdc3deaa4  vmovaps [rsp+0x50], xmm5
00007eafdc3deaaa  vmovaps [rsp+0x60], xmm6
00007eafdc3deab0  vmovaps [rsp+0x70], xmm7
00007eafdc3deab6  vmovaps [rsp+0x80], xmm8
00007eafdc3deabf  vmovaps [rsp+0x90], xmm9
00007eafdc3deac8  vmovaps [rsp+0xA0], xmm10
00007eafdc3dead1  vmovaps [rsp+0xB0], xmm11
00007eafdc3deada  vmovaps [rsp+0xC0], xmm12
00007eafdc3deae3  vmovaps [rsp+0xD0], xmm13
00007eafdc3deaec  vmovaps [rsp+0xE0], xmm14
00007eafdc3deaf5  sub rsp, 0x30
00007eafdc3deaf9  movaps [rsp], xmm15
00007eafdc3deafe  movaps [rsp+0x10], xmm14
00007eafdc3deb04  movaps [rsp+0x20], xmm4
00007eafdc3deb09  lea rdi, [rsp]
00007eafdc3deb0d  mov esi, 0x00
00007eafdc3deb12  mov rax, 0x645891675530
00007eafdc3deb1c  call rax
00007eafdc3deb1e  movaps xmm15, [rsp]
00007eafdc3deb23  add rsp, 0x30
00007eafdc3deb27  vmovaps xmm0, [rsp]
00007eafdc3deb2c  vmovaps xmm1, [rsp+0x10]
00007eafdc3deb32  vmovaps xmm2, [rsp+0x20]
00007eafdc3deb38  vmovaps xmm3, [rsp+0x30]
00007eafdc3deb3e  vmovaps xmm4, [rsp+0x40]
00007eafdc3deb44  vmovaps xmm5, [rsp+0x50]
00007eafdc3deb4a  vmovaps xmm6, [rsp+0x60]
00007eafdc3deb50  vmovaps xmm7, [rsp+0x70]
00007eafdc3deb56  vmovaps xmm8, [rsp+0x80]
00007eafdc3deb5f  vmovaps xmm9, [rsp+0x90]
00007eafdc3deb68  vmovaps xmm10, [rsp+0xA0]
00007eafdc3deb71  vmovaps xmm11, [rsp+0xB0]
00007eafdc3deb7a  vmovaps xmm12, [rsp+0xC0]
00007eafdc3deb83  vmovaps xmm13, [rsp+0xD0]
00007eafdc3deb8c  vmovaps xmm14, [rsp+0xE0]
00007eafdc3deb95  add rsp, 0xF0
00007eafdc3deb9c  pop r11
00007eafdc3deb9e  pop r10
00007eafdc3deba0  pop r9
00007eafdc3deba2  pop r8
00007eafdc3deba4  pop rsi
00007eafdc3deba5  pop rdi
00007eafdc3deba6  pop rdx
00007eafdc3deba7  pop rcx
00007eafdc3deba8  pop rax
00007eafdc3deba9  add rsp, 0x08
00007eafdc3debad  jmp 0x00007EAFDC3DC2AA
00007eafdc3debb2  sub rsp, 0x08
00007eafdc3debb6  push rax
00007eafdc3debb7  push rcx
00007eafdc3debb8  push rdx
00007eafdc3debb9  push rdi
00007eafdc3debba  push rsi
00007eafdc3debbb  push r8
00007eafdc3debbd  push r9
00007eafdc3debbf  push r10
00007eafdc3debc1  push r11
00007eafdc3debc3  sub rsp, 0xF0
00007eafdc3debca  vmovaps [rsp], xmm0
00007eafdc3debcf  vmovaps [rsp+0x10], xmm1
00007eafdc3debd5  vmovaps [rsp+0x20], xmm2
00007eafdc3debdb  vmovaps [rsp+0x30], xmm3
00007eafdc3debe1  vmovaps [rsp+0x40], xmm4
00007eafdc3debe7  vmovaps [rsp+0x50], xmm5
00007eafdc3debed  vmovaps [rsp+0x60], xmm6
00007eafdc3debf3  vmovaps [rsp+0x70], xmm7
00007eafdc3debf9  vmovaps [rsp+0x80], xmm8
00007eafdc3dec02  vmovaps [rsp+0x90], xmm9
00007eafdc3dec0b  vmovaps [rsp+0xA0], xmm10
00007eafdc3dec14  vmovaps [rsp+0xB0], xmm11
00007eafdc3dec1d  vmovaps [rsp+0xC0], xmm12
00007eafdc3dec26  vmovaps [rsp+0xD0], xmm13
00007eafdc3dec2f  vmovaps [rsp+0xE0], xmm15
00007eafdc3dec38  sub rsp, 0x30
00007eafdc3dec3c  movaps [rsp], xmm14
00007eafdc3dec41  movaps [rsp+0x10], xmm2
00007eafdc3dec46  movaps [rsp+0x20], xmm1
00007eafdc3dec4b  lea rdi, [rsp]
00007eafdc3dec4f  mov esi, 0x00
00007eafdc3dec54  mov rax, 0x645891675530
00007eafdc3dec5e  call rax
00007eafdc3dec60  movaps xmm14, [rsp]
00007eafdc3dec65  add rsp, 0x30
00007eafdc3dec69  vmovaps xmm0, [rsp]
00007eafdc3dec6e  vmovaps xmm1, [rsp+0x10]
00007eafdc3dec74  vmovaps xmm2, [rsp+0x20]
00007eafdc3dec7a  vmovaps xmm3, [rsp+0x30]
00007eafdc3dec80  vmovaps xmm4, [rsp+0x40]
00007eafdc3dec86  vmovaps xmm5, [rsp+0x50]
00007eafdc3dec8c  vmovaps xmm6, [rsp+0x60]
00007eafdc3dec92  vmovaps xmm7, [rsp+0x70]
00007eafdc3dec98  vmovaps xmm8, [rsp+0x80]
00007eafdc3deca1  vmovaps xmm9, [rsp+0x90]
00007eafdc3decaa  vmovaps xmm10, [rsp+0xA0]
00007eafdc3decb3  vmovaps xmm11, [rsp+0xB0]
00007eafdc3decbc  vmovaps xmm12, [rsp+0xC0]
00007eafdc3decc5  vmovaps xmm13, [rsp+0xD0]
00007eafdc3decce  vmovaps xmm15, [rsp+0xE0]
00007eafdc3decd7  add rsp, 0xF0
00007eafdc3decde  pop r11
00007eafdc3dece0  pop r10
00007eafdc3dece2  pop r9
00007eafdc3dece4  pop r8
00007eafdc3dece6  pop rsi
00007eafdc3dece7  pop rdi
00007eafdc3dece8  pop rdx
00007eafdc3dece9  pop rcx
00007eafdc3decea  pop rax
00007eafdc3deceb  add rsp, 0x08
00007eafdc3decef  jmp 0x00007EAFDC3DC2D0
00007eafdc3decf4  sub rsp, 0x08
00007eafdc3decf8  push rax
00007eafdc3decf9  push rcx
00007eafdc3decfa  push rdx
00007eafdc3decfb  push rdi
00007eafdc3decfc  push rsi
00007eafdc3decfd  push r8
00007eafdc3decff  push r9
00007eafdc3ded01  push r10
00007eafdc3ded03  push r11
00007eafdc3ded05  sub rsp, 0xF0
00007eafdc3ded0c  vmovaps [rsp], xmm0
00007eafdc3ded11  vmovaps [rsp+0x10], xmm2
00007eafdc3ded17  vmovaps [rsp+0x20], xmm3
00007eafdc3ded1d  vmovaps [rsp+0x30], xmm4
00007eafdc3ded23  vmovaps [rsp+0x40], xmm5
00007eafdc3ded29  vmovaps [rsp+0x50], xmm6
00007eafdc3ded2f  vmovaps [rsp+0x60], xmm7
00007eafdc3ded35  vmovaps [rsp+0x70], xmm8
00007eafdc3ded3b  vmovaps [rsp+0x80], xmm9
00007eafdc3ded44  vmovaps [rsp+0x90], xmm10
00007eafdc3ded4d  vmovaps [rsp+0xA0], xmm11
00007eafdc3ded56  vmovaps [rsp+0xB0], xmm12
00007eafdc3ded5f  vmovaps [rsp+0xC0], xmm13
00007eafdc3ded68  vmovaps [rsp+0xD0], xmm14
00007eafdc3ded71  vmovaps [rsp+0xE0], xmm15
00007eafdc3ded7a  sub rsp, 0x30
00007eafdc3ded7e  movaps [rsp], xmm1
00007eafdc3ded82  movaps [rsp+0x10], xmm4
00007eafdc3ded87  movaps [rsp+0x20], xmm9
00007eafdc3ded8d  lea rdi, [rsp]
00007eafdc3ded91  mov esi, 0x00
00007eafdc3ded96  mov rax, 0x645891675530
00007eafdc3deda0  call rax
00007eafdc3deda2  movaps xmm1, [rsp]
00007eafdc3deda6  add rsp, 0x30
00007eafdc3dedaa  vmovaps xmm0, [rsp]
00007eafdc3dedaf  vmovaps xmm2, [rsp+0x10]
00007eafdc3dedb5  vmovaps xmm3, [rsp+0x20]
00007eafdc3dedbb  vmovaps xmm4, [rsp+0x30]
00007eafdc3dedc1  vmovaps xmm5, [rsp+0x40]
00007eafdc3dedc7  vmovaps xmm6, [rsp+0x50]
00007eafdc3dedcd  vmovaps xmm7, [rsp+0x60]
00007eafdc3dedd3  vmovaps xmm8, [rsp+0x70]
00007eafdc3dedd9  vmovaps xmm9, [rsp+0x80]
00007eafdc3dede2  vmovaps xmm10, [rsp+0x90]
00007eafdc3dedeb  vmovaps xmm11, [rsp+0xA0]
00007eafdc3dedf4  vmovaps xmm12, [rsp+0xB0]
00007eafdc3dedfd  vmovaps xmm13, [rsp+0xC0]
00007eafdc3dee06  vmovaps xmm14, [rsp+0xD0]
00007eafdc3dee0f  vmovaps xmm15, [rsp+0xE0]
00007eafdc3dee18  add rsp, 0xF0
00007eafdc3dee1f  pop r11
00007eafdc3dee21  pop r10
00007eafdc3dee23  pop r9
00007eafdc3dee25  pop r8
00007eafdc3dee27  pop rsi
00007eafdc3dee28  pop rdi
00007eafdc3dee29  pop rdx
00007eafdc3dee2a  pop rcx
00007eafdc3dee2b  pop rax
00007eafdc3dee2c  add rsp, 0x08
00007eafdc3dee30  jmp 0x00007EAFDC3DC2EE
00007eafdc3dee35  sub rsp, 0x08
00007eafdc3dee39  push rax
00007eafdc3dee3a  push rcx
00007eafdc3dee3b  push rdx
00007eafdc3dee3c  push rdi
00007eafdc3dee3d  push rsi
00007eafdc3dee3e  push r8
00007eafdc3dee40  push r9
00007eafdc3dee42  push r10
00007eafdc3dee44  push r11
00007eafdc3dee46  sub rsp, 0xF0
00007eafdc3dee4d  vmovaps [rsp], xmm0
00007eafdc3dee52  vmovaps [rsp+0x10], xmm1
00007eafdc3dee58  vmovaps [rsp+0x20], xmm2
00007eafdc3dee5e  vmovaps [rsp+0x30], xmm3
00007eafdc3dee64  vmovaps [rsp+0x40], xmm5
00007eafdc3dee6a  vmovaps [rsp+0x50], xmm6
00007eafdc3dee70  vmovaps [rsp+0x60], xmm7
00007eafdc3dee76  vmovaps [rsp+0x70], xmm8
00007eafdc3dee7c  vmovaps [rsp+0x80], xmm9
00007eafdc3dee85  vmovaps [rsp+0x90], xmm10
00007eafdc3dee8e  vmovaps [rsp+0xA0], xmm11
00007eafdc3dee97  vmovaps [rsp+0xB0], xmm12
00007eafdc3deea0  vmovaps [rsp+0xC0], xmm13
00007eafdc3deea9  vmovaps [rsp+0xD0], xmm14
00007eafdc3deeb2  vmovaps [rsp+0xE0], xmm15
00007eafdc3deebb  sub rsp, 0x30
00007eafdc3deebf  movaps [rsp], xmm4
00007eafdc3deec3  movaps [rsp+0x10], xmm2
00007eafdc3deec8  movaps [rsp+0x20], xmm9
00007eafdc3deece  lea rdi, [rsp]
00007eafdc3deed2  mov esi, 0x00
00007eafdc3deed7  mov rax, 0x645891675530
00007eafdc3deee1  call rax
00007eafdc3deee3  movaps xmm4, [rsp]
00007eafdc3deee7  add rsp, 0x30
00007eafdc3deeeb  vmovaps xmm0, [rsp]
00007eafdc3deef0  vmovaps xmm1, [rsp+0x10]
00007eafdc3deef6  vmovaps xmm2, [rsp+0x20]
00007eafdc3deefc  vmovaps xmm3, [rsp+0x30]
00007eafdc3def02  vmovaps xmm5, [rsp+0x40]
00007eafdc3def08  vmovaps xmm6, [rsp+0x50]
00007eafdc3def0e  vmovaps xmm7, [rsp+0x60]
00007eafdc3def14  vmovaps xmm8, [rsp+0x70]
00007eafdc3def1a  vmovaps xmm9, [rsp+0x80]
00007eafdc3def23  vmovaps xmm10, [rsp+0x90]
00007eafdc3def2c  vmovaps xmm11, [rsp+0xA0]
00007eafdc3def35  vmovaps xmm12, [rsp+0xB0]
00007eafdc3def3e  vmovaps xmm13, [rsp+0xC0]
00007eafdc3def47  vmovaps xmm14, [rsp+0xD0]
00007eafdc3def50  vmovaps xmm15, [rsp+0xE0]
00007eafdc3def59  add rsp, 0xF0
00007eafdc3def60  pop r11
00007eafdc3def62  pop r10
00007eafdc3def64  pop r9
00007eafdc3def66  pop r8
00007eafdc3def68  pop rsi
00007eafdc3def69  pop rdi
00007eafdc3def6a  pop rdx
00007eafdc3def6b  pop rcx
00007eafdc3def6c  pop rax
00007eafdc3def6d  add rsp, 0x08
00007eafdc3def71  jmp 0x00007EAFDC3DC31E
00007eafdc3def76  sub rsp, 0x08
00007eafdc3def7a  push rax
00007eafdc3def7b  push rcx
00007eafdc3def7c  push rdx
00007eafdc3def7d  push rdi
00007eafdc3def7e  push rsi
00007eafdc3def7f  push r8
00007eafdc3def81  push r9
00007eafdc3def83  push r10
00007eafdc3def85  push r11
00007eafdc3def87  sub rsp, 0xF0
00007eafdc3def8e  vmovaps [rsp], xmm0
00007eafdc3def93  vmovaps [rsp+0x10], xmm1
00007eafdc3def99  vmovaps [rsp+0x20], xmm2
00007eafdc3def9f  vmovaps [rsp+0x30], xmm3
00007eafdc3defa5  vmovaps [rsp+0x40], xmm4
00007eafdc3defab  vmovaps [rsp+0x50], xmm5
00007eafdc3defb1  vmovaps [rsp+0x60], xmm6
00007eafdc3defb7  vmovaps [rsp+0x70], xmm7
00007eafdc3defbd  vmovaps [rsp+0x80], xmm8
00007eafdc3defc6  vmovaps [rsp+0x90], xmm10
00007eafdc3defcf  vmovaps [rsp+0xA0], xmm11
00007eafdc3defd8  vmovaps [rsp+0xB0], xmm12
00007eafdc3defe1  vmovaps [rsp+0xC0], xmm13
00007eafdc3defea  vmovaps [rsp+0xD0], xmm14
00007eafdc3deff3  vmovaps [rsp+0xE0], xmm15
00007eafdc3deffc  sub rsp, 0x30
00007eafdc3df000  movaps [rsp], xmm9
00007eafdc3df005  movaps [rsp+0x10], xmm2
00007eafdc3df00a  movaps [rsp+0x20], xmm1
00007eafdc3df00f  lea rdi, [rsp]
00007eafdc3df013  mov esi, 0x00
00007eafdc3df018  mov rax, 0x645891675530
00007eafdc3df022  call rax
00007eafdc3df024  movaps xmm9, [rsp]
00007eafdc3df029  add rsp, 0x30
00007eafdc3df02d  vmovaps xmm0, [rsp]
00007eafdc3df032  vmovaps xmm1, [rsp+0x10]
00007eafdc3df038  vmovaps xmm2, [rsp+0x20]
00007eafdc3df03e  vmovaps xmm3, [rsp+0x30]
00007eafdc3df044  vmovaps xmm4, [rsp+0x40]
00007eafdc3df04a  vmovaps xmm5, [rsp+0x50]
00007eafdc3df050  vmovaps xmm6, [rsp+0x60]
00007eafdc3df056  vmovaps xmm7, [rsp+0x70]
00007eafdc3df05c  vmovaps xmm8, [rsp+0x80]
00007eafdc3df065  vmovaps xmm10, [rsp+0x90]
00007eafdc3df06e  vmovaps xmm11, [rsp+0xA0]
00007eafdc3df077  vmovaps xmm12, [rsp+0xB0]
00007eafdc3df080  vmovaps xmm13, [rsp+0xC0]
00007eafdc3df089  vmovaps xmm14, [rsp+0xD0]
00007eafdc3df092  vmovaps xmm15, [rsp+0xE0]
00007eafdc3df09b  add rsp, 0xF0
00007eafdc3df0a2  pop r11
00007eafdc3df0a4  pop r10
00007eafdc3df0a6  pop r9
00007eafdc3df0a8  pop r8
00007eafdc3df0aa  pop rsi
00007eafdc3df0ab  pop rdi
00007eafdc3df0ac  pop rdx
00007eafdc3df0ad  pop rcx
00007eafdc3df0ae  pop rax
00007eafdc3df0af  add rsp, 0x08
00007eafdc3df0b3  jmp 0x00007EAFDC3DC354
00007eafdc3df0b8  sub rsp, 0x08
00007eafdc3df0bc  push rax
00007eafdc3df0bd  push rcx
00007eafdc3df0be  push rdx
00007eafdc3df0bf  push rdi
00007eafdc3df0c0  push rsi
00007eafdc3df0c1  push r8
00007eafdc3df0c3  push r9
00007eafdc3df0c5  push r10
00007eafdc3df0c7  push r11
00007eafdc3df0c9  sub rsp, 0xF0
00007eafdc3df0d0  vmovaps [rsp], xmm0
00007eafdc3df0d5  vmovaps [rsp+0x10], xmm2
00007eafdc3df0db  vmovaps [rsp+0x20], xmm3
00007eafdc3df0e1  vmovaps [rsp+0x30], xmm4
00007eafdc3df0e7  vmovaps [rsp+0x40], xmm5
00007eafdc3df0ed  vmovaps [rsp+0x50], xmm6
00007eafdc3df0f3  vmovaps [rsp+0x60], xmm7
00007eafdc3df0f9  vmovaps [rsp+0x70], xmm8
00007eafdc3df0ff  vmovaps [rsp+0x80], xmm9
00007eafdc3df108  vmovaps [rsp+0x90], xmm10
00007eafdc3df111  vmovaps [rsp+0xA0], xmm11
00007eafdc3df11a  vmovaps [rsp+0xB0], xmm12
00007eafdc3df123  vmovaps [rsp+0xC0], xmm13
00007eafdc3df12c  vmovaps [rsp+0xD0], xmm14
00007eafdc3df135  vmovaps [rsp+0xE0], xmm15
00007eafdc3df13e  sub rsp, 0x30
00007eafdc3df142  movaps [rsp], xmm1
00007eafdc3df146  movaps [rsp+0x10], xmm15
00007eafdc3df14c  movaps [rsp+0x20], xmm6
00007eafdc3df151  lea rdi, [rsp]
00007eafdc3df155  mov esi, 0x00
00007eafdc3df15a  mov rax, 0x645891675530
00007eafdc3df164  call rax
00007eafdc3df166  movaps xmm1, [rsp]
00007eafdc3df16a  add rsp, 0x30
00007eafdc3df16e  vmovaps xmm0, [rsp]
00007eafdc3df173  vmovaps xmm2, [rsp+0x10]
00007eafdc3df179  vmovaps xmm3, [rsp+0x20]
00007eafdc3df17f  vmovaps xmm4, [rsp+0x30]
00007eafdc3df185  vmovaps xmm5, [rsp+0x40]
00007eafdc3df18b  vmovaps xmm6, [rsp+0x50]
00007eafdc3df191  vmovaps xmm7, [rsp+0x60]
00007eafdc3df197  vmovaps xmm8, [rsp+0x70]
00007eafdc3df19d  vmovaps xmm9, [rsp+0x80]
00007eafdc3df1a6  vmovaps xmm10, [rsp+0x90]
00007eafdc3df1af  vmovaps xmm11, [rsp+0xA0]
00007eafdc3df1b8  vmovaps xmm12, [rsp+0xB0]
00007eafdc3df1c1  vmovaps xmm13, [rsp+0xC0]
00007eafdc3df1ca  vmovaps xmm14, [rsp+0xD0]
00007eafdc3df1d3  vmovaps xmm15, [rsp+0xE0]
00007eafdc3df1dc  add rsp, 0xF0
00007eafdc3df1e3  pop r11
00007eafdc3df1e5  pop r10
00007eafdc3df1e7  pop r9
00007eafdc3df1e9  pop r8
00007eafdc3df1eb  pop rsi
00007eafdc3df1ec  pop rdi
00007eafdc3df1ed  pop rdx
00007eafdc3df1ee  pop rcx
00007eafdc3df1ef  pop rax
00007eafdc3df1f0  add rsp, 0x08
00007eafdc3df1f4  jmp 0x00007EAFDC3DC375
00007eafdc3df1f9  sub rsp, 0x08
00007eafdc3df1fd  push rax
00007eafdc3df1fe  push rcx
00007eafdc3df1ff  push rdx
00007eafdc3df200  push rdi
00007eafdc3df201  push rsi
00007eafdc3df202  push r8
00007eafdc3df204  push r9
00007eafdc3df206  push r10
00007eafdc3df208  push r11
00007eafdc3df20a  sub rsp, 0xF0
00007eafdc3df211  vmovaps [rsp], xmm0
00007eafdc3df216  vmovaps [rsp+0x10], xmm1
00007eafdc3df21c  vmovaps [rsp+0x20], xmm2
00007eafdc3df222  vmovaps [rsp+0x30], xmm3
00007eafdc3df228  vmovaps [rsp+0x40], xmm4
00007eafdc3df22e  vmovaps [rsp+0x50], xmm5
00007eafdc3df234  vmovaps [rsp+0x60], xmm6
00007eafdc3df23a  vmovaps [rsp+0x70], xmm7
00007eafdc3df240  vmovaps [rsp+0x80], xmm8
00007eafdc3df249  vmovaps [rsp+0x90], xmm9
00007eafdc3df252  vmovaps [rsp+0xA0], xmm10
00007eafdc3df25b  vmovaps [rsp+0xB0], xmm11
00007eafdc3df264  vmovaps [rsp+0xC0], xmm12
00007eafdc3df26d  vmovaps [rsp+0xD0], xmm13
00007eafdc3df276  vmovaps [rsp+0xE0], xmm14
00007eafdc3df27f  sub rsp, 0x30
00007eafdc3df283  movaps [rsp], xmm15
00007eafdc3df288  movaps [rsp+0x10], xmm5
00007eafdc3df28d  movaps [rsp+0x20], xmm3
00007eafdc3df292  lea rdi, [rsp]
00007eafdc3df296  mov esi, 0x00
00007eafdc3df29b  mov rax, 0x645891675530
00007eafdc3df2a5  call rax
00007eafdc3df2a7  movaps xmm15, [rsp]
00007eafdc3df2ac  add rsp, 0x30
00007eafdc3df2b0  vmovaps xmm0, [rsp]
00007eafdc3df2b5  vmovaps xmm1, [rsp+0x10]
00007eafdc3df2bb  vmovaps xmm2, [rsp+0x20]
00007eafdc3df2c1  vmovaps xmm3, [rsp+0x30]
00007eafdc3df2c7  vmovaps xmm4, [rsp+0x40]
00007eafdc3df2cd  vmovaps xmm5, [rsp+0x50]
00007eafdc3df2d3  vmovaps xmm6, [rsp+0x60]
00007eafdc3df2d9  vmovaps xmm7, [rsp+0x70]
00007eafdc3df2df  vmovaps xmm8, [rsp+0x80]
00007eafdc3df2e8  vmovaps xmm9, [rsp+0x90]
00007eafdc3df2f1  vmovaps xmm10, [rsp+0xA0]
00007eafdc3df2fa  vmovaps xmm11, [rsp+0xB0]
00007eafdc3df303  vmovaps xmm12, [rsp+0xC0]
00007eafdc3df30c  vmovaps xmm13, [rsp+0xD0]
00007eafdc3df315  vmovaps xmm14, [rsp+0xE0]
00007eafdc3df31e  add rsp, 0xF0
00007eafdc3df325  pop r11
00007eafdc3df327  pop r10
00007eafdc3df329  pop r9
00007eafdc3df32b  pop r8
00007eafdc3df32d  pop rsi
00007eafdc3df32e  pop rdi
00007eafdc3df32f  pop rdx
00007eafdc3df330  pop rcx
00007eafdc3df331  pop rax
00007eafdc3df332  add rsp, 0x08
00007eafdc3df336  jmp 0x00007EAFDC3DC38F
00007eafdc3df33b  sub rsp, 0x08
00007eafdc3df33f  push rax
00007eafdc3df340  push rcx
00007eafdc3df341  push rdx
00007eafdc3df342  push rdi
00007eafdc3df343  push rsi
00007eafdc3df344  push r8
00007eafdc3df346  push r9
00007eafdc3df348  push r10
00007eafdc3df34a  push r11
00007eafdc3df34c  sub rsp, 0xF0
00007eafdc3df353  vmovaps [rsp], xmm0
00007eafdc3df358  vmovaps [rsp+0x10], xmm1
00007eafdc3df35e  vmovaps [rsp+0x20], xmm2
00007eafdc3df364  vmovaps [rsp+0x30], xmm3
00007eafdc3df36a  vmovaps [rsp+0x40], xmm4
00007eafdc3df370  vmovaps [rsp+0x50], xmm6
00007eafdc3df376  vmovaps [rsp+0x60], xmm7
00007eafdc3df37c  vmovaps [rsp+0x70], xmm8
00007eafdc3df382  vmovaps [rsp+0x80], xmm9
00007eafdc3df38b  vmovaps [rsp+0x90], xmm10
00007eafdc3df394  vmovaps [rsp+0xA0], xmm11
00007eafdc3df39d  vmovaps [rsp+0xB0], xmm12
00007eafdc3df3a6  vmovaps [rsp+0xC0], xmm13
00007eafdc3df3af  vmovaps [rsp+0xD0], xmm14
00007eafdc3df3b8  vmovaps [rsp+0xE0], xmm15
00007eafdc3df3c1  sub rsp, 0x30
00007eafdc3df3c5  movaps [rsp], xmm5
00007eafdc3df3c9  movaps [rsp+0x10], xmm8
00007eafdc3df3cf  movaps [rsp+0x20], xmm6
00007eafdc3df3d4  lea rdi, [rsp]
00007eafdc3df3d8  mov esi, 0x00
00007eafdc3df3dd  mov rax, 0x645891675530
00007eafdc3df3e7  call rax
00007eafdc3df3e9  movaps xmm5, [rsp]
00007eafdc3df3ed  add rsp, 0x30
00007eafdc3df3f1  vmovaps xmm0, [rsp]
00007eafdc3df3f6  vmovaps xmm1, [rsp+0x10]
00007eafdc3df3fc  vmovaps xmm2, [rsp+0x20]
00007eafdc3df402  vmovaps xmm3, [rsp+0x30]
00007eafdc3df408  vmovaps xmm4, [rsp+0x40]
00007eafdc3df40e  vmovaps xmm6, [rsp+0x50]
00007eafdc3df414  vmovaps xmm7, [rsp+0x60]
00007eafdc3df41a  vmovaps xmm8, [rsp+0x70]
00007eafdc3df420  vmovaps xmm9, [rsp+0x80]
00007eafdc3df429  vmovaps xmm10, [rsp+0x90]
00007eafdc3df432  vmovaps xmm11, [rsp+0xA0]
00007eafdc3df43b  vmovaps xmm12, [rsp+0xB0]
00007eafdc3df444  vmovaps xmm13, [rsp+0xC0]
00007eafdc3df44d  vmovaps xmm14, [rsp+0xD0]
00007eafdc3df456  vmovaps xmm15, [rsp+0xE0]
00007eafdc3df45f  add rsp, 0xF0
00007eafdc3df466  pop r11
00007eafdc3df468  pop r10
00007eafdc3df46a  pop r9
00007eafdc3df46c  pop r8
00007eafdc3df46e  pop rsi
00007eafdc3df46f  pop rdi
00007eafdc3df470  pop rdx
00007eafdc3df471  pop rcx
00007eafdc3df472  pop rax
00007eafdc3df473  add rsp, 0x08
00007eafdc3df477  jmp 0x00007EAFDC3DC3B3
00007eafdc3df47c  sub rsp, 0x08
00007eafdc3df480  push rax
00007eafdc3df481  push rcx
00007eafdc3df482  push rdx
00007eafdc3df483  push rdi
00007eafdc3df484  push rsi
00007eafdc3df485  push r8
00007eafdc3df487  push r9
00007eafdc3df489  push r10
00007eafdc3df48b  push r11
00007eafdc3df48d  sub rsp, 0xF0
00007eafdc3df494  vmovaps [rsp], xmm0
00007eafdc3df499  vmovaps [rsp+0x10], xmm1
00007eafdc3df49f  vmovaps [rsp+0x20], xmm2
00007eafdc3df4a5  vmovaps [rsp+0x30], xmm3
00007eafdc3df4ab  vmovaps [rsp+0x40], xmm4
00007eafdc3df4b1  vmovaps [rsp+0x50], xmm5
00007eafdc3df4b7  vmovaps [rsp+0x60], xmm7
00007eafdc3df4bd  vmovaps [rsp+0x70], xmm8
00007eafdc3df4c3  vmovaps [rsp+0x80], xmm9
00007eafdc3df4cc  vmovaps [rsp+0x90], xmm10
00007eafdc3df4d5  vmovaps [rsp+0xA0], xmm11
00007eafdc3df4de  vmovaps [rsp+0xB0], xmm12
00007eafdc3df4e7  vmovaps [rsp+0xC0], xmm13
00007eafdc3df4f0  vmovaps [rsp+0xD0], xmm14
00007eafdc3df4f9  vmovaps [rsp+0xE0], xmm15
00007eafdc3df502  sub rsp, 0x30
00007eafdc3df506  movaps [rsp], xmm6
00007eafdc3df50a  movaps [rsp+0x10], xmm10
00007eafdc3df510  movaps [rsp+0x20], xmm8
00007eafdc3df516  lea rdi, [rsp]
00007eafdc3df51a  mov esi, 0x00
00007eafdc3df51f  mov rax, 0x645891675530
00007eafdc3df529  call rax
00007eafdc3df52b  movaps xmm6, [rsp]
00007eafdc3df52f  add rsp, 0x30
00007eafdc3df533  vmovaps xmm0, [rsp]
00007eafdc3df538  vmovaps xmm1, [rsp+0x10]
00007eafdc3df53e  vmovaps xmm2, [rsp+0x20]
00007eafdc3df544  vmovaps xmm3, [rsp+0x30]
00007eafdc3df54a  vmovaps xmm4, [rsp+0x40]
00007eafdc3df550  vmovaps xmm5, [rsp+0x50]
00007eafdc3df556  vmovaps xmm7, [rsp+0x60]
00007eafdc3df55c  vmovaps xmm8, [rsp+0x70]
00007eafdc3df562  vmovaps xmm9, [rsp+0x80]
00007eafdc3df56b  vmovaps xmm10, [rsp+0x90]
00007eafdc3df574  vmovaps xmm11, [rsp+0xA0]
00007eafdc3df57d  vmovaps xmm12, [rsp+0xB0]
00007eafdc3df586  vmovaps xmm13, [rsp+0xC0]
00007eafdc3df58f  vmovaps xmm14, [rsp+0xD0]
00007eafdc3df598  vmovaps xmm15, [rsp+0xE0]
00007eafdc3df5a1  add rsp, 0xF0
00007eafdc3df5a8  pop r11
00007eafdc3df5aa  pop r10
00007eafdc3df5ac  pop r9
00007eafdc3df5ae  pop r8
00007eafdc3df5b0  pop rsi
00007eafdc3df5b1  pop rdi
00007eafdc3df5b2  pop rdx
00007eafdc3df5b3  pop rcx
00007eafdc3df5b4  pop rax
00007eafdc3df5b5  add rsp, 0x08
00007eafdc3df5b9  jmp 0x00007EAFDC3DC3D8
00007eafdc3df5be  sub rsp, 0x08
00007eafdc3df5c2  push rax
00007eafdc3df5c3  push rcx
00007eafdc3df5c4  push rdx
00007eafdc3df5c5  push rdi
00007eafdc3df5c6  push rsi
00007eafdc3df5c7  push r8
00007eafdc3df5c9  push r9
00007eafdc3df5cb  push r10
00007eafdc3df5cd  push r11
00007eafdc3df5cf  sub rsp, 0xF0
00007eafdc3df5d6  vmovaps [rsp], xmm0
00007eafdc3df5db  vmovaps [rsp+0x10], xmm1
00007eafdc3df5e1  vmovaps [rsp+0x20], xmm2
00007eafdc3df5e7  vmovaps [rsp+0x30], xmm3
00007eafdc3df5ed  vmovaps [rsp+0x40], xmm4
00007eafdc3df5f3  vmovaps [rsp+0x50], xmm5
00007eafdc3df5f9  vmovaps [rsp+0x60], xmm6
00007eafdc3df5ff  vmovaps [rsp+0x70], xmm7
00007eafdc3df605  vmovaps [rsp+0x80], xmm8
00007eafdc3df60e  vmovaps [rsp+0x90], xmm9
00007eafdc3df617  vmovaps [rsp+0xA0], xmm11
00007eafdc3df620  vmovaps [rsp+0xB0], xmm12
00007eafdc3df629  vmovaps [rsp+0xC0], xmm13
00007eafdc3df632  vmovaps [rsp+0xD0], xmm14
00007eafdc3df63b  vmovaps [rsp+0xE0], xmm15
00007eafdc3df644  sub rsp, 0x30
00007eafdc3df648  movaps [rsp], xmm10
00007eafdc3df64d  movaps [rsp+0x10], xmm8
00007eafdc3df653  movaps [rsp+0x20], xmm14
00007eafdc3df659  lea rdi, [rsp]
00007eafdc3df65d  mov esi, 0x00
00007eafdc3df662  mov rax, 0x645891675530
00007eafdc3df66c  call rax
00007eafdc3df66e  movaps xmm10, [rsp]
00007eafdc3df673  add rsp, 0x30
00007eafdc3df677  vmovaps xmm0, [rsp]
00007eafdc3df67c  vmovaps xmm1, [rsp+0x10]
00007eafdc3df682  vmovaps xmm2, [rsp+0x20]
00007eafdc3df688  vmovaps xmm3, [rsp+0x30]
00007eafdc3df68e  vmovaps xmm4, [rsp+0x40]
00007eafdc3df694  vmovaps xmm5, [rsp+0x50]
00007eafdc3df69a  vmovaps xmm6, [rsp+0x60]
00007eafdc3df6a0  vmovaps xmm7, [rsp+0x70]
00007eafdc3df6a6  vmovaps xmm8, [rsp+0x80]
00007eafdc3df6af  vmovaps xmm9, [rsp+0x90]
00007eafdc3df6b8  vmovaps xmm11, [rsp+0xA0]
00007eafdc3df6c1  vmovaps xmm12, [rsp+0xB0]
00007eafdc3df6ca  vmovaps xmm13, [rsp+0xC0]
00007eafdc3df6d3  vmovaps xmm14, [rsp+0xD0]
00007eafdc3df6dc  vmovaps xmm15, [rsp+0xE0]
00007eafdc3df6e5  add rsp, 0xF0
00007eafdc3df6ec  pop r11
00007eafdc3df6ee  pop r10
00007eafdc3df6f0  pop r9
00007eafdc3df6f2  pop r8
00007eafdc3df6f4  pop rsi
00007eafdc3df6f5  pop rdi
00007eafdc3df6f6  pop rdx
00007eafdc3df6f7  pop rcx
00007eafdc3df6f8  pop rax
00007eafdc3df6f9  add rsp, 0x08
00007eafdc3df6fd  jmp 0x00007EAFDC3DC3F8
00007eafdc3df702  sub rsp, 0x08
00007eafdc3df706  push rax
00007eafdc3df707  push rcx
00007eafdc3df708  push rdx
00007eafdc3df709  push rdi
00007eafdc3df70a  push rsi
00007eafdc3df70b  push r8
00007eafdc3df70d  push r9
00007eafdc3df70f  push r10
00007eafdc3df711  push r11
00007eafdc3df713  sub rsp, 0xF0
00007eafdc3df71a  vmovaps [rsp], xmm0
00007eafdc3df71f  vmovaps [rsp+0x10], xmm1
00007eafdc3df725  vmovaps [rsp+0x20], xmm2
00007eafdc3df72b  vmovaps [rsp+0x30], xmm3
00007eafdc3df731  vmovaps [rsp+0x40], xmm4
00007eafdc3df737  vmovaps [rsp+0x50], xmm5
00007eafdc3df73d  vmovaps [rsp+0x60], xmm6
00007eafdc3df743  vmovaps [rsp+0x70], xmm7
00007eafdc3df749  vmovaps [rsp+0x80], xmm8
00007eafdc3df752  vmovaps [rsp+0x90], xmm9
00007eafdc3df75b  vmovaps [rsp+0xA0], xmm10
00007eafdc3df764  vmovaps [rsp+0xB0], xmm11
00007eafdc3df76d  vmovaps [rsp+0xC0], xmm12
00007eafdc3df776  vmovaps [rsp+0xD0], xmm13
00007eafdc3df77f  vmovaps [rsp+0xE0], xmm15
00007eafdc3df788  sub rsp, 0x30
00007eafdc3df78c  movaps [rsp], xmm14
00007eafdc3df791  movaps [rsp+0x10], xmm8
00007eafdc3df797  movaps [rsp+0x20], xmm4
00007eafdc3df79c  lea rdi, [rsp]
00007eafdc3df7a0  mov esi, 0x00
00007eafdc3df7a5  mov rax, 0x645891675530
00007eafdc3df7af  call rax
00007eafdc3df7b1  movaps xmm14, [rsp]
00007eafdc3df7b6  add rsp, 0x30
00007eafdc3df7ba  vmovaps xmm0, [rsp]
00007eafdc3df7bf  vmovaps xmm1, [rsp+0x10]
00007eafdc3df7c5  vmovaps xmm2, [rsp+0x20]
00007eafdc3df7cb  vmovaps xmm3, [rsp+0x30]
00007eafdc3df7d1  vmovaps xmm4, [rsp+0x40]
00007eafdc3df7d7  vmovaps xmm5, [rsp+0x50]
00007eafdc3df7dd  vmovaps xmm6, [rsp+0x60]
00007eafdc3df7e3  vmovaps xmm7, [rsp+0x70]
00007eafdc3df7e9  vmovaps xmm8, [rsp+0x80]
00007eafdc3df7f2  vmovaps xmm9, [rsp+0x90]
00007eafdc3df7fb  vmovaps xmm10, [rsp+0xA0]
00007eafdc3df804  vmovaps xmm11, [rsp+0xB0]
00007eafdc3df80d  vmovaps xmm12, [rsp+0xC0]
00007eafdc3df816  vmovaps xmm13, [rsp+0xD0]
00007eafdc3df81f  vmovaps xmm15, [rsp+0xE0]
00007eafdc3df828  add rsp, 0xF0
00007eafdc3df82f  pop r11
00007eafdc3df831  pop r10
00007eafdc3df833  pop r9
00007eafdc3df835  pop r8
00007eafdc3df837  pop rsi
00007eafdc3df838  pop rdi
00007eafdc3df839  pop rdx
00007eafdc3df83a  pop rcx
00007eafdc3df83b  pop rax
00007eafdc3df83c  add rsp, 0x08
00007eafdc3df840  jmp 0x00007EAFDC3DC418
00007eafdc3df845  sub rsp, 0x08
00007eafdc3df849  push rax
00007eafdc3df84a  push rcx
00007eafdc3df84b  push rdx
00007eafdc3df84c  push rdi
00007eafdc3df84d  push rsi
00007eafdc3df84e  push r8
00007eafdc3df850  push r9
00007eafdc3df852  push r10
00007eafdc3df854  push r11
00007eafdc3df856  sub rsp, 0xF0
00007eafdc3df85d  vmovaps [rsp], xmm0
00007eafdc3df862  vmovaps [rsp+0x10], xmm1
00007eafdc3df868  vmovaps [rsp+0x20], xmm2
00007eafdc3df86e  vmovaps [rsp+0x30], xmm3
00007eafdc3df874  vmovaps [rsp+0x40], xmm5
00007eafdc3df87a  vmovaps [rsp+0x50], xmm6
00007eafdc3df880  vmovaps [rsp+0x60], xmm7
00007eafdc3df886  vmovaps [rsp+0x70], xmm8
00007eafdc3df88c  vmovaps [rsp+0x80], xmm9
00007eafdc3df895  vmovaps [rsp+0x90], xmm10
00007eafdc3df89e  vmovaps [rsp+0xA0], xmm11
00007eafdc3df8a7  vmovaps [rsp+0xB0], xmm12
00007eafdc3df8b0  vmovaps [rsp+0xC0], xmm13
00007eafdc3df8b9  vmovaps [rsp+0xD0], xmm14
00007eafdc3df8c2  vmovaps [rsp+0xE0], xmm15
00007eafdc3df8cb  sub rsp, 0x30
00007eafdc3df8cf  movaps [rsp], xmm4
00007eafdc3df8d3  movaps [rsp+0x10], xmm13
00007eafdc3df8d9  movaps [rsp+0x20], xmm8
00007eafdc3df8df  lea rdi, [rsp]
00007eafdc3df8e3  mov esi, 0x00
00007eafdc3df8e8  mov rax, 0x645891675530
00007eafdc3df8f2  call rax
00007eafdc3df8f4  movaps xmm4, [rsp]
00007eafdc3df8f8  add rsp, 0x30
00007eafdc3df8fc  vmovaps xmm0, [rsp]
00007eafdc3df901  vmovaps xmm1, [rsp+0x10]
00007eafdc3df907  vmovaps xmm2, [rsp+0x20]
00007eafdc3df90d  vmovaps xmm3, [rsp+0x30]
00007eafdc3df913  vmovaps xmm5, [rsp+0x40]
00007eafdc3df919  vmovaps xmm6, [rsp+0x50]
00007eafdc3df91f  vmovaps xmm7, [rsp+0x60]
00007eafdc3df925  vmovaps xmm8, [rsp+0x70]
00007eafdc3df92b  vmovaps xmm9, [rsp+0x80]
00007eafdc3df934  vmovaps xmm10, [rsp+0x90]
00007eafdc3df93d  vmovaps xmm11, [rsp+0xA0]
00007eafdc3df946  vmovaps xmm12, [rsp+0xB0]
00007eafdc3df94f  vmovaps xmm13, [rsp+0xC0]
00007eafdc3df958  vmovaps xmm14, [rsp+0xD0]
00007eafdc3df961  vmovaps xmm15, [rsp+0xE0]
00007eafdc3df96a  add rsp, 0xF0
00007eafdc3df971  pop r11
00007eafdc3df973  pop r10
00007eafdc3df975  pop r9
00007eafdc3df977  pop r8
00007eafdc3df979  pop rsi
00007eafdc3df97a  pop rdi
00007eafdc3df97b  pop rdx
00007eafdc3df97c  pop rcx
00007eafdc3df97d  pop rax
00007eafdc3df97e  add rsp, 0x08
00007eafdc3df982  jmp 0x00007EAFDC3DC43D
00007eafdc3df987  sub rsp, 0x08
00007eafdc3df98b  push rax
00007eafdc3df98c  push rcx
00007eafdc3df98d  push rdx
00007eafdc3df98e  push rdi
00007eafdc3df98f  push rsi
00007eafdc3df990  push r8
00007eafdc3df992  push r9
00007eafdc3df994  push r10
00007eafdc3df996  push r11
00007eafdc3df998  sub rsp, 0xF0
00007eafdc3df99f  vmovaps [rsp], xmm0
00007eafdc3df9a4  vmovaps [rsp+0x10], xmm1
00007eafdc3df9aa  vmovaps [rsp+0x20], xmm2
00007eafdc3df9b0  vmovaps [rsp+0x30], xmm3
00007eafdc3df9b6  vmovaps [rsp+0x40], xmm4
00007eafdc3df9bc  vmovaps [rsp+0x50], xmm5
00007eafdc3df9c2  vmovaps [rsp+0x60], xmm6
00007eafdc3df9c8  vmovaps [rsp+0x70], xmm7
00007eafdc3df9ce  vmovaps [rsp+0x80], xmm8
00007eafdc3df9d7  vmovaps [rsp+0x90], xmm9
00007eafdc3df9e0  vmovaps [rsp+0xA0], xmm10
00007eafdc3df9e9  vmovaps [rsp+0xB0], xmm11
00007eafdc3df9f2  vmovaps [rsp+0xC0], xmm12
00007eafdc3df9fb  vmovaps [rsp+0xD0], xmm14
00007eafdc3dfa04  vmovaps [rsp+0xE0], xmm15
00007eafdc3dfa0d  sub rsp, 0x30
00007eafdc3dfa11  movaps [rsp], xmm13
00007eafdc3dfa16  movaps [rsp+0x10], xmm15
00007eafdc3dfa1c  movaps [rsp+0x20], xmm9
00007eafdc3dfa22  lea rdi, [rsp]
00007eafdc3dfa26  mov esi, 0x00
00007eafdc3dfa2b  mov rax, 0x645891675530
00007eafdc3dfa35  call rax
00007eafdc3dfa37  movaps xmm13, [rsp]
00007eafdc3dfa3c  add rsp, 0x30
00007eafdc3dfa40  vmovaps xmm0, [rsp]
00007eafdc3dfa45  vmovaps xmm1, [rsp+0x10]
00007eafdc3dfa4b  vmovaps xmm2, [rsp+0x20]
00007eafdc3dfa51  vmovaps xmm3, [rsp+0x30]
00007eafdc3dfa57  vmovaps xmm4, [rsp+0x40]
00007eafdc3dfa5d  vmovaps xmm5, [rsp+0x50]
00007eafdc3dfa63  vmovaps xmm6, [rsp+0x60]
00007eafdc3dfa69  vmovaps xmm7, [rsp+0x70]
00007eafdc3dfa6f  vmovaps xmm8, [rsp+0x80]
00007eafdc3dfa78  vmovaps xmm9, [rsp+0x90]
00007eafdc3dfa81  vmovaps xmm10, [rsp+0xA0]
00007eafdc3dfa8a  vmovaps xmm11, [rsp+0xB0]
00007eafdc3dfa93  vmovaps xmm12, [rsp+0xC0]
00007eafdc3dfa9c  vmovaps xmm14, [rsp+0xD0]
00007eafdc3dfaa5  vmovaps xmm15, [rsp+0xE0]
00007eafdc3dfaae  add rsp, 0xF0
00007eafdc3dfab5  pop r11
00007eafdc3dfab7  pop r10
00007eafdc3dfab9  pop r9
00007eafdc3dfabb  pop r8
00007eafdc3dfabd  pop rsi
00007eafdc3dfabe  pop rdi
00007eafdc3dfabf  pop rdx
00007eafdc3dfac0  pop rcx
00007eafdc3dfac1  pop rax
00007eafdc3dfac2  add rsp, 0x08
00007eafdc3dfac6  jmp 0x00007EAFDC3DC458
00007eafdc3dfacb  sub rsp, 0x08
00007eafdc3dfacf  push rax
00007eafdc3dfad0  push rcx
00007eafdc3dfad1  push rdx
00007eafdc3dfad2  push rdi
00007eafdc3dfad3  push rsi
00007eafdc3dfad4  push r8
00007eafdc3dfad6  push r9
00007eafdc3dfad8  push r10
00007eafdc3dfada  push r11
00007eafdc3dfadc  sub rsp, 0xF0
00007eafdc3dfae3  vmovaps [rsp], xmm0
00007eafdc3dfae8  vmovaps [rsp+0x10], xmm1
00007eafdc3dfaee  vmovaps [rsp+0x20], xmm2
00007eafdc3dfaf4  vmovaps [rsp+0x30], xmm3
00007eafdc3dfafa  vmovaps [rsp+0x40], xmm4
00007eafdc3dfb00  vmovaps [rsp+0x50], xmm5
00007eafdc3dfb06  vmovaps [rsp+0x60], xmm6
00007eafdc3dfb0c  vmovaps [rsp+0x70], xmm7
00007eafdc3dfb12  vmovaps [rsp+0x80], xmm8
00007eafdc3dfb1b  vmovaps [rsp+0x90], xmm9
00007eafdc3dfb24  vmovaps [rsp+0xA0], xmm10
00007eafdc3dfb2d  vmovaps [rsp+0xB0], xmm11
00007eafdc3dfb36  vmovaps [rsp+0xC0], xmm12
00007eafdc3dfb3f  vmovaps [rsp+0xD0], xmm13
00007eafdc3dfb48  vmovaps [rsp+0xE0], xmm14
00007eafdc3dfb51  sub rsp, 0x30
00007eafdc3dfb55  movaps [rsp], xmm15
00007eafdc3dfb5a  movaps [rsp+0x10], xmm1
00007eafdc3dfb5f  movaps [rsp+0x20], xmm5
00007eafdc3dfb64  lea rdi, [rsp]
00007eafdc3dfb68  mov esi, 0x00
00007eafdc3dfb6d  mov rax, 0x645891675530
00007eafdc3dfb77  call rax
00007eafdc3dfb79  movaps xmm15, [rsp]
00007eafdc3dfb7e  add rsp, 0x30
00007eafdc3dfb82  vmovaps xmm0, [rsp]
00007eafdc3dfb87  vmovaps xmm1, [rsp+0x10]
00007eafdc3dfb8d  vmovaps xmm2, [rsp+0x20]
00007eafdc3dfb93  vmovaps xmm3, [rsp+0x30]
00007eafdc3dfb99  vmovaps xmm4, [rsp+0x40]
00007eafdc3dfb9f  vmovaps xmm5, [rsp+0x50]
00007eafdc3dfba5  vmovaps xmm6, [rsp+0x60]
00007eafdc3dfbab  vmovaps xmm7, [rsp+0x70]
00007eafdc3dfbb1  vmovaps xmm8, [rsp+0x80]
00007eafdc3dfbba  vmovaps xmm9, [rsp+0x90]
00007eafdc3dfbc3  vmovaps xmm10, [rsp+0xA0]
00007eafdc3dfbcc  vmovaps xmm11, [rsp+0xB0]
00007eafdc3dfbd5  vmovaps xmm12, [rsp+0xC0]
00007eafdc3dfbde  vmovaps xmm13, [rsp+0xD0]
00007eafdc3dfbe7  vmovaps xmm14, [rsp+0xE0]
00007eafdc3dfbf0  add rsp, 0xF0
00007eafdc3dfbf7  pop r11
00007eafdc3dfbf9  pop r10
00007eafdc3dfbfb  pop r9
00007eafdc3dfbfd  pop r8
00007eafdc3dfbff  pop rsi
00007eafdc3dfc00  pop rdi
00007eafdc3dfc01  pop rdx
00007eafdc3dfc02  pop rcx
00007eafdc3dfc03  pop rax
00007eafdc3dfc04  add rsp, 0x08
00007eafdc3dfc08  jmp 0x00007EAFDC3DC473
00007eafdc3dfc0d  call 0x00007EAFDC2B52F0
00007eafdc3dfc12  jmp 0x00007EAFDC3DC4CE
00007eafdc3dfc17  sub rsp, 0x08
00007eafdc3dfc1b  push rax
00007eafdc3dfc1c  push rcx
00007eafdc3dfc1d  push rdx
00007eafdc3dfc1e  push rdi
00007eafdc3dfc1f  push rsi
00007eafdc3dfc20  push r8
00007eafdc3dfc22  push r9
00007eafdc3dfc24  push r10
00007eafdc3dfc26  push r11
00007eafdc3dfc28  sub rsp, 0xF0
00007eafdc3dfc2f  vmovaps [rsp], xmm0
00007eafdc3dfc34  vmovaps [rsp+0x10], xmm1
00007eafdc3dfc3a  vmovaps [rsp+0x20], xmm2
00007eafdc3dfc40  vmovaps [rsp+0x30], xmm3
00007eafdc3dfc46  vmovaps [rsp+0x40], xmm4
00007eafdc3dfc4c  vmovaps [rsp+0x50], xmm5
00007eafdc3dfc52  vmovaps [rsp+0x60], xmm6
00007eafdc3dfc58  vmovaps [rsp+0x70], xmm7
00007eafdc3dfc5e  vmovaps [rsp+0x80], xmm8
00007eafdc3dfc67  vmovaps [rsp+0x90], xmm10
00007eafdc3dfc70  vmovaps [rsp+0xA0], xmm11
00007eafdc3dfc79  vmovaps [rsp+0xB0], xmm12
00007eafdc3dfc82  vmovaps [rsp+0xC0], xmm13
00007eafdc3dfc8b  vmovaps [rsp+0xD0], xmm14
00007eafdc3dfc94  vmovaps [rsp+0xE0], xmm15
00007eafdc3dfc9d  sub rsp, 0x30
00007eafdc3dfca1  movaps [rsp], xmm9
00007eafdc3dfca6  movaps [rsp+0x10], xmm8
00007eafdc3dfcac  movaps [rsp+0x20], xmm11
00007eafdc3dfcb2  lea rdi, [rsp]
00007eafdc3dfcb6  mov esi, 0x00
00007eafdc3dfcbb  mov rax, 0x645891675530
00007eafdc3dfcc5  call rax
00007eafdc3dfcc7  movaps xmm9, [rsp]
00007eafdc3dfccc  add rsp, 0x30
00007eafdc3dfcd0  vmovaps xmm0, [rsp]
00007eafdc3dfcd5  vmovaps xmm1, [rsp+0x10]
00007eafdc3dfcdb  vmovaps xmm2, [rsp+0x20]
00007eafdc3dfce1  vmovaps xmm3, [rsp+0x30]
00007eafdc3dfce7  vmovaps xmm4, [rsp+0x40]
00007eafdc3dfced  vmovaps xmm5, [rsp+0x50]
00007eafdc3dfcf3  vmovaps xmm6, [rsp+0x60]
00007eafdc3dfcf9  vmovaps xmm7, [rsp+0x70]
00007eafdc3dfcff  vmovaps xmm8, [rsp+0x80]
00007eafdc3dfd08  vmovaps xmm10, [rsp+0x90]
00007eafdc3dfd11  vmovaps xmm11, [rsp+0xA0]
00007eafdc3dfd1a  vmovaps xmm12, [rsp+0xB0]
00007eafdc3dfd23  vmovaps xmm13, [rsp+0xC0]
00007eafdc3dfd2c  vmovaps xmm14, [rsp+0xD0]
00007eafdc3dfd35  vmovaps xmm15, [rsp+0xE0]
00007eafdc3dfd3e  add rsp, 0xF0
00007eafdc3dfd45  pop r11
00007eafdc3dfd47  pop r10
00007eafdc3dfd49  pop r9
00007eafdc3dfd4b  pop r8
00007eafdc3dfd4d  pop rsi
00007eafdc3dfd4e  pop rdi
00007eafdc3dfd4f  pop rdx
00007eafdc3dfd50  pop rcx
00007eafdc3dfd51  pop rax
00007eafdc3dfd52  add rsp, 0x08
00007eafdc3dfd56  jmp 0x00007EAFDC3DC505
00007eafdc3dfd5b  sub rsp, 0x08
00007eafdc3dfd5f  push rax
00007eafdc3dfd60  push rcx
00007eafdc3dfd61  push rdx
00007eafdc3dfd62  push rdi
00007eafdc3dfd63  push rsi
00007eafdc3dfd64  push r8
00007eafdc3dfd66  push r9
00007eafdc3dfd68  push r10
00007eafdc3dfd6a  push r11
00007eafdc3dfd6c  sub rsp, 0xF0
00007eafdc3dfd73  vmovaps [rsp], xmm0
00007eafdc3dfd78  vmovaps [rsp+0x10], xmm1
00007eafdc3dfd7e  vmovaps [rsp+0x20], xmm2
00007eafdc3dfd84  vmovaps [rsp+0x30], xmm3
00007eafdc3dfd8a  vmovaps [rsp+0x40], xmm4
00007eafdc3dfd90  vmovaps [rsp+0x50], xmm5
00007eafdc3dfd96  vmovaps [rsp+0x60], xmm6
00007eafdc3dfd9c  vmovaps [rsp+0x70], xmm7
00007eafdc3dfda2  vmovaps [rsp+0x80], xmm8
00007eafdc3dfdab  vmovaps [rsp+0x90], xmm9
00007eafdc3dfdb4  vmovaps [rsp+0xA0], xmm10
00007eafdc3dfdbd  vmovaps [rsp+0xB0], xmm12
00007eafdc3dfdc6  vmovaps [rsp+0xC0], xmm13
00007eafdc3dfdcf  vmovaps [rsp+0xD0], xmm14
00007eafdc3dfdd8  vmovaps [rsp+0xE0], xmm15
00007eafdc3dfde1  sub rsp, 0x30
00007eafdc3dfde5  movaps [rsp], xmm11
00007eafdc3dfdea  movaps [rsp+0x10], xmm10
00007eafdc3dfdf0  movaps [rsp+0x20], xmm6
00007eafdc3dfdf5  lea rdi, [rsp]
00007eafdc3dfdf9  mov esi, 0x00
00007eafdc3dfdfe  mov rax, 0x645891675530
00007eafdc3dfe08  call rax
00007eafdc3dfe0a  movaps xmm11, [rsp]
00007eafdc3dfe0f  add rsp, 0x30
00007eafdc3dfe13  vmovaps xmm0, [rsp]
00007eafdc3dfe18  vmovaps xmm1, [rsp+0x10]
00007eafdc3dfe1e  vmovaps xmm2, [rsp+0x20]
00007eafdc3dfe24  vmovaps xmm3, [rsp+0x30]
00007eafdc3dfe2a  vmovaps xmm4, [rsp+0x40]
00007eafdc3dfe30  vmovaps xmm5, [rsp+0x50]
00007eafdc3dfe36  vmovaps xmm6, [rsp+0x60]
00007eafdc3dfe3c  vmovaps xmm7, [rsp+0x70]
00007eafdc3dfe42  vmovaps xmm8, [rsp+0x80]
00007eafdc3dfe4b  vmovaps xmm9, [rsp+0x90]
00007eafdc3dfe54  vmovaps xmm10, [rsp+0xA0]
00007eafdc3dfe5d  vmovaps xmm12, [rsp+0xB0]
00007eafdc3dfe66  vmovaps xmm13, [rsp+0xC0]
00007eafdc3dfe6f  vmovaps xmm14, [rsp+0xD0]
00007eafdc3dfe78  vmovaps xmm15, [rsp+0xE0]
00007eafdc3dfe81  add rsp, 0xF0
00007eafdc3dfe88  pop r11
00007eafdc3dfe8a  pop r10
00007eafdc3dfe8c  pop r9
00007eafdc3dfe8e  pop r8
00007eafdc3dfe90  pop rsi
00007eafdc3dfe91  pop rdi
00007eafdc3dfe92  pop rdx
00007eafdc3dfe93  pop rcx
00007eafdc3dfe94  pop rax
00007eafdc3dfe95  add rsp, 0x08
00007eafdc3dfe99  jmp 0x00007EAFDC3DC520
00007eafdc3dfe9e  sub rsp, 0x08
00007eafdc3dfea2  push rax
00007eafdc3dfea3  push rcx
00007eafdc3dfea4  push rdx
00007eafdc3dfea5  push rdi
00007eafdc3dfea6  push rsi
00007eafdc3dfea7  push r8
00007eafdc3dfea9  push r9
00007eafdc3dfeab  push r10
00007eafdc3dfead  push r11
00007eafdc3dfeaf  sub rsp, 0xF0
00007eafdc3dfeb6  vmovaps [rsp], xmm0
00007eafdc3dfebb  vmovaps [rsp+0x10], xmm1
00007eafdc3dfec1  vmovaps [rsp+0x20], xmm2
00007eafdc3dfec7  vmovaps [rsp+0x30], xmm3
00007eafdc3dfecd  vmovaps [rsp+0x40], xmm4
00007eafdc3dfed3  vmovaps [rsp+0x50], xmm5
00007eafdc3dfed9  vmovaps [rsp+0x60], xmm6
00007eafdc3dfedf  vmovaps [rsp+0x70], xmm7
00007eafdc3dfee5  vmovaps [rsp+0x80], xmm8
00007eafdc3dfeee  vmovaps [rsp+0x90], xmm9
00007eafdc3dfef7  vmovaps [rsp+0xA0], xmm11
00007eafdc3dff00  vmovaps [rsp+0xB0], xmm12
00007eafdc3dff09  vmovaps [rsp+0xC0], xmm13
00007eafdc3dff12  vmovaps [rsp+0xD0], xmm14
00007eafdc3dff1b  vmovaps [rsp+0xE0], xmm15
00007eafdc3dff24  sub rsp, 0x30
00007eafdc3dff28  movaps [rsp], xmm10
00007eafdc3dff2d  movaps [rsp+0x10], xmm14
00007eafdc3dff33  movaps [rsp+0x20], xmm4
00007eafdc3dff38  lea rdi, [rsp]
00007eafdc3dff3c  mov esi, 0x00
00007eafdc3dff41  mov rax, 0x645891675530
00007eafdc3dff4b  call rax
00007eafdc3dff4d  movaps xmm10, [rsp]
00007eafdc3dff52  add rsp, 0x30
00007eafdc3dff56  vmovaps xmm0, [rsp]
00007eafdc3dff5b  vmovaps xmm1, [rsp+0x10]
00007eafdc3dff61  vmovaps xmm2, [rsp+0x20]
00007eafdc3dff67  vmovaps xmm3, [rsp+0x30]
00007eafdc3dff6d  vmovaps xmm4, [rsp+0x40]
00007eafdc3dff73  vmovaps xmm5, [rsp+0x50]
00007eafdc3dff79  vmovaps xmm6, [rsp+0x60]
00007eafdc3dff7f  vmovaps xmm7, [rsp+0x70]
00007eafdc3dff85  vmovaps xmm8, [rsp+0x80]
00007eafdc3dff8e  vmovaps xmm9, [rsp+0x90]
00007eafdc3dff97  vmovaps xmm11, [rsp+0xA0]
00007eafdc3dffa0  vmovaps xmm12, [rsp+0xB0]
00007eafdc3dffa9  vmovaps xmm13, [rsp+0xC0]
00007eafdc3dffb2  vmovaps xmm14, [rsp+0xD0]
00007eafdc3dffbb  vmovaps xmm15, [rsp+0xE0]
00007eafdc3dffc4  add rsp, 0xF0
00007eafdc3dffcb  pop r11
00007eafdc3dffcd  pop r10
00007eafdc3dffcf  pop r9
00007eafdc3dffd1  pop r8
00007eafdc3dffd3  pop rsi
00007eafdc3dffd4  pop rdi
00007eafdc3dffd5  pop rdx
00007eafdc3dffd6  pop rcx
00007eafdc3dffd7  pop rax
00007eafdc3dffd8  add rsp, 0x08
00007eafdc3dffdc  jmp 0x00007EAFDC3DC53B
00007eafdc3dffe1  sub rsp, 0x08
00007eafdc3dffe5  push rax
00007eafdc3dffe6  push rcx
00007eafdc3dffe7  push rdx
00007eafdc3dffe8  push rdi
00007eafdc3dffe9  push rsi
00007eafdc3dffea  push r8
00007eafdc3dffec  push r9
00007eafdc3dffee  push r10
00007eafdc3dfff0  push r11
00007eafdc3dfff2  sub rsp, 0xF0
00007eafdc3dfff9  vmovaps [rsp], xmm0
00007eafdc3dfffe  vmovaps [rsp+0x10], xmm1
00007eafdc3e0004  vmovaps [rsp+0x20], xmm2
00007eafdc3e000a  vmovaps [rsp+0x30], xmm3
00007eafdc3e0010  vmovaps [rsp+0x40], xmm4
00007eafdc3e0016  vmovaps [rsp+0x50], xmm5
00007eafdc3e001c  vmovaps [rsp+0x60], xmm6
00007eafdc3e0022  vmovaps [rsp+0x70], xmm7
00007eafdc3e0028  vmovaps [rsp+0x80], xmm9
00007eafdc3e0031  vmovaps [rsp+0x90], xmm10
00007eafdc3e003a  vmovaps [rsp+0xA0], xmm11
00007eafdc3e0043  vmovaps [rsp+0xB0], xmm12
00007eafdc3e004c  vmovaps [rsp+0xC0], xmm13
00007eafdc3e0055  vmovaps [rsp+0xD0], xmm14
00007eafdc3e005e  vmovaps [rsp+0xE0], xmm15
00007eafdc3e0067  sub rsp, 0x30
00007eafdc3e006b  movaps [rsp], xmm8
00007eafdc3e0070  movaps [rsp+0x10], xmm1
00007eafdc3e0075  movaps [rsp+0x20], xmm14
00007eafdc3e007b  lea rdi, [rsp]
00007eafdc3e007f  mov esi, 0x00
00007eafdc3e0084  mov rax, 0x645891675530
00007eafdc3e008e  call rax
00007eafdc3e0090  movaps xmm8, [rsp]
00007eafdc3e0095  add rsp, 0x30
00007eafdc3e0099  vmovaps xmm0, [rsp]
00007eafdc3e009e  vmovaps xmm1, [rsp+0x10]
00007eafdc3e00a4  vmovaps xmm2, [rsp+0x20]
00007eafdc3e00aa  vmovaps xmm3, [rsp+0x30]
00007eafdc3e00b0  vmovaps xmm4, [rsp+0x40]
00007eafdc3e00b6  vmovaps xmm5, [rsp+0x50]
00007eafdc3e00bc  vmovaps xmm6, [rsp+0x60]
00007eafdc3e00c2  vmovaps xmm7, [rsp+0x70]
00007eafdc3e00c8  vmovaps xmm9, [rsp+0x80]
00007eafdc3e00d1  vmovaps xmm10, [rsp+0x90]
00007eafdc3e00da  vmovaps xmm11, [rsp+0xA0]
00007eafdc3e00e3  vmovaps xmm12, [rsp+0xB0]
00007eafdc3e00ec  vmovaps xmm13, [rsp+0xC0]
00007eafdc3e00f5  vmovaps xmm14, [rsp+0xD0]
00007eafdc3e00fe  vmovaps xmm15, [rsp+0xE0]
00007eafdc3e0107  add rsp, 0xF0
00007eafdc3e010e  pop r11
00007eafdc3e0110  pop r10
00007eafdc3e0112  pop r9
00007eafdc3e0114  pop r8
00007eafdc3e0116  pop rsi
00007eafdc3e0117  pop rdi
00007eafdc3e0118  pop rdx
00007eafdc3e0119  pop rcx
00007eafdc3e011a  pop rax
00007eafdc3e011b  add rsp, 0x08
00007eafdc3e011f  jmp 0x00007EAFDC3DC561
00007eafdc3e0124  sub rsp, 0x08
00007eafdc3e0128  push rax
00007eafdc3e0129  push rcx
00007eafdc3e012a  push rdx
00007eafdc3e012b  push rdi
00007eafdc3e012c  push rsi
00007eafdc3e012d  push r8
00007eafdc3e012f  push r9
00007eafdc3e0131  push r10
00007eafdc3e0133  push r11
00007eafdc3e0135  sub rsp, 0xF0
00007eafdc3e013c  vmovaps [rsp], xmm0
00007eafdc3e0141  vmovaps [rsp+0x10], xmm1
00007eafdc3e0147  vmovaps [rsp+0x20], xmm2
00007eafdc3e014d  vmovaps [rsp+0x30], xmm3
00007eafdc3e0153  vmovaps [rsp+0x40], xmm4
00007eafdc3e0159  vmovaps [rsp+0x50], xmm5
00007eafdc3e015f  vmovaps [rsp+0x60], xmm7
00007eafdc3e0165  vmovaps [rsp+0x70], xmm8
00007eafdc3e016b  vmovaps [rsp+0x80], xmm9
00007eafdc3e0174  vmovaps [rsp+0x90], xmm10
00007eafdc3e017d  vmovaps [rsp+0xA0], xmm11
00007eafdc3e0186  vmovaps [rsp+0xB0], xmm12
00007eafdc3e018f  vmovaps [rsp+0xC0], xmm13
00007eafdc3e0198  vmovaps [rsp+0xD0], xmm14
00007eafdc3e01a1  vmovaps [rsp+0xE0], xmm15
00007eafdc3e01aa  sub rsp, 0x30
00007eafdc3e01ae  movaps [rsp], xmm6
00007eafdc3e01b2  movaps [rsp+0x10], xmm1
00007eafdc3e01b7  movaps [rsp+0x20], xmm14
00007eafdc3e01bd  lea rdi, [rsp]
00007eafdc3e01c1  mov esi, 0x00
00007eafdc3e01c6  mov rax, 0x645891675530
00007eafdc3e01d0  call rax
00007eafdc3e01d2  movaps xmm6, [rsp]
00007eafdc3e01d6  add rsp, 0x30
00007eafdc3e01da  vmovaps xmm0, [rsp]
00007eafdc3e01df  vmovaps xmm1, [rsp+0x10]
00007eafdc3e01e5  vmovaps xmm2, [rsp+0x20]
00007eafdc3e01eb  vmovaps xmm3, [rsp+0x30]
00007eafdc3e01f1  vmovaps xmm4, [rsp+0x40]
00007eafdc3e01f7  vmovaps xmm5, [rsp+0x50]
00007eafdc3e01fd  vmovaps xmm7, [rsp+0x60]
00007eafdc3e0203  vmovaps xmm8, [rsp+0x70]
00007eafdc3e0209  vmovaps xmm9, [rsp+0x80]
00007eafdc3e0212  vmovaps xmm10, [rsp+0x90]
00007eafdc3e021b  vmovaps xmm11, [rsp+0xA0]
00007eafdc3e0224  vmovaps xmm12, [rsp+0xB0]
00007eafdc3e022d  vmovaps xmm13, [rsp+0xC0]
00007eafdc3e0236  vmovaps xmm14, [rsp+0xD0]
00007eafdc3e023f  vmovaps xmm15, [rsp+0xE0]
00007eafdc3e0248  add rsp, 0xF0
00007eafdc3e024f  pop r11
00007eafdc3e0251  pop r10
00007eafdc3e0253  pop r9
00007eafdc3e0255  pop r8
00007eafdc3e0257  pop rsi
00007eafdc3e0258  pop rdi
00007eafdc3e0259  pop rdx
00007eafdc3e025a  pop rcx
00007eafdc3e025b  pop rax
00007eafdc3e025c  add rsp, 0x08
00007eafdc3e0260  jmp 0x00007EAFDC3DC58D
00007eafdc3e0265  sub rsp, 0x08
00007eafdc3e0269  push rax
00007eafdc3e026a  push rcx
00007eafdc3e026b  push rdx
00007eafdc3e026c  push rdi
00007eafdc3e026d  push rsi
00007eafdc3e026e  push r8
00007eafdc3e0270  push r9
00007eafdc3e0272  push r10
00007eafdc3e0274  push r11
00007eafdc3e0276  sub rsp, 0xF0
00007eafdc3e027d  vmovaps [rsp], xmm0
00007eafdc3e0282  vmovaps [rsp+0x10], xmm1
00007eafdc3e0288  vmovaps [rsp+0x20], xmm2
00007eafdc3e028e  vmovaps [rsp+0x30], xmm3
00007eafdc3e0294  vmovaps [rsp+0x40], xmm4
00007eafdc3e029a  vmovaps [rsp+0x50], xmm5
00007eafdc3e02a0  vmovaps [rsp+0x60], xmm6
00007eafdc3e02a6  vmovaps [rsp+0x70], xmm7
00007eafdc3e02ac  vmovaps [rsp+0x80], xmm8
00007eafdc3e02b5  vmovaps [rsp+0x90], xmm9
00007eafdc3e02be  vmovaps [rsp+0xA0], xmm10
00007eafdc3e02c7  vmovaps [rsp+0xB0], xmm11
00007eafdc3e02d0  vmovaps [rsp+0xC0], xmm12
00007eafdc3e02d9  vmovaps [rsp+0xD0], xmm13
00007eafdc3e02e2  vmovaps [rsp+0xE0], xmm15
00007eafdc3e02eb  sub rsp, 0x30
00007eafdc3e02ef  movaps [rsp], xmm14
00007eafdc3e02f4  movaps [rsp+0x10], xmm12
00007eafdc3e02fa  movaps [rsp+0x20], xmm1
00007eafdc3e02ff  lea rdi, [rsp]
00007eafdc3e0303  mov esi, 0x00
00007eafdc3e0308  mov rax, 0x645891675530
00007eafdc3e0312  call rax
00007eafdc3e0314  movaps xmm14, [rsp]
00007eafdc3e0319  add rsp, 0x30
00007eafdc3e031d  vmovaps xmm0, [rsp]
00007eafdc3e0322  vmovaps xmm1, [rsp+0x10]
00007eafdc3e0328  vmovaps xmm2, [rsp+0x20]
00007eafdc3e032e  vmovaps xmm3, [rsp+0x30]
00007eafdc3e0334  vmovaps xmm4, [rsp+0x40]
00007eafdc3e033a  vmovaps xmm5, [rsp+0x50]
00007eafdc3e0340  vmovaps xmm6, [rsp+0x60]
00007eafdc3e0346  vmovaps xmm7, [rsp+0x70]
00007eafdc3e034c  vmovaps xmm8, [rsp+0x80]
00007eafdc3e0355  vmovaps xmm9, [rsp+0x90]
00007eafdc3e035e  vmovaps xmm10, [rsp+0xA0]
00007eafdc3e0367  vmovaps xmm11, [rsp+0xB0]
00007eafdc3e0370  vmovaps xmm12, [rsp+0xC0]
00007eafdc3e0379  vmovaps xmm13, [rsp+0xD0]
00007eafdc3e0382  vmovaps xmm15, [rsp+0xE0]
00007eafdc3e038b  add rsp, 0xF0
00007eafdc3e0392  pop r11
00007eafdc3e0394  pop r10
00007eafdc3e0396  pop r9
00007eafdc3e0398  pop r8
00007eafdc3e039a  pop rsi
00007eafdc3e039b  pop rdi
00007eafdc3e039c  pop rdx
00007eafdc3e039d  pop rcx
00007eafdc3e039e  pop rax
00007eafdc3e039f  add rsp, 0x08
00007eafdc3e03a3  jmp 0x00007EAFDC3DC5B3
00007eafdc3e03a8  sub rsp, 0x08
00007eafdc3e03ac  push rax
00007eafdc3e03ad  push rcx
00007eafdc3e03ae  push rdx
00007eafdc3e03af  push rdi
00007eafdc3e03b0  push rsi
00007eafdc3e03b1  push r8
00007eafdc3e03b3  push r9
00007eafdc3e03b5  push r10
00007eafdc3e03b7  push r11
00007eafdc3e03b9  sub rsp, 0xF0
00007eafdc3e03c0  vmovaps [rsp], xmm0
00007eafdc3e03c5  vmovaps [rsp+0x10], xmm2
00007eafdc3e03cb  vmovaps [rsp+0x20], xmm3
00007eafdc3e03d1  vmovaps [rsp+0x30], xmm4
00007eafdc3e03d7  vmovaps [rsp+0x40], xmm5
00007eafdc3e03dd  vmovaps [rsp+0x50], xmm6
00007eafdc3e03e3  vmovaps [rsp+0x60], xmm7
00007eafdc3e03e9  vmovaps [rsp+0x70], xmm8
00007eafdc3e03ef  vmovaps [rsp+0x80], xmm9
00007eafdc3e03f8  vmovaps [rsp+0x90], xmm10
00007eafdc3e0401  vmovaps [rsp+0xA0], xmm11
00007eafdc3e040a  vmovaps [rsp+0xB0], xmm12
00007eafdc3e0413  vmovaps [rsp+0xC0], xmm13
00007eafdc3e041c  vmovaps [rsp+0xD0], xmm14
00007eafdc3e0425  vmovaps [rsp+0xE0], xmm15
00007eafdc3e042e  sub rsp, 0x30
00007eafdc3e0432  movaps [rsp], xmm1
00007eafdc3e0436  movaps [rsp+0x10], xmm13
00007eafdc3e043c  movaps [rsp+0x20], xmm9
00007eafdc3e0442  lea rdi, [rsp]
00007eafdc3e0446  mov esi, 0x00
00007eafdc3e044b  mov rax, 0x645891675530
00007eafdc3e0455  call rax
00007eafdc3e0457  movaps xmm1, [rsp]
00007eafdc3e045b  add rsp, 0x30
00007eafdc3e045f  vmovaps xmm0, [rsp]
00007eafdc3e0464  vmovaps xmm2, [rsp+0x10]
00007eafdc3e046a  vmovaps xmm3, [rsp+0x20]
00007eafdc3e0470  vmovaps xmm4, [rsp+0x30]
00007eafdc3e0476  vmovaps xmm5, [rsp+0x40]
00007eafdc3e047c  vmovaps xmm6, [rsp+0x50]
00007eafdc3e0482  vmovaps xmm7, [rsp+0x60]
00007eafdc3e0488  vmovaps xmm8, [rsp+0x70]
00007eafdc3e048e  vmovaps xmm9, [rsp+0x80]
00007eafdc3e0497  vmovaps xmm10, [rsp+0x90]
00007eafdc3e04a0  vmovaps xmm11, [rsp+0xA0]
00007eafdc3e04a9  vmovaps xmm12, [rsp+0xB0]
00007eafdc3e04b2  vmovaps xmm13, [rsp+0xC0]
00007eafdc3e04bb  vmovaps xmm14, [rsp+0xD0]
00007eafdc3e04c4  vmovaps xmm15, [rsp+0xE0]
00007eafdc3e04cd  add rsp, 0xF0
00007eafdc3e04d4  pop r11
00007eafdc3e04d6  pop r10
00007eafdc3e04d8  pop r9
00007eafdc3e04da  pop r8
00007eafdc3e04dc  pop rsi
00007eafdc3e04dd  pop rdi
00007eafdc3e04de  pop rdx
00007eafdc3e04df  pop rcx
00007eafdc3e04e0  pop rax
00007eafdc3e04e1  add rsp, 0x08
00007eafdc3e04e5  jmp 0x00007EAFDC3DC5CD
00007eafdc3e04ea  sub rsp, 0x08
00007eafdc3e04ee  push rax
00007eafdc3e04ef  push rcx
00007eafdc3e04f0  push rdx
00007eafdc3e04f1  push rdi
00007eafdc3e04f2  push rsi
00007eafdc3e04f3  push r8
00007eafdc3e04f5  push r9
00007eafdc3e04f7  push r10
00007eafdc3e04f9  push r11
00007eafdc3e04fb  sub rsp, 0xF0
00007eafdc3e0502  vmovaps [rsp], xmm0
00007eafdc3e0507  vmovaps [rsp+0x10], xmm1
00007eafdc3e050d  vmovaps [rsp+0x20], xmm2
00007eafdc3e0513  vmovaps [rsp+0x30], xmm3
00007eafdc3e0519  vmovaps [rsp+0x40], xmm4
00007eafdc3e051f  vmovaps [rsp+0x50], xmm5
00007eafdc3e0525  vmovaps [rsp+0x60], xmm6
00007eafdc3e052b  vmovaps [rsp+0x70], xmm7
00007eafdc3e0531  vmovaps [rsp+0x80], xmm8
00007eafdc3e053a  vmovaps [rsp+0x90], xmm9
00007eafdc3e0543  vmovaps [rsp+0xA0], xmm10
00007eafdc3e054c  vmovaps [rsp+0xB0], xmm11
00007eafdc3e0555  vmovaps [rsp+0xC0], xmm13
00007eafdc3e055e  vmovaps [rsp+0xD0], xmm14
00007eafdc3e0567  vmovaps [rsp+0xE0], xmm15
00007eafdc3e0570  sub rsp, 0x30
00007eafdc3e0574  movaps [rsp], xmm12
00007eafdc3e0579  movaps [rsp+0x10], xmm7
00007eafdc3e057e  movaps [rsp+0x20], xmm13
00007eafdc3e0584  lea rdi, [rsp]
00007eafdc3e0588  mov esi, 0x00
00007eafdc3e058d  mov rax, 0x645891675530
00007eafdc3e0597  call rax
00007eafdc3e0599  movaps xmm12, [rsp]
00007eafdc3e059e  add rsp, 0x30
00007eafdc3e05a2  vmovaps xmm0, [rsp]
00007eafdc3e05a7  vmovaps xmm1, [rsp+0x10]
00007eafdc3e05ad  vmovaps xmm2, [rsp+0x20]
00007eafdc3e05b3  vmovaps xmm3, [rsp+0x30]
00007eafdc3e05b9  vmovaps xmm4, [rsp+0x40]
00007eafdc3e05bf  vmovaps xmm5, [rsp+0x50]
00007eafdc3e05c5  vmovaps xmm6, [rsp+0x60]
00007eafdc3e05cb  vmovaps xmm7, [rsp+0x70]
00007eafdc3e05d1  vmovaps xmm8, [rsp+0x80]
00007eafdc3e05da  vmovaps xmm9, [rsp+0x90]
00007eafdc3e05e3  vmovaps xmm10, [rsp+0xA0]
00007eafdc3e05ec  vmovaps xmm11, [rsp+0xB0]
00007eafdc3e05f5  vmovaps xmm13, [rsp+0xC0]
00007eafdc3e05fe  vmovaps xmm14, [rsp+0xD0]
00007eafdc3e0607  vmovaps xmm15, [rsp+0xE0]
00007eafdc3e0610  add rsp, 0xF0
00007eafdc3e0617  pop r11
00007eafdc3e0619  pop r10
00007eafdc3e061b  pop r9
00007eafdc3e061d  pop r8
00007eafdc3e061f  pop rsi
00007eafdc3e0620  pop rdi
00007eafdc3e0621  pop rdx
00007eafdc3e0622  pop rcx
00007eafdc3e0623  pop rax
00007eafdc3e0624  add rsp, 0x08
00007eafdc3e0628  jmp 0x00007EAFDC3DC5F4
00007eafdc3e062d  sub rsp, 0x08
00007eafdc3e0631  push rax
00007eafdc3e0632  push rcx
00007eafdc3e0633  push rdx
00007eafdc3e0634  push rdi
00007eafdc3e0635  push rsi
00007eafdc3e0636  push r8
00007eafdc3e0638  push r9
00007eafdc3e063a  push r10
00007eafdc3e063c  push r11
00007eafdc3e063e  sub rsp, 0xF0
00007eafdc3e0645  vmovaps [rsp], xmm0
00007eafdc3e064a  vmovaps [rsp+0x10], xmm1
00007eafdc3e0650  vmovaps [rsp+0x20], xmm2
00007eafdc3e0656  vmovaps [rsp+0x30], xmm3
00007eafdc3e065c  vmovaps [rsp+0x40], xmm4
00007eafdc3e0662  vmovaps [rsp+0x50], xmm5
00007eafdc3e0668  vmovaps [rsp+0x60], xmm6
00007eafdc3e066e  vmovaps [rsp+0x70], xmm7
00007eafdc3e0674  vmovaps [rsp+0x80], xmm8
00007eafdc3e067d  vmovaps [rsp+0x90], xmm9
00007eafdc3e0686  vmovaps [rsp+0xA0], xmm10
00007eafdc3e068f  vmovaps [rsp+0xB0], xmm11
00007eafdc3e0698  vmovaps [rsp+0xC0], xmm12
00007eafdc3e06a1  vmovaps [rsp+0xD0], xmm14
00007eafdc3e06aa  vmovaps [rsp+0xE0], xmm15
00007eafdc3e06b3  sub rsp, 0x30
00007eafdc3e06b7  movaps [rsp], xmm13
00007eafdc3e06bc  movaps [rsp+0x10], xmm15
00007eafdc3e06c2  movaps [rsp+0x20], xmm8
00007eafdc3e06c8  lea rdi, [rsp]
00007eafdc3e06cc  mov esi, 0x00
00007eafdc3e06d1  mov rax, 0x645891675530
00007eafdc3e06db  call rax
00007eafdc3e06dd  movaps xmm13, [rsp]
00007eafdc3e06e2  add rsp, 0x30
00007eafdc3e06e6  vmovaps xmm0, [rsp]
00007eafdc3e06eb  vmovaps xmm1, [rsp+0x10]
00007eafdc3e06f1  vmovaps xmm2, [rsp+0x20]
00007eafdc3e06f7  vmovaps xmm3, [rsp+0x30]
00007eafdc3e06fd  vmovaps xmm4, [rsp+0x40]
00007eafdc3e0703  vmovaps xmm5, [rsp+0x50]
00007eafdc3e0709  vmovaps xmm6, [rsp+0x60]
00007eafdc3e070f  vmovaps xmm7, [rsp+0x70]
00007eafdc3e0715  vmovaps xmm8, [rsp+0x80]
00007eafdc3e071e  vmovaps xmm9, [rsp+0x90]
00007eafdc3e0727  vmovaps xmm10, [rsp+0xA0]
00007eafdc3e0730  vmovaps xmm11, [rsp+0xB0]
00007eafdc3e0739  vmovaps xmm12, [rsp+0xC0]
00007eafdc3e0742  vmovaps xmm14, [rsp+0xD0]
00007eafdc3e074b  vmovaps xmm15, [rsp+0xE0]
00007eafdc3e0754  add rsp, 0xF0
00007eafdc3e075b  pop r11
00007eafdc3e075d  pop r10
00007eafdc3e075f  pop r9
00007eafdc3e0761  pop r8
00007eafdc3e0763  pop rsi
00007eafdc3e0764  pop rdi
00007eafdc3e0765  pop rdx
00007eafdc3e0766  pop rcx
00007eafdc3e0767  pop rax
00007eafdc3e0768  add rsp, 0x08
00007eafdc3e076c  jmp 0x00007EAFDC3DC60F
00007eafdc3e0771  sub rsp, 0x08
00007eafdc3e0775  push rax
00007eafdc3e0776  push rcx
00007eafdc3e0777  push rdx
00007eafdc3e0778  push rdi
00007eafdc3e0779  push rsi
00007eafdc3e077a  push r8
00007eafdc3e077c  push r9
00007eafdc3e077e  push r10
00007eafdc3e0780  push r11
00007eafdc3e0782  sub rsp, 0xF0
00007eafdc3e0789  vmovaps [rsp], xmm0
00007eafdc3e078e  vmovaps [rsp+0x10], xmm1
00007eafdc3e0794  vmovaps [rsp+0x20], xmm2
00007eafdc3e079a  vmovaps [rsp+0x30], xmm3
00007eafdc3e07a0  vmovaps [rsp+0x40], xmm4
00007eafdc3e07a6  vmovaps [rsp+0x50], xmm5
00007eafdc3e07ac  vmovaps [rsp+0x60], xmm6
00007eafdc3e07b2  vmovaps [rsp+0x70], xmm7
00007eafdc3e07b8  vmovaps [rsp+0x80], xmm9
00007eafdc3e07c1  vmovaps [rsp+0x90], xmm10
00007eafdc3e07ca  vmovaps [rsp+0xA0], xmm11
00007eafdc3e07d3  vmovaps [rsp+0xB0], xmm12
00007eafdc3e07dc  vmovaps [rsp+0xC0], xmm13
00007eafdc3e07e5  vmovaps [rsp+0xD0], xmm14
00007eafdc3e07ee  vmovaps [rsp+0xE0], xmm15
00007eafdc3e07f7  sub rsp, 0x30
00007eafdc3e07fb  movaps [rsp], xmm8
00007eafdc3e0800  movaps [rsp+0x10], xmm15
00007eafdc3e0806  movaps [rsp+0x20], xmm9
00007eafdc3e080c  lea rdi, [rsp]
00007eafdc3e0810  mov esi, 0x00
00007eafdc3e0815  mov rax, 0x645891675530
00007eafdc3e081f  call rax
00007eafdc3e0821  movaps xmm8, [rsp]
00007eafdc3e0826  add rsp, 0x30
00007eafdc3e082a  vmovaps xmm0, [rsp]
00007eafdc3e082f  vmovaps xmm1, [rsp+0x10]
00007eafdc3e0835  vmovaps xmm2, [rsp+0x20]
00007eafdc3e083b  vmovaps xmm3, [rsp+0x30]
00007eafdc3e0841  vmovaps xmm4, [rsp+0x40]
00007eafdc3e0847  vmovaps xmm5, [rsp+0x50]
00007eafdc3e084d  vmovaps xmm6, [rsp+0x60]
00007eafdc3e0853  vmovaps xmm7, [rsp+0x70]
00007eafdc3e0859  vmovaps xmm9, [rsp+0x80]
00007eafdc3e0862  vmovaps xmm10, [rsp+0x90]
00007eafdc3e086b  vmovaps xmm11, [rsp+0xA0]
00007eafdc3e0874  vmovaps xmm12, [rsp+0xB0]
00007eafdc3e087d  vmovaps xmm13, [rsp+0xC0]
00007eafdc3e0886  vmovaps xmm14, [rsp+0xD0]
00007eafdc3e088f  vmovaps xmm15, [rsp+0xE0]
00007eafdc3e0898  add rsp, 0xF0
00007eafdc3e089f  pop r11
00007eafdc3e08a1  pop r10
00007eafdc3e08a3  pop r9
00007eafdc3e08a5  pop r8
00007eafdc3e08a7  pop rsi
00007eafdc3e08a8  pop rdi
00007eafdc3e08a9  pop rdx
00007eafdc3e08aa  pop rcx
00007eafdc3e08ab  pop rax
00007eafdc3e08ac  add rsp, 0x08
00007eafdc3e08b0  jmp 0x00007EAFDC3DC63D
00007eafdc3e08b5  sub rsp, 0x08
00007eafdc3e08b9  push rax
00007eafdc3e08ba  push rcx
00007eafdc3e08bb  push rdx
00007eafdc3e08bc  push rdi
00007eafdc3e08bd  push rsi
00007eafdc3e08be  push r8
00007eafdc3e08c0  push r9
00007eafdc3e08c2  push r10
00007eafdc3e08c4  push r11
00007eafdc3e08c6  sub rsp, 0xF0
00007eafdc3e08cd  vmovaps [rsp], xmm0
00007eafdc3e08d2  vmovaps [rsp+0x10], xmm1
00007eafdc3e08d8  vmovaps [rsp+0x20], xmm2
00007eafdc3e08de  vmovaps [rsp+0x30], xmm3
00007eafdc3e08e4  vmovaps [rsp+0x40], xmm4
00007eafdc3e08ea  vmovaps [rsp+0x50], xmm5
00007eafdc3e08f0  vmovaps [rsp+0x60], xmm6
00007eafdc3e08f6  vmovaps [rsp+0x70], xmm7
00007eafdc3e08fc  vmovaps [rsp+0x80], xmm8
00007eafdc3e0905  vmovaps [rsp+0x90], xmm9
00007eafdc3e090e  vmovaps [rsp+0xA0], xmm10
00007eafdc3e0917  vmovaps [rsp+0xB0], xmm11
00007eafdc3e0920  vmovaps [rsp+0xC0], xmm12
00007eafdc3e0929  vmovaps [rsp+0xD0], xmm13
00007eafdc3e0932  vmovaps [rsp+0xE0], xmm14
00007eafdc3e093b  sub rsp, 0x30
00007eafdc3e093f  movaps [rsp], xmm15
00007eafdc3e0944  movaps [rsp+0x10], xmm11
00007eafdc3e094a  movaps [rsp+0x20], xmm6
00007eafdc3e094f  lea rdi, [rsp]
00007eafdc3e0953  mov esi, 0x00
00007eafdc3e0958  mov rax, 0x645891675530
00007eafdc3e0962  call rax
00007eafdc3e0964  movaps xmm15, [rsp]
00007eafdc3e0969  add rsp, 0x30
00007eafdc3e096d  vmovaps xmm0, [rsp]
00007eafdc3e0972  vmovaps xmm1, [rsp+0x10]
00007eafdc3e0978  vmovaps xmm2, [rsp+0x20]
00007eafdc3e097e  vmovaps xmm3, [rsp+0x30]
00007eafdc3e0984  vmovaps xmm4, [rsp+0x40]
00007eafdc3e098a  vmovaps xmm5, [rsp+0x50]
00007eafdc3e0990  vmovaps xmm6, [rsp+0x60]
00007eafdc3e0996  vmovaps xmm7, [rsp+0x70]
00007eafdc3e099c  vmovaps xmm8, [rsp+0x80]
00007eafdc3e09a5  vmovaps xmm9, [rsp+0x90]
00007eafdc3e09ae  vmovaps xmm10, [rsp+0xA0]
00007eafdc3e09b7  vmovaps xmm11, [rsp+0xB0]
00007eafdc3e09c0  vmovaps xmm12, [rsp+0xC0]
00007eafdc3e09c9  vmovaps xmm13, [rsp+0xD0]
00007eafdc3e09d2  vmovaps xmm14, [rsp+0xE0]
00007eafdc3e09db  add rsp, 0xF0
00007eafdc3e09e2  pop r11
00007eafdc3e09e4  pop r10
00007eafdc3e09e6  pop r9
00007eafdc3e09e8  pop r8
00007eafdc3e09ea  pop rsi
00007eafdc3e09eb  pop rdi
00007eafdc3e09ec  pop rdx
00007eafdc3e09ed  pop rcx
00007eafdc3e09ee  pop rax
00007eafdc3e09ef  add rsp, 0x08
00007eafdc3e09f3  jmp 0x00007EAFDC3DC658
00007eafdc3e09f8  sub rsp, 0x08
00007eafdc3e09fc  push rax
00007eafdc3e09fd  push rcx
00007eafdc3e09fe  push rdx
00007eafdc3e09ff  push rdi
00007eafdc3e0a00  push rsi
00007eafdc3e0a01  push r8
00007eafdc3e0a03  push r9
00007eafdc3e0a05  push r10
00007eafdc3e0a07  push r11
00007eafdc3e0a09  sub rsp, 0xF0
00007eafdc3e0a10  vmovaps [rsp], xmm0
00007eafdc3e0a15  vmovaps [rsp+0x10], xmm1
00007eafdc3e0a1b  vmovaps [rsp+0x20], xmm2
00007eafdc3e0a21  vmovaps [rsp+0x30], xmm3
00007eafdc3e0a27  vmovaps [rsp+0x40], xmm4
00007eafdc3e0a2d  vmovaps [rsp+0x50], xmm5
00007eafdc3e0a33  vmovaps [rsp+0x60], xmm6
00007eafdc3e0a39  vmovaps [rsp+0x70], xmm8
00007eafdc3e0a3f  vmovaps [rsp+0x80], xmm9
00007eafdc3e0a48  vmovaps [rsp+0x90], xmm10
00007eafdc3e0a51  vmovaps [rsp+0xA0], xmm11
00007eafdc3e0a5a  vmovaps [rsp+0xB0], xmm12
00007eafdc3e0a63  vmovaps [rsp+0xC0], xmm13
00007eafdc3e0a6c  vmovaps [rsp+0xD0], xmm14
00007eafdc3e0a75  vmovaps [rsp+0xE0], xmm15
00007eafdc3e0a7e  sub rsp, 0x30
00007eafdc3e0a82  movaps [rsp], xmm7
00007eafdc3e0a86  movaps [rsp+0x10], xmm11
00007eafdc3e0a8c  movaps [rsp+0x20], xmm9
00007eafdc3e0a92  lea rdi, [rsp]
00007eafdc3e0a96  mov esi, 0x00
00007eafdc3e0a9b  mov rax, 0x645891675530
00007eafdc3e0aa5  call rax
00007eafdc3e0aa7  movaps xmm7, [rsp]
00007eafdc3e0aab  add rsp, 0x30
00007eafdc3e0aaf  vmovaps xmm0, [rsp]
00007eafdc3e0ab4  vmovaps xmm1, [rsp+0x10]
00007eafdc3e0aba  vmovaps xmm2, [rsp+0x20]
00007eafdc3e0ac0  vmovaps xmm3, [rsp+0x30]
00007eafdc3e0ac6  vmovaps xmm4, [rsp+0x40]
00007eafdc3e0acc  vmovaps xmm5, [rsp+0x50]
00007eafdc3e0ad2  vmovaps xmm6, [rsp+0x60]
00007eafdc3e0ad8  vmovaps xmm8, [rsp+0x70]
00007eafdc3e0ade  vmovaps xmm9, [rsp+0x80]
00007eafdc3e0ae7  vmovaps xmm10, [rsp+0x90]
00007eafdc3e0af0  vmovaps xmm11, [rsp+0xA0]
00007eafdc3e0af9  vmovaps xmm12, [rsp+0xB0]
00007eafdc3e0b02  vmovaps xmm13, [rsp+0xC0]
00007eafdc3e0b0b  vmovaps xmm14, [rsp+0xD0]
00007eafdc3e0b14  vmovaps xmm15, [rsp+0xE0]
00007eafdc3e0b1d  add rsp, 0xF0
00007eafdc3e0b24  pop r11
00007eafdc3e0b26  pop r10
00007eafdc3e0b28  pop r9
00007eafdc3e0b2a  pop r8
00007eafdc3e0b2c  pop rsi
00007eafdc3e0b2d  pop rdi
00007eafdc3e0b2e  pop rdx
00007eafdc3e0b2f  pop rcx
00007eafdc3e0b30  pop rax
00007eafdc3e0b31  add rsp, 0x08
00007eafdc3e0b35  jmp 0x00007EAFDC3DC685
00007eafdc3e0b3a  sub rsp, 0x08
00007eafdc3e0b3e  push rax
00007eafdc3e0b3f  push rcx
00007eafdc3e0b40  push rdx
00007eafdc3e0b41  push rdi
00007eafdc3e0b42  push rsi
00007eafdc3e0b43  push r8
00007eafdc3e0b45  push r9
00007eafdc3e0b47  push r10
00007eafdc3e0b49  push r11
00007eafdc3e0b4b  sub rsp, 0xF0
00007eafdc3e0b52  vmovaps [rsp], xmm0
00007eafdc3e0b57  vmovaps [rsp+0x10], xmm1
00007eafdc3e0b5d  vmovaps [rsp+0x20], xmm2
00007eafdc3e0b63  vmovaps [rsp+0x30], xmm3
00007eafdc3e0b69  vmovaps [rsp+0x40], xmm4
00007eafdc3e0b6f  vmovaps [rsp+0x50], xmm5
00007eafdc3e0b75  vmovaps [rsp+0x60], xmm6
00007eafdc3e0b7b  vmovaps [rsp+0x70], xmm7
00007eafdc3e0b81  vmovaps [rsp+0x80], xmm8
00007eafdc3e0b8a  vmovaps [rsp+0x90], xmm9
00007eafdc3e0b93  vmovaps [rsp+0xA0], xmm10
00007eafdc3e0b9c  vmovaps [rsp+0xB0], xmm12
00007eafdc3e0ba5  vmovaps [rsp+0xC0], xmm13
00007eafdc3e0bae  vmovaps [rsp+0xD0], xmm14
00007eafdc3e0bb7  vmovaps [rsp+0xE0], xmm15
00007eafdc3e0bc0  sub rsp, 0x30
00007eafdc3e0bc4  movaps [rsp], xmm11
00007eafdc3e0bc9  movaps [rsp+0x10], xmm10
00007eafdc3e0bcf  movaps [rsp+0x20], xmm14
00007eafdc3e0bd5  lea rdi, [rsp]
00007eafdc3e0bd9  mov esi, 0x00
00007eafdc3e0bde  mov rax, 0x645891675530
00007eafdc3e0be8  call rax
00007eafdc3e0bea  movaps xmm11, [rsp]
00007eafdc3e0bef  add rsp, 0x30
00007eafdc3e0bf3  vmovaps xmm0, [rsp]
00007eafdc3e0bf8  vmovaps xmm1, [rsp+0x10]
00007eafdc3e0bfe  vmovaps xmm2, [rsp+0x20]
00007eafdc3e0c04  vmovaps xmm3, [rsp+0x30]
00007eafdc3e0c0a  vmovaps xmm4, [rsp+0x40]
00007eafdc3e0c10  vmovaps xmm5, [rsp+0x50]
00007eafdc3e0c16  vmovaps xmm6, [rsp+0x60]
00007eafdc3e0c1c  vmovaps xmm7, [rsp+0x70]
00007eafdc3e0c22  vmovaps xmm8, [rsp+0x80]
00007eafdc3e0c2b  vmovaps xmm9, [rsp+0x90]
00007eafdc3e0c34  vmovaps xmm10, [rsp+0xA0]
00007eafdc3e0c3d  vmovaps xmm12, [rsp+0xB0]
00007eafdc3e0c46  vmovaps xmm13, [rsp+0xC0]
00007eafdc3e0c4f  vmovaps xmm14, [rsp+0xD0]
00007eafdc3e0c58  vmovaps xmm15, [rsp+0xE0]
00007eafdc3e0c61  add rsp, 0xF0
00007eafdc3e0c68  pop r11
00007eafdc3e0c6a  pop r10
00007eafdc3e0c6c  pop r9
00007eafdc3e0c6e  pop r8
00007eafdc3e0c70  pop rsi
00007eafdc3e0c71  pop rdi
00007eafdc3e0c72  pop rdx
00007eafdc3e0c73  pop rcx
00007eafdc3e0c74  pop rax
00007eafdc3e0c75  add rsp, 0x08
00007eafdc3e0c79  jmp 0x00007EAFDC3DC6A0
00007eafdc3e0c7e  call 0x00007EAFDC2C33A0
00007eafdc3e0c83  jmp 0x00007EAFDC3DC6AA
00007eafdc3e0c88  sub rsp, 0x08
00007eafdc3e0c8c  push rax
00007eafdc3e0c8d  push rcx
00007eafdc3e0c8e  push rdx
00007eafdc3e0c8f  push rdi
00007eafdc3e0c90  push rsi
00007eafdc3e0c91  push r8
00007eafdc3e0c93  push r9
00007eafdc3e0c95  push r10
00007eafdc3e0c97  push r11
00007eafdc3e0c99  sub rsp, 0xF0
00007eafdc3e0ca0  vmovaps [rsp], xmm0
00007eafdc3e0ca5  vmovaps [rsp+0x10], xmm1
00007eafdc3e0cab  vmovaps [rsp+0x20], xmm2
00007eafdc3e0cb1  vmovaps [rsp+0x30], xmm3
00007eafdc3e0cb7  vmovaps [rsp+0x40], xmm4
00007eafdc3e0cbd  vmovaps [rsp+0x50], xmm5
00007eafdc3e0cc3  vmovaps [rsp+0x60], xmm6
00007eafdc3e0cc9  vmovaps [rsp+0x70], xmm7
00007eafdc3e0ccf  vmovaps [rsp+0x80], xmm8
00007eafdc3e0cd8  vmovaps [rsp+0x90], xmm9
00007eafdc3e0ce1  vmovaps [rsp+0xA0], xmm11
00007eafdc3e0cea  vmovaps [rsp+0xB0], xmm12
00007eafdc3e0cf3  vmovaps [rsp+0xC0], xmm13
00007eafdc3e0cfc  vmovaps [rsp+0xD0], xmm14
00007eafdc3e0d05  vmovaps [rsp+0xE0], xmm15
00007eafdc3e0d0e  sub rsp, 0x30
00007eafdc3e0d12  movaps [rsp], xmm10
00007eafdc3e0d17  movaps [rsp+0x10], xmm1
00007eafdc3e0d1c  movaps [rsp+0x20], xmm12
00007eafdc3e0d22  lea rdi, [rsp]
00007eafdc3e0d26  mov esi, 0x00
00007eafdc3e0d2b  mov rax, 0x645891675530
00007eafdc3e0d35  call rax
00007eafdc3e0d37  movaps xmm10, [rsp]
00007eafdc3e0d3c  add rsp, 0x30
00007eafdc3e0d40  vmovaps xmm0, [rsp]
00007eafdc3e0d45  vmovaps xmm1, [rsp+0x10]
00007eafdc3e0d4b  vmovaps xmm2, [rsp+0x20]
00007eafdc3e0d51  vmovaps xmm3, [rsp+0x30]
00007eafdc3e0d57  vmovaps xmm4, [rsp+0x40]
00007eafdc3e0d5d  vmovaps xmm5, [rsp+0x50]
00007eafdc3e0d63  vmovaps xmm6, [rsp+0x60]
00007eafdc3e0d69  vmovaps xmm7, [rsp+0x70]
00007eafdc3e0d6f  vmovaps xmm8, [rsp+0x80]
00007eafdc3e0d78  vmovaps xmm9, [rsp+0x90]
00007eafdc3e0d81  vmovaps xmm11, [rsp+0xA0]
00007eafdc3e0d8a  vmovaps xmm12, [rsp+0xB0]
00007eafdc3e0d93  vmovaps xmm13, [rsp+0xC0]
00007eafdc3e0d9c  vmovaps xmm14, [rsp+0xD0]
00007eafdc3e0da5  vmovaps xmm15, [rsp+0xE0]
00007eafdc3e0dae  add rsp, 0xF0
00007eafdc3e0db5  pop r11
00007eafdc3e0db7  pop r10
00007eafdc3e0db9  pop r9
00007eafdc3e0dbb  pop r8
00007eafdc3e0dbd  pop rsi
00007eafdc3e0dbe  pop rdi
00007eafdc3e0dbf  pop rdx
00007eafdc3e0dc0  pop rcx
00007eafdc3e0dc1  pop rax
00007eafdc3e0dc2  add rsp, 0x08
00007eafdc3e0dc6  jmp 0x00007EAFDC3DC6CD
00007eafdc3e0dcb  sub rsp, 0x08
00007eafdc3e0dcf  push rax
00007eafdc3e0dd0  push rcx
00007eafdc3e0dd1  push rdx
00007eafdc3e0dd2  push rdi
00007eafdc3e0dd3  push rsi
00007eafdc3e0dd4  push r8
00007eafdc3e0dd6  push r9
00007eafdc3e0dd8  push r10
00007eafdc3e0dda  push r11
00007eafdc3e0ddc  sub rsp, 0xF0
00007eafdc3e0de3  vmovaps [rsp], xmm0
00007eafdc3e0de8  vmovaps [rsp+0x10], xmm1
00007eafdc3e0dee  vmovaps [rsp+0x20], xmm2
00007eafdc3e0df4  vmovaps [rsp+0x30], xmm3
00007eafdc3e0dfa  vmovaps [rsp+0x40], xmm4
00007eafdc3e0e00  vmovaps [rsp+0x50], xmm5
00007eafdc3e0e06  vmovaps [rsp+0x60], xmm6
00007eafdc3e0e0c  vmovaps [rsp+0x70], xmm7
00007eafdc3e0e12  vmovaps [rsp+0x80], xmm8
00007eafdc3e0e1b  vmovaps [rsp+0x90], xmm9
00007eafdc3e0e24  vmovaps [rsp+0xA0], xmm10
00007eafdc3e0e2d  vmovaps [rsp+0xB0], xmm11
00007eafdc3e0e36  vmovaps [rsp+0xC0], xmm13
00007eafdc3e0e3f  vmovaps [rsp+0xD0], xmm14
00007eafdc3e0e48  vmovaps [rsp+0xE0], xmm15
00007eafdc3e0e51  sub rsp, 0x30
00007eafdc3e0e55  movaps [rsp], xmm12
00007eafdc3e0e5a  movaps [rsp+0x10], xmm14
00007eafdc3e0e60  movaps [rsp+0x20], xmm1
00007eafdc3e0e65  lea rdi, [rsp]
00007eafdc3e0e69  mov esi, 0x00
00007eafdc3e0e6e  mov rax, 0x645891675530
00007eafdc3e0e78  call rax
00007eafdc3e0e7a  movaps xmm12, [rsp]
00007eafdc3e0e7f  add rsp, 0x30
00007eafdc3e0e83  vmovaps xmm0, [rsp]
00007eafdc3e0e88  vmovaps xmm1, [rsp+0x10]
00007eafdc3e0e8e  vmovaps xmm2, [rsp+0x20]
00007eafdc3e0e94  vmovaps xmm3, [rsp+0x30]
00007eafdc3e0e9a  vmovaps xmm4, [rsp+0x40]
00007eafdc3e0ea0  vmovaps xmm5, [rsp+0x50]
00007eafdc3e0ea6  vmovaps xmm6, [rsp+0x60]
00007eafdc3e0eac  vmovaps xmm7, [rsp+0x70]
00007eafdc3e0eb2  vmovaps xmm8, [rsp+0x80]
00007eafdc3e0ebb  vmovaps xmm9, [rsp+0x90]
00007eafdc3e0ec4  vmovaps xmm10, [rsp+0xA0]
00007eafdc3e0ecd  vmovaps xmm11, [rsp+0xB0]
00007eafdc3e0ed6  vmovaps xmm13, [rsp+0xC0]
00007eafdc3e0edf  vmovaps xmm14, [rsp+0xD0]
00007eafdc3e0ee8  vmovaps xmm15, [rsp+0xE0]
00007eafdc3e0ef1  add rsp, 0xF0
00007eafdc3e0ef8  pop r11
00007eafdc3e0efa  pop r10
00007eafdc3e0efc  pop r9
00007eafdc3e0efe  pop r8
00007eafdc3e0f00  pop rsi
00007eafdc3e0f01  pop rdi
00007eafdc3e0f02  pop rdx
00007eafdc3e0f03  pop rcx
00007eafdc3e0f04  pop rax
00007eafdc3e0f05  add rsp, 0x08
00007eafdc3e0f09  jmp 0x00007EAFDC3DC6FC
00007eafdc3e0f0e  sub rsp, 0x08
00007eafdc3e0f12  push rax
00007eafdc3e0f13  push rcx
00007eafdc3e0f14  push rdx
00007eafdc3e0f15  push rdi
00007eafdc3e0f16  push rsi
00007eafdc3e0f17  push r8
00007eafdc3e0f19  push r9
00007eafdc3e0f1b  push r10
00007eafdc3e0f1d  push r11
00007eafdc3e0f1f  sub rsp, 0xF0
00007eafdc3e0f26  vmovaps [rsp], xmm0
00007eafdc3e0f2b  vmovaps [rsp+0x10], xmm1
00007eafdc3e0f31  vmovaps [rsp+0x20], xmm2
00007eafdc3e0f37  vmovaps [rsp+0x30], xmm3
00007eafdc3e0f3d  vmovaps [rsp+0x40], xmm4
00007eafdc3e0f43  vmovaps [rsp+0x50], xmm5
00007eafdc3e0f49  vmovaps [rsp+0x60], xmm6
00007eafdc3e0f4f  vmovaps [rsp+0x70], xmm7
00007eafdc3e0f55  vmovaps [rsp+0x80], xmm8
00007eafdc3e0f5e  vmovaps [rsp+0x90], xmm9
00007eafdc3e0f67  vmovaps [rsp+0xA0], xmm10
00007eafdc3e0f70  vmovaps [rsp+0xB0], xmm11
00007eafdc3e0f79  vmovaps [rsp+0xC0], xmm12
00007eafdc3e0f82  vmovaps [rsp+0xD0], xmm13
00007eafdc3e0f8b  vmovaps [rsp+0xE0], xmm15
00007eafdc3e0f94  sub rsp, 0x30
00007eafdc3e0f98  movaps [rsp], xmm14
00007eafdc3e0f9d  movaps [rsp+0x10], xmm9
00007eafdc3e0fa3  movaps [rsp+0x20], xmm1
00007eafdc3e0fa8  lea rdi, [rsp]
00007eafdc3e0fac  mov esi, 0x00
00007eafdc3e0fb1  mov rax, 0x645891675530
00007eafdc3e0fbb  call rax
00007eafdc3e0fbd  movaps xmm14, [rsp]
00007eafdc3e0fc2  add rsp, 0x30
00007eafdc3e0fc6  vmovaps xmm0, [rsp]
00007eafdc3e0fcb  vmovaps xmm1, [rsp+0x10]
00007eafdc3e0fd1  vmovaps xmm2, [rsp+0x20]
00007eafdc3e0fd7  vmovaps xmm3, [rsp+0x30]
00007eafdc3e0fdd  vmovaps xmm4, [rsp+0x40]
00007eafdc3e0fe3  vmovaps xmm5, [rsp+0x50]
00007eafdc3e0fe9  vmovaps xmm6, [rsp+0x60]
00007eafdc3e0fef  vmovaps xmm7, [rsp+0x70]
00007eafdc3e0ff5  vmovaps xmm8, [rsp+0x80]
00007eafdc3e0ffe  vmovaps xmm9, [rsp+0x90]
00007eafdc3e1007  vmovaps xmm10, [rsp+0xA0]
00007eafdc3e1010  vmovaps xmm11, [rsp+0xB0]
00007eafdc3e1019  vmovaps xmm12, [rsp+0xC0]
00007eafdc3e1022  vmovaps xmm13, [rsp+0xD0]
00007eafdc3e102b  vmovaps xmm15, [rsp+0xE0]
00007eafdc3e1034  add rsp, 0xF0
00007eafdc3e103b  pop r11
00007eafdc3e103d  pop r10
00007eafdc3e103f  pop r9
00007eafdc3e1041  pop r8
00007eafdc3e1043  pop rsi
00007eafdc3e1044  pop rdi
00007eafdc3e1045  pop rdx
00007eafdc3e1046  pop rcx
00007eafdc3e1047  pop rax
00007eafdc3e1048  add rsp, 0x08
00007eafdc3e104c  jmp 0x00007EAFDC3DC72B
00007eafdc3e1051  sub rsp, 0x08
00007eafdc3e1055  push rax
00007eafdc3e1056  push rcx
00007eafdc3e1057  push rdx
00007eafdc3e1058  push rdi
00007eafdc3e1059  push rsi
00007eafdc3e105a  push r8
00007eafdc3e105c  push r9
00007eafdc3e105e  push r10
00007eafdc3e1060  push r11
00007eafdc3e1062  sub rsp, 0xF0
00007eafdc3e1069  vmovaps [rsp], xmm0
00007eafdc3e106e  vmovaps [rsp+0x10], xmm2
00007eafdc3e1074  vmovaps [rsp+0x20], xmm3
00007eafdc3e107a  vmovaps [rsp+0x30], xmm4
00007eafdc3e1080  vmovaps [rsp+0x40], xmm5
00007eafdc3e1086  vmovaps [rsp+0x50], xmm6
00007eafdc3e108c  vmovaps [rsp+0x60], xmm7
00007eafdc3e1092  vmovaps [rsp+0x70], xmm8
00007eafdc3e1098  vmovaps [rsp+0x80], xmm9
00007eafdc3e10a1  vmovaps [rsp+0x90], xmm10
00007eafdc3e10aa  vmovaps [rsp+0xA0], xmm11
00007eafdc3e10b3  vmovaps [rsp+0xB0], xmm12
00007eafdc3e10bc  vmovaps [rsp+0xC0], xmm13
00007eafdc3e10c5  vmovaps [rsp+0xD0], xmm14
00007eafdc3e10ce  vmovaps [rsp+0xE0], xmm15
00007eafdc3e10d7  sub rsp, 0x30
00007eafdc3e10db  movaps [rsp], xmm1
00007eafdc3e10df  movaps [rsp+0x10], xmm13
00007eafdc3e10e5  movaps [rsp+0x20], xmm8
00007eafdc3e10eb  lea rdi, [rsp]
00007eafdc3e10ef  mov esi, 0x00
00007eafdc3e10f4  mov rax, 0x645891675530
00007eafdc3e10fe  call rax
00007eafdc3e1100  movaps xmm1, [rsp]
00007eafdc3e1104  add rsp, 0x30
00007eafdc3e1108  vmovaps xmm0, [rsp]
00007eafdc3e110d  vmovaps xmm2, [rsp+0x10]
00007eafdc3e1113  vmovaps xmm3, [rsp+0x20]
00007eafdc3e1119  vmovaps xmm4, [rsp+0x30]
00007eafdc3e111f  vmovaps xmm5, [rsp+0x40]
00007eafdc3e1125  vmovaps xmm6, [rsp+0x50]
00007eafdc3e112b  vmovaps xmm7, [rsp+0x60]
00007eafdc3e1131  vmovaps xmm8, [rsp+0x70]
00007eafdc3e1137  vmovaps xmm9, [rsp+0x80]
00007eafdc3e1140  vmovaps xmm10, [rsp+0x90]
00007eafdc3e1149  vmovaps xmm11, [rsp+0xA0]
00007eafdc3e1152  vmovaps xmm12, [rsp+0xB0]
00007eafdc3e115b  vmovaps xmm13, [rsp+0xC0]
00007eafdc3e1164  vmovaps xmm14, [rsp+0xD0]
00007eafdc3e116d  vmovaps xmm15, [rsp+0xE0]
00007eafdc3e1176  add rsp, 0xF0
00007eafdc3e117d  pop r11
00007eafdc3e117f  pop r10
00007eafdc3e1181  pop r9
00007eafdc3e1183  pop r8
00007eafdc3e1185  pop rsi
00007eafdc3e1186  pop rdi
00007eafdc3e1187  pop rdx
00007eafdc3e1188  pop rcx
00007eafdc3e1189  pop rax
00007eafdc3e118a  add rsp, 0x08
00007eafdc3e118e  jmp 0x00007EAFDC3DC74D
00007eafdc3e1193  call 0x00007EAFDC20C260
00007eafdc3e1198  jmp 0x00007EAFDC3DC75B
00007eafdc3e119d  call 0x00007EAFDC2BD750
00007eafdc3e11a2  jmp 0x00007EAFDC3DC765
00007eafdc3e11a7  sub rsp, 0x08
00007eafdc3e11ab  push rax
00007eafdc3e11ac  push rcx
00007eafdc3e11ad  push rdx
00007eafdc3e11ae  push rdi
00007eafdc3e11af  push rsi
00007eafdc3e11b0  push r8
00007eafdc3e11b2  push r9
00007eafdc3e11b4  push r10
00007eafdc3e11b6  push r11
00007eafdc3e11b8  sub rsp, 0xF0
00007eafdc3e11bf  vmovaps [rsp], xmm0
00007eafdc3e11c4  vmovaps [rsp+0x10], xmm1
00007eafdc3e11ca  vmovaps [rsp+0x20], xmm2
00007eafdc3e11d0  vmovaps [rsp+0x30], xmm3
00007eafdc3e11d6  vmovaps [rsp+0x40], xmm4
00007eafdc3e11dc  vmovaps [rsp+0x50], xmm5
00007eafdc3e11e2  vmovaps [rsp+0x60], xmm6
00007eafdc3e11e8  vmovaps [rsp+0x70], xmm7
00007eafdc3e11ee  vmovaps [rsp+0x80], xmm9
00007eafdc3e11f7  vmovaps [rsp+0x90], xmm10
00007eafdc3e1200  vmovaps [rsp+0xA0], xmm11
00007eafdc3e1209  vmovaps [rsp+0xB0], xmm12
00007eafdc3e1212  vmovaps [rsp+0xC0], xmm13
00007eafdc3e121b  vmovaps [rsp+0xD0], xmm14
00007eafdc3e1224  vmovaps [rsp+0xE0], xmm15
00007eafdc3e122d  sub rsp, 0x30
00007eafdc3e1231  movaps [rsp], xmm8
00007eafdc3e1236  movaps [rsp+0x10], xmm15
00007eafdc3e123c  movaps [rsp+0x20], xmm7
00007eafdc3e1241  lea rdi, [rsp]
00007eafdc3e1245  mov esi, 0x00
00007eafdc3e124a  mov rax, 0x645891675530
00007eafdc3e1254  call rax
00007eafdc3e1256  movaps xmm8, [rsp]
00007eafdc3e125b  add rsp, 0x30
00007eafdc3e125f  vmovaps xmm0, [rsp]
00007eafdc3e1264  vmovaps xmm1, [rsp+0x10]
00007eafdc3e126a  vmovaps xmm2, [rsp+0x20]
00007eafdc3e1270  vmovaps xmm3, [rsp+0x30]
00007eafdc3e1276  vmovaps xmm4, [rsp+0x40]
00007eafdc3e127c  vmovaps xmm5, [rsp+0x50]
00007eafdc3e1282  vmovaps xmm6, [rsp+0x60]
00007eafdc3e1288  vmovaps xmm7, [rsp+0x70]
00007eafdc3e128e  vmovaps xmm9, [rsp+0x80]
00007eafdc3e1297  vmovaps xmm10, [rsp+0x90]
00007eafdc3e12a0  vmovaps xmm11, [rsp+0xA0]
00007eafdc3e12a9  vmovaps xmm12, [rsp+0xB0]
00007eafdc3e12b2  vmovaps xmm13, [rsp+0xC0]
00007eafdc3e12bb  vmovaps xmm14, [rsp+0xD0]
00007eafdc3e12c4  vmovaps xmm15, [rsp+0xE0]
00007eafdc3e12cd  add rsp, 0xF0
00007eafdc3e12d4  pop r11
00007eafdc3e12d6  pop r10
00007eafdc3e12d8  pop r9
00007eafdc3e12da  pop r8
00007eafdc3e12dc  pop rsi
00007eafdc3e12dd  pop rdi
00007eafdc3e12de  pop rdx
00007eafdc3e12df  pop rcx
00007eafdc3e12e0  pop rax
00007eafdc3e12e1  add rsp, 0x08
00007eafdc3e12e5  jmp 0x00007EAFDC3DC787
00007eafdc3e12ea  sub rsp, 0x08
00007eafdc3e12ee  push rax
00007eafdc3e12ef  push rcx
00007eafdc3e12f0  push rdx
00007eafdc3e12f1  push rdi
00007eafdc3e12f2  push rsi
00007eafdc3e12f3  push r8
00007eafdc3e12f5  push r9
00007eafdc3e12f7  push r10
00007eafdc3e12f9  push r11
00007eafdc3e12fb  sub rsp, 0xF0
00007eafdc3e1302  vmovaps [rsp], xmm0
00007eafdc3e1307  vmovaps [rsp+0x10], xmm1
00007eafdc3e130d  vmovaps [rsp+0x20], xmm2
00007eafdc3e1313  vmovaps [rsp+0x30], xmm3
00007eafdc3e1319  vmovaps [rsp+0x40], xmm4
00007eafdc3e131f  vmovaps [rsp+0x50], xmm5
00007eafdc3e1325  vmovaps [rsp+0x60], xmm6
00007eafdc3e132b  vmovaps [rsp+0x70], xmm8
00007eafdc3e1331  vmovaps [rsp+0x80], xmm9
00007eafdc3e133a  vmovaps [rsp+0x90], xmm10
00007eafdc3e1343  vmovaps [rsp+0xA0], xmm11
00007eafdc3e134c  vmovaps [rsp+0xB0], xmm12
00007eafdc3e1355  vmovaps [rsp+0xC0], xmm13
00007eafdc3e135e  vmovaps [rsp+0xD0], xmm14
00007eafdc3e1367  vmovaps [rsp+0xE0], xmm15
00007eafdc3e1370  sub rsp, 0x30
00007eafdc3e1374  movaps [rsp], xmm7
00007eafdc3e1378  movaps [rsp+0x10], xmm9
00007eafdc3e137e  movaps [rsp+0x20], xmm15
00007eafdc3e1384  lea rdi, [rsp]
00007eafdc3e1388  mov esi, 0x00
00007eafdc3e138d  mov rax, 0x645891675530
00007eafdc3e1397  call rax
00007eafdc3e1399  movaps xmm7, [rsp]
00007eafdc3e139d  add rsp, 0x30
00007eafdc3e13a1  vmovaps xmm0, [rsp]
00007eafdc3e13a6  vmovaps xmm1, [rsp+0x10]
00007eafdc3e13ac  vmovaps xmm2, [rsp+0x20]
00007eafdc3e13b2  vmovaps xmm3, [rsp+0x30]
00007eafdc3e13b8  vmovaps xmm4, [rsp+0x40]
00007eafdc3e13be  vmovaps xmm5, [rsp+0x50]
00007eafdc3e13c4  vmovaps xmm6, [rsp+0x60]
00007eafdc3e13ca  vmovaps xmm8, [rsp+0x70]
00007eafdc3e13d0  vmovaps xmm9, [rsp+0x80]
00007eafdc3e13d9  vmovaps xmm10, [rsp+0x90]
00007eafdc3e13e2  vmovaps xmm11, [rsp+0xA0]
00007eafdc3e13eb  vmovaps xmm12, [rsp+0xB0]
00007eafdc3e13f4  vmovaps xmm13, [rsp+0xC0]
00007eafdc3e13fd  vmovaps xmm14, [rsp+0xD0]
00007eafdc3e1406  vmovaps xmm15, [rsp+0xE0]
00007eafdc3e140f  add rsp, 0xF0
00007eafdc3e1416  pop r11
00007eafdc3e1418  pop r10
00007eafdc3e141a  pop r9
00007eafdc3e141c  pop r8
00007eafdc3e141e  pop rsi
00007eafdc3e141f  pop rdi
00007eafdc3e1420  pop rdx
00007eafdc3e1421  pop rcx
00007eafdc3e1422  pop rax
00007eafdc3e1423  add rsp, 0x08
00007eafdc3e1427  jmp 0x00007EAFDC3DC7B4
00007eafdc3e142c  sub rsp, 0x08
00007eafdc3e1430  push rax
00007eafdc3e1431  push rcx
00007eafdc3e1432  push rdx
00007eafdc3e1433  push rdi
00007eafdc3e1434  push rsi
00007eafdc3e1435  push r8
00007eafdc3e1437  push r9
00007eafdc3e1439  push r10
00007eafdc3e143b  push r11
00007eafdc3e143d  sub rsp, 0xF0
00007eafdc3e1444  vmovaps [rsp], xmm0
00007eafdc3e1449  vmovaps [rsp+0x10], xmm1
00007eafdc3e144f  vmovaps [rsp+0x20], xmm2
00007eafdc3e1455  vmovaps [rsp+0x30], xmm3
00007eafdc3e145b  vmovaps [rsp+0x40], xmm4
00007eafdc3e1461  vmovaps [rsp+0x50], xmm5
00007eafdc3e1467  vmovaps [rsp+0x60], xmm6
00007eafdc3e146d  vmovaps [rsp+0x70], xmm7
00007eafdc3e1473  vmovaps [rsp+0x80], xmm8
00007eafdc3e147c  vmovaps [rsp+0x90], xmm10
00007eafdc3e1485  vmovaps [rsp+0xA0], xmm11
00007eafdc3e148e  vmovaps [rsp+0xB0], xmm12
00007eafdc3e1497  vmovaps [rsp+0xC0], xmm13
00007eafdc3e14a0  vmovaps [rsp+0xD0], xmm14
00007eafdc3e14a9  vmovaps [rsp+0xE0], xmm15
00007eafdc3e14b2  sub rsp, 0x30
00007eafdc3e14b6  movaps [rsp], xmm9
00007eafdc3e14bb  movaps [rsp+0x10], xmm13
00007eafdc3e14c1  movaps [rsp+0x20], xmm15
00007eafdc3e14c7  lea rdi, [rsp]
00007eafdc3e14cb  mov esi, 0x00
00007eafdc3e14d0  mov rax, 0x645891675530
00007eafdc3e14da  call rax
00007eafdc3e14dc  movaps xmm9, [rsp]
00007eafdc3e14e1  add rsp, 0x30
00007eafdc3e14e5  vmovaps xmm0, [rsp]
00007eafdc3e14ea  vmovaps xmm1, [rsp+0x10]
00007eafdc3e14f0  vmovaps xmm2, [rsp+0x20]
00007eafdc3e14f6  vmovaps xmm3, [rsp+0x30]
00007eafdc3e14fc  vmovaps xmm4, [rsp+0x40]
00007eafdc3e1502  vmovaps xmm5, [rsp+0x50]
00007eafdc3e1508  vmovaps xmm6, [rsp+0x60]
00007eafdc3e150e  vmovaps xmm7, [rsp+0x70]
00007eafdc3e1514  vmovaps xmm8, [rsp+0x80]
00007eafdc3e151d  vmovaps xmm10, [rsp+0x90]
00007eafdc3e1526  vmovaps xmm11, [rsp+0xA0]
00007eafdc3e152f  vmovaps xmm12, [rsp+0xB0]
00007eafdc3e1538  vmovaps xmm13, [rsp+0xC0]
00007eafdc3e1541  vmovaps xmm14, [rsp+0xD0]
00007eafdc3e154a  vmovaps xmm15, [rsp+0xE0]
00007eafdc3e1553  add rsp, 0xF0
00007eafdc3e155a  pop r11
00007eafdc3e155c  pop r10
00007eafdc3e155e  pop r9
00007eafdc3e1560  pop r8
00007eafdc3e1562  pop rsi
00007eafdc3e1563  pop rdi
00007eafdc3e1564  pop rdx
00007eafdc3e1565  pop rcx
00007eafdc3e1566  pop rax
00007eafdc3e1567  add rsp, 0x08
00007eafdc3e156b  jmp 0x00007EAFDC3DC7E2
00007eafdc3e1570  sub rsp, 0x08
00007eafdc3e1574  push rax
00007eafdc3e1575  push rcx
00007eafdc3e1576  push rdx
00007eafdc3e1577  push rdi
00007eafdc3e1578  push rsi
00007eafdc3e1579  push r8
00007eafdc3e157b  push r9
00007eafdc3e157d  push r10
00007eafdc3e157f  push r11
00007eafdc3e1581  sub rsp, 0xF0
00007eafdc3e1588  vmovaps [rsp], xmm0
00007eafdc3e158d  vmovaps [rsp+0x10], xmm1
00007eafdc3e1593  vmovaps [rsp+0x20], xmm2
00007eafdc3e1599  vmovaps [rsp+0x30], xmm3
00007eafdc3e159f  vmovaps [rsp+0x40], xmm4
00007eafdc3e15a5  vmovaps [rsp+0x50], xmm5
00007eafdc3e15ab  vmovaps [rsp+0x60], xmm6
00007eafdc3e15b1  vmovaps [rsp+0x70], xmm7
00007eafdc3e15b7  vmovaps [rsp+0x80], xmm8
00007eafdc3e15c0  vmovaps [rsp+0x90], xmm9
00007eafdc3e15c9  vmovaps [rsp+0xA0], xmm10
00007eafdc3e15d2  vmovaps [rsp+0xB0], xmm11
00007eafdc3e15db  vmovaps [rsp+0xC0], xmm12
00007eafdc3e15e4  vmovaps [rsp+0xD0], xmm13
00007eafdc3e15ed  vmovaps [rsp+0xE0], xmm14
00007eafdc3e15f6  sub rsp, 0x30
00007eafdc3e15fa  movaps [rsp], xmm15
00007eafdc3e15ff  movaps [rsp+0x10], xmm11
00007eafdc3e1605  movaps [rsp+0x20], xmm12
00007eafdc3e160b  lea rdi, [rsp]
00007eafdc3e160f  mov esi, 0x00
00007eafdc3e1614  mov rax, 0x645891675530
00007eafdc3e161e  call rax
00007eafdc3e1620  movaps xmm15, [rsp]
00007eafdc3e1625  add rsp, 0x30
00007eafdc3e1629  vmovaps xmm0, [rsp]
00007eafdc3e162e  vmovaps xmm1, [rsp+0x10]
00007eafdc3e1634  vmovaps xmm2, [rsp+0x20]
00007eafdc3e163a  vmovaps xmm3, [rsp+0x30]
00007eafdc3e1640  vmovaps xmm4, [rsp+0x40]
00007eafdc3e1646  vmovaps xmm5, [rsp+0x50]
00007eafdc3e164c  vmovaps xmm6, [rsp+0x60]
00007eafdc3e1652  vmovaps xmm7, [rsp+0x70]
00007eafdc3e1658  vmovaps xmm8, [rsp+0x80]
00007eafdc3e1661  vmovaps xmm9, [rsp+0x90]
00007eafdc3e166a  vmovaps xmm10, [rsp+0xA0]
00007eafdc3e1673  vmovaps xmm11, [rsp+0xB0]
00007eafdc3e167c  vmovaps xmm12, [rsp+0xC0]
00007eafdc3e1685  vmovaps xmm13, [rsp+0xD0]
00007eafdc3e168e  vmovaps xmm14, [rsp+0xE0]
00007eafdc3e1697  add rsp, 0xF0
00007eafdc3e169e  pop r11
00007eafdc3e16a0  pop r10
00007eafdc3e16a2  pop r9
00007eafdc3e16a4  pop r8
00007eafdc3e16a6  pop rsi
00007eafdc3e16a7  pop rdi
00007eafdc3e16a8  pop rdx
00007eafdc3e16a9  pop rcx
00007eafdc3e16aa  pop rax
00007eafdc3e16ab  add rsp, 0x08
00007eafdc3e16af  jmp 0x00007EAFDC3DC7FD
00007eafdc3e16b4  sub rsp, 0x08
00007eafdc3e16b8  push rax
00007eafdc3e16b9  push rcx
00007eafdc3e16ba  push rdx
00007eafdc3e16bb  push rdi
00007eafdc3e16bc  push rsi
00007eafdc3e16bd  push r8
00007eafdc3e16bf  push r9
00007eafdc3e16c1  push r10
00007eafdc3e16c3  push r11
00007eafdc3e16c5  sub rsp, 0xF0
00007eafdc3e16cc  vmovaps [rsp], xmm0
00007eafdc3e16d1  vmovaps [rsp+0x10], xmm1
00007eafdc3e16d7  vmovaps [rsp+0x20], xmm2
00007eafdc3e16dd  vmovaps [rsp+0x30], xmm3
00007eafdc3e16e3  vmovaps [rsp+0x40], xmm4
00007eafdc3e16e9  vmovaps [rsp+0x50], xmm5
00007eafdc3e16ef  vmovaps [rsp+0x60], xmm6
00007eafdc3e16f5  vmovaps [rsp+0x70], xmm7
00007eafdc3e16fb  vmovaps [rsp+0x80], xmm8
00007eafdc3e1704  vmovaps [rsp+0x90], xmm9
00007eafdc3e170d  vmovaps [rsp+0xA0], xmm10
00007eafdc3e1716  vmovaps [rsp+0xB0], xmm11
00007eafdc3e171f  vmovaps [rsp+0xC0], xmm12
00007eafdc3e1728  vmovaps [rsp+0xD0], xmm14
00007eafdc3e1731  vmovaps [rsp+0xE0], xmm15
00007eafdc3e173a  sub rsp, 0x30
00007eafdc3e173e  movaps [rsp], xmm13
00007eafdc3e1743  movaps [rsp+0x10], xmm10
00007eafdc3e1749  movaps [rsp+0x20], xmm14
00007eafdc3e174f  lea rdi, [rsp]
00007eafdc3e1753  mov esi, 0x00
00007eafdc3e1758  mov rax, 0x645891675530
00007eafdc3e1762  call rax
00007eafdc3e1764  movaps xmm13, [rsp]
00007eafdc3e1769  add rsp, 0x30
00007eafdc3e176d  vmovaps xmm0, [rsp]
00007eafdc3e1772  vmovaps xmm1, [rsp+0x10]
00007eafdc3e1778  vmovaps xmm2, [rsp+0x20]
00007eafdc3e177e  vmovaps xmm3, [rsp+0x30]
00007eafdc3e1784  vmovaps xmm4, [rsp+0x40]
00007eafdc3e178a  vmovaps xmm5, [rsp+0x50]
00007eafdc3e1790  vmovaps xmm6, [rsp+0x60]
00007eafdc3e1796  vmovaps xmm7, [rsp+0x70]
00007eafdc3e179c  vmovaps xmm8, [rsp+0x80]
00007eafdc3e17a5  vmovaps xmm9, [rsp+0x90]
00007eafdc3e17ae  vmovaps xmm10, [rsp+0xA0]
00007eafdc3e17b7  vmovaps xmm11, [rsp+0xB0]
00007eafdc3e17c0  vmovaps xmm12, [rsp+0xC0]
00007eafdc3e17c9  vmovaps xmm14, [rsp+0xD0]
00007eafdc3e17d2  vmovaps xmm15, [rsp+0xE0]
00007eafdc3e17db  add rsp, 0xF0
00007eafdc3e17e2  pop r11
00007eafdc3e17e4  pop r10
00007eafdc3e17e6  pop r9
00007eafdc3e17e8  pop r8
00007eafdc3e17ea  pop rsi
00007eafdc3e17eb  pop rdi
00007eafdc3e17ec  pop rdx
00007eafdc3e17ed  pop rcx
00007eafdc3e17ee  pop rax
00007eafdc3e17ef  add rsp, 0x08
00007eafdc3e17f3  jmp 0x00007EAFDC3DC820
00007eafdc3e17f8  sub rsp, 0x08
00007eafdc3e17fc  push rax
00007eafdc3e17fd  push rcx
00007eafdc3e17fe  push rdx
00007eafdc3e17ff  push rdi
00007eafdc3e1800  push rsi
00007eafdc3e1801  push r8
00007eafdc3e1803  push r9
00007eafdc3e1805  push r10
00007eafdc3e1807  push r11
00007eafdc3e1809  sub rsp, 0xF0
00007eafdc3e1810  vmovaps [rsp], xmm0
00007eafdc3e1815  vmovaps [rsp+0x10], xmm1
00007eafdc3e181b  vmovaps [rsp+0x20], xmm2
00007eafdc3e1821  vmovaps [rsp+0x30], xmm3
00007eafdc3e1827  vmovaps [rsp+0x40], xmm4
00007eafdc3e182d  vmovaps [rsp+0x50], xmm5
00007eafdc3e1833  vmovaps [rsp+0x60], xmm6
00007eafdc3e1839  vmovaps [rsp+0x70], xmm7
00007eafdc3e183f  vmovaps [rsp+0x80], xmm8
00007eafdc3e1848  vmovaps [rsp+0x90], xmm9
00007eafdc3e1851  vmovaps [rsp+0xA0], xmm10
00007eafdc3e185a  vmovaps [rsp+0xB0], xmm11
00007eafdc3e1863  vmovaps [rsp+0xC0], xmm12
00007eafdc3e186c  vmovaps [rsp+0xD0], xmm13
00007eafdc3e1875  vmovaps [rsp+0xE0], xmm15
00007eafdc3e187e  sub rsp, 0x30
00007eafdc3e1882  movaps [rsp], xmm14
00007eafdc3e1887  movaps [rsp+0x10], xmm1
00007eafdc3e188c  movaps [rsp+0x20], xmm7
00007eafdc3e1891  lea rdi, [rsp]
00007eafdc3e1895  mov esi, 0x00
00007eafdc3e189a  mov rax, 0x645891675530
00007eafdc3e18a4  call rax
00007eafdc3e18a6  movaps xmm14, [rsp]
00007eafdc3e18ab  add rsp, 0x30
00007eafdc3e18af  vmovaps xmm0, [rsp]
00007eafdc3e18b4  vmovaps xmm1, [rsp+0x10]
00007eafdc3e18ba  vmovaps xmm2, [rsp+0x20]
00007eafdc3e18c0  vmovaps xmm3, [rsp+0x30]
00007eafdc3e18c6  vmovaps xmm4, [rsp+0x40]
00007eafdc3e18cc  vmovaps xmm5, [rsp+0x50]
00007eafdc3e18d2  vmovaps xmm6, [rsp+0x60]
00007eafdc3e18d8  vmovaps xmm7, [rsp+0x70]
00007eafdc3e18de  vmovaps xmm8, [rsp+0x80]
00007eafdc3e18e7  vmovaps xmm9, [rsp+0x90]
00007eafdc3e18f0  vmovaps xmm10, [rsp+0xA0]
00007eafdc3e18f9  vmovaps xmm11, [rsp+0xB0]
00007eafdc3e1902  vmovaps xmm12, [rsp+0xC0]
00007eafdc3e190b  vmovaps xmm13, [rsp+0xD0]
00007eafdc3e1914  vmovaps xmm15, [rsp+0xE0]
00007eafdc3e191d  add rsp, 0xF0
00007eafdc3e1924  pop r11
00007eafdc3e1926  pop r10
00007eafdc3e1928  pop r9
00007eafdc3e192a  pop r8
00007eafdc3e192c  pop rsi
00007eafdc3e192d  pop rdi
00007eafdc3e192e  pop rdx
00007eafdc3e192f  pop rcx
00007eafdc3e1930  pop rax
00007eafdc3e1931  add rsp, 0x08
00007eafdc3e1935  jmp 0x00007EAFDC3DC843
00007eafdc3e193a  sub rsp, 0x08
00007eafdc3e193e  push rax
00007eafdc3e193f  push rcx
00007eafdc3e1940  push rdx
00007eafdc3e1941  push rdi
00007eafdc3e1942  push rsi
00007eafdc3e1943  push r8
00007eafdc3e1945  push r9
00007eafdc3e1947  push r10
00007eafdc3e1949  push r11
00007eafdc3e194b  sub rsp, 0xF0
00007eafdc3e1952  vmovaps [rsp], xmm0
00007eafdc3e1957  vmovaps [rsp+0x10], xmm2
00007eafdc3e195d  vmovaps [rsp+0x20], xmm3
00007eafdc3e1963  vmovaps [rsp+0x30], xmm4
00007eafdc3e1969  vmovaps [rsp+0x40], xmm5
00007eafdc3e196f  vmovaps [rsp+0x50], xmm6
00007eafdc3e1975  vmovaps [rsp+0x60], xmm7
00007eafdc3e197b  vmovaps [rsp+0x70], xmm8
00007eafdc3e1981  vmovaps [rsp+0x80], xmm9
00007eafdc3e198a  vmovaps [rsp+0x90], xmm10
00007eafdc3e1993  vmovaps [rsp+0xA0], xmm11
00007eafdc3e199c  vmovaps [rsp+0xB0], xmm12
00007eafdc3e19a5  vmovaps [rsp+0xC0], xmm13
00007eafdc3e19ae  vmovaps [rsp+0xD0], xmm14
00007eafdc3e19b7  vmovaps [rsp+0xE0], xmm15
00007eafdc3e19c0  sub rsp, 0x30
00007eafdc3e19c4  movaps [rsp], xmm1
00007eafdc3e19c8  movaps [rsp+0x10], xmm8
00007eafdc3e19ce  movaps [rsp+0x20], xmm9
00007eafdc3e19d4  lea rdi, [rsp]
00007eafdc3e19d8  mov esi, 0x00
00007eafdc3e19dd  mov rax, 0x645891675530
00007eafdc3e19e7  call rax
00007eafdc3e19e9  movaps xmm1, [rsp]
00007eafdc3e19ed  add rsp, 0x30
00007eafdc3e19f1  vmovaps xmm0, [rsp]
00007eafdc3e19f6  vmovaps xmm2, [rsp+0x10]
00007eafdc3e19fc  vmovaps xmm3, [rsp+0x20]
00007eafdc3e1a02  vmovaps xmm4, [rsp+0x30]
00007eafdc3e1a08  vmovaps xmm5, [rsp+0x40]
00007eafdc3e1a0e  vmovaps xmm6, [rsp+0x50]
00007eafdc3e1a14  vmovaps xmm7, [rsp+0x60]
00007eafdc3e1a1a  vmovaps xmm8, [rsp+0x70]
00007eafdc3e1a20  vmovaps xmm9, [rsp+0x80]
00007eafdc3e1a29  vmovaps xmm10, [rsp+0x90]
00007eafdc3e1a32  vmovaps xmm11, [rsp+0xA0]
00007eafdc3e1a3b  vmovaps xmm12, [rsp+0xB0]
00007eafdc3e1a44  vmovaps xmm13, [rsp+0xC0]
00007eafdc3e1a4d  vmovaps xmm14, [rsp+0xD0]
00007eafdc3e1a56  vmovaps xmm15, [rsp+0xE0]
00007eafdc3e1a5f  add rsp, 0xF0
00007eafdc3e1a66  pop r11
00007eafdc3e1a68  pop r10
00007eafdc3e1a6a  pop r9
00007eafdc3e1a6c  pop r8
00007eafdc3e1a6e  pop rsi
00007eafdc3e1a6f  pop rdi
00007eafdc3e1a70  pop rdx
00007eafdc3e1a71  pop rcx
00007eafdc3e1a72  pop rax
00007eafdc3e1a73  add rsp, 0x08
00007eafdc3e1a77  jmp 0x00007EAFDC3DC865
00007eafdc3e1a7c  call 0x00007EAFDC2E5940
00007eafdc3e1a81  jmp 0x00007EAFDC3DC873
00007eafdc3e1a86  call 0x00007EAFDC20C380
00007eafdc3e1a8b  jmp 0x00007EAFDC3DC87D
00007eafdc3e1a90  call 0x00007EAFDC20D600
00007eafdc3e1a95  jmp 0x00007EAFDC3DC887
00007eafdc3e1a9a  call 0x00007EAFDC1FF540
00007eafdc3e1a9f  jmp 0x00007EAFDC3DC891
00007eafdc3e1aa4  int3
00007eafdc3e1aa5  nop [rax+rax*1], ax
00007eafdc3e1aae  nop
00007eafdc3e1ab0  mov rax, [r15+0xF8]
00007eafdc3e1ab7  lea r14, [rax+0x140]
00007eafdc3e1abe  mov r12, [r13+r14*1]
00007eafdc3e1ac3  mov [r15+0xE8], r12
00007eafdc3e1aca  lea r14, [rax+0x130]
00007eafdc3e1ad1  mov r12, [r13+r14*1]
00007eafdc3e1ad6  lea r14, [rax+0x138]
00007eafdc3e1add  mov r11, [r13+r14*1]
00007eafdc3e1ae2  movq xmm1, r12
00007eafdc3e1ae7  movq xmm15, r11
00007eafdc3e1aec  movq xmm1, xmm1
00007eafdc3e1af0  movq xmm1, xmm1
00007eafdc3e1af4  movaps [r15+0x1A0], xmm1
00007eafdc3e1afc  movq xmm15, xmm15
00007eafdc3e1b01  movq xmm15, xmm15
00007eafdc3e1b06  movaps [r15+0x190], xmm15
00007eafdc3e1b0e  lea r14, [rax+0x120]
00007eafdc3e1b15  mov r12, [r13+r14*1]
00007eafdc3e1b1a  lea r14, [rax+0x128]
00007eafdc3e1b21  mov r11, [r13+r14*1]
00007eafdc3e1b26  movq xmm1, r12
00007eafdc3e1b2b  movq xmm15, r11
00007eafdc3e1b30  movq xmm1, xmm1
00007eafdc3e1b34  movq xmm1, xmm1
00007eafdc3e1b38  movaps [r15+0x1C0], xmm1
00007eafdc3e1b40  movq xmm15, xmm15
00007eafdc3e1b45  movq xmm15, xmm15
00007eafdc3e1b4a  movaps [r15+0x1B0], xmm15
00007eafdc3e1b52  lea r14, [rax+0x110]
00007eafdc3e1b59  mov r12, [r13+r14*1]
00007eafdc3e1b5e  lea r14, [rax+0x118]
00007eafdc3e1b65  mov r11, [r13+r14*1]
00007eafdc3e1b6a  movq xmm1, r12
00007eafdc3e1b6f  movq xmm15, r11
00007eafdc3e1b74  movq xmm1, xmm1
00007eafdc3e1b78  movq xmm1, xmm1
00007eafdc3e1b7c  movaps [r15+0x1E0], xmm1
00007eafdc3e1b84  movq xmm15, xmm15
00007eafdc3e1b89  movq xmm15, xmm15
00007eafdc3e1b8e  movaps [r15+0x1D0], xmm15
00007eafdc3e1b96  lea r14, [rax+0x100]
00007eafdc3e1b9d  mov r12, [r13+r14*1]
00007eafdc3e1ba2  lea r14, [rax+0x108]
00007eafdc3e1ba9  mov r11, [r13+r14*1]
00007eafdc3e1bae  movq xmm1, r12
00007eafdc3e1bb3  movq xmm15, r11
00007eafdc3e1bb8  movq xmm1, xmm1
00007eafdc3e1bbc  movq xmm1, xmm1
00007eafdc3e1bc0  movaps [r15+0x200], xmm1
00007eafdc3e1bc8  movq xmm15, xmm15
00007eafdc3e1bcd  movq xmm15, xmm15
00007eafdc3e1bd2  movaps [r15+0x1F0], xmm15
00007eafdc3e1bda  mov qword ptr [r15+0x40], 0x430000
00007eafdc3e1be2  mov r14d, 0x430510
00007eafdc3e1be8  mov r12, [r13+r14*1]
00007eafdc3e1bed  movq xmm1, r12
00007eafdc3e1bf2  lea r14, [rax+0x150]
00007eafdc3e1bf9  mov [r15+0xF8], r14
00007eafdc3e1c00  mov rax, [r15+0x50]
00007eafdc3e1c04  movups xmm15, [r13+rax*1]
00007eafdc3e1c0a  movaps [r15+0x120], xmm15
00007eafdc3e1c12  mov qword ptr [r15+0x48], 0x10
00007eafdc3e1c1a  xor eax, eax
00007eafdc3e1c1c  mov r14d, 0x10
00007eafdc3e1c22  mov r12d, 0x200
00007eafdc3e1c28  cmp r14, r12
00007eafdc3e1c2b  cmc
00007eafdc3e1c2c  lahf
00007eafdc3e1c2d  seto al
00007eafdc3e1c30  mov [r15+0x108], eax
00007eafdc3e1c37  pextrq rax, xmm15, 0x01
00007eafdc3e1c3e  movq xmm14, rax
00007eafdc3e1c43  movaps [r15+0x130], xmm14
00007eafdc3e1c4b  movq rax, xmm1
00007eafdc3e1c50  movq r14, xmm15
00007eafdc3e1c55  vmovq xmm1, rax
00007eafdc3e1c5a  vmovq xmm15, r14
00007eafdc3e1c5f  movaps xmm13, xmm1
00007eafdc3e1c63  addsd xmm13, xmm15
00007eafdc3e1c68  ucomisd xmm13, xmm13
00007eafdc3e1c6d  jp 0x00007EAFDC3E1D86
00007eafdc3e1c73  movq xmm13, xmm13
00007eafdc3e1c78  movq rax, xmm13
00007eafdc3e1c7d  movq r14, xmm14
00007eafdc3e1c82  vmovq xmm1, rax
00007eafdc3e1c87  vmovq xmm15, r14
00007eafdc3e1c8c  movaps xmm14, xmm1
00007eafdc3e1c90  addsd xmm14, xmm15
00007eafdc3e1c95  ucomisd xmm14, xmm14
00007eafdc3e1c9a  jp 0x00007EAFDC3E1DCE
00007eafdc3e1ca0  movq xmm14, xmm14
00007eafdc3e1ca5  movaps [r15+0x110], xmm14
00007eafdc3e1cad  mov eax, [r15+0x108]
00007eafdc3e1cb4  sahf
00007eafdc3e1cb5  jnz 0x00007EAFDC3E1CE7
00007eafdc3e1cb7  cmp dword ptr [r15+0x318], 0x00
00007eafdc3e1cbf  jz 0x00007EAFDC3E1FE0
00007eafdc3e1cc5  nop [rax+rax*1], ax
00007eafdc3e1cce  nop [rax+rax*1], eax
00007eafdc3e1cd6  mov eax, 0x410490
00007eafdc3e1cdb  mov [r15+0x100], rax
00007eafdc3e1ce2  jmp 0x00007EAFDC1FE110
00007eafdc3e1ce7  cmp dword ptr [r15+0x318], 0x00
00007eafdc3e1cef  jz 0x00007EAFDC3E1E20
00007eafdc3e1cf5  nop [rax+rax*1], ax
00007eafdc3e1cfe  nop [rax+rax*1], eax
00007eafdc3e1d06  mov eax, 0x410474
00007eafdc3e1d0b  mov [r15+0x100], rax
00007eafdc3e1d12  jmp 0x00007EAFDC1FE110
00007eafdc3e1d17  int3
00007eafdc3e1d18  call 0x00007EAFDC2E27E0
00007eafdc3e1d1d  jmp 0x00007EAFDC3E1AC3
00007eafdc3e1d22  call 0x00007EAFDC2E27E0
00007eafdc3e1d27  jmp 0x00007EAFDC3E1AD6
00007eafdc3e1d2c  call 0x00007EAFDC2E1570
00007eafdc3e1d31  jmp 0x00007EAFDC3E1AE2
00007eafdc3e1d36  call 0x00007EAFDC2E27E0
00007eafdc3e1d3b  jmp 0x00007EAFDC3E1B1A
00007eafdc3e1d40  call 0x00007EAFDC2E1570
00007eafdc3e1d45  jmp 0x00007EAFDC3E1B26
00007eafdc3e1d4a  call 0x00007EAFDC2E27E0
00007eafdc3e1d4f  jmp 0x00007EAFDC3E1B5E
00007eafdc3e1d54  call 0x00007EAFDC2E1570
00007eafdc3e1d59  jmp 0x00007EAFDC3E1B6A
00007eafdc3e1d5e  call 0x00007EAFDC2E27E0
00007eafdc3e1d63  jmp 0x00007EAFDC3E1BA2
00007eafdc3e1d68  call 0x00007EAFDC2E1570
00007eafdc3e1d6d  jmp 0x00007EAFDC3E1BAE
00007eafdc3e1d72  call 0x00007EAFDC2E27E0
00007eafdc3e1d77  jmp 0x00007EAFDC3E1BED
00007eafdc3e1d7c  call 0x00007EAFDC20E760
00007eafdc3e1d81  jmp 0x00007EAFDC3E1C0A
00007eafdc3e1d86  ucomisd xmm1, xmm15
00007eafdc3e1d8b  jp 0x00007EAFDC3E1D9A
00007eafdc3e1d8d  movaps xmm13, [0x00007EAFDBFFE060]
00007eafdc3e1d95  jmp 0x00007EAFDC3E1C73
00007eafdc3e1d9a  vxorps xmm0, xmm1, xmm15
00007eafdc3e1d9f  pextrw eax, xmm0, 0x03
00007eafdc3e1da4  and eax, 0x7FF8
00007eafdc3e1da9  cmp eax, 0x08
00007eafdc3e1dac  jnz 0x00007EAFDC3E1C73
00007eafdc3e1db2  movq rax, xmm15
00007eafdc3e1db7  shl rax, 0x0D
00007eafdc3e1dbb  jbe 0x00007EAFDC3E1C73
00007eafdc3e1dc1  vorps xmm13, xmm15, [0x00007EAFDBFFE070]
00007eafdc3e1dc9  jmp 0x00007EAFDC3E1C73
00007eafdc3e1dce  ucomisd xmm1, xmm15
00007eafdc3e1dd3  jp 0x00007EAFDC3E1DE2
00007eafdc3e1dd5  movaps xmm14, [0x00007EAFDBFFE060]
00007eafdc3e1ddd  jmp 0x00007EAFDC3E1CA0
00007eafdc3e1de2  vxorps xmm0, xmm1, xmm15
00007eafdc3e1de7  pextrw eax, xmm0, 0x03
00007eafdc3e1dec  and eax, 0x7FF8
00007eafdc3e1df1  cmp eax, 0x08
00007eafdc3e1df4  jnz 0x00007EAFDC3E1CA0
00007eafdc3e1dfa  movq rax, xmm15
00007eafdc3e1dff  shl rax, 0x0D
00007eafdc3e1e03  jbe 0x00007EAFDC3E1CA0
00007eafdc3e1e09  vorps xmm14, xmm15, [0x00007EAFDBFFE070]
00007eafdc3e1e11  jmp 0x00007EAFDC3E1CA0
00007eafdc3e1e16  int3
00007eafdc3e1e17  nop [rax+rax*1], ax
00007eafdc3e1e20  mov rax, [r15+0x48]
00007eafdc3e1e24  mov r14, [r15+0x50]
00007eafdc3e1e28  lea r12, [r14+rax*1]
00007eafdc3e1e2c  movups xmm1, [r13+r12*1]
00007eafdc3e1e32  movaps [r15+0x120], xmm1
00007eafdc3e1e3a  lea r14, [rax+0x10]
00007eafdc3e1e3e  mov [r15+0x48], r14
00007eafdc3e1e42  xor eax, eax
00007eafdc3e1e44  mov r12d, 0x200
00007eafdc3e1e4a  cmp r14, r12
00007eafdc3e1e4d  cmc
00007eafdc3e1e4e  lahf
00007eafdc3e1e4f  seto al
00007eafdc3e1e52  mov [r15+0x108], eax
00007eafdc3e1e59  pextrq rax, xmm1, 0x01
00007eafdc3e1e60  movq xmm15, rax
00007eafdc3e1e65  movaps [r15+0x130], xmm15
00007eafdc3e1e6d  movaps xmm14, [r15+0x110]
00007eafdc3e1e75  movq rax, xmm14
00007eafdc3e1e7a  movq r14, xmm1
00007eafdc3e1e7f  vmovq xmm1, rax
00007eafdc3e1e84  vmovq xmm14, r14
00007eafdc3e1e89  movaps xmm13, xmm1
00007eafdc3e1e8d  addsd xmm13, xmm14
00007eafdc3e1e92  ucomisd xmm13, xmm13
00007eafdc3e1e97  jp 0x00007EAFDC3E1F4C
00007eafdc3e1e9d  movq xmm13, xmm13
00007eafdc3e1ea2  movq rax, xmm13
00007eafdc3e1ea7  movq r14, xmm15
00007eafdc3e1eac  vmovq xmm1, rax
00007eafdc3e1eb1  vmovq xmm15, r14
00007eafdc3e1eb6  movaps xmm14, xmm1
00007eafdc3e1eba  addsd xmm14, xmm15
00007eafdc3e1ebf  ucomisd xmm14, xmm14
00007eafdc3e1ec4  jp 0x00007EAFDC3E1F94
00007eafdc3e1eca  movq xmm14, xmm14
00007eafdc3e1ecf  movaps [r15+0x110], xmm14
00007eafdc3e1ed7  mov eax, [r15+0x108]
00007eafdc3e1ede  sahf
00007eafdc3e1edf  jnz 0x00007EAFDC3E1F11
00007eafdc3e1ee1  cmp dword ptr [r15+0x318], 0x00
00007eafdc3e1ee9  jz 0x00007EAFDC3E1FE0
00007eafdc3e1eef  nop [rax+rax*1], ax
00007eafdc3e1ef8  nop [rax+rax*1], eax
00007eafdc3e1f00  mov eax, 0x410490
00007eafdc3e1f05  mov [r15+0x100], rax
00007eafdc3e1f0c  jmp 0x00007EAFDC1FE110
00007eafdc3e1f11  cmp dword ptr [r15+0x318], 0x00
00007eafdc3e1f19  jz 0x00007EAFDC3E1E20
00007eafdc3e1f1f  nop [rax+rax*1], ax
00007eafdc3e1f28  nop [rax+rax*1], eax
00007eafdc3e1f30  mov eax, 0x410474
00007eafdc3e1f35  mov [r15+0x100], rax
00007eafdc3e1f3c  jmp 0x00007EAFDC1FE110
00007eafdc3e1f41  int3
00007eafdc3e1f42  call 0x00007EAFDC2B52F0
00007eafdc3e1f47  jmp 0x00007EAFDC3E1E32
00007eafdc3e1f4c  ucomisd xmm1, xmm14
00007eafdc3e1f51  jp 0x00007EAFDC3E1F60
00007eafdc3e1f53  movaps xmm13, [0x00007EAFDBFFE060]
00007eafdc3e1f5b  jmp 0x00007EAFDC3E1E9D
00007eafdc3e1f60  vxorps xmm0, xmm1, xmm14
00007eafdc3e1f65  pextrw eax, xmm0, 0x03
00007eafdc3e1f6a  and eax, 0x7FF8
00007eafdc3e1f6f  cmp eax, 0x08
00007eafdc3e1f72  jnz 0x00007EAFDC3E1E9D
00007eafdc3e1f78  movq rax, xmm14
00007eafdc3e1f7d  shl rax, 0x0D
00007eafdc3e1f81  jbe 0x00007EAFDC3E1E9D
00007eafdc3e1f87  vorps xmm13, xmm14, [0x00007EAFDBFFE070]
00007eafdc3e1f8f  jmp 0x00007EAFDC3E1E9D
00007eafdc3e1f94  ucomisd xmm1, xmm15
00007eafdc3e1f99  jp 0x00007EAFDC3E1FA8
00007eafdc3e1f9b  movaps xmm14, [0x00007EAFDBFFE060]
00007eafdc3e1fa3  jmp 0x00007EAFDC3E1ECA
00007eafdc3e1fa8  vxorps xmm0, xmm1, xmm15
00007eafdc3e1fad  pextrw eax, xmm0, 0x03
00007eafdc3e1fb2  and eax, 0x7FF8
00007eafdc3e1fb7  cmp eax, 0x08
00007eafdc3e1fba  jnz 0x00007EAFDC3E1ECA
00007eafdc3e1fc0  movq rax, xmm15
00007eafdc3e1fc5  shl rax, 0x0D
00007eafdc3e1fc9  jbe 0x00007EAFDC3E1ECA
00007eafdc3e1fcf  vorps xmm14, xmm15, [0x00007EAFDBFFE070]
00007eafdc3e1fd7  jmp 0x00007EAFDC3E1ECA
00007eafdc3e1fdc  int3
00007eafdc3e1fdd  nop [rax], eax
00007eafdc3e1fe0  mov rax, [r15+0x40]
00007eafdc3e1fe4  lea r14, [rax+0x510]
00007eafdc3e1feb  movaps xmm1, [r15+0x110]
00007eafdc3e1ff3  movq rax, xmm1
00007eafdc3e1ff8  mov [r13+r14*1], rax
00007eafdc3e1ffd  mov rax, [r15+0xF0]
00007eafdc3e2004  mov [r15+0x100], rax
00007eafdc3e200b  jmp 0x00007EAFDC3CE5C0
00007eafdc3e2010  int3
00007eafdc3e2011  call 0x00007EAFDC2D5EB0
00007eafdc3e2016  jmp 0x00007EAFDC3E1FFD
00007eafdc3e201b  int3
00007eafdc3e201c  nop [rax], eax
00007eafdc3e2020  mov qword ptr [r15+0x100], 0x04
00007eafdc3e202b  mov esi, 0x00
00007eafdc3e2030  mov edx, 0x09
00007eafdc3e2035  mov rdi, 0x7FFC0059B460
00007eafdc3e203f  mov rax, 0x645891508970
00007eafdc3e2049  call rax
00007eafdc3e204b  cmp dword ptr [r15+0x318], 0x00
00007eafdc3e2053  jnz 0x00007EAFDC1FE110
00007eafdc3e2059  jmp 0x00007EAFDC1FE0A0
00007eafdc3e205e  int3
00007eafdc3e205f  int3
