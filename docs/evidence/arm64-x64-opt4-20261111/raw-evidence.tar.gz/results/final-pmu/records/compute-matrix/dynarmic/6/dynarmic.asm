00007f0145bce69b  nop [rax+rax*1], eax
00007f0145bce6a0  vmovaps xmm1, [0x00007F01457FE010]
00007f0145bce6a8  movq xmm1, xmm1
00007f0145bce6ac  movaps [r15+0x110], xmm1
00007f0145bce6b4  vmovaps xmm1, [0x00007F01457FE020]
00007f0145bce6bc  movq xmm1, xmm1
00007f0145bce6c0  movaps [r15+0x120], xmm1
00007f0145bce6c8  mov eax, 0x4204C0
00007f0145bce6cd  mov r14, [r13+rax*1]
00007f0145bce6d2  movq xmm1, r14
00007f0145bce6d7  movaps [r15+0x130], xmm1
00007f0145bce6df  vmovaps xmm1, [0x00007F01457FE030]
00007f0145bce6e7  vpbroadcastq xmm1, xmm1
00007f0145bce6ec  movaps [r15+0x140], xmm1
00007f0145bce6f4  mov qword ptr [r15+0x40], 0x02
00007f0145bce6fc  vmovaps xmm15, [0x00007F01457FE040]
00007f0145bce704  movq xmm15, xmm15
00007f0145bce709  movaps [r15+0x150], xmm15
00007f0145bce711  mov qword ptr [r15+0x58], 0x420000
00007f0145bce719  vmovaps xmm15, [0x00007F01457FE050]
00007f0145bce721  vpbroadcastq xmm15, xmm15
00007f0145bce726  movaps [r15+0x160], xmm15
00007f0145bce72e  mov rax, [r15+0x40]
00007f0145bce732  vmovq xmm14, rax
00007f0145bce737  vpbroadcastq xmm14, xmm14
00007f0145bce73c  movaps [r15+0x170], xmm14
00007f0145bce744  mov eax, 0x4204D0
00007f0145bce749  movups xmm13, [r13+rax*1]
00007f0145bce74f  mov qword ptr [r15+0x40], 0x430518
00007f0145bce757  mov qword ptr [r15+0x50], 0x430720
00007f0145bce75f  vpmovqd xmm12, xmm13
00007f0145bce765  pxor xmm11, xmm11
00007f0145bce76a  punpcklqdq xmm12, xmm11
00007f0145bce76f  movaps [r15+0x210], xmm12
00007f0145bce777  movq xmm12, qword ptr [r15+0x120]
00007f0145bce780  movq xmm11, qword ptr [r15+0x130]
00007f0145bce789  psubd xmm12, xmm11
00007f0145bce78e  movq xmm12, xmm12
00007f0145bce793  paddq xmm13, xmm14
00007f0145bce798  movaps [r15+0x180], xmm13
00007f0145bce7a0  movq xmm14, qword ptr [r15+0x150]
00007f0145bce7a9  paddd xmm11, xmm14
00007f0145bce7ae  movq xmm11, xmm11
00007f0145bce7b3  movq xmm11, xmm11
00007f0145bce7b8  movaps [r15+0x130], xmm11
00007f0145bce7c0  pmovzxdq xmm12, xmm12
00007f0145bce7c6  psllq xmm12, 0x00
00007f0145bce7cc  movq xmm14, qword ptr [r15+0x210]
00007f0145bce7d5  movq xmm13, qword ptr [r15+0x110]
00007f0145bce7de  paddd xmm14, xmm13
00007f0145bce7e3  movq xmm14, xmm14
00007f0145bce7e8  vcvtuqq2pd xmm12, xmm12
00007f0145bce7ee  pmovzxdq xmm14, xmm14
00007f0145bce7f4  psllq xmm14, 0x00
00007f0145bce7fa  vcvtuqq2pd xmm14, xmm14
00007f0145bce800  movaps xmm13, xmm12
00007f0145bce804  mulpd xmm13, xmm1
00007f0145bce809  vcmppd xmm11, xmm13, xmm13, 0x03
00007f0145bce80f  ptest xmm11, xmm11
00007f0145bce815  jnz 0x00007F0145BCE8FF
00007f0145bce81b  movaps [r15+0x220], xmm13
00007f0145bce823  mov eax, 0x430720
00007f0145bce828  movups [r13+rax*1], xmm13
00007f0145bce82e  movaps xmm1, xmm14
00007f0145bce832  mulpd xmm1, xmm15
00007f0145bce837  vcmppd xmm13, xmm1, xmm1, 0x03
00007f0145bce83c  ptest xmm13, xmm13
00007f0145bce842  jnz 0x00007F0145BCEA4C
00007f0145bce848  movaps [r15+0x210], xmm1
00007f0145bce850  mov eax, 0x430518
00007f0145bce855  movups [r13+rax*1], xmm1
00007f0145bce85b  mov qword ptr [r15+0x48], 0x10
00007f0145bce863  xor eax, eax
00007f0145bce865  mov r14d, 0x10
00007f0145bce86b  mov r12d, 0x200
00007f0145bce871  cmp r14, r12
00007f0145bce874  cmc
00007f0145bce875  lahf
00007f0145bce876  seto al
00007f0145bce879  mov [r15+0x108], eax
00007f0145bce880  mov eax, [r15+0x108]
00007f0145bce887  sahf
00007f0145bce888  jnz 0x00007F0145BCE8BA
00007f0145bce88a  cmp dword ptr [r15+0x318], 0x00
00007f0145bce892  jz 0x00007F0145BCEFF0
00007f0145bce898  nop [rax+rax*1], ax
00007f0145bce8a1  nop [rax+rax*1], eax
00007f0145bce8a9  mov eax, 0x4101EC
00007f0145bce8ae  mov [r15+0x100], rax
00007f0145bce8b5  jmp 0x00007F01459FE110
00007f0145bce8ba  cmp dword ptr [r15+0x318], 0x00
00007f0145bce8c2  jz 0x00007F0145BCEBA0
00007f0145bce8c8  nop [rax+rax*1], ax
00007f0145bce8d1  nop [rax+rax*1], eax
00007f0145bce8d9  mov eax, 0x4101AC
00007f0145bce8de  mov [r15+0x100], rax
00007f0145bce8e5  jmp 0x00007F01459FE110
00007f0145bce8ea  int3
00007f0145bce8eb  call 0x00007F0145A0DC20
00007f0145bce8f0  jmp 0x00007F0145BCE6D2
00007f0145bce8f5  call 0x00007F0145A0C260
00007f0145bce8fa  jmp 0x00007F0145BCE74F
00007f0145bce8ff  sub rsp, 0x08
00007f0145bce903  push rax
00007f0145bce904  push rcx
00007f0145bce905  push rdx
00007f0145bce906  push rdi
00007f0145bce907  push rsi
00007f0145bce908  push r8
00007f0145bce90a  push r9
00007f0145bce90c  push r10
00007f0145bce90e  push r11
00007f0145bce910  sub rsp, 0xF0
00007f0145bce917  vmovaps [rsp], xmm0
00007f0145bce91c  vmovaps [rsp+0x10], xmm1
00007f0145bce922  vmovaps [rsp+0x20], xmm2
00007f0145bce928  vmovaps [rsp+0x30], xmm3
00007f0145bce92e  vmovaps [rsp+0x40], xmm4
00007f0145bce934  vmovaps [rsp+0x50], xmm5
00007f0145bce93a  vmovaps [rsp+0x60], xmm6
00007f0145bce940  vmovaps [rsp+0x70], xmm7
00007f0145bce946  vmovaps [rsp+0x80], xmm8
00007f0145bce94f  vmovaps [rsp+0x90], xmm9
00007f0145bce958  vmovaps [rsp+0xA0], xmm10
00007f0145bce961  vmovaps [rsp+0xB0], xmm11
00007f0145bce96a  vmovaps [rsp+0xC0], xmm12
00007f0145bce973  vmovaps [rsp+0xD0], xmm14
00007f0145bce97c  vmovaps [rsp+0xE0], xmm15
00007f0145bce985  sub rsp, 0x30
00007f0145bce989  movaps [rsp], xmm13
00007f0145bce98e  movaps [rsp+0x10], xmm12
00007f0145bce994  movaps [rsp+0x20], xmm1
00007f0145bce999  lea rdi, [rsp]
00007f0145bce99d  mov esi, 0x00
00007f0145bce9a2  mov rax, 0x636570E98530
00007f0145bce9ac  call rax
00007f0145bce9ae  movaps xmm13, [rsp]
00007f0145bce9b3  add rsp, 0x30
00007f0145bce9b7  vmovaps xmm0, [rsp]
00007f0145bce9bc  vmovaps xmm1, [rsp+0x10]
00007f0145bce9c2  vmovaps xmm2, [rsp+0x20]
00007f0145bce9c8  vmovaps xmm3, [rsp+0x30]
00007f0145bce9ce  vmovaps xmm4, [rsp+0x40]
00007f0145bce9d4  vmovaps xmm5, [rsp+0x50]
00007f0145bce9da  vmovaps xmm6, [rsp+0x60]
00007f0145bce9e0  vmovaps xmm7, [rsp+0x70]
00007f0145bce9e6  vmovaps xmm8, [rsp+0x80]
00007f0145bce9ef  vmovaps xmm9, [rsp+0x90]
00007f0145bce9f8  vmovaps xmm10, [rsp+0xA0]
00007f0145bcea01  vmovaps xmm11, [rsp+0xB0]
00007f0145bcea0a  vmovaps xmm12, [rsp+0xC0]
00007f0145bcea13  vmovaps xmm14, [rsp+0xD0]
00007f0145bcea1c  vmovaps xmm15, [rsp+0xE0]
00007f0145bcea25  add rsp, 0xF0
00007f0145bcea2c  pop r11
00007f0145bcea2e  pop r10
00007f0145bcea30  pop r9
00007f0145bcea32  pop r8
00007f0145bcea34  pop rsi
00007f0145bcea35  pop rdi
00007f0145bcea36  pop rdx
00007f0145bcea37  pop rcx
00007f0145bcea38  pop rax
00007f0145bcea39  add rsp, 0x08
00007f0145bcea3d  jmp 0x00007F0145BCE81B
00007f0145bcea42  call 0x00007F0145A0C380
00007f0145bcea47  jmp 0x00007F0145BCE82E
00007f0145bcea4c  sub rsp, 0x08
00007f0145bcea50  push rax
00007f0145bcea51  push rcx
00007f0145bcea52  push rdx
00007f0145bcea53  push rdi
00007f0145bcea54  push rsi
00007f0145bcea55  push r8
00007f0145bcea57  push r9
00007f0145bcea59  push r10
00007f0145bcea5b  push r11
00007f0145bcea5d  sub rsp, 0xF0
00007f0145bcea64  vmovaps [rsp], xmm0
00007f0145bcea69  vmovaps [rsp+0x10], xmm2
00007f0145bcea6f  vmovaps [rsp+0x20], xmm3
00007f0145bcea75  vmovaps [rsp+0x30], xmm4
00007f0145bcea7b  vmovaps [rsp+0x40], xmm5
00007f0145bcea81  vmovaps [rsp+0x50], xmm6
00007f0145bcea87  vmovaps [rsp+0x60], xmm7
00007f0145bcea8d  vmovaps [rsp+0x70], xmm8
00007f0145bcea93  vmovaps [rsp+0x80], xmm9
00007f0145bcea9c  vmovaps [rsp+0x90], xmm10
00007f0145bceaa5  vmovaps [rsp+0xA0], xmm11
00007f0145bceaae  vmovaps [rsp+0xB0], xmm12
00007f0145bceab7  vmovaps [rsp+0xC0], xmm13
00007f0145bceac0  vmovaps [rsp+0xD0], xmm14
00007f0145bceac9  vmovaps [rsp+0xE0], xmm15
00007f0145bcead2  sub rsp, 0x30
00007f0145bcead6  movaps [rsp], xmm1
00007f0145bceada  movaps [rsp+0x10], xmm14
00007f0145bceae0  movaps [rsp+0x20], xmm15
00007f0145bceae6  lea rdi, [rsp]
00007f0145bceaea  mov esi, 0x00
00007f0145bceaef  mov rax, 0x636570E98530
00007f0145bceaf9  call rax
00007f0145bceafb  movaps xmm1, [rsp]
00007f0145bceaff  add rsp, 0x30
00007f0145bceb03  vmovaps xmm0, [rsp]
00007f0145bceb08  vmovaps xmm2, [rsp+0x10]
00007f0145bceb0e  vmovaps xmm3, [rsp+0x20]
00007f0145bceb14  vmovaps xmm4, [rsp+0x30]
00007f0145bceb1a  vmovaps xmm5, [rsp+0x40]
00007f0145bceb20  vmovaps xmm6, [rsp+0x50]
00007f0145bceb26  vmovaps xmm7, [rsp+0x60]
00007f0145bceb2c  vmovaps xmm8, [rsp+0x70]
00007f0145bceb32  vmovaps xmm9, [rsp+0x80]
00007f0145bceb3b  vmovaps xmm10, [rsp+0x90]
00007f0145bceb44  vmovaps xmm11, [rsp+0xA0]
00007f0145bceb4d  vmovaps xmm12, [rsp+0xB0]
00007f0145bceb56  vmovaps xmm13, [rsp+0xC0]
00007f0145bceb5f  vmovaps xmm14, [rsp+0xD0]
00007f0145bceb68  vmovaps xmm15, [rsp+0xE0]
00007f0145bceb71  add rsp, 0xF0
00007f0145bceb78  pop r11
00007f0145bceb7a  pop r10
00007f0145bceb7c  pop r9
00007f0145bceb7e  pop r8
00007f0145bceb80  pop rsi
00007f0145bceb81  pop rdi
00007f0145bceb82  pop rdx
00007f0145bceb83  pop rcx
00007f0145bceb84  pop rax
00007f0145bceb85  add rsp, 0x08
00007f0145bceb89  jmp 0x00007F0145BCE848
00007f0145bceb8e  call 0x00007F01459FF540
00007f0145bceb93  jmp 0x00007F0145BCE85B
00007f0145bceb98  int3
00007f0145bceb99  nop [rax], eax
00007f0145bceba0  movaps xmm1, [r15+0x180]
00007f0145bceba8  vpmovqd xmm15, xmm1
00007f0145bcebae  pxor xmm14, xmm14
00007f0145bcebb3  punpcklqdq xmm15, xmm14
00007f0145bcebb8  movaps [r15+0x210], xmm15
00007f0145bcebc0  movq xmm15, qword ptr [r15+0x120]
00007f0145bcebc9  movq xmm14, qword ptr [r15+0x130]
00007f0145bcebd2  psubd xmm15, xmm14
00007f0145bcebd7  movq xmm15, xmm15
00007f0145bcebdc  movaps xmm13, [r15+0x170]
00007f0145bcebe4  paddq xmm1, xmm13
00007f0145bcebe9  movaps [r15+0x180], xmm1
00007f0145bcebf1  movq xmm1, qword ptr [r15+0x150]
00007f0145bcebfa  paddd xmm14, xmm1
00007f0145bcebff  movq xmm14, xmm14
00007f0145bcec04  movq xmm14, xmm14
00007f0145bcec09  movaps [r15+0x130], xmm14
00007f0145bcec11  pmovzxdq xmm15, xmm15
00007f0145bcec17  psllq xmm15, 0x00
00007f0145bcec1d  movq xmm1, qword ptr [r15+0x210]
00007f0145bcec26  movq xmm14, qword ptr [r15+0x110]
00007f0145bcec2f  paddd xmm1, xmm14
00007f0145bcec34  movq xmm1, xmm1
00007f0145bcec38  vcvtuqq2pd xmm15, xmm15
00007f0145bcec3e  pmovzxdq xmm1, xmm1
00007f0145bcec43  psllq xmm1, 0x00
00007f0145bcec48  vcvtuqq2pd xmm1, xmm1
00007f0145bcec4e  movaps xmm14, [r15+0x140]
00007f0145bcec56  movaps xmm13, xmm15
00007f0145bcec5a  mulpd xmm13, xmm14
00007f0145bcec5f  vcmppd xmm12, xmm13, xmm13, 0x03
00007f0145bcec65  ptest xmm12, xmm12
00007f0145bcec6b  jnz 0x00007F0145BCED4E
00007f0145bcec71  movaps [r15+0x220], xmm13
00007f0145bcec79  mov rax, [r15+0x48]
00007f0145bcec7d  mov r14, [r15+0x50]
00007f0145bcec81  lea r12, [r14+rax*1]
00007f0145bcec85  movups [r13+r12*1], xmm13
00007f0145bcec8b  movaps xmm15, [r15+0x160]
00007f0145bcec93  movaps xmm14, xmm1
00007f0145bcec97  mulpd xmm14, xmm15
00007f0145bcec9c  vcmppd xmm13, xmm14, xmm14, 0x03
00007f0145bceca2  ptest xmm13, xmm13
00007f0145bceca8  jnz 0x00007F0145BCEE9C
00007f0145bcecae  movaps [r15+0x210], xmm14
00007f0145bcecb6  mov r14, [r15+0x40]
00007f0145bcecba  lea r12, [r14+rax*1]
00007f0145bcecbe  movups [r13+r12*1], xmm14
00007f0145bcecc4  lea r14, [rax+0x10]
00007f0145bcecc8  mov [r15+0x48], r14
00007f0145bceccc  xor eax, eax
00007f0145bcecce  mov r12d, 0x200
00007f0145bcecd4  cmp r14, r12
00007f0145bcecd7  cmc
00007f0145bcecd8  lahf
00007f0145bcecd9  seto al
00007f0145bcecdc  mov [r15+0x108], eax
00007f0145bcece3  mov eax, [r15+0x108]
00007f0145bcecea  sahf
00007f0145bceceb  jnz 0x00007F0145BCED1D
00007f0145bceced  cmp dword ptr [r15+0x318], 0x00
00007f0145bcecf5  jz 0x00007F0145BCEFF0
00007f0145bcecfb  nop [rax+rax*1], ax
00007f0145bced04  nop [rax+rax*1], eax
00007f0145bced0c  mov eax, 0x4101EC
00007f0145bced11  mov [r15+0x100], rax
00007f0145bced18  jmp 0x00007F01459FE110
00007f0145bced1d  cmp dword ptr [r15+0x318], 0x00
00007f0145bced25  jz 0x00007F0145BCEBA0
00007f0145bced2b  nop [rax+rax*1], ax
00007f0145bced34  nop [rax+rax*1], eax
00007f0145bced3c  mov eax, 0x4101AC
00007f0145bced41  mov [r15+0x100], rax
00007f0145bced48  jmp 0x00007F01459FE110
00007f0145bced4d  int3
00007f0145bced4e  sub rsp, 0x08
00007f0145bced52  push rax
00007f0145bced53  push rcx
00007f0145bced54  push rdx
00007f0145bced55  push rdi
00007f0145bced56  push rsi
00007f0145bced57  push r8
00007f0145bced59  push r9
00007f0145bced5b  push r10
00007f0145bced5d  push r11
00007f0145bced5f  sub rsp, 0xF0
00007f0145bced66  vmovaps [rsp], xmm0
00007f0145bced6b  vmovaps [rsp+0x10], xmm1
00007f0145bced71  vmovaps [rsp+0x20], xmm2
00007f0145bced77  vmovaps [rsp+0x30], xmm3
00007f0145bced7d  vmovaps [rsp+0x40], xmm4
00007f0145bced83  vmovaps [rsp+0x50], xmm5
00007f0145bced89  vmovaps [rsp+0x60], xmm6
00007f0145bced8f  vmovaps [rsp+0x70], xmm7
00007f0145bced95  vmovaps [rsp+0x80], xmm8
00007f0145bced9e  vmovaps [rsp+0x90], xmm9
00007f0145bceda7  vmovaps [rsp+0xA0], xmm10
00007f0145bcedb0  vmovaps [rsp+0xB0], xmm11
00007f0145bcedb9  vmovaps [rsp+0xC0], xmm12
00007f0145bcedc2  vmovaps [rsp+0xD0], xmm14
00007f0145bcedcb  vmovaps [rsp+0xE0], xmm15
00007f0145bcedd4  sub rsp, 0x30
00007f0145bcedd8  movaps [rsp], xmm13
00007f0145bceddd  movaps [rsp+0x10], xmm15
00007f0145bcede3  movaps [rsp+0x20], xmm14
00007f0145bcede9  lea rdi, [rsp]
00007f0145bceded  mov esi, 0x00
00007f0145bcedf2  mov rax, 0x636570E98530
00007f0145bcedfc  call rax
00007f0145bcedfe  movaps xmm13, [rsp]
00007f0145bcee03  add rsp, 0x30
00007f0145bcee07  vmovaps xmm0, [rsp]
00007f0145bcee0c  vmovaps xmm1, [rsp+0x10]
00007f0145bcee12  vmovaps xmm2, [rsp+0x20]
00007f0145bcee18  vmovaps xmm3, [rsp+0x30]
00007f0145bcee1e  vmovaps xmm4, [rsp+0x40]
00007f0145bcee24  vmovaps xmm5, [rsp+0x50]
00007f0145bcee2a  vmovaps xmm6, [rsp+0x60]
00007f0145bcee30  vmovaps xmm7, [rsp+0x70]
00007f0145bcee36  vmovaps xmm8, [rsp+0x80]
00007f0145bcee3f  vmovaps xmm9, [rsp+0x90]
00007f0145bcee48  vmovaps xmm10, [rsp+0xA0]
00007f0145bcee51  vmovaps xmm11, [rsp+0xB0]
00007f0145bcee5a  vmovaps xmm12, [rsp+0xC0]
00007f0145bcee63  vmovaps xmm14, [rsp+0xD0]
00007f0145bcee6c  vmovaps xmm15, [rsp+0xE0]
00007f0145bcee75  add rsp, 0xF0
00007f0145bcee7c  pop r11
00007f0145bcee7e  pop r10
00007f0145bcee80  pop r9
00007f0145bcee82  pop r8
00007f0145bcee84  pop rsi
00007f0145bcee85  pop rdi
00007f0145bcee86  pop rdx
00007f0145bcee87  pop rcx
00007f0145bcee88  pop rax
00007f0145bcee89  add rsp, 0x08
00007f0145bcee8d  jmp 0x00007F0145BCEC71
00007f0145bcee92  call 0x00007F0145AC2240
00007f0145bcee97  jmp 0x00007F0145BCEC8B
00007f0145bcee9c  sub rsp, 0x08
00007f0145bceea0  push rax
00007f0145bceea1  push rcx
00007f0145bceea2  push rdx
00007f0145bceea3  push rdi
00007f0145bceea4  push rsi
00007f0145bceea5  push r8
00007f0145bceea7  push r9
00007f0145bceea9  push r10
00007f0145bceeab  push r11
00007f0145bceead  sub rsp, 0xF0
00007f0145bceeb4  vmovaps [rsp], xmm0
00007f0145bceeb9  vmovaps [rsp+0x10], xmm1
00007f0145bceebf  vmovaps [rsp+0x20], xmm2
00007f0145bceec5  vmovaps [rsp+0x30], xmm3
00007f0145bceecb  vmovaps [rsp+0x40], xmm4
00007f0145bceed1  vmovaps [rsp+0x50], xmm5
00007f0145bceed7  vmovaps [rsp+0x60], xmm6
00007f0145bceedd  vmovaps [rsp+0x70], xmm7
00007f0145bceee3  vmovaps [rsp+0x80], xmm8
00007f0145bceeec  vmovaps [rsp+0x90], xmm9
00007f0145bceef5  vmovaps [rsp+0xA0], xmm10
00007f0145bceefe  vmovaps [rsp+0xB0], xmm11
00007f0145bcef07  vmovaps [rsp+0xC0], xmm12
00007f0145bcef10  vmovaps [rsp+0xD0], xmm13
00007f0145bcef19  vmovaps [rsp+0xE0], xmm15
00007f0145bcef22  sub rsp, 0x30
00007f0145bcef26  movaps [rsp], xmm14
00007f0145bcef2b  movaps [rsp+0x10], xmm1
00007f0145bcef30  movaps [rsp+0x20], xmm15
00007f0145bcef36  lea rdi, [rsp]
00007f0145bcef3a  mov esi, 0x00
00007f0145bcef3f  mov rax, 0x636570E98530
00007f0145bcef49  call rax
00007f0145bcef4b  movaps xmm14, [rsp]
00007f0145bcef50  add rsp, 0x30
00007f0145bcef54  vmovaps xmm0, [rsp]
00007f0145bcef59  vmovaps xmm1, [rsp+0x10]
00007f0145bcef5f  vmovaps xmm2, [rsp+0x20]
00007f0145bcef65  vmovaps xmm3, [rsp+0x30]
00007f0145bcef6b  vmovaps xmm4, [rsp+0x40]
00007f0145bcef71  vmovaps xmm5, [rsp+0x50]
00007f0145bcef77  vmovaps xmm6, [rsp+0x60]
00007f0145bcef7d  vmovaps xmm7, [rsp+0x70]
00007f0145bcef83  vmovaps xmm8, [rsp+0x80]
00007f0145bcef8c  vmovaps xmm9, [rsp+0x90]
00007f0145bcef95  vmovaps xmm10, [rsp+0xA0]
00007f0145bcef9e  vmovaps xmm11, [rsp+0xB0]
00007f0145bcefa7  vmovaps xmm12, [rsp+0xC0]
00007f0145bcefb0  vmovaps xmm13, [rsp+0xD0]
00007f0145bcefb9  vmovaps xmm15, [rsp+0xE0]
00007f0145bcefc2  add rsp, 0xF0
00007f0145bcefc9  pop r11
00007f0145bcefcb  pop r10
00007f0145bcefcd  pop r9
00007f0145bcefcf  pop r8
00007f0145bcefd1  pop rsi
00007f0145bcefd2  pop rdi
00007f0145bcefd3  pop rdx
00007f0145bcefd4  pop rcx
00007f0145bcefd5  pop rax
00007f0145bcefd6  add rsp, 0x08
00007f0145bcefda  jmp 0x00007F0145BCECAE
00007f0145bcefdf  call 0x00007F0145AC34C0
00007f0145bcefe4  jmp 0x00007F0145BCECC4
00007f0145bcefe9  int3
00007f0145bcefea  nop [rax+rax*1], ax
00007f0145bceff0  mov rax, [r15+0xF8]
00007f0145bceff7  lea r14, [rax-0x150]
00007f0145bceffe  mov [r15+0xF8], r14
00007f0145bcf005  mov rax, [r15+0x50]
00007f0145bcf009  lea r12, [rax+0x80]
00007f0145bcf010  movups xmm1, [r13+r12*1]
00007f0145bcf016  lea r12, [rax+0x90]
00007f0145bcf01d  movups xmm15, [r13+r12*1]
00007f0145bcf023  mov qword ptr [r15+0x48], 0x00
00007f0145bcf02b  lea r12, [rax+0x40]
00007f0145bcf02f  movups xmm14, [r13+r12*1]
00007f0145bcf035  lea r12, [rax+0x50]
00007f0145bcf039  movups xmm13, [r13+r12*1]
00007f0145bcf03f  lea r12, [r14+0x120]
00007f0145bcf046  movq xmm12, qword ptr [r15+0x1C0]
00007f0145bcf04f  movq xmm11, qword ptr [r15+0x1B0]
00007f0145bcf058  movq r11, xmm12
00007f0145bcf05d  movq r10, xmm11
00007f0145bcf062  mov [r13+r12*1], r11
00007f0145bcf067  lea r12, [r14+0x128]
00007f0145bcf06e  mov [r13+r12*1], r10
00007f0145bcf073  vxorps xmm12, xmm12, xmm12
00007f0145bcf078  vpbroadcastq xmm12, xmm12
00007f0145bcf07d  lea r12, [r14+0x100]
00007f0145bcf084  movq xmm11, qword ptr [r15+0x200]
00007f0145bcf08d  movq xmm10, qword ptr [r15+0x1F0]
00007f0145bcf096  movq r11, xmm11
00007f0145bcf09b  movq r10, xmm10
00007f0145bcf0a0  mov [r13+r12*1], r11
00007f0145bcf0a5  lea r12, [r14+0x108]
00007f0145bcf0ac  mov [r13+r12*1], r10
00007f0145bcf0b1  lea r12, [r14+0xE0]
00007f0145bcf0b8  movups [r13+r12*1], xmm15
00007f0145bcf0be  lea r12, [r14+0xF0]
00007f0145bcf0c5  movups [r13+r12*1], xmm1
00007f0145bcf0cb  lea r12, [rax+0xC0]
00007f0145bcf0d2  movups xmm1, [r13+r12*1]
00007f0145bcf0d8  lea r12, [rax+0xD0]
00007f0145bcf0df  movups xmm15, [r13+r12*1]
00007f0145bcf0e5  lea r12, [r14+0x110]
00007f0145bcf0ec  movq xmm11, qword ptr [r15+0x1E0]
00007f0145bcf0f5  movq xmm10, qword ptr [r15+0x1D0]
00007f0145bcf0fe  movq r11, xmm11
00007f0145bcf103  movq r10, xmm10
00007f0145bcf108  mov [r13+r12*1], r11
00007f0145bcf10d  lea r12, [r14+0x118]
00007f0145bcf114  mov [r13+r12*1], r10
00007f0145bcf119  movups xmm11, [r13+rax*1]
00007f0145bcf11f  lea r12, [rax+0x10]
00007f0145bcf123  movups xmm10, [r13+r12*1]
00007f0145bcf129  lea r12, [r14+0x130]
00007f0145bcf130  movq xmm9, qword ptr [r15+0x1A0]
00007f0145bcf139  movq xmm8, qword ptr [r15+0x190]
00007f0145bcf142  movq r11, xmm9
00007f0145bcf147  movq r10, xmm8
00007f0145bcf14c  mov [r13+r12*1], r11
00007f0145bcf151  lea r12, [r14+0x138]
00007f0145bcf158  mov [r13+r12*1], r10
00007f0145bcf15d  lea r12, [rax+0x140]
00007f0145bcf164  movups xmm9, [r13+r12*1]
00007f0145bcf16a  lea r12, [rax+0x150]
00007f0145bcf171  movups xmm8, [r13+r12*1]
00007f0145bcf177  lea r12, [r14+0xC0]
00007f0145bcf17e  movups [r13+r12*1], xmm15
00007f0145bcf184  lea r12, [r14+0xD0]
00007f0145bcf18b  movups [r13+r12*1], xmm1
00007f0145bcf191  lea r12, [rax+0x100]
00007f0145bcf198  movups xmm1, [r13+r12*1]
00007f0145bcf19e  lea r12, [rax+0x110]
00007f0145bcf1a5  movups xmm15, [r13+r12*1]
00007f0145bcf1ab  lea r12, [r14+0x140]
00007f0145bcf1b2  mov r11, [r15+0xE8]
00007f0145bcf1b9  mov [r13+r12*1], r11
00007f0145bcf1be  lea r12, [rax+0x180]
00007f0145bcf1c5  movups xmm7, [r13+r12*1]
00007f0145bcf1cb  lea r12, [rax+0x190]
00007f0145bcf1d2  movups xmm6, [r13+r12*1]
00007f0145bcf1d8  lea r12, [rax+0x1C0]
00007f0145bcf1df  movups xmm5, [r13+r12*1]
00007f0145bcf1e5  lea r12, [rax+0x1D0]
00007f0145bcf1ec  movups xmm4, [r13+r12*1]
00007f0145bcf1f2  lea r12, [r14+0x20]
00007f0145bcf1f6  movups [r13+r12*1], xmm1
00007f0145bcf1fc  lea r12, [r14+0x30]
00007f0145bcf200  movups [r13+r12*1], xmm13
00007f0145bcf206  lea r12, [rax+0x60]
00007f0145bcf20a  movups xmm1, [r13+r12*1]
00007f0145bcf210  lea r12, [rax+0x70]
00007f0145bcf214  movups xmm13, [r13+r12*1]
00007f0145bcf21a  lea r12, [rax+0x20]
00007f0145bcf21e  movups xmm3, [r13+r12*1]
00007f0145bcf224  lea r12, [rax+0x30]
00007f0145bcf228  movups xmm2, [r13+r12*1]
00007f0145bcf22e  movaps [r15+0x1F0], xmm2
00007f0145bcf236  lea r12, [r14+0x60]
00007f0145bcf23a  movups [r13+r12*1], xmm11
00007f0145bcf240  lea r12, [r14+0x70]
00007f0145bcf244  movups [r13+r12*1], xmm5
00007f0145bcf24a  lea r12, [rax+0xE0]
00007f0145bcf251  movups xmm11, [r13+r12*1]
00007f0145bcf257  lea r12, [rax+0xF0]
00007f0145bcf25e  movups xmm5, [r13+r12*1]
00007f0145bcf264  lea r12, [r14+0xA0]
00007f0145bcf26b  movups [r13+r12*1], xmm13
00007f0145bcf271  lea r12, [r14+0xB0]
00007f0145bcf278  movups [r13+r12*1], xmm1
00007f0145bcf27e  lea r12, [rax+0xA0]
00007f0145bcf285  movups xmm1, [r13+r12*1]
00007f0145bcf28b  lea r12, [rax+0xB0]
00007f0145bcf292  movups xmm13, [r13+r12*1]
00007f0145bcf298  lea r12, [rax+0x120]
00007f0145bcf29f  vmovaps [rsp+0x10], xmm1
00007f0145bcf2a5  movups xmm1, [r13+r12*1]
00007f0145bcf2ab  lea r12, [rax+0x130]
00007f0145bcf2b2  vmovaps [rsp+0x20], xmm1
00007f0145bcf2b8  movups xmm1, [r13+r12*1]
00007f0145bcf2be  lea r12, [rax+0x160]
00007f0145bcf2c5  vmovaps [rsp+0x30], xmm1
00007f0145bcf2cb  movups xmm1, [r13+r12*1]
00007f0145bcf2d1  lea r12, [rax+0x170]
00007f0145bcf2d8  vmovaps [rsp+0x40], xmm1
00007f0145bcf2de  movups xmm1, [r13+r12*1]
00007f0145bcf2e4  movaps [r15+0x2B0], xmm1
00007f0145bcf2ec  lea r12, [r14+0x80]
00007f0145bcf2f3  movups [r13+r12*1], xmm13
00007f0145bcf2f9  lea r12, [r14+0x90]
00007f0145bcf300  vmovaps xmm13, [rsp+0x10]
00007f0145bcf306  movups [r13+r12*1], xmm13
00007f0145bcf30c  lea r12, [rax+0x1A0]
00007f0145bcf313  movups xmm13, [r13+r12*1]
00007f0145bcf319  lea r12, [rax+0x1B0]
00007f0145bcf320  vmovaps [rsp+0x10], xmm1
00007f0145bcf326  movups xmm1, [r13+r12*1]
00007f0145bcf32c  movaps [r15+0x290], xmm13
00007f0145bcf334  movaps [r15+0x1E0], xmm1
00007f0145bcf33c  lea r12, [rax+0x1E0]
00007f0145bcf343  vmovaps [rsp+0x50], xmm1
00007f0145bcf349  movups xmm1, [r13+r12*1]
00007f0145bcf34f  lea r12, [rax+0x1F0]
00007f0145bcf356  vmovaps [rsp+0x60], xmm1
00007f0145bcf35c  movups xmm1, [r13+r12*1]
00007f0145bcf362  mov qword ptr [r15+0x50], 0x430920
00007f0145bcf36a  lea rax, [r14+0x40]
00007f0145bcf36e  vmovaps [rsp+0x70], xmm1
00007f0145bcf374  vmovaps xmm1, [rsp+0x40]
00007f0145bcf37a  movups [r13+rax*1], xmm1
00007f0145bcf380  lea rax, [r14+0x50]
00007f0145bcf384  movups [r13+rax*1], xmm10
00007f0145bcf38a  vmovaps xmm1, [rsp+0x70]
00007f0145bcf390  movups [r13+r14*1], xmm1
00007f0145bcf396  lea rax, [r14+0x10]
00007f0145bcf39a  vmovaps xmm1, [rsp+0x60]
00007f0145bcf3a0  movups [r13+rax*1], xmm1
00007f0145bcf3a6  mov rax, [r15+0x40]
00007f0145bcf3aa  vmovaps [rsp+0x40], xmm3
00007f0145bcf3b0  vmovaps xmm1, [rsp+0x40]
00007f0145bcf3b6  por xmm3, xmm1
00007f0145bcf3ba  vmovaps [rsp+0x40], xmm6
00007f0145bcf3c0  vmovaps xmm10, [rsp+0x40]
00007f0145bcf3c6  por xmm6, xmm10
00007f0145bcf3cb  lea r12, [rax+0x30]
00007f0145bcf3cf  mov r11, [r13+r12*1]
00007f0145bcf3d4  lea r12, [rax+0x38]
00007f0145bcf3d8  mov r10, [r13+r12*1]
00007f0145bcf3dd  movq xmm10, r11
00007f0145bcf3e2  vmovaps [rsp+0x40], xmm1
00007f0145bcf3e8  movq xmm1, r10
00007f0145bcf3ed  movq xmm10, xmm10
00007f0145bcf3f2  vmovaps [rsp+0x60], xmm10
00007f0145bcf3f8  movq xmm10, xmm10
00007f0145bcf3fd  movaps [r15+0x130], xmm10
00007f0145bcf405  movq xmm1, xmm1
00007f0145bcf409  vmovaps [rsp+0x70], xmm1
00007f0145bcf40f  movq xmm1, xmm1
00007f0145bcf413  movaps [r15+0x280], xmm1
00007f0145bcf41b  vmovaps [rsp+0x80], xmm9
00007f0145bcf424  vmovaps xmm1, [rsp+0x80]
00007f0145bcf42d  por xmm9, xmm1
00007f0145bcf432  lea r12, [rax+0x20]
00007f0145bcf436  mov r11, [r13+r12*1]
00007f0145bcf43b  lea r12, [rax+0x28]
00007f0145bcf43f  mov r10, [r13+r12*1]
00007f0145bcf444  movq xmm1, r11
00007f0145bcf449  movq xmm10, r10
00007f0145bcf44e  movq xmm1, xmm1
00007f0145bcf452  vmovaps [rsp+0x80], xmm1
00007f0145bcf45b  movq xmm1, xmm1
00007f0145bcf45f  movaps [r15+0x150], xmm1
00007f0145bcf467  movq xmm10, xmm10
00007f0145bcf46c  vmovaps [rsp+0x90], xmm10
00007f0145bcf475  movq xmm10, xmm10
00007f0145bcf47a  movaps [r15+0x140], xmm10
00007f0145bcf482  lea r12, [rax+0x10]
00007f0145bcf486  mov r11, [r13+r12*1]
00007f0145bcf48b  lea r12, [rax+0x18]
00007f0145bcf48f  mov r10, [r13+r12*1]
00007f0145bcf494  movq xmm1, r11
00007f0145bcf499  movq xmm10, r10
00007f0145bcf49e  movq xmm1, xmm1
00007f0145bcf4a2  vmovaps [rsp+0xA0], xmm1
00007f0145bcf4ab  movq xmm1, xmm1
00007f0145bcf4af  movaps [r15+0x170], xmm1
00007f0145bcf4b7  movq xmm10, xmm10
00007f0145bcf4bc  vmovaps [rsp+0xB0], xmm10
00007f0145bcf4c5  movq xmm10, xmm10
00007f0145bcf4ca  movaps [r15+0x160], xmm10
00007f0145bcf4d2  mov r12, [r13+rax*1]
00007f0145bcf4d7  vmovq xmm1, r12
00007f0145bcf4dc  vpbroadcastq xmm1, xmm1
00007f0145bcf4e1  lea r12, [rax+0x08]
00007f0145bcf4e5  mov rax, [r13+r12*1]
00007f0145bcf4ea  movq xmm10, rax
00007f0145bcf4ef  movaps [r15+0x230], xmm10
00007f0145bcf4f7  lea rax, [r14+0x50]
00007f0145bcf4fb  movups xmm10, [r13+rax*1]
00007f0145bcf501  lea rax, [r14+0x60]
00007f0145bcf505  vmovaps [rsp+0xC0], xmm1
00007f0145bcf50e  movups xmm1, [r13+rax*1]
00007f0145bcf514  lea rax, [r14+0x30]
00007f0145bcf518  vmovaps [rsp+0xD0], xmm1
00007f0145bcf521  movups xmm1, [r13+rax*1]
00007f0145bcf527  mov qword ptr [r15+0x60], 0x430920
00007f0145bcf52f  mov qword ptr [r15+0x58], 0x40
00007f0145bcf537  vmovaps [rsp+0xE0], xmm1
00007f0145bcf540  vmovaps [rsp+0xF0], xmm15
00007f0145bcf549  vmovaps xmm15, [rsp+0xC0]
00007f0145bcf552  vmovaps [rsp+0xC0], xmm14
00007f0145bcf55b  vmovaps xmm14, [rsp+0x40]
00007f0145bcf561  vmovaps [rsp+0x40], xmm13
00007f0145bcf567  movaps xmm1, xmm15
00007f0145bcf56b  mulpd xmm1, xmm14
00007f0145bcf570  vcmppd xmm13, xmm1, xmm1, 0x03
00007f0145bcf575  ptest xmm13, xmm13
00007f0145bcf57b  jnz 0x00007F0145BD0682
00007f0145bcf581  movq xmm14, qword ptr [r15+0x230]
00007f0145bcf58a  vmovaps [rsp+0x100], xmm14
00007f0145bcf593  vpermilpd xmm14, xmm14, 0x00
00007f0145bcf599  vmovaps [rsp+0x110], xmm1
00007f0145bcf5a2  vmovaps xmm1, [rsp+0xE0]
00007f0145bcf5ab  vmovaps [rsp+0xE0], xmm15
00007f0145bcf5b4  movaps xmm13, xmm1
00007f0145bcf5b8  mulpd xmm13, xmm14
00007f0145bcf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
00007f0145bcf5c3  ptest xmm15, xmm15
00007f0145bcf5c9  jnz 0x00007F0145BD07C4
00007f0145bcf5cf  vxorps xmm1, xmm1, xmm1
00007f0145bcf5d3  vpbroadcastq xmm1, xmm1
00007f0145bcf5d8  vmovaps xmm14, [rsp+0xE0]
00007f0145bcf5e1  vmovaps [rsp+0xE0], xmm1
00007f0145bcf5ea  vmovaps xmm1, [rsp+0xD0]
00007f0145bcf5f3  vmovaps [rsp+0xD0], xmm13
00007f0145bcf5fc  movaps xmm15, xmm14
00007f0145bcf600  mulpd xmm15, xmm1
00007f0145bcf605  vcmppd xmm13, xmm15, xmm15, 0x03
00007f0145bcf60b  ptest xmm13, xmm13
00007f0145bcf611  jnz 0x00007F0145BD0907
00007f0145bcf617  movaps xmm1, xmm14
00007f0145bcf61b  mulpd xmm1, xmm10
00007f0145bcf620  vcmppd xmm13, xmm1, xmm1, 0x03
00007f0145bcf625  ptest xmm13, xmm13
00007f0145bcf62b  jnz 0x00007F0145BD0A4A
00007f0145bcf631  movaps xmm13, xmm14
00007f0145bcf635  mulpd xmm13, xmm2
00007f0145bcf63a  vcmppd xmm10, xmm13, xmm13, 0x03
00007f0145bcf640  ptest xmm10, xmm10
00007f0145bcf646  jnz 0x00007F0145BD0B8C
00007f0145bcf64c  vmovaps [rsp+0x120], xmm7
00007f0145bcf655  vmovaps xmm14, [rsp+0x120]
00007f0145bcf65e  por xmm7, xmm14
00007f0145bcf663  vmovaps xmm14, [rsp+0xC0]
00007f0145bcf66c  vmovaps xmm10, [rsp+0xC0]
00007f0145bcf675  por xmm14, xmm10
00007f0145bcf67a  vmovaps xmm2, [rsp+0x100]
00007f0145bcf683  vpermilpd xmm2, xmm2, 0x00
00007f0145bcf689  vmovaps [rsp+0xC0], xmm1
00007f0145bcf692  vmovaps [rsp+0x120], xmm15
00007f0145bcf69b  movaps xmm1, xmm10
00007f0145bcf69f  mulpd xmm1, xmm2
00007f0145bcf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
00007f0145bcf6a8  ptest xmm15, xmm15
00007f0145bcf6ae  jnz 0x00007F0145BD0CCF
00007f0145bcf6b4  xor eax, eax
00007f0145bcf6b6  mov r12d, 0x40
00007f0145bcf6bc  mov r11d, 0x200
00007f0145bcf6c2  cmp r12, r11
00007f0145bcf6c5  cmc
00007f0145bcf6c6  lahf
00007f0145bcf6c7  seto al
00007f0145bcf6ca  mov [r15+0x108], eax
00007f0145bcf6d1  vmovaps xmm10, [rsp+0x110]
00007f0145bcf6da  vmovaps xmm2, [rsp+0xE0]
00007f0145bcf6e3  vmovaps [rsp+0xE0], xmm1
00007f0145bcf6ec  movaps xmm15, xmm10
00007f0145bcf6f0  addpd xmm15, xmm2
00007f0145bcf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
00007f0145bcf6fb  ptest xmm1, xmm1
00007f0145bcf700  jnz 0x00007F0145BD0E10
00007f0145bcf706  vmovaps xmm10, [rsp+0x120]
00007f0145bcf70f  vmovaps [rsp+0x110], xmm15
00007f0145bcf718  movaps xmm1, xmm10
00007f0145bcf71c  addpd xmm1, xmm12
00007f0145bcf721  vcmppd xmm15, xmm1, xmm1, 0x03
00007f0145bcf726  ptest xmm15, xmm15
00007f0145bcf72c  jnz 0x00007F0145BD0F53
00007f0145bcf732  vmovaps xmm10, [rsp+0xC0]
00007f0145bcf73b  vmovaps [rsp+0xC0], xmm1
00007f0145bcf744  movaps xmm15, xmm10
00007f0145bcf748  addpd xmm15, xmm12
00007f0145bcf74d  vcmppd xmm1, xmm15, xmm15, 0x03
00007f0145bcf753  ptest xmm1, xmm1
00007f0145bcf758  jnz 0x00007F0145BD1095
00007f0145bcf75e  vmovaps xmm1, [rsp+0x30]
00007f0145bcf764  vmovaps xmm12, [rsp+0x30]
00007f0145bcf76a  por xmm1, xmm12
00007f0145bcf76f  vmovaps xmm12, [rsp+0x20]
00007f0145bcf775  vmovaps xmm10, [rsp+0x20]
00007f0145bcf77b  por xmm12, xmm10
00007f0145bcf780  vmovaps [rsp+0x20], xmm5
00007f0145bcf786  vmovaps xmm10, [rsp+0x20]
00007f0145bcf78c  por xmm5, xmm10
00007f0145bcf791  vmovaps [rsp+0x20], xmm11
00007f0145bcf797  vmovaps xmm10, [rsp+0x20]
00007f0145bcf79d  por xmm11, xmm10
00007f0145bcf7a2  vmovaps [rsp+0x20], xmm4
00007f0145bcf7a8  vmovaps xmm10, [rsp+0x20]
00007f0145bcf7ae  por xmm4, xmm10
00007f0145bcf7b3  vmovaps [rsp+0x20], xmm8
00007f0145bcf7b9  vmovaps xmm10, [rsp+0x20]
00007f0145bcf7bf  por xmm8, xmm10
00007f0145bcf7c4  vmovaps xmm10, [rsp+0xF0]
00007f0145bcf7cd  vmovaps [rsp+0x20], xmm1
00007f0145bcf7d3  vmovaps xmm1, [rsp+0xF0]
00007f0145bcf7dc  por xmm10, xmm1
00007f0145bcf7e1  lea rax, [r14+0xA0]
00007f0145bcf7e8  movups xmm1, [r13+rax*1]
00007f0145bcf7ee  lea rax, [r14+0xB0]
00007f0145bcf7f5  vmovaps [rsp+0x30], xmm1
00007f0145bcf7fb  movups xmm1, [r13+rax*1]
00007f0145bcf801  vmovaps [rsp+0xF0], xmm1
00007f0145bcf80a  vmovaps [rsp+0x120], xmm15
00007f0145bcf813  movaps xmm1, xmm13
00007f0145bcf817  addpd xmm1, xmm2
00007f0145bcf81b  vcmppd xmm15, xmm1, xmm1, 0x03
00007f0145bcf820  ptest xmm15, xmm15
00007f0145bcf826  jnz 0x00007F0145BD11ED
00007f0145bcf82c  lea rax, [r14+0xF0]
00007f0145bcf833  movups xmm15, [r13+rax*1]
00007f0145bcf839  vmovaps xmm2, [rsp+0xC0]
00007f0145bcf842  vmovaps [rsp+0xC0], xmm1
00007f0145bcf84b  vmovaps xmm1, [rsp+0xE0]
00007f0145bcf854  vmovaps [rsp+0xE0], xmm15
00007f0145bcf85d  movaps xmm13, xmm2
00007f0145bcf861  addpd xmm13, xmm1
00007f0145bcf866  vcmppd xmm15, xmm13, xmm13, 0x03
00007f0145bcf86c  ptest xmm15, xmm15
00007f0145bcf872  jnz 0x00007F0145BD1338
00007f0145bcf878  vmovaps xmm15, [rsp+0x120]
00007f0145bcf881  vmovaps xmm2, [rsp+0xD0]
00007f0145bcf88a  vmovaps [rsp+0xD0], xmm14
00007f0145bcf893  movaps xmm1, xmm15
00007f0145bcf897  addpd xmm1, xmm2
00007f0145bcf89b  vcmppd xmm14, xmm1, xmm1, 0x03
00007f0145bcf8a0  ptest xmm14, xmm14
00007f0145bcf8a6  jnz 0x00007F0145BD147A
00007f0145bcf8ac  vmovaps xmm15, [rsp+0x100]
00007f0145bcf8b5  vpermilpd xmm15, xmm15, 0x00
00007f0145bcf8bb  vmovaps xmm2, [rsp+0xF0]
00007f0145bcf8c4  vmovaps [rsp+0xF0], xmm1
00007f0145bcf8cd  movaps xmm14, xmm2
00007f0145bcf8d1  mulpd xmm14, xmm15
00007f0145bcf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
00007f0145bcf8dc  ptest xmm1, xmm1
00007f0145bcf8e1  jnz 0x00007F0145BD15BB
00007f0145bcf8e7  vmovaps xmm1, [rsp+0xA0]
00007f0145bcf8f0  vpermilpd xmm1, xmm1, 0x00
00007f0145bcf8f6  vmovaps xmm2, [rsp+0xE0]
00007f0145bcf8ff  vmovaps [rsp+0xE0], xmm14
00007f0145bcf908  movaps xmm15, xmm2
00007f0145bcf90c  mulpd xmm15, xmm1
00007f0145bcf911  vcmppd xmm14, xmm15, xmm15, 0x03
00007f0145bcf917  ptest xmm14, xmm14
00007f0145bcf91d  jnz 0x00007F0145BD16FE
00007f0145bcf923  lea rax, [r14+0xE0]
00007f0145bcf92a  movups xmm1, [r13+rax*1]
00007f0145bcf930  vmovaps xmm14, [rsp+0x100]
00007f0145bcf939  vpermilpd xmm14, xmm14, 0x00
00007f0145bcf93f  vmovaps [rsp+0x100], xmm1
00007f0145bcf948  vmovaps xmm1, [rsp+0x30]
00007f0145bcf94e  vmovaps [rsp+0x30], xmm15
00007f0145bcf954  movaps xmm2, xmm1
00007f0145bcf957  mulpd xmm2, xmm14
00007f0145bcf95c  vcmppd xmm15, xmm2, xmm2, 0x03
00007f0145bcf961  ptest xmm15, xmm15
00007f0145bcf967  jnz 0x00007F0145BD184A
00007f0145bcf96d  vmovaps [rsp+0x120], xmm10
00007f0145bcf976  vmovaps xmm1, [rsp+0x120]
00007f0145bcf97f  por xmm10, xmm1
00007f0145bcf984  movaps [r15+0x300], xmm10
00007f0145bcf98c  vmovaps [rsp+0x120], xmm8
00007f0145bcf995  vmovaps xmm1, [rsp+0x120]
00007f0145bcf99e  por xmm8, xmm1
00007f0145bcf9a3  movaps [r15+0x190], xmm8
00007f0145bcf9ab  vmovaps xmm1, [rsp+0xA0]
00007f0145bcf9b4  vpermilpd xmm1, xmm1, 0x00
00007f0145bcf9ba  vmovaps xmm14, [rsp+0x100]
00007f0145bcf9c3  vmovaps [rsp+0x100], xmm13
00007f0145bcf9cc  movaps xmm15, xmm14
00007f0145bcf9d0  mulpd xmm15, xmm1
00007f0145bcf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
00007f0145bcf9db  ptest xmm13, xmm13
00007f0145bcf9e1  jnz 0x00007F0145BD198B
00007f0145bcf9e7  lea rax, [r14+0x90]
00007f0145bcf9ee  movups xmm1, [r13+rax*1]
00007f0145bcf9f4  vmovaps [rsp+0x120], xmm4
00007f0145bcf9fd  vmovaps xmm14, [rsp+0x120]
00007f0145bcfa06  por xmm4, xmm14
00007f0145bcfa0b  movaps [r15+0x1C0], xmm4
00007f0145bcfa13  vmovaps [rsp+0x120], xmm11
00007f0145bcfa1c  vmovaps xmm14, [rsp+0x120]
00007f0145bcfa25  por xmm11, xmm14
00007f0145bcfa2a  movaps [r15+0x200], xmm11
00007f0145bcfa32  vmovaps [rsp+0x120], xmm5
00007f0145bcfa3b  vmovaps xmm14, [rsp+0x120]
00007f0145bcfa44  por xmm5, xmm14
00007f0145bcfa49  movaps [r15+0x2D0], xmm5
00007f0145bcfa51  vmovaps [rsp+0x120], xmm12
00007f0145bcfa5a  vmovaps xmm14, [rsp+0x120]
00007f0145bcfa63  por xmm12, xmm14
00007f0145bcfa68  movaps [r15+0x2E0], xmm12
00007f0145bcfa70  vmovaps xmm13, [rsp+0x110]
00007f0145bcfa79  vmovaps [rsp+0x110], xmm1
00007f0145bcfa82  vmovaps xmm1, [rsp+0xE0]
00007f0145bcfa8b  vmovaps [rsp+0xE0], xmm15
00007f0145bcfa94  movaps xmm14, xmm13
00007f0145bcfa98  addpd xmm14, xmm1
00007f0145bcfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
00007f0145bcfaa3  ptest xmm15, xmm15
00007f0145bcfaa9  jnz 0x00007F0145BD1AD8
00007f0145bcfaaf  vmovaps xmm1, [rsp+0xA0]
00007f0145bcfab8  vpermilpd xmm1, xmm1, 0x00
00007f0145bcfabe  vmovaps xmm13, [rsp+0x110]
00007f0145bcfac7  vmovaps [rsp+0x110], xmm14
00007f0145bcfad0  movaps xmm15, xmm13
00007f0145bcfad4  mulpd xmm15, xmm1
00007f0145bcfad9  vcmppd xmm14, xmm15, xmm15, 0x03
00007f0145bcfadf  ptest xmm14, xmm14
00007f0145bcfae5  jnz 0x00007F0145BD1C1B
00007f0145bcfaeb  lea rax, [r14+0x80]
00007f0145bcfaf2  movups xmm1, [r13+rax*1]
00007f0145bcfaf8  vmovaps xmm13, [rsp+0xC0]
00007f0145bcfb01  vmovaps [rsp+0xC0], xmm1
00007f0145bcfb0a  movaps xmm14, xmm13
00007f0145bcfb0e  addpd xmm14, xmm2
00007f0145bcfb13  vcmppd xmm1, xmm14, xmm14, 0x03
00007f0145bcfb19  ptest xmm1, xmm1
00007f0145bcfb1e  jnz 0x00007F0145BD1D68
00007f0145bcfb24  vmovaps xmm13, [rsp+0x100]
00007f0145bcfb2d  vmovaps xmm2, [rsp+0x30]
00007f0145bcfb33  vmovaps [rsp+0x30], xmm15
00007f0145bcfb39  movaps xmm1, xmm13
00007f0145bcfb3d  addpd xmm1, xmm2
00007f0145bcfb41  vcmppd xmm15, xmm1, xmm1, 0x03
00007f0145bcfb46  ptest xmm15, xmm15
00007f0145bcfb4c  jnz 0x00007F0145BD1EAB
00007f0145bcfb52  vmovaps xmm15, [rsp+0x20]
00007f0145bcfb58  vmovaps xmm13, [rsp+0x20]
00007f0145bcfb5e  por xmm15, xmm13
00007f0145bcfb63  movaps [r15+0x2F0], xmm15
00007f0145bcfb6b  vmovaps xmm13, [rsp+0xA0]
00007f0145bcfb74  vpermilpd xmm13, xmm13, 0x00
00007f0145bcfb7a  vmovaps [rsp+0x20], xmm1
00007f0145bcfb80  vmovaps xmm1, [rsp+0xC0]
00007f0145bcfb89  vmovaps [rsp+0xA0], xmm15
00007f0145bcfb92  movaps xmm2, xmm1
00007f0145bcfb95  mulpd xmm2, xmm13
00007f0145bcfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
00007f0145bcfb9f  ptest xmm15, xmm15
00007f0145bcfba5  jnz 0x00007F0145BD1FEC
00007f0145bcfbab  lea rax, [r14+0xD0]
00007f0145bcfbb2  movups xmm1, [r13+rax*1]
00007f0145bcfbb8  vmovaps xmm13, [rsp+0xF0]
00007f0145bcfbc1  vmovaps [rsp+0xC0], xmm1
00007f0145bcfbca  vmovaps xmm1, [rsp+0xE0]
00007f0145bcfbd3  vmovaps [rsp+0xE0], xmm14
00007f0145bcfbdc  movaps xmm15, xmm13
00007f0145bcfbe0  addpd xmm15, xmm1
00007f0145bcfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
00007f0145bcfbeb  ptest xmm14, xmm14
00007f0145bcfbf1  jnz 0x00007F0145BD2137
00007f0145bcfbf7  vmovaps xmm1, [rsp+0xB0]
00007f0145bcfc00  vpermilpd xmm1, xmm1, 0x00
00007f0145bcfc06  movaps xmm14, xmm11
00007f0145bcfc0a  mulpd xmm14, xmm1
00007f0145bcfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
00007f0145bcfc15  ptest xmm13, xmm13
00007f0145bcfc1b  jnz 0x00007F0145BD227A
00007f0145bcfc21  movaps [r15+0x260], xmm14
00007f0145bcfc29  vxorps xmm1, xmm1, xmm1
00007f0145bcfc2d  vpbroadcastq xmm1, xmm1
00007f0145bcfc32  movaps [r15+0x1B0], xmm1
00007f0145bcfc3a  vmovaps xmm1, [rsp+0xB0]
00007f0145bcfc43  vpermilpd xmm1, xmm1, 0x00
00007f0145bcfc49  vmovaps xmm11, [rsp+0xC0]
00007f0145bcfc52  vmovaps [rsp+0xC0], xmm15
00007f0145bcfc5b  movaps xmm13, xmm11
00007f0145bcfc5f  mulpd xmm13, xmm1
00007f0145bcfc64  vcmppd xmm15, xmm13, xmm13, 0x03
00007f0145bcfc6a  ptest xmm15, xmm15
00007f0145bcfc70  jnz 0x00007F0145BD23BD
00007f0145bcfc76  lea rax, [r14+0xC0]
00007f0145bcfc7d  movups xmm1, [r13+rax*1]
00007f0145bcfc83  vmovaps xmm11, [rsp+0x110]
00007f0145bcfc8c  vmovaps [rsp+0xF0], xmm1
00007f0145bcfc95  vmovaps xmm1, [rsp+0x30]
00007f0145bcfc9b  vmovaps [rsp+0x30], xmm14
00007f0145bcfca1  movaps xmm15, xmm11
00007f0145bcfca5  addpd xmm15, xmm1
00007f0145bcfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
00007f0145bcfcb0  ptest xmm14, xmm14
00007f0145bcfcb6  jnz 0x00007F0145BD250A
00007f0145bcfcbc  vmovaps [rsp+0x100], xmm9
00007f0145bcfcc5  vmovaps xmm1, [rsp+0x100]
00007f0145bcfcce  por xmm9, xmm1
00007f0145bcfcd3  movaps [r15+0x270], xmm9
00007f0145bcfcdb  vmovaps [rsp+0x100], xmm6
00007f0145bcfce4  vmovaps xmm1, [rsp+0x100]
00007f0145bcfced  por xmm6, xmm1
00007f0145bcfcf1  movaps [r15+0x1A0], xmm6
00007f0145bcfcf9  vmovaps xmm14, [rsp+0xB0]
00007f0145bcfd02  vpermilpd xmm14, xmm14, 0x00
00007f0145bcfd08  vmovaps xmm6, [rsp+0xF0]
00007f0145bcfd11  vmovaps [rsp+0xF0], xmm1
00007f0145bcfd1a  movaps xmm11, xmm6
00007f0145bcfd1e  mulpd xmm11, xmm14
00007f0145bcfd23  vcmppd xmm1, xmm11, xmm11, 0x03
00007f0145bcfd29  ptest xmm1, xmm1
00007f0145bcfd2e  jnz 0x00007F0145BD264D
00007f0145bcfd34  lea rax, [r14+0x20]
00007f0145bcfd38  movups xmm1, [r13+rax*1]
00007f0145bcfd3e  movaps [r15+0x110], xmm1
00007f0145bcfd46  vmovaps xmm6, [rsp+0xE0]
00007f0145bcfd4f  vmovaps [rsp+0xE0], xmm1
00007f0145bcfd58  movaps xmm14, xmm6
00007f0145bcfd5c  addpd xmm14, xmm2
00007f0145bcfd61  vcmppd xmm1, xmm14, xmm14, 0x03
00007f0145bcfd67  ptest xmm1, xmm1
00007f0145bcfd6c  jnz 0x00007F0145BD279A
00007f0145bcfd72  vmovaps xmm1, [rsp+0xB0]
00007f0145bcfd7b  vpermilpd xmm1, xmm1, 0x00
00007f0145bcfd81  movaps xmm6, xmm5
00007f0145bcfd84  mulpd xmm6, xmm1
00007f0145bcfd88  vcmppd xmm2, xmm6, xmm6, 0x03
00007f0145bcfd8d  ptest xmm2, xmm2
00007f0145bcfd92  jnz 0x00007F0145BD28DC
00007f0145bcfd98  vmovaps xmm5, [rsp+0x20]
00007f0145bcfd9e  movaps xmm1, xmm5
00007f0145bcfda1  addpd xmm1, xmm13
00007f0145bcfda6  vcmppd xmm2, xmm1, xmm1, 0x03
00007f0145bcfdab  ptest xmm2, xmm2
00007f0145bcfdb0  jnz 0x00007F0145BD2A1C
00007f0145bcfdb6  vmovaps xmm13, [rsp+0x80]
00007f0145bcfdbf  vpermilpd xmm13, xmm13, 0x00
00007f0145bcfdc5  vmovaps xmm2, [rsp+0xE0]
00007f0145bcfdce  vmovaps [rsp+0x20], xmm1
00007f0145bcfdd4  movaps xmm5, xmm2
00007f0145bcfdd7  mulpd xmm5, xmm13
00007f0145bcfddc  vcmppd xmm1, xmm5, xmm5, 0x03
00007f0145bcfde1  ptest xmm1, xmm1
00007f0145bcfde6  jnz 0x00007F0145BD2B5D
00007f0145bcfdec  vmovaps xmm1, [rsp+0x80]
00007f0145bcfdf5  vpermilpd xmm1, xmm1, 0x00
00007f0145bcfdfb  movaps xmm13, xmm10
00007f0145bcfdff  mulpd xmm13, xmm1
00007f0145bcfe04  vcmppd xmm2, xmm13, xmm13, 0x03
00007f0145bcfe0a  ptest xmm2, xmm2
00007f0145bcfe0f  jnz 0x00007F0145BD2C9E
00007f0145bcfe15  vmovaps xmm10, [rsp+0x30]
00007f0145bcfe1b  movaps xmm1, xmm15
00007f0145bcfe1f  addpd xmm1, xmm10
00007f0145bcfe24  vcmppd xmm2, xmm1, xmm1, 0x03
00007f0145bcfe29  ptest xmm2, xmm2
00007f0145bcfe2e  jnz 0x00007F0145BD2DE1
00007f0145bcfe34  vmovaps xmm10, [rsp+0xC0]
00007f0145bcfe3d  movaps xmm15, xmm10
00007f0145bcfe41  addpd xmm15, xmm11
00007f0145bcfe46  vcmppd xmm2, xmm15, xmm15, 0x03
00007f0145bcfe4c  ptest xmm2, xmm2
00007f0145bcfe51  jnz 0x00007F0145BD2F23
00007f0145bcfe57  vmovaps xmm11, [rsp+0x80]
00007f0145bcfe60  vpermilpd xmm11, xmm11, 0x00
00007f0145bcfe66  movaps xmm10, xmm12
00007f0145bcfe6a  mulpd xmm10, xmm11
00007f0145bcfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
00007f0145bcfe75  ptest xmm2, xmm2
00007f0145bcfe7a  jnz 0x00007F0145BD3067
00007f0145bcfe80  vmovaps xmm12, [rsp+0x80]
00007f0145bcfe89  vpermilpd xmm12, xmm12, 0x00
00007f0145bcfe8f  vmovaps xmm2, [rsp+0xA0]
00007f0145bcfe98  vmovaps [rsp+0x30], xmm1
00007f0145bcfe9e  movaps xmm11, xmm2
00007f0145bcfea2  mulpd xmm11, xmm12
00007f0145bcfea7  vcmppd xmm1, xmm11, xmm11, 0x03
00007f0145bcfead  ptest xmm1, xmm1
00007f0145bcfeb2  jnz 0x00007F0145BD31AB
00007f0145bcfeb8  movaps xmm1, xmm14
00007f0145bcfebc  addpd xmm1, xmm6
00007f0145bcfec0  vcmppd xmm12, xmm1, xmm1, 0x03
00007f0145bcfec5  ptest xmm12, xmm12
00007f0145bcfecb  jnz 0x00007F0145BD32EE
00007f0145bcfed1  vmovaps xmm12, [rsp+0x20]
00007f0145bcfed7  movaps xmm14, xmm12
00007f0145bcfedb  addpd xmm14, xmm5
00007f0145bcfee0  vcmppd xmm6, xmm14, xmm14, 0x03
00007f0145bcfee6  ptest xmm6, xmm6
00007f0145bcfeeb  jnz 0x00007F0145BD342F
00007f0145bcfef1  vmovaps xmm12, [rsp+0x90]
00007f0145bcfefa  vpermilpd xmm12, xmm12, 0x00
00007f0145bcff00  movaps xmm6, xmm9
00007f0145bcff04  mulpd xmm6, xmm12
00007f0145bcff09  vcmppd xmm5, xmm6, xmm6, 0x03
00007f0145bcff0e  ptest xmm5, xmm5
00007f0145bcff13  jnz 0x00007F0145BD3572
00007f0145bcff19  movaps xmm12, xmm15
00007f0145bcff1d  addpd xmm12, xmm13
00007f0145bcff22  vcmppd xmm9, xmm12, xmm12, 0x03
00007f0145bcff28  ptest xmm9, xmm9
00007f0145bcff2e  jnz 0x00007F0145BD36B4
00007f0145bcff34  vmovaps xmm13, [rsp+0x30]
00007f0145bcff3a  movaps xmm15, xmm13
00007f0145bcff3e  addpd xmm15, xmm10
00007f0145bcff43  vcmppd xmm9, xmm15, xmm15, 0x03
00007f0145bcff49  ptest xmm9, xmm9
00007f0145bcff4f  jnz 0x00007F0145BD37F8
00007f0145bcff55  vmovaps xmm13, [rsp+0xD0]
00007f0145bcff5e  vmovaps xmm10, [rsp+0xD0]
00007f0145bcff67  por xmm13, xmm10
00007f0145bcff6c  movaps [r15+0x250], xmm13
00007f0145bcff74  vmovaps [rsp+0x20], xmm7
00007f0145bcff7a  vmovaps xmm13, [rsp+0x20]
00007f0145bcff80  por xmm7, xmm13
00007f0145bcff85  movaps [r15+0x2A0], xmm7
00007f0145bcff8d  vmovaps [rsp+0x20], xmm3
00007f0145bcff93  vmovaps xmm13, [rsp+0x20]
00007f0145bcff99  por xmm3, xmm13
00007f0145bcff9e  movaps [r15+0x1D0], xmm3
00007f0145bcffa6  lea rax, [r14+0x40]
00007f0145bcffaa  movups xmm13, [r13+rax*1]
00007f0145bcffb0  movaps [r15+0x2C0], xmm13
00007f0145bcffb8  vmovaps xmm10, [rsp+0x90]
00007f0145bcffc1  vpermilpd xmm10, xmm10, 0x00
00007f0145bcffc7  movaps xmm9, xmm8
00007f0145bcffcb  mulpd xmm9, xmm10
00007f0145bcffd0  vcmppd xmm5, xmm9, xmm9, 0x03
00007f0145bcffd6  ptest xmm5, xmm5
00007f0145bcffdb  jnz 0x00007F0145BD3946
00007f0145bcffe1  movaps xmm10, xmm1
00007f0145bcffe5  addpd xmm10, xmm11
00007f0145bcffea  vcmppd xmm8, xmm10, xmm10, 0x03
00007f0145bcfff0  ptest xmm8, xmm8
00007f0145bcfff6  jnz 0x00007F0145BD3A8A
00007f0145bcfffc  movaps xmm1, xmm14
00007f0145bd0000  addpd xmm1, xmm6
00007f0145bd0004  vcmppd xmm11, xmm1, xmm1, 0x03
00007f0145bd0009  ptest xmm11, xmm11
00007f0145bd000f  jnz 0x00007F0145BD3BCD
00007f0145bd0015  vmovaps xmm14, [rsp+0x90]
00007f0145bd001e  vpermilpd xmm14, xmm14, 0x00
00007f0145bd0024  movaps xmm11, xmm13
00007f0145bd0028  mulpd xmm11, xmm14
00007f0145bd002d  vcmppd xmm8, xmm11, xmm11, 0x03
00007f0145bd0033  ptest xmm8, xmm8
00007f0145bd0039  jnz 0x00007F0145BD3D0E
00007f0145bd003f  vmovaps xmm14, [rsp+0x90]
00007f0145bd0048  vpermilpd xmm14, xmm14, 0x00
00007f0145bd004e  vmovaps xmm8, [rsp+0x10]
00007f0145bd0054  movaps xmm13, xmm8
00007f0145bd0058  mulpd xmm13, xmm14
00007f0145bd005d  vcmppd xmm6, xmm13, xmm13, 0x03
00007f0145bd0063  ptest xmm6, xmm6
00007f0145bd0068  jnz 0x00007F0145BD3E52
00007f0145bd006e  vmovaps xmm14, [rsp+0x60]
00007f0145bd0074  vpermilpd xmm14, xmm14, 0x00
00007f0145bd007a  movaps xmm8, xmm7
00007f0145bd007e  mulpd xmm8, xmm14
00007f0145bd0083  vcmppd xmm6, xmm8, xmm8, 0x03
00007f0145bd0089  ptest xmm6, xmm6
00007f0145bd008e  jnz 0x00007F0145BD3F96
00007f0145bd0094  movaps xmm14, xmm12
00007f0145bd0098  addpd xmm14, xmm9
00007f0145bd009d  vcmppd xmm7, xmm14, xmm14, 0x03
00007f0145bd00a3  ptest xmm7, xmm7
00007f0145bd00a8  jnz 0x00007F0145BD40D9
00007f0145bd00ae  vmovaps xmm12, [rsp+0x60]
00007f0145bd00b4  vpermilpd xmm12, xmm12, 0x00
00007f0145bd00ba  vmovaps xmm7, [rsp+0xF0]
00007f0145bd00c3  movaps xmm9, xmm7
00007f0145bd00c7  mulpd xmm9, xmm12
00007f0145bd00cc  vcmppd xmm6, xmm9, xmm9, 0x03
00007f0145bd00d2  ptest xmm6, xmm6
00007f0145bd00d7  jnz 0x00007F0145BD421D
00007f0145bd00dd  movaps xmm12, xmm15
00007f0145bd00e1  addpd xmm12, xmm11
00007f0145bd00e6  vcmppd xmm7, xmm12, xmm12, 0x03
00007f0145bd00ec  ptest xmm7, xmm7
00007f0145bd00f1  jnz 0x00007F0145BD4360
00007f0145bd00f7  vmovaps xmm15, [rsp+0x60]
00007f0145bd00fd  vpermilpd xmm15, xmm15, 0x00
00007f0145bd0103  vmovaps xmm7, [rsp+0x40]
00007f0145bd0109  movaps xmm11, xmm7
00007f0145bd010d  mulpd xmm11, xmm15
00007f0145bd0112  vcmppd xmm6, xmm11, xmm11, 0x03
00007f0145bd0118  ptest xmm6, xmm6
00007f0145bd011d  jnz 0x00007F0145BD44A4
00007f0145bd0123  movaps xmm15, xmm10
00007f0145bd0127  addpd xmm15, xmm13
00007f0145bd012c  vcmppd xmm7, xmm15, xmm15, 0x03
00007f0145bd0132  ptest xmm7, xmm7
00007f0145bd0137  jnz 0x00007F0145BD45E7
00007f0145bd013d  vmovaps xmm13, [rsp+0x60]
00007f0145bd0143  vpermilpd xmm13, xmm13, 0x00
00007f0145bd0149  vmovaps xmm7, [rsp+0x50]
00007f0145bd014f  movaps xmm10, xmm7
00007f0145bd0153  mulpd xmm10, xmm13
00007f0145bd0158  vcmppd xmm6, xmm10, xmm10, 0x03
00007f0145bd015e  ptest xmm6, xmm6
00007f0145bd0163  jnz 0x00007F0145BD472B
00007f0145bd0169  movaps xmm13, xmm1
00007f0145bd016d  addpd xmm13, xmm8
00007f0145bd0172  vcmppd xmm7, xmm13, xmm13, 0x03
00007f0145bd0178  ptest xmm7, xmm7
00007f0145bd017d  jnz 0x00007F0145BD486E
00007f0145bd0183  lea rax, [r14+0x70]
00007f0145bd0187  movups xmm1, [r13+rax*1]
00007f0145bd018d  movaps [r15+0x240], xmm1
00007f0145bd0195  movaps xmm8, xmm14
00007f0145bd0199  addpd xmm8, xmm9
00007f0145bd019e  vcmppd xmm7, xmm8, xmm8, 0x03
00007f0145bd01a4  ptest xmm7, xmm7
00007f0145bd01a9  jnz 0x00007F0145BD49BB
00007f0145bd01af  movaps [r15+0x170], xmm8
00007f0145bd01b7  vmovaps xmm14, [rsp+0x70]
00007f0145bd01bd  vpermilpd xmm14, xmm14, 0x00
00007f0145bd01c3  movaps xmm9, xmm1
00007f0145bd01c7  mulpd xmm9, xmm14
00007f0145bd01cc  vcmppd xmm7, xmm9, xmm9, 0x03
00007f0145bd01d2  ptest xmm7, xmm7
00007f0145bd01d7  jnz 0x00007F0145BD4AFF
00007f0145bd01dd  vmovaps xmm1, [rsp+0x70]
00007f0145bd01e3  vpermilpd xmm1, xmm1, 0x00
00007f0145bd01e9  movaps xmm14, xmm4
00007f0145bd01ed  mulpd xmm14, xmm1
00007f0145bd01f2  vcmppd xmm7, xmm14, xmm14, 0x03
00007f0145bd01f8  ptest xmm7, xmm7
00007f0145bd01fd  jnz 0x00007F0145BD4C42
00007f0145bd0203  movaps [r15+0x180], xmm14
00007f0145bd020b  movaps xmm1, xmm12
00007f0145bd020f  addpd xmm1, xmm11
00007f0145bd0214  vcmppd xmm7, xmm1, xmm1, 0x03
00007f0145bd0219  ptest xmm7, xmm7
00007f0145bd021e  jnz 0x00007F0145BD4D84
00007f0145bd0224  movaps [r15+0x210], xmm1
00007f0145bd022c  movups xmm12, [r13+r14*1]
00007f0145bd0232  lea rax, [r14+0x10]
00007f0145bd0236  movups xmm11, [r13+rax*1]
00007f0145bd023c  movaps [r15+0x230], xmm11
00007f0145bd0244  movaps xmm7, xmm15
00007f0145bd0248  addpd xmm7, xmm10
00007f0145bd024d  vcmppd xmm6, xmm7, xmm7, 0x03
00007f0145bd0252  ptest xmm6, xmm6
00007f0145bd0257  jnz 0x00007F0145BD4EDA
00007f0145bd025d  movaps [r15+0x130], xmm7
00007f0145bd0265  vmovaps xmm15, [rsp+0x70]
00007f0145bd026b  vpermilpd xmm15, xmm15, 0x00
00007f0145bd0271  movaps xmm10, xmm11
00007f0145bd0275  mulpd xmm10, xmm15
00007f0145bd027a  vcmppd xmm6, xmm10, xmm10, 0x03
00007f0145bd0280  ptest xmm6, xmm6
00007f0145bd0285  jnz 0x00007F0145BD501C
00007f0145bd028b  movaps [r15+0x220], xmm10
00007f0145bd0293  vmovaps xmm15, [rsp+0x70]
00007f0145bd0299  vpermilpd xmm15, xmm15, 0x00
00007f0145bd029f  movaps xmm11, xmm12
00007f0145bd02a3  mulpd xmm11, xmm15
00007f0145bd02a8  vcmppd xmm6, xmm11, xmm11, 0x03
00007f0145bd02ae  ptest xmm6, xmm6
00007f0145bd02b3  jnz 0x00007F0145BD5160
00007f0145bd02b9  movaps xmm15, xmm13
00007f0145bd02bd  addpd xmm15, xmm9
00007f0145bd02c2  vcmppd xmm12, xmm15, xmm15, 0x03
00007f0145bd02c8  ptest xmm12, xmm12
00007f0145bd02ce  jnz 0x00007F0145BD52A4
00007f0145bd02d4  movaps [r15+0x140], xmm15
00007f0145bd02dc  movaps xmm13, xmm8
00007f0145bd02e0  addpd xmm13, xmm14
00007f0145bd02e5  vcmppd xmm12, xmm13, xmm13, 0x03
00007f0145bd02eb  ptest xmm12, xmm12
00007f0145bd02f1  jnz 0x00007F0145BD53E8
00007f0145bd02f7  movaps [r15+0x150], xmm13
00007f0145bd02ff  movaps xmm14, xmm1
00007f0145bd0303  addpd xmm14, xmm10
00007f0145bd0308  vcmppd xmm12, xmm14, xmm14, 0x03
00007f0145bd030e  ptest xmm12, xmm12
00007f0145bd0314  jnz 0x00007F0145BD552C
00007f0145bd031a  movaps [r15+0x160], xmm14
00007f0145bd0322  movaps xmm1, xmm7
00007f0145bd0325  addpd xmm1, xmm11
00007f0145bd032a  vcmppd xmm12, xmm1, xmm1, 0x03
00007f0145bd032f  ptest xmm12, xmm12
00007f0145bd0335  jnz 0x00007F0145BD566F
00007f0145bd033b  movaps [r15+0x120], xmm1
00007f0145bd0343  mov eax, 0x430920
00007f0145bd0348  movups [r13+rax*1], xmm15
00007f0145bd034e  mov eax, 0x430930
00007f0145bd0353  movups [r13+rax*1], xmm13
00007f0145bd0359  mov eax, 0x430940
00007f0145bd035e  movups [r13+rax*1], xmm14
00007f0145bd0364  mov eax, 0x430950
00007f0145bd0369  movups [r13+rax*1], xmm1
00007f0145bd036f  mov eax, [r15+0x108]
00007f0145bd0376  sahf
00007f0145bd0377  jnz 0x00007F0145BD03A9
00007f0145bd0379  cmp dword ptr [r15+0x318], 0x00
00007f0145bd0381  jz 0x00007F0145BDB900
00007f0145bd0387  nop [rax+rax*1], ax
00007f0145bd0390  nop [rax+rax*1], eax
00007f0145bd0398  mov eax, 0x410444
00007f0145bd039d  mov [r15+0x100], rax
00007f0145bd03a4  jmp 0x00007F01459FE110
00007f0145bd03a9  cmp dword ptr [r15+0x318], 0x00
00007f0145bd03b1  jz 0x00007F0145BD57E0
00007f0145bd03b7  nop [rax+rax*1], ax
00007f0145bd03c0  nop [rax+rax*1], eax
00007f0145bd03c8  mov eax, 0x410278
00007f0145bd03cd  mov [r15+0x100], rax
00007f0145bd03d4  jmp 0x00007F01459FE110
00007f0145bd03d9  int3
00007f0145bd03da  call 0x00007F0145AB52F0
00007f0145bd03df  jmp 0x00007F0145BCF016
00007f0145bd03e4  call 0x00007F0145AC4620
00007f0145bd03e9  jmp 0x00007F0145BCF023
00007f0145bd03ee  call 0x00007F0145AC33A0
00007f0145bd03f3  jmp 0x00007F0145BCF035
00007f0145bd03f8  call 0x00007F0145AC2120
00007f0145bd03fd  jmp 0x00007F0145BCF03F
00007f0145bd0402  call 0x00007F0145AC0860
00007f0145bd0407  jmp 0x00007F0145BCF067
00007f0145bd040c  call 0x00007F0145ABF5F0
00007f0145bd0411  jmp 0x00007F0145BCF073
00007f0145bd0416  call 0x00007F0145AC0860
00007f0145bd041b  jmp 0x00007F0145BCF0A5
00007f0145bd0420  call 0x00007F0145ABF5F0
00007f0145bd0425  jmp 0x00007F0145BCF0B1
00007f0145bd042a  call 0x00007F0145AC4740
00007f0145bd042f  jmp 0x00007F0145BCF0BE
00007f0145bd0434  call 0x00007F0145AB5400
00007f0145bd0439  jmp 0x00007F0145BCF0CB
00007f0145bd043e  call 0x00007F0145AB52F0
00007f0145bd0443  jmp 0x00007F0145BCF0D8
00007f0145bd0448  call 0x00007F0145AC4620
00007f0145bd044d  jmp 0x00007F0145BCF0E5
00007f0145bd0452  call 0x00007F0145AC0860
00007f0145bd0457  jmp 0x00007F0145BCF10D
00007f0145bd045c  call 0x00007F0145ABF5F0
00007f0145bd0461  jmp 0x00007F0145BCF119
00007f0145bd0466  call 0x00007F0145A09D70
00007f0145bd046b  jmp 0x00007F0145BCF11F
00007f0145bd0470  call 0x00007F0145ABE9C0
00007f0145bd0475  jmp 0x00007F0145BCF129
00007f0145bd047a  call 0x00007F0145AC0860
00007f0145bd047f  jmp 0x00007F0145BCF151
00007f0145bd0484  call 0x00007F0145ABF5F0
00007f0145bd0489  jmp 0x00007F0145BCF15D
00007f0145bd048e  call 0x00007F0145ABD750
00007f0145bd0493  jmp 0x00007F0145BCF16A
00007f0145bd0498  call 0x00007F0145ABC4E0
00007f0145bd049d  jmp 0x00007F0145BCF177
00007f0145bd04a2  call 0x00007F0145AC4740
00007f0145bd04a7  jmp 0x00007F0145BCF184
00007f0145bd04ac  call 0x00007F0145AB5400
00007f0145bd04b1  jmp 0x00007F0145BCF191
00007f0145bd04b6  call 0x00007F0145AB52F0
00007f0145bd04bb  jmp 0x00007F0145BCF19E
00007f0145bd04c0  call 0x00007F0145AC4620
00007f0145bd04c5  jmp 0x00007F0145BCF1AB
00007f0145bd04ca  call 0x00007F0145AC0860
00007f0145bd04cf  jmp 0x00007F0145BCF1BE
00007f0145bd04d4  call 0x00007F0145ABB270
00007f0145bd04d9  jmp 0x00007F0145BCF1CB
00007f0145bd04de  call 0x00007F0145ABA000
00007f0145bd04e3  jmp 0x00007F0145BCF1D8
00007f0145bd04e8  call 0x00007F0145AB8D90
00007f0145bd04ed  jmp 0x00007F0145BCF1E5
00007f0145bd04f2  call 0x00007F0145AB8A20
00007f0145bd04f7  jmp 0x00007F0145BCF1F2
00007f0145bd04fc  call 0x00007F0145AB5400
00007f0145bd0501  jmp 0x00007F0145BCF1FC
00007f0145bd0506  call 0x00007F0145AC2240
00007f0145bd050b  jmp 0x00007F0145BCF206
00007f0145bd0510  call 0x00007F0145AB52F0
00007f0145bd0515  jmp 0x00007F0145BCF210
00007f0145bd051a  call 0x00007F0145AC2120
00007f0145bd051f  jmp 0x00007F0145BCF21A
00007f0145bd0524  call 0x00007F0145AB77B0
00007f0145bd0529  jmp 0x00007F0145BCF224
00007f0145bd052e  call 0x00007F0145AB6550
00007f0145bd0533  jmp 0x00007F0145BCF22E
00007f0145bd0538  call 0x00007F0145ABFD50
00007f0145bd053d  jmp 0x00007F0145BCF240
00007f0145bd0542  call 0x00007F0145AB8EA0
00007f0145bd0547  jmp 0x00007F0145BCF24A
00007f0145bd054c  call 0x00007F0145ABFC30
00007f0145bd0551  jmp 0x00007F0145BCF257
00007f0145bd0556  call 0x00007F0145AB8D90
00007f0145bd055b  jmp 0x00007F0145BCF264
00007f0145bd0560  call 0x00007F0145AC2240
00007f0145bd0565  jmp 0x00007F0145BCF271
00007f0145bd056a  call 0x00007F0145AB5400
00007f0145bd056f  jmp 0x00007F0145BCF27E
00007f0145bd0574  call 0x00007F0145AB52F0
00007f0145bd0579  jmp 0x00007F0145BCF28B
00007f0145bd057e  call 0x00007F0145AC2120
00007f0145bd0583  jmp 0x00007F0145BCF298
00007f0145bd0588  call 0x00007F0145AB52F0
00007f0145bd058d  jmp 0x00007F0145BCF2AB
00007f0145bd0592  call 0x00007F0145AB52F0
00007f0145bd0597  jmp 0x00007F0145BCF2BE
00007f0145bd059c  call 0x00007F0145AB52F0
00007f0145bd05a1  jmp 0x00007F0145BCF2D1
00007f0145bd05a6  call 0x00007F0145AB52F0
00007f0145bd05ab  jmp 0x00007F0145BCF2E4
00007f0145bd05b0  call 0x00007F0145AC2240
00007f0145bd05b5  jmp 0x00007F0145BCF2F9
00007f0145bd05ba  call 0x00007F0145AC2240
00007f0145bd05bf  jmp 0x00007F0145BCF30C
00007f0145bd05c4  call 0x00007F0145AC2120
00007f0145bd05c9  jmp 0x00007F0145BCF319
00007f0145bd05ce  call 0x00007F0145AB52F0
00007f0145bd05d3  jmp 0x00007F0145BCF32C
00007f0145bd05d8  call 0x00007F0145AB52F0
00007f0145bd05dd  jmp 0x00007F0145BCF34F
00007f0145bd05e2  call 0x00007F0145AB52F0
00007f0145bd05e7  jmp 0x00007F0145BCF362
00007f0145bd05ec  call 0x00007F01459FF540
00007f0145bd05f1  jmp 0x00007F0145BCF380
00007f0145bd05f6  call 0x00007F0145A08C20
00007f0145bd05fb  jmp 0x00007F0145BCF38A
00007f0145bd0600  call 0x00007F0145AD6600
00007f0145bd0605  jmp 0x00007F0145BCF396
00007f0145bd060a  call 0x00007F01459FF540
00007f0145bd060f  jmp 0x00007F0145BCF3A6
00007f0145bd0614  call 0x00007F0145AC0370
00007f0145bd0619  jmp 0x00007F0145BCF3D4
00007f0145bd061e  call 0x00007F0145ABF100
00007f0145bd0623  jmp 0x00007F0145BCF3DD
00007f0145bd0628  call 0x00007F0145AC0370
00007f0145bd062d  jmp 0x00007F0145BCF43B
00007f0145bd0632  call 0x00007F0145ABF100
00007f0145bd0637  jmp 0x00007F0145BCF444
00007f0145bd063c  call 0x00007F0145AC0370
00007f0145bd0641  jmp 0x00007F0145BCF48B
00007f0145bd0646  call 0x00007F0145ABF100
00007f0145bd064b  jmp 0x00007F0145BCF494
00007f0145bd0650  call 0x00007F0145A0B720
00007f0145bd0655  jmp 0x00007F0145BCF4D7
00007f0145bd065a  call 0x00007F0145AB47C0
00007f0145bd065f  jmp 0x00007F0145BCF4EA
00007f0145bd0664  call 0x00007F0145A08B00
00007f0145bd0669  jmp 0x00007F0145BCF501
00007f0145bd066e  call 0x00007F01459FF430
00007f0145bd0673  jmp 0x00007F0145BCF514
00007f0145bd0678  call 0x00007F01459FF430
00007f0145bd067d  jmp 0x00007F0145BCF527
00007f0145bd0682  sub rsp, 0x08
00007f0145bd0686  push rax
00007f0145bd0687  push rcx
00007f0145bd0688  push rdx
00007f0145bd0689  push rdi
00007f0145bd068a  push rsi
00007f0145bd068b  push r8
00007f0145bd068d  push r9
00007f0145bd068f  push r10
00007f0145bd0691  push r11
00007f0145bd0693  sub rsp, 0xF0
00007f0145bd069a  vmovaps [rsp], xmm0
00007f0145bd069f  vmovaps [rsp+0x10], xmm2
00007f0145bd06a5  vmovaps [rsp+0x20], xmm3
00007f0145bd06ab  vmovaps [rsp+0x30], xmm4
00007f0145bd06b1  vmovaps [rsp+0x40], xmm5
00007f0145bd06b7  vmovaps [rsp+0x50], xmm6
00007f0145bd06bd  vmovaps [rsp+0x60], xmm7
00007f0145bd06c3  vmovaps [rsp+0x70], xmm8
00007f0145bd06c9  vmovaps [rsp+0x80], xmm9
00007f0145bd06d2  vmovaps [rsp+0x90], xmm10
00007f0145bd06db  vmovaps [rsp+0xA0], xmm11
00007f0145bd06e4  vmovaps [rsp+0xB0], xmm12
00007f0145bd06ed  vmovaps [rsp+0xC0], xmm13
00007f0145bd06f6  vmovaps [rsp+0xD0], xmm14
00007f0145bd06ff  vmovaps [rsp+0xE0], xmm15
00007f0145bd0708  sub rsp, 0x30
00007f0145bd070c  movaps [rsp], xmm1
00007f0145bd0710  movaps [rsp+0x10], xmm15
00007f0145bd0716  movaps [rsp+0x20], xmm14
00007f0145bd071c  lea rdi, [rsp]
00007f0145bd0720  mov esi, 0x00
00007f0145bd0725  mov rax, 0x636570E98530
00007f0145bd072f  call rax
00007f0145bd0731  movaps xmm1, [rsp]
00007f0145bd0735  add rsp, 0x30
00007f0145bd0739  vmovaps xmm0, [rsp]
00007f0145bd073e  vmovaps xmm2, [rsp+0x10]
00007f0145bd0744  vmovaps xmm3, [rsp+0x20]
00007f0145bd074a  vmovaps xmm4, [rsp+0x30]
00007f0145bd0750  vmovaps xmm5, [rsp+0x40]
00007f0145bd0756  vmovaps xmm6, [rsp+0x50]
00007f0145bd075c  vmovaps xmm7, [rsp+0x60]
00007f0145bd0762  vmovaps xmm8, [rsp+0x70]
00007f0145bd0768  vmovaps xmm9, [rsp+0x80]
00007f0145bd0771  vmovaps xmm10, [rsp+0x90]
00007f0145bd077a  vmovaps xmm11, [rsp+0xA0]
00007f0145bd0783  vmovaps xmm12, [rsp+0xB0]
00007f0145bd078c  vmovaps xmm13, [rsp+0xC0]
00007f0145bd0795  vmovaps xmm14, [rsp+0xD0]
00007f0145bd079e  vmovaps xmm15, [rsp+0xE0]
00007f0145bd07a7  add rsp, 0xF0
00007f0145bd07ae  pop r11
00007f0145bd07b0  pop r10
00007f0145bd07b2  pop r9
00007f0145bd07b4  pop r8
00007f0145bd07b6  pop rsi
00007f0145bd07b7  pop rdi
00007f0145bd07b8  pop rdx
00007f0145bd07b9  pop rcx
00007f0145bd07ba  pop rax
00007f0145bd07bb  add rsp, 0x08
00007f0145bd07bf  jmp 0x00007F0145BCF581
00007f0145bd07c4  sub rsp, 0x08
00007f0145bd07c8  push rax
00007f0145bd07c9  push rcx
00007f0145bd07ca  push rdx
00007f0145bd07cb  push rdi
00007f0145bd07cc  push rsi
00007f0145bd07cd  push r8
00007f0145bd07cf  push r9
00007f0145bd07d1  push r10
00007f0145bd07d3  push r11
00007f0145bd07d5  sub rsp, 0xF0
00007f0145bd07dc  vmovaps [rsp], xmm0
00007f0145bd07e1  vmovaps [rsp+0x10], xmm1
00007f0145bd07e7  vmovaps [rsp+0x20], xmm2
00007f0145bd07ed  vmovaps [rsp+0x30], xmm3
00007f0145bd07f3  vmovaps [rsp+0x40], xmm4
00007f0145bd07f9  vmovaps [rsp+0x50], xmm5
00007f0145bd07ff  vmovaps [rsp+0x60], xmm6
00007f0145bd0805  vmovaps [rsp+0x70], xmm7
00007f0145bd080b  vmovaps [rsp+0x80], xmm8
00007f0145bd0814  vmovaps [rsp+0x90], xmm9
00007f0145bd081d  vmovaps [rsp+0xA0], xmm10
00007f0145bd0826  vmovaps [rsp+0xB0], xmm11
00007f0145bd082f  vmovaps [rsp+0xC0], xmm12
00007f0145bd0838  vmovaps [rsp+0xD0], xmm14
00007f0145bd0841  vmovaps [rsp+0xE0], xmm15
00007f0145bd084a  sub rsp, 0x30
00007f0145bd084e  movaps [rsp], xmm13
00007f0145bd0853  movaps [rsp+0x10], xmm1
00007f0145bd0858  movaps [rsp+0x20], xmm14
00007f0145bd085e  lea rdi, [rsp]
00007f0145bd0862  mov esi, 0x00
00007f0145bd0867  mov rax, 0x636570E98530
00007f0145bd0871  call rax
00007f0145bd0873  movaps xmm13, [rsp]
00007f0145bd0878  add rsp, 0x30
00007f0145bd087c  vmovaps xmm0, [rsp]
00007f0145bd0881  vmovaps xmm1, [rsp+0x10]
00007f0145bd0887  vmovaps xmm2, [rsp+0x20]
00007f0145bd088d  vmovaps xmm3, [rsp+0x30]
00007f0145bd0893  vmovaps xmm4, [rsp+0x40]
00007f0145bd0899  vmovaps xmm5, [rsp+0x50]
00007f0145bd089f  vmovaps xmm6, [rsp+0x60]
00007f0145bd08a5  vmovaps xmm7, [rsp+0x70]
00007f0145bd08ab  vmovaps xmm8, [rsp+0x80]
00007f0145bd08b4  vmovaps xmm9, [rsp+0x90]
00007f0145bd08bd  vmovaps xmm10, [rsp+0xA0]
00007f0145bd08c6  vmovaps xmm11, [rsp+0xB0]
00007f0145bd08cf  vmovaps xmm12, [rsp+0xC0]
00007f0145bd08d8  vmovaps xmm14, [rsp+0xD0]
00007f0145bd08e1  vmovaps xmm15, [rsp+0xE0]
00007f0145bd08ea  add rsp, 0xF0
00007f0145bd08f1  pop r11
00007f0145bd08f3  pop r10
00007f0145bd08f5  pop r9
00007f0145bd08f7  pop r8
00007f0145bd08f9  pop rsi
00007f0145bd08fa  pop rdi
00007f0145bd08fb  pop rdx
00007f0145bd08fc  pop rcx
00007f0145bd08fd  pop rax
00007f0145bd08fe  add rsp, 0x08
00007f0145bd0902  jmp 0x00007F0145BCF5CF
00007f0145bd0907  sub rsp, 0x08
00007f0145bd090b  push rax
00007f0145bd090c  push rcx
00007f0145bd090d  push rdx
00007f0145bd090e  push rdi
00007f0145bd090f  push rsi
00007f0145bd0910  push r8
00007f0145bd0912  push r9
00007f0145bd0914  push r10
00007f0145bd0916  push r11
00007f0145bd0918  sub rsp, 0xF0
00007f0145bd091f  vmovaps [rsp], xmm0
00007f0145bd0924  vmovaps [rsp+0x10], xmm1
00007f0145bd092a  vmovaps [rsp+0x20], xmm2
00007f0145bd0930  vmovaps [rsp+0x30], xmm3
00007f0145bd0936  vmovaps [rsp+0x40], xmm4
00007f0145bd093c  vmovaps [rsp+0x50], xmm5
00007f0145bd0942  vmovaps [rsp+0x60], xmm6
00007f0145bd0948  vmovaps [rsp+0x70], xmm7
00007f0145bd094e  vmovaps [rsp+0x80], xmm8
00007f0145bd0957  vmovaps [rsp+0x90], xmm9
00007f0145bd0960  vmovaps [rsp+0xA0], xmm10
00007f0145bd0969  vmovaps [rsp+0xB0], xmm11
00007f0145bd0972  vmovaps [rsp+0xC0], xmm12
00007f0145bd097b  vmovaps [rsp+0xD0], xmm13
00007f0145bd0984  vmovaps [rsp+0xE0], xmm14
00007f0145bd098d  sub rsp, 0x30
00007f0145bd0991  movaps [rsp], xmm15
00007f0145bd0996  movaps [rsp+0x10], xmm14
00007f0145bd099c  movaps [rsp+0x20], xmm1
00007f0145bd09a1  lea rdi, [rsp]
00007f0145bd09a5  mov esi, 0x00
00007f0145bd09aa  mov rax, 0x636570E98530
00007f0145bd09b4  call rax
00007f0145bd09b6  movaps xmm15, [rsp]
00007f0145bd09bb  add rsp, 0x30
00007f0145bd09bf  vmovaps xmm0, [rsp]
00007f0145bd09c4  vmovaps xmm1, [rsp+0x10]
00007f0145bd09ca  vmovaps xmm2, [rsp+0x20]
00007f0145bd09d0  vmovaps xmm3, [rsp+0x30]
00007f0145bd09d6  vmovaps xmm4, [rsp+0x40]
00007f0145bd09dc  vmovaps xmm5, [rsp+0x50]
00007f0145bd09e2  vmovaps xmm6, [rsp+0x60]
00007f0145bd09e8  vmovaps xmm7, [rsp+0x70]
00007f0145bd09ee  vmovaps xmm8, [rsp+0x80]
00007f0145bd09f7  vmovaps xmm9, [rsp+0x90]
00007f0145bd0a00  vmovaps xmm10, [rsp+0xA0]
00007f0145bd0a09  vmovaps xmm11, [rsp+0xB0]
00007f0145bd0a12  vmovaps xmm12, [rsp+0xC0]
00007f0145bd0a1b  vmovaps xmm13, [rsp+0xD0]
00007f0145bd0a24  vmovaps xmm14, [rsp+0xE0]
00007f0145bd0a2d  add rsp, 0xF0
00007f0145bd0a34  pop r11
00007f0145bd0a36  pop r10
00007f0145bd0a38  pop r9
00007f0145bd0a3a  pop r8
00007f0145bd0a3c  pop rsi
00007f0145bd0a3d  pop rdi
00007f0145bd0a3e  pop rdx
00007f0145bd0a3f  pop rcx
00007f0145bd0a40  pop rax
00007f0145bd0a41  add rsp, 0x08
00007f0145bd0a45  jmp 0x00007F0145BCF617
00007f0145bd0a4a  sub rsp, 0x08
00007f0145bd0a4e  push rax
00007f0145bd0a4f  push rcx
00007f0145bd0a50  push rdx
00007f0145bd0a51  push rdi
00007f0145bd0a52  push rsi
00007f0145bd0a53  push r8
00007f0145bd0a55  push r9
00007f0145bd0a57  push r10
00007f0145bd0a59  push r11
00007f0145bd0a5b  sub rsp, 0xF0
00007f0145bd0a62  vmovaps [rsp], xmm0
00007f0145bd0a67  vmovaps [rsp+0x10], xmm2
00007f0145bd0a6d  vmovaps [rsp+0x20], xmm3
00007f0145bd0a73  vmovaps [rsp+0x30], xmm4
00007f0145bd0a79  vmovaps [rsp+0x40], xmm5
00007f0145bd0a7f  vmovaps [rsp+0x50], xmm6
00007f0145bd0a85  vmovaps [rsp+0x60], xmm7
00007f0145bd0a8b  vmovaps [rsp+0x70], xmm8
00007f0145bd0a91  vmovaps [rsp+0x80], xmm9
00007f0145bd0a9a  vmovaps [rsp+0x90], xmm10
00007f0145bd0aa3  vmovaps [rsp+0xA0], xmm11
00007f0145bd0aac  vmovaps [rsp+0xB0], xmm12
00007f0145bd0ab5  vmovaps [rsp+0xC0], xmm13
00007f0145bd0abe  vmovaps [rsp+0xD0], xmm14
00007f0145bd0ac7  vmovaps [rsp+0xE0], xmm15
00007f0145bd0ad0  sub rsp, 0x30
00007f0145bd0ad4  movaps [rsp], xmm1
00007f0145bd0ad8  movaps [rsp+0x10], xmm14
00007f0145bd0ade  movaps [rsp+0x20], xmm10
00007f0145bd0ae4  lea rdi, [rsp]
00007f0145bd0ae8  mov esi, 0x00
00007f0145bd0aed  mov rax, 0x636570E98530
00007f0145bd0af7  call rax
00007f0145bd0af9  movaps xmm1, [rsp]
00007f0145bd0afd  add rsp, 0x30
00007f0145bd0b01  vmovaps xmm0, [rsp]
00007f0145bd0b06  vmovaps xmm2, [rsp+0x10]
00007f0145bd0b0c  vmovaps xmm3, [rsp+0x20]
00007f0145bd0b12  vmovaps xmm4, [rsp+0x30]
00007f0145bd0b18  vmovaps xmm5, [rsp+0x40]
00007f0145bd0b1e  vmovaps xmm6, [rsp+0x50]
00007f0145bd0b24  vmovaps xmm7, [rsp+0x60]
00007f0145bd0b2a  vmovaps xmm8, [rsp+0x70]
00007f0145bd0b30  vmovaps xmm9, [rsp+0x80]
00007f0145bd0b39  vmovaps xmm10, [rsp+0x90]
00007f0145bd0b42  vmovaps xmm11, [rsp+0xA0]
00007f0145bd0b4b  vmovaps xmm12, [rsp+0xB0]
00007f0145bd0b54  vmovaps xmm13, [rsp+0xC0]
00007f0145bd0b5d  vmovaps xmm14, [rsp+0xD0]
00007f0145bd0b66  vmovaps xmm15, [rsp+0xE0]
00007f0145bd0b6f  add rsp, 0xF0
00007f0145bd0b76  pop r11
00007f0145bd0b78  pop r10
00007f0145bd0b7a  pop r9
00007f0145bd0b7c  pop r8
00007f0145bd0b7e  pop rsi
00007f0145bd0b7f  pop rdi
00007f0145bd0b80  pop rdx
00007f0145bd0b81  pop rcx
00007f0145bd0b82  pop rax
00007f0145bd0b83  add rsp, 0x08
00007f0145bd0b87  jmp 0x00007F0145BCF631
00007f0145bd0b8c  sub rsp, 0x08
00007f0145bd0b90  push rax
00007f0145bd0b91  push rcx
00007f0145bd0b92  push rdx
00007f0145bd0b93  push rdi
00007f0145bd0b94  push rsi
00007f0145bd0b95  push r8
00007f0145bd0b97  push r9
00007f0145bd0b99  push r10
00007f0145bd0b9b  push r11
00007f0145bd0b9d  sub rsp, 0xF0
00007f0145bd0ba4  vmovaps [rsp], xmm0
00007f0145bd0ba9  vmovaps [rsp+0x10], xmm1
00007f0145bd0baf  vmovaps [rsp+0x20], xmm2
00007f0145bd0bb5  vmovaps [rsp+0x30], xmm3
00007f0145bd0bbb  vmovaps [rsp+0x40], xmm4
00007f0145bd0bc1  vmovaps [rsp+0x50], xmm5
00007f0145bd0bc7  vmovaps [rsp+0x60], xmm6
00007f0145bd0bcd  vmovaps [rsp+0x70], xmm7
00007f0145bd0bd3  vmovaps [rsp+0x80], xmm8
00007f0145bd0bdc  vmovaps [rsp+0x90], xmm9
00007f0145bd0be5  vmovaps [rsp+0xA0], xmm10
00007f0145bd0bee  vmovaps [rsp+0xB0], xmm11
00007f0145bd0bf7  vmovaps [rsp+0xC0], xmm12
00007f0145bd0c00  vmovaps [rsp+0xD0], xmm14
00007f0145bd0c09  vmovaps [rsp+0xE0], xmm15
00007f0145bd0c12  sub rsp, 0x30
00007f0145bd0c16  movaps [rsp], xmm13
00007f0145bd0c1b  movaps [rsp+0x10], xmm14
00007f0145bd0c21  movaps [rsp+0x20], xmm2
00007f0145bd0c26  lea rdi, [rsp]
00007f0145bd0c2a  mov esi, 0x00
00007f0145bd0c2f  mov rax, 0x636570E98530
00007f0145bd0c39  call rax
00007f0145bd0c3b  movaps xmm13, [rsp]
00007f0145bd0c40  add rsp, 0x30
00007f0145bd0c44  vmovaps xmm0, [rsp]
00007f0145bd0c49  vmovaps xmm1, [rsp+0x10]
00007f0145bd0c4f  vmovaps xmm2, [rsp+0x20]
00007f0145bd0c55  vmovaps xmm3, [rsp+0x30]
00007f0145bd0c5b  vmovaps xmm4, [rsp+0x40]
00007f0145bd0c61  vmovaps xmm5, [rsp+0x50]
00007f0145bd0c67  vmovaps xmm6, [rsp+0x60]
00007f0145bd0c6d  vmovaps xmm7, [rsp+0x70]
00007f0145bd0c73  vmovaps xmm8, [rsp+0x80]
00007f0145bd0c7c  vmovaps xmm9, [rsp+0x90]
00007f0145bd0c85  vmovaps xmm10, [rsp+0xA0]
00007f0145bd0c8e  vmovaps xmm11, [rsp+0xB0]
00007f0145bd0c97  vmovaps xmm12, [rsp+0xC0]
00007f0145bd0ca0  vmovaps xmm14, [rsp+0xD0]
00007f0145bd0ca9  vmovaps xmm15, [rsp+0xE0]
00007f0145bd0cb2  add rsp, 0xF0
00007f0145bd0cb9  pop r11
00007f0145bd0cbb  pop r10
00007f0145bd0cbd  pop r9
00007f0145bd0cbf  pop r8
00007f0145bd0cc1  pop rsi
00007f0145bd0cc2  pop rdi
00007f0145bd0cc3  pop rdx
00007f0145bd0cc4  pop rcx
00007f0145bd0cc5  pop rax
00007f0145bd0cc6  add rsp, 0x08
00007f0145bd0cca  jmp 0x00007F0145BCF64C
00007f0145bd0ccf  sub rsp, 0x08
00007f0145bd0cd3  push rax
00007f0145bd0cd4  push rcx
00007f0145bd0cd5  push rdx
00007f0145bd0cd6  push rdi
00007f0145bd0cd7  push rsi
00007f0145bd0cd8  push r8
00007f0145bd0cda  push r9
00007f0145bd0cdc  push r10
00007f0145bd0cde  push r11
00007f0145bd0ce0  sub rsp, 0xF0
00007f0145bd0ce7  vmovaps [rsp], xmm0
00007f0145bd0cec  vmovaps [rsp+0x10], xmm2
00007f0145bd0cf2  vmovaps [rsp+0x20], xmm3
00007f0145bd0cf8  vmovaps [rsp+0x30], xmm4
00007f0145bd0cfe  vmovaps [rsp+0x40], xmm5
00007f0145bd0d04  vmovaps [rsp+0x50], xmm6
00007f0145bd0d0a  vmovaps [rsp+0x60], xmm7
00007f0145bd0d10  vmovaps [rsp+0x70], xmm8
00007f0145bd0d16  vmovaps [rsp+0x80], xmm9
00007f0145bd0d1f  vmovaps [rsp+0x90], xmm10
00007f0145bd0d28  vmovaps [rsp+0xA0], xmm11
00007f0145bd0d31  vmovaps [rsp+0xB0], xmm12
00007f0145bd0d3a  vmovaps [rsp+0xC0], xmm13
00007f0145bd0d43  vmovaps [rsp+0xD0], xmm14
00007f0145bd0d4c  vmovaps [rsp+0xE0], xmm15
00007f0145bd0d55  sub rsp, 0x30
00007f0145bd0d59  movaps [rsp], xmm1
00007f0145bd0d5d  movaps [rsp+0x10], xmm10
00007f0145bd0d63  movaps [rsp+0x20], xmm2
00007f0145bd0d68  lea rdi, [rsp]
00007f0145bd0d6c  mov esi, 0x00
00007f0145bd0d71  mov rax, 0x636570E98530
00007f0145bd0d7b  call rax
00007f0145bd0d7d  movaps xmm1, [rsp]
00007f0145bd0d81  add rsp, 0x30
00007f0145bd0d85  vmovaps xmm0, [rsp]
00007f0145bd0d8a  vmovaps xmm2, [rsp+0x10]
00007f0145bd0d90  vmovaps xmm3, [rsp+0x20]
00007f0145bd0d96  vmovaps xmm4, [rsp+0x30]
00007f0145bd0d9c  vmovaps xmm5, [rsp+0x40]
00007f0145bd0da2  vmovaps xmm6, [rsp+0x50]
00007f0145bd0da8  vmovaps xmm7, [rsp+0x60]
00007f0145bd0dae  vmovaps xmm8, [rsp+0x70]
00007f0145bd0db4  vmovaps xmm9, [rsp+0x80]
00007f0145bd0dbd  vmovaps xmm10, [rsp+0x90]
00007f0145bd0dc6  vmovaps xmm11, [rsp+0xA0]
00007f0145bd0dcf  vmovaps xmm12, [rsp+0xB0]
00007f0145bd0dd8  vmovaps xmm13, [rsp+0xC0]
00007f0145bd0de1  vmovaps xmm14, [rsp+0xD0]
00007f0145bd0dea  vmovaps xmm15, [rsp+0xE0]
00007f0145bd0df3  add rsp, 0xF0
00007f0145bd0dfa  pop r11
00007f0145bd0dfc  pop r10
00007f0145bd0dfe  pop r9
00007f0145bd0e00  pop r8
00007f0145bd0e02  pop rsi
00007f0145bd0e03  pop rdi
00007f0145bd0e04  pop rdx
00007f0145bd0e05  pop rcx
00007f0145bd0e06  pop rax
00007f0145bd0e07  add rsp, 0x08
00007f0145bd0e0b  jmp 0x00007F0145BCF6B4
00007f0145bd0e10  sub rsp, 0x08
00007f0145bd0e14  push rax
00007f0145bd0e15  push rcx
00007f0145bd0e16  push rdx
00007f0145bd0e17  push rdi
00007f0145bd0e18  push rsi
00007f0145bd0e19  push r8
00007f0145bd0e1b  push r9
00007f0145bd0e1d  push r10
00007f0145bd0e1f  push r11
00007f0145bd0e21  sub rsp, 0xF0
00007f0145bd0e28  vmovaps [rsp], xmm0
00007f0145bd0e2d  vmovaps [rsp+0x10], xmm1
00007f0145bd0e33  vmovaps [rsp+0x20], xmm2
00007f0145bd0e39  vmovaps [rsp+0x30], xmm3
00007f0145bd0e3f  vmovaps [rsp+0x40], xmm4
00007f0145bd0e45  vmovaps [rsp+0x50], xmm5
00007f0145bd0e4b  vmovaps [rsp+0x60], xmm6
00007f0145bd0e51  vmovaps [rsp+0x70], xmm7
00007f0145bd0e57  vmovaps [rsp+0x80], xmm8
00007f0145bd0e60  vmovaps [rsp+0x90], xmm9
00007f0145bd0e69  vmovaps [rsp+0xA0], xmm10
00007f0145bd0e72  vmovaps [rsp+0xB0], xmm11
00007f0145bd0e7b  vmovaps [rsp+0xC0], xmm12
00007f0145bd0e84  vmovaps [rsp+0xD0], xmm13
00007f0145bd0e8d  vmovaps [rsp+0xE0], xmm14
00007f0145bd0e96  sub rsp, 0x30
00007f0145bd0e9a  movaps [rsp], xmm15
00007f0145bd0e9f  movaps [rsp+0x10], xmm10
00007f0145bd0ea5  movaps [rsp+0x20], xmm2
00007f0145bd0eaa  lea rdi, [rsp]
00007f0145bd0eae  mov esi, 0x00
00007f0145bd0eb3  mov rax, 0x636570E98530
00007f0145bd0ebd  call rax
00007f0145bd0ebf  movaps xmm15, [rsp]
00007f0145bd0ec4  add rsp, 0x30
00007f0145bd0ec8  vmovaps xmm0, [rsp]
00007f0145bd0ecd  vmovaps xmm1, [rsp+0x10]
00007f0145bd0ed3  vmovaps xmm2, [rsp+0x20]
00007f0145bd0ed9  vmovaps xmm3, [rsp+0x30]
00007f0145bd0edf  vmovaps xmm4, [rsp+0x40]
00007f0145bd0ee5  vmovaps xmm5, [rsp+0x50]
00007f0145bd0eeb  vmovaps xmm6, [rsp+0x60]
00007f0145bd0ef1  vmovaps xmm7, [rsp+0x70]
00007f0145bd0ef7  vmovaps xmm8, [rsp+0x80]
00007f0145bd0f00  vmovaps xmm9, [rsp+0x90]
00007f0145bd0f09  vmovaps xmm10, [rsp+0xA0]
00007f0145bd0f12  vmovaps xmm11, [rsp+0xB0]
00007f0145bd0f1b  vmovaps xmm12, [rsp+0xC0]
00007f0145bd0f24  vmovaps xmm13, [rsp+0xD0]
00007f0145bd0f2d  vmovaps xmm14, [rsp+0xE0]
00007f0145bd0f36  add rsp, 0xF0
00007f0145bd0f3d  pop r11
00007f0145bd0f3f  pop r10
00007f0145bd0f41  pop r9
00007f0145bd0f43  pop r8
00007f0145bd0f45  pop rsi
00007f0145bd0f46  pop rdi
00007f0145bd0f47  pop rdx
00007f0145bd0f48  pop rcx
00007f0145bd0f49  pop rax
00007f0145bd0f4a  add rsp, 0x08
00007f0145bd0f4e  jmp 0x00007F0145BCF706
00007f0145bd0f53  sub rsp, 0x08
00007f0145bd0f57  push rax
00007f0145bd0f58  push rcx
00007f0145bd0f59  push rdx
00007f0145bd0f5a  push rdi
00007f0145bd0f5b  push rsi
00007f0145bd0f5c  push r8
00007f0145bd0f5e  push r9
00007f0145bd0f60  push r10
00007f0145bd0f62  push r11
00007f0145bd0f64  sub rsp, 0xF0
00007f0145bd0f6b  vmovaps [rsp], xmm0
00007f0145bd0f70  vmovaps [rsp+0x10], xmm2
00007f0145bd0f76  vmovaps [rsp+0x20], xmm3
00007f0145bd0f7c  vmovaps [rsp+0x30], xmm4
00007f0145bd0f82  vmovaps [rsp+0x40], xmm5
00007f0145bd0f88  vmovaps [rsp+0x50], xmm6
00007f0145bd0f8e  vmovaps [rsp+0x60], xmm7
00007f0145bd0f94  vmovaps [rsp+0x70], xmm8
00007f0145bd0f9a  vmovaps [rsp+0x80], xmm9
00007f0145bd0fa3  vmovaps [rsp+0x90], xmm10
00007f0145bd0fac  vmovaps [rsp+0xA0], xmm11
00007f0145bd0fb5  vmovaps [rsp+0xB0], xmm12
00007f0145bd0fbe  vmovaps [rsp+0xC0], xmm13
00007f0145bd0fc7  vmovaps [rsp+0xD0], xmm14
00007f0145bd0fd0  vmovaps [rsp+0xE0], xmm15
00007f0145bd0fd9  sub rsp, 0x30
00007f0145bd0fdd  movaps [rsp], xmm1
00007f0145bd0fe1  movaps [rsp+0x10], xmm10
00007f0145bd0fe7  movaps [rsp+0x20], xmm12
00007f0145bd0fed  lea rdi, [rsp]
00007f0145bd0ff1  mov esi, 0x00
00007f0145bd0ff6  mov rax, 0x636570E98530
00007f0145bd1000  call rax
00007f0145bd1002  movaps xmm1, [rsp]
00007f0145bd1006  add rsp, 0x30
00007f0145bd100a  vmovaps xmm0, [rsp]
00007f0145bd100f  vmovaps xmm2, [rsp+0x10]
00007f0145bd1015  vmovaps xmm3, [rsp+0x20]
00007f0145bd101b  vmovaps xmm4, [rsp+0x30]
00007f0145bd1021  vmovaps xmm5, [rsp+0x40]
00007f0145bd1027  vmovaps xmm6, [rsp+0x50]
00007f0145bd102d  vmovaps xmm7, [rsp+0x60]
00007f0145bd1033  vmovaps xmm8, [rsp+0x70]
00007f0145bd1039  vmovaps xmm9, [rsp+0x80]
00007f0145bd1042  vmovaps xmm10, [rsp+0x90]
00007f0145bd104b  vmovaps xmm11, [rsp+0xA0]
00007f0145bd1054  vmovaps xmm12, [rsp+0xB0]
00007f0145bd105d  vmovaps xmm13, [rsp+0xC0]
00007f0145bd1066  vmovaps xmm14, [rsp+0xD0]
00007f0145bd106f  vmovaps xmm15, [rsp+0xE0]
00007f0145bd1078  add rsp, 0xF0
00007f0145bd107f  pop r11
00007f0145bd1081  pop r10
00007f0145bd1083  pop r9
00007f0145bd1085  pop r8
00007f0145bd1087  pop rsi
00007f0145bd1088  pop rdi
00007f0145bd1089  pop rdx
00007f0145bd108a  pop rcx
00007f0145bd108b  pop rax
00007f0145bd108c  add rsp, 0x08
00007f0145bd1090  jmp 0x00007F0145BCF732
00007f0145bd1095  sub rsp, 0x08
00007f0145bd1099  push rax
00007f0145bd109a  push rcx
00007f0145bd109b  push rdx
00007f0145bd109c  push rdi
00007f0145bd109d  push rsi
00007f0145bd109e  push r8
00007f0145bd10a0  push r9
00007f0145bd10a2  push r10
00007f0145bd10a4  push r11
00007f0145bd10a6  sub rsp, 0xF0
00007f0145bd10ad  vmovaps [rsp], xmm0
00007f0145bd10b2  vmovaps [rsp+0x10], xmm1
00007f0145bd10b8  vmovaps [rsp+0x20], xmm2
00007f0145bd10be  vmovaps [rsp+0x30], xmm3
00007f0145bd10c4  vmovaps [rsp+0x40], xmm4
00007f0145bd10ca  vmovaps [rsp+0x50], xmm5
00007f0145bd10d0  vmovaps [rsp+0x60], xmm6
00007f0145bd10d6  vmovaps [rsp+0x70], xmm7
00007f0145bd10dc  vmovaps [rsp+0x80], xmm8
00007f0145bd10e5  vmovaps [rsp+0x90], xmm9
00007f0145bd10ee  vmovaps [rsp+0xA0], xmm10
00007f0145bd10f7  vmovaps [rsp+0xB0], xmm11
00007f0145bd1100  vmovaps [rsp+0xC0], xmm12
00007f0145bd1109  vmovaps [rsp+0xD0], xmm13
00007f0145bd1112  vmovaps [rsp+0xE0], xmm14
00007f0145bd111b  sub rsp, 0x30
00007f0145bd111f  movaps [rsp], xmm15
00007f0145bd1124  movaps [rsp+0x10], xmm10
00007f0145bd112a  movaps [rsp+0x20], xmm12
00007f0145bd1130  lea rdi, [rsp]
00007f0145bd1134  mov esi, 0x00
00007f0145bd1139  mov rax, 0x636570E98530
00007f0145bd1143  call rax
00007f0145bd1145  movaps xmm15, [rsp]
00007f0145bd114a  add rsp, 0x30
00007f0145bd114e  vmovaps xmm0, [rsp]
00007f0145bd1153  vmovaps xmm1, [rsp+0x10]
00007f0145bd1159  vmovaps xmm2, [rsp+0x20]
00007f0145bd115f  vmovaps xmm3, [rsp+0x30]
00007f0145bd1165  vmovaps xmm4, [rsp+0x40]
00007f0145bd116b  vmovaps xmm5, [rsp+0x50]
00007f0145bd1171  vmovaps xmm6, [rsp+0x60]
00007f0145bd1177  vmovaps xmm7, [rsp+0x70]
00007f0145bd117d  vmovaps xmm8, [rsp+0x80]
00007f0145bd1186  vmovaps xmm9, [rsp+0x90]
00007f0145bd118f  vmovaps xmm10, [rsp+0xA0]
00007f0145bd1198  vmovaps xmm11, [rsp+0xB0]
00007f0145bd11a1  vmovaps xmm12, [rsp+0xC0]
00007f0145bd11aa  vmovaps xmm13, [rsp+0xD0]
00007f0145bd11b3  vmovaps xmm14, [rsp+0xE0]
00007f0145bd11bc  add rsp, 0xF0
00007f0145bd11c3  pop r11
00007f0145bd11c5  pop r10
00007f0145bd11c7  pop r9
00007f0145bd11c9  pop r8
00007f0145bd11cb  pop rsi
00007f0145bd11cc  pop rdi
00007f0145bd11cd  pop rdx
00007f0145bd11ce  pop rcx
00007f0145bd11cf  pop rax
00007f0145bd11d0  add rsp, 0x08
00007f0145bd11d4  jmp 0x00007F0145BCF75E
00007f0145bd11d9  call 0x00007F01459FF430
00007f0145bd11de  jmp 0x00007F0145BCF7EE
00007f0145bd11e3  call 0x00007F01459FF430
00007f0145bd11e8  jmp 0x00007F0145BCF801
00007f0145bd11ed  sub rsp, 0x08
00007f0145bd11f1  push rax
00007f0145bd11f2  push rcx
00007f0145bd11f3  push rdx
00007f0145bd11f4  push rdi
00007f0145bd11f5  push rsi
00007f0145bd11f6  push r8
00007f0145bd11f8  push r9
00007f0145bd11fa  push r10
00007f0145bd11fc  push r11
00007f0145bd11fe  sub rsp, 0xF0
00007f0145bd1205  vmovaps [rsp], xmm0
00007f0145bd120a  vmovaps [rsp+0x10], xmm2
00007f0145bd1210  vmovaps [rsp+0x20], xmm3
00007f0145bd1216  vmovaps [rsp+0x30], xmm4
00007f0145bd121c  vmovaps [rsp+0x40], xmm5
00007f0145bd1222  vmovaps [rsp+0x50], xmm6
00007f0145bd1228  vmovaps [rsp+0x60], xmm7
00007f0145bd122e  vmovaps [rsp+0x70], xmm8
00007f0145bd1234  vmovaps [rsp+0x80], xmm9
00007f0145bd123d  vmovaps [rsp+0x90], xmm10
00007f0145bd1246  vmovaps [rsp+0xA0], xmm11
00007f0145bd124f  vmovaps [rsp+0xB0], xmm12
00007f0145bd1258  vmovaps [rsp+0xC0], xmm13
00007f0145bd1261  vmovaps [rsp+0xD0], xmm14
00007f0145bd126a  vmovaps [rsp+0xE0], xmm15
00007f0145bd1273  sub rsp, 0x30
00007f0145bd1277  movaps [rsp], xmm1
00007f0145bd127b  movaps [rsp+0x10], xmm13
00007f0145bd1281  movaps [rsp+0x20], xmm2
00007f0145bd1286  lea rdi, [rsp]
00007f0145bd128a  mov esi, 0x00
00007f0145bd128f  mov rax, 0x636570E98530
00007f0145bd1299  call rax
00007f0145bd129b  movaps xmm1, [rsp]
00007f0145bd129f  add rsp, 0x30
00007f0145bd12a3  vmovaps xmm0, [rsp]
00007f0145bd12a8  vmovaps xmm2, [rsp+0x10]
00007f0145bd12ae  vmovaps xmm3, [rsp+0x20]
00007f0145bd12b4  vmovaps xmm4, [rsp+0x30]
00007f0145bd12ba  vmovaps xmm5, [rsp+0x40]
00007f0145bd12c0  vmovaps xmm6, [rsp+0x50]
00007f0145bd12c6  vmovaps xmm7, [rsp+0x60]
00007f0145bd12cc  vmovaps xmm8, [rsp+0x70]
00007f0145bd12d2  vmovaps xmm9, [rsp+0x80]
00007f0145bd12db  vmovaps xmm10, [rsp+0x90]
00007f0145bd12e4  vmovaps xmm11, [rsp+0xA0]
00007f0145bd12ed  vmovaps xmm12, [rsp+0xB0]
00007f0145bd12f6  vmovaps xmm13, [rsp+0xC0]
00007f0145bd12ff  vmovaps xmm14, [rsp+0xD0]
00007f0145bd1308  vmovaps xmm15, [rsp+0xE0]
00007f0145bd1311  add rsp, 0xF0
00007f0145bd1318  pop r11
00007f0145bd131a  pop r10
00007f0145bd131c  pop r9
00007f0145bd131e  pop r8
00007f0145bd1320  pop rsi
00007f0145bd1321  pop rdi
00007f0145bd1322  pop rdx
00007f0145bd1323  pop rcx
00007f0145bd1324  pop rax
00007f0145bd1325  add rsp, 0x08
00007f0145bd1329  jmp 0x00007F0145BCF82C
00007f0145bd132e  call 0x00007F0145A0E760
00007f0145bd1333  jmp 0x00007F0145BCF839
00007f0145bd1338  sub rsp, 0x08
00007f0145bd133c  push rax
00007f0145bd133d  push rcx
00007f0145bd133e  push rdx
00007f0145bd133f  push rdi
00007f0145bd1340  push rsi
00007f0145bd1341  push r8
00007f0145bd1343  push r9
00007f0145bd1345  push r10
00007f0145bd1347  push r11
00007f0145bd1349  sub rsp, 0xF0
00007f0145bd1350  vmovaps [rsp], xmm0
00007f0145bd1355  vmovaps [rsp+0x10], xmm1
00007f0145bd135b  vmovaps [rsp+0x20], xmm2
00007f0145bd1361  vmovaps [rsp+0x30], xmm3
00007f0145bd1367  vmovaps [rsp+0x40], xmm4
00007f0145bd136d  vmovaps [rsp+0x50], xmm5
00007f0145bd1373  vmovaps [rsp+0x60], xmm6
00007f0145bd1379  vmovaps [rsp+0x70], xmm7
00007f0145bd137f  vmovaps [rsp+0x80], xmm8
00007f0145bd1388  vmovaps [rsp+0x90], xmm9
00007f0145bd1391  vmovaps [rsp+0xA0], xmm10
00007f0145bd139a  vmovaps [rsp+0xB0], xmm11
00007f0145bd13a3  vmovaps [rsp+0xC0], xmm12
00007f0145bd13ac  vmovaps [rsp+0xD0], xmm14
00007f0145bd13b5  vmovaps [rsp+0xE0], xmm15
00007f0145bd13be  sub rsp, 0x30
00007f0145bd13c2  movaps [rsp], xmm13
00007f0145bd13c7  movaps [rsp+0x10], xmm2
00007f0145bd13cc  movaps [rsp+0x20], xmm1
00007f0145bd13d1  lea rdi, [rsp]
00007f0145bd13d5  mov esi, 0x00
00007f0145bd13da  mov rax, 0x636570E98530
00007f0145bd13e4  call rax
00007f0145bd13e6  movaps xmm13, [rsp]
00007f0145bd13eb  add rsp, 0x30
00007f0145bd13ef  vmovaps xmm0, [rsp]
00007f0145bd13f4  vmovaps xmm1, [rsp+0x10]
00007f0145bd13fa  vmovaps xmm2, [rsp+0x20]
00007f0145bd1400  vmovaps xmm3, [rsp+0x30]
00007f0145bd1406  vmovaps xmm4, [rsp+0x40]
00007f0145bd140c  vmovaps xmm5, [rsp+0x50]
00007f0145bd1412  vmovaps xmm6, [rsp+0x60]
00007f0145bd1418  vmovaps xmm7, [rsp+0x70]
00007f0145bd141e  vmovaps xmm8, [rsp+0x80]
00007f0145bd1427  vmovaps xmm9, [rsp+0x90]
00007f0145bd1430  vmovaps xmm10, [rsp+0xA0]
00007f0145bd1439  vmovaps xmm11, [rsp+0xB0]
00007f0145bd1442  vmovaps xmm12, [rsp+0xC0]
00007f0145bd144b  vmovaps xmm14, [rsp+0xD0]
00007f0145bd1454  vmovaps xmm15, [rsp+0xE0]
00007f0145bd145d  add rsp, 0xF0
00007f0145bd1464  pop r11
00007f0145bd1466  pop r10
00007f0145bd1468  pop r9
00007f0145bd146a  pop r8
00007f0145bd146c  pop rsi
00007f0145bd146d  pop rdi
00007f0145bd146e  pop rdx
00007f0145bd146f  pop rcx
00007f0145bd1470  pop rax
00007f0145bd1471  add rsp, 0x08
00007f0145bd1475  jmp 0x00007F0145BCF878
00007f0145bd147a  sub rsp, 0x08
00007f0145bd147e  push rax
00007f0145bd147f  push rcx
00007f0145bd1480  push rdx
00007f0145bd1481  push rdi
00007f0145bd1482  push rsi
00007f0145bd1483  push r8
00007f0145bd1485  push r9
00007f0145bd1487  push r10
00007f0145bd1489  push r11
00007f0145bd148b  sub rsp, 0xF0
00007f0145bd1492  vmovaps [rsp], xmm0
00007f0145bd1497  vmovaps [rsp+0x10], xmm2
00007f0145bd149d  vmovaps [rsp+0x20], xmm3
00007f0145bd14a3  vmovaps [rsp+0x30], xmm4
00007f0145bd14a9  vmovaps [rsp+0x40], xmm5
00007f0145bd14af  vmovaps [rsp+0x50], xmm6
00007f0145bd14b5  vmovaps [rsp+0x60], xmm7
00007f0145bd14bb  vmovaps [rsp+0x70], xmm8
00007f0145bd14c1  vmovaps [rsp+0x80], xmm9
00007f0145bd14ca  vmovaps [rsp+0x90], xmm10
00007f0145bd14d3  vmovaps [rsp+0xA0], xmm11
00007f0145bd14dc  vmovaps [rsp+0xB0], xmm12
00007f0145bd14e5  vmovaps [rsp+0xC0], xmm13
00007f0145bd14ee  vmovaps [rsp+0xD0], xmm14
00007f0145bd14f7  vmovaps [rsp+0xE0], xmm15
00007f0145bd1500  sub rsp, 0x30
00007f0145bd1504  movaps [rsp], xmm1
00007f0145bd1508  movaps [rsp+0x10], xmm15
00007f0145bd150e  movaps [rsp+0x20], xmm2
00007f0145bd1513  lea rdi, [rsp]
00007f0145bd1517  mov esi, 0x00
00007f0145bd151c  mov rax, 0x636570E98530
00007f0145bd1526  call rax
00007f0145bd1528  movaps xmm1, [rsp]
00007f0145bd152c  add rsp, 0x30
00007f0145bd1530  vmovaps xmm0, [rsp]
00007f0145bd1535  vmovaps xmm2, [rsp+0x10]
00007f0145bd153b  vmovaps xmm3, [rsp+0x20]
00007f0145bd1541  vmovaps xmm4, [rsp+0x30]
00007f0145bd1547  vmovaps xmm5, [rsp+0x40]
00007f0145bd154d  vmovaps xmm6, [rsp+0x50]
00007f0145bd1553  vmovaps xmm7, [rsp+0x60]
00007f0145bd1559  vmovaps xmm8, [rsp+0x70]
00007f0145bd155f  vmovaps xmm9, [rsp+0x80]
00007f0145bd1568  vmovaps xmm10, [rsp+0x90]
00007f0145bd1571  vmovaps xmm11, [rsp+0xA0]
00007f0145bd157a  vmovaps xmm12, [rsp+0xB0]
00007f0145bd1583  vmovaps xmm13, [rsp+0xC0]
00007f0145bd158c  vmovaps xmm14, [rsp+0xD0]
00007f0145bd1595  vmovaps xmm15, [rsp+0xE0]
00007f0145bd159e  add rsp, 0xF0
00007f0145bd15a5  pop r11
00007f0145bd15a7  pop r10
00007f0145bd15a9  pop r9
00007f0145bd15ab  pop r8
00007f0145bd15ad  pop rsi
00007f0145bd15ae  pop rdi
00007f0145bd15af  pop rdx
00007f0145bd15b0  pop rcx
00007f0145bd15b1  pop rax
00007f0145bd15b2  add rsp, 0x08
00007f0145bd15b6  jmp 0x00007F0145BCF8AC
00007f0145bd15bb  sub rsp, 0x08
00007f0145bd15bf  push rax
00007f0145bd15c0  push rcx
00007f0145bd15c1  push rdx
00007f0145bd15c2  push rdi
00007f0145bd15c3  push rsi
00007f0145bd15c4  push r8
00007f0145bd15c6  push r9
00007f0145bd15c8  push r10
00007f0145bd15ca  push r11
00007f0145bd15cc  sub rsp, 0xF0
00007f0145bd15d3  vmovaps [rsp], xmm0
00007f0145bd15d8  vmovaps [rsp+0x10], xmm1
00007f0145bd15de  vmovaps [rsp+0x20], xmm2
00007f0145bd15e4  vmovaps [rsp+0x30], xmm3
00007f0145bd15ea  vmovaps [rsp+0x40], xmm4
00007f0145bd15f0  vmovaps [rsp+0x50], xmm5
00007f0145bd15f6  vmovaps [rsp+0x60], xmm6
00007f0145bd15fc  vmovaps [rsp+0x70], xmm7
00007f0145bd1602  vmovaps [rsp+0x80], xmm8
00007f0145bd160b  vmovaps [rsp+0x90], xmm9
00007f0145bd1614  vmovaps [rsp+0xA0], xmm10
00007f0145bd161d  vmovaps [rsp+0xB0], xmm11
00007f0145bd1626  vmovaps [rsp+0xC0], xmm12
00007f0145bd162f  vmovaps [rsp+0xD0], xmm13
00007f0145bd1638  vmovaps [rsp+0xE0], xmm15
00007f0145bd1641  sub rsp, 0x30
00007f0145bd1645  movaps [rsp], xmm14
00007f0145bd164a  movaps [rsp+0x10], xmm2
00007f0145bd164f  movaps [rsp+0x20], xmm15
00007f0145bd1655  lea rdi, [rsp]
00007f0145bd1659  mov esi, 0x00
00007f0145bd165e  mov rax, 0x636570E98530
00007f0145bd1668  call rax
00007f0145bd166a  movaps xmm14, [rsp]
00007f0145bd166f  add rsp, 0x30
00007f0145bd1673  vmovaps xmm0, [rsp]
00007f0145bd1678  vmovaps xmm1, [rsp+0x10]
00007f0145bd167e  vmovaps xmm2, [rsp+0x20]
00007f0145bd1684  vmovaps xmm3, [rsp+0x30]
00007f0145bd168a  vmovaps xmm4, [rsp+0x40]
00007f0145bd1690  vmovaps xmm5, [rsp+0x50]
00007f0145bd1696  vmovaps xmm6, [rsp+0x60]
00007f0145bd169c  vmovaps xmm7, [rsp+0x70]
00007f0145bd16a2  vmovaps xmm8, [rsp+0x80]
00007f0145bd16ab  vmovaps xmm9, [rsp+0x90]
00007f0145bd16b4  vmovaps xmm10, [rsp+0xA0]
00007f0145bd16bd  vmovaps xmm11, [rsp+0xB0]
00007f0145bd16c6  vmovaps xmm12, [rsp+0xC0]
00007f0145bd16cf  vmovaps xmm13, [rsp+0xD0]
00007f0145bd16d8  vmovaps xmm15, [rsp+0xE0]
00007f0145bd16e1  add rsp, 0xF0
00007f0145bd16e8  pop r11
00007f0145bd16ea  pop r10
00007f0145bd16ec  pop r9
00007f0145bd16ee  pop r8
00007f0145bd16f0  pop rsi
00007f0145bd16f1  pop rdi
00007f0145bd16f2  pop rdx
00007f0145bd16f3  pop rcx
00007f0145bd16f4  pop rax
00007f0145bd16f5  add rsp, 0x08
00007f0145bd16f9  jmp 0x00007F0145BCF8E7
00007f0145bd16fe  sub rsp, 0x08
00007f0145bd1702  push rax
00007f0145bd1703  push rcx
00007f0145bd1704  push rdx
00007f0145bd1705  push rdi
00007f0145bd1706  push rsi
00007f0145bd1707  push r8
00007f0145bd1709  push r9
00007f0145bd170b  push r10
00007f0145bd170d  push r11
00007f0145bd170f  sub rsp, 0xF0
00007f0145bd1716  vmovaps [rsp], xmm0
00007f0145bd171b  vmovaps [rsp+0x10], xmm1
00007f0145bd1721  vmovaps [rsp+0x20], xmm2
00007f0145bd1727  vmovaps [rsp+0x30], xmm3
00007f0145bd172d  vmovaps [rsp+0x40], xmm4
00007f0145bd1733  vmovaps [rsp+0x50], xmm5
00007f0145bd1739  vmovaps [rsp+0x60], xmm6
00007f0145bd173f  vmovaps [rsp+0x70], xmm7
00007f0145bd1745  vmovaps [rsp+0x80], xmm8
00007f0145bd174e  vmovaps [rsp+0x90], xmm9
00007f0145bd1757  vmovaps [rsp+0xA0], xmm10
00007f0145bd1760  vmovaps [rsp+0xB0], xmm11
00007f0145bd1769  vmovaps [rsp+0xC0], xmm12
00007f0145bd1772  vmovaps [rsp+0xD0], xmm13
00007f0145bd177b  vmovaps [rsp+0xE0], xmm14
00007f0145bd1784  sub rsp, 0x30
00007f0145bd1788  movaps [rsp], xmm15
00007f0145bd178d  movaps [rsp+0x10], xmm2
00007f0145bd1792  movaps [rsp+0x20], xmm1
00007f0145bd1797  lea rdi, [rsp]
00007f0145bd179b  mov esi, 0x00
00007f0145bd17a0  mov rax, 0x636570E98530
00007f0145bd17aa  call rax
00007f0145bd17ac  movaps xmm15, [rsp]
00007f0145bd17b1  add rsp, 0x30
00007f0145bd17b5  vmovaps xmm0, [rsp]
00007f0145bd17ba  vmovaps xmm1, [rsp+0x10]
00007f0145bd17c0  vmovaps xmm2, [rsp+0x20]
00007f0145bd17c6  vmovaps xmm3, [rsp+0x30]
00007f0145bd17cc  vmovaps xmm4, [rsp+0x40]
00007f0145bd17d2  vmovaps xmm5, [rsp+0x50]
00007f0145bd17d8  vmovaps xmm6, [rsp+0x60]
00007f0145bd17de  vmovaps xmm7, [rsp+0x70]
00007f0145bd17e4  vmovaps xmm8, [rsp+0x80]
00007f0145bd17ed  vmovaps xmm9, [rsp+0x90]
00007f0145bd17f6  vmovaps xmm10, [rsp+0xA0]
00007f0145bd17ff  vmovaps xmm11, [rsp+0xB0]
00007f0145bd1808  vmovaps xmm12, [rsp+0xC0]
00007f0145bd1811  vmovaps xmm13, [rsp+0xD0]
00007f0145bd181a  vmovaps xmm14, [rsp+0xE0]
00007f0145bd1823  add rsp, 0xF0
00007f0145bd182a  pop r11
00007f0145bd182c  pop r10
00007f0145bd182e  pop r9
00007f0145bd1830  pop r8
00007f0145bd1832  pop rsi
00007f0145bd1833  pop rdi
00007f0145bd1834  pop rdx
00007f0145bd1835  pop rcx
00007f0145bd1836  pop rax
00007f0145bd1837  add rsp, 0x08
00007f0145bd183b  jmp 0x00007F0145BCF923
00007f0145bd1840  call 0x00007F01459FF430
00007f0145bd1845  jmp 0x00007F0145BCF930
00007f0145bd184a  sub rsp, 0x08
00007f0145bd184e  push rax
00007f0145bd184f  push rcx
00007f0145bd1850  push rdx
00007f0145bd1851  push rdi
00007f0145bd1852  push rsi
00007f0145bd1853  push r8
00007f0145bd1855  push r9
00007f0145bd1857  push r10
00007f0145bd1859  push r11
00007f0145bd185b  sub rsp, 0xF0
00007f0145bd1862  vmovaps [rsp], xmm0
00007f0145bd1867  vmovaps [rsp+0x10], xmm1
00007f0145bd186d  vmovaps [rsp+0x20], xmm3
00007f0145bd1873  vmovaps [rsp+0x30], xmm4
00007f0145bd1879  vmovaps [rsp+0x40], xmm5
00007f0145bd187f  vmovaps [rsp+0x50], xmm6
00007f0145bd1885  vmovaps [rsp+0x60], xmm7
00007f0145bd188b  vmovaps [rsp+0x70], xmm8
00007f0145bd1891  vmovaps [rsp+0x80], xmm9
00007f0145bd189a  vmovaps [rsp+0x90], xmm10
00007f0145bd18a3  vmovaps [rsp+0xA0], xmm11
00007f0145bd18ac  vmovaps [rsp+0xB0], xmm12
00007f0145bd18b5  vmovaps [rsp+0xC0], xmm13
00007f0145bd18be  vmovaps [rsp+0xD0], xmm14
00007f0145bd18c7  vmovaps [rsp+0xE0], xmm15
00007f0145bd18d0  sub rsp, 0x30
00007f0145bd18d4  movaps [rsp], xmm2
00007f0145bd18d8  movaps [rsp+0x10], xmm1
00007f0145bd18dd  movaps [rsp+0x20], xmm14
00007f0145bd18e3  lea rdi, [rsp]
00007f0145bd18e7  mov esi, 0x00
00007f0145bd18ec  mov rax, 0x636570E98530
00007f0145bd18f6  call rax
00007f0145bd18f8  movaps xmm2, [rsp]
00007f0145bd18fc  add rsp, 0x30
00007f0145bd1900  vmovaps xmm0, [rsp]
00007f0145bd1905  vmovaps xmm1, [rsp+0x10]
00007f0145bd190b  vmovaps xmm3, [rsp+0x20]
00007f0145bd1911  vmovaps xmm4, [rsp+0x30]
00007f0145bd1917  vmovaps xmm5, [rsp+0x40]
00007f0145bd191d  vmovaps xmm6, [rsp+0x50]
00007f0145bd1923  vmovaps xmm7, [rsp+0x60]
00007f0145bd1929  vmovaps xmm8, [rsp+0x70]
00007f0145bd192f  vmovaps xmm9, [rsp+0x80]
00007f0145bd1938  vmovaps xmm10, [rsp+0x90]
00007f0145bd1941  vmovaps xmm11, [rsp+0xA0]
00007f0145bd194a  vmovaps xmm12, [rsp+0xB0]
00007f0145bd1953  vmovaps xmm13, [rsp+0xC0]
00007f0145bd195c  vmovaps xmm14, [rsp+0xD0]
00007f0145bd1965  vmovaps xmm15, [rsp+0xE0]
00007f0145bd196e  add rsp, 0xF0
00007f0145bd1975  pop r11
00007f0145bd1977  pop r10
00007f0145bd1979  pop r9
00007f0145bd197b  pop r8
00007f0145bd197d  pop rsi
00007f0145bd197e  pop rdi
00007f0145bd197f  pop rdx
00007f0145bd1980  pop rcx
00007f0145bd1981  pop rax
00007f0145bd1982  add rsp, 0x08
00007f0145bd1986  jmp 0x00007F0145BCF96D
00007f0145bd198b  sub rsp, 0x08
00007f0145bd198f  push rax
00007f0145bd1990  push rcx
00007f0145bd1991  push rdx
00007f0145bd1992  push rdi
00007f0145bd1993  push rsi
00007f0145bd1994  push r8
00007f0145bd1996  push r9
00007f0145bd1998  push r10
00007f0145bd199a  push r11
00007f0145bd199c  sub rsp, 0xF0
00007f0145bd19a3  vmovaps [rsp], xmm0
00007f0145bd19a8  vmovaps [rsp+0x10], xmm1
00007f0145bd19ae  vmovaps [rsp+0x20], xmm2
00007f0145bd19b4  vmovaps [rsp+0x30], xmm3
00007f0145bd19ba  vmovaps [rsp+0x40], xmm4
00007f0145bd19c0  vmovaps [rsp+0x50], xmm5
00007f0145bd19c6  vmovaps [rsp+0x60], xmm6
00007f0145bd19cc  vmovaps [rsp+0x70], xmm7
00007f0145bd19d2  vmovaps [rsp+0x80], xmm8
00007f0145bd19db  vmovaps [rsp+0x90], xmm9
00007f0145bd19e4  vmovaps [rsp+0xA0], xmm10
00007f0145bd19ed  vmovaps [rsp+0xB0], xmm11
00007f0145bd19f6  vmovaps [rsp+0xC0], xmm12
00007f0145bd19ff  vmovaps [rsp+0xD0], xmm13
00007f0145bd1a08  vmovaps [rsp+0xE0], xmm14
00007f0145bd1a11  sub rsp, 0x30
00007f0145bd1a15  movaps [rsp], xmm15
00007f0145bd1a1a  movaps [rsp+0x10], xmm14
00007f0145bd1a20  movaps [rsp+0x20], xmm1
00007f0145bd1a25  lea rdi, [rsp]
00007f0145bd1a29  mov esi, 0x00
00007f0145bd1a2e  mov rax, 0x636570E98530
00007f0145bd1a38  call rax
00007f0145bd1a3a  movaps xmm15, [rsp]
00007f0145bd1a3f  add rsp, 0x30
00007f0145bd1a43  vmovaps xmm0, [rsp]
00007f0145bd1a48  vmovaps xmm1, [rsp+0x10]
00007f0145bd1a4e  vmovaps xmm2, [rsp+0x20]
00007f0145bd1a54  vmovaps xmm3, [rsp+0x30]
00007f0145bd1a5a  vmovaps xmm4, [rsp+0x40]
00007f0145bd1a60  vmovaps xmm5, [rsp+0x50]
00007f0145bd1a66  vmovaps xmm6, [rsp+0x60]
00007f0145bd1a6c  vmovaps xmm7, [rsp+0x70]
00007f0145bd1a72  vmovaps xmm8, [rsp+0x80]
00007f0145bd1a7b  vmovaps xmm9, [rsp+0x90]
00007f0145bd1a84  vmovaps xmm10, [rsp+0xA0]
00007f0145bd1a8d  vmovaps xmm11, [rsp+0xB0]
00007f0145bd1a96  vmovaps xmm12, [rsp+0xC0]
00007f0145bd1a9f  vmovaps xmm13, [rsp+0xD0]
00007f0145bd1aa8  vmovaps xmm14, [rsp+0xE0]
00007f0145bd1ab1  add rsp, 0xF0
00007f0145bd1ab8  pop r11
00007f0145bd1aba  pop r10
00007f0145bd1abc  pop r9
00007f0145bd1abe  pop r8
00007f0145bd1ac0  pop rsi
00007f0145bd1ac1  pop rdi
00007f0145bd1ac2  pop rdx
00007f0145bd1ac3  pop rcx
00007f0145bd1ac4  pop rax
00007f0145bd1ac5  add rsp, 0x08
00007f0145bd1ac9  jmp 0x00007F0145BCF9E7
00007f0145bd1ace  call 0x00007F01459FF430
00007f0145bd1ad3  jmp 0x00007F0145BCF9F4
00007f0145bd1ad8  sub rsp, 0x08
00007f0145bd1adc  push rax
00007f0145bd1add  push rcx
00007f0145bd1ade  push rdx
00007f0145bd1adf  push rdi
00007f0145bd1ae0  push rsi
00007f0145bd1ae1  push r8
00007f0145bd1ae3  push r9
00007f0145bd1ae5  push r10
00007f0145bd1ae7  push r11
00007f0145bd1ae9  sub rsp, 0xF0
00007f0145bd1af0  vmovaps [rsp], xmm0
00007f0145bd1af5  vmovaps [rsp+0x10], xmm1
00007f0145bd1afb  vmovaps [rsp+0x20], xmm2
00007f0145bd1b01  vmovaps [rsp+0x30], xmm3
00007f0145bd1b07  vmovaps [rsp+0x40], xmm4
00007f0145bd1b0d  vmovaps [rsp+0x50], xmm5
00007f0145bd1b13  vmovaps [rsp+0x60], xmm6
00007f0145bd1b19  vmovaps [rsp+0x70], xmm7
00007f0145bd1b1f  vmovaps [rsp+0x80], xmm8
00007f0145bd1b28  vmovaps [rsp+0x90], xmm9
00007f0145bd1b31  vmovaps [rsp+0xA0], xmm10
00007f0145bd1b3a  vmovaps [rsp+0xB0], xmm11
00007f0145bd1b43  vmovaps [rsp+0xC0], xmm12
00007f0145bd1b4c  vmovaps [rsp+0xD0], xmm13
00007f0145bd1b55  vmovaps [rsp+0xE0], xmm15
00007f0145bd1b5e  sub rsp, 0x30
00007f0145bd1b62  movaps [rsp], xmm14
00007f0145bd1b67  movaps [rsp+0x10], xmm13
00007f0145bd1b6d  movaps [rsp+0x20], xmm1
00007f0145bd1b72  lea rdi, [rsp]
00007f0145bd1b76  mov esi, 0x00
00007f0145bd1b7b  mov rax, 0x636570E98530
00007f0145bd1b85  call rax
00007f0145bd1b87  movaps xmm14, [rsp]
00007f0145bd1b8c  add rsp, 0x30
00007f0145bd1b90  vmovaps xmm0, [rsp]
00007f0145bd1b95  vmovaps xmm1, [rsp+0x10]
00007f0145bd1b9b  vmovaps xmm2, [rsp+0x20]
00007f0145bd1ba1  vmovaps xmm3, [rsp+0x30]
00007f0145bd1ba7  vmovaps xmm4, [rsp+0x40]
00007f0145bd1bad  vmovaps xmm5, [rsp+0x50]
00007f0145bd1bb3  vmovaps xmm6, [rsp+0x60]
00007f0145bd1bb9  vmovaps xmm7, [rsp+0x70]
00007f0145bd1bbf  vmovaps xmm8, [rsp+0x80]
00007f0145bd1bc8  vmovaps xmm9, [rsp+0x90]
00007f0145bd1bd1  vmovaps xmm10, [rsp+0xA0]
00007f0145bd1bda  vmovaps xmm11, [rsp+0xB0]
00007f0145bd1be3  vmovaps xmm12, [rsp+0xC0]
00007f0145bd1bec  vmovaps xmm13, [rsp+0xD0]
00007f0145bd1bf5  vmovaps xmm15, [rsp+0xE0]
00007f0145bd1bfe  add rsp, 0xF0
00007f0145bd1c05  pop r11
00007f0145bd1c07  pop r10
00007f0145bd1c09  pop r9
00007f0145bd1c0b  pop r8
00007f0145bd1c0d  pop rsi
00007f0145bd1c0e  pop rdi
00007f0145bd1c0f  pop rdx
00007f0145bd1c10  pop rcx
00007f0145bd1c11  pop rax
00007f0145bd1c12  add rsp, 0x08
00007f0145bd1c16  jmp 0x00007F0145BCFAAF
00007f0145bd1c1b  sub rsp, 0x08
00007f0145bd1c1f  push rax
00007f0145bd1c20  push rcx
00007f0145bd1c21  push rdx
00007f0145bd1c22  push rdi
00007f0145bd1c23  push rsi
00007f0145bd1c24  push r8
00007f0145bd1c26  push r9
00007f0145bd1c28  push r10
00007f0145bd1c2a  push r11
00007f0145bd1c2c  sub rsp, 0xF0
00007f0145bd1c33  vmovaps [rsp], xmm0
00007f0145bd1c38  vmovaps [rsp+0x10], xmm1
00007f0145bd1c3e  vmovaps [rsp+0x20], xmm2
00007f0145bd1c44  vmovaps [rsp+0x30], xmm3
00007f0145bd1c4a  vmovaps [rsp+0x40], xmm4
00007f0145bd1c50  vmovaps [rsp+0x50], xmm5
00007f0145bd1c56  vmovaps [rsp+0x60], xmm6
00007f0145bd1c5c  vmovaps [rsp+0x70], xmm7
00007f0145bd1c62  vmovaps [rsp+0x80], xmm8
00007f0145bd1c6b  vmovaps [rsp+0x90], xmm9
00007f0145bd1c74  vmovaps [rsp+0xA0], xmm10
00007f0145bd1c7d  vmovaps [rsp+0xB0], xmm11
00007f0145bd1c86  vmovaps [rsp+0xC0], xmm12
00007f0145bd1c8f  vmovaps [rsp+0xD0], xmm13
00007f0145bd1c98  vmovaps [rsp+0xE0], xmm14
00007f0145bd1ca1  sub rsp, 0x30
00007f0145bd1ca5  movaps [rsp], xmm15
00007f0145bd1caa  movaps [rsp+0x10], xmm13
00007f0145bd1cb0  movaps [rsp+0x20], xmm1
00007f0145bd1cb5  lea rdi, [rsp]
00007f0145bd1cb9  mov esi, 0x00
00007f0145bd1cbe  mov rax, 0x636570E98530
00007f0145bd1cc8  call rax
00007f0145bd1cca  movaps xmm15, [rsp]
00007f0145bd1ccf  add rsp, 0x30
00007f0145bd1cd3  vmovaps xmm0, [rsp]
00007f0145bd1cd8  vmovaps xmm1, [rsp+0x10]
00007f0145bd1cde  vmovaps xmm2, [rsp+0x20]
00007f0145bd1ce4  vmovaps xmm3, [rsp+0x30]
00007f0145bd1cea  vmovaps xmm4, [rsp+0x40]
00007f0145bd1cf0  vmovaps xmm5, [rsp+0x50]
00007f0145bd1cf6  vmovaps xmm6, [rsp+0x60]
00007f0145bd1cfc  vmovaps xmm7, [rsp+0x70]
00007f0145bd1d02  vmovaps xmm8, [rsp+0x80]
00007f0145bd1d0b  vmovaps xmm9, [rsp+0x90]
00007f0145bd1d14  vmovaps xmm10, [rsp+0xA0]
00007f0145bd1d1d  vmovaps xmm11, [rsp+0xB0]
00007f0145bd1d26  vmovaps xmm12, [rsp+0xC0]
00007f0145bd1d2f  vmovaps xmm13, [rsp+0xD0]
00007f0145bd1d38  vmovaps xmm14, [rsp+0xE0]
00007f0145bd1d41  add rsp, 0xF0
00007f0145bd1d48  pop r11
00007f0145bd1d4a  pop r10
00007f0145bd1d4c  pop r9
00007f0145bd1d4e  pop r8
00007f0145bd1d50  pop rsi
00007f0145bd1d51  pop rdi
00007f0145bd1d52  pop rdx
00007f0145bd1d53  pop rcx
00007f0145bd1d54  pop rax
00007f0145bd1d55  add rsp, 0x08
00007f0145bd1d59  jmp 0x00007F0145BCFAEB
00007f0145bd1d5e  call 0x00007F01459FF430
00007f0145bd1d63  jmp 0x00007F0145BCFAF8
00007f0145bd1d68  sub rsp, 0x08
00007f0145bd1d6c  push rax
00007f0145bd1d6d  push rcx
00007f0145bd1d6e  push rdx
00007f0145bd1d6f  push rdi
00007f0145bd1d70  push rsi
00007f0145bd1d71  push r8
00007f0145bd1d73  push r9
00007f0145bd1d75  push r10
00007f0145bd1d77  push r11
00007f0145bd1d79  sub rsp, 0xF0
00007f0145bd1d80  vmovaps [rsp], xmm0
00007f0145bd1d85  vmovaps [rsp+0x10], xmm1
00007f0145bd1d8b  vmovaps [rsp+0x20], xmm2
00007f0145bd1d91  vmovaps [rsp+0x30], xmm3
00007f0145bd1d97  vmovaps [rsp+0x40], xmm4
00007f0145bd1d9d  vmovaps [rsp+0x50], xmm5
00007f0145bd1da3  vmovaps [rsp+0x60], xmm6
00007f0145bd1da9  vmovaps [rsp+0x70], xmm7
00007f0145bd1daf  vmovaps [rsp+0x80], xmm8
00007f0145bd1db8  vmovaps [rsp+0x90], xmm9
00007f0145bd1dc1  vmovaps [rsp+0xA0], xmm10
00007f0145bd1dca  vmovaps [rsp+0xB0], xmm11
00007f0145bd1dd3  vmovaps [rsp+0xC0], xmm12
00007f0145bd1ddc  vmovaps [rsp+0xD0], xmm13
00007f0145bd1de5  vmovaps [rsp+0xE0], xmm15
00007f0145bd1dee  sub rsp, 0x30
00007f0145bd1df2  movaps [rsp], xmm14
00007f0145bd1df7  movaps [rsp+0x10], xmm13
00007f0145bd1dfd  movaps [rsp+0x20], xmm2
00007f0145bd1e02  lea rdi, [rsp]
00007f0145bd1e06  mov esi, 0x00
00007f0145bd1e0b  mov rax, 0x636570E98530
00007f0145bd1e15  call rax
00007f0145bd1e17  movaps xmm14, [rsp]
00007f0145bd1e1c  add rsp, 0x30
00007f0145bd1e20  vmovaps xmm0, [rsp]
00007f0145bd1e25  vmovaps xmm1, [rsp+0x10]
00007f0145bd1e2b  vmovaps xmm2, [rsp+0x20]
00007f0145bd1e31  vmovaps xmm3, [rsp+0x30]
00007f0145bd1e37  vmovaps xmm4, [rsp+0x40]
00007f0145bd1e3d  vmovaps xmm5, [rsp+0x50]
00007f0145bd1e43  vmovaps xmm6, [rsp+0x60]
00007f0145bd1e49  vmovaps xmm7, [rsp+0x70]
00007f0145bd1e4f  vmovaps xmm8, [rsp+0x80]
00007f0145bd1e58  vmovaps xmm9, [rsp+0x90]
00007f0145bd1e61  vmovaps xmm10, [rsp+0xA0]
00007f0145bd1e6a  vmovaps xmm11, [rsp+0xB0]
00007f0145bd1e73  vmovaps xmm12, [rsp+0xC0]
00007f0145bd1e7c  vmovaps xmm13, [rsp+0xD0]
00007f0145bd1e85  vmovaps xmm15, [rsp+0xE0]
00007f0145bd1e8e  add rsp, 0xF0
00007f0145bd1e95  pop r11
00007f0145bd1e97  pop r10
00007f0145bd1e99  pop r9
00007f0145bd1e9b  pop r8
00007f0145bd1e9d  pop rsi
00007f0145bd1e9e  pop rdi
00007f0145bd1e9f  pop rdx
00007f0145bd1ea0  pop rcx
00007f0145bd1ea1  pop rax
00007f0145bd1ea2  add rsp, 0x08
00007f0145bd1ea6  jmp 0x00007F0145BCFB24
00007f0145bd1eab  sub rsp, 0x08
00007f0145bd1eaf  push rax
00007f0145bd1eb0  push rcx
00007f0145bd1eb1  push rdx
00007f0145bd1eb2  push rdi
00007f0145bd1eb3  push rsi
00007f0145bd1eb4  push r8
00007f0145bd1eb6  push r9
00007f0145bd1eb8  push r10
00007f0145bd1eba  push r11
00007f0145bd1ebc  sub rsp, 0xF0
00007f0145bd1ec3  vmovaps [rsp], xmm0
00007f0145bd1ec8  vmovaps [rsp+0x10], xmm2
00007f0145bd1ece  vmovaps [rsp+0x20], xmm3
00007f0145bd1ed4  vmovaps [rsp+0x30], xmm4
00007f0145bd1eda  vmovaps [rsp+0x40], xmm5
00007f0145bd1ee0  vmovaps [rsp+0x50], xmm6
00007f0145bd1ee6  vmovaps [rsp+0x60], xmm7
00007f0145bd1eec  vmovaps [rsp+0x70], xmm8
00007f0145bd1ef2  vmovaps [rsp+0x80], xmm9
00007f0145bd1efb  vmovaps [rsp+0x90], xmm10
00007f0145bd1f04  vmovaps [rsp+0xA0], xmm11
00007f0145bd1f0d  vmovaps [rsp+0xB0], xmm12
00007f0145bd1f16  vmovaps [rsp+0xC0], xmm13
00007f0145bd1f1f  vmovaps [rsp+0xD0], xmm14
00007f0145bd1f28  vmovaps [rsp+0xE0], xmm15
00007f0145bd1f31  sub rsp, 0x30
00007f0145bd1f35  movaps [rsp], xmm1
00007f0145bd1f39  movaps [rsp+0x10], xmm13
00007f0145bd1f3f  movaps [rsp+0x20], xmm2
00007f0145bd1f44  lea rdi, [rsp]
00007f0145bd1f48  mov esi, 0x00
00007f0145bd1f4d  mov rax, 0x636570E98530
00007f0145bd1f57  call rax
00007f0145bd1f59  movaps xmm1, [rsp]
00007f0145bd1f5d  add rsp, 0x30
00007f0145bd1f61  vmovaps xmm0, [rsp]
00007f0145bd1f66  vmovaps xmm2, [rsp+0x10]
00007f0145bd1f6c  vmovaps xmm3, [rsp+0x20]
00007f0145bd1f72  vmovaps xmm4, [rsp+0x30]
00007f0145bd1f78  vmovaps xmm5, [rsp+0x40]
00007f0145bd1f7e  vmovaps xmm6, [rsp+0x50]
00007f0145bd1f84  vmovaps xmm7, [rsp+0x60]
00007f0145bd1f8a  vmovaps xmm8, [rsp+0x70]
00007f0145bd1f90  vmovaps xmm9, [rsp+0x80]
00007f0145bd1f99  vmovaps xmm10, [rsp+0x90]
00007f0145bd1fa2  vmovaps xmm11, [rsp+0xA0]
00007f0145bd1fab  vmovaps xmm12, [rsp+0xB0]
00007f0145bd1fb4  vmovaps xmm13, [rsp+0xC0]
00007f0145bd1fbd  vmovaps xmm14, [rsp+0xD0]
00007f0145bd1fc6  vmovaps xmm15, [rsp+0xE0]
00007f0145bd1fcf  add rsp, 0xF0
00007f0145bd1fd6  pop r11
00007f0145bd1fd8  pop r10
00007f0145bd1fda  pop r9
00007f0145bd1fdc  pop r8
00007f0145bd1fde  pop rsi
00007f0145bd1fdf  pop rdi
00007f0145bd1fe0  pop rdx
00007f0145bd1fe1  pop rcx
00007f0145bd1fe2  pop rax
00007f0145bd1fe3  add rsp, 0x08
00007f0145bd1fe7  jmp 0x00007F0145BCFB52
00007f0145bd1fec  sub rsp, 0x08
00007f0145bd1ff0  push rax
00007f0145bd1ff1  push rcx
00007f0145bd1ff2  push rdx
00007f0145bd1ff3  push rdi
00007f0145bd1ff4  push rsi
00007f0145bd1ff5  push r8
00007f0145bd1ff7  push r9
00007f0145bd1ff9  push r10
00007f0145bd1ffb  push r11
00007f0145bd1ffd  sub rsp, 0xF0
00007f0145bd2004  vmovaps [rsp], xmm0
00007f0145bd2009  vmovaps [rsp+0x10], xmm1
00007f0145bd200f  vmovaps [rsp+0x20], xmm3
00007f0145bd2015  vmovaps [rsp+0x30], xmm4
00007f0145bd201b  vmovaps [rsp+0x40], xmm5
00007f0145bd2021  vmovaps [rsp+0x50], xmm6
00007f0145bd2027  vmovaps [rsp+0x60], xmm7
00007f0145bd202d  vmovaps [rsp+0x70], xmm8
00007f0145bd2033  vmovaps [rsp+0x80], xmm9
00007f0145bd203c  vmovaps [rsp+0x90], xmm10
00007f0145bd2045  vmovaps [rsp+0xA0], xmm11
00007f0145bd204e  vmovaps [rsp+0xB0], xmm12
00007f0145bd2057  vmovaps [rsp+0xC0], xmm13
00007f0145bd2060  vmovaps [rsp+0xD0], xmm14
00007f0145bd2069  vmovaps [rsp+0xE0], xmm15
00007f0145bd2072  sub rsp, 0x30
00007f0145bd2076  movaps [rsp], xmm2
00007f0145bd207a  movaps [rsp+0x10], xmm1
00007f0145bd207f  movaps [rsp+0x20], xmm13
00007f0145bd2085  lea rdi, [rsp]
00007f0145bd2089  mov esi, 0x00
00007f0145bd208e  mov rax, 0x636570E98530
00007f0145bd2098  call rax
00007f0145bd209a  movaps xmm2, [rsp]
00007f0145bd209e  add rsp, 0x30
00007f0145bd20a2  vmovaps xmm0, [rsp]
00007f0145bd20a7  vmovaps xmm1, [rsp+0x10]
00007f0145bd20ad  vmovaps xmm3, [rsp+0x20]
00007f0145bd20b3  vmovaps xmm4, [rsp+0x30]
00007f0145bd20b9  vmovaps xmm5, [rsp+0x40]
00007f0145bd20bf  vmovaps xmm6, [rsp+0x50]
00007f0145bd20c5  vmovaps xmm7, [rsp+0x60]
00007f0145bd20cb  vmovaps xmm8, [rsp+0x70]
00007f0145bd20d1  vmovaps xmm9, [rsp+0x80]
00007f0145bd20da  vmovaps xmm10, [rsp+0x90]
00007f0145bd20e3  vmovaps xmm11, [rsp+0xA0]
00007f0145bd20ec  vmovaps xmm12, [rsp+0xB0]
00007f0145bd20f5  vmovaps xmm13, [rsp+0xC0]
00007f0145bd20fe  vmovaps xmm14, [rsp+0xD0]
00007f0145bd2107  vmovaps xmm15, [rsp+0xE0]
00007f0145bd2110  add rsp, 0xF0
00007f0145bd2117  pop r11
00007f0145bd2119  pop r10
00007f0145bd211b  pop r9
00007f0145bd211d  pop r8
00007f0145bd211f  pop rsi
00007f0145bd2120  pop rdi
00007f0145bd2121  pop rdx
00007f0145bd2122  pop rcx
00007f0145bd2123  pop rax
00007f0145bd2124  add rsp, 0x08
00007f0145bd2128  jmp 0x00007F0145BCFBAB
00007f0145bd212d  call 0x00007F01459FF430
00007f0145bd2132  jmp 0x00007F0145BCFBB8
00007f0145bd2137  sub rsp, 0x08
00007f0145bd213b  push rax
00007f0145bd213c  push rcx
00007f0145bd213d  push rdx
00007f0145bd213e  push rdi
00007f0145bd213f  push rsi
00007f0145bd2140  push r8
00007f0145bd2142  push r9
00007f0145bd2144  push r10
00007f0145bd2146  push r11
00007f0145bd2148  sub rsp, 0xF0
00007f0145bd214f  vmovaps [rsp], xmm0
00007f0145bd2154  vmovaps [rsp+0x10], xmm1
00007f0145bd215a  vmovaps [rsp+0x20], xmm2
00007f0145bd2160  vmovaps [rsp+0x30], xmm3
00007f0145bd2166  vmovaps [rsp+0x40], xmm4
00007f0145bd216c  vmovaps [rsp+0x50], xmm5
00007f0145bd2172  vmovaps [rsp+0x60], xmm6
00007f0145bd2178  vmovaps [rsp+0x70], xmm7
00007f0145bd217e  vmovaps [rsp+0x80], xmm8
00007f0145bd2187  vmovaps [rsp+0x90], xmm9
00007f0145bd2190  vmovaps [rsp+0xA0], xmm10
00007f0145bd2199  vmovaps [rsp+0xB0], xmm11
00007f0145bd21a2  vmovaps [rsp+0xC0], xmm12
00007f0145bd21ab  vmovaps [rsp+0xD0], xmm13
00007f0145bd21b4  vmovaps [rsp+0xE0], xmm14
00007f0145bd21bd  sub rsp, 0x30
00007f0145bd21c1  movaps [rsp], xmm15
00007f0145bd21c6  movaps [rsp+0x10], xmm13
00007f0145bd21cc  movaps [rsp+0x20], xmm1
00007f0145bd21d1  lea rdi, [rsp]
00007f0145bd21d5  mov esi, 0x00
00007f0145bd21da  mov rax, 0x636570E98530
00007f0145bd21e4  call rax
00007f0145bd21e6  movaps xmm15, [rsp]
00007f0145bd21eb  add rsp, 0x30
00007f0145bd21ef  vmovaps xmm0, [rsp]
00007f0145bd21f4  vmovaps xmm1, [rsp+0x10]
00007f0145bd21fa  vmovaps xmm2, [rsp+0x20]
00007f0145bd2200  vmovaps xmm3, [rsp+0x30]
00007f0145bd2206  vmovaps xmm4, [rsp+0x40]
00007f0145bd220c  vmovaps xmm5, [rsp+0x50]
00007f0145bd2212  vmovaps xmm6, [rsp+0x60]
00007f0145bd2218  vmovaps xmm7, [rsp+0x70]
00007f0145bd221e  vmovaps xmm8, [rsp+0x80]
00007f0145bd2227  vmovaps xmm9, [rsp+0x90]
00007f0145bd2230  vmovaps xmm10, [rsp+0xA0]
00007f0145bd2239  vmovaps xmm11, [rsp+0xB0]
00007f0145bd2242  vmovaps xmm12, [rsp+0xC0]
00007f0145bd224b  vmovaps xmm13, [rsp+0xD0]
00007f0145bd2254  vmovaps xmm14, [rsp+0xE0]
00007f0145bd225d  add rsp, 0xF0
00007f0145bd2264  pop r11
00007f0145bd2266  pop r10
00007f0145bd2268  pop r9
00007f0145bd226a  pop r8
00007f0145bd226c  pop rsi
00007f0145bd226d  pop rdi
00007f0145bd226e  pop rdx
00007f0145bd226f  pop rcx
00007f0145bd2270  pop rax
00007f0145bd2271  add rsp, 0x08
00007f0145bd2275  jmp 0x00007F0145BCFBF7
00007f0145bd227a  sub rsp, 0x08
00007f0145bd227e  push rax
00007f0145bd227f  push rcx
00007f0145bd2280  push rdx
00007f0145bd2281  push rdi
00007f0145bd2282  push rsi
00007f0145bd2283  push r8
00007f0145bd2285  push r9
00007f0145bd2287  push r10
00007f0145bd2289  push r11
00007f0145bd228b  sub rsp, 0xF0
00007f0145bd2292  vmovaps [rsp], xmm0
00007f0145bd2297  vmovaps [rsp+0x10], xmm1
00007f0145bd229d  vmovaps [rsp+0x20], xmm2
00007f0145bd22a3  vmovaps [rsp+0x30], xmm3
00007f0145bd22a9  vmovaps [rsp+0x40], xmm4
00007f0145bd22af  vmovaps [rsp+0x50], xmm5
00007f0145bd22b5  vmovaps [rsp+0x60], xmm6
00007f0145bd22bb  vmovaps [rsp+0x70], xmm7
00007f0145bd22c1  vmovaps [rsp+0x80], xmm8
00007f0145bd22ca  vmovaps [rsp+0x90], xmm9
00007f0145bd22d3  vmovaps [rsp+0xA0], xmm10
00007f0145bd22dc  vmovaps [rsp+0xB0], xmm11
00007f0145bd22e5  vmovaps [rsp+0xC0], xmm12
00007f0145bd22ee  vmovaps [rsp+0xD0], xmm13
00007f0145bd22f7  vmovaps [rsp+0xE0], xmm15
00007f0145bd2300  sub rsp, 0x30
00007f0145bd2304  movaps [rsp], xmm14
00007f0145bd2309  movaps [rsp+0x10], xmm11
00007f0145bd230f  movaps [rsp+0x20], xmm1
00007f0145bd2314  lea rdi, [rsp]
00007f0145bd2318  mov esi, 0x00
00007f0145bd231d  mov rax, 0x636570E98530
00007f0145bd2327  call rax
00007f0145bd2329  movaps xmm14, [rsp]
00007f0145bd232e  add rsp, 0x30
00007f0145bd2332  vmovaps xmm0, [rsp]
00007f0145bd2337  vmovaps xmm1, [rsp+0x10]
00007f0145bd233d  vmovaps xmm2, [rsp+0x20]
00007f0145bd2343  vmovaps xmm3, [rsp+0x30]
00007f0145bd2349  vmovaps xmm4, [rsp+0x40]
00007f0145bd234f  vmovaps xmm5, [rsp+0x50]
00007f0145bd2355  vmovaps xmm6, [rsp+0x60]
00007f0145bd235b  vmovaps xmm7, [rsp+0x70]
00007f0145bd2361  vmovaps xmm8, [rsp+0x80]
00007f0145bd236a  vmovaps xmm9, [rsp+0x90]
00007f0145bd2373  vmovaps xmm10, [rsp+0xA0]
00007f0145bd237c  vmovaps xmm11, [rsp+0xB0]
00007f0145bd2385  vmovaps xmm12, [rsp+0xC0]
00007f0145bd238e  vmovaps xmm13, [rsp+0xD0]
00007f0145bd2397  vmovaps xmm15, [rsp+0xE0]
00007f0145bd23a0  add rsp, 0xF0
00007f0145bd23a7  pop r11
00007f0145bd23a9  pop r10
00007f0145bd23ab  pop r9
00007f0145bd23ad  pop r8
00007f0145bd23af  pop rsi
00007f0145bd23b0  pop rdi
00007f0145bd23b1  pop rdx
00007f0145bd23b2  pop rcx
00007f0145bd23b3  pop rax
00007f0145bd23b4  add rsp, 0x08
00007f0145bd23b8  jmp 0x00007F0145BCFC21
00007f0145bd23bd  sub rsp, 0x08
00007f0145bd23c1  push rax
00007f0145bd23c2  push rcx
00007f0145bd23c3  push rdx
00007f0145bd23c4  push rdi
00007f0145bd23c5  push rsi
00007f0145bd23c6  push r8
00007f0145bd23c8  push r9
00007f0145bd23ca  push r10
00007f0145bd23cc  push r11
00007f0145bd23ce  sub rsp, 0xF0
00007f0145bd23d5  vmovaps [rsp], xmm0
00007f0145bd23da  vmovaps [rsp+0x10], xmm1
00007f0145bd23e0  vmovaps [rsp+0x20], xmm2
00007f0145bd23e6  vmovaps [rsp+0x30], xmm3
00007f0145bd23ec  vmovaps [rsp+0x40], xmm4
00007f0145bd23f2  vmovaps [rsp+0x50], xmm5
00007f0145bd23f8  vmovaps [rsp+0x60], xmm6
00007f0145bd23fe  vmovaps [rsp+0x70], xmm7
00007f0145bd2404  vmovaps [rsp+0x80], xmm8
00007f0145bd240d  vmovaps [rsp+0x90], xmm9
00007f0145bd2416  vmovaps [rsp+0xA0], xmm10
00007f0145bd241f  vmovaps [rsp+0xB0], xmm11
00007f0145bd2428  vmovaps [rsp+0xC0], xmm12
00007f0145bd2431  vmovaps [rsp+0xD0], xmm14
00007f0145bd243a  vmovaps [rsp+0xE0], xmm15
00007f0145bd2443  sub rsp, 0x30
00007f0145bd2447  movaps [rsp], xmm13
00007f0145bd244c  movaps [rsp+0x10], xmm11
00007f0145bd2452  movaps [rsp+0x20], xmm1
00007f0145bd2457  lea rdi, [rsp]
00007f0145bd245b  mov esi, 0x00
00007f0145bd2460  mov rax, 0x636570E98530
00007f0145bd246a  call rax
00007f0145bd246c  movaps xmm13, [rsp]
00007f0145bd2471  add rsp, 0x30
00007f0145bd2475  vmovaps xmm0, [rsp]
00007f0145bd247a  vmovaps xmm1, [rsp+0x10]
00007f0145bd2480  vmovaps xmm2, [rsp+0x20]
00007f0145bd2486  vmovaps xmm3, [rsp+0x30]
00007f0145bd248c  vmovaps xmm4, [rsp+0x40]
00007f0145bd2492  vmovaps xmm5, [rsp+0x50]
00007f0145bd2498  vmovaps xmm6, [rsp+0x60]
00007f0145bd249e  vmovaps xmm7, [rsp+0x70]
00007f0145bd24a4  vmovaps xmm8, [rsp+0x80]
00007f0145bd24ad  vmovaps xmm9, [rsp+0x90]
00007f0145bd24b6  vmovaps xmm10, [rsp+0xA0]
00007f0145bd24bf  vmovaps xmm11, [rsp+0xB0]
00007f0145bd24c8  vmovaps xmm12, [rsp+0xC0]
00007f0145bd24d1  vmovaps xmm14, [rsp+0xD0]
00007f0145bd24da  vmovaps xmm15, [rsp+0xE0]
00007f0145bd24e3  add rsp, 0xF0
00007f0145bd24ea  pop r11
00007f0145bd24ec  pop r10
00007f0145bd24ee  pop r9
00007f0145bd24f0  pop r8
00007f0145bd24f2  pop rsi
00007f0145bd24f3  pop rdi
00007f0145bd24f4  pop rdx
00007f0145bd24f5  pop rcx
00007f0145bd24f6  pop rax
00007f0145bd24f7  add rsp, 0x08
00007f0145bd24fb  jmp 0x00007F0145BCFC76
00007f0145bd2500  call 0x00007F01459FF430
00007f0145bd2505  jmp 0x00007F0145BCFC83
00007f0145bd250a  sub rsp, 0x08
00007f0145bd250e  push rax
00007f0145bd250f  push rcx
00007f0145bd2510  push rdx
00007f0145bd2511  push rdi
00007f0145bd2512  push rsi
00007f0145bd2513  push r8
00007f0145bd2515  push r9
00007f0145bd2517  push r10
00007f0145bd2519  push r11
00007f0145bd251b  sub rsp, 0xF0
00007f0145bd2522  vmovaps [rsp], xmm0
00007f0145bd2527  vmovaps [rsp+0x10], xmm1
00007f0145bd252d  vmovaps [rsp+0x20], xmm2
00007f0145bd2533  vmovaps [rsp+0x30], xmm3
00007f0145bd2539  vmovaps [rsp+0x40], xmm4
00007f0145bd253f  vmovaps [rsp+0x50], xmm5
00007f0145bd2545  vmovaps [rsp+0x60], xmm6
00007f0145bd254b  vmovaps [rsp+0x70], xmm7
00007f0145bd2551  vmovaps [rsp+0x80], xmm8
00007f0145bd255a  vmovaps [rsp+0x90], xmm9
00007f0145bd2563  vmovaps [rsp+0xA0], xmm10
00007f0145bd256c  vmovaps [rsp+0xB0], xmm11
00007f0145bd2575  vmovaps [rsp+0xC0], xmm12
00007f0145bd257e  vmovaps [rsp+0xD0], xmm13
00007f0145bd2587  vmovaps [rsp+0xE0], xmm14
00007f0145bd2590  sub rsp, 0x30
00007f0145bd2594  movaps [rsp], xmm15
00007f0145bd2599  movaps [rsp+0x10], xmm11
00007f0145bd259f  movaps [rsp+0x20], xmm1
00007f0145bd25a4  lea rdi, [rsp]
00007f0145bd25a8  mov esi, 0x00
00007f0145bd25ad  mov rax, 0x636570E98530
00007f0145bd25b7  call rax
00007f0145bd25b9  movaps xmm15, [rsp]
00007f0145bd25be  add rsp, 0x30
00007f0145bd25c2  vmovaps xmm0, [rsp]
00007f0145bd25c7  vmovaps xmm1, [rsp+0x10]
00007f0145bd25cd  vmovaps xmm2, [rsp+0x20]
00007f0145bd25d3  vmovaps xmm3, [rsp+0x30]
00007f0145bd25d9  vmovaps xmm4, [rsp+0x40]
00007f0145bd25df  vmovaps xmm5, [rsp+0x50]
00007f0145bd25e5  vmovaps xmm6, [rsp+0x60]
00007f0145bd25eb  vmovaps xmm7, [rsp+0x70]
00007f0145bd25f1  vmovaps xmm8, [rsp+0x80]
00007f0145bd25fa  vmovaps xmm9, [rsp+0x90]
00007f0145bd2603  vmovaps xmm10, [rsp+0xA0]
00007f0145bd260c  vmovaps xmm11, [rsp+0xB0]
00007f0145bd2615  vmovaps xmm12, [rsp+0xC0]
00007f0145bd261e  vmovaps xmm13, [rsp+0xD0]
00007f0145bd2627  vmovaps xmm14, [rsp+0xE0]
00007f0145bd2630  add rsp, 0xF0
00007f0145bd2637  pop r11
00007f0145bd2639  pop r10
00007f0145bd263b  pop r9
00007f0145bd263d  pop r8
00007f0145bd263f  pop rsi
00007f0145bd2640  pop rdi
00007f0145bd2641  pop rdx
00007f0145bd2642  pop rcx
00007f0145bd2643  pop rax
00007f0145bd2644  add rsp, 0x08
00007f0145bd2648  jmp 0x00007F0145BCFCBC
00007f0145bd264d  sub rsp, 0x08
00007f0145bd2651  push rax
00007f0145bd2652  push rcx
00007f0145bd2653  push rdx
00007f0145bd2654  push rdi
00007f0145bd2655  push rsi
00007f0145bd2656  push r8
00007f0145bd2658  push r9
00007f0145bd265a  push r10
00007f0145bd265c  push r11
00007f0145bd265e  sub rsp, 0xF0
00007f0145bd2665  vmovaps [rsp], xmm0
00007f0145bd266a  vmovaps [rsp+0x10], xmm1
00007f0145bd2670  vmovaps [rsp+0x20], xmm2
00007f0145bd2676  vmovaps [rsp+0x30], xmm3
00007f0145bd267c  vmovaps [rsp+0x40], xmm4
00007f0145bd2682  vmovaps [rsp+0x50], xmm5
00007f0145bd2688  vmovaps [rsp+0x60], xmm6
00007f0145bd268e  vmovaps [rsp+0x70], xmm7
00007f0145bd2694  vmovaps [rsp+0x80], xmm8
00007f0145bd269d  vmovaps [rsp+0x90], xmm9
00007f0145bd26a6  vmovaps [rsp+0xA0], xmm10
00007f0145bd26af  vmovaps [rsp+0xB0], xmm12
00007f0145bd26b8  vmovaps [rsp+0xC0], xmm13
00007f0145bd26c1  vmovaps [rsp+0xD0], xmm14
00007f0145bd26ca  vmovaps [rsp+0xE0], xmm15
00007f0145bd26d3  sub rsp, 0x30
00007f0145bd26d7  movaps [rsp], xmm11
00007f0145bd26dc  movaps [rsp+0x10], xmm6
00007f0145bd26e1  movaps [rsp+0x20], xmm14
00007f0145bd26e7  lea rdi, [rsp]
00007f0145bd26eb  mov esi, 0x00
00007f0145bd26f0  mov rax, 0x636570E98530
00007f0145bd26fa  call rax
00007f0145bd26fc  movaps xmm11, [rsp]
00007f0145bd2701  add rsp, 0x30
00007f0145bd2705  vmovaps xmm0, [rsp]
00007f0145bd270a  vmovaps xmm1, [rsp+0x10]
00007f0145bd2710  vmovaps xmm2, [rsp+0x20]
00007f0145bd2716  vmovaps xmm3, [rsp+0x30]
00007f0145bd271c  vmovaps xmm4, [rsp+0x40]
00007f0145bd2722  vmovaps xmm5, [rsp+0x50]
00007f0145bd2728  vmovaps xmm6, [rsp+0x60]
00007f0145bd272e  vmovaps xmm7, [rsp+0x70]
00007f0145bd2734  vmovaps xmm8, [rsp+0x80]
00007f0145bd273d  vmovaps xmm9, [rsp+0x90]
00007f0145bd2746  vmovaps xmm10, [rsp+0xA0]
00007f0145bd274f  vmovaps xmm12, [rsp+0xB0]
00007f0145bd2758  vmovaps xmm13, [rsp+0xC0]
00007f0145bd2761  vmovaps xmm14, [rsp+0xD0]
00007f0145bd276a  vmovaps xmm15, [rsp+0xE0]
00007f0145bd2773  add rsp, 0xF0
00007f0145bd277a  pop r11
00007f0145bd277c  pop r10
00007f0145bd277e  pop r9
00007f0145bd2780  pop r8
00007f0145bd2782  pop rsi
00007f0145bd2783  pop rdi
00007f0145bd2784  pop rdx
00007f0145bd2785  pop rcx
00007f0145bd2786  pop rax
00007f0145bd2787  add rsp, 0x08
00007f0145bd278b  jmp 0x00007F0145BCFD34
00007f0145bd2790  call 0x00007F01459FF430
00007f0145bd2795  jmp 0x00007F0145BCFD3E
00007f0145bd279a  sub rsp, 0x08
00007f0145bd279e  push rax
00007f0145bd279f  push rcx
00007f0145bd27a0  push rdx
00007f0145bd27a1  push rdi
00007f0145bd27a2  push rsi
00007f0145bd27a3  push r8
00007f0145bd27a5  push r9
00007f0145bd27a7  push r10
00007f0145bd27a9  push r11
00007f0145bd27ab  sub rsp, 0xF0
00007f0145bd27b2  vmovaps [rsp], xmm0
00007f0145bd27b7  vmovaps [rsp+0x10], xmm1
00007f0145bd27bd  vmovaps [rsp+0x20], xmm2
00007f0145bd27c3  vmovaps [rsp+0x30], xmm3
00007f0145bd27c9  vmovaps [rsp+0x40], xmm4
00007f0145bd27cf  vmovaps [rsp+0x50], xmm5
00007f0145bd27d5  vmovaps [rsp+0x60], xmm6
00007f0145bd27db  vmovaps [rsp+0x70], xmm7
00007f0145bd27e1  vmovaps [rsp+0x80], xmm8
00007f0145bd27ea  vmovaps [rsp+0x90], xmm9
00007f0145bd27f3  vmovaps [rsp+0xA0], xmm10
00007f0145bd27fc  vmovaps [rsp+0xB0], xmm11
00007f0145bd2805  vmovaps [rsp+0xC0], xmm12
00007f0145bd280e  vmovaps [rsp+0xD0], xmm13
00007f0145bd2817  vmovaps [rsp+0xE0], xmm15
00007f0145bd2820  sub rsp, 0x30
00007f0145bd2824  movaps [rsp], xmm14
00007f0145bd2829  movaps [rsp+0x10], xmm6
00007f0145bd282e  movaps [rsp+0x20], xmm2
00007f0145bd2833  lea rdi, [rsp]
00007f0145bd2837  mov esi, 0x00
00007f0145bd283c  mov rax, 0x636570E98530
00007f0145bd2846  call rax
00007f0145bd2848  movaps xmm14, [rsp]
00007f0145bd284d  add rsp, 0x30
00007f0145bd2851  vmovaps xmm0, [rsp]
00007f0145bd2856  vmovaps xmm1, [rsp+0x10]
00007f0145bd285c  vmovaps xmm2, [rsp+0x20]
00007f0145bd2862  vmovaps xmm3, [rsp+0x30]
00007f0145bd2868  vmovaps xmm4, [rsp+0x40]
00007f0145bd286e  vmovaps xmm5, [rsp+0x50]
00007f0145bd2874  vmovaps xmm6, [rsp+0x60]
00007f0145bd287a  vmovaps xmm7, [rsp+0x70]
00007f0145bd2880  vmovaps xmm8, [rsp+0x80]
00007f0145bd2889  vmovaps xmm9, [rsp+0x90]
00007f0145bd2892  vmovaps xmm10, [rsp+0xA0]
00007f0145bd289b  vmovaps xmm11, [rsp+0xB0]
00007f0145bd28a4  vmovaps xmm12, [rsp+0xC0]
00007f0145bd28ad  vmovaps xmm13, [rsp+0xD0]
00007f0145bd28b6  vmovaps xmm15, [rsp+0xE0]
00007f0145bd28bf  add rsp, 0xF0
00007f0145bd28c6  pop r11
00007f0145bd28c8  pop r10
00007f0145bd28ca  pop r9
00007f0145bd28cc  pop r8
00007f0145bd28ce  pop rsi
00007f0145bd28cf  pop rdi
00007f0145bd28d0  pop rdx
00007f0145bd28d1  pop rcx
00007f0145bd28d2  pop rax
00007f0145bd28d3  add rsp, 0x08
00007f0145bd28d7  jmp 0x00007F0145BCFD72
00007f0145bd28dc  sub rsp, 0x08
00007f0145bd28e0  push rax
00007f0145bd28e1  push rcx
00007f0145bd28e2  push rdx
00007f0145bd28e3  push rdi
00007f0145bd28e4  push rsi
00007f0145bd28e5  push r8
00007f0145bd28e7  push r9
00007f0145bd28e9  push r10
00007f0145bd28eb  push r11
00007f0145bd28ed  sub rsp, 0xF0
00007f0145bd28f4  vmovaps [rsp], xmm0
00007f0145bd28f9  vmovaps [rsp+0x10], xmm1
00007f0145bd28ff  vmovaps [rsp+0x20], xmm2
00007f0145bd2905  vmovaps [rsp+0x30], xmm3
00007f0145bd290b  vmovaps [rsp+0x40], xmm4
00007f0145bd2911  vmovaps [rsp+0x50], xmm5
00007f0145bd2917  vmovaps [rsp+0x60], xmm7
00007f0145bd291d  vmovaps [rsp+0x70], xmm8
00007f0145bd2923  vmovaps [rsp+0x80], xmm9
00007f0145bd292c  vmovaps [rsp+0x90], xmm10
00007f0145bd2935  vmovaps [rsp+0xA0], xmm11
00007f0145bd293e  vmovaps [rsp+0xB0], xmm12
00007f0145bd2947  vmovaps [rsp+0xC0], xmm13
00007f0145bd2950  vmovaps [rsp+0xD0], xmm14
00007f0145bd2959  vmovaps [rsp+0xE0], xmm15
00007f0145bd2962  sub rsp, 0x30
00007f0145bd2966  movaps [rsp], xmm6
00007f0145bd296a  movaps [rsp+0x10], xmm5
00007f0145bd296f  movaps [rsp+0x20], xmm1
00007f0145bd2974  lea rdi, [rsp]
00007f0145bd2978  mov esi, 0x00
00007f0145bd297d  mov rax, 0x636570E98530
00007f0145bd2987  call rax
00007f0145bd2989  movaps xmm6, [rsp]
00007f0145bd298d  add rsp, 0x30
00007f0145bd2991  vmovaps xmm0, [rsp]
00007f0145bd2996  vmovaps xmm1, [rsp+0x10]
00007f0145bd299c  vmovaps xmm2, [rsp+0x20]
00007f0145bd29a2  vmovaps xmm3, [rsp+0x30]
00007f0145bd29a8  vmovaps xmm4, [rsp+0x40]
00007f0145bd29ae  vmovaps xmm5, [rsp+0x50]
00007f0145bd29b4  vmovaps xmm7, [rsp+0x60]
00007f0145bd29ba  vmovaps xmm8, [rsp+0x70]
00007f0145bd29c0  vmovaps xmm9, [rsp+0x80]
00007f0145bd29c9  vmovaps xmm10, [rsp+0x90]
00007f0145bd29d2  vmovaps xmm11, [rsp+0xA0]
00007f0145bd29db  vmovaps xmm12, [rsp+0xB0]
00007f0145bd29e4  vmovaps xmm13, [rsp+0xC0]
00007f0145bd29ed  vmovaps xmm14, [rsp+0xD0]
00007f0145bd29f6  vmovaps xmm15, [rsp+0xE0]
00007f0145bd29ff  add rsp, 0xF0
00007f0145bd2a06  pop r11
00007f0145bd2a08  pop r10
00007f0145bd2a0a  pop r9
00007f0145bd2a0c  pop r8
00007f0145bd2a0e  pop rsi
00007f0145bd2a0f  pop rdi
00007f0145bd2a10  pop rdx
00007f0145bd2a11  pop rcx
00007f0145bd2a12  pop rax
00007f0145bd2a13  add rsp, 0x08
00007f0145bd2a17  jmp 0x00007F0145BCFD98
00007f0145bd2a1c  sub rsp, 0x08
00007f0145bd2a20  push rax
00007f0145bd2a21  push rcx
00007f0145bd2a22  push rdx
00007f0145bd2a23  push rdi
00007f0145bd2a24  push rsi
00007f0145bd2a25  push r8
00007f0145bd2a27  push r9
00007f0145bd2a29  push r10
00007f0145bd2a2b  push r11
00007f0145bd2a2d  sub rsp, 0xF0
00007f0145bd2a34  vmovaps [rsp], xmm0
00007f0145bd2a39  vmovaps [rsp+0x10], xmm2
00007f0145bd2a3f  vmovaps [rsp+0x20], xmm3
00007f0145bd2a45  vmovaps [rsp+0x30], xmm4
00007f0145bd2a4b  vmovaps [rsp+0x40], xmm5
00007f0145bd2a51  vmovaps [rsp+0x50], xmm6
00007f0145bd2a57  vmovaps [rsp+0x60], xmm7
00007f0145bd2a5d  vmovaps [rsp+0x70], xmm8
00007f0145bd2a63  vmovaps [rsp+0x80], xmm9
00007f0145bd2a6c  vmovaps [rsp+0x90], xmm10
00007f0145bd2a75  vmovaps [rsp+0xA0], xmm11
00007f0145bd2a7e  vmovaps [rsp+0xB0], xmm12
00007f0145bd2a87  vmovaps [rsp+0xC0], xmm13
00007f0145bd2a90  vmovaps [rsp+0xD0], xmm14
00007f0145bd2a99  vmovaps [rsp+0xE0], xmm15
00007f0145bd2aa2  sub rsp, 0x30
00007f0145bd2aa6  movaps [rsp], xmm1
00007f0145bd2aaa  movaps [rsp+0x10], xmm5
00007f0145bd2aaf  movaps [rsp+0x20], xmm13
00007f0145bd2ab5  lea rdi, [rsp]
00007f0145bd2ab9  mov esi, 0x00
00007f0145bd2abe  mov rax, 0x636570E98530
00007f0145bd2ac8  call rax
00007f0145bd2aca  movaps xmm1, [rsp]
00007f0145bd2ace  add rsp, 0x30
00007f0145bd2ad2  vmovaps xmm0, [rsp]
00007f0145bd2ad7  vmovaps xmm2, [rsp+0x10]
00007f0145bd2add  vmovaps xmm3, [rsp+0x20]
00007f0145bd2ae3  vmovaps xmm4, [rsp+0x30]
00007f0145bd2ae9  vmovaps xmm5, [rsp+0x40]
00007f0145bd2aef  vmovaps xmm6, [rsp+0x50]
00007f0145bd2af5  vmovaps xmm7, [rsp+0x60]
00007f0145bd2afb  vmovaps xmm8, [rsp+0x70]
00007f0145bd2b01  vmovaps xmm9, [rsp+0x80]
00007f0145bd2b0a  vmovaps xmm10, [rsp+0x90]
00007f0145bd2b13  vmovaps xmm11, [rsp+0xA0]
00007f0145bd2b1c  vmovaps xmm12, [rsp+0xB0]
00007f0145bd2b25  vmovaps xmm13, [rsp+0xC0]
00007f0145bd2b2e  vmovaps xmm14, [rsp+0xD0]
00007f0145bd2b37  vmovaps xmm15, [rsp+0xE0]
00007f0145bd2b40  add rsp, 0xF0
00007f0145bd2b47  pop r11
00007f0145bd2b49  pop r10
00007f0145bd2b4b  pop r9
00007f0145bd2b4d  pop r8
00007f0145bd2b4f  pop rsi
00007f0145bd2b50  pop rdi
00007f0145bd2b51  pop rdx
00007f0145bd2b52  pop rcx
00007f0145bd2b53  pop rax
00007f0145bd2b54  add rsp, 0x08
00007f0145bd2b58  jmp 0x00007F0145BCFDB6
00007f0145bd2b5d  sub rsp, 0x08
00007f0145bd2b61  push rax
00007f0145bd2b62  push rcx
00007f0145bd2b63  push rdx
00007f0145bd2b64  push rdi
00007f0145bd2b65  push rsi
00007f0145bd2b66  push r8
00007f0145bd2b68  push r9
00007f0145bd2b6a  push r10
00007f0145bd2b6c  push r11
00007f0145bd2b6e  sub rsp, 0xF0
00007f0145bd2b75  vmovaps [rsp], xmm0
00007f0145bd2b7a  vmovaps [rsp+0x10], xmm1
00007f0145bd2b80  vmovaps [rsp+0x20], xmm2
00007f0145bd2b86  vmovaps [rsp+0x30], xmm3
00007f0145bd2b8c  vmovaps [rsp+0x40], xmm4
00007f0145bd2b92  vmovaps [rsp+0x50], xmm6
00007f0145bd2b98  vmovaps [rsp+0x60], xmm7
00007f0145bd2b9e  vmovaps [rsp+0x70], xmm8
00007f0145bd2ba4  vmovaps [rsp+0x80], xmm9
00007f0145bd2bad  vmovaps [rsp+0x90], xmm10
00007f0145bd2bb6  vmovaps [rsp+0xA0], xmm11
00007f0145bd2bbf  vmovaps [rsp+0xB0], xmm12
00007f0145bd2bc8  vmovaps [rsp+0xC0], xmm13
00007f0145bd2bd1  vmovaps [rsp+0xD0], xmm14
00007f0145bd2bda  vmovaps [rsp+0xE0], xmm15
00007f0145bd2be3  sub rsp, 0x30
00007f0145bd2be7  movaps [rsp], xmm5
00007f0145bd2beb  movaps [rsp+0x10], xmm2
00007f0145bd2bf0  movaps [rsp+0x20], xmm13
00007f0145bd2bf6  lea rdi, [rsp]
00007f0145bd2bfa  mov esi, 0x00
00007f0145bd2bff  mov rax, 0x636570E98530
00007f0145bd2c09  call rax
00007f0145bd2c0b  movaps xmm5, [rsp]
00007f0145bd2c0f  add rsp, 0x30
00007f0145bd2c13  vmovaps xmm0, [rsp]
00007f0145bd2c18  vmovaps xmm1, [rsp+0x10]
00007f0145bd2c1e  vmovaps xmm2, [rsp+0x20]
00007f0145bd2c24  vmovaps xmm3, [rsp+0x30]
00007f0145bd2c2a  vmovaps xmm4, [rsp+0x40]
00007f0145bd2c30  vmovaps xmm6, [rsp+0x50]
00007f0145bd2c36  vmovaps xmm7, [rsp+0x60]
00007f0145bd2c3c  vmovaps xmm8, [rsp+0x70]
00007f0145bd2c42  vmovaps xmm9, [rsp+0x80]
00007f0145bd2c4b  vmovaps xmm10, [rsp+0x90]
00007f0145bd2c54  vmovaps xmm11, [rsp+0xA0]
00007f0145bd2c5d  vmovaps xmm12, [rsp+0xB0]
00007f0145bd2c66  vmovaps xmm13, [rsp+0xC0]
00007f0145bd2c6f  vmovaps xmm14, [rsp+0xD0]
00007f0145bd2c78  vmovaps xmm15, [rsp+0xE0]
00007f0145bd2c81  add rsp, 0xF0
00007f0145bd2c88  pop r11
00007f0145bd2c8a  pop r10
00007f0145bd2c8c  pop r9
00007f0145bd2c8e  pop r8
00007f0145bd2c90  pop rsi
00007f0145bd2c91  pop rdi
00007f0145bd2c92  pop rdx
00007f0145bd2c93  pop rcx
00007f0145bd2c94  pop rax
00007f0145bd2c95  add rsp, 0x08
00007f0145bd2c99  jmp 0x00007F0145BCFDEC
00007f0145bd2c9e  sub rsp, 0x08
00007f0145bd2ca2  push rax
00007f0145bd2ca3  push rcx
00007f0145bd2ca4  push rdx
00007f0145bd2ca5  push rdi
00007f0145bd2ca6  push rsi
00007f0145bd2ca7  push r8
00007f0145bd2ca9  push r9
00007f0145bd2cab  push r10
00007f0145bd2cad  push r11
00007f0145bd2caf  sub rsp, 0xF0
00007f0145bd2cb6  vmovaps [rsp], xmm0
00007f0145bd2cbb  vmovaps [rsp+0x10], xmm1
00007f0145bd2cc1  vmovaps [rsp+0x20], xmm2
00007f0145bd2cc7  vmovaps [rsp+0x30], xmm3
00007f0145bd2ccd  vmovaps [rsp+0x40], xmm4
00007f0145bd2cd3  vmovaps [rsp+0x50], xmm5
00007f0145bd2cd9  vmovaps [rsp+0x60], xmm6
00007f0145bd2cdf  vmovaps [rsp+0x70], xmm7
00007f0145bd2ce5  vmovaps [rsp+0x80], xmm8
00007f0145bd2cee  vmovaps [rsp+0x90], xmm9
00007f0145bd2cf7  vmovaps [rsp+0xA0], xmm10
00007f0145bd2d00  vmovaps [rsp+0xB0], xmm11
00007f0145bd2d09  vmovaps [rsp+0xC0], xmm12
00007f0145bd2d12  vmovaps [rsp+0xD0], xmm14
00007f0145bd2d1b  vmovaps [rsp+0xE0], xmm15
00007f0145bd2d24  sub rsp, 0x30
00007f0145bd2d28  movaps [rsp], xmm13
00007f0145bd2d2d  movaps [rsp+0x10], xmm10
00007f0145bd2d33  movaps [rsp+0x20], xmm1
00007f0145bd2d38  lea rdi, [rsp]
00007f0145bd2d3c  mov esi, 0x00
00007f0145bd2d41  mov rax, 0x636570E98530
00007f0145bd2d4b  call rax
00007f0145bd2d4d  movaps xmm13, [rsp]
00007f0145bd2d52  add rsp, 0x30
00007f0145bd2d56  vmovaps xmm0, [rsp]
00007f0145bd2d5b  vmovaps xmm1, [rsp+0x10]
00007f0145bd2d61  vmovaps xmm2, [rsp+0x20]
00007f0145bd2d67  vmovaps xmm3, [rsp+0x30]
00007f0145bd2d6d  vmovaps xmm4, [rsp+0x40]
00007f0145bd2d73  vmovaps xmm5, [rsp+0x50]
00007f0145bd2d79  vmovaps xmm6, [rsp+0x60]
00007f0145bd2d7f  vmovaps xmm7, [rsp+0x70]
00007f0145bd2d85  vmovaps xmm8, [rsp+0x80]
00007f0145bd2d8e  vmovaps xmm9, [rsp+0x90]
00007f0145bd2d97  vmovaps xmm10, [rsp+0xA0]
00007f0145bd2da0  vmovaps xmm11, [rsp+0xB0]
00007f0145bd2da9  vmovaps xmm12, [rsp+0xC0]
00007f0145bd2db2  vmovaps xmm14, [rsp+0xD0]
00007f0145bd2dbb  vmovaps xmm15, [rsp+0xE0]
00007f0145bd2dc4  add rsp, 0xF0
00007f0145bd2dcb  pop r11
00007f0145bd2dcd  pop r10
00007f0145bd2dcf  pop r9
00007f0145bd2dd1  pop r8
00007f0145bd2dd3  pop rsi
00007f0145bd2dd4  pop rdi
00007f0145bd2dd5  pop rdx
00007f0145bd2dd6  pop rcx
00007f0145bd2dd7  pop rax
00007f0145bd2dd8  add rsp, 0x08
00007f0145bd2ddc  jmp 0x00007F0145BCFE15
00007f0145bd2de1  sub rsp, 0x08
00007f0145bd2de5  push rax
00007f0145bd2de6  push rcx
00007f0145bd2de7  push rdx
00007f0145bd2de8  push rdi
00007f0145bd2de9  push rsi
00007f0145bd2dea  push r8
00007f0145bd2dec  push r9
00007f0145bd2dee  push r10
00007f0145bd2df0  push r11
00007f0145bd2df2  sub rsp, 0xF0
00007f0145bd2df9  vmovaps [rsp], xmm0
00007f0145bd2dfe  vmovaps [rsp+0x10], xmm2
00007f0145bd2e04  vmovaps [rsp+0x20], xmm3
00007f0145bd2e0a  vmovaps [rsp+0x30], xmm4
00007f0145bd2e10  vmovaps [rsp+0x40], xmm5
00007f0145bd2e16  vmovaps [rsp+0x50], xmm6
00007f0145bd2e1c  vmovaps [rsp+0x60], xmm7
00007f0145bd2e22  vmovaps [rsp+0x70], xmm8
00007f0145bd2e28  vmovaps [rsp+0x80], xmm9
00007f0145bd2e31  vmovaps [rsp+0x90], xmm10
00007f0145bd2e3a  vmovaps [rsp+0xA0], xmm11
00007f0145bd2e43  vmovaps [rsp+0xB0], xmm12
00007f0145bd2e4c  vmovaps [rsp+0xC0], xmm13
00007f0145bd2e55  vmovaps [rsp+0xD0], xmm14
00007f0145bd2e5e  vmovaps [rsp+0xE0], xmm15
00007f0145bd2e67  sub rsp, 0x30
00007f0145bd2e6b  movaps [rsp], xmm1
00007f0145bd2e6f  movaps [rsp+0x10], xmm15
00007f0145bd2e75  movaps [rsp+0x20], xmm10
00007f0145bd2e7b  lea rdi, [rsp]
00007f0145bd2e7f  mov esi, 0x00
00007f0145bd2e84  mov rax, 0x636570E98530
00007f0145bd2e8e  call rax
00007f0145bd2e90  movaps xmm1, [rsp]
00007f0145bd2e94  add rsp, 0x30
00007f0145bd2e98  vmovaps xmm0, [rsp]
00007f0145bd2e9d  vmovaps xmm2, [rsp+0x10]
00007f0145bd2ea3  vmovaps xmm3, [rsp+0x20]
00007f0145bd2ea9  vmovaps xmm4, [rsp+0x30]
00007f0145bd2eaf  vmovaps xmm5, [rsp+0x40]
00007f0145bd2eb5  vmovaps xmm6, [rsp+0x50]
00007f0145bd2ebb  vmovaps xmm7, [rsp+0x60]
00007f0145bd2ec1  vmovaps xmm8, [rsp+0x70]
00007f0145bd2ec7  vmovaps xmm9, [rsp+0x80]
00007f0145bd2ed0  vmovaps xmm10, [rsp+0x90]
00007f0145bd2ed9  vmovaps xmm11, [rsp+0xA0]
00007f0145bd2ee2  vmovaps xmm12, [rsp+0xB0]
00007f0145bd2eeb  vmovaps xmm13, [rsp+0xC0]
00007f0145bd2ef4  vmovaps xmm14, [rsp+0xD0]
00007f0145bd2efd  vmovaps xmm15, [rsp+0xE0]
00007f0145bd2f06  add rsp, 0xF0
00007f0145bd2f0d  pop r11
00007f0145bd2f0f  pop r10
00007f0145bd2f11  pop r9
00007f0145bd2f13  pop r8
00007f0145bd2f15  pop rsi
00007f0145bd2f16  pop rdi
00007f0145bd2f17  pop rdx
00007f0145bd2f18  pop rcx
00007f0145bd2f19  pop rax
00007f0145bd2f1a  add rsp, 0x08
00007f0145bd2f1e  jmp 0x00007F0145BCFE34
00007f0145bd2f23  sub rsp, 0x08
00007f0145bd2f27  push rax
00007f0145bd2f28  push rcx
00007f0145bd2f29  push rdx
00007f0145bd2f2a  push rdi
00007f0145bd2f2b  push rsi
00007f0145bd2f2c  push r8
00007f0145bd2f2e  push r9
00007f0145bd2f30  push r10
00007f0145bd2f32  push r11
00007f0145bd2f34  sub rsp, 0xF0
00007f0145bd2f3b  vmovaps [rsp], xmm0
00007f0145bd2f40  vmovaps [rsp+0x10], xmm1
00007f0145bd2f46  vmovaps [rsp+0x20], xmm2
00007f0145bd2f4c  vmovaps [rsp+0x30], xmm3
00007f0145bd2f52  vmovaps [rsp+0x40], xmm4
00007f0145bd2f58  vmovaps [rsp+0x50], xmm5
00007f0145bd2f5e  vmovaps [rsp+0x60], xmm6
00007f0145bd2f64  vmovaps [rsp+0x70], xmm7
00007f0145bd2f6a  vmovaps [rsp+0x80], xmm8
00007f0145bd2f73  vmovaps [rsp+0x90], xmm9
00007f0145bd2f7c  vmovaps [rsp+0xA0], xmm10
00007f0145bd2f85  vmovaps [rsp+0xB0], xmm11
00007f0145bd2f8e  vmovaps [rsp+0xC0], xmm12
00007f0145bd2f97  vmovaps [rsp+0xD0], xmm13
00007f0145bd2fa0  vmovaps [rsp+0xE0], xmm14
00007f0145bd2fa9  sub rsp, 0x30
00007f0145bd2fad  movaps [rsp], xmm15
00007f0145bd2fb2  movaps [rsp+0x10], xmm10
00007f0145bd2fb8  movaps [rsp+0x20], xmm11
00007f0145bd2fbe  lea rdi, [rsp]
00007f0145bd2fc2  mov esi, 0x00
00007f0145bd2fc7  mov rax, 0x636570E98530
00007f0145bd2fd1  call rax
00007f0145bd2fd3  movaps xmm15, [rsp]
00007f0145bd2fd8  add rsp, 0x30
00007f0145bd2fdc  vmovaps xmm0, [rsp]
00007f0145bd2fe1  vmovaps xmm1, [rsp+0x10]
00007f0145bd2fe7  vmovaps xmm2, [rsp+0x20]
00007f0145bd2fed  vmovaps xmm3, [rsp+0x30]
00007f0145bd2ff3  vmovaps xmm4, [rsp+0x40]
00007f0145bd2ff9  vmovaps xmm5, [rsp+0x50]
00007f0145bd2fff  vmovaps xmm6, [rsp+0x60]
00007f0145bd3005  vmovaps xmm7, [rsp+0x70]
00007f0145bd300b  vmovaps xmm8, [rsp+0x80]
00007f0145bd3014  vmovaps xmm9, [rsp+0x90]
00007f0145bd301d  vmovaps xmm10, [rsp+0xA0]
00007f0145bd3026  vmovaps xmm11, [rsp+0xB0]
00007f0145bd302f  vmovaps xmm12, [rsp+0xC0]
00007f0145bd3038  vmovaps xmm13, [rsp+0xD0]
00007f0145bd3041  vmovaps xmm14, [rsp+0xE0]
00007f0145bd304a  add rsp, 0xF0
00007f0145bd3051  pop r11
00007f0145bd3053  pop r10
00007f0145bd3055  pop r9
00007f0145bd3057  pop r8
00007f0145bd3059  pop rsi
00007f0145bd305a  pop rdi
00007f0145bd305b  pop rdx
00007f0145bd305c  pop rcx
00007f0145bd305d  pop rax
00007f0145bd305e  add rsp, 0x08
00007f0145bd3062  jmp 0x00007F0145BCFE57
00007f0145bd3067  sub rsp, 0x08
00007f0145bd306b  push rax
00007f0145bd306c  push rcx
00007f0145bd306d  push rdx
00007f0145bd306e  push rdi
00007f0145bd306f  push rsi
00007f0145bd3070  push r8
00007f0145bd3072  push r9
00007f0145bd3074  push r10
00007f0145bd3076  push r11
00007f0145bd3078  sub rsp, 0xF0
00007f0145bd307f  vmovaps [rsp], xmm0
00007f0145bd3084  vmovaps [rsp+0x10], xmm1
00007f0145bd308a  vmovaps [rsp+0x20], xmm2
00007f0145bd3090  vmovaps [rsp+0x30], xmm3
00007f0145bd3096  vmovaps [rsp+0x40], xmm4
00007f0145bd309c  vmovaps [rsp+0x50], xmm5
00007f0145bd30a2  vmovaps [rsp+0x60], xmm6
00007f0145bd30a8  vmovaps [rsp+0x70], xmm7
00007f0145bd30ae  vmovaps [rsp+0x80], xmm8
00007f0145bd30b7  vmovaps [rsp+0x90], xmm9
00007f0145bd30c0  vmovaps [rsp+0xA0], xmm11
00007f0145bd30c9  vmovaps [rsp+0xB0], xmm12
00007f0145bd30d2  vmovaps [rsp+0xC0], xmm13
00007f0145bd30db  vmovaps [rsp+0xD0], xmm14
00007f0145bd30e4  vmovaps [rsp+0xE0], xmm15
00007f0145bd30ed  sub rsp, 0x30
00007f0145bd30f1  movaps [rsp], xmm10
00007f0145bd30f6  movaps [rsp+0x10], xmm12
00007f0145bd30fc  movaps [rsp+0x20], xmm11
00007f0145bd3102  lea rdi, [rsp]
00007f0145bd3106  mov esi, 0x00
00007f0145bd310b  mov rax, 0x636570E98530
00007f0145bd3115  call rax
00007f0145bd3117  movaps xmm10, [rsp]
00007f0145bd311c  add rsp, 0x30
00007f0145bd3120  vmovaps xmm0, [rsp]
00007f0145bd3125  vmovaps xmm1, [rsp+0x10]
00007f0145bd312b  vmovaps xmm2, [rsp+0x20]
00007f0145bd3131  vmovaps xmm3, [rsp+0x30]
00007f0145bd3137  vmovaps xmm4, [rsp+0x40]
00007f0145bd313d  vmovaps xmm5, [rsp+0x50]
00007f0145bd3143  vmovaps xmm6, [rsp+0x60]
00007f0145bd3149  vmovaps xmm7, [rsp+0x70]
00007f0145bd314f  vmovaps xmm8, [rsp+0x80]
00007f0145bd3158  vmovaps xmm9, [rsp+0x90]
00007f0145bd3161  vmovaps xmm11, [rsp+0xA0]
00007f0145bd316a  vmovaps xmm12, [rsp+0xB0]
00007f0145bd3173  vmovaps xmm13, [rsp+0xC0]
00007f0145bd317c  vmovaps xmm14, [rsp+0xD0]
00007f0145bd3185  vmovaps xmm15, [rsp+0xE0]
00007f0145bd318e  add rsp, 0xF0
00007f0145bd3195  pop r11
00007f0145bd3197  pop r10
00007f0145bd3199  pop r9
00007f0145bd319b  pop r8
00007f0145bd319d  pop rsi
00007f0145bd319e  pop rdi
00007f0145bd319f  pop rdx
00007f0145bd31a0  pop rcx
00007f0145bd31a1  pop rax
00007f0145bd31a2  add rsp, 0x08
00007f0145bd31a6  jmp 0x00007F0145BCFE80
00007f0145bd31ab  sub rsp, 0x08
00007f0145bd31af  push rax
00007f0145bd31b0  push rcx
00007f0145bd31b1  push rdx
00007f0145bd31b2  push rdi
00007f0145bd31b3  push rsi
00007f0145bd31b4  push r8
00007f0145bd31b6  push r9
00007f0145bd31b8  push r10
00007f0145bd31ba  push r11
00007f0145bd31bc  sub rsp, 0xF0
00007f0145bd31c3  vmovaps [rsp], xmm0
00007f0145bd31c8  vmovaps [rsp+0x10], xmm1
00007f0145bd31ce  vmovaps [rsp+0x20], xmm2
00007f0145bd31d4  vmovaps [rsp+0x30], xmm3
00007f0145bd31da  vmovaps [rsp+0x40], xmm4
00007f0145bd31e0  vmovaps [rsp+0x50], xmm5
00007f0145bd31e6  vmovaps [rsp+0x60], xmm6
00007f0145bd31ec  vmovaps [rsp+0x70], xmm7
00007f0145bd31f2  vmovaps [rsp+0x80], xmm8
00007f0145bd31fb  vmovaps [rsp+0x90], xmm9
00007f0145bd3204  vmovaps [rsp+0xA0], xmm10
00007f0145bd320d  vmovaps [rsp+0xB0], xmm12
00007f0145bd3216  vmovaps [rsp+0xC0], xmm13
00007f0145bd321f  vmovaps [rsp+0xD0], xmm14
00007f0145bd3228  vmovaps [rsp+0xE0], xmm15
00007f0145bd3231  sub rsp, 0x30
00007f0145bd3235  movaps [rsp], xmm11
00007f0145bd323a  movaps [rsp+0x10], xmm2
00007f0145bd323f  movaps [rsp+0x20], xmm12
00007f0145bd3245  lea rdi, [rsp]
00007f0145bd3249  mov esi, 0x00
00007f0145bd324e  mov rax, 0x636570E98530
00007f0145bd3258  call rax
00007f0145bd325a  movaps xmm11, [rsp]
00007f0145bd325f  add rsp, 0x30
00007f0145bd3263  vmovaps xmm0, [rsp]
00007f0145bd3268  vmovaps xmm1, [rsp+0x10]
00007f0145bd326e  vmovaps xmm2, [rsp+0x20]
00007f0145bd3274  vmovaps xmm3, [rsp+0x30]
00007f0145bd327a  vmovaps xmm4, [rsp+0x40]
00007f0145bd3280  vmovaps xmm5, [rsp+0x50]
00007f0145bd3286  vmovaps xmm6, [rsp+0x60]
00007f0145bd328c  vmovaps xmm7, [rsp+0x70]
00007f0145bd3292  vmovaps xmm8, [rsp+0x80]
00007f0145bd329b  vmovaps xmm9, [rsp+0x90]
00007f0145bd32a4  vmovaps xmm10, [rsp+0xA0]
00007f0145bd32ad  vmovaps xmm12, [rsp+0xB0]
00007f0145bd32b6  vmovaps xmm13, [rsp+0xC0]
00007f0145bd32bf  vmovaps xmm14, [rsp+0xD0]
00007f0145bd32c8  vmovaps xmm15, [rsp+0xE0]
00007f0145bd32d1  add rsp, 0xF0
00007f0145bd32d8  pop r11
00007f0145bd32da  pop r10
00007f0145bd32dc  pop r9
00007f0145bd32de  pop r8
00007f0145bd32e0  pop rsi
00007f0145bd32e1  pop rdi
00007f0145bd32e2  pop rdx
00007f0145bd32e3  pop rcx
00007f0145bd32e4  pop rax
00007f0145bd32e5  add rsp, 0x08
00007f0145bd32e9  jmp 0x00007F0145BCFEB8
00007f0145bd32ee  sub rsp, 0x08
00007f0145bd32f2  push rax
00007f0145bd32f3  push rcx
00007f0145bd32f4  push rdx
00007f0145bd32f5  push rdi
00007f0145bd32f6  push rsi
00007f0145bd32f7  push r8
00007f0145bd32f9  push r9
00007f0145bd32fb  push r10
00007f0145bd32fd  push r11
00007f0145bd32ff  sub rsp, 0xF0
00007f0145bd3306  vmovaps [rsp], xmm0
00007f0145bd330b  vmovaps [rsp+0x10], xmm2
00007f0145bd3311  vmovaps [rsp+0x20], xmm3
00007f0145bd3317  vmovaps [rsp+0x30], xmm4
00007f0145bd331d  vmovaps [rsp+0x40], xmm5
00007f0145bd3323  vmovaps [rsp+0x50], xmm6
00007f0145bd3329  vmovaps [rsp+0x60], xmm7
00007f0145bd332f  vmovaps [rsp+0x70], xmm8
00007f0145bd3335  vmovaps [rsp+0x80], xmm9
00007f0145bd333e  vmovaps [rsp+0x90], xmm10
00007f0145bd3347  vmovaps [rsp+0xA0], xmm11
00007f0145bd3350  vmovaps [rsp+0xB0], xmm12
00007f0145bd3359  vmovaps [rsp+0xC0], xmm13
00007f0145bd3362  vmovaps [rsp+0xD0], xmm14
00007f0145bd336b  vmovaps [rsp+0xE0], xmm15
00007f0145bd3374  sub rsp, 0x30
00007f0145bd3378  movaps [rsp], xmm1
00007f0145bd337c  movaps [rsp+0x10], xmm14
00007f0145bd3382  movaps [rsp+0x20], xmm6
00007f0145bd3387  lea rdi, [rsp]
00007f0145bd338b  mov esi, 0x00
00007f0145bd3390  mov rax, 0x636570E98530
00007f0145bd339a  call rax
00007f0145bd339c  movaps xmm1, [rsp]
00007f0145bd33a0  add rsp, 0x30
00007f0145bd33a4  vmovaps xmm0, [rsp]
00007f0145bd33a9  vmovaps xmm2, [rsp+0x10]
00007f0145bd33af  vmovaps xmm3, [rsp+0x20]
00007f0145bd33b5  vmovaps xmm4, [rsp+0x30]
00007f0145bd33bb  vmovaps xmm5, [rsp+0x40]
00007f0145bd33c1  vmovaps xmm6, [rsp+0x50]
00007f0145bd33c7  vmovaps xmm7, [rsp+0x60]
00007f0145bd33cd  vmovaps xmm8, [rsp+0x70]
00007f0145bd33d3  vmovaps xmm9, [rsp+0x80]
00007f0145bd33dc  vmovaps xmm10, [rsp+0x90]
00007f0145bd33e5  vmovaps xmm11, [rsp+0xA0]
00007f0145bd33ee  vmovaps xmm12, [rsp+0xB0]
00007f0145bd33f7  vmovaps xmm13, [rsp+0xC0]
00007f0145bd3400  vmovaps xmm14, [rsp+0xD0]
00007f0145bd3409  vmovaps xmm15, [rsp+0xE0]
00007f0145bd3412  add rsp, 0xF0
00007f0145bd3419  pop r11
00007f0145bd341b  pop r10
00007f0145bd341d  pop r9
00007f0145bd341f  pop r8
00007f0145bd3421  pop rsi
00007f0145bd3422  pop rdi
00007f0145bd3423  pop rdx
00007f0145bd3424  pop rcx
00007f0145bd3425  pop rax
00007f0145bd3426  add rsp, 0x08
00007f0145bd342a  jmp 0x00007F0145BCFED1
00007f0145bd342f  sub rsp, 0x08
00007f0145bd3433  push rax
00007f0145bd3434  push rcx
00007f0145bd3435  push rdx
00007f0145bd3436  push rdi
00007f0145bd3437  push rsi
00007f0145bd3438  push r8
00007f0145bd343a  push r9
00007f0145bd343c  push r10
00007f0145bd343e  push r11
00007f0145bd3440  sub rsp, 0xF0
00007f0145bd3447  vmovaps [rsp], xmm0
00007f0145bd344c  vmovaps [rsp+0x10], xmm1
00007f0145bd3452  vmovaps [rsp+0x20], xmm2
00007f0145bd3458  vmovaps [rsp+0x30], xmm3
00007f0145bd345e  vmovaps [rsp+0x40], xmm4
00007f0145bd3464  vmovaps [rsp+0x50], xmm5
00007f0145bd346a  vmovaps [rsp+0x60], xmm6
00007f0145bd3470  vmovaps [rsp+0x70], xmm7
00007f0145bd3476  vmovaps [rsp+0x80], xmm8
00007f0145bd347f  vmovaps [rsp+0x90], xmm9
00007f0145bd3488  vmovaps [rsp+0xA0], xmm10
00007f0145bd3491  vmovaps [rsp+0xB0], xmm11
00007f0145bd349a  vmovaps [rsp+0xC0], xmm12
00007f0145bd34a3  vmovaps [rsp+0xD0], xmm13
00007f0145bd34ac  vmovaps [rsp+0xE0], xmm15
00007f0145bd34b5  sub rsp, 0x30
00007f0145bd34b9  movaps [rsp], xmm14
00007f0145bd34be  movaps [rsp+0x10], xmm12
00007f0145bd34c4  movaps [rsp+0x20], xmm5
00007f0145bd34c9  lea rdi, [rsp]
00007f0145bd34cd  mov esi, 0x00
00007f0145bd34d2  mov rax, 0x636570E98530
00007f0145bd34dc  call rax
00007f0145bd34de  movaps xmm14, [rsp]
00007f0145bd34e3  add rsp, 0x30
00007f0145bd34e7  vmovaps xmm0, [rsp]
00007f0145bd34ec  vmovaps xmm1, [rsp+0x10]
00007f0145bd34f2  vmovaps xmm2, [rsp+0x20]
00007f0145bd34f8  vmovaps xmm3, [rsp+0x30]
00007f0145bd34fe  vmovaps xmm4, [rsp+0x40]
00007f0145bd3504  vmovaps xmm5, [rsp+0x50]
00007f0145bd350a  vmovaps xmm6, [rsp+0x60]
00007f0145bd3510  vmovaps xmm7, [rsp+0x70]
00007f0145bd3516  vmovaps xmm8, [rsp+0x80]
00007f0145bd351f  vmovaps xmm9, [rsp+0x90]
00007f0145bd3528  vmovaps xmm10, [rsp+0xA0]
00007f0145bd3531  vmovaps xmm11, [rsp+0xB0]
00007f0145bd353a  vmovaps xmm12, [rsp+0xC0]
00007f0145bd3543  vmovaps xmm13, [rsp+0xD0]
00007f0145bd354c  vmovaps xmm15, [rsp+0xE0]
00007f0145bd3555  add rsp, 0xF0
00007f0145bd355c  pop r11
00007f0145bd355e  pop r10
00007f0145bd3560  pop r9
00007f0145bd3562  pop r8
00007f0145bd3564  pop rsi
00007f0145bd3565  pop rdi
00007f0145bd3566  pop rdx
00007f0145bd3567  pop rcx
00007f0145bd3568  pop rax
00007f0145bd3569  add rsp, 0x08
00007f0145bd356d  jmp 0x00007F0145BCFEF1
00007f0145bd3572  sub rsp, 0x08
00007f0145bd3576  push rax
00007f0145bd3577  push rcx
00007f0145bd3578  push rdx
00007f0145bd3579  push rdi
00007f0145bd357a  push rsi
00007f0145bd357b  push r8
00007f0145bd357d  push r9
00007f0145bd357f  push r10
00007f0145bd3581  push r11
00007f0145bd3583  sub rsp, 0xF0
00007f0145bd358a  vmovaps [rsp], xmm0
00007f0145bd358f  vmovaps [rsp+0x10], xmm1
00007f0145bd3595  vmovaps [rsp+0x20], xmm2
00007f0145bd359b  vmovaps [rsp+0x30], xmm3
00007f0145bd35a1  vmovaps [rsp+0x40], xmm4
00007f0145bd35a7  vmovaps [rsp+0x50], xmm5
00007f0145bd35ad  vmovaps [rsp+0x60], xmm7
00007f0145bd35b3  vmovaps [rsp+0x70], xmm8
00007f0145bd35b9  vmovaps [rsp+0x80], xmm9
00007f0145bd35c2  vmovaps [rsp+0x90], xmm10
00007f0145bd35cb  vmovaps [rsp+0xA0], xmm11
00007f0145bd35d4  vmovaps [rsp+0xB0], xmm12
00007f0145bd35dd  vmovaps [rsp+0xC0], xmm13
00007f0145bd35e6  vmovaps [rsp+0xD0], xmm14
00007f0145bd35ef  vmovaps [rsp+0xE0], xmm15
00007f0145bd35f8  sub rsp, 0x30
00007f0145bd35fc  movaps [rsp], xmm6
00007f0145bd3600  movaps [rsp+0x10], xmm9
00007f0145bd3606  movaps [rsp+0x20], xmm12
00007f0145bd360c  lea rdi, [rsp]
00007f0145bd3610  mov esi, 0x00
00007f0145bd3615  mov rax, 0x636570E98530
00007f0145bd361f  call rax
00007f0145bd3621  movaps xmm6, [rsp]
00007f0145bd3625  add rsp, 0x30
00007f0145bd3629  vmovaps xmm0, [rsp]
00007f0145bd362e  vmovaps xmm1, [rsp+0x10]
00007f0145bd3634  vmovaps xmm2, [rsp+0x20]
00007f0145bd363a  vmovaps xmm3, [rsp+0x30]
00007f0145bd3640  vmovaps xmm4, [rsp+0x40]
00007f0145bd3646  vmovaps xmm5, [rsp+0x50]
00007f0145bd364c  vmovaps xmm7, [rsp+0x60]
00007f0145bd3652  vmovaps xmm8, [rsp+0x70]
00007f0145bd3658  vmovaps xmm9, [rsp+0x80]
00007f0145bd3661  vmovaps xmm10, [rsp+0x90]
00007f0145bd366a  vmovaps xmm11, [rsp+0xA0]
00007f0145bd3673  vmovaps xmm12, [rsp+0xB0]
00007f0145bd367c  vmovaps xmm13, [rsp+0xC0]
00007f0145bd3685  vmovaps xmm14, [rsp+0xD0]
00007f0145bd368e  vmovaps xmm15, [rsp+0xE0]
00007f0145bd3697  add rsp, 0xF0
00007f0145bd369e  pop r11
00007f0145bd36a0  pop r10
00007f0145bd36a2  pop r9
00007f0145bd36a4  pop r8
00007f0145bd36a6  pop rsi
00007f0145bd36a7  pop rdi
00007f0145bd36a8  pop rdx
00007f0145bd36a9  pop rcx
00007f0145bd36aa  pop rax
00007f0145bd36ab  add rsp, 0x08
00007f0145bd36af  jmp 0x00007F0145BCFF19
00007f0145bd36b4  sub rsp, 0x08
00007f0145bd36b8  push rax
00007f0145bd36b9  push rcx
00007f0145bd36ba  push rdx
00007f0145bd36bb  push rdi
00007f0145bd36bc  push rsi
00007f0145bd36bd  push r8
00007f0145bd36bf  push r9
00007f0145bd36c1  push r10
00007f0145bd36c3  push r11
00007f0145bd36c5  sub rsp, 0xF0
00007f0145bd36cc  vmovaps [rsp], xmm0
00007f0145bd36d1  vmovaps [rsp+0x10], xmm1
00007f0145bd36d7  vmovaps [rsp+0x20], xmm2
00007f0145bd36dd  vmovaps [rsp+0x30], xmm3
00007f0145bd36e3  vmovaps [rsp+0x40], xmm4
00007f0145bd36e9  vmovaps [rsp+0x50], xmm5
00007f0145bd36ef  vmovaps [rsp+0x60], xmm6
00007f0145bd36f5  vmovaps [rsp+0x70], xmm7
00007f0145bd36fb  vmovaps [rsp+0x80], xmm8
00007f0145bd3704  vmovaps [rsp+0x90], xmm9
00007f0145bd370d  vmovaps [rsp+0xA0], xmm10
00007f0145bd3716  vmovaps [rsp+0xB0], xmm11
00007f0145bd371f  vmovaps [rsp+0xC0], xmm13
00007f0145bd3728  vmovaps [rsp+0xD0], xmm14
00007f0145bd3731  vmovaps [rsp+0xE0], xmm15
00007f0145bd373a  sub rsp, 0x30
00007f0145bd373e  movaps [rsp], xmm12
00007f0145bd3743  movaps [rsp+0x10], xmm15
00007f0145bd3749  movaps [rsp+0x20], xmm13
00007f0145bd374f  lea rdi, [rsp]
00007f0145bd3753  mov esi, 0x00
00007f0145bd3758  mov rax, 0x636570E98530
00007f0145bd3762  call rax
00007f0145bd3764  movaps xmm12, [rsp]
00007f0145bd3769  add rsp, 0x30
00007f0145bd376d  vmovaps xmm0, [rsp]
00007f0145bd3772  vmovaps xmm1, [rsp+0x10]
00007f0145bd3778  vmovaps xmm2, [rsp+0x20]
00007f0145bd377e  vmovaps xmm3, [rsp+0x30]
00007f0145bd3784  vmovaps xmm4, [rsp+0x40]
00007f0145bd378a  vmovaps xmm5, [rsp+0x50]
00007f0145bd3790  vmovaps xmm6, [rsp+0x60]
00007f0145bd3796  vmovaps xmm7, [rsp+0x70]
00007f0145bd379c  vmovaps xmm8, [rsp+0x80]
00007f0145bd37a5  vmovaps xmm9, [rsp+0x90]
00007f0145bd37ae  vmovaps xmm10, [rsp+0xA0]
00007f0145bd37b7  vmovaps xmm11, [rsp+0xB0]
00007f0145bd37c0  vmovaps xmm13, [rsp+0xC0]
00007f0145bd37c9  vmovaps xmm14, [rsp+0xD0]
00007f0145bd37d2  vmovaps xmm15, [rsp+0xE0]
00007f0145bd37db  add rsp, 0xF0
00007f0145bd37e2  pop r11
00007f0145bd37e4  pop r10
00007f0145bd37e6  pop r9
00007f0145bd37e8  pop r8
00007f0145bd37ea  pop rsi
00007f0145bd37eb  pop rdi
00007f0145bd37ec  pop rdx
00007f0145bd37ed  pop rcx
00007f0145bd37ee  pop rax
00007f0145bd37ef  add rsp, 0x08
00007f0145bd37f3  jmp 0x00007F0145BCFF34
00007f0145bd37f8  sub rsp, 0x08
00007f0145bd37fc  push rax
00007f0145bd37fd  push rcx
00007f0145bd37fe  push rdx
00007f0145bd37ff  push rdi
00007f0145bd3800  push rsi
00007f0145bd3801  push r8
00007f0145bd3803  push r9
00007f0145bd3805  push r10
00007f0145bd3807  push r11
00007f0145bd3809  sub rsp, 0xF0
00007f0145bd3810  vmovaps [rsp], xmm0
00007f0145bd3815  vmovaps [rsp+0x10], xmm1
00007f0145bd381b  vmovaps [rsp+0x20], xmm2
00007f0145bd3821  vmovaps [rsp+0x30], xmm3
00007f0145bd3827  vmovaps [rsp+0x40], xmm4
00007f0145bd382d  vmovaps [rsp+0x50], xmm5
00007f0145bd3833  vmovaps [rsp+0x60], xmm6
00007f0145bd3839  vmovaps [rsp+0x70], xmm7
00007f0145bd383f  vmovaps [rsp+0x80], xmm8
00007f0145bd3848  vmovaps [rsp+0x90], xmm9
00007f0145bd3851  vmovaps [rsp+0xA0], xmm10
00007f0145bd385a  vmovaps [rsp+0xB0], xmm11
00007f0145bd3863  vmovaps [rsp+0xC0], xmm12
00007f0145bd386c  vmovaps [rsp+0xD0], xmm13
00007f0145bd3875  vmovaps [rsp+0xE0], xmm14
00007f0145bd387e  sub rsp, 0x30
00007f0145bd3882  movaps [rsp], xmm15
00007f0145bd3887  movaps [rsp+0x10], xmm13
00007f0145bd388d  movaps [rsp+0x20], xmm10
00007f0145bd3893  lea rdi, [rsp]
00007f0145bd3897  mov esi, 0x00
00007f0145bd389c  mov rax, 0x636570E98530
00007f0145bd38a6  call rax
00007f0145bd38a8  movaps xmm15, [rsp]
00007f0145bd38ad  add rsp, 0x30
00007f0145bd38b1  vmovaps xmm0, [rsp]
00007f0145bd38b6  vmovaps xmm1, [rsp+0x10]
00007f0145bd38bc  vmovaps xmm2, [rsp+0x20]
00007f0145bd38c2  vmovaps xmm3, [rsp+0x30]
00007f0145bd38c8  vmovaps xmm4, [rsp+0x40]
00007f0145bd38ce  vmovaps xmm5, [rsp+0x50]
00007f0145bd38d4  vmovaps xmm6, [rsp+0x60]
00007f0145bd38da  vmovaps xmm7, [rsp+0x70]
00007f0145bd38e0  vmovaps xmm8, [rsp+0x80]
00007f0145bd38e9  vmovaps xmm9, [rsp+0x90]
00007f0145bd38f2  vmovaps xmm10, [rsp+0xA0]
00007f0145bd38fb  vmovaps xmm11, [rsp+0xB0]
00007f0145bd3904  vmovaps xmm12, [rsp+0xC0]
00007f0145bd390d  vmovaps xmm13, [rsp+0xD0]
00007f0145bd3916  vmovaps xmm14, [rsp+0xE0]
00007f0145bd391f  add rsp, 0xF0
00007f0145bd3926  pop r11
00007f0145bd3928  pop r10
00007f0145bd392a  pop r9
00007f0145bd392c  pop r8
00007f0145bd392e  pop rsi
00007f0145bd392f  pop rdi
00007f0145bd3930  pop rdx
00007f0145bd3931  pop rcx
00007f0145bd3932  pop rax
00007f0145bd3933  add rsp, 0x08
00007f0145bd3937  jmp 0x00007F0145BCFF55
00007f0145bd393c  call 0x00007F0145A0C260
00007f0145bd3941  jmp 0x00007F0145BCFFB0
00007f0145bd3946  sub rsp, 0x08
00007f0145bd394a  push rax
00007f0145bd394b  push rcx
00007f0145bd394c  push rdx
00007f0145bd394d  push rdi
00007f0145bd394e  push rsi
00007f0145bd394f  push r8
00007f0145bd3951  push r9
00007f0145bd3953  push r10
00007f0145bd3955  push r11
00007f0145bd3957  sub rsp, 0xF0
00007f0145bd395e  vmovaps [rsp], xmm0
00007f0145bd3963  vmovaps [rsp+0x10], xmm1
00007f0145bd3969  vmovaps [rsp+0x20], xmm2
00007f0145bd396f  vmovaps [rsp+0x30], xmm3
00007f0145bd3975  vmovaps [rsp+0x40], xmm4
00007f0145bd397b  vmovaps [rsp+0x50], xmm5
00007f0145bd3981  vmovaps [rsp+0x60], xmm6
00007f0145bd3987  vmovaps [rsp+0x70], xmm7
00007f0145bd398d  vmovaps [rsp+0x80], xmm8
00007f0145bd3996  vmovaps [rsp+0x90], xmm10
00007f0145bd399f  vmovaps [rsp+0xA0], xmm11
00007f0145bd39a8  vmovaps [rsp+0xB0], xmm12
00007f0145bd39b1  vmovaps [rsp+0xC0], xmm13
00007f0145bd39ba  vmovaps [rsp+0xD0], xmm14
00007f0145bd39c3  vmovaps [rsp+0xE0], xmm15
00007f0145bd39cc  sub rsp, 0x30
00007f0145bd39d0  movaps [rsp], xmm9
00007f0145bd39d5  movaps [rsp+0x10], xmm8
00007f0145bd39db  movaps [rsp+0x20], xmm10
00007f0145bd39e1  lea rdi, [rsp]
00007f0145bd39e5  mov esi, 0x00
00007f0145bd39ea  mov rax, 0x636570E98530
00007f0145bd39f4  call rax
00007f0145bd39f6  movaps xmm9, [rsp]
00007f0145bd39fb  add rsp, 0x30
00007f0145bd39ff  vmovaps xmm0, [rsp]
00007f0145bd3a04  vmovaps xmm1, [rsp+0x10]
00007f0145bd3a0a  vmovaps xmm2, [rsp+0x20]
00007f0145bd3a10  vmovaps xmm3, [rsp+0x30]
00007f0145bd3a16  vmovaps xmm4, [rsp+0x40]
00007f0145bd3a1c  vmovaps xmm5, [rsp+0x50]
00007f0145bd3a22  vmovaps xmm6, [rsp+0x60]
00007f0145bd3a28  vmovaps xmm7, [rsp+0x70]
00007f0145bd3a2e  vmovaps xmm8, [rsp+0x80]
00007f0145bd3a37  vmovaps xmm10, [rsp+0x90]
00007f0145bd3a40  vmovaps xmm11, [rsp+0xA0]
00007f0145bd3a49  vmovaps xmm12, [rsp+0xB0]
00007f0145bd3a52  vmovaps xmm13, [rsp+0xC0]
00007f0145bd3a5b  vmovaps xmm14, [rsp+0xD0]
00007f0145bd3a64  vmovaps xmm15, [rsp+0xE0]
00007f0145bd3a6d  add rsp, 0xF0
00007f0145bd3a74  pop r11
00007f0145bd3a76  pop r10
00007f0145bd3a78  pop r9
00007f0145bd3a7a  pop r8
00007f0145bd3a7c  pop rsi
00007f0145bd3a7d  pop rdi
00007f0145bd3a7e  pop rdx
00007f0145bd3a7f  pop rcx
00007f0145bd3a80  pop rax
00007f0145bd3a81  add rsp, 0x08
00007f0145bd3a85  jmp 0x00007F0145BCFFE1
00007f0145bd3a8a  sub rsp, 0x08
00007f0145bd3a8e  push rax
00007f0145bd3a8f  push rcx
00007f0145bd3a90  push rdx
00007f0145bd3a91  push rdi
00007f0145bd3a92  push rsi
00007f0145bd3a93  push r8
00007f0145bd3a95  push r9
00007f0145bd3a97  push r10
00007f0145bd3a99  push r11
00007f0145bd3a9b  sub rsp, 0xF0
00007f0145bd3aa2  vmovaps [rsp], xmm0
00007f0145bd3aa7  vmovaps [rsp+0x10], xmm1
00007f0145bd3aad  vmovaps [rsp+0x20], xmm2
00007f0145bd3ab3  vmovaps [rsp+0x30], xmm3
00007f0145bd3ab9  vmovaps [rsp+0x40], xmm4
00007f0145bd3abf  vmovaps [rsp+0x50], xmm5
00007f0145bd3ac5  vmovaps [rsp+0x60], xmm6
00007f0145bd3acb  vmovaps [rsp+0x70], xmm7
00007f0145bd3ad1  vmovaps [rsp+0x80], xmm8
00007f0145bd3ada  vmovaps [rsp+0x90], xmm9
00007f0145bd3ae3  vmovaps [rsp+0xA0], xmm11
00007f0145bd3aec  vmovaps [rsp+0xB0], xmm12
00007f0145bd3af5  vmovaps [rsp+0xC0], xmm13
00007f0145bd3afe  vmovaps [rsp+0xD0], xmm14
00007f0145bd3b07  vmovaps [rsp+0xE0], xmm15
00007f0145bd3b10  sub rsp, 0x30
00007f0145bd3b14  movaps [rsp], xmm10
00007f0145bd3b19  movaps [rsp+0x10], xmm1
00007f0145bd3b1e  movaps [rsp+0x20], xmm11
00007f0145bd3b24  lea rdi, [rsp]
00007f0145bd3b28  mov esi, 0x00
00007f0145bd3b2d  mov rax, 0x636570E98530
00007f0145bd3b37  call rax
00007f0145bd3b39  movaps xmm10, [rsp]
00007f0145bd3b3e  add rsp, 0x30
00007f0145bd3b42  vmovaps xmm0, [rsp]
00007f0145bd3b47  vmovaps xmm1, [rsp+0x10]
00007f0145bd3b4d  vmovaps xmm2, [rsp+0x20]
00007f0145bd3b53  vmovaps xmm3, [rsp+0x30]
00007f0145bd3b59  vmovaps xmm4, [rsp+0x40]
00007f0145bd3b5f  vmovaps xmm5, [rsp+0x50]
00007f0145bd3b65  vmovaps xmm6, [rsp+0x60]
00007f0145bd3b6b  vmovaps xmm7, [rsp+0x70]
00007f0145bd3b71  vmovaps xmm8, [rsp+0x80]
00007f0145bd3b7a  vmovaps xmm9, [rsp+0x90]
00007f0145bd3b83  vmovaps xmm11, [rsp+0xA0]
00007f0145bd3b8c  vmovaps xmm12, [rsp+0xB0]
00007f0145bd3b95  vmovaps xmm13, [rsp+0xC0]
00007f0145bd3b9e  vmovaps xmm14, [rsp+0xD0]
00007f0145bd3ba7  vmovaps xmm15, [rsp+0xE0]
00007f0145bd3bb0  add rsp, 0xF0
00007f0145bd3bb7  pop r11
00007f0145bd3bb9  pop r10
00007f0145bd3bbb  pop r9
00007f0145bd3bbd  pop r8
00007f0145bd3bbf  pop rsi
00007f0145bd3bc0  pop rdi
00007f0145bd3bc1  pop rdx
00007f0145bd3bc2  pop rcx
00007f0145bd3bc3  pop rax
00007f0145bd3bc4  add rsp, 0x08
00007f0145bd3bc8  jmp 0x00007F0145BCFFFC
00007f0145bd3bcd  sub rsp, 0x08
00007f0145bd3bd1  push rax
00007f0145bd3bd2  push rcx
00007f0145bd3bd3  push rdx
00007f0145bd3bd4  push rdi
00007f0145bd3bd5  push rsi
00007f0145bd3bd6  push r8
00007f0145bd3bd8  push r9
00007f0145bd3bda  push r10
00007f0145bd3bdc  push r11
00007f0145bd3bde  sub rsp, 0xF0
00007f0145bd3be5  vmovaps [rsp], xmm0
00007f0145bd3bea  vmovaps [rsp+0x10], xmm2
00007f0145bd3bf0  vmovaps [rsp+0x20], xmm3
00007f0145bd3bf6  vmovaps [rsp+0x30], xmm4
00007f0145bd3bfc  vmovaps [rsp+0x40], xmm5
00007f0145bd3c02  vmovaps [rsp+0x50], xmm6
00007f0145bd3c08  vmovaps [rsp+0x60], xmm7
00007f0145bd3c0e  vmovaps [rsp+0x70], xmm8
00007f0145bd3c14  vmovaps [rsp+0x80], xmm9
00007f0145bd3c1d  vmovaps [rsp+0x90], xmm10
00007f0145bd3c26  vmovaps [rsp+0xA0], xmm11
00007f0145bd3c2f  vmovaps [rsp+0xB0], xmm12
00007f0145bd3c38  vmovaps [rsp+0xC0], xmm13
00007f0145bd3c41  vmovaps [rsp+0xD0], xmm14
00007f0145bd3c4a  vmovaps [rsp+0xE0], xmm15
00007f0145bd3c53  sub rsp, 0x30
00007f0145bd3c57  movaps [rsp], xmm1
00007f0145bd3c5b  movaps [rsp+0x10], xmm14
00007f0145bd3c61  movaps [rsp+0x20], xmm6
00007f0145bd3c66  lea rdi, [rsp]
00007f0145bd3c6a  mov esi, 0x00
00007f0145bd3c6f  mov rax, 0x636570E98530
00007f0145bd3c79  call rax
00007f0145bd3c7b  movaps xmm1, [rsp]
00007f0145bd3c7f  add rsp, 0x30
00007f0145bd3c83  vmovaps xmm0, [rsp]
00007f0145bd3c88  vmovaps xmm2, [rsp+0x10]
00007f0145bd3c8e  vmovaps xmm3, [rsp+0x20]
00007f0145bd3c94  vmovaps xmm4, [rsp+0x30]
00007f0145bd3c9a  vmovaps xmm5, [rsp+0x40]
00007f0145bd3ca0  vmovaps xmm6, [rsp+0x50]
00007f0145bd3ca6  vmovaps xmm7, [rsp+0x60]
00007f0145bd3cac  vmovaps xmm8, [rsp+0x70]
00007f0145bd3cb2  vmovaps xmm9, [rsp+0x80]
00007f0145bd3cbb  vmovaps xmm10, [rsp+0x90]
00007f0145bd3cc4  vmovaps xmm11, [rsp+0xA0]
00007f0145bd3ccd  vmovaps xmm12, [rsp+0xB0]
00007f0145bd3cd6  vmovaps xmm13, [rsp+0xC0]
00007f0145bd3cdf  vmovaps xmm14, [rsp+0xD0]
00007f0145bd3ce8  vmovaps xmm15, [rsp+0xE0]
00007f0145bd3cf1  add rsp, 0xF0
00007f0145bd3cf8  pop r11
00007f0145bd3cfa  pop r10
00007f0145bd3cfc  pop r9
00007f0145bd3cfe  pop r8
00007f0145bd3d00  pop rsi
00007f0145bd3d01  pop rdi
00007f0145bd3d02  pop rdx
00007f0145bd3d03  pop rcx
00007f0145bd3d04  pop rax
00007f0145bd3d05  add rsp, 0x08
00007f0145bd3d09  jmp 0x00007F0145BD0015
00007f0145bd3d0e  sub rsp, 0x08
00007f0145bd3d12  push rax
00007f0145bd3d13  push rcx
00007f0145bd3d14  push rdx
00007f0145bd3d15  push rdi
00007f0145bd3d16  push rsi
00007f0145bd3d17  push r8
00007f0145bd3d19  push r9
00007f0145bd3d1b  push r10
00007f0145bd3d1d  push r11
00007f0145bd3d1f  sub rsp, 0xF0
00007f0145bd3d26  vmovaps [rsp], xmm0
00007f0145bd3d2b  vmovaps [rsp+0x10], xmm1
00007f0145bd3d31  vmovaps [rsp+0x20], xmm2
00007f0145bd3d37  vmovaps [rsp+0x30], xmm3
00007f0145bd3d3d  vmovaps [rsp+0x40], xmm4
00007f0145bd3d43  vmovaps [rsp+0x50], xmm5
00007f0145bd3d49  vmovaps [rsp+0x60], xmm6
00007f0145bd3d4f  vmovaps [rsp+0x70], xmm7
00007f0145bd3d55  vmovaps [rsp+0x80], xmm8
00007f0145bd3d5e  vmovaps [rsp+0x90], xmm9
00007f0145bd3d67  vmovaps [rsp+0xA0], xmm10
00007f0145bd3d70  vmovaps [rsp+0xB0], xmm12
00007f0145bd3d79  vmovaps [rsp+0xC0], xmm13
00007f0145bd3d82  vmovaps [rsp+0xD0], xmm14
00007f0145bd3d8b  vmovaps [rsp+0xE0], xmm15
00007f0145bd3d94  sub rsp, 0x30
00007f0145bd3d98  movaps [rsp], xmm11
00007f0145bd3d9d  movaps [rsp+0x10], xmm13
00007f0145bd3da3  movaps [rsp+0x20], xmm14
00007f0145bd3da9  lea rdi, [rsp]
00007f0145bd3dad  mov esi, 0x00
00007f0145bd3db2  mov rax, 0x636570E98530
00007f0145bd3dbc  call rax
00007f0145bd3dbe  movaps xmm11, [rsp]
00007f0145bd3dc3  add rsp, 0x30
00007f0145bd3dc7  vmovaps xmm0, [rsp]
00007f0145bd3dcc  vmovaps xmm1, [rsp+0x10]
00007f0145bd3dd2  vmovaps xmm2, [rsp+0x20]
00007f0145bd3dd8  vmovaps xmm3, [rsp+0x30]
00007f0145bd3dde  vmovaps xmm4, [rsp+0x40]
00007f0145bd3de4  vmovaps xmm5, [rsp+0x50]
00007f0145bd3dea  vmovaps xmm6, [rsp+0x60]
00007f0145bd3df0  vmovaps xmm7, [rsp+0x70]
00007f0145bd3df6  vmovaps xmm8, [rsp+0x80]
00007f0145bd3dff  vmovaps xmm9, [rsp+0x90]
00007f0145bd3e08  vmovaps xmm10, [rsp+0xA0]
00007f0145bd3e11  vmovaps xmm12, [rsp+0xB0]
00007f0145bd3e1a  vmovaps xmm13, [rsp+0xC0]
00007f0145bd3e23  vmovaps xmm14, [rsp+0xD0]
00007f0145bd3e2c  vmovaps xmm15, [rsp+0xE0]
00007f0145bd3e35  add rsp, 0xF0
00007f0145bd3e3c  pop r11
00007f0145bd3e3e  pop r10
00007f0145bd3e40  pop r9
00007f0145bd3e42  pop r8
00007f0145bd3e44  pop rsi
00007f0145bd3e45  pop rdi
00007f0145bd3e46  pop rdx
00007f0145bd3e47  pop rcx
00007f0145bd3e48  pop rax
00007f0145bd3e49  add rsp, 0x08
00007f0145bd3e4d  jmp 0x00007F0145BD003F
00007f0145bd3e52  sub rsp, 0x08
00007f0145bd3e56  push rax
00007f0145bd3e57  push rcx
00007f0145bd3e58  push rdx
00007f0145bd3e59  push rdi
00007f0145bd3e5a  push rsi
00007f0145bd3e5b  push r8
00007f0145bd3e5d  push r9
00007f0145bd3e5f  push r10
00007f0145bd3e61  push r11
00007f0145bd3e63  sub rsp, 0xF0
00007f0145bd3e6a  vmovaps [rsp], xmm0
00007f0145bd3e6f  vmovaps [rsp+0x10], xmm1
00007f0145bd3e75  vmovaps [rsp+0x20], xmm2
00007f0145bd3e7b  vmovaps [rsp+0x30], xmm3
00007f0145bd3e81  vmovaps [rsp+0x40], xmm4
00007f0145bd3e87  vmovaps [rsp+0x50], xmm5
00007f0145bd3e8d  vmovaps [rsp+0x60], xmm6
00007f0145bd3e93  vmovaps [rsp+0x70], xmm7
00007f0145bd3e99  vmovaps [rsp+0x80], xmm8
00007f0145bd3ea2  vmovaps [rsp+0x90], xmm9
00007f0145bd3eab  vmovaps [rsp+0xA0], xmm10
00007f0145bd3eb4  vmovaps [rsp+0xB0], xmm11
00007f0145bd3ebd  vmovaps [rsp+0xC0], xmm12
00007f0145bd3ec6  vmovaps [rsp+0xD0], xmm14
00007f0145bd3ecf  vmovaps [rsp+0xE0], xmm15
00007f0145bd3ed8  sub rsp, 0x30
00007f0145bd3edc  movaps [rsp], xmm13
00007f0145bd3ee1  movaps [rsp+0x10], xmm8
00007f0145bd3ee7  movaps [rsp+0x20], xmm14
00007f0145bd3eed  lea rdi, [rsp]
00007f0145bd3ef1  mov esi, 0x00
00007f0145bd3ef6  mov rax, 0x636570E98530
00007f0145bd3f00  call rax
00007f0145bd3f02  movaps xmm13, [rsp]
00007f0145bd3f07  add rsp, 0x30
00007f0145bd3f0b  vmovaps xmm0, [rsp]
00007f0145bd3f10  vmovaps xmm1, [rsp+0x10]
00007f0145bd3f16  vmovaps xmm2, [rsp+0x20]
00007f0145bd3f1c  vmovaps xmm3, [rsp+0x30]
00007f0145bd3f22  vmovaps xmm4, [rsp+0x40]
00007f0145bd3f28  vmovaps xmm5, [rsp+0x50]
00007f0145bd3f2e  vmovaps xmm6, [rsp+0x60]
00007f0145bd3f34  vmovaps xmm7, [rsp+0x70]
00007f0145bd3f3a  vmovaps xmm8, [rsp+0x80]
00007f0145bd3f43  vmovaps xmm9, [rsp+0x90]
00007f0145bd3f4c  vmovaps xmm10, [rsp+0xA0]
00007f0145bd3f55  vmovaps xmm11, [rsp+0xB0]
00007f0145bd3f5e  vmovaps xmm12, [rsp+0xC0]
00007f0145bd3f67  vmovaps xmm14, [rsp+0xD0]
00007f0145bd3f70  vmovaps xmm15, [rsp+0xE0]
00007f0145bd3f79  add rsp, 0xF0
00007f0145bd3f80  pop r11
00007f0145bd3f82  pop r10
00007f0145bd3f84  pop r9
00007f0145bd3f86  pop r8
00007f0145bd3f88  pop rsi
00007f0145bd3f89  pop rdi
00007f0145bd3f8a  pop rdx
00007f0145bd3f8b  pop rcx
00007f0145bd3f8c  pop rax
00007f0145bd3f8d  add rsp, 0x08
00007f0145bd3f91  jmp 0x00007F0145BD006E
00007f0145bd3f96  sub rsp, 0x08
00007f0145bd3f9a  push rax
00007f0145bd3f9b  push rcx
00007f0145bd3f9c  push rdx
00007f0145bd3f9d  push rdi
00007f0145bd3f9e  push rsi
00007f0145bd3f9f  push r8
00007f0145bd3fa1  push r9
00007f0145bd3fa3  push r10
00007f0145bd3fa5  push r11
00007f0145bd3fa7  sub rsp, 0xF0
00007f0145bd3fae  vmovaps [rsp], xmm0
00007f0145bd3fb3  vmovaps [rsp+0x10], xmm1
00007f0145bd3fb9  vmovaps [rsp+0x20], xmm2
00007f0145bd3fbf  vmovaps [rsp+0x30], xmm3
00007f0145bd3fc5  vmovaps [rsp+0x40], xmm4
00007f0145bd3fcb  vmovaps [rsp+0x50], xmm5
00007f0145bd3fd1  vmovaps [rsp+0x60], xmm6
00007f0145bd3fd7  vmovaps [rsp+0x70], xmm7
00007f0145bd3fdd  vmovaps [rsp+0x80], xmm9
00007f0145bd3fe6  vmovaps [rsp+0x90], xmm10
00007f0145bd3fef  vmovaps [rsp+0xA0], xmm11
00007f0145bd3ff8  vmovaps [rsp+0xB0], xmm12
00007f0145bd4001  vmovaps [rsp+0xC0], xmm13
00007f0145bd400a  vmovaps [rsp+0xD0], xmm14
00007f0145bd4013  vmovaps [rsp+0xE0], xmm15
00007f0145bd401c  sub rsp, 0x30
00007f0145bd4020  movaps [rsp], xmm8
00007f0145bd4025  movaps [rsp+0x10], xmm7
00007f0145bd402a  movaps [rsp+0x20], xmm14
00007f0145bd4030  lea rdi, [rsp]
00007f0145bd4034  mov esi, 0x00
00007f0145bd4039  mov rax, 0x636570E98530
00007f0145bd4043  call rax
00007f0145bd4045  movaps xmm8, [rsp]
00007f0145bd404a  add rsp, 0x30
00007f0145bd404e  vmovaps xmm0, [rsp]
00007f0145bd4053  vmovaps xmm1, [rsp+0x10]
00007f0145bd4059  vmovaps xmm2, [rsp+0x20]
00007f0145bd405f  vmovaps xmm3, [rsp+0x30]
00007f0145bd4065  vmovaps xmm4, [rsp+0x40]
00007f0145bd406b  vmovaps xmm5, [rsp+0x50]
00007f0145bd4071  vmovaps xmm6, [rsp+0x60]
00007f0145bd4077  vmovaps xmm7, [rsp+0x70]
00007f0145bd407d  vmovaps xmm9, [rsp+0x80]
00007f0145bd4086  vmovaps xmm10, [rsp+0x90]
00007f0145bd408f  vmovaps xmm11, [rsp+0xA0]
00007f0145bd4098  vmovaps xmm12, [rsp+0xB0]
00007f0145bd40a1  vmovaps xmm13, [rsp+0xC0]
00007f0145bd40aa  vmovaps xmm14, [rsp+0xD0]
00007f0145bd40b3  vmovaps xmm15, [rsp+0xE0]
00007f0145bd40bc  add rsp, 0xF0
00007f0145bd40c3  pop r11
00007f0145bd40c5  pop r10
00007f0145bd40c7  pop r9
00007f0145bd40c9  pop r8
00007f0145bd40cb  pop rsi
00007f0145bd40cc  pop rdi
00007f0145bd40cd  pop rdx
00007f0145bd40ce  pop rcx
00007f0145bd40cf  pop rax
00007f0145bd40d0  add rsp, 0x08
00007f0145bd40d4  jmp 0x00007F0145BD0094
00007f0145bd40d9  sub rsp, 0x08
00007f0145bd40dd  push rax
00007f0145bd40de  push rcx
00007f0145bd40df  push rdx
00007f0145bd40e0  push rdi
00007f0145bd40e1  push rsi
00007f0145bd40e2  push r8
00007f0145bd40e4  push r9
00007f0145bd40e6  push r10
00007f0145bd40e8  push r11
00007f0145bd40ea  sub rsp, 0xF0
00007f0145bd40f1  vmovaps [rsp], xmm0
00007f0145bd40f6  vmovaps [rsp+0x10], xmm1
00007f0145bd40fc  vmovaps [rsp+0x20], xmm2
00007f0145bd4102  vmovaps [rsp+0x30], xmm3
00007f0145bd4108  vmovaps [rsp+0x40], xmm4
00007f0145bd410e  vmovaps [rsp+0x50], xmm5
00007f0145bd4114  vmovaps [rsp+0x60], xmm6
00007f0145bd411a  vmovaps [rsp+0x70], xmm7
00007f0145bd4120  vmovaps [rsp+0x80], xmm8
00007f0145bd4129  vmovaps [rsp+0x90], xmm9
00007f0145bd4132  vmovaps [rsp+0xA0], xmm10
00007f0145bd413b  vmovaps [rsp+0xB0], xmm11
00007f0145bd4144  vmovaps [rsp+0xC0], xmm12
00007f0145bd414d  vmovaps [rsp+0xD0], xmm13
00007f0145bd4156  vmovaps [rsp+0xE0], xmm15
00007f0145bd415f  sub rsp, 0x30
00007f0145bd4163  movaps [rsp], xmm14
00007f0145bd4168  movaps [rsp+0x10], xmm12
00007f0145bd416e  movaps [rsp+0x20], xmm9
00007f0145bd4174  lea rdi, [rsp]
00007f0145bd4178  mov esi, 0x00
00007f0145bd417d  mov rax, 0x636570E98530
00007f0145bd4187  call rax
00007f0145bd4189  movaps xmm14, [rsp]
00007f0145bd418e  add rsp, 0x30
00007f0145bd4192  vmovaps xmm0, [rsp]
00007f0145bd4197  vmovaps xmm1, [rsp+0x10]
00007f0145bd419d  vmovaps xmm2, [rsp+0x20]
00007f0145bd41a3  vmovaps xmm3, [rsp+0x30]
00007f0145bd41a9  vmovaps xmm4, [rsp+0x40]
00007f0145bd41af  vmovaps xmm5, [rsp+0x50]
00007f0145bd41b5  vmovaps xmm6, [rsp+0x60]
00007f0145bd41bb  vmovaps xmm7, [rsp+0x70]
00007f0145bd41c1  vmovaps xmm8, [rsp+0x80]
00007f0145bd41ca  vmovaps xmm9, [rsp+0x90]
00007f0145bd41d3  vmovaps xmm10, [rsp+0xA0]
00007f0145bd41dc  vmovaps xmm11, [rsp+0xB0]
00007f0145bd41e5  vmovaps xmm12, [rsp+0xC0]
00007f0145bd41ee  vmovaps xmm13, [rsp+0xD0]
00007f0145bd41f7  vmovaps xmm15, [rsp+0xE0]
00007f0145bd4200  add rsp, 0xF0
00007f0145bd4207  pop r11
00007f0145bd4209  pop r10
00007f0145bd420b  pop r9
00007f0145bd420d  pop r8
00007f0145bd420f  pop rsi
00007f0145bd4210  pop rdi
00007f0145bd4211  pop rdx
00007f0145bd4212  pop rcx
00007f0145bd4213  pop rax
00007f0145bd4214  add rsp, 0x08
00007f0145bd4218  jmp 0x00007F0145BD00AE
00007f0145bd421d  sub rsp, 0x08
00007f0145bd4221  push rax
00007f0145bd4222  push rcx
00007f0145bd4223  push rdx
00007f0145bd4224  push rdi
00007f0145bd4225  push rsi
00007f0145bd4226  push r8
00007f0145bd4228  push r9
00007f0145bd422a  push r10
00007f0145bd422c  push r11
00007f0145bd422e  sub rsp, 0xF0
00007f0145bd4235  vmovaps [rsp], xmm0
00007f0145bd423a  vmovaps [rsp+0x10], xmm1
00007f0145bd4240  vmovaps [rsp+0x20], xmm2
00007f0145bd4246  vmovaps [rsp+0x30], xmm3
00007f0145bd424c  vmovaps [rsp+0x40], xmm4
00007f0145bd4252  vmovaps [rsp+0x50], xmm5
00007f0145bd4258  vmovaps [rsp+0x60], xmm6
00007f0145bd425e  vmovaps [rsp+0x70], xmm7
00007f0145bd4264  vmovaps [rsp+0x80], xmm8
00007f0145bd426d  vmovaps [rsp+0x90], xmm10
00007f0145bd4276  vmovaps [rsp+0xA0], xmm11
00007f0145bd427f  vmovaps [rsp+0xB0], xmm12
00007f0145bd4288  vmovaps [rsp+0xC0], xmm13
00007f0145bd4291  vmovaps [rsp+0xD0], xmm14
00007f0145bd429a  vmovaps [rsp+0xE0], xmm15
00007f0145bd42a3  sub rsp, 0x30
00007f0145bd42a7  movaps [rsp], xmm9
00007f0145bd42ac  movaps [rsp+0x10], xmm7
00007f0145bd42b1  movaps [rsp+0x20], xmm12
00007f0145bd42b7  lea rdi, [rsp]
00007f0145bd42bb  mov esi, 0x00
00007f0145bd42c0  mov rax, 0x636570E98530
00007f0145bd42ca  call rax
00007f0145bd42cc  movaps xmm9, [rsp]
00007f0145bd42d1  add rsp, 0x30
00007f0145bd42d5  vmovaps xmm0, [rsp]
00007f0145bd42da  vmovaps xmm1, [rsp+0x10]
00007f0145bd42e0  vmovaps xmm2, [rsp+0x20]
00007f0145bd42e6  vmovaps xmm3, [rsp+0x30]
00007f0145bd42ec  vmovaps xmm4, [rsp+0x40]
00007f0145bd42f2  vmovaps xmm5, [rsp+0x50]
00007f0145bd42f8  vmovaps xmm6, [rsp+0x60]
00007f0145bd42fe  vmovaps xmm7, [rsp+0x70]
00007f0145bd4304  vmovaps xmm8, [rsp+0x80]
00007f0145bd430d  vmovaps xmm10, [rsp+0x90]
00007f0145bd4316  vmovaps xmm11, [rsp+0xA0]
00007f0145bd431f  vmovaps xmm12, [rsp+0xB0]
00007f0145bd4328  vmovaps xmm13, [rsp+0xC0]
00007f0145bd4331  vmovaps xmm14, [rsp+0xD0]
00007f0145bd433a  vmovaps xmm15, [rsp+0xE0]
00007f0145bd4343  add rsp, 0xF0
00007f0145bd434a  pop r11
00007f0145bd434c  pop r10
00007f0145bd434e  pop r9
00007f0145bd4350  pop r8
00007f0145bd4352  pop rsi
00007f0145bd4353  pop rdi
00007f0145bd4354  pop rdx
00007f0145bd4355  pop rcx
00007f0145bd4356  pop rax
00007f0145bd4357  add rsp, 0x08
00007f0145bd435b  jmp 0x00007F0145BD00DD
00007f0145bd4360  sub rsp, 0x08
00007f0145bd4364  push rax
00007f0145bd4365  push rcx
00007f0145bd4366  push rdx
00007f0145bd4367  push rdi
00007f0145bd4368  push rsi
00007f0145bd4369  push r8
00007f0145bd436b  push r9
00007f0145bd436d  push r10
00007f0145bd436f  push r11
00007f0145bd4371  sub rsp, 0xF0
00007f0145bd4378  vmovaps [rsp], xmm0
00007f0145bd437d  vmovaps [rsp+0x10], xmm1
00007f0145bd4383  vmovaps [rsp+0x20], xmm2
00007f0145bd4389  vmovaps [rsp+0x30], xmm3
00007f0145bd438f  vmovaps [rsp+0x40], xmm4
00007f0145bd4395  vmovaps [rsp+0x50], xmm5
00007f0145bd439b  vmovaps [rsp+0x60], xmm6
00007f0145bd43a1  vmovaps [rsp+0x70], xmm7
00007f0145bd43a7  vmovaps [rsp+0x80], xmm8
00007f0145bd43b0  vmovaps [rsp+0x90], xmm9
00007f0145bd43b9  vmovaps [rsp+0xA0], xmm10
00007f0145bd43c2  vmovaps [rsp+0xB0], xmm11
00007f0145bd43cb  vmovaps [rsp+0xC0], xmm13
00007f0145bd43d4  vmovaps [rsp+0xD0], xmm14
00007f0145bd43dd  vmovaps [rsp+0xE0], xmm15
00007f0145bd43e6  sub rsp, 0x30
00007f0145bd43ea  movaps [rsp], xmm12
00007f0145bd43ef  movaps [rsp+0x10], xmm15
00007f0145bd43f5  movaps [rsp+0x20], xmm11
00007f0145bd43fb  lea rdi, [rsp]
00007f0145bd43ff  mov esi, 0x00
00007f0145bd4404  mov rax, 0x636570E98530
00007f0145bd440e  call rax
00007f0145bd4410  movaps xmm12, [rsp]
00007f0145bd4415  add rsp, 0x30
00007f0145bd4419  vmovaps xmm0, [rsp]
00007f0145bd441e  vmovaps xmm1, [rsp+0x10]
00007f0145bd4424  vmovaps xmm2, [rsp+0x20]
00007f0145bd442a  vmovaps xmm3, [rsp+0x30]
00007f0145bd4430  vmovaps xmm4, [rsp+0x40]
00007f0145bd4436  vmovaps xmm5, [rsp+0x50]
00007f0145bd443c  vmovaps xmm6, [rsp+0x60]
00007f0145bd4442  vmovaps xmm7, [rsp+0x70]
00007f0145bd4448  vmovaps xmm8, [rsp+0x80]
00007f0145bd4451  vmovaps xmm9, [rsp+0x90]
00007f0145bd445a  vmovaps xmm10, [rsp+0xA0]
00007f0145bd4463  vmovaps xmm11, [rsp+0xB0]
00007f0145bd446c  vmovaps xmm13, [rsp+0xC0]
00007f0145bd4475  vmovaps xmm14, [rsp+0xD0]
00007f0145bd447e  vmovaps xmm15, [rsp+0xE0]
00007f0145bd4487  add rsp, 0xF0
00007f0145bd448e  pop r11
00007f0145bd4490  pop r10
00007f0145bd4492  pop r9
00007f0145bd4494  pop r8
00007f0145bd4496  pop rsi
00007f0145bd4497  pop rdi
00007f0145bd4498  pop rdx
00007f0145bd4499  pop rcx
00007f0145bd449a  pop rax
00007f0145bd449b  add rsp, 0x08
00007f0145bd449f  jmp 0x00007F0145BD00F7
00007f0145bd44a4  sub rsp, 0x08
00007f0145bd44a8  push rax
00007f0145bd44a9  push rcx
00007f0145bd44aa  push rdx
00007f0145bd44ab  push rdi
00007f0145bd44ac  push rsi
00007f0145bd44ad  push r8
00007f0145bd44af  push r9
00007f0145bd44b1  push r10
00007f0145bd44b3  push r11
00007f0145bd44b5  sub rsp, 0xF0
00007f0145bd44bc  vmovaps [rsp], xmm0
00007f0145bd44c1  vmovaps [rsp+0x10], xmm1
00007f0145bd44c7  vmovaps [rsp+0x20], xmm2
00007f0145bd44cd  vmovaps [rsp+0x30], xmm3
00007f0145bd44d3  vmovaps [rsp+0x40], xmm4
00007f0145bd44d9  vmovaps [rsp+0x50], xmm5
00007f0145bd44df  vmovaps [rsp+0x60], xmm6
00007f0145bd44e5  vmovaps [rsp+0x70], xmm7
00007f0145bd44eb  vmovaps [rsp+0x80], xmm8
00007f0145bd44f4  vmovaps [rsp+0x90], xmm9
00007f0145bd44fd  vmovaps [rsp+0xA0], xmm10
00007f0145bd4506  vmovaps [rsp+0xB0], xmm12
00007f0145bd450f  vmovaps [rsp+0xC0], xmm13
00007f0145bd4518  vmovaps [rsp+0xD0], xmm14
00007f0145bd4521  vmovaps [rsp+0xE0], xmm15
00007f0145bd452a  sub rsp, 0x30
00007f0145bd452e  movaps [rsp], xmm11
00007f0145bd4533  movaps [rsp+0x10], xmm7
00007f0145bd4538  movaps [rsp+0x20], xmm15
00007f0145bd453e  lea rdi, [rsp]
00007f0145bd4542  mov esi, 0x00
00007f0145bd4547  mov rax, 0x636570E98530
00007f0145bd4551  call rax
00007f0145bd4553  movaps xmm11, [rsp]
00007f0145bd4558  add rsp, 0x30
00007f0145bd455c  vmovaps xmm0, [rsp]
00007f0145bd4561  vmovaps xmm1, [rsp+0x10]
00007f0145bd4567  vmovaps xmm2, [rsp+0x20]
00007f0145bd456d  vmovaps xmm3, [rsp+0x30]
00007f0145bd4573  vmovaps xmm4, [rsp+0x40]
00007f0145bd4579  vmovaps xmm5, [rsp+0x50]
00007f0145bd457f  vmovaps xmm6, [rsp+0x60]
00007f0145bd4585  vmovaps xmm7, [rsp+0x70]
00007f0145bd458b  vmovaps xmm8, [rsp+0x80]
00007f0145bd4594  vmovaps xmm9, [rsp+0x90]
00007f0145bd459d  vmovaps xmm10, [rsp+0xA0]
00007f0145bd45a6  vmovaps xmm12, [rsp+0xB0]
00007f0145bd45af  vmovaps xmm13, [rsp+0xC0]
00007f0145bd45b8  vmovaps xmm14, [rsp+0xD0]
00007f0145bd45c1  vmovaps xmm15, [rsp+0xE0]
00007f0145bd45ca  add rsp, 0xF0
00007f0145bd45d1  pop r11
00007f0145bd45d3  pop r10
00007f0145bd45d5  pop r9
00007f0145bd45d7  pop r8
00007f0145bd45d9  pop rsi
00007f0145bd45da  pop rdi
00007f0145bd45db  pop rdx
00007f0145bd45dc  pop rcx
00007f0145bd45dd  pop rax
00007f0145bd45de  add rsp, 0x08
00007f0145bd45e2  jmp 0x00007F0145BD0123
00007f0145bd45e7  sub rsp, 0x08
00007f0145bd45eb  push rax
00007f0145bd45ec  push rcx
00007f0145bd45ed  push rdx
00007f0145bd45ee  push rdi
00007f0145bd45ef  push rsi
00007f0145bd45f0  push r8
00007f0145bd45f2  push r9
00007f0145bd45f4  push r10
00007f0145bd45f6  push r11
00007f0145bd45f8  sub rsp, 0xF0
00007f0145bd45ff  vmovaps [rsp], xmm0
00007f0145bd4604  vmovaps [rsp+0x10], xmm1
00007f0145bd460a  vmovaps [rsp+0x20], xmm2
00007f0145bd4610  vmovaps [rsp+0x30], xmm3
00007f0145bd4616  vmovaps [rsp+0x40], xmm4
00007f0145bd461c  vmovaps [rsp+0x50], xmm5
00007f0145bd4622  vmovaps [rsp+0x60], xmm6
00007f0145bd4628  vmovaps [rsp+0x70], xmm7
00007f0145bd462e  vmovaps [rsp+0x80], xmm8
00007f0145bd4637  vmovaps [rsp+0x90], xmm9
00007f0145bd4640  vmovaps [rsp+0xA0], xmm10
00007f0145bd4649  vmovaps [rsp+0xB0], xmm11
00007f0145bd4652  vmovaps [rsp+0xC0], xmm12
00007f0145bd465b  vmovaps [rsp+0xD0], xmm13
00007f0145bd4664  vmovaps [rsp+0xE0], xmm14
00007f0145bd466d  sub rsp, 0x30
00007f0145bd4671  movaps [rsp], xmm15
00007f0145bd4676  movaps [rsp+0x10], xmm10
00007f0145bd467c  movaps [rsp+0x20], xmm13
00007f0145bd4682  lea rdi, [rsp]
00007f0145bd4686  mov esi, 0x00
00007f0145bd468b  mov rax, 0x636570E98530
00007f0145bd4695  call rax
00007f0145bd4697  movaps xmm15, [rsp]
00007f0145bd469c  add rsp, 0x30
00007f0145bd46a0  vmovaps xmm0, [rsp]
00007f0145bd46a5  vmovaps xmm1, [rsp+0x10]
00007f0145bd46ab  vmovaps xmm2, [rsp+0x20]
00007f0145bd46b1  vmovaps xmm3, [rsp+0x30]
00007f0145bd46b7  vmovaps xmm4, [rsp+0x40]
00007f0145bd46bd  vmovaps xmm5, [rsp+0x50]
00007f0145bd46c3  vmovaps xmm6, [rsp+0x60]
00007f0145bd46c9  vmovaps xmm7, [rsp+0x70]
00007f0145bd46cf  vmovaps xmm8, [rsp+0x80]
00007f0145bd46d8  vmovaps xmm9, [rsp+0x90]
00007f0145bd46e1  vmovaps xmm10, [rsp+0xA0]
00007f0145bd46ea  vmovaps xmm11, [rsp+0xB0]
00007f0145bd46f3  vmovaps xmm12, [rsp+0xC0]
00007f0145bd46fc  vmovaps xmm13, [rsp+0xD0]
00007f0145bd4705  vmovaps xmm14, [rsp+0xE0]
00007f0145bd470e  add rsp, 0xF0
00007f0145bd4715  pop r11
00007f0145bd4717  pop r10
00007f0145bd4719  pop r9
00007f0145bd471b  pop r8
00007f0145bd471d  pop rsi
00007f0145bd471e  pop rdi
00007f0145bd471f  pop rdx
00007f0145bd4720  pop rcx
00007f0145bd4721  pop rax
00007f0145bd4722  add rsp, 0x08
00007f0145bd4726  jmp 0x00007F0145BD013D
00007f0145bd472b  sub rsp, 0x08
00007f0145bd472f  push rax
00007f0145bd4730  push rcx
00007f0145bd4731  push rdx
00007f0145bd4732  push rdi
00007f0145bd4733  push rsi
00007f0145bd4734  push r8
00007f0145bd4736  push r9
00007f0145bd4738  push r10
00007f0145bd473a  push r11
00007f0145bd473c  sub rsp, 0xF0
00007f0145bd4743  vmovaps [rsp], xmm0
00007f0145bd4748  vmovaps [rsp+0x10], xmm1
00007f0145bd474e  vmovaps [rsp+0x20], xmm2
00007f0145bd4754  vmovaps [rsp+0x30], xmm3
00007f0145bd475a  vmovaps [rsp+0x40], xmm4
00007f0145bd4760  vmovaps [rsp+0x50], xmm5
00007f0145bd4766  vmovaps [rsp+0x60], xmm6
00007f0145bd476c  vmovaps [rsp+0x70], xmm7
00007f0145bd4772  vmovaps [rsp+0x80], xmm8
00007f0145bd477b  vmovaps [rsp+0x90], xmm9
00007f0145bd4784  vmovaps [rsp+0xA0], xmm11
00007f0145bd478d  vmovaps [rsp+0xB0], xmm12
00007f0145bd4796  vmovaps [rsp+0xC0], xmm13
00007f0145bd479f  vmovaps [rsp+0xD0], xmm14
00007f0145bd47a8  vmovaps [rsp+0xE0], xmm15
00007f0145bd47b1  sub rsp, 0x30
00007f0145bd47b5  movaps [rsp], xmm10
00007f0145bd47ba  movaps [rsp+0x10], xmm7
00007f0145bd47bf  movaps [rsp+0x20], xmm13
00007f0145bd47c5  lea rdi, [rsp]
00007f0145bd47c9  mov esi, 0x00
00007f0145bd47ce  mov rax, 0x636570E98530
00007f0145bd47d8  call rax
00007f0145bd47da  movaps xmm10, [rsp]
00007f0145bd47df  add rsp, 0x30
00007f0145bd47e3  vmovaps xmm0, [rsp]
00007f0145bd47e8  vmovaps xmm1, [rsp+0x10]
00007f0145bd47ee  vmovaps xmm2, [rsp+0x20]
00007f0145bd47f4  vmovaps xmm3, [rsp+0x30]
00007f0145bd47fa  vmovaps xmm4, [rsp+0x40]
00007f0145bd4800  vmovaps xmm5, [rsp+0x50]
00007f0145bd4806  vmovaps xmm6, [rsp+0x60]
00007f0145bd480c  vmovaps xmm7, [rsp+0x70]
00007f0145bd4812  vmovaps xmm8, [rsp+0x80]
00007f0145bd481b  vmovaps xmm9, [rsp+0x90]
00007f0145bd4824  vmovaps xmm11, [rsp+0xA0]
00007f0145bd482d  vmovaps xmm12, [rsp+0xB0]
00007f0145bd4836  vmovaps xmm13, [rsp+0xC0]
00007f0145bd483f  vmovaps xmm14, [rsp+0xD0]
00007f0145bd4848  vmovaps xmm15, [rsp+0xE0]
00007f0145bd4851  add rsp, 0xF0
00007f0145bd4858  pop r11
00007f0145bd485a  pop r10
00007f0145bd485c  pop r9
00007f0145bd485e  pop r8
00007f0145bd4860  pop rsi
00007f0145bd4861  pop rdi
00007f0145bd4862  pop rdx
00007f0145bd4863  pop rcx
00007f0145bd4864  pop rax
00007f0145bd4865  add rsp, 0x08
00007f0145bd4869  jmp 0x00007F0145BD0169
00007f0145bd486e  sub rsp, 0x08
00007f0145bd4872  push rax
00007f0145bd4873  push rcx
00007f0145bd4874  push rdx
00007f0145bd4875  push rdi
00007f0145bd4876  push rsi
00007f0145bd4877  push r8
00007f0145bd4879  push r9
00007f0145bd487b  push r10
00007f0145bd487d  push r11
00007f0145bd487f  sub rsp, 0xF0
00007f0145bd4886  vmovaps [rsp], xmm0
00007f0145bd488b  vmovaps [rsp+0x10], xmm1
00007f0145bd4891  vmovaps [rsp+0x20], xmm2
00007f0145bd4897  vmovaps [rsp+0x30], xmm3
00007f0145bd489d  vmovaps [rsp+0x40], xmm4
00007f0145bd48a3  vmovaps [rsp+0x50], xmm5
00007f0145bd48a9  vmovaps [rsp+0x60], xmm6
00007f0145bd48af  vmovaps [rsp+0x70], xmm7
00007f0145bd48b5  vmovaps [rsp+0x80], xmm8
00007f0145bd48be  vmovaps [rsp+0x90], xmm9
00007f0145bd48c7  vmovaps [rsp+0xA0], xmm10
00007f0145bd48d0  vmovaps [rsp+0xB0], xmm11
00007f0145bd48d9  vmovaps [rsp+0xC0], xmm12
00007f0145bd48e2  vmovaps [rsp+0xD0], xmm14
00007f0145bd48eb  vmovaps [rsp+0xE0], xmm15
00007f0145bd48f4  sub rsp, 0x30
00007f0145bd48f8  movaps [rsp], xmm13
00007f0145bd48fd  movaps [rsp+0x10], xmm1
00007f0145bd4902  movaps [rsp+0x20], xmm8
00007f0145bd4908  lea rdi, [rsp]
00007f0145bd490c  mov esi, 0x00
00007f0145bd4911  mov rax, 0x636570E98530
00007f0145bd491b  call rax
00007f0145bd491d  movaps xmm13, [rsp]
00007f0145bd4922  add rsp, 0x30
00007f0145bd4926  vmovaps xmm0, [rsp]
00007f0145bd492b  vmovaps xmm1, [rsp+0x10]
00007f0145bd4931  vmovaps xmm2, [rsp+0x20]
00007f0145bd4937  vmovaps xmm3, [rsp+0x30]
00007f0145bd493d  vmovaps xmm4, [rsp+0x40]
00007f0145bd4943  vmovaps xmm5, [rsp+0x50]
00007f0145bd4949  vmovaps xmm6, [rsp+0x60]
00007f0145bd494f  vmovaps xmm7, [rsp+0x70]
00007f0145bd4955  vmovaps xmm8, [rsp+0x80]
00007f0145bd495e  vmovaps xmm9, [rsp+0x90]
00007f0145bd4967  vmovaps xmm10, [rsp+0xA0]
00007f0145bd4970  vmovaps xmm11, [rsp+0xB0]
00007f0145bd4979  vmovaps xmm12, [rsp+0xC0]
00007f0145bd4982  vmovaps xmm14, [rsp+0xD0]
00007f0145bd498b  vmovaps xmm15, [rsp+0xE0]
00007f0145bd4994  add rsp, 0xF0
00007f0145bd499b  pop r11
00007f0145bd499d  pop r10
00007f0145bd499f  pop r9
00007f0145bd49a1  pop r8
00007f0145bd49a3  pop rsi
00007f0145bd49a4  pop rdi
00007f0145bd49a5  pop rdx
00007f0145bd49a6  pop rcx
00007f0145bd49a7  pop rax
00007f0145bd49a8  add rsp, 0x08
00007f0145bd49ac  jmp 0x00007F0145BD0183
00007f0145bd49b1  call 0x00007F01459FF430
00007f0145bd49b6  jmp 0x00007F0145BD018D
00007f0145bd49bb  sub rsp, 0x08
00007f0145bd49bf  push rax
00007f0145bd49c0  push rcx
00007f0145bd49c1  push rdx
00007f0145bd49c2  push rdi
00007f0145bd49c3  push rsi
00007f0145bd49c4  push r8
00007f0145bd49c6  push r9
00007f0145bd49c8  push r10
00007f0145bd49ca  push r11
00007f0145bd49cc  sub rsp, 0xF0
00007f0145bd49d3  vmovaps [rsp], xmm0
00007f0145bd49d8  vmovaps [rsp+0x10], xmm1
00007f0145bd49de  vmovaps [rsp+0x20], xmm2
00007f0145bd49e4  vmovaps [rsp+0x30], xmm3
00007f0145bd49ea  vmovaps [rsp+0x40], xmm4
00007f0145bd49f0  vmovaps [rsp+0x50], xmm5
00007f0145bd49f6  vmovaps [rsp+0x60], xmm6
00007f0145bd49fc  vmovaps [rsp+0x70], xmm7
00007f0145bd4a02  vmovaps [rsp+0x80], xmm9
00007f0145bd4a0b  vmovaps [rsp+0x90], xmm10
00007f0145bd4a14  vmovaps [rsp+0xA0], xmm11
00007f0145bd4a1d  vmovaps [rsp+0xB0], xmm12
00007f0145bd4a26  vmovaps [rsp+0xC0], xmm13
00007f0145bd4a2f  vmovaps [rsp+0xD0], xmm14
00007f0145bd4a38  vmovaps [rsp+0xE0], xmm15
00007f0145bd4a41  sub rsp, 0x30
00007f0145bd4a45  movaps [rsp], xmm8
00007f0145bd4a4a  movaps [rsp+0x10], xmm14
00007f0145bd4a50  movaps [rsp+0x20], xmm9
00007f0145bd4a56  lea rdi, [rsp]
00007f0145bd4a5a  mov esi, 0x00
00007f0145bd4a5f  mov rax, 0x636570E98530
00007f0145bd4a69  call rax
00007f0145bd4a6b  movaps xmm8, [rsp]
00007f0145bd4a70  add rsp, 0x30
00007f0145bd4a74  vmovaps xmm0, [rsp]
00007f0145bd4a79  vmovaps xmm1, [rsp+0x10]
00007f0145bd4a7f  vmovaps xmm2, [rsp+0x20]
00007f0145bd4a85  vmovaps xmm3, [rsp+0x30]
00007f0145bd4a8b  vmovaps xmm4, [rsp+0x40]
00007f0145bd4a91  vmovaps xmm5, [rsp+0x50]
00007f0145bd4a97  vmovaps xmm6, [rsp+0x60]
00007f0145bd4a9d  vmovaps xmm7, [rsp+0x70]
00007f0145bd4aa3  vmovaps xmm9, [rsp+0x80]
00007f0145bd4aac  vmovaps xmm10, [rsp+0x90]
00007f0145bd4ab5  vmovaps xmm11, [rsp+0xA0]
00007f0145bd4abe  vmovaps xmm12, [rsp+0xB0]
00007f0145bd4ac7  vmovaps xmm13, [rsp+0xC0]
00007f0145bd4ad0  vmovaps xmm14, [rsp+0xD0]
00007f0145bd4ad9  vmovaps xmm15, [rsp+0xE0]
00007f0145bd4ae2  add rsp, 0xF0
00007f0145bd4ae9  pop r11
00007f0145bd4aeb  pop r10
00007f0145bd4aed  pop r9
00007f0145bd4aef  pop r8
00007f0145bd4af1  pop rsi
00007f0145bd4af2  pop rdi
00007f0145bd4af3  pop rdx
00007f0145bd4af4  pop rcx
00007f0145bd4af5  pop rax
00007f0145bd4af6  add rsp, 0x08
00007f0145bd4afa  jmp 0x00007F0145BD01AF
00007f0145bd4aff  sub rsp, 0x08
00007f0145bd4b03  push rax
00007f0145bd4b04  push rcx
00007f0145bd4b05  push rdx
00007f0145bd4b06  push rdi
00007f0145bd4b07  push rsi
00007f0145bd4b08  push r8
00007f0145bd4b0a  push r9
00007f0145bd4b0c  push r10
00007f0145bd4b0e  push r11
00007f0145bd4b10  sub rsp, 0xF0
00007f0145bd4b17  vmovaps [rsp], xmm0
00007f0145bd4b1c  vmovaps [rsp+0x10], xmm1
00007f0145bd4b22  vmovaps [rsp+0x20], xmm2
00007f0145bd4b28  vmovaps [rsp+0x30], xmm3
00007f0145bd4b2e  vmovaps [rsp+0x40], xmm4
00007f0145bd4b34  vmovaps [rsp+0x50], xmm5
00007f0145bd4b3a  vmovaps [rsp+0x60], xmm6
00007f0145bd4b40  vmovaps [rsp+0x70], xmm7
00007f0145bd4b46  vmovaps [rsp+0x80], xmm8
00007f0145bd4b4f  vmovaps [rsp+0x90], xmm10
00007f0145bd4b58  vmovaps [rsp+0xA0], xmm11
00007f0145bd4b61  vmovaps [rsp+0xB0], xmm12
00007f0145bd4b6a  vmovaps [rsp+0xC0], xmm13
00007f0145bd4b73  vmovaps [rsp+0xD0], xmm14
00007f0145bd4b7c  vmovaps [rsp+0xE0], xmm15
00007f0145bd4b85  sub rsp, 0x30
00007f0145bd4b89  movaps [rsp], xmm9
00007f0145bd4b8e  movaps [rsp+0x10], xmm1
00007f0145bd4b93  movaps [rsp+0x20], xmm14
00007f0145bd4b99  lea rdi, [rsp]
00007f0145bd4b9d  mov esi, 0x00
00007f0145bd4ba2  mov rax, 0x636570E98530
00007f0145bd4bac  call rax
00007f0145bd4bae  movaps xmm9, [rsp]
00007f0145bd4bb3  add rsp, 0x30
00007f0145bd4bb7  vmovaps xmm0, [rsp]
00007f0145bd4bbc  vmovaps xmm1, [rsp+0x10]
00007f0145bd4bc2  vmovaps xmm2, [rsp+0x20]
00007f0145bd4bc8  vmovaps xmm3, [rsp+0x30]
00007f0145bd4bce  vmovaps xmm4, [rsp+0x40]
00007f0145bd4bd4  vmovaps xmm5, [rsp+0x50]
00007f0145bd4bda  vmovaps xmm6, [rsp+0x60]
00007f0145bd4be0  vmovaps xmm7, [rsp+0x70]
00007f0145bd4be6  vmovaps xmm8, [rsp+0x80]
00007f0145bd4bef  vmovaps xmm10, [rsp+0x90]
00007f0145bd4bf8  vmovaps xmm11, [rsp+0xA0]
00007f0145bd4c01  vmovaps xmm12, [rsp+0xB0]
00007f0145bd4c0a  vmovaps xmm13, [rsp+0xC0]
00007f0145bd4c13  vmovaps xmm14, [rsp+0xD0]
00007f0145bd4c1c  vmovaps xmm15, [rsp+0xE0]
00007f0145bd4c25  add rsp, 0xF0
00007f0145bd4c2c  pop r11
00007f0145bd4c2e  pop r10
00007f0145bd4c30  pop r9
00007f0145bd4c32  pop r8
00007f0145bd4c34  pop rsi
00007f0145bd4c35  pop rdi
00007f0145bd4c36  pop rdx
00007f0145bd4c37  pop rcx
00007f0145bd4c38  pop rax
00007f0145bd4c39  add rsp, 0x08
00007f0145bd4c3d  jmp 0x00007F0145BD01DD
00007f0145bd4c42  sub rsp, 0x08
00007f0145bd4c46  push rax
00007f0145bd4c47  push rcx
00007f0145bd4c48  push rdx
00007f0145bd4c49  push rdi
00007f0145bd4c4a  push rsi
00007f0145bd4c4b  push r8
00007f0145bd4c4d  push r9
00007f0145bd4c4f  push r10
00007f0145bd4c51  push r11
00007f0145bd4c53  sub rsp, 0xF0
00007f0145bd4c5a  vmovaps [rsp], xmm0
00007f0145bd4c5f  vmovaps [rsp+0x10], xmm1
00007f0145bd4c65  vmovaps [rsp+0x20], xmm2
00007f0145bd4c6b  vmovaps [rsp+0x30], xmm3
00007f0145bd4c71  vmovaps [rsp+0x40], xmm4
00007f0145bd4c77  vmovaps [rsp+0x50], xmm5
00007f0145bd4c7d  vmovaps [rsp+0x60], xmm6
00007f0145bd4c83  vmovaps [rsp+0x70], xmm7
00007f0145bd4c89  vmovaps [rsp+0x80], xmm8
00007f0145bd4c92  vmovaps [rsp+0x90], xmm9
00007f0145bd4c9b  vmovaps [rsp+0xA0], xmm10
00007f0145bd4ca4  vmovaps [rsp+0xB0], xmm11
00007f0145bd4cad  vmovaps [rsp+0xC0], xmm12
00007f0145bd4cb6  vmovaps [rsp+0xD0], xmm13
00007f0145bd4cbf  vmovaps [rsp+0xE0], xmm15
00007f0145bd4cc8  sub rsp, 0x30
00007f0145bd4ccc  movaps [rsp], xmm14
00007f0145bd4cd1  movaps [rsp+0x10], xmm4
00007f0145bd4cd6  movaps [rsp+0x20], xmm1
00007f0145bd4cdb  lea rdi, [rsp]
00007f0145bd4cdf  mov esi, 0x00
00007f0145bd4ce4  mov rax, 0x636570E98530
00007f0145bd4cee  call rax
00007f0145bd4cf0  movaps xmm14, [rsp]
00007f0145bd4cf5  add rsp, 0x30
00007f0145bd4cf9  vmovaps xmm0, [rsp]
00007f0145bd4cfe  vmovaps xmm1, [rsp+0x10]
00007f0145bd4d04  vmovaps xmm2, [rsp+0x20]
00007f0145bd4d0a  vmovaps xmm3, [rsp+0x30]
00007f0145bd4d10  vmovaps xmm4, [rsp+0x40]
00007f0145bd4d16  vmovaps xmm5, [rsp+0x50]
00007f0145bd4d1c  vmovaps xmm6, [rsp+0x60]
00007f0145bd4d22  vmovaps xmm7, [rsp+0x70]
00007f0145bd4d28  vmovaps xmm8, [rsp+0x80]
00007f0145bd4d31  vmovaps xmm9, [rsp+0x90]
00007f0145bd4d3a  vmovaps xmm10, [rsp+0xA0]
00007f0145bd4d43  vmovaps xmm11, [rsp+0xB0]
00007f0145bd4d4c  vmovaps xmm12, [rsp+0xC0]
00007f0145bd4d55  vmovaps xmm13, [rsp+0xD0]
00007f0145bd4d5e  vmovaps xmm15, [rsp+0xE0]
00007f0145bd4d67  add rsp, 0xF0
00007f0145bd4d6e  pop r11
00007f0145bd4d70  pop r10
00007f0145bd4d72  pop r9
00007f0145bd4d74  pop r8
00007f0145bd4d76  pop rsi
00007f0145bd4d77  pop rdi
00007f0145bd4d78  pop rdx
00007f0145bd4d79  pop rcx
00007f0145bd4d7a  pop rax
00007f0145bd4d7b  add rsp, 0x08
00007f0145bd4d7f  jmp 0x00007F0145BD0203
00007f0145bd4d84  sub rsp, 0x08
00007f0145bd4d88  push rax
00007f0145bd4d89  push rcx
00007f0145bd4d8a  push rdx
00007f0145bd4d8b  push rdi
00007f0145bd4d8c  push rsi
00007f0145bd4d8d  push r8
00007f0145bd4d8f  push r9
00007f0145bd4d91  push r10
00007f0145bd4d93  push r11
00007f0145bd4d95  sub rsp, 0xF0
00007f0145bd4d9c  vmovaps [rsp], xmm0
00007f0145bd4da1  vmovaps [rsp+0x10], xmm2
00007f0145bd4da7  vmovaps [rsp+0x20], xmm3
00007f0145bd4dad  vmovaps [rsp+0x30], xmm4
00007f0145bd4db3  vmovaps [rsp+0x40], xmm5
00007f0145bd4db9  vmovaps [rsp+0x50], xmm6
00007f0145bd4dbf  vmovaps [rsp+0x60], xmm7
00007f0145bd4dc5  vmovaps [rsp+0x70], xmm8
00007f0145bd4dcb  vmovaps [rsp+0x80], xmm9
00007f0145bd4dd4  vmovaps [rsp+0x90], xmm10
00007f0145bd4ddd  vmovaps [rsp+0xA0], xmm11
00007f0145bd4de6  vmovaps [rsp+0xB0], xmm12
00007f0145bd4def  vmovaps [rsp+0xC0], xmm13
00007f0145bd4df8  vmovaps [rsp+0xD0], xmm14
00007f0145bd4e01  vmovaps [rsp+0xE0], xmm15
00007f0145bd4e0a  sub rsp, 0x30
00007f0145bd4e0e  movaps [rsp], xmm1
00007f0145bd4e12  movaps [rsp+0x10], xmm12
00007f0145bd4e18  movaps [rsp+0x20], xmm11
00007f0145bd4e1e  lea rdi, [rsp]
00007f0145bd4e22  mov esi, 0x00
00007f0145bd4e27  mov rax, 0x636570E98530
00007f0145bd4e31  call rax
00007f0145bd4e33  movaps xmm1, [rsp]
00007f0145bd4e37  add rsp, 0x30
00007f0145bd4e3b  vmovaps xmm0, [rsp]
00007f0145bd4e40  vmovaps xmm2, [rsp+0x10]
00007f0145bd4e46  vmovaps xmm3, [rsp+0x20]
00007f0145bd4e4c  vmovaps xmm4, [rsp+0x30]
00007f0145bd4e52  vmovaps xmm5, [rsp+0x40]
00007f0145bd4e58  vmovaps xmm6, [rsp+0x50]
00007f0145bd4e5e  vmovaps xmm7, [rsp+0x60]
00007f0145bd4e64  vmovaps xmm8, [rsp+0x70]
00007f0145bd4e6a  vmovaps xmm9, [rsp+0x80]
00007f0145bd4e73  vmovaps xmm10, [rsp+0x90]
00007f0145bd4e7c  vmovaps xmm11, [rsp+0xA0]
00007f0145bd4e85  vmovaps xmm12, [rsp+0xB0]
00007f0145bd4e8e  vmovaps xmm13, [rsp+0xC0]
00007f0145bd4e97  vmovaps xmm14, [rsp+0xD0]
00007f0145bd4ea0  vmovaps xmm15, [rsp+0xE0]
00007f0145bd4ea9  add rsp, 0xF0
00007f0145bd4eb0  pop r11
00007f0145bd4eb2  pop r10
00007f0145bd4eb4  pop r9
00007f0145bd4eb6  pop r8
00007f0145bd4eb8  pop rsi
00007f0145bd4eb9  pop rdi
00007f0145bd4eba  pop rdx
00007f0145bd4ebb  pop rcx
00007f0145bd4ebc  pop rax
00007f0145bd4ebd  add rsp, 0x08
00007f0145bd4ec1  jmp 0x00007F0145BD0224
00007f0145bd4ec6  call 0x00007F0145AE20A0
00007f0145bd4ecb  jmp 0x00007F0145BD0232
00007f0145bd4ed0  call 0x00007F0145A09D70
00007f0145bd4ed5  jmp 0x00007F0145BD023C
00007f0145bd4eda  sub rsp, 0x08
00007f0145bd4ede  push rax
00007f0145bd4edf  push rcx
00007f0145bd4ee0  push rdx
00007f0145bd4ee1  push rdi
00007f0145bd4ee2  push rsi
00007f0145bd4ee3  push r8
00007f0145bd4ee5  push r9
00007f0145bd4ee7  push r10
00007f0145bd4ee9  push r11
00007f0145bd4eeb  sub rsp, 0xF0
00007f0145bd4ef2  vmovaps [rsp], xmm0
00007f0145bd4ef7  vmovaps [rsp+0x10], xmm1
00007f0145bd4efd  vmovaps [rsp+0x20], xmm2
00007f0145bd4f03  vmovaps [rsp+0x30], xmm3
00007f0145bd4f09  vmovaps [rsp+0x40], xmm4
00007f0145bd4f0f  vmovaps [rsp+0x50], xmm5
00007f0145bd4f15  vmovaps [rsp+0x60], xmm6
00007f0145bd4f1b  vmovaps [rsp+0x70], xmm8
00007f0145bd4f21  vmovaps [rsp+0x80], xmm9
00007f0145bd4f2a  vmovaps [rsp+0x90], xmm10
00007f0145bd4f33  vmovaps [rsp+0xA0], xmm11
00007f0145bd4f3c  vmovaps [rsp+0xB0], xmm12
00007f0145bd4f45  vmovaps [rsp+0xC0], xmm13
00007f0145bd4f4e  vmovaps [rsp+0xD0], xmm14
00007f0145bd4f57  vmovaps [rsp+0xE0], xmm15
00007f0145bd4f60  sub rsp, 0x30
00007f0145bd4f64  movaps [rsp], xmm7
00007f0145bd4f68  movaps [rsp+0x10], xmm15
00007f0145bd4f6e  movaps [rsp+0x20], xmm10
00007f0145bd4f74  lea rdi, [rsp]
00007f0145bd4f78  mov esi, 0x00
00007f0145bd4f7d  mov rax, 0x636570E98530
00007f0145bd4f87  call rax
00007f0145bd4f89  movaps xmm7, [rsp]
00007f0145bd4f8d  add rsp, 0x30
00007f0145bd4f91  vmovaps xmm0, [rsp]
00007f0145bd4f96  vmovaps xmm1, [rsp+0x10]
00007f0145bd4f9c  vmovaps xmm2, [rsp+0x20]
00007f0145bd4fa2  vmovaps xmm3, [rsp+0x30]
00007f0145bd4fa8  vmovaps xmm4, [rsp+0x40]
00007f0145bd4fae  vmovaps xmm5, [rsp+0x50]
00007f0145bd4fb4  vmovaps xmm6, [rsp+0x60]
00007f0145bd4fba  vmovaps xmm8, [rsp+0x70]
00007f0145bd4fc0  vmovaps xmm9, [rsp+0x80]
00007f0145bd4fc9  vmovaps xmm10, [rsp+0x90]
00007f0145bd4fd2  vmovaps xmm11, [rsp+0xA0]
00007f0145bd4fdb  vmovaps xmm12, [rsp+0xB0]
00007f0145bd4fe4  vmovaps xmm13, [rsp+0xC0]
00007f0145bd4fed  vmovaps xmm14, [rsp+0xD0]
00007f0145bd4ff6  vmovaps xmm15, [rsp+0xE0]
00007f0145bd4fff  add rsp, 0xF0
00007f0145bd5006  pop r11
00007f0145bd5008  pop r10
00007f0145bd500a  pop r9
00007f0145bd500c  pop r8
00007f0145bd500e  pop rsi
00007f0145bd500f  pop rdi
00007f0145bd5010  pop rdx
00007f0145bd5011  pop rcx
00007f0145bd5012  pop rax
00007f0145bd5013  add rsp, 0x08
00007f0145bd5017  jmp 0x00007F0145BD025D
00007f0145bd501c  sub rsp, 0x08
00007f0145bd5020  push rax
00007f0145bd5021  push rcx
00007f0145bd5022  push rdx
00007f0145bd5023  push rdi
00007f0145bd5024  push rsi
00007f0145bd5025  push r8
00007f0145bd5027  push r9
00007f0145bd5029  push r10
00007f0145bd502b  push r11
00007f0145bd502d  sub rsp, 0xF0
00007f0145bd5034  vmovaps [rsp], xmm0
00007f0145bd5039  vmovaps [rsp+0x10], xmm1
00007f0145bd503f  vmovaps [rsp+0x20], xmm2
00007f0145bd5045  vmovaps [rsp+0x30], xmm3
00007f0145bd504b  vmovaps [rsp+0x40], xmm4
00007f0145bd5051  vmovaps [rsp+0x50], xmm5
00007f0145bd5057  vmovaps [rsp+0x60], xmm6
00007f0145bd505d  vmovaps [rsp+0x70], xmm7
00007f0145bd5063  vmovaps [rsp+0x80], xmm8
00007f0145bd506c  vmovaps [rsp+0x90], xmm9
00007f0145bd5075  vmovaps [rsp+0xA0], xmm11
00007f0145bd507e  vmovaps [rsp+0xB0], xmm12
00007f0145bd5087  vmovaps [rsp+0xC0], xmm13
00007f0145bd5090  vmovaps [rsp+0xD0], xmm14
00007f0145bd5099  vmovaps [rsp+0xE0], xmm15
00007f0145bd50a2  sub rsp, 0x30
00007f0145bd50a6  movaps [rsp], xmm10
00007f0145bd50ab  movaps [rsp+0x10], xmm11
00007f0145bd50b1  movaps [rsp+0x20], xmm15
00007f0145bd50b7  lea rdi, [rsp]
00007f0145bd50bb  mov esi, 0x00
00007f0145bd50c0  mov rax, 0x636570E98530
00007f0145bd50ca  call rax
00007f0145bd50cc  movaps xmm10, [rsp]
00007f0145bd50d1  add rsp, 0x30
00007f0145bd50d5  vmovaps xmm0, [rsp]
00007f0145bd50da  vmovaps xmm1, [rsp+0x10]
00007f0145bd50e0  vmovaps xmm2, [rsp+0x20]
00007f0145bd50e6  vmovaps xmm3, [rsp+0x30]
00007f0145bd50ec  vmovaps xmm4, [rsp+0x40]
00007f0145bd50f2  vmovaps xmm5, [rsp+0x50]
00007f0145bd50f8  vmovaps xmm6, [rsp+0x60]
00007f0145bd50fe  vmovaps xmm7, [rsp+0x70]
00007f0145bd5104  vmovaps xmm8, [rsp+0x80]
00007f0145bd510d  vmovaps xmm9, [rsp+0x90]
00007f0145bd5116  vmovaps xmm11, [rsp+0xA0]
00007f0145bd511f  vmovaps xmm12, [rsp+0xB0]
00007f0145bd5128  vmovaps xmm13, [rsp+0xC0]
00007f0145bd5131  vmovaps xmm14, [rsp+0xD0]
00007f0145bd513a  vmovaps xmm15, [rsp+0xE0]
00007f0145bd5143  add rsp, 0xF0
00007f0145bd514a  pop r11
00007f0145bd514c  pop r10
00007f0145bd514e  pop r9
00007f0145bd5150  pop r8
00007f0145bd5152  pop rsi
00007f0145bd5153  pop rdi
00007f0145bd5154  pop rdx
00007f0145bd5155  pop rcx
00007f0145bd5156  pop rax
00007f0145bd5157  add rsp, 0x08
00007f0145bd515b  jmp 0x00007F0145BD028B
00007f0145bd5160  sub rsp, 0x08
00007f0145bd5164  push rax
00007f0145bd5165  push rcx
00007f0145bd5166  push rdx
00007f0145bd5167  push rdi
00007f0145bd5168  push rsi
00007f0145bd5169  push r8
00007f0145bd516b  push r9
00007f0145bd516d  push r10
00007f0145bd516f  push r11
00007f0145bd5171  sub rsp, 0xF0
00007f0145bd5178  vmovaps [rsp], xmm0
00007f0145bd517d  vmovaps [rsp+0x10], xmm1
00007f0145bd5183  vmovaps [rsp+0x20], xmm2
00007f0145bd5189  vmovaps [rsp+0x30], xmm3
00007f0145bd518f  vmovaps [rsp+0x40], xmm4
00007f0145bd5195  vmovaps [rsp+0x50], xmm5
00007f0145bd519b  vmovaps [rsp+0x60], xmm6
00007f0145bd51a1  vmovaps [rsp+0x70], xmm7
00007f0145bd51a7  vmovaps [rsp+0x80], xmm8
00007f0145bd51b0  vmovaps [rsp+0x90], xmm9
00007f0145bd51b9  vmovaps [rsp+0xA0], xmm10
00007f0145bd51c2  vmovaps [rsp+0xB0], xmm12
00007f0145bd51cb  vmovaps [rsp+0xC0], xmm13
00007f0145bd51d4  vmovaps [rsp+0xD0], xmm14
00007f0145bd51dd  vmovaps [rsp+0xE0], xmm15
00007f0145bd51e6  sub rsp, 0x30
00007f0145bd51ea  movaps [rsp], xmm11
00007f0145bd51ef  movaps [rsp+0x10], xmm12
00007f0145bd51f5  movaps [rsp+0x20], xmm15
00007f0145bd51fb  lea rdi, [rsp]
00007f0145bd51ff  mov esi, 0x00
00007f0145bd5204  mov rax, 0x636570E98530
00007f0145bd520e  call rax
00007f0145bd5210  movaps xmm11, [rsp]
00007f0145bd5215  add rsp, 0x30
00007f0145bd5219  vmovaps xmm0, [rsp]
00007f0145bd521e  vmovaps xmm1, [rsp+0x10]
00007f0145bd5224  vmovaps xmm2, [rsp+0x20]
00007f0145bd522a  vmovaps xmm3, [rsp+0x30]
00007f0145bd5230  vmovaps xmm4, [rsp+0x40]
00007f0145bd5236  vmovaps xmm5, [rsp+0x50]
00007f0145bd523c  vmovaps xmm6, [rsp+0x60]
00007f0145bd5242  vmovaps xmm7, [rsp+0x70]
00007f0145bd5248  vmovaps xmm8, [rsp+0x80]
00007f0145bd5251  vmovaps xmm9, [rsp+0x90]
00007f0145bd525a  vmovaps xmm10, [rsp+0xA0]
00007f0145bd5263  vmovaps xmm12, [rsp+0xB0]
00007f0145bd526c  vmovaps xmm13, [rsp+0xC0]
00007f0145bd5275  vmovaps xmm14, [rsp+0xD0]
00007f0145bd527e  vmovaps xmm15, [rsp+0xE0]
00007f0145bd5287  add rsp, 0xF0
00007f0145bd528e  pop r11
00007f0145bd5290  pop r10
00007f0145bd5292  pop r9
00007f0145bd5294  pop r8
00007f0145bd5296  pop rsi
00007f0145bd5297  pop rdi
00007f0145bd5298  pop rdx
00007f0145bd5299  pop rcx
00007f0145bd529a  pop rax
00007f0145bd529b  add rsp, 0x08
00007f0145bd529f  jmp 0x00007F0145BD02B9
00007f0145bd52a4  sub rsp, 0x08
00007f0145bd52a8  push rax
00007f0145bd52a9  push rcx
00007f0145bd52aa  push rdx
00007f0145bd52ab  push rdi
00007f0145bd52ac  push rsi
00007f0145bd52ad  push r8
00007f0145bd52af  push r9
00007f0145bd52b1  push r10
00007f0145bd52b3  push r11
00007f0145bd52b5  sub rsp, 0xF0
00007f0145bd52bc  vmovaps [rsp], xmm0
00007f0145bd52c1  vmovaps [rsp+0x10], xmm1
00007f0145bd52c7  vmovaps [rsp+0x20], xmm2
00007f0145bd52cd  vmovaps [rsp+0x30], xmm3
00007f0145bd52d3  vmovaps [rsp+0x40], xmm4
00007f0145bd52d9  vmovaps [rsp+0x50], xmm5
00007f0145bd52df  vmovaps [rsp+0x60], xmm6
00007f0145bd52e5  vmovaps [rsp+0x70], xmm7
00007f0145bd52eb  vmovaps [rsp+0x80], xmm8
00007f0145bd52f4  vmovaps [rsp+0x90], xmm9
00007f0145bd52fd  vmovaps [rsp+0xA0], xmm10
00007f0145bd5306  vmovaps [rsp+0xB0], xmm11
00007f0145bd530f  vmovaps [rsp+0xC0], xmm12
00007f0145bd5318  vmovaps [rsp+0xD0], xmm13
00007f0145bd5321  vmovaps [rsp+0xE0], xmm14
00007f0145bd532a  sub rsp, 0x30
00007f0145bd532e  movaps [rsp], xmm15
00007f0145bd5333  movaps [rsp+0x10], xmm13
00007f0145bd5339  movaps [rsp+0x20], xmm9
00007f0145bd533f  lea rdi, [rsp]
00007f0145bd5343  mov esi, 0x00
00007f0145bd5348  mov rax, 0x636570E98530
00007f0145bd5352  call rax
00007f0145bd5354  movaps xmm15, [rsp]
00007f0145bd5359  add rsp, 0x30
00007f0145bd535d  vmovaps xmm0, [rsp]
00007f0145bd5362  vmovaps xmm1, [rsp+0x10]
00007f0145bd5368  vmovaps xmm2, [rsp+0x20]
00007f0145bd536e  vmovaps xmm3, [rsp+0x30]
00007f0145bd5374  vmovaps xmm4, [rsp+0x40]
00007f0145bd537a  vmovaps xmm5, [rsp+0x50]
00007f0145bd5380  vmovaps xmm6, [rsp+0x60]
00007f0145bd5386  vmovaps xmm7, [rsp+0x70]
00007f0145bd538c  vmovaps xmm8, [rsp+0x80]
00007f0145bd5395  vmovaps xmm9, [rsp+0x90]
00007f0145bd539e  vmovaps xmm10, [rsp+0xA0]
00007f0145bd53a7  vmovaps xmm11, [rsp+0xB0]
00007f0145bd53b0  vmovaps xmm12, [rsp+0xC0]
00007f0145bd53b9  vmovaps xmm13, [rsp+0xD0]
00007f0145bd53c2  vmovaps xmm14, [rsp+0xE0]
00007f0145bd53cb  add rsp, 0xF0
00007f0145bd53d2  pop r11
00007f0145bd53d4  pop r10
00007f0145bd53d6  pop r9
00007f0145bd53d8  pop r8
00007f0145bd53da  pop rsi
00007f0145bd53db  pop rdi
00007f0145bd53dc  pop rdx
00007f0145bd53dd  pop rcx
00007f0145bd53de  pop rax
00007f0145bd53df  add rsp, 0x08
00007f0145bd53e3  jmp 0x00007F0145BD02D4
00007f0145bd53e8  sub rsp, 0x08
00007f0145bd53ec  push rax
00007f0145bd53ed  push rcx
00007f0145bd53ee  push rdx
00007f0145bd53ef  push rdi
00007f0145bd53f0  push rsi
00007f0145bd53f1  push r8
00007f0145bd53f3  push r9
00007f0145bd53f5  push r10
00007f0145bd53f7  push r11
00007f0145bd53f9  sub rsp, 0xF0
00007f0145bd5400  vmovaps [rsp], xmm0
00007f0145bd5405  vmovaps [rsp+0x10], xmm1
00007f0145bd540b  vmovaps [rsp+0x20], xmm2
00007f0145bd5411  vmovaps [rsp+0x30], xmm3
00007f0145bd5417  vmovaps [rsp+0x40], xmm4
00007f0145bd541d  vmovaps [rsp+0x50], xmm5
00007f0145bd5423  vmovaps [rsp+0x60], xmm6
00007f0145bd5429  vmovaps [rsp+0x70], xmm7
00007f0145bd542f  vmovaps [rsp+0x80], xmm8
00007f0145bd5438  vmovaps [rsp+0x90], xmm9
00007f0145bd5441  vmovaps [rsp+0xA0], xmm10
00007f0145bd544a  vmovaps [rsp+0xB0], xmm11
00007f0145bd5453  vmovaps [rsp+0xC0], xmm12
00007f0145bd545c  vmovaps [rsp+0xD0], xmm14
00007f0145bd5465  vmovaps [rsp+0xE0], xmm15
00007f0145bd546e  sub rsp, 0x30
00007f0145bd5472  movaps [rsp], xmm13
00007f0145bd5477  movaps [rsp+0x10], xmm8
00007f0145bd547d  movaps [rsp+0x20], xmm14
00007f0145bd5483  lea rdi, [rsp]
00007f0145bd5487  mov esi, 0x00
00007f0145bd548c  mov rax, 0x636570E98530
00007f0145bd5496  call rax
00007f0145bd5498  movaps xmm13, [rsp]
00007f0145bd549d  add rsp, 0x30
00007f0145bd54a1  vmovaps xmm0, [rsp]
00007f0145bd54a6  vmovaps xmm1, [rsp+0x10]
00007f0145bd54ac  vmovaps xmm2, [rsp+0x20]
00007f0145bd54b2  vmovaps xmm3, [rsp+0x30]
00007f0145bd54b8  vmovaps xmm4, [rsp+0x40]
00007f0145bd54be  vmovaps xmm5, [rsp+0x50]
00007f0145bd54c4  vmovaps xmm6, [rsp+0x60]
00007f0145bd54ca  vmovaps xmm7, [rsp+0x70]
00007f0145bd54d0  vmovaps xmm8, [rsp+0x80]
00007f0145bd54d9  vmovaps xmm9, [rsp+0x90]
00007f0145bd54e2  vmovaps xmm10, [rsp+0xA0]
00007f0145bd54eb  vmovaps xmm11, [rsp+0xB0]
00007f0145bd54f4  vmovaps xmm12, [rsp+0xC0]
00007f0145bd54fd  vmovaps xmm14, [rsp+0xD0]
00007f0145bd5506  vmovaps xmm15, [rsp+0xE0]
00007f0145bd550f  add rsp, 0xF0
00007f0145bd5516  pop r11
00007f0145bd5518  pop r10
00007f0145bd551a  pop r9
00007f0145bd551c  pop r8
00007f0145bd551e  pop rsi
00007f0145bd551f  pop rdi
00007f0145bd5520  pop rdx
00007f0145bd5521  pop rcx
00007f0145bd5522  pop rax
00007f0145bd5523  add rsp, 0x08
00007f0145bd5527  jmp 0x00007F0145BD02F7
00007f0145bd552c  sub rsp, 0x08
00007f0145bd5530  push rax
00007f0145bd5531  push rcx
00007f0145bd5532  push rdx
00007f0145bd5533  push rdi
00007f0145bd5534  push rsi
00007f0145bd5535  push r8
00007f0145bd5537  push r9
00007f0145bd5539  push r10
00007f0145bd553b  push r11
00007f0145bd553d  sub rsp, 0xF0
00007f0145bd5544  vmovaps [rsp], xmm0
00007f0145bd5549  vmovaps [rsp+0x10], xmm1
00007f0145bd554f  vmovaps [rsp+0x20], xmm2
00007f0145bd5555  vmovaps [rsp+0x30], xmm3
00007f0145bd555b  vmovaps [rsp+0x40], xmm4
00007f0145bd5561  vmovaps [rsp+0x50], xmm5
00007f0145bd5567  vmovaps [rsp+0x60], xmm6
00007f0145bd556d  vmovaps [rsp+0x70], xmm7
00007f0145bd5573  vmovaps [rsp+0x80], xmm8
00007f0145bd557c  vmovaps [rsp+0x90], xmm9
00007f0145bd5585  vmovaps [rsp+0xA0], xmm10
00007f0145bd558e  vmovaps [rsp+0xB0], xmm11
00007f0145bd5597  vmovaps [rsp+0xC0], xmm12
00007f0145bd55a0  vmovaps [rsp+0xD0], xmm13
00007f0145bd55a9  vmovaps [rsp+0xE0], xmm15
00007f0145bd55b2  sub rsp, 0x30
00007f0145bd55b6  movaps [rsp], xmm14
00007f0145bd55bb  movaps [rsp+0x10], xmm1
00007f0145bd55c0  movaps [rsp+0x20], xmm10
00007f0145bd55c6  lea rdi, [rsp]
00007f0145bd55ca  mov esi, 0x00
00007f0145bd55cf  mov rax, 0x636570E98530
00007f0145bd55d9  call rax
00007f0145bd55db  movaps xmm14, [rsp]
00007f0145bd55e0  add rsp, 0x30
00007f0145bd55e4  vmovaps xmm0, [rsp]
00007f0145bd55e9  vmovaps xmm1, [rsp+0x10]
00007f0145bd55ef  vmovaps xmm2, [rsp+0x20]
00007f0145bd55f5  vmovaps xmm3, [rsp+0x30]
00007f0145bd55fb  vmovaps xmm4, [rsp+0x40]
00007f0145bd5601  vmovaps xmm5, [rsp+0x50]
00007f0145bd5607  vmovaps xmm6, [rsp+0x60]
00007f0145bd560d  vmovaps xmm7, [rsp+0x70]
00007f0145bd5613  vmovaps xmm8, [rsp+0x80]
00007f0145bd561c  vmovaps xmm9, [rsp+0x90]
00007f0145bd5625  vmovaps xmm10, [rsp+0xA0]
00007f0145bd562e  vmovaps xmm11, [rsp+0xB0]
00007f0145bd5637  vmovaps xmm12, [rsp+0xC0]
00007f0145bd5640  vmovaps xmm13, [rsp+0xD0]
00007f0145bd5649  vmovaps xmm15, [rsp+0xE0]
00007f0145bd5652  add rsp, 0xF0
00007f0145bd5659  pop r11
00007f0145bd565b  pop r10
00007f0145bd565d  pop r9
00007f0145bd565f  pop r8
00007f0145bd5661  pop rsi
00007f0145bd5662  pop rdi
00007f0145bd5663  pop rdx
00007f0145bd5664  pop rcx
00007f0145bd5665  pop rax
00007f0145bd5666  add rsp, 0x08
00007f0145bd566a  jmp 0x00007F0145BD031A
00007f0145bd566f  sub rsp, 0x08
00007f0145bd5673  push rax
00007f0145bd5674  push rcx
00007f0145bd5675  push rdx
00007f0145bd5676  push rdi
00007f0145bd5677  push rsi
00007f0145bd5678  push r8
00007f0145bd567a  push r9
00007f0145bd567c  push r10
00007f0145bd567e  push r11
00007f0145bd5680  sub rsp, 0xF0
00007f0145bd5687  vmovaps [rsp], xmm0
00007f0145bd568c  vmovaps [rsp+0x10], xmm2
00007f0145bd5692  vmovaps [rsp+0x20], xmm3
00007f0145bd5698  vmovaps [rsp+0x30], xmm4
00007f0145bd569e  vmovaps [rsp+0x40], xmm5
00007f0145bd56a4  vmovaps [rsp+0x50], xmm6
00007f0145bd56aa  vmovaps [rsp+0x60], xmm7
00007f0145bd56b0  vmovaps [rsp+0x70], xmm8
00007f0145bd56b6  vmovaps [rsp+0x80], xmm9
00007f0145bd56bf  vmovaps [rsp+0x90], xmm10
00007f0145bd56c8  vmovaps [rsp+0xA0], xmm11
00007f0145bd56d1  vmovaps [rsp+0xB0], xmm12
00007f0145bd56da  vmovaps [rsp+0xC0], xmm13
00007f0145bd56e3  vmovaps [rsp+0xD0], xmm14
00007f0145bd56ec  vmovaps [rsp+0xE0], xmm15
00007f0145bd56f5  sub rsp, 0x30
00007f0145bd56f9  movaps [rsp], xmm1
00007f0145bd56fd  movaps [rsp+0x10], xmm7
00007f0145bd5702  movaps [rsp+0x20], xmm11
00007f0145bd5708  lea rdi, [rsp]
00007f0145bd570c  mov esi, 0x00
00007f0145bd5711  mov rax, 0x636570E98530
00007f0145bd571b  call rax
00007f0145bd571d  movaps xmm1, [rsp]
00007f0145bd5721  add rsp, 0x30
00007f0145bd5725  vmovaps xmm0, [rsp]
00007f0145bd572a  vmovaps xmm2, [rsp+0x10]
00007f0145bd5730  vmovaps xmm3, [rsp+0x20]
00007f0145bd5736  vmovaps xmm4, [rsp+0x30]
00007f0145bd573c  vmovaps xmm5, [rsp+0x40]
00007f0145bd5742  vmovaps xmm6, [rsp+0x50]
00007f0145bd5748  vmovaps xmm7, [rsp+0x60]
00007f0145bd574e  vmovaps xmm8, [rsp+0x70]
00007f0145bd5754  vmovaps xmm9, [rsp+0x80]
00007f0145bd575d  vmovaps xmm10, [rsp+0x90]
00007f0145bd5766  vmovaps xmm11, [rsp+0xA0]
00007f0145bd576f  vmovaps xmm12, [rsp+0xB0]
00007f0145bd5778  vmovaps xmm13, [rsp+0xC0]
00007f0145bd5781  vmovaps xmm14, [rsp+0xD0]
00007f0145bd578a  vmovaps xmm15, [rsp+0xE0]
00007f0145bd5793  add rsp, 0xF0
00007f0145bd579a  pop r11
00007f0145bd579c  pop r10
00007f0145bd579e  pop r9
00007f0145bd57a0  pop r8
00007f0145bd57a2  pop rsi
00007f0145bd57a3  pop rdi
00007f0145bd57a4  pop rdx
00007f0145bd57a5  pop rcx
00007f0145bd57a6  pop rax
00007f0145bd57a7  add rsp, 0x08
00007f0145bd57ab  jmp 0x00007F0145BD033B
00007f0145bd57b0  call 0x00007F0145A0E880
00007f0145bd57b5  jmp 0x00007F0145BD034E
00007f0145bd57ba  call 0x00007F0145A0C380
00007f0145bd57bf  jmp 0x00007F0145BD0359
00007f0145bd57c4  call 0x00007F0145A0D600
00007f0145bd57c9  jmp 0x00007F0145BD0364
00007f0145bd57ce  call 0x00007F01459FF540
00007f0145bd57d3  jmp 0x00007F0145BD036F
00007f0145bd57d8  int3
00007f0145bd57d9  nop [rax], eax
00007f0145bd57e0  mov rax, [r15+0x40]
00007f0145bd57e4  mov r14, [r15+0x58]
00007f0145bd57e8  lea r12, [rax+r14*1]
00007f0145bd57ec  movaps xmm1, [r15+0x1D0]
00007f0145bd57f4  vmovaps [rsp+0x10], xmm1
00007f0145bd57fa  vmovaps xmm15, [rsp+0x10]
00007f0145bd5800  por xmm1, xmm15
00007f0145bd5805  movaps xmm14, [r15+0x1A0]
00007f0145bd580d  vmovaps [rsp+0x10], xmm14
00007f0145bd5813  vmovaps xmm13, [rsp+0x10]
00007f0145bd5819  por xmm14, xmm13
00007f0145bd581e  lea rax, [r12+0x30]
00007f0145bd5823  mov r11, [r13+rax*1]
00007f0145bd5828  lea rax, [r12+0x38]
00007f0145bd582d  mov r10, [r13+rax*1]
00007f0145bd5832  movq xmm13, r11
00007f0145bd5837  movq xmm12, r10
00007f0145bd583c  movq xmm13, xmm13
00007f0145bd5841  vmovaps [rsp+0x10], xmm13
00007f0145bd5847  movq xmm13, xmm13
00007f0145bd584c  movaps [r15+0x130], xmm13
00007f0145bd5854  movq xmm12, xmm12
00007f0145bd5859  vmovaps [rsp+0x20], xmm12
00007f0145bd585f  movq xmm12, xmm12
00007f0145bd5864  movaps [r15+0x280], xmm12
00007f0145bd586c  movaps xmm13, [r15+0x270]
00007f0145bd5874  vmovaps [rsp+0x30], xmm13
00007f0145bd587a  vmovaps xmm12, [rsp+0x30]
00007f0145bd5880  por xmm13, xmm12
00007f0145bd5885  lea rax, [r12+0x20]
00007f0145bd588a  mov r11, [r13+rax*1]
00007f0145bd588f  lea rax, [r12+0x28]
00007f0145bd5894  mov r10, [r13+rax*1]
00007f0145bd5899  movq xmm12, r11
00007f0145bd589e  movq xmm11, r10
00007f0145bd58a3  movq xmm12, xmm12
00007f0145bd58a8  vmovaps [rsp+0x30], xmm12
00007f0145bd58ae  movq xmm12, xmm12
00007f0145bd58b3  movaps [r15+0x150], xmm12
00007f0145bd58bb  movq xmm11, xmm11
00007f0145bd58c0  vmovaps [rsp+0x40], xmm11
00007f0145bd58c6  movq xmm11, xmm11
00007f0145bd58cb  movaps [r15+0x140], xmm11
00007f0145bd58d3  lea rax, [r12+0x10]
00007f0145bd58d8  mov r11, [r13+rax*1]
00007f0145bd58dd  lea rax, [r12+0x18]
00007f0145bd58e2  mov r10, [r13+rax*1]
00007f0145bd58e7  movq xmm12, r11
00007f0145bd58ec  movq xmm11, r10
00007f0145bd58f1  movq xmm12, xmm12
00007f0145bd58f6  vmovaps [rsp+0x50], xmm12
00007f0145bd58fc  movq xmm12, xmm12
00007f0145bd5901  movaps [r15+0x170], xmm12
00007f0145bd5909  movq xmm11, xmm11
00007f0145bd590e  vmovaps [rsp+0x60], xmm11
00007f0145bd5914  movq xmm11, xmm11
00007f0145bd5919  movaps [r15+0x160], xmm11
00007f0145bd5921  mov rax, [r13+r12*1]
00007f0145bd5926  vmovq xmm12, rax
00007f0145bd592b  vpbroadcastq xmm12, xmm12
00007f0145bd5930  lea rax, [r12+0x08]
00007f0145bd5935  mov r12, [r13+rax*1]
00007f0145bd593a  movq xmm11, r12
00007f0145bd593f  movaps [r15+0x230], xmm11
00007f0145bd5947  mov rax, [r15+0xF8]
00007f0145bd594e  lea r12, [rax+0x50]
00007f0145bd5952  movups xmm11, [r13+r12*1]
00007f0145bd5958  lea r12, [rax+0x60]
00007f0145bd595c  movups xmm10, [r13+r12*1]
00007f0145bd5962  lea r12, [rax+0x30]
00007f0145bd5966  movups xmm9, [r13+r12*1]
00007f0145bd596c  mov r12, [r15+0x50]
00007f0145bd5970  lea r11, [r12+r14*1]
00007f0145bd5974  mov [r15+0x60], r11
00007f0145bd5978  lea r12, [r14+0x40]
00007f0145bd597c  mov [r15+0x58], r12
00007f0145bd5980  movaps xmm8, xmm12
00007f0145bd5984  mulpd xmm8, xmm15
00007f0145bd5989  vcmppd xmm7, xmm8, xmm8, 0x03
00007f0145bd598f  ptest xmm7, xmm7
00007f0145bd5994  jnz 0x00007F0145BD67B7
00007f0145bd599a  movq xmm15, qword ptr [r15+0x230]
00007f0145bd59a3  vmovaps [rsp+0x70], xmm15
00007f0145bd59a9  vpermilpd xmm15, xmm15, 0x00
00007f0145bd59af  movaps xmm7, xmm9
00007f0145bd59b3  mulpd xmm7, xmm15
00007f0145bd59b8  vcmppd xmm6, xmm7, xmm7, 0x03
00007f0145bd59bd  ptest xmm6, xmm6
00007f0145bd59c2  jnz 0x00007F0145BD68FB
00007f0145bd59c8  vxorps xmm15, xmm15, xmm15
00007f0145bd59cd  vpbroadcastq xmm15, xmm15
00007f0145bd59d2  movaps xmm9, xmm12
00007f0145bd59d6  mulpd xmm9, xmm10
00007f0145bd59db  vcmppd xmm6, xmm9, xmm9, 0x03
00007f0145bd59e1  ptest xmm6, xmm6
00007f0145bd59e6  jnz 0x00007F0145BD6A3D
00007f0145bd59ec  movaps xmm10, xmm12
00007f0145bd59f0  mulpd xmm10, xmm11
00007f0145bd59f5  vcmppd xmm6, xmm10, xmm10, 0x03
00007f0145bd59fb  ptest xmm6, xmm6
00007f0145bd5a00  jnz 0x00007F0145BD6B81
00007f0145bd5a06  movaps xmm11, [r15+0x1F0]
00007f0145bd5a0e  movaps xmm6, xmm12
00007f0145bd5a12  mulpd xmm6, xmm11
00007f0145bd5a17  vcmppd xmm5, xmm6, xmm6, 0x03
00007f0145bd5a1c  ptest xmm5, xmm5
00007f0145bd5a21  jnz 0x00007F0145BD6CC5
00007f0145bd5a27  movaps xmm12, [r15+0x2A0]
00007f0145bd5a2f  vmovaps [rsp+0x80], xmm12
00007f0145bd5a38  vmovaps xmm11, [rsp+0x80]
00007f0145bd5a41  por xmm12, xmm11
00007f0145bd5a46  movaps xmm11, [r15+0x250]
00007f0145bd5a4e  vmovaps [rsp+0x80], xmm11
00007f0145bd5a57  vmovaps xmm5, [rsp+0x80]
00007f0145bd5a60  por xmm11, xmm5
00007f0145bd5a65  vmovaps xmm4, [rsp+0x70]
00007f0145bd5a6b  vpermilpd xmm4, xmm4, 0x00
00007f0145bd5a71  movaps xmm3, xmm5
00007f0145bd5a74  mulpd xmm3, xmm4
00007f0145bd5a78  vcmppd xmm2, xmm3, xmm3, 0x03
00007f0145bd5a7d  ptest xmm2, xmm2
00007f0145bd5a82  jnz 0x00007F0145BD6E07
00007f0145bd5a88  mov [rsp+0x80], rax
00007f0145bd5a90  xor eax, eax
00007f0145bd5a92  mov r14d, 0x200
00007f0145bd5a98  cmp r12, r14
00007f0145bd5a9b  cmc
00007f0145bd5a9c  lahf
00007f0145bd5a9d  seto al
00007f0145bd5aa0  mov [r15+0x108], eax
00007f0145bd5aa7  movaps xmm5, xmm8
00007f0145bd5aab  addpd xmm5, xmm15
00007f0145bd5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
00007f0145bd5ab5  ptest xmm4, xmm4
00007f0145bd5aba  jnz 0x00007F0145BD6F47
00007f0145bd5ac0  movaps xmm8, [r15+0x1B0]
00007f0145bd5ac8  movaps xmm4, xmm9
00007f0145bd5acc  addpd xmm4, xmm8
00007f0145bd5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
00007f0145bd5ad6  ptest xmm2, xmm2
00007f0145bd5adb  jnz 0x00007F0145BD7089
00007f0145bd5ae1  movaps xmm9, xmm10
00007f0145bd5ae5  addpd xmm9, xmm8
00007f0145bd5aea  vcmppd xmm2, xmm9, xmm9, 0x03
00007f0145bd5af0  ptest xmm2, xmm2
00007f0145bd5af5  jnz 0x00007F0145BD71CB
00007f0145bd5afb  movaps xmm10, [r15+0x2F0]
00007f0145bd5b03  vmovaps [rsp+0x90], xmm10
00007f0145bd5b0c  vmovaps xmm8, [rsp+0x90]
00007f0145bd5b15  por xmm10, xmm8
00007f0145bd5b1a  movaps xmm8, [r15+0x2E0]
00007f0145bd5b22  vmovaps [rsp+0x90], xmm8
00007f0145bd5b2b  vmovaps xmm2, [rsp+0x90]
00007f0145bd5b34  por xmm8, xmm2
00007f0145bd5b39  movaps xmm2, [r15+0x2D0]
00007f0145bd5b41  vmovaps [rsp+0x90], xmm2
00007f0145bd5b4a  vmovaps [rsp+0xA0], xmm1
00007f0145bd5b53  vmovaps xmm1, [rsp+0x90]
00007f0145bd5b5c  por xmm2, xmm1
00007f0145bd5b60  movaps xmm1, [r15+0x200]
00007f0145bd5b68  vmovaps [rsp+0x90], xmm1
00007f0145bd5b71  vmovaps [rsp+0xB0], xmm15
00007f0145bd5b7a  vmovaps xmm15, [rsp+0x90]
00007f0145bd5b83  por xmm1, xmm15
00007f0145bd5b88  movaps xmm15, [r15+0x1C0]
00007f0145bd5b90  vmovaps [rsp+0x90], xmm15
00007f0145bd5b99  vmovaps [rsp+0xC0], xmm1
00007f0145bd5ba2  vmovaps xmm1, [rsp+0x90]
00007f0145bd5bab  por xmm15, xmm1
00007f0145bd5bb0  movaps xmm1, [r15+0x190]
00007f0145bd5bb8  vmovaps [rsp+0x90], xmm1
00007f0145bd5bc1  vmovaps [rsp+0xD0], xmm15
00007f0145bd5bca  vmovaps xmm15, [rsp+0x90]
00007f0145bd5bd3  por xmm1, xmm15
00007f0145bd5bd8  movaps xmm15, [r15+0x300]
00007f0145bd5be0  vmovaps [rsp+0x90], xmm15
00007f0145bd5be9  vmovaps [rsp+0xE0], xmm1
00007f0145bd5bf2  vmovaps xmm1, [rsp+0x90]
00007f0145bd5bfb  por xmm15, xmm1
00007f0145bd5c00  mov rax, [rsp+0x80]
00007f0145bd5c08  lea r14, [rax+0xA0]
00007f0145bd5c0f  movups xmm1, [r13+r14*1]
00007f0145bd5c15  lea r14, [rax+0xB0]
00007f0145bd5c1c  vmovaps [rsp+0x80], xmm1
00007f0145bd5c25  movups xmm1, [r13+r14*1]
00007f0145bd5c2b  vmovaps [rsp+0x90], xmm1
00007f0145bd5c34  vmovaps [rsp+0xF0], xmm15
00007f0145bd5c3d  vmovaps xmm15, [rsp+0xB0]
00007f0145bd5c46  vmovaps [rsp+0xB0], xmm14
00007f0145bd5c4f  movaps xmm1, xmm6
00007f0145bd5c52  addpd xmm1, xmm15
00007f0145bd5c57  vcmppd xmm14, xmm1, xmm1, 0x03
00007f0145bd5c5c  ptest xmm14, xmm14
00007f0145bd5c62  jnz 0x00007F0145BD7323
00007f0145bd5c68  lea r14, [rax+0xF0]
00007f0145bd5c6f  movups xmm15, [r13+r14*1]
00007f0145bd5c75  movaps xmm14, xmm4
00007f0145bd5c79  addpd xmm14, xmm3
00007f0145bd5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
00007f0145bd5c84  ptest xmm6, xmm6
00007f0145bd5c89  jnz 0x00007F0145BD746E
00007f0145bd5c8f  movaps xmm6, xmm9
00007f0145bd5c93  addpd xmm6, xmm7
00007f0145bd5c97  vcmppd xmm4, xmm6, xmm6, 0x03
00007f0145bd5c9c  ptest xmm4, xmm4
00007f0145bd5ca1  jnz 0x00007F0145BD75B0
00007f0145bd5ca7  vmovaps xmm9, [rsp+0x70]
00007f0145bd5cad  vpermilpd xmm9, xmm9, 0x00
00007f0145bd5cb3  vmovaps xmm4, [rsp+0x90]
00007f0145bd5cbc  movaps xmm7, xmm4
00007f0145bd5cbf  mulpd xmm7, xmm9
00007f0145bd5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
00007f0145bd5cc9  ptest xmm3, xmm3
00007f0145bd5cce  jnz 0x00007F0145BD76F1
00007f0145bd5cd4  vmovaps xmm9, [rsp+0x50]
00007f0145bd5cda  vpermilpd xmm9, xmm9, 0x00
00007f0145bd5ce0  movaps xmm4, xmm15
00007f0145bd5ce4  mulpd xmm4, xmm9
00007f0145bd5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
00007f0145bd5cee  ptest xmm3, xmm3
00007f0145bd5cf3  jnz 0x00007F0145BD7832
00007f0145bd5cf9  lea r14, [rax+0xE0]
00007f0145bd5d00  movups xmm15, [r13+r14*1]
00007f0145bd5d06  vmovaps xmm9, [rsp+0x70]
00007f0145bd5d0c  vpermilpd xmm9, xmm9, 0x00
00007f0145bd5d12  vmovaps [rsp+0x70], xmm1
00007f0145bd5d18  vmovaps xmm1, [rsp+0x80]
00007f0145bd5d21  vmovaps [rsp+0x80], xmm15
00007f0145bd5d2a  movaps xmm3, xmm1
00007f0145bd5d2d  mulpd xmm3, xmm9
00007f0145bd5d32  vcmppd xmm15, xmm3, xmm3, 0x03
00007f0145bd5d37  ptest xmm15, xmm15
00007f0145bd5d3d  jnz 0x00007F0145BD797E
00007f0145bd5d43  vmovaps xmm1, [rsp+0xF0]
00007f0145bd5d4c  vmovaps xmm15, [rsp+0xF0]
00007f0145bd5d55  por xmm1, xmm15
00007f0145bd5d5a  movaps [r15+0x300], xmm1
00007f0145bd5d62  vmovaps xmm15, [rsp+0xE0]
00007f0145bd5d6b  vmovaps xmm9, [rsp+0xE0]
00007f0145bd5d74  por xmm15, xmm9
00007f0145bd5d79  movaps [r15+0x190], xmm15
00007f0145bd5d81  vmovaps xmm9, [rsp+0x50]
00007f0145bd5d87  vpermilpd xmm9, xmm9, 0x00
00007f0145bd5d8d  vmovaps [rsp+0x90], xmm1
00007f0145bd5d96  vmovaps [rsp+0xE0], xmm15
00007f0145bd5d9f  vmovaps xmm15, [rsp+0x80]
00007f0145bd5da8  vmovaps [rsp+0x80], xmm14
00007f0145bd5db1  movaps xmm1, xmm15
00007f0145bd5db5  mulpd xmm1, xmm9
00007f0145bd5dba  vcmppd xmm14, xmm1, xmm1, 0x03
00007f0145bd5dbf  ptest xmm14, xmm14
00007f0145bd5dc5  jnz 0x00007F0145BD7ABF
00007f0145bd5dcb  lea r14, [rax+0x90]
00007f0145bd5dd2  movups xmm15, [r13+r14*1]
00007f0145bd5dd8  vmovaps xmm14, [rsp+0xD0]
00007f0145bd5de1  vmovaps xmm9, [rsp+0xD0]
00007f0145bd5dea  por xmm14, xmm9
00007f0145bd5def  movaps [r15+0x1C0], xmm14
00007f0145bd5df7  vmovaps xmm9, [rsp+0xC0]
00007f0145bd5e00  vmovaps [rsp+0xD0], xmm1
00007f0145bd5e09  vmovaps xmm1, [rsp+0xC0]
00007f0145bd5e12  por xmm9, xmm1
00007f0145bd5e17  movaps [r15+0x200], xmm9
00007f0145bd5e1f  vmovaps [rsp+0xC0], xmm2
00007f0145bd5e28  vmovaps xmm1, [rsp+0xC0]
00007f0145bd5e31  por xmm2, xmm1
00007f0145bd5e35  movaps [r15+0x2D0], xmm2
00007f0145bd5e3d  vmovaps [rsp+0xC0], xmm8
00007f0145bd5e46  vmovaps xmm1, [rsp+0xC0]
00007f0145bd5e4f  por xmm8, xmm1
00007f0145bd5e54  movaps [r15+0x2E0], xmm8
00007f0145bd5e5c  vmovaps [rsp+0xC0], xmm15
00007f0145bd5e65  movaps xmm1, xmm5
00007f0145bd5e68  addpd xmm1, xmm7
00007f0145bd5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
00007f0145bd5e71  ptest xmm15, xmm15
00007f0145bd5e77  jnz 0x00007F0145BD7C0B
00007f0145bd5e7d  vmovaps xmm15, [rsp+0x50]
00007f0145bd5e83  vpermilpd xmm15, xmm15, 0x00
00007f0145bd5e89  vmovaps xmm5, [rsp+0xC0]
00007f0145bd5e92  vmovaps [rsp+0xC0], xmm1
00007f0145bd5e9b  movaps xmm7, xmm5
00007f0145bd5e9e  mulpd xmm7, xmm15
00007f0145bd5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
00007f0145bd5ea8  ptest xmm1, xmm1
00007f0145bd5ead  jnz 0x00007F0145BD7D4B
00007f0145bd5eb3  lea r14, [rax+0x80]
00007f0145bd5eba  movups xmm1, [r13+r14*1]
00007f0145bd5ec0  vmovaps xmm5, [rsp+0x70]
00007f0145bd5ec6  vmovaps [rsp+0x70], xmm1
00007f0145bd5ecc  movaps xmm15, xmm5
00007f0145bd5ed0  addpd xmm15, xmm3
00007f0145bd5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
00007f0145bd5edb  ptest xmm1, xmm1
00007f0145bd5ee0  jnz 0x00007F0145BD7E96
00007f0145bd5ee6  vmovaps xmm5, [rsp+0x80]
00007f0145bd5eef  movaps xmm1, xmm5
00007f0145bd5ef2  addpd xmm1, xmm4
00007f0145bd5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
00007f0145bd5efb  ptest xmm3, xmm3
00007f0145bd5f00  jnz 0x00007F0145BD7FD8
00007f0145bd5f06  vmovaps [rsp+0x80], xmm10
00007f0145bd5f0f  vmovaps xmm5, [rsp+0x80]
00007f0145bd5f18  por xmm10, xmm5
00007f0145bd5f1d  movaps [r15+0x2F0], xmm10
00007f0145bd5f25  vmovaps xmm5, [rsp+0x50]
00007f0145bd5f2b  vpermilpd xmm5, xmm5, 0x00
00007f0145bd5f31  vmovaps xmm3, [rsp+0x70]
00007f0145bd5f37  vmovaps [rsp+0x50], xmm1
00007f0145bd5f3d  movaps xmm4, xmm3
00007f0145bd5f40  mulpd xmm4, xmm5
00007f0145bd5f44  vcmppd xmm1, xmm4, xmm4, 0x03
00007f0145bd5f49  ptest xmm1, xmm1
00007f0145bd5f4e  jnz 0x00007F0145BD8118
00007f0145bd5f54  lea r14, [rax+0xD0]
00007f0145bd5f5b  movups xmm1, [r13+r14*1]
00007f0145bd5f61  vmovaps xmm3, [rsp+0xD0]
00007f0145bd5f6a  vmovaps [rsp+0x70], xmm1
00007f0145bd5f70  movaps xmm5, xmm6
00007f0145bd5f73  addpd xmm5, xmm3
00007f0145bd5f77  vcmppd xmm1, xmm5, xmm5, 0x03
00007f0145bd5f7c  ptest xmm1, xmm1
00007f0145bd5f81  jnz 0x00007F0145BD8262
00007f0145bd5f87  vmovaps xmm1, [rsp+0x60]
00007f0145bd5f8d  vpermilpd xmm1, xmm1, 0x00
00007f0145bd5f93  movaps xmm6, xmm9
00007f0145bd5f97  mulpd xmm6, xmm1
00007f0145bd5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
00007f0145bd5fa0  ptest xmm3, xmm3
00007f0145bd5fa5  jnz 0x00007F0145BD83A2
00007f0145bd5fab  movaps [r15+0x260], xmm6
00007f0145bd5fb3  vxorps xmm1, xmm1, xmm1
00007f0145bd5fb7  vpbroadcastq xmm1, xmm1
00007f0145bd5fbc  movaps [r15+0x1B0], xmm1
00007f0145bd5fc4  vmovaps xmm1, [rsp+0x60]
00007f0145bd5fca  vpermilpd xmm1, xmm1, 0x00
00007f0145bd5fd0  vmovaps xmm3, [rsp+0x70]
00007f0145bd5fd6  vmovaps [rsp+0x70], xmm15
00007f0145bd5fdc  movaps xmm9, xmm3
00007f0145bd5fe0  mulpd xmm9, xmm1
00007f0145bd5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
00007f0145bd5feb  ptest xmm15, xmm15
00007f0145bd5ff1  jnz 0x00007F0145BD84E3
00007f0145bd5ff7  lea r14, [rax+0xC0]
00007f0145bd5ffe  movups xmm1, [r13+r14*1]
00007f0145bd6004  vmovaps xmm3, [rsp+0xC0]
00007f0145bd600d  vmovaps [rsp+0x80], xmm1
00007f0145bd6016  movaps xmm15, xmm3
00007f0145bd601a  addpd xmm15, xmm7
00007f0145bd601f  vcmppd xmm1, xmm15, xmm15, 0x03
00007f0145bd6025  ptest xmm1, xmm1
00007f0145bd602a  jnz 0x00007F0145BD862F
00007f0145bd6030  vmovaps [rsp+0xC0], xmm13
00007f0145bd6039  vmovaps xmm1, [rsp+0xC0]
00007f0145bd6042  por xmm13, xmm1
00007f0145bd6047  movaps [r15+0x270], xmm13
00007f0145bd604f  vmovaps xmm1, [rsp+0xB0]
00007f0145bd6058  vmovaps xmm7, [rsp+0xB0]
00007f0145bd6061  por xmm1, xmm7
00007f0145bd6065  movaps [r15+0x1A0], xmm1
00007f0145bd606d  vmovaps xmm1, [rsp+0x60]
00007f0145bd6073  vpermilpd xmm1, xmm1, 0x00
00007f0145bd6079  vmovaps [rsp+0xB0], xmm1
00007f0145bd6082  vmovaps xmm1, [rsp+0x80]
00007f0145bd608b  vmovaps [rsp+0x80], xmm15
00007f0145bd6094  vmovaps xmm15, [rsp+0xB0]
00007f0145bd609d  vmovaps [rsp+0xB0], xmm14
00007f0145bd60a6  movaps xmm3, xmm1
00007f0145bd60a9  mulpd xmm3, xmm15
00007f0145bd60ae  vcmppd xmm14, xmm3, xmm3, 0x03
00007f0145bd60b3  ptest xmm14, xmm14
00007f0145bd60b9  jnz 0x00007F0145BD8771
00007f0145bd60bf  lea r14, [rax+0x20]
00007f0145bd60c3  movups xmm1, [r13+r14*1]
00007f0145bd60c9  movaps [r15+0x110], xmm1
00007f0145bd60d1  vmovaps xmm14, [rsp+0x70]
00007f0145bd60d7  vmovaps [rsp+0x70], xmm1
00007f0145bd60dd  movaps xmm15, xmm14
00007f0145bd60e1  addpd xmm15, xmm4
00007f0145bd60e6  vcmppd xmm1, xmm15, xmm15, 0x03
00007f0145bd60ec  ptest xmm1, xmm1
00007f0145bd60f1  jnz 0x00007F0145BD88BC
00007f0145bd60f7  vmovaps xmm1, [rsp+0x60]
00007f0145bd60fd  vpermilpd xmm1, xmm1, 0x00
00007f0145bd6103  movaps xmm14, xmm2
00007f0145bd6107  mulpd xmm14, xmm1
00007f0145bd610c  vcmppd xmm4, xmm14, xmm14, 0x03
00007f0145bd6112  ptest xmm4, xmm4
00007f0145bd6117  jnz 0x00007F0145BD89FF
00007f0145bd611d  vmovaps xmm4, [rsp+0x50]
00007f0145bd6123  movaps xmm1, xmm4
00007f0145bd6126  addpd xmm1, xmm9
00007f0145bd612b  vcmppd xmm2, xmm1, xmm1, 0x03
00007f0145bd6130  ptest xmm2, xmm2
00007f0145bd6135  jnz 0x00007F0145BD8B41
00007f0145bd613b  vmovaps xmm9, [rsp+0x30]
00007f0145bd6141  vpermilpd xmm9, xmm9, 0x00
00007f0145bd6147  vmovaps xmm2, [rsp+0x70]
00007f0145bd614d  vmovaps [rsp+0x50], xmm1
00007f0145bd6153  movaps xmm4, xmm2
00007f0145bd6156  mulpd xmm4, xmm9
00007f0145bd615b  vcmppd xmm1, xmm4, xmm4, 0x03
00007f0145bd6160  ptest xmm1, xmm1
00007f0145bd6165  jnz 0x00007F0145BD8C82
00007f0145bd616b  vmovaps xmm1, [rsp+0x30]
00007f0145bd6171  vpermilpd xmm1, xmm1, 0x00
00007f0145bd6177  vmovaps xmm2, [rsp+0x90]
00007f0145bd6180  vmovaps [rsp+0x60], xmm15
00007f0145bd6186  movaps xmm9, xmm2
00007f0145bd618a  mulpd xmm9, xmm1
00007f0145bd618f  vcmppd xmm15, xmm9, xmm9, 0x03
00007f0145bd6195  ptest xmm15, xmm15
00007f0145bd619b  jnz 0x00007F0145BD8DC3
00007f0145bd61a1  vmovaps xmm15, [rsp+0x80]
00007f0145bd61aa  movaps xmm1, xmm15
00007f0145bd61ae  addpd xmm1, xmm6
00007f0145bd61b2  vcmppd xmm2, xmm1, xmm1, 0x03
00007f0145bd61b7  ptest xmm2, xmm2
00007f0145bd61bc  jnz 0x00007F0145BD8F05
00007f0145bd61c2  movaps xmm15, xmm5
00007f0145bd61c6  addpd xmm15, xmm3
00007f0145bd61cb  vcmppd xmm6, xmm15, xmm15, 0x03
00007f0145bd61d1  ptest xmm6, xmm6
00007f0145bd61d6  jnz 0x00007F0145BD9046
00007f0145bd61dc  vmovaps xmm6, [rsp+0x30]
00007f0145bd61e2  vpermilpd xmm6, xmm6, 0x00
00007f0145bd61e8  movaps xmm5, xmm8
00007f0145bd61ec  mulpd xmm5, xmm6
00007f0145bd61f0  vcmppd xmm3, xmm5, xmm5, 0x03
00007f0145bd61f5  ptest xmm3, xmm3
00007f0145bd61fa  jnz 0x00007F0145BD9188
00007f0145bd6200  vmovaps xmm8, [rsp+0x30]
00007f0145bd6206  vpermilpd xmm8, xmm8, 0x00
00007f0145bd620c  movaps xmm6, xmm10
00007f0145bd6210  mulpd xmm6, xmm8
00007f0145bd6215  vcmppd xmm3, xmm6, xmm6, 0x03
00007f0145bd621a  ptest xmm3, xmm3
00007f0145bd621f  jnz 0x00007F0145BD92C9
00007f0145bd6225  vmovaps xmm8, [rsp+0x60]
00007f0145bd622b  movaps xmm10, xmm8
00007f0145bd622f  addpd xmm10, xmm14
00007f0145bd6234  vcmppd xmm3, xmm10, xmm10, 0x03
00007f0145bd623a  ptest xmm3, xmm3
00007f0145bd623f  jnz 0x00007F0145BD940B
00007f0145bd6245  vmovaps xmm8, [rsp+0x50]
00007f0145bd624b  movaps xmm14, xmm8
00007f0145bd624f  addpd xmm14, xmm4
00007f0145bd6254  vcmppd xmm3, xmm14, xmm14, 0x03
00007f0145bd625a  ptest xmm3, xmm3
00007f0145bd625f  jnz 0x00007F0145BD954F
00007f0145bd6265  vmovaps xmm8, [rsp+0x40]
00007f0145bd626b  vpermilpd xmm8, xmm8, 0x00
00007f0145bd6271  movaps xmm4, xmm13
00007f0145bd6275  mulpd xmm4, xmm8
00007f0145bd627a  vcmppd xmm3, xmm4, xmm4, 0x03
00007f0145bd627f  ptest xmm3, xmm3
00007f0145bd6284  jnz 0x00007F0145BD9692
00007f0145bd628a  movaps xmm13, xmm15
00007f0145bd628e  addpd xmm13, xmm9
00007f0145bd6293  vcmppd xmm8, xmm13, xmm13, 0x03
00007f0145bd6299  ptest xmm8, xmm8
00007f0145bd629f  jnz 0x00007F0145BD97D4
00007f0145bd62a5  movaps xmm15, xmm1
00007f0145bd62a9  addpd xmm15, xmm5
00007f0145bd62ae  vcmppd xmm9, xmm15, xmm15, 0x03
00007f0145bd62b4  ptest xmm9, xmm9
00007f0145bd62ba  jnz 0x00007F0145BD9918
00007f0145bd62c0  vmovaps [rsp+0x30], xmm11
00007f0145bd62c6  vmovaps xmm1, [rsp+0x30]
00007f0145bd62cc  por xmm11, xmm1
00007f0145bd62d1  movaps [r15+0x250], xmm11
00007f0145bd62d9  vmovaps [rsp+0x30], xmm12
00007f0145bd62df  vmovaps xmm1, [rsp+0x30]
00007f0145bd62e5  por xmm12, xmm1
00007f0145bd62ea  movaps [r15+0x2A0], xmm12
00007f0145bd62f2  vmovaps xmm1, [rsp+0xA0]
00007f0145bd62fb  vmovaps xmm11, [rsp+0xA0]
00007f0145bd6304  por xmm1, xmm11
00007f0145bd6309  movaps [r15+0x1D0], xmm1
00007f0145bd6311  lea r14, [rax+0x40]
00007f0145bd6315  movups xmm1, [r13+r14*1]
00007f0145bd631b  movaps [r15+0x2C0], xmm1
00007f0145bd6323  vmovaps xmm11, [rsp+0x40]
00007f0145bd6329  vpermilpd xmm11, xmm11, 0x00
00007f0145bd632f  vmovaps xmm8, [rsp+0xE0]
00007f0145bd6338  movaps xmm9, xmm8
00007f0145bd633c  mulpd xmm9, xmm11
00007f0145bd6341  vcmppd xmm5, xmm9, xmm9, 0x03
00007f0145bd6347  ptest xmm5, xmm5
00007f0145bd634c  jnz 0x00007F0145BD9A64
00007f0145bd6352  movaps xmm11, xmm10
00007f0145bd6356  addpd xmm11, xmm6
00007f0145bd635b  vcmppd xmm8, xmm11, xmm11, 0x03
00007f0145bd6361  ptest xmm8, xmm8
00007f0145bd6367  jnz 0x00007F0145BD9BA8
00007f0145bd636d  movaps xmm10, xmm14
00007f0145bd6371  addpd xmm10, xmm4
00007f0145bd6376  vcmppd xmm8, xmm10, xmm10, 0x03
00007f0145bd637c  ptest xmm8, xmm8
00007f0145bd6382  jnz 0x00007F0145BD9CEB
00007f0145bd6388  vmovaps xmm14, [rsp+0x40]
00007f0145bd638e  vpermilpd xmm14, xmm14, 0x00
00007f0145bd6394  movaps xmm8, xmm1
00007f0145bd6398  mulpd xmm8, xmm14
00007f0145bd639d  vcmppd xmm6, xmm8, xmm8, 0x03
00007f0145bd63a3  ptest xmm6, xmm6
00007f0145bd63a8  jnz 0x00007F0145BD9E2E
00007f0145bd63ae  movaps xmm1, [r15+0x2B0]
00007f0145bd63b6  vmovaps xmm14, [rsp+0x40]
00007f0145bd63bc  vpermilpd xmm14, xmm14, 0x00
00007f0145bd63c2  movaps xmm6, xmm1
00007f0145bd63c5  mulpd xmm6, xmm14
00007f0145bd63ca  vcmppd xmm5, xmm6, xmm6, 0x03
00007f0145bd63cf  ptest xmm5, xmm5
00007f0145bd63d4  jnz 0x00007F0145BD9F71
00007f0145bd63da  vmovaps xmm1, [rsp+0x10]
00007f0145bd63e0  vpermilpd xmm1, xmm1, 0x00
00007f0145bd63e6  movaps xmm14, xmm12
00007f0145bd63ea  mulpd xmm14, xmm1
00007f0145bd63ef  vcmppd xmm5, xmm14, xmm14, 0x03
00007f0145bd63f5  ptest xmm5, xmm5
00007f0145bd63fa  jnz 0x00007F0145BDA0B2
00007f0145bd6400  movaps xmm1, xmm13
00007f0145bd6404  addpd xmm1, xmm9
00007f0145bd6409  vcmppd xmm12, xmm1, xmm1, 0x03
00007f0145bd640e  ptest xmm12, xmm12
00007f0145bd6414  jnz 0x00007F0145BDA1F5
00007f0145bd641a  vmovaps xmm13, [rsp+0x10]
00007f0145bd6420  vpermilpd xmm13, xmm13, 0x00
00007f0145bd6426  movaps xmm12, xmm7
00007f0145bd642a  mulpd xmm12, xmm13
00007f0145bd642f  vcmppd xmm9, xmm12, xmm12, 0x03
00007f0145bd6435  ptest xmm9, xmm9
00007f0145bd643b  jnz 0x00007F0145BDA337
00007f0145bd6441  movaps xmm13, xmm15
00007f0145bd6445  addpd xmm13, xmm8
00007f0145bd644a  vcmppd xmm9, xmm13, xmm13, 0x03
00007f0145bd6450  ptest xmm9, xmm9
00007f0145bd6456  jnz 0x00007F0145BDA47A
00007f0145bd645c  movaps xmm15, [r15+0x290]
00007f0145bd6464  vmovaps xmm9, [rsp+0x10]
00007f0145bd646a  vpermilpd xmm9, xmm9, 0x00
00007f0145bd6470  movaps xmm8, xmm15
00007f0145bd6474  mulpd xmm8, xmm9
00007f0145bd6479  vcmppd xmm7, xmm8, xmm8, 0x03
00007f0145bd647f  ptest xmm7, xmm7
00007f0145bd6484  jnz 0x00007F0145BDA5BE
00007f0145bd648a  movaps xmm15, xmm11
00007f0145bd648e  addpd xmm15, xmm6
00007f0145bd6493  vcmppd xmm9, xmm15, xmm15, 0x03
00007f0145bd6499  ptest xmm9, xmm9
00007f0145bd649f  jnz 0x00007F0145BDA702
00007f0145bd64a5  movaps xmm11, [r15+0x1E0]
00007f0145bd64ad  vmovaps xmm9, [rsp+0x10]
00007f0145bd64b3  vpermilpd xmm9, xmm9, 0x00
00007f0145bd64b9  movaps xmm7, xmm11
00007f0145bd64bd  mulpd xmm7, xmm9
00007f0145bd64c2  vcmppd xmm6, xmm7, xmm7, 0x03
00007f0145bd64c7  ptest xmm6, xmm6
00007f0145bd64cc  jnz 0x00007F0145BDA845
00007f0145bd64d2  movaps xmm11, xmm10
00007f0145bd64d6  addpd xmm11, xmm14
00007f0145bd64db  vcmppd xmm9, xmm11, xmm11, 0x03
00007f0145bd64e1  ptest xmm9, xmm9
00007f0145bd64e7  jnz 0x00007F0145BDA987
00007f0145bd64ed  lea r14, [rax+0x70]
00007f0145bd64f1  movups xmm14, [r13+r14*1]
00007f0145bd64f7  movaps [r15+0x240], xmm14
00007f0145bd64ff  movaps xmm10, xmm1
00007f0145bd6503  addpd xmm10, xmm12
00007f0145bd6508  vcmppd xmm9, xmm10, xmm10, 0x03
00007f0145bd650e  ptest xmm9, xmm9
00007f0145bd6514  jnz 0x00007F0145BDAAD5
00007f0145bd651a  movaps [r15+0x170], xmm10
00007f0145bd6522  vmovaps xmm1, [rsp+0x20]
00007f0145bd6528  vpermilpd xmm1, xmm1, 0x00
00007f0145bd652e  movaps xmm12, xmm14
00007f0145bd6532  mulpd xmm12, xmm1
00007f0145bd6537  vcmppd xmm9, xmm12, xmm12, 0x03
00007f0145bd653d  ptest xmm9, xmm9
00007f0145bd6543  jnz 0x00007F0145BDAC18
00007f0145bd6549  vmovaps xmm1, [rsp+0x20]
00007f0145bd654f  vpermilpd xmm1, xmm1, 0x00
00007f0145bd6555  vmovaps xmm9, [rsp+0xB0]
00007f0145bd655e  movaps xmm14, xmm9
00007f0145bd6562  mulpd xmm14, xmm1
00007f0145bd6567  vcmppd xmm6, xmm14, xmm14, 0x03
00007f0145bd656d  ptest xmm6, xmm6
00007f0145bd6572  jnz 0x00007F0145BDAD5B
00007f0145bd6578  movaps [r15+0x180], xmm14
00007f0145bd6580  movaps xmm1, xmm13
00007f0145bd6584  addpd xmm1, xmm8
00007f0145bd6589  vcmppd xmm9, xmm1, xmm1, 0x03
00007f0145bd658e  ptest xmm9, xmm9
00007f0145bd6594  jnz 0x00007F0145BDAE9E
00007f0145bd659a  movaps [r15+0x210], xmm1
00007f0145bd65a2  movups xmm13, [r13+rax*1]
00007f0145bd65a8  lea r14, [rax+0x10]
00007f0145bd65ac  movups xmm9, [r13+r14*1]
00007f0145bd65b2  movaps [r15+0x230], xmm9
00007f0145bd65ba  movaps xmm8, xmm15
00007f0145bd65be  addpd xmm8, xmm7
00007f0145bd65c3  vcmppd xmm6, xmm8, xmm8, 0x03
00007f0145bd65c9  ptest xmm6, xmm6
00007f0145bd65ce  jnz 0x00007F0145BDAFF4
00007f0145bd65d4  movaps [r15+0x130], xmm8
00007f0145bd65dc  vmovaps xmm15, [rsp+0x20]
00007f0145bd65e2  vpermilpd xmm15, xmm15, 0x00
00007f0145bd65e8  movaps xmm7, xmm9
00007f0145bd65ec  mulpd xmm7, xmm15
00007f0145bd65f1  vcmppd xmm6, xmm7, xmm7, 0x03
00007f0145bd65f6  ptest xmm6, xmm6
00007f0145bd65fb  jnz 0x00007F0145BDB137
00007f0145bd6601  movaps [r15+0x220], xmm7
00007f0145bd6609  vmovaps xmm15, [rsp+0x20]
00007f0145bd660f  vpermilpd xmm15, xmm15, 0x00
00007f0145bd6615  movaps xmm9, xmm13
00007f0145bd6619  mulpd xmm9, xmm15
00007f0145bd661e  vcmppd xmm6, xmm9, xmm9, 0x03
00007f0145bd6624  ptest xmm6, xmm6
00007f0145bd6629  jnz 0x00007F0145BDB279
00007f0145bd662f  movaps xmm15, xmm11
00007f0145bd6633  addpd xmm15, xmm12
00007f0145bd6638  vcmppd xmm13, xmm15, xmm15, 0x03
00007f0145bd663e  ptest xmm13, xmm13
00007f0145bd6644  jnz 0x00007F0145BDB3BD
00007f0145bd664a  movaps [r15+0x140], xmm15
00007f0145bd6652  movaps xmm13, xmm10
00007f0145bd6656  addpd xmm13, xmm14
00007f0145bd665b  vcmppd xmm12, xmm13, xmm13, 0x03
00007f0145bd6661  ptest xmm12, xmm12
00007f0145bd6667  jnz 0x00007F0145BDB501
00007f0145bd666d  movaps [r15+0x150], xmm13
00007f0145bd6675  movaps xmm14, xmm1
00007f0145bd6679  addpd xmm14, xmm7
00007f0145bd667e  vcmppd xmm12, xmm14, xmm14, 0x03
00007f0145bd6684  ptest xmm12, xmm12
00007f0145bd668a  jnz 0x00007F0145BDB645
00007f0145bd6690  movaps [r15+0x160], xmm14
00007f0145bd6698  movaps xmm1, xmm8
00007f0145bd669c  addpd xmm1, xmm9
00007f0145bd66a1  vcmppd xmm12, xmm1, xmm1, 0x03
00007f0145bd66a6  ptest xmm12, xmm12
00007f0145bd66ac  jnz 0x00007F0145BDB787
00007f0145bd66b2  movaps [r15+0x120], xmm1
00007f0145bd66ba  movups [r13+r11*1], xmm15
00007f0145bd66c0  lea rax, [r11+0x10]
00007f0145bd66c4  movups [r13+rax*1], xmm13
00007f0145bd66ca  lea rax, [r11+0x20]
00007f0145bd66ce  movups [r13+rax*1], xmm14
00007f0145bd66d4  lea rax, [r11+0x30]
00007f0145bd66d8  movups [r13+rax*1], xmm1
00007f0145bd66de  mov eax, [r15+0x108]
00007f0145bd66e5  sahf
00007f0145bd66e6  jnz 0x00007F0145BD6718
00007f0145bd66e8  cmp dword ptr [r15+0x318], 0x00
00007f0145bd66f0  jz 0x00007F0145BDB900
00007f0145bd66f6  nop [rax+rax*1], ax
00007f0145bd66ff  nop [rax+rax*1], eax
00007f0145bd6707  mov eax, 0x410444
00007f0145bd670c  mov [r15+0x100], rax
00007f0145bd6713  jmp 0x00007F01459FE110
00007f0145bd6718  cmp dword ptr [r15+0x318], 0x00
00007f0145bd6720  jz 0x00007F0145BD57E0
00007f0145bd6726  nop [rax+rax*1], ax
00007f0145bd672f  nop [rax+rax*1], eax
00007f0145bd6737  mov eax, 0x410278
00007f0145bd673c  mov [r15+0x100], rax
00007f0145bd6743  jmp 0x00007F01459FE110
00007f0145bd6748  int3
00007f0145bd6749  call 0x00007F0145A0A4B0
00007f0145bd674e  jmp 0x00007F0145BD5828
00007f0145bd6753  call 0x00007F0145A09240
00007f0145bd6758  jmp 0x00007F0145BD5832
00007f0145bd675d  call 0x00007F0145A0A4B0
00007f0145bd6762  jmp 0x00007F0145BD588F
00007f0145bd6767  call 0x00007F0145A09240
00007f0145bd676c  jmp 0x00007F0145BD5899
00007f0145bd6771  call 0x00007F0145A0A4B0
00007f0145bd6776  jmp 0x00007F0145BD58DD
00007f0145bd677b  call 0x00007F0145A09240
00007f0145bd6780  jmp 0x00007F0145BD58E7
00007f0145bd6785  call 0x00007F0145AB47C0
00007f0145bd678a  jmp 0x00007F0145BD5926
00007f0145bd678f  call 0x00007F0145A0B720
00007f0145bd6794  jmp 0x00007F0145BD593A
00007f0145bd6799  call 0x00007F0145ABFC30
00007f0145bd679e  jmp 0x00007F0145BD5958
00007f0145bd67a3  call 0x00007F0145ABE9C0
00007f0145bd67a8  jmp 0x00007F0145BD5962
00007f0145bd67ad  call 0x00007F0145ABD750
00007f0145bd67b2  jmp 0x00007F0145BD596C
00007f0145bd67b7  sub rsp, 0x08
00007f0145bd67bb  push rax
00007f0145bd67bc  push rcx
00007f0145bd67bd  push rdx
00007f0145bd67be  push rdi
00007f0145bd67bf  push rsi
00007f0145bd67c0  push r8
00007f0145bd67c2  push r9
00007f0145bd67c4  push r10
00007f0145bd67c6  push r11
00007f0145bd67c8  sub rsp, 0xF0
00007f0145bd67cf  vmovaps [rsp], xmm0
00007f0145bd67d4  vmovaps [rsp+0x10], xmm1
00007f0145bd67da  vmovaps [rsp+0x20], xmm2
00007f0145bd67e0  vmovaps [rsp+0x30], xmm3
00007f0145bd67e6  vmovaps [rsp+0x40], xmm4
00007f0145bd67ec  vmovaps [rsp+0x50], xmm5
00007f0145bd67f2  vmovaps [rsp+0x60], xmm6
00007f0145bd67f8  vmovaps [rsp+0x70], xmm7
00007f0145bd67fe  vmovaps [rsp+0x80], xmm9
00007f0145bd6807  vmovaps [rsp+0x90], xmm10
00007f0145bd6810  vmovaps [rsp+0xA0], xmm11
00007f0145bd6819  vmovaps [rsp+0xB0], xmm12
00007f0145bd6822  vmovaps [rsp+0xC0], xmm13
00007f0145bd682b  vmovaps [rsp+0xD0], xmm14
00007f0145bd6834  vmovaps [rsp+0xE0], xmm15
00007f0145bd683d  sub rsp, 0x30
00007f0145bd6841  movaps [rsp], xmm8
00007f0145bd6846  movaps [rsp+0x10], xmm12
00007f0145bd684c  movaps [rsp+0x20], xmm15
00007f0145bd6852  lea rdi, [rsp]
00007f0145bd6856  mov esi, 0x00
00007f0145bd685b  mov rax, 0x636570E98530
00007f0145bd6865  call rax
00007f0145bd6867  movaps xmm8, [rsp]
00007f0145bd686c  add rsp, 0x30
00007f0145bd6870  vmovaps xmm0, [rsp]
00007f0145bd6875  vmovaps xmm1, [rsp+0x10]
00007f0145bd687b  vmovaps xmm2, [rsp+0x20]
00007f0145bd6881  vmovaps xmm3, [rsp+0x30]
00007f0145bd6887  vmovaps xmm4, [rsp+0x40]
00007f0145bd688d  vmovaps xmm5, [rsp+0x50]
00007f0145bd6893  vmovaps xmm6, [rsp+0x60]
00007f0145bd6899  vmovaps xmm7, [rsp+0x70]
00007f0145bd689f  vmovaps xmm9, [rsp+0x80]
00007f0145bd68a8  vmovaps xmm10, [rsp+0x90]
00007f0145bd68b1  vmovaps xmm11, [rsp+0xA0]
00007f0145bd68ba  vmovaps xmm12, [rsp+0xB0]
00007f0145bd68c3  vmovaps xmm13, [rsp+0xC0]
00007f0145bd68cc  vmovaps xmm14, [rsp+0xD0]
00007f0145bd68d5  vmovaps xmm15, [rsp+0xE0]
00007f0145bd68de  add rsp, 0xF0
00007f0145bd68e5  pop r11
00007f0145bd68e7  pop r10
00007f0145bd68e9  pop r9
00007f0145bd68eb  pop r8
00007f0145bd68ed  pop rsi
00007f0145bd68ee  pop rdi
00007f0145bd68ef  pop rdx
00007f0145bd68f0  pop rcx
00007f0145bd68f1  pop rax
00007f0145bd68f2  add rsp, 0x08
00007f0145bd68f6  jmp 0x00007F0145BD599A
00007f0145bd68fb  sub rsp, 0x08
00007f0145bd68ff  push rax
00007f0145bd6900  push rcx
00007f0145bd6901  push rdx
00007f0145bd6902  push rdi
00007f0145bd6903  push rsi
00007f0145bd6904  push r8
00007f0145bd6906  push r9
00007f0145bd6908  push r10
00007f0145bd690a  push r11
00007f0145bd690c  sub rsp, 0xF0
00007f0145bd6913  vmovaps [rsp], xmm0
00007f0145bd6918  vmovaps [rsp+0x10], xmm1
00007f0145bd691e  vmovaps [rsp+0x20], xmm2
00007f0145bd6924  vmovaps [rsp+0x30], xmm3
00007f0145bd692a  vmovaps [rsp+0x40], xmm4
00007f0145bd6930  vmovaps [rsp+0x50], xmm5
00007f0145bd6936  vmovaps [rsp+0x60], xmm6
00007f0145bd693c  vmovaps [rsp+0x70], xmm8
00007f0145bd6942  vmovaps [rsp+0x80], xmm9
00007f0145bd694b  vmovaps [rsp+0x90], xmm10
00007f0145bd6954  vmovaps [rsp+0xA0], xmm11
00007f0145bd695d  vmovaps [rsp+0xB0], xmm12
00007f0145bd6966  vmovaps [rsp+0xC0], xmm13
00007f0145bd696f  vmovaps [rsp+0xD0], xmm14
00007f0145bd6978  vmovaps [rsp+0xE0], xmm15
00007f0145bd6981  sub rsp, 0x30
00007f0145bd6985  movaps [rsp], xmm7
00007f0145bd6989  movaps [rsp+0x10], xmm9
00007f0145bd698f  movaps [rsp+0x20], xmm15
00007f0145bd6995  lea rdi, [rsp]
00007f0145bd6999  mov esi, 0x00
00007f0145bd699e  mov rax, 0x636570E98530
00007f0145bd69a8  call rax
00007f0145bd69aa  movaps xmm7, [rsp]
00007f0145bd69ae  add rsp, 0x30
00007f0145bd69b2  vmovaps xmm0, [rsp]
00007f0145bd69b7  vmovaps xmm1, [rsp+0x10]
00007f0145bd69bd  vmovaps xmm2, [rsp+0x20]
00007f0145bd69c3  vmovaps xmm3, [rsp+0x30]
00007f0145bd69c9  vmovaps xmm4, [rsp+0x40]
00007f0145bd69cf  vmovaps xmm5, [rsp+0x50]
00007f0145bd69d5  vmovaps xmm6, [rsp+0x60]
00007f0145bd69db  vmovaps xmm8, [rsp+0x70]
00007f0145bd69e1  vmovaps xmm9, [rsp+0x80]
00007f0145bd69ea  vmovaps xmm10, [rsp+0x90]
00007f0145bd69f3  vmovaps xmm11, [rsp+0xA0]
00007f0145bd69fc  vmovaps xmm12, [rsp+0xB0]
00007f0145bd6a05  vmovaps xmm13, [rsp+0xC0]
00007f0145bd6a0e  vmovaps xmm14, [rsp+0xD0]
00007f0145bd6a17  vmovaps xmm15, [rsp+0xE0]
00007f0145bd6a20  add rsp, 0xF0
00007f0145bd6a27  pop r11
00007f0145bd6a29  pop r10
00007f0145bd6a2b  pop r9
00007f0145bd6a2d  pop r8
00007f0145bd6a2f  pop rsi
00007f0145bd6a30  pop rdi
00007f0145bd6a31  pop rdx
00007f0145bd6a32  pop rcx
00007f0145bd6a33  pop rax
00007f0145bd6a34  add rsp, 0x08
00007f0145bd6a38  jmp 0x00007F0145BD59C8
00007f0145bd6a3d  sub rsp, 0x08
00007f0145bd6a41  push rax
00007f0145bd6a42  push rcx
00007f0145bd6a43  push rdx
00007f0145bd6a44  push rdi
00007f0145bd6a45  push rsi
00007f0145bd6a46  push r8
00007f0145bd6a48  push r9
00007f0145bd6a4a  push r10
00007f0145bd6a4c  push r11
00007f0145bd6a4e  sub rsp, 0xF0
00007f0145bd6a55  vmovaps [rsp], xmm0
00007f0145bd6a5a  vmovaps [rsp+0x10], xmm1
00007f0145bd6a60  vmovaps [rsp+0x20], xmm2
00007f0145bd6a66  vmovaps [rsp+0x30], xmm3
00007f0145bd6a6c  vmovaps [rsp+0x40], xmm4
00007f0145bd6a72  vmovaps [rsp+0x50], xmm5
00007f0145bd6a78  vmovaps [rsp+0x60], xmm6
00007f0145bd6a7e  vmovaps [rsp+0x70], xmm7
00007f0145bd6a84  vmovaps [rsp+0x80], xmm8
00007f0145bd6a8d  vmovaps [rsp+0x90], xmm10
00007f0145bd6a96  vmovaps [rsp+0xA0], xmm11
00007f0145bd6a9f  vmovaps [rsp+0xB0], xmm12
00007f0145bd6aa8  vmovaps [rsp+0xC0], xmm13
00007f0145bd6ab1  vmovaps [rsp+0xD0], xmm14
00007f0145bd6aba  vmovaps [rsp+0xE0], xmm15
00007f0145bd6ac3  sub rsp, 0x30
00007f0145bd6ac7  movaps [rsp], xmm9
00007f0145bd6acc  movaps [rsp+0x10], xmm12
00007f0145bd6ad2  movaps [rsp+0x20], xmm10
00007f0145bd6ad8  lea rdi, [rsp]
00007f0145bd6adc  mov esi, 0x00
00007f0145bd6ae1  mov rax, 0x636570E98530
00007f0145bd6aeb  call rax
00007f0145bd6aed  movaps xmm9, [rsp]
00007f0145bd6af2  add rsp, 0x30
00007f0145bd6af6  vmovaps xmm0, [rsp]
00007f0145bd6afb  vmovaps xmm1, [rsp+0x10]
00007f0145bd6b01  vmovaps xmm2, [rsp+0x20]
00007f0145bd6b07  vmovaps xmm3, [rsp+0x30]
00007f0145bd6b0d  vmovaps xmm4, [rsp+0x40]
00007f0145bd6b13  vmovaps xmm5, [rsp+0x50]
00007f0145bd6b19  vmovaps xmm6, [rsp+0x60]
00007f0145bd6b1f  vmovaps xmm7, [rsp+0x70]
00007f0145bd6b25  vmovaps xmm8, [rsp+0x80]
00007f0145bd6b2e  vmovaps xmm10, [rsp+0x90]
00007f0145bd6b37  vmovaps xmm11, [rsp+0xA0]
00007f0145bd6b40  vmovaps xmm12, [rsp+0xB0]
00007f0145bd6b49  vmovaps xmm13, [rsp+0xC0]
00007f0145bd6b52  vmovaps xmm14, [rsp+0xD0]
00007f0145bd6b5b  vmovaps xmm15, [rsp+0xE0]
00007f0145bd6b64  add rsp, 0xF0
00007f0145bd6b6b  pop r11
00007f0145bd6b6d  pop r10
00007f0145bd6b6f  pop r9
00007f0145bd6b71  pop r8
00007f0145bd6b73  pop rsi
00007f0145bd6b74  pop rdi
00007f0145bd6b75  pop rdx
00007f0145bd6b76  pop rcx
00007f0145bd6b77  pop rax
00007f0145bd6b78  add rsp, 0x08
00007f0145bd6b7c  jmp 0x00007F0145BD59EC
00007f0145bd6b81  sub rsp, 0x08
00007f0145bd6b85  push rax
00007f0145bd6b86  push rcx
00007f0145bd6b87  push rdx
00007f0145bd6b88  push rdi
00007f0145bd6b89  push rsi
00007f0145bd6b8a  push r8
00007f0145bd6b8c  push r9
00007f0145bd6b8e  push r10
00007f0145bd6b90  push r11
00007f0145bd6b92  sub rsp, 0xF0
00007f0145bd6b99  vmovaps [rsp], xmm0
00007f0145bd6b9e  vmovaps [rsp+0x10], xmm1
00007f0145bd6ba4  vmovaps [rsp+0x20], xmm2
00007f0145bd6baa  vmovaps [rsp+0x30], xmm3
00007f0145bd6bb0  vmovaps [rsp+0x40], xmm4
00007f0145bd6bb6  vmovaps [rsp+0x50], xmm5
00007f0145bd6bbc  vmovaps [rsp+0x60], xmm6
00007f0145bd6bc2  vmovaps [rsp+0x70], xmm7
00007f0145bd6bc8  vmovaps [rsp+0x80], xmm8
00007f0145bd6bd1  vmovaps [rsp+0x90], xmm9
00007f0145bd6bda  vmovaps [rsp+0xA0], xmm11
00007f0145bd6be3  vmovaps [rsp+0xB0], xmm12
00007f0145bd6bec  vmovaps [rsp+0xC0], xmm13
00007f0145bd6bf5  vmovaps [rsp+0xD0], xmm14
00007f0145bd6bfe  vmovaps [rsp+0xE0], xmm15
00007f0145bd6c07  sub rsp, 0x30
00007f0145bd6c0b  movaps [rsp], xmm10
00007f0145bd6c10  movaps [rsp+0x10], xmm12
00007f0145bd6c16  movaps [rsp+0x20], xmm11
00007f0145bd6c1c  lea rdi, [rsp]
00007f0145bd6c20  mov esi, 0x00
00007f0145bd6c25  mov rax, 0x636570E98530
00007f0145bd6c2f  call rax
00007f0145bd6c31  movaps xmm10, [rsp]
00007f0145bd6c36  add rsp, 0x30
00007f0145bd6c3a  vmovaps xmm0, [rsp]
00007f0145bd6c3f  vmovaps xmm1, [rsp+0x10]
00007f0145bd6c45  vmovaps xmm2, [rsp+0x20]
00007f0145bd6c4b  vmovaps xmm3, [rsp+0x30]
00007f0145bd6c51  vmovaps xmm4, [rsp+0x40]
00007f0145bd6c57  vmovaps xmm5, [rsp+0x50]
00007f0145bd6c5d  vmovaps xmm6, [rsp+0x60]
00007f0145bd6c63  vmovaps xmm7, [rsp+0x70]
00007f0145bd6c69  vmovaps xmm8, [rsp+0x80]
00007f0145bd6c72  vmovaps xmm9, [rsp+0x90]
00007f0145bd6c7b  vmovaps xmm11, [rsp+0xA0]
00007f0145bd6c84  vmovaps xmm12, [rsp+0xB0]
00007f0145bd6c8d  vmovaps xmm13, [rsp+0xC0]
00007f0145bd6c96  vmovaps xmm14, [rsp+0xD0]
00007f0145bd6c9f  vmovaps xmm15, [rsp+0xE0]
00007f0145bd6ca8  add rsp, 0xF0
00007f0145bd6caf  pop r11
00007f0145bd6cb1  pop r10
00007f0145bd6cb3  pop r9
00007f0145bd6cb5  pop r8
00007f0145bd6cb7  pop rsi
00007f0145bd6cb8  pop rdi
00007f0145bd6cb9  pop rdx
00007f0145bd6cba  pop rcx
00007f0145bd6cbb  pop rax
00007f0145bd6cbc  add rsp, 0x08
00007f0145bd6cc0  jmp 0x00007F0145BD5A06
00007f0145bd6cc5  sub rsp, 0x08
00007f0145bd6cc9  push rax
00007f0145bd6cca  push rcx
00007f0145bd6ccb  push rdx
00007f0145bd6ccc  push rdi
00007f0145bd6ccd  push rsi
00007f0145bd6cce  push r8
00007f0145bd6cd0  push r9
00007f0145bd6cd2  push r10
00007f0145bd6cd4  push r11
00007f0145bd6cd6  sub rsp, 0xF0
00007f0145bd6cdd  vmovaps [rsp], xmm0
00007f0145bd6ce2  vmovaps [rsp+0x10], xmm1
00007f0145bd6ce8  vmovaps [rsp+0x20], xmm2
00007f0145bd6cee  vmovaps [rsp+0x30], xmm3
00007f0145bd6cf4  vmovaps [rsp+0x40], xmm4
00007f0145bd6cfa  vmovaps [rsp+0x50], xmm5
00007f0145bd6d00  vmovaps [rsp+0x60], xmm7
00007f0145bd6d06  vmovaps [rsp+0x70], xmm8
00007f0145bd6d0c  vmovaps [rsp+0x80], xmm9
00007f0145bd6d15  vmovaps [rsp+0x90], xmm10
00007f0145bd6d1e  vmovaps [rsp+0xA0], xmm11
00007f0145bd6d27  vmovaps [rsp+0xB0], xmm12
00007f0145bd6d30  vmovaps [rsp+0xC0], xmm13
00007f0145bd6d39  vmovaps [rsp+0xD0], xmm14
00007f0145bd6d42  vmovaps [rsp+0xE0], xmm15
00007f0145bd6d4b  sub rsp, 0x30
00007f0145bd6d4f  movaps [rsp], xmm6
00007f0145bd6d53  movaps [rsp+0x10], xmm12
00007f0145bd6d59  movaps [rsp+0x20], xmm11
00007f0145bd6d5f  lea rdi, [rsp]
00007f0145bd6d63  mov esi, 0x00
00007f0145bd6d68  mov rax, 0x636570E98530
00007f0145bd6d72  call rax
00007f0145bd6d74  movaps xmm6, [rsp]
00007f0145bd6d78  add rsp, 0x30
00007f0145bd6d7c  vmovaps xmm0, [rsp]
00007f0145bd6d81  vmovaps xmm1, [rsp+0x10]
00007f0145bd6d87  vmovaps xmm2, [rsp+0x20]
00007f0145bd6d8d  vmovaps xmm3, [rsp+0x30]
00007f0145bd6d93  vmovaps xmm4, [rsp+0x40]
00007f0145bd6d99  vmovaps xmm5, [rsp+0x50]
00007f0145bd6d9f  vmovaps xmm7, [rsp+0x60]
00007f0145bd6da5  vmovaps xmm8, [rsp+0x70]
00007f0145bd6dab  vmovaps xmm9, [rsp+0x80]
00007f0145bd6db4  vmovaps xmm10, [rsp+0x90]
00007f0145bd6dbd  vmovaps xmm11, [rsp+0xA0]
00007f0145bd6dc6  vmovaps xmm12, [rsp+0xB0]
00007f0145bd6dcf  vmovaps xmm13, [rsp+0xC0]
00007f0145bd6dd8  vmovaps xmm14, [rsp+0xD0]
00007f0145bd6de1  vmovaps xmm15, [rsp+0xE0]
00007f0145bd6dea  add rsp, 0xF0
00007f0145bd6df1  pop r11
00007f0145bd6df3  pop r10
00007f0145bd6df5  pop r9
00007f0145bd6df7  pop r8
00007f0145bd6df9  pop rsi
00007f0145bd6dfa  pop rdi
00007f0145bd6dfb  pop rdx
00007f0145bd6dfc  pop rcx
00007f0145bd6dfd  pop rax
00007f0145bd6dfe  add rsp, 0x08
00007f0145bd6e02  jmp 0x00007F0145BD5A27
00007f0145bd6e07  sub rsp, 0x08
00007f0145bd6e0b  push rax
00007f0145bd6e0c  push rcx
00007f0145bd6e0d  push rdx
00007f0145bd6e0e  push rdi
00007f0145bd6e0f  push rsi
00007f0145bd6e10  push r8
00007f0145bd6e12  push r9
00007f0145bd6e14  push r10
00007f0145bd6e16  push r11
00007f0145bd6e18  sub rsp, 0xF0
00007f0145bd6e1f  vmovaps [rsp], xmm0
00007f0145bd6e24  vmovaps [rsp+0x10], xmm1
00007f0145bd6e2a  vmovaps [rsp+0x20], xmm2
00007f0145bd6e30  vmovaps [rsp+0x30], xmm4
00007f0145bd6e36  vmovaps [rsp+0x40], xmm5
00007f0145bd6e3c  vmovaps [rsp+0x50], xmm6
00007f0145bd6e42  vmovaps [rsp+0x60], xmm7
00007f0145bd6e48  vmovaps [rsp+0x70], xmm8
00007f0145bd6e4e  vmovaps [rsp+0x80], xmm9
00007f0145bd6e57  vmovaps [rsp+0x90], xmm10
00007f0145bd6e60  vmovaps [rsp+0xA0], xmm11
00007f0145bd6e69  vmovaps [rsp+0xB0], xmm12
00007f0145bd6e72  vmovaps [rsp+0xC0], xmm13
00007f0145bd6e7b  vmovaps [rsp+0xD0], xmm14
00007f0145bd6e84  vmovaps [rsp+0xE0], xmm15
00007f0145bd6e8d  sub rsp, 0x30
00007f0145bd6e91  movaps [rsp], xmm3
00007f0145bd6e95  movaps [rsp+0x10], xmm5
00007f0145bd6e9a  movaps [rsp+0x20], xmm4
00007f0145bd6e9f  lea rdi, [rsp]
00007f0145bd6ea3  mov esi, 0x00
00007f0145bd6ea8  mov rax, 0x636570E98530
00007f0145bd6eb2  call rax
00007f0145bd6eb4  movaps xmm3, [rsp]
00007f0145bd6eb8  add rsp, 0x30
00007f0145bd6ebc  vmovaps xmm0, [rsp]
00007f0145bd6ec1  vmovaps xmm1, [rsp+0x10]
00007f0145bd6ec7  vmovaps xmm2, [rsp+0x20]
00007f0145bd6ecd  vmovaps xmm4, [rsp+0x30]
00007f0145bd6ed3  vmovaps xmm5, [rsp+0x40]
00007f0145bd6ed9  vmovaps xmm6, [rsp+0x50]
00007f0145bd6edf  vmovaps xmm7, [rsp+0x60]
00007f0145bd6ee5  vmovaps xmm8, [rsp+0x70]
00007f0145bd6eeb  vmovaps xmm9, [rsp+0x80]
00007f0145bd6ef4  vmovaps xmm10, [rsp+0x90]
00007f0145bd6efd  vmovaps xmm11, [rsp+0xA0]
00007f0145bd6f06  vmovaps xmm12, [rsp+0xB0]
00007f0145bd6f0f  vmovaps xmm13, [rsp+0xC0]
00007f0145bd6f18  vmovaps xmm14, [rsp+0xD0]
00007f0145bd6f21  vmovaps xmm15, [rsp+0xE0]
00007f0145bd6f2a  add rsp, 0xF0
00007f0145bd6f31  pop r11
00007f0145bd6f33  pop r10
00007f0145bd6f35  pop r9
00007f0145bd6f37  pop r8
00007f0145bd6f39  pop rsi
00007f0145bd6f3a  pop rdi
00007f0145bd6f3b  pop rdx
00007f0145bd6f3c  pop rcx
00007f0145bd6f3d  pop rax
00007f0145bd6f3e  add rsp, 0x08
00007f0145bd6f42  jmp 0x00007F0145BD5A88
00007f0145bd6f47  sub rsp, 0x08
00007f0145bd6f4b  push rax
00007f0145bd6f4c  push rcx
00007f0145bd6f4d  push rdx
00007f0145bd6f4e  push rdi
00007f0145bd6f4f  push rsi
00007f0145bd6f50  push r8
00007f0145bd6f52  push r9
00007f0145bd6f54  push r10
00007f0145bd6f56  push r11
00007f0145bd6f58  sub rsp, 0xF0
00007f0145bd6f5f  vmovaps [rsp], xmm0
00007f0145bd6f64  vmovaps [rsp+0x10], xmm1
00007f0145bd6f6a  vmovaps [rsp+0x20], xmm2
00007f0145bd6f70  vmovaps [rsp+0x30], xmm3
00007f0145bd6f76  vmovaps [rsp+0x40], xmm4
00007f0145bd6f7c  vmovaps [rsp+0x50], xmm6
00007f0145bd6f82  vmovaps [rsp+0x60], xmm7
00007f0145bd6f88  vmovaps [rsp+0x70], xmm8
00007f0145bd6f8e  vmovaps [rsp+0x80], xmm9
00007f0145bd6f97  vmovaps [rsp+0x90], xmm10
00007f0145bd6fa0  vmovaps [rsp+0xA0], xmm11
00007f0145bd6fa9  vmovaps [rsp+0xB0], xmm12
00007f0145bd6fb2  vmovaps [rsp+0xC0], xmm13
00007f0145bd6fbb  vmovaps [rsp+0xD0], xmm14
00007f0145bd6fc4  vmovaps [rsp+0xE0], xmm15
00007f0145bd6fcd  sub rsp, 0x30
00007f0145bd6fd1  movaps [rsp], xmm5
00007f0145bd6fd5  movaps [rsp+0x10], xmm8
00007f0145bd6fdb  movaps [rsp+0x20], xmm15
00007f0145bd6fe1  lea rdi, [rsp]
00007f0145bd6fe5  mov esi, 0x00
00007f0145bd6fea  mov rax, 0x636570E98530
00007f0145bd6ff4  call rax
00007f0145bd6ff6  movaps xmm5, [rsp]
00007f0145bd6ffa  add rsp, 0x30
00007f0145bd6ffe  vmovaps xmm0, [rsp]
00007f0145bd7003  vmovaps xmm1, [rsp+0x10]
00007f0145bd7009  vmovaps xmm2, [rsp+0x20]
00007f0145bd700f  vmovaps xmm3, [rsp+0x30]
00007f0145bd7015  vmovaps xmm4, [rsp+0x40]
00007f0145bd701b  vmovaps xmm6, [rsp+0x50]
00007f0145bd7021  vmovaps xmm7, [rsp+0x60]
00007f0145bd7027  vmovaps xmm8, [rsp+0x70]
00007f0145bd702d  vmovaps xmm9, [rsp+0x80]
00007f0145bd7036  vmovaps xmm10, [rsp+0x90]
00007f0145bd703f  vmovaps xmm11, [rsp+0xA0]
00007f0145bd7048  vmovaps xmm12, [rsp+0xB0]
00007f0145bd7051  vmovaps xmm13, [rsp+0xC0]
00007f0145bd705a  vmovaps xmm14, [rsp+0xD0]
00007f0145bd7063  vmovaps xmm15, [rsp+0xE0]
00007f0145bd706c  add rsp, 0xF0
00007f0145bd7073  pop r11
00007f0145bd7075  pop r10
00007f0145bd7077  pop r9
00007f0145bd7079  pop r8
00007f0145bd707b  pop rsi
00007f0145bd707c  pop rdi
00007f0145bd707d  pop rdx
00007f0145bd707e  pop rcx
00007f0145bd707f  pop rax
00007f0145bd7080  add rsp, 0x08
00007f0145bd7084  jmp 0x00007F0145BD5AC0
00007f0145bd7089  sub rsp, 0x08
00007f0145bd708d  push rax
00007f0145bd708e  push rcx
00007f0145bd708f  push rdx
00007f0145bd7090  push rdi
00007f0145bd7091  push rsi
00007f0145bd7092  push r8
00007f0145bd7094  push r9
00007f0145bd7096  push r10
00007f0145bd7098  push r11
00007f0145bd709a  sub rsp, 0xF0
00007f0145bd70a1  vmovaps [rsp], xmm0
00007f0145bd70a6  vmovaps [rsp+0x10], xmm1
00007f0145bd70ac  vmovaps [rsp+0x20], xmm2
00007f0145bd70b2  vmovaps [rsp+0x30], xmm3
00007f0145bd70b8  vmovaps [rsp+0x40], xmm5
00007f0145bd70be  vmovaps [rsp+0x50], xmm6
00007f0145bd70c4  vmovaps [rsp+0x60], xmm7
00007f0145bd70ca  vmovaps [rsp+0x70], xmm8
00007f0145bd70d0  vmovaps [rsp+0x80], xmm9
00007f0145bd70d9  vmovaps [rsp+0x90], xmm10
00007f0145bd70e2  vmovaps [rsp+0xA0], xmm11
00007f0145bd70eb  vmovaps [rsp+0xB0], xmm12
00007f0145bd70f4  vmovaps [rsp+0xC0], xmm13
00007f0145bd70fd  vmovaps [rsp+0xD0], xmm14
00007f0145bd7106  vmovaps [rsp+0xE0], xmm15
00007f0145bd710f  sub rsp, 0x30
00007f0145bd7113  movaps [rsp], xmm4
00007f0145bd7117  movaps [rsp+0x10], xmm9
00007f0145bd711d  movaps [rsp+0x20], xmm8
00007f0145bd7123  lea rdi, [rsp]
00007f0145bd7127  mov esi, 0x00
00007f0145bd712c  mov rax, 0x636570E98530
00007f0145bd7136  call rax
00007f0145bd7138  movaps xmm4, [rsp]
00007f0145bd713c  add rsp, 0x30
00007f0145bd7140  vmovaps xmm0, [rsp]
00007f0145bd7145  vmovaps xmm1, [rsp+0x10]
00007f0145bd714b  vmovaps xmm2, [rsp+0x20]
00007f0145bd7151  vmovaps xmm3, [rsp+0x30]
00007f0145bd7157  vmovaps xmm5, [rsp+0x40]
00007f0145bd715d  vmovaps xmm6, [rsp+0x50]
00007f0145bd7163  vmovaps xmm7, [rsp+0x60]
00007f0145bd7169  vmovaps xmm8, [rsp+0x70]
00007f0145bd716f  vmovaps xmm9, [rsp+0x80]
00007f0145bd7178  vmovaps xmm10, [rsp+0x90]
00007f0145bd7181  vmovaps xmm11, [rsp+0xA0]
00007f0145bd718a  vmovaps xmm12, [rsp+0xB0]
00007f0145bd7193  vmovaps xmm13, [rsp+0xC0]
00007f0145bd719c  vmovaps xmm14, [rsp+0xD0]
00007f0145bd71a5  vmovaps xmm15, [rsp+0xE0]
00007f0145bd71ae  add rsp, 0xF0
00007f0145bd71b5  pop r11
00007f0145bd71b7  pop r10
00007f0145bd71b9  pop r9
00007f0145bd71bb  pop r8
00007f0145bd71bd  pop rsi
00007f0145bd71be  pop rdi
00007f0145bd71bf  pop rdx
00007f0145bd71c0  pop rcx
00007f0145bd71c1  pop rax
00007f0145bd71c2  add rsp, 0x08
00007f0145bd71c6  jmp 0x00007F0145BD5AE1
00007f0145bd71cb  sub rsp, 0x08
00007f0145bd71cf  push rax
00007f0145bd71d0  push rcx
00007f0145bd71d1  push rdx
00007f0145bd71d2  push rdi
00007f0145bd71d3  push rsi
00007f0145bd71d4  push r8
00007f0145bd71d6  push r9
00007f0145bd71d8  push r10
00007f0145bd71da  push r11
00007f0145bd71dc  sub rsp, 0xF0
00007f0145bd71e3  vmovaps [rsp], xmm0
00007f0145bd71e8  vmovaps [rsp+0x10], xmm1
00007f0145bd71ee  vmovaps [rsp+0x20], xmm2
00007f0145bd71f4  vmovaps [rsp+0x30], xmm3
00007f0145bd71fa  vmovaps [rsp+0x40], xmm4
00007f0145bd7200  vmovaps [rsp+0x50], xmm5
00007f0145bd7206  vmovaps [rsp+0x60], xmm6
00007f0145bd720c  vmovaps [rsp+0x70], xmm7
00007f0145bd7212  vmovaps [rsp+0x80], xmm8
00007f0145bd721b  vmovaps [rsp+0x90], xmm10
00007f0145bd7224  vmovaps [rsp+0xA0], xmm11
00007f0145bd722d  vmovaps [rsp+0xB0], xmm12
00007f0145bd7236  vmovaps [rsp+0xC0], xmm13
00007f0145bd723f  vmovaps [rsp+0xD0], xmm14
00007f0145bd7248  vmovaps [rsp+0xE0], xmm15
00007f0145bd7251  sub rsp, 0x30
00007f0145bd7255  movaps [rsp], xmm9
00007f0145bd725a  movaps [rsp+0x10], xmm10
00007f0145bd7260  movaps [rsp+0x20], xmm8
00007f0145bd7266  lea rdi, [rsp]
00007f0145bd726a  mov esi, 0x00
00007f0145bd726f  mov rax, 0x636570E98530
00007f0145bd7279  call rax
00007f0145bd727b  movaps xmm9, [rsp]
00007f0145bd7280  add rsp, 0x30
00007f0145bd7284  vmovaps xmm0, [rsp]
00007f0145bd7289  vmovaps xmm1, [rsp+0x10]
00007f0145bd728f  vmovaps xmm2, [rsp+0x20]
00007f0145bd7295  vmovaps xmm3, [rsp+0x30]
00007f0145bd729b  vmovaps xmm4, [rsp+0x40]
00007f0145bd72a1  vmovaps xmm5, [rsp+0x50]
00007f0145bd72a7  vmovaps xmm6, [rsp+0x60]
00007f0145bd72ad  vmovaps xmm7, [rsp+0x70]
00007f0145bd72b3  vmovaps xmm8, [rsp+0x80]
00007f0145bd72bc  vmovaps xmm10, [rsp+0x90]
00007f0145bd72c5  vmovaps xmm11, [rsp+0xA0]
00007f0145bd72ce  vmovaps xmm12, [rsp+0xB0]
00007f0145bd72d7  vmovaps xmm13, [rsp+0xC0]
00007f0145bd72e0  vmovaps xmm14, [rsp+0xD0]
00007f0145bd72e9  vmovaps xmm15, [rsp+0xE0]
00007f0145bd72f2  add rsp, 0xF0
00007f0145bd72f9  pop r11
00007f0145bd72fb  pop r10
00007f0145bd72fd  pop r9
00007f0145bd72ff  pop r8
00007f0145bd7301  pop rsi
00007f0145bd7302  pop rdi
00007f0145bd7303  pop rdx
00007f0145bd7304  pop rcx
00007f0145bd7305  pop rax
00007f0145bd7306  add rsp, 0x08
00007f0145bd730a  jmp 0x00007F0145BD5AFB
00007f0145bd730f  call 0x00007F0145AD64F0
00007f0145bd7314  jmp 0x00007F0145BD5C15
00007f0145bd7319  call 0x00007F0145AD64F0
00007f0145bd731e  jmp 0x00007F0145BD5C2B
00007f0145bd7323  sub rsp, 0x08
00007f0145bd7327  push rax
00007f0145bd7328  push rcx
00007f0145bd7329  push rdx
00007f0145bd732a  push rdi
00007f0145bd732b  push rsi
00007f0145bd732c  push r8
00007f0145bd732e  push r9
00007f0145bd7330  push r10
00007f0145bd7332  push r11
00007f0145bd7334  sub rsp, 0xF0
00007f0145bd733b  vmovaps [rsp], xmm0
00007f0145bd7340  vmovaps [rsp+0x10], xmm2
00007f0145bd7346  vmovaps [rsp+0x20], xmm3
00007f0145bd734c  vmovaps [rsp+0x30], xmm4
00007f0145bd7352  vmovaps [rsp+0x40], xmm5
00007f0145bd7358  vmovaps [rsp+0x50], xmm6
00007f0145bd735e  vmovaps [rsp+0x60], xmm7
00007f0145bd7364  vmovaps [rsp+0x70], xmm8
00007f0145bd736a  vmovaps [rsp+0x80], xmm9
00007f0145bd7373  vmovaps [rsp+0x90], xmm10
00007f0145bd737c  vmovaps [rsp+0xA0], xmm11
00007f0145bd7385  vmovaps [rsp+0xB0], xmm12
00007f0145bd738e  vmovaps [rsp+0xC0], xmm13
00007f0145bd7397  vmovaps [rsp+0xD0], xmm14
00007f0145bd73a0  vmovaps [rsp+0xE0], xmm15
00007f0145bd73a9  sub rsp, 0x30
00007f0145bd73ad  movaps [rsp], xmm1
00007f0145bd73b1  movaps [rsp+0x10], xmm6
00007f0145bd73b6  movaps [rsp+0x20], xmm15
00007f0145bd73bc  lea rdi, [rsp]
00007f0145bd73c0  mov esi, 0x00
00007f0145bd73c5  mov rax, 0x636570E98530
00007f0145bd73cf  call rax
00007f0145bd73d1  movaps xmm1, [rsp]
00007f0145bd73d5  add rsp, 0x30
00007f0145bd73d9  vmovaps xmm0, [rsp]
00007f0145bd73de  vmovaps xmm2, [rsp+0x10]
00007f0145bd73e4  vmovaps xmm3, [rsp+0x20]
00007f0145bd73ea  vmovaps xmm4, [rsp+0x30]
00007f0145bd73f0  vmovaps xmm5, [rsp+0x40]
00007f0145bd73f6  vmovaps xmm6, [rsp+0x50]
00007f0145bd73fc  vmovaps xmm7, [rsp+0x60]
00007f0145bd7402  vmovaps xmm8, [rsp+0x70]
00007f0145bd7408  vmovaps xmm9, [rsp+0x80]
00007f0145bd7411  vmovaps xmm10, [rsp+0x90]
00007f0145bd741a  vmovaps xmm11, [rsp+0xA0]
00007f0145bd7423  vmovaps xmm12, [rsp+0xB0]
00007f0145bd742c  vmovaps xmm13, [rsp+0xC0]
00007f0145bd7435  vmovaps xmm14, [rsp+0xD0]
00007f0145bd743e  vmovaps xmm15, [rsp+0xE0]
00007f0145bd7447  add rsp, 0xF0
00007f0145bd744e  pop r11
00007f0145bd7450  pop r10
00007f0145bd7452  pop r9
00007f0145bd7454  pop r8
00007f0145bd7456  pop rsi
00007f0145bd7457  pop rdi
00007f0145bd7458  pop rdx
00007f0145bd7459  pop rcx
00007f0145bd745a  pop rax
00007f0145bd745b  add rsp, 0x08
00007f0145bd745f  jmp 0x00007F0145BD5C68
00007f0145bd7464  call 0x00007F0145AE5820
00007f0145bd7469  jmp 0x00007F0145BD5C75
00007f0145bd746e  sub rsp, 0x08
00007f0145bd7472  push rax
00007f0145bd7473  push rcx
00007f0145bd7474  push rdx
00007f0145bd7475  push rdi
00007f0145bd7476  push rsi
00007f0145bd7477  push r8
00007f0145bd7479  push r9
00007f0145bd747b  push r10
00007f0145bd747d  push r11
00007f0145bd747f  sub rsp, 0xF0
00007f0145bd7486  vmovaps [rsp], xmm0
00007f0145bd748b  vmovaps [rsp+0x10], xmm1
00007f0145bd7491  vmovaps [rsp+0x20], xmm2
00007f0145bd7497  vmovaps [rsp+0x30], xmm3
00007f0145bd749d  vmovaps [rsp+0x40], xmm4
00007f0145bd74a3  vmovaps [rsp+0x50], xmm5
00007f0145bd74a9  vmovaps [rsp+0x60], xmm6
00007f0145bd74af  vmovaps [rsp+0x70], xmm7
00007f0145bd74b5  vmovaps [rsp+0x80], xmm8
00007f0145bd74be  vmovaps [rsp+0x90], xmm9
00007f0145bd74c7  vmovaps [rsp+0xA0], xmm10
00007f0145bd74d0  vmovaps [rsp+0xB0], xmm11
00007f0145bd74d9  vmovaps [rsp+0xC0], xmm12
00007f0145bd74e2  vmovaps [rsp+0xD0], xmm13
00007f0145bd74eb  vmovaps [rsp+0xE0], xmm15
00007f0145bd74f4  sub rsp, 0x30
00007f0145bd74f8  movaps [rsp], xmm14
00007f0145bd74fd  movaps [rsp+0x10], xmm4
00007f0145bd7502  movaps [rsp+0x20], xmm3
00007f0145bd7507  lea rdi, [rsp]
00007f0145bd750b  mov esi, 0x00
00007f0145bd7510  mov rax, 0x636570E98530
00007f0145bd751a  call rax
00007f0145bd751c  movaps xmm14, [rsp]
00007f0145bd7521  add rsp, 0x30
00007f0145bd7525  vmovaps xmm0, [rsp]
00007f0145bd752a  vmovaps xmm1, [rsp+0x10]
00007f0145bd7530  vmovaps xmm2, [rsp+0x20]
00007f0145bd7536  vmovaps xmm3, [rsp+0x30]
00007f0145bd753c  vmovaps xmm4, [rsp+0x40]
00007f0145bd7542  vmovaps xmm5, [rsp+0x50]
00007f0145bd7548  vmovaps xmm6, [rsp+0x60]
00007f0145bd754e  vmovaps xmm7, [rsp+0x70]
00007f0145bd7554  vmovaps xmm8, [rsp+0x80]
00007f0145bd755d  vmovaps xmm9, [rsp+0x90]
00007f0145bd7566  vmovaps xmm10, [rsp+0xA0]
00007f0145bd756f  vmovaps xmm11, [rsp+0xB0]
00007f0145bd7578  vmovaps xmm12, [rsp+0xC0]
00007f0145bd7581  vmovaps xmm13, [rsp+0xD0]
00007f0145bd758a  vmovaps xmm15, [rsp+0xE0]
00007f0145bd7593  add rsp, 0xF0
00007f0145bd759a  pop r11
00007f0145bd759c  pop r10
00007f0145bd759e  pop r9
00007f0145bd75a0  pop r8
00007f0145bd75a2  pop rsi
00007f0145bd75a3  pop rdi
00007f0145bd75a4  pop rdx
00007f0145bd75a5  pop rcx
00007f0145bd75a6  pop rax
00007f0145bd75a7  add rsp, 0x08
00007f0145bd75ab  jmp 0x00007F0145BD5C8F
00007f0145bd75b0  sub rsp, 0x08
00007f0145bd75b4  push rax
00007f0145bd75b5  push rcx
00007f0145bd75b6  push rdx
00007f0145bd75b7  push rdi
00007f0145bd75b8  push rsi
00007f0145bd75b9  push r8
00007f0145bd75bb  push r9
00007f0145bd75bd  push r10
00007f0145bd75bf  push r11
00007f0145bd75c1  sub rsp, 0xF0
00007f0145bd75c8  vmovaps [rsp], xmm0
00007f0145bd75cd  vmovaps [rsp+0x10], xmm1
00007f0145bd75d3  vmovaps [rsp+0x20], xmm2
00007f0145bd75d9  vmovaps [rsp+0x30], xmm3
00007f0145bd75df  vmovaps [rsp+0x40], xmm4
00007f0145bd75e5  vmovaps [rsp+0x50], xmm5
00007f0145bd75eb  vmovaps [rsp+0x60], xmm7
00007f0145bd75f1  vmovaps [rsp+0x70], xmm8
00007f0145bd75f7  vmovaps [rsp+0x80], xmm9
00007f0145bd7600  vmovaps [rsp+0x90], xmm10
00007f0145bd7609  vmovaps [rsp+0xA0], xmm11
00007f0145bd7612  vmovaps [rsp+0xB0], xmm12
00007f0145bd761b  vmovaps [rsp+0xC0], xmm13
00007f0145bd7624  vmovaps [rsp+0xD0], xmm14
00007f0145bd762d  vmovaps [rsp+0xE0], xmm15
00007f0145bd7636  sub rsp, 0x30
00007f0145bd763a  movaps [rsp], xmm6
00007f0145bd763e  movaps [rsp+0x10], xmm9
00007f0145bd7644  movaps [rsp+0x20], xmm7
00007f0145bd7649  lea rdi, [rsp]
00007f0145bd764d  mov esi, 0x00
00007f0145bd7652  mov rax, 0x636570E98530
00007f0145bd765c  call rax
00007f0145bd765e  movaps xmm6, [rsp]
00007f0145bd7662  add rsp, 0x30
00007f0145bd7666  vmovaps xmm0, [rsp]
00007f0145bd766b  vmovaps xmm1, [rsp+0x10]
00007f0145bd7671  vmovaps xmm2, [rsp+0x20]
00007f0145bd7677  vmovaps xmm3, [rsp+0x30]
00007f0145bd767d  vmovaps xmm4, [rsp+0x40]
00007f0145bd7683  vmovaps xmm5, [rsp+0x50]
00007f0145bd7689  vmovaps xmm7, [rsp+0x60]
00007f0145bd768f  vmovaps xmm8, [rsp+0x70]
00007f0145bd7695  vmovaps xmm9, [rsp+0x80]
00007f0145bd769e  vmovaps xmm10, [rsp+0x90]
00007f0145bd76a7  vmovaps xmm11, [rsp+0xA0]
00007f0145bd76b0  vmovaps xmm12, [rsp+0xB0]
00007f0145bd76b9  vmovaps xmm13, [rsp+0xC0]
00007f0145bd76c2  vmovaps xmm14, [rsp+0xD0]
00007f0145bd76cb  vmovaps xmm15, [rsp+0xE0]
00007f0145bd76d4  add rsp, 0xF0
00007f0145bd76db  pop r11
00007f0145bd76dd  pop r10
00007f0145bd76df  pop r9
00007f0145bd76e1  pop r8
00007f0145bd76e3  pop rsi
00007f0145bd76e4  pop rdi
00007f0145bd76e5  pop rdx
00007f0145bd76e6  pop rcx
00007f0145bd76e7  pop rax
00007f0145bd76e8  add rsp, 0x08
00007f0145bd76ec  jmp 0x00007F0145BD5CA7
00007f0145bd76f1  sub rsp, 0x08
00007f0145bd76f5  push rax
00007f0145bd76f6  push rcx
00007f0145bd76f7  push rdx
00007f0145bd76f8  push rdi
00007f0145bd76f9  push rsi
00007f0145bd76fa  push r8
00007f0145bd76fc  push r9
00007f0145bd76fe  push r10
00007f0145bd7700  push r11
00007f0145bd7702  sub rsp, 0xF0
00007f0145bd7709  vmovaps [rsp], xmm0
00007f0145bd770e  vmovaps [rsp+0x10], xmm1
00007f0145bd7714  vmovaps [rsp+0x20], xmm2
00007f0145bd771a  vmovaps [rsp+0x30], xmm3
00007f0145bd7720  vmovaps [rsp+0x40], xmm4
00007f0145bd7726  vmovaps [rsp+0x50], xmm5
00007f0145bd772c  vmovaps [rsp+0x60], xmm6
00007f0145bd7732  vmovaps [rsp+0x70], xmm8
00007f0145bd7738  vmovaps [rsp+0x80], xmm9
00007f0145bd7741  vmovaps [rsp+0x90], xmm10
00007f0145bd774a  vmovaps [rsp+0xA0], xmm11
00007f0145bd7753  vmovaps [rsp+0xB0], xmm12
00007f0145bd775c  vmovaps [rsp+0xC0], xmm13
00007f0145bd7765  vmovaps [rsp+0xD0], xmm14
00007f0145bd776e  vmovaps [rsp+0xE0], xmm15
00007f0145bd7777  sub rsp, 0x30
00007f0145bd777b  movaps [rsp], xmm7
00007f0145bd777f  movaps [rsp+0x10], xmm4
00007f0145bd7784  movaps [rsp+0x20], xmm9
00007f0145bd778a  lea rdi, [rsp]
00007f0145bd778e  mov esi, 0x00
00007f0145bd7793  mov rax, 0x636570E98530
00007f0145bd779d  call rax
00007f0145bd779f  movaps xmm7, [rsp]
00007f0145bd77a3  add rsp, 0x30
00007f0145bd77a7  vmovaps xmm0, [rsp]
00007f0145bd77ac  vmovaps xmm1, [rsp+0x10]
00007f0145bd77b2  vmovaps xmm2, [rsp+0x20]
00007f0145bd77b8  vmovaps xmm3, [rsp+0x30]
00007f0145bd77be  vmovaps xmm4, [rsp+0x40]
00007f0145bd77c4  vmovaps xmm5, [rsp+0x50]
00007f0145bd77ca  vmovaps xmm6, [rsp+0x60]
00007f0145bd77d0  vmovaps xmm8, [rsp+0x70]
00007f0145bd77d6  vmovaps xmm9, [rsp+0x80]
00007f0145bd77df  vmovaps xmm10, [rsp+0x90]
00007f0145bd77e8  vmovaps xmm11, [rsp+0xA0]
00007f0145bd77f1  vmovaps xmm12, [rsp+0xB0]
00007f0145bd77fa  vmovaps xmm13, [rsp+0xC0]
00007f0145bd7803  vmovaps xmm14, [rsp+0xD0]
00007f0145bd780c  vmovaps xmm15, [rsp+0xE0]
00007f0145bd7815  add rsp, 0xF0
00007f0145bd781c  pop r11
00007f0145bd781e  pop r10
00007f0145bd7820  pop r9
00007f0145bd7822  pop r8
00007f0145bd7824  pop rsi
00007f0145bd7825  pop rdi
00007f0145bd7826  pop rdx
00007f0145bd7827  pop rcx
00007f0145bd7828  pop rax
00007f0145bd7829  add rsp, 0x08
00007f0145bd782d  jmp 0x00007F0145BD5CD4
00007f0145bd7832  sub rsp, 0x08
00007f0145bd7836  push rax
00007f0145bd7837  push rcx
00007f0145bd7838  push rdx
00007f0145bd7839  push rdi
00007f0145bd783a  push rsi
00007f0145bd783b  push r8
00007f0145bd783d  push r9
00007f0145bd783f  push r10
00007f0145bd7841  push r11
00007f0145bd7843  sub rsp, 0xF0
00007f0145bd784a  vmovaps [rsp], xmm0
00007f0145bd784f  vmovaps [rsp+0x10], xmm1
00007f0145bd7855  vmovaps [rsp+0x20], xmm2
00007f0145bd785b  vmovaps [rsp+0x30], xmm3
00007f0145bd7861  vmovaps [rsp+0x40], xmm5
00007f0145bd7867  vmovaps [rsp+0x50], xmm6
00007f0145bd786d  vmovaps [rsp+0x60], xmm7
00007f0145bd7873  vmovaps [rsp+0x70], xmm8
00007f0145bd7879  vmovaps [rsp+0x80], xmm9
00007f0145bd7882  vmovaps [rsp+0x90], xmm10
00007f0145bd788b  vmovaps [rsp+0xA0], xmm11
00007f0145bd7894  vmovaps [rsp+0xB0], xmm12
00007f0145bd789d  vmovaps [rsp+0xC0], xmm13
00007f0145bd78a6  vmovaps [rsp+0xD0], xmm14
00007f0145bd78af  vmovaps [rsp+0xE0], xmm15
00007f0145bd78b8  sub rsp, 0x30
00007f0145bd78bc  movaps [rsp], xmm4
00007f0145bd78c0  movaps [rsp+0x10], xmm15
00007f0145bd78c6  movaps [rsp+0x20], xmm9
00007f0145bd78cc  lea rdi, [rsp]
00007f0145bd78d0  mov esi, 0x00
00007f0145bd78d5  mov rax, 0x636570E98530
00007f0145bd78df  call rax
00007f0145bd78e1  movaps xmm4, [rsp]
00007f0145bd78e5  add rsp, 0x30
00007f0145bd78e9  vmovaps xmm0, [rsp]
00007f0145bd78ee  vmovaps xmm1, [rsp+0x10]
00007f0145bd78f4  vmovaps xmm2, [rsp+0x20]
00007f0145bd78fa  vmovaps xmm3, [rsp+0x30]
00007f0145bd7900  vmovaps xmm5, [rsp+0x40]
00007f0145bd7906  vmovaps xmm6, [rsp+0x50]
00007f0145bd790c  vmovaps xmm7, [rsp+0x60]
00007f0145bd7912  vmovaps xmm8, [rsp+0x70]
00007f0145bd7918  vmovaps xmm9, [rsp+0x80]
00007f0145bd7921  vmovaps xmm10, [rsp+0x90]
00007f0145bd792a  vmovaps xmm11, [rsp+0xA0]
00007f0145bd7933  vmovaps xmm12, [rsp+0xB0]
00007f0145bd793c  vmovaps xmm13, [rsp+0xC0]
00007f0145bd7945  vmovaps xmm14, [rsp+0xD0]
00007f0145bd794e  vmovaps xmm15, [rsp+0xE0]
00007f0145bd7957  add rsp, 0xF0
00007f0145bd795e  pop r11
00007f0145bd7960  pop r10
00007f0145bd7962  pop r9
00007f0145bd7964  pop r8
00007f0145bd7966  pop rsi
00007f0145bd7967  pop rdi
00007f0145bd7968  pop rdx
00007f0145bd7969  pop rcx
00007f0145bd796a  pop rax
00007f0145bd796b  add rsp, 0x08
00007f0145bd796f  jmp 0x00007F0145BD5CF9
00007f0145bd7974  call 0x00007F0145AE5820
00007f0145bd7979  jmp 0x00007F0145BD5D06
00007f0145bd797e  sub rsp, 0x08
00007f0145bd7982  push rax
00007f0145bd7983  push rcx
00007f0145bd7984  push rdx
00007f0145bd7985  push rdi
00007f0145bd7986  push rsi
00007f0145bd7987  push r8
00007f0145bd7989  push r9
00007f0145bd798b  push r10
00007f0145bd798d  push r11
00007f0145bd798f  sub rsp, 0xF0
00007f0145bd7996  vmovaps [rsp], xmm0
00007f0145bd799b  vmovaps [rsp+0x10], xmm1
00007f0145bd79a1  vmovaps [rsp+0x20], xmm2
00007f0145bd79a7  vmovaps [rsp+0x30], xmm4
00007f0145bd79ad  vmovaps [rsp+0x40], xmm5
00007f0145bd79b3  vmovaps [rsp+0x50], xmm6
00007f0145bd79b9  vmovaps [rsp+0x60], xmm7
00007f0145bd79bf  vmovaps [rsp+0x70], xmm8
00007f0145bd79c5  vmovaps [rsp+0x80], xmm9
00007f0145bd79ce  vmovaps [rsp+0x90], xmm10
00007f0145bd79d7  vmovaps [rsp+0xA0], xmm11
00007f0145bd79e0  vmovaps [rsp+0xB0], xmm12
00007f0145bd79e9  vmovaps [rsp+0xC0], xmm13
00007f0145bd79f2  vmovaps [rsp+0xD0], xmm14
00007f0145bd79fb  vmovaps [rsp+0xE0], xmm15
00007f0145bd7a04  sub rsp, 0x30
00007f0145bd7a08  movaps [rsp], xmm3
00007f0145bd7a0c  movaps [rsp+0x10], xmm1
00007f0145bd7a11  movaps [rsp+0x20], xmm9
00007f0145bd7a17  lea rdi, [rsp]
00007f0145bd7a1b  mov esi, 0x00
00007f0145bd7a20  mov rax, 0x636570E98530
00007f0145bd7a2a  call rax
00007f0145bd7a2c  movaps xmm3, [rsp]
00007f0145bd7a30  add rsp, 0x30
00007f0145bd7a34  vmovaps xmm0, [rsp]
00007f0145bd7a39  vmovaps xmm1, [rsp+0x10]
00007f0145bd7a3f  vmovaps xmm2, [rsp+0x20]
00007f0145bd7a45  vmovaps xmm4, [rsp+0x30]
00007f0145bd7a4b  vmovaps xmm5, [rsp+0x40]
00007f0145bd7a51  vmovaps xmm6, [rsp+0x50]
00007f0145bd7a57  vmovaps xmm7, [rsp+0x60]
00007f0145bd7a5d  vmovaps xmm8, [rsp+0x70]
00007f0145bd7a63  vmovaps xmm9, [rsp+0x80]
00007f0145bd7a6c  vmovaps xmm10, [rsp+0x90]
00007f0145bd7a75  vmovaps xmm11, [rsp+0xA0]
00007f0145bd7a7e  vmovaps xmm12, [rsp+0xB0]
00007f0145bd7a87  vmovaps xmm13, [rsp+0xC0]
00007f0145bd7a90  vmovaps xmm14, [rsp+0xD0]
00007f0145bd7a99  vmovaps xmm15, [rsp+0xE0]
00007f0145bd7aa2  add rsp, 0xF0
00007f0145bd7aa9  pop r11
00007f0145bd7aab  pop r10
00007f0145bd7aad  pop r9
00007f0145bd7aaf  pop r8
00007f0145bd7ab1  pop rsi
00007f0145bd7ab2  pop rdi
00007f0145bd7ab3  pop rdx
00007f0145bd7ab4  pop rcx
00007f0145bd7ab5  pop rax
00007f0145bd7ab6  add rsp, 0x08
00007f0145bd7aba  jmp 0x00007F0145BD5D43
00007f0145bd7abf  sub rsp, 0x08
00007f0145bd7ac3  push rax
00007f0145bd7ac4  push rcx
00007f0145bd7ac5  push rdx
00007f0145bd7ac6  push rdi
00007f0145bd7ac7  push rsi
00007f0145bd7ac8  push r8
00007f0145bd7aca  push r9
00007f0145bd7acc  push r10
00007f0145bd7ace  push r11
00007f0145bd7ad0  sub rsp, 0xF0
00007f0145bd7ad7  vmovaps [rsp], xmm0
00007f0145bd7adc  vmovaps [rsp+0x10], xmm2
00007f0145bd7ae2  vmovaps [rsp+0x20], xmm3
00007f0145bd7ae8  vmovaps [rsp+0x30], xmm4
00007f0145bd7aee  vmovaps [rsp+0x40], xmm5
00007f0145bd7af4  vmovaps [rsp+0x50], xmm6
00007f0145bd7afa  vmovaps [rsp+0x60], xmm7
00007f0145bd7b00  vmovaps [rsp+0x70], xmm8
00007f0145bd7b06  vmovaps [rsp+0x80], xmm9
00007f0145bd7b0f  vmovaps [rsp+0x90], xmm10
00007f0145bd7b18  vmovaps [rsp+0xA0], xmm11
00007f0145bd7b21  vmovaps [rsp+0xB0], xmm12
00007f0145bd7b2a  vmovaps [rsp+0xC0], xmm13
00007f0145bd7b33  vmovaps [rsp+0xD0], xmm14
00007f0145bd7b3c  vmovaps [rsp+0xE0], xmm15
00007f0145bd7b45  sub rsp, 0x30
00007f0145bd7b49  movaps [rsp], xmm1
00007f0145bd7b4d  movaps [rsp+0x10], xmm15
00007f0145bd7b53  movaps [rsp+0x20], xmm9
00007f0145bd7b59  lea rdi, [rsp]
00007f0145bd7b5d  mov esi, 0x00
00007f0145bd7b62  mov rax, 0x636570E98530
00007f0145bd7b6c  call rax
00007f0145bd7b6e  movaps xmm1, [rsp]
00007f0145bd7b72  add rsp, 0x30
00007f0145bd7b76  vmovaps xmm0, [rsp]
00007f0145bd7b7b  vmovaps xmm2, [rsp+0x10]
00007f0145bd7b81  vmovaps xmm3, [rsp+0x20]
00007f0145bd7b87  vmovaps xmm4, [rsp+0x30]
00007f0145bd7b8d  vmovaps xmm5, [rsp+0x40]
00007f0145bd7b93  vmovaps xmm6, [rsp+0x50]
00007f0145bd7b99  vmovaps xmm7, [rsp+0x60]
00007f0145bd7b9f  vmovaps xmm8, [rsp+0x70]
00007f0145bd7ba5  vmovaps xmm9, [rsp+0x80]
00007f0145bd7bae  vmovaps xmm10, [rsp+0x90]
00007f0145bd7bb7  vmovaps xmm11, [rsp+0xA0]
00007f0145bd7bc0  vmovaps xmm12, [rsp+0xB0]
00007f0145bd7bc9  vmovaps xmm13, [rsp+0xC0]
00007f0145bd7bd2  vmovaps xmm14, [rsp+0xD0]
00007f0145bd7bdb  vmovaps xmm15, [rsp+0xE0]
00007f0145bd7be4  add rsp, 0xF0
00007f0145bd7beb  pop r11
00007f0145bd7bed  pop r10
00007f0145bd7bef  pop r9
00007f0145bd7bf1  pop r8
00007f0145bd7bf3  pop rsi
00007f0145bd7bf4  pop rdi
00007f0145bd7bf5  pop rdx
00007f0145bd7bf6  pop rcx
00007f0145bd7bf7  pop rax
00007f0145bd7bf8  add rsp, 0x08
00007f0145bd7bfc  jmp 0x00007F0145BD5DCB
00007f0145bd7c01  call 0x00007F0145AE5820
00007f0145bd7c06  jmp 0x00007F0145BD5DD8
00007f0145bd7c0b  sub rsp, 0x08
00007f0145bd7c0f  push rax
00007f0145bd7c10  push rcx
00007f0145bd7c11  push rdx
00007f0145bd7c12  push rdi
00007f0145bd7c13  push rsi
00007f0145bd7c14  push r8
00007f0145bd7c16  push r9
00007f0145bd7c18  push r10
00007f0145bd7c1a  push r11
00007f0145bd7c1c  sub rsp, 0xF0
00007f0145bd7c23  vmovaps [rsp], xmm0
00007f0145bd7c28  vmovaps [rsp+0x10], xmm2
00007f0145bd7c2e  vmovaps [rsp+0x20], xmm3
00007f0145bd7c34  vmovaps [rsp+0x30], xmm4
00007f0145bd7c3a  vmovaps [rsp+0x40], xmm5
00007f0145bd7c40  vmovaps [rsp+0x50], xmm6
00007f0145bd7c46  vmovaps [rsp+0x60], xmm7
00007f0145bd7c4c  vmovaps [rsp+0x70], xmm8
00007f0145bd7c52  vmovaps [rsp+0x80], xmm9
00007f0145bd7c5b  vmovaps [rsp+0x90], xmm10
00007f0145bd7c64  vmovaps [rsp+0xA0], xmm11
00007f0145bd7c6d  vmovaps [rsp+0xB0], xmm12
00007f0145bd7c76  vmovaps [rsp+0xC0], xmm13
00007f0145bd7c7f  vmovaps [rsp+0xD0], xmm14
00007f0145bd7c88  vmovaps [rsp+0xE0], xmm15
00007f0145bd7c91  sub rsp, 0x30
00007f0145bd7c95  movaps [rsp], xmm1
00007f0145bd7c99  movaps [rsp+0x10], xmm5
00007f0145bd7c9e  movaps [rsp+0x20], xmm7
00007f0145bd7ca3  lea rdi, [rsp]
00007f0145bd7ca7  mov esi, 0x00
00007f0145bd7cac  mov rax, 0x636570E98530
00007f0145bd7cb6  call rax
00007f0145bd7cb8  movaps xmm1, [rsp]
00007f0145bd7cbc  add rsp, 0x30
00007f0145bd7cc0  vmovaps xmm0, [rsp]
00007f0145bd7cc5  vmovaps xmm2, [rsp+0x10]
00007f0145bd7ccb  vmovaps xmm3, [rsp+0x20]
00007f0145bd7cd1  vmovaps xmm4, [rsp+0x30]
00007f0145bd7cd7  vmovaps xmm5, [rsp+0x40]
00007f0145bd7cdd  vmovaps xmm6, [rsp+0x50]
00007f0145bd7ce3  vmovaps xmm7, [rsp+0x60]
00007f0145bd7ce9  vmovaps xmm8, [rsp+0x70]
00007f0145bd7cef  vmovaps xmm9, [rsp+0x80]
00007f0145bd7cf8  vmovaps xmm10, [rsp+0x90]
00007f0145bd7d01  vmovaps xmm11, [rsp+0xA0]
00007f0145bd7d0a  vmovaps xmm12, [rsp+0xB0]
00007f0145bd7d13  vmovaps xmm13, [rsp+0xC0]
00007f0145bd7d1c  vmovaps xmm14, [rsp+0xD0]
00007f0145bd7d25  vmovaps xmm15, [rsp+0xE0]
00007f0145bd7d2e  add rsp, 0xF0
00007f0145bd7d35  pop r11
00007f0145bd7d37  pop r10
00007f0145bd7d39  pop r9
00007f0145bd7d3b  pop r8
00007f0145bd7d3d  pop rsi
00007f0145bd7d3e  pop rdi
00007f0145bd7d3f  pop rdx
00007f0145bd7d40  pop rcx
00007f0145bd7d41  pop rax
00007f0145bd7d42  add rsp, 0x08
00007f0145bd7d46  jmp 0x00007F0145BD5E7D
00007f0145bd7d4b  sub rsp, 0x08
00007f0145bd7d4f  push rax
00007f0145bd7d50  push rcx
00007f0145bd7d51  push rdx
00007f0145bd7d52  push rdi
00007f0145bd7d53  push rsi
00007f0145bd7d54  push r8
00007f0145bd7d56  push r9
00007f0145bd7d58  push r10
00007f0145bd7d5a  push r11
00007f0145bd7d5c  sub rsp, 0xF0
00007f0145bd7d63  vmovaps [rsp], xmm0
00007f0145bd7d68  vmovaps [rsp+0x10], xmm1
00007f0145bd7d6e  vmovaps [rsp+0x20], xmm2
00007f0145bd7d74  vmovaps [rsp+0x30], xmm3
00007f0145bd7d7a  vmovaps [rsp+0x40], xmm4
00007f0145bd7d80  vmovaps [rsp+0x50], xmm5
00007f0145bd7d86  vmovaps [rsp+0x60], xmm6
00007f0145bd7d8c  vmovaps [rsp+0x70], xmm8
00007f0145bd7d92  vmovaps [rsp+0x80], xmm9
00007f0145bd7d9b  vmovaps [rsp+0x90], xmm10
00007f0145bd7da4  vmovaps [rsp+0xA0], xmm11
00007f0145bd7dad  vmovaps [rsp+0xB0], xmm12
00007f0145bd7db6  vmovaps [rsp+0xC0], xmm13
00007f0145bd7dbf  vmovaps [rsp+0xD0], xmm14
00007f0145bd7dc8  vmovaps [rsp+0xE0], xmm15
00007f0145bd7dd1  sub rsp, 0x30
00007f0145bd7dd5  movaps [rsp], xmm7
00007f0145bd7dd9  movaps [rsp+0x10], xmm5
00007f0145bd7dde  movaps [rsp+0x20], xmm15
00007f0145bd7de4  lea rdi, [rsp]
00007f0145bd7de8  mov esi, 0x00
00007f0145bd7ded  mov rax, 0x636570E98530
00007f0145bd7df7  call rax
00007f0145bd7df9  movaps xmm7, [rsp]
00007f0145bd7dfd  add rsp, 0x30
00007f0145bd7e01  vmovaps xmm0, [rsp]
00007f0145bd7e06  vmovaps xmm1, [rsp+0x10]
00007f0145bd7e0c  vmovaps xmm2, [rsp+0x20]
00007f0145bd7e12  vmovaps xmm3, [rsp+0x30]
00007f0145bd7e18  vmovaps xmm4, [rsp+0x40]
00007f0145bd7e1e  vmovaps xmm5, [rsp+0x50]
00007f0145bd7e24  vmovaps xmm6, [rsp+0x60]
00007f0145bd7e2a  vmovaps xmm8, [rsp+0x70]
00007f0145bd7e30  vmovaps xmm9, [rsp+0x80]
00007f0145bd7e39  vmovaps xmm10, [rsp+0x90]
00007f0145bd7e42  vmovaps xmm11, [rsp+0xA0]
00007f0145bd7e4b  vmovaps xmm12, [rsp+0xB0]
00007f0145bd7e54  vmovaps xmm13, [rsp+0xC0]
00007f0145bd7e5d  vmovaps xmm14, [rsp+0xD0]
00007f0145bd7e66  vmovaps xmm15, [rsp+0xE0]
00007f0145bd7e6f  add rsp, 0xF0
00007f0145bd7e76  pop r11
00007f0145bd7e78  pop r10
00007f0145bd7e7a  pop r9
00007f0145bd7e7c  pop r8
00007f0145bd7e7e  pop rsi
00007f0145bd7e7f  pop rdi
00007f0145bd7e80  pop rdx
00007f0145bd7e81  pop rcx
00007f0145bd7e82  pop rax
00007f0145bd7e83  add rsp, 0x08
00007f0145bd7e87  jmp 0x00007F0145BD5EB3
00007f0145bd7e8c  call 0x00007F0145AD64F0
00007f0145bd7e91  jmp 0x00007F0145BD5EC0
00007f0145bd7e96  sub rsp, 0x08
00007f0145bd7e9a  push rax
00007f0145bd7e9b  push rcx
00007f0145bd7e9c  push rdx
00007f0145bd7e9d  push rdi
00007f0145bd7e9e  push rsi
00007f0145bd7e9f  push r8
00007f0145bd7ea1  push r9
00007f0145bd7ea3  push r10
00007f0145bd7ea5  push r11
00007f0145bd7ea7  sub rsp, 0xF0
00007f0145bd7eae  vmovaps [rsp], xmm0
00007f0145bd7eb3  vmovaps [rsp+0x10], xmm1
00007f0145bd7eb9  vmovaps [rsp+0x20], xmm2
00007f0145bd7ebf  vmovaps [rsp+0x30], xmm3
00007f0145bd7ec5  vmovaps [rsp+0x40], xmm4
00007f0145bd7ecb  vmovaps [rsp+0x50], xmm5
00007f0145bd7ed1  vmovaps [rsp+0x60], xmm6
00007f0145bd7ed7  vmovaps [rsp+0x70], xmm7
00007f0145bd7edd  vmovaps [rsp+0x80], xmm8
00007f0145bd7ee6  vmovaps [rsp+0x90], xmm9
00007f0145bd7eef  vmovaps [rsp+0xA0], xmm10
00007f0145bd7ef8  vmovaps [rsp+0xB0], xmm11
00007f0145bd7f01  vmovaps [rsp+0xC0], xmm12
00007f0145bd7f0a  vmovaps [rsp+0xD0], xmm13
00007f0145bd7f13  vmovaps [rsp+0xE0], xmm14
00007f0145bd7f1c  sub rsp, 0x30
00007f0145bd7f20  movaps [rsp], xmm15
00007f0145bd7f25  movaps [rsp+0x10], xmm5
00007f0145bd7f2a  movaps [rsp+0x20], xmm3
00007f0145bd7f2f  lea rdi, [rsp]
00007f0145bd7f33  mov esi, 0x00
00007f0145bd7f38  mov rax, 0x636570E98530
00007f0145bd7f42  call rax
00007f0145bd7f44  movaps xmm15, [rsp]
00007f0145bd7f49  add rsp, 0x30
00007f0145bd7f4d  vmovaps xmm0, [rsp]
00007f0145bd7f52  vmovaps xmm1, [rsp+0x10]
00007f0145bd7f58  vmovaps xmm2, [rsp+0x20]
00007f0145bd7f5e  vmovaps xmm3, [rsp+0x30]
00007f0145bd7f64  vmovaps xmm4, [rsp+0x40]
00007f0145bd7f6a  vmovaps xmm5, [rsp+0x50]
00007f0145bd7f70  vmovaps xmm6, [rsp+0x60]
00007f0145bd7f76  vmovaps xmm7, [rsp+0x70]
00007f0145bd7f7c  vmovaps xmm8, [rsp+0x80]
00007f0145bd7f85  vmovaps xmm9, [rsp+0x90]
00007f0145bd7f8e  vmovaps xmm10, [rsp+0xA0]
00007f0145bd7f97  vmovaps xmm11, [rsp+0xB0]
00007f0145bd7fa0  vmovaps xmm12, [rsp+0xC0]
00007f0145bd7fa9  vmovaps xmm13, [rsp+0xD0]
00007f0145bd7fb2  vmovaps xmm14, [rsp+0xE0]
00007f0145bd7fbb  add rsp, 0xF0
00007f0145bd7fc2  pop r11
00007f0145bd7fc4  pop r10
00007f0145bd7fc6  pop r9
00007f0145bd7fc8  pop r8
00007f0145bd7fca  pop rsi
00007f0145bd7fcb  pop rdi
00007f0145bd7fcc  pop rdx
00007f0145bd7fcd  pop rcx
00007f0145bd7fce  pop rax
00007f0145bd7fcf  add rsp, 0x08
00007f0145bd7fd3  jmp 0x00007F0145BD5EE6
00007f0145bd7fd8  sub rsp, 0x08
00007f0145bd7fdc  push rax
00007f0145bd7fdd  push rcx
00007f0145bd7fde  push rdx
00007f0145bd7fdf  push rdi
00007f0145bd7fe0  push rsi
00007f0145bd7fe1  push r8
00007f0145bd7fe3  push r9
00007f0145bd7fe5  push r10
00007f0145bd7fe7  push r11
00007f0145bd7fe9  sub rsp, 0xF0
00007f0145bd7ff0  vmovaps [rsp], xmm0
00007f0145bd7ff5  vmovaps [rsp+0x10], xmm2
00007f0145bd7ffb  vmovaps [rsp+0x20], xmm3
00007f0145bd8001  vmovaps [rsp+0x30], xmm4
00007f0145bd8007  vmovaps [rsp+0x40], xmm5
00007f0145bd800d  vmovaps [rsp+0x50], xmm6
00007f0145bd8013  vmovaps [rsp+0x60], xmm7
00007f0145bd8019  vmovaps [rsp+0x70], xmm8
00007f0145bd801f  vmovaps [rsp+0x80], xmm9
00007f0145bd8028  vmovaps [rsp+0x90], xmm10
00007f0145bd8031  vmovaps [rsp+0xA0], xmm11
00007f0145bd803a  vmovaps [rsp+0xB0], xmm12
00007f0145bd8043  vmovaps [rsp+0xC0], xmm13
00007f0145bd804c  vmovaps [rsp+0xD0], xmm14
00007f0145bd8055  vmovaps [rsp+0xE0], xmm15
00007f0145bd805e  sub rsp, 0x30
00007f0145bd8062  movaps [rsp], xmm1
00007f0145bd8066  movaps [rsp+0x10], xmm5
00007f0145bd806b  movaps [rsp+0x20], xmm4
00007f0145bd8070  lea rdi, [rsp]
00007f0145bd8074  mov esi, 0x00
00007f0145bd8079  mov rax, 0x636570E98530
00007f0145bd8083  call rax
00007f0145bd8085  movaps xmm1, [rsp]
00007f0145bd8089  add rsp, 0x30
00007f0145bd808d  vmovaps xmm0, [rsp]
00007f0145bd8092  vmovaps xmm2, [rsp+0x10]
00007f0145bd8098  vmovaps xmm3, [rsp+0x20]
00007f0145bd809e  vmovaps xmm4, [rsp+0x30]
00007f0145bd80a4  vmovaps xmm5, [rsp+0x40]
00007f0145bd80aa  vmovaps xmm6, [rsp+0x50]
00007f0145bd80b0  vmovaps xmm7, [rsp+0x60]
00007f0145bd80b6  vmovaps xmm8, [rsp+0x70]
00007f0145bd80bc  vmovaps xmm9, [rsp+0x80]
00007f0145bd80c5  vmovaps xmm10, [rsp+0x90]
00007f0145bd80ce  vmovaps xmm11, [rsp+0xA0]
00007f0145bd80d7  vmovaps xmm12, [rsp+0xB0]
00007f0145bd80e0  vmovaps xmm13, [rsp+0xC0]
00007f0145bd80e9  vmovaps xmm14, [rsp+0xD0]
00007f0145bd80f2  vmovaps xmm15, [rsp+0xE0]
00007f0145bd80fb  add rsp, 0xF0
00007f0145bd8102  pop r11
00007f0145bd8104  pop r10
00007f0145bd8106  pop r9
00007f0145bd8108  pop r8
00007f0145bd810a  pop rsi
00007f0145bd810b  pop rdi
00007f0145bd810c  pop rdx
00007f0145bd810d  pop rcx
00007f0145bd810e  pop rax
00007f0145bd810f  add rsp, 0x08
00007f0145bd8113  jmp 0x00007F0145BD5F06
00007f0145bd8118  sub rsp, 0x08
00007f0145bd811c  push rax
00007f0145bd811d  push rcx
00007f0145bd811e  push rdx
00007f0145bd811f  push rdi
00007f0145bd8120  push rsi
00007f0145bd8121  push r8
00007f0145bd8123  push r9
00007f0145bd8125  push r10
00007f0145bd8127  push r11
00007f0145bd8129  sub rsp, 0xF0
00007f0145bd8130  vmovaps [rsp], xmm0
00007f0145bd8135  vmovaps [rsp+0x10], xmm1
00007f0145bd813b  vmovaps [rsp+0x20], xmm2
00007f0145bd8141  vmovaps [rsp+0x30], xmm3
00007f0145bd8147  vmovaps [rsp+0x40], xmm5
00007f0145bd814d  vmovaps [rsp+0x50], xmm6
00007f0145bd8153  vmovaps [rsp+0x60], xmm7
00007f0145bd8159  vmovaps [rsp+0x70], xmm8
00007f0145bd815f  vmovaps [rsp+0x80], xmm9
00007f0145bd8168  vmovaps [rsp+0x90], xmm10
00007f0145bd8171  vmovaps [rsp+0xA0], xmm11
00007f0145bd817a  vmovaps [rsp+0xB0], xmm12
00007f0145bd8183  vmovaps [rsp+0xC0], xmm13
00007f0145bd818c  vmovaps [rsp+0xD0], xmm14
00007f0145bd8195  vmovaps [rsp+0xE0], xmm15
00007f0145bd819e  sub rsp, 0x30
00007f0145bd81a2  movaps [rsp], xmm4
00007f0145bd81a6  movaps [rsp+0x10], xmm3
00007f0145bd81ab  movaps [rsp+0x20], xmm5
00007f0145bd81b0  lea rdi, [rsp]
00007f0145bd81b4  mov esi, 0x00
00007f0145bd81b9  mov rax, 0x636570E98530
00007f0145bd81c3  call rax
00007f0145bd81c5  movaps xmm4, [rsp]
00007f0145bd81c9  add rsp, 0x30
00007f0145bd81cd  vmovaps xmm0, [rsp]
00007f0145bd81d2  vmovaps xmm1, [rsp+0x10]
00007f0145bd81d8  vmovaps xmm2, [rsp+0x20]
00007f0145bd81de  vmovaps xmm3, [rsp+0x30]
00007f0145bd81e4  vmovaps xmm5, [rsp+0x40]
00007f0145bd81ea  vmovaps xmm6, [rsp+0x50]
00007f0145bd81f0  vmovaps xmm7, [rsp+0x60]
00007f0145bd81f6  vmovaps xmm8, [rsp+0x70]
00007f0145bd81fc  vmovaps xmm9, [rsp+0x80]
00007f0145bd8205  vmovaps xmm10, [rsp+0x90]
00007f0145bd820e  vmovaps xmm11, [rsp+0xA0]
00007f0145bd8217  vmovaps xmm12, [rsp+0xB0]
00007f0145bd8220  vmovaps xmm13, [rsp+0xC0]
00007f0145bd8229  vmovaps xmm14, [rsp+0xD0]
00007f0145bd8232  vmovaps xmm15, [rsp+0xE0]
00007f0145bd823b  add rsp, 0xF0
00007f0145bd8242  pop r11
00007f0145bd8244  pop r10
00007f0145bd8246  pop r9
00007f0145bd8248  pop r8
00007f0145bd824a  pop rsi
00007f0145bd824b  pop rdi
00007f0145bd824c  pop rdx
00007f0145bd824d  pop rcx
00007f0145bd824e  pop rax
00007f0145bd824f  add rsp, 0x08
00007f0145bd8253  jmp 0x00007F0145BD5F54
00007f0145bd8258  call 0x00007F0145AD64F0
00007f0145bd825d  jmp 0x00007F0145BD5F61
00007f0145bd8262  sub rsp, 0x08
00007f0145bd8266  push rax
00007f0145bd8267  push rcx
00007f0145bd8268  push rdx
00007f0145bd8269  push rdi
00007f0145bd826a  push rsi
00007f0145bd826b  push r8
00007f0145bd826d  push r9
00007f0145bd826f  push r10
00007f0145bd8271  push r11
00007f0145bd8273  sub rsp, 0xF0
00007f0145bd827a  vmovaps [rsp], xmm0
00007f0145bd827f  vmovaps [rsp+0x10], xmm1
00007f0145bd8285  vmovaps [rsp+0x20], xmm2
00007f0145bd828b  vmovaps [rsp+0x30], xmm3
00007f0145bd8291  vmovaps [rsp+0x40], xmm4
00007f0145bd8297  vmovaps [rsp+0x50], xmm6
00007f0145bd829d  vmovaps [rsp+0x60], xmm7
00007f0145bd82a3  vmovaps [rsp+0x70], xmm8
00007f0145bd82a9  vmovaps [rsp+0x80], xmm9
00007f0145bd82b2  vmovaps [rsp+0x90], xmm10
00007f0145bd82bb  vmovaps [rsp+0xA0], xmm11
00007f0145bd82c4  vmovaps [rsp+0xB0], xmm12
00007f0145bd82cd  vmovaps [rsp+0xC0], xmm13
00007f0145bd82d6  vmovaps [rsp+0xD0], xmm14
00007f0145bd82df  vmovaps [rsp+0xE0], xmm15
00007f0145bd82e8  sub rsp, 0x30
00007f0145bd82ec  movaps [rsp], xmm5
00007f0145bd82f0  movaps [rsp+0x10], xmm6
00007f0145bd82f5  movaps [rsp+0x20], xmm3
00007f0145bd82fa  lea rdi, [rsp]
00007f0145bd82fe  mov esi, 0x00
00007f0145bd8303  mov rax, 0x636570E98530
00007f0145bd830d  call rax
00007f0145bd830f  movaps xmm5, [rsp]
00007f0145bd8313  add rsp, 0x30
00007f0145bd8317  vmovaps xmm0, [rsp]
00007f0145bd831c  vmovaps xmm1, [rsp+0x10]
00007f0145bd8322  vmovaps xmm2, [rsp+0x20]
00007f0145bd8328  vmovaps xmm3, [rsp+0x30]
00007f0145bd832e  vmovaps xmm4, [rsp+0x40]
00007f0145bd8334  vmovaps xmm6, [rsp+0x50]
00007f0145bd833a  vmovaps xmm7, [rsp+0x60]
00007f0145bd8340  vmovaps xmm8, [rsp+0x70]
00007f0145bd8346  vmovaps xmm9, [rsp+0x80]
00007f0145bd834f  vmovaps xmm10, [rsp+0x90]
00007f0145bd8358  vmovaps xmm11, [rsp+0xA0]
00007f0145bd8361  vmovaps xmm12, [rsp+0xB0]
00007f0145bd836a  vmovaps xmm13, [rsp+0xC0]
00007f0145bd8373  vmovaps xmm14, [rsp+0xD0]
00007f0145bd837c  vmovaps xmm15, [rsp+0xE0]
00007f0145bd8385  add rsp, 0xF0
00007f0145bd838c  pop r11
00007f0145bd838e  pop r10
00007f0145bd8390  pop r9
00007f0145bd8392  pop r8
00007f0145bd8394  pop rsi
00007f0145bd8395  pop rdi
00007f0145bd8396  pop rdx
00007f0145bd8397  pop rcx
00007f0145bd8398  pop rax
00007f0145bd8399  add rsp, 0x08
00007f0145bd839d  jmp 0x00007F0145BD5F87
00007f0145bd83a2  sub rsp, 0x08
00007f0145bd83a6  push rax
00007f0145bd83a7  push rcx
00007f0145bd83a8  push rdx
00007f0145bd83a9  push rdi
00007f0145bd83aa  push rsi
00007f0145bd83ab  push r8
00007f0145bd83ad  push r9
00007f0145bd83af  push r10
00007f0145bd83b1  push r11
00007f0145bd83b3  sub rsp, 0xF0
00007f0145bd83ba  vmovaps [rsp], xmm0
00007f0145bd83bf  vmovaps [rsp+0x10], xmm1
00007f0145bd83c5  vmovaps [rsp+0x20], xmm2
00007f0145bd83cb  vmovaps [rsp+0x30], xmm3
00007f0145bd83d1  vmovaps [rsp+0x40], xmm4
00007f0145bd83d7  vmovaps [rsp+0x50], xmm5
00007f0145bd83dd  vmovaps [rsp+0x60], xmm7
00007f0145bd83e3  vmovaps [rsp+0x70], xmm8
00007f0145bd83e9  vmovaps [rsp+0x80], xmm9
00007f0145bd83f2  vmovaps [rsp+0x90], xmm10
00007f0145bd83fb  vmovaps [rsp+0xA0], xmm11
00007f0145bd8404  vmovaps [rsp+0xB0], xmm12
00007f0145bd840d  vmovaps [rsp+0xC0], xmm13
00007f0145bd8416  vmovaps [rsp+0xD0], xmm14
00007f0145bd841f  vmovaps [rsp+0xE0], xmm15
00007f0145bd8428  sub rsp, 0x30
00007f0145bd842c  movaps [rsp], xmm6
00007f0145bd8430  movaps [rsp+0x10], xmm9
00007f0145bd8436  movaps [rsp+0x20], xmm1
00007f0145bd843b  lea rdi, [rsp]
00007f0145bd843f  mov esi, 0x00
00007f0145bd8444  mov rax, 0x636570E98530
00007f0145bd844e  call rax
00007f0145bd8450  movaps xmm6, [rsp]
00007f0145bd8454  add rsp, 0x30
00007f0145bd8458  vmovaps xmm0, [rsp]
00007f0145bd845d  vmovaps xmm1, [rsp+0x10]
00007f0145bd8463  vmovaps xmm2, [rsp+0x20]
00007f0145bd8469  vmovaps xmm3, [rsp+0x30]
00007f0145bd846f  vmovaps xmm4, [rsp+0x40]
00007f0145bd8475  vmovaps xmm5, [rsp+0x50]
00007f0145bd847b  vmovaps xmm7, [rsp+0x60]
00007f0145bd8481  vmovaps xmm8, [rsp+0x70]
00007f0145bd8487  vmovaps xmm9, [rsp+0x80]
00007f0145bd8490  vmovaps xmm10, [rsp+0x90]
00007f0145bd8499  vmovaps xmm11, [rsp+0xA0]
00007f0145bd84a2  vmovaps xmm12, [rsp+0xB0]
00007f0145bd84ab  vmovaps xmm13, [rsp+0xC0]
00007f0145bd84b4  vmovaps xmm14, [rsp+0xD0]
00007f0145bd84bd  vmovaps xmm15, [rsp+0xE0]
00007f0145bd84c6  add rsp, 0xF0
00007f0145bd84cd  pop r11
00007f0145bd84cf  pop r10
00007f0145bd84d1  pop r9
00007f0145bd84d3  pop r8
00007f0145bd84d5  pop rsi
00007f0145bd84d6  pop rdi
00007f0145bd84d7  pop rdx
00007f0145bd84d8  pop rcx
00007f0145bd84d9  pop rax
00007f0145bd84da  add rsp, 0x08
00007f0145bd84de  jmp 0x00007F0145BD5FAB
00007f0145bd84e3  sub rsp, 0x08
00007f0145bd84e7  push rax
00007f0145bd84e8  push rcx
00007f0145bd84e9  push rdx
00007f0145bd84ea  push rdi
00007f0145bd84eb  push rsi
00007f0145bd84ec  push r8
00007f0145bd84ee  push r9
00007f0145bd84f0  push r10
00007f0145bd84f2  push r11
00007f0145bd84f4  sub rsp, 0xF0
00007f0145bd84fb  vmovaps [rsp], xmm0
00007f0145bd8500  vmovaps [rsp+0x10], xmm1
00007f0145bd8506  vmovaps [rsp+0x20], xmm2
00007f0145bd850c  vmovaps [rsp+0x30], xmm3
00007f0145bd8512  vmovaps [rsp+0x40], xmm4
00007f0145bd8518  vmovaps [rsp+0x50], xmm5
00007f0145bd851e  vmovaps [rsp+0x60], xmm6
00007f0145bd8524  vmovaps [rsp+0x70], xmm7
00007f0145bd852a  vmovaps [rsp+0x80], xmm8
00007f0145bd8533  vmovaps [rsp+0x90], xmm10
00007f0145bd853c  vmovaps [rsp+0xA0], xmm11
00007f0145bd8545  vmovaps [rsp+0xB0], xmm12
00007f0145bd854e  vmovaps [rsp+0xC0], xmm13
00007f0145bd8557  vmovaps [rsp+0xD0], xmm14
00007f0145bd8560  vmovaps [rsp+0xE0], xmm15
00007f0145bd8569  sub rsp, 0x30
00007f0145bd856d  movaps [rsp], xmm9
00007f0145bd8572  movaps [rsp+0x10], xmm3
00007f0145bd8577  movaps [rsp+0x20], xmm1
00007f0145bd857c  lea rdi, [rsp]
00007f0145bd8580  mov esi, 0x00
00007f0145bd8585  mov rax, 0x636570E98530
00007f0145bd858f  call rax
00007f0145bd8591  movaps xmm9, [rsp]
00007f0145bd8596  add rsp, 0x30
00007f0145bd859a  vmovaps xmm0, [rsp]
00007f0145bd859f  vmovaps xmm1, [rsp+0x10]
00007f0145bd85a5  vmovaps xmm2, [rsp+0x20]
00007f0145bd85ab  vmovaps xmm3, [rsp+0x30]
00007f0145bd85b1  vmovaps xmm4, [rsp+0x40]
00007f0145bd85b7  vmovaps xmm5, [rsp+0x50]
00007f0145bd85bd  vmovaps xmm6, [rsp+0x60]
00007f0145bd85c3  vmovaps xmm7, [rsp+0x70]
00007f0145bd85c9  vmovaps xmm8, [rsp+0x80]
00007f0145bd85d2  vmovaps xmm10, [rsp+0x90]
00007f0145bd85db  vmovaps xmm11, [rsp+0xA0]
00007f0145bd85e4  vmovaps xmm12, [rsp+0xB0]
00007f0145bd85ed  vmovaps xmm13, [rsp+0xC0]
00007f0145bd85f6  vmovaps xmm14, [rsp+0xD0]
00007f0145bd85ff  vmovaps xmm15, [rsp+0xE0]
00007f0145bd8608  add rsp, 0xF0
00007f0145bd860f  pop r11
00007f0145bd8611  pop r10
00007f0145bd8613  pop r9
00007f0145bd8615  pop r8
00007f0145bd8617  pop rsi
00007f0145bd8618  pop rdi
00007f0145bd8619  pop rdx
00007f0145bd861a  pop rcx
00007f0145bd861b  pop rax
00007f0145bd861c  add rsp, 0x08
00007f0145bd8620  jmp 0x00007F0145BD5FF7
00007f0145bd8625  call 0x00007F0145AD64F0
00007f0145bd862a  jmp 0x00007F0145BD6004
00007f0145bd862f  sub rsp, 0x08
00007f0145bd8633  push rax
00007f0145bd8634  push rcx
00007f0145bd8635  push rdx
00007f0145bd8636  push rdi
00007f0145bd8637  push rsi
00007f0145bd8638  push r8
00007f0145bd863a  push r9
00007f0145bd863c  push r10
00007f0145bd863e  push r11
00007f0145bd8640  sub rsp, 0xF0
00007f0145bd8647  vmovaps [rsp], xmm0
00007f0145bd864c  vmovaps [rsp+0x10], xmm1
00007f0145bd8652  vmovaps [rsp+0x20], xmm2
00007f0145bd8658  vmovaps [rsp+0x30], xmm3
00007f0145bd865e  vmovaps [rsp+0x40], xmm4
00007f0145bd8664  vmovaps [rsp+0x50], xmm5
00007f0145bd866a  vmovaps [rsp+0x60], xmm6
00007f0145bd8670  vmovaps [rsp+0x70], xmm7
00007f0145bd8676  vmovaps [rsp+0x80], xmm8
00007f0145bd867f  vmovaps [rsp+0x90], xmm9
00007f0145bd8688  vmovaps [rsp+0xA0], xmm10
00007f0145bd8691  vmovaps [rsp+0xB0], xmm11
00007f0145bd869a  vmovaps [rsp+0xC0], xmm12
00007f0145bd86a3  vmovaps [rsp+0xD0], xmm13
00007f0145bd86ac  vmovaps [rsp+0xE0], xmm14
00007f0145bd86b5  sub rsp, 0x30
00007f0145bd86b9  movaps [rsp], xmm15
00007f0145bd86be  movaps [rsp+0x10], xmm3
00007f0145bd86c3  movaps [rsp+0x20], xmm7
00007f0145bd86c8  lea rdi, [rsp]
00007f0145bd86cc  mov esi, 0x00
00007f0145bd86d1  mov rax, 0x636570E98530
00007f0145bd86db  call rax
00007f0145bd86dd  movaps xmm15, [rsp]
00007f0145bd86e2  add rsp, 0x30
00007f0145bd86e6  vmovaps xmm0, [rsp]
00007f0145bd86eb  vmovaps xmm1, [rsp+0x10]
00007f0145bd86f1  vmovaps xmm2, [rsp+0x20]
00007f0145bd86f7  vmovaps xmm3, [rsp+0x30]
00007f0145bd86fd  vmovaps xmm4, [rsp+0x40]
00007f0145bd8703  vmovaps xmm5, [rsp+0x50]
00007f0145bd8709  vmovaps xmm6, [rsp+0x60]
00007f0145bd870f  vmovaps xmm7, [rsp+0x70]
00007f0145bd8715  vmovaps xmm8, [rsp+0x80]
00007f0145bd871e  vmovaps xmm9, [rsp+0x90]
00007f0145bd8727  vmovaps xmm10, [rsp+0xA0]
00007f0145bd8730  vmovaps xmm11, [rsp+0xB0]
00007f0145bd8739  vmovaps xmm12, [rsp+0xC0]
00007f0145bd8742  vmovaps xmm13, [rsp+0xD0]
00007f0145bd874b  vmovaps xmm14, [rsp+0xE0]
00007f0145bd8754  add rsp, 0xF0
00007f0145bd875b  pop r11
00007f0145bd875d  pop r10
00007f0145bd875f  pop r9
00007f0145bd8761  pop r8
00007f0145bd8763  pop rsi
00007f0145bd8764  pop rdi
00007f0145bd8765  pop rdx
00007f0145bd8766  pop rcx
00007f0145bd8767  pop rax
00007f0145bd8768  add rsp, 0x08
00007f0145bd876c  jmp 0x00007F0145BD6030
00007f0145bd8771  sub rsp, 0x08
00007f0145bd8775  push rax
00007f0145bd8776  push rcx
00007f0145bd8777  push rdx
00007f0145bd8778  push rdi
00007f0145bd8779  push rsi
00007f0145bd877a  push r8
00007f0145bd877c  push r9
00007f0145bd877e  push r10
00007f0145bd8780  push r11
00007f0145bd8782  sub rsp, 0xF0
00007f0145bd8789  vmovaps [rsp], xmm0
00007f0145bd878e  vmovaps [rsp+0x10], xmm1
00007f0145bd8794  vmovaps [rsp+0x20], xmm2
00007f0145bd879a  vmovaps [rsp+0x30], xmm4
00007f0145bd87a0  vmovaps [rsp+0x40], xmm5
00007f0145bd87a6  vmovaps [rsp+0x50], xmm6
00007f0145bd87ac  vmovaps [rsp+0x60], xmm7
00007f0145bd87b2  vmovaps [rsp+0x70], xmm8
00007f0145bd87b8  vmovaps [rsp+0x80], xmm9
00007f0145bd87c1  vmovaps [rsp+0x90], xmm10
00007f0145bd87ca  vmovaps [rsp+0xA0], xmm11
00007f0145bd87d3  vmovaps [rsp+0xB0], xmm12
00007f0145bd87dc  vmovaps [rsp+0xC0], xmm13
00007f0145bd87e5  vmovaps [rsp+0xD0], xmm14
00007f0145bd87ee  vmovaps [rsp+0xE0], xmm15
00007f0145bd87f7  sub rsp, 0x30
00007f0145bd87fb  movaps [rsp], xmm3
00007f0145bd87ff  movaps [rsp+0x10], xmm1
00007f0145bd8804  movaps [rsp+0x20], xmm15
00007f0145bd880a  lea rdi, [rsp]
00007f0145bd880e  mov esi, 0x00
00007f0145bd8813  mov rax, 0x636570E98530
00007f0145bd881d  call rax
00007f0145bd881f  movaps xmm3, [rsp]
00007f0145bd8823  add rsp, 0x30
00007f0145bd8827  vmovaps xmm0, [rsp]
00007f0145bd882c  vmovaps xmm1, [rsp+0x10]
00007f0145bd8832  vmovaps xmm2, [rsp+0x20]
00007f0145bd8838  vmovaps xmm4, [rsp+0x30]
00007f0145bd883e  vmovaps xmm5, [rsp+0x40]
00007f0145bd8844  vmovaps xmm6, [rsp+0x50]
00007f0145bd884a  vmovaps xmm7, [rsp+0x60]
00007f0145bd8850  vmovaps xmm8, [rsp+0x70]
00007f0145bd8856  vmovaps xmm9, [rsp+0x80]
00007f0145bd885f  vmovaps xmm10, [rsp+0x90]
00007f0145bd8868  vmovaps xmm11, [rsp+0xA0]
00007f0145bd8871  vmovaps xmm12, [rsp+0xB0]
00007f0145bd887a  vmovaps xmm13, [rsp+0xC0]
00007f0145bd8883  vmovaps xmm14, [rsp+0xD0]
00007f0145bd888c  vmovaps xmm15, [rsp+0xE0]
00007f0145bd8895  add rsp, 0xF0
00007f0145bd889c  pop r11
00007f0145bd889e  pop r10
00007f0145bd88a0  pop r9
00007f0145bd88a2  pop r8
00007f0145bd88a4  pop rsi
00007f0145bd88a5  pop rdi
00007f0145bd88a6  pop rdx
00007f0145bd88a7  pop rcx
00007f0145bd88a8  pop rax
00007f0145bd88a9  add rsp, 0x08
00007f0145bd88ad  jmp 0x00007F0145BD60BF
00007f0145bd88b2  call 0x00007F0145AD64F0
00007f0145bd88b7  jmp 0x00007F0145BD60C9
00007f0145bd88bc  sub rsp, 0x08
00007f0145bd88c0  push rax
00007f0145bd88c1  push rcx
00007f0145bd88c2  push rdx
00007f0145bd88c3  push rdi
00007f0145bd88c4  push rsi
00007f0145bd88c5  push r8
00007f0145bd88c7  push r9
00007f0145bd88c9  push r10
00007f0145bd88cb  push r11
00007f0145bd88cd  sub rsp, 0xF0
00007f0145bd88d4  vmovaps [rsp], xmm0
00007f0145bd88d9  vmovaps [rsp+0x10], xmm1
00007f0145bd88df  vmovaps [rsp+0x20], xmm2
00007f0145bd88e5  vmovaps [rsp+0x30], xmm3
00007f0145bd88eb  vmovaps [rsp+0x40], xmm4
00007f0145bd88f1  vmovaps [rsp+0x50], xmm5
00007f0145bd88f7  vmovaps [rsp+0x60], xmm6
00007f0145bd88fd  vmovaps [rsp+0x70], xmm7
00007f0145bd8903  vmovaps [rsp+0x80], xmm8
00007f0145bd890c  vmovaps [rsp+0x90], xmm9
00007f0145bd8915  vmovaps [rsp+0xA0], xmm10
00007f0145bd891e  vmovaps [rsp+0xB0], xmm11
00007f0145bd8927  vmovaps [rsp+0xC0], xmm12
00007f0145bd8930  vmovaps [rsp+0xD0], xmm13
00007f0145bd8939  vmovaps [rsp+0xE0], xmm14
00007f0145bd8942  sub rsp, 0x30
00007f0145bd8946  movaps [rsp], xmm15
00007f0145bd894b  movaps [rsp+0x10], xmm14
00007f0145bd8951  movaps [rsp+0x20], xmm4
00007f0145bd8956  lea rdi, [rsp]
00007f0145bd895a  mov esi, 0x00
00007f0145bd895f  mov rax, 0x636570E98530
00007f0145bd8969  call rax
00007f0145bd896b  movaps xmm15, [rsp]
00007f0145bd8970  add rsp, 0x30
00007f0145bd8974  vmovaps xmm0, [rsp]
00007f0145bd8979  vmovaps xmm1, [rsp+0x10]
00007f0145bd897f  vmovaps xmm2, [rsp+0x20]
00007f0145bd8985  vmovaps xmm3, [rsp+0x30]
00007f0145bd898b  vmovaps xmm4, [rsp+0x40]
00007f0145bd8991  vmovaps xmm5, [rsp+0x50]
00007f0145bd8997  vmovaps xmm6, [rsp+0x60]
00007f0145bd899d  vmovaps xmm7, [rsp+0x70]
00007f0145bd89a3  vmovaps xmm8, [rsp+0x80]
00007f0145bd89ac  vmovaps xmm9, [rsp+0x90]
00007f0145bd89b5  vmovaps xmm10, [rsp+0xA0]
00007f0145bd89be  vmovaps xmm11, [rsp+0xB0]
00007f0145bd89c7  vmovaps xmm12, [rsp+0xC0]
00007f0145bd89d0  vmovaps xmm13, [rsp+0xD0]
00007f0145bd89d9  vmovaps xmm14, [rsp+0xE0]
00007f0145bd89e2  add rsp, 0xF0
00007f0145bd89e9  pop r11
00007f0145bd89eb  pop r10
00007f0145bd89ed  pop r9
00007f0145bd89ef  pop r8
00007f0145bd89f1  pop rsi
00007f0145bd89f2  pop rdi
00007f0145bd89f3  pop rdx
00007f0145bd89f4  pop rcx
00007f0145bd89f5  pop rax
00007f0145bd89f6  add rsp, 0x08
00007f0145bd89fa  jmp 0x00007F0145BD60F7
00007f0145bd89ff  sub rsp, 0x08
00007f0145bd8a03  push rax
00007f0145bd8a04  push rcx
00007f0145bd8a05  push rdx
00007f0145bd8a06  push rdi
00007f0145bd8a07  push rsi
00007f0145bd8a08  push r8
00007f0145bd8a0a  push r9
00007f0145bd8a0c  push r10
00007f0145bd8a0e  push r11
00007f0145bd8a10  sub rsp, 0xF0
00007f0145bd8a17  vmovaps [rsp], xmm0
00007f0145bd8a1c  vmovaps [rsp+0x10], xmm1
00007f0145bd8a22  vmovaps [rsp+0x20], xmm2
00007f0145bd8a28  vmovaps [rsp+0x30], xmm3
00007f0145bd8a2e  vmovaps [rsp+0x40], xmm4
00007f0145bd8a34  vmovaps [rsp+0x50], xmm5
00007f0145bd8a3a  vmovaps [rsp+0x60], xmm6
00007f0145bd8a40  vmovaps [rsp+0x70], xmm7
00007f0145bd8a46  vmovaps [rsp+0x80], xmm8
00007f0145bd8a4f  vmovaps [rsp+0x90], xmm9
00007f0145bd8a58  vmovaps [rsp+0xA0], xmm10
00007f0145bd8a61  vmovaps [rsp+0xB0], xmm11
00007f0145bd8a6a  vmovaps [rsp+0xC0], xmm12
00007f0145bd8a73  vmovaps [rsp+0xD0], xmm13
00007f0145bd8a7c  vmovaps [rsp+0xE0], xmm15
00007f0145bd8a85  sub rsp, 0x30
00007f0145bd8a89  movaps [rsp], xmm14
00007f0145bd8a8e  movaps [rsp+0x10], xmm2
00007f0145bd8a93  movaps [rsp+0x20], xmm1
00007f0145bd8a98  lea rdi, [rsp]
00007f0145bd8a9c  mov esi, 0x00
00007f0145bd8aa1  mov rax, 0x636570E98530
00007f0145bd8aab  call rax
00007f0145bd8aad  movaps xmm14, [rsp]
00007f0145bd8ab2  add rsp, 0x30
00007f0145bd8ab6  vmovaps xmm0, [rsp]
00007f0145bd8abb  vmovaps xmm1, [rsp+0x10]
00007f0145bd8ac1  vmovaps xmm2, [rsp+0x20]
00007f0145bd8ac7  vmovaps xmm3, [rsp+0x30]
00007f0145bd8acd  vmovaps xmm4, [rsp+0x40]
00007f0145bd8ad3  vmovaps xmm5, [rsp+0x50]
00007f0145bd8ad9  vmovaps xmm6, [rsp+0x60]
00007f0145bd8adf  vmovaps xmm7, [rsp+0x70]
00007f0145bd8ae5  vmovaps xmm8, [rsp+0x80]
00007f0145bd8aee  vmovaps xmm9, [rsp+0x90]
00007f0145bd8af7  vmovaps xmm10, [rsp+0xA0]
00007f0145bd8b00  vmovaps xmm11, [rsp+0xB0]
00007f0145bd8b09  vmovaps xmm12, [rsp+0xC0]
00007f0145bd8b12  vmovaps xmm13, [rsp+0xD0]
00007f0145bd8b1b  vmovaps xmm15, [rsp+0xE0]
00007f0145bd8b24  add rsp, 0xF0
00007f0145bd8b2b  pop r11
00007f0145bd8b2d  pop r10
00007f0145bd8b2f  pop r9
00007f0145bd8b31  pop r8
00007f0145bd8b33  pop rsi
00007f0145bd8b34  pop rdi
00007f0145bd8b35  pop rdx
00007f0145bd8b36  pop rcx
00007f0145bd8b37  pop rax
00007f0145bd8b38  add rsp, 0x08
00007f0145bd8b3c  jmp 0x00007F0145BD611D
00007f0145bd8b41  sub rsp, 0x08
00007f0145bd8b45  push rax
00007f0145bd8b46  push rcx
00007f0145bd8b47  push rdx
00007f0145bd8b48  push rdi
00007f0145bd8b49  push rsi
00007f0145bd8b4a  push r8
00007f0145bd8b4c  push r9
00007f0145bd8b4e  push r10
00007f0145bd8b50  push r11
00007f0145bd8b52  sub rsp, 0xF0
00007f0145bd8b59  vmovaps [rsp], xmm0
00007f0145bd8b5e  vmovaps [rsp+0x10], xmm2
00007f0145bd8b64  vmovaps [rsp+0x20], xmm3
00007f0145bd8b6a  vmovaps [rsp+0x30], xmm4
00007f0145bd8b70  vmovaps [rsp+0x40], xmm5
00007f0145bd8b76  vmovaps [rsp+0x50], xmm6
00007f0145bd8b7c  vmovaps [rsp+0x60], xmm7
00007f0145bd8b82  vmovaps [rsp+0x70], xmm8
00007f0145bd8b88  vmovaps [rsp+0x80], xmm9
00007f0145bd8b91  vmovaps [rsp+0x90], xmm10
00007f0145bd8b9a  vmovaps [rsp+0xA0], xmm11
00007f0145bd8ba3  vmovaps [rsp+0xB0], xmm12
00007f0145bd8bac  vmovaps [rsp+0xC0], xmm13
00007f0145bd8bb5  vmovaps [rsp+0xD0], xmm14
00007f0145bd8bbe  vmovaps [rsp+0xE0], xmm15
00007f0145bd8bc7  sub rsp, 0x30
00007f0145bd8bcb  movaps [rsp], xmm1
00007f0145bd8bcf  movaps [rsp+0x10], xmm4
00007f0145bd8bd4  movaps [rsp+0x20], xmm9
00007f0145bd8bda  lea rdi, [rsp]
00007f0145bd8bde  mov esi, 0x00
00007f0145bd8be3  mov rax, 0x636570E98530
00007f0145bd8bed  call rax
00007f0145bd8bef  movaps xmm1, [rsp]
00007f0145bd8bf3  add rsp, 0x30
00007f0145bd8bf7  vmovaps xmm0, [rsp]
00007f0145bd8bfc  vmovaps xmm2, [rsp+0x10]
00007f0145bd8c02  vmovaps xmm3, [rsp+0x20]
00007f0145bd8c08  vmovaps xmm4, [rsp+0x30]
00007f0145bd8c0e  vmovaps xmm5, [rsp+0x40]
00007f0145bd8c14  vmovaps xmm6, [rsp+0x50]
00007f0145bd8c1a  vmovaps xmm7, [rsp+0x60]
00007f0145bd8c20  vmovaps xmm8, [rsp+0x70]
00007f0145bd8c26  vmovaps xmm9, [rsp+0x80]
00007f0145bd8c2f  vmovaps xmm10, [rsp+0x90]
00007f0145bd8c38  vmovaps xmm11, [rsp+0xA0]
00007f0145bd8c41  vmovaps xmm12, [rsp+0xB0]
00007f0145bd8c4a  vmovaps xmm13, [rsp+0xC0]
00007f0145bd8c53  vmovaps xmm14, [rsp+0xD0]
00007f0145bd8c5c  vmovaps xmm15, [rsp+0xE0]
00007f0145bd8c65  add rsp, 0xF0
00007f0145bd8c6c  pop r11
00007f0145bd8c6e  pop r10
00007f0145bd8c70  pop r9
00007f0145bd8c72  pop r8
00007f0145bd8c74  pop rsi
00007f0145bd8c75  pop rdi
00007f0145bd8c76  pop rdx
00007f0145bd8c77  pop rcx
00007f0145bd8c78  pop rax
00007f0145bd8c79  add rsp, 0x08
00007f0145bd8c7d  jmp 0x00007F0145BD613B
00007f0145bd8c82  sub rsp, 0x08
00007f0145bd8c86  push rax
00007f0145bd8c87  push rcx
00007f0145bd8c88  push rdx
00007f0145bd8c89  push rdi
00007f0145bd8c8a  push rsi
00007f0145bd8c8b  push r8
00007f0145bd8c8d  push r9
00007f0145bd8c8f  push r10
00007f0145bd8c91  push r11
00007f0145bd8c93  sub rsp, 0xF0
00007f0145bd8c9a  vmovaps [rsp], xmm0
00007f0145bd8c9f  vmovaps [rsp+0x10], xmm1
00007f0145bd8ca5  vmovaps [rsp+0x20], xmm2
00007f0145bd8cab  vmovaps [rsp+0x30], xmm3
00007f0145bd8cb1  vmovaps [rsp+0x40], xmm5
00007f0145bd8cb7  vmovaps [rsp+0x50], xmm6
00007f0145bd8cbd  vmovaps [rsp+0x60], xmm7
00007f0145bd8cc3  vmovaps [rsp+0x70], xmm8
00007f0145bd8cc9  vmovaps [rsp+0x80], xmm9
00007f0145bd8cd2  vmovaps [rsp+0x90], xmm10
00007f0145bd8cdb  vmovaps [rsp+0xA0], xmm11
00007f0145bd8ce4  vmovaps [rsp+0xB0], xmm12
00007f0145bd8ced  vmovaps [rsp+0xC0], xmm13
00007f0145bd8cf6  vmovaps [rsp+0xD0], xmm14
00007f0145bd8cff  vmovaps [rsp+0xE0], xmm15
00007f0145bd8d08  sub rsp, 0x30
00007f0145bd8d0c  movaps [rsp], xmm4
00007f0145bd8d10  movaps [rsp+0x10], xmm2
00007f0145bd8d15  movaps [rsp+0x20], xmm9
00007f0145bd8d1b  lea rdi, [rsp]
00007f0145bd8d1f  mov esi, 0x00
00007f0145bd8d24  mov rax, 0x636570E98530
00007f0145bd8d2e  call rax
00007f0145bd8d30  movaps xmm4, [rsp]
00007f0145bd8d34  add rsp, 0x30
00007f0145bd8d38  vmovaps xmm0, [rsp]
00007f0145bd8d3d  vmovaps xmm1, [rsp+0x10]
00007f0145bd8d43  vmovaps xmm2, [rsp+0x20]
00007f0145bd8d49  vmovaps xmm3, [rsp+0x30]
00007f0145bd8d4f  vmovaps xmm5, [rsp+0x40]
00007f0145bd8d55  vmovaps xmm6, [rsp+0x50]
00007f0145bd8d5b  vmovaps xmm7, [rsp+0x60]
00007f0145bd8d61  vmovaps xmm8, [rsp+0x70]
00007f0145bd8d67  vmovaps xmm9, [rsp+0x80]
00007f0145bd8d70  vmovaps xmm10, [rsp+0x90]
00007f0145bd8d79  vmovaps xmm11, [rsp+0xA0]
00007f0145bd8d82  vmovaps xmm12, [rsp+0xB0]
00007f0145bd8d8b  vmovaps xmm13, [rsp+0xC0]
00007f0145bd8d94  vmovaps xmm14, [rsp+0xD0]
00007f0145bd8d9d  vmovaps xmm15, [rsp+0xE0]
00007f0145bd8da6  add rsp, 0xF0
00007f0145bd8dad  pop r11
00007f0145bd8daf  pop r10
00007f0145bd8db1  pop r9
00007f0145bd8db3  pop r8
00007f0145bd8db5  pop rsi
00007f0145bd8db6  pop rdi
00007f0145bd8db7  pop rdx
00007f0145bd8db8  pop rcx
00007f0145bd8db9  pop rax
00007f0145bd8dba  add rsp, 0x08
00007f0145bd8dbe  jmp 0x00007F0145BD616B
00007f0145bd8dc3  sub rsp, 0x08
00007f0145bd8dc7  push rax
00007f0145bd8dc8  push rcx
00007f0145bd8dc9  push rdx
00007f0145bd8dca  push rdi
00007f0145bd8dcb  push rsi
00007f0145bd8dcc  push r8
00007f0145bd8dce  push r9
00007f0145bd8dd0  push r10
00007f0145bd8dd2  push r11
00007f0145bd8dd4  sub rsp, 0xF0
00007f0145bd8ddb  vmovaps [rsp], xmm0
00007f0145bd8de0  vmovaps [rsp+0x10], xmm1
00007f0145bd8de6  vmovaps [rsp+0x20], xmm2
00007f0145bd8dec  vmovaps [rsp+0x30], xmm3
00007f0145bd8df2  vmovaps [rsp+0x40], xmm4
00007f0145bd8df8  vmovaps [rsp+0x50], xmm5
00007f0145bd8dfe  vmovaps [rsp+0x60], xmm6
00007f0145bd8e04  vmovaps [rsp+0x70], xmm7
00007f0145bd8e0a  vmovaps [rsp+0x80], xmm8
00007f0145bd8e13  vmovaps [rsp+0x90], xmm10
00007f0145bd8e1c  vmovaps [rsp+0xA0], xmm11
00007f0145bd8e25  vmovaps [rsp+0xB0], xmm12
00007f0145bd8e2e  vmovaps [rsp+0xC0], xmm13
00007f0145bd8e37  vmovaps [rsp+0xD0], xmm14
00007f0145bd8e40  vmovaps [rsp+0xE0], xmm15
00007f0145bd8e49  sub rsp, 0x30
00007f0145bd8e4d  movaps [rsp], xmm9
00007f0145bd8e52  movaps [rsp+0x10], xmm2
00007f0145bd8e57  movaps [rsp+0x20], xmm1
00007f0145bd8e5c  lea rdi, [rsp]
00007f0145bd8e60  mov esi, 0x00
00007f0145bd8e65  mov rax, 0x636570E98530
00007f0145bd8e6f  call rax
00007f0145bd8e71  movaps xmm9, [rsp]
00007f0145bd8e76  add rsp, 0x30
00007f0145bd8e7a  vmovaps xmm0, [rsp]
00007f0145bd8e7f  vmovaps xmm1, [rsp+0x10]
00007f0145bd8e85  vmovaps xmm2, [rsp+0x20]
00007f0145bd8e8b  vmovaps xmm3, [rsp+0x30]
00007f0145bd8e91  vmovaps xmm4, [rsp+0x40]
00007f0145bd8e97  vmovaps xmm5, [rsp+0x50]
00007f0145bd8e9d  vmovaps xmm6, [rsp+0x60]
00007f0145bd8ea3  vmovaps xmm7, [rsp+0x70]
00007f0145bd8ea9  vmovaps xmm8, [rsp+0x80]
00007f0145bd8eb2  vmovaps xmm10, [rsp+0x90]
00007f0145bd8ebb  vmovaps xmm11, [rsp+0xA0]
00007f0145bd8ec4  vmovaps xmm12, [rsp+0xB0]
00007f0145bd8ecd  vmovaps xmm13, [rsp+0xC0]
00007f0145bd8ed6  vmovaps xmm14, [rsp+0xD0]
00007f0145bd8edf  vmovaps xmm15, [rsp+0xE0]
00007f0145bd8ee8  add rsp, 0xF0
00007f0145bd8eef  pop r11
00007f0145bd8ef1  pop r10
00007f0145bd8ef3  pop r9
00007f0145bd8ef5  pop r8
00007f0145bd8ef7  pop rsi
00007f0145bd8ef8  pop rdi
00007f0145bd8ef9  pop rdx
00007f0145bd8efa  pop rcx
00007f0145bd8efb  pop rax
00007f0145bd8efc  add rsp, 0x08
00007f0145bd8f00  jmp 0x00007F0145BD61A1
00007f0145bd8f05  sub rsp, 0x08
00007f0145bd8f09  push rax
00007f0145bd8f0a  push rcx
00007f0145bd8f0b  push rdx
00007f0145bd8f0c  push rdi
00007f0145bd8f0d  push rsi
00007f0145bd8f0e  push r8
00007f0145bd8f10  push r9
00007f0145bd8f12  push r10
00007f0145bd8f14  push r11
00007f0145bd8f16  sub rsp, 0xF0
00007f0145bd8f1d  vmovaps [rsp], xmm0
00007f0145bd8f22  vmovaps [rsp+0x10], xmm2
00007f0145bd8f28  vmovaps [rsp+0x20], xmm3
00007f0145bd8f2e  vmovaps [rsp+0x30], xmm4
00007f0145bd8f34  vmovaps [rsp+0x40], xmm5
00007f0145bd8f3a  vmovaps [rsp+0x50], xmm6
00007f0145bd8f40  vmovaps [rsp+0x60], xmm7
00007f0145bd8f46  vmovaps [rsp+0x70], xmm8
00007f0145bd8f4c  vmovaps [rsp+0x80], xmm9
00007f0145bd8f55  vmovaps [rsp+0x90], xmm10
00007f0145bd8f5e  vmovaps [rsp+0xA0], xmm11
00007f0145bd8f67  vmovaps [rsp+0xB0], xmm12
00007f0145bd8f70  vmovaps [rsp+0xC0], xmm13
00007f0145bd8f79  vmovaps [rsp+0xD0], xmm14
00007f0145bd8f82  vmovaps [rsp+0xE0], xmm15
00007f0145bd8f8b  sub rsp, 0x30
00007f0145bd8f8f  movaps [rsp], xmm1
00007f0145bd8f93  movaps [rsp+0x10], xmm15
00007f0145bd8f99  movaps [rsp+0x20], xmm6
00007f0145bd8f9e  lea rdi, [rsp]
00007f0145bd8fa2  mov esi, 0x00
00007f0145bd8fa7  mov rax, 0x636570E98530
00007f0145bd8fb1  call rax
00007f0145bd8fb3  movaps xmm1, [rsp]
00007f0145bd8fb7  add rsp, 0x30
00007f0145bd8fbb  vmovaps xmm0, [rsp]
00007f0145bd8fc0  vmovaps xmm2, [rsp+0x10]
00007f0145bd8fc6  vmovaps xmm3, [rsp+0x20]
00007f0145bd8fcc  vmovaps xmm4, [rsp+0x30]
00007f0145bd8fd2  vmovaps xmm5, [rsp+0x40]
00007f0145bd8fd8  vmovaps xmm6, [rsp+0x50]
00007f0145bd8fde  vmovaps xmm7, [rsp+0x60]
00007f0145bd8fe4  vmovaps xmm8, [rsp+0x70]
00007f0145bd8fea  vmovaps xmm9, [rsp+0x80]
00007f0145bd8ff3  vmovaps xmm10, [rsp+0x90]
00007f0145bd8ffc  vmovaps xmm11, [rsp+0xA0]
00007f0145bd9005  vmovaps xmm12, [rsp+0xB0]
00007f0145bd900e  vmovaps xmm13, [rsp+0xC0]
00007f0145bd9017  vmovaps xmm14, [rsp+0xD0]
00007f0145bd9020  vmovaps xmm15, [rsp+0xE0]
00007f0145bd9029  add rsp, 0xF0
00007f0145bd9030  pop r11
00007f0145bd9032  pop r10
00007f0145bd9034  pop r9
00007f0145bd9036  pop r8
00007f0145bd9038  pop rsi
00007f0145bd9039  pop rdi
00007f0145bd903a  pop rdx
00007f0145bd903b  pop rcx
00007f0145bd903c  pop rax
00007f0145bd903d  add rsp, 0x08
00007f0145bd9041  jmp 0x00007F0145BD61C2
00007f0145bd9046  sub rsp, 0x08
00007f0145bd904a  push rax
00007f0145bd904b  push rcx
00007f0145bd904c  push rdx
00007f0145bd904d  push rdi
00007f0145bd904e  push rsi
00007f0145bd904f  push r8
00007f0145bd9051  push r9
00007f0145bd9053  push r10
00007f0145bd9055  push r11
00007f0145bd9057  sub rsp, 0xF0
00007f0145bd905e  vmovaps [rsp], xmm0
00007f0145bd9063  vmovaps [rsp+0x10], xmm1
00007f0145bd9069  vmovaps [rsp+0x20], xmm2
00007f0145bd906f  vmovaps [rsp+0x30], xmm3
00007f0145bd9075  vmovaps [rsp+0x40], xmm4
00007f0145bd907b  vmovaps [rsp+0x50], xmm5
00007f0145bd9081  vmovaps [rsp+0x60], xmm6
00007f0145bd9087  vmovaps [rsp+0x70], xmm7
00007f0145bd908d  vmovaps [rsp+0x80], xmm8
00007f0145bd9096  vmovaps [rsp+0x90], xmm9
00007f0145bd909f  vmovaps [rsp+0xA0], xmm10
00007f0145bd90a8  vmovaps [rsp+0xB0], xmm11
00007f0145bd90b1  vmovaps [rsp+0xC0], xmm12
00007f0145bd90ba  vmovaps [rsp+0xD0], xmm13
00007f0145bd90c3  vmovaps [rsp+0xE0], xmm14
00007f0145bd90cc  sub rsp, 0x30
00007f0145bd90d0  movaps [rsp], xmm15
00007f0145bd90d5  movaps [rsp+0x10], xmm5
00007f0145bd90da  movaps [rsp+0x20], xmm3
00007f0145bd90df  lea rdi, [rsp]
00007f0145bd90e3  mov esi, 0x00
00007f0145bd90e8  mov rax, 0x636570E98530
00007f0145bd90f2  call rax
00007f0145bd90f4  movaps xmm15, [rsp]
00007f0145bd90f9  add rsp, 0x30
00007f0145bd90fd  vmovaps xmm0, [rsp]
00007f0145bd9102  vmovaps xmm1, [rsp+0x10]
00007f0145bd9108  vmovaps xmm2, [rsp+0x20]
00007f0145bd910e  vmovaps xmm3, [rsp+0x30]
00007f0145bd9114  vmovaps xmm4, [rsp+0x40]
00007f0145bd911a  vmovaps xmm5, [rsp+0x50]
00007f0145bd9120  vmovaps xmm6, [rsp+0x60]
00007f0145bd9126  vmovaps xmm7, [rsp+0x70]
00007f0145bd912c  vmovaps xmm8, [rsp+0x80]
00007f0145bd9135  vmovaps xmm9, [rsp+0x90]
00007f0145bd913e  vmovaps xmm10, [rsp+0xA0]
00007f0145bd9147  vmovaps xmm11, [rsp+0xB0]
00007f0145bd9150  vmovaps xmm12, [rsp+0xC0]
00007f0145bd9159  vmovaps xmm13, [rsp+0xD0]
00007f0145bd9162  vmovaps xmm14, [rsp+0xE0]
00007f0145bd916b  add rsp, 0xF0
00007f0145bd9172  pop r11
00007f0145bd9174  pop r10
00007f0145bd9176  pop r9
00007f0145bd9178  pop r8
00007f0145bd917a  pop rsi
00007f0145bd917b  pop rdi
00007f0145bd917c  pop rdx
00007f0145bd917d  pop rcx
00007f0145bd917e  pop rax
00007f0145bd917f  add rsp, 0x08
00007f0145bd9183  jmp 0x00007F0145BD61DC
00007f0145bd9188  sub rsp, 0x08
00007f0145bd918c  push rax
00007f0145bd918d  push rcx
00007f0145bd918e  push rdx
00007f0145bd918f  push rdi
00007f0145bd9190  push rsi
00007f0145bd9191  push r8
00007f0145bd9193  push r9
00007f0145bd9195  push r10
00007f0145bd9197  push r11
00007f0145bd9199  sub rsp, 0xF0
00007f0145bd91a0  vmovaps [rsp], xmm0
00007f0145bd91a5  vmovaps [rsp+0x10], xmm1
00007f0145bd91ab  vmovaps [rsp+0x20], xmm2
00007f0145bd91b1  vmovaps [rsp+0x30], xmm3
00007f0145bd91b7  vmovaps [rsp+0x40], xmm4
00007f0145bd91bd  vmovaps [rsp+0x50], xmm6
00007f0145bd91c3  vmovaps [rsp+0x60], xmm7
00007f0145bd91c9  vmovaps [rsp+0x70], xmm8
00007f0145bd91cf  vmovaps [rsp+0x80], xmm9
00007f0145bd91d8  vmovaps [rsp+0x90], xmm10
00007f0145bd91e1  vmovaps [rsp+0xA0], xmm11
00007f0145bd91ea  vmovaps [rsp+0xB0], xmm12
00007f0145bd91f3  vmovaps [rsp+0xC0], xmm13
00007f0145bd91fc  vmovaps [rsp+0xD0], xmm14
00007f0145bd9205  vmovaps [rsp+0xE0], xmm15
00007f0145bd920e  sub rsp, 0x30
00007f0145bd9212  movaps [rsp], xmm5
00007f0145bd9216  movaps [rsp+0x10], xmm8
00007f0145bd921c  movaps [rsp+0x20], xmm6
00007f0145bd9221  lea rdi, [rsp]
00007f0145bd9225  mov esi, 0x00
00007f0145bd922a  mov rax, 0x636570E98530
00007f0145bd9234  call rax
00007f0145bd9236  movaps xmm5, [rsp]
00007f0145bd923a  add rsp, 0x30
00007f0145bd923e  vmovaps xmm0, [rsp]
00007f0145bd9243  vmovaps xmm1, [rsp+0x10]
00007f0145bd9249  vmovaps xmm2, [rsp+0x20]
00007f0145bd924f  vmovaps xmm3, [rsp+0x30]
00007f0145bd9255  vmovaps xmm4, [rsp+0x40]
00007f0145bd925b  vmovaps xmm6, [rsp+0x50]
00007f0145bd9261  vmovaps xmm7, [rsp+0x60]
00007f0145bd9267  vmovaps xmm8, [rsp+0x70]
00007f0145bd926d  vmovaps xmm9, [rsp+0x80]
00007f0145bd9276  vmovaps xmm10, [rsp+0x90]
00007f0145bd927f  vmovaps xmm11, [rsp+0xA0]
00007f0145bd9288  vmovaps xmm12, [rsp+0xB0]
00007f0145bd9291  vmovaps xmm13, [rsp+0xC0]
00007f0145bd929a  vmovaps xmm14, [rsp+0xD0]
00007f0145bd92a3  vmovaps xmm15, [rsp+0xE0]
00007f0145bd92ac  add rsp, 0xF0
00007f0145bd92b3  pop r11
00007f0145bd92b5  pop r10
00007f0145bd92b7  pop r9
00007f0145bd92b9  pop r8
00007f0145bd92bb  pop rsi
00007f0145bd92bc  pop rdi
00007f0145bd92bd  pop rdx
00007f0145bd92be  pop rcx
00007f0145bd92bf  pop rax
00007f0145bd92c0  add rsp, 0x08
00007f0145bd92c4  jmp 0x00007F0145BD6200
00007f0145bd92c9  sub rsp, 0x08
00007f0145bd92cd  push rax
00007f0145bd92ce  push rcx
00007f0145bd92cf  push rdx
00007f0145bd92d0  push rdi
00007f0145bd92d1  push rsi
00007f0145bd92d2  push r8
00007f0145bd92d4  push r9
00007f0145bd92d6  push r10
00007f0145bd92d8  push r11
00007f0145bd92da  sub rsp, 0xF0
00007f0145bd92e1  vmovaps [rsp], xmm0
00007f0145bd92e6  vmovaps [rsp+0x10], xmm1
00007f0145bd92ec  vmovaps [rsp+0x20], xmm2
00007f0145bd92f2  vmovaps [rsp+0x30], xmm3
00007f0145bd92f8  vmovaps [rsp+0x40], xmm4
00007f0145bd92fe  vmovaps [rsp+0x50], xmm5
00007f0145bd9304  vmovaps [rsp+0x60], xmm7
00007f0145bd930a  vmovaps [rsp+0x70], xmm8
00007f0145bd9310  vmovaps [rsp+0x80], xmm9
00007f0145bd9319  vmovaps [rsp+0x90], xmm10
00007f0145bd9322  vmovaps [rsp+0xA0], xmm11
00007f0145bd932b  vmovaps [rsp+0xB0], xmm12
00007f0145bd9334  vmovaps [rsp+0xC0], xmm13
00007f0145bd933d  vmovaps [rsp+0xD0], xmm14
00007f0145bd9346  vmovaps [rsp+0xE0], xmm15
00007f0145bd934f  sub rsp, 0x30
00007f0145bd9353  movaps [rsp], xmm6
00007f0145bd9357  movaps [rsp+0x10], xmm10
00007f0145bd935d  movaps [rsp+0x20], xmm8
00007f0145bd9363  lea rdi, [rsp]
00007f0145bd9367  mov esi, 0x00
00007f0145bd936c  mov rax, 0x636570E98530
00007f0145bd9376  call rax
00007f0145bd9378  movaps xmm6, [rsp]
00007f0145bd937c  add rsp, 0x30
00007f0145bd9380  vmovaps xmm0, [rsp]
00007f0145bd9385  vmovaps xmm1, [rsp+0x10]
00007f0145bd938b  vmovaps xmm2, [rsp+0x20]
00007f0145bd9391  vmovaps xmm3, [rsp+0x30]
00007f0145bd9397  vmovaps xmm4, [rsp+0x40]
00007f0145bd939d  vmovaps xmm5, [rsp+0x50]
00007f0145bd93a3  vmovaps xmm7, [rsp+0x60]
00007f0145bd93a9  vmovaps xmm8, [rsp+0x70]
00007f0145bd93af  vmovaps xmm9, [rsp+0x80]
00007f0145bd93b8  vmovaps xmm10, [rsp+0x90]
00007f0145bd93c1  vmovaps xmm11, [rsp+0xA0]
00007f0145bd93ca  vmovaps xmm12, [rsp+0xB0]
00007f0145bd93d3  vmovaps xmm13, [rsp+0xC0]
00007f0145bd93dc  vmovaps xmm14, [rsp+0xD0]
00007f0145bd93e5  vmovaps xmm15, [rsp+0xE0]
00007f0145bd93ee  add rsp, 0xF0
00007f0145bd93f5  pop r11
00007f0145bd93f7  pop r10
00007f0145bd93f9  pop r9
00007f0145bd93fb  pop r8
00007f0145bd93fd  pop rsi
00007f0145bd93fe  pop rdi
00007f0145bd93ff  pop rdx
00007f0145bd9400  pop rcx
00007f0145bd9401  pop rax
00007f0145bd9402  add rsp, 0x08
00007f0145bd9406  jmp 0x00007F0145BD6225
00007f0145bd940b  sub rsp, 0x08
00007f0145bd940f  push rax
00007f0145bd9410  push rcx
00007f0145bd9411  push rdx
00007f0145bd9412  push rdi
00007f0145bd9413  push rsi
00007f0145bd9414  push r8
00007f0145bd9416  push r9
00007f0145bd9418  push r10
00007f0145bd941a  push r11
00007f0145bd941c  sub rsp, 0xF0
00007f0145bd9423  vmovaps [rsp], xmm0
00007f0145bd9428  vmovaps [rsp+0x10], xmm1
00007f0145bd942e  vmovaps [rsp+0x20], xmm2
00007f0145bd9434  vmovaps [rsp+0x30], xmm3
00007f0145bd943a  vmovaps [rsp+0x40], xmm4
00007f0145bd9440  vmovaps [rsp+0x50], xmm5
00007f0145bd9446  vmovaps [rsp+0x60], xmm6
00007f0145bd944c  vmovaps [rsp+0x70], xmm7
00007f0145bd9452  vmovaps [rsp+0x80], xmm8
00007f0145bd945b  vmovaps [rsp+0x90], xmm9
00007f0145bd9464  vmovaps [rsp+0xA0], xmm11
00007f0145bd946d  vmovaps [rsp+0xB0], xmm12
00007f0145bd9476  vmovaps [rsp+0xC0], xmm13
00007f0145bd947f  vmovaps [rsp+0xD0], xmm14
00007f0145bd9488  vmovaps [rsp+0xE0], xmm15
00007f0145bd9491  sub rsp, 0x30
00007f0145bd9495  movaps [rsp], xmm10
00007f0145bd949a  movaps [rsp+0x10], xmm8
00007f0145bd94a0  movaps [rsp+0x20], xmm14
00007f0145bd94a6  lea rdi, [rsp]
00007f0145bd94aa  mov esi, 0x00
00007f0145bd94af  mov rax, 0x636570E98530
00007f0145bd94b9  call rax
00007f0145bd94bb  movaps xmm10, [rsp]
00007f0145bd94c0  add rsp, 0x30
00007f0145bd94c4  vmovaps xmm0, [rsp]
00007f0145bd94c9  vmovaps xmm1, [rsp+0x10]
00007f0145bd94cf  vmovaps xmm2, [rsp+0x20]
00007f0145bd94d5  vmovaps xmm3, [rsp+0x30]
00007f0145bd94db  vmovaps xmm4, [rsp+0x40]
00007f0145bd94e1  vmovaps xmm5, [rsp+0x50]
00007f0145bd94e7  vmovaps xmm6, [rsp+0x60]
00007f0145bd94ed  vmovaps xmm7, [rsp+0x70]
00007f0145bd94f3  vmovaps xmm8, [rsp+0x80]
00007f0145bd94fc  vmovaps xmm9, [rsp+0x90]
00007f0145bd9505  vmovaps xmm11, [rsp+0xA0]
00007f0145bd950e  vmovaps xmm12, [rsp+0xB0]
00007f0145bd9517  vmovaps xmm13, [rsp+0xC0]
00007f0145bd9520  vmovaps xmm14, [rsp+0xD0]
00007f0145bd9529  vmovaps xmm15, [rsp+0xE0]
00007f0145bd9532  add rsp, 0xF0
00007f0145bd9539  pop r11
00007f0145bd953b  pop r10
00007f0145bd953d  pop r9
00007f0145bd953f  pop r8
00007f0145bd9541  pop rsi
00007f0145bd9542  pop rdi
00007f0145bd9543  pop rdx
00007f0145bd9544  pop rcx
00007f0145bd9545  pop rax
00007f0145bd9546  add rsp, 0x08
00007f0145bd954a  jmp 0x00007F0145BD6245
00007f0145bd954f  sub rsp, 0x08
00007f0145bd9553  push rax
00007f0145bd9554  push rcx
00007f0145bd9555  push rdx
00007f0145bd9556  push rdi
00007f0145bd9557  push rsi
00007f0145bd9558  push r8
00007f0145bd955a  push r9
00007f0145bd955c  push r10
00007f0145bd955e  push r11
00007f0145bd9560  sub rsp, 0xF0
00007f0145bd9567  vmovaps [rsp], xmm0
00007f0145bd956c  vmovaps [rsp+0x10], xmm1
00007f0145bd9572  vmovaps [rsp+0x20], xmm2
00007f0145bd9578  vmovaps [rsp+0x30], xmm3
00007f0145bd957e  vmovaps [rsp+0x40], xmm4
00007f0145bd9584  vmovaps [rsp+0x50], xmm5
00007f0145bd958a  vmovaps [rsp+0x60], xmm6
00007f0145bd9590  vmovaps [rsp+0x70], xmm7
00007f0145bd9596  vmovaps [rsp+0x80], xmm8
00007f0145bd959f  vmovaps [rsp+0x90], xmm9
00007f0145bd95a8  vmovaps [rsp+0xA0], xmm10
00007f0145bd95b1  vmovaps [rsp+0xB0], xmm11
00007f0145bd95ba  vmovaps [rsp+0xC0], xmm12
00007f0145bd95c3  vmovaps [rsp+0xD0], xmm13
00007f0145bd95cc  vmovaps [rsp+0xE0], xmm15
00007f0145bd95d5  sub rsp, 0x30
00007f0145bd95d9  movaps [rsp], xmm14
00007f0145bd95de  movaps [rsp+0x10], xmm8
00007f0145bd95e4  movaps [rsp+0x20], xmm4
00007f0145bd95e9  lea rdi, [rsp]
00007f0145bd95ed  mov esi, 0x00
00007f0145bd95f2  mov rax, 0x636570E98530
00007f0145bd95fc  call rax
00007f0145bd95fe  movaps xmm14, [rsp]
00007f0145bd9603  add rsp, 0x30
00007f0145bd9607  vmovaps xmm0, [rsp]
00007f0145bd960c  vmovaps xmm1, [rsp+0x10]
00007f0145bd9612  vmovaps xmm2, [rsp+0x20]
00007f0145bd9618  vmovaps xmm3, [rsp+0x30]
00007f0145bd961e  vmovaps xmm4, [rsp+0x40]
00007f0145bd9624  vmovaps xmm5, [rsp+0x50]
00007f0145bd962a  vmovaps xmm6, [rsp+0x60]
00007f0145bd9630  vmovaps xmm7, [rsp+0x70]
00007f0145bd9636  vmovaps xmm8, [rsp+0x80]
00007f0145bd963f  vmovaps xmm9, [rsp+0x90]
00007f0145bd9648  vmovaps xmm10, [rsp+0xA0]
00007f0145bd9651  vmovaps xmm11, [rsp+0xB0]
00007f0145bd965a  vmovaps xmm12, [rsp+0xC0]
00007f0145bd9663  vmovaps xmm13, [rsp+0xD0]
00007f0145bd966c  vmovaps xmm15, [rsp+0xE0]
00007f0145bd9675  add rsp, 0xF0
00007f0145bd967c  pop r11
00007f0145bd967e  pop r10
00007f0145bd9680  pop r9
00007f0145bd9682  pop r8
00007f0145bd9684  pop rsi
00007f0145bd9685  pop rdi
00007f0145bd9686  pop rdx
00007f0145bd9687  pop rcx
00007f0145bd9688  pop rax
00007f0145bd9689  add rsp, 0x08
00007f0145bd968d  jmp 0x00007F0145BD6265
00007f0145bd9692  sub rsp, 0x08
00007f0145bd9696  push rax
00007f0145bd9697  push rcx
00007f0145bd9698  push rdx
00007f0145bd9699  push rdi
00007f0145bd969a  push rsi
00007f0145bd969b  push r8
00007f0145bd969d  push r9
00007f0145bd969f  push r10
00007f0145bd96a1  push r11
00007f0145bd96a3  sub rsp, 0xF0
00007f0145bd96aa  vmovaps [rsp], xmm0
00007f0145bd96af  vmovaps [rsp+0x10], xmm1
00007f0145bd96b5  vmovaps [rsp+0x20], xmm2
00007f0145bd96bb  vmovaps [rsp+0x30], xmm3
00007f0145bd96c1  vmovaps [rsp+0x40], xmm5
00007f0145bd96c7  vmovaps [rsp+0x50], xmm6
00007f0145bd96cd  vmovaps [rsp+0x60], xmm7
00007f0145bd96d3  vmovaps [rsp+0x70], xmm8
00007f0145bd96d9  vmovaps [rsp+0x80], xmm9
00007f0145bd96e2  vmovaps [rsp+0x90], xmm10
00007f0145bd96eb  vmovaps [rsp+0xA0], xmm11
00007f0145bd96f4  vmovaps [rsp+0xB0], xmm12
00007f0145bd96fd  vmovaps [rsp+0xC0], xmm13
00007f0145bd9706  vmovaps [rsp+0xD0], xmm14
00007f0145bd970f  vmovaps [rsp+0xE0], xmm15
00007f0145bd9718  sub rsp, 0x30
00007f0145bd971c  movaps [rsp], xmm4
00007f0145bd9720  movaps [rsp+0x10], xmm13
00007f0145bd9726  movaps [rsp+0x20], xmm8
00007f0145bd972c  lea rdi, [rsp]
00007f0145bd9730  mov esi, 0x00
00007f0145bd9735  mov rax, 0x636570E98530
00007f0145bd973f  call rax
00007f0145bd9741  movaps xmm4, [rsp]
00007f0145bd9745  add rsp, 0x30
00007f0145bd9749  vmovaps xmm0, [rsp]
00007f0145bd974e  vmovaps xmm1, [rsp+0x10]
00007f0145bd9754  vmovaps xmm2, [rsp+0x20]
00007f0145bd975a  vmovaps xmm3, [rsp+0x30]
00007f0145bd9760  vmovaps xmm5, [rsp+0x40]
00007f0145bd9766  vmovaps xmm6, [rsp+0x50]
00007f0145bd976c  vmovaps xmm7, [rsp+0x60]
00007f0145bd9772  vmovaps xmm8, [rsp+0x70]
00007f0145bd9778  vmovaps xmm9, [rsp+0x80]
00007f0145bd9781  vmovaps xmm10, [rsp+0x90]
00007f0145bd978a  vmovaps xmm11, [rsp+0xA0]
00007f0145bd9793  vmovaps xmm12, [rsp+0xB0]
00007f0145bd979c  vmovaps xmm13, [rsp+0xC0]
00007f0145bd97a5  vmovaps xmm14, [rsp+0xD0]
00007f0145bd97ae  vmovaps xmm15, [rsp+0xE0]
00007f0145bd97b7  add rsp, 0xF0
00007f0145bd97be  pop r11
00007f0145bd97c0  pop r10
00007f0145bd97c2  pop r9
00007f0145bd97c4  pop r8
00007f0145bd97c6  pop rsi
00007f0145bd97c7  pop rdi
00007f0145bd97c8  pop rdx
00007f0145bd97c9  pop rcx
00007f0145bd97ca  pop rax
00007f0145bd97cb  add rsp, 0x08
00007f0145bd97cf  jmp 0x00007F0145BD628A
00007f0145bd97d4  sub rsp, 0x08
00007f0145bd97d8  push rax
00007f0145bd97d9  push rcx
00007f0145bd97da  push rdx
00007f0145bd97db  push rdi
00007f0145bd97dc  push rsi
00007f0145bd97dd  push r8
00007f0145bd97df  push r9
00007f0145bd97e1  push r10
00007f0145bd97e3  push r11
00007f0145bd97e5  sub rsp, 0xF0
00007f0145bd97ec  vmovaps [rsp], xmm0
00007f0145bd97f1  vmovaps [rsp+0x10], xmm1
00007f0145bd97f7  vmovaps [rsp+0x20], xmm2
00007f0145bd97fd  vmovaps [rsp+0x30], xmm3
00007f0145bd9803  vmovaps [rsp+0x40], xmm4
00007f0145bd9809  vmovaps [rsp+0x50], xmm5
00007f0145bd980f  vmovaps [rsp+0x60], xmm6
00007f0145bd9815  vmovaps [rsp+0x70], xmm7
00007f0145bd981b  vmovaps [rsp+0x80], xmm8
00007f0145bd9824  vmovaps [rsp+0x90], xmm9
00007f0145bd982d  vmovaps [rsp+0xA0], xmm10
00007f0145bd9836  vmovaps [rsp+0xB0], xmm11
00007f0145bd983f  vmovaps [rsp+0xC0], xmm12
00007f0145bd9848  vmovaps [rsp+0xD0], xmm14
00007f0145bd9851  vmovaps [rsp+0xE0], xmm15
00007f0145bd985a  sub rsp, 0x30
00007f0145bd985e  movaps [rsp], xmm13
00007f0145bd9863  movaps [rsp+0x10], xmm15
00007f0145bd9869  movaps [rsp+0x20], xmm9
00007f0145bd986f  lea rdi, [rsp]
00007f0145bd9873  mov esi, 0x00
00007f0145bd9878  mov rax, 0x636570E98530
00007f0145bd9882  call rax
00007f0145bd9884  movaps xmm13, [rsp]
00007f0145bd9889  add rsp, 0x30
00007f0145bd988d  vmovaps xmm0, [rsp]
00007f0145bd9892  vmovaps xmm1, [rsp+0x10]
00007f0145bd9898  vmovaps xmm2, [rsp+0x20]
00007f0145bd989e  vmovaps xmm3, [rsp+0x30]
00007f0145bd98a4  vmovaps xmm4, [rsp+0x40]
00007f0145bd98aa  vmovaps xmm5, [rsp+0x50]
00007f0145bd98b0  vmovaps xmm6, [rsp+0x60]
00007f0145bd98b6  vmovaps xmm7, [rsp+0x70]
00007f0145bd98bc  vmovaps xmm8, [rsp+0x80]
00007f0145bd98c5  vmovaps xmm9, [rsp+0x90]
00007f0145bd98ce  vmovaps xmm10, [rsp+0xA0]
00007f0145bd98d7  vmovaps xmm11, [rsp+0xB0]
00007f0145bd98e0  vmovaps xmm12, [rsp+0xC0]
00007f0145bd98e9  vmovaps xmm14, [rsp+0xD0]
00007f0145bd98f2  vmovaps xmm15, [rsp+0xE0]
00007f0145bd98fb  add rsp, 0xF0
00007f0145bd9902  pop r11
00007f0145bd9904  pop r10
00007f0145bd9906  pop r9
00007f0145bd9908  pop r8
00007f0145bd990a  pop rsi
00007f0145bd990b  pop rdi
00007f0145bd990c  pop rdx
00007f0145bd990d  pop rcx
00007f0145bd990e  pop rax
00007f0145bd990f  add rsp, 0x08
00007f0145bd9913  jmp 0x00007F0145BD62A5
00007f0145bd9918  sub rsp, 0x08
00007f0145bd991c  push rax
00007f0145bd991d  push rcx
00007f0145bd991e  push rdx
00007f0145bd991f  push rdi
00007f0145bd9920  push rsi
00007f0145bd9921  push r8
00007f0145bd9923  push r9
00007f0145bd9925  push r10
00007f0145bd9927  push r11
00007f0145bd9929  sub rsp, 0xF0
00007f0145bd9930  vmovaps [rsp], xmm0
00007f0145bd9935  vmovaps [rsp+0x10], xmm1
00007f0145bd993b  vmovaps [rsp+0x20], xmm2
00007f0145bd9941  vmovaps [rsp+0x30], xmm3
00007f0145bd9947  vmovaps [rsp+0x40], xmm4
00007f0145bd994d  vmovaps [rsp+0x50], xmm5
00007f0145bd9953  vmovaps [rsp+0x60], xmm6
00007f0145bd9959  vmovaps [rsp+0x70], xmm7
00007f0145bd995f  vmovaps [rsp+0x80], xmm8
00007f0145bd9968  vmovaps [rsp+0x90], xmm9
00007f0145bd9971  vmovaps [rsp+0xA0], xmm10
00007f0145bd997a  vmovaps [rsp+0xB0], xmm11
00007f0145bd9983  vmovaps [rsp+0xC0], xmm12
00007f0145bd998c  vmovaps [rsp+0xD0], xmm13
00007f0145bd9995  vmovaps [rsp+0xE0], xmm14
00007f0145bd999e  sub rsp, 0x30
00007f0145bd99a2  movaps [rsp], xmm15
00007f0145bd99a7  movaps [rsp+0x10], xmm1
00007f0145bd99ac  movaps [rsp+0x20], xmm5
00007f0145bd99b1  lea rdi, [rsp]
00007f0145bd99b5  mov esi, 0x00
00007f0145bd99ba  mov rax, 0x636570E98530
00007f0145bd99c4  call rax
00007f0145bd99c6  movaps xmm15, [rsp]
00007f0145bd99cb  add rsp, 0x30
00007f0145bd99cf  vmovaps xmm0, [rsp]
00007f0145bd99d4  vmovaps xmm1, [rsp+0x10]
00007f0145bd99da  vmovaps xmm2, [rsp+0x20]
00007f0145bd99e0  vmovaps xmm3, [rsp+0x30]
00007f0145bd99e6  vmovaps xmm4, [rsp+0x40]
00007f0145bd99ec  vmovaps xmm5, [rsp+0x50]
00007f0145bd99f2  vmovaps xmm6, [rsp+0x60]
00007f0145bd99f8  vmovaps xmm7, [rsp+0x70]
00007f0145bd99fe  vmovaps xmm8, [rsp+0x80]
00007f0145bd9a07  vmovaps xmm9, [rsp+0x90]
00007f0145bd9a10  vmovaps xmm10, [rsp+0xA0]
00007f0145bd9a19  vmovaps xmm11, [rsp+0xB0]
00007f0145bd9a22  vmovaps xmm12, [rsp+0xC0]
00007f0145bd9a2b  vmovaps xmm13, [rsp+0xD0]
00007f0145bd9a34  vmovaps xmm14, [rsp+0xE0]
00007f0145bd9a3d  add rsp, 0xF0
00007f0145bd9a44  pop r11
00007f0145bd9a46  pop r10
00007f0145bd9a48  pop r9
00007f0145bd9a4a  pop r8
00007f0145bd9a4c  pop rsi
00007f0145bd9a4d  pop rdi
00007f0145bd9a4e  pop rdx
00007f0145bd9a4f  pop rcx
00007f0145bd9a50  pop rax
00007f0145bd9a51  add rsp, 0x08
00007f0145bd9a55  jmp 0x00007F0145BD62C0
00007f0145bd9a5a  call 0x00007F0145AD64F0
00007f0145bd9a5f  jmp 0x00007F0145BD631B
00007f0145bd9a64  sub rsp, 0x08
00007f0145bd9a68  push rax
00007f0145bd9a69  push rcx
00007f0145bd9a6a  push rdx
00007f0145bd9a6b  push rdi
00007f0145bd9a6c  push rsi
00007f0145bd9a6d  push r8
00007f0145bd9a6f  push r9
00007f0145bd9a71  push r10
00007f0145bd9a73  push r11
00007f0145bd9a75  sub rsp, 0xF0
00007f0145bd9a7c  vmovaps [rsp], xmm0
00007f0145bd9a81  vmovaps [rsp+0x10], xmm1
00007f0145bd9a87  vmovaps [rsp+0x20], xmm2
00007f0145bd9a8d  vmovaps [rsp+0x30], xmm3
00007f0145bd9a93  vmovaps [rsp+0x40], xmm4
00007f0145bd9a99  vmovaps [rsp+0x50], xmm5
00007f0145bd9a9f  vmovaps [rsp+0x60], xmm6
00007f0145bd9aa5  vmovaps [rsp+0x70], xmm7
00007f0145bd9aab  vmovaps [rsp+0x80], xmm8
00007f0145bd9ab4  vmovaps [rsp+0x90], xmm10
00007f0145bd9abd  vmovaps [rsp+0xA0], xmm11
00007f0145bd9ac6  vmovaps [rsp+0xB0], xmm12
00007f0145bd9acf  vmovaps [rsp+0xC0], xmm13
00007f0145bd9ad8  vmovaps [rsp+0xD0], xmm14
00007f0145bd9ae1  vmovaps [rsp+0xE0], xmm15
00007f0145bd9aea  sub rsp, 0x30
00007f0145bd9aee  movaps [rsp], xmm9
00007f0145bd9af3  movaps [rsp+0x10], xmm8
00007f0145bd9af9  movaps [rsp+0x20], xmm11
00007f0145bd9aff  lea rdi, [rsp]
00007f0145bd9b03  mov esi, 0x00
00007f0145bd9b08  mov rax, 0x636570E98530
00007f0145bd9b12  call rax
00007f0145bd9b14  movaps xmm9, [rsp]
00007f0145bd9b19  add rsp, 0x30
00007f0145bd9b1d  vmovaps xmm0, [rsp]
00007f0145bd9b22  vmovaps xmm1, [rsp+0x10]
00007f0145bd9b28  vmovaps xmm2, [rsp+0x20]
00007f0145bd9b2e  vmovaps xmm3, [rsp+0x30]
00007f0145bd9b34  vmovaps xmm4, [rsp+0x40]
00007f0145bd9b3a  vmovaps xmm5, [rsp+0x50]
00007f0145bd9b40  vmovaps xmm6, [rsp+0x60]
00007f0145bd9b46  vmovaps xmm7, [rsp+0x70]
00007f0145bd9b4c  vmovaps xmm8, [rsp+0x80]
00007f0145bd9b55  vmovaps xmm10, [rsp+0x90]
00007f0145bd9b5e  vmovaps xmm11, [rsp+0xA0]
00007f0145bd9b67  vmovaps xmm12, [rsp+0xB0]
00007f0145bd9b70  vmovaps xmm13, [rsp+0xC0]
00007f0145bd9b79  vmovaps xmm14, [rsp+0xD0]
00007f0145bd9b82  vmovaps xmm15, [rsp+0xE0]
00007f0145bd9b8b  add rsp, 0xF0
00007f0145bd9b92  pop r11
00007f0145bd9b94  pop r10
00007f0145bd9b96  pop r9
00007f0145bd9b98  pop r8
00007f0145bd9b9a  pop rsi
00007f0145bd9b9b  pop rdi
00007f0145bd9b9c  pop rdx
00007f0145bd9b9d  pop rcx
00007f0145bd9b9e  pop rax
00007f0145bd9b9f  add rsp, 0x08
00007f0145bd9ba3  jmp 0x00007F0145BD6352
00007f0145bd9ba8  sub rsp, 0x08
00007f0145bd9bac  push rax
00007f0145bd9bad  push rcx
00007f0145bd9bae  push rdx
00007f0145bd9baf  push rdi
00007f0145bd9bb0  push rsi
00007f0145bd9bb1  push r8
00007f0145bd9bb3  push r9
00007f0145bd9bb5  push r10
00007f0145bd9bb7  push r11
00007f0145bd9bb9  sub rsp, 0xF0
00007f0145bd9bc0  vmovaps [rsp], xmm0
00007f0145bd9bc5  vmovaps [rsp+0x10], xmm1
00007f0145bd9bcb  vmovaps [rsp+0x20], xmm2
00007f0145bd9bd1  vmovaps [rsp+0x30], xmm3
00007f0145bd9bd7  vmovaps [rsp+0x40], xmm4
00007f0145bd9bdd  vmovaps [rsp+0x50], xmm5
00007f0145bd9be3  vmovaps [rsp+0x60], xmm6
00007f0145bd9be9  vmovaps [rsp+0x70], xmm7
00007f0145bd9bef  vmovaps [rsp+0x80], xmm8
00007f0145bd9bf8  vmovaps [rsp+0x90], xmm9
00007f0145bd9c01  vmovaps [rsp+0xA0], xmm10
00007f0145bd9c0a  vmovaps [rsp+0xB0], xmm12
00007f0145bd9c13  vmovaps [rsp+0xC0], xmm13
00007f0145bd9c1c  vmovaps [rsp+0xD0], xmm14
00007f0145bd9c25  vmovaps [rsp+0xE0], xmm15
00007f0145bd9c2e  sub rsp, 0x30
00007f0145bd9c32  movaps [rsp], xmm11
00007f0145bd9c37  movaps [rsp+0x10], xmm10
00007f0145bd9c3d  movaps [rsp+0x20], xmm6
00007f0145bd9c42  lea rdi, [rsp]
00007f0145bd9c46  mov esi, 0x00
00007f0145bd9c4b  mov rax, 0x636570E98530
00007f0145bd9c55  call rax
00007f0145bd9c57  movaps xmm11, [rsp]
00007f0145bd9c5c  add rsp, 0x30
00007f0145bd9c60  vmovaps xmm0, [rsp]
00007f0145bd9c65  vmovaps xmm1, [rsp+0x10]
00007f0145bd9c6b  vmovaps xmm2, [rsp+0x20]
00007f0145bd9c71  vmovaps xmm3, [rsp+0x30]
00007f0145bd9c77  vmovaps xmm4, [rsp+0x40]
00007f0145bd9c7d  vmovaps xmm5, [rsp+0x50]
00007f0145bd9c83  vmovaps xmm6, [rsp+0x60]
00007f0145bd9c89  vmovaps xmm7, [rsp+0x70]
00007f0145bd9c8f  vmovaps xmm8, [rsp+0x80]
00007f0145bd9c98  vmovaps xmm9, [rsp+0x90]
00007f0145bd9ca1  vmovaps xmm10, [rsp+0xA0]
00007f0145bd9caa  vmovaps xmm12, [rsp+0xB0]
00007f0145bd9cb3  vmovaps xmm13, [rsp+0xC0]
00007f0145bd9cbc  vmovaps xmm14, [rsp+0xD0]
00007f0145bd9cc5  vmovaps xmm15, [rsp+0xE0]
00007f0145bd9cce  add rsp, 0xF0
00007f0145bd9cd5  pop r11
00007f0145bd9cd7  pop r10
00007f0145bd9cd9  pop r9
00007f0145bd9cdb  pop r8
00007f0145bd9cdd  pop rsi
00007f0145bd9cde  pop rdi
00007f0145bd9cdf  pop rdx
00007f0145bd9ce0  pop rcx
00007f0145bd9ce1  pop rax
00007f0145bd9ce2  add rsp, 0x08
00007f0145bd9ce6  jmp 0x00007F0145BD636D
00007f0145bd9ceb  sub rsp, 0x08
00007f0145bd9cef  push rax
00007f0145bd9cf0  push rcx
00007f0145bd9cf1  push rdx
00007f0145bd9cf2  push rdi
00007f0145bd9cf3  push rsi
00007f0145bd9cf4  push r8
00007f0145bd9cf6  push r9
00007f0145bd9cf8  push r10
00007f0145bd9cfa  push r11
00007f0145bd9cfc  sub rsp, 0xF0
00007f0145bd9d03  vmovaps [rsp], xmm0
00007f0145bd9d08  vmovaps [rsp+0x10], xmm1
00007f0145bd9d0e  vmovaps [rsp+0x20], xmm2
00007f0145bd9d14  vmovaps [rsp+0x30], xmm3
00007f0145bd9d1a  vmovaps [rsp+0x40], xmm4
00007f0145bd9d20  vmovaps [rsp+0x50], xmm5
00007f0145bd9d26  vmovaps [rsp+0x60], xmm6
00007f0145bd9d2c  vmovaps [rsp+0x70], xmm7
00007f0145bd9d32  vmovaps [rsp+0x80], xmm8
00007f0145bd9d3b  vmovaps [rsp+0x90], xmm9
00007f0145bd9d44  vmovaps [rsp+0xA0], xmm11
00007f0145bd9d4d  vmovaps [rsp+0xB0], xmm12
00007f0145bd9d56  vmovaps [rsp+0xC0], xmm13
00007f0145bd9d5f  vmovaps [rsp+0xD0], xmm14
00007f0145bd9d68  vmovaps [rsp+0xE0], xmm15
00007f0145bd9d71  sub rsp, 0x30
00007f0145bd9d75  movaps [rsp], xmm10
00007f0145bd9d7a  movaps [rsp+0x10], xmm14
00007f0145bd9d80  movaps [rsp+0x20], xmm4
00007f0145bd9d85  lea rdi, [rsp]
00007f0145bd9d89  mov esi, 0x00
00007f0145bd9d8e  mov rax, 0x636570E98530
00007f0145bd9d98  call rax
00007f0145bd9d9a  movaps xmm10, [rsp]
00007f0145bd9d9f  add rsp, 0x30
00007f0145bd9da3  vmovaps xmm0, [rsp]
00007f0145bd9da8  vmovaps xmm1, [rsp+0x10]
00007f0145bd9dae  vmovaps xmm2, [rsp+0x20]
00007f0145bd9db4  vmovaps xmm3, [rsp+0x30]
00007f0145bd9dba  vmovaps xmm4, [rsp+0x40]
00007f0145bd9dc0  vmovaps xmm5, [rsp+0x50]
00007f0145bd9dc6  vmovaps xmm6, [rsp+0x60]
00007f0145bd9dcc  vmovaps xmm7, [rsp+0x70]
00007f0145bd9dd2  vmovaps xmm8, [rsp+0x80]
00007f0145bd9ddb  vmovaps xmm9, [rsp+0x90]
00007f0145bd9de4  vmovaps xmm11, [rsp+0xA0]
00007f0145bd9ded  vmovaps xmm12, [rsp+0xB0]
00007f0145bd9df6  vmovaps xmm13, [rsp+0xC0]
00007f0145bd9dff  vmovaps xmm14, [rsp+0xD0]
00007f0145bd9e08  vmovaps xmm15, [rsp+0xE0]
00007f0145bd9e11  add rsp, 0xF0
00007f0145bd9e18  pop r11
00007f0145bd9e1a  pop r10
00007f0145bd9e1c  pop r9
00007f0145bd9e1e  pop r8
00007f0145bd9e20  pop rsi
00007f0145bd9e21  pop rdi
00007f0145bd9e22  pop rdx
00007f0145bd9e23  pop rcx
00007f0145bd9e24  pop rax
00007f0145bd9e25  add rsp, 0x08
00007f0145bd9e29  jmp 0x00007F0145BD6388
00007f0145bd9e2e  sub rsp, 0x08
00007f0145bd9e32  push rax
00007f0145bd9e33  push rcx
00007f0145bd9e34  push rdx
00007f0145bd9e35  push rdi
00007f0145bd9e36  push rsi
00007f0145bd9e37  push r8
00007f0145bd9e39  push r9
00007f0145bd9e3b  push r10
00007f0145bd9e3d  push r11
00007f0145bd9e3f  sub rsp, 0xF0
00007f0145bd9e46  vmovaps [rsp], xmm0
00007f0145bd9e4b  vmovaps [rsp+0x10], xmm1
00007f0145bd9e51  vmovaps [rsp+0x20], xmm2
00007f0145bd9e57  vmovaps [rsp+0x30], xmm3
00007f0145bd9e5d  vmovaps [rsp+0x40], xmm4
00007f0145bd9e63  vmovaps [rsp+0x50], xmm5
00007f0145bd9e69  vmovaps [rsp+0x60], xmm6
00007f0145bd9e6f  vmovaps [rsp+0x70], xmm7
00007f0145bd9e75  vmovaps [rsp+0x80], xmm9
00007f0145bd9e7e  vmovaps [rsp+0x90], xmm10
00007f0145bd9e87  vmovaps [rsp+0xA0], xmm11
00007f0145bd9e90  vmovaps [rsp+0xB0], xmm12
00007f0145bd9e99  vmovaps [rsp+0xC0], xmm13
00007f0145bd9ea2  vmovaps [rsp+0xD0], xmm14
00007f0145bd9eab  vmovaps [rsp+0xE0], xmm15
00007f0145bd9eb4  sub rsp, 0x30
00007f0145bd9eb8  movaps [rsp], xmm8
00007f0145bd9ebd  movaps [rsp+0x10], xmm1
00007f0145bd9ec2  movaps [rsp+0x20], xmm14
00007f0145bd9ec8  lea rdi, [rsp]
00007f0145bd9ecc  mov esi, 0x00
00007f0145bd9ed1  mov rax, 0x636570E98530
00007f0145bd9edb  call rax
00007f0145bd9edd  movaps xmm8, [rsp]
00007f0145bd9ee2  add rsp, 0x30
00007f0145bd9ee6  vmovaps xmm0, [rsp]
00007f0145bd9eeb  vmovaps xmm1, [rsp+0x10]
00007f0145bd9ef1  vmovaps xmm2, [rsp+0x20]
00007f0145bd9ef7  vmovaps xmm3, [rsp+0x30]
00007f0145bd9efd  vmovaps xmm4, [rsp+0x40]
00007f0145bd9f03  vmovaps xmm5, [rsp+0x50]
00007f0145bd9f09  vmovaps xmm6, [rsp+0x60]
00007f0145bd9f0f  vmovaps xmm7, [rsp+0x70]
00007f0145bd9f15  vmovaps xmm9, [rsp+0x80]
00007f0145bd9f1e  vmovaps xmm10, [rsp+0x90]
00007f0145bd9f27  vmovaps xmm11, [rsp+0xA0]
00007f0145bd9f30  vmovaps xmm12, [rsp+0xB0]
00007f0145bd9f39  vmovaps xmm13, [rsp+0xC0]
00007f0145bd9f42  vmovaps xmm14, [rsp+0xD0]
00007f0145bd9f4b  vmovaps xmm15, [rsp+0xE0]
00007f0145bd9f54  add rsp, 0xF0
00007f0145bd9f5b  pop r11
00007f0145bd9f5d  pop r10
00007f0145bd9f5f  pop r9
00007f0145bd9f61  pop r8
00007f0145bd9f63  pop rsi
00007f0145bd9f64  pop rdi
00007f0145bd9f65  pop rdx
00007f0145bd9f66  pop rcx
00007f0145bd9f67  pop rax
00007f0145bd9f68  add rsp, 0x08
00007f0145bd9f6c  jmp 0x00007F0145BD63AE
00007f0145bd9f71  sub rsp, 0x08
00007f0145bd9f75  push rax
00007f0145bd9f76  push rcx
00007f0145bd9f77  push rdx
00007f0145bd9f78  push rdi
00007f0145bd9f79  push rsi
00007f0145bd9f7a  push r8
00007f0145bd9f7c  push r9
00007f0145bd9f7e  push r10
00007f0145bd9f80  push r11
00007f0145bd9f82  sub rsp, 0xF0
00007f0145bd9f89  vmovaps [rsp], xmm0
00007f0145bd9f8e  vmovaps [rsp+0x10], xmm1
00007f0145bd9f94  vmovaps [rsp+0x20], xmm2
00007f0145bd9f9a  vmovaps [rsp+0x30], xmm3
00007f0145bd9fa0  vmovaps [rsp+0x40], xmm4
00007f0145bd9fa6  vmovaps [rsp+0x50], xmm5
00007f0145bd9fac  vmovaps [rsp+0x60], xmm7
00007f0145bd9fb2  vmovaps [rsp+0x70], xmm8
00007f0145bd9fb8  vmovaps [rsp+0x80], xmm9
00007f0145bd9fc1  vmovaps [rsp+0x90], xmm10
00007f0145bd9fca  vmovaps [rsp+0xA0], xmm11
00007f0145bd9fd3  vmovaps [rsp+0xB0], xmm12
00007f0145bd9fdc  vmovaps [rsp+0xC0], xmm13
00007f0145bd9fe5  vmovaps [rsp+0xD0], xmm14
00007f0145bd9fee  vmovaps [rsp+0xE0], xmm15
00007f0145bd9ff7  sub rsp, 0x30
00007f0145bd9ffb  movaps [rsp], xmm6
00007f0145bd9fff  movaps [rsp+0x10], xmm1
00007f0145bda004  movaps [rsp+0x20], xmm14
00007f0145bda00a  lea rdi, [rsp]
00007f0145bda00e  mov esi, 0x00
00007f0145bda013  mov rax, 0x636570E98530
00007f0145bda01d  call rax
00007f0145bda01f  movaps xmm6, [rsp]
00007f0145bda023  add rsp, 0x30
00007f0145bda027  vmovaps xmm0, [rsp]
00007f0145bda02c  vmovaps xmm1, [rsp+0x10]
00007f0145bda032  vmovaps xmm2, [rsp+0x20]
00007f0145bda038  vmovaps xmm3, [rsp+0x30]
00007f0145bda03e  vmovaps xmm4, [rsp+0x40]
00007f0145bda044  vmovaps xmm5, [rsp+0x50]
00007f0145bda04a  vmovaps xmm7, [rsp+0x60]
00007f0145bda050  vmovaps xmm8, [rsp+0x70]
00007f0145bda056  vmovaps xmm9, [rsp+0x80]
00007f0145bda05f  vmovaps xmm10, [rsp+0x90]
00007f0145bda068  vmovaps xmm11, [rsp+0xA0]
00007f0145bda071  vmovaps xmm12, [rsp+0xB0]
00007f0145bda07a  vmovaps xmm13, [rsp+0xC0]
00007f0145bda083  vmovaps xmm14, [rsp+0xD0]
00007f0145bda08c  vmovaps xmm15, [rsp+0xE0]
00007f0145bda095  add rsp, 0xF0
00007f0145bda09c  pop r11
00007f0145bda09e  pop r10
00007f0145bda0a0  pop r9
00007f0145bda0a2  pop r8
00007f0145bda0a4  pop rsi
00007f0145bda0a5  pop rdi
00007f0145bda0a6  pop rdx
00007f0145bda0a7  pop rcx
00007f0145bda0a8  pop rax
00007f0145bda0a9  add rsp, 0x08
00007f0145bda0ad  jmp 0x00007F0145BD63DA
00007f0145bda0b2  sub rsp, 0x08
00007f0145bda0b6  push rax
00007f0145bda0b7  push rcx
00007f0145bda0b8  push rdx
00007f0145bda0b9  push rdi
00007f0145bda0ba  push rsi
00007f0145bda0bb  push r8
00007f0145bda0bd  push r9
00007f0145bda0bf  push r10
00007f0145bda0c1  push r11
00007f0145bda0c3  sub rsp, 0xF0
00007f0145bda0ca  vmovaps [rsp], xmm0
00007f0145bda0cf  vmovaps [rsp+0x10], xmm1
00007f0145bda0d5  vmovaps [rsp+0x20], xmm2
00007f0145bda0db  vmovaps [rsp+0x30], xmm3
00007f0145bda0e1  vmovaps [rsp+0x40], xmm4
00007f0145bda0e7  vmovaps [rsp+0x50], xmm5
00007f0145bda0ed  vmovaps [rsp+0x60], xmm6
00007f0145bda0f3  vmovaps [rsp+0x70], xmm7
00007f0145bda0f9  vmovaps [rsp+0x80], xmm8
00007f0145bda102  vmovaps [rsp+0x90], xmm9
00007f0145bda10b  vmovaps [rsp+0xA0], xmm10
00007f0145bda114  vmovaps [rsp+0xB0], xmm11
00007f0145bda11d  vmovaps [rsp+0xC0], xmm12
00007f0145bda126  vmovaps [rsp+0xD0], xmm13
00007f0145bda12f  vmovaps [rsp+0xE0], xmm15
00007f0145bda138  sub rsp, 0x30
00007f0145bda13c  movaps [rsp], xmm14
00007f0145bda141  movaps [rsp+0x10], xmm12
00007f0145bda147  movaps [rsp+0x20], xmm1
00007f0145bda14c  lea rdi, [rsp]
00007f0145bda150  mov esi, 0x00
00007f0145bda155  mov rax, 0x636570E98530
00007f0145bda15f  call rax
00007f0145bda161  movaps xmm14, [rsp]
00007f0145bda166  add rsp, 0x30
00007f0145bda16a  vmovaps xmm0, [rsp]
00007f0145bda16f  vmovaps xmm1, [rsp+0x10]
00007f0145bda175  vmovaps xmm2, [rsp+0x20]
00007f0145bda17b  vmovaps xmm3, [rsp+0x30]
00007f0145bda181  vmovaps xmm4, [rsp+0x40]
00007f0145bda187  vmovaps xmm5, [rsp+0x50]
00007f0145bda18d  vmovaps xmm6, [rsp+0x60]
00007f0145bda193  vmovaps xmm7, [rsp+0x70]
00007f0145bda199  vmovaps xmm8, [rsp+0x80]
00007f0145bda1a2  vmovaps xmm9, [rsp+0x90]
00007f0145bda1ab  vmovaps xmm10, [rsp+0xA0]
00007f0145bda1b4  vmovaps xmm11, [rsp+0xB0]
00007f0145bda1bd  vmovaps xmm12, [rsp+0xC0]
00007f0145bda1c6  vmovaps xmm13, [rsp+0xD0]
00007f0145bda1cf  vmovaps xmm15, [rsp+0xE0]
00007f0145bda1d8  add rsp, 0xF0
00007f0145bda1df  pop r11
00007f0145bda1e1  pop r10
00007f0145bda1e3  pop r9
00007f0145bda1e5  pop r8
00007f0145bda1e7  pop rsi
00007f0145bda1e8  pop rdi
00007f0145bda1e9  pop rdx
00007f0145bda1ea  pop rcx
00007f0145bda1eb  pop rax
00007f0145bda1ec  add rsp, 0x08
00007f0145bda1f0  jmp 0x00007F0145BD6400
00007f0145bda1f5  sub rsp, 0x08
00007f0145bda1f9  push rax
00007f0145bda1fa  push rcx
00007f0145bda1fb  push rdx
00007f0145bda1fc  push rdi
00007f0145bda1fd  push rsi
00007f0145bda1fe  push r8
00007f0145bda200  push r9
00007f0145bda202  push r10
00007f0145bda204  push r11
00007f0145bda206  sub rsp, 0xF0
00007f0145bda20d  vmovaps [rsp], xmm0
00007f0145bda212  vmovaps [rsp+0x10], xmm2
00007f0145bda218  vmovaps [rsp+0x20], xmm3
00007f0145bda21e  vmovaps [rsp+0x30], xmm4
00007f0145bda224  vmovaps [rsp+0x40], xmm5
00007f0145bda22a  vmovaps [rsp+0x50], xmm6
00007f0145bda230  vmovaps [rsp+0x60], xmm7
00007f0145bda236  vmovaps [rsp+0x70], xmm8
00007f0145bda23c  vmovaps [rsp+0x80], xmm9
00007f0145bda245  vmovaps [rsp+0x90], xmm10
00007f0145bda24e  vmovaps [rsp+0xA0], xmm11
00007f0145bda257  vmovaps [rsp+0xB0], xmm12
00007f0145bda260  vmovaps [rsp+0xC0], xmm13
00007f0145bda269  vmovaps [rsp+0xD0], xmm14
00007f0145bda272  vmovaps [rsp+0xE0], xmm15
00007f0145bda27b  sub rsp, 0x30
00007f0145bda27f  movaps [rsp], xmm1
00007f0145bda283  movaps [rsp+0x10], xmm13
00007f0145bda289  movaps [rsp+0x20], xmm9
00007f0145bda28f  lea rdi, [rsp]
00007f0145bda293  mov esi, 0x00
00007f0145bda298  mov rax, 0x636570E98530
00007f0145bda2a2  call rax
00007f0145bda2a4  movaps xmm1, [rsp]
00007f0145bda2a8  add rsp, 0x30
00007f0145bda2ac  vmovaps xmm0, [rsp]
00007f0145bda2b1  vmovaps xmm2, [rsp+0x10]
00007f0145bda2b7  vmovaps xmm3, [rsp+0x20]
00007f0145bda2bd  vmovaps xmm4, [rsp+0x30]
00007f0145bda2c3  vmovaps xmm5, [rsp+0x40]
00007f0145bda2c9  vmovaps xmm6, [rsp+0x50]
00007f0145bda2cf  vmovaps xmm7, [rsp+0x60]
00007f0145bda2d5  vmovaps xmm8, [rsp+0x70]
00007f0145bda2db  vmovaps xmm9, [rsp+0x80]
00007f0145bda2e4  vmovaps xmm10, [rsp+0x90]
00007f0145bda2ed  vmovaps xmm11, [rsp+0xA0]
00007f0145bda2f6  vmovaps xmm12, [rsp+0xB0]
00007f0145bda2ff  vmovaps xmm13, [rsp+0xC0]
00007f0145bda308  vmovaps xmm14, [rsp+0xD0]
00007f0145bda311  vmovaps xmm15, [rsp+0xE0]
00007f0145bda31a  add rsp, 0xF0
00007f0145bda321  pop r11
00007f0145bda323  pop r10
00007f0145bda325  pop r9
00007f0145bda327  pop r8
00007f0145bda329  pop rsi
00007f0145bda32a  pop rdi
00007f0145bda32b  pop rdx
00007f0145bda32c  pop rcx
00007f0145bda32d  pop rax
00007f0145bda32e  add rsp, 0x08
00007f0145bda332  jmp 0x00007F0145BD641A
00007f0145bda337  sub rsp, 0x08
00007f0145bda33b  push rax
00007f0145bda33c  push rcx
00007f0145bda33d  push rdx
00007f0145bda33e  push rdi
00007f0145bda33f  push rsi
00007f0145bda340  push r8
00007f0145bda342  push r9
00007f0145bda344  push r10
00007f0145bda346  push r11
00007f0145bda348  sub rsp, 0xF0
00007f0145bda34f  vmovaps [rsp], xmm0
00007f0145bda354  vmovaps [rsp+0x10], xmm1
00007f0145bda35a  vmovaps [rsp+0x20], xmm2
00007f0145bda360  vmovaps [rsp+0x30], xmm3
00007f0145bda366  vmovaps [rsp+0x40], xmm4
00007f0145bda36c  vmovaps [rsp+0x50], xmm5
00007f0145bda372  vmovaps [rsp+0x60], xmm6
00007f0145bda378  vmovaps [rsp+0x70], xmm7
00007f0145bda37e  vmovaps [rsp+0x80], xmm8
00007f0145bda387  vmovaps [rsp+0x90], xmm9
00007f0145bda390  vmovaps [rsp+0xA0], xmm10
00007f0145bda399  vmovaps [rsp+0xB0], xmm11
00007f0145bda3a2  vmovaps [rsp+0xC0], xmm13
00007f0145bda3ab  vmovaps [rsp+0xD0], xmm14
00007f0145bda3b4  vmovaps [rsp+0xE0], xmm15
00007f0145bda3bd  sub rsp, 0x30
00007f0145bda3c1  movaps [rsp], xmm12
00007f0145bda3c6  movaps [rsp+0x10], xmm7
00007f0145bda3cb  movaps [rsp+0x20], xmm13
00007f0145bda3d1  lea rdi, [rsp]
00007f0145bda3d5  mov esi, 0x00
00007f0145bda3da  mov rax, 0x636570E98530
00007f0145bda3e4  call rax
00007f0145bda3e6  movaps xmm12, [rsp]
00007f0145bda3eb  add rsp, 0x30
00007f0145bda3ef  vmovaps xmm0, [rsp]
00007f0145bda3f4  vmovaps xmm1, [rsp+0x10]
00007f0145bda3fa  vmovaps xmm2, [rsp+0x20]
00007f0145bda400  vmovaps xmm3, [rsp+0x30]
00007f0145bda406  vmovaps xmm4, [rsp+0x40]
00007f0145bda40c  vmovaps xmm5, [rsp+0x50]
00007f0145bda412  vmovaps xmm6, [rsp+0x60]
00007f0145bda418  vmovaps xmm7, [rsp+0x70]
00007f0145bda41e  vmovaps xmm8, [rsp+0x80]
00007f0145bda427  vmovaps xmm9, [rsp+0x90]
00007f0145bda430  vmovaps xmm10, [rsp+0xA0]
00007f0145bda439  vmovaps xmm11, [rsp+0xB0]
00007f0145bda442  vmovaps xmm13, [rsp+0xC0]
00007f0145bda44b  vmovaps xmm14, [rsp+0xD0]
00007f0145bda454  vmovaps xmm15, [rsp+0xE0]
00007f0145bda45d  add rsp, 0xF0
00007f0145bda464  pop r11
00007f0145bda466  pop r10
00007f0145bda468  pop r9
00007f0145bda46a  pop r8
00007f0145bda46c  pop rsi
00007f0145bda46d  pop rdi
00007f0145bda46e  pop rdx
00007f0145bda46f  pop rcx
00007f0145bda470  pop rax
00007f0145bda471  add rsp, 0x08
00007f0145bda475  jmp 0x00007F0145BD6441
00007f0145bda47a  sub rsp, 0x08
00007f0145bda47e  push rax
00007f0145bda47f  push rcx
00007f0145bda480  push rdx
00007f0145bda481  push rdi
00007f0145bda482  push rsi
00007f0145bda483  push r8
00007f0145bda485  push r9
00007f0145bda487  push r10
00007f0145bda489  push r11
00007f0145bda48b  sub rsp, 0xF0
00007f0145bda492  vmovaps [rsp], xmm0
00007f0145bda497  vmovaps [rsp+0x10], xmm1
00007f0145bda49d  vmovaps [rsp+0x20], xmm2
00007f0145bda4a3  vmovaps [rsp+0x30], xmm3
00007f0145bda4a9  vmovaps [rsp+0x40], xmm4
00007f0145bda4af  vmovaps [rsp+0x50], xmm5
00007f0145bda4b5  vmovaps [rsp+0x60], xmm6
00007f0145bda4bb  vmovaps [rsp+0x70], xmm7
00007f0145bda4c1  vmovaps [rsp+0x80], xmm8
00007f0145bda4ca  vmovaps [rsp+0x90], xmm9
00007f0145bda4d3  vmovaps [rsp+0xA0], xmm10
00007f0145bda4dc  vmovaps [rsp+0xB0], xmm11
00007f0145bda4e5  vmovaps [rsp+0xC0], xmm12
00007f0145bda4ee  vmovaps [rsp+0xD0], xmm14
00007f0145bda4f7  vmovaps [rsp+0xE0], xmm15
00007f0145bda500  sub rsp, 0x30
00007f0145bda504  movaps [rsp], xmm13
00007f0145bda509  movaps [rsp+0x10], xmm15
00007f0145bda50f  movaps [rsp+0x20], xmm8
00007f0145bda515  lea rdi, [rsp]
00007f0145bda519  mov esi, 0x00
00007f0145bda51e  mov rax, 0x636570E98530
00007f0145bda528  call rax
00007f0145bda52a  movaps xmm13, [rsp]
00007f0145bda52f  add rsp, 0x30
00007f0145bda533  vmovaps xmm0, [rsp]
00007f0145bda538  vmovaps xmm1, [rsp+0x10]
00007f0145bda53e  vmovaps xmm2, [rsp+0x20]
00007f0145bda544  vmovaps xmm3, [rsp+0x30]
00007f0145bda54a  vmovaps xmm4, [rsp+0x40]
00007f0145bda550  vmovaps xmm5, [rsp+0x50]
00007f0145bda556  vmovaps xmm6, [rsp+0x60]
00007f0145bda55c  vmovaps xmm7, [rsp+0x70]
00007f0145bda562  vmovaps xmm8, [rsp+0x80]
00007f0145bda56b  vmovaps xmm9, [rsp+0x90]
00007f0145bda574  vmovaps xmm10, [rsp+0xA0]
00007f0145bda57d  vmovaps xmm11, [rsp+0xB0]
00007f0145bda586  vmovaps xmm12, [rsp+0xC0]
00007f0145bda58f  vmovaps xmm14, [rsp+0xD0]
00007f0145bda598  vmovaps xmm15, [rsp+0xE0]
00007f0145bda5a1  add rsp, 0xF0
00007f0145bda5a8  pop r11
00007f0145bda5aa  pop r10
00007f0145bda5ac  pop r9
00007f0145bda5ae  pop r8
00007f0145bda5b0  pop rsi
00007f0145bda5b1  pop rdi
00007f0145bda5b2  pop rdx
00007f0145bda5b3  pop rcx
00007f0145bda5b4  pop rax
00007f0145bda5b5  add rsp, 0x08
00007f0145bda5b9  jmp 0x00007F0145BD645C
00007f0145bda5be  sub rsp, 0x08
00007f0145bda5c2  push rax
00007f0145bda5c3  push rcx
00007f0145bda5c4  push rdx
00007f0145bda5c5  push rdi
00007f0145bda5c6  push rsi
00007f0145bda5c7  push r8
00007f0145bda5c9  push r9
00007f0145bda5cb  push r10
00007f0145bda5cd  push r11
00007f0145bda5cf  sub rsp, 0xF0
00007f0145bda5d6  vmovaps [rsp], xmm0
00007f0145bda5db  vmovaps [rsp+0x10], xmm1
00007f0145bda5e1  vmovaps [rsp+0x20], xmm2
00007f0145bda5e7  vmovaps [rsp+0x30], xmm3
00007f0145bda5ed  vmovaps [rsp+0x40], xmm4
00007f0145bda5f3  vmovaps [rsp+0x50], xmm5
00007f0145bda5f9  vmovaps [rsp+0x60], xmm6
00007f0145bda5ff  vmovaps [rsp+0x70], xmm7
00007f0145bda605  vmovaps [rsp+0x80], xmm9
00007f0145bda60e  vmovaps [rsp+0x90], xmm10
00007f0145bda617  vmovaps [rsp+0xA0], xmm11
00007f0145bda620  vmovaps [rsp+0xB0], xmm12
00007f0145bda629  vmovaps [rsp+0xC0], xmm13
00007f0145bda632  vmovaps [rsp+0xD0], xmm14
00007f0145bda63b  vmovaps [rsp+0xE0], xmm15
00007f0145bda644  sub rsp, 0x30
00007f0145bda648  movaps [rsp], xmm8
00007f0145bda64d  movaps [rsp+0x10], xmm15
00007f0145bda653  movaps [rsp+0x20], xmm9
00007f0145bda659  lea rdi, [rsp]
00007f0145bda65d  mov esi, 0x00
00007f0145bda662  mov rax, 0x636570E98530
00007f0145bda66c  call rax
00007f0145bda66e  movaps xmm8, [rsp]
00007f0145bda673  add rsp, 0x30
00007f0145bda677  vmovaps xmm0, [rsp]
00007f0145bda67c  vmovaps xmm1, [rsp+0x10]
00007f0145bda682  vmovaps xmm2, [rsp+0x20]
00007f0145bda688  vmovaps xmm3, [rsp+0x30]
00007f0145bda68e  vmovaps xmm4, [rsp+0x40]
00007f0145bda694  vmovaps xmm5, [rsp+0x50]
00007f0145bda69a  vmovaps xmm6, [rsp+0x60]
00007f0145bda6a0  vmovaps xmm7, [rsp+0x70]
00007f0145bda6a6  vmovaps xmm9, [rsp+0x80]
00007f0145bda6af  vmovaps xmm10, [rsp+0x90]
00007f0145bda6b8  vmovaps xmm11, [rsp+0xA0]
00007f0145bda6c1  vmovaps xmm12, [rsp+0xB0]
00007f0145bda6ca  vmovaps xmm13, [rsp+0xC0]
00007f0145bda6d3  vmovaps xmm14, [rsp+0xD0]
00007f0145bda6dc  vmovaps xmm15, [rsp+0xE0]
00007f0145bda6e5  add rsp, 0xF0
00007f0145bda6ec  pop r11
00007f0145bda6ee  pop r10
00007f0145bda6f0  pop r9
00007f0145bda6f2  pop r8
00007f0145bda6f4  pop rsi
00007f0145bda6f5  pop rdi
00007f0145bda6f6  pop rdx
00007f0145bda6f7  pop rcx
00007f0145bda6f8  pop rax
00007f0145bda6f9  add rsp, 0x08
00007f0145bda6fd  jmp 0x00007F0145BD648A
00007f0145bda702  sub rsp, 0x08
00007f0145bda706  push rax
00007f0145bda707  push rcx
00007f0145bda708  push rdx
00007f0145bda709  push rdi
00007f0145bda70a  push rsi
00007f0145bda70b  push r8
00007f0145bda70d  push r9
00007f0145bda70f  push r10
00007f0145bda711  push r11
00007f0145bda713  sub rsp, 0xF0
00007f0145bda71a  vmovaps [rsp], xmm0
00007f0145bda71f  vmovaps [rsp+0x10], xmm1
00007f0145bda725  vmovaps [rsp+0x20], xmm2
00007f0145bda72b  vmovaps [rsp+0x30], xmm3
00007f0145bda731  vmovaps [rsp+0x40], xmm4
00007f0145bda737  vmovaps [rsp+0x50], xmm5
00007f0145bda73d  vmovaps [rsp+0x60], xmm6
00007f0145bda743  vmovaps [rsp+0x70], xmm7
00007f0145bda749  vmovaps [rsp+0x80], xmm8
00007f0145bda752  vmovaps [rsp+0x90], xmm9
00007f0145bda75b  vmovaps [rsp+0xA0], xmm10
00007f0145bda764  vmovaps [rsp+0xB0], xmm11
00007f0145bda76d  vmovaps [rsp+0xC0], xmm12
00007f0145bda776  vmovaps [rsp+0xD0], xmm13
00007f0145bda77f  vmovaps [rsp+0xE0], xmm14
00007f0145bda788  sub rsp, 0x30
00007f0145bda78c  movaps [rsp], xmm15
00007f0145bda791  movaps [rsp+0x10], xmm11
00007f0145bda797  movaps [rsp+0x20], xmm6
00007f0145bda79c  lea rdi, [rsp]
00007f0145bda7a0  mov esi, 0x00
00007f0145bda7a5  mov rax, 0x636570E98530
00007f0145bda7af  call rax
00007f0145bda7b1  movaps xmm15, [rsp]
00007f0145bda7b6  add rsp, 0x30
00007f0145bda7ba  vmovaps xmm0, [rsp]
00007f0145bda7bf  vmovaps xmm1, [rsp+0x10]
00007f0145bda7c5  vmovaps xmm2, [rsp+0x20]
00007f0145bda7cb  vmovaps xmm3, [rsp+0x30]
00007f0145bda7d1  vmovaps xmm4, [rsp+0x40]
00007f0145bda7d7  vmovaps xmm5, [rsp+0x50]
00007f0145bda7dd  vmovaps xmm6, [rsp+0x60]
00007f0145bda7e3  vmovaps xmm7, [rsp+0x70]
00007f0145bda7e9  vmovaps xmm8, [rsp+0x80]
00007f0145bda7f2  vmovaps xmm9, [rsp+0x90]
00007f0145bda7fb  vmovaps xmm10, [rsp+0xA0]
00007f0145bda804  vmovaps xmm11, [rsp+0xB0]
00007f0145bda80d  vmovaps xmm12, [rsp+0xC0]
00007f0145bda816  vmovaps xmm13, [rsp+0xD0]
00007f0145bda81f  vmovaps xmm14, [rsp+0xE0]
00007f0145bda828  add rsp, 0xF0
00007f0145bda82f  pop r11
00007f0145bda831  pop r10
00007f0145bda833  pop r9
00007f0145bda835  pop r8
00007f0145bda837  pop rsi
00007f0145bda838  pop rdi
00007f0145bda839  pop rdx
00007f0145bda83a  pop rcx
00007f0145bda83b  pop rax
00007f0145bda83c  add rsp, 0x08
00007f0145bda840  jmp 0x00007F0145BD64A5
00007f0145bda845  sub rsp, 0x08
00007f0145bda849  push rax
00007f0145bda84a  push rcx
00007f0145bda84b  push rdx
00007f0145bda84c  push rdi
00007f0145bda84d  push rsi
00007f0145bda84e  push r8
00007f0145bda850  push r9
00007f0145bda852  push r10
00007f0145bda854  push r11
00007f0145bda856  sub rsp, 0xF0
00007f0145bda85d  vmovaps [rsp], xmm0
00007f0145bda862  vmovaps [rsp+0x10], xmm1
00007f0145bda868  vmovaps [rsp+0x20], xmm2
00007f0145bda86e  vmovaps [rsp+0x30], xmm3
00007f0145bda874  vmovaps [rsp+0x40], xmm4
00007f0145bda87a  vmovaps [rsp+0x50], xmm5
00007f0145bda880  vmovaps [rsp+0x60], xmm6
00007f0145bda886  vmovaps [rsp+0x70], xmm8
00007f0145bda88c  vmovaps [rsp+0x80], xmm9
00007f0145bda895  vmovaps [rsp+0x90], xmm10
00007f0145bda89e  vmovaps [rsp+0xA0], xmm11
00007f0145bda8a7  vmovaps [rsp+0xB0], xmm12
00007f0145bda8b0  vmovaps [rsp+0xC0], xmm13
00007f0145bda8b9  vmovaps [rsp+0xD0], xmm14
00007f0145bda8c2  vmovaps [rsp+0xE0], xmm15
00007f0145bda8cb  sub rsp, 0x30
00007f0145bda8cf  movaps [rsp], xmm7
00007f0145bda8d3  movaps [rsp+0x10], xmm11
00007f0145bda8d9  movaps [rsp+0x20], xmm9
00007f0145bda8df  lea rdi, [rsp]
00007f0145bda8e3  mov esi, 0x00
00007f0145bda8e8  mov rax, 0x636570E98530
00007f0145bda8f2  call rax
00007f0145bda8f4  movaps xmm7, [rsp]
00007f0145bda8f8  add rsp, 0x30
00007f0145bda8fc  vmovaps xmm0, [rsp]
00007f0145bda901  vmovaps xmm1, [rsp+0x10]
00007f0145bda907  vmovaps xmm2, [rsp+0x20]
00007f0145bda90d  vmovaps xmm3, [rsp+0x30]
00007f0145bda913  vmovaps xmm4, [rsp+0x40]
00007f0145bda919  vmovaps xmm5, [rsp+0x50]
00007f0145bda91f  vmovaps xmm6, [rsp+0x60]
00007f0145bda925  vmovaps xmm8, [rsp+0x70]
00007f0145bda92b  vmovaps xmm9, [rsp+0x80]
00007f0145bda934  vmovaps xmm10, [rsp+0x90]
00007f0145bda93d  vmovaps xmm11, [rsp+0xA0]
00007f0145bda946  vmovaps xmm12, [rsp+0xB0]
00007f0145bda94f  vmovaps xmm13, [rsp+0xC0]
00007f0145bda958  vmovaps xmm14, [rsp+0xD0]
00007f0145bda961  vmovaps xmm15, [rsp+0xE0]
00007f0145bda96a  add rsp, 0xF0
00007f0145bda971  pop r11
00007f0145bda973  pop r10
00007f0145bda975  pop r9
00007f0145bda977  pop r8
00007f0145bda979  pop rsi
00007f0145bda97a  pop rdi
00007f0145bda97b  pop rdx
00007f0145bda97c  pop rcx
00007f0145bda97d  pop rax
00007f0145bda97e  add rsp, 0x08
00007f0145bda982  jmp 0x00007F0145BD64D2
00007f0145bda987  sub rsp, 0x08
00007f0145bda98b  push rax
00007f0145bda98c  push rcx
00007f0145bda98d  push rdx
00007f0145bda98e  push rdi
00007f0145bda98f  push rsi
00007f0145bda990  push r8
00007f0145bda992  push r9
00007f0145bda994  push r10
00007f0145bda996  push r11
00007f0145bda998  sub rsp, 0xF0
00007f0145bda99f  vmovaps [rsp], xmm0
00007f0145bda9a4  vmovaps [rsp+0x10], xmm1
00007f0145bda9aa  vmovaps [rsp+0x20], xmm2
00007f0145bda9b0  vmovaps [rsp+0x30], xmm3
00007f0145bda9b6  vmovaps [rsp+0x40], xmm4
00007f0145bda9bc  vmovaps [rsp+0x50], xmm5
00007f0145bda9c2  vmovaps [rsp+0x60], xmm6
00007f0145bda9c8  vmovaps [rsp+0x70], xmm7
00007f0145bda9ce  vmovaps [rsp+0x80], xmm8
00007f0145bda9d7  vmovaps [rsp+0x90], xmm9
00007f0145bda9e0  vmovaps [rsp+0xA0], xmm10
00007f0145bda9e9  vmovaps [rsp+0xB0], xmm12
00007f0145bda9f2  vmovaps [rsp+0xC0], xmm13
00007f0145bda9fb  vmovaps [rsp+0xD0], xmm14
00007f0145bdaa04  vmovaps [rsp+0xE0], xmm15
00007f0145bdaa0d  sub rsp, 0x30
00007f0145bdaa11  movaps [rsp], xmm11
00007f0145bdaa16  movaps [rsp+0x10], xmm10
00007f0145bdaa1c  movaps [rsp+0x20], xmm14
00007f0145bdaa22  lea rdi, [rsp]
00007f0145bdaa26  mov esi, 0x00
00007f0145bdaa2b  mov rax, 0x636570E98530
00007f0145bdaa35  call rax
00007f0145bdaa37  movaps xmm11, [rsp]
00007f0145bdaa3c  add rsp, 0x30
00007f0145bdaa40  vmovaps xmm0, [rsp]
00007f0145bdaa45  vmovaps xmm1, [rsp+0x10]
00007f0145bdaa4b  vmovaps xmm2, [rsp+0x20]
00007f0145bdaa51  vmovaps xmm3, [rsp+0x30]
00007f0145bdaa57  vmovaps xmm4, [rsp+0x40]
00007f0145bdaa5d  vmovaps xmm5, [rsp+0x50]
00007f0145bdaa63  vmovaps xmm6, [rsp+0x60]
00007f0145bdaa69  vmovaps xmm7, [rsp+0x70]
00007f0145bdaa6f  vmovaps xmm8, [rsp+0x80]
00007f0145bdaa78  vmovaps xmm9, [rsp+0x90]
00007f0145bdaa81  vmovaps xmm10, [rsp+0xA0]
00007f0145bdaa8a  vmovaps xmm12, [rsp+0xB0]
00007f0145bdaa93  vmovaps xmm13, [rsp+0xC0]
00007f0145bdaa9c  vmovaps xmm14, [rsp+0xD0]
00007f0145bdaaa5  vmovaps xmm15, [rsp+0xE0]
00007f0145bdaaae  add rsp, 0xF0
00007f0145bdaab5  pop r11
00007f0145bdaab7  pop r10
00007f0145bdaab9  pop r9
00007f0145bdaabb  pop r8
00007f0145bdaabd  pop rsi
00007f0145bdaabe  pop rdi
00007f0145bdaabf  pop rdx
00007f0145bdaac0  pop rcx
00007f0145bdaac1  pop rax
00007f0145bdaac2  add rsp, 0x08
00007f0145bdaac6  jmp 0x00007F0145BD64ED
00007f0145bdaacb  call 0x00007F0145AE45A0
00007f0145bdaad0  jmp 0x00007F0145BD64F7
00007f0145bdaad5  sub rsp, 0x08
00007f0145bdaad9  push rax
00007f0145bdaada  push rcx
00007f0145bdaadb  push rdx
00007f0145bdaadc  push rdi
00007f0145bdaadd  push rsi
00007f0145bdaade  push r8
00007f0145bdaae0  push r9
00007f0145bdaae2  push r10
00007f0145bdaae4  push r11
00007f0145bdaae6  sub rsp, 0xF0
00007f0145bdaaed  vmovaps [rsp], xmm0
00007f0145bdaaf2  vmovaps [rsp+0x10], xmm1
00007f0145bdaaf8  vmovaps [rsp+0x20], xmm2
00007f0145bdaafe  vmovaps [rsp+0x30], xmm3
00007f0145bdab04  vmovaps [rsp+0x40], xmm4
00007f0145bdab0a  vmovaps [rsp+0x50], xmm5
00007f0145bdab10  vmovaps [rsp+0x60], xmm6
00007f0145bdab16  vmovaps [rsp+0x70], xmm7
00007f0145bdab1c  vmovaps [rsp+0x80], xmm8
00007f0145bdab25  vmovaps [rsp+0x90], xmm9
00007f0145bdab2e  vmovaps [rsp+0xA0], xmm11
00007f0145bdab37  vmovaps [rsp+0xB0], xmm12
00007f0145bdab40  vmovaps [rsp+0xC0], xmm13
00007f0145bdab49  vmovaps [rsp+0xD0], xmm14
00007f0145bdab52  vmovaps [rsp+0xE0], xmm15
00007f0145bdab5b  sub rsp, 0x30
00007f0145bdab5f  movaps [rsp], xmm10
00007f0145bdab64  movaps [rsp+0x10], xmm1
00007f0145bdab69  movaps [rsp+0x20], xmm12
00007f0145bdab6f  lea rdi, [rsp]
00007f0145bdab73  mov esi, 0x00
00007f0145bdab78  mov rax, 0x636570E98530
00007f0145bdab82  call rax
00007f0145bdab84  movaps xmm10, [rsp]
00007f0145bdab89  add rsp, 0x30
00007f0145bdab8d  vmovaps xmm0, [rsp]
00007f0145bdab92  vmovaps xmm1, [rsp+0x10]
00007f0145bdab98  vmovaps xmm2, [rsp+0x20]
00007f0145bdab9e  vmovaps xmm3, [rsp+0x30]
00007f0145bdaba4  vmovaps xmm4, [rsp+0x40]
00007f0145bdabaa  vmovaps xmm5, [rsp+0x50]
00007f0145bdabb0  vmovaps xmm6, [rsp+0x60]
00007f0145bdabb6  vmovaps xmm7, [rsp+0x70]
00007f0145bdabbc  vmovaps xmm8, [rsp+0x80]
00007f0145bdabc5  vmovaps xmm9, [rsp+0x90]
00007f0145bdabce  vmovaps xmm11, [rsp+0xA0]
00007f0145bdabd7  vmovaps xmm12, [rsp+0xB0]
00007f0145bdabe0  vmovaps xmm13, [rsp+0xC0]
00007f0145bdabe9  vmovaps xmm14, [rsp+0xD0]
00007f0145bdabf2  vmovaps xmm15, [rsp+0xE0]
00007f0145bdabfb  add rsp, 0xF0
00007f0145bdac02  pop r11
00007f0145bdac04  pop r10
00007f0145bdac06  pop r9
00007f0145bdac08  pop r8
00007f0145bdac0a  pop rsi
00007f0145bdac0b  pop rdi
00007f0145bdac0c  pop rdx
00007f0145bdac0d  pop rcx
00007f0145bdac0e  pop rax
00007f0145bdac0f  add rsp, 0x08
00007f0145bdac13  jmp 0x00007F0145BD651A
00007f0145bdac18  sub rsp, 0x08
00007f0145bdac1c  push rax
00007f0145bdac1d  push rcx
00007f0145bdac1e  push rdx
00007f0145bdac1f  push rdi
00007f0145bdac20  push rsi
00007f0145bdac21  push r8
00007f0145bdac23  push r9
00007f0145bdac25  push r10
00007f0145bdac27  push r11
00007f0145bdac29  sub rsp, 0xF0
00007f0145bdac30  vmovaps [rsp], xmm0
00007f0145bdac35  vmovaps [rsp+0x10], xmm1
00007f0145bdac3b  vmovaps [rsp+0x20], xmm2
00007f0145bdac41  vmovaps [rsp+0x30], xmm3
00007f0145bdac47  vmovaps [rsp+0x40], xmm4
00007f0145bdac4d  vmovaps [rsp+0x50], xmm5
00007f0145bdac53  vmovaps [rsp+0x60], xmm6
00007f0145bdac59  vmovaps [rsp+0x70], xmm7
00007f0145bdac5f  vmovaps [rsp+0x80], xmm8
00007f0145bdac68  vmovaps [rsp+0x90], xmm9
00007f0145bdac71  vmovaps [rsp+0xA0], xmm10
00007f0145bdac7a  vmovaps [rsp+0xB0], xmm11
00007f0145bdac83  vmovaps [rsp+0xC0], xmm13
00007f0145bdac8c  vmovaps [rsp+0xD0], xmm14
00007f0145bdac95  vmovaps [rsp+0xE0], xmm15
00007f0145bdac9e  sub rsp, 0x30
00007f0145bdaca2  movaps [rsp], xmm12
00007f0145bdaca7  movaps [rsp+0x10], xmm14
00007f0145bdacad  movaps [rsp+0x20], xmm1
00007f0145bdacb2  lea rdi, [rsp]
00007f0145bdacb6  mov esi, 0x00
00007f0145bdacbb  mov rax, 0x636570E98530
00007f0145bdacc5  call rax
00007f0145bdacc7  movaps xmm12, [rsp]
00007f0145bdaccc  add rsp, 0x30
00007f0145bdacd0  vmovaps xmm0, [rsp]
00007f0145bdacd5  vmovaps xmm1, [rsp+0x10]
00007f0145bdacdb  vmovaps xmm2, [rsp+0x20]
00007f0145bdace1  vmovaps xmm3, [rsp+0x30]
00007f0145bdace7  vmovaps xmm4, [rsp+0x40]
00007f0145bdaced  vmovaps xmm5, [rsp+0x50]
00007f0145bdacf3  vmovaps xmm6, [rsp+0x60]
00007f0145bdacf9  vmovaps xmm7, [rsp+0x70]
00007f0145bdacff  vmovaps xmm8, [rsp+0x80]
00007f0145bdad08  vmovaps xmm9, [rsp+0x90]
00007f0145bdad11  vmovaps xmm10, [rsp+0xA0]
00007f0145bdad1a  vmovaps xmm11, [rsp+0xB0]
00007f0145bdad23  vmovaps xmm13, [rsp+0xC0]
00007f0145bdad2c  vmovaps xmm14, [rsp+0xD0]
00007f0145bdad35  vmovaps xmm15, [rsp+0xE0]
00007f0145bdad3e  add rsp, 0xF0
00007f0145bdad45  pop r11
00007f0145bdad47  pop r10
00007f0145bdad49  pop r9
00007f0145bdad4b  pop r8
00007f0145bdad4d  pop rsi
00007f0145bdad4e  pop rdi
00007f0145bdad4f  pop rdx
00007f0145bdad50  pop rcx
00007f0145bdad51  pop rax
00007f0145bdad52  add rsp, 0x08
00007f0145bdad56  jmp 0x00007F0145BD6549
00007f0145bdad5b  sub rsp, 0x08
00007f0145bdad5f  push rax
00007f0145bdad60  push rcx
00007f0145bdad61  push rdx
00007f0145bdad62  push rdi
00007f0145bdad63  push rsi
00007f0145bdad64  push r8
00007f0145bdad66  push r9
00007f0145bdad68  push r10
00007f0145bdad6a  push r11
00007f0145bdad6c  sub rsp, 0xF0
00007f0145bdad73  vmovaps [rsp], xmm0
00007f0145bdad78  vmovaps [rsp+0x10], xmm1
00007f0145bdad7e  vmovaps [rsp+0x20], xmm2
00007f0145bdad84  vmovaps [rsp+0x30], xmm3
00007f0145bdad8a  vmovaps [rsp+0x40], xmm4
00007f0145bdad90  vmovaps [rsp+0x50], xmm5
00007f0145bdad96  vmovaps [rsp+0x60], xmm6
00007f0145bdad9c  vmovaps [rsp+0x70], xmm7
00007f0145bdada2  vmovaps [rsp+0x80], xmm8
00007f0145bdadab  vmovaps [rsp+0x90], xmm9
00007f0145bdadb4  vmovaps [rsp+0xA0], xmm10
00007f0145bdadbd  vmovaps [rsp+0xB0], xmm11
00007f0145bdadc6  vmovaps [rsp+0xC0], xmm12
00007f0145bdadcf  vmovaps [rsp+0xD0], xmm13
00007f0145bdadd8  vmovaps [rsp+0xE0], xmm15
00007f0145bdade1  sub rsp, 0x30
00007f0145bdade5  movaps [rsp], xmm14
00007f0145bdadea  movaps [rsp+0x10], xmm9
00007f0145bdadf0  movaps [rsp+0x20], xmm1
00007f0145bdadf5  lea rdi, [rsp]
00007f0145bdadf9  mov esi, 0x00
00007f0145bdadfe  mov rax, 0x636570E98530
00007f0145bdae08  call rax
00007f0145bdae0a  movaps xmm14, [rsp]
00007f0145bdae0f  add rsp, 0x30
00007f0145bdae13  vmovaps xmm0, [rsp]
00007f0145bdae18  vmovaps xmm1, [rsp+0x10]
00007f0145bdae1e  vmovaps xmm2, [rsp+0x20]
00007f0145bdae24  vmovaps xmm3, [rsp+0x30]
00007f0145bdae2a  vmovaps xmm4, [rsp+0x40]
00007f0145bdae30  vmovaps xmm5, [rsp+0x50]
00007f0145bdae36  vmovaps xmm6, [rsp+0x60]
00007f0145bdae3c  vmovaps xmm7, [rsp+0x70]
00007f0145bdae42  vmovaps xmm8, [rsp+0x80]
00007f0145bdae4b  vmovaps xmm9, [rsp+0x90]
00007f0145bdae54  vmovaps xmm10, [rsp+0xA0]
00007f0145bdae5d  vmovaps xmm11, [rsp+0xB0]
00007f0145bdae66  vmovaps xmm12, [rsp+0xC0]
00007f0145bdae6f  vmovaps xmm13, [rsp+0xD0]
00007f0145bdae78  vmovaps xmm15, [rsp+0xE0]
00007f0145bdae81  add rsp, 0xF0
00007f0145bdae88  pop r11
00007f0145bdae8a  pop r10
00007f0145bdae8c  pop r9
00007f0145bdae8e  pop r8
00007f0145bdae90  pop rsi
00007f0145bdae91  pop rdi
00007f0145bdae92  pop rdx
00007f0145bdae93  pop rcx
00007f0145bdae94  pop rax
00007f0145bdae95  add rsp, 0x08
00007f0145bdae99  jmp 0x00007F0145BD6578
00007f0145bdae9e  sub rsp, 0x08
00007f0145bdaea2  push rax
00007f0145bdaea3  push rcx
00007f0145bdaea4  push rdx
00007f0145bdaea5  push rdi
00007f0145bdaea6  push rsi
00007f0145bdaea7  push r8
00007f0145bdaea9  push r9
00007f0145bdaeab  push r10
00007f0145bdaead  push r11
00007f0145bdaeaf  sub rsp, 0xF0
00007f0145bdaeb6  vmovaps [rsp], xmm0
00007f0145bdaebb  vmovaps [rsp+0x10], xmm2
00007f0145bdaec1  vmovaps [rsp+0x20], xmm3
00007f0145bdaec7  vmovaps [rsp+0x30], xmm4
00007f0145bdaecd  vmovaps [rsp+0x40], xmm5
00007f0145bdaed3  vmovaps [rsp+0x50], xmm6
00007f0145bdaed9  vmovaps [rsp+0x60], xmm7
00007f0145bdaedf  vmovaps [rsp+0x70], xmm8
00007f0145bdaee5  vmovaps [rsp+0x80], xmm9
00007f0145bdaeee  vmovaps [rsp+0x90], xmm10
00007f0145bdaef7  vmovaps [rsp+0xA0], xmm11
00007f0145bdaf00  vmovaps [rsp+0xB0], xmm12
00007f0145bdaf09  vmovaps [rsp+0xC0], xmm13
00007f0145bdaf12  vmovaps [rsp+0xD0], xmm14
00007f0145bdaf1b  vmovaps [rsp+0xE0], xmm15
00007f0145bdaf24  sub rsp, 0x30
00007f0145bdaf28  movaps [rsp], xmm1
00007f0145bdaf2c  movaps [rsp+0x10], xmm13
00007f0145bdaf32  movaps [rsp+0x20], xmm8
00007f0145bdaf38  lea rdi, [rsp]
00007f0145bdaf3c  mov esi, 0x00
00007f0145bdaf41  mov rax, 0x636570E98530
00007f0145bdaf4b  call rax
00007f0145bdaf4d  movaps xmm1, [rsp]
00007f0145bdaf51  add rsp, 0x30
00007f0145bdaf55  vmovaps xmm0, [rsp]
00007f0145bdaf5a  vmovaps xmm2, [rsp+0x10]
00007f0145bdaf60  vmovaps xmm3, [rsp+0x20]
00007f0145bdaf66  vmovaps xmm4, [rsp+0x30]
00007f0145bdaf6c  vmovaps xmm5, [rsp+0x40]
00007f0145bdaf72  vmovaps xmm6, [rsp+0x50]
00007f0145bdaf78  vmovaps xmm7, [rsp+0x60]
00007f0145bdaf7e  vmovaps xmm8, [rsp+0x70]
00007f0145bdaf84  vmovaps xmm9, [rsp+0x80]
00007f0145bdaf8d  vmovaps xmm10, [rsp+0x90]
00007f0145bdaf96  vmovaps xmm11, [rsp+0xA0]
00007f0145bdaf9f  vmovaps xmm12, [rsp+0xB0]
00007f0145bdafa8  vmovaps xmm13, [rsp+0xC0]
00007f0145bdafb1  vmovaps xmm14, [rsp+0xD0]
00007f0145bdafba  vmovaps xmm15, [rsp+0xE0]
00007f0145bdafc3  add rsp, 0xF0
00007f0145bdafca  pop r11
00007f0145bdafcc  pop r10
00007f0145bdafce  pop r9
00007f0145bdafd0  pop r8
00007f0145bdafd2  pop rsi
00007f0145bdafd3  pop rdi
00007f0145bdafd4  pop rdx
00007f0145bdafd5  pop rcx
00007f0145bdafd6  pop rax
00007f0145bdafd7  add rsp, 0x08
00007f0145bdafdb  jmp 0x00007F0145BD659A
00007f0145bdafe0  call 0x00007F0145A0C260
00007f0145bdafe5  jmp 0x00007F0145BD65A8
00007f0145bdafea  call 0x00007F0145ADE950
00007f0145bdafef  jmp 0x00007F0145BD65B2
00007f0145bdaff4  sub rsp, 0x08
00007f0145bdaff8  push rax
00007f0145bdaff9  push rcx
00007f0145bdaffa  push rdx
00007f0145bdaffb  push rdi
00007f0145bdaffc  push rsi
00007f0145bdaffd  push r8
00007f0145bdafff  push r9
00007f0145bdb001  push r10
00007f0145bdb003  push r11
00007f0145bdb005  sub rsp, 0xF0
00007f0145bdb00c  vmovaps [rsp], xmm0
00007f0145bdb011  vmovaps [rsp+0x10], xmm1
00007f0145bdb017  vmovaps [rsp+0x20], xmm2
00007f0145bdb01d  vmovaps [rsp+0x30], xmm3
00007f0145bdb023  vmovaps [rsp+0x40], xmm4
00007f0145bdb029  vmovaps [rsp+0x50], xmm5
00007f0145bdb02f  vmovaps [rsp+0x60], xmm6
00007f0145bdb035  vmovaps [rsp+0x70], xmm7
00007f0145bdb03b  vmovaps [rsp+0x80], xmm9
00007f0145bdb044  vmovaps [rsp+0x90], xmm10
00007f0145bdb04d  vmovaps [rsp+0xA0], xmm11
00007f0145bdb056  vmovaps [rsp+0xB0], xmm12
00007f0145bdb05f  vmovaps [rsp+0xC0], xmm13
00007f0145bdb068  vmovaps [rsp+0xD0], xmm14
00007f0145bdb071  vmovaps [rsp+0xE0], xmm15
00007f0145bdb07a  sub rsp, 0x30
00007f0145bdb07e  movaps [rsp], xmm8
00007f0145bdb083  movaps [rsp+0x10], xmm15
00007f0145bdb089  movaps [rsp+0x20], xmm7
00007f0145bdb08e  lea rdi, [rsp]
00007f0145bdb092  mov esi, 0x00
00007f0145bdb097  mov rax, 0x636570E98530
00007f0145bdb0a1  call rax
00007f0145bdb0a3  movaps xmm8, [rsp]
00007f0145bdb0a8  add rsp, 0x30
00007f0145bdb0ac  vmovaps xmm0, [rsp]
00007f0145bdb0b1  vmovaps xmm1, [rsp+0x10]
00007f0145bdb0b7  vmovaps xmm2, [rsp+0x20]
00007f0145bdb0bd  vmovaps xmm3, [rsp+0x30]
00007f0145bdb0c3  vmovaps xmm4, [rsp+0x40]
00007f0145bdb0c9  vmovaps xmm5, [rsp+0x50]
00007f0145bdb0cf  vmovaps xmm6, [rsp+0x60]
00007f0145bdb0d5  vmovaps xmm7, [rsp+0x70]
00007f0145bdb0db  vmovaps xmm9, [rsp+0x80]
00007f0145bdb0e4  vmovaps xmm10, [rsp+0x90]
00007f0145bdb0ed  vmovaps xmm11, [rsp+0xA0]
00007f0145bdb0f6  vmovaps xmm12, [rsp+0xB0]
00007f0145bdb0ff  vmovaps xmm13, [rsp+0xC0]
00007f0145bdb108  vmovaps xmm14, [rsp+0xD0]
00007f0145bdb111  vmovaps xmm15, [rsp+0xE0]
00007f0145bdb11a  add rsp, 0xF0
00007f0145bdb121  pop r11
00007f0145bdb123  pop r10
00007f0145bdb125  pop r9
00007f0145bdb127  pop r8
00007f0145bdb129  pop rsi
00007f0145bdb12a  pop rdi
00007f0145bdb12b  pop rdx
00007f0145bdb12c  pop rcx
00007f0145bdb12d  pop rax
00007f0145bdb12e  add rsp, 0x08
00007f0145bdb132  jmp 0x00007F0145BD65D4
00007f0145bdb137  sub rsp, 0x08
00007f0145bdb13b  push rax
00007f0145bdb13c  push rcx
00007f0145bdb13d  push rdx
00007f0145bdb13e  push rdi
00007f0145bdb13f  push rsi
00007f0145bdb140  push r8
00007f0145bdb142  push r9
00007f0145bdb144  push r10
00007f0145bdb146  push r11
00007f0145bdb148  sub rsp, 0xF0
00007f0145bdb14f  vmovaps [rsp], xmm0
00007f0145bdb154  vmovaps [rsp+0x10], xmm1
00007f0145bdb15a  vmovaps [rsp+0x20], xmm2
00007f0145bdb160  vmovaps [rsp+0x30], xmm3
00007f0145bdb166  vmovaps [rsp+0x40], xmm4
00007f0145bdb16c  vmovaps [rsp+0x50], xmm5
00007f0145bdb172  vmovaps [rsp+0x60], xmm6
00007f0145bdb178  vmovaps [rsp+0x70], xmm8
00007f0145bdb17e  vmovaps [rsp+0x80], xmm9
00007f0145bdb187  vmovaps [rsp+0x90], xmm10
00007f0145bdb190  vmovaps [rsp+0xA0], xmm11
00007f0145bdb199  vmovaps [rsp+0xB0], xmm12
00007f0145bdb1a2  vmovaps [rsp+0xC0], xmm13
00007f0145bdb1ab  vmovaps [rsp+0xD0], xmm14
00007f0145bdb1b4  vmovaps [rsp+0xE0], xmm15
00007f0145bdb1bd  sub rsp, 0x30
00007f0145bdb1c1  movaps [rsp], xmm7
00007f0145bdb1c5  movaps [rsp+0x10], xmm9
00007f0145bdb1cb  movaps [rsp+0x20], xmm15
00007f0145bdb1d1  lea rdi, [rsp]
00007f0145bdb1d5  mov esi, 0x00
00007f0145bdb1da  mov rax, 0x636570E98530
00007f0145bdb1e4  call rax
00007f0145bdb1e6  movaps xmm7, [rsp]
00007f0145bdb1ea  add rsp, 0x30
00007f0145bdb1ee  vmovaps xmm0, [rsp]
00007f0145bdb1f3  vmovaps xmm1, [rsp+0x10]
00007f0145bdb1f9  vmovaps xmm2, [rsp+0x20]
00007f0145bdb1ff  vmovaps xmm3, [rsp+0x30]
00007f0145bdb205  vmovaps xmm4, [rsp+0x40]
00007f0145bdb20b  vmovaps xmm5, [rsp+0x50]
00007f0145bdb211  vmovaps xmm6, [rsp+0x60]
00007f0145bdb217  vmovaps xmm8, [rsp+0x70]
00007f0145bdb21d  vmovaps xmm9, [rsp+0x80]
00007f0145bdb226  vmovaps xmm10, [rsp+0x90]
00007f0145bdb22f  vmovaps xmm11, [rsp+0xA0]
00007f0145bdb238  vmovaps xmm12, [rsp+0xB0]
00007f0145bdb241  vmovaps xmm13, [rsp+0xC0]
00007f0145bdb24a  vmovaps xmm14, [rsp+0xD0]
00007f0145bdb253  vmovaps xmm15, [rsp+0xE0]
00007f0145bdb25c  add rsp, 0xF0
00007f0145bdb263  pop r11
00007f0145bdb265  pop r10
00007f0145bdb267  pop r9
00007f0145bdb269  pop r8
00007f0145bdb26b  pop rsi
00007f0145bdb26c  pop rdi
00007f0145bdb26d  pop rdx
00007f0145bdb26e  pop rcx
00007f0145bdb26f  pop rax
00007f0145bdb270  add rsp, 0x08
00007f0145bdb274  jmp 0x00007F0145BD6601
00007f0145bdb279  sub rsp, 0x08
00007f0145bdb27d  push rax
00007f0145bdb27e  push rcx
00007f0145bdb27f  push rdx
00007f0145bdb280  push rdi
00007f0145bdb281  push rsi
00007f0145bdb282  push r8
00007f0145bdb284  push r9
00007f0145bdb286  push r10
00007f0145bdb288  push r11
00007f0145bdb28a  sub rsp, 0xF0
00007f0145bdb291  vmovaps [rsp], xmm0
00007f0145bdb296  vmovaps [rsp+0x10], xmm1
00007f0145bdb29c  vmovaps [rsp+0x20], xmm2
00007f0145bdb2a2  vmovaps [rsp+0x30], xmm3
00007f0145bdb2a8  vmovaps [rsp+0x40], xmm4
00007f0145bdb2ae  vmovaps [rsp+0x50], xmm5
00007f0145bdb2b4  vmovaps [rsp+0x60], xmm6
00007f0145bdb2ba  vmovaps [rsp+0x70], xmm7
00007f0145bdb2c0  vmovaps [rsp+0x80], xmm8
00007f0145bdb2c9  vmovaps [rsp+0x90], xmm10
00007f0145bdb2d2  vmovaps [rsp+0xA0], xmm11
00007f0145bdb2db  vmovaps [rsp+0xB0], xmm12
00007f0145bdb2e4  vmovaps [rsp+0xC0], xmm13
00007f0145bdb2ed  vmovaps [rsp+0xD0], xmm14
00007f0145bdb2f6  vmovaps [rsp+0xE0], xmm15
00007f0145bdb2ff  sub rsp, 0x30
00007f0145bdb303  movaps [rsp], xmm9
00007f0145bdb308  movaps [rsp+0x10], xmm13
00007f0145bdb30e  movaps [rsp+0x20], xmm15
00007f0145bdb314  lea rdi, [rsp]
00007f0145bdb318  mov esi, 0x00
00007f0145bdb31d  mov rax, 0x636570E98530
00007f0145bdb327  call rax
00007f0145bdb329  movaps xmm9, [rsp]
00007f0145bdb32e  add rsp, 0x30
00007f0145bdb332  vmovaps xmm0, [rsp]
00007f0145bdb337  vmovaps xmm1, [rsp+0x10]
00007f0145bdb33d  vmovaps xmm2, [rsp+0x20]
00007f0145bdb343  vmovaps xmm3, [rsp+0x30]
00007f0145bdb349  vmovaps xmm4, [rsp+0x40]
00007f0145bdb34f  vmovaps xmm5, [rsp+0x50]
00007f0145bdb355  vmovaps xmm6, [rsp+0x60]
00007f0145bdb35b  vmovaps xmm7, [rsp+0x70]
00007f0145bdb361  vmovaps xmm8, [rsp+0x80]
00007f0145bdb36a  vmovaps xmm10, [rsp+0x90]
00007f0145bdb373  vmovaps xmm11, [rsp+0xA0]
00007f0145bdb37c  vmovaps xmm12, [rsp+0xB0]
00007f0145bdb385  vmovaps xmm13, [rsp+0xC0]
00007f0145bdb38e  vmovaps xmm14, [rsp+0xD0]
00007f0145bdb397  vmovaps xmm15, [rsp+0xE0]
00007f0145bdb3a0  add rsp, 0xF0
00007f0145bdb3a7  pop r11
00007f0145bdb3a9  pop r10
00007f0145bdb3ab  pop r9
00007f0145bdb3ad  pop r8
00007f0145bdb3af  pop rsi
00007f0145bdb3b0  pop rdi
00007f0145bdb3b1  pop rdx
00007f0145bdb3b2  pop rcx
00007f0145bdb3b3  pop rax
00007f0145bdb3b4  add rsp, 0x08
00007f0145bdb3b8  jmp 0x00007F0145BD662F
00007f0145bdb3bd  sub rsp, 0x08
00007f0145bdb3c1  push rax
00007f0145bdb3c2  push rcx
00007f0145bdb3c3  push rdx
00007f0145bdb3c4  push rdi
00007f0145bdb3c5  push rsi
00007f0145bdb3c6  push r8
00007f0145bdb3c8  push r9
00007f0145bdb3ca  push r10
00007f0145bdb3cc  push r11
00007f0145bdb3ce  sub rsp, 0xF0
00007f0145bdb3d5  vmovaps [rsp], xmm0
00007f0145bdb3da  vmovaps [rsp+0x10], xmm1
00007f0145bdb3e0  vmovaps [rsp+0x20], xmm2
00007f0145bdb3e6  vmovaps [rsp+0x30], xmm3
00007f0145bdb3ec  vmovaps [rsp+0x40], xmm4
00007f0145bdb3f2  vmovaps [rsp+0x50], xmm5
00007f0145bdb3f8  vmovaps [rsp+0x60], xmm6
00007f0145bdb3fe  vmovaps [rsp+0x70], xmm7
00007f0145bdb404  vmovaps [rsp+0x80], xmm8
00007f0145bdb40d  vmovaps [rsp+0x90], xmm9
00007f0145bdb416  vmovaps [rsp+0xA0], xmm10
00007f0145bdb41f  vmovaps [rsp+0xB0], xmm11
00007f0145bdb428  vmovaps [rsp+0xC0], xmm12
00007f0145bdb431  vmovaps [rsp+0xD0], xmm13
00007f0145bdb43a  vmovaps [rsp+0xE0], xmm14
00007f0145bdb443  sub rsp, 0x30
00007f0145bdb447  movaps [rsp], xmm15
00007f0145bdb44c  movaps [rsp+0x10], xmm11
00007f0145bdb452  movaps [rsp+0x20], xmm12
00007f0145bdb458  lea rdi, [rsp]
00007f0145bdb45c  mov esi, 0x00
00007f0145bdb461  mov rax, 0x636570E98530
00007f0145bdb46b  call rax
00007f0145bdb46d  movaps xmm15, [rsp]
00007f0145bdb472  add rsp, 0x30
00007f0145bdb476  vmovaps xmm0, [rsp]
00007f0145bdb47b  vmovaps xmm1, [rsp+0x10]
00007f0145bdb481  vmovaps xmm2, [rsp+0x20]
00007f0145bdb487  vmovaps xmm3, [rsp+0x30]
00007f0145bdb48d  vmovaps xmm4, [rsp+0x40]
00007f0145bdb493  vmovaps xmm5, [rsp+0x50]
00007f0145bdb499  vmovaps xmm6, [rsp+0x60]
00007f0145bdb49f  vmovaps xmm7, [rsp+0x70]
00007f0145bdb4a5  vmovaps xmm8, [rsp+0x80]
00007f0145bdb4ae  vmovaps xmm9, [rsp+0x90]
00007f0145bdb4b7  vmovaps xmm10, [rsp+0xA0]
00007f0145bdb4c0  vmovaps xmm11, [rsp+0xB0]
00007f0145bdb4c9  vmovaps xmm12, [rsp+0xC0]
00007f0145bdb4d2  vmovaps xmm13, [rsp+0xD0]
00007f0145bdb4db  vmovaps xmm14, [rsp+0xE0]
00007f0145bdb4e4  add rsp, 0xF0
00007f0145bdb4eb  pop r11
00007f0145bdb4ed  pop r10
00007f0145bdb4ef  pop r9
00007f0145bdb4f1  pop r8
00007f0145bdb4f3  pop rsi
00007f0145bdb4f4  pop rdi
00007f0145bdb4f5  pop rdx
00007f0145bdb4f6  pop rcx
00007f0145bdb4f7  pop rax
00007f0145bdb4f8  add rsp, 0x08
00007f0145bdb4fc  jmp 0x00007F0145BD664A
00007f0145bdb501  sub rsp, 0x08
00007f0145bdb505  push rax
00007f0145bdb506  push rcx
00007f0145bdb507  push rdx
00007f0145bdb508  push rdi
00007f0145bdb509  push rsi
00007f0145bdb50a  push r8
00007f0145bdb50c  push r9
00007f0145bdb50e  push r10
00007f0145bdb510  push r11
00007f0145bdb512  sub rsp, 0xF0
00007f0145bdb519  vmovaps [rsp], xmm0
00007f0145bdb51e  vmovaps [rsp+0x10], xmm1
00007f0145bdb524  vmovaps [rsp+0x20], xmm2
00007f0145bdb52a  vmovaps [rsp+0x30], xmm3
00007f0145bdb530  vmovaps [rsp+0x40], xmm4
00007f0145bdb536  vmovaps [rsp+0x50], xmm5
00007f0145bdb53c  vmovaps [rsp+0x60], xmm6
00007f0145bdb542  vmovaps [rsp+0x70], xmm7
00007f0145bdb548  vmovaps [rsp+0x80], xmm8
00007f0145bdb551  vmovaps [rsp+0x90], xmm9
00007f0145bdb55a  vmovaps [rsp+0xA0], xmm10
00007f0145bdb563  vmovaps [rsp+0xB0], xmm11
00007f0145bdb56c  vmovaps [rsp+0xC0], xmm12
00007f0145bdb575  vmovaps [rsp+0xD0], xmm14
00007f0145bdb57e  vmovaps [rsp+0xE0], xmm15
00007f0145bdb587  sub rsp, 0x30
00007f0145bdb58b  movaps [rsp], xmm13
00007f0145bdb590  movaps [rsp+0x10], xmm10
00007f0145bdb596  movaps [rsp+0x20], xmm14
00007f0145bdb59c  lea rdi, [rsp]
00007f0145bdb5a0  mov esi, 0x00
00007f0145bdb5a5  mov rax, 0x636570E98530
00007f0145bdb5af  call rax
00007f0145bdb5b1  movaps xmm13, [rsp]
00007f0145bdb5b6  add rsp, 0x30
00007f0145bdb5ba  vmovaps xmm0, [rsp]
00007f0145bdb5bf  vmovaps xmm1, [rsp+0x10]
00007f0145bdb5c5  vmovaps xmm2, [rsp+0x20]
00007f0145bdb5cb  vmovaps xmm3, [rsp+0x30]
00007f0145bdb5d1  vmovaps xmm4, [rsp+0x40]
00007f0145bdb5d7  vmovaps xmm5, [rsp+0x50]
00007f0145bdb5dd  vmovaps xmm6, [rsp+0x60]
00007f0145bdb5e3  vmovaps xmm7, [rsp+0x70]
00007f0145bdb5e9  vmovaps xmm8, [rsp+0x80]
00007f0145bdb5f2  vmovaps xmm9, [rsp+0x90]
00007f0145bdb5fb  vmovaps xmm10, [rsp+0xA0]
00007f0145bdb604  vmovaps xmm11, [rsp+0xB0]
00007f0145bdb60d  vmovaps xmm12, [rsp+0xC0]
00007f0145bdb616  vmovaps xmm14, [rsp+0xD0]
00007f0145bdb61f  vmovaps xmm15, [rsp+0xE0]
00007f0145bdb628  add rsp, 0xF0
00007f0145bdb62f  pop r11
00007f0145bdb631  pop r10
00007f0145bdb633  pop r9
00007f0145bdb635  pop r8
00007f0145bdb637  pop rsi
00007f0145bdb638  pop rdi
00007f0145bdb639  pop rdx
00007f0145bdb63a  pop rcx
00007f0145bdb63b  pop rax
00007f0145bdb63c  add rsp, 0x08
00007f0145bdb640  jmp 0x00007F0145BD666D
00007f0145bdb645  sub rsp, 0x08
00007f0145bdb649  push rax
00007f0145bdb64a  push rcx
00007f0145bdb64b  push rdx
00007f0145bdb64c  push rdi
00007f0145bdb64d  push rsi
00007f0145bdb64e  push r8
00007f0145bdb650  push r9
00007f0145bdb652  push r10
00007f0145bdb654  push r11
00007f0145bdb656  sub rsp, 0xF0
00007f0145bdb65d  vmovaps [rsp], xmm0
00007f0145bdb662  vmovaps [rsp+0x10], xmm1
00007f0145bdb668  vmovaps [rsp+0x20], xmm2
00007f0145bdb66e  vmovaps [rsp+0x30], xmm3
00007f0145bdb674  vmovaps [rsp+0x40], xmm4
00007f0145bdb67a  vmovaps [rsp+0x50], xmm5
00007f0145bdb680  vmovaps [rsp+0x60], xmm6
00007f0145bdb686  vmovaps [rsp+0x70], xmm7
00007f0145bdb68c  vmovaps [rsp+0x80], xmm8
00007f0145bdb695  vmovaps [rsp+0x90], xmm9
00007f0145bdb69e  vmovaps [rsp+0xA0], xmm10
00007f0145bdb6a7  vmovaps [rsp+0xB0], xmm11
00007f0145bdb6b0  vmovaps [rsp+0xC0], xmm12
00007f0145bdb6b9  vmovaps [rsp+0xD0], xmm13
00007f0145bdb6c2  vmovaps [rsp+0xE0], xmm15
00007f0145bdb6cb  sub rsp, 0x30
00007f0145bdb6cf  movaps [rsp], xmm14
00007f0145bdb6d4  movaps [rsp+0x10], xmm1
00007f0145bdb6d9  movaps [rsp+0x20], xmm7
00007f0145bdb6de  lea rdi, [rsp]
00007f0145bdb6e2  mov esi, 0x00
00007f0145bdb6e7  mov rax, 0x636570E98530
00007f0145bdb6f1  call rax
00007f0145bdb6f3  movaps xmm14, [rsp]
00007f0145bdb6f8  add rsp, 0x30
00007f0145bdb6fc  vmovaps xmm0, [rsp]
00007f0145bdb701  vmovaps xmm1, [rsp+0x10]
00007f0145bdb707  vmovaps xmm2, [rsp+0x20]
00007f0145bdb70d  vmovaps xmm3, [rsp+0x30]
00007f0145bdb713  vmovaps xmm4, [rsp+0x40]
00007f0145bdb719  vmovaps xmm5, [rsp+0x50]
00007f0145bdb71f  vmovaps xmm6, [rsp+0x60]
00007f0145bdb725  vmovaps xmm7, [rsp+0x70]
00007f0145bdb72b  vmovaps xmm8, [rsp+0x80]
00007f0145bdb734  vmovaps xmm9, [rsp+0x90]
00007f0145bdb73d  vmovaps xmm10, [rsp+0xA0]
00007f0145bdb746  vmovaps xmm11, [rsp+0xB0]
00007f0145bdb74f  vmovaps xmm12, [rsp+0xC0]
00007f0145bdb758  vmovaps xmm13, [rsp+0xD0]
00007f0145bdb761  vmovaps xmm15, [rsp+0xE0]
00007f0145bdb76a  add rsp, 0xF0
00007f0145bdb771  pop r11
00007f0145bdb773  pop r10
00007f0145bdb775  pop r9
00007f0145bdb777  pop r8
00007f0145bdb779  pop rsi
00007f0145bdb77a  pop rdi
00007f0145bdb77b  pop rdx
00007f0145bdb77c  pop rcx
00007f0145bdb77d  pop rax
00007f0145bdb77e  add rsp, 0x08
00007f0145bdb782  jmp 0x00007F0145BD6690
00007f0145bdb787  sub rsp, 0x08
00007f0145bdb78b  push rax
00007f0145bdb78c  push rcx
00007f0145bdb78d  push rdx
00007f0145bdb78e  push rdi
00007f0145bdb78f  push rsi
00007f0145bdb790  push r8
00007f0145bdb792  push r9
00007f0145bdb794  push r10
00007f0145bdb796  push r11
00007f0145bdb798  sub rsp, 0xF0
00007f0145bdb79f  vmovaps [rsp], xmm0
00007f0145bdb7a4  vmovaps [rsp+0x10], xmm2
00007f0145bdb7aa  vmovaps [rsp+0x20], xmm3
00007f0145bdb7b0  vmovaps [rsp+0x30], xmm4
00007f0145bdb7b6  vmovaps [rsp+0x40], xmm5
00007f0145bdb7bc  vmovaps [rsp+0x50], xmm6
00007f0145bdb7c2  vmovaps [rsp+0x60], xmm7
00007f0145bdb7c8  vmovaps [rsp+0x70], xmm8
00007f0145bdb7ce  vmovaps [rsp+0x80], xmm9
00007f0145bdb7d7  vmovaps [rsp+0x90], xmm10
00007f0145bdb7e0  vmovaps [rsp+0xA0], xmm11
00007f0145bdb7e9  vmovaps [rsp+0xB0], xmm12
00007f0145bdb7f2  vmovaps [rsp+0xC0], xmm13
00007f0145bdb7fb  vmovaps [rsp+0xD0], xmm14
00007f0145bdb804  vmovaps [rsp+0xE0], xmm15
00007f0145bdb80d  sub rsp, 0x30
00007f0145bdb811  movaps [rsp], xmm1
00007f0145bdb815  movaps [rsp+0x10], xmm8
00007f0145bdb81b  movaps [rsp+0x20], xmm9
00007f0145bdb821  lea rdi, [rsp]
00007f0145bdb825  mov esi, 0x00
00007f0145bdb82a  mov rax, 0x636570E98530
00007f0145bdb834  call rax
00007f0145bdb836  movaps xmm1, [rsp]
00007f0145bdb83a  add rsp, 0x30
00007f0145bdb83e  vmovaps xmm0, [rsp]
00007f0145bdb843  vmovaps xmm2, [rsp+0x10]
00007f0145bdb849  vmovaps xmm3, [rsp+0x20]
00007f0145bdb84f  vmovaps xmm4, [rsp+0x30]
00007f0145bdb855  vmovaps xmm5, [rsp+0x40]
00007f0145bdb85b  vmovaps xmm6, [rsp+0x50]
00007f0145bdb861  vmovaps xmm7, [rsp+0x60]
00007f0145bdb867  vmovaps xmm8, [rsp+0x70]
00007f0145bdb86d  vmovaps xmm9, [rsp+0x80]
00007f0145bdb876  vmovaps xmm10, [rsp+0x90]
00007f0145bdb87f  vmovaps xmm11, [rsp+0xA0]
00007f0145bdb888  vmovaps xmm12, [rsp+0xB0]
00007f0145bdb891  vmovaps xmm13, [rsp+0xC0]
00007f0145bdb89a  vmovaps xmm14, [rsp+0xD0]
00007f0145bdb8a3  vmovaps xmm15, [rsp+0xE0]
00007f0145bdb8ac  add rsp, 0xF0
00007f0145bdb8b3  pop r11
00007f0145bdb8b5  pop r10
00007f0145bdb8b7  pop r9
00007f0145bdb8b9  pop r8
00007f0145bdb8bb  pop rsi
00007f0145bdb8bc  pop rdi
00007f0145bdb8bd  pop rdx
00007f0145bdb8be  pop rcx
00007f0145bdb8bf  pop rax
00007f0145bdb8c0  add rsp, 0x08
00007f0145bdb8c4  jmp 0x00007F0145BD66B2
00007f0145bdb8c9  call 0x00007F0145AB3E40
00007f0145bdb8ce  jmp 0x00007F0145BD66C0
00007f0145bdb8d3  call 0x00007F0145A0C380
00007f0145bdb8d8  jmp 0x00007F0145BD66CA
00007f0145bdb8dd  call 0x00007F0145A0D600
00007f0145bdb8e2  jmp 0x00007F0145BD66D4
00007f0145bdb8e7  call 0x00007F01459FF540
00007f0145bdb8ec  jmp 0x00007F0145BD66DE
00007f0145bdb8f1  int3
00007f0145bdb8f2  nop [rax+rax*1], ax
00007f0145bdb8fb  nop [rax+rax*1], eax
00007f0145bdb900  mov eax, [r15+0x48]
00007f0145bdb904  lea r14d, [eax+0x01]
00007f0145bdb909  mov [rsp+0x10], r14d
00007f0145bdb90e  mov r14d, r14d
00007f0145bdb911  mov [r15+0x48], r14
00007f0145bdb915  xor eax, eax
00007f0145bdb917  mov r14d, [rsp+0x10]
00007f0145bdb91c  cmp r14d, 0x1F4
00007f0145bdb923  cmc
00007f0145bdb924  lahf
00007f0145bdb925  seto al
00007f0145bdb928  mov [r15+0x108], eax
00007f0145bdb92f  mov eax, [r15+0x108]
00007f0145bdb936  sahf
00007f0145bdb937  jnz 0x00007F0145BDB969
00007f0145bdb939  cmp dword ptr [r15+0x318], 0x00
00007f0145bdb941  jz 0x00007F0145BE1AB0
00007f0145bdb947  nop [rax+rax*1], ax
00007f0145bdb950  nop [rax+rax*1], eax
00007f0145bdb958  mov eax, 0x410450
00007f0145bdb95d  mov [r15+0x100], rax
00007f0145bdb964  jmp 0x00007F01459FE110
00007f0145bdb969  cmp dword ptr [r15+0x318], 0x00
00007f0145bdb971  jz 0x00007F0145BDB9A0
00007f0145bdb977  nop [rax+rax*1], ax
00007f0145bdb980  nop [rax+rax*1], eax
00007f0145bdb988  mov eax, 0x410274
00007f0145bdb98d  mov [r15+0x100], rax
00007f0145bdb994  jmp 0x00007F01459FE110
00007f0145bdb999  int3
00007f0145bdb99a  int3
00007f0145bdb99b  nop [rax+rax*1], eax
00007f0145bdb9a0  mov rax, [r15+0x40]
00007f0145bdb9a4  movaps xmm1, [r15+0x1D0]
00007f0145bdb9ac  vmovaps [rsp+0x10], xmm1
00007f0145bdb9b2  vmovaps xmm15, [rsp+0x10]
00007f0145bdb9b8  por xmm1, xmm15
00007f0145bdb9bd  movaps xmm14, [r15+0x1A0]
00007f0145bdb9c5  vmovaps [rsp+0x10], xmm14
00007f0145bdb9cb  vmovaps xmm13, [rsp+0x10]
00007f0145bdb9d1  por xmm14, xmm13
00007f0145bdb9d6  lea r14, [rax+0x30]
00007f0145bdb9da  mov r12, [r13+r14*1]
00007f0145bdb9df  lea r14, [rax+0x38]
00007f0145bdb9e3  mov r11, [r13+r14*1]
00007f0145bdb9e8  movq xmm13, r12
00007f0145bdb9ed  movq xmm12, r11
00007f0145bdb9f2  movq xmm13, xmm13
00007f0145bdb9f7  vmovaps [rsp+0x10], xmm13
00007f0145bdb9fd  movq xmm13, xmm13
00007f0145bdba02  movaps [r15+0x130], xmm13
00007f0145bdba0a  movq xmm12, xmm12
00007f0145bdba0f  vmovaps [rsp+0x20], xmm12
00007f0145bdba15  movq xmm12, xmm12
00007f0145bdba1a  movaps [r15+0x280], xmm12
00007f0145bdba22  movaps xmm13, [r15+0x270]
00007f0145bdba2a  vmovaps [rsp+0x30], xmm13
00007f0145bdba30  vmovaps xmm12, [rsp+0x30]
00007f0145bdba36  por xmm13, xmm12
00007f0145bdba3b  lea r14, [rax+0x20]
00007f0145bdba3f  mov r12, [r13+r14*1]
00007f0145bdba44  lea r14, [rax+0x28]
00007f0145bdba48  mov r11, [r13+r14*1]
00007f0145bdba4d  movq xmm12, r12
00007f0145bdba52  movq xmm11, r11
00007f0145bdba57  movq xmm12, xmm12
00007f0145bdba5c  vmovaps [rsp+0x30], xmm12
00007f0145bdba62  movq xmm12, xmm12
00007f0145bdba67  movaps [r15+0x150], xmm12
00007f0145bdba6f  movq xmm11, xmm11
00007f0145bdba74  vmovaps [rsp+0x40], xmm11
00007f0145bdba7a  movq xmm11, xmm11
00007f0145bdba7f  movaps [r15+0x140], xmm11
00007f0145bdba87  lea r14, [rax+0x10]
00007f0145bdba8b  mov r12, [r13+r14*1]
00007f0145bdba90  lea r14, [rax+0x18]
00007f0145bdba94  mov r11, [r13+r14*1]
00007f0145bdba99  movq xmm12, r12
00007f0145bdba9e  movq xmm11, r11
00007f0145bdbaa3  movq xmm12, xmm12
00007f0145bdbaa8  vmovaps [rsp+0x50], xmm12
00007f0145bdbaae  movq xmm12, xmm12
00007f0145bdbab3  movaps [r15+0x170], xmm12
00007f0145bdbabb  movq xmm11, xmm11
00007f0145bdbac0  vmovaps [rsp+0x60], xmm11
00007f0145bdbac6  movq xmm11, xmm11
00007f0145bdbacb  movaps [r15+0x160], xmm11
00007f0145bdbad3  mov r14, [r13+rax*1]
00007f0145bdbad8  vmovq xmm12, r14
00007f0145bdbadd  vpbroadcastq xmm12, xmm12
00007f0145bdbae2  lea r14, [rax+0x08]
00007f0145bdbae6  mov rax, [r13+r14*1]
00007f0145bdbaeb  movq xmm11, rax
00007f0145bdbaf0  movaps [r15+0x230], xmm11
00007f0145bdbaf8  mov rax, [r15+0xF8]
00007f0145bdbaff  lea r14, [rax+0x50]
00007f0145bdbb03  movups xmm11, [r13+r14*1]
00007f0145bdbb09  lea r14, [rax+0x60]
00007f0145bdbb0d  movups xmm10, [r13+r14*1]
00007f0145bdbb13  lea r14, [rax+0x30]
00007f0145bdbb17  movups xmm9, [r13+r14*1]
00007f0145bdbb1d  mov r14, [r15+0x50]
00007f0145bdbb21  mov [r15+0x60], r14
00007f0145bdbb25  mov qword ptr [r15+0x58], 0x40
00007f0145bdbb2d  movaps xmm8, xmm12
00007f0145bdbb31  mulpd xmm8, xmm15
00007f0145bdbb36  vcmppd xmm7, xmm8, xmm8, 0x03
00007f0145bdbb3c  ptest xmm7, xmm7
00007f0145bdbb41  jnz 0x00007F0145BDC96A
00007f0145bdbb47  movq xmm15, qword ptr [r15+0x230]
00007f0145bdbb50  vmovaps [rsp+0x70], xmm15
00007f0145bdbb56  vpermilpd xmm15, xmm15, 0x00
00007f0145bdbb5c  movaps xmm7, xmm9
00007f0145bdbb60  mulpd xmm7, xmm15
00007f0145bdbb65  vcmppd xmm6, xmm7, xmm7, 0x03
00007f0145bdbb6a  ptest xmm6, xmm6
00007f0145bdbb6f  jnz 0x00007F0145BDCAAE
00007f0145bdbb75  vxorps xmm15, xmm15, xmm15
00007f0145bdbb7a  vpbroadcastq xmm15, xmm15
00007f0145bdbb7f  movaps xmm9, xmm12
00007f0145bdbb83  mulpd xmm9, xmm10
00007f0145bdbb88  vcmppd xmm6, xmm9, xmm9, 0x03
00007f0145bdbb8e  ptest xmm6, xmm6
00007f0145bdbb93  jnz 0x00007F0145BDCBF0
00007f0145bdbb99  movaps xmm10, xmm12
00007f0145bdbb9d  mulpd xmm10, xmm11
00007f0145bdbba2  vcmppd xmm6, xmm10, xmm10, 0x03
00007f0145bdbba8  ptest xmm6, xmm6
00007f0145bdbbad  jnz 0x00007F0145BDCD34
00007f0145bdbbb3  movaps xmm11, [r15+0x1F0]
00007f0145bdbbbb  movaps xmm6, xmm12
00007f0145bdbbbf  mulpd xmm6, xmm11
00007f0145bdbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
00007f0145bdbbc9  ptest xmm5, xmm5
00007f0145bdbbce  jnz 0x00007F0145BDCE78
00007f0145bdbbd4  movaps xmm12, [r15+0x2A0]
00007f0145bdbbdc  vmovaps [rsp+0x80], xmm12
00007f0145bdbbe5  vmovaps xmm11, [rsp+0x80]
00007f0145bdbbee  por xmm12, xmm11
00007f0145bdbbf3  movaps xmm11, [r15+0x250]
00007f0145bdbbfb  vmovaps [rsp+0x80], xmm11
00007f0145bdbc04  vmovaps xmm5, [rsp+0x80]
00007f0145bdbc0d  por xmm11, xmm5
00007f0145bdbc12  vmovaps xmm4, [rsp+0x70]
00007f0145bdbc18  vpermilpd xmm4, xmm4, 0x00
00007f0145bdbc1e  movaps xmm3, xmm5
00007f0145bdbc21  mulpd xmm3, xmm4
00007f0145bdbc25  vcmppd xmm2, xmm3, xmm3, 0x03
00007f0145bdbc2a  ptest xmm2, xmm2
00007f0145bdbc2f  jnz 0x00007F0145BDCFBA
00007f0145bdbc35  mov [rsp+0x80], rax
00007f0145bdbc3d  xor eax, eax
00007f0145bdbc3f  mov r12d, 0x40
00007f0145bdbc45  mov r11d, 0x200
00007f0145bdbc4b  cmp r12, r11
00007f0145bdbc4e  cmc
00007f0145bdbc4f  lahf
00007f0145bdbc50  seto al
00007f0145bdbc53  mov [r15+0x108], eax
00007f0145bdbc5a  movaps xmm5, xmm8
00007f0145bdbc5e  addpd xmm5, xmm15
00007f0145bdbc63  vcmppd xmm4, xmm5, xmm5, 0x03
00007f0145bdbc68  ptest xmm4, xmm4
00007f0145bdbc6d  jnz 0x00007F0145BDD0FA
00007f0145bdbc73  movaps xmm8, [r15+0x1B0]
00007f0145bdbc7b  movaps xmm4, xmm9
00007f0145bdbc7f  addpd xmm4, xmm8
00007f0145bdbc84  vcmppd xmm2, xmm4, xmm4, 0x03
00007f0145bdbc89  ptest xmm2, xmm2
00007f0145bdbc8e  jnz 0x00007F0145BDD23C
00007f0145bdbc94  movaps xmm9, xmm10
00007f0145bdbc98  addpd xmm9, xmm8
00007f0145bdbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
00007f0145bdbca3  ptest xmm2, xmm2
00007f0145bdbca8  jnz 0x00007F0145BDD37E
00007f0145bdbcae  movaps xmm10, [r15+0x2F0]
00007f0145bdbcb6  vmovaps [rsp+0x90], xmm10
00007f0145bdbcbf  vmovaps xmm8, [rsp+0x90]
00007f0145bdbcc8  por xmm10, xmm8
00007f0145bdbccd  movaps xmm8, [r15+0x2E0]
00007f0145bdbcd5  vmovaps [rsp+0x90], xmm8
00007f0145bdbcde  vmovaps xmm2, [rsp+0x90]
00007f0145bdbce7  por xmm8, xmm2
00007f0145bdbcec  movaps xmm2, [r15+0x2D0]
00007f0145bdbcf4  vmovaps [rsp+0x90], xmm2
00007f0145bdbcfd  vmovaps [rsp+0xA0], xmm1
00007f0145bdbd06  vmovaps xmm1, [rsp+0x90]
00007f0145bdbd0f  por xmm2, xmm1
00007f0145bdbd13  movaps xmm1, [r15+0x200]
00007f0145bdbd1b  vmovaps [rsp+0x90], xmm1
00007f0145bdbd24  vmovaps [rsp+0xB0], xmm15
00007f0145bdbd2d  vmovaps xmm15, [rsp+0x90]
00007f0145bdbd36  por xmm1, xmm15
00007f0145bdbd3b  movaps xmm15, [r15+0x1C0]
00007f0145bdbd43  vmovaps [rsp+0x90], xmm15
00007f0145bdbd4c  vmovaps [rsp+0xC0], xmm1
00007f0145bdbd55  vmovaps xmm1, [rsp+0x90]
00007f0145bdbd5e  por xmm15, xmm1
00007f0145bdbd63  movaps xmm1, [r15+0x190]
00007f0145bdbd6b  vmovaps [rsp+0x90], xmm1
00007f0145bdbd74  vmovaps [rsp+0xD0], xmm15
00007f0145bdbd7d  vmovaps xmm15, [rsp+0x90]
00007f0145bdbd86  por xmm1, xmm15
00007f0145bdbd8b  movaps xmm15, [r15+0x300]
00007f0145bdbd93  vmovaps [rsp+0x90], xmm15
00007f0145bdbd9c  vmovaps [rsp+0xE0], xmm1
00007f0145bdbda5  vmovaps xmm1, [rsp+0x90]
00007f0145bdbdae  por xmm15, xmm1
00007f0145bdbdb3  mov rax, [rsp+0x80]
00007f0145bdbdbb  lea r12, [rax+0xA0]
00007f0145bdbdc2  movups xmm1, [r13+r12*1]
00007f0145bdbdc8  lea r12, [rax+0xB0]
00007f0145bdbdcf  vmovaps [rsp+0x80], xmm1
00007f0145bdbdd8  movups xmm1, [r13+r12*1]
00007f0145bdbdde  vmovaps [rsp+0x90], xmm1
00007f0145bdbde7  vmovaps [rsp+0xF0], xmm15
00007f0145bdbdf0  vmovaps xmm15, [rsp+0xB0]
00007f0145bdbdf9  vmovaps [rsp+0xB0], xmm14
00007f0145bdbe02  movaps xmm1, xmm6
00007f0145bdbe05  addpd xmm1, xmm15
00007f0145bdbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
00007f0145bdbe0f  ptest xmm14, xmm14
00007f0145bdbe15  jnz 0x00007F0145BDD4D6
00007f0145bdbe1b  lea r12, [rax+0xF0]
00007f0145bdbe22  movups xmm15, [r13+r12*1]
00007f0145bdbe28  movaps xmm14, xmm4
00007f0145bdbe2c  addpd xmm14, xmm3
00007f0145bdbe31  vcmppd xmm6, xmm14, xmm14, 0x03
00007f0145bdbe37  ptest xmm6, xmm6
00007f0145bdbe3c  jnz 0x00007F0145BDD621
00007f0145bdbe42  movaps xmm6, xmm9
00007f0145bdbe46  addpd xmm6, xmm7
00007f0145bdbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
00007f0145bdbe4f  ptest xmm4, xmm4
00007f0145bdbe54  jnz 0x00007F0145BDD763
00007f0145bdbe5a  vmovaps xmm9, [rsp+0x70]
00007f0145bdbe60  vpermilpd xmm9, xmm9, 0x00
00007f0145bdbe66  vmovaps xmm4, [rsp+0x90]
00007f0145bdbe6f  movaps xmm7, xmm4
00007f0145bdbe72  mulpd xmm7, xmm9
00007f0145bdbe77  vcmppd xmm3, xmm7, xmm7, 0x03
00007f0145bdbe7c  ptest xmm3, xmm3
00007f0145bdbe81  jnz 0x00007F0145BDD8A4
00007f0145bdbe87  vmovaps xmm9, [rsp+0x50]
00007f0145bdbe8d  vpermilpd xmm9, xmm9, 0x00
00007f0145bdbe93  movaps xmm4, xmm15
00007f0145bdbe97  mulpd xmm4, xmm9
00007f0145bdbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
00007f0145bdbea1  ptest xmm3, xmm3
00007f0145bdbea6  jnz 0x00007F0145BDD9E5
00007f0145bdbeac  lea r12, [rax+0xE0]
00007f0145bdbeb3  movups xmm15, [r13+r12*1]
00007f0145bdbeb9  vmovaps xmm9, [rsp+0x70]
00007f0145bdbebf  vpermilpd xmm9, xmm9, 0x00
00007f0145bdbec5  vmovaps [rsp+0x70], xmm1
00007f0145bdbecb  vmovaps xmm1, [rsp+0x80]
00007f0145bdbed4  vmovaps [rsp+0x80], xmm15
00007f0145bdbedd  movaps xmm3, xmm1
00007f0145bdbee0  mulpd xmm3, xmm9
00007f0145bdbee5  vcmppd xmm15, xmm3, xmm3, 0x03
00007f0145bdbeea  ptest xmm15, xmm15
00007f0145bdbef0  jnz 0x00007F0145BDDB31
00007f0145bdbef6  vmovaps xmm1, [rsp+0xF0]
00007f0145bdbeff  vmovaps xmm15, [rsp+0xF0]
00007f0145bdbf08  por xmm1, xmm15
00007f0145bdbf0d  movaps [r15+0x300], xmm1
00007f0145bdbf15  vmovaps xmm15, [rsp+0xE0]
00007f0145bdbf1e  vmovaps xmm9, [rsp+0xE0]
00007f0145bdbf27  por xmm15, xmm9
00007f0145bdbf2c  movaps [r15+0x190], xmm15
00007f0145bdbf34  vmovaps xmm9, [rsp+0x50]
00007f0145bdbf3a  vpermilpd xmm9, xmm9, 0x00
00007f0145bdbf40  vmovaps [rsp+0x90], xmm1
00007f0145bdbf49  vmovaps [rsp+0xE0], xmm15
00007f0145bdbf52  vmovaps xmm15, [rsp+0x80]
00007f0145bdbf5b  vmovaps [rsp+0x80], xmm14
00007f0145bdbf64  movaps xmm1, xmm15
00007f0145bdbf68  mulpd xmm1, xmm9
00007f0145bdbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
00007f0145bdbf72  ptest xmm14, xmm14
00007f0145bdbf78  jnz 0x00007F0145BDDC72
00007f0145bdbf7e  lea r12, [rax+0x90]
00007f0145bdbf85  movups xmm15, [r13+r12*1]
00007f0145bdbf8b  vmovaps xmm14, [rsp+0xD0]
00007f0145bdbf94  vmovaps xmm9, [rsp+0xD0]
00007f0145bdbf9d  por xmm14, xmm9
00007f0145bdbfa2  movaps [r15+0x1C0], xmm14
00007f0145bdbfaa  vmovaps xmm9, [rsp+0xC0]
00007f0145bdbfb3  vmovaps [rsp+0xD0], xmm1
00007f0145bdbfbc  vmovaps xmm1, [rsp+0xC0]
00007f0145bdbfc5  por xmm9, xmm1
00007f0145bdbfca  movaps [r15+0x200], xmm9
00007f0145bdbfd2  vmovaps [rsp+0xC0], xmm2
00007f0145bdbfdb  vmovaps xmm1, [rsp+0xC0]
00007f0145bdbfe4  por xmm2, xmm1
00007f0145bdbfe8  movaps [r15+0x2D0], xmm2
00007f0145bdbff0  vmovaps [rsp+0xC0], xmm8
00007f0145bdbff9  vmovaps xmm1, [rsp+0xC0]
00007f0145bdc002  por xmm8, xmm1
00007f0145bdc007  movaps [r15+0x2E0], xmm8
00007f0145bdc00f  vmovaps [rsp+0xC0], xmm15
00007f0145bdc018  movaps xmm1, xmm5
00007f0145bdc01b  addpd xmm1, xmm7
00007f0145bdc01f  vcmppd xmm15, xmm1, xmm1, 0x03
00007f0145bdc024  ptest xmm15, xmm15
00007f0145bdc02a  jnz 0x00007F0145BDDDBE
00007f0145bdc030  vmovaps xmm15, [rsp+0x50]
00007f0145bdc036  vpermilpd xmm15, xmm15, 0x00
00007f0145bdc03c  vmovaps xmm5, [rsp+0xC0]
00007f0145bdc045  vmovaps [rsp+0xC0], xmm1
00007f0145bdc04e  movaps xmm7, xmm5
00007f0145bdc051  mulpd xmm7, xmm15
00007f0145bdc056  vcmppd xmm1, xmm7, xmm7, 0x03
00007f0145bdc05b  ptest xmm1, xmm1
00007f0145bdc060  jnz 0x00007F0145BDDEFE
00007f0145bdc066  lea r12, [rax+0x80]
00007f0145bdc06d  movups xmm1, [r13+r12*1]
00007f0145bdc073  vmovaps xmm5, [rsp+0x70]
00007f0145bdc079  vmovaps [rsp+0x70], xmm1
00007f0145bdc07f  movaps xmm15, xmm5
00007f0145bdc083  addpd xmm15, xmm3
00007f0145bdc088  vcmppd xmm1, xmm15, xmm15, 0x03
00007f0145bdc08e  ptest xmm1, xmm1
00007f0145bdc093  jnz 0x00007F0145BDE049
00007f0145bdc099  vmovaps xmm5, [rsp+0x80]
00007f0145bdc0a2  movaps xmm1, xmm5
00007f0145bdc0a5  addpd xmm1, xmm4
00007f0145bdc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
00007f0145bdc0ae  ptest xmm3, xmm3
00007f0145bdc0b3  jnz 0x00007F0145BDE18B
00007f0145bdc0b9  vmovaps [rsp+0x80], xmm10
00007f0145bdc0c2  vmovaps xmm5, [rsp+0x80]
00007f0145bdc0cb  por xmm10, xmm5
00007f0145bdc0d0  movaps [r15+0x2F0], xmm10
00007f0145bdc0d8  vmovaps xmm5, [rsp+0x50]
00007f0145bdc0de  vpermilpd xmm5, xmm5, 0x00
00007f0145bdc0e4  vmovaps xmm3, [rsp+0x70]
00007f0145bdc0ea  vmovaps [rsp+0x50], xmm1
00007f0145bdc0f0  movaps xmm4, xmm3
00007f0145bdc0f3  mulpd xmm4, xmm5
00007f0145bdc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
00007f0145bdc0fc  ptest xmm1, xmm1
00007f0145bdc101  jnz 0x00007F0145BDE2CB
00007f0145bdc107  lea r12, [rax+0xD0]
00007f0145bdc10e  movups xmm1, [r13+r12*1]
00007f0145bdc114  vmovaps xmm3, [rsp+0xD0]
00007f0145bdc11d  vmovaps [rsp+0x70], xmm1
00007f0145bdc123  movaps xmm5, xmm6
00007f0145bdc126  addpd xmm5, xmm3
00007f0145bdc12a  vcmppd xmm1, xmm5, xmm5, 0x03
00007f0145bdc12f  ptest xmm1, xmm1
00007f0145bdc134  jnz 0x00007F0145BDE415
00007f0145bdc13a  vmovaps xmm1, [rsp+0x60]
00007f0145bdc140  vpermilpd xmm1, xmm1, 0x00
00007f0145bdc146  movaps xmm6, xmm9
00007f0145bdc14a  mulpd xmm6, xmm1
00007f0145bdc14e  vcmppd xmm3, xmm6, xmm6, 0x03
00007f0145bdc153  ptest xmm3, xmm3
00007f0145bdc158  jnz 0x00007F0145BDE555
00007f0145bdc15e  movaps [r15+0x260], xmm6
00007f0145bdc166  vxorps xmm1, xmm1, xmm1
00007f0145bdc16a  vpbroadcastq xmm1, xmm1
00007f0145bdc16f  movaps [r15+0x1B0], xmm1
00007f0145bdc177  vmovaps xmm1, [rsp+0x60]
00007f0145bdc17d  vpermilpd xmm1, xmm1, 0x00
00007f0145bdc183  vmovaps xmm3, [rsp+0x70]
00007f0145bdc189  vmovaps [rsp+0x70], xmm15
00007f0145bdc18f  movaps xmm9, xmm3
00007f0145bdc193  mulpd xmm9, xmm1
00007f0145bdc198  vcmppd xmm15, xmm9, xmm9, 0x03
00007f0145bdc19e  ptest xmm15, xmm15
00007f0145bdc1a4  jnz 0x00007F0145BDE696
00007f0145bdc1aa  lea r12, [rax+0xC0]
00007f0145bdc1b1  movups xmm1, [r13+r12*1]
00007f0145bdc1b7  vmovaps xmm3, [rsp+0xC0]
00007f0145bdc1c0  vmovaps [rsp+0x80], xmm1
00007f0145bdc1c9  movaps xmm15, xmm3
00007f0145bdc1cd  addpd xmm15, xmm7
00007f0145bdc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
00007f0145bdc1d8  ptest xmm1, xmm1
00007f0145bdc1dd  jnz 0x00007F0145BDE7E2
00007f0145bdc1e3  vmovaps [rsp+0xC0], xmm13
00007f0145bdc1ec  vmovaps xmm1, [rsp+0xC0]
00007f0145bdc1f5  por xmm13, xmm1
00007f0145bdc1fa  movaps [r15+0x270], xmm13
00007f0145bdc202  vmovaps xmm1, [rsp+0xB0]
00007f0145bdc20b  vmovaps xmm7, [rsp+0xB0]
00007f0145bdc214  por xmm1, xmm7
00007f0145bdc218  movaps [r15+0x1A0], xmm1
00007f0145bdc220  vmovaps xmm1, [rsp+0x60]
00007f0145bdc226  vpermilpd xmm1, xmm1, 0x00
00007f0145bdc22c  vmovaps [rsp+0xB0], xmm1
00007f0145bdc235  vmovaps xmm1, [rsp+0x80]
00007f0145bdc23e  vmovaps [rsp+0x80], xmm15
00007f0145bdc247  vmovaps xmm15, [rsp+0xB0]
00007f0145bdc250  vmovaps [rsp+0xB0], xmm14
00007f0145bdc259  movaps xmm3, xmm1
00007f0145bdc25c  mulpd xmm3, xmm15
00007f0145bdc261  vcmppd xmm14, xmm3, xmm3, 0x03
00007f0145bdc266  ptest xmm14, xmm14
00007f0145bdc26c  jnz 0x00007F0145BDE924
00007f0145bdc272  lea r12, [rax+0x20]
00007f0145bdc276  movups xmm1, [r13+r12*1]
00007f0145bdc27c  movaps [r15+0x110], xmm1
00007f0145bdc284  vmovaps xmm14, [rsp+0x70]
00007f0145bdc28a  vmovaps [rsp+0x70], xmm1
00007f0145bdc290  movaps xmm15, xmm14
00007f0145bdc294  addpd xmm15, xmm4
00007f0145bdc299  vcmppd xmm1, xmm15, xmm15, 0x03
00007f0145bdc29f  ptest xmm1, xmm1
00007f0145bdc2a4  jnz 0x00007F0145BDEA6F
00007f0145bdc2aa  vmovaps xmm1, [rsp+0x60]
00007f0145bdc2b0  vpermilpd xmm1, xmm1, 0x00
00007f0145bdc2b6  movaps xmm14, xmm2
00007f0145bdc2ba  mulpd xmm14, xmm1
00007f0145bdc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
00007f0145bdc2c5  ptest xmm4, xmm4
00007f0145bdc2ca  jnz 0x00007F0145BDEBB2
00007f0145bdc2d0  vmovaps xmm4, [rsp+0x50]
00007f0145bdc2d6  movaps xmm1, xmm4
00007f0145bdc2d9  addpd xmm1, xmm9
00007f0145bdc2de  vcmppd xmm2, xmm1, xmm1, 0x03
00007f0145bdc2e3  ptest xmm2, xmm2
00007f0145bdc2e8  jnz 0x00007F0145BDECF4
00007f0145bdc2ee  vmovaps xmm9, [rsp+0x30]
00007f0145bdc2f4  vpermilpd xmm9, xmm9, 0x00
00007f0145bdc2fa  vmovaps xmm2, [rsp+0x70]
00007f0145bdc300  vmovaps [rsp+0x50], xmm1
00007f0145bdc306  movaps xmm4, xmm2
00007f0145bdc309  mulpd xmm4, xmm9
00007f0145bdc30e  vcmppd xmm1, xmm4, xmm4, 0x03
00007f0145bdc313  ptest xmm1, xmm1
00007f0145bdc318  jnz 0x00007F0145BDEE35
00007f0145bdc31e  vmovaps xmm1, [rsp+0x30]
00007f0145bdc324  vpermilpd xmm1, xmm1, 0x00
00007f0145bdc32a  vmovaps xmm2, [rsp+0x90]
00007f0145bdc333  vmovaps [rsp+0x60], xmm15
00007f0145bdc339  movaps xmm9, xmm2
00007f0145bdc33d  mulpd xmm9, xmm1
00007f0145bdc342  vcmppd xmm15, xmm9, xmm9, 0x03
00007f0145bdc348  ptest xmm15, xmm15
00007f0145bdc34e  jnz 0x00007F0145BDEF76
00007f0145bdc354  vmovaps xmm15, [rsp+0x80]
00007f0145bdc35d  movaps xmm1, xmm15
00007f0145bdc361  addpd xmm1, xmm6
00007f0145bdc365  vcmppd xmm2, xmm1, xmm1, 0x03
00007f0145bdc36a  ptest xmm2, xmm2
00007f0145bdc36f  jnz 0x00007F0145BDF0B8
00007f0145bdc375  movaps xmm15, xmm5
00007f0145bdc379  addpd xmm15, xmm3
00007f0145bdc37e  vcmppd xmm6, xmm15, xmm15, 0x03
00007f0145bdc384  ptest xmm6, xmm6
00007f0145bdc389  jnz 0x00007F0145BDF1F9
00007f0145bdc38f  vmovaps xmm6, [rsp+0x30]
00007f0145bdc395  vpermilpd xmm6, xmm6, 0x00
00007f0145bdc39b  movaps xmm5, xmm8
00007f0145bdc39f  mulpd xmm5, xmm6
00007f0145bdc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
00007f0145bdc3a8  ptest xmm3, xmm3
00007f0145bdc3ad  jnz 0x00007F0145BDF33B
00007f0145bdc3b3  vmovaps xmm8, [rsp+0x30]
00007f0145bdc3b9  vpermilpd xmm8, xmm8, 0x00
00007f0145bdc3bf  movaps xmm6, xmm10
00007f0145bdc3c3  mulpd xmm6, xmm8
00007f0145bdc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
00007f0145bdc3cd  ptest xmm3, xmm3
00007f0145bdc3d2  jnz 0x00007F0145BDF47C
00007f0145bdc3d8  vmovaps xmm8, [rsp+0x60]
00007f0145bdc3de  movaps xmm10, xmm8
00007f0145bdc3e2  addpd xmm10, xmm14
00007f0145bdc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
00007f0145bdc3ed  ptest xmm3, xmm3
00007f0145bdc3f2  jnz 0x00007F0145BDF5BE
00007f0145bdc3f8  vmovaps xmm8, [rsp+0x50]
00007f0145bdc3fe  movaps xmm14, xmm8
00007f0145bdc402  addpd xmm14, xmm4
00007f0145bdc407  vcmppd xmm3, xmm14, xmm14, 0x03
00007f0145bdc40d  ptest xmm3, xmm3
00007f0145bdc412  jnz 0x00007F0145BDF702
00007f0145bdc418  vmovaps xmm8, [rsp+0x40]
00007f0145bdc41e  vpermilpd xmm8, xmm8, 0x00
00007f0145bdc424  movaps xmm4, xmm13
00007f0145bdc428  mulpd xmm4, xmm8
00007f0145bdc42d  vcmppd xmm3, xmm4, xmm4, 0x03
00007f0145bdc432  ptest xmm3, xmm3
00007f0145bdc437  jnz 0x00007F0145BDF845
00007f0145bdc43d  movaps xmm13, xmm15
00007f0145bdc441  addpd xmm13, xmm9
00007f0145bdc446  vcmppd xmm8, xmm13, xmm13, 0x03
00007f0145bdc44c  ptest xmm8, xmm8
00007f0145bdc452  jnz 0x00007F0145BDF987
00007f0145bdc458  movaps xmm15, xmm1
00007f0145bdc45c  addpd xmm15, xmm5
00007f0145bdc461  vcmppd xmm9, xmm15, xmm15, 0x03
00007f0145bdc467  ptest xmm9, xmm9
00007f0145bdc46d  jnz 0x00007F0145BDFACB
00007f0145bdc473  vmovaps [rsp+0x30], xmm11
00007f0145bdc479  vmovaps xmm1, [rsp+0x30]
00007f0145bdc47f  por xmm11, xmm1
00007f0145bdc484  movaps [r15+0x250], xmm11
00007f0145bdc48c  vmovaps [rsp+0x30], xmm12
00007f0145bdc492  vmovaps xmm1, [rsp+0x30]
00007f0145bdc498  por xmm12, xmm1
00007f0145bdc49d  movaps [r15+0x2A0], xmm12
00007f0145bdc4a5  vmovaps xmm1, [rsp+0xA0]
00007f0145bdc4ae  vmovaps xmm11, [rsp+0xA0]
00007f0145bdc4b7  por xmm1, xmm11
00007f0145bdc4bc  movaps [r15+0x1D0], xmm1
00007f0145bdc4c4  lea r12, [rax+0x40]
00007f0145bdc4c8  movups xmm1, [r13+r12*1]
00007f0145bdc4ce  movaps [r15+0x2C0], xmm1
00007f0145bdc4d6  vmovaps xmm11, [rsp+0x40]
00007f0145bdc4dc  vpermilpd xmm11, xmm11, 0x00
00007f0145bdc4e2  vmovaps xmm8, [rsp+0xE0]
00007f0145bdc4eb  movaps xmm9, xmm8
00007f0145bdc4ef  mulpd xmm9, xmm11
00007f0145bdc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
00007f0145bdc4fa  ptest xmm5, xmm5
00007f0145bdc4ff  jnz 0x00007F0145BDFC17
00007f0145bdc505  movaps xmm11, xmm10
00007f0145bdc509  addpd xmm11, xmm6
00007f0145bdc50e  vcmppd xmm8, xmm11, xmm11, 0x03
00007f0145bdc514  ptest xmm8, xmm8
00007f0145bdc51a  jnz 0x00007F0145BDFD5B
00007f0145bdc520  movaps xmm10, xmm14
00007f0145bdc524  addpd xmm10, xmm4
00007f0145bdc529  vcmppd xmm8, xmm10, xmm10, 0x03
00007f0145bdc52f  ptest xmm8, xmm8
00007f0145bdc535  jnz 0x00007F0145BDFE9E
00007f0145bdc53b  vmovaps xmm14, [rsp+0x40]
00007f0145bdc541  vpermilpd xmm14, xmm14, 0x00
00007f0145bdc547  movaps xmm8, xmm1
00007f0145bdc54b  mulpd xmm8, xmm14
00007f0145bdc550  vcmppd xmm6, xmm8, xmm8, 0x03
00007f0145bdc556  ptest xmm6, xmm6
00007f0145bdc55b  jnz 0x00007F0145BDFFE1
00007f0145bdc561  movaps xmm1, [r15+0x2B0]
00007f0145bdc569  vmovaps xmm14, [rsp+0x40]
00007f0145bdc56f  vpermilpd xmm14, xmm14, 0x00
00007f0145bdc575  movaps xmm6, xmm1
00007f0145bdc578  mulpd xmm6, xmm14
00007f0145bdc57d  vcmppd xmm5, xmm6, xmm6, 0x03
00007f0145bdc582  ptest xmm5, xmm5
00007f0145bdc587  jnz 0x00007F0145BE0124
00007f0145bdc58d  vmovaps xmm1, [rsp+0x10]
00007f0145bdc593  vpermilpd xmm1, xmm1, 0x00
00007f0145bdc599  movaps xmm14, xmm12
00007f0145bdc59d  mulpd xmm14, xmm1
00007f0145bdc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
00007f0145bdc5a8  ptest xmm5, xmm5
00007f0145bdc5ad  jnz 0x00007F0145BE0265
00007f0145bdc5b3  movaps xmm1, xmm13
00007f0145bdc5b7  addpd xmm1, xmm9
00007f0145bdc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
00007f0145bdc5c1  ptest xmm12, xmm12
00007f0145bdc5c7  jnz 0x00007F0145BE03A8
00007f0145bdc5cd  vmovaps xmm13, [rsp+0x10]
00007f0145bdc5d3  vpermilpd xmm13, xmm13, 0x00
00007f0145bdc5d9  movaps xmm12, xmm7
00007f0145bdc5dd  mulpd xmm12, xmm13
00007f0145bdc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
00007f0145bdc5e8  ptest xmm9, xmm9
00007f0145bdc5ee  jnz 0x00007F0145BE04EA
00007f0145bdc5f4  movaps xmm13, xmm15
00007f0145bdc5f8  addpd xmm13, xmm8
00007f0145bdc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
00007f0145bdc603  ptest xmm9, xmm9
00007f0145bdc609  jnz 0x00007F0145BE062D
00007f0145bdc60f  movaps xmm15, [r15+0x290]
00007f0145bdc617  vmovaps xmm9, [rsp+0x10]
00007f0145bdc61d  vpermilpd xmm9, xmm9, 0x00
00007f0145bdc623  movaps xmm8, xmm15
00007f0145bdc627  mulpd xmm8, xmm9
00007f0145bdc62c  vcmppd xmm7, xmm8, xmm8, 0x03
00007f0145bdc632  ptest xmm7, xmm7
00007f0145bdc637  jnz 0x00007F0145BE0771
00007f0145bdc63d  movaps xmm15, xmm11
00007f0145bdc641  addpd xmm15, xmm6
00007f0145bdc646  vcmppd xmm9, xmm15, xmm15, 0x03
00007f0145bdc64c  ptest xmm9, xmm9
00007f0145bdc652  jnz 0x00007F0145BE08B5
00007f0145bdc658  movaps xmm11, [r15+0x1E0]
00007f0145bdc660  vmovaps xmm9, [rsp+0x10]
00007f0145bdc666  vpermilpd xmm9, xmm9, 0x00
00007f0145bdc66c  movaps xmm7, xmm11
00007f0145bdc670  mulpd xmm7, xmm9
00007f0145bdc675  vcmppd xmm6, xmm7, xmm7, 0x03
00007f0145bdc67a  ptest xmm6, xmm6
00007f0145bdc67f  jnz 0x00007F0145BE09F8
00007f0145bdc685  movaps xmm11, xmm10
00007f0145bdc689  addpd xmm11, xmm14
00007f0145bdc68e  vcmppd xmm9, xmm11, xmm11, 0x03
00007f0145bdc694  ptest xmm9, xmm9
00007f0145bdc69a  jnz 0x00007F0145BE0B3A
00007f0145bdc6a0  lea r12, [rax+0x70]
00007f0145bdc6a4  movups xmm14, [r13+r12*1]
00007f0145bdc6aa  movaps [r15+0x240], xmm14
00007f0145bdc6b2  movaps xmm10, xmm1
00007f0145bdc6b6  addpd xmm10, xmm12
00007f0145bdc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
00007f0145bdc6c1  ptest xmm9, xmm9
00007f0145bdc6c7  jnz 0x00007F0145BE0C88
00007f0145bdc6cd  movaps [r15+0x170], xmm10
00007f0145bdc6d5  vmovaps xmm1, [rsp+0x20]
00007f0145bdc6db  vpermilpd xmm1, xmm1, 0x00
00007f0145bdc6e1  movaps xmm12, xmm14
00007f0145bdc6e5  mulpd xmm12, xmm1
00007f0145bdc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
00007f0145bdc6f0  ptest xmm9, xmm9
00007f0145bdc6f6  jnz 0x00007F0145BE0DCB
00007f0145bdc6fc  vmovaps xmm1, [rsp+0x20]
00007f0145bdc702  vpermilpd xmm1, xmm1, 0x00
00007f0145bdc708  vmovaps xmm9, [rsp+0xB0]
00007f0145bdc711  movaps xmm14, xmm9
00007f0145bdc715  mulpd xmm14, xmm1
00007f0145bdc71a  vcmppd xmm6, xmm14, xmm14, 0x03
00007f0145bdc720  ptest xmm6, xmm6
00007f0145bdc725  jnz 0x00007F0145BE0F0E
00007f0145bdc72b  movaps [r15+0x180], xmm14
00007f0145bdc733  movaps xmm1, xmm13
00007f0145bdc737  addpd xmm1, xmm8
00007f0145bdc73c  vcmppd xmm9, xmm1, xmm1, 0x03
00007f0145bdc741  ptest xmm9, xmm9
00007f0145bdc747  jnz 0x00007F0145BE1051
00007f0145bdc74d  movaps [r15+0x210], xmm1
00007f0145bdc755  movups xmm13, [r13+rax*1]
00007f0145bdc75b  lea r12, [rax+0x10]
00007f0145bdc75f  movups xmm9, [r13+r12*1]
00007f0145bdc765  movaps [r15+0x230], xmm9
00007f0145bdc76d  movaps xmm8, xmm15
00007f0145bdc771  addpd xmm8, xmm7
00007f0145bdc776  vcmppd xmm6, xmm8, xmm8, 0x03
00007f0145bdc77c  ptest xmm6, xmm6
00007f0145bdc781  jnz 0x00007F0145BE11A7
00007f0145bdc787  movaps [r15+0x130], xmm8
00007f0145bdc78f  vmovaps xmm15, [rsp+0x20]
00007f0145bdc795  vpermilpd xmm15, xmm15, 0x00
00007f0145bdc79b  movaps xmm7, xmm9
00007f0145bdc79f  mulpd xmm7, xmm15
00007f0145bdc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
00007f0145bdc7a9  ptest xmm6, xmm6
00007f0145bdc7ae  jnz 0x00007F0145BE12EA
00007f0145bdc7b4  movaps [r15+0x220], xmm7
00007f0145bdc7bc  vmovaps xmm15, [rsp+0x20]
00007f0145bdc7c2  vpermilpd xmm15, xmm15, 0x00
00007f0145bdc7c8  movaps xmm9, xmm13
00007f0145bdc7cc  mulpd xmm9, xmm15
00007f0145bdc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
00007f0145bdc7d7  ptest xmm6, xmm6
00007f0145bdc7dc  jnz 0x00007F0145BE142C
00007f0145bdc7e2  movaps xmm15, xmm11
00007f0145bdc7e6  addpd xmm15, xmm12
00007f0145bdc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
00007f0145bdc7f1  ptest xmm13, xmm13
00007f0145bdc7f7  jnz 0x00007F0145BE1570
00007f0145bdc7fd  movaps [r15+0x140], xmm15
00007f0145bdc805  movaps xmm13, xmm10
00007f0145bdc809  addpd xmm13, xmm14
00007f0145bdc80e  vcmppd xmm12, xmm13, xmm13, 0x03
00007f0145bdc814  ptest xmm12, xmm12
00007f0145bdc81a  jnz 0x00007F0145BE16B4
00007f0145bdc820  movaps [r15+0x150], xmm13
00007f0145bdc828  movaps xmm14, xmm1
00007f0145bdc82c  addpd xmm14, xmm7
00007f0145bdc831  vcmppd xmm12, xmm14, xmm14, 0x03
00007f0145bdc837  ptest xmm12, xmm12
00007f0145bdc83d  jnz 0x00007F0145BE17F8
00007f0145bdc843  movaps [r15+0x160], xmm14
00007f0145bdc84b  movaps xmm1, xmm8
00007f0145bdc84f  addpd xmm1, xmm9
00007f0145bdc854  vcmppd xmm12, xmm1, xmm1, 0x03
00007f0145bdc859  ptest xmm12, xmm12
00007f0145bdc85f  jnz 0x00007F0145BE193A
00007f0145bdc865  movaps [r15+0x120], xmm1
00007f0145bdc86d  movups [r13+r14*1], xmm15
00007f0145bdc873  lea rax, [r14+0x10]
00007f0145bdc877  movups [r13+rax*1], xmm13
00007f0145bdc87d  lea rax, [r14+0x20]
00007f0145bdc881  movups [r13+rax*1], xmm14
00007f0145bdc887  lea rax, [r14+0x30]
00007f0145bdc88b  movups [r13+rax*1], xmm1
00007f0145bdc891  mov eax, [r15+0x108]
00007f0145bdc898  sahf
00007f0145bdc899  jnz 0x00007F0145BDC8CB
00007f0145bdc89b  cmp dword ptr [r15+0x318], 0x00
00007f0145bdc8a3  jz 0x00007F0145BDB900
00007f0145bdc8a9  nop [rax+rax*1], ax
00007f0145bdc8b2  nop [rax+rax*1], eax
00007f0145bdc8ba  mov eax, 0x410444
00007f0145bdc8bf  mov [r15+0x100], rax
00007f0145bdc8c6  jmp 0x00007F01459FE110
00007f0145bdc8cb  cmp dword ptr [r15+0x318], 0x00
00007f0145bdc8d3  jz 0x00007F0145BD57E0
00007f0145bdc8d9  nop [rax+rax*1], ax
00007f0145bdc8e2  nop [rax+rax*1], eax
00007f0145bdc8ea  mov eax, 0x410278
00007f0145bdc8ef  mov [r15+0x100], rax
00007f0145bdc8f6  jmp 0x00007F01459FE110
00007f0145bdc8fb  int3
00007f0145bdc8fc  call 0x00007F0145AE27E0
00007f0145bdc901  jmp 0x00007F0145BDB9DF
00007f0145bdc906  call 0x00007F0145AE1570
00007f0145bdc90b  jmp 0x00007F0145BDB9E8
00007f0145bdc910  call 0x00007F0145AE27E0
00007f0145bdc915  jmp 0x00007F0145BDBA44
00007f0145bdc91a  call 0x00007F0145AE1570
00007f0145bdc91f  jmp 0x00007F0145BDBA4D
00007f0145bdc924  call 0x00007F0145AE27E0
00007f0145bdc929  jmp 0x00007F0145BDBA90
00007f0145bdc92e  call 0x00007F0145AE1570
00007f0145bdc933  jmp 0x00007F0145BDBA99
00007f0145bdc938  call 0x00007F0145A0DC20
00007f0145bdc93d  jmp 0x00007F0145BDBAD8
00007f0145bdc942  call 0x00007F0145AD59C0
00007f0145bdc947  jmp 0x00007F0145BDBAEB
00007f0145bdc94c  call 0x00007F0145AE0E30
00007f0145bdc951  jmp 0x00007F0145BDBB09
00007f0145bdc956  call 0x00007F0145ADFBC0
00007f0145bdc95b  jmp 0x00007F0145BDBB13
00007f0145bdc960  call 0x00007F0145ADE950
00007f0145bdc965  jmp 0x00007F0145BDBB1D
00007f0145bdc96a  sub rsp, 0x08
00007f0145bdc96e  push rax
00007f0145bdc96f  push rcx
00007f0145bdc970  push rdx
00007f0145bdc971  push rdi
00007f0145bdc972  push rsi
00007f0145bdc973  push r8
00007f0145bdc975  push r9
00007f0145bdc977  push r10
00007f0145bdc979  push r11
00007f0145bdc97b  sub rsp, 0xF0
00007f0145bdc982  vmovaps [rsp], xmm0
00007f0145bdc987  vmovaps [rsp+0x10], xmm1
00007f0145bdc98d  vmovaps [rsp+0x20], xmm2
00007f0145bdc993  vmovaps [rsp+0x30], xmm3
00007f0145bdc999  vmovaps [rsp+0x40], xmm4
00007f0145bdc99f  vmovaps [rsp+0x50], xmm5
00007f0145bdc9a5  vmovaps [rsp+0x60], xmm6
00007f0145bdc9ab  vmovaps [rsp+0x70], xmm7
00007f0145bdc9b1  vmovaps [rsp+0x80], xmm9
00007f0145bdc9ba  vmovaps [rsp+0x90], xmm10
00007f0145bdc9c3  vmovaps [rsp+0xA0], xmm11
00007f0145bdc9cc  vmovaps [rsp+0xB0], xmm12
00007f0145bdc9d5  vmovaps [rsp+0xC0], xmm13
00007f0145bdc9de  vmovaps [rsp+0xD0], xmm14
00007f0145bdc9e7  vmovaps [rsp+0xE0], xmm15
00007f0145bdc9f0  sub rsp, 0x30
00007f0145bdc9f4  movaps [rsp], xmm8
00007f0145bdc9f9  movaps [rsp+0x10], xmm12
00007f0145bdc9ff  movaps [rsp+0x20], xmm15
00007f0145bdca05  lea rdi, [rsp]
00007f0145bdca09  mov esi, 0x00
00007f0145bdca0e  mov rax, 0x636570E98530
00007f0145bdca18  call rax
00007f0145bdca1a  movaps xmm8, [rsp]
00007f0145bdca1f  add rsp, 0x30
00007f0145bdca23  vmovaps xmm0, [rsp]
00007f0145bdca28  vmovaps xmm1, [rsp+0x10]
00007f0145bdca2e  vmovaps xmm2, [rsp+0x20]
00007f0145bdca34  vmovaps xmm3, [rsp+0x30]
00007f0145bdca3a  vmovaps xmm4, [rsp+0x40]
00007f0145bdca40  vmovaps xmm5, [rsp+0x50]
00007f0145bdca46  vmovaps xmm6, [rsp+0x60]
00007f0145bdca4c  vmovaps xmm7, [rsp+0x70]
00007f0145bdca52  vmovaps xmm9, [rsp+0x80]
00007f0145bdca5b  vmovaps xmm10, [rsp+0x90]
00007f0145bdca64  vmovaps xmm11, [rsp+0xA0]
00007f0145bdca6d  vmovaps xmm12, [rsp+0xB0]
00007f0145bdca76  vmovaps xmm13, [rsp+0xC0]
00007f0145bdca7f  vmovaps xmm14, [rsp+0xD0]
00007f0145bdca88  vmovaps xmm15, [rsp+0xE0]
00007f0145bdca91  add rsp, 0xF0
00007f0145bdca98  pop r11
00007f0145bdca9a  pop r10
00007f0145bdca9c  pop r9
00007f0145bdca9e  pop r8
00007f0145bdcaa0  pop rsi
00007f0145bdcaa1  pop rdi
00007f0145bdcaa2  pop rdx
00007f0145bdcaa3  pop rcx
00007f0145bdcaa4  pop rax
00007f0145bdcaa5  add rsp, 0x08
00007f0145bdcaa9  jmp 0x00007F0145BDBB47
00007f0145bdcaae  sub rsp, 0x08
00007f0145bdcab2  push rax
00007f0145bdcab3  push rcx
00007f0145bdcab4  push rdx
00007f0145bdcab5  push rdi
00007f0145bdcab6  push rsi
00007f0145bdcab7  push r8
00007f0145bdcab9  push r9
00007f0145bdcabb  push r10
00007f0145bdcabd  push r11
00007f0145bdcabf  sub rsp, 0xF0
00007f0145bdcac6  vmovaps [rsp], xmm0
00007f0145bdcacb  vmovaps [rsp+0x10], xmm1
00007f0145bdcad1  vmovaps [rsp+0x20], xmm2
00007f0145bdcad7  vmovaps [rsp+0x30], xmm3
00007f0145bdcadd  vmovaps [rsp+0x40], xmm4
00007f0145bdcae3  vmovaps [rsp+0x50], xmm5
00007f0145bdcae9  vmovaps [rsp+0x60], xmm6
00007f0145bdcaef  vmovaps [rsp+0x70], xmm8
00007f0145bdcaf5  vmovaps [rsp+0x80], xmm9
00007f0145bdcafe  vmovaps [rsp+0x90], xmm10
00007f0145bdcb07  vmovaps [rsp+0xA0], xmm11
00007f0145bdcb10  vmovaps [rsp+0xB0], xmm12
00007f0145bdcb19  vmovaps [rsp+0xC0], xmm13
00007f0145bdcb22  vmovaps [rsp+0xD0], xmm14
00007f0145bdcb2b  vmovaps [rsp+0xE0], xmm15
00007f0145bdcb34  sub rsp, 0x30
00007f0145bdcb38  movaps [rsp], xmm7
00007f0145bdcb3c  movaps [rsp+0x10], xmm9
00007f0145bdcb42  movaps [rsp+0x20], xmm15
00007f0145bdcb48  lea rdi, [rsp]
00007f0145bdcb4c  mov esi, 0x00
00007f0145bdcb51  mov rax, 0x636570E98530
00007f0145bdcb5b  call rax
00007f0145bdcb5d  movaps xmm7, [rsp]
00007f0145bdcb61  add rsp, 0x30
00007f0145bdcb65  vmovaps xmm0, [rsp]
00007f0145bdcb6a  vmovaps xmm1, [rsp+0x10]
00007f0145bdcb70  vmovaps xmm2, [rsp+0x20]
00007f0145bdcb76  vmovaps xmm3, [rsp+0x30]
00007f0145bdcb7c  vmovaps xmm4, [rsp+0x40]
00007f0145bdcb82  vmovaps xmm5, [rsp+0x50]
00007f0145bdcb88  vmovaps xmm6, [rsp+0x60]
00007f0145bdcb8e  vmovaps xmm8, [rsp+0x70]
00007f0145bdcb94  vmovaps xmm9, [rsp+0x80]
00007f0145bdcb9d  vmovaps xmm10, [rsp+0x90]
00007f0145bdcba6  vmovaps xmm11, [rsp+0xA0]
00007f0145bdcbaf  vmovaps xmm12, [rsp+0xB0]
00007f0145bdcbb8  vmovaps xmm13, [rsp+0xC0]
00007f0145bdcbc1  vmovaps xmm14, [rsp+0xD0]
00007f0145bdcbca  vmovaps xmm15, [rsp+0xE0]
00007f0145bdcbd3  add rsp, 0xF0
00007f0145bdcbda  pop r11
00007f0145bdcbdc  pop r10
00007f0145bdcbde  pop r9
00007f0145bdcbe0  pop r8
00007f0145bdcbe2  pop rsi
00007f0145bdcbe3  pop rdi
00007f0145bdcbe4  pop rdx
00007f0145bdcbe5  pop rcx
00007f0145bdcbe6  pop rax
00007f0145bdcbe7  add rsp, 0x08
00007f0145bdcbeb  jmp 0x00007F0145BDBB75
00007f0145bdcbf0  sub rsp, 0x08
00007f0145bdcbf4  push rax
00007f0145bdcbf5  push rcx
00007f0145bdcbf6  push rdx
00007f0145bdcbf7  push rdi
00007f0145bdcbf8  push rsi
00007f0145bdcbf9  push r8
00007f0145bdcbfb  push r9
00007f0145bdcbfd  push r10
00007f0145bdcbff  push r11
00007f0145bdcc01  sub rsp, 0xF0
00007f0145bdcc08  vmovaps [rsp], xmm0
00007f0145bdcc0d  vmovaps [rsp+0x10], xmm1
00007f0145bdcc13  vmovaps [rsp+0x20], xmm2
00007f0145bdcc19  vmovaps [rsp+0x30], xmm3
00007f0145bdcc1f  vmovaps [rsp+0x40], xmm4
00007f0145bdcc25  vmovaps [rsp+0x50], xmm5
00007f0145bdcc2b  vmovaps [rsp+0x60], xmm6
00007f0145bdcc31  vmovaps [rsp+0x70], xmm7
00007f0145bdcc37  vmovaps [rsp+0x80], xmm8
00007f0145bdcc40  vmovaps [rsp+0x90], xmm10
00007f0145bdcc49  vmovaps [rsp+0xA0], xmm11
00007f0145bdcc52  vmovaps [rsp+0xB0], xmm12
00007f0145bdcc5b  vmovaps [rsp+0xC0], xmm13
00007f0145bdcc64  vmovaps [rsp+0xD0], xmm14
00007f0145bdcc6d  vmovaps [rsp+0xE0], xmm15
00007f0145bdcc76  sub rsp, 0x30
00007f0145bdcc7a  movaps [rsp], xmm9
00007f0145bdcc7f  movaps [rsp+0x10], xmm12
00007f0145bdcc85  movaps [rsp+0x20], xmm10
00007f0145bdcc8b  lea rdi, [rsp]
00007f0145bdcc8f  mov esi, 0x00
00007f0145bdcc94  mov rax, 0x636570E98530
00007f0145bdcc9e  call rax
00007f0145bdcca0  movaps xmm9, [rsp]
00007f0145bdcca5  add rsp, 0x30
00007f0145bdcca9  vmovaps xmm0, [rsp]
00007f0145bdccae  vmovaps xmm1, [rsp+0x10]
00007f0145bdccb4  vmovaps xmm2, [rsp+0x20]
00007f0145bdccba  vmovaps xmm3, [rsp+0x30]
00007f0145bdccc0  vmovaps xmm4, [rsp+0x40]
00007f0145bdccc6  vmovaps xmm5, [rsp+0x50]
00007f0145bdcccc  vmovaps xmm6, [rsp+0x60]
00007f0145bdccd2  vmovaps xmm7, [rsp+0x70]
00007f0145bdccd8  vmovaps xmm8, [rsp+0x80]
00007f0145bdcce1  vmovaps xmm10, [rsp+0x90]
00007f0145bdccea  vmovaps xmm11, [rsp+0xA0]
00007f0145bdccf3  vmovaps xmm12, [rsp+0xB0]
00007f0145bdccfc  vmovaps xmm13, [rsp+0xC0]
00007f0145bdcd05  vmovaps xmm14, [rsp+0xD0]
00007f0145bdcd0e  vmovaps xmm15, [rsp+0xE0]
00007f0145bdcd17  add rsp, 0xF0
00007f0145bdcd1e  pop r11
00007f0145bdcd20  pop r10
00007f0145bdcd22  pop r9
00007f0145bdcd24  pop r8
00007f0145bdcd26  pop rsi
00007f0145bdcd27  pop rdi
00007f0145bdcd28  pop rdx
00007f0145bdcd29  pop rcx
00007f0145bdcd2a  pop rax
00007f0145bdcd2b  add rsp, 0x08
00007f0145bdcd2f  jmp 0x00007F0145BDBB99
00007f0145bdcd34  sub rsp, 0x08
00007f0145bdcd38  push rax
00007f0145bdcd39  push rcx
00007f0145bdcd3a  push rdx
00007f0145bdcd3b  push rdi
00007f0145bdcd3c  push rsi
00007f0145bdcd3d  push r8
00007f0145bdcd3f  push r9
00007f0145bdcd41  push r10
00007f0145bdcd43  push r11
00007f0145bdcd45  sub rsp, 0xF0
00007f0145bdcd4c  vmovaps [rsp], xmm0
00007f0145bdcd51  vmovaps [rsp+0x10], xmm1
00007f0145bdcd57  vmovaps [rsp+0x20], xmm2
00007f0145bdcd5d  vmovaps [rsp+0x30], xmm3
00007f0145bdcd63  vmovaps [rsp+0x40], xmm4
00007f0145bdcd69  vmovaps [rsp+0x50], xmm5
00007f0145bdcd6f  vmovaps [rsp+0x60], xmm6
00007f0145bdcd75  vmovaps [rsp+0x70], xmm7
00007f0145bdcd7b  vmovaps [rsp+0x80], xmm8
00007f0145bdcd84  vmovaps [rsp+0x90], xmm9
00007f0145bdcd8d  vmovaps [rsp+0xA0], xmm11
00007f0145bdcd96  vmovaps [rsp+0xB0], xmm12
00007f0145bdcd9f  vmovaps [rsp+0xC0], xmm13
00007f0145bdcda8  vmovaps [rsp+0xD0], xmm14
00007f0145bdcdb1  vmovaps [rsp+0xE0], xmm15
00007f0145bdcdba  sub rsp, 0x30
00007f0145bdcdbe  movaps [rsp], xmm10
00007f0145bdcdc3  movaps [rsp+0x10], xmm12
00007f0145bdcdc9  movaps [rsp+0x20], xmm11
00007f0145bdcdcf  lea rdi, [rsp]
00007f0145bdcdd3  mov esi, 0x00
00007f0145bdcdd8  mov rax, 0x636570E98530
00007f0145bdcde2  call rax
00007f0145bdcde4  movaps xmm10, [rsp]
00007f0145bdcde9  add rsp, 0x30
00007f0145bdcded  vmovaps xmm0, [rsp]
00007f0145bdcdf2  vmovaps xmm1, [rsp+0x10]
00007f0145bdcdf8  vmovaps xmm2, [rsp+0x20]
00007f0145bdcdfe  vmovaps xmm3, [rsp+0x30]
00007f0145bdce04  vmovaps xmm4, [rsp+0x40]
00007f0145bdce0a  vmovaps xmm5, [rsp+0x50]
00007f0145bdce10  vmovaps xmm6, [rsp+0x60]
00007f0145bdce16  vmovaps xmm7, [rsp+0x70]
00007f0145bdce1c  vmovaps xmm8, [rsp+0x80]
00007f0145bdce25  vmovaps xmm9, [rsp+0x90]
00007f0145bdce2e  vmovaps xmm11, [rsp+0xA0]
00007f0145bdce37  vmovaps xmm12, [rsp+0xB0]
00007f0145bdce40  vmovaps xmm13, [rsp+0xC0]
00007f0145bdce49  vmovaps xmm14, [rsp+0xD0]
00007f0145bdce52  vmovaps xmm15, [rsp+0xE0]
00007f0145bdce5b  add rsp, 0xF0
00007f0145bdce62  pop r11
00007f0145bdce64  pop r10
00007f0145bdce66  pop r9
00007f0145bdce68  pop r8
00007f0145bdce6a  pop rsi
00007f0145bdce6b  pop rdi
00007f0145bdce6c  pop rdx
00007f0145bdce6d  pop rcx
00007f0145bdce6e  pop rax
00007f0145bdce6f  add rsp, 0x08
00007f0145bdce73  jmp 0x00007F0145BDBBB3
00007f0145bdce78  sub rsp, 0x08
00007f0145bdce7c  push rax
00007f0145bdce7d  push rcx
00007f0145bdce7e  push rdx
00007f0145bdce7f  push rdi
00007f0145bdce80  push rsi
00007f0145bdce81  push r8
00007f0145bdce83  push r9
00007f0145bdce85  push r10
00007f0145bdce87  push r11
00007f0145bdce89  sub rsp, 0xF0
00007f0145bdce90  vmovaps [rsp], xmm0
00007f0145bdce95  vmovaps [rsp+0x10], xmm1
00007f0145bdce9b  vmovaps [rsp+0x20], xmm2
00007f0145bdcea1  vmovaps [rsp+0x30], xmm3
00007f0145bdcea7  vmovaps [rsp+0x40], xmm4
00007f0145bdcead  vmovaps [rsp+0x50], xmm5
00007f0145bdceb3  vmovaps [rsp+0x60], xmm7
00007f0145bdceb9  vmovaps [rsp+0x70], xmm8
00007f0145bdcebf  vmovaps [rsp+0x80], xmm9
00007f0145bdcec8  vmovaps [rsp+0x90], xmm10
00007f0145bdced1  vmovaps [rsp+0xA0], xmm11
00007f0145bdceda  vmovaps [rsp+0xB0], xmm12
00007f0145bdcee3  vmovaps [rsp+0xC0], xmm13
00007f0145bdceec  vmovaps [rsp+0xD0], xmm14
00007f0145bdcef5  vmovaps [rsp+0xE0], xmm15
00007f0145bdcefe  sub rsp, 0x30
00007f0145bdcf02  movaps [rsp], xmm6
00007f0145bdcf06  movaps [rsp+0x10], xmm12
00007f0145bdcf0c  movaps [rsp+0x20], xmm11
00007f0145bdcf12  lea rdi, [rsp]
00007f0145bdcf16  mov esi, 0x00
00007f0145bdcf1b  mov rax, 0x636570E98530
00007f0145bdcf25  call rax
00007f0145bdcf27  movaps xmm6, [rsp]
00007f0145bdcf2b  add rsp, 0x30
00007f0145bdcf2f  vmovaps xmm0, [rsp]
00007f0145bdcf34  vmovaps xmm1, [rsp+0x10]
00007f0145bdcf3a  vmovaps xmm2, [rsp+0x20]
00007f0145bdcf40  vmovaps xmm3, [rsp+0x30]
00007f0145bdcf46  vmovaps xmm4, [rsp+0x40]
00007f0145bdcf4c  vmovaps xmm5, [rsp+0x50]
00007f0145bdcf52  vmovaps xmm7, [rsp+0x60]
00007f0145bdcf58  vmovaps xmm8, [rsp+0x70]
00007f0145bdcf5e  vmovaps xmm9, [rsp+0x80]
00007f0145bdcf67  vmovaps xmm10, [rsp+0x90]
00007f0145bdcf70  vmovaps xmm11, [rsp+0xA0]
00007f0145bdcf79  vmovaps xmm12, [rsp+0xB0]
00007f0145bdcf82  vmovaps xmm13, [rsp+0xC0]
00007f0145bdcf8b  vmovaps xmm14, [rsp+0xD0]
00007f0145bdcf94  vmovaps xmm15, [rsp+0xE0]
00007f0145bdcf9d  add rsp, 0xF0
00007f0145bdcfa4  pop r11
00007f0145bdcfa6  pop r10
00007f0145bdcfa8  pop r9
00007f0145bdcfaa  pop r8
00007f0145bdcfac  pop rsi
00007f0145bdcfad  pop rdi
00007f0145bdcfae  pop rdx
00007f0145bdcfaf  pop rcx
00007f0145bdcfb0  pop rax
00007f0145bdcfb1  add rsp, 0x08
00007f0145bdcfb5  jmp 0x00007F0145BDBBD4
00007f0145bdcfba  sub rsp, 0x08
00007f0145bdcfbe  push rax
00007f0145bdcfbf  push rcx
00007f0145bdcfc0  push rdx
00007f0145bdcfc1  push rdi
00007f0145bdcfc2  push rsi
00007f0145bdcfc3  push r8
00007f0145bdcfc5  push r9
00007f0145bdcfc7  push r10
00007f0145bdcfc9  push r11
00007f0145bdcfcb  sub rsp, 0xF0
00007f0145bdcfd2  vmovaps [rsp], xmm0
00007f0145bdcfd7  vmovaps [rsp+0x10], xmm1
00007f0145bdcfdd  vmovaps [rsp+0x20], xmm2
00007f0145bdcfe3  vmovaps [rsp+0x30], xmm4
00007f0145bdcfe9  vmovaps [rsp+0x40], xmm5
00007f0145bdcfef  vmovaps [rsp+0x50], xmm6
00007f0145bdcff5  vmovaps [rsp+0x60], xmm7
00007f0145bdcffb  vmovaps [rsp+0x70], xmm8
00007f0145bdd001  vmovaps [rsp+0x80], xmm9
00007f0145bdd00a  vmovaps [rsp+0x90], xmm10
00007f0145bdd013  vmovaps [rsp+0xA0], xmm11
00007f0145bdd01c  vmovaps [rsp+0xB0], xmm12
00007f0145bdd025  vmovaps [rsp+0xC0], xmm13
00007f0145bdd02e  vmovaps [rsp+0xD0], xmm14
00007f0145bdd037  vmovaps [rsp+0xE0], xmm15
00007f0145bdd040  sub rsp, 0x30
00007f0145bdd044  movaps [rsp], xmm3
00007f0145bdd048  movaps [rsp+0x10], xmm5
00007f0145bdd04d  movaps [rsp+0x20], xmm4
00007f0145bdd052  lea rdi, [rsp]
00007f0145bdd056  mov esi, 0x00
00007f0145bdd05b  mov rax, 0x636570E98530
00007f0145bdd065  call rax
00007f0145bdd067  movaps xmm3, [rsp]
00007f0145bdd06b  add rsp, 0x30
00007f0145bdd06f  vmovaps xmm0, [rsp]
00007f0145bdd074  vmovaps xmm1, [rsp+0x10]
00007f0145bdd07a  vmovaps xmm2, [rsp+0x20]
00007f0145bdd080  vmovaps xmm4, [rsp+0x30]
00007f0145bdd086  vmovaps xmm5, [rsp+0x40]
00007f0145bdd08c  vmovaps xmm6, [rsp+0x50]
00007f0145bdd092  vmovaps xmm7, [rsp+0x60]
00007f0145bdd098  vmovaps xmm8, [rsp+0x70]
00007f0145bdd09e  vmovaps xmm9, [rsp+0x80]
00007f0145bdd0a7  vmovaps xmm10, [rsp+0x90]
00007f0145bdd0b0  vmovaps xmm11, [rsp+0xA0]
00007f0145bdd0b9  vmovaps xmm12, [rsp+0xB0]
00007f0145bdd0c2  vmovaps xmm13, [rsp+0xC0]
00007f0145bdd0cb  vmovaps xmm14, [rsp+0xD0]
00007f0145bdd0d4  vmovaps xmm15, [rsp+0xE0]
00007f0145bdd0dd  add rsp, 0xF0
00007f0145bdd0e4  pop r11
00007f0145bdd0e6  pop r10
00007f0145bdd0e8  pop r9
00007f0145bdd0ea  pop r8
00007f0145bdd0ec  pop rsi
00007f0145bdd0ed  pop rdi
00007f0145bdd0ee  pop rdx
00007f0145bdd0ef  pop rcx
00007f0145bdd0f0  pop rax
00007f0145bdd0f1  add rsp, 0x08
00007f0145bdd0f5  jmp 0x00007F0145BDBC35
00007f0145bdd0fa  sub rsp, 0x08
00007f0145bdd0fe  push rax
00007f0145bdd0ff  push rcx
00007f0145bdd100  push rdx
00007f0145bdd101  push rdi
00007f0145bdd102  push rsi
00007f0145bdd103  push r8
00007f0145bdd105  push r9
00007f0145bdd107  push r10
00007f0145bdd109  push r11
00007f0145bdd10b  sub rsp, 0xF0
00007f0145bdd112  vmovaps [rsp], xmm0
00007f0145bdd117  vmovaps [rsp+0x10], xmm1
00007f0145bdd11d  vmovaps [rsp+0x20], xmm2
00007f0145bdd123  vmovaps [rsp+0x30], xmm3
00007f0145bdd129  vmovaps [rsp+0x40], xmm4
00007f0145bdd12f  vmovaps [rsp+0x50], xmm6
00007f0145bdd135  vmovaps [rsp+0x60], xmm7
00007f0145bdd13b  vmovaps [rsp+0x70], xmm8
00007f0145bdd141  vmovaps [rsp+0x80], xmm9
00007f0145bdd14a  vmovaps [rsp+0x90], xmm10
00007f0145bdd153  vmovaps [rsp+0xA0], xmm11
00007f0145bdd15c  vmovaps [rsp+0xB0], xmm12
00007f0145bdd165  vmovaps [rsp+0xC0], xmm13
00007f0145bdd16e  vmovaps [rsp+0xD0], xmm14
00007f0145bdd177  vmovaps [rsp+0xE0], xmm15
00007f0145bdd180  sub rsp, 0x30
00007f0145bdd184  movaps [rsp], xmm5
00007f0145bdd188  movaps [rsp+0x10], xmm8
00007f0145bdd18e  movaps [rsp+0x20], xmm15
00007f0145bdd194  lea rdi, [rsp]
00007f0145bdd198  mov esi, 0x00
00007f0145bdd19d  mov rax, 0x636570E98530
00007f0145bdd1a7  call rax
00007f0145bdd1a9  movaps xmm5, [rsp]
00007f0145bdd1ad  add rsp, 0x30
00007f0145bdd1b1  vmovaps xmm0, [rsp]
00007f0145bdd1b6  vmovaps xmm1, [rsp+0x10]
00007f0145bdd1bc  vmovaps xmm2, [rsp+0x20]
00007f0145bdd1c2  vmovaps xmm3, [rsp+0x30]
00007f0145bdd1c8  vmovaps xmm4, [rsp+0x40]
00007f0145bdd1ce  vmovaps xmm6, [rsp+0x50]
00007f0145bdd1d4  vmovaps xmm7, [rsp+0x60]
00007f0145bdd1da  vmovaps xmm8, [rsp+0x70]
00007f0145bdd1e0  vmovaps xmm9, [rsp+0x80]
00007f0145bdd1e9  vmovaps xmm10, [rsp+0x90]
00007f0145bdd1f2  vmovaps xmm11, [rsp+0xA0]
00007f0145bdd1fb  vmovaps xmm12, [rsp+0xB0]
00007f0145bdd204  vmovaps xmm13, [rsp+0xC0]
00007f0145bdd20d  vmovaps xmm14, [rsp+0xD0]
00007f0145bdd216  vmovaps xmm15, [rsp+0xE0]
00007f0145bdd21f  add rsp, 0xF0
00007f0145bdd226  pop r11
00007f0145bdd228  pop r10
00007f0145bdd22a  pop r9
00007f0145bdd22c  pop r8
00007f0145bdd22e  pop rsi
00007f0145bdd22f  pop rdi
00007f0145bdd230  pop rdx
00007f0145bdd231  pop rcx
00007f0145bdd232  pop rax
00007f0145bdd233  add rsp, 0x08
00007f0145bdd237  jmp 0x00007F0145BDBC73
00007f0145bdd23c  sub rsp, 0x08
00007f0145bdd240  push rax
00007f0145bdd241  push rcx
00007f0145bdd242  push rdx
00007f0145bdd243  push rdi
00007f0145bdd244  push rsi
00007f0145bdd245  push r8
00007f0145bdd247  push r9
00007f0145bdd249  push r10
00007f0145bdd24b  push r11
00007f0145bdd24d  sub rsp, 0xF0
00007f0145bdd254  vmovaps [rsp], xmm0
00007f0145bdd259  vmovaps [rsp+0x10], xmm1
00007f0145bdd25f  vmovaps [rsp+0x20], xmm2
00007f0145bdd265  vmovaps [rsp+0x30], xmm3
00007f0145bdd26b  vmovaps [rsp+0x40], xmm5
00007f0145bdd271  vmovaps [rsp+0x50], xmm6
00007f0145bdd277  vmovaps [rsp+0x60], xmm7
00007f0145bdd27d  vmovaps [rsp+0x70], xmm8
00007f0145bdd283  vmovaps [rsp+0x80], xmm9
00007f0145bdd28c  vmovaps [rsp+0x90], xmm10
00007f0145bdd295  vmovaps [rsp+0xA0], xmm11
00007f0145bdd29e  vmovaps [rsp+0xB0], xmm12
00007f0145bdd2a7  vmovaps [rsp+0xC0], xmm13
00007f0145bdd2b0  vmovaps [rsp+0xD0], xmm14
00007f0145bdd2b9  vmovaps [rsp+0xE0], xmm15
00007f0145bdd2c2  sub rsp, 0x30
00007f0145bdd2c6  movaps [rsp], xmm4
00007f0145bdd2ca  movaps [rsp+0x10], xmm9
00007f0145bdd2d0  movaps [rsp+0x20], xmm8
00007f0145bdd2d6  lea rdi, [rsp]
00007f0145bdd2da  mov esi, 0x00
00007f0145bdd2df  mov rax, 0x636570E98530
00007f0145bdd2e9  call rax
00007f0145bdd2eb  movaps xmm4, [rsp]
00007f0145bdd2ef  add rsp, 0x30
00007f0145bdd2f3  vmovaps xmm0, [rsp]
00007f0145bdd2f8  vmovaps xmm1, [rsp+0x10]
00007f0145bdd2fe  vmovaps xmm2, [rsp+0x20]
00007f0145bdd304  vmovaps xmm3, [rsp+0x30]
00007f0145bdd30a  vmovaps xmm5, [rsp+0x40]
00007f0145bdd310  vmovaps xmm6, [rsp+0x50]
00007f0145bdd316  vmovaps xmm7, [rsp+0x60]
00007f0145bdd31c  vmovaps xmm8, [rsp+0x70]
00007f0145bdd322  vmovaps xmm9, [rsp+0x80]
00007f0145bdd32b  vmovaps xmm10, [rsp+0x90]
00007f0145bdd334  vmovaps xmm11, [rsp+0xA0]
00007f0145bdd33d  vmovaps xmm12, [rsp+0xB0]
00007f0145bdd346  vmovaps xmm13, [rsp+0xC0]
00007f0145bdd34f  vmovaps xmm14, [rsp+0xD0]
00007f0145bdd358  vmovaps xmm15, [rsp+0xE0]
00007f0145bdd361  add rsp, 0xF0
00007f0145bdd368  pop r11
00007f0145bdd36a  pop r10
00007f0145bdd36c  pop r9
00007f0145bdd36e  pop r8
00007f0145bdd370  pop rsi
00007f0145bdd371  pop rdi
00007f0145bdd372  pop rdx
00007f0145bdd373  pop rcx
00007f0145bdd374  pop rax
00007f0145bdd375  add rsp, 0x08
00007f0145bdd379  jmp 0x00007F0145BDBC94
00007f0145bdd37e  sub rsp, 0x08
00007f0145bdd382  push rax
00007f0145bdd383  push rcx
00007f0145bdd384  push rdx
00007f0145bdd385  push rdi
00007f0145bdd386  push rsi
00007f0145bdd387  push r8
00007f0145bdd389  push r9
00007f0145bdd38b  push r10
00007f0145bdd38d  push r11
00007f0145bdd38f  sub rsp, 0xF0
00007f0145bdd396  vmovaps [rsp], xmm0
00007f0145bdd39b  vmovaps [rsp+0x10], xmm1
00007f0145bdd3a1  vmovaps [rsp+0x20], xmm2
00007f0145bdd3a7  vmovaps [rsp+0x30], xmm3
00007f0145bdd3ad  vmovaps [rsp+0x40], xmm4
00007f0145bdd3b3  vmovaps [rsp+0x50], xmm5
00007f0145bdd3b9  vmovaps [rsp+0x60], xmm6
00007f0145bdd3bf  vmovaps [rsp+0x70], xmm7
00007f0145bdd3c5  vmovaps [rsp+0x80], xmm8
00007f0145bdd3ce  vmovaps [rsp+0x90], xmm10
00007f0145bdd3d7  vmovaps [rsp+0xA0], xmm11
00007f0145bdd3e0  vmovaps [rsp+0xB0], xmm12
00007f0145bdd3e9  vmovaps [rsp+0xC0], xmm13
00007f0145bdd3f2  vmovaps [rsp+0xD0], xmm14
00007f0145bdd3fb  vmovaps [rsp+0xE0], xmm15
00007f0145bdd404  sub rsp, 0x30
00007f0145bdd408  movaps [rsp], xmm9
00007f0145bdd40d  movaps [rsp+0x10], xmm10
00007f0145bdd413  movaps [rsp+0x20], xmm8
00007f0145bdd419  lea rdi, [rsp]
00007f0145bdd41d  mov esi, 0x00
00007f0145bdd422  mov rax, 0x636570E98530
00007f0145bdd42c  call rax
00007f0145bdd42e  movaps xmm9, [rsp]
00007f0145bdd433  add rsp, 0x30
00007f0145bdd437  vmovaps xmm0, [rsp]
00007f0145bdd43c  vmovaps xmm1, [rsp+0x10]
00007f0145bdd442  vmovaps xmm2, [rsp+0x20]
00007f0145bdd448  vmovaps xmm3, [rsp+0x30]
00007f0145bdd44e  vmovaps xmm4, [rsp+0x40]
00007f0145bdd454  vmovaps xmm5, [rsp+0x50]
00007f0145bdd45a  vmovaps xmm6, [rsp+0x60]
00007f0145bdd460  vmovaps xmm7, [rsp+0x70]
00007f0145bdd466  vmovaps xmm8, [rsp+0x80]
00007f0145bdd46f  vmovaps xmm10, [rsp+0x90]
00007f0145bdd478  vmovaps xmm11, [rsp+0xA0]
00007f0145bdd481  vmovaps xmm12, [rsp+0xB0]
00007f0145bdd48a  vmovaps xmm13, [rsp+0xC0]
00007f0145bdd493  vmovaps xmm14, [rsp+0xD0]
00007f0145bdd49c  vmovaps xmm15, [rsp+0xE0]
00007f0145bdd4a5  add rsp, 0xF0
00007f0145bdd4ac  pop r11
00007f0145bdd4ae  pop r10
00007f0145bdd4b0  pop r9
00007f0145bdd4b2  pop r8
00007f0145bdd4b4  pop rsi
00007f0145bdd4b5  pop rdi
00007f0145bdd4b6  pop rdx
00007f0145bdd4b7  pop rcx
00007f0145bdd4b8  pop rax
00007f0145bdd4b9  add rsp, 0x08
00007f0145bdd4bd  jmp 0x00007F0145BDBCAE
00007f0145bdd4c2  call 0x00007F0145AB52F0
00007f0145bdd4c7  jmp 0x00007F0145BDBDC8
00007f0145bdd4cc  call 0x00007F0145AB52F0
00007f0145bdd4d1  jmp 0x00007F0145BDBDDE
00007f0145bdd4d6  sub rsp, 0x08
00007f0145bdd4da  push rax
00007f0145bdd4db  push rcx
00007f0145bdd4dc  push rdx
00007f0145bdd4dd  push rdi
00007f0145bdd4de  push rsi
00007f0145bdd4df  push r8
00007f0145bdd4e1  push r9
00007f0145bdd4e3  push r10
00007f0145bdd4e5  push r11
00007f0145bdd4e7  sub rsp, 0xF0
00007f0145bdd4ee  vmovaps [rsp], xmm0
00007f0145bdd4f3  vmovaps [rsp+0x10], xmm2
00007f0145bdd4f9  vmovaps [rsp+0x20], xmm3
00007f0145bdd4ff  vmovaps [rsp+0x30], xmm4
00007f0145bdd505  vmovaps [rsp+0x40], xmm5
00007f0145bdd50b  vmovaps [rsp+0x50], xmm6
00007f0145bdd511  vmovaps [rsp+0x60], xmm7
00007f0145bdd517  vmovaps [rsp+0x70], xmm8
00007f0145bdd51d  vmovaps [rsp+0x80], xmm9
00007f0145bdd526  vmovaps [rsp+0x90], xmm10
00007f0145bdd52f  vmovaps [rsp+0xA0], xmm11
00007f0145bdd538  vmovaps [rsp+0xB0], xmm12
00007f0145bdd541  vmovaps [rsp+0xC0], xmm13
00007f0145bdd54a  vmovaps [rsp+0xD0], xmm14
00007f0145bdd553  vmovaps [rsp+0xE0], xmm15
00007f0145bdd55c  sub rsp, 0x30
00007f0145bdd560  movaps [rsp], xmm1
00007f0145bdd564  movaps [rsp+0x10], xmm6
00007f0145bdd569  movaps [rsp+0x20], xmm15
00007f0145bdd56f  lea rdi, [rsp]
00007f0145bdd573  mov esi, 0x00
00007f0145bdd578  mov rax, 0x636570E98530
00007f0145bdd582  call rax
00007f0145bdd584  movaps xmm1, [rsp]
00007f0145bdd588  add rsp, 0x30
00007f0145bdd58c  vmovaps xmm0, [rsp]
00007f0145bdd591  vmovaps xmm2, [rsp+0x10]
00007f0145bdd597  vmovaps xmm3, [rsp+0x20]
00007f0145bdd59d  vmovaps xmm4, [rsp+0x30]
00007f0145bdd5a3  vmovaps xmm5, [rsp+0x40]
00007f0145bdd5a9  vmovaps xmm6, [rsp+0x50]
00007f0145bdd5af  vmovaps xmm7, [rsp+0x60]
00007f0145bdd5b5  vmovaps xmm8, [rsp+0x70]
00007f0145bdd5bb  vmovaps xmm9, [rsp+0x80]
00007f0145bdd5c4  vmovaps xmm10, [rsp+0x90]
00007f0145bdd5cd  vmovaps xmm11, [rsp+0xA0]
00007f0145bdd5d6  vmovaps xmm12, [rsp+0xB0]
00007f0145bdd5df  vmovaps xmm13, [rsp+0xC0]
00007f0145bdd5e8  vmovaps xmm14, [rsp+0xD0]
00007f0145bdd5f1  vmovaps xmm15, [rsp+0xE0]
00007f0145bdd5fa  add rsp, 0xF0
00007f0145bdd601  pop r11
00007f0145bdd603  pop r10
00007f0145bdd605  pop r9
00007f0145bdd607  pop r8
00007f0145bdd609  pop rsi
00007f0145bdd60a  pop rdi
00007f0145bdd60b  pop rdx
00007f0145bdd60c  pop rcx
00007f0145bdd60d  pop rax
00007f0145bdd60e  add rsp, 0x08
00007f0145bdd612  jmp 0x00007F0145BDBE1B
00007f0145bdd617  call 0x00007F0145AC4620
00007f0145bdd61c  jmp 0x00007F0145BDBE28
00007f0145bdd621  sub rsp, 0x08
00007f0145bdd625  push rax
00007f0145bdd626  push rcx
00007f0145bdd627  push rdx
00007f0145bdd628  push rdi
00007f0145bdd629  push rsi
00007f0145bdd62a  push r8
00007f0145bdd62c  push r9
00007f0145bdd62e  push r10
00007f0145bdd630  push r11
00007f0145bdd632  sub rsp, 0xF0
00007f0145bdd639  vmovaps [rsp], xmm0
00007f0145bdd63e  vmovaps [rsp+0x10], xmm1
00007f0145bdd644  vmovaps [rsp+0x20], xmm2
00007f0145bdd64a  vmovaps [rsp+0x30], xmm3
00007f0145bdd650  vmovaps [rsp+0x40], xmm4
00007f0145bdd656  vmovaps [rsp+0x50], xmm5
00007f0145bdd65c  vmovaps [rsp+0x60], xmm6
00007f0145bdd662  vmovaps [rsp+0x70], xmm7
00007f0145bdd668  vmovaps [rsp+0x80], xmm8
00007f0145bdd671  vmovaps [rsp+0x90], xmm9
00007f0145bdd67a  vmovaps [rsp+0xA0], xmm10
00007f0145bdd683  vmovaps [rsp+0xB0], xmm11
00007f0145bdd68c  vmovaps [rsp+0xC0], xmm12
00007f0145bdd695  vmovaps [rsp+0xD0], xmm13
00007f0145bdd69e  vmovaps [rsp+0xE0], xmm15
00007f0145bdd6a7  sub rsp, 0x30
00007f0145bdd6ab  movaps [rsp], xmm14
00007f0145bdd6b0  movaps [rsp+0x10], xmm4
00007f0145bdd6b5  movaps [rsp+0x20], xmm3
00007f0145bdd6ba  lea rdi, [rsp]
00007f0145bdd6be  mov esi, 0x00
00007f0145bdd6c3  mov rax, 0x636570E98530
00007f0145bdd6cd  call rax
00007f0145bdd6cf  movaps xmm14, [rsp]
00007f0145bdd6d4  add rsp, 0x30
00007f0145bdd6d8  vmovaps xmm0, [rsp]
00007f0145bdd6dd  vmovaps xmm1, [rsp+0x10]
00007f0145bdd6e3  vmovaps xmm2, [rsp+0x20]
00007f0145bdd6e9  vmovaps xmm3, [rsp+0x30]
00007f0145bdd6ef  vmovaps xmm4, [rsp+0x40]
00007f0145bdd6f5  vmovaps xmm5, [rsp+0x50]
00007f0145bdd6fb  vmovaps xmm6, [rsp+0x60]
00007f0145bdd701  vmovaps xmm7, [rsp+0x70]
00007f0145bdd707  vmovaps xmm8, [rsp+0x80]
00007f0145bdd710  vmovaps xmm9, [rsp+0x90]
00007f0145bdd719  vmovaps xmm10, [rsp+0xA0]
00007f0145bdd722  vmovaps xmm11, [rsp+0xB0]
00007f0145bdd72b  vmovaps xmm12, [rsp+0xC0]
00007f0145bdd734  vmovaps xmm13, [rsp+0xD0]
00007f0145bdd73d  vmovaps xmm15, [rsp+0xE0]
00007f0145bdd746  add rsp, 0xF0
00007f0145bdd74d  pop r11
00007f0145bdd74f  pop r10
00007f0145bdd751  pop r9
00007f0145bdd753  pop r8
00007f0145bdd755  pop rsi
00007f0145bdd756  pop rdi
00007f0145bdd757  pop rdx
00007f0145bdd758  pop rcx
00007f0145bdd759  pop rax
00007f0145bdd75a  add rsp, 0x08
00007f0145bdd75e  jmp 0x00007F0145BDBE42
00007f0145bdd763  sub rsp, 0x08
00007f0145bdd767  push rax
00007f0145bdd768  push rcx
00007f0145bdd769  push rdx
00007f0145bdd76a  push rdi
00007f0145bdd76b  push rsi
00007f0145bdd76c  push r8
00007f0145bdd76e  push r9
00007f0145bdd770  push r10
00007f0145bdd772  push r11
00007f0145bdd774  sub rsp, 0xF0
00007f0145bdd77b  vmovaps [rsp], xmm0
00007f0145bdd780  vmovaps [rsp+0x10], xmm1
00007f0145bdd786  vmovaps [rsp+0x20], xmm2
00007f0145bdd78c  vmovaps [rsp+0x30], xmm3
00007f0145bdd792  vmovaps [rsp+0x40], xmm4
00007f0145bdd798  vmovaps [rsp+0x50], xmm5
00007f0145bdd79e  vmovaps [rsp+0x60], xmm7
00007f0145bdd7a4  vmovaps [rsp+0x70], xmm8
00007f0145bdd7aa  vmovaps [rsp+0x80], xmm9
00007f0145bdd7b3  vmovaps [rsp+0x90], xmm10
00007f0145bdd7bc  vmovaps [rsp+0xA0], xmm11
00007f0145bdd7c5  vmovaps [rsp+0xB0], xmm12
00007f0145bdd7ce  vmovaps [rsp+0xC0], xmm13
00007f0145bdd7d7  vmovaps [rsp+0xD0], xmm14
00007f0145bdd7e0  vmovaps [rsp+0xE0], xmm15
00007f0145bdd7e9  sub rsp, 0x30
00007f0145bdd7ed  movaps [rsp], xmm6
00007f0145bdd7f1  movaps [rsp+0x10], xmm9
00007f0145bdd7f7  movaps [rsp+0x20], xmm7
00007f0145bdd7fc  lea rdi, [rsp]
00007f0145bdd800  mov esi, 0x00
00007f0145bdd805  mov rax, 0x636570E98530
00007f0145bdd80f  call rax
00007f0145bdd811  movaps xmm6, [rsp]
00007f0145bdd815  add rsp, 0x30
00007f0145bdd819  vmovaps xmm0, [rsp]
00007f0145bdd81e  vmovaps xmm1, [rsp+0x10]
00007f0145bdd824  vmovaps xmm2, [rsp+0x20]
00007f0145bdd82a  vmovaps xmm3, [rsp+0x30]
00007f0145bdd830  vmovaps xmm4, [rsp+0x40]
00007f0145bdd836  vmovaps xmm5, [rsp+0x50]
00007f0145bdd83c  vmovaps xmm7, [rsp+0x60]
00007f0145bdd842  vmovaps xmm8, [rsp+0x70]
00007f0145bdd848  vmovaps xmm9, [rsp+0x80]
00007f0145bdd851  vmovaps xmm10, [rsp+0x90]
00007f0145bdd85a  vmovaps xmm11, [rsp+0xA0]
00007f0145bdd863  vmovaps xmm12, [rsp+0xB0]
00007f0145bdd86c  vmovaps xmm13, [rsp+0xC0]
00007f0145bdd875  vmovaps xmm14, [rsp+0xD0]
00007f0145bdd87e  vmovaps xmm15, [rsp+0xE0]
00007f0145bdd887  add rsp, 0xF0
00007f0145bdd88e  pop r11
00007f0145bdd890  pop r10
00007f0145bdd892  pop r9
00007f0145bdd894  pop r8
00007f0145bdd896  pop rsi
00007f0145bdd897  pop rdi
00007f0145bdd898  pop rdx
00007f0145bdd899  pop rcx
00007f0145bdd89a  pop rax
00007f0145bdd89b  add rsp, 0x08
00007f0145bdd89f  jmp 0x00007F0145BDBE5A
00007f0145bdd8a4  sub rsp, 0x08
00007f0145bdd8a8  push rax
00007f0145bdd8a9  push rcx
00007f0145bdd8aa  push rdx
00007f0145bdd8ab  push rdi
00007f0145bdd8ac  push rsi
00007f0145bdd8ad  push r8
00007f0145bdd8af  push r9
00007f0145bdd8b1  push r10
00007f0145bdd8b3  push r11
00007f0145bdd8b5  sub rsp, 0xF0
00007f0145bdd8bc  vmovaps [rsp], xmm0
00007f0145bdd8c1  vmovaps [rsp+0x10], xmm1
00007f0145bdd8c7  vmovaps [rsp+0x20], xmm2
00007f0145bdd8cd  vmovaps [rsp+0x30], xmm3
00007f0145bdd8d3  vmovaps [rsp+0x40], xmm4
00007f0145bdd8d9  vmovaps [rsp+0x50], xmm5
00007f0145bdd8df  vmovaps [rsp+0x60], xmm6
00007f0145bdd8e5  vmovaps [rsp+0x70], xmm8
00007f0145bdd8eb  vmovaps [rsp+0x80], xmm9
00007f0145bdd8f4  vmovaps [rsp+0x90], xmm10
00007f0145bdd8fd  vmovaps [rsp+0xA0], xmm11
00007f0145bdd906  vmovaps [rsp+0xB0], xmm12
00007f0145bdd90f  vmovaps [rsp+0xC0], xmm13
00007f0145bdd918  vmovaps [rsp+0xD0], xmm14
00007f0145bdd921  vmovaps [rsp+0xE0], xmm15
00007f0145bdd92a  sub rsp, 0x30
00007f0145bdd92e  movaps [rsp], xmm7
00007f0145bdd932  movaps [rsp+0x10], xmm4
00007f0145bdd937  movaps [rsp+0x20], xmm9
00007f0145bdd93d  lea rdi, [rsp]
00007f0145bdd941  mov esi, 0x00
00007f0145bdd946  mov rax, 0x636570E98530
00007f0145bdd950  call rax
00007f0145bdd952  movaps xmm7, [rsp]
00007f0145bdd956  add rsp, 0x30
00007f0145bdd95a  vmovaps xmm0, [rsp]
00007f0145bdd95f  vmovaps xmm1, [rsp+0x10]
00007f0145bdd965  vmovaps xmm2, [rsp+0x20]
00007f0145bdd96b  vmovaps xmm3, [rsp+0x30]
00007f0145bdd971  vmovaps xmm4, [rsp+0x40]
00007f0145bdd977  vmovaps xmm5, [rsp+0x50]
00007f0145bdd97d  vmovaps xmm6, [rsp+0x60]
00007f0145bdd983  vmovaps xmm8, [rsp+0x70]
00007f0145bdd989  vmovaps xmm9, [rsp+0x80]
00007f0145bdd992  vmovaps xmm10, [rsp+0x90]
00007f0145bdd99b  vmovaps xmm11, [rsp+0xA0]
00007f0145bdd9a4  vmovaps xmm12, [rsp+0xB0]
00007f0145bdd9ad  vmovaps xmm13, [rsp+0xC0]
00007f0145bdd9b6  vmovaps xmm14, [rsp+0xD0]
00007f0145bdd9bf  vmovaps xmm15, [rsp+0xE0]
00007f0145bdd9c8  add rsp, 0xF0
00007f0145bdd9cf  pop r11
00007f0145bdd9d1  pop r10
00007f0145bdd9d3  pop r9
00007f0145bdd9d5  pop r8
00007f0145bdd9d7  pop rsi
00007f0145bdd9d8  pop rdi
00007f0145bdd9d9  pop rdx
00007f0145bdd9da  pop rcx
00007f0145bdd9db  pop rax
00007f0145bdd9dc  add rsp, 0x08
00007f0145bdd9e0  jmp 0x00007F0145BDBE87
00007f0145bdd9e5  sub rsp, 0x08
00007f0145bdd9e9  push rax
00007f0145bdd9ea  push rcx
00007f0145bdd9eb  push rdx
00007f0145bdd9ec  push rdi
00007f0145bdd9ed  push rsi
00007f0145bdd9ee  push r8
00007f0145bdd9f0  push r9
00007f0145bdd9f2  push r10
00007f0145bdd9f4  push r11
00007f0145bdd9f6  sub rsp, 0xF0
00007f0145bdd9fd  vmovaps [rsp], xmm0
00007f0145bdda02  vmovaps [rsp+0x10], xmm1
00007f0145bdda08  vmovaps [rsp+0x20], xmm2
00007f0145bdda0e  vmovaps [rsp+0x30], xmm3
00007f0145bdda14  vmovaps [rsp+0x40], xmm5
00007f0145bdda1a  vmovaps [rsp+0x50], xmm6
00007f0145bdda20  vmovaps [rsp+0x60], xmm7
00007f0145bdda26  vmovaps [rsp+0x70], xmm8
00007f0145bdda2c  vmovaps [rsp+0x80], xmm9
00007f0145bdda35  vmovaps [rsp+0x90], xmm10
00007f0145bdda3e  vmovaps [rsp+0xA0], xmm11
00007f0145bdda47  vmovaps [rsp+0xB0], xmm12
00007f0145bdda50  vmovaps [rsp+0xC0], xmm13
00007f0145bdda59  vmovaps [rsp+0xD0], xmm14
00007f0145bdda62  vmovaps [rsp+0xE0], xmm15
00007f0145bdda6b  sub rsp, 0x30
00007f0145bdda6f  movaps [rsp], xmm4
00007f0145bdda73  movaps [rsp+0x10], xmm15
00007f0145bdda79  movaps [rsp+0x20], xmm9
00007f0145bdda7f  lea rdi, [rsp]
00007f0145bdda83  mov esi, 0x00
00007f0145bdda88  mov rax, 0x636570E98530
00007f0145bdda92  call rax
00007f0145bdda94  movaps xmm4, [rsp]
00007f0145bdda98  add rsp, 0x30
00007f0145bdda9c  vmovaps xmm0, [rsp]
00007f0145bddaa1  vmovaps xmm1, [rsp+0x10]
00007f0145bddaa7  vmovaps xmm2, [rsp+0x20]
00007f0145bddaad  vmovaps xmm3, [rsp+0x30]
00007f0145bddab3  vmovaps xmm5, [rsp+0x40]
00007f0145bddab9  vmovaps xmm6, [rsp+0x50]
00007f0145bddabf  vmovaps xmm7, [rsp+0x60]
00007f0145bddac5  vmovaps xmm8, [rsp+0x70]
00007f0145bddacb  vmovaps xmm9, [rsp+0x80]
00007f0145bddad4  vmovaps xmm10, [rsp+0x90]
00007f0145bddadd  vmovaps xmm11, [rsp+0xA0]
00007f0145bddae6  vmovaps xmm12, [rsp+0xB0]
00007f0145bddaef  vmovaps xmm13, [rsp+0xC0]
00007f0145bddaf8  vmovaps xmm14, [rsp+0xD0]
00007f0145bddb01  vmovaps xmm15, [rsp+0xE0]
00007f0145bddb0a  add rsp, 0xF0
00007f0145bddb11  pop r11
00007f0145bddb13  pop r10
00007f0145bddb15  pop r9
00007f0145bddb17  pop r8
00007f0145bddb19  pop rsi
00007f0145bddb1a  pop rdi
00007f0145bddb1b  pop rdx
00007f0145bddb1c  pop rcx
00007f0145bddb1d  pop rax
00007f0145bddb1e  add rsp, 0x08
00007f0145bddb22  jmp 0x00007F0145BDBEAC
00007f0145bddb27  call 0x00007F0145AC4620
00007f0145bddb2c  jmp 0x00007F0145BDBEB9
00007f0145bddb31  sub rsp, 0x08
00007f0145bddb35  push rax
00007f0145bddb36  push rcx
00007f0145bddb37  push rdx
00007f0145bddb38  push rdi
00007f0145bddb39  push rsi
00007f0145bddb3a  push r8
00007f0145bddb3c  push r9
00007f0145bddb3e  push r10
00007f0145bddb40  push r11
00007f0145bddb42  sub rsp, 0xF0
00007f0145bddb49  vmovaps [rsp], xmm0
00007f0145bddb4e  vmovaps [rsp+0x10], xmm1
00007f0145bddb54  vmovaps [rsp+0x20], xmm2
00007f0145bddb5a  vmovaps [rsp+0x30], xmm4
00007f0145bddb60  vmovaps [rsp+0x40], xmm5
00007f0145bddb66  vmovaps [rsp+0x50], xmm6
00007f0145bddb6c  vmovaps [rsp+0x60], xmm7
00007f0145bddb72  vmovaps [rsp+0x70], xmm8
00007f0145bddb78  vmovaps [rsp+0x80], xmm9
00007f0145bddb81  vmovaps [rsp+0x90], xmm10
00007f0145bddb8a  vmovaps [rsp+0xA0], xmm11
00007f0145bddb93  vmovaps [rsp+0xB0], xmm12
00007f0145bddb9c  vmovaps [rsp+0xC0], xmm13
00007f0145bddba5  vmovaps [rsp+0xD0], xmm14
00007f0145bddbae  vmovaps [rsp+0xE0], xmm15
00007f0145bddbb7  sub rsp, 0x30
00007f0145bddbbb  movaps [rsp], xmm3
00007f0145bddbbf  movaps [rsp+0x10], xmm1
00007f0145bddbc4  movaps [rsp+0x20], xmm9
00007f0145bddbca  lea rdi, [rsp]
00007f0145bddbce  mov esi, 0x00
00007f0145bddbd3  mov rax, 0x636570E98530
00007f0145bddbdd  call rax
00007f0145bddbdf  movaps xmm3, [rsp]
00007f0145bddbe3  add rsp, 0x30
00007f0145bddbe7  vmovaps xmm0, [rsp]
00007f0145bddbec  vmovaps xmm1, [rsp+0x10]
00007f0145bddbf2  vmovaps xmm2, [rsp+0x20]
00007f0145bddbf8  vmovaps xmm4, [rsp+0x30]
00007f0145bddbfe  vmovaps xmm5, [rsp+0x40]
00007f0145bddc04  vmovaps xmm6, [rsp+0x50]
00007f0145bddc0a  vmovaps xmm7, [rsp+0x60]
00007f0145bddc10  vmovaps xmm8, [rsp+0x70]
00007f0145bddc16  vmovaps xmm9, [rsp+0x80]
00007f0145bddc1f  vmovaps xmm10, [rsp+0x90]
00007f0145bddc28  vmovaps xmm11, [rsp+0xA0]
00007f0145bddc31  vmovaps xmm12, [rsp+0xB0]
00007f0145bddc3a  vmovaps xmm13, [rsp+0xC0]
00007f0145bddc43  vmovaps xmm14, [rsp+0xD0]
00007f0145bddc4c  vmovaps xmm15, [rsp+0xE0]
00007f0145bddc55  add rsp, 0xF0
00007f0145bddc5c  pop r11
00007f0145bddc5e  pop r10
00007f0145bddc60  pop r9
00007f0145bddc62  pop r8
00007f0145bddc64  pop rsi
00007f0145bddc65  pop rdi
00007f0145bddc66  pop rdx
00007f0145bddc67  pop rcx
00007f0145bddc68  pop rax
00007f0145bddc69  add rsp, 0x08
00007f0145bddc6d  jmp 0x00007F0145BDBEF6
00007f0145bddc72  sub rsp, 0x08
00007f0145bddc76  push rax
00007f0145bddc77  push rcx
00007f0145bddc78  push rdx
00007f0145bddc79  push rdi
00007f0145bddc7a  push rsi
00007f0145bddc7b  push r8
00007f0145bddc7d  push r9
00007f0145bddc7f  push r10
00007f0145bddc81  push r11
00007f0145bddc83  sub rsp, 0xF0
00007f0145bddc8a  vmovaps [rsp], xmm0
00007f0145bddc8f  vmovaps [rsp+0x10], xmm2
00007f0145bddc95  vmovaps [rsp+0x20], xmm3
00007f0145bddc9b  vmovaps [rsp+0x30], xmm4
00007f0145bddca1  vmovaps [rsp+0x40], xmm5
00007f0145bddca7  vmovaps [rsp+0x50], xmm6
00007f0145bddcad  vmovaps [rsp+0x60], xmm7
00007f0145bddcb3  vmovaps [rsp+0x70], xmm8
00007f0145bddcb9  vmovaps [rsp+0x80], xmm9
00007f0145bddcc2  vmovaps [rsp+0x90], xmm10
00007f0145bddccb  vmovaps [rsp+0xA0], xmm11
00007f0145bddcd4  vmovaps [rsp+0xB0], xmm12
00007f0145bddcdd  vmovaps [rsp+0xC0], xmm13
00007f0145bddce6  vmovaps [rsp+0xD0], xmm14
00007f0145bddcef  vmovaps [rsp+0xE0], xmm15
00007f0145bddcf8  sub rsp, 0x30
00007f0145bddcfc  movaps [rsp], xmm1
00007f0145bddd00  movaps [rsp+0x10], xmm15
00007f0145bddd06  movaps [rsp+0x20], xmm9
00007f0145bddd0c  lea rdi, [rsp]
00007f0145bddd10  mov esi, 0x00
00007f0145bddd15  mov rax, 0x636570E98530
00007f0145bddd1f  call rax
00007f0145bddd21  movaps xmm1, [rsp]
00007f0145bddd25  add rsp, 0x30
00007f0145bddd29  vmovaps xmm0, [rsp]
00007f0145bddd2e  vmovaps xmm2, [rsp+0x10]
00007f0145bddd34  vmovaps xmm3, [rsp+0x20]
00007f0145bddd3a  vmovaps xmm4, [rsp+0x30]
00007f0145bddd40  vmovaps xmm5, [rsp+0x40]
00007f0145bddd46  vmovaps xmm6, [rsp+0x50]
00007f0145bddd4c  vmovaps xmm7, [rsp+0x60]
00007f0145bddd52  vmovaps xmm8, [rsp+0x70]
00007f0145bddd58  vmovaps xmm9, [rsp+0x80]
00007f0145bddd61  vmovaps xmm10, [rsp+0x90]
00007f0145bddd6a  vmovaps xmm11, [rsp+0xA0]
00007f0145bddd73  vmovaps xmm12, [rsp+0xB0]
00007f0145bddd7c  vmovaps xmm13, [rsp+0xC0]
00007f0145bddd85  vmovaps xmm14, [rsp+0xD0]
00007f0145bddd8e  vmovaps xmm15, [rsp+0xE0]
00007f0145bddd97  add rsp, 0xF0
00007f0145bddd9e  pop r11
00007f0145bddda0  pop r10
00007f0145bddda2  pop r9
00007f0145bddda4  pop r8
00007f0145bddda6  pop rsi
00007f0145bddda7  pop rdi
00007f0145bddda8  pop rdx
00007f0145bddda9  pop rcx
00007f0145bdddaa  pop rax
00007f0145bdddab  add rsp, 0x08
00007f0145bdddaf  jmp 0x00007F0145BDBF7E
00007f0145bdddb4  call 0x00007F0145AC4620
00007f0145bdddb9  jmp 0x00007F0145BDBF8B
00007f0145bdddbe  sub rsp, 0x08
00007f0145bdddc2  push rax
00007f0145bdddc3  push rcx
00007f0145bdddc4  push rdx
00007f0145bdddc5  push rdi
00007f0145bdddc6  push rsi
00007f0145bdddc7  push r8
00007f0145bdddc9  push r9
00007f0145bdddcb  push r10
00007f0145bdddcd  push r11
00007f0145bdddcf  sub rsp, 0xF0
00007f0145bdddd6  vmovaps [rsp], xmm0
00007f0145bddddb  vmovaps [rsp+0x10], xmm2
00007f0145bddde1  vmovaps [rsp+0x20], xmm3
00007f0145bddde7  vmovaps [rsp+0x30], xmm4
00007f0145bddded  vmovaps [rsp+0x40], xmm5
00007f0145bdddf3  vmovaps [rsp+0x50], xmm6
00007f0145bdddf9  vmovaps [rsp+0x60], xmm7
00007f0145bdddff  vmovaps [rsp+0x70], xmm8
00007f0145bdde05  vmovaps [rsp+0x80], xmm9
00007f0145bdde0e  vmovaps [rsp+0x90], xmm10
00007f0145bdde17  vmovaps [rsp+0xA0], xmm11
00007f0145bdde20  vmovaps [rsp+0xB0], xmm12
00007f0145bdde29  vmovaps [rsp+0xC0], xmm13
00007f0145bdde32  vmovaps [rsp+0xD0], xmm14
00007f0145bdde3b  vmovaps [rsp+0xE0], xmm15
00007f0145bdde44  sub rsp, 0x30
00007f0145bdde48  movaps [rsp], xmm1
00007f0145bdde4c  movaps [rsp+0x10], xmm5
00007f0145bdde51  movaps [rsp+0x20], xmm7
00007f0145bdde56  lea rdi, [rsp]
00007f0145bdde5a  mov esi, 0x00
00007f0145bdde5f  mov rax, 0x636570E98530
00007f0145bdde69  call rax
00007f0145bdde6b  movaps xmm1, [rsp]
00007f0145bdde6f  add rsp, 0x30
00007f0145bdde73  vmovaps xmm0, [rsp]
00007f0145bdde78  vmovaps xmm2, [rsp+0x10]
00007f0145bdde7e  vmovaps xmm3, [rsp+0x20]
00007f0145bdde84  vmovaps xmm4, [rsp+0x30]
00007f0145bdde8a  vmovaps xmm5, [rsp+0x40]
00007f0145bdde90  vmovaps xmm6, [rsp+0x50]
00007f0145bdde96  vmovaps xmm7, [rsp+0x60]
00007f0145bdde9c  vmovaps xmm8, [rsp+0x70]
00007f0145bddea2  vmovaps xmm9, [rsp+0x80]
00007f0145bddeab  vmovaps xmm10, [rsp+0x90]
00007f0145bddeb4  vmovaps xmm11, [rsp+0xA0]
00007f0145bddebd  vmovaps xmm12, [rsp+0xB0]
00007f0145bddec6  vmovaps xmm13, [rsp+0xC0]
00007f0145bddecf  vmovaps xmm14, [rsp+0xD0]
00007f0145bdded8  vmovaps xmm15, [rsp+0xE0]
00007f0145bddee1  add rsp, 0xF0
00007f0145bddee8  pop r11
00007f0145bddeea  pop r10
00007f0145bddeec  pop r9
00007f0145bddeee  pop r8
00007f0145bddef0  pop rsi
00007f0145bddef1  pop rdi
00007f0145bddef2  pop rdx
00007f0145bddef3  pop rcx
00007f0145bddef4  pop rax
00007f0145bddef5  add rsp, 0x08
00007f0145bddef9  jmp 0x00007F0145BDC030
00007f0145bddefe  sub rsp, 0x08
00007f0145bddf02  push rax
00007f0145bddf03  push rcx
00007f0145bddf04  push rdx
00007f0145bddf05  push rdi
00007f0145bddf06  push rsi
00007f0145bddf07  push r8
00007f0145bddf09  push r9
00007f0145bddf0b  push r10
00007f0145bddf0d  push r11
00007f0145bddf0f  sub rsp, 0xF0
00007f0145bddf16  vmovaps [rsp], xmm0
00007f0145bddf1b  vmovaps [rsp+0x10], xmm1
00007f0145bddf21  vmovaps [rsp+0x20], xmm2
00007f0145bddf27  vmovaps [rsp+0x30], xmm3
00007f0145bddf2d  vmovaps [rsp+0x40], xmm4
00007f0145bddf33  vmovaps [rsp+0x50], xmm5
00007f0145bddf39  vmovaps [rsp+0x60], xmm6
00007f0145bddf3f  vmovaps [rsp+0x70], xmm8
00007f0145bddf45  vmovaps [rsp+0x80], xmm9
00007f0145bddf4e  vmovaps [rsp+0x90], xmm10
00007f0145bddf57  vmovaps [rsp+0xA0], xmm11
00007f0145bddf60  vmovaps [rsp+0xB0], xmm12
00007f0145bddf69  vmovaps [rsp+0xC0], xmm13
00007f0145bddf72  vmovaps [rsp+0xD0], xmm14
00007f0145bddf7b  vmovaps [rsp+0xE0], xmm15
00007f0145bddf84  sub rsp, 0x30
00007f0145bddf88  movaps [rsp], xmm7
00007f0145bddf8c  movaps [rsp+0x10], xmm5
00007f0145bddf91  movaps [rsp+0x20], xmm15
00007f0145bddf97  lea rdi, [rsp]
00007f0145bddf9b  mov esi, 0x00
00007f0145bddfa0  mov rax, 0x636570E98530
00007f0145bddfaa  call rax
00007f0145bddfac  movaps xmm7, [rsp]
00007f0145bddfb0  add rsp, 0x30
00007f0145bddfb4  vmovaps xmm0, [rsp]
00007f0145bddfb9  vmovaps xmm1, [rsp+0x10]
00007f0145bddfbf  vmovaps xmm2, [rsp+0x20]
00007f0145bddfc5  vmovaps xmm3, [rsp+0x30]
00007f0145bddfcb  vmovaps xmm4, [rsp+0x40]
00007f0145bddfd1  vmovaps xmm5, [rsp+0x50]
00007f0145bddfd7  vmovaps xmm6, [rsp+0x60]
00007f0145bddfdd  vmovaps xmm8, [rsp+0x70]
00007f0145bddfe3  vmovaps xmm9, [rsp+0x80]
00007f0145bddfec  vmovaps xmm10, [rsp+0x90]
00007f0145bddff5  vmovaps xmm11, [rsp+0xA0]
00007f0145bddffe  vmovaps xmm12, [rsp+0xB0]
00007f0145bde007  vmovaps xmm13, [rsp+0xC0]
00007f0145bde010  vmovaps xmm14, [rsp+0xD0]
00007f0145bde019  vmovaps xmm15, [rsp+0xE0]
00007f0145bde022  add rsp, 0xF0
00007f0145bde029  pop r11
00007f0145bde02b  pop r10
00007f0145bde02d  pop r9
00007f0145bde02f  pop r8
00007f0145bde031  pop rsi
00007f0145bde032  pop rdi
00007f0145bde033  pop rdx
00007f0145bde034  pop rcx
00007f0145bde035  pop rax
00007f0145bde036  add rsp, 0x08
00007f0145bde03a  jmp 0x00007F0145BDC066
00007f0145bde03f  call 0x00007F0145AB52F0
00007f0145bde044  jmp 0x00007F0145BDC073
00007f0145bde049  sub rsp, 0x08
00007f0145bde04d  push rax
00007f0145bde04e  push rcx
00007f0145bde04f  push rdx
00007f0145bde050  push rdi
00007f0145bde051  push rsi
00007f0145bde052  push r8
00007f0145bde054  push r9
00007f0145bde056  push r10
00007f0145bde058  push r11
00007f0145bde05a  sub rsp, 0xF0
00007f0145bde061  vmovaps [rsp], xmm0
00007f0145bde066  vmovaps [rsp+0x10], xmm1
00007f0145bde06c  vmovaps [rsp+0x20], xmm2
00007f0145bde072  vmovaps [rsp+0x30], xmm3
00007f0145bde078  vmovaps [rsp+0x40], xmm4
00007f0145bde07e  vmovaps [rsp+0x50], xmm5
00007f0145bde084  vmovaps [rsp+0x60], xmm6
00007f0145bde08a  vmovaps [rsp+0x70], xmm7
00007f0145bde090  vmovaps [rsp+0x80], xmm8
00007f0145bde099  vmovaps [rsp+0x90], xmm9
00007f0145bde0a2  vmovaps [rsp+0xA0], xmm10
00007f0145bde0ab  vmovaps [rsp+0xB0], xmm11
00007f0145bde0b4  vmovaps [rsp+0xC0], xmm12
00007f0145bde0bd  vmovaps [rsp+0xD0], xmm13
00007f0145bde0c6  vmovaps [rsp+0xE0], xmm14
00007f0145bde0cf  sub rsp, 0x30
00007f0145bde0d3  movaps [rsp], xmm15
00007f0145bde0d8  movaps [rsp+0x10], xmm5
00007f0145bde0dd  movaps [rsp+0x20], xmm3
00007f0145bde0e2  lea rdi, [rsp]
00007f0145bde0e6  mov esi, 0x00
00007f0145bde0eb  mov rax, 0x636570E98530
00007f0145bde0f5  call rax
00007f0145bde0f7  movaps xmm15, [rsp]
00007f0145bde0fc  add rsp, 0x30
00007f0145bde100  vmovaps xmm0, [rsp]
00007f0145bde105  vmovaps xmm1, [rsp+0x10]
00007f0145bde10b  vmovaps xmm2, [rsp+0x20]
00007f0145bde111  vmovaps xmm3, [rsp+0x30]
00007f0145bde117  vmovaps xmm4, [rsp+0x40]
00007f0145bde11d  vmovaps xmm5, [rsp+0x50]
00007f0145bde123  vmovaps xmm6, [rsp+0x60]
00007f0145bde129  vmovaps xmm7, [rsp+0x70]
00007f0145bde12f  vmovaps xmm8, [rsp+0x80]
00007f0145bde138  vmovaps xmm9, [rsp+0x90]
00007f0145bde141  vmovaps xmm10, [rsp+0xA0]
00007f0145bde14a  vmovaps xmm11, [rsp+0xB0]
00007f0145bde153  vmovaps xmm12, [rsp+0xC0]
00007f0145bde15c  vmovaps xmm13, [rsp+0xD0]
00007f0145bde165  vmovaps xmm14, [rsp+0xE0]
00007f0145bde16e  add rsp, 0xF0
00007f0145bde175  pop r11
00007f0145bde177  pop r10
00007f0145bde179  pop r9
00007f0145bde17b  pop r8
00007f0145bde17d  pop rsi
00007f0145bde17e  pop rdi
00007f0145bde17f  pop rdx
00007f0145bde180  pop rcx
00007f0145bde181  pop rax
00007f0145bde182  add rsp, 0x08
00007f0145bde186  jmp 0x00007F0145BDC099
00007f0145bde18b  sub rsp, 0x08
00007f0145bde18f  push rax
00007f0145bde190  push rcx
00007f0145bde191  push rdx
00007f0145bde192  push rdi
00007f0145bde193  push rsi
00007f0145bde194  push r8
00007f0145bde196  push r9
00007f0145bde198  push r10
00007f0145bde19a  push r11
00007f0145bde19c  sub rsp, 0xF0
00007f0145bde1a3  vmovaps [rsp], xmm0
00007f0145bde1a8  vmovaps [rsp+0x10], xmm2
00007f0145bde1ae  vmovaps [rsp+0x20], xmm3
00007f0145bde1b4  vmovaps [rsp+0x30], xmm4
00007f0145bde1ba  vmovaps [rsp+0x40], xmm5
00007f0145bde1c0  vmovaps [rsp+0x50], xmm6
00007f0145bde1c6  vmovaps [rsp+0x60], xmm7
00007f0145bde1cc  vmovaps [rsp+0x70], xmm8
00007f0145bde1d2  vmovaps [rsp+0x80], xmm9
00007f0145bde1db  vmovaps [rsp+0x90], xmm10
00007f0145bde1e4  vmovaps [rsp+0xA0], xmm11
00007f0145bde1ed  vmovaps [rsp+0xB0], xmm12
00007f0145bde1f6  vmovaps [rsp+0xC0], xmm13
00007f0145bde1ff  vmovaps [rsp+0xD0], xmm14
00007f0145bde208  vmovaps [rsp+0xE0], xmm15
00007f0145bde211  sub rsp, 0x30
00007f0145bde215  movaps [rsp], xmm1
00007f0145bde219  movaps [rsp+0x10], xmm5
00007f0145bde21e  movaps [rsp+0x20], xmm4
00007f0145bde223  lea rdi, [rsp]
00007f0145bde227  mov esi, 0x00
00007f0145bde22c  mov rax, 0x636570E98530
00007f0145bde236  call rax
00007f0145bde238  movaps xmm1, [rsp]
00007f0145bde23c  add rsp, 0x30
00007f0145bde240  vmovaps xmm0, [rsp]
00007f0145bde245  vmovaps xmm2, [rsp+0x10]
00007f0145bde24b  vmovaps xmm3, [rsp+0x20]
00007f0145bde251  vmovaps xmm4, [rsp+0x30]
00007f0145bde257  vmovaps xmm5, [rsp+0x40]
00007f0145bde25d  vmovaps xmm6, [rsp+0x50]
00007f0145bde263  vmovaps xmm7, [rsp+0x60]
00007f0145bde269  vmovaps xmm8, [rsp+0x70]
00007f0145bde26f  vmovaps xmm9, [rsp+0x80]
00007f0145bde278  vmovaps xmm10, [rsp+0x90]
00007f0145bde281  vmovaps xmm11, [rsp+0xA0]
00007f0145bde28a  vmovaps xmm12, [rsp+0xB0]
00007f0145bde293  vmovaps xmm13, [rsp+0xC0]
00007f0145bde29c  vmovaps xmm14, [rsp+0xD0]
00007f0145bde2a5  vmovaps xmm15, [rsp+0xE0]
00007f0145bde2ae  add rsp, 0xF0
00007f0145bde2b5  pop r11
00007f0145bde2b7  pop r10
00007f0145bde2b9  pop r9
00007f0145bde2bb  pop r8
00007f0145bde2bd  pop rsi
00007f0145bde2be  pop rdi
00007f0145bde2bf  pop rdx
00007f0145bde2c0  pop rcx
00007f0145bde2c1  pop rax
00007f0145bde2c2  add rsp, 0x08
00007f0145bde2c6  jmp 0x00007F0145BDC0B9
00007f0145bde2cb  sub rsp, 0x08
00007f0145bde2cf  push rax
00007f0145bde2d0  push rcx
00007f0145bde2d1  push rdx
00007f0145bde2d2  push rdi
00007f0145bde2d3  push rsi
00007f0145bde2d4  push r8
00007f0145bde2d6  push r9
00007f0145bde2d8  push r10
00007f0145bde2da  push r11
00007f0145bde2dc  sub rsp, 0xF0
00007f0145bde2e3  vmovaps [rsp], xmm0
00007f0145bde2e8  vmovaps [rsp+0x10], xmm1
00007f0145bde2ee  vmovaps [rsp+0x20], xmm2
00007f0145bde2f4  vmovaps [rsp+0x30], xmm3
00007f0145bde2fa  vmovaps [rsp+0x40], xmm5
00007f0145bde300  vmovaps [rsp+0x50], xmm6
00007f0145bde306  vmovaps [rsp+0x60], xmm7
00007f0145bde30c  vmovaps [rsp+0x70], xmm8
00007f0145bde312  vmovaps [rsp+0x80], xmm9
00007f0145bde31b  vmovaps [rsp+0x90], xmm10
00007f0145bde324  vmovaps [rsp+0xA0], xmm11
00007f0145bde32d  vmovaps [rsp+0xB0], xmm12
00007f0145bde336  vmovaps [rsp+0xC0], xmm13
00007f0145bde33f  vmovaps [rsp+0xD0], xmm14
00007f0145bde348  vmovaps [rsp+0xE0], xmm15
00007f0145bde351  sub rsp, 0x30
00007f0145bde355  movaps [rsp], xmm4
00007f0145bde359  movaps [rsp+0x10], xmm3
00007f0145bde35e  movaps [rsp+0x20], xmm5
00007f0145bde363  lea rdi, [rsp]
00007f0145bde367  mov esi, 0x00
00007f0145bde36c  mov rax, 0x636570E98530
00007f0145bde376  call rax
00007f0145bde378  movaps xmm4, [rsp]
00007f0145bde37c  add rsp, 0x30
00007f0145bde380  vmovaps xmm0, [rsp]
00007f0145bde385  vmovaps xmm1, [rsp+0x10]
00007f0145bde38b  vmovaps xmm2, [rsp+0x20]
00007f0145bde391  vmovaps xmm3, [rsp+0x30]
00007f0145bde397  vmovaps xmm5, [rsp+0x40]
00007f0145bde39d  vmovaps xmm6, [rsp+0x50]
00007f0145bde3a3  vmovaps xmm7, [rsp+0x60]
00007f0145bde3a9  vmovaps xmm8, [rsp+0x70]
00007f0145bde3af  vmovaps xmm9, [rsp+0x80]
00007f0145bde3b8  vmovaps xmm10, [rsp+0x90]
00007f0145bde3c1  vmovaps xmm11, [rsp+0xA0]
00007f0145bde3ca  vmovaps xmm12, [rsp+0xB0]
00007f0145bde3d3  vmovaps xmm13, [rsp+0xC0]
00007f0145bde3dc  vmovaps xmm14, [rsp+0xD0]
00007f0145bde3e5  vmovaps xmm15, [rsp+0xE0]
00007f0145bde3ee  add rsp, 0xF0
00007f0145bde3f5  pop r11
00007f0145bde3f7  pop r10
00007f0145bde3f9  pop r9
00007f0145bde3fb  pop r8
00007f0145bde3fd  pop rsi
00007f0145bde3fe  pop rdi
00007f0145bde3ff  pop rdx
00007f0145bde400  pop rcx
00007f0145bde401  pop rax
00007f0145bde402  add rsp, 0x08
00007f0145bde406  jmp 0x00007F0145BDC107
00007f0145bde40b  call 0x00007F0145AB52F0
00007f0145bde410  jmp 0x00007F0145BDC114
00007f0145bde415  sub rsp, 0x08
00007f0145bde419  push rax
00007f0145bde41a  push rcx
00007f0145bde41b  push rdx
00007f0145bde41c  push rdi
00007f0145bde41d  push rsi
00007f0145bde41e  push r8
00007f0145bde420  push r9
00007f0145bde422  push r10
00007f0145bde424  push r11
00007f0145bde426  sub rsp, 0xF0
00007f0145bde42d  vmovaps [rsp], xmm0
00007f0145bde432  vmovaps [rsp+0x10], xmm1
00007f0145bde438  vmovaps [rsp+0x20], xmm2
00007f0145bde43e  vmovaps [rsp+0x30], xmm3
00007f0145bde444  vmovaps [rsp+0x40], xmm4
00007f0145bde44a  vmovaps [rsp+0x50], xmm6
00007f0145bde450  vmovaps [rsp+0x60], xmm7
00007f0145bde456  vmovaps [rsp+0x70], xmm8
00007f0145bde45c  vmovaps [rsp+0x80], xmm9
00007f0145bde465  vmovaps [rsp+0x90], xmm10
00007f0145bde46e  vmovaps [rsp+0xA0], xmm11
00007f0145bde477  vmovaps [rsp+0xB0], xmm12
00007f0145bde480  vmovaps [rsp+0xC0], xmm13
00007f0145bde489  vmovaps [rsp+0xD0], xmm14
00007f0145bde492  vmovaps [rsp+0xE0], xmm15
00007f0145bde49b  sub rsp, 0x30
00007f0145bde49f  movaps [rsp], xmm5
00007f0145bde4a3  movaps [rsp+0x10], xmm6
00007f0145bde4a8  movaps [rsp+0x20], xmm3
00007f0145bde4ad  lea rdi, [rsp]
00007f0145bde4b1  mov esi, 0x00
00007f0145bde4b6  mov rax, 0x636570E98530
00007f0145bde4c0  call rax
00007f0145bde4c2  movaps xmm5, [rsp]
00007f0145bde4c6  add rsp, 0x30
00007f0145bde4ca  vmovaps xmm0, [rsp]
00007f0145bde4cf  vmovaps xmm1, [rsp+0x10]
00007f0145bde4d5  vmovaps xmm2, [rsp+0x20]
00007f0145bde4db  vmovaps xmm3, [rsp+0x30]
00007f0145bde4e1  vmovaps xmm4, [rsp+0x40]
00007f0145bde4e7  vmovaps xmm6, [rsp+0x50]
00007f0145bde4ed  vmovaps xmm7, [rsp+0x60]
00007f0145bde4f3  vmovaps xmm8, [rsp+0x70]
00007f0145bde4f9  vmovaps xmm9, [rsp+0x80]
00007f0145bde502  vmovaps xmm10, [rsp+0x90]
00007f0145bde50b  vmovaps xmm11, [rsp+0xA0]
00007f0145bde514  vmovaps xmm12, [rsp+0xB0]
00007f0145bde51d  vmovaps xmm13, [rsp+0xC0]
00007f0145bde526  vmovaps xmm14, [rsp+0xD0]
00007f0145bde52f  vmovaps xmm15, [rsp+0xE0]
00007f0145bde538  add rsp, 0xF0
00007f0145bde53f  pop r11
00007f0145bde541  pop r10
00007f0145bde543  pop r9
00007f0145bde545  pop r8
00007f0145bde547  pop rsi
00007f0145bde548  pop rdi
00007f0145bde549  pop rdx
00007f0145bde54a  pop rcx
00007f0145bde54b  pop rax
00007f0145bde54c  add rsp, 0x08
00007f0145bde550  jmp 0x00007F0145BDC13A
00007f0145bde555  sub rsp, 0x08
00007f0145bde559  push rax
00007f0145bde55a  push rcx
00007f0145bde55b  push rdx
00007f0145bde55c  push rdi
00007f0145bde55d  push rsi
00007f0145bde55e  push r8
00007f0145bde560  push r9
00007f0145bde562  push r10
00007f0145bde564  push r11
00007f0145bde566  sub rsp, 0xF0
00007f0145bde56d  vmovaps [rsp], xmm0
00007f0145bde572  vmovaps [rsp+0x10], xmm1
00007f0145bde578  vmovaps [rsp+0x20], xmm2
00007f0145bde57e  vmovaps [rsp+0x30], xmm3
00007f0145bde584  vmovaps [rsp+0x40], xmm4
00007f0145bde58a  vmovaps [rsp+0x50], xmm5
00007f0145bde590  vmovaps [rsp+0x60], xmm7
00007f0145bde596  vmovaps [rsp+0x70], xmm8
00007f0145bde59c  vmovaps [rsp+0x80], xmm9
00007f0145bde5a5  vmovaps [rsp+0x90], xmm10
00007f0145bde5ae  vmovaps [rsp+0xA0], xmm11
00007f0145bde5b7  vmovaps [rsp+0xB0], xmm12
00007f0145bde5c0  vmovaps [rsp+0xC0], xmm13
00007f0145bde5c9  vmovaps [rsp+0xD0], xmm14
00007f0145bde5d2  vmovaps [rsp+0xE0], xmm15
00007f0145bde5db  sub rsp, 0x30
00007f0145bde5df  movaps [rsp], xmm6
00007f0145bde5e3  movaps [rsp+0x10], xmm9
00007f0145bde5e9  movaps [rsp+0x20], xmm1
00007f0145bde5ee  lea rdi, [rsp]
00007f0145bde5f2  mov esi, 0x00
00007f0145bde5f7  mov rax, 0x636570E98530
00007f0145bde601  call rax
00007f0145bde603  movaps xmm6, [rsp]
00007f0145bde607  add rsp, 0x30
00007f0145bde60b  vmovaps xmm0, [rsp]
00007f0145bde610  vmovaps xmm1, [rsp+0x10]
00007f0145bde616  vmovaps xmm2, [rsp+0x20]
00007f0145bde61c  vmovaps xmm3, [rsp+0x30]
00007f0145bde622  vmovaps xmm4, [rsp+0x40]
00007f0145bde628  vmovaps xmm5, [rsp+0x50]
00007f0145bde62e  vmovaps xmm7, [rsp+0x60]
00007f0145bde634  vmovaps xmm8, [rsp+0x70]
00007f0145bde63a  vmovaps xmm9, [rsp+0x80]
00007f0145bde643  vmovaps xmm10, [rsp+0x90]
00007f0145bde64c  vmovaps xmm11, [rsp+0xA0]
00007f0145bde655  vmovaps xmm12, [rsp+0xB0]
00007f0145bde65e  vmovaps xmm13, [rsp+0xC0]
00007f0145bde667  vmovaps xmm14, [rsp+0xD0]
00007f0145bde670  vmovaps xmm15, [rsp+0xE0]
00007f0145bde679  add rsp, 0xF0
00007f0145bde680  pop r11
00007f0145bde682  pop r10
00007f0145bde684  pop r9
00007f0145bde686  pop r8
00007f0145bde688  pop rsi
00007f0145bde689  pop rdi
00007f0145bde68a  pop rdx
00007f0145bde68b  pop rcx
00007f0145bde68c  pop rax
00007f0145bde68d  add rsp, 0x08
00007f0145bde691  jmp 0x00007F0145BDC15E
00007f0145bde696  sub rsp, 0x08
00007f0145bde69a  push rax
00007f0145bde69b  push rcx
00007f0145bde69c  push rdx
00007f0145bde69d  push rdi
00007f0145bde69e  push rsi
00007f0145bde69f  push r8
00007f0145bde6a1  push r9
00007f0145bde6a3  push r10
00007f0145bde6a5  push r11
00007f0145bde6a7  sub rsp, 0xF0
00007f0145bde6ae  vmovaps [rsp], xmm0
00007f0145bde6b3  vmovaps [rsp+0x10], xmm1
00007f0145bde6b9  vmovaps [rsp+0x20], xmm2
00007f0145bde6bf  vmovaps [rsp+0x30], xmm3
00007f0145bde6c5  vmovaps [rsp+0x40], xmm4
00007f0145bde6cb  vmovaps [rsp+0x50], xmm5
00007f0145bde6d1  vmovaps [rsp+0x60], xmm6
00007f0145bde6d7  vmovaps [rsp+0x70], xmm7
00007f0145bde6dd  vmovaps [rsp+0x80], xmm8
00007f0145bde6e6  vmovaps [rsp+0x90], xmm10
00007f0145bde6ef  vmovaps [rsp+0xA0], xmm11
00007f0145bde6f8  vmovaps [rsp+0xB0], xmm12
00007f0145bde701  vmovaps [rsp+0xC0], xmm13
00007f0145bde70a  vmovaps [rsp+0xD0], xmm14
00007f0145bde713  vmovaps [rsp+0xE0], xmm15
00007f0145bde71c  sub rsp, 0x30
00007f0145bde720  movaps [rsp], xmm9
00007f0145bde725  movaps [rsp+0x10], xmm3
00007f0145bde72a  movaps [rsp+0x20], xmm1
00007f0145bde72f  lea rdi, [rsp]
00007f0145bde733  mov esi, 0x00
00007f0145bde738  mov rax, 0x636570E98530
00007f0145bde742  call rax
00007f0145bde744  movaps xmm9, [rsp]
00007f0145bde749  add rsp, 0x30
00007f0145bde74d  vmovaps xmm0, [rsp]
00007f0145bde752  vmovaps xmm1, [rsp+0x10]
00007f0145bde758  vmovaps xmm2, [rsp+0x20]
00007f0145bde75e  vmovaps xmm3, [rsp+0x30]
00007f0145bde764  vmovaps xmm4, [rsp+0x40]
00007f0145bde76a  vmovaps xmm5, [rsp+0x50]
00007f0145bde770  vmovaps xmm6, [rsp+0x60]
00007f0145bde776  vmovaps xmm7, [rsp+0x70]
00007f0145bde77c  vmovaps xmm8, [rsp+0x80]
00007f0145bde785  vmovaps xmm10, [rsp+0x90]
00007f0145bde78e  vmovaps xmm11, [rsp+0xA0]
00007f0145bde797  vmovaps xmm12, [rsp+0xB0]
00007f0145bde7a0  vmovaps xmm13, [rsp+0xC0]
00007f0145bde7a9  vmovaps xmm14, [rsp+0xD0]
00007f0145bde7b2  vmovaps xmm15, [rsp+0xE0]
00007f0145bde7bb  add rsp, 0xF0
00007f0145bde7c2  pop r11
00007f0145bde7c4  pop r10
00007f0145bde7c6  pop r9
00007f0145bde7c8  pop r8
00007f0145bde7ca  pop rsi
00007f0145bde7cb  pop rdi
00007f0145bde7cc  pop rdx
00007f0145bde7cd  pop rcx
00007f0145bde7ce  pop rax
00007f0145bde7cf  add rsp, 0x08
00007f0145bde7d3  jmp 0x00007F0145BDC1AA
00007f0145bde7d8  call 0x00007F0145AB52F0
00007f0145bde7dd  jmp 0x00007F0145BDC1B7
00007f0145bde7e2  sub rsp, 0x08
00007f0145bde7e6  push rax
00007f0145bde7e7  push rcx
00007f0145bde7e8  push rdx
00007f0145bde7e9  push rdi
00007f0145bde7ea  push rsi
00007f0145bde7eb  push r8
00007f0145bde7ed  push r9
00007f0145bde7ef  push r10
00007f0145bde7f1  push r11
00007f0145bde7f3  sub rsp, 0xF0
00007f0145bde7fa  vmovaps [rsp], xmm0
00007f0145bde7ff  vmovaps [rsp+0x10], xmm1
00007f0145bde805  vmovaps [rsp+0x20], xmm2
00007f0145bde80b  vmovaps [rsp+0x30], xmm3
00007f0145bde811  vmovaps [rsp+0x40], xmm4
00007f0145bde817  vmovaps [rsp+0x50], xmm5
00007f0145bde81d  vmovaps [rsp+0x60], xmm6
00007f0145bde823  vmovaps [rsp+0x70], xmm7
00007f0145bde829  vmovaps [rsp+0x80], xmm8
00007f0145bde832  vmovaps [rsp+0x90], xmm9
00007f0145bde83b  vmovaps [rsp+0xA0], xmm10
00007f0145bde844  vmovaps [rsp+0xB0], xmm11
00007f0145bde84d  vmovaps [rsp+0xC0], xmm12
00007f0145bde856  vmovaps [rsp+0xD0], xmm13
00007f0145bde85f  vmovaps [rsp+0xE0], xmm14
00007f0145bde868  sub rsp, 0x30
00007f0145bde86c  movaps [rsp], xmm15
00007f0145bde871  movaps [rsp+0x10], xmm3
00007f0145bde876  movaps [rsp+0x20], xmm7
00007f0145bde87b  lea rdi, [rsp]
00007f0145bde87f  mov esi, 0x00
00007f0145bde884  mov rax, 0x636570E98530
00007f0145bde88e  call rax
00007f0145bde890  movaps xmm15, [rsp]
00007f0145bde895  add rsp, 0x30
00007f0145bde899  vmovaps xmm0, [rsp]
00007f0145bde89e  vmovaps xmm1, [rsp+0x10]
00007f0145bde8a4  vmovaps xmm2, [rsp+0x20]
00007f0145bde8aa  vmovaps xmm3, [rsp+0x30]
00007f0145bde8b0  vmovaps xmm4, [rsp+0x40]
00007f0145bde8b6  vmovaps xmm5, [rsp+0x50]
00007f0145bde8bc  vmovaps xmm6, [rsp+0x60]
00007f0145bde8c2  vmovaps xmm7, [rsp+0x70]
00007f0145bde8c8  vmovaps xmm8, [rsp+0x80]
00007f0145bde8d1  vmovaps xmm9, [rsp+0x90]
00007f0145bde8da  vmovaps xmm10, [rsp+0xA0]
00007f0145bde8e3  vmovaps xmm11, [rsp+0xB0]
00007f0145bde8ec  vmovaps xmm12, [rsp+0xC0]
00007f0145bde8f5  vmovaps xmm13, [rsp+0xD0]
00007f0145bde8fe  vmovaps xmm14, [rsp+0xE0]
00007f0145bde907  add rsp, 0xF0
00007f0145bde90e  pop r11
00007f0145bde910  pop r10
00007f0145bde912  pop r9
00007f0145bde914  pop r8
00007f0145bde916  pop rsi
00007f0145bde917  pop rdi
00007f0145bde918  pop rdx
00007f0145bde919  pop rcx
00007f0145bde91a  pop rax
00007f0145bde91b  add rsp, 0x08
00007f0145bde91f  jmp 0x00007F0145BDC1E3
00007f0145bde924  sub rsp, 0x08
00007f0145bde928  push rax
00007f0145bde929  push rcx
00007f0145bde92a  push rdx
00007f0145bde92b  push rdi
00007f0145bde92c  push rsi
00007f0145bde92d  push r8
00007f0145bde92f  push r9
00007f0145bde931  push r10
00007f0145bde933  push r11
00007f0145bde935  sub rsp, 0xF0
00007f0145bde93c  vmovaps [rsp], xmm0
00007f0145bde941  vmovaps [rsp+0x10], xmm1
00007f0145bde947  vmovaps [rsp+0x20], xmm2
00007f0145bde94d  vmovaps [rsp+0x30], xmm4
00007f0145bde953  vmovaps [rsp+0x40], xmm5
00007f0145bde959  vmovaps [rsp+0x50], xmm6
00007f0145bde95f  vmovaps [rsp+0x60], xmm7
00007f0145bde965  vmovaps [rsp+0x70], xmm8
00007f0145bde96b  vmovaps [rsp+0x80], xmm9
00007f0145bde974  vmovaps [rsp+0x90], xmm10
00007f0145bde97d  vmovaps [rsp+0xA0], xmm11
00007f0145bde986  vmovaps [rsp+0xB0], xmm12
00007f0145bde98f  vmovaps [rsp+0xC0], xmm13
00007f0145bde998  vmovaps [rsp+0xD0], xmm14
00007f0145bde9a1  vmovaps [rsp+0xE0], xmm15
00007f0145bde9aa  sub rsp, 0x30
00007f0145bde9ae  movaps [rsp], xmm3
00007f0145bde9b2  movaps [rsp+0x10], xmm1
00007f0145bde9b7  movaps [rsp+0x20], xmm15
00007f0145bde9bd  lea rdi, [rsp]
00007f0145bde9c1  mov esi, 0x00
00007f0145bde9c6  mov rax, 0x636570E98530
00007f0145bde9d0  call rax
00007f0145bde9d2  movaps xmm3, [rsp]
00007f0145bde9d6  add rsp, 0x30
00007f0145bde9da  vmovaps xmm0, [rsp]
00007f0145bde9df  vmovaps xmm1, [rsp+0x10]
00007f0145bde9e5  vmovaps xmm2, [rsp+0x20]
00007f0145bde9eb  vmovaps xmm4, [rsp+0x30]
00007f0145bde9f1  vmovaps xmm5, [rsp+0x40]
00007f0145bde9f7  vmovaps xmm6, [rsp+0x50]
00007f0145bde9fd  vmovaps xmm7, [rsp+0x60]
00007f0145bdea03  vmovaps xmm8, [rsp+0x70]
00007f0145bdea09  vmovaps xmm9, [rsp+0x80]
00007f0145bdea12  vmovaps xmm10, [rsp+0x90]
00007f0145bdea1b  vmovaps xmm11, [rsp+0xA0]
00007f0145bdea24  vmovaps xmm12, [rsp+0xB0]
00007f0145bdea2d  vmovaps xmm13, [rsp+0xC0]
00007f0145bdea36  vmovaps xmm14, [rsp+0xD0]
00007f0145bdea3f  vmovaps xmm15, [rsp+0xE0]
00007f0145bdea48  add rsp, 0xF0
00007f0145bdea4f  pop r11
00007f0145bdea51  pop r10
00007f0145bdea53  pop r9
00007f0145bdea55  pop r8
00007f0145bdea57  pop rsi
00007f0145bdea58  pop rdi
00007f0145bdea59  pop rdx
00007f0145bdea5a  pop rcx
00007f0145bdea5b  pop rax
00007f0145bdea5c  add rsp, 0x08
00007f0145bdea60  jmp 0x00007F0145BDC272
00007f0145bdea65  call 0x00007F0145AB52F0
00007f0145bdea6a  jmp 0x00007F0145BDC27C
00007f0145bdea6f  sub rsp, 0x08
00007f0145bdea73  push rax
00007f0145bdea74  push rcx
00007f0145bdea75  push rdx
00007f0145bdea76  push rdi
00007f0145bdea77  push rsi
00007f0145bdea78  push r8
00007f0145bdea7a  push r9
00007f0145bdea7c  push r10
00007f0145bdea7e  push r11
00007f0145bdea80  sub rsp, 0xF0
00007f0145bdea87  vmovaps [rsp], xmm0
00007f0145bdea8c  vmovaps [rsp+0x10], xmm1
00007f0145bdea92  vmovaps [rsp+0x20], xmm2
00007f0145bdea98  vmovaps [rsp+0x30], xmm3
00007f0145bdea9e  vmovaps [rsp+0x40], xmm4
00007f0145bdeaa4  vmovaps [rsp+0x50], xmm5
00007f0145bdeaaa  vmovaps [rsp+0x60], xmm6
00007f0145bdeab0  vmovaps [rsp+0x70], xmm7
00007f0145bdeab6  vmovaps [rsp+0x80], xmm8
00007f0145bdeabf  vmovaps [rsp+0x90], xmm9
00007f0145bdeac8  vmovaps [rsp+0xA0], xmm10
00007f0145bdead1  vmovaps [rsp+0xB0], xmm11
00007f0145bdeada  vmovaps [rsp+0xC0], xmm12
00007f0145bdeae3  vmovaps [rsp+0xD0], xmm13
00007f0145bdeaec  vmovaps [rsp+0xE0], xmm14
00007f0145bdeaf5  sub rsp, 0x30
00007f0145bdeaf9  movaps [rsp], xmm15
00007f0145bdeafe  movaps [rsp+0x10], xmm14
00007f0145bdeb04  movaps [rsp+0x20], xmm4
00007f0145bdeb09  lea rdi, [rsp]
00007f0145bdeb0d  mov esi, 0x00
00007f0145bdeb12  mov rax, 0x636570E98530
00007f0145bdeb1c  call rax
00007f0145bdeb1e  movaps xmm15, [rsp]
00007f0145bdeb23  add rsp, 0x30
00007f0145bdeb27  vmovaps xmm0, [rsp]
00007f0145bdeb2c  vmovaps xmm1, [rsp+0x10]
00007f0145bdeb32  vmovaps xmm2, [rsp+0x20]
00007f0145bdeb38  vmovaps xmm3, [rsp+0x30]
00007f0145bdeb3e  vmovaps xmm4, [rsp+0x40]
00007f0145bdeb44  vmovaps xmm5, [rsp+0x50]
00007f0145bdeb4a  vmovaps xmm6, [rsp+0x60]
00007f0145bdeb50  vmovaps xmm7, [rsp+0x70]
00007f0145bdeb56  vmovaps xmm8, [rsp+0x80]
00007f0145bdeb5f  vmovaps xmm9, [rsp+0x90]
00007f0145bdeb68  vmovaps xmm10, [rsp+0xA0]
00007f0145bdeb71  vmovaps xmm11, [rsp+0xB0]
00007f0145bdeb7a  vmovaps xmm12, [rsp+0xC0]
00007f0145bdeb83  vmovaps xmm13, [rsp+0xD0]
00007f0145bdeb8c  vmovaps xmm14, [rsp+0xE0]
00007f0145bdeb95  add rsp, 0xF0
00007f0145bdeb9c  pop r11
00007f0145bdeb9e  pop r10
00007f0145bdeba0  pop r9
00007f0145bdeba2  pop r8
00007f0145bdeba4  pop rsi
00007f0145bdeba5  pop rdi
00007f0145bdeba6  pop rdx
00007f0145bdeba7  pop rcx
00007f0145bdeba8  pop rax
00007f0145bdeba9  add rsp, 0x08
00007f0145bdebad  jmp 0x00007F0145BDC2AA
00007f0145bdebb2  sub rsp, 0x08
00007f0145bdebb6  push rax
00007f0145bdebb7  push rcx
00007f0145bdebb8  push rdx
00007f0145bdebb9  push rdi
00007f0145bdebba  push rsi
00007f0145bdebbb  push r8
00007f0145bdebbd  push r9
00007f0145bdebbf  push r10
00007f0145bdebc1  push r11
00007f0145bdebc3  sub rsp, 0xF0
00007f0145bdebca  vmovaps [rsp], xmm0
00007f0145bdebcf  vmovaps [rsp+0x10], xmm1
00007f0145bdebd5  vmovaps [rsp+0x20], xmm2
00007f0145bdebdb  vmovaps [rsp+0x30], xmm3
00007f0145bdebe1  vmovaps [rsp+0x40], xmm4
00007f0145bdebe7  vmovaps [rsp+0x50], xmm5
00007f0145bdebed  vmovaps [rsp+0x60], xmm6
00007f0145bdebf3  vmovaps [rsp+0x70], xmm7
00007f0145bdebf9  vmovaps [rsp+0x80], xmm8
00007f0145bdec02  vmovaps [rsp+0x90], xmm9
00007f0145bdec0b  vmovaps [rsp+0xA0], xmm10
00007f0145bdec14  vmovaps [rsp+0xB0], xmm11
00007f0145bdec1d  vmovaps [rsp+0xC0], xmm12
00007f0145bdec26  vmovaps [rsp+0xD0], xmm13
00007f0145bdec2f  vmovaps [rsp+0xE0], xmm15
00007f0145bdec38  sub rsp, 0x30
00007f0145bdec3c  movaps [rsp], xmm14
00007f0145bdec41  movaps [rsp+0x10], xmm2
00007f0145bdec46  movaps [rsp+0x20], xmm1
00007f0145bdec4b  lea rdi, [rsp]
00007f0145bdec4f  mov esi, 0x00
00007f0145bdec54  mov rax, 0x636570E98530
00007f0145bdec5e  call rax
00007f0145bdec60  movaps xmm14, [rsp]
00007f0145bdec65  add rsp, 0x30
00007f0145bdec69  vmovaps xmm0, [rsp]
00007f0145bdec6e  vmovaps xmm1, [rsp+0x10]
00007f0145bdec74  vmovaps xmm2, [rsp+0x20]
00007f0145bdec7a  vmovaps xmm3, [rsp+0x30]
00007f0145bdec80  vmovaps xmm4, [rsp+0x40]
00007f0145bdec86  vmovaps xmm5, [rsp+0x50]
00007f0145bdec8c  vmovaps xmm6, [rsp+0x60]
00007f0145bdec92  vmovaps xmm7, [rsp+0x70]
00007f0145bdec98  vmovaps xmm8, [rsp+0x80]
00007f0145bdeca1  vmovaps xmm9, [rsp+0x90]
00007f0145bdecaa  vmovaps xmm10, [rsp+0xA0]
00007f0145bdecb3  vmovaps xmm11, [rsp+0xB0]
00007f0145bdecbc  vmovaps xmm12, [rsp+0xC0]
00007f0145bdecc5  vmovaps xmm13, [rsp+0xD0]
00007f0145bdecce  vmovaps xmm15, [rsp+0xE0]
00007f0145bdecd7  add rsp, 0xF0
00007f0145bdecde  pop r11
00007f0145bdece0  pop r10
00007f0145bdece2  pop r9
00007f0145bdece4  pop r8
00007f0145bdece6  pop rsi
00007f0145bdece7  pop rdi
00007f0145bdece8  pop rdx
00007f0145bdece9  pop rcx
00007f0145bdecea  pop rax
00007f0145bdeceb  add rsp, 0x08
00007f0145bdecef  jmp 0x00007F0145BDC2D0
00007f0145bdecf4  sub rsp, 0x08
00007f0145bdecf8  push rax
00007f0145bdecf9  push rcx
00007f0145bdecfa  push rdx
00007f0145bdecfb  push rdi
00007f0145bdecfc  push rsi
00007f0145bdecfd  push r8
00007f0145bdecff  push r9
00007f0145bded01  push r10
00007f0145bded03  push r11
00007f0145bded05  sub rsp, 0xF0
00007f0145bded0c  vmovaps [rsp], xmm0
00007f0145bded11  vmovaps [rsp+0x10], xmm2
00007f0145bded17  vmovaps [rsp+0x20], xmm3
00007f0145bded1d  vmovaps [rsp+0x30], xmm4
00007f0145bded23  vmovaps [rsp+0x40], xmm5
00007f0145bded29  vmovaps [rsp+0x50], xmm6
00007f0145bded2f  vmovaps [rsp+0x60], xmm7
00007f0145bded35  vmovaps [rsp+0x70], xmm8
00007f0145bded3b  vmovaps [rsp+0x80], xmm9
00007f0145bded44  vmovaps [rsp+0x90], xmm10
00007f0145bded4d  vmovaps [rsp+0xA0], xmm11
00007f0145bded56  vmovaps [rsp+0xB0], xmm12
00007f0145bded5f  vmovaps [rsp+0xC0], xmm13
00007f0145bded68  vmovaps [rsp+0xD0], xmm14
00007f0145bded71  vmovaps [rsp+0xE0], xmm15
00007f0145bded7a  sub rsp, 0x30
00007f0145bded7e  movaps [rsp], xmm1
00007f0145bded82  movaps [rsp+0x10], xmm4
00007f0145bded87  movaps [rsp+0x20], xmm9
00007f0145bded8d  lea rdi, [rsp]
00007f0145bded91  mov esi, 0x00
00007f0145bded96  mov rax, 0x636570E98530
00007f0145bdeda0  call rax
00007f0145bdeda2  movaps xmm1, [rsp]
00007f0145bdeda6  add rsp, 0x30
00007f0145bdedaa  vmovaps xmm0, [rsp]
00007f0145bdedaf  vmovaps xmm2, [rsp+0x10]
00007f0145bdedb5  vmovaps xmm3, [rsp+0x20]
00007f0145bdedbb  vmovaps xmm4, [rsp+0x30]
00007f0145bdedc1  vmovaps xmm5, [rsp+0x40]
00007f0145bdedc7  vmovaps xmm6, [rsp+0x50]
00007f0145bdedcd  vmovaps xmm7, [rsp+0x60]
00007f0145bdedd3  vmovaps xmm8, [rsp+0x70]
00007f0145bdedd9  vmovaps xmm9, [rsp+0x80]
00007f0145bdede2  vmovaps xmm10, [rsp+0x90]
00007f0145bdedeb  vmovaps xmm11, [rsp+0xA0]
00007f0145bdedf4  vmovaps xmm12, [rsp+0xB0]
00007f0145bdedfd  vmovaps xmm13, [rsp+0xC0]
00007f0145bdee06  vmovaps xmm14, [rsp+0xD0]
00007f0145bdee0f  vmovaps xmm15, [rsp+0xE0]
00007f0145bdee18  add rsp, 0xF0
00007f0145bdee1f  pop r11
00007f0145bdee21  pop r10
00007f0145bdee23  pop r9
00007f0145bdee25  pop r8
00007f0145bdee27  pop rsi
00007f0145bdee28  pop rdi
00007f0145bdee29  pop rdx
00007f0145bdee2a  pop rcx
00007f0145bdee2b  pop rax
00007f0145bdee2c  add rsp, 0x08
00007f0145bdee30  jmp 0x00007F0145BDC2EE
00007f0145bdee35  sub rsp, 0x08
00007f0145bdee39  push rax
00007f0145bdee3a  push rcx
00007f0145bdee3b  push rdx
00007f0145bdee3c  push rdi
00007f0145bdee3d  push rsi
00007f0145bdee3e  push r8
00007f0145bdee40  push r9
00007f0145bdee42  push r10
00007f0145bdee44  push r11
00007f0145bdee46  sub rsp, 0xF0
00007f0145bdee4d  vmovaps [rsp], xmm0
00007f0145bdee52  vmovaps [rsp+0x10], xmm1
00007f0145bdee58  vmovaps [rsp+0x20], xmm2
00007f0145bdee5e  vmovaps [rsp+0x30], xmm3
00007f0145bdee64  vmovaps [rsp+0x40], xmm5
00007f0145bdee6a  vmovaps [rsp+0x50], xmm6
00007f0145bdee70  vmovaps [rsp+0x60], xmm7
00007f0145bdee76  vmovaps [rsp+0x70], xmm8
00007f0145bdee7c  vmovaps [rsp+0x80], xmm9
00007f0145bdee85  vmovaps [rsp+0x90], xmm10
00007f0145bdee8e  vmovaps [rsp+0xA0], xmm11
00007f0145bdee97  vmovaps [rsp+0xB0], xmm12
00007f0145bdeea0  vmovaps [rsp+0xC0], xmm13
00007f0145bdeea9  vmovaps [rsp+0xD0], xmm14
00007f0145bdeeb2  vmovaps [rsp+0xE0], xmm15
00007f0145bdeebb  sub rsp, 0x30
00007f0145bdeebf  movaps [rsp], xmm4
00007f0145bdeec3  movaps [rsp+0x10], xmm2
00007f0145bdeec8  movaps [rsp+0x20], xmm9
00007f0145bdeece  lea rdi, [rsp]
00007f0145bdeed2  mov esi, 0x00
00007f0145bdeed7  mov rax, 0x636570E98530
00007f0145bdeee1  call rax
00007f0145bdeee3  movaps xmm4, [rsp]
00007f0145bdeee7  add rsp, 0x30
00007f0145bdeeeb  vmovaps xmm0, [rsp]
00007f0145bdeef0  vmovaps xmm1, [rsp+0x10]
00007f0145bdeef6  vmovaps xmm2, [rsp+0x20]
00007f0145bdeefc  vmovaps xmm3, [rsp+0x30]
00007f0145bdef02  vmovaps xmm5, [rsp+0x40]
00007f0145bdef08  vmovaps xmm6, [rsp+0x50]
00007f0145bdef0e  vmovaps xmm7, [rsp+0x60]
00007f0145bdef14  vmovaps xmm8, [rsp+0x70]
00007f0145bdef1a  vmovaps xmm9, [rsp+0x80]
00007f0145bdef23  vmovaps xmm10, [rsp+0x90]
00007f0145bdef2c  vmovaps xmm11, [rsp+0xA0]
00007f0145bdef35  vmovaps xmm12, [rsp+0xB0]
00007f0145bdef3e  vmovaps xmm13, [rsp+0xC0]
00007f0145bdef47  vmovaps xmm14, [rsp+0xD0]
00007f0145bdef50  vmovaps xmm15, [rsp+0xE0]
00007f0145bdef59  add rsp, 0xF0
00007f0145bdef60  pop r11
00007f0145bdef62  pop r10
00007f0145bdef64  pop r9
00007f0145bdef66  pop r8
00007f0145bdef68  pop rsi
00007f0145bdef69  pop rdi
00007f0145bdef6a  pop rdx
00007f0145bdef6b  pop rcx
00007f0145bdef6c  pop rax
00007f0145bdef6d  add rsp, 0x08
00007f0145bdef71  jmp 0x00007F0145BDC31E
00007f0145bdef76  sub rsp, 0x08
00007f0145bdef7a  push rax
00007f0145bdef7b  push rcx
00007f0145bdef7c  push rdx
00007f0145bdef7d  push rdi
00007f0145bdef7e  push rsi
00007f0145bdef7f  push r8
00007f0145bdef81  push r9
00007f0145bdef83  push r10
00007f0145bdef85  push r11
00007f0145bdef87  sub rsp, 0xF0
00007f0145bdef8e  vmovaps [rsp], xmm0
00007f0145bdef93  vmovaps [rsp+0x10], xmm1
00007f0145bdef99  vmovaps [rsp+0x20], xmm2
00007f0145bdef9f  vmovaps [rsp+0x30], xmm3
00007f0145bdefa5  vmovaps [rsp+0x40], xmm4
00007f0145bdefab  vmovaps [rsp+0x50], xmm5
00007f0145bdefb1  vmovaps [rsp+0x60], xmm6
00007f0145bdefb7  vmovaps [rsp+0x70], xmm7
00007f0145bdefbd  vmovaps [rsp+0x80], xmm8
00007f0145bdefc6  vmovaps [rsp+0x90], xmm10
00007f0145bdefcf  vmovaps [rsp+0xA0], xmm11
00007f0145bdefd8  vmovaps [rsp+0xB0], xmm12
00007f0145bdefe1  vmovaps [rsp+0xC0], xmm13
00007f0145bdefea  vmovaps [rsp+0xD0], xmm14
00007f0145bdeff3  vmovaps [rsp+0xE0], xmm15
00007f0145bdeffc  sub rsp, 0x30
00007f0145bdf000  movaps [rsp], xmm9
00007f0145bdf005  movaps [rsp+0x10], xmm2
00007f0145bdf00a  movaps [rsp+0x20], xmm1
00007f0145bdf00f  lea rdi, [rsp]
00007f0145bdf013  mov esi, 0x00
00007f0145bdf018  mov rax, 0x636570E98530
00007f0145bdf022  call rax
00007f0145bdf024  movaps xmm9, [rsp]
00007f0145bdf029  add rsp, 0x30
00007f0145bdf02d  vmovaps xmm0, [rsp]
00007f0145bdf032  vmovaps xmm1, [rsp+0x10]
00007f0145bdf038  vmovaps xmm2, [rsp+0x20]
00007f0145bdf03e  vmovaps xmm3, [rsp+0x30]
00007f0145bdf044  vmovaps xmm4, [rsp+0x40]
00007f0145bdf04a  vmovaps xmm5, [rsp+0x50]
00007f0145bdf050  vmovaps xmm6, [rsp+0x60]
00007f0145bdf056  vmovaps xmm7, [rsp+0x70]
00007f0145bdf05c  vmovaps xmm8, [rsp+0x80]
00007f0145bdf065  vmovaps xmm10, [rsp+0x90]
00007f0145bdf06e  vmovaps xmm11, [rsp+0xA0]
00007f0145bdf077  vmovaps xmm12, [rsp+0xB0]
00007f0145bdf080  vmovaps xmm13, [rsp+0xC0]
00007f0145bdf089  vmovaps xmm14, [rsp+0xD0]
00007f0145bdf092  vmovaps xmm15, [rsp+0xE0]
00007f0145bdf09b  add rsp, 0xF0
00007f0145bdf0a2  pop r11
00007f0145bdf0a4  pop r10
00007f0145bdf0a6  pop r9
00007f0145bdf0a8  pop r8
00007f0145bdf0aa  pop rsi
00007f0145bdf0ab  pop rdi
00007f0145bdf0ac  pop rdx
00007f0145bdf0ad  pop rcx
00007f0145bdf0ae  pop rax
00007f0145bdf0af  add rsp, 0x08
00007f0145bdf0b3  jmp 0x00007F0145BDC354
00007f0145bdf0b8  sub rsp, 0x08
00007f0145bdf0bc  push rax
00007f0145bdf0bd  push rcx
00007f0145bdf0be  push rdx
00007f0145bdf0bf  push rdi
00007f0145bdf0c0  push rsi
00007f0145bdf0c1  push r8
00007f0145bdf0c3  push r9
00007f0145bdf0c5  push r10
00007f0145bdf0c7  push r11
00007f0145bdf0c9  sub rsp, 0xF0
00007f0145bdf0d0  vmovaps [rsp], xmm0
00007f0145bdf0d5  vmovaps [rsp+0x10], xmm2
00007f0145bdf0db  vmovaps [rsp+0x20], xmm3
00007f0145bdf0e1  vmovaps [rsp+0x30], xmm4
00007f0145bdf0e7  vmovaps [rsp+0x40], xmm5
00007f0145bdf0ed  vmovaps [rsp+0x50], xmm6
00007f0145bdf0f3  vmovaps [rsp+0x60], xmm7
00007f0145bdf0f9  vmovaps [rsp+0x70], xmm8
00007f0145bdf0ff  vmovaps [rsp+0x80], xmm9
00007f0145bdf108  vmovaps [rsp+0x90], xmm10
00007f0145bdf111  vmovaps [rsp+0xA0], xmm11
00007f0145bdf11a  vmovaps [rsp+0xB0], xmm12
00007f0145bdf123  vmovaps [rsp+0xC0], xmm13
00007f0145bdf12c  vmovaps [rsp+0xD0], xmm14
00007f0145bdf135  vmovaps [rsp+0xE0], xmm15
00007f0145bdf13e  sub rsp, 0x30
00007f0145bdf142  movaps [rsp], xmm1
00007f0145bdf146  movaps [rsp+0x10], xmm15
00007f0145bdf14c  movaps [rsp+0x20], xmm6
00007f0145bdf151  lea rdi, [rsp]
00007f0145bdf155  mov esi, 0x00
00007f0145bdf15a  mov rax, 0x636570E98530
00007f0145bdf164  call rax
00007f0145bdf166  movaps xmm1, [rsp]
00007f0145bdf16a  add rsp, 0x30
00007f0145bdf16e  vmovaps xmm0, [rsp]
00007f0145bdf173  vmovaps xmm2, [rsp+0x10]
00007f0145bdf179  vmovaps xmm3, [rsp+0x20]
00007f0145bdf17f  vmovaps xmm4, [rsp+0x30]
00007f0145bdf185  vmovaps xmm5, [rsp+0x40]
00007f0145bdf18b  vmovaps xmm6, [rsp+0x50]
00007f0145bdf191  vmovaps xmm7, [rsp+0x60]
00007f0145bdf197  vmovaps xmm8, [rsp+0x70]
00007f0145bdf19d  vmovaps xmm9, [rsp+0x80]
00007f0145bdf1a6  vmovaps xmm10, [rsp+0x90]
00007f0145bdf1af  vmovaps xmm11, [rsp+0xA0]
00007f0145bdf1b8  vmovaps xmm12, [rsp+0xB0]
00007f0145bdf1c1  vmovaps xmm13, [rsp+0xC0]
00007f0145bdf1ca  vmovaps xmm14, [rsp+0xD0]
00007f0145bdf1d3  vmovaps xmm15, [rsp+0xE0]
00007f0145bdf1dc  add rsp, 0xF0
00007f0145bdf1e3  pop r11
00007f0145bdf1e5  pop r10
00007f0145bdf1e7  pop r9
00007f0145bdf1e9  pop r8
00007f0145bdf1eb  pop rsi
00007f0145bdf1ec  pop rdi
00007f0145bdf1ed  pop rdx
00007f0145bdf1ee  pop rcx
00007f0145bdf1ef  pop rax
00007f0145bdf1f0  add rsp, 0x08
00007f0145bdf1f4  jmp 0x00007F0145BDC375
00007f0145bdf1f9  sub rsp, 0x08
00007f0145bdf1fd  push rax
00007f0145bdf1fe  push rcx
00007f0145bdf1ff  push rdx
00007f0145bdf200  push rdi
00007f0145bdf201  push rsi
00007f0145bdf202  push r8
00007f0145bdf204  push r9
00007f0145bdf206  push r10
00007f0145bdf208  push r11
00007f0145bdf20a  sub rsp, 0xF0
00007f0145bdf211  vmovaps [rsp], xmm0
00007f0145bdf216  vmovaps [rsp+0x10], xmm1
00007f0145bdf21c  vmovaps [rsp+0x20], xmm2
00007f0145bdf222  vmovaps [rsp+0x30], xmm3
00007f0145bdf228  vmovaps [rsp+0x40], xmm4
00007f0145bdf22e  vmovaps [rsp+0x50], xmm5
00007f0145bdf234  vmovaps [rsp+0x60], xmm6
00007f0145bdf23a  vmovaps [rsp+0x70], xmm7
00007f0145bdf240  vmovaps [rsp+0x80], xmm8
00007f0145bdf249  vmovaps [rsp+0x90], xmm9
00007f0145bdf252  vmovaps [rsp+0xA0], xmm10
00007f0145bdf25b  vmovaps [rsp+0xB0], xmm11
00007f0145bdf264  vmovaps [rsp+0xC0], xmm12
00007f0145bdf26d  vmovaps [rsp+0xD0], xmm13
00007f0145bdf276  vmovaps [rsp+0xE0], xmm14
00007f0145bdf27f  sub rsp, 0x30
00007f0145bdf283  movaps [rsp], xmm15
00007f0145bdf288  movaps [rsp+0x10], xmm5
00007f0145bdf28d  movaps [rsp+0x20], xmm3
00007f0145bdf292  lea rdi, [rsp]
00007f0145bdf296  mov esi, 0x00
00007f0145bdf29b  mov rax, 0x636570E98530
00007f0145bdf2a5  call rax
00007f0145bdf2a7  movaps xmm15, [rsp]
00007f0145bdf2ac  add rsp, 0x30
00007f0145bdf2b0  vmovaps xmm0, [rsp]
00007f0145bdf2b5  vmovaps xmm1, [rsp+0x10]
00007f0145bdf2bb  vmovaps xmm2, [rsp+0x20]
00007f0145bdf2c1  vmovaps xmm3, [rsp+0x30]
00007f0145bdf2c7  vmovaps xmm4, [rsp+0x40]
00007f0145bdf2cd  vmovaps xmm5, [rsp+0x50]
00007f0145bdf2d3  vmovaps xmm6, [rsp+0x60]
00007f0145bdf2d9  vmovaps xmm7, [rsp+0x70]
00007f0145bdf2df  vmovaps xmm8, [rsp+0x80]
00007f0145bdf2e8  vmovaps xmm9, [rsp+0x90]
00007f0145bdf2f1  vmovaps xmm10, [rsp+0xA0]
00007f0145bdf2fa  vmovaps xmm11, [rsp+0xB0]
00007f0145bdf303  vmovaps xmm12, [rsp+0xC0]
00007f0145bdf30c  vmovaps xmm13, [rsp+0xD0]
00007f0145bdf315  vmovaps xmm14, [rsp+0xE0]
00007f0145bdf31e  add rsp, 0xF0
00007f0145bdf325  pop r11
00007f0145bdf327  pop r10
00007f0145bdf329  pop r9
00007f0145bdf32b  pop r8
00007f0145bdf32d  pop rsi
00007f0145bdf32e  pop rdi
00007f0145bdf32f  pop rdx
00007f0145bdf330  pop rcx
00007f0145bdf331  pop rax
00007f0145bdf332  add rsp, 0x08
00007f0145bdf336  jmp 0x00007F0145BDC38F
00007f0145bdf33b  sub rsp, 0x08
00007f0145bdf33f  push rax
00007f0145bdf340  push rcx
00007f0145bdf341  push rdx
00007f0145bdf342  push rdi
00007f0145bdf343  push rsi
00007f0145bdf344  push r8
00007f0145bdf346  push r9
00007f0145bdf348  push r10
00007f0145bdf34a  push r11
00007f0145bdf34c  sub rsp, 0xF0
00007f0145bdf353  vmovaps [rsp], xmm0
00007f0145bdf358  vmovaps [rsp+0x10], xmm1
00007f0145bdf35e  vmovaps [rsp+0x20], xmm2
00007f0145bdf364  vmovaps [rsp+0x30], xmm3
00007f0145bdf36a  vmovaps [rsp+0x40], xmm4
00007f0145bdf370  vmovaps [rsp+0x50], xmm6
00007f0145bdf376  vmovaps [rsp+0x60], xmm7
00007f0145bdf37c  vmovaps [rsp+0x70], xmm8
00007f0145bdf382  vmovaps [rsp+0x80], xmm9
00007f0145bdf38b  vmovaps [rsp+0x90], xmm10
00007f0145bdf394  vmovaps [rsp+0xA0], xmm11
00007f0145bdf39d  vmovaps [rsp+0xB0], xmm12
00007f0145bdf3a6  vmovaps [rsp+0xC0], xmm13
00007f0145bdf3af  vmovaps [rsp+0xD0], xmm14
00007f0145bdf3b8  vmovaps [rsp+0xE0], xmm15
00007f0145bdf3c1  sub rsp, 0x30
00007f0145bdf3c5  movaps [rsp], xmm5
00007f0145bdf3c9  movaps [rsp+0x10], xmm8
00007f0145bdf3cf  movaps [rsp+0x20], xmm6
00007f0145bdf3d4  lea rdi, [rsp]
00007f0145bdf3d8  mov esi, 0x00
00007f0145bdf3dd  mov rax, 0x636570E98530
00007f0145bdf3e7  call rax
00007f0145bdf3e9  movaps xmm5, [rsp]
00007f0145bdf3ed  add rsp, 0x30
00007f0145bdf3f1  vmovaps xmm0, [rsp]
00007f0145bdf3f6  vmovaps xmm1, [rsp+0x10]
00007f0145bdf3fc  vmovaps xmm2, [rsp+0x20]
00007f0145bdf402  vmovaps xmm3, [rsp+0x30]
00007f0145bdf408  vmovaps xmm4, [rsp+0x40]
00007f0145bdf40e  vmovaps xmm6, [rsp+0x50]
00007f0145bdf414  vmovaps xmm7, [rsp+0x60]
00007f0145bdf41a  vmovaps xmm8, [rsp+0x70]
00007f0145bdf420  vmovaps xmm9, [rsp+0x80]
00007f0145bdf429  vmovaps xmm10, [rsp+0x90]
00007f0145bdf432  vmovaps xmm11, [rsp+0xA0]
00007f0145bdf43b  vmovaps xmm12, [rsp+0xB0]
00007f0145bdf444  vmovaps xmm13, [rsp+0xC0]
00007f0145bdf44d  vmovaps xmm14, [rsp+0xD0]
00007f0145bdf456  vmovaps xmm15, [rsp+0xE0]
00007f0145bdf45f  add rsp, 0xF0
00007f0145bdf466  pop r11
00007f0145bdf468  pop r10
00007f0145bdf46a  pop r9
00007f0145bdf46c  pop r8
00007f0145bdf46e  pop rsi
00007f0145bdf46f  pop rdi
00007f0145bdf470  pop rdx
00007f0145bdf471  pop rcx
00007f0145bdf472  pop rax
00007f0145bdf473  add rsp, 0x08
00007f0145bdf477  jmp 0x00007F0145BDC3B3
00007f0145bdf47c  sub rsp, 0x08
00007f0145bdf480  push rax
00007f0145bdf481  push rcx
00007f0145bdf482  push rdx
00007f0145bdf483  push rdi
00007f0145bdf484  push rsi
00007f0145bdf485  push r8
00007f0145bdf487  push r9
00007f0145bdf489  push r10
00007f0145bdf48b  push r11
00007f0145bdf48d  sub rsp, 0xF0
00007f0145bdf494  vmovaps [rsp], xmm0
00007f0145bdf499  vmovaps [rsp+0x10], xmm1
00007f0145bdf49f  vmovaps [rsp+0x20], xmm2
00007f0145bdf4a5  vmovaps [rsp+0x30], xmm3
00007f0145bdf4ab  vmovaps [rsp+0x40], xmm4
00007f0145bdf4b1  vmovaps [rsp+0x50], xmm5
00007f0145bdf4b7  vmovaps [rsp+0x60], xmm7
00007f0145bdf4bd  vmovaps [rsp+0x70], xmm8
00007f0145bdf4c3  vmovaps [rsp+0x80], xmm9
00007f0145bdf4cc  vmovaps [rsp+0x90], xmm10
00007f0145bdf4d5  vmovaps [rsp+0xA0], xmm11
00007f0145bdf4de  vmovaps [rsp+0xB0], xmm12
00007f0145bdf4e7  vmovaps [rsp+0xC0], xmm13
00007f0145bdf4f0  vmovaps [rsp+0xD0], xmm14
00007f0145bdf4f9  vmovaps [rsp+0xE0], xmm15
00007f0145bdf502  sub rsp, 0x30
00007f0145bdf506  movaps [rsp], xmm6
00007f0145bdf50a  movaps [rsp+0x10], xmm10
00007f0145bdf510  movaps [rsp+0x20], xmm8
00007f0145bdf516  lea rdi, [rsp]
00007f0145bdf51a  mov esi, 0x00
00007f0145bdf51f  mov rax, 0x636570E98530
00007f0145bdf529  call rax
00007f0145bdf52b  movaps xmm6, [rsp]
00007f0145bdf52f  add rsp, 0x30
00007f0145bdf533  vmovaps xmm0, [rsp]
00007f0145bdf538  vmovaps xmm1, [rsp+0x10]
00007f0145bdf53e  vmovaps xmm2, [rsp+0x20]
00007f0145bdf544  vmovaps xmm3, [rsp+0x30]
00007f0145bdf54a  vmovaps xmm4, [rsp+0x40]
00007f0145bdf550  vmovaps xmm5, [rsp+0x50]
00007f0145bdf556  vmovaps xmm7, [rsp+0x60]
00007f0145bdf55c  vmovaps xmm8, [rsp+0x70]
00007f0145bdf562  vmovaps xmm9, [rsp+0x80]
00007f0145bdf56b  vmovaps xmm10, [rsp+0x90]
00007f0145bdf574  vmovaps xmm11, [rsp+0xA0]
00007f0145bdf57d  vmovaps xmm12, [rsp+0xB0]
00007f0145bdf586  vmovaps xmm13, [rsp+0xC0]
00007f0145bdf58f  vmovaps xmm14, [rsp+0xD0]
00007f0145bdf598  vmovaps xmm15, [rsp+0xE0]
00007f0145bdf5a1  add rsp, 0xF0
00007f0145bdf5a8  pop r11
00007f0145bdf5aa  pop r10
00007f0145bdf5ac  pop r9
00007f0145bdf5ae  pop r8
00007f0145bdf5b0  pop rsi
00007f0145bdf5b1  pop rdi
00007f0145bdf5b2  pop rdx
00007f0145bdf5b3  pop rcx
00007f0145bdf5b4  pop rax
00007f0145bdf5b5  add rsp, 0x08
00007f0145bdf5b9  jmp 0x00007F0145BDC3D8
00007f0145bdf5be  sub rsp, 0x08
00007f0145bdf5c2  push rax
00007f0145bdf5c3  push rcx
00007f0145bdf5c4  push rdx
00007f0145bdf5c5  push rdi
00007f0145bdf5c6  push rsi
00007f0145bdf5c7  push r8
00007f0145bdf5c9  push r9
00007f0145bdf5cb  push r10
00007f0145bdf5cd  push r11
00007f0145bdf5cf  sub rsp, 0xF0
00007f0145bdf5d6  vmovaps [rsp], xmm0
00007f0145bdf5db  vmovaps [rsp+0x10], xmm1
00007f0145bdf5e1  vmovaps [rsp+0x20], xmm2
00007f0145bdf5e7  vmovaps [rsp+0x30], xmm3
00007f0145bdf5ed  vmovaps [rsp+0x40], xmm4
00007f0145bdf5f3  vmovaps [rsp+0x50], xmm5
00007f0145bdf5f9  vmovaps [rsp+0x60], xmm6
00007f0145bdf5ff  vmovaps [rsp+0x70], xmm7
00007f0145bdf605  vmovaps [rsp+0x80], xmm8
00007f0145bdf60e  vmovaps [rsp+0x90], xmm9
00007f0145bdf617  vmovaps [rsp+0xA0], xmm11
00007f0145bdf620  vmovaps [rsp+0xB0], xmm12
00007f0145bdf629  vmovaps [rsp+0xC0], xmm13
00007f0145bdf632  vmovaps [rsp+0xD0], xmm14
00007f0145bdf63b  vmovaps [rsp+0xE0], xmm15
00007f0145bdf644  sub rsp, 0x30
00007f0145bdf648  movaps [rsp], xmm10
00007f0145bdf64d  movaps [rsp+0x10], xmm8
00007f0145bdf653  movaps [rsp+0x20], xmm14
00007f0145bdf659  lea rdi, [rsp]
00007f0145bdf65d  mov esi, 0x00
00007f0145bdf662  mov rax, 0x636570E98530
00007f0145bdf66c  call rax
00007f0145bdf66e  movaps xmm10, [rsp]
00007f0145bdf673  add rsp, 0x30
00007f0145bdf677  vmovaps xmm0, [rsp]
00007f0145bdf67c  vmovaps xmm1, [rsp+0x10]
00007f0145bdf682  vmovaps xmm2, [rsp+0x20]
00007f0145bdf688  vmovaps xmm3, [rsp+0x30]
00007f0145bdf68e  vmovaps xmm4, [rsp+0x40]
00007f0145bdf694  vmovaps xmm5, [rsp+0x50]
00007f0145bdf69a  vmovaps xmm6, [rsp+0x60]
00007f0145bdf6a0  vmovaps xmm7, [rsp+0x70]
00007f0145bdf6a6  vmovaps xmm8, [rsp+0x80]
00007f0145bdf6af  vmovaps xmm9, [rsp+0x90]
00007f0145bdf6b8  vmovaps xmm11, [rsp+0xA0]
00007f0145bdf6c1  vmovaps xmm12, [rsp+0xB0]
00007f0145bdf6ca  vmovaps xmm13, [rsp+0xC0]
00007f0145bdf6d3  vmovaps xmm14, [rsp+0xD0]
00007f0145bdf6dc  vmovaps xmm15, [rsp+0xE0]
00007f0145bdf6e5  add rsp, 0xF0
00007f0145bdf6ec  pop r11
00007f0145bdf6ee  pop r10
00007f0145bdf6f0  pop r9
00007f0145bdf6f2  pop r8
00007f0145bdf6f4  pop rsi
00007f0145bdf6f5  pop rdi
00007f0145bdf6f6  pop rdx
00007f0145bdf6f7  pop rcx
00007f0145bdf6f8  pop rax
00007f0145bdf6f9  add rsp, 0x08
00007f0145bdf6fd  jmp 0x00007F0145BDC3F8
00007f0145bdf702  sub rsp, 0x08
00007f0145bdf706  push rax
00007f0145bdf707  push rcx
00007f0145bdf708  push rdx
00007f0145bdf709  push rdi
00007f0145bdf70a  push rsi
00007f0145bdf70b  push r8
00007f0145bdf70d  push r9
00007f0145bdf70f  push r10
00007f0145bdf711  push r11
00007f0145bdf713  sub rsp, 0xF0
00007f0145bdf71a  vmovaps [rsp], xmm0
00007f0145bdf71f  vmovaps [rsp+0x10], xmm1
00007f0145bdf725  vmovaps [rsp+0x20], xmm2
00007f0145bdf72b  vmovaps [rsp+0x30], xmm3
00007f0145bdf731  vmovaps [rsp+0x40], xmm4
00007f0145bdf737  vmovaps [rsp+0x50], xmm5
00007f0145bdf73d  vmovaps [rsp+0x60], xmm6
00007f0145bdf743  vmovaps [rsp+0x70], xmm7
00007f0145bdf749  vmovaps [rsp+0x80], xmm8
00007f0145bdf752  vmovaps [rsp+0x90], xmm9
00007f0145bdf75b  vmovaps [rsp+0xA0], xmm10
00007f0145bdf764  vmovaps [rsp+0xB0], xmm11
00007f0145bdf76d  vmovaps [rsp+0xC0], xmm12
00007f0145bdf776  vmovaps [rsp+0xD0], xmm13
00007f0145bdf77f  vmovaps [rsp+0xE0], xmm15
00007f0145bdf788  sub rsp, 0x30
00007f0145bdf78c  movaps [rsp], xmm14
00007f0145bdf791  movaps [rsp+0x10], xmm8
00007f0145bdf797  movaps [rsp+0x20], xmm4
00007f0145bdf79c  lea rdi, [rsp]
00007f0145bdf7a0  mov esi, 0x00
00007f0145bdf7a5  mov rax, 0x636570E98530
00007f0145bdf7af  call rax
00007f0145bdf7b1  movaps xmm14, [rsp]
00007f0145bdf7b6  add rsp, 0x30
00007f0145bdf7ba  vmovaps xmm0, [rsp]
00007f0145bdf7bf  vmovaps xmm1, [rsp+0x10]
00007f0145bdf7c5  vmovaps xmm2, [rsp+0x20]
00007f0145bdf7cb  vmovaps xmm3, [rsp+0x30]
00007f0145bdf7d1  vmovaps xmm4, [rsp+0x40]
00007f0145bdf7d7  vmovaps xmm5, [rsp+0x50]
00007f0145bdf7dd  vmovaps xmm6, [rsp+0x60]
00007f0145bdf7e3  vmovaps xmm7, [rsp+0x70]
00007f0145bdf7e9  vmovaps xmm8, [rsp+0x80]
00007f0145bdf7f2  vmovaps xmm9, [rsp+0x90]
00007f0145bdf7fb  vmovaps xmm10, [rsp+0xA0]
00007f0145bdf804  vmovaps xmm11, [rsp+0xB0]
00007f0145bdf80d  vmovaps xmm12, [rsp+0xC0]
00007f0145bdf816  vmovaps xmm13, [rsp+0xD0]
00007f0145bdf81f  vmovaps xmm15, [rsp+0xE0]
00007f0145bdf828  add rsp, 0xF0
00007f0145bdf82f  pop r11
00007f0145bdf831  pop r10
00007f0145bdf833  pop r9
00007f0145bdf835  pop r8
00007f0145bdf837  pop rsi
00007f0145bdf838  pop rdi
00007f0145bdf839  pop rdx
00007f0145bdf83a  pop rcx
00007f0145bdf83b  pop rax
00007f0145bdf83c  add rsp, 0x08
00007f0145bdf840  jmp 0x00007F0145BDC418
00007f0145bdf845  sub rsp, 0x08
00007f0145bdf849  push rax
00007f0145bdf84a  push rcx
00007f0145bdf84b  push rdx
00007f0145bdf84c  push rdi
00007f0145bdf84d  push rsi
00007f0145bdf84e  push r8
00007f0145bdf850  push r9
00007f0145bdf852  push r10
00007f0145bdf854  push r11
00007f0145bdf856  sub rsp, 0xF0
00007f0145bdf85d  vmovaps [rsp], xmm0
00007f0145bdf862  vmovaps [rsp+0x10], xmm1
00007f0145bdf868  vmovaps [rsp+0x20], xmm2
00007f0145bdf86e  vmovaps [rsp+0x30], xmm3
00007f0145bdf874  vmovaps [rsp+0x40], xmm5
00007f0145bdf87a  vmovaps [rsp+0x50], xmm6
00007f0145bdf880  vmovaps [rsp+0x60], xmm7
00007f0145bdf886  vmovaps [rsp+0x70], xmm8
00007f0145bdf88c  vmovaps [rsp+0x80], xmm9
00007f0145bdf895  vmovaps [rsp+0x90], xmm10
00007f0145bdf89e  vmovaps [rsp+0xA0], xmm11
00007f0145bdf8a7  vmovaps [rsp+0xB0], xmm12
00007f0145bdf8b0  vmovaps [rsp+0xC0], xmm13
00007f0145bdf8b9  vmovaps [rsp+0xD0], xmm14
00007f0145bdf8c2  vmovaps [rsp+0xE0], xmm15
00007f0145bdf8cb  sub rsp, 0x30
00007f0145bdf8cf  movaps [rsp], xmm4
00007f0145bdf8d3  movaps [rsp+0x10], xmm13
00007f0145bdf8d9  movaps [rsp+0x20], xmm8
00007f0145bdf8df  lea rdi, [rsp]
00007f0145bdf8e3  mov esi, 0x00
00007f0145bdf8e8  mov rax, 0x636570E98530
00007f0145bdf8f2  call rax
00007f0145bdf8f4  movaps xmm4, [rsp]
00007f0145bdf8f8  add rsp, 0x30
00007f0145bdf8fc  vmovaps xmm0, [rsp]
00007f0145bdf901  vmovaps xmm1, [rsp+0x10]
00007f0145bdf907  vmovaps xmm2, [rsp+0x20]
00007f0145bdf90d  vmovaps xmm3, [rsp+0x30]
00007f0145bdf913  vmovaps xmm5, [rsp+0x40]
00007f0145bdf919  vmovaps xmm6, [rsp+0x50]
00007f0145bdf91f  vmovaps xmm7, [rsp+0x60]
00007f0145bdf925  vmovaps xmm8, [rsp+0x70]
00007f0145bdf92b  vmovaps xmm9, [rsp+0x80]
00007f0145bdf934  vmovaps xmm10, [rsp+0x90]
00007f0145bdf93d  vmovaps xmm11, [rsp+0xA0]
00007f0145bdf946  vmovaps xmm12, [rsp+0xB0]
00007f0145bdf94f  vmovaps xmm13, [rsp+0xC0]
00007f0145bdf958  vmovaps xmm14, [rsp+0xD0]
00007f0145bdf961  vmovaps xmm15, [rsp+0xE0]
00007f0145bdf96a  add rsp, 0xF0
00007f0145bdf971  pop r11
00007f0145bdf973  pop r10
00007f0145bdf975  pop r9
00007f0145bdf977  pop r8
00007f0145bdf979  pop rsi
00007f0145bdf97a  pop rdi
00007f0145bdf97b  pop rdx
00007f0145bdf97c  pop rcx
00007f0145bdf97d  pop rax
00007f0145bdf97e  add rsp, 0x08
00007f0145bdf982  jmp 0x00007F0145BDC43D
00007f0145bdf987  sub rsp, 0x08
00007f0145bdf98b  push rax
00007f0145bdf98c  push rcx
00007f0145bdf98d  push rdx
00007f0145bdf98e  push rdi
00007f0145bdf98f  push rsi
00007f0145bdf990  push r8
00007f0145bdf992  push r9
00007f0145bdf994  push r10
00007f0145bdf996  push r11
00007f0145bdf998  sub rsp, 0xF0
00007f0145bdf99f  vmovaps [rsp], xmm0
00007f0145bdf9a4  vmovaps [rsp+0x10], xmm1
00007f0145bdf9aa  vmovaps [rsp+0x20], xmm2
00007f0145bdf9b0  vmovaps [rsp+0x30], xmm3
00007f0145bdf9b6  vmovaps [rsp+0x40], xmm4
00007f0145bdf9bc  vmovaps [rsp+0x50], xmm5
00007f0145bdf9c2  vmovaps [rsp+0x60], xmm6
00007f0145bdf9c8  vmovaps [rsp+0x70], xmm7
00007f0145bdf9ce  vmovaps [rsp+0x80], xmm8
00007f0145bdf9d7  vmovaps [rsp+0x90], xmm9
00007f0145bdf9e0  vmovaps [rsp+0xA0], xmm10
00007f0145bdf9e9  vmovaps [rsp+0xB0], xmm11
00007f0145bdf9f2  vmovaps [rsp+0xC0], xmm12
00007f0145bdf9fb  vmovaps [rsp+0xD0], xmm14
00007f0145bdfa04  vmovaps [rsp+0xE0], xmm15
00007f0145bdfa0d  sub rsp, 0x30
00007f0145bdfa11  movaps [rsp], xmm13
00007f0145bdfa16  movaps [rsp+0x10], xmm15
00007f0145bdfa1c  movaps [rsp+0x20], xmm9
00007f0145bdfa22  lea rdi, [rsp]
00007f0145bdfa26  mov esi, 0x00
00007f0145bdfa2b  mov rax, 0x636570E98530
00007f0145bdfa35  call rax
00007f0145bdfa37  movaps xmm13, [rsp]
00007f0145bdfa3c  add rsp, 0x30
00007f0145bdfa40  vmovaps xmm0, [rsp]
00007f0145bdfa45  vmovaps xmm1, [rsp+0x10]
00007f0145bdfa4b  vmovaps xmm2, [rsp+0x20]
00007f0145bdfa51  vmovaps xmm3, [rsp+0x30]
00007f0145bdfa57  vmovaps xmm4, [rsp+0x40]
00007f0145bdfa5d  vmovaps xmm5, [rsp+0x50]
00007f0145bdfa63  vmovaps xmm6, [rsp+0x60]
00007f0145bdfa69  vmovaps xmm7, [rsp+0x70]
00007f0145bdfa6f  vmovaps xmm8, [rsp+0x80]
00007f0145bdfa78  vmovaps xmm9, [rsp+0x90]
00007f0145bdfa81  vmovaps xmm10, [rsp+0xA0]
00007f0145bdfa8a  vmovaps xmm11, [rsp+0xB0]
00007f0145bdfa93  vmovaps xmm12, [rsp+0xC0]
00007f0145bdfa9c  vmovaps xmm14, [rsp+0xD0]
00007f0145bdfaa5  vmovaps xmm15, [rsp+0xE0]
00007f0145bdfaae  add rsp, 0xF0
00007f0145bdfab5  pop r11
00007f0145bdfab7  pop r10
00007f0145bdfab9  pop r9
00007f0145bdfabb  pop r8
00007f0145bdfabd  pop rsi
00007f0145bdfabe  pop rdi
00007f0145bdfabf  pop rdx
00007f0145bdfac0  pop rcx
00007f0145bdfac1  pop rax
00007f0145bdfac2  add rsp, 0x08
00007f0145bdfac6  jmp 0x00007F0145BDC458
00007f0145bdfacb  sub rsp, 0x08
00007f0145bdfacf  push rax
00007f0145bdfad0  push rcx
00007f0145bdfad1  push rdx
00007f0145bdfad2  push rdi
00007f0145bdfad3  push rsi
00007f0145bdfad4  push r8
00007f0145bdfad6  push r9
00007f0145bdfad8  push r10
00007f0145bdfada  push r11
00007f0145bdfadc  sub rsp, 0xF0
00007f0145bdfae3  vmovaps [rsp], xmm0
00007f0145bdfae8  vmovaps [rsp+0x10], xmm1
00007f0145bdfaee  vmovaps [rsp+0x20], xmm2
00007f0145bdfaf4  vmovaps [rsp+0x30], xmm3
00007f0145bdfafa  vmovaps [rsp+0x40], xmm4
00007f0145bdfb00  vmovaps [rsp+0x50], xmm5
00007f0145bdfb06  vmovaps [rsp+0x60], xmm6
00007f0145bdfb0c  vmovaps [rsp+0x70], xmm7
00007f0145bdfb12  vmovaps [rsp+0x80], xmm8
00007f0145bdfb1b  vmovaps [rsp+0x90], xmm9
00007f0145bdfb24  vmovaps [rsp+0xA0], xmm10
00007f0145bdfb2d  vmovaps [rsp+0xB0], xmm11
00007f0145bdfb36  vmovaps [rsp+0xC0], xmm12
00007f0145bdfb3f  vmovaps [rsp+0xD0], xmm13
00007f0145bdfb48  vmovaps [rsp+0xE0], xmm14
00007f0145bdfb51  sub rsp, 0x30
00007f0145bdfb55  movaps [rsp], xmm15
00007f0145bdfb5a  movaps [rsp+0x10], xmm1
00007f0145bdfb5f  movaps [rsp+0x20], xmm5
00007f0145bdfb64  lea rdi, [rsp]
00007f0145bdfb68  mov esi, 0x00
00007f0145bdfb6d  mov rax, 0x636570E98530
00007f0145bdfb77  call rax
00007f0145bdfb79  movaps xmm15, [rsp]
00007f0145bdfb7e  add rsp, 0x30
00007f0145bdfb82  vmovaps xmm0, [rsp]
00007f0145bdfb87  vmovaps xmm1, [rsp+0x10]
00007f0145bdfb8d  vmovaps xmm2, [rsp+0x20]
00007f0145bdfb93  vmovaps xmm3, [rsp+0x30]
00007f0145bdfb99  vmovaps xmm4, [rsp+0x40]
00007f0145bdfb9f  vmovaps xmm5, [rsp+0x50]
00007f0145bdfba5  vmovaps xmm6, [rsp+0x60]
00007f0145bdfbab  vmovaps xmm7, [rsp+0x70]
00007f0145bdfbb1  vmovaps xmm8, [rsp+0x80]
00007f0145bdfbba  vmovaps xmm9, [rsp+0x90]
00007f0145bdfbc3  vmovaps xmm10, [rsp+0xA0]
00007f0145bdfbcc  vmovaps xmm11, [rsp+0xB0]
00007f0145bdfbd5  vmovaps xmm12, [rsp+0xC0]
00007f0145bdfbde  vmovaps xmm13, [rsp+0xD0]
00007f0145bdfbe7  vmovaps xmm14, [rsp+0xE0]
00007f0145bdfbf0  add rsp, 0xF0
00007f0145bdfbf7  pop r11
00007f0145bdfbf9  pop r10
00007f0145bdfbfb  pop r9
00007f0145bdfbfd  pop r8
00007f0145bdfbff  pop rsi
00007f0145bdfc00  pop rdi
00007f0145bdfc01  pop rdx
00007f0145bdfc02  pop rcx
00007f0145bdfc03  pop rax
00007f0145bdfc04  add rsp, 0x08
00007f0145bdfc08  jmp 0x00007F0145BDC473
00007f0145bdfc0d  call 0x00007F0145AB52F0
00007f0145bdfc12  jmp 0x00007F0145BDC4CE
00007f0145bdfc17  sub rsp, 0x08
00007f0145bdfc1b  push rax
00007f0145bdfc1c  push rcx
00007f0145bdfc1d  push rdx
00007f0145bdfc1e  push rdi
00007f0145bdfc1f  push rsi
00007f0145bdfc20  push r8
00007f0145bdfc22  push r9
00007f0145bdfc24  push r10
00007f0145bdfc26  push r11
00007f0145bdfc28  sub rsp, 0xF0
00007f0145bdfc2f  vmovaps [rsp], xmm0
00007f0145bdfc34  vmovaps [rsp+0x10], xmm1
00007f0145bdfc3a  vmovaps [rsp+0x20], xmm2
00007f0145bdfc40  vmovaps [rsp+0x30], xmm3
00007f0145bdfc46  vmovaps [rsp+0x40], xmm4
00007f0145bdfc4c  vmovaps [rsp+0x50], xmm5
00007f0145bdfc52  vmovaps [rsp+0x60], xmm6
00007f0145bdfc58  vmovaps [rsp+0x70], xmm7
00007f0145bdfc5e  vmovaps [rsp+0x80], xmm8
00007f0145bdfc67  vmovaps [rsp+0x90], xmm10
00007f0145bdfc70  vmovaps [rsp+0xA0], xmm11
00007f0145bdfc79  vmovaps [rsp+0xB0], xmm12
00007f0145bdfc82  vmovaps [rsp+0xC0], xmm13
00007f0145bdfc8b  vmovaps [rsp+0xD0], xmm14
00007f0145bdfc94  vmovaps [rsp+0xE0], xmm15
00007f0145bdfc9d  sub rsp, 0x30
00007f0145bdfca1  movaps [rsp], xmm9
00007f0145bdfca6  movaps [rsp+0x10], xmm8
00007f0145bdfcac  movaps [rsp+0x20], xmm11
00007f0145bdfcb2  lea rdi, [rsp]
00007f0145bdfcb6  mov esi, 0x00
00007f0145bdfcbb  mov rax, 0x636570E98530
00007f0145bdfcc5  call rax
00007f0145bdfcc7  movaps xmm9, [rsp]
00007f0145bdfccc  add rsp, 0x30
00007f0145bdfcd0  vmovaps xmm0, [rsp]
00007f0145bdfcd5  vmovaps xmm1, [rsp+0x10]
00007f0145bdfcdb  vmovaps xmm2, [rsp+0x20]
00007f0145bdfce1  vmovaps xmm3, [rsp+0x30]
00007f0145bdfce7  vmovaps xmm4, [rsp+0x40]
00007f0145bdfced  vmovaps xmm5, [rsp+0x50]
00007f0145bdfcf3  vmovaps xmm6, [rsp+0x60]
00007f0145bdfcf9  vmovaps xmm7, [rsp+0x70]
00007f0145bdfcff  vmovaps xmm8, [rsp+0x80]
00007f0145bdfd08  vmovaps xmm10, [rsp+0x90]
00007f0145bdfd11  vmovaps xmm11, [rsp+0xA0]
00007f0145bdfd1a  vmovaps xmm12, [rsp+0xB0]
00007f0145bdfd23  vmovaps xmm13, [rsp+0xC0]
00007f0145bdfd2c  vmovaps xmm14, [rsp+0xD0]
00007f0145bdfd35  vmovaps xmm15, [rsp+0xE0]
00007f0145bdfd3e  add rsp, 0xF0
00007f0145bdfd45  pop r11
00007f0145bdfd47  pop r10
00007f0145bdfd49  pop r9
00007f0145bdfd4b  pop r8
00007f0145bdfd4d  pop rsi
00007f0145bdfd4e  pop rdi
00007f0145bdfd4f  pop rdx
00007f0145bdfd50  pop rcx
00007f0145bdfd51  pop rax
00007f0145bdfd52  add rsp, 0x08
00007f0145bdfd56  jmp 0x00007F0145BDC505
00007f0145bdfd5b  sub rsp, 0x08
00007f0145bdfd5f  push rax
00007f0145bdfd60  push rcx
00007f0145bdfd61  push rdx
00007f0145bdfd62  push rdi
00007f0145bdfd63  push rsi
00007f0145bdfd64  push r8
00007f0145bdfd66  push r9
00007f0145bdfd68  push r10
00007f0145bdfd6a  push r11
00007f0145bdfd6c  sub rsp, 0xF0
00007f0145bdfd73  vmovaps [rsp], xmm0
00007f0145bdfd78  vmovaps [rsp+0x10], xmm1
00007f0145bdfd7e  vmovaps [rsp+0x20], xmm2
00007f0145bdfd84  vmovaps [rsp+0x30], xmm3
00007f0145bdfd8a  vmovaps [rsp+0x40], xmm4
00007f0145bdfd90  vmovaps [rsp+0x50], xmm5
00007f0145bdfd96  vmovaps [rsp+0x60], xmm6
00007f0145bdfd9c  vmovaps [rsp+0x70], xmm7
00007f0145bdfda2  vmovaps [rsp+0x80], xmm8
00007f0145bdfdab  vmovaps [rsp+0x90], xmm9
00007f0145bdfdb4  vmovaps [rsp+0xA0], xmm10
00007f0145bdfdbd  vmovaps [rsp+0xB0], xmm12
00007f0145bdfdc6  vmovaps [rsp+0xC0], xmm13
00007f0145bdfdcf  vmovaps [rsp+0xD0], xmm14
00007f0145bdfdd8  vmovaps [rsp+0xE0], xmm15
00007f0145bdfde1  sub rsp, 0x30
00007f0145bdfde5  movaps [rsp], xmm11
00007f0145bdfdea  movaps [rsp+0x10], xmm10
00007f0145bdfdf0  movaps [rsp+0x20], xmm6
00007f0145bdfdf5  lea rdi, [rsp]
00007f0145bdfdf9  mov esi, 0x00
00007f0145bdfdfe  mov rax, 0x636570E98530
00007f0145bdfe08  call rax
00007f0145bdfe0a  movaps xmm11, [rsp]
00007f0145bdfe0f  add rsp, 0x30
00007f0145bdfe13  vmovaps xmm0, [rsp]
00007f0145bdfe18  vmovaps xmm1, [rsp+0x10]
00007f0145bdfe1e  vmovaps xmm2, [rsp+0x20]
00007f0145bdfe24  vmovaps xmm3, [rsp+0x30]
00007f0145bdfe2a  vmovaps xmm4, [rsp+0x40]
00007f0145bdfe30  vmovaps xmm5, [rsp+0x50]
00007f0145bdfe36  vmovaps xmm6, [rsp+0x60]
00007f0145bdfe3c  vmovaps xmm7, [rsp+0x70]
00007f0145bdfe42  vmovaps xmm8, [rsp+0x80]
00007f0145bdfe4b  vmovaps xmm9, [rsp+0x90]
00007f0145bdfe54  vmovaps xmm10, [rsp+0xA0]
00007f0145bdfe5d  vmovaps xmm12, [rsp+0xB0]
00007f0145bdfe66  vmovaps xmm13, [rsp+0xC0]
00007f0145bdfe6f  vmovaps xmm14, [rsp+0xD0]
00007f0145bdfe78  vmovaps xmm15, [rsp+0xE0]
00007f0145bdfe81  add rsp, 0xF0
00007f0145bdfe88  pop r11
00007f0145bdfe8a  pop r10
00007f0145bdfe8c  pop r9
00007f0145bdfe8e  pop r8
00007f0145bdfe90  pop rsi
00007f0145bdfe91  pop rdi
00007f0145bdfe92  pop rdx
00007f0145bdfe93  pop rcx
00007f0145bdfe94  pop rax
00007f0145bdfe95  add rsp, 0x08
00007f0145bdfe99  jmp 0x00007F0145BDC520
00007f0145bdfe9e  sub rsp, 0x08
00007f0145bdfea2  push rax
00007f0145bdfea3  push rcx
00007f0145bdfea4  push rdx
00007f0145bdfea5  push rdi
00007f0145bdfea6  push rsi
00007f0145bdfea7  push r8
00007f0145bdfea9  push r9
00007f0145bdfeab  push r10
00007f0145bdfead  push r11
00007f0145bdfeaf  sub rsp, 0xF0
00007f0145bdfeb6  vmovaps [rsp], xmm0
00007f0145bdfebb  vmovaps [rsp+0x10], xmm1
00007f0145bdfec1  vmovaps [rsp+0x20], xmm2
00007f0145bdfec7  vmovaps [rsp+0x30], xmm3
00007f0145bdfecd  vmovaps [rsp+0x40], xmm4
00007f0145bdfed3  vmovaps [rsp+0x50], xmm5
00007f0145bdfed9  vmovaps [rsp+0x60], xmm6
00007f0145bdfedf  vmovaps [rsp+0x70], xmm7
00007f0145bdfee5  vmovaps [rsp+0x80], xmm8
00007f0145bdfeee  vmovaps [rsp+0x90], xmm9
00007f0145bdfef7  vmovaps [rsp+0xA0], xmm11
00007f0145bdff00  vmovaps [rsp+0xB0], xmm12
00007f0145bdff09  vmovaps [rsp+0xC0], xmm13
00007f0145bdff12  vmovaps [rsp+0xD0], xmm14
00007f0145bdff1b  vmovaps [rsp+0xE0], xmm15
00007f0145bdff24  sub rsp, 0x30
00007f0145bdff28  movaps [rsp], xmm10
00007f0145bdff2d  movaps [rsp+0x10], xmm14
00007f0145bdff33  movaps [rsp+0x20], xmm4
00007f0145bdff38  lea rdi, [rsp]
00007f0145bdff3c  mov esi, 0x00
00007f0145bdff41  mov rax, 0x636570E98530
00007f0145bdff4b  call rax
00007f0145bdff4d  movaps xmm10, [rsp]
00007f0145bdff52  add rsp, 0x30
00007f0145bdff56  vmovaps xmm0, [rsp]
00007f0145bdff5b  vmovaps xmm1, [rsp+0x10]
00007f0145bdff61  vmovaps xmm2, [rsp+0x20]
00007f0145bdff67  vmovaps xmm3, [rsp+0x30]
00007f0145bdff6d  vmovaps xmm4, [rsp+0x40]
00007f0145bdff73  vmovaps xmm5, [rsp+0x50]
00007f0145bdff79  vmovaps xmm6, [rsp+0x60]
00007f0145bdff7f  vmovaps xmm7, [rsp+0x70]
00007f0145bdff85  vmovaps xmm8, [rsp+0x80]
00007f0145bdff8e  vmovaps xmm9, [rsp+0x90]
00007f0145bdff97  vmovaps xmm11, [rsp+0xA0]
00007f0145bdffa0  vmovaps xmm12, [rsp+0xB0]
00007f0145bdffa9  vmovaps xmm13, [rsp+0xC0]
00007f0145bdffb2  vmovaps xmm14, [rsp+0xD0]
00007f0145bdffbb  vmovaps xmm15, [rsp+0xE0]
00007f0145bdffc4  add rsp, 0xF0
00007f0145bdffcb  pop r11
00007f0145bdffcd  pop r10
00007f0145bdffcf  pop r9
00007f0145bdffd1  pop r8
00007f0145bdffd3  pop rsi
00007f0145bdffd4  pop rdi
00007f0145bdffd5  pop rdx
00007f0145bdffd6  pop rcx
00007f0145bdffd7  pop rax
00007f0145bdffd8  add rsp, 0x08
00007f0145bdffdc  jmp 0x00007F0145BDC53B
00007f0145bdffe1  sub rsp, 0x08
00007f0145bdffe5  push rax
00007f0145bdffe6  push rcx
00007f0145bdffe7  push rdx
00007f0145bdffe8  push rdi
00007f0145bdffe9  push rsi
00007f0145bdffea  push r8
00007f0145bdffec  push r9
00007f0145bdffee  push r10
00007f0145bdfff0  push r11
00007f0145bdfff2  sub rsp, 0xF0
00007f0145bdfff9  vmovaps [rsp], xmm0
00007f0145bdfffe  vmovaps [rsp+0x10], xmm1
00007f0145be0004  vmovaps [rsp+0x20], xmm2
00007f0145be000a  vmovaps [rsp+0x30], xmm3
00007f0145be0010  vmovaps [rsp+0x40], xmm4
00007f0145be0016  vmovaps [rsp+0x50], xmm5
00007f0145be001c  vmovaps [rsp+0x60], xmm6
00007f0145be0022  vmovaps [rsp+0x70], xmm7
00007f0145be0028  vmovaps [rsp+0x80], xmm9
00007f0145be0031  vmovaps [rsp+0x90], xmm10
00007f0145be003a  vmovaps [rsp+0xA0], xmm11
00007f0145be0043  vmovaps [rsp+0xB0], xmm12
00007f0145be004c  vmovaps [rsp+0xC0], xmm13
00007f0145be0055  vmovaps [rsp+0xD0], xmm14
00007f0145be005e  vmovaps [rsp+0xE0], xmm15
00007f0145be0067  sub rsp, 0x30
00007f0145be006b  movaps [rsp], xmm8
00007f0145be0070  movaps [rsp+0x10], xmm1
00007f0145be0075  movaps [rsp+0x20], xmm14
00007f0145be007b  lea rdi, [rsp]
00007f0145be007f  mov esi, 0x00
00007f0145be0084  mov rax, 0x636570E98530
00007f0145be008e  call rax
00007f0145be0090  movaps xmm8, [rsp]
00007f0145be0095  add rsp, 0x30
00007f0145be0099  vmovaps xmm0, [rsp]
00007f0145be009e  vmovaps xmm1, [rsp+0x10]
00007f0145be00a4  vmovaps xmm2, [rsp+0x20]
00007f0145be00aa  vmovaps xmm3, [rsp+0x30]
00007f0145be00b0  vmovaps xmm4, [rsp+0x40]
00007f0145be00b6  vmovaps xmm5, [rsp+0x50]
00007f0145be00bc  vmovaps xmm6, [rsp+0x60]
00007f0145be00c2  vmovaps xmm7, [rsp+0x70]
00007f0145be00c8  vmovaps xmm9, [rsp+0x80]
00007f0145be00d1  vmovaps xmm10, [rsp+0x90]
00007f0145be00da  vmovaps xmm11, [rsp+0xA0]
00007f0145be00e3  vmovaps xmm12, [rsp+0xB0]
00007f0145be00ec  vmovaps xmm13, [rsp+0xC0]
00007f0145be00f5  vmovaps xmm14, [rsp+0xD0]
00007f0145be00fe  vmovaps xmm15, [rsp+0xE0]
00007f0145be0107  add rsp, 0xF0
00007f0145be010e  pop r11
00007f0145be0110  pop r10
00007f0145be0112  pop r9
00007f0145be0114  pop r8
00007f0145be0116  pop rsi
00007f0145be0117  pop rdi
00007f0145be0118  pop rdx
00007f0145be0119  pop rcx
00007f0145be011a  pop rax
00007f0145be011b  add rsp, 0x08
00007f0145be011f  jmp 0x00007F0145BDC561
00007f0145be0124  sub rsp, 0x08
00007f0145be0128  push rax
00007f0145be0129  push rcx
00007f0145be012a  push rdx
00007f0145be012b  push rdi
00007f0145be012c  push rsi
00007f0145be012d  push r8
00007f0145be012f  push r9
00007f0145be0131  push r10
00007f0145be0133  push r11
00007f0145be0135  sub rsp, 0xF0
00007f0145be013c  vmovaps [rsp], xmm0
00007f0145be0141  vmovaps [rsp+0x10], xmm1
00007f0145be0147  vmovaps [rsp+0x20], xmm2
00007f0145be014d  vmovaps [rsp+0x30], xmm3
00007f0145be0153  vmovaps [rsp+0x40], xmm4
00007f0145be0159  vmovaps [rsp+0x50], xmm5
00007f0145be015f  vmovaps [rsp+0x60], xmm7
00007f0145be0165  vmovaps [rsp+0x70], xmm8
00007f0145be016b  vmovaps [rsp+0x80], xmm9
00007f0145be0174  vmovaps [rsp+0x90], xmm10
00007f0145be017d  vmovaps [rsp+0xA0], xmm11
00007f0145be0186  vmovaps [rsp+0xB0], xmm12
00007f0145be018f  vmovaps [rsp+0xC0], xmm13
00007f0145be0198  vmovaps [rsp+0xD0], xmm14
00007f0145be01a1  vmovaps [rsp+0xE0], xmm15
00007f0145be01aa  sub rsp, 0x30
00007f0145be01ae  movaps [rsp], xmm6
00007f0145be01b2  movaps [rsp+0x10], xmm1
00007f0145be01b7  movaps [rsp+0x20], xmm14
00007f0145be01bd  lea rdi, [rsp]
00007f0145be01c1  mov esi, 0x00
00007f0145be01c6  mov rax, 0x636570E98530
00007f0145be01d0  call rax
00007f0145be01d2  movaps xmm6, [rsp]
00007f0145be01d6  add rsp, 0x30
00007f0145be01da  vmovaps xmm0, [rsp]
00007f0145be01df  vmovaps xmm1, [rsp+0x10]
00007f0145be01e5  vmovaps xmm2, [rsp+0x20]
00007f0145be01eb  vmovaps xmm3, [rsp+0x30]
00007f0145be01f1  vmovaps xmm4, [rsp+0x40]
00007f0145be01f7  vmovaps xmm5, [rsp+0x50]
00007f0145be01fd  vmovaps xmm7, [rsp+0x60]
00007f0145be0203  vmovaps xmm8, [rsp+0x70]
00007f0145be0209  vmovaps xmm9, [rsp+0x80]
00007f0145be0212  vmovaps xmm10, [rsp+0x90]
00007f0145be021b  vmovaps xmm11, [rsp+0xA0]
00007f0145be0224  vmovaps xmm12, [rsp+0xB0]
00007f0145be022d  vmovaps xmm13, [rsp+0xC0]
00007f0145be0236  vmovaps xmm14, [rsp+0xD0]
00007f0145be023f  vmovaps xmm15, [rsp+0xE0]
00007f0145be0248  add rsp, 0xF0
00007f0145be024f  pop r11
00007f0145be0251  pop r10
00007f0145be0253  pop r9
00007f0145be0255  pop r8
00007f0145be0257  pop rsi
00007f0145be0258  pop rdi
00007f0145be0259  pop rdx
00007f0145be025a  pop rcx
00007f0145be025b  pop rax
00007f0145be025c  add rsp, 0x08
00007f0145be0260  jmp 0x00007F0145BDC58D
00007f0145be0265  sub rsp, 0x08
00007f0145be0269  push rax
00007f0145be026a  push rcx
00007f0145be026b  push rdx
00007f0145be026c  push rdi
00007f0145be026d  push rsi
00007f0145be026e  push r8
00007f0145be0270  push r9
00007f0145be0272  push r10
00007f0145be0274  push r11
00007f0145be0276  sub rsp, 0xF0
00007f0145be027d  vmovaps [rsp], xmm0
00007f0145be0282  vmovaps [rsp+0x10], xmm1
00007f0145be0288  vmovaps [rsp+0x20], xmm2
00007f0145be028e  vmovaps [rsp+0x30], xmm3
00007f0145be0294  vmovaps [rsp+0x40], xmm4
00007f0145be029a  vmovaps [rsp+0x50], xmm5
00007f0145be02a0  vmovaps [rsp+0x60], xmm6
00007f0145be02a6  vmovaps [rsp+0x70], xmm7
00007f0145be02ac  vmovaps [rsp+0x80], xmm8
00007f0145be02b5  vmovaps [rsp+0x90], xmm9
00007f0145be02be  vmovaps [rsp+0xA0], xmm10
00007f0145be02c7  vmovaps [rsp+0xB0], xmm11
00007f0145be02d0  vmovaps [rsp+0xC0], xmm12
00007f0145be02d9  vmovaps [rsp+0xD0], xmm13
00007f0145be02e2  vmovaps [rsp+0xE0], xmm15
00007f0145be02eb  sub rsp, 0x30
00007f0145be02ef  movaps [rsp], xmm14
00007f0145be02f4  movaps [rsp+0x10], xmm12
00007f0145be02fa  movaps [rsp+0x20], xmm1
00007f0145be02ff  lea rdi, [rsp]
00007f0145be0303  mov esi, 0x00
00007f0145be0308  mov rax, 0x636570E98530
00007f0145be0312  call rax
00007f0145be0314  movaps xmm14, [rsp]
00007f0145be0319  add rsp, 0x30
00007f0145be031d  vmovaps xmm0, [rsp]
00007f0145be0322  vmovaps xmm1, [rsp+0x10]
00007f0145be0328  vmovaps xmm2, [rsp+0x20]
00007f0145be032e  vmovaps xmm3, [rsp+0x30]
00007f0145be0334  vmovaps xmm4, [rsp+0x40]
00007f0145be033a  vmovaps xmm5, [rsp+0x50]
00007f0145be0340  vmovaps xmm6, [rsp+0x60]
00007f0145be0346  vmovaps xmm7, [rsp+0x70]
00007f0145be034c  vmovaps xmm8, [rsp+0x80]
00007f0145be0355  vmovaps xmm9, [rsp+0x90]
00007f0145be035e  vmovaps xmm10, [rsp+0xA0]
00007f0145be0367  vmovaps xmm11, [rsp+0xB0]
00007f0145be0370  vmovaps xmm12, [rsp+0xC0]
00007f0145be0379  vmovaps xmm13, [rsp+0xD0]
00007f0145be0382  vmovaps xmm15, [rsp+0xE0]
00007f0145be038b  add rsp, 0xF0
00007f0145be0392  pop r11
00007f0145be0394  pop r10
00007f0145be0396  pop r9
00007f0145be0398  pop r8
00007f0145be039a  pop rsi
00007f0145be039b  pop rdi
00007f0145be039c  pop rdx
00007f0145be039d  pop rcx
00007f0145be039e  pop rax
00007f0145be039f  add rsp, 0x08
00007f0145be03a3  jmp 0x00007F0145BDC5B3
00007f0145be03a8  sub rsp, 0x08
00007f0145be03ac  push rax
00007f0145be03ad  push rcx
00007f0145be03ae  push rdx
00007f0145be03af  push rdi
00007f0145be03b0  push rsi
00007f0145be03b1  push r8
00007f0145be03b3  push r9
00007f0145be03b5  push r10
00007f0145be03b7  push r11
00007f0145be03b9  sub rsp, 0xF0
00007f0145be03c0  vmovaps [rsp], xmm0
00007f0145be03c5  vmovaps [rsp+0x10], xmm2
00007f0145be03cb  vmovaps [rsp+0x20], xmm3
00007f0145be03d1  vmovaps [rsp+0x30], xmm4
00007f0145be03d7  vmovaps [rsp+0x40], xmm5
00007f0145be03dd  vmovaps [rsp+0x50], xmm6
00007f0145be03e3  vmovaps [rsp+0x60], xmm7
00007f0145be03e9  vmovaps [rsp+0x70], xmm8
00007f0145be03ef  vmovaps [rsp+0x80], xmm9
00007f0145be03f8  vmovaps [rsp+0x90], xmm10
00007f0145be0401  vmovaps [rsp+0xA0], xmm11
00007f0145be040a  vmovaps [rsp+0xB0], xmm12
00007f0145be0413  vmovaps [rsp+0xC0], xmm13
00007f0145be041c  vmovaps [rsp+0xD0], xmm14
00007f0145be0425  vmovaps [rsp+0xE0], xmm15
00007f0145be042e  sub rsp, 0x30
00007f0145be0432  movaps [rsp], xmm1
00007f0145be0436  movaps [rsp+0x10], xmm13
00007f0145be043c  movaps [rsp+0x20], xmm9
00007f0145be0442  lea rdi, [rsp]
00007f0145be0446  mov esi, 0x00
00007f0145be044b  mov rax, 0x636570E98530
00007f0145be0455  call rax
00007f0145be0457  movaps xmm1, [rsp]
00007f0145be045b  add rsp, 0x30
00007f0145be045f  vmovaps xmm0, [rsp]
00007f0145be0464  vmovaps xmm2, [rsp+0x10]
00007f0145be046a  vmovaps xmm3, [rsp+0x20]
00007f0145be0470  vmovaps xmm4, [rsp+0x30]
00007f0145be0476  vmovaps xmm5, [rsp+0x40]
00007f0145be047c  vmovaps xmm6, [rsp+0x50]
00007f0145be0482  vmovaps xmm7, [rsp+0x60]
00007f0145be0488  vmovaps xmm8, [rsp+0x70]
00007f0145be048e  vmovaps xmm9, [rsp+0x80]
00007f0145be0497  vmovaps xmm10, [rsp+0x90]
00007f0145be04a0  vmovaps xmm11, [rsp+0xA0]
00007f0145be04a9  vmovaps xmm12, [rsp+0xB0]
00007f0145be04b2  vmovaps xmm13, [rsp+0xC0]
00007f0145be04bb  vmovaps xmm14, [rsp+0xD0]
00007f0145be04c4  vmovaps xmm15, [rsp+0xE0]
00007f0145be04cd  add rsp, 0xF0
00007f0145be04d4  pop r11
00007f0145be04d6  pop r10
00007f0145be04d8  pop r9
00007f0145be04da  pop r8
00007f0145be04dc  pop rsi
00007f0145be04dd  pop rdi
00007f0145be04de  pop rdx
00007f0145be04df  pop rcx
00007f0145be04e0  pop rax
00007f0145be04e1  add rsp, 0x08
00007f0145be04e5  jmp 0x00007F0145BDC5CD
00007f0145be04ea  sub rsp, 0x08
00007f0145be04ee  push rax
00007f0145be04ef  push rcx
00007f0145be04f0  push rdx
00007f0145be04f1  push rdi
00007f0145be04f2  push rsi
00007f0145be04f3  push r8
00007f0145be04f5  push r9
00007f0145be04f7  push r10
00007f0145be04f9  push r11
00007f0145be04fb  sub rsp, 0xF0
00007f0145be0502  vmovaps [rsp], xmm0
00007f0145be0507  vmovaps [rsp+0x10], xmm1
00007f0145be050d  vmovaps [rsp+0x20], xmm2
00007f0145be0513  vmovaps [rsp+0x30], xmm3
00007f0145be0519  vmovaps [rsp+0x40], xmm4
00007f0145be051f  vmovaps [rsp+0x50], xmm5
00007f0145be0525  vmovaps [rsp+0x60], xmm6
00007f0145be052b  vmovaps [rsp+0x70], xmm7
00007f0145be0531  vmovaps [rsp+0x80], xmm8
00007f0145be053a  vmovaps [rsp+0x90], xmm9
00007f0145be0543  vmovaps [rsp+0xA0], xmm10
00007f0145be054c  vmovaps [rsp+0xB0], xmm11
00007f0145be0555  vmovaps [rsp+0xC0], xmm13
00007f0145be055e  vmovaps [rsp+0xD0], xmm14
00007f0145be0567  vmovaps [rsp+0xE0], xmm15
00007f0145be0570  sub rsp, 0x30
00007f0145be0574  movaps [rsp], xmm12
00007f0145be0579  movaps [rsp+0x10], xmm7
00007f0145be057e  movaps [rsp+0x20], xmm13
00007f0145be0584  lea rdi, [rsp]
00007f0145be0588  mov esi, 0x00
00007f0145be058d  mov rax, 0x636570E98530
00007f0145be0597  call rax
00007f0145be0599  movaps xmm12, [rsp]
00007f0145be059e  add rsp, 0x30
00007f0145be05a2  vmovaps xmm0, [rsp]
00007f0145be05a7  vmovaps xmm1, [rsp+0x10]
00007f0145be05ad  vmovaps xmm2, [rsp+0x20]
00007f0145be05b3  vmovaps xmm3, [rsp+0x30]
00007f0145be05b9  vmovaps xmm4, [rsp+0x40]
00007f0145be05bf  vmovaps xmm5, [rsp+0x50]
00007f0145be05c5  vmovaps xmm6, [rsp+0x60]
00007f0145be05cb  vmovaps xmm7, [rsp+0x70]
00007f0145be05d1  vmovaps xmm8, [rsp+0x80]
00007f0145be05da  vmovaps xmm9, [rsp+0x90]
00007f0145be05e3  vmovaps xmm10, [rsp+0xA0]
00007f0145be05ec  vmovaps xmm11, [rsp+0xB0]
00007f0145be05f5  vmovaps xmm13, [rsp+0xC0]
00007f0145be05fe  vmovaps xmm14, [rsp+0xD0]
00007f0145be0607  vmovaps xmm15, [rsp+0xE0]
00007f0145be0610  add rsp, 0xF0
00007f0145be0617  pop r11
00007f0145be0619  pop r10
00007f0145be061b  pop r9
00007f0145be061d  pop r8
00007f0145be061f  pop rsi
00007f0145be0620  pop rdi
00007f0145be0621  pop rdx
00007f0145be0622  pop rcx
00007f0145be0623  pop rax
00007f0145be0624  add rsp, 0x08
00007f0145be0628  jmp 0x00007F0145BDC5F4
00007f0145be062d  sub rsp, 0x08
00007f0145be0631  push rax
00007f0145be0632  push rcx
00007f0145be0633  push rdx
00007f0145be0634  push rdi
00007f0145be0635  push rsi
00007f0145be0636  push r8
00007f0145be0638  push r9
00007f0145be063a  push r10
00007f0145be063c  push r11
00007f0145be063e  sub rsp, 0xF0
00007f0145be0645  vmovaps [rsp], xmm0
00007f0145be064a  vmovaps [rsp+0x10], xmm1
00007f0145be0650  vmovaps [rsp+0x20], xmm2
00007f0145be0656  vmovaps [rsp+0x30], xmm3
00007f0145be065c  vmovaps [rsp+0x40], xmm4
00007f0145be0662  vmovaps [rsp+0x50], xmm5
00007f0145be0668  vmovaps [rsp+0x60], xmm6
00007f0145be066e  vmovaps [rsp+0x70], xmm7
00007f0145be0674  vmovaps [rsp+0x80], xmm8
00007f0145be067d  vmovaps [rsp+0x90], xmm9
00007f0145be0686  vmovaps [rsp+0xA0], xmm10
00007f0145be068f  vmovaps [rsp+0xB0], xmm11
00007f0145be0698  vmovaps [rsp+0xC0], xmm12
00007f0145be06a1  vmovaps [rsp+0xD0], xmm14
00007f0145be06aa  vmovaps [rsp+0xE0], xmm15
00007f0145be06b3  sub rsp, 0x30
00007f0145be06b7  movaps [rsp], xmm13
00007f0145be06bc  movaps [rsp+0x10], xmm15
00007f0145be06c2  movaps [rsp+0x20], xmm8
00007f0145be06c8  lea rdi, [rsp]
00007f0145be06cc  mov esi, 0x00
00007f0145be06d1  mov rax, 0x636570E98530
00007f0145be06db  call rax
00007f0145be06dd  movaps xmm13, [rsp]
00007f0145be06e2  add rsp, 0x30
00007f0145be06e6  vmovaps xmm0, [rsp]
00007f0145be06eb  vmovaps xmm1, [rsp+0x10]
00007f0145be06f1  vmovaps xmm2, [rsp+0x20]
00007f0145be06f7  vmovaps xmm3, [rsp+0x30]
00007f0145be06fd  vmovaps xmm4, [rsp+0x40]
00007f0145be0703  vmovaps xmm5, [rsp+0x50]
00007f0145be0709  vmovaps xmm6, [rsp+0x60]
00007f0145be070f  vmovaps xmm7, [rsp+0x70]
00007f0145be0715  vmovaps xmm8, [rsp+0x80]
00007f0145be071e  vmovaps xmm9, [rsp+0x90]
00007f0145be0727  vmovaps xmm10, [rsp+0xA0]
00007f0145be0730  vmovaps xmm11, [rsp+0xB0]
00007f0145be0739  vmovaps xmm12, [rsp+0xC0]
00007f0145be0742  vmovaps xmm14, [rsp+0xD0]
00007f0145be074b  vmovaps xmm15, [rsp+0xE0]
00007f0145be0754  add rsp, 0xF0
00007f0145be075b  pop r11
00007f0145be075d  pop r10
00007f0145be075f  pop r9
00007f0145be0761  pop r8
00007f0145be0763  pop rsi
00007f0145be0764  pop rdi
00007f0145be0765  pop rdx
00007f0145be0766  pop rcx
00007f0145be0767  pop rax
00007f0145be0768  add rsp, 0x08
00007f0145be076c  jmp 0x00007F0145BDC60F
00007f0145be0771  sub rsp, 0x08
00007f0145be0775  push rax
00007f0145be0776  push rcx
00007f0145be0777  push rdx
00007f0145be0778  push rdi
00007f0145be0779  push rsi
00007f0145be077a  push r8
00007f0145be077c  push r9
00007f0145be077e  push r10
00007f0145be0780  push r11
00007f0145be0782  sub rsp, 0xF0
00007f0145be0789  vmovaps [rsp], xmm0
00007f0145be078e  vmovaps [rsp+0x10], xmm1
00007f0145be0794  vmovaps [rsp+0x20], xmm2
00007f0145be079a  vmovaps [rsp+0x30], xmm3
00007f0145be07a0  vmovaps [rsp+0x40], xmm4
00007f0145be07a6  vmovaps [rsp+0x50], xmm5
00007f0145be07ac  vmovaps [rsp+0x60], xmm6
00007f0145be07b2  vmovaps [rsp+0x70], xmm7
00007f0145be07b8  vmovaps [rsp+0x80], xmm9
00007f0145be07c1  vmovaps [rsp+0x90], xmm10
00007f0145be07ca  vmovaps [rsp+0xA0], xmm11
00007f0145be07d3  vmovaps [rsp+0xB0], xmm12
00007f0145be07dc  vmovaps [rsp+0xC0], xmm13
00007f0145be07e5  vmovaps [rsp+0xD0], xmm14
00007f0145be07ee  vmovaps [rsp+0xE0], xmm15
00007f0145be07f7  sub rsp, 0x30
00007f0145be07fb  movaps [rsp], xmm8
00007f0145be0800  movaps [rsp+0x10], xmm15
00007f0145be0806  movaps [rsp+0x20], xmm9
00007f0145be080c  lea rdi, [rsp]
00007f0145be0810  mov esi, 0x00
00007f0145be0815  mov rax, 0x636570E98530
00007f0145be081f  call rax
00007f0145be0821  movaps xmm8, [rsp]
00007f0145be0826  add rsp, 0x30
00007f0145be082a  vmovaps xmm0, [rsp]
00007f0145be082f  vmovaps xmm1, [rsp+0x10]
00007f0145be0835  vmovaps xmm2, [rsp+0x20]
00007f0145be083b  vmovaps xmm3, [rsp+0x30]
00007f0145be0841  vmovaps xmm4, [rsp+0x40]
00007f0145be0847  vmovaps xmm5, [rsp+0x50]
00007f0145be084d  vmovaps xmm6, [rsp+0x60]
00007f0145be0853  vmovaps xmm7, [rsp+0x70]
00007f0145be0859  vmovaps xmm9, [rsp+0x80]
00007f0145be0862  vmovaps xmm10, [rsp+0x90]
00007f0145be086b  vmovaps xmm11, [rsp+0xA0]
00007f0145be0874  vmovaps xmm12, [rsp+0xB0]
00007f0145be087d  vmovaps xmm13, [rsp+0xC0]
00007f0145be0886  vmovaps xmm14, [rsp+0xD0]
00007f0145be088f  vmovaps xmm15, [rsp+0xE0]
00007f0145be0898  add rsp, 0xF0
00007f0145be089f  pop r11
00007f0145be08a1  pop r10
00007f0145be08a3  pop r9
00007f0145be08a5  pop r8
00007f0145be08a7  pop rsi
00007f0145be08a8  pop rdi
00007f0145be08a9  pop rdx
00007f0145be08aa  pop rcx
00007f0145be08ab  pop rax
00007f0145be08ac  add rsp, 0x08
00007f0145be08b0  jmp 0x00007F0145BDC63D
00007f0145be08b5  sub rsp, 0x08
00007f0145be08b9  push rax
00007f0145be08ba  push rcx
00007f0145be08bb  push rdx
00007f0145be08bc  push rdi
00007f0145be08bd  push rsi
00007f0145be08be  push r8
00007f0145be08c0  push r9
00007f0145be08c2  push r10
00007f0145be08c4  push r11
00007f0145be08c6  sub rsp, 0xF0
00007f0145be08cd  vmovaps [rsp], xmm0
00007f0145be08d2  vmovaps [rsp+0x10], xmm1
00007f0145be08d8  vmovaps [rsp+0x20], xmm2
00007f0145be08de  vmovaps [rsp+0x30], xmm3
00007f0145be08e4  vmovaps [rsp+0x40], xmm4
00007f0145be08ea  vmovaps [rsp+0x50], xmm5
00007f0145be08f0  vmovaps [rsp+0x60], xmm6
00007f0145be08f6  vmovaps [rsp+0x70], xmm7
00007f0145be08fc  vmovaps [rsp+0x80], xmm8
00007f0145be0905  vmovaps [rsp+0x90], xmm9
00007f0145be090e  vmovaps [rsp+0xA0], xmm10
00007f0145be0917  vmovaps [rsp+0xB0], xmm11
00007f0145be0920  vmovaps [rsp+0xC0], xmm12
00007f0145be0929  vmovaps [rsp+0xD0], xmm13
00007f0145be0932  vmovaps [rsp+0xE0], xmm14
00007f0145be093b  sub rsp, 0x30
00007f0145be093f  movaps [rsp], xmm15
00007f0145be0944  movaps [rsp+0x10], xmm11
00007f0145be094a  movaps [rsp+0x20], xmm6
00007f0145be094f  lea rdi, [rsp]
00007f0145be0953  mov esi, 0x00
00007f0145be0958  mov rax, 0x636570E98530
00007f0145be0962  call rax
00007f0145be0964  movaps xmm15, [rsp]
00007f0145be0969  add rsp, 0x30
00007f0145be096d  vmovaps xmm0, [rsp]
00007f0145be0972  vmovaps xmm1, [rsp+0x10]
00007f0145be0978  vmovaps xmm2, [rsp+0x20]
00007f0145be097e  vmovaps xmm3, [rsp+0x30]
00007f0145be0984  vmovaps xmm4, [rsp+0x40]
00007f0145be098a  vmovaps xmm5, [rsp+0x50]
00007f0145be0990  vmovaps xmm6, [rsp+0x60]
00007f0145be0996  vmovaps xmm7, [rsp+0x70]
00007f0145be099c  vmovaps xmm8, [rsp+0x80]
00007f0145be09a5  vmovaps xmm9, [rsp+0x90]
00007f0145be09ae  vmovaps xmm10, [rsp+0xA0]
00007f0145be09b7  vmovaps xmm11, [rsp+0xB0]
00007f0145be09c0  vmovaps xmm12, [rsp+0xC0]
00007f0145be09c9  vmovaps xmm13, [rsp+0xD0]
00007f0145be09d2  vmovaps xmm14, [rsp+0xE0]
00007f0145be09db  add rsp, 0xF0
00007f0145be09e2  pop r11
00007f0145be09e4  pop r10
00007f0145be09e6  pop r9
00007f0145be09e8  pop r8
00007f0145be09ea  pop rsi
00007f0145be09eb  pop rdi
00007f0145be09ec  pop rdx
00007f0145be09ed  pop rcx
00007f0145be09ee  pop rax
00007f0145be09ef  add rsp, 0x08
00007f0145be09f3  jmp 0x00007F0145BDC658
00007f0145be09f8  sub rsp, 0x08
00007f0145be09fc  push rax
00007f0145be09fd  push rcx
00007f0145be09fe  push rdx
00007f0145be09ff  push rdi
00007f0145be0a00  push rsi
00007f0145be0a01  push r8
00007f0145be0a03  push r9
00007f0145be0a05  push r10
00007f0145be0a07  push r11
00007f0145be0a09  sub rsp, 0xF0
00007f0145be0a10  vmovaps [rsp], xmm0
00007f0145be0a15  vmovaps [rsp+0x10], xmm1
00007f0145be0a1b  vmovaps [rsp+0x20], xmm2
00007f0145be0a21  vmovaps [rsp+0x30], xmm3
00007f0145be0a27  vmovaps [rsp+0x40], xmm4
00007f0145be0a2d  vmovaps [rsp+0x50], xmm5
00007f0145be0a33  vmovaps [rsp+0x60], xmm6
00007f0145be0a39  vmovaps [rsp+0x70], xmm8
00007f0145be0a3f  vmovaps [rsp+0x80], xmm9
00007f0145be0a48  vmovaps [rsp+0x90], xmm10
00007f0145be0a51  vmovaps [rsp+0xA0], xmm11
00007f0145be0a5a  vmovaps [rsp+0xB0], xmm12
00007f0145be0a63  vmovaps [rsp+0xC0], xmm13
00007f0145be0a6c  vmovaps [rsp+0xD0], xmm14
00007f0145be0a75  vmovaps [rsp+0xE0], xmm15
00007f0145be0a7e  sub rsp, 0x30
00007f0145be0a82  movaps [rsp], xmm7
00007f0145be0a86  movaps [rsp+0x10], xmm11
00007f0145be0a8c  movaps [rsp+0x20], xmm9
00007f0145be0a92  lea rdi, [rsp]
00007f0145be0a96  mov esi, 0x00
00007f0145be0a9b  mov rax, 0x636570E98530
00007f0145be0aa5  call rax
00007f0145be0aa7  movaps xmm7, [rsp]
00007f0145be0aab  add rsp, 0x30
00007f0145be0aaf  vmovaps xmm0, [rsp]
00007f0145be0ab4  vmovaps xmm1, [rsp+0x10]
00007f0145be0aba  vmovaps xmm2, [rsp+0x20]
00007f0145be0ac0  vmovaps xmm3, [rsp+0x30]
00007f0145be0ac6  vmovaps xmm4, [rsp+0x40]
00007f0145be0acc  vmovaps xmm5, [rsp+0x50]
00007f0145be0ad2  vmovaps xmm6, [rsp+0x60]
00007f0145be0ad8  vmovaps xmm8, [rsp+0x70]
00007f0145be0ade  vmovaps xmm9, [rsp+0x80]
00007f0145be0ae7  vmovaps xmm10, [rsp+0x90]
00007f0145be0af0  vmovaps xmm11, [rsp+0xA0]
00007f0145be0af9  vmovaps xmm12, [rsp+0xB0]
00007f0145be0b02  vmovaps xmm13, [rsp+0xC0]
00007f0145be0b0b  vmovaps xmm14, [rsp+0xD0]
00007f0145be0b14  vmovaps xmm15, [rsp+0xE0]
00007f0145be0b1d  add rsp, 0xF0
00007f0145be0b24  pop r11
00007f0145be0b26  pop r10
00007f0145be0b28  pop r9
00007f0145be0b2a  pop r8
00007f0145be0b2c  pop rsi
00007f0145be0b2d  pop rdi
00007f0145be0b2e  pop rdx
00007f0145be0b2f  pop rcx
00007f0145be0b30  pop rax
00007f0145be0b31  add rsp, 0x08
00007f0145be0b35  jmp 0x00007F0145BDC685
00007f0145be0b3a  sub rsp, 0x08
00007f0145be0b3e  push rax
00007f0145be0b3f  push rcx
00007f0145be0b40  push rdx
00007f0145be0b41  push rdi
00007f0145be0b42  push rsi
00007f0145be0b43  push r8
00007f0145be0b45  push r9
00007f0145be0b47  push r10
00007f0145be0b49  push r11
00007f0145be0b4b  sub rsp, 0xF0
00007f0145be0b52  vmovaps [rsp], xmm0
00007f0145be0b57  vmovaps [rsp+0x10], xmm1
00007f0145be0b5d  vmovaps [rsp+0x20], xmm2
00007f0145be0b63  vmovaps [rsp+0x30], xmm3
00007f0145be0b69  vmovaps [rsp+0x40], xmm4
00007f0145be0b6f  vmovaps [rsp+0x50], xmm5
00007f0145be0b75  vmovaps [rsp+0x60], xmm6
00007f0145be0b7b  vmovaps [rsp+0x70], xmm7
00007f0145be0b81  vmovaps [rsp+0x80], xmm8
00007f0145be0b8a  vmovaps [rsp+0x90], xmm9
00007f0145be0b93  vmovaps [rsp+0xA0], xmm10
00007f0145be0b9c  vmovaps [rsp+0xB0], xmm12
00007f0145be0ba5  vmovaps [rsp+0xC0], xmm13
00007f0145be0bae  vmovaps [rsp+0xD0], xmm14
00007f0145be0bb7  vmovaps [rsp+0xE0], xmm15
00007f0145be0bc0  sub rsp, 0x30
00007f0145be0bc4  movaps [rsp], xmm11
00007f0145be0bc9  movaps [rsp+0x10], xmm10
00007f0145be0bcf  movaps [rsp+0x20], xmm14
00007f0145be0bd5  lea rdi, [rsp]
00007f0145be0bd9  mov esi, 0x00
00007f0145be0bde  mov rax, 0x636570E98530
00007f0145be0be8  call rax
00007f0145be0bea  movaps xmm11, [rsp]
00007f0145be0bef  add rsp, 0x30
00007f0145be0bf3  vmovaps xmm0, [rsp]
00007f0145be0bf8  vmovaps xmm1, [rsp+0x10]
00007f0145be0bfe  vmovaps xmm2, [rsp+0x20]
00007f0145be0c04  vmovaps xmm3, [rsp+0x30]
00007f0145be0c0a  vmovaps xmm4, [rsp+0x40]
00007f0145be0c10  vmovaps xmm5, [rsp+0x50]
00007f0145be0c16  vmovaps xmm6, [rsp+0x60]
00007f0145be0c1c  vmovaps xmm7, [rsp+0x70]
00007f0145be0c22  vmovaps xmm8, [rsp+0x80]
00007f0145be0c2b  vmovaps xmm9, [rsp+0x90]
00007f0145be0c34  vmovaps xmm10, [rsp+0xA0]
00007f0145be0c3d  vmovaps xmm12, [rsp+0xB0]
00007f0145be0c46  vmovaps xmm13, [rsp+0xC0]
00007f0145be0c4f  vmovaps xmm14, [rsp+0xD0]
00007f0145be0c58  vmovaps xmm15, [rsp+0xE0]
00007f0145be0c61  add rsp, 0xF0
00007f0145be0c68  pop r11
00007f0145be0c6a  pop r10
00007f0145be0c6c  pop r9
00007f0145be0c6e  pop r8
00007f0145be0c70  pop rsi
00007f0145be0c71  pop rdi
00007f0145be0c72  pop rdx
00007f0145be0c73  pop rcx
00007f0145be0c74  pop rax
00007f0145be0c75  add rsp, 0x08
00007f0145be0c79  jmp 0x00007F0145BDC6A0
00007f0145be0c7e  call 0x00007F0145AC33A0
00007f0145be0c83  jmp 0x00007F0145BDC6AA
00007f0145be0c88  sub rsp, 0x08
00007f0145be0c8c  push rax
00007f0145be0c8d  push rcx
00007f0145be0c8e  push rdx
00007f0145be0c8f  push rdi
00007f0145be0c90  push rsi
00007f0145be0c91  push r8
00007f0145be0c93  push r9
00007f0145be0c95  push r10
00007f0145be0c97  push r11
00007f0145be0c99  sub rsp, 0xF0
00007f0145be0ca0  vmovaps [rsp], xmm0
00007f0145be0ca5  vmovaps [rsp+0x10], xmm1
00007f0145be0cab  vmovaps [rsp+0x20], xmm2
00007f0145be0cb1  vmovaps [rsp+0x30], xmm3
00007f0145be0cb7  vmovaps [rsp+0x40], xmm4
00007f0145be0cbd  vmovaps [rsp+0x50], xmm5
00007f0145be0cc3  vmovaps [rsp+0x60], xmm6
00007f0145be0cc9  vmovaps [rsp+0x70], xmm7
00007f0145be0ccf  vmovaps [rsp+0x80], xmm8
00007f0145be0cd8  vmovaps [rsp+0x90], xmm9
00007f0145be0ce1  vmovaps [rsp+0xA0], xmm11
00007f0145be0cea  vmovaps [rsp+0xB0], xmm12
00007f0145be0cf3  vmovaps [rsp+0xC0], xmm13
00007f0145be0cfc  vmovaps [rsp+0xD0], xmm14
00007f0145be0d05  vmovaps [rsp+0xE0], xmm15
00007f0145be0d0e  sub rsp, 0x30
00007f0145be0d12  movaps [rsp], xmm10
00007f0145be0d17  movaps [rsp+0x10], xmm1
00007f0145be0d1c  movaps [rsp+0x20], xmm12
00007f0145be0d22  lea rdi, [rsp]
00007f0145be0d26  mov esi, 0x00
00007f0145be0d2b  mov rax, 0x636570E98530
00007f0145be0d35  call rax
00007f0145be0d37  movaps xmm10, [rsp]
00007f0145be0d3c  add rsp, 0x30
00007f0145be0d40  vmovaps xmm0, [rsp]
00007f0145be0d45  vmovaps xmm1, [rsp+0x10]
00007f0145be0d4b  vmovaps xmm2, [rsp+0x20]
00007f0145be0d51  vmovaps xmm3, [rsp+0x30]
00007f0145be0d57  vmovaps xmm4, [rsp+0x40]
00007f0145be0d5d  vmovaps xmm5, [rsp+0x50]
00007f0145be0d63  vmovaps xmm6, [rsp+0x60]
00007f0145be0d69  vmovaps xmm7, [rsp+0x70]
00007f0145be0d6f  vmovaps xmm8, [rsp+0x80]
00007f0145be0d78  vmovaps xmm9, [rsp+0x90]
00007f0145be0d81  vmovaps xmm11, [rsp+0xA0]
00007f0145be0d8a  vmovaps xmm12, [rsp+0xB0]
00007f0145be0d93  vmovaps xmm13, [rsp+0xC0]
00007f0145be0d9c  vmovaps xmm14, [rsp+0xD0]
00007f0145be0da5  vmovaps xmm15, [rsp+0xE0]
00007f0145be0dae  add rsp, 0xF0
00007f0145be0db5  pop r11
00007f0145be0db7  pop r10
00007f0145be0db9  pop r9
00007f0145be0dbb  pop r8
00007f0145be0dbd  pop rsi
00007f0145be0dbe  pop rdi
00007f0145be0dbf  pop rdx
00007f0145be0dc0  pop rcx
00007f0145be0dc1  pop rax
00007f0145be0dc2  add rsp, 0x08
00007f0145be0dc6  jmp 0x00007F0145BDC6CD
00007f0145be0dcb  sub rsp, 0x08
00007f0145be0dcf  push rax
00007f0145be0dd0  push rcx
00007f0145be0dd1  push rdx
00007f0145be0dd2  push rdi
00007f0145be0dd3  push rsi
00007f0145be0dd4  push r8
00007f0145be0dd6  push r9
00007f0145be0dd8  push r10
00007f0145be0dda  push r11
00007f0145be0ddc  sub rsp, 0xF0
00007f0145be0de3  vmovaps [rsp], xmm0
00007f0145be0de8  vmovaps [rsp+0x10], xmm1
00007f0145be0dee  vmovaps [rsp+0x20], xmm2
00007f0145be0df4  vmovaps [rsp+0x30], xmm3
00007f0145be0dfa  vmovaps [rsp+0x40], xmm4
00007f0145be0e00  vmovaps [rsp+0x50], xmm5
00007f0145be0e06  vmovaps [rsp+0x60], xmm6
00007f0145be0e0c  vmovaps [rsp+0x70], xmm7
00007f0145be0e12  vmovaps [rsp+0x80], xmm8
00007f0145be0e1b  vmovaps [rsp+0x90], xmm9
00007f0145be0e24  vmovaps [rsp+0xA0], xmm10
00007f0145be0e2d  vmovaps [rsp+0xB0], xmm11
00007f0145be0e36  vmovaps [rsp+0xC0], xmm13
00007f0145be0e3f  vmovaps [rsp+0xD0], xmm14
00007f0145be0e48  vmovaps [rsp+0xE0], xmm15
00007f0145be0e51  sub rsp, 0x30
00007f0145be0e55  movaps [rsp], xmm12
00007f0145be0e5a  movaps [rsp+0x10], xmm14
00007f0145be0e60  movaps [rsp+0x20], xmm1
00007f0145be0e65  lea rdi, [rsp]
00007f0145be0e69  mov esi, 0x00
00007f0145be0e6e  mov rax, 0x636570E98530
00007f0145be0e78  call rax
00007f0145be0e7a  movaps xmm12, [rsp]
00007f0145be0e7f  add rsp, 0x30
00007f0145be0e83  vmovaps xmm0, [rsp]
00007f0145be0e88  vmovaps xmm1, [rsp+0x10]
00007f0145be0e8e  vmovaps xmm2, [rsp+0x20]
00007f0145be0e94  vmovaps xmm3, [rsp+0x30]
00007f0145be0e9a  vmovaps xmm4, [rsp+0x40]
00007f0145be0ea0  vmovaps xmm5, [rsp+0x50]
00007f0145be0ea6  vmovaps xmm6, [rsp+0x60]
00007f0145be0eac  vmovaps xmm7, [rsp+0x70]
00007f0145be0eb2  vmovaps xmm8, [rsp+0x80]
00007f0145be0ebb  vmovaps xmm9, [rsp+0x90]
00007f0145be0ec4  vmovaps xmm10, [rsp+0xA0]
00007f0145be0ecd  vmovaps xmm11, [rsp+0xB0]
00007f0145be0ed6  vmovaps xmm13, [rsp+0xC0]
00007f0145be0edf  vmovaps xmm14, [rsp+0xD0]
00007f0145be0ee8  vmovaps xmm15, [rsp+0xE0]
00007f0145be0ef1  add rsp, 0xF0
00007f0145be0ef8  pop r11
00007f0145be0efa  pop r10
00007f0145be0efc  pop r9
00007f0145be0efe  pop r8
00007f0145be0f00  pop rsi
00007f0145be0f01  pop rdi
00007f0145be0f02  pop rdx
00007f0145be0f03  pop rcx
00007f0145be0f04  pop rax
00007f0145be0f05  add rsp, 0x08
00007f0145be0f09  jmp 0x00007F0145BDC6FC
00007f0145be0f0e  sub rsp, 0x08
00007f0145be0f12  push rax
00007f0145be0f13  push rcx
00007f0145be0f14  push rdx
00007f0145be0f15  push rdi
00007f0145be0f16  push rsi
00007f0145be0f17  push r8
00007f0145be0f19  push r9
00007f0145be0f1b  push r10
00007f0145be0f1d  push r11
00007f0145be0f1f  sub rsp, 0xF0
00007f0145be0f26  vmovaps [rsp], xmm0
00007f0145be0f2b  vmovaps [rsp+0x10], xmm1
00007f0145be0f31  vmovaps [rsp+0x20], xmm2
00007f0145be0f37  vmovaps [rsp+0x30], xmm3
00007f0145be0f3d  vmovaps [rsp+0x40], xmm4
00007f0145be0f43  vmovaps [rsp+0x50], xmm5
00007f0145be0f49  vmovaps [rsp+0x60], xmm6
00007f0145be0f4f  vmovaps [rsp+0x70], xmm7
00007f0145be0f55  vmovaps [rsp+0x80], xmm8
00007f0145be0f5e  vmovaps [rsp+0x90], xmm9
00007f0145be0f67  vmovaps [rsp+0xA0], xmm10
00007f0145be0f70  vmovaps [rsp+0xB0], xmm11
00007f0145be0f79  vmovaps [rsp+0xC0], xmm12
00007f0145be0f82  vmovaps [rsp+0xD0], xmm13
00007f0145be0f8b  vmovaps [rsp+0xE0], xmm15
00007f0145be0f94  sub rsp, 0x30
00007f0145be0f98  movaps [rsp], xmm14
00007f0145be0f9d  movaps [rsp+0x10], xmm9
00007f0145be0fa3  movaps [rsp+0x20], xmm1
00007f0145be0fa8  lea rdi, [rsp]
00007f0145be0fac  mov esi, 0x00
00007f0145be0fb1  mov rax, 0x636570E98530
00007f0145be0fbb  call rax
00007f0145be0fbd  movaps xmm14, [rsp]
00007f0145be0fc2  add rsp, 0x30
00007f0145be0fc6  vmovaps xmm0, [rsp]
00007f0145be0fcb  vmovaps xmm1, [rsp+0x10]
00007f0145be0fd1  vmovaps xmm2, [rsp+0x20]
00007f0145be0fd7  vmovaps xmm3, [rsp+0x30]
00007f0145be0fdd  vmovaps xmm4, [rsp+0x40]
00007f0145be0fe3  vmovaps xmm5, [rsp+0x50]
00007f0145be0fe9  vmovaps xmm6, [rsp+0x60]
00007f0145be0fef  vmovaps xmm7, [rsp+0x70]
00007f0145be0ff5  vmovaps xmm8, [rsp+0x80]
00007f0145be0ffe  vmovaps xmm9, [rsp+0x90]
00007f0145be1007  vmovaps xmm10, [rsp+0xA0]
00007f0145be1010  vmovaps xmm11, [rsp+0xB0]
00007f0145be1019  vmovaps xmm12, [rsp+0xC0]
00007f0145be1022  vmovaps xmm13, [rsp+0xD0]
00007f0145be102b  vmovaps xmm15, [rsp+0xE0]
00007f0145be1034  add rsp, 0xF0
00007f0145be103b  pop r11
00007f0145be103d  pop r10
00007f0145be103f  pop r9
00007f0145be1041  pop r8
00007f0145be1043  pop rsi
00007f0145be1044  pop rdi
00007f0145be1045  pop rdx
00007f0145be1046  pop rcx
00007f0145be1047  pop rax
00007f0145be1048  add rsp, 0x08
00007f0145be104c  jmp 0x00007F0145BDC72B
00007f0145be1051  sub rsp, 0x08
00007f0145be1055  push rax
00007f0145be1056  push rcx
00007f0145be1057  push rdx
00007f0145be1058  push rdi
00007f0145be1059  push rsi
00007f0145be105a  push r8
00007f0145be105c  push r9
00007f0145be105e  push r10
00007f0145be1060  push r11
00007f0145be1062  sub rsp, 0xF0
00007f0145be1069  vmovaps [rsp], xmm0
00007f0145be106e  vmovaps [rsp+0x10], xmm2
00007f0145be1074  vmovaps [rsp+0x20], xmm3
00007f0145be107a  vmovaps [rsp+0x30], xmm4
00007f0145be1080  vmovaps [rsp+0x40], xmm5
00007f0145be1086  vmovaps [rsp+0x50], xmm6
00007f0145be108c  vmovaps [rsp+0x60], xmm7
00007f0145be1092  vmovaps [rsp+0x70], xmm8
00007f0145be1098  vmovaps [rsp+0x80], xmm9
00007f0145be10a1  vmovaps [rsp+0x90], xmm10
00007f0145be10aa  vmovaps [rsp+0xA0], xmm11
00007f0145be10b3  vmovaps [rsp+0xB0], xmm12
00007f0145be10bc  vmovaps [rsp+0xC0], xmm13
00007f0145be10c5  vmovaps [rsp+0xD0], xmm14
00007f0145be10ce  vmovaps [rsp+0xE0], xmm15
00007f0145be10d7  sub rsp, 0x30
00007f0145be10db  movaps [rsp], xmm1
00007f0145be10df  movaps [rsp+0x10], xmm13
00007f0145be10e5  movaps [rsp+0x20], xmm8
00007f0145be10eb  lea rdi, [rsp]
00007f0145be10ef  mov esi, 0x00
00007f0145be10f4  mov rax, 0x636570E98530
00007f0145be10fe  call rax
00007f0145be1100  movaps xmm1, [rsp]
00007f0145be1104  add rsp, 0x30
00007f0145be1108  vmovaps xmm0, [rsp]
00007f0145be110d  vmovaps xmm2, [rsp+0x10]
00007f0145be1113  vmovaps xmm3, [rsp+0x20]
00007f0145be1119  vmovaps xmm4, [rsp+0x30]
00007f0145be111f  vmovaps xmm5, [rsp+0x40]
00007f0145be1125  vmovaps xmm6, [rsp+0x50]
00007f0145be112b  vmovaps xmm7, [rsp+0x60]
00007f0145be1131  vmovaps xmm8, [rsp+0x70]
00007f0145be1137  vmovaps xmm9, [rsp+0x80]
00007f0145be1140  vmovaps xmm10, [rsp+0x90]
00007f0145be1149  vmovaps xmm11, [rsp+0xA0]
00007f0145be1152  vmovaps xmm12, [rsp+0xB0]
00007f0145be115b  vmovaps xmm13, [rsp+0xC0]
00007f0145be1164  vmovaps xmm14, [rsp+0xD0]
00007f0145be116d  vmovaps xmm15, [rsp+0xE0]
00007f0145be1176  add rsp, 0xF0
00007f0145be117d  pop r11
00007f0145be117f  pop r10
00007f0145be1181  pop r9
00007f0145be1183  pop r8
00007f0145be1185  pop rsi
00007f0145be1186  pop rdi
00007f0145be1187  pop rdx
00007f0145be1188  pop rcx
00007f0145be1189  pop rax
00007f0145be118a  add rsp, 0x08
00007f0145be118e  jmp 0x00007F0145BDC74D
00007f0145be1193  call 0x00007F0145A0C260
00007f0145be1198  jmp 0x00007F0145BDC75B
00007f0145be119d  call 0x00007F0145ABD750
00007f0145be11a2  jmp 0x00007F0145BDC765
00007f0145be11a7  sub rsp, 0x08
00007f0145be11ab  push rax
00007f0145be11ac  push rcx
00007f0145be11ad  push rdx
00007f0145be11ae  push rdi
00007f0145be11af  push rsi
00007f0145be11b0  push r8
00007f0145be11b2  push r9
00007f0145be11b4  push r10
00007f0145be11b6  push r11
00007f0145be11b8  sub rsp, 0xF0
00007f0145be11bf  vmovaps [rsp], xmm0
00007f0145be11c4  vmovaps [rsp+0x10], xmm1
00007f0145be11ca  vmovaps [rsp+0x20], xmm2
00007f0145be11d0  vmovaps [rsp+0x30], xmm3
00007f0145be11d6  vmovaps [rsp+0x40], xmm4
00007f0145be11dc  vmovaps [rsp+0x50], xmm5
00007f0145be11e2  vmovaps [rsp+0x60], xmm6
00007f0145be11e8  vmovaps [rsp+0x70], xmm7
00007f0145be11ee  vmovaps [rsp+0x80], xmm9
00007f0145be11f7  vmovaps [rsp+0x90], xmm10
00007f0145be1200  vmovaps [rsp+0xA0], xmm11
00007f0145be1209  vmovaps [rsp+0xB0], xmm12
00007f0145be1212  vmovaps [rsp+0xC0], xmm13
00007f0145be121b  vmovaps [rsp+0xD0], xmm14
00007f0145be1224  vmovaps [rsp+0xE0], xmm15
00007f0145be122d  sub rsp, 0x30
00007f0145be1231  movaps [rsp], xmm8
00007f0145be1236  movaps [rsp+0x10], xmm15
00007f0145be123c  movaps [rsp+0x20], xmm7
00007f0145be1241  lea rdi, [rsp]
00007f0145be1245  mov esi, 0x00
00007f0145be124a  mov rax, 0x636570E98530
00007f0145be1254  call rax
00007f0145be1256  movaps xmm8, [rsp]
00007f0145be125b  add rsp, 0x30
00007f0145be125f  vmovaps xmm0, [rsp]
00007f0145be1264  vmovaps xmm1, [rsp+0x10]
00007f0145be126a  vmovaps xmm2, [rsp+0x20]
00007f0145be1270  vmovaps xmm3, [rsp+0x30]
00007f0145be1276  vmovaps xmm4, [rsp+0x40]
00007f0145be127c  vmovaps xmm5, [rsp+0x50]
00007f0145be1282  vmovaps xmm6, [rsp+0x60]
00007f0145be1288  vmovaps xmm7, [rsp+0x70]
00007f0145be128e  vmovaps xmm9, [rsp+0x80]
00007f0145be1297  vmovaps xmm10, [rsp+0x90]
00007f0145be12a0  vmovaps xmm11, [rsp+0xA0]
00007f0145be12a9  vmovaps xmm12, [rsp+0xB0]
00007f0145be12b2  vmovaps xmm13, [rsp+0xC0]
00007f0145be12bb  vmovaps xmm14, [rsp+0xD0]
00007f0145be12c4  vmovaps xmm15, [rsp+0xE0]
00007f0145be12cd  add rsp, 0xF0
00007f0145be12d4  pop r11
00007f0145be12d6  pop r10
00007f0145be12d8  pop r9
00007f0145be12da  pop r8
00007f0145be12dc  pop rsi
00007f0145be12dd  pop rdi
00007f0145be12de  pop rdx
00007f0145be12df  pop rcx
00007f0145be12e0  pop rax
00007f0145be12e1  add rsp, 0x08
00007f0145be12e5  jmp 0x00007F0145BDC787
00007f0145be12ea  sub rsp, 0x08
00007f0145be12ee  push rax
00007f0145be12ef  push rcx
00007f0145be12f0  push rdx
00007f0145be12f1  push rdi
00007f0145be12f2  push rsi
00007f0145be12f3  push r8
00007f0145be12f5  push r9
00007f0145be12f7  push r10
00007f0145be12f9  push r11
00007f0145be12fb  sub rsp, 0xF0
00007f0145be1302  vmovaps [rsp], xmm0
00007f0145be1307  vmovaps [rsp+0x10], xmm1
00007f0145be130d  vmovaps [rsp+0x20], xmm2
00007f0145be1313  vmovaps [rsp+0x30], xmm3
00007f0145be1319  vmovaps [rsp+0x40], xmm4
00007f0145be131f  vmovaps [rsp+0x50], xmm5
00007f0145be1325  vmovaps [rsp+0x60], xmm6
00007f0145be132b  vmovaps [rsp+0x70], xmm8
00007f0145be1331  vmovaps [rsp+0x80], xmm9
00007f0145be133a  vmovaps [rsp+0x90], xmm10
00007f0145be1343  vmovaps [rsp+0xA0], xmm11
00007f0145be134c  vmovaps [rsp+0xB0], xmm12
00007f0145be1355  vmovaps [rsp+0xC0], xmm13
00007f0145be135e  vmovaps [rsp+0xD0], xmm14
00007f0145be1367  vmovaps [rsp+0xE0], xmm15
00007f0145be1370  sub rsp, 0x30
00007f0145be1374  movaps [rsp], xmm7
00007f0145be1378  movaps [rsp+0x10], xmm9
00007f0145be137e  movaps [rsp+0x20], xmm15
00007f0145be1384  lea rdi, [rsp]
00007f0145be1388  mov esi, 0x00
00007f0145be138d  mov rax, 0x636570E98530
00007f0145be1397  call rax
00007f0145be1399  movaps xmm7, [rsp]
00007f0145be139d  add rsp, 0x30
00007f0145be13a1  vmovaps xmm0, [rsp]
00007f0145be13a6  vmovaps xmm1, [rsp+0x10]
00007f0145be13ac  vmovaps xmm2, [rsp+0x20]
00007f0145be13b2  vmovaps xmm3, [rsp+0x30]
00007f0145be13b8  vmovaps xmm4, [rsp+0x40]
00007f0145be13be  vmovaps xmm5, [rsp+0x50]
00007f0145be13c4  vmovaps xmm6, [rsp+0x60]
00007f0145be13ca  vmovaps xmm8, [rsp+0x70]
00007f0145be13d0  vmovaps xmm9, [rsp+0x80]
00007f0145be13d9  vmovaps xmm10, [rsp+0x90]
00007f0145be13e2  vmovaps xmm11, [rsp+0xA0]
00007f0145be13eb  vmovaps xmm12, [rsp+0xB0]
00007f0145be13f4  vmovaps xmm13, [rsp+0xC0]
00007f0145be13fd  vmovaps xmm14, [rsp+0xD0]
00007f0145be1406  vmovaps xmm15, [rsp+0xE0]
00007f0145be140f  add rsp, 0xF0
00007f0145be1416  pop r11
00007f0145be1418  pop r10
00007f0145be141a  pop r9
00007f0145be141c  pop r8
00007f0145be141e  pop rsi
00007f0145be141f  pop rdi
00007f0145be1420  pop rdx
00007f0145be1421  pop rcx
00007f0145be1422  pop rax
00007f0145be1423  add rsp, 0x08
00007f0145be1427  jmp 0x00007F0145BDC7B4
00007f0145be142c  sub rsp, 0x08
00007f0145be1430  push rax
00007f0145be1431  push rcx
00007f0145be1432  push rdx
00007f0145be1433  push rdi
00007f0145be1434  push rsi
00007f0145be1435  push r8
00007f0145be1437  push r9
00007f0145be1439  push r10
00007f0145be143b  push r11
00007f0145be143d  sub rsp, 0xF0
00007f0145be1444  vmovaps [rsp], xmm0
00007f0145be1449  vmovaps [rsp+0x10], xmm1
00007f0145be144f  vmovaps [rsp+0x20], xmm2
00007f0145be1455  vmovaps [rsp+0x30], xmm3
00007f0145be145b  vmovaps [rsp+0x40], xmm4
00007f0145be1461  vmovaps [rsp+0x50], xmm5
00007f0145be1467  vmovaps [rsp+0x60], xmm6
00007f0145be146d  vmovaps [rsp+0x70], xmm7
00007f0145be1473  vmovaps [rsp+0x80], xmm8
00007f0145be147c  vmovaps [rsp+0x90], xmm10
00007f0145be1485  vmovaps [rsp+0xA0], xmm11
00007f0145be148e  vmovaps [rsp+0xB0], xmm12
00007f0145be1497  vmovaps [rsp+0xC0], xmm13
00007f0145be14a0  vmovaps [rsp+0xD0], xmm14
00007f0145be14a9  vmovaps [rsp+0xE0], xmm15
00007f0145be14b2  sub rsp, 0x30
00007f0145be14b6  movaps [rsp], xmm9
00007f0145be14bb  movaps [rsp+0x10], xmm13
00007f0145be14c1  movaps [rsp+0x20], xmm15
00007f0145be14c7  lea rdi, [rsp]
00007f0145be14cb  mov esi, 0x00
00007f0145be14d0  mov rax, 0x636570E98530
00007f0145be14da  call rax
00007f0145be14dc  movaps xmm9, [rsp]
00007f0145be14e1  add rsp, 0x30
00007f0145be14e5  vmovaps xmm0, [rsp]
00007f0145be14ea  vmovaps xmm1, [rsp+0x10]
00007f0145be14f0  vmovaps xmm2, [rsp+0x20]
00007f0145be14f6  vmovaps xmm3, [rsp+0x30]
00007f0145be14fc  vmovaps xmm4, [rsp+0x40]
00007f0145be1502  vmovaps xmm5, [rsp+0x50]
00007f0145be1508  vmovaps xmm6, [rsp+0x60]
00007f0145be150e  vmovaps xmm7, [rsp+0x70]
00007f0145be1514  vmovaps xmm8, [rsp+0x80]
00007f0145be151d  vmovaps xmm10, [rsp+0x90]
00007f0145be1526  vmovaps xmm11, [rsp+0xA0]
00007f0145be152f  vmovaps xmm12, [rsp+0xB0]
00007f0145be1538  vmovaps xmm13, [rsp+0xC0]
00007f0145be1541  vmovaps xmm14, [rsp+0xD0]
00007f0145be154a  vmovaps xmm15, [rsp+0xE0]
00007f0145be1553  add rsp, 0xF0
00007f0145be155a  pop r11
00007f0145be155c  pop r10
00007f0145be155e  pop r9
00007f0145be1560  pop r8
00007f0145be1562  pop rsi
00007f0145be1563  pop rdi
00007f0145be1564  pop rdx
00007f0145be1565  pop rcx
00007f0145be1566  pop rax
00007f0145be1567  add rsp, 0x08
00007f0145be156b  jmp 0x00007F0145BDC7E2
00007f0145be1570  sub rsp, 0x08
00007f0145be1574  push rax
00007f0145be1575  push rcx
00007f0145be1576  push rdx
00007f0145be1577  push rdi
00007f0145be1578  push rsi
00007f0145be1579  push r8
00007f0145be157b  push r9
00007f0145be157d  push r10
00007f0145be157f  push r11
00007f0145be1581  sub rsp, 0xF0
00007f0145be1588  vmovaps [rsp], xmm0
00007f0145be158d  vmovaps [rsp+0x10], xmm1
00007f0145be1593  vmovaps [rsp+0x20], xmm2
00007f0145be1599  vmovaps [rsp+0x30], xmm3
00007f0145be159f  vmovaps [rsp+0x40], xmm4
00007f0145be15a5  vmovaps [rsp+0x50], xmm5
00007f0145be15ab  vmovaps [rsp+0x60], xmm6
00007f0145be15b1  vmovaps [rsp+0x70], xmm7
00007f0145be15b7  vmovaps [rsp+0x80], xmm8
00007f0145be15c0  vmovaps [rsp+0x90], xmm9
00007f0145be15c9  vmovaps [rsp+0xA0], xmm10
00007f0145be15d2  vmovaps [rsp+0xB0], xmm11
00007f0145be15db  vmovaps [rsp+0xC0], xmm12
00007f0145be15e4  vmovaps [rsp+0xD0], xmm13
00007f0145be15ed  vmovaps [rsp+0xE0], xmm14
00007f0145be15f6  sub rsp, 0x30
00007f0145be15fa  movaps [rsp], xmm15
00007f0145be15ff  movaps [rsp+0x10], xmm11
00007f0145be1605  movaps [rsp+0x20], xmm12
00007f0145be160b  lea rdi, [rsp]
00007f0145be160f  mov esi, 0x00
00007f0145be1614  mov rax, 0x636570E98530
00007f0145be161e  call rax
00007f0145be1620  movaps xmm15, [rsp]
00007f0145be1625  add rsp, 0x30
00007f0145be1629  vmovaps xmm0, [rsp]
00007f0145be162e  vmovaps xmm1, [rsp+0x10]
00007f0145be1634  vmovaps xmm2, [rsp+0x20]
00007f0145be163a  vmovaps xmm3, [rsp+0x30]
00007f0145be1640  vmovaps xmm4, [rsp+0x40]
00007f0145be1646  vmovaps xmm5, [rsp+0x50]
00007f0145be164c  vmovaps xmm6, [rsp+0x60]
00007f0145be1652  vmovaps xmm7, [rsp+0x70]
00007f0145be1658  vmovaps xmm8, [rsp+0x80]
00007f0145be1661  vmovaps xmm9, [rsp+0x90]
00007f0145be166a  vmovaps xmm10, [rsp+0xA0]
00007f0145be1673  vmovaps xmm11, [rsp+0xB0]
00007f0145be167c  vmovaps xmm12, [rsp+0xC0]
00007f0145be1685  vmovaps xmm13, [rsp+0xD0]
00007f0145be168e  vmovaps xmm14, [rsp+0xE0]
00007f0145be1697  add rsp, 0xF0
00007f0145be169e  pop r11
00007f0145be16a0  pop r10
00007f0145be16a2  pop r9
00007f0145be16a4  pop r8
00007f0145be16a6  pop rsi
00007f0145be16a7  pop rdi
00007f0145be16a8  pop rdx
00007f0145be16a9  pop rcx
00007f0145be16aa  pop rax
00007f0145be16ab  add rsp, 0x08
00007f0145be16af  jmp 0x00007F0145BDC7FD
00007f0145be16b4  sub rsp, 0x08
00007f0145be16b8  push rax
00007f0145be16b9  push rcx
00007f0145be16ba  push rdx
00007f0145be16bb  push rdi
00007f0145be16bc  push rsi
00007f0145be16bd  push r8
00007f0145be16bf  push r9
00007f0145be16c1  push r10
00007f0145be16c3  push r11
00007f0145be16c5  sub rsp, 0xF0
00007f0145be16cc  vmovaps [rsp], xmm0
00007f0145be16d1  vmovaps [rsp+0x10], xmm1
00007f0145be16d7  vmovaps [rsp+0x20], xmm2
00007f0145be16dd  vmovaps [rsp+0x30], xmm3
00007f0145be16e3  vmovaps [rsp+0x40], xmm4
00007f0145be16e9  vmovaps [rsp+0x50], xmm5
00007f0145be16ef  vmovaps [rsp+0x60], xmm6
00007f0145be16f5  vmovaps [rsp+0x70], xmm7
00007f0145be16fb  vmovaps [rsp+0x80], xmm8
00007f0145be1704  vmovaps [rsp+0x90], xmm9
00007f0145be170d  vmovaps [rsp+0xA0], xmm10
00007f0145be1716  vmovaps [rsp+0xB0], xmm11
00007f0145be171f  vmovaps [rsp+0xC0], xmm12
00007f0145be1728  vmovaps [rsp+0xD0], xmm14
00007f0145be1731  vmovaps [rsp+0xE0], xmm15
00007f0145be173a  sub rsp, 0x30
00007f0145be173e  movaps [rsp], xmm13
00007f0145be1743  movaps [rsp+0x10], xmm10
00007f0145be1749  movaps [rsp+0x20], xmm14
00007f0145be174f  lea rdi, [rsp]
00007f0145be1753  mov esi, 0x00
00007f0145be1758  mov rax, 0x636570E98530
00007f0145be1762  call rax
00007f0145be1764  movaps xmm13, [rsp]
00007f0145be1769  add rsp, 0x30
00007f0145be176d  vmovaps xmm0, [rsp]
00007f0145be1772  vmovaps xmm1, [rsp+0x10]
00007f0145be1778  vmovaps xmm2, [rsp+0x20]
00007f0145be177e  vmovaps xmm3, [rsp+0x30]
00007f0145be1784  vmovaps xmm4, [rsp+0x40]
00007f0145be178a  vmovaps xmm5, [rsp+0x50]
00007f0145be1790  vmovaps xmm6, [rsp+0x60]
00007f0145be1796  vmovaps xmm7, [rsp+0x70]
00007f0145be179c  vmovaps xmm8, [rsp+0x80]
00007f0145be17a5  vmovaps xmm9, [rsp+0x90]
00007f0145be17ae  vmovaps xmm10, [rsp+0xA0]
00007f0145be17b7  vmovaps xmm11, [rsp+0xB0]
00007f0145be17c0  vmovaps xmm12, [rsp+0xC0]
00007f0145be17c9  vmovaps xmm14, [rsp+0xD0]
00007f0145be17d2  vmovaps xmm15, [rsp+0xE0]
00007f0145be17db  add rsp, 0xF0
00007f0145be17e2  pop r11
00007f0145be17e4  pop r10
00007f0145be17e6  pop r9
00007f0145be17e8  pop r8
00007f0145be17ea  pop rsi
00007f0145be17eb  pop rdi
00007f0145be17ec  pop rdx
00007f0145be17ed  pop rcx
00007f0145be17ee  pop rax
00007f0145be17ef  add rsp, 0x08
00007f0145be17f3  jmp 0x00007F0145BDC820
00007f0145be17f8  sub rsp, 0x08
00007f0145be17fc  push rax
00007f0145be17fd  push rcx
00007f0145be17fe  push rdx
00007f0145be17ff  push rdi
00007f0145be1800  push rsi
00007f0145be1801  push r8
00007f0145be1803  push r9
00007f0145be1805  push r10
00007f0145be1807  push r11
00007f0145be1809  sub rsp, 0xF0
00007f0145be1810  vmovaps [rsp], xmm0
00007f0145be1815  vmovaps [rsp+0x10], xmm1
00007f0145be181b  vmovaps [rsp+0x20], xmm2
00007f0145be1821  vmovaps [rsp+0x30], xmm3
00007f0145be1827  vmovaps [rsp+0x40], xmm4
00007f0145be182d  vmovaps [rsp+0x50], xmm5
00007f0145be1833  vmovaps [rsp+0x60], xmm6
00007f0145be1839  vmovaps [rsp+0x70], xmm7
00007f0145be183f  vmovaps [rsp+0x80], xmm8
00007f0145be1848  vmovaps [rsp+0x90], xmm9
00007f0145be1851  vmovaps [rsp+0xA0], xmm10
00007f0145be185a  vmovaps [rsp+0xB0], xmm11
00007f0145be1863  vmovaps [rsp+0xC0], xmm12
00007f0145be186c  vmovaps [rsp+0xD0], xmm13
00007f0145be1875  vmovaps [rsp+0xE0], xmm15
00007f0145be187e  sub rsp, 0x30
00007f0145be1882  movaps [rsp], xmm14
00007f0145be1887  movaps [rsp+0x10], xmm1
00007f0145be188c  movaps [rsp+0x20], xmm7
00007f0145be1891  lea rdi, [rsp]
00007f0145be1895  mov esi, 0x00
00007f0145be189a  mov rax, 0x636570E98530
00007f0145be18a4  call rax
00007f0145be18a6  movaps xmm14, [rsp]
00007f0145be18ab  add rsp, 0x30
00007f0145be18af  vmovaps xmm0, [rsp]
00007f0145be18b4  vmovaps xmm1, [rsp+0x10]
00007f0145be18ba  vmovaps xmm2, [rsp+0x20]
00007f0145be18c0  vmovaps xmm3, [rsp+0x30]
00007f0145be18c6  vmovaps xmm4, [rsp+0x40]
00007f0145be18cc  vmovaps xmm5, [rsp+0x50]
00007f0145be18d2  vmovaps xmm6, [rsp+0x60]
00007f0145be18d8  vmovaps xmm7, [rsp+0x70]
00007f0145be18de  vmovaps xmm8, [rsp+0x80]
00007f0145be18e7  vmovaps xmm9, [rsp+0x90]
00007f0145be18f0  vmovaps xmm10, [rsp+0xA0]
00007f0145be18f9  vmovaps xmm11, [rsp+0xB0]
00007f0145be1902  vmovaps xmm12, [rsp+0xC0]
00007f0145be190b  vmovaps xmm13, [rsp+0xD0]
00007f0145be1914  vmovaps xmm15, [rsp+0xE0]
00007f0145be191d  add rsp, 0xF0
00007f0145be1924  pop r11
00007f0145be1926  pop r10
00007f0145be1928  pop r9
00007f0145be192a  pop r8
00007f0145be192c  pop rsi
00007f0145be192d  pop rdi
00007f0145be192e  pop rdx
00007f0145be192f  pop rcx
00007f0145be1930  pop rax
00007f0145be1931  add rsp, 0x08
00007f0145be1935  jmp 0x00007F0145BDC843
00007f0145be193a  sub rsp, 0x08
00007f0145be193e  push rax
00007f0145be193f  push rcx
00007f0145be1940  push rdx
00007f0145be1941  push rdi
00007f0145be1942  push rsi
00007f0145be1943  push r8
00007f0145be1945  push r9
00007f0145be1947  push r10
00007f0145be1949  push r11
00007f0145be194b  sub rsp, 0xF0
00007f0145be1952  vmovaps [rsp], xmm0
00007f0145be1957  vmovaps [rsp+0x10], xmm2
00007f0145be195d  vmovaps [rsp+0x20], xmm3
00007f0145be1963  vmovaps [rsp+0x30], xmm4
00007f0145be1969  vmovaps [rsp+0x40], xmm5
00007f0145be196f  vmovaps [rsp+0x50], xmm6
00007f0145be1975  vmovaps [rsp+0x60], xmm7
00007f0145be197b  vmovaps [rsp+0x70], xmm8
00007f0145be1981  vmovaps [rsp+0x80], xmm9
00007f0145be198a  vmovaps [rsp+0x90], xmm10
00007f0145be1993  vmovaps [rsp+0xA0], xmm11
00007f0145be199c  vmovaps [rsp+0xB0], xmm12
00007f0145be19a5  vmovaps [rsp+0xC0], xmm13
00007f0145be19ae  vmovaps [rsp+0xD0], xmm14
00007f0145be19b7  vmovaps [rsp+0xE0], xmm15
00007f0145be19c0  sub rsp, 0x30
00007f0145be19c4  movaps [rsp], xmm1
00007f0145be19c8  movaps [rsp+0x10], xmm8
00007f0145be19ce  movaps [rsp+0x20], xmm9
00007f0145be19d4  lea rdi, [rsp]
00007f0145be19d8  mov esi, 0x00
00007f0145be19dd  mov rax, 0x636570E98530
00007f0145be19e7  call rax
00007f0145be19e9  movaps xmm1, [rsp]
00007f0145be19ed  add rsp, 0x30
00007f0145be19f1  vmovaps xmm0, [rsp]
00007f0145be19f6  vmovaps xmm2, [rsp+0x10]
00007f0145be19fc  vmovaps xmm3, [rsp+0x20]
00007f0145be1a02  vmovaps xmm4, [rsp+0x30]
00007f0145be1a08  vmovaps xmm5, [rsp+0x40]
00007f0145be1a0e  vmovaps xmm6, [rsp+0x50]
00007f0145be1a14  vmovaps xmm7, [rsp+0x60]
00007f0145be1a1a  vmovaps xmm8, [rsp+0x70]
00007f0145be1a20  vmovaps xmm9, [rsp+0x80]
00007f0145be1a29  vmovaps xmm10, [rsp+0x90]
00007f0145be1a32  vmovaps xmm11, [rsp+0xA0]
00007f0145be1a3b  vmovaps xmm12, [rsp+0xB0]
00007f0145be1a44  vmovaps xmm13, [rsp+0xC0]
00007f0145be1a4d  vmovaps xmm14, [rsp+0xD0]
00007f0145be1a56  vmovaps xmm15, [rsp+0xE0]
00007f0145be1a5f  add rsp, 0xF0
00007f0145be1a66  pop r11
00007f0145be1a68  pop r10
00007f0145be1a6a  pop r9
00007f0145be1a6c  pop r8
00007f0145be1a6e  pop rsi
00007f0145be1a6f  pop rdi
00007f0145be1a70  pop rdx
00007f0145be1a71  pop rcx
00007f0145be1a72  pop rax
00007f0145be1a73  add rsp, 0x08
00007f0145be1a77  jmp 0x00007F0145BDC865
00007f0145be1a7c  call 0x00007F0145AE5940
00007f0145be1a81  jmp 0x00007F0145BDC873
00007f0145be1a86  call 0x00007F0145A0C380
00007f0145be1a8b  jmp 0x00007F0145BDC87D
00007f0145be1a90  call 0x00007F0145A0D600
00007f0145be1a95  jmp 0x00007F0145BDC887
00007f0145be1a9a  call 0x00007F01459FF540
00007f0145be1a9f  jmp 0x00007F0145BDC891
00007f0145be1aa4  int3
00007f0145be1aa5  nop [rax+rax*1], ax
00007f0145be1aae  nop
00007f0145be1ab0  mov rax, [r15+0xF8]
00007f0145be1ab7  lea r14, [rax+0x140]
00007f0145be1abe  mov r12, [r13+r14*1]
00007f0145be1ac3  mov [r15+0xE8], r12
00007f0145be1aca  lea r14, [rax+0x130]
00007f0145be1ad1  mov r12, [r13+r14*1]
00007f0145be1ad6  lea r14, [rax+0x138]
00007f0145be1add  mov r11, [r13+r14*1]
00007f0145be1ae2  movq xmm1, r12
00007f0145be1ae7  movq xmm15, r11
00007f0145be1aec  movq xmm1, xmm1
00007f0145be1af0  movq xmm1, xmm1
00007f0145be1af4  movaps [r15+0x1A0], xmm1
00007f0145be1afc  movq xmm15, xmm15
00007f0145be1b01  movq xmm15, xmm15
00007f0145be1b06  movaps [r15+0x190], xmm15
00007f0145be1b0e  lea r14, [rax+0x120]
00007f0145be1b15  mov r12, [r13+r14*1]
00007f0145be1b1a  lea r14, [rax+0x128]
00007f0145be1b21  mov r11, [r13+r14*1]
00007f0145be1b26  movq xmm1, r12
00007f0145be1b2b  movq xmm15, r11
00007f0145be1b30  movq xmm1, xmm1
00007f0145be1b34  movq xmm1, xmm1
00007f0145be1b38  movaps [r15+0x1C0], xmm1
00007f0145be1b40  movq xmm15, xmm15
00007f0145be1b45  movq xmm15, xmm15
00007f0145be1b4a  movaps [r15+0x1B0], xmm15
00007f0145be1b52  lea r14, [rax+0x110]
00007f0145be1b59  mov r12, [r13+r14*1]
00007f0145be1b5e  lea r14, [rax+0x118]
00007f0145be1b65  mov r11, [r13+r14*1]
00007f0145be1b6a  movq xmm1, r12
00007f0145be1b6f  movq xmm15, r11
00007f0145be1b74  movq xmm1, xmm1
00007f0145be1b78  movq xmm1, xmm1
00007f0145be1b7c  movaps [r15+0x1E0], xmm1
00007f0145be1b84  movq xmm15, xmm15
00007f0145be1b89  movq xmm15, xmm15
00007f0145be1b8e  movaps [r15+0x1D0], xmm15
00007f0145be1b96  lea r14, [rax+0x100]
00007f0145be1b9d  mov r12, [r13+r14*1]
00007f0145be1ba2  lea r14, [rax+0x108]
00007f0145be1ba9  mov r11, [r13+r14*1]
00007f0145be1bae  movq xmm1, r12
00007f0145be1bb3  movq xmm15, r11
00007f0145be1bb8  movq xmm1, xmm1
00007f0145be1bbc  movq xmm1, xmm1
00007f0145be1bc0  movaps [r15+0x200], xmm1
00007f0145be1bc8  movq xmm15, xmm15
00007f0145be1bcd  movq xmm15, xmm15
00007f0145be1bd2  movaps [r15+0x1F0], xmm15
00007f0145be1bda  mov qword ptr [r15+0x40], 0x430000
00007f0145be1be2  mov r14d, 0x430510
00007f0145be1be8  mov r12, [r13+r14*1]
00007f0145be1bed  movq xmm1, r12
00007f0145be1bf2  lea r14, [rax+0x150]
00007f0145be1bf9  mov [r15+0xF8], r14
00007f0145be1c00  mov rax, [r15+0x50]
00007f0145be1c04  movups xmm15, [r13+rax*1]
00007f0145be1c0a  movaps [r15+0x120], xmm15
00007f0145be1c12  mov qword ptr [r15+0x48], 0x10
00007f0145be1c1a  xor eax, eax
00007f0145be1c1c  mov r14d, 0x10
00007f0145be1c22  mov r12d, 0x200
00007f0145be1c28  cmp r14, r12
00007f0145be1c2b  cmc
00007f0145be1c2c  lahf
00007f0145be1c2d  seto al
00007f0145be1c30  mov [r15+0x108], eax
00007f0145be1c37  pextrq rax, xmm15, 0x01
00007f0145be1c3e  movq xmm14, rax
00007f0145be1c43  movaps [r15+0x130], xmm14
00007f0145be1c4b  movq rax, xmm1
00007f0145be1c50  movq r14, xmm15
00007f0145be1c55  vmovq xmm1, rax
00007f0145be1c5a  vmovq xmm15, r14
00007f0145be1c5f  movaps xmm13, xmm1
00007f0145be1c63  addsd xmm13, xmm15
00007f0145be1c68  ucomisd xmm13, xmm13
00007f0145be1c6d  jp 0x00007F0145BE1D86
00007f0145be1c73  movq xmm13, xmm13
00007f0145be1c78  movq rax, xmm13
00007f0145be1c7d  movq r14, xmm14
00007f0145be1c82  vmovq xmm1, rax
00007f0145be1c87  vmovq xmm15, r14
00007f0145be1c8c  movaps xmm14, xmm1
00007f0145be1c90  addsd xmm14, xmm15
00007f0145be1c95  ucomisd xmm14, xmm14
00007f0145be1c9a  jp 0x00007F0145BE1DCE
00007f0145be1ca0  movq xmm14, xmm14
00007f0145be1ca5  movaps [r15+0x110], xmm14
00007f0145be1cad  mov eax, [r15+0x108]
00007f0145be1cb4  sahf
00007f0145be1cb5  jnz 0x00007F0145BE1CE7
00007f0145be1cb7  cmp dword ptr [r15+0x318], 0x00
00007f0145be1cbf  jz 0x00007F0145BE1FE0
00007f0145be1cc5  nop [rax+rax*1], ax
00007f0145be1cce  nop [rax+rax*1], eax
00007f0145be1cd6  mov eax, 0x410490
00007f0145be1cdb  mov [r15+0x100], rax
00007f0145be1ce2  jmp 0x00007F01459FE110
00007f0145be1ce7  cmp dword ptr [r15+0x318], 0x00
00007f0145be1cef  jz 0x00007F0145BE1E20
00007f0145be1cf5  nop [rax+rax*1], ax
00007f0145be1cfe  nop [rax+rax*1], eax
00007f0145be1d06  mov eax, 0x410474
00007f0145be1d0b  mov [r15+0x100], rax
00007f0145be1d12  jmp 0x00007F01459FE110
00007f0145be1d17  int3
00007f0145be1d18  call 0x00007F0145AE27E0
00007f0145be1d1d  jmp 0x00007F0145BE1AC3
00007f0145be1d22  call 0x00007F0145AE27E0
00007f0145be1d27  jmp 0x00007F0145BE1AD6
00007f0145be1d2c  call 0x00007F0145AE1570
00007f0145be1d31  jmp 0x00007F0145BE1AE2
00007f0145be1d36  call 0x00007F0145AE27E0
00007f0145be1d3b  jmp 0x00007F0145BE1B1A
00007f0145be1d40  call 0x00007F0145AE1570
00007f0145be1d45  jmp 0x00007F0145BE1B26
00007f0145be1d4a  call 0x00007F0145AE27E0
00007f0145be1d4f  jmp 0x00007F0145BE1B5E
00007f0145be1d54  call 0x00007F0145AE1570
00007f0145be1d59  jmp 0x00007F0145BE1B6A
00007f0145be1d5e  call 0x00007F0145AE27E0
00007f0145be1d63  jmp 0x00007F0145BE1BA2
00007f0145be1d68  call 0x00007F0145AE1570
00007f0145be1d6d  jmp 0x00007F0145BE1BAE
00007f0145be1d72  call 0x00007F0145AE27E0
00007f0145be1d77  jmp 0x00007F0145BE1BED
00007f0145be1d7c  call 0x00007F0145A0E760
00007f0145be1d81  jmp 0x00007F0145BE1C0A
00007f0145be1d86  ucomisd xmm1, xmm15
00007f0145be1d8b  jp 0x00007F0145BE1D9A
00007f0145be1d8d  movaps xmm13, [0x00007F01457FE060]
00007f0145be1d95  jmp 0x00007F0145BE1C73
00007f0145be1d9a  vxorps xmm0, xmm1, xmm15
00007f0145be1d9f  pextrw eax, xmm0, 0x03
00007f0145be1da4  and eax, 0x7FF8
00007f0145be1da9  cmp eax, 0x08
00007f0145be1dac  jnz 0x00007F0145BE1C73
00007f0145be1db2  movq rax, xmm15
00007f0145be1db7  shl rax, 0x0D
00007f0145be1dbb  jbe 0x00007F0145BE1C73
00007f0145be1dc1  vorps xmm13, xmm15, [0x00007F01457FE070]
00007f0145be1dc9  jmp 0x00007F0145BE1C73
00007f0145be1dce  ucomisd xmm1, xmm15
00007f0145be1dd3  jp 0x00007F0145BE1DE2
00007f0145be1dd5  movaps xmm14, [0x00007F01457FE060]
00007f0145be1ddd  jmp 0x00007F0145BE1CA0
00007f0145be1de2  vxorps xmm0, xmm1, xmm15
00007f0145be1de7  pextrw eax, xmm0, 0x03
00007f0145be1dec  and eax, 0x7FF8
00007f0145be1df1  cmp eax, 0x08
00007f0145be1df4  jnz 0x00007F0145BE1CA0
00007f0145be1dfa  movq rax, xmm15
00007f0145be1dff  shl rax, 0x0D
00007f0145be1e03  jbe 0x00007F0145BE1CA0
00007f0145be1e09  vorps xmm14, xmm15, [0x00007F01457FE070]
00007f0145be1e11  jmp 0x00007F0145BE1CA0
00007f0145be1e16  int3
00007f0145be1e17  nop [rax+rax*1], ax
00007f0145be1e20  mov rax, [r15+0x48]
00007f0145be1e24  mov r14, [r15+0x50]
00007f0145be1e28  lea r12, [r14+rax*1]
00007f0145be1e2c  movups xmm1, [r13+r12*1]
00007f0145be1e32  movaps [r15+0x120], xmm1
00007f0145be1e3a  lea r14, [rax+0x10]
00007f0145be1e3e  mov [r15+0x48], r14
00007f0145be1e42  xor eax, eax
00007f0145be1e44  mov r12d, 0x200
00007f0145be1e4a  cmp r14, r12
00007f0145be1e4d  cmc
00007f0145be1e4e  lahf
00007f0145be1e4f  seto al
00007f0145be1e52  mov [r15+0x108], eax
00007f0145be1e59  pextrq rax, xmm1, 0x01
00007f0145be1e60  movq xmm15, rax
00007f0145be1e65  movaps [r15+0x130], xmm15
00007f0145be1e6d  movaps xmm14, [r15+0x110]
00007f0145be1e75  movq rax, xmm14
00007f0145be1e7a  movq r14, xmm1
00007f0145be1e7f  vmovq xmm1, rax
00007f0145be1e84  vmovq xmm14, r14
00007f0145be1e89  movaps xmm13, xmm1
00007f0145be1e8d  addsd xmm13, xmm14
00007f0145be1e92  ucomisd xmm13, xmm13
00007f0145be1e97  jp 0x00007F0145BE1F4C
00007f0145be1e9d  movq xmm13, xmm13
00007f0145be1ea2  movq rax, xmm13
00007f0145be1ea7  movq r14, xmm15
00007f0145be1eac  vmovq xmm1, rax
00007f0145be1eb1  vmovq xmm15, r14
00007f0145be1eb6  movaps xmm14, xmm1
00007f0145be1eba  addsd xmm14, xmm15
00007f0145be1ebf  ucomisd xmm14, xmm14
00007f0145be1ec4  jp 0x00007F0145BE1F94
00007f0145be1eca  movq xmm14, xmm14
00007f0145be1ecf  movaps [r15+0x110], xmm14
00007f0145be1ed7  mov eax, [r15+0x108]
00007f0145be1ede  sahf
00007f0145be1edf  jnz 0x00007F0145BE1F11
00007f0145be1ee1  cmp dword ptr [r15+0x318], 0x00
00007f0145be1ee9  jz 0x00007F0145BE1FE0
00007f0145be1eef  nop [rax+rax*1], ax
00007f0145be1ef8  nop [rax+rax*1], eax
00007f0145be1f00  mov eax, 0x410490
00007f0145be1f05  mov [r15+0x100], rax
00007f0145be1f0c  jmp 0x00007F01459FE110
00007f0145be1f11  cmp dword ptr [r15+0x318], 0x00
00007f0145be1f19  jz 0x00007F0145BE1E20
00007f0145be1f1f  nop [rax+rax*1], ax
00007f0145be1f28  nop [rax+rax*1], eax
00007f0145be1f30  mov eax, 0x410474
00007f0145be1f35  mov [r15+0x100], rax
00007f0145be1f3c  jmp 0x00007F01459FE110
00007f0145be1f41  int3
00007f0145be1f42  call 0x00007F0145AB52F0
00007f0145be1f47  jmp 0x00007F0145BE1E32
00007f0145be1f4c  ucomisd xmm1, xmm14
00007f0145be1f51  jp 0x00007F0145BE1F60
00007f0145be1f53  movaps xmm13, [0x00007F01457FE060]
00007f0145be1f5b  jmp 0x00007F0145BE1E9D
00007f0145be1f60  vxorps xmm0, xmm1, xmm14
00007f0145be1f65  pextrw eax, xmm0, 0x03
00007f0145be1f6a  and eax, 0x7FF8
00007f0145be1f6f  cmp eax, 0x08
00007f0145be1f72  jnz 0x00007F0145BE1E9D
00007f0145be1f78  movq rax, xmm14
00007f0145be1f7d  shl rax, 0x0D
00007f0145be1f81  jbe 0x00007F0145BE1E9D
00007f0145be1f87  vorps xmm13, xmm14, [0x00007F01457FE070]
00007f0145be1f8f  jmp 0x00007F0145BE1E9D
00007f0145be1f94  ucomisd xmm1, xmm15
00007f0145be1f99  jp 0x00007F0145BE1FA8
00007f0145be1f9b  movaps xmm14, [0x00007F01457FE060]
00007f0145be1fa3  jmp 0x00007F0145BE1ECA
00007f0145be1fa8  vxorps xmm0, xmm1, xmm15
00007f0145be1fad  pextrw eax, xmm0, 0x03
00007f0145be1fb2  and eax, 0x7FF8
00007f0145be1fb7  cmp eax, 0x08
00007f0145be1fba  jnz 0x00007F0145BE1ECA
00007f0145be1fc0  movq rax, xmm15
00007f0145be1fc5  shl rax, 0x0D
00007f0145be1fc9  jbe 0x00007F0145BE1ECA
00007f0145be1fcf  vorps xmm14, xmm15, [0x00007F01457FE070]
00007f0145be1fd7  jmp 0x00007F0145BE1ECA
00007f0145be1fdc  int3
00007f0145be1fdd  nop [rax], eax
00007f0145be1fe0  mov rax, [r15+0x40]
00007f0145be1fe4  lea r14, [rax+0x510]
00007f0145be1feb  movaps xmm1, [r15+0x110]
00007f0145be1ff3  movq rax, xmm1
00007f0145be1ff8  mov [r13+r14*1], rax
00007f0145be1ffd  mov rax, [r15+0xF0]
00007f0145be2004  mov [r15+0x100], rax
00007f0145be200b  jmp 0x00007F0145BCE5C0
00007f0145be2010  int3
00007f0145be2011  call 0x00007F0145AD5EB0
00007f0145be2016  jmp 0x00007F0145BE1FFD
00007f0145be201b  int3
00007f0145be201c  nop [rax], eax
00007f0145be2020  mov qword ptr [r15+0x100], 0x04
00007f0145be202b  mov esi, 0x00
00007f0145be2030  mov edx, 0x09
00007f0145be2035  mov rdi, 0x7FFE79B58390
00007f0145be203f  mov rax, 0x636570D2B970
00007f0145be2049  call rax
00007f0145be204b  cmp dword ptr [r15+0x318], 0x00
00007f0145be2053  jnz 0x00007F01459FE110
00007f0145be2059  jmp 0x00007F01459FE0A0
00007f0145be205e  int3
00007f0145be205f  int3
