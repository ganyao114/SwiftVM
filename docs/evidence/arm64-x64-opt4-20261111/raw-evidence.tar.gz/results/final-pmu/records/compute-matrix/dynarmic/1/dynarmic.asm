000074b6341ce69b  nop [rax+rax*1], eax
000074b6341ce6a0  vmovaps xmm1, [0x000074B633DFE010]
000074b6341ce6a8  movq xmm1, xmm1
000074b6341ce6ac  movaps [r15+0x110], xmm1
000074b6341ce6b4  vmovaps xmm1, [0x000074B633DFE020]
000074b6341ce6bc  movq xmm1, xmm1
000074b6341ce6c0  movaps [r15+0x120], xmm1
000074b6341ce6c8  mov eax, 0x4204C0
000074b6341ce6cd  mov r14, [r13+rax*1]
000074b6341ce6d2  movq xmm1, r14
000074b6341ce6d7  movaps [r15+0x130], xmm1
000074b6341ce6df  vmovaps xmm1, [0x000074B633DFE030]
000074b6341ce6e7  vpbroadcastq xmm1, xmm1
000074b6341ce6ec  movaps [r15+0x140], xmm1
000074b6341ce6f4  mov qword ptr [r15+0x40], 0x02
000074b6341ce6fc  vmovaps xmm15, [0x000074B633DFE040]
000074b6341ce704  movq xmm15, xmm15
000074b6341ce709  movaps [r15+0x150], xmm15
000074b6341ce711  mov qword ptr [r15+0x58], 0x420000
000074b6341ce719  vmovaps xmm15, [0x000074B633DFE050]
000074b6341ce721  vpbroadcastq xmm15, xmm15
000074b6341ce726  movaps [r15+0x160], xmm15
000074b6341ce72e  mov rax, [r15+0x40]
000074b6341ce732  vmovq xmm14, rax
000074b6341ce737  vpbroadcastq xmm14, xmm14
000074b6341ce73c  movaps [r15+0x170], xmm14
000074b6341ce744  mov eax, 0x4204D0
000074b6341ce749  movups xmm13, [r13+rax*1]
000074b6341ce74f  mov qword ptr [r15+0x40], 0x430518
000074b6341ce757  mov qword ptr [r15+0x50], 0x430720
000074b6341ce75f  vpmovqd xmm12, xmm13
000074b6341ce765  pxor xmm11, xmm11
000074b6341ce76a  punpcklqdq xmm12, xmm11
000074b6341ce76f  movaps [r15+0x210], xmm12
000074b6341ce777  movq xmm12, qword ptr [r15+0x120]
000074b6341ce780  movq xmm11, qword ptr [r15+0x130]
000074b6341ce789  psubd xmm12, xmm11
000074b6341ce78e  movq xmm12, xmm12
000074b6341ce793  paddq xmm13, xmm14
000074b6341ce798  movaps [r15+0x180], xmm13
000074b6341ce7a0  movq xmm14, qword ptr [r15+0x150]
000074b6341ce7a9  paddd xmm11, xmm14
000074b6341ce7ae  movq xmm11, xmm11
000074b6341ce7b3  movq xmm11, xmm11
000074b6341ce7b8  movaps [r15+0x130], xmm11
000074b6341ce7c0  pmovzxdq xmm12, xmm12
000074b6341ce7c6  psllq xmm12, 0x00
000074b6341ce7cc  movq xmm14, qword ptr [r15+0x210]
000074b6341ce7d5  movq xmm13, qword ptr [r15+0x110]
000074b6341ce7de  paddd xmm14, xmm13
000074b6341ce7e3  movq xmm14, xmm14
000074b6341ce7e8  vcvtuqq2pd xmm12, xmm12
000074b6341ce7ee  pmovzxdq xmm14, xmm14
000074b6341ce7f4  psllq xmm14, 0x00
000074b6341ce7fa  vcvtuqq2pd xmm14, xmm14
000074b6341ce800  movaps xmm13, xmm12
000074b6341ce804  mulpd xmm13, xmm1
000074b6341ce809  vcmppd xmm11, xmm13, xmm13, 0x03
000074b6341ce80f  ptest xmm11, xmm11
000074b6341ce815  jnz 0x000074B6341CE8FF
000074b6341ce81b  movaps [r15+0x220], xmm13
000074b6341ce823  mov eax, 0x430720
000074b6341ce828  movups [r13+rax*1], xmm13
000074b6341ce82e  movaps xmm1, xmm14
000074b6341ce832  mulpd xmm1, xmm15
000074b6341ce837  vcmppd xmm13, xmm1, xmm1, 0x03
000074b6341ce83c  ptest xmm13, xmm13
000074b6341ce842  jnz 0x000074B6341CEA4C
000074b6341ce848  movaps [r15+0x210], xmm1
000074b6341ce850  mov eax, 0x430518
000074b6341ce855  movups [r13+rax*1], xmm1
000074b6341ce85b  mov qword ptr [r15+0x48], 0x10
000074b6341ce863  xor eax, eax
000074b6341ce865  mov r14d, 0x10
000074b6341ce86b  mov r12d, 0x200
000074b6341ce871  cmp r14, r12
000074b6341ce874  cmc
000074b6341ce875  lahf
000074b6341ce876  seto al
000074b6341ce879  mov [r15+0x108], eax
000074b6341ce880  mov eax, [r15+0x108]
000074b6341ce887  sahf
000074b6341ce888  jnz 0x000074B6341CE8BA
000074b6341ce88a  cmp dword ptr [r15+0x318], 0x00
000074b6341ce892  jz 0x000074B6341CEFF0
000074b6341ce898  nop [rax+rax*1], ax
000074b6341ce8a1  nop [rax+rax*1], eax
000074b6341ce8a9  mov eax, 0x4101EC
000074b6341ce8ae  mov [r15+0x100], rax
000074b6341ce8b5  jmp 0x000074B633FFE110
000074b6341ce8ba  cmp dword ptr [r15+0x318], 0x00
000074b6341ce8c2  jz 0x000074B6341CEBA0
000074b6341ce8c8  nop [rax+rax*1], ax
000074b6341ce8d1  nop [rax+rax*1], eax
000074b6341ce8d9  mov eax, 0x4101AC
000074b6341ce8de  mov [r15+0x100], rax
000074b6341ce8e5  jmp 0x000074B633FFE110
000074b6341ce8ea  int3
000074b6341ce8eb  call 0x000074B63400DC20
000074b6341ce8f0  jmp 0x000074B6341CE6D2
000074b6341ce8f5  call 0x000074B63400C260
000074b6341ce8fa  jmp 0x000074B6341CE74F
000074b6341ce8ff  sub rsp, 0x08
000074b6341ce903  push rax
000074b6341ce904  push rcx
000074b6341ce905  push rdx
000074b6341ce906  push rdi
000074b6341ce907  push rsi
000074b6341ce908  push r8
000074b6341ce90a  push r9
000074b6341ce90c  push r10
000074b6341ce90e  push r11
000074b6341ce910  sub rsp, 0xF0
000074b6341ce917  vmovaps [rsp], xmm0
000074b6341ce91c  vmovaps [rsp+0x10], xmm1
000074b6341ce922  vmovaps [rsp+0x20], xmm2
000074b6341ce928  vmovaps [rsp+0x30], xmm3
000074b6341ce92e  vmovaps [rsp+0x40], xmm4
000074b6341ce934  vmovaps [rsp+0x50], xmm5
000074b6341ce93a  vmovaps [rsp+0x60], xmm6
000074b6341ce940  vmovaps [rsp+0x70], xmm7
000074b6341ce946  vmovaps [rsp+0x80], xmm8
000074b6341ce94f  vmovaps [rsp+0x90], xmm9
000074b6341ce958  vmovaps [rsp+0xA0], xmm10
000074b6341ce961  vmovaps [rsp+0xB0], xmm11
000074b6341ce96a  vmovaps [rsp+0xC0], xmm12
000074b6341ce973  vmovaps [rsp+0xD0], xmm14
000074b6341ce97c  vmovaps [rsp+0xE0], xmm15
000074b6341ce985  sub rsp, 0x30
000074b6341ce989  movaps [rsp], xmm13
000074b6341ce98e  movaps [rsp+0x10], xmm12
000074b6341ce994  movaps [rsp+0x20], xmm1
000074b6341ce999  lea rdi, [rsp]
000074b6341ce99d  mov esi, 0x00
000074b6341ce9a2  mov rax, 0x5E1AA0A2F530
000074b6341ce9ac  call rax
000074b6341ce9ae  movaps xmm13, [rsp]
000074b6341ce9b3  add rsp, 0x30
000074b6341ce9b7  vmovaps xmm0, [rsp]
000074b6341ce9bc  vmovaps xmm1, [rsp+0x10]
000074b6341ce9c2  vmovaps xmm2, [rsp+0x20]
000074b6341ce9c8  vmovaps xmm3, [rsp+0x30]
000074b6341ce9ce  vmovaps xmm4, [rsp+0x40]
000074b6341ce9d4  vmovaps xmm5, [rsp+0x50]
000074b6341ce9da  vmovaps xmm6, [rsp+0x60]
000074b6341ce9e0  vmovaps xmm7, [rsp+0x70]
000074b6341ce9e6  vmovaps xmm8, [rsp+0x80]
000074b6341ce9ef  vmovaps xmm9, [rsp+0x90]
000074b6341ce9f8  vmovaps xmm10, [rsp+0xA0]
000074b6341cea01  vmovaps xmm11, [rsp+0xB0]
000074b6341cea0a  vmovaps xmm12, [rsp+0xC0]
000074b6341cea13  vmovaps xmm14, [rsp+0xD0]
000074b6341cea1c  vmovaps xmm15, [rsp+0xE0]
000074b6341cea25  add rsp, 0xF0
000074b6341cea2c  pop r11
000074b6341cea2e  pop r10
000074b6341cea30  pop r9
000074b6341cea32  pop r8
000074b6341cea34  pop rsi
000074b6341cea35  pop rdi
000074b6341cea36  pop rdx
000074b6341cea37  pop rcx
000074b6341cea38  pop rax
000074b6341cea39  add rsp, 0x08
000074b6341cea3d  jmp 0x000074B6341CE81B
000074b6341cea42  call 0x000074B63400C380
000074b6341cea47  jmp 0x000074B6341CE82E
000074b6341cea4c  sub rsp, 0x08
000074b6341cea50  push rax
000074b6341cea51  push rcx
000074b6341cea52  push rdx
000074b6341cea53  push rdi
000074b6341cea54  push rsi
000074b6341cea55  push r8
000074b6341cea57  push r9
000074b6341cea59  push r10
000074b6341cea5b  push r11
000074b6341cea5d  sub rsp, 0xF0
000074b6341cea64  vmovaps [rsp], xmm0
000074b6341cea69  vmovaps [rsp+0x10], xmm2
000074b6341cea6f  vmovaps [rsp+0x20], xmm3
000074b6341cea75  vmovaps [rsp+0x30], xmm4
000074b6341cea7b  vmovaps [rsp+0x40], xmm5
000074b6341cea81  vmovaps [rsp+0x50], xmm6
000074b6341cea87  vmovaps [rsp+0x60], xmm7
000074b6341cea8d  vmovaps [rsp+0x70], xmm8
000074b6341cea93  vmovaps [rsp+0x80], xmm9
000074b6341cea9c  vmovaps [rsp+0x90], xmm10
000074b6341ceaa5  vmovaps [rsp+0xA0], xmm11
000074b6341ceaae  vmovaps [rsp+0xB0], xmm12
000074b6341ceab7  vmovaps [rsp+0xC0], xmm13
000074b6341ceac0  vmovaps [rsp+0xD0], xmm14
000074b6341ceac9  vmovaps [rsp+0xE0], xmm15
000074b6341cead2  sub rsp, 0x30
000074b6341cead6  movaps [rsp], xmm1
000074b6341ceada  movaps [rsp+0x10], xmm14
000074b6341ceae0  movaps [rsp+0x20], xmm15
000074b6341ceae6  lea rdi, [rsp]
000074b6341ceaea  mov esi, 0x00
000074b6341ceaef  mov rax, 0x5E1AA0A2F530
000074b6341ceaf9  call rax
000074b6341ceafb  movaps xmm1, [rsp]
000074b6341ceaff  add rsp, 0x30
000074b6341ceb03  vmovaps xmm0, [rsp]
000074b6341ceb08  vmovaps xmm2, [rsp+0x10]
000074b6341ceb0e  vmovaps xmm3, [rsp+0x20]
000074b6341ceb14  vmovaps xmm4, [rsp+0x30]
000074b6341ceb1a  vmovaps xmm5, [rsp+0x40]
000074b6341ceb20  vmovaps xmm6, [rsp+0x50]
000074b6341ceb26  vmovaps xmm7, [rsp+0x60]
000074b6341ceb2c  vmovaps xmm8, [rsp+0x70]
000074b6341ceb32  vmovaps xmm9, [rsp+0x80]
000074b6341ceb3b  vmovaps xmm10, [rsp+0x90]
000074b6341ceb44  vmovaps xmm11, [rsp+0xA0]
000074b6341ceb4d  vmovaps xmm12, [rsp+0xB0]
000074b6341ceb56  vmovaps xmm13, [rsp+0xC0]
000074b6341ceb5f  vmovaps xmm14, [rsp+0xD0]
000074b6341ceb68  vmovaps xmm15, [rsp+0xE0]
000074b6341ceb71  add rsp, 0xF0
000074b6341ceb78  pop r11
000074b6341ceb7a  pop r10
000074b6341ceb7c  pop r9
000074b6341ceb7e  pop r8
000074b6341ceb80  pop rsi
000074b6341ceb81  pop rdi
000074b6341ceb82  pop rdx
000074b6341ceb83  pop rcx
000074b6341ceb84  pop rax
000074b6341ceb85  add rsp, 0x08
000074b6341ceb89  jmp 0x000074B6341CE848
000074b6341ceb8e  call 0x000074B633FFF540
000074b6341ceb93  jmp 0x000074B6341CE85B
000074b6341ceb98  int3
000074b6341ceb99  nop [rax], eax
000074b6341ceba0  movaps xmm1, [r15+0x180]
000074b6341ceba8  vpmovqd xmm15, xmm1
000074b6341cebae  pxor xmm14, xmm14
000074b6341cebb3  punpcklqdq xmm15, xmm14
000074b6341cebb8  movaps [r15+0x210], xmm15
000074b6341cebc0  movq xmm15, qword ptr [r15+0x120]
000074b6341cebc9  movq xmm14, qword ptr [r15+0x130]
000074b6341cebd2  psubd xmm15, xmm14
000074b6341cebd7  movq xmm15, xmm15
000074b6341cebdc  movaps xmm13, [r15+0x170]
000074b6341cebe4  paddq xmm1, xmm13
000074b6341cebe9  movaps [r15+0x180], xmm1
000074b6341cebf1  movq xmm1, qword ptr [r15+0x150]
000074b6341cebfa  paddd xmm14, xmm1
000074b6341cebff  movq xmm14, xmm14
000074b6341cec04  movq xmm14, xmm14
000074b6341cec09  movaps [r15+0x130], xmm14
000074b6341cec11  pmovzxdq xmm15, xmm15
000074b6341cec17  psllq xmm15, 0x00
000074b6341cec1d  movq xmm1, qword ptr [r15+0x210]
000074b6341cec26  movq xmm14, qword ptr [r15+0x110]
000074b6341cec2f  paddd xmm1, xmm14
000074b6341cec34  movq xmm1, xmm1
000074b6341cec38  vcvtuqq2pd xmm15, xmm15
000074b6341cec3e  pmovzxdq xmm1, xmm1
000074b6341cec43  psllq xmm1, 0x00
000074b6341cec48  vcvtuqq2pd xmm1, xmm1
000074b6341cec4e  movaps xmm14, [r15+0x140]
000074b6341cec56  movaps xmm13, xmm15
000074b6341cec5a  mulpd xmm13, xmm14
000074b6341cec5f  vcmppd xmm12, xmm13, xmm13, 0x03
000074b6341cec65  ptest xmm12, xmm12
000074b6341cec6b  jnz 0x000074B6341CED4E
000074b6341cec71  movaps [r15+0x220], xmm13
000074b6341cec79  mov rax, [r15+0x48]
000074b6341cec7d  mov r14, [r15+0x50]
000074b6341cec81  lea r12, [r14+rax*1]
000074b6341cec85  movups [r13+r12*1], xmm13
000074b6341cec8b  movaps xmm15, [r15+0x160]
000074b6341cec93  movaps xmm14, xmm1
000074b6341cec97  mulpd xmm14, xmm15
000074b6341cec9c  vcmppd xmm13, xmm14, xmm14, 0x03
000074b6341ceca2  ptest xmm13, xmm13
000074b6341ceca8  jnz 0x000074B6341CEE9C
000074b6341cecae  movaps [r15+0x210], xmm14
000074b6341cecb6  mov r14, [r15+0x40]
000074b6341cecba  lea r12, [r14+rax*1]
000074b6341cecbe  movups [r13+r12*1], xmm14
000074b6341cecc4  lea r14, [rax+0x10]
000074b6341cecc8  mov [r15+0x48], r14
000074b6341ceccc  xor eax, eax
000074b6341cecce  mov r12d, 0x200
000074b6341cecd4  cmp r14, r12
000074b6341cecd7  cmc
000074b6341cecd8  lahf
000074b6341cecd9  seto al
000074b6341cecdc  mov [r15+0x108], eax
000074b6341cece3  mov eax, [r15+0x108]
000074b6341cecea  sahf
000074b6341ceceb  jnz 0x000074B6341CED1D
000074b6341ceced  cmp dword ptr [r15+0x318], 0x00
000074b6341cecf5  jz 0x000074B6341CEFF0
000074b6341cecfb  nop [rax+rax*1], ax
000074b6341ced04  nop [rax+rax*1], eax
000074b6341ced0c  mov eax, 0x4101EC
000074b6341ced11  mov [r15+0x100], rax
000074b6341ced18  jmp 0x000074B633FFE110
000074b6341ced1d  cmp dword ptr [r15+0x318], 0x00
000074b6341ced25  jz 0x000074B6341CEBA0
000074b6341ced2b  nop [rax+rax*1], ax
000074b6341ced34  nop [rax+rax*1], eax
000074b6341ced3c  mov eax, 0x4101AC
000074b6341ced41  mov [r15+0x100], rax
000074b6341ced48  jmp 0x000074B633FFE110
000074b6341ced4d  int3
000074b6341ced4e  sub rsp, 0x08
000074b6341ced52  push rax
000074b6341ced53  push rcx
000074b6341ced54  push rdx
000074b6341ced55  push rdi
000074b6341ced56  push rsi
000074b6341ced57  push r8
000074b6341ced59  push r9
000074b6341ced5b  push r10
000074b6341ced5d  push r11
000074b6341ced5f  sub rsp, 0xF0
000074b6341ced66  vmovaps [rsp], xmm0
000074b6341ced6b  vmovaps [rsp+0x10], xmm1
000074b6341ced71  vmovaps [rsp+0x20], xmm2
000074b6341ced77  vmovaps [rsp+0x30], xmm3
000074b6341ced7d  vmovaps [rsp+0x40], xmm4
000074b6341ced83  vmovaps [rsp+0x50], xmm5
000074b6341ced89  vmovaps [rsp+0x60], xmm6
000074b6341ced8f  vmovaps [rsp+0x70], xmm7
000074b6341ced95  vmovaps [rsp+0x80], xmm8
000074b6341ced9e  vmovaps [rsp+0x90], xmm9
000074b6341ceda7  vmovaps [rsp+0xA0], xmm10
000074b6341cedb0  vmovaps [rsp+0xB0], xmm11
000074b6341cedb9  vmovaps [rsp+0xC0], xmm12
000074b6341cedc2  vmovaps [rsp+0xD0], xmm14
000074b6341cedcb  vmovaps [rsp+0xE0], xmm15
000074b6341cedd4  sub rsp, 0x30
000074b6341cedd8  movaps [rsp], xmm13
000074b6341ceddd  movaps [rsp+0x10], xmm15
000074b6341cede3  movaps [rsp+0x20], xmm14
000074b6341cede9  lea rdi, [rsp]
000074b6341ceded  mov esi, 0x00
000074b6341cedf2  mov rax, 0x5E1AA0A2F530
000074b6341cedfc  call rax
000074b6341cedfe  movaps xmm13, [rsp]
000074b6341cee03  add rsp, 0x30
000074b6341cee07  vmovaps xmm0, [rsp]
000074b6341cee0c  vmovaps xmm1, [rsp+0x10]
000074b6341cee12  vmovaps xmm2, [rsp+0x20]
000074b6341cee18  vmovaps xmm3, [rsp+0x30]
000074b6341cee1e  vmovaps xmm4, [rsp+0x40]
000074b6341cee24  vmovaps xmm5, [rsp+0x50]
000074b6341cee2a  vmovaps xmm6, [rsp+0x60]
000074b6341cee30  vmovaps xmm7, [rsp+0x70]
000074b6341cee36  vmovaps xmm8, [rsp+0x80]
000074b6341cee3f  vmovaps xmm9, [rsp+0x90]
000074b6341cee48  vmovaps xmm10, [rsp+0xA0]
000074b6341cee51  vmovaps xmm11, [rsp+0xB0]
000074b6341cee5a  vmovaps xmm12, [rsp+0xC0]
000074b6341cee63  vmovaps xmm14, [rsp+0xD0]
000074b6341cee6c  vmovaps xmm15, [rsp+0xE0]
000074b6341cee75  add rsp, 0xF0
000074b6341cee7c  pop r11
000074b6341cee7e  pop r10
000074b6341cee80  pop r9
000074b6341cee82  pop r8
000074b6341cee84  pop rsi
000074b6341cee85  pop rdi
000074b6341cee86  pop rdx
000074b6341cee87  pop rcx
000074b6341cee88  pop rax
000074b6341cee89  add rsp, 0x08
000074b6341cee8d  jmp 0x000074B6341CEC71
000074b6341cee92  call 0x000074B6340C2240
000074b6341cee97  jmp 0x000074B6341CEC8B
000074b6341cee9c  sub rsp, 0x08
000074b6341ceea0  push rax
000074b6341ceea1  push rcx
000074b6341ceea2  push rdx
000074b6341ceea3  push rdi
000074b6341ceea4  push rsi
000074b6341ceea5  push r8
000074b6341ceea7  push r9
000074b6341ceea9  push r10
000074b6341ceeab  push r11
000074b6341ceead  sub rsp, 0xF0
000074b6341ceeb4  vmovaps [rsp], xmm0
000074b6341ceeb9  vmovaps [rsp+0x10], xmm1
000074b6341ceebf  vmovaps [rsp+0x20], xmm2
000074b6341ceec5  vmovaps [rsp+0x30], xmm3
000074b6341ceecb  vmovaps [rsp+0x40], xmm4
000074b6341ceed1  vmovaps [rsp+0x50], xmm5
000074b6341ceed7  vmovaps [rsp+0x60], xmm6
000074b6341ceedd  vmovaps [rsp+0x70], xmm7
000074b6341ceee3  vmovaps [rsp+0x80], xmm8
000074b6341ceeec  vmovaps [rsp+0x90], xmm9
000074b6341ceef5  vmovaps [rsp+0xA0], xmm10
000074b6341ceefe  vmovaps [rsp+0xB0], xmm11
000074b6341cef07  vmovaps [rsp+0xC0], xmm12
000074b6341cef10  vmovaps [rsp+0xD0], xmm13
000074b6341cef19  vmovaps [rsp+0xE0], xmm15
000074b6341cef22  sub rsp, 0x30
000074b6341cef26  movaps [rsp], xmm14
000074b6341cef2b  movaps [rsp+0x10], xmm1
000074b6341cef30  movaps [rsp+0x20], xmm15
000074b6341cef36  lea rdi, [rsp]
000074b6341cef3a  mov esi, 0x00
000074b6341cef3f  mov rax, 0x5E1AA0A2F530
000074b6341cef49  call rax
000074b6341cef4b  movaps xmm14, [rsp]
000074b6341cef50  add rsp, 0x30
000074b6341cef54  vmovaps xmm0, [rsp]
000074b6341cef59  vmovaps xmm1, [rsp+0x10]
000074b6341cef5f  vmovaps xmm2, [rsp+0x20]
000074b6341cef65  vmovaps xmm3, [rsp+0x30]
000074b6341cef6b  vmovaps xmm4, [rsp+0x40]
000074b6341cef71  vmovaps xmm5, [rsp+0x50]
000074b6341cef77  vmovaps xmm6, [rsp+0x60]
000074b6341cef7d  vmovaps xmm7, [rsp+0x70]
000074b6341cef83  vmovaps xmm8, [rsp+0x80]
000074b6341cef8c  vmovaps xmm9, [rsp+0x90]
000074b6341cef95  vmovaps xmm10, [rsp+0xA0]
000074b6341cef9e  vmovaps xmm11, [rsp+0xB0]
000074b6341cefa7  vmovaps xmm12, [rsp+0xC0]
000074b6341cefb0  vmovaps xmm13, [rsp+0xD0]
000074b6341cefb9  vmovaps xmm15, [rsp+0xE0]
000074b6341cefc2  add rsp, 0xF0
000074b6341cefc9  pop r11
000074b6341cefcb  pop r10
000074b6341cefcd  pop r9
000074b6341cefcf  pop r8
000074b6341cefd1  pop rsi
000074b6341cefd2  pop rdi
000074b6341cefd3  pop rdx
000074b6341cefd4  pop rcx
000074b6341cefd5  pop rax
000074b6341cefd6  add rsp, 0x08
000074b6341cefda  jmp 0x000074B6341CECAE
000074b6341cefdf  call 0x000074B6340C34C0
000074b6341cefe4  jmp 0x000074B6341CECC4
000074b6341cefe9  int3
000074b6341cefea  nop [rax+rax*1], ax
000074b6341ceff0  mov rax, [r15+0xF8]
000074b6341ceff7  lea r14, [rax-0x150]
000074b6341ceffe  mov [r15+0xF8], r14
000074b6341cf005  mov rax, [r15+0x50]
000074b6341cf009  lea r12, [rax+0x80]
000074b6341cf010  movups xmm1, [r13+r12*1]
000074b6341cf016  lea r12, [rax+0x90]
000074b6341cf01d  movups xmm15, [r13+r12*1]
000074b6341cf023  mov qword ptr [r15+0x48], 0x00
000074b6341cf02b  lea r12, [rax+0x40]
000074b6341cf02f  movups xmm14, [r13+r12*1]
000074b6341cf035  lea r12, [rax+0x50]
000074b6341cf039  movups xmm13, [r13+r12*1]
000074b6341cf03f  lea r12, [r14+0x120]
000074b6341cf046  movq xmm12, qword ptr [r15+0x1C0]
000074b6341cf04f  movq xmm11, qword ptr [r15+0x1B0]
000074b6341cf058  movq r11, xmm12
000074b6341cf05d  movq r10, xmm11
000074b6341cf062  mov [r13+r12*1], r11
000074b6341cf067  lea r12, [r14+0x128]
000074b6341cf06e  mov [r13+r12*1], r10
000074b6341cf073  vxorps xmm12, xmm12, xmm12
000074b6341cf078  vpbroadcastq xmm12, xmm12
000074b6341cf07d  lea r12, [r14+0x100]
000074b6341cf084  movq xmm11, qword ptr [r15+0x200]
000074b6341cf08d  movq xmm10, qword ptr [r15+0x1F0]
000074b6341cf096  movq r11, xmm11
000074b6341cf09b  movq r10, xmm10
000074b6341cf0a0  mov [r13+r12*1], r11
000074b6341cf0a5  lea r12, [r14+0x108]
000074b6341cf0ac  mov [r13+r12*1], r10
000074b6341cf0b1  lea r12, [r14+0xE0]
000074b6341cf0b8  movups [r13+r12*1], xmm15
000074b6341cf0be  lea r12, [r14+0xF0]
000074b6341cf0c5  movups [r13+r12*1], xmm1
000074b6341cf0cb  lea r12, [rax+0xC0]
000074b6341cf0d2  movups xmm1, [r13+r12*1]
000074b6341cf0d8  lea r12, [rax+0xD0]
000074b6341cf0df  movups xmm15, [r13+r12*1]
000074b6341cf0e5  lea r12, [r14+0x110]
000074b6341cf0ec  movq xmm11, qword ptr [r15+0x1E0]
000074b6341cf0f5  movq xmm10, qword ptr [r15+0x1D0]
000074b6341cf0fe  movq r11, xmm11
000074b6341cf103  movq r10, xmm10
000074b6341cf108  mov [r13+r12*1], r11
000074b6341cf10d  lea r12, [r14+0x118]
000074b6341cf114  mov [r13+r12*1], r10
000074b6341cf119  movups xmm11, [r13+rax*1]
000074b6341cf11f  lea r12, [rax+0x10]
000074b6341cf123  movups xmm10, [r13+r12*1]
000074b6341cf129  lea r12, [r14+0x130]
000074b6341cf130  movq xmm9, qword ptr [r15+0x1A0]
000074b6341cf139  movq xmm8, qword ptr [r15+0x190]
000074b6341cf142  movq r11, xmm9
000074b6341cf147  movq r10, xmm8
000074b6341cf14c  mov [r13+r12*1], r11
000074b6341cf151  lea r12, [r14+0x138]
000074b6341cf158  mov [r13+r12*1], r10
000074b6341cf15d  lea r12, [rax+0x140]
000074b6341cf164  movups xmm9, [r13+r12*1]
000074b6341cf16a  lea r12, [rax+0x150]
000074b6341cf171  movups xmm8, [r13+r12*1]
000074b6341cf177  lea r12, [r14+0xC0]
000074b6341cf17e  movups [r13+r12*1], xmm15
000074b6341cf184  lea r12, [r14+0xD0]
000074b6341cf18b  movups [r13+r12*1], xmm1
000074b6341cf191  lea r12, [rax+0x100]
000074b6341cf198  movups xmm1, [r13+r12*1]
000074b6341cf19e  lea r12, [rax+0x110]
000074b6341cf1a5  movups xmm15, [r13+r12*1]
000074b6341cf1ab  lea r12, [r14+0x140]
000074b6341cf1b2  mov r11, [r15+0xE8]
000074b6341cf1b9  mov [r13+r12*1], r11
000074b6341cf1be  lea r12, [rax+0x180]
000074b6341cf1c5  movups xmm7, [r13+r12*1]
000074b6341cf1cb  lea r12, [rax+0x190]
000074b6341cf1d2  movups xmm6, [r13+r12*1]
000074b6341cf1d8  lea r12, [rax+0x1C0]
000074b6341cf1df  movups xmm5, [r13+r12*1]
000074b6341cf1e5  lea r12, [rax+0x1D0]
000074b6341cf1ec  movups xmm4, [r13+r12*1]
000074b6341cf1f2  lea r12, [r14+0x20]
000074b6341cf1f6  movups [r13+r12*1], xmm1
000074b6341cf1fc  lea r12, [r14+0x30]
000074b6341cf200  movups [r13+r12*1], xmm13
000074b6341cf206  lea r12, [rax+0x60]
000074b6341cf20a  movups xmm1, [r13+r12*1]
000074b6341cf210  lea r12, [rax+0x70]
000074b6341cf214  movups xmm13, [r13+r12*1]
000074b6341cf21a  lea r12, [rax+0x20]
000074b6341cf21e  movups xmm3, [r13+r12*1]
000074b6341cf224  lea r12, [rax+0x30]
000074b6341cf228  movups xmm2, [r13+r12*1]
000074b6341cf22e  movaps [r15+0x1F0], xmm2
000074b6341cf236  lea r12, [r14+0x60]
000074b6341cf23a  movups [r13+r12*1], xmm11
000074b6341cf240  lea r12, [r14+0x70]
000074b6341cf244  movups [r13+r12*1], xmm5
000074b6341cf24a  lea r12, [rax+0xE0]
000074b6341cf251  movups xmm11, [r13+r12*1]
000074b6341cf257  lea r12, [rax+0xF0]
000074b6341cf25e  movups xmm5, [r13+r12*1]
000074b6341cf264  lea r12, [r14+0xA0]
000074b6341cf26b  movups [r13+r12*1], xmm13
000074b6341cf271  lea r12, [r14+0xB0]
000074b6341cf278  movups [r13+r12*1], xmm1
000074b6341cf27e  lea r12, [rax+0xA0]
000074b6341cf285  movups xmm1, [r13+r12*1]
000074b6341cf28b  lea r12, [rax+0xB0]
000074b6341cf292  movups xmm13, [r13+r12*1]
000074b6341cf298  lea r12, [rax+0x120]
000074b6341cf29f  vmovaps [rsp+0x10], xmm1
000074b6341cf2a5  movups xmm1, [r13+r12*1]
000074b6341cf2ab  lea r12, [rax+0x130]
000074b6341cf2b2  vmovaps [rsp+0x20], xmm1
000074b6341cf2b8  movups xmm1, [r13+r12*1]
000074b6341cf2be  lea r12, [rax+0x160]
000074b6341cf2c5  vmovaps [rsp+0x30], xmm1
000074b6341cf2cb  movups xmm1, [r13+r12*1]
000074b6341cf2d1  lea r12, [rax+0x170]
000074b6341cf2d8  vmovaps [rsp+0x40], xmm1
000074b6341cf2de  movups xmm1, [r13+r12*1]
000074b6341cf2e4  movaps [r15+0x2B0], xmm1
000074b6341cf2ec  lea r12, [r14+0x80]
000074b6341cf2f3  movups [r13+r12*1], xmm13
000074b6341cf2f9  lea r12, [r14+0x90]
000074b6341cf300  vmovaps xmm13, [rsp+0x10]
000074b6341cf306  movups [r13+r12*1], xmm13
000074b6341cf30c  lea r12, [rax+0x1A0]
000074b6341cf313  movups xmm13, [r13+r12*1]
000074b6341cf319  lea r12, [rax+0x1B0]
000074b6341cf320  vmovaps [rsp+0x10], xmm1
000074b6341cf326  movups xmm1, [r13+r12*1]
000074b6341cf32c  movaps [r15+0x290], xmm13
000074b6341cf334  movaps [r15+0x1E0], xmm1
000074b6341cf33c  lea r12, [rax+0x1E0]
000074b6341cf343  vmovaps [rsp+0x50], xmm1
000074b6341cf349  movups xmm1, [r13+r12*1]
000074b6341cf34f  lea r12, [rax+0x1F0]
000074b6341cf356  vmovaps [rsp+0x60], xmm1
000074b6341cf35c  movups xmm1, [r13+r12*1]
000074b6341cf362  mov qword ptr [r15+0x50], 0x430920
000074b6341cf36a  lea rax, [r14+0x40]
000074b6341cf36e  vmovaps [rsp+0x70], xmm1
000074b6341cf374  vmovaps xmm1, [rsp+0x40]
000074b6341cf37a  movups [r13+rax*1], xmm1
000074b6341cf380  lea rax, [r14+0x50]
000074b6341cf384  movups [r13+rax*1], xmm10
000074b6341cf38a  vmovaps xmm1, [rsp+0x70]
000074b6341cf390  movups [r13+r14*1], xmm1
000074b6341cf396  lea rax, [r14+0x10]
000074b6341cf39a  vmovaps xmm1, [rsp+0x60]
000074b6341cf3a0  movups [r13+rax*1], xmm1
000074b6341cf3a6  mov rax, [r15+0x40]
000074b6341cf3aa  vmovaps [rsp+0x40], xmm3
000074b6341cf3b0  vmovaps xmm1, [rsp+0x40]
000074b6341cf3b6  por xmm3, xmm1
000074b6341cf3ba  vmovaps [rsp+0x40], xmm6
000074b6341cf3c0  vmovaps xmm10, [rsp+0x40]
000074b6341cf3c6  por xmm6, xmm10
000074b6341cf3cb  lea r12, [rax+0x30]
000074b6341cf3cf  mov r11, [r13+r12*1]
000074b6341cf3d4  lea r12, [rax+0x38]
000074b6341cf3d8  mov r10, [r13+r12*1]
000074b6341cf3dd  movq xmm10, r11
000074b6341cf3e2  vmovaps [rsp+0x40], xmm1
000074b6341cf3e8  movq xmm1, r10
000074b6341cf3ed  movq xmm10, xmm10
000074b6341cf3f2  vmovaps [rsp+0x60], xmm10
000074b6341cf3f8  movq xmm10, xmm10
000074b6341cf3fd  movaps [r15+0x130], xmm10
000074b6341cf405  movq xmm1, xmm1
000074b6341cf409  vmovaps [rsp+0x70], xmm1
000074b6341cf40f  movq xmm1, xmm1
000074b6341cf413  movaps [r15+0x280], xmm1
000074b6341cf41b  vmovaps [rsp+0x80], xmm9
000074b6341cf424  vmovaps xmm1, [rsp+0x80]
000074b6341cf42d  por xmm9, xmm1
000074b6341cf432  lea r12, [rax+0x20]
000074b6341cf436  mov r11, [r13+r12*1]
000074b6341cf43b  lea r12, [rax+0x28]
000074b6341cf43f  mov r10, [r13+r12*1]
000074b6341cf444  movq xmm1, r11
000074b6341cf449  movq xmm10, r10
000074b6341cf44e  movq xmm1, xmm1
000074b6341cf452  vmovaps [rsp+0x80], xmm1
000074b6341cf45b  movq xmm1, xmm1
000074b6341cf45f  movaps [r15+0x150], xmm1
000074b6341cf467  movq xmm10, xmm10
000074b6341cf46c  vmovaps [rsp+0x90], xmm10
000074b6341cf475  movq xmm10, xmm10
000074b6341cf47a  movaps [r15+0x140], xmm10
000074b6341cf482  lea r12, [rax+0x10]
000074b6341cf486  mov r11, [r13+r12*1]
000074b6341cf48b  lea r12, [rax+0x18]
000074b6341cf48f  mov r10, [r13+r12*1]
000074b6341cf494  movq xmm1, r11
000074b6341cf499  movq xmm10, r10
000074b6341cf49e  movq xmm1, xmm1
000074b6341cf4a2  vmovaps [rsp+0xA0], xmm1
000074b6341cf4ab  movq xmm1, xmm1
000074b6341cf4af  movaps [r15+0x170], xmm1
000074b6341cf4b7  movq xmm10, xmm10
000074b6341cf4bc  vmovaps [rsp+0xB0], xmm10
000074b6341cf4c5  movq xmm10, xmm10
000074b6341cf4ca  movaps [r15+0x160], xmm10
000074b6341cf4d2  mov r12, [r13+rax*1]
000074b6341cf4d7  vmovq xmm1, r12
000074b6341cf4dc  vpbroadcastq xmm1, xmm1
000074b6341cf4e1  lea r12, [rax+0x08]
000074b6341cf4e5  mov rax, [r13+r12*1]
000074b6341cf4ea  movq xmm10, rax
000074b6341cf4ef  movaps [r15+0x230], xmm10
000074b6341cf4f7  lea rax, [r14+0x50]
000074b6341cf4fb  movups xmm10, [r13+rax*1]
000074b6341cf501  lea rax, [r14+0x60]
000074b6341cf505  vmovaps [rsp+0xC0], xmm1
000074b6341cf50e  movups xmm1, [r13+rax*1]
000074b6341cf514  lea rax, [r14+0x30]
000074b6341cf518  vmovaps [rsp+0xD0], xmm1
000074b6341cf521  movups xmm1, [r13+rax*1]
000074b6341cf527  mov qword ptr [r15+0x60], 0x430920
000074b6341cf52f  mov qword ptr [r15+0x58], 0x40
000074b6341cf537  vmovaps [rsp+0xE0], xmm1
000074b6341cf540  vmovaps [rsp+0xF0], xmm15
000074b6341cf549  vmovaps xmm15, [rsp+0xC0]
000074b6341cf552  vmovaps [rsp+0xC0], xmm14
000074b6341cf55b  vmovaps xmm14, [rsp+0x40]
000074b6341cf561  vmovaps [rsp+0x40], xmm13
000074b6341cf567  movaps xmm1, xmm15
000074b6341cf56b  mulpd xmm1, xmm14
000074b6341cf570  vcmppd xmm13, xmm1, xmm1, 0x03
000074b6341cf575  ptest xmm13, xmm13
000074b6341cf57b  jnz 0x000074B6341D0682
000074b6341cf581  movq xmm14, qword ptr [r15+0x230]
000074b6341cf58a  vmovaps [rsp+0x100], xmm14
000074b6341cf593  vpermilpd xmm14, xmm14, 0x00
000074b6341cf599  vmovaps [rsp+0x110], xmm1
000074b6341cf5a2  vmovaps xmm1, [rsp+0xE0]
000074b6341cf5ab  vmovaps [rsp+0xE0], xmm15
000074b6341cf5b4  movaps xmm13, xmm1
000074b6341cf5b8  mulpd xmm13, xmm14
000074b6341cf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
000074b6341cf5c3  ptest xmm15, xmm15
000074b6341cf5c9  jnz 0x000074B6341D07C4
000074b6341cf5cf  vxorps xmm1, xmm1, xmm1
000074b6341cf5d3  vpbroadcastq xmm1, xmm1
000074b6341cf5d8  vmovaps xmm14, [rsp+0xE0]
000074b6341cf5e1  vmovaps [rsp+0xE0], xmm1
000074b6341cf5ea  vmovaps xmm1, [rsp+0xD0]
000074b6341cf5f3  vmovaps [rsp+0xD0], xmm13
000074b6341cf5fc  movaps xmm15, xmm14
000074b6341cf600  mulpd xmm15, xmm1
000074b6341cf605  vcmppd xmm13, xmm15, xmm15, 0x03
000074b6341cf60b  ptest xmm13, xmm13
000074b6341cf611  jnz 0x000074B6341D0907
000074b6341cf617  movaps xmm1, xmm14
000074b6341cf61b  mulpd xmm1, xmm10
000074b6341cf620  vcmppd xmm13, xmm1, xmm1, 0x03
000074b6341cf625  ptest xmm13, xmm13
000074b6341cf62b  jnz 0x000074B6341D0A4A
000074b6341cf631  movaps xmm13, xmm14
000074b6341cf635  mulpd xmm13, xmm2
000074b6341cf63a  vcmppd xmm10, xmm13, xmm13, 0x03
000074b6341cf640  ptest xmm10, xmm10
000074b6341cf646  jnz 0x000074B6341D0B8C
000074b6341cf64c  vmovaps [rsp+0x120], xmm7
000074b6341cf655  vmovaps xmm14, [rsp+0x120]
000074b6341cf65e  por xmm7, xmm14
000074b6341cf663  vmovaps xmm14, [rsp+0xC0]
000074b6341cf66c  vmovaps xmm10, [rsp+0xC0]
000074b6341cf675  por xmm14, xmm10
000074b6341cf67a  vmovaps xmm2, [rsp+0x100]
000074b6341cf683  vpermilpd xmm2, xmm2, 0x00
000074b6341cf689  vmovaps [rsp+0xC0], xmm1
000074b6341cf692  vmovaps [rsp+0x120], xmm15
000074b6341cf69b  movaps xmm1, xmm10
000074b6341cf69f  mulpd xmm1, xmm2
000074b6341cf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
000074b6341cf6a8  ptest xmm15, xmm15
000074b6341cf6ae  jnz 0x000074B6341D0CCF
000074b6341cf6b4  xor eax, eax
000074b6341cf6b6  mov r12d, 0x40
000074b6341cf6bc  mov r11d, 0x200
000074b6341cf6c2  cmp r12, r11
000074b6341cf6c5  cmc
000074b6341cf6c6  lahf
000074b6341cf6c7  seto al
000074b6341cf6ca  mov [r15+0x108], eax
000074b6341cf6d1  vmovaps xmm10, [rsp+0x110]
000074b6341cf6da  vmovaps xmm2, [rsp+0xE0]
000074b6341cf6e3  vmovaps [rsp+0xE0], xmm1
000074b6341cf6ec  movaps xmm15, xmm10
000074b6341cf6f0  addpd xmm15, xmm2
000074b6341cf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
000074b6341cf6fb  ptest xmm1, xmm1
000074b6341cf700  jnz 0x000074B6341D0E10
000074b6341cf706  vmovaps xmm10, [rsp+0x120]
000074b6341cf70f  vmovaps [rsp+0x110], xmm15
000074b6341cf718  movaps xmm1, xmm10
000074b6341cf71c  addpd xmm1, xmm12
000074b6341cf721  vcmppd xmm15, xmm1, xmm1, 0x03
000074b6341cf726  ptest xmm15, xmm15
000074b6341cf72c  jnz 0x000074B6341D0F53
000074b6341cf732  vmovaps xmm10, [rsp+0xC0]
000074b6341cf73b  vmovaps [rsp+0xC0], xmm1
000074b6341cf744  movaps xmm15, xmm10
000074b6341cf748  addpd xmm15, xmm12
000074b6341cf74d  vcmppd xmm1, xmm15, xmm15, 0x03
000074b6341cf753  ptest xmm1, xmm1
000074b6341cf758  jnz 0x000074B6341D1095
000074b6341cf75e  vmovaps xmm1, [rsp+0x30]
000074b6341cf764  vmovaps xmm12, [rsp+0x30]
000074b6341cf76a  por xmm1, xmm12
000074b6341cf76f  vmovaps xmm12, [rsp+0x20]
000074b6341cf775  vmovaps xmm10, [rsp+0x20]
000074b6341cf77b  por xmm12, xmm10
000074b6341cf780  vmovaps [rsp+0x20], xmm5
000074b6341cf786  vmovaps xmm10, [rsp+0x20]
000074b6341cf78c  por xmm5, xmm10
000074b6341cf791  vmovaps [rsp+0x20], xmm11
000074b6341cf797  vmovaps xmm10, [rsp+0x20]
000074b6341cf79d  por xmm11, xmm10
000074b6341cf7a2  vmovaps [rsp+0x20], xmm4
000074b6341cf7a8  vmovaps xmm10, [rsp+0x20]
000074b6341cf7ae  por xmm4, xmm10
000074b6341cf7b3  vmovaps [rsp+0x20], xmm8
000074b6341cf7b9  vmovaps xmm10, [rsp+0x20]
000074b6341cf7bf  por xmm8, xmm10
000074b6341cf7c4  vmovaps xmm10, [rsp+0xF0]
000074b6341cf7cd  vmovaps [rsp+0x20], xmm1
000074b6341cf7d3  vmovaps xmm1, [rsp+0xF0]
000074b6341cf7dc  por xmm10, xmm1
000074b6341cf7e1  lea rax, [r14+0xA0]
000074b6341cf7e8  movups xmm1, [r13+rax*1]
000074b6341cf7ee  lea rax, [r14+0xB0]
000074b6341cf7f5  vmovaps [rsp+0x30], xmm1
000074b6341cf7fb  movups xmm1, [r13+rax*1]
000074b6341cf801  vmovaps [rsp+0xF0], xmm1
000074b6341cf80a  vmovaps [rsp+0x120], xmm15
000074b6341cf813  movaps xmm1, xmm13
000074b6341cf817  addpd xmm1, xmm2
000074b6341cf81b  vcmppd xmm15, xmm1, xmm1, 0x03
000074b6341cf820  ptest xmm15, xmm15
000074b6341cf826  jnz 0x000074B6341D11ED
000074b6341cf82c  lea rax, [r14+0xF0]
000074b6341cf833  movups xmm15, [r13+rax*1]
000074b6341cf839  vmovaps xmm2, [rsp+0xC0]
000074b6341cf842  vmovaps [rsp+0xC0], xmm1
000074b6341cf84b  vmovaps xmm1, [rsp+0xE0]
000074b6341cf854  vmovaps [rsp+0xE0], xmm15
000074b6341cf85d  movaps xmm13, xmm2
000074b6341cf861  addpd xmm13, xmm1
000074b6341cf866  vcmppd xmm15, xmm13, xmm13, 0x03
000074b6341cf86c  ptest xmm15, xmm15
000074b6341cf872  jnz 0x000074B6341D1338
000074b6341cf878  vmovaps xmm15, [rsp+0x120]
000074b6341cf881  vmovaps xmm2, [rsp+0xD0]
000074b6341cf88a  vmovaps [rsp+0xD0], xmm14
000074b6341cf893  movaps xmm1, xmm15
000074b6341cf897  addpd xmm1, xmm2
000074b6341cf89b  vcmppd xmm14, xmm1, xmm1, 0x03
000074b6341cf8a0  ptest xmm14, xmm14
000074b6341cf8a6  jnz 0x000074B6341D147A
000074b6341cf8ac  vmovaps xmm15, [rsp+0x100]
000074b6341cf8b5  vpermilpd xmm15, xmm15, 0x00
000074b6341cf8bb  vmovaps xmm2, [rsp+0xF0]
000074b6341cf8c4  vmovaps [rsp+0xF0], xmm1
000074b6341cf8cd  movaps xmm14, xmm2
000074b6341cf8d1  mulpd xmm14, xmm15
000074b6341cf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
000074b6341cf8dc  ptest xmm1, xmm1
000074b6341cf8e1  jnz 0x000074B6341D15BB
000074b6341cf8e7  vmovaps xmm1, [rsp+0xA0]
000074b6341cf8f0  vpermilpd xmm1, xmm1, 0x00
000074b6341cf8f6  vmovaps xmm2, [rsp+0xE0]
000074b6341cf8ff  vmovaps [rsp+0xE0], xmm14
000074b6341cf908  movaps xmm15, xmm2
000074b6341cf90c  mulpd xmm15, xmm1
000074b6341cf911  vcmppd xmm14, xmm15, xmm15, 0x03
000074b6341cf917  ptest xmm14, xmm14
000074b6341cf91d  jnz 0x000074B6341D16FE
000074b6341cf923  lea rax, [r14+0xE0]
000074b6341cf92a  movups xmm1, [r13+rax*1]
000074b6341cf930  vmovaps xmm14, [rsp+0x100]
000074b6341cf939  vpermilpd xmm14, xmm14, 0x00
000074b6341cf93f  vmovaps [rsp+0x100], xmm1
000074b6341cf948  vmovaps xmm1, [rsp+0x30]
000074b6341cf94e  vmovaps [rsp+0x30], xmm15
000074b6341cf954  movaps xmm2, xmm1
000074b6341cf957  mulpd xmm2, xmm14
000074b6341cf95c  vcmppd xmm15, xmm2, xmm2, 0x03
000074b6341cf961  ptest xmm15, xmm15
000074b6341cf967  jnz 0x000074B6341D184A
000074b6341cf96d  vmovaps [rsp+0x120], xmm10
000074b6341cf976  vmovaps xmm1, [rsp+0x120]
000074b6341cf97f  por xmm10, xmm1
000074b6341cf984  movaps [r15+0x300], xmm10
000074b6341cf98c  vmovaps [rsp+0x120], xmm8
000074b6341cf995  vmovaps xmm1, [rsp+0x120]
000074b6341cf99e  por xmm8, xmm1
000074b6341cf9a3  movaps [r15+0x190], xmm8
000074b6341cf9ab  vmovaps xmm1, [rsp+0xA0]
000074b6341cf9b4  vpermilpd xmm1, xmm1, 0x00
000074b6341cf9ba  vmovaps xmm14, [rsp+0x100]
000074b6341cf9c3  vmovaps [rsp+0x100], xmm13
000074b6341cf9cc  movaps xmm15, xmm14
000074b6341cf9d0  mulpd xmm15, xmm1
000074b6341cf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
000074b6341cf9db  ptest xmm13, xmm13
000074b6341cf9e1  jnz 0x000074B6341D198B
000074b6341cf9e7  lea rax, [r14+0x90]
000074b6341cf9ee  movups xmm1, [r13+rax*1]
000074b6341cf9f4  vmovaps [rsp+0x120], xmm4
000074b6341cf9fd  vmovaps xmm14, [rsp+0x120]
000074b6341cfa06  por xmm4, xmm14
000074b6341cfa0b  movaps [r15+0x1C0], xmm4
000074b6341cfa13  vmovaps [rsp+0x120], xmm11
000074b6341cfa1c  vmovaps xmm14, [rsp+0x120]
000074b6341cfa25  por xmm11, xmm14
000074b6341cfa2a  movaps [r15+0x200], xmm11
000074b6341cfa32  vmovaps [rsp+0x120], xmm5
000074b6341cfa3b  vmovaps xmm14, [rsp+0x120]
000074b6341cfa44  por xmm5, xmm14
000074b6341cfa49  movaps [r15+0x2D0], xmm5
000074b6341cfa51  vmovaps [rsp+0x120], xmm12
000074b6341cfa5a  vmovaps xmm14, [rsp+0x120]
000074b6341cfa63  por xmm12, xmm14
000074b6341cfa68  movaps [r15+0x2E0], xmm12
000074b6341cfa70  vmovaps xmm13, [rsp+0x110]
000074b6341cfa79  vmovaps [rsp+0x110], xmm1
000074b6341cfa82  vmovaps xmm1, [rsp+0xE0]
000074b6341cfa8b  vmovaps [rsp+0xE0], xmm15
000074b6341cfa94  movaps xmm14, xmm13
000074b6341cfa98  addpd xmm14, xmm1
000074b6341cfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
000074b6341cfaa3  ptest xmm15, xmm15
000074b6341cfaa9  jnz 0x000074B6341D1AD8
000074b6341cfaaf  vmovaps xmm1, [rsp+0xA0]
000074b6341cfab8  vpermilpd xmm1, xmm1, 0x00
000074b6341cfabe  vmovaps xmm13, [rsp+0x110]
000074b6341cfac7  vmovaps [rsp+0x110], xmm14
000074b6341cfad0  movaps xmm15, xmm13
000074b6341cfad4  mulpd xmm15, xmm1
000074b6341cfad9  vcmppd xmm14, xmm15, xmm15, 0x03
000074b6341cfadf  ptest xmm14, xmm14
000074b6341cfae5  jnz 0x000074B6341D1C1B
000074b6341cfaeb  lea rax, [r14+0x80]
000074b6341cfaf2  movups xmm1, [r13+rax*1]
000074b6341cfaf8  vmovaps xmm13, [rsp+0xC0]
000074b6341cfb01  vmovaps [rsp+0xC0], xmm1
000074b6341cfb0a  movaps xmm14, xmm13
000074b6341cfb0e  addpd xmm14, xmm2
000074b6341cfb13  vcmppd xmm1, xmm14, xmm14, 0x03
000074b6341cfb19  ptest xmm1, xmm1
000074b6341cfb1e  jnz 0x000074B6341D1D68
000074b6341cfb24  vmovaps xmm13, [rsp+0x100]
000074b6341cfb2d  vmovaps xmm2, [rsp+0x30]
000074b6341cfb33  vmovaps [rsp+0x30], xmm15
000074b6341cfb39  movaps xmm1, xmm13
000074b6341cfb3d  addpd xmm1, xmm2
000074b6341cfb41  vcmppd xmm15, xmm1, xmm1, 0x03
000074b6341cfb46  ptest xmm15, xmm15
000074b6341cfb4c  jnz 0x000074B6341D1EAB
000074b6341cfb52  vmovaps xmm15, [rsp+0x20]
000074b6341cfb58  vmovaps xmm13, [rsp+0x20]
000074b6341cfb5e  por xmm15, xmm13
000074b6341cfb63  movaps [r15+0x2F0], xmm15
000074b6341cfb6b  vmovaps xmm13, [rsp+0xA0]
000074b6341cfb74  vpermilpd xmm13, xmm13, 0x00
000074b6341cfb7a  vmovaps [rsp+0x20], xmm1
000074b6341cfb80  vmovaps xmm1, [rsp+0xC0]
000074b6341cfb89  vmovaps [rsp+0xA0], xmm15
000074b6341cfb92  movaps xmm2, xmm1
000074b6341cfb95  mulpd xmm2, xmm13
000074b6341cfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
000074b6341cfb9f  ptest xmm15, xmm15
000074b6341cfba5  jnz 0x000074B6341D1FEC
000074b6341cfbab  lea rax, [r14+0xD0]
000074b6341cfbb2  movups xmm1, [r13+rax*1]
000074b6341cfbb8  vmovaps xmm13, [rsp+0xF0]
000074b6341cfbc1  vmovaps [rsp+0xC0], xmm1
000074b6341cfbca  vmovaps xmm1, [rsp+0xE0]
000074b6341cfbd3  vmovaps [rsp+0xE0], xmm14
000074b6341cfbdc  movaps xmm15, xmm13
000074b6341cfbe0  addpd xmm15, xmm1
000074b6341cfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
000074b6341cfbeb  ptest xmm14, xmm14
000074b6341cfbf1  jnz 0x000074B6341D2137
000074b6341cfbf7  vmovaps xmm1, [rsp+0xB0]
000074b6341cfc00  vpermilpd xmm1, xmm1, 0x00
000074b6341cfc06  movaps xmm14, xmm11
000074b6341cfc0a  mulpd xmm14, xmm1
000074b6341cfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
000074b6341cfc15  ptest xmm13, xmm13
000074b6341cfc1b  jnz 0x000074B6341D227A
000074b6341cfc21  movaps [r15+0x260], xmm14
000074b6341cfc29  vxorps xmm1, xmm1, xmm1
000074b6341cfc2d  vpbroadcastq xmm1, xmm1
000074b6341cfc32  movaps [r15+0x1B0], xmm1
000074b6341cfc3a  vmovaps xmm1, [rsp+0xB0]
000074b6341cfc43  vpermilpd xmm1, xmm1, 0x00
000074b6341cfc49  vmovaps xmm11, [rsp+0xC0]
000074b6341cfc52  vmovaps [rsp+0xC0], xmm15
000074b6341cfc5b  movaps xmm13, xmm11
000074b6341cfc5f  mulpd xmm13, xmm1
000074b6341cfc64  vcmppd xmm15, xmm13, xmm13, 0x03
000074b6341cfc6a  ptest xmm15, xmm15
000074b6341cfc70  jnz 0x000074B6341D23BD
000074b6341cfc76  lea rax, [r14+0xC0]
000074b6341cfc7d  movups xmm1, [r13+rax*1]
000074b6341cfc83  vmovaps xmm11, [rsp+0x110]
000074b6341cfc8c  vmovaps [rsp+0xF0], xmm1
000074b6341cfc95  vmovaps xmm1, [rsp+0x30]
000074b6341cfc9b  vmovaps [rsp+0x30], xmm14
000074b6341cfca1  movaps xmm15, xmm11
000074b6341cfca5  addpd xmm15, xmm1
000074b6341cfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
000074b6341cfcb0  ptest xmm14, xmm14
000074b6341cfcb6  jnz 0x000074B6341D250A
000074b6341cfcbc  vmovaps [rsp+0x100], xmm9
000074b6341cfcc5  vmovaps xmm1, [rsp+0x100]
000074b6341cfcce  por xmm9, xmm1
000074b6341cfcd3  movaps [r15+0x270], xmm9
000074b6341cfcdb  vmovaps [rsp+0x100], xmm6
000074b6341cfce4  vmovaps xmm1, [rsp+0x100]
000074b6341cfced  por xmm6, xmm1
000074b6341cfcf1  movaps [r15+0x1A0], xmm6
000074b6341cfcf9  vmovaps xmm14, [rsp+0xB0]
000074b6341cfd02  vpermilpd xmm14, xmm14, 0x00
000074b6341cfd08  vmovaps xmm6, [rsp+0xF0]
000074b6341cfd11  vmovaps [rsp+0xF0], xmm1
000074b6341cfd1a  movaps xmm11, xmm6
000074b6341cfd1e  mulpd xmm11, xmm14
000074b6341cfd23  vcmppd xmm1, xmm11, xmm11, 0x03
000074b6341cfd29  ptest xmm1, xmm1
000074b6341cfd2e  jnz 0x000074B6341D264D
000074b6341cfd34  lea rax, [r14+0x20]
000074b6341cfd38  movups xmm1, [r13+rax*1]
000074b6341cfd3e  movaps [r15+0x110], xmm1
000074b6341cfd46  vmovaps xmm6, [rsp+0xE0]
000074b6341cfd4f  vmovaps [rsp+0xE0], xmm1
000074b6341cfd58  movaps xmm14, xmm6
000074b6341cfd5c  addpd xmm14, xmm2
000074b6341cfd61  vcmppd xmm1, xmm14, xmm14, 0x03
000074b6341cfd67  ptest xmm1, xmm1
000074b6341cfd6c  jnz 0x000074B6341D279A
000074b6341cfd72  vmovaps xmm1, [rsp+0xB0]
000074b6341cfd7b  vpermilpd xmm1, xmm1, 0x00
000074b6341cfd81  movaps xmm6, xmm5
000074b6341cfd84  mulpd xmm6, xmm1
000074b6341cfd88  vcmppd xmm2, xmm6, xmm6, 0x03
000074b6341cfd8d  ptest xmm2, xmm2
000074b6341cfd92  jnz 0x000074B6341D28DC
000074b6341cfd98  vmovaps xmm5, [rsp+0x20]
000074b6341cfd9e  movaps xmm1, xmm5
000074b6341cfda1  addpd xmm1, xmm13
000074b6341cfda6  vcmppd xmm2, xmm1, xmm1, 0x03
000074b6341cfdab  ptest xmm2, xmm2
000074b6341cfdb0  jnz 0x000074B6341D2A1C
000074b6341cfdb6  vmovaps xmm13, [rsp+0x80]
000074b6341cfdbf  vpermilpd xmm13, xmm13, 0x00
000074b6341cfdc5  vmovaps xmm2, [rsp+0xE0]
000074b6341cfdce  vmovaps [rsp+0x20], xmm1
000074b6341cfdd4  movaps xmm5, xmm2
000074b6341cfdd7  mulpd xmm5, xmm13
000074b6341cfddc  vcmppd xmm1, xmm5, xmm5, 0x03
000074b6341cfde1  ptest xmm1, xmm1
000074b6341cfde6  jnz 0x000074B6341D2B5D
000074b6341cfdec  vmovaps xmm1, [rsp+0x80]
000074b6341cfdf5  vpermilpd xmm1, xmm1, 0x00
000074b6341cfdfb  movaps xmm13, xmm10
000074b6341cfdff  mulpd xmm13, xmm1
000074b6341cfe04  vcmppd xmm2, xmm13, xmm13, 0x03
000074b6341cfe0a  ptest xmm2, xmm2
000074b6341cfe0f  jnz 0x000074B6341D2C9E
000074b6341cfe15  vmovaps xmm10, [rsp+0x30]
000074b6341cfe1b  movaps xmm1, xmm15
000074b6341cfe1f  addpd xmm1, xmm10
000074b6341cfe24  vcmppd xmm2, xmm1, xmm1, 0x03
000074b6341cfe29  ptest xmm2, xmm2
000074b6341cfe2e  jnz 0x000074B6341D2DE1
000074b6341cfe34  vmovaps xmm10, [rsp+0xC0]
000074b6341cfe3d  movaps xmm15, xmm10
000074b6341cfe41  addpd xmm15, xmm11
000074b6341cfe46  vcmppd xmm2, xmm15, xmm15, 0x03
000074b6341cfe4c  ptest xmm2, xmm2
000074b6341cfe51  jnz 0x000074B6341D2F23
000074b6341cfe57  vmovaps xmm11, [rsp+0x80]
000074b6341cfe60  vpermilpd xmm11, xmm11, 0x00
000074b6341cfe66  movaps xmm10, xmm12
000074b6341cfe6a  mulpd xmm10, xmm11
000074b6341cfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
000074b6341cfe75  ptest xmm2, xmm2
000074b6341cfe7a  jnz 0x000074B6341D3067
000074b6341cfe80  vmovaps xmm12, [rsp+0x80]
000074b6341cfe89  vpermilpd xmm12, xmm12, 0x00
000074b6341cfe8f  vmovaps xmm2, [rsp+0xA0]
000074b6341cfe98  vmovaps [rsp+0x30], xmm1
000074b6341cfe9e  movaps xmm11, xmm2
000074b6341cfea2  mulpd xmm11, xmm12
000074b6341cfea7  vcmppd xmm1, xmm11, xmm11, 0x03
000074b6341cfead  ptest xmm1, xmm1
000074b6341cfeb2  jnz 0x000074B6341D31AB
000074b6341cfeb8  movaps xmm1, xmm14
000074b6341cfebc  addpd xmm1, xmm6
000074b6341cfec0  vcmppd xmm12, xmm1, xmm1, 0x03
000074b6341cfec5  ptest xmm12, xmm12
000074b6341cfecb  jnz 0x000074B6341D32EE
000074b6341cfed1  vmovaps xmm12, [rsp+0x20]
000074b6341cfed7  movaps xmm14, xmm12
000074b6341cfedb  addpd xmm14, xmm5
000074b6341cfee0  vcmppd xmm6, xmm14, xmm14, 0x03
000074b6341cfee6  ptest xmm6, xmm6
000074b6341cfeeb  jnz 0x000074B6341D342F
000074b6341cfef1  vmovaps xmm12, [rsp+0x90]
000074b6341cfefa  vpermilpd xmm12, xmm12, 0x00
000074b6341cff00  movaps xmm6, xmm9
000074b6341cff04  mulpd xmm6, xmm12
000074b6341cff09  vcmppd xmm5, xmm6, xmm6, 0x03
000074b6341cff0e  ptest xmm5, xmm5
000074b6341cff13  jnz 0x000074B6341D3572
000074b6341cff19  movaps xmm12, xmm15
000074b6341cff1d  addpd xmm12, xmm13
000074b6341cff22  vcmppd xmm9, xmm12, xmm12, 0x03
000074b6341cff28  ptest xmm9, xmm9
000074b6341cff2e  jnz 0x000074B6341D36B4
000074b6341cff34  vmovaps xmm13, [rsp+0x30]
000074b6341cff3a  movaps xmm15, xmm13
000074b6341cff3e  addpd xmm15, xmm10
000074b6341cff43  vcmppd xmm9, xmm15, xmm15, 0x03
000074b6341cff49  ptest xmm9, xmm9
000074b6341cff4f  jnz 0x000074B6341D37F8
000074b6341cff55  vmovaps xmm13, [rsp+0xD0]
000074b6341cff5e  vmovaps xmm10, [rsp+0xD0]
000074b6341cff67  por xmm13, xmm10
000074b6341cff6c  movaps [r15+0x250], xmm13
000074b6341cff74  vmovaps [rsp+0x20], xmm7
000074b6341cff7a  vmovaps xmm13, [rsp+0x20]
000074b6341cff80  por xmm7, xmm13
000074b6341cff85  movaps [r15+0x2A0], xmm7
000074b6341cff8d  vmovaps [rsp+0x20], xmm3
000074b6341cff93  vmovaps xmm13, [rsp+0x20]
000074b6341cff99  por xmm3, xmm13
000074b6341cff9e  movaps [r15+0x1D0], xmm3
000074b6341cffa6  lea rax, [r14+0x40]
000074b6341cffaa  movups xmm13, [r13+rax*1]
000074b6341cffb0  movaps [r15+0x2C0], xmm13
000074b6341cffb8  vmovaps xmm10, [rsp+0x90]
000074b6341cffc1  vpermilpd xmm10, xmm10, 0x00
000074b6341cffc7  movaps xmm9, xmm8
000074b6341cffcb  mulpd xmm9, xmm10
000074b6341cffd0  vcmppd xmm5, xmm9, xmm9, 0x03
000074b6341cffd6  ptest xmm5, xmm5
000074b6341cffdb  jnz 0x000074B6341D3946
000074b6341cffe1  movaps xmm10, xmm1
000074b6341cffe5  addpd xmm10, xmm11
000074b6341cffea  vcmppd xmm8, xmm10, xmm10, 0x03
000074b6341cfff0  ptest xmm8, xmm8
000074b6341cfff6  jnz 0x000074B6341D3A8A
000074b6341cfffc  movaps xmm1, xmm14
000074b6341d0000  addpd xmm1, xmm6
000074b6341d0004  vcmppd xmm11, xmm1, xmm1, 0x03
000074b6341d0009  ptest xmm11, xmm11
000074b6341d000f  jnz 0x000074B6341D3BCD
000074b6341d0015  vmovaps xmm14, [rsp+0x90]
000074b6341d001e  vpermilpd xmm14, xmm14, 0x00
000074b6341d0024  movaps xmm11, xmm13
000074b6341d0028  mulpd xmm11, xmm14
000074b6341d002d  vcmppd xmm8, xmm11, xmm11, 0x03
000074b6341d0033  ptest xmm8, xmm8
000074b6341d0039  jnz 0x000074B6341D3D0E
000074b6341d003f  vmovaps xmm14, [rsp+0x90]
000074b6341d0048  vpermilpd xmm14, xmm14, 0x00
000074b6341d004e  vmovaps xmm8, [rsp+0x10]
000074b6341d0054  movaps xmm13, xmm8
000074b6341d0058  mulpd xmm13, xmm14
000074b6341d005d  vcmppd xmm6, xmm13, xmm13, 0x03
000074b6341d0063  ptest xmm6, xmm6
000074b6341d0068  jnz 0x000074B6341D3E52
000074b6341d006e  vmovaps xmm14, [rsp+0x60]
000074b6341d0074  vpermilpd xmm14, xmm14, 0x00
000074b6341d007a  movaps xmm8, xmm7
000074b6341d007e  mulpd xmm8, xmm14
000074b6341d0083  vcmppd xmm6, xmm8, xmm8, 0x03
000074b6341d0089  ptest xmm6, xmm6
000074b6341d008e  jnz 0x000074B6341D3F96
000074b6341d0094  movaps xmm14, xmm12
000074b6341d0098  addpd xmm14, xmm9
000074b6341d009d  vcmppd xmm7, xmm14, xmm14, 0x03
000074b6341d00a3  ptest xmm7, xmm7
000074b6341d00a8  jnz 0x000074B6341D40D9
000074b6341d00ae  vmovaps xmm12, [rsp+0x60]
000074b6341d00b4  vpermilpd xmm12, xmm12, 0x00
000074b6341d00ba  vmovaps xmm7, [rsp+0xF0]
000074b6341d00c3  movaps xmm9, xmm7
000074b6341d00c7  mulpd xmm9, xmm12
000074b6341d00cc  vcmppd xmm6, xmm9, xmm9, 0x03
000074b6341d00d2  ptest xmm6, xmm6
000074b6341d00d7  jnz 0x000074B6341D421D
000074b6341d00dd  movaps xmm12, xmm15
000074b6341d00e1  addpd xmm12, xmm11
000074b6341d00e6  vcmppd xmm7, xmm12, xmm12, 0x03
000074b6341d00ec  ptest xmm7, xmm7
000074b6341d00f1  jnz 0x000074B6341D4360
000074b6341d00f7  vmovaps xmm15, [rsp+0x60]
000074b6341d00fd  vpermilpd xmm15, xmm15, 0x00
000074b6341d0103  vmovaps xmm7, [rsp+0x40]
000074b6341d0109  movaps xmm11, xmm7
000074b6341d010d  mulpd xmm11, xmm15
000074b6341d0112  vcmppd xmm6, xmm11, xmm11, 0x03
000074b6341d0118  ptest xmm6, xmm6
000074b6341d011d  jnz 0x000074B6341D44A4
000074b6341d0123  movaps xmm15, xmm10
000074b6341d0127  addpd xmm15, xmm13
000074b6341d012c  vcmppd xmm7, xmm15, xmm15, 0x03
000074b6341d0132  ptest xmm7, xmm7
000074b6341d0137  jnz 0x000074B6341D45E7
000074b6341d013d  vmovaps xmm13, [rsp+0x60]
000074b6341d0143  vpermilpd xmm13, xmm13, 0x00
000074b6341d0149  vmovaps xmm7, [rsp+0x50]
000074b6341d014f  movaps xmm10, xmm7
000074b6341d0153  mulpd xmm10, xmm13
000074b6341d0158  vcmppd xmm6, xmm10, xmm10, 0x03
000074b6341d015e  ptest xmm6, xmm6
000074b6341d0163  jnz 0x000074B6341D472B
000074b6341d0169  movaps xmm13, xmm1
000074b6341d016d  addpd xmm13, xmm8
000074b6341d0172  vcmppd xmm7, xmm13, xmm13, 0x03
000074b6341d0178  ptest xmm7, xmm7
000074b6341d017d  jnz 0x000074B6341D486E
000074b6341d0183  lea rax, [r14+0x70]
000074b6341d0187  movups xmm1, [r13+rax*1]
000074b6341d018d  movaps [r15+0x240], xmm1
000074b6341d0195  movaps xmm8, xmm14
000074b6341d0199  addpd xmm8, xmm9
000074b6341d019e  vcmppd xmm7, xmm8, xmm8, 0x03
000074b6341d01a4  ptest xmm7, xmm7
000074b6341d01a9  jnz 0x000074B6341D49BB
000074b6341d01af  movaps [r15+0x170], xmm8
000074b6341d01b7  vmovaps xmm14, [rsp+0x70]
000074b6341d01bd  vpermilpd xmm14, xmm14, 0x00
000074b6341d01c3  movaps xmm9, xmm1
000074b6341d01c7  mulpd xmm9, xmm14
000074b6341d01cc  vcmppd xmm7, xmm9, xmm9, 0x03
000074b6341d01d2  ptest xmm7, xmm7
000074b6341d01d7  jnz 0x000074B6341D4AFF
000074b6341d01dd  vmovaps xmm1, [rsp+0x70]
000074b6341d01e3  vpermilpd xmm1, xmm1, 0x00
000074b6341d01e9  movaps xmm14, xmm4
000074b6341d01ed  mulpd xmm14, xmm1
000074b6341d01f2  vcmppd xmm7, xmm14, xmm14, 0x03
000074b6341d01f8  ptest xmm7, xmm7
000074b6341d01fd  jnz 0x000074B6341D4C42
000074b6341d0203  movaps [r15+0x180], xmm14
000074b6341d020b  movaps xmm1, xmm12
000074b6341d020f  addpd xmm1, xmm11
000074b6341d0214  vcmppd xmm7, xmm1, xmm1, 0x03
000074b6341d0219  ptest xmm7, xmm7
000074b6341d021e  jnz 0x000074B6341D4D84
000074b6341d0224  movaps [r15+0x210], xmm1
000074b6341d022c  movups xmm12, [r13+r14*1]
000074b6341d0232  lea rax, [r14+0x10]
000074b6341d0236  movups xmm11, [r13+rax*1]
000074b6341d023c  movaps [r15+0x230], xmm11
000074b6341d0244  movaps xmm7, xmm15
000074b6341d0248  addpd xmm7, xmm10
000074b6341d024d  vcmppd xmm6, xmm7, xmm7, 0x03
000074b6341d0252  ptest xmm6, xmm6
000074b6341d0257  jnz 0x000074B6341D4EDA
000074b6341d025d  movaps [r15+0x130], xmm7
000074b6341d0265  vmovaps xmm15, [rsp+0x70]
000074b6341d026b  vpermilpd xmm15, xmm15, 0x00
000074b6341d0271  movaps xmm10, xmm11
000074b6341d0275  mulpd xmm10, xmm15
000074b6341d027a  vcmppd xmm6, xmm10, xmm10, 0x03
000074b6341d0280  ptest xmm6, xmm6
000074b6341d0285  jnz 0x000074B6341D501C
000074b6341d028b  movaps [r15+0x220], xmm10
000074b6341d0293  vmovaps xmm15, [rsp+0x70]
000074b6341d0299  vpermilpd xmm15, xmm15, 0x00
000074b6341d029f  movaps xmm11, xmm12
000074b6341d02a3  mulpd xmm11, xmm15
000074b6341d02a8  vcmppd xmm6, xmm11, xmm11, 0x03
000074b6341d02ae  ptest xmm6, xmm6
000074b6341d02b3  jnz 0x000074B6341D5160
000074b6341d02b9  movaps xmm15, xmm13
000074b6341d02bd  addpd xmm15, xmm9
000074b6341d02c2  vcmppd xmm12, xmm15, xmm15, 0x03
000074b6341d02c8  ptest xmm12, xmm12
000074b6341d02ce  jnz 0x000074B6341D52A4
000074b6341d02d4  movaps [r15+0x140], xmm15
000074b6341d02dc  movaps xmm13, xmm8
000074b6341d02e0  addpd xmm13, xmm14
000074b6341d02e5  vcmppd xmm12, xmm13, xmm13, 0x03
000074b6341d02eb  ptest xmm12, xmm12
000074b6341d02f1  jnz 0x000074B6341D53E8
000074b6341d02f7  movaps [r15+0x150], xmm13
000074b6341d02ff  movaps xmm14, xmm1
000074b6341d0303  addpd xmm14, xmm10
000074b6341d0308  vcmppd xmm12, xmm14, xmm14, 0x03
000074b6341d030e  ptest xmm12, xmm12
000074b6341d0314  jnz 0x000074B6341D552C
000074b6341d031a  movaps [r15+0x160], xmm14
000074b6341d0322  movaps xmm1, xmm7
000074b6341d0325  addpd xmm1, xmm11
000074b6341d032a  vcmppd xmm12, xmm1, xmm1, 0x03
000074b6341d032f  ptest xmm12, xmm12
000074b6341d0335  jnz 0x000074B6341D566F
000074b6341d033b  movaps [r15+0x120], xmm1
000074b6341d0343  mov eax, 0x430920
000074b6341d0348  movups [r13+rax*1], xmm15
000074b6341d034e  mov eax, 0x430930
000074b6341d0353  movups [r13+rax*1], xmm13
000074b6341d0359  mov eax, 0x430940
000074b6341d035e  movups [r13+rax*1], xmm14
000074b6341d0364  mov eax, 0x430950
000074b6341d0369  movups [r13+rax*1], xmm1
000074b6341d036f  mov eax, [r15+0x108]
000074b6341d0376  sahf
000074b6341d0377  jnz 0x000074B6341D03A9
000074b6341d0379  cmp dword ptr [r15+0x318], 0x00
000074b6341d0381  jz 0x000074B6341DB900
000074b6341d0387  nop [rax+rax*1], ax
000074b6341d0390  nop [rax+rax*1], eax
000074b6341d0398  mov eax, 0x410444
000074b6341d039d  mov [r15+0x100], rax
000074b6341d03a4  jmp 0x000074B633FFE110
000074b6341d03a9  cmp dword ptr [r15+0x318], 0x00
000074b6341d03b1  jz 0x000074B6341D57E0
000074b6341d03b7  nop [rax+rax*1], ax
000074b6341d03c0  nop [rax+rax*1], eax
000074b6341d03c8  mov eax, 0x410278
000074b6341d03cd  mov [r15+0x100], rax
000074b6341d03d4  jmp 0x000074B633FFE110
000074b6341d03d9  int3
000074b6341d03da  call 0x000074B6340B52F0
000074b6341d03df  jmp 0x000074B6341CF016
000074b6341d03e4  call 0x000074B6340C4620
000074b6341d03e9  jmp 0x000074B6341CF023
000074b6341d03ee  call 0x000074B6340C33A0
000074b6341d03f3  jmp 0x000074B6341CF035
000074b6341d03f8  call 0x000074B6340C2120
000074b6341d03fd  jmp 0x000074B6341CF03F
000074b6341d0402  call 0x000074B6340C0860
000074b6341d0407  jmp 0x000074B6341CF067
000074b6341d040c  call 0x000074B6340BF5F0
000074b6341d0411  jmp 0x000074B6341CF073
000074b6341d0416  call 0x000074B6340C0860
000074b6341d041b  jmp 0x000074B6341CF0A5
000074b6341d0420  call 0x000074B6340BF5F0
000074b6341d0425  jmp 0x000074B6341CF0B1
000074b6341d042a  call 0x000074B6340C4740
000074b6341d042f  jmp 0x000074B6341CF0BE
000074b6341d0434  call 0x000074B6340B5400
000074b6341d0439  jmp 0x000074B6341CF0CB
000074b6341d043e  call 0x000074B6340B52F0
000074b6341d0443  jmp 0x000074B6341CF0D8
000074b6341d0448  call 0x000074B6340C4620
000074b6341d044d  jmp 0x000074B6341CF0E5
000074b6341d0452  call 0x000074B6340C0860
000074b6341d0457  jmp 0x000074B6341CF10D
000074b6341d045c  call 0x000074B6340BF5F0
000074b6341d0461  jmp 0x000074B6341CF119
000074b6341d0466  call 0x000074B634009D70
000074b6341d046b  jmp 0x000074B6341CF11F
000074b6341d0470  call 0x000074B6340BE9C0
000074b6341d0475  jmp 0x000074B6341CF129
000074b6341d047a  call 0x000074B6340C0860
000074b6341d047f  jmp 0x000074B6341CF151
000074b6341d0484  call 0x000074B6340BF5F0
000074b6341d0489  jmp 0x000074B6341CF15D
000074b6341d048e  call 0x000074B6340BD750
000074b6341d0493  jmp 0x000074B6341CF16A
000074b6341d0498  call 0x000074B6340BC4E0
000074b6341d049d  jmp 0x000074B6341CF177
000074b6341d04a2  call 0x000074B6340C4740
000074b6341d04a7  jmp 0x000074B6341CF184
000074b6341d04ac  call 0x000074B6340B5400
000074b6341d04b1  jmp 0x000074B6341CF191
000074b6341d04b6  call 0x000074B6340B52F0
000074b6341d04bb  jmp 0x000074B6341CF19E
000074b6341d04c0  call 0x000074B6340C4620
000074b6341d04c5  jmp 0x000074B6341CF1AB
000074b6341d04ca  call 0x000074B6340C0860
000074b6341d04cf  jmp 0x000074B6341CF1BE
000074b6341d04d4  call 0x000074B6340BB270
000074b6341d04d9  jmp 0x000074B6341CF1CB
000074b6341d04de  call 0x000074B6340BA000
000074b6341d04e3  jmp 0x000074B6341CF1D8
000074b6341d04e8  call 0x000074B6340B8D90
000074b6341d04ed  jmp 0x000074B6341CF1E5
000074b6341d04f2  call 0x000074B6340B8A20
000074b6341d04f7  jmp 0x000074B6341CF1F2
000074b6341d04fc  call 0x000074B6340B5400
000074b6341d0501  jmp 0x000074B6341CF1FC
000074b6341d0506  call 0x000074B6340C2240
000074b6341d050b  jmp 0x000074B6341CF206
000074b6341d0510  call 0x000074B6340B52F0
000074b6341d0515  jmp 0x000074B6341CF210
000074b6341d051a  call 0x000074B6340C2120
000074b6341d051f  jmp 0x000074B6341CF21A
000074b6341d0524  call 0x000074B6340B77B0
000074b6341d0529  jmp 0x000074B6341CF224
000074b6341d052e  call 0x000074B6340B6550
000074b6341d0533  jmp 0x000074B6341CF22E
000074b6341d0538  call 0x000074B6340BFD50
000074b6341d053d  jmp 0x000074B6341CF240
000074b6341d0542  call 0x000074B6340B8EA0
000074b6341d0547  jmp 0x000074B6341CF24A
000074b6341d054c  call 0x000074B6340BFC30
000074b6341d0551  jmp 0x000074B6341CF257
000074b6341d0556  call 0x000074B6340B8D90
000074b6341d055b  jmp 0x000074B6341CF264
000074b6341d0560  call 0x000074B6340C2240
000074b6341d0565  jmp 0x000074B6341CF271
000074b6341d056a  call 0x000074B6340B5400
000074b6341d056f  jmp 0x000074B6341CF27E
000074b6341d0574  call 0x000074B6340B52F0
000074b6341d0579  jmp 0x000074B6341CF28B
000074b6341d057e  call 0x000074B6340C2120
000074b6341d0583  jmp 0x000074B6341CF298
000074b6341d0588  call 0x000074B6340B52F0
000074b6341d058d  jmp 0x000074B6341CF2AB
000074b6341d0592  call 0x000074B6340B52F0
000074b6341d0597  jmp 0x000074B6341CF2BE
000074b6341d059c  call 0x000074B6340B52F0
000074b6341d05a1  jmp 0x000074B6341CF2D1
000074b6341d05a6  call 0x000074B6340B52F0
000074b6341d05ab  jmp 0x000074B6341CF2E4
000074b6341d05b0  call 0x000074B6340C2240
000074b6341d05b5  jmp 0x000074B6341CF2F9
000074b6341d05ba  call 0x000074B6340C2240
000074b6341d05bf  jmp 0x000074B6341CF30C
000074b6341d05c4  call 0x000074B6340C2120
000074b6341d05c9  jmp 0x000074B6341CF319
000074b6341d05ce  call 0x000074B6340B52F0
000074b6341d05d3  jmp 0x000074B6341CF32C
000074b6341d05d8  call 0x000074B6340B52F0
000074b6341d05dd  jmp 0x000074B6341CF34F
000074b6341d05e2  call 0x000074B6340B52F0
000074b6341d05e7  jmp 0x000074B6341CF362
000074b6341d05ec  call 0x000074B633FFF540
000074b6341d05f1  jmp 0x000074B6341CF380
000074b6341d05f6  call 0x000074B634008C20
000074b6341d05fb  jmp 0x000074B6341CF38A
000074b6341d0600  call 0x000074B6340D6600
000074b6341d0605  jmp 0x000074B6341CF396
000074b6341d060a  call 0x000074B633FFF540
000074b6341d060f  jmp 0x000074B6341CF3A6
000074b6341d0614  call 0x000074B6340C0370
000074b6341d0619  jmp 0x000074B6341CF3D4
000074b6341d061e  call 0x000074B6340BF100
000074b6341d0623  jmp 0x000074B6341CF3DD
000074b6341d0628  call 0x000074B6340C0370
000074b6341d062d  jmp 0x000074B6341CF43B
000074b6341d0632  call 0x000074B6340BF100
000074b6341d0637  jmp 0x000074B6341CF444
000074b6341d063c  call 0x000074B6340C0370
000074b6341d0641  jmp 0x000074B6341CF48B
000074b6341d0646  call 0x000074B6340BF100
000074b6341d064b  jmp 0x000074B6341CF494
000074b6341d0650  call 0x000074B63400B720
000074b6341d0655  jmp 0x000074B6341CF4D7
000074b6341d065a  call 0x000074B6340B47C0
000074b6341d065f  jmp 0x000074B6341CF4EA
000074b6341d0664  call 0x000074B634008B00
000074b6341d0669  jmp 0x000074B6341CF501
000074b6341d066e  call 0x000074B633FFF430
000074b6341d0673  jmp 0x000074B6341CF514
000074b6341d0678  call 0x000074B633FFF430
000074b6341d067d  jmp 0x000074B6341CF527
000074b6341d0682  sub rsp, 0x08
000074b6341d0686  push rax
000074b6341d0687  push rcx
000074b6341d0688  push rdx
000074b6341d0689  push rdi
000074b6341d068a  push rsi
000074b6341d068b  push r8
000074b6341d068d  push r9
000074b6341d068f  push r10
000074b6341d0691  push r11
000074b6341d0693  sub rsp, 0xF0
000074b6341d069a  vmovaps [rsp], xmm0
000074b6341d069f  vmovaps [rsp+0x10], xmm2
000074b6341d06a5  vmovaps [rsp+0x20], xmm3
000074b6341d06ab  vmovaps [rsp+0x30], xmm4
000074b6341d06b1  vmovaps [rsp+0x40], xmm5
000074b6341d06b7  vmovaps [rsp+0x50], xmm6
000074b6341d06bd  vmovaps [rsp+0x60], xmm7
000074b6341d06c3  vmovaps [rsp+0x70], xmm8
000074b6341d06c9  vmovaps [rsp+0x80], xmm9
000074b6341d06d2  vmovaps [rsp+0x90], xmm10
000074b6341d06db  vmovaps [rsp+0xA0], xmm11
000074b6341d06e4  vmovaps [rsp+0xB0], xmm12
000074b6341d06ed  vmovaps [rsp+0xC0], xmm13
000074b6341d06f6  vmovaps [rsp+0xD0], xmm14
000074b6341d06ff  vmovaps [rsp+0xE0], xmm15
000074b6341d0708  sub rsp, 0x30
000074b6341d070c  movaps [rsp], xmm1
000074b6341d0710  movaps [rsp+0x10], xmm15
000074b6341d0716  movaps [rsp+0x20], xmm14
000074b6341d071c  lea rdi, [rsp]
000074b6341d0720  mov esi, 0x00
000074b6341d0725  mov rax, 0x5E1AA0A2F530
000074b6341d072f  call rax
000074b6341d0731  movaps xmm1, [rsp]
000074b6341d0735  add rsp, 0x30
000074b6341d0739  vmovaps xmm0, [rsp]
000074b6341d073e  vmovaps xmm2, [rsp+0x10]
000074b6341d0744  vmovaps xmm3, [rsp+0x20]
000074b6341d074a  vmovaps xmm4, [rsp+0x30]
000074b6341d0750  vmovaps xmm5, [rsp+0x40]
000074b6341d0756  vmovaps xmm6, [rsp+0x50]
000074b6341d075c  vmovaps xmm7, [rsp+0x60]
000074b6341d0762  vmovaps xmm8, [rsp+0x70]
000074b6341d0768  vmovaps xmm9, [rsp+0x80]
000074b6341d0771  vmovaps xmm10, [rsp+0x90]
000074b6341d077a  vmovaps xmm11, [rsp+0xA0]
000074b6341d0783  vmovaps xmm12, [rsp+0xB0]
000074b6341d078c  vmovaps xmm13, [rsp+0xC0]
000074b6341d0795  vmovaps xmm14, [rsp+0xD0]
000074b6341d079e  vmovaps xmm15, [rsp+0xE0]
000074b6341d07a7  add rsp, 0xF0
000074b6341d07ae  pop r11
000074b6341d07b0  pop r10
000074b6341d07b2  pop r9
000074b6341d07b4  pop r8
000074b6341d07b6  pop rsi
000074b6341d07b7  pop rdi
000074b6341d07b8  pop rdx
000074b6341d07b9  pop rcx
000074b6341d07ba  pop rax
000074b6341d07bb  add rsp, 0x08
000074b6341d07bf  jmp 0x000074B6341CF581
000074b6341d07c4  sub rsp, 0x08
000074b6341d07c8  push rax
000074b6341d07c9  push rcx
000074b6341d07ca  push rdx
000074b6341d07cb  push rdi
000074b6341d07cc  push rsi
000074b6341d07cd  push r8
000074b6341d07cf  push r9
000074b6341d07d1  push r10
000074b6341d07d3  push r11
000074b6341d07d5  sub rsp, 0xF0
000074b6341d07dc  vmovaps [rsp], xmm0
000074b6341d07e1  vmovaps [rsp+0x10], xmm1
000074b6341d07e7  vmovaps [rsp+0x20], xmm2
000074b6341d07ed  vmovaps [rsp+0x30], xmm3
000074b6341d07f3  vmovaps [rsp+0x40], xmm4
000074b6341d07f9  vmovaps [rsp+0x50], xmm5
000074b6341d07ff  vmovaps [rsp+0x60], xmm6
000074b6341d0805  vmovaps [rsp+0x70], xmm7
000074b6341d080b  vmovaps [rsp+0x80], xmm8
000074b6341d0814  vmovaps [rsp+0x90], xmm9
000074b6341d081d  vmovaps [rsp+0xA0], xmm10
000074b6341d0826  vmovaps [rsp+0xB0], xmm11
000074b6341d082f  vmovaps [rsp+0xC0], xmm12
000074b6341d0838  vmovaps [rsp+0xD0], xmm14
000074b6341d0841  vmovaps [rsp+0xE0], xmm15
000074b6341d084a  sub rsp, 0x30
000074b6341d084e  movaps [rsp], xmm13
000074b6341d0853  movaps [rsp+0x10], xmm1
000074b6341d0858  movaps [rsp+0x20], xmm14
000074b6341d085e  lea rdi, [rsp]
000074b6341d0862  mov esi, 0x00
000074b6341d0867  mov rax, 0x5E1AA0A2F530
000074b6341d0871  call rax
000074b6341d0873  movaps xmm13, [rsp]
000074b6341d0878  add rsp, 0x30
000074b6341d087c  vmovaps xmm0, [rsp]
000074b6341d0881  vmovaps xmm1, [rsp+0x10]
000074b6341d0887  vmovaps xmm2, [rsp+0x20]
000074b6341d088d  vmovaps xmm3, [rsp+0x30]
000074b6341d0893  vmovaps xmm4, [rsp+0x40]
000074b6341d0899  vmovaps xmm5, [rsp+0x50]
000074b6341d089f  vmovaps xmm6, [rsp+0x60]
000074b6341d08a5  vmovaps xmm7, [rsp+0x70]
000074b6341d08ab  vmovaps xmm8, [rsp+0x80]
000074b6341d08b4  vmovaps xmm9, [rsp+0x90]
000074b6341d08bd  vmovaps xmm10, [rsp+0xA0]
000074b6341d08c6  vmovaps xmm11, [rsp+0xB0]
000074b6341d08cf  vmovaps xmm12, [rsp+0xC0]
000074b6341d08d8  vmovaps xmm14, [rsp+0xD0]
000074b6341d08e1  vmovaps xmm15, [rsp+0xE0]
000074b6341d08ea  add rsp, 0xF0
000074b6341d08f1  pop r11
000074b6341d08f3  pop r10
000074b6341d08f5  pop r9
000074b6341d08f7  pop r8
000074b6341d08f9  pop rsi
000074b6341d08fa  pop rdi
000074b6341d08fb  pop rdx
000074b6341d08fc  pop rcx
000074b6341d08fd  pop rax
000074b6341d08fe  add rsp, 0x08
000074b6341d0902  jmp 0x000074B6341CF5CF
000074b6341d0907  sub rsp, 0x08
000074b6341d090b  push rax
000074b6341d090c  push rcx
000074b6341d090d  push rdx
000074b6341d090e  push rdi
000074b6341d090f  push rsi
000074b6341d0910  push r8
000074b6341d0912  push r9
000074b6341d0914  push r10
000074b6341d0916  push r11
000074b6341d0918  sub rsp, 0xF0
000074b6341d091f  vmovaps [rsp], xmm0
000074b6341d0924  vmovaps [rsp+0x10], xmm1
000074b6341d092a  vmovaps [rsp+0x20], xmm2
000074b6341d0930  vmovaps [rsp+0x30], xmm3
000074b6341d0936  vmovaps [rsp+0x40], xmm4
000074b6341d093c  vmovaps [rsp+0x50], xmm5
000074b6341d0942  vmovaps [rsp+0x60], xmm6
000074b6341d0948  vmovaps [rsp+0x70], xmm7
000074b6341d094e  vmovaps [rsp+0x80], xmm8
000074b6341d0957  vmovaps [rsp+0x90], xmm9
000074b6341d0960  vmovaps [rsp+0xA0], xmm10
000074b6341d0969  vmovaps [rsp+0xB0], xmm11
000074b6341d0972  vmovaps [rsp+0xC0], xmm12
000074b6341d097b  vmovaps [rsp+0xD0], xmm13
000074b6341d0984  vmovaps [rsp+0xE0], xmm14
000074b6341d098d  sub rsp, 0x30
000074b6341d0991  movaps [rsp], xmm15
000074b6341d0996  movaps [rsp+0x10], xmm14
000074b6341d099c  movaps [rsp+0x20], xmm1
000074b6341d09a1  lea rdi, [rsp]
000074b6341d09a5  mov esi, 0x00
000074b6341d09aa  mov rax, 0x5E1AA0A2F530
000074b6341d09b4  call rax
000074b6341d09b6  movaps xmm15, [rsp]
000074b6341d09bb  add rsp, 0x30
000074b6341d09bf  vmovaps xmm0, [rsp]
000074b6341d09c4  vmovaps xmm1, [rsp+0x10]
000074b6341d09ca  vmovaps xmm2, [rsp+0x20]
000074b6341d09d0  vmovaps xmm3, [rsp+0x30]
000074b6341d09d6  vmovaps xmm4, [rsp+0x40]
000074b6341d09dc  vmovaps xmm5, [rsp+0x50]
000074b6341d09e2  vmovaps xmm6, [rsp+0x60]
000074b6341d09e8  vmovaps xmm7, [rsp+0x70]
000074b6341d09ee  vmovaps xmm8, [rsp+0x80]
000074b6341d09f7  vmovaps xmm9, [rsp+0x90]
000074b6341d0a00  vmovaps xmm10, [rsp+0xA0]
000074b6341d0a09  vmovaps xmm11, [rsp+0xB0]
000074b6341d0a12  vmovaps xmm12, [rsp+0xC0]
000074b6341d0a1b  vmovaps xmm13, [rsp+0xD0]
000074b6341d0a24  vmovaps xmm14, [rsp+0xE0]
000074b6341d0a2d  add rsp, 0xF0
000074b6341d0a34  pop r11
000074b6341d0a36  pop r10
000074b6341d0a38  pop r9
000074b6341d0a3a  pop r8
000074b6341d0a3c  pop rsi
000074b6341d0a3d  pop rdi
000074b6341d0a3e  pop rdx
000074b6341d0a3f  pop rcx
000074b6341d0a40  pop rax
000074b6341d0a41  add rsp, 0x08
000074b6341d0a45  jmp 0x000074B6341CF617
000074b6341d0a4a  sub rsp, 0x08
000074b6341d0a4e  push rax
000074b6341d0a4f  push rcx
000074b6341d0a50  push rdx
000074b6341d0a51  push rdi
000074b6341d0a52  push rsi
000074b6341d0a53  push r8
000074b6341d0a55  push r9
000074b6341d0a57  push r10
000074b6341d0a59  push r11
000074b6341d0a5b  sub rsp, 0xF0
000074b6341d0a62  vmovaps [rsp], xmm0
000074b6341d0a67  vmovaps [rsp+0x10], xmm2
000074b6341d0a6d  vmovaps [rsp+0x20], xmm3
000074b6341d0a73  vmovaps [rsp+0x30], xmm4
000074b6341d0a79  vmovaps [rsp+0x40], xmm5
000074b6341d0a7f  vmovaps [rsp+0x50], xmm6
000074b6341d0a85  vmovaps [rsp+0x60], xmm7
000074b6341d0a8b  vmovaps [rsp+0x70], xmm8
000074b6341d0a91  vmovaps [rsp+0x80], xmm9
000074b6341d0a9a  vmovaps [rsp+0x90], xmm10
000074b6341d0aa3  vmovaps [rsp+0xA0], xmm11
000074b6341d0aac  vmovaps [rsp+0xB0], xmm12
000074b6341d0ab5  vmovaps [rsp+0xC0], xmm13
000074b6341d0abe  vmovaps [rsp+0xD0], xmm14
000074b6341d0ac7  vmovaps [rsp+0xE0], xmm15
000074b6341d0ad0  sub rsp, 0x30
000074b6341d0ad4  movaps [rsp], xmm1
000074b6341d0ad8  movaps [rsp+0x10], xmm14
000074b6341d0ade  movaps [rsp+0x20], xmm10
000074b6341d0ae4  lea rdi, [rsp]
000074b6341d0ae8  mov esi, 0x00
000074b6341d0aed  mov rax, 0x5E1AA0A2F530
000074b6341d0af7  call rax
000074b6341d0af9  movaps xmm1, [rsp]
000074b6341d0afd  add rsp, 0x30
000074b6341d0b01  vmovaps xmm0, [rsp]
000074b6341d0b06  vmovaps xmm2, [rsp+0x10]
000074b6341d0b0c  vmovaps xmm3, [rsp+0x20]
000074b6341d0b12  vmovaps xmm4, [rsp+0x30]
000074b6341d0b18  vmovaps xmm5, [rsp+0x40]
000074b6341d0b1e  vmovaps xmm6, [rsp+0x50]
000074b6341d0b24  vmovaps xmm7, [rsp+0x60]
000074b6341d0b2a  vmovaps xmm8, [rsp+0x70]
000074b6341d0b30  vmovaps xmm9, [rsp+0x80]
000074b6341d0b39  vmovaps xmm10, [rsp+0x90]
000074b6341d0b42  vmovaps xmm11, [rsp+0xA0]
000074b6341d0b4b  vmovaps xmm12, [rsp+0xB0]
000074b6341d0b54  vmovaps xmm13, [rsp+0xC0]
000074b6341d0b5d  vmovaps xmm14, [rsp+0xD0]
000074b6341d0b66  vmovaps xmm15, [rsp+0xE0]
000074b6341d0b6f  add rsp, 0xF0
000074b6341d0b76  pop r11
000074b6341d0b78  pop r10
000074b6341d0b7a  pop r9
000074b6341d0b7c  pop r8
000074b6341d0b7e  pop rsi
000074b6341d0b7f  pop rdi
000074b6341d0b80  pop rdx
000074b6341d0b81  pop rcx
000074b6341d0b82  pop rax
000074b6341d0b83  add rsp, 0x08
000074b6341d0b87  jmp 0x000074B6341CF631
000074b6341d0b8c  sub rsp, 0x08
000074b6341d0b90  push rax
000074b6341d0b91  push rcx
000074b6341d0b92  push rdx
000074b6341d0b93  push rdi
000074b6341d0b94  push rsi
000074b6341d0b95  push r8
000074b6341d0b97  push r9
000074b6341d0b99  push r10
000074b6341d0b9b  push r11
000074b6341d0b9d  sub rsp, 0xF0
000074b6341d0ba4  vmovaps [rsp], xmm0
000074b6341d0ba9  vmovaps [rsp+0x10], xmm1
000074b6341d0baf  vmovaps [rsp+0x20], xmm2
000074b6341d0bb5  vmovaps [rsp+0x30], xmm3
000074b6341d0bbb  vmovaps [rsp+0x40], xmm4
000074b6341d0bc1  vmovaps [rsp+0x50], xmm5
000074b6341d0bc7  vmovaps [rsp+0x60], xmm6
000074b6341d0bcd  vmovaps [rsp+0x70], xmm7
000074b6341d0bd3  vmovaps [rsp+0x80], xmm8
000074b6341d0bdc  vmovaps [rsp+0x90], xmm9
000074b6341d0be5  vmovaps [rsp+0xA0], xmm10
000074b6341d0bee  vmovaps [rsp+0xB0], xmm11
000074b6341d0bf7  vmovaps [rsp+0xC0], xmm12
000074b6341d0c00  vmovaps [rsp+0xD0], xmm14
000074b6341d0c09  vmovaps [rsp+0xE0], xmm15
000074b6341d0c12  sub rsp, 0x30
000074b6341d0c16  movaps [rsp], xmm13
000074b6341d0c1b  movaps [rsp+0x10], xmm14
000074b6341d0c21  movaps [rsp+0x20], xmm2
000074b6341d0c26  lea rdi, [rsp]
000074b6341d0c2a  mov esi, 0x00
000074b6341d0c2f  mov rax, 0x5E1AA0A2F530
000074b6341d0c39  call rax
000074b6341d0c3b  movaps xmm13, [rsp]
000074b6341d0c40  add rsp, 0x30
000074b6341d0c44  vmovaps xmm0, [rsp]
000074b6341d0c49  vmovaps xmm1, [rsp+0x10]
000074b6341d0c4f  vmovaps xmm2, [rsp+0x20]
000074b6341d0c55  vmovaps xmm3, [rsp+0x30]
000074b6341d0c5b  vmovaps xmm4, [rsp+0x40]
000074b6341d0c61  vmovaps xmm5, [rsp+0x50]
000074b6341d0c67  vmovaps xmm6, [rsp+0x60]
000074b6341d0c6d  vmovaps xmm7, [rsp+0x70]
000074b6341d0c73  vmovaps xmm8, [rsp+0x80]
000074b6341d0c7c  vmovaps xmm9, [rsp+0x90]
000074b6341d0c85  vmovaps xmm10, [rsp+0xA0]
000074b6341d0c8e  vmovaps xmm11, [rsp+0xB0]
000074b6341d0c97  vmovaps xmm12, [rsp+0xC0]
000074b6341d0ca0  vmovaps xmm14, [rsp+0xD0]
000074b6341d0ca9  vmovaps xmm15, [rsp+0xE0]
000074b6341d0cb2  add rsp, 0xF0
000074b6341d0cb9  pop r11
000074b6341d0cbb  pop r10
000074b6341d0cbd  pop r9
000074b6341d0cbf  pop r8
000074b6341d0cc1  pop rsi
000074b6341d0cc2  pop rdi
000074b6341d0cc3  pop rdx
000074b6341d0cc4  pop rcx
000074b6341d0cc5  pop rax
000074b6341d0cc6  add rsp, 0x08
000074b6341d0cca  jmp 0x000074B6341CF64C
000074b6341d0ccf  sub rsp, 0x08
000074b6341d0cd3  push rax
000074b6341d0cd4  push rcx
000074b6341d0cd5  push rdx
000074b6341d0cd6  push rdi
000074b6341d0cd7  push rsi
000074b6341d0cd8  push r8
000074b6341d0cda  push r9
000074b6341d0cdc  push r10
000074b6341d0cde  push r11
000074b6341d0ce0  sub rsp, 0xF0
000074b6341d0ce7  vmovaps [rsp], xmm0
000074b6341d0cec  vmovaps [rsp+0x10], xmm2
000074b6341d0cf2  vmovaps [rsp+0x20], xmm3
000074b6341d0cf8  vmovaps [rsp+0x30], xmm4
000074b6341d0cfe  vmovaps [rsp+0x40], xmm5
000074b6341d0d04  vmovaps [rsp+0x50], xmm6
000074b6341d0d0a  vmovaps [rsp+0x60], xmm7
000074b6341d0d10  vmovaps [rsp+0x70], xmm8
000074b6341d0d16  vmovaps [rsp+0x80], xmm9
000074b6341d0d1f  vmovaps [rsp+0x90], xmm10
000074b6341d0d28  vmovaps [rsp+0xA0], xmm11
000074b6341d0d31  vmovaps [rsp+0xB0], xmm12
000074b6341d0d3a  vmovaps [rsp+0xC0], xmm13
000074b6341d0d43  vmovaps [rsp+0xD0], xmm14
000074b6341d0d4c  vmovaps [rsp+0xE0], xmm15
000074b6341d0d55  sub rsp, 0x30
000074b6341d0d59  movaps [rsp], xmm1
000074b6341d0d5d  movaps [rsp+0x10], xmm10
000074b6341d0d63  movaps [rsp+0x20], xmm2
000074b6341d0d68  lea rdi, [rsp]
000074b6341d0d6c  mov esi, 0x00
000074b6341d0d71  mov rax, 0x5E1AA0A2F530
000074b6341d0d7b  call rax
000074b6341d0d7d  movaps xmm1, [rsp]
000074b6341d0d81  add rsp, 0x30
000074b6341d0d85  vmovaps xmm0, [rsp]
000074b6341d0d8a  vmovaps xmm2, [rsp+0x10]
000074b6341d0d90  vmovaps xmm3, [rsp+0x20]
000074b6341d0d96  vmovaps xmm4, [rsp+0x30]
000074b6341d0d9c  vmovaps xmm5, [rsp+0x40]
000074b6341d0da2  vmovaps xmm6, [rsp+0x50]
000074b6341d0da8  vmovaps xmm7, [rsp+0x60]
000074b6341d0dae  vmovaps xmm8, [rsp+0x70]
000074b6341d0db4  vmovaps xmm9, [rsp+0x80]
000074b6341d0dbd  vmovaps xmm10, [rsp+0x90]
000074b6341d0dc6  vmovaps xmm11, [rsp+0xA0]
000074b6341d0dcf  vmovaps xmm12, [rsp+0xB0]
000074b6341d0dd8  vmovaps xmm13, [rsp+0xC0]
000074b6341d0de1  vmovaps xmm14, [rsp+0xD0]
000074b6341d0dea  vmovaps xmm15, [rsp+0xE0]
000074b6341d0df3  add rsp, 0xF0
000074b6341d0dfa  pop r11
000074b6341d0dfc  pop r10
000074b6341d0dfe  pop r9
000074b6341d0e00  pop r8
000074b6341d0e02  pop rsi
000074b6341d0e03  pop rdi
000074b6341d0e04  pop rdx
000074b6341d0e05  pop rcx
000074b6341d0e06  pop rax
000074b6341d0e07  add rsp, 0x08
000074b6341d0e0b  jmp 0x000074B6341CF6B4
000074b6341d0e10  sub rsp, 0x08
000074b6341d0e14  push rax
000074b6341d0e15  push rcx
000074b6341d0e16  push rdx
000074b6341d0e17  push rdi
000074b6341d0e18  push rsi
000074b6341d0e19  push r8
000074b6341d0e1b  push r9
000074b6341d0e1d  push r10
000074b6341d0e1f  push r11
000074b6341d0e21  sub rsp, 0xF0
000074b6341d0e28  vmovaps [rsp], xmm0
000074b6341d0e2d  vmovaps [rsp+0x10], xmm1
000074b6341d0e33  vmovaps [rsp+0x20], xmm2
000074b6341d0e39  vmovaps [rsp+0x30], xmm3
000074b6341d0e3f  vmovaps [rsp+0x40], xmm4
000074b6341d0e45  vmovaps [rsp+0x50], xmm5
000074b6341d0e4b  vmovaps [rsp+0x60], xmm6
000074b6341d0e51  vmovaps [rsp+0x70], xmm7
000074b6341d0e57  vmovaps [rsp+0x80], xmm8
000074b6341d0e60  vmovaps [rsp+0x90], xmm9
000074b6341d0e69  vmovaps [rsp+0xA0], xmm10
000074b6341d0e72  vmovaps [rsp+0xB0], xmm11
000074b6341d0e7b  vmovaps [rsp+0xC0], xmm12
000074b6341d0e84  vmovaps [rsp+0xD0], xmm13
000074b6341d0e8d  vmovaps [rsp+0xE0], xmm14
000074b6341d0e96  sub rsp, 0x30
000074b6341d0e9a  movaps [rsp], xmm15
000074b6341d0e9f  movaps [rsp+0x10], xmm10
000074b6341d0ea5  movaps [rsp+0x20], xmm2
000074b6341d0eaa  lea rdi, [rsp]
000074b6341d0eae  mov esi, 0x00
000074b6341d0eb3  mov rax, 0x5E1AA0A2F530
000074b6341d0ebd  call rax
000074b6341d0ebf  movaps xmm15, [rsp]
000074b6341d0ec4  add rsp, 0x30
000074b6341d0ec8  vmovaps xmm0, [rsp]
000074b6341d0ecd  vmovaps xmm1, [rsp+0x10]
000074b6341d0ed3  vmovaps xmm2, [rsp+0x20]
000074b6341d0ed9  vmovaps xmm3, [rsp+0x30]
000074b6341d0edf  vmovaps xmm4, [rsp+0x40]
000074b6341d0ee5  vmovaps xmm5, [rsp+0x50]
000074b6341d0eeb  vmovaps xmm6, [rsp+0x60]
000074b6341d0ef1  vmovaps xmm7, [rsp+0x70]
000074b6341d0ef7  vmovaps xmm8, [rsp+0x80]
000074b6341d0f00  vmovaps xmm9, [rsp+0x90]
000074b6341d0f09  vmovaps xmm10, [rsp+0xA0]
000074b6341d0f12  vmovaps xmm11, [rsp+0xB0]
000074b6341d0f1b  vmovaps xmm12, [rsp+0xC0]
000074b6341d0f24  vmovaps xmm13, [rsp+0xD0]
000074b6341d0f2d  vmovaps xmm14, [rsp+0xE0]
000074b6341d0f36  add rsp, 0xF0
000074b6341d0f3d  pop r11
000074b6341d0f3f  pop r10
000074b6341d0f41  pop r9
000074b6341d0f43  pop r8
000074b6341d0f45  pop rsi
000074b6341d0f46  pop rdi
000074b6341d0f47  pop rdx
000074b6341d0f48  pop rcx
000074b6341d0f49  pop rax
000074b6341d0f4a  add rsp, 0x08
000074b6341d0f4e  jmp 0x000074B6341CF706
000074b6341d0f53  sub rsp, 0x08
000074b6341d0f57  push rax
000074b6341d0f58  push rcx
000074b6341d0f59  push rdx
000074b6341d0f5a  push rdi
000074b6341d0f5b  push rsi
000074b6341d0f5c  push r8
000074b6341d0f5e  push r9
000074b6341d0f60  push r10
000074b6341d0f62  push r11
000074b6341d0f64  sub rsp, 0xF0
000074b6341d0f6b  vmovaps [rsp], xmm0
000074b6341d0f70  vmovaps [rsp+0x10], xmm2
000074b6341d0f76  vmovaps [rsp+0x20], xmm3
000074b6341d0f7c  vmovaps [rsp+0x30], xmm4
000074b6341d0f82  vmovaps [rsp+0x40], xmm5
000074b6341d0f88  vmovaps [rsp+0x50], xmm6
000074b6341d0f8e  vmovaps [rsp+0x60], xmm7
000074b6341d0f94  vmovaps [rsp+0x70], xmm8
000074b6341d0f9a  vmovaps [rsp+0x80], xmm9
000074b6341d0fa3  vmovaps [rsp+0x90], xmm10
000074b6341d0fac  vmovaps [rsp+0xA0], xmm11
000074b6341d0fb5  vmovaps [rsp+0xB0], xmm12
000074b6341d0fbe  vmovaps [rsp+0xC0], xmm13
000074b6341d0fc7  vmovaps [rsp+0xD0], xmm14
000074b6341d0fd0  vmovaps [rsp+0xE0], xmm15
000074b6341d0fd9  sub rsp, 0x30
000074b6341d0fdd  movaps [rsp], xmm1
000074b6341d0fe1  movaps [rsp+0x10], xmm10
000074b6341d0fe7  movaps [rsp+0x20], xmm12
000074b6341d0fed  lea rdi, [rsp]
000074b6341d0ff1  mov esi, 0x00
000074b6341d0ff6  mov rax, 0x5E1AA0A2F530
000074b6341d1000  call rax
000074b6341d1002  movaps xmm1, [rsp]
000074b6341d1006  add rsp, 0x30
000074b6341d100a  vmovaps xmm0, [rsp]
000074b6341d100f  vmovaps xmm2, [rsp+0x10]
000074b6341d1015  vmovaps xmm3, [rsp+0x20]
000074b6341d101b  vmovaps xmm4, [rsp+0x30]
000074b6341d1021  vmovaps xmm5, [rsp+0x40]
000074b6341d1027  vmovaps xmm6, [rsp+0x50]
000074b6341d102d  vmovaps xmm7, [rsp+0x60]
000074b6341d1033  vmovaps xmm8, [rsp+0x70]
000074b6341d1039  vmovaps xmm9, [rsp+0x80]
000074b6341d1042  vmovaps xmm10, [rsp+0x90]
000074b6341d104b  vmovaps xmm11, [rsp+0xA0]
000074b6341d1054  vmovaps xmm12, [rsp+0xB0]
000074b6341d105d  vmovaps xmm13, [rsp+0xC0]
000074b6341d1066  vmovaps xmm14, [rsp+0xD0]
000074b6341d106f  vmovaps xmm15, [rsp+0xE0]
000074b6341d1078  add rsp, 0xF0
000074b6341d107f  pop r11
000074b6341d1081  pop r10
000074b6341d1083  pop r9
000074b6341d1085  pop r8
000074b6341d1087  pop rsi
000074b6341d1088  pop rdi
000074b6341d1089  pop rdx
000074b6341d108a  pop rcx
000074b6341d108b  pop rax
000074b6341d108c  add rsp, 0x08
000074b6341d1090  jmp 0x000074B6341CF732
000074b6341d1095  sub rsp, 0x08
000074b6341d1099  push rax
000074b6341d109a  push rcx
000074b6341d109b  push rdx
000074b6341d109c  push rdi
000074b6341d109d  push rsi
000074b6341d109e  push r8
000074b6341d10a0  push r9
000074b6341d10a2  push r10
000074b6341d10a4  push r11
000074b6341d10a6  sub rsp, 0xF0
000074b6341d10ad  vmovaps [rsp], xmm0
000074b6341d10b2  vmovaps [rsp+0x10], xmm1
000074b6341d10b8  vmovaps [rsp+0x20], xmm2
000074b6341d10be  vmovaps [rsp+0x30], xmm3
000074b6341d10c4  vmovaps [rsp+0x40], xmm4
000074b6341d10ca  vmovaps [rsp+0x50], xmm5
000074b6341d10d0  vmovaps [rsp+0x60], xmm6
000074b6341d10d6  vmovaps [rsp+0x70], xmm7
000074b6341d10dc  vmovaps [rsp+0x80], xmm8
000074b6341d10e5  vmovaps [rsp+0x90], xmm9
000074b6341d10ee  vmovaps [rsp+0xA0], xmm10
000074b6341d10f7  vmovaps [rsp+0xB0], xmm11
000074b6341d1100  vmovaps [rsp+0xC0], xmm12
000074b6341d1109  vmovaps [rsp+0xD0], xmm13
000074b6341d1112  vmovaps [rsp+0xE0], xmm14
000074b6341d111b  sub rsp, 0x30
000074b6341d111f  movaps [rsp], xmm15
000074b6341d1124  movaps [rsp+0x10], xmm10
000074b6341d112a  movaps [rsp+0x20], xmm12
000074b6341d1130  lea rdi, [rsp]
000074b6341d1134  mov esi, 0x00
000074b6341d1139  mov rax, 0x5E1AA0A2F530
000074b6341d1143  call rax
000074b6341d1145  movaps xmm15, [rsp]
000074b6341d114a  add rsp, 0x30
000074b6341d114e  vmovaps xmm0, [rsp]
000074b6341d1153  vmovaps xmm1, [rsp+0x10]
000074b6341d1159  vmovaps xmm2, [rsp+0x20]
000074b6341d115f  vmovaps xmm3, [rsp+0x30]
000074b6341d1165  vmovaps xmm4, [rsp+0x40]
000074b6341d116b  vmovaps xmm5, [rsp+0x50]
000074b6341d1171  vmovaps xmm6, [rsp+0x60]
000074b6341d1177  vmovaps xmm7, [rsp+0x70]
000074b6341d117d  vmovaps xmm8, [rsp+0x80]
000074b6341d1186  vmovaps xmm9, [rsp+0x90]
000074b6341d118f  vmovaps xmm10, [rsp+0xA0]
000074b6341d1198  vmovaps xmm11, [rsp+0xB0]
000074b6341d11a1  vmovaps xmm12, [rsp+0xC0]
000074b6341d11aa  vmovaps xmm13, [rsp+0xD0]
000074b6341d11b3  vmovaps xmm14, [rsp+0xE0]
000074b6341d11bc  add rsp, 0xF0
000074b6341d11c3  pop r11
000074b6341d11c5  pop r10
000074b6341d11c7  pop r9
000074b6341d11c9  pop r8
000074b6341d11cb  pop rsi
000074b6341d11cc  pop rdi
000074b6341d11cd  pop rdx
000074b6341d11ce  pop rcx
000074b6341d11cf  pop rax
000074b6341d11d0  add rsp, 0x08
000074b6341d11d4  jmp 0x000074B6341CF75E
000074b6341d11d9  call 0x000074B633FFF430
000074b6341d11de  jmp 0x000074B6341CF7EE
000074b6341d11e3  call 0x000074B633FFF430
000074b6341d11e8  jmp 0x000074B6341CF801
000074b6341d11ed  sub rsp, 0x08
000074b6341d11f1  push rax
000074b6341d11f2  push rcx
000074b6341d11f3  push rdx
000074b6341d11f4  push rdi
000074b6341d11f5  push rsi
000074b6341d11f6  push r8
000074b6341d11f8  push r9
000074b6341d11fa  push r10
000074b6341d11fc  push r11
000074b6341d11fe  sub rsp, 0xF0
000074b6341d1205  vmovaps [rsp], xmm0
000074b6341d120a  vmovaps [rsp+0x10], xmm2
000074b6341d1210  vmovaps [rsp+0x20], xmm3
000074b6341d1216  vmovaps [rsp+0x30], xmm4
000074b6341d121c  vmovaps [rsp+0x40], xmm5
000074b6341d1222  vmovaps [rsp+0x50], xmm6
000074b6341d1228  vmovaps [rsp+0x60], xmm7
000074b6341d122e  vmovaps [rsp+0x70], xmm8
000074b6341d1234  vmovaps [rsp+0x80], xmm9
000074b6341d123d  vmovaps [rsp+0x90], xmm10
000074b6341d1246  vmovaps [rsp+0xA0], xmm11
000074b6341d124f  vmovaps [rsp+0xB0], xmm12
000074b6341d1258  vmovaps [rsp+0xC0], xmm13
000074b6341d1261  vmovaps [rsp+0xD0], xmm14
000074b6341d126a  vmovaps [rsp+0xE0], xmm15
000074b6341d1273  sub rsp, 0x30
000074b6341d1277  movaps [rsp], xmm1
000074b6341d127b  movaps [rsp+0x10], xmm13
000074b6341d1281  movaps [rsp+0x20], xmm2
000074b6341d1286  lea rdi, [rsp]
000074b6341d128a  mov esi, 0x00
000074b6341d128f  mov rax, 0x5E1AA0A2F530
000074b6341d1299  call rax
000074b6341d129b  movaps xmm1, [rsp]
000074b6341d129f  add rsp, 0x30
000074b6341d12a3  vmovaps xmm0, [rsp]
000074b6341d12a8  vmovaps xmm2, [rsp+0x10]
000074b6341d12ae  vmovaps xmm3, [rsp+0x20]
000074b6341d12b4  vmovaps xmm4, [rsp+0x30]
000074b6341d12ba  vmovaps xmm5, [rsp+0x40]
000074b6341d12c0  vmovaps xmm6, [rsp+0x50]
000074b6341d12c6  vmovaps xmm7, [rsp+0x60]
000074b6341d12cc  vmovaps xmm8, [rsp+0x70]
000074b6341d12d2  vmovaps xmm9, [rsp+0x80]
000074b6341d12db  vmovaps xmm10, [rsp+0x90]
000074b6341d12e4  vmovaps xmm11, [rsp+0xA0]
000074b6341d12ed  vmovaps xmm12, [rsp+0xB0]
000074b6341d12f6  vmovaps xmm13, [rsp+0xC0]
000074b6341d12ff  vmovaps xmm14, [rsp+0xD0]
000074b6341d1308  vmovaps xmm15, [rsp+0xE0]
000074b6341d1311  add rsp, 0xF0
000074b6341d1318  pop r11
000074b6341d131a  pop r10
000074b6341d131c  pop r9
000074b6341d131e  pop r8
000074b6341d1320  pop rsi
000074b6341d1321  pop rdi
000074b6341d1322  pop rdx
000074b6341d1323  pop rcx
000074b6341d1324  pop rax
000074b6341d1325  add rsp, 0x08
000074b6341d1329  jmp 0x000074B6341CF82C
000074b6341d132e  call 0x000074B63400E760
000074b6341d1333  jmp 0x000074B6341CF839
000074b6341d1338  sub rsp, 0x08
000074b6341d133c  push rax
000074b6341d133d  push rcx
000074b6341d133e  push rdx
000074b6341d133f  push rdi
000074b6341d1340  push rsi
000074b6341d1341  push r8
000074b6341d1343  push r9
000074b6341d1345  push r10
000074b6341d1347  push r11
000074b6341d1349  sub rsp, 0xF0
000074b6341d1350  vmovaps [rsp], xmm0
000074b6341d1355  vmovaps [rsp+0x10], xmm1
000074b6341d135b  vmovaps [rsp+0x20], xmm2
000074b6341d1361  vmovaps [rsp+0x30], xmm3
000074b6341d1367  vmovaps [rsp+0x40], xmm4
000074b6341d136d  vmovaps [rsp+0x50], xmm5
000074b6341d1373  vmovaps [rsp+0x60], xmm6
000074b6341d1379  vmovaps [rsp+0x70], xmm7
000074b6341d137f  vmovaps [rsp+0x80], xmm8
000074b6341d1388  vmovaps [rsp+0x90], xmm9
000074b6341d1391  vmovaps [rsp+0xA0], xmm10
000074b6341d139a  vmovaps [rsp+0xB0], xmm11
000074b6341d13a3  vmovaps [rsp+0xC0], xmm12
000074b6341d13ac  vmovaps [rsp+0xD0], xmm14
000074b6341d13b5  vmovaps [rsp+0xE0], xmm15
000074b6341d13be  sub rsp, 0x30
000074b6341d13c2  movaps [rsp], xmm13
000074b6341d13c7  movaps [rsp+0x10], xmm2
000074b6341d13cc  movaps [rsp+0x20], xmm1
000074b6341d13d1  lea rdi, [rsp]
000074b6341d13d5  mov esi, 0x00
000074b6341d13da  mov rax, 0x5E1AA0A2F530
000074b6341d13e4  call rax
000074b6341d13e6  movaps xmm13, [rsp]
000074b6341d13eb  add rsp, 0x30
000074b6341d13ef  vmovaps xmm0, [rsp]
000074b6341d13f4  vmovaps xmm1, [rsp+0x10]
000074b6341d13fa  vmovaps xmm2, [rsp+0x20]
000074b6341d1400  vmovaps xmm3, [rsp+0x30]
000074b6341d1406  vmovaps xmm4, [rsp+0x40]
000074b6341d140c  vmovaps xmm5, [rsp+0x50]
000074b6341d1412  vmovaps xmm6, [rsp+0x60]
000074b6341d1418  vmovaps xmm7, [rsp+0x70]
000074b6341d141e  vmovaps xmm8, [rsp+0x80]
000074b6341d1427  vmovaps xmm9, [rsp+0x90]
000074b6341d1430  vmovaps xmm10, [rsp+0xA0]
000074b6341d1439  vmovaps xmm11, [rsp+0xB0]
000074b6341d1442  vmovaps xmm12, [rsp+0xC0]
000074b6341d144b  vmovaps xmm14, [rsp+0xD0]
000074b6341d1454  vmovaps xmm15, [rsp+0xE0]
000074b6341d145d  add rsp, 0xF0
000074b6341d1464  pop r11
000074b6341d1466  pop r10
000074b6341d1468  pop r9
000074b6341d146a  pop r8
000074b6341d146c  pop rsi
000074b6341d146d  pop rdi
000074b6341d146e  pop rdx
000074b6341d146f  pop rcx
000074b6341d1470  pop rax
000074b6341d1471  add rsp, 0x08
000074b6341d1475  jmp 0x000074B6341CF878
000074b6341d147a  sub rsp, 0x08
000074b6341d147e  push rax
000074b6341d147f  push rcx
000074b6341d1480  push rdx
000074b6341d1481  push rdi
000074b6341d1482  push rsi
000074b6341d1483  push r8
000074b6341d1485  push r9
000074b6341d1487  push r10
000074b6341d1489  push r11
000074b6341d148b  sub rsp, 0xF0
000074b6341d1492  vmovaps [rsp], xmm0
000074b6341d1497  vmovaps [rsp+0x10], xmm2
000074b6341d149d  vmovaps [rsp+0x20], xmm3
000074b6341d14a3  vmovaps [rsp+0x30], xmm4
000074b6341d14a9  vmovaps [rsp+0x40], xmm5
000074b6341d14af  vmovaps [rsp+0x50], xmm6
000074b6341d14b5  vmovaps [rsp+0x60], xmm7
000074b6341d14bb  vmovaps [rsp+0x70], xmm8
000074b6341d14c1  vmovaps [rsp+0x80], xmm9
000074b6341d14ca  vmovaps [rsp+0x90], xmm10
000074b6341d14d3  vmovaps [rsp+0xA0], xmm11
000074b6341d14dc  vmovaps [rsp+0xB0], xmm12
000074b6341d14e5  vmovaps [rsp+0xC0], xmm13
000074b6341d14ee  vmovaps [rsp+0xD0], xmm14
000074b6341d14f7  vmovaps [rsp+0xE0], xmm15
000074b6341d1500  sub rsp, 0x30
000074b6341d1504  movaps [rsp], xmm1
000074b6341d1508  movaps [rsp+0x10], xmm15
000074b6341d150e  movaps [rsp+0x20], xmm2
000074b6341d1513  lea rdi, [rsp]
000074b6341d1517  mov esi, 0x00
000074b6341d151c  mov rax, 0x5E1AA0A2F530
000074b6341d1526  call rax
000074b6341d1528  movaps xmm1, [rsp]
000074b6341d152c  add rsp, 0x30
000074b6341d1530  vmovaps xmm0, [rsp]
000074b6341d1535  vmovaps xmm2, [rsp+0x10]
000074b6341d153b  vmovaps xmm3, [rsp+0x20]
000074b6341d1541  vmovaps xmm4, [rsp+0x30]
000074b6341d1547  vmovaps xmm5, [rsp+0x40]
000074b6341d154d  vmovaps xmm6, [rsp+0x50]
000074b6341d1553  vmovaps xmm7, [rsp+0x60]
000074b6341d1559  vmovaps xmm8, [rsp+0x70]
000074b6341d155f  vmovaps xmm9, [rsp+0x80]
000074b6341d1568  vmovaps xmm10, [rsp+0x90]
000074b6341d1571  vmovaps xmm11, [rsp+0xA0]
000074b6341d157a  vmovaps xmm12, [rsp+0xB0]
000074b6341d1583  vmovaps xmm13, [rsp+0xC0]
000074b6341d158c  vmovaps xmm14, [rsp+0xD0]
000074b6341d1595  vmovaps xmm15, [rsp+0xE0]
000074b6341d159e  add rsp, 0xF0
000074b6341d15a5  pop r11
000074b6341d15a7  pop r10
000074b6341d15a9  pop r9
000074b6341d15ab  pop r8
000074b6341d15ad  pop rsi
000074b6341d15ae  pop rdi
000074b6341d15af  pop rdx
000074b6341d15b0  pop rcx
000074b6341d15b1  pop rax
000074b6341d15b2  add rsp, 0x08
000074b6341d15b6  jmp 0x000074B6341CF8AC
000074b6341d15bb  sub rsp, 0x08
000074b6341d15bf  push rax
000074b6341d15c0  push rcx
000074b6341d15c1  push rdx
000074b6341d15c2  push rdi
000074b6341d15c3  push rsi
000074b6341d15c4  push r8
000074b6341d15c6  push r9
000074b6341d15c8  push r10
000074b6341d15ca  push r11
000074b6341d15cc  sub rsp, 0xF0
000074b6341d15d3  vmovaps [rsp], xmm0
000074b6341d15d8  vmovaps [rsp+0x10], xmm1
000074b6341d15de  vmovaps [rsp+0x20], xmm2
000074b6341d15e4  vmovaps [rsp+0x30], xmm3
000074b6341d15ea  vmovaps [rsp+0x40], xmm4
000074b6341d15f0  vmovaps [rsp+0x50], xmm5
000074b6341d15f6  vmovaps [rsp+0x60], xmm6
000074b6341d15fc  vmovaps [rsp+0x70], xmm7
000074b6341d1602  vmovaps [rsp+0x80], xmm8
000074b6341d160b  vmovaps [rsp+0x90], xmm9
000074b6341d1614  vmovaps [rsp+0xA0], xmm10
000074b6341d161d  vmovaps [rsp+0xB0], xmm11
000074b6341d1626  vmovaps [rsp+0xC0], xmm12
000074b6341d162f  vmovaps [rsp+0xD0], xmm13
000074b6341d1638  vmovaps [rsp+0xE0], xmm15
000074b6341d1641  sub rsp, 0x30
000074b6341d1645  movaps [rsp], xmm14
000074b6341d164a  movaps [rsp+0x10], xmm2
000074b6341d164f  movaps [rsp+0x20], xmm15
000074b6341d1655  lea rdi, [rsp]
000074b6341d1659  mov esi, 0x00
000074b6341d165e  mov rax, 0x5E1AA0A2F530
000074b6341d1668  call rax
000074b6341d166a  movaps xmm14, [rsp]
000074b6341d166f  add rsp, 0x30
000074b6341d1673  vmovaps xmm0, [rsp]
000074b6341d1678  vmovaps xmm1, [rsp+0x10]
000074b6341d167e  vmovaps xmm2, [rsp+0x20]
000074b6341d1684  vmovaps xmm3, [rsp+0x30]
000074b6341d168a  vmovaps xmm4, [rsp+0x40]
000074b6341d1690  vmovaps xmm5, [rsp+0x50]
000074b6341d1696  vmovaps xmm6, [rsp+0x60]
000074b6341d169c  vmovaps xmm7, [rsp+0x70]
000074b6341d16a2  vmovaps xmm8, [rsp+0x80]
000074b6341d16ab  vmovaps xmm9, [rsp+0x90]
000074b6341d16b4  vmovaps xmm10, [rsp+0xA0]
000074b6341d16bd  vmovaps xmm11, [rsp+0xB0]
000074b6341d16c6  vmovaps xmm12, [rsp+0xC0]
000074b6341d16cf  vmovaps xmm13, [rsp+0xD0]
000074b6341d16d8  vmovaps xmm15, [rsp+0xE0]
000074b6341d16e1  add rsp, 0xF0
000074b6341d16e8  pop r11
000074b6341d16ea  pop r10
000074b6341d16ec  pop r9
000074b6341d16ee  pop r8
000074b6341d16f0  pop rsi
000074b6341d16f1  pop rdi
000074b6341d16f2  pop rdx
000074b6341d16f3  pop rcx
000074b6341d16f4  pop rax
000074b6341d16f5  add rsp, 0x08
000074b6341d16f9  jmp 0x000074B6341CF8E7
000074b6341d16fe  sub rsp, 0x08
000074b6341d1702  push rax
000074b6341d1703  push rcx
000074b6341d1704  push rdx
000074b6341d1705  push rdi
000074b6341d1706  push rsi
000074b6341d1707  push r8
000074b6341d1709  push r9
000074b6341d170b  push r10
000074b6341d170d  push r11
000074b6341d170f  sub rsp, 0xF0
000074b6341d1716  vmovaps [rsp], xmm0
000074b6341d171b  vmovaps [rsp+0x10], xmm1
000074b6341d1721  vmovaps [rsp+0x20], xmm2
000074b6341d1727  vmovaps [rsp+0x30], xmm3
000074b6341d172d  vmovaps [rsp+0x40], xmm4
000074b6341d1733  vmovaps [rsp+0x50], xmm5
000074b6341d1739  vmovaps [rsp+0x60], xmm6
000074b6341d173f  vmovaps [rsp+0x70], xmm7
000074b6341d1745  vmovaps [rsp+0x80], xmm8
000074b6341d174e  vmovaps [rsp+0x90], xmm9
000074b6341d1757  vmovaps [rsp+0xA0], xmm10
000074b6341d1760  vmovaps [rsp+0xB0], xmm11
000074b6341d1769  vmovaps [rsp+0xC0], xmm12
000074b6341d1772  vmovaps [rsp+0xD0], xmm13
000074b6341d177b  vmovaps [rsp+0xE0], xmm14
000074b6341d1784  sub rsp, 0x30
000074b6341d1788  movaps [rsp], xmm15
000074b6341d178d  movaps [rsp+0x10], xmm2
000074b6341d1792  movaps [rsp+0x20], xmm1
000074b6341d1797  lea rdi, [rsp]
000074b6341d179b  mov esi, 0x00
000074b6341d17a0  mov rax, 0x5E1AA0A2F530
000074b6341d17aa  call rax
000074b6341d17ac  movaps xmm15, [rsp]
000074b6341d17b1  add rsp, 0x30
000074b6341d17b5  vmovaps xmm0, [rsp]
000074b6341d17ba  vmovaps xmm1, [rsp+0x10]
000074b6341d17c0  vmovaps xmm2, [rsp+0x20]
000074b6341d17c6  vmovaps xmm3, [rsp+0x30]
000074b6341d17cc  vmovaps xmm4, [rsp+0x40]
000074b6341d17d2  vmovaps xmm5, [rsp+0x50]
000074b6341d17d8  vmovaps xmm6, [rsp+0x60]
000074b6341d17de  vmovaps xmm7, [rsp+0x70]
000074b6341d17e4  vmovaps xmm8, [rsp+0x80]
000074b6341d17ed  vmovaps xmm9, [rsp+0x90]
000074b6341d17f6  vmovaps xmm10, [rsp+0xA0]
000074b6341d17ff  vmovaps xmm11, [rsp+0xB0]
000074b6341d1808  vmovaps xmm12, [rsp+0xC0]
000074b6341d1811  vmovaps xmm13, [rsp+0xD0]
000074b6341d181a  vmovaps xmm14, [rsp+0xE0]
000074b6341d1823  add rsp, 0xF0
000074b6341d182a  pop r11
000074b6341d182c  pop r10
000074b6341d182e  pop r9
000074b6341d1830  pop r8
000074b6341d1832  pop rsi
000074b6341d1833  pop rdi
000074b6341d1834  pop rdx
000074b6341d1835  pop rcx
000074b6341d1836  pop rax
000074b6341d1837  add rsp, 0x08
000074b6341d183b  jmp 0x000074B6341CF923
000074b6341d1840  call 0x000074B633FFF430
000074b6341d1845  jmp 0x000074B6341CF930
000074b6341d184a  sub rsp, 0x08
000074b6341d184e  push rax
000074b6341d184f  push rcx
000074b6341d1850  push rdx
000074b6341d1851  push rdi
000074b6341d1852  push rsi
000074b6341d1853  push r8
000074b6341d1855  push r9
000074b6341d1857  push r10
000074b6341d1859  push r11
000074b6341d185b  sub rsp, 0xF0
000074b6341d1862  vmovaps [rsp], xmm0
000074b6341d1867  vmovaps [rsp+0x10], xmm1
000074b6341d186d  vmovaps [rsp+0x20], xmm3
000074b6341d1873  vmovaps [rsp+0x30], xmm4
000074b6341d1879  vmovaps [rsp+0x40], xmm5
000074b6341d187f  vmovaps [rsp+0x50], xmm6
000074b6341d1885  vmovaps [rsp+0x60], xmm7
000074b6341d188b  vmovaps [rsp+0x70], xmm8
000074b6341d1891  vmovaps [rsp+0x80], xmm9
000074b6341d189a  vmovaps [rsp+0x90], xmm10
000074b6341d18a3  vmovaps [rsp+0xA0], xmm11
000074b6341d18ac  vmovaps [rsp+0xB0], xmm12
000074b6341d18b5  vmovaps [rsp+0xC0], xmm13
000074b6341d18be  vmovaps [rsp+0xD0], xmm14
000074b6341d18c7  vmovaps [rsp+0xE0], xmm15
000074b6341d18d0  sub rsp, 0x30
000074b6341d18d4  movaps [rsp], xmm2
000074b6341d18d8  movaps [rsp+0x10], xmm1
000074b6341d18dd  movaps [rsp+0x20], xmm14
000074b6341d18e3  lea rdi, [rsp]
000074b6341d18e7  mov esi, 0x00
000074b6341d18ec  mov rax, 0x5E1AA0A2F530
000074b6341d18f6  call rax
000074b6341d18f8  movaps xmm2, [rsp]
000074b6341d18fc  add rsp, 0x30
000074b6341d1900  vmovaps xmm0, [rsp]
000074b6341d1905  vmovaps xmm1, [rsp+0x10]
000074b6341d190b  vmovaps xmm3, [rsp+0x20]
000074b6341d1911  vmovaps xmm4, [rsp+0x30]
000074b6341d1917  vmovaps xmm5, [rsp+0x40]
000074b6341d191d  vmovaps xmm6, [rsp+0x50]
000074b6341d1923  vmovaps xmm7, [rsp+0x60]
000074b6341d1929  vmovaps xmm8, [rsp+0x70]
000074b6341d192f  vmovaps xmm9, [rsp+0x80]
000074b6341d1938  vmovaps xmm10, [rsp+0x90]
000074b6341d1941  vmovaps xmm11, [rsp+0xA0]
000074b6341d194a  vmovaps xmm12, [rsp+0xB0]
000074b6341d1953  vmovaps xmm13, [rsp+0xC0]
000074b6341d195c  vmovaps xmm14, [rsp+0xD0]
000074b6341d1965  vmovaps xmm15, [rsp+0xE0]
000074b6341d196e  add rsp, 0xF0
000074b6341d1975  pop r11
000074b6341d1977  pop r10
000074b6341d1979  pop r9
000074b6341d197b  pop r8
000074b6341d197d  pop rsi
000074b6341d197e  pop rdi
000074b6341d197f  pop rdx
000074b6341d1980  pop rcx
000074b6341d1981  pop rax
000074b6341d1982  add rsp, 0x08
000074b6341d1986  jmp 0x000074B6341CF96D
000074b6341d198b  sub rsp, 0x08
000074b6341d198f  push rax
000074b6341d1990  push rcx
000074b6341d1991  push rdx
000074b6341d1992  push rdi
000074b6341d1993  push rsi
000074b6341d1994  push r8
000074b6341d1996  push r9
000074b6341d1998  push r10
000074b6341d199a  push r11
000074b6341d199c  sub rsp, 0xF0
000074b6341d19a3  vmovaps [rsp], xmm0
000074b6341d19a8  vmovaps [rsp+0x10], xmm1
000074b6341d19ae  vmovaps [rsp+0x20], xmm2
000074b6341d19b4  vmovaps [rsp+0x30], xmm3
000074b6341d19ba  vmovaps [rsp+0x40], xmm4
000074b6341d19c0  vmovaps [rsp+0x50], xmm5
000074b6341d19c6  vmovaps [rsp+0x60], xmm6
000074b6341d19cc  vmovaps [rsp+0x70], xmm7
000074b6341d19d2  vmovaps [rsp+0x80], xmm8
000074b6341d19db  vmovaps [rsp+0x90], xmm9
000074b6341d19e4  vmovaps [rsp+0xA0], xmm10
000074b6341d19ed  vmovaps [rsp+0xB0], xmm11
000074b6341d19f6  vmovaps [rsp+0xC0], xmm12
000074b6341d19ff  vmovaps [rsp+0xD0], xmm13
000074b6341d1a08  vmovaps [rsp+0xE0], xmm14
000074b6341d1a11  sub rsp, 0x30
000074b6341d1a15  movaps [rsp], xmm15
000074b6341d1a1a  movaps [rsp+0x10], xmm14
000074b6341d1a20  movaps [rsp+0x20], xmm1
000074b6341d1a25  lea rdi, [rsp]
000074b6341d1a29  mov esi, 0x00
000074b6341d1a2e  mov rax, 0x5E1AA0A2F530
000074b6341d1a38  call rax
000074b6341d1a3a  movaps xmm15, [rsp]
000074b6341d1a3f  add rsp, 0x30
000074b6341d1a43  vmovaps xmm0, [rsp]
000074b6341d1a48  vmovaps xmm1, [rsp+0x10]
000074b6341d1a4e  vmovaps xmm2, [rsp+0x20]
000074b6341d1a54  vmovaps xmm3, [rsp+0x30]
000074b6341d1a5a  vmovaps xmm4, [rsp+0x40]
000074b6341d1a60  vmovaps xmm5, [rsp+0x50]
000074b6341d1a66  vmovaps xmm6, [rsp+0x60]
000074b6341d1a6c  vmovaps xmm7, [rsp+0x70]
000074b6341d1a72  vmovaps xmm8, [rsp+0x80]
000074b6341d1a7b  vmovaps xmm9, [rsp+0x90]
000074b6341d1a84  vmovaps xmm10, [rsp+0xA0]
000074b6341d1a8d  vmovaps xmm11, [rsp+0xB0]
000074b6341d1a96  vmovaps xmm12, [rsp+0xC0]
000074b6341d1a9f  vmovaps xmm13, [rsp+0xD0]
000074b6341d1aa8  vmovaps xmm14, [rsp+0xE0]
000074b6341d1ab1  add rsp, 0xF0
000074b6341d1ab8  pop r11
000074b6341d1aba  pop r10
000074b6341d1abc  pop r9
000074b6341d1abe  pop r8
000074b6341d1ac0  pop rsi
000074b6341d1ac1  pop rdi
000074b6341d1ac2  pop rdx
000074b6341d1ac3  pop rcx
000074b6341d1ac4  pop rax
000074b6341d1ac5  add rsp, 0x08
000074b6341d1ac9  jmp 0x000074B6341CF9E7
000074b6341d1ace  call 0x000074B633FFF430
000074b6341d1ad3  jmp 0x000074B6341CF9F4
000074b6341d1ad8  sub rsp, 0x08
000074b6341d1adc  push rax
000074b6341d1add  push rcx
000074b6341d1ade  push rdx
000074b6341d1adf  push rdi
000074b6341d1ae0  push rsi
000074b6341d1ae1  push r8
000074b6341d1ae3  push r9
000074b6341d1ae5  push r10
000074b6341d1ae7  push r11
000074b6341d1ae9  sub rsp, 0xF0
000074b6341d1af0  vmovaps [rsp], xmm0
000074b6341d1af5  vmovaps [rsp+0x10], xmm1
000074b6341d1afb  vmovaps [rsp+0x20], xmm2
000074b6341d1b01  vmovaps [rsp+0x30], xmm3
000074b6341d1b07  vmovaps [rsp+0x40], xmm4
000074b6341d1b0d  vmovaps [rsp+0x50], xmm5
000074b6341d1b13  vmovaps [rsp+0x60], xmm6
000074b6341d1b19  vmovaps [rsp+0x70], xmm7
000074b6341d1b1f  vmovaps [rsp+0x80], xmm8
000074b6341d1b28  vmovaps [rsp+0x90], xmm9
000074b6341d1b31  vmovaps [rsp+0xA0], xmm10
000074b6341d1b3a  vmovaps [rsp+0xB0], xmm11
000074b6341d1b43  vmovaps [rsp+0xC0], xmm12
000074b6341d1b4c  vmovaps [rsp+0xD0], xmm13
000074b6341d1b55  vmovaps [rsp+0xE0], xmm15
000074b6341d1b5e  sub rsp, 0x30
000074b6341d1b62  movaps [rsp], xmm14
000074b6341d1b67  movaps [rsp+0x10], xmm13
000074b6341d1b6d  movaps [rsp+0x20], xmm1
000074b6341d1b72  lea rdi, [rsp]
000074b6341d1b76  mov esi, 0x00
000074b6341d1b7b  mov rax, 0x5E1AA0A2F530
000074b6341d1b85  call rax
000074b6341d1b87  movaps xmm14, [rsp]
000074b6341d1b8c  add rsp, 0x30
000074b6341d1b90  vmovaps xmm0, [rsp]
000074b6341d1b95  vmovaps xmm1, [rsp+0x10]
000074b6341d1b9b  vmovaps xmm2, [rsp+0x20]
000074b6341d1ba1  vmovaps xmm3, [rsp+0x30]
000074b6341d1ba7  vmovaps xmm4, [rsp+0x40]
000074b6341d1bad  vmovaps xmm5, [rsp+0x50]
000074b6341d1bb3  vmovaps xmm6, [rsp+0x60]
000074b6341d1bb9  vmovaps xmm7, [rsp+0x70]
000074b6341d1bbf  vmovaps xmm8, [rsp+0x80]
000074b6341d1bc8  vmovaps xmm9, [rsp+0x90]
000074b6341d1bd1  vmovaps xmm10, [rsp+0xA0]
000074b6341d1bda  vmovaps xmm11, [rsp+0xB0]
000074b6341d1be3  vmovaps xmm12, [rsp+0xC0]
000074b6341d1bec  vmovaps xmm13, [rsp+0xD0]
000074b6341d1bf5  vmovaps xmm15, [rsp+0xE0]
000074b6341d1bfe  add rsp, 0xF0
000074b6341d1c05  pop r11
000074b6341d1c07  pop r10
000074b6341d1c09  pop r9
000074b6341d1c0b  pop r8
000074b6341d1c0d  pop rsi
000074b6341d1c0e  pop rdi
000074b6341d1c0f  pop rdx
000074b6341d1c10  pop rcx
000074b6341d1c11  pop rax
000074b6341d1c12  add rsp, 0x08
000074b6341d1c16  jmp 0x000074B6341CFAAF
000074b6341d1c1b  sub rsp, 0x08
000074b6341d1c1f  push rax
000074b6341d1c20  push rcx
000074b6341d1c21  push rdx
000074b6341d1c22  push rdi
000074b6341d1c23  push rsi
000074b6341d1c24  push r8
000074b6341d1c26  push r9
000074b6341d1c28  push r10
000074b6341d1c2a  push r11
000074b6341d1c2c  sub rsp, 0xF0
000074b6341d1c33  vmovaps [rsp], xmm0
000074b6341d1c38  vmovaps [rsp+0x10], xmm1
000074b6341d1c3e  vmovaps [rsp+0x20], xmm2
000074b6341d1c44  vmovaps [rsp+0x30], xmm3
000074b6341d1c4a  vmovaps [rsp+0x40], xmm4
000074b6341d1c50  vmovaps [rsp+0x50], xmm5
000074b6341d1c56  vmovaps [rsp+0x60], xmm6
000074b6341d1c5c  vmovaps [rsp+0x70], xmm7
000074b6341d1c62  vmovaps [rsp+0x80], xmm8
000074b6341d1c6b  vmovaps [rsp+0x90], xmm9
000074b6341d1c74  vmovaps [rsp+0xA0], xmm10
000074b6341d1c7d  vmovaps [rsp+0xB0], xmm11
000074b6341d1c86  vmovaps [rsp+0xC0], xmm12
000074b6341d1c8f  vmovaps [rsp+0xD0], xmm13
000074b6341d1c98  vmovaps [rsp+0xE0], xmm14
000074b6341d1ca1  sub rsp, 0x30
000074b6341d1ca5  movaps [rsp], xmm15
000074b6341d1caa  movaps [rsp+0x10], xmm13
000074b6341d1cb0  movaps [rsp+0x20], xmm1
000074b6341d1cb5  lea rdi, [rsp]
000074b6341d1cb9  mov esi, 0x00
000074b6341d1cbe  mov rax, 0x5E1AA0A2F530
000074b6341d1cc8  call rax
000074b6341d1cca  movaps xmm15, [rsp]
000074b6341d1ccf  add rsp, 0x30
000074b6341d1cd3  vmovaps xmm0, [rsp]
000074b6341d1cd8  vmovaps xmm1, [rsp+0x10]
000074b6341d1cde  vmovaps xmm2, [rsp+0x20]
000074b6341d1ce4  vmovaps xmm3, [rsp+0x30]
000074b6341d1cea  vmovaps xmm4, [rsp+0x40]
000074b6341d1cf0  vmovaps xmm5, [rsp+0x50]
000074b6341d1cf6  vmovaps xmm6, [rsp+0x60]
000074b6341d1cfc  vmovaps xmm7, [rsp+0x70]
000074b6341d1d02  vmovaps xmm8, [rsp+0x80]
000074b6341d1d0b  vmovaps xmm9, [rsp+0x90]
000074b6341d1d14  vmovaps xmm10, [rsp+0xA0]
000074b6341d1d1d  vmovaps xmm11, [rsp+0xB0]
000074b6341d1d26  vmovaps xmm12, [rsp+0xC0]
000074b6341d1d2f  vmovaps xmm13, [rsp+0xD0]
000074b6341d1d38  vmovaps xmm14, [rsp+0xE0]
000074b6341d1d41  add rsp, 0xF0
000074b6341d1d48  pop r11
000074b6341d1d4a  pop r10
000074b6341d1d4c  pop r9
000074b6341d1d4e  pop r8
000074b6341d1d50  pop rsi
000074b6341d1d51  pop rdi
000074b6341d1d52  pop rdx
000074b6341d1d53  pop rcx
000074b6341d1d54  pop rax
000074b6341d1d55  add rsp, 0x08
000074b6341d1d59  jmp 0x000074B6341CFAEB
000074b6341d1d5e  call 0x000074B633FFF430
000074b6341d1d63  jmp 0x000074B6341CFAF8
000074b6341d1d68  sub rsp, 0x08
000074b6341d1d6c  push rax
000074b6341d1d6d  push rcx
000074b6341d1d6e  push rdx
000074b6341d1d6f  push rdi
000074b6341d1d70  push rsi
000074b6341d1d71  push r8
000074b6341d1d73  push r9
000074b6341d1d75  push r10
000074b6341d1d77  push r11
000074b6341d1d79  sub rsp, 0xF0
000074b6341d1d80  vmovaps [rsp], xmm0
000074b6341d1d85  vmovaps [rsp+0x10], xmm1
000074b6341d1d8b  vmovaps [rsp+0x20], xmm2
000074b6341d1d91  vmovaps [rsp+0x30], xmm3
000074b6341d1d97  vmovaps [rsp+0x40], xmm4
000074b6341d1d9d  vmovaps [rsp+0x50], xmm5
000074b6341d1da3  vmovaps [rsp+0x60], xmm6
000074b6341d1da9  vmovaps [rsp+0x70], xmm7
000074b6341d1daf  vmovaps [rsp+0x80], xmm8
000074b6341d1db8  vmovaps [rsp+0x90], xmm9
000074b6341d1dc1  vmovaps [rsp+0xA0], xmm10
000074b6341d1dca  vmovaps [rsp+0xB0], xmm11
000074b6341d1dd3  vmovaps [rsp+0xC0], xmm12
000074b6341d1ddc  vmovaps [rsp+0xD0], xmm13
000074b6341d1de5  vmovaps [rsp+0xE0], xmm15
000074b6341d1dee  sub rsp, 0x30
000074b6341d1df2  movaps [rsp], xmm14
000074b6341d1df7  movaps [rsp+0x10], xmm13
000074b6341d1dfd  movaps [rsp+0x20], xmm2
000074b6341d1e02  lea rdi, [rsp]
000074b6341d1e06  mov esi, 0x00
000074b6341d1e0b  mov rax, 0x5E1AA0A2F530
000074b6341d1e15  call rax
000074b6341d1e17  movaps xmm14, [rsp]
000074b6341d1e1c  add rsp, 0x30
000074b6341d1e20  vmovaps xmm0, [rsp]
000074b6341d1e25  vmovaps xmm1, [rsp+0x10]
000074b6341d1e2b  vmovaps xmm2, [rsp+0x20]
000074b6341d1e31  vmovaps xmm3, [rsp+0x30]
000074b6341d1e37  vmovaps xmm4, [rsp+0x40]
000074b6341d1e3d  vmovaps xmm5, [rsp+0x50]
000074b6341d1e43  vmovaps xmm6, [rsp+0x60]
000074b6341d1e49  vmovaps xmm7, [rsp+0x70]
000074b6341d1e4f  vmovaps xmm8, [rsp+0x80]
000074b6341d1e58  vmovaps xmm9, [rsp+0x90]
000074b6341d1e61  vmovaps xmm10, [rsp+0xA0]
000074b6341d1e6a  vmovaps xmm11, [rsp+0xB0]
000074b6341d1e73  vmovaps xmm12, [rsp+0xC0]
000074b6341d1e7c  vmovaps xmm13, [rsp+0xD0]
000074b6341d1e85  vmovaps xmm15, [rsp+0xE0]
000074b6341d1e8e  add rsp, 0xF0
000074b6341d1e95  pop r11
000074b6341d1e97  pop r10
000074b6341d1e99  pop r9
000074b6341d1e9b  pop r8
000074b6341d1e9d  pop rsi
000074b6341d1e9e  pop rdi
000074b6341d1e9f  pop rdx
000074b6341d1ea0  pop rcx
000074b6341d1ea1  pop rax
000074b6341d1ea2  add rsp, 0x08
000074b6341d1ea6  jmp 0x000074B6341CFB24
000074b6341d1eab  sub rsp, 0x08
000074b6341d1eaf  push rax
000074b6341d1eb0  push rcx
000074b6341d1eb1  push rdx
000074b6341d1eb2  push rdi
000074b6341d1eb3  push rsi
000074b6341d1eb4  push r8
000074b6341d1eb6  push r9
000074b6341d1eb8  push r10
000074b6341d1eba  push r11
000074b6341d1ebc  sub rsp, 0xF0
000074b6341d1ec3  vmovaps [rsp], xmm0
000074b6341d1ec8  vmovaps [rsp+0x10], xmm2
000074b6341d1ece  vmovaps [rsp+0x20], xmm3
000074b6341d1ed4  vmovaps [rsp+0x30], xmm4
000074b6341d1eda  vmovaps [rsp+0x40], xmm5
000074b6341d1ee0  vmovaps [rsp+0x50], xmm6
000074b6341d1ee6  vmovaps [rsp+0x60], xmm7
000074b6341d1eec  vmovaps [rsp+0x70], xmm8
000074b6341d1ef2  vmovaps [rsp+0x80], xmm9
000074b6341d1efb  vmovaps [rsp+0x90], xmm10
000074b6341d1f04  vmovaps [rsp+0xA0], xmm11
000074b6341d1f0d  vmovaps [rsp+0xB0], xmm12
000074b6341d1f16  vmovaps [rsp+0xC0], xmm13
000074b6341d1f1f  vmovaps [rsp+0xD0], xmm14
000074b6341d1f28  vmovaps [rsp+0xE0], xmm15
000074b6341d1f31  sub rsp, 0x30
000074b6341d1f35  movaps [rsp], xmm1
000074b6341d1f39  movaps [rsp+0x10], xmm13
000074b6341d1f3f  movaps [rsp+0x20], xmm2
000074b6341d1f44  lea rdi, [rsp]
000074b6341d1f48  mov esi, 0x00
000074b6341d1f4d  mov rax, 0x5E1AA0A2F530
000074b6341d1f57  call rax
000074b6341d1f59  movaps xmm1, [rsp]
000074b6341d1f5d  add rsp, 0x30
000074b6341d1f61  vmovaps xmm0, [rsp]
000074b6341d1f66  vmovaps xmm2, [rsp+0x10]
000074b6341d1f6c  vmovaps xmm3, [rsp+0x20]
000074b6341d1f72  vmovaps xmm4, [rsp+0x30]
000074b6341d1f78  vmovaps xmm5, [rsp+0x40]
000074b6341d1f7e  vmovaps xmm6, [rsp+0x50]
000074b6341d1f84  vmovaps xmm7, [rsp+0x60]
000074b6341d1f8a  vmovaps xmm8, [rsp+0x70]
000074b6341d1f90  vmovaps xmm9, [rsp+0x80]
000074b6341d1f99  vmovaps xmm10, [rsp+0x90]
000074b6341d1fa2  vmovaps xmm11, [rsp+0xA0]
000074b6341d1fab  vmovaps xmm12, [rsp+0xB0]
000074b6341d1fb4  vmovaps xmm13, [rsp+0xC0]
000074b6341d1fbd  vmovaps xmm14, [rsp+0xD0]
000074b6341d1fc6  vmovaps xmm15, [rsp+0xE0]
000074b6341d1fcf  add rsp, 0xF0
000074b6341d1fd6  pop r11
000074b6341d1fd8  pop r10
000074b6341d1fda  pop r9
000074b6341d1fdc  pop r8
000074b6341d1fde  pop rsi
000074b6341d1fdf  pop rdi
000074b6341d1fe0  pop rdx
000074b6341d1fe1  pop rcx
000074b6341d1fe2  pop rax
000074b6341d1fe3  add rsp, 0x08
000074b6341d1fe7  jmp 0x000074B6341CFB52
000074b6341d1fec  sub rsp, 0x08
000074b6341d1ff0  push rax
000074b6341d1ff1  push rcx
000074b6341d1ff2  push rdx
000074b6341d1ff3  push rdi
000074b6341d1ff4  push rsi
000074b6341d1ff5  push r8
000074b6341d1ff7  push r9
000074b6341d1ff9  push r10
000074b6341d1ffb  push r11
000074b6341d1ffd  sub rsp, 0xF0
000074b6341d2004  vmovaps [rsp], xmm0
000074b6341d2009  vmovaps [rsp+0x10], xmm1
000074b6341d200f  vmovaps [rsp+0x20], xmm3
000074b6341d2015  vmovaps [rsp+0x30], xmm4
000074b6341d201b  vmovaps [rsp+0x40], xmm5
000074b6341d2021  vmovaps [rsp+0x50], xmm6
000074b6341d2027  vmovaps [rsp+0x60], xmm7
000074b6341d202d  vmovaps [rsp+0x70], xmm8
000074b6341d2033  vmovaps [rsp+0x80], xmm9
000074b6341d203c  vmovaps [rsp+0x90], xmm10
000074b6341d2045  vmovaps [rsp+0xA0], xmm11
000074b6341d204e  vmovaps [rsp+0xB0], xmm12
000074b6341d2057  vmovaps [rsp+0xC0], xmm13
000074b6341d2060  vmovaps [rsp+0xD0], xmm14
000074b6341d2069  vmovaps [rsp+0xE0], xmm15
000074b6341d2072  sub rsp, 0x30
000074b6341d2076  movaps [rsp], xmm2
000074b6341d207a  movaps [rsp+0x10], xmm1
000074b6341d207f  movaps [rsp+0x20], xmm13
000074b6341d2085  lea rdi, [rsp]
000074b6341d2089  mov esi, 0x00
000074b6341d208e  mov rax, 0x5E1AA0A2F530
000074b6341d2098  call rax
000074b6341d209a  movaps xmm2, [rsp]
000074b6341d209e  add rsp, 0x30
000074b6341d20a2  vmovaps xmm0, [rsp]
000074b6341d20a7  vmovaps xmm1, [rsp+0x10]
000074b6341d20ad  vmovaps xmm3, [rsp+0x20]
000074b6341d20b3  vmovaps xmm4, [rsp+0x30]
000074b6341d20b9  vmovaps xmm5, [rsp+0x40]
000074b6341d20bf  vmovaps xmm6, [rsp+0x50]
000074b6341d20c5  vmovaps xmm7, [rsp+0x60]
000074b6341d20cb  vmovaps xmm8, [rsp+0x70]
000074b6341d20d1  vmovaps xmm9, [rsp+0x80]
000074b6341d20da  vmovaps xmm10, [rsp+0x90]
000074b6341d20e3  vmovaps xmm11, [rsp+0xA0]
000074b6341d20ec  vmovaps xmm12, [rsp+0xB0]
000074b6341d20f5  vmovaps xmm13, [rsp+0xC0]
000074b6341d20fe  vmovaps xmm14, [rsp+0xD0]
000074b6341d2107  vmovaps xmm15, [rsp+0xE0]
000074b6341d2110  add rsp, 0xF0
000074b6341d2117  pop r11
000074b6341d2119  pop r10
000074b6341d211b  pop r9
000074b6341d211d  pop r8
000074b6341d211f  pop rsi
000074b6341d2120  pop rdi
000074b6341d2121  pop rdx
000074b6341d2122  pop rcx
000074b6341d2123  pop rax
000074b6341d2124  add rsp, 0x08
000074b6341d2128  jmp 0x000074B6341CFBAB
000074b6341d212d  call 0x000074B633FFF430
000074b6341d2132  jmp 0x000074B6341CFBB8
000074b6341d2137  sub rsp, 0x08
000074b6341d213b  push rax
000074b6341d213c  push rcx
000074b6341d213d  push rdx
000074b6341d213e  push rdi
000074b6341d213f  push rsi
000074b6341d2140  push r8
000074b6341d2142  push r9
000074b6341d2144  push r10
000074b6341d2146  push r11
000074b6341d2148  sub rsp, 0xF0
000074b6341d214f  vmovaps [rsp], xmm0
000074b6341d2154  vmovaps [rsp+0x10], xmm1
000074b6341d215a  vmovaps [rsp+0x20], xmm2
000074b6341d2160  vmovaps [rsp+0x30], xmm3
000074b6341d2166  vmovaps [rsp+0x40], xmm4
000074b6341d216c  vmovaps [rsp+0x50], xmm5
000074b6341d2172  vmovaps [rsp+0x60], xmm6
000074b6341d2178  vmovaps [rsp+0x70], xmm7
000074b6341d217e  vmovaps [rsp+0x80], xmm8
000074b6341d2187  vmovaps [rsp+0x90], xmm9
000074b6341d2190  vmovaps [rsp+0xA0], xmm10
000074b6341d2199  vmovaps [rsp+0xB0], xmm11
000074b6341d21a2  vmovaps [rsp+0xC0], xmm12
000074b6341d21ab  vmovaps [rsp+0xD0], xmm13
000074b6341d21b4  vmovaps [rsp+0xE0], xmm14
000074b6341d21bd  sub rsp, 0x30
000074b6341d21c1  movaps [rsp], xmm15
000074b6341d21c6  movaps [rsp+0x10], xmm13
000074b6341d21cc  movaps [rsp+0x20], xmm1
000074b6341d21d1  lea rdi, [rsp]
000074b6341d21d5  mov esi, 0x00
000074b6341d21da  mov rax, 0x5E1AA0A2F530
000074b6341d21e4  call rax
000074b6341d21e6  movaps xmm15, [rsp]
000074b6341d21eb  add rsp, 0x30
000074b6341d21ef  vmovaps xmm0, [rsp]
000074b6341d21f4  vmovaps xmm1, [rsp+0x10]
000074b6341d21fa  vmovaps xmm2, [rsp+0x20]
000074b6341d2200  vmovaps xmm3, [rsp+0x30]
000074b6341d2206  vmovaps xmm4, [rsp+0x40]
000074b6341d220c  vmovaps xmm5, [rsp+0x50]
000074b6341d2212  vmovaps xmm6, [rsp+0x60]
000074b6341d2218  vmovaps xmm7, [rsp+0x70]
000074b6341d221e  vmovaps xmm8, [rsp+0x80]
000074b6341d2227  vmovaps xmm9, [rsp+0x90]
000074b6341d2230  vmovaps xmm10, [rsp+0xA0]
000074b6341d2239  vmovaps xmm11, [rsp+0xB0]
000074b6341d2242  vmovaps xmm12, [rsp+0xC0]
000074b6341d224b  vmovaps xmm13, [rsp+0xD0]
000074b6341d2254  vmovaps xmm14, [rsp+0xE0]
000074b6341d225d  add rsp, 0xF0
000074b6341d2264  pop r11
000074b6341d2266  pop r10
000074b6341d2268  pop r9
000074b6341d226a  pop r8
000074b6341d226c  pop rsi
000074b6341d226d  pop rdi
000074b6341d226e  pop rdx
000074b6341d226f  pop rcx
000074b6341d2270  pop rax
000074b6341d2271  add rsp, 0x08
000074b6341d2275  jmp 0x000074B6341CFBF7
000074b6341d227a  sub rsp, 0x08
000074b6341d227e  push rax
000074b6341d227f  push rcx
000074b6341d2280  push rdx
000074b6341d2281  push rdi
000074b6341d2282  push rsi
000074b6341d2283  push r8
000074b6341d2285  push r9
000074b6341d2287  push r10
000074b6341d2289  push r11
000074b6341d228b  sub rsp, 0xF0
000074b6341d2292  vmovaps [rsp], xmm0
000074b6341d2297  vmovaps [rsp+0x10], xmm1
000074b6341d229d  vmovaps [rsp+0x20], xmm2
000074b6341d22a3  vmovaps [rsp+0x30], xmm3
000074b6341d22a9  vmovaps [rsp+0x40], xmm4
000074b6341d22af  vmovaps [rsp+0x50], xmm5
000074b6341d22b5  vmovaps [rsp+0x60], xmm6
000074b6341d22bb  vmovaps [rsp+0x70], xmm7
000074b6341d22c1  vmovaps [rsp+0x80], xmm8
000074b6341d22ca  vmovaps [rsp+0x90], xmm9
000074b6341d22d3  vmovaps [rsp+0xA0], xmm10
000074b6341d22dc  vmovaps [rsp+0xB0], xmm11
000074b6341d22e5  vmovaps [rsp+0xC0], xmm12
000074b6341d22ee  vmovaps [rsp+0xD0], xmm13
000074b6341d22f7  vmovaps [rsp+0xE0], xmm15
000074b6341d2300  sub rsp, 0x30
000074b6341d2304  movaps [rsp], xmm14
000074b6341d2309  movaps [rsp+0x10], xmm11
000074b6341d230f  movaps [rsp+0x20], xmm1
000074b6341d2314  lea rdi, [rsp]
000074b6341d2318  mov esi, 0x00
000074b6341d231d  mov rax, 0x5E1AA0A2F530
000074b6341d2327  call rax
000074b6341d2329  movaps xmm14, [rsp]
000074b6341d232e  add rsp, 0x30
000074b6341d2332  vmovaps xmm0, [rsp]
000074b6341d2337  vmovaps xmm1, [rsp+0x10]
000074b6341d233d  vmovaps xmm2, [rsp+0x20]
000074b6341d2343  vmovaps xmm3, [rsp+0x30]
000074b6341d2349  vmovaps xmm4, [rsp+0x40]
000074b6341d234f  vmovaps xmm5, [rsp+0x50]
000074b6341d2355  vmovaps xmm6, [rsp+0x60]
000074b6341d235b  vmovaps xmm7, [rsp+0x70]
000074b6341d2361  vmovaps xmm8, [rsp+0x80]
000074b6341d236a  vmovaps xmm9, [rsp+0x90]
000074b6341d2373  vmovaps xmm10, [rsp+0xA0]
000074b6341d237c  vmovaps xmm11, [rsp+0xB0]
000074b6341d2385  vmovaps xmm12, [rsp+0xC0]
000074b6341d238e  vmovaps xmm13, [rsp+0xD0]
000074b6341d2397  vmovaps xmm15, [rsp+0xE0]
000074b6341d23a0  add rsp, 0xF0
000074b6341d23a7  pop r11
000074b6341d23a9  pop r10
000074b6341d23ab  pop r9
000074b6341d23ad  pop r8
000074b6341d23af  pop rsi
000074b6341d23b0  pop rdi
000074b6341d23b1  pop rdx
000074b6341d23b2  pop rcx
000074b6341d23b3  pop rax
000074b6341d23b4  add rsp, 0x08
000074b6341d23b8  jmp 0x000074B6341CFC21
000074b6341d23bd  sub rsp, 0x08
000074b6341d23c1  push rax
000074b6341d23c2  push rcx
000074b6341d23c3  push rdx
000074b6341d23c4  push rdi
000074b6341d23c5  push rsi
000074b6341d23c6  push r8
000074b6341d23c8  push r9
000074b6341d23ca  push r10
000074b6341d23cc  push r11
000074b6341d23ce  sub rsp, 0xF0
000074b6341d23d5  vmovaps [rsp], xmm0
000074b6341d23da  vmovaps [rsp+0x10], xmm1
000074b6341d23e0  vmovaps [rsp+0x20], xmm2
000074b6341d23e6  vmovaps [rsp+0x30], xmm3
000074b6341d23ec  vmovaps [rsp+0x40], xmm4
000074b6341d23f2  vmovaps [rsp+0x50], xmm5
000074b6341d23f8  vmovaps [rsp+0x60], xmm6
000074b6341d23fe  vmovaps [rsp+0x70], xmm7
000074b6341d2404  vmovaps [rsp+0x80], xmm8
000074b6341d240d  vmovaps [rsp+0x90], xmm9
000074b6341d2416  vmovaps [rsp+0xA0], xmm10
000074b6341d241f  vmovaps [rsp+0xB0], xmm11
000074b6341d2428  vmovaps [rsp+0xC0], xmm12
000074b6341d2431  vmovaps [rsp+0xD0], xmm14
000074b6341d243a  vmovaps [rsp+0xE0], xmm15
000074b6341d2443  sub rsp, 0x30
000074b6341d2447  movaps [rsp], xmm13
000074b6341d244c  movaps [rsp+0x10], xmm11
000074b6341d2452  movaps [rsp+0x20], xmm1
000074b6341d2457  lea rdi, [rsp]
000074b6341d245b  mov esi, 0x00
000074b6341d2460  mov rax, 0x5E1AA0A2F530
000074b6341d246a  call rax
000074b6341d246c  movaps xmm13, [rsp]
000074b6341d2471  add rsp, 0x30
000074b6341d2475  vmovaps xmm0, [rsp]
000074b6341d247a  vmovaps xmm1, [rsp+0x10]
000074b6341d2480  vmovaps xmm2, [rsp+0x20]
000074b6341d2486  vmovaps xmm3, [rsp+0x30]
000074b6341d248c  vmovaps xmm4, [rsp+0x40]
000074b6341d2492  vmovaps xmm5, [rsp+0x50]
000074b6341d2498  vmovaps xmm6, [rsp+0x60]
000074b6341d249e  vmovaps xmm7, [rsp+0x70]
000074b6341d24a4  vmovaps xmm8, [rsp+0x80]
000074b6341d24ad  vmovaps xmm9, [rsp+0x90]
000074b6341d24b6  vmovaps xmm10, [rsp+0xA0]
000074b6341d24bf  vmovaps xmm11, [rsp+0xB0]
000074b6341d24c8  vmovaps xmm12, [rsp+0xC0]
000074b6341d24d1  vmovaps xmm14, [rsp+0xD0]
000074b6341d24da  vmovaps xmm15, [rsp+0xE0]
000074b6341d24e3  add rsp, 0xF0
000074b6341d24ea  pop r11
000074b6341d24ec  pop r10
000074b6341d24ee  pop r9
000074b6341d24f0  pop r8
000074b6341d24f2  pop rsi
000074b6341d24f3  pop rdi
000074b6341d24f4  pop rdx
000074b6341d24f5  pop rcx
000074b6341d24f6  pop rax
000074b6341d24f7  add rsp, 0x08
000074b6341d24fb  jmp 0x000074B6341CFC76
000074b6341d2500  call 0x000074B633FFF430
000074b6341d2505  jmp 0x000074B6341CFC83
000074b6341d250a  sub rsp, 0x08
000074b6341d250e  push rax
000074b6341d250f  push rcx
000074b6341d2510  push rdx
000074b6341d2511  push rdi
000074b6341d2512  push rsi
000074b6341d2513  push r8
000074b6341d2515  push r9
000074b6341d2517  push r10
000074b6341d2519  push r11
000074b6341d251b  sub rsp, 0xF0
000074b6341d2522  vmovaps [rsp], xmm0
000074b6341d2527  vmovaps [rsp+0x10], xmm1
000074b6341d252d  vmovaps [rsp+0x20], xmm2
000074b6341d2533  vmovaps [rsp+0x30], xmm3
000074b6341d2539  vmovaps [rsp+0x40], xmm4
000074b6341d253f  vmovaps [rsp+0x50], xmm5
000074b6341d2545  vmovaps [rsp+0x60], xmm6
000074b6341d254b  vmovaps [rsp+0x70], xmm7
000074b6341d2551  vmovaps [rsp+0x80], xmm8
000074b6341d255a  vmovaps [rsp+0x90], xmm9
000074b6341d2563  vmovaps [rsp+0xA0], xmm10
000074b6341d256c  vmovaps [rsp+0xB0], xmm11
000074b6341d2575  vmovaps [rsp+0xC0], xmm12
000074b6341d257e  vmovaps [rsp+0xD0], xmm13
000074b6341d2587  vmovaps [rsp+0xE0], xmm14
000074b6341d2590  sub rsp, 0x30
000074b6341d2594  movaps [rsp], xmm15
000074b6341d2599  movaps [rsp+0x10], xmm11
000074b6341d259f  movaps [rsp+0x20], xmm1
000074b6341d25a4  lea rdi, [rsp]
000074b6341d25a8  mov esi, 0x00
000074b6341d25ad  mov rax, 0x5E1AA0A2F530
000074b6341d25b7  call rax
000074b6341d25b9  movaps xmm15, [rsp]
000074b6341d25be  add rsp, 0x30
000074b6341d25c2  vmovaps xmm0, [rsp]
000074b6341d25c7  vmovaps xmm1, [rsp+0x10]
000074b6341d25cd  vmovaps xmm2, [rsp+0x20]
000074b6341d25d3  vmovaps xmm3, [rsp+0x30]
000074b6341d25d9  vmovaps xmm4, [rsp+0x40]
000074b6341d25df  vmovaps xmm5, [rsp+0x50]
000074b6341d25e5  vmovaps xmm6, [rsp+0x60]
000074b6341d25eb  vmovaps xmm7, [rsp+0x70]
000074b6341d25f1  vmovaps xmm8, [rsp+0x80]
000074b6341d25fa  vmovaps xmm9, [rsp+0x90]
000074b6341d2603  vmovaps xmm10, [rsp+0xA0]
000074b6341d260c  vmovaps xmm11, [rsp+0xB0]
000074b6341d2615  vmovaps xmm12, [rsp+0xC0]
000074b6341d261e  vmovaps xmm13, [rsp+0xD0]
000074b6341d2627  vmovaps xmm14, [rsp+0xE0]
000074b6341d2630  add rsp, 0xF0
000074b6341d2637  pop r11
000074b6341d2639  pop r10
000074b6341d263b  pop r9
000074b6341d263d  pop r8
000074b6341d263f  pop rsi
000074b6341d2640  pop rdi
000074b6341d2641  pop rdx
000074b6341d2642  pop rcx
000074b6341d2643  pop rax
000074b6341d2644  add rsp, 0x08
000074b6341d2648  jmp 0x000074B6341CFCBC
000074b6341d264d  sub rsp, 0x08
000074b6341d2651  push rax
000074b6341d2652  push rcx
000074b6341d2653  push rdx
000074b6341d2654  push rdi
000074b6341d2655  push rsi
000074b6341d2656  push r8
000074b6341d2658  push r9
000074b6341d265a  push r10
000074b6341d265c  push r11
000074b6341d265e  sub rsp, 0xF0
000074b6341d2665  vmovaps [rsp], xmm0
000074b6341d266a  vmovaps [rsp+0x10], xmm1
000074b6341d2670  vmovaps [rsp+0x20], xmm2
000074b6341d2676  vmovaps [rsp+0x30], xmm3
000074b6341d267c  vmovaps [rsp+0x40], xmm4
000074b6341d2682  vmovaps [rsp+0x50], xmm5
000074b6341d2688  vmovaps [rsp+0x60], xmm6
000074b6341d268e  vmovaps [rsp+0x70], xmm7
000074b6341d2694  vmovaps [rsp+0x80], xmm8
000074b6341d269d  vmovaps [rsp+0x90], xmm9
000074b6341d26a6  vmovaps [rsp+0xA0], xmm10
000074b6341d26af  vmovaps [rsp+0xB0], xmm12
000074b6341d26b8  vmovaps [rsp+0xC0], xmm13
000074b6341d26c1  vmovaps [rsp+0xD0], xmm14
000074b6341d26ca  vmovaps [rsp+0xE0], xmm15
000074b6341d26d3  sub rsp, 0x30
000074b6341d26d7  movaps [rsp], xmm11
000074b6341d26dc  movaps [rsp+0x10], xmm6
000074b6341d26e1  movaps [rsp+0x20], xmm14
000074b6341d26e7  lea rdi, [rsp]
000074b6341d26eb  mov esi, 0x00
000074b6341d26f0  mov rax, 0x5E1AA0A2F530
000074b6341d26fa  call rax
000074b6341d26fc  movaps xmm11, [rsp]
000074b6341d2701  add rsp, 0x30
000074b6341d2705  vmovaps xmm0, [rsp]
000074b6341d270a  vmovaps xmm1, [rsp+0x10]
000074b6341d2710  vmovaps xmm2, [rsp+0x20]
000074b6341d2716  vmovaps xmm3, [rsp+0x30]
000074b6341d271c  vmovaps xmm4, [rsp+0x40]
000074b6341d2722  vmovaps xmm5, [rsp+0x50]
000074b6341d2728  vmovaps xmm6, [rsp+0x60]
000074b6341d272e  vmovaps xmm7, [rsp+0x70]
000074b6341d2734  vmovaps xmm8, [rsp+0x80]
000074b6341d273d  vmovaps xmm9, [rsp+0x90]
000074b6341d2746  vmovaps xmm10, [rsp+0xA0]
000074b6341d274f  vmovaps xmm12, [rsp+0xB0]
000074b6341d2758  vmovaps xmm13, [rsp+0xC0]
000074b6341d2761  vmovaps xmm14, [rsp+0xD0]
000074b6341d276a  vmovaps xmm15, [rsp+0xE0]
000074b6341d2773  add rsp, 0xF0
000074b6341d277a  pop r11
000074b6341d277c  pop r10
000074b6341d277e  pop r9
000074b6341d2780  pop r8
000074b6341d2782  pop rsi
000074b6341d2783  pop rdi
000074b6341d2784  pop rdx
000074b6341d2785  pop rcx
000074b6341d2786  pop rax
000074b6341d2787  add rsp, 0x08
000074b6341d278b  jmp 0x000074B6341CFD34
000074b6341d2790  call 0x000074B633FFF430
000074b6341d2795  jmp 0x000074B6341CFD3E
000074b6341d279a  sub rsp, 0x08
000074b6341d279e  push rax
000074b6341d279f  push rcx
000074b6341d27a0  push rdx
000074b6341d27a1  push rdi
000074b6341d27a2  push rsi
000074b6341d27a3  push r8
000074b6341d27a5  push r9
000074b6341d27a7  push r10
000074b6341d27a9  push r11
000074b6341d27ab  sub rsp, 0xF0
000074b6341d27b2  vmovaps [rsp], xmm0
000074b6341d27b7  vmovaps [rsp+0x10], xmm1
000074b6341d27bd  vmovaps [rsp+0x20], xmm2
000074b6341d27c3  vmovaps [rsp+0x30], xmm3
000074b6341d27c9  vmovaps [rsp+0x40], xmm4
000074b6341d27cf  vmovaps [rsp+0x50], xmm5
000074b6341d27d5  vmovaps [rsp+0x60], xmm6
000074b6341d27db  vmovaps [rsp+0x70], xmm7
000074b6341d27e1  vmovaps [rsp+0x80], xmm8
000074b6341d27ea  vmovaps [rsp+0x90], xmm9
000074b6341d27f3  vmovaps [rsp+0xA0], xmm10
000074b6341d27fc  vmovaps [rsp+0xB0], xmm11
000074b6341d2805  vmovaps [rsp+0xC0], xmm12
000074b6341d280e  vmovaps [rsp+0xD0], xmm13
000074b6341d2817  vmovaps [rsp+0xE0], xmm15
000074b6341d2820  sub rsp, 0x30
000074b6341d2824  movaps [rsp], xmm14
000074b6341d2829  movaps [rsp+0x10], xmm6
000074b6341d282e  movaps [rsp+0x20], xmm2
000074b6341d2833  lea rdi, [rsp]
000074b6341d2837  mov esi, 0x00
000074b6341d283c  mov rax, 0x5E1AA0A2F530
000074b6341d2846  call rax
000074b6341d2848  movaps xmm14, [rsp]
000074b6341d284d  add rsp, 0x30
000074b6341d2851  vmovaps xmm0, [rsp]
000074b6341d2856  vmovaps xmm1, [rsp+0x10]
000074b6341d285c  vmovaps xmm2, [rsp+0x20]
000074b6341d2862  vmovaps xmm3, [rsp+0x30]
000074b6341d2868  vmovaps xmm4, [rsp+0x40]
000074b6341d286e  vmovaps xmm5, [rsp+0x50]
000074b6341d2874  vmovaps xmm6, [rsp+0x60]
000074b6341d287a  vmovaps xmm7, [rsp+0x70]
000074b6341d2880  vmovaps xmm8, [rsp+0x80]
000074b6341d2889  vmovaps xmm9, [rsp+0x90]
000074b6341d2892  vmovaps xmm10, [rsp+0xA0]
000074b6341d289b  vmovaps xmm11, [rsp+0xB0]
000074b6341d28a4  vmovaps xmm12, [rsp+0xC0]
000074b6341d28ad  vmovaps xmm13, [rsp+0xD0]
000074b6341d28b6  vmovaps xmm15, [rsp+0xE0]
000074b6341d28bf  add rsp, 0xF0
000074b6341d28c6  pop r11
000074b6341d28c8  pop r10
000074b6341d28ca  pop r9
000074b6341d28cc  pop r8
000074b6341d28ce  pop rsi
000074b6341d28cf  pop rdi
000074b6341d28d0  pop rdx
000074b6341d28d1  pop rcx
000074b6341d28d2  pop rax
000074b6341d28d3  add rsp, 0x08
000074b6341d28d7  jmp 0x000074B6341CFD72
000074b6341d28dc  sub rsp, 0x08
000074b6341d28e0  push rax
000074b6341d28e1  push rcx
000074b6341d28e2  push rdx
000074b6341d28e3  push rdi
000074b6341d28e4  push rsi
000074b6341d28e5  push r8
000074b6341d28e7  push r9
000074b6341d28e9  push r10
000074b6341d28eb  push r11
000074b6341d28ed  sub rsp, 0xF0
000074b6341d28f4  vmovaps [rsp], xmm0
000074b6341d28f9  vmovaps [rsp+0x10], xmm1
000074b6341d28ff  vmovaps [rsp+0x20], xmm2
000074b6341d2905  vmovaps [rsp+0x30], xmm3
000074b6341d290b  vmovaps [rsp+0x40], xmm4
000074b6341d2911  vmovaps [rsp+0x50], xmm5
000074b6341d2917  vmovaps [rsp+0x60], xmm7
000074b6341d291d  vmovaps [rsp+0x70], xmm8
000074b6341d2923  vmovaps [rsp+0x80], xmm9
000074b6341d292c  vmovaps [rsp+0x90], xmm10
000074b6341d2935  vmovaps [rsp+0xA0], xmm11
000074b6341d293e  vmovaps [rsp+0xB0], xmm12
000074b6341d2947  vmovaps [rsp+0xC0], xmm13
000074b6341d2950  vmovaps [rsp+0xD0], xmm14
000074b6341d2959  vmovaps [rsp+0xE0], xmm15
000074b6341d2962  sub rsp, 0x30
000074b6341d2966  movaps [rsp], xmm6
000074b6341d296a  movaps [rsp+0x10], xmm5
000074b6341d296f  movaps [rsp+0x20], xmm1
000074b6341d2974  lea rdi, [rsp]
000074b6341d2978  mov esi, 0x00
000074b6341d297d  mov rax, 0x5E1AA0A2F530
000074b6341d2987  call rax
000074b6341d2989  movaps xmm6, [rsp]
000074b6341d298d  add rsp, 0x30
000074b6341d2991  vmovaps xmm0, [rsp]
000074b6341d2996  vmovaps xmm1, [rsp+0x10]
000074b6341d299c  vmovaps xmm2, [rsp+0x20]
000074b6341d29a2  vmovaps xmm3, [rsp+0x30]
000074b6341d29a8  vmovaps xmm4, [rsp+0x40]
000074b6341d29ae  vmovaps xmm5, [rsp+0x50]
000074b6341d29b4  vmovaps xmm7, [rsp+0x60]
000074b6341d29ba  vmovaps xmm8, [rsp+0x70]
000074b6341d29c0  vmovaps xmm9, [rsp+0x80]
000074b6341d29c9  vmovaps xmm10, [rsp+0x90]
000074b6341d29d2  vmovaps xmm11, [rsp+0xA0]
000074b6341d29db  vmovaps xmm12, [rsp+0xB0]
000074b6341d29e4  vmovaps xmm13, [rsp+0xC0]
000074b6341d29ed  vmovaps xmm14, [rsp+0xD0]
000074b6341d29f6  vmovaps xmm15, [rsp+0xE0]
000074b6341d29ff  add rsp, 0xF0
000074b6341d2a06  pop r11
000074b6341d2a08  pop r10
000074b6341d2a0a  pop r9
000074b6341d2a0c  pop r8
000074b6341d2a0e  pop rsi
000074b6341d2a0f  pop rdi
000074b6341d2a10  pop rdx
000074b6341d2a11  pop rcx
000074b6341d2a12  pop rax
000074b6341d2a13  add rsp, 0x08
000074b6341d2a17  jmp 0x000074B6341CFD98
000074b6341d2a1c  sub rsp, 0x08
000074b6341d2a20  push rax
000074b6341d2a21  push rcx
000074b6341d2a22  push rdx
000074b6341d2a23  push rdi
000074b6341d2a24  push rsi
000074b6341d2a25  push r8
000074b6341d2a27  push r9
000074b6341d2a29  push r10
000074b6341d2a2b  push r11
000074b6341d2a2d  sub rsp, 0xF0
000074b6341d2a34  vmovaps [rsp], xmm0
000074b6341d2a39  vmovaps [rsp+0x10], xmm2
000074b6341d2a3f  vmovaps [rsp+0x20], xmm3
000074b6341d2a45  vmovaps [rsp+0x30], xmm4
000074b6341d2a4b  vmovaps [rsp+0x40], xmm5
000074b6341d2a51  vmovaps [rsp+0x50], xmm6
000074b6341d2a57  vmovaps [rsp+0x60], xmm7
000074b6341d2a5d  vmovaps [rsp+0x70], xmm8
000074b6341d2a63  vmovaps [rsp+0x80], xmm9
000074b6341d2a6c  vmovaps [rsp+0x90], xmm10
000074b6341d2a75  vmovaps [rsp+0xA0], xmm11
000074b6341d2a7e  vmovaps [rsp+0xB0], xmm12
000074b6341d2a87  vmovaps [rsp+0xC0], xmm13
000074b6341d2a90  vmovaps [rsp+0xD0], xmm14
000074b6341d2a99  vmovaps [rsp+0xE0], xmm15
000074b6341d2aa2  sub rsp, 0x30
000074b6341d2aa6  movaps [rsp], xmm1
000074b6341d2aaa  movaps [rsp+0x10], xmm5
000074b6341d2aaf  movaps [rsp+0x20], xmm13
000074b6341d2ab5  lea rdi, [rsp]
000074b6341d2ab9  mov esi, 0x00
000074b6341d2abe  mov rax, 0x5E1AA0A2F530
000074b6341d2ac8  call rax
000074b6341d2aca  movaps xmm1, [rsp]
000074b6341d2ace  add rsp, 0x30
000074b6341d2ad2  vmovaps xmm0, [rsp]
000074b6341d2ad7  vmovaps xmm2, [rsp+0x10]
000074b6341d2add  vmovaps xmm3, [rsp+0x20]
000074b6341d2ae3  vmovaps xmm4, [rsp+0x30]
000074b6341d2ae9  vmovaps xmm5, [rsp+0x40]
000074b6341d2aef  vmovaps xmm6, [rsp+0x50]
000074b6341d2af5  vmovaps xmm7, [rsp+0x60]
000074b6341d2afb  vmovaps xmm8, [rsp+0x70]
000074b6341d2b01  vmovaps xmm9, [rsp+0x80]
000074b6341d2b0a  vmovaps xmm10, [rsp+0x90]
000074b6341d2b13  vmovaps xmm11, [rsp+0xA0]
000074b6341d2b1c  vmovaps xmm12, [rsp+0xB0]
000074b6341d2b25  vmovaps xmm13, [rsp+0xC0]
000074b6341d2b2e  vmovaps xmm14, [rsp+0xD0]
000074b6341d2b37  vmovaps xmm15, [rsp+0xE0]
000074b6341d2b40  add rsp, 0xF0
000074b6341d2b47  pop r11
000074b6341d2b49  pop r10
000074b6341d2b4b  pop r9
000074b6341d2b4d  pop r8
000074b6341d2b4f  pop rsi
000074b6341d2b50  pop rdi
000074b6341d2b51  pop rdx
000074b6341d2b52  pop rcx
000074b6341d2b53  pop rax
000074b6341d2b54  add rsp, 0x08
000074b6341d2b58  jmp 0x000074B6341CFDB6
000074b6341d2b5d  sub rsp, 0x08
000074b6341d2b61  push rax
000074b6341d2b62  push rcx
000074b6341d2b63  push rdx
000074b6341d2b64  push rdi
000074b6341d2b65  push rsi
000074b6341d2b66  push r8
000074b6341d2b68  push r9
000074b6341d2b6a  push r10
000074b6341d2b6c  push r11
000074b6341d2b6e  sub rsp, 0xF0
000074b6341d2b75  vmovaps [rsp], xmm0
000074b6341d2b7a  vmovaps [rsp+0x10], xmm1
000074b6341d2b80  vmovaps [rsp+0x20], xmm2
000074b6341d2b86  vmovaps [rsp+0x30], xmm3
000074b6341d2b8c  vmovaps [rsp+0x40], xmm4
000074b6341d2b92  vmovaps [rsp+0x50], xmm6
000074b6341d2b98  vmovaps [rsp+0x60], xmm7
000074b6341d2b9e  vmovaps [rsp+0x70], xmm8
000074b6341d2ba4  vmovaps [rsp+0x80], xmm9
000074b6341d2bad  vmovaps [rsp+0x90], xmm10
000074b6341d2bb6  vmovaps [rsp+0xA0], xmm11
000074b6341d2bbf  vmovaps [rsp+0xB0], xmm12
000074b6341d2bc8  vmovaps [rsp+0xC0], xmm13
000074b6341d2bd1  vmovaps [rsp+0xD0], xmm14
000074b6341d2bda  vmovaps [rsp+0xE0], xmm15
000074b6341d2be3  sub rsp, 0x30
000074b6341d2be7  movaps [rsp], xmm5
000074b6341d2beb  movaps [rsp+0x10], xmm2
000074b6341d2bf0  movaps [rsp+0x20], xmm13
000074b6341d2bf6  lea rdi, [rsp]
000074b6341d2bfa  mov esi, 0x00
000074b6341d2bff  mov rax, 0x5E1AA0A2F530
000074b6341d2c09  call rax
000074b6341d2c0b  movaps xmm5, [rsp]
000074b6341d2c0f  add rsp, 0x30
000074b6341d2c13  vmovaps xmm0, [rsp]
000074b6341d2c18  vmovaps xmm1, [rsp+0x10]
000074b6341d2c1e  vmovaps xmm2, [rsp+0x20]
000074b6341d2c24  vmovaps xmm3, [rsp+0x30]
000074b6341d2c2a  vmovaps xmm4, [rsp+0x40]
000074b6341d2c30  vmovaps xmm6, [rsp+0x50]
000074b6341d2c36  vmovaps xmm7, [rsp+0x60]
000074b6341d2c3c  vmovaps xmm8, [rsp+0x70]
000074b6341d2c42  vmovaps xmm9, [rsp+0x80]
000074b6341d2c4b  vmovaps xmm10, [rsp+0x90]
000074b6341d2c54  vmovaps xmm11, [rsp+0xA0]
000074b6341d2c5d  vmovaps xmm12, [rsp+0xB0]
000074b6341d2c66  vmovaps xmm13, [rsp+0xC0]
000074b6341d2c6f  vmovaps xmm14, [rsp+0xD0]
000074b6341d2c78  vmovaps xmm15, [rsp+0xE0]
000074b6341d2c81  add rsp, 0xF0
000074b6341d2c88  pop r11
000074b6341d2c8a  pop r10
000074b6341d2c8c  pop r9
000074b6341d2c8e  pop r8
000074b6341d2c90  pop rsi
000074b6341d2c91  pop rdi
000074b6341d2c92  pop rdx
000074b6341d2c93  pop rcx
000074b6341d2c94  pop rax
000074b6341d2c95  add rsp, 0x08
000074b6341d2c99  jmp 0x000074B6341CFDEC
000074b6341d2c9e  sub rsp, 0x08
000074b6341d2ca2  push rax
000074b6341d2ca3  push rcx
000074b6341d2ca4  push rdx
000074b6341d2ca5  push rdi
000074b6341d2ca6  push rsi
000074b6341d2ca7  push r8
000074b6341d2ca9  push r9
000074b6341d2cab  push r10
000074b6341d2cad  push r11
000074b6341d2caf  sub rsp, 0xF0
000074b6341d2cb6  vmovaps [rsp], xmm0
000074b6341d2cbb  vmovaps [rsp+0x10], xmm1
000074b6341d2cc1  vmovaps [rsp+0x20], xmm2
000074b6341d2cc7  vmovaps [rsp+0x30], xmm3
000074b6341d2ccd  vmovaps [rsp+0x40], xmm4
000074b6341d2cd3  vmovaps [rsp+0x50], xmm5
000074b6341d2cd9  vmovaps [rsp+0x60], xmm6
000074b6341d2cdf  vmovaps [rsp+0x70], xmm7
000074b6341d2ce5  vmovaps [rsp+0x80], xmm8
000074b6341d2cee  vmovaps [rsp+0x90], xmm9
000074b6341d2cf7  vmovaps [rsp+0xA0], xmm10
000074b6341d2d00  vmovaps [rsp+0xB0], xmm11
000074b6341d2d09  vmovaps [rsp+0xC0], xmm12
000074b6341d2d12  vmovaps [rsp+0xD0], xmm14
000074b6341d2d1b  vmovaps [rsp+0xE0], xmm15
000074b6341d2d24  sub rsp, 0x30
000074b6341d2d28  movaps [rsp], xmm13
000074b6341d2d2d  movaps [rsp+0x10], xmm10
000074b6341d2d33  movaps [rsp+0x20], xmm1
000074b6341d2d38  lea rdi, [rsp]
000074b6341d2d3c  mov esi, 0x00
000074b6341d2d41  mov rax, 0x5E1AA0A2F530
000074b6341d2d4b  call rax
000074b6341d2d4d  movaps xmm13, [rsp]
000074b6341d2d52  add rsp, 0x30
000074b6341d2d56  vmovaps xmm0, [rsp]
000074b6341d2d5b  vmovaps xmm1, [rsp+0x10]
000074b6341d2d61  vmovaps xmm2, [rsp+0x20]
000074b6341d2d67  vmovaps xmm3, [rsp+0x30]
000074b6341d2d6d  vmovaps xmm4, [rsp+0x40]
000074b6341d2d73  vmovaps xmm5, [rsp+0x50]
000074b6341d2d79  vmovaps xmm6, [rsp+0x60]
000074b6341d2d7f  vmovaps xmm7, [rsp+0x70]
000074b6341d2d85  vmovaps xmm8, [rsp+0x80]
000074b6341d2d8e  vmovaps xmm9, [rsp+0x90]
000074b6341d2d97  vmovaps xmm10, [rsp+0xA0]
000074b6341d2da0  vmovaps xmm11, [rsp+0xB0]
000074b6341d2da9  vmovaps xmm12, [rsp+0xC0]
000074b6341d2db2  vmovaps xmm14, [rsp+0xD0]
000074b6341d2dbb  vmovaps xmm15, [rsp+0xE0]
000074b6341d2dc4  add rsp, 0xF0
000074b6341d2dcb  pop r11
000074b6341d2dcd  pop r10
000074b6341d2dcf  pop r9
000074b6341d2dd1  pop r8
000074b6341d2dd3  pop rsi
000074b6341d2dd4  pop rdi
000074b6341d2dd5  pop rdx
000074b6341d2dd6  pop rcx
000074b6341d2dd7  pop rax
000074b6341d2dd8  add rsp, 0x08
000074b6341d2ddc  jmp 0x000074B6341CFE15
000074b6341d2de1  sub rsp, 0x08
000074b6341d2de5  push rax
000074b6341d2de6  push rcx
000074b6341d2de7  push rdx
000074b6341d2de8  push rdi
000074b6341d2de9  push rsi
000074b6341d2dea  push r8
000074b6341d2dec  push r9
000074b6341d2dee  push r10
000074b6341d2df0  push r11
000074b6341d2df2  sub rsp, 0xF0
000074b6341d2df9  vmovaps [rsp], xmm0
000074b6341d2dfe  vmovaps [rsp+0x10], xmm2
000074b6341d2e04  vmovaps [rsp+0x20], xmm3
000074b6341d2e0a  vmovaps [rsp+0x30], xmm4
000074b6341d2e10  vmovaps [rsp+0x40], xmm5
000074b6341d2e16  vmovaps [rsp+0x50], xmm6
000074b6341d2e1c  vmovaps [rsp+0x60], xmm7
000074b6341d2e22  vmovaps [rsp+0x70], xmm8
000074b6341d2e28  vmovaps [rsp+0x80], xmm9
000074b6341d2e31  vmovaps [rsp+0x90], xmm10
000074b6341d2e3a  vmovaps [rsp+0xA0], xmm11
000074b6341d2e43  vmovaps [rsp+0xB0], xmm12
000074b6341d2e4c  vmovaps [rsp+0xC0], xmm13
000074b6341d2e55  vmovaps [rsp+0xD0], xmm14
000074b6341d2e5e  vmovaps [rsp+0xE0], xmm15
000074b6341d2e67  sub rsp, 0x30
000074b6341d2e6b  movaps [rsp], xmm1
000074b6341d2e6f  movaps [rsp+0x10], xmm15
000074b6341d2e75  movaps [rsp+0x20], xmm10
000074b6341d2e7b  lea rdi, [rsp]
000074b6341d2e7f  mov esi, 0x00
000074b6341d2e84  mov rax, 0x5E1AA0A2F530
000074b6341d2e8e  call rax
000074b6341d2e90  movaps xmm1, [rsp]
000074b6341d2e94  add rsp, 0x30
000074b6341d2e98  vmovaps xmm0, [rsp]
000074b6341d2e9d  vmovaps xmm2, [rsp+0x10]
000074b6341d2ea3  vmovaps xmm3, [rsp+0x20]
000074b6341d2ea9  vmovaps xmm4, [rsp+0x30]
000074b6341d2eaf  vmovaps xmm5, [rsp+0x40]
000074b6341d2eb5  vmovaps xmm6, [rsp+0x50]
000074b6341d2ebb  vmovaps xmm7, [rsp+0x60]
000074b6341d2ec1  vmovaps xmm8, [rsp+0x70]
000074b6341d2ec7  vmovaps xmm9, [rsp+0x80]
000074b6341d2ed0  vmovaps xmm10, [rsp+0x90]
000074b6341d2ed9  vmovaps xmm11, [rsp+0xA0]
000074b6341d2ee2  vmovaps xmm12, [rsp+0xB0]
000074b6341d2eeb  vmovaps xmm13, [rsp+0xC0]
000074b6341d2ef4  vmovaps xmm14, [rsp+0xD0]
000074b6341d2efd  vmovaps xmm15, [rsp+0xE0]
000074b6341d2f06  add rsp, 0xF0
000074b6341d2f0d  pop r11
000074b6341d2f0f  pop r10
000074b6341d2f11  pop r9
000074b6341d2f13  pop r8
000074b6341d2f15  pop rsi
000074b6341d2f16  pop rdi
000074b6341d2f17  pop rdx
000074b6341d2f18  pop rcx
000074b6341d2f19  pop rax
000074b6341d2f1a  add rsp, 0x08
000074b6341d2f1e  jmp 0x000074B6341CFE34
000074b6341d2f23  sub rsp, 0x08
000074b6341d2f27  push rax
000074b6341d2f28  push rcx
000074b6341d2f29  push rdx
000074b6341d2f2a  push rdi
000074b6341d2f2b  push rsi
000074b6341d2f2c  push r8
000074b6341d2f2e  push r9
000074b6341d2f30  push r10
000074b6341d2f32  push r11
000074b6341d2f34  sub rsp, 0xF0
000074b6341d2f3b  vmovaps [rsp], xmm0
000074b6341d2f40  vmovaps [rsp+0x10], xmm1
000074b6341d2f46  vmovaps [rsp+0x20], xmm2
000074b6341d2f4c  vmovaps [rsp+0x30], xmm3
000074b6341d2f52  vmovaps [rsp+0x40], xmm4
000074b6341d2f58  vmovaps [rsp+0x50], xmm5
000074b6341d2f5e  vmovaps [rsp+0x60], xmm6
000074b6341d2f64  vmovaps [rsp+0x70], xmm7
000074b6341d2f6a  vmovaps [rsp+0x80], xmm8
000074b6341d2f73  vmovaps [rsp+0x90], xmm9
000074b6341d2f7c  vmovaps [rsp+0xA0], xmm10
000074b6341d2f85  vmovaps [rsp+0xB0], xmm11
000074b6341d2f8e  vmovaps [rsp+0xC0], xmm12
000074b6341d2f97  vmovaps [rsp+0xD0], xmm13
000074b6341d2fa0  vmovaps [rsp+0xE0], xmm14
000074b6341d2fa9  sub rsp, 0x30
000074b6341d2fad  movaps [rsp], xmm15
000074b6341d2fb2  movaps [rsp+0x10], xmm10
000074b6341d2fb8  movaps [rsp+0x20], xmm11
000074b6341d2fbe  lea rdi, [rsp]
000074b6341d2fc2  mov esi, 0x00
000074b6341d2fc7  mov rax, 0x5E1AA0A2F530
000074b6341d2fd1  call rax
000074b6341d2fd3  movaps xmm15, [rsp]
000074b6341d2fd8  add rsp, 0x30
000074b6341d2fdc  vmovaps xmm0, [rsp]
000074b6341d2fe1  vmovaps xmm1, [rsp+0x10]
000074b6341d2fe7  vmovaps xmm2, [rsp+0x20]
000074b6341d2fed  vmovaps xmm3, [rsp+0x30]
000074b6341d2ff3  vmovaps xmm4, [rsp+0x40]
000074b6341d2ff9  vmovaps xmm5, [rsp+0x50]
000074b6341d2fff  vmovaps xmm6, [rsp+0x60]
000074b6341d3005  vmovaps xmm7, [rsp+0x70]
000074b6341d300b  vmovaps xmm8, [rsp+0x80]
000074b6341d3014  vmovaps xmm9, [rsp+0x90]
000074b6341d301d  vmovaps xmm10, [rsp+0xA0]
000074b6341d3026  vmovaps xmm11, [rsp+0xB0]
000074b6341d302f  vmovaps xmm12, [rsp+0xC0]
000074b6341d3038  vmovaps xmm13, [rsp+0xD0]
000074b6341d3041  vmovaps xmm14, [rsp+0xE0]
000074b6341d304a  add rsp, 0xF0
000074b6341d3051  pop r11
000074b6341d3053  pop r10
000074b6341d3055  pop r9
000074b6341d3057  pop r8
000074b6341d3059  pop rsi
000074b6341d305a  pop rdi
000074b6341d305b  pop rdx
000074b6341d305c  pop rcx
000074b6341d305d  pop rax
000074b6341d305e  add rsp, 0x08
000074b6341d3062  jmp 0x000074B6341CFE57
000074b6341d3067  sub rsp, 0x08
000074b6341d306b  push rax
000074b6341d306c  push rcx
000074b6341d306d  push rdx
000074b6341d306e  push rdi
000074b6341d306f  push rsi
000074b6341d3070  push r8
000074b6341d3072  push r9
000074b6341d3074  push r10
000074b6341d3076  push r11
000074b6341d3078  sub rsp, 0xF0
000074b6341d307f  vmovaps [rsp], xmm0
000074b6341d3084  vmovaps [rsp+0x10], xmm1
000074b6341d308a  vmovaps [rsp+0x20], xmm2
000074b6341d3090  vmovaps [rsp+0x30], xmm3
000074b6341d3096  vmovaps [rsp+0x40], xmm4
000074b6341d309c  vmovaps [rsp+0x50], xmm5
000074b6341d30a2  vmovaps [rsp+0x60], xmm6
000074b6341d30a8  vmovaps [rsp+0x70], xmm7
000074b6341d30ae  vmovaps [rsp+0x80], xmm8
000074b6341d30b7  vmovaps [rsp+0x90], xmm9
000074b6341d30c0  vmovaps [rsp+0xA0], xmm11
000074b6341d30c9  vmovaps [rsp+0xB0], xmm12
000074b6341d30d2  vmovaps [rsp+0xC0], xmm13
000074b6341d30db  vmovaps [rsp+0xD0], xmm14
000074b6341d30e4  vmovaps [rsp+0xE0], xmm15
000074b6341d30ed  sub rsp, 0x30
000074b6341d30f1  movaps [rsp], xmm10
000074b6341d30f6  movaps [rsp+0x10], xmm12
000074b6341d30fc  movaps [rsp+0x20], xmm11
000074b6341d3102  lea rdi, [rsp]
000074b6341d3106  mov esi, 0x00
000074b6341d310b  mov rax, 0x5E1AA0A2F530
000074b6341d3115  call rax
000074b6341d3117  movaps xmm10, [rsp]
000074b6341d311c  add rsp, 0x30
000074b6341d3120  vmovaps xmm0, [rsp]
000074b6341d3125  vmovaps xmm1, [rsp+0x10]
000074b6341d312b  vmovaps xmm2, [rsp+0x20]
000074b6341d3131  vmovaps xmm3, [rsp+0x30]
000074b6341d3137  vmovaps xmm4, [rsp+0x40]
000074b6341d313d  vmovaps xmm5, [rsp+0x50]
000074b6341d3143  vmovaps xmm6, [rsp+0x60]
000074b6341d3149  vmovaps xmm7, [rsp+0x70]
000074b6341d314f  vmovaps xmm8, [rsp+0x80]
000074b6341d3158  vmovaps xmm9, [rsp+0x90]
000074b6341d3161  vmovaps xmm11, [rsp+0xA0]
000074b6341d316a  vmovaps xmm12, [rsp+0xB0]
000074b6341d3173  vmovaps xmm13, [rsp+0xC0]
000074b6341d317c  vmovaps xmm14, [rsp+0xD0]
000074b6341d3185  vmovaps xmm15, [rsp+0xE0]
000074b6341d318e  add rsp, 0xF0
000074b6341d3195  pop r11
000074b6341d3197  pop r10
000074b6341d3199  pop r9
000074b6341d319b  pop r8
000074b6341d319d  pop rsi
000074b6341d319e  pop rdi
000074b6341d319f  pop rdx
000074b6341d31a0  pop rcx
000074b6341d31a1  pop rax
000074b6341d31a2  add rsp, 0x08
000074b6341d31a6  jmp 0x000074B6341CFE80
000074b6341d31ab  sub rsp, 0x08
000074b6341d31af  push rax
000074b6341d31b0  push rcx
000074b6341d31b1  push rdx
000074b6341d31b2  push rdi
000074b6341d31b3  push rsi
000074b6341d31b4  push r8
000074b6341d31b6  push r9
000074b6341d31b8  push r10
000074b6341d31ba  push r11
000074b6341d31bc  sub rsp, 0xF0
000074b6341d31c3  vmovaps [rsp], xmm0
000074b6341d31c8  vmovaps [rsp+0x10], xmm1
000074b6341d31ce  vmovaps [rsp+0x20], xmm2
000074b6341d31d4  vmovaps [rsp+0x30], xmm3
000074b6341d31da  vmovaps [rsp+0x40], xmm4
000074b6341d31e0  vmovaps [rsp+0x50], xmm5
000074b6341d31e6  vmovaps [rsp+0x60], xmm6
000074b6341d31ec  vmovaps [rsp+0x70], xmm7
000074b6341d31f2  vmovaps [rsp+0x80], xmm8
000074b6341d31fb  vmovaps [rsp+0x90], xmm9
000074b6341d3204  vmovaps [rsp+0xA0], xmm10
000074b6341d320d  vmovaps [rsp+0xB0], xmm12
000074b6341d3216  vmovaps [rsp+0xC0], xmm13
000074b6341d321f  vmovaps [rsp+0xD0], xmm14
000074b6341d3228  vmovaps [rsp+0xE0], xmm15
000074b6341d3231  sub rsp, 0x30
000074b6341d3235  movaps [rsp], xmm11
000074b6341d323a  movaps [rsp+0x10], xmm2
000074b6341d323f  movaps [rsp+0x20], xmm12
000074b6341d3245  lea rdi, [rsp]
000074b6341d3249  mov esi, 0x00
000074b6341d324e  mov rax, 0x5E1AA0A2F530
000074b6341d3258  call rax
000074b6341d325a  movaps xmm11, [rsp]
000074b6341d325f  add rsp, 0x30
000074b6341d3263  vmovaps xmm0, [rsp]
000074b6341d3268  vmovaps xmm1, [rsp+0x10]
000074b6341d326e  vmovaps xmm2, [rsp+0x20]
000074b6341d3274  vmovaps xmm3, [rsp+0x30]
000074b6341d327a  vmovaps xmm4, [rsp+0x40]
000074b6341d3280  vmovaps xmm5, [rsp+0x50]
000074b6341d3286  vmovaps xmm6, [rsp+0x60]
000074b6341d328c  vmovaps xmm7, [rsp+0x70]
000074b6341d3292  vmovaps xmm8, [rsp+0x80]
000074b6341d329b  vmovaps xmm9, [rsp+0x90]
000074b6341d32a4  vmovaps xmm10, [rsp+0xA0]
000074b6341d32ad  vmovaps xmm12, [rsp+0xB0]
000074b6341d32b6  vmovaps xmm13, [rsp+0xC0]
000074b6341d32bf  vmovaps xmm14, [rsp+0xD0]
000074b6341d32c8  vmovaps xmm15, [rsp+0xE0]
000074b6341d32d1  add rsp, 0xF0
000074b6341d32d8  pop r11
000074b6341d32da  pop r10
000074b6341d32dc  pop r9
000074b6341d32de  pop r8
000074b6341d32e0  pop rsi
000074b6341d32e1  pop rdi
000074b6341d32e2  pop rdx
000074b6341d32e3  pop rcx
000074b6341d32e4  pop rax
000074b6341d32e5  add rsp, 0x08
000074b6341d32e9  jmp 0x000074B6341CFEB8
000074b6341d32ee  sub rsp, 0x08
000074b6341d32f2  push rax
000074b6341d32f3  push rcx
000074b6341d32f4  push rdx
000074b6341d32f5  push rdi
000074b6341d32f6  push rsi
000074b6341d32f7  push r8
000074b6341d32f9  push r9
000074b6341d32fb  push r10
000074b6341d32fd  push r11
000074b6341d32ff  sub rsp, 0xF0
000074b6341d3306  vmovaps [rsp], xmm0
000074b6341d330b  vmovaps [rsp+0x10], xmm2
000074b6341d3311  vmovaps [rsp+0x20], xmm3
000074b6341d3317  vmovaps [rsp+0x30], xmm4
000074b6341d331d  vmovaps [rsp+0x40], xmm5
000074b6341d3323  vmovaps [rsp+0x50], xmm6
000074b6341d3329  vmovaps [rsp+0x60], xmm7
000074b6341d332f  vmovaps [rsp+0x70], xmm8
000074b6341d3335  vmovaps [rsp+0x80], xmm9
000074b6341d333e  vmovaps [rsp+0x90], xmm10
000074b6341d3347  vmovaps [rsp+0xA0], xmm11
000074b6341d3350  vmovaps [rsp+0xB0], xmm12
000074b6341d3359  vmovaps [rsp+0xC0], xmm13
000074b6341d3362  vmovaps [rsp+0xD0], xmm14
000074b6341d336b  vmovaps [rsp+0xE0], xmm15
000074b6341d3374  sub rsp, 0x30
000074b6341d3378  movaps [rsp], xmm1
000074b6341d337c  movaps [rsp+0x10], xmm14
000074b6341d3382  movaps [rsp+0x20], xmm6
000074b6341d3387  lea rdi, [rsp]
000074b6341d338b  mov esi, 0x00
000074b6341d3390  mov rax, 0x5E1AA0A2F530
000074b6341d339a  call rax
000074b6341d339c  movaps xmm1, [rsp]
000074b6341d33a0  add rsp, 0x30
000074b6341d33a4  vmovaps xmm0, [rsp]
000074b6341d33a9  vmovaps xmm2, [rsp+0x10]
000074b6341d33af  vmovaps xmm3, [rsp+0x20]
000074b6341d33b5  vmovaps xmm4, [rsp+0x30]
000074b6341d33bb  vmovaps xmm5, [rsp+0x40]
000074b6341d33c1  vmovaps xmm6, [rsp+0x50]
000074b6341d33c7  vmovaps xmm7, [rsp+0x60]
000074b6341d33cd  vmovaps xmm8, [rsp+0x70]
000074b6341d33d3  vmovaps xmm9, [rsp+0x80]
000074b6341d33dc  vmovaps xmm10, [rsp+0x90]
000074b6341d33e5  vmovaps xmm11, [rsp+0xA0]
000074b6341d33ee  vmovaps xmm12, [rsp+0xB0]
000074b6341d33f7  vmovaps xmm13, [rsp+0xC0]
000074b6341d3400  vmovaps xmm14, [rsp+0xD0]
000074b6341d3409  vmovaps xmm15, [rsp+0xE0]
000074b6341d3412  add rsp, 0xF0
000074b6341d3419  pop r11
000074b6341d341b  pop r10
000074b6341d341d  pop r9
000074b6341d341f  pop r8
000074b6341d3421  pop rsi
000074b6341d3422  pop rdi
000074b6341d3423  pop rdx
000074b6341d3424  pop rcx
000074b6341d3425  pop rax
000074b6341d3426  add rsp, 0x08
000074b6341d342a  jmp 0x000074B6341CFED1
000074b6341d342f  sub rsp, 0x08
000074b6341d3433  push rax
000074b6341d3434  push rcx
000074b6341d3435  push rdx
000074b6341d3436  push rdi
000074b6341d3437  push rsi
000074b6341d3438  push r8
000074b6341d343a  push r9
000074b6341d343c  push r10
000074b6341d343e  push r11
000074b6341d3440  sub rsp, 0xF0
000074b6341d3447  vmovaps [rsp], xmm0
000074b6341d344c  vmovaps [rsp+0x10], xmm1
000074b6341d3452  vmovaps [rsp+0x20], xmm2
000074b6341d3458  vmovaps [rsp+0x30], xmm3
000074b6341d345e  vmovaps [rsp+0x40], xmm4
000074b6341d3464  vmovaps [rsp+0x50], xmm5
000074b6341d346a  vmovaps [rsp+0x60], xmm6
000074b6341d3470  vmovaps [rsp+0x70], xmm7
000074b6341d3476  vmovaps [rsp+0x80], xmm8
000074b6341d347f  vmovaps [rsp+0x90], xmm9
000074b6341d3488  vmovaps [rsp+0xA0], xmm10
000074b6341d3491  vmovaps [rsp+0xB0], xmm11
000074b6341d349a  vmovaps [rsp+0xC0], xmm12
000074b6341d34a3  vmovaps [rsp+0xD0], xmm13
000074b6341d34ac  vmovaps [rsp+0xE0], xmm15
000074b6341d34b5  sub rsp, 0x30
000074b6341d34b9  movaps [rsp], xmm14
000074b6341d34be  movaps [rsp+0x10], xmm12
000074b6341d34c4  movaps [rsp+0x20], xmm5
000074b6341d34c9  lea rdi, [rsp]
000074b6341d34cd  mov esi, 0x00
000074b6341d34d2  mov rax, 0x5E1AA0A2F530
000074b6341d34dc  call rax
000074b6341d34de  movaps xmm14, [rsp]
000074b6341d34e3  add rsp, 0x30
000074b6341d34e7  vmovaps xmm0, [rsp]
000074b6341d34ec  vmovaps xmm1, [rsp+0x10]
000074b6341d34f2  vmovaps xmm2, [rsp+0x20]
000074b6341d34f8  vmovaps xmm3, [rsp+0x30]
000074b6341d34fe  vmovaps xmm4, [rsp+0x40]
000074b6341d3504  vmovaps xmm5, [rsp+0x50]
000074b6341d350a  vmovaps xmm6, [rsp+0x60]
000074b6341d3510  vmovaps xmm7, [rsp+0x70]
000074b6341d3516  vmovaps xmm8, [rsp+0x80]
000074b6341d351f  vmovaps xmm9, [rsp+0x90]
000074b6341d3528  vmovaps xmm10, [rsp+0xA0]
000074b6341d3531  vmovaps xmm11, [rsp+0xB0]
000074b6341d353a  vmovaps xmm12, [rsp+0xC0]
000074b6341d3543  vmovaps xmm13, [rsp+0xD0]
000074b6341d354c  vmovaps xmm15, [rsp+0xE0]
000074b6341d3555  add rsp, 0xF0
000074b6341d355c  pop r11
000074b6341d355e  pop r10
000074b6341d3560  pop r9
000074b6341d3562  pop r8
000074b6341d3564  pop rsi
000074b6341d3565  pop rdi
000074b6341d3566  pop rdx
000074b6341d3567  pop rcx
000074b6341d3568  pop rax
000074b6341d3569  add rsp, 0x08
000074b6341d356d  jmp 0x000074B6341CFEF1
000074b6341d3572  sub rsp, 0x08
000074b6341d3576  push rax
000074b6341d3577  push rcx
000074b6341d3578  push rdx
000074b6341d3579  push rdi
000074b6341d357a  push rsi
000074b6341d357b  push r8
000074b6341d357d  push r9
000074b6341d357f  push r10
000074b6341d3581  push r11
000074b6341d3583  sub rsp, 0xF0
000074b6341d358a  vmovaps [rsp], xmm0
000074b6341d358f  vmovaps [rsp+0x10], xmm1
000074b6341d3595  vmovaps [rsp+0x20], xmm2
000074b6341d359b  vmovaps [rsp+0x30], xmm3
000074b6341d35a1  vmovaps [rsp+0x40], xmm4
000074b6341d35a7  vmovaps [rsp+0x50], xmm5
000074b6341d35ad  vmovaps [rsp+0x60], xmm7
000074b6341d35b3  vmovaps [rsp+0x70], xmm8
000074b6341d35b9  vmovaps [rsp+0x80], xmm9
000074b6341d35c2  vmovaps [rsp+0x90], xmm10
000074b6341d35cb  vmovaps [rsp+0xA0], xmm11
000074b6341d35d4  vmovaps [rsp+0xB0], xmm12
000074b6341d35dd  vmovaps [rsp+0xC0], xmm13
000074b6341d35e6  vmovaps [rsp+0xD0], xmm14
000074b6341d35ef  vmovaps [rsp+0xE0], xmm15
000074b6341d35f8  sub rsp, 0x30
000074b6341d35fc  movaps [rsp], xmm6
000074b6341d3600  movaps [rsp+0x10], xmm9
000074b6341d3606  movaps [rsp+0x20], xmm12
000074b6341d360c  lea rdi, [rsp]
000074b6341d3610  mov esi, 0x00
000074b6341d3615  mov rax, 0x5E1AA0A2F530
000074b6341d361f  call rax
000074b6341d3621  movaps xmm6, [rsp]
000074b6341d3625  add rsp, 0x30
000074b6341d3629  vmovaps xmm0, [rsp]
000074b6341d362e  vmovaps xmm1, [rsp+0x10]
000074b6341d3634  vmovaps xmm2, [rsp+0x20]
000074b6341d363a  vmovaps xmm3, [rsp+0x30]
000074b6341d3640  vmovaps xmm4, [rsp+0x40]
000074b6341d3646  vmovaps xmm5, [rsp+0x50]
000074b6341d364c  vmovaps xmm7, [rsp+0x60]
000074b6341d3652  vmovaps xmm8, [rsp+0x70]
000074b6341d3658  vmovaps xmm9, [rsp+0x80]
000074b6341d3661  vmovaps xmm10, [rsp+0x90]
000074b6341d366a  vmovaps xmm11, [rsp+0xA0]
000074b6341d3673  vmovaps xmm12, [rsp+0xB0]
000074b6341d367c  vmovaps xmm13, [rsp+0xC0]
000074b6341d3685  vmovaps xmm14, [rsp+0xD0]
000074b6341d368e  vmovaps xmm15, [rsp+0xE0]
000074b6341d3697  add rsp, 0xF0
000074b6341d369e  pop r11
000074b6341d36a0  pop r10
000074b6341d36a2  pop r9
000074b6341d36a4  pop r8
000074b6341d36a6  pop rsi
000074b6341d36a7  pop rdi
000074b6341d36a8  pop rdx
000074b6341d36a9  pop rcx
000074b6341d36aa  pop rax
000074b6341d36ab  add rsp, 0x08
000074b6341d36af  jmp 0x000074B6341CFF19
000074b6341d36b4  sub rsp, 0x08
000074b6341d36b8  push rax
000074b6341d36b9  push rcx
000074b6341d36ba  push rdx
000074b6341d36bb  push rdi
000074b6341d36bc  push rsi
000074b6341d36bd  push r8
000074b6341d36bf  push r9
000074b6341d36c1  push r10
000074b6341d36c3  push r11
000074b6341d36c5  sub rsp, 0xF0
000074b6341d36cc  vmovaps [rsp], xmm0
000074b6341d36d1  vmovaps [rsp+0x10], xmm1
000074b6341d36d7  vmovaps [rsp+0x20], xmm2
000074b6341d36dd  vmovaps [rsp+0x30], xmm3
000074b6341d36e3  vmovaps [rsp+0x40], xmm4
000074b6341d36e9  vmovaps [rsp+0x50], xmm5
000074b6341d36ef  vmovaps [rsp+0x60], xmm6
000074b6341d36f5  vmovaps [rsp+0x70], xmm7
000074b6341d36fb  vmovaps [rsp+0x80], xmm8
000074b6341d3704  vmovaps [rsp+0x90], xmm9
000074b6341d370d  vmovaps [rsp+0xA0], xmm10
000074b6341d3716  vmovaps [rsp+0xB0], xmm11
000074b6341d371f  vmovaps [rsp+0xC0], xmm13
000074b6341d3728  vmovaps [rsp+0xD0], xmm14
000074b6341d3731  vmovaps [rsp+0xE0], xmm15
000074b6341d373a  sub rsp, 0x30
000074b6341d373e  movaps [rsp], xmm12
000074b6341d3743  movaps [rsp+0x10], xmm15
000074b6341d3749  movaps [rsp+0x20], xmm13
000074b6341d374f  lea rdi, [rsp]
000074b6341d3753  mov esi, 0x00
000074b6341d3758  mov rax, 0x5E1AA0A2F530
000074b6341d3762  call rax
000074b6341d3764  movaps xmm12, [rsp]
000074b6341d3769  add rsp, 0x30
000074b6341d376d  vmovaps xmm0, [rsp]
000074b6341d3772  vmovaps xmm1, [rsp+0x10]
000074b6341d3778  vmovaps xmm2, [rsp+0x20]
000074b6341d377e  vmovaps xmm3, [rsp+0x30]
000074b6341d3784  vmovaps xmm4, [rsp+0x40]
000074b6341d378a  vmovaps xmm5, [rsp+0x50]
000074b6341d3790  vmovaps xmm6, [rsp+0x60]
000074b6341d3796  vmovaps xmm7, [rsp+0x70]
000074b6341d379c  vmovaps xmm8, [rsp+0x80]
000074b6341d37a5  vmovaps xmm9, [rsp+0x90]
000074b6341d37ae  vmovaps xmm10, [rsp+0xA0]
000074b6341d37b7  vmovaps xmm11, [rsp+0xB0]
000074b6341d37c0  vmovaps xmm13, [rsp+0xC0]
000074b6341d37c9  vmovaps xmm14, [rsp+0xD0]
000074b6341d37d2  vmovaps xmm15, [rsp+0xE0]
000074b6341d37db  add rsp, 0xF0
000074b6341d37e2  pop r11
000074b6341d37e4  pop r10
000074b6341d37e6  pop r9
000074b6341d37e8  pop r8
000074b6341d37ea  pop rsi
000074b6341d37eb  pop rdi
000074b6341d37ec  pop rdx
000074b6341d37ed  pop rcx
000074b6341d37ee  pop rax
000074b6341d37ef  add rsp, 0x08
000074b6341d37f3  jmp 0x000074B6341CFF34
000074b6341d37f8  sub rsp, 0x08
000074b6341d37fc  push rax
000074b6341d37fd  push rcx
000074b6341d37fe  push rdx
000074b6341d37ff  push rdi
000074b6341d3800  push rsi
000074b6341d3801  push r8
000074b6341d3803  push r9
000074b6341d3805  push r10
000074b6341d3807  push r11
000074b6341d3809  sub rsp, 0xF0
000074b6341d3810  vmovaps [rsp], xmm0
000074b6341d3815  vmovaps [rsp+0x10], xmm1
000074b6341d381b  vmovaps [rsp+0x20], xmm2
000074b6341d3821  vmovaps [rsp+0x30], xmm3
000074b6341d3827  vmovaps [rsp+0x40], xmm4
000074b6341d382d  vmovaps [rsp+0x50], xmm5
000074b6341d3833  vmovaps [rsp+0x60], xmm6
000074b6341d3839  vmovaps [rsp+0x70], xmm7
000074b6341d383f  vmovaps [rsp+0x80], xmm8
000074b6341d3848  vmovaps [rsp+0x90], xmm9
000074b6341d3851  vmovaps [rsp+0xA0], xmm10
000074b6341d385a  vmovaps [rsp+0xB0], xmm11
000074b6341d3863  vmovaps [rsp+0xC0], xmm12
000074b6341d386c  vmovaps [rsp+0xD0], xmm13
000074b6341d3875  vmovaps [rsp+0xE0], xmm14
000074b6341d387e  sub rsp, 0x30
000074b6341d3882  movaps [rsp], xmm15
000074b6341d3887  movaps [rsp+0x10], xmm13
000074b6341d388d  movaps [rsp+0x20], xmm10
000074b6341d3893  lea rdi, [rsp]
000074b6341d3897  mov esi, 0x00
000074b6341d389c  mov rax, 0x5E1AA0A2F530
000074b6341d38a6  call rax
000074b6341d38a8  movaps xmm15, [rsp]
000074b6341d38ad  add rsp, 0x30
000074b6341d38b1  vmovaps xmm0, [rsp]
000074b6341d38b6  vmovaps xmm1, [rsp+0x10]
000074b6341d38bc  vmovaps xmm2, [rsp+0x20]
000074b6341d38c2  vmovaps xmm3, [rsp+0x30]
000074b6341d38c8  vmovaps xmm4, [rsp+0x40]
000074b6341d38ce  vmovaps xmm5, [rsp+0x50]
000074b6341d38d4  vmovaps xmm6, [rsp+0x60]
000074b6341d38da  vmovaps xmm7, [rsp+0x70]
000074b6341d38e0  vmovaps xmm8, [rsp+0x80]
000074b6341d38e9  vmovaps xmm9, [rsp+0x90]
000074b6341d38f2  vmovaps xmm10, [rsp+0xA0]
000074b6341d38fb  vmovaps xmm11, [rsp+0xB0]
000074b6341d3904  vmovaps xmm12, [rsp+0xC0]
000074b6341d390d  vmovaps xmm13, [rsp+0xD0]
000074b6341d3916  vmovaps xmm14, [rsp+0xE0]
000074b6341d391f  add rsp, 0xF0
000074b6341d3926  pop r11
000074b6341d3928  pop r10
000074b6341d392a  pop r9
000074b6341d392c  pop r8
000074b6341d392e  pop rsi
000074b6341d392f  pop rdi
000074b6341d3930  pop rdx
000074b6341d3931  pop rcx
000074b6341d3932  pop rax
000074b6341d3933  add rsp, 0x08
000074b6341d3937  jmp 0x000074B6341CFF55
000074b6341d393c  call 0x000074B63400C260
000074b6341d3941  jmp 0x000074B6341CFFB0
000074b6341d3946  sub rsp, 0x08
000074b6341d394a  push rax
000074b6341d394b  push rcx
000074b6341d394c  push rdx
000074b6341d394d  push rdi
000074b6341d394e  push rsi
000074b6341d394f  push r8
000074b6341d3951  push r9
000074b6341d3953  push r10
000074b6341d3955  push r11
000074b6341d3957  sub rsp, 0xF0
000074b6341d395e  vmovaps [rsp], xmm0
000074b6341d3963  vmovaps [rsp+0x10], xmm1
000074b6341d3969  vmovaps [rsp+0x20], xmm2
000074b6341d396f  vmovaps [rsp+0x30], xmm3
000074b6341d3975  vmovaps [rsp+0x40], xmm4
000074b6341d397b  vmovaps [rsp+0x50], xmm5
000074b6341d3981  vmovaps [rsp+0x60], xmm6
000074b6341d3987  vmovaps [rsp+0x70], xmm7
000074b6341d398d  vmovaps [rsp+0x80], xmm8
000074b6341d3996  vmovaps [rsp+0x90], xmm10
000074b6341d399f  vmovaps [rsp+0xA0], xmm11
000074b6341d39a8  vmovaps [rsp+0xB0], xmm12
000074b6341d39b1  vmovaps [rsp+0xC0], xmm13
000074b6341d39ba  vmovaps [rsp+0xD0], xmm14
000074b6341d39c3  vmovaps [rsp+0xE0], xmm15
000074b6341d39cc  sub rsp, 0x30
000074b6341d39d0  movaps [rsp], xmm9
000074b6341d39d5  movaps [rsp+0x10], xmm8
000074b6341d39db  movaps [rsp+0x20], xmm10
000074b6341d39e1  lea rdi, [rsp]
000074b6341d39e5  mov esi, 0x00
000074b6341d39ea  mov rax, 0x5E1AA0A2F530
000074b6341d39f4  call rax
000074b6341d39f6  movaps xmm9, [rsp]
000074b6341d39fb  add rsp, 0x30
000074b6341d39ff  vmovaps xmm0, [rsp]
000074b6341d3a04  vmovaps xmm1, [rsp+0x10]
000074b6341d3a0a  vmovaps xmm2, [rsp+0x20]
000074b6341d3a10  vmovaps xmm3, [rsp+0x30]
000074b6341d3a16  vmovaps xmm4, [rsp+0x40]
000074b6341d3a1c  vmovaps xmm5, [rsp+0x50]
000074b6341d3a22  vmovaps xmm6, [rsp+0x60]
000074b6341d3a28  vmovaps xmm7, [rsp+0x70]
000074b6341d3a2e  vmovaps xmm8, [rsp+0x80]
000074b6341d3a37  vmovaps xmm10, [rsp+0x90]
000074b6341d3a40  vmovaps xmm11, [rsp+0xA0]
000074b6341d3a49  vmovaps xmm12, [rsp+0xB0]
000074b6341d3a52  vmovaps xmm13, [rsp+0xC0]
000074b6341d3a5b  vmovaps xmm14, [rsp+0xD0]
000074b6341d3a64  vmovaps xmm15, [rsp+0xE0]
000074b6341d3a6d  add rsp, 0xF0
000074b6341d3a74  pop r11
000074b6341d3a76  pop r10
000074b6341d3a78  pop r9
000074b6341d3a7a  pop r8
000074b6341d3a7c  pop rsi
000074b6341d3a7d  pop rdi
000074b6341d3a7e  pop rdx
000074b6341d3a7f  pop rcx
000074b6341d3a80  pop rax
000074b6341d3a81  add rsp, 0x08
000074b6341d3a85  jmp 0x000074B6341CFFE1
000074b6341d3a8a  sub rsp, 0x08
000074b6341d3a8e  push rax
000074b6341d3a8f  push rcx
000074b6341d3a90  push rdx
000074b6341d3a91  push rdi
000074b6341d3a92  push rsi
000074b6341d3a93  push r8
000074b6341d3a95  push r9
000074b6341d3a97  push r10
000074b6341d3a99  push r11
000074b6341d3a9b  sub rsp, 0xF0
000074b6341d3aa2  vmovaps [rsp], xmm0
000074b6341d3aa7  vmovaps [rsp+0x10], xmm1
000074b6341d3aad  vmovaps [rsp+0x20], xmm2
000074b6341d3ab3  vmovaps [rsp+0x30], xmm3
000074b6341d3ab9  vmovaps [rsp+0x40], xmm4
000074b6341d3abf  vmovaps [rsp+0x50], xmm5
000074b6341d3ac5  vmovaps [rsp+0x60], xmm6
000074b6341d3acb  vmovaps [rsp+0x70], xmm7
000074b6341d3ad1  vmovaps [rsp+0x80], xmm8
000074b6341d3ada  vmovaps [rsp+0x90], xmm9
000074b6341d3ae3  vmovaps [rsp+0xA0], xmm11
000074b6341d3aec  vmovaps [rsp+0xB0], xmm12
000074b6341d3af5  vmovaps [rsp+0xC0], xmm13
000074b6341d3afe  vmovaps [rsp+0xD0], xmm14
000074b6341d3b07  vmovaps [rsp+0xE0], xmm15
000074b6341d3b10  sub rsp, 0x30
000074b6341d3b14  movaps [rsp], xmm10
000074b6341d3b19  movaps [rsp+0x10], xmm1
000074b6341d3b1e  movaps [rsp+0x20], xmm11
000074b6341d3b24  lea rdi, [rsp]
000074b6341d3b28  mov esi, 0x00
000074b6341d3b2d  mov rax, 0x5E1AA0A2F530
000074b6341d3b37  call rax
000074b6341d3b39  movaps xmm10, [rsp]
000074b6341d3b3e  add rsp, 0x30
000074b6341d3b42  vmovaps xmm0, [rsp]
000074b6341d3b47  vmovaps xmm1, [rsp+0x10]
000074b6341d3b4d  vmovaps xmm2, [rsp+0x20]
000074b6341d3b53  vmovaps xmm3, [rsp+0x30]
000074b6341d3b59  vmovaps xmm4, [rsp+0x40]
000074b6341d3b5f  vmovaps xmm5, [rsp+0x50]
000074b6341d3b65  vmovaps xmm6, [rsp+0x60]
000074b6341d3b6b  vmovaps xmm7, [rsp+0x70]
000074b6341d3b71  vmovaps xmm8, [rsp+0x80]
000074b6341d3b7a  vmovaps xmm9, [rsp+0x90]
000074b6341d3b83  vmovaps xmm11, [rsp+0xA0]
000074b6341d3b8c  vmovaps xmm12, [rsp+0xB0]
000074b6341d3b95  vmovaps xmm13, [rsp+0xC0]
000074b6341d3b9e  vmovaps xmm14, [rsp+0xD0]
000074b6341d3ba7  vmovaps xmm15, [rsp+0xE0]
000074b6341d3bb0  add rsp, 0xF0
000074b6341d3bb7  pop r11
000074b6341d3bb9  pop r10
000074b6341d3bbb  pop r9
000074b6341d3bbd  pop r8
000074b6341d3bbf  pop rsi
000074b6341d3bc0  pop rdi
000074b6341d3bc1  pop rdx
000074b6341d3bc2  pop rcx
000074b6341d3bc3  pop rax
000074b6341d3bc4  add rsp, 0x08
000074b6341d3bc8  jmp 0x000074B6341CFFFC
000074b6341d3bcd  sub rsp, 0x08
000074b6341d3bd1  push rax
000074b6341d3bd2  push rcx
000074b6341d3bd3  push rdx
000074b6341d3bd4  push rdi
000074b6341d3bd5  push rsi
000074b6341d3bd6  push r8
000074b6341d3bd8  push r9
000074b6341d3bda  push r10
000074b6341d3bdc  push r11
000074b6341d3bde  sub rsp, 0xF0
000074b6341d3be5  vmovaps [rsp], xmm0
000074b6341d3bea  vmovaps [rsp+0x10], xmm2
000074b6341d3bf0  vmovaps [rsp+0x20], xmm3
000074b6341d3bf6  vmovaps [rsp+0x30], xmm4
000074b6341d3bfc  vmovaps [rsp+0x40], xmm5
000074b6341d3c02  vmovaps [rsp+0x50], xmm6
000074b6341d3c08  vmovaps [rsp+0x60], xmm7
000074b6341d3c0e  vmovaps [rsp+0x70], xmm8
000074b6341d3c14  vmovaps [rsp+0x80], xmm9
000074b6341d3c1d  vmovaps [rsp+0x90], xmm10
000074b6341d3c26  vmovaps [rsp+0xA0], xmm11
000074b6341d3c2f  vmovaps [rsp+0xB0], xmm12
000074b6341d3c38  vmovaps [rsp+0xC0], xmm13
000074b6341d3c41  vmovaps [rsp+0xD0], xmm14
000074b6341d3c4a  vmovaps [rsp+0xE0], xmm15
000074b6341d3c53  sub rsp, 0x30
000074b6341d3c57  movaps [rsp], xmm1
000074b6341d3c5b  movaps [rsp+0x10], xmm14
000074b6341d3c61  movaps [rsp+0x20], xmm6
000074b6341d3c66  lea rdi, [rsp]
000074b6341d3c6a  mov esi, 0x00
000074b6341d3c6f  mov rax, 0x5E1AA0A2F530
000074b6341d3c79  call rax
000074b6341d3c7b  movaps xmm1, [rsp]
000074b6341d3c7f  add rsp, 0x30
000074b6341d3c83  vmovaps xmm0, [rsp]
000074b6341d3c88  vmovaps xmm2, [rsp+0x10]
000074b6341d3c8e  vmovaps xmm3, [rsp+0x20]
000074b6341d3c94  vmovaps xmm4, [rsp+0x30]
000074b6341d3c9a  vmovaps xmm5, [rsp+0x40]
000074b6341d3ca0  vmovaps xmm6, [rsp+0x50]
000074b6341d3ca6  vmovaps xmm7, [rsp+0x60]
000074b6341d3cac  vmovaps xmm8, [rsp+0x70]
000074b6341d3cb2  vmovaps xmm9, [rsp+0x80]
000074b6341d3cbb  vmovaps xmm10, [rsp+0x90]
000074b6341d3cc4  vmovaps xmm11, [rsp+0xA0]
000074b6341d3ccd  vmovaps xmm12, [rsp+0xB0]
000074b6341d3cd6  vmovaps xmm13, [rsp+0xC0]
000074b6341d3cdf  vmovaps xmm14, [rsp+0xD0]
000074b6341d3ce8  vmovaps xmm15, [rsp+0xE0]
000074b6341d3cf1  add rsp, 0xF0
000074b6341d3cf8  pop r11
000074b6341d3cfa  pop r10
000074b6341d3cfc  pop r9
000074b6341d3cfe  pop r8
000074b6341d3d00  pop rsi
000074b6341d3d01  pop rdi
000074b6341d3d02  pop rdx
000074b6341d3d03  pop rcx
000074b6341d3d04  pop rax
000074b6341d3d05  add rsp, 0x08
000074b6341d3d09  jmp 0x000074B6341D0015
000074b6341d3d0e  sub rsp, 0x08
000074b6341d3d12  push rax
000074b6341d3d13  push rcx
000074b6341d3d14  push rdx
000074b6341d3d15  push rdi
000074b6341d3d16  push rsi
000074b6341d3d17  push r8
000074b6341d3d19  push r9
000074b6341d3d1b  push r10
000074b6341d3d1d  push r11
000074b6341d3d1f  sub rsp, 0xF0
000074b6341d3d26  vmovaps [rsp], xmm0
000074b6341d3d2b  vmovaps [rsp+0x10], xmm1
000074b6341d3d31  vmovaps [rsp+0x20], xmm2
000074b6341d3d37  vmovaps [rsp+0x30], xmm3
000074b6341d3d3d  vmovaps [rsp+0x40], xmm4
000074b6341d3d43  vmovaps [rsp+0x50], xmm5
000074b6341d3d49  vmovaps [rsp+0x60], xmm6
000074b6341d3d4f  vmovaps [rsp+0x70], xmm7
000074b6341d3d55  vmovaps [rsp+0x80], xmm8
000074b6341d3d5e  vmovaps [rsp+0x90], xmm9
000074b6341d3d67  vmovaps [rsp+0xA0], xmm10
000074b6341d3d70  vmovaps [rsp+0xB0], xmm12
000074b6341d3d79  vmovaps [rsp+0xC0], xmm13
000074b6341d3d82  vmovaps [rsp+0xD0], xmm14
000074b6341d3d8b  vmovaps [rsp+0xE0], xmm15
000074b6341d3d94  sub rsp, 0x30
000074b6341d3d98  movaps [rsp], xmm11
000074b6341d3d9d  movaps [rsp+0x10], xmm13
000074b6341d3da3  movaps [rsp+0x20], xmm14
000074b6341d3da9  lea rdi, [rsp]
000074b6341d3dad  mov esi, 0x00
000074b6341d3db2  mov rax, 0x5E1AA0A2F530
000074b6341d3dbc  call rax
000074b6341d3dbe  movaps xmm11, [rsp]
000074b6341d3dc3  add rsp, 0x30
000074b6341d3dc7  vmovaps xmm0, [rsp]
000074b6341d3dcc  vmovaps xmm1, [rsp+0x10]
000074b6341d3dd2  vmovaps xmm2, [rsp+0x20]
000074b6341d3dd8  vmovaps xmm3, [rsp+0x30]
000074b6341d3dde  vmovaps xmm4, [rsp+0x40]
000074b6341d3de4  vmovaps xmm5, [rsp+0x50]
000074b6341d3dea  vmovaps xmm6, [rsp+0x60]
000074b6341d3df0  vmovaps xmm7, [rsp+0x70]
000074b6341d3df6  vmovaps xmm8, [rsp+0x80]
000074b6341d3dff  vmovaps xmm9, [rsp+0x90]
000074b6341d3e08  vmovaps xmm10, [rsp+0xA0]
000074b6341d3e11  vmovaps xmm12, [rsp+0xB0]
000074b6341d3e1a  vmovaps xmm13, [rsp+0xC0]
000074b6341d3e23  vmovaps xmm14, [rsp+0xD0]
000074b6341d3e2c  vmovaps xmm15, [rsp+0xE0]
000074b6341d3e35  add rsp, 0xF0
000074b6341d3e3c  pop r11
000074b6341d3e3e  pop r10
000074b6341d3e40  pop r9
000074b6341d3e42  pop r8
000074b6341d3e44  pop rsi
000074b6341d3e45  pop rdi
000074b6341d3e46  pop rdx
000074b6341d3e47  pop rcx
000074b6341d3e48  pop rax
000074b6341d3e49  add rsp, 0x08
000074b6341d3e4d  jmp 0x000074B6341D003F
000074b6341d3e52  sub rsp, 0x08
000074b6341d3e56  push rax
000074b6341d3e57  push rcx
000074b6341d3e58  push rdx
000074b6341d3e59  push rdi
000074b6341d3e5a  push rsi
000074b6341d3e5b  push r8
000074b6341d3e5d  push r9
000074b6341d3e5f  push r10
000074b6341d3e61  push r11
000074b6341d3e63  sub rsp, 0xF0
000074b6341d3e6a  vmovaps [rsp], xmm0
000074b6341d3e6f  vmovaps [rsp+0x10], xmm1
000074b6341d3e75  vmovaps [rsp+0x20], xmm2
000074b6341d3e7b  vmovaps [rsp+0x30], xmm3
000074b6341d3e81  vmovaps [rsp+0x40], xmm4
000074b6341d3e87  vmovaps [rsp+0x50], xmm5
000074b6341d3e8d  vmovaps [rsp+0x60], xmm6
000074b6341d3e93  vmovaps [rsp+0x70], xmm7
000074b6341d3e99  vmovaps [rsp+0x80], xmm8
000074b6341d3ea2  vmovaps [rsp+0x90], xmm9
000074b6341d3eab  vmovaps [rsp+0xA0], xmm10
000074b6341d3eb4  vmovaps [rsp+0xB0], xmm11
000074b6341d3ebd  vmovaps [rsp+0xC0], xmm12
000074b6341d3ec6  vmovaps [rsp+0xD0], xmm14
000074b6341d3ecf  vmovaps [rsp+0xE0], xmm15
000074b6341d3ed8  sub rsp, 0x30
000074b6341d3edc  movaps [rsp], xmm13
000074b6341d3ee1  movaps [rsp+0x10], xmm8
000074b6341d3ee7  movaps [rsp+0x20], xmm14
000074b6341d3eed  lea rdi, [rsp]
000074b6341d3ef1  mov esi, 0x00
000074b6341d3ef6  mov rax, 0x5E1AA0A2F530
000074b6341d3f00  call rax
000074b6341d3f02  movaps xmm13, [rsp]
000074b6341d3f07  add rsp, 0x30
000074b6341d3f0b  vmovaps xmm0, [rsp]
000074b6341d3f10  vmovaps xmm1, [rsp+0x10]
000074b6341d3f16  vmovaps xmm2, [rsp+0x20]
000074b6341d3f1c  vmovaps xmm3, [rsp+0x30]
000074b6341d3f22  vmovaps xmm4, [rsp+0x40]
000074b6341d3f28  vmovaps xmm5, [rsp+0x50]
000074b6341d3f2e  vmovaps xmm6, [rsp+0x60]
000074b6341d3f34  vmovaps xmm7, [rsp+0x70]
000074b6341d3f3a  vmovaps xmm8, [rsp+0x80]
000074b6341d3f43  vmovaps xmm9, [rsp+0x90]
000074b6341d3f4c  vmovaps xmm10, [rsp+0xA0]
000074b6341d3f55  vmovaps xmm11, [rsp+0xB0]
000074b6341d3f5e  vmovaps xmm12, [rsp+0xC0]
000074b6341d3f67  vmovaps xmm14, [rsp+0xD0]
000074b6341d3f70  vmovaps xmm15, [rsp+0xE0]
000074b6341d3f79  add rsp, 0xF0
000074b6341d3f80  pop r11
000074b6341d3f82  pop r10
000074b6341d3f84  pop r9
000074b6341d3f86  pop r8
000074b6341d3f88  pop rsi
000074b6341d3f89  pop rdi
000074b6341d3f8a  pop rdx
000074b6341d3f8b  pop rcx
000074b6341d3f8c  pop rax
000074b6341d3f8d  add rsp, 0x08
000074b6341d3f91  jmp 0x000074B6341D006E
000074b6341d3f96  sub rsp, 0x08
000074b6341d3f9a  push rax
000074b6341d3f9b  push rcx
000074b6341d3f9c  push rdx
000074b6341d3f9d  push rdi
000074b6341d3f9e  push rsi
000074b6341d3f9f  push r8
000074b6341d3fa1  push r9
000074b6341d3fa3  push r10
000074b6341d3fa5  push r11
000074b6341d3fa7  sub rsp, 0xF0
000074b6341d3fae  vmovaps [rsp], xmm0
000074b6341d3fb3  vmovaps [rsp+0x10], xmm1
000074b6341d3fb9  vmovaps [rsp+0x20], xmm2
000074b6341d3fbf  vmovaps [rsp+0x30], xmm3
000074b6341d3fc5  vmovaps [rsp+0x40], xmm4
000074b6341d3fcb  vmovaps [rsp+0x50], xmm5
000074b6341d3fd1  vmovaps [rsp+0x60], xmm6
000074b6341d3fd7  vmovaps [rsp+0x70], xmm7
000074b6341d3fdd  vmovaps [rsp+0x80], xmm9
000074b6341d3fe6  vmovaps [rsp+0x90], xmm10
000074b6341d3fef  vmovaps [rsp+0xA0], xmm11
000074b6341d3ff8  vmovaps [rsp+0xB0], xmm12
000074b6341d4001  vmovaps [rsp+0xC0], xmm13
000074b6341d400a  vmovaps [rsp+0xD0], xmm14
000074b6341d4013  vmovaps [rsp+0xE0], xmm15
000074b6341d401c  sub rsp, 0x30
000074b6341d4020  movaps [rsp], xmm8
000074b6341d4025  movaps [rsp+0x10], xmm7
000074b6341d402a  movaps [rsp+0x20], xmm14
000074b6341d4030  lea rdi, [rsp]
000074b6341d4034  mov esi, 0x00
000074b6341d4039  mov rax, 0x5E1AA0A2F530
000074b6341d4043  call rax
000074b6341d4045  movaps xmm8, [rsp]
000074b6341d404a  add rsp, 0x30
000074b6341d404e  vmovaps xmm0, [rsp]
000074b6341d4053  vmovaps xmm1, [rsp+0x10]
000074b6341d4059  vmovaps xmm2, [rsp+0x20]
000074b6341d405f  vmovaps xmm3, [rsp+0x30]
000074b6341d4065  vmovaps xmm4, [rsp+0x40]
000074b6341d406b  vmovaps xmm5, [rsp+0x50]
000074b6341d4071  vmovaps xmm6, [rsp+0x60]
000074b6341d4077  vmovaps xmm7, [rsp+0x70]
000074b6341d407d  vmovaps xmm9, [rsp+0x80]
000074b6341d4086  vmovaps xmm10, [rsp+0x90]
000074b6341d408f  vmovaps xmm11, [rsp+0xA0]
000074b6341d4098  vmovaps xmm12, [rsp+0xB0]
000074b6341d40a1  vmovaps xmm13, [rsp+0xC0]
000074b6341d40aa  vmovaps xmm14, [rsp+0xD0]
000074b6341d40b3  vmovaps xmm15, [rsp+0xE0]
000074b6341d40bc  add rsp, 0xF0
000074b6341d40c3  pop r11
000074b6341d40c5  pop r10
000074b6341d40c7  pop r9
000074b6341d40c9  pop r8
000074b6341d40cb  pop rsi
000074b6341d40cc  pop rdi
000074b6341d40cd  pop rdx
000074b6341d40ce  pop rcx
000074b6341d40cf  pop rax
000074b6341d40d0  add rsp, 0x08
000074b6341d40d4  jmp 0x000074B6341D0094
000074b6341d40d9  sub rsp, 0x08
000074b6341d40dd  push rax
000074b6341d40de  push rcx
000074b6341d40df  push rdx
000074b6341d40e0  push rdi
000074b6341d40e1  push rsi
000074b6341d40e2  push r8
000074b6341d40e4  push r9
000074b6341d40e6  push r10
000074b6341d40e8  push r11
000074b6341d40ea  sub rsp, 0xF0
000074b6341d40f1  vmovaps [rsp], xmm0
000074b6341d40f6  vmovaps [rsp+0x10], xmm1
000074b6341d40fc  vmovaps [rsp+0x20], xmm2
000074b6341d4102  vmovaps [rsp+0x30], xmm3
000074b6341d4108  vmovaps [rsp+0x40], xmm4
000074b6341d410e  vmovaps [rsp+0x50], xmm5
000074b6341d4114  vmovaps [rsp+0x60], xmm6
000074b6341d411a  vmovaps [rsp+0x70], xmm7
000074b6341d4120  vmovaps [rsp+0x80], xmm8
000074b6341d4129  vmovaps [rsp+0x90], xmm9
000074b6341d4132  vmovaps [rsp+0xA0], xmm10
000074b6341d413b  vmovaps [rsp+0xB0], xmm11
000074b6341d4144  vmovaps [rsp+0xC0], xmm12
000074b6341d414d  vmovaps [rsp+0xD0], xmm13
000074b6341d4156  vmovaps [rsp+0xE0], xmm15
000074b6341d415f  sub rsp, 0x30
000074b6341d4163  movaps [rsp], xmm14
000074b6341d4168  movaps [rsp+0x10], xmm12
000074b6341d416e  movaps [rsp+0x20], xmm9
000074b6341d4174  lea rdi, [rsp]
000074b6341d4178  mov esi, 0x00
000074b6341d417d  mov rax, 0x5E1AA0A2F530
000074b6341d4187  call rax
000074b6341d4189  movaps xmm14, [rsp]
000074b6341d418e  add rsp, 0x30
000074b6341d4192  vmovaps xmm0, [rsp]
000074b6341d4197  vmovaps xmm1, [rsp+0x10]
000074b6341d419d  vmovaps xmm2, [rsp+0x20]
000074b6341d41a3  vmovaps xmm3, [rsp+0x30]
000074b6341d41a9  vmovaps xmm4, [rsp+0x40]
000074b6341d41af  vmovaps xmm5, [rsp+0x50]
000074b6341d41b5  vmovaps xmm6, [rsp+0x60]
000074b6341d41bb  vmovaps xmm7, [rsp+0x70]
000074b6341d41c1  vmovaps xmm8, [rsp+0x80]
000074b6341d41ca  vmovaps xmm9, [rsp+0x90]
000074b6341d41d3  vmovaps xmm10, [rsp+0xA0]
000074b6341d41dc  vmovaps xmm11, [rsp+0xB0]
000074b6341d41e5  vmovaps xmm12, [rsp+0xC0]
000074b6341d41ee  vmovaps xmm13, [rsp+0xD0]
000074b6341d41f7  vmovaps xmm15, [rsp+0xE0]
000074b6341d4200  add rsp, 0xF0
000074b6341d4207  pop r11
000074b6341d4209  pop r10
000074b6341d420b  pop r9
000074b6341d420d  pop r8
000074b6341d420f  pop rsi
000074b6341d4210  pop rdi
000074b6341d4211  pop rdx
000074b6341d4212  pop rcx
000074b6341d4213  pop rax
000074b6341d4214  add rsp, 0x08
000074b6341d4218  jmp 0x000074B6341D00AE
000074b6341d421d  sub rsp, 0x08
000074b6341d4221  push rax
000074b6341d4222  push rcx
000074b6341d4223  push rdx
000074b6341d4224  push rdi
000074b6341d4225  push rsi
000074b6341d4226  push r8
000074b6341d4228  push r9
000074b6341d422a  push r10
000074b6341d422c  push r11
000074b6341d422e  sub rsp, 0xF0
000074b6341d4235  vmovaps [rsp], xmm0
000074b6341d423a  vmovaps [rsp+0x10], xmm1
000074b6341d4240  vmovaps [rsp+0x20], xmm2
000074b6341d4246  vmovaps [rsp+0x30], xmm3
000074b6341d424c  vmovaps [rsp+0x40], xmm4
000074b6341d4252  vmovaps [rsp+0x50], xmm5
000074b6341d4258  vmovaps [rsp+0x60], xmm6
000074b6341d425e  vmovaps [rsp+0x70], xmm7
000074b6341d4264  vmovaps [rsp+0x80], xmm8
000074b6341d426d  vmovaps [rsp+0x90], xmm10
000074b6341d4276  vmovaps [rsp+0xA0], xmm11
000074b6341d427f  vmovaps [rsp+0xB0], xmm12
000074b6341d4288  vmovaps [rsp+0xC0], xmm13
000074b6341d4291  vmovaps [rsp+0xD0], xmm14
000074b6341d429a  vmovaps [rsp+0xE0], xmm15
000074b6341d42a3  sub rsp, 0x30
000074b6341d42a7  movaps [rsp], xmm9
000074b6341d42ac  movaps [rsp+0x10], xmm7
000074b6341d42b1  movaps [rsp+0x20], xmm12
000074b6341d42b7  lea rdi, [rsp]
000074b6341d42bb  mov esi, 0x00
000074b6341d42c0  mov rax, 0x5E1AA0A2F530
000074b6341d42ca  call rax
000074b6341d42cc  movaps xmm9, [rsp]
000074b6341d42d1  add rsp, 0x30
000074b6341d42d5  vmovaps xmm0, [rsp]
000074b6341d42da  vmovaps xmm1, [rsp+0x10]
000074b6341d42e0  vmovaps xmm2, [rsp+0x20]
000074b6341d42e6  vmovaps xmm3, [rsp+0x30]
000074b6341d42ec  vmovaps xmm4, [rsp+0x40]
000074b6341d42f2  vmovaps xmm5, [rsp+0x50]
000074b6341d42f8  vmovaps xmm6, [rsp+0x60]
000074b6341d42fe  vmovaps xmm7, [rsp+0x70]
000074b6341d4304  vmovaps xmm8, [rsp+0x80]
000074b6341d430d  vmovaps xmm10, [rsp+0x90]
000074b6341d4316  vmovaps xmm11, [rsp+0xA0]
000074b6341d431f  vmovaps xmm12, [rsp+0xB0]
000074b6341d4328  vmovaps xmm13, [rsp+0xC0]
000074b6341d4331  vmovaps xmm14, [rsp+0xD0]
000074b6341d433a  vmovaps xmm15, [rsp+0xE0]
000074b6341d4343  add rsp, 0xF0
000074b6341d434a  pop r11
000074b6341d434c  pop r10
000074b6341d434e  pop r9
000074b6341d4350  pop r8
000074b6341d4352  pop rsi
000074b6341d4353  pop rdi
000074b6341d4354  pop rdx
000074b6341d4355  pop rcx
000074b6341d4356  pop rax
000074b6341d4357  add rsp, 0x08
000074b6341d435b  jmp 0x000074B6341D00DD
000074b6341d4360  sub rsp, 0x08
000074b6341d4364  push rax
000074b6341d4365  push rcx
000074b6341d4366  push rdx
000074b6341d4367  push rdi
000074b6341d4368  push rsi
000074b6341d4369  push r8
000074b6341d436b  push r9
000074b6341d436d  push r10
000074b6341d436f  push r11
000074b6341d4371  sub rsp, 0xF0
000074b6341d4378  vmovaps [rsp], xmm0
000074b6341d437d  vmovaps [rsp+0x10], xmm1
000074b6341d4383  vmovaps [rsp+0x20], xmm2
000074b6341d4389  vmovaps [rsp+0x30], xmm3
000074b6341d438f  vmovaps [rsp+0x40], xmm4
000074b6341d4395  vmovaps [rsp+0x50], xmm5
000074b6341d439b  vmovaps [rsp+0x60], xmm6
000074b6341d43a1  vmovaps [rsp+0x70], xmm7
000074b6341d43a7  vmovaps [rsp+0x80], xmm8
000074b6341d43b0  vmovaps [rsp+0x90], xmm9
000074b6341d43b9  vmovaps [rsp+0xA0], xmm10
000074b6341d43c2  vmovaps [rsp+0xB0], xmm11
000074b6341d43cb  vmovaps [rsp+0xC0], xmm13
000074b6341d43d4  vmovaps [rsp+0xD0], xmm14
000074b6341d43dd  vmovaps [rsp+0xE0], xmm15
000074b6341d43e6  sub rsp, 0x30
000074b6341d43ea  movaps [rsp], xmm12
000074b6341d43ef  movaps [rsp+0x10], xmm15
000074b6341d43f5  movaps [rsp+0x20], xmm11
000074b6341d43fb  lea rdi, [rsp]
000074b6341d43ff  mov esi, 0x00
000074b6341d4404  mov rax, 0x5E1AA0A2F530
000074b6341d440e  call rax
000074b6341d4410  movaps xmm12, [rsp]
000074b6341d4415  add rsp, 0x30
000074b6341d4419  vmovaps xmm0, [rsp]
000074b6341d441e  vmovaps xmm1, [rsp+0x10]
000074b6341d4424  vmovaps xmm2, [rsp+0x20]
000074b6341d442a  vmovaps xmm3, [rsp+0x30]
000074b6341d4430  vmovaps xmm4, [rsp+0x40]
000074b6341d4436  vmovaps xmm5, [rsp+0x50]
000074b6341d443c  vmovaps xmm6, [rsp+0x60]
000074b6341d4442  vmovaps xmm7, [rsp+0x70]
000074b6341d4448  vmovaps xmm8, [rsp+0x80]
000074b6341d4451  vmovaps xmm9, [rsp+0x90]
000074b6341d445a  vmovaps xmm10, [rsp+0xA0]
000074b6341d4463  vmovaps xmm11, [rsp+0xB0]
000074b6341d446c  vmovaps xmm13, [rsp+0xC0]
000074b6341d4475  vmovaps xmm14, [rsp+0xD0]
000074b6341d447e  vmovaps xmm15, [rsp+0xE0]
000074b6341d4487  add rsp, 0xF0
000074b6341d448e  pop r11
000074b6341d4490  pop r10
000074b6341d4492  pop r9
000074b6341d4494  pop r8
000074b6341d4496  pop rsi
000074b6341d4497  pop rdi
000074b6341d4498  pop rdx
000074b6341d4499  pop rcx
000074b6341d449a  pop rax
000074b6341d449b  add rsp, 0x08
000074b6341d449f  jmp 0x000074B6341D00F7
000074b6341d44a4  sub rsp, 0x08
000074b6341d44a8  push rax
000074b6341d44a9  push rcx
000074b6341d44aa  push rdx
000074b6341d44ab  push rdi
000074b6341d44ac  push rsi
000074b6341d44ad  push r8
000074b6341d44af  push r9
000074b6341d44b1  push r10
000074b6341d44b3  push r11
000074b6341d44b5  sub rsp, 0xF0
000074b6341d44bc  vmovaps [rsp], xmm0
000074b6341d44c1  vmovaps [rsp+0x10], xmm1
000074b6341d44c7  vmovaps [rsp+0x20], xmm2
000074b6341d44cd  vmovaps [rsp+0x30], xmm3
000074b6341d44d3  vmovaps [rsp+0x40], xmm4
000074b6341d44d9  vmovaps [rsp+0x50], xmm5
000074b6341d44df  vmovaps [rsp+0x60], xmm6
000074b6341d44e5  vmovaps [rsp+0x70], xmm7
000074b6341d44eb  vmovaps [rsp+0x80], xmm8
000074b6341d44f4  vmovaps [rsp+0x90], xmm9
000074b6341d44fd  vmovaps [rsp+0xA0], xmm10
000074b6341d4506  vmovaps [rsp+0xB0], xmm12
000074b6341d450f  vmovaps [rsp+0xC0], xmm13
000074b6341d4518  vmovaps [rsp+0xD0], xmm14
000074b6341d4521  vmovaps [rsp+0xE0], xmm15
000074b6341d452a  sub rsp, 0x30
000074b6341d452e  movaps [rsp], xmm11
000074b6341d4533  movaps [rsp+0x10], xmm7
000074b6341d4538  movaps [rsp+0x20], xmm15
000074b6341d453e  lea rdi, [rsp]
000074b6341d4542  mov esi, 0x00
000074b6341d4547  mov rax, 0x5E1AA0A2F530
000074b6341d4551  call rax
000074b6341d4553  movaps xmm11, [rsp]
000074b6341d4558  add rsp, 0x30
000074b6341d455c  vmovaps xmm0, [rsp]
000074b6341d4561  vmovaps xmm1, [rsp+0x10]
000074b6341d4567  vmovaps xmm2, [rsp+0x20]
000074b6341d456d  vmovaps xmm3, [rsp+0x30]
000074b6341d4573  vmovaps xmm4, [rsp+0x40]
000074b6341d4579  vmovaps xmm5, [rsp+0x50]
000074b6341d457f  vmovaps xmm6, [rsp+0x60]
000074b6341d4585  vmovaps xmm7, [rsp+0x70]
000074b6341d458b  vmovaps xmm8, [rsp+0x80]
000074b6341d4594  vmovaps xmm9, [rsp+0x90]
000074b6341d459d  vmovaps xmm10, [rsp+0xA0]
000074b6341d45a6  vmovaps xmm12, [rsp+0xB0]
000074b6341d45af  vmovaps xmm13, [rsp+0xC0]
000074b6341d45b8  vmovaps xmm14, [rsp+0xD0]
000074b6341d45c1  vmovaps xmm15, [rsp+0xE0]
000074b6341d45ca  add rsp, 0xF0
000074b6341d45d1  pop r11
000074b6341d45d3  pop r10
000074b6341d45d5  pop r9
000074b6341d45d7  pop r8
000074b6341d45d9  pop rsi
000074b6341d45da  pop rdi
000074b6341d45db  pop rdx
000074b6341d45dc  pop rcx
000074b6341d45dd  pop rax
000074b6341d45de  add rsp, 0x08
000074b6341d45e2  jmp 0x000074B6341D0123
000074b6341d45e7  sub rsp, 0x08
000074b6341d45eb  push rax
000074b6341d45ec  push rcx
000074b6341d45ed  push rdx
000074b6341d45ee  push rdi
000074b6341d45ef  push rsi
000074b6341d45f0  push r8
000074b6341d45f2  push r9
000074b6341d45f4  push r10
000074b6341d45f6  push r11
000074b6341d45f8  sub rsp, 0xF0
000074b6341d45ff  vmovaps [rsp], xmm0
000074b6341d4604  vmovaps [rsp+0x10], xmm1
000074b6341d460a  vmovaps [rsp+0x20], xmm2
000074b6341d4610  vmovaps [rsp+0x30], xmm3
000074b6341d4616  vmovaps [rsp+0x40], xmm4
000074b6341d461c  vmovaps [rsp+0x50], xmm5
000074b6341d4622  vmovaps [rsp+0x60], xmm6
000074b6341d4628  vmovaps [rsp+0x70], xmm7
000074b6341d462e  vmovaps [rsp+0x80], xmm8
000074b6341d4637  vmovaps [rsp+0x90], xmm9
000074b6341d4640  vmovaps [rsp+0xA0], xmm10
000074b6341d4649  vmovaps [rsp+0xB0], xmm11
000074b6341d4652  vmovaps [rsp+0xC0], xmm12
000074b6341d465b  vmovaps [rsp+0xD0], xmm13
000074b6341d4664  vmovaps [rsp+0xE0], xmm14
000074b6341d466d  sub rsp, 0x30
000074b6341d4671  movaps [rsp], xmm15
000074b6341d4676  movaps [rsp+0x10], xmm10
000074b6341d467c  movaps [rsp+0x20], xmm13
000074b6341d4682  lea rdi, [rsp]
000074b6341d4686  mov esi, 0x00
000074b6341d468b  mov rax, 0x5E1AA0A2F530
000074b6341d4695  call rax
000074b6341d4697  movaps xmm15, [rsp]
000074b6341d469c  add rsp, 0x30
000074b6341d46a0  vmovaps xmm0, [rsp]
000074b6341d46a5  vmovaps xmm1, [rsp+0x10]
000074b6341d46ab  vmovaps xmm2, [rsp+0x20]
000074b6341d46b1  vmovaps xmm3, [rsp+0x30]
000074b6341d46b7  vmovaps xmm4, [rsp+0x40]
000074b6341d46bd  vmovaps xmm5, [rsp+0x50]
000074b6341d46c3  vmovaps xmm6, [rsp+0x60]
000074b6341d46c9  vmovaps xmm7, [rsp+0x70]
000074b6341d46cf  vmovaps xmm8, [rsp+0x80]
000074b6341d46d8  vmovaps xmm9, [rsp+0x90]
000074b6341d46e1  vmovaps xmm10, [rsp+0xA0]
000074b6341d46ea  vmovaps xmm11, [rsp+0xB0]
000074b6341d46f3  vmovaps xmm12, [rsp+0xC0]
000074b6341d46fc  vmovaps xmm13, [rsp+0xD0]
000074b6341d4705  vmovaps xmm14, [rsp+0xE0]
000074b6341d470e  add rsp, 0xF0
000074b6341d4715  pop r11
000074b6341d4717  pop r10
000074b6341d4719  pop r9
000074b6341d471b  pop r8
000074b6341d471d  pop rsi
000074b6341d471e  pop rdi
000074b6341d471f  pop rdx
000074b6341d4720  pop rcx
000074b6341d4721  pop rax
000074b6341d4722  add rsp, 0x08
000074b6341d4726  jmp 0x000074B6341D013D
000074b6341d472b  sub rsp, 0x08
000074b6341d472f  push rax
000074b6341d4730  push rcx
000074b6341d4731  push rdx
000074b6341d4732  push rdi
000074b6341d4733  push rsi
000074b6341d4734  push r8
000074b6341d4736  push r9
000074b6341d4738  push r10
000074b6341d473a  push r11
000074b6341d473c  sub rsp, 0xF0
000074b6341d4743  vmovaps [rsp], xmm0
000074b6341d4748  vmovaps [rsp+0x10], xmm1
000074b6341d474e  vmovaps [rsp+0x20], xmm2
000074b6341d4754  vmovaps [rsp+0x30], xmm3
000074b6341d475a  vmovaps [rsp+0x40], xmm4
000074b6341d4760  vmovaps [rsp+0x50], xmm5
000074b6341d4766  vmovaps [rsp+0x60], xmm6
000074b6341d476c  vmovaps [rsp+0x70], xmm7
000074b6341d4772  vmovaps [rsp+0x80], xmm8
000074b6341d477b  vmovaps [rsp+0x90], xmm9
000074b6341d4784  vmovaps [rsp+0xA0], xmm11
000074b6341d478d  vmovaps [rsp+0xB0], xmm12
000074b6341d4796  vmovaps [rsp+0xC0], xmm13
000074b6341d479f  vmovaps [rsp+0xD0], xmm14
000074b6341d47a8  vmovaps [rsp+0xE0], xmm15
000074b6341d47b1  sub rsp, 0x30
000074b6341d47b5  movaps [rsp], xmm10
000074b6341d47ba  movaps [rsp+0x10], xmm7
000074b6341d47bf  movaps [rsp+0x20], xmm13
000074b6341d47c5  lea rdi, [rsp]
000074b6341d47c9  mov esi, 0x00
000074b6341d47ce  mov rax, 0x5E1AA0A2F530
000074b6341d47d8  call rax
000074b6341d47da  movaps xmm10, [rsp]
000074b6341d47df  add rsp, 0x30
000074b6341d47e3  vmovaps xmm0, [rsp]
000074b6341d47e8  vmovaps xmm1, [rsp+0x10]
000074b6341d47ee  vmovaps xmm2, [rsp+0x20]
000074b6341d47f4  vmovaps xmm3, [rsp+0x30]
000074b6341d47fa  vmovaps xmm4, [rsp+0x40]
000074b6341d4800  vmovaps xmm5, [rsp+0x50]
000074b6341d4806  vmovaps xmm6, [rsp+0x60]
000074b6341d480c  vmovaps xmm7, [rsp+0x70]
000074b6341d4812  vmovaps xmm8, [rsp+0x80]
000074b6341d481b  vmovaps xmm9, [rsp+0x90]
000074b6341d4824  vmovaps xmm11, [rsp+0xA0]
000074b6341d482d  vmovaps xmm12, [rsp+0xB0]
000074b6341d4836  vmovaps xmm13, [rsp+0xC0]
000074b6341d483f  vmovaps xmm14, [rsp+0xD0]
000074b6341d4848  vmovaps xmm15, [rsp+0xE0]
000074b6341d4851  add rsp, 0xF0
000074b6341d4858  pop r11
000074b6341d485a  pop r10
000074b6341d485c  pop r9
000074b6341d485e  pop r8
000074b6341d4860  pop rsi
000074b6341d4861  pop rdi
000074b6341d4862  pop rdx
000074b6341d4863  pop rcx
000074b6341d4864  pop rax
000074b6341d4865  add rsp, 0x08
000074b6341d4869  jmp 0x000074B6341D0169
000074b6341d486e  sub rsp, 0x08
000074b6341d4872  push rax
000074b6341d4873  push rcx
000074b6341d4874  push rdx
000074b6341d4875  push rdi
000074b6341d4876  push rsi
000074b6341d4877  push r8
000074b6341d4879  push r9
000074b6341d487b  push r10
000074b6341d487d  push r11
000074b6341d487f  sub rsp, 0xF0
000074b6341d4886  vmovaps [rsp], xmm0
000074b6341d488b  vmovaps [rsp+0x10], xmm1
000074b6341d4891  vmovaps [rsp+0x20], xmm2
000074b6341d4897  vmovaps [rsp+0x30], xmm3
000074b6341d489d  vmovaps [rsp+0x40], xmm4
000074b6341d48a3  vmovaps [rsp+0x50], xmm5
000074b6341d48a9  vmovaps [rsp+0x60], xmm6
000074b6341d48af  vmovaps [rsp+0x70], xmm7
000074b6341d48b5  vmovaps [rsp+0x80], xmm8
000074b6341d48be  vmovaps [rsp+0x90], xmm9
000074b6341d48c7  vmovaps [rsp+0xA0], xmm10
000074b6341d48d0  vmovaps [rsp+0xB0], xmm11
000074b6341d48d9  vmovaps [rsp+0xC0], xmm12
000074b6341d48e2  vmovaps [rsp+0xD0], xmm14
000074b6341d48eb  vmovaps [rsp+0xE0], xmm15
000074b6341d48f4  sub rsp, 0x30
000074b6341d48f8  movaps [rsp], xmm13
000074b6341d48fd  movaps [rsp+0x10], xmm1
000074b6341d4902  movaps [rsp+0x20], xmm8
000074b6341d4908  lea rdi, [rsp]
000074b6341d490c  mov esi, 0x00
000074b6341d4911  mov rax, 0x5E1AA0A2F530
000074b6341d491b  call rax
000074b6341d491d  movaps xmm13, [rsp]
000074b6341d4922  add rsp, 0x30
000074b6341d4926  vmovaps xmm0, [rsp]
000074b6341d492b  vmovaps xmm1, [rsp+0x10]
000074b6341d4931  vmovaps xmm2, [rsp+0x20]
000074b6341d4937  vmovaps xmm3, [rsp+0x30]
000074b6341d493d  vmovaps xmm4, [rsp+0x40]
000074b6341d4943  vmovaps xmm5, [rsp+0x50]
000074b6341d4949  vmovaps xmm6, [rsp+0x60]
000074b6341d494f  vmovaps xmm7, [rsp+0x70]
000074b6341d4955  vmovaps xmm8, [rsp+0x80]
000074b6341d495e  vmovaps xmm9, [rsp+0x90]
000074b6341d4967  vmovaps xmm10, [rsp+0xA0]
000074b6341d4970  vmovaps xmm11, [rsp+0xB0]
000074b6341d4979  vmovaps xmm12, [rsp+0xC0]
000074b6341d4982  vmovaps xmm14, [rsp+0xD0]
000074b6341d498b  vmovaps xmm15, [rsp+0xE0]
000074b6341d4994  add rsp, 0xF0
000074b6341d499b  pop r11
000074b6341d499d  pop r10
000074b6341d499f  pop r9
000074b6341d49a1  pop r8
000074b6341d49a3  pop rsi
000074b6341d49a4  pop rdi
000074b6341d49a5  pop rdx
000074b6341d49a6  pop rcx
000074b6341d49a7  pop rax
000074b6341d49a8  add rsp, 0x08
000074b6341d49ac  jmp 0x000074B6341D0183
000074b6341d49b1  call 0x000074B633FFF430
000074b6341d49b6  jmp 0x000074B6341D018D
000074b6341d49bb  sub rsp, 0x08
000074b6341d49bf  push rax
000074b6341d49c0  push rcx
000074b6341d49c1  push rdx
000074b6341d49c2  push rdi
000074b6341d49c3  push rsi
000074b6341d49c4  push r8
000074b6341d49c6  push r9
000074b6341d49c8  push r10
000074b6341d49ca  push r11
000074b6341d49cc  sub rsp, 0xF0
000074b6341d49d3  vmovaps [rsp], xmm0
000074b6341d49d8  vmovaps [rsp+0x10], xmm1
000074b6341d49de  vmovaps [rsp+0x20], xmm2
000074b6341d49e4  vmovaps [rsp+0x30], xmm3
000074b6341d49ea  vmovaps [rsp+0x40], xmm4
000074b6341d49f0  vmovaps [rsp+0x50], xmm5
000074b6341d49f6  vmovaps [rsp+0x60], xmm6
000074b6341d49fc  vmovaps [rsp+0x70], xmm7
000074b6341d4a02  vmovaps [rsp+0x80], xmm9
000074b6341d4a0b  vmovaps [rsp+0x90], xmm10
000074b6341d4a14  vmovaps [rsp+0xA0], xmm11
000074b6341d4a1d  vmovaps [rsp+0xB0], xmm12
000074b6341d4a26  vmovaps [rsp+0xC0], xmm13
000074b6341d4a2f  vmovaps [rsp+0xD0], xmm14
000074b6341d4a38  vmovaps [rsp+0xE0], xmm15
000074b6341d4a41  sub rsp, 0x30
000074b6341d4a45  movaps [rsp], xmm8
000074b6341d4a4a  movaps [rsp+0x10], xmm14
000074b6341d4a50  movaps [rsp+0x20], xmm9
000074b6341d4a56  lea rdi, [rsp]
000074b6341d4a5a  mov esi, 0x00
000074b6341d4a5f  mov rax, 0x5E1AA0A2F530
000074b6341d4a69  call rax
000074b6341d4a6b  movaps xmm8, [rsp]
000074b6341d4a70  add rsp, 0x30
000074b6341d4a74  vmovaps xmm0, [rsp]
000074b6341d4a79  vmovaps xmm1, [rsp+0x10]
000074b6341d4a7f  vmovaps xmm2, [rsp+0x20]
000074b6341d4a85  vmovaps xmm3, [rsp+0x30]
000074b6341d4a8b  vmovaps xmm4, [rsp+0x40]
000074b6341d4a91  vmovaps xmm5, [rsp+0x50]
000074b6341d4a97  vmovaps xmm6, [rsp+0x60]
000074b6341d4a9d  vmovaps xmm7, [rsp+0x70]
000074b6341d4aa3  vmovaps xmm9, [rsp+0x80]
000074b6341d4aac  vmovaps xmm10, [rsp+0x90]
000074b6341d4ab5  vmovaps xmm11, [rsp+0xA0]
000074b6341d4abe  vmovaps xmm12, [rsp+0xB0]
000074b6341d4ac7  vmovaps xmm13, [rsp+0xC0]
000074b6341d4ad0  vmovaps xmm14, [rsp+0xD0]
000074b6341d4ad9  vmovaps xmm15, [rsp+0xE0]
000074b6341d4ae2  add rsp, 0xF0
000074b6341d4ae9  pop r11
000074b6341d4aeb  pop r10
000074b6341d4aed  pop r9
000074b6341d4aef  pop r8
000074b6341d4af1  pop rsi
000074b6341d4af2  pop rdi
000074b6341d4af3  pop rdx
000074b6341d4af4  pop rcx
000074b6341d4af5  pop rax
000074b6341d4af6  add rsp, 0x08
000074b6341d4afa  jmp 0x000074B6341D01AF
000074b6341d4aff  sub rsp, 0x08
000074b6341d4b03  push rax
000074b6341d4b04  push rcx
000074b6341d4b05  push rdx
000074b6341d4b06  push rdi
000074b6341d4b07  push rsi
000074b6341d4b08  push r8
000074b6341d4b0a  push r9
000074b6341d4b0c  push r10
000074b6341d4b0e  push r11
000074b6341d4b10  sub rsp, 0xF0
000074b6341d4b17  vmovaps [rsp], xmm0
000074b6341d4b1c  vmovaps [rsp+0x10], xmm1
000074b6341d4b22  vmovaps [rsp+0x20], xmm2
000074b6341d4b28  vmovaps [rsp+0x30], xmm3
000074b6341d4b2e  vmovaps [rsp+0x40], xmm4
000074b6341d4b34  vmovaps [rsp+0x50], xmm5
000074b6341d4b3a  vmovaps [rsp+0x60], xmm6
000074b6341d4b40  vmovaps [rsp+0x70], xmm7
000074b6341d4b46  vmovaps [rsp+0x80], xmm8
000074b6341d4b4f  vmovaps [rsp+0x90], xmm10
000074b6341d4b58  vmovaps [rsp+0xA0], xmm11
000074b6341d4b61  vmovaps [rsp+0xB0], xmm12
000074b6341d4b6a  vmovaps [rsp+0xC0], xmm13
000074b6341d4b73  vmovaps [rsp+0xD0], xmm14
000074b6341d4b7c  vmovaps [rsp+0xE0], xmm15
000074b6341d4b85  sub rsp, 0x30
000074b6341d4b89  movaps [rsp], xmm9
000074b6341d4b8e  movaps [rsp+0x10], xmm1
000074b6341d4b93  movaps [rsp+0x20], xmm14
000074b6341d4b99  lea rdi, [rsp]
000074b6341d4b9d  mov esi, 0x00
000074b6341d4ba2  mov rax, 0x5E1AA0A2F530
000074b6341d4bac  call rax
000074b6341d4bae  movaps xmm9, [rsp]
000074b6341d4bb3  add rsp, 0x30
000074b6341d4bb7  vmovaps xmm0, [rsp]
000074b6341d4bbc  vmovaps xmm1, [rsp+0x10]
000074b6341d4bc2  vmovaps xmm2, [rsp+0x20]
000074b6341d4bc8  vmovaps xmm3, [rsp+0x30]
000074b6341d4bce  vmovaps xmm4, [rsp+0x40]
000074b6341d4bd4  vmovaps xmm5, [rsp+0x50]
000074b6341d4bda  vmovaps xmm6, [rsp+0x60]
000074b6341d4be0  vmovaps xmm7, [rsp+0x70]
000074b6341d4be6  vmovaps xmm8, [rsp+0x80]
000074b6341d4bef  vmovaps xmm10, [rsp+0x90]
000074b6341d4bf8  vmovaps xmm11, [rsp+0xA0]
000074b6341d4c01  vmovaps xmm12, [rsp+0xB0]
000074b6341d4c0a  vmovaps xmm13, [rsp+0xC0]
000074b6341d4c13  vmovaps xmm14, [rsp+0xD0]
000074b6341d4c1c  vmovaps xmm15, [rsp+0xE0]
000074b6341d4c25  add rsp, 0xF0
000074b6341d4c2c  pop r11
000074b6341d4c2e  pop r10
000074b6341d4c30  pop r9
000074b6341d4c32  pop r8
000074b6341d4c34  pop rsi
000074b6341d4c35  pop rdi
000074b6341d4c36  pop rdx
000074b6341d4c37  pop rcx
000074b6341d4c38  pop rax
000074b6341d4c39  add rsp, 0x08
000074b6341d4c3d  jmp 0x000074B6341D01DD
000074b6341d4c42  sub rsp, 0x08
000074b6341d4c46  push rax
000074b6341d4c47  push rcx
000074b6341d4c48  push rdx
000074b6341d4c49  push rdi
000074b6341d4c4a  push rsi
000074b6341d4c4b  push r8
000074b6341d4c4d  push r9
000074b6341d4c4f  push r10
000074b6341d4c51  push r11
000074b6341d4c53  sub rsp, 0xF0
000074b6341d4c5a  vmovaps [rsp], xmm0
000074b6341d4c5f  vmovaps [rsp+0x10], xmm1
000074b6341d4c65  vmovaps [rsp+0x20], xmm2
000074b6341d4c6b  vmovaps [rsp+0x30], xmm3
000074b6341d4c71  vmovaps [rsp+0x40], xmm4
000074b6341d4c77  vmovaps [rsp+0x50], xmm5
000074b6341d4c7d  vmovaps [rsp+0x60], xmm6
000074b6341d4c83  vmovaps [rsp+0x70], xmm7
000074b6341d4c89  vmovaps [rsp+0x80], xmm8
000074b6341d4c92  vmovaps [rsp+0x90], xmm9
000074b6341d4c9b  vmovaps [rsp+0xA0], xmm10
000074b6341d4ca4  vmovaps [rsp+0xB0], xmm11
000074b6341d4cad  vmovaps [rsp+0xC0], xmm12
000074b6341d4cb6  vmovaps [rsp+0xD0], xmm13
000074b6341d4cbf  vmovaps [rsp+0xE0], xmm15
000074b6341d4cc8  sub rsp, 0x30
000074b6341d4ccc  movaps [rsp], xmm14
000074b6341d4cd1  movaps [rsp+0x10], xmm4
000074b6341d4cd6  movaps [rsp+0x20], xmm1
000074b6341d4cdb  lea rdi, [rsp]
000074b6341d4cdf  mov esi, 0x00
000074b6341d4ce4  mov rax, 0x5E1AA0A2F530
000074b6341d4cee  call rax
000074b6341d4cf0  movaps xmm14, [rsp]
000074b6341d4cf5  add rsp, 0x30
000074b6341d4cf9  vmovaps xmm0, [rsp]
000074b6341d4cfe  vmovaps xmm1, [rsp+0x10]
000074b6341d4d04  vmovaps xmm2, [rsp+0x20]
000074b6341d4d0a  vmovaps xmm3, [rsp+0x30]
000074b6341d4d10  vmovaps xmm4, [rsp+0x40]
000074b6341d4d16  vmovaps xmm5, [rsp+0x50]
000074b6341d4d1c  vmovaps xmm6, [rsp+0x60]
000074b6341d4d22  vmovaps xmm7, [rsp+0x70]
000074b6341d4d28  vmovaps xmm8, [rsp+0x80]
000074b6341d4d31  vmovaps xmm9, [rsp+0x90]
000074b6341d4d3a  vmovaps xmm10, [rsp+0xA0]
000074b6341d4d43  vmovaps xmm11, [rsp+0xB0]
000074b6341d4d4c  vmovaps xmm12, [rsp+0xC0]
000074b6341d4d55  vmovaps xmm13, [rsp+0xD0]
000074b6341d4d5e  vmovaps xmm15, [rsp+0xE0]
000074b6341d4d67  add rsp, 0xF0
000074b6341d4d6e  pop r11
000074b6341d4d70  pop r10
000074b6341d4d72  pop r9
000074b6341d4d74  pop r8
000074b6341d4d76  pop rsi
000074b6341d4d77  pop rdi
000074b6341d4d78  pop rdx
000074b6341d4d79  pop rcx
000074b6341d4d7a  pop rax
000074b6341d4d7b  add rsp, 0x08
000074b6341d4d7f  jmp 0x000074B6341D0203
000074b6341d4d84  sub rsp, 0x08
000074b6341d4d88  push rax
000074b6341d4d89  push rcx
000074b6341d4d8a  push rdx
000074b6341d4d8b  push rdi
000074b6341d4d8c  push rsi
000074b6341d4d8d  push r8
000074b6341d4d8f  push r9
000074b6341d4d91  push r10
000074b6341d4d93  push r11
000074b6341d4d95  sub rsp, 0xF0
000074b6341d4d9c  vmovaps [rsp], xmm0
000074b6341d4da1  vmovaps [rsp+0x10], xmm2
000074b6341d4da7  vmovaps [rsp+0x20], xmm3
000074b6341d4dad  vmovaps [rsp+0x30], xmm4
000074b6341d4db3  vmovaps [rsp+0x40], xmm5
000074b6341d4db9  vmovaps [rsp+0x50], xmm6
000074b6341d4dbf  vmovaps [rsp+0x60], xmm7
000074b6341d4dc5  vmovaps [rsp+0x70], xmm8
000074b6341d4dcb  vmovaps [rsp+0x80], xmm9
000074b6341d4dd4  vmovaps [rsp+0x90], xmm10
000074b6341d4ddd  vmovaps [rsp+0xA0], xmm11
000074b6341d4de6  vmovaps [rsp+0xB0], xmm12
000074b6341d4def  vmovaps [rsp+0xC0], xmm13
000074b6341d4df8  vmovaps [rsp+0xD0], xmm14
000074b6341d4e01  vmovaps [rsp+0xE0], xmm15
000074b6341d4e0a  sub rsp, 0x30
000074b6341d4e0e  movaps [rsp], xmm1
000074b6341d4e12  movaps [rsp+0x10], xmm12
000074b6341d4e18  movaps [rsp+0x20], xmm11
000074b6341d4e1e  lea rdi, [rsp]
000074b6341d4e22  mov esi, 0x00
000074b6341d4e27  mov rax, 0x5E1AA0A2F530
000074b6341d4e31  call rax
000074b6341d4e33  movaps xmm1, [rsp]
000074b6341d4e37  add rsp, 0x30
000074b6341d4e3b  vmovaps xmm0, [rsp]
000074b6341d4e40  vmovaps xmm2, [rsp+0x10]
000074b6341d4e46  vmovaps xmm3, [rsp+0x20]
000074b6341d4e4c  vmovaps xmm4, [rsp+0x30]
000074b6341d4e52  vmovaps xmm5, [rsp+0x40]
000074b6341d4e58  vmovaps xmm6, [rsp+0x50]
000074b6341d4e5e  vmovaps xmm7, [rsp+0x60]
000074b6341d4e64  vmovaps xmm8, [rsp+0x70]
000074b6341d4e6a  vmovaps xmm9, [rsp+0x80]
000074b6341d4e73  vmovaps xmm10, [rsp+0x90]
000074b6341d4e7c  vmovaps xmm11, [rsp+0xA0]
000074b6341d4e85  vmovaps xmm12, [rsp+0xB0]
000074b6341d4e8e  vmovaps xmm13, [rsp+0xC0]
000074b6341d4e97  vmovaps xmm14, [rsp+0xD0]
000074b6341d4ea0  vmovaps xmm15, [rsp+0xE0]
000074b6341d4ea9  add rsp, 0xF0
000074b6341d4eb0  pop r11
000074b6341d4eb2  pop r10
000074b6341d4eb4  pop r9
000074b6341d4eb6  pop r8
000074b6341d4eb8  pop rsi
000074b6341d4eb9  pop rdi
000074b6341d4eba  pop rdx
000074b6341d4ebb  pop rcx
000074b6341d4ebc  pop rax
000074b6341d4ebd  add rsp, 0x08
000074b6341d4ec1  jmp 0x000074B6341D0224
000074b6341d4ec6  call 0x000074B6340E20A0
000074b6341d4ecb  jmp 0x000074B6341D0232
000074b6341d4ed0  call 0x000074B634009D70
000074b6341d4ed5  jmp 0x000074B6341D023C
000074b6341d4eda  sub rsp, 0x08
000074b6341d4ede  push rax
000074b6341d4edf  push rcx
000074b6341d4ee0  push rdx
000074b6341d4ee1  push rdi
000074b6341d4ee2  push rsi
000074b6341d4ee3  push r8
000074b6341d4ee5  push r9
000074b6341d4ee7  push r10
000074b6341d4ee9  push r11
000074b6341d4eeb  sub rsp, 0xF0
000074b6341d4ef2  vmovaps [rsp], xmm0
000074b6341d4ef7  vmovaps [rsp+0x10], xmm1
000074b6341d4efd  vmovaps [rsp+0x20], xmm2
000074b6341d4f03  vmovaps [rsp+0x30], xmm3
000074b6341d4f09  vmovaps [rsp+0x40], xmm4
000074b6341d4f0f  vmovaps [rsp+0x50], xmm5
000074b6341d4f15  vmovaps [rsp+0x60], xmm6
000074b6341d4f1b  vmovaps [rsp+0x70], xmm8
000074b6341d4f21  vmovaps [rsp+0x80], xmm9
000074b6341d4f2a  vmovaps [rsp+0x90], xmm10
000074b6341d4f33  vmovaps [rsp+0xA0], xmm11
000074b6341d4f3c  vmovaps [rsp+0xB0], xmm12
000074b6341d4f45  vmovaps [rsp+0xC0], xmm13
000074b6341d4f4e  vmovaps [rsp+0xD0], xmm14
000074b6341d4f57  vmovaps [rsp+0xE0], xmm15
000074b6341d4f60  sub rsp, 0x30
000074b6341d4f64  movaps [rsp], xmm7
000074b6341d4f68  movaps [rsp+0x10], xmm15
000074b6341d4f6e  movaps [rsp+0x20], xmm10
000074b6341d4f74  lea rdi, [rsp]
000074b6341d4f78  mov esi, 0x00
000074b6341d4f7d  mov rax, 0x5E1AA0A2F530
000074b6341d4f87  call rax
000074b6341d4f89  movaps xmm7, [rsp]
000074b6341d4f8d  add rsp, 0x30
000074b6341d4f91  vmovaps xmm0, [rsp]
000074b6341d4f96  vmovaps xmm1, [rsp+0x10]
000074b6341d4f9c  vmovaps xmm2, [rsp+0x20]
000074b6341d4fa2  vmovaps xmm3, [rsp+0x30]
000074b6341d4fa8  vmovaps xmm4, [rsp+0x40]
000074b6341d4fae  vmovaps xmm5, [rsp+0x50]
000074b6341d4fb4  vmovaps xmm6, [rsp+0x60]
000074b6341d4fba  vmovaps xmm8, [rsp+0x70]
000074b6341d4fc0  vmovaps xmm9, [rsp+0x80]
000074b6341d4fc9  vmovaps xmm10, [rsp+0x90]
000074b6341d4fd2  vmovaps xmm11, [rsp+0xA0]
000074b6341d4fdb  vmovaps xmm12, [rsp+0xB0]
000074b6341d4fe4  vmovaps xmm13, [rsp+0xC0]
000074b6341d4fed  vmovaps xmm14, [rsp+0xD0]
000074b6341d4ff6  vmovaps xmm15, [rsp+0xE0]
000074b6341d4fff  add rsp, 0xF0
000074b6341d5006  pop r11
000074b6341d5008  pop r10
000074b6341d500a  pop r9
000074b6341d500c  pop r8
000074b6341d500e  pop rsi
000074b6341d500f  pop rdi
000074b6341d5010  pop rdx
000074b6341d5011  pop rcx
000074b6341d5012  pop rax
000074b6341d5013  add rsp, 0x08
000074b6341d5017  jmp 0x000074B6341D025D
000074b6341d501c  sub rsp, 0x08
000074b6341d5020  push rax
000074b6341d5021  push rcx
000074b6341d5022  push rdx
000074b6341d5023  push rdi
000074b6341d5024  push rsi
000074b6341d5025  push r8
000074b6341d5027  push r9
000074b6341d5029  push r10
000074b6341d502b  push r11
000074b6341d502d  sub rsp, 0xF0
000074b6341d5034  vmovaps [rsp], xmm0
000074b6341d5039  vmovaps [rsp+0x10], xmm1
000074b6341d503f  vmovaps [rsp+0x20], xmm2
000074b6341d5045  vmovaps [rsp+0x30], xmm3
000074b6341d504b  vmovaps [rsp+0x40], xmm4
000074b6341d5051  vmovaps [rsp+0x50], xmm5
000074b6341d5057  vmovaps [rsp+0x60], xmm6
000074b6341d505d  vmovaps [rsp+0x70], xmm7
000074b6341d5063  vmovaps [rsp+0x80], xmm8
000074b6341d506c  vmovaps [rsp+0x90], xmm9
000074b6341d5075  vmovaps [rsp+0xA0], xmm11
000074b6341d507e  vmovaps [rsp+0xB0], xmm12
000074b6341d5087  vmovaps [rsp+0xC0], xmm13
000074b6341d5090  vmovaps [rsp+0xD0], xmm14
000074b6341d5099  vmovaps [rsp+0xE0], xmm15
000074b6341d50a2  sub rsp, 0x30
000074b6341d50a6  movaps [rsp], xmm10
000074b6341d50ab  movaps [rsp+0x10], xmm11
000074b6341d50b1  movaps [rsp+0x20], xmm15
000074b6341d50b7  lea rdi, [rsp]
000074b6341d50bb  mov esi, 0x00
000074b6341d50c0  mov rax, 0x5E1AA0A2F530
000074b6341d50ca  call rax
000074b6341d50cc  movaps xmm10, [rsp]
000074b6341d50d1  add rsp, 0x30
000074b6341d50d5  vmovaps xmm0, [rsp]
000074b6341d50da  vmovaps xmm1, [rsp+0x10]
000074b6341d50e0  vmovaps xmm2, [rsp+0x20]
000074b6341d50e6  vmovaps xmm3, [rsp+0x30]
000074b6341d50ec  vmovaps xmm4, [rsp+0x40]
000074b6341d50f2  vmovaps xmm5, [rsp+0x50]
000074b6341d50f8  vmovaps xmm6, [rsp+0x60]
000074b6341d50fe  vmovaps xmm7, [rsp+0x70]
000074b6341d5104  vmovaps xmm8, [rsp+0x80]
000074b6341d510d  vmovaps xmm9, [rsp+0x90]
000074b6341d5116  vmovaps xmm11, [rsp+0xA0]
000074b6341d511f  vmovaps xmm12, [rsp+0xB0]
000074b6341d5128  vmovaps xmm13, [rsp+0xC0]
000074b6341d5131  vmovaps xmm14, [rsp+0xD0]
000074b6341d513a  vmovaps xmm15, [rsp+0xE0]
000074b6341d5143  add rsp, 0xF0
000074b6341d514a  pop r11
000074b6341d514c  pop r10
000074b6341d514e  pop r9
000074b6341d5150  pop r8
000074b6341d5152  pop rsi
000074b6341d5153  pop rdi
000074b6341d5154  pop rdx
000074b6341d5155  pop rcx
000074b6341d5156  pop rax
000074b6341d5157  add rsp, 0x08
000074b6341d515b  jmp 0x000074B6341D028B
000074b6341d5160  sub rsp, 0x08
000074b6341d5164  push rax
000074b6341d5165  push rcx
000074b6341d5166  push rdx
000074b6341d5167  push rdi
000074b6341d5168  push rsi
000074b6341d5169  push r8
000074b6341d516b  push r9
000074b6341d516d  push r10
000074b6341d516f  push r11
000074b6341d5171  sub rsp, 0xF0
000074b6341d5178  vmovaps [rsp], xmm0
000074b6341d517d  vmovaps [rsp+0x10], xmm1
000074b6341d5183  vmovaps [rsp+0x20], xmm2
000074b6341d5189  vmovaps [rsp+0x30], xmm3
000074b6341d518f  vmovaps [rsp+0x40], xmm4
000074b6341d5195  vmovaps [rsp+0x50], xmm5
000074b6341d519b  vmovaps [rsp+0x60], xmm6
000074b6341d51a1  vmovaps [rsp+0x70], xmm7
000074b6341d51a7  vmovaps [rsp+0x80], xmm8
000074b6341d51b0  vmovaps [rsp+0x90], xmm9
000074b6341d51b9  vmovaps [rsp+0xA0], xmm10
000074b6341d51c2  vmovaps [rsp+0xB0], xmm12
000074b6341d51cb  vmovaps [rsp+0xC0], xmm13
000074b6341d51d4  vmovaps [rsp+0xD0], xmm14
000074b6341d51dd  vmovaps [rsp+0xE0], xmm15
000074b6341d51e6  sub rsp, 0x30
000074b6341d51ea  movaps [rsp], xmm11
000074b6341d51ef  movaps [rsp+0x10], xmm12
000074b6341d51f5  movaps [rsp+0x20], xmm15
000074b6341d51fb  lea rdi, [rsp]
000074b6341d51ff  mov esi, 0x00
000074b6341d5204  mov rax, 0x5E1AA0A2F530
000074b6341d520e  call rax
000074b6341d5210  movaps xmm11, [rsp]
000074b6341d5215  add rsp, 0x30
000074b6341d5219  vmovaps xmm0, [rsp]
000074b6341d521e  vmovaps xmm1, [rsp+0x10]
000074b6341d5224  vmovaps xmm2, [rsp+0x20]
000074b6341d522a  vmovaps xmm3, [rsp+0x30]
000074b6341d5230  vmovaps xmm4, [rsp+0x40]
000074b6341d5236  vmovaps xmm5, [rsp+0x50]
000074b6341d523c  vmovaps xmm6, [rsp+0x60]
000074b6341d5242  vmovaps xmm7, [rsp+0x70]
000074b6341d5248  vmovaps xmm8, [rsp+0x80]
000074b6341d5251  vmovaps xmm9, [rsp+0x90]
000074b6341d525a  vmovaps xmm10, [rsp+0xA0]
000074b6341d5263  vmovaps xmm12, [rsp+0xB0]
000074b6341d526c  vmovaps xmm13, [rsp+0xC0]
000074b6341d5275  vmovaps xmm14, [rsp+0xD0]
000074b6341d527e  vmovaps xmm15, [rsp+0xE0]
000074b6341d5287  add rsp, 0xF0
000074b6341d528e  pop r11
000074b6341d5290  pop r10
000074b6341d5292  pop r9
000074b6341d5294  pop r8
000074b6341d5296  pop rsi
000074b6341d5297  pop rdi
000074b6341d5298  pop rdx
000074b6341d5299  pop rcx
000074b6341d529a  pop rax
000074b6341d529b  add rsp, 0x08
000074b6341d529f  jmp 0x000074B6341D02B9
000074b6341d52a4  sub rsp, 0x08
000074b6341d52a8  push rax
000074b6341d52a9  push rcx
000074b6341d52aa  push rdx
000074b6341d52ab  push rdi
000074b6341d52ac  push rsi
000074b6341d52ad  push r8
000074b6341d52af  push r9
000074b6341d52b1  push r10
000074b6341d52b3  push r11
000074b6341d52b5  sub rsp, 0xF0
000074b6341d52bc  vmovaps [rsp], xmm0
000074b6341d52c1  vmovaps [rsp+0x10], xmm1
000074b6341d52c7  vmovaps [rsp+0x20], xmm2
000074b6341d52cd  vmovaps [rsp+0x30], xmm3
000074b6341d52d3  vmovaps [rsp+0x40], xmm4
000074b6341d52d9  vmovaps [rsp+0x50], xmm5
000074b6341d52df  vmovaps [rsp+0x60], xmm6
000074b6341d52e5  vmovaps [rsp+0x70], xmm7
000074b6341d52eb  vmovaps [rsp+0x80], xmm8
000074b6341d52f4  vmovaps [rsp+0x90], xmm9
000074b6341d52fd  vmovaps [rsp+0xA0], xmm10
000074b6341d5306  vmovaps [rsp+0xB0], xmm11
000074b6341d530f  vmovaps [rsp+0xC0], xmm12
000074b6341d5318  vmovaps [rsp+0xD0], xmm13
000074b6341d5321  vmovaps [rsp+0xE0], xmm14
000074b6341d532a  sub rsp, 0x30
000074b6341d532e  movaps [rsp], xmm15
000074b6341d5333  movaps [rsp+0x10], xmm13
000074b6341d5339  movaps [rsp+0x20], xmm9
000074b6341d533f  lea rdi, [rsp]
000074b6341d5343  mov esi, 0x00
000074b6341d5348  mov rax, 0x5E1AA0A2F530
000074b6341d5352  call rax
000074b6341d5354  movaps xmm15, [rsp]
000074b6341d5359  add rsp, 0x30
000074b6341d535d  vmovaps xmm0, [rsp]
000074b6341d5362  vmovaps xmm1, [rsp+0x10]
000074b6341d5368  vmovaps xmm2, [rsp+0x20]
000074b6341d536e  vmovaps xmm3, [rsp+0x30]
000074b6341d5374  vmovaps xmm4, [rsp+0x40]
000074b6341d537a  vmovaps xmm5, [rsp+0x50]
000074b6341d5380  vmovaps xmm6, [rsp+0x60]
000074b6341d5386  vmovaps xmm7, [rsp+0x70]
000074b6341d538c  vmovaps xmm8, [rsp+0x80]
000074b6341d5395  vmovaps xmm9, [rsp+0x90]
000074b6341d539e  vmovaps xmm10, [rsp+0xA0]
000074b6341d53a7  vmovaps xmm11, [rsp+0xB0]
000074b6341d53b0  vmovaps xmm12, [rsp+0xC0]
000074b6341d53b9  vmovaps xmm13, [rsp+0xD0]
000074b6341d53c2  vmovaps xmm14, [rsp+0xE0]
000074b6341d53cb  add rsp, 0xF0
000074b6341d53d2  pop r11
000074b6341d53d4  pop r10
000074b6341d53d6  pop r9
000074b6341d53d8  pop r8
000074b6341d53da  pop rsi
000074b6341d53db  pop rdi
000074b6341d53dc  pop rdx
000074b6341d53dd  pop rcx
000074b6341d53de  pop rax
000074b6341d53df  add rsp, 0x08
000074b6341d53e3  jmp 0x000074B6341D02D4
000074b6341d53e8  sub rsp, 0x08
000074b6341d53ec  push rax
000074b6341d53ed  push rcx
000074b6341d53ee  push rdx
000074b6341d53ef  push rdi
000074b6341d53f0  push rsi
000074b6341d53f1  push r8
000074b6341d53f3  push r9
000074b6341d53f5  push r10
000074b6341d53f7  push r11
000074b6341d53f9  sub rsp, 0xF0
000074b6341d5400  vmovaps [rsp], xmm0
000074b6341d5405  vmovaps [rsp+0x10], xmm1
000074b6341d540b  vmovaps [rsp+0x20], xmm2
000074b6341d5411  vmovaps [rsp+0x30], xmm3
000074b6341d5417  vmovaps [rsp+0x40], xmm4
000074b6341d541d  vmovaps [rsp+0x50], xmm5
000074b6341d5423  vmovaps [rsp+0x60], xmm6
000074b6341d5429  vmovaps [rsp+0x70], xmm7
000074b6341d542f  vmovaps [rsp+0x80], xmm8
000074b6341d5438  vmovaps [rsp+0x90], xmm9
000074b6341d5441  vmovaps [rsp+0xA0], xmm10
000074b6341d544a  vmovaps [rsp+0xB0], xmm11
000074b6341d5453  vmovaps [rsp+0xC0], xmm12
000074b6341d545c  vmovaps [rsp+0xD0], xmm14
000074b6341d5465  vmovaps [rsp+0xE0], xmm15
000074b6341d546e  sub rsp, 0x30
000074b6341d5472  movaps [rsp], xmm13
000074b6341d5477  movaps [rsp+0x10], xmm8
000074b6341d547d  movaps [rsp+0x20], xmm14
000074b6341d5483  lea rdi, [rsp]
000074b6341d5487  mov esi, 0x00
000074b6341d548c  mov rax, 0x5E1AA0A2F530
000074b6341d5496  call rax
000074b6341d5498  movaps xmm13, [rsp]
000074b6341d549d  add rsp, 0x30
000074b6341d54a1  vmovaps xmm0, [rsp]
000074b6341d54a6  vmovaps xmm1, [rsp+0x10]
000074b6341d54ac  vmovaps xmm2, [rsp+0x20]
000074b6341d54b2  vmovaps xmm3, [rsp+0x30]
000074b6341d54b8  vmovaps xmm4, [rsp+0x40]
000074b6341d54be  vmovaps xmm5, [rsp+0x50]
000074b6341d54c4  vmovaps xmm6, [rsp+0x60]
000074b6341d54ca  vmovaps xmm7, [rsp+0x70]
000074b6341d54d0  vmovaps xmm8, [rsp+0x80]
000074b6341d54d9  vmovaps xmm9, [rsp+0x90]
000074b6341d54e2  vmovaps xmm10, [rsp+0xA0]
000074b6341d54eb  vmovaps xmm11, [rsp+0xB0]
000074b6341d54f4  vmovaps xmm12, [rsp+0xC0]
000074b6341d54fd  vmovaps xmm14, [rsp+0xD0]
000074b6341d5506  vmovaps xmm15, [rsp+0xE0]
000074b6341d550f  add rsp, 0xF0
000074b6341d5516  pop r11
000074b6341d5518  pop r10
000074b6341d551a  pop r9
000074b6341d551c  pop r8
000074b6341d551e  pop rsi
000074b6341d551f  pop rdi
000074b6341d5520  pop rdx
000074b6341d5521  pop rcx
000074b6341d5522  pop rax
000074b6341d5523  add rsp, 0x08
000074b6341d5527  jmp 0x000074B6341D02F7
000074b6341d552c  sub rsp, 0x08
000074b6341d5530  push rax
000074b6341d5531  push rcx
000074b6341d5532  push rdx
000074b6341d5533  push rdi
000074b6341d5534  push rsi
000074b6341d5535  push r8
000074b6341d5537  push r9
000074b6341d5539  push r10
000074b6341d553b  push r11
000074b6341d553d  sub rsp, 0xF0
000074b6341d5544  vmovaps [rsp], xmm0
000074b6341d5549  vmovaps [rsp+0x10], xmm1
000074b6341d554f  vmovaps [rsp+0x20], xmm2
000074b6341d5555  vmovaps [rsp+0x30], xmm3
000074b6341d555b  vmovaps [rsp+0x40], xmm4
000074b6341d5561  vmovaps [rsp+0x50], xmm5
000074b6341d5567  vmovaps [rsp+0x60], xmm6
000074b6341d556d  vmovaps [rsp+0x70], xmm7
000074b6341d5573  vmovaps [rsp+0x80], xmm8
000074b6341d557c  vmovaps [rsp+0x90], xmm9
000074b6341d5585  vmovaps [rsp+0xA0], xmm10
000074b6341d558e  vmovaps [rsp+0xB0], xmm11
000074b6341d5597  vmovaps [rsp+0xC0], xmm12
000074b6341d55a0  vmovaps [rsp+0xD0], xmm13
000074b6341d55a9  vmovaps [rsp+0xE0], xmm15
000074b6341d55b2  sub rsp, 0x30
000074b6341d55b6  movaps [rsp], xmm14
000074b6341d55bb  movaps [rsp+0x10], xmm1
000074b6341d55c0  movaps [rsp+0x20], xmm10
000074b6341d55c6  lea rdi, [rsp]
000074b6341d55ca  mov esi, 0x00
000074b6341d55cf  mov rax, 0x5E1AA0A2F530
000074b6341d55d9  call rax
000074b6341d55db  movaps xmm14, [rsp]
000074b6341d55e0  add rsp, 0x30
000074b6341d55e4  vmovaps xmm0, [rsp]
000074b6341d55e9  vmovaps xmm1, [rsp+0x10]
000074b6341d55ef  vmovaps xmm2, [rsp+0x20]
000074b6341d55f5  vmovaps xmm3, [rsp+0x30]
000074b6341d55fb  vmovaps xmm4, [rsp+0x40]
000074b6341d5601  vmovaps xmm5, [rsp+0x50]
000074b6341d5607  vmovaps xmm6, [rsp+0x60]
000074b6341d560d  vmovaps xmm7, [rsp+0x70]
000074b6341d5613  vmovaps xmm8, [rsp+0x80]
000074b6341d561c  vmovaps xmm9, [rsp+0x90]
000074b6341d5625  vmovaps xmm10, [rsp+0xA0]
000074b6341d562e  vmovaps xmm11, [rsp+0xB0]
000074b6341d5637  vmovaps xmm12, [rsp+0xC0]
000074b6341d5640  vmovaps xmm13, [rsp+0xD0]
000074b6341d5649  vmovaps xmm15, [rsp+0xE0]
000074b6341d5652  add rsp, 0xF0
000074b6341d5659  pop r11
000074b6341d565b  pop r10
000074b6341d565d  pop r9
000074b6341d565f  pop r8
000074b6341d5661  pop rsi
000074b6341d5662  pop rdi
000074b6341d5663  pop rdx
000074b6341d5664  pop rcx
000074b6341d5665  pop rax
000074b6341d5666  add rsp, 0x08
000074b6341d566a  jmp 0x000074B6341D031A
000074b6341d566f  sub rsp, 0x08
000074b6341d5673  push rax
000074b6341d5674  push rcx
000074b6341d5675  push rdx
000074b6341d5676  push rdi
000074b6341d5677  push rsi
000074b6341d5678  push r8
000074b6341d567a  push r9
000074b6341d567c  push r10
000074b6341d567e  push r11
000074b6341d5680  sub rsp, 0xF0
000074b6341d5687  vmovaps [rsp], xmm0
000074b6341d568c  vmovaps [rsp+0x10], xmm2
000074b6341d5692  vmovaps [rsp+0x20], xmm3
000074b6341d5698  vmovaps [rsp+0x30], xmm4
000074b6341d569e  vmovaps [rsp+0x40], xmm5
000074b6341d56a4  vmovaps [rsp+0x50], xmm6
000074b6341d56aa  vmovaps [rsp+0x60], xmm7
000074b6341d56b0  vmovaps [rsp+0x70], xmm8
000074b6341d56b6  vmovaps [rsp+0x80], xmm9
000074b6341d56bf  vmovaps [rsp+0x90], xmm10
000074b6341d56c8  vmovaps [rsp+0xA0], xmm11
000074b6341d56d1  vmovaps [rsp+0xB0], xmm12
000074b6341d56da  vmovaps [rsp+0xC0], xmm13
000074b6341d56e3  vmovaps [rsp+0xD0], xmm14
000074b6341d56ec  vmovaps [rsp+0xE0], xmm15
000074b6341d56f5  sub rsp, 0x30
000074b6341d56f9  movaps [rsp], xmm1
000074b6341d56fd  movaps [rsp+0x10], xmm7
000074b6341d5702  movaps [rsp+0x20], xmm11
000074b6341d5708  lea rdi, [rsp]
000074b6341d570c  mov esi, 0x00
000074b6341d5711  mov rax, 0x5E1AA0A2F530
000074b6341d571b  call rax
000074b6341d571d  movaps xmm1, [rsp]
000074b6341d5721  add rsp, 0x30
000074b6341d5725  vmovaps xmm0, [rsp]
000074b6341d572a  vmovaps xmm2, [rsp+0x10]
000074b6341d5730  vmovaps xmm3, [rsp+0x20]
000074b6341d5736  vmovaps xmm4, [rsp+0x30]
000074b6341d573c  vmovaps xmm5, [rsp+0x40]
000074b6341d5742  vmovaps xmm6, [rsp+0x50]
000074b6341d5748  vmovaps xmm7, [rsp+0x60]
000074b6341d574e  vmovaps xmm8, [rsp+0x70]
000074b6341d5754  vmovaps xmm9, [rsp+0x80]
000074b6341d575d  vmovaps xmm10, [rsp+0x90]
000074b6341d5766  vmovaps xmm11, [rsp+0xA0]
000074b6341d576f  vmovaps xmm12, [rsp+0xB0]
000074b6341d5778  vmovaps xmm13, [rsp+0xC0]
000074b6341d5781  vmovaps xmm14, [rsp+0xD0]
000074b6341d578a  vmovaps xmm15, [rsp+0xE0]
000074b6341d5793  add rsp, 0xF0
000074b6341d579a  pop r11
000074b6341d579c  pop r10
000074b6341d579e  pop r9
000074b6341d57a0  pop r8
000074b6341d57a2  pop rsi
000074b6341d57a3  pop rdi
000074b6341d57a4  pop rdx
000074b6341d57a5  pop rcx
000074b6341d57a6  pop rax
000074b6341d57a7  add rsp, 0x08
000074b6341d57ab  jmp 0x000074B6341D033B
000074b6341d57b0  call 0x000074B63400E880
000074b6341d57b5  jmp 0x000074B6341D034E
000074b6341d57ba  call 0x000074B63400C380
000074b6341d57bf  jmp 0x000074B6341D0359
000074b6341d57c4  call 0x000074B63400D600
000074b6341d57c9  jmp 0x000074B6341D0364
000074b6341d57ce  call 0x000074B633FFF540
000074b6341d57d3  jmp 0x000074B6341D036F
000074b6341d57d8  int3
000074b6341d57d9  nop [rax], eax
000074b6341d57e0  mov rax, [r15+0x40]
000074b6341d57e4  mov r14, [r15+0x58]
000074b6341d57e8  lea r12, [rax+r14*1]
000074b6341d57ec  movaps xmm1, [r15+0x1D0]
000074b6341d57f4  vmovaps [rsp+0x10], xmm1
000074b6341d57fa  vmovaps xmm15, [rsp+0x10]
000074b6341d5800  por xmm1, xmm15
000074b6341d5805  movaps xmm14, [r15+0x1A0]
000074b6341d580d  vmovaps [rsp+0x10], xmm14
000074b6341d5813  vmovaps xmm13, [rsp+0x10]
000074b6341d5819  por xmm14, xmm13
000074b6341d581e  lea rax, [r12+0x30]
000074b6341d5823  mov r11, [r13+rax*1]
000074b6341d5828  lea rax, [r12+0x38]
000074b6341d582d  mov r10, [r13+rax*1]
000074b6341d5832  movq xmm13, r11
000074b6341d5837  movq xmm12, r10
000074b6341d583c  movq xmm13, xmm13
000074b6341d5841  vmovaps [rsp+0x10], xmm13
000074b6341d5847  movq xmm13, xmm13
000074b6341d584c  movaps [r15+0x130], xmm13
000074b6341d5854  movq xmm12, xmm12
000074b6341d5859  vmovaps [rsp+0x20], xmm12
000074b6341d585f  movq xmm12, xmm12
000074b6341d5864  movaps [r15+0x280], xmm12
000074b6341d586c  movaps xmm13, [r15+0x270]
000074b6341d5874  vmovaps [rsp+0x30], xmm13
000074b6341d587a  vmovaps xmm12, [rsp+0x30]
000074b6341d5880  por xmm13, xmm12
000074b6341d5885  lea rax, [r12+0x20]
000074b6341d588a  mov r11, [r13+rax*1]
000074b6341d588f  lea rax, [r12+0x28]
000074b6341d5894  mov r10, [r13+rax*1]
000074b6341d5899  movq xmm12, r11
000074b6341d589e  movq xmm11, r10
000074b6341d58a3  movq xmm12, xmm12
000074b6341d58a8  vmovaps [rsp+0x30], xmm12
000074b6341d58ae  movq xmm12, xmm12
000074b6341d58b3  movaps [r15+0x150], xmm12
000074b6341d58bb  movq xmm11, xmm11
000074b6341d58c0  vmovaps [rsp+0x40], xmm11
000074b6341d58c6  movq xmm11, xmm11
000074b6341d58cb  movaps [r15+0x140], xmm11
000074b6341d58d3  lea rax, [r12+0x10]
000074b6341d58d8  mov r11, [r13+rax*1]
000074b6341d58dd  lea rax, [r12+0x18]
000074b6341d58e2  mov r10, [r13+rax*1]
000074b6341d58e7  movq xmm12, r11
000074b6341d58ec  movq xmm11, r10
000074b6341d58f1  movq xmm12, xmm12
000074b6341d58f6  vmovaps [rsp+0x50], xmm12
000074b6341d58fc  movq xmm12, xmm12
000074b6341d5901  movaps [r15+0x170], xmm12
000074b6341d5909  movq xmm11, xmm11
000074b6341d590e  vmovaps [rsp+0x60], xmm11
000074b6341d5914  movq xmm11, xmm11
000074b6341d5919  movaps [r15+0x160], xmm11
000074b6341d5921  mov rax, [r13+r12*1]
000074b6341d5926  vmovq xmm12, rax
000074b6341d592b  vpbroadcastq xmm12, xmm12
000074b6341d5930  lea rax, [r12+0x08]
000074b6341d5935  mov r12, [r13+rax*1]
000074b6341d593a  movq xmm11, r12
000074b6341d593f  movaps [r15+0x230], xmm11
000074b6341d5947  mov rax, [r15+0xF8]
000074b6341d594e  lea r12, [rax+0x50]
000074b6341d5952  movups xmm11, [r13+r12*1]
000074b6341d5958  lea r12, [rax+0x60]
000074b6341d595c  movups xmm10, [r13+r12*1]
000074b6341d5962  lea r12, [rax+0x30]
000074b6341d5966  movups xmm9, [r13+r12*1]
000074b6341d596c  mov r12, [r15+0x50]
000074b6341d5970  lea r11, [r12+r14*1]
000074b6341d5974  mov [r15+0x60], r11
000074b6341d5978  lea r12, [r14+0x40]
000074b6341d597c  mov [r15+0x58], r12
000074b6341d5980  movaps xmm8, xmm12
000074b6341d5984  mulpd xmm8, xmm15
000074b6341d5989  vcmppd xmm7, xmm8, xmm8, 0x03
000074b6341d598f  ptest xmm7, xmm7
000074b6341d5994  jnz 0x000074B6341D67B7
000074b6341d599a  movq xmm15, qword ptr [r15+0x230]
000074b6341d59a3  vmovaps [rsp+0x70], xmm15
000074b6341d59a9  vpermilpd xmm15, xmm15, 0x00
000074b6341d59af  movaps xmm7, xmm9
000074b6341d59b3  mulpd xmm7, xmm15
000074b6341d59b8  vcmppd xmm6, xmm7, xmm7, 0x03
000074b6341d59bd  ptest xmm6, xmm6
000074b6341d59c2  jnz 0x000074B6341D68FB
000074b6341d59c8  vxorps xmm15, xmm15, xmm15
000074b6341d59cd  vpbroadcastq xmm15, xmm15
000074b6341d59d2  movaps xmm9, xmm12
000074b6341d59d6  mulpd xmm9, xmm10
000074b6341d59db  vcmppd xmm6, xmm9, xmm9, 0x03
000074b6341d59e1  ptest xmm6, xmm6
000074b6341d59e6  jnz 0x000074B6341D6A3D
000074b6341d59ec  movaps xmm10, xmm12
000074b6341d59f0  mulpd xmm10, xmm11
000074b6341d59f5  vcmppd xmm6, xmm10, xmm10, 0x03
000074b6341d59fb  ptest xmm6, xmm6
000074b6341d5a00  jnz 0x000074B6341D6B81
000074b6341d5a06  movaps xmm11, [r15+0x1F0]
000074b6341d5a0e  movaps xmm6, xmm12
000074b6341d5a12  mulpd xmm6, xmm11
000074b6341d5a17  vcmppd xmm5, xmm6, xmm6, 0x03
000074b6341d5a1c  ptest xmm5, xmm5
000074b6341d5a21  jnz 0x000074B6341D6CC5
000074b6341d5a27  movaps xmm12, [r15+0x2A0]
000074b6341d5a2f  vmovaps [rsp+0x80], xmm12
000074b6341d5a38  vmovaps xmm11, [rsp+0x80]
000074b6341d5a41  por xmm12, xmm11
000074b6341d5a46  movaps xmm11, [r15+0x250]
000074b6341d5a4e  vmovaps [rsp+0x80], xmm11
000074b6341d5a57  vmovaps xmm5, [rsp+0x80]
000074b6341d5a60  por xmm11, xmm5
000074b6341d5a65  vmovaps xmm4, [rsp+0x70]
000074b6341d5a6b  vpermilpd xmm4, xmm4, 0x00
000074b6341d5a71  movaps xmm3, xmm5
000074b6341d5a74  mulpd xmm3, xmm4
000074b6341d5a78  vcmppd xmm2, xmm3, xmm3, 0x03
000074b6341d5a7d  ptest xmm2, xmm2
000074b6341d5a82  jnz 0x000074B6341D6E07
000074b6341d5a88  mov [rsp+0x80], rax
000074b6341d5a90  xor eax, eax
000074b6341d5a92  mov r14d, 0x200
000074b6341d5a98  cmp r12, r14
000074b6341d5a9b  cmc
000074b6341d5a9c  lahf
000074b6341d5a9d  seto al
000074b6341d5aa0  mov [r15+0x108], eax
000074b6341d5aa7  movaps xmm5, xmm8
000074b6341d5aab  addpd xmm5, xmm15
000074b6341d5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
000074b6341d5ab5  ptest xmm4, xmm4
000074b6341d5aba  jnz 0x000074B6341D6F47
000074b6341d5ac0  movaps xmm8, [r15+0x1B0]
000074b6341d5ac8  movaps xmm4, xmm9
000074b6341d5acc  addpd xmm4, xmm8
000074b6341d5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
000074b6341d5ad6  ptest xmm2, xmm2
000074b6341d5adb  jnz 0x000074B6341D7089
000074b6341d5ae1  movaps xmm9, xmm10
000074b6341d5ae5  addpd xmm9, xmm8
000074b6341d5aea  vcmppd xmm2, xmm9, xmm9, 0x03
000074b6341d5af0  ptest xmm2, xmm2
000074b6341d5af5  jnz 0x000074B6341D71CB
000074b6341d5afb  movaps xmm10, [r15+0x2F0]
000074b6341d5b03  vmovaps [rsp+0x90], xmm10
000074b6341d5b0c  vmovaps xmm8, [rsp+0x90]
000074b6341d5b15  por xmm10, xmm8
000074b6341d5b1a  movaps xmm8, [r15+0x2E0]
000074b6341d5b22  vmovaps [rsp+0x90], xmm8
000074b6341d5b2b  vmovaps xmm2, [rsp+0x90]
000074b6341d5b34  por xmm8, xmm2
000074b6341d5b39  movaps xmm2, [r15+0x2D0]
000074b6341d5b41  vmovaps [rsp+0x90], xmm2
000074b6341d5b4a  vmovaps [rsp+0xA0], xmm1
000074b6341d5b53  vmovaps xmm1, [rsp+0x90]
000074b6341d5b5c  por xmm2, xmm1
000074b6341d5b60  movaps xmm1, [r15+0x200]
000074b6341d5b68  vmovaps [rsp+0x90], xmm1
000074b6341d5b71  vmovaps [rsp+0xB0], xmm15
000074b6341d5b7a  vmovaps xmm15, [rsp+0x90]
000074b6341d5b83  por xmm1, xmm15
000074b6341d5b88  movaps xmm15, [r15+0x1C0]
000074b6341d5b90  vmovaps [rsp+0x90], xmm15
000074b6341d5b99  vmovaps [rsp+0xC0], xmm1
000074b6341d5ba2  vmovaps xmm1, [rsp+0x90]
000074b6341d5bab  por xmm15, xmm1
000074b6341d5bb0  movaps xmm1, [r15+0x190]
000074b6341d5bb8  vmovaps [rsp+0x90], xmm1
000074b6341d5bc1  vmovaps [rsp+0xD0], xmm15
000074b6341d5bca  vmovaps xmm15, [rsp+0x90]
000074b6341d5bd3  por xmm1, xmm15
000074b6341d5bd8  movaps xmm15, [r15+0x300]
000074b6341d5be0  vmovaps [rsp+0x90], xmm15
000074b6341d5be9  vmovaps [rsp+0xE0], xmm1
000074b6341d5bf2  vmovaps xmm1, [rsp+0x90]
000074b6341d5bfb  por xmm15, xmm1
000074b6341d5c00  mov rax, [rsp+0x80]
000074b6341d5c08  lea r14, [rax+0xA0]
000074b6341d5c0f  movups xmm1, [r13+r14*1]
000074b6341d5c15  lea r14, [rax+0xB0]
000074b6341d5c1c  vmovaps [rsp+0x80], xmm1
000074b6341d5c25  movups xmm1, [r13+r14*1]
000074b6341d5c2b  vmovaps [rsp+0x90], xmm1
000074b6341d5c34  vmovaps [rsp+0xF0], xmm15
000074b6341d5c3d  vmovaps xmm15, [rsp+0xB0]
000074b6341d5c46  vmovaps [rsp+0xB0], xmm14
000074b6341d5c4f  movaps xmm1, xmm6
000074b6341d5c52  addpd xmm1, xmm15
000074b6341d5c57  vcmppd xmm14, xmm1, xmm1, 0x03
000074b6341d5c5c  ptest xmm14, xmm14
000074b6341d5c62  jnz 0x000074B6341D7323
000074b6341d5c68  lea r14, [rax+0xF0]
000074b6341d5c6f  movups xmm15, [r13+r14*1]
000074b6341d5c75  movaps xmm14, xmm4
000074b6341d5c79  addpd xmm14, xmm3
000074b6341d5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
000074b6341d5c84  ptest xmm6, xmm6
000074b6341d5c89  jnz 0x000074B6341D746E
000074b6341d5c8f  movaps xmm6, xmm9
000074b6341d5c93  addpd xmm6, xmm7
000074b6341d5c97  vcmppd xmm4, xmm6, xmm6, 0x03
000074b6341d5c9c  ptest xmm4, xmm4
000074b6341d5ca1  jnz 0x000074B6341D75B0
000074b6341d5ca7  vmovaps xmm9, [rsp+0x70]
000074b6341d5cad  vpermilpd xmm9, xmm9, 0x00
000074b6341d5cb3  vmovaps xmm4, [rsp+0x90]
000074b6341d5cbc  movaps xmm7, xmm4
000074b6341d5cbf  mulpd xmm7, xmm9
000074b6341d5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
000074b6341d5cc9  ptest xmm3, xmm3
000074b6341d5cce  jnz 0x000074B6341D76F1
000074b6341d5cd4  vmovaps xmm9, [rsp+0x50]
000074b6341d5cda  vpermilpd xmm9, xmm9, 0x00
000074b6341d5ce0  movaps xmm4, xmm15
000074b6341d5ce4  mulpd xmm4, xmm9
000074b6341d5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
000074b6341d5cee  ptest xmm3, xmm3
000074b6341d5cf3  jnz 0x000074B6341D7832
000074b6341d5cf9  lea r14, [rax+0xE0]
000074b6341d5d00  movups xmm15, [r13+r14*1]
000074b6341d5d06  vmovaps xmm9, [rsp+0x70]
000074b6341d5d0c  vpermilpd xmm9, xmm9, 0x00
000074b6341d5d12  vmovaps [rsp+0x70], xmm1
000074b6341d5d18  vmovaps xmm1, [rsp+0x80]
000074b6341d5d21  vmovaps [rsp+0x80], xmm15
000074b6341d5d2a  movaps xmm3, xmm1
000074b6341d5d2d  mulpd xmm3, xmm9
000074b6341d5d32  vcmppd xmm15, xmm3, xmm3, 0x03
000074b6341d5d37  ptest xmm15, xmm15
000074b6341d5d3d  jnz 0x000074B6341D797E
000074b6341d5d43  vmovaps xmm1, [rsp+0xF0]
000074b6341d5d4c  vmovaps xmm15, [rsp+0xF0]
000074b6341d5d55  por xmm1, xmm15
000074b6341d5d5a  movaps [r15+0x300], xmm1
000074b6341d5d62  vmovaps xmm15, [rsp+0xE0]
000074b6341d5d6b  vmovaps xmm9, [rsp+0xE0]
000074b6341d5d74  por xmm15, xmm9
000074b6341d5d79  movaps [r15+0x190], xmm15
000074b6341d5d81  vmovaps xmm9, [rsp+0x50]
000074b6341d5d87  vpermilpd xmm9, xmm9, 0x00
000074b6341d5d8d  vmovaps [rsp+0x90], xmm1
000074b6341d5d96  vmovaps [rsp+0xE0], xmm15
000074b6341d5d9f  vmovaps xmm15, [rsp+0x80]
000074b6341d5da8  vmovaps [rsp+0x80], xmm14
000074b6341d5db1  movaps xmm1, xmm15
000074b6341d5db5  mulpd xmm1, xmm9
000074b6341d5dba  vcmppd xmm14, xmm1, xmm1, 0x03
000074b6341d5dbf  ptest xmm14, xmm14
000074b6341d5dc5  jnz 0x000074B6341D7ABF
000074b6341d5dcb  lea r14, [rax+0x90]
000074b6341d5dd2  movups xmm15, [r13+r14*1]
000074b6341d5dd8  vmovaps xmm14, [rsp+0xD0]
000074b6341d5de1  vmovaps xmm9, [rsp+0xD0]
000074b6341d5dea  por xmm14, xmm9
000074b6341d5def  movaps [r15+0x1C0], xmm14
000074b6341d5df7  vmovaps xmm9, [rsp+0xC0]
000074b6341d5e00  vmovaps [rsp+0xD0], xmm1
000074b6341d5e09  vmovaps xmm1, [rsp+0xC0]
000074b6341d5e12  por xmm9, xmm1
000074b6341d5e17  movaps [r15+0x200], xmm9
000074b6341d5e1f  vmovaps [rsp+0xC0], xmm2
000074b6341d5e28  vmovaps xmm1, [rsp+0xC0]
000074b6341d5e31  por xmm2, xmm1
000074b6341d5e35  movaps [r15+0x2D0], xmm2
000074b6341d5e3d  vmovaps [rsp+0xC0], xmm8
000074b6341d5e46  vmovaps xmm1, [rsp+0xC0]
000074b6341d5e4f  por xmm8, xmm1
000074b6341d5e54  movaps [r15+0x2E0], xmm8
000074b6341d5e5c  vmovaps [rsp+0xC0], xmm15
000074b6341d5e65  movaps xmm1, xmm5
000074b6341d5e68  addpd xmm1, xmm7
000074b6341d5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
000074b6341d5e71  ptest xmm15, xmm15
000074b6341d5e77  jnz 0x000074B6341D7C0B
000074b6341d5e7d  vmovaps xmm15, [rsp+0x50]
000074b6341d5e83  vpermilpd xmm15, xmm15, 0x00
000074b6341d5e89  vmovaps xmm5, [rsp+0xC0]
000074b6341d5e92  vmovaps [rsp+0xC0], xmm1
000074b6341d5e9b  movaps xmm7, xmm5
000074b6341d5e9e  mulpd xmm7, xmm15
000074b6341d5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
000074b6341d5ea8  ptest xmm1, xmm1
000074b6341d5ead  jnz 0x000074B6341D7D4B
000074b6341d5eb3  lea r14, [rax+0x80]
000074b6341d5eba  movups xmm1, [r13+r14*1]
000074b6341d5ec0  vmovaps xmm5, [rsp+0x70]
000074b6341d5ec6  vmovaps [rsp+0x70], xmm1
000074b6341d5ecc  movaps xmm15, xmm5
000074b6341d5ed0  addpd xmm15, xmm3
000074b6341d5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
000074b6341d5edb  ptest xmm1, xmm1
000074b6341d5ee0  jnz 0x000074B6341D7E96
000074b6341d5ee6  vmovaps xmm5, [rsp+0x80]
000074b6341d5eef  movaps xmm1, xmm5
000074b6341d5ef2  addpd xmm1, xmm4
000074b6341d5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
000074b6341d5efb  ptest xmm3, xmm3
000074b6341d5f00  jnz 0x000074B6341D7FD8
000074b6341d5f06  vmovaps [rsp+0x80], xmm10
000074b6341d5f0f  vmovaps xmm5, [rsp+0x80]
000074b6341d5f18  por xmm10, xmm5
000074b6341d5f1d  movaps [r15+0x2F0], xmm10
000074b6341d5f25  vmovaps xmm5, [rsp+0x50]
000074b6341d5f2b  vpermilpd xmm5, xmm5, 0x00
000074b6341d5f31  vmovaps xmm3, [rsp+0x70]
000074b6341d5f37  vmovaps [rsp+0x50], xmm1
000074b6341d5f3d  movaps xmm4, xmm3
000074b6341d5f40  mulpd xmm4, xmm5
000074b6341d5f44  vcmppd xmm1, xmm4, xmm4, 0x03
000074b6341d5f49  ptest xmm1, xmm1
000074b6341d5f4e  jnz 0x000074B6341D8118
000074b6341d5f54  lea r14, [rax+0xD0]
000074b6341d5f5b  movups xmm1, [r13+r14*1]
000074b6341d5f61  vmovaps xmm3, [rsp+0xD0]
000074b6341d5f6a  vmovaps [rsp+0x70], xmm1
000074b6341d5f70  movaps xmm5, xmm6
000074b6341d5f73  addpd xmm5, xmm3
000074b6341d5f77  vcmppd xmm1, xmm5, xmm5, 0x03
000074b6341d5f7c  ptest xmm1, xmm1
000074b6341d5f81  jnz 0x000074B6341D8262
000074b6341d5f87  vmovaps xmm1, [rsp+0x60]
000074b6341d5f8d  vpermilpd xmm1, xmm1, 0x00
000074b6341d5f93  movaps xmm6, xmm9
000074b6341d5f97  mulpd xmm6, xmm1
000074b6341d5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
000074b6341d5fa0  ptest xmm3, xmm3
000074b6341d5fa5  jnz 0x000074B6341D83A2
000074b6341d5fab  movaps [r15+0x260], xmm6
000074b6341d5fb3  vxorps xmm1, xmm1, xmm1
000074b6341d5fb7  vpbroadcastq xmm1, xmm1
000074b6341d5fbc  movaps [r15+0x1B0], xmm1
000074b6341d5fc4  vmovaps xmm1, [rsp+0x60]
000074b6341d5fca  vpermilpd xmm1, xmm1, 0x00
000074b6341d5fd0  vmovaps xmm3, [rsp+0x70]
000074b6341d5fd6  vmovaps [rsp+0x70], xmm15
000074b6341d5fdc  movaps xmm9, xmm3
000074b6341d5fe0  mulpd xmm9, xmm1
000074b6341d5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
000074b6341d5feb  ptest xmm15, xmm15
000074b6341d5ff1  jnz 0x000074B6341D84E3
000074b6341d5ff7  lea r14, [rax+0xC0]
000074b6341d5ffe  movups xmm1, [r13+r14*1]
000074b6341d6004  vmovaps xmm3, [rsp+0xC0]
000074b6341d600d  vmovaps [rsp+0x80], xmm1
000074b6341d6016  movaps xmm15, xmm3
000074b6341d601a  addpd xmm15, xmm7
000074b6341d601f  vcmppd xmm1, xmm15, xmm15, 0x03
000074b6341d6025  ptest xmm1, xmm1
000074b6341d602a  jnz 0x000074B6341D862F
000074b6341d6030  vmovaps [rsp+0xC0], xmm13
000074b6341d6039  vmovaps xmm1, [rsp+0xC0]
000074b6341d6042  por xmm13, xmm1
000074b6341d6047  movaps [r15+0x270], xmm13
000074b6341d604f  vmovaps xmm1, [rsp+0xB0]
000074b6341d6058  vmovaps xmm7, [rsp+0xB0]
000074b6341d6061  por xmm1, xmm7
000074b6341d6065  movaps [r15+0x1A0], xmm1
000074b6341d606d  vmovaps xmm1, [rsp+0x60]
000074b6341d6073  vpermilpd xmm1, xmm1, 0x00
000074b6341d6079  vmovaps [rsp+0xB0], xmm1
000074b6341d6082  vmovaps xmm1, [rsp+0x80]
000074b6341d608b  vmovaps [rsp+0x80], xmm15
000074b6341d6094  vmovaps xmm15, [rsp+0xB0]
000074b6341d609d  vmovaps [rsp+0xB0], xmm14
000074b6341d60a6  movaps xmm3, xmm1
000074b6341d60a9  mulpd xmm3, xmm15
000074b6341d60ae  vcmppd xmm14, xmm3, xmm3, 0x03
000074b6341d60b3  ptest xmm14, xmm14
000074b6341d60b9  jnz 0x000074B6341D8771
000074b6341d60bf  lea r14, [rax+0x20]
000074b6341d60c3  movups xmm1, [r13+r14*1]
000074b6341d60c9  movaps [r15+0x110], xmm1
000074b6341d60d1  vmovaps xmm14, [rsp+0x70]
000074b6341d60d7  vmovaps [rsp+0x70], xmm1
000074b6341d60dd  movaps xmm15, xmm14
000074b6341d60e1  addpd xmm15, xmm4
000074b6341d60e6  vcmppd xmm1, xmm15, xmm15, 0x03
000074b6341d60ec  ptest xmm1, xmm1
000074b6341d60f1  jnz 0x000074B6341D88BC
000074b6341d60f7  vmovaps xmm1, [rsp+0x60]
000074b6341d60fd  vpermilpd xmm1, xmm1, 0x00
000074b6341d6103  movaps xmm14, xmm2
000074b6341d6107  mulpd xmm14, xmm1
000074b6341d610c  vcmppd xmm4, xmm14, xmm14, 0x03
000074b6341d6112  ptest xmm4, xmm4
000074b6341d6117  jnz 0x000074B6341D89FF
000074b6341d611d  vmovaps xmm4, [rsp+0x50]
000074b6341d6123  movaps xmm1, xmm4
000074b6341d6126  addpd xmm1, xmm9
000074b6341d612b  vcmppd xmm2, xmm1, xmm1, 0x03
000074b6341d6130  ptest xmm2, xmm2
000074b6341d6135  jnz 0x000074B6341D8B41
000074b6341d613b  vmovaps xmm9, [rsp+0x30]
000074b6341d6141  vpermilpd xmm9, xmm9, 0x00
000074b6341d6147  vmovaps xmm2, [rsp+0x70]
000074b6341d614d  vmovaps [rsp+0x50], xmm1
000074b6341d6153  movaps xmm4, xmm2
000074b6341d6156  mulpd xmm4, xmm9
000074b6341d615b  vcmppd xmm1, xmm4, xmm4, 0x03
000074b6341d6160  ptest xmm1, xmm1
000074b6341d6165  jnz 0x000074B6341D8C82
000074b6341d616b  vmovaps xmm1, [rsp+0x30]
000074b6341d6171  vpermilpd xmm1, xmm1, 0x00
000074b6341d6177  vmovaps xmm2, [rsp+0x90]
000074b6341d6180  vmovaps [rsp+0x60], xmm15
000074b6341d6186  movaps xmm9, xmm2
000074b6341d618a  mulpd xmm9, xmm1
000074b6341d618f  vcmppd xmm15, xmm9, xmm9, 0x03
000074b6341d6195  ptest xmm15, xmm15
000074b6341d619b  jnz 0x000074B6341D8DC3
000074b6341d61a1  vmovaps xmm15, [rsp+0x80]
000074b6341d61aa  movaps xmm1, xmm15
000074b6341d61ae  addpd xmm1, xmm6
000074b6341d61b2  vcmppd xmm2, xmm1, xmm1, 0x03
000074b6341d61b7  ptest xmm2, xmm2
000074b6341d61bc  jnz 0x000074B6341D8F05
000074b6341d61c2  movaps xmm15, xmm5
000074b6341d61c6  addpd xmm15, xmm3
000074b6341d61cb  vcmppd xmm6, xmm15, xmm15, 0x03
000074b6341d61d1  ptest xmm6, xmm6
000074b6341d61d6  jnz 0x000074B6341D9046
000074b6341d61dc  vmovaps xmm6, [rsp+0x30]
000074b6341d61e2  vpermilpd xmm6, xmm6, 0x00
000074b6341d61e8  movaps xmm5, xmm8
000074b6341d61ec  mulpd xmm5, xmm6
000074b6341d61f0  vcmppd xmm3, xmm5, xmm5, 0x03
000074b6341d61f5  ptest xmm3, xmm3
000074b6341d61fa  jnz 0x000074B6341D9188
000074b6341d6200  vmovaps xmm8, [rsp+0x30]
000074b6341d6206  vpermilpd xmm8, xmm8, 0x00
000074b6341d620c  movaps xmm6, xmm10
000074b6341d6210  mulpd xmm6, xmm8
000074b6341d6215  vcmppd xmm3, xmm6, xmm6, 0x03
000074b6341d621a  ptest xmm3, xmm3
000074b6341d621f  jnz 0x000074B6341D92C9
000074b6341d6225  vmovaps xmm8, [rsp+0x60]
000074b6341d622b  movaps xmm10, xmm8
000074b6341d622f  addpd xmm10, xmm14
000074b6341d6234  vcmppd xmm3, xmm10, xmm10, 0x03
000074b6341d623a  ptest xmm3, xmm3
000074b6341d623f  jnz 0x000074B6341D940B
000074b6341d6245  vmovaps xmm8, [rsp+0x50]
000074b6341d624b  movaps xmm14, xmm8
000074b6341d624f  addpd xmm14, xmm4
000074b6341d6254  vcmppd xmm3, xmm14, xmm14, 0x03
000074b6341d625a  ptest xmm3, xmm3
000074b6341d625f  jnz 0x000074B6341D954F
000074b6341d6265  vmovaps xmm8, [rsp+0x40]
000074b6341d626b  vpermilpd xmm8, xmm8, 0x00
000074b6341d6271  movaps xmm4, xmm13
000074b6341d6275  mulpd xmm4, xmm8
000074b6341d627a  vcmppd xmm3, xmm4, xmm4, 0x03
000074b6341d627f  ptest xmm3, xmm3
000074b6341d6284  jnz 0x000074B6341D9692
000074b6341d628a  movaps xmm13, xmm15
000074b6341d628e  addpd xmm13, xmm9
000074b6341d6293  vcmppd xmm8, xmm13, xmm13, 0x03
000074b6341d6299  ptest xmm8, xmm8
000074b6341d629f  jnz 0x000074B6341D97D4
000074b6341d62a5  movaps xmm15, xmm1
000074b6341d62a9  addpd xmm15, xmm5
000074b6341d62ae  vcmppd xmm9, xmm15, xmm15, 0x03
000074b6341d62b4  ptest xmm9, xmm9
000074b6341d62ba  jnz 0x000074B6341D9918
000074b6341d62c0  vmovaps [rsp+0x30], xmm11
000074b6341d62c6  vmovaps xmm1, [rsp+0x30]
000074b6341d62cc  por xmm11, xmm1
000074b6341d62d1  movaps [r15+0x250], xmm11
000074b6341d62d9  vmovaps [rsp+0x30], xmm12
000074b6341d62df  vmovaps xmm1, [rsp+0x30]
000074b6341d62e5  por xmm12, xmm1
000074b6341d62ea  movaps [r15+0x2A0], xmm12
000074b6341d62f2  vmovaps xmm1, [rsp+0xA0]
000074b6341d62fb  vmovaps xmm11, [rsp+0xA0]
000074b6341d6304  por xmm1, xmm11
000074b6341d6309  movaps [r15+0x1D0], xmm1
000074b6341d6311  lea r14, [rax+0x40]
000074b6341d6315  movups xmm1, [r13+r14*1]
000074b6341d631b  movaps [r15+0x2C0], xmm1
000074b6341d6323  vmovaps xmm11, [rsp+0x40]
000074b6341d6329  vpermilpd xmm11, xmm11, 0x00
000074b6341d632f  vmovaps xmm8, [rsp+0xE0]
000074b6341d6338  movaps xmm9, xmm8
000074b6341d633c  mulpd xmm9, xmm11
000074b6341d6341  vcmppd xmm5, xmm9, xmm9, 0x03
000074b6341d6347  ptest xmm5, xmm5
000074b6341d634c  jnz 0x000074B6341D9A64
000074b6341d6352  movaps xmm11, xmm10
000074b6341d6356  addpd xmm11, xmm6
000074b6341d635b  vcmppd xmm8, xmm11, xmm11, 0x03
000074b6341d6361  ptest xmm8, xmm8
000074b6341d6367  jnz 0x000074B6341D9BA8
000074b6341d636d  movaps xmm10, xmm14
000074b6341d6371  addpd xmm10, xmm4
000074b6341d6376  vcmppd xmm8, xmm10, xmm10, 0x03
000074b6341d637c  ptest xmm8, xmm8
000074b6341d6382  jnz 0x000074B6341D9CEB
000074b6341d6388  vmovaps xmm14, [rsp+0x40]
000074b6341d638e  vpermilpd xmm14, xmm14, 0x00
000074b6341d6394  movaps xmm8, xmm1
000074b6341d6398  mulpd xmm8, xmm14
000074b6341d639d  vcmppd xmm6, xmm8, xmm8, 0x03
000074b6341d63a3  ptest xmm6, xmm6
000074b6341d63a8  jnz 0x000074B6341D9E2E
000074b6341d63ae  movaps xmm1, [r15+0x2B0]
000074b6341d63b6  vmovaps xmm14, [rsp+0x40]
000074b6341d63bc  vpermilpd xmm14, xmm14, 0x00
000074b6341d63c2  movaps xmm6, xmm1
000074b6341d63c5  mulpd xmm6, xmm14
000074b6341d63ca  vcmppd xmm5, xmm6, xmm6, 0x03
000074b6341d63cf  ptest xmm5, xmm5
000074b6341d63d4  jnz 0x000074B6341D9F71
000074b6341d63da  vmovaps xmm1, [rsp+0x10]
000074b6341d63e0  vpermilpd xmm1, xmm1, 0x00
000074b6341d63e6  movaps xmm14, xmm12
000074b6341d63ea  mulpd xmm14, xmm1
000074b6341d63ef  vcmppd xmm5, xmm14, xmm14, 0x03
000074b6341d63f5  ptest xmm5, xmm5
000074b6341d63fa  jnz 0x000074B6341DA0B2
000074b6341d6400  movaps xmm1, xmm13
000074b6341d6404  addpd xmm1, xmm9
000074b6341d6409  vcmppd xmm12, xmm1, xmm1, 0x03
000074b6341d640e  ptest xmm12, xmm12
000074b6341d6414  jnz 0x000074B6341DA1F5
000074b6341d641a  vmovaps xmm13, [rsp+0x10]
000074b6341d6420  vpermilpd xmm13, xmm13, 0x00
000074b6341d6426  movaps xmm12, xmm7
000074b6341d642a  mulpd xmm12, xmm13
000074b6341d642f  vcmppd xmm9, xmm12, xmm12, 0x03
000074b6341d6435  ptest xmm9, xmm9
000074b6341d643b  jnz 0x000074B6341DA337
000074b6341d6441  movaps xmm13, xmm15
000074b6341d6445  addpd xmm13, xmm8
000074b6341d644a  vcmppd xmm9, xmm13, xmm13, 0x03
000074b6341d6450  ptest xmm9, xmm9
000074b6341d6456  jnz 0x000074B6341DA47A
000074b6341d645c  movaps xmm15, [r15+0x290]
000074b6341d6464  vmovaps xmm9, [rsp+0x10]
000074b6341d646a  vpermilpd xmm9, xmm9, 0x00
000074b6341d6470  movaps xmm8, xmm15
000074b6341d6474  mulpd xmm8, xmm9
000074b6341d6479  vcmppd xmm7, xmm8, xmm8, 0x03
000074b6341d647f  ptest xmm7, xmm7
000074b6341d6484  jnz 0x000074B6341DA5BE
000074b6341d648a  movaps xmm15, xmm11
000074b6341d648e  addpd xmm15, xmm6
000074b6341d6493  vcmppd xmm9, xmm15, xmm15, 0x03
000074b6341d6499  ptest xmm9, xmm9
000074b6341d649f  jnz 0x000074B6341DA702
000074b6341d64a5  movaps xmm11, [r15+0x1E0]
000074b6341d64ad  vmovaps xmm9, [rsp+0x10]
000074b6341d64b3  vpermilpd xmm9, xmm9, 0x00
000074b6341d64b9  movaps xmm7, xmm11
000074b6341d64bd  mulpd xmm7, xmm9
000074b6341d64c2  vcmppd xmm6, xmm7, xmm7, 0x03
000074b6341d64c7  ptest xmm6, xmm6
000074b6341d64cc  jnz 0x000074B6341DA845
000074b6341d64d2  movaps xmm11, xmm10
000074b6341d64d6  addpd xmm11, xmm14
000074b6341d64db  vcmppd xmm9, xmm11, xmm11, 0x03
000074b6341d64e1  ptest xmm9, xmm9
000074b6341d64e7  jnz 0x000074B6341DA987
000074b6341d64ed  lea r14, [rax+0x70]
000074b6341d64f1  movups xmm14, [r13+r14*1]
000074b6341d64f7  movaps [r15+0x240], xmm14
000074b6341d64ff  movaps xmm10, xmm1
000074b6341d6503  addpd xmm10, xmm12
000074b6341d6508  vcmppd xmm9, xmm10, xmm10, 0x03
000074b6341d650e  ptest xmm9, xmm9
000074b6341d6514  jnz 0x000074B6341DAAD5
000074b6341d651a  movaps [r15+0x170], xmm10
000074b6341d6522  vmovaps xmm1, [rsp+0x20]
000074b6341d6528  vpermilpd xmm1, xmm1, 0x00
000074b6341d652e  movaps xmm12, xmm14
000074b6341d6532  mulpd xmm12, xmm1
000074b6341d6537  vcmppd xmm9, xmm12, xmm12, 0x03
000074b6341d653d  ptest xmm9, xmm9
000074b6341d6543  jnz 0x000074B6341DAC18
000074b6341d6549  vmovaps xmm1, [rsp+0x20]
000074b6341d654f  vpermilpd xmm1, xmm1, 0x00
000074b6341d6555  vmovaps xmm9, [rsp+0xB0]
000074b6341d655e  movaps xmm14, xmm9
000074b6341d6562  mulpd xmm14, xmm1
000074b6341d6567  vcmppd xmm6, xmm14, xmm14, 0x03
000074b6341d656d  ptest xmm6, xmm6
000074b6341d6572  jnz 0x000074B6341DAD5B
000074b6341d6578  movaps [r15+0x180], xmm14
000074b6341d6580  movaps xmm1, xmm13
000074b6341d6584  addpd xmm1, xmm8
000074b6341d6589  vcmppd xmm9, xmm1, xmm1, 0x03
000074b6341d658e  ptest xmm9, xmm9
000074b6341d6594  jnz 0x000074B6341DAE9E
000074b6341d659a  movaps [r15+0x210], xmm1
000074b6341d65a2  movups xmm13, [r13+rax*1]
000074b6341d65a8  lea r14, [rax+0x10]
000074b6341d65ac  movups xmm9, [r13+r14*1]
000074b6341d65b2  movaps [r15+0x230], xmm9
000074b6341d65ba  movaps xmm8, xmm15
000074b6341d65be  addpd xmm8, xmm7
000074b6341d65c3  vcmppd xmm6, xmm8, xmm8, 0x03
000074b6341d65c9  ptest xmm6, xmm6
000074b6341d65ce  jnz 0x000074B6341DAFF4
000074b6341d65d4  movaps [r15+0x130], xmm8
000074b6341d65dc  vmovaps xmm15, [rsp+0x20]
000074b6341d65e2  vpermilpd xmm15, xmm15, 0x00
000074b6341d65e8  movaps xmm7, xmm9
000074b6341d65ec  mulpd xmm7, xmm15
000074b6341d65f1  vcmppd xmm6, xmm7, xmm7, 0x03
000074b6341d65f6  ptest xmm6, xmm6
000074b6341d65fb  jnz 0x000074B6341DB137
000074b6341d6601  movaps [r15+0x220], xmm7
000074b6341d6609  vmovaps xmm15, [rsp+0x20]
000074b6341d660f  vpermilpd xmm15, xmm15, 0x00
000074b6341d6615  movaps xmm9, xmm13
000074b6341d6619  mulpd xmm9, xmm15
000074b6341d661e  vcmppd xmm6, xmm9, xmm9, 0x03
000074b6341d6624  ptest xmm6, xmm6
000074b6341d6629  jnz 0x000074B6341DB279
000074b6341d662f  movaps xmm15, xmm11
000074b6341d6633  addpd xmm15, xmm12
000074b6341d6638  vcmppd xmm13, xmm15, xmm15, 0x03
000074b6341d663e  ptest xmm13, xmm13
000074b6341d6644  jnz 0x000074B6341DB3BD
000074b6341d664a  movaps [r15+0x140], xmm15
000074b6341d6652  movaps xmm13, xmm10
000074b6341d6656  addpd xmm13, xmm14
000074b6341d665b  vcmppd xmm12, xmm13, xmm13, 0x03
000074b6341d6661  ptest xmm12, xmm12
000074b6341d6667  jnz 0x000074B6341DB501
000074b6341d666d  movaps [r15+0x150], xmm13
000074b6341d6675  movaps xmm14, xmm1
000074b6341d6679  addpd xmm14, xmm7
000074b6341d667e  vcmppd xmm12, xmm14, xmm14, 0x03
000074b6341d6684  ptest xmm12, xmm12
000074b6341d668a  jnz 0x000074B6341DB645
000074b6341d6690  movaps [r15+0x160], xmm14
000074b6341d6698  movaps xmm1, xmm8
000074b6341d669c  addpd xmm1, xmm9
000074b6341d66a1  vcmppd xmm12, xmm1, xmm1, 0x03
000074b6341d66a6  ptest xmm12, xmm12
000074b6341d66ac  jnz 0x000074B6341DB787
000074b6341d66b2  movaps [r15+0x120], xmm1
000074b6341d66ba  movups [r13+r11*1], xmm15
000074b6341d66c0  lea rax, [r11+0x10]
000074b6341d66c4  movups [r13+rax*1], xmm13
000074b6341d66ca  lea rax, [r11+0x20]
000074b6341d66ce  movups [r13+rax*1], xmm14
000074b6341d66d4  lea rax, [r11+0x30]
000074b6341d66d8  movups [r13+rax*1], xmm1
000074b6341d66de  mov eax, [r15+0x108]
000074b6341d66e5  sahf
000074b6341d66e6  jnz 0x000074B6341D6718
000074b6341d66e8  cmp dword ptr [r15+0x318], 0x00
000074b6341d66f0  jz 0x000074B6341DB900
000074b6341d66f6  nop [rax+rax*1], ax
000074b6341d66ff  nop [rax+rax*1], eax
000074b6341d6707  mov eax, 0x410444
000074b6341d670c  mov [r15+0x100], rax
000074b6341d6713  jmp 0x000074B633FFE110
000074b6341d6718  cmp dword ptr [r15+0x318], 0x00
000074b6341d6720  jz 0x000074B6341D57E0
000074b6341d6726  nop [rax+rax*1], ax
000074b6341d672f  nop [rax+rax*1], eax
000074b6341d6737  mov eax, 0x410278
000074b6341d673c  mov [r15+0x100], rax
000074b6341d6743  jmp 0x000074B633FFE110
000074b6341d6748  int3
000074b6341d6749  call 0x000074B63400A4B0
000074b6341d674e  jmp 0x000074B6341D5828
000074b6341d6753  call 0x000074B634009240
000074b6341d6758  jmp 0x000074B6341D5832
000074b6341d675d  call 0x000074B63400A4B0
000074b6341d6762  jmp 0x000074B6341D588F
000074b6341d6767  call 0x000074B634009240
000074b6341d676c  jmp 0x000074B6341D5899
000074b6341d6771  call 0x000074B63400A4B0
000074b6341d6776  jmp 0x000074B6341D58DD
000074b6341d677b  call 0x000074B634009240
000074b6341d6780  jmp 0x000074B6341D58E7
000074b6341d6785  call 0x000074B6340B47C0
000074b6341d678a  jmp 0x000074B6341D5926
000074b6341d678f  call 0x000074B63400B720
000074b6341d6794  jmp 0x000074B6341D593A
000074b6341d6799  call 0x000074B6340BFC30
000074b6341d679e  jmp 0x000074B6341D5958
000074b6341d67a3  call 0x000074B6340BE9C0
000074b6341d67a8  jmp 0x000074B6341D5962
000074b6341d67ad  call 0x000074B6340BD750
000074b6341d67b2  jmp 0x000074B6341D596C
000074b6341d67b7  sub rsp, 0x08
000074b6341d67bb  push rax
000074b6341d67bc  push rcx
000074b6341d67bd  push rdx
000074b6341d67be  push rdi
000074b6341d67bf  push rsi
000074b6341d67c0  push r8
000074b6341d67c2  push r9
000074b6341d67c4  push r10
000074b6341d67c6  push r11
000074b6341d67c8  sub rsp, 0xF0
000074b6341d67cf  vmovaps [rsp], xmm0
000074b6341d67d4  vmovaps [rsp+0x10], xmm1
000074b6341d67da  vmovaps [rsp+0x20], xmm2
000074b6341d67e0  vmovaps [rsp+0x30], xmm3
000074b6341d67e6  vmovaps [rsp+0x40], xmm4
000074b6341d67ec  vmovaps [rsp+0x50], xmm5
000074b6341d67f2  vmovaps [rsp+0x60], xmm6
000074b6341d67f8  vmovaps [rsp+0x70], xmm7
000074b6341d67fe  vmovaps [rsp+0x80], xmm9
000074b6341d6807  vmovaps [rsp+0x90], xmm10
000074b6341d6810  vmovaps [rsp+0xA0], xmm11
000074b6341d6819  vmovaps [rsp+0xB0], xmm12
000074b6341d6822  vmovaps [rsp+0xC0], xmm13
000074b6341d682b  vmovaps [rsp+0xD0], xmm14
000074b6341d6834  vmovaps [rsp+0xE0], xmm15
000074b6341d683d  sub rsp, 0x30
000074b6341d6841  movaps [rsp], xmm8
000074b6341d6846  movaps [rsp+0x10], xmm12
000074b6341d684c  movaps [rsp+0x20], xmm15
000074b6341d6852  lea rdi, [rsp]
000074b6341d6856  mov esi, 0x00
000074b6341d685b  mov rax, 0x5E1AA0A2F530
000074b6341d6865  call rax
000074b6341d6867  movaps xmm8, [rsp]
000074b6341d686c  add rsp, 0x30
000074b6341d6870  vmovaps xmm0, [rsp]
000074b6341d6875  vmovaps xmm1, [rsp+0x10]
000074b6341d687b  vmovaps xmm2, [rsp+0x20]
000074b6341d6881  vmovaps xmm3, [rsp+0x30]
000074b6341d6887  vmovaps xmm4, [rsp+0x40]
000074b6341d688d  vmovaps xmm5, [rsp+0x50]
000074b6341d6893  vmovaps xmm6, [rsp+0x60]
000074b6341d6899  vmovaps xmm7, [rsp+0x70]
000074b6341d689f  vmovaps xmm9, [rsp+0x80]
000074b6341d68a8  vmovaps xmm10, [rsp+0x90]
000074b6341d68b1  vmovaps xmm11, [rsp+0xA0]
000074b6341d68ba  vmovaps xmm12, [rsp+0xB0]
000074b6341d68c3  vmovaps xmm13, [rsp+0xC0]
000074b6341d68cc  vmovaps xmm14, [rsp+0xD0]
000074b6341d68d5  vmovaps xmm15, [rsp+0xE0]
000074b6341d68de  add rsp, 0xF0
000074b6341d68e5  pop r11
000074b6341d68e7  pop r10
000074b6341d68e9  pop r9
000074b6341d68eb  pop r8
000074b6341d68ed  pop rsi
000074b6341d68ee  pop rdi
000074b6341d68ef  pop rdx
000074b6341d68f0  pop rcx
000074b6341d68f1  pop rax
000074b6341d68f2  add rsp, 0x08
000074b6341d68f6  jmp 0x000074B6341D599A
000074b6341d68fb  sub rsp, 0x08
000074b6341d68ff  push rax
000074b6341d6900  push rcx
000074b6341d6901  push rdx
000074b6341d6902  push rdi
000074b6341d6903  push rsi
000074b6341d6904  push r8
000074b6341d6906  push r9
000074b6341d6908  push r10
000074b6341d690a  push r11
000074b6341d690c  sub rsp, 0xF0
000074b6341d6913  vmovaps [rsp], xmm0
000074b6341d6918  vmovaps [rsp+0x10], xmm1
000074b6341d691e  vmovaps [rsp+0x20], xmm2
000074b6341d6924  vmovaps [rsp+0x30], xmm3
000074b6341d692a  vmovaps [rsp+0x40], xmm4
000074b6341d6930  vmovaps [rsp+0x50], xmm5
000074b6341d6936  vmovaps [rsp+0x60], xmm6
000074b6341d693c  vmovaps [rsp+0x70], xmm8
000074b6341d6942  vmovaps [rsp+0x80], xmm9
000074b6341d694b  vmovaps [rsp+0x90], xmm10
000074b6341d6954  vmovaps [rsp+0xA0], xmm11
000074b6341d695d  vmovaps [rsp+0xB0], xmm12
000074b6341d6966  vmovaps [rsp+0xC0], xmm13
000074b6341d696f  vmovaps [rsp+0xD0], xmm14
000074b6341d6978  vmovaps [rsp+0xE0], xmm15
000074b6341d6981  sub rsp, 0x30
000074b6341d6985  movaps [rsp], xmm7
000074b6341d6989  movaps [rsp+0x10], xmm9
000074b6341d698f  movaps [rsp+0x20], xmm15
000074b6341d6995  lea rdi, [rsp]
000074b6341d6999  mov esi, 0x00
000074b6341d699e  mov rax, 0x5E1AA0A2F530
000074b6341d69a8  call rax
000074b6341d69aa  movaps xmm7, [rsp]
000074b6341d69ae  add rsp, 0x30
000074b6341d69b2  vmovaps xmm0, [rsp]
000074b6341d69b7  vmovaps xmm1, [rsp+0x10]
000074b6341d69bd  vmovaps xmm2, [rsp+0x20]
000074b6341d69c3  vmovaps xmm3, [rsp+0x30]
000074b6341d69c9  vmovaps xmm4, [rsp+0x40]
000074b6341d69cf  vmovaps xmm5, [rsp+0x50]
000074b6341d69d5  vmovaps xmm6, [rsp+0x60]
000074b6341d69db  vmovaps xmm8, [rsp+0x70]
000074b6341d69e1  vmovaps xmm9, [rsp+0x80]
000074b6341d69ea  vmovaps xmm10, [rsp+0x90]
000074b6341d69f3  vmovaps xmm11, [rsp+0xA0]
000074b6341d69fc  vmovaps xmm12, [rsp+0xB0]
000074b6341d6a05  vmovaps xmm13, [rsp+0xC0]
000074b6341d6a0e  vmovaps xmm14, [rsp+0xD0]
000074b6341d6a17  vmovaps xmm15, [rsp+0xE0]
000074b6341d6a20  add rsp, 0xF0
000074b6341d6a27  pop r11
000074b6341d6a29  pop r10
000074b6341d6a2b  pop r9
000074b6341d6a2d  pop r8
000074b6341d6a2f  pop rsi
000074b6341d6a30  pop rdi
000074b6341d6a31  pop rdx
000074b6341d6a32  pop rcx
000074b6341d6a33  pop rax
000074b6341d6a34  add rsp, 0x08
000074b6341d6a38  jmp 0x000074B6341D59C8
000074b6341d6a3d  sub rsp, 0x08
000074b6341d6a41  push rax
000074b6341d6a42  push rcx
000074b6341d6a43  push rdx
000074b6341d6a44  push rdi
000074b6341d6a45  push rsi
000074b6341d6a46  push r8
000074b6341d6a48  push r9
000074b6341d6a4a  push r10
000074b6341d6a4c  push r11
000074b6341d6a4e  sub rsp, 0xF0
000074b6341d6a55  vmovaps [rsp], xmm0
000074b6341d6a5a  vmovaps [rsp+0x10], xmm1
000074b6341d6a60  vmovaps [rsp+0x20], xmm2
000074b6341d6a66  vmovaps [rsp+0x30], xmm3
000074b6341d6a6c  vmovaps [rsp+0x40], xmm4
000074b6341d6a72  vmovaps [rsp+0x50], xmm5
000074b6341d6a78  vmovaps [rsp+0x60], xmm6
000074b6341d6a7e  vmovaps [rsp+0x70], xmm7
000074b6341d6a84  vmovaps [rsp+0x80], xmm8
000074b6341d6a8d  vmovaps [rsp+0x90], xmm10
000074b6341d6a96  vmovaps [rsp+0xA0], xmm11
000074b6341d6a9f  vmovaps [rsp+0xB0], xmm12
000074b6341d6aa8  vmovaps [rsp+0xC0], xmm13
000074b6341d6ab1  vmovaps [rsp+0xD0], xmm14
000074b6341d6aba  vmovaps [rsp+0xE0], xmm15
000074b6341d6ac3  sub rsp, 0x30
000074b6341d6ac7  movaps [rsp], xmm9
000074b6341d6acc  movaps [rsp+0x10], xmm12
000074b6341d6ad2  movaps [rsp+0x20], xmm10
000074b6341d6ad8  lea rdi, [rsp]
000074b6341d6adc  mov esi, 0x00
000074b6341d6ae1  mov rax, 0x5E1AA0A2F530
000074b6341d6aeb  call rax
000074b6341d6aed  movaps xmm9, [rsp]
000074b6341d6af2  add rsp, 0x30
000074b6341d6af6  vmovaps xmm0, [rsp]
000074b6341d6afb  vmovaps xmm1, [rsp+0x10]
000074b6341d6b01  vmovaps xmm2, [rsp+0x20]
000074b6341d6b07  vmovaps xmm3, [rsp+0x30]
000074b6341d6b0d  vmovaps xmm4, [rsp+0x40]
000074b6341d6b13  vmovaps xmm5, [rsp+0x50]
000074b6341d6b19  vmovaps xmm6, [rsp+0x60]
000074b6341d6b1f  vmovaps xmm7, [rsp+0x70]
000074b6341d6b25  vmovaps xmm8, [rsp+0x80]
000074b6341d6b2e  vmovaps xmm10, [rsp+0x90]
000074b6341d6b37  vmovaps xmm11, [rsp+0xA0]
000074b6341d6b40  vmovaps xmm12, [rsp+0xB0]
000074b6341d6b49  vmovaps xmm13, [rsp+0xC0]
000074b6341d6b52  vmovaps xmm14, [rsp+0xD0]
000074b6341d6b5b  vmovaps xmm15, [rsp+0xE0]
000074b6341d6b64  add rsp, 0xF0
000074b6341d6b6b  pop r11
000074b6341d6b6d  pop r10
000074b6341d6b6f  pop r9
000074b6341d6b71  pop r8
000074b6341d6b73  pop rsi
000074b6341d6b74  pop rdi
000074b6341d6b75  pop rdx
000074b6341d6b76  pop rcx
000074b6341d6b77  pop rax
000074b6341d6b78  add rsp, 0x08
000074b6341d6b7c  jmp 0x000074B6341D59EC
000074b6341d6b81  sub rsp, 0x08
000074b6341d6b85  push rax
000074b6341d6b86  push rcx
000074b6341d6b87  push rdx
000074b6341d6b88  push rdi
000074b6341d6b89  push rsi
000074b6341d6b8a  push r8
000074b6341d6b8c  push r9
000074b6341d6b8e  push r10
000074b6341d6b90  push r11
000074b6341d6b92  sub rsp, 0xF0
000074b6341d6b99  vmovaps [rsp], xmm0
000074b6341d6b9e  vmovaps [rsp+0x10], xmm1
000074b6341d6ba4  vmovaps [rsp+0x20], xmm2
000074b6341d6baa  vmovaps [rsp+0x30], xmm3
000074b6341d6bb0  vmovaps [rsp+0x40], xmm4
000074b6341d6bb6  vmovaps [rsp+0x50], xmm5
000074b6341d6bbc  vmovaps [rsp+0x60], xmm6
000074b6341d6bc2  vmovaps [rsp+0x70], xmm7
000074b6341d6bc8  vmovaps [rsp+0x80], xmm8
000074b6341d6bd1  vmovaps [rsp+0x90], xmm9
000074b6341d6bda  vmovaps [rsp+0xA0], xmm11
000074b6341d6be3  vmovaps [rsp+0xB0], xmm12
000074b6341d6bec  vmovaps [rsp+0xC0], xmm13
000074b6341d6bf5  vmovaps [rsp+0xD0], xmm14
000074b6341d6bfe  vmovaps [rsp+0xE0], xmm15
000074b6341d6c07  sub rsp, 0x30
000074b6341d6c0b  movaps [rsp], xmm10
000074b6341d6c10  movaps [rsp+0x10], xmm12
000074b6341d6c16  movaps [rsp+0x20], xmm11
000074b6341d6c1c  lea rdi, [rsp]
000074b6341d6c20  mov esi, 0x00
000074b6341d6c25  mov rax, 0x5E1AA0A2F530
000074b6341d6c2f  call rax
000074b6341d6c31  movaps xmm10, [rsp]
000074b6341d6c36  add rsp, 0x30
000074b6341d6c3a  vmovaps xmm0, [rsp]
000074b6341d6c3f  vmovaps xmm1, [rsp+0x10]
000074b6341d6c45  vmovaps xmm2, [rsp+0x20]
000074b6341d6c4b  vmovaps xmm3, [rsp+0x30]
000074b6341d6c51  vmovaps xmm4, [rsp+0x40]
000074b6341d6c57  vmovaps xmm5, [rsp+0x50]
000074b6341d6c5d  vmovaps xmm6, [rsp+0x60]
000074b6341d6c63  vmovaps xmm7, [rsp+0x70]
000074b6341d6c69  vmovaps xmm8, [rsp+0x80]
000074b6341d6c72  vmovaps xmm9, [rsp+0x90]
000074b6341d6c7b  vmovaps xmm11, [rsp+0xA0]
000074b6341d6c84  vmovaps xmm12, [rsp+0xB0]
000074b6341d6c8d  vmovaps xmm13, [rsp+0xC0]
000074b6341d6c96  vmovaps xmm14, [rsp+0xD0]
000074b6341d6c9f  vmovaps xmm15, [rsp+0xE0]
000074b6341d6ca8  add rsp, 0xF0
000074b6341d6caf  pop r11
000074b6341d6cb1  pop r10
000074b6341d6cb3  pop r9
000074b6341d6cb5  pop r8
000074b6341d6cb7  pop rsi
000074b6341d6cb8  pop rdi
000074b6341d6cb9  pop rdx
000074b6341d6cba  pop rcx
000074b6341d6cbb  pop rax
000074b6341d6cbc  add rsp, 0x08
000074b6341d6cc0  jmp 0x000074B6341D5A06
000074b6341d6cc5  sub rsp, 0x08
000074b6341d6cc9  push rax
000074b6341d6cca  push rcx
000074b6341d6ccb  push rdx
000074b6341d6ccc  push rdi
000074b6341d6ccd  push rsi
000074b6341d6cce  push r8
000074b6341d6cd0  push r9
000074b6341d6cd2  push r10
000074b6341d6cd4  push r11
000074b6341d6cd6  sub rsp, 0xF0
000074b6341d6cdd  vmovaps [rsp], xmm0
000074b6341d6ce2  vmovaps [rsp+0x10], xmm1
000074b6341d6ce8  vmovaps [rsp+0x20], xmm2
000074b6341d6cee  vmovaps [rsp+0x30], xmm3
000074b6341d6cf4  vmovaps [rsp+0x40], xmm4
000074b6341d6cfa  vmovaps [rsp+0x50], xmm5
000074b6341d6d00  vmovaps [rsp+0x60], xmm7
000074b6341d6d06  vmovaps [rsp+0x70], xmm8
000074b6341d6d0c  vmovaps [rsp+0x80], xmm9
000074b6341d6d15  vmovaps [rsp+0x90], xmm10
000074b6341d6d1e  vmovaps [rsp+0xA0], xmm11
000074b6341d6d27  vmovaps [rsp+0xB0], xmm12
000074b6341d6d30  vmovaps [rsp+0xC0], xmm13
000074b6341d6d39  vmovaps [rsp+0xD0], xmm14
000074b6341d6d42  vmovaps [rsp+0xE0], xmm15
000074b6341d6d4b  sub rsp, 0x30
000074b6341d6d4f  movaps [rsp], xmm6
000074b6341d6d53  movaps [rsp+0x10], xmm12
000074b6341d6d59  movaps [rsp+0x20], xmm11
000074b6341d6d5f  lea rdi, [rsp]
000074b6341d6d63  mov esi, 0x00
000074b6341d6d68  mov rax, 0x5E1AA0A2F530
000074b6341d6d72  call rax
000074b6341d6d74  movaps xmm6, [rsp]
000074b6341d6d78  add rsp, 0x30
000074b6341d6d7c  vmovaps xmm0, [rsp]
000074b6341d6d81  vmovaps xmm1, [rsp+0x10]
000074b6341d6d87  vmovaps xmm2, [rsp+0x20]
000074b6341d6d8d  vmovaps xmm3, [rsp+0x30]
000074b6341d6d93  vmovaps xmm4, [rsp+0x40]
000074b6341d6d99  vmovaps xmm5, [rsp+0x50]
000074b6341d6d9f  vmovaps xmm7, [rsp+0x60]
000074b6341d6da5  vmovaps xmm8, [rsp+0x70]
000074b6341d6dab  vmovaps xmm9, [rsp+0x80]
000074b6341d6db4  vmovaps xmm10, [rsp+0x90]
000074b6341d6dbd  vmovaps xmm11, [rsp+0xA0]
000074b6341d6dc6  vmovaps xmm12, [rsp+0xB0]
000074b6341d6dcf  vmovaps xmm13, [rsp+0xC0]
000074b6341d6dd8  vmovaps xmm14, [rsp+0xD0]
000074b6341d6de1  vmovaps xmm15, [rsp+0xE0]
000074b6341d6dea  add rsp, 0xF0
000074b6341d6df1  pop r11
000074b6341d6df3  pop r10
000074b6341d6df5  pop r9
000074b6341d6df7  pop r8
000074b6341d6df9  pop rsi
000074b6341d6dfa  pop rdi
000074b6341d6dfb  pop rdx
000074b6341d6dfc  pop rcx
000074b6341d6dfd  pop rax
000074b6341d6dfe  add rsp, 0x08
000074b6341d6e02  jmp 0x000074B6341D5A27
000074b6341d6e07  sub rsp, 0x08
000074b6341d6e0b  push rax
000074b6341d6e0c  push rcx
000074b6341d6e0d  push rdx
000074b6341d6e0e  push rdi
000074b6341d6e0f  push rsi
000074b6341d6e10  push r8
000074b6341d6e12  push r9
000074b6341d6e14  push r10
000074b6341d6e16  push r11
000074b6341d6e18  sub rsp, 0xF0
000074b6341d6e1f  vmovaps [rsp], xmm0
000074b6341d6e24  vmovaps [rsp+0x10], xmm1
000074b6341d6e2a  vmovaps [rsp+0x20], xmm2
000074b6341d6e30  vmovaps [rsp+0x30], xmm4
000074b6341d6e36  vmovaps [rsp+0x40], xmm5
000074b6341d6e3c  vmovaps [rsp+0x50], xmm6
000074b6341d6e42  vmovaps [rsp+0x60], xmm7
000074b6341d6e48  vmovaps [rsp+0x70], xmm8
000074b6341d6e4e  vmovaps [rsp+0x80], xmm9
000074b6341d6e57  vmovaps [rsp+0x90], xmm10
000074b6341d6e60  vmovaps [rsp+0xA0], xmm11
000074b6341d6e69  vmovaps [rsp+0xB0], xmm12
000074b6341d6e72  vmovaps [rsp+0xC0], xmm13
000074b6341d6e7b  vmovaps [rsp+0xD0], xmm14
000074b6341d6e84  vmovaps [rsp+0xE0], xmm15
000074b6341d6e8d  sub rsp, 0x30
000074b6341d6e91  movaps [rsp], xmm3
000074b6341d6e95  movaps [rsp+0x10], xmm5
000074b6341d6e9a  movaps [rsp+0x20], xmm4
000074b6341d6e9f  lea rdi, [rsp]
000074b6341d6ea3  mov esi, 0x00
000074b6341d6ea8  mov rax, 0x5E1AA0A2F530
000074b6341d6eb2  call rax
000074b6341d6eb4  movaps xmm3, [rsp]
000074b6341d6eb8  add rsp, 0x30
000074b6341d6ebc  vmovaps xmm0, [rsp]
000074b6341d6ec1  vmovaps xmm1, [rsp+0x10]
000074b6341d6ec7  vmovaps xmm2, [rsp+0x20]
000074b6341d6ecd  vmovaps xmm4, [rsp+0x30]
000074b6341d6ed3  vmovaps xmm5, [rsp+0x40]
000074b6341d6ed9  vmovaps xmm6, [rsp+0x50]
000074b6341d6edf  vmovaps xmm7, [rsp+0x60]
000074b6341d6ee5  vmovaps xmm8, [rsp+0x70]
000074b6341d6eeb  vmovaps xmm9, [rsp+0x80]
000074b6341d6ef4  vmovaps xmm10, [rsp+0x90]
000074b6341d6efd  vmovaps xmm11, [rsp+0xA0]
000074b6341d6f06  vmovaps xmm12, [rsp+0xB0]
000074b6341d6f0f  vmovaps xmm13, [rsp+0xC0]
000074b6341d6f18  vmovaps xmm14, [rsp+0xD0]
000074b6341d6f21  vmovaps xmm15, [rsp+0xE0]
000074b6341d6f2a  add rsp, 0xF0
000074b6341d6f31  pop r11
000074b6341d6f33  pop r10
000074b6341d6f35  pop r9
000074b6341d6f37  pop r8
000074b6341d6f39  pop rsi
000074b6341d6f3a  pop rdi
000074b6341d6f3b  pop rdx
000074b6341d6f3c  pop rcx
000074b6341d6f3d  pop rax
000074b6341d6f3e  add rsp, 0x08
000074b6341d6f42  jmp 0x000074B6341D5A88
000074b6341d6f47  sub rsp, 0x08
000074b6341d6f4b  push rax
000074b6341d6f4c  push rcx
000074b6341d6f4d  push rdx
000074b6341d6f4e  push rdi
000074b6341d6f4f  push rsi
000074b6341d6f50  push r8
000074b6341d6f52  push r9
000074b6341d6f54  push r10
000074b6341d6f56  push r11
000074b6341d6f58  sub rsp, 0xF0
000074b6341d6f5f  vmovaps [rsp], xmm0
000074b6341d6f64  vmovaps [rsp+0x10], xmm1
000074b6341d6f6a  vmovaps [rsp+0x20], xmm2
000074b6341d6f70  vmovaps [rsp+0x30], xmm3
000074b6341d6f76  vmovaps [rsp+0x40], xmm4
000074b6341d6f7c  vmovaps [rsp+0x50], xmm6
000074b6341d6f82  vmovaps [rsp+0x60], xmm7
000074b6341d6f88  vmovaps [rsp+0x70], xmm8
000074b6341d6f8e  vmovaps [rsp+0x80], xmm9
000074b6341d6f97  vmovaps [rsp+0x90], xmm10
000074b6341d6fa0  vmovaps [rsp+0xA0], xmm11
000074b6341d6fa9  vmovaps [rsp+0xB0], xmm12
000074b6341d6fb2  vmovaps [rsp+0xC0], xmm13
000074b6341d6fbb  vmovaps [rsp+0xD0], xmm14
000074b6341d6fc4  vmovaps [rsp+0xE0], xmm15
000074b6341d6fcd  sub rsp, 0x30
000074b6341d6fd1  movaps [rsp], xmm5
000074b6341d6fd5  movaps [rsp+0x10], xmm8
000074b6341d6fdb  movaps [rsp+0x20], xmm15
000074b6341d6fe1  lea rdi, [rsp]
000074b6341d6fe5  mov esi, 0x00
000074b6341d6fea  mov rax, 0x5E1AA0A2F530
000074b6341d6ff4  call rax
000074b6341d6ff6  movaps xmm5, [rsp]
000074b6341d6ffa  add rsp, 0x30
000074b6341d6ffe  vmovaps xmm0, [rsp]
000074b6341d7003  vmovaps xmm1, [rsp+0x10]
000074b6341d7009  vmovaps xmm2, [rsp+0x20]
000074b6341d700f  vmovaps xmm3, [rsp+0x30]
000074b6341d7015  vmovaps xmm4, [rsp+0x40]
000074b6341d701b  vmovaps xmm6, [rsp+0x50]
000074b6341d7021  vmovaps xmm7, [rsp+0x60]
000074b6341d7027  vmovaps xmm8, [rsp+0x70]
000074b6341d702d  vmovaps xmm9, [rsp+0x80]
000074b6341d7036  vmovaps xmm10, [rsp+0x90]
000074b6341d703f  vmovaps xmm11, [rsp+0xA0]
000074b6341d7048  vmovaps xmm12, [rsp+0xB0]
000074b6341d7051  vmovaps xmm13, [rsp+0xC0]
000074b6341d705a  vmovaps xmm14, [rsp+0xD0]
000074b6341d7063  vmovaps xmm15, [rsp+0xE0]
000074b6341d706c  add rsp, 0xF0
000074b6341d7073  pop r11
000074b6341d7075  pop r10
000074b6341d7077  pop r9
000074b6341d7079  pop r8
000074b6341d707b  pop rsi
000074b6341d707c  pop rdi
000074b6341d707d  pop rdx
000074b6341d707e  pop rcx
000074b6341d707f  pop rax
000074b6341d7080  add rsp, 0x08
000074b6341d7084  jmp 0x000074B6341D5AC0
000074b6341d7089  sub rsp, 0x08
000074b6341d708d  push rax
000074b6341d708e  push rcx
000074b6341d708f  push rdx
000074b6341d7090  push rdi
000074b6341d7091  push rsi
000074b6341d7092  push r8
000074b6341d7094  push r9
000074b6341d7096  push r10
000074b6341d7098  push r11
000074b6341d709a  sub rsp, 0xF0
000074b6341d70a1  vmovaps [rsp], xmm0
000074b6341d70a6  vmovaps [rsp+0x10], xmm1
000074b6341d70ac  vmovaps [rsp+0x20], xmm2
000074b6341d70b2  vmovaps [rsp+0x30], xmm3
000074b6341d70b8  vmovaps [rsp+0x40], xmm5
000074b6341d70be  vmovaps [rsp+0x50], xmm6
000074b6341d70c4  vmovaps [rsp+0x60], xmm7
000074b6341d70ca  vmovaps [rsp+0x70], xmm8
000074b6341d70d0  vmovaps [rsp+0x80], xmm9
000074b6341d70d9  vmovaps [rsp+0x90], xmm10
000074b6341d70e2  vmovaps [rsp+0xA0], xmm11
000074b6341d70eb  vmovaps [rsp+0xB0], xmm12
000074b6341d70f4  vmovaps [rsp+0xC0], xmm13
000074b6341d70fd  vmovaps [rsp+0xD0], xmm14
000074b6341d7106  vmovaps [rsp+0xE0], xmm15
000074b6341d710f  sub rsp, 0x30
000074b6341d7113  movaps [rsp], xmm4
000074b6341d7117  movaps [rsp+0x10], xmm9
000074b6341d711d  movaps [rsp+0x20], xmm8
000074b6341d7123  lea rdi, [rsp]
000074b6341d7127  mov esi, 0x00
000074b6341d712c  mov rax, 0x5E1AA0A2F530
000074b6341d7136  call rax
000074b6341d7138  movaps xmm4, [rsp]
000074b6341d713c  add rsp, 0x30
000074b6341d7140  vmovaps xmm0, [rsp]
000074b6341d7145  vmovaps xmm1, [rsp+0x10]
000074b6341d714b  vmovaps xmm2, [rsp+0x20]
000074b6341d7151  vmovaps xmm3, [rsp+0x30]
000074b6341d7157  vmovaps xmm5, [rsp+0x40]
000074b6341d715d  vmovaps xmm6, [rsp+0x50]
000074b6341d7163  vmovaps xmm7, [rsp+0x60]
000074b6341d7169  vmovaps xmm8, [rsp+0x70]
000074b6341d716f  vmovaps xmm9, [rsp+0x80]
000074b6341d7178  vmovaps xmm10, [rsp+0x90]
000074b6341d7181  vmovaps xmm11, [rsp+0xA0]
000074b6341d718a  vmovaps xmm12, [rsp+0xB0]
000074b6341d7193  vmovaps xmm13, [rsp+0xC0]
000074b6341d719c  vmovaps xmm14, [rsp+0xD0]
000074b6341d71a5  vmovaps xmm15, [rsp+0xE0]
000074b6341d71ae  add rsp, 0xF0
000074b6341d71b5  pop r11
000074b6341d71b7  pop r10
000074b6341d71b9  pop r9
000074b6341d71bb  pop r8
000074b6341d71bd  pop rsi
000074b6341d71be  pop rdi
000074b6341d71bf  pop rdx
000074b6341d71c0  pop rcx
000074b6341d71c1  pop rax
000074b6341d71c2  add rsp, 0x08
000074b6341d71c6  jmp 0x000074B6341D5AE1
000074b6341d71cb  sub rsp, 0x08
000074b6341d71cf  push rax
000074b6341d71d0  push rcx
000074b6341d71d1  push rdx
000074b6341d71d2  push rdi
000074b6341d71d3  push rsi
000074b6341d71d4  push r8
000074b6341d71d6  push r9
000074b6341d71d8  push r10
000074b6341d71da  push r11
000074b6341d71dc  sub rsp, 0xF0
000074b6341d71e3  vmovaps [rsp], xmm0
000074b6341d71e8  vmovaps [rsp+0x10], xmm1
000074b6341d71ee  vmovaps [rsp+0x20], xmm2
000074b6341d71f4  vmovaps [rsp+0x30], xmm3
000074b6341d71fa  vmovaps [rsp+0x40], xmm4
000074b6341d7200  vmovaps [rsp+0x50], xmm5
000074b6341d7206  vmovaps [rsp+0x60], xmm6
000074b6341d720c  vmovaps [rsp+0x70], xmm7
000074b6341d7212  vmovaps [rsp+0x80], xmm8
000074b6341d721b  vmovaps [rsp+0x90], xmm10
000074b6341d7224  vmovaps [rsp+0xA0], xmm11
000074b6341d722d  vmovaps [rsp+0xB0], xmm12
000074b6341d7236  vmovaps [rsp+0xC0], xmm13
000074b6341d723f  vmovaps [rsp+0xD0], xmm14
000074b6341d7248  vmovaps [rsp+0xE0], xmm15
000074b6341d7251  sub rsp, 0x30
000074b6341d7255  movaps [rsp], xmm9
000074b6341d725a  movaps [rsp+0x10], xmm10
000074b6341d7260  movaps [rsp+0x20], xmm8
000074b6341d7266  lea rdi, [rsp]
000074b6341d726a  mov esi, 0x00
000074b6341d726f  mov rax, 0x5E1AA0A2F530
000074b6341d7279  call rax
000074b6341d727b  movaps xmm9, [rsp]
000074b6341d7280  add rsp, 0x30
000074b6341d7284  vmovaps xmm0, [rsp]
000074b6341d7289  vmovaps xmm1, [rsp+0x10]
000074b6341d728f  vmovaps xmm2, [rsp+0x20]
000074b6341d7295  vmovaps xmm3, [rsp+0x30]
000074b6341d729b  vmovaps xmm4, [rsp+0x40]
000074b6341d72a1  vmovaps xmm5, [rsp+0x50]
000074b6341d72a7  vmovaps xmm6, [rsp+0x60]
000074b6341d72ad  vmovaps xmm7, [rsp+0x70]
000074b6341d72b3  vmovaps xmm8, [rsp+0x80]
000074b6341d72bc  vmovaps xmm10, [rsp+0x90]
000074b6341d72c5  vmovaps xmm11, [rsp+0xA0]
000074b6341d72ce  vmovaps xmm12, [rsp+0xB0]
000074b6341d72d7  vmovaps xmm13, [rsp+0xC0]
000074b6341d72e0  vmovaps xmm14, [rsp+0xD0]
000074b6341d72e9  vmovaps xmm15, [rsp+0xE0]
000074b6341d72f2  add rsp, 0xF0
000074b6341d72f9  pop r11
000074b6341d72fb  pop r10
000074b6341d72fd  pop r9
000074b6341d72ff  pop r8
000074b6341d7301  pop rsi
000074b6341d7302  pop rdi
000074b6341d7303  pop rdx
000074b6341d7304  pop rcx
000074b6341d7305  pop rax
000074b6341d7306  add rsp, 0x08
000074b6341d730a  jmp 0x000074B6341D5AFB
000074b6341d730f  call 0x000074B6340D64F0
000074b6341d7314  jmp 0x000074B6341D5C15
000074b6341d7319  call 0x000074B6340D64F0
000074b6341d731e  jmp 0x000074B6341D5C2B
000074b6341d7323  sub rsp, 0x08
000074b6341d7327  push rax
000074b6341d7328  push rcx
000074b6341d7329  push rdx
000074b6341d732a  push rdi
000074b6341d732b  push rsi
000074b6341d732c  push r8
000074b6341d732e  push r9
000074b6341d7330  push r10
000074b6341d7332  push r11
000074b6341d7334  sub rsp, 0xF0
000074b6341d733b  vmovaps [rsp], xmm0
000074b6341d7340  vmovaps [rsp+0x10], xmm2
000074b6341d7346  vmovaps [rsp+0x20], xmm3
000074b6341d734c  vmovaps [rsp+0x30], xmm4
000074b6341d7352  vmovaps [rsp+0x40], xmm5
000074b6341d7358  vmovaps [rsp+0x50], xmm6
000074b6341d735e  vmovaps [rsp+0x60], xmm7
000074b6341d7364  vmovaps [rsp+0x70], xmm8
000074b6341d736a  vmovaps [rsp+0x80], xmm9
000074b6341d7373  vmovaps [rsp+0x90], xmm10
000074b6341d737c  vmovaps [rsp+0xA0], xmm11
000074b6341d7385  vmovaps [rsp+0xB0], xmm12
000074b6341d738e  vmovaps [rsp+0xC0], xmm13
000074b6341d7397  vmovaps [rsp+0xD0], xmm14
000074b6341d73a0  vmovaps [rsp+0xE0], xmm15
000074b6341d73a9  sub rsp, 0x30
000074b6341d73ad  movaps [rsp], xmm1
000074b6341d73b1  movaps [rsp+0x10], xmm6
000074b6341d73b6  movaps [rsp+0x20], xmm15
000074b6341d73bc  lea rdi, [rsp]
000074b6341d73c0  mov esi, 0x00
000074b6341d73c5  mov rax, 0x5E1AA0A2F530
000074b6341d73cf  call rax
000074b6341d73d1  movaps xmm1, [rsp]
000074b6341d73d5  add rsp, 0x30
000074b6341d73d9  vmovaps xmm0, [rsp]
000074b6341d73de  vmovaps xmm2, [rsp+0x10]
000074b6341d73e4  vmovaps xmm3, [rsp+0x20]
000074b6341d73ea  vmovaps xmm4, [rsp+0x30]
000074b6341d73f0  vmovaps xmm5, [rsp+0x40]
000074b6341d73f6  vmovaps xmm6, [rsp+0x50]
000074b6341d73fc  vmovaps xmm7, [rsp+0x60]
000074b6341d7402  vmovaps xmm8, [rsp+0x70]
000074b6341d7408  vmovaps xmm9, [rsp+0x80]
000074b6341d7411  vmovaps xmm10, [rsp+0x90]
000074b6341d741a  vmovaps xmm11, [rsp+0xA0]
000074b6341d7423  vmovaps xmm12, [rsp+0xB0]
000074b6341d742c  vmovaps xmm13, [rsp+0xC0]
000074b6341d7435  vmovaps xmm14, [rsp+0xD0]
000074b6341d743e  vmovaps xmm15, [rsp+0xE0]
000074b6341d7447  add rsp, 0xF0
000074b6341d744e  pop r11
000074b6341d7450  pop r10
000074b6341d7452  pop r9
000074b6341d7454  pop r8
000074b6341d7456  pop rsi
000074b6341d7457  pop rdi
000074b6341d7458  pop rdx
000074b6341d7459  pop rcx
000074b6341d745a  pop rax
000074b6341d745b  add rsp, 0x08
000074b6341d745f  jmp 0x000074B6341D5C68
000074b6341d7464  call 0x000074B6340E5820
000074b6341d7469  jmp 0x000074B6341D5C75
000074b6341d746e  sub rsp, 0x08
000074b6341d7472  push rax
000074b6341d7473  push rcx
000074b6341d7474  push rdx
000074b6341d7475  push rdi
000074b6341d7476  push rsi
000074b6341d7477  push r8
000074b6341d7479  push r9
000074b6341d747b  push r10
000074b6341d747d  push r11
000074b6341d747f  sub rsp, 0xF0
000074b6341d7486  vmovaps [rsp], xmm0
000074b6341d748b  vmovaps [rsp+0x10], xmm1
000074b6341d7491  vmovaps [rsp+0x20], xmm2
000074b6341d7497  vmovaps [rsp+0x30], xmm3
000074b6341d749d  vmovaps [rsp+0x40], xmm4
000074b6341d74a3  vmovaps [rsp+0x50], xmm5
000074b6341d74a9  vmovaps [rsp+0x60], xmm6
000074b6341d74af  vmovaps [rsp+0x70], xmm7
000074b6341d74b5  vmovaps [rsp+0x80], xmm8
000074b6341d74be  vmovaps [rsp+0x90], xmm9
000074b6341d74c7  vmovaps [rsp+0xA0], xmm10
000074b6341d74d0  vmovaps [rsp+0xB0], xmm11
000074b6341d74d9  vmovaps [rsp+0xC0], xmm12
000074b6341d74e2  vmovaps [rsp+0xD0], xmm13
000074b6341d74eb  vmovaps [rsp+0xE0], xmm15
000074b6341d74f4  sub rsp, 0x30
000074b6341d74f8  movaps [rsp], xmm14
000074b6341d74fd  movaps [rsp+0x10], xmm4
000074b6341d7502  movaps [rsp+0x20], xmm3
000074b6341d7507  lea rdi, [rsp]
000074b6341d750b  mov esi, 0x00
000074b6341d7510  mov rax, 0x5E1AA0A2F530
000074b6341d751a  call rax
000074b6341d751c  movaps xmm14, [rsp]
000074b6341d7521  add rsp, 0x30
000074b6341d7525  vmovaps xmm0, [rsp]
000074b6341d752a  vmovaps xmm1, [rsp+0x10]
000074b6341d7530  vmovaps xmm2, [rsp+0x20]
000074b6341d7536  vmovaps xmm3, [rsp+0x30]
000074b6341d753c  vmovaps xmm4, [rsp+0x40]
000074b6341d7542  vmovaps xmm5, [rsp+0x50]
000074b6341d7548  vmovaps xmm6, [rsp+0x60]
000074b6341d754e  vmovaps xmm7, [rsp+0x70]
000074b6341d7554  vmovaps xmm8, [rsp+0x80]
000074b6341d755d  vmovaps xmm9, [rsp+0x90]
000074b6341d7566  vmovaps xmm10, [rsp+0xA0]
000074b6341d756f  vmovaps xmm11, [rsp+0xB0]
000074b6341d7578  vmovaps xmm12, [rsp+0xC0]
000074b6341d7581  vmovaps xmm13, [rsp+0xD0]
000074b6341d758a  vmovaps xmm15, [rsp+0xE0]
000074b6341d7593  add rsp, 0xF0
000074b6341d759a  pop r11
000074b6341d759c  pop r10
000074b6341d759e  pop r9
000074b6341d75a0  pop r8
000074b6341d75a2  pop rsi
000074b6341d75a3  pop rdi
000074b6341d75a4  pop rdx
000074b6341d75a5  pop rcx
000074b6341d75a6  pop rax
000074b6341d75a7  add rsp, 0x08
000074b6341d75ab  jmp 0x000074B6341D5C8F
000074b6341d75b0  sub rsp, 0x08
000074b6341d75b4  push rax
000074b6341d75b5  push rcx
000074b6341d75b6  push rdx
000074b6341d75b7  push rdi
000074b6341d75b8  push rsi
000074b6341d75b9  push r8
000074b6341d75bb  push r9
000074b6341d75bd  push r10
000074b6341d75bf  push r11
000074b6341d75c1  sub rsp, 0xF0
000074b6341d75c8  vmovaps [rsp], xmm0
000074b6341d75cd  vmovaps [rsp+0x10], xmm1
000074b6341d75d3  vmovaps [rsp+0x20], xmm2
000074b6341d75d9  vmovaps [rsp+0x30], xmm3
000074b6341d75df  vmovaps [rsp+0x40], xmm4
000074b6341d75e5  vmovaps [rsp+0x50], xmm5
000074b6341d75eb  vmovaps [rsp+0x60], xmm7
000074b6341d75f1  vmovaps [rsp+0x70], xmm8
000074b6341d75f7  vmovaps [rsp+0x80], xmm9
000074b6341d7600  vmovaps [rsp+0x90], xmm10
000074b6341d7609  vmovaps [rsp+0xA0], xmm11
000074b6341d7612  vmovaps [rsp+0xB0], xmm12
000074b6341d761b  vmovaps [rsp+0xC0], xmm13
000074b6341d7624  vmovaps [rsp+0xD0], xmm14
000074b6341d762d  vmovaps [rsp+0xE0], xmm15
000074b6341d7636  sub rsp, 0x30
000074b6341d763a  movaps [rsp], xmm6
000074b6341d763e  movaps [rsp+0x10], xmm9
000074b6341d7644  movaps [rsp+0x20], xmm7
000074b6341d7649  lea rdi, [rsp]
000074b6341d764d  mov esi, 0x00
000074b6341d7652  mov rax, 0x5E1AA0A2F530
000074b6341d765c  call rax
000074b6341d765e  movaps xmm6, [rsp]
000074b6341d7662  add rsp, 0x30
000074b6341d7666  vmovaps xmm0, [rsp]
000074b6341d766b  vmovaps xmm1, [rsp+0x10]
000074b6341d7671  vmovaps xmm2, [rsp+0x20]
000074b6341d7677  vmovaps xmm3, [rsp+0x30]
000074b6341d767d  vmovaps xmm4, [rsp+0x40]
000074b6341d7683  vmovaps xmm5, [rsp+0x50]
000074b6341d7689  vmovaps xmm7, [rsp+0x60]
000074b6341d768f  vmovaps xmm8, [rsp+0x70]
000074b6341d7695  vmovaps xmm9, [rsp+0x80]
000074b6341d769e  vmovaps xmm10, [rsp+0x90]
000074b6341d76a7  vmovaps xmm11, [rsp+0xA0]
000074b6341d76b0  vmovaps xmm12, [rsp+0xB0]
000074b6341d76b9  vmovaps xmm13, [rsp+0xC0]
000074b6341d76c2  vmovaps xmm14, [rsp+0xD0]
000074b6341d76cb  vmovaps xmm15, [rsp+0xE0]
000074b6341d76d4  add rsp, 0xF0
000074b6341d76db  pop r11
000074b6341d76dd  pop r10
000074b6341d76df  pop r9
000074b6341d76e1  pop r8
000074b6341d76e3  pop rsi
000074b6341d76e4  pop rdi
000074b6341d76e5  pop rdx
000074b6341d76e6  pop rcx
000074b6341d76e7  pop rax
000074b6341d76e8  add rsp, 0x08
000074b6341d76ec  jmp 0x000074B6341D5CA7
000074b6341d76f1  sub rsp, 0x08
000074b6341d76f5  push rax
000074b6341d76f6  push rcx
000074b6341d76f7  push rdx
000074b6341d76f8  push rdi
000074b6341d76f9  push rsi
000074b6341d76fa  push r8
000074b6341d76fc  push r9
000074b6341d76fe  push r10
000074b6341d7700  push r11
000074b6341d7702  sub rsp, 0xF0
000074b6341d7709  vmovaps [rsp], xmm0
000074b6341d770e  vmovaps [rsp+0x10], xmm1
000074b6341d7714  vmovaps [rsp+0x20], xmm2
000074b6341d771a  vmovaps [rsp+0x30], xmm3
000074b6341d7720  vmovaps [rsp+0x40], xmm4
000074b6341d7726  vmovaps [rsp+0x50], xmm5
000074b6341d772c  vmovaps [rsp+0x60], xmm6
000074b6341d7732  vmovaps [rsp+0x70], xmm8
000074b6341d7738  vmovaps [rsp+0x80], xmm9
000074b6341d7741  vmovaps [rsp+0x90], xmm10
000074b6341d774a  vmovaps [rsp+0xA0], xmm11
000074b6341d7753  vmovaps [rsp+0xB0], xmm12
000074b6341d775c  vmovaps [rsp+0xC0], xmm13
000074b6341d7765  vmovaps [rsp+0xD0], xmm14
000074b6341d776e  vmovaps [rsp+0xE0], xmm15
000074b6341d7777  sub rsp, 0x30
000074b6341d777b  movaps [rsp], xmm7
000074b6341d777f  movaps [rsp+0x10], xmm4
000074b6341d7784  movaps [rsp+0x20], xmm9
000074b6341d778a  lea rdi, [rsp]
000074b6341d778e  mov esi, 0x00
000074b6341d7793  mov rax, 0x5E1AA0A2F530
000074b6341d779d  call rax
000074b6341d779f  movaps xmm7, [rsp]
000074b6341d77a3  add rsp, 0x30
000074b6341d77a7  vmovaps xmm0, [rsp]
000074b6341d77ac  vmovaps xmm1, [rsp+0x10]
000074b6341d77b2  vmovaps xmm2, [rsp+0x20]
000074b6341d77b8  vmovaps xmm3, [rsp+0x30]
000074b6341d77be  vmovaps xmm4, [rsp+0x40]
000074b6341d77c4  vmovaps xmm5, [rsp+0x50]
000074b6341d77ca  vmovaps xmm6, [rsp+0x60]
000074b6341d77d0  vmovaps xmm8, [rsp+0x70]
000074b6341d77d6  vmovaps xmm9, [rsp+0x80]
000074b6341d77df  vmovaps xmm10, [rsp+0x90]
000074b6341d77e8  vmovaps xmm11, [rsp+0xA0]
000074b6341d77f1  vmovaps xmm12, [rsp+0xB0]
000074b6341d77fa  vmovaps xmm13, [rsp+0xC0]
000074b6341d7803  vmovaps xmm14, [rsp+0xD0]
000074b6341d780c  vmovaps xmm15, [rsp+0xE0]
000074b6341d7815  add rsp, 0xF0
000074b6341d781c  pop r11
000074b6341d781e  pop r10
000074b6341d7820  pop r9
000074b6341d7822  pop r8
000074b6341d7824  pop rsi
000074b6341d7825  pop rdi
000074b6341d7826  pop rdx
000074b6341d7827  pop rcx
000074b6341d7828  pop rax
000074b6341d7829  add rsp, 0x08
000074b6341d782d  jmp 0x000074B6341D5CD4
000074b6341d7832  sub rsp, 0x08
000074b6341d7836  push rax
000074b6341d7837  push rcx
000074b6341d7838  push rdx
000074b6341d7839  push rdi
000074b6341d783a  push rsi
000074b6341d783b  push r8
000074b6341d783d  push r9
000074b6341d783f  push r10
000074b6341d7841  push r11
000074b6341d7843  sub rsp, 0xF0
000074b6341d784a  vmovaps [rsp], xmm0
000074b6341d784f  vmovaps [rsp+0x10], xmm1
000074b6341d7855  vmovaps [rsp+0x20], xmm2
000074b6341d785b  vmovaps [rsp+0x30], xmm3
000074b6341d7861  vmovaps [rsp+0x40], xmm5
000074b6341d7867  vmovaps [rsp+0x50], xmm6
000074b6341d786d  vmovaps [rsp+0x60], xmm7
000074b6341d7873  vmovaps [rsp+0x70], xmm8
000074b6341d7879  vmovaps [rsp+0x80], xmm9
000074b6341d7882  vmovaps [rsp+0x90], xmm10
000074b6341d788b  vmovaps [rsp+0xA0], xmm11
000074b6341d7894  vmovaps [rsp+0xB0], xmm12
000074b6341d789d  vmovaps [rsp+0xC0], xmm13
000074b6341d78a6  vmovaps [rsp+0xD0], xmm14
000074b6341d78af  vmovaps [rsp+0xE0], xmm15
000074b6341d78b8  sub rsp, 0x30
000074b6341d78bc  movaps [rsp], xmm4
000074b6341d78c0  movaps [rsp+0x10], xmm15
000074b6341d78c6  movaps [rsp+0x20], xmm9
000074b6341d78cc  lea rdi, [rsp]
000074b6341d78d0  mov esi, 0x00
000074b6341d78d5  mov rax, 0x5E1AA0A2F530
000074b6341d78df  call rax
000074b6341d78e1  movaps xmm4, [rsp]
000074b6341d78e5  add rsp, 0x30
000074b6341d78e9  vmovaps xmm0, [rsp]
000074b6341d78ee  vmovaps xmm1, [rsp+0x10]
000074b6341d78f4  vmovaps xmm2, [rsp+0x20]
000074b6341d78fa  vmovaps xmm3, [rsp+0x30]
000074b6341d7900  vmovaps xmm5, [rsp+0x40]
000074b6341d7906  vmovaps xmm6, [rsp+0x50]
000074b6341d790c  vmovaps xmm7, [rsp+0x60]
000074b6341d7912  vmovaps xmm8, [rsp+0x70]
000074b6341d7918  vmovaps xmm9, [rsp+0x80]
000074b6341d7921  vmovaps xmm10, [rsp+0x90]
000074b6341d792a  vmovaps xmm11, [rsp+0xA0]
000074b6341d7933  vmovaps xmm12, [rsp+0xB0]
000074b6341d793c  vmovaps xmm13, [rsp+0xC0]
000074b6341d7945  vmovaps xmm14, [rsp+0xD0]
000074b6341d794e  vmovaps xmm15, [rsp+0xE0]
000074b6341d7957  add rsp, 0xF0
000074b6341d795e  pop r11
000074b6341d7960  pop r10
000074b6341d7962  pop r9
000074b6341d7964  pop r8
000074b6341d7966  pop rsi
000074b6341d7967  pop rdi
000074b6341d7968  pop rdx
000074b6341d7969  pop rcx
000074b6341d796a  pop rax
000074b6341d796b  add rsp, 0x08
000074b6341d796f  jmp 0x000074B6341D5CF9
000074b6341d7974  call 0x000074B6340E5820
000074b6341d7979  jmp 0x000074B6341D5D06
000074b6341d797e  sub rsp, 0x08
000074b6341d7982  push rax
000074b6341d7983  push rcx
000074b6341d7984  push rdx
000074b6341d7985  push rdi
000074b6341d7986  push rsi
000074b6341d7987  push r8
000074b6341d7989  push r9
000074b6341d798b  push r10
000074b6341d798d  push r11
000074b6341d798f  sub rsp, 0xF0
000074b6341d7996  vmovaps [rsp], xmm0
000074b6341d799b  vmovaps [rsp+0x10], xmm1
000074b6341d79a1  vmovaps [rsp+0x20], xmm2
000074b6341d79a7  vmovaps [rsp+0x30], xmm4
000074b6341d79ad  vmovaps [rsp+0x40], xmm5
000074b6341d79b3  vmovaps [rsp+0x50], xmm6
000074b6341d79b9  vmovaps [rsp+0x60], xmm7
000074b6341d79bf  vmovaps [rsp+0x70], xmm8
000074b6341d79c5  vmovaps [rsp+0x80], xmm9
000074b6341d79ce  vmovaps [rsp+0x90], xmm10
000074b6341d79d7  vmovaps [rsp+0xA0], xmm11
000074b6341d79e0  vmovaps [rsp+0xB0], xmm12
000074b6341d79e9  vmovaps [rsp+0xC0], xmm13
000074b6341d79f2  vmovaps [rsp+0xD0], xmm14
000074b6341d79fb  vmovaps [rsp+0xE0], xmm15
000074b6341d7a04  sub rsp, 0x30
000074b6341d7a08  movaps [rsp], xmm3
000074b6341d7a0c  movaps [rsp+0x10], xmm1
000074b6341d7a11  movaps [rsp+0x20], xmm9
000074b6341d7a17  lea rdi, [rsp]
000074b6341d7a1b  mov esi, 0x00
000074b6341d7a20  mov rax, 0x5E1AA0A2F530
000074b6341d7a2a  call rax
000074b6341d7a2c  movaps xmm3, [rsp]
000074b6341d7a30  add rsp, 0x30
000074b6341d7a34  vmovaps xmm0, [rsp]
000074b6341d7a39  vmovaps xmm1, [rsp+0x10]
000074b6341d7a3f  vmovaps xmm2, [rsp+0x20]
000074b6341d7a45  vmovaps xmm4, [rsp+0x30]
000074b6341d7a4b  vmovaps xmm5, [rsp+0x40]
000074b6341d7a51  vmovaps xmm6, [rsp+0x50]
000074b6341d7a57  vmovaps xmm7, [rsp+0x60]
000074b6341d7a5d  vmovaps xmm8, [rsp+0x70]
000074b6341d7a63  vmovaps xmm9, [rsp+0x80]
000074b6341d7a6c  vmovaps xmm10, [rsp+0x90]
000074b6341d7a75  vmovaps xmm11, [rsp+0xA0]
000074b6341d7a7e  vmovaps xmm12, [rsp+0xB0]
000074b6341d7a87  vmovaps xmm13, [rsp+0xC0]
000074b6341d7a90  vmovaps xmm14, [rsp+0xD0]
000074b6341d7a99  vmovaps xmm15, [rsp+0xE0]
000074b6341d7aa2  add rsp, 0xF0
000074b6341d7aa9  pop r11
000074b6341d7aab  pop r10
000074b6341d7aad  pop r9
000074b6341d7aaf  pop r8
000074b6341d7ab1  pop rsi
000074b6341d7ab2  pop rdi
000074b6341d7ab3  pop rdx
000074b6341d7ab4  pop rcx
000074b6341d7ab5  pop rax
000074b6341d7ab6  add rsp, 0x08
000074b6341d7aba  jmp 0x000074B6341D5D43
000074b6341d7abf  sub rsp, 0x08
000074b6341d7ac3  push rax
000074b6341d7ac4  push rcx
000074b6341d7ac5  push rdx
000074b6341d7ac6  push rdi
000074b6341d7ac7  push rsi
000074b6341d7ac8  push r8
000074b6341d7aca  push r9
000074b6341d7acc  push r10
000074b6341d7ace  push r11
000074b6341d7ad0  sub rsp, 0xF0
000074b6341d7ad7  vmovaps [rsp], xmm0
000074b6341d7adc  vmovaps [rsp+0x10], xmm2
000074b6341d7ae2  vmovaps [rsp+0x20], xmm3
000074b6341d7ae8  vmovaps [rsp+0x30], xmm4
000074b6341d7aee  vmovaps [rsp+0x40], xmm5
000074b6341d7af4  vmovaps [rsp+0x50], xmm6
000074b6341d7afa  vmovaps [rsp+0x60], xmm7
000074b6341d7b00  vmovaps [rsp+0x70], xmm8
000074b6341d7b06  vmovaps [rsp+0x80], xmm9
000074b6341d7b0f  vmovaps [rsp+0x90], xmm10
000074b6341d7b18  vmovaps [rsp+0xA0], xmm11
000074b6341d7b21  vmovaps [rsp+0xB0], xmm12
000074b6341d7b2a  vmovaps [rsp+0xC0], xmm13
000074b6341d7b33  vmovaps [rsp+0xD0], xmm14
000074b6341d7b3c  vmovaps [rsp+0xE0], xmm15
000074b6341d7b45  sub rsp, 0x30
000074b6341d7b49  movaps [rsp], xmm1
000074b6341d7b4d  movaps [rsp+0x10], xmm15
000074b6341d7b53  movaps [rsp+0x20], xmm9
000074b6341d7b59  lea rdi, [rsp]
000074b6341d7b5d  mov esi, 0x00
000074b6341d7b62  mov rax, 0x5E1AA0A2F530
000074b6341d7b6c  call rax
000074b6341d7b6e  movaps xmm1, [rsp]
000074b6341d7b72  add rsp, 0x30
000074b6341d7b76  vmovaps xmm0, [rsp]
000074b6341d7b7b  vmovaps xmm2, [rsp+0x10]
000074b6341d7b81  vmovaps xmm3, [rsp+0x20]
000074b6341d7b87  vmovaps xmm4, [rsp+0x30]
000074b6341d7b8d  vmovaps xmm5, [rsp+0x40]
000074b6341d7b93  vmovaps xmm6, [rsp+0x50]
000074b6341d7b99  vmovaps xmm7, [rsp+0x60]
000074b6341d7b9f  vmovaps xmm8, [rsp+0x70]
000074b6341d7ba5  vmovaps xmm9, [rsp+0x80]
000074b6341d7bae  vmovaps xmm10, [rsp+0x90]
000074b6341d7bb7  vmovaps xmm11, [rsp+0xA0]
000074b6341d7bc0  vmovaps xmm12, [rsp+0xB0]
000074b6341d7bc9  vmovaps xmm13, [rsp+0xC0]
000074b6341d7bd2  vmovaps xmm14, [rsp+0xD0]
000074b6341d7bdb  vmovaps xmm15, [rsp+0xE0]
000074b6341d7be4  add rsp, 0xF0
000074b6341d7beb  pop r11
000074b6341d7bed  pop r10
000074b6341d7bef  pop r9
000074b6341d7bf1  pop r8
000074b6341d7bf3  pop rsi
000074b6341d7bf4  pop rdi
000074b6341d7bf5  pop rdx
000074b6341d7bf6  pop rcx
000074b6341d7bf7  pop rax
000074b6341d7bf8  add rsp, 0x08
000074b6341d7bfc  jmp 0x000074B6341D5DCB
000074b6341d7c01  call 0x000074B6340E5820
000074b6341d7c06  jmp 0x000074B6341D5DD8
000074b6341d7c0b  sub rsp, 0x08
000074b6341d7c0f  push rax
000074b6341d7c10  push rcx
000074b6341d7c11  push rdx
000074b6341d7c12  push rdi
000074b6341d7c13  push rsi
000074b6341d7c14  push r8
000074b6341d7c16  push r9
000074b6341d7c18  push r10
000074b6341d7c1a  push r11
000074b6341d7c1c  sub rsp, 0xF0
000074b6341d7c23  vmovaps [rsp], xmm0
000074b6341d7c28  vmovaps [rsp+0x10], xmm2
000074b6341d7c2e  vmovaps [rsp+0x20], xmm3
000074b6341d7c34  vmovaps [rsp+0x30], xmm4
000074b6341d7c3a  vmovaps [rsp+0x40], xmm5
000074b6341d7c40  vmovaps [rsp+0x50], xmm6
000074b6341d7c46  vmovaps [rsp+0x60], xmm7
000074b6341d7c4c  vmovaps [rsp+0x70], xmm8
000074b6341d7c52  vmovaps [rsp+0x80], xmm9
000074b6341d7c5b  vmovaps [rsp+0x90], xmm10
000074b6341d7c64  vmovaps [rsp+0xA0], xmm11
000074b6341d7c6d  vmovaps [rsp+0xB0], xmm12
000074b6341d7c76  vmovaps [rsp+0xC0], xmm13
000074b6341d7c7f  vmovaps [rsp+0xD0], xmm14
000074b6341d7c88  vmovaps [rsp+0xE0], xmm15
000074b6341d7c91  sub rsp, 0x30
000074b6341d7c95  movaps [rsp], xmm1
000074b6341d7c99  movaps [rsp+0x10], xmm5
000074b6341d7c9e  movaps [rsp+0x20], xmm7
000074b6341d7ca3  lea rdi, [rsp]
000074b6341d7ca7  mov esi, 0x00
000074b6341d7cac  mov rax, 0x5E1AA0A2F530
000074b6341d7cb6  call rax
000074b6341d7cb8  movaps xmm1, [rsp]
000074b6341d7cbc  add rsp, 0x30
000074b6341d7cc0  vmovaps xmm0, [rsp]
000074b6341d7cc5  vmovaps xmm2, [rsp+0x10]
000074b6341d7ccb  vmovaps xmm3, [rsp+0x20]
000074b6341d7cd1  vmovaps xmm4, [rsp+0x30]
000074b6341d7cd7  vmovaps xmm5, [rsp+0x40]
000074b6341d7cdd  vmovaps xmm6, [rsp+0x50]
000074b6341d7ce3  vmovaps xmm7, [rsp+0x60]
000074b6341d7ce9  vmovaps xmm8, [rsp+0x70]
000074b6341d7cef  vmovaps xmm9, [rsp+0x80]
000074b6341d7cf8  vmovaps xmm10, [rsp+0x90]
000074b6341d7d01  vmovaps xmm11, [rsp+0xA0]
000074b6341d7d0a  vmovaps xmm12, [rsp+0xB0]
000074b6341d7d13  vmovaps xmm13, [rsp+0xC0]
000074b6341d7d1c  vmovaps xmm14, [rsp+0xD0]
000074b6341d7d25  vmovaps xmm15, [rsp+0xE0]
000074b6341d7d2e  add rsp, 0xF0
000074b6341d7d35  pop r11
000074b6341d7d37  pop r10
000074b6341d7d39  pop r9
000074b6341d7d3b  pop r8
000074b6341d7d3d  pop rsi
000074b6341d7d3e  pop rdi
000074b6341d7d3f  pop rdx
000074b6341d7d40  pop rcx
000074b6341d7d41  pop rax
000074b6341d7d42  add rsp, 0x08
000074b6341d7d46  jmp 0x000074B6341D5E7D
000074b6341d7d4b  sub rsp, 0x08
000074b6341d7d4f  push rax
000074b6341d7d50  push rcx
000074b6341d7d51  push rdx
000074b6341d7d52  push rdi
000074b6341d7d53  push rsi
000074b6341d7d54  push r8
000074b6341d7d56  push r9
000074b6341d7d58  push r10
000074b6341d7d5a  push r11
000074b6341d7d5c  sub rsp, 0xF0
000074b6341d7d63  vmovaps [rsp], xmm0
000074b6341d7d68  vmovaps [rsp+0x10], xmm1
000074b6341d7d6e  vmovaps [rsp+0x20], xmm2
000074b6341d7d74  vmovaps [rsp+0x30], xmm3
000074b6341d7d7a  vmovaps [rsp+0x40], xmm4
000074b6341d7d80  vmovaps [rsp+0x50], xmm5
000074b6341d7d86  vmovaps [rsp+0x60], xmm6
000074b6341d7d8c  vmovaps [rsp+0x70], xmm8
000074b6341d7d92  vmovaps [rsp+0x80], xmm9
000074b6341d7d9b  vmovaps [rsp+0x90], xmm10
000074b6341d7da4  vmovaps [rsp+0xA0], xmm11
000074b6341d7dad  vmovaps [rsp+0xB0], xmm12
000074b6341d7db6  vmovaps [rsp+0xC0], xmm13
000074b6341d7dbf  vmovaps [rsp+0xD0], xmm14
000074b6341d7dc8  vmovaps [rsp+0xE0], xmm15
000074b6341d7dd1  sub rsp, 0x30
000074b6341d7dd5  movaps [rsp], xmm7
000074b6341d7dd9  movaps [rsp+0x10], xmm5
000074b6341d7dde  movaps [rsp+0x20], xmm15
000074b6341d7de4  lea rdi, [rsp]
000074b6341d7de8  mov esi, 0x00
000074b6341d7ded  mov rax, 0x5E1AA0A2F530
000074b6341d7df7  call rax
000074b6341d7df9  movaps xmm7, [rsp]
000074b6341d7dfd  add rsp, 0x30
000074b6341d7e01  vmovaps xmm0, [rsp]
000074b6341d7e06  vmovaps xmm1, [rsp+0x10]
000074b6341d7e0c  vmovaps xmm2, [rsp+0x20]
000074b6341d7e12  vmovaps xmm3, [rsp+0x30]
000074b6341d7e18  vmovaps xmm4, [rsp+0x40]
000074b6341d7e1e  vmovaps xmm5, [rsp+0x50]
000074b6341d7e24  vmovaps xmm6, [rsp+0x60]
000074b6341d7e2a  vmovaps xmm8, [rsp+0x70]
000074b6341d7e30  vmovaps xmm9, [rsp+0x80]
000074b6341d7e39  vmovaps xmm10, [rsp+0x90]
000074b6341d7e42  vmovaps xmm11, [rsp+0xA0]
000074b6341d7e4b  vmovaps xmm12, [rsp+0xB0]
000074b6341d7e54  vmovaps xmm13, [rsp+0xC0]
000074b6341d7e5d  vmovaps xmm14, [rsp+0xD0]
000074b6341d7e66  vmovaps xmm15, [rsp+0xE0]
000074b6341d7e6f  add rsp, 0xF0
000074b6341d7e76  pop r11
000074b6341d7e78  pop r10
000074b6341d7e7a  pop r9
000074b6341d7e7c  pop r8
000074b6341d7e7e  pop rsi
000074b6341d7e7f  pop rdi
000074b6341d7e80  pop rdx
000074b6341d7e81  pop rcx
000074b6341d7e82  pop rax
000074b6341d7e83  add rsp, 0x08
000074b6341d7e87  jmp 0x000074B6341D5EB3
000074b6341d7e8c  call 0x000074B6340D64F0
000074b6341d7e91  jmp 0x000074B6341D5EC0
000074b6341d7e96  sub rsp, 0x08
000074b6341d7e9a  push rax
000074b6341d7e9b  push rcx
000074b6341d7e9c  push rdx
000074b6341d7e9d  push rdi
000074b6341d7e9e  push rsi
000074b6341d7e9f  push r8
000074b6341d7ea1  push r9
000074b6341d7ea3  push r10
000074b6341d7ea5  push r11
000074b6341d7ea7  sub rsp, 0xF0
000074b6341d7eae  vmovaps [rsp], xmm0
000074b6341d7eb3  vmovaps [rsp+0x10], xmm1
000074b6341d7eb9  vmovaps [rsp+0x20], xmm2
000074b6341d7ebf  vmovaps [rsp+0x30], xmm3
000074b6341d7ec5  vmovaps [rsp+0x40], xmm4
000074b6341d7ecb  vmovaps [rsp+0x50], xmm5
000074b6341d7ed1  vmovaps [rsp+0x60], xmm6
000074b6341d7ed7  vmovaps [rsp+0x70], xmm7
000074b6341d7edd  vmovaps [rsp+0x80], xmm8
000074b6341d7ee6  vmovaps [rsp+0x90], xmm9
000074b6341d7eef  vmovaps [rsp+0xA0], xmm10
000074b6341d7ef8  vmovaps [rsp+0xB0], xmm11
000074b6341d7f01  vmovaps [rsp+0xC0], xmm12
000074b6341d7f0a  vmovaps [rsp+0xD0], xmm13
000074b6341d7f13  vmovaps [rsp+0xE0], xmm14
000074b6341d7f1c  sub rsp, 0x30
000074b6341d7f20  movaps [rsp], xmm15
000074b6341d7f25  movaps [rsp+0x10], xmm5
000074b6341d7f2a  movaps [rsp+0x20], xmm3
000074b6341d7f2f  lea rdi, [rsp]
000074b6341d7f33  mov esi, 0x00
000074b6341d7f38  mov rax, 0x5E1AA0A2F530
000074b6341d7f42  call rax
000074b6341d7f44  movaps xmm15, [rsp]
000074b6341d7f49  add rsp, 0x30
000074b6341d7f4d  vmovaps xmm0, [rsp]
000074b6341d7f52  vmovaps xmm1, [rsp+0x10]
000074b6341d7f58  vmovaps xmm2, [rsp+0x20]
000074b6341d7f5e  vmovaps xmm3, [rsp+0x30]
000074b6341d7f64  vmovaps xmm4, [rsp+0x40]
000074b6341d7f6a  vmovaps xmm5, [rsp+0x50]
000074b6341d7f70  vmovaps xmm6, [rsp+0x60]
000074b6341d7f76  vmovaps xmm7, [rsp+0x70]
000074b6341d7f7c  vmovaps xmm8, [rsp+0x80]
000074b6341d7f85  vmovaps xmm9, [rsp+0x90]
000074b6341d7f8e  vmovaps xmm10, [rsp+0xA0]
000074b6341d7f97  vmovaps xmm11, [rsp+0xB0]
000074b6341d7fa0  vmovaps xmm12, [rsp+0xC0]
000074b6341d7fa9  vmovaps xmm13, [rsp+0xD0]
000074b6341d7fb2  vmovaps xmm14, [rsp+0xE0]
000074b6341d7fbb  add rsp, 0xF0
000074b6341d7fc2  pop r11
000074b6341d7fc4  pop r10
000074b6341d7fc6  pop r9
000074b6341d7fc8  pop r8
000074b6341d7fca  pop rsi
000074b6341d7fcb  pop rdi
000074b6341d7fcc  pop rdx
000074b6341d7fcd  pop rcx
000074b6341d7fce  pop rax
000074b6341d7fcf  add rsp, 0x08
000074b6341d7fd3  jmp 0x000074B6341D5EE6
000074b6341d7fd8  sub rsp, 0x08
000074b6341d7fdc  push rax
000074b6341d7fdd  push rcx
000074b6341d7fde  push rdx
000074b6341d7fdf  push rdi
000074b6341d7fe0  push rsi
000074b6341d7fe1  push r8
000074b6341d7fe3  push r9
000074b6341d7fe5  push r10
000074b6341d7fe7  push r11
000074b6341d7fe9  sub rsp, 0xF0
000074b6341d7ff0  vmovaps [rsp], xmm0
000074b6341d7ff5  vmovaps [rsp+0x10], xmm2
000074b6341d7ffb  vmovaps [rsp+0x20], xmm3
000074b6341d8001  vmovaps [rsp+0x30], xmm4
000074b6341d8007  vmovaps [rsp+0x40], xmm5
000074b6341d800d  vmovaps [rsp+0x50], xmm6
000074b6341d8013  vmovaps [rsp+0x60], xmm7
000074b6341d8019  vmovaps [rsp+0x70], xmm8
000074b6341d801f  vmovaps [rsp+0x80], xmm9
000074b6341d8028  vmovaps [rsp+0x90], xmm10
000074b6341d8031  vmovaps [rsp+0xA0], xmm11
000074b6341d803a  vmovaps [rsp+0xB0], xmm12
000074b6341d8043  vmovaps [rsp+0xC0], xmm13
000074b6341d804c  vmovaps [rsp+0xD0], xmm14
000074b6341d8055  vmovaps [rsp+0xE0], xmm15
000074b6341d805e  sub rsp, 0x30
000074b6341d8062  movaps [rsp], xmm1
000074b6341d8066  movaps [rsp+0x10], xmm5
000074b6341d806b  movaps [rsp+0x20], xmm4
000074b6341d8070  lea rdi, [rsp]
000074b6341d8074  mov esi, 0x00
000074b6341d8079  mov rax, 0x5E1AA0A2F530
000074b6341d8083  call rax
000074b6341d8085  movaps xmm1, [rsp]
000074b6341d8089  add rsp, 0x30
000074b6341d808d  vmovaps xmm0, [rsp]
000074b6341d8092  vmovaps xmm2, [rsp+0x10]
000074b6341d8098  vmovaps xmm3, [rsp+0x20]
000074b6341d809e  vmovaps xmm4, [rsp+0x30]
000074b6341d80a4  vmovaps xmm5, [rsp+0x40]
000074b6341d80aa  vmovaps xmm6, [rsp+0x50]
000074b6341d80b0  vmovaps xmm7, [rsp+0x60]
000074b6341d80b6  vmovaps xmm8, [rsp+0x70]
000074b6341d80bc  vmovaps xmm9, [rsp+0x80]
000074b6341d80c5  vmovaps xmm10, [rsp+0x90]
000074b6341d80ce  vmovaps xmm11, [rsp+0xA0]
000074b6341d80d7  vmovaps xmm12, [rsp+0xB0]
000074b6341d80e0  vmovaps xmm13, [rsp+0xC0]
000074b6341d80e9  vmovaps xmm14, [rsp+0xD0]
000074b6341d80f2  vmovaps xmm15, [rsp+0xE0]
000074b6341d80fb  add rsp, 0xF0
000074b6341d8102  pop r11
000074b6341d8104  pop r10
000074b6341d8106  pop r9
000074b6341d8108  pop r8
000074b6341d810a  pop rsi
000074b6341d810b  pop rdi
000074b6341d810c  pop rdx
000074b6341d810d  pop rcx
000074b6341d810e  pop rax
000074b6341d810f  add rsp, 0x08
000074b6341d8113  jmp 0x000074B6341D5F06
000074b6341d8118  sub rsp, 0x08
000074b6341d811c  push rax
000074b6341d811d  push rcx
000074b6341d811e  push rdx
000074b6341d811f  push rdi
000074b6341d8120  push rsi
000074b6341d8121  push r8
000074b6341d8123  push r9
000074b6341d8125  push r10
000074b6341d8127  push r11
000074b6341d8129  sub rsp, 0xF0
000074b6341d8130  vmovaps [rsp], xmm0
000074b6341d8135  vmovaps [rsp+0x10], xmm1
000074b6341d813b  vmovaps [rsp+0x20], xmm2
000074b6341d8141  vmovaps [rsp+0x30], xmm3
000074b6341d8147  vmovaps [rsp+0x40], xmm5
000074b6341d814d  vmovaps [rsp+0x50], xmm6
000074b6341d8153  vmovaps [rsp+0x60], xmm7
000074b6341d8159  vmovaps [rsp+0x70], xmm8
000074b6341d815f  vmovaps [rsp+0x80], xmm9
000074b6341d8168  vmovaps [rsp+0x90], xmm10
000074b6341d8171  vmovaps [rsp+0xA0], xmm11
000074b6341d817a  vmovaps [rsp+0xB0], xmm12
000074b6341d8183  vmovaps [rsp+0xC0], xmm13
000074b6341d818c  vmovaps [rsp+0xD0], xmm14
000074b6341d8195  vmovaps [rsp+0xE0], xmm15
000074b6341d819e  sub rsp, 0x30
000074b6341d81a2  movaps [rsp], xmm4
000074b6341d81a6  movaps [rsp+0x10], xmm3
000074b6341d81ab  movaps [rsp+0x20], xmm5
000074b6341d81b0  lea rdi, [rsp]
000074b6341d81b4  mov esi, 0x00
000074b6341d81b9  mov rax, 0x5E1AA0A2F530
000074b6341d81c3  call rax
000074b6341d81c5  movaps xmm4, [rsp]
000074b6341d81c9  add rsp, 0x30
000074b6341d81cd  vmovaps xmm0, [rsp]
000074b6341d81d2  vmovaps xmm1, [rsp+0x10]
000074b6341d81d8  vmovaps xmm2, [rsp+0x20]
000074b6341d81de  vmovaps xmm3, [rsp+0x30]
000074b6341d81e4  vmovaps xmm5, [rsp+0x40]
000074b6341d81ea  vmovaps xmm6, [rsp+0x50]
000074b6341d81f0  vmovaps xmm7, [rsp+0x60]
000074b6341d81f6  vmovaps xmm8, [rsp+0x70]
000074b6341d81fc  vmovaps xmm9, [rsp+0x80]
000074b6341d8205  vmovaps xmm10, [rsp+0x90]
000074b6341d820e  vmovaps xmm11, [rsp+0xA0]
000074b6341d8217  vmovaps xmm12, [rsp+0xB0]
000074b6341d8220  vmovaps xmm13, [rsp+0xC0]
000074b6341d8229  vmovaps xmm14, [rsp+0xD0]
000074b6341d8232  vmovaps xmm15, [rsp+0xE0]
000074b6341d823b  add rsp, 0xF0
000074b6341d8242  pop r11
000074b6341d8244  pop r10
000074b6341d8246  pop r9
000074b6341d8248  pop r8
000074b6341d824a  pop rsi
000074b6341d824b  pop rdi
000074b6341d824c  pop rdx
000074b6341d824d  pop rcx
000074b6341d824e  pop rax
000074b6341d824f  add rsp, 0x08
000074b6341d8253  jmp 0x000074B6341D5F54
000074b6341d8258  call 0x000074B6340D64F0
000074b6341d825d  jmp 0x000074B6341D5F61
000074b6341d8262  sub rsp, 0x08
000074b6341d8266  push rax
000074b6341d8267  push rcx
000074b6341d8268  push rdx
000074b6341d8269  push rdi
000074b6341d826a  push rsi
000074b6341d826b  push r8
000074b6341d826d  push r9
000074b6341d826f  push r10
000074b6341d8271  push r11
000074b6341d8273  sub rsp, 0xF0
000074b6341d827a  vmovaps [rsp], xmm0
000074b6341d827f  vmovaps [rsp+0x10], xmm1
000074b6341d8285  vmovaps [rsp+0x20], xmm2
000074b6341d828b  vmovaps [rsp+0x30], xmm3
000074b6341d8291  vmovaps [rsp+0x40], xmm4
000074b6341d8297  vmovaps [rsp+0x50], xmm6
000074b6341d829d  vmovaps [rsp+0x60], xmm7
000074b6341d82a3  vmovaps [rsp+0x70], xmm8
000074b6341d82a9  vmovaps [rsp+0x80], xmm9
000074b6341d82b2  vmovaps [rsp+0x90], xmm10
000074b6341d82bb  vmovaps [rsp+0xA0], xmm11
000074b6341d82c4  vmovaps [rsp+0xB0], xmm12
000074b6341d82cd  vmovaps [rsp+0xC0], xmm13
000074b6341d82d6  vmovaps [rsp+0xD0], xmm14
000074b6341d82df  vmovaps [rsp+0xE0], xmm15
000074b6341d82e8  sub rsp, 0x30
000074b6341d82ec  movaps [rsp], xmm5
000074b6341d82f0  movaps [rsp+0x10], xmm6
000074b6341d82f5  movaps [rsp+0x20], xmm3
000074b6341d82fa  lea rdi, [rsp]
000074b6341d82fe  mov esi, 0x00
000074b6341d8303  mov rax, 0x5E1AA0A2F530
000074b6341d830d  call rax
000074b6341d830f  movaps xmm5, [rsp]
000074b6341d8313  add rsp, 0x30
000074b6341d8317  vmovaps xmm0, [rsp]
000074b6341d831c  vmovaps xmm1, [rsp+0x10]
000074b6341d8322  vmovaps xmm2, [rsp+0x20]
000074b6341d8328  vmovaps xmm3, [rsp+0x30]
000074b6341d832e  vmovaps xmm4, [rsp+0x40]
000074b6341d8334  vmovaps xmm6, [rsp+0x50]
000074b6341d833a  vmovaps xmm7, [rsp+0x60]
000074b6341d8340  vmovaps xmm8, [rsp+0x70]
000074b6341d8346  vmovaps xmm9, [rsp+0x80]
000074b6341d834f  vmovaps xmm10, [rsp+0x90]
000074b6341d8358  vmovaps xmm11, [rsp+0xA0]
000074b6341d8361  vmovaps xmm12, [rsp+0xB0]
000074b6341d836a  vmovaps xmm13, [rsp+0xC0]
000074b6341d8373  vmovaps xmm14, [rsp+0xD0]
000074b6341d837c  vmovaps xmm15, [rsp+0xE0]
000074b6341d8385  add rsp, 0xF0
000074b6341d838c  pop r11
000074b6341d838e  pop r10
000074b6341d8390  pop r9
000074b6341d8392  pop r8
000074b6341d8394  pop rsi
000074b6341d8395  pop rdi
000074b6341d8396  pop rdx
000074b6341d8397  pop rcx
000074b6341d8398  pop rax
000074b6341d8399  add rsp, 0x08
000074b6341d839d  jmp 0x000074B6341D5F87
000074b6341d83a2  sub rsp, 0x08
000074b6341d83a6  push rax
000074b6341d83a7  push rcx
000074b6341d83a8  push rdx
000074b6341d83a9  push rdi
000074b6341d83aa  push rsi
000074b6341d83ab  push r8
000074b6341d83ad  push r9
000074b6341d83af  push r10
000074b6341d83b1  push r11
000074b6341d83b3  sub rsp, 0xF0
000074b6341d83ba  vmovaps [rsp], xmm0
000074b6341d83bf  vmovaps [rsp+0x10], xmm1
000074b6341d83c5  vmovaps [rsp+0x20], xmm2
000074b6341d83cb  vmovaps [rsp+0x30], xmm3
000074b6341d83d1  vmovaps [rsp+0x40], xmm4
000074b6341d83d7  vmovaps [rsp+0x50], xmm5
000074b6341d83dd  vmovaps [rsp+0x60], xmm7
000074b6341d83e3  vmovaps [rsp+0x70], xmm8
000074b6341d83e9  vmovaps [rsp+0x80], xmm9
000074b6341d83f2  vmovaps [rsp+0x90], xmm10
000074b6341d83fb  vmovaps [rsp+0xA0], xmm11
000074b6341d8404  vmovaps [rsp+0xB0], xmm12
000074b6341d840d  vmovaps [rsp+0xC0], xmm13
000074b6341d8416  vmovaps [rsp+0xD0], xmm14
000074b6341d841f  vmovaps [rsp+0xE0], xmm15
000074b6341d8428  sub rsp, 0x30
000074b6341d842c  movaps [rsp], xmm6
000074b6341d8430  movaps [rsp+0x10], xmm9
000074b6341d8436  movaps [rsp+0x20], xmm1
000074b6341d843b  lea rdi, [rsp]
000074b6341d843f  mov esi, 0x00
000074b6341d8444  mov rax, 0x5E1AA0A2F530
000074b6341d844e  call rax
000074b6341d8450  movaps xmm6, [rsp]
000074b6341d8454  add rsp, 0x30
000074b6341d8458  vmovaps xmm0, [rsp]
000074b6341d845d  vmovaps xmm1, [rsp+0x10]
000074b6341d8463  vmovaps xmm2, [rsp+0x20]
000074b6341d8469  vmovaps xmm3, [rsp+0x30]
000074b6341d846f  vmovaps xmm4, [rsp+0x40]
000074b6341d8475  vmovaps xmm5, [rsp+0x50]
000074b6341d847b  vmovaps xmm7, [rsp+0x60]
000074b6341d8481  vmovaps xmm8, [rsp+0x70]
000074b6341d8487  vmovaps xmm9, [rsp+0x80]
000074b6341d8490  vmovaps xmm10, [rsp+0x90]
000074b6341d8499  vmovaps xmm11, [rsp+0xA0]
000074b6341d84a2  vmovaps xmm12, [rsp+0xB0]
000074b6341d84ab  vmovaps xmm13, [rsp+0xC0]
000074b6341d84b4  vmovaps xmm14, [rsp+0xD0]
000074b6341d84bd  vmovaps xmm15, [rsp+0xE0]
000074b6341d84c6  add rsp, 0xF0
000074b6341d84cd  pop r11
000074b6341d84cf  pop r10
000074b6341d84d1  pop r9
000074b6341d84d3  pop r8
000074b6341d84d5  pop rsi
000074b6341d84d6  pop rdi
000074b6341d84d7  pop rdx
000074b6341d84d8  pop rcx
000074b6341d84d9  pop rax
000074b6341d84da  add rsp, 0x08
000074b6341d84de  jmp 0x000074B6341D5FAB
000074b6341d84e3  sub rsp, 0x08
000074b6341d84e7  push rax
000074b6341d84e8  push rcx
000074b6341d84e9  push rdx
000074b6341d84ea  push rdi
000074b6341d84eb  push rsi
000074b6341d84ec  push r8
000074b6341d84ee  push r9
000074b6341d84f0  push r10
000074b6341d84f2  push r11
000074b6341d84f4  sub rsp, 0xF0
000074b6341d84fb  vmovaps [rsp], xmm0
000074b6341d8500  vmovaps [rsp+0x10], xmm1
000074b6341d8506  vmovaps [rsp+0x20], xmm2
000074b6341d850c  vmovaps [rsp+0x30], xmm3
000074b6341d8512  vmovaps [rsp+0x40], xmm4
000074b6341d8518  vmovaps [rsp+0x50], xmm5
000074b6341d851e  vmovaps [rsp+0x60], xmm6
000074b6341d8524  vmovaps [rsp+0x70], xmm7
000074b6341d852a  vmovaps [rsp+0x80], xmm8
000074b6341d8533  vmovaps [rsp+0x90], xmm10
000074b6341d853c  vmovaps [rsp+0xA0], xmm11
000074b6341d8545  vmovaps [rsp+0xB0], xmm12
000074b6341d854e  vmovaps [rsp+0xC0], xmm13
000074b6341d8557  vmovaps [rsp+0xD0], xmm14
000074b6341d8560  vmovaps [rsp+0xE0], xmm15
000074b6341d8569  sub rsp, 0x30
000074b6341d856d  movaps [rsp], xmm9
000074b6341d8572  movaps [rsp+0x10], xmm3
000074b6341d8577  movaps [rsp+0x20], xmm1
000074b6341d857c  lea rdi, [rsp]
000074b6341d8580  mov esi, 0x00
000074b6341d8585  mov rax, 0x5E1AA0A2F530
000074b6341d858f  call rax
000074b6341d8591  movaps xmm9, [rsp]
000074b6341d8596  add rsp, 0x30
000074b6341d859a  vmovaps xmm0, [rsp]
000074b6341d859f  vmovaps xmm1, [rsp+0x10]
000074b6341d85a5  vmovaps xmm2, [rsp+0x20]
000074b6341d85ab  vmovaps xmm3, [rsp+0x30]
000074b6341d85b1  vmovaps xmm4, [rsp+0x40]
000074b6341d85b7  vmovaps xmm5, [rsp+0x50]
000074b6341d85bd  vmovaps xmm6, [rsp+0x60]
000074b6341d85c3  vmovaps xmm7, [rsp+0x70]
000074b6341d85c9  vmovaps xmm8, [rsp+0x80]
000074b6341d85d2  vmovaps xmm10, [rsp+0x90]
000074b6341d85db  vmovaps xmm11, [rsp+0xA0]
000074b6341d85e4  vmovaps xmm12, [rsp+0xB0]
000074b6341d85ed  vmovaps xmm13, [rsp+0xC0]
000074b6341d85f6  vmovaps xmm14, [rsp+0xD0]
000074b6341d85ff  vmovaps xmm15, [rsp+0xE0]
000074b6341d8608  add rsp, 0xF0
000074b6341d860f  pop r11
000074b6341d8611  pop r10
000074b6341d8613  pop r9
000074b6341d8615  pop r8
000074b6341d8617  pop rsi
000074b6341d8618  pop rdi
000074b6341d8619  pop rdx
000074b6341d861a  pop rcx
000074b6341d861b  pop rax
000074b6341d861c  add rsp, 0x08
000074b6341d8620  jmp 0x000074B6341D5FF7
000074b6341d8625  call 0x000074B6340D64F0
000074b6341d862a  jmp 0x000074B6341D6004
000074b6341d862f  sub rsp, 0x08
000074b6341d8633  push rax
000074b6341d8634  push rcx
000074b6341d8635  push rdx
000074b6341d8636  push rdi
000074b6341d8637  push rsi
000074b6341d8638  push r8
000074b6341d863a  push r9
000074b6341d863c  push r10
000074b6341d863e  push r11
000074b6341d8640  sub rsp, 0xF0
000074b6341d8647  vmovaps [rsp], xmm0
000074b6341d864c  vmovaps [rsp+0x10], xmm1
000074b6341d8652  vmovaps [rsp+0x20], xmm2
000074b6341d8658  vmovaps [rsp+0x30], xmm3
000074b6341d865e  vmovaps [rsp+0x40], xmm4
000074b6341d8664  vmovaps [rsp+0x50], xmm5
000074b6341d866a  vmovaps [rsp+0x60], xmm6
000074b6341d8670  vmovaps [rsp+0x70], xmm7
000074b6341d8676  vmovaps [rsp+0x80], xmm8
000074b6341d867f  vmovaps [rsp+0x90], xmm9
000074b6341d8688  vmovaps [rsp+0xA0], xmm10
000074b6341d8691  vmovaps [rsp+0xB0], xmm11
000074b6341d869a  vmovaps [rsp+0xC0], xmm12
000074b6341d86a3  vmovaps [rsp+0xD0], xmm13
000074b6341d86ac  vmovaps [rsp+0xE0], xmm14
000074b6341d86b5  sub rsp, 0x30
000074b6341d86b9  movaps [rsp], xmm15
000074b6341d86be  movaps [rsp+0x10], xmm3
000074b6341d86c3  movaps [rsp+0x20], xmm7
000074b6341d86c8  lea rdi, [rsp]
000074b6341d86cc  mov esi, 0x00
000074b6341d86d1  mov rax, 0x5E1AA0A2F530
000074b6341d86db  call rax
000074b6341d86dd  movaps xmm15, [rsp]
000074b6341d86e2  add rsp, 0x30
000074b6341d86e6  vmovaps xmm0, [rsp]
000074b6341d86eb  vmovaps xmm1, [rsp+0x10]
000074b6341d86f1  vmovaps xmm2, [rsp+0x20]
000074b6341d86f7  vmovaps xmm3, [rsp+0x30]
000074b6341d86fd  vmovaps xmm4, [rsp+0x40]
000074b6341d8703  vmovaps xmm5, [rsp+0x50]
000074b6341d8709  vmovaps xmm6, [rsp+0x60]
000074b6341d870f  vmovaps xmm7, [rsp+0x70]
000074b6341d8715  vmovaps xmm8, [rsp+0x80]
000074b6341d871e  vmovaps xmm9, [rsp+0x90]
000074b6341d8727  vmovaps xmm10, [rsp+0xA0]
000074b6341d8730  vmovaps xmm11, [rsp+0xB0]
000074b6341d8739  vmovaps xmm12, [rsp+0xC0]
000074b6341d8742  vmovaps xmm13, [rsp+0xD0]
000074b6341d874b  vmovaps xmm14, [rsp+0xE0]
000074b6341d8754  add rsp, 0xF0
000074b6341d875b  pop r11
000074b6341d875d  pop r10
000074b6341d875f  pop r9
000074b6341d8761  pop r8
000074b6341d8763  pop rsi
000074b6341d8764  pop rdi
000074b6341d8765  pop rdx
000074b6341d8766  pop rcx
000074b6341d8767  pop rax
000074b6341d8768  add rsp, 0x08
000074b6341d876c  jmp 0x000074B6341D6030
000074b6341d8771  sub rsp, 0x08
000074b6341d8775  push rax
000074b6341d8776  push rcx
000074b6341d8777  push rdx
000074b6341d8778  push rdi
000074b6341d8779  push rsi
000074b6341d877a  push r8
000074b6341d877c  push r9
000074b6341d877e  push r10
000074b6341d8780  push r11
000074b6341d8782  sub rsp, 0xF0
000074b6341d8789  vmovaps [rsp], xmm0
000074b6341d878e  vmovaps [rsp+0x10], xmm1
000074b6341d8794  vmovaps [rsp+0x20], xmm2
000074b6341d879a  vmovaps [rsp+0x30], xmm4
000074b6341d87a0  vmovaps [rsp+0x40], xmm5
000074b6341d87a6  vmovaps [rsp+0x50], xmm6
000074b6341d87ac  vmovaps [rsp+0x60], xmm7
000074b6341d87b2  vmovaps [rsp+0x70], xmm8
000074b6341d87b8  vmovaps [rsp+0x80], xmm9
000074b6341d87c1  vmovaps [rsp+0x90], xmm10
000074b6341d87ca  vmovaps [rsp+0xA0], xmm11
000074b6341d87d3  vmovaps [rsp+0xB0], xmm12
000074b6341d87dc  vmovaps [rsp+0xC0], xmm13
000074b6341d87e5  vmovaps [rsp+0xD0], xmm14
000074b6341d87ee  vmovaps [rsp+0xE0], xmm15
000074b6341d87f7  sub rsp, 0x30
000074b6341d87fb  movaps [rsp], xmm3
000074b6341d87ff  movaps [rsp+0x10], xmm1
000074b6341d8804  movaps [rsp+0x20], xmm15
000074b6341d880a  lea rdi, [rsp]
000074b6341d880e  mov esi, 0x00
000074b6341d8813  mov rax, 0x5E1AA0A2F530
000074b6341d881d  call rax
000074b6341d881f  movaps xmm3, [rsp]
000074b6341d8823  add rsp, 0x30
000074b6341d8827  vmovaps xmm0, [rsp]
000074b6341d882c  vmovaps xmm1, [rsp+0x10]
000074b6341d8832  vmovaps xmm2, [rsp+0x20]
000074b6341d8838  vmovaps xmm4, [rsp+0x30]
000074b6341d883e  vmovaps xmm5, [rsp+0x40]
000074b6341d8844  vmovaps xmm6, [rsp+0x50]
000074b6341d884a  vmovaps xmm7, [rsp+0x60]
000074b6341d8850  vmovaps xmm8, [rsp+0x70]
000074b6341d8856  vmovaps xmm9, [rsp+0x80]
000074b6341d885f  vmovaps xmm10, [rsp+0x90]
000074b6341d8868  vmovaps xmm11, [rsp+0xA0]
000074b6341d8871  vmovaps xmm12, [rsp+0xB0]
000074b6341d887a  vmovaps xmm13, [rsp+0xC0]
000074b6341d8883  vmovaps xmm14, [rsp+0xD0]
000074b6341d888c  vmovaps xmm15, [rsp+0xE0]
000074b6341d8895  add rsp, 0xF0
000074b6341d889c  pop r11
000074b6341d889e  pop r10
000074b6341d88a0  pop r9
000074b6341d88a2  pop r8
000074b6341d88a4  pop rsi
000074b6341d88a5  pop rdi
000074b6341d88a6  pop rdx
000074b6341d88a7  pop rcx
000074b6341d88a8  pop rax
000074b6341d88a9  add rsp, 0x08
000074b6341d88ad  jmp 0x000074B6341D60BF
000074b6341d88b2  call 0x000074B6340D64F0
000074b6341d88b7  jmp 0x000074B6341D60C9
000074b6341d88bc  sub rsp, 0x08
000074b6341d88c0  push rax
000074b6341d88c1  push rcx
000074b6341d88c2  push rdx
000074b6341d88c3  push rdi
000074b6341d88c4  push rsi
000074b6341d88c5  push r8
000074b6341d88c7  push r9
000074b6341d88c9  push r10
000074b6341d88cb  push r11
000074b6341d88cd  sub rsp, 0xF0
000074b6341d88d4  vmovaps [rsp], xmm0
000074b6341d88d9  vmovaps [rsp+0x10], xmm1
000074b6341d88df  vmovaps [rsp+0x20], xmm2
000074b6341d88e5  vmovaps [rsp+0x30], xmm3
000074b6341d88eb  vmovaps [rsp+0x40], xmm4
000074b6341d88f1  vmovaps [rsp+0x50], xmm5
000074b6341d88f7  vmovaps [rsp+0x60], xmm6
000074b6341d88fd  vmovaps [rsp+0x70], xmm7
000074b6341d8903  vmovaps [rsp+0x80], xmm8
000074b6341d890c  vmovaps [rsp+0x90], xmm9
000074b6341d8915  vmovaps [rsp+0xA0], xmm10
000074b6341d891e  vmovaps [rsp+0xB0], xmm11
000074b6341d8927  vmovaps [rsp+0xC0], xmm12
000074b6341d8930  vmovaps [rsp+0xD0], xmm13
000074b6341d8939  vmovaps [rsp+0xE0], xmm14
000074b6341d8942  sub rsp, 0x30
000074b6341d8946  movaps [rsp], xmm15
000074b6341d894b  movaps [rsp+0x10], xmm14
000074b6341d8951  movaps [rsp+0x20], xmm4
000074b6341d8956  lea rdi, [rsp]
000074b6341d895a  mov esi, 0x00
000074b6341d895f  mov rax, 0x5E1AA0A2F530
000074b6341d8969  call rax
000074b6341d896b  movaps xmm15, [rsp]
000074b6341d8970  add rsp, 0x30
000074b6341d8974  vmovaps xmm0, [rsp]
000074b6341d8979  vmovaps xmm1, [rsp+0x10]
000074b6341d897f  vmovaps xmm2, [rsp+0x20]
000074b6341d8985  vmovaps xmm3, [rsp+0x30]
000074b6341d898b  vmovaps xmm4, [rsp+0x40]
000074b6341d8991  vmovaps xmm5, [rsp+0x50]
000074b6341d8997  vmovaps xmm6, [rsp+0x60]
000074b6341d899d  vmovaps xmm7, [rsp+0x70]
000074b6341d89a3  vmovaps xmm8, [rsp+0x80]
000074b6341d89ac  vmovaps xmm9, [rsp+0x90]
000074b6341d89b5  vmovaps xmm10, [rsp+0xA0]
000074b6341d89be  vmovaps xmm11, [rsp+0xB0]
000074b6341d89c7  vmovaps xmm12, [rsp+0xC0]
000074b6341d89d0  vmovaps xmm13, [rsp+0xD0]
000074b6341d89d9  vmovaps xmm14, [rsp+0xE0]
000074b6341d89e2  add rsp, 0xF0
000074b6341d89e9  pop r11
000074b6341d89eb  pop r10
000074b6341d89ed  pop r9
000074b6341d89ef  pop r8
000074b6341d89f1  pop rsi
000074b6341d89f2  pop rdi
000074b6341d89f3  pop rdx
000074b6341d89f4  pop rcx
000074b6341d89f5  pop rax
000074b6341d89f6  add rsp, 0x08
000074b6341d89fa  jmp 0x000074B6341D60F7
000074b6341d89ff  sub rsp, 0x08
000074b6341d8a03  push rax
000074b6341d8a04  push rcx
000074b6341d8a05  push rdx
000074b6341d8a06  push rdi
000074b6341d8a07  push rsi
000074b6341d8a08  push r8
000074b6341d8a0a  push r9
000074b6341d8a0c  push r10
000074b6341d8a0e  push r11
000074b6341d8a10  sub rsp, 0xF0
000074b6341d8a17  vmovaps [rsp], xmm0
000074b6341d8a1c  vmovaps [rsp+0x10], xmm1
000074b6341d8a22  vmovaps [rsp+0x20], xmm2
000074b6341d8a28  vmovaps [rsp+0x30], xmm3
000074b6341d8a2e  vmovaps [rsp+0x40], xmm4
000074b6341d8a34  vmovaps [rsp+0x50], xmm5
000074b6341d8a3a  vmovaps [rsp+0x60], xmm6
000074b6341d8a40  vmovaps [rsp+0x70], xmm7
000074b6341d8a46  vmovaps [rsp+0x80], xmm8
000074b6341d8a4f  vmovaps [rsp+0x90], xmm9
000074b6341d8a58  vmovaps [rsp+0xA0], xmm10
000074b6341d8a61  vmovaps [rsp+0xB0], xmm11
000074b6341d8a6a  vmovaps [rsp+0xC0], xmm12
000074b6341d8a73  vmovaps [rsp+0xD0], xmm13
000074b6341d8a7c  vmovaps [rsp+0xE0], xmm15
000074b6341d8a85  sub rsp, 0x30
000074b6341d8a89  movaps [rsp], xmm14
000074b6341d8a8e  movaps [rsp+0x10], xmm2
000074b6341d8a93  movaps [rsp+0x20], xmm1
000074b6341d8a98  lea rdi, [rsp]
000074b6341d8a9c  mov esi, 0x00
000074b6341d8aa1  mov rax, 0x5E1AA0A2F530
000074b6341d8aab  call rax
000074b6341d8aad  movaps xmm14, [rsp]
000074b6341d8ab2  add rsp, 0x30
000074b6341d8ab6  vmovaps xmm0, [rsp]
000074b6341d8abb  vmovaps xmm1, [rsp+0x10]
000074b6341d8ac1  vmovaps xmm2, [rsp+0x20]
000074b6341d8ac7  vmovaps xmm3, [rsp+0x30]
000074b6341d8acd  vmovaps xmm4, [rsp+0x40]
000074b6341d8ad3  vmovaps xmm5, [rsp+0x50]
000074b6341d8ad9  vmovaps xmm6, [rsp+0x60]
000074b6341d8adf  vmovaps xmm7, [rsp+0x70]
000074b6341d8ae5  vmovaps xmm8, [rsp+0x80]
000074b6341d8aee  vmovaps xmm9, [rsp+0x90]
000074b6341d8af7  vmovaps xmm10, [rsp+0xA0]
000074b6341d8b00  vmovaps xmm11, [rsp+0xB0]
000074b6341d8b09  vmovaps xmm12, [rsp+0xC0]
000074b6341d8b12  vmovaps xmm13, [rsp+0xD0]
000074b6341d8b1b  vmovaps xmm15, [rsp+0xE0]
000074b6341d8b24  add rsp, 0xF0
000074b6341d8b2b  pop r11
000074b6341d8b2d  pop r10
000074b6341d8b2f  pop r9
000074b6341d8b31  pop r8
000074b6341d8b33  pop rsi
000074b6341d8b34  pop rdi
000074b6341d8b35  pop rdx
000074b6341d8b36  pop rcx
000074b6341d8b37  pop rax
000074b6341d8b38  add rsp, 0x08
000074b6341d8b3c  jmp 0x000074B6341D611D
000074b6341d8b41  sub rsp, 0x08
000074b6341d8b45  push rax
000074b6341d8b46  push rcx
000074b6341d8b47  push rdx
000074b6341d8b48  push rdi
000074b6341d8b49  push rsi
000074b6341d8b4a  push r8
000074b6341d8b4c  push r9
000074b6341d8b4e  push r10
000074b6341d8b50  push r11
000074b6341d8b52  sub rsp, 0xF0
000074b6341d8b59  vmovaps [rsp], xmm0
000074b6341d8b5e  vmovaps [rsp+0x10], xmm2
000074b6341d8b64  vmovaps [rsp+0x20], xmm3
000074b6341d8b6a  vmovaps [rsp+0x30], xmm4
000074b6341d8b70  vmovaps [rsp+0x40], xmm5
000074b6341d8b76  vmovaps [rsp+0x50], xmm6
000074b6341d8b7c  vmovaps [rsp+0x60], xmm7
000074b6341d8b82  vmovaps [rsp+0x70], xmm8
000074b6341d8b88  vmovaps [rsp+0x80], xmm9
000074b6341d8b91  vmovaps [rsp+0x90], xmm10
000074b6341d8b9a  vmovaps [rsp+0xA0], xmm11
000074b6341d8ba3  vmovaps [rsp+0xB0], xmm12
000074b6341d8bac  vmovaps [rsp+0xC0], xmm13
000074b6341d8bb5  vmovaps [rsp+0xD0], xmm14
000074b6341d8bbe  vmovaps [rsp+0xE0], xmm15
000074b6341d8bc7  sub rsp, 0x30
000074b6341d8bcb  movaps [rsp], xmm1
000074b6341d8bcf  movaps [rsp+0x10], xmm4
000074b6341d8bd4  movaps [rsp+0x20], xmm9
000074b6341d8bda  lea rdi, [rsp]
000074b6341d8bde  mov esi, 0x00
000074b6341d8be3  mov rax, 0x5E1AA0A2F530
000074b6341d8bed  call rax
000074b6341d8bef  movaps xmm1, [rsp]
000074b6341d8bf3  add rsp, 0x30
000074b6341d8bf7  vmovaps xmm0, [rsp]
000074b6341d8bfc  vmovaps xmm2, [rsp+0x10]
000074b6341d8c02  vmovaps xmm3, [rsp+0x20]
000074b6341d8c08  vmovaps xmm4, [rsp+0x30]
000074b6341d8c0e  vmovaps xmm5, [rsp+0x40]
000074b6341d8c14  vmovaps xmm6, [rsp+0x50]
000074b6341d8c1a  vmovaps xmm7, [rsp+0x60]
000074b6341d8c20  vmovaps xmm8, [rsp+0x70]
000074b6341d8c26  vmovaps xmm9, [rsp+0x80]
000074b6341d8c2f  vmovaps xmm10, [rsp+0x90]
000074b6341d8c38  vmovaps xmm11, [rsp+0xA0]
000074b6341d8c41  vmovaps xmm12, [rsp+0xB0]
000074b6341d8c4a  vmovaps xmm13, [rsp+0xC0]
000074b6341d8c53  vmovaps xmm14, [rsp+0xD0]
000074b6341d8c5c  vmovaps xmm15, [rsp+0xE0]
000074b6341d8c65  add rsp, 0xF0
000074b6341d8c6c  pop r11
000074b6341d8c6e  pop r10
000074b6341d8c70  pop r9
000074b6341d8c72  pop r8
000074b6341d8c74  pop rsi
000074b6341d8c75  pop rdi
000074b6341d8c76  pop rdx
000074b6341d8c77  pop rcx
000074b6341d8c78  pop rax
000074b6341d8c79  add rsp, 0x08
000074b6341d8c7d  jmp 0x000074B6341D613B
000074b6341d8c82  sub rsp, 0x08
000074b6341d8c86  push rax
000074b6341d8c87  push rcx
000074b6341d8c88  push rdx
000074b6341d8c89  push rdi
000074b6341d8c8a  push rsi
000074b6341d8c8b  push r8
000074b6341d8c8d  push r9
000074b6341d8c8f  push r10
000074b6341d8c91  push r11
000074b6341d8c93  sub rsp, 0xF0
000074b6341d8c9a  vmovaps [rsp], xmm0
000074b6341d8c9f  vmovaps [rsp+0x10], xmm1
000074b6341d8ca5  vmovaps [rsp+0x20], xmm2
000074b6341d8cab  vmovaps [rsp+0x30], xmm3
000074b6341d8cb1  vmovaps [rsp+0x40], xmm5
000074b6341d8cb7  vmovaps [rsp+0x50], xmm6
000074b6341d8cbd  vmovaps [rsp+0x60], xmm7
000074b6341d8cc3  vmovaps [rsp+0x70], xmm8
000074b6341d8cc9  vmovaps [rsp+0x80], xmm9
000074b6341d8cd2  vmovaps [rsp+0x90], xmm10
000074b6341d8cdb  vmovaps [rsp+0xA0], xmm11
000074b6341d8ce4  vmovaps [rsp+0xB0], xmm12
000074b6341d8ced  vmovaps [rsp+0xC0], xmm13
000074b6341d8cf6  vmovaps [rsp+0xD0], xmm14
000074b6341d8cff  vmovaps [rsp+0xE0], xmm15
000074b6341d8d08  sub rsp, 0x30
000074b6341d8d0c  movaps [rsp], xmm4
000074b6341d8d10  movaps [rsp+0x10], xmm2
000074b6341d8d15  movaps [rsp+0x20], xmm9
000074b6341d8d1b  lea rdi, [rsp]
000074b6341d8d1f  mov esi, 0x00
000074b6341d8d24  mov rax, 0x5E1AA0A2F530
000074b6341d8d2e  call rax
000074b6341d8d30  movaps xmm4, [rsp]
000074b6341d8d34  add rsp, 0x30
000074b6341d8d38  vmovaps xmm0, [rsp]
000074b6341d8d3d  vmovaps xmm1, [rsp+0x10]
000074b6341d8d43  vmovaps xmm2, [rsp+0x20]
000074b6341d8d49  vmovaps xmm3, [rsp+0x30]
000074b6341d8d4f  vmovaps xmm5, [rsp+0x40]
000074b6341d8d55  vmovaps xmm6, [rsp+0x50]
000074b6341d8d5b  vmovaps xmm7, [rsp+0x60]
000074b6341d8d61  vmovaps xmm8, [rsp+0x70]
000074b6341d8d67  vmovaps xmm9, [rsp+0x80]
000074b6341d8d70  vmovaps xmm10, [rsp+0x90]
000074b6341d8d79  vmovaps xmm11, [rsp+0xA0]
000074b6341d8d82  vmovaps xmm12, [rsp+0xB0]
000074b6341d8d8b  vmovaps xmm13, [rsp+0xC0]
000074b6341d8d94  vmovaps xmm14, [rsp+0xD0]
000074b6341d8d9d  vmovaps xmm15, [rsp+0xE0]
000074b6341d8da6  add rsp, 0xF0
000074b6341d8dad  pop r11
000074b6341d8daf  pop r10
000074b6341d8db1  pop r9
000074b6341d8db3  pop r8
000074b6341d8db5  pop rsi
000074b6341d8db6  pop rdi
000074b6341d8db7  pop rdx
000074b6341d8db8  pop rcx
000074b6341d8db9  pop rax
000074b6341d8dba  add rsp, 0x08
000074b6341d8dbe  jmp 0x000074B6341D616B
000074b6341d8dc3  sub rsp, 0x08
000074b6341d8dc7  push rax
000074b6341d8dc8  push rcx
000074b6341d8dc9  push rdx
000074b6341d8dca  push rdi
000074b6341d8dcb  push rsi
000074b6341d8dcc  push r8
000074b6341d8dce  push r9
000074b6341d8dd0  push r10
000074b6341d8dd2  push r11
000074b6341d8dd4  sub rsp, 0xF0
000074b6341d8ddb  vmovaps [rsp], xmm0
000074b6341d8de0  vmovaps [rsp+0x10], xmm1
000074b6341d8de6  vmovaps [rsp+0x20], xmm2
000074b6341d8dec  vmovaps [rsp+0x30], xmm3
000074b6341d8df2  vmovaps [rsp+0x40], xmm4
000074b6341d8df8  vmovaps [rsp+0x50], xmm5
000074b6341d8dfe  vmovaps [rsp+0x60], xmm6
000074b6341d8e04  vmovaps [rsp+0x70], xmm7
000074b6341d8e0a  vmovaps [rsp+0x80], xmm8
000074b6341d8e13  vmovaps [rsp+0x90], xmm10
000074b6341d8e1c  vmovaps [rsp+0xA0], xmm11
000074b6341d8e25  vmovaps [rsp+0xB0], xmm12
000074b6341d8e2e  vmovaps [rsp+0xC0], xmm13
000074b6341d8e37  vmovaps [rsp+0xD0], xmm14
000074b6341d8e40  vmovaps [rsp+0xE0], xmm15
000074b6341d8e49  sub rsp, 0x30
000074b6341d8e4d  movaps [rsp], xmm9
000074b6341d8e52  movaps [rsp+0x10], xmm2
000074b6341d8e57  movaps [rsp+0x20], xmm1
000074b6341d8e5c  lea rdi, [rsp]
000074b6341d8e60  mov esi, 0x00
000074b6341d8e65  mov rax, 0x5E1AA0A2F530
000074b6341d8e6f  call rax
000074b6341d8e71  movaps xmm9, [rsp]
000074b6341d8e76  add rsp, 0x30
000074b6341d8e7a  vmovaps xmm0, [rsp]
000074b6341d8e7f  vmovaps xmm1, [rsp+0x10]
000074b6341d8e85  vmovaps xmm2, [rsp+0x20]
000074b6341d8e8b  vmovaps xmm3, [rsp+0x30]
000074b6341d8e91  vmovaps xmm4, [rsp+0x40]
000074b6341d8e97  vmovaps xmm5, [rsp+0x50]
000074b6341d8e9d  vmovaps xmm6, [rsp+0x60]
000074b6341d8ea3  vmovaps xmm7, [rsp+0x70]
000074b6341d8ea9  vmovaps xmm8, [rsp+0x80]
000074b6341d8eb2  vmovaps xmm10, [rsp+0x90]
000074b6341d8ebb  vmovaps xmm11, [rsp+0xA0]
000074b6341d8ec4  vmovaps xmm12, [rsp+0xB0]
000074b6341d8ecd  vmovaps xmm13, [rsp+0xC0]
000074b6341d8ed6  vmovaps xmm14, [rsp+0xD0]
000074b6341d8edf  vmovaps xmm15, [rsp+0xE0]
000074b6341d8ee8  add rsp, 0xF0
000074b6341d8eef  pop r11
000074b6341d8ef1  pop r10
000074b6341d8ef3  pop r9
000074b6341d8ef5  pop r8
000074b6341d8ef7  pop rsi
000074b6341d8ef8  pop rdi
000074b6341d8ef9  pop rdx
000074b6341d8efa  pop rcx
000074b6341d8efb  pop rax
000074b6341d8efc  add rsp, 0x08
000074b6341d8f00  jmp 0x000074B6341D61A1
000074b6341d8f05  sub rsp, 0x08
000074b6341d8f09  push rax
000074b6341d8f0a  push rcx
000074b6341d8f0b  push rdx
000074b6341d8f0c  push rdi
000074b6341d8f0d  push rsi
000074b6341d8f0e  push r8
000074b6341d8f10  push r9
000074b6341d8f12  push r10
000074b6341d8f14  push r11
000074b6341d8f16  sub rsp, 0xF0
000074b6341d8f1d  vmovaps [rsp], xmm0
000074b6341d8f22  vmovaps [rsp+0x10], xmm2
000074b6341d8f28  vmovaps [rsp+0x20], xmm3
000074b6341d8f2e  vmovaps [rsp+0x30], xmm4
000074b6341d8f34  vmovaps [rsp+0x40], xmm5
000074b6341d8f3a  vmovaps [rsp+0x50], xmm6
000074b6341d8f40  vmovaps [rsp+0x60], xmm7
000074b6341d8f46  vmovaps [rsp+0x70], xmm8
000074b6341d8f4c  vmovaps [rsp+0x80], xmm9
000074b6341d8f55  vmovaps [rsp+0x90], xmm10
000074b6341d8f5e  vmovaps [rsp+0xA0], xmm11
000074b6341d8f67  vmovaps [rsp+0xB0], xmm12
000074b6341d8f70  vmovaps [rsp+0xC0], xmm13
000074b6341d8f79  vmovaps [rsp+0xD0], xmm14
000074b6341d8f82  vmovaps [rsp+0xE0], xmm15
000074b6341d8f8b  sub rsp, 0x30
000074b6341d8f8f  movaps [rsp], xmm1
000074b6341d8f93  movaps [rsp+0x10], xmm15
000074b6341d8f99  movaps [rsp+0x20], xmm6
000074b6341d8f9e  lea rdi, [rsp]
000074b6341d8fa2  mov esi, 0x00
000074b6341d8fa7  mov rax, 0x5E1AA0A2F530
000074b6341d8fb1  call rax
000074b6341d8fb3  movaps xmm1, [rsp]
000074b6341d8fb7  add rsp, 0x30
000074b6341d8fbb  vmovaps xmm0, [rsp]
000074b6341d8fc0  vmovaps xmm2, [rsp+0x10]
000074b6341d8fc6  vmovaps xmm3, [rsp+0x20]
000074b6341d8fcc  vmovaps xmm4, [rsp+0x30]
000074b6341d8fd2  vmovaps xmm5, [rsp+0x40]
000074b6341d8fd8  vmovaps xmm6, [rsp+0x50]
000074b6341d8fde  vmovaps xmm7, [rsp+0x60]
000074b6341d8fe4  vmovaps xmm8, [rsp+0x70]
000074b6341d8fea  vmovaps xmm9, [rsp+0x80]
000074b6341d8ff3  vmovaps xmm10, [rsp+0x90]
000074b6341d8ffc  vmovaps xmm11, [rsp+0xA0]
000074b6341d9005  vmovaps xmm12, [rsp+0xB0]
000074b6341d900e  vmovaps xmm13, [rsp+0xC0]
000074b6341d9017  vmovaps xmm14, [rsp+0xD0]
000074b6341d9020  vmovaps xmm15, [rsp+0xE0]
000074b6341d9029  add rsp, 0xF0
000074b6341d9030  pop r11
000074b6341d9032  pop r10
000074b6341d9034  pop r9
000074b6341d9036  pop r8
000074b6341d9038  pop rsi
000074b6341d9039  pop rdi
000074b6341d903a  pop rdx
000074b6341d903b  pop rcx
000074b6341d903c  pop rax
000074b6341d903d  add rsp, 0x08
000074b6341d9041  jmp 0x000074B6341D61C2
000074b6341d9046  sub rsp, 0x08
000074b6341d904a  push rax
000074b6341d904b  push rcx
000074b6341d904c  push rdx
000074b6341d904d  push rdi
000074b6341d904e  push rsi
000074b6341d904f  push r8
000074b6341d9051  push r9
000074b6341d9053  push r10
000074b6341d9055  push r11
000074b6341d9057  sub rsp, 0xF0
000074b6341d905e  vmovaps [rsp], xmm0
000074b6341d9063  vmovaps [rsp+0x10], xmm1
000074b6341d9069  vmovaps [rsp+0x20], xmm2
000074b6341d906f  vmovaps [rsp+0x30], xmm3
000074b6341d9075  vmovaps [rsp+0x40], xmm4
000074b6341d907b  vmovaps [rsp+0x50], xmm5
000074b6341d9081  vmovaps [rsp+0x60], xmm6
000074b6341d9087  vmovaps [rsp+0x70], xmm7
000074b6341d908d  vmovaps [rsp+0x80], xmm8
000074b6341d9096  vmovaps [rsp+0x90], xmm9
000074b6341d909f  vmovaps [rsp+0xA0], xmm10
000074b6341d90a8  vmovaps [rsp+0xB0], xmm11
000074b6341d90b1  vmovaps [rsp+0xC0], xmm12
000074b6341d90ba  vmovaps [rsp+0xD0], xmm13
000074b6341d90c3  vmovaps [rsp+0xE0], xmm14
000074b6341d90cc  sub rsp, 0x30
000074b6341d90d0  movaps [rsp], xmm15
000074b6341d90d5  movaps [rsp+0x10], xmm5
000074b6341d90da  movaps [rsp+0x20], xmm3
000074b6341d90df  lea rdi, [rsp]
000074b6341d90e3  mov esi, 0x00
000074b6341d90e8  mov rax, 0x5E1AA0A2F530
000074b6341d90f2  call rax
000074b6341d90f4  movaps xmm15, [rsp]
000074b6341d90f9  add rsp, 0x30
000074b6341d90fd  vmovaps xmm0, [rsp]
000074b6341d9102  vmovaps xmm1, [rsp+0x10]
000074b6341d9108  vmovaps xmm2, [rsp+0x20]
000074b6341d910e  vmovaps xmm3, [rsp+0x30]
000074b6341d9114  vmovaps xmm4, [rsp+0x40]
000074b6341d911a  vmovaps xmm5, [rsp+0x50]
000074b6341d9120  vmovaps xmm6, [rsp+0x60]
000074b6341d9126  vmovaps xmm7, [rsp+0x70]
000074b6341d912c  vmovaps xmm8, [rsp+0x80]
000074b6341d9135  vmovaps xmm9, [rsp+0x90]
000074b6341d913e  vmovaps xmm10, [rsp+0xA0]
000074b6341d9147  vmovaps xmm11, [rsp+0xB0]
000074b6341d9150  vmovaps xmm12, [rsp+0xC0]
000074b6341d9159  vmovaps xmm13, [rsp+0xD0]
000074b6341d9162  vmovaps xmm14, [rsp+0xE0]
000074b6341d916b  add rsp, 0xF0
000074b6341d9172  pop r11
000074b6341d9174  pop r10
000074b6341d9176  pop r9
000074b6341d9178  pop r8
000074b6341d917a  pop rsi
000074b6341d917b  pop rdi
000074b6341d917c  pop rdx
000074b6341d917d  pop rcx
000074b6341d917e  pop rax
000074b6341d917f  add rsp, 0x08
000074b6341d9183  jmp 0x000074B6341D61DC
000074b6341d9188  sub rsp, 0x08
000074b6341d918c  push rax
000074b6341d918d  push rcx
000074b6341d918e  push rdx
000074b6341d918f  push rdi
000074b6341d9190  push rsi
000074b6341d9191  push r8
000074b6341d9193  push r9
000074b6341d9195  push r10
000074b6341d9197  push r11
000074b6341d9199  sub rsp, 0xF0
000074b6341d91a0  vmovaps [rsp], xmm0
000074b6341d91a5  vmovaps [rsp+0x10], xmm1
000074b6341d91ab  vmovaps [rsp+0x20], xmm2
000074b6341d91b1  vmovaps [rsp+0x30], xmm3
000074b6341d91b7  vmovaps [rsp+0x40], xmm4
000074b6341d91bd  vmovaps [rsp+0x50], xmm6
000074b6341d91c3  vmovaps [rsp+0x60], xmm7
000074b6341d91c9  vmovaps [rsp+0x70], xmm8
000074b6341d91cf  vmovaps [rsp+0x80], xmm9
000074b6341d91d8  vmovaps [rsp+0x90], xmm10
000074b6341d91e1  vmovaps [rsp+0xA0], xmm11
000074b6341d91ea  vmovaps [rsp+0xB0], xmm12
000074b6341d91f3  vmovaps [rsp+0xC0], xmm13
000074b6341d91fc  vmovaps [rsp+0xD0], xmm14
000074b6341d9205  vmovaps [rsp+0xE0], xmm15
000074b6341d920e  sub rsp, 0x30
000074b6341d9212  movaps [rsp], xmm5
000074b6341d9216  movaps [rsp+0x10], xmm8
000074b6341d921c  movaps [rsp+0x20], xmm6
000074b6341d9221  lea rdi, [rsp]
000074b6341d9225  mov esi, 0x00
000074b6341d922a  mov rax, 0x5E1AA0A2F530
000074b6341d9234  call rax
000074b6341d9236  movaps xmm5, [rsp]
000074b6341d923a  add rsp, 0x30
000074b6341d923e  vmovaps xmm0, [rsp]
000074b6341d9243  vmovaps xmm1, [rsp+0x10]
000074b6341d9249  vmovaps xmm2, [rsp+0x20]
000074b6341d924f  vmovaps xmm3, [rsp+0x30]
000074b6341d9255  vmovaps xmm4, [rsp+0x40]
000074b6341d925b  vmovaps xmm6, [rsp+0x50]
000074b6341d9261  vmovaps xmm7, [rsp+0x60]
000074b6341d9267  vmovaps xmm8, [rsp+0x70]
000074b6341d926d  vmovaps xmm9, [rsp+0x80]
000074b6341d9276  vmovaps xmm10, [rsp+0x90]
000074b6341d927f  vmovaps xmm11, [rsp+0xA0]
000074b6341d9288  vmovaps xmm12, [rsp+0xB0]
000074b6341d9291  vmovaps xmm13, [rsp+0xC0]
000074b6341d929a  vmovaps xmm14, [rsp+0xD0]
000074b6341d92a3  vmovaps xmm15, [rsp+0xE0]
000074b6341d92ac  add rsp, 0xF0
000074b6341d92b3  pop r11
000074b6341d92b5  pop r10
000074b6341d92b7  pop r9
000074b6341d92b9  pop r8
000074b6341d92bb  pop rsi
000074b6341d92bc  pop rdi
000074b6341d92bd  pop rdx
000074b6341d92be  pop rcx
000074b6341d92bf  pop rax
000074b6341d92c0  add rsp, 0x08
000074b6341d92c4  jmp 0x000074B6341D6200
000074b6341d92c9  sub rsp, 0x08
000074b6341d92cd  push rax
000074b6341d92ce  push rcx
000074b6341d92cf  push rdx
000074b6341d92d0  push rdi
000074b6341d92d1  push rsi
000074b6341d92d2  push r8
000074b6341d92d4  push r9
000074b6341d92d6  push r10
000074b6341d92d8  push r11
000074b6341d92da  sub rsp, 0xF0
000074b6341d92e1  vmovaps [rsp], xmm0
000074b6341d92e6  vmovaps [rsp+0x10], xmm1
000074b6341d92ec  vmovaps [rsp+0x20], xmm2
000074b6341d92f2  vmovaps [rsp+0x30], xmm3
000074b6341d92f8  vmovaps [rsp+0x40], xmm4
000074b6341d92fe  vmovaps [rsp+0x50], xmm5
000074b6341d9304  vmovaps [rsp+0x60], xmm7
000074b6341d930a  vmovaps [rsp+0x70], xmm8
000074b6341d9310  vmovaps [rsp+0x80], xmm9
000074b6341d9319  vmovaps [rsp+0x90], xmm10
000074b6341d9322  vmovaps [rsp+0xA0], xmm11
000074b6341d932b  vmovaps [rsp+0xB0], xmm12
000074b6341d9334  vmovaps [rsp+0xC0], xmm13
000074b6341d933d  vmovaps [rsp+0xD0], xmm14
000074b6341d9346  vmovaps [rsp+0xE0], xmm15
000074b6341d934f  sub rsp, 0x30
000074b6341d9353  movaps [rsp], xmm6
000074b6341d9357  movaps [rsp+0x10], xmm10
000074b6341d935d  movaps [rsp+0x20], xmm8
000074b6341d9363  lea rdi, [rsp]
000074b6341d9367  mov esi, 0x00
000074b6341d936c  mov rax, 0x5E1AA0A2F530
000074b6341d9376  call rax
000074b6341d9378  movaps xmm6, [rsp]
000074b6341d937c  add rsp, 0x30
000074b6341d9380  vmovaps xmm0, [rsp]
000074b6341d9385  vmovaps xmm1, [rsp+0x10]
000074b6341d938b  vmovaps xmm2, [rsp+0x20]
000074b6341d9391  vmovaps xmm3, [rsp+0x30]
000074b6341d9397  vmovaps xmm4, [rsp+0x40]
000074b6341d939d  vmovaps xmm5, [rsp+0x50]
000074b6341d93a3  vmovaps xmm7, [rsp+0x60]
000074b6341d93a9  vmovaps xmm8, [rsp+0x70]
000074b6341d93af  vmovaps xmm9, [rsp+0x80]
000074b6341d93b8  vmovaps xmm10, [rsp+0x90]
000074b6341d93c1  vmovaps xmm11, [rsp+0xA0]
000074b6341d93ca  vmovaps xmm12, [rsp+0xB0]
000074b6341d93d3  vmovaps xmm13, [rsp+0xC0]
000074b6341d93dc  vmovaps xmm14, [rsp+0xD0]
000074b6341d93e5  vmovaps xmm15, [rsp+0xE0]
000074b6341d93ee  add rsp, 0xF0
000074b6341d93f5  pop r11
000074b6341d93f7  pop r10
000074b6341d93f9  pop r9
000074b6341d93fb  pop r8
000074b6341d93fd  pop rsi
000074b6341d93fe  pop rdi
000074b6341d93ff  pop rdx
000074b6341d9400  pop rcx
000074b6341d9401  pop rax
000074b6341d9402  add rsp, 0x08
000074b6341d9406  jmp 0x000074B6341D6225
000074b6341d940b  sub rsp, 0x08
000074b6341d940f  push rax
000074b6341d9410  push rcx
000074b6341d9411  push rdx
000074b6341d9412  push rdi
000074b6341d9413  push rsi
000074b6341d9414  push r8
000074b6341d9416  push r9
000074b6341d9418  push r10
000074b6341d941a  push r11
000074b6341d941c  sub rsp, 0xF0
000074b6341d9423  vmovaps [rsp], xmm0
000074b6341d9428  vmovaps [rsp+0x10], xmm1
000074b6341d942e  vmovaps [rsp+0x20], xmm2
000074b6341d9434  vmovaps [rsp+0x30], xmm3
000074b6341d943a  vmovaps [rsp+0x40], xmm4
000074b6341d9440  vmovaps [rsp+0x50], xmm5
000074b6341d9446  vmovaps [rsp+0x60], xmm6
000074b6341d944c  vmovaps [rsp+0x70], xmm7
000074b6341d9452  vmovaps [rsp+0x80], xmm8
000074b6341d945b  vmovaps [rsp+0x90], xmm9
000074b6341d9464  vmovaps [rsp+0xA0], xmm11
000074b6341d946d  vmovaps [rsp+0xB0], xmm12
000074b6341d9476  vmovaps [rsp+0xC0], xmm13
000074b6341d947f  vmovaps [rsp+0xD0], xmm14
000074b6341d9488  vmovaps [rsp+0xE0], xmm15
000074b6341d9491  sub rsp, 0x30
000074b6341d9495  movaps [rsp], xmm10
000074b6341d949a  movaps [rsp+0x10], xmm8
000074b6341d94a0  movaps [rsp+0x20], xmm14
000074b6341d94a6  lea rdi, [rsp]
000074b6341d94aa  mov esi, 0x00
000074b6341d94af  mov rax, 0x5E1AA0A2F530
000074b6341d94b9  call rax
000074b6341d94bb  movaps xmm10, [rsp]
000074b6341d94c0  add rsp, 0x30
000074b6341d94c4  vmovaps xmm0, [rsp]
000074b6341d94c9  vmovaps xmm1, [rsp+0x10]
000074b6341d94cf  vmovaps xmm2, [rsp+0x20]
000074b6341d94d5  vmovaps xmm3, [rsp+0x30]
000074b6341d94db  vmovaps xmm4, [rsp+0x40]
000074b6341d94e1  vmovaps xmm5, [rsp+0x50]
000074b6341d94e7  vmovaps xmm6, [rsp+0x60]
000074b6341d94ed  vmovaps xmm7, [rsp+0x70]
000074b6341d94f3  vmovaps xmm8, [rsp+0x80]
000074b6341d94fc  vmovaps xmm9, [rsp+0x90]
000074b6341d9505  vmovaps xmm11, [rsp+0xA0]
000074b6341d950e  vmovaps xmm12, [rsp+0xB0]
000074b6341d9517  vmovaps xmm13, [rsp+0xC0]
000074b6341d9520  vmovaps xmm14, [rsp+0xD0]
000074b6341d9529  vmovaps xmm15, [rsp+0xE0]
000074b6341d9532  add rsp, 0xF0
000074b6341d9539  pop r11
000074b6341d953b  pop r10
000074b6341d953d  pop r9
000074b6341d953f  pop r8
000074b6341d9541  pop rsi
000074b6341d9542  pop rdi
000074b6341d9543  pop rdx
000074b6341d9544  pop rcx
000074b6341d9545  pop rax
000074b6341d9546  add rsp, 0x08
000074b6341d954a  jmp 0x000074B6341D6245
000074b6341d954f  sub rsp, 0x08
000074b6341d9553  push rax
000074b6341d9554  push rcx
000074b6341d9555  push rdx
000074b6341d9556  push rdi
000074b6341d9557  push rsi
000074b6341d9558  push r8
000074b6341d955a  push r9
000074b6341d955c  push r10
000074b6341d955e  push r11
000074b6341d9560  sub rsp, 0xF0
000074b6341d9567  vmovaps [rsp], xmm0
000074b6341d956c  vmovaps [rsp+0x10], xmm1
000074b6341d9572  vmovaps [rsp+0x20], xmm2
000074b6341d9578  vmovaps [rsp+0x30], xmm3
000074b6341d957e  vmovaps [rsp+0x40], xmm4
000074b6341d9584  vmovaps [rsp+0x50], xmm5
000074b6341d958a  vmovaps [rsp+0x60], xmm6
000074b6341d9590  vmovaps [rsp+0x70], xmm7
000074b6341d9596  vmovaps [rsp+0x80], xmm8
000074b6341d959f  vmovaps [rsp+0x90], xmm9
000074b6341d95a8  vmovaps [rsp+0xA0], xmm10
000074b6341d95b1  vmovaps [rsp+0xB0], xmm11
000074b6341d95ba  vmovaps [rsp+0xC0], xmm12
000074b6341d95c3  vmovaps [rsp+0xD0], xmm13
000074b6341d95cc  vmovaps [rsp+0xE0], xmm15
000074b6341d95d5  sub rsp, 0x30
000074b6341d95d9  movaps [rsp], xmm14
000074b6341d95de  movaps [rsp+0x10], xmm8
000074b6341d95e4  movaps [rsp+0x20], xmm4
000074b6341d95e9  lea rdi, [rsp]
000074b6341d95ed  mov esi, 0x00
000074b6341d95f2  mov rax, 0x5E1AA0A2F530
000074b6341d95fc  call rax
000074b6341d95fe  movaps xmm14, [rsp]
000074b6341d9603  add rsp, 0x30
000074b6341d9607  vmovaps xmm0, [rsp]
000074b6341d960c  vmovaps xmm1, [rsp+0x10]
000074b6341d9612  vmovaps xmm2, [rsp+0x20]
000074b6341d9618  vmovaps xmm3, [rsp+0x30]
000074b6341d961e  vmovaps xmm4, [rsp+0x40]
000074b6341d9624  vmovaps xmm5, [rsp+0x50]
000074b6341d962a  vmovaps xmm6, [rsp+0x60]
000074b6341d9630  vmovaps xmm7, [rsp+0x70]
000074b6341d9636  vmovaps xmm8, [rsp+0x80]
000074b6341d963f  vmovaps xmm9, [rsp+0x90]
000074b6341d9648  vmovaps xmm10, [rsp+0xA0]
000074b6341d9651  vmovaps xmm11, [rsp+0xB0]
000074b6341d965a  vmovaps xmm12, [rsp+0xC0]
000074b6341d9663  vmovaps xmm13, [rsp+0xD0]
000074b6341d966c  vmovaps xmm15, [rsp+0xE0]
000074b6341d9675  add rsp, 0xF0
000074b6341d967c  pop r11
000074b6341d967e  pop r10
000074b6341d9680  pop r9
000074b6341d9682  pop r8
000074b6341d9684  pop rsi
000074b6341d9685  pop rdi
000074b6341d9686  pop rdx
000074b6341d9687  pop rcx
000074b6341d9688  pop rax
000074b6341d9689  add rsp, 0x08
000074b6341d968d  jmp 0x000074B6341D6265
000074b6341d9692  sub rsp, 0x08
000074b6341d9696  push rax
000074b6341d9697  push rcx
000074b6341d9698  push rdx
000074b6341d9699  push rdi
000074b6341d969a  push rsi
000074b6341d969b  push r8
000074b6341d969d  push r9
000074b6341d969f  push r10
000074b6341d96a1  push r11
000074b6341d96a3  sub rsp, 0xF0
000074b6341d96aa  vmovaps [rsp], xmm0
000074b6341d96af  vmovaps [rsp+0x10], xmm1
000074b6341d96b5  vmovaps [rsp+0x20], xmm2
000074b6341d96bb  vmovaps [rsp+0x30], xmm3
000074b6341d96c1  vmovaps [rsp+0x40], xmm5
000074b6341d96c7  vmovaps [rsp+0x50], xmm6
000074b6341d96cd  vmovaps [rsp+0x60], xmm7
000074b6341d96d3  vmovaps [rsp+0x70], xmm8
000074b6341d96d9  vmovaps [rsp+0x80], xmm9
000074b6341d96e2  vmovaps [rsp+0x90], xmm10
000074b6341d96eb  vmovaps [rsp+0xA0], xmm11
000074b6341d96f4  vmovaps [rsp+0xB0], xmm12
000074b6341d96fd  vmovaps [rsp+0xC0], xmm13
000074b6341d9706  vmovaps [rsp+0xD0], xmm14
000074b6341d970f  vmovaps [rsp+0xE0], xmm15
000074b6341d9718  sub rsp, 0x30
000074b6341d971c  movaps [rsp], xmm4
000074b6341d9720  movaps [rsp+0x10], xmm13
000074b6341d9726  movaps [rsp+0x20], xmm8
000074b6341d972c  lea rdi, [rsp]
000074b6341d9730  mov esi, 0x00
000074b6341d9735  mov rax, 0x5E1AA0A2F530
000074b6341d973f  call rax
000074b6341d9741  movaps xmm4, [rsp]
000074b6341d9745  add rsp, 0x30
000074b6341d9749  vmovaps xmm0, [rsp]
000074b6341d974e  vmovaps xmm1, [rsp+0x10]
000074b6341d9754  vmovaps xmm2, [rsp+0x20]
000074b6341d975a  vmovaps xmm3, [rsp+0x30]
000074b6341d9760  vmovaps xmm5, [rsp+0x40]
000074b6341d9766  vmovaps xmm6, [rsp+0x50]
000074b6341d976c  vmovaps xmm7, [rsp+0x60]
000074b6341d9772  vmovaps xmm8, [rsp+0x70]
000074b6341d9778  vmovaps xmm9, [rsp+0x80]
000074b6341d9781  vmovaps xmm10, [rsp+0x90]
000074b6341d978a  vmovaps xmm11, [rsp+0xA0]
000074b6341d9793  vmovaps xmm12, [rsp+0xB0]
000074b6341d979c  vmovaps xmm13, [rsp+0xC0]
000074b6341d97a5  vmovaps xmm14, [rsp+0xD0]
000074b6341d97ae  vmovaps xmm15, [rsp+0xE0]
000074b6341d97b7  add rsp, 0xF0
000074b6341d97be  pop r11
000074b6341d97c0  pop r10
000074b6341d97c2  pop r9
000074b6341d97c4  pop r8
000074b6341d97c6  pop rsi
000074b6341d97c7  pop rdi
000074b6341d97c8  pop rdx
000074b6341d97c9  pop rcx
000074b6341d97ca  pop rax
000074b6341d97cb  add rsp, 0x08
000074b6341d97cf  jmp 0x000074B6341D628A
000074b6341d97d4  sub rsp, 0x08
000074b6341d97d8  push rax
000074b6341d97d9  push rcx
000074b6341d97da  push rdx
000074b6341d97db  push rdi
000074b6341d97dc  push rsi
000074b6341d97dd  push r8
000074b6341d97df  push r9
000074b6341d97e1  push r10
000074b6341d97e3  push r11
000074b6341d97e5  sub rsp, 0xF0
000074b6341d97ec  vmovaps [rsp], xmm0
000074b6341d97f1  vmovaps [rsp+0x10], xmm1
000074b6341d97f7  vmovaps [rsp+0x20], xmm2
000074b6341d97fd  vmovaps [rsp+0x30], xmm3
000074b6341d9803  vmovaps [rsp+0x40], xmm4
000074b6341d9809  vmovaps [rsp+0x50], xmm5
000074b6341d980f  vmovaps [rsp+0x60], xmm6
000074b6341d9815  vmovaps [rsp+0x70], xmm7
000074b6341d981b  vmovaps [rsp+0x80], xmm8
000074b6341d9824  vmovaps [rsp+0x90], xmm9
000074b6341d982d  vmovaps [rsp+0xA0], xmm10
000074b6341d9836  vmovaps [rsp+0xB0], xmm11
000074b6341d983f  vmovaps [rsp+0xC0], xmm12
000074b6341d9848  vmovaps [rsp+0xD0], xmm14
000074b6341d9851  vmovaps [rsp+0xE0], xmm15
000074b6341d985a  sub rsp, 0x30
000074b6341d985e  movaps [rsp], xmm13
000074b6341d9863  movaps [rsp+0x10], xmm15
000074b6341d9869  movaps [rsp+0x20], xmm9
000074b6341d986f  lea rdi, [rsp]
000074b6341d9873  mov esi, 0x00
000074b6341d9878  mov rax, 0x5E1AA0A2F530
000074b6341d9882  call rax
000074b6341d9884  movaps xmm13, [rsp]
000074b6341d9889  add rsp, 0x30
000074b6341d988d  vmovaps xmm0, [rsp]
000074b6341d9892  vmovaps xmm1, [rsp+0x10]
000074b6341d9898  vmovaps xmm2, [rsp+0x20]
000074b6341d989e  vmovaps xmm3, [rsp+0x30]
000074b6341d98a4  vmovaps xmm4, [rsp+0x40]
000074b6341d98aa  vmovaps xmm5, [rsp+0x50]
000074b6341d98b0  vmovaps xmm6, [rsp+0x60]
000074b6341d98b6  vmovaps xmm7, [rsp+0x70]
000074b6341d98bc  vmovaps xmm8, [rsp+0x80]
000074b6341d98c5  vmovaps xmm9, [rsp+0x90]
000074b6341d98ce  vmovaps xmm10, [rsp+0xA0]
000074b6341d98d7  vmovaps xmm11, [rsp+0xB0]
000074b6341d98e0  vmovaps xmm12, [rsp+0xC0]
000074b6341d98e9  vmovaps xmm14, [rsp+0xD0]
000074b6341d98f2  vmovaps xmm15, [rsp+0xE0]
000074b6341d98fb  add rsp, 0xF0
000074b6341d9902  pop r11
000074b6341d9904  pop r10
000074b6341d9906  pop r9
000074b6341d9908  pop r8
000074b6341d990a  pop rsi
000074b6341d990b  pop rdi
000074b6341d990c  pop rdx
000074b6341d990d  pop rcx
000074b6341d990e  pop rax
000074b6341d990f  add rsp, 0x08
000074b6341d9913  jmp 0x000074B6341D62A5
000074b6341d9918  sub rsp, 0x08
000074b6341d991c  push rax
000074b6341d991d  push rcx
000074b6341d991e  push rdx
000074b6341d991f  push rdi
000074b6341d9920  push rsi
000074b6341d9921  push r8
000074b6341d9923  push r9
000074b6341d9925  push r10
000074b6341d9927  push r11
000074b6341d9929  sub rsp, 0xF0
000074b6341d9930  vmovaps [rsp], xmm0
000074b6341d9935  vmovaps [rsp+0x10], xmm1
000074b6341d993b  vmovaps [rsp+0x20], xmm2
000074b6341d9941  vmovaps [rsp+0x30], xmm3
000074b6341d9947  vmovaps [rsp+0x40], xmm4
000074b6341d994d  vmovaps [rsp+0x50], xmm5
000074b6341d9953  vmovaps [rsp+0x60], xmm6
000074b6341d9959  vmovaps [rsp+0x70], xmm7
000074b6341d995f  vmovaps [rsp+0x80], xmm8
000074b6341d9968  vmovaps [rsp+0x90], xmm9
000074b6341d9971  vmovaps [rsp+0xA0], xmm10
000074b6341d997a  vmovaps [rsp+0xB0], xmm11
000074b6341d9983  vmovaps [rsp+0xC0], xmm12
000074b6341d998c  vmovaps [rsp+0xD0], xmm13
000074b6341d9995  vmovaps [rsp+0xE0], xmm14
000074b6341d999e  sub rsp, 0x30
000074b6341d99a2  movaps [rsp], xmm15
000074b6341d99a7  movaps [rsp+0x10], xmm1
000074b6341d99ac  movaps [rsp+0x20], xmm5
000074b6341d99b1  lea rdi, [rsp]
000074b6341d99b5  mov esi, 0x00
000074b6341d99ba  mov rax, 0x5E1AA0A2F530
000074b6341d99c4  call rax
000074b6341d99c6  movaps xmm15, [rsp]
000074b6341d99cb  add rsp, 0x30
000074b6341d99cf  vmovaps xmm0, [rsp]
000074b6341d99d4  vmovaps xmm1, [rsp+0x10]
000074b6341d99da  vmovaps xmm2, [rsp+0x20]
000074b6341d99e0  vmovaps xmm3, [rsp+0x30]
000074b6341d99e6  vmovaps xmm4, [rsp+0x40]
000074b6341d99ec  vmovaps xmm5, [rsp+0x50]
000074b6341d99f2  vmovaps xmm6, [rsp+0x60]
000074b6341d99f8  vmovaps xmm7, [rsp+0x70]
000074b6341d99fe  vmovaps xmm8, [rsp+0x80]
000074b6341d9a07  vmovaps xmm9, [rsp+0x90]
000074b6341d9a10  vmovaps xmm10, [rsp+0xA0]
000074b6341d9a19  vmovaps xmm11, [rsp+0xB0]
000074b6341d9a22  vmovaps xmm12, [rsp+0xC0]
000074b6341d9a2b  vmovaps xmm13, [rsp+0xD0]
000074b6341d9a34  vmovaps xmm14, [rsp+0xE0]
000074b6341d9a3d  add rsp, 0xF0
000074b6341d9a44  pop r11
000074b6341d9a46  pop r10
000074b6341d9a48  pop r9
000074b6341d9a4a  pop r8
000074b6341d9a4c  pop rsi
000074b6341d9a4d  pop rdi
000074b6341d9a4e  pop rdx
000074b6341d9a4f  pop rcx
000074b6341d9a50  pop rax
000074b6341d9a51  add rsp, 0x08
000074b6341d9a55  jmp 0x000074B6341D62C0
000074b6341d9a5a  call 0x000074B6340D64F0
000074b6341d9a5f  jmp 0x000074B6341D631B
000074b6341d9a64  sub rsp, 0x08
000074b6341d9a68  push rax
000074b6341d9a69  push rcx
000074b6341d9a6a  push rdx
000074b6341d9a6b  push rdi
000074b6341d9a6c  push rsi
000074b6341d9a6d  push r8
000074b6341d9a6f  push r9
000074b6341d9a71  push r10
000074b6341d9a73  push r11
000074b6341d9a75  sub rsp, 0xF0
000074b6341d9a7c  vmovaps [rsp], xmm0
000074b6341d9a81  vmovaps [rsp+0x10], xmm1
000074b6341d9a87  vmovaps [rsp+0x20], xmm2
000074b6341d9a8d  vmovaps [rsp+0x30], xmm3
000074b6341d9a93  vmovaps [rsp+0x40], xmm4
000074b6341d9a99  vmovaps [rsp+0x50], xmm5
000074b6341d9a9f  vmovaps [rsp+0x60], xmm6
000074b6341d9aa5  vmovaps [rsp+0x70], xmm7
000074b6341d9aab  vmovaps [rsp+0x80], xmm8
000074b6341d9ab4  vmovaps [rsp+0x90], xmm10
000074b6341d9abd  vmovaps [rsp+0xA0], xmm11
000074b6341d9ac6  vmovaps [rsp+0xB0], xmm12
000074b6341d9acf  vmovaps [rsp+0xC0], xmm13
000074b6341d9ad8  vmovaps [rsp+0xD0], xmm14
000074b6341d9ae1  vmovaps [rsp+0xE0], xmm15
000074b6341d9aea  sub rsp, 0x30
000074b6341d9aee  movaps [rsp], xmm9
000074b6341d9af3  movaps [rsp+0x10], xmm8
000074b6341d9af9  movaps [rsp+0x20], xmm11
000074b6341d9aff  lea rdi, [rsp]
000074b6341d9b03  mov esi, 0x00
000074b6341d9b08  mov rax, 0x5E1AA0A2F530
000074b6341d9b12  call rax
000074b6341d9b14  movaps xmm9, [rsp]
000074b6341d9b19  add rsp, 0x30
000074b6341d9b1d  vmovaps xmm0, [rsp]
000074b6341d9b22  vmovaps xmm1, [rsp+0x10]
000074b6341d9b28  vmovaps xmm2, [rsp+0x20]
000074b6341d9b2e  vmovaps xmm3, [rsp+0x30]
000074b6341d9b34  vmovaps xmm4, [rsp+0x40]
000074b6341d9b3a  vmovaps xmm5, [rsp+0x50]
000074b6341d9b40  vmovaps xmm6, [rsp+0x60]
000074b6341d9b46  vmovaps xmm7, [rsp+0x70]
000074b6341d9b4c  vmovaps xmm8, [rsp+0x80]
000074b6341d9b55  vmovaps xmm10, [rsp+0x90]
000074b6341d9b5e  vmovaps xmm11, [rsp+0xA0]
000074b6341d9b67  vmovaps xmm12, [rsp+0xB0]
000074b6341d9b70  vmovaps xmm13, [rsp+0xC0]
000074b6341d9b79  vmovaps xmm14, [rsp+0xD0]
000074b6341d9b82  vmovaps xmm15, [rsp+0xE0]
000074b6341d9b8b  add rsp, 0xF0
000074b6341d9b92  pop r11
000074b6341d9b94  pop r10
000074b6341d9b96  pop r9
000074b6341d9b98  pop r8
000074b6341d9b9a  pop rsi
000074b6341d9b9b  pop rdi
000074b6341d9b9c  pop rdx
000074b6341d9b9d  pop rcx
000074b6341d9b9e  pop rax
000074b6341d9b9f  add rsp, 0x08
000074b6341d9ba3  jmp 0x000074B6341D6352
000074b6341d9ba8  sub rsp, 0x08
000074b6341d9bac  push rax
000074b6341d9bad  push rcx
000074b6341d9bae  push rdx
000074b6341d9baf  push rdi
000074b6341d9bb0  push rsi
000074b6341d9bb1  push r8
000074b6341d9bb3  push r9
000074b6341d9bb5  push r10
000074b6341d9bb7  push r11
000074b6341d9bb9  sub rsp, 0xF0
000074b6341d9bc0  vmovaps [rsp], xmm0
000074b6341d9bc5  vmovaps [rsp+0x10], xmm1
000074b6341d9bcb  vmovaps [rsp+0x20], xmm2
000074b6341d9bd1  vmovaps [rsp+0x30], xmm3
000074b6341d9bd7  vmovaps [rsp+0x40], xmm4
000074b6341d9bdd  vmovaps [rsp+0x50], xmm5
000074b6341d9be3  vmovaps [rsp+0x60], xmm6
000074b6341d9be9  vmovaps [rsp+0x70], xmm7
000074b6341d9bef  vmovaps [rsp+0x80], xmm8
000074b6341d9bf8  vmovaps [rsp+0x90], xmm9
000074b6341d9c01  vmovaps [rsp+0xA0], xmm10
000074b6341d9c0a  vmovaps [rsp+0xB0], xmm12
000074b6341d9c13  vmovaps [rsp+0xC0], xmm13
000074b6341d9c1c  vmovaps [rsp+0xD0], xmm14
000074b6341d9c25  vmovaps [rsp+0xE0], xmm15
000074b6341d9c2e  sub rsp, 0x30
000074b6341d9c32  movaps [rsp], xmm11
000074b6341d9c37  movaps [rsp+0x10], xmm10
000074b6341d9c3d  movaps [rsp+0x20], xmm6
000074b6341d9c42  lea rdi, [rsp]
000074b6341d9c46  mov esi, 0x00
000074b6341d9c4b  mov rax, 0x5E1AA0A2F530
000074b6341d9c55  call rax
000074b6341d9c57  movaps xmm11, [rsp]
000074b6341d9c5c  add rsp, 0x30
000074b6341d9c60  vmovaps xmm0, [rsp]
000074b6341d9c65  vmovaps xmm1, [rsp+0x10]
000074b6341d9c6b  vmovaps xmm2, [rsp+0x20]
000074b6341d9c71  vmovaps xmm3, [rsp+0x30]
000074b6341d9c77  vmovaps xmm4, [rsp+0x40]
000074b6341d9c7d  vmovaps xmm5, [rsp+0x50]
000074b6341d9c83  vmovaps xmm6, [rsp+0x60]
000074b6341d9c89  vmovaps xmm7, [rsp+0x70]
000074b6341d9c8f  vmovaps xmm8, [rsp+0x80]
000074b6341d9c98  vmovaps xmm9, [rsp+0x90]
000074b6341d9ca1  vmovaps xmm10, [rsp+0xA0]
000074b6341d9caa  vmovaps xmm12, [rsp+0xB0]
000074b6341d9cb3  vmovaps xmm13, [rsp+0xC0]
000074b6341d9cbc  vmovaps xmm14, [rsp+0xD0]
000074b6341d9cc5  vmovaps xmm15, [rsp+0xE0]
000074b6341d9cce  add rsp, 0xF0
000074b6341d9cd5  pop r11
000074b6341d9cd7  pop r10
000074b6341d9cd9  pop r9
000074b6341d9cdb  pop r8
000074b6341d9cdd  pop rsi
000074b6341d9cde  pop rdi
000074b6341d9cdf  pop rdx
000074b6341d9ce0  pop rcx
000074b6341d9ce1  pop rax
000074b6341d9ce2  add rsp, 0x08
000074b6341d9ce6  jmp 0x000074B6341D636D
000074b6341d9ceb  sub rsp, 0x08
000074b6341d9cef  push rax
000074b6341d9cf0  push rcx
000074b6341d9cf1  push rdx
000074b6341d9cf2  push rdi
000074b6341d9cf3  push rsi
000074b6341d9cf4  push r8
000074b6341d9cf6  push r9
000074b6341d9cf8  push r10
000074b6341d9cfa  push r11
000074b6341d9cfc  sub rsp, 0xF0
000074b6341d9d03  vmovaps [rsp], xmm0
000074b6341d9d08  vmovaps [rsp+0x10], xmm1
000074b6341d9d0e  vmovaps [rsp+0x20], xmm2
000074b6341d9d14  vmovaps [rsp+0x30], xmm3
000074b6341d9d1a  vmovaps [rsp+0x40], xmm4
000074b6341d9d20  vmovaps [rsp+0x50], xmm5
000074b6341d9d26  vmovaps [rsp+0x60], xmm6
000074b6341d9d2c  vmovaps [rsp+0x70], xmm7
000074b6341d9d32  vmovaps [rsp+0x80], xmm8
000074b6341d9d3b  vmovaps [rsp+0x90], xmm9
000074b6341d9d44  vmovaps [rsp+0xA0], xmm11
000074b6341d9d4d  vmovaps [rsp+0xB0], xmm12
000074b6341d9d56  vmovaps [rsp+0xC0], xmm13
000074b6341d9d5f  vmovaps [rsp+0xD0], xmm14
000074b6341d9d68  vmovaps [rsp+0xE0], xmm15
000074b6341d9d71  sub rsp, 0x30
000074b6341d9d75  movaps [rsp], xmm10
000074b6341d9d7a  movaps [rsp+0x10], xmm14
000074b6341d9d80  movaps [rsp+0x20], xmm4
000074b6341d9d85  lea rdi, [rsp]
000074b6341d9d89  mov esi, 0x00
000074b6341d9d8e  mov rax, 0x5E1AA0A2F530
000074b6341d9d98  call rax
000074b6341d9d9a  movaps xmm10, [rsp]
000074b6341d9d9f  add rsp, 0x30
000074b6341d9da3  vmovaps xmm0, [rsp]
000074b6341d9da8  vmovaps xmm1, [rsp+0x10]
000074b6341d9dae  vmovaps xmm2, [rsp+0x20]
000074b6341d9db4  vmovaps xmm3, [rsp+0x30]
000074b6341d9dba  vmovaps xmm4, [rsp+0x40]
000074b6341d9dc0  vmovaps xmm5, [rsp+0x50]
000074b6341d9dc6  vmovaps xmm6, [rsp+0x60]
000074b6341d9dcc  vmovaps xmm7, [rsp+0x70]
000074b6341d9dd2  vmovaps xmm8, [rsp+0x80]
000074b6341d9ddb  vmovaps xmm9, [rsp+0x90]
000074b6341d9de4  vmovaps xmm11, [rsp+0xA0]
000074b6341d9ded  vmovaps xmm12, [rsp+0xB0]
000074b6341d9df6  vmovaps xmm13, [rsp+0xC0]
000074b6341d9dff  vmovaps xmm14, [rsp+0xD0]
000074b6341d9e08  vmovaps xmm15, [rsp+0xE0]
000074b6341d9e11  add rsp, 0xF0
000074b6341d9e18  pop r11
000074b6341d9e1a  pop r10
000074b6341d9e1c  pop r9
000074b6341d9e1e  pop r8
000074b6341d9e20  pop rsi
000074b6341d9e21  pop rdi
000074b6341d9e22  pop rdx
000074b6341d9e23  pop rcx
000074b6341d9e24  pop rax
000074b6341d9e25  add rsp, 0x08
000074b6341d9e29  jmp 0x000074B6341D6388
000074b6341d9e2e  sub rsp, 0x08
000074b6341d9e32  push rax
000074b6341d9e33  push rcx
000074b6341d9e34  push rdx
000074b6341d9e35  push rdi
000074b6341d9e36  push rsi
000074b6341d9e37  push r8
000074b6341d9e39  push r9
000074b6341d9e3b  push r10
000074b6341d9e3d  push r11
000074b6341d9e3f  sub rsp, 0xF0
000074b6341d9e46  vmovaps [rsp], xmm0
000074b6341d9e4b  vmovaps [rsp+0x10], xmm1
000074b6341d9e51  vmovaps [rsp+0x20], xmm2
000074b6341d9e57  vmovaps [rsp+0x30], xmm3
000074b6341d9e5d  vmovaps [rsp+0x40], xmm4
000074b6341d9e63  vmovaps [rsp+0x50], xmm5
000074b6341d9e69  vmovaps [rsp+0x60], xmm6
000074b6341d9e6f  vmovaps [rsp+0x70], xmm7
000074b6341d9e75  vmovaps [rsp+0x80], xmm9
000074b6341d9e7e  vmovaps [rsp+0x90], xmm10
000074b6341d9e87  vmovaps [rsp+0xA0], xmm11
000074b6341d9e90  vmovaps [rsp+0xB0], xmm12
000074b6341d9e99  vmovaps [rsp+0xC0], xmm13
000074b6341d9ea2  vmovaps [rsp+0xD0], xmm14
000074b6341d9eab  vmovaps [rsp+0xE0], xmm15
000074b6341d9eb4  sub rsp, 0x30
000074b6341d9eb8  movaps [rsp], xmm8
000074b6341d9ebd  movaps [rsp+0x10], xmm1
000074b6341d9ec2  movaps [rsp+0x20], xmm14
000074b6341d9ec8  lea rdi, [rsp]
000074b6341d9ecc  mov esi, 0x00
000074b6341d9ed1  mov rax, 0x5E1AA0A2F530
000074b6341d9edb  call rax
000074b6341d9edd  movaps xmm8, [rsp]
000074b6341d9ee2  add rsp, 0x30
000074b6341d9ee6  vmovaps xmm0, [rsp]
000074b6341d9eeb  vmovaps xmm1, [rsp+0x10]
000074b6341d9ef1  vmovaps xmm2, [rsp+0x20]
000074b6341d9ef7  vmovaps xmm3, [rsp+0x30]
000074b6341d9efd  vmovaps xmm4, [rsp+0x40]
000074b6341d9f03  vmovaps xmm5, [rsp+0x50]
000074b6341d9f09  vmovaps xmm6, [rsp+0x60]
000074b6341d9f0f  vmovaps xmm7, [rsp+0x70]
000074b6341d9f15  vmovaps xmm9, [rsp+0x80]
000074b6341d9f1e  vmovaps xmm10, [rsp+0x90]
000074b6341d9f27  vmovaps xmm11, [rsp+0xA0]
000074b6341d9f30  vmovaps xmm12, [rsp+0xB0]
000074b6341d9f39  vmovaps xmm13, [rsp+0xC0]
000074b6341d9f42  vmovaps xmm14, [rsp+0xD0]
000074b6341d9f4b  vmovaps xmm15, [rsp+0xE0]
000074b6341d9f54  add rsp, 0xF0
000074b6341d9f5b  pop r11
000074b6341d9f5d  pop r10
000074b6341d9f5f  pop r9
000074b6341d9f61  pop r8
000074b6341d9f63  pop rsi
000074b6341d9f64  pop rdi
000074b6341d9f65  pop rdx
000074b6341d9f66  pop rcx
000074b6341d9f67  pop rax
000074b6341d9f68  add rsp, 0x08
000074b6341d9f6c  jmp 0x000074B6341D63AE
000074b6341d9f71  sub rsp, 0x08
000074b6341d9f75  push rax
000074b6341d9f76  push rcx
000074b6341d9f77  push rdx
000074b6341d9f78  push rdi
000074b6341d9f79  push rsi
000074b6341d9f7a  push r8
000074b6341d9f7c  push r9
000074b6341d9f7e  push r10
000074b6341d9f80  push r11
000074b6341d9f82  sub rsp, 0xF0
000074b6341d9f89  vmovaps [rsp], xmm0
000074b6341d9f8e  vmovaps [rsp+0x10], xmm1
000074b6341d9f94  vmovaps [rsp+0x20], xmm2
000074b6341d9f9a  vmovaps [rsp+0x30], xmm3
000074b6341d9fa0  vmovaps [rsp+0x40], xmm4
000074b6341d9fa6  vmovaps [rsp+0x50], xmm5
000074b6341d9fac  vmovaps [rsp+0x60], xmm7
000074b6341d9fb2  vmovaps [rsp+0x70], xmm8
000074b6341d9fb8  vmovaps [rsp+0x80], xmm9
000074b6341d9fc1  vmovaps [rsp+0x90], xmm10
000074b6341d9fca  vmovaps [rsp+0xA0], xmm11
000074b6341d9fd3  vmovaps [rsp+0xB0], xmm12
000074b6341d9fdc  vmovaps [rsp+0xC0], xmm13
000074b6341d9fe5  vmovaps [rsp+0xD0], xmm14
000074b6341d9fee  vmovaps [rsp+0xE0], xmm15
000074b6341d9ff7  sub rsp, 0x30
000074b6341d9ffb  movaps [rsp], xmm6
000074b6341d9fff  movaps [rsp+0x10], xmm1
000074b6341da004  movaps [rsp+0x20], xmm14
000074b6341da00a  lea rdi, [rsp]
000074b6341da00e  mov esi, 0x00
000074b6341da013  mov rax, 0x5E1AA0A2F530
000074b6341da01d  call rax
000074b6341da01f  movaps xmm6, [rsp]
000074b6341da023  add rsp, 0x30
000074b6341da027  vmovaps xmm0, [rsp]
000074b6341da02c  vmovaps xmm1, [rsp+0x10]
000074b6341da032  vmovaps xmm2, [rsp+0x20]
000074b6341da038  vmovaps xmm3, [rsp+0x30]
000074b6341da03e  vmovaps xmm4, [rsp+0x40]
000074b6341da044  vmovaps xmm5, [rsp+0x50]
000074b6341da04a  vmovaps xmm7, [rsp+0x60]
000074b6341da050  vmovaps xmm8, [rsp+0x70]
000074b6341da056  vmovaps xmm9, [rsp+0x80]
000074b6341da05f  vmovaps xmm10, [rsp+0x90]
000074b6341da068  vmovaps xmm11, [rsp+0xA0]
000074b6341da071  vmovaps xmm12, [rsp+0xB0]
000074b6341da07a  vmovaps xmm13, [rsp+0xC0]
000074b6341da083  vmovaps xmm14, [rsp+0xD0]
000074b6341da08c  vmovaps xmm15, [rsp+0xE0]
000074b6341da095  add rsp, 0xF0
000074b6341da09c  pop r11
000074b6341da09e  pop r10
000074b6341da0a0  pop r9
000074b6341da0a2  pop r8
000074b6341da0a4  pop rsi
000074b6341da0a5  pop rdi
000074b6341da0a6  pop rdx
000074b6341da0a7  pop rcx
000074b6341da0a8  pop rax
000074b6341da0a9  add rsp, 0x08
000074b6341da0ad  jmp 0x000074B6341D63DA
000074b6341da0b2  sub rsp, 0x08
000074b6341da0b6  push rax
000074b6341da0b7  push rcx
000074b6341da0b8  push rdx
000074b6341da0b9  push rdi
000074b6341da0ba  push rsi
000074b6341da0bb  push r8
000074b6341da0bd  push r9
000074b6341da0bf  push r10
000074b6341da0c1  push r11
000074b6341da0c3  sub rsp, 0xF0
000074b6341da0ca  vmovaps [rsp], xmm0
000074b6341da0cf  vmovaps [rsp+0x10], xmm1
000074b6341da0d5  vmovaps [rsp+0x20], xmm2
000074b6341da0db  vmovaps [rsp+0x30], xmm3
000074b6341da0e1  vmovaps [rsp+0x40], xmm4
000074b6341da0e7  vmovaps [rsp+0x50], xmm5
000074b6341da0ed  vmovaps [rsp+0x60], xmm6
000074b6341da0f3  vmovaps [rsp+0x70], xmm7
000074b6341da0f9  vmovaps [rsp+0x80], xmm8
000074b6341da102  vmovaps [rsp+0x90], xmm9
000074b6341da10b  vmovaps [rsp+0xA0], xmm10
000074b6341da114  vmovaps [rsp+0xB0], xmm11
000074b6341da11d  vmovaps [rsp+0xC0], xmm12
000074b6341da126  vmovaps [rsp+0xD0], xmm13
000074b6341da12f  vmovaps [rsp+0xE0], xmm15
000074b6341da138  sub rsp, 0x30
000074b6341da13c  movaps [rsp], xmm14
000074b6341da141  movaps [rsp+0x10], xmm12
000074b6341da147  movaps [rsp+0x20], xmm1
000074b6341da14c  lea rdi, [rsp]
000074b6341da150  mov esi, 0x00
000074b6341da155  mov rax, 0x5E1AA0A2F530
000074b6341da15f  call rax
000074b6341da161  movaps xmm14, [rsp]
000074b6341da166  add rsp, 0x30
000074b6341da16a  vmovaps xmm0, [rsp]
000074b6341da16f  vmovaps xmm1, [rsp+0x10]
000074b6341da175  vmovaps xmm2, [rsp+0x20]
000074b6341da17b  vmovaps xmm3, [rsp+0x30]
000074b6341da181  vmovaps xmm4, [rsp+0x40]
000074b6341da187  vmovaps xmm5, [rsp+0x50]
000074b6341da18d  vmovaps xmm6, [rsp+0x60]
000074b6341da193  vmovaps xmm7, [rsp+0x70]
000074b6341da199  vmovaps xmm8, [rsp+0x80]
000074b6341da1a2  vmovaps xmm9, [rsp+0x90]
000074b6341da1ab  vmovaps xmm10, [rsp+0xA0]
000074b6341da1b4  vmovaps xmm11, [rsp+0xB0]
000074b6341da1bd  vmovaps xmm12, [rsp+0xC0]
000074b6341da1c6  vmovaps xmm13, [rsp+0xD0]
000074b6341da1cf  vmovaps xmm15, [rsp+0xE0]
000074b6341da1d8  add rsp, 0xF0
000074b6341da1df  pop r11
000074b6341da1e1  pop r10
000074b6341da1e3  pop r9
000074b6341da1e5  pop r8
000074b6341da1e7  pop rsi
000074b6341da1e8  pop rdi
000074b6341da1e9  pop rdx
000074b6341da1ea  pop rcx
000074b6341da1eb  pop rax
000074b6341da1ec  add rsp, 0x08
000074b6341da1f0  jmp 0x000074B6341D6400
000074b6341da1f5  sub rsp, 0x08
000074b6341da1f9  push rax
000074b6341da1fa  push rcx
000074b6341da1fb  push rdx
000074b6341da1fc  push rdi
000074b6341da1fd  push rsi
000074b6341da1fe  push r8
000074b6341da200  push r9
000074b6341da202  push r10
000074b6341da204  push r11
000074b6341da206  sub rsp, 0xF0
000074b6341da20d  vmovaps [rsp], xmm0
000074b6341da212  vmovaps [rsp+0x10], xmm2
000074b6341da218  vmovaps [rsp+0x20], xmm3
000074b6341da21e  vmovaps [rsp+0x30], xmm4
000074b6341da224  vmovaps [rsp+0x40], xmm5
000074b6341da22a  vmovaps [rsp+0x50], xmm6
000074b6341da230  vmovaps [rsp+0x60], xmm7
000074b6341da236  vmovaps [rsp+0x70], xmm8
000074b6341da23c  vmovaps [rsp+0x80], xmm9
000074b6341da245  vmovaps [rsp+0x90], xmm10
000074b6341da24e  vmovaps [rsp+0xA0], xmm11
000074b6341da257  vmovaps [rsp+0xB0], xmm12
000074b6341da260  vmovaps [rsp+0xC0], xmm13
000074b6341da269  vmovaps [rsp+0xD0], xmm14
000074b6341da272  vmovaps [rsp+0xE0], xmm15
000074b6341da27b  sub rsp, 0x30
000074b6341da27f  movaps [rsp], xmm1
000074b6341da283  movaps [rsp+0x10], xmm13
000074b6341da289  movaps [rsp+0x20], xmm9
000074b6341da28f  lea rdi, [rsp]
000074b6341da293  mov esi, 0x00
000074b6341da298  mov rax, 0x5E1AA0A2F530
000074b6341da2a2  call rax
000074b6341da2a4  movaps xmm1, [rsp]
000074b6341da2a8  add rsp, 0x30
000074b6341da2ac  vmovaps xmm0, [rsp]
000074b6341da2b1  vmovaps xmm2, [rsp+0x10]
000074b6341da2b7  vmovaps xmm3, [rsp+0x20]
000074b6341da2bd  vmovaps xmm4, [rsp+0x30]
000074b6341da2c3  vmovaps xmm5, [rsp+0x40]
000074b6341da2c9  vmovaps xmm6, [rsp+0x50]
000074b6341da2cf  vmovaps xmm7, [rsp+0x60]
000074b6341da2d5  vmovaps xmm8, [rsp+0x70]
000074b6341da2db  vmovaps xmm9, [rsp+0x80]
000074b6341da2e4  vmovaps xmm10, [rsp+0x90]
000074b6341da2ed  vmovaps xmm11, [rsp+0xA0]
000074b6341da2f6  vmovaps xmm12, [rsp+0xB0]
000074b6341da2ff  vmovaps xmm13, [rsp+0xC0]
000074b6341da308  vmovaps xmm14, [rsp+0xD0]
000074b6341da311  vmovaps xmm15, [rsp+0xE0]
000074b6341da31a  add rsp, 0xF0
000074b6341da321  pop r11
000074b6341da323  pop r10
000074b6341da325  pop r9
000074b6341da327  pop r8
000074b6341da329  pop rsi
000074b6341da32a  pop rdi
000074b6341da32b  pop rdx
000074b6341da32c  pop rcx
000074b6341da32d  pop rax
000074b6341da32e  add rsp, 0x08
000074b6341da332  jmp 0x000074B6341D641A
000074b6341da337  sub rsp, 0x08
000074b6341da33b  push rax
000074b6341da33c  push rcx
000074b6341da33d  push rdx
000074b6341da33e  push rdi
000074b6341da33f  push rsi
000074b6341da340  push r8
000074b6341da342  push r9
000074b6341da344  push r10
000074b6341da346  push r11
000074b6341da348  sub rsp, 0xF0
000074b6341da34f  vmovaps [rsp], xmm0
000074b6341da354  vmovaps [rsp+0x10], xmm1
000074b6341da35a  vmovaps [rsp+0x20], xmm2
000074b6341da360  vmovaps [rsp+0x30], xmm3
000074b6341da366  vmovaps [rsp+0x40], xmm4
000074b6341da36c  vmovaps [rsp+0x50], xmm5
000074b6341da372  vmovaps [rsp+0x60], xmm6
000074b6341da378  vmovaps [rsp+0x70], xmm7
000074b6341da37e  vmovaps [rsp+0x80], xmm8
000074b6341da387  vmovaps [rsp+0x90], xmm9
000074b6341da390  vmovaps [rsp+0xA0], xmm10
000074b6341da399  vmovaps [rsp+0xB0], xmm11
000074b6341da3a2  vmovaps [rsp+0xC0], xmm13
000074b6341da3ab  vmovaps [rsp+0xD0], xmm14
000074b6341da3b4  vmovaps [rsp+0xE0], xmm15
000074b6341da3bd  sub rsp, 0x30
000074b6341da3c1  movaps [rsp], xmm12
000074b6341da3c6  movaps [rsp+0x10], xmm7
000074b6341da3cb  movaps [rsp+0x20], xmm13
000074b6341da3d1  lea rdi, [rsp]
000074b6341da3d5  mov esi, 0x00
000074b6341da3da  mov rax, 0x5E1AA0A2F530
000074b6341da3e4  call rax
000074b6341da3e6  movaps xmm12, [rsp]
000074b6341da3eb  add rsp, 0x30
000074b6341da3ef  vmovaps xmm0, [rsp]
000074b6341da3f4  vmovaps xmm1, [rsp+0x10]
000074b6341da3fa  vmovaps xmm2, [rsp+0x20]
000074b6341da400  vmovaps xmm3, [rsp+0x30]
000074b6341da406  vmovaps xmm4, [rsp+0x40]
000074b6341da40c  vmovaps xmm5, [rsp+0x50]
000074b6341da412  vmovaps xmm6, [rsp+0x60]
000074b6341da418  vmovaps xmm7, [rsp+0x70]
000074b6341da41e  vmovaps xmm8, [rsp+0x80]
000074b6341da427  vmovaps xmm9, [rsp+0x90]
000074b6341da430  vmovaps xmm10, [rsp+0xA0]
000074b6341da439  vmovaps xmm11, [rsp+0xB0]
000074b6341da442  vmovaps xmm13, [rsp+0xC0]
000074b6341da44b  vmovaps xmm14, [rsp+0xD0]
000074b6341da454  vmovaps xmm15, [rsp+0xE0]
000074b6341da45d  add rsp, 0xF0
000074b6341da464  pop r11
000074b6341da466  pop r10
000074b6341da468  pop r9
000074b6341da46a  pop r8
000074b6341da46c  pop rsi
000074b6341da46d  pop rdi
000074b6341da46e  pop rdx
000074b6341da46f  pop rcx
000074b6341da470  pop rax
000074b6341da471  add rsp, 0x08
000074b6341da475  jmp 0x000074B6341D6441
000074b6341da47a  sub rsp, 0x08
000074b6341da47e  push rax
000074b6341da47f  push rcx
000074b6341da480  push rdx
000074b6341da481  push rdi
000074b6341da482  push rsi
000074b6341da483  push r8
000074b6341da485  push r9
000074b6341da487  push r10
000074b6341da489  push r11
000074b6341da48b  sub rsp, 0xF0
000074b6341da492  vmovaps [rsp], xmm0
000074b6341da497  vmovaps [rsp+0x10], xmm1
000074b6341da49d  vmovaps [rsp+0x20], xmm2
000074b6341da4a3  vmovaps [rsp+0x30], xmm3
000074b6341da4a9  vmovaps [rsp+0x40], xmm4
000074b6341da4af  vmovaps [rsp+0x50], xmm5
000074b6341da4b5  vmovaps [rsp+0x60], xmm6
000074b6341da4bb  vmovaps [rsp+0x70], xmm7
000074b6341da4c1  vmovaps [rsp+0x80], xmm8
000074b6341da4ca  vmovaps [rsp+0x90], xmm9
000074b6341da4d3  vmovaps [rsp+0xA0], xmm10
000074b6341da4dc  vmovaps [rsp+0xB0], xmm11
000074b6341da4e5  vmovaps [rsp+0xC0], xmm12
000074b6341da4ee  vmovaps [rsp+0xD0], xmm14
000074b6341da4f7  vmovaps [rsp+0xE0], xmm15
000074b6341da500  sub rsp, 0x30
000074b6341da504  movaps [rsp], xmm13
000074b6341da509  movaps [rsp+0x10], xmm15
000074b6341da50f  movaps [rsp+0x20], xmm8
000074b6341da515  lea rdi, [rsp]
000074b6341da519  mov esi, 0x00
000074b6341da51e  mov rax, 0x5E1AA0A2F530
000074b6341da528  call rax
000074b6341da52a  movaps xmm13, [rsp]
000074b6341da52f  add rsp, 0x30
000074b6341da533  vmovaps xmm0, [rsp]
000074b6341da538  vmovaps xmm1, [rsp+0x10]
000074b6341da53e  vmovaps xmm2, [rsp+0x20]
000074b6341da544  vmovaps xmm3, [rsp+0x30]
000074b6341da54a  vmovaps xmm4, [rsp+0x40]
000074b6341da550  vmovaps xmm5, [rsp+0x50]
000074b6341da556  vmovaps xmm6, [rsp+0x60]
000074b6341da55c  vmovaps xmm7, [rsp+0x70]
000074b6341da562  vmovaps xmm8, [rsp+0x80]
000074b6341da56b  vmovaps xmm9, [rsp+0x90]
000074b6341da574  vmovaps xmm10, [rsp+0xA0]
000074b6341da57d  vmovaps xmm11, [rsp+0xB0]
000074b6341da586  vmovaps xmm12, [rsp+0xC0]
000074b6341da58f  vmovaps xmm14, [rsp+0xD0]
000074b6341da598  vmovaps xmm15, [rsp+0xE0]
000074b6341da5a1  add rsp, 0xF0
000074b6341da5a8  pop r11
000074b6341da5aa  pop r10
000074b6341da5ac  pop r9
000074b6341da5ae  pop r8
000074b6341da5b0  pop rsi
000074b6341da5b1  pop rdi
000074b6341da5b2  pop rdx
000074b6341da5b3  pop rcx
000074b6341da5b4  pop rax
000074b6341da5b5  add rsp, 0x08
000074b6341da5b9  jmp 0x000074B6341D645C
000074b6341da5be  sub rsp, 0x08
000074b6341da5c2  push rax
000074b6341da5c3  push rcx
000074b6341da5c4  push rdx
000074b6341da5c5  push rdi
000074b6341da5c6  push rsi
000074b6341da5c7  push r8
000074b6341da5c9  push r9
000074b6341da5cb  push r10
000074b6341da5cd  push r11
000074b6341da5cf  sub rsp, 0xF0
000074b6341da5d6  vmovaps [rsp], xmm0
000074b6341da5db  vmovaps [rsp+0x10], xmm1
000074b6341da5e1  vmovaps [rsp+0x20], xmm2
000074b6341da5e7  vmovaps [rsp+0x30], xmm3
000074b6341da5ed  vmovaps [rsp+0x40], xmm4
000074b6341da5f3  vmovaps [rsp+0x50], xmm5
000074b6341da5f9  vmovaps [rsp+0x60], xmm6
000074b6341da5ff  vmovaps [rsp+0x70], xmm7
000074b6341da605  vmovaps [rsp+0x80], xmm9
000074b6341da60e  vmovaps [rsp+0x90], xmm10
000074b6341da617  vmovaps [rsp+0xA0], xmm11
000074b6341da620  vmovaps [rsp+0xB0], xmm12
000074b6341da629  vmovaps [rsp+0xC0], xmm13
000074b6341da632  vmovaps [rsp+0xD0], xmm14
000074b6341da63b  vmovaps [rsp+0xE0], xmm15
000074b6341da644  sub rsp, 0x30
000074b6341da648  movaps [rsp], xmm8
000074b6341da64d  movaps [rsp+0x10], xmm15
000074b6341da653  movaps [rsp+0x20], xmm9
000074b6341da659  lea rdi, [rsp]
000074b6341da65d  mov esi, 0x00
000074b6341da662  mov rax, 0x5E1AA0A2F530
000074b6341da66c  call rax
000074b6341da66e  movaps xmm8, [rsp]
000074b6341da673  add rsp, 0x30
000074b6341da677  vmovaps xmm0, [rsp]
000074b6341da67c  vmovaps xmm1, [rsp+0x10]
000074b6341da682  vmovaps xmm2, [rsp+0x20]
000074b6341da688  vmovaps xmm3, [rsp+0x30]
000074b6341da68e  vmovaps xmm4, [rsp+0x40]
000074b6341da694  vmovaps xmm5, [rsp+0x50]
000074b6341da69a  vmovaps xmm6, [rsp+0x60]
000074b6341da6a0  vmovaps xmm7, [rsp+0x70]
000074b6341da6a6  vmovaps xmm9, [rsp+0x80]
000074b6341da6af  vmovaps xmm10, [rsp+0x90]
000074b6341da6b8  vmovaps xmm11, [rsp+0xA0]
000074b6341da6c1  vmovaps xmm12, [rsp+0xB0]
000074b6341da6ca  vmovaps xmm13, [rsp+0xC0]
000074b6341da6d3  vmovaps xmm14, [rsp+0xD0]
000074b6341da6dc  vmovaps xmm15, [rsp+0xE0]
000074b6341da6e5  add rsp, 0xF0
000074b6341da6ec  pop r11
000074b6341da6ee  pop r10
000074b6341da6f0  pop r9
000074b6341da6f2  pop r8
000074b6341da6f4  pop rsi
000074b6341da6f5  pop rdi
000074b6341da6f6  pop rdx
000074b6341da6f7  pop rcx
000074b6341da6f8  pop rax
000074b6341da6f9  add rsp, 0x08
000074b6341da6fd  jmp 0x000074B6341D648A
000074b6341da702  sub rsp, 0x08
000074b6341da706  push rax
000074b6341da707  push rcx
000074b6341da708  push rdx
000074b6341da709  push rdi
000074b6341da70a  push rsi
000074b6341da70b  push r8
000074b6341da70d  push r9
000074b6341da70f  push r10
000074b6341da711  push r11
000074b6341da713  sub rsp, 0xF0
000074b6341da71a  vmovaps [rsp], xmm0
000074b6341da71f  vmovaps [rsp+0x10], xmm1
000074b6341da725  vmovaps [rsp+0x20], xmm2
000074b6341da72b  vmovaps [rsp+0x30], xmm3
000074b6341da731  vmovaps [rsp+0x40], xmm4
000074b6341da737  vmovaps [rsp+0x50], xmm5
000074b6341da73d  vmovaps [rsp+0x60], xmm6
000074b6341da743  vmovaps [rsp+0x70], xmm7
000074b6341da749  vmovaps [rsp+0x80], xmm8
000074b6341da752  vmovaps [rsp+0x90], xmm9
000074b6341da75b  vmovaps [rsp+0xA0], xmm10
000074b6341da764  vmovaps [rsp+0xB0], xmm11
000074b6341da76d  vmovaps [rsp+0xC0], xmm12
000074b6341da776  vmovaps [rsp+0xD0], xmm13
000074b6341da77f  vmovaps [rsp+0xE0], xmm14
000074b6341da788  sub rsp, 0x30
000074b6341da78c  movaps [rsp], xmm15
000074b6341da791  movaps [rsp+0x10], xmm11
000074b6341da797  movaps [rsp+0x20], xmm6
000074b6341da79c  lea rdi, [rsp]
000074b6341da7a0  mov esi, 0x00
000074b6341da7a5  mov rax, 0x5E1AA0A2F530
000074b6341da7af  call rax
000074b6341da7b1  movaps xmm15, [rsp]
000074b6341da7b6  add rsp, 0x30
000074b6341da7ba  vmovaps xmm0, [rsp]
000074b6341da7bf  vmovaps xmm1, [rsp+0x10]
000074b6341da7c5  vmovaps xmm2, [rsp+0x20]
000074b6341da7cb  vmovaps xmm3, [rsp+0x30]
000074b6341da7d1  vmovaps xmm4, [rsp+0x40]
000074b6341da7d7  vmovaps xmm5, [rsp+0x50]
000074b6341da7dd  vmovaps xmm6, [rsp+0x60]
000074b6341da7e3  vmovaps xmm7, [rsp+0x70]
000074b6341da7e9  vmovaps xmm8, [rsp+0x80]
000074b6341da7f2  vmovaps xmm9, [rsp+0x90]
000074b6341da7fb  vmovaps xmm10, [rsp+0xA0]
000074b6341da804  vmovaps xmm11, [rsp+0xB0]
000074b6341da80d  vmovaps xmm12, [rsp+0xC0]
000074b6341da816  vmovaps xmm13, [rsp+0xD0]
000074b6341da81f  vmovaps xmm14, [rsp+0xE0]
000074b6341da828  add rsp, 0xF0
000074b6341da82f  pop r11
000074b6341da831  pop r10
000074b6341da833  pop r9
000074b6341da835  pop r8
000074b6341da837  pop rsi
000074b6341da838  pop rdi
000074b6341da839  pop rdx
000074b6341da83a  pop rcx
000074b6341da83b  pop rax
000074b6341da83c  add rsp, 0x08
000074b6341da840  jmp 0x000074B6341D64A5
000074b6341da845  sub rsp, 0x08
000074b6341da849  push rax
000074b6341da84a  push rcx
000074b6341da84b  push rdx
000074b6341da84c  push rdi
000074b6341da84d  push rsi
000074b6341da84e  push r8
000074b6341da850  push r9
000074b6341da852  push r10
000074b6341da854  push r11
000074b6341da856  sub rsp, 0xF0
000074b6341da85d  vmovaps [rsp], xmm0
000074b6341da862  vmovaps [rsp+0x10], xmm1
000074b6341da868  vmovaps [rsp+0x20], xmm2
000074b6341da86e  vmovaps [rsp+0x30], xmm3
000074b6341da874  vmovaps [rsp+0x40], xmm4
000074b6341da87a  vmovaps [rsp+0x50], xmm5
000074b6341da880  vmovaps [rsp+0x60], xmm6
000074b6341da886  vmovaps [rsp+0x70], xmm8
000074b6341da88c  vmovaps [rsp+0x80], xmm9
000074b6341da895  vmovaps [rsp+0x90], xmm10
000074b6341da89e  vmovaps [rsp+0xA0], xmm11
000074b6341da8a7  vmovaps [rsp+0xB0], xmm12
000074b6341da8b0  vmovaps [rsp+0xC0], xmm13
000074b6341da8b9  vmovaps [rsp+0xD0], xmm14
000074b6341da8c2  vmovaps [rsp+0xE0], xmm15
000074b6341da8cb  sub rsp, 0x30
000074b6341da8cf  movaps [rsp], xmm7
000074b6341da8d3  movaps [rsp+0x10], xmm11
000074b6341da8d9  movaps [rsp+0x20], xmm9
000074b6341da8df  lea rdi, [rsp]
000074b6341da8e3  mov esi, 0x00
000074b6341da8e8  mov rax, 0x5E1AA0A2F530
000074b6341da8f2  call rax
000074b6341da8f4  movaps xmm7, [rsp]
000074b6341da8f8  add rsp, 0x30
000074b6341da8fc  vmovaps xmm0, [rsp]
000074b6341da901  vmovaps xmm1, [rsp+0x10]
000074b6341da907  vmovaps xmm2, [rsp+0x20]
000074b6341da90d  vmovaps xmm3, [rsp+0x30]
000074b6341da913  vmovaps xmm4, [rsp+0x40]
000074b6341da919  vmovaps xmm5, [rsp+0x50]
000074b6341da91f  vmovaps xmm6, [rsp+0x60]
000074b6341da925  vmovaps xmm8, [rsp+0x70]
000074b6341da92b  vmovaps xmm9, [rsp+0x80]
000074b6341da934  vmovaps xmm10, [rsp+0x90]
000074b6341da93d  vmovaps xmm11, [rsp+0xA0]
000074b6341da946  vmovaps xmm12, [rsp+0xB0]
000074b6341da94f  vmovaps xmm13, [rsp+0xC0]
000074b6341da958  vmovaps xmm14, [rsp+0xD0]
000074b6341da961  vmovaps xmm15, [rsp+0xE0]
000074b6341da96a  add rsp, 0xF0
000074b6341da971  pop r11
000074b6341da973  pop r10
000074b6341da975  pop r9
000074b6341da977  pop r8
000074b6341da979  pop rsi
000074b6341da97a  pop rdi
000074b6341da97b  pop rdx
000074b6341da97c  pop rcx
000074b6341da97d  pop rax
000074b6341da97e  add rsp, 0x08
000074b6341da982  jmp 0x000074B6341D64D2
000074b6341da987  sub rsp, 0x08
000074b6341da98b  push rax
000074b6341da98c  push rcx
000074b6341da98d  push rdx
000074b6341da98e  push rdi
000074b6341da98f  push rsi
000074b6341da990  push r8
000074b6341da992  push r9
000074b6341da994  push r10
000074b6341da996  push r11
000074b6341da998  sub rsp, 0xF0
000074b6341da99f  vmovaps [rsp], xmm0
000074b6341da9a4  vmovaps [rsp+0x10], xmm1
000074b6341da9aa  vmovaps [rsp+0x20], xmm2
000074b6341da9b0  vmovaps [rsp+0x30], xmm3
000074b6341da9b6  vmovaps [rsp+0x40], xmm4
000074b6341da9bc  vmovaps [rsp+0x50], xmm5
000074b6341da9c2  vmovaps [rsp+0x60], xmm6
000074b6341da9c8  vmovaps [rsp+0x70], xmm7
000074b6341da9ce  vmovaps [rsp+0x80], xmm8
000074b6341da9d7  vmovaps [rsp+0x90], xmm9
000074b6341da9e0  vmovaps [rsp+0xA0], xmm10
000074b6341da9e9  vmovaps [rsp+0xB0], xmm12
000074b6341da9f2  vmovaps [rsp+0xC0], xmm13
000074b6341da9fb  vmovaps [rsp+0xD0], xmm14
000074b6341daa04  vmovaps [rsp+0xE0], xmm15
000074b6341daa0d  sub rsp, 0x30
000074b6341daa11  movaps [rsp], xmm11
000074b6341daa16  movaps [rsp+0x10], xmm10
000074b6341daa1c  movaps [rsp+0x20], xmm14
000074b6341daa22  lea rdi, [rsp]
000074b6341daa26  mov esi, 0x00
000074b6341daa2b  mov rax, 0x5E1AA0A2F530
000074b6341daa35  call rax
000074b6341daa37  movaps xmm11, [rsp]
000074b6341daa3c  add rsp, 0x30
000074b6341daa40  vmovaps xmm0, [rsp]
000074b6341daa45  vmovaps xmm1, [rsp+0x10]
000074b6341daa4b  vmovaps xmm2, [rsp+0x20]
000074b6341daa51  vmovaps xmm3, [rsp+0x30]
000074b6341daa57  vmovaps xmm4, [rsp+0x40]
000074b6341daa5d  vmovaps xmm5, [rsp+0x50]
000074b6341daa63  vmovaps xmm6, [rsp+0x60]
000074b6341daa69  vmovaps xmm7, [rsp+0x70]
000074b6341daa6f  vmovaps xmm8, [rsp+0x80]
000074b6341daa78  vmovaps xmm9, [rsp+0x90]
000074b6341daa81  vmovaps xmm10, [rsp+0xA0]
000074b6341daa8a  vmovaps xmm12, [rsp+0xB0]
000074b6341daa93  vmovaps xmm13, [rsp+0xC0]
000074b6341daa9c  vmovaps xmm14, [rsp+0xD0]
000074b6341daaa5  vmovaps xmm15, [rsp+0xE0]
000074b6341daaae  add rsp, 0xF0
000074b6341daab5  pop r11
000074b6341daab7  pop r10
000074b6341daab9  pop r9
000074b6341daabb  pop r8
000074b6341daabd  pop rsi
000074b6341daabe  pop rdi
000074b6341daabf  pop rdx
000074b6341daac0  pop rcx
000074b6341daac1  pop rax
000074b6341daac2  add rsp, 0x08
000074b6341daac6  jmp 0x000074B6341D64ED
000074b6341daacb  call 0x000074B6340E45A0
000074b6341daad0  jmp 0x000074B6341D64F7
000074b6341daad5  sub rsp, 0x08
000074b6341daad9  push rax
000074b6341daada  push rcx
000074b6341daadb  push rdx
000074b6341daadc  push rdi
000074b6341daadd  push rsi
000074b6341daade  push r8
000074b6341daae0  push r9
000074b6341daae2  push r10
000074b6341daae4  push r11
000074b6341daae6  sub rsp, 0xF0
000074b6341daaed  vmovaps [rsp], xmm0
000074b6341daaf2  vmovaps [rsp+0x10], xmm1
000074b6341daaf8  vmovaps [rsp+0x20], xmm2
000074b6341daafe  vmovaps [rsp+0x30], xmm3
000074b6341dab04  vmovaps [rsp+0x40], xmm4
000074b6341dab0a  vmovaps [rsp+0x50], xmm5
000074b6341dab10  vmovaps [rsp+0x60], xmm6
000074b6341dab16  vmovaps [rsp+0x70], xmm7
000074b6341dab1c  vmovaps [rsp+0x80], xmm8
000074b6341dab25  vmovaps [rsp+0x90], xmm9
000074b6341dab2e  vmovaps [rsp+0xA0], xmm11
000074b6341dab37  vmovaps [rsp+0xB0], xmm12
000074b6341dab40  vmovaps [rsp+0xC0], xmm13
000074b6341dab49  vmovaps [rsp+0xD0], xmm14
000074b6341dab52  vmovaps [rsp+0xE0], xmm15
000074b6341dab5b  sub rsp, 0x30
000074b6341dab5f  movaps [rsp], xmm10
000074b6341dab64  movaps [rsp+0x10], xmm1
000074b6341dab69  movaps [rsp+0x20], xmm12
000074b6341dab6f  lea rdi, [rsp]
000074b6341dab73  mov esi, 0x00
000074b6341dab78  mov rax, 0x5E1AA0A2F530
000074b6341dab82  call rax
000074b6341dab84  movaps xmm10, [rsp]
000074b6341dab89  add rsp, 0x30
000074b6341dab8d  vmovaps xmm0, [rsp]
000074b6341dab92  vmovaps xmm1, [rsp+0x10]
000074b6341dab98  vmovaps xmm2, [rsp+0x20]
000074b6341dab9e  vmovaps xmm3, [rsp+0x30]
000074b6341daba4  vmovaps xmm4, [rsp+0x40]
000074b6341dabaa  vmovaps xmm5, [rsp+0x50]
000074b6341dabb0  vmovaps xmm6, [rsp+0x60]
000074b6341dabb6  vmovaps xmm7, [rsp+0x70]
000074b6341dabbc  vmovaps xmm8, [rsp+0x80]
000074b6341dabc5  vmovaps xmm9, [rsp+0x90]
000074b6341dabce  vmovaps xmm11, [rsp+0xA0]
000074b6341dabd7  vmovaps xmm12, [rsp+0xB0]
000074b6341dabe0  vmovaps xmm13, [rsp+0xC0]
000074b6341dabe9  vmovaps xmm14, [rsp+0xD0]
000074b6341dabf2  vmovaps xmm15, [rsp+0xE0]
000074b6341dabfb  add rsp, 0xF0
000074b6341dac02  pop r11
000074b6341dac04  pop r10
000074b6341dac06  pop r9
000074b6341dac08  pop r8
000074b6341dac0a  pop rsi
000074b6341dac0b  pop rdi
000074b6341dac0c  pop rdx
000074b6341dac0d  pop rcx
000074b6341dac0e  pop rax
000074b6341dac0f  add rsp, 0x08
000074b6341dac13  jmp 0x000074B6341D651A
000074b6341dac18  sub rsp, 0x08
000074b6341dac1c  push rax
000074b6341dac1d  push rcx
000074b6341dac1e  push rdx
000074b6341dac1f  push rdi
000074b6341dac20  push rsi
000074b6341dac21  push r8
000074b6341dac23  push r9
000074b6341dac25  push r10
000074b6341dac27  push r11
000074b6341dac29  sub rsp, 0xF0
000074b6341dac30  vmovaps [rsp], xmm0
000074b6341dac35  vmovaps [rsp+0x10], xmm1
000074b6341dac3b  vmovaps [rsp+0x20], xmm2
000074b6341dac41  vmovaps [rsp+0x30], xmm3
000074b6341dac47  vmovaps [rsp+0x40], xmm4
000074b6341dac4d  vmovaps [rsp+0x50], xmm5
000074b6341dac53  vmovaps [rsp+0x60], xmm6
000074b6341dac59  vmovaps [rsp+0x70], xmm7
000074b6341dac5f  vmovaps [rsp+0x80], xmm8
000074b6341dac68  vmovaps [rsp+0x90], xmm9
000074b6341dac71  vmovaps [rsp+0xA0], xmm10
000074b6341dac7a  vmovaps [rsp+0xB0], xmm11
000074b6341dac83  vmovaps [rsp+0xC0], xmm13
000074b6341dac8c  vmovaps [rsp+0xD0], xmm14
000074b6341dac95  vmovaps [rsp+0xE0], xmm15
000074b6341dac9e  sub rsp, 0x30
000074b6341daca2  movaps [rsp], xmm12
000074b6341daca7  movaps [rsp+0x10], xmm14
000074b6341dacad  movaps [rsp+0x20], xmm1
000074b6341dacb2  lea rdi, [rsp]
000074b6341dacb6  mov esi, 0x00
000074b6341dacbb  mov rax, 0x5E1AA0A2F530
000074b6341dacc5  call rax
000074b6341dacc7  movaps xmm12, [rsp]
000074b6341daccc  add rsp, 0x30
000074b6341dacd0  vmovaps xmm0, [rsp]
000074b6341dacd5  vmovaps xmm1, [rsp+0x10]
000074b6341dacdb  vmovaps xmm2, [rsp+0x20]
000074b6341dace1  vmovaps xmm3, [rsp+0x30]
000074b6341dace7  vmovaps xmm4, [rsp+0x40]
000074b6341daced  vmovaps xmm5, [rsp+0x50]
000074b6341dacf3  vmovaps xmm6, [rsp+0x60]
000074b6341dacf9  vmovaps xmm7, [rsp+0x70]
000074b6341dacff  vmovaps xmm8, [rsp+0x80]
000074b6341dad08  vmovaps xmm9, [rsp+0x90]
000074b6341dad11  vmovaps xmm10, [rsp+0xA0]
000074b6341dad1a  vmovaps xmm11, [rsp+0xB0]
000074b6341dad23  vmovaps xmm13, [rsp+0xC0]
000074b6341dad2c  vmovaps xmm14, [rsp+0xD0]
000074b6341dad35  vmovaps xmm15, [rsp+0xE0]
000074b6341dad3e  add rsp, 0xF0
000074b6341dad45  pop r11
000074b6341dad47  pop r10
000074b6341dad49  pop r9
000074b6341dad4b  pop r8
000074b6341dad4d  pop rsi
000074b6341dad4e  pop rdi
000074b6341dad4f  pop rdx
000074b6341dad50  pop rcx
000074b6341dad51  pop rax
000074b6341dad52  add rsp, 0x08
000074b6341dad56  jmp 0x000074B6341D6549
000074b6341dad5b  sub rsp, 0x08
000074b6341dad5f  push rax
000074b6341dad60  push rcx
000074b6341dad61  push rdx
000074b6341dad62  push rdi
000074b6341dad63  push rsi
000074b6341dad64  push r8
000074b6341dad66  push r9
000074b6341dad68  push r10
000074b6341dad6a  push r11
000074b6341dad6c  sub rsp, 0xF0
000074b6341dad73  vmovaps [rsp], xmm0
000074b6341dad78  vmovaps [rsp+0x10], xmm1
000074b6341dad7e  vmovaps [rsp+0x20], xmm2
000074b6341dad84  vmovaps [rsp+0x30], xmm3
000074b6341dad8a  vmovaps [rsp+0x40], xmm4
000074b6341dad90  vmovaps [rsp+0x50], xmm5
000074b6341dad96  vmovaps [rsp+0x60], xmm6
000074b6341dad9c  vmovaps [rsp+0x70], xmm7
000074b6341dada2  vmovaps [rsp+0x80], xmm8
000074b6341dadab  vmovaps [rsp+0x90], xmm9
000074b6341dadb4  vmovaps [rsp+0xA0], xmm10
000074b6341dadbd  vmovaps [rsp+0xB0], xmm11
000074b6341dadc6  vmovaps [rsp+0xC0], xmm12
000074b6341dadcf  vmovaps [rsp+0xD0], xmm13
000074b6341dadd8  vmovaps [rsp+0xE0], xmm15
000074b6341dade1  sub rsp, 0x30
000074b6341dade5  movaps [rsp], xmm14
000074b6341dadea  movaps [rsp+0x10], xmm9
000074b6341dadf0  movaps [rsp+0x20], xmm1
000074b6341dadf5  lea rdi, [rsp]
000074b6341dadf9  mov esi, 0x00
000074b6341dadfe  mov rax, 0x5E1AA0A2F530
000074b6341dae08  call rax
000074b6341dae0a  movaps xmm14, [rsp]
000074b6341dae0f  add rsp, 0x30
000074b6341dae13  vmovaps xmm0, [rsp]
000074b6341dae18  vmovaps xmm1, [rsp+0x10]
000074b6341dae1e  vmovaps xmm2, [rsp+0x20]
000074b6341dae24  vmovaps xmm3, [rsp+0x30]
000074b6341dae2a  vmovaps xmm4, [rsp+0x40]
000074b6341dae30  vmovaps xmm5, [rsp+0x50]
000074b6341dae36  vmovaps xmm6, [rsp+0x60]
000074b6341dae3c  vmovaps xmm7, [rsp+0x70]
000074b6341dae42  vmovaps xmm8, [rsp+0x80]
000074b6341dae4b  vmovaps xmm9, [rsp+0x90]
000074b6341dae54  vmovaps xmm10, [rsp+0xA0]
000074b6341dae5d  vmovaps xmm11, [rsp+0xB0]
000074b6341dae66  vmovaps xmm12, [rsp+0xC0]
000074b6341dae6f  vmovaps xmm13, [rsp+0xD0]
000074b6341dae78  vmovaps xmm15, [rsp+0xE0]
000074b6341dae81  add rsp, 0xF0
000074b6341dae88  pop r11
000074b6341dae8a  pop r10
000074b6341dae8c  pop r9
000074b6341dae8e  pop r8
000074b6341dae90  pop rsi
000074b6341dae91  pop rdi
000074b6341dae92  pop rdx
000074b6341dae93  pop rcx
000074b6341dae94  pop rax
000074b6341dae95  add rsp, 0x08
000074b6341dae99  jmp 0x000074B6341D6578
000074b6341dae9e  sub rsp, 0x08
000074b6341daea2  push rax
000074b6341daea3  push rcx
000074b6341daea4  push rdx
000074b6341daea5  push rdi
000074b6341daea6  push rsi
000074b6341daea7  push r8
000074b6341daea9  push r9
000074b6341daeab  push r10
000074b6341daead  push r11
000074b6341daeaf  sub rsp, 0xF0
000074b6341daeb6  vmovaps [rsp], xmm0
000074b6341daebb  vmovaps [rsp+0x10], xmm2
000074b6341daec1  vmovaps [rsp+0x20], xmm3
000074b6341daec7  vmovaps [rsp+0x30], xmm4
000074b6341daecd  vmovaps [rsp+0x40], xmm5
000074b6341daed3  vmovaps [rsp+0x50], xmm6
000074b6341daed9  vmovaps [rsp+0x60], xmm7
000074b6341daedf  vmovaps [rsp+0x70], xmm8
000074b6341daee5  vmovaps [rsp+0x80], xmm9
000074b6341daeee  vmovaps [rsp+0x90], xmm10
000074b6341daef7  vmovaps [rsp+0xA0], xmm11
000074b6341daf00  vmovaps [rsp+0xB0], xmm12
000074b6341daf09  vmovaps [rsp+0xC0], xmm13
000074b6341daf12  vmovaps [rsp+0xD0], xmm14
000074b6341daf1b  vmovaps [rsp+0xE0], xmm15
000074b6341daf24  sub rsp, 0x30
000074b6341daf28  movaps [rsp], xmm1
000074b6341daf2c  movaps [rsp+0x10], xmm13
000074b6341daf32  movaps [rsp+0x20], xmm8
000074b6341daf38  lea rdi, [rsp]
000074b6341daf3c  mov esi, 0x00
000074b6341daf41  mov rax, 0x5E1AA0A2F530
000074b6341daf4b  call rax
000074b6341daf4d  movaps xmm1, [rsp]
000074b6341daf51  add rsp, 0x30
000074b6341daf55  vmovaps xmm0, [rsp]
000074b6341daf5a  vmovaps xmm2, [rsp+0x10]
000074b6341daf60  vmovaps xmm3, [rsp+0x20]
000074b6341daf66  vmovaps xmm4, [rsp+0x30]
000074b6341daf6c  vmovaps xmm5, [rsp+0x40]
000074b6341daf72  vmovaps xmm6, [rsp+0x50]
000074b6341daf78  vmovaps xmm7, [rsp+0x60]
000074b6341daf7e  vmovaps xmm8, [rsp+0x70]
000074b6341daf84  vmovaps xmm9, [rsp+0x80]
000074b6341daf8d  vmovaps xmm10, [rsp+0x90]
000074b6341daf96  vmovaps xmm11, [rsp+0xA0]
000074b6341daf9f  vmovaps xmm12, [rsp+0xB0]
000074b6341dafa8  vmovaps xmm13, [rsp+0xC0]
000074b6341dafb1  vmovaps xmm14, [rsp+0xD0]
000074b6341dafba  vmovaps xmm15, [rsp+0xE0]
000074b6341dafc3  add rsp, 0xF0
000074b6341dafca  pop r11
000074b6341dafcc  pop r10
000074b6341dafce  pop r9
000074b6341dafd0  pop r8
000074b6341dafd2  pop rsi
000074b6341dafd3  pop rdi
000074b6341dafd4  pop rdx
000074b6341dafd5  pop rcx
000074b6341dafd6  pop rax
000074b6341dafd7  add rsp, 0x08
000074b6341dafdb  jmp 0x000074B6341D659A
000074b6341dafe0  call 0x000074B63400C260
000074b6341dafe5  jmp 0x000074B6341D65A8
000074b6341dafea  call 0x000074B6340DE950
000074b6341dafef  jmp 0x000074B6341D65B2
000074b6341daff4  sub rsp, 0x08
000074b6341daff8  push rax
000074b6341daff9  push rcx
000074b6341daffa  push rdx
000074b6341daffb  push rdi
000074b6341daffc  push rsi
000074b6341daffd  push r8
000074b6341dafff  push r9
000074b6341db001  push r10
000074b6341db003  push r11
000074b6341db005  sub rsp, 0xF0
000074b6341db00c  vmovaps [rsp], xmm0
000074b6341db011  vmovaps [rsp+0x10], xmm1
000074b6341db017  vmovaps [rsp+0x20], xmm2
000074b6341db01d  vmovaps [rsp+0x30], xmm3
000074b6341db023  vmovaps [rsp+0x40], xmm4
000074b6341db029  vmovaps [rsp+0x50], xmm5
000074b6341db02f  vmovaps [rsp+0x60], xmm6
000074b6341db035  vmovaps [rsp+0x70], xmm7
000074b6341db03b  vmovaps [rsp+0x80], xmm9
000074b6341db044  vmovaps [rsp+0x90], xmm10
000074b6341db04d  vmovaps [rsp+0xA0], xmm11
000074b6341db056  vmovaps [rsp+0xB0], xmm12
000074b6341db05f  vmovaps [rsp+0xC0], xmm13
000074b6341db068  vmovaps [rsp+0xD0], xmm14
000074b6341db071  vmovaps [rsp+0xE0], xmm15
000074b6341db07a  sub rsp, 0x30
000074b6341db07e  movaps [rsp], xmm8
000074b6341db083  movaps [rsp+0x10], xmm15
000074b6341db089  movaps [rsp+0x20], xmm7
000074b6341db08e  lea rdi, [rsp]
000074b6341db092  mov esi, 0x00
000074b6341db097  mov rax, 0x5E1AA0A2F530
000074b6341db0a1  call rax
000074b6341db0a3  movaps xmm8, [rsp]
000074b6341db0a8  add rsp, 0x30
000074b6341db0ac  vmovaps xmm0, [rsp]
000074b6341db0b1  vmovaps xmm1, [rsp+0x10]
000074b6341db0b7  vmovaps xmm2, [rsp+0x20]
000074b6341db0bd  vmovaps xmm3, [rsp+0x30]
000074b6341db0c3  vmovaps xmm4, [rsp+0x40]
000074b6341db0c9  vmovaps xmm5, [rsp+0x50]
000074b6341db0cf  vmovaps xmm6, [rsp+0x60]
000074b6341db0d5  vmovaps xmm7, [rsp+0x70]
000074b6341db0db  vmovaps xmm9, [rsp+0x80]
000074b6341db0e4  vmovaps xmm10, [rsp+0x90]
000074b6341db0ed  vmovaps xmm11, [rsp+0xA0]
000074b6341db0f6  vmovaps xmm12, [rsp+0xB0]
000074b6341db0ff  vmovaps xmm13, [rsp+0xC0]
000074b6341db108  vmovaps xmm14, [rsp+0xD0]
000074b6341db111  vmovaps xmm15, [rsp+0xE0]
000074b6341db11a  add rsp, 0xF0
000074b6341db121  pop r11
000074b6341db123  pop r10
000074b6341db125  pop r9
000074b6341db127  pop r8
000074b6341db129  pop rsi
000074b6341db12a  pop rdi
000074b6341db12b  pop rdx
000074b6341db12c  pop rcx
000074b6341db12d  pop rax
000074b6341db12e  add rsp, 0x08
000074b6341db132  jmp 0x000074B6341D65D4
000074b6341db137  sub rsp, 0x08
000074b6341db13b  push rax
000074b6341db13c  push rcx
000074b6341db13d  push rdx
000074b6341db13e  push rdi
000074b6341db13f  push rsi
000074b6341db140  push r8
000074b6341db142  push r9
000074b6341db144  push r10
000074b6341db146  push r11
000074b6341db148  sub rsp, 0xF0
000074b6341db14f  vmovaps [rsp], xmm0
000074b6341db154  vmovaps [rsp+0x10], xmm1
000074b6341db15a  vmovaps [rsp+0x20], xmm2
000074b6341db160  vmovaps [rsp+0x30], xmm3
000074b6341db166  vmovaps [rsp+0x40], xmm4
000074b6341db16c  vmovaps [rsp+0x50], xmm5
000074b6341db172  vmovaps [rsp+0x60], xmm6
000074b6341db178  vmovaps [rsp+0x70], xmm8
000074b6341db17e  vmovaps [rsp+0x80], xmm9
000074b6341db187  vmovaps [rsp+0x90], xmm10
000074b6341db190  vmovaps [rsp+0xA0], xmm11
000074b6341db199  vmovaps [rsp+0xB0], xmm12
000074b6341db1a2  vmovaps [rsp+0xC0], xmm13
000074b6341db1ab  vmovaps [rsp+0xD0], xmm14
000074b6341db1b4  vmovaps [rsp+0xE0], xmm15
000074b6341db1bd  sub rsp, 0x30
000074b6341db1c1  movaps [rsp], xmm7
000074b6341db1c5  movaps [rsp+0x10], xmm9
000074b6341db1cb  movaps [rsp+0x20], xmm15
000074b6341db1d1  lea rdi, [rsp]
000074b6341db1d5  mov esi, 0x00
000074b6341db1da  mov rax, 0x5E1AA0A2F530
000074b6341db1e4  call rax
000074b6341db1e6  movaps xmm7, [rsp]
000074b6341db1ea  add rsp, 0x30
000074b6341db1ee  vmovaps xmm0, [rsp]
000074b6341db1f3  vmovaps xmm1, [rsp+0x10]
000074b6341db1f9  vmovaps xmm2, [rsp+0x20]
000074b6341db1ff  vmovaps xmm3, [rsp+0x30]
000074b6341db205  vmovaps xmm4, [rsp+0x40]
000074b6341db20b  vmovaps xmm5, [rsp+0x50]
000074b6341db211  vmovaps xmm6, [rsp+0x60]
000074b6341db217  vmovaps xmm8, [rsp+0x70]
000074b6341db21d  vmovaps xmm9, [rsp+0x80]
000074b6341db226  vmovaps xmm10, [rsp+0x90]
000074b6341db22f  vmovaps xmm11, [rsp+0xA0]
000074b6341db238  vmovaps xmm12, [rsp+0xB0]
000074b6341db241  vmovaps xmm13, [rsp+0xC0]
000074b6341db24a  vmovaps xmm14, [rsp+0xD0]
000074b6341db253  vmovaps xmm15, [rsp+0xE0]
000074b6341db25c  add rsp, 0xF0
000074b6341db263  pop r11
000074b6341db265  pop r10
000074b6341db267  pop r9
000074b6341db269  pop r8
000074b6341db26b  pop rsi
000074b6341db26c  pop rdi
000074b6341db26d  pop rdx
000074b6341db26e  pop rcx
000074b6341db26f  pop rax
000074b6341db270  add rsp, 0x08
000074b6341db274  jmp 0x000074B6341D6601
000074b6341db279  sub rsp, 0x08
000074b6341db27d  push rax
000074b6341db27e  push rcx
000074b6341db27f  push rdx
000074b6341db280  push rdi
000074b6341db281  push rsi
000074b6341db282  push r8
000074b6341db284  push r9
000074b6341db286  push r10
000074b6341db288  push r11
000074b6341db28a  sub rsp, 0xF0
000074b6341db291  vmovaps [rsp], xmm0
000074b6341db296  vmovaps [rsp+0x10], xmm1
000074b6341db29c  vmovaps [rsp+0x20], xmm2
000074b6341db2a2  vmovaps [rsp+0x30], xmm3
000074b6341db2a8  vmovaps [rsp+0x40], xmm4
000074b6341db2ae  vmovaps [rsp+0x50], xmm5
000074b6341db2b4  vmovaps [rsp+0x60], xmm6
000074b6341db2ba  vmovaps [rsp+0x70], xmm7
000074b6341db2c0  vmovaps [rsp+0x80], xmm8
000074b6341db2c9  vmovaps [rsp+0x90], xmm10
000074b6341db2d2  vmovaps [rsp+0xA0], xmm11
000074b6341db2db  vmovaps [rsp+0xB0], xmm12
000074b6341db2e4  vmovaps [rsp+0xC0], xmm13
000074b6341db2ed  vmovaps [rsp+0xD0], xmm14
000074b6341db2f6  vmovaps [rsp+0xE0], xmm15
000074b6341db2ff  sub rsp, 0x30
000074b6341db303  movaps [rsp], xmm9
000074b6341db308  movaps [rsp+0x10], xmm13
000074b6341db30e  movaps [rsp+0x20], xmm15
000074b6341db314  lea rdi, [rsp]
000074b6341db318  mov esi, 0x00
000074b6341db31d  mov rax, 0x5E1AA0A2F530
000074b6341db327  call rax
000074b6341db329  movaps xmm9, [rsp]
000074b6341db32e  add rsp, 0x30
000074b6341db332  vmovaps xmm0, [rsp]
000074b6341db337  vmovaps xmm1, [rsp+0x10]
000074b6341db33d  vmovaps xmm2, [rsp+0x20]
000074b6341db343  vmovaps xmm3, [rsp+0x30]
000074b6341db349  vmovaps xmm4, [rsp+0x40]
000074b6341db34f  vmovaps xmm5, [rsp+0x50]
000074b6341db355  vmovaps xmm6, [rsp+0x60]
000074b6341db35b  vmovaps xmm7, [rsp+0x70]
000074b6341db361  vmovaps xmm8, [rsp+0x80]
000074b6341db36a  vmovaps xmm10, [rsp+0x90]
000074b6341db373  vmovaps xmm11, [rsp+0xA0]
000074b6341db37c  vmovaps xmm12, [rsp+0xB0]
000074b6341db385  vmovaps xmm13, [rsp+0xC0]
000074b6341db38e  vmovaps xmm14, [rsp+0xD0]
000074b6341db397  vmovaps xmm15, [rsp+0xE0]
000074b6341db3a0  add rsp, 0xF0
000074b6341db3a7  pop r11
000074b6341db3a9  pop r10
000074b6341db3ab  pop r9
000074b6341db3ad  pop r8
000074b6341db3af  pop rsi
000074b6341db3b0  pop rdi
000074b6341db3b1  pop rdx
000074b6341db3b2  pop rcx
000074b6341db3b3  pop rax
000074b6341db3b4  add rsp, 0x08
000074b6341db3b8  jmp 0x000074B6341D662F
000074b6341db3bd  sub rsp, 0x08
000074b6341db3c1  push rax
000074b6341db3c2  push rcx
000074b6341db3c3  push rdx
000074b6341db3c4  push rdi
000074b6341db3c5  push rsi
000074b6341db3c6  push r8
000074b6341db3c8  push r9
000074b6341db3ca  push r10
000074b6341db3cc  push r11
000074b6341db3ce  sub rsp, 0xF0
000074b6341db3d5  vmovaps [rsp], xmm0
000074b6341db3da  vmovaps [rsp+0x10], xmm1
000074b6341db3e0  vmovaps [rsp+0x20], xmm2
000074b6341db3e6  vmovaps [rsp+0x30], xmm3
000074b6341db3ec  vmovaps [rsp+0x40], xmm4
000074b6341db3f2  vmovaps [rsp+0x50], xmm5
000074b6341db3f8  vmovaps [rsp+0x60], xmm6
000074b6341db3fe  vmovaps [rsp+0x70], xmm7
000074b6341db404  vmovaps [rsp+0x80], xmm8
000074b6341db40d  vmovaps [rsp+0x90], xmm9
000074b6341db416  vmovaps [rsp+0xA0], xmm10
000074b6341db41f  vmovaps [rsp+0xB0], xmm11
000074b6341db428  vmovaps [rsp+0xC0], xmm12
000074b6341db431  vmovaps [rsp+0xD0], xmm13
000074b6341db43a  vmovaps [rsp+0xE0], xmm14
000074b6341db443  sub rsp, 0x30
000074b6341db447  movaps [rsp], xmm15
000074b6341db44c  movaps [rsp+0x10], xmm11
000074b6341db452  movaps [rsp+0x20], xmm12
000074b6341db458  lea rdi, [rsp]
000074b6341db45c  mov esi, 0x00
000074b6341db461  mov rax, 0x5E1AA0A2F530
000074b6341db46b  call rax
000074b6341db46d  movaps xmm15, [rsp]
000074b6341db472  add rsp, 0x30
000074b6341db476  vmovaps xmm0, [rsp]
000074b6341db47b  vmovaps xmm1, [rsp+0x10]
000074b6341db481  vmovaps xmm2, [rsp+0x20]
000074b6341db487  vmovaps xmm3, [rsp+0x30]
000074b6341db48d  vmovaps xmm4, [rsp+0x40]
000074b6341db493  vmovaps xmm5, [rsp+0x50]
000074b6341db499  vmovaps xmm6, [rsp+0x60]
000074b6341db49f  vmovaps xmm7, [rsp+0x70]
000074b6341db4a5  vmovaps xmm8, [rsp+0x80]
000074b6341db4ae  vmovaps xmm9, [rsp+0x90]
000074b6341db4b7  vmovaps xmm10, [rsp+0xA0]
000074b6341db4c0  vmovaps xmm11, [rsp+0xB0]
000074b6341db4c9  vmovaps xmm12, [rsp+0xC0]
000074b6341db4d2  vmovaps xmm13, [rsp+0xD0]
000074b6341db4db  vmovaps xmm14, [rsp+0xE0]
000074b6341db4e4  add rsp, 0xF0
000074b6341db4eb  pop r11
000074b6341db4ed  pop r10
000074b6341db4ef  pop r9
000074b6341db4f1  pop r8
000074b6341db4f3  pop rsi
000074b6341db4f4  pop rdi
000074b6341db4f5  pop rdx
000074b6341db4f6  pop rcx
000074b6341db4f7  pop rax
000074b6341db4f8  add rsp, 0x08
000074b6341db4fc  jmp 0x000074B6341D664A
000074b6341db501  sub rsp, 0x08
000074b6341db505  push rax
000074b6341db506  push rcx
000074b6341db507  push rdx
000074b6341db508  push rdi
000074b6341db509  push rsi
000074b6341db50a  push r8
000074b6341db50c  push r9
000074b6341db50e  push r10
000074b6341db510  push r11
000074b6341db512  sub rsp, 0xF0
000074b6341db519  vmovaps [rsp], xmm0
000074b6341db51e  vmovaps [rsp+0x10], xmm1
000074b6341db524  vmovaps [rsp+0x20], xmm2
000074b6341db52a  vmovaps [rsp+0x30], xmm3
000074b6341db530  vmovaps [rsp+0x40], xmm4
000074b6341db536  vmovaps [rsp+0x50], xmm5
000074b6341db53c  vmovaps [rsp+0x60], xmm6
000074b6341db542  vmovaps [rsp+0x70], xmm7
000074b6341db548  vmovaps [rsp+0x80], xmm8
000074b6341db551  vmovaps [rsp+0x90], xmm9
000074b6341db55a  vmovaps [rsp+0xA0], xmm10
000074b6341db563  vmovaps [rsp+0xB0], xmm11
000074b6341db56c  vmovaps [rsp+0xC0], xmm12
000074b6341db575  vmovaps [rsp+0xD0], xmm14
000074b6341db57e  vmovaps [rsp+0xE0], xmm15
000074b6341db587  sub rsp, 0x30
000074b6341db58b  movaps [rsp], xmm13
000074b6341db590  movaps [rsp+0x10], xmm10
000074b6341db596  movaps [rsp+0x20], xmm14
000074b6341db59c  lea rdi, [rsp]
000074b6341db5a0  mov esi, 0x00
000074b6341db5a5  mov rax, 0x5E1AA0A2F530
000074b6341db5af  call rax
000074b6341db5b1  movaps xmm13, [rsp]
000074b6341db5b6  add rsp, 0x30
000074b6341db5ba  vmovaps xmm0, [rsp]
000074b6341db5bf  vmovaps xmm1, [rsp+0x10]
000074b6341db5c5  vmovaps xmm2, [rsp+0x20]
000074b6341db5cb  vmovaps xmm3, [rsp+0x30]
000074b6341db5d1  vmovaps xmm4, [rsp+0x40]
000074b6341db5d7  vmovaps xmm5, [rsp+0x50]
000074b6341db5dd  vmovaps xmm6, [rsp+0x60]
000074b6341db5e3  vmovaps xmm7, [rsp+0x70]
000074b6341db5e9  vmovaps xmm8, [rsp+0x80]
000074b6341db5f2  vmovaps xmm9, [rsp+0x90]
000074b6341db5fb  vmovaps xmm10, [rsp+0xA0]
000074b6341db604  vmovaps xmm11, [rsp+0xB0]
000074b6341db60d  vmovaps xmm12, [rsp+0xC0]
000074b6341db616  vmovaps xmm14, [rsp+0xD0]
000074b6341db61f  vmovaps xmm15, [rsp+0xE0]
000074b6341db628  add rsp, 0xF0
000074b6341db62f  pop r11
000074b6341db631  pop r10
000074b6341db633  pop r9
000074b6341db635  pop r8
000074b6341db637  pop rsi
000074b6341db638  pop rdi
000074b6341db639  pop rdx
000074b6341db63a  pop rcx
000074b6341db63b  pop rax
000074b6341db63c  add rsp, 0x08
000074b6341db640  jmp 0x000074B6341D666D
000074b6341db645  sub rsp, 0x08
000074b6341db649  push rax
000074b6341db64a  push rcx
000074b6341db64b  push rdx
000074b6341db64c  push rdi
000074b6341db64d  push rsi
000074b6341db64e  push r8
000074b6341db650  push r9
000074b6341db652  push r10
000074b6341db654  push r11
000074b6341db656  sub rsp, 0xF0
000074b6341db65d  vmovaps [rsp], xmm0
000074b6341db662  vmovaps [rsp+0x10], xmm1
000074b6341db668  vmovaps [rsp+0x20], xmm2
000074b6341db66e  vmovaps [rsp+0x30], xmm3
000074b6341db674  vmovaps [rsp+0x40], xmm4
000074b6341db67a  vmovaps [rsp+0x50], xmm5
000074b6341db680  vmovaps [rsp+0x60], xmm6
000074b6341db686  vmovaps [rsp+0x70], xmm7
000074b6341db68c  vmovaps [rsp+0x80], xmm8
000074b6341db695  vmovaps [rsp+0x90], xmm9
000074b6341db69e  vmovaps [rsp+0xA0], xmm10
000074b6341db6a7  vmovaps [rsp+0xB0], xmm11
000074b6341db6b0  vmovaps [rsp+0xC0], xmm12
000074b6341db6b9  vmovaps [rsp+0xD0], xmm13
000074b6341db6c2  vmovaps [rsp+0xE0], xmm15
000074b6341db6cb  sub rsp, 0x30
000074b6341db6cf  movaps [rsp], xmm14
000074b6341db6d4  movaps [rsp+0x10], xmm1
000074b6341db6d9  movaps [rsp+0x20], xmm7
000074b6341db6de  lea rdi, [rsp]
000074b6341db6e2  mov esi, 0x00
000074b6341db6e7  mov rax, 0x5E1AA0A2F530
000074b6341db6f1  call rax
000074b6341db6f3  movaps xmm14, [rsp]
000074b6341db6f8  add rsp, 0x30
000074b6341db6fc  vmovaps xmm0, [rsp]
000074b6341db701  vmovaps xmm1, [rsp+0x10]
000074b6341db707  vmovaps xmm2, [rsp+0x20]
000074b6341db70d  vmovaps xmm3, [rsp+0x30]
000074b6341db713  vmovaps xmm4, [rsp+0x40]
000074b6341db719  vmovaps xmm5, [rsp+0x50]
000074b6341db71f  vmovaps xmm6, [rsp+0x60]
000074b6341db725  vmovaps xmm7, [rsp+0x70]
000074b6341db72b  vmovaps xmm8, [rsp+0x80]
000074b6341db734  vmovaps xmm9, [rsp+0x90]
000074b6341db73d  vmovaps xmm10, [rsp+0xA0]
000074b6341db746  vmovaps xmm11, [rsp+0xB0]
000074b6341db74f  vmovaps xmm12, [rsp+0xC0]
000074b6341db758  vmovaps xmm13, [rsp+0xD0]
000074b6341db761  vmovaps xmm15, [rsp+0xE0]
000074b6341db76a  add rsp, 0xF0
000074b6341db771  pop r11
000074b6341db773  pop r10
000074b6341db775  pop r9
000074b6341db777  pop r8
000074b6341db779  pop rsi
000074b6341db77a  pop rdi
000074b6341db77b  pop rdx
000074b6341db77c  pop rcx
000074b6341db77d  pop rax
000074b6341db77e  add rsp, 0x08
000074b6341db782  jmp 0x000074B6341D6690
000074b6341db787  sub rsp, 0x08
000074b6341db78b  push rax
000074b6341db78c  push rcx
000074b6341db78d  push rdx
000074b6341db78e  push rdi
000074b6341db78f  push rsi
000074b6341db790  push r8
000074b6341db792  push r9
000074b6341db794  push r10
000074b6341db796  push r11
000074b6341db798  sub rsp, 0xF0
000074b6341db79f  vmovaps [rsp], xmm0
000074b6341db7a4  vmovaps [rsp+0x10], xmm2
000074b6341db7aa  vmovaps [rsp+0x20], xmm3
000074b6341db7b0  vmovaps [rsp+0x30], xmm4
000074b6341db7b6  vmovaps [rsp+0x40], xmm5
000074b6341db7bc  vmovaps [rsp+0x50], xmm6
000074b6341db7c2  vmovaps [rsp+0x60], xmm7
000074b6341db7c8  vmovaps [rsp+0x70], xmm8
000074b6341db7ce  vmovaps [rsp+0x80], xmm9
000074b6341db7d7  vmovaps [rsp+0x90], xmm10
000074b6341db7e0  vmovaps [rsp+0xA0], xmm11
000074b6341db7e9  vmovaps [rsp+0xB0], xmm12
000074b6341db7f2  vmovaps [rsp+0xC0], xmm13
000074b6341db7fb  vmovaps [rsp+0xD0], xmm14
000074b6341db804  vmovaps [rsp+0xE0], xmm15
000074b6341db80d  sub rsp, 0x30
000074b6341db811  movaps [rsp], xmm1
000074b6341db815  movaps [rsp+0x10], xmm8
000074b6341db81b  movaps [rsp+0x20], xmm9
000074b6341db821  lea rdi, [rsp]
000074b6341db825  mov esi, 0x00
000074b6341db82a  mov rax, 0x5E1AA0A2F530
000074b6341db834  call rax
000074b6341db836  movaps xmm1, [rsp]
000074b6341db83a  add rsp, 0x30
000074b6341db83e  vmovaps xmm0, [rsp]
000074b6341db843  vmovaps xmm2, [rsp+0x10]
000074b6341db849  vmovaps xmm3, [rsp+0x20]
000074b6341db84f  vmovaps xmm4, [rsp+0x30]
000074b6341db855  vmovaps xmm5, [rsp+0x40]
000074b6341db85b  vmovaps xmm6, [rsp+0x50]
000074b6341db861  vmovaps xmm7, [rsp+0x60]
000074b6341db867  vmovaps xmm8, [rsp+0x70]
000074b6341db86d  vmovaps xmm9, [rsp+0x80]
000074b6341db876  vmovaps xmm10, [rsp+0x90]
000074b6341db87f  vmovaps xmm11, [rsp+0xA0]
000074b6341db888  vmovaps xmm12, [rsp+0xB0]
000074b6341db891  vmovaps xmm13, [rsp+0xC0]
000074b6341db89a  vmovaps xmm14, [rsp+0xD0]
000074b6341db8a3  vmovaps xmm15, [rsp+0xE0]
000074b6341db8ac  add rsp, 0xF0
000074b6341db8b3  pop r11
000074b6341db8b5  pop r10
000074b6341db8b7  pop r9
000074b6341db8b9  pop r8
000074b6341db8bb  pop rsi
000074b6341db8bc  pop rdi
000074b6341db8bd  pop rdx
000074b6341db8be  pop rcx
000074b6341db8bf  pop rax
000074b6341db8c0  add rsp, 0x08
000074b6341db8c4  jmp 0x000074B6341D66B2
000074b6341db8c9  call 0x000074B6340B3E40
000074b6341db8ce  jmp 0x000074B6341D66C0
000074b6341db8d3  call 0x000074B63400C380
000074b6341db8d8  jmp 0x000074B6341D66CA
000074b6341db8dd  call 0x000074B63400D600
000074b6341db8e2  jmp 0x000074B6341D66D4
000074b6341db8e7  call 0x000074B633FFF540
000074b6341db8ec  jmp 0x000074B6341D66DE
000074b6341db8f1  int3
000074b6341db8f2  nop [rax+rax*1], ax
000074b6341db8fb  nop [rax+rax*1], eax
000074b6341db900  mov eax, [r15+0x48]
000074b6341db904  lea r14d, [eax+0x01]
000074b6341db909  mov [rsp+0x10], r14d
000074b6341db90e  mov r14d, r14d
000074b6341db911  mov [r15+0x48], r14
000074b6341db915  xor eax, eax
000074b6341db917  mov r14d, [rsp+0x10]
000074b6341db91c  cmp r14d, 0x1F4
000074b6341db923  cmc
000074b6341db924  lahf
000074b6341db925  seto al
000074b6341db928  mov [r15+0x108], eax
000074b6341db92f  mov eax, [r15+0x108]
000074b6341db936  sahf
000074b6341db937  jnz 0x000074B6341DB969
000074b6341db939  cmp dword ptr [r15+0x318], 0x00
000074b6341db941  jz 0x000074B6341E1AB0
000074b6341db947  nop [rax+rax*1], ax
000074b6341db950  nop [rax+rax*1], eax
000074b6341db958  mov eax, 0x410450
000074b6341db95d  mov [r15+0x100], rax
000074b6341db964  jmp 0x000074B633FFE110
000074b6341db969  cmp dword ptr [r15+0x318], 0x00
000074b6341db971  jz 0x000074B6341DB9A0
000074b6341db977  nop [rax+rax*1], ax
000074b6341db980  nop [rax+rax*1], eax
000074b6341db988  mov eax, 0x410274
000074b6341db98d  mov [r15+0x100], rax
000074b6341db994  jmp 0x000074B633FFE110
000074b6341db999  int3
000074b6341db99a  int3
000074b6341db99b  nop [rax+rax*1], eax
000074b6341db9a0  mov rax, [r15+0x40]
000074b6341db9a4  movaps xmm1, [r15+0x1D0]
000074b6341db9ac  vmovaps [rsp+0x10], xmm1
000074b6341db9b2  vmovaps xmm15, [rsp+0x10]
000074b6341db9b8  por xmm1, xmm15
000074b6341db9bd  movaps xmm14, [r15+0x1A0]
000074b6341db9c5  vmovaps [rsp+0x10], xmm14
000074b6341db9cb  vmovaps xmm13, [rsp+0x10]
000074b6341db9d1  por xmm14, xmm13
000074b6341db9d6  lea r14, [rax+0x30]
000074b6341db9da  mov r12, [r13+r14*1]
000074b6341db9df  lea r14, [rax+0x38]
000074b6341db9e3  mov r11, [r13+r14*1]
000074b6341db9e8  movq xmm13, r12
000074b6341db9ed  movq xmm12, r11
000074b6341db9f2  movq xmm13, xmm13
000074b6341db9f7  vmovaps [rsp+0x10], xmm13
000074b6341db9fd  movq xmm13, xmm13
000074b6341dba02  movaps [r15+0x130], xmm13
000074b6341dba0a  movq xmm12, xmm12
000074b6341dba0f  vmovaps [rsp+0x20], xmm12
000074b6341dba15  movq xmm12, xmm12
000074b6341dba1a  movaps [r15+0x280], xmm12
000074b6341dba22  movaps xmm13, [r15+0x270]
000074b6341dba2a  vmovaps [rsp+0x30], xmm13
000074b6341dba30  vmovaps xmm12, [rsp+0x30]
000074b6341dba36  por xmm13, xmm12
000074b6341dba3b  lea r14, [rax+0x20]
000074b6341dba3f  mov r12, [r13+r14*1]
000074b6341dba44  lea r14, [rax+0x28]
000074b6341dba48  mov r11, [r13+r14*1]
000074b6341dba4d  movq xmm12, r12
000074b6341dba52  movq xmm11, r11
000074b6341dba57  movq xmm12, xmm12
000074b6341dba5c  vmovaps [rsp+0x30], xmm12
000074b6341dba62  movq xmm12, xmm12
000074b6341dba67  movaps [r15+0x150], xmm12
000074b6341dba6f  movq xmm11, xmm11
000074b6341dba74  vmovaps [rsp+0x40], xmm11
000074b6341dba7a  movq xmm11, xmm11
000074b6341dba7f  movaps [r15+0x140], xmm11
000074b6341dba87  lea r14, [rax+0x10]
000074b6341dba8b  mov r12, [r13+r14*1]
000074b6341dba90  lea r14, [rax+0x18]
000074b6341dba94  mov r11, [r13+r14*1]
000074b6341dba99  movq xmm12, r12
000074b6341dba9e  movq xmm11, r11
000074b6341dbaa3  movq xmm12, xmm12
000074b6341dbaa8  vmovaps [rsp+0x50], xmm12
000074b6341dbaae  movq xmm12, xmm12
000074b6341dbab3  movaps [r15+0x170], xmm12
000074b6341dbabb  movq xmm11, xmm11
000074b6341dbac0  vmovaps [rsp+0x60], xmm11
000074b6341dbac6  movq xmm11, xmm11
000074b6341dbacb  movaps [r15+0x160], xmm11
000074b6341dbad3  mov r14, [r13+rax*1]
000074b6341dbad8  vmovq xmm12, r14
000074b6341dbadd  vpbroadcastq xmm12, xmm12
000074b6341dbae2  lea r14, [rax+0x08]
000074b6341dbae6  mov rax, [r13+r14*1]
000074b6341dbaeb  movq xmm11, rax
000074b6341dbaf0  movaps [r15+0x230], xmm11
000074b6341dbaf8  mov rax, [r15+0xF8]
000074b6341dbaff  lea r14, [rax+0x50]
000074b6341dbb03  movups xmm11, [r13+r14*1]
000074b6341dbb09  lea r14, [rax+0x60]
000074b6341dbb0d  movups xmm10, [r13+r14*1]
000074b6341dbb13  lea r14, [rax+0x30]
000074b6341dbb17  movups xmm9, [r13+r14*1]
000074b6341dbb1d  mov r14, [r15+0x50]
000074b6341dbb21  mov [r15+0x60], r14
000074b6341dbb25  mov qword ptr [r15+0x58], 0x40
000074b6341dbb2d  movaps xmm8, xmm12
000074b6341dbb31  mulpd xmm8, xmm15
000074b6341dbb36  vcmppd xmm7, xmm8, xmm8, 0x03
000074b6341dbb3c  ptest xmm7, xmm7
000074b6341dbb41  jnz 0x000074B6341DC96A
000074b6341dbb47  movq xmm15, qword ptr [r15+0x230]
000074b6341dbb50  vmovaps [rsp+0x70], xmm15
000074b6341dbb56  vpermilpd xmm15, xmm15, 0x00
000074b6341dbb5c  movaps xmm7, xmm9
000074b6341dbb60  mulpd xmm7, xmm15
000074b6341dbb65  vcmppd xmm6, xmm7, xmm7, 0x03
000074b6341dbb6a  ptest xmm6, xmm6
000074b6341dbb6f  jnz 0x000074B6341DCAAE
000074b6341dbb75  vxorps xmm15, xmm15, xmm15
000074b6341dbb7a  vpbroadcastq xmm15, xmm15
000074b6341dbb7f  movaps xmm9, xmm12
000074b6341dbb83  mulpd xmm9, xmm10
000074b6341dbb88  vcmppd xmm6, xmm9, xmm9, 0x03
000074b6341dbb8e  ptest xmm6, xmm6
000074b6341dbb93  jnz 0x000074B6341DCBF0
000074b6341dbb99  movaps xmm10, xmm12
000074b6341dbb9d  mulpd xmm10, xmm11
000074b6341dbba2  vcmppd xmm6, xmm10, xmm10, 0x03
000074b6341dbba8  ptest xmm6, xmm6
000074b6341dbbad  jnz 0x000074B6341DCD34
000074b6341dbbb3  movaps xmm11, [r15+0x1F0]
000074b6341dbbbb  movaps xmm6, xmm12
000074b6341dbbbf  mulpd xmm6, xmm11
000074b6341dbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
000074b6341dbbc9  ptest xmm5, xmm5
000074b6341dbbce  jnz 0x000074B6341DCE78
000074b6341dbbd4  movaps xmm12, [r15+0x2A0]
000074b6341dbbdc  vmovaps [rsp+0x80], xmm12
000074b6341dbbe5  vmovaps xmm11, [rsp+0x80]
000074b6341dbbee  por xmm12, xmm11
000074b6341dbbf3  movaps xmm11, [r15+0x250]
000074b6341dbbfb  vmovaps [rsp+0x80], xmm11
000074b6341dbc04  vmovaps xmm5, [rsp+0x80]
000074b6341dbc0d  por xmm11, xmm5
000074b6341dbc12  vmovaps xmm4, [rsp+0x70]
000074b6341dbc18  vpermilpd xmm4, xmm4, 0x00
000074b6341dbc1e  movaps xmm3, xmm5
000074b6341dbc21  mulpd xmm3, xmm4
000074b6341dbc25  vcmppd xmm2, xmm3, xmm3, 0x03
000074b6341dbc2a  ptest xmm2, xmm2
000074b6341dbc2f  jnz 0x000074B6341DCFBA
000074b6341dbc35  mov [rsp+0x80], rax
000074b6341dbc3d  xor eax, eax
000074b6341dbc3f  mov r12d, 0x40
000074b6341dbc45  mov r11d, 0x200
000074b6341dbc4b  cmp r12, r11
000074b6341dbc4e  cmc
000074b6341dbc4f  lahf
000074b6341dbc50  seto al
000074b6341dbc53  mov [r15+0x108], eax
000074b6341dbc5a  movaps xmm5, xmm8
000074b6341dbc5e  addpd xmm5, xmm15
000074b6341dbc63  vcmppd xmm4, xmm5, xmm5, 0x03
000074b6341dbc68  ptest xmm4, xmm4
000074b6341dbc6d  jnz 0x000074B6341DD0FA
000074b6341dbc73  movaps xmm8, [r15+0x1B0]
000074b6341dbc7b  movaps xmm4, xmm9
000074b6341dbc7f  addpd xmm4, xmm8
000074b6341dbc84  vcmppd xmm2, xmm4, xmm4, 0x03
000074b6341dbc89  ptest xmm2, xmm2
000074b6341dbc8e  jnz 0x000074B6341DD23C
000074b6341dbc94  movaps xmm9, xmm10
000074b6341dbc98  addpd xmm9, xmm8
000074b6341dbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
000074b6341dbca3  ptest xmm2, xmm2
000074b6341dbca8  jnz 0x000074B6341DD37E
000074b6341dbcae  movaps xmm10, [r15+0x2F0]
000074b6341dbcb6  vmovaps [rsp+0x90], xmm10
000074b6341dbcbf  vmovaps xmm8, [rsp+0x90]
000074b6341dbcc8  por xmm10, xmm8
000074b6341dbccd  movaps xmm8, [r15+0x2E0]
000074b6341dbcd5  vmovaps [rsp+0x90], xmm8
000074b6341dbcde  vmovaps xmm2, [rsp+0x90]
000074b6341dbce7  por xmm8, xmm2
000074b6341dbcec  movaps xmm2, [r15+0x2D0]
000074b6341dbcf4  vmovaps [rsp+0x90], xmm2
000074b6341dbcfd  vmovaps [rsp+0xA0], xmm1
000074b6341dbd06  vmovaps xmm1, [rsp+0x90]
000074b6341dbd0f  por xmm2, xmm1
000074b6341dbd13  movaps xmm1, [r15+0x200]
000074b6341dbd1b  vmovaps [rsp+0x90], xmm1
000074b6341dbd24  vmovaps [rsp+0xB0], xmm15
000074b6341dbd2d  vmovaps xmm15, [rsp+0x90]
000074b6341dbd36  por xmm1, xmm15
000074b6341dbd3b  movaps xmm15, [r15+0x1C0]
000074b6341dbd43  vmovaps [rsp+0x90], xmm15
000074b6341dbd4c  vmovaps [rsp+0xC0], xmm1
000074b6341dbd55  vmovaps xmm1, [rsp+0x90]
000074b6341dbd5e  por xmm15, xmm1
000074b6341dbd63  movaps xmm1, [r15+0x190]
000074b6341dbd6b  vmovaps [rsp+0x90], xmm1
000074b6341dbd74  vmovaps [rsp+0xD0], xmm15
000074b6341dbd7d  vmovaps xmm15, [rsp+0x90]
000074b6341dbd86  por xmm1, xmm15
000074b6341dbd8b  movaps xmm15, [r15+0x300]
000074b6341dbd93  vmovaps [rsp+0x90], xmm15
000074b6341dbd9c  vmovaps [rsp+0xE0], xmm1
000074b6341dbda5  vmovaps xmm1, [rsp+0x90]
000074b6341dbdae  por xmm15, xmm1
000074b6341dbdb3  mov rax, [rsp+0x80]
000074b6341dbdbb  lea r12, [rax+0xA0]
000074b6341dbdc2  movups xmm1, [r13+r12*1]
000074b6341dbdc8  lea r12, [rax+0xB0]
000074b6341dbdcf  vmovaps [rsp+0x80], xmm1
000074b6341dbdd8  movups xmm1, [r13+r12*1]
000074b6341dbdde  vmovaps [rsp+0x90], xmm1
000074b6341dbde7  vmovaps [rsp+0xF0], xmm15
000074b6341dbdf0  vmovaps xmm15, [rsp+0xB0]
000074b6341dbdf9  vmovaps [rsp+0xB0], xmm14
000074b6341dbe02  movaps xmm1, xmm6
000074b6341dbe05  addpd xmm1, xmm15
000074b6341dbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
000074b6341dbe0f  ptest xmm14, xmm14
000074b6341dbe15  jnz 0x000074B6341DD4D6
000074b6341dbe1b  lea r12, [rax+0xF0]
000074b6341dbe22  movups xmm15, [r13+r12*1]
000074b6341dbe28  movaps xmm14, xmm4
000074b6341dbe2c  addpd xmm14, xmm3
000074b6341dbe31  vcmppd xmm6, xmm14, xmm14, 0x03
000074b6341dbe37  ptest xmm6, xmm6
000074b6341dbe3c  jnz 0x000074B6341DD621
000074b6341dbe42  movaps xmm6, xmm9
000074b6341dbe46  addpd xmm6, xmm7
000074b6341dbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
000074b6341dbe4f  ptest xmm4, xmm4
000074b6341dbe54  jnz 0x000074B6341DD763
000074b6341dbe5a  vmovaps xmm9, [rsp+0x70]
000074b6341dbe60  vpermilpd xmm9, xmm9, 0x00
000074b6341dbe66  vmovaps xmm4, [rsp+0x90]
000074b6341dbe6f  movaps xmm7, xmm4
000074b6341dbe72  mulpd xmm7, xmm9
000074b6341dbe77  vcmppd xmm3, xmm7, xmm7, 0x03
000074b6341dbe7c  ptest xmm3, xmm3
000074b6341dbe81  jnz 0x000074B6341DD8A4
000074b6341dbe87  vmovaps xmm9, [rsp+0x50]
000074b6341dbe8d  vpermilpd xmm9, xmm9, 0x00
000074b6341dbe93  movaps xmm4, xmm15
000074b6341dbe97  mulpd xmm4, xmm9
000074b6341dbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
000074b6341dbea1  ptest xmm3, xmm3
000074b6341dbea6  jnz 0x000074B6341DD9E5
000074b6341dbeac  lea r12, [rax+0xE0]
000074b6341dbeb3  movups xmm15, [r13+r12*1]
000074b6341dbeb9  vmovaps xmm9, [rsp+0x70]
000074b6341dbebf  vpermilpd xmm9, xmm9, 0x00
000074b6341dbec5  vmovaps [rsp+0x70], xmm1
000074b6341dbecb  vmovaps xmm1, [rsp+0x80]
000074b6341dbed4  vmovaps [rsp+0x80], xmm15
000074b6341dbedd  movaps xmm3, xmm1
000074b6341dbee0  mulpd xmm3, xmm9
000074b6341dbee5  vcmppd xmm15, xmm3, xmm3, 0x03
000074b6341dbeea  ptest xmm15, xmm15
000074b6341dbef0  jnz 0x000074B6341DDB31
000074b6341dbef6  vmovaps xmm1, [rsp+0xF0]
000074b6341dbeff  vmovaps xmm15, [rsp+0xF0]
000074b6341dbf08  por xmm1, xmm15
000074b6341dbf0d  movaps [r15+0x300], xmm1
000074b6341dbf15  vmovaps xmm15, [rsp+0xE0]
000074b6341dbf1e  vmovaps xmm9, [rsp+0xE0]
000074b6341dbf27  por xmm15, xmm9
000074b6341dbf2c  movaps [r15+0x190], xmm15
000074b6341dbf34  vmovaps xmm9, [rsp+0x50]
000074b6341dbf3a  vpermilpd xmm9, xmm9, 0x00
000074b6341dbf40  vmovaps [rsp+0x90], xmm1
000074b6341dbf49  vmovaps [rsp+0xE0], xmm15
000074b6341dbf52  vmovaps xmm15, [rsp+0x80]
000074b6341dbf5b  vmovaps [rsp+0x80], xmm14
000074b6341dbf64  movaps xmm1, xmm15
000074b6341dbf68  mulpd xmm1, xmm9
000074b6341dbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
000074b6341dbf72  ptest xmm14, xmm14
000074b6341dbf78  jnz 0x000074B6341DDC72
000074b6341dbf7e  lea r12, [rax+0x90]
000074b6341dbf85  movups xmm15, [r13+r12*1]
000074b6341dbf8b  vmovaps xmm14, [rsp+0xD0]
000074b6341dbf94  vmovaps xmm9, [rsp+0xD0]
000074b6341dbf9d  por xmm14, xmm9
000074b6341dbfa2  movaps [r15+0x1C0], xmm14
000074b6341dbfaa  vmovaps xmm9, [rsp+0xC0]
000074b6341dbfb3  vmovaps [rsp+0xD0], xmm1
000074b6341dbfbc  vmovaps xmm1, [rsp+0xC0]
000074b6341dbfc5  por xmm9, xmm1
000074b6341dbfca  movaps [r15+0x200], xmm9
000074b6341dbfd2  vmovaps [rsp+0xC0], xmm2
000074b6341dbfdb  vmovaps xmm1, [rsp+0xC0]
000074b6341dbfe4  por xmm2, xmm1
000074b6341dbfe8  movaps [r15+0x2D0], xmm2
000074b6341dbff0  vmovaps [rsp+0xC0], xmm8
000074b6341dbff9  vmovaps xmm1, [rsp+0xC0]
000074b6341dc002  por xmm8, xmm1
000074b6341dc007  movaps [r15+0x2E0], xmm8
000074b6341dc00f  vmovaps [rsp+0xC0], xmm15
000074b6341dc018  movaps xmm1, xmm5
000074b6341dc01b  addpd xmm1, xmm7
000074b6341dc01f  vcmppd xmm15, xmm1, xmm1, 0x03
000074b6341dc024  ptest xmm15, xmm15
000074b6341dc02a  jnz 0x000074B6341DDDBE
000074b6341dc030  vmovaps xmm15, [rsp+0x50]
000074b6341dc036  vpermilpd xmm15, xmm15, 0x00
000074b6341dc03c  vmovaps xmm5, [rsp+0xC0]
000074b6341dc045  vmovaps [rsp+0xC0], xmm1
000074b6341dc04e  movaps xmm7, xmm5
000074b6341dc051  mulpd xmm7, xmm15
000074b6341dc056  vcmppd xmm1, xmm7, xmm7, 0x03
000074b6341dc05b  ptest xmm1, xmm1
000074b6341dc060  jnz 0x000074B6341DDEFE
000074b6341dc066  lea r12, [rax+0x80]
000074b6341dc06d  movups xmm1, [r13+r12*1]
000074b6341dc073  vmovaps xmm5, [rsp+0x70]
000074b6341dc079  vmovaps [rsp+0x70], xmm1
000074b6341dc07f  movaps xmm15, xmm5
000074b6341dc083  addpd xmm15, xmm3
000074b6341dc088  vcmppd xmm1, xmm15, xmm15, 0x03
000074b6341dc08e  ptest xmm1, xmm1
000074b6341dc093  jnz 0x000074B6341DE049
000074b6341dc099  vmovaps xmm5, [rsp+0x80]
000074b6341dc0a2  movaps xmm1, xmm5
000074b6341dc0a5  addpd xmm1, xmm4
000074b6341dc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
000074b6341dc0ae  ptest xmm3, xmm3
000074b6341dc0b3  jnz 0x000074B6341DE18B
000074b6341dc0b9  vmovaps [rsp+0x80], xmm10
000074b6341dc0c2  vmovaps xmm5, [rsp+0x80]
000074b6341dc0cb  por xmm10, xmm5
000074b6341dc0d0  movaps [r15+0x2F0], xmm10
000074b6341dc0d8  vmovaps xmm5, [rsp+0x50]
000074b6341dc0de  vpermilpd xmm5, xmm5, 0x00
000074b6341dc0e4  vmovaps xmm3, [rsp+0x70]
000074b6341dc0ea  vmovaps [rsp+0x50], xmm1
000074b6341dc0f0  movaps xmm4, xmm3
000074b6341dc0f3  mulpd xmm4, xmm5
000074b6341dc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
000074b6341dc0fc  ptest xmm1, xmm1
000074b6341dc101  jnz 0x000074B6341DE2CB
000074b6341dc107  lea r12, [rax+0xD0]
000074b6341dc10e  movups xmm1, [r13+r12*1]
000074b6341dc114  vmovaps xmm3, [rsp+0xD0]
000074b6341dc11d  vmovaps [rsp+0x70], xmm1
000074b6341dc123  movaps xmm5, xmm6
000074b6341dc126  addpd xmm5, xmm3
000074b6341dc12a  vcmppd xmm1, xmm5, xmm5, 0x03
000074b6341dc12f  ptest xmm1, xmm1
000074b6341dc134  jnz 0x000074B6341DE415
000074b6341dc13a  vmovaps xmm1, [rsp+0x60]
000074b6341dc140  vpermilpd xmm1, xmm1, 0x00
000074b6341dc146  movaps xmm6, xmm9
000074b6341dc14a  mulpd xmm6, xmm1
000074b6341dc14e  vcmppd xmm3, xmm6, xmm6, 0x03
000074b6341dc153  ptest xmm3, xmm3
000074b6341dc158  jnz 0x000074B6341DE555
000074b6341dc15e  movaps [r15+0x260], xmm6
000074b6341dc166  vxorps xmm1, xmm1, xmm1
000074b6341dc16a  vpbroadcastq xmm1, xmm1
000074b6341dc16f  movaps [r15+0x1B0], xmm1
000074b6341dc177  vmovaps xmm1, [rsp+0x60]
000074b6341dc17d  vpermilpd xmm1, xmm1, 0x00
000074b6341dc183  vmovaps xmm3, [rsp+0x70]
000074b6341dc189  vmovaps [rsp+0x70], xmm15
000074b6341dc18f  movaps xmm9, xmm3
000074b6341dc193  mulpd xmm9, xmm1
000074b6341dc198  vcmppd xmm15, xmm9, xmm9, 0x03
000074b6341dc19e  ptest xmm15, xmm15
000074b6341dc1a4  jnz 0x000074B6341DE696
000074b6341dc1aa  lea r12, [rax+0xC0]
000074b6341dc1b1  movups xmm1, [r13+r12*1]
000074b6341dc1b7  vmovaps xmm3, [rsp+0xC0]
000074b6341dc1c0  vmovaps [rsp+0x80], xmm1
000074b6341dc1c9  movaps xmm15, xmm3
000074b6341dc1cd  addpd xmm15, xmm7
000074b6341dc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
000074b6341dc1d8  ptest xmm1, xmm1
000074b6341dc1dd  jnz 0x000074B6341DE7E2
000074b6341dc1e3  vmovaps [rsp+0xC0], xmm13
000074b6341dc1ec  vmovaps xmm1, [rsp+0xC0]
000074b6341dc1f5  por xmm13, xmm1
000074b6341dc1fa  movaps [r15+0x270], xmm13
000074b6341dc202  vmovaps xmm1, [rsp+0xB0]
000074b6341dc20b  vmovaps xmm7, [rsp+0xB0]
000074b6341dc214  por xmm1, xmm7
000074b6341dc218  movaps [r15+0x1A0], xmm1
000074b6341dc220  vmovaps xmm1, [rsp+0x60]
000074b6341dc226  vpermilpd xmm1, xmm1, 0x00
000074b6341dc22c  vmovaps [rsp+0xB0], xmm1
000074b6341dc235  vmovaps xmm1, [rsp+0x80]
000074b6341dc23e  vmovaps [rsp+0x80], xmm15
000074b6341dc247  vmovaps xmm15, [rsp+0xB0]
000074b6341dc250  vmovaps [rsp+0xB0], xmm14
000074b6341dc259  movaps xmm3, xmm1
000074b6341dc25c  mulpd xmm3, xmm15
000074b6341dc261  vcmppd xmm14, xmm3, xmm3, 0x03
000074b6341dc266  ptest xmm14, xmm14
000074b6341dc26c  jnz 0x000074B6341DE924
000074b6341dc272  lea r12, [rax+0x20]
000074b6341dc276  movups xmm1, [r13+r12*1]
000074b6341dc27c  movaps [r15+0x110], xmm1
000074b6341dc284  vmovaps xmm14, [rsp+0x70]
000074b6341dc28a  vmovaps [rsp+0x70], xmm1
000074b6341dc290  movaps xmm15, xmm14
000074b6341dc294  addpd xmm15, xmm4
000074b6341dc299  vcmppd xmm1, xmm15, xmm15, 0x03
000074b6341dc29f  ptest xmm1, xmm1
000074b6341dc2a4  jnz 0x000074B6341DEA6F
000074b6341dc2aa  vmovaps xmm1, [rsp+0x60]
000074b6341dc2b0  vpermilpd xmm1, xmm1, 0x00
000074b6341dc2b6  movaps xmm14, xmm2
000074b6341dc2ba  mulpd xmm14, xmm1
000074b6341dc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
000074b6341dc2c5  ptest xmm4, xmm4
000074b6341dc2ca  jnz 0x000074B6341DEBB2
000074b6341dc2d0  vmovaps xmm4, [rsp+0x50]
000074b6341dc2d6  movaps xmm1, xmm4
000074b6341dc2d9  addpd xmm1, xmm9
000074b6341dc2de  vcmppd xmm2, xmm1, xmm1, 0x03
000074b6341dc2e3  ptest xmm2, xmm2
000074b6341dc2e8  jnz 0x000074B6341DECF4
000074b6341dc2ee  vmovaps xmm9, [rsp+0x30]
000074b6341dc2f4  vpermilpd xmm9, xmm9, 0x00
000074b6341dc2fa  vmovaps xmm2, [rsp+0x70]
000074b6341dc300  vmovaps [rsp+0x50], xmm1
000074b6341dc306  movaps xmm4, xmm2
000074b6341dc309  mulpd xmm4, xmm9
000074b6341dc30e  vcmppd xmm1, xmm4, xmm4, 0x03
000074b6341dc313  ptest xmm1, xmm1
000074b6341dc318  jnz 0x000074B6341DEE35
000074b6341dc31e  vmovaps xmm1, [rsp+0x30]
000074b6341dc324  vpermilpd xmm1, xmm1, 0x00
000074b6341dc32a  vmovaps xmm2, [rsp+0x90]
000074b6341dc333  vmovaps [rsp+0x60], xmm15
000074b6341dc339  movaps xmm9, xmm2
000074b6341dc33d  mulpd xmm9, xmm1
000074b6341dc342  vcmppd xmm15, xmm9, xmm9, 0x03
000074b6341dc348  ptest xmm15, xmm15
000074b6341dc34e  jnz 0x000074B6341DEF76
000074b6341dc354  vmovaps xmm15, [rsp+0x80]
000074b6341dc35d  movaps xmm1, xmm15
000074b6341dc361  addpd xmm1, xmm6
000074b6341dc365  vcmppd xmm2, xmm1, xmm1, 0x03
000074b6341dc36a  ptest xmm2, xmm2
000074b6341dc36f  jnz 0x000074B6341DF0B8
000074b6341dc375  movaps xmm15, xmm5
000074b6341dc379  addpd xmm15, xmm3
000074b6341dc37e  vcmppd xmm6, xmm15, xmm15, 0x03
000074b6341dc384  ptest xmm6, xmm6
000074b6341dc389  jnz 0x000074B6341DF1F9
000074b6341dc38f  vmovaps xmm6, [rsp+0x30]
000074b6341dc395  vpermilpd xmm6, xmm6, 0x00
000074b6341dc39b  movaps xmm5, xmm8
000074b6341dc39f  mulpd xmm5, xmm6
000074b6341dc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
000074b6341dc3a8  ptest xmm3, xmm3
000074b6341dc3ad  jnz 0x000074B6341DF33B
000074b6341dc3b3  vmovaps xmm8, [rsp+0x30]
000074b6341dc3b9  vpermilpd xmm8, xmm8, 0x00
000074b6341dc3bf  movaps xmm6, xmm10
000074b6341dc3c3  mulpd xmm6, xmm8
000074b6341dc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
000074b6341dc3cd  ptest xmm3, xmm3
000074b6341dc3d2  jnz 0x000074B6341DF47C
000074b6341dc3d8  vmovaps xmm8, [rsp+0x60]
000074b6341dc3de  movaps xmm10, xmm8
000074b6341dc3e2  addpd xmm10, xmm14
000074b6341dc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
000074b6341dc3ed  ptest xmm3, xmm3
000074b6341dc3f2  jnz 0x000074B6341DF5BE
000074b6341dc3f8  vmovaps xmm8, [rsp+0x50]
000074b6341dc3fe  movaps xmm14, xmm8
000074b6341dc402  addpd xmm14, xmm4
000074b6341dc407  vcmppd xmm3, xmm14, xmm14, 0x03
000074b6341dc40d  ptest xmm3, xmm3
000074b6341dc412  jnz 0x000074B6341DF702
000074b6341dc418  vmovaps xmm8, [rsp+0x40]
000074b6341dc41e  vpermilpd xmm8, xmm8, 0x00
000074b6341dc424  movaps xmm4, xmm13
000074b6341dc428  mulpd xmm4, xmm8
000074b6341dc42d  vcmppd xmm3, xmm4, xmm4, 0x03
000074b6341dc432  ptest xmm3, xmm3
000074b6341dc437  jnz 0x000074B6341DF845
000074b6341dc43d  movaps xmm13, xmm15
000074b6341dc441  addpd xmm13, xmm9
000074b6341dc446  vcmppd xmm8, xmm13, xmm13, 0x03
000074b6341dc44c  ptest xmm8, xmm8
000074b6341dc452  jnz 0x000074B6341DF987
000074b6341dc458  movaps xmm15, xmm1
000074b6341dc45c  addpd xmm15, xmm5
000074b6341dc461  vcmppd xmm9, xmm15, xmm15, 0x03
000074b6341dc467  ptest xmm9, xmm9
000074b6341dc46d  jnz 0x000074B6341DFACB
000074b6341dc473  vmovaps [rsp+0x30], xmm11
000074b6341dc479  vmovaps xmm1, [rsp+0x30]
000074b6341dc47f  por xmm11, xmm1
000074b6341dc484  movaps [r15+0x250], xmm11
000074b6341dc48c  vmovaps [rsp+0x30], xmm12
000074b6341dc492  vmovaps xmm1, [rsp+0x30]
000074b6341dc498  por xmm12, xmm1
000074b6341dc49d  movaps [r15+0x2A0], xmm12
000074b6341dc4a5  vmovaps xmm1, [rsp+0xA0]
000074b6341dc4ae  vmovaps xmm11, [rsp+0xA0]
000074b6341dc4b7  por xmm1, xmm11
000074b6341dc4bc  movaps [r15+0x1D0], xmm1
000074b6341dc4c4  lea r12, [rax+0x40]
000074b6341dc4c8  movups xmm1, [r13+r12*1]
000074b6341dc4ce  movaps [r15+0x2C0], xmm1
000074b6341dc4d6  vmovaps xmm11, [rsp+0x40]
000074b6341dc4dc  vpermilpd xmm11, xmm11, 0x00
000074b6341dc4e2  vmovaps xmm8, [rsp+0xE0]
000074b6341dc4eb  movaps xmm9, xmm8
000074b6341dc4ef  mulpd xmm9, xmm11
000074b6341dc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
000074b6341dc4fa  ptest xmm5, xmm5
000074b6341dc4ff  jnz 0x000074B6341DFC17
000074b6341dc505  movaps xmm11, xmm10
000074b6341dc509  addpd xmm11, xmm6
000074b6341dc50e  vcmppd xmm8, xmm11, xmm11, 0x03
000074b6341dc514  ptest xmm8, xmm8
000074b6341dc51a  jnz 0x000074B6341DFD5B
000074b6341dc520  movaps xmm10, xmm14
000074b6341dc524  addpd xmm10, xmm4
000074b6341dc529  vcmppd xmm8, xmm10, xmm10, 0x03
000074b6341dc52f  ptest xmm8, xmm8
000074b6341dc535  jnz 0x000074B6341DFE9E
000074b6341dc53b  vmovaps xmm14, [rsp+0x40]
000074b6341dc541  vpermilpd xmm14, xmm14, 0x00
000074b6341dc547  movaps xmm8, xmm1
000074b6341dc54b  mulpd xmm8, xmm14
000074b6341dc550  vcmppd xmm6, xmm8, xmm8, 0x03
000074b6341dc556  ptest xmm6, xmm6
000074b6341dc55b  jnz 0x000074B6341DFFE1
000074b6341dc561  movaps xmm1, [r15+0x2B0]
000074b6341dc569  vmovaps xmm14, [rsp+0x40]
000074b6341dc56f  vpermilpd xmm14, xmm14, 0x00
000074b6341dc575  movaps xmm6, xmm1
000074b6341dc578  mulpd xmm6, xmm14
000074b6341dc57d  vcmppd xmm5, xmm6, xmm6, 0x03
000074b6341dc582  ptest xmm5, xmm5
000074b6341dc587  jnz 0x000074B6341E0124
000074b6341dc58d  vmovaps xmm1, [rsp+0x10]
000074b6341dc593  vpermilpd xmm1, xmm1, 0x00
000074b6341dc599  movaps xmm14, xmm12
000074b6341dc59d  mulpd xmm14, xmm1
000074b6341dc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
000074b6341dc5a8  ptest xmm5, xmm5
000074b6341dc5ad  jnz 0x000074B6341E0265
000074b6341dc5b3  movaps xmm1, xmm13
000074b6341dc5b7  addpd xmm1, xmm9
000074b6341dc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
000074b6341dc5c1  ptest xmm12, xmm12
000074b6341dc5c7  jnz 0x000074B6341E03A8
000074b6341dc5cd  vmovaps xmm13, [rsp+0x10]
000074b6341dc5d3  vpermilpd xmm13, xmm13, 0x00
000074b6341dc5d9  movaps xmm12, xmm7
000074b6341dc5dd  mulpd xmm12, xmm13
000074b6341dc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
000074b6341dc5e8  ptest xmm9, xmm9
000074b6341dc5ee  jnz 0x000074B6341E04EA
000074b6341dc5f4  movaps xmm13, xmm15
000074b6341dc5f8  addpd xmm13, xmm8
000074b6341dc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
000074b6341dc603  ptest xmm9, xmm9
000074b6341dc609  jnz 0x000074B6341E062D
000074b6341dc60f  movaps xmm15, [r15+0x290]
000074b6341dc617  vmovaps xmm9, [rsp+0x10]
000074b6341dc61d  vpermilpd xmm9, xmm9, 0x00
000074b6341dc623  movaps xmm8, xmm15
000074b6341dc627  mulpd xmm8, xmm9
000074b6341dc62c  vcmppd xmm7, xmm8, xmm8, 0x03
000074b6341dc632  ptest xmm7, xmm7
000074b6341dc637  jnz 0x000074B6341E0771
000074b6341dc63d  movaps xmm15, xmm11
000074b6341dc641  addpd xmm15, xmm6
000074b6341dc646  vcmppd xmm9, xmm15, xmm15, 0x03
000074b6341dc64c  ptest xmm9, xmm9
000074b6341dc652  jnz 0x000074B6341E08B5
000074b6341dc658  movaps xmm11, [r15+0x1E0]
000074b6341dc660  vmovaps xmm9, [rsp+0x10]
000074b6341dc666  vpermilpd xmm9, xmm9, 0x00
000074b6341dc66c  movaps xmm7, xmm11
000074b6341dc670  mulpd xmm7, xmm9
000074b6341dc675  vcmppd xmm6, xmm7, xmm7, 0x03
000074b6341dc67a  ptest xmm6, xmm6
000074b6341dc67f  jnz 0x000074B6341E09F8
000074b6341dc685  movaps xmm11, xmm10
000074b6341dc689  addpd xmm11, xmm14
000074b6341dc68e  vcmppd xmm9, xmm11, xmm11, 0x03
000074b6341dc694  ptest xmm9, xmm9
000074b6341dc69a  jnz 0x000074B6341E0B3A
000074b6341dc6a0  lea r12, [rax+0x70]
000074b6341dc6a4  movups xmm14, [r13+r12*1]
000074b6341dc6aa  movaps [r15+0x240], xmm14
000074b6341dc6b2  movaps xmm10, xmm1
000074b6341dc6b6  addpd xmm10, xmm12
000074b6341dc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
000074b6341dc6c1  ptest xmm9, xmm9
000074b6341dc6c7  jnz 0x000074B6341E0C88
000074b6341dc6cd  movaps [r15+0x170], xmm10
000074b6341dc6d5  vmovaps xmm1, [rsp+0x20]
000074b6341dc6db  vpermilpd xmm1, xmm1, 0x00
000074b6341dc6e1  movaps xmm12, xmm14
000074b6341dc6e5  mulpd xmm12, xmm1
000074b6341dc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
000074b6341dc6f0  ptest xmm9, xmm9
000074b6341dc6f6  jnz 0x000074B6341E0DCB
000074b6341dc6fc  vmovaps xmm1, [rsp+0x20]
000074b6341dc702  vpermilpd xmm1, xmm1, 0x00
000074b6341dc708  vmovaps xmm9, [rsp+0xB0]
000074b6341dc711  movaps xmm14, xmm9
000074b6341dc715  mulpd xmm14, xmm1
000074b6341dc71a  vcmppd xmm6, xmm14, xmm14, 0x03
000074b6341dc720  ptest xmm6, xmm6
000074b6341dc725  jnz 0x000074B6341E0F0E
000074b6341dc72b  movaps [r15+0x180], xmm14
000074b6341dc733  movaps xmm1, xmm13
000074b6341dc737  addpd xmm1, xmm8
000074b6341dc73c  vcmppd xmm9, xmm1, xmm1, 0x03
000074b6341dc741  ptest xmm9, xmm9
000074b6341dc747  jnz 0x000074B6341E1051
000074b6341dc74d  movaps [r15+0x210], xmm1
000074b6341dc755  movups xmm13, [r13+rax*1]
000074b6341dc75b  lea r12, [rax+0x10]
000074b6341dc75f  movups xmm9, [r13+r12*1]
000074b6341dc765  movaps [r15+0x230], xmm9
000074b6341dc76d  movaps xmm8, xmm15
000074b6341dc771  addpd xmm8, xmm7
000074b6341dc776  vcmppd xmm6, xmm8, xmm8, 0x03
000074b6341dc77c  ptest xmm6, xmm6
000074b6341dc781  jnz 0x000074B6341E11A7
000074b6341dc787  movaps [r15+0x130], xmm8
000074b6341dc78f  vmovaps xmm15, [rsp+0x20]
000074b6341dc795  vpermilpd xmm15, xmm15, 0x00
000074b6341dc79b  movaps xmm7, xmm9
000074b6341dc79f  mulpd xmm7, xmm15
000074b6341dc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
000074b6341dc7a9  ptest xmm6, xmm6
000074b6341dc7ae  jnz 0x000074B6341E12EA
000074b6341dc7b4  movaps [r15+0x220], xmm7
000074b6341dc7bc  vmovaps xmm15, [rsp+0x20]
000074b6341dc7c2  vpermilpd xmm15, xmm15, 0x00
000074b6341dc7c8  movaps xmm9, xmm13
000074b6341dc7cc  mulpd xmm9, xmm15
000074b6341dc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
000074b6341dc7d7  ptest xmm6, xmm6
000074b6341dc7dc  jnz 0x000074B6341E142C
000074b6341dc7e2  movaps xmm15, xmm11
000074b6341dc7e6  addpd xmm15, xmm12
000074b6341dc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
000074b6341dc7f1  ptest xmm13, xmm13
000074b6341dc7f7  jnz 0x000074B6341E1570
000074b6341dc7fd  movaps [r15+0x140], xmm15
000074b6341dc805  movaps xmm13, xmm10
000074b6341dc809  addpd xmm13, xmm14
000074b6341dc80e  vcmppd xmm12, xmm13, xmm13, 0x03
000074b6341dc814  ptest xmm12, xmm12
000074b6341dc81a  jnz 0x000074B6341E16B4
000074b6341dc820  movaps [r15+0x150], xmm13
000074b6341dc828  movaps xmm14, xmm1
000074b6341dc82c  addpd xmm14, xmm7
000074b6341dc831  vcmppd xmm12, xmm14, xmm14, 0x03
000074b6341dc837  ptest xmm12, xmm12
000074b6341dc83d  jnz 0x000074B6341E17F8
000074b6341dc843  movaps [r15+0x160], xmm14
000074b6341dc84b  movaps xmm1, xmm8
000074b6341dc84f  addpd xmm1, xmm9
000074b6341dc854  vcmppd xmm12, xmm1, xmm1, 0x03
000074b6341dc859  ptest xmm12, xmm12
000074b6341dc85f  jnz 0x000074B6341E193A
000074b6341dc865  movaps [r15+0x120], xmm1
000074b6341dc86d  movups [r13+r14*1], xmm15
000074b6341dc873  lea rax, [r14+0x10]
000074b6341dc877  movups [r13+rax*1], xmm13
000074b6341dc87d  lea rax, [r14+0x20]
000074b6341dc881  movups [r13+rax*1], xmm14
000074b6341dc887  lea rax, [r14+0x30]
000074b6341dc88b  movups [r13+rax*1], xmm1
000074b6341dc891  mov eax, [r15+0x108]
000074b6341dc898  sahf
000074b6341dc899  jnz 0x000074B6341DC8CB
000074b6341dc89b  cmp dword ptr [r15+0x318], 0x00
000074b6341dc8a3  jz 0x000074B6341DB900
000074b6341dc8a9  nop [rax+rax*1], ax
000074b6341dc8b2  nop [rax+rax*1], eax
000074b6341dc8ba  mov eax, 0x410444
000074b6341dc8bf  mov [r15+0x100], rax
000074b6341dc8c6  jmp 0x000074B633FFE110
000074b6341dc8cb  cmp dword ptr [r15+0x318], 0x00
000074b6341dc8d3  jz 0x000074B6341D57E0
000074b6341dc8d9  nop [rax+rax*1], ax
000074b6341dc8e2  nop [rax+rax*1], eax
000074b6341dc8ea  mov eax, 0x410278
000074b6341dc8ef  mov [r15+0x100], rax
000074b6341dc8f6  jmp 0x000074B633FFE110
000074b6341dc8fb  int3
000074b6341dc8fc  call 0x000074B6340E27E0
000074b6341dc901  jmp 0x000074B6341DB9DF
000074b6341dc906  call 0x000074B6340E1570
000074b6341dc90b  jmp 0x000074B6341DB9E8
000074b6341dc910  call 0x000074B6340E27E0
000074b6341dc915  jmp 0x000074B6341DBA44
000074b6341dc91a  call 0x000074B6340E1570
000074b6341dc91f  jmp 0x000074B6341DBA4D
000074b6341dc924  call 0x000074B6340E27E0
000074b6341dc929  jmp 0x000074B6341DBA90
000074b6341dc92e  call 0x000074B6340E1570
000074b6341dc933  jmp 0x000074B6341DBA99
000074b6341dc938  call 0x000074B63400DC20
000074b6341dc93d  jmp 0x000074B6341DBAD8
000074b6341dc942  call 0x000074B6340D59C0
000074b6341dc947  jmp 0x000074B6341DBAEB
000074b6341dc94c  call 0x000074B6340E0E30
000074b6341dc951  jmp 0x000074B6341DBB09
000074b6341dc956  call 0x000074B6340DFBC0
000074b6341dc95b  jmp 0x000074B6341DBB13
000074b6341dc960  call 0x000074B6340DE950
000074b6341dc965  jmp 0x000074B6341DBB1D
000074b6341dc96a  sub rsp, 0x08
000074b6341dc96e  push rax
000074b6341dc96f  push rcx
000074b6341dc970  push rdx
000074b6341dc971  push rdi
000074b6341dc972  push rsi
000074b6341dc973  push r8
000074b6341dc975  push r9
000074b6341dc977  push r10
000074b6341dc979  push r11
000074b6341dc97b  sub rsp, 0xF0
000074b6341dc982  vmovaps [rsp], xmm0
000074b6341dc987  vmovaps [rsp+0x10], xmm1
000074b6341dc98d  vmovaps [rsp+0x20], xmm2
000074b6341dc993  vmovaps [rsp+0x30], xmm3
000074b6341dc999  vmovaps [rsp+0x40], xmm4
000074b6341dc99f  vmovaps [rsp+0x50], xmm5
000074b6341dc9a5  vmovaps [rsp+0x60], xmm6
000074b6341dc9ab  vmovaps [rsp+0x70], xmm7
000074b6341dc9b1  vmovaps [rsp+0x80], xmm9
000074b6341dc9ba  vmovaps [rsp+0x90], xmm10
000074b6341dc9c3  vmovaps [rsp+0xA0], xmm11
000074b6341dc9cc  vmovaps [rsp+0xB0], xmm12
000074b6341dc9d5  vmovaps [rsp+0xC0], xmm13
000074b6341dc9de  vmovaps [rsp+0xD0], xmm14
000074b6341dc9e7  vmovaps [rsp+0xE0], xmm15
000074b6341dc9f0  sub rsp, 0x30
000074b6341dc9f4  movaps [rsp], xmm8
000074b6341dc9f9  movaps [rsp+0x10], xmm12
000074b6341dc9ff  movaps [rsp+0x20], xmm15
000074b6341dca05  lea rdi, [rsp]
000074b6341dca09  mov esi, 0x00
000074b6341dca0e  mov rax, 0x5E1AA0A2F530
000074b6341dca18  call rax
000074b6341dca1a  movaps xmm8, [rsp]
000074b6341dca1f  add rsp, 0x30
000074b6341dca23  vmovaps xmm0, [rsp]
000074b6341dca28  vmovaps xmm1, [rsp+0x10]
000074b6341dca2e  vmovaps xmm2, [rsp+0x20]
000074b6341dca34  vmovaps xmm3, [rsp+0x30]
000074b6341dca3a  vmovaps xmm4, [rsp+0x40]
000074b6341dca40  vmovaps xmm5, [rsp+0x50]
000074b6341dca46  vmovaps xmm6, [rsp+0x60]
000074b6341dca4c  vmovaps xmm7, [rsp+0x70]
000074b6341dca52  vmovaps xmm9, [rsp+0x80]
000074b6341dca5b  vmovaps xmm10, [rsp+0x90]
000074b6341dca64  vmovaps xmm11, [rsp+0xA0]
000074b6341dca6d  vmovaps xmm12, [rsp+0xB0]
000074b6341dca76  vmovaps xmm13, [rsp+0xC0]
000074b6341dca7f  vmovaps xmm14, [rsp+0xD0]
000074b6341dca88  vmovaps xmm15, [rsp+0xE0]
000074b6341dca91  add rsp, 0xF0
000074b6341dca98  pop r11
000074b6341dca9a  pop r10
000074b6341dca9c  pop r9
000074b6341dca9e  pop r8
000074b6341dcaa0  pop rsi
000074b6341dcaa1  pop rdi
000074b6341dcaa2  pop rdx
000074b6341dcaa3  pop rcx
000074b6341dcaa4  pop rax
000074b6341dcaa5  add rsp, 0x08
000074b6341dcaa9  jmp 0x000074B6341DBB47
000074b6341dcaae  sub rsp, 0x08
000074b6341dcab2  push rax
000074b6341dcab3  push rcx
000074b6341dcab4  push rdx
000074b6341dcab5  push rdi
000074b6341dcab6  push rsi
000074b6341dcab7  push r8
000074b6341dcab9  push r9
000074b6341dcabb  push r10
000074b6341dcabd  push r11
000074b6341dcabf  sub rsp, 0xF0
000074b6341dcac6  vmovaps [rsp], xmm0
000074b6341dcacb  vmovaps [rsp+0x10], xmm1
000074b6341dcad1  vmovaps [rsp+0x20], xmm2
000074b6341dcad7  vmovaps [rsp+0x30], xmm3
000074b6341dcadd  vmovaps [rsp+0x40], xmm4
000074b6341dcae3  vmovaps [rsp+0x50], xmm5
000074b6341dcae9  vmovaps [rsp+0x60], xmm6
000074b6341dcaef  vmovaps [rsp+0x70], xmm8
000074b6341dcaf5  vmovaps [rsp+0x80], xmm9
000074b6341dcafe  vmovaps [rsp+0x90], xmm10
000074b6341dcb07  vmovaps [rsp+0xA0], xmm11
000074b6341dcb10  vmovaps [rsp+0xB0], xmm12
000074b6341dcb19  vmovaps [rsp+0xC0], xmm13
000074b6341dcb22  vmovaps [rsp+0xD0], xmm14
000074b6341dcb2b  vmovaps [rsp+0xE0], xmm15
000074b6341dcb34  sub rsp, 0x30
000074b6341dcb38  movaps [rsp], xmm7
000074b6341dcb3c  movaps [rsp+0x10], xmm9
000074b6341dcb42  movaps [rsp+0x20], xmm15
000074b6341dcb48  lea rdi, [rsp]
000074b6341dcb4c  mov esi, 0x00
000074b6341dcb51  mov rax, 0x5E1AA0A2F530
000074b6341dcb5b  call rax
000074b6341dcb5d  movaps xmm7, [rsp]
000074b6341dcb61  add rsp, 0x30
000074b6341dcb65  vmovaps xmm0, [rsp]
000074b6341dcb6a  vmovaps xmm1, [rsp+0x10]
000074b6341dcb70  vmovaps xmm2, [rsp+0x20]
000074b6341dcb76  vmovaps xmm3, [rsp+0x30]
000074b6341dcb7c  vmovaps xmm4, [rsp+0x40]
000074b6341dcb82  vmovaps xmm5, [rsp+0x50]
000074b6341dcb88  vmovaps xmm6, [rsp+0x60]
000074b6341dcb8e  vmovaps xmm8, [rsp+0x70]
000074b6341dcb94  vmovaps xmm9, [rsp+0x80]
000074b6341dcb9d  vmovaps xmm10, [rsp+0x90]
000074b6341dcba6  vmovaps xmm11, [rsp+0xA0]
000074b6341dcbaf  vmovaps xmm12, [rsp+0xB0]
000074b6341dcbb8  vmovaps xmm13, [rsp+0xC0]
000074b6341dcbc1  vmovaps xmm14, [rsp+0xD0]
000074b6341dcbca  vmovaps xmm15, [rsp+0xE0]
000074b6341dcbd3  add rsp, 0xF0
000074b6341dcbda  pop r11
000074b6341dcbdc  pop r10
000074b6341dcbde  pop r9
000074b6341dcbe0  pop r8
000074b6341dcbe2  pop rsi
000074b6341dcbe3  pop rdi
000074b6341dcbe4  pop rdx
000074b6341dcbe5  pop rcx
000074b6341dcbe6  pop rax
000074b6341dcbe7  add rsp, 0x08
000074b6341dcbeb  jmp 0x000074B6341DBB75
000074b6341dcbf0  sub rsp, 0x08
000074b6341dcbf4  push rax
000074b6341dcbf5  push rcx
000074b6341dcbf6  push rdx
000074b6341dcbf7  push rdi
000074b6341dcbf8  push rsi
000074b6341dcbf9  push r8
000074b6341dcbfb  push r9
000074b6341dcbfd  push r10
000074b6341dcbff  push r11
000074b6341dcc01  sub rsp, 0xF0
000074b6341dcc08  vmovaps [rsp], xmm0
000074b6341dcc0d  vmovaps [rsp+0x10], xmm1
000074b6341dcc13  vmovaps [rsp+0x20], xmm2
000074b6341dcc19  vmovaps [rsp+0x30], xmm3
000074b6341dcc1f  vmovaps [rsp+0x40], xmm4
000074b6341dcc25  vmovaps [rsp+0x50], xmm5
000074b6341dcc2b  vmovaps [rsp+0x60], xmm6
000074b6341dcc31  vmovaps [rsp+0x70], xmm7
000074b6341dcc37  vmovaps [rsp+0x80], xmm8
000074b6341dcc40  vmovaps [rsp+0x90], xmm10
000074b6341dcc49  vmovaps [rsp+0xA0], xmm11
000074b6341dcc52  vmovaps [rsp+0xB0], xmm12
000074b6341dcc5b  vmovaps [rsp+0xC0], xmm13
000074b6341dcc64  vmovaps [rsp+0xD0], xmm14
000074b6341dcc6d  vmovaps [rsp+0xE0], xmm15
000074b6341dcc76  sub rsp, 0x30
000074b6341dcc7a  movaps [rsp], xmm9
000074b6341dcc7f  movaps [rsp+0x10], xmm12
000074b6341dcc85  movaps [rsp+0x20], xmm10
000074b6341dcc8b  lea rdi, [rsp]
000074b6341dcc8f  mov esi, 0x00
000074b6341dcc94  mov rax, 0x5E1AA0A2F530
000074b6341dcc9e  call rax
000074b6341dcca0  movaps xmm9, [rsp]
000074b6341dcca5  add rsp, 0x30
000074b6341dcca9  vmovaps xmm0, [rsp]
000074b6341dccae  vmovaps xmm1, [rsp+0x10]
000074b6341dccb4  vmovaps xmm2, [rsp+0x20]
000074b6341dccba  vmovaps xmm3, [rsp+0x30]
000074b6341dccc0  vmovaps xmm4, [rsp+0x40]
000074b6341dccc6  vmovaps xmm5, [rsp+0x50]
000074b6341dcccc  vmovaps xmm6, [rsp+0x60]
000074b6341dccd2  vmovaps xmm7, [rsp+0x70]
000074b6341dccd8  vmovaps xmm8, [rsp+0x80]
000074b6341dcce1  vmovaps xmm10, [rsp+0x90]
000074b6341dccea  vmovaps xmm11, [rsp+0xA0]
000074b6341dccf3  vmovaps xmm12, [rsp+0xB0]
000074b6341dccfc  vmovaps xmm13, [rsp+0xC0]
000074b6341dcd05  vmovaps xmm14, [rsp+0xD0]
000074b6341dcd0e  vmovaps xmm15, [rsp+0xE0]
000074b6341dcd17  add rsp, 0xF0
000074b6341dcd1e  pop r11
000074b6341dcd20  pop r10
000074b6341dcd22  pop r9
000074b6341dcd24  pop r8
000074b6341dcd26  pop rsi
000074b6341dcd27  pop rdi
000074b6341dcd28  pop rdx
000074b6341dcd29  pop rcx
000074b6341dcd2a  pop rax
000074b6341dcd2b  add rsp, 0x08
000074b6341dcd2f  jmp 0x000074B6341DBB99
000074b6341dcd34  sub rsp, 0x08
000074b6341dcd38  push rax
000074b6341dcd39  push rcx
000074b6341dcd3a  push rdx
000074b6341dcd3b  push rdi
000074b6341dcd3c  push rsi
000074b6341dcd3d  push r8
000074b6341dcd3f  push r9
000074b6341dcd41  push r10
000074b6341dcd43  push r11
000074b6341dcd45  sub rsp, 0xF0
000074b6341dcd4c  vmovaps [rsp], xmm0
000074b6341dcd51  vmovaps [rsp+0x10], xmm1
000074b6341dcd57  vmovaps [rsp+0x20], xmm2
000074b6341dcd5d  vmovaps [rsp+0x30], xmm3
000074b6341dcd63  vmovaps [rsp+0x40], xmm4
000074b6341dcd69  vmovaps [rsp+0x50], xmm5
000074b6341dcd6f  vmovaps [rsp+0x60], xmm6
000074b6341dcd75  vmovaps [rsp+0x70], xmm7
000074b6341dcd7b  vmovaps [rsp+0x80], xmm8
000074b6341dcd84  vmovaps [rsp+0x90], xmm9
000074b6341dcd8d  vmovaps [rsp+0xA0], xmm11
000074b6341dcd96  vmovaps [rsp+0xB0], xmm12
000074b6341dcd9f  vmovaps [rsp+0xC0], xmm13
000074b6341dcda8  vmovaps [rsp+0xD0], xmm14
000074b6341dcdb1  vmovaps [rsp+0xE0], xmm15
000074b6341dcdba  sub rsp, 0x30
000074b6341dcdbe  movaps [rsp], xmm10
000074b6341dcdc3  movaps [rsp+0x10], xmm12
000074b6341dcdc9  movaps [rsp+0x20], xmm11
000074b6341dcdcf  lea rdi, [rsp]
000074b6341dcdd3  mov esi, 0x00
000074b6341dcdd8  mov rax, 0x5E1AA0A2F530
000074b6341dcde2  call rax
000074b6341dcde4  movaps xmm10, [rsp]
000074b6341dcde9  add rsp, 0x30
000074b6341dcded  vmovaps xmm0, [rsp]
000074b6341dcdf2  vmovaps xmm1, [rsp+0x10]
000074b6341dcdf8  vmovaps xmm2, [rsp+0x20]
000074b6341dcdfe  vmovaps xmm3, [rsp+0x30]
000074b6341dce04  vmovaps xmm4, [rsp+0x40]
000074b6341dce0a  vmovaps xmm5, [rsp+0x50]
000074b6341dce10  vmovaps xmm6, [rsp+0x60]
000074b6341dce16  vmovaps xmm7, [rsp+0x70]
000074b6341dce1c  vmovaps xmm8, [rsp+0x80]
000074b6341dce25  vmovaps xmm9, [rsp+0x90]
000074b6341dce2e  vmovaps xmm11, [rsp+0xA0]
000074b6341dce37  vmovaps xmm12, [rsp+0xB0]
000074b6341dce40  vmovaps xmm13, [rsp+0xC0]
000074b6341dce49  vmovaps xmm14, [rsp+0xD0]
000074b6341dce52  vmovaps xmm15, [rsp+0xE0]
000074b6341dce5b  add rsp, 0xF0
000074b6341dce62  pop r11
000074b6341dce64  pop r10
000074b6341dce66  pop r9
000074b6341dce68  pop r8
000074b6341dce6a  pop rsi
000074b6341dce6b  pop rdi
000074b6341dce6c  pop rdx
000074b6341dce6d  pop rcx
000074b6341dce6e  pop rax
000074b6341dce6f  add rsp, 0x08
000074b6341dce73  jmp 0x000074B6341DBBB3
000074b6341dce78  sub rsp, 0x08
000074b6341dce7c  push rax
000074b6341dce7d  push rcx
000074b6341dce7e  push rdx
000074b6341dce7f  push rdi
000074b6341dce80  push rsi
000074b6341dce81  push r8
000074b6341dce83  push r9
000074b6341dce85  push r10
000074b6341dce87  push r11
000074b6341dce89  sub rsp, 0xF0
000074b6341dce90  vmovaps [rsp], xmm0
000074b6341dce95  vmovaps [rsp+0x10], xmm1
000074b6341dce9b  vmovaps [rsp+0x20], xmm2
000074b6341dcea1  vmovaps [rsp+0x30], xmm3
000074b6341dcea7  vmovaps [rsp+0x40], xmm4
000074b6341dcead  vmovaps [rsp+0x50], xmm5
000074b6341dceb3  vmovaps [rsp+0x60], xmm7
000074b6341dceb9  vmovaps [rsp+0x70], xmm8
000074b6341dcebf  vmovaps [rsp+0x80], xmm9
000074b6341dcec8  vmovaps [rsp+0x90], xmm10
000074b6341dced1  vmovaps [rsp+0xA0], xmm11
000074b6341dceda  vmovaps [rsp+0xB0], xmm12
000074b6341dcee3  vmovaps [rsp+0xC0], xmm13
000074b6341dceec  vmovaps [rsp+0xD0], xmm14
000074b6341dcef5  vmovaps [rsp+0xE0], xmm15
000074b6341dcefe  sub rsp, 0x30
000074b6341dcf02  movaps [rsp], xmm6
000074b6341dcf06  movaps [rsp+0x10], xmm12
000074b6341dcf0c  movaps [rsp+0x20], xmm11
000074b6341dcf12  lea rdi, [rsp]
000074b6341dcf16  mov esi, 0x00
000074b6341dcf1b  mov rax, 0x5E1AA0A2F530
000074b6341dcf25  call rax
000074b6341dcf27  movaps xmm6, [rsp]
000074b6341dcf2b  add rsp, 0x30
000074b6341dcf2f  vmovaps xmm0, [rsp]
000074b6341dcf34  vmovaps xmm1, [rsp+0x10]
000074b6341dcf3a  vmovaps xmm2, [rsp+0x20]
000074b6341dcf40  vmovaps xmm3, [rsp+0x30]
000074b6341dcf46  vmovaps xmm4, [rsp+0x40]
000074b6341dcf4c  vmovaps xmm5, [rsp+0x50]
000074b6341dcf52  vmovaps xmm7, [rsp+0x60]
000074b6341dcf58  vmovaps xmm8, [rsp+0x70]
000074b6341dcf5e  vmovaps xmm9, [rsp+0x80]
000074b6341dcf67  vmovaps xmm10, [rsp+0x90]
000074b6341dcf70  vmovaps xmm11, [rsp+0xA0]
000074b6341dcf79  vmovaps xmm12, [rsp+0xB0]
000074b6341dcf82  vmovaps xmm13, [rsp+0xC0]
000074b6341dcf8b  vmovaps xmm14, [rsp+0xD0]
000074b6341dcf94  vmovaps xmm15, [rsp+0xE0]
000074b6341dcf9d  add rsp, 0xF0
000074b6341dcfa4  pop r11
000074b6341dcfa6  pop r10
000074b6341dcfa8  pop r9
000074b6341dcfaa  pop r8
000074b6341dcfac  pop rsi
000074b6341dcfad  pop rdi
000074b6341dcfae  pop rdx
000074b6341dcfaf  pop rcx
000074b6341dcfb0  pop rax
000074b6341dcfb1  add rsp, 0x08
000074b6341dcfb5  jmp 0x000074B6341DBBD4
000074b6341dcfba  sub rsp, 0x08
000074b6341dcfbe  push rax
000074b6341dcfbf  push rcx
000074b6341dcfc0  push rdx
000074b6341dcfc1  push rdi
000074b6341dcfc2  push rsi
000074b6341dcfc3  push r8
000074b6341dcfc5  push r9
000074b6341dcfc7  push r10
000074b6341dcfc9  push r11
000074b6341dcfcb  sub rsp, 0xF0
000074b6341dcfd2  vmovaps [rsp], xmm0
000074b6341dcfd7  vmovaps [rsp+0x10], xmm1
000074b6341dcfdd  vmovaps [rsp+0x20], xmm2
000074b6341dcfe3  vmovaps [rsp+0x30], xmm4
000074b6341dcfe9  vmovaps [rsp+0x40], xmm5
000074b6341dcfef  vmovaps [rsp+0x50], xmm6
000074b6341dcff5  vmovaps [rsp+0x60], xmm7
000074b6341dcffb  vmovaps [rsp+0x70], xmm8
000074b6341dd001  vmovaps [rsp+0x80], xmm9
000074b6341dd00a  vmovaps [rsp+0x90], xmm10
000074b6341dd013  vmovaps [rsp+0xA0], xmm11
000074b6341dd01c  vmovaps [rsp+0xB0], xmm12
000074b6341dd025  vmovaps [rsp+0xC0], xmm13
000074b6341dd02e  vmovaps [rsp+0xD0], xmm14
000074b6341dd037  vmovaps [rsp+0xE0], xmm15
000074b6341dd040  sub rsp, 0x30
000074b6341dd044  movaps [rsp], xmm3
000074b6341dd048  movaps [rsp+0x10], xmm5
000074b6341dd04d  movaps [rsp+0x20], xmm4
000074b6341dd052  lea rdi, [rsp]
000074b6341dd056  mov esi, 0x00
000074b6341dd05b  mov rax, 0x5E1AA0A2F530
000074b6341dd065  call rax
000074b6341dd067  movaps xmm3, [rsp]
000074b6341dd06b  add rsp, 0x30
000074b6341dd06f  vmovaps xmm0, [rsp]
000074b6341dd074  vmovaps xmm1, [rsp+0x10]
000074b6341dd07a  vmovaps xmm2, [rsp+0x20]
000074b6341dd080  vmovaps xmm4, [rsp+0x30]
000074b6341dd086  vmovaps xmm5, [rsp+0x40]
000074b6341dd08c  vmovaps xmm6, [rsp+0x50]
000074b6341dd092  vmovaps xmm7, [rsp+0x60]
000074b6341dd098  vmovaps xmm8, [rsp+0x70]
000074b6341dd09e  vmovaps xmm9, [rsp+0x80]
000074b6341dd0a7  vmovaps xmm10, [rsp+0x90]
000074b6341dd0b0  vmovaps xmm11, [rsp+0xA0]
000074b6341dd0b9  vmovaps xmm12, [rsp+0xB0]
000074b6341dd0c2  vmovaps xmm13, [rsp+0xC0]
000074b6341dd0cb  vmovaps xmm14, [rsp+0xD0]
000074b6341dd0d4  vmovaps xmm15, [rsp+0xE0]
000074b6341dd0dd  add rsp, 0xF0
000074b6341dd0e4  pop r11
000074b6341dd0e6  pop r10
000074b6341dd0e8  pop r9
000074b6341dd0ea  pop r8
000074b6341dd0ec  pop rsi
000074b6341dd0ed  pop rdi
000074b6341dd0ee  pop rdx
000074b6341dd0ef  pop rcx
000074b6341dd0f0  pop rax
000074b6341dd0f1  add rsp, 0x08
000074b6341dd0f5  jmp 0x000074B6341DBC35
000074b6341dd0fa  sub rsp, 0x08
000074b6341dd0fe  push rax
000074b6341dd0ff  push rcx
000074b6341dd100  push rdx
000074b6341dd101  push rdi
000074b6341dd102  push rsi
000074b6341dd103  push r8
000074b6341dd105  push r9
000074b6341dd107  push r10
000074b6341dd109  push r11
000074b6341dd10b  sub rsp, 0xF0
000074b6341dd112  vmovaps [rsp], xmm0
000074b6341dd117  vmovaps [rsp+0x10], xmm1
000074b6341dd11d  vmovaps [rsp+0x20], xmm2
000074b6341dd123  vmovaps [rsp+0x30], xmm3
000074b6341dd129  vmovaps [rsp+0x40], xmm4
000074b6341dd12f  vmovaps [rsp+0x50], xmm6
000074b6341dd135  vmovaps [rsp+0x60], xmm7
000074b6341dd13b  vmovaps [rsp+0x70], xmm8
000074b6341dd141  vmovaps [rsp+0x80], xmm9
000074b6341dd14a  vmovaps [rsp+0x90], xmm10
000074b6341dd153  vmovaps [rsp+0xA0], xmm11
000074b6341dd15c  vmovaps [rsp+0xB0], xmm12
000074b6341dd165  vmovaps [rsp+0xC0], xmm13
000074b6341dd16e  vmovaps [rsp+0xD0], xmm14
000074b6341dd177  vmovaps [rsp+0xE0], xmm15
000074b6341dd180  sub rsp, 0x30
000074b6341dd184  movaps [rsp], xmm5
000074b6341dd188  movaps [rsp+0x10], xmm8
000074b6341dd18e  movaps [rsp+0x20], xmm15
000074b6341dd194  lea rdi, [rsp]
000074b6341dd198  mov esi, 0x00
000074b6341dd19d  mov rax, 0x5E1AA0A2F530
000074b6341dd1a7  call rax
000074b6341dd1a9  movaps xmm5, [rsp]
000074b6341dd1ad  add rsp, 0x30
000074b6341dd1b1  vmovaps xmm0, [rsp]
000074b6341dd1b6  vmovaps xmm1, [rsp+0x10]
000074b6341dd1bc  vmovaps xmm2, [rsp+0x20]
000074b6341dd1c2  vmovaps xmm3, [rsp+0x30]
000074b6341dd1c8  vmovaps xmm4, [rsp+0x40]
000074b6341dd1ce  vmovaps xmm6, [rsp+0x50]
000074b6341dd1d4  vmovaps xmm7, [rsp+0x60]
000074b6341dd1da  vmovaps xmm8, [rsp+0x70]
000074b6341dd1e0  vmovaps xmm9, [rsp+0x80]
000074b6341dd1e9  vmovaps xmm10, [rsp+0x90]
000074b6341dd1f2  vmovaps xmm11, [rsp+0xA0]
000074b6341dd1fb  vmovaps xmm12, [rsp+0xB0]
000074b6341dd204  vmovaps xmm13, [rsp+0xC0]
000074b6341dd20d  vmovaps xmm14, [rsp+0xD0]
000074b6341dd216  vmovaps xmm15, [rsp+0xE0]
000074b6341dd21f  add rsp, 0xF0
000074b6341dd226  pop r11
000074b6341dd228  pop r10
000074b6341dd22a  pop r9
000074b6341dd22c  pop r8
000074b6341dd22e  pop rsi
000074b6341dd22f  pop rdi
000074b6341dd230  pop rdx
000074b6341dd231  pop rcx
000074b6341dd232  pop rax
000074b6341dd233  add rsp, 0x08
000074b6341dd237  jmp 0x000074B6341DBC73
000074b6341dd23c  sub rsp, 0x08
000074b6341dd240  push rax
000074b6341dd241  push rcx
000074b6341dd242  push rdx
000074b6341dd243  push rdi
000074b6341dd244  push rsi
000074b6341dd245  push r8
000074b6341dd247  push r9
000074b6341dd249  push r10
000074b6341dd24b  push r11
000074b6341dd24d  sub rsp, 0xF0
000074b6341dd254  vmovaps [rsp], xmm0
000074b6341dd259  vmovaps [rsp+0x10], xmm1
000074b6341dd25f  vmovaps [rsp+0x20], xmm2
000074b6341dd265  vmovaps [rsp+0x30], xmm3
000074b6341dd26b  vmovaps [rsp+0x40], xmm5
000074b6341dd271  vmovaps [rsp+0x50], xmm6
000074b6341dd277  vmovaps [rsp+0x60], xmm7
000074b6341dd27d  vmovaps [rsp+0x70], xmm8
000074b6341dd283  vmovaps [rsp+0x80], xmm9
000074b6341dd28c  vmovaps [rsp+0x90], xmm10
000074b6341dd295  vmovaps [rsp+0xA0], xmm11
000074b6341dd29e  vmovaps [rsp+0xB0], xmm12
000074b6341dd2a7  vmovaps [rsp+0xC0], xmm13
000074b6341dd2b0  vmovaps [rsp+0xD0], xmm14
000074b6341dd2b9  vmovaps [rsp+0xE0], xmm15
000074b6341dd2c2  sub rsp, 0x30
000074b6341dd2c6  movaps [rsp], xmm4
000074b6341dd2ca  movaps [rsp+0x10], xmm9
000074b6341dd2d0  movaps [rsp+0x20], xmm8
000074b6341dd2d6  lea rdi, [rsp]
000074b6341dd2da  mov esi, 0x00
000074b6341dd2df  mov rax, 0x5E1AA0A2F530
000074b6341dd2e9  call rax
000074b6341dd2eb  movaps xmm4, [rsp]
000074b6341dd2ef  add rsp, 0x30
000074b6341dd2f3  vmovaps xmm0, [rsp]
000074b6341dd2f8  vmovaps xmm1, [rsp+0x10]
000074b6341dd2fe  vmovaps xmm2, [rsp+0x20]
000074b6341dd304  vmovaps xmm3, [rsp+0x30]
000074b6341dd30a  vmovaps xmm5, [rsp+0x40]
000074b6341dd310  vmovaps xmm6, [rsp+0x50]
000074b6341dd316  vmovaps xmm7, [rsp+0x60]
000074b6341dd31c  vmovaps xmm8, [rsp+0x70]
000074b6341dd322  vmovaps xmm9, [rsp+0x80]
000074b6341dd32b  vmovaps xmm10, [rsp+0x90]
000074b6341dd334  vmovaps xmm11, [rsp+0xA0]
000074b6341dd33d  vmovaps xmm12, [rsp+0xB0]
000074b6341dd346  vmovaps xmm13, [rsp+0xC0]
000074b6341dd34f  vmovaps xmm14, [rsp+0xD0]
000074b6341dd358  vmovaps xmm15, [rsp+0xE0]
000074b6341dd361  add rsp, 0xF0
000074b6341dd368  pop r11
000074b6341dd36a  pop r10
000074b6341dd36c  pop r9
000074b6341dd36e  pop r8
000074b6341dd370  pop rsi
000074b6341dd371  pop rdi
000074b6341dd372  pop rdx
000074b6341dd373  pop rcx
000074b6341dd374  pop rax
000074b6341dd375  add rsp, 0x08
000074b6341dd379  jmp 0x000074B6341DBC94
000074b6341dd37e  sub rsp, 0x08
000074b6341dd382  push rax
000074b6341dd383  push rcx
000074b6341dd384  push rdx
000074b6341dd385  push rdi
000074b6341dd386  push rsi
000074b6341dd387  push r8
000074b6341dd389  push r9
000074b6341dd38b  push r10
000074b6341dd38d  push r11
000074b6341dd38f  sub rsp, 0xF0
000074b6341dd396  vmovaps [rsp], xmm0
000074b6341dd39b  vmovaps [rsp+0x10], xmm1
000074b6341dd3a1  vmovaps [rsp+0x20], xmm2
000074b6341dd3a7  vmovaps [rsp+0x30], xmm3
000074b6341dd3ad  vmovaps [rsp+0x40], xmm4
000074b6341dd3b3  vmovaps [rsp+0x50], xmm5
000074b6341dd3b9  vmovaps [rsp+0x60], xmm6
000074b6341dd3bf  vmovaps [rsp+0x70], xmm7
000074b6341dd3c5  vmovaps [rsp+0x80], xmm8
000074b6341dd3ce  vmovaps [rsp+0x90], xmm10
000074b6341dd3d7  vmovaps [rsp+0xA0], xmm11
000074b6341dd3e0  vmovaps [rsp+0xB0], xmm12
000074b6341dd3e9  vmovaps [rsp+0xC0], xmm13
000074b6341dd3f2  vmovaps [rsp+0xD0], xmm14
000074b6341dd3fb  vmovaps [rsp+0xE0], xmm15
000074b6341dd404  sub rsp, 0x30
000074b6341dd408  movaps [rsp], xmm9
000074b6341dd40d  movaps [rsp+0x10], xmm10
000074b6341dd413  movaps [rsp+0x20], xmm8
000074b6341dd419  lea rdi, [rsp]
000074b6341dd41d  mov esi, 0x00
000074b6341dd422  mov rax, 0x5E1AA0A2F530
000074b6341dd42c  call rax
000074b6341dd42e  movaps xmm9, [rsp]
000074b6341dd433  add rsp, 0x30
000074b6341dd437  vmovaps xmm0, [rsp]
000074b6341dd43c  vmovaps xmm1, [rsp+0x10]
000074b6341dd442  vmovaps xmm2, [rsp+0x20]
000074b6341dd448  vmovaps xmm3, [rsp+0x30]
000074b6341dd44e  vmovaps xmm4, [rsp+0x40]
000074b6341dd454  vmovaps xmm5, [rsp+0x50]
000074b6341dd45a  vmovaps xmm6, [rsp+0x60]
000074b6341dd460  vmovaps xmm7, [rsp+0x70]
000074b6341dd466  vmovaps xmm8, [rsp+0x80]
000074b6341dd46f  vmovaps xmm10, [rsp+0x90]
000074b6341dd478  vmovaps xmm11, [rsp+0xA0]
000074b6341dd481  vmovaps xmm12, [rsp+0xB0]
000074b6341dd48a  vmovaps xmm13, [rsp+0xC0]
000074b6341dd493  vmovaps xmm14, [rsp+0xD0]
000074b6341dd49c  vmovaps xmm15, [rsp+0xE0]
000074b6341dd4a5  add rsp, 0xF0
000074b6341dd4ac  pop r11
000074b6341dd4ae  pop r10
000074b6341dd4b0  pop r9
000074b6341dd4b2  pop r8
000074b6341dd4b4  pop rsi
000074b6341dd4b5  pop rdi
000074b6341dd4b6  pop rdx
000074b6341dd4b7  pop rcx
000074b6341dd4b8  pop rax
000074b6341dd4b9  add rsp, 0x08
000074b6341dd4bd  jmp 0x000074B6341DBCAE
000074b6341dd4c2  call 0x000074B6340B52F0
000074b6341dd4c7  jmp 0x000074B6341DBDC8
000074b6341dd4cc  call 0x000074B6340B52F0
000074b6341dd4d1  jmp 0x000074B6341DBDDE
000074b6341dd4d6  sub rsp, 0x08
000074b6341dd4da  push rax
000074b6341dd4db  push rcx
000074b6341dd4dc  push rdx
000074b6341dd4dd  push rdi
000074b6341dd4de  push rsi
000074b6341dd4df  push r8
000074b6341dd4e1  push r9
000074b6341dd4e3  push r10
000074b6341dd4e5  push r11
000074b6341dd4e7  sub rsp, 0xF0
000074b6341dd4ee  vmovaps [rsp], xmm0
000074b6341dd4f3  vmovaps [rsp+0x10], xmm2
000074b6341dd4f9  vmovaps [rsp+0x20], xmm3
000074b6341dd4ff  vmovaps [rsp+0x30], xmm4
000074b6341dd505  vmovaps [rsp+0x40], xmm5
000074b6341dd50b  vmovaps [rsp+0x50], xmm6
000074b6341dd511  vmovaps [rsp+0x60], xmm7
000074b6341dd517  vmovaps [rsp+0x70], xmm8
000074b6341dd51d  vmovaps [rsp+0x80], xmm9
000074b6341dd526  vmovaps [rsp+0x90], xmm10
000074b6341dd52f  vmovaps [rsp+0xA0], xmm11
000074b6341dd538  vmovaps [rsp+0xB0], xmm12
000074b6341dd541  vmovaps [rsp+0xC0], xmm13
000074b6341dd54a  vmovaps [rsp+0xD0], xmm14
000074b6341dd553  vmovaps [rsp+0xE0], xmm15
000074b6341dd55c  sub rsp, 0x30
000074b6341dd560  movaps [rsp], xmm1
000074b6341dd564  movaps [rsp+0x10], xmm6
000074b6341dd569  movaps [rsp+0x20], xmm15
000074b6341dd56f  lea rdi, [rsp]
000074b6341dd573  mov esi, 0x00
000074b6341dd578  mov rax, 0x5E1AA0A2F530
000074b6341dd582  call rax
000074b6341dd584  movaps xmm1, [rsp]
000074b6341dd588  add rsp, 0x30
000074b6341dd58c  vmovaps xmm0, [rsp]
000074b6341dd591  vmovaps xmm2, [rsp+0x10]
000074b6341dd597  vmovaps xmm3, [rsp+0x20]
000074b6341dd59d  vmovaps xmm4, [rsp+0x30]
000074b6341dd5a3  vmovaps xmm5, [rsp+0x40]
000074b6341dd5a9  vmovaps xmm6, [rsp+0x50]
000074b6341dd5af  vmovaps xmm7, [rsp+0x60]
000074b6341dd5b5  vmovaps xmm8, [rsp+0x70]
000074b6341dd5bb  vmovaps xmm9, [rsp+0x80]
000074b6341dd5c4  vmovaps xmm10, [rsp+0x90]
000074b6341dd5cd  vmovaps xmm11, [rsp+0xA0]
000074b6341dd5d6  vmovaps xmm12, [rsp+0xB0]
000074b6341dd5df  vmovaps xmm13, [rsp+0xC0]
000074b6341dd5e8  vmovaps xmm14, [rsp+0xD0]
000074b6341dd5f1  vmovaps xmm15, [rsp+0xE0]
000074b6341dd5fa  add rsp, 0xF0
000074b6341dd601  pop r11
000074b6341dd603  pop r10
000074b6341dd605  pop r9
000074b6341dd607  pop r8
000074b6341dd609  pop rsi
000074b6341dd60a  pop rdi
000074b6341dd60b  pop rdx
000074b6341dd60c  pop rcx
000074b6341dd60d  pop rax
000074b6341dd60e  add rsp, 0x08
000074b6341dd612  jmp 0x000074B6341DBE1B
000074b6341dd617  call 0x000074B6340C4620
000074b6341dd61c  jmp 0x000074B6341DBE28
000074b6341dd621  sub rsp, 0x08
000074b6341dd625  push rax
000074b6341dd626  push rcx
000074b6341dd627  push rdx
000074b6341dd628  push rdi
000074b6341dd629  push rsi
000074b6341dd62a  push r8
000074b6341dd62c  push r9
000074b6341dd62e  push r10
000074b6341dd630  push r11
000074b6341dd632  sub rsp, 0xF0
000074b6341dd639  vmovaps [rsp], xmm0
000074b6341dd63e  vmovaps [rsp+0x10], xmm1
000074b6341dd644  vmovaps [rsp+0x20], xmm2
000074b6341dd64a  vmovaps [rsp+0x30], xmm3
000074b6341dd650  vmovaps [rsp+0x40], xmm4
000074b6341dd656  vmovaps [rsp+0x50], xmm5
000074b6341dd65c  vmovaps [rsp+0x60], xmm6
000074b6341dd662  vmovaps [rsp+0x70], xmm7
000074b6341dd668  vmovaps [rsp+0x80], xmm8
000074b6341dd671  vmovaps [rsp+0x90], xmm9
000074b6341dd67a  vmovaps [rsp+0xA0], xmm10
000074b6341dd683  vmovaps [rsp+0xB0], xmm11
000074b6341dd68c  vmovaps [rsp+0xC0], xmm12
000074b6341dd695  vmovaps [rsp+0xD0], xmm13
000074b6341dd69e  vmovaps [rsp+0xE0], xmm15
000074b6341dd6a7  sub rsp, 0x30
000074b6341dd6ab  movaps [rsp], xmm14
000074b6341dd6b0  movaps [rsp+0x10], xmm4
000074b6341dd6b5  movaps [rsp+0x20], xmm3
000074b6341dd6ba  lea rdi, [rsp]
000074b6341dd6be  mov esi, 0x00
000074b6341dd6c3  mov rax, 0x5E1AA0A2F530
000074b6341dd6cd  call rax
000074b6341dd6cf  movaps xmm14, [rsp]
000074b6341dd6d4  add rsp, 0x30
000074b6341dd6d8  vmovaps xmm0, [rsp]
000074b6341dd6dd  vmovaps xmm1, [rsp+0x10]
000074b6341dd6e3  vmovaps xmm2, [rsp+0x20]
000074b6341dd6e9  vmovaps xmm3, [rsp+0x30]
000074b6341dd6ef  vmovaps xmm4, [rsp+0x40]
000074b6341dd6f5  vmovaps xmm5, [rsp+0x50]
000074b6341dd6fb  vmovaps xmm6, [rsp+0x60]
000074b6341dd701  vmovaps xmm7, [rsp+0x70]
000074b6341dd707  vmovaps xmm8, [rsp+0x80]
000074b6341dd710  vmovaps xmm9, [rsp+0x90]
000074b6341dd719  vmovaps xmm10, [rsp+0xA0]
000074b6341dd722  vmovaps xmm11, [rsp+0xB0]
000074b6341dd72b  vmovaps xmm12, [rsp+0xC0]
000074b6341dd734  vmovaps xmm13, [rsp+0xD0]
000074b6341dd73d  vmovaps xmm15, [rsp+0xE0]
000074b6341dd746  add rsp, 0xF0
000074b6341dd74d  pop r11
000074b6341dd74f  pop r10
000074b6341dd751  pop r9
000074b6341dd753  pop r8
000074b6341dd755  pop rsi
000074b6341dd756  pop rdi
000074b6341dd757  pop rdx
000074b6341dd758  pop rcx
000074b6341dd759  pop rax
000074b6341dd75a  add rsp, 0x08
000074b6341dd75e  jmp 0x000074B6341DBE42
000074b6341dd763  sub rsp, 0x08
000074b6341dd767  push rax
000074b6341dd768  push rcx
000074b6341dd769  push rdx
000074b6341dd76a  push rdi
000074b6341dd76b  push rsi
000074b6341dd76c  push r8
000074b6341dd76e  push r9
000074b6341dd770  push r10
000074b6341dd772  push r11
000074b6341dd774  sub rsp, 0xF0
000074b6341dd77b  vmovaps [rsp], xmm0
000074b6341dd780  vmovaps [rsp+0x10], xmm1
000074b6341dd786  vmovaps [rsp+0x20], xmm2
000074b6341dd78c  vmovaps [rsp+0x30], xmm3
000074b6341dd792  vmovaps [rsp+0x40], xmm4
000074b6341dd798  vmovaps [rsp+0x50], xmm5
000074b6341dd79e  vmovaps [rsp+0x60], xmm7
000074b6341dd7a4  vmovaps [rsp+0x70], xmm8
000074b6341dd7aa  vmovaps [rsp+0x80], xmm9
000074b6341dd7b3  vmovaps [rsp+0x90], xmm10
000074b6341dd7bc  vmovaps [rsp+0xA0], xmm11
000074b6341dd7c5  vmovaps [rsp+0xB0], xmm12
000074b6341dd7ce  vmovaps [rsp+0xC0], xmm13
000074b6341dd7d7  vmovaps [rsp+0xD0], xmm14
000074b6341dd7e0  vmovaps [rsp+0xE0], xmm15
000074b6341dd7e9  sub rsp, 0x30
000074b6341dd7ed  movaps [rsp], xmm6
000074b6341dd7f1  movaps [rsp+0x10], xmm9
000074b6341dd7f7  movaps [rsp+0x20], xmm7
000074b6341dd7fc  lea rdi, [rsp]
000074b6341dd800  mov esi, 0x00
000074b6341dd805  mov rax, 0x5E1AA0A2F530
000074b6341dd80f  call rax
000074b6341dd811  movaps xmm6, [rsp]
000074b6341dd815  add rsp, 0x30
000074b6341dd819  vmovaps xmm0, [rsp]
000074b6341dd81e  vmovaps xmm1, [rsp+0x10]
000074b6341dd824  vmovaps xmm2, [rsp+0x20]
000074b6341dd82a  vmovaps xmm3, [rsp+0x30]
000074b6341dd830  vmovaps xmm4, [rsp+0x40]
000074b6341dd836  vmovaps xmm5, [rsp+0x50]
000074b6341dd83c  vmovaps xmm7, [rsp+0x60]
000074b6341dd842  vmovaps xmm8, [rsp+0x70]
000074b6341dd848  vmovaps xmm9, [rsp+0x80]
000074b6341dd851  vmovaps xmm10, [rsp+0x90]
000074b6341dd85a  vmovaps xmm11, [rsp+0xA0]
000074b6341dd863  vmovaps xmm12, [rsp+0xB0]
000074b6341dd86c  vmovaps xmm13, [rsp+0xC0]
000074b6341dd875  vmovaps xmm14, [rsp+0xD0]
000074b6341dd87e  vmovaps xmm15, [rsp+0xE0]
000074b6341dd887  add rsp, 0xF0
000074b6341dd88e  pop r11
000074b6341dd890  pop r10
000074b6341dd892  pop r9
000074b6341dd894  pop r8
000074b6341dd896  pop rsi
000074b6341dd897  pop rdi
000074b6341dd898  pop rdx
000074b6341dd899  pop rcx
000074b6341dd89a  pop rax
000074b6341dd89b  add rsp, 0x08
000074b6341dd89f  jmp 0x000074B6341DBE5A
000074b6341dd8a4  sub rsp, 0x08
000074b6341dd8a8  push rax
000074b6341dd8a9  push rcx
000074b6341dd8aa  push rdx
000074b6341dd8ab  push rdi
000074b6341dd8ac  push rsi
000074b6341dd8ad  push r8
000074b6341dd8af  push r9
000074b6341dd8b1  push r10
000074b6341dd8b3  push r11
000074b6341dd8b5  sub rsp, 0xF0
000074b6341dd8bc  vmovaps [rsp], xmm0
000074b6341dd8c1  vmovaps [rsp+0x10], xmm1
000074b6341dd8c7  vmovaps [rsp+0x20], xmm2
000074b6341dd8cd  vmovaps [rsp+0x30], xmm3
000074b6341dd8d3  vmovaps [rsp+0x40], xmm4
000074b6341dd8d9  vmovaps [rsp+0x50], xmm5
000074b6341dd8df  vmovaps [rsp+0x60], xmm6
000074b6341dd8e5  vmovaps [rsp+0x70], xmm8
000074b6341dd8eb  vmovaps [rsp+0x80], xmm9
000074b6341dd8f4  vmovaps [rsp+0x90], xmm10
000074b6341dd8fd  vmovaps [rsp+0xA0], xmm11
000074b6341dd906  vmovaps [rsp+0xB0], xmm12
000074b6341dd90f  vmovaps [rsp+0xC0], xmm13
000074b6341dd918  vmovaps [rsp+0xD0], xmm14
000074b6341dd921  vmovaps [rsp+0xE0], xmm15
000074b6341dd92a  sub rsp, 0x30
000074b6341dd92e  movaps [rsp], xmm7
000074b6341dd932  movaps [rsp+0x10], xmm4
000074b6341dd937  movaps [rsp+0x20], xmm9
000074b6341dd93d  lea rdi, [rsp]
000074b6341dd941  mov esi, 0x00
000074b6341dd946  mov rax, 0x5E1AA0A2F530
000074b6341dd950  call rax
000074b6341dd952  movaps xmm7, [rsp]
000074b6341dd956  add rsp, 0x30
000074b6341dd95a  vmovaps xmm0, [rsp]
000074b6341dd95f  vmovaps xmm1, [rsp+0x10]
000074b6341dd965  vmovaps xmm2, [rsp+0x20]
000074b6341dd96b  vmovaps xmm3, [rsp+0x30]
000074b6341dd971  vmovaps xmm4, [rsp+0x40]
000074b6341dd977  vmovaps xmm5, [rsp+0x50]
000074b6341dd97d  vmovaps xmm6, [rsp+0x60]
000074b6341dd983  vmovaps xmm8, [rsp+0x70]
000074b6341dd989  vmovaps xmm9, [rsp+0x80]
000074b6341dd992  vmovaps xmm10, [rsp+0x90]
000074b6341dd99b  vmovaps xmm11, [rsp+0xA0]
000074b6341dd9a4  vmovaps xmm12, [rsp+0xB0]
000074b6341dd9ad  vmovaps xmm13, [rsp+0xC0]
000074b6341dd9b6  vmovaps xmm14, [rsp+0xD0]
000074b6341dd9bf  vmovaps xmm15, [rsp+0xE0]
000074b6341dd9c8  add rsp, 0xF0
000074b6341dd9cf  pop r11
000074b6341dd9d1  pop r10
000074b6341dd9d3  pop r9
000074b6341dd9d5  pop r8
000074b6341dd9d7  pop rsi
000074b6341dd9d8  pop rdi
000074b6341dd9d9  pop rdx
000074b6341dd9da  pop rcx
000074b6341dd9db  pop rax
000074b6341dd9dc  add rsp, 0x08
000074b6341dd9e0  jmp 0x000074B6341DBE87
000074b6341dd9e5  sub rsp, 0x08
000074b6341dd9e9  push rax
000074b6341dd9ea  push rcx
000074b6341dd9eb  push rdx
000074b6341dd9ec  push rdi
000074b6341dd9ed  push rsi
000074b6341dd9ee  push r8
000074b6341dd9f0  push r9
000074b6341dd9f2  push r10
000074b6341dd9f4  push r11
000074b6341dd9f6  sub rsp, 0xF0
000074b6341dd9fd  vmovaps [rsp], xmm0
000074b6341dda02  vmovaps [rsp+0x10], xmm1
000074b6341dda08  vmovaps [rsp+0x20], xmm2
000074b6341dda0e  vmovaps [rsp+0x30], xmm3
000074b6341dda14  vmovaps [rsp+0x40], xmm5
000074b6341dda1a  vmovaps [rsp+0x50], xmm6
000074b6341dda20  vmovaps [rsp+0x60], xmm7
000074b6341dda26  vmovaps [rsp+0x70], xmm8
000074b6341dda2c  vmovaps [rsp+0x80], xmm9
000074b6341dda35  vmovaps [rsp+0x90], xmm10
000074b6341dda3e  vmovaps [rsp+0xA0], xmm11
000074b6341dda47  vmovaps [rsp+0xB0], xmm12
000074b6341dda50  vmovaps [rsp+0xC0], xmm13
000074b6341dda59  vmovaps [rsp+0xD0], xmm14
000074b6341dda62  vmovaps [rsp+0xE0], xmm15
000074b6341dda6b  sub rsp, 0x30
000074b6341dda6f  movaps [rsp], xmm4
000074b6341dda73  movaps [rsp+0x10], xmm15
000074b6341dda79  movaps [rsp+0x20], xmm9
000074b6341dda7f  lea rdi, [rsp]
000074b6341dda83  mov esi, 0x00
000074b6341dda88  mov rax, 0x5E1AA0A2F530
000074b6341dda92  call rax
000074b6341dda94  movaps xmm4, [rsp]
000074b6341dda98  add rsp, 0x30
000074b6341dda9c  vmovaps xmm0, [rsp]
000074b6341ddaa1  vmovaps xmm1, [rsp+0x10]
000074b6341ddaa7  vmovaps xmm2, [rsp+0x20]
000074b6341ddaad  vmovaps xmm3, [rsp+0x30]
000074b6341ddab3  vmovaps xmm5, [rsp+0x40]
000074b6341ddab9  vmovaps xmm6, [rsp+0x50]
000074b6341ddabf  vmovaps xmm7, [rsp+0x60]
000074b6341ddac5  vmovaps xmm8, [rsp+0x70]
000074b6341ddacb  vmovaps xmm9, [rsp+0x80]
000074b6341ddad4  vmovaps xmm10, [rsp+0x90]
000074b6341ddadd  vmovaps xmm11, [rsp+0xA0]
000074b6341ddae6  vmovaps xmm12, [rsp+0xB0]
000074b6341ddaef  vmovaps xmm13, [rsp+0xC0]
000074b6341ddaf8  vmovaps xmm14, [rsp+0xD0]
000074b6341ddb01  vmovaps xmm15, [rsp+0xE0]
000074b6341ddb0a  add rsp, 0xF0
000074b6341ddb11  pop r11
000074b6341ddb13  pop r10
000074b6341ddb15  pop r9
000074b6341ddb17  pop r8
000074b6341ddb19  pop rsi
000074b6341ddb1a  pop rdi
000074b6341ddb1b  pop rdx
000074b6341ddb1c  pop rcx
000074b6341ddb1d  pop rax
000074b6341ddb1e  add rsp, 0x08
000074b6341ddb22  jmp 0x000074B6341DBEAC
000074b6341ddb27  call 0x000074B6340C4620
000074b6341ddb2c  jmp 0x000074B6341DBEB9
000074b6341ddb31  sub rsp, 0x08
000074b6341ddb35  push rax
000074b6341ddb36  push rcx
000074b6341ddb37  push rdx
000074b6341ddb38  push rdi
000074b6341ddb39  push rsi
000074b6341ddb3a  push r8
000074b6341ddb3c  push r9
000074b6341ddb3e  push r10
000074b6341ddb40  push r11
000074b6341ddb42  sub rsp, 0xF0
000074b6341ddb49  vmovaps [rsp], xmm0
000074b6341ddb4e  vmovaps [rsp+0x10], xmm1
000074b6341ddb54  vmovaps [rsp+0x20], xmm2
000074b6341ddb5a  vmovaps [rsp+0x30], xmm4
000074b6341ddb60  vmovaps [rsp+0x40], xmm5
000074b6341ddb66  vmovaps [rsp+0x50], xmm6
000074b6341ddb6c  vmovaps [rsp+0x60], xmm7
000074b6341ddb72  vmovaps [rsp+0x70], xmm8
000074b6341ddb78  vmovaps [rsp+0x80], xmm9
000074b6341ddb81  vmovaps [rsp+0x90], xmm10
000074b6341ddb8a  vmovaps [rsp+0xA0], xmm11
000074b6341ddb93  vmovaps [rsp+0xB0], xmm12
000074b6341ddb9c  vmovaps [rsp+0xC0], xmm13
000074b6341ddba5  vmovaps [rsp+0xD0], xmm14
000074b6341ddbae  vmovaps [rsp+0xE0], xmm15
000074b6341ddbb7  sub rsp, 0x30
000074b6341ddbbb  movaps [rsp], xmm3
000074b6341ddbbf  movaps [rsp+0x10], xmm1
000074b6341ddbc4  movaps [rsp+0x20], xmm9
000074b6341ddbca  lea rdi, [rsp]
000074b6341ddbce  mov esi, 0x00
000074b6341ddbd3  mov rax, 0x5E1AA0A2F530
000074b6341ddbdd  call rax
000074b6341ddbdf  movaps xmm3, [rsp]
000074b6341ddbe3  add rsp, 0x30
000074b6341ddbe7  vmovaps xmm0, [rsp]
000074b6341ddbec  vmovaps xmm1, [rsp+0x10]
000074b6341ddbf2  vmovaps xmm2, [rsp+0x20]
000074b6341ddbf8  vmovaps xmm4, [rsp+0x30]
000074b6341ddbfe  vmovaps xmm5, [rsp+0x40]
000074b6341ddc04  vmovaps xmm6, [rsp+0x50]
000074b6341ddc0a  vmovaps xmm7, [rsp+0x60]
000074b6341ddc10  vmovaps xmm8, [rsp+0x70]
000074b6341ddc16  vmovaps xmm9, [rsp+0x80]
000074b6341ddc1f  vmovaps xmm10, [rsp+0x90]
000074b6341ddc28  vmovaps xmm11, [rsp+0xA0]
000074b6341ddc31  vmovaps xmm12, [rsp+0xB0]
000074b6341ddc3a  vmovaps xmm13, [rsp+0xC0]
000074b6341ddc43  vmovaps xmm14, [rsp+0xD0]
000074b6341ddc4c  vmovaps xmm15, [rsp+0xE0]
000074b6341ddc55  add rsp, 0xF0
000074b6341ddc5c  pop r11
000074b6341ddc5e  pop r10
000074b6341ddc60  pop r9
000074b6341ddc62  pop r8
000074b6341ddc64  pop rsi
000074b6341ddc65  pop rdi
000074b6341ddc66  pop rdx
000074b6341ddc67  pop rcx
000074b6341ddc68  pop rax
000074b6341ddc69  add rsp, 0x08
000074b6341ddc6d  jmp 0x000074B6341DBEF6
000074b6341ddc72  sub rsp, 0x08
000074b6341ddc76  push rax
000074b6341ddc77  push rcx
000074b6341ddc78  push rdx
000074b6341ddc79  push rdi
000074b6341ddc7a  push rsi
000074b6341ddc7b  push r8
000074b6341ddc7d  push r9
000074b6341ddc7f  push r10
000074b6341ddc81  push r11
000074b6341ddc83  sub rsp, 0xF0
000074b6341ddc8a  vmovaps [rsp], xmm0
000074b6341ddc8f  vmovaps [rsp+0x10], xmm2
000074b6341ddc95  vmovaps [rsp+0x20], xmm3
000074b6341ddc9b  vmovaps [rsp+0x30], xmm4
000074b6341ddca1  vmovaps [rsp+0x40], xmm5
000074b6341ddca7  vmovaps [rsp+0x50], xmm6
000074b6341ddcad  vmovaps [rsp+0x60], xmm7
000074b6341ddcb3  vmovaps [rsp+0x70], xmm8
000074b6341ddcb9  vmovaps [rsp+0x80], xmm9
000074b6341ddcc2  vmovaps [rsp+0x90], xmm10
000074b6341ddccb  vmovaps [rsp+0xA0], xmm11
000074b6341ddcd4  vmovaps [rsp+0xB0], xmm12
000074b6341ddcdd  vmovaps [rsp+0xC0], xmm13
000074b6341ddce6  vmovaps [rsp+0xD0], xmm14
000074b6341ddcef  vmovaps [rsp+0xE0], xmm15
000074b6341ddcf8  sub rsp, 0x30
000074b6341ddcfc  movaps [rsp], xmm1
000074b6341ddd00  movaps [rsp+0x10], xmm15
000074b6341ddd06  movaps [rsp+0x20], xmm9
000074b6341ddd0c  lea rdi, [rsp]
000074b6341ddd10  mov esi, 0x00
000074b6341ddd15  mov rax, 0x5E1AA0A2F530
000074b6341ddd1f  call rax
000074b6341ddd21  movaps xmm1, [rsp]
000074b6341ddd25  add rsp, 0x30
000074b6341ddd29  vmovaps xmm0, [rsp]
000074b6341ddd2e  vmovaps xmm2, [rsp+0x10]
000074b6341ddd34  vmovaps xmm3, [rsp+0x20]
000074b6341ddd3a  vmovaps xmm4, [rsp+0x30]
000074b6341ddd40  vmovaps xmm5, [rsp+0x40]
000074b6341ddd46  vmovaps xmm6, [rsp+0x50]
000074b6341ddd4c  vmovaps xmm7, [rsp+0x60]
000074b6341ddd52  vmovaps xmm8, [rsp+0x70]
000074b6341ddd58  vmovaps xmm9, [rsp+0x80]
000074b6341ddd61  vmovaps xmm10, [rsp+0x90]
000074b6341ddd6a  vmovaps xmm11, [rsp+0xA0]
000074b6341ddd73  vmovaps xmm12, [rsp+0xB0]
000074b6341ddd7c  vmovaps xmm13, [rsp+0xC0]
000074b6341ddd85  vmovaps xmm14, [rsp+0xD0]
000074b6341ddd8e  vmovaps xmm15, [rsp+0xE0]
000074b6341ddd97  add rsp, 0xF0
000074b6341ddd9e  pop r11
000074b6341ddda0  pop r10
000074b6341ddda2  pop r9
000074b6341ddda4  pop r8
000074b6341ddda6  pop rsi
000074b6341ddda7  pop rdi
000074b6341ddda8  pop rdx
000074b6341ddda9  pop rcx
000074b6341dddaa  pop rax
000074b6341dddab  add rsp, 0x08
000074b6341dddaf  jmp 0x000074B6341DBF7E
000074b6341dddb4  call 0x000074B6340C4620
000074b6341dddb9  jmp 0x000074B6341DBF8B
000074b6341dddbe  sub rsp, 0x08
000074b6341dddc2  push rax
000074b6341dddc3  push rcx
000074b6341dddc4  push rdx
000074b6341dddc5  push rdi
000074b6341dddc6  push rsi
000074b6341dddc7  push r8
000074b6341dddc9  push r9
000074b6341dddcb  push r10
000074b6341dddcd  push r11
000074b6341dddcf  sub rsp, 0xF0
000074b6341dddd6  vmovaps [rsp], xmm0
000074b6341ddddb  vmovaps [rsp+0x10], xmm2
000074b6341ddde1  vmovaps [rsp+0x20], xmm3
000074b6341ddde7  vmovaps [rsp+0x30], xmm4
000074b6341ddded  vmovaps [rsp+0x40], xmm5
000074b6341dddf3  vmovaps [rsp+0x50], xmm6
000074b6341dddf9  vmovaps [rsp+0x60], xmm7
000074b6341dddff  vmovaps [rsp+0x70], xmm8
000074b6341dde05  vmovaps [rsp+0x80], xmm9
000074b6341dde0e  vmovaps [rsp+0x90], xmm10
000074b6341dde17  vmovaps [rsp+0xA0], xmm11
000074b6341dde20  vmovaps [rsp+0xB0], xmm12
000074b6341dde29  vmovaps [rsp+0xC0], xmm13
000074b6341dde32  vmovaps [rsp+0xD0], xmm14
000074b6341dde3b  vmovaps [rsp+0xE0], xmm15
000074b6341dde44  sub rsp, 0x30
000074b6341dde48  movaps [rsp], xmm1
000074b6341dde4c  movaps [rsp+0x10], xmm5
000074b6341dde51  movaps [rsp+0x20], xmm7
000074b6341dde56  lea rdi, [rsp]
000074b6341dde5a  mov esi, 0x00
000074b6341dde5f  mov rax, 0x5E1AA0A2F530
000074b6341dde69  call rax
000074b6341dde6b  movaps xmm1, [rsp]
000074b6341dde6f  add rsp, 0x30
000074b6341dde73  vmovaps xmm0, [rsp]
000074b6341dde78  vmovaps xmm2, [rsp+0x10]
000074b6341dde7e  vmovaps xmm3, [rsp+0x20]
000074b6341dde84  vmovaps xmm4, [rsp+0x30]
000074b6341dde8a  vmovaps xmm5, [rsp+0x40]
000074b6341dde90  vmovaps xmm6, [rsp+0x50]
000074b6341dde96  vmovaps xmm7, [rsp+0x60]
000074b6341dde9c  vmovaps xmm8, [rsp+0x70]
000074b6341ddea2  vmovaps xmm9, [rsp+0x80]
000074b6341ddeab  vmovaps xmm10, [rsp+0x90]
000074b6341ddeb4  vmovaps xmm11, [rsp+0xA0]
000074b6341ddebd  vmovaps xmm12, [rsp+0xB0]
000074b6341ddec6  vmovaps xmm13, [rsp+0xC0]
000074b6341ddecf  vmovaps xmm14, [rsp+0xD0]
000074b6341dded8  vmovaps xmm15, [rsp+0xE0]
000074b6341ddee1  add rsp, 0xF0
000074b6341ddee8  pop r11
000074b6341ddeea  pop r10
000074b6341ddeec  pop r9
000074b6341ddeee  pop r8
000074b6341ddef0  pop rsi
000074b6341ddef1  pop rdi
000074b6341ddef2  pop rdx
000074b6341ddef3  pop rcx
000074b6341ddef4  pop rax
000074b6341ddef5  add rsp, 0x08
000074b6341ddef9  jmp 0x000074B6341DC030
000074b6341ddefe  sub rsp, 0x08
000074b6341ddf02  push rax
000074b6341ddf03  push rcx
000074b6341ddf04  push rdx
000074b6341ddf05  push rdi
000074b6341ddf06  push rsi
000074b6341ddf07  push r8
000074b6341ddf09  push r9
000074b6341ddf0b  push r10
000074b6341ddf0d  push r11
000074b6341ddf0f  sub rsp, 0xF0
000074b6341ddf16  vmovaps [rsp], xmm0
000074b6341ddf1b  vmovaps [rsp+0x10], xmm1
000074b6341ddf21  vmovaps [rsp+0x20], xmm2
000074b6341ddf27  vmovaps [rsp+0x30], xmm3
000074b6341ddf2d  vmovaps [rsp+0x40], xmm4
000074b6341ddf33  vmovaps [rsp+0x50], xmm5
000074b6341ddf39  vmovaps [rsp+0x60], xmm6
000074b6341ddf3f  vmovaps [rsp+0x70], xmm8
000074b6341ddf45  vmovaps [rsp+0x80], xmm9
000074b6341ddf4e  vmovaps [rsp+0x90], xmm10
000074b6341ddf57  vmovaps [rsp+0xA0], xmm11
000074b6341ddf60  vmovaps [rsp+0xB0], xmm12
000074b6341ddf69  vmovaps [rsp+0xC0], xmm13
000074b6341ddf72  vmovaps [rsp+0xD0], xmm14
000074b6341ddf7b  vmovaps [rsp+0xE0], xmm15
000074b6341ddf84  sub rsp, 0x30
000074b6341ddf88  movaps [rsp], xmm7
000074b6341ddf8c  movaps [rsp+0x10], xmm5
000074b6341ddf91  movaps [rsp+0x20], xmm15
000074b6341ddf97  lea rdi, [rsp]
000074b6341ddf9b  mov esi, 0x00
000074b6341ddfa0  mov rax, 0x5E1AA0A2F530
000074b6341ddfaa  call rax
000074b6341ddfac  movaps xmm7, [rsp]
000074b6341ddfb0  add rsp, 0x30
000074b6341ddfb4  vmovaps xmm0, [rsp]
000074b6341ddfb9  vmovaps xmm1, [rsp+0x10]
000074b6341ddfbf  vmovaps xmm2, [rsp+0x20]
000074b6341ddfc5  vmovaps xmm3, [rsp+0x30]
000074b6341ddfcb  vmovaps xmm4, [rsp+0x40]
000074b6341ddfd1  vmovaps xmm5, [rsp+0x50]
000074b6341ddfd7  vmovaps xmm6, [rsp+0x60]
000074b6341ddfdd  vmovaps xmm8, [rsp+0x70]
000074b6341ddfe3  vmovaps xmm9, [rsp+0x80]
000074b6341ddfec  vmovaps xmm10, [rsp+0x90]
000074b6341ddff5  vmovaps xmm11, [rsp+0xA0]
000074b6341ddffe  vmovaps xmm12, [rsp+0xB0]
000074b6341de007  vmovaps xmm13, [rsp+0xC0]
000074b6341de010  vmovaps xmm14, [rsp+0xD0]
000074b6341de019  vmovaps xmm15, [rsp+0xE0]
000074b6341de022  add rsp, 0xF0
000074b6341de029  pop r11
000074b6341de02b  pop r10
000074b6341de02d  pop r9
000074b6341de02f  pop r8
000074b6341de031  pop rsi
000074b6341de032  pop rdi
000074b6341de033  pop rdx
000074b6341de034  pop rcx
000074b6341de035  pop rax
000074b6341de036  add rsp, 0x08
000074b6341de03a  jmp 0x000074B6341DC066
000074b6341de03f  call 0x000074B6340B52F0
000074b6341de044  jmp 0x000074B6341DC073
000074b6341de049  sub rsp, 0x08
000074b6341de04d  push rax
000074b6341de04e  push rcx
000074b6341de04f  push rdx
000074b6341de050  push rdi
000074b6341de051  push rsi
000074b6341de052  push r8
000074b6341de054  push r9
000074b6341de056  push r10
000074b6341de058  push r11
000074b6341de05a  sub rsp, 0xF0
000074b6341de061  vmovaps [rsp], xmm0
000074b6341de066  vmovaps [rsp+0x10], xmm1
000074b6341de06c  vmovaps [rsp+0x20], xmm2
000074b6341de072  vmovaps [rsp+0x30], xmm3
000074b6341de078  vmovaps [rsp+0x40], xmm4
000074b6341de07e  vmovaps [rsp+0x50], xmm5
000074b6341de084  vmovaps [rsp+0x60], xmm6
000074b6341de08a  vmovaps [rsp+0x70], xmm7
000074b6341de090  vmovaps [rsp+0x80], xmm8
000074b6341de099  vmovaps [rsp+0x90], xmm9
000074b6341de0a2  vmovaps [rsp+0xA0], xmm10
000074b6341de0ab  vmovaps [rsp+0xB0], xmm11
000074b6341de0b4  vmovaps [rsp+0xC0], xmm12
000074b6341de0bd  vmovaps [rsp+0xD0], xmm13
000074b6341de0c6  vmovaps [rsp+0xE0], xmm14
000074b6341de0cf  sub rsp, 0x30
000074b6341de0d3  movaps [rsp], xmm15
000074b6341de0d8  movaps [rsp+0x10], xmm5
000074b6341de0dd  movaps [rsp+0x20], xmm3
000074b6341de0e2  lea rdi, [rsp]
000074b6341de0e6  mov esi, 0x00
000074b6341de0eb  mov rax, 0x5E1AA0A2F530
000074b6341de0f5  call rax
000074b6341de0f7  movaps xmm15, [rsp]
000074b6341de0fc  add rsp, 0x30
000074b6341de100  vmovaps xmm0, [rsp]
000074b6341de105  vmovaps xmm1, [rsp+0x10]
000074b6341de10b  vmovaps xmm2, [rsp+0x20]
000074b6341de111  vmovaps xmm3, [rsp+0x30]
000074b6341de117  vmovaps xmm4, [rsp+0x40]
000074b6341de11d  vmovaps xmm5, [rsp+0x50]
000074b6341de123  vmovaps xmm6, [rsp+0x60]
000074b6341de129  vmovaps xmm7, [rsp+0x70]
000074b6341de12f  vmovaps xmm8, [rsp+0x80]
000074b6341de138  vmovaps xmm9, [rsp+0x90]
000074b6341de141  vmovaps xmm10, [rsp+0xA0]
000074b6341de14a  vmovaps xmm11, [rsp+0xB0]
000074b6341de153  vmovaps xmm12, [rsp+0xC0]
000074b6341de15c  vmovaps xmm13, [rsp+0xD0]
000074b6341de165  vmovaps xmm14, [rsp+0xE0]
000074b6341de16e  add rsp, 0xF0
000074b6341de175  pop r11
000074b6341de177  pop r10
000074b6341de179  pop r9
000074b6341de17b  pop r8
000074b6341de17d  pop rsi
000074b6341de17e  pop rdi
000074b6341de17f  pop rdx
000074b6341de180  pop rcx
000074b6341de181  pop rax
000074b6341de182  add rsp, 0x08
000074b6341de186  jmp 0x000074B6341DC099
000074b6341de18b  sub rsp, 0x08
000074b6341de18f  push rax
000074b6341de190  push rcx
000074b6341de191  push rdx
000074b6341de192  push rdi
000074b6341de193  push rsi
000074b6341de194  push r8
000074b6341de196  push r9
000074b6341de198  push r10
000074b6341de19a  push r11
000074b6341de19c  sub rsp, 0xF0
000074b6341de1a3  vmovaps [rsp], xmm0
000074b6341de1a8  vmovaps [rsp+0x10], xmm2
000074b6341de1ae  vmovaps [rsp+0x20], xmm3
000074b6341de1b4  vmovaps [rsp+0x30], xmm4
000074b6341de1ba  vmovaps [rsp+0x40], xmm5
000074b6341de1c0  vmovaps [rsp+0x50], xmm6
000074b6341de1c6  vmovaps [rsp+0x60], xmm7
000074b6341de1cc  vmovaps [rsp+0x70], xmm8
000074b6341de1d2  vmovaps [rsp+0x80], xmm9
000074b6341de1db  vmovaps [rsp+0x90], xmm10
000074b6341de1e4  vmovaps [rsp+0xA0], xmm11
000074b6341de1ed  vmovaps [rsp+0xB0], xmm12
000074b6341de1f6  vmovaps [rsp+0xC0], xmm13
000074b6341de1ff  vmovaps [rsp+0xD0], xmm14
000074b6341de208  vmovaps [rsp+0xE0], xmm15
000074b6341de211  sub rsp, 0x30
000074b6341de215  movaps [rsp], xmm1
000074b6341de219  movaps [rsp+0x10], xmm5
000074b6341de21e  movaps [rsp+0x20], xmm4
000074b6341de223  lea rdi, [rsp]
000074b6341de227  mov esi, 0x00
000074b6341de22c  mov rax, 0x5E1AA0A2F530
000074b6341de236  call rax
000074b6341de238  movaps xmm1, [rsp]
000074b6341de23c  add rsp, 0x30
000074b6341de240  vmovaps xmm0, [rsp]
000074b6341de245  vmovaps xmm2, [rsp+0x10]
000074b6341de24b  vmovaps xmm3, [rsp+0x20]
000074b6341de251  vmovaps xmm4, [rsp+0x30]
000074b6341de257  vmovaps xmm5, [rsp+0x40]
000074b6341de25d  vmovaps xmm6, [rsp+0x50]
000074b6341de263  vmovaps xmm7, [rsp+0x60]
000074b6341de269  vmovaps xmm8, [rsp+0x70]
000074b6341de26f  vmovaps xmm9, [rsp+0x80]
000074b6341de278  vmovaps xmm10, [rsp+0x90]
000074b6341de281  vmovaps xmm11, [rsp+0xA0]
000074b6341de28a  vmovaps xmm12, [rsp+0xB0]
000074b6341de293  vmovaps xmm13, [rsp+0xC0]
000074b6341de29c  vmovaps xmm14, [rsp+0xD0]
000074b6341de2a5  vmovaps xmm15, [rsp+0xE0]
000074b6341de2ae  add rsp, 0xF0
000074b6341de2b5  pop r11
000074b6341de2b7  pop r10
000074b6341de2b9  pop r9
000074b6341de2bb  pop r8
000074b6341de2bd  pop rsi
000074b6341de2be  pop rdi
000074b6341de2bf  pop rdx
000074b6341de2c0  pop rcx
000074b6341de2c1  pop rax
000074b6341de2c2  add rsp, 0x08
000074b6341de2c6  jmp 0x000074B6341DC0B9
000074b6341de2cb  sub rsp, 0x08
000074b6341de2cf  push rax
000074b6341de2d0  push rcx
000074b6341de2d1  push rdx
000074b6341de2d2  push rdi
000074b6341de2d3  push rsi
000074b6341de2d4  push r8
000074b6341de2d6  push r9
000074b6341de2d8  push r10
000074b6341de2da  push r11
000074b6341de2dc  sub rsp, 0xF0
000074b6341de2e3  vmovaps [rsp], xmm0
000074b6341de2e8  vmovaps [rsp+0x10], xmm1
000074b6341de2ee  vmovaps [rsp+0x20], xmm2
000074b6341de2f4  vmovaps [rsp+0x30], xmm3
000074b6341de2fa  vmovaps [rsp+0x40], xmm5
000074b6341de300  vmovaps [rsp+0x50], xmm6
000074b6341de306  vmovaps [rsp+0x60], xmm7
000074b6341de30c  vmovaps [rsp+0x70], xmm8
000074b6341de312  vmovaps [rsp+0x80], xmm9
000074b6341de31b  vmovaps [rsp+0x90], xmm10
000074b6341de324  vmovaps [rsp+0xA0], xmm11
000074b6341de32d  vmovaps [rsp+0xB0], xmm12
000074b6341de336  vmovaps [rsp+0xC0], xmm13
000074b6341de33f  vmovaps [rsp+0xD0], xmm14
000074b6341de348  vmovaps [rsp+0xE0], xmm15
000074b6341de351  sub rsp, 0x30
000074b6341de355  movaps [rsp], xmm4
000074b6341de359  movaps [rsp+0x10], xmm3
000074b6341de35e  movaps [rsp+0x20], xmm5
000074b6341de363  lea rdi, [rsp]
000074b6341de367  mov esi, 0x00
000074b6341de36c  mov rax, 0x5E1AA0A2F530
000074b6341de376  call rax
000074b6341de378  movaps xmm4, [rsp]
000074b6341de37c  add rsp, 0x30
000074b6341de380  vmovaps xmm0, [rsp]
000074b6341de385  vmovaps xmm1, [rsp+0x10]
000074b6341de38b  vmovaps xmm2, [rsp+0x20]
000074b6341de391  vmovaps xmm3, [rsp+0x30]
000074b6341de397  vmovaps xmm5, [rsp+0x40]
000074b6341de39d  vmovaps xmm6, [rsp+0x50]
000074b6341de3a3  vmovaps xmm7, [rsp+0x60]
000074b6341de3a9  vmovaps xmm8, [rsp+0x70]
000074b6341de3af  vmovaps xmm9, [rsp+0x80]
000074b6341de3b8  vmovaps xmm10, [rsp+0x90]
000074b6341de3c1  vmovaps xmm11, [rsp+0xA0]
000074b6341de3ca  vmovaps xmm12, [rsp+0xB0]
000074b6341de3d3  vmovaps xmm13, [rsp+0xC0]
000074b6341de3dc  vmovaps xmm14, [rsp+0xD0]
000074b6341de3e5  vmovaps xmm15, [rsp+0xE0]
000074b6341de3ee  add rsp, 0xF0
000074b6341de3f5  pop r11
000074b6341de3f7  pop r10
000074b6341de3f9  pop r9
000074b6341de3fb  pop r8
000074b6341de3fd  pop rsi
000074b6341de3fe  pop rdi
000074b6341de3ff  pop rdx
000074b6341de400  pop rcx
000074b6341de401  pop rax
000074b6341de402  add rsp, 0x08
000074b6341de406  jmp 0x000074B6341DC107
000074b6341de40b  call 0x000074B6340B52F0
000074b6341de410  jmp 0x000074B6341DC114
000074b6341de415  sub rsp, 0x08
000074b6341de419  push rax
000074b6341de41a  push rcx
000074b6341de41b  push rdx
000074b6341de41c  push rdi
000074b6341de41d  push rsi
000074b6341de41e  push r8
000074b6341de420  push r9
000074b6341de422  push r10
000074b6341de424  push r11
000074b6341de426  sub rsp, 0xF0
000074b6341de42d  vmovaps [rsp], xmm0
000074b6341de432  vmovaps [rsp+0x10], xmm1
000074b6341de438  vmovaps [rsp+0x20], xmm2
000074b6341de43e  vmovaps [rsp+0x30], xmm3
000074b6341de444  vmovaps [rsp+0x40], xmm4
000074b6341de44a  vmovaps [rsp+0x50], xmm6
000074b6341de450  vmovaps [rsp+0x60], xmm7
000074b6341de456  vmovaps [rsp+0x70], xmm8
000074b6341de45c  vmovaps [rsp+0x80], xmm9
000074b6341de465  vmovaps [rsp+0x90], xmm10
000074b6341de46e  vmovaps [rsp+0xA0], xmm11
000074b6341de477  vmovaps [rsp+0xB0], xmm12
000074b6341de480  vmovaps [rsp+0xC0], xmm13
000074b6341de489  vmovaps [rsp+0xD0], xmm14
000074b6341de492  vmovaps [rsp+0xE0], xmm15
000074b6341de49b  sub rsp, 0x30
000074b6341de49f  movaps [rsp], xmm5
000074b6341de4a3  movaps [rsp+0x10], xmm6
000074b6341de4a8  movaps [rsp+0x20], xmm3
000074b6341de4ad  lea rdi, [rsp]
000074b6341de4b1  mov esi, 0x00
000074b6341de4b6  mov rax, 0x5E1AA0A2F530
000074b6341de4c0  call rax
000074b6341de4c2  movaps xmm5, [rsp]
000074b6341de4c6  add rsp, 0x30
000074b6341de4ca  vmovaps xmm0, [rsp]
000074b6341de4cf  vmovaps xmm1, [rsp+0x10]
000074b6341de4d5  vmovaps xmm2, [rsp+0x20]
000074b6341de4db  vmovaps xmm3, [rsp+0x30]
000074b6341de4e1  vmovaps xmm4, [rsp+0x40]
000074b6341de4e7  vmovaps xmm6, [rsp+0x50]
000074b6341de4ed  vmovaps xmm7, [rsp+0x60]
000074b6341de4f3  vmovaps xmm8, [rsp+0x70]
000074b6341de4f9  vmovaps xmm9, [rsp+0x80]
000074b6341de502  vmovaps xmm10, [rsp+0x90]
000074b6341de50b  vmovaps xmm11, [rsp+0xA0]
000074b6341de514  vmovaps xmm12, [rsp+0xB0]
000074b6341de51d  vmovaps xmm13, [rsp+0xC0]
000074b6341de526  vmovaps xmm14, [rsp+0xD0]
000074b6341de52f  vmovaps xmm15, [rsp+0xE0]
000074b6341de538  add rsp, 0xF0
000074b6341de53f  pop r11
000074b6341de541  pop r10
000074b6341de543  pop r9
000074b6341de545  pop r8
000074b6341de547  pop rsi
000074b6341de548  pop rdi
000074b6341de549  pop rdx
000074b6341de54a  pop rcx
000074b6341de54b  pop rax
000074b6341de54c  add rsp, 0x08
000074b6341de550  jmp 0x000074B6341DC13A
000074b6341de555  sub rsp, 0x08
000074b6341de559  push rax
000074b6341de55a  push rcx
000074b6341de55b  push rdx
000074b6341de55c  push rdi
000074b6341de55d  push rsi
000074b6341de55e  push r8
000074b6341de560  push r9
000074b6341de562  push r10
000074b6341de564  push r11
000074b6341de566  sub rsp, 0xF0
000074b6341de56d  vmovaps [rsp], xmm0
000074b6341de572  vmovaps [rsp+0x10], xmm1
000074b6341de578  vmovaps [rsp+0x20], xmm2
000074b6341de57e  vmovaps [rsp+0x30], xmm3
000074b6341de584  vmovaps [rsp+0x40], xmm4
000074b6341de58a  vmovaps [rsp+0x50], xmm5
000074b6341de590  vmovaps [rsp+0x60], xmm7
000074b6341de596  vmovaps [rsp+0x70], xmm8
000074b6341de59c  vmovaps [rsp+0x80], xmm9
000074b6341de5a5  vmovaps [rsp+0x90], xmm10
000074b6341de5ae  vmovaps [rsp+0xA0], xmm11
000074b6341de5b7  vmovaps [rsp+0xB0], xmm12
000074b6341de5c0  vmovaps [rsp+0xC0], xmm13
000074b6341de5c9  vmovaps [rsp+0xD0], xmm14
000074b6341de5d2  vmovaps [rsp+0xE0], xmm15
000074b6341de5db  sub rsp, 0x30
000074b6341de5df  movaps [rsp], xmm6
000074b6341de5e3  movaps [rsp+0x10], xmm9
000074b6341de5e9  movaps [rsp+0x20], xmm1
000074b6341de5ee  lea rdi, [rsp]
000074b6341de5f2  mov esi, 0x00
000074b6341de5f7  mov rax, 0x5E1AA0A2F530
000074b6341de601  call rax
000074b6341de603  movaps xmm6, [rsp]
000074b6341de607  add rsp, 0x30
000074b6341de60b  vmovaps xmm0, [rsp]
000074b6341de610  vmovaps xmm1, [rsp+0x10]
000074b6341de616  vmovaps xmm2, [rsp+0x20]
000074b6341de61c  vmovaps xmm3, [rsp+0x30]
000074b6341de622  vmovaps xmm4, [rsp+0x40]
000074b6341de628  vmovaps xmm5, [rsp+0x50]
000074b6341de62e  vmovaps xmm7, [rsp+0x60]
000074b6341de634  vmovaps xmm8, [rsp+0x70]
000074b6341de63a  vmovaps xmm9, [rsp+0x80]
000074b6341de643  vmovaps xmm10, [rsp+0x90]
000074b6341de64c  vmovaps xmm11, [rsp+0xA0]
000074b6341de655  vmovaps xmm12, [rsp+0xB0]
000074b6341de65e  vmovaps xmm13, [rsp+0xC0]
000074b6341de667  vmovaps xmm14, [rsp+0xD0]
000074b6341de670  vmovaps xmm15, [rsp+0xE0]
000074b6341de679  add rsp, 0xF0
000074b6341de680  pop r11
000074b6341de682  pop r10
000074b6341de684  pop r9
000074b6341de686  pop r8
000074b6341de688  pop rsi
000074b6341de689  pop rdi
000074b6341de68a  pop rdx
000074b6341de68b  pop rcx
000074b6341de68c  pop rax
000074b6341de68d  add rsp, 0x08
000074b6341de691  jmp 0x000074B6341DC15E
000074b6341de696  sub rsp, 0x08
000074b6341de69a  push rax
000074b6341de69b  push rcx
000074b6341de69c  push rdx
000074b6341de69d  push rdi
000074b6341de69e  push rsi
000074b6341de69f  push r8
000074b6341de6a1  push r9
000074b6341de6a3  push r10
000074b6341de6a5  push r11
000074b6341de6a7  sub rsp, 0xF0
000074b6341de6ae  vmovaps [rsp], xmm0
000074b6341de6b3  vmovaps [rsp+0x10], xmm1
000074b6341de6b9  vmovaps [rsp+0x20], xmm2
000074b6341de6bf  vmovaps [rsp+0x30], xmm3
000074b6341de6c5  vmovaps [rsp+0x40], xmm4
000074b6341de6cb  vmovaps [rsp+0x50], xmm5
000074b6341de6d1  vmovaps [rsp+0x60], xmm6
000074b6341de6d7  vmovaps [rsp+0x70], xmm7
000074b6341de6dd  vmovaps [rsp+0x80], xmm8
000074b6341de6e6  vmovaps [rsp+0x90], xmm10
000074b6341de6ef  vmovaps [rsp+0xA0], xmm11
000074b6341de6f8  vmovaps [rsp+0xB0], xmm12
000074b6341de701  vmovaps [rsp+0xC0], xmm13
000074b6341de70a  vmovaps [rsp+0xD0], xmm14
000074b6341de713  vmovaps [rsp+0xE0], xmm15
000074b6341de71c  sub rsp, 0x30
000074b6341de720  movaps [rsp], xmm9
000074b6341de725  movaps [rsp+0x10], xmm3
000074b6341de72a  movaps [rsp+0x20], xmm1
000074b6341de72f  lea rdi, [rsp]
000074b6341de733  mov esi, 0x00
000074b6341de738  mov rax, 0x5E1AA0A2F530
000074b6341de742  call rax
000074b6341de744  movaps xmm9, [rsp]
000074b6341de749  add rsp, 0x30
000074b6341de74d  vmovaps xmm0, [rsp]
000074b6341de752  vmovaps xmm1, [rsp+0x10]
000074b6341de758  vmovaps xmm2, [rsp+0x20]
000074b6341de75e  vmovaps xmm3, [rsp+0x30]
000074b6341de764  vmovaps xmm4, [rsp+0x40]
000074b6341de76a  vmovaps xmm5, [rsp+0x50]
000074b6341de770  vmovaps xmm6, [rsp+0x60]
000074b6341de776  vmovaps xmm7, [rsp+0x70]
000074b6341de77c  vmovaps xmm8, [rsp+0x80]
000074b6341de785  vmovaps xmm10, [rsp+0x90]
000074b6341de78e  vmovaps xmm11, [rsp+0xA0]
000074b6341de797  vmovaps xmm12, [rsp+0xB0]
000074b6341de7a0  vmovaps xmm13, [rsp+0xC0]
000074b6341de7a9  vmovaps xmm14, [rsp+0xD0]
000074b6341de7b2  vmovaps xmm15, [rsp+0xE0]
000074b6341de7bb  add rsp, 0xF0
000074b6341de7c2  pop r11
000074b6341de7c4  pop r10
000074b6341de7c6  pop r9
000074b6341de7c8  pop r8
000074b6341de7ca  pop rsi
000074b6341de7cb  pop rdi
000074b6341de7cc  pop rdx
000074b6341de7cd  pop rcx
000074b6341de7ce  pop rax
000074b6341de7cf  add rsp, 0x08
000074b6341de7d3  jmp 0x000074B6341DC1AA
000074b6341de7d8  call 0x000074B6340B52F0
000074b6341de7dd  jmp 0x000074B6341DC1B7
000074b6341de7e2  sub rsp, 0x08
000074b6341de7e6  push rax
000074b6341de7e7  push rcx
000074b6341de7e8  push rdx
000074b6341de7e9  push rdi
000074b6341de7ea  push rsi
000074b6341de7eb  push r8
000074b6341de7ed  push r9
000074b6341de7ef  push r10
000074b6341de7f1  push r11
000074b6341de7f3  sub rsp, 0xF0
000074b6341de7fa  vmovaps [rsp], xmm0
000074b6341de7ff  vmovaps [rsp+0x10], xmm1
000074b6341de805  vmovaps [rsp+0x20], xmm2
000074b6341de80b  vmovaps [rsp+0x30], xmm3
000074b6341de811  vmovaps [rsp+0x40], xmm4
000074b6341de817  vmovaps [rsp+0x50], xmm5
000074b6341de81d  vmovaps [rsp+0x60], xmm6
000074b6341de823  vmovaps [rsp+0x70], xmm7
000074b6341de829  vmovaps [rsp+0x80], xmm8
000074b6341de832  vmovaps [rsp+0x90], xmm9
000074b6341de83b  vmovaps [rsp+0xA0], xmm10
000074b6341de844  vmovaps [rsp+0xB0], xmm11
000074b6341de84d  vmovaps [rsp+0xC0], xmm12
000074b6341de856  vmovaps [rsp+0xD0], xmm13
000074b6341de85f  vmovaps [rsp+0xE0], xmm14
000074b6341de868  sub rsp, 0x30
000074b6341de86c  movaps [rsp], xmm15
000074b6341de871  movaps [rsp+0x10], xmm3
000074b6341de876  movaps [rsp+0x20], xmm7
000074b6341de87b  lea rdi, [rsp]
000074b6341de87f  mov esi, 0x00
000074b6341de884  mov rax, 0x5E1AA0A2F530
000074b6341de88e  call rax
000074b6341de890  movaps xmm15, [rsp]
000074b6341de895  add rsp, 0x30
000074b6341de899  vmovaps xmm0, [rsp]
000074b6341de89e  vmovaps xmm1, [rsp+0x10]
000074b6341de8a4  vmovaps xmm2, [rsp+0x20]
000074b6341de8aa  vmovaps xmm3, [rsp+0x30]
000074b6341de8b0  vmovaps xmm4, [rsp+0x40]
000074b6341de8b6  vmovaps xmm5, [rsp+0x50]
000074b6341de8bc  vmovaps xmm6, [rsp+0x60]
000074b6341de8c2  vmovaps xmm7, [rsp+0x70]
000074b6341de8c8  vmovaps xmm8, [rsp+0x80]
000074b6341de8d1  vmovaps xmm9, [rsp+0x90]
000074b6341de8da  vmovaps xmm10, [rsp+0xA0]
000074b6341de8e3  vmovaps xmm11, [rsp+0xB0]
000074b6341de8ec  vmovaps xmm12, [rsp+0xC0]
000074b6341de8f5  vmovaps xmm13, [rsp+0xD0]
000074b6341de8fe  vmovaps xmm14, [rsp+0xE0]
000074b6341de907  add rsp, 0xF0
000074b6341de90e  pop r11
000074b6341de910  pop r10
000074b6341de912  pop r9
000074b6341de914  pop r8
000074b6341de916  pop rsi
000074b6341de917  pop rdi
000074b6341de918  pop rdx
000074b6341de919  pop rcx
000074b6341de91a  pop rax
000074b6341de91b  add rsp, 0x08
000074b6341de91f  jmp 0x000074B6341DC1E3
000074b6341de924  sub rsp, 0x08
000074b6341de928  push rax
000074b6341de929  push rcx
000074b6341de92a  push rdx
000074b6341de92b  push rdi
000074b6341de92c  push rsi
000074b6341de92d  push r8
000074b6341de92f  push r9
000074b6341de931  push r10
000074b6341de933  push r11
000074b6341de935  sub rsp, 0xF0
000074b6341de93c  vmovaps [rsp], xmm0
000074b6341de941  vmovaps [rsp+0x10], xmm1
000074b6341de947  vmovaps [rsp+0x20], xmm2
000074b6341de94d  vmovaps [rsp+0x30], xmm4
000074b6341de953  vmovaps [rsp+0x40], xmm5
000074b6341de959  vmovaps [rsp+0x50], xmm6
000074b6341de95f  vmovaps [rsp+0x60], xmm7
000074b6341de965  vmovaps [rsp+0x70], xmm8
000074b6341de96b  vmovaps [rsp+0x80], xmm9
000074b6341de974  vmovaps [rsp+0x90], xmm10
000074b6341de97d  vmovaps [rsp+0xA0], xmm11
000074b6341de986  vmovaps [rsp+0xB0], xmm12
000074b6341de98f  vmovaps [rsp+0xC0], xmm13
000074b6341de998  vmovaps [rsp+0xD0], xmm14
000074b6341de9a1  vmovaps [rsp+0xE0], xmm15
000074b6341de9aa  sub rsp, 0x30
000074b6341de9ae  movaps [rsp], xmm3
000074b6341de9b2  movaps [rsp+0x10], xmm1
000074b6341de9b7  movaps [rsp+0x20], xmm15
000074b6341de9bd  lea rdi, [rsp]
000074b6341de9c1  mov esi, 0x00
000074b6341de9c6  mov rax, 0x5E1AA0A2F530
000074b6341de9d0  call rax
000074b6341de9d2  movaps xmm3, [rsp]
000074b6341de9d6  add rsp, 0x30
000074b6341de9da  vmovaps xmm0, [rsp]
000074b6341de9df  vmovaps xmm1, [rsp+0x10]
000074b6341de9e5  vmovaps xmm2, [rsp+0x20]
000074b6341de9eb  vmovaps xmm4, [rsp+0x30]
000074b6341de9f1  vmovaps xmm5, [rsp+0x40]
000074b6341de9f7  vmovaps xmm6, [rsp+0x50]
000074b6341de9fd  vmovaps xmm7, [rsp+0x60]
000074b6341dea03  vmovaps xmm8, [rsp+0x70]
000074b6341dea09  vmovaps xmm9, [rsp+0x80]
000074b6341dea12  vmovaps xmm10, [rsp+0x90]
000074b6341dea1b  vmovaps xmm11, [rsp+0xA0]
000074b6341dea24  vmovaps xmm12, [rsp+0xB0]
000074b6341dea2d  vmovaps xmm13, [rsp+0xC0]
000074b6341dea36  vmovaps xmm14, [rsp+0xD0]
000074b6341dea3f  vmovaps xmm15, [rsp+0xE0]
000074b6341dea48  add rsp, 0xF0
000074b6341dea4f  pop r11
000074b6341dea51  pop r10
000074b6341dea53  pop r9
000074b6341dea55  pop r8
000074b6341dea57  pop rsi
000074b6341dea58  pop rdi
000074b6341dea59  pop rdx
000074b6341dea5a  pop rcx
000074b6341dea5b  pop rax
000074b6341dea5c  add rsp, 0x08
000074b6341dea60  jmp 0x000074B6341DC272
000074b6341dea65  call 0x000074B6340B52F0
000074b6341dea6a  jmp 0x000074B6341DC27C
000074b6341dea6f  sub rsp, 0x08
000074b6341dea73  push rax
000074b6341dea74  push rcx
000074b6341dea75  push rdx
000074b6341dea76  push rdi
000074b6341dea77  push rsi
000074b6341dea78  push r8
000074b6341dea7a  push r9
000074b6341dea7c  push r10
000074b6341dea7e  push r11
000074b6341dea80  sub rsp, 0xF0
000074b6341dea87  vmovaps [rsp], xmm0
000074b6341dea8c  vmovaps [rsp+0x10], xmm1
000074b6341dea92  vmovaps [rsp+0x20], xmm2
000074b6341dea98  vmovaps [rsp+0x30], xmm3
000074b6341dea9e  vmovaps [rsp+0x40], xmm4
000074b6341deaa4  vmovaps [rsp+0x50], xmm5
000074b6341deaaa  vmovaps [rsp+0x60], xmm6
000074b6341deab0  vmovaps [rsp+0x70], xmm7
000074b6341deab6  vmovaps [rsp+0x80], xmm8
000074b6341deabf  vmovaps [rsp+0x90], xmm9
000074b6341deac8  vmovaps [rsp+0xA0], xmm10
000074b6341dead1  vmovaps [rsp+0xB0], xmm11
000074b6341deada  vmovaps [rsp+0xC0], xmm12
000074b6341deae3  vmovaps [rsp+0xD0], xmm13
000074b6341deaec  vmovaps [rsp+0xE0], xmm14
000074b6341deaf5  sub rsp, 0x30
000074b6341deaf9  movaps [rsp], xmm15
000074b6341deafe  movaps [rsp+0x10], xmm14
000074b6341deb04  movaps [rsp+0x20], xmm4
000074b6341deb09  lea rdi, [rsp]
000074b6341deb0d  mov esi, 0x00
000074b6341deb12  mov rax, 0x5E1AA0A2F530
000074b6341deb1c  call rax
000074b6341deb1e  movaps xmm15, [rsp]
000074b6341deb23  add rsp, 0x30
000074b6341deb27  vmovaps xmm0, [rsp]
000074b6341deb2c  vmovaps xmm1, [rsp+0x10]
000074b6341deb32  vmovaps xmm2, [rsp+0x20]
000074b6341deb38  vmovaps xmm3, [rsp+0x30]
000074b6341deb3e  vmovaps xmm4, [rsp+0x40]
000074b6341deb44  vmovaps xmm5, [rsp+0x50]
000074b6341deb4a  vmovaps xmm6, [rsp+0x60]
000074b6341deb50  vmovaps xmm7, [rsp+0x70]
000074b6341deb56  vmovaps xmm8, [rsp+0x80]
000074b6341deb5f  vmovaps xmm9, [rsp+0x90]
000074b6341deb68  vmovaps xmm10, [rsp+0xA0]
000074b6341deb71  vmovaps xmm11, [rsp+0xB0]
000074b6341deb7a  vmovaps xmm12, [rsp+0xC0]
000074b6341deb83  vmovaps xmm13, [rsp+0xD0]
000074b6341deb8c  vmovaps xmm14, [rsp+0xE0]
000074b6341deb95  add rsp, 0xF0
000074b6341deb9c  pop r11
000074b6341deb9e  pop r10
000074b6341deba0  pop r9
000074b6341deba2  pop r8
000074b6341deba4  pop rsi
000074b6341deba5  pop rdi
000074b6341deba6  pop rdx
000074b6341deba7  pop rcx
000074b6341deba8  pop rax
000074b6341deba9  add rsp, 0x08
000074b6341debad  jmp 0x000074B6341DC2AA
000074b6341debb2  sub rsp, 0x08
000074b6341debb6  push rax
000074b6341debb7  push rcx
000074b6341debb8  push rdx
000074b6341debb9  push rdi
000074b6341debba  push rsi
000074b6341debbb  push r8
000074b6341debbd  push r9
000074b6341debbf  push r10
000074b6341debc1  push r11
000074b6341debc3  sub rsp, 0xF0
000074b6341debca  vmovaps [rsp], xmm0
000074b6341debcf  vmovaps [rsp+0x10], xmm1
000074b6341debd5  vmovaps [rsp+0x20], xmm2
000074b6341debdb  vmovaps [rsp+0x30], xmm3
000074b6341debe1  vmovaps [rsp+0x40], xmm4
000074b6341debe7  vmovaps [rsp+0x50], xmm5
000074b6341debed  vmovaps [rsp+0x60], xmm6
000074b6341debf3  vmovaps [rsp+0x70], xmm7
000074b6341debf9  vmovaps [rsp+0x80], xmm8
000074b6341dec02  vmovaps [rsp+0x90], xmm9
000074b6341dec0b  vmovaps [rsp+0xA0], xmm10
000074b6341dec14  vmovaps [rsp+0xB0], xmm11
000074b6341dec1d  vmovaps [rsp+0xC0], xmm12
000074b6341dec26  vmovaps [rsp+0xD0], xmm13
000074b6341dec2f  vmovaps [rsp+0xE0], xmm15
000074b6341dec38  sub rsp, 0x30
000074b6341dec3c  movaps [rsp], xmm14
000074b6341dec41  movaps [rsp+0x10], xmm2
000074b6341dec46  movaps [rsp+0x20], xmm1
000074b6341dec4b  lea rdi, [rsp]
000074b6341dec4f  mov esi, 0x00
000074b6341dec54  mov rax, 0x5E1AA0A2F530
000074b6341dec5e  call rax
000074b6341dec60  movaps xmm14, [rsp]
000074b6341dec65  add rsp, 0x30
000074b6341dec69  vmovaps xmm0, [rsp]
000074b6341dec6e  vmovaps xmm1, [rsp+0x10]
000074b6341dec74  vmovaps xmm2, [rsp+0x20]
000074b6341dec7a  vmovaps xmm3, [rsp+0x30]
000074b6341dec80  vmovaps xmm4, [rsp+0x40]
000074b6341dec86  vmovaps xmm5, [rsp+0x50]
000074b6341dec8c  vmovaps xmm6, [rsp+0x60]
000074b6341dec92  vmovaps xmm7, [rsp+0x70]
000074b6341dec98  vmovaps xmm8, [rsp+0x80]
000074b6341deca1  vmovaps xmm9, [rsp+0x90]
000074b6341decaa  vmovaps xmm10, [rsp+0xA0]
000074b6341decb3  vmovaps xmm11, [rsp+0xB0]
000074b6341decbc  vmovaps xmm12, [rsp+0xC0]
000074b6341decc5  vmovaps xmm13, [rsp+0xD0]
000074b6341decce  vmovaps xmm15, [rsp+0xE0]
000074b6341decd7  add rsp, 0xF0
000074b6341decde  pop r11
000074b6341dece0  pop r10
000074b6341dece2  pop r9
000074b6341dece4  pop r8
000074b6341dece6  pop rsi
000074b6341dece7  pop rdi
000074b6341dece8  pop rdx
000074b6341dece9  pop rcx
000074b6341decea  pop rax
000074b6341deceb  add rsp, 0x08
000074b6341decef  jmp 0x000074B6341DC2D0
000074b6341decf4  sub rsp, 0x08
000074b6341decf8  push rax
000074b6341decf9  push rcx
000074b6341decfa  push rdx
000074b6341decfb  push rdi
000074b6341decfc  push rsi
000074b6341decfd  push r8
000074b6341decff  push r9
000074b6341ded01  push r10
000074b6341ded03  push r11
000074b6341ded05  sub rsp, 0xF0
000074b6341ded0c  vmovaps [rsp], xmm0
000074b6341ded11  vmovaps [rsp+0x10], xmm2
000074b6341ded17  vmovaps [rsp+0x20], xmm3
000074b6341ded1d  vmovaps [rsp+0x30], xmm4
000074b6341ded23  vmovaps [rsp+0x40], xmm5
000074b6341ded29  vmovaps [rsp+0x50], xmm6
000074b6341ded2f  vmovaps [rsp+0x60], xmm7
000074b6341ded35  vmovaps [rsp+0x70], xmm8
000074b6341ded3b  vmovaps [rsp+0x80], xmm9
000074b6341ded44  vmovaps [rsp+0x90], xmm10
000074b6341ded4d  vmovaps [rsp+0xA0], xmm11
000074b6341ded56  vmovaps [rsp+0xB0], xmm12
000074b6341ded5f  vmovaps [rsp+0xC0], xmm13
000074b6341ded68  vmovaps [rsp+0xD0], xmm14
000074b6341ded71  vmovaps [rsp+0xE0], xmm15
000074b6341ded7a  sub rsp, 0x30
000074b6341ded7e  movaps [rsp], xmm1
000074b6341ded82  movaps [rsp+0x10], xmm4
000074b6341ded87  movaps [rsp+0x20], xmm9
000074b6341ded8d  lea rdi, [rsp]
000074b6341ded91  mov esi, 0x00
000074b6341ded96  mov rax, 0x5E1AA0A2F530
000074b6341deda0  call rax
000074b6341deda2  movaps xmm1, [rsp]
000074b6341deda6  add rsp, 0x30
000074b6341dedaa  vmovaps xmm0, [rsp]
000074b6341dedaf  vmovaps xmm2, [rsp+0x10]
000074b6341dedb5  vmovaps xmm3, [rsp+0x20]
000074b6341dedbb  vmovaps xmm4, [rsp+0x30]
000074b6341dedc1  vmovaps xmm5, [rsp+0x40]
000074b6341dedc7  vmovaps xmm6, [rsp+0x50]
000074b6341dedcd  vmovaps xmm7, [rsp+0x60]
000074b6341dedd3  vmovaps xmm8, [rsp+0x70]
000074b6341dedd9  vmovaps xmm9, [rsp+0x80]
000074b6341dede2  vmovaps xmm10, [rsp+0x90]
000074b6341dedeb  vmovaps xmm11, [rsp+0xA0]
000074b6341dedf4  vmovaps xmm12, [rsp+0xB0]
000074b6341dedfd  vmovaps xmm13, [rsp+0xC0]
000074b6341dee06  vmovaps xmm14, [rsp+0xD0]
000074b6341dee0f  vmovaps xmm15, [rsp+0xE0]
000074b6341dee18  add rsp, 0xF0
000074b6341dee1f  pop r11
000074b6341dee21  pop r10
000074b6341dee23  pop r9
000074b6341dee25  pop r8
000074b6341dee27  pop rsi
000074b6341dee28  pop rdi
000074b6341dee29  pop rdx
000074b6341dee2a  pop rcx
000074b6341dee2b  pop rax
000074b6341dee2c  add rsp, 0x08
000074b6341dee30  jmp 0x000074B6341DC2EE
000074b6341dee35  sub rsp, 0x08
000074b6341dee39  push rax
000074b6341dee3a  push rcx
000074b6341dee3b  push rdx
000074b6341dee3c  push rdi
000074b6341dee3d  push rsi
000074b6341dee3e  push r8
000074b6341dee40  push r9
000074b6341dee42  push r10
000074b6341dee44  push r11
000074b6341dee46  sub rsp, 0xF0
000074b6341dee4d  vmovaps [rsp], xmm0
000074b6341dee52  vmovaps [rsp+0x10], xmm1
000074b6341dee58  vmovaps [rsp+0x20], xmm2
000074b6341dee5e  vmovaps [rsp+0x30], xmm3
000074b6341dee64  vmovaps [rsp+0x40], xmm5
000074b6341dee6a  vmovaps [rsp+0x50], xmm6
000074b6341dee70  vmovaps [rsp+0x60], xmm7
000074b6341dee76  vmovaps [rsp+0x70], xmm8
000074b6341dee7c  vmovaps [rsp+0x80], xmm9
000074b6341dee85  vmovaps [rsp+0x90], xmm10
000074b6341dee8e  vmovaps [rsp+0xA0], xmm11
000074b6341dee97  vmovaps [rsp+0xB0], xmm12
000074b6341deea0  vmovaps [rsp+0xC0], xmm13
000074b6341deea9  vmovaps [rsp+0xD0], xmm14
000074b6341deeb2  vmovaps [rsp+0xE0], xmm15
000074b6341deebb  sub rsp, 0x30
000074b6341deebf  movaps [rsp], xmm4
000074b6341deec3  movaps [rsp+0x10], xmm2
000074b6341deec8  movaps [rsp+0x20], xmm9
000074b6341deece  lea rdi, [rsp]
000074b6341deed2  mov esi, 0x00
000074b6341deed7  mov rax, 0x5E1AA0A2F530
000074b6341deee1  call rax
000074b6341deee3  movaps xmm4, [rsp]
000074b6341deee7  add rsp, 0x30
000074b6341deeeb  vmovaps xmm0, [rsp]
000074b6341deef0  vmovaps xmm1, [rsp+0x10]
000074b6341deef6  vmovaps xmm2, [rsp+0x20]
000074b6341deefc  vmovaps xmm3, [rsp+0x30]
000074b6341def02  vmovaps xmm5, [rsp+0x40]
000074b6341def08  vmovaps xmm6, [rsp+0x50]
000074b6341def0e  vmovaps xmm7, [rsp+0x60]
000074b6341def14  vmovaps xmm8, [rsp+0x70]
000074b6341def1a  vmovaps xmm9, [rsp+0x80]
000074b6341def23  vmovaps xmm10, [rsp+0x90]
000074b6341def2c  vmovaps xmm11, [rsp+0xA0]
000074b6341def35  vmovaps xmm12, [rsp+0xB0]
000074b6341def3e  vmovaps xmm13, [rsp+0xC0]
000074b6341def47  vmovaps xmm14, [rsp+0xD0]
000074b6341def50  vmovaps xmm15, [rsp+0xE0]
000074b6341def59  add rsp, 0xF0
000074b6341def60  pop r11
000074b6341def62  pop r10
000074b6341def64  pop r9
000074b6341def66  pop r8
000074b6341def68  pop rsi
000074b6341def69  pop rdi
000074b6341def6a  pop rdx
000074b6341def6b  pop rcx
000074b6341def6c  pop rax
000074b6341def6d  add rsp, 0x08
000074b6341def71  jmp 0x000074B6341DC31E
000074b6341def76  sub rsp, 0x08
000074b6341def7a  push rax
000074b6341def7b  push rcx
000074b6341def7c  push rdx
000074b6341def7d  push rdi
000074b6341def7e  push rsi
000074b6341def7f  push r8
000074b6341def81  push r9
000074b6341def83  push r10
000074b6341def85  push r11
000074b6341def87  sub rsp, 0xF0
000074b6341def8e  vmovaps [rsp], xmm0
000074b6341def93  vmovaps [rsp+0x10], xmm1
000074b6341def99  vmovaps [rsp+0x20], xmm2
000074b6341def9f  vmovaps [rsp+0x30], xmm3
000074b6341defa5  vmovaps [rsp+0x40], xmm4
000074b6341defab  vmovaps [rsp+0x50], xmm5
000074b6341defb1  vmovaps [rsp+0x60], xmm6
000074b6341defb7  vmovaps [rsp+0x70], xmm7
000074b6341defbd  vmovaps [rsp+0x80], xmm8
000074b6341defc6  vmovaps [rsp+0x90], xmm10
000074b6341defcf  vmovaps [rsp+0xA0], xmm11
000074b6341defd8  vmovaps [rsp+0xB0], xmm12
000074b6341defe1  vmovaps [rsp+0xC0], xmm13
000074b6341defea  vmovaps [rsp+0xD0], xmm14
000074b6341deff3  vmovaps [rsp+0xE0], xmm15
000074b6341deffc  sub rsp, 0x30
000074b6341df000  movaps [rsp], xmm9
000074b6341df005  movaps [rsp+0x10], xmm2
000074b6341df00a  movaps [rsp+0x20], xmm1
000074b6341df00f  lea rdi, [rsp]
000074b6341df013  mov esi, 0x00
000074b6341df018  mov rax, 0x5E1AA0A2F530
000074b6341df022  call rax
000074b6341df024  movaps xmm9, [rsp]
000074b6341df029  add rsp, 0x30
000074b6341df02d  vmovaps xmm0, [rsp]
000074b6341df032  vmovaps xmm1, [rsp+0x10]
000074b6341df038  vmovaps xmm2, [rsp+0x20]
000074b6341df03e  vmovaps xmm3, [rsp+0x30]
000074b6341df044  vmovaps xmm4, [rsp+0x40]
000074b6341df04a  vmovaps xmm5, [rsp+0x50]
000074b6341df050  vmovaps xmm6, [rsp+0x60]
000074b6341df056  vmovaps xmm7, [rsp+0x70]
000074b6341df05c  vmovaps xmm8, [rsp+0x80]
000074b6341df065  vmovaps xmm10, [rsp+0x90]
000074b6341df06e  vmovaps xmm11, [rsp+0xA0]
000074b6341df077  vmovaps xmm12, [rsp+0xB0]
000074b6341df080  vmovaps xmm13, [rsp+0xC0]
000074b6341df089  vmovaps xmm14, [rsp+0xD0]
000074b6341df092  vmovaps xmm15, [rsp+0xE0]
000074b6341df09b  add rsp, 0xF0
000074b6341df0a2  pop r11
000074b6341df0a4  pop r10
000074b6341df0a6  pop r9
000074b6341df0a8  pop r8
000074b6341df0aa  pop rsi
000074b6341df0ab  pop rdi
000074b6341df0ac  pop rdx
000074b6341df0ad  pop rcx
000074b6341df0ae  pop rax
000074b6341df0af  add rsp, 0x08
000074b6341df0b3  jmp 0x000074B6341DC354
000074b6341df0b8  sub rsp, 0x08
000074b6341df0bc  push rax
000074b6341df0bd  push rcx
000074b6341df0be  push rdx
000074b6341df0bf  push rdi
000074b6341df0c0  push rsi
000074b6341df0c1  push r8
000074b6341df0c3  push r9
000074b6341df0c5  push r10
000074b6341df0c7  push r11
000074b6341df0c9  sub rsp, 0xF0
000074b6341df0d0  vmovaps [rsp], xmm0
000074b6341df0d5  vmovaps [rsp+0x10], xmm2
000074b6341df0db  vmovaps [rsp+0x20], xmm3
000074b6341df0e1  vmovaps [rsp+0x30], xmm4
000074b6341df0e7  vmovaps [rsp+0x40], xmm5
000074b6341df0ed  vmovaps [rsp+0x50], xmm6
000074b6341df0f3  vmovaps [rsp+0x60], xmm7
000074b6341df0f9  vmovaps [rsp+0x70], xmm8
000074b6341df0ff  vmovaps [rsp+0x80], xmm9
000074b6341df108  vmovaps [rsp+0x90], xmm10
000074b6341df111  vmovaps [rsp+0xA0], xmm11
000074b6341df11a  vmovaps [rsp+0xB0], xmm12
000074b6341df123  vmovaps [rsp+0xC0], xmm13
000074b6341df12c  vmovaps [rsp+0xD0], xmm14
000074b6341df135  vmovaps [rsp+0xE0], xmm15
000074b6341df13e  sub rsp, 0x30
000074b6341df142  movaps [rsp], xmm1
000074b6341df146  movaps [rsp+0x10], xmm15
000074b6341df14c  movaps [rsp+0x20], xmm6
000074b6341df151  lea rdi, [rsp]
000074b6341df155  mov esi, 0x00
000074b6341df15a  mov rax, 0x5E1AA0A2F530
000074b6341df164  call rax
000074b6341df166  movaps xmm1, [rsp]
000074b6341df16a  add rsp, 0x30
000074b6341df16e  vmovaps xmm0, [rsp]
000074b6341df173  vmovaps xmm2, [rsp+0x10]
000074b6341df179  vmovaps xmm3, [rsp+0x20]
000074b6341df17f  vmovaps xmm4, [rsp+0x30]
000074b6341df185  vmovaps xmm5, [rsp+0x40]
000074b6341df18b  vmovaps xmm6, [rsp+0x50]
000074b6341df191  vmovaps xmm7, [rsp+0x60]
000074b6341df197  vmovaps xmm8, [rsp+0x70]
000074b6341df19d  vmovaps xmm9, [rsp+0x80]
000074b6341df1a6  vmovaps xmm10, [rsp+0x90]
000074b6341df1af  vmovaps xmm11, [rsp+0xA0]
000074b6341df1b8  vmovaps xmm12, [rsp+0xB0]
000074b6341df1c1  vmovaps xmm13, [rsp+0xC0]
000074b6341df1ca  vmovaps xmm14, [rsp+0xD0]
000074b6341df1d3  vmovaps xmm15, [rsp+0xE0]
000074b6341df1dc  add rsp, 0xF0
000074b6341df1e3  pop r11
000074b6341df1e5  pop r10
000074b6341df1e7  pop r9
000074b6341df1e9  pop r8
000074b6341df1eb  pop rsi
000074b6341df1ec  pop rdi
000074b6341df1ed  pop rdx
000074b6341df1ee  pop rcx
000074b6341df1ef  pop rax
000074b6341df1f0  add rsp, 0x08
000074b6341df1f4  jmp 0x000074B6341DC375
000074b6341df1f9  sub rsp, 0x08
000074b6341df1fd  push rax
000074b6341df1fe  push rcx
000074b6341df1ff  push rdx
000074b6341df200  push rdi
000074b6341df201  push rsi
000074b6341df202  push r8
000074b6341df204  push r9
000074b6341df206  push r10
000074b6341df208  push r11
000074b6341df20a  sub rsp, 0xF0
000074b6341df211  vmovaps [rsp], xmm0
000074b6341df216  vmovaps [rsp+0x10], xmm1
000074b6341df21c  vmovaps [rsp+0x20], xmm2
000074b6341df222  vmovaps [rsp+0x30], xmm3
000074b6341df228  vmovaps [rsp+0x40], xmm4
000074b6341df22e  vmovaps [rsp+0x50], xmm5
000074b6341df234  vmovaps [rsp+0x60], xmm6
000074b6341df23a  vmovaps [rsp+0x70], xmm7
000074b6341df240  vmovaps [rsp+0x80], xmm8
000074b6341df249  vmovaps [rsp+0x90], xmm9
000074b6341df252  vmovaps [rsp+0xA0], xmm10
000074b6341df25b  vmovaps [rsp+0xB0], xmm11
000074b6341df264  vmovaps [rsp+0xC0], xmm12
000074b6341df26d  vmovaps [rsp+0xD0], xmm13
000074b6341df276  vmovaps [rsp+0xE0], xmm14
000074b6341df27f  sub rsp, 0x30
000074b6341df283  movaps [rsp], xmm15
000074b6341df288  movaps [rsp+0x10], xmm5
000074b6341df28d  movaps [rsp+0x20], xmm3
000074b6341df292  lea rdi, [rsp]
000074b6341df296  mov esi, 0x00
000074b6341df29b  mov rax, 0x5E1AA0A2F530
000074b6341df2a5  call rax
000074b6341df2a7  movaps xmm15, [rsp]
000074b6341df2ac  add rsp, 0x30
000074b6341df2b0  vmovaps xmm0, [rsp]
000074b6341df2b5  vmovaps xmm1, [rsp+0x10]
000074b6341df2bb  vmovaps xmm2, [rsp+0x20]
000074b6341df2c1  vmovaps xmm3, [rsp+0x30]
000074b6341df2c7  vmovaps xmm4, [rsp+0x40]
000074b6341df2cd  vmovaps xmm5, [rsp+0x50]
000074b6341df2d3  vmovaps xmm6, [rsp+0x60]
000074b6341df2d9  vmovaps xmm7, [rsp+0x70]
000074b6341df2df  vmovaps xmm8, [rsp+0x80]
000074b6341df2e8  vmovaps xmm9, [rsp+0x90]
000074b6341df2f1  vmovaps xmm10, [rsp+0xA0]
000074b6341df2fa  vmovaps xmm11, [rsp+0xB0]
000074b6341df303  vmovaps xmm12, [rsp+0xC0]
000074b6341df30c  vmovaps xmm13, [rsp+0xD0]
000074b6341df315  vmovaps xmm14, [rsp+0xE0]
000074b6341df31e  add rsp, 0xF0
000074b6341df325  pop r11
000074b6341df327  pop r10
000074b6341df329  pop r9
000074b6341df32b  pop r8
000074b6341df32d  pop rsi
000074b6341df32e  pop rdi
000074b6341df32f  pop rdx
000074b6341df330  pop rcx
000074b6341df331  pop rax
000074b6341df332  add rsp, 0x08
000074b6341df336  jmp 0x000074B6341DC38F
000074b6341df33b  sub rsp, 0x08
000074b6341df33f  push rax
000074b6341df340  push rcx
000074b6341df341  push rdx
000074b6341df342  push rdi
000074b6341df343  push rsi
000074b6341df344  push r8
000074b6341df346  push r9
000074b6341df348  push r10
000074b6341df34a  push r11
000074b6341df34c  sub rsp, 0xF0
000074b6341df353  vmovaps [rsp], xmm0
000074b6341df358  vmovaps [rsp+0x10], xmm1
000074b6341df35e  vmovaps [rsp+0x20], xmm2
000074b6341df364  vmovaps [rsp+0x30], xmm3
000074b6341df36a  vmovaps [rsp+0x40], xmm4
000074b6341df370  vmovaps [rsp+0x50], xmm6
000074b6341df376  vmovaps [rsp+0x60], xmm7
000074b6341df37c  vmovaps [rsp+0x70], xmm8
000074b6341df382  vmovaps [rsp+0x80], xmm9
000074b6341df38b  vmovaps [rsp+0x90], xmm10
000074b6341df394  vmovaps [rsp+0xA0], xmm11
000074b6341df39d  vmovaps [rsp+0xB0], xmm12
000074b6341df3a6  vmovaps [rsp+0xC0], xmm13
000074b6341df3af  vmovaps [rsp+0xD0], xmm14
000074b6341df3b8  vmovaps [rsp+0xE0], xmm15
000074b6341df3c1  sub rsp, 0x30
000074b6341df3c5  movaps [rsp], xmm5
000074b6341df3c9  movaps [rsp+0x10], xmm8
000074b6341df3cf  movaps [rsp+0x20], xmm6
000074b6341df3d4  lea rdi, [rsp]
000074b6341df3d8  mov esi, 0x00
000074b6341df3dd  mov rax, 0x5E1AA0A2F530
000074b6341df3e7  call rax
000074b6341df3e9  movaps xmm5, [rsp]
000074b6341df3ed  add rsp, 0x30
000074b6341df3f1  vmovaps xmm0, [rsp]
000074b6341df3f6  vmovaps xmm1, [rsp+0x10]
000074b6341df3fc  vmovaps xmm2, [rsp+0x20]
000074b6341df402  vmovaps xmm3, [rsp+0x30]
000074b6341df408  vmovaps xmm4, [rsp+0x40]
000074b6341df40e  vmovaps xmm6, [rsp+0x50]
000074b6341df414  vmovaps xmm7, [rsp+0x60]
000074b6341df41a  vmovaps xmm8, [rsp+0x70]
000074b6341df420  vmovaps xmm9, [rsp+0x80]
000074b6341df429  vmovaps xmm10, [rsp+0x90]
000074b6341df432  vmovaps xmm11, [rsp+0xA0]
000074b6341df43b  vmovaps xmm12, [rsp+0xB0]
000074b6341df444  vmovaps xmm13, [rsp+0xC0]
000074b6341df44d  vmovaps xmm14, [rsp+0xD0]
000074b6341df456  vmovaps xmm15, [rsp+0xE0]
000074b6341df45f  add rsp, 0xF0
000074b6341df466  pop r11
000074b6341df468  pop r10
000074b6341df46a  pop r9
000074b6341df46c  pop r8
000074b6341df46e  pop rsi
000074b6341df46f  pop rdi
000074b6341df470  pop rdx
000074b6341df471  pop rcx
000074b6341df472  pop rax
000074b6341df473  add rsp, 0x08
000074b6341df477  jmp 0x000074B6341DC3B3
000074b6341df47c  sub rsp, 0x08
000074b6341df480  push rax
000074b6341df481  push rcx
000074b6341df482  push rdx
000074b6341df483  push rdi
000074b6341df484  push rsi
000074b6341df485  push r8
000074b6341df487  push r9
000074b6341df489  push r10
000074b6341df48b  push r11
000074b6341df48d  sub rsp, 0xF0
000074b6341df494  vmovaps [rsp], xmm0
000074b6341df499  vmovaps [rsp+0x10], xmm1
000074b6341df49f  vmovaps [rsp+0x20], xmm2
000074b6341df4a5  vmovaps [rsp+0x30], xmm3
000074b6341df4ab  vmovaps [rsp+0x40], xmm4
000074b6341df4b1  vmovaps [rsp+0x50], xmm5
000074b6341df4b7  vmovaps [rsp+0x60], xmm7
000074b6341df4bd  vmovaps [rsp+0x70], xmm8
000074b6341df4c3  vmovaps [rsp+0x80], xmm9
000074b6341df4cc  vmovaps [rsp+0x90], xmm10
000074b6341df4d5  vmovaps [rsp+0xA0], xmm11
000074b6341df4de  vmovaps [rsp+0xB0], xmm12
000074b6341df4e7  vmovaps [rsp+0xC0], xmm13
000074b6341df4f0  vmovaps [rsp+0xD0], xmm14
000074b6341df4f9  vmovaps [rsp+0xE0], xmm15
000074b6341df502  sub rsp, 0x30
000074b6341df506  movaps [rsp], xmm6
000074b6341df50a  movaps [rsp+0x10], xmm10
000074b6341df510  movaps [rsp+0x20], xmm8
000074b6341df516  lea rdi, [rsp]
000074b6341df51a  mov esi, 0x00
000074b6341df51f  mov rax, 0x5E1AA0A2F530
000074b6341df529  call rax
000074b6341df52b  movaps xmm6, [rsp]
000074b6341df52f  add rsp, 0x30
000074b6341df533  vmovaps xmm0, [rsp]
000074b6341df538  vmovaps xmm1, [rsp+0x10]
000074b6341df53e  vmovaps xmm2, [rsp+0x20]
000074b6341df544  vmovaps xmm3, [rsp+0x30]
000074b6341df54a  vmovaps xmm4, [rsp+0x40]
000074b6341df550  vmovaps xmm5, [rsp+0x50]
000074b6341df556  vmovaps xmm7, [rsp+0x60]
000074b6341df55c  vmovaps xmm8, [rsp+0x70]
000074b6341df562  vmovaps xmm9, [rsp+0x80]
000074b6341df56b  vmovaps xmm10, [rsp+0x90]
000074b6341df574  vmovaps xmm11, [rsp+0xA0]
000074b6341df57d  vmovaps xmm12, [rsp+0xB0]
000074b6341df586  vmovaps xmm13, [rsp+0xC0]
000074b6341df58f  vmovaps xmm14, [rsp+0xD0]
000074b6341df598  vmovaps xmm15, [rsp+0xE0]
000074b6341df5a1  add rsp, 0xF0
000074b6341df5a8  pop r11
000074b6341df5aa  pop r10
000074b6341df5ac  pop r9
000074b6341df5ae  pop r8
000074b6341df5b0  pop rsi
000074b6341df5b1  pop rdi
000074b6341df5b2  pop rdx
000074b6341df5b3  pop rcx
000074b6341df5b4  pop rax
000074b6341df5b5  add rsp, 0x08
000074b6341df5b9  jmp 0x000074B6341DC3D8
000074b6341df5be  sub rsp, 0x08
000074b6341df5c2  push rax
000074b6341df5c3  push rcx
000074b6341df5c4  push rdx
000074b6341df5c5  push rdi
000074b6341df5c6  push rsi
000074b6341df5c7  push r8
000074b6341df5c9  push r9
000074b6341df5cb  push r10
000074b6341df5cd  push r11
000074b6341df5cf  sub rsp, 0xF0
000074b6341df5d6  vmovaps [rsp], xmm0
000074b6341df5db  vmovaps [rsp+0x10], xmm1
000074b6341df5e1  vmovaps [rsp+0x20], xmm2
000074b6341df5e7  vmovaps [rsp+0x30], xmm3
000074b6341df5ed  vmovaps [rsp+0x40], xmm4
000074b6341df5f3  vmovaps [rsp+0x50], xmm5
000074b6341df5f9  vmovaps [rsp+0x60], xmm6
000074b6341df5ff  vmovaps [rsp+0x70], xmm7
000074b6341df605  vmovaps [rsp+0x80], xmm8
000074b6341df60e  vmovaps [rsp+0x90], xmm9
000074b6341df617  vmovaps [rsp+0xA0], xmm11
000074b6341df620  vmovaps [rsp+0xB0], xmm12
000074b6341df629  vmovaps [rsp+0xC0], xmm13
000074b6341df632  vmovaps [rsp+0xD0], xmm14
000074b6341df63b  vmovaps [rsp+0xE0], xmm15
000074b6341df644  sub rsp, 0x30
000074b6341df648  movaps [rsp], xmm10
000074b6341df64d  movaps [rsp+0x10], xmm8
000074b6341df653  movaps [rsp+0x20], xmm14
000074b6341df659  lea rdi, [rsp]
000074b6341df65d  mov esi, 0x00
000074b6341df662  mov rax, 0x5E1AA0A2F530
000074b6341df66c  call rax
000074b6341df66e  movaps xmm10, [rsp]
000074b6341df673  add rsp, 0x30
000074b6341df677  vmovaps xmm0, [rsp]
000074b6341df67c  vmovaps xmm1, [rsp+0x10]
000074b6341df682  vmovaps xmm2, [rsp+0x20]
000074b6341df688  vmovaps xmm3, [rsp+0x30]
000074b6341df68e  vmovaps xmm4, [rsp+0x40]
000074b6341df694  vmovaps xmm5, [rsp+0x50]
000074b6341df69a  vmovaps xmm6, [rsp+0x60]
000074b6341df6a0  vmovaps xmm7, [rsp+0x70]
000074b6341df6a6  vmovaps xmm8, [rsp+0x80]
000074b6341df6af  vmovaps xmm9, [rsp+0x90]
000074b6341df6b8  vmovaps xmm11, [rsp+0xA0]
000074b6341df6c1  vmovaps xmm12, [rsp+0xB0]
000074b6341df6ca  vmovaps xmm13, [rsp+0xC0]
000074b6341df6d3  vmovaps xmm14, [rsp+0xD0]
000074b6341df6dc  vmovaps xmm15, [rsp+0xE0]
000074b6341df6e5  add rsp, 0xF0
000074b6341df6ec  pop r11
000074b6341df6ee  pop r10
000074b6341df6f0  pop r9
000074b6341df6f2  pop r8
000074b6341df6f4  pop rsi
000074b6341df6f5  pop rdi
000074b6341df6f6  pop rdx
000074b6341df6f7  pop rcx
000074b6341df6f8  pop rax
000074b6341df6f9  add rsp, 0x08
000074b6341df6fd  jmp 0x000074B6341DC3F8
000074b6341df702  sub rsp, 0x08
000074b6341df706  push rax
000074b6341df707  push rcx
000074b6341df708  push rdx
000074b6341df709  push rdi
000074b6341df70a  push rsi
000074b6341df70b  push r8
000074b6341df70d  push r9
000074b6341df70f  push r10
000074b6341df711  push r11
000074b6341df713  sub rsp, 0xF0
000074b6341df71a  vmovaps [rsp], xmm0
000074b6341df71f  vmovaps [rsp+0x10], xmm1
000074b6341df725  vmovaps [rsp+0x20], xmm2
000074b6341df72b  vmovaps [rsp+0x30], xmm3
000074b6341df731  vmovaps [rsp+0x40], xmm4
000074b6341df737  vmovaps [rsp+0x50], xmm5
000074b6341df73d  vmovaps [rsp+0x60], xmm6
000074b6341df743  vmovaps [rsp+0x70], xmm7
000074b6341df749  vmovaps [rsp+0x80], xmm8
000074b6341df752  vmovaps [rsp+0x90], xmm9
000074b6341df75b  vmovaps [rsp+0xA0], xmm10
000074b6341df764  vmovaps [rsp+0xB0], xmm11
000074b6341df76d  vmovaps [rsp+0xC0], xmm12
000074b6341df776  vmovaps [rsp+0xD0], xmm13
000074b6341df77f  vmovaps [rsp+0xE0], xmm15
000074b6341df788  sub rsp, 0x30
000074b6341df78c  movaps [rsp], xmm14
000074b6341df791  movaps [rsp+0x10], xmm8
000074b6341df797  movaps [rsp+0x20], xmm4
000074b6341df79c  lea rdi, [rsp]
000074b6341df7a0  mov esi, 0x00
000074b6341df7a5  mov rax, 0x5E1AA0A2F530
000074b6341df7af  call rax
000074b6341df7b1  movaps xmm14, [rsp]
000074b6341df7b6  add rsp, 0x30
000074b6341df7ba  vmovaps xmm0, [rsp]
000074b6341df7bf  vmovaps xmm1, [rsp+0x10]
000074b6341df7c5  vmovaps xmm2, [rsp+0x20]
000074b6341df7cb  vmovaps xmm3, [rsp+0x30]
000074b6341df7d1  vmovaps xmm4, [rsp+0x40]
000074b6341df7d7  vmovaps xmm5, [rsp+0x50]
000074b6341df7dd  vmovaps xmm6, [rsp+0x60]
000074b6341df7e3  vmovaps xmm7, [rsp+0x70]
000074b6341df7e9  vmovaps xmm8, [rsp+0x80]
000074b6341df7f2  vmovaps xmm9, [rsp+0x90]
000074b6341df7fb  vmovaps xmm10, [rsp+0xA0]
000074b6341df804  vmovaps xmm11, [rsp+0xB0]
000074b6341df80d  vmovaps xmm12, [rsp+0xC0]
000074b6341df816  vmovaps xmm13, [rsp+0xD0]
000074b6341df81f  vmovaps xmm15, [rsp+0xE0]
000074b6341df828  add rsp, 0xF0
000074b6341df82f  pop r11
000074b6341df831  pop r10
000074b6341df833  pop r9
000074b6341df835  pop r8
000074b6341df837  pop rsi
000074b6341df838  pop rdi
000074b6341df839  pop rdx
000074b6341df83a  pop rcx
000074b6341df83b  pop rax
000074b6341df83c  add rsp, 0x08
000074b6341df840  jmp 0x000074B6341DC418
000074b6341df845  sub rsp, 0x08
000074b6341df849  push rax
000074b6341df84a  push rcx
000074b6341df84b  push rdx
000074b6341df84c  push rdi
000074b6341df84d  push rsi
000074b6341df84e  push r8
000074b6341df850  push r9
000074b6341df852  push r10
000074b6341df854  push r11
000074b6341df856  sub rsp, 0xF0
000074b6341df85d  vmovaps [rsp], xmm0
000074b6341df862  vmovaps [rsp+0x10], xmm1
000074b6341df868  vmovaps [rsp+0x20], xmm2
000074b6341df86e  vmovaps [rsp+0x30], xmm3
000074b6341df874  vmovaps [rsp+0x40], xmm5
000074b6341df87a  vmovaps [rsp+0x50], xmm6
000074b6341df880  vmovaps [rsp+0x60], xmm7
000074b6341df886  vmovaps [rsp+0x70], xmm8
000074b6341df88c  vmovaps [rsp+0x80], xmm9
000074b6341df895  vmovaps [rsp+0x90], xmm10
000074b6341df89e  vmovaps [rsp+0xA0], xmm11
000074b6341df8a7  vmovaps [rsp+0xB0], xmm12
000074b6341df8b0  vmovaps [rsp+0xC0], xmm13
000074b6341df8b9  vmovaps [rsp+0xD0], xmm14
000074b6341df8c2  vmovaps [rsp+0xE0], xmm15
000074b6341df8cb  sub rsp, 0x30
000074b6341df8cf  movaps [rsp], xmm4
000074b6341df8d3  movaps [rsp+0x10], xmm13
000074b6341df8d9  movaps [rsp+0x20], xmm8
000074b6341df8df  lea rdi, [rsp]
000074b6341df8e3  mov esi, 0x00
000074b6341df8e8  mov rax, 0x5E1AA0A2F530
000074b6341df8f2  call rax
000074b6341df8f4  movaps xmm4, [rsp]
000074b6341df8f8  add rsp, 0x30
000074b6341df8fc  vmovaps xmm0, [rsp]
000074b6341df901  vmovaps xmm1, [rsp+0x10]
000074b6341df907  vmovaps xmm2, [rsp+0x20]
000074b6341df90d  vmovaps xmm3, [rsp+0x30]
000074b6341df913  vmovaps xmm5, [rsp+0x40]
000074b6341df919  vmovaps xmm6, [rsp+0x50]
000074b6341df91f  vmovaps xmm7, [rsp+0x60]
000074b6341df925  vmovaps xmm8, [rsp+0x70]
000074b6341df92b  vmovaps xmm9, [rsp+0x80]
000074b6341df934  vmovaps xmm10, [rsp+0x90]
000074b6341df93d  vmovaps xmm11, [rsp+0xA0]
000074b6341df946  vmovaps xmm12, [rsp+0xB0]
000074b6341df94f  vmovaps xmm13, [rsp+0xC0]
000074b6341df958  vmovaps xmm14, [rsp+0xD0]
000074b6341df961  vmovaps xmm15, [rsp+0xE0]
000074b6341df96a  add rsp, 0xF0
000074b6341df971  pop r11
000074b6341df973  pop r10
000074b6341df975  pop r9
000074b6341df977  pop r8
000074b6341df979  pop rsi
000074b6341df97a  pop rdi
000074b6341df97b  pop rdx
000074b6341df97c  pop rcx
000074b6341df97d  pop rax
000074b6341df97e  add rsp, 0x08
000074b6341df982  jmp 0x000074B6341DC43D
000074b6341df987  sub rsp, 0x08
000074b6341df98b  push rax
000074b6341df98c  push rcx
000074b6341df98d  push rdx
000074b6341df98e  push rdi
000074b6341df98f  push rsi
000074b6341df990  push r8
000074b6341df992  push r9
000074b6341df994  push r10
000074b6341df996  push r11
000074b6341df998  sub rsp, 0xF0
000074b6341df99f  vmovaps [rsp], xmm0
000074b6341df9a4  vmovaps [rsp+0x10], xmm1
000074b6341df9aa  vmovaps [rsp+0x20], xmm2
000074b6341df9b0  vmovaps [rsp+0x30], xmm3
000074b6341df9b6  vmovaps [rsp+0x40], xmm4
000074b6341df9bc  vmovaps [rsp+0x50], xmm5
000074b6341df9c2  vmovaps [rsp+0x60], xmm6
000074b6341df9c8  vmovaps [rsp+0x70], xmm7
000074b6341df9ce  vmovaps [rsp+0x80], xmm8
000074b6341df9d7  vmovaps [rsp+0x90], xmm9
000074b6341df9e0  vmovaps [rsp+0xA0], xmm10
000074b6341df9e9  vmovaps [rsp+0xB0], xmm11
000074b6341df9f2  vmovaps [rsp+0xC0], xmm12
000074b6341df9fb  vmovaps [rsp+0xD0], xmm14
000074b6341dfa04  vmovaps [rsp+0xE0], xmm15
000074b6341dfa0d  sub rsp, 0x30
000074b6341dfa11  movaps [rsp], xmm13
000074b6341dfa16  movaps [rsp+0x10], xmm15
000074b6341dfa1c  movaps [rsp+0x20], xmm9
000074b6341dfa22  lea rdi, [rsp]
000074b6341dfa26  mov esi, 0x00
000074b6341dfa2b  mov rax, 0x5E1AA0A2F530
000074b6341dfa35  call rax
000074b6341dfa37  movaps xmm13, [rsp]
000074b6341dfa3c  add rsp, 0x30
000074b6341dfa40  vmovaps xmm0, [rsp]
000074b6341dfa45  vmovaps xmm1, [rsp+0x10]
000074b6341dfa4b  vmovaps xmm2, [rsp+0x20]
000074b6341dfa51  vmovaps xmm3, [rsp+0x30]
000074b6341dfa57  vmovaps xmm4, [rsp+0x40]
000074b6341dfa5d  vmovaps xmm5, [rsp+0x50]
000074b6341dfa63  vmovaps xmm6, [rsp+0x60]
000074b6341dfa69  vmovaps xmm7, [rsp+0x70]
000074b6341dfa6f  vmovaps xmm8, [rsp+0x80]
000074b6341dfa78  vmovaps xmm9, [rsp+0x90]
000074b6341dfa81  vmovaps xmm10, [rsp+0xA0]
000074b6341dfa8a  vmovaps xmm11, [rsp+0xB0]
000074b6341dfa93  vmovaps xmm12, [rsp+0xC0]
000074b6341dfa9c  vmovaps xmm14, [rsp+0xD0]
000074b6341dfaa5  vmovaps xmm15, [rsp+0xE0]
000074b6341dfaae  add rsp, 0xF0
000074b6341dfab5  pop r11
000074b6341dfab7  pop r10
000074b6341dfab9  pop r9
000074b6341dfabb  pop r8
000074b6341dfabd  pop rsi
000074b6341dfabe  pop rdi
000074b6341dfabf  pop rdx
000074b6341dfac0  pop rcx
000074b6341dfac1  pop rax
000074b6341dfac2  add rsp, 0x08
000074b6341dfac6  jmp 0x000074B6341DC458
000074b6341dfacb  sub rsp, 0x08
000074b6341dfacf  push rax
000074b6341dfad0  push rcx
000074b6341dfad1  push rdx
000074b6341dfad2  push rdi
000074b6341dfad3  push rsi
000074b6341dfad4  push r8
000074b6341dfad6  push r9
000074b6341dfad8  push r10
000074b6341dfada  push r11
000074b6341dfadc  sub rsp, 0xF0
000074b6341dfae3  vmovaps [rsp], xmm0
000074b6341dfae8  vmovaps [rsp+0x10], xmm1
000074b6341dfaee  vmovaps [rsp+0x20], xmm2
000074b6341dfaf4  vmovaps [rsp+0x30], xmm3
000074b6341dfafa  vmovaps [rsp+0x40], xmm4
000074b6341dfb00  vmovaps [rsp+0x50], xmm5
000074b6341dfb06  vmovaps [rsp+0x60], xmm6
000074b6341dfb0c  vmovaps [rsp+0x70], xmm7
000074b6341dfb12  vmovaps [rsp+0x80], xmm8
000074b6341dfb1b  vmovaps [rsp+0x90], xmm9
000074b6341dfb24  vmovaps [rsp+0xA0], xmm10
000074b6341dfb2d  vmovaps [rsp+0xB0], xmm11
000074b6341dfb36  vmovaps [rsp+0xC0], xmm12
000074b6341dfb3f  vmovaps [rsp+0xD0], xmm13
000074b6341dfb48  vmovaps [rsp+0xE0], xmm14
000074b6341dfb51  sub rsp, 0x30
000074b6341dfb55  movaps [rsp], xmm15
000074b6341dfb5a  movaps [rsp+0x10], xmm1
000074b6341dfb5f  movaps [rsp+0x20], xmm5
000074b6341dfb64  lea rdi, [rsp]
000074b6341dfb68  mov esi, 0x00
000074b6341dfb6d  mov rax, 0x5E1AA0A2F530
000074b6341dfb77  call rax
000074b6341dfb79  movaps xmm15, [rsp]
000074b6341dfb7e  add rsp, 0x30
000074b6341dfb82  vmovaps xmm0, [rsp]
000074b6341dfb87  vmovaps xmm1, [rsp+0x10]
000074b6341dfb8d  vmovaps xmm2, [rsp+0x20]
000074b6341dfb93  vmovaps xmm3, [rsp+0x30]
000074b6341dfb99  vmovaps xmm4, [rsp+0x40]
000074b6341dfb9f  vmovaps xmm5, [rsp+0x50]
000074b6341dfba5  vmovaps xmm6, [rsp+0x60]
000074b6341dfbab  vmovaps xmm7, [rsp+0x70]
000074b6341dfbb1  vmovaps xmm8, [rsp+0x80]
000074b6341dfbba  vmovaps xmm9, [rsp+0x90]
000074b6341dfbc3  vmovaps xmm10, [rsp+0xA0]
000074b6341dfbcc  vmovaps xmm11, [rsp+0xB0]
000074b6341dfbd5  vmovaps xmm12, [rsp+0xC0]
000074b6341dfbde  vmovaps xmm13, [rsp+0xD0]
000074b6341dfbe7  vmovaps xmm14, [rsp+0xE0]
000074b6341dfbf0  add rsp, 0xF0
000074b6341dfbf7  pop r11
000074b6341dfbf9  pop r10
000074b6341dfbfb  pop r9
000074b6341dfbfd  pop r8
000074b6341dfbff  pop rsi
000074b6341dfc00  pop rdi
000074b6341dfc01  pop rdx
000074b6341dfc02  pop rcx
000074b6341dfc03  pop rax
000074b6341dfc04  add rsp, 0x08
000074b6341dfc08  jmp 0x000074B6341DC473
000074b6341dfc0d  call 0x000074B6340B52F0
000074b6341dfc12  jmp 0x000074B6341DC4CE
000074b6341dfc17  sub rsp, 0x08
000074b6341dfc1b  push rax
000074b6341dfc1c  push rcx
000074b6341dfc1d  push rdx
000074b6341dfc1e  push rdi
000074b6341dfc1f  push rsi
000074b6341dfc20  push r8
000074b6341dfc22  push r9
000074b6341dfc24  push r10
000074b6341dfc26  push r11
000074b6341dfc28  sub rsp, 0xF0
000074b6341dfc2f  vmovaps [rsp], xmm0
000074b6341dfc34  vmovaps [rsp+0x10], xmm1
000074b6341dfc3a  vmovaps [rsp+0x20], xmm2
000074b6341dfc40  vmovaps [rsp+0x30], xmm3
000074b6341dfc46  vmovaps [rsp+0x40], xmm4
000074b6341dfc4c  vmovaps [rsp+0x50], xmm5
000074b6341dfc52  vmovaps [rsp+0x60], xmm6
000074b6341dfc58  vmovaps [rsp+0x70], xmm7
000074b6341dfc5e  vmovaps [rsp+0x80], xmm8
000074b6341dfc67  vmovaps [rsp+0x90], xmm10
000074b6341dfc70  vmovaps [rsp+0xA0], xmm11
000074b6341dfc79  vmovaps [rsp+0xB0], xmm12
000074b6341dfc82  vmovaps [rsp+0xC0], xmm13
000074b6341dfc8b  vmovaps [rsp+0xD0], xmm14
000074b6341dfc94  vmovaps [rsp+0xE0], xmm15
000074b6341dfc9d  sub rsp, 0x30
000074b6341dfca1  movaps [rsp], xmm9
000074b6341dfca6  movaps [rsp+0x10], xmm8
000074b6341dfcac  movaps [rsp+0x20], xmm11
000074b6341dfcb2  lea rdi, [rsp]
000074b6341dfcb6  mov esi, 0x00
000074b6341dfcbb  mov rax, 0x5E1AA0A2F530
000074b6341dfcc5  call rax
000074b6341dfcc7  movaps xmm9, [rsp]
000074b6341dfccc  add rsp, 0x30
000074b6341dfcd0  vmovaps xmm0, [rsp]
000074b6341dfcd5  vmovaps xmm1, [rsp+0x10]
000074b6341dfcdb  vmovaps xmm2, [rsp+0x20]
000074b6341dfce1  vmovaps xmm3, [rsp+0x30]
000074b6341dfce7  vmovaps xmm4, [rsp+0x40]
000074b6341dfced  vmovaps xmm5, [rsp+0x50]
000074b6341dfcf3  vmovaps xmm6, [rsp+0x60]
000074b6341dfcf9  vmovaps xmm7, [rsp+0x70]
000074b6341dfcff  vmovaps xmm8, [rsp+0x80]
000074b6341dfd08  vmovaps xmm10, [rsp+0x90]
000074b6341dfd11  vmovaps xmm11, [rsp+0xA0]
000074b6341dfd1a  vmovaps xmm12, [rsp+0xB0]
000074b6341dfd23  vmovaps xmm13, [rsp+0xC0]
000074b6341dfd2c  vmovaps xmm14, [rsp+0xD0]
000074b6341dfd35  vmovaps xmm15, [rsp+0xE0]
000074b6341dfd3e  add rsp, 0xF0
000074b6341dfd45  pop r11
000074b6341dfd47  pop r10
000074b6341dfd49  pop r9
000074b6341dfd4b  pop r8
000074b6341dfd4d  pop rsi
000074b6341dfd4e  pop rdi
000074b6341dfd4f  pop rdx
000074b6341dfd50  pop rcx
000074b6341dfd51  pop rax
000074b6341dfd52  add rsp, 0x08
000074b6341dfd56  jmp 0x000074B6341DC505
000074b6341dfd5b  sub rsp, 0x08
000074b6341dfd5f  push rax
000074b6341dfd60  push rcx
000074b6341dfd61  push rdx
000074b6341dfd62  push rdi
000074b6341dfd63  push rsi
000074b6341dfd64  push r8
000074b6341dfd66  push r9
000074b6341dfd68  push r10
000074b6341dfd6a  push r11
000074b6341dfd6c  sub rsp, 0xF0
000074b6341dfd73  vmovaps [rsp], xmm0
000074b6341dfd78  vmovaps [rsp+0x10], xmm1
000074b6341dfd7e  vmovaps [rsp+0x20], xmm2
000074b6341dfd84  vmovaps [rsp+0x30], xmm3
000074b6341dfd8a  vmovaps [rsp+0x40], xmm4
000074b6341dfd90  vmovaps [rsp+0x50], xmm5
000074b6341dfd96  vmovaps [rsp+0x60], xmm6
000074b6341dfd9c  vmovaps [rsp+0x70], xmm7
000074b6341dfda2  vmovaps [rsp+0x80], xmm8
000074b6341dfdab  vmovaps [rsp+0x90], xmm9
000074b6341dfdb4  vmovaps [rsp+0xA0], xmm10
000074b6341dfdbd  vmovaps [rsp+0xB0], xmm12
000074b6341dfdc6  vmovaps [rsp+0xC0], xmm13
000074b6341dfdcf  vmovaps [rsp+0xD0], xmm14
000074b6341dfdd8  vmovaps [rsp+0xE0], xmm15
000074b6341dfde1  sub rsp, 0x30
000074b6341dfde5  movaps [rsp], xmm11
000074b6341dfdea  movaps [rsp+0x10], xmm10
000074b6341dfdf0  movaps [rsp+0x20], xmm6
000074b6341dfdf5  lea rdi, [rsp]
000074b6341dfdf9  mov esi, 0x00
000074b6341dfdfe  mov rax, 0x5E1AA0A2F530
000074b6341dfe08  call rax
000074b6341dfe0a  movaps xmm11, [rsp]
000074b6341dfe0f  add rsp, 0x30
000074b6341dfe13  vmovaps xmm0, [rsp]
000074b6341dfe18  vmovaps xmm1, [rsp+0x10]
000074b6341dfe1e  vmovaps xmm2, [rsp+0x20]
000074b6341dfe24  vmovaps xmm3, [rsp+0x30]
000074b6341dfe2a  vmovaps xmm4, [rsp+0x40]
000074b6341dfe30  vmovaps xmm5, [rsp+0x50]
000074b6341dfe36  vmovaps xmm6, [rsp+0x60]
000074b6341dfe3c  vmovaps xmm7, [rsp+0x70]
000074b6341dfe42  vmovaps xmm8, [rsp+0x80]
000074b6341dfe4b  vmovaps xmm9, [rsp+0x90]
000074b6341dfe54  vmovaps xmm10, [rsp+0xA0]
000074b6341dfe5d  vmovaps xmm12, [rsp+0xB0]
000074b6341dfe66  vmovaps xmm13, [rsp+0xC0]
000074b6341dfe6f  vmovaps xmm14, [rsp+0xD0]
000074b6341dfe78  vmovaps xmm15, [rsp+0xE0]
000074b6341dfe81  add rsp, 0xF0
000074b6341dfe88  pop r11
000074b6341dfe8a  pop r10
000074b6341dfe8c  pop r9
000074b6341dfe8e  pop r8
000074b6341dfe90  pop rsi
000074b6341dfe91  pop rdi
000074b6341dfe92  pop rdx
000074b6341dfe93  pop rcx
000074b6341dfe94  pop rax
000074b6341dfe95  add rsp, 0x08
000074b6341dfe99  jmp 0x000074B6341DC520
000074b6341dfe9e  sub rsp, 0x08
000074b6341dfea2  push rax
000074b6341dfea3  push rcx
000074b6341dfea4  push rdx
000074b6341dfea5  push rdi
000074b6341dfea6  push rsi
000074b6341dfea7  push r8
000074b6341dfea9  push r9
000074b6341dfeab  push r10
000074b6341dfead  push r11
000074b6341dfeaf  sub rsp, 0xF0
000074b6341dfeb6  vmovaps [rsp], xmm0
000074b6341dfebb  vmovaps [rsp+0x10], xmm1
000074b6341dfec1  vmovaps [rsp+0x20], xmm2
000074b6341dfec7  vmovaps [rsp+0x30], xmm3
000074b6341dfecd  vmovaps [rsp+0x40], xmm4
000074b6341dfed3  vmovaps [rsp+0x50], xmm5
000074b6341dfed9  vmovaps [rsp+0x60], xmm6
000074b6341dfedf  vmovaps [rsp+0x70], xmm7
000074b6341dfee5  vmovaps [rsp+0x80], xmm8
000074b6341dfeee  vmovaps [rsp+0x90], xmm9
000074b6341dfef7  vmovaps [rsp+0xA0], xmm11
000074b6341dff00  vmovaps [rsp+0xB0], xmm12
000074b6341dff09  vmovaps [rsp+0xC0], xmm13
000074b6341dff12  vmovaps [rsp+0xD0], xmm14
000074b6341dff1b  vmovaps [rsp+0xE0], xmm15
000074b6341dff24  sub rsp, 0x30
000074b6341dff28  movaps [rsp], xmm10
000074b6341dff2d  movaps [rsp+0x10], xmm14
000074b6341dff33  movaps [rsp+0x20], xmm4
000074b6341dff38  lea rdi, [rsp]
000074b6341dff3c  mov esi, 0x00
000074b6341dff41  mov rax, 0x5E1AA0A2F530
000074b6341dff4b  call rax
000074b6341dff4d  movaps xmm10, [rsp]
000074b6341dff52  add rsp, 0x30
000074b6341dff56  vmovaps xmm0, [rsp]
000074b6341dff5b  vmovaps xmm1, [rsp+0x10]
000074b6341dff61  vmovaps xmm2, [rsp+0x20]
000074b6341dff67  vmovaps xmm3, [rsp+0x30]
000074b6341dff6d  vmovaps xmm4, [rsp+0x40]
000074b6341dff73  vmovaps xmm5, [rsp+0x50]
000074b6341dff79  vmovaps xmm6, [rsp+0x60]
000074b6341dff7f  vmovaps xmm7, [rsp+0x70]
000074b6341dff85  vmovaps xmm8, [rsp+0x80]
000074b6341dff8e  vmovaps xmm9, [rsp+0x90]
000074b6341dff97  vmovaps xmm11, [rsp+0xA0]
000074b6341dffa0  vmovaps xmm12, [rsp+0xB0]
000074b6341dffa9  vmovaps xmm13, [rsp+0xC0]
000074b6341dffb2  vmovaps xmm14, [rsp+0xD0]
000074b6341dffbb  vmovaps xmm15, [rsp+0xE0]
000074b6341dffc4  add rsp, 0xF0
000074b6341dffcb  pop r11
000074b6341dffcd  pop r10
000074b6341dffcf  pop r9
000074b6341dffd1  pop r8
000074b6341dffd3  pop rsi
000074b6341dffd4  pop rdi
000074b6341dffd5  pop rdx
000074b6341dffd6  pop rcx
000074b6341dffd7  pop rax
000074b6341dffd8  add rsp, 0x08
000074b6341dffdc  jmp 0x000074B6341DC53B
000074b6341dffe1  sub rsp, 0x08
000074b6341dffe5  push rax
000074b6341dffe6  push rcx
000074b6341dffe7  push rdx
000074b6341dffe8  push rdi
000074b6341dffe9  push rsi
000074b6341dffea  push r8
000074b6341dffec  push r9
000074b6341dffee  push r10
000074b6341dfff0  push r11
000074b6341dfff2  sub rsp, 0xF0
000074b6341dfff9  vmovaps [rsp], xmm0
000074b6341dfffe  vmovaps [rsp+0x10], xmm1
000074b6341e0004  vmovaps [rsp+0x20], xmm2
000074b6341e000a  vmovaps [rsp+0x30], xmm3
000074b6341e0010  vmovaps [rsp+0x40], xmm4
000074b6341e0016  vmovaps [rsp+0x50], xmm5
000074b6341e001c  vmovaps [rsp+0x60], xmm6
000074b6341e0022  vmovaps [rsp+0x70], xmm7
000074b6341e0028  vmovaps [rsp+0x80], xmm9
000074b6341e0031  vmovaps [rsp+0x90], xmm10
000074b6341e003a  vmovaps [rsp+0xA0], xmm11
000074b6341e0043  vmovaps [rsp+0xB0], xmm12
000074b6341e004c  vmovaps [rsp+0xC0], xmm13
000074b6341e0055  vmovaps [rsp+0xD0], xmm14
000074b6341e005e  vmovaps [rsp+0xE0], xmm15
000074b6341e0067  sub rsp, 0x30
000074b6341e006b  movaps [rsp], xmm8
000074b6341e0070  movaps [rsp+0x10], xmm1
000074b6341e0075  movaps [rsp+0x20], xmm14
000074b6341e007b  lea rdi, [rsp]
000074b6341e007f  mov esi, 0x00
000074b6341e0084  mov rax, 0x5E1AA0A2F530
000074b6341e008e  call rax
000074b6341e0090  movaps xmm8, [rsp]
000074b6341e0095  add rsp, 0x30
000074b6341e0099  vmovaps xmm0, [rsp]
000074b6341e009e  vmovaps xmm1, [rsp+0x10]
000074b6341e00a4  vmovaps xmm2, [rsp+0x20]
000074b6341e00aa  vmovaps xmm3, [rsp+0x30]
000074b6341e00b0  vmovaps xmm4, [rsp+0x40]
000074b6341e00b6  vmovaps xmm5, [rsp+0x50]
000074b6341e00bc  vmovaps xmm6, [rsp+0x60]
000074b6341e00c2  vmovaps xmm7, [rsp+0x70]
000074b6341e00c8  vmovaps xmm9, [rsp+0x80]
000074b6341e00d1  vmovaps xmm10, [rsp+0x90]
000074b6341e00da  vmovaps xmm11, [rsp+0xA0]
000074b6341e00e3  vmovaps xmm12, [rsp+0xB0]
000074b6341e00ec  vmovaps xmm13, [rsp+0xC0]
000074b6341e00f5  vmovaps xmm14, [rsp+0xD0]
000074b6341e00fe  vmovaps xmm15, [rsp+0xE0]
000074b6341e0107  add rsp, 0xF0
000074b6341e010e  pop r11
000074b6341e0110  pop r10
000074b6341e0112  pop r9
000074b6341e0114  pop r8
000074b6341e0116  pop rsi
000074b6341e0117  pop rdi
000074b6341e0118  pop rdx
000074b6341e0119  pop rcx
000074b6341e011a  pop rax
000074b6341e011b  add rsp, 0x08
000074b6341e011f  jmp 0x000074B6341DC561
000074b6341e0124  sub rsp, 0x08
000074b6341e0128  push rax
000074b6341e0129  push rcx
000074b6341e012a  push rdx
000074b6341e012b  push rdi
000074b6341e012c  push rsi
000074b6341e012d  push r8
000074b6341e012f  push r9
000074b6341e0131  push r10
000074b6341e0133  push r11
000074b6341e0135  sub rsp, 0xF0
000074b6341e013c  vmovaps [rsp], xmm0
000074b6341e0141  vmovaps [rsp+0x10], xmm1
000074b6341e0147  vmovaps [rsp+0x20], xmm2
000074b6341e014d  vmovaps [rsp+0x30], xmm3
000074b6341e0153  vmovaps [rsp+0x40], xmm4
000074b6341e0159  vmovaps [rsp+0x50], xmm5
000074b6341e015f  vmovaps [rsp+0x60], xmm7
000074b6341e0165  vmovaps [rsp+0x70], xmm8
000074b6341e016b  vmovaps [rsp+0x80], xmm9
000074b6341e0174  vmovaps [rsp+0x90], xmm10
000074b6341e017d  vmovaps [rsp+0xA0], xmm11
000074b6341e0186  vmovaps [rsp+0xB0], xmm12
000074b6341e018f  vmovaps [rsp+0xC0], xmm13
000074b6341e0198  vmovaps [rsp+0xD0], xmm14
000074b6341e01a1  vmovaps [rsp+0xE0], xmm15
000074b6341e01aa  sub rsp, 0x30
000074b6341e01ae  movaps [rsp], xmm6
000074b6341e01b2  movaps [rsp+0x10], xmm1
000074b6341e01b7  movaps [rsp+0x20], xmm14
000074b6341e01bd  lea rdi, [rsp]
000074b6341e01c1  mov esi, 0x00
000074b6341e01c6  mov rax, 0x5E1AA0A2F530
000074b6341e01d0  call rax
000074b6341e01d2  movaps xmm6, [rsp]
000074b6341e01d6  add rsp, 0x30
000074b6341e01da  vmovaps xmm0, [rsp]
000074b6341e01df  vmovaps xmm1, [rsp+0x10]
000074b6341e01e5  vmovaps xmm2, [rsp+0x20]
000074b6341e01eb  vmovaps xmm3, [rsp+0x30]
000074b6341e01f1  vmovaps xmm4, [rsp+0x40]
000074b6341e01f7  vmovaps xmm5, [rsp+0x50]
000074b6341e01fd  vmovaps xmm7, [rsp+0x60]
000074b6341e0203  vmovaps xmm8, [rsp+0x70]
000074b6341e0209  vmovaps xmm9, [rsp+0x80]
000074b6341e0212  vmovaps xmm10, [rsp+0x90]
000074b6341e021b  vmovaps xmm11, [rsp+0xA0]
000074b6341e0224  vmovaps xmm12, [rsp+0xB0]
000074b6341e022d  vmovaps xmm13, [rsp+0xC0]
000074b6341e0236  vmovaps xmm14, [rsp+0xD0]
000074b6341e023f  vmovaps xmm15, [rsp+0xE0]
000074b6341e0248  add rsp, 0xF0
000074b6341e024f  pop r11
000074b6341e0251  pop r10
000074b6341e0253  pop r9
000074b6341e0255  pop r8
000074b6341e0257  pop rsi
000074b6341e0258  pop rdi
000074b6341e0259  pop rdx
000074b6341e025a  pop rcx
000074b6341e025b  pop rax
000074b6341e025c  add rsp, 0x08
000074b6341e0260  jmp 0x000074B6341DC58D
000074b6341e0265  sub rsp, 0x08
000074b6341e0269  push rax
000074b6341e026a  push rcx
000074b6341e026b  push rdx
000074b6341e026c  push rdi
000074b6341e026d  push rsi
000074b6341e026e  push r8
000074b6341e0270  push r9
000074b6341e0272  push r10
000074b6341e0274  push r11
000074b6341e0276  sub rsp, 0xF0
000074b6341e027d  vmovaps [rsp], xmm0
000074b6341e0282  vmovaps [rsp+0x10], xmm1
000074b6341e0288  vmovaps [rsp+0x20], xmm2
000074b6341e028e  vmovaps [rsp+0x30], xmm3
000074b6341e0294  vmovaps [rsp+0x40], xmm4
000074b6341e029a  vmovaps [rsp+0x50], xmm5
000074b6341e02a0  vmovaps [rsp+0x60], xmm6
000074b6341e02a6  vmovaps [rsp+0x70], xmm7
000074b6341e02ac  vmovaps [rsp+0x80], xmm8
000074b6341e02b5  vmovaps [rsp+0x90], xmm9
000074b6341e02be  vmovaps [rsp+0xA0], xmm10
000074b6341e02c7  vmovaps [rsp+0xB0], xmm11
000074b6341e02d0  vmovaps [rsp+0xC0], xmm12
000074b6341e02d9  vmovaps [rsp+0xD0], xmm13
000074b6341e02e2  vmovaps [rsp+0xE0], xmm15
000074b6341e02eb  sub rsp, 0x30
000074b6341e02ef  movaps [rsp], xmm14
000074b6341e02f4  movaps [rsp+0x10], xmm12
000074b6341e02fa  movaps [rsp+0x20], xmm1
000074b6341e02ff  lea rdi, [rsp]
000074b6341e0303  mov esi, 0x00
000074b6341e0308  mov rax, 0x5E1AA0A2F530
000074b6341e0312  call rax
000074b6341e0314  movaps xmm14, [rsp]
000074b6341e0319  add rsp, 0x30
000074b6341e031d  vmovaps xmm0, [rsp]
000074b6341e0322  vmovaps xmm1, [rsp+0x10]
000074b6341e0328  vmovaps xmm2, [rsp+0x20]
000074b6341e032e  vmovaps xmm3, [rsp+0x30]
000074b6341e0334  vmovaps xmm4, [rsp+0x40]
000074b6341e033a  vmovaps xmm5, [rsp+0x50]
000074b6341e0340  vmovaps xmm6, [rsp+0x60]
000074b6341e0346  vmovaps xmm7, [rsp+0x70]
000074b6341e034c  vmovaps xmm8, [rsp+0x80]
000074b6341e0355  vmovaps xmm9, [rsp+0x90]
000074b6341e035e  vmovaps xmm10, [rsp+0xA0]
000074b6341e0367  vmovaps xmm11, [rsp+0xB0]
000074b6341e0370  vmovaps xmm12, [rsp+0xC0]
000074b6341e0379  vmovaps xmm13, [rsp+0xD0]
000074b6341e0382  vmovaps xmm15, [rsp+0xE0]
000074b6341e038b  add rsp, 0xF0
000074b6341e0392  pop r11
000074b6341e0394  pop r10
000074b6341e0396  pop r9
000074b6341e0398  pop r8
000074b6341e039a  pop rsi
000074b6341e039b  pop rdi
000074b6341e039c  pop rdx
000074b6341e039d  pop rcx
000074b6341e039e  pop rax
000074b6341e039f  add rsp, 0x08
000074b6341e03a3  jmp 0x000074B6341DC5B3
000074b6341e03a8  sub rsp, 0x08
000074b6341e03ac  push rax
000074b6341e03ad  push rcx
000074b6341e03ae  push rdx
000074b6341e03af  push rdi
000074b6341e03b0  push rsi
000074b6341e03b1  push r8
000074b6341e03b3  push r9
000074b6341e03b5  push r10
000074b6341e03b7  push r11
000074b6341e03b9  sub rsp, 0xF0
000074b6341e03c0  vmovaps [rsp], xmm0
000074b6341e03c5  vmovaps [rsp+0x10], xmm2
000074b6341e03cb  vmovaps [rsp+0x20], xmm3
000074b6341e03d1  vmovaps [rsp+0x30], xmm4
000074b6341e03d7  vmovaps [rsp+0x40], xmm5
000074b6341e03dd  vmovaps [rsp+0x50], xmm6
000074b6341e03e3  vmovaps [rsp+0x60], xmm7
000074b6341e03e9  vmovaps [rsp+0x70], xmm8
000074b6341e03ef  vmovaps [rsp+0x80], xmm9
000074b6341e03f8  vmovaps [rsp+0x90], xmm10
000074b6341e0401  vmovaps [rsp+0xA0], xmm11
000074b6341e040a  vmovaps [rsp+0xB0], xmm12
000074b6341e0413  vmovaps [rsp+0xC0], xmm13
000074b6341e041c  vmovaps [rsp+0xD0], xmm14
000074b6341e0425  vmovaps [rsp+0xE0], xmm15
000074b6341e042e  sub rsp, 0x30
000074b6341e0432  movaps [rsp], xmm1
000074b6341e0436  movaps [rsp+0x10], xmm13
000074b6341e043c  movaps [rsp+0x20], xmm9
000074b6341e0442  lea rdi, [rsp]
000074b6341e0446  mov esi, 0x00
000074b6341e044b  mov rax, 0x5E1AA0A2F530
000074b6341e0455  call rax
000074b6341e0457  movaps xmm1, [rsp]
000074b6341e045b  add rsp, 0x30
000074b6341e045f  vmovaps xmm0, [rsp]
000074b6341e0464  vmovaps xmm2, [rsp+0x10]
000074b6341e046a  vmovaps xmm3, [rsp+0x20]
000074b6341e0470  vmovaps xmm4, [rsp+0x30]
000074b6341e0476  vmovaps xmm5, [rsp+0x40]
000074b6341e047c  vmovaps xmm6, [rsp+0x50]
000074b6341e0482  vmovaps xmm7, [rsp+0x60]
000074b6341e0488  vmovaps xmm8, [rsp+0x70]
000074b6341e048e  vmovaps xmm9, [rsp+0x80]
000074b6341e0497  vmovaps xmm10, [rsp+0x90]
000074b6341e04a0  vmovaps xmm11, [rsp+0xA0]
000074b6341e04a9  vmovaps xmm12, [rsp+0xB0]
000074b6341e04b2  vmovaps xmm13, [rsp+0xC0]
000074b6341e04bb  vmovaps xmm14, [rsp+0xD0]
000074b6341e04c4  vmovaps xmm15, [rsp+0xE0]
000074b6341e04cd  add rsp, 0xF0
000074b6341e04d4  pop r11
000074b6341e04d6  pop r10
000074b6341e04d8  pop r9
000074b6341e04da  pop r8
000074b6341e04dc  pop rsi
000074b6341e04dd  pop rdi
000074b6341e04de  pop rdx
000074b6341e04df  pop rcx
000074b6341e04e0  pop rax
000074b6341e04e1  add rsp, 0x08
000074b6341e04e5  jmp 0x000074B6341DC5CD
000074b6341e04ea  sub rsp, 0x08
000074b6341e04ee  push rax
000074b6341e04ef  push rcx
000074b6341e04f0  push rdx
000074b6341e04f1  push rdi
000074b6341e04f2  push rsi
000074b6341e04f3  push r8
000074b6341e04f5  push r9
000074b6341e04f7  push r10
000074b6341e04f9  push r11
000074b6341e04fb  sub rsp, 0xF0
000074b6341e0502  vmovaps [rsp], xmm0
000074b6341e0507  vmovaps [rsp+0x10], xmm1
000074b6341e050d  vmovaps [rsp+0x20], xmm2
000074b6341e0513  vmovaps [rsp+0x30], xmm3
000074b6341e0519  vmovaps [rsp+0x40], xmm4
000074b6341e051f  vmovaps [rsp+0x50], xmm5
000074b6341e0525  vmovaps [rsp+0x60], xmm6
000074b6341e052b  vmovaps [rsp+0x70], xmm7
000074b6341e0531  vmovaps [rsp+0x80], xmm8
000074b6341e053a  vmovaps [rsp+0x90], xmm9
000074b6341e0543  vmovaps [rsp+0xA0], xmm10
000074b6341e054c  vmovaps [rsp+0xB0], xmm11
000074b6341e0555  vmovaps [rsp+0xC0], xmm13
000074b6341e055e  vmovaps [rsp+0xD0], xmm14
000074b6341e0567  vmovaps [rsp+0xE0], xmm15
000074b6341e0570  sub rsp, 0x30
000074b6341e0574  movaps [rsp], xmm12
000074b6341e0579  movaps [rsp+0x10], xmm7
000074b6341e057e  movaps [rsp+0x20], xmm13
000074b6341e0584  lea rdi, [rsp]
000074b6341e0588  mov esi, 0x00
000074b6341e058d  mov rax, 0x5E1AA0A2F530
000074b6341e0597  call rax
000074b6341e0599  movaps xmm12, [rsp]
000074b6341e059e  add rsp, 0x30
000074b6341e05a2  vmovaps xmm0, [rsp]
000074b6341e05a7  vmovaps xmm1, [rsp+0x10]
000074b6341e05ad  vmovaps xmm2, [rsp+0x20]
000074b6341e05b3  vmovaps xmm3, [rsp+0x30]
000074b6341e05b9  vmovaps xmm4, [rsp+0x40]
000074b6341e05bf  vmovaps xmm5, [rsp+0x50]
000074b6341e05c5  vmovaps xmm6, [rsp+0x60]
000074b6341e05cb  vmovaps xmm7, [rsp+0x70]
000074b6341e05d1  vmovaps xmm8, [rsp+0x80]
000074b6341e05da  vmovaps xmm9, [rsp+0x90]
000074b6341e05e3  vmovaps xmm10, [rsp+0xA0]
000074b6341e05ec  vmovaps xmm11, [rsp+0xB0]
000074b6341e05f5  vmovaps xmm13, [rsp+0xC0]
000074b6341e05fe  vmovaps xmm14, [rsp+0xD0]
000074b6341e0607  vmovaps xmm15, [rsp+0xE0]
000074b6341e0610  add rsp, 0xF0
000074b6341e0617  pop r11
000074b6341e0619  pop r10
000074b6341e061b  pop r9
000074b6341e061d  pop r8
000074b6341e061f  pop rsi
000074b6341e0620  pop rdi
000074b6341e0621  pop rdx
000074b6341e0622  pop rcx
000074b6341e0623  pop rax
000074b6341e0624  add rsp, 0x08
000074b6341e0628  jmp 0x000074B6341DC5F4
000074b6341e062d  sub rsp, 0x08
000074b6341e0631  push rax
000074b6341e0632  push rcx
000074b6341e0633  push rdx
000074b6341e0634  push rdi
000074b6341e0635  push rsi
000074b6341e0636  push r8
000074b6341e0638  push r9
000074b6341e063a  push r10
000074b6341e063c  push r11
000074b6341e063e  sub rsp, 0xF0
000074b6341e0645  vmovaps [rsp], xmm0
000074b6341e064a  vmovaps [rsp+0x10], xmm1
000074b6341e0650  vmovaps [rsp+0x20], xmm2
000074b6341e0656  vmovaps [rsp+0x30], xmm3
000074b6341e065c  vmovaps [rsp+0x40], xmm4
000074b6341e0662  vmovaps [rsp+0x50], xmm5
000074b6341e0668  vmovaps [rsp+0x60], xmm6
000074b6341e066e  vmovaps [rsp+0x70], xmm7
000074b6341e0674  vmovaps [rsp+0x80], xmm8
000074b6341e067d  vmovaps [rsp+0x90], xmm9
000074b6341e0686  vmovaps [rsp+0xA0], xmm10
000074b6341e068f  vmovaps [rsp+0xB0], xmm11
000074b6341e0698  vmovaps [rsp+0xC0], xmm12
000074b6341e06a1  vmovaps [rsp+0xD0], xmm14
000074b6341e06aa  vmovaps [rsp+0xE0], xmm15
000074b6341e06b3  sub rsp, 0x30
000074b6341e06b7  movaps [rsp], xmm13
000074b6341e06bc  movaps [rsp+0x10], xmm15
000074b6341e06c2  movaps [rsp+0x20], xmm8
000074b6341e06c8  lea rdi, [rsp]
000074b6341e06cc  mov esi, 0x00
000074b6341e06d1  mov rax, 0x5E1AA0A2F530
000074b6341e06db  call rax
000074b6341e06dd  movaps xmm13, [rsp]
000074b6341e06e2  add rsp, 0x30
000074b6341e06e6  vmovaps xmm0, [rsp]
000074b6341e06eb  vmovaps xmm1, [rsp+0x10]
000074b6341e06f1  vmovaps xmm2, [rsp+0x20]
000074b6341e06f7  vmovaps xmm3, [rsp+0x30]
000074b6341e06fd  vmovaps xmm4, [rsp+0x40]
000074b6341e0703  vmovaps xmm5, [rsp+0x50]
000074b6341e0709  vmovaps xmm6, [rsp+0x60]
000074b6341e070f  vmovaps xmm7, [rsp+0x70]
000074b6341e0715  vmovaps xmm8, [rsp+0x80]
000074b6341e071e  vmovaps xmm9, [rsp+0x90]
000074b6341e0727  vmovaps xmm10, [rsp+0xA0]
000074b6341e0730  vmovaps xmm11, [rsp+0xB0]
000074b6341e0739  vmovaps xmm12, [rsp+0xC0]
000074b6341e0742  vmovaps xmm14, [rsp+0xD0]
000074b6341e074b  vmovaps xmm15, [rsp+0xE0]
000074b6341e0754  add rsp, 0xF0
000074b6341e075b  pop r11
000074b6341e075d  pop r10
000074b6341e075f  pop r9
000074b6341e0761  pop r8
000074b6341e0763  pop rsi
000074b6341e0764  pop rdi
000074b6341e0765  pop rdx
000074b6341e0766  pop rcx
000074b6341e0767  pop rax
000074b6341e0768  add rsp, 0x08
000074b6341e076c  jmp 0x000074B6341DC60F
000074b6341e0771  sub rsp, 0x08
000074b6341e0775  push rax
000074b6341e0776  push rcx
000074b6341e0777  push rdx
000074b6341e0778  push rdi
000074b6341e0779  push rsi
000074b6341e077a  push r8
000074b6341e077c  push r9
000074b6341e077e  push r10
000074b6341e0780  push r11
000074b6341e0782  sub rsp, 0xF0
000074b6341e0789  vmovaps [rsp], xmm0
000074b6341e078e  vmovaps [rsp+0x10], xmm1
000074b6341e0794  vmovaps [rsp+0x20], xmm2
000074b6341e079a  vmovaps [rsp+0x30], xmm3
000074b6341e07a0  vmovaps [rsp+0x40], xmm4
000074b6341e07a6  vmovaps [rsp+0x50], xmm5
000074b6341e07ac  vmovaps [rsp+0x60], xmm6
000074b6341e07b2  vmovaps [rsp+0x70], xmm7
000074b6341e07b8  vmovaps [rsp+0x80], xmm9
000074b6341e07c1  vmovaps [rsp+0x90], xmm10
000074b6341e07ca  vmovaps [rsp+0xA0], xmm11
000074b6341e07d3  vmovaps [rsp+0xB0], xmm12
000074b6341e07dc  vmovaps [rsp+0xC0], xmm13
000074b6341e07e5  vmovaps [rsp+0xD0], xmm14
000074b6341e07ee  vmovaps [rsp+0xE0], xmm15
000074b6341e07f7  sub rsp, 0x30
000074b6341e07fb  movaps [rsp], xmm8
000074b6341e0800  movaps [rsp+0x10], xmm15
000074b6341e0806  movaps [rsp+0x20], xmm9
000074b6341e080c  lea rdi, [rsp]
000074b6341e0810  mov esi, 0x00
000074b6341e0815  mov rax, 0x5E1AA0A2F530
000074b6341e081f  call rax
000074b6341e0821  movaps xmm8, [rsp]
000074b6341e0826  add rsp, 0x30
000074b6341e082a  vmovaps xmm0, [rsp]
000074b6341e082f  vmovaps xmm1, [rsp+0x10]
000074b6341e0835  vmovaps xmm2, [rsp+0x20]
000074b6341e083b  vmovaps xmm3, [rsp+0x30]
000074b6341e0841  vmovaps xmm4, [rsp+0x40]
000074b6341e0847  vmovaps xmm5, [rsp+0x50]
000074b6341e084d  vmovaps xmm6, [rsp+0x60]
000074b6341e0853  vmovaps xmm7, [rsp+0x70]
000074b6341e0859  vmovaps xmm9, [rsp+0x80]
000074b6341e0862  vmovaps xmm10, [rsp+0x90]
000074b6341e086b  vmovaps xmm11, [rsp+0xA0]
000074b6341e0874  vmovaps xmm12, [rsp+0xB0]
000074b6341e087d  vmovaps xmm13, [rsp+0xC0]
000074b6341e0886  vmovaps xmm14, [rsp+0xD0]
000074b6341e088f  vmovaps xmm15, [rsp+0xE0]
000074b6341e0898  add rsp, 0xF0
000074b6341e089f  pop r11
000074b6341e08a1  pop r10
000074b6341e08a3  pop r9
000074b6341e08a5  pop r8
000074b6341e08a7  pop rsi
000074b6341e08a8  pop rdi
000074b6341e08a9  pop rdx
000074b6341e08aa  pop rcx
000074b6341e08ab  pop rax
000074b6341e08ac  add rsp, 0x08
000074b6341e08b0  jmp 0x000074B6341DC63D
000074b6341e08b5  sub rsp, 0x08
000074b6341e08b9  push rax
000074b6341e08ba  push rcx
000074b6341e08bb  push rdx
000074b6341e08bc  push rdi
000074b6341e08bd  push rsi
000074b6341e08be  push r8
000074b6341e08c0  push r9
000074b6341e08c2  push r10
000074b6341e08c4  push r11
000074b6341e08c6  sub rsp, 0xF0
000074b6341e08cd  vmovaps [rsp], xmm0
000074b6341e08d2  vmovaps [rsp+0x10], xmm1
000074b6341e08d8  vmovaps [rsp+0x20], xmm2
000074b6341e08de  vmovaps [rsp+0x30], xmm3
000074b6341e08e4  vmovaps [rsp+0x40], xmm4
000074b6341e08ea  vmovaps [rsp+0x50], xmm5
000074b6341e08f0  vmovaps [rsp+0x60], xmm6
000074b6341e08f6  vmovaps [rsp+0x70], xmm7
000074b6341e08fc  vmovaps [rsp+0x80], xmm8
000074b6341e0905  vmovaps [rsp+0x90], xmm9
000074b6341e090e  vmovaps [rsp+0xA0], xmm10
000074b6341e0917  vmovaps [rsp+0xB0], xmm11
000074b6341e0920  vmovaps [rsp+0xC0], xmm12
000074b6341e0929  vmovaps [rsp+0xD0], xmm13
000074b6341e0932  vmovaps [rsp+0xE0], xmm14
000074b6341e093b  sub rsp, 0x30
000074b6341e093f  movaps [rsp], xmm15
000074b6341e0944  movaps [rsp+0x10], xmm11
000074b6341e094a  movaps [rsp+0x20], xmm6
000074b6341e094f  lea rdi, [rsp]
000074b6341e0953  mov esi, 0x00
000074b6341e0958  mov rax, 0x5E1AA0A2F530
000074b6341e0962  call rax
000074b6341e0964  movaps xmm15, [rsp]
000074b6341e0969  add rsp, 0x30
000074b6341e096d  vmovaps xmm0, [rsp]
000074b6341e0972  vmovaps xmm1, [rsp+0x10]
000074b6341e0978  vmovaps xmm2, [rsp+0x20]
000074b6341e097e  vmovaps xmm3, [rsp+0x30]
000074b6341e0984  vmovaps xmm4, [rsp+0x40]
000074b6341e098a  vmovaps xmm5, [rsp+0x50]
000074b6341e0990  vmovaps xmm6, [rsp+0x60]
000074b6341e0996  vmovaps xmm7, [rsp+0x70]
000074b6341e099c  vmovaps xmm8, [rsp+0x80]
000074b6341e09a5  vmovaps xmm9, [rsp+0x90]
000074b6341e09ae  vmovaps xmm10, [rsp+0xA0]
000074b6341e09b7  vmovaps xmm11, [rsp+0xB0]
000074b6341e09c0  vmovaps xmm12, [rsp+0xC0]
000074b6341e09c9  vmovaps xmm13, [rsp+0xD0]
000074b6341e09d2  vmovaps xmm14, [rsp+0xE0]
000074b6341e09db  add rsp, 0xF0
000074b6341e09e2  pop r11
000074b6341e09e4  pop r10
000074b6341e09e6  pop r9
000074b6341e09e8  pop r8
000074b6341e09ea  pop rsi
000074b6341e09eb  pop rdi
000074b6341e09ec  pop rdx
000074b6341e09ed  pop rcx
000074b6341e09ee  pop rax
000074b6341e09ef  add rsp, 0x08
000074b6341e09f3  jmp 0x000074B6341DC658
000074b6341e09f8  sub rsp, 0x08
000074b6341e09fc  push rax
000074b6341e09fd  push rcx
000074b6341e09fe  push rdx
000074b6341e09ff  push rdi
000074b6341e0a00  push rsi
000074b6341e0a01  push r8
000074b6341e0a03  push r9
000074b6341e0a05  push r10
000074b6341e0a07  push r11
000074b6341e0a09  sub rsp, 0xF0
000074b6341e0a10  vmovaps [rsp], xmm0
000074b6341e0a15  vmovaps [rsp+0x10], xmm1
000074b6341e0a1b  vmovaps [rsp+0x20], xmm2
000074b6341e0a21  vmovaps [rsp+0x30], xmm3
000074b6341e0a27  vmovaps [rsp+0x40], xmm4
000074b6341e0a2d  vmovaps [rsp+0x50], xmm5
000074b6341e0a33  vmovaps [rsp+0x60], xmm6
000074b6341e0a39  vmovaps [rsp+0x70], xmm8
000074b6341e0a3f  vmovaps [rsp+0x80], xmm9
000074b6341e0a48  vmovaps [rsp+0x90], xmm10
000074b6341e0a51  vmovaps [rsp+0xA0], xmm11
000074b6341e0a5a  vmovaps [rsp+0xB0], xmm12
000074b6341e0a63  vmovaps [rsp+0xC0], xmm13
000074b6341e0a6c  vmovaps [rsp+0xD0], xmm14
000074b6341e0a75  vmovaps [rsp+0xE0], xmm15
000074b6341e0a7e  sub rsp, 0x30
000074b6341e0a82  movaps [rsp], xmm7
000074b6341e0a86  movaps [rsp+0x10], xmm11
000074b6341e0a8c  movaps [rsp+0x20], xmm9
000074b6341e0a92  lea rdi, [rsp]
000074b6341e0a96  mov esi, 0x00
000074b6341e0a9b  mov rax, 0x5E1AA0A2F530
000074b6341e0aa5  call rax
000074b6341e0aa7  movaps xmm7, [rsp]
000074b6341e0aab  add rsp, 0x30
000074b6341e0aaf  vmovaps xmm0, [rsp]
000074b6341e0ab4  vmovaps xmm1, [rsp+0x10]
000074b6341e0aba  vmovaps xmm2, [rsp+0x20]
000074b6341e0ac0  vmovaps xmm3, [rsp+0x30]
000074b6341e0ac6  vmovaps xmm4, [rsp+0x40]
000074b6341e0acc  vmovaps xmm5, [rsp+0x50]
000074b6341e0ad2  vmovaps xmm6, [rsp+0x60]
000074b6341e0ad8  vmovaps xmm8, [rsp+0x70]
000074b6341e0ade  vmovaps xmm9, [rsp+0x80]
000074b6341e0ae7  vmovaps xmm10, [rsp+0x90]
000074b6341e0af0  vmovaps xmm11, [rsp+0xA0]
000074b6341e0af9  vmovaps xmm12, [rsp+0xB0]
000074b6341e0b02  vmovaps xmm13, [rsp+0xC0]
000074b6341e0b0b  vmovaps xmm14, [rsp+0xD0]
000074b6341e0b14  vmovaps xmm15, [rsp+0xE0]
000074b6341e0b1d  add rsp, 0xF0
000074b6341e0b24  pop r11
000074b6341e0b26  pop r10
000074b6341e0b28  pop r9
000074b6341e0b2a  pop r8
000074b6341e0b2c  pop rsi
000074b6341e0b2d  pop rdi
000074b6341e0b2e  pop rdx
000074b6341e0b2f  pop rcx
000074b6341e0b30  pop rax
000074b6341e0b31  add rsp, 0x08
000074b6341e0b35  jmp 0x000074B6341DC685
000074b6341e0b3a  sub rsp, 0x08
000074b6341e0b3e  push rax
000074b6341e0b3f  push rcx
000074b6341e0b40  push rdx
000074b6341e0b41  push rdi
000074b6341e0b42  push rsi
000074b6341e0b43  push r8
000074b6341e0b45  push r9
000074b6341e0b47  push r10
000074b6341e0b49  push r11
000074b6341e0b4b  sub rsp, 0xF0
000074b6341e0b52  vmovaps [rsp], xmm0
000074b6341e0b57  vmovaps [rsp+0x10], xmm1
000074b6341e0b5d  vmovaps [rsp+0x20], xmm2
000074b6341e0b63  vmovaps [rsp+0x30], xmm3
000074b6341e0b69  vmovaps [rsp+0x40], xmm4
000074b6341e0b6f  vmovaps [rsp+0x50], xmm5
000074b6341e0b75  vmovaps [rsp+0x60], xmm6
000074b6341e0b7b  vmovaps [rsp+0x70], xmm7
000074b6341e0b81  vmovaps [rsp+0x80], xmm8
000074b6341e0b8a  vmovaps [rsp+0x90], xmm9
000074b6341e0b93  vmovaps [rsp+0xA0], xmm10
000074b6341e0b9c  vmovaps [rsp+0xB0], xmm12
000074b6341e0ba5  vmovaps [rsp+0xC0], xmm13
000074b6341e0bae  vmovaps [rsp+0xD0], xmm14
000074b6341e0bb7  vmovaps [rsp+0xE0], xmm15
000074b6341e0bc0  sub rsp, 0x30
000074b6341e0bc4  movaps [rsp], xmm11
000074b6341e0bc9  movaps [rsp+0x10], xmm10
000074b6341e0bcf  movaps [rsp+0x20], xmm14
000074b6341e0bd5  lea rdi, [rsp]
000074b6341e0bd9  mov esi, 0x00
000074b6341e0bde  mov rax, 0x5E1AA0A2F530
000074b6341e0be8  call rax
000074b6341e0bea  movaps xmm11, [rsp]
000074b6341e0bef  add rsp, 0x30
000074b6341e0bf3  vmovaps xmm0, [rsp]
000074b6341e0bf8  vmovaps xmm1, [rsp+0x10]
000074b6341e0bfe  vmovaps xmm2, [rsp+0x20]
000074b6341e0c04  vmovaps xmm3, [rsp+0x30]
000074b6341e0c0a  vmovaps xmm4, [rsp+0x40]
000074b6341e0c10  vmovaps xmm5, [rsp+0x50]
000074b6341e0c16  vmovaps xmm6, [rsp+0x60]
000074b6341e0c1c  vmovaps xmm7, [rsp+0x70]
000074b6341e0c22  vmovaps xmm8, [rsp+0x80]
000074b6341e0c2b  vmovaps xmm9, [rsp+0x90]
000074b6341e0c34  vmovaps xmm10, [rsp+0xA0]
000074b6341e0c3d  vmovaps xmm12, [rsp+0xB0]
000074b6341e0c46  vmovaps xmm13, [rsp+0xC0]
000074b6341e0c4f  vmovaps xmm14, [rsp+0xD0]
000074b6341e0c58  vmovaps xmm15, [rsp+0xE0]
000074b6341e0c61  add rsp, 0xF0
000074b6341e0c68  pop r11
000074b6341e0c6a  pop r10
000074b6341e0c6c  pop r9
000074b6341e0c6e  pop r8
000074b6341e0c70  pop rsi
000074b6341e0c71  pop rdi
000074b6341e0c72  pop rdx
000074b6341e0c73  pop rcx
000074b6341e0c74  pop rax
000074b6341e0c75  add rsp, 0x08
000074b6341e0c79  jmp 0x000074B6341DC6A0
000074b6341e0c7e  call 0x000074B6340C33A0
000074b6341e0c83  jmp 0x000074B6341DC6AA
000074b6341e0c88  sub rsp, 0x08
000074b6341e0c8c  push rax
000074b6341e0c8d  push rcx
000074b6341e0c8e  push rdx
000074b6341e0c8f  push rdi
000074b6341e0c90  push rsi
000074b6341e0c91  push r8
000074b6341e0c93  push r9
000074b6341e0c95  push r10
000074b6341e0c97  push r11
000074b6341e0c99  sub rsp, 0xF0
000074b6341e0ca0  vmovaps [rsp], xmm0
000074b6341e0ca5  vmovaps [rsp+0x10], xmm1
000074b6341e0cab  vmovaps [rsp+0x20], xmm2
000074b6341e0cb1  vmovaps [rsp+0x30], xmm3
000074b6341e0cb7  vmovaps [rsp+0x40], xmm4
000074b6341e0cbd  vmovaps [rsp+0x50], xmm5
000074b6341e0cc3  vmovaps [rsp+0x60], xmm6
000074b6341e0cc9  vmovaps [rsp+0x70], xmm7
000074b6341e0ccf  vmovaps [rsp+0x80], xmm8
000074b6341e0cd8  vmovaps [rsp+0x90], xmm9
000074b6341e0ce1  vmovaps [rsp+0xA0], xmm11
000074b6341e0cea  vmovaps [rsp+0xB0], xmm12
000074b6341e0cf3  vmovaps [rsp+0xC0], xmm13
000074b6341e0cfc  vmovaps [rsp+0xD0], xmm14
000074b6341e0d05  vmovaps [rsp+0xE0], xmm15
000074b6341e0d0e  sub rsp, 0x30
000074b6341e0d12  movaps [rsp], xmm10
000074b6341e0d17  movaps [rsp+0x10], xmm1
000074b6341e0d1c  movaps [rsp+0x20], xmm12
000074b6341e0d22  lea rdi, [rsp]
000074b6341e0d26  mov esi, 0x00
000074b6341e0d2b  mov rax, 0x5E1AA0A2F530
000074b6341e0d35  call rax
000074b6341e0d37  movaps xmm10, [rsp]
000074b6341e0d3c  add rsp, 0x30
000074b6341e0d40  vmovaps xmm0, [rsp]
000074b6341e0d45  vmovaps xmm1, [rsp+0x10]
000074b6341e0d4b  vmovaps xmm2, [rsp+0x20]
000074b6341e0d51  vmovaps xmm3, [rsp+0x30]
000074b6341e0d57  vmovaps xmm4, [rsp+0x40]
000074b6341e0d5d  vmovaps xmm5, [rsp+0x50]
000074b6341e0d63  vmovaps xmm6, [rsp+0x60]
000074b6341e0d69  vmovaps xmm7, [rsp+0x70]
000074b6341e0d6f  vmovaps xmm8, [rsp+0x80]
000074b6341e0d78  vmovaps xmm9, [rsp+0x90]
000074b6341e0d81  vmovaps xmm11, [rsp+0xA0]
000074b6341e0d8a  vmovaps xmm12, [rsp+0xB0]
000074b6341e0d93  vmovaps xmm13, [rsp+0xC0]
000074b6341e0d9c  vmovaps xmm14, [rsp+0xD0]
000074b6341e0da5  vmovaps xmm15, [rsp+0xE0]
000074b6341e0dae  add rsp, 0xF0
000074b6341e0db5  pop r11
000074b6341e0db7  pop r10
000074b6341e0db9  pop r9
000074b6341e0dbb  pop r8
000074b6341e0dbd  pop rsi
000074b6341e0dbe  pop rdi
000074b6341e0dbf  pop rdx
000074b6341e0dc0  pop rcx
000074b6341e0dc1  pop rax
000074b6341e0dc2  add rsp, 0x08
000074b6341e0dc6  jmp 0x000074B6341DC6CD
000074b6341e0dcb  sub rsp, 0x08
000074b6341e0dcf  push rax
000074b6341e0dd0  push rcx
000074b6341e0dd1  push rdx
000074b6341e0dd2  push rdi
000074b6341e0dd3  push rsi
000074b6341e0dd4  push r8
000074b6341e0dd6  push r9
000074b6341e0dd8  push r10
000074b6341e0dda  push r11
000074b6341e0ddc  sub rsp, 0xF0
000074b6341e0de3  vmovaps [rsp], xmm0
000074b6341e0de8  vmovaps [rsp+0x10], xmm1
000074b6341e0dee  vmovaps [rsp+0x20], xmm2
000074b6341e0df4  vmovaps [rsp+0x30], xmm3
000074b6341e0dfa  vmovaps [rsp+0x40], xmm4
000074b6341e0e00  vmovaps [rsp+0x50], xmm5
000074b6341e0e06  vmovaps [rsp+0x60], xmm6
000074b6341e0e0c  vmovaps [rsp+0x70], xmm7
000074b6341e0e12  vmovaps [rsp+0x80], xmm8
000074b6341e0e1b  vmovaps [rsp+0x90], xmm9
000074b6341e0e24  vmovaps [rsp+0xA0], xmm10
000074b6341e0e2d  vmovaps [rsp+0xB0], xmm11
000074b6341e0e36  vmovaps [rsp+0xC0], xmm13
000074b6341e0e3f  vmovaps [rsp+0xD0], xmm14
000074b6341e0e48  vmovaps [rsp+0xE0], xmm15
000074b6341e0e51  sub rsp, 0x30
000074b6341e0e55  movaps [rsp], xmm12
000074b6341e0e5a  movaps [rsp+0x10], xmm14
000074b6341e0e60  movaps [rsp+0x20], xmm1
000074b6341e0e65  lea rdi, [rsp]
000074b6341e0e69  mov esi, 0x00
000074b6341e0e6e  mov rax, 0x5E1AA0A2F530
000074b6341e0e78  call rax
000074b6341e0e7a  movaps xmm12, [rsp]
000074b6341e0e7f  add rsp, 0x30
000074b6341e0e83  vmovaps xmm0, [rsp]
000074b6341e0e88  vmovaps xmm1, [rsp+0x10]
000074b6341e0e8e  vmovaps xmm2, [rsp+0x20]
000074b6341e0e94  vmovaps xmm3, [rsp+0x30]
000074b6341e0e9a  vmovaps xmm4, [rsp+0x40]
000074b6341e0ea0  vmovaps xmm5, [rsp+0x50]
000074b6341e0ea6  vmovaps xmm6, [rsp+0x60]
000074b6341e0eac  vmovaps xmm7, [rsp+0x70]
000074b6341e0eb2  vmovaps xmm8, [rsp+0x80]
000074b6341e0ebb  vmovaps xmm9, [rsp+0x90]
000074b6341e0ec4  vmovaps xmm10, [rsp+0xA0]
000074b6341e0ecd  vmovaps xmm11, [rsp+0xB0]
000074b6341e0ed6  vmovaps xmm13, [rsp+0xC0]
000074b6341e0edf  vmovaps xmm14, [rsp+0xD0]
000074b6341e0ee8  vmovaps xmm15, [rsp+0xE0]
000074b6341e0ef1  add rsp, 0xF0
000074b6341e0ef8  pop r11
000074b6341e0efa  pop r10
000074b6341e0efc  pop r9
000074b6341e0efe  pop r8
000074b6341e0f00  pop rsi
000074b6341e0f01  pop rdi
000074b6341e0f02  pop rdx
000074b6341e0f03  pop rcx
000074b6341e0f04  pop rax
000074b6341e0f05  add rsp, 0x08
000074b6341e0f09  jmp 0x000074B6341DC6FC
000074b6341e0f0e  sub rsp, 0x08
000074b6341e0f12  push rax
000074b6341e0f13  push rcx
000074b6341e0f14  push rdx
000074b6341e0f15  push rdi
000074b6341e0f16  push rsi
000074b6341e0f17  push r8
000074b6341e0f19  push r9
000074b6341e0f1b  push r10
000074b6341e0f1d  push r11
000074b6341e0f1f  sub rsp, 0xF0
000074b6341e0f26  vmovaps [rsp], xmm0
000074b6341e0f2b  vmovaps [rsp+0x10], xmm1
000074b6341e0f31  vmovaps [rsp+0x20], xmm2
000074b6341e0f37  vmovaps [rsp+0x30], xmm3
000074b6341e0f3d  vmovaps [rsp+0x40], xmm4
000074b6341e0f43  vmovaps [rsp+0x50], xmm5
000074b6341e0f49  vmovaps [rsp+0x60], xmm6
000074b6341e0f4f  vmovaps [rsp+0x70], xmm7
000074b6341e0f55  vmovaps [rsp+0x80], xmm8
000074b6341e0f5e  vmovaps [rsp+0x90], xmm9
000074b6341e0f67  vmovaps [rsp+0xA0], xmm10
000074b6341e0f70  vmovaps [rsp+0xB0], xmm11
000074b6341e0f79  vmovaps [rsp+0xC0], xmm12
000074b6341e0f82  vmovaps [rsp+0xD0], xmm13
000074b6341e0f8b  vmovaps [rsp+0xE0], xmm15
000074b6341e0f94  sub rsp, 0x30
000074b6341e0f98  movaps [rsp], xmm14
000074b6341e0f9d  movaps [rsp+0x10], xmm9
000074b6341e0fa3  movaps [rsp+0x20], xmm1
000074b6341e0fa8  lea rdi, [rsp]
000074b6341e0fac  mov esi, 0x00
000074b6341e0fb1  mov rax, 0x5E1AA0A2F530
000074b6341e0fbb  call rax
000074b6341e0fbd  movaps xmm14, [rsp]
000074b6341e0fc2  add rsp, 0x30
000074b6341e0fc6  vmovaps xmm0, [rsp]
000074b6341e0fcb  vmovaps xmm1, [rsp+0x10]
000074b6341e0fd1  vmovaps xmm2, [rsp+0x20]
000074b6341e0fd7  vmovaps xmm3, [rsp+0x30]
000074b6341e0fdd  vmovaps xmm4, [rsp+0x40]
000074b6341e0fe3  vmovaps xmm5, [rsp+0x50]
000074b6341e0fe9  vmovaps xmm6, [rsp+0x60]
000074b6341e0fef  vmovaps xmm7, [rsp+0x70]
000074b6341e0ff5  vmovaps xmm8, [rsp+0x80]
000074b6341e0ffe  vmovaps xmm9, [rsp+0x90]
000074b6341e1007  vmovaps xmm10, [rsp+0xA0]
000074b6341e1010  vmovaps xmm11, [rsp+0xB0]
000074b6341e1019  vmovaps xmm12, [rsp+0xC0]
000074b6341e1022  vmovaps xmm13, [rsp+0xD0]
000074b6341e102b  vmovaps xmm15, [rsp+0xE0]
000074b6341e1034  add rsp, 0xF0
000074b6341e103b  pop r11
000074b6341e103d  pop r10
000074b6341e103f  pop r9
000074b6341e1041  pop r8
000074b6341e1043  pop rsi
000074b6341e1044  pop rdi
000074b6341e1045  pop rdx
000074b6341e1046  pop rcx
000074b6341e1047  pop rax
000074b6341e1048  add rsp, 0x08
000074b6341e104c  jmp 0x000074B6341DC72B
000074b6341e1051  sub rsp, 0x08
000074b6341e1055  push rax
000074b6341e1056  push rcx
000074b6341e1057  push rdx
000074b6341e1058  push rdi
000074b6341e1059  push rsi
000074b6341e105a  push r8
000074b6341e105c  push r9
000074b6341e105e  push r10
000074b6341e1060  push r11
000074b6341e1062  sub rsp, 0xF0
000074b6341e1069  vmovaps [rsp], xmm0
000074b6341e106e  vmovaps [rsp+0x10], xmm2
000074b6341e1074  vmovaps [rsp+0x20], xmm3
000074b6341e107a  vmovaps [rsp+0x30], xmm4
000074b6341e1080  vmovaps [rsp+0x40], xmm5
000074b6341e1086  vmovaps [rsp+0x50], xmm6
000074b6341e108c  vmovaps [rsp+0x60], xmm7
000074b6341e1092  vmovaps [rsp+0x70], xmm8
000074b6341e1098  vmovaps [rsp+0x80], xmm9
000074b6341e10a1  vmovaps [rsp+0x90], xmm10
000074b6341e10aa  vmovaps [rsp+0xA0], xmm11
000074b6341e10b3  vmovaps [rsp+0xB0], xmm12
000074b6341e10bc  vmovaps [rsp+0xC0], xmm13
000074b6341e10c5  vmovaps [rsp+0xD0], xmm14
000074b6341e10ce  vmovaps [rsp+0xE0], xmm15
000074b6341e10d7  sub rsp, 0x30
000074b6341e10db  movaps [rsp], xmm1
000074b6341e10df  movaps [rsp+0x10], xmm13
000074b6341e10e5  movaps [rsp+0x20], xmm8
000074b6341e10eb  lea rdi, [rsp]
000074b6341e10ef  mov esi, 0x00
000074b6341e10f4  mov rax, 0x5E1AA0A2F530
000074b6341e10fe  call rax
000074b6341e1100  movaps xmm1, [rsp]
000074b6341e1104  add rsp, 0x30
000074b6341e1108  vmovaps xmm0, [rsp]
000074b6341e110d  vmovaps xmm2, [rsp+0x10]
000074b6341e1113  vmovaps xmm3, [rsp+0x20]
000074b6341e1119  vmovaps xmm4, [rsp+0x30]
000074b6341e111f  vmovaps xmm5, [rsp+0x40]
000074b6341e1125  vmovaps xmm6, [rsp+0x50]
000074b6341e112b  vmovaps xmm7, [rsp+0x60]
000074b6341e1131  vmovaps xmm8, [rsp+0x70]
000074b6341e1137  vmovaps xmm9, [rsp+0x80]
000074b6341e1140  vmovaps xmm10, [rsp+0x90]
000074b6341e1149  vmovaps xmm11, [rsp+0xA0]
000074b6341e1152  vmovaps xmm12, [rsp+0xB0]
000074b6341e115b  vmovaps xmm13, [rsp+0xC0]
000074b6341e1164  vmovaps xmm14, [rsp+0xD0]
000074b6341e116d  vmovaps xmm15, [rsp+0xE0]
000074b6341e1176  add rsp, 0xF0
000074b6341e117d  pop r11
000074b6341e117f  pop r10
000074b6341e1181  pop r9
000074b6341e1183  pop r8
000074b6341e1185  pop rsi
000074b6341e1186  pop rdi
000074b6341e1187  pop rdx
000074b6341e1188  pop rcx
000074b6341e1189  pop rax
000074b6341e118a  add rsp, 0x08
000074b6341e118e  jmp 0x000074B6341DC74D
000074b6341e1193  call 0x000074B63400C260
000074b6341e1198  jmp 0x000074B6341DC75B
000074b6341e119d  call 0x000074B6340BD750
000074b6341e11a2  jmp 0x000074B6341DC765
000074b6341e11a7  sub rsp, 0x08
000074b6341e11ab  push rax
000074b6341e11ac  push rcx
000074b6341e11ad  push rdx
000074b6341e11ae  push rdi
000074b6341e11af  push rsi
000074b6341e11b0  push r8
000074b6341e11b2  push r9
000074b6341e11b4  push r10
000074b6341e11b6  push r11
000074b6341e11b8  sub rsp, 0xF0
000074b6341e11bf  vmovaps [rsp], xmm0
000074b6341e11c4  vmovaps [rsp+0x10], xmm1
000074b6341e11ca  vmovaps [rsp+0x20], xmm2
000074b6341e11d0  vmovaps [rsp+0x30], xmm3
000074b6341e11d6  vmovaps [rsp+0x40], xmm4
000074b6341e11dc  vmovaps [rsp+0x50], xmm5
000074b6341e11e2  vmovaps [rsp+0x60], xmm6
000074b6341e11e8  vmovaps [rsp+0x70], xmm7
000074b6341e11ee  vmovaps [rsp+0x80], xmm9
000074b6341e11f7  vmovaps [rsp+0x90], xmm10
000074b6341e1200  vmovaps [rsp+0xA0], xmm11
000074b6341e1209  vmovaps [rsp+0xB0], xmm12
000074b6341e1212  vmovaps [rsp+0xC0], xmm13
000074b6341e121b  vmovaps [rsp+0xD0], xmm14
000074b6341e1224  vmovaps [rsp+0xE0], xmm15
000074b6341e122d  sub rsp, 0x30
000074b6341e1231  movaps [rsp], xmm8
000074b6341e1236  movaps [rsp+0x10], xmm15
000074b6341e123c  movaps [rsp+0x20], xmm7
000074b6341e1241  lea rdi, [rsp]
000074b6341e1245  mov esi, 0x00
000074b6341e124a  mov rax, 0x5E1AA0A2F530
000074b6341e1254  call rax
000074b6341e1256  movaps xmm8, [rsp]
000074b6341e125b  add rsp, 0x30
000074b6341e125f  vmovaps xmm0, [rsp]
000074b6341e1264  vmovaps xmm1, [rsp+0x10]
000074b6341e126a  vmovaps xmm2, [rsp+0x20]
000074b6341e1270  vmovaps xmm3, [rsp+0x30]
000074b6341e1276  vmovaps xmm4, [rsp+0x40]
000074b6341e127c  vmovaps xmm5, [rsp+0x50]
000074b6341e1282  vmovaps xmm6, [rsp+0x60]
000074b6341e1288  vmovaps xmm7, [rsp+0x70]
000074b6341e128e  vmovaps xmm9, [rsp+0x80]
000074b6341e1297  vmovaps xmm10, [rsp+0x90]
000074b6341e12a0  vmovaps xmm11, [rsp+0xA0]
000074b6341e12a9  vmovaps xmm12, [rsp+0xB0]
000074b6341e12b2  vmovaps xmm13, [rsp+0xC0]
000074b6341e12bb  vmovaps xmm14, [rsp+0xD0]
000074b6341e12c4  vmovaps xmm15, [rsp+0xE0]
000074b6341e12cd  add rsp, 0xF0
000074b6341e12d4  pop r11
000074b6341e12d6  pop r10
000074b6341e12d8  pop r9
000074b6341e12da  pop r8
000074b6341e12dc  pop rsi
000074b6341e12dd  pop rdi
000074b6341e12de  pop rdx
000074b6341e12df  pop rcx
000074b6341e12e0  pop rax
000074b6341e12e1  add rsp, 0x08
000074b6341e12e5  jmp 0x000074B6341DC787
000074b6341e12ea  sub rsp, 0x08
000074b6341e12ee  push rax
000074b6341e12ef  push rcx
000074b6341e12f0  push rdx
000074b6341e12f1  push rdi
000074b6341e12f2  push rsi
000074b6341e12f3  push r8
000074b6341e12f5  push r9
000074b6341e12f7  push r10
000074b6341e12f9  push r11
000074b6341e12fb  sub rsp, 0xF0
000074b6341e1302  vmovaps [rsp], xmm0
000074b6341e1307  vmovaps [rsp+0x10], xmm1
000074b6341e130d  vmovaps [rsp+0x20], xmm2
000074b6341e1313  vmovaps [rsp+0x30], xmm3
000074b6341e1319  vmovaps [rsp+0x40], xmm4
000074b6341e131f  vmovaps [rsp+0x50], xmm5
000074b6341e1325  vmovaps [rsp+0x60], xmm6
000074b6341e132b  vmovaps [rsp+0x70], xmm8
000074b6341e1331  vmovaps [rsp+0x80], xmm9
000074b6341e133a  vmovaps [rsp+0x90], xmm10
000074b6341e1343  vmovaps [rsp+0xA0], xmm11
000074b6341e134c  vmovaps [rsp+0xB0], xmm12
000074b6341e1355  vmovaps [rsp+0xC0], xmm13
000074b6341e135e  vmovaps [rsp+0xD0], xmm14
000074b6341e1367  vmovaps [rsp+0xE0], xmm15
000074b6341e1370  sub rsp, 0x30
000074b6341e1374  movaps [rsp], xmm7
000074b6341e1378  movaps [rsp+0x10], xmm9
000074b6341e137e  movaps [rsp+0x20], xmm15
000074b6341e1384  lea rdi, [rsp]
000074b6341e1388  mov esi, 0x00
000074b6341e138d  mov rax, 0x5E1AA0A2F530
000074b6341e1397  call rax
000074b6341e1399  movaps xmm7, [rsp]
000074b6341e139d  add rsp, 0x30
000074b6341e13a1  vmovaps xmm0, [rsp]
000074b6341e13a6  vmovaps xmm1, [rsp+0x10]
000074b6341e13ac  vmovaps xmm2, [rsp+0x20]
000074b6341e13b2  vmovaps xmm3, [rsp+0x30]
000074b6341e13b8  vmovaps xmm4, [rsp+0x40]
000074b6341e13be  vmovaps xmm5, [rsp+0x50]
000074b6341e13c4  vmovaps xmm6, [rsp+0x60]
000074b6341e13ca  vmovaps xmm8, [rsp+0x70]
000074b6341e13d0  vmovaps xmm9, [rsp+0x80]
000074b6341e13d9  vmovaps xmm10, [rsp+0x90]
000074b6341e13e2  vmovaps xmm11, [rsp+0xA0]
000074b6341e13eb  vmovaps xmm12, [rsp+0xB0]
000074b6341e13f4  vmovaps xmm13, [rsp+0xC0]
000074b6341e13fd  vmovaps xmm14, [rsp+0xD0]
000074b6341e1406  vmovaps xmm15, [rsp+0xE0]
000074b6341e140f  add rsp, 0xF0
000074b6341e1416  pop r11
000074b6341e1418  pop r10
000074b6341e141a  pop r9
000074b6341e141c  pop r8
000074b6341e141e  pop rsi
000074b6341e141f  pop rdi
000074b6341e1420  pop rdx
000074b6341e1421  pop rcx
000074b6341e1422  pop rax
000074b6341e1423  add rsp, 0x08
000074b6341e1427  jmp 0x000074B6341DC7B4
000074b6341e142c  sub rsp, 0x08
000074b6341e1430  push rax
000074b6341e1431  push rcx
000074b6341e1432  push rdx
000074b6341e1433  push rdi
000074b6341e1434  push rsi
000074b6341e1435  push r8
000074b6341e1437  push r9
000074b6341e1439  push r10
000074b6341e143b  push r11
000074b6341e143d  sub rsp, 0xF0
000074b6341e1444  vmovaps [rsp], xmm0
000074b6341e1449  vmovaps [rsp+0x10], xmm1
000074b6341e144f  vmovaps [rsp+0x20], xmm2
000074b6341e1455  vmovaps [rsp+0x30], xmm3
000074b6341e145b  vmovaps [rsp+0x40], xmm4
000074b6341e1461  vmovaps [rsp+0x50], xmm5
000074b6341e1467  vmovaps [rsp+0x60], xmm6
000074b6341e146d  vmovaps [rsp+0x70], xmm7
000074b6341e1473  vmovaps [rsp+0x80], xmm8
000074b6341e147c  vmovaps [rsp+0x90], xmm10
000074b6341e1485  vmovaps [rsp+0xA0], xmm11
000074b6341e148e  vmovaps [rsp+0xB0], xmm12
000074b6341e1497  vmovaps [rsp+0xC0], xmm13
000074b6341e14a0  vmovaps [rsp+0xD0], xmm14
000074b6341e14a9  vmovaps [rsp+0xE0], xmm15
000074b6341e14b2  sub rsp, 0x30
000074b6341e14b6  movaps [rsp], xmm9
000074b6341e14bb  movaps [rsp+0x10], xmm13
000074b6341e14c1  movaps [rsp+0x20], xmm15
000074b6341e14c7  lea rdi, [rsp]
000074b6341e14cb  mov esi, 0x00
000074b6341e14d0  mov rax, 0x5E1AA0A2F530
000074b6341e14da  call rax
000074b6341e14dc  movaps xmm9, [rsp]
000074b6341e14e1  add rsp, 0x30
000074b6341e14e5  vmovaps xmm0, [rsp]
000074b6341e14ea  vmovaps xmm1, [rsp+0x10]
000074b6341e14f0  vmovaps xmm2, [rsp+0x20]
000074b6341e14f6  vmovaps xmm3, [rsp+0x30]
000074b6341e14fc  vmovaps xmm4, [rsp+0x40]
000074b6341e1502  vmovaps xmm5, [rsp+0x50]
000074b6341e1508  vmovaps xmm6, [rsp+0x60]
000074b6341e150e  vmovaps xmm7, [rsp+0x70]
000074b6341e1514  vmovaps xmm8, [rsp+0x80]
000074b6341e151d  vmovaps xmm10, [rsp+0x90]
000074b6341e1526  vmovaps xmm11, [rsp+0xA0]
000074b6341e152f  vmovaps xmm12, [rsp+0xB0]
000074b6341e1538  vmovaps xmm13, [rsp+0xC0]
000074b6341e1541  vmovaps xmm14, [rsp+0xD0]
000074b6341e154a  vmovaps xmm15, [rsp+0xE0]
000074b6341e1553  add rsp, 0xF0
000074b6341e155a  pop r11
000074b6341e155c  pop r10
000074b6341e155e  pop r9
000074b6341e1560  pop r8
000074b6341e1562  pop rsi
000074b6341e1563  pop rdi
000074b6341e1564  pop rdx
000074b6341e1565  pop rcx
000074b6341e1566  pop rax
000074b6341e1567  add rsp, 0x08
000074b6341e156b  jmp 0x000074B6341DC7E2
000074b6341e1570  sub rsp, 0x08
000074b6341e1574  push rax
000074b6341e1575  push rcx
000074b6341e1576  push rdx
000074b6341e1577  push rdi
000074b6341e1578  push rsi
000074b6341e1579  push r8
000074b6341e157b  push r9
000074b6341e157d  push r10
000074b6341e157f  push r11
000074b6341e1581  sub rsp, 0xF0
000074b6341e1588  vmovaps [rsp], xmm0
000074b6341e158d  vmovaps [rsp+0x10], xmm1
000074b6341e1593  vmovaps [rsp+0x20], xmm2
000074b6341e1599  vmovaps [rsp+0x30], xmm3
000074b6341e159f  vmovaps [rsp+0x40], xmm4
000074b6341e15a5  vmovaps [rsp+0x50], xmm5
000074b6341e15ab  vmovaps [rsp+0x60], xmm6
000074b6341e15b1  vmovaps [rsp+0x70], xmm7
000074b6341e15b7  vmovaps [rsp+0x80], xmm8
000074b6341e15c0  vmovaps [rsp+0x90], xmm9
000074b6341e15c9  vmovaps [rsp+0xA0], xmm10
000074b6341e15d2  vmovaps [rsp+0xB0], xmm11
000074b6341e15db  vmovaps [rsp+0xC0], xmm12
000074b6341e15e4  vmovaps [rsp+0xD0], xmm13
000074b6341e15ed  vmovaps [rsp+0xE0], xmm14
000074b6341e15f6  sub rsp, 0x30
000074b6341e15fa  movaps [rsp], xmm15
000074b6341e15ff  movaps [rsp+0x10], xmm11
000074b6341e1605  movaps [rsp+0x20], xmm12
000074b6341e160b  lea rdi, [rsp]
000074b6341e160f  mov esi, 0x00
000074b6341e1614  mov rax, 0x5E1AA0A2F530
000074b6341e161e  call rax
000074b6341e1620  movaps xmm15, [rsp]
000074b6341e1625  add rsp, 0x30
000074b6341e1629  vmovaps xmm0, [rsp]
000074b6341e162e  vmovaps xmm1, [rsp+0x10]
000074b6341e1634  vmovaps xmm2, [rsp+0x20]
000074b6341e163a  vmovaps xmm3, [rsp+0x30]
000074b6341e1640  vmovaps xmm4, [rsp+0x40]
000074b6341e1646  vmovaps xmm5, [rsp+0x50]
000074b6341e164c  vmovaps xmm6, [rsp+0x60]
000074b6341e1652  vmovaps xmm7, [rsp+0x70]
000074b6341e1658  vmovaps xmm8, [rsp+0x80]
000074b6341e1661  vmovaps xmm9, [rsp+0x90]
000074b6341e166a  vmovaps xmm10, [rsp+0xA0]
000074b6341e1673  vmovaps xmm11, [rsp+0xB0]
000074b6341e167c  vmovaps xmm12, [rsp+0xC0]
000074b6341e1685  vmovaps xmm13, [rsp+0xD0]
000074b6341e168e  vmovaps xmm14, [rsp+0xE0]
000074b6341e1697  add rsp, 0xF0
000074b6341e169e  pop r11
000074b6341e16a0  pop r10
000074b6341e16a2  pop r9
000074b6341e16a4  pop r8
000074b6341e16a6  pop rsi
000074b6341e16a7  pop rdi
000074b6341e16a8  pop rdx
000074b6341e16a9  pop rcx
000074b6341e16aa  pop rax
000074b6341e16ab  add rsp, 0x08
000074b6341e16af  jmp 0x000074B6341DC7FD
000074b6341e16b4  sub rsp, 0x08
000074b6341e16b8  push rax
000074b6341e16b9  push rcx
000074b6341e16ba  push rdx
000074b6341e16bb  push rdi
000074b6341e16bc  push rsi
000074b6341e16bd  push r8
000074b6341e16bf  push r9
000074b6341e16c1  push r10
000074b6341e16c3  push r11
000074b6341e16c5  sub rsp, 0xF0
000074b6341e16cc  vmovaps [rsp], xmm0
000074b6341e16d1  vmovaps [rsp+0x10], xmm1
000074b6341e16d7  vmovaps [rsp+0x20], xmm2
000074b6341e16dd  vmovaps [rsp+0x30], xmm3
000074b6341e16e3  vmovaps [rsp+0x40], xmm4
000074b6341e16e9  vmovaps [rsp+0x50], xmm5
000074b6341e16ef  vmovaps [rsp+0x60], xmm6
000074b6341e16f5  vmovaps [rsp+0x70], xmm7
000074b6341e16fb  vmovaps [rsp+0x80], xmm8
000074b6341e1704  vmovaps [rsp+0x90], xmm9
000074b6341e170d  vmovaps [rsp+0xA0], xmm10
000074b6341e1716  vmovaps [rsp+0xB0], xmm11
000074b6341e171f  vmovaps [rsp+0xC0], xmm12
000074b6341e1728  vmovaps [rsp+0xD0], xmm14
000074b6341e1731  vmovaps [rsp+0xE0], xmm15
000074b6341e173a  sub rsp, 0x30
000074b6341e173e  movaps [rsp], xmm13
000074b6341e1743  movaps [rsp+0x10], xmm10
000074b6341e1749  movaps [rsp+0x20], xmm14
000074b6341e174f  lea rdi, [rsp]
000074b6341e1753  mov esi, 0x00
000074b6341e1758  mov rax, 0x5E1AA0A2F530
000074b6341e1762  call rax
000074b6341e1764  movaps xmm13, [rsp]
000074b6341e1769  add rsp, 0x30
000074b6341e176d  vmovaps xmm0, [rsp]
000074b6341e1772  vmovaps xmm1, [rsp+0x10]
000074b6341e1778  vmovaps xmm2, [rsp+0x20]
000074b6341e177e  vmovaps xmm3, [rsp+0x30]
000074b6341e1784  vmovaps xmm4, [rsp+0x40]
000074b6341e178a  vmovaps xmm5, [rsp+0x50]
000074b6341e1790  vmovaps xmm6, [rsp+0x60]
000074b6341e1796  vmovaps xmm7, [rsp+0x70]
000074b6341e179c  vmovaps xmm8, [rsp+0x80]
000074b6341e17a5  vmovaps xmm9, [rsp+0x90]
000074b6341e17ae  vmovaps xmm10, [rsp+0xA0]
000074b6341e17b7  vmovaps xmm11, [rsp+0xB0]
000074b6341e17c0  vmovaps xmm12, [rsp+0xC0]
000074b6341e17c9  vmovaps xmm14, [rsp+0xD0]
000074b6341e17d2  vmovaps xmm15, [rsp+0xE0]
000074b6341e17db  add rsp, 0xF0
000074b6341e17e2  pop r11
000074b6341e17e4  pop r10
000074b6341e17e6  pop r9
000074b6341e17e8  pop r8
000074b6341e17ea  pop rsi
000074b6341e17eb  pop rdi
000074b6341e17ec  pop rdx
000074b6341e17ed  pop rcx
000074b6341e17ee  pop rax
000074b6341e17ef  add rsp, 0x08
000074b6341e17f3  jmp 0x000074B6341DC820
000074b6341e17f8  sub rsp, 0x08
000074b6341e17fc  push rax
000074b6341e17fd  push rcx
000074b6341e17fe  push rdx
000074b6341e17ff  push rdi
000074b6341e1800  push rsi
000074b6341e1801  push r8
000074b6341e1803  push r9
000074b6341e1805  push r10
000074b6341e1807  push r11
000074b6341e1809  sub rsp, 0xF0
000074b6341e1810  vmovaps [rsp], xmm0
000074b6341e1815  vmovaps [rsp+0x10], xmm1
000074b6341e181b  vmovaps [rsp+0x20], xmm2
000074b6341e1821  vmovaps [rsp+0x30], xmm3
000074b6341e1827  vmovaps [rsp+0x40], xmm4
000074b6341e182d  vmovaps [rsp+0x50], xmm5
000074b6341e1833  vmovaps [rsp+0x60], xmm6
000074b6341e1839  vmovaps [rsp+0x70], xmm7
000074b6341e183f  vmovaps [rsp+0x80], xmm8
000074b6341e1848  vmovaps [rsp+0x90], xmm9
000074b6341e1851  vmovaps [rsp+0xA0], xmm10
000074b6341e185a  vmovaps [rsp+0xB0], xmm11
000074b6341e1863  vmovaps [rsp+0xC0], xmm12
000074b6341e186c  vmovaps [rsp+0xD0], xmm13
000074b6341e1875  vmovaps [rsp+0xE0], xmm15
000074b6341e187e  sub rsp, 0x30
000074b6341e1882  movaps [rsp], xmm14
000074b6341e1887  movaps [rsp+0x10], xmm1
000074b6341e188c  movaps [rsp+0x20], xmm7
000074b6341e1891  lea rdi, [rsp]
000074b6341e1895  mov esi, 0x00
000074b6341e189a  mov rax, 0x5E1AA0A2F530
000074b6341e18a4  call rax
000074b6341e18a6  movaps xmm14, [rsp]
000074b6341e18ab  add rsp, 0x30
000074b6341e18af  vmovaps xmm0, [rsp]
000074b6341e18b4  vmovaps xmm1, [rsp+0x10]
000074b6341e18ba  vmovaps xmm2, [rsp+0x20]
000074b6341e18c0  vmovaps xmm3, [rsp+0x30]
000074b6341e18c6  vmovaps xmm4, [rsp+0x40]
000074b6341e18cc  vmovaps xmm5, [rsp+0x50]
000074b6341e18d2  vmovaps xmm6, [rsp+0x60]
000074b6341e18d8  vmovaps xmm7, [rsp+0x70]
000074b6341e18de  vmovaps xmm8, [rsp+0x80]
000074b6341e18e7  vmovaps xmm9, [rsp+0x90]
000074b6341e18f0  vmovaps xmm10, [rsp+0xA0]
000074b6341e18f9  vmovaps xmm11, [rsp+0xB0]
000074b6341e1902  vmovaps xmm12, [rsp+0xC0]
000074b6341e190b  vmovaps xmm13, [rsp+0xD0]
000074b6341e1914  vmovaps xmm15, [rsp+0xE0]
000074b6341e191d  add rsp, 0xF0
000074b6341e1924  pop r11
000074b6341e1926  pop r10
000074b6341e1928  pop r9
000074b6341e192a  pop r8
000074b6341e192c  pop rsi
000074b6341e192d  pop rdi
000074b6341e192e  pop rdx
000074b6341e192f  pop rcx
000074b6341e1930  pop rax
000074b6341e1931  add rsp, 0x08
000074b6341e1935  jmp 0x000074B6341DC843
000074b6341e193a  sub rsp, 0x08
000074b6341e193e  push rax
000074b6341e193f  push rcx
000074b6341e1940  push rdx
000074b6341e1941  push rdi
000074b6341e1942  push rsi
000074b6341e1943  push r8
000074b6341e1945  push r9
000074b6341e1947  push r10
000074b6341e1949  push r11
000074b6341e194b  sub rsp, 0xF0
000074b6341e1952  vmovaps [rsp], xmm0
000074b6341e1957  vmovaps [rsp+0x10], xmm2
000074b6341e195d  vmovaps [rsp+0x20], xmm3
000074b6341e1963  vmovaps [rsp+0x30], xmm4
000074b6341e1969  vmovaps [rsp+0x40], xmm5
000074b6341e196f  vmovaps [rsp+0x50], xmm6
000074b6341e1975  vmovaps [rsp+0x60], xmm7
000074b6341e197b  vmovaps [rsp+0x70], xmm8
000074b6341e1981  vmovaps [rsp+0x80], xmm9
000074b6341e198a  vmovaps [rsp+0x90], xmm10
000074b6341e1993  vmovaps [rsp+0xA0], xmm11
000074b6341e199c  vmovaps [rsp+0xB0], xmm12
000074b6341e19a5  vmovaps [rsp+0xC0], xmm13
000074b6341e19ae  vmovaps [rsp+0xD0], xmm14
000074b6341e19b7  vmovaps [rsp+0xE0], xmm15
000074b6341e19c0  sub rsp, 0x30
000074b6341e19c4  movaps [rsp], xmm1
000074b6341e19c8  movaps [rsp+0x10], xmm8
000074b6341e19ce  movaps [rsp+0x20], xmm9
000074b6341e19d4  lea rdi, [rsp]
000074b6341e19d8  mov esi, 0x00
000074b6341e19dd  mov rax, 0x5E1AA0A2F530
000074b6341e19e7  call rax
000074b6341e19e9  movaps xmm1, [rsp]
000074b6341e19ed  add rsp, 0x30
000074b6341e19f1  vmovaps xmm0, [rsp]
000074b6341e19f6  vmovaps xmm2, [rsp+0x10]
000074b6341e19fc  vmovaps xmm3, [rsp+0x20]
000074b6341e1a02  vmovaps xmm4, [rsp+0x30]
000074b6341e1a08  vmovaps xmm5, [rsp+0x40]
000074b6341e1a0e  vmovaps xmm6, [rsp+0x50]
000074b6341e1a14  vmovaps xmm7, [rsp+0x60]
000074b6341e1a1a  vmovaps xmm8, [rsp+0x70]
000074b6341e1a20  vmovaps xmm9, [rsp+0x80]
000074b6341e1a29  vmovaps xmm10, [rsp+0x90]
000074b6341e1a32  vmovaps xmm11, [rsp+0xA0]
000074b6341e1a3b  vmovaps xmm12, [rsp+0xB0]
000074b6341e1a44  vmovaps xmm13, [rsp+0xC0]
000074b6341e1a4d  vmovaps xmm14, [rsp+0xD0]
000074b6341e1a56  vmovaps xmm15, [rsp+0xE0]
000074b6341e1a5f  add rsp, 0xF0
000074b6341e1a66  pop r11
000074b6341e1a68  pop r10
000074b6341e1a6a  pop r9
000074b6341e1a6c  pop r8
000074b6341e1a6e  pop rsi
000074b6341e1a6f  pop rdi
000074b6341e1a70  pop rdx
000074b6341e1a71  pop rcx
000074b6341e1a72  pop rax
000074b6341e1a73  add rsp, 0x08
000074b6341e1a77  jmp 0x000074B6341DC865
000074b6341e1a7c  call 0x000074B6340E5940
000074b6341e1a81  jmp 0x000074B6341DC873
000074b6341e1a86  call 0x000074B63400C380
000074b6341e1a8b  jmp 0x000074B6341DC87D
000074b6341e1a90  call 0x000074B63400D600
000074b6341e1a95  jmp 0x000074B6341DC887
000074b6341e1a9a  call 0x000074B633FFF540
000074b6341e1a9f  jmp 0x000074B6341DC891
000074b6341e1aa4  int3
000074b6341e1aa5  nop [rax+rax*1], ax
000074b6341e1aae  nop
000074b6341e1ab0  mov rax, [r15+0xF8]
000074b6341e1ab7  lea r14, [rax+0x140]
000074b6341e1abe  mov r12, [r13+r14*1]
000074b6341e1ac3  mov [r15+0xE8], r12
000074b6341e1aca  lea r14, [rax+0x130]
000074b6341e1ad1  mov r12, [r13+r14*1]
000074b6341e1ad6  lea r14, [rax+0x138]
000074b6341e1add  mov r11, [r13+r14*1]
000074b6341e1ae2  movq xmm1, r12
000074b6341e1ae7  movq xmm15, r11
000074b6341e1aec  movq xmm1, xmm1
000074b6341e1af0  movq xmm1, xmm1
000074b6341e1af4  movaps [r15+0x1A0], xmm1
000074b6341e1afc  movq xmm15, xmm15
000074b6341e1b01  movq xmm15, xmm15
000074b6341e1b06  movaps [r15+0x190], xmm15
000074b6341e1b0e  lea r14, [rax+0x120]
000074b6341e1b15  mov r12, [r13+r14*1]
000074b6341e1b1a  lea r14, [rax+0x128]
000074b6341e1b21  mov r11, [r13+r14*1]
000074b6341e1b26  movq xmm1, r12
000074b6341e1b2b  movq xmm15, r11
000074b6341e1b30  movq xmm1, xmm1
000074b6341e1b34  movq xmm1, xmm1
000074b6341e1b38  movaps [r15+0x1C0], xmm1
000074b6341e1b40  movq xmm15, xmm15
000074b6341e1b45  movq xmm15, xmm15
000074b6341e1b4a  movaps [r15+0x1B0], xmm15
000074b6341e1b52  lea r14, [rax+0x110]
000074b6341e1b59  mov r12, [r13+r14*1]
000074b6341e1b5e  lea r14, [rax+0x118]
000074b6341e1b65  mov r11, [r13+r14*1]
000074b6341e1b6a  movq xmm1, r12
000074b6341e1b6f  movq xmm15, r11
000074b6341e1b74  movq xmm1, xmm1
000074b6341e1b78  movq xmm1, xmm1
000074b6341e1b7c  movaps [r15+0x1E0], xmm1
000074b6341e1b84  movq xmm15, xmm15
000074b6341e1b89  movq xmm15, xmm15
000074b6341e1b8e  movaps [r15+0x1D0], xmm15
000074b6341e1b96  lea r14, [rax+0x100]
000074b6341e1b9d  mov r12, [r13+r14*1]
000074b6341e1ba2  lea r14, [rax+0x108]
000074b6341e1ba9  mov r11, [r13+r14*1]
000074b6341e1bae  movq xmm1, r12
000074b6341e1bb3  movq xmm15, r11
000074b6341e1bb8  movq xmm1, xmm1
000074b6341e1bbc  movq xmm1, xmm1
000074b6341e1bc0  movaps [r15+0x200], xmm1
000074b6341e1bc8  movq xmm15, xmm15
000074b6341e1bcd  movq xmm15, xmm15
000074b6341e1bd2  movaps [r15+0x1F0], xmm15
000074b6341e1bda  mov qword ptr [r15+0x40], 0x430000
000074b6341e1be2  mov r14d, 0x430510
000074b6341e1be8  mov r12, [r13+r14*1]
000074b6341e1bed  movq xmm1, r12
000074b6341e1bf2  lea r14, [rax+0x150]
000074b6341e1bf9  mov [r15+0xF8], r14
000074b6341e1c00  mov rax, [r15+0x50]
000074b6341e1c04  movups xmm15, [r13+rax*1]
000074b6341e1c0a  movaps [r15+0x120], xmm15
000074b6341e1c12  mov qword ptr [r15+0x48], 0x10
000074b6341e1c1a  xor eax, eax
000074b6341e1c1c  mov r14d, 0x10
000074b6341e1c22  mov r12d, 0x200
000074b6341e1c28  cmp r14, r12
000074b6341e1c2b  cmc
000074b6341e1c2c  lahf
000074b6341e1c2d  seto al
000074b6341e1c30  mov [r15+0x108], eax
000074b6341e1c37  pextrq rax, xmm15, 0x01
000074b6341e1c3e  movq xmm14, rax
000074b6341e1c43  movaps [r15+0x130], xmm14
000074b6341e1c4b  movq rax, xmm1
000074b6341e1c50  movq r14, xmm15
000074b6341e1c55  vmovq xmm1, rax
000074b6341e1c5a  vmovq xmm15, r14
000074b6341e1c5f  movaps xmm13, xmm1
000074b6341e1c63  addsd xmm13, xmm15
000074b6341e1c68  ucomisd xmm13, xmm13
000074b6341e1c6d  jp 0x000074B6341E1D86
000074b6341e1c73  movq xmm13, xmm13
000074b6341e1c78  movq rax, xmm13
000074b6341e1c7d  movq r14, xmm14
000074b6341e1c82  vmovq xmm1, rax
000074b6341e1c87  vmovq xmm15, r14
000074b6341e1c8c  movaps xmm14, xmm1
000074b6341e1c90  addsd xmm14, xmm15
000074b6341e1c95  ucomisd xmm14, xmm14
000074b6341e1c9a  jp 0x000074B6341E1DCE
000074b6341e1ca0  movq xmm14, xmm14
000074b6341e1ca5  movaps [r15+0x110], xmm14
000074b6341e1cad  mov eax, [r15+0x108]
000074b6341e1cb4  sahf
000074b6341e1cb5  jnz 0x000074B6341E1CE7
000074b6341e1cb7  cmp dword ptr [r15+0x318], 0x00
000074b6341e1cbf  jz 0x000074B6341E1FE0
000074b6341e1cc5  nop [rax+rax*1], ax
000074b6341e1cce  nop [rax+rax*1], eax
000074b6341e1cd6  mov eax, 0x410490
000074b6341e1cdb  mov [r15+0x100], rax
000074b6341e1ce2  jmp 0x000074B633FFE110
000074b6341e1ce7  cmp dword ptr [r15+0x318], 0x00
000074b6341e1cef  jz 0x000074B6341E1E20
000074b6341e1cf5  nop [rax+rax*1], ax
000074b6341e1cfe  nop [rax+rax*1], eax
000074b6341e1d06  mov eax, 0x410474
000074b6341e1d0b  mov [r15+0x100], rax
000074b6341e1d12  jmp 0x000074B633FFE110
000074b6341e1d17  int3
000074b6341e1d18  call 0x000074B6340E27E0
000074b6341e1d1d  jmp 0x000074B6341E1AC3
000074b6341e1d22  call 0x000074B6340E27E0
000074b6341e1d27  jmp 0x000074B6341E1AD6
000074b6341e1d2c  call 0x000074B6340E1570
000074b6341e1d31  jmp 0x000074B6341E1AE2
000074b6341e1d36  call 0x000074B6340E27E0
000074b6341e1d3b  jmp 0x000074B6341E1B1A
000074b6341e1d40  call 0x000074B6340E1570
000074b6341e1d45  jmp 0x000074B6341E1B26
000074b6341e1d4a  call 0x000074B6340E27E0
000074b6341e1d4f  jmp 0x000074B6341E1B5E
000074b6341e1d54  call 0x000074B6340E1570
000074b6341e1d59  jmp 0x000074B6341E1B6A
000074b6341e1d5e  call 0x000074B6340E27E0
000074b6341e1d63  jmp 0x000074B6341E1BA2
000074b6341e1d68  call 0x000074B6340E1570
000074b6341e1d6d  jmp 0x000074B6341E1BAE
000074b6341e1d72  call 0x000074B6340E27E0
000074b6341e1d77  jmp 0x000074B6341E1BED
000074b6341e1d7c  call 0x000074B63400E760
000074b6341e1d81  jmp 0x000074B6341E1C0A
000074b6341e1d86  ucomisd xmm1, xmm15
000074b6341e1d8b  jp 0x000074B6341E1D9A
000074b6341e1d8d  movaps xmm13, [0x000074B633DFE060]
000074b6341e1d95  jmp 0x000074B6341E1C73
000074b6341e1d9a  vxorps xmm0, xmm1, xmm15
000074b6341e1d9f  pextrw eax, xmm0, 0x03
000074b6341e1da4  and eax, 0x7FF8
000074b6341e1da9  cmp eax, 0x08
000074b6341e1dac  jnz 0x000074B6341E1C73
000074b6341e1db2  movq rax, xmm15
000074b6341e1db7  shl rax, 0x0D
000074b6341e1dbb  jbe 0x000074B6341E1C73
000074b6341e1dc1  vorps xmm13, xmm15, [0x000074B633DFE070]
000074b6341e1dc9  jmp 0x000074B6341E1C73
000074b6341e1dce  ucomisd xmm1, xmm15
000074b6341e1dd3  jp 0x000074B6341E1DE2
000074b6341e1dd5  movaps xmm14, [0x000074B633DFE060]
000074b6341e1ddd  jmp 0x000074B6341E1CA0
000074b6341e1de2  vxorps xmm0, xmm1, xmm15
000074b6341e1de7  pextrw eax, xmm0, 0x03
000074b6341e1dec  and eax, 0x7FF8
000074b6341e1df1  cmp eax, 0x08
000074b6341e1df4  jnz 0x000074B6341E1CA0
000074b6341e1dfa  movq rax, xmm15
000074b6341e1dff  shl rax, 0x0D
000074b6341e1e03  jbe 0x000074B6341E1CA0
000074b6341e1e09  vorps xmm14, xmm15, [0x000074B633DFE070]
000074b6341e1e11  jmp 0x000074B6341E1CA0
000074b6341e1e16  int3
000074b6341e1e17  nop [rax+rax*1], ax
000074b6341e1e20  mov rax, [r15+0x48]
000074b6341e1e24  mov r14, [r15+0x50]
000074b6341e1e28  lea r12, [r14+rax*1]
000074b6341e1e2c  movups xmm1, [r13+r12*1]
000074b6341e1e32  movaps [r15+0x120], xmm1
000074b6341e1e3a  lea r14, [rax+0x10]
000074b6341e1e3e  mov [r15+0x48], r14
000074b6341e1e42  xor eax, eax
000074b6341e1e44  mov r12d, 0x200
000074b6341e1e4a  cmp r14, r12
000074b6341e1e4d  cmc
000074b6341e1e4e  lahf
000074b6341e1e4f  seto al
000074b6341e1e52  mov [r15+0x108], eax
000074b6341e1e59  pextrq rax, xmm1, 0x01
000074b6341e1e60  movq xmm15, rax
000074b6341e1e65  movaps [r15+0x130], xmm15
000074b6341e1e6d  movaps xmm14, [r15+0x110]
000074b6341e1e75  movq rax, xmm14
000074b6341e1e7a  movq r14, xmm1
000074b6341e1e7f  vmovq xmm1, rax
000074b6341e1e84  vmovq xmm14, r14
000074b6341e1e89  movaps xmm13, xmm1
000074b6341e1e8d  addsd xmm13, xmm14
000074b6341e1e92  ucomisd xmm13, xmm13
000074b6341e1e97  jp 0x000074B6341E1F4C
000074b6341e1e9d  movq xmm13, xmm13
000074b6341e1ea2  movq rax, xmm13
000074b6341e1ea7  movq r14, xmm15
000074b6341e1eac  vmovq xmm1, rax
000074b6341e1eb1  vmovq xmm15, r14
000074b6341e1eb6  movaps xmm14, xmm1
000074b6341e1eba  addsd xmm14, xmm15
000074b6341e1ebf  ucomisd xmm14, xmm14
000074b6341e1ec4  jp 0x000074B6341E1F94
000074b6341e1eca  movq xmm14, xmm14
000074b6341e1ecf  movaps [r15+0x110], xmm14
000074b6341e1ed7  mov eax, [r15+0x108]
000074b6341e1ede  sahf
000074b6341e1edf  jnz 0x000074B6341E1F11
000074b6341e1ee1  cmp dword ptr [r15+0x318], 0x00
000074b6341e1ee9  jz 0x000074B6341E1FE0
000074b6341e1eef  nop [rax+rax*1], ax
000074b6341e1ef8  nop [rax+rax*1], eax
000074b6341e1f00  mov eax, 0x410490
000074b6341e1f05  mov [r15+0x100], rax
000074b6341e1f0c  jmp 0x000074B633FFE110
000074b6341e1f11  cmp dword ptr [r15+0x318], 0x00
000074b6341e1f19  jz 0x000074B6341E1E20
000074b6341e1f1f  nop [rax+rax*1], ax
000074b6341e1f28  nop [rax+rax*1], eax
000074b6341e1f30  mov eax, 0x410474
000074b6341e1f35  mov [r15+0x100], rax
000074b6341e1f3c  jmp 0x000074B633FFE110
000074b6341e1f41  int3
000074b6341e1f42  call 0x000074B6340B52F0
000074b6341e1f47  jmp 0x000074B6341E1E32
000074b6341e1f4c  ucomisd xmm1, xmm14
000074b6341e1f51  jp 0x000074B6341E1F60
000074b6341e1f53  movaps xmm13, [0x000074B633DFE060]
000074b6341e1f5b  jmp 0x000074B6341E1E9D
000074b6341e1f60  vxorps xmm0, xmm1, xmm14
000074b6341e1f65  pextrw eax, xmm0, 0x03
000074b6341e1f6a  and eax, 0x7FF8
000074b6341e1f6f  cmp eax, 0x08
000074b6341e1f72  jnz 0x000074B6341E1E9D
000074b6341e1f78  movq rax, xmm14
000074b6341e1f7d  shl rax, 0x0D
000074b6341e1f81  jbe 0x000074B6341E1E9D
000074b6341e1f87  vorps xmm13, xmm14, [0x000074B633DFE070]
000074b6341e1f8f  jmp 0x000074B6341E1E9D
000074b6341e1f94  ucomisd xmm1, xmm15
000074b6341e1f99  jp 0x000074B6341E1FA8
000074b6341e1f9b  movaps xmm14, [0x000074B633DFE060]
000074b6341e1fa3  jmp 0x000074B6341E1ECA
000074b6341e1fa8  vxorps xmm0, xmm1, xmm15
000074b6341e1fad  pextrw eax, xmm0, 0x03
000074b6341e1fb2  and eax, 0x7FF8
000074b6341e1fb7  cmp eax, 0x08
000074b6341e1fba  jnz 0x000074B6341E1ECA
000074b6341e1fc0  movq rax, xmm15
000074b6341e1fc5  shl rax, 0x0D
000074b6341e1fc9  jbe 0x000074B6341E1ECA
000074b6341e1fcf  vorps xmm14, xmm15, [0x000074B633DFE070]
000074b6341e1fd7  jmp 0x000074B6341E1ECA
000074b6341e1fdc  int3
000074b6341e1fdd  nop [rax], eax
000074b6341e1fe0  mov rax, [r15+0x40]
000074b6341e1fe4  lea r14, [rax+0x510]
000074b6341e1feb  movaps xmm1, [r15+0x110]
000074b6341e1ff3  movq rax, xmm1
000074b6341e1ff8  mov [r13+r14*1], rax
000074b6341e1ffd  mov rax, [r15+0xF0]
000074b6341e2004  mov [r15+0x100], rax
000074b6341e200b  jmp 0x000074B6341CE5C0
000074b6341e2010  int3
000074b6341e2011  call 0x000074B6340D5EB0
000074b6341e2016  jmp 0x000074B6341E1FFD
000074b6341e201b  int3
000074b6341e201c  nop [rax], eax
000074b6341e2020  mov qword ptr [r15+0x100], 0x04
000074b6341e202b  mov esi, 0x00
000074b6341e2030  mov edx, 0x09
000074b6341e2035  mov rdi, 0x7FFEAA86D0C0
000074b6341e203f  mov rax, 0x5E1AA08C2970
000074b6341e2049  call rax
000074b6341e204b  cmp dword ptr [r15+0x318], 0x00
000074b6341e2053  jnz 0x000074B633FFE110
000074b6341e2059  jmp 0x000074B633FFE0A0
000074b6341e205e  int3
000074b6341e205f  int3
