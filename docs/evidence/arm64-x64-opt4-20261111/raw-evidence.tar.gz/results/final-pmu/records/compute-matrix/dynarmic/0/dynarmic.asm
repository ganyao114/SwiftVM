00007b1fbf9ce69b  nop [rax+rax*1], eax
00007b1fbf9ce6a0  vmovaps xmm1, [0x00007B1FBF5FE010]
00007b1fbf9ce6a8  movq xmm1, xmm1
00007b1fbf9ce6ac  movaps [r15+0x110], xmm1
00007b1fbf9ce6b4  vmovaps xmm1, [0x00007B1FBF5FE020]
00007b1fbf9ce6bc  movq xmm1, xmm1
00007b1fbf9ce6c0  movaps [r15+0x120], xmm1
00007b1fbf9ce6c8  mov eax, 0x4204C0
00007b1fbf9ce6cd  mov r14, [r13+rax*1]
00007b1fbf9ce6d2  movq xmm1, r14
00007b1fbf9ce6d7  movaps [r15+0x130], xmm1
00007b1fbf9ce6df  vmovaps xmm1, [0x00007B1FBF5FE030]
00007b1fbf9ce6e7  vpbroadcastq xmm1, xmm1
00007b1fbf9ce6ec  movaps [r15+0x140], xmm1
00007b1fbf9ce6f4  mov qword ptr [r15+0x40], 0x02
00007b1fbf9ce6fc  vmovaps xmm15, [0x00007B1FBF5FE040]
00007b1fbf9ce704  movq xmm15, xmm15
00007b1fbf9ce709  movaps [r15+0x150], xmm15
00007b1fbf9ce711  mov qword ptr [r15+0x58], 0x420000
00007b1fbf9ce719  vmovaps xmm15, [0x00007B1FBF5FE050]
00007b1fbf9ce721  vpbroadcastq xmm15, xmm15
00007b1fbf9ce726  movaps [r15+0x160], xmm15
00007b1fbf9ce72e  mov rax, [r15+0x40]
00007b1fbf9ce732  vmovq xmm14, rax
00007b1fbf9ce737  vpbroadcastq xmm14, xmm14
00007b1fbf9ce73c  movaps [r15+0x170], xmm14
00007b1fbf9ce744  mov eax, 0x4204D0
00007b1fbf9ce749  movups xmm13, [r13+rax*1]
00007b1fbf9ce74f  mov qword ptr [r15+0x40], 0x430518
00007b1fbf9ce757  mov qword ptr [r15+0x50], 0x430720
00007b1fbf9ce75f  vpmovqd xmm12, xmm13
00007b1fbf9ce765  pxor xmm11, xmm11
00007b1fbf9ce76a  punpcklqdq xmm12, xmm11
00007b1fbf9ce76f  movaps [r15+0x210], xmm12
00007b1fbf9ce777  movq xmm12, qword ptr [r15+0x120]
00007b1fbf9ce780  movq xmm11, qword ptr [r15+0x130]
00007b1fbf9ce789  psubd xmm12, xmm11
00007b1fbf9ce78e  movq xmm12, xmm12
00007b1fbf9ce793  paddq xmm13, xmm14
00007b1fbf9ce798  movaps [r15+0x180], xmm13
00007b1fbf9ce7a0  movq xmm14, qword ptr [r15+0x150]
00007b1fbf9ce7a9  paddd xmm11, xmm14
00007b1fbf9ce7ae  movq xmm11, xmm11
00007b1fbf9ce7b3  movq xmm11, xmm11
00007b1fbf9ce7b8  movaps [r15+0x130], xmm11
00007b1fbf9ce7c0  pmovzxdq xmm12, xmm12
00007b1fbf9ce7c6  psllq xmm12, 0x00
00007b1fbf9ce7cc  movq xmm14, qword ptr [r15+0x210]
00007b1fbf9ce7d5  movq xmm13, qword ptr [r15+0x110]
00007b1fbf9ce7de  paddd xmm14, xmm13
00007b1fbf9ce7e3  movq xmm14, xmm14
00007b1fbf9ce7e8  vcvtuqq2pd xmm12, xmm12
00007b1fbf9ce7ee  pmovzxdq xmm14, xmm14
00007b1fbf9ce7f4  psllq xmm14, 0x00
00007b1fbf9ce7fa  vcvtuqq2pd xmm14, xmm14
00007b1fbf9ce800  movaps xmm13, xmm12
00007b1fbf9ce804  mulpd xmm13, xmm1
00007b1fbf9ce809  vcmppd xmm11, xmm13, xmm13, 0x03
00007b1fbf9ce80f  ptest xmm11, xmm11
00007b1fbf9ce815  jnz 0x00007B1FBF9CE8FF
00007b1fbf9ce81b  movaps [r15+0x220], xmm13
00007b1fbf9ce823  mov eax, 0x430720
00007b1fbf9ce828  movups [r13+rax*1], xmm13
00007b1fbf9ce82e  movaps xmm1, xmm14
00007b1fbf9ce832  mulpd xmm1, xmm15
00007b1fbf9ce837  vcmppd xmm13, xmm1, xmm1, 0x03
00007b1fbf9ce83c  ptest xmm13, xmm13
00007b1fbf9ce842  jnz 0x00007B1FBF9CEA4C
00007b1fbf9ce848  movaps [r15+0x210], xmm1
00007b1fbf9ce850  mov eax, 0x430518
00007b1fbf9ce855  movups [r13+rax*1], xmm1
00007b1fbf9ce85b  mov qword ptr [r15+0x48], 0x10
00007b1fbf9ce863  xor eax, eax
00007b1fbf9ce865  mov r14d, 0x10
00007b1fbf9ce86b  mov r12d, 0x200
00007b1fbf9ce871  cmp r14, r12
00007b1fbf9ce874  cmc
00007b1fbf9ce875  lahf
00007b1fbf9ce876  seto al
00007b1fbf9ce879  mov [r15+0x108], eax
00007b1fbf9ce880  mov eax, [r15+0x108]
00007b1fbf9ce887  sahf
00007b1fbf9ce888  jnz 0x00007B1FBF9CE8BA
00007b1fbf9ce88a  cmp dword ptr [r15+0x318], 0x00
00007b1fbf9ce892  jz 0x00007B1FBF9CEFF0
00007b1fbf9ce898  nop [rax+rax*1], ax
00007b1fbf9ce8a1  nop [rax+rax*1], eax
00007b1fbf9ce8a9  mov eax, 0x4101EC
00007b1fbf9ce8ae  mov [r15+0x100], rax
00007b1fbf9ce8b5  jmp 0x00007B1FBF7FE110
00007b1fbf9ce8ba  cmp dword ptr [r15+0x318], 0x00
00007b1fbf9ce8c2  jz 0x00007B1FBF9CEBA0
00007b1fbf9ce8c8  nop [rax+rax*1], ax
00007b1fbf9ce8d1  nop [rax+rax*1], eax
00007b1fbf9ce8d9  mov eax, 0x4101AC
00007b1fbf9ce8de  mov [r15+0x100], rax
00007b1fbf9ce8e5  jmp 0x00007B1FBF7FE110
00007b1fbf9ce8ea  int3
00007b1fbf9ce8eb  call 0x00007B1FBF80DC20
00007b1fbf9ce8f0  jmp 0x00007B1FBF9CE6D2
00007b1fbf9ce8f5  call 0x00007B1FBF80C260
00007b1fbf9ce8fa  jmp 0x00007B1FBF9CE74F
00007b1fbf9ce8ff  sub rsp, 0x08
00007b1fbf9ce903  push rax
00007b1fbf9ce904  push rcx
00007b1fbf9ce905  push rdx
00007b1fbf9ce906  push rdi
00007b1fbf9ce907  push rsi
00007b1fbf9ce908  push r8
00007b1fbf9ce90a  push r9
00007b1fbf9ce90c  push r10
00007b1fbf9ce90e  push r11
00007b1fbf9ce910  sub rsp, 0xF0
00007b1fbf9ce917  vmovaps [rsp], xmm0
00007b1fbf9ce91c  vmovaps [rsp+0x10], xmm1
00007b1fbf9ce922  vmovaps [rsp+0x20], xmm2
00007b1fbf9ce928  vmovaps [rsp+0x30], xmm3
00007b1fbf9ce92e  vmovaps [rsp+0x40], xmm4
00007b1fbf9ce934  vmovaps [rsp+0x50], xmm5
00007b1fbf9ce93a  vmovaps [rsp+0x60], xmm6
00007b1fbf9ce940  vmovaps [rsp+0x70], xmm7
00007b1fbf9ce946  vmovaps [rsp+0x80], xmm8
00007b1fbf9ce94f  vmovaps [rsp+0x90], xmm9
00007b1fbf9ce958  vmovaps [rsp+0xA0], xmm10
00007b1fbf9ce961  vmovaps [rsp+0xB0], xmm11
00007b1fbf9ce96a  vmovaps [rsp+0xC0], xmm12
00007b1fbf9ce973  vmovaps [rsp+0xD0], xmm14
00007b1fbf9ce97c  vmovaps [rsp+0xE0], xmm15
00007b1fbf9ce985  sub rsp, 0x30
00007b1fbf9ce989  movaps [rsp], xmm13
00007b1fbf9ce98e  movaps [rsp+0x10], xmm12
00007b1fbf9ce994  movaps [rsp+0x20], xmm1
00007b1fbf9ce999  lea rdi, [rsp]
00007b1fbf9ce99d  mov esi, 0x00
00007b1fbf9ce9a2  mov rax, 0x64AEE5F12530
00007b1fbf9ce9ac  call rax
00007b1fbf9ce9ae  movaps xmm13, [rsp]
00007b1fbf9ce9b3  add rsp, 0x30
00007b1fbf9ce9b7  vmovaps xmm0, [rsp]
00007b1fbf9ce9bc  vmovaps xmm1, [rsp+0x10]
00007b1fbf9ce9c2  vmovaps xmm2, [rsp+0x20]
00007b1fbf9ce9c8  vmovaps xmm3, [rsp+0x30]
00007b1fbf9ce9ce  vmovaps xmm4, [rsp+0x40]
00007b1fbf9ce9d4  vmovaps xmm5, [rsp+0x50]
00007b1fbf9ce9da  vmovaps xmm6, [rsp+0x60]
00007b1fbf9ce9e0  vmovaps xmm7, [rsp+0x70]
00007b1fbf9ce9e6  vmovaps xmm8, [rsp+0x80]
00007b1fbf9ce9ef  vmovaps xmm9, [rsp+0x90]
00007b1fbf9ce9f8  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9cea01  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9cea0a  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9cea13  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9cea1c  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9cea25  add rsp, 0xF0
00007b1fbf9cea2c  pop r11
00007b1fbf9cea2e  pop r10
00007b1fbf9cea30  pop r9
00007b1fbf9cea32  pop r8
00007b1fbf9cea34  pop rsi
00007b1fbf9cea35  pop rdi
00007b1fbf9cea36  pop rdx
00007b1fbf9cea37  pop rcx
00007b1fbf9cea38  pop rax
00007b1fbf9cea39  add rsp, 0x08
00007b1fbf9cea3d  jmp 0x00007B1FBF9CE81B
00007b1fbf9cea42  call 0x00007B1FBF80C380
00007b1fbf9cea47  jmp 0x00007B1FBF9CE82E
00007b1fbf9cea4c  sub rsp, 0x08
00007b1fbf9cea50  push rax
00007b1fbf9cea51  push rcx
00007b1fbf9cea52  push rdx
00007b1fbf9cea53  push rdi
00007b1fbf9cea54  push rsi
00007b1fbf9cea55  push r8
00007b1fbf9cea57  push r9
00007b1fbf9cea59  push r10
00007b1fbf9cea5b  push r11
00007b1fbf9cea5d  sub rsp, 0xF0
00007b1fbf9cea64  vmovaps [rsp], xmm0
00007b1fbf9cea69  vmovaps [rsp+0x10], xmm2
00007b1fbf9cea6f  vmovaps [rsp+0x20], xmm3
00007b1fbf9cea75  vmovaps [rsp+0x30], xmm4
00007b1fbf9cea7b  vmovaps [rsp+0x40], xmm5
00007b1fbf9cea81  vmovaps [rsp+0x50], xmm6
00007b1fbf9cea87  vmovaps [rsp+0x60], xmm7
00007b1fbf9cea8d  vmovaps [rsp+0x70], xmm8
00007b1fbf9cea93  vmovaps [rsp+0x80], xmm9
00007b1fbf9cea9c  vmovaps [rsp+0x90], xmm10
00007b1fbf9ceaa5  vmovaps [rsp+0xA0], xmm11
00007b1fbf9ceaae  vmovaps [rsp+0xB0], xmm12
00007b1fbf9ceab7  vmovaps [rsp+0xC0], xmm13
00007b1fbf9ceac0  vmovaps [rsp+0xD0], xmm14
00007b1fbf9ceac9  vmovaps [rsp+0xE0], xmm15
00007b1fbf9cead2  sub rsp, 0x30
00007b1fbf9cead6  movaps [rsp], xmm1
00007b1fbf9ceada  movaps [rsp+0x10], xmm14
00007b1fbf9ceae0  movaps [rsp+0x20], xmm15
00007b1fbf9ceae6  lea rdi, [rsp]
00007b1fbf9ceaea  mov esi, 0x00
00007b1fbf9ceaef  mov rax, 0x64AEE5F12530
00007b1fbf9ceaf9  call rax
00007b1fbf9ceafb  movaps xmm1, [rsp]
00007b1fbf9ceaff  add rsp, 0x30
00007b1fbf9ceb03  vmovaps xmm0, [rsp]
00007b1fbf9ceb08  vmovaps xmm2, [rsp+0x10]
00007b1fbf9ceb0e  vmovaps xmm3, [rsp+0x20]
00007b1fbf9ceb14  vmovaps xmm4, [rsp+0x30]
00007b1fbf9ceb1a  vmovaps xmm5, [rsp+0x40]
00007b1fbf9ceb20  vmovaps xmm6, [rsp+0x50]
00007b1fbf9ceb26  vmovaps xmm7, [rsp+0x60]
00007b1fbf9ceb2c  vmovaps xmm8, [rsp+0x70]
00007b1fbf9ceb32  vmovaps xmm9, [rsp+0x80]
00007b1fbf9ceb3b  vmovaps xmm10, [rsp+0x90]
00007b1fbf9ceb44  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9ceb4d  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9ceb56  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9ceb5f  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9ceb68  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9ceb71  add rsp, 0xF0
00007b1fbf9ceb78  pop r11
00007b1fbf9ceb7a  pop r10
00007b1fbf9ceb7c  pop r9
00007b1fbf9ceb7e  pop r8
00007b1fbf9ceb80  pop rsi
00007b1fbf9ceb81  pop rdi
00007b1fbf9ceb82  pop rdx
00007b1fbf9ceb83  pop rcx
00007b1fbf9ceb84  pop rax
00007b1fbf9ceb85  add rsp, 0x08
00007b1fbf9ceb89  jmp 0x00007B1FBF9CE848
00007b1fbf9ceb8e  call 0x00007B1FBF7FF540
00007b1fbf9ceb93  jmp 0x00007B1FBF9CE85B
00007b1fbf9ceb98  int3
00007b1fbf9ceb99  nop [rax], eax
00007b1fbf9ceba0  movaps xmm1, [r15+0x180]
00007b1fbf9ceba8  vpmovqd xmm15, xmm1
00007b1fbf9cebae  pxor xmm14, xmm14
00007b1fbf9cebb3  punpcklqdq xmm15, xmm14
00007b1fbf9cebb8  movaps [r15+0x210], xmm15
00007b1fbf9cebc0  movq xmm15, qword ptr [r15+0x120]
00007b1fbf9cebc9  movq xmm14, qword ptr [r15+0x130]
00007b1fbf9cebd2  psubd xmm15, xmm14
00007b1fbf9cebd7  movq xmm15, xmm15
00007b1fbf9cebdc  movaps xmm13, [r15+0x170]
00007b1fbf9cebe4  paddq xmm1, xmm13
00007b1fbf9cebe9  movaps [r15+0x180], xmm1
00007b1fbf9cebf1  movq xmm1, qword ptr [r15+0x150]
00007b1fbf9cebfa  paddd xmm14, xmm1
00007b1fbf9cebff  movq xmm14, xmm14
00007b1fbf9cec04  movq xmm14, xmm14
00007b1fbf9cec09  movaps [r15+0x130], xmm14
00007b1fbf9cec11  pmovzxdq xmm15, xmm15
00007b1fbf9cec17  psllq xmm15, 0x00
00007b1fbf9cec1d  movq xmm1, qword ptr [r15+0x210]
00007b1fbf9cec26  movq xmm14, qword ptr [r15+0x110]
00007b1fbf9cec2f  paddd xmm1, xmm14
00007b1fbf9cec34  movq xmm1, xmm1
00007b1fbf9cec38  vcvtuqq2pd xmm15, xmm15
00007b1fbf9cec3e  pmovzxdq xmm1, xmm1
00007b1fbf9cec43  psllq xmm1, 0x00
00007b1fbf9cec48  vcvtuqq2pd xmm1, xmm1
00007b1fbf9cec4e  movaps xmm14, [r15+0x140]
00007b1fbf9cec56  movaps xmm13, xmm15
00007b1fbf9cec5a  mulpd xmm13, xmm14
00007b1fbf9cec5f  vcmppd xmm12, xmm13, xmm13, 0x03
00007b1fbf9cec65  ptest xmm12, xmm12
00007b1fbf9cec6b  jnz 0x00007B1FBF9CED4E
00007b1fbf9cec71  movaps [r15+0x220], xmm13
00007b1fbf9cec79  mov rax, [r15+0x48]
00007b1fbf9cec7d  mov r14, [r15+0x50]
00007b1fbf9cec81  lea r12, [r14+rax*1]
00007b1fbf9cec85  movups [r13+r12*1], xmm13
00007b1fbf9cec8b  movaps xmm15, [r15+0x160]
00007b1fbf9cec93  movaps xmm14, xmm1
00007b1fbf9cec97  mulpd xmm14, xmm15
00007b1fbf9cec9c  vcmppd xmm13, xmm14, xmm14, 0x03
00007b1fbf9ceca2  ptest xmm13, xmm13
00007b1fbf9ceca8  jnz 0x00007B1FBF9CEE9C
00007b1fbf9cecae  movaps [r15+0x210], xmm14
00007b1fbf9cecb6  mov r14, [r15+0x40]
00007b1fbf9cecba  lea r12, [r14+rax*1]
00007b1fbf9cecbe  movups [r13+r12*1], xmm14
00007b1fbf9cecc4  lea r14, [rax+0x10]
00007b1fbf9cecc8  mov [r15+0x48], r14
00007b1fbf9ceccc  xor eax, eax
00007b1fbf9cecce  mov r12d, 0x200
00007b1fbf9cecd4  cmp r14, r12
00007b1fbf9cecd7  cmc
00007b1fbf9cecd8  lahf
00007b1fbf9cecd9  seto al
00007b1fbf9cecdc  mov [r15+0x108], eax
00007b1fbf9cece3  mov eax, [r15+0x108]
00007b1fbf9cecea  sahf
00007b1fbf9ceceb  jnz 0x00007B1FBF9CED1D
00007b1fbf9ceced  cmp dword ptr [r15+0x318], 0x00
00007b1fbf9cecf5  jz 0x00007B1FBF9CEFF0
00007b1fbf9cecfb  nop [rax+rax*1], ax
00007b1fbf9ced04  nop [rax+rax*1], eax
00007b1fbf9ced0c  mov eax, 0x4101EC
00007b1fbf9ced11  mov [r15+0x100], rax
00007b1fbf9ced18  jmp 0x00007B1FBF7FE110
00007b1fbf9ced1d  cmp dword ptr [r15+0x318], 0x00
00007b1fbf9ced25  jz 0x00007B1FBF9CEBA0
00007b1fbf9ced2b  nop [rax+rax*1], ax
00007b1fbf9ced34  nop [rax+rax*1], eax
00007b1fbf9ced3c  mov eax, 0x4101AC
00007b1fbf9ced41  mov [r15+0x100], rax
00007b1fbf9ced48  jmp 0x00007B1FBF7FE110
00007b1fbf9ced4d  int3
00007b1fbf9ced4e  sub rsp, 0x08
00007b1fbf9ced52  push rax
00007b1fbf9ced53  push rcx
00007b1fbf9ced54  push rdx
00007b1fbf9ced55  push rdi
00007b1fbf9ced56  push rsi
00007b1fbf9ced57  push r8
00007b1fbf9ced59  push r9
00007b1fbf9ced5b  push r10
00007b1fbf9ced5d  push r11
00007b1fbf9ced5f  sub rsp, 0xF0
00007b1fbf9ced66  vmovaps [rsp], xmm0
00007b1fbf9ced6b  vmovaps [rsp+0x10], xmm1
00007b1fbf9ced71  vmovaps [rsp+0x20], xmm2
00007b1fbf9ced77  vmovaps [rsp+0x30], xmm3
00007b1fbf9ced7d  vmovaps [rsp+0x40], xmm4
00007b1fbf9ced83  vmovaps [rsp+0x50], xmm5
00007b1fbf9ced89  vmovaps [rsp+0x60], xmm6
00007b1fbf9ced8f  vmovaps [rsp+0x70], xmm7
00007b1fbf9ced95  vmovaps [rsp+0x80], xmm8
00007b1fbf9ced9e  vmovaps [rsp+0x90], xmm9
00007b1fbf9ceda7  vmovaps [rsp+0xA0], xmm10
00007b1fbf9cedb0  vmovaps [rsp+0xB0], xmm11
00007b1fbf9cedb9  vmovaps [rsp+0xC0], xmm12
00007b1fbf9cedc2  vmovaps [rsp+0xD0], xmm14
00007b1fbf9cedcb  vmovaps [rsp+0xE0], xmm15
00007b1fbf9cedd4  sub rsp, 0x30
00007b1fbf9cedd8  movaps [rsp], xmm13
00007b1fbf9ceddd  movaps [rsp+0x10], xmm15
00007b1fbf9cede3  movaps [rsp+0x20], xmm14
00007b1fbf9cede9  lea rdi, [rsp]
00007b1fbf9ceded  mov esi, 0x00
00007b1fbf9cedf2  mov rax, 0x64AEE5F12530
00007b1fbf9cedfc  call rax
00007b1fbf9cedfe  movaps xmm13, [rsp]
00007b1fbf9cee03  add rsp, 0x30
00007b1fbf9cee07  vmovaps xmm0, [rsp]
00007b1fbf9cee0c  vmovaps xmm1, [rsp+0x10]
00007b1fbf9cee12  vmovaps xmm2, [rsp+0x20]
00007b1fbf9cee18  vmovaps xmm3, [rsp+0x30]
00007b1fbf9cee1e  vmovaps xmm4, [rsp+0x40]
00007b1fbf9cee24  vmovaps xmm5, [rsp+0x50]
00007b1fbf9cee2a  vmovaps xmm6, [rsp+0x60]
00007b1fbf9cee30  vmovaps xmm7, [rsp+0x70]
00007b1fbf9cee36  vmovaps xmm8, [rsp+0x80]
00007b1fbf9cee3f  vmovaps xmm9, [rsp+0x90]
00007b1fbf9cee48  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9cee51  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9cee5a  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9cee63  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9cee6c  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9cee75  add rsp, 0xF0
00007b1fbf9cee7c  pop r11
00007b1fbf9cee7e  pop r10
00007b1fbf9cee80  pop r9
00007b1fbf9cee82  pop r8
00007b1fbf9cee84  pop rsi
00007b1fbf9cee85  pop rdi
00007b1fbf9cee86  pop rdx
00007b1fbf9cee87  pop rcx
00007b1fbf9cee88  pop rax
00007b1fbf9cee89  add rsp, 0x08
00007b1fbf9cee8d  jmp 0x00007B1FBF9CEC71
00007b1fbf9cee92  call 0x00007B1FBF8C2240
00007b1fbf9cee97  jmp 0x00007B1FBF9CEC8B
00007b1fbf9cee9c  sub rsp, 0x08
00007b1fbf9ceea0  push rax
00007b1fbf9ceea1  push rcx
00007b1fbf9ceea2  push rdx
00007b1fbf9ceea3  push rdi
00007b1fbf9ceea4  push rsi
00007b1fbf9ceea5  push r8
00007b1fbf9ceea7  push r9
00007b1fbf9ceea9  push r10
00007b1fbf9ceeab  push r11
00007b1fbf9ceead  sub rsp, 0xF0
00007b1fbf9ceeb4  vmovaps [rsp], xmm0
00007b1fbf9ceeb9  vmovaps [rsp+0x10], xmm1
00007b1fbf9ceebf  vmovaps [rsp+0x20], xmm2
00007b1fbf9ceec5  vmovaps [rsp+0x30], xmm3
00007b1fbf9ceecb  vmovaps [rsp+0x40], xmm4
00007b1fbf9ceed1  vmovaps [rsp+0x50], xmm5
00007b1fbf9ceed7  vmovaps [rsp+0x60], xmm6
00007b1fbf9ceedd  vmovaps [rsp+0x70], xmm7
00007b1fbf9ceee3  vmovaps [rsp+0x80], xmm8
00007b1fbf9ceeec  vmovaps [rsp+0x90], xmm9
00007b1fbf9ceef5  vmovaps [rsp+0xA0], xmm10
00007b1fbf9ceefe  vmovaps [rsp+0xB0], xmm11
00007b1fbf9cef07  vmovaps [rsp+0xC0], xmm12
00007b1fbf9cef10  vmovaps [rsp+0xD0], xmm13
00007b1fbf9cef19  vmovaps [rsp+0xE0], xmm15
00007b1fbf9cef22  sub rsp, 0x30
00007b1fbf9cef26  movaps [rsp], xmm14
00007b1fbf9cef2b  movaps [rsp+0x10], xmm1
00007b1fbf9cef30  movaps [rsp+0x20], xmm15
00007b1fbf9cef36  lea rdi, [rsp]
00007b1fbf9cef3a  mov esi, 0x00
00007b1fbf9cef3f  mov rax, 0x64AEE5F12530
00007b1fbf9cef49  call rax
00007b1fbf9cef4b  movaps xmm14, [rsp]
00007b1fbf9cef50  add rsp, 0x30
00007b1fbf9cef54  vmovaps xmm0, [rsp]
00007b1fbf9cef59  vmovaps xmm1, [rsp+0x10]
00007b1fbf9cef5f  vmovaps xmm2, [rsp+0x20]
00007b1fbf9cef65  vmovaps xmm3, [rsp+0x30]
00007b1fbf9cef6b  vmovaps xmm4, [rsp+0x40]
00007b1fbf9cef71  vmovaps xmm5, [rsp+0x50]
00007b1fbf9cef77  vmovaps xmm6, [rsp+0x60]
00007b1fbf9cef7d  vmovaps xmm7, [rsp+0x70]
00007b1fbf9cef83  vmovaps xmm8, [rsp+0x80]
00007b1fbf9cef8c  vmovaps xmm9, [rsp+0x90]
00007b1fbf9cef95  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9cef9e  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9cefa7  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9cefb0  vmovaps xmm13, [rsp+0xD0]
00007b1fbf9cefb9  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9cefc2  add rsp, 0xF0
00007b1fbf9cefc9  pop r11
00007b1fbf9cefcb  pop r10
00007b1fbf9cefcd  pop r9
00007b1fbf9cefcf  pop r8
00007b1fbf9cefd1  pop rsi
00007b1fbf9cefd2  pop rdi
00007b1fbf9cefd3  pop rdx
00007b1fbf9cefd4  pop rcx
00007b1fbf9cefd5  pop rax
00007b1fbf9cefd6  add rsp, 0x08
00007b1fbf9cefda  jmp 0x00007B1FBF9CECAE
00007b1fbf9cefdf  call 0x00007B1FBF8C34C0
00007b1fbf9cefe4  jmp 0x00007B1FBF9CECC4
00007b1fbf9cefe9  int3
00007b1fbf9cefea  nop [rax+rax*1], ax
00007b1fbf9ceff0  mov rax, [r15+0xF8]
00007b1fbf9ceff7  lea r14, [rax-0x150]
00007b1fbf9ceffe  mov [r15+0xF8], r14
00007b1fbf9cf005  mov rax, [r15+0x50]
00007b1fbf9cf009  lea r12, [rax+0x80]
00007b1fbf9cf010  movups xmm1, [r13+r12*1]
00007b1fbf9cf016  lea r12, [rax+0x90]
00007b1fbf9cf01d  movups xmm15, [r13+r12*1]
00007b1fbf9cf023  mov qword ptr [r15+0x48], 0x00
00007b1fbf9cf02b  lea r12, [rax+0x40]
00007b1fbf9cf02f  movups xmm14, [r13+r12*1]
00007b1fbf9cf035  lea r12, [rax+0x50]
00007b1fbf9cf039  movups xmm13, [r13+r12*1]
00007b1fbf9cf03f  lea r12, [r14+0x120]
00007b1fbf9cf046  movq xmm12, qword ptr [r15+0x1C0]
00007b1fbf9cf04f  movq xmm11, qword ptr [r15+0x1B0]
00007b1fbf9cf058  movq r11, xmm12
00007b1fbf9cf05d  movq r10, xmm11
00007b1fbf9cf062  mov [r13+r12*1], r11
00007b1fbf9cf067  lea r12, [r14+0x128]
00007b1fbf9cf06e  mov [r13+r12*1], r10
00007b1fbf9cf073  vxorps xmm12, xmm12, xmm12
00007b1fbf9cf078  vpbroadcastq xmm12, xmm12
00007b1fbf9cf07d  lea r12, [r14+0x100]
00007b1fbf9cf084  movq xmm11, qword ptr [r15+0x200]
00007b1fbf9cf08d  movq xmm10, qword ptr [r15+0x1F0]
00007b1fbf9cf096  movq r11, xmm11
00007b1fbf9cf09b  movq r10, xmm10
00007b1fbf9cf0a0  mov [r13+r12*1], r11
00007b1fbf9cf0a5  lea r12, [r14+0x108]
00007b1fbf9cf0ac  mov [r13+r12*1], r10
00007b1fbf9cf0b1  lea r12, [r14+0xE0]
00007b1fbf9cf0b8  movups [r13+r12*1], xmm15
00007b1fbf9cf0be  lea r12, [r14+0xF0]
00007b1fbf9cf0c5  movups [r13+r12*1], xmm1
00007b1fbf9cf0cb  lea r12, [rax+0xC0]
00007b1fbf9cf0d2  movups xmm1, [r13+r12*1]
00007b1fbf9cf0d8  lea r12, [rax+0xD0]
00007b1fbf9cf0df  movups xmm15, [r13+r12*1]
00007b1fbf9cf0e5  lea r12, [r14+0x110]
00007b1fbf9cf0ec  movq xmm11, qword ptr [r15+0x1E0]
00007b1fbf9cf0f5  movq xmm10, qword ptr [r15+0x1D0]
00007b1fbf9cf0fe  movq r11, xmm11
00007b1fbf9cf103  movq r10, xmm10
00007b1fbf9cf108  mov [r13+r12*1], r11
00007b1fbf9cf10d  lea r12, [r14+0x118]
00007b1fbf9cf114  mov [r13+r12*1], r10
00007b1fbf9cf119  movups xmm11, [r13+rax*1]
00007b1fbf9cf11f  lea r12, [rax+0x10]
00007b1fbf9cf123  movups xmm10, [r13+r12*1]
00007b1fbf9cf129  lea r12, [r14+0x130]
00007b1fbf9cf130  movq xmm9, qword ptr [r15+0x1A0]
00007b1fbf9cf139  movq xmm8, qword ptr [r15+0x190]
00007b1fbf9cf142  movq r11, xmm9
00007b1fbf9cf147  movq r10, xmm8
00007b1fbf9cf14c  mov [r13+r12*1], r11
00007b1fbf9cf151  lea r12, [r14+0x138]
00007b1fbf9cf158  mov [r13+r12*1], r10
00007b1fbf9cf15d  lea r12, [rax+0x140]
00007b1fbf9cf164  movups xmm9, [r13+r12*1]
00007b1fbf9cf16a  lea r12, [rax+0x150]
00007b1fbf9cf171  movups xmm8, [r13+r12*1]
00007b1fbf9cf177  lea r12, [r14+0xC0]
00007b1fbf9cf17e  movups [r13+r12*1], xmm15
00007b1fbf9cf184  lea r12, [r14+0xD0]
00007b1fbf9cf18b  movups [r13+r12*1], xmm1
00007b1fbf9cf191  lea r12, [rax+0x100]
00007b1fbf9cf198  movups xmm1, [r13+r12*1]
00007b1fbf9cf19e  lea r12, [rax+0x110]
00007b1fbf9cf1a5  movups xmm15, [r13+r12*1]
00007b1fbf9cf1ab  lea r12, [r14+0x140]
00007b1fbf9cf1b2  mov r11, [r15+0xE8]
00007b1fbf9cf1b9  mov [r13+r12*1], r11
00007b1fbf9cf1be  lea r12, [rax+0x180]
00007b1fbf9cf1c5  movups xmm7, [r13+r12*1]
00007b1fbf9cf1cb  lea r12, [rax+0x190]
00007b1fbf9cf1d2  movups xmm6, [r13+r12*1]
00007b1fbf9cf1d8  lea r12, [rax+0x1C0]
00007b1fbf9cf1df  movups xmm5, [r13+r12*1]
00007b1fbf9cf1e5  lea r12, [rax+0x1D0]
00007b1fbf9cf1ec  movups xmm4, [r13+r12*1]
00007b1fbf9cf1f2  lea r12, [r14+0x20]
00007b1fbf9cf1f6  movups [r13+r12*1], xmm1
00007b1fbf9cf1fc  lea r12, [r14+0x30]
00007b1fbf9cf200  movups [r13+r12*1], xmm13
00007b1fbf9cf206  lea r12, [rax+0x60]
00007b1fbf9cf20a  movups xmm1, [r13+r12*1]
00007b1fbf9cf210  lea r12, [rax+0x70]
00007b1fbf9cf214  movups xmm13, [r13+r12*1]
00007b1fbf9cf21a  lea r12, [rax+0x20]
00007b1fbf9cf21e  movups xmm3, [r13+r12*1]
00007b1fbf9cf224  lea r12, [rax+0x30]
00007b1fbf9cf228  movups xmm2, [r13+r12*1]
00007b1fbf9cf22e  movaps [r15+0x1F0], xmm2
00007b1fbf9cf236  lea r12, [r14+0x60]
00007b1fbf9cf23a  movups [r13+r12*1], xmm11
00007b1fbf9cf240  lea r12, [r14+0x70]
00007b1fbf9cf244  movups [r13+r12*1], xmm5
00007b1fbf9cf24a  lea r12, [rax+0xE0]
00007b1fbf9cf251  movups xmm11, [r13+r12*1]
00007b1fbf9cf257  lea r12, [rax+0xF0]
00007b1fbf9cf25e  movups xmm5, [r13+r12*1]
00007b1fbf9cf264  lea r12, [r14+0xA0]
00007b1fbf9cf26b  movups [r13+r12*1], xmm13
00007b1fbf9cf271  lea r12, [r14+0xB0]
00007b1fbf9cf278  movups [r13+r12*1], xmm1
00007b1fbf9cf27e  lea r12, [rax+0xA0]
00007b1fbf9cf285  movups xmm1, [r13+r12*1]
00007b1fbf9cf28b  lea r12, [rax+0xB0]
00007b1fbf9cf292  movups xmm13, [r13+r12*1]
00007b1fbf9cf298  lea r12, [rax+0x120]
00007b1fbf9cf29f  vmovaps [rsp+0x10], xmm1
00007b1fbf9cf2a5  movups xmm1, [r13+r12*1]
00007b1fbf9cf2ab  lea r12, [rax+0x130]
00007b1fbf9cf2b2  vmovaps [rsp+0x20], xmm1
00007b1fbf9cf2b8  movups xmm1, [r13+r12*1]
00007b1fbf9cf2be  lea r12, [rax+0x160]
00007b1fbf9cf2c5  vmovaps [rsp+0x30], xmm1
00007b1fbf9cf2cb  movups xmm1, [r13+r12*1]
00007b1fbf9cf2d1  lea r12, [rax+0x170]
00007b1fbf9cf2d8  vmovaps [rsp+0x40], xmm1
00007b1fbf9cf2de  movups xmm1, [r13+r12*1]
00007b1fbf9cf2e4  movaps [r15+0x2B0], xmm1
00007b1fbf9cf2ec  lea r12, [r14+0x80]
00007b1fbf9cf2f3  movups [r13+r12*1], xmm13
00007b1fbf9cf2f9  lea r12, [r14+0x90]
00007b1fbf9cf300  vmovaps xmm13, [rsp+0x10]
00007b1fbf9cf306  movups [r13+r12*1], xmm13
00007b1fbf9cf30c  lea r12, [rax+0x1A0]
00007b1fbf9cf313  movups xmm13, [r13+r12*1]
00007b1fbf9cf319  lea r12, [rax+0x1B0]
00007b1fbf9cf320  vmovaps [rsp+0x10], xmm1
00007b1fbf9cf326  movups xmm1, [r13+r12*1]
00007b1fbf9cf32c  movaps [r15+0x290], xmm13
00007b1fbf9cf334  movaps [r15+0x1E0], xmm1
00007b1fbf9cf33c  lea r12, [rax+0x1E0]
00007b1fbf9cf343  vmovaps [rsp+0x50], xmm1
00007b1fbf9cf349  movups xmm1, [r13+r12*1]
00007b1fbf9cf34f  lea r12, [rax+0x1F0]
00007b1fbf9cf356  vmovaps [rsp+0x60], xmm1
00007b1fbf9cf35c  movups xmm1, [r13+r12*1]
00007b1fbf9cf362  mov qword ptr [r15+0x50], 0x430920
00007b1fbf9cf36a  lea rax, [r14+0x40]
00007b1fbf9cf36e  vmovaps [rsp+0x70], xmm1
00007b1fbf9cf374  vmovaps xmm1, [rsp+0x40]
00007b1fbf9cf37a  movups [r13+rax*1], xmm1
00007b1fbf9cf380  lea rax, [r14+0x50]
00007b1fbf9cf384  movups [r13+rax*1], xmm10
00007b1fbf9cf38a  vmovaps xmm1, [rsp+0x70]
00007b1fbf9cf390  movups [r13+r14*1], xmm1
00007b1fbf9cf396  lea rax, [r14+0x10]
00007b1fbf9cf39a  vmovaps xmm1, [rsp+0x60]
00007b1fbf9cf3a0  movups [r13+rax*1], xmm1
00007b1fbf9cf3a6  mov rax, [r15+0x40]
00007b1fbf9cf3aa  vmovaps [rsp+0x40], xmm3
00007b1fbf9cf3b0  vmovaps xmm1, [rsp+0x40]
00007b1fbf9cf3b6  por xmm3, xmm1
00007b1fbf9cf3ba  vmovaps [rsp+0x40], xmm6
00007b1fbf9cf3c0  vmovaps xmm10, [rsp+0x40]
00007b1fbf9cf3c6  por xmm6, xmm10
00007b1fbf9cf3cb  lea r12, [rax+0x30]
00007b1fbf9cf3cf  mov r11, [r13+r12*1]
00007b1fbf9cf3d4  lea r12, [rax+0x38]
00007b1fbf9cf3d8  mov r10, [r13+r12*1]
00007b1fbf9cf3dd  movq xmm10, r11
00007b1fbf9cf3e2  vmovaps [rsp+0x40], xmm1
00007b1fbf9cf3e8  movq xmm1, r10
00007b1fbf9cf3ed  movq xmm10, xmm10
00007b1fbf9cf3f2  vmovaps [rsp+0x60], xmm10
00007b1fbf9cf3f8  movq xmm10, xmm10
00007b1fbf9cf3fd  movaps [r15+0x130], xmm10
00007b1fbf9cf405  movq xmm1, xmm1
00007b1fbf9cf409  vmovaps [rsp+0x70], xmm1
00007b1fbf9cf40f  movq xmm1, xmm1
00007b1fbf9cf413  movaps [r15+0x280], xmm1
00007b1fbf9cf41b  vmovaps [rsp+0x80], xmm9
00007b1fbf9cf424  vmovaps xmm1, [rsp+0x80]
00007b1fbf9cf42d  por xmm9, xmm1
00007b1fbf9cf432  lea r12, [rax+0x20]
00007b1fbf9cf436  mov r11, [r13+r12*1]
00007b1fbf9cf43b  lea r12, [rax+0x28]
00007b1fbf9cf43f  mov r10, [r13+r12*1]
00007b1fbf9cf444  movq xmm1, r11
00007b1fbf9cf449  movq xmm10, r10
00007b1fbf9cf44e  movq xmm1, xmm1
00007b1fbf9cf452  vmovaps [rsp+0x80], xmm1
00007b1fbf9cf45b  movq xmm1, xmm1
00007b1fbf9cf45f  movaps [r15+0x150], xmm1
00007b1fbf9cf467  movq xmm10, xmm10
00007b1fbf9cf46c  vmovaps [rsp+0x90], xmm10
00007b1fbf9cf475  movq xmm10, xmm10
00007b1fbf9cf47a  movaps [r15+0x140], xmm10
00007b1fbf9cf482  lea r12, [rax+0x10]
00007b1fbf9cf486  mov r11, [r13+r12*1]
00007b1fbf9cf48b  lea r12, [rax+0x18]
00007b1fbf9cf48f  mov r10, [r13+r12*1]
00007b1fbf9cf494  movq xmm1, r11
00007b1fbf9cf499  movq xmm10, r10
00007b1fbf9cf49e  movq xmm1, xmm1
00007b1fbf9cf4a2  vmovaps [rsp+0xA0], xmm1
00007b1fbf9cf4ab  movq xmm1, xmm1
00007b1fbf9cf4af  movaps [r15+0x170], xmm1
00007b1fbf9cf4b7  movq xmm10, xmm10
00007b1fbf9cf4bc  vmovaps [rsp+0xB0], xmm10
00007b1fbf9cf4c5  movq xmm10, xmm10
00007b1fbf9cf4ca  movaps [r15+0x160], xmm10
00007b1fbf9cf4d2  mov r12, [r13+rax*1]
00007b1fbf9cf4d7  vmovq xmm1, r12
00007b1fbf9cf4dc  vpbroadcastq xmm1, xmm1
00007b1fbf9cf4e1  lea r12, [rax+0x08]
00007b1fbf9cf4e5  mov rax, [r13+r12*1]
00007b1fbf9cf4ea  movq xmm10, rax
00007b1fbf9cf4ef  movaps [r15+0x230], xmm10
00007b1fbf9cf4f7  lea rax, [r14+0x50]
00007b1fbf9cf4fb  movups xmm10, [r13+rax*1]
00007b1fbf9cf501  lea rax, [r14+0x60]
00007b1fbf9cf505  vmovaps [rsp+0xC0], xmm1
00007b1fbf9cf50e  movups xmm1, [r13+rax*1]
00007b1fbf9cf514  lea rax, [r14+0x30]
00007b1fbf9cf518  vmovaps [rsp+0xD0], xmm1
00007b1fbf9cf521  movups xmm1, [r13+rax*1]
00007b1fbf9cf527  mov qword ptr [r15+0x60], 0x430920
00007b1fbf9cf52f  mov qword ptr [r15+0x58], 0x40
00007b1fbf9cf537  vmovaps [rsp+0xE0], xmm1
00007b1fbf9cf540  vmovaps [rsp+0xF0], xmm15
00007b1fbf9cf549  vmovaps xmm15, [rsp+0xC0]
00007b1fbf9cf552  vmovaps [rsp+0xC0], xmm14
00007b1fbf9cf55b  vmovaps xmm14, [rsp+0x40]
00007b1fbf9cf561  vmovaps [rsp+0x40], xmm13
00007b1fbf9cf567  movaps xmm1, xmm15
00007b1fbf9cf56b  mulpd xmm1, xmm14
00007b1fbf9cf570  vcmppd xmm13, xmm1, xmm1, 0x03
00007b1fbf9cf575  ptest xmm13, xmm13
00007b1fbf9cf57b  jnz 0x00007B1FBF9D0682
00007b1fbf9cf581  movq xmm14, qword ptr [r15+0x230]
00007b1fbf9cf58a  vmovaps [rsp+0x100], xmm14
00007b1fbf9cf593  vpermilpd xmm14, xmm14, 0x00
00007b1fbf9cf599  vmovaps [rsp+0x110], xmm1
00007b1fbf9cf5a2  vmovaps xmm1, [rsp+0xE0]
00007b1fbf9cf5ab  vmovaps [rsp+0xE0], xmm15
00007b1fbf9cf5b4  movaps xmm13, xmm1
00007b1fbf9cf5b8  mulpd xmm13, xmm14
00007b1fbf9cf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
00007b1fbf9cf5c3  ptest xmm15, xmm15
00007b1fbf9cf5c9  jnz 0x00007B1FBF9D07C4
00007b1fbf9cf5cf  vxorps xmm1, xmm1, xmm1
00007b1fbf9cf5d3  vpbroadcastq xmm1, xmm1
00007b1fbf9cf5d8  vmovaps xmm14, [rsp+0xE0]
00007b1fbf9cf5e1  vmovaps [rsp+0xE0], xmm1
00007b1fbf9cf5ea  vmovaps xmm1, [rsp+0xD0]
00007b1fbf9cf5f3  vmovaps [rsp+0xD0], xmm13
00007b1fbf9cf5fc  movaps xmm15, xmm14
00007b1fbf9cf600  mulpd xmm15, xmm1
00007b1fbf9cf605  vcmppd xmm13, xmm15, xmm15, 0x03
00007b1fbf9cf60b  ptest xmm13, xmm13
00007b1fbf9cf611  jnz 0x00007B1FBF9D0907
00007b1fbf9cf617  movaps xmm1, xmm14
00007b1fbf9cf61b  mulpd xmm1, xmm10
00007b1fbf9cf620  vcmppd xmm13, xmm1, xmm1, 0x03
00007b1fbf9cf625  ptest xmm13, xmm13
00007b1fbf9cf62b  jnz 0x00007B1FBF9D0A4A
00007b1fbf9cf631  movaps xmm13, xmm14
00007b1fbf9cf635  mulpd xmm13, xmm2
00007b1fbf9cf63a  vcmppd xmm10, xmm13, xmm13, 0x03
00007b1fbf9cf640  ptest xmm10, xmm10
00007b1fbf9cf646  jnz 0x00007B1FBF9D0B8C
00007b1fbf9cf64c  vmovaps [rsp+0x120], xmm7
00007b1fbf9cf655  vmovaps xmm14, [rsp+0x120]
00007b1fbf9cf65e  por xmm7, xmm14
00007b1fbf9cf663  vmovaps xmm14, [rsp+0xC0]
00007b1fbf9cf66c  vmovaps xmm10, [rsp+0xC0]
00007b1fbf9cf675  por xmm14, xmm10
00007b1fbf9cf67a  vmovaps xmm2, [rsp+0x100]
00007b1fbf9cf683  vpermilpd xmm2, xmm2, 0x00
00007b1fbf9cf689  vmovaps [rsp+0xC0], xmm1
00007b1fbf9cf692  vmovaps [rsp+0x120], xmm15
00007b1fbf9cf69b  movaps xmm1, xmm10
00007b1fbf9cf69f  mulpd xmm1, xmm2
00007b1fbf9cf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
00007b1fbf9cf6a8  ptest xmm15, xmm15
00007b1fbf9cf6ae  jnz 0x00007B1FBF9D0CCF
00007b1fbf9cf6b4  xor eax, eax
00007b1fbf9cf6b6  mov r12d, 0x40
00007b1fbf9cf6bc  mov r11d, 0x200
00007b1fbf9cf6c2  cmp r12, r11
00007b1fbf9cf6c5  cmc
00007b1fbf9cf6c6  lahf
00007b1fbf9cf6c7  seto al
00007b1fbf9cf6ca  mov [r15+0x108], eax
00007b1fbf9cf6d1  vmovaps xmm10, [rsp+0x110]
00007b1fbf9cf6da  vmovaps xmm2, [rsp+0xE0]
00007b1fbf9cf6e3  vmovaps [rsp+0xE0], xmm1
00007b1fbf9cf6ec  movaps xmm15, xmm10
00007b1fbf9cf6f0  addpd xmm15, xmm2
00007b1fbf9cf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
00007b1fbf9cf6fb  ptest xmm1, xmm1
00007b1fbf9cf700  jnz 0x00007B1FBF9D0E10
00007b1fbf9cf706  vmovaps xmm10, [rsp+0x120]
00007b1fbf9cf70f  vmovaps [rsp+0x110], xmm15
00007b1fbf9cf718  movaps xmm1, xmm10
00007b1fbf9cf71c  addpd xmm1, xmm12
00007b1fbf9cf721  vcmppd xmm15, xmm1, xmm1, 0x03
00007b1fbf9cf726  ptest xmm15, xmm15
00007b1fbf9cf72c  jnz 0x00007B1FBF9D0F53
00007b1fbf9cf732  vmovaps xmm10, [rsp+0xC0]
00007b1fbf9cf73b  vmovaps [rsp+0xC0], xmm1
00007b1fbf9cf744  movaps xmm15, xmm10
00007b1fbf9cf748  addpd xmm15, xmm12
00007b1fbf9cf74d  vcmppd xmm1, xmm15, xmm15, 0x03
00007b1fbf9cf753  ptest xmm1, xmm1
00007b1fbf9cf758  jnz 0x00007B1FBF9D1095
00007b1fbf9cf75e  vmovaps xmm1, [rsp+0x30]
00007b1fbf9cf764  vmovaps xmm12, [rsp+0x30]
00007b1fbf9cf76a  por xmm1, xmm12
00007b1fbf9cf76f  vmovaps xmm12, [rsp+0x20]
00007b1fbf9cf775  vmovaps xmm10, [rsp+0x20]
00007b1fbf9cf77b  por xmm12, xmm10
00007b1fbf9cf780  vmovaps [rsp+0x20], xmm5
00007b1fbf9cf786  vmovaps xmm10, [rsp+0x20]
00007b1fbf9cf78c  por xmm5, xmm10
00007b1fbf9cf791  vmovaps [rsp+0x20], xmm11
00007b1fbf9cf797  vmovaps xmm10, [rsp+0x20]
00007b1fbf9cf79d  por xmm11, xmm10
00007b1fbf9cf7a2  vmovaps [rsp+0x20], xmm4
00007b1fbf9cf7a8  vmovaps xmm10, [rsp+0x20]
00007b1fbf9cf7ae  por xmm4, xmm10
00007b1fbf9cf7b3  vmovaps [rsp+0x20], xmm8
00007b1fbf9cf7b9  vmovaps xmm10, [rsp+0x20]
00007b1fbf9cf7bf  por xmm8, xmm10
00007b1fbf9cf7c4  vmovaps xmm10, [rsp+0xF0]
00007b1fbf9cf7cd  vmovaps [rsp+0x20], xmm1
00007b1fbf9cf7d3  vmovaps xmm1, [rsp+0xF0]
00007b1fbf9cf7dc  por xmm10, xmm1
00007b1fbf9cf7e1  lea rax, [r14+0xA0]
00007b1fbf9cf7e8  movups xmm1, [r13+rax*1]
00007b1fbf9cf7ee  lea rax, [r14+0xB0]
00007b1fbf9cf7f5  vmovaps [rsp+0x30], xmm1
00007b1fbf9cf7fb  movups xmm1, [r13+rax*1]
00007b1fbf9cf801  vmovaps [rsp+0xF0], xmm1
00007b1fbf9cf80a  vmovaps [rsp+0x120], xmm15
00007b1fbf9cf813  movaps xmm1, xmm13
00007b1fbf9cf817  addpd xmm1, xmm2
00007b1fbf9cf81b  vcmppd xmm15, xmm1, xmm1, 0x03
00007b1fbf9cf820  ptest xmm15, xmm15
00007b1fbf9cf826  jnz 0x00007B1FBF9D11ED
00007b1fbf9cf82c  lea rax, [r14+0xF0]
00007b1fbf9cf833  movups xmm15, [r13+rax*1]
00007b1fbf9cf839  vmovaps xmm2, [rsp+0xC0]
00007b1fbf9cf842  vmovaps [rsp+0xC0], xmm1
00007b1fbf9cf84b  vmovaps xmm1, [rsp+0xE0]
00007b1fbf9cf854  vmovaps [rsp+0xE0], xmm15
00007b1fbf9cf85d  movaps xmm13, xmm2
00007b1fbf9cf861  addpd xmm13, xmm1
00007b1fbf9cf866  vcmppd xmm15, xmm13, xmm13, 0x03
00007b1fbf9cf86c  ptest xmm15, xmm15
00007b1fbf9cf872  jnz 0x00007B1FBF9D1338
00007b1fbf9cf878  vmovaps xmm15, [rsp+0x120]
00007b1fbf9cf881  vmovaps xmm2, [rsp+0xD0]
00007b1fbf9cf88a  vmovaps [rsp+0xD0], xmm14
00007b1fbf9cf893  movaps xmm1, xmm15
00007b1fbf9cf897  addpd xmm1, xmm2
00007b1fbf9cf89b  vcmppd xmm14, xmm1, xmm1, 0x03
00007b1fbf9cf8a0  ptest xmm14, xmm14
00007b1fbf9cf8a6  jnz 0x00007B1FBF9D147A
00007b1fbf9cf8ac  vmovaps xmm15, [rsp+0x100]
00007b1fbf9cf8b5  vpermilpd xmm15, xmm15, 0x00
00007b1fbf9cf8bb  vmovaps xmm2, [rsp+0xF0]
00007b1fbf9cf8c4  vmovaps [rsp+0xF0], xmm1
00007b1fbf9cf8cd  movaps xmm14, xmm2
00007b1fbf9cf8d1  mulpd xmm14, xmm15
00007b1fbf9cf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
00007b1fbf9cf8dc  ptest xmm1, xmm1
00007b1fbf9cf8e1  jnz 0x00007B1FBF9D15BB
00007b1fbf9cf8e7  vmovaps xmm1, [rsp+0xA0]
00007b1fbf9cf8f0  vpermilpd xmm1, xmm1, 0x00
00007b1fbf9cf8f6  vmovaps xmm2, [rsp+0xE0]
00007b1fbf9cf8ff  vmovaps [rsp+0xE0], xmm14
00007b1fbf9cf908  movaps xmm15, xmm2
00007b1fbf9cf90c  mulpd xmm15, xmm1
00007b1fbf9cf911  vcmppd xmm14, xmm15, xmm15, 0x03
00007b1fbf9cf917  ptest xmm14, xmm14
00007b1fbf9cf91d  jnz 0x00007B1FBF9D16FE
00007b1fbf9cf923  lea rax, [r14+0xE0]
00007b1fbf9cf92a  movups xmm1, [r13+rax*1]
00007b1fbf9cf930  vmovaps xmm14, [rsp+0x100]
00007b1fbf9cf939  vpermilpd xmm14, xmm14, 0x00
00007b1fbf9cf93f  vmovaps [rsp+0x100], xmm1
00007b1fbf9cf948  vmovaps xmm1, [rsp+0x30]
00007b1fbf9cf94e  vmovaps [rsp+0x30], xmm15
00007b1fbf9cf954  movaps xmm2, xmm1
00007b1fbf9cf957  mulpd xmm2, xmm14
00007b1fbf9cf95c  vcmppd xmm15, xmm2, xmm2, 0x03
00007b1fbf9cf961  ptest xmm15, xmm15
00007b1fbf9cf967  jnz 0x00007B1FBF9D184A
00007b1fbf9cf96d  vmovaps [rsp+0x120], xmm10
00007b1fbf9cf976  vmovaps xmm1, [rsp+0x120]
00007b1fbf9cf97f  por xmm10, xmm1
00007b1fbf9cf984  movaps [r15+0x300], xmm10
00007b1fbf9cf98c  vmovaps [rsp+0x120], xmm8
00007b1fbf9cf995  vmovaps xmm1, [rsp+0x120]
00007b1fbf9cf99e  por xmm8, xmm1
00007b1fbf9cf9a3  movaps [r15+0x190], xmm8
00007b1fbf9cf9ab  vmovaps xmm1, [rsp+0xA0]
00007b1fbf9cf9b4  vpermilpd xmm1, xmm1, 0x00
00007b1fbf9cf9ba  vmovaps xmm14, [rsp+0x100]
00007b1fbf9cf9c3  vmovaps [rsp+0x100], xmm13
00007b1fbf9cf9cc  movaps xmm15, xmm14
00007b1fbf9cf9d0  mulpd xmm15, xmm1
00007b1fbf9cf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
00007b1fbf9cf9db  ptest xmm13, xmm13
00007b1fbf9cf9e1  jnz 0x00007B1FBF9D198B
00007b1fbf9cf9e7  lea rax, [r14+0x90]
00007b1fbf9cf9ee  movups xmm1, [r13+rax*1]
00007b1fbf9cf9f4  vmovaps [rsp+0x120], xmm4
00007b1fbf9cf9fd  vmovaps xmm14, [rsp+0x120]
00007b1fbf9cfa06  por xmm4, xmm14
00007b1fbf9cfa0b  movaps [r15+0x1C0], xmm4
00007b1fbf9cfa13  vmovaps [rsp+0x120], xmm11
00007b1fbf9cfa1c  vmovaps xmm14, [rsp+0x120]
00007b1fbf9cfa25  por xmm11, xmm14
00007b1fbf9cfa2a  movaps [r15+0x200], xmm11
00007b1fbf9cfa32  vmovaps [rsp+0x120], xmm5
00007b1fbf9cfa3b  vmovaps xmm14, [rsp+0x120]
00007b1fbf9cfa44  por xmm5, xmm14
00007b1fbf9cfa49  movaps [r15+0x2D0], xmm5
00007b1fbf9cfa51  vmovaps [rsp+0x120], xmm12
00007b1fbf9cfa5a  vmovaps xmm14, [rsp+0x120]
00007b1fbf9cfa63  por xmm12, xmm14
00007b1fbf9cfa68  movaps [r15+0x2E0], xmm12
00007b1fbf9cfa70  vmovaps xmm13, [rsp+0x110]
00007b1fbf9cfa79  vmovaps [rsp+0x110], xmm1
00007b1fbf9cfa82  vmovaps xmm1, [rsp+0xE0]
00007b1fbf9cfa8b  vmovaps [rsp+0xE0], xmm15
00007b1fbf9cfa94  movaps xmm14, xmm13
00007b1fbf9cfa98  addpd xmm14, xmm1
00007b1fbf9cfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
00007b1fbf9cfaa3  ptest xmm15, xmm15
00007b1fbf9cfaa9  jnz 0x00007B1FBF9D1AD8
00007b1fbf9cfaaf  vmovaps xmm1, [rsp+0xA0]
00007b1fbf9cfab8  vpermilpd xmm1, xmm1, 0x00
00007b1fbf9cfabe  vmovaps xmm13, [rsp+0x110]
00007b1fbf9cfac7  vmovaps [rsp+0x110], xmm14
00007b1fbf9cfad0  movaps xmm15, xmm13
00007b1fbf9cfad4  mulpd xmm15, xmm1
00007b1fbf9cfad9  vcmppd xmm14, xmm15, xmm15, 0x03
00007b1fbf9cfadf  ptest xmm14, xmm14
00007b1fbf9cfae5  jnz 0x00007B1FBF9D1C1B
00007b1fbf9cfaeb  lea rax, [r14+0x80]
00007b1fbf9cfaf2  movups xmm1, [r13+rax*1]
00007b1fbf9cfaf8  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9cfb01  vmovaps [rsp+0xC0], xmm1
00007b1fbf9cfb0a  movaps xmm14, xmm13
00007b1fbf9cfb0e  addpd xmm14, xmm2
00007b1fbf9cfb13  vcmppd xmm1, xmm14, xmm14, 0x03
00007b1fbf9cfb19  ptest xmm1, xmm1
00007b1fbf9cfb1e  jnz 0x00007B1FBF9D1D68
00007b1fbf9cfb24  vmovaps xmm13, [rsp+0x100]
00007b1fbf9cfb2d  vmovaps xmm2, [rsp+0x30]
00007b1fbf9cfb33  vmovaps [rsp+0x30], xmm15
00007b1fbf9cfb39  movaps xmm1, xmm13
00007b1fbf9cfb3d  addpd xmm1, xmm2
00007b1fbf9cfb41  vcmppd xmm15, xmm1, xmm1, 0x03
00007b1fbf9cfb46  ptest xmm15, xmm15
00007b1fbf9cfb4c  jnz 0x00007B1FBF9D1EAB
00007b1fbf9cfb52  vmovaps xmm15, [rsp+0x20]
00007b1fbf9cfb58  vmovaps xmm13, [rsp+0x20]
00007b1fbf9cfb5e  por xmm15, xmm13
00007b1fbf9cfb63  movaps [r15+0x2F0], xmm15
00007b1fbf9cfb6b  vmovaps xmm13, [rsp+0xA0]
00007b1fbf9cfb74  vpermilpd xmm13, xmm13, 0x00
00007b1fbf9cfb7a  vmovaps [rsp+0x20], xmm1
00007b1fbf9cfb80  vmovaps xmm1, [rsp+0xC0]
00007b1fbf9cfb89  vmovaps [rsp+0xA0], xmm15
00007b1fbf9cfb92  movaps xmm2, xmm1
00007b1fbf9cfb95  mulpd xmm2, xmm13
00007b1fbf9cfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
00007b1fbf9cfb9f  ptest xmm15, xmm15
00007b1fbf9cfba5  jnz 0x00007B1FBF9D1FEC
00007b1fbf9cfbab  lea rax, [r14+0xD0]
00007b1fbf9cfbb2  movups xmm1, [r13+rax*1]
00007b1fbf9cfbb8  vmovaps xmm13, [rsp+0xF0]
00007b1fbf9cfbc1  vmovaps [rsp+0xC0], xmm1
00007b1fbf9cfbca  vmovaps xmm1, [rsp+0xE0]
00007b1fbf9cfbd3  vmovaps [rsp+0xE0], xmm14
00007b1fbf9cfbdc  movaps xmm15, xmm13
00007b1fbf9cfbe0  addpd xmm15, xmm1
00007b1fbf9cfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
00007b1fbf9cfbeb  ptest xmm14, xmm14
00007b1fbf9cfbf1  jnz 0x00007B1FBF9D2137
00007b1fbf9cfbf7  vmovaps xmm1, [rsp+0xB0]
00007b1fbf9cfc00  vpermilpd xmm1, xmm1, 0x00
00007b1fbf9cfc06  movaps xmm14, xmm11
00007b1fbf9cfc0a  mulpd xmm14, xmm1
00007b1fbf9cfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
00007b1fbf9cfc15  ptest xmm13, xmm13
00007b1fbf9cfc1b  jnz 0x00007B1FBF9D227A
00007b1fbf9cfc21  movaps [r15+0x260], xmm14
00007b1fbf9cfc29  vxorps xmm1, xmm1, xmm1
00007b1fbf9cfc2d  vpbroadcastq xmm1, xmm1
00007b1fbf9cfc32  movaps [r15+0x1B0], xmm1
00007b1fbf9cfc3a  vmovaps xmm1, [rsp+0xB0]
00007b1fbf9cfc43  vpermilpd xmm1, xmm1, 0x00
00007b1fbf9cfc49  vmovaps xmm11, [rsp+0xC0]
00007b1fbf9cfc52  vmovaps [rsp+0xC0], xmm15
00007b1fbf9cfc5b  movaps xmm13, xmm11
00007b1fbf9cfc5f  mulpd xmm13, xmm1
00007b1fbf9cfc64  vcmppd xmm15, xmm13, xmm13, 0x03
00007b1fbf9cfc6a  ptest xmm15, xmm15
00007b1fbf9cfc70  jnz 0x00007B1FBF9D23BD
00007b1fbf9cfc76  lea rax, [r14+0xC0]
00007b1fbf9cfc7d  movups xmm1, [r13+rax*1]
00007b1fbf9cfc83  vmovaps xmm11, [rsp+0x110]
00007b1fbf9cfc8c  vmovaps [rsp+0xF0], xmm1
00007b1fbf9cfc95  vmovaps xmm1, [rsp+0x30]
00007b1fbf9cfc9b  vmovaps [rsp+0x30], xmm14
00007b1fbf9cfca1  movaps xmm15, xmm11
00007b1fbf9cfca5  addpd xmm15, xmm1
00007b1fbf9cfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
00007b1fbf9cfcb0  ptest xmm14, xmm14
00007b1fbf9cfcb6  jnz 0x00007B1FBF9D250A
00007b1fbf9cfcbc  vmovaps [rsp+0x100], xmm9
00007b1fbf9cfcc5  vmovaps xmm1, [rsp+0x100]
00007b1fbf9cfcce  por xmm9, xmm1
00007b1fbf9cfcd3  movaps [r15+0x270], xmm9
00007b1fbf9cfcdb  vmovaps [rsp+0x100], xmm6
00007b1fbf9cfce4  vmovaps xmm1, [rsp+0x100]
00007b1fbf9cfced  por xmm6, xmm1
00007b1fbf9cfcf1  movaps [r15+0x1A0], xmm6
00007b1fbf9cfcf9  vmovaps xmm14, [rsp+0xB0]
00007b1fbf9cfd02  vpermilpd xmm14, xmm14, 0x00
00007b1fbf9cfd08  vmovaps xmm6, [rsp+0xF0]
00007b1fbf9cfd11  vmovaps [rsp+0xF0], xmm1
00007b1fbf9cfd1a  movaps xmm11, xmm6
00007b1fbf9cfd1e  mulpd xmm11, xmm14
00007b1fbf9cfd23  vcmppd xmm1, xmm11, xmm11, 0x03
00007b1fbf9cfd29  ptest xmm1, xmm1
00007b1fbf9cfd2e  jnz 0x00007B1FBF9D264D
00007b1fbf9cfd34  lea rax, [r14+0x20]
00007b1fbf9cfd38  movups xmm1, [r13+rax*1]
00007b1fbf9cfd3e  movaps [r15+0x110], xmm1
00007b1fbf9cfd46  vmovaps xmm6, [rsp+0xE0]
00007b1fbf9cfd4f  vmovaps [rsp+0xE0], xmm1
00007b1fbf9cfd58  movaps xmm14, xmm6
00007b1fbf9cfd5c  addpd xmm14, xmm2
00007b1fbf9cfd61  vcmppd xmm1, xmm14, xmm14, 0x03
00007b1fbf9cfd67  ptest xmm1, xmm1
00007b1fbf9cfd6c  jnz 0x00007B1FBF9D279A
00007b1fbf9cfd72  vmovaps xmm1, [rsp+0xB0]
00007b1fbf9cfd7b  vpermilpd xmm1, xmm1, 0x00
00007b1fbf9cfd81  movaps xmm6, xmm5
00007b1fbf9cfd84  mulpd xmm6, xmm1
00007b1fbf9cfd88  vcmppd xmm2, xmm6, xmm6, 0x03
00007b1fbf9cfd8d  ptest xmm2, xmm2
00007b1fbf9cfd92  jnz 0x00007B1FBF9D28DC
00007b1fbf9cfd98  vmovaps xmm5, [rsp+0x20]
00007b1fbf9cfd9e  movaps xmm1, xmm5
00007b1fbf9cfda1  addpd xmm1, xmm13
00007b1fbf9cfda6  vcmppd xmm2, xmm1, xmm1, 0x03
00007b1fbf9cfdab  ptest xmm2, xmm2
00007b1fbf9cfdb0  jnz 0x00007B1FBF9D2A1C
00007b1fbf9cfdb6  vmovaps xmm13, [rsp+0x80]
00007b1fbf9cfdbf  vpermilpd xmm13, xmm13, 0x00
00007b1fbf9cfdc5  vmovaps xmm2, [rsp+0xE0]
00007b1fbf9cfdce  vmovaps [rsp+0x20], xmm1
00007b1fbf9cfdd4  movaps xmm5, xmm2
00007b1fbf9cfdd7  mulpd xmm5, xmm13
00007b1fbf9cfddc  vcmppd xmm1, xmm5, xmm5, 0x03
00007b1fbf9cfde1  ptest xmm1, xmm1
00007b1fbf9cfde6  jnz 0x00007B1FBF9D2B5D
00007b1fbf9cfdec  vmovaps xmm1, [rsp+0x80]
00007b1fbf9cfdf5  vpermilpd xmm1, xmm1, 0x00
00007b1fbf9cfdfb  movaps xmm13, xmm10
00007b1fbf9cfdff  mulpd xmm13, xmm1
00007b1fbf9cfe04  vcmppd xmm2, xmm13, xmm13, 0x03
00007b1fbf9cfe0a  ptest xmm2, xmm2
00007b1fbf9cfe0f  jnz 0x00007B1FBF9D2C9E
00007b1fbf9cfe15  vmovaps xmm10, [rsp+0x30]
00007b1fbf9cfe1b  movaps xmm1, xmm15
00007b1fbf9cfe1f  addpd xmm1, xmm10
00007b1fbf9cfe24  vcmppd xmm2, xmm1, xmm1, 0x03
00007b1fbf9cfe29  ptest xmm2, xmm2
00007b1fbf9cfe2e  jnz 0x00007B1FBF9D2DE1
00007b1fbf9cfe34  vmovaps xmm10, [rsp+0xC0]
00007b1fbf9cfe3d  movaps xmm15, xmm10
00007b1fbf9cfe41  addpd xmm15, xmm11
00007b1fbf9cfe46  vcmppd xmm2, xmm15, xmm15, 0x03
00007b1fbf9cfe4c  ptest xmm2, xmm2
00007b1fbf9cfe51  jnz 0x00007B1FBF9D2F23
00007b1fbf9cfe57  vmovaps xmm11, [rsp+0x80]
00007b1fbf9cfe60  vpermilpd xmm11, xmm11, 0x00
00007b1fbf9cfe66  movaps xmm10, xmm12
00007b1fbf9cfe6a  mulpd xmm10, xmm11
00007b1fbf9cfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
00007b1fbf9cfe75  ptest xmm2, xmm2
00007b1fbf9cfe7a  jnz 0x00007B1FBF9D3067
00007b1fbf9cfe80  vmovaps xmm12, [rsp+0x80]
00007b1fbf9cfe89  vpermilpd xmm12, xmm12, 0x00
00007b1fbf9cfe8f  vmovaps xmm2, [rsp+0xA0]
00007b1fbf9cfe98  vmovaps [rsp+0x30], xmm1
00007b1fbf9cfe9e  movaps xmm11, xmm2
00007b1fbf9cfea2  mulpd xmm11, xmm12
00007b1fbf9cfea7  vcmppd xmm1, xmm11, xmm11, 0x03
00007b1fbf9cfead  ptest xmm1, xmm1
00007b1fbf9cfeb2  jnz 0x00007B1FBF9D31AB
00007b1fbf9cfeb8  movaps xmm1, xmm14
00007b1fbf9cfebc  addpd xmm1, xmm6
00007b1fbf9cfec0  vcmppd xmm12, xmm1, xmm1, 0x03
00007b1fbf9cfec5  ptest xmm12, xmm12
00007b1fbf9cfecb  jnz 0x00007B1FBF9D32EE
00007b1fbf9cfed1  vmovaps xmm12, [rsp+0x20]
00007b1fbf9cfed7  movaps xmm14, xmm12
00007b1fbf9cfedb  addpd xmm14, xmm5
00007b1fbf9cfee0  vcmppd xmm6, xmm14, xmm14, 0x03
00007b1fbf9cfee6  ptest xmm6, xmm6
00007b1fbf9cfeeb  jnz 0x00007B1FBF9D342F
00007b1fbf9cfef1  vmovaps xmm12, [rsp+0x90]
00007b1fbf9cfefa  vpermilpd xmm12, xmm12, 0x00
00007b1fbf9cff00  movaps xmm6, xmm9
00007b1fbf9cff04  mulpd xmm6, xmm12
00007b1fbf9cff09  vcmppd xmm5, xmm6, xmm6, 0x03
00007b1fbf9cff0e  ptest xmm5, xmm5
00007b1fbf9cff13  jnz 0x00007B1FBF9D3572
00007b1fbf9cff19  movaps xmm12, xmm15
00007b1fbf9cff1d  addpd xmm12, xmm13
00007b1fbf9cff22  vcmppd xmm9, xmm12, xmm12, 0x03
00007b1fbf9cff28  ptest xmm9, xmm9
00007b1fbf9cff2e  jnz 0x00007B1FBF9D36B4
00007b1fbf9cff34  vmovaps xmm13, [rsp+0x30]
00007b1fbf9cff3a  movaps xmm15, xmm13
00007b1fbf9cff3e  addpd xmm15, xmm10
00007b1fbf9cff43  vcmppd xmm9, xmm15, xmm15, 0x03
00007b1fbf9cff49  ptest xmm9, xmm9
00007b1fbf9cff4f  jnz 0x00007B1FBF9D37F8
00007b1fbf9cff55  vmovaps xmm13, [rsp+0xD0]
00007b1fbf9cff5e  vmovaps xmm10, [rsp+0xD0]
00007b1fbf9cff67  por xmm13, xmm10
00007b1fbf9cff6c  movaps [r15+0x250], xmm13
00007b1fbf9cff74  vmovaps [rsp+0x20], xmm7
00007b1fbf9cff7a  vmovaps xmm13, [rsp+0x20]
00007b1fbf9cff80  por xmm7, xmm13
00007b1fbf9cff85  movaps [r15+0x2A0], xmm7
00007b1fbf9cff8d  vmovaps [rsp+0x20], xmm3
00007b1fbf9cff93  vmovaps xmm13, [rsp+0x20]
00007b1fbf9cff99  por xmm3, xmm13
00007b1fbf9cff9e  movaps [r15+0x1D0], xmm3
00007b1fbf9cffa6  lea rax, [r14+0x40]
00007b1fbf9cffaa  movups xmm13, [r13+rax*1]
00007b1fbf9cffb0  movaps [r15+0x2C0], xmm13
00007b1fbf9cffb8  vmovaps xmm10, [rsp+0x90]
00007b1fbf9cffc1  vpermilpd xmm10, xmm10, 0x00
00007b1fbf9cffc7  movaps xmm9, xmm8
00007b1fbf9cffcb  mulpd xmm9, xmm10
00007b1fbf9cffd0  vcmppd xmm5, xmm9, xmm9, 0x03
00007b1fbf9cffd6  ptest xmm5, xmm5
00007b1fbf9cffdb  jnz 0x00007B1FBF9D3946
00007b1fbf9cffe1  movaps xmm10, xmm1
00007b1fbf9cffe5  addpd xmm10, xmm11
00007b1fbf9cffea  vcmppd xmm8, xmm10, xmm10, 0x03
00007b1fbf9cfff0  ptest xmm8, xmm8
00007b1fbf9cfff6  jnz 0x00007B1FBF9D3A8A
00007b1fbf9cfffc  movaps xmm1, xmm14
00007b1fbf9d0000  addpd xmm1, xmm6
00007b1fbf9d0004  vcmppd xmm11, xmm1, xmm1, 0x03
00007b1fbf9d0009  ptest xmm11, xmm11
00007b1fbf9d000f  jnz 0x00007B1FBF9D3BCD
00007b1fbf9d0015  vmovaps xmm14, [rsp+0x90]
00007b1fbf9d001e  vpermilpd xmm14, xmm14, 0x00
00007b1fbf9d0024  movaps xmm11, xmm13
00007b1fbf9d0028  mulpd xmm11, xmm14
00007b1fbf9d002d  vcmppd xmm8, xmm11, xmm11, 0x03
00007b1fbf9d0033  ptest xmm8, xmm8
00007b1fbf9d0039  jnz 0x00007B1FBF9D3D0E
00007b1fbf9d003f  vmovaps xmm14, [rsp+0x90]
00007b1fbf9d0048  vpermilpd xmm14, xmm14, 0x00
00007b1fbf9d004e  vmovaps xmm8, [rsp+0x10]
00007b1fbf9d0054  movaps xmm13, xmm8
00007b1fbf9d0058  mulpd xmm13, xmm14
00007b1fbf9d005d  vcmppd xmm6, xmm13, xmm13, 0x03
00007b1fbf9d0063  ptest xmm6, xmm6
00007b1fbf9d0068  jnz 0x00007B1FBF9D3E52
00007b1fbf9d006e  vmovaps xmm14, [rsp+0x60]
00007b1fbf9d0074  vpermilpd xmm14, xmm14, 0x00
00007b1fbf9d007a  movaps xmm8, xmm7
00007b1fbf9d007e  mulpd xmm8, xmm14
00007b1fbf9d0083  vcmppd xmm6, xmm8, xmm8, 0x03
00007b1fbf9d0089  ptest xmm6, xmm6
00007b1fbf9d008e  jnz 0x00007B1FBF9D3F96
00007b1fbf9d0094  movaps xmm14, xmm12
00007b1fbf9d0098  addpd xmm14, xmm9
00007b1fbf9d009d  vcmppd xmm7, xmm14, xmm14, 0x03
00007b1fbf9d00a3  ptest xmm7, xmm7
00007b1fbf9d00a8  jnz 0x00007B1FBF9D40D9
00007b1fbf9d00ae  vmovaps xmm12, [rsp+0x60]
00007b1fbf9d00b4  vpermilpd xmm12, xmm12, 0x00
00007b1fbf9d00ba  vmovaps xmm7, [rsp+0xF0]
00007b1fbf9d00c3  movaps xmm9, xmm7
00007b1fbf9d00c7  mulpd xmm9, xmm12
00007b1fbf9d00cc  vcmppd xmm6, xmm9, xmm9, 0x03
00007b1fbf9d00d2  ptest xmm6, xmm6
00007b1fbf9d00d7  jnz 0x00007B1FBF9D421D
00007b1fbf9d00dd  movaps xmm12, xmm15
00007b1fbf9d00e1  addpd xmm12, xmm11
00007b1fbf9d00e6  vcmppd xmm7, xmm12, xmm12, 0x03
00007b1fbf9d00ec  ptest xmm7, xmm7
00007b1fbf9d00f1  jnz 0x00007B1FBF9D4360
00007b1fbf9d00f7  vmovaps xmm15, [rsp+0x60]
00007b1fbf9d00fd  vpermilpd xmm15, xmm15, 0x00
00007b1fbf9d0103  vmovaps xmm7, [rsp+0x40]
00007b1fbf9d0109  movaps xmm11, xmm7
00007b1fbf9d010d  mulpd xmm11, xmm15
00007b1fbf9d0112  vcmppd xmm6, xmm11, xmm11, 0x03
00007b1fbf9d0118  ptest xmm6, xmm6
00007b1fbf9d011d  jnz 0x00007B1FBF9D44A4
00007b1fbf9d0123  movaps xmm15, xmm10
00007b1fbf9d0127  addpd xmm15, xmm13
00007b1fbf9d012c  vcmppd xmm7, xmm15, xmm15, 0x03
00007b1fbf9d0132  ptest xmm7, xmm7
00007b1fbf9d0137  jnz 0x00007B1FBF9D45E7
00007b1fbf9d013d  vmovaps xmm13, [rsp+0x60]
00007b1fbf9d0143  vpermilpd xmm13, xmm13, 0x00
00007b1fbf9d0149  vmovaps xmm7, [rsp+0x50]
00007b1fbf9d014f  movaps xmm10, xmm7
00007b1fbf9d0153  mulpd xmm10, xmm13
00007b1fbf9d0158  vcmppd xmm6, xmm10, xmm10, 0x03
00007b1fbf9d015e  ptest xmm6, xmm6
00007b1fbf9d0163  jnz 0x00007B1FBF9D472B
00007b1fbf9d0169  movaps xmm13, xmm1
00007b1fbf9d016d  addpd xmm13, xmm8
00007b1fbf9d0172  vcmppd xmm7, xmm13, xmm13, 0x03
00007b1fbf9d0178  ptest xmm7, xmm7
00007b1fbf9d017d  jnz 0x00007B1FBF9D486E
00007b1fbf9d0183  lea rax, [r14+0x70]
00007b1fbf9d0187  movups xmm1, [r13+rax*1]
00007b1fbf9d018d  movaps [r15+0x240], xmm1
00007b1fbf9d0195  movaps xmm8, xmm14
00007b1fbf9d0199  addpd xmm8, xmm9
00007b1fbf9d019e  vcmppd xmm7, xmm8, xmm8, 0x03
00007b1fbf9d01a4  ptest xmm7, xmm7
00007b1fbf9d01a9  jnz 0x00007B1FBF9D49BB
00007b1fbf9d01af  movaps [r15+0x170], xmm8
00007b1fbf9d01b7  vmovaps xmm14, [rsp+0x70]
00007b1fbf9d01bd  vpermilpd xmm14, xmm14, 0x00
00007b1fbf9d01c3  movaps xmm9, xmm1
00007b1fbf9d01c7  mulpd xmm9, xmm14
00007b1fbf9d01cc  vcmppd xmm7, xmm9, xmm9, 0x03
00007b1fbf9d01d2  ptest xmm7, xmm7
00007b1fbf9d01d7  jnz 0x00007B1FBF9D4AFF
00007b1fbf9d01dd  vmovaps xmm1, [rsp+0x70]
00007b1fbf9d01e3  vpermilpd xmm1, xmm1, 0x00
00007b1fbf9d01e9  movaps xmm14, xmm4
00007b1fbf9d01ed  mulpd xmm14, xmm1
00007b1fbf9d01f2  vcmppd xmm7, xmm14, xmm14, 0x03
00007b1fbf9d01f8  ptest xmm7, xmm7
00007b1fbf9d01fd  jnz 0x00007B1FBF9D4C42
00007b1fbf9d0203  movaps [r15+0x180], xmm14
00007b1fbf9d020b  movaps xmm1, xmm12
00007b1fbf9d020f  addpd xmm1, xmm11
00007b1fbf9d0214  vcmppd xmm7, xmm1, xmm1, 0x03
00007b1fbf9d0219  ptest xmm7, xmm7
00007b1fbf9d021e  jnz 0x00007B1FBF9D4D84
00007b1fbf9d0224  movaps [r15+0x210], xmm1
00007b1fbf9d022c  movups xmm12, [r13+r14*1]
00007b1fbf9d0232  lea rax, [r14+0x10]
00007b1fbf9d0236  movups xmm11, [r13+rax*1]
00007b1fbf9d023c  movaps [r15+0x230], xmm11
00007b1fbf9d0244  movaps xmm7, xmm15
00007b1fbf9d0248  addpd xmm7, xmm10
00007b1fbf9d024d  vcmppd xmm6, xmm7, xmm7, 0x03
00007b1fbf9d0252  ptest xmm6, xmm6
00007b1fbf9d0257  jnz 0x00007B1FBF9D4EDA
00007b1fbf9d025d  movaps [r15+0x130], xmm7
00007b1fbf9d0265  vmovaps xmm15, [rsp+0x70]
00007b1fbf9d026b  vpermilpd xmm15, xmm15, 0x00
00007b1fbf9d0271  movaps xmm10, xmm11
00007b1fbf9d0275  mulpd xmm10, xmm15
00007b1fbf9d027a  vcmppd xmm6, xmm10, xmm10, 0x03
00007b1fbf9d0280  ptest xmm6, xmm6
00007b1fbf9d0285  jnz 0x00007B1FBF9D501C
00007b1fbf9d028b  movaps [r15+0x220], xmm10
00007b1fbf9d0293  vmovaps xmm15, [rsp+0x70]
00007b1fbf9d0299  vpermilpd xmm15, xmm15, 0x00
00007b1fbf9d029f  movaps xmm11, xmm12
00007b1fbf9d02a3  mulpd xmm11, xmm15
00007b1fbf9d02a8  vcmppd xmm6, xmm11, xmm11, 0x03
00007b1fbf9d02ae  ptest xmm6, xmm6
00007b1fbf9d02b3  jnz 0x00007B1FBF9D5160
00007b1fbf9d02b9  movaps xmm15, xmm13
00007b1fbf9d02bd  addpd xmm15, xmm9
00007b1fbf9d02c2  vcmppd xmm12, xmm15, xmm15, 0x03
00007b1fbf9d02c8  ptest xmm12, xmm12
00007b1fbf9d02ce  jnz 0x00007B1FBF9D52A4
00007b1fbf9d02d4  movaps [r15+0x140], xmm15
00007b1fbf9d02dc  movaps xmm13, xmm8
00007b1fbf9d02e0  addpd xmm13, xmm14
00007b1fbf9d02e5  vcmppd xmm12, xmm13, xmm13, 0x03
00007b1fbf9d02eb  ptest xmm12, xmm12
00007b1fbf9d02f1  jnz 0x00007B1FBF9D53E8
00007b1fbf9d02f7  movaps [r15+0x150], xmm13
00007b1fbf9d02ff  movaps xmm14, xmm1
00007b1fbf9d0303  addpd xmm14, xmm10
00007b1fbf9d0308  vcmppd xmm12, xmm14, xmm14, 0x03
00007b1fbf9d030e  ptest xmm12, xmm12
00007b1fbf9d0314  jnz 0x00007B1FBF9D552C
00007b1fbf9d031a  movaps [r15+0x160], xmm14
00007b1fbf9d0322  movaps xmm1, xmm7
00007b1fbf9d0325  addpd xmm1, xmm11
00007b1fbf9d032a  vcmppd xmm12, xmm1, xmm1, 0x03
00007b1fbf9d032f  ptest xmm12, xmm12
00007b1fbf9d0335  jnz 0x00007B1FBF9D566F
00007b1fbf9d033b  movaps [r15+0x120], xmm1
00007b1fbf9d0343  mov eax, 0x430920
00007b1fbf9d0348  movups [r13+rax*1], xmm15
00007b1fbf9d034e  mov eax, 0x430930
00007b1fbf9d0353  movups [r13+rax*1], xmm13
00007b1fbf9d0359  mov eax, 0x430940
00007b1fbf9d035e  movups [r13+rax*1], xmm14
00007b1fbf9d0364  mov eax, 0x430950
00007b1fbf9d0369  movups [r13+rax*1], xmm1
00007b1fbf9d036f  mov eax, [r15+0x108]
00007b1fbf9d0376  sahf
00007b1fbf9d0377  jnz 0x00007B1FBF9D03A9
00007b1fbf9d0379  cmp dword ptr [r15+0x318], 0x00
00007b1fbf9d0381  jz 0x00007B1FBF9DB900
00007b1fbf9d0387  nop [rax+rax*1], ax
00007b1fbf9d0390  nop [rax+rax*1], eax
00007b1fbf9d0398  mov eax, 0x410444
00007b1fbf9d039d  mov [r15+0x100], rax
00007b1fbf9d03a4  jmp 0x00007B1FBF7FE110
00007b1fbf9d03a9  cmp dword ptr [r15+0x318], 0x00
00007b1fbf9d03b1  jz 0x00007B1FBF9D57E0
00007b1fbf9d03b7  nop [rax+rax*1], ax
00007b1fbf9d03c0  nop [rax+rax*1], eax
00007b1fbf9d03c8  mov eax, 0x410278
00007b1fbf9d03cd  mov [r15+0x100], rax
00007b1fbf9d03d4  jmp 0x00007B1FBF7FE110
00007b1fbf9d03d9  int3
00007b1fbf9d03da  call 0x00007B1FBF8B52F0
00007b1fbf9d03df  jmp 0x00007B1FBF9CF016
00007b1fbf9d03e4  call 0x00007B1FBF8C4620
00007b1fbf9d03e9  jmp 0x00007B1FBF9CF023
00007b1fbf9d03ee  call 0x00007B1FBF8C33A0
00007b1fbf9d03f3  jmp 0x00007B1FBF9CF035
00007b1fbf9d03f8  call 0x00007B1FBF8C2120
00007b1fbf9d03fd  jmp 0x00007B1FBF9CF03F
00007b1fbf9d0402  call 0x00007B1FBF8C0860
00007b1fbf9d0407  jmp 0x00007B1FBF9CF067
00007b1fbf9d040c  call 0x00007B1FBF8BF5F0
00007b1fbf9d0411  jmp 0x00007B1FBF9CF073
00007b1fbf9d0416  call 0x00007B1FBF8C0860
00007b1fbf9d041b  jmp 0x00007B1FBF9CF0A5
00007b1fbf9d0420  call 0x00007B1FBF8BF5F0
00007b1fbf9d0425  jmp 0x00007B1FBF9CF0B1
00007b1fbf9d042a  call 0x00007B1FBF8C4740
00007b1fbf9d042f  jmp 0x00007B1FBF9CF0BE
00007b1fbf9d0434  call 0x00007B1FBF8B5400
00007b1fbf9d0439  jmp 0x00007B1FBF9CF0CB
00007b1fbf9d043e  call 0x00007B1FBF8B52F0
00007b1fbf9d0443  jmp 0x00007B1FBF9CF0D8
00007b1fbf9d0448  call 0x00007B1FBF8C4620
00007b1fbf9d044d  jmp 0x00007B1FBF9CF0E5
00007b1fbf9d0452  call 0x00007B1FBF8C0860
00007b1fbf9d0457  jmp 0x00007B1FBF9CF10D
00007b1fbf9d045c  call 0x00007B1FBF8BF5F0
00007b1fbf9d0461  jmp 0x00007B1FBF9CF119
00007b1fbf9d0466  call 0x00007B1FBF809D70
00007b1fbf9d046b  jmp 0x00007B1FBF9CF11F
00007b1fbf9d0470  call 0x00007B1FBF8BE9C0
00007b1fbf9d0475  jmp 0x00007B1FBF9CF129
00007b1fbf9d047a  call 0x00007B1FBF8C0860
00007b1fbf9d047f  jmp 0x00007B1FBF9CF151
00007b1fbf9d0484  call 0x00007B1FBF8BF5F0
00007b1fbf9d0489  jmp 0x00007B1FBF9CF15D
00007b1fbf9d048e  call 0x00007B1FBF8BD750
00007b1fbf9d0493  jmp 0x00007B1FBF9CF16A
00007b1fbf9d0498  call 0x00007B1FBF8BC4E0
00007b1fbf9d049d  jmp 0x00007B1FBF9CF177
00007b1fbf9d04a2  call 0x00007B1FBF8C4740
00007b1fbf9d04a7  jmp 0x00007B1FBF9CF184
00007b1fbf9d04ac  call 0x00007B1FBF8B5400
00007b1fbf9d04b1  jmp 0x00007B1FBF9CF191
00007b1fbf9d04b6  call 0x00007B1FBF8B52F0
00007b1fbf9d04bb  jmp 0x00007B1FBF9CF19E
00007b1fbf9d04c0  call 0x00007B1FBF8C4620
00007b1fbf9d04c5  jmp 0x00007B1FBF9CF1AB
00007b1fbf9d04ca  call 0x00007B1FBF8C0860
00007b1fbf9d04cf  jmp 0x00007B1FBF9CF1BE
00007b1fbf9d04d4  call 0x00007B1FBF8BB270
00007b1fbf9d04d9  jmp 0x00007B1FBF9CF1CB
00007b1fbf9d04de  call 0x00007B1FBF8BA000
00007b1fbf9d04e3  jmp 0x00007B1FBF9CF1D8
00007b1fbf9d04e8  call 0x00007B1FBF8B8D90
00007b1fbf9d04ed  jmp 0x00007B1FBF9CF1E5
00007b1fbf9d04f2  call 0x00007B1FBF8B8A20
00007b1fbf9d04f7  jmp 0x00007B1FBF9CF1F2
00007b1fbf9d04fc  call 0x00007B1FBF8B5400
00007b1fbf9d0501  jmp 0x00007B1FBF9CF1FC
00007b1fbf9d0506  call 0x00007B1FBF8C2240
00007b1fbf9d050b  jmp 0x00007B1FBF9CF206
00007b1fbf9d0510  call 0x00007B1FBF8B52F0
00007b1fbf9d0515  jmp 0x00007B1FBF9CF210
00007b1fbf9d051a  call 0x00007B1FBF8C2120
00007b1fbf9d051f  jmp 0x00007B1FBF9CF21A
00007b1fbf9d0524  call 0x00007B1FBF8B77B0
00007b1fbf9d0529  jmp 0x00007B1FBF9CF224
00007b1fbf9d052e  call 0x00007B1FBF8B6550
00007b1fbf9d0533  jmp 0x00007B1FBF9CF22E
00007b1fbf9d0538  call 0x00007B1FBF8BFD50
00007b1fbf9d053d  jmp 0x00007B1FBF9CF240
00007b1fbf9d0542  call 0x00007B1FBF8B8EA0
00007b1fbf9d0547  jmp 0x00007B1FBF9CF24A
00007b1fbf9d054c  call 0x00007B1FBF8BFC30
00007b1fbf9d0551  jmp 0x00007B1FBF9CF257
00007b1fbf9d0556  call 0x00007B1FBF8B8D90
00007b1fbf9d055b  jmp 0x00007B1FBF9CF264
00007b1fbf9d0560  call 0x00007B1FBF8C2240
00007b1fbf9d0565  jmp 0x00007B1FBF9CF271
00007b1fbf9d056a  call 0x00007B1FBF8B5400
00007b1fbf9d056f  jmp 0x00007B1FBF9CF27E
00007b1fbf9d0574  call 0x00007B1FBF8B52F0
00007b1fbf9d0579  jmp 0x00007B1FBF9CF28B
00007b1fbf9d057e  call 0x00007B1FBF8C2120
00007b1fbf9d0583  jmp 0x00007B1FBF9CF298
00007b1fbf9d0588  call 0x00007B1FBF8B52F0
00007b1fbf9d058d  jmp 0x00007B1FBF9CF2AB
00007b1fbf9d0592  call 0x00007B1FBF8B52F0
00007b1fbf9d0597  jmp 0x00007B1FBF9CF2BE
00007b1fbf9d059c  call 0x00007B1FBF8B52F0
00007b1fbf9d05a1  jmp 0x00007B1FBF9CF2D1
00007b1fbf9d05a6  call 0x00007B1FBF8B52F0
00007b1fbf9d05ab  jmp 0x00007B1FBF9CF2E4
00007b1fbf9d05b0  call 0x00007B1FBF8C2240
00007b1fbf9d05b5  jmp 0x00007B1FBF9CF2F9
00007b1fbf9d05ba  call 0x00007B1FBF8C2240
00007b1fbf9d05bf  jmp 0x00007B1FBF9CF30C
00007b1fbf9d05c4  call 0x00007B1FBF8C2120
00007b1fbf9d05c9  jmp 0x00007B1FBF9CF319
00007b1fbf9d05ce  call 0x00007B1FBF8B52F0
00007b1fbf9d05d3  jmp 0x00007B1FBF9CF32C
00007b1fbf9d05d8  call 0x00007B1FBF8B52F0
00007b1fbf9d05dd  jmp 0x00007B1FBF9CF34F
00007b1fbf9d05e2  call 0x00007B1FBF8B52F0
00007b1fbf9d05e7  jmp 0x00007B1FBF9CF362
00007b1fbf9d05ec  call 0x00007B1FBF7FF540
00007b1fbf9d05f1  jmp 0x00007B1FBF9CF380
00007b1fbf9d05f6  call 0x00007B1FBF808C20
00007b1fbf9d05fb  jmp 0x00007B1FBF9CF38A
00007b1fbf9d0600  call 0x00007B1FBF8D6600
00007b1fbf9d0605  jmp 0x00007B1FBF9CF396
00007b1fbf9d060a  call 0x00007B1FBF7FF540
00007b1fbf9d060f  jmp 0x00007B1FBF9CF3A6
00007b1fbf9d0614  call 0x00007B1FBF8C0370
00007b1fbf9d0619  jmp 0x00007B1FBF9CF3D4
00007b1fbf9d061e  call 0x00007B1FBF8BF100
00007b1fbf9d0623  jmp 0x00007B1FBF9CF3DD
00007b1fbf9d0628  call 0x00007B1FBF8C0370
00007b1fbf9d062d  jmp 0x00007B1FBF9CF43B
00007b1fbf9d0632  call 0x00007B1FBF8BF100
00007b1fbf9d0637  jmp 0x00007B1FBF9CF444
00007b1fbf9d063c  call 0x00007B1FBF8C0370
00007b1fbf9d0641  jmp 0x00007B1FBF9CF48B
00007b1fbf9d0646  call 0x00007B1FBF8BF100
00007b1fbf9d064b  jmp 0x00007B1FBF9CF494
00007b1fbf9d0650  call 0x00007B1FBF80B720
00007b1fbf9d0655  jmp 0x00007B1FBF9CF4D7
00007b1fbf9d065a  call 0x00007B1FBF8B47C0
00007b1fbf9d065f  jmp 0x00007B1FBF9CF4EA
00007b1fbf9d0664  call 0x00007B1FBF808B00
00007b1fbf9d0669  jmp 0x00007B1FBF9CF501
00007b1fbf9d066e  call 0x00007B1FBF7FF430
00007b1fbf9d0673  jmp 0x00007B1FBF9CF514
00007b1fbf9d0678  call 0x00007B1FBF7FF430
00007b1fbf9d067d  jmp 0x00007B1FBF9CF527
00007b1fbf9d0682  sub rsp, 0x08
00007b1fbf9d0686  push rax
00007b1fbf9d0687  push rcx
00007b1fbf9d0688  push rdx
00007b1fbf9d0689  push rdi
00007b1fbf9d068a  push rsi
00007b1fbf9d068b  push r8
00007b1fbf9d068d  push r9
00007b1fbf9d068f  push r10
00007b1fbf9d0691  push r11
00007b1fbf9d0693  sub rsp, 0xF0
00007b1fbf9d069a  vmovaps [rsp], xmm0
00007b1fbf9d069f  vmovaps [rsp+0x10], xmm2
00007b1fbf9d06a5  vmovaps [rsp+0x20], xmm3
00007b1fbf9d06ab  vmovaps [rsp+0x30], xmm4
00007b1fbf9d06b1  vmovaps [rsp+0x40], xmm5
00007b1fbf9d06b7  vmovaps [rsp+0x50], xmm6
00007b1fbf9d06bd  vmovaps [rsp+0x60], xmm7
00007b1fbf9d06c3  vmovaps [rsp+0x70], xmm8
00007b1fbf9d06c9  vmovaps [rsp+0x80], xmm9
00007b1fbf9d06d2  vmovaps [rsp+0x90], xmm10
00007b1fbf9d06db  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d06e4  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d06ed  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d06f6  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d06ff  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d0708  sub rsp, 0x30
00007b1fbf9d070c  movaps [rsp], xmm1
00007b1fbf9d0710  movaps [rsp+0x10], xmm15
00007b1fbf9d0716  movaps [rsp+0x20], xmm14
00007b1fbf9d071c  lea rdi, [rsp]
00007b1fbf9d0720  mov esi, 0x00
00007b1fbf9d0725  mov rax, 0x64AEE5F12530
00007b1fbf9d072f  call rax
00007b1fbf9d0731  movaps xmm1, [rsp]
00007b1fbf9d0735  add rsp, 0x30
00007b1fbf9d0739  vmovaps xmm0, [rsp]
00007b1fbf9d073e  vmovaps xmm2, [rsp+0x10]
00007b1fbf9d0744  vmovaps xmm3, [rsp+0x20]
00007b1fbf9d074a  vmovaps xmm4, [rsp+0x30]
00007b1fbf9d0750  vmovaps xmm5, [rsp+0x40]
00007b1fbf9d0756  vmovaps xmm6, [rsp+0x50]
00007b1fbf9d075c  vmovaps xmm7, [rsp+0x60]
00007b1fbf9d0762  vmovaps xmm8, [rsp+0x70]
00007b1fbf9d0768  vmovaps xmm9, [rsp+0x80]
00007b1fbf9d0771  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d077a  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d0783  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d078c  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d0795  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d079e  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d07a7  add rsp, 0xF0
00007b1fbf9d07ae  pop r11
00007b1fbf9d07b0  pop r10
00007b1fbf9d07b2  pop r9
00007b1fbf9d07b4  pop r8
00007b1fbf9d07b6  pop rsi
00007b1fbf9d07b7  pop rdi
00007b1fbf9d07b8  pop rdx
00007b1fbf9d07b9  pop rcx
00007b1fbf9d07ba  pop rax
00007b1fbf9d07bb  add rsp, 0x08
00007b1fbf9d07bf  jmp 0x00007B1FBF9CF581
00007b1fbf9d07c4  sub rsp, 0x08
00007b1fbf9d07c8  push rax
00007b1fbf9d07c9  push rcx
00007b1fbf9d07ca  push rdx
00007b1fbf9d07cb  push rdi
00007b1fbf9d07cc  push rsi
00007b1fbf9d07cd  push r8
00007b1fbf9d07cf  push r9
00007b1fbf9d07d1  push r10
00007b1fbf9d07d3  push r11
00007b1fbf9d07d5  sub rsp, 0xF0
00007b1fbf9d07dc  vmovaps [rsp], xmm0
00007b1fbf9d07e1  vmovaps [rsp+0x10], xmm1
00007b1fbf9d07e7  vmovaps [rsp+0x20], xmm2
00007b1fbf9d07ed  vmovaps [rsp+0x30], xmm3
00007b1fbf9d07f3  vmovaps [rsp+0x40], xmm4
00007b1fbf9d07f9  vmovaps [rsp+0x50], xmm5
00007b1fbf9d07ff  vmovaps [rsp+0x60], xmm6
00007b1fbf9d0805  vmovaps [rsp+0x70], xmm7
00007b1fbf9d080b  vmovaps [rsp+0x80], xmm8
00007b1fbf9d0814  vmovaps [rsp+0x90], xmm9
00007b1fbf9d081d  vmovaps [rsp+0xA0], xmm10
00007b1fbf9d0826  vmovaps [rsp+0xB0], xmm11
00007b1fbf9d082f  vmovaps [rsp+0xC0], xmm12
00007b1fbf9d0838  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d0841  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d084a  sub rsp, 0x30
00007b1fbf9d084e  movaps [rsp], xmm13
00007b1fbf9d0853  movaps [rsp+0x10], xmm1
00007b1fbf9d0858  movaps [rsp+0x20], xmm14
00007b1fbf9d085e  lea rdi, [rsp]
00007b1fbf9d0862  mov esi, 0x00
00007b1fbf9d0867  mov rax, 0x64AEE5F12530
00007b1fbf9d0871  call rax
00007b1fbf9d0873  movaps xmm13, [rsp]
00007b1fbf9d0878  add rsp, 0x30
00007b1fbf9d087c  vmovaps xmm0, [rsp]
00007b1fbf9d0881  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d0887  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d088d  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d0893  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d0899  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d089f  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d08a5  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d08ab  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d08b4  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d08bd  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9d08c6  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9d08cf  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9d08d8  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d08e1  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d08ea  add rsp, 0xF0
00007b1fbf9d08f1  pop r11
00007b1fbf9d08f3  pop r10
00007b1fbf9d08f5  pop r9
00007b1fbf9d08f7  pop r8
00007b1fbf9d08f9  pop rsi
00007b1fbf9d08fa  pop rdi
00007b1fbf9d08fb  pop rdx
00007b1fbf9d08fc  pop rcx
00007b1fbf9d08fd  pop rax
00007b1fbf9d08fe  add rsp, 0x08
00007b1fbf9d0902  jmp 0x00007B1FBF9CF5CF
00007b1fbf9d0907  sub rsp, 0x08
00007b1fbf9d090b  push rax
00007b1fbf9d090c  push rcx
00007b1fbf9d090d  push rdx
00007b1fbf9d090e  push rdi
00007b1fbf9d090f  push rsi
00007b1fbf9d0910  push r8
00007b1fbf9d0912  push r9
00007b1fbf9d0914  push r10
00007b1fbf9d0916  push r11
00007b1fbf9d0918  sub rsp, 0xF0
00007b1fbf9d091f  vmovaps [rsp], xmm0
00007b1fbf9d0924  vmovaps [rsp+0x10], xmm1
00007b1fbf9d092a  vmovaps [rsp+0x20], xmm2
00007b1fbf9d0930  vmovaps [rsp+0x30], xmm3
00007b1fbf9d0936  vmovaps [rsp+0x40], xmm4
00007b1fbf9d093c  vmovaps [rsp+0x50], xmm5
00007b1fbf9d0942  vmovaps [rsp+0x60], xmm6
00007b1fbf9d0948  vmovaps [rsp+0x70], xmm7
00007b1fbf9d094e  vmovaps [rsp+0x80], xmm8
00007b1fbf9d0957  vmovaps [rsp+0x90], xmm9
00007b1fbf9d0960  vmovaps [rsp+0xA0], xmm10
00007b1fbf9d0969  vmovaps [rsp+0xB0], xmm11
00007b1fbf9d0972  vmovaps [rsp+0xC0], xmm12
00007b1fbf9d097b  vmovaps [rsp+0xD0], xmm13
00007b1fbf9d0984  vmovaps [rsp+0xE0], xmm14
00007b1fbf9d098d  sub rsp, 0x30
00007b1fbf9d0991  movaps [rsp], xmm15
00007b1fbf9d0996  movaps [rsp+0x10], xmm14
00007b1fbf9d099c  movaps [rsp+0x20], xmm1
00007b1fbf9d09a1  lea rdi, [rsp]
00007b1fbf9d09a5  mov esi, 0x00
00007b1fbf9d09aa  mov rax, 0x64AEE5F12530
00007b1fbf9d09b4  call rax
00007b1fbf9d09b6  movaps xmm15, [rsp]
00007b1fbf9d09bb  add rsp, 0x30
00007b1fbf9d09bf  vmovaps xmm0, [rsp]
00007b1fbf9d09c4  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d09ca  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d09d0  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d09d6  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d09dc  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d09e2  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d09e8  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d09ee  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d09f7  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d0a00  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9d0a09  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9d0a12  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9d0a1b  vmovaps xmm13, [rsp+0xD0]
00007b1fbf9d0a24  vmovaps xmm14, [rsp+0xE0]
00007b1fbf9d0a2d  add rsp, 0xF0
00007b1fbf9d0a34  pop r11
00007b1fbf9d0a36  pop r10
00007b1fbf9d0a38  pop r9
00007b1fbf9d0a3a  pop r8
00007b1fbf9d0a3c  pop rsi
00007b1fbf9d0a3d  pop rdi
00007b1fbf9d0a3e  pop rdx
00007b1fbf9d0a3f  pop rcx
00007b1fbf9d0a40  pop rax
00007b1fbf9d0a41  add rsp, 0x08
00007b1fbf9d0a45  jmp 0x00007B1FBF9CF617
00007b1fbf9d0a4a  sub rsp, 0x08
00007b1fbf9d0a4e  push rax
00007b1fbf9d0a4f  push rcx
00007b1fbf9d0a50  push rdx
00007b1fbf9d0a51  push rdi
00007b1fbf9d0a52  push rsi
00007b1fbf9d0a53  push r8
00007b1fbf9d0a55  push r9
00007b1fbf9d0a57  push r10
00007b1fbf9d0a59  push r11
00007b1fbf9d0a5b  sub rsp, 0xF0
00007b1fbf9d0a62  vmovaps [rsp], xmm0
00007b1fbf9d0a67  vmovaps [rsp+0x10], xmm2
00007b1fbf9d0a6d  vmovaps [rsp+0x20], xmm3
00007b1fbf9d0a73  vmovaps [rsp+0x30], xmm4
00007b1fbf9d0a79  vmovaps [rsp+0x40], xmm5
00007b1fbf9d0a7f  vmovaps [rsp+0x50], xmm6
00007b1fbf9d0a85  vmovaps [rsp+0x60], xmm7
00007b1fbf9d0a8b  vmovaps [rsp+0x70], xmm8
00007b1fbf9d0a91  vmovaps [rsp+0x80], xmm9
00007b1fbf9d0a9a  vmovaps [rsp+0x90], xmm10
00007b1fbf9d0aa3  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d0aac  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d0ab5  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d0abe  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d0ac7  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d0ad0  sub rsp, 0x30
00007b1fbf9d0ad4  movaps [rsp], xmm1
00007b1fbf9d0ad8  movaps [rsp+0x10], xmm14
00007b1fbf9d0ade  movaps [rsp+0x20], xmm10
00007b1fbf9d0ae4  lea rdi, [rsp]
00007b1fbf9d0ae8  mov esi, 0x00
00007b1fbf9d0aed  mov rax, 0x64AEE5F12530
00007b1fbf9d0af7  call rax
00007b1fbf9d0af9  movaps xmm1, [rsp]
00007b1fbf9d0afd  add rsp, 0x30
00007b1fbf9d0b01  vmovaps xmm0, [rsp]
00007b1fbf9d0b06  vmovaps xmm2, [rsp+0x10]
00007b1fbf9d0b0c  vmovaps xmm3, [rsp+0x20]
00007b1fbf9d0b12  vmovaps xmm4, [rsp+0x30]
00007b1fbf9d0b18  vmovaps xmm5, [rsp+0x40]
00007b1fbf9d0b1e  vmovaps xmm6, [rsp+0x50]
00007b1fbf9d0b24  vmovaps xmm7, [rsp+0x60]
00007b1fbf9d0b2a  vmovaps xmm8, [rsp+0x70]
00007b1fbf9d0b30  vmovaps xmm9, [rsp+0x80]
00007b1fbf9d0b39  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d0b42  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d0b4b  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d0b54  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d0b5d  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d0b66  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d0b6f  add rsp, 0xF0
00007b1fbf9d0b76  pop r11
00007b1fbf9d0b78  pop r10
00007b1fbf9d0b7a  pop r9
00007b1fbf9d0b7c  pop r8
00007b1fbf9d0b7e  pop rsi
00007b1fbf9d0b7f  pop rdi
00007b1fbf9d0b80  pop rdx
00007b1fbf9d0b81  pop rcx
00007b1fbf9d0b82  pop rax
00007b1fbf9d0b83  add rsp, 0x08
00007b1fbf9d0b87  jmp 0x00007B1FBF9CF631
00007b1fbf9d0b8c  sub rsp, 0x08
00007b1fbf9d0b90  push rax
00007b1fbf9d0b91  push rcx
00007b1fbf9d0b92  push rdx
00007b1fbf9d0b93  push rdi
00007b1fbf9d0b94  push rsi
00007b1fbf9d0b95  push r8
00007b1fbf9d0b97  push r9
00007b1fbf9d0b99  push r10
00007b1fbf9d0b9b  push r11
00007b1fbf9d0b9d  sub rsp, 0xF0
00007b1fbf9d0ba4  vmovaps [rsp], xmm0
00007b1fbf9d0ba9  vmovaps [rsp+0x10], xmm1
00007b1fbf9d0baf  vmovaps [rsp+0x20], xmm2
00007b1fbf9d0bb5  vmovaps [rsp+0x30], xmm3
00007b1fbf9d0bbb  vmovaps [rsp+0x40], xmm4
00007b1fbf9d0bc1  vmovaps [rsp+0x50], xmm5
00007b1fbf9d0bc7  vmovaps [rsp+0x60], xmm6
00007b1fbf9d0bcd  vmovaps [rsp+0x70], xmm7
00007b1fbf9d0bd3  vmovaps [rsp+0x80], xmm8
00007b1fbf9d0bdc  vmovaps [rsp+0x90], xmm9
00007b1fbf9d0be5  vmovaps [rsp+0xA0], xmm10
00007b1fbf9d0bee  vmovaps [rsp+0xB0], xmm11
00007b1fbf9d0bf7  vmovaps [rsp+0xC0], xmm12
00007b1fbf9d0c00  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d0c09  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d0c12  sub rsp, 0x30
00007b1fbf9d0c16  movaps [rsp], xmm13
00007b1fbf9d0c1b  movaps [rsp+0x10], xmm14
00007b1fbf9d0c21  movaps [rsp+0x20], xmm2
00007b1fbf9d0c26  lea rdi, [rsp]
00007b1fbf9d0c2a  mov esi, 0x00
00007b1fbf9d0c2f  mov rax, 0x64AEE5F12530
00007b1fbf9d0c39  call rax
00007b1fbf9d0c3b  movaps xmm13, [rsp]
00007b1fbf9d0c40  add rsp, 0x30
00007b1fbf9d0c44  vmovaps xmm0, [rsp]
00007b1fbf9d0c49  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d0c4f  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d0c55  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d0c5b  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d0c61  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d0c67  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d0c6d  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d0c73  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d0c7c  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d0c85  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9d0c8e  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9d0c97  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9d0ca0  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d0ca9  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d0cb2  add rsp, 0xF0
00007b1fbf9d0cb9  pop r11
00007b1fbf9d0cbb  pop r10
00007b1fbf9d0cbd  pop r9
00007b1fbf9d0cbf  pop r8
00007b1fbf9d0cc1  pop rsi
00007b1fbf9d0cc2  pop rdi
00007b1fbf9d0cc3  pop rdx
00007b1fbf9d0cc4  pop rcx
00007b1fbf9d0cc5  pop rax
00007b1fbf9d0cc6  add rsp, 0x08
00007b1fbf9d0cca  jmp 0x00007B1FBF9CF64C
00007b1fbf9d0ccf  sub rsp, 0x08
00007b1fbf9d0cd3  push rax
00007b1fbf9d0cd4  push rcx
00007b1fbf9d0cd5  push rdx
00007b1fbf9d0cd6  push rdi
00007b1fbf9d0cd7  push rsi
00007b1fbf9d0cd8  push r8
00007b1fbf9d0cda  push r9
00007b1fbf9d0cdc  push r10
00007b1fbf9d0cde  push r11
00007b1fbf9d0ce0  sub rsp, 0xF0
00007b1fbf9d0ce7  vmovaps [rsp], xmm0
00007b1fbf9d0cec  vmovaps [rsp+0x10], xmm2
00007b1fbf9d0cf2  vmovaps [rsp+0x20], xmm3
00007b1fbf9d0cf8  vmovaps [rsp+0x30], xmm4
00007b1fbf9d0cfe  vmovaps [rsp+0x40], xmm5
00007b1fbf9d0d04  vmovaps [rsp+0x50], xmm6
00007b1fbf9d0d0a  vmovaps [rsp+0x60], xmm7
00007b1fbf9d0d10  vmovaps [rsp+0x70], xmm8
00007b1fbf9d0d16  vmovaps [rsp+0x80], xmm9
00007b1fbf9d0d1f  vmovaps [rsp+0x90], xmm10
00007b1fbf9d0d28  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d0d31  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d0d3a  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d0d43  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d0d4c  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d0d55  sub rsp, 0x30
00007b1fbf9d0d59  movaps [rsp], xmm1
00007b1fbf9d0d5d  movaps [rsp+0x10], xmm10
00007b1fbf9d0d63  movaps [rsp+0x20], xmm2
00007b1fbf9d0d68  lea rdi, [rsp]
00007b1fbf9d0d6c  mov esi, 0x00
00007b1fbf9d0d71  mov rax, 0x64AEE5F12530
00007b1fbf9d0d7b  call rax
00007b1fbf9d0d7d  movaps xmm1, [rsp]
00007b1fbf9d0d81  add rsp, 0x30
00007b1fbf9d0d85  vmovaps xmm0, [rsp]
00007b1fbf9d0d8a  vmovaps xmm2, [rsp+0x10]
00007b1fbf9d0d90  vmovaps xmm3, [rsp+0x20]
00007b1fbf9d0d96  vmovaps xmm4, [rsp+0x30]
00007b1fbf9d0d9c  vmovaps xmm5, [rsp+0x40]
00007b1fbf9d0da2  vmovaps xmm6, [rsp+0x50]
00007b1fbf9d0da8  vmovaps xmm7, [rsp+0x60]
00007b1fbf9d0dae  vmovaps xmm8, [rsp+0x70]
00007b1fbf9d0db4  vmovaps xmm9, [rsp+0x80]
00007b1fbf9d0dbd  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d0dc6  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d0dcf  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d0dd8  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d0de1  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d0dea  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d0df3  add rsp, 0xF0
00007b1fbf9d0dfa  pop r11
00007b1fbf9d0dfc  pop r10
00007b1fbf9d0dfe  pop r9
00007b1fbf9d0e00  pop r8
00007b1fbf9d0e02  pop rsi
00007b1fbf9d0e03  pop rdi
00007b1fbf9d0e04  pop rdx
00007b1fbf9d0e05  pop rcx
00007b1fbf9d0e06  pop rax
00007b1fbf9d0e07  add rsp, 0x08
00007b1fbf9d0e0b  jmp 0x00007B1FBF9CF6B4
00007b1fbf9d0e10  sub rsp, 0x08
00007b1fbf9d0e14  push rax
00007b1fbf9d0e15  push rcx
00007b1fbf9d0e16  push rdx
00007b1fbf9d0e17  push rdi
00007b1fbf9d0e18  push rsi
00007b1fbf9d0e19  push r8
00007b1fbf9d0e1b  push r9
00007b1fbf9d0e1d  push r10
00007b1fbf9d0e1f  push r11
00007b1fbf9d0e21  sub rsp, 0xF0
00007b1fbf9d0e28  vmovaps [rsp], xmm0
00007b1fbf9d0e2d  vmovaps [rsp+0x10], xmm1
00007b1fbf9d0e33  vmovaps [rsp+0x20], xmm2
00007b1fbf9d0e39  vmovaps [rsp+0x30], xmm3
00007b1fbf9d0e3f  vmovaps [rsp+0x40], xmm4
00007b1fbf9d0e45  vmovaps [rsp+0x50], xmm5
00007b1fbf9d0e4b  vmovaps [rsp+0x60], xmm6
00007b1fbf9d0e51  vmovaps [rsp+0x70], xmm7
00007b1fbf9d0e57  vmovaps [rsp+0x80], xmm8
00007b1fbf9d0e60  vmovaps [rsp+0x90], xmm9
00007b1fbf9d0e69  vmovaps [rsp+0xA0], xmm10
00007b1fbf9d0e72  vmovaps [rsp+0xB0], xmm11
00007b1fbf9d0e7b  vmovaps [rsp+0xC0], xmm12
00007b1fbf9d0e84  vmovaps [rsp+0xD0], xmm13
00007b1fbf9d0e8d  vmovaps [rsp+0xE0], xmm14
00007b1fbf9d0e96  sub rsp, 0x30
00007b1fbf9d0e9a  movaps [rsp], xmm15
00007b1fbf9d0e9f  movaps [rsp+0x10], xmm10
00007b1fbf9d0ea5  movaps [rsp+0x20], xmm2
00007b1fbf9d0eaa  lea rdi, [rsp]
00007b1fbf9d0eae  mov esi, 0x00
00007b1fbf9d0eb3  mov rax, 0x64AEE5F12530
00007b1fbf9d0ebd  call rax
00007b1fbf9d0ebf  movaps xmm15, [rsp]
00007b1fbf9d0ec4  add rsp, 0x30
00007b1fbf9d0ec8  vmovaps xmm0, [rsp]
00007b1fbf9d0ecd  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d0ed3  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d0ed9  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d0edf  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d0ee5  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d0eeb  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d0ef1  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d0ef7  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d0f00  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d0f09  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9d0f12  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9d0f1b  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9d0f24  vmovaps xmm13, [rsp+0xD0]
00007b1fbf9d0f2d  vmovaps xmm14, [rsp+0xE0]
00007b1fbf9d0f36  add rsp, 0xF0
00007b1fbf9d0f3d  pop r11
00007b1fbf9d0f3f  pop r10
00007b1fbf9d0f41  pop r9
00007b1fbf9d0f43  pop r8
00007b1fbf9d0f45  pop rsi
00007b1fbf9d0f46  pop rdi
00007b1fbf9d0f47  pop rdx
00007b1fbf9d0f48  pop rcx
00007b1fbf9d0f49  pop rax
00007b1fbf9d0f4a  add rsp, 0x08
00007b1fbf9d0f4e  jmp 0x00007B1FBF9CF706
00007b1fbf9d0f53  sub rsp, 0x08
00007b1fbf9d0f57  push rax
00007b1fbf9d0f58  push rcx
00007b1fbf9d0f59  push rdx
00007b1fbf9d0f5a  push rdi
00007b1fbf9d0f5b  push rsi
00007b1fbf9d0f5c  push r8
00007b1fbf9d0f5e  push r9
00007b1fbf9d0f60  push r10
00007b1fbf9d0f62  push r11
00007b1fbf9d0f64  sub rsp, 0xF0
00007b1fbf9d0f6b  vmovaps [rsp], xmm0
00007b1fbf9d0f70  vmovaps [rsp+0x10], xmm2
00007b1fbf9d0f76  vmovaps [rsp+0x20], xmm3
00007b1fbf9d0f7c  vmovaps [rsp+0x30], xmm4
00007b1fbf9d0f82  vmovaps [rsp+0x40], xmm5
00007b1fbf9d0f88  vmovaps [rsp+0x50], xmm6
00007b1fbf9d0f8e  vmovaps [rsp+0x60], xmm7
00007b1fbf9d0f94  vmovaps [rsp+0x70], xmm8
00007b1fbf9d0f9a  vmovaps [rsp+0x80], xmm9
00007b1fbf9d0fa3  vmovaps [rsp+0x90], xmm10
00007b1fbf9d0fac  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d0fb5  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d0fbe  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d0fc7  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d0fd0  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d0fd9  sub rsp, 0x30
00007b1fbf9d0fdd  movaps [rsp], xmm1
00007b1fbf9d0fe1  movaps [rsp+0x10], xmm10
00007b1fbf9d0fe7  movaps [rsp+0x20], xmm12
00007b1fbf9d0fed  lea rdi, [rsp]
00007b1fbf9d0ff1  mov esi, 0x00
00007b1fbf9d0ff6  mov rax, 0x64AEE5F12530
00007b1fbf9d1000  call rax
00007b1fbf9d1002  movaps xmm1, [rsp]
00007b1fbf9d1006  add rsp, 0x30
00007b1fbf9d100a  vmovaps xmm0, [rsp]
00007b1fbf9d100f  vmovaps xmm2, [rsp+0x10]
00007b1fbf9d1015  vmovaps xmm3, [rsp+0x20]
00007b1fbf9d101b  vmovaps xmm4, [rsp+0x30]
00007b1fbf9d1021  vmovaps xmm5, [rsp+0x40]
00007b1fbf9d1027  vmovaps xmm6, [rsp+0x50]
00007b1fbf9d102d  vmovaps xmm7, [rsp+0x60]
00007b1fbf9d1033  vmovaps xmm8, [rsp+0x70]
00007b1fbf9d1039  vmovaps xmm9, [rsp+0x80]
00007b1fbf9d1042  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d104b  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d1054  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d105d  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d1066  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d106f  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d1078  add rsp, 0xF0
00007b1fbf9d107f  pop r11
00007b1fbf9d1081  pop r10
00007b1fbf9d1083  pop r9
00007b1fbf9d1085  pop r8
00007b1fbf9d1087  pop rsi
00007b1fbf9d1088  pop rdi
00007b1fbf9d1089  pop rdx
00007b1fbf9d108a  pop rcx
00007b1fbf9d108b  pop rax
00007b1fbf9d108c  add rsp, 0x08
00007b1fbf9d1090  jmp 0x00007B1FBF9CF732
00007b1fbf9d1095  sub rsp, 0x08
00007b1fbf9d1099  push rax
00007b1fbf9d109a  push rcx
00007b1fbf9d109b  push rdx
00007b1fbf9d109c  push rdi
00007b1fbf9d109d  push rsi
00007b1fbf9d109e  push r8
00007b1fbf9d10a0  push r9
00007b1fbf9d10a2  push r10
00007b1fbf9d10a4  push r11
00007b1fbf9d10a6  sub rsp, 0xF0
00007b1fbf9d10ad  vmovaps [rsp], xmm0
00007b1fbf9d10b2  vmovaps [rsp+0x10], xmm1
00007b1fbf9d10b8  vmovaps [rsp+0x20], xmm2
00007b1fbf9d10be  vmovaps [rsp+0x30], xmm3
00007b1fbf9d10c4  vmovaps [rsp+0x40], xmm4
00007b1fbf9d10ca  vmovaps [rsp+0x50], xmm5
00007b1fbf9d10d0  vmovaps [rsp+0x60], xmm6
00007b1fbf9d10d6  vmovaps [rsp+0x70], xmm7
00007b1fbf9d10dc  vmovaps [rsp+0x80], xmm8
00007b1fbf9d10e5  vmovaps [rsp+0x90], xmm9
00007b1fbf9d10ee  vmovaps [rsp+0xA0], xmm10
00007b1fbf9d10f7  vmovaps [rsp+0xB0], xmm11
00007b1fbf9d1100  vmovaps [rsp+0xC0], xmm12
00007b1fbf9d1109  vmovaps [rsp+0xD0], xmm13
00007b1fbf9d1112  vmovaps [rsp+0xE0], xmm14
00007b1fbf9d111b  sub rsp, 0x30
00007b1fbf9d111f  movaps [rsp], xmm15
00007b1fbf9d1124  movaps [rsp+0x10], xmm10
00007b1fbf9d112a  movaps [rsp+0x20], xmm12
00007b1fbf9d1130  lea rdi, [rsp]
00007b1fbf9d1134  mov esi, 0x00
00007b1fbf9d1139  mov rax, 0x64AEE5F12530
00007b1fbf9d1143  call rax
00007b1fbf9d1145  movaps xmm15, [rsp]
00007b1fbf9d114a  add rsp, 0x30
00007b1fbf9d114e  vmovaps xmm0, [rsp]
00007b1fbf9d1153  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d1159  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d115f  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d1165  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d116b  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d1171  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d1177  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d117d  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d1186  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d118f  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9d1198  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9d11a1  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9d11aa  vmovaps xmm13, [rsp+0xD0]
00007b1fbf9d11b3  vmovaps xmm14, [rsp+0xE0]
00007b1fbf9d11bc  add rsp, 0xF0
00007b1fbf9d11c3  pop r11
00007b1fbf9d11c5  pop r10
00007b1fbf9d11c7  pop r9
00007b1fbf9d11c9  pop r8
00007b1fbf9d11cb  pop rsi
00007b1fbf9d11cc  pop rdi
00007b1fbf9d11cd  pop rdx
00007b1fbf9d11ce  pop rcx
00007b1fbf9d11cf  pop rax
00007b1fbf9d11d0  add rsp, 0x08
00007b1fbf9d11d4  jmp 0x00007B1FBF9CF75E
00007b1fbf9d11d9  call 0x00007B1FBF7FF430
00007b1fbf9d11de  jmp 0x00007B1FBF9CF7EE
00007b1fbf9d11e3  call 0x00007B1FBF7FF430
00007b1fbf9d11e8  jmp 0x00007B1FBF9CF801
00007b1fbf9d11ed  sub rsp, 0x08
00007b1fbf9d11f1  push rax
00007b1fbf9d11f2  push rcx
00007b1fbf9d11f3  push rdx
00007b1fbf9d11f4  push rdi
00007b1fbf9d11f5  push rsi
00007b1fbf9d11f6  push r8
00007b1fbf9d11f8  push r9
00007b1fbf9d11fa  push r10
00007b1fbf9d11fc  push r11
00007b1fbf9d11fe  sub rsp, 0xF0
00007b1fbf9d1205  vmovaps [rsp], xmm0
00007b1fbf9d120a  vmovaps [rsp+0x10], xmm2
00007b1fbf9d1210  vmovaps [rsp+0x20], xmm3
00007b1fbf9d1216  vmovaps [rsp+0x30], xmm4
00007b1fbf9d121c  vmovaps [rsp+0x40], xmm5
00007b1fbf9d1222  vmovaps [rsp+0x50], xmm6
00007b1fbf9d1228  vmovaps [rsp+0x60], xmm7
00007b1fbf9d122e  vmovaps [rsp+0x70], xmm8
00007b1fbf9d1234  vmovaps [rsp+0x80], xmm9
00007b1fbf9d123d  vmovaps [rsp+0x90], xmm10
00007b1fbf9d1246  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d124f  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d1258  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d1261  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d126a  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d1273  sub rsp, 0x30
00007b1fbf9d1277  movaps [rsp], xmm1
00007b1fbf9d127b  movaps [rsp+0x10], xmm13
00007b1fbf9d1281  movaps [rsp+0x20], xmm2
00007b1fbf9d1286  lea rdi, [rsp]
00007b1fbf9d128a  mov esi, 0x00
00007b1fbf9d128f  mov rax, 0x64AEE5F12530
00007b1fbf9d1299  call rax
00007b1fbf9d129b  movaps xmm1, [rsp]
00007b1fbf9d129f  add rsp, 0x30
00007b1fbf9d12a3  vmovaps xmm0, [rsp]
00007b1fbf9d12a8  vmovaps xmm2, [rsp+0x10]
00007b1fbf9d12ae  vmovaps xmm3, [rsp+0x20]
00007b1fbf9d12b4  vmovaps xmm4, [rsp+0x30]
00007b1fbf9d12ba  vmovaps xmm5, [rsp+0x40]
00007b1fbf9d12c0  vmovaps xmm6, [rsp+0x50]
00007b1fbf9d12c6  vmovaps xmm7, [rsp+0x60]
00007b1fbf9d12cc  vmovaps xmm8, [rsp+0x70]
00007b1fbf9d12d2  vmovaps xmm9, [rsp+0x80]
00007b1fbf9d12db  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d12e4  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d12ed  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d12f6  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d12ff  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d1308  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d1311  add rsp, 0xF0
00007b1fbf9d1318  pop r11
00007b1fbf9d131a  pop r10
00007b1fbf9d131c  pop r9
00007b1fbf9d131e  pop r8
00007b1fbf9d1320  pop rsi
00007b1fbf9d1321  pop rdi
00007b1fbf9d1322  pop rdx
00007b1fbf9d1323  pop rcx
00007b1fbf9d1324  pop rax
00007b1fbf9d1325  add rsp, 0x08
00007b1fbf9d1329  jmp 0x00007B1FBF9CF82C
00007b1fbf9d132e  call 0x00007B1FBF80E760
00007b1fbf9d1333  jmp 0x00007B1FBF9CF839
00007b1fbf9d1338  sub rsp, 0x08
00007b1fbf9d133c  push rax
00007b1fbf9d133d  push rcx
00007b1fbf9d133e  push rdx
00007b1fbf9d133f  push rdi
00007b1fbf9d1340  push rsi
00007b1fbf9d1341  push r8
00007b1fbf9d1343  push r9
00007b1fbf9d1345  push r10
00007b1fbf9d1347  push r11
00007b1fbf9d1349  sub rsp, 0xF0
00007b1fbf9d1350  vmovaps [rsp], xmm0
00007b1fbf9d1355  vmovaps [rsp+0x10], xmm1
00007b1fbf9d135b  vmovaps [rsp+0x20], xmm2
00007b1fbf9d1361  vmovaps [rsp+0x30], xmm3
00007b1fbf9d1367  vmovaps [rsp+0x40], xmm4
00007b1fbf9d136d  vmovaps [rsp+0x50], xmm5
00007b1fbf9d1373  vmovaps [rsp+0x60], xmm6
00007b1fbf9d1379  vmovaps [rsp+0x70], xmm7
00007b1fbf9d137f  vmovaps [rsp+0x80], xmm8
00007b1fbf9d1388  vmovaps [rsp+0x90], xmm9
00007b1fbf9d1391  vmovaps [rsp+0xA0], xmm10
00007b1fbf9d139a  vmovaps [rsp+0xB0], xmm11
00007b1fbf9d13a3  vmovaps [rsp+0xC0], xmm12
00007b1fbf9d13ac  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d13b5  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d13be  sub rsp, 0x30
00007b1fbf9d13c2  movaps [rsp], xmm13
00007b1fbf9d13c7  movaps [rsp+0x10], xmm2
00007b1fbf9d13cc  movaps [rsp+0x20], xmm1
00007b1fbf9d13d1  lea rdi, [rsp]
00007b1fbf9d13d5  mov esi, 0x00
00007b1fbf9d13da  mov rax, 0x64AEE5F12530
00007b1fbf9d13e4  call rax
00007b1fbf9d13e6  movaps xmm13, [rsp]
00007b1fbf9d13eb  add rsp, 0x30
00007b1fbf9d13ef  vmovaps xmm0, [rsp]
00007b1fbf9d13f4  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d13fa  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d1400  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d1406  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d140c  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d1412  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d1418  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d141e  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d1427  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d1430  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9d1439  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9d1442  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9d144b  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d1454  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d145d  add rsp, 0xF0
00007b1fbf9d1464  pop r11
00007b1fbf9d1466  pop r10
00007b1fbf9d1468  pop r9
00007b1fbf9d146a  pop r8
00007b1fbf9d146c  pop rsi
00007b1fbf9d146d  pop rdi
00007b1fbf9d146e  pop rdx
00007b1fbf9d146f  pop rcx
00007b1fbf9d1470  pop rax
00007b1fbf9d1471  add rsp, 0x08
00007b1fbf9d1475  jmp 0x00007B1FBF9CF878
00007b1fbf9d147a  sub rsp, 0x08
00007b1fbf9d147e  push rax
00007b1fbf9d147f  push rcx
00007b1fbf9d1480  push rdx
00007b1fbf9d1481  push rdi
00007b1fbf9d1482  push rsi
00007b1fbf9d1483  push r8
00007b1fbf9d1485  push r9
00007b1fbf9d1487  push r10
00007b1fbf9d1489  push r11
00007b1fbf9d148b  sub rsp, 0xF0
00007b1fbf9d1492  vmovaps [rsp], xmm0
00007b1fbf9d1497  vmovaps [rsp+0x10], xmm2
00007b1fbf9d149d  vmovaps [rsp+0x20], xmm3
00007b1fbf9d14a3  vmovaps [rsp+0x30], xmm4
00007b1fbf9d14a9  vmovaps [rsp+0x40], xmm5
00007b1fbf9d14af  vmovaps [rsp+0x50], xmm6
00007b1fbf9d14b5  vmovaps [rsp+0x60], xmm7
00007b1fbf9d14bb  vmovaps [rsp+0x70], xmm8
00007b1fbf9d14c1  vmovaps [rsp+0x80], xmm9
00007b1fbf9d14ca  vmovaps [rsp+0x90], xmm10
00007b1fbf9d14d3  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d14dc  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d14e5  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d14ee  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d14f7  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d1500  sub rsp, 0x30
00007b1fbf9d1504  movaps [rsp], xmm1
00007b1fbf9d1508  movaps [rsp+0x10], xmm15
00007b1fbf9d150e  movaps [rsp+0x20], xmm2
00007b1fbf9d1513  lea rdi, [rsp]
00007b1fbf9d1517  mov esi, 0x00
00007b1fbf9d151c  mov rax, 0x64AEE5F12530
00007b1fbf9d1526  call rax
00007b1fbf9d1528  movaps xmm1, [rsp]
00007b1fbf9d152c  add rsp, 0x30
00007b1fbf9d1530  vmovaps xmm0, [rsp]
00007b1fbf9d1535  vmovaps xmm2, [rsp+0x10]
00007b1fbf9d153b  vmovaps xmm3, [rsp+0x20]
00007b1fbf9d1541  vmovaps xmm4, [rsp+0x30]
00007b1fbf9d1547  vmovaps xmm5, [rsp+0x40]
00007b1fbf9d154d  vmovaps xmm6, [rsp+0x50]
00007b1fbf9d1553  vmovaps xmm7, [rsp+0x60]
00007b1fbf9d1559  vmovaps xmm8, [rsp+0x70]
00007b1fbf9d155f  vmovaps xmm9, [rsp+0x80]
00007b1fbf9d1568  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d1571  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d157a  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d1583  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d158c  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d1595  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d159e  add rsp, 0xF0
00007b1fbf9d15a5  pop r11
00007b1fbf9d15a7  pop r10
00007b1fbf9d15a9  pop r9
00007b1fbf9d15ab  pop r8
00007b1fbf9d15ad  pop rsi
00007b1fbf9d15ae  pop rdi
00007b1fbf9d15af  pop rdx
00007b1fbf9d15b0  pop rcx
00007b1fbf9d15b1  pop rax
00007b1fbf9d15b2  add rsp, 0x08
00007b1fbf9d15b6  jmp 0x00007B1FBF9CF8AC
00007b1fbf9d15bb  sub rsp, 0x08
00007b1fbf9d15bf  push rax
00007b1fbf9d15c0  push rcx
00007b1fbf9d15c1  push rdx
00007b1fbf9d15c2  push rdi
00007b1fbf9d15c3  push rsi
00007b1fbf9d15c4  push r8
00007b1fbf9d15c6  push r9
00007b1fbf9d15c8  push r10
00007b1fbf9d15ca  push r11
00007b1fbf9d15cc  sub rsp, 0xF0
00007b1fbf9d15d3  vmovaps [rsp], xmm0
00007b1fbf9d15d8  vmovaps [rsp+0x10], xmm1
00007b1fbf9d15de  vmovaps [rsp+0x20], xmm2
00007b1fbf9d15e4  vmovaps [rsp+0x30], xmm3
00007b1fbf9d15ea  vmovaps [rsp+0x40], xmm4
00007b1fbf9d15f0  vmovaps [rsp+0x50], xmm5
00007b1fbf9d15f6  vmovaps [rsp+0x60], xmm6
00007b1fbf9d15fc  vmovaps [rsp+0x70], xmm7
00007b1fbf9d1602  vmovaps [rsp+0x80], xmm8
00007b1fbf9d160b  vmovaps [rsp+0x90], xmm9
00007b1fbf9d1614  vmovaps [rsp+0xA0], xmm10
00007b1fbf9d161d  vmovaps [rsp+0xB0], xmm11
00007b1fbf9d1626  vmovaps [rsp+0xC0], xmm12
00007b1fbf9d162f  vmovaps [rsp+0xD0], xmm13
00007b1fbf9d1638  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d1641  sub rsp, 0x30
00007b1fbf9d1645  movaps [rsp], xmm14
00007b1fbf9d164a  movaps [rsp+0x10], xmm2
00007b1fbf9d164f  movaps [rsp+0x20], xmm15
00007b1fbf9d1655  lea rdi, [rsp]
00007b1fbf9d1659  mov esi, 0x00
00007b1fbf9d165e  mov rax, 0x64AEE5F12530
00007b1fbf9d1668  call rax
00007b1fbf9d166a  movaps xmm14, [rsp]
00007b1fbf9d166f  add rsp, 0x30
00007b1fbf9d1673  vmovaps xmm0, [rsp]
00007b1fbf9d1678  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d167e  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d1684  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d168a  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d1690  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d1696  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d169c  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d16a2  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d16ab  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d16b4  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9d16bd  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9d16c6  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9d16cf  vmovaps xmm13, [rsp+0xD0]
00007b1fbf9d16d8  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d16e1  add rsp, 0xF0
00007b1fbf9d16e8  pop r11
00007b1fbf9d16ea  pop r10
00007b1fbf9d16ec  pop r9
00007b1fbf9d16ee  pop r8
00007b1fbf9d16f0  pop rsi
00007b1fbf9d16f1  pop rdi
00007b1fbf9d16f2  pop rdx
00007b1fbf9d16f3  pop rcx
00007b1fbf9d16f4  pop rax
00007b1fbf9d16f5  add rsp, 0x08
00007b1fbf9d16f9  jmp 0x00007B1FBF9CF8E7
00007b1fbf9d16fe  sub rsp, 0x08
00007b1fbf9d1702  push rax
00007b1fbf9d1703  push rcx
00007b1fbf9d1704  push rdx
00007b1fbf9d1705  push rdi
00007b1fbf9d1706  push rsi
00007b1fbf9d1707  push r8
00007b1fbf9d1709  push r9
00007b1fbf9d170b  push r10
00007b1fbf9d170d  push r11
00007b1fbf9d170f  sub rsp, 0xF0
00007b1fbf9d1716  vmovaps [rsp], xmm0
00007b1fbf9d171b  vmovaps [rsp+0x10], xmm1
00007b1fbf9d1721  vmovaps [rsp+0x20], xmm2
00007b1fbf9d1727  vmovaps [rsp+0x30], xmm3
00007b1fbf9d172d  vmovaps [rsp+0x40], xmm4
00007b1fbf9d1733  vmovaps [rsp+0x50], xmm5
00007b1fbf9d1739  vmovaps [rsp+0x60], xmm6
00007b1fbf9d173f  vmovaps [rsp+0x70], xmm7
00007b1fbf9d1745  vmovaps [rsp+0x80], xmm8
00007b1fbf9d174e  vmovaps [rsp+0x90], xmm9
00007b1fbf9d1757  vmovaps [rsp+0xA0], xmm10
00007b1fbf9d1760  vmovaps [rsp+0xB0], xmm11
00007b1fbf9d1769  vmovaps [rsp+0xC0], xmm12
00007b1fbf9d1772  vmovaps [rsp+0xD0], xmm13
00007b1fbf9d177b  vmovaps [rsp+0xE0], xmm14
00007b1fbf9d1784  sub rsp, 0x30
00007b1fbf9d1788  movaps [rsp], xmm15
00007b1fbf9d178d  movaps [rsp+0x10], xmm2
00007b1fbf9d1792  movaps [rsp+0x20], xmm1
00007b1fbf9d1797  lea rdi, [rsp]
00007b1fbf9d179b  mov esi, 0x00
00007b1fbf9d17a0  mov rax, 0x64AEE5F12530
00007b1fbf9d17aa  call rax
00007b1fbf9d17ac  movaps xmm15, [rsp]
00007b1fbf9d17b1  add rsp, 0x30
00007b1fbf9d17b5  vmovaps xmm0, [rsp]
00007b1fbf9d17ba  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d17c0  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d17c6  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d17cc  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d17d2  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d17d8  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d17de  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d17e4  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d17ed  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d17f6  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9d17ff  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9d1808  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9d1811  vmovaps xmm13, [rsp+0xD0]
00007b1fbf9d181a  vmovaps xmm14, [rsp+0xE0]
00007b1fbf9d1823  add rsp, 0xF0
00007b1fbf9d182a  pop r11
00007b1fbf9d182c  pop r10
00007b1fbf9d182e  pop r9
00007b1fbf9d1830  pop r8
00007b1fbf9d1832  pop rsi
00007b1fbf9d1833  pop rdi
00007b1fbf9d1834  pop rdx
00007b1fbf9d1835  pop rcx
00007b1fbf9d1836  pop rax
00007b1fbf9d1837  add rsp, 0x08
00007b1fbf9d183b  jmp 0x00007B1FBF9CF923
00007b1fbf9d1840  call 0x00007B1FBF7FF430
00007b1fbf9d1845  jmp 0x00007B1FBF9CF930
00007b1fbf9d184a  sub rsp, 0x08
00007b1fbf9d184e  push rax
00007b1fbf9d184f  push rcx
00007b1fbf9d1850  push rdx
00007b1fbf9d1851  push rdi
00007b1fbf9d1852  push rsi
00007b1fbf9d1853  push r8
00007b1fbf9d1855  push r9
00007b1fbf9d1857  push r10
00007b1fbf9d1859  push r11
00007b1fbf9d185b  sub rsp, 0xF0
00007b1fbf9d1862  vmovaps [rsp], xmm0
00007b1fbf9d1867  vmovaps [rsp+0x10], xmm1
00007b1fbf9d186d  vmovaps [rsp+0x20], xmm3
00007b1fbf9d1873  vmovaps [rsp+0x30], xmm4
00007b1fbf9d1879  vmovaps [rsp+0x40], xmm5
00007b1fbf9d187f  vmovaps [rsp+0x50], xmm6
00007b1fbf9d1885  vmovaps [rsp+0x60], xmm7
00007b1fbf9d188b  vmovaps [rsp+0x70], xmm8
00007b1fbf9d1891  vmovaps [rsp+0x80], xmm9
00007b1fbf9d189a  vmovaps [rsp+0x90], xmm10
00007b1fbf9d18a3  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d18ac  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d18b5  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d18be  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d18c7  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d18d0  sub rsp, 0x30
00007b1fbf9d18d4  movaps [rsp], xmm2
00007b1fbf9d18d8  movaps [rsp+0x10], xmm1
00007b1fbf9d18dd  movaps [rsp+0x20], xmm14
00007b1fbf9d18e3  lea rdi, [rsp]
00007b1fbf9d18e7  mov esi, 0x00
00007b1fbf9d18ec  mov rax, 0x64AEE5F12530
00007b1fbf9d18f6  call rax
00007b1fbf9d18f8  movaps xmm2, [rsp]
00007b1fbf9d18fc  add rsp, 0x30
00007b1fbf9d1900  vmovaps xmm0, [rsp]
00007b1fbf9d1905  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d190b  vmovaps xmm3, [rsp+0x20]
00007b1fbf9d1911  vmovaps xmm4, [rsp+0x30]
00007b1fbf9d1917  vmovaps xmm5, [rsp+0x40]
00007b1fbf9d191d  vmovaps xmm6, [rsp+0x50]
00007b1fbf9d1923  vmovaps xmm7, [rsp+0x60]
00007b1fbf9d1929  vmovaps xmm8, [rsp+0x70]
00007b1fbf9d192f  vmovaps xmm9, [rsp+0x80]
00007b1fbf9d1938  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d1941  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d194a  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d1953  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d195c  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d1965  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d196e  add rsp, 0xF0
00007b1fbf9d1975  pop r11
00007b1fbf9d1977  pop r10
00007b1fbf9d1979  pop r9
00007b1fbf9d197b  pop r8
00007b1fbf9d197d  pop rsi
00007b1fbf9d197e  pop rdi
00007b1fbf9d197f  pop rdx
00007b1fbf9d1980  pop rcx
00007b1fbf9d1981  pop rax
00007b1fbf9d1982  add rsp, 0x08
00007b1fbf9d1986  jmp 0x00007B1FBF9CF96D
00007b1fbf9d198b  sub rsp, 0x08
00007b1fbf9d198f  push rax
00007b1fbf9d1990  push rcx
00007b1fbf9d1991  push rdx
00007b1fbf9d1992  push rdi
00007b1fbf9d1993  push rsi
00007b1fbf9d1994  push r8
00007b1fbf9d1996  push r9
00007b1fbf9d1998  push r10
00007b1fbf9d199a  push r11
00007b1fbf9d199c  sub rsp, 0xF0
00007b1fbf9d19a3  vmovaps [rsp], xmm0
00007b1fbf9d19a8  vmovaps [rsp+0x10], xmm1
00007b1fbf9d19ae  vmovaps [rsp+0x20], xmm2
00007b1fbf9d19b4  vmovaps [rsp+0x30], xmm3
00007b1fbf9d19ba  vmovaps [rsp+0x40], xmm4
00007b1fbf9d19c0  vmovaps [rsp+0x50], xmm5
00007b1fbf9d19c6  vmovaps [rsp+0x60], xmm6
00007b1fbf9d19cc  vmovaps [rsp+0x70], xmm7
00007b1fbf9d19d2  vmovaps [rsp+0x80], xmm8
00007b1fbf9d19db  vmovaps [rsp+0x90], xmm9
00007b1fbf9d19e4  vmovaps [rsp+0xA0], xmm10
00007b1fbf9d19ed  vmovaps [rsp+0xB0], xmm11
00007b1fbf9d19f6  vmovaps [rsp+0xC0], xmm12
00007b1fbf9d19ff  vmovaps [rsp+0xD0], xmm13
00007b1fbf9d1a08  vmovaps [rsp+0xE0], xmm14
00007b1fbf9d1a11  sub rsp, 0x30
00007b1fbf9d1a15  movaps [rsp], xmm15
00007b1fbf9d1a1a  movaps [rsp+0x10], xmm14
00007b1fbf9d1a20  movaps [rsp+0x20], xmm1
00007b1fbf9d1a25  lea rdi, [rsp]
00007b1fbf9d1a29  mov esi, 0x00
00007b1fbf9d1a2e  mov rax, 0x64AEE5F12530
00007b1fbf9d1a38  call rax
00007b1fbf9d1a3a  movaps xmm15, [rsp]
00007b1fbf9d1a3f  add rsp, 0x30
00007b1fbf9d1a43  vmovaps xmm0, [rsp]
00007b1fbf9d1a48  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d1a4e  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d1a54  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d1a5a  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d1a60  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d1a66  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d1a6c  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d1a72  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d1a7b  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d1a84  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9d1a8d  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9d1a96  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9d1a9f  vmovaps xmm13, [rsp+0xD0]
00007b1fbf9d1aa8  vmovaps xmm14, [rsp+0xE0]
00007b1fbf9d1ab1  add rsp, 0xF0
00007b1fbf9d1ab8  pop r11
00007b1fbf9d1aba  pop r10
00007b1fbf9d1abc  pop r9
00007b1fbf9d1abe  pop r8
00007b1fbf9d1ac0  pop rsi
00007b1fbf9d1ac1  pop rdi
00007b1fbf9d1ac2  pop rdx
00007b1fbf9d1ac3  pop rcx
00007b1fbf9d1ac4  pop rax
00007b1fbf9d1ac5  add rsp, 0x08
00007b1fbf9d1ac9  jmp 0x00007B1FBF9CF9E7
00007b1fbf9d1ace  call 0x00007B1FBF7FF430
00007b1fbf9d1ad3  jmp 0x00007B1FBF9CF9F4
00007b1fbf9d1ad8  sub rsp, 0x08
00007b1fbf9d1adc  push rax
00007b1fbf9d1add  push rcx
00007b1fbf9d1ade  push rdx
00007b1fbf9d1adf  push rdi
00007b1fbf9d1ae0  push rsi
00007b1fbf9d1ae1  push r8
00007b1fbf9d1ae3  push r9
00007b1fbf9d1ae5  push r10
00007b1fbf9d1ae7  push r11
00007b1fbf9d1ae9  sub rsp, 0xF0
00007b1fbf9d1af0  vmovaps [rsp], xmm0
00007b1fbf9d1af5  vmovaps [rsp+0x10], xmm1
00007b1fbf9d1afb  vmovaps [rsp+0x20], xmm2
00007b1fbf9d1b01  vmovaps [rsp+0x30], xmm3
00007b1fbf9d1b07  vmovaps [rsp+0x40], xmm4
00007b1fbf9d1b0d  vmovaps [rsp+0x50], xmm5
00007b1fbf9d1b13  vmovaps [rsp+0x60], xmm6
00007b1fbf9d1b19  vmovaps [rsp+0x70], xmm7
00007b1fbf9d1b1f  vmovaps [rsp+0x80], xmm8
00007b1fbf9d1b28  vmovaps [rsp+0x90], xmm9
00007b1fbf9d1b31  vmovaps [rsp+0xA0], xmm10
00007b1fbf9d1b3a  vmovaps [rsp+0xB0], xmm11
00007b1fbf9d1b43  vmovaps [rsp+0xC0], xmm12
00007b1fbf9d1b4c  vmovaps [rsp+0xD0], xmm13
00007b1fbf9d1b55  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d1b5e  sub rsp, 0x30
00007b1fbf9d1b62  movaps [rsp], xmm14
00007b1fbf9d1b67  movaps [rsp+0x10], xmm13
00007b1fbf9d1b6d  movaps [rsp+0x20], xmm1
00007b1fbf9d1b72  lea rdi, [rsp]
00007b1fbf9d1b76  mov esi, 0x00
00007b1fbf9d1b7b  mov rax, 0x64AEE5F12530
00007b1fbf9d1b85  call rax
00007b1fbf9d1b87  movaps xmm14, [rsp]
00007b1fbf9d1b8c  add rsp, 0x30
00007b1fbf9d1b90  vmovaps xmm0, [rsp]
00007b1fbf9d1b95  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d1b9b  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d1ba1  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d1ba7  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d1bad  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d1bb3  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d1bb9  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d1bbf  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d1bc8  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d1bd1  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9d1bda  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9d1be3  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9d1bec  vmovaps xmm13, [rsp+0xD0]
00007b1fbf9d1bf5  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d1bfe  add rsp, 0xF0
00007b1fbf9d1c05  pop r11
00007b1fbf9d1c07  pop r10
00007b1fbf9d1c09  pop r9
00007b1fbf9d1c0b  pop r8
00007b1fbf9d1c0d  pop rsi
00007b1fbf9d1c0e  pop rdi
00007b1fbf9d1c0f  pop rdx
00007b1fbf9d1c10  pop rcx
00007b1fbf9d1c11  pop rax
00007b1fbf9d1c12  add rsp, 0x08
00007b1fbf9d1c16  jmp 0x00007B1FBF9CFAAF
00007b1fbf9d1c1b  sub rsp, 0x08
00007b1fbf9d1c1f  push rax
00007b1fbf9d1c20  push rcx
00007b1fbf9d1c21  push rdx
00007b1fbf9d1c22  push rdi
00007b1fbf9d1c23  push rsi
00007b1fbf9d1c24  push r8
00007b1fbf9d1c26  push r9
00007b1fbf9d1c28  push r10
00007b1fbf9d1c2a  push r11
00007b1fbf9d1c2c  sub rsp, 0xF0
00007b1fbf9d1c33  vmovaps [rsp], xmm0
00007b1fbf9d1c38  vmovaps [rsp+0x10], xmm1
00007b1fbf9d1c3e  vmovaps [rsp+0x20], xmm2
00007b1fbf9d1c44  vmovaps [rsp+0x30], xmm3
00007b1fbf9d1c4a  vmovaps [rsp+0x40], xmm4
00007b1fbf9d1c50  vmovaps [rsp+0x50], xmm5
00007b1fbf9d1c56  vmovaps [rsp+0x60], xmm6
00007b1fbf9d1c5c  vmovaps [rsp+0x70], xmm7
00007b1fbf9d1c62  vmovaps [rsp+0x80], xmm8
00007b1fbf9d1c6b  vmovaps [rsp+0x90], xmm9
00007b1fbf9d1c74  vmovaps [rsp+0xA0], xmm10
00007b1fbf9d1c7d  vmovaps [rsp+0xB0], xmm11
00007b1fbf9d1c86  vmovaps [rsp+0xC0], xmm12
00007b1fbf9d1c8f  vmovaps [rsp+0xD0], xmm13
00007b1fbf9d1c98  vmovaps [rsp+0xE0], xmm14
00007b1fbf9d1ca1  sub rsp, 0x30
00007b1fbf9d1ca5  movaps [rsp], xmm15
00007b1fbf9d1caa  movaps [rsp+0x10], xmm13
00007b1fbf9d1cb0  movaps [rsp+0x20], xmm1
00007b1fbf9d1cb5  lea rdi, [rsp]
00007b1fbf9d1cb9  mov esi, 0x00
00007b1fbf9d1cbe  mov rax, 0x64AEE5F12530
00007b1fbf9d1cc8  call rax
00007b1fbf9d1cca  movaps xmm15, [rsp]
00007b1fbf9d1ccf  add rsp, 0x30
00007b1fbf9d1cd3  vmovaps xmm0, [rsp]
00007b1fbf9d1cd8  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d1cde  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d1ce4  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d1cea  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d1cf0  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d1cf6  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d1cfc  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d1d02  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d1d0b  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d1d14  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9d1d1d  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9d1d26  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9d1d2f  vmovaps xmm13, [rsp+0xD0]
00007b1fbf9d1d38  vmovaps xmm14, [rsp+0xE0]
00007b1fbf9d1d41  add rsp, 0xF0
00007b1fbf9d1d48  pop r11
00007b1fbf9d1d4a  pop r10
00007b1fbf9d1d4c  pop r9
00007b1fbf9d1d4e  pop r8
00007b1fbf9d1d50  pop rsi
00007b1fbf9d1d51  pop rdi
00007b1fbf9d1d52  pop rdx
00007b1fbf9d1d53  pop rcx
00007b1fbf9d1d54  pop rax
00007b1fbf9d1d55  add rsp, 0x08
00007b1fbf9d1d59  jmp 0x00007B1FBF9CFAEB
00007b1fbf9d1d5e  call 0x00007B1FBF7FF430
00007b1fbf9d1d63  jmp 0x00007B1FBF9CFAF8
00007b1fbf9d1d68  sub rsp, 0x08
00007b1fbf9d1d6c  push rax
00007b1fbf9d1d6d  push rcx
00007b1fbf9d1d6e  push rdx
00007b1fbf9d1d6f  push rdi
00007b1fbf9d1d70  push rsi
00007b1fbf9d1d71  push r8
00007b1fbf9d1d73  push r9
00007b1fbf9d1d75  push r10
00007b1fbf9d1d77  push r11
00007b1fbf9d1d79  sub rsp, 0xF0
00007b1fbf9d1d80  vmovaps [rsp], xmm0
00007b1fbf9d1d85  vmovaps [rsp+0x10], xmm1
00007b1fbf9d1d8b  vmovaps [rsp+0x20], xmm2
00007b1fbf9d1d91  vmovaps [rsp+0x30], xmm3
00007b1fbf9d1d97  vmovaps [rsp+0x40], xmm4
00007b1fbf9d1d9d  vmovaps [rsp+0x50], xmm5
00007b1fbf9d1da3  vmovaps [rsp+0x60], xmm6
00007b1fbf9d1da9  vmovaps [rsp+0x70], xmm7
00007b1fbf9d1daf  vmovaps [rsp+0x80], xmm8
00007b1fbf9d1db8  vmovaps [rsp+0x90], xmm9
00007b1fbf9d1dc1  vmovaps [rsp+0xA0], xmm10
00007b1fbf9d1dca  vmovaps [rsp+0xB0], xmm11
00007b1fbf9d1dd3  vmovaps [rsp+0xC0], xmm12
00007b1fbf9d1ddc  vmovaps [rsp+0xD0], xmm13
00007b1fbf9d1de5  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d1dee  sub rsp, 0x30
00007b1fbf9d1df2  movaps [rsp], xmm14
00007b1fbf9d1df7  movaps [rsp+0x10], xmm13
00007b1fbf9d1dfd  movaps [rsp+0x20], xmm2
00007b1fbf9d1e02  lea rdi, [rsp]
00007b1fbf9d1e06  mov esi, 0x00
00007b1fbf9d1e0b  mov rax, 0x64AEE5F12530
00007b1fbf9d1e15  call rax
00007b1fbf9d1e17  movaps xmm14, [rsp]
00007b1fbf9d1e1c  add rsp, 0x30
00007b1fbf9d1e20  vmovaps xmm0, [rsp]
00007b1fbf9d1e25  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d1e2b  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d1e31  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d1e37  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d1e3d  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d1e43  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d1e49  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d1e4f  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d1e58  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d1e61  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9d1e6a  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9d1e73  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9d1e7c  vmovaps xmm13, [rsp+0xD0]
00007b1fbf9d1e85  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d1e8e  add rsp, 0xF0
00007b1fbf9d1e95  pop r11
00007b1fbf9d1e97  pop r10
00007b1fbf9d1e99  pop r9
00007b1fbf9d1e9b  pop r8
00007b1fbf9d1e9d  pop rsi
00007b1fbf9d1e9e  pop rdi
00007b1fbf9d1e9f  pop rdx
00007b1fbf9d1ea0  pop rcx
00007b1fbf9d1ea1  pop rax
00007b1fbf9d1ea2  add rsp, 0x08
00007b1fbf9d1ea6  jmp 0x00007B1FBF9CFB24
00007b1fbf9d1eab  sub rsp, 0x08
00007b1fbf9d1eaf  push rax
00007b1fbf9d1eb0  push rcx
00007b1fbf9d1eb1  push rdx
00007b1fbf9d1eb2  push rdi
00007b1fbf9d1eb3  push rsi
00007b1fbf9d1eb4  push r8
00007b1fbf9d1eb6  push r9
00007b1fbf9d1eb8  push r10
00007b1fbf9d1eba  push r11
00007b1fbf9d1ebc  sub rsp, 0xF0
00007b1fbf9d1ec3  vmovaps [rsp], xmm0
00007b1fbf9d1ec8  vmovaps [rsp+0x10], xmm2
00007b1fbf9d1ece  vmovaps [rsp+0x20], xmm3
00007b1fbf9d1ed4  vmovaps [rsp+0x30], xmm4
00007b1fbf9d1eda  vmovaps [rsp+0x40], xmm5
00007b1fbf9d1ee0  vmovaps [rsp+0x50], xmm6
00007b1fbf9d1ee6  vmovaps [rsp+0x60], xmm7
00007b1fbf9d1eec  vmovaps [rsp+0x70], xmm8
00007b1fbf9d1ef2  vmovaps [rsp+0x80], xmm9
00007b1fbf9d1efb  vmovaps [rsp+0x90], xmm10
00007b1fbf9d1f04  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d1f0d  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d1f16  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d1f1f  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d1f28  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d1f31  sub rsp, 0x30
00007b1fbf9d1f35  movaps [rsp], xmm1
00007b1fbf9d1f39  movaps [rsp+0x10], xmm13
00007b1fbf9d1f3f  movaps [rsp+0x20], xmm2
00007b1fbf9d1f44  lea rdi, [rsp]
00007b1fbf9d1f48  mov esi, 0x00
00007b1fbf9d1f4d  mov rax, 0x64AEE5F12530
00007b1fbf9d1f57  call rax
00007b1fbf9d1f59  movaps xmm1, [rsp]
00007b1fbf9d1f5d  add rsp, 0x30
00007b1fbf9d1f61  vmovaps xmm0, [rsp]
00007b1fbf9d1f66  vmovaps xmm2, [rsp+0x10]
00007b1fbf9d1f6c  vmovaps xmm3, [rsp+0x20]
00007b1fbf9d1f72  vmovaps xmm4, [rsp+0x30]
00007b1fbf9d1f78  vmovaps xmm5, [rsp+0x40]
00007b1fbf9d1f7e  vmovaps xmm6, [rsp+0x50]
00007b1fbf9d1f84  vmovaps xmm7, [rsp+0x60]
00007b1fbf9d1f8a  vmovaps xmm8, [rsp+0x70]
00007b1fbf9d1f90  vmovaps xmm9, [rsp+0x80]
00007b1fbf9d1f99  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d1fa2  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d1fab  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d1fb4  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d1fbd  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d1fc6  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d1fcf  add rsp, 0xF0
00007b1fbf9d1fd6  pop r11
00007b1fbf9d1fd8  pop r10
00007b1fbf9d1fda  pop r9
00007b1fbf9d1fdc  pop r8
00007b1fbf9d1fde  pop rsi
00007b1fbf9d1fdf  pop rdi
00007b1fbf9d1fe0  pop rdx
00007b1fbf9d1fe1  pop rcx
00007b1fbf9d1fe2  pop rax
00007b1fbf9d1fe3  add rsp, 0x08
00007b1fbf9d1fe7  jmp 0x00007B1FBF9CFB52
00007b1fbf9d1fec  sub rsp, 0x08
00007b1fbf9d1ff0  push rax
00007b1fbf9d1ff1  push rcx
00007b1fbf9d1ff2  push rdx
00007b1fbf9d1ff3  push rdi
00007b1fbf9d1ff4  push rsi
00007b1fbf9d1ff5  push r8
00007b1fbf9d1ff7  push r9
00007b1fbf9d1ff9  push r10
00007b1fbf9d1ffb  push r11
00007b1fbf9d1ffd  sub rsp, 0xF0
00007b1fbf9d2004  vmovaps [rsp], xmm0
00007b1fbf9d2009  vmovaps [rsp+0x10], xmm1
00007b1fbf9d200f  vmovaps [rsp+0x20], xmm3
00007b1fbf9d2015  vmovaps [rsp+0x30], xmm4
00007b1fbf9d201b  vmovaps [rsp+0x40], xmm5
00007b1fbf9d2021  vmovaps [rsp+0x50], xmm6
00007b1fbf9d2027  vmovaps [rsp+0x60], xmm7
00007b1fbf9d202d  vmovaps [rsp+0x70], xmm8
00007b1fbf9d2033  vmovaps [rsp+0x80], xmm9
00007b1fbf9d203c  vmovaps [rsp+0x90], xmm10
00007b1fbf9d2045  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d204e  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d2057  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d2060  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d2069  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d2072  sub rsp, 0x30
00007b1fbf9d2076  movaps [rsp], xmm2
00007b1fbf9d207a  movaps [rsp+0x10], xmm1
00007b1fbf9d207f  movaps [rsp+0x20], xmm13
00007b1fbf9d2085  lea rdi, [rsp]
00007b1fbf9d2089  mov esi, 0x00
00007b1fbf9d208e  mov rax, 0x64AEE5F12530
00007b1fbf9d2098  call rax
00007b1fbf9d209a  movaps xmm2, [rsp]
00007b1fbf9d209e  add rsp, 0x30
00007b1fbf9d20a2  vmovaps xmm0, [rsp]
00007b1fbf9d20a7  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d20ad  vmovaps xmm3, [rsp+0x20]
00007b1fbf9d20b3  vmovaps xmm4, [rsp+0x30]
00007b1fbf9d20b9  vmovaps xmm5, [rsp+0x40]
00007b1fbf9d20bf  vmovaps xmm6, [rsp+0x50]
00007b1fbf9d20c5  vmovaps xmm7, [rsp+0x60]
00007b1fbf9d20cb  vmovaps xmm8, [rsp+0x70]
00007b1fbf9d20d1  vmovaps xmm9, [rsp+0x80]
00007b1fbf9d20da  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d20e3  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d20ec  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d20f5  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d20fe  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d2107  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d2110  add rsp, 0xF0
00007b1fbf9d2117  pop r11
00007b1fbf9d2119  pop r10
00007b1fbf9d211b  pop r9
00007b1fbf9d211d  pop r8
00007b1fbf9d211f  pop rsi
00007b1fbf9d2120  pop rdi
00007b1fbf9d2121  pop rdx
00007b1fbf9d2122  pop rcx
00007b1fbf9d2123  pop rax
00007b1fbf9d2124  add rsp, 0x08
00007b1fbf9d2128  jmp 0x00007B1FBF9CFBAB
00007b1fbf9d212d  call 0x00007B1FBF7FF430
00007b1fbf9d2132  jmp 0x00007B1FBF9CFBB8
00007b1fbf9d2137  sub rsp, 0x08
00007b1fbf9d213b  push rax
00007b1fbf9d213c  push rcx
00007b1fbf9d213d  push rdx
00007b1fbf9d213e  push rdi
00007b1fbf9d213f  push rsi
00007b1fbf9d2140  push r8
00007b1fbf9d2142  push r9
00007b1fbf9d2144  push r10
00007b1fbf9d2146  push r11
00007b1fbf9d2148  sub rsp, 0xF0
00007b1fbf9d214f  vmovaps [rsp], xmm0
00007b1fbf9d2154  vmovaps [rsp+0x10], xmm1
00007b1fbf9d215a  vmovaps [rsp+0x20], xmm2
00007b1fbf9d2160  vmovaps [rsp+0x30], xmm3
00007b1fbf9d2166  vmovaps [rsp+0x40], xmm4
00007b1fbf9d216c  vmovaps [rsp+0x50], xmm5
00007b1fbf9d2172  vmovaps [rsp+0x60], xmm6
00007b1fbf9d2178  vmovaps [rsp+0x70], xmm7
00007b1fbf9d217e  vmovaps [rsp+0x80], xmm8
00007b1fbf9d2187  vmovaps [rsp+0x90], xmm9
00007b1fbf9d2190  vmovaps [rsp+0xA0], xmm10
00007b1fbf9d2199  vmovaps [rsp+0xB0], xmm11
00007b1fbf9d21a2  vmovaps [rsp+0xC0], xmm12
00007b1fbf9d21ab  vmovaps [rsp+0xD0], xmm13
00007b1fbf9d21b4  vmovaps [rsp+0xE0], xmm14
00007b1fbf9d21bd  sub rsp, 0x30
00007b1fbf9d21c1  movaps [rsp], xmm15
00007b1fbf9d21c6  movaps [rsp+0x10], xmm13
00007b1fbf9d21cc  movaps [rsp+0x20], xmm1
00007b1fbf9d21d1  lea rdi, [rsp]
00007b1fbf9d21d5  mov esi, 0x00
00007b1fbf9d21da  mov rax, 0x64AEE5F12530
00007b1fbf9d21e4  call rax
00007b1fbf9d21e6  movaps xmm15, [rsp]
00007b1fbf9d21eb  add rsp, 0x30
00007b1fbf9d21ef  vmovaps xmm0, [rsp]
00007b1fbf9d21f4  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d21fa  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d2200  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d2206  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d220c  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d2212  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d2218  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d221e  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d2227  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d2230  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9d2239  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9d2242  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9d224b  vmovaps xmm13, [rsp+0xD0]
00007b1fbf9d2254  vmovaps xmm14, [rsp+0xE0]
00007b1fbf9d225d  add rsp, 0xF0
00007b1fbf9d2264  pop r11
00007b1fbf9d2266  pop r10
00007b1fbf9d2268  pop r9
00007b1fbf9d226a  pop r8
00007b1fbf9d226c  pop rsi
00007b1fbf9d226d  pop rdi
00007b1fbf9d226e  pop rdx
00007b1fbf9d226f  pop rcx
00007b1fbf9d2270  pop rax
00007b1fbf9d2271  add rsp, 0x08
00007b1fbf9d2275  jmp 0x00007B1FBF9CFBF7
00007b1fbf9d227a  sub rsp, 0x08
00007b1fbf9d227e  push rax
00007b1fbf9d227f  push rcx
00007b1fbf9d2280  push rdx
00007b1fbf9d2281  push rdi
00007b1fbf9d2282  push rsi
00007b1fbf9d2283  push r8
00007b1fbf9d2285  push r9
00007b1fbf9d2287  push r10
00007b1fbf9d2289  push r11
00007b1fbf9d228b  sub rsp, 0xF0
00007b1fbf9d2292  vmovaps [rsp], xmm0
00007b1fbf9d2297  vmovaps [rsp+0x10], xmm1
00007b1fbf9d229d  vmovaps [rsp+0x20], xmm2
00007b1fbf9d22a3  vmovaps [rsp+0x30], xmm3
00007b1fbf9d22a9  vmovaps [rsp+0x40], xmm4
00007b1fbf9d22af  vmovaps [rsp+0x50], xmm5
00007b1fbf9d22b5  vmovaps [rsp+0x60], xmm6
00007b1fbf9d22bb  vmovaps [rsp+0x70], xmm7
00007b1fbf9d22c1  vmovaps [rsp+0x80], xmm8
00007b1fbf9d22ca  vmovaps [rsp+0x90], xmm9
00007b1fbf9d22d3  vmovaps [rsp+0xA0], xmm10
00007b1fbf9d22dc  vmovaps [rsp+0xB0], xmm11
00007b1fbf9d22e5  vmovaps [rsp+0xC0], xmm12
00007b1fbf9d22ee  vmovaps [rsp+0xD0], xmm13
00007b1fbf9d22f7  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d2300  sub rsp, 0x30
00007b1fbf9d2304  movaps [rsp], xmm14
00007b1fbf9d2309  movaps [rsp+0x10], xmm11
00007b1fbf9d230f  movaps [rsp+0x20], xmm1
00007b1fbf9d2314  lea rdi, [rsp]
00007b1fbf9d2318  mov esi, 0x00
00007b1fbf9d231d  mov rax, 0x64AEE5F12530
00007b1fbf9d2327  call rax
00007b1fbf9d2329  movaps xmm14, [rsp]
00007b1fbf9d232e  add rsp, 0x30
00007b1fbf9d2332  vmovaps xmm0, [rsp]
00007b1fbf9d2337  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d233d  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d2343  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d2349  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d234f  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d2355  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d235b  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d2361  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d236a  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d2373  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9d237c  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9d2385  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9d238e  vmovaps xmm13, [rsp+0xD0]
00007b1fbf9d2397  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d23a0  add rsp, 0xF0
00007b1fbf9d23a7  pop r11
00007b1fbf9d23a9  pop r10
00007b1fbf9d23ab  pop r9
00007b1fbf9d23ad  pop r8
00007b1fbf9d23af  pop rsi
00007b1fbf9d23b0  pop rdi
00007b1fbf9d23b1  pop rdx
00007b1fbf9d23b2  pop rcx
00007b1fbf9d23b3  pop rax
00007b1fbf9d23b4  add rsp, 0x08
00007b1fbf9d23b8  jmp 0x00007B1FBF9CFC21
00007b1fbf9d23bd  sub rsp, 0x08
00007b1fbf9d23c1  push rax
00007b1fbf9d23c2  push rcx
00007b1fbf9d23c3  push rdx
00007b1fbf9d23c4  push rdi
00007b1fbf9d23c5  push rsi
00007b1fbf9d23c6  push r8
00007b1fbf9d23c8  push r9
00007b1fbf9d23ca  push r10
00007b1fbf9d23cc  push r11
00007b1fbf9d23ce  sub rsp, 0xF0
00007b1fbf9d23d5  vmovaps [rsp], xmm0
00007b1fbf9d23da  vmovaps [rsp+0x10], xmm1
00007b1fbf9d23e0  vmovaps [rsp+0x20], xmm2
00007b1fbf9d23e6  vmovaps [rsp+0x30], xmm3
00007b1fbf9d23ec  vmovaps [rsp+0x40], xmm4
00007b1fbf9d23f2  vmovaps [rsp+0x50], xmm5
00007b1fbf9d23f8  vmovaps [rsp+0x60], xmm6
00007b1fbf9d23fe  vmovaps [rsp+0x70], xmm7
00007b1fbf9d2404  vmovaps [rsp+0x80], xmm8
00007b1fbf9d240d  vmovaps [rsp+0x90], xmm9
00007b1fbf9d2416  vmovaps [rsp+0xA0], xmm10
00007b1fbf9d241f  vmovaps [rsp+0xB0], xmm11
00007b1fbf9d2428  vmovaps [rsp+0xC0], xmm12
00007b1fbf9d2431  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d243a  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d2443  sub rsp, 0x30
00007b1fbf9d2447  movaps [rsp], xmm13
00007b1fbf9d244c  movaps [rsp+0x10], xmm11
00007b1fbf9d2452  movaps [rsp+0x20], xmm1
00007b1fbf9d2457  lea rdi, [rsp]
00007b1fbf9d245b  mov esi, 0x00
00007b1fbf9d2460  mov rax, 0x64AEE5F12530
00007b1fbf9d246a  call rax
00007b1fbf9d246c  movaps xmm13, [rsp]
00007b1fbf9d2471  add rsp, 0x30
00007b1fbf9d2475  vmovaps xmm0, [rsp]
00007b1fbf9d247a  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d2480  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d2486  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d248c  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d2492  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d2498  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d249e  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d24a4  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d24ad  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d24b6  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9d24bf  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9d24c8  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9d24d1  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d24da  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d24e3  add rsp, 0xF0
00007b1fbf9d24ea  pop r11
00007b1fbf9d24ec  pop r10
00007b1fbf9d24ee  pop r9
00007b1fbf9d24f0  pop r8
00007b1fbf9d24f2  pop rsi
00007b1fbf9d24f3  pop rdi
00007b1fbf9d24f4  pop rdx
00007b1fbf9d24f5  pop rcx
00007b1fbf9d24f6  pop rax
00007b1fbf9d24f7  add rsp, 0x08
00007b1fbf9d24fb  jmp 0x00007B1FBF9CFC76
00007b1fbf9d2500  call 0x00007B1FBF7FF430
00007b1fbf9d2505  jmp 0x00007B1FBF9CFC83
00007b1fbf9d250a  sub rsp, 0x08
00007b1fbf9d250e  push rax
00007b1fbf9d250f  push rcx
00007b1fbf9d2510  push rdx
00007b1fbf9d2511  push rdi
00007b1fbf9d2512  push rsi
00007b1fbf9d2513  push r8
00007b1fbf9d2515  push r9
00007b1fbf9d2517  push r10
00007b1fbf9d2519  push r11
00007b1fbf9d251b  sub rsp, 0xF0
00007b1fbf9d2522  vmovaps [rsp], xmm0
00007b1fbf9d2527  vmovaps [rsp+0x10], xmm1
00007b1fbf9d252d  vmovaps [rsp+0x20], xmm2
00007b1fbf9d2533  vmovaps [rsp+0x30], xmm3
00007b1fbf9d2539  vmovaps [rsp+0x40], xmm4
00007b1fbf9d253f  vmovaps [rsp+0x50], xmm5
00007b1fbf9d2545  vmovaps [rsp+0x60], xmm6
00007b1fbf9d254b  vmovaps [rsp+0x70], xmm7
00007b1fbf9d2551  vmovaps [rsp+0x80], xmm8
00007b1fbf9d255a  vmovaps [rsp+0x90], xmm9
00007b1fbf9d2563  vmovaps [rsp+0xA0], xmm10
00007b1fbf9d256c  vmovaps [rsp+0xB0], xmm11
00007b1fbf9d2575  vmovaps [rsp+0xC0], xmm12
00007b1fbf9d257e  vmovaps [rsp+0xD0], xmm13
00007b1fbf9d2587  vmovaps [rsp+0xE0], xmm14
00007b1fbf9d2590  sub rsp, 0x30
00007b1fbf9d2594  movaps [rsp], xmm15
00007b1fbf9d2599  movaps [rsp+0x10], xmm11
00007b1fbf9d259f  movaps [rsp+0x20], xmm1
00007b1fbf9d25a4  lea rdi, [rsp]
00007b1fbf9d25a8  mov esi, 0x00
00007b1fbf9d25ad  mov rax, 0x64AEE5F12530
00007b1fbf9d25b7  call rax
00007b1fbf9d25b9  movaps xmm15, [rsp]
00007b1fbf9d25be  add rsp, 0x30
00007b1fbf9d25c2  vmovaps xmm0, [rsp]
00007b1fbf9d25c7  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d25cd  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d25d3  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d25d9  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d25df  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d25e5  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d25eb  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d25f1  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d25fa  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d2603  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9d260c  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9d2615  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9d261e  vmovaps xmm13, [rsp+0xD0]
00007b1fbf9d2627  vmovaps xmm14, [rsp+0xE0]
00007b1fbf9d2630  add rsp, 0xF0
00007b1fbf9d2637  pop r11
00007b1fbf9d2639  pop r10
00007b1fbf9d263b  pop r9
00007b1fbf9d263d  pop r8
00007b1fbf9d263f  pop rsi
00007b1fbf9d2640  pop rdi
00007b1fbf9d2641  pop rdx
00007b1fbf9d2642  pop rcx
00007b1fbf9d2643  pop rax
00007b1fbf9d2644  add rsp, 0x08
00007b1fbf9d2648  jmp 0x00007B1FBF9CFCBC
00007b1fbf9d264d  sub rsp, 0x08
00007b1fbf9d2651  push rax
00007b1fbf9d2652  push rcx
00007b1fbf9d2653  push rdx
00007b1fbf9d2654  push rdi
00007b1fbf9d2655  push rsi
00007b1fbf9d2656  push r8
00007b1fbf9d2658  push r9
00007b1fbf9d265a  push r10
00007b1fbf9d265c  push r11
00007b1fbf9d265e  sub rsp, 0xF0
00007b1fbf9d2665  vmovaps [rsp], xmm0
00007b1fbf9d266a  vmovaps [rsp+0x10], xmm1
00007b1fbf9d2670  vmovaps [rsp+0x20], xmm2
00007b1fbf9d2676  vmovaps [rsp+0x30], xmm3
00007b1fbf9d267c  vmovaps [rsp+0x40], xmm4
00007b1fbf9d2682  vmovaps [rsp+0x50], xmm5
00007b1fbf9d2688  vmovaps [rsp+0x60], xmm6
00007b1fbf9d268e  vmovaps [rsp+0x70], xmm7
00007b1fbf9d2694  vmovaps [rsp+0x80], xmm8
00007b1fbf9d269d  vmovaps [rsp+0x90], xmm9
00007b1fbf9d26a6  vmovaps [rsp+0xA0], xmm10
00007b1fbf9d26af  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d26b8  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d26c1  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d26ca  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d26d3  sub rsp, 0x30
00007b1fbf9d26d7  movaps [rsp], xmm11
00007b1fbf9d26dc  movaps [rsp+0x10], xmm6
00007b1fbf9d26e1  movaps [rsp+0x20], xmm14
00007b1fbf9d26e7  lea rdi, [rsp]
00007b1fbf9d26eb  mov esi, 0x00
00007b1fbf9d26f0  mov rax, 0x64AEE5F12530
00007b1fbf9d26fa  call rax
00007b1fbf9d26fc  movaps xmm11, [rsp]
00007b1fbf9d2701  add rsp, 0x30
00007b1fbf9d2705  vmovaps xmm0, [rsp]
00007b1fbf9d270a  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d2710  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d2716  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d271c  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d2722  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d2728  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d272e  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d2734  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d273d  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d2746  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9d274f  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d2758  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d2761  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d276a  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d2773  add rsp, 0xF0
00007b1fbf9d277a  pop r11
00007b1fbf9d277c  pop r10
00007b1fbf9d277e  pop r9
00007b1fbf9d2780  pop r8
00007b1fbf9d2782  pop rsi
00007b1fbf9d2783  pop rdi
00007b1fbf9d2784  pop rdx
00007b1fbf9d2785  pop rcx
00007b1fbf9d2786  pop rax
00007b1fbf9d2787  add rsp, 0x08
00007b1fbf9d278b  jmp 0x00007B1FBF9CFD34
00007b1fbf9d2790  call 0x00007B1FBF7FF430
00007b1fbf9d2795  jmp 0x00007B1FBF9CFD3E
00007b1fbf9d279a  sub rsp, 0x08
00007b1fbf9d279e  push rax
00007b1fbf9d279f  push rcx
00007b1fbf9d27a0  push rdx
00007b1fbf9d27a1  push rdi
00007b1fbf9d27a2  push rsi
00007b1fbf9d27a3  push r8
00007b1fbf9d27a5  push r9
00007b1fbf9d27a7  push r10
00007b1fbf9d27a9  push r11
00007b1fbf9d27ab  sub rsp, 0xF0
00007b1fbf9d27b2  vmovaps [rsp], xmm0
00007b1fbf9d27b7  vmovaps [rsp+0x10], xmm1
00007b1fbf9d27bd  vmovaps [rsp+0x20], xmm2
00007b1fbf9d27c3  vmovaps [rsp+0x30], xmm3
00007b1fbf9d27c9  vmovaps [rsp+0x40], xmm4
00007b1fbf9d27cf  vmovaps [rsp+0x50], xmm5
00007b1fbf9d27d5  vmovaps [rsp+0x60], xmm6
00007b1fbf9d27db  vmovaps [rsp+0x70], xmm7
00007b1fbf9d27e1  vmovaps [rsp+0x80], xmm8
00007b1fbf9d27ea  vmovaps [rsp+0x90], xmm9
00007b1fbf9d27f3  vmovaps [rsp+0xA0], xmm10
00007b1fbf9d27fc  vmovaps [rsp+0xB0], xmm11
00007b1fbf9d2805  vmovaps [rsp+0xC0], xmm12
00007b1fbf9d280e  vmovaps [rsp+0xD0], xmm13
00007b1fbf9d2817  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d2820  sub rsp, 0x30
00007b1fbf9d2824  movaps [rsp], xmm14
00007b1fbf9d2829  movaps [rsp+0x10], xmm6
00007b1fbf9d282e  movaps [rsp+0x20], xmm2
00007b1fbf9d2833  lea rdi, [rsp]
00007b1fbf9d2837  mov esi, 0x00
00007b1fbf9d283c  mov rax, 0x64AEE5F12530
00007b1fbf9d2846  call rax
00007b1fbf9d2848  movaps xmm14, [rsp]
00007b1fbf9d284d  add rsp, 0x30
00007b1fbf9d2851  vmovaps xmm0, [rsp]
00007b1fbf9d2856  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d285c  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d2862  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d2868  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d286e  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d2874  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d287a  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d2880  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d2889  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d2892  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9d289b  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9d28a4  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9d28ad  vmovaps xmm13, [rsp+0xD0]
00007b1fbf9d28b6  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d28bf  add rsp, 0xF0
00007b1fbf9d28c6  pop r11
00007b1fbf9d28c8  pop r10
00007b1fbf9d28ca  pop r9
00007b1fbf9d28cc  pop r8
00007b1fbf9d28ce  pop rsi
00007b1fbf9d28cf  pop rdi
00007b1fbf9d28d0  pop rdx
00007b1fbf9d28d1  pop rcx
00007b1fbf9d28d2  pop rax
00007b1fbf9d28d3  add rsp, 0x08
00007b1fbf9d28d7  jmp 0x00007B1FBF9CFD72
00007b1fbf9d28dc  sub rsp, 0x08
00007b1fbf9d28e0  push rax
00007b1fbf9d28e1  push rcx
00007b1fbf9d28e2  push rdx
00007b1fbf9d28e3  push rdi
00007b1fbf9d28e4  push rsi
00007b1fbf9d28e5  push r8
00007b1fbf9d28e7  push r9
00007b1fbf9d28e9  push r10
00007b1fbf9d28eb  push r11
00007b1fbf9d28ed  sub rsp, 0xF0
00007b1fbf9d28f4  vmovaps [rsp], xmm0
00007b1fbf9d28f9  vmovaps [rsp+0x10], xmm1
00007b1fbf9d28ff  vmovaps [rsp+0x20], xmm2
00007b1fbf9d2905  vmovaps [rsp+0x30], xmm3
00007b1fbf9d290b  vmovaps [rsp+0x40], xmm4
00007b1fbf9d2911  vmovaps [rsp+0x50], xmm5
00007b1fbf9d2917  vmovaps [rsp+0x60], xmm7
00007b1fbf9d291d  vmovaps [rsp+0x70], xmm8
00007b1fbf9d2923  vmovaps [rsp+0x80], xmm9
00007b1fbf9d292c  vmovaps [rsp+0x90], xmm10
00007b1fbf9d2935  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d293e  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d2947  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d2950  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d2959  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d2962  sub rsp, 0x30
00007b1fbf9d2966  movaps [rsp], xmm6
00007b1fbf9d296a  movaps [rsp+0x10], xmm5
00007b1fbf9d296f  movaps [rsp+0x20], xmm1
00007b1fbf9d2974  lea rdi, [rsp]
00007b1fbf9d2978  mov esi, 0x00
00007b1fbf9d297d  mov rax, 0x64AEE5F12530
00007b1fbf9d2987  call rax
00007b1fbf9d2989  movaps xmm6, [rsp]
00007b1fbf9d298d  add rsp, 0x30
00007b1fbf9d2991  vmovaps xmm0, [rsp]
00007b1fbf9d2996  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d299c  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d29a2  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d29a8  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d29ae  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d29b4  vmovaps xmm7, [rsp+0x60]
00007b1fbf9d29ba  vmovaps xmm8, [rsp+0x70]
00007b1fbf9d29c0  vmovaps xmm9, [rsp+0x80]
00007b1fbf9d29c9  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d29d2  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d29db  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d29e4  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d29ed  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d29f6  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d29ff  add rsp, 0xF0
00007b1fbf9d2a06  pop r11
00007b1fbf9d2a08  pop r10
00007b1fbf9d2a0a  pop r9
00007b1fbf9d2a0c  pop r8
00007b1fbf9d2a0e  pop rsi
00007b1fbf9d2a0f  pop rdi
00007b1fbf9d2a10  pop rdx
00007b1fbf9d2a11  pop rcx
00007b1fbf9d2a12  pop rax
00007b1fbf9d2a13  add rsp, 0x08
00007b1fbf9d2a17  jmp 0x00007B1FBF9CFD98
00007b1fbf9d2a1c  sub rsp, 0x08
00007b1fbf9d2a20  push rax
00007b1fbf9d2a21  push rcx
00007b1fbf9d2a22  push rdx
00007b1fbf9d2a23  push rdi
00007b1fbf9d2a24  push rsi
00007b1fbf9d2a25  push r8
00007b1fbf9d2a27  push r9
00007b1fbf9d2a29  push r10
00007b1fbf9d2a2b  push r11
00007b1fbf9d2a2d  sub rsp, 0xF0
00007b1fbf9d2a34  vmovaps [rsp], xmm0
00007b1fbf9d2a39  vmovaps [rsp+0x10], xmm2
00007b1fbf9d2a3f  vmovaps [rsp+0x20], xmm3
00007b1fbf9d2a45  vmovaps [rsp+0x30], xmm4
00007b1fbf9d2a4b  vmovaps [rsp+0x40], xmm5
00007b1fbf9d2a51  vmovaps [rsp+0x50], xmm6
00007b1fbf9d2a57  vmovaps [rsp+0x60], xmm7
00007b1fbf9d2a5d  vmovaps [rsp+0x70], xmm8
00007b1fbf9d2a63  vmovaps [rsp+0x80], xmm9
00007b1fbf9d2a6c  vmovaps [rsp+0x90], xmm10
00007b1fbf9d2a75  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d2a7e  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d2a87  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d2a90  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d2a99  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d2aa2  sub rsp, 0x30
00007b1fbf9d2aa6  movaps [rsp], xmm1
00007b1fbf9d2aaa  movaps [rsp+0x10], xmm5
00007b1fbf9d2aaf  movaps [rsp+0x20], xmm13
00007b1fbf9d2ab5  lea rdi, [rsp]
00007b1fbf9d2ab9  mov esi, 0x00
00007b1fbf9d2abe  mov rax, 0x64AEE5F12530
00007b1fbf9d2ac8  call rax
00007b1fbf9d2aca  movaps xmm1, [rsp]
00007b1fbf9d2ace  add rsp, 0x30
00007b1fbf9d2ad2  vmovaps xmm0, [rsp]
00007b1fbf9d2ad7  vmovaps xmm2, [rsp+0x10]
00007b1fbf9d2add  vmovaps xmm3, [rsp+0x20]
00007b1fbf9d2ae3  vmovaps xmm4, [rsp+0x30]
00007b1fbf9d2ae9  vmovaps xmm5, [rsp+0x40]
00007b1fbf9d2aef  vmovaps xmm6, [rsp+0x50]
00007b1fbf9d2af5  vmovaps xmm7, [rsp+0x60]
00007b1fbf9d2afb  vmovaps xmm8, [rsp+0x70]
00007b1fbf9d2b01  vmovaps xmm9, [rsp+0x80]
00007b1fbf9d2b0a  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d2b13  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d2b1c  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d2b25  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d2b2e  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d2b37  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d2b40  add rsp, 0xF0
00007b1fbf9d2b47  pop r11
00007b1fbf9d2b49  pop r10
00007b1fbf9d2b4b  pop r9
00007b1fbf9d2b4d  pop r8
00007b1fbf9d2b4f  pop rsi
00007b1fbf9d2b50  pop rdi
00007b1fbf9d2b51  pop rdx
00007b1fbf9d2b52  pop rcx
00007b1fbf9d2b53  pop rax
00007b1fbf9d2b54  add rsp, 0x08
00007b1fbf9d2b58  jmp 0x00007B1FBF9CFDB6
00007b1fbf9d2b5d  sub rsp, 0x08
00007b1fbf9d2b61  push rax
00007b1fbf9d2b62  push rcx
00007b1fbf9d2b63  push rdx
00007b1fbf9d2b64  push rdi
00007b1fbf9d2b65  push rsi
00007b1fbf9d2b66  push r8
00007b1fbf9d2b68  push r9
00007b1fbf9d2b6a  push r10
00007b1fbf9d2b6c  push r11
00007b1fbf9d2b6e  sub rsp, 0xF0
00007b1fbf9d2b75  vmovaps [rsp], xmm0
00007b1fbf9d2b7a  vmovaps [rsp+0x10], xmm1
00007b1fbf9d2b80  vmovaps [rsp+0x20], xmm2
00007b1fbf9d2b86  vmovaps [rsp+0x30], xmm3
00007b1fbf9d2b8c  vmovaps [rsp+0x40], xmm4
00007b1fbf9d2b92  vmovaps [rsp+0x50], xmm6
00007b1fbf9d2b98  vmovaps [rsp+0x60], xmm7
00007b1fbf9d2b9e  vmovaps [rsp+0x70], xmm8
00007b1fbf9d2ba4  vmovaps [rsp+0x80], xmm9
00007b1fbf9d2bad  vmovaps [rsp+0x90], xmm10
00007b1fbf9d2bb6  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d2bbf  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d2bc8  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d2bd1  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d2bda  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d2be3  sub rsp, 0x30
00007b1fbf9d2be7  movaps [rsp], xmm5
00007b1fbf9d2beb  movaps [rsp+0x10], xmm2
00007b1fbf9d2bf0  movaps [rsp+0x20], xmm13
00007b1fbf9d2bf6  lea rdi, [rsp]
00007b1fbf9d2bfa  mov esi, 0x00
00007b1fbf9d2bff  mov rax, 0x64AEE5F12530
00007b1fbf9d2c09  call rax
00007b1fbf9d2c0b  movaps xmm5, [rsp]
00007b1fbf9d2c0f  add rsp, 0x30
00007b1fbf9d2c13  vmovaps xmm0, [rsp]
00007b1fbf9d2c18  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d2c1e  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d2c24  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d2c2a  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d2c30  vmovaps xmm6, [rsp+0x50]
00007b1fbf9d2c36  vmovaps xmm7, [rsp+0x60]
00007b1fbf9d2c3c  vmovaps xmm8, [rsp+0x70]
00007b1fbf9d2c42  vmovaps xmm9, [rsp+0x80]
00007b1fbf9d2c4b  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d2c54  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d2c5d  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d2c66  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d2c6f  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d2c78  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d2c81  add rsp, 0xF0
00007b1fbf9d2c88  pop r11
00007b1fbf9d2c8a  pop r10
00007b1fbf9d2c8c  pop r9
00007b1fbf9d2c8e  pop r8
00007b1fbf9d2c90  pop rsi
00007b1fbf9d2c91  pop rdi
00007b1fbf9d2c92  pop rdx
00007b1fbf9d2c93  pop rcx
00007b1fbf9d2c94  pop rax
00007b1fbf9d2c95  add rsp, 0x08
00007b1fbf9d2c99  jmp 0x00007B1FBF9CFDEC
00007b1fbf9d2c9e  sub rsp, 0x08
00007b1fbf9d2ca2  push rax
00007b1fbf9d2ca3  push rcx
00007b1fbf9d2ca4  push rdx
00007b1fbf9d2ca5  push rdi
00007b1fbf9d2ca6  push rsi
00007b1fbf9d2ca7  push r8
00007b1fbf9d2ca9  push r9
00007b1fbf9d2cab  push r10
00007b1fbf9d2cad  push r11
00007b1fbf9d2caf  sub rsp, 0xF0
00007b1fbf9d2cb6  vmovaps [rsp], xmm0
00007b1fbf9d2cbb  vmovaps [rsp+0x10], xmm1
00007b1fbf9d2cc1  vmovaps [rsp+0x20], xmm2
00007b1fbf9d2cc7  vmovaps [rsp+0x30], xmm3
00007b1fbf9d2ccd  vmovaps [rsp+0x40], xmm4
00007b1fbf9d2cd3  vmovaps [rsp+0x50], xmm5
00007b1fbf9d2cd9  vmovaps [rsp+0x60], xmm6
00007b1fbf9d2cdf  vmovaps [rsp+0x70], xmm7
00007b1fbf9d2ce5  vmovaps [rsp+0x80], xmm8
00007b1fbf9d2cee  vmovaps [rsp+0x90], xmm9
00007b1fbf9d2cf7  vmovaps [rsp+0xA0], xmm10
00007b1fbf9d2d00  vmovaps [rsp+0xB0], xmm11
00007b1fbf9d2d09  vmovaps [rsp+0xC0], xmm12
00007b1fbf9d2d12  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d2d1b  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d2d24  sub rsp, 0x30
00007b1fbf9d2d28  movaps [rsp], xmm13
00007b1fbf9d2d2d  movaps [rsp+0x10], xmm10
00007b1fbf9d2d33  movaps [rsp+0x20], xmm1
00007b1fbf9d2d38  lea rdi, [rsp]
00007b1fbf9d2d3c  mov esi, 0x00
00007b1fbf9d2d41  mov rax, 0x64AEE5F12530
00007b1fbf9d2d4b  call rax
00007b1fbf9d2d4d  movaps xmm13, [rsp]
00007b1fbf9d2d52  add rsp, 0x30
00007b1fbf9d2d56  vmovaps xmm0, [rsp]
00007b1fbf9d2d5b  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d2d61  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d2d67  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d2d6d  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d2d73  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d2d79  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d2d7f  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d2d85  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d2d8e  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d2d97  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9d2da0  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9d2da9  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9d2db2  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d2dbb  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d2dc4  add rsp, 0xF0
00007b1fbf9d2dcb  pop r11
00007b1fbf9d2dcd  pop r10
00007b1fbf9d2dcf  pop r9
00007b1fbf9d2dd1  pop r8
00007b1fbf9d2dd3  pop rsi
00007b1fbf9d2dd4  pop rdi
00007b1fbf9d2dd5  pop rdx
00007b1fbf9d2dd6  pop rcx
00007b1fbf9d2dd7  pop rax
00007b1fbf9d2dd8  add rsp, 0x08
00007b1fbf9d2ddc  jmp 0x00007B1FBF9CFE15
00007b1fbf9d2de1  sub rsp, 0x08
00007b1fbf9d2de5  push rax
00007b1fbf9d2de6  push rcx
00007b1fbf9d2de7  push rdx
00007b1fbf9d2de8  push rdi
00007b1fbf9d2de9  push rsi
00007b1fbf9d2dea  push r8
00007b1fbf9d2dec  push r9
00007b1fbf9d2dee  push r10
00007b1fbf9d2df0  push r11
00007b1fbf9d2df2  sub rsp, 0xF0
00007b1fbf9d2df9  vmovaps [rsp], xmm0
00007b1fbf9d2dfe  vmovaps [rsp+0x10], xmm2
00007b1fbf9d2e04  vmovaps [rsp+0x20], xmm3
00007b1fbf9d2e0a  vmovaps [rsp+0x30], xmm4
00007b1fbf9d2e10  vmovaps [rsp+0x40], xmm5
00007b1fbf9d2e16  vmovaps [rsp+0x50], xmm6
00007b1fbf9d2e1c  vmovaps [rsp+0x60], xmm7
00007b1fbf9d2e22  vmovaps [rsp+0x70], xmm8
00007b1fbf9d2e28  vmovaps [rsp+0x80], xmm9
00007b1fbf9d2e31  vmovaps [rsp+0x90], xmm10
00007b1fbf9d2e3a  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d2e43  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d2e4c  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d2e55  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d2e5e  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d2e67  sub rsp, 0x30
00007b1fbf9d2e6b  movaps [rsp], xmm1
00007b1fbf9d2e6f  movaps [rsp+0x10], xmm15
00007b1fbf9d2e75  movaps [rsp+0x20], xmm10
00007b1fbf9d2e7b  lea rdi, [rsp]
00007b1fbf9d2e7f  mov esi, 0x00
00007b1fbf9d2e84  mov rax, 0x64AEE5F12530
00007b1fbf9d2e8e  call rax
00007b1fbf9d2e90  movaps xmm1, [rsp]
00007b1fbf9d2e94  add rsp, 0x30
00007b1fbf9d2e98  vmovaps xmm0, [rsp]
00007b1fbf9d2e9d  vmovaps xmm2, [rsp+0x10]
00007b1fbf9d2ea3  vmovaps xmm3, [rsp+0x20]
00007b1fbf9d2ea9  vmovaps xmm4, [rsp+0x30]
00007b1fbf9d2eaf  vmovaps xmm5, [rsp+0x40]
00007b1fbf9d2eb5  vmovaps xmm6, [rsp+0x50]
00007b1fbf9d2ebb  vmovaps xmm7, [rsp+0x60]
00007b1fbf9d2ec1  vmovaps xmm8, [rsp+0x70]
00007b1fbf9d2ec7  vmovaps xmm9, [rsp+0x80]
00007b1fbf9d2ed0  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d2ed9  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d2ee2  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d2eeb  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d2ef4  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d2efd  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d2f06  add rsp, 0xF0
00007b1fbf9d2f0d  pop r11
00007b1fbf9d2f0f  pop r10
00007b1fbf9d2f11  pop r9
00007b1fbf9d2f13  pop r8
00007b1fbf9d2f15  pop rsi
00007b1fbf9d2f16  pop rdi
00007b1fbf9d2f17  pop rdx
00007b1fbf9d2f18  pop rcx
00007b1fbf9d2f19  pop rax
00007b1fbf9d2f1a  add rsp, 0x08
00007b1fbf9d2f1e  jmp 0x00007B1FBF9CFE34
00007b1fbf9d2f23  sub rsp, 0x08
00007b1fbf9d2f27  push rax
00007b1fbf9d2f28  push rcx
00007b1fbf9d2f29  push rdx
00007b1fbf9d2f2a  push rdi
00007b1fbf9d2f2b  push rsi
00007b1fbf9d2f2c  push r8
00007b1fbf9d2f2e  push r9
00007b1fbf9d2f30  push r10
00007b1fbf9d2f32  push r11
00007b1fbf9d2f34  sub rsp, 0xF0
00007b1fbf9d2f3b  vmovaps [rsp], xmm0
00007b1fbf9d2f40  vmovaps [rsp+0x10], xmm1
00007b1fbf9d2f46  vmovaps [rsp+0x20], xmm2
00007b1fbf9d2f4c  vmovaps [rsp+0x30], xmm3
00007b1fbf9d2f52  vmovaps [rsp+0x40], xmm4
00007b1fbf9d2f58  vmovaps [rsp+0x50], xmm5
00007b1fbf9d2f5e  vmovaps [rsp+0x60], xmm6
00007b1fbf9d2f64  vmovaps [rsp+0x70], xmm7
00007b1fbf9d2f6a  vmovaps [rsp+0x80], xmm8
00007b1fbf9d2f73  vmovaps [rsp+0x90], xmm9
00007b1fbf9d2f7c  vmovaps [rsp+0xA0], xmm10
00007b1fbf9d2f85  vmovaps [rsp+0xB0], xmm11
00007b1fbf9d2f8e  vmovaps [rsp+0xC0], xmm12
00007b1fbf9d2f97  vmovaps [rsp+0xD0], xmm13
00007b1fbf9d2fa0  vmovaps [rsp+0xE0], xmm14
00007b1fbf9d2fa9  sub rsp, 0x30
00007b1fbf9d2fad  movaps [rsp], xmm15
00007b1fbf9d2fb2  movaps [rsp+0x10], xmm10
00007b1fbf9d2fb8  movaps [rsp+0x20], xmm11
00007b1fbf9d2fbe  lea rdi, [rsp]
00007b1fbf9d2fc2  mov esi, 0x00
00007b1fbf9d2fc7  mov rax, 0x64AEE5F12530
00007b1fbf9d2fd1  call rax
00007b1fbf9d2fd3  movaps xmm15, [rsp]
00007b1fbf9d2fd8  add rsp, 0x30
00007b1fbf9d2fdc  vmovaps xmm0, [rsp]
00007b1fbf9d2fe1  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d2fe7  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d2fed  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d2ff3  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d2ff9  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d2fff  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d3005  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d300b  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d3014  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d301d  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9d3026  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9d302f  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9d3038  vmovaps xmm13, [rsp+0xD0]
00007b1fbf9d3041  vmovaps xmm14, [rsp+0xE0]
00007b1fbf9d304a  add rsp, 0xF0
00007b1fbf9d3051  pop r11
00007b1fbf9d3053  pop r10
00007b1fbf9d3055  pop r9
00007b1fbf9d3057  pop r8
00007b1fbf9d3059  pop rsi
00007b1fbf9d305a  pop rdi
00007b1fbf9d305b  pop rdx
00007b1fbf9d305c  pop rcx
00007b1fbf9d305d  pop rax
00007b1fbf9d305e  add rsp, 0x08
00007b1fbf9d3062  jmp 0x00007B1FBF9CFE57
00007b1fbf9d3067  sub rsp, 0x08
00007b1fbf9d306b  push rax
00007b1fbf9d306c  push rcx
00007b1fbf9d306d  push rdx
00007b1fbf9d306e  push rdi
00007b1fbf9d306f  push rsi
00007b1fbf9d3070  push r8
00007b1fbf9d3072  push r9
00007b1fbf9d3074  push r10
00007b1fbf9d3076  push r11
00007b1fbf9d3078  sub rsp, 0xF0
00007b1fbf9d307f  vmovaps [rsp], xmm0
00007b1fbf9d3084  vmovaps [rsp+0x10], xmm1
00007b1fbf9d308a  vmovaps [rsp+0x20], xmm2
00007b1fbf9d3090  vmovaps [rsp+0x30], xmm3
00007b1fbf9d3096  vmovaps [rsp+0x40], xmm4
00007b1fbf9d309c  vmovaps [rsp+0x50], xmm5
00007b1fbf9d30a2  vmovaps [rsp+0x60], xmm6
00007b1fbf9d30a8  vmovaps [rsp+0x70], xmm7
00007b1fbf9d30ae  vmovaps [rsp+0x80], xmm8
00007b1fbf9d30b7  vmovaps [rsp+0x90], xmm9
00007b1fbf9d30c0  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d30c9  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d30d2  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d30db  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d30e4  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d30ed  sub rsp, 0x30
00007b1fbf9d30f1  movaps [rsp], xmm10
00007b1fbf9d30f6  movaps [rsp+0x10], xmm12
00007b1fbf9d30fc  movaps [rsp+0x20], xmm11
00007b1fbf9d3102  lea rdi, [rsp]
00007b1fbf9d3106  mov esi, 0x00
00007b1fbf9d310b  mov rax, 0x64AEE5F12530
00007b1fbf9d3115  call rax
00007b1fbf9d3117  movaps xmm10, [rsp]
00007b1fbf9d311c  add rsp, 0x30
00007b1fbf9d3120  vmovaps xmm0, [rsp]
00007b1fbf9d3125  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d312b  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d3131  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d3137  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d313d  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d3143  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d3149  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d314f  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d3158  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d3161  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d316a  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d3173  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d317c  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d3185  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d318e  add rsp, 0xF0
00007b1fbf9d3195  pop r11
00007b1fbf9d3197  pop r10
00007b1fbf9d3199  pop r9
00007b1fbf9d319b  pop r8
00007b1fbf9d319d  pop rsi
00007b1fbf9d319e  pop rdi
00007b1fbf9d319f  pop rdx
00007b1fbf9d31a0  pop rcx
00007b1fbf9d31a1  pop rax
00007b1fbf9d31a2  add rsp, 0x08
00007b1fbf9d31a6  jmp 0x00007B1FBF9CFE80
00007b1fbf9d31ab  sub rsp, 0x08
00007b1fbf9d31af  push rax
00007b1fbf9d31b0  push rcx
00007b1fbf9d31b1  push rdx
00007b1fbf9d31b2  push rdi
00007b1fbf9d31b3  push rsi
00007b1fbf9d31b4  push r8
00007b1fbf9d31b6  push r9
00007b1fbf9d31b8  push r10
00007b1fbf9d31ba  push r11
00007b1fbf9d31bc  sub rsp, 0xF0
00007b1fbf9d31c3  vmovaps [rsp], xmm0
00007b1fbf9d31c8  vmovaps [rsp+0x10], xmm1
00007b1fbf9d31ce  vmovaps [rsp+0x20], xmm2
00007b1fbf9d31d4  vmovaps [rsp+0x30], xmm3
00007b1fbf9d31da  vmovaps [rsp+0x40], xmm4
00007b1fbf9d31e0  vmovaps [rsp+0x50], xmm5
00007b1fbf9d31e6  vmovaps [rsp+0x60], xmm6
00007b1fbf9d31ec  vmovaps [rsp+0x70], xmm7
00007b1fbf9d31f2  vmovaps [rsp+0x80], xmm8
00007b1fbf9d31fb  vmovaps [rsp+0x90], xmm9
00007b1fbf9d3204  vmovaps [rsp+0xA0], xmm10
00007b1fbf9d320d  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d3216  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d321f  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d3228  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d3231  sub rsp, 0x30
00007b1fbf9d3235  movaps [rsp], xmm11
00007b1fbf9d323a  movaps [rsp+0x10], xmm2
00007b1fbf9d323f  movaps [rsp+0x20], xmm12
00007b1fbf9d3245  lea rdi, [rsp]
00007b1fbf9d3249  mov esi, 0x00
00007b1fbf9d324e  mov rax, 0x64AEE5F12530
00007b1fbf9d3258  call rax
00007b1fbf9d325a  movaps xmm11, [rsp]
00007b1fbf9d325f  add rsp, 0x30
00007b1fbf9d3263  vmovaps xmm0, [rsp]
00007b1fbf9d3268  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d326e  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d3274  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d327a  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d3280  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d3286  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d328c  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d3292  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d329b  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d32a4  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9d32ad  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d32b6  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d32bf  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d32c8  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d32d1  add rsp, 0xF0
00007b1fbf9d32d8  pop r11
00007b1fbf9d32da  pop r10
00007b1fbf9d32dc  pop r9
00007b1fbf9d32de  pop r8
00007b1fbf9d32e0  pop rsi
00007b1fbf9d32e1  pop rdi
00007b1fbf9d32e2  pop rdx
00007b1fbf9d32e3  pop rcx
00007b1fbf9d32e4  pop rax
00007b1fbf9d32e5  add rsp, 0x08
00007b1fbf9d32e9  jmp 0x00007B1FBF9CFEB8
00007b1fbf9d32ee  sub rsp, 0x08
00007b1fbf9d32f2  push rax
00007b1fbf9d32f3  push rcx
00007b1fbf9d32f4  push rdx
00007b1fbf9d32f5  push rdi
00007b1fbf9d32f6  push rsi
00007b1fbf9d32f7  push r8
00007b1fbf9d32f9  push r9
00007b1fbf9d32fb  push r10
00007b1fbf9d32fd  push r11
00007b1fbf9d32ff  sub rsp, 0xF0
00007b1fbf9d3306  vmovaps [rsp], xmm0
00007b1fbf9d330b  vmovaps [rsp+0x10], xmm2
00007b1fbf9d3311  vmovaps [rsp+0x20], xmm3
00007b1fbf9d3317  vmovaps [rsp+0x30], xmm4
00007b1fbf9d331d  vmovaps [rsp+0x40], xmm5
00007b1fbf9d3323  vmovaps [rsp+0x50], xmm6
00007b1fbf9d3329  vmovaps [rsp+0x60], xmm7
00007b1fbf9d332f  vmovaps [rsp+0x70], xmm8
00007b1fbf9d3335  vmovaps [rsp+0x80], xmm9
00007b1fbf9d333e  vmovaps [rsp+0x90], xmm10
00007b1fbf9d3347  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d3350  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d3359  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d3362  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d336b  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d3374  sub rsp, 0x30
00007b1fbf9d3378  movaps [rsp], xmm1
00007b1fbf9d337c  movaps [rsp+0x10], xmm14
00007b1fbf9d3382  movaps [rsp+0x20], xmm6
00007b1fbf9d3387  lea rdi, [rsp]
00007b1fbf9d338b  mov esi, 0x00
00007b1fbf9d3390  mov rax, 0x64AEE5F12530
00007b1fbf9d339a  call rax
00007b1fbf9d339c  movaps xmm1, [rsp]
00007b1fbf9d33a0  add rsp, 0x30
00007b1fbf9d33a4  vmovaps xmm0, [rsp]
00007b1fbf9d33a9  vmovaps xmm2, [rsp+0x10]
00007b1fbf9d33af  vmovaps xmm3, [rsp+0x20]
00007b1fbf9d33b5  vmovaps xmm4, [rsp+0x30]
00007b1fbf9d33bb  vmovaps xmm5, [rsp+0x40]
00007b1fbf9d33c1  vmovaps xmm6, [rsp+0x50]
00007b1fbf9d33c7  vmovaps xmm7, [rsp+0x60]
00007b1fbf9d33cd  vmovaps xmm8, [rsp+0x70]
00007b1fbf9d33d3  vmovaps xmm9, [rsp+0x80]
00007b1fbf9d33dc  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d33e5  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d33ee  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d33f7  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d3400  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d3409  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d3412  add rsp, 0xF0
00007b1fbf9d3419  pop r11
00007b1fbf9d341b  pop r10
00007b1fbf9d341d  pop r9
00007b1fbf9d341f  pop r8
00007b1fbf9d3421  pop rsi
00007b1fbf9d3422  pop rdi
00007b1fbf9d3423  pop rdx
00007b1fbf9d3424  pop rcx
00007b1fbf9d3425  pop rax
00007b1fbf9d3426  add rsp, 0x08
00007b1fbf9d342a  jmp 0x00007B1FBF9CFED1
00007b1fbf9d342f  sub rsp, 0x08
00007b1fbf9d3433  push rax
00007b1fbf9d3434  push rcx
00007b1fbf9d3435  push rdx
00007b1fbf9d3436  push rdi
00007b1fbf9d3437  push rsi
00007b1fbf9d3438  push r8
00007b1fbf9d343a  push r9
00007b1fbf9d343c  push r10
00007b1fbf9d343e  push r11
00007b1fbf9d3440  sub rsp, 0xF0
00007b1fbf9d3447  vmovaps [rsp], xmm0
00007b1fbf9d344c  vmovaps [rsp+0x10], xmm1
00007b1fbf9d3452  vmovaps [rsp+0x20], xmm2
00007b1fbf9d3458  vmovaps [rsp+0x30], xmm3
00007b1fbf9d345e  vmovaps [rsp+0x40], xmm4
00007b1fbf9d3464  vmovaps [rsp+0x50], xmm5
00007b1fbf9d346a  vmovaps [rsp+0x60], xmm6
00007b1fbf9d3470  vmovaps [rsp+0x70], xmm7
00007b1fbf9d3476  vmovaps [rsp+0x80], xmm8
00007b1fbf9d347f  vmovaps [rsp+0x90], xmm9
00007b1fbf9d3488  vmovaps [rsp+0xA0], xmm10
00007b1fbf9d3491  vmovaps [rsp+0xB0], xmm11
00007b1fbf9d349a  vmovaps [rsp+0xC0], xmm12
00007b1fbf9d34a3  vmovaps [rsp+0xD0], xmm13
00007b1fbf9d34ac  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d34b5  sub rsp, 0x30
00007b1fbf9d34b9  movaps [rsp], xmm14
00007b1fbf9d34be  movaps [rsp+0x10], xmm12
00007b1fbf9d34c4  movaps [rsp+0x20], xmm5
00007b1fbf9d34c9  lea rdi, [rsp]
00007b1fbf9d34cd  mov esi, 0x00
00007b1fbf9d34d2  mov rax, 0x64AEE5F12530
00007b1fbf9d34dc  call rax
00007b1fbf9d34de  movaps xmm14, [rsp]
00007b1fbf9d34e3  add rsp, 0x30
00007b1fbf9d34e7  vmovaps xmm0, [rsp]
00007b1fbf9d34ec  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d34f2  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d34f8  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d34fe  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d3504  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d350a  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d3510  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d3516  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d351f  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d3528  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9d3531  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9d353a  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9d3543  vmovaps xmm13, [rsp+0xD0]
00007b1fbf9d354c  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d3555  add rsp, 0xF0
00007b1fbf9d355c  pop r11
00007b1fbf9d355e  pop r10
00007b1fbf9d3560  pop r9
00007b1fbf9d3562  pop r8
00007b1fbf9d3564  pop rsi
00007b1fbf9d3565  pop rdi
00007b1fbf9d3566  pop rdx
00007b1fbf9d3567  pop rcx
00007b1fbf9d3568  pop rax
00007b1fbf9d3569  add rsp, 0x08
00007b1fbf9d356d  jmp 0x00007B1FBF9CFEF1
00007b1fbf9d3572  sub rsp, 0x08
00007b1fbf9d3576  push rax
00007b1fbf9d3577  push rcx
00007b1fbf9d3578  push rdx
00007b1fbf9d3579  push rdi
00007b1fbf9d357a  push rsi
00007b1fbf9d357b  push r8
00007b1fbf9d357d  push r9
00007b1fbf9d357f  push r10
00007b1fbf9d3581  push r11
00007b1fbf9d3583  sub rsp, 0xF0
00007b1fbf9d358a  vmovaps [rsp], xmm0
00007b1fbf9d358f  vmovaps [rsp+0x10], xmm1
00007b1fbf9d3595  vmovaps [rsp+0x20], xmm2
00007b1fbf9d359b  vmovaps [rsp+0x30], xmm3
00007b1fbf9d35a1  vmovaps [rsp+0x40], xmm4
00007b1fbf9d35a7  vmovaps [rsp+0x50], xmm5
00007b1fbf9d35ad  vmovaps [rsp+0x60], xmm7
00007b1fbf9d35b3  vmovaps [rsp+0x70], xmm8
00007b1fbf9d35b9  vmovaps [rsp+0x80], xmm9
00007b1fbf9d35c2  vmovaps [rsp+0x90], xmm10
00007b1fbf9d35cb  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d35d4  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d35dd  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d35e6  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d35ef  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d35f8  sub rsp, 0x30
00007b1fbf9d35fc  movaps [rsp], xmm6
00007b1fbf9d3600  movaps [rsp+0x10], xmm9
00007b1fbf9d3606  movaps [rsp+0x20], xmm12
00007b1fbf9d360c  lea rdi, [rsp]
00007b1fbf9d3610  mov esi, 0x00
00007b1fbf9d3615  mov rax, 0x64AEE5F12530
00007b1fbf9d361f  call rax
00007b1fbf9d3621  movaps xmm6, [rsp]
00007b1fbf9d3625  add rsp, 0x30
00007b1fbf9d3629  vmovaps xmm0, [rsp]
00007b1fbf9d362e  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d3634  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d363a  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d3640  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d3646  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d364c  vmovaps xmm7, [rsp+0x60]
00007b1fbf9d3652  vmovaps xmm8, [rsp+0x70]
00007b1fbf9d3658  vmovaps xmm9, [rsp+0x80]
00007b1fbf9d3661  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d366a  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d3673  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d367c  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d3685  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d368e  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d3697  add rsp, 0xF0
00007b1fbf9d369e  pop r11
00007b1fbf9d36a0  pop r10
00007b1fbf9d36a2  pop r9
00007b1fbf9d36a4  pop r8
00007b1fbf9d36a6  pop rsi
00007b1fbf9d36a7  pop rdi
00007b1fbf9d36a8  pop rdx
00007b1fbf9d36a9  pop rcx
00007b1fbf9d36aa  pop rax
00007b1fbf9d36ab  add rsp, 0x08
00007b1fbf9d36af  jmp 0x00007B1FBF9CFF19
00007b1fbf9d36b4  sub rsp, 0x08
00007b1fbf9d36b8  push rax
00007b1fbf9d36b9  push rcx
00007b1fbf9d36ba  push rdx
00007b1fbf9d36bb  push rdi
00007b1fbf9d36bc  push rsi
00007b1fbf9d36bd  push r8
00007b1fbf9d36bf  push r9
00007b1fbf9d36c1  push r10
00007b1fbf9d36c3  push r11
00007b1fbf9d36c5  sub rsp, 0xF0
00007b1fbf9d36cc  vmovaps [rsp], xmm0
00007b1fbf9d36d1  vmovaps [rsp+0x10], xmm1
00007b1fbf9d36d7  vmovaps [rsp+0x20], xmm2
00007b1fbf9d36dd  vmovaps [rsp+0x30], xmm3
00007b1fbf9d36e3  vmovaps [rsp+0x40], xmm4
00007b1fbf9d36e9  vmovaps [rsp+0x50], xmm5
00007b1fbf9d36ef  vmovaps [rsp+0x60], xmm6
00007b1fbf9d36f5  vmovaps [rsp+0x70], xmm7
00007b1fbf9d36fb  vmovaps [rsp+0x80], xmm8
00007b1fbf9d3704  vmovaps [rsp+0x90], xmm9
00007b1fbf9d370d  vmovaps [rsp+0xA0], xmm10
00007b1fbf9d3716  vmovaps [rsp+0xB0], xmm11
00007b1fbf9d371f  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d3728  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d3731  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d373a  sub rsp, 0x30
00007b1fbf9d373e  movaps [rsp], xmm12
00007b1fbf9d3743  movaps [rsp+0x10], xmm15
00007b1fbf9d3749  movaps [rsp+0x20], xmm13
00007b1fbf9d374f  lea rdi, [rsp]
00007b1fbf9d3753  mov esi, 0x00
00007b1fbf9d3758  mov rax, 0x64AEE5F12530
00007b1fbf9d3762  call rax
00007b1fbf9d3764  movaps xmm12, [rsp]
00007b1fbf9d3769  add rsp, 0x30
00007b1fbf9d376d  vmovaps xmm0, [rsp]
00007b1fbf9d3772  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d3778  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d377e  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d3784  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d378a  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d3790  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d3796  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d379c  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d37a5  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d37ae  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9d37b7  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9d37c0  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d37c9  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d37d2  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d37db  add rsp, 0xF0
00007b1fbf9d37e2  pop r11
00007b1fbf9d37e4  pop r10
00007b1fbf9d37e6  pop r9
00007b1fbf9d37e8  pop r8
00007b1fbf9d37ea  pop rsi
00007b1fbf9d37eb  pop rdi
00007b1fbf9d37ec  pop rdx
00007b1fbf9d37ed  pop rcx
00007b1fbf9d37ee  pop rax
00007b1fbf9d37ef  add rsp, 0x08
00007b1fbf9d37f3  jmp 0x00007B1FBF9CFF34
00007b1fbf9d37f8  sub rsp, 0x08
00007b1fbf9d37fc  push rax
00007b1fbf9d37fd  push rcx
00007b1fbf9d37fe  push rdx
00007b1fbf9d37ff  push rdi
00007b1fbf9d3800  push rsi
00007b1fbf9d3801  push r8
00007b1fbf9d3803  push r9
00007b1fbf9d3805  push r10
00007b1fbf9d3807  push r11
00007b1fbf9d3809  sub rsp, 0xF0
00007b1fbf9d3810  vmovaps [rsp], xmm0
00007b1fbf9d3815  vmovaps [rsp+0x10], xmm1
00007b1fbf9d381b  vmovaps [rsp+0x20], xmm2
00007b1fbf9d3821  vmovaps [rsp+0x30], xmm3
00007b1fbf9d3827  vmovaps [rsp+0x40], xmm4
00007b1fbf9d382d  vmovaps [rsp+0x50], xmm5
00007b1fbf9d3833  vmovaps [rsp+0x60], xmm6
00007b1fbf9d3839  vmovaps [rsp+0x70], xmm7
00007b1fbf9d383f  vmovaps [rsp+0x80], xmm8
00007b1fbf9d3848  vmovaps [rsp+0x90], xmm9
00007b1fbf9d3851  vmovaps [rsp+0xA0], xmm10
00007b1fbf9d385a  vmovaps [rsp+0xB0], xmm11
00007b1fbf9d3863  vmovaps [rsp+0xC0], xmm12
00007b1fbf9d386c  vmovaps [rsp+0xD0], xmm13
00007b1fbf9d3875  vmovaps [rsp+0xE0], xmm14
00007b1fbf9d387e  sub rsp, 0x30
00007b1fbf9d3882  movaps [rsp], xmm15
00007b1fbf9d3887  movaps [rsp+0x10], xmm13
00007b1fbf9d388d  movaps [rsp+0x20], xmm10
00007b1fbf9d3893  lea rdi, [rsp]
00007b1fbf9d3897  mov esi, 0x00
00007b1fbf9d389c  mov rax, 0x64AEE5F12530
00007b1fbf9d38a6  call rax
00007b1fbf9d38a8  movaps xmm15, [rsp]
00007b1fbf9d38ad  add rsp, 0x30
00007b1fbf9d38b1  vmovaps xmm0, [rsp]
00007b1fbf9d38b6  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d38bc  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d38c2  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d38c8  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d38ce  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d38d4  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d38da  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d38e0  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d38e9  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d38f2  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9d38fb  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9d3904  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9d390d  vmovaps xmm13, [rsp+0xD0]
00007b1fbf9d3916  vmovaps xmm14, [rsp+0xE0]
00007b1fbf9d391f  add rsp, 0xF0
00007b1fbf9d3926  pop r11
00007b1fbf9d3928  pop r10
00007b1fbf9d392a  pop r9
00007b1fbf9d392c  pop r8
00007b1fbf9d392e  pop rsi
00007b1fbf9d392f  pop rdi
00007b1fbf9d3930  pop rdx
00007b1fbf9d3931  pop rcx
00007b1fbf9d3932  pop rax
00007b1fbf9d3933  add rsp, 0x08
00007b1fbf9d3937  jmp 0x00007B1FBF9CFF55
00007b1fbf9d393c  call 0x00007B1FBF80C260
00007b1fbf9d3941  jmp 0x00007B1FBF9CFFB0
00007b1fbf9d3946  sub rsp, 0x08
00007b1fbf9d394a  push rax
00007b1fbf9d394b  push rcx
00007b1fbf9d394c  push rdx
00007b1fbf9d394d  push rdi
00007b1fbf9d394e  push rsi
00007b1fbf9d394f  push r8
00007b1fbf9d3951  push r9
00007b1fbf9d3953  push r10
00007b1fbf9d3955  push r11
00007b1fbf9d3957  sub rsp, 0xF0
00007b1fbf9d395e  vmovaps [rsp], xmm0
00007b1fbf9d3963  vmovaps [rsp+0x10], xmm1
00007b1fbf9d3969  vmovaps [rsp+0x20], xmm2
00007b1fbf9d396f  vmovaps [rsp+0x30], xmm3
00007b1fbf9d3975  vmovaps [rsp+0x40], xmm4
00007b1fbf9d397b  vmovaps [rsp+0x50], xmm5
00007b1fbf9d3981  vmovaps [rsp+0x60], xmm6
00007b1fbf9d3987  vmovaps [rsp+0x70], xmm7
00007b1fbf9d398d  vmovaps [rsp+0x80], xmm8
00007b1fbf9d3996  vmovaps [rsp+0x90], xmm10
00007b1fbf9d399f  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d39a8  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d39b1  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d39ba  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d39c3  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d39cc  sub rsp, 0x30
00007b1fbf9d39d0  movaps [rsp], xmm9
00007b1fbf9d39d5  movaps [rsp+0x10], xmm8
00007b1fbf9d39db  movaps [rsp+0x20], xmm10
00007b1fbf9d39e1  lea rdi, [rsp]
00007b1fbf9d39e5  mov esi, 0x00
00007b1fbf9d39ea  mov rax, 0x64AEE5F12530
00007b1fbf9d39f4  call rax
00007b1fbf9d39f6  movaps xmm9, [rsp]
00007b1fbf9d39fb  add rsp, 0x30
00007b1fbf9d39ff  vmovaps xmm0, [rsp]
00007b1fbf9d3a04  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d3a0a  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d3a10  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d3a16  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d3a1c  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d3a22  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d3a28  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d3a2e  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d3a37  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d3a40  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d3a49  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d3a52  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d3a5b  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d3a64  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d3a6d  add rsp, 0xF0
00007b1fbf9d3a74  pop r11
00007b1fbf9d3a76  pop r10
00007b1fbf9d3a78  pop r9
00007b1fbf9d3a7a  pop r8
00007b1fbf9d3a7c  pop rsi
00007b1fbf9d3a7d  pop rdi
00007b1fbf9d3a7e  pop rdx
00007b1fbf9d3a7f  pop rcx
00007b1fbf9d3a80  pop rax
00007b1fbf9d3a81  add rsp, 0x08
00007b1fbf9d3a85  jmp 0x00007B1FBF9CFFE1
00007b1fbf9d3a8a  sub rsp, 0x08
00007b1fbf9d3a8e  push rax
00007b1fbf9d3a8f  push rcx
00007b1fbf9d3a90  push rdx
00007b1fbf9d3a91  push rdi
00007b1fbf9d3a92  push rsi
00007b1fbf9d3a93  push r8
00007b1fbf9d3a95  push r9
00007b1fbf9d3a97  push r10
00007b1fbf9d3a99  push r11
00007b1fbf9d3a9b  sub rsp, 0xF0
00007b1fbf9d3aa2  vmovaps [rsp], xmm0
00007b1fbf9d3aa7  vmovaps [rsp+0x10], xmm1
00007b1fbf9d3aad  vmovaps [rsp+0x20], xmm2
00007b1fbf9d3ab3  vmovaps [rsp+0x30], xmm3
00007b1fbf9d3ab9  vmovaps [rsp+0x40], xmm4
00007b1fbf9d3abf  vmovaps [rsp+0x50], xmm5
00007b1fbf9d3ac5  vmovaps [rsp+0x60], xmm6
00007b1fbf9d3acb  vmovaps [rsp+0x70], xmm7
00007b1fbf9d3ad1  vmovaps [rsp+0x80], xmm8
00007b1fbf9d3ada  vmovaps [rsp+0x90], xmm9
00007b1fbf9d3ae3  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d3aec  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d3af5  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d3afe  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d3b07  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d3b10  sub rsp, 0x30
00007b1fbf9d3b14  movaps [rsp], xmm10
00007b1fbf9d3b19  movaps [rsp+0x10], xmm1
00007b1fbf9d3b1e  movaps [rsp+0x20], xmm11
00007b1fbf9d3b24  lea rdi, [rsp]
00007b1fbf9d3b28  mov esi, 0x00
00007b1fbf9d3b2d  mov rax, 0x64AEE5F12530
00007b1fbf9d3b37  call rax
00007b1fbf9d3b39  movaps xmm10, [rsp]
00007b1fbf9d3b3e  add rsp, 0x30
00007b1fbf9d3b42  vmovaps xmm0, [rsp]
00007b1fbf9d3b47  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d3b4d  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d3b53  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d3b59  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d3b5f  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d3b65  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d3b6b  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d3b71  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d3b7a  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d3b83  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d3b8c  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d3b95  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d3b9e  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d3ba7  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d3bb0  add rsp, 0xF0
00007b1fbf9d3bb7  pop r11
00007b1fbf9d3bb9  pop r10
00007b1fbf9d3bbb  pop r9
00007b1fbf9d3bbd  pop r8
00007b1fbf9d3bbf  pop rsi
00007b1fbf9d3bc0  pop rdi
00007b1fbf9d3bc1  pop rdx
00007b1fbf9d3bc2  pop rcx
00007b1fbf9d3bc3  pop rax
00007b1fbf9d3bc4  add rsp, 0x08
00007b1fbf9d3bc8  jmp 0x00007B1FBF9CFFFC
00007b1fbf9d3bcd  sub rsp, 0x08
00007b1fbf9d3bd1  push rax
00007b1fbf9d3bd2  push rcx
00007b1fbf9d3bd3  push rdx
00007b1fbf9d3bd4  push rdi
00007b1fbf9d3bd5  push rsi
00007b1fbf9d3bd6  push r8
00007b1fbf9d3bd8  push r9
00007b1fbf9d3bda  push r10
00007b1fbf9d3bdc  push r11
00007b1fbf9d3bde  sub rsp, 0xF0
00007b1fbf9d3be5  vmovaps [rsp], xmm0
00007b1fbf9d3bea  vmovaps [rsp+0x10], xmm2
00007b1fbf9d3bf0  vmovaps [rsp+0x20], xmm3
00007b1fbf9d3bf6  vmovaps [rsp+0x30], xmm4
00007b1fbf9d3bfc  vmovaps [rsp+0x40], xmm5
00007b1fbf9d3c02  vmovaps [rsp+0x50], xmm6
00007b1fbf9d3c08  vmovaps [rsp+0x60], xmm7
00007b1fbf9d3c0e  vmovaps [rsp+0x70], xmm8
00007b1fbf9d3c14  vmovaps [rsp+0x80], xmm9
00007b1fbf9d3c1d  vmovaps [rsp+0x90], xmm10
00007b1fbf9d3c26  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d3c2f  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d3c38  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d3c41  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d3c4a  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d3c53  sub rsp, 0x30
00007b1fbf9d3c57  movaps [rsp], xmm1
00007b1fbf9d3c5b  movaps [rsp+0x10], xmm14
00007b1fbf9d3c61  movaps [rsp+0x20], xmm6
00007b1fbf9d3c66  lea rdi, [rsp]
00007b1fbf9d3c6a  mov esi, 0x00
00007b1fbf9d3c6f  mov rax, 0x64AEE5F12530
00007b1fbf9d3c79  call rax
00007b1fbf9d3c7b  movaps xmm1, [rsp]
00007b1fbf9d3c7f  add rsp, 0x30
00007b1fbf9d3c83  vmovaps xmm0, [rsp]
00007b1fbf9d3c88  vmovaps xmm2, [rsp+0x10]
00007b1fbf9d3c8e  vmovaps xmm3, [rsp+0x20]
00007b1fbf9d3c94  vmovaps xmm4, [rsp+0x30]
00007b1fbf9d3c9a  vmovaps xmm5, [rsp+0x40]
00007b1fbf9d3ca0  vmovaps xmm6, [rsp+0x50]
00007b1fbf9d3ca6  vmovaps xmm7, [rsp+0x60]
00007b1fbf9d3cac  vmovaps xmm8, [rsp+0x70]
00007b1fbf9d3cb2  vmovaps xmm9, [rsp+0x80]
00007b1fbf9d3cbb  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d3cc4  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d3ccd  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d3cd6  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d3cdf  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d3ce8  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d3cf1  add rsp, 0xF0
00007b1fbf9d3cf8  pop r11
00007b1fbf9d3cfa  pop r10
00007b1fbf9d3cfc  pop r9
00007b1fbf9d3cfe  pop r8
00007b1fbf9d3d00  pop rsi
00007b1fbf9d3d01  pop rdi
00007b1fbf9d3d02  pop rdx
00007b1fbf9d3d03  pop rcx
00007b1fbf9d3d04  pop rax
00007b1fbf9d3d05  add rsp, 0x08
00007b1fbf9d3d09  jmp 0x00007B1FBF9D0015
00007b1fbf9d3d0e  sub rsp, 0x08
00007b1fbf9d3d12  push rax
00007b1fbf9d3d13  push rcx
00007b1fbf9d3d14  push rdx
00007b1fbf9d3d15  push rdi
00007b1fbf9d3d16  push rsi
00007b1fbf9d3d17  push r8
00007b1fbf9d3d19  push r9
00007b1fbf9d3d1b  push r10
00007b1fbf9d3d1d  push r11
00007b1fbf9d3d1f  sub rsp, 0xF0
00007b1fbf9d3d26  vmovaps [rsp], xmm0
00007b1fbf9d3d2b  vmovaps [rsp+0x10], xmm1
00007b1fbf9d3d31  vmovaps [rsp+0x20], xmm2
00007b1fbf9d3d37  vmovaps [rsp+0x30], xmm3
00007b1fbf9d3d3d  vmovaps [rsp+0x40], xmm4
00007b1fbf9d3d43  vmovaps [rsp+0x50], xmm5
00007b1fbf9d3d49  vmovaps [rsp+0x60], xmm6
00007b1fbf9d3d4f  vmovaps [rsp+0x70], xmm7
00007b1fbf9d3d55  vmovaps [rsp+0x80], xmm8
00007b1fbf9d3d5e  vmovaps [rsp+0x90], xmm9
00007b1fbf9d3d67  vmovaps [rsp+0xA0], xmm10
00007b1fbf9d3d70  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d3d79  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d3d82  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d3d8b  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d3d94  sub rsp, 0x30
00007b1fbf9d3d98  movaps [rsp], xmm11
00007b1fbf9d3d9d  movaps [rsp+0x10], xmm13
00007b1fbf9d3da3  movaps [rsp+0x20], xmm14
00007b1fbf9d3da9  lea rdi, [rsp]
00007b1fbf9d3dad  mov esi, 0x00
00007b1fbf9d3db2  mov rax, 0x64AEE5F12530
00007b1fbf9d3dbc  call rax
00007b1fbf9d3dbe  movaps xmm11, [rsp]
00007b1fbf9d3dc3  add rsp, 0x30
00007b1fbf9d3dc7  vmovaps xmm0, [rsp]
00007b1fbf9d3dcc  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d3dd2  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d3dd8  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d3dde  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d3de4  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d3dea  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d3df0  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d3df6  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d3dff  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d3e08  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9d3e11  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d3e1a  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d3e23  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d3e2c  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d3e35  add rsp, 0xF0
00007b1fbf9d3e3c  pop r11
00007b1fbf9d3e3e  pop r10
00007b1fbf9d3e40  pop r9
00007b1fbf9d3e42  pop r8
00007b1fbf9d3e44  pop rsi
00007b1fbf9d3e45  pop rdi
00007b1fbf9d3e46  pop rdx
00007b1fbf9d3e47  pop rcx
00007b1fbf9d3e48  pop rax
00007b1fbf9d3e49  add rsp, 0x08
00007b1fbf9d3e4d  jmp 0x00007B1FBF9D003F
00007b1fbf9d3e52  sub rsp, 0x08
00007b1fbf9d3e56  push rax
00007b1fbf9d3e57  push rcx
00007b1fbf9d3e58  push rdx
00007b1fbf9d3e59  push rdi
00007b1fbf9d3e5a  push rsi
00007b1fbf9d3e5b  push r8
00007b1fbf9d3e5d  push r9
00007b1fbf9d3e5f  push r10
00007b1fbf9d3e61  push r11
00007b1fbf9d3e63  sub rsp, 0xF0
00007b1fbf9d3e6a  vmovaps [rsp], xmm0
00007b1fbf9d3e6f  vmovaps [rsp+0x10], xmm1
00007b1fbf9d3e75  vmovaps [rsp+0x20], xmm2
00007b1fbf9d3e7b  vmovaps [rsp+0x30], xmm3
00007b1fbf9d3e81  vmovaps [rsp+0x40], xmm4
00007b1fbf9d3e87  vmovaps [rsp+0x50], xmm5
00007b1fbf9d3e8d  vmovaps [rsp+0x60], xmm6
00007b1fbf9d3e93  vmovaps [rsp+0x70], xmm7
00007b1fbf9d3e99  vmovaps [rsp+0x80], xmm8
00007b1fbf9d3ea2  vmovaps [rsp+0x90], xmm9
00007b1fbf9d3eab  vmovaps [rsp+0xA0], xmm10
00007b1fbf9d3eb4  vmovaps [rsp+0xB0], xmm11
00007b1fbf9d3ebd  vmovaps [rsp+0xC0], xmm12
00007b1fbf9d3ec6  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d3ecf  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d3ed8  sub rsp, 0x30
00007b1fbf9d3edc  movaps [rsp], xmm13
00007b1fbf9d3ee1  movaps [rsp+0x10], xmm8
00007b1fbf9d3ee7  movaps [rsp+0x20], xmm14
00007b1fbf9d3eed  lea rdi, [rsp]
00007b1fbf9d3ef1  mov esi, 0x00
00007b1fbf9d3ef6  mov rax, 0x64AEE5F12530
00007b1fbf9d3f00  call rax
00007b1fbf9d3f02  movaps xmm13, [rsp]
00007b1fbf9d3f07  add rsp, 0x30
00007b1fbf9d3f0b  vmovaps xmm0, [rsp]
00007b1fbf9d3f10  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d3f16  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d3f1c  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d3f22  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d3f28  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d3f2e  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d3f34  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d3f3a  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d3f43  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d3f4c  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9d3f55  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9d3f5e  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9d3f67  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d3f70  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d3f79  add rsp, 0xF0
00007b1fbf9d3f80  pop r11
00007b1fbf9d3f82  pop r10
00007b1fbf9d3f84  pop r9
00007b1fbf9d3f86  pop r8
00007b1fbf9d3f88  pop rsi
00007b1fbf9d3f89  pop rdi
00007b1fbf9d3f8a  pop rdx
00007b1fbf9d3f8b  pop rcx
00007b1fbf9d3f8c  pop rax
00007b1fbf9d3f8d  add rsp, 0x08
00007b1fbf9d3f91  jmp 0x00007B1FBF9D006E
00007b1fbf9d3f96  sub rsp, 0x08
00007b1fbf9d3f9a  push rax
00007b1fbf9d3f9b  push rcx
00007b1fbf9d3f9c  push rdx
00007b1fbf9d3f9d  push rdi
00007b1fbf9d3f9e  push rsi
00007b1fbf9d3f9f  push r8
00007b1fbf9d3fa1  push r9
00007b1fbf9d3fa3  push r10
00007b1fbf9d3fa5  push r11
00007b1fbf9d3fa7  sub rsp, 0xF0
00007b1fbf9d3fae  vmovaps [rsp], xmm0
00007b1fbf9d3fb3  vmovaps [rsp+0x10], xmm1
00007b1fbf9d3fb9  vmovaps [rsp+0x20], xmm2
00007b1fbf9d3fbf  vmovaps [rsp+0x30], xmm3
00007b1fbf9d3fc5  vmovaps [rsp+0x40], xmm4
00007b1fbf9d3fcb  vmovaps [rsp+0x50], xmm5
00007b1fbf9d3fd1  vmovaps [rsp+0x60], xmm6
00007b1fbf9d3fd7  vmovaps [rsp+0x70], xmm7
00007b1fbf9d3fdd  vmovaps [rsp+0x80], xmm9
00007b1fbf9d3fe6  vmovaps [rsp+0x90], xmm10
00007b1fbf9d3fef  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d3ff8  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d4001  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d400a  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d4013  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d401c  sub rsp, 0x30
00007b1fbf9d4020  movaps [rsp], xmm8
00007b1fbf9d4025  movaps [rsp+0x10], xmm7
00007b1fbf9d402a  movaps [rsp+0x20], xmm14
00007b1fbf9d4030  lea rdi, [rsp]
00007b1fbf9d4034  mov esi, 0x00
00007b1fbf9d4039  mov rax, 0x64AEE5F12530
00007b1fbf9d4043  call rax
00007b1fbf9d4045  movaps xmm8, [rsp]
00007b1fbf9d404a  add rsp, 0x30
00007b1fbf9d404e  vmovaps xmm0, [rsp]
00007b1fbf9d4053  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d4059  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d405f  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d4065  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d406b  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d4071  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d4077  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d407d  vmovaps xmm9, [rsp+0x80]
00007b1fbf9d4086  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d408f  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d4098  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d40a1  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d40aa  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d40b3  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d40bc  add rsp, 0xF0
00007b1fbf9d40c3  pop r11
00007b1fbf9d40c5  pop r10
00007b1fbf9d40c7  pop r9
00007b1fbf9d40c9  pop r8
00007b1fbf9d40cb  pop rsi
00007b1fbf9d40cc  pop rdi
00007b1fbf9d40cd  pop rdx
00007b1fbf9d40ce  pop rcx
00007b1fbf9d40cf  pop rax
00007b1fbf9d40d0  add rsp, 0x08
00007b1fbf9d40d4  jmp 0x00007B1FBF9D0094
00007b1fbf9d40d9  sub rsp, 0x08
00007b1fbf9d40dd  push rax
00007b1fbf9d40de  push rcx
00007b1fbf9d40df  push rdx
00007b1fbf9d40e0  push rdi
00007b1fbf9d40e1  push rsi
00007b1fbf9d40e2  push r8
00007b1fbf9d40e4  push r9
00007b1fbf9d40e6  push r10
00007b1fbf9d40e8  push r11
00007b1fbf9d40ea  sub rsp, 0xF0
00007b1fbf9d40f1  vmovaps [rsp], xmm0
00007b1fbf9d40f6  vmovaps [rsp+0x10], xmm1
00007b1fbf9d40fc  vmovaps [rsp+0x20], xmm2
00007b1fbf9d4102  vmovaps [rsp+0x30], xmm3
00007b1fbf9d4108  vmovaps [rsp+0x40], xmm4
00007b1fbf9d410e  vmovaps [rsp+0x50], xmm5
00007b1fbf9d4114  vmovaps [rsp+0x60], xmm6
00007b1fbf9d411a  vmovaps [rsp+0x70], xmm7
00007b1fbf9d4120  vmovaps [rsp+0x80], xmm8
00007b1fbf9d4129  vmovaps [rsp+0x90], xmm9
00007b1fbf9d4132  vmovaps [rsp+0xA0], xmm10
00007b1fbf9d413b  vmovaps [rsp+0xB0], xmm11
00007b1fbf9d4144  vmovaps [rsp+0xC0], xmm12
00007b1fbf9d414d  vmovaps [rsp+0xD0], xmm13
00007b1fbf9d4156  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d415f  sub rsp, 0x30
00007b1fbf9d4163  movaps [rsp], xmm14
00007b1fbf9d4168  movaps [rsp+0x10], xmm12
00007b1fbf9d416e  movaps [rsp+0x20], xmm9
00007b1fbf9d4174  lea rdi, [rsp]
00007b1fbf9d4178  mov esi, 0x00
00007b1fbf9d417d  mov rax, 0x64AEE5F12530
00007b1fbf9d4187  call rax
00007b1fbf9d4189  movaps xmm14, [rsp]
00007b1fbf9d418e  add rsp, 0x30
00007b1fbf9d4192  vmovaps xmm0, [rsp]
00007b1fbf9d4197  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d419d  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d41a3  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d41a9  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d41af  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d41b5  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d41bb  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d41c1  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d41ca  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d41d3  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9d41dc  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9d41e5  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9d41ee  vmovaps xmm13, [rsp+0xD0]
00007b1fbf9d41f7  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d4200  add rsp, 0xF0
00007b1fbf9d4207  pop r11
00007b1fbf9d4209  pop r10
00007b1fbf9d420b  pop r9
00007b1fbf9d420d  pop r8
00007b1fbf9d420f  pop rsi
00007b1fbf9d4210  pop rdi
00007b1fbf9d4211  pop rdx
00007b1fbf9d4212  pop rcx
00007b1fbf9d4213  pop rax
00007b1fbf9d4214  add rsp, 0x08
00007b1fbf9d4218  jmp 0x00007B1FBF9D00AE
00007b1fbf9d421d  sub rsp, 0x08
00007b1fbf9d4221  push rax
00007b1fbf9d4222  push rcx
00007b1fbf9d4223  push rdx
00007b1fbf9d4224  push rdi
00007b1fbf9d4225  push rsi
00007b1fbf9d4226  push r8
00007b1fbf9d4228  push r9
00007b1fbf9d422a  push r10
00007b1fbf9d422c  push r11
00007b1fbf9d422e  sub rsp, 0xF0
00007b1fbf9d4235  vmovaps [rsp], xmm0
00007b1fbf9d423a  vmovaps [rsp+0x10], xmm1
00007b1fbf9d4240  vmovaps [rsp+0x20], xmm2
00007b1fbf9d4246  vmovaps [rsp+0x30], xmm3
00007b1fbf9d424c  vmovaps [rsp+0x40], xmm4
00007b1fbf9d4252  vmovaps [rsp+0x50], xmm5
00007b1fbf9d4258  vmovaps [rsp+0x60], xmm6
00007b1fbf9d425e  vmovaps [rsp+0x70], xmm7
00007b1fbf9d4264  vmovaps [rsp+0x80], xmm8
00007b1fbf9d426d  vmovaps [rsp+0x90], xmm10
00007b1fbf9d4276  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d427f  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d4288  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d4291  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d429a  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d42a3  sub rsp, 0x30
00007b1fbf9d42a7  movaps [rsp], xmm9
00007b1fbf9d42ac  movaps [rsp+0x10], xmm7
00007b1fbf9d42b1  movaps [rsp+0x20], xmm12
00007b1fbf9d42b7  lea rdi, [rsp]
00007b1fbf9d42bb  mov esi, 0x00
00007b1fbf9d42c0  mov rax, 0x64AEE5F12530
00007b1fbf9d42ca  call rax
00007b1fbf9d42cc  movaps xmm9, [rsp]
00007b1fbf9d42d1  add rsp, 0x30
00007b1fbf9d42d5  vmovaps xmm0, [rsp]
00007b1fbf9d42da  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d42e0  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d42e6  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d42ec  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d42f2  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d42f8  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d42fe  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d4304  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d430d  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d4316  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d431f  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d4328  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d4331  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d433a  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d4343  add rsp, 0xF0
00007b1fbf9d434a  pop r11
00007b1fbf9d434c  pop r10
00007b1fbf9d434e  pop r9
00007b1fbf9d4350  pop r8
00007b1fbf9d4352  pop rsi
00007b1fbf9d4353  pop rdi
00007b1fbf9d4354  pop rdx
00007b1fbf9d4355  pop rcx
00007b1fbf9d4356  pop rax
00007b1fbf9d4357  add rsp, 0x08
00007b1fbf9d435b  jmp 0x00007B1FBF9D00DD
00007b1fbf9d4360  sub rsp, 0x08
00007b1fbf9d4364  push rax
00007b1fbf9d4365  push rcx
00007b1fbf9d4366  push rdx
00007b1fbf9d4367  push rdi
00007b1fbf9d4368  push rsi
00007b1fbf9d4369  push r8
00007b1fbf9d436b  push r9
00007b1fbf9d436d  push r10
00007b1fbf9d436f  push r11
00007b1fbf9d4371  sub rsp, 0xF0
00007b1fbf9d4378  vmovaps [rsp], xmm0
00007b1fbf9d437d  vmovaps [rsp+0x10], xmm1
00007b1fbf9d4383  vmovaps [rsp+0x20], xmm2
00007b1fbf9d4389  vmovaps [rsp+0x30], xmm3
00007b1fbf9d438f  vmovaps [rsp+0x40], xmm4
00007b1fbf9d4395  vmovaps [rsp+0x50], xmm5
00007b1fbf9d439b  vmovaps [rsp+0x60], xmm6
00007b1fbf9d43a1  vmovaps [rsp+0x70], xmm7
00007b1fbf9d43a7  vmovaps [rsp+0x80], xmm8
00007b1fbf9d43b0  vmovaps [rsp+0x90], xmm9
00007b1fbf9d43b9  vmovaps [rsp+0xA0], xmm10
00007b1fbf9d43c2  vmovaps [rsp+0xB0], xmm11
00007b1fbf9d43cb  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d43d4  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d43dd  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d43e6  sub rsp, 0x30
00007b1fbf9d43ea  movaps [rsp], xmm12
00007b1fbf9d43ef  movaps [rsp+0x10], xmm15
00007b1fbf9d43f5  movaps [rsp+0x20], xmm11
00007b1fbf9d43fb  lea rdi, [rsp]
00007b1fbf9d43ff  mov esi, 0x00
00007b1fbf9d4404  mov rax, 0x64AEE5F12530
00007b1fbf9d440e  call rax
00007b1fbf9d4410  movaps xmm12, [rsp]
00007b1fbf9d4415  add rsp, 0x30
00007b1fbf9d4419  vmovaps xmm0, [rsp]
00007b1fbf9d441e  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d4424  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d442a  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d4430  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d4436  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d443c  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d4442  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d4448  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d4451  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d445a  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9d4463  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9d446c  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d4475  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d447e  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d4487  add rsp, 0xF0
00007b1fbf9d448e  pop r11
00007b1fbf9d4490  pop r10
00007b1fbf9d4492  pop r9
00007b1fbf9d4494  pop r8
00007b1fbf9d4496  pop rsi
00007b1fbf9d4497  pop rdi
00007b1fbf9d4498  pop rdx
00007b1fbf9d4499  pop rcx
00007b1fbf9d449a  pop rax
00007b1fbf9d449b  add rsp, 0x08
00007b1fbf9d449f  jmp 0x00007B1FBF9D00F7
00007b1fbf9d44a4  sub rsp, 0x08
00007b1fbf9d44a8  push rax
00007b1fbf9d44a9  push rcx
00007b1fbf9d44aa  push rdx
00007b1fbf9d44ab  push rdi
00007b1fbf9d44ac  push rsi
00007b1fbf9d44ad  push r8
00007b1fbf9d44af  push r9
00007b1fbf9d44b1  push r10
00007b1fbf9d44b3  push r11
00007b1fbf9d44b5  sub rsp, 0xF0
00007b1fbf9d44bc  vmovaps [rsp], xmm0
00007b1fbf9d44c1  vmovaps [rsp+0x10], xmm1
00007b1fbf9d44c7  vmovaps [rsp+0x20], xmm2
00007b1fbf9d44cd  vmovaps [rsp+0x30], xmm3
00007b1fbf9d44d3  vmovaps [rsp+0x40], xmm4
00007b1fbf9d44d9  vmovaps [rsp+0x50], xmm5
00007b1fbf9d44df  vmovaps [rsp+0x60], xmm6
00007b1fbf9d44e5  vmovaps [rsp+0x70], xmm7
00007b1fbf9d44eb  vmovaps [rsp+0x80], xmm8
00007b1fbf9d44f4  vmovaps [rsp+0x90], xmm9
00007b1fbf9d44fd  vmovaps [rsp+0xA0], xmm10
00007b1fbf9d4506  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d450f  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d4518  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d4521  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d452a  sub rsp, 0x30
00007b1fbf9d452e  movaps [rsp], xmm11
00007b1fbf9d4533  movaps [rsp+0x10], xmm7
00007b1fbf9d4538  movaps [rsp+0x20], xmm15
00007b1fbf9d453e  lea rdi, [rsp]
00007b1fbf9d4542  mov esi, 0x00
00007b1fbf9d4547  mov rax, 0x64AEE5F12530
00007b1fbf9d4551  call rax
00007b1fbf9d4553  movaps xmm11, [rsp]
00007b1fbf9d4558  add rsp, 0x30
00007b1fbf9d455c  vmovaps xmm0, [rsp]
00007b1fbf9d4561  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d4567  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d456d  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d4573  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d4579  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d457f  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d4585  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d458b  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d4594  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d459d  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9d45a6  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d45af  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d45b8  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d45c1  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d45ca  add rsp, 0xF0
00007b1fbf9d45d1  pop r11
00007b1fbf9d45d3  pop r10
00007b1fbf9d45d5  pop r9
00007b1fbf9d45d7  pop r8
00007b1fbf9d45d9  pop rsi
00007b1fbf9d45da  pop rdi
00007b1fbf9d45db  pop rdx
00007b1fbf9d45dc  pop rcx
00007b1fbf9d45dd  pop rax
00007b1fbf9d45de  add rsp, 0x08
00007b1fbf9d45e2  jmp 0x00007B1FBF9D0123
00007b1fbf9d45e7  sub rsp, 0x08
00007b1fbf9d45eb  push rax
00007b1fbf9d45ec  push rcx
00007b1fbf9d45ed  push rdx
00007b1fbf9d45ee  push rdi
00007b1fbf9d45ef  push rsi
00007b1fbf9d45f0  push r8
00007b1fbf9d45f2  push r9
00007b1fbf9d45f4  push r10
00007b1fbf9d45f6  push r11
00007b1fbf9d45f8  sub rsp, 0xF0
00007b1fbf9d45ff  vmovaps [rsp], xmm0
00007b1fbf9d4604  vmovaps [rsp+0x10], xmm1
00007b1fbf9d460a  vmovaps [rsp+0x20], xmm2
00007b1fbf9d4610  vmovaps [rsp+0x30], xmm3
00007b1fbf9d4616  vmovaps [rsp+0x40], xmm4
00007b1fbf9d461c  vmovaps [rsp+0x50], xmm5
00007b1fbf9d4622  vmovaps [rsp+0x60], xmm6
00007b1fbf9d4628  vmovaps [rsp+0x70], xmm7
00007b1fbf9d462e  vmovaps [rsp+0x80], xmm8
00007b1fbf9d4637  vmovaps [rsp+0x90], xmm9
00007b1fbf9d4640  vmovaps [rsp+0xA0], xmm10
00007b1fbf9d4649  vmovaps [rsp+0xB0], xmm11
00007b1fbf9d4652  vmovaps [rsp+0xC0], xmm12
00007b1fbf9d465b  vmovaps [rsp+0xD0], xmm13
00007b1fbf9d4664  vmovaps [rsp+0xE0], xmm14
00007b1fbf9d466d  sub rsp, 0x30
00007b1fbf9d4671  movaps [rsp], xmm15
00007b1fbf9d4676  movaps [rsp+0x10], xmm10
00007b1fbf9d467c  movaps [rsp+0x20], xmm13
00007b1fbf9d4682  lea rdi, [rsp]
00007b1fbf9d4686  mov esi, 0x00
00007b1fbf9d468b  mov rax, 0x64AEE5F12530
00007b1fbf9d4695  call rax
00007b1fbf9d4697  movaps xmm15, [rsp]
00007b1fbf9d469c  add rsp, 0x30
00007b1fbf9d46a0  vmovaps xmm0, [rsp]
00007b1fbf9d46a5  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d46ab  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d46b1  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d46b7  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d46bd  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d46c3  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d46c9  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d46cf  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d46d8  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d46e1  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9d46ea  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9d46f3  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9d46fc  vmovaps xmm13, [rsp+0xD0]
00007b1fbf9d4705  vmovaps xmm14, [rsp+0xE0]
00007b1fbf9d470e  add rsp, 0xF0
00007b1fbf9d4715  pop r11
00007b1fbf9d4717  pop r10
00007b1fbf9d4719  pop r9
00007b1fbf9d471b  pop r8
00007b1fbf9d471d  pop rsi
00007b1fbf9d471e  pop rdi
00007b1fbf9d471f  pop rdx
00007b1fbf9d4720  pop rcx
00007b1fbf9d4721  pop rax
00007b1fbf9d4722  add rsp, 0x08
00007b1fbf9d4726  jmp 0x00007B1FBF9D013D
00007b1fbf9d472b  sub rsp, 0x08
00007b1fbf9d472f  push rax
00007b1fbf9d4730  push rcx
00007b1fbf9d4731  push rdx
00007b1fbf9d4732  push rdi
00007b1fbf9d4733  push rsi
00007b1fbf9d4734  push r8
00007b1fbf9d4736  push r9
00007b1fbf9d4738  push r10
00007b1fbf9d473a  push r11
00007b1fbf9d473c  sub rsp, 0xF0
00007b1fbf9d4743  vmovaps [rsp], xmm0
00007b1fbf9d4748  vmovaps [rsp+0x10], xmm1
00007b1fbf9d474e  vmovaps [rsp+0x20], xmm2
00007b1fbf9d4754  vmovaps [rsp+0x30], xmm3
00007b1fbf9d475a  vmovaps [rsp+0x40], xmm4
00007b1fbf9d4760  vmovaps [rsp+0x50], xmm5
00007b1fbf9d4766  vmovaps [rsp+0x60], xmm6
00007b1fbf9d476c  vmovaps [rsp+0x70], xmm7
00007b1fbf9d4772  vmovaps [rsp+0x80], xmm8
00007b1fbf9d477b  vmovaps [rsp+0x90], xmm9
00007b1fbf9d4784  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d478d  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d4796  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d479f  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d47a8  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d47b1  sub rsp, 0x30
00007b1fbf9d47b5  movaps [rsp], xmm10
00007b1fbf9d47ba  movaps [rsp+0x10], xmm7
00007b1fbf9d47bf  movaps [rsp+0x20], xmm13
00007b1fbf9d47c5  lea rdi, [rsp]
00007b1fbf9d47c9  mov esi, 0x00
00007b1fbf9d47ce  mov rax, 0x64AEE5F12530
00007b1fbf9d47d8  call rax
00007b1fbf9d47da  movaps xmm10, [rsp]
00007b1fbf9d47df  add rsp, 0x30
00007b1fbf9d47e3  vmovaps xmm0, [rsp]
00007b1fbf9d47e8  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d47ee  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d47f4  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d47fa  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d4800  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d4806  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d480c  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d4812  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d481b  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d4824  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d482d  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d4836  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d483f  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d4848  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d4851  add rsp, 0xF0
00007b1fbf9d4858  pop r11
00007b1fbf9d485a  pop r10
00007b1fbf9d485c  pop r9
00007b1fbf9d485e  pop r8
00007b1fbf9d4860  pop rsi
00007b1fbf9d4861  pop rdi
00007b1fbf9d4862  pop rdx
00007b1fbf9d4863  pop rcx
00007b1fbf9d4864  pop rax
00007b1fbf9d4865  add rsp, 0x08
00007b1fbf9d4869  jmp 0x00007B1FBF9D0169
00007b1fbf9d486e  sub rsp, 0x08
00007b1fbf9d4872  push rax
00007b1fbf9d4873  push rcx
00007b1fbf9d4874  push rdx
00007b1fbf9d4875  push rdi
00007b1fbf9d4876  push rsi
00007b1fbf9d4877  push r8
00007b1fbf9d4879  push r9
00007b1fbf9d487b  push r10
00007b1fbf9d487d  push r11
00007b1fbf9d487f  sub rsp, 0xF0
00007b1fbf9d4886  vmovaps [rsp], xmm0
00007b1fbf9d488b  vmovaps [rsp+0x10], xmm1
00007b1fbf9d4891  vmovaps [rsp+0x20], xmm2
00007b1fbf9d4897  vmovaps [rsp+0x30], xmm3
00007b1fbf9d489d  vmovaps [rsp+0x40], xmm4
00007b1fbf9d48a3  vmovaps [rsp+0x50], xmm5
00007b1fbf9d48a9  vmovaps [rsp+0x60], xmm6
00007b1fbf9d48af  vmovaps [rsp+0x70], xmm7
00007b1fbf9d48b5  vmovaps [rsp+0x80], xmm8
00007b1fbf9d48be  vmovaps [rsp+0x90], xmm9
00007b1fbf9d48c7  vmovaps [rsp+0xA0], xmm10
00007b1fbf9d48d0  vmovaps [rsp+0xB0], xmm11
00007b1fbf9d48d9  vmovaps [rsp+0xC0], xmm12
00007b1fbf9d48e2  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d48eb  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d48f4  sub rsp, 0x30
00007b1fbf9d48f8  movaps [rsp], xmm13
00007b1fbf9d48fd  movaps [rsp+0x10], xmm1
00007b1fbf9d4902  movaps [rsp+0x20], xmm8
00007b1fbf9d4908  lea rdi, [rsp]
00007b1fbf9d490c  mov esi, 0x00
00007b1fbf9d4911  mov rax, 0x64AEE5F12530
00007b1fbf9d491b  call rax
00007b1fbf9d491d  movaps xmm13, [rsp]
00007b1fbf9d4922  add rsp, 0x30
00007b1fbf9d4926  vmovaps xmm0, [rsp]
00007b1fbf9d492b  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d4931  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d4937  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d493d  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d4943  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d4949  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d494f  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d4955  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d495e  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d4967  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9d4970  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9d4979  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9d4982  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d498b  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d4994  add rsp, 0xF0
00007b1fbf9d499b  pop r11
00007b1fbf9d499d  pop r10
00007b1fbf9d499f  pop r9
00007b1fbf9d49a1  pop r8
00007b1fbf9d49a3  pop rsi
00007b1fbf9d49a4  pop rdi
00007b1fbf9d49a5  pop rdx
00007b1fbf9d49a6  pop rcx
00007b1fbf9d49a7  pop rax
00007b1fbf9d49a8  add rsp, 0x08
00007b1fbf9d49ac  jmp 0x00007B1FBF9D0183
00007b1fbf9d49b1  call 0x00007B1FBF7FF430
00007b1fbf9d49b6  jmp 0x00007B1FBF9D018D
00007b1fbf9d49bb  sub rsp, 0x08
00007b1fbf9d49bf  push rax
00007b1fbf9d49c0  push rcx
00007b1fbf9d49c1  push rdx
00007b1fbf9d49c2  push rdi
00007b1fbf9d49c3  push rsi
00007b1fbf9d49c4  push r8
00007b1fbf9d49c6  push r9
00007b1fbf9d49c8  push r10
00007b1fbf9d49ca  push r11
00007b1fbf9d49cc  sub rsp, 0xF0
00007b1fbf9d49d3  vmovaps [rsp], xmm0
00007b1fbf9d49d8  vmovaps [rsp+0x10], xmm1
00007b1fbf9d49de  vmovaps [rsp+0x20], xmm2
00007b1fbf9d49e4  vmovaps [rsp+0x30], xmm3
00007b1fbf9d49ea  vmovaps [rsp+0x40], xmm4
00007b1fbf9d49f0  vmovaps [rsp+0x50], xmm5
00007b1fbf9d49f6  vmovaps [rsp+0x60], xmm6
00007b1fbf9d49fc  vmovaps [rsp+0x70], xmm7
00007b1fbf9d4a02  vmovaps [rsp+0x80], xmm9
00007b1fbf9d4a0b  vmovaps [rsp+0x90], xmm10
00007b1fbf9d4a14  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d4a1d  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d4a26  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d4a2f  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d4a38  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d4a41  sub rsp, 0x30
00007b1fbf9d4a45  movaps [rsp], xmm8
00007b1fbf9d4a4a  movaps [rsp+0x10], xmm14
00007b1fbf9d4a50  movaps [rsp+0x20], xmm9
00007b1fbf9d4a56  lea rdi, [rsp]
00007b1fbf9d4a5a  mov esi, 0x00
00007b1fbf9d4a5f  mov rax, 0x64AEE5F12530
00007b1fbf9d4a69  call rax
00007b1fbf9d4a6b  movaps xmm8, [rsp]
00007b1fbf9d4a70  add rsp, 0x30
00007b1fbf9d4a74  vmovaps xmm0, [rsp]
00007b1fbf9d4a79  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d4a7f  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d4a85  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d4a8b  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d4a91  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d4a97  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d4a9d  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d4aa3  vmovaps xmm9, [rsp+0x80]
00007b1fbf9d4aac  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d4ab5  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d4abe  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d4ac7  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d4ad0  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d4ad9  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d4ae2  add rsp, 0xF0
00007b1fbf9d4ae9  pop r11
00007b1fbf9d4aeb  pop r10
00007b1fbf9d4aed  pop r9
00007b1fbf9d4aef  pop r8
00007b1fbf9d4af1  pop rsi
00007b1fbf9d4af2  pop rdi
00007b1fbf9d4af3  pop rdx
00007b1fbf9d4af4  pop rcx
00007b1fbf9d4af5  pop rax
00007b1fbf9d4af6  add rsp, 0x08
00007b1fbf9d4afa  jmp 0x00007B1FBF9D01AF
00007b1fbf9d4aff  sub rsp, 0x08
00007b1fbf9d4b03  push rax
00007b1fbf9d4b04  push rcx
00007b1fbf9d4b05  push rdx
00007b1fbf9d4b06  push rdi
00007b1fbf9d4b07  push rsi
00007b1fbf9d4b08  push r8
00007b1fbf9d4b0a  push r9
00007b1fbf9d4b0c  push r10
00007b1fbf9d4b0e  push r11
00007b1fbf9d4b10  sub rsp, 0xF0
00007b1fbf9d4b17  vmovaps [rsp], xmm0
00007b1fbf9d4b1c  vmovaps [rsp+0x10], xmm1
00007b1fbf9d4b22  vmovaps [rsp+0x20], xmm2
00007b1fbf9d4b28  vmovaps [rsp+0x30], xmm3
00007b1fbf9d4b2e  vmovaps [rsp+0x40], xmm4
00007b1fbf9d4b34  vmovaps [rsp+0x50], xmm5
00007b1fbf9d4b3a  vmovaps [rsp+0x60], xmm6
00007b1fbf9d4b40  vmovaps [rsp+0x70], xmm7
00007b1fbf9d4b46  vmovaps [rsp+0x80], xmm8
00007b1fbf9d4b4f  vmovaps [rsp+0x90], xmm10
00007b1fbf9d4b58  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d4b61  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d4b6a  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d4b73  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d4b7c  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d4b85  sub rsp, 0x30
00007b1fbf9d4b89  movaps [rsp], xmm9
00007b1fbf9d4b8e  movaps [rsp+0x10], xmm1
00007b1fbf9d4b93  movaps [rsp+0x20], xmm14
00007b1fbf9d4b99  lea rdi, [rsp]
00007b1fbf9d4b9d  mov esi, 0x00
00007b1fbf9d4ba2  mov rax, 0x64AEE5F12530
00007b1fbf9d4bac  call rax
00007b1fbf9d4bae  movaps xmm9, [rsp]
00007b1fbf9d4bb3  add rsp, 0x30
00007b1fbf9d4bb7  vmovaps xmm0, [rsp]
00007b1fbf9d4bbc  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d4bc2  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d4bc8  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d4bce  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d4bd4  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d4bda  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d4be0  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d4be6  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d4bef  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d4bf8  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d4c01  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d4c0a  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d4c13  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d4c1c  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d4c25  add rsp, 0xF0
00007b1fbf9d4c2c  pop r11
00007b1fbf9d4c2e  pop r10
00007b1fbf9d4c30  pop r9
00007b1fbf9d4c32  pop r8
00007b1fbf9d4c34  pop rsi
00007b1fbf9d4c35  pop rdi
00007b1fbf9d4c36  pop rdx
00007b1fbf9d4c37  pop rcx
00007b1fbf9d4c38  pop rax
00007b1fbf9d4c39  add rsp, 0x08
00007b1fbf9d4c3d  jmp 0x00007B1FBF9D01DD
00007b1fbf9d4c42  sub rsp, 0x08
00007b1fbf9d4c46  push rax
00007b1fbf9d4c47  push rcx
00007b1fbf9d4c48  push rdx
00007b1fbf9d4c49  push rdi
00007b1fbf9d4c4a  push rsi
00007b1fbf9d4c4b  push r8
00007b1fbf9d4c4d  push r9
00007b1fbf9d4c4f  push r10
00007b1fbf9d4c51  push r11
00007b1fbf9d4c53  sub rsp, 0xF0
00007b1fbf9d4c5a  vmovaps [rsp], xmm0
00007b1fbf9d4c5f  vmovaps [rsp+0x10], xmm1
00007b1fbf9d4c65  vmovaps [rsp+0x20], xmm2
00007b1fbf9d4c6b  vmovaps [rsp+0x30], xmm3
00007b1fbf9d4c71  vmovaps [rsp+0x40], xmm4
00007b1fbf9d4c77  vmovaps [rsp+0x50], xmm5
00007b1fbf9d4c7d  vmovaps [rsp+0x60], xmm6
00007b1fbf9d4c83  vmovaps [rsp+0x70], xmm7
00007b1fbf9d4c89  vmovaps [rsp+0x80], xmm8
00007b1fbf9d4c92  vmovaps [rsp+0x90], xmm9
00007b1fbf9d4c9b  vmovaps [rsp+0xA0], xmm10
00007b1fbf9d4ca4  vmovaps [rsp+0xB0], xmm11
00007b1fbf9d4cad  vmovaps [rsp+0xC0], xmm12
00007b1fbf9d4cb6  vmovaps [rsp+0xD0], xmm13
00007b1fbf9d4cbf  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d4cc8  sub rsp, 0x30
00007b1fbf9d4ccc  movaps [rsp], xmm14
00007b1fbf9d4cd1  movaps [rsp+0x10], xmm4
00007b1fbf9d4cd6  movaps [rsp+0x20], xmm1
00007b1fbf9d4cdb  lea rdi, [rsp]
00007b1fbf9d4cdf  mov esi, 0x00
00007b1fbf9d4ce4  mov rax, 0x64AEE5F12530
00007b1fbf9d4cee  call rax
00007b1fbf9d4cf0  movaps xmm14, [rsp]
00007b1fbf9d4cf5  add rsp, 0x30
00007b1fbf9d4cf9  vmovaps xmm0, [rsp]
00007b1fbf9d4cfe  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d4d04  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d4d0a  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d4d10  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d4d16  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d4d1c  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d4d22  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d4d28  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d4d31  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d4d3a  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9d4d43  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9d4d4c  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9d4d55  vmovaps xmm13, [rsp+0xD0]
00007b1fbf9d4d5e  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d4d67  add rsp, 0xF0
00007b1fbf9d4d6e  pop r11
00007b1fbf9d4d70  pop r10
00007b1fbf9d4d72  pop r9
00007b1fbf9d4d74  pop r8
00007b1fbf9d4d76  pop rsi
00007b1fbf9d4d77  pop rdi
00007b1fbf9d4d78  pop rdx
00007b1fbf9d4d79  pop rcx
00007b1fbf9d4d7a  pop rax
00007b1fbf9d4d7b  add rsp, 0x08
00007b1fbf9d4d7f  jmp 0x00007B1FBF9D0203
00007b1fbf9d4d84  sub rsp, 0x08
00007b1fbf9d4d88  push rax
00007b1fbf9d4d89  push rcx
00007b1fbf9d4d8a  push rdx
00007b1fbf9d4d8b  push rdi
00007b1fbf9d4d8c  push rsi
00007b1fbf9d4d8d  push r8
00007b1fbf9d4d8f  push r9
00007b1fbf9d4d91  push r10
00007b1fbf9d4d93  push r11
00007b1fbf9d4d95  sub rsp, 0xF0
00007b1fbf9d4d9c  vmovaps [rsp], xmm0
00007b1fbf9d4da1  vmovaps [rsp+0x10], xmm2
00007b1fbf9d4da7  vmovaps [rsp+0x20], xmm3
00007b1fbf9d4dad  vmovaps [rsp+0x30], xmm4
00007b1fbf9d4db3  vmovaps [rsp+0x40], xmm5
00007b1fbf9d4db9  vmovaps [rsp+0x50], xmm6
00007b1fbf9d4dbf  vmovaps [rsp+0x60], xmm7
00007b1fbf9d4dc5  vmovaps [rsp+0x70], xmm8
00007b1fbf9d4dcb  vmovaps [rsp+0x80], xmm9
00007b1fbf9d4dd4  vmovaps [rsp+0x90], xmm10
00007b1fbf9d4ddd  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d4de6  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d4def  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d4df8  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d4e01  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d4e0a  sub rsp, 0x30
00007b1fbf9d4e0e  movaps [rsp], xmm1
00007b1fbf9d4e12  movaps [rsp+0x10], xmm12
00007b1fbf9d4e18  movaps [rsp+0x20], xmm11
00007b1fbf9d4e1e  lea rdi, [rsp]
00007b1fbf9d4e22  mov esi, 0x00
00007b1fbf9d4e27  mov rax, 0x64AEE5F12530
00007b1fbf9d4e31  call rax
00007b1fbf9d4e33  movaps xmm1, [rsp]
00007b1fbf9d4e37  add rsp, 0x30
00007b1fbf9d4e3b  vmovaps xmm0, [rsp]
00007b1fbf9d4e40  vmovaps xmm2, [rsp+0x10]
00007b1fbf9d4e46  vmovaps xmm3, [rsp+0x20]
00007b1fbf9d4e4c  vmovaps xmm4, [rsp+0x30]
00007b1fbf9d4e52  vmovaps xmm5, [rsp+0x40]
00007b1fbf9d4e58  vmovaps xmm6, [rsp+0x50]
00007b1fbf9d4e5e  vmovaps xmm7, [rsp+0x60]
00007b1fbf9d4e64  vmovaps xmm8, [rsp+0x70]
00007b1fbf9d4e6a  vmovaps xmm9, [rsp+0x80]
00007b1fbf9d4e73  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d4e7c  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d4e85  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d4e8e  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d4e97  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d4ea0  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d4ea9  add rsp, 0xF0
00007b1fbf9d4eb0  pop r11
00007b1fbf9d4eb2  pop r10
00007b1fbf9d4eb4  pop r9
00007b1fbf9d4eb6  pop r8
00007b1fbf9d4eb8  pop rsi
00007b1fbf9d4eb9  pop rdi
00007b1fbf9d4eba  pop rdx
00007b1fbf9d4ebb  pop rcx
00007b1fbf9d4ebc  pop rax
00007b1fbf9d4ebd  add rsp, 0x08
00007b1fbf9d4ec1  jmp 0x00007B1FBF9D0224
00007b1fbf9d4ec6  call 0x00007B1FBF8E20A0
00007b1fbf9d4ecb  jmp 0x00007B1FBF9D0232
00007b1fbf9d4ed0  call 0x00007B1FBF809D70
00007b1fbf9d4ed5  jmp 0x00007B1FBF9D023C
00007b1fbf9d4eda  sub rsp, 0x08
00007b1fbf9d4ede  push rax
00007b1fbf9d4edf  push rcx
00007b1fbf9d4ee0  push rdx
00007b1fbf9d4ee1  push rdi
00007b1fbf9d4ee2  push rsi
00007b1fbf9d4ee3  push r8
00007b1fbf9d4ee5  push r9
00007b1fbf9d4ee7  push r10
00007b1fbf9d4ee9  push r11
00007b1fbf9d4eeb  sub rsp, 0xF0
00007b1fbf9d4ef2  vmovaps [rsp], xmm0
00007b1fbf9d4ef7  vmovaps [rsp+0x10], xmm1
00007b1fbf9d4efd  vmovaps [rsp+0x20], xmm2
00007b1fbf9d4f03  vmovaps [rsp+0x30], xmm3
00007b1fbf9d4f09  vmovaps [rsp+0x40], xmm4
00007b1fbf9d4f0f  vmovaps [rsp+0x50], xmm5
00007b1fbf9d4f15  vmovaps [rsp+0x60], xmm6
00007b1fbf9d4f1b  vmovaps [rsp+0x70], xmm8
00007b1fbf9d4f21  vmovaps [rsp+0x80], xmm9
00007b1fbf9d4f2a  vmovaps [rsp+0x90], xmm10
00007b1fbf9d4f33  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d4f3c  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d4f45  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d4f4e  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d4f57  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d4f60  sub rsp, 0x30
00007b1fbf9d4f64  movaps [rsp], xmm7
00007b1fbf9d4f68  movaps [rsp+0x10], xmm15
00007b1fbf9d4f6e  movaps [rsp+0x20], xmm10
00007b1fbf9d4f74  lea rdi, [rsp]
00007b1fbf9d4f78  mov esi, 0x00
00007b1fbf9d4f7d  mov rax, 0x64AEE5F12530
00007b1fbf9d4f87  call rax
00007b1fbf9d4f89  movaps xmm7, [rsp]
00007b1fbf9d4f8d  add rsp, 0x30
00007b1fbf9d4f91  vmovaps xmm0, [rsp]
00007b1fbf9d4f96  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d4f9c  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d4fa2  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d4fa8  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d4fae  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d4fb4  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d4fba  vmovaps xmm8, [rsp+0x70]
00007b1fbf9d4fc0  vmovaps xmm9, [rsp+0x80]
00007b1fbf9d4fc9  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d4fd2  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d4fdb  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d4fe4  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d4fed  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d4ff6  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d4fff  add rsp, 0xF0
00007b1fbf9d5006  pop r11
00007b1fbf9d5008  pop r10
00007b1fbf9d500a  pop r9
00007b1fbf9d500c  pop r8
00007b1fbf9d500e  pop rsi
00007b1fbf9d500f  pop rdi
00007b1fbf9d5010  pop rdx
00007b1fbf9d5011  pop rcx
00007b1fbf9d5012  pop rax
00007b1fbf9d5013  add rsp, 0x08
00007b1fbf9d5017  jmp 0x00007B1FBF9D025D
00007b1fbf9d501c  sub rsp, 0x08
00007b1fbf9d5020  push rax
00007b1fbf9d5021  push rcx
00007b1fbf9d5022  push rdx
00007b1fbf9d5023  push rdi
00007b1fbf9d5024  push rsi
00007b1fbf9d5025  push r8
00007b1fbf9d5027  push r9
00007b1fbf9d5029  push r10
00007b1fbf9d502b  push r11
00007b1fbf9d502d  sub rsp, 0xF0
00007b1fbf9d5034  vmovaps [rsp], xmm0
00007b1fbf9d5039  vmovaps [rsp+0x10], xmm1
00007b1fbf9d503f  vmovaps [rsp+0x20], xmm2
00007b1fbf9d5045  vmovaps [rsp+0x30], xmm3
00007b1fbf9d504b  vmovaps [rsp+0x40], xmm4
00007b1fbf9d5051  vmovaps [rsp+0x50], xmm5
00007b1fbf9d5057  vmovaps [rsp+0x60], xmm6
00007b1fbf9d505d  vmovaps [rsp+0x70], xmm7
00007b1fbf9d5063  vmovaps [rsp+0x80], xmm8
00007b1fbf9d506c  vmovaps [rsp+0x90], xmm9
00007b1fbf9d5075  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d507e  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d5087  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d5090  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d5099  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d50a2  sub rsp, 0x30
00007b1fbf9d50a6  movaps [rsp], xmm10
00007b1fbf9d50ab  movaps [rsp+0x10], xmm11
00007b1fbf9d50b1  movaps [rsp+0x20], xmm15
00007b1fbf9d50b7  lea rdi, [rsp]
00007b1fbf9d50bb  mov esi, 0x00
00007b1fbf9d50c0  mov rax, 0x64AEE5F12530
00007b1fbf9d50ca  call rax
00007b1fbf9d50cc  movaps xmm10, [rsp]
00007b1fbf9d50d1  add rsp, 0x30
00007b1fbf9d50d5  vmovaps xmm0, [rsp]
00007b1fbf9d50da  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d50e0  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d50e6  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d50ec  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d50f2  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d50f8  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d50fe  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d5104  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d510d  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d5116  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d511f  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d5128  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d5131  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d513a  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d5143  add rsp, 0xF0
00007b1fbf9d514a  pop r11
00007b1fbf9d514c  pop r10
00007b1fbf9d514e  pop r9
00007b1fbf9d5150  pop r8
00007b1fbf9d5152  pop rsi
00007b1fbf9d5153  pop rdi
00007b1fbf9d5154  pop rdx
00007b1fbf9d5155  pop rcx
00007b1fbf9d5156  pop rax
00007b1fbf9d5157  add rsp, 0x08
00007b1fbf9d515b  jmp 0x00007B1FBF9D028B
00007b1fbf9d5160  sub rsp, 0x08
00007b1fbf9d5164  push rax
00007b1fbf9d5165  push rcx
00007b1fbf9d5166  push rdx
00007b1fbf9d5167  push rdi
00007b1fbf9d5168  push rsi
00007b1fbf9d5169  push r8
00007b1fbf9d516b  push r9
00007b1fbf9d516d  push r10
00007b1fbf9d516f  push r11
00007b1fbf9d5171  sub rsp, 0xF0
00007b1fbf9d5178  vmovaps [rsp], xmm0
00007b1fbf9d517d  vmovaps [rsp+0x10], xmm1
00007b1fbf9d5183  vmovaps [rsp+0x20], xmm2
00007b1fbf9d5189  vmovaps [rsp+0x30], xmm3
00007b1fbf9d518f  vmovaps [rsp+0x40], xmm4
00007b1fbf9d5195  vmovaps [rsp+0x50], xmm5
00007b1fbf9d519b  vmovaps [rsp+0x60], xmm6
00007b1fbf9d51a1  vmovaps [rsp+0x70], xmm7
00007b1fbf9d51a7  vmovaps [rsp+0x80], xmm8
00007b1fbf9d51b0  vmovaps [rsp+0x90], xmm9
00007b1fbf9d51b9  vmovaps [rsp+0xA0], xmm10
00007b1fbf9d51c2  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d51cb  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d51d4  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d51dd  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d51e6  sub rsp, 0x30
00007b1fbf9d51ea  movaps [rsp], xmm11
00007b1fbf9d51ef  movaps [rsp+0x10], xmm12
00007b1fbf9d51f5  movaps [rsp+0x20], xmm15
00007b1fbf9d51fb  lea rdi, [rsp]
00007b1fbf9d51ff  mov esi, 0x00
00007b1fbf9d5204  mov rax, 0x64AEE5F12530
00007b1fbf9d520e  call rax
00007b1fbf9d5210  movaps xmm11, [rsp]
00007b1fbf9d5215  add rsp, 0x30
00007b1fbf9d5219  vmovaps xmm0, [rsp]
00007b1fbf9d521e  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d5224  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d522a  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d5230  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d5236  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d523c  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d5242  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d5248  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d5251  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d525a  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9d5263  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d526c  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d5275  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d527e  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d5287  add rsp, 0xF0
00007b1fbf9d528e  pop r11
00007b1fbf9d5290  pop r10
00007b1fbf9d5292  pop r9
00007b1fbf9d5294  pop r8
00007b1fbf9d5296  pop rsi
00007b1fbf9d5297  pop rdi
00007b1fbf9d5298  pop rdx
00007b1fbf9d5299  pop rcx
00007b1fbf9d529a  pop rax
00007b1fbf9d529b  add rsp, 0x08
00007b1fbf9d529f  jmp 0x00007B1FBF9D02B9
00007b1fbf9d52a4  sub rsp, 0x08
00007b1fbf9d52a8  push rax
00007b1fbf9d52a9  push rcx
00007b1fbf9d52aa  push rdx
00007b1fbf9d52ab  push rdi
00007b1fbf9d52ac  push rsi
00007b1fbf9d52ad  push r8
00007b1fbf9d52af  push r9
00007b1fbf9d52b1  push r10
00007b1fbf9d52b3  push r11
00007b1fbf9d52b5  sub rsp, 0xF0
00007b1fbf9d52bc  vmovaps [rsp], xmm0
00007b1fbf9d52c1  vmovaps [rsp+0x10], xmm1
00007b1fbf9d52c7  vmovaps [rsp+0x20], xmm2
00007b1fbf9d52cd  vmovaps [rsp+0x30], xmm3
00007b1fbf9d52d3  vmovaps [rsp+0x40], xmm4
00007b1fbf9d52d9  vmovaps [rsp+0x50], xmm5
00007b1fbf9d52df  vmovaps [rsp+0x60], xmm6
00007b1fbf9d52e5  vmovaps [rsp+0x70], xmm7
00007b1fbf9d52eb  vmovaps [rsp+0x80], xmm8
00007b1fbf9d52f4  vmovaps [rsp+0x90], xmm9
00007b1fbf9d52fd  vmovaps [rsp+0xA0], xmm10
00007b1fbf9d5306  vmovaps [rsp+0xB0], xmm11
00007b1fbf9d530f  vmovaps [rsp+0xC0], xmm12
00007b1fbf9d5318  vmovaps [rsp+0xD0], xmm13
00007b1fbf9d5321  vmovaps [rsp+0xE0], xmm14
00007b1fbf9d532a  sub rsp, 0x30
00007b1fbf9d532e  movaps [rsp], xmm15
00007b1fbf9d5333  movaps [rsp+0x10], xmm13
00007b1fbf9d5339  movaps [rsp+0x20], xmm9
00007b1fbf9d533f  lea rdi, [rsp]
00007b1fbf9d5343  mov esi, 0x00
00007b1fbf9d5348  mov rax, 0x64AEE5F12530
00007b1fbf9d5352  call rax
00007b1fbf9d5354  movaps xmm15, [rsp]
00007b1fbf9d5359  add rsp, 0x30
00007b1fbf9d535d  vmovaps xmm0, [rsp]
00007b1fbf9d5362  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d5368  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d536e  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d5374  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d537a  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d5380  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d5386  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d538c  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d5395  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d539e  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9d53a7  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9d53b0  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9d53b9  vmovaps xmm13, [rsp+0xD0]
00007b1fbf9d53c2  vmovaps xmm14, [rsp+0xE0]
00007b1fbf9d53cb  add rsp, 0xF0
00007b1fbf9d53d2  pop r11
00007b1fbf9d53d4  pop r10
00007b1fbf9d53d6  pop r9
00007b1fbf9d53d8  pop r8
00007b1fbf9d53da  pop rsi
00007b1fbf9d53db  pop rdi
00007b1fbf9d53dc  pop rdx
00007b1fbf9d53dd  pop rcx
00007b1fbf9d53de  pop rax
00007b1fbf9d53df  add rsp, 0x08
00007b1fbf9d53e3  jmp 0x00007B1FBF9D02D4
00007b1fbf9d53e8  sub rsp, 0x08
00007b1fbf9d53ec  push rax
00007b1fbf9d53ed  push rcx
00007b1fbf9d53ee  push rdx
00007b1fbf9d53ef  push rdi
00007b1fbf9d53f0  push rsi
00007b1fbf9d53f1  push r8
00007b1fbf9d53f3  push r9
00007b1fbf9d53f5  push r10
00007b1fbf9d53f7  push r11
00007b1fbf9d53f9  sub rsp, 0xF0
00007b1fbf9d5400  vmovaps [rsp], xmm0
00007b1fbf9d5405  vmovaps [rsp+0x10], xmm1
00007b1fbf9d540b  vmovaps [rsp+0x20], xmm2
00007b1fbf9d5411  vmovaps [rsp+0x30], xmm3
00007b1fbf9d5417  vmovaps [rsp+0x40], xmm4
00007b1fbf9d541d  vmovaps [rsp+0x50], xmm5
00007b1fbf9d5423  vmovaps [rsp+0x60], xmm6
00007b1fbf9d5429  vmovaps [rsp+0x70], xmm7
00007b1fbf9d542f  vmovaps [rsp+0x80], xmm8
00007b1fbf9d5438  vmovaps [rsp+0x90], xmm9
00007b1fbf9d5441  vmovaps [rsp+0xA0], xmm10
00007b1fbf9d544a  vmovaps [rsp+0xB0], xmm11
00007b1fbf9d5453  vmovaps [rsp+0xC0], xmm12
00007b1fbf9d545c  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d5465  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d546e  sub rsp, 0x30
00007b1fbf9d5472  movaps [rsp], xmm13
00007b1fbf9d5477  movaps [rsp+0x10], xmm8
00007b1fbf9d547d  movaps [rsp+0x20], xmm14
00007b1fbf9d5483  lea rdi, [rsp]
00007b1fbf9d5487  mov esi, 0x00
00007b1fbf9d548c  mov rax, 0x64AEE5F12530
00007b1fbf9d5496  call rax
00007b1fbf9d5498  movaps xmm13, [rsp]
00007b1fbf9d549d  add rsp, 0x30
00007b1fbf9d54a1  vmovaps xmm0, [rsp]
00007b1fbf9d54a6  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d54ac  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d54b2  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d54b8  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d54be  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d54c4  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d54ca  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d54d0  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d54d9  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d54e2  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9d54eb  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9d54f4  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9d54fd  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d5506  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d550f  add rsp, 0xF0
00007b1fbf9d5516  pop r11
00007b1fbf9d5518  pop r10
00007b1fbf9d551a  pop r9
00007b1fbf9d551c  pop r8
00007b1fbf9d551e  pop rsi
00007b1fbf9d551f  pop rdi
00007b1fbf9d5520  pop rdx
00007b1fbf9d5521  pop rcx
00007b1fbf9d5522  pop rax
00007b1fbf9d5523  add rsp, 0x08
00007b1fbf9d5527  jmp 0x00007B1FBF9D02F7
00007b1fbf9d552c  sub rsp, 0x08
00007b1fbf9d5530  push rax
00007b1fbf9d5531  push rcx
00007b1fbf9d5532  push rdx
00007b1fbf9d5533  push rdi
00007b1fbf9d5534  push rsi
00007b1fbf9d5535  push r8
00007b1fbf9d5537  push r9
00007b1fbf9d5539  push r10
00007b1fbf9d553b  push r11
00007b1fbf9d553d  sub rsp, 0xF0
00007b1fbf9d5544  vmovaps [rsp], xmm0
00007b1fbf9d5549  vmovaps [rsp+0x10], xmm1
00007b1fbf9d554f  vmovaps [rsp+0x20], xmm2
00007b1fbf9d5555  vmovaps [rsp+0x30], xmm3
00007b1fbf9d555b  vmovaps [rsp+0x40], xmm4
00007b1fbf9d5561  vmovaps [rsp+0x50], xmm5
00007b1fbf9d5567  vmovaps [rsp+0x60], xmm6
00007b1fbf9d556d  vmovaps [rsp+0x70], xmm7
00007b1fbf9d5573  vmovaps [rsp+0x80], xmm8
00007b1fbf9d557c  vmovaps [rsp+0x90], xmm9
00007b1fbf9d5585  vmovaps [rsp+0xA0], xmm10
00007b1fbf9d558e  vmovaps [rsp+0xB0], xmm11
00007b1fbf9d5597  vmovaps [rsp+0xC0], xmm12
00007b1fbf9d55a0  vmovaps [rsp+0xD0], xmm13
00007b1fbf9d55a9  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d55b2  sub rsp, 0x30
00007b1fbf9d55b6  movaps [rsp], xmm14
00007b1fbf9d55bb  movaps [rsp+0x10], xmm1
00007b1fbf9d55c0  movaps [rsp+0x20], xmm10
00007b1fbf9d55c6  lea rdi, [rsp]
00007b1fbf9d55ca  mov esi, 0x00
00007b1fbf9d55cf  mov rax, 0x64AEE5F12530
00007b1fbf9d55d9  call rax
00007b1fbf9d55db  movaps xmm14, [rsp]
00007b1fbf9d55e0  add rsp, 0x30
00007b1fbf9d55e4  vmovaps xmm0, [rsp]
00007b1fbf9d55e9  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d55ef  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d55f5  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d55fb  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d5601  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d5607  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d560d  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d5613  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d561c  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d5625  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9d562e  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9d5637  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9d5640  vmovaps xmm13, [rsp+0xD0]
00007b1fbf9d5649  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d5652  add rsp, 0xF0
00007b1fbf9d5659  pop r11
00007b1fbf9d565b  pop r10
00007b1fbf9d565d  pop r9
00007b1fbf9d565f  pop r8
00007b1fbf9d5661  pop rsi
00007b1fbf9d5662  pop rdi
00007b1fbf9d5663  pop rdx
00007b1fbf9d5664  pop rcx
00007b1fbf9d5665  pop rax
00007b1fbf9d5666  add rsp, 0x08
00007b1fbf9d566a  jmp 0x00007B1FBF9D031A
00007b1fbf9d566f  sub rsp, 0x08
00007b1fbf9d5673  push rax
00007b1fbf9d5674  push rcx
00007b1fbf9d5675  push rdx
00007b1fbf9d5676  push rdi
00007b1fbf9d5677  push rsi
00007b1fbf9d5678  push r8
00007b1fbf9d567a  push r9
00007b1fbf9d567c  push r10
00007b1fbf9d567e  push r11
00007b1fbf9d5680  sub rsp, 0xF0
00007b1fbf9d5687  vmovaps [rsp], xmm0
00007b1fbf9d568c  vmovaps [rsp+0x10], xmm2
00007b1fbf9d5692  vmovaps [rsp+0x20], xmm3
00007b1fbf9d5698  vmovaps [rsp+0x30], xmm4
00007b1fbf9d569e  vmovaps [rsp+0x40], xmm5
00007b1fbf9d56a4  vmovaps [rsp+0x50], xmm6
00007b1fbf9d56aa  vmovaps [rsp+0x60], xmm7
00007b1fbf9d56b0  vmovaps [rsp+0x70], xmm8
00007b1fbf9d56b6  vmovaps [rsp+0x80], xmm9
00007b1fbf9d56bf  vmovaps [rsp+0x90], xmm10
00007b1fbf9d56c8  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d56d1  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d56da  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d56e3  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d56ec  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d56f5  sub rsp, 0x30
00007b1fbf9d56f9  movaps [rsp], xmm1
00007b1fbf9d56fd  movaps [rsp+0x10], xmm7
00007b1fbf9d5702  movaps [rsp+0x20], xmm11
00007b1fbf9d5708  lea rdi, [rsp]
00007b1fbf9d570c  mov esi, 0x00
00007b1fbf9d5711  mov rax, 0x64AEE5F12530
00007b1fbf9d571b  call rax
00007b1fbf9d571d  movaps xmm1, [rsp]
00007b1fbf9d5721  add rsp, 0x30
00007b1fbf9d5725  vmovaps xmm0, [rsp]
00007b1fbf9d572a  vmovaps xmm2, [rsp+0x10]
00007b1fbf9d5730  vmovaps xmm3, [rsp+0x20]
00007b1fbf9d5736  vmovaps xmm4, [rsp+0x30]
00007b1fbf9d573c  vmovaps xmm5, [rsp+0x40]
00007b1fbf9d5742  vmovaps xmm6, [rsp+0x50]
00007b1fbf9d5748  vmovaps xmm7, [rsp+0x60]
00007b1fbf9d574e  vmovaps xmm8, [rsp+0x70]
00007b1fbf9d5754  vmovaps xmm9, [rsp+0x80]
00007b1fbf9d575d  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d5766  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d576f  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d5778  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d5781  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d578a  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d5793  add rsp, 0xF0
00007b1fbf9d579a  pop r11
00007b1fbf9d579c  pop r10
00007b1fbf9d579e  pop r9
00007b1fbf9d57a0  pop r8
00007b1fbf9d57a2  pop rsi
00007b1fbf9d57a3  pop rdi
00007b1fbf9d57a4  pop rdx
00007b1fbf9d57a5  pop rcx
00007b1fbf9d57a6  pop rax
00007b1fbf9d57a7  add rsp, 0x08
00007b1fbf9d57ab  jmp 0x00007B1FBF9D033B
00007b1fbf9d57b0  call 0x00007B1FBF80E880
00007b1fbf9d57b5  jmp 0x00007B1FBF9D034E
00007b1fbf9d57ba  call 0x00007B1FBF80C380
00007b1fbf9d57bf  jmp 0x00007B1FBF9D0359
00007b1fbf9d57c4  call 0x00007B1FBF80D600
00007b1fbf9d57c9  jmp 0x00007B1FBF9D0364
00007b1fbf9d57ce  call 0x00007B1FBF7FF540
00007b1fbf9d57d3  jmp 0x00007B1FBF9D036F
00007b1fbf9d57d8  int3
00007b1fbf9d57d9  nop [rax], eax
00007b1fbf9d57e0  mov rax, [r15+0x40]
00007b1fbf9d57e4  mov r14, [r15+0x58]
00007b1fbf9d57e8  lea r12, [rax+r14*1]
00007b1fbf9d57ec  movaps xmm1, [r15+0x1D0]
00007b1fbf9d57f4  vmovaps [rsp+0x10], xmm1
00007b1fbf9d57fa  vmovaps xmm15, [rsp+0x10]
00007b1fbf9d5800  por xmm1, xmm15
00007b1fbf9d5805  movaps xmm14, [r15+0x1A0]
00007b1fbf9d580d  vmovaps [rsp+0x10], xmm14
00007b1fbf9d5813  vmovaps xmm13, [rsp+0x10]
00007b1fbf9d5819  por xmm14, xmm13
00007b1fbf9d581e  lea rax, [r12+0x30]
00007b1fbf9d5823  mov r11, [r13+rax*1]
00007b1fbf9d5828  lea rax, [r12+0x38]
00007b1fbf9d582d  mov r10, [r13+rax*1]
00007b1fbf9d5832  movq xmm13, r11
00007b1fbf9d5837  movq xmm12, r10
00007b1fbf9d583c  movq xmm13, xmm13
00007b1fbf9d5841  vmovaps [rsp+0x10], xmm13
00007b1fbf9d5847  movq xmm13, xmm13
00007b1fbf9d584c  movaps [r15+0x130], xmm13
00007b1fbf9d5854  movq xmm12, xmm12
00007b1fbf9d5859  vmovaps [rsp+0x20], xmm12
00007b1fbf9d585f  movq xmm12, xmm12
00007b1fbf9d5864  movaps [r15+0x280], xmm12
00007b1fbf9d586c  movaps xmm13, [r15+0x270]
00007b1fbf9d5874  vmovaps [rsp+0x30], xmm13
00007b1fbf9d587a  vmovaps xmm12, [rsp+0x30]
00007b1fbf9d5880  por xmm13, xmm12
00007b1fbf9d5885  lea rax, [r12+0x20]
00007b1fbf9d588a  mov r11, [r13+rax*1]
00007b1fbf9d588f  lea rax, [r12+0x28]
00007b1fbf9d5894  mov r10, [r13+rax*1]
00007b1fbf9d5899  movq xmm12, r11
00007b1fbf9d589e  movq xmm11, r10
00007b1fbf9d58a3  movq xmm12, xmm12
00007b1fbf9d58a8  vmovaps [rsp+0x30], xmm12
00007b1fbf9d58ae  movq xmm12, xmm12
00007b1fbf9d58b3  movaps [r15+0x150], xmm12
00007b1fbf9d58bb  movq xmm11, xmm11
00007b1fbf9d58c0  vmovaps [rsp+0x40], xmm11
00007b1fbf9d58c6  movq xmm11, xmm11
00007b1fbf9d58cb  movaps [r15+0x140], xmm11
00007b1fbf9d58d3  lea rax, [r12+0x10]
00007b1fbf9d58d8  mov r11, [r13+rax*1]
00007b1fbf9d58dd  lea rax, [r12+0x18]
00007b1fbf9d58e2  mov r10, [r13+rax*1]
00007b1fbf9d58e7  movq xmm12, r11
00007b1fbf9d58ec  movq xmm11, r10
00007b1fbf9d58f1  movq xmm12, xmm12
00007b1fbf9d58f6  vmovaps [rsp+0x50], xmm12
00007b1fbf9d58fc  movq xmm12, xmm12
00007b1fbf9d5901  movaps [r15+0x170], xmm12
00007b1fbf9d5909  movq xmm11, xmm11
00007b1fbf9d590e  vmovaps [rsp+0x60], xmm11
00007b1fbf9d5914  movq xmm11, xmm11
00007b1fbf9d5919  movaps [r15+0x160], xmm11
00007b1fbf9d5921  mov rax, [r13+r12*1]
00007b1fbf9d5926  vmovq xmm12, rax
00007b1fbf9d592b  vpbroadcastq xmm12, xmm12
00007b1fbf9d5930  lea rax, [r12+0x08]
00007b1fbf9d5935  mov r12, [r13+rax*1]
00007b1fbf9d593a  movq xmm11, r12
00007b1fbf9d593f  movaps [r15+0x230], xmm11
00007b1fbf9d5947  mov rax, [r15+0xF8]
00007b1fbf9d594e  lea r12, [rax+0x50]
00007b1fbf9d5952  movups xmm11, [r13+r12*1]
00007b1fbf9d5958  lea r12, [rax+0x60]
00007b1fbf9d595c  movups xmm10, [r13+r12*1]
00007b1fbf9d5962  lea r12, [rax+0x30]
00007b1fbf9d5966  movups xmm9, [r13+r12*1]
00007b1fbf9d596c  mov r12, [r15+0x50]
00007b1fbf9d5970  lea r11, [r12+r14*1]
00007b1fbf9d5974  mov [r15+0x60], r11
00007b1fbf9d5978  lea r12, [r14+0x40]
00007b1fbf9d597c  mov [r15+0x58], r12
00007b1fbf9d5980  movaps xmm8, xmm12
00007b1fbf9d5984  mulpd xmm8, xmm15
00007b1fbf9d5989  vcmppd xmm7, xmm8, xmm8, 0x03
00007b1fbf9d598f  ptest xmm7, xmm7
00007b1fbf9d5994  jnz 0x00007B1FBF9D67B7
00007b1fbf9d599a  movq xmm15, qword ptr [r15+0x230]
00007b1fbf9d59a3  vmovaps [rsp+0x70], xmm15
00007b1fbf9d59a9  vpermilpd xmm15, xmm15, 0x00
00007b1fbf9d59af  movaps xmm7, xmm9
00007b1fbf9d59b3  mulpd xmm7, xmm15
00007b1fbf9d59b8  vcmppd xmm6, xmm7, xmm7, 0x03
00007b1fbf9d59bd  ptest xmm6, xmm6
00007b1fbf9d59c2  jnz 0x00007B1FBF9D68FB
00007b1fbf9d59c8  vxorps xmm15, xmm15, xmm15
00007b1fbf9d59cd  vpbroadcastq xmm15, xmm15
00007b1fbf9d59d2  movaps xmm9, xmm12
00007b1fbf9d59d6  mulpd xmm9, xmm10
00007b1fbf9d59db  vcmppd xmm6, xmm9, xmm9, 0x03
00007b1fbf9d59e1  ptest xmm6, xmm6
00007b1fbf9d59e6  jnz 0x00007B1FBF9D6A3D
00007b1fbf9d59ec  movaps xmm10, xmm12
00007b1fbf9d59f0  mulpd xmm10, xmm11
00007b1fbf9d59f5  vcmppd xmm6, xmm10, xmm10, 0x03
00007b1fbf9d59fb  ptest xmm6, xmm6
00007b1fbf9d5a00  jnz 0x00007B1FBF9D6B81
00007b1fbf9d5a06  movaps xmm11, [r15+0x1F0]
00007b1fbf9d5a0e  movaps xmm6, xmm12
00007b1fbf9d5a12  mulpd xmm6, xmm11
00007b1fbf9d5a17  vcmppd xmm5, xmm6, xmm6, 0x03
00007b1fbf9d5a1c  ptest xmm5, xmm5
00007b1fbf9d5a21  jnz 0x00007B1FBF9D6CC5
00007b1fbf9d5a27  movaps xmm12, [r15+0x2A0]
00007b1fbf9d5a2f  vmovaps [rsp+0x80], xmm12
00007b1fbf9d5a38  vmovaps xmm11, [rsp+0x80]
00007b1fbf9d5a41  por xmm12, xmm11
00007b1fbf9d5a46  movaps xmm11, [r15+0x250]
00007b1fbf9d5a4e  vmovaps [rsp+0x80], xmm11
00007b1fbf9d5a57  vmovaps xmm5, [rsp+0x80]
00007b1fbf9d5a60  por xmm11, xmm5
00007b1fbf9d5a65  vmovaps xmm4, [rsp+0x70]
00007b1fbf9d5a6b  vpermilpd xmm4, xmm4, 0x00
00007b1fbf9d5a71  movaps xmm3, xmm5
00007b1fbf9d5a74  mulpd xmm3, xmm4
00007b1fbf9d5a78  vcmppd xmm2, xmm3, xmm3, 0x03
00007b1fbf9d5a7d  ptest xmm2, xmm2
00007b1fbf9d5a82  jnz 0x00007B1FBF9D6E07
00007b1fbf9d5a88  mov [rsp+0x80], rax
00007b1fbf9d5a90  xor eax, eax
00007b1fbf9d5a92  mov r14d, 0x200
00007b1fbf9d5a98  cmp r12, r14
00007b1fbf9d5a9b  cmc
00007b1fbf9d5a9c  lahf
00007b1fbf9d5a9d  seto al
00007b1fbf9d5aa0  mov [r15+0x108], eax
00007b1fbf9d5aa7  movaps xmm5, xmm8
00007b1fbf9d5aab  addpd xmm5, xmm15
00007b1fbf9d5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
00007b1fbf9d5ab5  ptest xmm4, xmm4
00007b1fbf9d5aba  jnz 0x00007B1FBF9D6F47
00007b1fbf9d5ac0  movaps xmm8, [r15+0x1B0]
00007b1fbf9d5ac8  movaps xmm4, xmm9
00007b1fbf9d5acc  addpd xmm4, xmm8
00007b1fbf9d5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
00007b1fbf9d5ad6  ptest xmm2, xmm2
00007b1fbf9d5adb  jnz 0x00007B1FBF9D7089
00007b1fbf9d5ae1  movaps xmm9, xmm10
00007b1fbf9d5ae5  addpd xmm9, xmm8
00007b1fbf9d5aea  vcmppd xmm2, xmm9, xmm9, 0x03
00007b1fbf9d5af0  ptest xmm2, xmm2
00007b1fbf9d5af5  jnz 0x00007B1FBF9D71CB
00007b1fbf9d5afb  movaps xmm10, [r15+0x2F0]
00007b1fbf9d5b03  vmovaps [rsp+0x90], xmm10
00007b1fbf9d5b0c  vmovaps xmm8, [rsp+0x90]
00007b1fbf9d5b15  por xmm10, xmm8
00007b1fbf9d5b1a  movaps xmm8, [r15+0x2E0]
00007b1fbf9d5b22  vmovaps [rsp+0x90], xmm8
00007b1fbf9d5b2b  vmovaps xmm2, [rsp+0x90]
00007b1fbf9d5b34  por xmm8, xmm2
00007b1fbf9d5b39  movaps xmm2, [r15+0x2D0]
00007b1fbf9d5b41  vmovaps [rsp+0x90], xmm2
00007b1fbf9d5b4a  vmovaps [rsp+0xA0], xmm1
00007b1fbf9d5b53  vmovaps xmm1, [rsp+0x90]
00007b1fbf9d5b5c  por xmm2, xmm1
00007b1fbf9d5b60  movaps xmm1, [r15+0x200]
00007b1fbf9d5b68  vmovaps [rsp+0x90], xmm1
00007b1fbf9d5b71  vmovaps [rsp+0xB0], xmm15
00007b1fbf9d5b7a  vmovaps xmm15, [rsp+0x90]
00007b1fbf9d5b83  por xmm1, xmm15
00007b1fbf9d5b88  movaps xmm15, [r15+0x1C0]
00007b1fbf9d5b90  vmovaps [rsp+0x90], xmm15
00007b1fbf9d5b99  vmovaps [rsp+0xC0], xmm1
00007b1fbf9d5ba2  vmovaps xmm1, [rsp+0x90]
00007b1fbf9d5bab  por xmm15, xmm1
00007b1fbf9d5bb0  movaps xmm1, [r15+0x190]
00007b1fbf9d5bb8  vmovaps [rsp+0x90], xmm1
00007b1fbf9d5bc1  vmovaps [rsp+0xD0], xmm15
00007b1fbf9d5bca  vmovaps xmm15, [rsp+0x90]
00007b1fbf9d5bd3  por xmm1, xmm15
00007b1fbf9d5bd8  movaps xmm15, [r15+0x300]
00007b1fbf9d5be0  vmovaps [rsp+0x90], xmm15
00007b1fbf9d5be9  vmovaps [rsp+0xE0], xmm1
00007b1fbf9d5bf2  vmovaps xmm1, [rsp+0x90]
00007b1fbf9d5bfb  por xmm15, xmm1
00007b1fbf9d5c00  mov rax, [rsp+0x80]
00007b1fbf9d5c08  lea r14, [rax+0xA0]
00007b1fbf9d5c0f  movups xmm1, [r13+r14*1]
00007b1fbf9d5c15  lea r14, [rax+0xB0]
00007b1fbf9d5c1c  vmovaps [rsp+0x80], xmm1
00007b1fbf9d5c25  movups xmm1, [r13+r14*1]
00007b1fbf9d5c2b  vmovaps [rsp+0x90], xmm1
00007b1fbf9d5c34  vmovaps [rsp+0xF0], xmm15
00007b1fbf9d5c3d  vmovaps xmm15, [rsp+0xB0]
00007b1fbf9d5c46  vmovaps [rsp+0xB0], xmm14
00007b1fbf9d5c4f  movaps xmm1, xmm6
00007b1fbf9d5c52  addpd xmm1, xmm15
00007b1fbf9d5c57  vcmppd xmm14, xmm1, xmm1, 0x03
00007b1fbf9d5c5c  ptest xmm14, xmm14
00007b1fbf9d5c62  jnz 0x00007B1FBF9D7323
00007b1fbf9d5c68  lea r14, [rax+0xF0]
00007b1fbf9d5c6f  movups xmm15, [r13+r14*1]
00007b1fbf9d5c75  movaps xmm14, xmm4
00007b1fbf9d5c79  addpd xmm14, xmm3
00007b1fbf9d5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
00007b1fbf9d5c84  ptest xmm6, xmm6
00007b1fbf9d5c89  jnz 0x00007B1FBF9D746E
00007b1fbf9d5c8f  movaps xmm6, xmm9
00007b1fbf9d5c93  addpd xmm6, xmm7
00007b1fbf9d5c97  vcmppd xmm4, xmm6, xmm6, 0x03
00007b1fbf9d5c9c  ptest xmm4, xmm4
00007b1fbf9d5ca1  jnz 0x00007B1FBF9D75B0
00007b1fbf9d5ca7  vmovaps xmm9, [rsp+0x70]
00007b1fbf9d5cad  vpermilpd xmm9, xmm9, 0x00
00007b1fbf9d5cb3  vmovaps xmm4, [rsp+0x90]
00007b1fbf9d5cbc  movaps xmm7, xmm4
00007b1fbf9d5cbf  mulpd xmm7, xmm9
00007b1fbf9d5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
00007b1fbf9d5cc9  ptest xmm3, xmm3
00007b1fbf9d5cce  jnz 0x00007B1FBF9D76F1
00007b1fbf9d5cd4  vmovaps xmm9, [rsp+0x50]
00007b1fbf9d5cda  vpermilpd xmm9, xmm9, 0x00
00007b1fbf9d5ce0  movaps xmm4, xmm15
00007b1fbf9d5ce4  mulpd xmm4, xmm9
00007b1fbf9d5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
00007b1fbf9d5cee  ptest xmm3, xmm3
00007b1fbf9d5cf3  jnz 0x00007B1FBF9D7832
00007b1fbf9d5cf9  lea r14, [rax+0xE0]
00007b1fbf9d5d00  movups xmm15, [r13+r14*1]
00007b1fbf9d5d06  vmovaps xmm9, [rsp+0x70]
00007b1fbf9d5d0c  vpermilpd xmm9, xmm9, 0x00
00007b1fbf9d5d12  vmovaps [rsp+0x70], xmm1
00007b1fbf9d5d18  vmovaps xmm1, [rsp+0x80]
00007b1fbf9d5d21  vmovaps [rsp+0x80], xmm15
00007b1fbf9d5d2a  movaps xmm3, xmm1
00007b1fbf9d5d2d  mulpd xmm3, xmm9
00007b1fbf9d5d32  vcmppd xmm15, xmm3, xmm3, 0x03
00007b1fbf9d5d37  ptest xmm15, xmm15
00007b1fbf9d5d3d  jnz 0x00007B1FBF9D797E
00007b1fbf9d5d43  vmovaps xmm1, [rsp+0xF0]
00007b1fbf9d5d4c  vmovaps xmm15, [rsp+0xF0]
00007b1fbf9d5d55  por xmm1, xmm15
00007b1fbf9d5d5a  movaps [r15+0x300], xmm1
00007b1fbf9d5d62  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d5d6b  vmovaps xmm9, [rsp+0xE0]
00007b1fbf9d5d74  por xmm15, xmm9
00007b1fbf9d5d79  movaps [r15+0x190], xmm15
00007b1fbf9d5d81  vmovaps xmm9, [rsp+0x50]
00007b1fbf9d5d87  vpermilpd xmm9, xmm9, 0x00
00007b1fbf9d5d8d  vmovaps [rsp+0x90], xmm1
00007b1fbf9d5d96  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d5d9f  vmovaps xmm15, [rsp+0x80]
00007b1fbf9d5da8  vmovaps [rsp+0x80], xmm14
00007b1fbf9d5db1  movaps xmm1, xmm15
00007b1fbf9d5db5  mulpd xmm1, xmm9
00007b1fbf9d5dba  vcmppd xmm14, xmm1, xmm1, 0x03
00007b1fbf9d5dbf  ptest xmm14, xmm14
00007b1fbf9d5dc5  jnz 0x00007B1FBF9D7ABF
00007b1fbf9d5dcb  lea r14, [rax+0x90]
00007b1fbf9d5dd2  movups xmm15, [r13+r14*1]
00007b1fbf9d5dd8  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d5de1  vmovaps xmm9, [rsp+0xD0]
00007b1fbf9d5dea  por xmm14, xmm9
00007b1fbf9d5def  movaps [r15+0x1C0], xmm14
00007b1fbf9d5df7  vmovaps xmm9, [rsp+0xC0]
00007b1fbf9d5e00  vmovaps [rsp+0xD0], xmm1
00007b1fbf9d5e09  vmovaps xmm1, [rsp+0xC0]
00007b1fbf9d5e12  por xmm9, xmm1
00007b1fbf9d5e17  movaps [r15+0x200], xmm9
00007b1fbf9d5e1f  vmovaps [rsp+0xC0], xmm2
00007b1fbf9d5e28  vmovaps xmm1, [rsp+0xC0]
00007b1fbf9d5e31  por xmm2, xmm1
00007b1fbf9d5e35  movaps [r15+0x2D0], xmm2
00007b1fbf9d5e3d  vmovaps [rsp+0xC0], xmm8
00007b1fbf9d5e46  vmovaps xmm1, [rsp+0xC0]
00007b1fbf9d5e4f  por xmm8, xmm1
00007b1fbf9d5e54  movaps [r15+0x2E0], xmm8
00007b1fbf9d5e5c  vmovaps [rsp+0xC0], xmm15
00007b1fbf9d5e65  movaps xmm1, xmm5
00007b1fbf9d5e68  addpd xmm1, xmm7
00007b1fbf9d5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
00007b1fbf9d5e71  ptest xmm15, xmm15
00007b1fbf9d5e77  jnz 0x00007B1FBF9D7C0B
00007b1fbf9d5e7d  vmovaps xmm15, [rsp+0x50]
00007b1fbf9d5e83  vpermilpd xmm15, xmm15, 0x00
00007b1fbf9d5e89  vmovaps xmm5, [rsp+0xC0]
00007b1fbf9d5e92  vmovaps [rsp+0xC0], xmm1
00007b1fbf9d5e9b  movaps xmm7, xmm5
00007b1fbf9d5e9e  mulpd xmm7, xmm15
00007b1fbf9d5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
00007b1fbf9d5ea8  ptest xmm1, xmm1
00007b1fbf9d5ead  jnz 0x00007B1FBF9D7D4B
00007b1fbf9d5eb3  lea r14, [rax+0x80]
00007b1fbf9d5eba  movups xmm1, [r13+r14*1]
00007b1fbf9d5ec0  vmovaps xmm5, [rsp+0x70]
00007b1fbf9d5ec6  vmovaps [rsp+0x70], xmm1
00007b1fbf9d5ecc  movaps xmm15, xmm5
00007b1fbf9d5ed0  addpd xmm15, xmm3
00007b1fbf9d5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
00007b1fbf9d5edb  ptest xmm1, xmm1
00007b1fbf9d5ee0  jnz 0x00007B1FBF9D7E96
00007b1fbf9d5ee6  vmovaps xmm5, [rsp+0x80]
00007b1fbf9d5eef  movaps xmm1, xmm5
00007b1fbf9d5ef2  addpd xmm1, xmm4
00007b1fbf9d5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
00007b1fbf9d5efb  ptest xmm3, xmm3
00007b1fbf9d5f00  jnz 0x00007B1FBF9D7FD8
00007b1fbf9d5f06  vmovaps [rsp+0x80], xmm10
00007b1fbf9d5f0f  vmovaps xmm5, [rsp+0x80]
00007b1fbf9d5f18  por xmm10, xmm5
00007b1fbf9d5f1d  movaps [r15+0x2F0], xmm10
00007b1fbf9d5f25  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d5f2b  vpermilpd xmm5, xmm5, 0x00
00007b1fbf9d5f31  vmovaps xmm3, [rsp+0x70]
00007b1fbf9d5f37  vmovaps [rsp+0x50], xmm1
00007b1fbf9d5f3d  movaps xmm4, xmm3
00007b1fbf9d5f40  mulpd xmm4, xmm5
00007b1fbf9d5f44  vcmppd xmm1, xmm4, xmm4, 0x03
00007b1fbf9d5f49  ptest xmm1, xmm1
00007b1fbf9d5f4e  jnz 0x00007B1FBF9D8118
00007b1fbf9d5f54  lea r14, [rax+0xD0]
00007b1fbf9d5f5b  movups xmm1, [r13+r14*1]
00007b1fbf9d5f61  vmovaps xmm3, [rsp+0xD0]
00007b1fbf9d5f6a  vmovaps [rsp+0x70], xmm1
00007b1fbf9d5f70  movaps xmm5, xmm6
00007b1fbf9d5f73  addpd xmm5, xmm3
00007b1fbf9d5f77  vcmppd xmm1, xmm5, xmm5, 0x03
00007b1fbf9d5f7c  ptest xmm1, xmm1
00007b1fbf9d5f81  jnz 0x00007B1FBF9D8262
00007b1fbf9d5f87  vmovaps xmm1, [rsp+0x60]
00007b1fbf9d5f8d  vpermilpd xmm1, xmm1, 0x00
00007b1fbf9d5f93  movaps xmm6, xmm9
00007b1fbf9d5f97  mulpd xmm6, xmm1
00007b1fbf9d5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
00007b1fbf9d5fa0  ptest xmm3, xmm3
00007b1fbf9d5fa5  jnz 0x00007B1FBF9D83A2
00007b1fbf9d5fab  movaps [r15+0x260], xmm6
00007b1fbf9d5fb3  vxorps xmm1, xmm1, xmm1
00007b1fbf9d5fb7  vpbroadcastq xmm1, xmm1
00007b1fbf9d5fbc  movaps [r15+0x1B0], xmm1
00007b1fbf9d5fc4  vmovaps xmm1, [rsp+0x60]
00007b1fbf9d5fca  vpermilpd xmm1, xmm1, 0x00
00007b1fbf9d5fd0  vmovaps xmm3, [rsp+0x70]
00007b1fbf9d5fd6  vmovaps [rsp+0x70], xmm15
00007b1fbf9d5fdc  movaps xmm9, xmm3
00007b1fbf9d5fe0  mulpd xmm9, xmm1
00007b1fbf9d5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
00007b1fbf9d5feb  ptest xmm15, xmm15
00007b1fbf9d5ff1  jnz 0x00007B1FBF9D84E3
00007b1fbf9d5ff7  lea r14, [rax+0xC0]
00007b1fbf9d5ffe  movups xmm1, [r13+r14*1]
00007b1fbf9d6004  vmovaps xmm3, [rsp+0xC0]
00007b1fbf9d600d  vmovaps [rsp+0x80], xmm1
00007b1fbf9d6016  movaps xmm15, xmm3
00007b1fbf9d601a  addpd xmm15, xmm7
00007b1fbf9d601f  vcmppd xmm1, xmm15, xmm15, 0x03
00007b1fbf9d6025  ptest xmm1, xmm1
00007b1fbf9d602a  jnz 0x00007B1FBF9D862F
00007b1fbf9d6030  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d6039  vmovaps xmm1, [rsp+0xC0]
00007b1fbf9d6042  por xmm13, xmm1
00007b1fbf9d6047  movaps [r15+0x270], xmm13
00007b1fbf9d604f  vmovaps xmm1, [rsp+0xB0]
00007b1fbf9d6058  vmovaps xmm7, [rsp+0xB0]
00007b1fbf9d6061  por xmm1, xmm7
00007b1fbf9d6065  movaps [r15+0x1A0], xmm1
00007b1fbf9d606d  vmovaps xmm1, [rsp+0x60]
00007b1fbf9d6073  vpermilpd xmm1, xmm1, 0x00
00007b1fbf9d6079  vmovaps [rsp+0xB0], xmm1
00007b1fbf9d6082  vmovaps xmm1, [rsp+0x80]
00007b1fbf9d608b  vmovaps [rsp+0x80], xmm15
00007b1fbf9d6094  vmovaps xmm15, [rsp+0xB0]
00007b1fbf9d609d  vmovaps [rsp+0xB0], xmm14
00007b1fbf9d60a6  movaps xmm3, xmm1
00007b1fbf9d60a9  mulpd xmm3, xmm15
00007b1fbf9d60ae  vcmppd xmm14, xmm3, xmm3, 0x03
00007b1fbf9d60b3  ptest xmm14, xmm14
00007b1fbf9d60b9  jnz 0x00007B1FBF9D8771
00007b1fbf9d60bf  lea r14, [rax+0x20]
00007b1fbf9d60c3  movups xmm1, [r13+r14*1]
00007b1fbf9d60c9  movaps [r15+0x110], xmm1
00007b1fbf9d60d1  vmovaps xmm14, [rsp+0x70]
00007b1fbf9d60d7  vmovaps [rsp+0x70], xmm1
00007b1fbf9d60dd  movaps xmm15, xmm14
00007b1fbf9d60e1  addpd xmm15, xmm4
00007b1fbf9d60e6  vcmppd xmm1, xmm15, xmm15, 0x03
00007b1fbf9d60ec  ptest xmm1, xmm1
00007b1fbf9d60f1  jnz 0x00007B1FBF9D88BC
00007b1fbf9d60f7  vmovaps xmm1, [rsp+0x60]
00007b1fbf9d60fd  vpermilpd xmm1, xmm1, 0x00
00007b1fbf9d6103  movaps xmm14, xmm2
00007b1fbf9d6107  mulpd xmm14, xmm1
00007b1fbf9d610c  vcmppd xmm4, xmm14, xmm14, 0x03
00007b1fbf9d6112  ptest xmm4, xmm4
00007b1fbf9d6117  jnz 0x00007B1FBF9D89FF
00007b1fbf9d611d  vmovaps xmm4, [rsp+0x50]
00007b1fbf9d6123  movaps xmm1, xmm4
00007b1fbf9d6126  addpd xmm1, xmm9
00007b1fbf9d612b  vcmppd xmm2, xmm1, xmm1, 0x03
00007b1fbf9d6130  ptest xmm2, xmm2
00007b1fbf9d6135  jnz 0x00007B1FBF9D8B41
00007b1fbf9d613b  vmovaps xmm9, [rsp+0x30]
00007b1fbf9d6141  vpermilpd xmm9, xmm9, 0x00
00007b1fbf9d6147  vmovaps xmm2, [rsp+0x70]
00007b1fbf9d614d  vmovaps [rsp+0x50], xmm1
00007b1fbf9d6153  movaps xmm4, xmm2
00007b1fbf9d6156  mulpd xmm4, xmm9
00007b1fbf9d615b  vcmppd xmm1, xmm4, xmm4, 0x03
00007b1fbf9d6160  ptest xmm1, xmm1
00007b1fbf9d6165  jnz 0x00007B1FBF9D8C82
00007b1fbf9d616b  vmovaps xmm1, [rsp+0x30]
00007b1fbf9d6171  vpermilpd xmm1, xmm1, 0x00
00007b1fbf9d6177  vmovaps xmm2, [rsp+0x90]
00007b1fbf9d6180  vmovaps [rsp+0x60], xmm15
00007b1fbf9d6186  movaps xmm9, xmm2
00007b1fbf9d618a  mulpd xmm9, xmm1
00007b1fbf9d618f  vcmppd xmm15, xmm9, xmm9, 0x03
00007b1fbf9d6195  ptest xmm15, xmm15
00007b1fbf9d619b  jnz 0x00007B1FBF9D8DC3
00007b1fbf9d61a1  vmovaps xmm15, [rsp+0x80]
00007b1fbf9d61aa  movaps xmm1, xmm15
00007b1fbf9d61ae  addpd xmm1, xmm6
00007b1fbf9d61b2  vcmppd xmm2, xmm1, xmm1, 0x03
00007b1fbf9d61b7  ptest xmm2, xmm2
00007b1fbf9d61bc  jnz 0x00007B1FBF9D8F05
00007b1fbf9d61c2  movaps xmm15, xmm5
00007b1fbf9d61c6  addpd xmm15, xmm3
00007b1fbf9d61cb  vcmppd xmm6, xmm15, xmm15, 0x03
00007b1fbf9d61d1  ptest xmm6, xmm6
00007b1fbf9d61d6  jnz 0x00007B1FBF9D9046
00007b1fbf9d61dc  vmovaps xmm6, [rsp+0x30]
00007b1fbf9d61e2  vpermilpd xmm6, xmm6, 0x00
00007b1fbf9d61e8  movaps xmm5, xmm8
00007b1fbf9d61ec  mulpd xmm5, xmm6
00007b1fbf9d61f0  vcmppd xmm3, xmm5, xmm5, 0x03
00007b1fbf9d61f5  ptest xmm3, xmm3
00007b1fbf9d61fa  jnz 0x00007B1FBF9D9188
00007b1fbf9d6200  vmovaps xmm8, [rsp+0x30]
00007b1fbf9d6206  vpermilpd xmm8, xmm8, 0x00
00007b1fbf9d620c  movaps xmm6, xmm10
00007b1fbf9d6210  mulpd xmm6, xmm8
00007b1fbf9d6215  vcmppd xmm3, xmm6, xmm6, 0x03
00007b1fbf9d621a  ptest xmm3, xmm3
00007b1fbf9d621f  jnz 0x00007B1FBF9D92C9
00007b1fbf9d6225  vmovaps xmm8, [rsp+0x60]
00007b1fbf9d622b  movaps xmm10, xmm8
00007b1fbf9d622f  addpd xmm10, xmm14
00007b1fbf9d6234  vcmppd xmm3, xmm10, xmm10, 0x03
00007b1fbf9d623a  ptest xmm3, xmm3
00007b1fbf9d623f  jnz 0x00007B1FBF9D940B
00007b1fbf9d6245  vmovaps xmm8, [rsp+0x50]
00007b1fbf9d624b  movaps xmm14, xmm8
00007b1fbf9d624f  addpd xmm14, xmm4
00007b1fbf9d6254  vcmppd xmm3, xmm14, xmm14, 0x03
00007b1fbf9d625a  ptest xmm3, xmm3
00007b1fbf9d625f  jnz 0x00007B1FBF9D954F
00007b1fbf9d6265  vmovaps xmm8, [rsp+0x40]
00007b1fbf9d626b  vpermilpd xmm8, xmm8, 0x00
00007b1fbf9d6271  movaps xmm4, xmm13
00007b1fbf9d6275  mulpd xmm4, xmm8
00007b1fbf9d627a  vcmppd xmm3, xmm4, xmm4, 0x03
00007b1fbf9d627f  ptest xmm3, xmm3
00007b1fbf9d6284  jnz 0x00007B1FBF9D9692
00007b1fbf9d628a  movaps xmm13, xmm15
00007b1fbf9d628e  addpd xmm13, xmm9
00007b1fbf9d6293  vcmppd xmm8, xmm13, xmm13, 0x03
00007b1fbf9d6299  ptest xmm8, xmm8
00007b1fbf9d629f  jnz 0x00007B1FBF9D97D4
00007b1fbf9d62a5  movaps xmm15, xmm1
00007b1fbf9d62a9  addpd xmm15, xmm5
00007b1fbf9d62ae  vcmppd xmm9, xmm15, xmm15, 0x03
00007b1fbf9d62b4  ptest xmm9, xmm9
00007b1fbf9d62ba  jnz 0x00007B1FBF9D9918
00007b1fbf9d62c0  vmovaps [rsp+0x30], xmm11
00007b1fbf9d62c6  vmovaps xmm1, [rsp+0x30]
00007b1fbf9d62cc  por xmm11, xmm1
00007b1fbf9d62d1  movaps [r15+0x250], xmm11
00007b1fbf9d62d9  vmovaps [rsp+0x30], xmm12
00007b1fbf9d62df  vmovaps xmm1, [rsp+0x30]
00007b1fbf9d62e5  por xmm12, xmm1
00007b1fbf9d62ea  movaps [r15+0x2A0], xmm12
00007b1fbf9d62f2  vmovaps xmm1, [rsp+0xA0]
00007b1fbf9d62fb  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d6304  por xmm1, xmm11
00007b1fbf9d6309  movaps [r15+0x1D0], xmm1
00007b1fbf9d6311  lea r14, [rax+0x40]
00007b1fbf9d6315  movups xmm1, [r13+r14*1]
00007b1fbf9d631b  movaps [r15+0x2C0], xmm1
00007b1fbf9d6323  vmovaps xmm11, [rsp+0x40]
00007b1fbf9d6329  vpermilpd xmm11, xmm11, 0x00
00007b1fbf9d632f  vmovaps xmm8, [rsp+0xE0]
00007b1fbf9d6338  movaps xmm9, xmm8
00007b1fbf9d633c  mulpd xmm9, xmm11
00007b1fbf9d6341  vcmppd xmm5, xmm9, xmm9, 0x03
00007b1fbf9d6347  ptest xmm5, xmm5
00007b1fbf9d634c  jnz 0x00007B1FBF9D9A64
00007b1fbf9d6352  movaps xmm11, xmm10
00007b1fbf9d6356  addpd xmm11, xmm6
00007b1fbf9d635b  vcmppd xmm8, xmm11, xmm11, 0x03
00007b1fbf9d6361  ptest xmm8, xmm8
00007b1fbf9d6367  jnz 0x00007B1FBF9D9BA8
00007b1fbf9d636d  movaps xmm10, xmm14
00007b1fbf9d6371  addpd xmm10, xmm4
00007b1fbf9d6376  vcmppd xmm8, xmm10, xmm10, 0x03
00007b1fbf9d637c  ptest xmm8, xmm8
00007b1fbf9d6382  jnz 0x00007B1FBF9D9CEB
00007b1fbf9d6388  vmovaps xmm14, [rsp+0x40]
00007b1fbf9d638e  vpermilpd xmm14, xmm14, 0x00
00007b1fbf9d6394  movaps xmm8, xmm1
00007b1fbf9d6398  mulpd xmm8, xmm14
00007b1fbf9d639d  vcmppd xmm6, xmm8, xmm8, 0x03
00007b1fbf9d63a3  ptest xmm6, xmm6
00007b1fbf9d63a8  jnz 0x00007B1FBF9D9E2E
00007b1fbf9d63ae  movaps xmm1, [r15+0x2B0]
00007b1fbf9d63b6  vmovaps xmm14, [rsp+0x40]
00007b1fbf9d63bc  vpermilpd xmm14, xmm14, 0x00
00007b1fbf9d63c2  movaps xmm6, xmm1
00007b1fbf9d63c5  mulpd xmm6, xmm14
00007b1fbf9d63ca  vcmppd xmm5, xmm6, xmm6, 0x03
00007b1fbf9d63cf  ptest xmm5, xmm5
00007b1fbf9d63d4  jnz 0x00007B1FBF9D9F71
00007b1fbf9d63da  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d63e0  vpermilpd xmm1, xmm1, 0x00
00007b1fbf9d63e6  movaps xmm14, xmm12
00007b1fbf9d63ea  mulpd xmm14, xmm1
00007b1fbf9d63ef  vcmppd xmm5, xmm14, xmm14, 0x03
00007b1fbf9d63f5  ptest xmm5, xmm5
00007b1fbf9d63fa  jnz 0x00007B1FBF9DA0B2
00007b1fbf9d6400  movaps xmm1, xmm13
00007b1fbf9d6404  addpd xmm1, xmm9
00007b1fbf9d6409  vcmppd xmm12, xmm1, xmm1, 0x03
00007b1fbf9d640e  ptest xmm12, xmm12
00007b1fbf9d6414  jnz 0x00007B1FBF9DA1F5
00007b1fbf9d641a  vmovaps xmm13, [rsp+0x10]
00007b1fbf9d6420  vpermilpd xmm13, xmm13, 0x00
00007b1fbf9d6426  movaps xmm12, xmm7
00007b1fbf9d642a  mulpd xmm12, xmm13
00007b1fbf9d642f  vcmppd xmm9, xmm12, xmm12, 0x03
00007b1fbf9d6435  ptest xmm9, xmm9
00007b1fbf9d643b  jnz 0x00007B1FBF9DA337
00007b1fbf9d6441  movaps xmm13, xmm15
00007b1fbf9d6445  addpd xmm13, xmm8
00007b1fbf9d644a  vcmppd xmm9, xmm13, xmm13, 0x03
00007b1fbf9d6450  ptest xmm9, xmm9
00007b1fbf9d6456  jnz 0x00007B1FBF9DA47A
00007b1fbf9d645c  movaps xmm15, [r15+0x290]
00007b1fbf9d6464  vmovaps xmm9, [rsp+0x10]
00007b1fbf9d646a  vpermilpd xmm9, xmm9, 0x00
00007b1fbf9d6470  movaps xmm8, xmm15
00007b1fbf9d6474  mulpd xmm8, xmm9
00007b1fbf9d6479  vcmppd xmm7, xmm8, xmm8, 0x03
00007b1fbf9d647f  ptest xmm7, xmm7
00007b1fbf9d6484  jnz 0x00007B1FBF9DA5BE
00007b1fbf9d648a  movaps xmm15, xmm11
00007b1fbf9d648e  addpd xmm15, xmm6
00007b1fbf9d6493  vcmppd xmm9, xmm15, xmm15, 0x03
00007b1fbf9d6499  ptest xmm9, xmm9
00007b1fbf9d649f  jnz 0x00007B1FBF9DA702
00007b1fbf9d64a5  movaps xmm11, [r15+0x1E0]
00007b1fbf9d64ad  vmovaps xmm9, [rsp+0x10]
00007b1fbf9d64b3  vpermilpd xmm9, xmm9, 0x00
00007b1fbf9d64b9  movaps xmm7, xmm11
00007b1fbf9d64bd  mulpd xmm7, xmm9
00007b1fbf9d64c2  vcmppd xmm6, xmm7, xmm7, 0x03
00007b1fbf9d64c7  ptest xmm6, xmm6
00007b1fbf9d64cc  jnz 0x00007B1FBF9DA845
00007b1fbf9d64d2  movaps xmm11, xmm10
00007b1fbf9d64d6  addpd xmm11, xmm14
00007b1fbf9d64db  vcmppd xmm9, xmm11, xmm11, 0x03
00007b1fbf9d64e1  ptest xmm9, xmm9
00007b1fbf9d64e7  jnz 0x00007B1FBF9DA987
00007b1fbf9d64ed  lea r14, [rax+0x70]
00007b1fbf9d64f1  movups xmm14, [r13+r14*1]
00007b1fbf9d64f7  movaps [r15+0x240], xmm14
00007b1fbf9d64ff  movaps xmm10, xmm1
00007b1fbf9d6503  addpd xmm10, xmm12
00007b1fbf9d6508  vcmppd xmm9, xmm10, xmm10, 0x03
00007b1fbf9d650e  ptest xmm9, xmm9
00007b1fbf9d6514  jnz 0x00007B1FBF9DAAD5
00007b1fbf9d651a  movaps [r15+0x170], xmm10
00007b1fbf9d6522  vmovaps xmm1, [rsp+0x20]
00007b1fbf9d6528  vpermilpd xmm1, xmm1, 0x00
00007b1fbf9d652e  movaps xmm12, xmm14
00007b1fbf9d6532  mulpd xmm12, xmm1
00007b1fbf9d6537  vcmppd xmm9, xmm12, xmm12, 0x03
00007b1fbf9d653d  ptest xmm9, xmm9
00007b1fbf9d6543  jnz 0x00007B1FBF9DAC18
00007b1fbf9d6549  vmovaps xmm1, [rsp+0x20]
00007b1fbf9d654f  vpermilpd xmm1, xmm1, 0x00
00007b1fbf9d6555  vmovaps xmm9, [rsp+0xB0]
00007b1fbf9d655e  movaps xmm14, xmm9
00007b1fbf9d6562  mulpd xmm14, xmm1
00007b1fbf9d6567  vcmppd xmm6, xmm14, xmm14, 0x03
00007b1fbf9d656d  ptest xmm6, xmm6
00007b1fbf9d6572  jnz 0x00007B1FBF9DAD5B
00007b1fbf9d6578  movaps [r15+0x180], xmm14
00007b1fbf9d6580  movaps xmm1, xmm13
00007b1fbf9d6584  addpd xmm1, xmm8
00007b1fbf9d6589  vcmppd xmm9, xmm1, xmm1, 0x03
00007b1fbf9d658e  ptest xmm9, xmm9
00007b1fbf9d6594  jnz 0x00007B1FBF9DAE9E
00007b1fbf9d659a  movaps [r15+0x210], xmm1
00007b1fbf9d65a2  movups xmm13, [r13+rax*1]
00007b1fbf9d65a8  lea r14, [rax+0x10]
00007b1fbf9d65ac  movups xmm9, [r13+r14*1]
00007b1fbf9d65b2  movaps [r15+0x230], xmm9
00007b1fbf9d65ba  movaps xmm8, xmm15
00007b1fbf9d65be  addpd xmm8, xmm7
00007b1fbf9d65c3  vcmppd xmm6, xmm8, xmm8, 0x03
00007b1fbf9d65c9  ptest xmm6, xmm6
00007b1fbf9d65ce  jnz 0x00007B1FBF9DAFF4
00007b1fbf9d65d4  movaps [r15+0x130], xmm8
00007b1fbf9d65dc  vmovaps xmm15, [rsp+0x20]
00007b1fbf9d65e2  vpermilpd xmm15, xmm15, 0x00
00007b1fbf9d65e8  movaps xmm7, xmm9
00007b1fbf9d65ec  mulpd xmm7, xmm15
00007b1fbf9d65f1  vcmppd xmm6, xmm7, xmm7, 0x03
00007b1fbf9d65f6  ptest xmm6, xmm6
00007b1fbf9d65fb  jnz 0x00007B1FBF9DB137
00007b1fbf9d6601  movaps [r15+0x220], xmm7
00007b1fbf9d6609  vmovaps xmm15, [rsp+0x20]
00007b1fbf9d660f  vpermilpd xmm15, xmm15, 0x00
00007b1fbf9d6615  movaps xmm9, xmm13
00007b1fbf9d6619  mulpd xmm9, xmm15
00007b1fbf9d661e  vcmppd xmm6, xmm9, xmm9, 0x03
00007b1fbf9d6624  ptest xmm6, xmm6
00007b1fbf9d6629  jnz 0x00007B1FBF9DB279
00007b1fbf9d662f  movaps xmm15, xmm11
00007b1fbf9d6633  addpd xmm15, xmm12
00007b1fbf9d6638  vcmppd xmm13, xmm15, xmm15, 0x03
00007b1fbf9d663e  ptest xmm13, xmm13
00007b1fbf9d6644  jnz 0x00007B1FBF9DB3BD
00007b1fbf9d664a  movaps [r15+0x140], xmm15
00007b1fbf9d6652  movaps xmm13, xmm10
00007b1fbf9d6656  addpd xmm13, xmm14
00007b1fbf9d665b  vcmppd xmm12, xmm13, xmm13, 0x03
00007b1fbf9d6661  ptest xmm12, xmm12
00007b1fbf9d6667  jnz 0x00007B1FBF9DB501
00007b1fbf9d666d  movaps [r15+0x150], xmm13
00007b1fbf9d6675  movaps xmm14, xmm1
00007b1fbf9d6679  addpd xmm14, xmm7
00007b1fbf9d667e  vcmppd xmm12, xmm14, xmm14, 0x03
00007b1fbf9d6684  ptest xmm12, xmm12
00007b1fbf9d668a  jnz 0x00007B1FBF9DB645
00007b1fbf9d6690  movaps [r15+0x160], xmm14
00007b1fbf9d6698  movaps xmm1, xmm8
00007b1fbf9d669c  addpd xmm1, xmm9
00007b1fbf9d66a1  vcmppd xmm12, xmm1, xmm1, 0x03
00007b1fbf9d66a6  ptest xmm12, xmm12
00007b1fbf9d66ac  jnz 0x00007B1FBF9DB787
00007b1fbf9d66b2  movaps [r15+0x120], xmm1
00007b1fbf9d66ba  movups [r13+r11*1], xmm15
00007b1fbf9d66c0  lea rax, [r11+0x10]
00007b1fbf9d66c4  movups [r13+rax*1], xmm13
00007b1fbf9d66ca  lea rax, [r11+0x20]
00007b1fbf9d66ce  movups [r13+rax*1], xmm14
00007b1fbf9d66d4  lea rax, [r11+0x30]
00007b1fbf9d66d8  movups [r13+rax*1], xmm1
00007b1fbf9d66de  mov eax, [r15+0x108]
00007b1fbf9d66e5  sahf
00007b1fbf9d66e6  jnz 0x00007B1FBF9D6718
00007b1fbf9d66e8  cmp dword ptr [r15+0x318], 0x00
00007b1fbf9d66f0  jz 0x00007B1FBF9DB900
00007b1fbf9d66f6  nop [rax+rax*1], ax
00007b1fbf9d66ff  nop [rax+rax*1], eax
00007b1fbf9d6707  mov eax, 0x410444
00007b1fbf9d670c  mov [r15+0x100], rax
00007b1fbf9d6713  jmp 0x00007B1FBF7FE110
00007b1fbf9d6718  cmp dword ptr [r15+0x318], 0x00
00007b1fbf9d6720  jz 0x00007B1FBF9D57E0
00007b1fbf9d6726  nop [rax+rax*1], ax
00007b1fbf9d672f  nop [rax+rax*1], eax
00007b1fbf9d6737  mov eax, 0x410278
00007b1fbf9d673c  mov [r15+0x100], rax
00007b1fbf9d6743  jmp 0x00007B1FBF7FE110
00007b1fbf9d6748  int3
00007b1fbf9d6749  call 0x00007B1FBF80A4B0
00007b1fbf9d674e  jmp 0x00007B1FBF9D5828
00007b1fbf9d6753  call 0x00007B1FBF809240
00007b1fbf9d6758  jmp 0x00007B1FBF9D5832
00007b1fbf9d675d  call 0x00007B1FBF80A4B0
00007b1fbf9d6762  jmp 0x00007B1FBF9D588F
00007b1fbf9d6767  call 0x00007B1FBF809240
00007b1fbf9d676c  jmp 0x00007B1FBF9D5899
00007b1fbf9d6771  call 0x00007B1FBF80A4B0
00007b1fbf9d6776  jmp 0x00007B1FBF9D58DD
00007b1fbf9d677b  call 0x00007B1FBF809240
00007b1fbf9d6780  jmp 0x00007B1FBF9D58E7
00007b1fbf9d6785  call 0x00007B1FBF8B47C0
00007b1fbf9d678a  jmp 0x00007B1FBF9D5926
00007b1fbf9d678f  call 0x00007B1FBF80B720
00007b1fbf9d6794  jmp 0x00007B1FBF9D593A
00007b1fbf9d6799  call 0x00007B1FBF8BFC30
00007b1fbf9d679e  jmp 0x00007B1FBF9D5958
00007b1fbf9d67a3  call 0x00007B1FBF8BE9C0
00007b1fbf9d67a8  jmp 0x00007B1FBF9D5962
00007b1fbf9d67ad  call 0x00007B1FBF8BD750
00007b1fbf9d67b2  jmp 0x00007B1FBF9D596C
00007b1fbf9d67b7  sub rsp, 0x08
00007b1fbf9d67bb  push rax
00007b1fbf9d67bc  push rcx
00007b1fbf9d67bd  push rdx
00007b1fbf9d67be  push rdi
00007b1fbf9d67bf  push rsi
00007b1fbf9d67c0  push r8
00007b1fbf9d67c2  push r9
00007b1fbf9d67c4  push r10
00007b1fbf9d67c6  push r11
00007b1fbf9d67c8  sub rsp, 0xF0
00007b1fbf9d67cf  vmovaps [rsp], xmm0
00007b1fbf9d67d4  vmovaps [rsp+0x10], xmm1
00007b1fbf9d67da  vmovaps [rsp+0x20], xmm2
00007b1fbf9d67e0  vmovaps [rsp+0x30], xmm3
00007b1fbf9d67e6  vmovaps [rsp+0x40], xmm4
00007b1fbf9d67ec  vmovaps [rsp+0x50], xmm5
00007b1fbf9d67f2  vmovaps [rsp+0x60], xmm6
00007b1fbf9d67f8  vmovaps [rsp+0x70], xmm7
00007b1fbf9d67fe  vmovaps [rsp+0x80], xmm9
00007b1fbf9d6807  vmovaps [rsp+0x90], xmm10
00007b1fbf9d6810  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d6819  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d6822  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d682b  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d6834  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d683d  sub rsp, 0x30
00007b1fbf9d6841  movaps [rsp], xmm8
00007b1fbf9d6846  movaps [rsp+0x10], xmm12
00007b1fbf9d684c  movaps [rsp+0x20], xmm15
00007b1fbf9d6852  lea rdi, [rsp]
00007b1fbf9d6856  mov esi, 0x00
00007b1fbf9d685b  mov rax, 0x64AEE5F12530
00007b1fbf9d6865  call rax
00007b1fbf9d6867  movaps xmm8, [rsp]
00007b1fbf9d686c  add rsp, 0x30
00007b1fbf9d6870  vmovaps xmm0, [rsp]
00007b1fbf9d6875  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d687b  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d6881  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d6887  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d688d  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d6893  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d6899  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d689f  vmovaps xmm9, [rsp+0x80]
00007b1fbf9d68a8  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d68b1  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d68ba  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d68c3  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d68cc  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d68d5  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d68de  add rsp, 0xF0
00007b1fbf9d68e5  pop r11
00007b1fbf9d68e7  pop r10
00007b1fbf9d68e9  pop r9
00007b1fbf9d68eb  pop r8
00007b1fbf9d68ed  pop rsi
00007b1fbf9d68ee  pop rdi
00007b1fbf9d68ef  pop rdx
00007b1fbf9d68f0  pop rcx
00007b1fbf9d68f1  pop rax
00007b1fbf9d68f2  add rsp, 0x08
00007b1fbf9d68f6  jmp 0x00007B1FBF9D599A
00007b1fbf9d68fb  sub rsp, 0x08
00007b1fbf9d68ff  push rax
00007b1fbf9d6900  push rcx
00007b1fbf9d6901  push rdx
00007b1fbf9d6902  push rdi
00007b1fbf9d6903  push rsi
00007b1fbf9d6904  push r8
00007b1fbf9d6906  push r9
00007b1fbf9d6908  push r10
00007b1fbf9d690a  push r11
00007b1fbf9d690c  sub rsp, 0xF0
00007b1fbf9d6913  vmovaps [rsp], xmm0
00007b1fbf9d6918  vmovaps [rsp+0x10], xmm1
00007b1fbf9d691e  vmovaps [rsp+0x20], xmm2
00007b1fbf9d6924  vmovaps [rsp+0x30], xmm3
00007b1fbf9d692a  vmovaps [rsp+0x40], xmm4
00007b1fbf9d6930  vmovaps [rsp+0x50], xmm5
00007b1fbf9d6936  vmovaps [rsp+0x60], xmm6
00007b1fbf9d693c  vmovaps [rsp+0x70], xmm8
00007b1fbf9d6942  vmovaps [rsp+0x80], xmm9
00007b1fbf9d694b  vmovaps [rsp+0x90], xmm10
00007b1fbf9d6954  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d695d  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d6966  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d696f  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d6978  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d6981  sub rsp, 0x30
00007b1fbf9d6985  movaps [rsp], xmm7
00007b1fbf9d6989  movaps [rsp+0x10], xmm9
00007b1fbf9d698f  movaps [rsp+0x20], xmm15
00007b1fbf9d6995  lea rdi, [rsp]
00007b1fbf9d6999  mov esi, 0x00
00007b1fbf9d699e  mov rax, 0x64AEE5F12530
00007b1fbf9d69a8  call rax
00007b1fbf9d69aa  movaps xmm7, [rsp]
00007b1fbf9d69ae  add rsp, 0x30
00007b1fbf9d69b2  vmovaps xmm0, [rsp]
00007b1fbf9d69b7  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d69bd  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d69c3  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d69c9  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d69cf  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d69d5  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d69db  vmovaps xmm8, [rsp+0x70]
00007b1fbf9d69e1  vmovaps xmm9, [rsp+0x80]
00007b1fbf9d69ea  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d69f3  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d69fc  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d6a05  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d6a0e  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d6a17  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d6a20  add rsp, 0xF0
00007b1fbf9d6a27  pop r11
00007b1fbf9d6a29  pop r10
00007b1fbf9d6a2b  pop r9
00007b1fbf9d6a2d  pop r8
00007b1fbf9d6a2f  pop rsi
00007b1fbf9d6a30  pop rdi
00007b1fbf9d6a31  pop rdx
00007b1fbf9d6a32  pop rcx
00007b1fbf9d6a33  pop rax
00007b1fbf9d6a34  add rsp, 0x08
00007b1fbf9d6a38  jmp 0x00007B1FBF9D59C8
00007b1fbf9d6a3d  sub rsp, 0x08
00007b1fbf9d6a41  push rax
00007b1fbf9d6a42  push rcx
00007b1fbf9d6a43  push rdx
00007b1fbf9d6a44  push rdi
00007b1fbf9d6a45  push rsi
00007b1fbf9d6a46  push r8
00007b1fbf9d6a48  push r9
00007b1fbf9d6a4a  push r10
00007b1fbf9d6a4c  push r11
00007b1fbf9d6a4e  sub rsp, 0xF0
00007b1fbf9d6a55  vmovaps [rsp], xmm0
00007b1fbf9d6a5a  vmovaps [rsp+0x10], xmm1
00007b1fbf9d6a60  vmovaps [rsp+0x20], xmm2
00007b1fbf9d6a66  vmovaps [rsp+0x30], xmm3
00007b1fbf9d6a6c  vmovaps [rsp+0x40], xmm4
00007b1fbf9d6a72  vmovaps [rsp+0x50], xmm5
00007b1fbf9d6a78  vmovaps [rsp+0x60], xmm6
00007b1fbf9d6a7e  vmovaps [rsp+0x70], xmm7
00007b1fbf9d6a84  vmovaps [rsp+0x80], xmm8
00007b1fbf9d6a8d  vmovaps [rsp+0x90], xmm10
00007b1fbf9d6a96  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d6a9f  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d6aa8  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d6ab1  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d6aba  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d6ac3  sub rsp, 0x30
00007b1fbf9d6ac7  movaps [rsp], xmm9
00007b1fbf9d6acc  movaps [rsp+0x10], xmm12
00007b1fbf9d6ad2  movaps [rsp+0x20], xmm10
00007b1fbf9d6ad8  lea rdi, [rsp]
00007b1fbf9d6adc  mov esi, 0x00
00007b1fbf9d6ae1  mov rax, 0x64AEE5F12530
00007b1fbf9d6aeb  call rax
00007b1fbf9d6aed  movaps xmm9, [rsp]
00007b1fbf9d6af2  add rsp, 0x30
00007b1fbf9d6af6  vmovaps xmm0, [rsp]
00007b1fbf9d6afb  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d6b01  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d6b07  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d6b0d  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d6b13  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d6b19  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d6b1f  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d6b25  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d6b2e  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d6b37  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d6b40  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d6b49  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d6b52  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d6b5b  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d6b64  add rsp, 0xF0
00007b1fbf9d6b6b  pop r11
00007b1fbf9d6b6d  pop r10
00007b1fbf9d6b6f  pop r9
00007b1fbf9d6b71  pop r8
00007b1fbf9d6b73  pop rsi
00007b1fbf9d6b74  pop rdi
00007b1fbf9d6b75  pop rdx
00007b1fbf9d6b76  pop rcx
00007b1fbf9d6b77  pop rax
00007b1fbf9d6b78  add rsp, 0x08
00007b1fbf9d6b7c  jmp 0x00007B1FBF9D59EC
00007b1fbf9d6b81  sub rsp, 0x08
00007b1fbf9d6b85  push rax
00007b1fbf9d6b86  push rcx
00007b1fbf9d6b87  push rdx
00007b1fbf9d6b88  push rdi
00007b1fbf9d6b89  push rsi
00007b1fbf9d6b8a  push r8
00007b1fbf9d6b8c  push r9
00007b1fbf9d6b8e  push r10
00007b1fbf9d6b90  push r11
00007b1fbf9d6b92  sub rsp, 0xF0
00007b1fbf9d6b99  vmovaps [rsp], xmm0
00007b1fbf9d6b9e  vmovaps [rsp+0x10], xmm1
00007b1fbf9d6ba4  vmovaps [rsp+0x20], xmm2
00007b1fbf9d6baa  vmovaps [rsp+0x30], xmm3
00007b1fbf9d6bb0  vmovaps [rsp+0x40], xmm4
00007b1fbf9d6bb6  vmovaps [rsp+0x50], xmm5
00007b1fbf9d6bbc  vmovaps [rsp+0x60], xmm6
00007b1fbf9d6bc2  vmovaps [rsp+0x70], xmm7
00007b1fbf9d6bc8  vmovaps [rsp+0x80], xmm8
00007b1fbf9d6bd1  vmovaps [rsp+0x90], xmm9
00007b1fbf9d6bda  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d6be3  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d6bec  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d6bf5  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d6bfe  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d6c07  sub rsp, 0x30
00007b1fbf9d6c0b  movaps [rsp], xmm10
00007b1fbf9d6c10  movaps [rsp+0x10], xmm12
00007b1fbf9d6c16  movaps [rsp+0x20], xmm11
00007b1fbf9d6c1c  lea rdi, [rsp]
00007b1fbf9d6c20  mov esi, 0x00
00007b1fbf9d6c25  mov rax, 0x64AEE5F12530
00007b1fbf9d6c2f  call rax
00007b1fbf9d6c31  movaps xmm10, [rsp]
00007b1fbf9d6c36  add rsp, 0x30
00007b1fbf9d6c3a  vmovaps xmm0, [rsp]
00007b1fbf9d6c3f  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d6c45  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d6c4b  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d6c51  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d6c57  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d6c5d  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d6c63  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d6c69  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d6c72  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d6c7b  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d6c84  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d6c8d  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d6c96  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d6c9f  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d6ca8  add rsp, 0xF0
00007b1fbf9d6caf  pop r11
00007b1fbf9d6cb1  pop r10
00007b1fbf9d6cb3  pop r9
00007b1fbf9d6cb5  pop r8
00007b1fbf9d6cb7  pop rsi
00007b1fbf9d6cb8  pop rdi
00007b1fbf9d6cb9  pop rdx
00007b1fbf9d6cba  pop rcx
00007b1fbf9d6cbb  pop rax
00007b1fbf9d6cbc  add rsp, 0x08
00007b1fbf9d6cc0  jmp 0x00007B1FBF9D5A06
00007b1fbf9d6cc5  sub rsp, 0x08
00007b1fbf9d6cc9  push rax
00007b1fbf9d6cca  push rcx
00007b1fbf9d6ccb  push rdx
00007b1fbf9d6ccc  push rdi
00007b1fbf9d6ccd  push rsi
00007b1fbf9d6cce  push r8
00007b1fbf9d6cd0  push r9
00007b1fbf9d6cd2  push r10
00007b1fbf9d6cd4  push r11
00007b1fbf9d6cd6  sub rsp, 0xF0
00007b1fbf9d6cdd  vmovaps [rsp], xmm0
00007b1fbf9d6ce2  vmovaps [rsp+0x10], xmm1
00007b1fbf9d6ce8  vmovaps [rsp+0x20], xmm2
00007b1fbf9d6cee  vmovaps [rsp+0x30], xmm3
00007b1fbf9d6cf4  vmovaps [rsp+0x40], xmm4
00007b1fbf9d6cfa  vmovaps [rsp+0x50], xmm5
00007b1fbf9d6d00  vmovaps [rsp+0x60], xmm7
00007b1fbf9d6d06  vmovaps [rsp+0x70], xmm8
00007b1fbf9d6d0c  vmovaps [rsp+0x80], xmm9
00007b1fbf9d6d15  vmovaps [rsp+0x90], xmm10
00007b1fbf9d6d1e  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d6d27  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d6d30  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d6d39  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d6d42  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d6d4b  sub rsp, 0x30
00007b1fbf9d6d4f  movaps [rsp], xmm6
00007b1fbf9d6d53  movaps [rsp+0x10], xmm12
00007b1fbf9d6d59  movaps [rsp+0x20], xmm11
00007b1fbf9d6d5f  lea rdi, [rsp]
00007b1fbf9d6d63  mov esi, 0x00
00007b1fbf9d6d68  mov rax, 0x64AEE5F12530
00007b1fbf9d6d72  call rax
00007b1fbf9d6d74  movaps xmm6, [rsp]
00007b1fbf9d6d78  add rsp, 0x30
00007b1fbf9d6d7c  vmovaps xmm0, [rsp]
00007b1fbf9d6d81  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d6d87  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d6d8d  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d6d93  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d6d99  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d6d9f  vmovaps xmm7, [rsp+0x60]
00007b1fbf9d6da5  vmovaps xmm8, [rsp+0x70]
00007b1fbf9d6dab  vmovaps xmm9, [rsp+0x80]
00007b1fbf9d6db4  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d6dbd  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d6dc6  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d6dcf  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d6dd8  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d6de1  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d6dea  add rsp, 0xF0
00007b1fbf9d6df1  pop r11
00007b1fbf9d6df3  pop r10
00007b1fbf9d6df5  pop r9
00007b1fbf9d6df7  pop r8
00007b1fbf9d6df9  pop rsi
00007b1fbf9d6dfa  pop rdi
00007b1fbf9d6dfb  pop rdx
00007b1fbf9d6dfc  pop rcx
00007b1fbf9d6dfd  pop rax
00007b1fbf9d6dfe  add rsp, 0x08
00007b1fbf9d6e02  jmp 0x00007B1FBF9D5A27
00007b1fbf9d6e07  sub rsp, 0x08
00007b1fbf9d6e0b  push rax
00007b1fbf9d6e0c  push rcx
00007b1fbf9d6e0d  push rdx
00007b1fbf9d6e0e  push rdi
00007b1fbf9d6e0f  push rsi
00007b1fbf9d6e10  push r8
00007b1fbf9d6e12  push r9
00007b1fbf9d6e14  push r10
00007b1fbf9d6e16  push r11
00007b1fbf9d6e18  sub rsp, 0xF0
00007b1fbf9d6e1f  vmovaps [rsp], xmm0
00007b1fbf9d6e24  vmovaps [rsp+0x10], xmm1
00007b1fbf9d6e2a  vmovaps [rsp+0x20], xmm2
00007b1fbf9d6e30  vmovaps [rsp+0x30], xmm4
00007b1fbf9d6e36  vmovaps [rsp+0x40], xmm5
00007b1fbf9d6e3c  vmovaps [rsp+0x50], xmm6
00007b1fbf9d6e42  vmovaps [rsp+0x60], xmm7
00007b1fbf9d6e48  vmovaps [rsp+0x70], xmm8
00007b1fbf9d6e4e  vmovaps [rsp+0x80], xmm9
00007b1fbf9d6e57  vmovaps [rsp+0x90], xmm10
00007b1fbf9d6e60  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d6e69  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d6e72  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d6e7b  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d6e84  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d6e8d  sub rsp, 0x30
00007b1fbf9d6e91  movaps [rsp], xmm3
00007b1fbf9d6e95  movaps [rsp+0x10], xmm5
00007b1fbf9d6e9a  movaps [rsp+0x20], xmm4
00007b1fbf9d6e9f  lea rdi, [rsp]
00007b1fbf9d6ea3  mov esi, 0x00
00007b1fbf9d6ea8  mov rax, 0x64AEE5F12530
00007b1fbf9d6eb2  call rax
00007b1fbf9d6eb4  movaps xmm3, [rsp]
00007b1fbf9d6eb8  add rsp, 0x30
00007b1fbf9d6ebc  vmovaps xmm0, [rsp]
00007b1fbf9d6ec1  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d6ec7  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d6ecd  vmovaps xmm4, [rsp+0x30]
00007b1fbf9d6ed3  vmovaps xmm5, [rsp+0x40]
00007b1fbf9d6ed9  vmovaps xmm6, [rsp+0x50]
00007b1fbf9d6edf  vmovaps xmm7, [rsp+0x60]
00007b1fbf9d6ee5  vmovaps xmm8, [rsp+0x70]
00007b1fbf9d6eeb  vmovaps xmm9, [rsp+0x80]
00007b1fbf9d6ef4  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d6efd  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d6f06  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d6f0f  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d6f18  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d6f21  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d6f2a  add rsp, 0xF0
00007b1fbf9d6f31  pop r11
00007b1fbf9d6f33  pop r10
00007b1fbf9d6f35  pop r9
00007b1fbf9d6f37  pop r8
00007b1fbf9d6f39  pop rsi
00007b1fbf9d6f3a  pop rdi
00007b1fbf9d6f3b  pop rdx
00007b1fbf9d6f3c  pop rcx
00007b1fbf9d6f3d  pop rax
00007b1fbf9d6f3e  add rsp, 0x08
00007b1fbf9d6f42  jmp 0x00007B1FBF9D5A88
00007b1fbf9d6f47  sub rsp, 0x08
00007b1fbf9d6f4b  push rax
00007b1fbf9d6f4c  push rcx
00007b1fbf9d6f4d  push rdx
00007b1fbf9d6f4e  push rdi
00007b1fbf9d6f4f  push rsi
00007b1fbf9d6f50  push r8
00007b1fbf9d6f52  push r9
00007b1fbf9d6f54  push r10
00007b1fbf9d6f56  push r11
00007b1fbf9d6f58  sub rsp, 0xF0
00007b1fbf9d6f5f  vmovaps [rsp], xmm0
00007b1fbf9d6f64  vmovaps [rsp+0x10], xmm1
00007b1fbf9d6f6a  vmovaps [rsp+0x20], xmm2
00007b1fbf9d6f70  vmovaps [rsp+0x30], xmm3
00007b1fbf9d6f76  vmovaps [rsp+0x40], xmm4
00007b1fbf9d6f7c  vmovaps [rsp+0x50], xmm6
00007b1fbf9d6f82  vmovaps [rsp+0x60], xmm7
00007b1fbf9d6f88  vmovaps [rsp+0x70], xmm8
00007b1fbf9d6f8e  vmovaps [rsp+0x80], xmm9
00007b1fbf9d6f97  vmovaps [rsp+0x90], xmm10
00007b1fbf9d6fa0  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d6fa9  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d6fb2  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d6fbb  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d6fc4  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d6fcd  sub rsp, 0x30
00007b1fbf9d6fd1  movaps [rsp], xmm5
00007b1fbf9d6fd5  movaps [rsp+0x10], xmm8
00007b1fbf9d6fdb  movaps [rsp+0x20], xmm15
00007b1fbf9d6fe1  lea rdi, [rsp]
00007b1fbf9d6fe5  mov esi, 0x00
00007b1fbf9d6fea  mov rax, 0x64AEE5F12530
00007b1fbf9d6ff4  call rax
00007b1fbf9d6ff6  movaps xmm5, [rsp]
00007b1fbf9d6ffa  add rsp, 0x30
00007b1fbf9d6ffe  vmovaps xmm0, [rsp]
00007b1fbf9d7003  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d7009  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d700f  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d7015  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d701b  vmovaps xmm6, [rsp+0x50]
00007b1fbf9d7021  vmovaps xmm7, [rsp+0x60]
00007b1fbf9d7027  vmovaps xmm8, [rsp+0x70]
00007b1fbf9d702d  vmovaps xmm9, [rsp+0x80]
00007b1fbf9d7036  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d703f  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d7048  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d7051  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d705a  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d7063  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d706c  add rsp, 0xF0
00007b1fbf9d7073  pop r11
00007b1fbf9d7075  pop r10
00007b1fbf9d7077  pop r9
00007b1fbf9d7079  pop r8
00007b1fbf9d707b  pop rsi
00007b1fbf9d707c  pop rdi
00007b1fbf9d707d  pop rdx
00007b1fbf9d707e  pop rcx
00007b1fbf9d707f  pop rax
00007b1fbf9d7080  add rsp, 0x08
00007b1fbf9d7084  jmp 0x00007B1FBF9D5AC0
00007b1fbf9d7089  sub rsp, 0x08
00007b1fbf9d708d  push rax
00007b1fbf9d708e  push rcx
00007b1fbf9d708f  push rdx
00007b1fbf9d7090  push rdi
00007b1fbf9d7091  push rsi
00007b1fbf9d7092  push r8
00007b1fbf9d7094  push r9
00007b1fbf9d7096  push r10
00007b1fbf9d7098  push r11
00007b1fbf9d709a  sub rsp, 0xF0
00007b1fbf9d70a1  vmovaps [rsp], xmm0
00007b1fbf9d70a6  vmovaps [rsp+0x10], xmm1
00007b1fbf9d70ac  vmovaps [rsp+0x20], xmm2
00007b1fbf9d70b2  vmovaps [rsp+0x30], xmm3
00007b1fbf9d70b8  vmovaps [rsp+0x40], xmm5
00007b1fbf9d70be  vmovaps [rsp+0x50], xmm6
00007b1fbf9d70c4  vmovaps [rsp+0x60], xmm7
00007b1fbf9d70ca  vmovaps [rsp+0x70], xmm8
00007b1fbf9d70d0  vmovaps [rsp+0x80], xmm9
00007b1fbf9d70d9  vmovaps [rsp+0x90], xmm10
00007b1fbf9d70e2  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d70eb  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d70f4  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d70fd  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d7106  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d710f  sub rsp, 0x30
00007b1fbf9d7113  movaps [rsp], xmm4
00007b1fbf9d7117  movaps [rsp+0x10], xmm9
00007b1fbf9d711d  movaps [rsp+0x20], xmm8
00007b1fbf9d7123  lea rdi, [rsp]
00007b1fbf9d7127  mov esi, 0x00
00007b1fbf9d712c  mov rax, 0x64AEE5F12530
00007b1fbf9d7136  call rax
00007b1fbf9d7138  movaps xmm4, [rsp]
00007b1fbf9d713c  add rsp, 0x30
00007b1fbf9d7140  vmovaps xmm0, [rsp]
00007b1fbf9d7145  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d714b  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d7151  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d7157  vmovaps xmm5, [rsp+0x40]
00007b1fbf9d715d  vmovaps xmm6, [rsp+0x50]
00007b1fbf9d7163  vmovaps xmm7, [rsp+0x60]
00007b1fbf9d7169  vmovaps xmm8, [rsp+0x70]
00007b1fbf9d716f  vmovaps xmm9, [rsp+0x80]
00007b1fbf9d7178  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d7181  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d718a  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d7193  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d719c  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d71a5  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d71ae  add rsp, 0xF0
00007b1fbf9d71b5  pop r11
00007b1fbf9d71b7  pop r10
00007b1fbf9d71b9  pop r9
00007b1fbf9d71bb  pop r8
00007b1fbf9d71bd  pop rsi
00007b1fbf9d71be  pop rdi
00007b1fbf9d71bf  pop rdx
00007b1fbf9d71c0  pop rcx
00007b1fbf9d71c1  pop rax
00007b1fbf9d71c2  add rsp, 0x08
00007b1fbf9d71c6  jmp 0x00007B1FBF9D5AE1
00007b1fbf9d71cb  sub rsp, 0x08
00007b1fbf9d71cf  push rax
00007b1fbf9d71d0  push rcx
00007b1fbf9d71d1  push rdx
00007b1fbf9d71d2  push rdi
00007b1fbf9d71d3  push rsi
00007b1fbf9d71d4  push r8
00007b1fbf9d71d6  push r9
00007b1fbf9d71d8  push r10
00007b1fbf9d71da  push r11
00007b1fbf9d71dc  sub rsp, 0xF0
00007b1fbf9d71e3  vmovaps [rsp], xmm0
00007b1fbf9d71e8  vmovaps [rsp+0x10], xmm1
00007b1fbf9d71ee  vmovaps [rsp+0x20], xmm2
00007b1fbf9d71f4  vmovaps [rsp+0x30], xmm3
00007b1fbf9d71fa  vmovaps [rsp+0x40], xmm4
00007b1fbf9d7200  vmovaps [rsp+0x50], xmm5
00007b1fbf9d7206  vmovaps [rsp+0x60], xmm6
00007b1fbf9d720c  vmovaps [rsp+0x70], xmm7
00007b1fbf9d7212  vmovaps [rsp+0x80], xmm8
00007b1fbf9d721b  vmovaps [rsp+0x90], xmm10
00007b1fbf9d7224  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d722d  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d7236  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d723f  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d7248  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d7251  sub rsp, 0x30
00007b1fbf9d7255  movaps [rsp], xmm9
00007b1fbf9d725a  movaps [rsp+0x10], xmm10
00007b1fbf9d7260  movaps [rsp+0x20], xmm8
00007b1fbf9d7266  lea rdi, [rsp]
00007b1fbf9d726a  mov esi, 0x00
00007b1fbf9d726f  mov rax, 0x64AEE5F12530
00007b1fbf9d7279  call rax
00007b1fbf9d727b  movaps xmm9, [rsp]
00007b1fbf9d7280  add rsp, 0x30
00007b1fbf9d7284  vmovaps xmm0, [rsp]
00007b1fbf9d7289  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d728f  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d7295  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d729b  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d72a1  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d72a7  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d72ad  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d72b3  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d72bc  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d72c5  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d72ce  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d72d7  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d72e0  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d72e9  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d72f2  add rsp, 0xF0
00007b1fbf9d72f9  pop r11
00007b1fbf9d72fb  pop r10
00007b1fbf9d72fd  pop r9
00007b1fbf9d72ff  pop r8
00007b1fbf9d7301  pop rsi
00007b1fbf9d7302  pop rdi
00007b1fbf9d7303  pop rdx
00007b1fbf9d7304  pop rcx
00007b1fbf9d7305  pop rax
00007b1fbf9d7306  add rsp, 0x08
00007b1fbf9d730a  jmp 0x00007B1FBF9D5AFB
00007b1fbf9d730f  call 0x00007B1FBF8D64F0
00007b1fbf9d7314  jmp 0x00007B1FBF9D5C15
00007b1fbf9d7319  call 0x00007B1FBF8D64F0
00007b1fbf9d731e  jmp 0x00007B1FBF9D5C2B
00007b1fbf9d7323  sub rsp, 0x08
00007b1fbf9d7327  push rax
00007b1fbf9d7328  push rcx
00007b1fbf9d7329  push rdx
00007b1fbf9d732a  push rdi
00007b1fbf9d732b  push rsi
00007b1fbf9d732c  push r8
00007b1fbf9d732e  push r9
00007b1fbf9d7330  push r10
00007b1fbf9d7332  push r11
00007b1fbf9d7334  sub rsp, 0xF0
00007b1fbf9d733b  vmovaps [rsp], xmm0
00007b1fbf9d7340  vmovaps [rsp+0x10], xmm2
00007b1fbf9d7346  vmovaps [rsp+0x20], xmm3
00007b1fbf9d734c  vmovaps [rsp+0x30], xmm4
00007b1fbf9d7352  vmovaps [rsp+0x40], xmm5
00007b1fbf9d7358  vmovaps [rsp+0x50], xmm6
00007b1fbf9d735e  vmovaps [rsp+0x60], xmm7
00007b1fbf9d7364  vmovaps [rsp+0x70], xmm8
00007b1fbf9d736a  vmovaps [rsp+0x80], xmm9
00007b1fbf9d7373  vmovaps [rsp+0x90], xmm10
00007b1fbf9d737c  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d7385  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d738e  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d7397  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d73a0  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d73a9  sub rsp, 0x30
00007b1fbf9d73ad  movaps [rsp], xmm1
00007b1fbf9d73b1  movaps [rsp+0x10], xmm6
00007b1fbf9d73b6  movaps [rsp+0x20], xmm15
00007b1fbf9d73bc  lea rdi, [rsp]
00007b1fbf9d73c0  mov esi, 0x00
00007b1fbf9d73c5  mov rax, 0x64AEE5F12530
00007b1fbf9d73cf  call rax
00007b1fbf9d73d1  movaps xmm1, [rsp]
00007b1fbf9d73d5  add rsp, 0x30
00007b1fbf9d73d9  vmovaps xmm0, [rsp]
00007b1fbf9d73de  vmovaps xmm2, [rsp+0x10]
00007b1fbf9d73e4  vmovaps xmm3, [rsp+0x20]
00007b1fbf9d73ea  vmovaps xmm4, [rsp+0x30]
00007b1fbf9d73f0  vmovaps xmm5, [rsp+0x40]
00007b1fbf9d73f6  vmovaps xmm6, [rsp+0x50]
00007b1fbf9d73fc  vmovaps xmm7, [rsp+0x60]
00007b1fbf9d7402  vmovaps xmm8, [rsp+0x70]
00007b1fbf9d7408  vmovaps xmm9, [rsp+0x80]
00007b1fbf9d7411  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d741a  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d7423  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d742c  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d7435  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d743e  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d7447  add rsp, 0xF0
00007b1fbf9d744e  pop r11
00007b1fbf9d7450  pop r10
00007b1fbf9d7452  pop r9
00007b1fbf9d7454  pop r8
00007b1fbf9d7456  pop rsi
00007b1fbf9d7457  pop rdi
00007b1fbf9d7458  pop rdx
00007b1fbf9d7459  pop rcx
00007b1fbf9d745a  pop rax
00007b1fbf9d745b  add rsp, 0x08
00007b1fbf9d745f  jmp 0x00007B1FBF9D5C68
00007b1fbf9d7464  call 0x00007B1FBF8E5820
00007b1fbf9d7469  jmp 0x00007B1FBF9D5C75
00007b1fbf9d746e  sub rsp, 0x08
00007b1fbf9d7472  push rax
00007b1fbf9d7473  push rcx
00007b1fbf9d7474  push rdx
00007b1fbf9d7475  push rdi
00007b1fbf9d7476  push rsi
00007b1fbf9d7477  push r8
00007b1fbf9d7479  push r9
00007b1fbf9d747b  push r10
00007b1fbf9d747d  push r11
00007b1fbf9d747f  sub rsp, 0xF0
00007b1fbf9d7486  vmovaps [rsp], xmm0
00007b1fbf9d748b  vmovaps [rsp+0x10], xmm1
00007b1fbf9d7491  vmovaps [rsp+0x20], xmm2
00007b1fbf9d7497  vmovaps [rsp+0x30], xmm3
00007b1fbf9d749d  vmovaps [rsp+0x40], xmm4
00007b1fbf9d74a3  vmovaps [rsp+0x50], xmm5
00007b1fbf9d74a9  vmovaps [rsp+0x60], xmm6
00007b1fbf9d74af  vmovaps [rsp+0x70], xmm7
00007b1fbf9d74b5  vmovaps [rsp+0x80], xmm8
00007b1fbf9d74be  vmovaps [rsp+0x90], xmm9
00007b1fbf9d74c7  vmovaps [rsp+0xA0], xmm10
00007b1fbf9d74d0  vmovaps [rsp+0xB0], xmm11
00007b1fbf9d74d9  vmovaps [rsp+0xC0], xmm12
00007b1fbf9d74e2  vmovaps [rsp+0xD0], xmm13
00007b1fbf9d74eb  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d74f4  sub rsp, 0x30
00007b1fbf9d74f8  movaps [rsp], xmm14
00007b1fbf9d74fd  movaps [rsp+0x10], xmm4
00007b1fbf9d7502  movaps [rsp+0x20], xmm3
00007b1fbf9d7507  lea rdi, [rsp]
00007b1fbf9d750b  mov esi, 0x00
00007b1fbf9d7510  mov rax, 0x64AEE5F12530
00007b1fbf9d751a  call rax
00007b1fbf9d751c  movaps xmm14, [rsp]
00007b1fbf9d7521  add rsp, 0x30
00007b1fbf9d7525  vmovaps xmm0, [rsp]
00007b1fbf9d752a  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d7530  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d7536  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d753c  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d7542  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d7548  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d754e  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d7554  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d755d  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d7566  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9d756f  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9d7578  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9d7581  vmovaps xmm13, [rsp+0xD0]
00007b1fbf9d758a  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d7593  add rsp, 0xF0
00007b1fbf9d759a  pop r11
00007b1fbf9d759c  pop r10
00007b1fbf9d759e  pop r9
00007b1fbf9d75a0  pop r8
00007b1fbf9d75a2  pop rsi
00007b1fbf9d75a3  pop rdi
00007b1fbf9d75a4  pop rdx
00007b1fbf9d75a5  pop rcx
00007b1fbf9d75a6  pop rax
00007b1fbf9d75a7  add rsp, 0x08
00007b1fbf9d75ab  jmp 0x00007B1FBF9D5C8F
00007b1fbf9d75b0  sub rsp, 0x08
00007b1fbf9d75b4  push rax
00007b1fbf9d75b5  push rcx
00007b1fbf9d75b6  push rdx
00007b1fbf9d75b7  push rdi
00007b1fbf9d75b8  push rsi
00007b1fbf9d75b9  push r8
00007b1fbf9d75bb  push r9
00007b1fbf9d75bd  push r10
00007b1fbf9d75bf  push r11
00007b1fbf9d75c1  sub rsp, 0xF0
00007b1fbf9d75c8  vmovaps [rsp], xmm0
00007b1fbf9d75cd  vmovaps [rsp+0x10], xmm1
00007b1fbf9d75d3  vmovaps [rsp+0x20], xmm2
00007b1fbf9d75d9  vmovaps [rsp+0x30], xmm3
00007b1fbf9d75df  vmovaps [rsp+0x40], xmm4
00007b1fbf9d75e5  vmovaps [rsp+0x50], xmm5
00007b1fbf9d75eb  vmovaps [rsp+0x60], xmm7
00007b1fbf9d75f1  vmovaps [rsp+0x70], xmm8
00007b1fbf9d75f7  vmovaps [rsp+0x80], xmm9
00007b1fbf9d7600  vmovaps [rsp+0x90], xmm10
00007b1fbf9d7609  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d7612  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d761b  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d7624  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d762d  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d7636  sub rsp, 0x30
00007b1fbf9d763a  movaps [rsp], xmm6
00007b1fbf9d763e  movaps [rsp+0x10], xmm9
00007b1fbf9d7644  movaps [rsp+0x20], xmm7
00007b1fbf9d7649  lea rdi, [rsp]
00007b1fbf9d764d  mov esi, 0x00
00007b1fbf9d7652  mov rax, 0x64AEE5F12530
00007b1fbf9d765c  call rax
00007b1fbf9d765e  movaps xmm6, [rsp]
00007b1fbf9d7662  add rsp, 0x30
00007b1fbf9d7666  vmovaps xmm0, [rsp]
00007b1fbf9d766b  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d7671  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d7677  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d767d  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d7683  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d7689  vmovaps xmm7, [rsp+0x60]
00007b1fbf9d768f  vmovaps xmm8, [rsp+0x70]
00007b1fbf9d7695  vmovaps xmm9, [rsp+0x80]
00007b1fbf9d769e  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d76a7  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d76b0  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d76b9  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d76c2  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d76cb  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d76d4  add rsp, 0xF0
00007b1fbf9d76db  pop r11
00007b1fbf9d76dd  pop r10
00007b1fbf9d76df  pop r9
00007b1fbf9d76e1  pop r8
00007b1fbf9d76e3  pop rsi
00007b1fbf9d76e4  pop rdi
00007b1fbf9d76e5  pop rdx
00007b1fbf9d76e6  pop rcx
00007b1fbf9d76e7  pop rax
00007b1fbf9d76e8  add rsp, 0x08
00007b1fbf9d76ec  jmp 0x00007B1FBF9D5CA7
00007b1fbf9d76f1  sub rsp, 0x08
00007b1fbf9d76f5  push rax
00007b1fbf9d76f6  push rcx
00007b1fbf9d76f7  push rdx
00007b1fbf9d76f8  push rdi
00007b1fbf9d76f9  push rsi
00007b1fbf9d76fa  push r8
00007b1fbf9d76fc  push r9
00007b1fbf9d76fe  push r10
00007b1fbf9d7700  push r11
00007b1fbf9d7702  sub rsp, 0xF0
00007b1fbf9d7709  vmovaps [rsp], xmm0
00007b1fbf9d770e  vmovaps [rsp+0x10], xmm1
00007b1fbf9d7714  vmovaps [rsp+0x20], xmm2
00007b1fbf9d771a  vmovaps [rsp+0x30], xmm3
00007b1fbf9d7720  vmovaps [rsp+0x40], xmm4
00007b1fbf9d7726  vmovaps [rsp+0x50], xmm5
00007b1fbf9d772c  vmovaps [rsp+0x60], xmm6
00007b1fbf9d7732  vmovaps [rsp+0x70], xmm8
00007b1fbf9d7738  vmovaps [rsp+0x80], xmm9
00007b1fbf9d7741  vmovaps [rsp+0x90], xmm10
00007b1fbf9d774a  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d7753  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d775c  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d7765  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d776e  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d7777  sub rsp, 0x30
00007b1fbf9d777b  movaps [rsp], xmm7
00007b1fbf9d777f  movaps [rsp+0x10], xmm4
00007b1fbf9d7784  movaps [rsp+0x20], xmm9
00007b1fbf9d778a  lea rdi, [rsp]
00007b1fbf9d778e  mov esi, 0x00
00007b1fbf9d7793  mov rax, 0x64AEE5F12530
00007b1fbf9d779d  call rax
00007b1fbf9d779f  movaps xmm7, [rsp]
00007b1fbf9d77a3  add rsp, 0x30
00007b1fbf9d77a7  vmovaps xmm0, [rsp]
00007b1fbf9d77ac  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d77b2  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d77b8  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d77be  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d77c4  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d77ca  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d77d0  vmovaps xmm8, [rsp+0x70]
00007b1fbf9d77d6  vmovaps xmm9, [rsp+0x80]
00007b1fbf9d77df  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d77e8  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d77f1  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d77fa  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d7803  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d780c  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d7815  add rsp, 0xF0
00007b1fbf9d781c  pop r11
00007b1fbf9d781e  pop r10
00007b1fbf9d7820  pop r9
00007b1fbf9d7822  pop r8
00007b1fbf9d7824  pop rsi
00007b1fbf9d7825  pop rdi
00007b1fbf9d7826  pop rdx
00007b1fbf9d7827  pop rcx
00007b1fbf9d7828  pop rax
00007b1fbf9d7829  add rsp, 0x08
00007b1fbf9d782d  jmp 0x00007B1FBF9D5CD4
00007b1fbf9d7832  sub rsp, 0x08
00007b1fbf9d7836  push rax
00007b1fbf9d7837  push rcx
00007b1fbf9d7838  push rdx
00007b1fbf9d7839  push rdi
00007b1fbf9d783a  push rsi
00007b1fbf9d783b  push r8
00007b1fbf9d783d  push r9
00007b1fbf9d783f  push r10
00007b1fbf9d7841  push r11
00007b1fbf9d7843  sub rsp, 0xF0
00007b1fbf9d784a  vmovaps [rsp], xmm0
00007b1fbf9d784f  vmovaps [rsp+0x10], xmm1
00007b1fbf9d7855  vmovaps [rsp+0x20], xmm2
00007b1fbf9d785b  vmovaps [rsp+0x30], xmm3
00007b1fbf9d7861  vmovaps [rsp+0x40], xmm5
00007b1fbf9d7867  vmovaps [rsp+0x50], xmm6
00007b1fbf9d786d  vmovaps [rsp+0x60], xmm7
00007b1fbf9d7873  vmovaps [rsp+0x70], xmm8
00007b1fbf9d7879  vmovaps [rsp+0x80], xmm9
00007b1fbf9d7882  vmovaps [rsp+0x90], xmm10
00007b1fbf9d788b  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d7894  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d789d  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d78a6  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d78af  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d78b8  sub rsp, 0x30
00007b1fbf9d78bc  movaps [rsp], xmm4
00007b1fbf9d78c0  movaps [rsp+0x10], xmm15
00007b1fbf9d78c6  movaps [rsp+0x20], xmm9
00007b1fbf9d78cc  lea rdi, [rsp]
00007b1fbf9d78d0  mov esi, 0x00
00007b1fbf9d78d5  mov rax, 0x64AEE5F12530
00007b1fbf9d78df  call rax
00007b1fbf9d78e1  movaps xmm4, [rsp]
00007b1fbf9d78e5  add rsp, 0x30
00007b1fbf9d78e9  vmovaps xmm0, [rsp]
00007b1fbf9d78ee  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d78f4  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d78fa  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d7900  vmovaps xmm5, [rsp+0x40]
00007b1fbf9d7906  vmovaps xmm6, [rsp+0x50]
00007b1fbf9d790c  vmovaps xmm7, [rsp+0x60]
00007b1fbf9d7912  vmovaps xmm8, [rsp+0x70]
00007b1fbf9d7918  vmovaps xmm9, [rsp+0x80]
00007b1fbf9d7921  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d792a  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d7933  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d793c  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d7945  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d794e  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d7957  add rsp, 0xF0
00007b1fbf9d795e  pop r11
00007b1fbf9d7960  pop r10
00007b1fbf9d7962  pop r9
00007b1fbf9d7964  pop r8
00007b1fbf9d7966  pop rsi
00007b1fbf9d7967  pop rdi
00007b1fbf9d7968  pop rdx
00007b1fbf9d7969  pop rcx
00007b1fbf9d796a  pop rax
00007b1fbf9d796b  add rsp, 0x08
00007b1fbf9d796f  jmp 0x00007B1FBF9D5CF9
00007b1fbf9d7974  call 0x00007B1FBF8E5820
00007b1fbf9d7979  jmp 0x00007B1FBF9D5D06
00007b1fbf9d797e  sub rsp, 0x08
00007b1fbf9d7982  push rax
00007b1fbf9d7983  push rcx
00007b1fbf9d7984  push rdx
00007b1fbf9d7985  push rdi
00007b1fbf9d7986  push rsi
00007b1fbf9d7987  push r8
00007b1fbf9d7989  push r9
00007b1fbf9d798b  push r10
00007b1fbf9d798d  push r11
00007b1fbf9d798f  sub rsp, 0xF0
00007b1fbf9d7996  vmovaps [rsp], xmm0
00007b1fbf9d799b  vmovaps [rsp+0x10], xmm1
00007b1fbf9d79a1  vmovaps [rsp+0x20], xmm2
00007b1fbf9d79a7  vmovaps [rsp+0x30], xmm4
00007b1fbf9d79ad  vmovaps [rsp+0x40], xmm5
00007b1fbf9d79b3  vmovaps [rsp+0x50], xmm6
00007b1fbf9d79b9  vmovaps [rsp+0x60], xmm7
00007b1fbf9d79bf  vmovaps [rsp+0x70], xmm8
00007b1fbf9d79c5  vmovaps [rsp+0x80], xmm9
00007b1fbf9d79ce  vmovaps [rsp+0x90], xmm10
00007b1fbf9d79d7  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d79e0  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d79e9  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d79f2  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d79fb  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d7a04  sub rsp, 0x30
00007b1fbf9d7a08  movaps [rsp], xmm3
00007b1fbf9d7a0c  movaps [rsp+0x10], xmm1
00007b1fbf9d7a11  movaps [rsp+0x20], xmm9
00007b1fbf9d7a17  lea rdi, [rsp]
00007b1fbf9d7a1b  mov esi, 0x00
00007b1fbf9d7a20  mov rax, 0x64AEE5F12530
00007b1fbf9d7a2a  call rax
00007b1fbf9d7a2c  movaps xmm3, [rsp]
00007b1fbf9d7a30  add rsp, 0x30
00007b1fbf9d7a34  vmovaps xmm0, [rsp]
00007b1fbf9d7a39  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d7a3f  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d7a45  vmovaps xmm4, [rsp+0x30]
00007b1fbf9d7a4b  vmovaps xmm5, [rsp+0x40]
00007b1fbf9d7a51  vmovaps xmm6, [rsp+0x50]
00007b1fbf9d7a57  vmovaps xmm7, [rsp+0x60]
00007b1fbf9d7a5d  vmovaps xmm8, [rsp+0x70]
00007b1fbf9d7a63  vmovaps xmm9, [rsp+0x80]
00007b1fbf9d7a6c  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d7a75  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d7a7e  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d7a87  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d7a90  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d7a99  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d7aa2  add rsp, 0xF0
00007b1fbf9d7aa9  pop r11
00007b1fbf9d7aab  pop r10
00007b1fbf9d7aad  pop r9
00007b1fbf9d7aaf  pop r8
00007b1fbf9d7ab1  pop rsi
00007b1fbf9d7ab2  pop rdi
00007b1fbf9d7ab3  pop rdx
00007b1fbf9d7ab4  pop rcx
00007b1fbf9d7ab5  pop rax
00007b1fbf9d7ab6  add rsp, 0x08
00007b1fbf9d7aba  jmp 0x00007B1FBF9D5D43
00007b1fbf9d7abf  sub rsp, 0x08
00007b1fbf9d7ac3  push rax
00007b1fbf9d7ac4  push rcx
00007b1fbf9d7ac5  push rdx
00007b1fbf9d7ac6  push rdi
00007b1fbf9d7ac7  push rsi
00007b1fbf9d7ac8  push r8
00007b1fbf9d7aca  push r9
00007b1fbf9d7acc  push r10
00007b1fbf9d7ace  push r11
00007b1fbf9d7ad0  sub rsp, 0xF0
00007b1fbf9d7ad7  vmovaps [rsp], xmm0
00007b1fbf9d7adc  vmovaps [rsp+0x10], xmm2
00007b1fbf9d7ae2  vmovaps [rsp+0x20], xmm3
00007b1fbf9d7ae8  vmovaps [rsp+0x30], xmm4
00007b1fbf9d7aee  vmovaps [rsp+0x40], xmm5
00007b1fbf9d7af4  vmovaps [rsp+0x50], xmm6
00007b1fbf9d7afa  vmovaps [rsp+0x60], xmm7
00007b1fbf9d7b00  vmovaps [rsp+0x70], xmm8
00007b1fbf9d7b06  vmovaps [rsp+0x80], xmm9
00007b1fbf9d7b0f  vmovaps [rsp+0x90], xmm10
00007b1fbf9d7b18  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d7b21  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d7b2a  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d7b33  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d7b3c  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d7b45  sub rsp, 0x30
00007b1fbf9d7b49  movaps [rsp], xmm1
00007b1fbf9d7b4d  movaps [rsp+0x10], xmm15
00007b1fbf9d7b53  movaps [rsp+0x20], xmm9
00007b1fbf9d7b59  lea rdi, [rsp]
00007b1fbf9d7b5d  mov esi, 0x00
00007b1fbf9d7b62  mov rax, 0x64AEE5F12530
00007b1fbf9d7b6c  call rax
00007b1fbf9d7b6e  movaps xmm1, [rsp]
00007b1fbf9d7b72  add rsp, 0x30
00007b1fbf9d7b76  vmovaps xmm0, [rsp]
00007b1fbf9d7b7b  vmovaps xmm2, [rsp+0x10]
00007b1fbf9d7b81  vmovaps xmm3, [rsp+0x20]
00007b1fbf9d7b87  vmovaps xmm4, [rsp+0x30]
00007b1fbf9d7b8d  vmovaps xmm5, [rsp+0x40]
00007b1fbf9d7b93  vmovaps xmm6, [rsp+0x50]
00007b1fbf9d7b99  vmovaps xmm7, [rsp+0x60]
00007b1fbf9d7b9f  vmovaps xmm8, [rsp+0x70]
00007b1fbf9d7ba5  vmovaps xmm9, [rsp+0x80]
00007b1fbf9d7bae  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d7bb7  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d7bc0  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d7bc9  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d7bd2  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d7bdb  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d7be4  add rsp, 0xF0
00007b1fbf9d7beb  pop r11
00007b1fbf9d7bed  pop r10
00007b1fbf9d7bef  pop r9
00007b1fbf9d7bf1  pop r8
00007b1fbf9d7bf3  pop rsi
00007b1fbf9d7bf4  pop rdi
00007b1fbf9d7bf5  pop rdx
00007b1fbf9d7bf6  pop rcx
00007b1fbf9d7bf7  pop rax
00007b1fbf9d7bf8  add rsp, 0x08
00007b1fbf9d7bfc  jmp 0x00007B1FBF9D5DCB
00007b1fbf9d7c01  call 0x00007B1FBF8E5820
00007b1fbf9d7c06  jmp 0x00007B1FBF9D5DD8
00007b1fbf9d7c0b  sub rsp, 0x08
00007b1fbf9d7c0f  push rax
00007b1fbf9d7c10  push rcx
00007b1fbf9d7c11  push rdx
00007b1fbf9d7c12  push rdi
00007b1fbf9d7c13  push rsi
00007b1fbf9d7c14  push r8
00007b1fbf9d7c16  push r9
00007b1fbf9d7c18  push r10
00007b1fbf9d7c1a  push r11
00007b1fbf9d7c1c  sub rsp, 0xF0
00007b1fbf9d7c23  vmovaps [rsp], xmm0
00007b1fbf9d7c28  vmovaps [rsp+0x10], xmm2
00007b1fbf9d7c2e  vmovaps [rsp+0x20], xmm3
00007b1fbf9d7c34  vmovaps [rsp+0x30], xmm4
00007b1fbf9d7c3a  vmovaps [rsp+0x40], xmm5
00007b1fbf9d7c40  vmovaps [rsp+0x50], xmm6
00007b1fbf9d7c46  vmovaps [rsp+0x60], xmm7
00007b1fbf9d7c4c  vmovaps [rsp+0x70], xmm8
00007b1fbf9d7c52  vmovaps [rsp+0x80], xmm9
00007b1fbf9d7c5b  vmovaps [rsp+0x90], xmm10
00007b1fbf9d7c64  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d7c6d  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d7c76  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d7c7f  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d7c88  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d7c91  sub rsp, 0x30
00007b1fbf9d7c95  movaps [rsp], xmm1
00007b1fbf9d7c99  movaps [rsp+0x10], xmm5
00007b1fbf9d7c9e  movaps [rsp+0x20], xmm7
00007b1fbf9d7ca3  lea rdi, [rsp]
00007b1fbf9d7ca7  mov esi, 0x00
00007b1fbf9d7cac  mov rax, 0x64AEE5F12530
00007b1fbf9d7cb6  call rax
00007b1fbf9d7cb8  movaps xmm1, [rsp]
00007b1fbf9d7cbc  add rsp, 0x30
00007b1fbf9d7cc0  vmovaps xmm0, [rsp]
00007b1fbf9d7cc5  vmovaps xmm2, [rsp+0x10]
00007b1fbf9d7ccb  vmovaps xmm3, [rsp+0x20]
00007b1fbf9d7cd1  vmovaps xmm4, [rsp+0x30]
00007b1fbf9d7cd7  vmovaps xmm5, [rsp+0x40]
00007b1fbf9d7cdd  vmovaps xmm6, [rsp+0x50]
00007b1fbf9d7ce3  vmovaps xmm7, [rsp+0x60]
00007b1fbf9d7ce9  vmovaps xmm8, [rsp+0x70]
00007b1fbf9d7cef  vmovaps xmm9, [rsp+0x80]
00007b1fbf9d7cf8  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d7d01  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d7d0a  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d7d13  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d7d1c  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d7d25  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d7d2e  add rsp, 0xF0
00007b1fbf9d7d35  pop r11
00007b1fbf9d7d37  pop r10
00007b1fbf9d7d39  pop r9
00007b1fbf9d7d3b  pop r8
00007b1fbf9d7d3d  pop rsi
00007b1fbf9d7d3e  pop rdi
00007b1fbf9d7d3f  pop rdx
00007b1fbf9d7d40  pop rcx
00007b1fbf9d7d41  pop rax
00007b1fbf9d7d42  add rsp, 0x08
00007b1fbf9d7d46  jmp 0x00007B1FBF9D5E7D
00007b1fbf9d7d4b  sub rsp, 0x08
00007b1fbf9d7d4f  push rax
00007b1fbf9d7d50  push rcx
00007b1fbf9d7d51  push rdx
00007b1fbf9d7d52  push rdi
00007b1fbf9d7d53  push rsi
00007b1fbf9d7d54  push r8
00007b1fbf9d7d56  push r9
00007b1fbf9d7d58  push r10
00007b1fbf9d7d5a  push r11
00007b1fbf9d7d5c  sub rsp, 0xF0
00007b1fbf9d7d63  vmovaps [rsp], xmm0
00007b1fbf9d7d68  vmovaps [rsp+0x10], xmm1
00007b1fbf9d7d6e  vmovaps [rsp+0x20], xmm2
00007b1fbf9d7d74  vmovaps [rsp+0x30], xmm3
00007b1fbf9d7d7a  vmovaps [rsp+0x40], xmm4
00007b1fbf9d7d80  vmovaps [rsp+0x50], xmm5
00007b1fbf9d7d86  vmovaps [rsp+0x60], xmm6
00007b1fbf9d7d8c  vmovaps [rsp+0x70], xmm8
00007b1fbf9d7d92  vmovaps [rsp+0x80], xmm9
00007b1fbf9d7d9b  vmovaps [rsp+0x90], xmm10
00007b1fbf9d7da4  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d7dad  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d7db6  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d7dbf  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d7dc8  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d7dd1  sub rsp, 0x30
00007b1fbf9d7dd5  movaps [rsp], xmm7
00007b1fbf9d7dd9  movaps [rsp+0x10], xmm5
00007b1fbf9d7dde  movaps [rsp+0x20], xmm15
00007b1fbf9d7de4  lea rdi, [rsp]
00007b1fbf9d7de8  mov esi, 0x00
00007b1fbf9d7ded  mov rax, 0x64AEE5F12530
00007b1fbf9d7df7  call rax
00007b1fbf9d7df9  movaps xmm7, [rsp]
00007b1fbf9d7dfd  add rsp, 0x30
00007b1fbf9d7e01  vmovaps xmm0, [rsp]
00007b1fbf9d7e06  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d7e0c  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d7e12  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d7e18  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d7e1e  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d7e24  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d7e2a  vmovaps xmm8, [rsp+0x70]
00007b1fbf9d7e30  vmovaps xmm9, [rsp+0x80]
00007b1fbf9d7e39  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d7e42  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d7e4b  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d7e54  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d7e5d  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d7e66  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d7e6f  add rsp, 0xF0
00007b1fbf9d7e76  pop r11
00007b1fbf9d7e78  pop r10
00007b1fbf9d7e7a  pop r9
00007b1fbf9d7e7c  pop r8
00007b1fbf9d7e7e  pop rsi
00007b1fbf9d7e7f  pop rdi
00007b1fbf9d7e80  pop rdx
00007b1fbf9d7e81  pop rcx
00007b1fbf9d7e82  pop rax
00007b1fbf9d7e83  add rsp, 0x08
00007b1fbf9d7e87  jmp 0x00007B1FBF9D5EB3
00007b1fbf9d7e8c  call 0x00007B1FBF8D64F0
00007b1fbf9d7e91  jmp 0x00007B1FBF9D5EC0
00007b1fbf9d7e96  sub rsp, 0x08
00007b1fbf9d7e9a  push rax
00007b1fbf9d7e9b  push rcx
00007b1fbf9d7e9c  push rdx
00007b1fbf9d7e9d  push rdi
00007b1fbf9d7e9e  push rsi
00007b1fbf9d7e9f  push r8
00007b1fbf9d7ea1  push r9
00007b1fbf9d7ea3  push r10
00007b1fbf9d7ea5  push r11
00007b1fbf9d7ea7  sub rsp, 0xF0
00007b1fbf9d7eae  vmovaps [rsp], xmm0
00007b1fbf9d7eb3  vmovaps [rsp+0x10], xmm1
00007b1fbf9d7eb9  vmovaps [rsp+0x20], xmm2
00007b1fbf9d7ebf  vmovaps [rsp+0x30], xmm3
00007b1fbf9d7ec5  vmovaps [rsp+0x40], xmm4
00007b1fbf9d7ecb  vmovaps [rsp+0x50], xmm5
00007b1fbf9d7ed1  vmovaps [rsp+0x60], xmm6
00007b1fbf9d7ed7  vmovaps [rsp+0x70], xmm7
00007b1fbf9d7edd  vmovaps [rsp+0x80], xmm8
00007b1fbf9d7ee6  vmovaps [rsp+0x90], xmm9
00007b1fbf9d7eef  vmovaps [rsp+0xA0], xmm10
00007b1fbf9d7ef8  vmovaps [rsp+0xB0], xmm11
00007b1fbf9d7f01  vmovaps [rsp+0xC0], xmm12
00007b1fbf9d7f0a  vmovaps [rsp+0xD0], xmm13
00007b1fbf9d7f13  vmovaps [rsp+0xE0], xmm14
00007b1fbf9d7f1c  sub rsp, 0x30
00007b1fbf9d7f20  movaps [rsp], xmm15
00007b1fbf9d7f25  movaps [rsp+0x10], xmm5
00007b1fbf9d7f2a  movaps [rsp+0x20], xmm3
00007b1fbf9d7f2f  lea rdi, [rsp]
00007b1fbf9d7f33  mov esi, 0x00
00007b1fbf9d7f38  mov rax, 0x64AEE5F12530
00007b1fbf9d7f42  call rax
00007b1fbf9d7f44  movaps xmm15, [rsp]
00007b1fbf9d7f49  add rsp, 0x30
00007b1fbf9d7f4d  vmovaps xmm0, [rsp]
00007b1fbf9d7f52  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d7f58  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d7f5e  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d7f64  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d7f6a  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d7f70  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d7f76  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d7f7c  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d7f85  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d7f8e  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9d7f97  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9d7fa0  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9d7fa9  vmovaps xmm13, [rsp+0xD0]
00007b1fbf9d7fb2  vmovaps xmm14, [rsp+0xE0]
00007b1fbf9d7fbb  add rsp, 0xF0
00007b1fbf9d7fc2  pop r11
00007b1fbf9d7fc4  pop r10
00007b1fbf9d7fc6  pop r9
00007b1fbf9d7fc8  pop r8
00007b1fbf9d7fca  pop rsi
00007b1fbf9d7fcb  pop rdi
00007b1fbf9d7fcc  pop rdx
00007b1fbf9d7fcd  pop rcx
00007b1fbf9d7fce  pop rax
00007b1fbf9d7fcf  add rsp, 0x08
00007b1fbf9d7fd3  jmp 0x00007B1FBF9D5EE6
00007b1fbf9d7fd8  sub rsp, 0x08
00007b1fbf9d7fdc  push rax
00007b1fbf9d7fdd  push rcx
00007b1fbf9d7fde  push rdx
00007b1fbf9d7fdf  push rdi
00007b1fbf9d7fe0  push rsi
00007b1fbf9d7fe1  push r8
00007b1fbf9d7fe3  push r9
00007b1fbf9d7fe5  push r10
00007b1fbf9d7fe7  push r11
00007b1fbf9d7fe9  sub rsp, 0xF0
00007b1fbf9d7ff0  vmovaps [rsp], xmm0
00007b1fbf9d7ff5  vmovaps [rsp+0x10], xmm2
00007b1fbf9d7ffb  vmovaps [rsp+0x20], xmm3
00007b1fbf9d8001  vmovaps [rsp+0x30], xmm4
00007b1fbf9d8007  vmovaps [rsp+0x40], xmm5
00007b1fbf9d800d  vmovaps [rsp+0x50], xmm6
00007b1fbf9d8013  vmovaps [rsp+0x60], xmm7
00007b1fbf9d8019  vmovaps [rsp+0x70], xmm8
00007b1fbf9d801f  vmovaps [rsp+0x80], xmm9
00007b1fbf9d8028  vmovaps [rsp+0x90], xmm10
00007b1fbf9d8031  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d803a  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d8043  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d804c  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d8055  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d805e  sub rsp, 0x30
00007b1fbf9d8062  movaps [rsp], xmm1
00007b1fbf9d8066  movaps [rsp+0x10], xmm5
00007b1fbf9d806b  movaps [rsp+0x20], xmm4
00007b1fbf9d8070  lea rdi, [rsp]
00007b1fbf9d8074  mov esi, 0x00
00007b1fbf9d8079  mov rax, 0x64AEE5F12530
00007b1fbf9d8083  call rax
00007b1fbf9d8085  movaps xmm1, [rsp]
00007b1fbf9d8089  add rsp, 0x30
00007b1fbf9d808d  vmovaps xmm0, [rsp]
00007b1fbf9d8092  vmovaps xmm2, [rsp+0x10]
00007b1fbf9d8098  vmovaps xmm3, [rsp+0x20]
00007b1fbf9d809e  vmovaps xmm4, [rsp+0x30]
00007b1fbf9d80a4  vmovaps xmm5, [rsp+0x40]
00007b1fbf9d80aa  vmovaps xmm6, [rsp+0x50]
00007b1fbf9d80b0  vmovaps xmm7, [rsp+0x60]
00007b1fbf9d80b6  vmovaps xmm8, [rsp+0x70]
00007b1fbf9d80bc  vmovaps xmm9, [rsp+0x80]
00007b1fbf9d80c5  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d80ce  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d80d7  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d80e0  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d80e9  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d80f2  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d80fb  add rsp, 0xF0
00007b1fbf9d8102  pop r11
00007b1fbf9d8104  pop r10
00007b1fbf9d8106  pop r9
00007b1fbf9d8108  pop r8
00007b1fbf9d810a  pop rsi
00007b1fbf9d810b  pop rdi
00007b1fbf9d810c  pop rdx
00007b1fbf9d810d  pop rcx
00007b1fbf9d810e  pop rax
00007b1fbf9d810f  add rsp, 0x08
00007b1fbf9d8113  jmp 0x00007B1FBF9D5F06
00007b1fbf9d8118  sub rsp, 0x08
00007b1fbf9d811c  push rax
00007b1fbf9d811d  push rcx
00007b1fbf9d811e  push rdx
00007b1fbf9d811f  push rdi
00007b1fbf9d8120  push rsi
00007b1fbf9d8121  push r8
00007b1fbf9d8123  push r9
00007b1fbf9d8125  push r10
00007b1fbf9d8127  push r11
00007b1fbf9d8129  sub rsp, 0xF0
00007b1fbf9d8130  vmovaps [rsp], xmm0
00007b1fbf9d8135  vmovaps [rsp+0x10], xmm1
00007b1fbf9d813b  vmovaps [rsp+0x20], xmm2
00007b1fbf9d8141  vmovaps [rsp+0x30], xmm3
00007b1fbf9d8147  vmovaps [rsp+0x40], xmm5
00007b1fbf9d814d  vmovaps [rsp+0x50], xmm6
00007b1fbf9d8153  vmovaps [rsp+0x60], xmm7
00007b1fbf9d8159  vmovaps [rsp+0x70], xmm8
00007b1fbf9d815f  vmovaps [rsp+0x80], xmm9
00007b1fbf9d8168  vmovaps [rsp+0x90], xmm10
00007b1fbf9d8171  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d817a  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d8183  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d818c  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d8195  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d819e  sub rsp, 0x30
00007b1fbf9d81a2  movaps [rsp], xmm4
00007b1fbf9d81a6  movaps [rsp+0x10], xmm3
00007b1fbf9d81ab  movaps [rsp+0x20], xmm5
00007b1fbf9d81b0  lea rdi, [rsp]
00007b1fbf9d81b4  mov esi, 0x00
00007b1fbf9d81b9  mov rax, 0x64AEE5F12530
00007b1fbf9d81c3  call rax
00007b1fbf9d81c5  movaps xmm4, [rsp]
00007b1fbf9d81c9  add rsp, 0x30
00007b1fbf9d81cd  vmovaps xmm0, [rsp]
00007b1fbf9d81d2  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d81d8  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d81de  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d81e4  vmovaps xmm5, [rsp+0x40]
00007b1fbf9d81ea  vmovaps xmm6, [rsp+0x50]
00007b1fbf9d81f0  vmovaps xmm7, [rsp+0x60]
00007b1fbf9d81f6  vmovaps xmm8, [rsp+0x70]
00007b1fbf9d81fc  vmovaps xmm9, [rsp+0x80]
00007b1fbf9d8205  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d820e  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d8217  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d8220  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d8229  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d8232  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d823b  add rsp, 0xF0
00007b1fbf9d8242  pop r11
00007b1fbf9d8244  pop r10
00007b1fbf9d8246  pop r9
00007b1fbf9d8248  pop r8
00007b1fbf9d824a  pop rsi
00007b1fbf9d824b  pop rdi
00007b1fbf9d824c  pop rdx
00007b1fbf9d824d  pop rcx
00007b1fbf9d824e  pop rax
00007b1fbf9d824f  add rsp, 0x08
00007b1fbf9d8253  jmp 0x00007B1FBF9D5F54
00007b1fbf9d8258  call 0x00007B1FBF8D64F0
00007b1fbf9d825d  jmp 0x00007B1FBF9D5F61
00007b1fbf9d8262  sub rsp, 0x08
00007b1fbf9d8266  push rax
00007b1fbf9d8267  push rcx
00007b1fbf9d8268  push rdx
00007b1fbf9d8269  push rdi
00007b1fbf9d826a  push rsi
00007b1fbf9d826b  push r8
00007b1fbf9d826d  push r9
00007b1fbf9d826f  push r10
00007b1fbf9d8271  push r11
00007b1fbf9d8273  sub rsp, 0xF0
00007b1fbf9d827a  vmovaps [rsp], xmm0
00007b1fbf9d827f  vmovaps [rsp+0x10], xmm1
00007b1fbf9d8285  vmovaps [rsp+0x20], xmm2
00007b1fbf9d828b  vmovaps [rsp+0x30], xmm3
00007b1fbf9d8291  vmovaps [rsp+0x40], xmm4
00007b1fbf9d8297  vmovaps [rsp+0x50], xmm6
00007b1fbf9d829d  vmovaps [rsp+0x60], xmm7
00007b1fbf9d82a3  vmovaps [rsp+0x70], xmm8
00007b1fbf9d82a9  vmovaps [rsp+0x80], xmm9
00007b1fbf9d82b2  vmovaps [rsp+0x90], xmm10
00007b1fbf9d82bb  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d82c4  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d82cd  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d82d6  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d82df  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d82e8  sub rsp, 0x30
00007b1fbf9d82ec  movaps [rsp], xmm5
00007b1fbf9d82f0  movaps [rsp+0x10], xmm6
00007b1fbf9d82f5  movaps [rsp+0x20], xmm3
00007b1fbf9d82fa  lea rdi, [rsp]
00007b1fbf9d82fe  mov esi, 0x00
00007b1fbf9d8303  mov rax, 0x64AEE5F12530
00007b1fbf9d830d  call rax
00007b1fbf9d830f  movaps xmm5, [rsp]
00007b1fbf9d8313  add rsp, 0x30
00007b1fbf9d8317  vmovaps xmm0, [rsp]
00007b1fbf9d831c  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d8322  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d8328  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d832e  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d8334  vmovaps xmm6, [rsp+0x50]
00007b1fbf9d833a  vmovaps xmm7, [rsp+0x60]
00007b1fbf9d8340  vmovaps xmm8, [rsp+0x70]
00007b1fbf9d8346  vmovaps xmm9, [rsp+0x80]
00007b1fbf9d834f  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d8358  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d8361  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d836a  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d8373  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d837c  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d8385  add rsp, 0xF0
00007b1fbf9d838c  pop r11
00007b1fbf9d838e  pop r10
00007b1fbf9d8390  pop r9
00007b1fbf9d8392  pop r8
00007b1fbf9d8394  pop rsi
00007b1fbf9d8395  pop rdi
00007b1fbf9d8396  pop rdx
00007b1fbf9d8397  pop rcx
00007b1fbf9d8398  pop rax
00007b1fbf9d8399  add rsp, 0x08
00007b1fbf9d839d  jmp 0x00007B1FBF9D5F87
00007b1fbf9d83a2  sub rsp, 0x08
00007b1fbf9d83a6  push rax
00007b1fbf9d83a7  push rcx
00007b1fbf9d83a8  push rdx
00007b1fbf9d83a9  push rdi
00007b1fbf9d83aa  push rsi
00007b1fbf9d83ab  push r8
00007b1fbf9d83ad  push r9
00007b1fbf9d83af  push r10
00007b1fbf9d83b1  push r11
00007b1fbf9d83b3  sub rsp, 0xF0
00007b1fbf9d83ba  vmovaps [rsp], xmm0
00007b1fbf9d83bf  vmovaps [rsp+0x10], xmm1
00007b1fbf9d83c5  vmovaps [rsp+0x20], xmm2
00007b1fbf9d83cb  vmovaps [rsp+0x30], xmm3
00007b1fbf9d83d1  vmovaps [rsp+0x40], xmm4
00007b1fbf9d83d7  vmovaps [rsp+0x50], xmm5
00007b1fbf9d83dd  vmovaps [rsp+0x60], xmm7
00007b1fbf9d83e3  vmovaps [rsp+0x70], xmm8
00007b1fbf9d83e9  vmovaps [rsp+0x80], xmm9
00007b1fbf9d83f2  vmovaps [rsp+0x90], xmm10
00007b1fbf9d83fb  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d8404  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d840d  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d8416  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d841f  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d8428  sub rsp, 0x30
00007b1fbf9d842c  movaps [rsp], xmm6
00007b1fbf9d8430  movaps [rsp+0x10], xmm9
00007b1fbf9d8436  movaps [rsp+0x20], xmm1
00007b1fbf9d843b  lea rdi, [rsp]
00007b1fbf9d843f  mov esi, 0x00
00007b1fbf9d8444  mov rax, 0x64AEE5F12530
00007b1fbf9d844e  call rax
00007b1fbf9d8450  movaps xmm6, [rsp]
00007b1fbf9d8454  add rsp, 0x30
00007b1fbf9d8458  vmovaps xmm0, [rsp]
00007b1fbf9d845d  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d8463  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d8469  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d846f  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d8475  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d847b  vmovaps xmm7, [rsp+0x60]
00007b1fbf9d8481  vmovaps xmm8, [rsp+0x70]
00007b1fbf9d8487  vmovaps xmm9, [rsp+0x80]
00007b1fbf9d8490  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d8499  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d84a2  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d84ab  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d84b4  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d84bd  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d84c6  add rsp, 0xF0
00007b1fbf9d84cd  pop r11
00007b1fbf9d84cf  pop r10
00007b1fbf9d84d1  pop r9
00007b1fbf9d84d3  pop r8
00007b1fbf9d84d5  pop rsi
00007b1fbf9d84d6  pop rdi
00007b1fbf9d84d7  pop rdx
00007b1fbf9d84d8  pop rcx
00007b1fbf9d84d9  pop rax
00007b1fbf9d84da  add rsp, 0x08
00007b1fbf9d84de  jmp 0x00007B1FBF9D5FAB
00007b1fbf9d84e3  sub rsp, 0x08
00007b1fbf9d84e7  push rax
00007b1fbf9d84e8  push rcx
00007b1fbf9d84e9  push rdx
00007b1fbf9d84ea  push rdi
00007b1fbf9d84eb  push rsi
00007b1fbf9d84ec  push r8
00007b1fbf9d84ee  push r9
00007b1fbf9d84f0  push r10
00007b1fbf9d84f2  push r11
00007b1fbf9d84f4  sub rsp, 0xF0
00007b1fbf9d84fb  vmovaps [rsp], xmm0
00007b1fbf9d8500  vmovaps [rsp+0x10], xmm1
00007b1fbf9d8506  vmovaps [rsp+0x20], xmm2
00007b1fbf9d850c  vmovaps [rsp+0x30], xmm3
00007b1fbf9d8512  vmovaps [rsp+0x40], xmm4
00007b1fbf9d8518  vmovaps [rsp+0x50], xmm5
00007b1fbf9d851e  vmovaps [rsp+0x60], xmm6
00007b1fbf9d8524  vmovaps [rsp+0x70], xmm7
00007b1fbf9d852a  vmovaps [rsp+0x80], xmm8
00007b1fbf9d8533  vmovaps [rsp+0x90], xmm10
00007b1fbf9d853c  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d8545  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d854e  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d8557  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d8560  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d8569  sub rsp, 0x30
00007b1fbf9d856d  movaps [rsp], xmm9
00007b1fbf9d8572  movaps [rsp+0x10], xmm3
00007b1fbf9d8577  movaps [rsp+0x20], xmm1
00007b1fbf9d857c  lea rdi, [rsp]
00007b1fbf9d8580  mov esi, 0x00
00007b1fbf9d8585  mov rax, 0x64AEE5F12530
00007b1fbf9d858f  call rax
00007b1fbf9d8591  movaps xmm9, [rsp]
00007b1fbf9d8596  add rsp, 0x30
00007b1fbf9d859a  vmovaps xmm0, [rsp]
00007b1fbf9d859f  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d85a5  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d85ab  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d85b1  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d85b7  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d85bd  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d85c3  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d85c9  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d85d2  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d85db  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d85e4  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d85ed  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d85f6  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d85ff  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d8608  add rsp, 0xF0
00007b1fbf9d860f  pop r11
00007b1fbf9d8611  pop r10
00007b1fbf9d8613  pop r9
00007b1fbf9d8615  pop r8
00007b1fbf9d8617  pop rsi
00007b1fbf9d8618  pop rdi
00007b1fbf9d8619  pop rdx
00007b1fbf9d861a  pop rcx
00007b1fbf9d861b  pop rax
00007b1fbf9d861c  add rsp, 0x08
00007b1fbf9d8620  jmp 0x00007B1FBF9D5FF7
00007b1fbf9d8625  call 0x00007B1FBF8D64F0
00007b1fbf9d862a  jmp 0x00007B1FBF9D6004
00007b1fbf9d862f  sub rsp, 0x08
00007b1fbf9d8633  push rax
00007b1fbf9d8634  push rcx
00007b1fbf9d8635  push rdx
00007b1fbf9d8636  push rdi
00007b1fbf9d8637  push rsi
00007b1fbf9d8638  push r8
00007b1fbf9d863a  push r9
00007b1fbf9d863c  push r10
00007b1fbf9d863e  push r11
00007b1fbf9d8640  sub rsp, 0xF0
00007b1fbf9d8647  vmovaps [rsp], xmm0
00007b1fbf9d864c  vmovaps [rsp+0x10], xmm1
00007b1fbf9d8652  vmovaps [rsp+0x20], xmm2
00007b1fbf9d8658  vmovaps [rsp+0x30], xmm3
00007b1fbf9d865e  vmovaps [rsp+0x40], xmm4
00007b1fbf9d8664  vmovaps [rsp+0x50], xmm5
00007b1fbf9d866a  vmovaps [rsp+0x60], xmm6
00007b1fbf9d8670  vmovaps [rsp+0x70], xmm7
00007b1fbf9d8676  vmovaps [rsp+0x80], xmm8
00007b1fbf9d867f  vmovaps [rsp+0x90], xmm9
00007b1fbf9d8688  vmovaps [rsp+0xA0], xmm10
00007b1fbf9d8691  vmovaps [rsp+0xB0], xmm11
00007b1fbf9d869a  vmovaps [rsp+0xC0], xmm12
00007b1fbf9d86a3  vmovaps [rsp+0xD0], xmm13
00007b1fbf9d86ac  vmovaps [rsp+0xE0], xmm14
00007b1fbf9d86b5  sub rsp, 0x30
00007b1fbf9d86b9  movaps [rsp], xmm15
00007b1fbf9d86be  movaps [rsp+0x10], xmm3
00007b1fbf9d86c3  movaps [rsp+0x20], xmm7
00007b1fbf9d86c8  lea rdi, [rsp]
00007b1fbf9d86cc  mov esi, 0x00
00007b1fbf9d86d1  mov rax, 0x64AEE5F12530
00007b1fbf9d86db  call rax
00007b1fbf9d86dd  movaps xmm15, [rsp]
00007b1fbf9d86e2  add rsp, 0x30
00007b1fbf9d86e6  vmovaps xmm0, [rsp]
00007b1fbf9d86eb  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d86f1  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d86f7  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d86fd  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d8703  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d8709  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d870f  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d8715  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d871e  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d8727  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9d8730  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9d8739  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9d8742  vmovaps xmm13, [rsp+0xD0]
00007b1fbf9d874b  vmovaps xmm14, [rsp+0xE0]
00007b1fbf9d8754  add rsp, 0xF0
00007b1fbf9d875b  pop r11
00007b1fbf9d875d  pop r10
00007b1fbf9d875f  pop r9
00007b1fbf9d8761  pop r8
00007b1fbf9d8763  pop rsi
00007b1fbf9d8764  pop rdi
00007b1fbf9d8765  pop rdx
00007b1fbf9d8766  pop rcx
00007b1fbf9d8767  pop rax
00007b1fbf9d8768  add rsp, 0x08
00007b1fbf9d876c  jmp 0x00007B1FBF9D6030
00007b1fbf9d8771  sub rsp, 0x08
00007b1fbf9d8775  push rax
00007b1fbf9d8776  push rcx
00007b1fbf9d8777  push rdx
00007b1fbf9d8778  push rdi
00007b1fbf9d8779  push rsi
00007b1fbf9d877a  push r8
00007b1fbf9d877c  push r9
00007b1fbf9d877e  push r10
00007b1fbf9d8780  push r11
00007b1fbf9d8782  sub rsp, 0xF0
00007b1fbf9d8789  vmovaps [rsp], xmm0
00007b1fbf9d878e  vmovaps [rsp+0x10], xmm1
00007b1fbf9d8794  vmovaps [rsp+0x20], xmm2
00007b1fbf9d879a  vmovaps [rsp+0x30], xmm4
00007b1fbf9d87a0  vmovaps [rsp+0x40], xmm5
00007b1fbf9d87a6  vmovaps [rsp+0x50], xmm6
00007b1fbf9d87ac  vmovaps [rsp+0x60], xmm7
00007b1fbf9d87b2  vmovaps [rsp+0x70], xmm8
00007b1fbf9d87b8  vmovaps [rsp+0x80], xmm9
00007b1fbf9d87c1  vmovaps [rsp+0x90], xmm10
00007b1fbf9d87ca  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d87d3  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d87dc  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d87e5  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d87ee  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d87f7  sub rsp, 0x30
00007b1fbf9d87fb  movaps [rsp], xmm3
00007b1fbf9d87ff  movaps [rsp+0x10], xmm1
00007b1fbf9d8804  movaps [rsp+0x20], xmm15
00007b1fbf9d880a  lea rdi, [rsp]
00007b1fbf9d880e  mov esi, 0x00
00007b1fbf9d8813  mov rax, 0x64AEE5F12530
00007b1fbf9d881d  call rax
00007b1fbf9d881f  movaps xmm3, [rsp]
00007b1fbf9d8823  add rsp, 0x30
00007b1fbf9d8827  vmovaps xmm0, [rsp]
00007b1fbf9d882c  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d8832  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d8838  vmovaps xmm4, [rsp+0x30]
00007b1fbf9d883e  vmovaps xmm5, [rsp+0x40]
00007b1fbf9d8844  vmovaps xmm6, [rsp+0x50]
00007b1fbf9d884a  vmovaps xmm7, [rsp+0x60]
00007b1fbf9d8850  vmovaps xmm8, [rsp+0x70]
00007b1fbf9d8856  vmovaps xmm9, [rsp+0x80]
00007b1fbf9d885f  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d8868  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d8871  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d887a  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d8883  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d888c  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d8895  add rsp, 0xF0
00007b1fbf9d889c  pop r11
00007b1fbf9d889e  pop r10
00007b1fbf9d88a0  pop r9
00007b1fbf9d88a2  pop r8
00007b1fbf9d88a4  pop rsi
00007b1fbf9d88a5  pop rdi
00007b1fbf9d88a6  pop rdx
00007b1fbf9d88a7  pop rcx
00007b1fbf9d88a8  pop rax
00007b1fbf9d88a9  add rsp, 0x08
00007b1fbf9d88ad  jmp 0x00007B1FBF9D60BF
00007b1fbf9d88b2  call 0x00007B1FBF8D64F0
00007b1fbf9d88b7  jmp 0x00007B1FBF9D60C9
00007b1fbf9d88bc  sub rsp, 0x08
00007b1fbf9d88c0  push rax
00007b1fbf9d88c1  push rcx
00007b1fbf9d88c2  push rdx
00007b1fbf9d88c3  push rdi
00007b1fbf9d88c4  push rsi
00007b1fbf9d88c5  push r8
00007b1fbf9d88c7  push r9
00007b1fbf9d88c9  push r10
00007b1fbf9d88cb  push r11
00007b1fbf9d88cd  sub rsp, 0xF0
00007b1fbf9d88d4  vmovaps [rsp], xmm0
00007b1fbf9d88d9  vmovaps [rsp+0x10], xmm1
00007b1fbf9d88df  vmovaps [rsp+0x20], xmm2
00007b1fbf9d88e5  vmovaps [rsp+0x30], xmm3
00007b1fbf9d88eb  vmovaps [rsp+0x40], xmm4
00007b1fbf9d88f1  vmovaps [rsp+0x50], xmm5
00007b1fbf9d88f7  vmovaps [rsp+0x60], xmm6
00007b1fbf9d88fd  vmovaps [rsp+0x70], xmm7
00007b1fbf9d8903  vmovaps [rsp+0x80], xmm8
00007b1fbf9d890c  vmovaps [rsp+0x90], xmm9
00007b1fbf9d8915  vmovaps [rsp+0xA0], xmm10
00007b1fbf9d891e  vmovaps [rsp+0xB0], xmm11
00007b1fbf9d8927  vmovaps [rsp+0xC0], xmm12
00007b1fbf9d8930  vmovaps [rsp+0xD0], xmm13
00007b1fbf9d8939  vmovaps [rsp+0xE0], xmm14
00007b1fbf9d8942  sub rsp, 0x30
00007b1fbf9d8946  movaps [rsp], xmm15
00007b1fbf9d894b  movaps [rsp+0x10], xmm14
00007b1fbf9d8951  movaps [rsp+0x20], xmm4
00007b1fbf9d8956  lea rdi, [rsp]
00007b1fbf9d895a  mov esi, 0x00
00007b1fbf9d895f  mov rax, 0x64AEE5F12530
00007b1fbf9d8969  call rax
00007b1fbf9d896b  movaps xmm15, [rsp]
00007b1fbf9d8970  add rsp, 0x30
00007b1fbf9d8974  vmovaps xmm0, [rsp]
00007b1fbf9d8979  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d897f  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d8985  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d898b  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d8991  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d8997  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d899d  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d89a3  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d89ac  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d89b5  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9d89be  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9d89c7  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9d89d0  vmovaps xmm13, [rsp+0xD0]
00007b1fbf9d89d9  vmovaps xmm14, [rsp+0xE0]
00007b1fbf9d89e2  add rsp, 0xF0
00007b1fbf9d89e9  pop r11
00007b1fbf9d89eb  pop r10
00007b1fbf9d89ed  pop r9
00007b1fbf9d89ef  pop r8
00007b1fbf9d89f1  pop rsi
00007b1fbf9d89f2  pop rdi
00007b1fbf9d89f3  pop rdx
00007b1fbf9d89f4  pop rcx
00007b1fbf9d89f5  pop rax
00007b1fbf9d89f6  add rsp, 0x08
00007b1fbf9d89fa  jmp 0x00007B1FBF9D60F7
00007b1fbf9d89ff  sub rsp, 0x08
00007b1fbf9d8a03  push rax
00007b1fbf9d8a04  push rcx
00007b1fbf9d8a05  push rdx
00007b1fbf9d8a06  push rdi
00007b1fbf9d8a07  push rsi
00007b1fbf9d8a08  push r8
00007b1fbf9d8a0a  push r9
00007b1fbf9d8a0c  push r10
00007b1fbf9d8a0e  push r11
00007b1fbf9d8a10  sub rsp, 0xF0
00007b1fbf9d8a17  vmovaps [rsp], xmm0
00007b1fbf9d8a1c  vmovaps [rsp+0x10], xmm1
00007b1fbf9d8a22  vmovaps [rsp+0x20], xmm2
00007b1fbf9d8a28  vmovaps [rsp+0x30], xmm3
00007b1fbf9d8a2e  vmovaps [rsp+0x40], xmm4
00007b1fbf9d8a34  vmovaps [rsp+0x50], xmm5
00007b1fbf9d8a3a  vmovaps [rsp+0x60], xmm6
00007b1fbf9d8a40  vmovaps [rsp+0x70], xmm7
00007b1fbf9d8a46  vmovaps [rsp+0x80], xmm8
00007b1fbf9d8a4f  vmovaps [rsp+0x90], xmm9
00007b1fbf9d8a58  vmovaps [rsp+0xA0], xmm10
00007b1fbf9d8a61  vmovaps [rsp+0xB0], xmm11
00007b1fbf9d8a6a  vmovaps [rsp+0xC0], xmm12
00007b1fbf9d8a73  vmovaps [rsp+0xD0], xmm13
00007b1fbf9d8a7c  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d8a85  sub rsp, 0x30
00007b1fbf9d8a89  movaps [rsp], xmm14
00007b1fbf9d8a8e  movaps [rsp+0x10], xmm2
00007b1fbf9d8a93  movaps [rsp+0x20], xmm1
00007b1fbf9d8a98  lea rdi, [rsp]
00007b1fbf9d8a9c  mov esi, 0x00
00007b1fbf9d8aa1  mov rax, 0x64AEE5F12530
00007b1fbf9d8aab  call rax
00007b1fbf9d8aad  movaps xmm14, [rsp]
00007b1fbf9d8ab2  add rsp, 0x30
00007b1fbf9d8ab6  vmovaps xmm0, [rsp]
00007b1fbf9d8abb  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d8ac1  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d8ac7  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d8acd  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d8ad3  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d8ad9  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d8adf  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d8ae5  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d8aee  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d8af7  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9d8b00  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9d8b09  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9d8b12  vmovaps xmm13, [rsp+0xD0]
00007b1fbf9d8b1b  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d8b24  add rsp, 0xF0
00007b1fbf9d8b2b  pop r11
00007b1fbf9d8b2d  pop r10
00007b1fbf9d8b2f  pop r9
00007b1fbf9d8b31  pop r8
00007b1fbf9d8b33  pop rsi
00007b1fbf9d8b34  pop rdi
00007b1fbf9d8b35  pop rdx
00007b1fbf9d8b36  pop rcx
00007b1fbf9d8b37  pop rax
00007b1fbf9d8b38  add rsp, 0x08
00007b1fbf9d8b3c  jmp 0x00007B1FBF9D611D
00007b1fbf9d8b41  sub rsp, 0x08
00007b1fbf9d8b45  push rax
00007b1fbf9d8b46  push rcx
00007b1fbf9d8b47  push rdx
00007b1fbf9d8b48  push rdi
00007b1fbf9d8b49  push rsi
00007b1fbf9d8b4a  push r8
00007b1fbf9d8b4c  push r9
00007b1fbf9d8b4e  push r10
00007b1fbf9d8b50  push r11
00007b1fbf9d8b52  sub rsp, 0xF0
00007b1fbf9d8b59  vmovaps [rsp], xmm0
00007b1fbf9d8b5e  vmovaps [rsp+0x10], xmm2
00007b1fbf9d8b64  vmovaps [rsp+0x20], xmm3
00007b1fbf9d8b6a  vmovaps [rsp+0x30], xmm4
00007b1fbf9d8b70  vmovaps [rsp+0x40], xmm5
00007b1fbf9d8b76  vmovaps [rsp+0x50], xmm6
00007b1fbf9d8b7c  vmovaps [rsp+0x60], xmm7
00007b1fbf9d8b82  vmovaps [rsp+0x70], xmm8
00007b1fbf9d8b88  vmovaps [rsp+0x80], xmm9
00007b1fbf9d8b91  vmovaps [rsp+0x90], xmm10
00007b1fbf9d8b9a  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d8ba3  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d8bac  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d8bb5  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d8bbe  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d8bc7  sub rsp, 0x30
00007b1fbf9d8bcb  movaps [rsp], xmm1
00007b1fbf9d8bcf  movaps [rsp+0x10], xmm4
00007b1fbf9d8bd4  movaps [rsp+0x20], xmm9
00007b1fbf9d8bda  lea rdi, [rsp]
00007b1fbf9d8bde  mov esi, 0x00
00007b1fbf9d8be3  mov rax, 0x64AEE5F12530
00007b1fbf9d8bed  call rax
00007b1fbf9d8bef  movaps xmm1, [rsp]
00007b1fbf9d8bf3  add rsp, 0x30
00007b1fbf9d8bf7  vmovaps xmm0, [rsp]
00007b1fbf9d8bfc  vmovaps xmm2, [rsp+0x10]
00007b1fbf9d8c02  vmovaps xmm3, [rsp+0x20]
00007b1fbf9d8c08  vmovaps xmm4, [rsp+0x30]
00007b1fbf9d8c0e  vmovaps xmm5, [rsp+0x40]
00007b1fbf9d8c14  vmovaps xmm6, [rsp+0x50]
00007b1fbf9d8c1a  vmovaps xmm7, [rsp+0x60]
00007b1fbf9d8c20  vmovaps xmm8, [rsp+0x70]
00007b1fbf9d8c26  vmovaps xmm9, [rsp+0x80]
00007b1fbf9d8c2f  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d8c38  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d8c41  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d8c4a  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d8c53  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d8c5c  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d8c65  add rsp, 0xF0
00007b1fbf9d8c6c  pop r11
00007b1fbf9d8c6e  pop r10
00007b1fbf9d8c70  pop r9
00007b1fbf9d8c72  pop r8
00007b1fbf9d8c74  pop rsi
00007b1fbf9d8c75  pop rdi
00007b1fbf9d8c76  pop rdx
00007b1fbf9d8c77  pop rcx
00007b1fbf9d8c78  pop rax
00007b1fbf9d8c79  add rsp, 0x08
00007b1fbf9d8c7d  jmp 0x00007B1FBF9D613B
00007b1fbf9d8c82  sub rsp, 0x08
00007b1fbf9d8c86  push rax
00007b1fbf9d8c87  push rcx
00007b1fbf9d8c88  push rdx
00007b1fbf9d8c89  push rdi
00007b1fbf9d8c8a  push rsi
00007b1fbf9d8c8b  push r8
00007b1fbf9d8c8d  push r9
00007b1fbf9d8c8f  push r10
00007b1fbf9d8c91  push r11
00007b1fbf9d8c93  sub rsp, 0xF0
00007b1fbf9d8c9a  vmovaps [rsp], xmm0
00007b1fbf9d8c9f  vmovaps [rsp+0x10], xmm1
00007b1fbf9d8ca5  vmovaps [rsp+0x20], xmm2
00007b1fbf9d8cab  vmovaps [rsp+0x30], xmm3
00007b1fbf9d8cb1  vmovaps [rsp+0x40], xmm5
00007b1fbf9d8cb7  vmovaps [rsp+0x50], xmm6
00007b1fbf9d8cbd  vmovaps [rsp+0x60], xmm7
00007b1fbf9d8cc3  vmovaps [rsp+0x70], xmm8
00007b1fbf9d8cc9  vmovaps [rsp+0x80], xmm9
00007b1fbf9d8cd2  vmovaps [rsp+0x90], xmm10
00007b1fbf9d8cdb  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d8ce4  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d8ced  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d8cf6  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d8cff  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d8d08  sub rsp, 0x30
00007b1fbf9d8d0c  movaps [rsp], xmm4
00007b1fbf9d8d10  movaps [rsp+0x10], xmm2
00007b1fbf9d8d15  movaps [rsp+0x20], xmm9
00007b1fbf9d8d1b  lea rdi, [rsp]
00007b1fbf9d8d1f  mov esi, 0x00
00007b1fbf9d8d24  mov rax, 0x64AEE5F12530
00007b1fbf9d8d2e  call rax
00007b1fbf9d8d30  movaps xmm4, [rsp]
00007b1fbf9d8d34  add rsp, 0x30
00007b1fbf9d8d38  vmovaps xmm0, [rsp]
00007b1fbf9d8d3d  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d8d43  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d8d49  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d8d4f  vmovaps xmm5, [rsp+0x40]
00007b1fbf9d8d55  vmovaps xmm6, [rsp+0x50]
00007b1fbf9d8d5b  vmovaps xmm7, [rsp+0x60]
00007b1fbf9d8d61  vmovaps xmm8, [rsp+0x70]
00007b1fbf9d8d67  vmovaps xmm9, [rsp+0x80]
00007b1fbf9d8d70  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d8d79  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d8d82  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d8d8b  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d8d94  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d8d9d  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d8da6  add rsp, 0xF0
00007b1fbf9d8dad  pop r11
00007b1fbf9d8daf  pop r10
00007b1fbf9d8db1  pop r9
00007b1fbf9d8db3  pop r8
00007b1fbf9d8db5  pop rsi
00007b1fbf9d8db6  pop rdi
00007b1fbf9d8db7  pop rdx
00007b1fbf9d8db8  pop rcx
00007b1fbf9d8db9  pop rax
00007b1fbf9d8dba  add rsp, 0x08
00007b1fbf9d8dbe  jmp 0x00007B1FBF9D616B
00007b1fbf9d8dc3  sub rsp, 0x08
00007b1fbf9d8dc7  push rax
00007b1fbf9d8dc8  push rcx
00007b1fbf9d8dc9  push rdx
00007b1fbf9d8dca  push rdi
00007b1fbf9d8dcb  push rsi
00007b1fbf9d8dcc  push r8
00007b1fbf9d8dce  push r9
00007b1fbf9d8dd0  push r10
00007b1fbf9d8dd2  push r11
00007b1fbf9d8dd4  sub rsp, 0xF0
00007b1fbf9d8ddb  vmovaps [rsp], xmm0
00007b1fbf9d8de0  vmovaps [rsp+0x10], xmm1
00007b1fbf9d8de6  vmovaps [rsp+0x20], xmm2
00007b1fbf9d8dec  vmovaps [rsp+0x30], xmm3
00007b1fbf9d8df2  vmovaps [rsp+0x40], xmm4
00007b1fbf9d8df8  vmovaps [rsp+0x50], xmm5
00007b1fbf9d8dfe  vmovaps [rsp+0x60], xmm6
00007b1fbf9d8e04  vmovaps [rsp+0x70], xmm7
00007b1fbf9d8e0a  vmovaps [rsp+0x80], xmm8
00007b1fbf9d8e13  vmovaps [rsp+0x90], xmm10
00007b1fbf9d8e1c  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d8e25  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d8e2e  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d8e37  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d8e40  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d8e49  sub rsp, 0x30
00007b1fbf9d8e4d  movaps [rsp], xmm9
00007b1fbf9d8e52  movaps [rsp+0x10], xmm2
00007b1fbf9d8e57  movaps [rsp+0x20], xmm1
00007b1fbf9d8e5c  lea rdi, [rsp]
00007b1fbf9d8e60  mov esi, 0x00
00007b1fbf9d8e65  mov rax, 0x64AEE5F12530
00007b1fbf9d8e6f  call rax
00007b1fbf9d8e71  movaps xmm9, [rsp]
00007b1fbf9d8e76  add rsp, 0x30
00007b1fbf9d8e7a  vmovaps xmm0, [rsp]
00007b1fbf9d8e7f  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d8e85  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d8e8b  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d8e91  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d8e97  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d8e9d  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d8ea3  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d8ea9  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d8eb2  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d8ebb  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d8ec4  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d8ecd  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d8ed6  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d8edf  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d8ee8  add rsp, 0xF0
00007b1fbf9d8eef  pop r11
00007b1fbf9d8ef1  pop r10
00007b1fbf9d8ef3  pop r9
00007b1fbf9d8ef5  pop r8
00007b1fbf9d8ef7  pop rsi
00007b1fbf9d8ef8  pop rdi
00007b1fbf9d8ef9  pop rdx
00007b1fbf9d8efa  pop rcx
00007b1fbf9d8efb  pop rax
00007b1fbf9d8efc  add rsp, 0x08
00007b1fbf9d8f00  jmp 0x00007B1FBF9D61A1
00007b1fbf9d8f05  sub rsp, 0x08
00007b1fbf9d8f09  push rax
00007b1fbf9d8f0a  push rcx
00007b1fbf9d8f0b  push rdx
00007b1fbf9d8f0c  push rdi
00007b1fbf9d8f0d  push rsi
00007b1fbf9d8f0e  push r8
00007b1fbf9d8f10  push r9
00007b1fbf9d8f12  push r10
00007b1fbf9d8f14  push r11
00007b1fbf9d8f16  sub rsp, 0xF0
00007b1fbf9d8f1d  vmovaps [rsp], xmm0
00007b1fbf9d8f22  vmovaps [rsp+0x10], xmm2
00007b1fbf9d8f28  vmovaps [rsp+0x20], xmm3
00007b1fbf9d8f2e  vmovaps [rsp+0x30], xmm4
00007b1fbf9d8f34  vmovaps [rsp+0x40], xmm5
00007b1fbf9d8f3a  vmovaps [rsp+0x50], xmm6
00007b1fbf9d8f40  vmovaps [rsp+0x60], xmm7
00007b1fbf9d8f46  vmovaps [rsp+0x70], xmm8
00007b1fbf9d8f4c  vmovaps [rsp+0x80], xmm9
00007b1fbf9d8f55  vmovaps [rsp+0x90], xmm10
00007b1fbf9d8f5e  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d8f67  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d8f70  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d8f79  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d8f82  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d8f8b  sub rsp, 0x30
00007b1fbf9d8f8f  movaps [rsp], xmm1
00007b1fbf9d8f93  movaps [rsp+0x10], xmm15
00007b1fbf9d8f99  movaps [rsp+0x20], xmm6
00007b1fbf9d8f9e  lea rdi, [rsp]
00007b1fbf9d8fa2  mov esi, 0x00
00007b1fbf9d8fa7  mov rax, 0x64AEE5F12530
00007b1fbf9d8fb1  call rax
00007b1fbf9d8fb3  movaps xmm1, [rsp]
00007b1fbf9d8fb7  add rsp, 0x30
00007b1fbf9d8fbb  vmovaps xmm0, [rsp]
00007b1fbf9d8fc0  vmovaps xmm2, [rsp+0x10]
00007b1fbf9d8fc6  vmovaps xmm3, [rsp+0x20]
00007b1fbf9d8fcc  vmovaps xmm4, [rsp+0x30]
00007b1fbf9d8fd2  vmovaps xmm5, [rsp+0x40]
00007b1fbf9d8fd8  vmovaps xmm6, [rsp+0x50]
00007b1fbf9d8fde  vmovaps xmm7, [rsp+0x60]
00007b1fbf9d8fe4  vmovaps xmm8, [rsp+0x70]
00007b1fbf9d8fea  vmovaps xmm9, [rsp+0x80]
00007b1fbf9d8ff3  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d8ffc  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d9005  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d900e  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d9017  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d9020  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d9029  add rsp, 0xF0
00007b1fbf9d9030  pop r11
00007b1fbf9d9032  pop r10
00007b1fbf9d9034  pop r9
00007b1fbf9d9036  pop r8
00007b1fbf9d9038  pop rsi
00007b1fbf9d9039  pop rdi
00007b1fbf9d903a  pop rdx
00007b1fbf9d903b  pop rcx
00007b1fbf9d903c  pop rax
00007b1fbf9d903d  add rsp, 0x08
00007b1fbf9d9041  jmp 0x00007B1FBF9D61C2
00007b1fbf9d9046  sub rsp, 0x08
00007b1fbf9d904a  push rax
00007b1fbf9d904b  push rcx
00007b1fbf9d904c  push rdx
00007b1fbf9d904d  push rdi
00007b1fbf9d904e  push rsi
00007b1fbf9d904f  push r8
00007b1fbf9d9051  push r9
00007b1fbf9d9053  push r10
00007b1fbf9d9055  push r11
00007b1fbf9d9057  sub rsp, 0xF0
00007b1fbf9d905e  vmovaps [rsp], xmm0
00007b1fbf9d9063  vmovaps [rsp+0x10], xmm1
00007b1fbf9d9069  vmovaps [rsp+0x20], xmm2
00007b1fbf9d906f  vmovaps [rsp+0x30], xmm3
00007b1fbf9d9075  vmovaps [rsp+0x40], xmm4
00007b1fbf9d907b  vmovaps [rsp+0x50], xmm5
00007b1fbf9d9081  vmovaps [rsp+0x60], xmm6
00007b1fbf9d9087  vmovaps [rsp+0x70], xmm7
00007b1fbf9d908d  vmovaps [rsp+0x80], xmm8
00007b1fbf9d9096  vmovaps [rsp+0x90], xmm9
00007b1fbf9d909f  vmovaps [rsp+0xA0], xmm10
00007b1fbf9d90a8  vmovaps [rsp+0xB0], xmm11
00007b1fbf9d90b1  vmovaps [rsp+0xC0], xmm12
00007b1fbf9d90ba  vmovaps [rsp+0xD0], xmm13
00007b1fbf9d90c3  vmovaps [rsp+0xE0], xmm14
00007b1fbf9d90cc  sub rsp, 0x30
00007b1fbf9d90d0  movaps [rsp], xmm15
00007b1fbf9d90d5  movaps [rsp+0x10], xmm5
00007b1fbf9d90da  movaps [rsp+0x20], xmm3
00007b1fbf9d90df  lea rdi, [rsp]
00007b1fbf9d90e3  mov esi, 0x00
00007b1fbf9d90e8  mov rax, 0x64AEE5F12530
00007b1fbf9d90f2  call rax
00007b1fbf9d90f4  movaps xmm15, [rsp]
00007b1fbf9d90f9  add rsp, 0x30
00007b1fbf9d90fd  vmovaps xmm0, [rsp]
00007b1fbf9d9102  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d9108  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d910e  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d9114  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d911a  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d9120  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d9126  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d912c  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d9135  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d913e  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9d9147  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9d9150  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9d9159  vmovaps xmm13, [rsp+0xD0]
00007b1fbf9d9162  vmovaps xmm14, [rsp+0xE0]
00007b1fbf9d916b  add rsp, 0xF0
00007b1fbf9d9172  pop r11
00007b1fbf9d9174  pop r10
00007b1fbf9d9176  pop r9
00007b1fbf9d9178  pop r8
00007b1fbf9d917a  pop rsi
00007b1fbf9d917b  pop rdi
00007b1fbf9d917c  pop rdx
00007b1fbf9d917d  pop rcx
00007b1fbf9d917e  pop rax
00007b1fbf9d917f  add rsp, 0x08
00007b1fbf9d9183  jmp 0x00007B1FBF9D61DC
00007b1fbf9d9188  sub rsp, 0x08
00007b1fbf9d918c  push rax
00007b1fbf9d918d  push rcx
00007b1fbf9d918e  push rdx
00007b1fbf9d918f  push rdi
00007b1fbf9d9190  push rsi
00007b1fbf9d9191  push r8
00007b1fbf9d9193  push r9
00007b1fbf9d9195  push r10
00007b1fbf9d9197  push r11
00007b1fbf9d9199  sub rsp, 0xF0
00007b1fbf9d91a0  vmovaps [rsp], xmm0
00007b1fbf9d91a5  vmovaps [rsp+0x10], xmm1
00007b1fbf9d91ab  vmovaps [rsp+0x20], xmm2
00007b1fbf9d91b1  vmovaps [rsp+0x30], xmm3
00007b1fbf9d91b7  vmovaps [rsp+0x40], xmm4
00007b1fbf9d91bd  vmovaps [rsp+0x50], xmm6
00007b1fbf9d91c3  vmovaps [rsp+0x60], xmm7
00007b1fbf9d91c9  vmovaps [rsp+0x70], xmm8
00007b1fbf9d91cf  vmovaps [rsp+0x80], xmm9
00007b1fbf9d91d8  vmovaps [rsp+0x90], xmm10
00007b1fbf9d91e1  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d91ea  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d91f3  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d91fc  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d9205  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d920e  sub rsp, 0x30
00007b1fbf9d9212  movaps [rsp], xmm5
00007b1fbf9d9216  movaps [rsp+0x10], xmm8
00007b1fbf9d921c  movaps [rsp+0x20], xmm6
00007b1fbf9d9221  lea rdi, [rsp]
00007b1fbf9d9225  mov esi, 0x00
00007b1fbf9d922a  mov rax, 0x64AEE5F12530
00007b1fbf9d9234  call rax
00007b1fbf9d9236  movaps xmm5, [rsp]
00007b1fbf9d923a  add rsp, 0x30
00007b1fbf9d923e  vmovaps xmm0, [rsp]
00007b1fbf9d9243  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d9249  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d924f  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d9255  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d925b  vmovaps xmm6, [rsp+0x50]
00007b1fbf9d9261  vmovaps xmm7, [rsp+0x60]
00007b1fbf9d9267  vmovaps xmm8, [rsp+0x70]
00007b1fbf9d926d  vmovaps xmm9, [rsp+0x80]
00007b1fbf9d9276  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d927f  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d9288  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d9291  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d929a  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d92a3  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d92ac  add rsp, 0xF0
00007b1fbf9d92b3  pop r11
00007b1fbf9d92b5  pop r10
00007b1fbf9d92b7  pop r9
00007b1fbf9d92b9  pop r8
00007b1fbf9d92bb  pop rsi
00007b1fbf9d92bc  pop rdi
00007b1fbf9d92bd  pop rdx
00007b1fbf9d92be  pop rcx
00007b1fbf9d92bf  pop rax
00007b1fbf9d92c0  add rsp, 0x08
00007b1fbf9d92c4  jmp 0x00007B1FBF9D6200
00007b1fbf9d92c9  sub rsp, 0x08
00007b1fbf9d92cd  push rax
00007b1fbf9d92ce  push rcx
00007b1fbf9d92cf  push rdx
00007b1fbf9d92d0  push rdi
00007b1fbf9d92d1  push rsi
00007b1fbf9d92d2  push r8
00007b1fbf9d92d4  push r9
00007b1fbf9d92d6  push r10
00007b1fbf9d92d8  push r11
00007b1fbf9d92da  sub rsp, 0xF0
00007b1fbf9d92e1  vmovaps [rsp], xmm0
00007b1fbf9d92e6  vmovaps [rsp+0x10], xmm1
00007b1fbf9d92ec  vmovaps [rsp+0x20], xmm2
00007b1fbf9d92f2  vmovaps [rsp+0x30], xmm3
00007b1fbf9d92f8  vmovaps [rsp+0x40], xmm4
00007b1fbf9d92fe  vmovaps [rsp+0x50], xmm5
00007b1fbf9d9304  vmovaps [rsp+0x60], xmm7
00007b1fbf9d930a  vmovaps [rsp+0x70], xmm8
00007b1fbf9d9310  vmovaps [rsp+0x80], xmm9
00007b1fbf9d9319  vmovaps [rsp+0x90], xmm10
00007b1fbf9d9322  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d932b  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d9334  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d933d  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d9346  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d934f  sub rsp, 0x30
00007b1fbf9d9353  movaps [rsp], xmm6
00007b1fbf9d9357  movaps [rsp+0x10], xmm10
00007b1fbf9d935d  movaps [rsp+0x20], xmm8
00007b1fbf9d9363  lea rdi, [rsp]
00007b1fbf9d9367  mov esi, 0x00
00007b1fbf9d936c  mov rax, 0x64AEE5F12530
00007b1fbf9d9376  call rax
00007b1fbf9d9378  movaps xmm6, [rsp]
00007b1fbf9d937c  add rsp, 0x30
00007b1fbf9d9380  vmovaps xmm0, [rsp]
00007b1fbf9d9385  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d938b  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d9391  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d9397  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d939d  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d93a3  vmovaps xmm7, [rsp+0x60]
00007b1fbf9d93a9  vmovaps xmm8, [rsp+0x70]
00007b1fbf9d93af  vmovaps xmm9, [rsp+0x80]
00007b1fbf9d93b8  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d93c1  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d93ca  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d93d3  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d93dc  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d93e5  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d93ee  add rsp, 0xF0
00007b1fbf9d93f5  pop r11
00007b1fbf9d93f7  pop r10
00007b1fbf9d93f9  pop r9
00007b1fbf9d93fb  pop r8
00007b1fbf9d93fd  pop rsi
00007b1fbf9d93fe  pop rdi
00007b1fbf9d93ff  pop rdx
00007b1fbf9d9400  pop rcx
00007b1fbf9d9401  pop rax
00007b1fbf9d9402  add rsp, 0x08
00007b1fbf9d9406  jmp 0x00007B1FBF9D6225
00007b1fbf9d940b  sub rsp, 0x08
00007b1fbf9d940f  push rax
00007b1fbf9d9410  push rcx
00007b1fbf9d9411  push rdx
00007b1fbf9d9412  push rdi
00007b1fbf9d9413  push rsi
00007b1fbf9d9414  push r8
00007b1fbf9d9416  push r9
00007b1fbf9d9418  push r10
00007b1fbf9d941a  push r11
00007b1fbf9d941c  sub rsp, 0xF0
00007b1fbf9d9423  vmovaps [rsp], xmm0
00007b1fbf9d9428  vmovaps [rsp+0x10], xmm1
00007b1fbf9d942e  vmovaps [rsp+0x20], xmm2
00007b1fbf9d9434  vmovaps [rsp+0x30], xmm3
00007b1fbf9d943a  vmovaps [rsp+0x40], xmm4
00007b1fbf9d9440  vmovaps [rsp+0x50], xmm5
00007b1fbf9d9446  vmovaps [rsp+0x60], xmm6
00007b1fbf9d944c  vmovaps [rsp+0x70], xmm7
00007b1fbf9d9452  vmovaps [rsp+0x80], xmm8
00007b1fbf9d945b  vmovaps [rsp+0x90], xmm9
00007b1fbf9d9464  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d946d  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d9476  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d947f  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d9488  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d9491  sub rsp, 0x30
00007b1fbf9d9495  movaps [rsp], xmm10
00007b1fbf9d949a  movaps [rsp+0x10], xmm8
00007b1fbf9d94a0  movaps [rsp+0x20], xmm14
00007b1fbf9d94a6  lea rdi, [rsp]
00007b1fbf9d94aa  mov esi, 0x00
00007b1fbf9d94af  mov rax, 0x64AEE5F12530
00007b1fbf9d94b9  call rax
00007b1fbf9d94bb  movaps xmm10, [rsp]
00007b1fbf9d94c0  add rsp, 0x30
00007b1fbf9d94c4  vmovaps xmm0, [rsp]
00007b1fbf9d94c9  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d94cf  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d94d5  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d94db  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d94e1  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d94e7  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d94ed  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d94f3  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d94fc  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d9505  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d950e  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d9517  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d9520  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d9529  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d9532  add rsp, 0xF0
00007b1fbf9d9539  pop r11
00007b1fbf9d953b  pop r10
00007b1fbf9d953d  pop r9
00007b1fbf9d953f  pop r8
00007b1fbf9d9541  pop rsi
00007b1fbf9d9542  pop rdi
00007b1fbf9d9543  pop rdx
00007b1fbf9d9544  pop rcx
00007b1fbf9d9545  pop rax
00007b1fbf9d9546  add rsp, 0x08
00007b1fbf9d954a  jmp 0x00007B1FBF9D6245
00007b1fbf9d954f  sub rsp, 0x08
00007b1fbf9d9553  push rax
00007b1fbf9d9554  push rcx
00007b1fbf9d9555  push rdx
00007b1fbf9d9556  push rdi
00007b1fbf9d9557  push rsi
00007b1fbf9d9558  push r8
00007b1fbf9d955a  push r9
00007b1fbf9d955c  push r10
00007b1fbf9d955e  push r11
00007b1fbf9d9560  sub rsp, 0xF0
00007b1fbf9d9567  vmovaps [rsp], xmm0
00007b1fbf9d956c  vmovaps [rsp+0x10], xmm1
00007b1fbf9d9572  vmovaps [rsp+0x20], xmm2
00007b1fbf9d9578  vmovaps [rsp+0x30], xmm3
00007b1fbf9d957e  vmovaps [rsp+0x40], xmm4
00007b1fbf9d9584  vmovaps [rsp+0x50], xmm5
00007b1fbf9d958a  vmovaps [rsp+0x60], xmm6
00007b1fbf9d9590  vmovaps [rsp+0x70], xmm7
00007b1fbf9d9596  vmovaps [rsp+0x80], xmm8
00007b1fbf9d959f  vmovaps [rsp+0x90], xmm9
00007b1fbf9d95a8  vmovaps [rsp+0xA0], xmm10
00007b1fbf9d95b1  vmovaps [rsp+0xB0], xmm11
00007b1fbf9d95ba  vmovaps [rsp+0xC0], xmm12
00007b1fbf9d95c3  vmovaps [rsp+0xD0], xmm13
00007b1fbf9d95cc  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d95d5  sub rsp, 0x30
00007b1fbf9d95d9  movaps [rsp], xmm14
00007b1fbf9d95de  movaps [rsp+0x10], xmm8
00007b1fbf9d95e4  movaps [rsp+0x20], xmm4
00007b1fbf9d95e9  lea rdi, [rsp]
00007b1fbf9d95ed  mov esi, 0x00
00007b1fbf9d95f2  mov rax, 0x64AEE5F12530
00007b1fbf9d95fc  call rax
00007b1fbf9d95fe  movaps xmm14, [rsp]
00007b1fbf9d9603  add rsp, 0x30
00007b1fbf9d9607  vmovaps xmm0, [rsp]
00007b1fbf9d960c  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d9612  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d9618  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d961e  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d9624  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d962a  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d9630  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d9636  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d963f  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d9648  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9d9651  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9d965a  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9d9663  vmovaps xmm13, [rsp+0xD0]
00007b1fbf9d966c  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d9675  add rsp, 0xF0
00007b1fbf9d967c  pop r11
00007b1fbf9d967e  pop r10
00007b1fbf9d9680  pop r9
00007b1fbf9d9682  pop r8
00007b1fbf9d9684  pop rsi
00007b1fbf9d9685  pop rdi
00007b1fbf9d9686  pop rdx
00007b1fbf9d9687  pop rcx
00007b1fbf9d9688  pop rax
00007b1fbf9d9689  add rsp, 0x08
00007b1fbf9d968d  jmp 0x00007B1FBF9D6265
00007b1fbf9d9692  sub rsp, 0x08
00007b1fbf9d9696  push rax
00007b1fbf9d9697  push rcx
00007b1fbf9d9698  push rdx
00007b1fbf9d9699  push rdi
00007b1fbf9d969a  push rsi
00007b1fbf9d969b  push r8
00007b1fbf9d969d  push r9
00007b1fbf9d969f  push r10
00007b1fbf9d96a1  push r11
00007b1fbf9d96a3  sub rsp, 0xF0
00007b1fbf9d96aa  vmovaps [rsp], xmm0
00007b1fbf9d96af  vmovaps [rsp+0x10], xmm1
00007b1fbf9d96b5  vmovaps [rsp+0x20], xmm2
00007b1fbf9d96bb  vmovaps [rsp+0x30], xmm3
00007b1fbf9d96c1  vmovaps [rsp+0x40], xmm5
00007b1fbf9d96c7  vmovaps [rsp+0x50], xmm6
00007b1fbf9d96cd  vmovaps [rsp+0x60], xmm7
00007b1fbf9d96d3  vmovaps [rsp+0x70], xmm8
00007b1fbf9d96d9  vmovaps [rsp+0x80], xmm9
00007b1fbf9d96e2  vmovaps [rsp+0x90], xmm10
00007b1fbf9d96eb  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d96f4  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d96fd  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d9706  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d970f  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d9718  sub rsp, 0x30
00007b1fbf9d971c  movaps [rsp], xmm4
00007b1fbf9d9720  movaps [rsp+0x10], xmm13
00007b1fbf9d9726  movaps [rsp+0x20], xmm8
00007b1fbf9d972c  lea rdi, [rsp]
00007b1fbf9d9730  mov esi, 0x00
00007b1fbf9d9735  mov rax, 0x64AEE5F12530
00007b1fbf9d973f  call rax
00007b1fbf9d9741  movaps xmm4, [rsp]
00007b1fbf9d9745  add rsp, 0x30
00007b1fbf9d9749  vmovaps xmm0, [rsp]
00007b1fbf9d974e  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d9754  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d975a  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d9760  vmovaps xmm5, [rsp+0x40]
00007b1fbf9d9766  vmovaps xmm6, [rsp+0x50]
00007b1fbf9d976c  vmovaps xmm7, [rsp+0x60]
00007b1fbf9d9772  vmovaps xmm8, [rsp+0x70]
00007b1fbf9d9778  vmovaps xmm9, [rsp+0x80]
00007b1fbf9d9781  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d978a  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d9793  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d979c  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d97a5  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d97ae  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d97b7  add rsp, 0xF0
00007b1fbf9d97be  pop r11
00007b1fbf9d97c0  pop r10
00007b1fbf9d97c2  pop r9
00007b1fbf9d97c4  pop r8
00007b1fbf9d97c6  pop rsi
00007b1fbf9d97c7  pop rdi
00007b1fbf9d97c8  pop rdx
00007b1fbf9d97c9  pop rcx
00007b1fbf9d97ca  pop rax
00007b1fbf9d97cb  add rsp, 0x08
00007b1fbf9d97cf  jmp 0x00007B1FBF9D628A
00007b1fbf9d97d4  sub rsp, 0x08
00007b1fbf9d97d8  push rax
00007b1fbf9d97d9  push rcx
00007b1fbf9d97da  push rdx
00007b1fbf9d97db  push rdi
00007b1fbf9d97dc  push rsi
00007b1fbf9d97dd  push r8
00007b1fbf9d97df  push r9
00007b1fbf9d97e1  push r10
00007b1fbf9d97e3  push r11
00007b1fbf9d97e5  sub rsp, 0xF0
00007b1fbf9d97ec  vmovaps [rsp], xmm0
00007b1fbf9d97f1  vmovaps [rsp+0x10], xmm1
00007b1fbf9d97f7  vmovaps [rsp+0x20], xmm2
00007b1fbf9d97fd  vmovaps [rsp+0x30], xmm3
00007b1fbf9d9803  vmovaps [rsp+0x40], xmm4
00007b1fbf9d9809  vmovaps [rsp+0x50], xmm5
00007b1fbf9d980f  vmovaps [rsp+0x60], xmm6
00007b1fbf9d9815  vmovaps [rsp+0x70], xmm7
00007b1fbf9d981b  vmovaps [rsp+0x80], xmm8
00007b1fbf9d9824  vmovaps [rsp+0x90], xmm9
00007b1fbf9d982d  vmovaps [rsp+0xA0], xmm10
00007b1fbf9d9836  vmovaps [rsp+0xB0], xmm11
00007b1fbf9d983f  vmovaps [rsp+0xC0], xmm12
00007b1fbf9d9848  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d9851  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d985a  sub rsp, 0x30
00007b1fbf9d985e  movaps [rsp], xmm13
00007b1fbf9d9863  movaps [rsp+0x10], xmm15
00007b1fbf9d9869  movaps [rsp+0x20], xmm9
00007b1fbf9d986f  lea rdi, [rsp]
00007b1fbf9d9873  mov esi, 0x00
00007b1fbf9d9878  mov rax, 0x64AEE5F12530
00007b1fbf9d9882  call rax
00007b1fbf9d9884  movaps xmm13, [rsp]
00007b1fbf9d9889  add rsp, 0x30
00007b1fbf9d988d  vmovaps xmm0, [rsp]
00007b1fbf9d9892  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d9898  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d989e  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d98a4  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d98aa  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d98b0  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d98b6  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d98bc  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d98c5  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d98ce  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9d98d7  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9d98e0  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9d98e9  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d98f2  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d98fb  add rsp, 0xF0
00007b1fbf9d9902  pop r11
00007b1fbf9d9904  pop r10
00007b1fbf9d9906  pop r9
00007b1fbf9d9908  pop r8
00007b1fbf9d990a  pop rsi
00007b1fbf9d990b  pop rdi
00007b1fbf9d990c  pop rdx
00007b1fbf9d990d  pop rcx
00007b1fbf9d990e  pop rax
00007b1fbf9d990f  add rsp, 0x08
00007b1fbf9d9913  jmp 0x00007B1FBF9D62A5
00007b1fbf9d9918  sub rsp, 0x08
00007b1fbf9d991c  push rax
00007b1fbf9d991d  push rcx
00007b1fbf9d991e  push rdx
00007b1fbf9d991f  push rdi
00007b1fbf9d9920  push rsi
00007b1fbf9d9921  push r8
00007b1fbf9d9923  push r9
00007b1fbf9d9925  push r10
00007b1fbf9d9927  push r11
00007b1fbf9d9929  sub rsp, 0xF0
00007b1fbf9d9930  vmovaps [rsp], xmm0
00007b1fbf9d9935  vmovaps [rsp+0x10], xmm1
00007b1fbf9d993b  vmovaps [rsp+0x20], xmm2
00007b1fbf9d9941  vmovaps [rsp+0x30], xmm3
00007b1fbf9d9947  vmovaps [rsp+0x40], xmm4
00007b1fbf9d994d  vmovaps [rsp+0x50], xmm5
00007b1fbf9d9953  vmovaps [rsp+0x60], xmm6
00007b1fbf9d9959  vmovaps [rsp+0x70], xmm7
00007b1fbf9d995f  vmovaps [rsp+0x80], xmm8
00007b1fbf9d9968  vmovaps [rsp+0x90], xmm9
00007b1fbf9d9971  vmovaps [rsp+0xA0], xmm10
00007b1fbf9d997a  vmovaps [rsp+0xB0], xmm11
00007b1fbf9d9983  vmovaps [rsp+0xC0], xmm12
00007b1fbf9d998c  vmovaps [rsp+0xD0], xmm13
00007b1fbf9d9995  vmovaps [rsp+0xE0], xmm14
00007b1fbf9d999e  sub rsp, 0x30
00007b1fbf9d99a2  movaps [rsp], xmm15
00007b1fbf9d99a7  movaps [rsp+0x10], xmm1
00007b1fbf9d99ac  movaps [rsp+0x20], xmm5
00007b1fbf9d99b1  lea rdi, [rsp]
00007b1fbf9d99b5  mov esi, 0x00
00007b1fbf9d99ba  mov rax, 0x64AEE5F12530
00007b1fbf9d99c4  call rax
00007b1fbf9d99c6  movaps xmm15, [rsp]
00007b1fbf9d99cb  add rsp, 0x30
00007b1fbf9d99cf  vmovaps xmm0, [rsp]
00007b1fbf9d99d4  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d99da  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d99e0  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d99e6  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d99ec  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d99f2  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d99f8  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d99fe  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d9a07  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d9a10  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9d9a19  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9d9a22  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9d9a2b  vmovaps xmm13, [rsp+0xD0]
00007b1fbf9d9a34  vmovaps xmm14, [rsp+0xE0]
00007b1fbf9d9a3d  add rsp, 0xF0
00007b1fbf9d9a44  pop r11
00007b1fbf9d9a46  pop r10
00007b1fbf9d9a48  pop r9
00007b1fbf9d9a4a  pop r8
00007b1fbf9d9a4c  pop rsi
00007b1fbf9d9a4d  pop rdi
00007b1fbf9d9a4e  pop rdx
00007b1fbf9d9a4f  pop rcx
00007b1fbf9d9a50  pop rax
00007b1fbf9d9a51  add rsp, 0x08
00007b1fbf9d9a55  jmp 0x00007B1FBF9D62C0
00007b1fbf9d9a5a  call 0x00007B1FBF8D64F0
00007b1fbf9d9a5f  jmp 0x00007B1FBF9D631B
00007b1fbf9d9a64  sub rsp, 0x08
00007b1fbf9d9a68  push rax
00007b1fbf9d9a69  push rcx
00007b1fbf9d9a6a  push rdx
00007b1fbf9d9a6b  push rdi
00007b1fbf9d9a6c  push rsi
00007b1fbf9d9a6d  push r8
00007b1fbf9d9a6f  push r9
00007b1fbf9d9a71  push r10
00007b1fbf9d9a73  push r11
00007b1fbf9d9a75  sub rsp, 0xF0
00007b1fbf9d9a7c  vmovaps [rsp], xmm0
00007b1fbf9d9a81  vmovaps [rsp+0x10], xmm1
00007b1fbf9d9a87  vmovaps [rsp+0x20], xmm2
00007b1fbf9d9a8d  vmovaps [rsp+0x30], xmm3
00007b1fbf9d9a93  vmovaps [rsp+0x40], xmm4
00007b1fbf9d9a99  vmovaps [rsp+0x50], xmm5
00007b1fbf9d9a9f  vmovaps [rsp+0x60], xmm6
00007b1fbf9d9aa5  vmovaps [rsp+0x70], xmm7
00007b1fbf9d9aab  vmovaps [rsp+0x80], xmm8
00007b1fbf9d9ab4  vmovaps [rsp+0x90], xmm10
00007b1fbf9d9abd  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d9ac6  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d9acf  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d9ad8  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d9ae1  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d9aea  sub rsp, 0x30
00007b1fbf9d9aee  movaps [rsp], xmm9
00007b1fbf9d9af3  movaps [rsp+0x10], xmm8
00007b1fbf9d9af9  movaps [rsp+0x20], xmm11
00007b1fbf9d9aff  lea rdi, [rsp]
00007b1fbf9d9b03  mov esi, 0x00
00007b1fbf9d9b08  mov rax, 0x64AEE5F12530
00007b1fbf9d9b12  call rax
00007b1fbf9d9b14  movaps xmm9, [rsp]
00007b1fbf9d9b19  add rsp, 0x30
00007b1fbf9d9b1d  vmovaps xmm0, [rsp]
00007b1fbf9d9b22  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d9b28  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d9b2e  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d9b34  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d9b3a  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d9b40  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d9b46  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d9b4c  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d9b55  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d9b5e  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d9b67  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d9b70  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d9b79  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d9b82  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d9b8b  add rsp, 0xF0
00007b1fbf9d9b92  pop r11
00007b1fbf9d9b94  pop r10
00007b1fbf9d9b96  pop r9
00007b1fbf9d9b98  pop r8
00007b1fbf9d9b9a  pop rsi
00007b1fbf9d9b9b  pop rdi
00007b1fbf9d9b9c  pop rdx
00007b1fbf9d9b9d  pop rcx
00007b1fbf9d9b9e  pop rax
00007b1fbf9d9b9f  add rsp, 0x08
00007b1fbf9d9ba3  jmp 0x00007B1FBF9D6352
00007b1fbf9d9ba8  sub rsp, 0x08
00007b1fbf9d9bac  push rax
00007b1fbf9d9bad  push rcx
00007b1fbf9d9bae  push rdx
00007b1fbf9d9baf  push rdi
00007b1fbf9d9bb0  push rsi
00007b1fbf9d9bb1  push r8
00007b1fbf9d9bb3  push r9
00007b1fbf9d9bb5  push r10
00007b1fbf9d9bb7  push r11
00007b1fbf9d9bb9  sub rsp, 0xF0
00007b1fbf9d9bc0  vmovaps [rsp], xmm0
00007b1fbf9d9bc5  vmovaps [rsp+0x10], xmm1
00007b1fbf9d9bcb  vmovaps [rsp+0x20], xmm2
00007b1fbf9d9bd1  vmovaps [rsp+0x30], xmm3
00007b1fbf9d9bd7  vmovaps [rsp+0x40], xmm4
00007b1fbf9d9bdd  vmovaps [rsp+0x50], xmm5
00007b1fbf9d9be3  vmovaps [rsp+0x60], xmm6
00007b1fbf9d9be9  vmovaps [rsp+0x70], xmm7
00007b1fbf9d9bef  vmovaps [rsp+0x80], xmm8
00007b1fbf9d9bf8  vmovaps [rsp+0x90], xmm9
00007b1fbf9d9c01  vmovaps [rsp+0xA0], xmm10
00007b1fbf9d9c0a  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d9c13  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d9c1c  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d9c25  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d9c2e  sub rsp, 0x30
00007b1fbf9d9c32  movaps [rsp], xmm11
00007b1fbf9d9c37  movaps [rsp+0x10], xmm10
00007b1fbf9d9c3d  movaps [rsp+0x20], xmm6
00007b1fbf9d9c42  lea rdi, [rsp]
00007b1fbf9d9c46  mov esi, 0x00
00007b1fbf9d9c4b  mov rax, 0x64AEE5F12530
00007b1fbf9d9c55  call rax
00007b1fbf9d9c57  movaps xmm11, [rsp]
00007b1fbf9d9c5c  add rsp, 0x30
00007b1fbf9d9c60  vmovaps xmm0, [rsp]
00007b1fbf9d9c65  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d9c6b  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d9c71  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d9c77  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d9c7d  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d9c83  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d9c89  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d9c8f  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d9c98  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d9ca1  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9d9caa  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d9cb3  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d9cbc  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d9cc5  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d9cce  add rsp, 0xF0
00007b1fbf9d9cd5  pop r11
00007b1fbf9d9cd7  pop r10
00007b1fbf9d9cd9  pop r9
00007b1fbf9d9cdb  pop r8
00007b1fbf9d9cdd  pop rsi
00007b1fbf9d9cde  pop rdi
00007b1fbf9d9cdf  pop rdx
00007b1fbf9d9ce0  pop rcx
00007b1fbf9d9ce1  pop rax
00007b1fbf9d9ce2  add rsp, 0x08
00007b1fbf9d9ce6  jmp 0x00007B1FBF9D636D
00007b1fbf9d9ceb  sub rsp, 0x08
00007b1fbf9d9cef  push rax
00007b1fbf9d9cf0  push rcx
00007b1fbf9d9cf1  push rdx
00007b1fbf9d9cf2  push rdi
00007b1fbf9d9cf3  push rsi
00007b1fbf9d9cf4  push r8
00007b1fbf9d9cf6  push r9
00007b1fbf9d9cf8  push r10
00007b1fbf9d9cfa  push r11
00007b1fbf9d9cfc  sub rsp, 0xF0
00007b1fbf9d9d03  vmovaps [rsp], xmm0
00007b1fbf9d9d08  vmovaps [rsp+0x10], xmm1
00007b1fbf9d9d0e  vmovaps [rsp+0x20], xmm2
00007b1fbf9d9d14  vmovaps [rsp+0x30], xmm3
00007b1fbf9d9d1a  vmovaps [rsp+0x40], xmm4
00007b1fbf9d9d20  vmovaps [rsp+0x50], xmm5
00007b1fbf9d9d26  vmovaps [rsp+0x60], xmm6
00007b1fbf9d9d2c  vmovaps [rsp+0x70], xmm7
00007b1fbf9d9d32  vmovaps [rsp+0x80], xmm8
00007b1fbf9d9d3b  vmovaps [rsp+0x90], xmm9
00007b1fbf9d9d44  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d9d4d  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d9d56  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d9d5f  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d9d68  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d9d71  sub rsp, 0x30
00007b1fbf9d9d75  movaps [rsp], xmm10
00007b1fbf9d9d7a  movaps [rsp+0x10], xmm14
00007b1fbf9d9d80  movaps [rsp+0x20], xmm4
00007b1fbf9d9d85  lea rdi, [rsp]
00007b1fbf9d9d89  mov esi, 0x00
00007b1fbf9d9d8e  mov rax, 0x64AEE5F12530
00007b1fbf9d9d98  call rax
00007b1fbf9d9d9a  movaps xmm10, [rsp]
00007b1fbf9d9d9f  add rsp, 0x30
00007b1fbf9d9da3  vmovaps xmm0, [rsp]
00007b1fbf9d9da8  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d9dae  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d9db4  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d9dba  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d9dc0  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d9dc6  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d9dcc  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d9dd2  vmovaps xmm8, [rsp+0x80]
00007b1fbf9d9ddb  vmovaps xmm9, [rsp+0x90]
00007b1fbf9d9de4  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d9ded  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d9df6  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d9dff  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d9e08  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d9e11  add rsp, 0xF0
00007b1fbf9d9e18  pop r11
00007b1fbf9d9e1a  pop r10
00007b1fbf9d9e1c  pop r9
00007b1fbf9d9e1e  pop r8
00007b1fbf9d9e20  pop rsi
00007b1fbf9d9e21  pop rdi
00007b1fbf9d9e22  pop rdx
00007b1fbf9d9e23  pop rcx
00007b1fbf9d9e24  pop rax
00007b1fbf9d9e25  add rsp, 0x08
00007b1fbf9d9e29  jmp 0x00007B1FBF9D6388
00007b1fbf9d9e2e  sub rsp, 0x08
00007b1fbf9d9e32  push rax
00007b1fbf9d9e33  push rcx
00007b1fbf9d9e34  push rdx
00007b1fbf9d9e35  push rdi
00007b1fbf9d9e36  push rsi
00007b1fbf9d9e37  push r8
00007b1fbf9d9e39  push r9
00007b1fbf9d9e3b  push r10
00007b1fbf9d9e3d  push r11
00007b1fbf9d9e3f  sub rsp, 0xF0
00007b1fbf9d9e46  vmovaps [rsp], xmm0
00007b1fbf9d9e4b  vmovaps [rsp+0x10], xmm1
00007b1fbf9d9e51  vmovaps [rsp+0x20], xmm2
00007b1fbf9d9e57  vmovaps [rsp+0x30], xmm3
00007b1fbf9d9e5d  vmovaps [rsp+0x40], xmm4
00007b1fbf9d9e63  vmovaps [rsp+0x50], xmm5
00007b1fbf9d9e69  vmovaps [rsp+0x60], xmm6
00007b1fbf9d9e6f  vmovaps [rsp+0x70], xmm7
00007b1fbf9d9e75  vmovaps [rsp+0x80], xmm9
00007b1fbf9d9e7e  vmovaps [rsp+0x90], xmm10
00007b1fbf9d9e87  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d9e90  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d9e99  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d9ea2  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d9eab  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d9eb4  sub rsp, 0x30
00007b1fbf9d9eb8  movaps [rsp], xmm8
00007b1fbf9d9ebd  movaps [rsp+0x10], xmm1
00007b1fbf9d9ec2  movaps [rsp+0x20], xmm14
00007b1fbf9d9ec8  lea rdi, [rsp]
00007b1fbf9d9ecc  mov esi, 0x00
00007b1fbf9d9ed1  mov rax, 0x64AEE5F12530
00007b1fbf9d9edb  call rax
00007b1fbf9d9edd  movaps xmm8, [rsp]
00007b1fbf9d9ee2  add rsp, 0x30
00007b1fbf9d9ee6  vmovaps xmm0, [rsp]
00007b1fbf9d9eeb  vmovaps xmm1, [rsp+0x10]
00007b1fbf9d9ef1  vmovaps xmm2, [rsp+0x20]
00007b1fbf9d9ef7  vmovaps xmm3, [rsp+0x30]
00007b1fbf9d9efd  vmovaps xmm4, [rsp+0x40]
00007b1fbf9d9f03  vmovaps xmm5, [rsp+0x50]
00007b1fbf9d9f09  vmovaps xmm6, [rsp+0x60]
00007b1fbf9d9f0f  vmovaps xmm7, [rsp+0x70]
00007b1fbf9d9f15  vmovaps xmm9, [rsp+0x80]
00007b1fbf9d9f1e  vmovaps xmm10, [rsp+0x90]
00007b1fbf9d9f27  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9d9f30  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9d9f39  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9d9f42  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9d9f4b  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9d9f54  add rsp, 0xF0
00007b1fbf9d9f5b  pop r11
00007b1fbf9d9f5d  pop r10
00007b1fbf9d9f5f  pop r9
00007b1fbf9d9f61  pop r8
00007b1fbf9d9f63  pop rsi
00007b1fbf9d9f64  pop rdi
00007b1fbf9d9f65  pop rdx
00007b1fbf9d9f66  pop rcx
00007b1fbf9d9f67  pop rax
00007b1fbf9d9f68  add rsp, 0x08
00007b1fbf9d9f6c  jmp 0x00007B1FBF9D63AE
00007b1fbf9d9f71  sub rsp, 0x08
00007b1fbf9d9f75  push rax
00007b1fbf9d9f76  push rcx
00007b1fbf9d9f77  push rdx
00007b1fbf9d9f78  push rdi
00007b1fbf9d9f79  push rsi
00007b1fbf9d9f7a  push r8
00007b1fbf9d9f7c  push r9
00007b1fbf9d9f7e  push r10
00007b1fbf9d9f80  push r11
00007b1fbf9d9f82  sub rsp, 0xF0
00007b1fbf9d9f89  vmovaps [rsp], xmm0
00007b1fbf9d9f8e  vmovaps [rsp+0x10], xmm1
00007b1fbf9d9f94  vmovaps [rsp+0x20], xmm2
00007b1fbf9d9f9a  vmovaps [rsp+0x30], xmm3
00007b1fbf9d9fa0  vmovaps [rsp+0x40], xmm4
00007b1fbf9d9fa6  vmovaps [rsp+0x50], xmm5
00007b1fbf9d9fac  vmovaps [rsp+0x60], xmm7
00007b1fbf9d9fb2  vmovaps [rsp+0x70], xmm8
00007b1fbf9d9fb8  vmovaps [rsp+0x80], xmm9
00007b1fbf9d9fc1  vmovaps [rsp+0x90], xmm10
00007b1fbf9d9fca  vmovaps [rsp+0xA0], xmm11
00007b1fbf9d9fd3  vmovaps [rsp+0xB0], xmm12
00007b1fbf9d9fdc  vmovaps [rsp+0xC0], xmm13
00007b1fbf9d9fe5  vmovaps [rsp+0xD0], xmm14
00007b1fbf9d9fee  vmovaps [rsp+0xE0], xmm15
00007b1fbf9d9ff7  sub rsp, 0x30
00007b1fbf9d9ffb  movaps [rsp], xmm6
00007b1fbf9d9fff  movaps [rsp+0x10], xmm1
00007b1fbf9da004  movaps [rsp+0x20], xmm14
00007b1fbf9da00a  lea rdi, [rsp]
00007b1fbf9da00e  mov esi, 0x00
00007b1fbf9da013  mov rax, 0x64AEE5F12530
00007b1fbf9da01d  call rax
00007b1fbf9da01f  movaps xmm6, [rsp]
00007b1fbf9da023  add rsp, 0x30
00007b1fbf9da027  vmovaps xmm0, [rsp]
00007b1fbf9da02c  vmovaps xmm1, [rsp+0x10]
00007b1fbf9da032  vmovaps xmm2, [rsp+0x20]
00007b1fbf9da038  vmovaps xmm3, [rsp+0x30]
00007b1fbf9da03e  vmovaps xmm4, [rsp+0x40]
00007b1fbf9da044  vmovaps xmm5, [rsp+0x50]
00007b1fbf9da04a  vmovaps xmm7, [rsp+0x60]
00007b1fbf9da050  vmovaps xmm8, [rsp+0x70]
00007b1fbf9da056  vmovaps xmm9, [rsp+0x80]
00007b1fbf9da05f  vmovaps xmm10, [rsp+0x90]
00007b1fbf9da068  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9da071  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9da07a  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9da083  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9da08c  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9da095  add rsp, 0xF0
00007b1fbf9da09c  pop r11
00007b1fbf9da09e  pop r10
00007b1fbf9da0a0  pop r9
00007b1fbf9da0a2  pop r8
00007b1fbf9da0a4  pop rsi
00007b1fbf9da0a5  pop rdi
00007b1fbf9da0a6  pop rdx
00007b1fbf9da0a7  pop rcx
00007b1fbf9da0a8  pop rax
00007b1fbf9da0a9  add rsp, 0x08
00007b1fbf9da0ad  jmp 0x00007B1FBF9D63DA
00007b1fbf9da0b2  sub rsp, 0x08
00007b1fbf9da0b6  push rax
00007b1fbf9da0b7  push rcx
00007b1fbf9da0b8  push rdx
00007b1fbf9da0b9  push rdi
00007b1fbf9da0ba  push rsi
00007b1fbf9da0bb  push r8
00007b1fbf9da0bd  push r9
00007b1fbf9da0bf  push r10
00007b1fbf9da0c1  push r11
00007b1fbf9da0c3  sub rsp, 0xF0
00007b1fbf9da0ca  vmovaps [rsp], xmm0
00007b1fbf9da0cf  vmovaps [rsp+0x10], xmm1
00007b1fbf9da0d5  vmovaps [rsp+0x20], xmm2
00007b1fbf9da0db  vmovaps [rsp+0x30], xmm3
00007b1fbf9da0e1  vmovaps [rsp+0x40], xmm4
00007b1fbf9da0e7  vmovaps [rsp+0x50], xmm5
00007b1fbf9da0ed  vmovaps [rsp+0x60], xmm6
00007b1fbf9da0f3  vmovaps [rsp+0x70], xmm7
00007b1fbf9da0f9  vmovaps [rsp+0x80], xmm8
00007b1fbf9da102  vmovaps [rsp+0x90], xmm9
00007b1fbf9da10b  vmovaps [rsp+0xA0], xmm10
00007b1fbf9da114  vmovaps [rsp+0xB0], xmm11
00007b1fbf9da11d  vmovaps [rsp+0xC0], xmm12
00007b1fbf9da126  vmovaps [rsp+0xD0], xmm13
00007b1fbf9da12f  vmovaps [rsp+0xE0], xmm15
00007b1fbf9da138  sub rsp, 0x30
00007b1fbf9da13c  movaps [rsp], xmm14
00007b1fbf9da141  movaps [rsp+0x10], xmm12
00007b1fbf9da147  movaps [rsp+0x20], xmm1
00007b1fbf9da14c  lea rdi, [rsp]
00007b1fbf9da150  mov esi, 0x00
00007b1fbf9da155  mov rax, 0x64AEE5F12530
00007b1fbf9da15f  call rax
00007b1fbf9da161  movaps xmm14, [rsp]
00007b1fbf9da166  add rsp, 0x30
00007b1fbf9da16a  vmovaps xmm0, [rsp]
00007b1fbf9da16f  vmovaps xmm1, [rsp+0x10]
00007b1fbf9da175  vmovaps xmm2, [rsp+0x20]
00007b1fbf9da17b  vmovaps xmm3, [rsp+0x30]
00007b1fbf9da181  vmovaps xmm4, [rsp+0x40]
00007b1fbf9da187  vmovaps xmm5, [rsp+0x50]
00007b1fbf9da18d  vmovaps xmm6, [rsp+0x60]
00007b1fbf9da193  vmovaps xmm7, [rsp+0x70]
00007b1fbf9da199  vmovaps xmm8, [rsp+0x80]
00007b1fbf9da1a2  vmovaps xmm9, [rsp+0x90]
00007b1fbf9da1ab  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9da1b4  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9da1bd  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9da1c6  vmovaps xmm13, [rsp+0xD0]
00007b1fbf9da1cf  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9da1d8  add rsp, 0xF0
00007b1fbf9da1df  pop r11
00007b1fbf9da1e1  pop r10
00007b1fbf9da1e3  pop r9
00007b1fbf9da1e5  pop r8
00007b1fbf9da1e7  pop rsi
00007b1fbf9da1e8  pop rdi
00007b1fbf9da1e9  pop rdx
00007b1fbf9da1ea  pop rcx
00007b1fbf9da1eb  pop rax
00007b1fbf9da1ec  add rsp, 0x08
00007b1fbf9da1f0  jmp 0x00007B1FBF9D6400
00007b1fbf9da1f5  sub rsp, 0x08
00007b1fbf9da1f9  push rax
00007b1fbf9da1fa  push rcx
00007b1fbf9da1fb  push rdx
00007b1fbf9da1fc  push rdi
00007b1fbf9da1fd  push rsi
00007b1fbf9da1fe  push r8
00007b1fbf9da200  push r9
00007b1fbf9da202  push r10
00007b1fbf9da204  push r11
00007b1fbf9da206  sub rsp, 0xF0
00007b1fbf9da20d  vmovaps [rsp], xmm0
00007b1fbf9da212  vmovaps [rsp+0x10], xmm2
00007b1fbf9da218  vmovaps [rsp+0x20], xmm3
00007b1fbf9da21e  vmovaps [rsp+0x30], xmm4
00007b1fbf9da224  vmovaps [rsp+0x40], xmm5
00007b1fbf9da22a  vmovaps [rsp+0x50], xmm6
00007b1fbf9da230  vmovaps [rsp+0x60], xmm7
00007b1fbf9da236  vmovaps [rsp+0x70], xmm8
00007b1fbf9da23c  vmovaps [rsp+0x80], xmm9
00007b1fbf9da245  vmovaps [rsp+0x90], xmm10
00007b1fbf9da24e  vmovaps [rsp+0xA0], xmm11
00007b1fbf9da257  vmovaps [rsp+0xB0], xmm12
00007b1fbf9da260  vmovaps [rsp+0xC0], xmm13
00007b1fbf9da269  vmovaps [rsp+0xD0], xmm14
00007b1fbf9da272  vmovaps [rsp+0xE0], xmm15
00007b1fbf9da27b  sub rsp, 0x30
00007b1fbf9da27f  movaps [rsp], xmm1
00007b1fbf9da283  movaps [rsp+0x10], xmm13
00007b1fbf9da289  movaps [rsp+0x20], xmm9
00007b1fbf9da28f  lea rdi, [rsp]
00007b1fbf9da293  mov esi, 0x00
00007b1fbf9da298  mov rax, 0x64AEE5F12530
00007b1fbf9da2a2  call rax
00007b1fbf9da2a4  movaps xmm1, [rsp]
00007b1fbf9da2a8  add rsp, 0x30
00007b1fbf9da2ac  vmovaps xmm0, [rsp]
00007b1fbf9da2b1  vmovaps xmm2, [rsp+0x10]
00007b1fbf9da2b7  vmovaps xmm3, [rsp+0x20]
00007b1fbf9da2bd  vmovaps xmm4, [rsp+0x30]
00007b1fbf9da2c3  vmovaps xmm5, [rsp+0x40]
00007b1fbf9da2c9  vmovaps xmm6, [rsp+0x50]
00007b1fbf9da2cf  vmovaps xmm7, [rsp+0x60]
00007b1fbf9da2d5  vmovaps xmm8, [rsp+0x70]
00007b1fbf9da2db  vmovaps xmm9, [rsp+0x80]
00007b1fbf9da2e4  vmovaps xmm10, [rsp+0x90]
00007b1fbf9da2ed  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9da2f6  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9da2ff  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9da308  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9da311  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9da31a  add rsp, 0xF0
00007b1fbf9da321  pop r11
00007b1fbf9da323  pop r10
00007b1fbf9da325  pop r9
00007b1fbf9da327  pop r8
00007b1fbf9da329  pop rsi
00007b1fbf9da32a  pop rdi
00007b1fbf9da32b  pop rdx
00007b1fbf9da32c  pop rcx
00007b1fbf9da32d  pop rax
00007b1fbf9da32e  add rsp, 0x08
00007b1fbf9da332  jmp 0x00007B1FBF9D641A
00007b1fbf9da337  sub rsp, 0x08
00007b1fbf9da33b  push rax
00007b1fbf9da33c  push rcx
00007b1fbf9da33d  push rdx
00007b1fbf9da33e  push rdi
00007b1fbf9da33f  push rsi
00007b1fbf9da340  push r8
00007b1fbf9da342  push r9
00007b1fbf9da344  push r10
00007b1fbf9da346  push r11
00007b1fbf9da348  sub rsp, 0xF0
00007b1fbf9da34f  vmovaps [rsp], xmm0
00007b1fbf9da354  vmovaps [rsp+0x10], xmm1
00007b1fbf9da35a  vmovaps [rsp+0x20], xmm2
00007b1fbf9da360  vmovaps [rsp+0x30], xmm3
00007b1fbf9da366  vmovaps [rsp+0x40], xmm4
00007b1fbf9da36c  vmovaps [rsp+0x50], xmm5
00007b1fbf9da372  vmovaps [rsp+0x60], xmm6
00007b1fbf9da378  vmovaps [rsp+0x70], xmm7
00007b1fbf9da37e  vmovaps [rsp+0x80], xmm8
00007b1fbf9da387  vmovaps [rsp+0x90], xmm9
00007b1fbf9da390  vmovaps [rsp+0xA0], xmm10
00007b1fbf9da399  vmovaps [rsp+0xB0], xmm11
00007b1fbf9da3a2  vmovaps [rsp+0xC0], xmm13
00007b1fbf9da3ab  vmovaps [rsp+0xD0], xmm14
00007b1fbf9da3b4  vmovaps [rsp+0xE0], xmm15
00007b1fbf9da3bd  sub rsp, 0x30
00007b1fbf9da3c1  movaps [rsp], xmm12
00007b1fbf9da3c6  movaps [rsp+0x10], xmm7
00007b1fbf9da3cb  movaps [rsp+0x20], xmm13
00007b1fbf9da3d1  lea rdi, [rsp]
00007b1fbf9da3d5  mov esi, 0x00
00007b1fbf9da3da  mov rax, 0x64AEE5F12530
00007b1fbf9da3e4  call rax
00007b1fbf9da3e6  movaps xmm12, [rsp]
00007b1fbf9da3eb  add rsp, 0x30
00007b1fbf9da3ef  vmovaps xmm0, [rsp]
00007b1fbf9da3f4  vmovaps xmm1, [rsp+0x10]
00007b1fbf9da3fa  vmovaps xmm2, [rsp+0x20]
00007b1fbf9da400  vmovaps xmm3, [rsp+0x30]
00007b1fbf9da406  vmovaps xmm4, [rsp+0x40]
00007b1fbf9da40c  vmovaps xmm5, [rsp+0x50]
00007b1fbf9da412  vmovaps xmm6, [rsp+0x60]
00007b1fbf9da418  vmovaps xmm7, [rsp+0x70]
00007b1fbf9da41e  vmovaps xmm8, [rsp+0x80]
00007b1fbf9da427  vmovaps xmm9, [rsp+0x90]
00007b1fbf9da430  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9da439  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9da442  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9da44b  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9da454  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9da45d  add rsp, 0xF0
00007b1fbf9da464  pop r11
00007b1fbf9da466  pop r10
00007b1fbf9da468  pop r9
00007b1fbf9da46a  pop r8
00007b1fbf9da46c  pop rsi
00007b1fbf9da46d  pop rdi
00007b1fbf9da46e  pop rdx
00007b1fbf9da46f  pop rcx
00007b1fbf9da470  pop rax
00007b1fbf9da471  add rsp, 0x08
00007b1fbf9da475  jmp 0x00007B1FBF9D6441
00007b1fbf9da47a  sub rsp, 0x08
00007b1fbf9da47e  push rax
00007b1fbf9da47f  push rcx
00007b1fbf9da480  push rdx
00007b1fbf9da481  push rdi
00007b1fbf9da482  push rsi
00007b1fbf9da483  push r8
00007b1fbf9da485  push r9
00007b1fbf9da487  push r10
00007b1fbf9da489  push r11
00007b1fbf9da48b  sub rsp, 0xF0
00007b1fbf9da492  vmovaps [rsp], xmm0
00007b1fbf9da497  vmovaps [rsp+0x10], xmm1
00007b1fbf9da49d  vmovaps [rsp+0x20], xmm2
00007b1fbf9da4a3  vmovaps [rsp+0x30], xmm3
00007b1fbf9da4a9  vmovaps [rsp+0x40], xmm4
00007b1fbf9da4af  vmovaps [rsp+0x50], xmm5
00007b1fbf9da4b5  vmovaps [rsp+0x60], xmm6
00007b1fbf9da4bb  vmovaps [rsp+0x70], xmm7
00007b1fbf9da4c1  vmovaps [rsp+0x80], xmm8
00007b1fbf9da4ca  vmovaps [rsp+0x90], xmm9
00007b1fbf9da4d3  vmovaps [rsp+0xA0], xmm10
00007b1fbf9da4dc  vmovaps [rsp+0xB0], xmm11
00007b1fbf9da4e5  vmovaps [rsp+0xC0], xmm12
00007b1fbf9da4ee  vmovaps [rsp+0xD0], xmm14
00007b1fbf9da4f7  vmovaps [rsp+0xE0], xmm15
00007b1fbf9da500  sub rsp, 0x30
00007b1fbf9da504  movaps [rsp], xmm13
00007b1fbf9da509  movaps [rsp+0x10], xmm15
00007b1fbf9da50f  movaps [rsp+0x20], xmm8
00007b1fbf9da515  lea rdi, [rsp]
00007b1fbf9da519  mov esi, 0x00
00007b1fbf9da51e  mov rax, 0x64AEE5F12530
00007b1fbf9da528  call rax
00007b1fbf9da52a  movaps xmm13, [rsp]
00007b1fbf9da52f  add rsp, 0x30
00007b1fbf9da533  vmovaps xmm0, [rsp]
00007b1fbf9da538  vmovaps xmm1, [rsp+0x10]
00007b1fbf9da53e  vmovaps xmm2, [rsp+0x20]
00007b1fbf9da544  vmovaps xmm3, [rsp+0x30]
00007b1fbf9da54a  vmovaps xmm4, [rsp+0x40]
00007b1fbf9da550  vmovaps xmm5, [rsp+0x50]
00007b1fbf9da556  vmovaps xmm6, [rsp+0x60]
00007b1fbf9da55c  vmovaps xmm7, [rsp+0x70]
00007b1fbf9da562  vmovaps xmm8, [rsp+0x80]
00007b1fbf9da56b  vmovaps xmm9, [rsp+0x90]
00007b1fbf9da574  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9da57d  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9da586  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9da58f  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9da598  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9da5a1  add rsp, 0xF0
00007b1fbf9da5a8  pop r11
00007b1fbf9da5aa  pop r10
00007b1fbf9da5ac  pop r9
00007b1fbf9da5ae  pop r8
00007b1fbf9da5b0  pop rsi
00007b1fbf9da5b1  pop rdi
00007b1fbf9da5b2  pop rdx
00007b1fbf9da5b3  pop rcx
00007b1fbf9da5b4  pop rax
00007b1fbf9da5b5  add rsp, 0x08
00007b1fbf9da5b9  jmp 0x00007B1FBF9D645C
00007b1fbf9da5be  sub rsp, 0x08
00007b1fbf9da5c2  push rax
00007b1fbf9da5c3  push rcx
00007b1fbf9da5c4  push rdx
00007b1fbf9da5c5  push rdi
00007b1fbf9da5c6  push rsi
00007b1fbf9da5c7  push r8
00007b1fbf9da5c9  push r9
00007b1fbf9da5cb  push r10
00007b1fbf9da5cd  push r11
00007b1fbf9da5cf  sub rsp, 0xF0
00007b1fbf9da5d6  vmovaps [rsp], xmm0
00007b1fbf9da5db  vmovaps [rsp+0x10], xmm1
00007b1fbf9da5e1  vmovaps [rsp+0x20], xmm2
00007b1fbf9da5e7  vmovaps [rsp+0x30], xmm3
00007b1fbf9da5ed  vmovaps [rsp+0x40], xmm4
00007b1fbf9da5f3  vmovaps [rsp+0x50], xmm5
00007b1fbf9da5f9  vmovaps [rsp+0x60], xmm6
00007b1fbf9da5ff  vmovaps [rsp+0x70], xmm7
00007b1fbf9da605  vmovaps [rsp+0x80], xmm9
00007b1fbf9da60e  vmovaps [rsp+0x90], xmm10
00007b1fbf9da617  vmovaps [rsp+0xA0], xmm11
00007b1fbf9da620  vmovaps [rsp+0xB0], xmm12
00007b1fbf9da629  vmovaps [rsp+0xC0], xmm13
00007b1fbf9da632  vmovaps [rsp+0xD0], xmm14
00007b1fbf9da63b  vmovaps [rsp+0xE0], xmm15
00007b1fbf9da644  sub rsp, 0x30
00007b1fbf9da648  movaps [rsp], xmm8
00007b1fbf9da64d  movaps [rsp+0x10], xmm15
00007b1fbf9da653  movaps [rsp+0x20], xmm9
00007b1fbf9da659  lea rdi, [rsp]
00007b1fbf9da65d  mov esi, 0x00
00007b1fbf9da662  mov rax, 0x64AEE5F12530
00007b1fbf9da66c  call rax
00007b1fbf9da66e  movaps xmm8, [rsp]
00007b1fbf9da673  add rsp, 0x30
00007b1fbf9da677  vmovaps xmm0, [rsp]
00007b1fbf9da67c  vmovaps xmm1, [rsp+0x10]
00007b1fbf9da682  vmovaps xmm2, [rsp+0x20]
00007b1fbf9da688  vmovaps xmm3, [rsp+0x30]
00007b1fbf9da68e  vmovaps xmm4, [rsp+0x40]
00007b1fbf9da694  vmovaps xmm5, [rsp+0x50]
00007b1fbf9da69a  vmovaps xmm6, [rsp+0x60]
00007b1fbf9da6a0  vmovaps xmm7, [rsp+0x70]
00007b1fbf9da6a6  vmovaps xmm9, [rsp+0x80]
00007b1fbf9da6af  vmovaps xmm10, [rsp+0x90]
00007b1fbf9da6b8  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9da6c1  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9da6ca  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9da6d3  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9da6dc  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9da6e5  add rsp, 0xF0
00007b1fbf9da6ec  pop r11
00007b1fbf9da6ee  pop r10
00007b1fbf9da6f0  pop r9
00007b1fbf9da6f2  pop r8
00007b1fbf9da6f4  pop rsi
00007b1fbf9da6f5  pop rdi
00007b1fbf9da6f6  pop rdx
00007b1fbf9da6f7  pop rcx
00007b1fbf9da6f8  pop rax
00007b1fbf9da6f9  add rsp, 0x08
00007b1fbf9da6fd  jmp 0x00007B1FBF9D648A
00007b1fbf9da702  sub rsp, 0x08
00007b1fbf9da706  push rax
00007b1fbf9da707  push rcx
00007b1fbf9da708  push rdx
00007b1fbf9da709  push rdi
00007b1fbf9da70a  push rsi
00007b1fbf9da70b  push r8
00007b1fbf9da70d  push r9
00007b1fbf9da70f  push r10
00007b1fbf9da711  push r11
00007b1fbf9da713  sub rsp, 0xF0
00007b1fbf9da71a  vmovaps [rsp], xmm0
00007b1fbf9da71f  vmovaps [rsp+0x10], xmm1
00007b1fbf9da725  vmovaps [rsp+0x20], xmm2
00007b1fbf9da72b  vmovaps [rsp+0x30], xmm3
00007b1fbf9da731  vmovaps [rsp+0x40], xmm4
00007b1fbf9da737  vmovaps [rsp+0x50], xmm5
00007b1fbf9da73d  vmovaps [rsp+0x60], xmm6
00007b1fbf9da743  vmovaps [rsp+0x70], xmm7
00007b1fbf9da749  vmovaps [rsp+0x80], xmm8
00007b1fbf9da752  vmovaps [rsp+0x90], xmm9
00007b1fbf9da75b  vmovaps [rsp+0xA0], xmm10
00007b1fbf9da764  vmovaps [rsp+0xB0], xmm11
00007b1fbf9da76d  vmovaps [rsp+0xC0], xmm12
00007b1fbf9da776  vmovaps [rsp+0xD0], xmm13
00007b1fbf9da77f  vmovaps [rsp+0xE0], xmm14
00007b1fbf9da788  sub rsp, 0x30
00007b1fbf9da78c  movaps [rsp], xmm15
00007b1fbf9da791  movaps [rsp+0x10], xmm11
00007b1fbf9da797  movaps [rsp+0x20], xmm6
00007b1fbf9da79c  lea rdi, [rsp]
00007b1fbf9da7a0  mov esi, 0x00
00007b1fbf9da7a5  mov rax, 0x64AEE5F12530
00007b1fbf9da7af  call rax
00007b1fbf9da7b1  movaps xmm15, [rsp]
00007b1fbf9da7b6  add rsp, 0x30
00007b1fbf9da7ba  vmovaps xmm0, [rsp]
00007b1fbf9da7bf  vmovaps xmm1, [rsp+0x10]
00007b1fbf9da7c5  vmovaps xmm2, [rsp+0x20]
00007b1fbf9da7cb  vmovaps xmm3, [rsp+0x30]
00007b1fbf9da7d1  vmovaps xmm4, [rsp+0x40]
00007b1fbf9da7d7  vmovaps xmm5, [rsp+0x50]
00007b1fbf9da7dd  vmovaps xmm6, [rsp+0x60]
00007b1fbf9da7e3  vmovaps xmm7, [rsp+0x70]
00007b1fbf9da7e9  vmovaps xmm8, [rsp+0x80]
00007b1fbf9da7f2  vmovaps xmm9, [rsp+0x90]
00007b1fbf9da7fb  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9da804  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9da80d  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9da816  vmovaps xmm13, [rsp+0xD0]
00007b1fbf9da81f  vmovaps xmm14, [rsp+0xE0]
00007b1fbf9da828  add rsp, 0xF0
00007b1fbf9da82f  pop r11
00007b1fbf9da831  pop r10
00007b1fbf9da833  pop r9
00007b1fbf9da835  pop r8
00007b1fbf9da837  pop rsi
00007b1fbf9da838  pop rdi
00007b1fbf9da839  pop rdx
00007b1fbf9da83a  pop rcx
00007b1fbf9da83b  pop rax
00007b1fbf9da83c  add rsp, 0x08
00007b1fbf9da840  jmp 0x00007B1FBF9D64A5
00007b1fbf9da845  sub rsp, 0x08
00007b1fbf9da849  push rax
00007b1fbf9da84a  push rcx
00007b1fbf9da84b  push rdx
00007b1fbf9da84c  push rdi
00007b1fbf9da84d  push rsi
00007b1fbf9da84e  push r8
00007b1fbf9da850  push r9
00007b1fbf9da852  push r10
00007b1fbf9da854  push r11
00007b1fbf9da856  sub rsp, 0xF0
00007b1fbf9da85d  vmovaps [rsp], xmm0
00007b1fbf9da862  vmovaps [rsp+0x10], xmm1
00007b1fbf9da868  vmovaps [rsp+0x20], xmm2
00007b1fbf9da86e  vmovaps [rsp+0x30], xmm3
00007b1fbf9da874  vmovaps [rsp+0x40], xmm4
00007b1fbf9da87a  vmovaps [rsp+0x50], xmm5
00007b1fbf9da880  vmovaps [rsp+0x60], xmm6
00007b1fbf9da886  vmovaps [rsp+0x70], xmm8
00007b1fbf9da88c  vmovaps [rsp+0x80], xmm9
00007b1fbf9da895  vmovaps [rsp+0x90], xmm10
00007b1fbf9da89e  vmovaps [rsp+0xA0], xmm11
00007b1fbf9da8a7  vmovaps [rsp+0xB0], xmm12
00007b1fbf9da8b0  vmovaps [rsp+0xC0], xmm13
00007b1fbf9da8b9  vmovaps [rsp+0xD0], xmm14
00007b1fbf9da8c2  vmovaps [rsp+0xE0], xmm15
00007b1fbf9da8cb  sub rsp, 0x30
00007b1fbf9da8cf  movaps [rsp], xmm7
00007b1fbf9da8d3  movaps [rsp+0x10], xmm11
00007b1fbf9da8d9  movaps [rsp+0x20], xmm9
00007b1fbf9da8df  lea rdi, [rsp]
00007b1fbf9da8e3  mov esi, 0x00
00007b1fbf9da8e8  mov rax, 0x64AEE5F12530
00007b1fbf9da8f2  call rax
00007b1fbf9da8f4  movaps xmm7, [rsp]
00007b1fbf9da8f8  add rsp, 0x30
00007b1fbf9da8fc  vmovaps xmm0, [rsp]
00007b1fbf9da901  vmovaps xmm1, [rsp+0x10]
00007b1fbf9da907  vmovaps xmm2, [rsp+0x20]
00007b1fbf9da90d  vmovaps xmm3, [rsp+0x30]
00007b1fbf9da913  vmovaps xmm4, [rsp+0x40]
00007b1fbf9da919  vmovaps xmm5, [rsp+0x50]
00007b1fbf9da91f  vmovaps xmm6, [rsp+0x60]
00007b1fbf9da925  vmovaps xmm8, [rsp+0x70]
00007b1fbf9da92b  vmovaps xmm9, [rsp+0x80]
00007b1fbf9da934  vmovaps xmm10, [rsp+0x90]
00007b1fbf9da93d  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9da946  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9da94f  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9da958  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9da961  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9da96a  add rsp, 0xF0
00007b1fbf9da971  pop r11
00007b1fbf9da973  pop r10
00007b1fbf9da975  pop r9
00007b1fbf9da977  pop r8
00007b1fbf9da979  pop rsi
00007b1fbf9da97a  pop rdi
00007b1fbf9da97b  pop rdx
00007b1fbf9da97c  pop rcx
00007b1fbf9da97d  pop rax
00007b1fbf9da97e  add rsp, 0x08
00007b1fbf9da982  jmp 0x00007B1FBF9D64D2
00007b1fbf9da987  sub rsp, 0x08
00007b1fbf9da98b  push rax
00007b1fbf9da98c  push rcx
00007b1fbf9da98d  push rdx
00007b1fbf9da98e  push rdi
00007b1fbf9da98f  push rsi
00007b1fbf9da990  push r8
00007b1fbf9da992  push r9
00007b1fbf9da994  push r10
00007b1fbf9da996  push r11
00007b1fbf9da998  sub rsp, 0xF0
00007b1fbf9da99f  vmovaps [rsp], xmm0
00007b1fbf9da9a4  vmovaps [rsp+0x10], xmm1
00007b1fbf9da9aa  vmovaps [rsp+0x20], xmm2
00007b1fbf9da9b0  vmovaps [rsp+0x30], xmm3
00007b1fbf9da9b6  vmovaps [rsp+0x40], xmm4
00007b1fbf9da9bc  vmovaps [rsp+0x50], xmm5
00007b1fbf9da9c2  vmovaps [rsp+0x60], xmm6
00007b1fbf9da9c8  vmovaps [rsp+0x70], xmm7
00007b1fbf9da9ce  vmovaps [rsp+0x80], xmm8
00007b1fbf9da9d7  vmovaps [rsp+0x90], xmm9
00007b1fbf9da9e0  vmovaps [rsp+0xA0], xmm10
00007b1fbf9da9e9  vmovaps [rsp+0xB0], xmm12
00007b1fbf9da9f2  vmovaps [rsp+0xC0], xmm13
00007b1fbf9da9fb  vmovaps [rsp+0xD0], xmm14
00007b1fbf9daa04  vmovaps [rsp+0xE0], xmm15
00007b1fbf9daa0d  sub rsp, 0x30
00007b1fbf9daa11  movaps [rsp], xmm11
00007b1fbf9daa16  movaps [rsp+0x10], xmm10
00007b1fbf9daa1c  movaps [rsp+0x20], xmm14
00007b1fbf9daa22  lea rdi, [rsp]
00007b1fbf9daa26  mov esi, 0x00
00007b1fbf9daa2b  mov rax, 0x64AEE5F12530
00007b1fbf9daa35  call rax
00007b1fbf9daa37  movaps xmm11, [rsp]
00007b1fbf9daa3c  add rsp, 0x30
00007b1fbf9daa40  vmovaps xmm0, [rsp]
00007b1fbf9daa45  vmovaps xmm1, [rsp+0x10]
00007b1fbf9daa4b  vmovaps xmm2, [rsp+0x20]
00007b1fbf9daa51  vmovaps xmm3, [rsp+0x30]
00007b1fbf9daa57  vmovaps xmm4, [rsp+0x40]
00007b1fbf9daa5d  vmovaps xmm5, [rsp+0x50]
00007b1fbf9daa63  vmovaps xmm6, [rsp+0x60]
00007b1fbf9daa69  vmovaps xmm7, [rsp+0x70]
00007b1fbf9daa6f  vmovaps xmm8, [rsp+0x80]
00007b1fbf9daa78  vmovaps xmm9, [rsp+0x90]
00007b1fbf9daa81  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9daa8a  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9daa93  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9daa9c  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9daaa5  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9daaae  add rsp, 0xF0
00007b1fbf9daab5  pop r11
00007b1fbf9daab7  pop r10
00007b1fbf9daab9  pop r9
00007b1fbf9daabb  pop r8
00007b1fbf9daabd  pop rsi
00007b1fbf9daabe  pop rdi
00007b1fbf9daabf  pop rdx
00007b1fbf9daac0  pop rcx
00007b1fbf9daac1  pop rax
00007b1fbf9daac2  add rsp, 0x08
00007b1fbf9daac6  jmp 0x00007B1FBF9D64ED
00007b1fbf9daacb  call 0x00007B1FBF8E45A0
00007b1fbf9daad0  jmp 0x00007B1FBF9D64F7
00007b1fbf9daad5  sub rsp, 0x08
00007b1fbf9daad9  push rax
00007b1fbf9daada  push rcx
00007b1fbf9daadb  push rdx
00007b1fbf9daadc  push rdi
00007b1fbf9daadd  push rsi
00007b1fbf9daade  push r8
00007b1fbf9daae0  push r9
00007b1fbf9daae2  push r10
00007b1fbf9daae4  push r11
00007b1fbf9daae6  sub rsp, 0xF0
00007b1fbf9daaed  vmovaps [rsp], xmm0
00007b1fbf9daaf2  vmovaps [rsp+0x10], xmm1
00007b1fbf9daaf8  vmovaps [rsp+0x20], xmm2
00007b1fbf9daafe  vmovaps [rsp+0x30], xmm3
00007b1fbf9dab04  vmovaps [rsp+0x40], xmm4
00007b1fbf9dab0a  vmovaps [rsp+0x50], xmm5
00007b1fbf9dab10  vmovaps [rsp+0x60], xmm6
00007b1fbf9dab16  vmovaps [rsp+0x70], xmm7
00007b1fbf9dab1c  vmovaps [rsp+0x80], xmm8
00007b1fbf9dab25  vmovaps [rsp+0x90], xmm9
00007b1fbf9dab2e  vmovaps [rsp+0xA0], xmm11
00007b1fbf9dab37  vmovaps [rsp+0xB0], xmm12
00007b1fbf9dab40  vmovaps [rsp+0xC0], xmm13
00007b1fbf9dab49  vmovaps [rsp+0xD0], xmm14
00007b1fbf9dab52  vmovaps [rsp+0xE0], xmm15
00007b1fbf9dab5b  sub rsp, 0x30
00007b1fbf9dab5f  movaps [rsp], xmm10
00007b1fbf9dab64  movaps [rsp+0x10], xmm1
00007b1fbf9dab69  movaps [rsp+0x20], xmm12
00007b1fbf9dab6f  lea rdi, [rsp]
00007b1fbf9dab73  mov esi, 0x00
00007b1fbf9dab78  mov rax, 0x64AEE5F12530
00007b1fbf9dab82  call rax
00007b1fbf9dab84  movaps xmm10, [rsp]
00007b1fbf9dab89  add rsp, 0x30
00007b1fbf9dab8d  vmovaps xmm0, [rsp]
00007b1fbf9dab92  vmovaps xmm1, [rsp+0x10]
00007b1fbf9dab98  vmovaps xmm2, [rsp+0x20]
00007b1fbf9dab9e  vmovaps xmm3, [rsp+0x30]
00007b1fbf9daba4  vmovaps xmm4, [rsp+0x40]
00007b1fbf9dabaa  vmovaps xmm5, [rsp+0x50]
00007b1fbf9dabb0  vmovaps xmm6, [rsp+0x60]
00007b1fbf9dabb6  vmovaps xmm7, [rsp+0x70]
00007b1fbf9dabbc  vmovaps xmm8, [rsp+0x80]
00007b1fbf9dabc5  vmovaps xmm9, [rsp+0x90]
00007b1fbf9dabce  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9dabd7  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9dabe0  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9dabe9  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9dabf2  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9dabfb  add rsp, 0xF0
00007b1fbf9dac02  pop r11
00007b1fbf9dac04  pop r10
00007b1fbf9dac06  pop r9
00007b1fbf9dac08  pop r8
00007b1fbf9dac0a  pop rsi
00007b1fbf9dac0b  pop rdi
00007b1fbf9dac0c  pop rdx
00007b1fbf9dac0d  pop rcx
00007b1fbf9dac0e  pop rax
00007b1fbf9dac0f  add rsp, 0x08
00007b1fbf9dac13  jmp 0x00007B1FBF9D651A
00007b1fbf9dac18  sub rsp, 0x08
00007b1fbf9dac1c  push rax
00007b1fbf9dac1d  push rcx
00007b1fbf9dac1e  push rdx
00007b1fbf9dac1f  push rdi
00007b1fbf9dac20  push rsi
00007b1fbf9dac21  push r8
00007b1fbf9dac23  push r9
00007b1fbf9dac25  push r10
00007b1fbf9dac27  push r11
00007b1fbf9dac29  sub rsp, 0xF0
00007b1fbf9dac30  vmovaps [rsp], xmm0
00007b1fbf9dac35  vmovaps [rsp+0x10], xmm1
00007b1fbf9dac3b  vmovaps [rsp+0x20], xmm2
00007b1fbf9dac41  vmovaps [rsp+0x30], xmm3
00007b1fbf9dac47  vmovaps [rsp+0x40], xmm4
00007b1fbf9dac4d  vmovaps [rsp+0x50], xmm5
00007b1fbf9dac53  vmovaps [rsp+0x60], xmm6
00007b1fbf9dac59  vmovaps [rsp+0x70], xmm7
00007b1fbf9dac5f  vmovaps [rsp+0x80], xmm8
00007b1fbf9dac68  vmovaps [rsp+0x90], xmm9
00007b1fbf9dac71  vmovaps [rsp+0xA0], xmm10
00007b1fbf9dac7a  vmovaps [rsp+0xB0], xmm11
00007b1fbf9dac83  vmovaps [rsp+0xC0], xmm13
00007b1fbf9dac8c  vmovaps [rsp+0xD0], xmm14
00007b1fbf9dac95  vmovaps [rsp+0xE0], xmm15
00007b1fbf9dac9e  sub rsp, 0x30
00007b1fbf9daca2  movaps [rsp], xmm12
00007b1fbf9daca7  movaps [rsp+0x10], xmm14
00007b1fbf9dacad  movaps [rsp+0x20], xmm1
00007b1fbf9dacb2  lea rdi, [rsp]
00007b1fbf9dacb6  mov esi, 0x00
00007b1fbf9dacbb  mov rax, 0x64AEE5F12530
00007b1fbf9dacc5  call rax
00007b1fbf9dacc7  movaps xmm12, [rsp]
00007b1fbf9daccc  add rsp, 0x30
00007b1fbf9dacd0  vmovaps xmm0, [rsp]
00007b1fbf9dacd5  vmovaps xmm1, [rsp+0x10]
00007b1fbf9dacdb  vmovaps xmm2, [rsp+0x20]
00007b1fbf9dace1  vmovaps xmm3, [rsp+0x30]
00007b1fbf9dace7  vmovaps xmm4, [rsp+0x40]
00007b1fbf9daced  vmovaps xmm5, [rsp+0x50]
00007b1fbf9dacf3  vmovaps xmm6, [rsp+0x60]
00007b1fbf9dacf9  vmovaps xmm7, [rsp+0x70]
00007b1fbf9dacff  vmovaps xmm8, [rsp+0x80]
00007b1fbf9dad08  vmovaps xmm9, [rsp+0x90]
00007b1fbf9dad11  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9dad1a  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9dad23  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9dad2c  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9dad35  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9dad3e  add rsp, 0xF0
00007b1fbf9dad45  pop r11
00007b1fbf9dad47  pop r10
00007b1fbf9dad49  pop r9
00007b1fbf9dad4b  pop r8
00007b1fbf9dad4d  pop rsi
00007b1fbf9dad4e  pop rdi
00007b1fbf9dad4f  pop rdx
00007b1fbf9dad50  pop rcx
00007b1fbf9dad51  pop rax
00007b1fbf9dad52  add rsp, 0x08
00007b1fbf9dad56  jmp 0x00007B1FBF9D6549
00007b1fbf9dad5b  sub rsp, 0x08
00007b1fbf9dad5f  push rax
00007b1fbf9dad60  push rcx
00007b1fbf9dad61  push rdx
00007b1fbf9dad62  push rdi
00007b1fbf9dad63  push rsi
00007b1fbf9dad64  push r8
00007b1fbf9dad66  push r9
00007b1fbf9dad68  push r10
00007b1fbf9dad6a  push r11
00007b1fbf9dad6c  sub rsp, 0xF0
00007b1fbf9dad73  vmovaps [rsp], xmm0
00007b1fbf9dad78  vmovaps [rsp+0x10], xmm1
00007b1fbf9dad7e  vmovaps [rsp+0x20], xmm2
00007b1fbf9dad84  vmovaps [rsp+0x30], xmm3
00007b1fbf9dad8a  vmovaps [rsp+0x40], xmm4
00007b1fbf9dad90  vmovaps [rsp+0x50], xmm5
00007b1fbf9dad96  vmovaps [rsp+0x60], xmm6
00007b1fbf9dad9c  vmovaps [rsp+0x70], xmm7
00007b1fbf9dada2  vmovaps [rsp+0x80], xmm8
00007b1fbf9dadab  vmovaps [rsp+0x90], xmm9
00007b1fbf9dadb4  vmovaps [rsp+0xA0], xmm10
00007b1fbf9dadbd  vmovaps [rsp+0xB0], xmm11
00007b1fbf9dadc6  vmovaps [rsp+0xC0], xmm12
00007b1fbf9dadcf  vmovaps [rsp+0xD0], xmm13
00007b1fbf9dadd8  vmovaps [rsp+0xE0], xmm15
00007b1fbf9dade1  sub rsp, 0x30
00007b1fbf9dade5  movaps [rsp], xmm14
00007b1fbf9dadea  movaps [rsp+0x10], xmm9
00007b1fbf9dadf0  movaps [rsp+0x20], xmm1
00007b1fbf9dadf5  lea rdi, [rsp]
00007b1fbf9dadf9  mov esi, 0x00
00007b1fbf9dadfe  mov rax, 0x64AEE5F12530
00007b1fbf9dae08  call rax
00007b1fbf9dae0a  movaps xmm14, [rsp]
00007b1fbf9dae0f  add rsp, 0x30
00007b1fbf9dae13  vmovaps xmm0, [rsp]
00007b1fbf9dae18  vmovaps xmm1, [rsp+0x10]
00007b1fbf9dae1e  vmovaps xmm2, [rsp+0x20]
00007b1fbf9dae24  vmovaps xmm3, [rsp+0x30]
00007b1fbf9dae2a  vmovaps xmm4, [rsp+0x40]
00007b1fbf9dae30  vmovaps xmm5, [rsp+0x50]
00007b1fbf9dae36  vmovaps xmm6, [rsp+0x60]
00007b1fbf9dae3c  vmovaps xmm7, [rsp+0x70]
00007b1fbf9dae42  vmovaps xmm8, [rsp+0x80]
00007b1fbf9dae4b  vmovaps xmm9, [rsp+0x90]
00007b1fbf9dae54  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9dae5d  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9dae66  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9dae6f  vmovaps xmm13, [rsp+0xD0]
00007b1fbf9dae78  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9dae81  add rsp, 0xF0
00007b1fbf9dae88  pop r11
00007b1fbf9dae8a  pop r10
00007b1fbf9dae8c  pop r9
00007b1fbf9dae8e  pop r8
00007b1fbf9dae90  pop rsi
00007b1fbf9dae91  pop rdi
00007b1fbf9dae92  pop rdx
00007b1fbf9dae93  pop rcx
00007b1fbf9dae94  pop rax
00007b1fbf9dae95  add rsp, 0x08
00007b1fbf9dae99  jmp 0x00007B1FBF9D6578
00007b1fbf9dae9e  sub rsp, 0x08
00007b1fbf9daea2  push rax
00007b1fbf9daea3  push rcx
00007b1fbf9daea4  push rdx
00007b1fbf9daea5  push rdi
00007b1fbf9daea6  push rsi
00007b1fbf9daea7  push r8
00007b1fbf9daea9  push r9
00007b1fbf9daeab  push r10
00007b1fbf9daead  push r11
00007b1fbf9daeaf  sub rsp, 0xF0
00007b1fbf9daeb6  vmovaps [rsp], xmm0
00007b1fbf9daebb  vmovaps [rsp+0x10], xmm2
00007b1fbf9daec1  vmovaps [rsp+0x20], xmm3
00007b1fbf9daec7  vmovaps [rsp+0x30], xmm4
00007b1fbf9daecd  vmovaps [rsp+0x40], xmm5
00007b1fbf9daed3  vmovaps [rsp+0x50], xmm6
00007b1fbf9daed9  vmovaps [rsp+0x60], xmm7
00007b1fbf9daedf  vmovaps [rsp+0x70], xmm8
00007b1fbf9daee5  vmovaps [rsp+0x80], xmm9
00007b1fbf9daeee  vmovaps [rsp+0x90], xmm10
00007b1fbf9daef7  vmovaps [rsp+0xA0], xmm11
00007b1fbf9daf00  vmovaps [rsp+0xB0], xmm12
00007b1fbf9daf09  vmovaps [rsp+0xC0], xmm13
00007b1fbf9daf12  vmovaps [rsp+0xD0], xmm14
00007b1fbf9daf1b  vmovaps [rsp+0xE0], xmm15
00007b1fbf9daf24  sub rsp, 0x30
00007b1fbf9daf28  movaps [rsp], xmm1
00007b1fbf9daf2c  movaps [rsp+0x10], xmm13
00007b1fbf9daf32  movaps [rsp+0x20], xmm8
00007b1fbf9daf38  lea rdi, [rsp]
00007b1fbf9daf3c  mov esi, 0x00
00007b1fbf9daf41  mov rax, 0x64AEE5F12530
00007b1fbf9daf4b  call rax
00007b1fbf9daf4d  movaps xmm1, [rsp]
00007b1fbf9daf51  add rsp, 0x30
00007b1fbf9daf55  vmovaps xmm0, [rsp]
00007b1fbf9daf5a  vmovaps xmm2, [rsp+0x10]
00007b1fbf9daf60  vmovaps xmm3, [rsp+0x20]
00007b1fbf9daf66  vmovaps xmm4, [rsp+0x30]
00007b1fbf9daf6c  vmovaps xmm5, [rsp+0x40]
00007b1fbf9daf72  vmovaps xmm6, [rsp+0x50]
00007b1fbf9daf78  vmovaps xmm7, [rsp+0x60]
00007b1fbf9daf7e  vmovaps xmm8, [rsp+0x70]
00007b1fbf9daf84  vmovaps xmm9, [rsp+0x80]
00007b1fbf9daf8d  vmovaps xmm10, [rsp+0x90]
00007b1fbf9daf96  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9daf9f  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9dafa8  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9dafb1  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9dafba  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9dafc3  add rsp, 0xF0
00007b1fbf9dafca  pop r11
00007b1fbf9dafcc  pop r10
00007b1fbf9dafce  pop r9
00007b1fbf9dafd0  pop r8
00007b1fbf9dafd2  pop rsi
00007b1fbf9dafd3  pop rdi
00007b1fbf9dafd4  pop rdx
00007b1fbf9dafd5  pop rcx
00007b1fbf9dafd6  pop rax
00007b1fbf9dafd7  add rsp, 0x08
00007b1fbf9dafdb  jmp 0x00007B1FBF9D659A
00007b1fbf9dafe0  call 0x00007B1FBF80C260
00007b1fbf9dafe5  jmp 0x00007B1FBF9D65A8
00007b1fbf9dafea  call 0x00007B1FBF8DE950
00007b1fbf9dafef  jmp 0x00007B1FBF9D65B2
00007b1fbf9daff4  sub rsp, 0x08
00007b1fbf9daff8  push rax
00007b1fbf9daff9  push rcx
00007b1fbf9daffa  push rdx
00007b1fbf9daffb  push rdi
00007b1fbf9daffc  push rsi
00007b1fbf9daffd  push r8
00007b1fbf9dafff  push r9
00007b1fbf9db001  push r10
00007b1fbf9db003  push r11
00007b1fbf9db005  sub rsp, 0xF0
00007b1fbf9db00c  vmovaps [rsp], xmm0
00007b1fbf9db011  vmovaps [rsp+0x10], xmm1
00007b1fbf9db017  vmovaps [rsp+0x20], xmm2
00007b1fbf9db01d  vmovaps [rsp+0x30], xmm3
00007b1fbf9db023  vmovaps [rsp+0x40], xmm4
00007b1fbf9db029  vmovaps [rsp+0x50], xmm5
00007b1fbf9db02f  vmovaps [rsp+0x60], xmm6
00007b1fbf9db035  vmovaps [rsp+0x70], xmm7
00007b1fbf9db03b  vmovaps [rsp+0x80], xmm9
00007b1fbf9db044  vmovaps [rsp+0x90], xmm10
00007b1fbf9db04d  vmovaps [rsp+0xA0], xmm11
00007b1fbf9db056  vmovaps [rsp+0xB0], xmm12
00007b1fbf9db05f  vmovaps [rsp+0xC0], xmm13
00007b1fbf9db068  vmovaps [rsp+0xD0], xmm14
00007b1fbf9db071  vmovaps [rsp+0xE0], xmm15
00007b1fbf9db07a  sub rsp, 0x30
00007b1fbf9db07e  movaps [rsp], xmm8
00007b1fbf9db083  movaps [rsp+0x10], xmm15
00007b1fbf9db089  movaps [rsp+0x20], xmm7
00007b1fbf9db08e  lea rdi, [rsp]
00007b1fbf9db092  mov esi, 0x00
00007b1fbf9db097  mov rax, 0x64AEE5F12530
00007b1fbf9db0a1  call rax
00007b1fbf9db0a3  movaps xmm8, [rsp]
00007b1fbf9db0a8  add rsp, 0x30
00007b1fbf9db0ac  vmovaps xmm0, [rsp]
00007b1fbf9db0b1  vmovaps xmm1, [rsp+0x10]
00007b1fbf9db0b7  vmovaps xmm2, [rsp+0x20]
00007b1fbf9db0bd  vmovaps xmm3, [rsp+0x30]
00007b1fbf9db0c3  vmovaps xmm4, [rsp+0x40]
00007b1fbf9db0c9  vmovaps xmm5, [rsp+0x50]
00007b1fbf9db0cf  vmovaps xmm6, [rsp+0x60]
00007b1fbf9db0d5  vmovaps xmm7, [rsp+0x70]
00007b1fbf9db0db  vmovaps xmm9, [rsp+0x80]
00007b1fbf9db0e4  vmovaps xmm10, [rsp+0x90]
00007b1fbf9db0ed  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9db0f6  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9db0ff  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9db108  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9db111  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9db11a  add rsp, 0xF0
00007b1fbf9db121  pop r11
00007b1fbf9db123  pop r10
00007b1fbf9db125  pop r9
00007b1fbf9db127  pop r8
00007b1fbf9db129  pop rsi
00007b1fbf9db12a  pop rdi
00007b1fbf9db12b  pop rdx
00007b1fbf9db12c  pop rcx
00007b1fbf9db12d  pop rax
00007b1fbf9db12e  add rsp, 0x08
00007b1fbf9db132  jmp 0x00007B1FBF9D65D4
00007b1fbf9db137  sub rsp, 0x08
00007b1fbf9db13b  push rax
00007b1fbf9db13c  push rcx
00007b1fbf9db13d  push rdx
00007b1fbf9db13e  push rdi
00007b1fbf9db13f  push rsi
00007b1fbf9db140  push r8
00007b1fbf9db142  push r9
00007b1fbf9db144  push r10
00007b1fbf9db146  push r11
00007b1fbf9db148  sub rsp, 0xF0
00007b1fbf9db14f  vmovaps [rsp], xmm0
00007b1fbf9db154  vmovaps [rsp+0x10], xmm1
00007b1fbf9db15a  vmovaps [rsp+0x20], xmm2
00007b1fbf9db160  vmovaps [rsp+0x30], xmm3
00007b1fbf9db166  vmovaps [rsp+0x40], xmm4
00007b1fbf9db16c  vmovaps [rsp+0x50], xmm5
00007b1fbf9db172  vmovaps [rsp+0x60], xmm6
00007b1fbf9db178  vmovaps [rsp+0x70], xmm8
00007b1fbf9db17e  vmovaps [rsp+0x80], xmm9
00007b1fbf9db187  vmovaps [rsp+0x90], xmm10
00007b1fbf9db190  vmovaps [rsp+0xA0], xmm11
00007b1fbf9db199  vmovaps [rsp+0xB0], xmm12
00007b1fbf9db1a2  vmovaps [rsp+0xC0], xmm13
00007b1fbf9db1ab  vmovaps [rsp+0xD0], xmm14
00007b1fbf9db1b4  vmovaps [rsp+0xE0], xmm15
00007b1fbf9db1bd  sub rsp, 0x30
00007b1fbf9db1c1  movaps [rsp], xmm7
00007b1fbf9db1c5  movaps [rsp+0x10], xmm9
00007b1fbf9db1cb  movaps [rsp+0x20], xmm15
00007b1fbf9db1d1  lea rdi, [rsp]
00007b1fbf9db1d5  mov esi, 0x00
00007b1fbf9db1da  mov rax, 0x64AEE5F12530
00007b1fbf9db1e4  call rax
00007b1fbf9db1e6  movaps xmm7, [rsp]
00007b1fbf9db1ea  add rsp, 0x30
00007b1fbf9db1ee  vmovaps xmm0, [rsp]
00007b1fbf9db1f3  vmovaps xmm1, [rsp+0x10]
00007b1fbf9db1f9  vmovaps xmm2, [rsp+0x20]
00007b1fbf9db1ff  vmovaps xmm3, [rsp+0x30]
00007b1fbf9db205  vmovaps xmm4, [rsp+0x40]
00007b1fbf9db20b  vmovaps xmm5, [rsp+0x50]
00007b1fbf9db211  vmovaps xmm6, [rsp+0x60]
00007b1fbf9db217  vmovaps xmm8, [rsp+0x70]
00007b1fbf9db21d  vmovaps xmm9, [rsp+0x80]
00007b1fbf9db226  vmovaps xmm10, [rsp+0x90]
00007b1fbf9db22f  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9db238  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9db241  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9db24a  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9db253  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9db25c  add rsp, 0xF0
00007b1fbf9db263  pop r11
00007b1fbf9db265  pop r10
00007b1fbf9db267  pop r9
00007b1fbf9db269  pop r8
00007b1fbf9db26b  pop rsi
00007b1fbf9db26c  pop rdi
00007b1fbf9db26d  pop rdx
00007b1fbf9db26e  pop rcx
00007b1fbf9db26f  pop rax
00007b1fbf9db270  add rsp, 0x08
00007b1fbf9db274  jmp 0x00007B1FBF9D6601
00007b1fbf9db279  sub rsp, 0x08
00007b1fbf9db27d  push rax
00007b1fbf9db27e  push rcx
00007b1fbf9db27f  push rdx
00007b1fbf9db280  push rdi
00007b1fbf9db281  push rsi
00007b1fbf9db282  push r8
00007b1fbf9db284  push r9
00007b1fbf9db286  push r10
00007b1fbf9db288  push r11
00007b1fbf9db28a  sub rsp, 0xF0
00007b1fbf9db291  vmovaps [rsp], xmm0
00007b1fbf9db296  vmovaps [rsp+0x10], xmm1
00007b1fbf9db29c  vmovaps [rsp+0x20], xmm2
00007b1fbf9db2a2  vmovaps [rsp+0x30], xmm3
00007b1fbf9db2a8  vmovaps [rsp+0x40], xmm4
00007b1fbf9db2ae  vmovaps [rsp+0x50], xmm5
00007b1fbf9db2b4  vmovaps [rsp+0x60], xmm6
00007b1fbf9db2ba  vmovaps [rsp+0x70], xmm7
00007b1fbf9db2c0  vmovaps [rsp+0x80], xmm8
00007b1fbf9db2c9  vmovaps [rsp+0x90], xmm10
00007b1fbf9db2d2  vmovaps [rsp+0xA0], xmm11
00007b1fbf9db2db  vmovaps [rsp+0xB0], xmm12
00007b1fbf9db2e4  vmovaps [rsp+0xC0], xmm13
00007b1fbf9db2ed  vmovaps [rsp+0xD0], xmm14
00007b1fbf9db2f6  vmovaps [rsp+0xE0], xmm15
00007b1fbf9db2ff  sub rsp, 0x30
00007b1fbf9db303  movaps [rsp], xmm9
00007b1fbf9db308  movaps [rsp+0x10], xmm13
00007b1fbf9db30e  movaps [rsp+0x20], xmm15
00007b1fbf9db314  lea rdi, [rsp]
00007b1fbf9db318  mov esi, 0x00
00007b1fbf9db31d  mov rax, 0x64AEE5F12530
00007b1fbf9db327  call rax
00007b1fbf9db329  movaps xmm9, [rsp]
00007b1fbf9db32e  add rsp, 0x30
00007b1fbf9db332  vmovaps xmm0, [rsp]
00007b1fbf9db337  vmovaps xmm1, [rsp+0x10]
00007b1fbf9db33d  vmovaps xmm2, [rsp+0x20]
00007b1fbf9db343  vmovaps xmm3, [rsp+0x30]
00007b1fbf9db349  vmovaps xmm4, [rsp+0x40]
00007b1fbf9db34f  vmovaps xmm5, [rsp+0x50]
00007b1fbf9db355  vmovaps xmm6, [rsp+0x60]
00007b1fbf9db35b  vmovaps xmm7, [rsp+0x70]
00007b1fbf9db361  vmovaps xmm8, [rsp+0x80]
00007b1fbf9db36a  vmovaps xmm10, [rsp+0x90]
00007b1fbf9db373  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9db37c  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9db385  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9db38e  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9db397  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9db3a0  add rsp, 0xF0
00007b1fbf9db3a7  pop r11
00007b1fbf9db3a9  pop r10
00007b1fbf9db3ab  pop r9
00007b1fbf9db3ad  pop r8
00007b1fbf9db3af  pop rsi
00007b1fbf9db3b0  pop rdi
00007b1fbf9db3b1  pop rdx
00007b1fbf9db3b2  pop rcx
00007b1fbf9db3b3  pop rax
00007b1fbf9db3b4  add rsp, 0x08
00007b1fbf9db3b8  jmp 0x00007B1FBF9D662F
00007b1fbf9db3bd  sub rsp, 0x08
00007b1fbf9db3c1  push rax
00007b1fbf9db3c2  push rcx
00007b1fbf9db3c3  push rdx
00007b1fbf9db3c4  push rdi
00007b1fbf9db3c5  push rsi
00007b1fbf9db3c6  push r8
00007b1fbf9db3c8  push r9
00007b1fbf9db3ca  push r10
00007b1fbf9db3cc  push r11
00007b1fbf9db3ce  sub rsp, 0xF0
00007b1fbf9db3d5  vmovaps [rsp], xmm0
00007b1fbf9db3da  vmovaps [rsp+0x10], xmm1
00007b1fbf9db3e0  vmovaps [rsp+0x20], xmm2
00007b1fbf9db3e6  vmovaps [rsp+0x30], xmm3
00007b1fbf9db3ec  vmovaps [rsp+0x40], xmm4
00007b1fbf9db3f2  vmovaps [rsp+0x50], xmm5
00007b1fbf9db3f8  vmovaps [rsp+0x60], xmm6
00007b1fbf9db3fe  vmovaps [rsp+0x70], xmm7
00007b1fbf9db404  vmovaps [rsp+0x80], xmm8
00007b1fbf9db40d  vmovaps [rsp+0x90], xmm9
00007b1fbf9db416  vmovaps [rsp+0xA0], xmm10
00007b1fbf9db41f  vmovaps [rsp+0xB0], xmm11
00007b1fbf9db428  vmovaps [rsp+0xC0], xmm12
00007b1fbf9db431  vmovaps [rsp+0xD0], xmm13
00007b1fbf9db43a  vmovaps [rsp+0xE0], xmm14
00007b1fbf9db443  sub rsp, 0x30
00007b1fbf9db447  movaps [rsp], xmm15
00007b1fbf9db44c  movaps [rsp+0x10], xmm11
00007b1fbf9db452  movaps [rsp+0x20], xmm12
00007b1fbf9db458  lea rdi, [rsp]
00007b1fbf9db45c  mov esi, 0x00
00007b1fbf9db461  mov rax, 0x64AEE5F12530
00007b1fbf9db46b  call rax
00007b1fbf9db46d  movaps xmm15, [rsp]
00007b1fbf9db472  add rsp, 0x30
00007b1fbf9db476  vmovaps xmm0, [rsp]
00007b1fbf9db47b  vmovaps xmm1, [rsp+0x10]
00007b1fbf9db481  vmovaps xmm2, [rsp+0x20]
00007b1fbf9db487  vmovaps xmm3, [rsp+0x30]
00007b1fbf9db48d  vmovaps xmm4, [rsp+0x40]
00007b1fbf9db493  vmovaps xmm5, [rsp+0x50]
00007b1fbf9db499  vmovaps xmm6, [rsp+0x60]
00007b1fbf9db49f  vmovaps xmm7, [rsp+0x70]
00007b1fbf9db4a5  vmovaps xmm8, [rsp+0x80]
00007b1fbf9db4ae  vmovaps xmm9, [rsp+0x90]
00007b1fbf9db4b7  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9db4c0  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9db4c9  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9db4d2  vmovaps xmm13, [rsp+0xD0]
00007b1fbf9db4db  vmovaps xmm14, [rsp+0xE0]
00007b1fbf9db4e4  add rsp, 0xF0
00007b1fbf9db4eb  pop r11
00007b1fbf9db4ed  pop r10
00007b1fbf9db4ef  pop r9
00007b1fbf9db4f1  pop r8
00007b1fbf9db4f3  pop rsi
00007b1fbf9db4f4  pop rdi
00007b1fbf9db4f5  pop rdx
00007b1fbf9db4f6  pop rcx
00007b1fbf9db4f7  pop rax
00007b1fbf9db4f8  add rsp, 0x08
00007b1fbf9db4fc  jmp 0x00007B1FBF9D664A
00007b1fbf9db501  sub rsp, 0x08
00007b1fbf9db505  push rax
00007b1fbf9db506  push rcx
00007b1fbf9db507  push rdx
00007b1fbf9db508  push rdi
00007b1fbf9db509  push rsi
00007b1fbf9db50a  push r8
00007b1fbf9db50c  push r9
00007b1fbf9db50e  push r10
00007b1fbf9db510  push r11
00007b1fbf9db512  sub rsp, 0xF0
00007b1fbf9db519  vmovaps [rsp], xmm0
00007b1fbf9db51e  vmovaps [rsp+0x10], xmm1
00007b1fbf9db524  vmovaps [rsp+0x20], xmm2
00007b1fbf9db52a  vmovaps [rsp+0x30], xmm3
00007b1fbf9db530  vmovaps [rsp+0x40], xmm4
00007b1fbf9db536  vmovaps [rsp+0x50], xmm5
00007b1fbf9db53c  vmovaps [rsp+0x60], xmm6
00007b1fbf9db542  vmovaps [rsp+0x70], xmm7
00007b1fbf9db548  vmovaps [rsp+0x80], xmm8
00007b1fbf9db551  vmovaps [rsp+0x90], xmm9
00007b1fbf9db55a  vmovaps [rsp+0xA0], xmm10
00007b1fbf9db563  vmovaps [rsp+0xB0], xmm11
00007b1fbf9db56c  vmovaps [rsp+0xC0], xmm12
00007b1fbf9db575  vmovaps [rsp+0xD0], xmm14
00007b1fbf9db57e  vmovaps [rsp+0xE0], xmm15
00007b1fbf9db587  sub rsp, 0x30
00007b1fbf9db58b  movaps [rsp], xmm13
00007b1fbf9db590  movaps [rsp+0x10], xmm10
00007b1fbf9db596  movaps [rsp+0x20], xmm14
00007b1fbf9db59c  lea rdi, [rsp]
00007b1fbf9db5a0  mov esi, 0x00
00007b1fbf9db5a5  mov rax, 0x64AEE5F12530
00007b1fbf9db5af  call rax
00007b1fbf9db5b1  movaps xmm13, [rsp]
00007b1fbf9db5b6  add rsp, 0x30
00007b1fbf9db5ba  vmovaps xmm0, [rsp]
00007b1fbf9db5bf  vmovaps xmm1, [rsp+0x10]
00007b1fbf9db5c5  vmovaps xmm2, [rsp+0x20]
00007b1fbf9db5cb  vmovaps xmm3, [rsp+0x30]
00007b1fbf9db5d1  vmovaps xmm4, [rsp+0x40]
00007b1fbf9db5d7  vmovaps xmm5, [rsp+0x50]
00007b1fbf9db5dd  vmovaps xmm6, [rsp+0x60]
00007b1fbf9db5e3  vmovaps xmm7, [rsp+0x70]
00007b1fbf9db5e9  vmovaps xmm8, [rsp+0x80]
00007b1fbf9db5f2  vmovaps xmm9, [rsp+0x90]
00007b1fbf9db5fb  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9db604  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9db60d  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9db616  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9db61f  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9db628  add rsp, 0xF0
00007b1fbf9db62f  pop r11
00007b1fbf9db631  pop r10
00007b1fbf9db633  pop r9
00007b1fbf9db635  pop r8
00007b1fbf9db637  pop rsi
00007b1fbf9db638  pop rdi
00007b1fbf9db639  pop rdx
00007b1fbf9db63a  pop rcx
00007b1fbf9db63b  pop rax
00007b1fbf9db63c  add rsp, 0x08
00007b1fbf9db640  jmp 0x00007B1FBF9D666D
00007b1fbf9db645  sub rsp, 0x08
00007b1fbf9db649  push rax
00007b1fbf9db64a  push rcx
00007b1fbf9db64b  push rdx
00007b1fbf9db64c  push rdi
00007b1fbf9db64d  push rsi
00007b1fbf9db64e  push r8
00007b1fbf9db650  push r9
00007b1fbf9db652  push r10
00007b1fbf9db654  push r11
00007b1fbf9db656  sub rsp, 0xF0
00007b1fbf9db65d  vmovaps [rsp], xmm0
00007b1fbf9db662  vmovaps [rsp+0x10], xmm1
00007b1fbf9db668  vmovaps [rsp+0x20], xmm2
00007b1fbf9db66e  vmovaps [rsp+0x30], xmm3
00007b1fbf9db674  vmovaps [rsp+0x40], xmm4
00007b1fbf9db67a  vmovaps [rsp+0x50], xmm5
00007b1fbf9db680  vmovaps [rsp+0x60], xmm6
00007b1fbf9db686  vmovaps [rsp+0x70], xmm7
00007b1fbf9db68c  vmovaps [rsp+0x80], xmm8
00007b1fbf9db695  vmovaps [rsp+0x90], xmm9
00007b1fbf9db69e  vmovaps [rsp+0xA0], xmm10
00007b1fbf9db6a7  vmovaps [rsp+0xB0], xmm11
00007b1fbf9db6b0  vmovaps [rsp+0xC0], xmm12
00007b1fbf9db6b9  vmovaps [rsp+0xD0], xmm13
00007b1fbf9db6c2  vmovaps [rsp+0xE0], xmm15
00007b1fbf9db6cb  sub rsp, 0x30
00007b1fbf9db6cf  movaps [rsp], xmm14
00007b1fbf9db6d4  movaps [rsp+0x10], xmm1
00007b1fbf9db6d9  movaps [rsp+0x20], xmm7
00007b1fbf9db6de  lea rdi, [rsp]
00007b1fbf9db6e2  mov esi, 0x00
00007b1fbf9db6e7  mov rax, 0x64AEE5F12530
00007b1fbf9db6f1  call rax
00007b1fbf9db6f3  movaps xmm14, [rsp]
00007b1fbf9db6f8  add rsp, 0x30
00007b1fbf9db6fc  vmovaps xmm0, [rsp]
00007b1fbf9db701  vmovaps xmm1, [rsp+0x10]
00007b1fbf9db707  vmovaps xmm2, [rsp+0x20]
00007b1fbf9db70d  vmovaps xmm3, [rsp+0x30]
00007b1fbf9db713  vmovaps xmm4, [rsp+0x40]
00007b1fbf9db719  vmovaps xmm5, [rsp+0x50]
00007b1fbf9db71f  vmovaps xmm6, [rsp+0x60]
00007b1fbf9db725  vmovaps xmm7, [rsp+0x70]
00007b1fbf9db72b  vmovaps xmm8, [rsp+0x80]
00007b1fbf9db734  vmovaps xmm9, [rsp+0x90]
00007b1fbf9db73d  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9db746  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9db74f  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9db758  vmovaps xmm13, [rsp+0xD0]
00007b1fbf9db761  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9db76a  add rsp, 0xF0
00007b1fbf9db771  pop r11
00007b1fbf9db773  pop r10
00007b1fbf9db775  pop r9
00007b1fbf9db777  pop r8
00007b1fbf9db779  pop rsi
00007b1fbf9db77a  pop rdi
00007b1fbf9db77b  pop rdx
00007b1fbf9db77c  pop rcx
00007b1fbf9db77d  pop rax
00007b1fbf9db77e  add rsp, 0x08
00007b1fbf9db782  jmp 0x00007B1FBF9D6690
00007b1fbf9db787  sub rsp, 0x08
00007b1fbf9db78b  push rax
00007b1fbf9db78c  push rcx
00007b1fbf9db78d  push rdx
00007b1fbf9db78e  push rdi
00007b1fbf9db78f  push rsi
00007b1fbf9db790  push r8
00007b1fbf9db792  push r9
00007b1fbf9db794  push r10
00007b1fbf9db796  push r11
00007b1fbf9db798  sub rsp, 0xF0
00007b1fbf9db79f  vmovaps [rsp], xmm0
00007b1fbf9db7a4  vmovaps [rsp+0x10], xmm2
00007b1fbf9db7aa  vmovaps [rsp+0x20], xmm3
00007b1fbf9db7b0  vmovaps [rsp+0x30], xmm4
00007b1fbf9db7b6  vmovaps [rsp+0x40], xmm5
00007b1fbf9db7bc  vmovaps [rsp+0x50], xmm6
00007b1fbf9db7c2  vmovaps [rsp+0x60], xmm7
00007b1fbf9db7c8  vmovaps [rsp+0x70], xmm8
00007b1fbf9db7ce  vmovaps [rsp+0x80], xmm9
00007b1fbf9db7d7  vmovaps [rsp+0x90], xmm10
00007b1fbf9db7e0  vmovaps [rsp+0xA0], xmm11
00007b1fbf9db7e9  vmovaps [rsp+0xB0], xmm12
00007b1fbf9db7f2  vmovaps [rsp+0xC0], xmm13
00007b1fbf9db7fb  vmovaps [rsp+0xD0], xmm14
00007b1fbf9db804  vmovaps [rsp+0xE0], xmm15
00007b1fbf9db80d  sub rsp, 0x30
00007b1fbf9db811  movaps [rsp], xmm1
00007b1fbf9db815  movaps [rsp+0x10], xmm8
00007b1fbf9db81b  movaps [rsp+0x20], xmm9
00007b1fbf9db821  lea rdi, [rsp]
00007b1fbf9db825  mov esi, 0x00
00007b1fbf9db82a  mov rax, 0x64AEE5F12530
00007b1fbf9db834  call rax
00007b1fbf9db836  movaps xmm1, [rsp]
00007b1fbf9db83a  add rsp, 0x30
00007b1fbf9db83e  vmovaps xmm0, [rsp]
00007b1fbf9db843  vmovaps xmm2, [rsp+0x10]
00007b1fbf9db849  vmovaps xmm3, [rsp+0x20]
00007b1fbf9db84f  vmovaps xmm4, [rsp+0x30]
00007b1fbf9db855  vmovaps xmm5, [rsp+0x40]
00007b1fbf9db85b  vmovaps xmm6, [rsp+0x50]
00007b1fbf9db861  vmovaps xmm7, [rsp+0x60]
00007b1fbf9db867  vmovaps xmm8, [rsp+0x70]
00007b1fbf9db86d  vmovaps xmm9, [rsp+0x80]
00007b1fbf9db876  vmovaps xmm10, [rsp+0x90]
00007b1fbf9db87f  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9db888  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9db891  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9db89a  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9db8a3  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9db8ac  add rsp, 0xF0
00007b1fbf9db8b3  pop r11
00007b1fbf9db8b5  pop r10
00007b1fbf9db8b7  pop r9
00007b1fbf9db8b9  pop r8
00007b1fbf9db8bb  pop rsi
00007b1fbf9db8bc  pop rdi
00007b1fbf9db8bd  pop rdx
00007b1fbf9db8be  pop rcx
00007b1fbf9db8bf  pop rax
00007b1fbf9db8c0  add rsp, 0x08
00007b1fbf9db8c4  jmp 0x00007B1FBF9D66B2
00007b1fbf9db8c9  call 0x00007B1FBF8B3E40
00007b1fbf9db8ce  jmp 0x00007B1FBF9D66C0
00007b1fbf9db8d3  call 0x00007B1FBF80C380
00007b1fbf9db8d8  jmp 0x00007B1FBF9D66CA
00007b1fbf9db8dd  call 0x00007B1FBF80D600
00007b1fbf9db8e2  jmp 0x00007B1FBF9D66D4
00007b1fbf9db8e7  call 0x00007B1FBF7FF540
00007b1fbf9db8ec  jmp 0x00007B1FBF9D66DE
00007b1fbf9db8f1  int3
00007b1fbf9db8f2  nop [rax+rax*1], ax
00007b1fbf9db8fb  nop [rax+rax*1], eax
00007b1fbf9db900  mov eax, [r15+0x48]
00007b1fbf9db904  lea r14d, [eax+0x01]
00007b1fbf9db909  mov [rsp+0x10], r14d
00007b1fbf9db90e  mov r14d, r14d
00007b1fbf9db911  mov [r15+0x48], r14
00007b1fbf9db915  xor eax, eax
00007b1fbf9db917  mov r14d, [rsp+0x10]
00007b1fbf9db91c  cmp r14d, 0x1F4
00007b1fbf9db923  cmc
00007b1fbf9db924  lahf
00007b1fbf9db925  seto al
00007b1fbf9db928  mov [r15+0x108], eax
00007b1fbf9db92f  mov eax, [r15+0x108]
00007b1fbf9db936  sahf
00007b1fbf9db937  jnz 0x00007B1FBF9DB969
00007b1fbf9db939  cmp dword ptr [r15+0x318], 0x00
00007b1fbf9db941  jz 0x00007B1FBF9E1AB0
00007b1fbf9db947  nop [rax+rax*1], ax
00007b1fbf9db950  nop [rax+rax*1], eax
00007b1fbf9db958  mov eax, 0x410450
00007b1fbf9db95d  mov [r15+0x100], rax
00007b1fbf9db964  jmp 0x00007B1FBF7FE110
00007b1fbf9db969  cmp dword ptr [r15+0x318], 0x00
00007b1fbf9db971  jz 0x00007B1FBF9DB9A0
00007b1fbf9db977  nop [rax+rax*1], ax
00007b1fbf9db980  nop [rax+rax*1], eax
00007b1fbf9db988  mov eax, 0x410274
00007b1fbf9db98d  mov [r15+0x100], rax
00007b1fbf9db994  jmp 0x00007B1FBF7FE110
00007b1fbf9db999  int3
00007b1fbf9db99a  int3
00007b1fbf9db99b  nop [rax+rax*1], eax
00007b1fbf9db9a0  mov rax, [r15+0x40]
00007b1fbf9db9a4  movaps xmm1, [r15+0x1D0]
00007b1fbf9db9ac  vmovaps [rsp+0x10], xmm1
00007b1fbf9db9b2  vmovaps xmm15, [rsp+0x10]
00007b1fbf9db9b8  por xmm1, xmm15
00007b1fbf9db9bd  movaps xmm14, [r15+0x1A0]
00007b1fbf9db9c5  vmovaps [rsp+0x10], xmm14
00007b1fbf9db9cb  vmovaps xmm13, [rsp+0x10]
00007b1fbf9db9d1  por xmm14, xmm13
00007b1fbf9db9d6  lea r14, [rax+0x30]
00007b1fbf9db9da  mov r12, [r13+r14*1]
00007b1fbf9db9df  lea r14, [rax+0x38]
00007b1fbf9db9e3  mov r11, [r13+r14*1]
00007b1fbf9db9e8  movq xmm13, r12
00007b1fbf9db9ed  movq xmm12, r11
00007b1fbf9db9f2  movq xmm13, xmm13
00007b1fbf9db9f7  vmovaps [rsp+0x10], xmm13
00007b1fbf9db9fd  movq xmm13, xmm13
00007b1fbf9dba02  movaps [r15+0x130], xmm13
00007b1fbf9dba0a  movq xmm12, xmm12
00007b1fbf9dba0f  vmovaps [rsp+0x20], xmm12
00007b1fbf9dba15  movq xmm12, xmm12
00007b1fbf9dba1a  movaps [r15+0x280], xmm12
00007b1fbf9dba22  movaps xmm13, [r15+0x270]
00007b1fbf9dba2a  vmovaps [rsp+0x30], xmm13
00007b1fbf9dba30  vmovaps xmm12, [rsp+0x30]
00007b1fbf9dba36  por xmm13, xmm12
00007b1fbf9dba3b  lea r14, [rax+0x20]
00007b1fbf9dba3f  mov r12, [r13+r14*1]
00007b1fbf9dba44  lea r14, [rax+0x28]
00007b1fbf9dba48  mov r11, [r13+r14*1]
00007b1fbf9dba4d  movq xmm12, r12
00007b1fbf9dba52  movq xmm11, r11
00007b1fbf9dba57  movq xmm12, xmm12
00007b1fbf9dba5c  vmovaps [rsp+0x30], xmm12
00007b1fbf9dba62  movq xmm12, xmm12
00007b1fbf9dba67  movaps [r15+0x150], xmm12
00007b1fbf9dba6f  movq xmm11, xmm11
00007b1fbf9dba74  vmovaps [rsp+0x40], xmm11
00007b1fbf9dba7a  movq xmm11, xmm11
00007b1fbf9dba7f  movaps [r15+0x140], xmm11
00007b1fbf9dba87  lea r14, [rax+0x10]
00007b1fbf9dba8b  mov r12, [r13+r14*1]
00007b1fbf9dba90  lea r14, [rax+0x18]
00007b1fbf9dba94  mov r11, [r13+r14*1]
00007b1fbf9dba99  movq xmm12, r12
00007b1fbf9dba9e  movq xmm11, r11
00007b1fbf9dbaa3  movq xmm12, xmm12
00007b1fbf9dbaa8  vmovaps [rsp+0x50], xmm12
00007b1fbf9dbaae  movq xmm12, xmm12
00007b1fbf9dbab3  movaps [r15+0x170], xmm12
00007b1fbf9dbabb  movq xmm11, xmm11
00007b1fbf9dbac0  vmovaps [rsp+0x60], xmm11
00007b1fbf9dbac6  movq xmm11, xmm11
00007b1fbf9dbacb  movaps [r15+0x160], xmm11
00007b1fbf9dbad3  mov r14, [r13+rax*1]
00007b1fbf9dbad8  vmovq xmm12, r14
00007b1fbf9dbadd  vpbroadcastq xmm12, xmm12
00007b1fbf9dbae2  lea r14, [rax+0x08]
00007b1fbf9dbae6  mov rax, [r13+r14*1]
00007b1fbf9dbaeb  movq xmm11, rax
00007b1fbf9dbaf0  movaps [r15+0x230], xmm11
00007b1fbf9dbaf8  mov rax, [r15+0xF8]
00007b1fbf9dbaff  lea r14, [rax+0x50]
00007b1fbf9dbb03  movups xmm11, [r13+r14*1]
00007b1fbf9dbb09  lea r14, [rax+0x60]
00007b1fbf9dbb0d  movups xmm10, [r13+r14*1]
00007b1fbf9dbb13  lea r14, [rax+0x30]
00007b1fbf9dbb17  movups xmm9, [r13+r14*1]
00007b1fbf9dbb1d  mov r14, [r15+0x50]
00007b1fbf9dbb21  mov [r15+0x60], r14
00007b1fbf9dbb25  mov qword ptr [r15+0x58], 0x40
00007b1fbf9dbb2d  movaps xmm8, xmm12
00007b1fbf9dbb31  mulpd xmm8, xmm15
00007b1fbf9dbb36  vcmppd xmm7, xmm8, xmm8, 0x03
00007b1fbf9dbb3c  ptest xmm7, xmm7
00007b1fbf9dbb41  jnz 0x00007B1FBF9DC96A
00007b1fbf9dbb47  movq xmm15, qword ptr [r15+0x230]
00007b1fbf9dbb50  vmovaps [rsp+0x70], xmm15
00007b1fbf9dbb56  vpermilpd xmm15, xmm15, 0x00
00007b1fbf9dbb5c  movaps xmm7, xmm9
00007b1fbf9dbb60  mulpd xmm7, xmm15
00007b1fbf9dbb65  vcmppd xmm6, xmm7, xmm7, 0x03
00007b1fbf9dbb6a  ptest xmm6, xmm6
00007b1fbf9dbb6f  jnz 0x00007B1FBF9DCAAE
00007b1fbf9dbb75  vxorps xmm15, xmm15, xmm15
00007b1fbf9dbb7a  vpbroadcastq xmm15, xmm15
00007b1fbf9dbb7f  movaps xmm9, xmm12
00007b1fbf9dbb83  mulpd xmm9, xmm10
00007b1fbf9dbb88  vcmppd xmm6, xmm9, xmm9, 0x03
00007b1fbf9dbb8e  ptest xmm6, xmm6
00007b1fbf9dbb93  jnz 0x00007B1FBF9DCBF0
00007b1fbf9dbb99  movaps xmm10, xmm12
00007b1fbf9dbb9d  mulpd xmm10, xmm11
00007b1fbf9dbba2  vcmppd xmm6, xmm10, xmm10, 0x03
00007b1fbf9dbba8  ptest xmm6, xmm6
00007b1fbf9dbbad  jnz 0x00007B1FBF9DCD34
00007b1fbf9dbbb3  movaps xmm11, [r15+0x1F0]
00007b1fbf9dbbbb  movaps xmm6, xmm12
00007b1fbf9dbbbf  mulpd xmm6, xmm11
00007b1fbf9dbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
00007b1fbf9dbbc9  ptest xmm5, xmm5
00007b1fbf9dbbce  jnz 0x00007B1FBF9DCE78
00007b1fbf9dbbd4  movaps xmm12, [r15+0x2A0]
00007b1fbf9dbbdc  vmovaps [rsp+0x80], xmm12
00007b1fbf9dbbe5  vmovaps xmm11, [rsp+0x80]
00007b1fbf9dbbee  por xmm12, xmm11
00007b1fbf9dbbf3  movaps xmm11, [r15+0x250]
00007b1fbf9dbbfb  vmovaps [rsp+0x80], xmm11
00007b1fbf9dbc04  vmovaps xmm5, [rsp+0x80]
00007b1fbf9dbc0d  por xmm11, xmm5
00007b1fbf9dbc12  vmovaps xmm4, [rsp+0x70]
00007b1fbf9dbc18  vpermilpd xmm4, xmm4, 0x00
00007b1fbf9dbc1e  movaps xmm3, xmm5
00007b1fbf9dbc21  mulpd xmm3, xmm4
00007b1fbf9dbc25  vcmppd xmm2, xmm3, xmm3, 0x03
00007b1fbf9dbc2a  ptest xmm2, xmm2
00007b1fbf9dbc2f  jnz 0x00007B1FBF9DCFBA
00007b1fbf9dbc35  mov [rsp+0x80], rax
00007b1fbf9dbc3d  xor eax, eax
00007b1fbf9dbc3f  mov r12d, 0x40
00007b1fbf9dbc45  mov r11d, 0x200
00007b1fbf9dbc4b  cmp r12, r11
00007b1fbf9dbc4e  cmc
00007b1fbf9dbc4f  lahf
00007b1fbf9dbc50  seto al
00007b1fbf9dbc53  mov [r15+0x108], eax
00007b1fbf9dbc5a  movaps xmm5, xmm8
00007b1fbf9dbc5e  addpd xmm5, xmm15
00007b1fbf9dbc63  vcmppd xmm4, xmm5, xmm5, 0x03
00007b1fbf9dbc68  ptest xmm4, xmm4
00007b1fbf9dbc6d  jnz 0x00007B1FBF9DD0FA
00007b1fbf9dbc73  movaps xmm8, [r15+0x1B0]
00007b1fbf9dbc7b  movaps xmm4, xmm9
00007b1fbf9dbc7f  addpd xmm4, xmm8
00007b1fbf9dbc84  vcmppd xmm2, xmm4, xmm4, 0x03
00007b1fbf9dbc89  ptest xmm2, xmm2
00007b1fbf9dbc8e  jnz 0x00007B1FBF9DD23C
00007b1fbf9dbc94  movaps xmm9, xmm10
00007b1fbf9dbc98  addpd xmm9, xmm8
00007b1fbf9dbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
00007b1fbf9dbca3  ptest xmm2, xmm2
00007b1fbf9dbca8  jnz 0x00007B1FBF9DD37E
00007b1fbf9dbcae  movaps xmm10, [r15+0x2F0]
00007b1fbf9dbcb6  vmovaps [rsp+0x90], xmm10
00007b1fbf9dbcbf  vmovaps xmm8, [rsp+0x90]
00007b1fbf9dbcc8  por xmm10, xmm8
00007b1fbf9dbccd  movaps xmm8, [r15+0x2E0]
00007b1fbf9dbcd5  vmovaps [rsp+0x90], xmm8
00007b1fbf9dbcde  vmovaps xmm2, [rsp+0x90]
00007b1fbf9dbce7  por xmm8, xmm2
00007b1fbf9dbcec  movaps xmm2, [r15+0x2D0]
00007b1fbf9dbcf4  vmovaps [rsp+0x90], xmm2
00007b1fbf9dbcfd  vmovaps [rsp+0xA0], xmm1
00007b1fbf9dbd06  vmovaps xmm1, [rsp+0x90]
00007b1fbf9dbd0f  por xmm2, xmm1
00007b1fbf9dbd13  movaps xmm1, [r15+0x200]
00007b1fbf9dbd1b  vmovaps [rsp+0x90], xmm1
00007b1fbf9dbd24  vmovaps [rsp+0xB0], xmm15
00007b1fbf9dbd2d  vmovaps xmm15, [rsp+0x90]
00007b1fbf9dbd36  por xmm1, xmm15
00007b1fbf9dbd3b  movaps xmm15, [r15+0x1C0]
00007b1fbf9dbd43  vmovaps [rsp+0x90], xmm15
00007b1fbf9dbd4c  vmovaps [rsp+0xC0], xmm1
00007b1fbf9dbd55  vmovaps xmm1, [rsp+0x90]
00007b1fbf9dbd5e  por xmm15, xmm1
00007b1fbf9dbd63  movaps xmm1, [r15+0x190]
00007b1fbf9dbd6b  vmovaps [rsp+0x90], xmm1
00007b1fbf9dbd74  vmovaps [rsp+0xD0], xmm15
00007b1fbf9dbd7d  vmovaps xmm15, [rsp+0x90]
00007b1fbf9dbd86  por xmm1, xmm15
00007b1fbf9dbd8b  movaps xmm15, [r15+0x300]
00007b1fbf9dbd93  vmovaps [rsp+0x90], xmm15
00007b1fbf9dbd9c  vmovaps [rsp+0xE0], xmm1
00007b1fbf9dbda5  vmovaps xmm1, [rsp+0x90]
00007b1fbf9dbdae  por xmm15, xmm1
00007b1fbf9dbdb3  mov rax, [rsp+0x80]
00007b1fbf9dbdbb  lea r12, [rax+0xA0]
00007b1fbf9dbdc2  movups xmm1, [r13+r12*1]
00007b1fbf9dbdc8  lea r12, [rax+0xB0]
00007b1fbf9dbdcf  vmovaps [rsp+0x80], xmm1
00007b1fbf9dbdd8  movups xmm1, [r13+r12*1]
00007b1fbf9dbdde  vmovaps [rsp+0x90], xmm1
00007b1fbf9dbde7  vmovaps [rsp+0xF0], xmm15
00007b1fbf9dbdf0  vmovaps xmm15, [rsp+0xB0]
00007b1fbf9dbdf9  vmovaps [rsp+0xB0], xmm14
00007b1fbf9dbe02  movaps xmm1, xmm6
00007b1fbf9dbe05  addpd xmm1, xmm15
00007b1fbf9dbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
00007b1fbf9dbe0f  ptest xmm14, xmm14
00007b1fbf9dbe15  jnz 0x00007B1FBF9DD4D6
00007b1fbf9dbe1b  lea r12, [rax+0xF0]
00007b1fbf9dbe22  movups xmm15, [r13+r12*1]
00007b1fbf9dbe28  movaps xmm14, xmm4
00007b1fbf9dbe2c  addpd xmm14, xmm3
00007b1fbf9dbe31  vcmppd xmm6, xmm14, xmm14, 0x03
00007b1fbf9dbe37  ptest xmm6, xmm6
00007b1fbf9dbe3c  jnz 0x00007B1FBF9DD621
00007b1fbf9dbe42  movaps xmm6, xmm9
00007b1fbf9dbe46  addpd xmm6, xmm7
00007b1fbf9dbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
00007b1fbf9dbe4f  ptest xmm4, xmm4
00007b1fbf9dbe54  jnz 0x00007B1FBF9DD763
00007b1fbf9dbe5a  vmovaps xmm9, [rsp+0x70]
00007b1fbf9dbe60  vpermilpd xmm9, xmm9, 0x00
00007b1fbf9dbe66  vmovaps xmm4, [rsp+0x90]
00007b1fbf9dbe6f  movaps xmm7, xmm4
00007b1fbf9dbe72  mulpd xmm7, xmm9
00007b1fbf9dbe77  vcmppd xmm3, xmm7, xmm7, 0x03
00007b1fbf9dbe7c  ptest xmm3, xmm3
00007b1fbf9dbe81  jnz 0x00007B1FBF9DD8A4
00007b1fbf9dbe87  vmovaps xmm9, [rsp+0x50]
00007b1fbf9dbe8d  vpermilpd xmm9, xmm9, 0x00
00007b1fbf9dbe93  movaps xmm4, xmm15
00007b1fbf9dbe97  mulpd xmm4, xmm9
00007b1fbf9dbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
00007b1fbf9dbea1  ptest xmm3, xmm3
00007b1fbf9dbea6  jnz 0x00007B1FBF9DD9E5
00007b1fbf9dbeac  lea r12, [rax+0xE0]
00007b1fbf9dbeb3  movups xmm15, [r13+r12*1]
00007b1fbf9dbeb9  vmovaps xmm9, [rsp+0x70]
00007b1fbf9dbebf  vpermilpd xmm9, xmm9, 0x00
00007b1fbf9dbec5  vmovaps [rsp+0x70], xmm1
00007b1fbf9dbecb  vmovaps xmm1, [rsp+0x80]
00007b1fbf9dbed4  vmovaps [rsp+0x80], xmm15
00007b1fbf9dbedd  movaps xmm3, xmm1
00007b1fbf9dbee0  mulpd xmm3, xmm9
00007b1fbf9dbee5  vcmppd xmm15, xmm3, xmm3, 0x03
00007b1fbf9dbeea  ptest xmm15, xmm15
00007b1fbf9dbef0  jnz 0x00007B1FBF9DDB31
00007b1fbf9dbef6  vmovaps xmm1, [rsp+0xF0]
00007b1fbf9dbeff  vmovaps xmm15, [rsp+0xF0]
00007b1fbf9dbf08  por xmm1, xmm15
00007b1fbf9dbf0d  movaps [r15+0x300], xmm1
00007b1fbf9dbf15  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9dbf1e  vmovaps xmm9, [rsp+0xE0]
00007b1fbf9dbf27  por xmm15, xmm9
00007b1fbf9dbf2c  movaps [r15+0x190], xmm15
00007b1fbf9dbf34  vmovaps xmm9, [rsp+0x50]
00007b1fbf9dbf3a  vpermilpd xmm9, xmm9, 0x00
00007b1fbf9dbf40  vmovaps [rsp+0x90], xmm1
00007b1fbf9dbf49  vmovaps [rsp+0xE0], xmm15
00007b1fbf9dbf52  vmovaps xmm15, [rsp+0x80]
00007b1fbf9dbf5b  vmovaps [rsp+0x80], xmm14
00007b1fbf9dbf64  movaps xmm1, xmm15
00007b1fbf9dbf68  mulpd xmm1, xmm9
00007b1fbf9dbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
00007b1fbf9dbf72  ptest xmm14, xmm14
00007b1fbf9dbf78  jnz 0x00007B1FBF9DDC72
00007b1fbf9dbf7e  lea r12, [rax+0x90]
00007b1fbf9dbf85  movups xmm15, [r13+r12*1]
00007b1fbf9dbf8b  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9dbf94  vmovaps xmm9, [rsp+0xD0]
00007b1fbf9dbf9d  por xmm14, xmm9
00007b1fbf9dbfa2  movaps [r15+0x1C0], xmm14
00007b1fbf9dbfaa  vmovaps xmm9, [rsp+0xC0]
00007b1fbf9dbfb3  vmovaps [rsp+0xD0], xmm1
00007b1fbf9dbfbc  vmovaps xmm1, [rsp+0xC0]
00007b1fbf9dbfc5  por xmm9, xmm1
00007b1fbf9dbfca  movaps [r15+0x200], xmm9
00007b1fbf9dbfd2  vmovaps [rsp+0xC0], xmm2
00007b1fbf9dbfdb  vmovaps xmm1, [rsp+0xC0]
00007b1fbf9dbfe4  por xmm2, xmm1
00007b1fbf9dbfe8  movaps [r15+0x2D0], xmm2
00007b1fbf9dbff0  vmovaps [rsp+0xC0], xmm8
00007b1fbf9dbff9  vmovaps xmm1, [rsp+0xC0]
00007b1fbf9dc002  por xmm8, xmm1
00007b1fbf9dc007  movaps [r15+0x2E0], xmm8
00007b1fbf9dc00f  vmovaps [rsp+0xC0], xmm15
00007b1fbf9dc018  movaps xmm1, xmm5
00007b1fbf9dc01b  addpd xmm1, xmm7
00007b1fbf9dc01f  vcmppd xmm15, xmm1, xmm1, 0x03
00007b1fbf9dc024  ptest xmm15, xmm15
00007b1fbf9dc02a  jnz 0x00007B1FBF9DDDBE
00007b1fbf9dc030  vmovaps xmm15, [rsp+0x50]
00007b1fbf9dc036  vpermilpd xmm15, xmm15, 0x00
00007b1fbf9dc03c  vmovaps xmm5, [rsp+0xC0]
00007b1fbf9dc045  vmovaps [rsp+0xC0], xmm1
00007b1fbf9dc04e  movaps xmm7, xmm5
00007b1fbf9dc051  mulpd xmm7, xmm15
00007b1fbf9dc056  vcmppd xmm1, xmm7, xmm7, 0x03
00007b1fbf9dc05b  ptest xmm1, xmm1
00007b1fbf9dc060  jnz 0x00007B1FBF9DDEFE
00007b1fbf9dc066  lea r12, [rax+0x80]
00007b1fbf9dc06d  movups xmm1, [r13+r12*1]
00007b1fbf9dc073  vmovaps xmm5, [rsp+0x70]
00007b1fbf9dc079  vmovaps [rsp+0x70], xmm1
00007b1fbf9dc07f  movaps xmm15, xmm5
00007b1fbf9dc083  addpd xmm15, xmm3
00007b1fbf9dc088  vcmppd xmm1, xmm15, xmm15, 0x03
00007b1fbf9dc08e  ptest xmm1, xmm1
00007b1fbf9dc093  jnz 0x00007B1FBF9DE049
00007b1fbf9dc099  vmovaps xmm5, [rsp+0x80]
00007b1fbf9dc0a2  movaps xmm1, xmm5
00007b1fbf9dc0a5  addpd xmm1, xmm4
00007b1fbf9dc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
00007b1fbf9dc0ae  ptest xmm3, xmm3
00007b1fbf9dc0b3  jnz 0x00007B1FBF9DE18B
00007b1fbf9dc0b9  vmovaps [rsp+0x80], xmm10
00007b1fbf9dc0c2  vmovaps xmm5, [rsp+0x80]
00007b1fbf9dc0cb  por xmm10, xmm5
00007b1fbf9dc0d0  movaps [r15+0x2F0], xmm10
00007b1fbf9dc0d8  vmovaps xmm5, [rsp+0x50]
00007b1fbf9dc0de  vpermilpd xmm5, xmm5, 0x00
00007b1fbf9dc0e4  vmovaps xmm3, [rsp+0x70]
00007b1fbf9dc0ea  vmovaps [rsp+0x50], xmm1
00007b1fbf9dc0f0  movaps xmm4, xmm3
00007b1fbf9dc0f3  mulpd xmm4, xmm5
00007b1fbf9dc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
00007b1fbf9dc0fc  ptest xmm1, xmm1
00007b1fbf9dc101  jnz 0x00007B1FBF9DE2CB
00007b1fbf9dc107  lea r12, [rax+0xD0]
00007b1fbf9dc10e  movups xmm1, [r13+r12*1]
00007b1fbf9dc114  vmovaps xmm3, [rsp+0xD0]
00007b1fbf9dc11d  vmovaps [rsp+0x70], xmm1
00007b1fbf9dc123  movaps xmm5, xmm6
00007b1fbf9dc126  addpd xmm5, xmm3
00007b1fbf9dc12a  vcmppd xmm1, xmm5, xmm5, 0x03
00007b1fbf9dc12f  ptest xmm1, xmm1
00007b1fbf9dc134  jnz 0x00007B1FBF9DE415
00007b1fbf9dc13a  vmovaps xmm1, [rsp+0x60]
00007b1fbf9dc140  vpermilpd xmm1, xmm1, 0x00
00007b1fbf9dc146  movaps xmm6, xmm9
00007b1fbf9dc14a  mulpd xmm6, xmm1
00007b1fbf9dc14e  vcmppd xmm3, xmm6, xmm6, 0x03
00007b1fbf9dc153  ptest xmm3, xmm3
00007b1fbf9dc158  jnz 0x00007B1FBF9DE555
00007b1fbf9dc15e  movaps [r15+0x260], xmm6
00007b1fbf9dc166  vxorps xmm1, xmm1, xmm1
00007b1fbf9dc16a  vpbroadcastq xmm1, xmm1
00007b1fbf9dc16f  movaps [r15+0x1B0], xmm1
00007b1fbf9dc177  vmovaps xmm1, [rsp+0x60]
00007b1fbf9dc17d  vpermilpd xmm1, xmm1, 0x00
00007b1fbf9dc183  vmovaps xmm3, [rsp+0x70]
00007b1fbf9dc189  vmovaps [rsp+0x70], xmm15
00007b1fbf9dc18f  movaps xmm9, xmm3
00007b1fbf9dc193  mulpd xmm9, xmm1
00007b1fbf9dc198  vcmppd xmm15, xmm9, xmm9, 0x03
00007b1fbf9dc19e  ptest xmm15, xmm15
00007b1fbf9dc1a4  jnz 0x00007B1FBF9DE696
00007b1fbf9dc1aa  lea r12, [rax+0xC0]
00007b1fbf9dc1b1  movups xmm1, [r13+r12*1]
00007b1fbf9dc1b7  vmovaps xmm3, [rsp+0xC0]
00007b1fbf9dc1c0  vmovaps [rsp+0x80], xmm1
00007b1fbf9dc1c9  movaps xmm15, xmm3
00007b1fbf9dc1cd  addpd xmm15, xmm7
00007b1fbf9dc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
00007b1fbf9dc1d8  ptest xmm1, xmm1
00007b1fbf9dc1dd  jnz 0x00007B1FBF9DE7E2
00007b1fbf9dc1e3  vmovaps [rsp+0xC0], xmm13
00007b1fbf9dc1ec  vmovaps xmm1, [rsp+0xC0]
00007b1fbf9dc1f5  por xmm13, xmm1
00007b1fbf9dc1fa  movaps [r15+0x270], xmm13
00007b1fbf9dc202  vmovaps xmm1, [rsp+0xB0]
00007b1fbf9dc20b  vmovaps xmm7, [rsp+0xB0]
00007b1fbf9dc214  por xmm1, xmm7
00007b1fbf9dc218  movaps [r15+0x1A0], xmm1
00007b1fbf9dc220  vmovaps xmm1, [rsp+0x60]
00007b1fbf9dc226  vpermilpd xmm1, xmm1, 0x00
00007b1fbf9dc22c  vmovaps [rsp+0xB0], xmm1
00007b1fbf9dc235  vmovaps xmm1, [rsp+0x80]
00007b1fbf9dc23e  vmovaps [rsp+0x80], xmm15
00007b1fbf9dc247  vmovaps xmm15, [rsp+0xB0]
00007b1fbf9dc250  vmovaps [rsp+0xB0], xmm14
00007b1fbf9dc259  movaps xmm3, xmm1
00007b1fbf9dc25c  mulpd xmm3, xmm15
00007b1fbf9dc261  vcmppd xmm14, xmm3, xmm3, 0x03
00007b1fbf9dc266  ptest xmm14, xmm14
00007b1fbf9dc26c  jnz 0x00007B1FBF9DE924
00007b1fbf9dc272  lea r12, [rax+0x20]
00007b1fbf9dc276  movups xmm1, [r13+r12*1]
00007b1fbf9dc27c  movaps [r15+0x110], xmm1
00007b1fbf9dc284  vmovaps xmm14, [rsp+0x70]
00007b1fbf9dc28a  vmovaps [rsp+0x70], xmm1
00007b1fbf9dc290  movaps xmm15, xmm14
00007b1fbf9dc294  addpd xmm15, xmm4
00007b1fbf9dc299  vcmppd xmm1, xmm15, xmm15, 0x03
00007b1fbf9dc29f  ptest xmm1, xmm1
00007b1fbf9dc2a4  jnz 0x00007B1FBF9DEA6F
00007b1fbf9dc2aa  vmovaps xmm1, [rsp+0x60]
00007b1fbf9dc2b0  vpermilpd xmm1, xmm1, 0x00
00007b1fbf9dc2b6  movaps xmm14, xmm2
00007b1fbf9dc2ba  mulpd xmm14, xmm1
00007b1fbf9dc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
00007b1fbf9dc2c5  ptest xmm4, xmm4
00007b1fbf9dc2ca  jnz 0x00007B1FBF9DEBB2
00007b1fbf9dc2d0  vmovaps xmm4, [rsp+0x50]
00007b1fbf9dc2d6  movaps xmm1, xmm4
00007b1fbf9dc2d9  addpd xmm1, xmm9
00007b1fbf9dc2de  vcmppd xmm2, xmm1, xmm1, 0x03
00007b1fbf9dc2e3  ptest xmm2, xmm2
00007b1fbf9dc2e8  jnz 0x00007B1FBF9DECF4
00007b1fbf9dc2ee  vmovaps xmm9, [rsp+0x30]
00007b1fbf9dc2f4  vpermilpd xmm9, xmm9, 0x00
00007b1fbf9dc2fa  vmovaps xmm2, [rsp+0x70]
00007b1fbf9dc300  vmovaps [rsp+0x50], xmm1
00007b1fbf9dc306  movaps xmm4, xmm2
00007b1fbf9dc309  mulpd xmm4, xmm9
00007b1fbf9dc30e  vcmppd xmm1, xmm4, xmm4, 0x03
00007b1fbf9dc313  ptest xmm1, xmm1
00007b1fbf9dc318  jnz 0x00007B1FBF9DEE35
00007b1fbf9dc31e  vmovaps xmm1, [rsp+0x30]
00007b1fbf9dc324  vpermilpd xmm1, xmm1, 0x00
00007b1fbf9dc32a  vmovaps xmm2, [rsp+0x90]
00007b1fbf9dc333  vmovaps [rsp+0x60], xmm15
00007b1fbf9dc339  movaps xmm9, xmm2
00007b1fbf9dc33d  mulpd xmm9, xmm1
00007b1fbf9dc342  vcmppd xmm15, xmm9, xmm9, 0x03
00007b1fbf9dc348  ptest xmm15, xmm15
00007b1fbf9dc34e  jnz 0x00007B1FBF9DEF76
00007b1fbf9dc354  vmovaps xmm15, [rsp+0x80]
00007b1fbf9dc35d  movaps xmm1, xmm15
00007b1fbf9dc361  addpd xmm1, xmm6
00007b1fbf9dc365  vcmppd xmm2, xmm1, xmm1, 0x03
00007b1fbf9dc36a  ptest xmm2, xmm2
00007b1fbf9dc36f  jnz 0x00007B1FBF9DF0B8
00007b1fbf9dc375  movaps xmm15, xmm5
00007b1fbf9dc379  addpd xmm15, xmm3
00007b1fbf9dc37e  vcmppd xmm6, xmm15, xmm15, 0x03
00007b1fbf9dc384  ptest xmm6, xmm6
00007b1fbf9dc389  jnz 0x00007B1FBF9DF1F9
00007b1fbf9dc38f  vmovaps xmm6, [rsp+0x30]
00007b1fbf9dc395  vpermilpd xmm6, xmm6, 0x00
00007b1fbf9dc39b  movaps xmm5, xmm8
00007b1fbf9dc39f  mulpd xmm5, xmm6
00007b1fbf9dc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
00007b1fbf9dc3a8  ptest xmm3, xmm3
00007b1fbf9dc3ad  jnz 0x00007B1FBF9DF33B
00007b1fbf9dc3b3  vmovaps xmm8, [rsp+0x30]
00007b1fbf9dc3b9  vpermilpd xmm8, xmm8, 0x00
00007b1fbf9dc3bf  movaps xmm6, xmm10
00007b1fbf9dc3c3  mulpd xmm6, xmm8
00007b1fbf9dc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
00007b1fbf9dc3cd  ptest xmm3, xmm3
00007b1fbf9dc3d2  jnz 0x00007B1FBF9DF47C
00007b1fbf9dc3d8  vmovaps xmm8, [rsp+0x60]
00007b1fbf9dc3de  movaps xmm10, xmm8
00007b1fbf9dc3e2  addpd xmm10, xmm14
00007b1fbf9dc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
00007b1fbf9dc3ed  ptest xmm3, xmm3
00007b1fbf9dc3f2  jnz 0x00007B1FBF9DF5BE
00007b1fbf9dc3f8  vmovaps xmm8, [rsp+0x50]
00007b1fbf9dc3fe  movaps xmm14, xmm8
00007b1fbf9dc402  addpd xmm14, xmm4
00007b1fbf9dc407  vcmppd xmm3, xmm14, xmm14, 0x03
00007b1fbf9dc40d  ptest xmm3, xmm3
00007b1fbf9dc412  jnz 0x00007B1FBF9DF702
00007b1fbf9dc418  vmovaps xmm8, [rsp+0x40]
00007b1fbf9dc41e  vpermilpd xmm8, xmm8, 0x00
00007b1fbf9dc424  movaps xmm4, xmm13
00007b1fbf9dc428  mulpd xmm4, xmm8
00007b1fbf9dc42d  vcmppd xmm3, xmm4, xmm4, 0x03
00007b1fbf9dc432  ptest xmm3, xmm3
00007b1fbf9dc437  jnz 0x00007B1FBF9DF845
00007b1fbf9dc43d  movaps xmm13, xmm15
00007b1fbf9dc441  addpd xmm13, xmm9
00007b1fbf9dc446  vcmppd xmm8, xmm13, xmm13, 0x03
00007b1fbf9dc44c  ptest xmm8, xmm8
00007b1fbf9dc452  jnz 0x00007B1FBF9DF987
00007b1fbf9dc458  movaps xmm15, xmm1
00007b1fbf9dc45c  addpd xmm15, xmm5
00007b1fbf9dc461  vcmppd xmm9, xmm15, xmm15, 0x03
00007b1fbf9dc467  ptest xmm9, xmm9
00007b1fbf9dc46d  jnz 0x00007B1FBF9DFACB
00007b1fbf9dc473  vmovaps [rsp+0x30], xmm11
00007b1fbf9dc479  vmovaps xmm1, [rsp+0x30]
00007b1fbf9dc47f  por xmm11, xmm1
00007b1fbf9dc484  movaps [r15+0x250], xmm11
00007b1fbf9dc48c  vmovaps [rsp+0x30], xmm12
00007b1fbf9dc492  vmovaps xmm1, [rsp+0x30]
00007b1fbf9dc498  por xmm12, xmm1
00007b1fbf9dc49d  movaps [r15+0x2A0], xmm12
00007b1fbf9dc4a5  vmovaps xmm1, [rsp+0xA0]
00007b1fbf9dc4ae  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9dc4b7  por xmm1, xmm11
00007b1fbf9dc4bc  movaps [r15+0x1D0], xmm1
00007b1fbf9dc4c4  lea r12, [rax+0x40]
00007b1fbf9dc4c8  movups xmm1, [r13+r12*1]
00007b1fbf9dc4ce  movaps [r15+0x2C0], xmm1
00007b1fbf9dc4d6  vmovaps xmm11, [rsp+0x40]
00007b1fbf9dc4dc  vpermilpd xmm11, xmm11, 0x00
00007b1fbf9dc4e2  vmovaps xmm8, [rsp+0xE0]
00007b1fbf9dc4eb  movaps xmm9, xmm8
00007b1fbf9dc4ef  mulpd xmm9, xmm11
00007b1fbf9dc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
00007b1fbf9dc4fa  ptest xmm5, xmm5
00007b1fbf9dc4ff  jnz 0x00007B1FBF9DFC17
00007b1fbf9dc505  movaps xmm11, xmm10
00007b1fbf9dc509  addpd xmm11, xmm6
00007b1fbf9dc50e  vcmppd xmm8, xmm11, xmm11, 0x03
00007b1fbf9dc514  ptest xmm8, xmm8
00007b1fbf9dc51a  jnz 0x00007B1FBF9DFD5B
00007b1fbf9dc520  movaps xmm10, xmm14
00007b1fbf9dc524  addpd xmm10, xmm4
00007b1fbf9dc529  vcmppd xmm8, xmm10, xmm10, 0x03
00007b1fbf9dc52f  ptest xmm8, xmm8
00007b1fbf9dc535  jnz 0x00007B1FBF9DFE9E
00007b1fbf9dc53b  vmovaps xmm14, [rsp+0x40]
00007b1fbf9dc541  vpermilpd xmm14, xmm14, 0x00
00007b1fbf9dc547  movaps xmm8, xmm1
00007b1fbf9dc54b  mulpd xmm8, xmm14
00007b1fbf9dc550  vcmppd xmm6, xmm8, xmm8, 0x03
00007b1fbf9dc556  ptest xmm6, xmm6
00007b1fbf9dc55b  jnz 0x00007B1FBF9DFFE1
00007b1fbf9dc561  movaps xmm1, [r15+0x2B0]
00007b1fbf9dc569  vmovaps xmm14, [rsp+0x40]
00007b1fbf9dc56f  vpermilpd xmm14, xmm14, 0x00
00007b1fbf9dc575  movaps xmm6, xmm1
00007b1fbf9dc578  mulpd xmm6, xmm14
00007b1fbf9dc57d  vcmppd xmm5, xmm6, xmm6, 0x03
00007b1fbf9dc582  ptest xmm5, xmm5
00007b1fbf9dc587  jnz 0x00007B1FBF9E0124
00007b1fbf9dc58d  vmovaps xmm1, [rsp+0x10]
00007b1fbf9dc593  vpermilpd xmm1, xmm1, 0x00
00007b1fbf9dc599  movaps xmm14, xmm12
00007b1fbf9dc59d  mulpd xmm14, xmm1
00007b1fbf9dc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
00007b1fbf9dc5a8  ptest xmm5, xmm5
00007b1fbf9dc5ad  jnz 0x00007B1FBF9E0265
00007b1fbf9dc5b3  movaps xmm1, xmm13
00007b1fbf9dc5b7  addpd xmm1, xmm9
00007b1fbf9dc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
00007b1fbf9dc5c1  ptest xmm12, xmm12
00007b1fbf9dc5c7  jnz 0x00007B1FBF9E03A8
00007b1fbf9dc5cd  vmovaps xmm13, [rsp+0x10]
00007b1fbf9dc5d3  vpermilpd xmm13, xmm13, 0x00
00007b1fbf9dc5d9  movaps xmm12, xmm7
00007b1fbf9dc5dd  mulpd xmm12, xmm13
00007b1fbf9dc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
00007b1fbf9dc5e8  ptest xmm9, xmm9
00007b1fbf9dc5ee  jnz 0x00007B1FBF9E04EA
00007b1fbf9dc5f4  movaps xmm13, xmm15
00007b1fbf9dc5f8  addpd xmm13, xmm8
00007b1fbf9dc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
00007b1fbf9dc603  ptest xmm9, xmm9
00007b1fbf9dc609  jnz 0x00007B1FBF9E062D
00007b1fbf9dc60f  movaps xmm15, [r15+0x290]
00007b1fbf9dc617  vmovaps xmm9, [rsp+0x10]
00007b1fbf9dc61d  vpermilpd xmm9, xmm9, 0x00
00007b1fbf9dc623  movaps xmm8, xmm15
00007b1fbf9dc627  mulpd xmm8, xmm9
00007b1fbf9dc62c  vcmppd xmm7, xmm8, xmm8, 0x03
00007b1fbf9dc632  ptest xmm7, xmm7
00007b1fbf9dc637  jnz 0x00007B1FBF9E0771
00007b1fbf9dc63d  movaps xmm15, xmm11
00007b1fbf9dc641  addpd xmm15, xmm6
00007b1fbf9dc646  vcmppd xmm9, xmm15, xmm15, 0x03
00007b1fbf9dc64c  ptest xmm9, xmm9
00007b1fbf9dc652  jnz 0x00007B1FBF9E08B5
00007b1fbf9dc658  movaps xmm11, [r15+0x1E0]
00007b1fbf9dc660  vmovaps xmm9, [rsp+0x10]
00007b1fbf9dc666  vpermilpd xmm9, xmm9, 0x00
00007b1fbf9dc66c  movaps xmm7, xmm11
00007b1fbf9dc670  mulpd xmm7, xmm9
00007b1fbf9dc675  vcmppd xmm6, xmm7, xmm7, 0x03
00007b1fbf9dc67a  ptest xmm6, xmm6
00007b1fbf9dc67f  jnz 0x00007B1FBF9E09F8
00007b1fbf9dc685  movaps xmm11, xmm10
00007b1fbf9dc689  addpd xmm11, xmm14
00007b1fbf9dc68e  vcmppd xmm9, xmm11, xmm11, 0x03
00007b1fbf9dc694  ptest xmm9, xmm9
00007b1fbf9dc69a  jnz 0x00007B1FBF9E0B3A
00007b1fbf9dc6a0  lea r12, [rax+0x70]
00007b1fbf9dc6a4  movups xmm14, [r13+r12*1]
00007b1fbf9dc6aa  movaps [r15+0x240], xmm14
00007b1fbf9dc6b2  movaps xmm10, xmm1
00007b1fbf9dc6b6  addpd xmm10, xmm12
00007b1fbf9dc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
00007b1fbf9dc6c1  ptest xmm9, xmm9
00007b1fbf9dc6c7  jnz 0x00007B1FBF9E0C88
00007b1fbf9dc6cd  movaps [r15+0x170], xmm10
00007b1fbf9dc6d5  vmovaps xmm1, [rsp+0x20]
00007b1fbf9dc6db  vpermilpd xmm1, xmm1, 0x00
00007b1fbf9dc6e1  movaps xmm12, xmm14
00007b1fbf9dc6e5  mulpd xmm12, xmm1
00007b1fbf9dc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
00007b1fbf9dc6f0  ptest xmm9, xmm9
00007b1fbf9dc6f6  jnz 0x00007B1FBF9E0DCB
00007b1fbf9dc6fc  vmovaps xmm1, [rsp+0x20]
00007b1fbf9dc702  vpermilpd xmm1, xmm1, 0x00
00007b1fbf9dc708  vmovaps xmm9, [rsp+0xB0]
00007b1fbf9dc711  movaps xmm14, xmm9
00007b1fbf9dc715  mulpd xmm14, xmm1
00007b1fbf9dc71a  vcmppd xmm6, xmm14, xmm14, 0x03
00007b1fbf9dc720  ptest xmm6, xmm6
00007b1fbf9dc725  jnz 0x00007B1FBF9E0F0E
00007b1fbf9dc72b  movaps [r15+0x180], xmm14
00007b1fbf9dc733  movaps xmm1, xmm13
00007b1fbf9dc737  addpd xmm1, xmm8
00007b1fbf9dc73c  vcmppd xmm9, xmm1, xmm1, 0x03
00007b1fbf9dc741  ptest xmm9, xmm9
00007b1fbf9dc747  jnz 0x00007B1FBF9E1051
00007b1fbf9dc74d  movaps [r15+0x210], xmm1
00007b1fbf9dc755  movups xmm13, [r13+rax*1]
00007b1fbf9dc75b  lea r12, [rax+0x10]
00007b1fbf9dc75f  movups xmm9, [r13+r12*1]
00007b1fbf9dc765  movaps [r15+0x230], xmm9
00007b1fbf9dc76d  movaps xmm8, xmm15
00007b1fbf9dc771  addpd xmm8, xmm7
00007b1fbf9dc776  vcmppd xmm6, xmm8, xmm8, 0x03
00007b1fbf9dc77c  ptest xmm6, xmm6
00007b1fbf9dc781  jnz 0x00007B1FBF9E11A7
00007b1fbf9dc787  movaps [r15+0x130], xmm8
00007b1fbf9dc78f  vmovaps xmm15, [rsp+0x20]
00007b1fbf9dc795  vpermilpd xmm15, xmm15, 0x00
00007b1fbf9dc79b  movaps xmm7, xmm9
00007b1fbf9dc79f  mulpd xmm7, xmm15
00007b1fbf9dc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
00007b1fbf9dc7a9  ptest xmm6, xmm6
00007b1fbf9dc7ae  jnz 0x00007B1FBF9E12EA
00007b1fbf9dc7b4  movaps [r15+0x220], xmm7
00007b1fbf9dc7bc  vmovaps xmm15, [rsp+0x20]
00007b1fbf9dc7c2  vpermilpd xmm15, xmm15, 0x00
00007b1fbf9dc7c8  movaps xmm9, xmm13
00007b1fbf9dc7cc  mulpd xmm9, xmm15
00007b1fbf9dc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
00007b1fbf9dc7d7  ptest xmm6, xmm6
00007b1fbf9dc7dc  jnz 0x00007B1FBF9E142C
00007b1fbf9dc7e2  movaps xmm15, xmm11
00007b1fbf9dc7e6  addpd xmm15, xmm12
00007b1fbf9dc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
00007b1fbf9dc7f1  ptest xmm13, xmm13
00007b1fbf9dc7f7  jnz 0x00007B1FBF9E1570
00007b1fbf9dc7fd  movaps [r15+0x140], xmm15
00007b1fbf9dc805  movaps xmm13, xmm10
00007b1fbf9dc809  addpd xmm13, xmm14
00007b1fbf9dc80e  vcmppd xmm12, xmm13, xmm13, 0x03
00007b1fbf9dc814  ptest xmm12, xmm12
00007b1fbf9dc81a  jnz 0x00007B1FBF9E16B4
00007b1fbf9dc820  movaps [r15+0x150], xmm13
00007b1fbf9dc828  movaps xmm14, xmm1
00007b1fbf9dc82c  addpd xmm14, xmm7
00007b1fbf9dc831  vcmppd xmm12, xmm14, xmm14, 0x03
00007b1fbf9dc837  ptest xmm12, xmm12
00007b1fbf9dc83d  jnz 0x00007B1FBF9E17F8
00007b1fbf9dc843  movaps [r15+0x160], xmm14
00007b1fbf9dc84b  movaps xmm1, xmm8
00007b1fbf9dc84f  addpd xmm1, xmm9
00007b1fbf9dc854  vcmppd xmm12, xmm1, xmm1, 0x03
00007b1fbf9dc859  ptest xmm12, xmm12
00007b1fbf9dc85f  jnz 0x00007B1FBF9E193A
00007b1fbf9dc865  movaps [r15+0x120], xmm1
00007b1fbf9dc86d  movups [r13+r14*1], xmm15
00007b1fbf9dc873  lea rax, [r14+0x10]
00007b1fbf9dc877  movups [r13+rax*1], xmm13
00007b1fbf9dc87d  lea rax, [r14+0x20]
00007b1fbf9dc881  movups [r13+rax*1], xmm14
00007b1fbf9dc887  lea rax, [r14+0x30]
00007b1fbf9dc88b  movups [r13+rax*1], xmm1
00007b1fbf9dc891  mov eax, [r15+0x108]
00007b1fbf9dc898  sahf
00007b1fbf9dc899  jnz 0x00007B1FBF9DC8CB
00007b1fbf9dc89b  cmp dword ptr [r15+0x318], 0x00
00007b1fbf9dc8a3  jz 0x00007B1FBF9DB900
00007b1fbf9dc8a9  nop [rax+rax*1], ax
00007b1fbf9dc8b2  nop [rax+rax*1], eax
00007b1fbf9dc8ba  mov eax, 0x410444
00007b1fbf9dc8bf  mov [r15+0x100], rax
00007b1fbf9dc8c6  jmp 0x00007B1FBF7FE110
00007b1fbf9dc8cb  cmp dword ptr [r15+0x318], 0x00
00007b1fbf9dc8d3  jz 0x00007B1FBF9D57E0
00007b1fbf9dc8d9  nop [rax+rax*1], ax
00007b1fbf9dc8e2  nop [rax+rax*1], eax
00007b1fbf9dc8ea  mov eax, 0x410278
00007b1fbf9dc8ef  mov [r15+0x100], rax
00007b1fbf9dc8f6  jmp 0x00007B1FBF7FE110
00007b1fbf9dc8fb  int3
00007b1fbf9dc8fc  call 0x00007B1FBF8E27E0
00007b1fbf9dc901  jmp 0x00007B1FBF9DB9DF
00007b1fbf9dc906  call 0x00007B1FBF8E1570
00007b1fbf9dc90b  jmp 0x00007B1FBF9DB9E8
00007b1fbf9dc910  call 0x00007B1FBF8E27E0
00007b1fbf9dc915  jmp 0x00007B1FBF9DBA44
00007b1fbf9dc91a  call 0x00007B1FBF8E1570
00007b1fbf9dc91f  jmp 0x00007B1FBF9DBA4D
00007b1fbf9dc924  call 0x00007B1FBF8E27E0
00007b1fbf9dc929  jmp 0x00007B1FBF9DBA90
00007b1fbf9dc92e  call 0x00007B1FBF8E1570
00007b1fbf9dc933  jmp 0x00007B1FBF9DBA99
00007b1fbf9dc938  call 0x00007B1FBF80DC20
00007b1fbf9dc93d  jmp 0x00007B1FBF9DBAD8
00007b1fbf9dc942  call 0x00007B1FBF8D59C0
00007b1fbf9dc947  jmp 0x00007B1FBF9DBAEB
00007b1fbf9dc94c  call 0x00007B1FBF8E0E30
00007b1fbf9dc951  jmp 0x00007B1FBF9DBB09
00007b1fbf9dc956  call 0x00007B1FBF8DFBC0
00007b1fbf9dc95b  jmp 0x00007B1FBF9DBB13
00007b1fbf9dc960  call 0x00007B1FBF8DE950
00007b1fbf9dc965  jmp 0x00007B1FBF9DBB1D
00007b1fbf9dc96a  sub rsp, 0x08
00007b1fbf9dc96e  push rax
00007b1fbf9dc96f  push rcx
00007b1fbf9dc970  push rdx
00007b1fbf9dc971  push rdi
00007b1fbf9dc972  push rsi
00007b1fbf9dc973  push r8
00007b1fbf9dc975  push r9
00007b1fbf9dc977  push r10
00007b1fbf9dc979  push r11
00007b1fbf9dc97b  sub rsp, 0xF0
00007b1fbf9dc982  vmovaps [rsp], xmm0
00007b1fbf9dc987  vmovaps [rsp+0x10], xmm1
00007b1fbf9dc98d  vmovaps [rsp+0x20], xmm2
00007b1fbf9dc993  vmovaps [rsp+0x30], xmm3
00007b1fbf9dc999  vmovaps [rsp+0x40], xmm4
00007b1fbf9dc99f  vmovaps [rsp+0x50], xmm5
00007b1fbf9dc9a5  vmovaps [rsp+0x60], xmm6
00007b1fbf9dc9ab  vmovaps [rsp+0x70], xmm7
00007b1fbf9dc9b1  vmovaps [rsp+0x80], xmm9
00007b1fbf9dc9ba  vmovaps [rsp+0x90], xmm10
00007b1fbf9dc9c3  vmovaps [rsp+0xA0], xmm11
00007b1fbf9dc9cc  vmovaps [rsp+0xB0], xmm12
00007b1fbf9dc9d5  vmovaps [rsp+0xC0], xmm13
00007b1fbf9dc9de  vmovaps [rsp+0xD0], xmm14
00007b1fbf9dc9e7  vmovaps [rsp+0xE0], xmm15
00007b1fbf9dc9f0  sub rsp, 0x30
00007b1fbf9dc9f4  movaps [rsp], xmm8
00007b1fbf9dc9f9  movaps [rsp+0x10], xmm12
00007b1fbf9dc9ff  movaps [rsp+0x20], xmm15
00007b1fbf9dca05  lea rdi, [rsp]
00007b1fbf9dca09  mov esi, 0x00
00007b1fbf9dca0e  mov rax, 0x64AEE5F12530
00007b1fbf9dca18  call rax
00007b1fbf9dca1a  movaps xmm8, [rsp]
00007b1fbf9dca1f  add rsp, 0x30
00007b1fbf9dca23  vmovaps xmm0, [rsp]
00007b1fbf9dca28  vmovaps xmm1, [rsp+0x10]
00007b1fbf9dca2e  vmovaps xmm2, [rsp+0x20]
00007b1fbf9dca34  vmovaps xmm3, [rsp+0x30]
00007b1fbf9dca3a  vmovaps xmm4, [rsp+0x40]
00007b1fbf9dca40  vmovaps xmm5, [rsp+0x50]
00007b1fbf9dca46  vmovaps xmm6, [rsp+0x60]
00007b1fbf9dca4c  vmovaps xmm7, [rsp+0x70]
00007b1fbf9dca52  vmovaps xmm9, [rsp+0x80]
00007b1fbf9dca5b  vmovaps xmm10, [rsp+0x90]
00007b1fbf9dca64  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9dca6d  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9dca76  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9dca7f  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9dca88  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9dca91  add rsp, 0xF0
00007b1fbf9dca98  pop r11
00007b1fbf9dca9a  pop r10
00007b1fbf9dca9c  pop r9
00007b1fbf9dca9e  pop r8
00007b1fbf9dcaa0  pop rsi
00007b1fbf9dcaa1  pop rdi
00007b1fbf9dcaa2  pop rdx
00007b1fbf9dcaa3  pop rcx
00007b1fbf9dcaa4  pop rax
00007b1fbf9dcaa5  add rsp, 0x08
00007b1fbf9dcaa9  jmp 0x00007B1FBF9DBB47
00007b1fbf9dcaae  sub rsp, 0x08
00007b1fbf9dcab2  push rax
00007b1fbf9dcab3  push rcx
00007b1fbf9dcab4  push rdx
00007b1fbf9dcab5  push rdi
00007b1fbf9dcab6  push rsi
00007b1fbf9dcab7  push r8
00007b1fbf9dcab9  push r9
00007b1fbf9dcabb  push r10
00007b1fbf9dcabd  push r11
00007b1fbf9dcabf  sub rsp, 0xF0
00007b1fbf9dcac6  vmovaps [rsp], xmm0
00007b1fbf9dcacb  vmovaps [rsp+0x10], xmm1
00007b1fbf9dcad1  vmovaps [rsp+0x20], xmm2
00007b1fbf9dcad7  vmovaps [rsp+0x30], xmm3
00007b1fbf9dcadd  vmovaps [rsp+0x40], xmm4
00007b1fbf9dcae3  vmovaps [rsp+0x50], xmm5
00007b1fbf9dcae9  vmovaps [rsp+0x60], xmm6
00007b1fbf9dcaef  vmovaps [rsp+0x70], xmm8
00007b1fbf9dcaf5  vmovaps [rsp+0x80], xmm9
00007b1fbf9dcafe  vmovaps [rsp+0x90], xmm10
00007b1fbf9dcb07  vmovaps [rsp+0xA0], xmm11
00007b1fbf9dcb10  vmovaps [rsp+0xB0], xmm12
00007b1fbf9dcb19  vmovaps [rsp+0xC0], xmm13
00007b1fbf9dcb22  vmovaps [rsp+0xD0], xmm14
00007b1fbf9dcb2b  vmovaps [rsp+0xE0], xmm15
00007b1fbf9dcb34  sub rsp, 0x30
00007b1fbf9dcb38  movaps [rsp], xmm7
00007b1fbf9dcb3c  movaps [rsp+0x10], xmm9
00007b1fbf9dcb42  movaps [rsp+0x20], xmm15
00007b1fbf9dcb48  lea rdi, [rsp]
00007b1fbf9dcb4c  mov esi, 0x00
00007b1fbf9dcb51  mov rax, 0x64AEE5F12530
00007b1fbf9dcb5b  call rax
00007b1fbf9dcb5d  movaps xmm7, [rsp]
00007b1fbf9dcb61  add rsp, 0x30
00007b1fbf9dcb65  vmovaps xmm0, [rsp]
00007b1fbf9dcb6a  vmovaps xmm1, [rsp+0x10]
00007b1fbf9dcb70  vmovaps xmm2, [rsp+0x20]
00007b1fbf9dcb76  vmovaps xmm3, [rsp+0x30]
00007b1fbf9dcb7c  vmovaps xmm4, [rsp+0x40]
00007b1fbf9dcb82  vmovaps xmm5, [rsp+0x50]
00007b1fbf9dcb88  vmovaps xmm6, [rsp+0x60]
00007b1fbf9dcb8e  vmovaps xmm8, [rsp+0x70]
00007b1fbf9dcb94  vmovaps xmm9, [rsp+0x80]
00007b1fbf9dcb9d  vmovaps xmm10, [rsp+0x90]
00007b1fbf9dcba6  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9dcbaf  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9dcbb8  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9dcbc1  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9dcbca  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9dcbd3  add rsp, 0xF0
00007b1fbf9dcbda  pop r11
00007b1fbf9dcbdc  pop r10
00007b1fbf9dcbde  pop r9
00007b1fbf9dcbe0  pop r8
00007b1fbf9dcbe2  pop rsi
00007b1fbf9dcbe3  pop rdi
00007b1fbf9dcbe4  pop rdx
00007b1fbf9dcbe5  pop rcx
00007b1fbf9dcbe6  pop rax
00007b1fbf9dcbe7  add rsp, 0x08
00007b1fbf9dcbeb  jmp 0x00007B1FBF9DBB75
00007b1fbf9dcbf0  sub rsp, 0x08
00007b1fbf9dcbf4  push rax
00007b1fbf9dcbf5  push rcx
00007b1fbf9dcbf6  push rdx
00007b1fbf9dcbf7  push rdi
00007b1fbf9dcbf8  push rsi
00007b1fbf9dcbf9  push r8
00007b1fbf9dcbfb  push r9
00007b1fbf9dcbfd  push r10
00007b1fbf9dcbff  push r11
00007b1fbf9dcc01  sub rsp, 0xF0
00007b1fbf9dcc08  vmovaps [rsp], xmm0
00007b1fbf9dcc0d  vmovaps [rsp+0x10], xmm1
00007b1fbf9dcc13  vmovaps [rsp+0x20], xmm2
00007b1fbf9dcc19  vmovaps [rsp+0x30], xmm3
00007b1fbf9dcc1f  vmovaps [rsp+0x40], xmm4
00007b1fbf9dcc25  vmovaps [rsp+0x50], xmm5
00007b1fbf9dcc2b  vmovaps [rsp+0x60], xmm6
00007b1fbf9dcc31  vmovaps [rsp+0x70], xmm7
00007b1fbf9dcc37  vmovaps [rsp+0x80], xmm8
00007b1fbf9dcc40  vmovaps [rsp+0x90], xmm10
00007b1fbf9dcc49  vmovaps [rsp+0xA0], xmm11
00007b1fbf9dcc52  vmovaps [rsp+0xB0], xmm12
00007b1fbf9dcc5b  vmovaps [rsp+0xC0], xmm13
00007b1fbf9dcc64  vmovaps [rsp+0xD0], xmm14
00007b1fbf9dcc6d  vmovaps [rsp+0xE0], xmm15
00007b1fbf9dcc76  sub rsp, 0x30
00007b1fbf9dcc7a  movaps [rsp], xmm9
00007b1fbf9dcc7f  movaps [rsp+0x10], xmm12
00007b1fbf9dcc85  movaps [rsp+0x20], xmm10
00007b1fbf9dcc8b  lea rdi, [rsp]
00007b1fbf9dcc8f  mov esi, 0x00
00007b1fbf9dcc94  mov rax, 0x64AEE5F12530
00007b1fbf9dcc9e  call rax
00007b1fbf9dcca0  movaps xmm9, [rsp]
00007b1fbf9dcca5  add rsp, 0x30
00007b1fbf9dcca9  vmovaps xmm0, [rsp]
00007b1fbf9dccae  vmovaps xmm1, [rsp+0x10]
00007b1fbf9dccb4  vmovaps xmm2, [rsp+0x20]
00007b1fbf9dccba  vmovaps xmm3, [rsp+0x30]
00007b1fbf9dccc0  vmovaps xmm4, [rsp+0x40]
00007b1fbf9dccc6  vmovaps xmm5, [rsp+0x50]
00007b1fbf9dcccc  vmovaps xmm6, [rsp+0x60]
00007b1fbf9dccd2  vmovaps xmm7, [rsp+0x70]
00007b1fbf9dccd8  vmovaps xmm8, [rsp+0x80]
00007b1fbf9dcce1  vmovaps xmm10, [rsp+0x90]
00007b1fbf9dccea  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9dccf3  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9dccfc  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9dcd05  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9dcd0e  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9dcd17  add rsp, 0xF0
00007b1fbf9dcd1e  pop r11
00007b1fbf9dcd20  pop r10
00007b1fbf9dcd22  pop r9
00007b1fbf9dcd24  pop r8
00007b1fbf9dcd26  pop rsi
00007b1fbf9dcd27  pop rdi
00007b1fbf9dcd28  pop rdx
00007b1fbf9dcd29  pop rcx
00007b1fbf9dcd2a  pop rax
00007b1fbf9dcd2b  add rsp, 0x08
00007b1fbf9dcd2f  jmp 0x00007B1FBF9DBB99
00007b1fbf9dcd34  sub rsp, 0x08
00007b1fbf9dcd38  push rax
00007b1fbf9dcd39  push rcx
00007b1fbf9dcd3a  push rdx
00007b1fbf9dcd3b  push rdi
00007b1fbf9dcd3c  push rsi
00007b1fbf9dcd3d  push r8
00007b1fbf9dcd3f  push r9
00007b1fbf9dcd41  push r10
00007b1fbf9dcd43  push r11
00007b1fbf9dcd45  sub rsp, 0xF0
00007b1fbf9dcd4c  vmovaps [rsp], xmm0
00007b1fbf9dcd51  vmovaps [rsp+0x10], xmm1
00007b1fbf9dcd57  vmovaps [rsp+0x20], xmm2
00007b1fbf9dcd5d  vmovaps [rsp+0x30], xmm3
00007b1fbf9dcd63  vmovaps [rsp+0x40], xmm4
00007b1fbf9dcd69  vmovaps [rsp+0x50], xmm5
00007b1fbf9dcd6f  vmovaps [rsp+0x60], xmm6
00007b1fbf9dcd75  vmovaps [rsp+0x70], xmm7
00007b1fbf9dcd7b  vmovaps [rsp+0x80], xmm8
00007b1fbf9dcd84  vmovaps [rsp+0x90], xmm9
00007b1fbf9dcd8d  vmovaps [rsp+0xA0], xmm11
00007b1fbf9dcd96  vmovaps [rsp+0xB0], xmm12
00007b1fbf9dcd9f  vmovaps [rsp+0xC0], xmm13
00007b1fbf9dcda8  vmovaps [rsp+0xD0], xmm14
00007b1fbf9dcdb1  vmovaps [rsp+0xE0], xmm15
00007b1fbf9dcdba  sub rsp, 0x30
00007b1fbf9dcdbe  movaps [rsp], xmm10
00007b1fbf9dcdc3  movaps [rsp+0x10], xmm12
00007b1fbf9dcdc9  movaps [rsp+0x20], xmm11
00007b1fbf9dcdcf  lea rdi, [rsp]
00007b1fbf9dcdd3  mov esi, 0x00
00007b1fbf9dcdd8  mov rax, 0x64AEE5F12530
00007b1fbf9dcde2  call rax
00007b1fbf9dcde4  movaps xmm10, [rsp]
00007b1fbf9dcde9  add rsp, 0x30
00007b1fbf9dcded  vmovaps xmm0, [rsp]
00007b1fbf9dcdf2  vmovaps xmm1, [rsp+0x10]
00007b1fbf9dcdf8  vmovaps xmm2, [rsp+0x20]
00007b1fbf9dcdfe  vmovaps xmm3, [rsp+0x30]
00007b1fbf9dce04  vmovaps xmm4, [rsp+0x40]
00007b1fbf9dce0a  vmovaps xmm5, [rsp+0x50]
00007b1fbf9dce10  vmovaps xmm6, [rsp+0x60]
00007b1fbf9dce16  vmovaps xmm7, [rsp+0x70]
00007b1fbf9dce1c  vmovaps xmm8, [rsp+0x80]
00007b1fbf9dce25  vmovaps xmm9, [rsp+0x90]
00007b1fbf9dce2e  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9dce37  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9dce40  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9dce49  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9dce52  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9dce5b  add rsp, 0xF0
00007b1fbf9dce62  pop r11
00007b1fbf9dce64  pop r10
00007b1fbf9dce66  pop r9
00007b1fbf9dce68  pop r8
00007b1fbf9dce6a  pop rsi
00007b1fbf9dce6b  pop rdi
00007b1fbf9dce6c  pop rdx
00007b1fbf9dce6d  pop rcx
00007b1fbf9dce6e  pop rax
00007b1fbf9dce6f  add rsp, 0x08
00007b1fbf9dce73  jmp 0x00007B1FBF9DBBB3
00007b1fbf9dce78  sub rsp, 0x08
00007b1fbf9dce7c  push rax
00007b1fbf9dce7d  push rcx
00007b1fbf9dce7e  push rdx
00007b1fbf9dce7f  push rdi
00007b1fbf9dce80  push rsi
00007b1fbf9dce81  push r8
00007b1fbf9dce83  push r9
00007b1fbf9dce85  push r10
00007b1fbf9dce87  push r11
00007b1fbf9dce89  sub rsp, 0xF0
00007b1fbf9dce90  vmovaps [rsp], xmm0
00007b1fbf9dce95  vmovaps [rsp+0x10], xmm1
00007b1fbf9dce9b  vmovaps [rsp+0x20], xmm2
00007b1fbf9dcea1  vmovaps [rsp+0x30], xmm3
00007b1fbf9dcea7  vmovaps [rsp+0x40], xmm4
00007b1fbf9dcead  vmovaps [rsp+0x50], xmm5
00007b1fbf9dceb3  vmovaps [rsp+0x60], xmm7
00007b1fbf9dceb9  vmovaps [rsp+0x70], xmm8
00007b1fbf9dcebf  vmovaps [rsp+0x80], xmm9
00007b1fbf9dcec8  vmovaps [rsp+0x90], xmm10
00007b1fbf9dced1  vmovaps [rsp+0xA0], xmm11
00007b1fbf9dceda  vmovaps [rsp+0xB0], xmm12
00007b1fbf9dcee3  vmovaps [rsp+0xC0], xmm13
00007b1fbf9dceec  vmovaps [rsp+0xD0], xmm14
00007b1fbf9dcef5  vmovaps [rsp+0xE0], xmm15
00007b1fbf9dcefe  sub rsp, 0x30
00007b1fbf9dcf02  movaps [rsp], xmm6
00007b1fbf9dcf06  movaps [rsp+0x10], xmm12
00007b1fbf9dcf0c  movaps [rsp+0x20], xmm11
00007b1fbf9dcf12  lea rdi, [rsp]
00007b1fbf9dcf16  mov esi, 0x00
00007b1fbf9dcf1b  mov rax, 0x64AEE5F12530
00007b1fbf9dcf25  call rax
00007b1fbf9dcf27  movaps xmm6, [rsp]
00007b1fbf9dcf2b  add rsp, 0x30
00007b1fbf9dcf2f  vmovaps xmm0, [rsp]
00007b1fbf9dcf34  vmovaps xmm1, [rsp+0x10]
00007b1fbf9dcf3a  vmovaps xmm2, [rsp+0x20]
00007b1fbf9dcf40  vmovaps xmm3, [rsp+0x30]
00007b1fbf9dcf46  vmovaps xmm4, [rsp+0x40]
00007b1fbf9dcf4c  vmovaps xmm5, [rsp+0x50]
00007b1fbf9dcf52  vmovaps xmm7, [rsp+0x60]
00007b1fbf9dcf58  vmovaps xmm8, [rsp+0x70]
00007b1fbf9dcf5e  vmovaps xmm9, [rsp+0x80]
00007b1fbf9dcf67  vmovaps xmm10, [rsp+0x90]
00007b1fbf9dcf70  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9dcf79  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9dcf82  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9dcf8b  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9dcf94  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9dcf9d  add rsp, 0xF0
00007b1fbf9dcfa4  pop r11
00007b1fbf9dcfa6  pop r10
00007b1fbf9dcfa8  pop r9
00007b1fbf9dcfaa  pop r8
00007b1fbf9dcfac  pop rsi
00007b1fbf9dcfad  pop rdi
00007b1fbf9dcfae  pop rdx
00007b1fbf9dcfaf  pop rcx
00007b1fbf9dcfb0  pop rax
00007b1fbf9dcfb1  add rsp, 0x08
00007b1fbf9dcfb5  jmp 0x00007B1FBF9DBBD4
00007b1fbf9dcfba  sub rsp, 0x08
00007b1fbf9dcfbe  push rax
00007b1fbf9dcfbf  push rcx
00007b1fbf9dcfc0  push rdx
00007b1fbf9dcfc1  push rdi
00007b1fbf9dcfc2  push rsi
00007b1fbf9dcfc3  push r8
00007b1fbf9dcfc5  push r9
00007b1fbf9dcfc7  push r10
00007b1fbf9dcfc9  push r11
00007b1fbf9dcfcb  sub rsp, 0xF0
00007b1fbf9dcfd2  vmovaps [rsp], xmm0
00007b1fbf9dcfd7  vmovaps [rsp+0x10], xmm1
00007b1fbf9dcfdd  vmovaps [rsp+0x20], xmm2
00007b1fbf9dcfe3  vmovaps [rsp+0x30], xmm4
00007b1fbf9dcfe9  vmovaps [rsp+0x40], xmm5
00007b1fbf9dcfef  vmovaps [rsp+0x50], xmm6
00007b1fbf9dcff5  vmovaps [rsp+0x60], xmm7
00007b1fbf9dcffb  vmovaps [rsp+0x70], xmm8
00007b1fbf9dd001  vmovaps [rsp+0x80], xmm9
00007b1fbf9dd00a  vmovaps [rsp+0x90], xmm10
00007b1fbf9dd013  vmovaps [rsp+0xA0], xmm11
00007b1fbf9dd01c  vmovaps [rsp+0xB0], xmm12
00007b1fbf9dd025  vmovaps [rsp+0xC0], xmm13
00007b1fbf9dd02e  vmovaps [rsp+0xD0], xmm14
00007b1fbf9dd037  vmovaps [rsp+0xE0], xmm15
00007b1fbf9dd040  sub rsp, 0x30
00007b1fbf9dd044  movaps [rsp], xmm3
00007b1fbf9dd048  movaps [rsp+0x10], xmm5
00007b1fbf9dd04d  movaps [rsp+0x20], xmm4
00007b1fbf9dd052  lea rdi, [rsp]
00007b1fbf9dd056  mov esi, 0x00
00007b1fbf9dd05b  mov rax, 0x64AEE5F12530
00007b1fbf9dd065  call rax
00007b1fbf9dd067  movaps xmm3, [rsp]
00007b1fbf9dd06b  add rsp, 0x30
00007b1fbf9dd06f  vmovaps xmm0, [rsp]
00007b1fbf9dd074  vmovaps xmm1, [rsp+0x10]
00007b1fbf9dd07a  vmovaps xmm2, [rsp+0x20]
00007b1fbf9dd080  vmovaps xmm4, [rsp+0x30]
00007b1fbf9dd086  vmovaps xmm5, [rsp+0x40]
00007b1fbf9dd08c  vmovaps xmm6, [rsp+0x50]
00007b1fbf9dd092  vmovaps xmm7, [rsp+0x60]
00007b1fbf9dd098  vmovaps xmm8, [rsp+0x70]
00007b1fbf9dd09e  vmovaps xmm9, [rsp+0x80]
00007b1fbf9dd0a7  vmovaps xmm10, [rsp+0x90]
00007b1fbf9dd0b0  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9dd0b9  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9dd0c2  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9dd0cb  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9dd0d4  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9dd0dd  add rsp, 0xF0
00007b1fbf9dd0e4  pop r11
00007b1fbf9dd0e6  pop r10
00007b1fbf9dd0e8  pop r9
00007b1fbf9dd0ea  pop r8
00007b1fbf9dd0ec  pop rsi
00007b1fbf9dd0ed  pop rdi
00007b1fbf9dd0ee  pop rdx
00007b1fbf9dd0ef  pop rcx
00007b1fbf9dd0f0  pop rax
00007b1fbf9dd0f1  add rsp, 0x08
00007b1fbf9dd0f5  jmp 0x00007B1FBF9DBC35
00007b1fbf9dd0fa  sub rsp, 0x08
00007b1fbf9dd0fe  push rax
00007b1fbf9dd0ff  push rcx
00007b1fbf9dd100  push rdx
00007b1fbf9dd101  push rdi
00007b1fbf9dd102  push rsi
00007b1fbf9dd103  push r8
00007b1fbf9dd105  push r9
00007b1fbf9dd107  push r10
00007b1fbf9dd109  push r11
00007b1fbf9dd10b  sub rsp, 0xF0
00007b1fbf9dd112  vmovaps [rsp], xmm0
00007b1fbf9dd117  vmovaps [rsp+0x10], xmm1
00007b1fbf9dd11d  vmovaps [rsp+0x20], xmm2
00007b1fbf9dd123  vmovaps [rsp+0x30], xmm3
00007b1fbf9dd129  vmovaps [rsp+0x40], xmm4
00007b1fbf9dd12f  vmovaps [rsp+0x50], xmm6
00007b1fbf9dd135  vmovaps [rsp+0x60], xmm7
00007b1fbf9dd13b  vmovaps [rsp+0x70], xmm8
00007b1fbf9dd141  vmovaps [rsp+0x80], xmm9
00007b1fbf9dd14a  vmovaps [rsp+0x90], xmm10
00007b1fbf9dd153  vmovaps [rsp+0xA0], xmm11
00007b1fbf9dd15c  vmovaps [rsp+0xB0], xmm12
00007b1fbf9dd165  vmovaps [rsp+0xC0], xmm13
00007b1fbf9dd16e  vmovaps [rsp+0xD0], xmm14
00007b1fbf9dd177  vmovaps [rsp+0xE0], xmm15
00007b1fbf9dd180  sub rsp, 0x30
00007b1fbf9dd184  movaps [rsp], xmm5
00007b1fbf9dd188  movaps [rsp+0x10], xmm8
00007b1fbf9dd18e  movaps [rsp+0x20], xmm15
00007b1fbf9dd194  lea rdi, [rsp]
00007b1fbf9dd198  mov esi, 0x00
00007b1fbf9dd19d  mov rax, 0x64AEE5F12530
00007b1fbf9dd1a7  call rax
00007b1fbf9dd1a9  movaps xmm5, [rsp]
00007b1fbf9dd1ad  add rsp, 0x30
00007b1fbf9dd1b1  vmovaps xmm0, [rsp]
00007b1fbf9dd1b6  vmovaps xmm1, [rsp+0x10]
00007b1fbf9dd1bc  vmovaps xmm2, [rsp+0x20]
00007b1fbf9dd1c2  vmovaps xmm3, [rsp+0x30]
00007b1fbf9dd1c8  vmovaps xmm4, [rsp+0x40]
00007b1fbf9dd1ce  vmovaps xmm6, [rsp+0x50]
00007b1fbf9dd1d4  vmovaps xmm7, [rsp+0x60]
00007b1fbf9dd1da  vmovaps xmm8, [rsp+0x70]
00007b1fbf9dd1e0  vmovaps xmm9, [rsp+0x80]
00007b1fbf9dd1e9  vmovaps xmm10, [rsp+0x90]
00007b1fbf9dd1f2  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9dd1fb  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9dd204  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9dd20d  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9dd216  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9dd21f  add rsp, 0xF0
00007b1fbf9dd226  pop r11
00007b1fbf9dd228  pop r10
00007b1fbf9dd22a  pop r9
00007b1fbf9dd22c  pop r8
00007b1fbf9dd22e  pop rsi
00007b1fbf9dd22f  pop rdi
00007b1fbf9dd230  pop rdx
00007b1fbf9dd231  pop rcx
00007b1fbf9dd232  pop rax
00007b1fbf9dd233  add rsp, 0x08
00007b1fbf9dd237  jmp 0x00007B1FBF9DBC73
00007b1fbf9dd23c  sub rsp, 0x08
00007b1fbf9dd240  push rax
00007b1fbf9dd241  push rcx
00007b1fbf9dd242  push rdx
00007b1fbf9dd243  push rdi
00007b1fbf9dd244  push rsi
00007b1fbf9dd245  push r8
00007b1fbf9dd247  push r9
00007b1fbf9dd249  push r10
00007b1fbf9dd24b  push r11
00007b1fbf9dd24d  sub rsp, 0xF0
00007b1fbf9dd254  vmovaps [rsp], xmm0
00007b1fbf9dd259  vmovaps [rsp+0x10], xmm1
00007b1fbf9dd25f  vmovaps [rsp+0x20], xmm2
00007b1fbf9dd265  vmovaps [rsp+0x30], xmm3
00007b1fbf9dd26b  vmovaps [rsp+0x40], xmm5
00007b1fbf9dd271  vmovaps [rsp+0x50], xmm6
00007b1fbf9dd277  vmovaps [rsp+0x60], xmm7
00007b1fbf9dd27d  vmovaps [rsp+0x70], xmm8
00007b1fbf9dd283  vmovaps [rsp+0x80], xmm9
00007b1fbf9dd28c  vmovaps [rsp+0x90], xmm10
00007b1fbf9dd295  vmovaps [rsp+0xA0], xmm11
00007b1fbf9dd29e  vmovaps [rsp+0xB0], xmm12
00007b1fbf9dd2a7  vmovaps [rsp+0xC0], xmm13
00007b1fbf9dd2b0  vmovaps [rsp+0xD0], xmm14
00007b1fbf9dd2b9  vmovaps [rsp+0xE0], xmm15
00007b1fbf9dd2c2  sub rsp, 0x30
00007b1fbf9dd2c6  movaps [rsp], xmm4
00007b1fbf9dd2ca  movaps [rsp+0x10], xmm9
00007b1fbf9dd2d0  movaps [rsp+0x20], xmm8
00007b1fbf9dd2d6  lea rdi, [rsp]
00007b1fbf9dd2da  mov esi, 0x00
00007b1fbf9dd2df  mov rax, 0x64AEE5F12530
00007b1fbf9dd2e9  call rax
00007b1fbf9dd2eb  movaps xmm4, [rsp]
00007b1fbf9dd2ef  add rsp, 0x30
00007b1fbf9dd2f3  vmovaps xmm0, [rsp]
00007b1fbf9dd2f8  vmovaps xmm1, [rsp+0x10]
00007b1fbf9dd2fe  vmovaps xmm2, [rsp+0x20]
00007b1fbf9dd304  vmovaps xmm3, [rsp+0x30]
00007b1fbf9dd30a  vmovaps xmm5, [rsp+0x40]
00007b1fbf9dd310  vmovaps xmm6, [rsp+0x50]
00007b1fbf9dd316  vmovaps xmm7, [rsp+0x60]
00007b1fbf9dd31c  vmovaps xmm8, [rsp+0x70]
00007b1fbf9dd322  vmovaps xmm9, [rsp+0x80]
00007b1fbf9dd32b  vmovaps xmm10, [rsp+0x90]
00007b1fbf9dd334  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9dd33d  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9dd346  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9dd34f  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9dd358  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9dd361  add rsp, 0xF0
00007b1fbf9dd368  pop r11
00007b1fbf9dd36a  pop r10
00007b1fbf9dd36c  pop r9
00007b1fbf9dd36e  pop r8
00007b1fbf9dd370  pop rsi
00007b1fbf9dd371  pop rdi
00007b1fbf9dd372  pop rdx
00007b1fbf9dd373  pop rcx
00007b1fbf9dd374  pop rax
00007b1fbf9dd375  add rsp, 0x08
00007b1fbf9dd379  jmp 0x00007B1FBF9DBC94
00007b1fbf9dd37e  sub rsp, 0x08
00007b1fbf9dd382  push rax
00007b1fbf9dd383  push rcx
00007b1fbf9dd384  push rdx
00007b1fbf9dd385  push rdi
00007b1fbf9dd386  push rsi
00007b1fbf9dd387  push r8
00007b1fbf9dd389  push r9
00007b1fbf9dd38b  push r10
00007b1fbf9dd38d  push r11
00007b1fbf9dd38f  sub rsp, 0xF0
00007b1fbf9dd396  vmovaps [rsp], xmm0
00007b1fbf9dd39b  vmovaps [rsp+0x10], xmm1
00007b1fbf9dd3a1  vmovaps [rsp+0x20], xmm2
00007b1fbf9dd3a7  vmovaps [rsp+0x30], xmm3
00007b1fbf9dd3ad  vmovaps [rsp+0x40], xmm4
00007b1fbf9dd3b3  vmovaps [rsp+0x50], xmm5
00007b1fbf9dd3b9  vmovaps [rsp+0x60], xmm6
00007b1fbf9dd3bf  vmovaps [rsp+0x70], xmm7
00007b1fbf9dd3c5  vmovaps [rsp+0x80], xmm8
00007b1fbf9dd3ce  vmovaps [rsp+0x90], xmm10
00007b1fbf9dd3d7  vmovaps [rsp+0xA0], xmm11
00007b1fbf9dd3e0  vmovaps [rsp+0xB0], xmm12
00007b1fbf9dd3e9  vmovaps [rsp+0xC0], xmm13
00007b1fbf9dd3f2  vmovaps [rsp+0xD0], xmm14
00007b1fbf9dd3fb  vmovaps [rsp+0xE0], xmm15
00007b1fbf9dd404  sub rsp, 0x30
00007b1fbf9dd408  movaps [rsp], xmm9
00007b1fbf9dd40d  movaps [rsp+0x10], xmm10
00007b1fbf9dd413  movaps [rsp+0x20], xmm8
00007b1fbf9dd419  lea rdi, [rsp]
00007b1fbf9dd41d  mov esi, 0x00
00007b1fbf9dd422  mov rax, 0x64AEE5F12530
00007b1fbf9dd42c  call rax
00007b1fbf9dd42e  movaps xmm9, [rsp]
00007b1fbf9dd433  add rsp, 0x30
00007b1fbf9dd437  vmovaps xmm0, [rsp]
00007b1fbf9dd43c  vmovaps xmm1, [rsp+0x10]
00007b1fbf9dd442  vmovaps xmm2, [rsp+0x20]
00007b1fbf9dd448  vmovaps xmm3, [rsp+0x30]
00007b1fbf9dd44e  vmovaps xmm4, [rsp+0x40]
00007b1fbf9dd454  vmovaps xmm5, [rsp+0x50]
00007b1fbf9dd45a  vmovaps xmm6, [rsp+0x60]
00007b1fbf9dd460  vmovaps xmm7, [rsp+0x70]
00007b1fbf9dd466  vmovaps xmm8, [rsp+0x80]
00007b1fbf9dd46f  vmovaps xmm10, [rsp+0x90]
00007b1fbf9dd478  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9dd481  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9dd48a  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9dd493  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9dd49c  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9dd4a5  add rsp, 0xF0
00007b1fbf9dd4ac  pop r11
00007b1fbf9dd4ae  pop r10
00007b1fbf9dd4b0  pop r9
00007b1fbf9dd4b2  pop r8
00007b1fbf9dd4b4  pop rsi
00007b1fbf9dd4b5  pop rdi
00007b1fbf9dd4b6  pop rdx
00007b1fbf9dd4b7  pop rcx
00007b1fbf9dd4b8  pop rax
00007b1fbf9dd4b9  add rsp, 0x08
00007b1fbf9dd4bd  jmp 0x00007B1FBF9DBCAE
00007b1fbf9dd4c2  call 0x00007B1FBF8B52F0
00007b1fbf9dd4c7  jmp 0x00007B1FBF9DBDC8
00007b1fbf9dd4cc  call 0x00007B1FBF8B52F0
00007b1fbf9dd4d1  jmp 0x00007B1FBF9DBDDE
00007b1fbf9dd4d6  sub rsp, 0x08
00007b1fbf9dd4da  push rax
00007b1fbf9dd4db  push rcx
00007b1fbf9dd4dc  push rdx
00007b1fbf9dd4dd  push rdi
00007b1fbf9dd4de  push rsi
00007b1fbf9dd4df  push r8
00007b1fbf9dd4e1  push r9
00007b1fbf9dd4e3  push r10
00007b1fbf9dd4e5  push r11
00007b1fbf9dd4e7  sub rsp, 0xF0
00007b1fbf9dd4ee  vmovaps [rsp], xmm0
00007b1fbf9dd4f3  vmovaps [rsp+0x10], xmm2
00007b1fbf9dd4f9  vmovaps [rsp+0x20], xmm3
00007b1fbf9dd4ff  vmovaps [rsp+0x30], xmm4
00007b1fbf9dd505  vmovaps [rsp+0x40], xmm5
00007b1fbf9dd50b  vmovaps [rsp+0x50], xmm6
00007b1fbf9dd511  vmovaps [rsp+0x60], xmm7
00007b1fbf9dd517  vmovaps [rsp+0x70], xmm8
00007b1fbf9dd51d  vmovaps [rsp+0x80], xmm9
00007b1fbf9dd526  vmovaps [rsp+0x90], xmm10
00007b1fbf9dd52f  vmovaps [rsp+0xA0], xmm11
00007b1fbf9dd538  vmovaps [rsp+0xB0], xmm12
00007b1fbf9dd541  vmovaps [rsp+0xC0], xmm13
00007b1fbf9dd54a  vmovaps [rsp+0xD0], xmm14
00007b1fbf9dd553  vmovaps [rsp+0xE0], xmm15
00007b1fbf9dd55c  sub rsp, 0x30
00007b1fbf9dd560  movaps [rsp], xmm1
00007b1fbf9dd564  movaps [rsp+0x10], xmm6
00007b1fbf9dd569  movaps [rsp+0x20], xmm15
00007b1fbf9dd56f  lea rdi, [rsp]
00007b1fbf9dd573  mov esi, 0x00
00007b1fbf9dd578  mov rax, 0x64AEE5F12530
00007b1fbf9dd582  call rax
00007b1fbf9dd584  movaps xmm1, [rsp]
00007b1fbf9dd588  add rsp, 0x30
00007b1fbf9dd58c  vmovaps xmm0, [rsp]
00007b1fbf9dd591  vmovaps xmm2, [rsp+0x10]
00007b1fbf9dd597  vmovaps xmm3, [rsp+0x20]
00007b1fbf9dd59d  vmovaps xmm4, [rsp+0x30]
00007b1fbf9dd5a3  vmovaps xmm5, [rsp+0x40]
00007b1fbf9dd5a9  vmovaps xmm6, [rsp+0x50]
00007b1fbf9dd5af  vmovaps xmm7, [rsp+0x60]
00007b1fbf9dd5b5  vmovaps xmm8, [rsp+0x70]
00007b1fbf9dd5bb  vmovaps xmm9, [rsp+0x80]
00007b1fbf9dd5c4  vmovaps xmm10, [rsp+0x90]
00007b1fbf9dd5cd  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9dd5d6  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9dd5df  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9dd5e8  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9dd5f1  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9dd5fa  add rsp, 0xF0
00007b1fbf9dd601  pop r11
00007b1fbf9dd603  pop r10
00007b1fbf9dd605  pop r9
00007b1fbf9dd607  pop r8
00007b1fbf9dd609  pop rsi
00007b1fbf9dd60a  pop rdi
00007b1fbf9dd60b  pop rdx
00007b1fbf9dd60c  pop rcx
00007b1fbf9dd60d  pop rax
00007b1fbf9dd60e  add rsp, 0x08
00007b1fbf9dd612  jmp 0x00007B1FBF9DBE1B
00007b1fbf9dd617  call 0x00007B1FBF8C4620
00007b1fbf9dd61c  jmp 0x00007B1FBF9DBE28
00007b1fbf9dd621  sub rsp, 0x08
00007b1fbf9dd625  push rax
00007b1fbf9dd626  push rcx
00007b1fbf9dd627  push rdx
00007b1fbf9dd628  push rdi
00007b1fbf9dd629  push rsi
00007b1fbf9dd62a  push r8
00007b1fbf9dd62c  push r9
00007b1fbf9dd62e  push r10
00007b1fbf9dd630  push r11
00007b1fbf9dd632  sub rsp, 0xF0
00007b1fbf9dd639  vmovaps [rsp], xmm0
00007b1fbf9dd63e  vmovaps [rsp+0x10], xmm1
00007b1fbf9dd644  vmovaps [rsp+0x20], xmm2
00007b1fbf9dd64a  vmovaps [rsp+0x30], xmm3
00007b1fbf9dd650  vmovaps [rsp+0x40], xmm4
00007b1fbf9dd656  vmovaps [rsp+0x50], xmm5
00007b1fbf9dd65c  vmovaps [rsp+0x60], xmm6
00007b1fbf9dd662  vmovaps [rsp+0x70], xmm7
00007b1fbf9dd668  vmovaps [rsp+0x80], xmm8
00007b1fbf9dd671  vmovaps [rsp+0x90], xmm9
00007b1fbf9dd67a  vmovaps [rsp+0xA0], xmm10
00007b1fbf9dd683  vmovaps [rsp+0xB0], xmm11
00007b1fbf9dd68c  vmovaps [rsp+0xC0], xmm12
00007b1fbf9dd695  vmovaps [rsp+0xD0], xmm13
00007b1fbf9dd69e  vmovaps [rsp+0xE0], xmm15
00007b1fbf9dd6a7  sub rsp, 0x30
00007b1fbf9dd6ab  movaps [rsp], xmm14
00007b1fbf9dd6b0  movaps [rsp+0x10], xmm4
00007b1fbf9dd6b5  movaps [rsp+0x20], xmm3
00007b1fbf9dd6ba  lea rdi, [rsp]
00007b1fbf9dd6be  mov esi, 0x00
00007b1fbf9dd6c3  mov rax, 0x64AEE5F12530
00007b1fbf9dd6cd  call rax
00007b1fbf9dd6cf  movaps xmm14, [rsp]
00007b1fbf9dd6d4  add rsp, 0x30
00007b1fbf9dd6d8  vmovaps xmm0, [rsp]
00007b1fbf9dd6dd  vmovaps xmm1, [rsp+0x10]
00007b1fbf9dd6e3  vmovaps xmm2, [rsp+0x20]
00007b1fbf9dd6e9  vmovaps xmm3, [rsp+0x30]
00007b1fbf9dd6ef  vmovaps xmm4, [rsp+0x40]
00007b1fbf9dd6f5  vmovaps xmm5, [rsp+0x50]
00007b1fbf9dd6fb  vmovaps xmm6, [rsp+0x60]
00007b1fbf9dd701  vmovaps xmm7, [rsp+0x70]
00007b1fbf9dd707  vmovaps xmm8, [rsp+0x80]
00007b1fbf9dd710  vmovaps xmm9, [rsp+0x90]
00007b1fbf9dd719  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9dd722  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9dd72b  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9dd734  vmovaps xmm13, [rsp+0xD0]
00007b1fbf9dd73d  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9dd746  add rsp, 0xF0
00007b1fbf9dd74d  pop r11
00007b1fbf9dd74f  pop r10
00007b1fbf9dd751  pop r9
00007b1fbf9dd753  pop r8
00007b1fbf9dd755  pop rsi
00007b1fbf9dd756  pop rdi
00007b1fbf9dd757  pop rdx
00007b1fbf9dd758  pop rcx
00007b1fbf9dd759  pop rax
00007b1fbf9dd75a  add rsp, 0x08
00007b1fbf9dd75e  jmp 0x00007B1FBF9DBE42
00007b1fbf9dd763  sub rsp, 0x08
00007b1fbf9dd767  push rax
00007b1fbf9dd768  push rcx
00007b1fbf9dd769  push rdx
00007b1fbf9dd76a  push rdi
00007b1fbf9dd76b  push rsi
00007b1fbf9dd76c  push r8
00007b1fbf9dd76e  push r9
00007b1fbf9dd770  push r10
00007b1fbf9dd772  push r11
00007b1fbf9dd774  sub rsp, 0xF0
00007b1fbf9dd77b  vmovaps [rsp], xmm0
00007b1fbf9dd780  vmovaps [rsp+0x10], xmm1
00007b1fbf9dd786  vmovaps [rsp+0x20], xmm2
00007b1fbf9dd78c  vmovaps [rsp+0x30], xmm3
00007b1fbf9dd792  vmovaps [rsp+0x40], xmm4
00007b1fbf9dd798  vmovaps [rsp+0x50], xmm5
00007b1fbf9dd79e  vmovaps [rsp+0x60], xmm7
00007b1fbf9dd7a4  vmovaps [rsp+0x70], xmm8
00007b1fbf9dd7aa  vmovaps [rsp+0x80], xmm9
00007b1fbf9dd7b3  vmovaps [rsp+0x90], xmm10
00007b1fbf9dd7bc  vmovaps [rsp+0xA0], xmm11
00007b1fbf9dd7c5  vmovaps [rsp+0xB0], xmm12
00007b1fbf9dd7ce  vmovaps [rsp+0xC0], xmm13
00007b1fbf9dd7d7  vmovaps [rsp+0xD0], xmm14
00007b1fbf9dd7e0  vmovaps [rsp+0xE0], xmm15
00007b1fbf9dd7e9  sub rsp, 0x30
00007b1fbf9dd7ed  movaps [rsp], xmm6
00007b1fbf9dd7f1  movaps [rsp+0x10], xmm9
00007b1fbf9dd7f7  movaps [rsp+0x20], xmm7
00007b1fbf9dd7fc  lea rdi, [rsp]
00007b1fbf9dd800  mov esi, 0x00
00007b1fbf9dd805  mov rax, 0x64AEE5F12530
00007b1fbf9dd80f  call rax
00007b1fbf9dd811  movaps xmm6, [rsp]
00007b1fbf9dd815  add rsp, 0x30
00007b1fbf9dd819  vmovaps xmm0, [rsp]
00007b1fbf9dd81e  vmovaps xmm1, [rsp+0x10]
00007b1fbf9dd824  vmovaps xmm2, [rsp+0x20]
00007b1fbf9dd82a  vmovaps xmm3, [rsp+0x30]
00007b1fbf9dd830  vmovaps xmm4, [rsp+0x40]
00007b1fbf9dd836  vmovaps xmm5, [rsp+0x50]
00007b1fbf9dd83c  vmovaps xmm7, [rsp+0x60]
00007b1fbf9dd842  vmovaps xmm8, [rsp+0x70]
00007b1fbf9dd848  vmovaps xmm9, [rsp+0x80]
00007b1fbf9dd851  vmovaps xmm10, [rsp+0x90]
00007b1fbf9dd85a  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9dd863  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9dd86c  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9dd875  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9dd87e  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9dd887  add rsp, 0xF0
00007b1fbf9dd88e  pop r11
00007b1fbf9dd890  pop r10
00007b1fbf9dd892  pop r9
00007b1fbf9dd894  pop r8
00007b1fbf9dd896  pop rsi
00007b1fbf9dd897  pop rdi
00007b1fbf9dd898  pop rdx
00007b1fbf9dd899  pop rcx
00007b1fbf9dd89a  pop rax
00007b1fbf9dd89b  add rsp, 0x08
00007b1fbf9dd89f  jmp 0x00007B1FBF9DBE5A
00007b1fbf9dd8a4  sub rsp, 0x08
00007b1fbf9dd8a8  push rax
00007b1fbf9dd8a9  push rcx
00007b1fbf9dd8aa  push rdx
00007b1fbf9dd8ab  push rdi
00007b1fbf9dd8ac  push rsi
00007b1fbf9dd8ad  push r8
00007b1fbf9dd8af  push r9
00007b1fbf9dd8b1  push r10
00007b1fbf9dd8b3  push r11
00007b1fbf9dd8b5  sub rsp, 0xF0
00007b1fbf9dd8bc  vmovaps [rsp], xmm0
00007b1fbf9dd8c1  vmovaps [rsp+0x10], xmm1
00007b1fbf9dd8c7  vmovaps [rsp+0x20], xmm2
00007b1fbf9dd8cd  vmovaps [rsp+0x30], xmm3
00007b1fbf9dd8d3  vmovaps [rsp+0x40], xmm4
00007b1fbf9dd8d9  vmovaps [rsp+0x50], xmm5
00007b1fbf9dd8df  vmovaps [rsp+0x60], xmm6
00007b1fbf9dd8e5  vmovaps [rsp+0x70], xmm8
00007b1fbf9dd8eb  vmovaps [rsp+0x80], xmm9
00007b1fbf9dd8f4  vmovaps [rsp+0x90], xmm10
00007b1fbf9dd8fd  vmovaps [rsp+0xA0], xmm11
00007b1fbf9dd906  vmovaps [rsp+0xB0], xmm12
00007b1fbf9dd90f  vmovaps [rsp+0xC0], xmm13
00007b1fbf9dd918  vmovaps [rsp+0xD0], xmm14
00007b1fbf9dd921  vmovaps [rsp+0xE0], xmm15
00007b1fbf9dd92a  sub rsp, 0x30
00007b1fbf9dd92e  movaps [rsp], xmm7
00007b1fbf9dd932  movaps [rsp+0x10], xmm4
00007b1fbf9dd937  movaps [rsp+0x20], xmm9
00007b1fbf9dd93d  lea rdi, [rsp]
00007b1fbf9dd941  mov esi, 0x00
00007b1fbf9dd946  mov rax, 0x64AEE5F12530
00007b1fbf9dd950  call rax
00007b1fbf9dd952  movaps xmm7, [rsp]
00007b1fbf9dd956  add rsp, 0x30
00007b1fbf9dd95a  vmovaps xmm0, [rsp]
00007b1fbf9dd95f  vmovaps xmm1, [rsp+0x10]
00007b1fbf9dd965  vmovaps xmm2, [rsp+0x20]
00007b1fbf9dd96b  vmovaps xmm3, [rsp+0x30]
00007b1fbf9dd971  vmovaps xmm4, [rsp+0x40]
00007b1fbf9dd977  vmovaps xmm5, [rsp+0x50]
00007b1fbf9dd97d  vmovaps xmm6, [rsp+0x60]
00007b1fbf9dd983  vmovaps xmm8, [rsp+0x70]
00007b1fbf9dd989  vmovaps xmm9, [rsp+0x80]
00007b1fbf9dd992  vmovaps xmm10, [rsp+0x90]
00007b1fbf9dd99b  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9dd9a4  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9dd9ad  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9dd9b6  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9dd9bf  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9dd9c8  add rsp, 0xF0
00007b1fbf9dd9cf  pop r11
00007b1fbf9dd9d1  pop r10
00007b1fbf9dd9d3  pop r9
00007b1fbf9dd9d5  pop r8
00007b1fbf9dd9d7  pop rsi
00007b1fbf9dd9d8  pop rdi
00007b1fbf9dd9d9  pop rdx
00007b1fbf9dd9da  pop rcx
00007b1fbf9dd9db  pop rax
00007b1fbf9dd9dc  add rsp, 0x08
00007b1fbf9dd9e0  jmp 0x00007B1FBF9DBE87
00007b1fbf9dd9e5  sub rsp, 0x08
00007b1fbf9dd9e9  push rax
00007b1fbf9dd9ea  push rcx
00007b1fbf9dd9eb  push rdx
00007b1fbf9dd9ec  push rdi
00007b1fbf9dd9ed  push rsi
00007b1fbf9dd9ee  push r8
00007b1fbf9dd9f0  push r9
00007b1fbf9dd9f2  push r10
00007b1fbf9dd9f4  push r11
00007b1fbf9dd9f6  sub rsp, 0xF0
00007b1fbf9dd9fd  vmovaps [rsp], xmm0
00007b1fbf9dda02  vmovaps [rsp+0x10], xmm1
00007b1fbf9dda08  vmovaps [rsp+0x20], xmm2
00007b1fbf9dda0e  vmovaps [rsp+0x30], xmm3
00007b1fbf9dda14  vmovaps [rsp+0x40], xmm5
00007b1fbf9dda1a  vmovaps [rsp+0x50], xmm6
00007b1fbf9dda20  vmovaps [rsp+0x60], xmm7
00007b1fbf9dda26  vmovaps [rsp+0x70], xmm8
00007b1fbf9dda2c  vmovaps [rsp+0x80], xmm9
00007b1fbf9dda35  vmovaps [rsp+0x90], xmm10
00007b1fbf9dda3e  vmovaps [rsp+0xA0], xmm11
00007b1fbf9dda47  vmovaps [rsp+0xB0], xmm12
00007b1fbf9dda50  vmovaps [rsp+0xC0], xmm13
00007b1fbf9dda59  vmovaps [rsp+0xD0], xmm14
00007b1fbf9dda62  vmovaps [rsp+0xE0], xmm15
00007b1fbf9dda6b  sub rsp, 0x30
00007b1fbf9dda6f  movaps [rsp], xmm4
00007b1fbf9dda73  movaps [rsp+0x10], xmm15
00007b1fbf9dda79  movaps [rsp+0x20], xmm9
00007b1fbf9dda7f  lea rdi, [rsp]
00007b1fbf9dda83  mov esi, 0x00
00007b1fbf9dda88  mov rax, 0x64AEE5F12530
00007b1fbf9dda92  call rax
00007b1fbf9dda94  movaps xmm4, [rsp]
00007b1fbf9dda98  add rsp, 0x30
00007b1fbf9dda9c  vmovaps xmm0, [rsp]
00007b1fbf9ddaa1  vmovaps xmm1, [rsp+0x10]
00007b1fbf9ddaa7  vmovaps xmm2, [rsp+0x20]
00007b1fbf9ddaad  vmovaps xmm3, [rsp+0x30]
00007b1fbf9ddab3  vmovaps xmm5, [rsp+0x40]
00007b1fbf9ddab9  vmovaps xmm6, [rsp+0x50]
00007b1fbf9ddabf  vmovaps xmm7, [rsp+0x60]
00007b1fbf9ddac5  vmovaps xmm8, [rsp+0x70]
00007b1fbf9ddacb  vmovaps xmm9, [rsp+0x80]
00007b1fbf9ddad4  vmovaps xmm10, [rsp+0x90]
00007b1fbf9ddadd  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9ddae6  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9ddaef  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9ddaf8  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9ddb01  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9ddb0a  add rsp, 0xF0
00007b1fbf9ddb11  pop r11
00007b1fbf9ddb13  pop r10
00007b1fbf9ddb15  pop r9
00007b1fbf9ddb17  pop r8
00007b1fbf9ddb19  pop rsi
00007b1fbf9ddb1a  pop rdi
00007b1fbf9ddb1b  pop rdx
00007b1fbf9ddb1c  pop rcx
00007b1fbf9ddb1d  pop rax
00007b1fbf9ddb1e  add rsp, 0x08
00007b1fbf9ddb22  jmp 0x00007B1FBF9DBEAC
00007b1fbf9ddb27  call 0x00007B1FBF8C4620
00007b1fbf9ddb2c  jmp 0x00007B1FBF9DBEB9
00007b1fbf9ddb31  sub rsp, 0x08
00007b1fbf9ddb35  push rax
00007b1fbf9ddb36  push rcx
00007b1fbf9ddb37  push rdx
00007b1fbf9ddb38  push rdi
00007b1fbf9ddb39  push rsi
00007b1fbf9ddb3a  push r8
00007b1fbf9ddb3c  push r9
00007b1fbf9ddb3e  push r10
00007b1fbf9ddb40  push r11
00007b1fbf9ddb42  sub rsp, 0xF0
00007b1fbf9ddb49  vmovaps [rsp], xmm0
00007b1fbf9ddb4e  vmovaps [rsp+0x10], xmm1
00007b1fbf9ddb54  vmovaps [rsp+0x20], xmm2
00007b1fbf9ddb5a  vmovaps [rsp+0x30], xmm4
00007b1fbf9ddb60  vmovaps [rsp+0x40], xmm5
00007b1fbf9ddb66  vmovaps [rsp+0x50], xmm6
00007b1fbf9ddb6c  vmovaps [rsp+0x60], xmm7
00007b1fbf9ddb72  vmovaps [rsp+0x70], xmm8
00007b1fbf9ddb78  vmovaps [rsp+0x80], xmm9
00007b1fbf9ddb81  vmovaps [rsp+0x90], xmm10
00007b1fbf9ddb8a  vmovaps [rsp+0xA0], xmm11
00007b1fbf9ddb93  vmovaps [rsp+0xB0], xmm12
00007b1fbf9ddb9c  vmovaps [rsp+0xC0], xmm13
00007b1fbf9ddba5  vmovaps [rsp+0xD0], xmm14
00007b1fbf9ddbae  vmovaps [rsp+0xE0], xmm15
00007b1fbf9ddbb7  sub rsp, 0x30
00007b1fbf9ddbbb  movaps [rsp], xmm3
00007b1fbf9ddbbf  movaps [rsp+0x10], xmm1
00007b1fbf9ddbc4  movaps [rsp+0x20], xmm9
00007b1fbf9ddbca  lea rdi, [rsp]
00007b1fbf9ddbce  mov esi, 0x00
00007b1fbf9ddbd3  mov rax, 0x64AEE5F12530
00007b1fbf9ddbdd  call rax
00007b1fbf9ddbdf  movaps xmm3, [rsp]
00007b1fbf9ddbe3  add rsp, 0x30
00007b1fbf9ddbe7  vmovaps xmm0, [rsp]
00007b1fbf9ddbec  vmovaps xmm1, [rsp+0x10]
00007b1fbf9ddbf2  vmovaps xmm2, [rsp+0x20]
00007b1fbf9ddbf8  vmovaps xmm4, [rsp+0x30]
00007b1fbf9ddbfe  vmovaps xmm5, [rsp+0x40]
00007b1fbf9ddc04  vmovaps xmm6, [rsp+0x50]
00007b1fbf9ddc0a  vmovaps xmm7, [rsp+0x60]
00007b1fbf9ddc10  vmovaps xmm8, [rsp+0x70]
00007b1fbf9ddc16  vmovaps xmm9, [rsp+0x80]
00007b1fbf9ddc1f  vmovaps xmm10, [rsp+0x90]
00007b1fbf9ddc28  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9ddc31  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9ddc3a  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9ddc43  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9ddc4c  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9ddc55  add rsp, 0xF0
00007b1fbf9ddc5c  pop r11
00007b1fbf9ddc5e  pop r10
00007b1fbf9ddc60  pop r9
00007b1fbf9ddc62  pop r8
00007b1fbf9ddc64  pop rsi
00007b1fbf9ddc65  pop rdi
00007b1fbf9ddc66  pop rdx
00007b1fbf9ddc67  pop rcx
00007b1fbf9ddc68  pop rax
00007b1fbf9ddc69  add rsp, 0x08
00007b1fbf9ddc6d  jmp 0x00007B1FBF9DBEF6
00007b1fbf9ddc72  sub rsp, 0x08
00007b1fbf9ddc76  push rax
00007b1fbf9ddc77  push rcx
00007b1fbf9ddc78  push rdx
00007b1fbf9ddc79  push rdi
00007b1fbf9ddc7a  push rsi
00007b1fbf9ddc7b  push r8
00007b1fbf9ddc7d  push r9
00007b1fbf9ddc7f  push r10
00007b1fbf9ddc81  push r11
00007b1fbf9ddc83  sub rsp, 0xF0
00007b1fbf9ddc8a  vmovaps [rsp], xmm0
00007b1fbf9ddc8f  vmovaps [rsp+0x10], xmm2
00007b1fbf9ddc95  vmovaps [rsp+0x20], xmm3
00007b1fbf9ddc9b  vmovaps [rsp+0x30], xmm4
00007b1fbf9ddca1  vmovaps [rsp+0x40], xmm5
00007b1fbf9ddca7  vmovaps [rsp+0x50], xmm6
00007b1fbf9ddcad  vmovaps [rsp+0x60], xmm7
00007b1fbf9ddcb3  vmovaps [rsp+0x70], xmm8
00007b1fbf9ddcb9  vmovaps [rsp+0x80], xmm9
00007b1fbf9ddcc2  vmovaps [rsp+0x90], xmm10
00007b1fbf9ddccb  vmovaps [rsp+0xA0], xmm11
00007b1fbf9ddcd4  vmovaps [rsp+0xB0], xmm12
00007b1fbf9ddcdd  vmovaps [rsp+0xC0], xmm13
00007b1fbf9ddce6  vmovaps [rsp+0xD0], xmm14
00007b1fbf9ddcef  vmovaps [rsp+0xE0], xmm15
00007b1fbf9ddcf8  sub rsp, 0x30
00007b1fbf9ddcfc  movaps [rsp], xmm1
00007b1fbf9ddd00  movaps [rsp+0x10], xmm15
00007b1fbf9ddd06  movaps [rsp+0x20], xmm9
00007b1fbf9ddd0c  lea rdi, [rsp]
00007b1fbf9ddd10  mov esi, 0x00
00007b1fbf9ddd15  mov rax, 0x64AEE5F12530
00007b1fbf9ddd1f  call rax
00007b1fbf9ddd21  movaps xmm1, [rsp]
00007b1fbf9ddd25  add rsp, 0x30
00007b1fbf9ddd29  vmovaps xmm0, [rsp]
00007b1fbf9ddd2e  vmovaps xmm2, [rsp+0x10]
00007b1fbf9ddd34  vmovaps xmm3, [rsp+0x20]
00007b1fbf9ddd3a  vmovaps xmm4, [rsp+0x30]
00007b1fbf9ddd40  vmovaps xmm5, [rsp+0x40]
00007b1fbf9ddd46  vmovaps xmm6, [rsp+0x50]
00007b1fbf9ddd4c  vmovaps xmm7, [rsp+0x60]
00007b1fbf9ddd52  vmovaps xmm8, [rsp+0x70]
00007b1fbf9ddd58  vmovaps xmm9, [rsp+0x80]
00007b1fbf9ddd61  vmovaps xmm10, [rsp+0x90]
00007b1fbf9ddd6a  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9ddd73  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9ddd7c  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9ddd85  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9ddd8e  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9ddd97  add rsp, 0xF0
00007b1fbf9ddd9e  pop r11
00007b1fbf9ddda0  pop r10
00007b1fbf9ddda2  pop r9
00007b1fbf9ddda4  pop r8
00007b1fbf9ddda6  pop rsi
00007b1fbf9ddda7  pop rdi
00007b1fbf9ddda8  pop rdx
00007b1fbf9ddda9  pop rcx
00007b1fbf9dddaa  pop rax
00007b1fbf9dddab  add rsp, 0x08
00007b1fbf9dddaf  jmp 0x00007B1FBF9DBF7E
00007b1fbf9dddb4  call 0x00007B1FBF8C4620
00007b1fbf9dddb9  jmp 0x00007B1FBF9DBF8B
00007b1fbf9dddbe  sub rsp, 0x08
00007b1fbf9dddc2  push rax
00007b1fbf9dddc3  push rcx
00007b1fbf9dddc4  push rdx
00007b1fbf9dddc5  push rdi
00007b1fbf9dddc6  push rsi
00007b1fbf9dddc7  push r8
00007b1fbf9dddc9  push r9
00007b1fbf9dddcb  push r10
00007b1fbf9dddcd  push r11
00007b1fbf9dddcf  sub rsp, 0xF0
00007b1fbf9dddd6  vmovaps [rsp], xmm0
00007b1fbf9ddddb  vmovaps [rsp+0x10], xmm2
00007b1fbf9ddde1  vmovaps [rsp+0x20], xmm3
00007b1fbf9ddde7  vmovaps [rsp+0x30], xmm4
00007b1fbf9ddded  vmovaps [rsp+0x40], xmm5
00007b1fbf9dddf3  vmovaps [rsp+0x50], xmm6
00007b1fbf9dddf9  vmovaps [rsp+0x60], xmm7
00007b1fbf9dddff  vmovaps [rsp+0x70], xmm8
00007b1fbf9dde05  vmovaps [rsp+0x80], xmm9
00007b1fbf9dde0e  vmovaps [rsp+0x90], xmm10
00007b1fbf9dde17  vmovaps [rsp+0xA0], xmm11
00007b1fbf9dde20  vmovaps [rsp+0xB0], xmm12
00007b1fbf9dde29  vmovaps [rsp+0xC0], xmm13
00007b1fbf9dde32  vmovaps [rsp+0xD0], xmm14
00007b1fbf9dde3b  vmovaps [rsp+0xE0], xmm15
00007b1fbf9dde44  sub rsp, 0x30
00007b1fbf9dde48  movaps [rsp], xmm1
00007b1fbf9dde4c  movaps [rsp+0x10], xmm5
00007b1fbf9dde51  movaps [rsp+0x20], xmm7
00007b1fbf9dde56  lea rdi, [rsp]
00007b1fbf9dde5a  mov esi, 0x00
00007b1fbf9dde5f  mov rax, 0x64AEE5F12530
00007b1fbf9dde69  call rax
00007b1fbf9dde6b  movaps xmm1, [rsp]
00007b1fbf9dde6f  add rsp, 0x30
00007b1fbf9dde73  vmovaps xmm0, [rsp]
00007b1fbf9dde78  vmovaps xmm2, [rsp+0x10]
00007b1fbf9dde7e  vmovaps xmm3, [rsp+0x20]
00007b1fbf9dde84  vmovaps xmm4, [rsp+0x30]
00007b1fbf9dde8a  vmovaps xmm5, [rsp+0x40]
00007b1fbf9dde90  vmovaps xmm6, [rsp+0x50]
00007b1fbf9dde96  vmovaps xmm7, [rsp+0x60]
00007b1fbf9dde9c  vmovaps xmm8, [rsp+0x70]
00007b1fbf9ddea2  vmovaps xmm9, [rsp+0x80]
00007b1fbf9ddeab  vmovaps xmm10, [rsp+0x90]
00007b1fbf9ddeb4  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9ddebd  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9ddec6  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9ddecf  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9dded8  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9ddee1  add rsp, 0xF0
00007b1fbf9ddee8  pop r11
00007b1fbf9ddeea  pop r10
00007b1fbf9ddeec  pop r9
00007b1fbf9ddeee  pop r8
00007b1fbf9ddef0  pop rsi
00007b1fbf9ddef1  pop rdi
00007b1fbf9ddef2  pop rdx
00007b1fbf9ddef3  pop rcx
00007b1fbf9ddef4  pop rax
00007b1fbf9ddef5  add rsp, 0x08
00007b1fbf9ddef9  jmp 0x00007B1FBF9DC030
00007b1fbf9ddefe  sub rsp, 0x08
00007b1fbf9ddf02  push rax
00007b1fbf9ddf03  push rcx
00007b1fbf9ddf04  push rdx
00007b1fbf9ddf05  push rdi
00007b1fbf9ddf06  push rsi
00007b1fbf9ddf07  push r8
00007b1fbf9ddf09  push r9
00007b1fbf9ddf0b  push r10
00007b1fbf9ddf0d  push r11
00007b1fbf9ddf0f  sub rsp, 0xF0
00007b1fbf9ddf16  vmovaps [rsp], xmm0
00007b1fbf9ddf1b  vmovaps [rsp+0x10], xmm1
00007b1fbf9ddf21  vmovaps [rsp+0x20], xmm2
00007b1fbf9ddf27  vmovaps [rsp+0x30], xmm3
00007b1fbf9ddf2d  vmovaps [rsp+0x40], xmm4
00007b1fbf9ddf33  vmovaps [rsp+0x50], xmm5
00007b1fbf9ddf39  vmovaps [rsp+0x60], xmm6
00007b1fbf9ddf3f  vmovaps [rsp+0x70], xmm8
00007b1fbf9ddf45  vmovaps [rsp+0x80], xmm9
00007b1fbf9ddf4e  vmovaps [rsp+0x90], xmm10
00007b1fbf9ddf57  vmovaps [rsp+0xA0], xmm11
00007b1fbf9ddf60  vmovaps [rsp+0xB0], xmm12
00007b1fbf9ddf69  vmovaps [rsp+0xC0], xmm13
00007b1fbf9ddf72  vmovaps [rsp+0xD0], xmm14
00007b1fbf9ddf7b  vmovaps [rsp+0xE0], xmm15
00007b1fbf9ddf84  sub rsp, 0x30
00007b1fbf9ddf88  movaps [rsp], xmm7
00007b1fbf9ddf8c  movaps [rsp+0x10], xmm5
00007b1fbf9ddf91  movaps [rsp+0x20], xmm15
00007b1fbf9ddf97  lea rdi, [rsp]
00007b1fbf9ddf9b  mov esi, 0x00
00007b1fbf9ddfa0  mov rax, 0x64AEE5F12530
00007b1fbf9ddfaa  call rax
00007b1fbf9ddfac  movaps xmm7, [rsp]
00007b1fbf9ddfb0  add rsp, 0x30
00007b1fbf9ddfb4  vmovaps xmm0, [rsp]
00007b1fbf9ddfb9  vmovaps xmm1, [rsp+0x10]
00007b1fbf9ddfbf  vmovaps xmm2, [rsp+0x20]
00007b1fbf9ddfc5  vmovaps xmm3, [rsp+0x30]
00007b1fbf9ddfcb  vmovaps xmm4, [rsp+0x40]
00007b1fbf9ddfd1  vmovaps xmm5, [rsp+0x50]
00007b1fbf9ddfd7  vmovaps xmm6, [rsp+0x60]
00007b1fbf9ddfdd  vmovaps xmm8, [rsp+0x70]
00007b1fbf9ddfe3  vmovaps xmm9, [rsp+0x80]
00007b1fbf9ddfec  vmovaps xmm10, [rsp+0x90]
00007b1fbf9ddff5  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9ddffe  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9de007  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9de010  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9de019  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9de022  add rsp, 0xF0
00007b1fbf9de029  pop r11
00007b1fbf9de02b  pop r10
00007b1fbf9de02d  pop r9
00007b1fbf9de02f  pop r8
00007b1fbf9de031  pop rsi
00007b1fbf9de032  pop rdi
00007b1fbf9de033  pop rdx
00007b1fbf9de034  pop rcx
00007b1fbf9de035  pop rax
00007b1fbf9de036  add rsp, 0x08
00007b1fbf9de03a  jmp 0x00007B1FBF9DC066
00007b1fbf9de03f  call 0x00007B1FBF8B52F0
00007b1fbf9de044  jmp 0x00007B1FBF9DC073
00007b1fbf9de049  sub rsp, 0x08
00007b1fbf9de04d  push rax
00007b1fbf9de04e  push rcx
00007b1fbf9de04f  push rdx
00007b1fbf9de050  push rdi
00007b1fbf9de051  push rsi
00007b1fbf9de052  push r8
00007b1fbf9de054  push r9
00007b1fbf9de056  push r10
00007b1fbf9de058  push r11
00007b1fbf9de05a  sub rsp, 0xF0
00007b1fbf9de061  vmovaps [rsp], xmm0
00007b1fbf9de066  vmovaps [rsp+0x10], xmm1
00007b1fbf9de06c  vmovaps [rsp+0x20], xmm2
00007b1fbf9de072  vmovaps [rsp+0x30], xmm3
00007b1fbf9de078  vmovaps [rsp+0x40], xmm4
00007b1fbf9de07e  vmovaps [rsp+0x50], xmm5
00007b1fbf9de084  vmovaps [rsp+0x60], xmm6
00007b1fbf9de08a  vmovaps [rsp+0x70], xmm7
00007b1fbf9de090  vmovaps [rsp+0x80], xmm8
00007b1fbf9de099  vmovaps [rsp+0x90], xmm9
00007b1fbf9de0a2  vmovaps [rsp+0xA0], xmm10
00007b1fbf9de0ab  vmovaps [rsp+0xB0], xmm11
00007b1fbf9de0b4  vmovaps [rsp+0xC0], xmm12
00007b1fbf9de0bd  vmovaps [rsp+0xD0], xmm13
00007b1fbf9de0c6  vmovaps [rsp+0xE0], xmm14
00007b1fbf9de0cf  sub rsp, 0x30
00007b1fbf9de0d3  movaps [rsp], xmm15
00007b1fbf9de0d8  movaps [rsp+0x10], xmm5
00007b1fbf9de0dd  movaps [rsp+0x20], xmm3
00007b1fbf9de0e2  lea rdi, [rsp]
00007b1fbf9de0e6  mov esi, 0x00
00007b1fbf9de0eb  mov rax, 0x64AEE5F12530
00007b1fbf9de0f5  call rax
00007b1fbf9de0f7  movaps xmm15, [rsp]
00007b1fbf9de0fc  add rsp, 0x30
00007b1fbf9de100  vmovaps xmm0, [rsp]
00007b1fbf9de105  vmovaps xmm1, [rsp+0x10]
00007b1fbf9de10b  vmovaps xmm2, [rsp+0x20]
00007b1fbf9de111  vmovaps xmm3, [rsp+0x30]
00007b1fbf9de117  vmovaps xmm4, [rsp+0x40]
00007b1fbf9de11d  vmovaps xmm5, [rsp+0x50]
00007b1fbf9de123  vmovaps xmm6, [rsp+0x60]
00007b1fbf9de129  vmovaps xmm7, [rsp+0x70]
00007b1fbf9de12f  vmovaps xmm8, [rsp+0x80]
00007b1fbf9de138  vmovaps xmm9, [rsp+0x90]
00007b1fbf9de141  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9de14a  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9de153  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9de15c  vmovaps xmm13, [rsp+0xD0]
00007b1fbf9de165  vmovaps xmm14, [rsp+0xE0]
00007b1fbf9de16e  add rsp, 0xF0
00007b1fbf9de175  pop r11
00007b1fbf9de177  pop r10
00007b1fbf9de179  pop r9
00007b1fbf9de17b  pop r8
00007b1fbf9de17d  pop rsi
00007b1fbf9de17e  pop rdi
00007b1fbf9de17f  pop rdx
00007b1fbf9de180  pop rcx
00007b1fbf9de181  pop rax
00007b1fbf9de182  add rsp, 0x08
00007b1fbf9de186  jmp 0x00007B1FBF9DC099
00007b1fbf9de18b  sub rsp, 0x08
00007b1fbf9de18f  push rax
00007b1fbf9de190  push rcx
00007b1fbf9de191  push rdx
00007b1fbf9de192  push rdi
00007b1fbf9de193  push rsi
00007b1fbf9de194  push r8
00007b1fbf9de196  push r9
00007b1fbf9de198  push r10
00007b1fbf9de19a  push r11
00007b1fbf9de19c  sub rsp, 0xF0
00007b1fbf9de1a3  vmovaps [rsp], xmm0
00007b1fbf9de1a8  vmovaps [rsp+0x10], xmm2
00007b1fbf9de1ae  vmovaps [rsp+0x20], xmm3
00007b1fbf9de1b4  vmovaps [rsp+0x30], xmm4
00007b1fbf9de1ba  vmovaps [rsp+0x40], xmm5
00007b1fbf9de1c0  vmovaps [rsp+0x50], xmm6
00007b1fbf9de1c6  vmovaps [rsp+0x60], xmm7
00007b1fbf9de1cc  vmovaps [rsp+0x70], xmm8
00007b1fbf9de1d2  vmovaps [rsp+0x80], xmm9
00007b1fbf9de1db  vmovaps [rsp+0x90], xmm10
00007b1fbf9de1e4  vmovaps [rsp+0xA0], xmm11
00007b1fbf9de1ed  vmovaps [rsp+0xB0], xmm12
00007b1fbf9de1f6  vmovaps [rsp+0xC0], xmm13
00007b1fbf9de1ff  vmovaps [rsp+0xD0], xmm14
00007b1fbf9de208  vmovaps [rsp+0xE0], xmm15
00007b1fbf9de211  sub rsp, 0x30
00007b1fbf9de215  movaps [rsp], xmm1
00007b1fbf9de219  movaps [rsp+0x10], xmm5
00007b1fbf9de21e  movaps [rsp+0x20], xmm4
00007b1fbf9de223  lea rdi, [rsp]
00007b1fbf9de227  mov esi, 0x00
00007b1fbf9de22c  mov rax, 0x64AEE5F12530
00007b1fbf9de236  call rax
00007b1fbf9de238  movaps xmm1, [rsp]
00007b1fbf9de23c  add rsp, 0x30
00007b1fbf9de240  vmovaps xmm0, [rsp]
00007b1fbf9de245  vmovaps xmm2, [rsp+0x10]
00007b1fbf9de24b  vmovaps xmm3, [rsp+0x20]
00007b1fbf9de251  vmovaps xmm4, [rsp+0x30]
00007b1fbf9de257  vmovaps xmm5, [rsp+0x40]
00007b1fbf9de25d  vmovaps xmm6, [rsp+0x50]
00007b1fbf9de263  vmovaps xmm7, [rsp+0x60]
00007b1fbf9de269  vmovaps xmm8, [rsp+0x70]
00007b1fbf9de26f  vmovaps xmm9, [rsp+0x80]
00007b1fbf9de278  vmovaps xmm10, [rsp+0x90]
00007b1fbf9de281  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9de28a  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9de293  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9de29c  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9de2a5  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9de2ae  add rsp, 0xF0
00007b1fbf9de2b5  pop r11
00007b1fbf9de2b7  pop r10
00007b1fbf9de2b9  pop r9
00007b1fbf9de2bb  pop r8
00007b1fbf9de2bd  pop rsi
00007b1fbf9de2be  pop rdi
00007b1fbf9de2bf  pop rdx
00007b1fbf9de2c0  pop rcx
00007b1fbf9de2c1  pop rax
00007b1fbf9de2c2  add rsp, 0x08
00007b1fbf9de2c6  jmp 0x00007B1FBF9DC0B9
00007b1fbf9de2cb  sub rsp, 0x08
00007b1fbf9de2cf  push rax
00007b1fbf9de2d0  push rcx
00007b1fbf9de2d1  push rdx
00007b1fbf9de2d2  push rdi
00007b1fbf9de2d3  push rsi
00007b1fbf9de2d4  push r8
00007b1fbf9de2d6  push r9
00007b1fbf9de2d8  push r10
00007b1fbf9de2da  push r11
00007b1fbf9de2dc  sub rsp, 0xF0
00007b1fbf9de2e3  vmovaps [rsp], xmm0
00007b1fbf9de2e8  vmovaps [rsp+0x10], xmm1
00007b1fbf9de2ee  vmovaps [rsp+0x20], xmm2
00007b1fbf9de2f4  vmovaps [rsp+0x30], xmm3
00007b1fbf9de2fa  vmovaps [rsp+0x40], xmm5
00007b1fbf9de300  vmovaps [rsp+0x50], xmm6
00007b1fbf9de306  vmovaps [rsp+0x60], xmm7
00007b1fbf9de30c  vmovaps [rsp+0x70], xmm8
00007b1fbf9de312  vmovaps [rsp+0x80], xmm9
00007b1fbf9de31b  vmovaps [rsp+0x90], xmm10
00007b1fbf9de324  vmovaps [rsp+0xA0], xmm11
00007b1fbf9de32d  vmovaps [rsp+0xB0], xmm12
00007b1fbf9de336  vmovaps [rsp+0xC0], xmm13
00007b1fbf9de33f  vmovaps [rsp+0xD0], xmm14
00007b1fbf9de348  vmovaps [rsp+0xE0], xmm15
00007b1fbf9de351  sub rsp, 0x30
00007b1fbf9de355  movaps [rsp], xmm4
00007b1fbf9de359  movaps [rsp+0x10], xmm3
00007b1fbf9de35e  movaps [rsp+0x20], xmm5
00007b1fbf9de363  lea rdi, [rsp]
00007b1fbf9de367  mov esi, 0x00
00007b1fbf9de36c  mov rax, 0x64AEE5F12530
00007b1fbf9de376  call rax
00007b1fbf9de378  movaps xmm4, [rsp]
00007b1fbf9de37c  add rsp, 0x30
00007b1fbf9de380  vmovaps xmm0, [rsp]
00007b1fbf9de385  vmovaps xmm1, [rsp+0x10]
00007b1fbf9de38b  vmovaps xmm2, [rsp+0x20]
00007b1fbf9de391  vmovaps xmm3, [rsp+0x30]
00007b1fbf9de397  vmovaps xmm5, [rsp+0x40]
00007b1fbf9de39d  vmovaps xmm6, [rsp+0x50]
00007b1fbf9de3a3  vmovaps xmm7, [rsp+0x60]
00007b1fbf9de3a9  vmovaps xmm8, [rsp+0x70]
00007b1fbf9de3af  vmovaps xmm9, [rsp+0x80]
00007b1fbf9de3b8  vmovaps xmm10, [rsp+0x90]
00007b1fbf9de3c1  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9de3ca  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9de3d3  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9de3dc  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9de3e5  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9de3ee  add rsp, 0xF0
00007b1fbf9de3f5  pop r11
00007b1fbf9de3f7  pop r10
00007b1fbf9de3f9  pop r9
00007b1fbf9de3fb  pop r8
00007b1fbf9de3fd  pop rsi
00007b1fbf9de3fe  pop rdi
00007b1fbf9de3ff  pop rdx
00007b1fbf9de400  pop rcx
00007b1fbf9de401  pop rax
00007b1fbf9de402  add rsp, 0x08
00007b1fbf9de406  jmp 0x00007B1FBF9DC107
00007b1fbf9de40b  call 0x00007B1FBF8B52F0
00007b1fbf9de410  jmp 0x00007B1FBF9DC114
00007b1fbf9de415  sub rsp, 0x08
00007b1fbf9de419  push rax
00007b1fbf9de41a  push rcx
00007b1fbf9de41b  push rdx
00007b1fbf9de41c  push rdi
00007b1fbf9de41d  push rsi
00007b1fbf9de41e  push r8
00007b1fbf9de420  push r9
00007b1fbf9de422  push r10
00007b1fbf9de424  push r11
00007b1fbf9de426  sub rsp, 0xF0
00007b1fbf9de42d  vmovaps [rsp], xmm0
00007b1fbf9de432  vmovaps [rsp+0x10], xmm1
00007b1fbf9de438  vmovaps [rsp+0x20], xmm2
00007b1fbf9de43e  vmovaps [rsp+0x30], xmm3
00007b1fbf9de444  vmovaps [rsp+0x40], xmm4
00007b1fbf9de44a  vmovaps [rsp+0x50], xmm6
00007b1fbf9de450  vmovaps [rsp+0x60], xmm7
00007b1fbf9de456  vmovaps [rsp+0x70], xmm8
00007b1fbf9de45c  vmovaps [rsp+0x80], xmm9
00007b1fbf9de465  vmovaps [rsp+0x90], xmm10
00007b1fbf9de46e  vmovaps [rsp+0xA0], xmm11
00007b1fbf9de477  vmovaps [rsp+0xB0], xmm12
00007b1fbf9de480  vmovaps [rsp+0xC0], xmm13
00007b1fbf9de489  vmovaps [rsp+0xD0], xmm14
00007b1fbf9de492  vmovaps [rsp+0xE0], xmm15
00007b1fbf9de49b  sub rsp, 0x30
00007b1fbf9de49f  movaps [rsp], xmm5
00007b1fbf9de4a3  movaps [rsp+0x10], xmm6
00007b1fbf9de4a8  movaps [rsp+0x20], xmm3
00007b1fbf9de4ad  lea rdi, [rsp]
00007b1fbf9de4b1  mov esi, 0x00
00007b1fbf9de4b6  mov rax, 0x64AEE5F12530
00007b1fbf9de4c0  call rax
00007b1fbf9de4c2  movaps xmm5, [rsp]
00007b1fbf9de4c6  add rsp, 0x30
00007b1fbf9de4ca  vmovaps xmm0, [rsp]
00007b1fbf9de4cf  vmovaps xmm1, [rsp+0x10]
00007b1fbf9de4d5  vmovaps xmm2, [rsp+0x20]
00007b1fbf9de4db  vmovaps xmm3, [rsp+0x30]
00007b1fbf9de4e1  vmovaps xmm4, [rsp+0x40]
00007b1fbf9de4e7  vmovaps xmm6, [rsp+0x50]
00007b1fbf9de4ed  vmovaps xmm7, [rsp+0x60]
00007b1fbf9de4f3  vmovaps xmm8, [rsp+0x70]
00007b1fbf9de4f9  vmovaps xmm9, [rsp+0x80]
00007b1fbf9de502  vmovaps xmm10, [rsp+0x90]
00007b1fbf9de50b  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9de514  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9de51d  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9de526  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9de52f  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9de538  add rsp, 0xF0
00007b1fbf9de53f  pop r11
00007b1fbf9de541  pop r10
00007b1fbf9de543  pop r9
00007b1fbf9de545  pop r8
00007b1fbf9de547  pop rsi
00007b1fbf9de548  pop rdi
00007b1fbf9de549  pop rdx
00007b1fbf9de54a  pop rcx
00007b1fbf9de54b  pop rax
00007b1fbf9de54c  add rsp, 0x08
00007b1fbf9de550  jmp 0x00007B1FBF9DC13A
00007b1fbf9de555  sub rsp, 0x08
00007b1fbf9de559  push rax
00007b1fbf9de55a  push rcx
00007b1fbf9de55b  push rdx
00007b1fbf9de55c  push rdi
00007b1fbf9de55d  push rsi
00007b1fbf9de55e  push r8
00007b1fbf9de560  push r9
00007b1fbf9de562  push r10
00007b1fbf9de564  push r11
00007b1fbf9de566  sub rsp, 0xF0
00007b1fbf9de56d  vmovaps [rsp], xmm0
00007b1fbf9de572  vmovaps [rsp+0x10], xmm1
00007b1fbf9de578  vmovaps [rsp+0x20], xmm2
00007b1fbf9de57e  vmovaps [rsp+0x30], xmm3
00007b1fbf9de584  vmovaps [rsp+0x40], xmm4
00007b1fbf9de58a  vmovaps [rsp+0x50], xmm5
00007b1fbf9de590  vmovaps [rsp+0x60], xmm7
00007b1fbf9de596  vmovaps [rsp+0x70], xmm8
00007b1fbf9de59c  vmovaps [rsp+0x80], xmm9
00007b1fbf9de5a5  vmovaps [rsp+0x90], xmm10
00007b1fbf9de5ae  vmovaps [rsp+0xA0], xmm11
00007b1fbf9de5b7  vmovaps [rsp+0xB0], xmm12
00007b1fbf9de5c0  vmovaps [rsp+0xC0], xmm13
00007b1fbf9de5c9  vmovaps [rsp+0xD0], xmm14
00007b1fbf9de5d2  vmovaps [rsp+0xE0], xmm15
00007b1fbf9de5db  sub rsp, 0x30
00007b1fbf9de5df  movaps [rsp], xmm6
00007b1fbf9de5e3  movaps [rsp+0x10], xmm9
00007b1fbf9de5e9  movaps [rsp+0x20], xmm1
00007b1fbf9de5ee  lea rdi, [rsp]
00007b1fbf9de5f2  mov esi, 0x00
00007b1fbf9de5f7  mov rax, 0x64AEE5F12530
00007b1fbf9de601  call rax
00007b1fbf9de603  movaps xmm6, [rsp]
00007b1fbf9de607  add rsp, 0x30
00007b1fbf9de60b  vmovaps xmm0, [rsp]
00007b1fbf9de610  vmovaps xmm1, [rsp+0x10]
00007b1fbf9de616  vmovaps xmm2, [rsp+0x20]
00007b1fbf9de61c  vmovaps xmm3, [rsp+0x30]
00007b1fbf9de622  vmovaps xmm4, [rsp+0x40]
00007b1fbf9de628  vmovaps xmm5, [rsp+0x50]
00007b1fbf9de62e  vmovaps xmm7, [rsp+0x60]
00007b1fbf9de634  vmovaps xmm8, [rsp+0x70]
00007b1fbf9de63a  vmovaps xmm9, [rsp+0x80]
00007b1fbf9de643  vmovaps xmm10, [rsp+0x90]
00007b1fbf9de64c  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9de655  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9de65e  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9de667  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9de670  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9de679  add rsp, 0xF0
00007b1fbf9de680  pop r11
00007b1fbf9de682  pop r10
00007b1fbf9de684  pop r9
00007b1fbf9de686  pop r8
00007b1fbf9de688  pop rsi
00007b1fbf9de689  pop rdi
00007b1fbf9de68a  pop rdx
00007b1fbf9de68b  pop rcx
00007b1fbf9de68c  pop rax
00007b1fbf9de68d  add rsp, 0x08
00007b1fbf9de691  jmp 0x00007B1FBF9DC15E
00007b1fbf9de696  sub rsp, 0x08
00007b1fbf9de69a  push rax
00007b1fbf9de69b  push rcx
00007b1fbf9de69c  push rdx
00007b1fbf9de69d  push rdi
00007b1fbf9de69e  push rsi
00007b1fbf9de69f  push r8
00007b1fbf9de6a1  push r9
00007b1fbf9de6a3  push r10
00007b1fbf9de6a5  push r11
00007b1fbf9de6a7  sub rsp, 0xF0
00007b1fbf9de6ae  vmovaps [rsp], xmm0
00007b1fbf9de6b3  vmovaps [rsp+0x10], xmm1
00007b1fbf9de6b9  vmovaps [rsp+0x20], xmm2
00007b1fbf9de6bf  vmovaps [rsp+0x30], xmm3
00007b1fbf9de6c5  vmovaps [rsp+0x40], xmm4
00007b1fbf9de6cb  vmovaps [rsp+0x50], xmm5
00007b1fbf9de6d1  vmovaps [rsp+0x60], xmm6
00007b1fbf9de6d7  vmovaps [rsp+0x70], xmm7
00007b1fbf9de6dd  vmovaps [rsp+0x80], xmm8
00007b1fbf9de6e6  vmovaps [rsp+0x90], xmm10
00007b1fbf9de6ef  vmovaps [rsp+0xA0], xmm11
00007b1fbf9de6f8  vmovaps [rsp+0xB0], xmm12
00007b1fbf9de701  vmovaps [rsp+0xC0], xmm13
00007b1fbf9de70a  vmovaps [rsp+0xD0], xmm14
00007b1fbf9de713  vmovaps [rsp+0xE0], xmm15
00007b1fbf9de71c  sub rsp, 0x30
00007b1fbf9de720  movaps [rsp], xmm9
00007b1fbf9de725  movaps [rsp+0x10], xmm3
00007b1fbf9de72a  movaps [rsp+0x20], xmm1
00007b1fbf9de72f  lea rdi, [rsp]
00007b1fbf9de733  mov esi, 0x00
00007b1fbf9de738  mov rax, 0x64AEE5F12530
00007b1fbf9de742  call rax
00007b1fbf9de744  movaps xmm9, [rsp]
00007b1fbf9de749  add rsp, 0x30
00007b1fbf9de74d  vmovaps xmm0, [rsp]
00007b1fbf9de752  vmovaps xmm1, [rsp+0x10]
00007b1fbf9de758  vmovaps xmm2, [rsp+0x20]
00007b1fbf9de75e  vmovaps xmm3, [rsp+0x30]
00007b1fbf9de764  vmovaps xmm4, [rsp+0x40]
00007b1fbf9de76a  vmovaps xmm5, [rsp+0x50]
00007b1fbf9de770  vmovaps xmm6, [rsp+0x60]
00007b1fbf9de776  vmovaps xmm7, [rsp+0x70]
00007b1fbf9de77c  vmovaps xmm8, [rsp+0x80]
00007b1fbf9de785  vmovaps xmm10, [rsp+0x90]
00007b1fbf9de78e  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9de797  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9de7a0  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9de7a9  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9de7b2  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9de7bb  add rsp, 0xF0
00007b1fbf9de7c2  pop r11
00007b1fbf9de7c4  pop r10
00007b1fbf9de7c6  pop r9
00007b1fbf9de7c8  pop r8
00007b1fbf9de7ca  pop rsi
00007b1fbf9de7cb  pop rdi
00007b1fbf9de7cc  pop rdx
00007b1fbf9de7cd  pop rcx
00007b1fbf9de7ce  pop rax
00007b1fbf9de7cf  add rsp, 0x08
00007b1fbf9de7d3  jmp 0x00007B1FBF9DC1AA
00007b1fbf9de7d8  call 0x00007B1FBF8B52F0
00007b1fbf9de7dd  jmp 0x00007B1FBF9DC1B7
00007b1fbf9de7e2  sub rsp, 0x08
00007b1fbf9de7e6  push rax
00007b1fbf9de7e7  push rcx
00007b1fbf9de7e8  push rdx
00007b1fbf9de7e9  push rdi
00007b1fbf9de7ea  push rsi
00007b1fbf9de7eb  push r8
00007b1fbf9de7ed  push r9
00007b1fbf9de7ef  push r10
00007b1fbf9de7f1  push r11
00007b1fbf9de7f3  sub rsp, 0xF0
00007b1fbf9de7fa  vmovaps [rsp], xmm0
00007b1fbf9de7ff  vmovaps [rsp+0x10], xmm1
00007b1fbf9de805  vmovaps [rsp+0x20], xmm2
00007b1fbf9de80b  vmovaps [rsp+0x30], xmm3
00007b1fbf9de811  vmovaps [rsp+0x40], xmm4
00007b1fbf9de817  vmovaps [rsp+0x50], xmm5
00007b1fbf9de81d  vmovaps [rsp+0x60], xmm6
00007b1fbf9de823  vmovaps [rsp+0x70], xmm7
00007b1fbf9de829  vmovaps [rsp+0x80], xmm8
00007b1fbf9de832  vmovaps [rsp+0x90], xmm9
00007b1fbf9de83b  vmovaps [rsp+0xA0], xmm10
00007b1fbf9de844  vmovaps [rsp+0xB0], xmm11
00007b1fbf9de84d  vmovaps [rsp+0xC0], xmm12
00007b1fbf9de856  vmovaps [rsp+0xD0], xmm13
00007b1fbf9de85f  vmovaps [rsp+0xE0], xmm14
00007b1fbf9de868  sub rsp, 0x30
00007b1fbf9de86c  movaps [rsp], xmm15
00007b1fbf9de871  movaps [rsp+0x10], xmm3
00007b1fbf9de876  movaps [rsp+0x20], xmm7
00007b1fbf9de87b  lea rdi, [rsp]
00007b1fbf9de87f  mov esi, 0x00
00007b1fbf9de884  mov rax, 0x64AEE5F12530
00007b1fbf9de88e  call rax
00007b1fbf9de890  movaps xmm15, [rsp]
00007b1fbf9de895  add rsp, 0x30
00007b1fbf9de899  vmovaps xmm0, [rsp]
00007b1fbf9de89e  vmovaps xmm1, [rsp+0x10]
00007b1fbf9de8a4  vmovaps xmm2, [rsp+0x20]
00007b1fbf9de8aa  vmovaps xmm3, [rsp+0x30]
00007b1fbf9de8b0  vmovaps xmm4, [rsp+0x40]
00007b1fbf9de8b6  vmovaps xmm5, [rsp+0x50]
00007b1fbf9de8bc  vmovaps xmm6, [rsp+0x60]
00007b1fbf9de8c2  vmovaps xmm7, [rsp+0x70]
00007b1fbf9de8c8  vmovaps xmm8, [rsp+0x80]
00007b1fbf9de8d1  vmovaps xmm9, [rsp+0x90]
00007b1fbf9de8da  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9de8e3  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9de8ec  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9de8f5  vmovaps xmm13, [rsp+0xD0]
00007b1fbf9de8fe  vmovaps xmm14, [rsp+0xE0]
00007b1fbf9de907  add rsp, 0xF0
00007b1fbf9de90e  pop r11
00007b1fbf9de910  pop r10
00007b1fbf9de912  pop r9
00007b1fbf9de914  pop r8
00007b1fbf9de916  pop rsi
00007b1fbf9de917  pop rdi
00007b1fbf9de918  pop rdx
00007b1fbf9de919  pop rcx
00007b1fbf9de91a  pop rax
00007b1fbf9de91b  add rsp, 0x08
00007b1fbf9de91f  jmp 0x00007B1FBF9DC1E3
00007b1fbf9de924  sub rsp, 0x08
00007b1fbf9de928  push rax
00007b1fbf9de929  push rcx
00007b1fbf9de92a  push rdx
00007b1fbf9de92b  push rdi
00007b1fbf9de92c  push rsi
00007b1fbf9de92d  push r8
00007b1fbf9de92f  push r9
00007b1fbf9de931  push r10
00007b1fbf9de933  push r11
00007b1fbf9de935  sub rsp, 0xF0
00007b1fbf9de93c  vmovaps [rsp], xmm0
00007b1fbf9de941  vmovaps [rsp+0x10], xmm1
00007b1fbf9de947  vmovaps [rsp+0x20], xmm2
00007b1fbf9de94d  vmovaps [rsp+0x30], xmm4
00007b1fbf9de953  vmovaps [rsp+0x40], xmm5
00007b1fbf9de959  vmovaps [rsp+0x50], xmm6
00007b1fbf9de95f  vmovaps [rsp+0x60], xmm7
00007b1fbf9de965  vmovaps [rsp+0x70], xmm8
00007b1fbf9de96b  vmovaps [rsp+0x80], xmm9
00007b1fbf9de974  vmovaps [rsp+0x90], xmm10
00007b1fbf9de97d  vmovaps [rsp+0xA0], xmm11
00007b1fbf9de986  vmovaps [rsp+0xB0], xmm12
00007b1fbf9de98f  vmovaps [rsp+0xC0], xmm13
00007b1fbf9de998  vmovaps [rsp+0xD0], xmm14
00007b1fbf9de9a1  vmovaps [rsp+0xE0], xmm15
00007b1fbf9de9aa  sub rsp, 0x30
00007b1fbf9de9ae  movaps [rsp], xmm3
00007b1fbf9de9b2  movaps [rsp+0x10], xmm1
00007b1fbf9de9b7  movaps [rsp+0x20], xmm15
00007b1fbf9de9bd  lea rdi, [rsp]
00007b1fbf9de9c1  mov esi, 0x00
00007b1fbf9de9c6  mov rax, 0x64AEE5F12530
00007b1fbf9de9d0  call rax
00007b1fbf9de9d2  movaps xmm3, [rsp]
00007b1fbf9de9d6  add rsp, 0x30
00007b1fbf9de9da  vmovaps xmm0, [rsp]
00007b1fbf9de9df  vmovaps xmm1, [rsp+0x10]
00007b1fbf9de9e5  vmovaps xmm2, [rsp+0x20]
00007b1fbf9de9eb  vmovaps xmm4, [rsp+0x30]
00007b1fbf9de9f1  vmovaps xmm5, [rsp+0x40]
00007b1fbf9de9f7  vmovaps xmm6, [rsp+0x50]
00007b1fbf9de9fd  vmovaps xmm7, [rsp+0x60]
00007b1fbf9dea03  vmovaps xmm8, [rsp+0x70]
00007b1fbf9dea09  vmovaps xmm9, [rsp+0x80]
00007b1fbf9dea12  vmovaps xmm10, [rsp+0x90]
00007b1fbf9dea1b  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9dea24  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9dea2d  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9dea36  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9dea3f  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9dea48  add rsp, 0xF0
00007b1fbf9dea4f  pop r11
00007b1fbf9dea51  pop r10
00007b1fbf9dea53  pop r9
00007b1fbf9dea55  pop r8
00007b1fbf9dea57  pop rsi
00007b1fbf9dea58  pop rdi
00007b1fbf9dea59  pop rdx
00007b1fbf9dea5a  pop rcx
00007b1fbf9dea5b  pop rax
00007b1fbf9dea5c  add rsp, 0x08
00007b1fbf9dea60  jmp 0x00007B1FBF9DC272
00007b1fbf9dea65  call 0x00007B1FBF8B52F0
00007b1fbf9dea6a  jmp 0x00007B1FBF9DC27C
00007b1fbf9dea6f  sub rsp, 0x08
00007b1fbf9dea73  push rax
00007b1fbf9dea74  push rcx
00007b1fbf9dea75  push rdx
00007b1fbf9dea76  push rdi
00007b1fbf9dea77  push rsi
00007b1fbf9dea78  push r8
00007b1fbf9dea7a  push r9
00007b1fbf9dea7c  push r10
00007b1fbf9dea7e  push r11
00007b1fbf9dea80  sub rsp, 0xF0
00007b1fbf9dea87  vmovaps [rsp], xmm0
00007b1fbf9dea8c  vmovaps [rsp+0x10], xmm1
00007b1fbf9dea92  vmovaps [rsp+0x20], xmm2
00007b1fbf9dea98  vmovaps [rsp+0x30], xmm3
00007b1fbf9dea9e  vmovaps [rsp+0x40], xmm4
00007b1fbf9deaa4  vmovaps [rsp+0x50], xmm5
00007b1fbf9deaaa  vmovaps [rsp+0x60], xmm6
00007b1fbf9deab0  vmovaps [rsp+0x70], xmm7
00007b1fbf9deab6  vmovaps [rsp+0x80], xmm8
00007b1fbf9deabf  vmovaps [rsp+0x90], xmm9
00007b1fbf9deac8  vmovaps [rsp+0xA0], xmm10
00007b1fbf9dead1  vmovaps [rsp+0xB0], xmm11
00007b1fbf9deada  vmovaps [rsp+0xC0], xmm12
00007b1fbf9deae3  vmovaps [rsp+0xD0], xmm13
00007b1fbf9deaec  vmovaps [rsp+0xE0], xmm14
00007b1fbf9deaf5  sub rsp, 0x30
00007b1fbf9deaf9  movaps [rsp], xmm15
00007b1fbf9deafe  movaps [rsp+0x10], xmm14
00007b1fbf9deb04  movaps [rsp+0x20], xmm4
00007b1fbf9deb09  lea rdi, [rsp]
00007b1fbf9deb0d  mov esi, 0x00
00007b1fbf9deb12  mov rax, 0x64AEE5F12530
00007b1fbf9deb1c  call rax
00007b1fbf9deb1e  movaps xmm15, [rsp]
00007b1fbf9deb23  add rsp, 0x30
00007b1fbf9deb27  vmovaps xmm0, [rsp]
00007b1fbf9deb2c  vmovaps xmm1, [rsp+0x10]
00007b1fbf9deb32  vmovaps xmm2, [rsp+0x20]
00007b1fbf9deb38  vmovaps xmm3, [rsp+0x30]
00007b1fbf9deb3e  vmovaps xmm4, [rsp+0x40]
00007b1fbf9deb44  vmovaps xmm5, [rsp+0x50]
00007b1fbf9deb4a  vmovaps xmm6, [rsp+0x60]
00007b1fbf9deb50  vmovaps xmm7, [rsp+0x70]
00007b1fbf9deb56  vmovaps xmm8, [rsp+0x80]
00007b1fbf9deb5f  vmovaps xmm9, [rsp+0x90]
00007b1fbf9deb68  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9deb71  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9deb7a  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9deb83  vmovaps xmm13, [rsp+0xD0]
00007b1fbf9deb8c  vmovaps xmm14, [rsp+0xE0]
00007b1fbf9deb95  add rsp, 0xF0
00007b1fbf9deb9c  pop r11
00007b1fbf9deb9e  pop r10
00007b1fbf9deba0  pop r9
00007b1fbf9deba2  pop r8
00007b1fbf9deba4  pop rsi
00007b1fbf9deba5  pop rdi
00007b1fbf9deba6  pop rdx
00007b1fbf9deba7  pop rcx
00007b1fbf9deba8  pop rax
00007b1fbf9deba9  add rsp, 0x08
00007b1fbf9debad  jmp 0x00007B1FBF9DC2AA
00007b1fbf9debb2  sub rsp, 0x08
00007b1fbf9debb6  push rax
00007b1fbf9debb7  push rcx
00007b1fbf9debb8  push rdx
00007b1fbf9debb9  push rdi
00007b1fbf9debba  push rsi
00007b1fbf9debbb  push r8
00007b1fbf9debbd  push r9
00007b1fbf9debbf  push r10
00007b1fbf9debc1  push r11
00007b1fbf9debc3  sub rsp, 0xF0
00007b1fbf9debca  vmovaps [rsp], xmm0
00007b1fbf9debcf  vmovaps [rsp+0x10], xmm1
00007b1fbf9debd5  vmovaps [rsp+0x20], xmm2
00007b1fbf9debdb  vmovaps [rsp+0x30], xmm3
00007b1fbf9debe1  vmovaps [rsp+0x40], xmm4
00007b1fbf9debe7  vmovaps [rsp+0x50], xmm5
00007b1fbf9debed  vmovaps [rsp+0x60], xmm6
00007b1fbf9debf3  vmovaps [rsp+0x70], xmm7
00007b1fbf9debf9  vmovaps [rsp+0x80], xmm8
00007b1fbf9dec02  vmovaps [rsp+0x90], xmm9
00007b1fbf9dec0b  vmovaps [rsp+0xA0], xmm10
00007b1fbf9dec14  vmovaps [rsp+0xB0], xmm11
00007b1fbf9dec1d  vmovaps [rsp+0xC0], xmm12
00007b1fbf9dec26  vmovaps [rsp+0xD0], xmm13
00007b1fbf9dec2f  vmovaps [rsp+0xE0], xmm15
00007b1fbf9dec38  sub rsp, 0x30
00007b1fbf9dec3c  movaps [rsp], xmm14
00007b1fbf9dec41  movaps [rsp+0x10], xmm2
00007b1fbf9dec46  movaps [rsp+0x20], xmm1
00007b1fbf9dec4b  lea rdi, [rsp]
00007b1fbf9dec4f  mov esi, 0x00
00007b1fbf9dec54  mov rax, 0x64AEE5F12530
00007b1fbf9dec5e  call rax
00007b1fbf9dec60  movaps xmm14, [rsp]
00007b1fbf9dec65  add rsp, 0x30
00007b1fbf9dec69  vmovaps xmm0, [rsp]
00007b1fbf9dec6e  vmovaps xmm1, [rsp+0x10]
00007b1fbf9dec74  vmovaps xmm2, [rsp+0x20]
00007b1fbf9dec7a  vmovaps xmm3, [rsp+0x30]
00007b1fbf9dec80  vmovaps xmm4, [rsp+0x40]
00007b1fbf9dec86  vmovaps xmm5, [rsp+0x50]
00007b1fbf9dec8c  vmovaps xmm6, [rsp+0x60]
00007b1fbf9dec92  vmovaps xmm7, [rsp+0x70]
00007b1fbf9dec98  vmovaps xmm8, [rsp+0x80]
00007b1fbf9deca1  vmovaps xmm9, [rsp+0x90]
00007b1fbf9decaa  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9decb3  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9decbc  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9decc5  vmovaps xmm13, [rsp+0xD0]
00007b1fbf9decce  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9decd7  add rsp, 0xF0
00007b1fbf9decde  pop r11
00007b1fbf9dece0  pop r10
00007b1fbf9dece2  pop r9
00007b1fbf9dece4  pop r8
00007b1fbf9dece6  pop rsi
00007b1fbf9dece7  pop rdi
00007b1fbf9dece8  pop rdx
00007b1fbf9dece9  pop rcx
00007b1fbf9decea  pop rax
00007b1fbf9deceb  add rsp, 0x08
00007b1fbf9decef  jmp 0x00007B1FBF9DC2D0
00007b1fbf9decf4  sub rsp, 0x08
00007b1fbf9decf8  push rax
00007b1fbf9decf9  push rcx
00007b1fbf9decfa  push rdx
00007b1fbf9decfb  push rdi
00007b1fbf9decfc  push rsi
00007b1fbf9decfd  push r8
00007b1fbf9decff  push r9
00007b1fbf9ded01  push r10
00007b1fbf9ded03  push r11
00007b1fbf9ded05  sub rsp, 0xF0
00007b1fbf9ded0c  vmovaps [rsp], xmm0
00007b1fbf9ded11  vmovaps [rsp+0x10], xmm2
00007b1fbf9ded17  vmovaps [rsp+0x20], xmm3
00007b1fbf9ded1d  vmovaps [rsp+0x30], xmm4
00007b1fbf9ded23  vmovaps [rsp+0x40], xmm5
00007b1fbf9ded29  vmovaps [rsp+0x50], xmm6
00007b1fbf9ded2f  vmovaps [rsp+0x60], xmm7
00007b1fbf9ded35  vmovaps [rsp+0x70], xmm8
00007b1fbf9ded3b  vmovaps [rsp+0x80], xmm9
00007b1fbf9ded44  vmovaps [rsp+0x90], xmm10
00007b1fbf9ded4d  vmovaps [rsp+0xA0], xmm11
00007b1fbf9ded56  vmovaps [rsp+0xB0], xmm12
00007b1fbf9ded5f  vmovaps [rsp+0xC0], xmm13
00007b1fbf9ded68  vmovaps [rsp+0xD0], xmm14
00007b1fbf9ded71  vmovaps [rsp+0xE0], xmm15
00007b1fbf9ded7a  sub rsp, 0x30
00007b1fbf9ded7e  movaps [rsp], xmm1
00007b1fbf9ded82  movaps [rsp+0x10], xmm4
00007b1fbf9ded87  movaps [rsp+0x20], xmm9
00007b1fbf9ded8d  lea rdi, [rsp]
00007b1fbf9ded91  mov esi, 0x00
00007b1fbf9ded96  mov rax, 0x64AEE5F12530
00007b1fbf9deda0  call rax
00007b1fbf9deda2  movaps xmm1, [rsp]
00007b1fbf9deda6  add rsp, 0x30
00007b1fbf9dedaa  vmovaps xmm0, [rsp]
00007b1fbf9dedaf  vmovaps xmm2, [rsp+0x10]
00007b1fbf9dedb5  vmovaps xmm3, [rsp+0x20]
00007b1fbf9dedbb  vmovaps xmm4, [rsp+0x30]
00007b1fbf9dedc1  vmovaps xmm5, [rsp+0x40]
00007b1fbf9dedc7  vmovaps xmm6, [rsp+0x50]
00007b1fbf9dedcd  vmovaps xmm7, [rsp+0x60]
00007b1fbf9dedd3  vmovaps xmm8, [rsp+0x70]
00007b1fbf9dedd9  vmovaps xmm9, [rsp+0x80]
00007b1fbf9dede2  vmovaps xmm10, [rsp+0x90]
00007b1fbf9dedeb  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9dedf4  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9dedfd  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9dee06  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9dee0f  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9dee18  add rsp, 0xF0
00007b1fbf9dee1f  pop r11
00007b1fbf9dee21  pop r10
00007b1fbf9dee23  pop r9
00007b1fbf9dee25  pop r8
00007b1fbf9dee27  pop rsi
00007b1fbf9dee28  pop rdi
00007b1fbf9dee29  pop rdx
00007b1fbf9dee2a  pop rcx
00007b1fbf9dee2b  pop rax
00007b1fbf9dee2c  add rsp, 0x08
00007b1fbf9dee30  jmp 0x00007B1FBF9DC2EE
00007b1fbf9dee35  sub rsp, 0x08
00007b1fbf9dee39  push rax
00007b1fbf9dee3a  push rcx
00007b1fbf9dee3b  push rdx
00007b1fbf9dee3c  push rdi
00007b1fbf9dee3d  push rsi
00007b1fbf9dee3e  push r8
00007b1fbf9dee40  push r9
00007b1fbf9dee42  push r10
00007b1fbf9dee44  push r11
00007b1fbf9dee46  sub rsp, 0xF0
00007b1fbf9dee4d  vmovaps [rsp], xmm0
00007b1fbf9dee52  vmovaps [rsp+0x10], xmm1
00007b1fbf9dee58  vmovaps [rsp+0x20], xmm2
00007b1fbf9dee5e  vmovaps [rsp+0x30], xmm3
00007b1fbf9dee64  vmovaps [rsp+0x40], xmm5
00007b1fbf9dee6a  vmovaps [rsp+0x50], xmm6
00007b1fbf9dee70  vmovaps [rsp+0x60], xmm7
00007b1fbf9dee76  vmovaps [rsp+0x70], xmm8
00007b1fbf9dee7c  vmovaps [rsp+0x80], xmm9
00007b1fbf9dee85  vmovaps [rsp+0x90], xmm10
00007b1fbf9dee8e  vmovaps [rsp+0xA0], xmm11
00007b1fbf9dee97  vmovaps [rsp+0xB0], xmm12
00007b1fbf9deea0  vmovaps [rsp+0xC0], xmm13
00007b1fbf9deea9  vmovaps [rsp+0xD0], xmm14
00007b1fbf9deeb2  vmovaps [rsp+0xE0], xmm15
00007b1fbf9deebb  sub rsp, 0x30
00007b1fbf9deebf  movaps [rsp], xmm4
00007b1fbf9deec3  movaps [rsp+0x10], xmm2
00007b1fbf9deec8  movaps [rsp+0x20], xmm9
00007b1fbf9deece  lea rdi, [rsp]
00007b1fbf9deed2  mov esi, 0x00
00007b1fbf9deed7  mov rax, 0x64AEE5F12530
00007b1fbf9deee1  call rax
00007b1fbf9deee3  movaps xmm4, [rsp]
00007b1fbf9deee7  add rsp, 0x30
00007b1fbf9deeeb  vmovaps xmm0, [rsp]
00007b1fbf9deef0  vmovaps xmm1, [rsp+0x10]
00007b1fbf9deef6  vmovaps xmm2, [rsp+0x20]
00007b1fbf9deefc  vmovaps xmm3, [rsp+0x30]
00007b1fbf9def02  vmovaps xmm5, [rsp+0x40]
00007b1fbf9def08  vmovaps xmm6, [rsp+0x50]
00007b1fbf9def0e  vmovaps xmm7, [rsp+0x60]
00007b1fbf9def14  vmovaps xmm8, [rsp+0x70]
00007b1fbf9def1a  vmovaps xmm9, [rsp+0x80]
00007b1fbf9def23  vmovaps xmm10, [rsp+0x90]
00007b1fbf9def2c  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9def35  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9def3e  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9def47  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9def50  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9def59  add rsp, 0xF0
00007b1fbf9def60  pop r11
00007b1fbf9def62  pop r10
00007b1fbf9def64  pop r9
00007b1fbf9def66  pop r8
00007b1fbf9def68  pop rsi
00007b1fbf9def69  pop rdi
00007b1fbf9def6a  pop rdx
00007b1fbf9def6b  pop rcx
00007b1fbf9def6c  pop rax
00007b1fbf9def6d  add rsp, 0x08
00007b1fbf9def71  jmp 0x00007B1FBF9DC31E
00007b1fbf9def76  sub rsp, 0x08
00007b1fbf9def7a  push rax
00007b1fbf9def7b  push rcx
00007b1fbf9def7c  push rdx
00007b1fbf9def7d  push rdi
00007b1fbf9def7e  push rsi
00007b1fbf9def7f  push r8
00007b1fbf9def81  push r9
00007b1fbf9def83  push r10
00007b1fbf9def85  push r11
00007b1fbf9def87  sub rsp, 0xF0
00007b1fbf9def8e  vmovaps [rsp], xmm0
00007b1fbf9def93  vmovaps [rsp+0x10], xmm1
00007b1fbf9def99  vmovaps [rsp+0x20], xmm2
00007b1fbf9def9f  vmovaps [rsp+0x30], xmm3
00007b1fbf9defa5  vmovaps [rsp+0x40], xmm4
00007b1fbf9defab  vmovaps [rsp+0x50], xmm5
00007b1fbf9defb1  vmovaps [rsp+0x60], xmm6
00007b1fbf9defb7  vmovaps [rsp+0x70], xmm7
00007b1fbf9defbd  vmovaps [rsp+0x80], xmm8
00007b1fbf9defc6  vmovaps [rsp+0x90], xmm10
00007b1fbf9defcf  vmovaps [rsp+0xA0], xmm11
00007b1fbf9defd8  vmovaps [rsp+0xB0], xmm12
00007b1fbf9defe1  vmovaps [rsp+0xC0], xmm13
00007b1fbf9defea  vmovaps [rsp+0xD0], xmm14
00007b1fbf9deff3  vmovaps [rsp+0xE0], xmm15
00007b1fbf9deffc  sub rsp, 0x30
00007b1fbf9df000  movaps [rsp], xmm9
00007b1fbf9df005  movaps [rsp+0x10], xmm2
00007b1fbf9df00a  movaps [rsp+0x20], xmm1
00007b1fbf9df00f  lea rdi, [rsp]
00007b1fbf9df013  mov esi, 0x00
00007b1fbf9df018  mov rax, 0x64AEE5F12530
00007b1fbf9df022  call rax
00007b1fbf9df024  movaps xmm9, [rsp]
00007b1fbf9df029  add rsp, 0x30
00007b1fbf9df02d  vmovaps xmm0, [rsp]
00007b1fbf9df032  vmovaps xmm1, [rsp+0x10]
00007b1fbf9df038  vmovaps xmm2, [rsp+0x20]
00007b1fbf9df03e  vmovaps xmm3, [rsp+0x30]
00007b1fbf9df044  vmovaps xmm4, [rsp+0x40]
00007b1fbf9df04a  vmovaps xmm5, [rsp+0x50]
00007b1fbf9df050  vmovaps xmm6, [rsp+0x60]
00007b1fbf9df056  vmovaps xmm7, [rsp+0x70]
00007b1fbf9df05c  vmovaps xmm8, [rsp+0x80]
00007b1fbf9df065  vmovaps xmm10, [rsp+0x90]
00007b1fbf9df06e  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9df077  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9df080  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9df089  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9df092  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9df09b  add rsp, 0xF0
00007b1fbf9df0a2  pop r11
00007b1fbf9df0a4  pop r10
00007b1fbf9df0a6  pop r9
00007b1fbf9df0a8  pop r8
00007b1fbf9df0aa  pop rsi
00007b1fbf9df0ab  pop rdi
00007b1fbf9df0ac  pop rdx
00007b1fbf9df0ad  pop rcx
00007b1fbf9df0ae  pop rax
00007b1fbf9df0af  add rsp, 0x08
00007b1fbf9df0b3  jmp 0x00007B1FBF9DC354
00007b1fbf9df0b8  sub rsp, 0x08
00007b1fbf9df0bc  push rax
00007b1fbf9df0bd  push rcx
00007b1fbf9df0be  push rdx
00007b1fbf9df0bf  push rdi
00007b1fbf9df0c0  push rsi
00007b1fbf9df0c1  push r8
00007b1fbf9df0c3  push r9
00007b1fbf9df0c5  push r10
00007b1fbf9df0c7  push r11
00007b1fbf9df0c9  sub rsp, 0xF0
00007b1fbf9df0d0  vmovaps [rsp], xmm0
00007b1fbf9df0d5  vmovaps [rsp+0x10], xmm2
00007b1fbf9df0db  vmovaps [rsp+0x20], xmm3
00007b1fbf9df0e1  vmovaps [rsp+0x30], xmm4
00007b1fbf9df0e7  vmovaps [rsp+0x40], xmm5
00007b1fbf9df0ed  vmovaps [rsp+0x50], xmm6
00007b1fbf9df0f3  vmovaps [rsp+0x60], xmm7
00007b1fbf9df0f9  vmovaps [rsp+0x70], xmm8
00007b1fbf9df0ff  vmovaps [rsp+0x80], xmm9
00007b1fbf9df108  vmovaps [rsp+0x90], xmm10
00007b1fbf9df111  vmovaps [rsp+0xA0], xmm11
00007b1fbf9df11a  vmovaps [rsp+0xB0], xmm12
00007b1fbf9df123  vmovaps [rsp+0xC0], xmm13
00007b1fbf9df12c  vmovaps [rsp+0xD0], xmm14
00007b1fbf9df135  vmovaps [rsp+0xE0], xmm15
00007b1fbf9df13e  sub rsp, 0x30
00007b1fbf9df142  movaps [rsp], xmm1
00007b1fbf9df146  movaps [rsp+0x10], xmm15
00007b1fbf9df14c  movaps [rsp+0x20], xmm6
00007b1fbf9df151  lea rdi, [rsp]
00007b1fbf9df155  mov esi, 0x00
00007b1fbf9df15a  mov rax, 0x64AEE5F12530
00007b1fbf9df164  call rax
00007b1fbf9df166  movaps xmm1, [rsp]
00007b1fbf9df16a  add rsp, 0x30
00007b1fbf9df16e  vmovaps xmm0, [rsp]
00007b1fbf9df173  vmovaps xmm2, [rsp+0x10]
00007b1fbf9df179  vmovaps xmm3, [rsp+0x20]
00007b1fbf9df17f  vmovaps xmm4, [rsp+0x30]
00007b1fbf9df185  vmovaps xmm5, [rsp+0x40]
00007b1fbf9df18b  vmovaps xmm6, [rsp+0x50]
00007b1fbf9df191  vmovaps xmm7, [rsp+0x60]
00007b1fbf9df197  vmovaps xmm8, [rsp+0x70]
00007b1fbf9df19d  vmovaps xmm9, [rsp+0x80]
00007b1fbf9df1a6  vmovaps xmm10, [rsp+0x90]
00007b1fbf9df1af  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9df1b8  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9df1c1  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9df1ca  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9df1d3  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9df1dc  add rsp, 0xF0
00007b1fbf9df1e3  pop r11
00007b1fbf9df1e5  pop r10
00007b1fbf9df1e7  pop r9
00007b1fbf9df1e9  pop r8
00007b1fbf9df1eb  pop rsi
00007b1fbf9df1ec  pop rdi
00007b1fbf9df1ed  pop rdx
00007b1fbf9df1ee  pop rcx
00007b1fbf9df1ef  pop rax
00007b1fbf9df1f0  add rsp, 0x08
00007b1fbf9df1f4  jmp 0x00007B1FBF9DC375
00007b1fbf9df1f9  sub rsp, 0x08
00007b1fbf9df1fd  push rax
00007b1fbf9df1fe  push rcx
00007b1fbf9df1ff  push rdx
00007b1fbf9df200  push rdi
00007b1fbf9df201  push rsi
00007b1fbf9df202  push r8
00007b1fbf9df204  push r9
00007b1fbf9df206  push r10
00007b1fbf9df208  push r11
00007b1fbf9df20a  sub rsp, 0xF0
00007b1fbf9df211  vmovaps [rsp], xmm0
00007b1fbf9df216  vmovaps [rsp+0x10], xmm1
00007b1fbf9df21c  vmovaps [rsp+0x20], xmm2
00007b1fbf9df222  vmovaps [rsp+0x30], xmm3
00007b1fbf9df228  vmovaps [rsp+0x40], xmm4
00007b1fbf9df22e  vmovaps [rsp+0x50], xmm5
00007b1fbf9df234  vmovaps [rsp+0x60], xmm6
00007b1fbf9df23a  vmovaps [rsp+0x70], xmm7
00007b1fbf9df240  vmovaps [rsp+0x80], xmm8
00007b1fbf9df249  vmovaps [rsp+0x90], xmm9
00007b1fbf9df252  vmovaps [rsp+0xA0], xmm10
00007b1fbf9df25b  vmovaps [rsp+0xB0], xmm11
00007b1fbf9df264  vmovaps [rsp+0xC0], xmm12
00007b1fbf9df26d  vmovaps [rsp+0xD0], xmm13
00007b1fbf9df276  vmovaps [rsp+0xE0], xmm14
00007b1fbf9df27f  sub rsp, 0x30
00007b1fbf9df283  movaps [rsp], xmm15
00007b1fbf9df288  movaps [rsp+0x10], xmm5
00007b1fbf9df28d  movaps [rsp+0x20], xmm3
00007b1fbf9df292  lea rdi, [rsp]
00007b1fbf9df296  mov esi, 0x00
00007b1fbf9df29b  mov rax, 0x64AEE5F12530
00007b1fbf9df2a5  call rax
00007b1fbf9df2a7  movaps xmm15, [rsp]
00007b1fbf9df2ac  add rsp, 0x30
00007b1fbf9df2b0  vmovaps xmm0, [rsp]
00007b1fbf9df2b5  vmovaps xmm1, [rsp+0x10]
00007b1fbf9df2bb  vmovaps xmm2, [rsp+0x20]
00007b1fbf9df2c1  vmovaps xmm3, [rsp+0x30]
00007b1fbf9df2c7  vmovaps xmm4, [rsp+0x40]
00007b1fbf9df2cd  vmovaps xmm5, [rsp+0x50]
00007b1fbf9df2d3  vmovaps xmm6, [rsp+0x60]
00007b1fbf9df2d9  vmovaps xmm7, [rsp+0x70]
00007b1fbf9df2df  vmovaps xmm8, [rsp+0x80]
00007b1fbf9df2e8  vmovaps xmm9, [rsp+0x90]
00007b1fbf9df2f1  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9df2fa  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9df303  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9df30c  vmovaps xmm13, [rsp+0xD0]
00007b1fbf9df315  vmovaps xmm14, [rsp+0xE0]
00007b1fbf9df31e  add rsp, 0xF0
00007b1fbf9df325  pop r11
00007b1fbf9df327  pop r10
00007b1fbf9df329  pop r9
00007b1fbf9df32b  pop r8
00007b1fbf9df32d  pop rsi
00007b1fbf9df32e  pop rdi
00007b1fbf9df32f  pop rdx
00007b1fbf9df330  pop rcx
00007b1fbf9df331  pop rax
00007b1fbf9df332  add rsp, 0x08
00007b1fbf9df336  jmp 0x00007B1FBF9DC38F
00007b1fbf9df33b  sub rsp, 0x08
00007b1fbf9df33f  push rax
00007b1fbf9df340  push rcx
00007b1fbf9df341  push rdx
00007b1fbf9df342  push rdi
00007b1fbf9df343  push rsi
00007b1fbf9df344  push r8
00007b1fbf9df346  push r9
00007b1fbf9df348  push r10
00007b1fbf9df34a  push r11
00007b1fbf9df34c  sub rsp, 0xF0
00007b1fbf9df353  vmovaps [rsp], xmm0
00007b1fbf9df358  vmovaps [rsp+0x10], xmm1
00007b1fbf9df35e  vmovaps [rsp+0x20], xmm2
00007b1fbf9df364  vmovaps [rsp+0x30], xmm3
00007b1fbf9df36a  vmovaps [rsp+0x40], xmm4
00007b1fbf9df370  vmovaps [rsp+0x50], xmm6
00007b1fbf9df376  vmovaps [rsp+0x60], xmm7
00007b1fbf9df37c  vmovaps [rsp+0x70], xmm8
00007b1fbf9df382  vmovaps [rsp+0x80], xmm9
00007b1fbf9df38b  vmovaps [rsp+0x90], xmm10
00007b1fbf9df394  vmovaps [rsp+0xA0], xmm11
00007b1fbf9df39d  vmovaps [rsp+0xB0], xmm12
00007b1fbf9df3a6  vmovaps [rsp+0xC0], xmm13
00007b1fbf9df3af  vmovaps [rsp+0xD0], xmm14
00007b1fbf9df3b8  vmovaps [rsp+0xE0], xmm15
00007b1fbf9df3c1  sub rsp, 0x30
00007b1fbf9df3c5  movaps [rsp], xmm5
00007b1fbf9df3c9  movaps [rsp+0x10], xmm8
00007b1fbf9df3cf  movaps [rsp+0x20], xmm6
00007b1fbf9df3d4  lea rdi, [rsp]
00007b1fbf9df3d8  mov esi, 0x00
00007b1fbf9df3dd  mov rax, 0x64AEE5F12530
00007b1fbf9df3e7  call rax
00007b1fbf9df3e9  movaps xmm5, [rsp]
00007b1fbf9df3ed  add rsp, 0x30
00007b1fbf9df3f1  vmovaps xmm0, [rsp]
00007b1fbf9df3f6  vmovaps xmm1, [rsp+0x10]
00007b1fbf9df3fc  vmovaps xmm2, [rsp+0x20]
00007b1fbf9df402  vmovaps xmm3, [rsp+0x30]
00007b1fbf9df408  vmovaps xmm4, [rsp+0x40]
00007b1fbf9df40e  vmovaps xmm6, [rsp+0x50]
00007b1fbf9df414  vmovaps xmm7, [rsp+0x60]
00007b1fbf9df41a  vmovaps xmm8, [rsp+0x70]
00007b1fbf9df420  vmovaps xmm9, [rsp+0x80]
00007b1fbf9df429  vmovaps xmm10, [rsp+0x90]
00007b1fbf9df432  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9df43b  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9df444  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9df44d  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9df456  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9df45f  add rsp, 0xF0
00007b1fbf9df466  pop r11
00007b1fbf9df468  pop r10
00007b1fbf9df46a  pop r9
00007b1fbf9df46c  pop r8
00007b1fbf9df46e  pop rsi
00007b1fbf9df46f  pop rdi
00007b1fbf9df470  pop rdx
00007b1fbf9df471  pop rcx
00007b1fbf9df472  pop rax
00007b1fbf9df473  add rsp, 0x08
00007b1fbf9df477  jmp 0x00007B1FBF9DC3B3
00007b1fbf9df47c  sub rsp, 0x08
00007b1fbf9df480  push rax
00007b1fbf9df481  push rcx
00007b1fbf9df482  push rdx
00007b1fbf9df483  push rdi
00007b1fbf9df484  push rsi
00007b1fbf9df485  push r8
00007b1fbf9df487  push r9
00007b1fbf9df489  push r10
00007b1fbf9df48b  push r11
00007b1fbf9df48d  sub rsp, 0xF0
00007b1fbf9df494  vmovaps [rsp], xmm0
00007b1fbf9df499  vmovaps [rsp+0x10], xmm1
00007b1fbf9df49f  vmovaps [rsp+0x20], xmm2
00007b1fbf9df4a5  vmovaps [rsp+0x30], xmm3
00007b1fbf9df4ab  vmovaps [rsp+0x40], xmm4
00007b1fbf9df4b1  vmovaps [rsp+0x50], xmm5
00007b1fbf9df4b7  vmovaps [rsp+0x60], xmm7
00007b1fbf9df4bd  vmovaps [rsp+0x70], xmm8
00007b1fbf9df4c3  vmovaps [rsp+0x80], xmm9
00007b1fbf9df4cc  vmovaps [rsp+0x90], xmm10
00007b1fbf9df4d5  vmovaps [rsp+0xA0], xmm11
00007b1fbf9df4de  vmovaps [rsp+0xB0], xmm12
00007b1fbf9df4e7  vmovaps [rsp+0xC0], xmm13
00007b1fbf9df4f0  vmovaps [rsp+0xD0], xmm14
00007b1fbf9df4f9  vmovaps [rsp+0xE0], xmm15
00007b1fbf9df502  sub rsp, 0x30
00007b1fbf9df506  movaps [rsp], xmm6
00007b1fbf9df50a  movaps [rsp+0x10], xmm10
00007b1fbf9df510  movaps [rsp+0x20], xmm8
00007b1fbf9df516  lea rdi, [rsp]
00007b1fbf9df51a  mov esi, 0x00
00007b1fbf9df51f  mov rax, 0x64AEE5F12530
00007b1fbf9df529  call rax
00007b1fbf9df52b  movaps xmm6, [rsp]
00007b1fbf9df52f  add rsp, 0x30
00007b1fbf9df533  vmovaps xmm0, [rsp]
00007b1fbf9df538  vmovaps xmm1, [rsp+0x10]
00007b1fbf9df53e  vmovaps xmm2, [rsp+0x20]
00007b1fbf9df544  vmovaps xmm3, [rsp+0x30]
00007b1fbf9df54a  vmovaps xmm4, [rsp+0x40]
00007b1fbf9df550  vmovaps xmm5, [rsp+0x50]
00007b1fbf9df556  vmovaps xmm7, [rsp+0x60]
00007b1fbf9df55c  vmovaps xmm8, [rsp+0x70]
00007b1fbf9df562  vmovaps xmm9, [rsp+0x80]
00007b1fbf9df56b  vmovaps xmm10, [rsp+0x90]
00007b1fbf9df574  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9df57d  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9df586  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9df58f  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9df598  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9df5a1  add rsp, 0xF0
00007b1fbf9df5a8  pop r11
00007b1fbf9df5aa  pop r10
00007b1fbf9df5ac  pop r9
00007b1fbf9df5ae  pop r8
00007b1fbf9df5b0  pop rsi
00007b1fbf9df5b1  pop rdi
00007b1fbf9df5b2  pop rdx
00007b1fbf9df5b3  pop rcx
00007b1fbf9df5b4  pop rax
00007b1fbf9df5b5  add rsp, 0x08
00007b1fbf9df5b9  jmp 0x00007B1FBF9DC3D8
00007b1fbf9df5be  sub rsp, 0x08
00007b1fbf9df5c2  push rax
00007b1fbf9df5c3  push rcx
00007b1fbf9df5c4  push rdx
00007b1fbf9df5c5  push rdi
00007b1fbf9df5c6  push rsi
00007b1fbf9df5c7  push r8
00007b1fbf9df5c9  push r9
00007b1fbf9df5cb  push r10
00007b1fbf9df5cd  push r11
00007b1fbf9df5cf  sub rsp, 0xF0
00007b1fbf9df5d6  vmovaps [rsp], xmm0
00007b1fbf9df5db  vmovaps [rsp+0x10], xmm1
00007b1fbf9df5e1  vmovaps [rsp+0x20], xmm2
00007b1fbf9df5e7  vmovaps [rsp+0x30], xmm3
00007b1fbf9df5ed  vmovaps [rsp+0x40], xmm4
00007b1fbf9df5f3  vmovaps [rsp+0x50], xmm5
00007b1fbf9df5f9  vmovaps [rsp+0x60], xmm6
00007b1fbf9df5ff  vmovaps [rsp+0x70], xmm7
00007b1fbf9df605  vmovaps [rsp+0x80], xmm8
00007b1fbf9df60e  vmovaps [rsp+0x90], xmm9
00007b1fbf9df617  vmovaps [rsp+0xA0], xmm11
00007b1fbf9df620  vmovaps [rsp+0xB0], xmm12
00007b1fbf9df629  vmovaps [rsp+0xC0], xmm13
00007b1fbf9df632  vmovaps [rsp+0xD0], xmm14
00007b1fbf9df63b  vmovaps [rsp+0xE0], xmm15
00007b1fbf9df644  sub rsp, 0x30
00007b1fbf9df648  movaps [rsp], xmm10
00007b1fbf9df64d  movaps [rsp+0x10], xmm8
00007b1fbf9df653  movaps [rsp+0x20], xmm14
00007b1fbf9df659  lea rdi, [rsp]
00007b1fbf9df65d  mov esi, 0x00
00007b1fbf9df662  mov rax, 0x64AEE5F12530
00007b1fbf9df66c  call rax
00007b1fbf9df66e  movaps xmm10, [rsp]
00007b1fbf9df673  add rsp, 0x30
00007b1fbf9df677  vmovaps xmm0, [rsp]
00007b1fbf9df67c  vmovaps xmm1, [rsp+0x10]
00007b1fbf9df682  vmovaps xmm2, [rsp+0x20]
00007b1fbf9df688  vmovaps xmm3, [rsp+0x30]
00007b1fbf9df68e  vmovaps xmm4, [rsp+0x40]
00007b1fbf9df694  vmovaps xmm5, [rsp+0x50]
00007b1fbf9df69a  vmovaps xmm6, [rsp+0x60]
00007b1fbf9df6a0  vmovaps xmm7, [rsp+0x70]
00007b1fbf9df6a6  vmovaps xmm8, [rsp+0x80]
00007b1fbf9df6af  vmovaps xmm9, [rsp+0x90]
00007b1fbf9df6b8  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9df6c1  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9df6ca  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9df6d3  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9df6dc  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9df6e5  add rsp, 0xF0
00007b1fbf9df6ec  pop r11
00007b1fbf9df6ee  pop r10
00007b1fbf9df6f0  pop r9
00007b1fbf9df6f2  pop r8
00007b1fbf9df6f4  pop rsi
00007b1fbf9df6f5  pop rdi
00007b1fbf9df6f6  pop rdx
00007b1fbf9df6f7  pop rcx
00007b1fbf9df6f8  pop rax
00007b1fbf9df6f9  add rsp, 0x08
00007b1fbf9df6fd  jmp 0x00007B1FBF9DC3F8
00007b1fbf9df702  sub rsp, 0x08
00007b1fbf9df706  push rax
00007b1fbf9df707  push rcx
00007b1fbf9df708  push rdx
00007b1fbf9df709  push rdi
00007b1fbf9df70a  push rsi
00007b1fbf9df70b  push r8
00007b1fbf9df70d  push r9
00007b1fbf9df70f  push r10
00007b1fbf9df711  push r11
00007b1fbf9df713  sub rsp, 0xF0
00007b1fbf9df71a  vmovaps [rsp], xmm0
00007b1fbf9df71f  vmovaps [rsp+0x10], xmm1
00007b1fbf9df725  vmovaps [rsp+0x20], xmm2
00007b1fbf9df72b  vmovaps [rsp+0x30], xmm3
00007b1fbf9df731  vmovaps [rsp+0x40], xmm4
00007b1fbf9df737  vmovaps [rsp+0x50], xmm5
00007b1fbf9df73d  vmovaps [rsp+0x60], xmm6
00007b1fbf9df743  vmovaps [rsp+0x70], xmm7
00007b1fbf9df749  vmovaps [rsp+0x80], xmm8
00007b1fbf9df752  vmovaps [rsp+0x90], xmm9
00007b1fbf9df75b  vmovaps [rsp+0xA0], xmm10
00007b1fbf9df764  vmovaps [rsp+0xB0], xmm11
00007b1fbf9df76d  vmovaps [rsp+0xC0], xmm12
00007b1fbf9df776  vmovaps [rsp+0xD0], xmm13
00007b1fbf9df77f  vmovaps [rsp+0xE0], xmm15
00007b1fbf9df788  sub rsp, 0x30
00007b1fbf9df78c  movaps [rsp], xmm14
00007b1fbf9df791  movaps [rsp+0x10], xmm8
00007b1fbf9df797  movaps [rsp+0x20], xmm4
00007b1fbf9df79c  lea rdi, [rsp]
00007b1fbf9df7a0  mov esi, 0x00
00007b1fbf9df7a5  mov rax, 0x64AEE5F12530
00007b1fbf9df7af  call rax
00007b1fbf9df7b1  movaps xmm14, [rsp]
00007b1fbf9df7b6  add rsp, 0x30
00007b1fbf9df7ba  vmovaps xmm0, [rsp]
00007b1fbf9df7bf  vmovaps xmm1, [rsp+0x10]
00007b1fbf9df7c5  vmovaps xmm2, [rsp+0x20]
00007b1fbf9df7cb  vmovaps xmm3, [rsp+0x30]
00007b1fbf9df7d1  vmovaps xmm4, [rsp+0x40]
00007b1fbf9df7d7  vmovaps xmm5, [rsp+0x50]
00007b1fbf9df7dd  vmovaps xmm6, [rsp+0x60]
00007b1fbf9df7e3  vmovaps xmm7, [rsp+0x70]
00007b1fbf9df7e9  vmovaps xmm8, [rsp+0x80]
00007b1fbf9df7f2  vmovaps xmm9, [rsp+0x90]
00007b1fbf9df7fb  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9df804  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9df80d  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9df816  vmovaps xmm13, [rsp+0xD0]
00007b1fbf9df81f  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9df828  add rsp, 0xF0
00007b1fbf9df82f  pop r11
00007b1fbf9df831  pop r10
00007b1fbf9df833  pop r9
00007b1fbf9df835  pop r8
00007b1fbf9df837  pop rsi
00007b1fbf9df838  pop rdi
00007b1fbf9df839  pop rdx
00007b1fbf9df83a  pop rcx
00007b1fbf9df83b  pop rax
00007b1fbf9df83c  add rsp, 0x08
00007b1fbf9df840  jmp 0x00007B1FBF9DC418
00007b1fbf9df845  sub rsp, 0x08
00007b1fbf9df849  push rax
00007b1fbf9df84a  push rcx
00007b1fbf9df84b  push rdx
00007b1fbf9df84c  push rdi
00007b1fbf9df84d  push rsi
00007b1fbf9df84e  push r8
00007b1fbf9df850  push r9
00007b1fbf9df852  push r10
00007b1fbf9df854  push r11
00007b1fbf9df856  sub rsp, 0xF0
00007b1fbf9df85d  vmovaps [rsp], xmm0
00007b1fbf9df862  vmovaps [rsp+0x10], xmm1
00007b1fbf9df868  vmovaps [rsp+0x20], xmm2
00007b1fbf9df86e  vmovaps [rsp+0x30], xmm3
00007b1fbf9df874  vmovaps [rsp+0x40], xmm5
00007b1fbf9df87a  vmovaps [rsp+0x50], xmm6
00007b1fbf9df880  vmovaps [rsp+0x60], xmm7
00007b1fbf9df886  vmovaps [rsp+0x70], xmm8
00007b1fbf9df88c  vmovaps [rsp+0x80], xmm9
00007b1fbf9df895  vmovaps [rsp+0x90], xmm10
00007b1fbf9df89e  vmovaps [rsp+0xA0], xmm11
00007b1fbf9df8a7  vmovaps [rsp+0xB0], xmm12
00007b1fbf9df8b0  vmovaps [rsp+0xC0], xmm13
00007b1fbf9df8b9  vmovaps [rsp+0xD0], xmm14
00007b1fbf9df8c2  vmovaps [rsp+0xE0], xmm15
00007b1fbf9df8cb  sub rsp, 0x30
00007b1fbf9df8cf  movaps [rsp], xmm4
00007b1fbf9df8d3  movaps [rsp+0x10], xmm13
00007b1fbf9df8d9  movaps [rsp+0x20], xmm8
00007b1fbf9df8df  lea rdi, [rsp]
00007b1fbf9df8e3  mov esi, 0x00
00007b1fbf9df8e8  mov rax, 0x64AEE5F12530
00007b1fbf9df8f2  call rax
00007b1fbf9df8f4  movaps xmm4, [rsp]
00007b1fbf9df8f8  add rsp, 0x30
00007b1fbf9df8fc  vmovaps xmm0, [rsp]
00007b1fbf9df901  vmovaps xmm1, [rsp+0x10]
00007b1fbf9df907  vmovaps xmm2, [rsp+0x20]
00007b1fbf9df90d  vmovaps xmm3, [rsp+0x30]
00007b1fbf9df913  vmovaps xmm5, [rsp+0x40]
00007b1fbf9df919  vmovaps xmm6, [rsp+0x50]
00007b1fbf9df91f  vmovaps xmm7, [rsp+0x60]
00007b1fbf9df925  vmovaps xmm8, [rsp+0x70]
00007b1fbf9df92b  vmovaps xmm9, [rsp+0x80]
00007b1fbf9df934  vmovaps xmm10, [rsp+0x90]
00007b1fbf9df93d  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9df946  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9df94f  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9df958  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9df961  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9df96a  add rsp, 0xF0
00007b1fbf9df971  pop r11
00007b1fbf9df973  pop r10
00007b1fbf9df975  pop r9
00007b1fbf9df977  pop r8
00007b1fbf9df979  pop rsi
00007b1fbf9df97a  pop rdi
00007b1fbf9df97b  pop rdx
00007b1fbf9df97c  pop rcx
00007b1fbf9df97d  pop rax
00007b1fbf9df97e  add rsp, 0x08
00007b1fbf9df982  jmp 0x00007B1FBF9DC43D
00007b1fbf9df987  sub rsp, 0x08
00007b1fbf9df98b  push rax
00007b1fbf9df98c  push rcx
00007b1fbf9df98d  push rdx
00007b1fbf9df98e  push rdi
00007b1fbf9df98f  push rsi
00007b1fbf9df990  push r8
00007b1fbf9df992  push r9
00007b1fbf9df994  push r10
00007b1fbf9df996  push r11
00007b1fbf9df998  sub rsp, 0xF0
00007b1fbf9df99f  vmovaps [rsp], xmm0
00007b1fbf9df9a4  vmovaps [rsp+0x10], xmm1
00007b1fbf9df9aa  vmovaps [rsp+0x20], xmm2
00007b1fbf9df9b0  vmovaps [rsp+0x30], xmm3
00007b1fbf9df9b6  vmovaps [rsp+0x40], xmm4
00007b1fbf9df9bc  vmovaps [rsp+0x50], xmm5
00007b1fbf9df9c2  vmovaps [rsp+0x60], xmm6
00007b1fbf9df9c8  vmovaps [rsp+0x70], xmm7
00007b1fbf9df9ce  vmovaps [rsp+0x80], xmm8
00007b1fbf9df9d7  vmovaps [rsp+0x90], xmm9
00007b1fbf9df9e0  vmovaps [rsp+0xA0], xmm10
00007b1fbf9df9e9  vmovaps [rsp+0xB0], xmm11
00007b1fbf9df9f2  vmovaps [rsp+0xC0], xmm12
00007b1fbf9df9fb  vmovaps [rsp+0xD0], xmm14
00007b1fbf9dfa04  vmovaps [rsp+0xE0], xmm15
00007b1fbf9dfa0d  sub rsp, 0x30
00007b1fbf9dfa11  movaps [rsp], xmm13
00007b1fbf9dfa16  movaps [rsp+0x10], xmm15
00007b1fbf9dfa1c  movaps [rsp+0x20], xmm9
00007b1fbf9dfa22  lea rdi, [rsp]
00007b1fbf9dfa26  mov esi, 0x00
00007b1fbf9dfa2b  mov rax, 0x64AEE5F12530
00007b1fbf9dfa35  call rax
00007b1fbf9dfa37  movaps xmm13, [rsp]
00007b1fbf9dfa3c  add rsp, 0x30
00007b1fbf9dfa40  vmovaps xmm0, [rsp]
00007b1fbf9dfa45  vmovaps xmm1, [rsp+0x10]
00007b1fbf9dfa4b  vmovaps xmm2, [rsp+0x20]
00007b1fbf9dfa51  vmovaps xmm3, [rsp+0x30]
00007b1fbf9dfa57  vmovaps xmm4, [rsp+0x40]
00007b1fbf9dfa5d  vmovaps xmm5, [rsp+0x50]
00007b1fbf9dfa63  vmovaps xmm6, [rsp+0x60]
00007b1fbf9dfa69  vmovaps xmm7, [rsp+0x70]
00007b1fbf9dfa6f  vmovaps xmm8, [rsp+0x80]
00007b1fbf9dfa78  vmovaps xmm9, [rsp+0x90]
00007b1fbf9dfa81  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9dfa8a  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9dfa93  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9dfa9c  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9dfaa5  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9dfaae  add rsp, 0xF0
00007b1fbf9dfab5  pop r11
00007b1fbf9dfab7  pop r10
00007b1fbf9dfab9  pop r9
00007b1fbf9dfabb  pop r8
00007b1fbf9dfabd  pop rsi
00007b1fbf9dfabe  pop rdi
00007b1fbf9dfabf  pop rdx
00007b1fbf9dfac0  pop rcx
00007b1fbf9dfac1  pop rax
00007b1fbf9dfac2  add rsp, 0x08
00007b1fbf9dfac6  jmp 0x00007B1FBF9DC458
00007b1fbf9dfacb  sub rsp, 0x08
00007b1fbf9dfacf  push rax
00007b1fbf9dfad0  push rcx
00007b1fbf9dfad1  push rdx
00007b1fbf9dfad2  push rdi
00007b1fbf9dfad3  push rsi
00007b1fbf9dfad4  push r8
00007b1fbf9dfad6  push r9
00007b1fbf9dfad8  push r10
00007b1fbf9dfada  push r11
00007b1fbf9dfadc  sub rsp, 0xF0
00007b1fbf9dfae3  vmovaps [rsp], xmm0
00007b1fbf9dfae8  vmovaps [rsp+0x10], xmm1
00007b1fbf9dfaee  vmovaps [rsp+0x20], xmm2
00007b1fbf9dfaf4  vmovaps [rsp+0x30], xmm3
00007b1fbf9dfafa  vmovaps [rsp+0x40], xmm4
00007b1fbf9dfb00  vmovaps [rsp+0x50], xmm5
00007b1fbf9dfb06  vmovaps [rsp+0x60], xmm6
00007b1fbf9dfb0c  vmovaps [rsp+0x70], xmm7
00007b1fbf9dfb12  vmovaps [rsp+0x80], xmm8
00007b1fbf9dfb1b  vmovaps [rsp+0x90], xmm9
00007b1fbf9dfb24  vmovaps [rsp+0xA0], xmm10
00007b1fbf9dfb2d  vmovaps [rsp+0xB0], xmm11
00007b1fbf9dfb36  vmovaps [rsp+0xC0], xmm12
00007b1fbf9dfb3f  vmovaps [rsp+0xD0], xmm13
00007b1fbf9dfb48  vmovaps [rsp+0xE0], xmm14
00007b1fbf9dfb51  sub rsp, 0x30
00007b1fbf9dfb55  movaps [rsp], xmm15
00007b1fbf9dfb5a  movaps [rsp+0x10], xmm1
00007b1fbf9dfb5f  movaps [rsp+0x20], xmm5
00007b1fbf9dfb64  lea rdi, [rsp]
00007b1fbf9dfb68  mov esi, 0x00
00007b1fbf9dfb6d  mov rax, 0x64AEE5F12530
00007b1fbf9dfb77  call rax
00007b1fbf9dfb79  movaps xmm15, [rsp]
00007b1fbf9dfb7e  add rsp, 0x30
00007b1fbf9dfb82  vmovaps xmm0, [rsp]
00007b1fbf9dfb87  vmovaps xmm1, [rsp+0x10]
00007b1fbf9dfb8d  vmovaps xmm2, [rsp+0x20]
00007b1fbf9dfb93  vmovaps xmm3, [rsp+0x30]
00007b1fbf9dfb99  vmovaps xmm4, [rsp+0x40]
00007b1fbf9dfb9f  vmovaps xmm5, [rsp+0x50]
00007b1fbf9dfba5  vmovaps xmm6, [rsp+0x60]
00007b1fbf9dfbab  vmovaps xmm7, [rsp+0x70]
00007b1fbf9dfbb1  vmovaps xmm8, [rsp+0x80]
00007b1fbf9dfbba  vmovaps xmm9, [rsp+0x90]
00007b1fbf9dfbc3  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9dfbcc  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9dfbd5  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9dfbde  vmovaps xmm13, [rsp+0xD0]
00007b1fbf9dfbe7  vmovaps xmm14, [rsp+0xE0]
00007b1fbf9dfbf0  add rsp, 0xF0
00007b1fbf9dfbf7  pop r11
00007b1fbf9dfbf9  pop r10
00007b1fbf9dfbfb  pop r9
00007b1fbf9dfbfd  pop r8
00007b1fbf9dfbff  pop rsi
00007b1fbf9dfc00  pop rdi
00007b1fbf9dfc01  pop rdx
00007b1fbf9dfc02  pop rcx
00007b1fbf9dfc03  pop rax
00007b1fbf9dfc04  add rsp, 0x08
00007b1fbf9dfc08  jmp 0x00007B1FBF9DC473
00007b1fbf9dfc0d  call 0x00007B1FBF8B52F0
00007b1fbf9dfc12  jmp 0x00007B1FBF9DC4CE
00007b1fbf9dfc17  sub rsp, 0x08
00007b1fbf9dfc1b  push rax
00007b1fbf9dfc1c  push rcx
00007b1fbf9dfc1d  push rdx
00007b1fbf9dfc1e  push rdi
00007b1fbf9dfc1f  push rsi
00007b1fbf9dfc20  push r8
00007b1fbf9dfc22  push r9
00007b1fbf9dfc24  push r10
00007b1fbf9dfc26  push r11
00007b1fbf9dfc28  sub rsp, 0xF0
00007b1fbf9dfc2f  vmovaps [rsp], xmm0
00007b1fbf9dfc34  vmovaps [rsp+0x10], xmm1
00007b1fbf9dfc3a  vmovaps [rsp+0x20], xmm2
00007b1fbf9dfc40  vmovaps [rsp+0x30], xmm3
00007b1fbf9dfc46  vmovaps [rsp+0x40], xmm4
00007b1fbf9dfc4c  vmovaps [rsp+0x50], xmm5
00007b1fbf9dfc52  vmovaps [rsp+0x60], xmm6
00007b1fbf9dfc58  vmovaps [rsp+0x70], xmm7
00007b1fbf9dfc5e  vmovaps [rsp+0x80], xmm8
00007b1fbf9dfc67  vmovaps [rsp+0x90], xmm10
00007b1fbf9dfc70  vmovaps [rsp+0xA0], xmm11
00007b1fbf9dfc79  vmovaps [rsp+0xB0], xmm12
00007b1fbf9dfc82  vmovaps [rsp+0xC0], xmm13
00007b1fbf9dfc8b  vmovaps [rsp+0xD0], xmm14
00007b1fbf9dfc94  vmovaps [rsp+0xE0], xmm15
00007b1fbf9dfc9d  sub rsp, 0x30
00007b1fbf9dfca1  movaps [rsp], xmm9
00007b1fbf9dfca6  movaps [rsp+0x10], xmm8
00007b1fbf9dfcac  movaps [rsp+0x20], xmm11
00007b1fbf9dfcb2  lea rdi, [rsp]
00007b1fbf9dfcb6  mov esi, 0x00
00007b1fbf9dfcbb  mov rax, 0x64AEE5F12530
00007b1fbf9dfcc5  call rax
00007b1fbf9dfcc7  movaps xmm9, [rsp]
00007b1fbf9dfccc  add rsp, 0x30
00007b1fbf9dfcd0  vmovaps xmm0, [rsp]
00007b1fbf9dfcd5  vmovaps xmm1, [rsp+0x10]
00007b1fbf9dfcdb  vmovaps xmm2, [rsp+0x20]
00007b1fbf9dfce1  vmovaps xmm3, [rsp+0x30]
00007b1fbf9dfce7  vmovaps xmm4, [rsp+0x40]
00007b1fbf9dfced  vmovaps xmm5, [rsp+0x50]
00007b1fbf9dfcf3  vmovaps xmm6, [rsp+0x60]
00007b1fbf9dfcf9  vmovaps xmm7, [rsp+0x70]
00007b1fbf9dfcff  vmovaps xmm8, [rsp+0x80]
00007b1fbf9dfd08  vmovaps xmm10, [rsp+0x90]
00007b1fbf9dfd11  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9dfd1a  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9dfd23  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9dfd2c  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9dfd35  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9dfd3e  add rsp, 0xF0
00007b1fbf9dfd45  pop r11
00007b1fbf9dfd47  pop r10
00007b1fbf9dfd49  pop r9
00007b1fbf9dfd4b  pop r8
00007b1fbf9dfd4d  pop rsi
00007b1fbf9dfd4e  pop rdi
00007b1fbf9dfd4f  pop rdx
00007b1fbf9dfd50  pop rcx
00007b1fbf9dfd51  pop rax
00007b1fbf9dfd52  add rsp, 0x08
00007b1fbf9dfd56  jmp 0x00007B1FBF9DC505
00007b1fbf9dfd5b  sub rsp, 0x08
00007b1fbf9dfd5f  push rax
00007b1fbf9dfd60  push rcx
00007b1fbf9dfd61  push rdx
00007b1fbf9dfd62  push rdi
00007b1fbf9dfd63  push rsi
00007b1fbf9dfd64  push r8
00007b1fbf9dfd66  push r9
00007b1fbf9dfd68  push r10
00007b1fbf9dfd6a  push r11
00007b1fbf9dfd6c  sub rsp, 0xF0
00007b1fbf9dfd73  vmovaps [rsp], xmm0
00007b1fbf9dfd78  vmovaps [rsp+0x10], xmm1
00007b1fbf9dfd7e  vmovaps [rsp+0x20], xmm2
00007b1fbf9dfd84  vmovaps [rsp+0x30], xmm3
00007b1fbf9dfd8a  vmovaps [rsp+0x40], xmm4
00007b1fbf9dfd90  vmovaps [rsp+0x50], xmm5
00007b1fbf9dfd96  vmovaps [rsp+0x60], xmm6
00007b1fbf9dfd9c  vmovaps [rsp+0x70], xmm7
00007b1fbf9dfda2  vmovaps [rsp+0x80], xmm8
00007b1fbf9dfdab  vmovaps [rsp+0x90], xmm9
00007b1fbf9dfdb4  vmovaps [rsp+0xA0], xmm10
00007b1fbf9dfdbd  vmovaps [rsp+0xB0], xmm12
00007b1fbf9dfdc6  vmovaps [rsp+0xC0], xmm13
00007b1fbf9dfdcf  vmovaps [rsp+0xD0], xmm14
00007b1fbf9dfdd8  vmovaps [rsp+0xE0], xmm15
00007b1fbf9dfde1  sub rsp, 0x30
00007b1fbf9dfde5  movaps [rsp], xmm11
00007b1fbf9dfdea  movaps [rsp+0x10], xmm10
00007b1fbf9dfdf0  movaps [rsp+0x20], xmm6
00007b1fbf9dfdf5  lea rdi, [rsp]
00007b1fbf9dfdf9  mov esi, 0x00
00007b1fbf9dfdfe  mov rax, 0x64AEE5F12530
00007b1fbf9dfe08  call rax
00007b1fbf9dfe0a  movaps xmm11, [rsp]
00007b1fbf9dfe0f  add rsp, 0x30
00007b1fbf9dfe13  vmovaps xmm0, [rsp]
00007b1fbf9dfe18  vmovaps xmm1, [rsp+0x10]
00007b1fbf9dfe1e  vmovaps xmm2, [rsp+0x20]
00007b1fbf9dfe24  vmovaps xmm3, [rsp+0x30]
00007b1fbf9dfe2a  vmovaps xmm4, [rsp+0x40]
00007b1fbf9dfe30  vmovaps xmm5, [rsp+0x50]
00007b1fbf9dfe36  vmovaps xmm6, [rsp+0x60]
00007b1fbf9dfe3c  vmovaps xmm7, [rsp+0x70]
00007b1fbf9dfe42  vmovaps xmm8, [rsp+0x80]
00007b1fbf9dfe4b  vmovaps xmm9, [rsp+0x90]
00007b1fbf9dfe54  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9dfe5d  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9dfe66  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9dfe6f  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9dfe78  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9dfe81  add rsp, 0xF0
00007b1fbf9dfe88  pop r11
00007b1fbf9dfe8a  pop r10
00007b1fbf9dfe8c  pop r9
00007b1fbf9dfe8e  pop r8
00007b1fbf9dfe90  pop rsi
00007b1fbf9dfe91  pop rdi
00007b1fbf9dfe92  pop rdx
00007b1fbf9dfe93  pop rcx
00007b1fbf9dfe94  pop rax
00007b1fbf9dfe95  add rsp, 0x08
00007b1fbf9dfe99  jmp 0x00007B1FBF9DC520
00007b1fbf9dfe9e  sub rsp, 0x08
00007b1fbf9dfea2  push rax
00007b1fbf9dfea3  push rcx
00007b1fbf9dfea4  push rdx
00007b1fbf9dfea5  push rdi
00007b1fbf9dfea6  push rsi
00007b1fbf9dfea7  push r8
00007b1fbf9dfea9  push r9
00007b1fbf9dfeab  push r10
00007b1fbf9dfead  push r11
00007b1fbf9dfeaf  sub rsp, 0xF0
00007b1fbf9dfeb6  vmovaps [rsp], xmm0
00007b1fbf9dfebb  vmovaps [rsp+0x10], xmm1
00007b1fbf9dfec1  vmovaps [rsp+0x20], xmm2
00007b1fbf9dfec7  vmovaps [rsp+0x30], xmm3
00007b1fbf9dfecd  vmovaps [rsp+0x40], xmm4
00007b1fbf9dfed3  vmovaps [rsp+0x50], xmm5
00007b1fbf9dfed9  vmovaps [rsp+0x60], xmm6
00007b1fbf9dfedf  vmovaps [rsp+0x70], xmm7
00007b1fbf9dfee5  vmovaps [rsp+0x80], xmm8
00007b1fbf9dfeee  vmovaps [rsp+0x90], xmm9
00007b1fbf9dfef7  vmovaps [rsp+0xA0], xmm11
00007b1fbf9dff00  vmovaps [rsp+0xB0], xmm12
00007b1fbf9dff09  vmovaps [rsp+0xC0], xmm13
00007b1fbf9dff12  vmovaps [rsp+0xD0], xmm14
00007b1fbf9dff1b  vmovaps [rsp+0xE0], xmm15
00007b1fbf9dff24  sub rsp, 0x30
00007b1fbf9dff28  movaps [rsp], xmm10
00007b1fbf9dff2d  movaps [rsp+0x10], xmm14
00007b1fbf9dff33  movaps [rsp+0x20], xmm4
00007b1fbf9dff38  lea rdi, [rsp]
00007b1fbf9dff3c  mov esi, 0x00
00007b1fbf9dff41  mov rax, 0x64AEE5F12530
00007b1fbf9dff4b  call rax
00007b1fbf9dff4d  movaps xmm10, [rsp]
00007b1fbf9dff52  add rsp, 0x30
00007b1fbf9dff56  vmovaps xmm0, [rsp]
00007b1fbf9dff5b  vmovaps xmm1, [rsp+0x10]
00007b1fbf9dff61  vmovaps xmm2, [rsp+0x20]
00007b1fbf9dff67  vmovaps xmm3, [rsp+0x30]
00007b1fbf9dff6d  vmovaps xmm4, [rsp+0x40]
00007b1fbf9dff73  vmovaps xmm5, [rsp+0x50]
00007b1fbf9dff79  vmovaps xmm6, [rsp+0x60]
00007b1fbf9dff7f  vmovaps xmm7, [rsp+0x70]
00007b1fbf9dff85  vmovaps xmm8, [rsp+0x80]
00007b1fbf9dff8e  vmovaps xmm9, [rsp+0x90]
00007b1fbf9dff97  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9dffa0  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9dffa9  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9dffb2  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9dffbb  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9dffc4  add rsp, 0xF0
00007b1fbf9dffcb  pop r11
00007b1fbf9dffcd  pop r10
00007b1fbf9dffcf  pop r9
00007b1fbf9dffd1  pop r8
00007b1fbf9dffd3  pop rsi
00007b1fbf9dffd4  pop rdi
00007b1fbf9dffd5  pop rdx
00007b1fbf9dffd6  pop rcx
00007b1fbf9dffd7  pop rax
00007b1fbf9dffd8  add rsp, 0x08
00007b1fbf9dffdc  jmp 0x00007B1FBF9DC53B
00007b1fbf9dffe1  sub rsp, 0x08
00007b1fbf9dffe5  push rax
00007b1fbf9dffe6  push rcx
00007b1fbf9dffe7  push rdx
00007b1fbf9dffe8  push rdi
00007b1fbf9dffe9  push rsi
00007b1fbf9dffea  push r8
00007b1fbf9dffec  push r9
00007b1fbf9dffee  push r10
00007b1fbf9dfff0  push r11
00007b1fbf9dfff2  sub rsp, 0xF0
00007b1fbf9dfff9  vmovaps [rsp], xmm0
00007b1fbf9dfffe  vmovaps [rsp+0x10], xmm1
00007b1fbf9e0004  vmovaps [rsp+0x20], xmm2
00007b1fbf9e000a  vmovaps [rsp+0x30], xmm3
00007b1fbf9e0010  vmovaps [rsp+0x40], xmm4
00007b1fbf9e0016  vmovaps [rsp+0x50], xmm5
00007b1fbf9e001c  vmovaps [rsp+0x60], xmm6
00007b1fbf9e0022  vmovaps [rsp+0x70], xmm7
00007b1fbf9e0028  vmovaps [rsp+0x80], xmm9
00007b1fbf9e0031  vmovaps [rsp+0x90], xmm10
00007b1fbf9e003a  vmovaps [rsp+0xA0], xmm11
00007b1fbf9e0043  vmovaps [rsp+0xB0], xmm12
00007b1fbf9e004c  vmovaps [rsp+0xC0], xmm13
00007b1fbf9e0055  vmovaps [rsp+0xD0], xmm14
00007b1fbf9e005e  vmovaps [rsp+0xE0], xmm15
00007b1fbf9e0067  sub rsp, 0x30
00007b1fbf9e006b  movaps [rsp], xmm8
00007b1fbf9e0070  movaps [rsp+0x10], xmm1
00007b1fbf9e0075  movaps [rsp+0x20], xmm14
00007b1fbf9e007b  lea rdi, [rsp]
00007b1fbf9e007f  mov esi, 0x00
00007b1fbf9e0084  mov rax, 0x64AEE5F12530
00007b1fbf9e008e  call rax
00007b1fbf9e0090  movaps xmm8, [rsp]
00007b1fbf9e0095  add rsp, 0x30
00007b1fbf9e0099  vmovaps xmm0, [rsp]
00007b1fbf9e009e  vmovaps xmm1, [rsp+0x10]
00007b1fbf9e00a4  vmovaps xmm2, [rsp+0x20]
00007b1fbf9e00aa  vmovaps xmm3, [rsp+0x30]
00007b1fbf9e00b0  vmovaps xmm4, [rsp+0x40]
00007b1fbf9e00b6  vmovaps xmm5, [rsp+0x50]
00007b1fbf9e00bc  vmovaps xmm6, [rsp+0x60]
00007b1fbf9e00c2  vmovaps xmm7, [rsp+0x70]
00007b1fbf9e00c8  vmovaps xmm9, [rsp+0x80]
00007b1fbf9e00d1  vmovaps xmm10, [rsp+0x90]
00007b1fbf9e00da  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9e00e3  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9e00ec  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9e00f5  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9e00fe  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9e0107  add rsp, 0xF0
00007b1fbf9e010e  pop r11
00007b1fbf9e0110  pop r10
00007b1fbf9e0112  pop r9
00007b1fbf9e0114  pop r8
00007b1fbf9e0116  pop rsi
00007b1fbf9e0117  pop rdi
00007b1fbf9e0118  pop rdx
00007b1fbf9e0119  pop rcx
00007b1fbf9e011a  pop rax
00007b1fbf9e011b  add rsp, 0x08
00007b1fbf9e011f  jmp 0x00007B1FBF9DC561
00007b1fbf9e0124  sub rsp, 0x08
00007b1fbf9e0128  push rax
00007b1fbf9e0129  push rcx
00007b1fbf9e012a  push rdx
00007b1fbf9e012b  push rdi
00007b1fbf9e012c  push rsi
00007b1fbf9e012d  push r8
00007b1fbf9e012f  push r9
00007b1fbf9e0131  push r10
00007b1fbf9e0133  push r11
00007b1fbf9e0135  sub rsp, 0xF0
00007b1fbf9e013c  vmovaps [rsp], xmm0
00007b1fbf9e0141  vmovaps [rsp+0x10], xmm1
00007b1fbf9e0147  vmovaps [rsp+0x20], xmm2
00007b1fbf9e014d  vmovaps [rsp+0x30], xmm3
00007b1fbf9e0153  vmovaps [rsp+0x40], xmm4
00007b1fbf9e0159  vmovaps [rsp+0x50], xmm5
00007b1fbf9e015f  vmovaps [rsp+0x60], xmm7
00007b1fbf9e0165  vmovaps [rsp+0x70], xmm8
00007b1fbf9e016b  vmovaps [rsp+0x80], xmm9
00007b1fbf9e0174  vmovaps [rsp+0x90], xmm10
00007b1fbf9e017d  vmovaps [rsp+0xA0], xmm11
00007b1fbf9e0186  vmovaps [rsp+0xB0], xmm12
00007b1fbf9e018f  vmovaps [rsp+0xC0], xmm13
00007b1fbf9e0198  vmovaps [rsp+0xD0], xmm14
00007b1fbf9e01a1  vmovaps [rsp+0xE0], xmm15
00007b1fbf9e01aa  sub rsp, 0x30
00007b1fbf9e01ae  movaps [rsp], xmm6
00007b1fbf9e01b2  movaps [rsp+0x10], xmm1
00007b1fbf9e01b7  movaps [rsp+0x20], xmm14
00007b1fbf9e01bd  lea rdi, [rsp]
00007b1fbf9e01c1  mov esi, 0x00
00007b1fbf9e01c6  mov rax, 0x64AEE5F12530
00007b1fbf9e01d0  call rax
00007b1fbf9e01d2  movaps xmm6, [rsp]
00007b1fbf9e01d6  add rsp, 0x30
00007b1fbf9e01da  vmovaps xmm0, [rsp]
00007b1fbf9e01df  vmovaps xmm1, [rsp+0x10]
00007b1fbf9e01e5  vmovaps xmm2, [rsp+0x20]
00007b1fbf9e01eb  vmovaps xmm3, [rsp+0x30]
00007b1fbf9e01f1  vmovaps xmm4, [rsp+0x40]
00007b1fbf9e01f7  vmovaps xmm5, [rsp+0x50]
00007b1fbf9e01fd  vmovaps xmm7, [rsp+0x60]
00007b1fbf9e0203  vmovaps xmm8, [rsp+0x70]
00007b1fbf9e0209  vmovaps xmm9, [rsp+0x80]
00007b1fbf9e0212  vmovaps xmm10, [rsp+0x90]
00007b1fbf9e021b  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9e0224  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9e022d  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9e0236  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9e023f  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9e0248  add rsp, 0xF0
00007b1fbf9e024f  pop r11
00007b1fbf9e0251  pop r10
00007b1fbf9e0253  pop r9
00007b1fbf9e0255  pop r8
00007b1fbf9e0257  pop rsi
00007b1fbf9e0258  pop rdi
00007b1fbf9e0259  pop rdx
00007b1fbf9e025a  pop rcx
00007b1fbf9e025b  pop rax
00007b1fbf9e025c  add rsp, 0x08
00007b1fbf9e0260  jmp 0x00007B1FBF9DC58D
00007b1fbf9e0265  sub rsp, 0x08
00007b1fbf9e0269  push rax
00007b1fbf9e026a  push rcx
00007b1fbf9e026b  push rdx
00007b1fbf9e026c  push rdi
00007b1fbf9e026d  push rsi
00007b1fbf9e026e  push r8
00007b1fbf9e0270  push r9
00007b1fbf9e0272  push r10
00007b1fbf9e0274  push r11
00007b1fbf9e0276  sub rsp, 0xF0
00007b1fbf9e027d  vmovaps [rsp], xmm0
00007b1fbf9e0282  vmovaps [rsp+0x10], xmm1
00007b1fbf9e0288  vmovaps [rsp+0x20], xmm2
00007b1fbf9e028e  vmovaps [rsp+0x30], xmm3
00007b1fbf9e0294  vmovaps [rsp+0x40], xmm4
00007b1fbf9e029a  vmovaps [rsp+0x50], xmm5
00007b1fbf9e02a0  vmovaps [rsp+0x60], xmm6
00007b1fbf9e02a6  vmovaps [rsp+0x70], xmm7
00007b1fbf9e02ac  vmovaps [rsp+0x80], xmm8
00007b1fbf9e02b5  vmovaps [rsp+0x90], xmm9
00007b1fbf9e02be  vmovaps [rsp+0xA0], xmm10
00007b1fbf9e02c7  vmovaps [rsp+0xB0], xmm11
00007b1fbf9e02d0  vmovaps [rsp+0xC0], xmm12
00007b1fbf9e02d9  vmovaps [rsp+0xD0], xmm13
00007b1fbf9e02e2  vmovaps [rsp+0xE0], xmm15
00007b1fbf9e02eb  sub rsp, 0x30
00007b1fbf9e02ef  movaps [rsp], xmm14
00007b1fbf9e02f4  movaps [rsp+0x10], xmm12
00007b1fbf9e02fa  movaps [rsp+0x20], xmm1
00007b1fbf9e02ff  lea rdi, [rsp]
00007b1fbf9e0303  mov esi, 0x00
00007b1fbf9e0308  mov rax, 0x64AEE5F12530
00007b1fbf9e0312  call rax
00007b1fbf9e0314  movaps xmm14, [rsp]
00007b1fbf9e0319  add rsp, 0x30
00007b1fbf9e031d  vmovaps xmm0, [rsp]
00007b1fbf9e0322  vmovaps xmm1, [rsp+0x10]
00007b1fbf9e0328  vmovaps xmm2, [rsp+0x20]
00007b1fbf9e032e  vmovaps xmm3, [rsp+0x30]
00007b1fbf9e0334  vmovaps xmm4, [rsp+0x40]
00007b1fbf9e033a  vmovaps xmm5, [rsp+0x50]
00007b1fbf9e0340  vmovaps xmm6, [rsp+0x60]
00007b1fbf9e0346  vmovaps xmm7, [rsp+0x70]
00007b1fbf9e034c  vmovaps xmm8, [rsp+0x80]
00007b1fbf9e0355  vmovaps xmm9, [rsp+0x90]
00007b1fbf9e035e  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9e0367  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9e0370  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9e0379  vmovaps xmm13, [rsp+0xD0]
00007b1fbf9e0382  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9e038b  add rsp, 0xF0
00007b1fbf9e0392  pop r11
00007b1fbf9e0394  pop r10
00007b1fbf9e0396  pop r9
00007b1fbf9e0398  pop r8
00007b1fbf9e039a  pop rsi
00007b1fbf9e039b  pop rdi
00007b1fbf9e039c  pop rdx
00007b1fbf9e039d  pop rcx
00007b1fbf9e039e  pop rax
00007b1fbf9e039f  add rsp, 0x08
00007b1fbf9e03a3  jmp 0x00007B1FBF9DC5B3
00007b1fbf9e03a8  sub rsp, 0x08
00007b1fbf9e03ac  push rax
00007b1fbf9e03ad  push rcx
00007b1fbf9e03ae  push rdx
00007b1fbf9e03af  push rdi
00007b1fbf9e03b0  push rsi
00007b1fbf9e03b1  push r8
00007b1fbf9e03b3  push r9
00007b1fbf9e03b5  push r10
00007b1fbf9e03b7  push r11
00007b1fbf9e03b9  sub rsp, 0xF0
00007b1fbf9e03c0  vmovaps [rsp], xmm0
00007b1fbf9e03c5  vmovaps [rsp+0x10], xmm2
00007b1fbf9e03cb  vmovaps [rsp+0x20], xmm3
00007b1fbf9e03d1  vmovaps [rsp+0x30], xmm4
00007b1fbf9e03d7  vmovaps [rsp+0x40], xmm5
00007b1fbf9e03dd  vmovaps [rsp+0x50], xmm6
00007b1fbf9e03e3  vmovaps [rsp+0x60], xmm7
00007b1fbf9e03e9  vmovaps [rsp+0x70], xmm8
00007b1fbf9e03ef  vmovaps [rsp+0x80], xmm9
00007b1fbf9e03f8  vmovaps [rsp+0x90], xmm10
00007b1fbf9e0401  vmovaps [rsp+0xA0], xmm11
00007b1fbf9e040a  vmovaps [rsp+0xB0], xmm12
00007b1fbf9e0413  vmovaps [rsp+0xC0], xmm13
00007b1fbf9e041c  vmovaps [rsp+0xD0], xmm14
00007b1fbf9e0425  vmovaps [rsp+0xE0], xmm15
00007b1fbf9e042e  sub rsp, 0x30
00007b1fbf9e0432  movaps [rsp], xmm1
00007b1fbf9e0436  movaps [rsp+0x10], xmm13
00007b1fbf9e043c  movaps [rsp+0x20], xmm9
00007b1fbf9e0442  lea rdi, [rsp]
00007b1fbf9e0446  mov esi, 0x00
00007b1fbf9e044b  mov rax, 0x64AEE5F12530
00007b1fbf9e0455  call rax
00007b1fbf9e0457  movaps xmm1, [rsp]
00007b1fbf9e045b  add rsp, 0x30
00007b1fbf9e045f  vmovaps xmm0, [rsp]
00007b1fbf9e0464  vmovaps xmm2, [rsp+0x10]
00007b1fbf9e046a  vmovaps xmm3, [rsp+0x20]
00007b1fbf9e0470  vmovaps xmm4, [rsp+0x30]
00007b1fbf9e0476  vmovaps xmm5, [rsp+0x40]
00007b1fbf9e047c  vmovaps xmm6, [rsp+0x50]
00007b1fbf9e0482  vmovaps xmm7, [rsp+0x60]
00007b1fbf9e0488  vmovaps xmm8, [rsp+0x70]
00007b1fbf9e048e  vmovaps xmm9, [rsp+0x80]
00007b1fbf9e0497  vmovaps xmm10, [rsp+0x90]
00007b1fbf9e04a0  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9e04a9  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9e04b2  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9e04bb  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9e04c4  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9e04cd  add rsp, 0xF0
00007b1fbf9e04d4  pop r11
00007b1fbf9e04d6  pop r10
00007b1fbf9e04d8  pop r9
00007b1fbf9e04da  pop r8
00007b1fbf9e04dc  pop rsi
00007b1fbf9e04dd  pop rdi
00007b1fbf9e04de  pop rdx
00007b1fbf9e04df  pop rcx
00007b1fbf9e04e0  pop rax
00007b1fbf9e04e1  add rsp, 0x08
00007b1fbf9e04e5  jmp 0x00007B1FBF9DC5CD
00007b1fbf9e04ea  sub rsp, 0x08
00007b1fbf9e04ee  push rax
00007b1fbf9e04ef  push rcx
00007b1fbf9e04f0  push rdx
00007b1fbf9e04f1  push rdi
00007b1fbf9e04f2  push rsi
00007b1fbf9e04f3  push r8
00007b1fbf9e04f5  push r9
00007b1fbf9e04f7  push r10
00007b1fbf9e04f9  push r11
00007b1fbf9e04fb  sub rsp, 0xF0
00007b1fbf9e0502  vmovaps [rsp], xmm0
00007b1fbf9e0507  vmovaps [rsp+0x10], xmm1
00007b1fbf9e050d  vmovaps [rsp+0x20], xmm2
00007b1fbf9e0513  vmovaps [rsp+0x30], xmm3
00007b1fbf9e0519  vmovaps [rsp+0x40], xmm4
00007b1fbf9e051f  vmovaps [rsp+0x50], xmm5
00007b1fbf9e0525  vmovaps [rsp+0x60], xmm6
00007b1fbf9e052b  vmovaps [rsp+0x70], xmm7
00007b1fbf9e0531  vmovaps [rsp+0x80], xmm8
00007b1fbf9e053a  vmovaps [rsp+0x90], xmm9
00007b1fbf9e0543  vmovaps [rsp+0xA0], xmm10
00007b1fbf9e054c  vmovaps [rsp+0xB0], xmm11
00007b1fbf9e0555  vmovaps [rsp+0xC0], xmm13
00007b1fbf9e055e  vmovaps [rsp+0xD0], xmm14
00007b1fbf9e0567  vmovaps [rsp+0xE0], xmm15
00007b1fbf9e0570  sub rsp, 0x30
00007b1fbf9e0574  movaps [rsp], xmm12
00007b1fbf9e0579  movaps [rsp+0x10], xmm7
00007b1fbf9e057e  movaps [rsp+0x20], xmm13
00007b1fbf9e0584  lea rdi, [rsp]
00007b1fbf9e0588  mov esi, 0x00
00007b1fbf9e058d  mov rax, 0x64AEE5F12530
00007b1fbf9e0597  call rax
00007b1fbf9e0599  movaps xmm12, [rsp]
00007b1fbf9e059e  add rsp, 0x30
00007b1fbf9e05a2  vmovaps xmm0, [rsp]
00007b1fbf9e05a7  vmovaps xmm1, [rsp+0x10]
00007b1fbf9e05ad  vmovaps xmm2, [rsp+0x20]
00007b1fbf9e05b3  vmovaps xmm3, [rsp+0x30]
00007b1fbf9e05b9  vmovaps xmm4, [rsp+0x40]
00007b1fbf9e05bf  vmovaps xmm5, [rsp+0x50]
00007b1fbf9e05c5  vmovaps xmm6, [rsp+0x60]
00007b1fbf9e05cb  vmovaps xmm7, [rsp+0x70]
00007b1fbf9e05d1  vmovaps xmm8, [rsp+0x80]
00007b1fbf9e05da  vmovaps xmm9, [rsp+0x90]
00007b1fbf9e05e3  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9e05ec  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9e05f5  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9e05fe  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9e0607  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9e0610  add rsp, 0xF0
00007b1fbf9e0617  pop r11
00007b1fbf9e0619  pop r10
00007b1fbf9e061b  pop r9
00007b1fbf9e061d  pop r8
00007b1fbf9e061f  pop rsi
00007b1fbf9e0620  pop rdi
00007b1fbf9e0621  pop rdx
00007b1fbf9e0622  pop rcx
00007b1fbf9e0623  pop rax
00007b1fbf9e0624  add rsp, 0x08
00007b1fbf9e0628  jmp 0x00007B1FBF9DC5F4
00007b1fbf9e062d  sub rsp, 0x08
00007b1fbf9e0631  push rax
00007b1fbf9e0632  push rcx
00007b1fbf9e0633  push rdx
00007b1fbf9e0634  push rdi
00007b1fbf9e0635  push rsi
00007b1fbf9e0636  push r8
00007b1fbf9e0638  push r9
00007b1fbf9e063a  push r10
00007b1fbf9e063c  push r11
00007b1fbf9e063e  sub rsp, 0xF0
00007b1fbf9e0645  vmovaps [rsp], xmm0
00007b1fbf9e064a  vmovaps [rsp+0x10], xmm1
00007b1fbf9e0650  vmovaps [rsp+0x20], xmm2
00007b1fbf9e0656  vmovaps [rsp+0x30], xmm3
00007b1fbf9e065c  vmovaps [rsp+0x40], xmm4
00007b1fbf9e0662  vmovaps [rsp+0x50], xmm5
00007b1fbf9e0668  vmovaps [rsp+0x60], xmm6
00007b1fbf9e066e  vmovaps [rsp+0x70], xmm7
00007b1fbf9e0674  vmovaps [rsp+0x80], xmm8
00007b1fbf9e067d  vmovaps [rsp+0x90], xmm9
00007b1fbf9e0686  vmovaps [rsp+0xA0], xmm10
00007b1fbf9e068f  vmovaps [rsp+0xB0], xmm11
00007b1fbf9e0698  vmovaps [rsp+0xC0], xmm12
00007b1fbf9e06a1  vmovaps [rsp+0xD0], xmm14
00007b1fbf9e06aa  vmovaps [rsp+0xE0], xmm15
00007b1fbf9e06b3  sub rsp, 0x30
00007b1fbf9e06b7  movaps [rsp], xmm13
00007b1fbf9e06bc  movaps [rsp+0x10], xmm15
00007b1fbf9e06c2  movaps [rsp+0x20], xmm8
00007b1fbf9e06c8  lea rdi, [rsp]
00007b1fbf9e06cc  mov esi, 0x00
00007b1fbf9e06d1  mov rax, 0x64AEE5F12530
00007b1fbf9e06db  call rax
00007b1fbf9e06dd  movaps xmm13, [rsp]
00007b1fbf9e06e2  add rsp, 0x30
00007b1fbf9e06e6  vmovaps xmm0, [rsp]
00007b1fbf9e06eb  vmovaps xmm1, [rsp+0x10]
00007b1fbf9e06f1  vmovaps xmm2, [rsp+0x20]
00007b1fbf9e06f7  vmovaps xmm3, [rsp+0x30]
00007b1fbf9e06fd  vmovaps xmm4, [rsp+0x40]
00007b1fbf9e0703  vmovaps xmm5, [rsp+0x50]
00007b1fbf9e0709  vmovaps xmm6, [rsp+0x60]
00007b1fbf9e070f  vmovaps xmm7, [rsp+0x70]
00007b1fbf9e0715  vmovaps xmm8, [rsp+0x80]
00007b1fbf9e071e  vmovaps xmm9, [rsp+0x90]
00007b1fbf9e0727  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9e0730  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9e0739  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9e0742  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9e074b  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9e0754  add rsp, 0xF0
00007b1fbf9e075b  pop r11
00007b1fbf9e075d  pop r10
00007b1fbf9e075f  pop r9
00007b1fbf9e0761  pop r8
00007b1fbf9e0763  pop rsi
00007b1fbf9e0764  pop rdi
00007b1fbf9e0765  pop rdx
00007b1fbf9e0766  pop rcx
00007b1fbf9e0767  pop rax
00007b1fbf9e0768  add rsp, 0x08
00007b1fbf9e076c  jmp 0x00007B1FBF9DC60F
00007b1fbf9e0771  sub rsp, 0x08
00007b1fbf9e0775  push rax
00007b1fbf9e0776  push rcx
00007b1fbf9e0777  push rdx
00007b1fbf9e0778  push rdi
00007b1fbf9e0779  push rsi
00007b1fbf9e077a  push r8
00007b1fbf9e077c  push r9
00007b1fbf9e077e  push r10
00007b1fbf9e0780  push r11
00007b1fbf9e0782  sub rsp, 0xF0
00007b1fbf9e0789  vmovaps [rsp], xmm0
00007b1fbf9e078e  vmovaps [rsp+0x10], xmm1
00007b1fbf9e0794  vmovaps [rsp+0x20], xmm2
00007b1fbf9e079a  vmovaps [rsp+0x30], xmm3
00007b1fbf9e07a0  vmovaps [rsp+0x40], xmm4
00007b1fbf9e07a6  vmovaps [rsp+0x50], xmm5
00007b1fbf9e07ac  vmovaps [rsp+0x60], xmm6
00007b1fbf9e07b2  vmovaps [rsp+0x70], xmm7
00007b1fbf9e07b8  vmovaps [rsp+0x80], xmm9
00007b1fbf9e07c1  vmovaps [rsp+0x90], xmm10
00007b1fbf9e07ca  vmovaps [rsp+0xA0], xmm11
00007b1fbf9e07d3  vmovaps [rsp+0xB0], xmm12
00007b1fbf9e07dc  vmovaps [rsp+0xC0], xmm13
00007b1fbf9e07e5  vmovaps [rsp+0xD0], xmm14
00007b1fbf9e07ee  vmovaps [rsp+0xE0], xmm15
00007b1fbf9e07f7  sub rsp, 0x30
00007b1fbf9e07fb  movaps [rsp], xmm8
00007b1fbf9e0800  movaps [rsp+0x10], xmm15
00007b1fbf9e0806  movaps [rsp+0x20], xmm9
00007b1fbf9e080c  lea rdi, [rsp]
00007b1fbf9e0810  mov esi, 0x00
00007b1fbf9e0815  mov rax, 0x64AEE5F12530
00007b1fbf9e081f  call rax
00007b1fbf9e0821  movaps xmm8, [rsp]
00007b1fbf9e0826  add rsp, 0x30
00007b1fbf9e082a  vmovaps xmm0, [rsp]
00007b1fbf9e082f  vmovaps xmm1, [rsp+0x10]
00007b1fbf9e0835  vmovaps xmm2, [rsp+0x20]
00007b1fbf9e083b  vmovaps xmm3, [rsp+0x30]
00007b1fbf9e0841  vmovaps xmm4, [rsp+0x40]
00007b1fbf9e0847  vmovaps xmm5, [rsp+0x50]
00007b1fbf9e084d  vmovaps xmm6, [rsp+0x60]
00007b1fbf9e0853  vmovaps xmm7, [rsp+0x70]
00007b1fbf9e0859  vmovaps xmm9, [rsp+0x80]
00007b1fbf9e0862  vmovaps xmm10, [rsp+0x90]
00007b1fbf9e086b  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9e0874  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9e087d  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9e0886  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9e088f  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9e0898  add rsp, 0xF0
00007b1fbf9e089f  pop r11
00007b1fbf9e08a1  pop r10
00007b1fbf9e08a3  pop r9
00007b1fbf9e08a5  pop r8
00007b1fbf9e08a7  pop rsi
00007b1fbf9e08a8  pop rdi
00007b1fbf9e08a9  pop rdx
00007b1fbf9e08aa  pop rcx
00007b1fbf9e08ab  pop rax
00007b1fbf9e08ac  add rsp, 0x08
00007b1fbf9e08b0  jmp 0x00007B1FBF9DC63D
00007b1fbf9e08b5  sub rsp, 0x08
00007b1fbf9e08b9  push rax
00007b1fbf9e08ba  push rcx
00007b1fbf9e08bb  push rdx
00007b1fbf9e08bc  push rdi
00007b1fbf9e08bd  push rsi
00007b1fbf9e08be  push r8
00007b1fbf9e08c0  push r9
00007b1fbf9e08c2  push r10
00007b1fbf9e08c4  push r11
00007b1fbf9e08c6  sub rsp, 0xF0
00007b1fbf9e08cd  vmovaps [rsp], xmm0
00007b1fbf9e08d2  vmovaps [rsp+0x10], xmm1
00007b1fbf9e08d8  vmovaps [rsp+0x20], xmm2
00007b1fbf9e08de  vmovaps [rsp+0x30], xmm3
00007b1fbf9e08e4  vmovaps [rsp+0x40], xmm4
00007b1fbf9e08ea  vmovaps [rsp+0x50], xmm5
00007b1fbf9e08f0  vmovaps [rsp+0x60], xmm6
00007b1fbf9e08f6  vmovaps [rsp+0x70], xmm7
00007b1fbf9e08fc  vmovaps [rsp+0x80], xmm8
00007b1fbf9e0905  vmovaps [rsp+0x90], xmm9
00007b1fbf9e090e  vmovaps [rsp+0xA0], xmm10
00007b1fbf9e0917  vmovaps [rsp+0xB0], xmm11
00007b1fbf9e0920  vmovaps [rsp+0xC0], xmm12
00007b1fbf9e0929  vmovaps [rsp+0xD0], xmm13
00007b1fbf9e0932  vmovaps [rsp+0xE0], xmm14
00007b1fbf9e093b  sub rsp, 0x30
00007b1fbf9e093f  movaps [rsp], xmm15
00007b1fbf9e0944  movaps [rsp+0x10], xmm11
00007b1fbf9e094a  movaps [rsp+0x20], xmm6
00007b1fbf9e094f  lea rdi, [rsp]
00007b1fbf9e0953  mov esi, 0x00
00007b1fbf9e0958  mov rax, 0x64AEE5F12530
00007b1fbf9e0962  call rax
00007b1fbf9e0964  movaps xmm15, [rsp]
00007b1fbf9e0969  add rsp, 0x30
00007b1fbf9e096d  vmovaps xmm0, [rsp]
00007b1fbf9e0972  vmovaps xmm1, [rsp+0x10]
00007b1fbf9e0978  vmovaps xmm2, [rsp+0x20]
00007b1fbf9e097e  vmovaps xmm3, [rsp+0x30]
00007b1fbf9e0984  vmovaps xmm4, [rsp+0x40]
00007b1fbf9e098a  vmovaps xmm5, [rsp+0x50]
00007b1fbf9e0990  vmovaps xmm6, [rsp+0x60]
00007b1fbf9e0996  vmovaps xmm7, [rsp+0x70]
00007b1fbf9e099c  vmovaps xmm8, [rsp+0x80]
00007b1fbf9e09a5  vmovaps xmm9, [rsp+0x90]
00007b1fbf9e09ae  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9e09b7  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9e09c0  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9e09c9  vmovaps xmm13, [rsp+0xD0]
00007b1fbf9e09d2  vmovaps xmm14, [rsp+0xE0]
00007b1fbf9e09db  add rsp, 0xF0
00007b1fbf9e09e2  pop r11
00007b1fbf9e09e4  pop r10
00007b1fbf9e09e6  pop r9
00007b1fbf9e09e8  pop r8
00007b1fbf9e09ea  pop rsi
00007b1fbf9e09eb  pop rdi
00007b1fbf9e09ec  pop rdx
00007b1fbf9e09ed  pop rcx
00007b1fbf9e09ee  pop rax
00007b1fbf9e09ef  add rsp, 0x08
00007b1fbf9e09f3  jmp 0x00007B1FBF9DC658
00007b1fbf9e09f8  sub rsp, 0x08
00007b1fbf9e09fc  push rax
00007b1fbf9e09fd  push rcx
00007b1fbf9e09fe  push rdx
00007b1fbf9e09ff  push rdi
00007b1fbf9e0a00  push rsi
00007b1fbf9e0a01  push r8
00007b1fbf9e0a03  push r9
00007b1fbf9e0a05  push r10
00007b1fbf9e0a07  push r11
00007b1fbf9e0a09  sub rsp, 0xF0
00007b1fbf9e0a10  vmovaps [rsp], xmm0
00007b1fbf9e0a15  vmovaps [rsp+0x10], xmm1
00007b1fbf9e0a1b  vmovaps [rsp+0x20], xmm2
00007b1fbf9e0a21  vmovaps [rsp+0x30], xmm3
00007b1fbf9e0a27  vmovaps [rsp+0x40], xmm4
00007b1fbf9e0a2d  vmovaps [rsp+0x50], xmm5
00007b1fbf9e0a33  vmovaps [rsp+0x60], xmm6
00007b1fbf9e0a39  vmovaps [rsp+0x70], xmm8
00007b1fbf9e0a3f  vmovaps [rsp+0x80], xmm9
00007b1fbf9e0a48  vmovaps [rsp+0x90], xmm10
00007b1fbf9e0a51  vmovaps [rsp+0xA0], xmm11
00007b1fbf9e0a5a  vmovaps [rsp+0xB0], xmm12
00007b1fbf9e0a63  vmovaps [rsp+0xC0], xmm13
00007b1fbf9e0a6c  vmovaps [rsp+0xD0], xmm14
00007b1fbf9e0a75  vmovaps [rsp+0xE0], xmm15
00007b1fbf9e0a7e  sub rsp, 0x30
00007b1fbf9e0a82  movaps [rsp], xmm7
00007b1fbf9e0a86  movaps [rsp+0x10], xmm11
00007b1fbf9e0a8c  movaps [rsp+0x20], xmm9
00007b1fbf9e0a92  lea rdi, [rsp]
00007b1fbf9e0a96  mov esi, 0x00
00007b1fbf9e0a9b  mov rax, 0x64AEE5F12530
00007b1fbf9e0aa5  call rax
00007b1fbf9e0aa7  movaps xmm7, [rsp]
00007b1fbf9e0aab  add rsp, 0x30
00007b1fbf9e0aaf  vmovaps xmm0, [rsp]
00007b1fbf9e0ab4  vmovaps xmm1, [rsp+0x10]
00007b1fbf9e0aba  vmovaps xmm2, [rsp+0x20]
00007b1fbf9e0ac0  vmovaps xmm3, [rsp+0x30]
00007b1fbf9e0ac6  vmovaps xmm4, [rsp+0x40]
00007b1fbf9e0acc  vmovaps xmm5, [rsp+0x50]
00007b1fbf9e0ad2  vmovaps xmm6, [rsp+0x60]
00007b1fbf9e0ad8  vmovaps xmm8, [rsp+0x70]
00007b1fbf9e0ade  vmovaps xmm9, [rsp+0x80]
00007b1fbf9e0ae7  vmovaps xmm10, [rsp+0x90]
00007b1fbf9e0af0  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9e0af9  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9e0b02  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9e0b0b  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9e0b14  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9e0b1d  add rsp, 0xF0
00007b1fbf9e0b24  pop r11
00007b1fbf9e0b26  pop r10
00007b1fbf9e0b28  pop r9
00007b1fbf9e0b2a  pop r8
00007b1fbf9e0b2c  pop rsi
00007b1fbf9e0b2d  pop rdi
00007b1fbf9e0b2e  pop rdx
00007b1fbf9e0b2f  pop rcx
00007b1fbf9e0b30  pop rax
00007b1fbf9e0b31  add rsp, 0x08
00007b1fbf9e0b35  jmp 0x00007B1FBF9DC685
00007b1fbf9e0b3a  sub rsp, 0x08
00007b1fbf9e0b3e  push rax
00007b1fbf9e0b3f  push rcx
00007b1fbf9e0b40  push rdx
00007b1fbf9e0b41  push rdi
00007b1fbf9e0b42  push rsi
00007b1fbf9e0b43  push r8
00007b1fbf9e0b45  push r9
00007b1fbf9e0b47  push r10
00007b1fbf9e0b49  push r11
00007b1fbf9e0b4b  sub rsp, 0xF0
00007b1fbf9e0b52  vmovaps [rsp], xmm0
00007b1fbf9e0b57  vmovaps [rsp+0x10], xmm1
00007b1fbf9e0b5d  vmovaps [rsp+0x20], xmm2
00007b1fbf9e0b63  vmovaps [rsp+0x30], xmm3
00007b1fbf9e0b69  vmovaps [rsp+0x40], xmm4
00007b1fbf9e0b6f  vmovaps [rsp+0x50], xmm5
00007b1fbf9e0b75  vmovaps [rsp+0x60], xmm6
00007b1fbf9e0b7b  vmovaps [rsp+0x70], xmm7
00007b1fbf9e0b81  vmovaps [rsp+0x80], xmm8
00007b1fbf9e0b8a  vmovaps [rsp+0x90], xmm9
00007b1fbf9e0b93  vmovaps [rsp+0xA0], xmm10
00007b1fbf9e0b9c  vmovaps [rsp+0xB0], xmm12
00007b1fbf9e0ba5  vmovaps [rsp+0xC0], xmm13
00007b1fbf9e0bae  vmovaps [rsp+0xD0], xmm14
00007b1fbf9e0bb7  vmovaps [rsp+0xE0], xmm15
00007b1fbf9e0bc0  sub rsp, 0x30
00007b1fbf9e0bc4  movaps [rsp], xmm11
00007b1fbf9e0bc9  movaps [rsp+0x10], xmm10
00007b1fbf9e0bcf  movaps [rsp+0x20], xmm14
00007b1fbf9e0bd5  lea rdi, [rsp]
00007b1fbf9e0bd9  mov esi, 0x00
00007b1fbf9e0bde  mov rax, 0x64AEE5F12530
00007b1fbf9e0be8  call rax
00007b1fbf9e0bea  movaps xmm11, [rsp]
00007b1fbf9e0bef  add rsp, 0x30
00007b1fbf9e0bf3  vmovaps xmm0, [rsp]
00007b1fbf9e0bf8  vmovaps xmm1, [rsp+0x10]
00007b1fbf9e0bfe  vmovaps xmm2, [rsp+0x20]
00007b1fbf9e0c04  vmovaps xmm3, [rsp+0x30]
00007b1fbf9e0c0a  vmovaps xmm4, [rsp+0x40]
00007b1fbf9e0c10  vmovaps xmm5, [rsp+0x50]
00007b1fbf9e0c16  vmovaps xmm6, [rsp+0x60]
00007b1fbf9e0c1c  vmovaps xmm7, [rsp+0x70]
00007b1fbf9e0c22  vmovaps xmm8, [rsp+0x80]
00007b1fbf9e0c2b  vmovaps xmm9, [rsp+0x90]
00007b1fbf9e0c34  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9e0c3d  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9e0c46  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9e0c4f  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9e0c58  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9e0c61  add rsp, 0xF0
00007b1fbf9e0c68  pop r11
00007b1fbf9e0c6a  pop r10
00007b1fbf9e0c6c  pop r9
00007b1fbf9e0c6e  pop r8
00007b1fbf9e0c70  pop rsi
00007b1fbf9e0c71  pop rdi
00007b1fbf9e0c72  pop rdx
00007b1fbf9e0c73  pop rcx
00007b1fbf9e0c74  pop rax
00007b1fbf9e0c75  add rsp, 0x08
00007b1fbf9e0c79  jmp 0x00007B1FBF9DC6A0
00007b1fbf9e0c7e  call 0x00007B1FBF8C33A0
00007b1fbf9e0c83  jmp 0x00007B1FBF9DC6AA
00007b1fbf9e0c88  sub rsp, 0x08
00007b1fbf9e0c8c  push rax
00007b1fbf9e0c8d  push rcx
00007b1fbf9e0c8e  push rdx
00007b1fbf9e0c8f  push rdi
00007b1fbf9e0c90  push rsi
00007b1fbf9e0c91  push r8
00007b1fbf9e0c93  push r9
00007b1fbf9e0c95  push r10
00007b1fbf9e0c97  push r11
00007b1fbf9e0c99  sub rsp, 0xF0
00007b1fbf9e0ca0  vmovaps [rsp], xmm0
00007b1fbf9e0ca5  vmovaps [rsp+0x10], xmm1
00007b1fbf9e0cab  vmovaps [rsp+0x20], xmm2
00007b1fbf9e0cb1  vmovaps [rsp+0x30], xmm3
00007b1fbf9e0cb7  vmovaps [rsp+0x40], xmm4
00007b1fbf9e0cbd  vmovaps [rsp+0x50], xmm5
00007b1fbf9e0cc3  vmovaps [rsp+0x60], xmm6
00007b1fbf9e0cc9  vmovaps [rsp+0x70], xmm7
00007b1fbf9e0ccf  vmovaps [rsp+0x80], xmm8
00007b1fbf9e0cd8  vmovaps [rsp+0x90], xmm9
00007b1fbf9e0ce1  vmovaps [rsp+0xA0], xmm11
00007b1fbf9e0cea  vmovaps [rsp+0xB0], xmm12
00007b1fbf9e0cf3  vmovaps [rsp+0xC0], xmm13
00007b1fbf9e0cfc  vmovaps [rsp+0xD0], xmm14
00007b1fbf9e0d05  vmovaps [rsp+0xE0], xmm15
00007b1fbf9e0d0e  sub rsp, 0x30
00007b1fbf9e0d12  movaps [rsp], xmm10
00007b1fbf9e0d17  movaps [rsp+0x10], xmm1
00007b1fbf9e0d1c  movaps [rsp+0x20], xmm12
00007b1fbf9e0d22  lea rdi, [rsp]
00007b1fbf9e0d26  mov esi, 0x00
00007b1fbf9e0d2b  mov rax, 0x64AEE5F12530
00007b1fbf9e0d35  call rax
00007b1fbf9e0d37  movaps xmm10, [rsp]
00007b1fbf9e0d3c  add rsp, 0x30
00007b1fbf9e0d40  vmovaps xmm0, [rsp]
00007b1fbf9e0d45  vmovaps xmm1, [rsp+0x10]
00007b1fbf9e0d4b  vmovaps xmm2, [rsp+0x20]
00007b1fbf9e0d51  vmovaps xmm3, [rsp+0x30]
00007b1fbf9e0d57  vmovaps xmm4, [rsp+0x40]
00007b1fbf9e0d5d  vmovaps xmm5, [rsp+0x50]
00007b1fbf9e0d63  vmovaps xmm6, [rsp+0x60]
00007b1fbf9e0d69  vmovaps xmm7, [rsp+0x70]
00007b1fbf9e0d6f  vmovaps xmm8, [rsp+0x80]
00007b1fbf9e0d78  vmovaps xmm9, [rsp+0x90]
00007b1fbf9e0d81  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9e0d8a  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9e0d93  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9e0d9c  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9e0da5  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9e0dae  add rsp, 0xF0
00007b1fbf9e0db5  pop r11
00007b1fbf9e0db7  pop r10
00007b1fbf9e0db9  pop r9
00007b1fbf9e0dbb  pop r8
00007b1fbf9e0dbd  pop rsi
00007b1fbf9e0dbe  pop rdi
00007b1fbf9e0dbf  pop rdx
00007b1fbf9e0dc0  pop rcx
00007b1fbf9e0dc1  pop rax
00007b1fbf9e0dc2  add rsp, 0x08
00007b1fbf9e0dc6  jmp 0x00007B1FBF9DC6CD
00007b1fbf9e0dcb  sub rsp, 0x08
00007b1fbf9e0dcf  push rax
00007b1fbf9e0dd0  push rcx
00007b1fbf9e0dd1  push rdx
00007b1fbf9e0dd2  push rdi
00007b1fbf9e0dd3  push rsi
00007b1fbf9e0dd4  push r8
00007b1fbf9e0dd6  push r9
00007b1fbf9e0dd8  push r10
00007b1fbf9e0dda  push r11
00007b1fbf9e0ddc  sub rsp, 0xF0
00007b1fbf9e0de3  vmovaps [rsp], xmm0
00007b1fbf9e0de8  vmovaps [rsp+0x10], xmm1
00007b1fbf9e0dee  vmovaps [rsp+0x20], xmm2
00007b1fbf9e0df4  vmovaps [rsp+0x30], xmm3
00007b1fbf9e0dfa  vmovaps [rsp+0x40], xmm4
00007b1fbf9e0e00  vmovaps [rsp+0x50], xmm5
00007b1fbf9e0e06  vmovaps [rsp+0x60], xmm6
00007b1fbf9e0e0c  vmovaps [rsp+0x70], xmm7
00007b1fbf9e0e12  vmovaps [rsp+0x80], xmm8
00007b1fbf9e0e1b  vmovaps [rsp+0x90], xmm9
00007b1fbf9e0e24  vmovaps [rsp+0xA0], xmm10
00007b1fbf9e0e2d  vmovaps [rsp+0xB0], xmm11
00007b1fbf9e0e36  vmovaps [rsp+0xC0], xmm13
00007b1fbf9e0e3f  vmovaps [rsp+0xD0], xmm14
00007b1fbf9e0e48  vmovaps [rsp+0xE0], xmm15
00007b1fbf9e0e51  sub rsp, 0x30
00007b1fbf9e0e55  movaps [rsp], xmm12
00007b1fbf9e0e5a  movaps [rsp+0x10], xmm14
00007b1fbf9e0e60  movaps [rsp+0x20], xmm1
00007b1fbf9e0e65  lea rdi, [rsp]
00007b1fbf9e0e69  mov esi, 0x00
00007b1fbf9e0e6e  mov rax, 0x64AEE5F12530
00007b1fbf9e0e78  call rax
00007b1fbf9e0e7a  movaps xmm12, [rsp]
00007b1fbf9e0e7f  add rsp, 0x30
00007b1fbf9e0e83  vmovaps xmm0, [rsp]
00007b1fbf9e0e88  vmovaps xmm1, [rsp+0x10]
00007b1fbf9e0e8e  vmovaps xmm2, [rsp+0x20]
00007b1fbf9e0e94  vmovaps xmm3, [rsp+0x30]
00007b1fbf9e0e9a  vmovaps xmm4, [rsp+0x40]
00007b1fbf9e0ea0  vmovaps xmm5, [rsp+0x50]
00007b1fbf9e0ea6  vmovaps xmm6, [rsp+0x60]
00007b1fbf9e0eac  vmovaps xmm7, [rsp+0x70]
00007b1fbf9e0eb2  vmovaps xmm8, [rsp+0x80]
00007b1fbf9e0ebb  vmovaps xmm9, [rsp+0x90]
00007b1fbf9e0ec4  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9e0ecd  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9e0ed6  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9e0edf  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9e0ee8  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9e0ef1  add rsp, 0xF0
00007b1fbf9e0ef8  pop r11
00007b1fbf9e0efa  pop r10
00007b1fbf9e0efc  pop r9
00007b1fbf9e0efe  pop r8
00007b1fbf9e0f00  pop rsi
00007b1fbf9e0f01  pop rdi
00007b1fbf9e0f02  pop rdx
00007b1fbf9e0f03  pop rcx
00007b1fbf9e0f04  pop rax
00007b1fbf9e0f05  add rsp, 0x08
00007b1fbf9e0f09  jmp 0x00007B1FBF9DC6FC
00007b1fbf9e0f0e  sub rsp, 0x08
00007b1fbf9e0f12  push rax
00007b1fbf9e0f13  push rcx
00007b1fbf9e0f14  push rdx
00007b1fbf9e0f15  push rdi
00007b1fbf9e0f16  push rsi
00007b1fbf9e0f17  push r8
00007b1fbf9e0f19  push r9
00007b1fbf9e0f1b  push r10
00007b1fbf9e0f1d  push r11
00007b1fbf9e0f1f  sub rsp, 0xF0
00007b1fbf9e0f26  vmovaps [rsp], xmm0
00007b1fbf9e0f2b  vmovaps [rsp+0x10], xmm1
00007b1fbf9e0f31  vmovaps [rsp+0x20], xmm2
00007b1fbf9e0f37  vmovaps [rsp+0x30], xmm3
00007b1fbf9e0f3d  vmovaps [rsp+0x40], xmm4
00007b1fbf9e0f43  vmovaps [rsp+0x50], xmm5
00007b1fbf9e0f49  vmovaps [rsp+0x60], xmm6
00007b1fbf9e0f4f  vmovaps [rsp+0x70], xmm7
00007b1fbf9e0f55  vmovaps [rsp+0x80], xmm8
00007b1fbf9e0f5e  vmovaps [rsp+0x90], xmm9
00007b1fbf9e0f67  vmovaps [rsp+0xA0], xmm10
00007b1fbf9e0f70  vmovaps [rsp+0xB0], xmm11
00007b1fbf9e0f79  vmovaps [rsp+0xC0], xmm12
00007b1fbf9e0f82  vmovaps [rsp+0xD0], xmm13
00007b1fbf9e0f8b  vmovaps [rsp+0xE0], xmm15
00007b1fbf9e0f94  sub rsp, 0x30
00007b1fbf9e0f98  movaps [rsp], xmm14
00007b1fbf9e0f9d  movaps [rsp+0x10], xmm9
00007b1fbf9e0fa3  movaps [rsp+0x20], xmm1
00007b1fbf9e0fa8  lea rdi, [rsp]
00007b1fbf9e0fac  mov esi, 0x00
00007b1fbf9e0fb1  mov rax, 0x64AEE5F12530
00007b1fbf9e0fbb  call rax
00007b1fbf9e0fbd  movaps xmm14, [rsp]
00007b1fbf9e0fc2  add rsp, 0x30
00007b1fbf9e0fc6  vmovaps xmm0, [rsp]
00007b1fbf9e0fcb  vmovaps xmm1, [rsp+0x10]
00007b1fbf9e0fd1  vmovaps xmm2, [rsp+0x20]
00007b1fbf9e0fd7  vmovaps xmm3, [rsp+0x30]
00007b1fbf9e0fdd  vmovaps xmm4, [rsp+0x40]
00007b1fbf9e0fe3  vmovaps xmm5, [rsp+0x50]
00007b1fbf9e0fe9  vmovaps xmm6, [rsp+0x60]
00007b1fbf9e0fef  vmovaps xmm7, [rsp+0x70]
00007b1fbf9e0ff5  vmovaps xmm8, [rsp+0x80]
00007b1fbf9e0ffe  vmovaps xmm9, [rsp+0x90]
00007b1fbf9e1007  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9e1010  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9e1019  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9e1022  vmovaps xmm13, [rsp+0xD0]
00007b1fbf9e102b  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9e1034  add rsp, 0xF0
00007b1fbf9e103b  pop r11
00007b1fbf9e103d  pop r10
00007b1fbf9e103f  pop r9
00007b1fbf9e1041  pop r8
00007b1fbf9e1043  pop rsi
00007b1fbf9e1044  pop rdi
00007b1fbf9e1045  pop rdx
00007b1fbf9e1046  pop rcx
00007b1fbf9e1047  pop rax
00007b1fbf9e1048  add rsp, 0x08
00007b1fbf9e104c  jmp 0x00007B1FBF9DC72B
00007b1fbf9e1051  sub rsp, 0x08
00007b1fbf9e1055  push rax
00007b1fbf9e1056  push rcx
00007b1fbf9e1057  push rdx
00007b1fbf9e1058  push rdi
00007b1fbf9e1059  push rsi
00007b1fbf9e105a  push r8
00007b1fbf9e105c  push r9
00007b1fbf9e105e  push r10
00007b1fbf9e1060  push r11
00007b1fbf9e1062  sub rsp, 0xF0
00007b1fbf9e1069  vmovaps [rsp], xmm0
00007b1fbf9e106e  vmovaps [rsp+0x10], xmm2
00007b1fbf9e1074  vmovaps [rsp+0x20], xmm3
00007b1fbf9e107a  vmovaps [rsp+0x30], xmm4
00007b1fbf9e1080  vmovaps [rsp+0x40], xmm5
00007b1fbf9e1086  vmovaps [rsp+0x50], xmm6
00007b1fbf9e108c  vmovaps [rsp+0x60], xmm7
00007b1fbf9e1092  vmovaps [rsp+0x70], xmm8
00007b1fbf9e1098  vmovaps [rsp+0x80], xmm9
00007b1fbf9e10a1  vmovaps [rsp+0x90], xmm10
00007b1fbf9e10aa  vmovaps [rsp+0xA0], xmm11
00007b1fbf9e10b3  vmovaps [rsp+0xB0], xmm12
00007b1fbf9e10bc  vmovaps [rsp+0xC0], xmm13
00007b1fbf9e10c5  vmovaps [rsp+0xD0], xmm14
00007b1fbf9e10ce  vmovaps [rsp+0xE0], xmm15
00007b1fbf9e10d7  sub rsp, 0x30
00007b1fbf9e10db  movaps [rsp], xmm1
00007b1fbf9e10df  movaps [rsp+0x10], xmm13
00007b1fbf9e10e5  movaps [rsp+0x20], xmm8
00007b1fbf9e10eb  lea rdi, [rsp]
00007b1fbf9e10ef  mov esi, 0x00
00007b1fbf9e10f4  mov rax, 0x64AEE5F12530
00007b1fbf9e10fe  call rax
00007b1fbf9e1100  movaps xmm1, [rsp]
00007b1fbf9e1104  add rsp, 0x30
00007b1fbf9e1108  vmovaps xmm0, [rsp]
00007b1fbf9e110d  vmovaps xmm2, [rsp+0x10]
00007b1fbf9e1113  vmovaps xmm3, [rsp+0x20]
00007b1fbf9e1119  vmovaps xmm4, [rsp+0x30]
00007b1fbf9e111f  vmovaps xmm5, [rsp+0x40]
00007b1fbf9e1125  vmovaps xmm6, [rsp+0x50]
00007b1fbf9e112b  vmovaps xmm7, [rsp+0x60]
00007b1fbf9e1131  vmovaps xmm8, [rsp+0x70]
00007b1fbf9e1137  vmovaps xmm9, [rsp+0x80]
00007b1fbf9e1140  vmovaps xmm10, [rsp+0x90]
00007b1fbf9e1149  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9e1152  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9e115b  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9e1164  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9e116d  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9e1176  add rsp, 0xF0
00007b1fbf9e117d  pop r11
00007b1fbf9e117f  pop r10
00007b1fbf9e1181  pop r9
00007b1fbf9e1183  pop r8
00007b1fbf9e1185  pop rsi
00007b1fbf9e1186  pop rdi
00007b1fbf9e1187  pop rdx
00007b1fbf9e1188  pop rcx
00007b1fbf9e1189  pop rax
00007b1fbf9e118a  add rsp, 0x08
00007b1fbf9e118e  jmp 0x00007B1FBF9DC74D
00007b1fbf9e1193  call 0x00007B1FBF80C260
00007b1fbf9e1198  jmp 0x00007B1FBF9DC75B
00007b1fbf9e119d  call 0x00007B1FBF8BD750
00007b1fbf9e11a2  jmp 0x00007B1FBF9DC765
00007b1fbf9e11a7  sub rsp, 0x08
00007b1fbf9e11ab  push rax
00007b1fbf9e11ac  push rcx
00007b1fbf9e11ad  push rdx
00007b1fbf9e11ae  push rdi
00007b1fbf9e11af  push rsi
00007b1fbf9e11b0  push r8
00007b1fbf9e11b2  push r9
00007b1fbf9e11b4  push r10
00007b1fbf9e11b6  push r11
00007b1fbf9e11b8  sub rsp, 0xF0
00007b1fbf9e11bf  vmovaps [rsp], xmm0
00007b1fbf9e11c4  vmovaps [rsp+0x10], xmm1
00007b1fbf9e11ca  vmovaps [rsp+0x20], xmm2
00007b1fbf9e11d0  vmovaps [rsp+0x30], xmm3
00007b1fbf9e11d6  vmovaps [rsp+0x40], xmm4
00007b1fbf9e11dc  vmovaps [rsp+0x50], xmm5
00007b1fbf9e11e2  vmovaps [rsp+0x60], xmm6
00007b1fbf9e11e8  vmovaps [rsp+0x70], xmm7
00007b1fbf9e11ee  vmovaps [rsp+0x80], xmm9
00007b1fbf9e11f7  vmovaps [rsp+0x90], xmm10
00007b1fbf9e1200  vmovaps [rsp+0xA0], xmm11
00007b1fbf9e1209  vmovaps [rsp+0xB0], xmm12
00007b1fbf9e1212  vmovaps [rsp+0xC0], xmm13
00007b1fbf9e121b  vmovaps [rsp+0xD0], xmm14
00007b1fbf9e1224  vmovaps [rsp+0xE0], xmm15
00007b1fbf9e122d  sub rsp, 0x30
00007b1fbf9e1231  movaps [rsp], xmm8
00007b1fbf9e1236  movaps [rsp+0x10], xmm15
00007b1fbf9e123c  movaps [rsp+0x20], xmm7
00007b1fbf9e1241  lea rdi, [rsp]
00007b1fbf9e1245  mov esi, 0x00
00007b1fbf9e124a  mov rax, 0x64AEE5F12530
00007b1fbf9e1254  call rax
00007b1fbf9e1256  movaps xmm8, [rsp]
00007b1fbf9e125b  add rsp, 0x30
00007b1fbf9e125f  vmovaps xmm0, [rsp]
00007b1fbf9e1264  vmovaps xmm1, [rsp+0x10]
00007b1fbf9e126a  vmovaps xmm2, [rsp+0x20]
00007b1fbf9e1270  vmovaps xmm3, [rsp+0x30]
00007b1fbf9e1276  vmovaps xmm4, [rsp+0x40]
00007b1fbf9e127c  vmovaps xmm5, [rsp+0x50]
00007b1fbf9e1282  vmovaps xmm6, [rsp+0x60]
00007b1fbf9e1288  vmovaps xmm7, [rsp+0x70]
00007b1fbf9e128e  vmovaps xmm9, [rsp+0x80]
00007b1fbf9e1297  vmovaps xmm10, [rsp+0x90]
00007b1fbf9e12a0  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9e12a9  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9e12b2  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9e12bb  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9e12c4  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9e12cd  add rsp, 0xF0
00007b1fbf9e12d4  pop r11
00007b1fbf9e12d6  pop r10
00007b1fbf9e12d8  pop r9
00007b1fbf9e12da  pop r8
00007b1fbf9e12dc  pop rsi
00007b1fbf9e12dd  pop rdi
00007b1fbf9e12de  pop rdx
00007b1fbf9e12df  pop rcx
00007b1fbf9e12e0  pop rax
00007b1fbf9e12e1  add rsp, 0x08
00007b1fbf9e12e5  jmp 0x00007B1FBF9DC787
00007b1fbf9e12ea  sub rsp, 0x08
00007b1fbf9e12ee  push rax
00007b1fbf9e12ef  push rcx
00007b1fbf9e12f0  push rdx
00007b1fbf9e12f1  push rdi
00007b1fbf9e12f2  push rsi
00007b1fbf9e12f3  push r8
00007b1fbf9e12f5  push r9
00007b1fbf9e12f7  push r10
00007b1fbf9e12f9  push r11
00007b1fbf9e12fb  sub rsp, 0xF0
00007b1fbf9e1302  vmovaps [rsp], xmm0
00007b1fbf9e1307  vmovaps [rsp+0x10], xmm1
00007b1fbf9e130d  vmovaps [rsp+0x20], xmm2
00007b1fbf9e1313  vmovaps [rsp+0x30], xmm3
00007b1fbf9e1319  vmovaps [rsp+0x40], xmm4
00007b1fbf9e131f  vmovaps [rsp+0x50], xmm5
00007b1fbf9e1325  vmovaps [rsp+0x60], xmm6
00007b1fbf9e132b  vmovaps [rsp+0x70], xmm8
00007b1fbf9e1331  vmovaps [rsp+0x80], xmm9
00007b1fbf9e133a  vmovaps [rsp+0x90], xmm10
00007b1fbf9e1343  vmovaps [rsp+0xA0], xmm11
00007b1fbf9e134c  vmovaps [rsp+0xB0], xmm12
00007b1fbf9e1355  vmovaps [rsp+0xC0], xmm13
00007b1fbf9e135e  vmovaps [rsp+0xD0], xmm14
00007b1fbf9e1367  vmovaps [rsp+0xE0], xmm15
00007b1fbf9e1370  sub rsp, 0x30
00007b1fbf9e1374  movaps [rsp], xmm7
00007b1fbf9e1378  movaps [rsp+0x10], xmm9
00007b1fbf9e137e  movaps [rsp+0x20], xmm15
00007b1fbf9e1384  lea rdi, [rsp]
00007b1fbf9e1388  mov esi, 0x00
00007b1fbf9e138d  mov rax, 0x64AEE5F12530
00007b1fbf9e1397  call rax
00007b1fbf9e1399  movaps xmm7, [rsp]
00007b1fbf9e139d  add rsp, 0x30
00007b1fbf9e13a1  vmovaps xmm0, [rsp]
00007b1fbf9e13a6  vmovaps xmm1, [rsp+0x10]
00007b1fbf9e13ac  vmovaps xmm2, [rsp+0x20]
00007b1fbf9e13b2  vmovaps xmm3, [rsp+0x30]
00007b1fbf9e13b8  vmovaps xmm4, [rsp+0x40]
00007b1fbf9e13be  vmovaps xmm5, [rsp+0x50]
00007b1fbf9e13c4  vmovaps xmm6, [rsp+0x60]
00007b1fbf9e13ca  vmovaps xmm8, [rsp+0x70]
00007b1fbf9e13d0  vmovaps xmm9, [rsp+0x80]
00007b1fbf9e13d9  vmovaps xmm10, [rsp+0x90]
00007b1fbf9e13e2  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9e13eb  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9e13f4  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9e13fd  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9e1406  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9e140f  add rsp, 0xF0
00007b1fbf9e1416  pop r11
00007b1fbf9e1418  pop r10
00007b1fbf9e141a  pop r9
00007b1fbf9e141c  pop r8
00007b1fbf9e141e  pop rsi
00007b1fbf9e141f  pop rdi
00007b1fbf9e1420  pop rdx
00007b1fbf9e1421  pop rcx
00007b1fbf9e1422  pop rax
00007b1fbf9e1423  add rsp, 0x08
00007b1fbf9e1427  jmp 0x00007B1FBF9DC7B4
00007b1fbf9e142c  sub rsp, 0x08
00007b1fbf9e1430  push rax
00007b1fbf9e1431  push rcx
00007b1fbf9e1432  push rdx
00007b1fbf9e1433  push rdi
00007b1fbf9e1434  push rsi
00007b1fbf9e1435  push r8
00007b1fbf9e1437  push r9
00007b1fbf9e1439  push r10
00007b1fbf9e143b  push r11
00007b1fbf9e143d  sub rsp, 0xF0
00007b1fbf9e1444  vmovaps [rsp], xmm0
00007b1fbf9e1449  vmovaps [rsp+0x10], xmm1
00007b1fbf9e144f  vmovaps [rsp+0x20], xmm2
00007b1fbf9e1455  vmovaps [rsp+0x30], xmm3
00007b1fbf9e145b  vmovaps [rsp+0x40], xmm4
00007b1fbf9e1461  vmovaps [rsp+0x50], xmm5
00007b1fbf9e1467  vmovaps [rsp+0x60], xmm6
00007b1fbf9e146d  vmovaps [rsp+0x70], xmm7
00007b1fbf9e1473  vmovaps [rsp+0x80], xmm8
00007b1fbf9e147c  vmovaps [rsp+0x90], xmm10
00007b1fbf9e1485  vmovaps [rsp+0xA0], xmm11
00007b1fbf9e148e  vmovaps [rsp+0xB0], xmm12
00007b1fbf9e1497  vmovaps [rsp+0xC0], xmm13
00007b1fbf9e14a0  vmovaps [rsp+0xD0], xmm14
00007b1fbf9e14a9  vmovaps [rsp+0xE0], xmm15
00007b1fbf9e14b2  sub rsp, 0x30
00007b1fbf9e14b6  movaps [rsp], xmm9
00007b1fbf9e14bb  movaps [rsp+0x10], xmm13
00007b1fbf9e14c1  movaps [rsp+0x20], xmm15
00007b1fbf9e14c7  lea rdi, [rsp]
00007b1fbf9e14cb  mov esi, 0x00
00007b1fbf9e14d0  mov rax, 0x64AEE5F12530
00007b1fbf9e14da  call rax
00007b1fbf9e14dc  movaps xmm9, [rsp]
00007b1fbf9e14e1  add rsp, 0x30
00007b1fbf9e14e5  vmovaps xmm0, [rsp]
00007b1fbf9e14ea  vmovaps xmm1, [rsp+0x10]
00007b1fbf9e14f0  vmovaps xmm2, [rsp+0x20]
00007b1fbf9e14f6  vmovaps xmm3, [rsp+0x30]
00007b1fbf9e14fc  vmovaps xmm4, [rsp+0x40]
00007b1fbf9e1502  vmovaps xmm5, [rsp+0x50]
00007b1fbf9e1508  vmovaps xmm6, [rsp+0x60]
00007b1fbf9e150e  vmovaps xmm7, [rsp+0x70]
00007b1fbf9e1514  vmovaps xmm8, [rsp+0x80]
00007b1fbf9e151d  vmovaps xmm10, [rsp+0x90]
00007b1fbf9e1526  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9e152f  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9e1538  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9e1541  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9e154a  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9e1553  add rsp, 0xF0
00007b1fbf9e155a  pop r11
00007b1fbf9e155c  pop r10
00007b1fbf9e155e  pop r9
00007b1fbf9e1560  pop r8
00007b1fbf9e1562  pop rsi
00007b1fbf9e1563  pop rdi
00007b1fbf9e1564  pop rdx
00007b1fbf9e1565  pop rcx
00007b1fbf9e1566  pop rax
00007b1fbf9e1567  add rsp, 0x08
00007b1fbf9e156b  jmp 0x00007B1FBF9DC7E2
00007b1fbf9e1570  sub rsp, 0x08
00007b1fbf9e1574  push rax
00007b1fbf9e1575  push rcx
00007b1fbf9e1576  push rdx
00007b1fbf9e1577  push rdi
00007b1fbf9e1578  push rsi
00007b1fbf9e1579  push r8
00007b1fbf9e157b  push r9
00007b1fbf9e157d  push r10
00007b1fbf9e157f  push r11
00007b1fbf9e1581  sub rsp, 0xF0
00007b1fbf9e1588  vmovaps [rsp], xmm0
00007b1fbf9e158d  vmovaps [rsp+0x10], xmm1
00007b1fbf9e1593  vmovaps [rsp+0x20], xmm2
00007b1fbf9e1599  vmovaps [rsp+0x30], xmm3
00007b1fbf9e159f  vmovaps [rsp+0x40], xmm4
00007b1fbf9e15a5  vmovaps [rsp+0x50], xmm5
00007b1fbf9e15ab  vmovaps [rsp+0x60], xmm6
00007b1fbf9e15b1  vmovaps [rsp+0x70], xmm7
00007b1fbf9e15b7  vmovaps [rsp+0x80], xmm8
00007b1fbf9e15c0  vmovaps [rsp+0x90], xmm9
00007b1fbf9e15c9  vmovaps [rsp+0xA0], xmm10
00007b1fbf9e15d2  vmovaps [rsp+0xB0], xmm11
00007b1fbf9e15db  vmovaps [rsp+0xC0], xmm12
00007b1fbf9e15e4  vmovaps [rsp+0xD0], xmm13
00007b1fbf9e15ed  vmovaps [rsp+0xE0], xmm14
00007b1fbf9e15f6  sub rsp, 0x30
00007b1fbf9e15fa  movaps [rsp], xmm15
00007b1fbf9e15ff  movaps [rsp+0x10], xmm11
00007b1fbf9e1605  movaps [rsp+0x20], xmm12
00007b1fbf9e160b  lea rdi, [rsp]
00007b1fbf9e160f  mov esi, 0x00
00007b1fbf9e1614  mov rax, 0x64AEE5F12530
00007b1fbf9e161e  call rax
00007b1fbf9e1620  movaps xmm15, [rsp]
00007b1fbf9e1625  add rsp, 0x30
00007b1fbf9e1629  vmovaps xmm0, [rsp]
00007b1fbf9e162e  vmovaps xmm1, [rsp+0x10]
00007b1fbf9e1634  vmovaps xmm2, [rsp+0x20]
00007b1fbf9e163a  vmovaps xmm3, [rsp+0x30]
00007b1fbf9e1640  vmovaps xmm4, [rsp+0x40]
00007b1fbf9e1646  vmovaps xmm5, [rsp+0x50]
00007b1fbf9e164c  vmovaps xmm6, [rsp+0x60]
00007b1fbf9e1652  vmovaps xmm7, [rsp+0x70]
00007b1fbf9e1658  vmovaps xmm8, [rsp+0x80]
00007b1fbf9e1661  vmovaps xmm9, [rsp+0x90]
00007b1fbf9e166a  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9e1673  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9e167c  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9e1685  vmovaps xmm13, [rsp+0xD0]
00007b1fbf9e168e  vmovaps xmm14, [rsp+0xE0]
00007b1fbf9e1697  add rsp, 0xF0
00007b1fbf9e169e  pop r11
00007b1fbf9e16a0  pop r10
00007b1fbf9e16a2  pop r9
00007b1fbf9e16a4  pop r8
00007b1fbf9e16a6  pop rsi
00007b1fbf9e16a7  pop rdi
00007b1fbf9e16a8  pop rdx
00007b1fbf9e16a9  pop rcx
00007b1fbf9e16aa  pop rax
00007b1fbf9e16ab  add rsp, 0x08
00007b1fbf9e16af  jmp 0x00007B1FBF9DC7FD
00007b1fbf9e16b4  sub rsp, 0x08
00007b1fbf9e16b8  push rax
00007b1fbf9e16b9  push rcx
00007b1fbf9e16ba  push rdx
00007b1fbf9e16bb  push rdi
00007b1fbf9e16bc  push rsi
00007b1fbf9e16bd  push r8
00007b1fbf9e16bf  push r9
00007b1fbf9e16c1  push r10
00007b1fbf9e16c3  push r11
00007b1fbf9e16c5  sub rsp, 0xF0
00007b1fbf9e16cc  vmovaps [rsp], xmm0
00007b1fbf9e16d1  vmovaps [rsp+0x10], xmm1
00007b1fbf9e16d7  vmovaps [rsp+0x20], xmm2
00007b1fbf9e16dd  vmovaps [rsp+0x30], xmm3
00007b1fbf9e16e3  vmovaps [rsp+0x40], xmm4
00007b1fbf9e16e9  vmovaps [rsp+0x50], xmm5
00007b1fbf9e16ef  vmovaps [rsp+0x60], xmm6
00007b1fbf9e16f5  vmovaps [rsp+0x70], xmm7
00007b1fbf9e16fb  vmovaps [rsp+0x80], xmm8
00007b1fbf9e1704  vmovaps [rsp+0x90], xmm9
00007b1fbf9e170d  vmovaps [rsp+0xA0], xmm10
00007b1fbf9e1716  vmovaps [rsp+0xB0], xmm11
00007b1fbf9e171f  vmovaps [rsp+0xC0], xmm12
00007b1fbf9e1728  vmovaps [rsp+0xD0], xmm14
00007b1fbf9e1731  vmovaps [rsp+0xE0], xmm15
00007b1fbf9e173a  sub rsp, 0x30
00007b1fbf9e173e  movaps [rsp], xmm13
00007b1fbf9e1743  movaps [rsp+0x10], xmm10
00007b1fbf9e1749  movaps [rsp+0x20], xmm14
00007b1fbf9e174f  lea rdi, [rsp]
00007b1fbf9e1753  mov esi, 0x00
00007b1fbf9e1758  mov rax, 0x64AEE5F12530
00007b1fbf9e1762  call rax
00007b1fbf9e1764  movaps xmm13, [rsp]
00007b1fbf9e1769  add rsp, 0x30
00007b1fbf9e176d  vmovaps xmm0, [rsp]
00007b1fbf9e1772  vmovaps xmm1, [rsp+0x10]
00007b1fbf9e1778  vmovaps xmm2, [rsp+0x20]
00007b1fbf9e177e  vmovaps xmm3, [rsp+0x30]
00007b1fbf9e1784  vmovaps xmm4, [rsp+0x40]
00007b1fbf9e178a  vmovaps xmm5, [rsp+0x50]
00007b1fbf9e1790  vmovaps xmm6, [rsp+0x60]
00007b1fbf9e1796  vmovaps xmm7, [rsp+0x70]
00007b1fbf9e179c  vmovaps xmm8, [rsp+0x80]
00007b1fbf9e17a5  vmovaps xmm9, [rsp+0x90]
00007b1fbf9e17ae  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9e17b7  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9e17c0  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9e17c9  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9e17d2  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9e17db  add rsp, 0xF0
00007b1fbf9e17e2  pop r11
00007b1fbf9e17e4  pop r10
00007b1fbf9e17e6  pop r9
00007b1fbf9e17e8  pop r8
00007b1fbf9e17ea  pop rsi
00007b1fbf9e17eb  pop rdi
00007b1fbf9e17ec  pop rdx
00007b1fbf9e17ed  pop rcx
00007b1fbf9e17ee  pop rax
00007b1fbf9e17ef  add rsp, 0x08
00007b1fbf9e17f3  jmp 0x00007B1FBF9DC820
00007b1fbf9e17f8  sub rsp, 0x08
00007b1fbf9e17fc  push rax
00007b1fbf9e17fd  push rcx
00007b1fbf9e17fe  push rdx
00007b1fbf9e17ff  push rdi
00007b1fbf9e1800  push rsi
00007b1fbf9e1801  push r8
00007b1fbf9e1803  push r9
00007b1fbf9e1805  push r10
00007b1fbf9e1807  push r11
00007b1fbf9e1809  sub rsp, 0xF0
00007b1fbf9e1810  vmovaps [rsp], xmm0
00007b1fbf9e1815  vmovaps [rsp+0x10], xmm1
00007b1fbf9e181b  vmovaps [rsp+0x20], xmm2
00007b1fbf9e1821  vmovaps [rsp+0x30], xmm3
00007b1fbf9e1827  vmovaps [rsp+0x40], xmm4
00007b1fbf9e182d  vmovaps [rsp+0x50], xmm5
00007b1fbf9e1833  vmovaps [rsp+0x60], xmm6
00007b1fbf9e1839  vmovaps [rsp+0x70], xmm7
00007b1fbf9e183f  vmovaps [rsp+0x80], xmm8
00007b1fbf9e1848  vmovaps [rsp+0x90], xmm9
00007b1fbf9e1851  vmovaps [rsp+0xA0], xmm10
00007b1fbf9e185a  vmovaps [rsp+0xB0], xmm11
00007b1fbf9e1863  vmovaps [rsp+0xC0], xmm12
00007b1fbf9e186c  vmovaps [rsp+0xD0], xmm13
00007b1fbf9e1875  vmovaps [rsp+0xE0], xmm15
00007b1fbf9e187e  sub rsp, 0x30
00007b1fbf9e1882  movaps [rsp], xmm14
00007b1fbf9e1887  movaps [rsp+0x10], xmm1
00007b1fbf9e188c  movaps [rsp+0x20], xmm7
00007b1fbf9e1891  lea rdi, [rsp]
00007b1fbf9e1895  mov esi, 0x00
00007b1fbf9e189a  mov rax, 0x64AEE5F12530
00007b1fbf9e18a4  call rax
00007b1fbf9e18a6  movaps xmm14, [rsp]
00007b1fbf9e18ab  add rsp, 0x30
00007b1fbf9e18af  vmovaps xmm0, [rsp]
00007b1fbf9e18b4  vmovaps xmm1, [rsp+0x10]
00007b1fbf9e18ba  vmovaps xmm2, [rsp+0x20]
00007b1fbf9e18c0  vmovaps xmm3, [rsp+0x30]
00007b1fbf9e18c6  vmovaps xmm4, [rsp+0x40]
00007b1fbf9e18cc  vmovaps xmm5, [rsp+0x50]
00007b1fbf9e18d2  vmovaps xmm6, [rsp+0x60]
00007b1fbf9e18d8  vmovaps xmm7, [rsp+0x70]
00007b1fbf9e18de  vmovaps xmm8, [rsp+0x80]
00007b1fbf9e18e7  vmovaps xmm9, [rsp+0x90]
00007b1fbf9e18f0  vmovaps xmm10, [rsp+0xA0]
00007b1fbf9e18f9  vmovaps xmm11, [rsp+0xB0]
00007b1fbf9e1902  vmovaps xmm12, [rsp+0xC0]
00007b1fbf9e190b  vmovaps xmm13, [rsp+0xD0]
00007b1fbf9e1914  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9e191d  add rsp, 0xF0
00007b1fbf9e1924  pop r11
00007b1fbf9e1926  pop r10
00007b1fbf9e1928  pop r9
00007b1fbf9e192a  pop r8
00007b1fbf9e192c  pop rsi
00007b1fbf9e192d  pop rdi
00007b1fbf9e192e  pop rdx
00007b1fbf9e192f  pop rcx
00007b1fbf9e1930  pop rax
00007b1fbf9e1931  add rsp, 0x08
00007b1fbf9e1935  jmp 0x00007B1FBF9DC843
00007b1fbf9e193a  sub rsp, 0x08
00007b1fbf9e193e  push rax
00007b1fbf9e193f  push rcx
00007b1fbf9e1940  push rdx
00007b1fbf9e1941  push rdi
00007b1fbf9e1942  push rsi
00007b1fbf9e1943  push r8
00007b1fbf9e1945  push r9
00007b1fbf9e1947  push r10
00007b1fbf9e1949  push r11
00007b1fbf9e194b  sub rsp, 0xF0
00007b1fbf9e1952  vmovaps [rsp], xmm0
00007b1fbf9e1957  vmovaps [rsp+0x10], xmm2
00007b1fbf9e195d  vmovaps [rsp+0x20], xmm3
00007b1fbf9e1963  vmovaps [rsp+0x30], xmm4
00007b1fbf9e1969  vmovaps [rsp+0x40], xmm5
00007b1fbf9e196f  vmovaps [rsp+0x50], xmm6
00007b1fbf9e1975  vmovaps [rsp+0x60], xmm7
00007b1fbf9e197b  vmovaps [rsp+0x70], xmm8
00007b1fbf9e1981  vmovaps [rsp+0x80], xmm9
00007b1fbf9e198a  vmovaps [rsp+0x90], xmm10
00007b1fbf9e1993  vmovaps [rsp+0xA0], xmm11
00007b1fbf9e199c  vmovaps [rsp+0xB0], xmm12
00007b1fbf9e19a5  vmovaps [rsp+0xC0], xmm13
00007b1fbf9e19ae  vmovaps [rsp+0xD0], xmm14
00007b1fbf9e19b7  vmovaps [rsp+0xE0], xmm15
00007b1fbf9e19c0  sub rsp, 0x30
00007b1fbf9e19c4  movaps [rsp], xmm1
00007b1fbf9e19c8  movaps [rsp+0x10], xmm8
00007b1fbf9e19ce  movaps [rsp+0x20], xmm9
00007b1fbf9e19d4  lea rdi, [rsp]
00007b1fbf9e19d8  mov esi, 0x00
00007b1fbf9e19dd  mov rax, 0x64AEE5F12530
00007b1fbf9e19e7  call rax
00007b1fbf9e19e9  movaps xmm1, [rsp]
00007b1fbf9e19ed  add rsp, 0x30
00007b1fbf9e19f1  vmovaps xmm0, [rsp]
00007b1fbf9e19f6  vmovaps xmm2, [rsp+0x10]
00007b1fbf9e19fc  vmovaps xmm3, [rsp+0x20]
00007b1fbf9e1a02  vmovaps xmm4, [rsp+0x30]
00007b1fbf9e1a08  vmovaps xmm5, [rsp+0x40]
00007b1fbf9e1a0e  vmovaps xmm6, [rsp+0x50]
00007b1fbf9e1a14  vmovaps xmm7, [rsp+0x60]
00007b1fbf9e1a1a  vmovaps xmm8, [rsp+0x70]
00007b1fbf9e1a20  vmovaps xmm9, [rsp+0x80]
00007b1fbf9e1a29  vmovaps xmm10, [rsp+0x90]
00007b1fbf9e1a32  vmovaps xmm11, [rsp+0xA0]
00007b1fbf9e1a3b  vmovaps xmm12, [rsp+0xB0]
00007b1fbf9e1a44  vmovaps xmm13, [rsp+0xC0]
00007b1fbf9e1a4d  vmovaps xmm14, [rsp+0xD0]
00007b1fbf9e1a56  vmovaps xmm15, [rsp+0xE0]
00007b1fbf9e1a5f  add rsp, 0xF0
00007b1fbf9e1a66  pop r11
00007b1fbf9e1a68  pop r10
00007b1fbf9e1a6a  pop r9
00007b1fbf9e1a6c  pop r8
00007b1fbf9e1a6e  pop rsi
00007b1fbf9e1a6f  pop rdi
00007b1fbf9e1a70  pop rdx
00007b1fbf9e1a71  pop rcx
00007b1fbf9e1a72  pop rax
00007b1fbf9e1a73  add rsp, 0x08
00007b1fbf9e1a77  jmp 0x00007B1FBF9DC865
00007b1fbf9e1a7c  call 0x00007B1FBF8E5940
00007b1fbf9e1a81  jmp 0x00007B1FBF9DC873
00007b1fbf9e1a86  call 0x00007B1FBF80C380
00007b1fbf9e1a8b  jmp 0x00007B1FBF9DC87D
00007b1fbf9e1a90  call 0x00007B1FBF80D600
00007b1fbf9e1a95  jmp 0x00007B1FBF9DC887
00007b1fbf9e1a9a  call 0x00007B1FBF7FF540
00007b1fbf9e1a9f  jmp 0x00007B1FBF9DC891
00007b1fbf9e1aa4  int3
00007b1fbf9e1aa5  nop [rax+rax*1], ax
00007b1fbf9e1aae  nop
00007b1fbf9e1ab0  mov rax, [r15+0xF8]
00007b1fbf9e1ab7  lea r14, [rax+0x140]
00007b1fbf9e1abe  mov r12, [r13+r14*1]
00007b1fbf9e1ac3  mov [r15+0xE8], r12
00007b1fbf9e1aca  lea r14, [rax+0x130]
00007b1fbf9e1ad1  mov r12, [r13+r14*1]
00007b1fbf9e1ad6  lea r14, [rax+0x138]
00007b1fbf9e1add  mov r11, [r13+r14*1]
00007b1fbf9e1ae2  movq xmm1, r12
00007b1fbf9e1ae7  movq xmm15, r11
00007b1fbf9e1aec  movq xmm1, xmm1
00007b1fbf9e1af0  movq xmm1, xmm1
00007b1fbf9e1af4  movaps [r15+0x1A0], xmm1
00007b1fbf9e1afc  movq xmm15, xmm15
00007b1fbf9e1b01  movq xmm15, xmm15
00007b1fbf9e1b06  movaps [r15+0x190], xmm15
00007b1fbf9e1b0e  lea r14, [rax+0x120]
00007b1fbf9e1b15  mov r12, [r13+r14*1]
00007b1fbf9e1b1a  lea r14, [rax+0x128]
00007b1fbf9e1b21  mov r11, [r13+r14*1]
00007b1fbf9e1b26  movq xmm1, r12
00007b1fbf9e1b2b  movq xmm15, r11
00007b1fbf9e1b30  movq xmm1, xmm1
00007b1fbf9e1b34  movq xmm1, xmm1
00007b1fbf9e1b38  movaps [r15+0x1C0], xmm1
00007b1fbf9e1b40  movq xmm15, xmm15
00007b1fbf9e1b45  movq xmm15, xmm15
00007b1fbf9e1b4a  movaps [r15+0x1B0], xmm15
00007b1fbf9e1b52  lea r14, [rax+0x110]
00007b1fbf9e1b59  mov r12, [r13+r14*1]
00007b1fbf9e1b5e  lea r14, [rax+0x118]
00007b1fbf9e1b65  mov r11, [r13+r14*1]
00007b1fbf9e1b6a  movq xmm1, r12
00007b1fbf9e1b6f  movq xmm15, r11
00007b1fbf9e1b74  movq xmm1, xmm1
00007b1fbf9e1b78  movq xmm1, xmm1
00007b1fbf9e1b7c  movaps [r15+0x1E0], xmm1
00007b1fbf9e1b84  movq xmm15, xmm15
00007b1fbf9e1b89  movq xmm15, xmm15
00007b1fbf9e1b8e  movaps [r15+0x1D0], xmm15
00007b1fbf9e1b96  lea r14, [rax+0x100]
00007b1fbf9e1b9d  mov r12, [r13+r14*1]
00007b1fbf9e1ba2  lea r14, [rax+0x108]
00007b1fbf9e1ba9  mov r11, [r13+r14*1]
00007b1fbf9e1bae  movq xmm1, r12
00007b1fbf9e1bb3  movq xmm15, r11
00007b1fbf9e1bb8  movq xmm1, xmm1
00007b1fbf9e1bbc  movq xmm1, xmm1
00007b1fbf9e1bc0  movaps [r15+0x200], xmm1
00007b1fbf9e1bc8  movq xmm15, xmm15
00007b1fbf9e1bcd  movq xmm15, xmm15
00007b1fbf9e1bd2  movaps [r15+0x1F0], xmm15
00007b1fbf9e1bda  mov qword ptr [r15+0x40], 0x430000
00007b1fbf9e1be2  mov r14d, 0x430510
00007b1fbf9e1be8  mov r12, [r13+r14*1]
00007b1fbf9e1bed  movq xmm1, r12
00007b1fbf9e1bf2  lea r14, [rax+0x150]
00007b1fbf9e1bf9  mov [r15+0xF8], r14
00007b1fbf9e1c00  mov rax, [r15+0x50]
00007b1fbf9e1c04  movups xmm15, [r13+rax*1]
00007b1fbf9e1c0a  movaps [r15+0x120], xmm15
00007b1fbf9e1c12  mov qword ptr [r15+0x48], 0x10
00007b1fbf9e1c1a  xor eax, eax
00007b1fbf9e1c1c  mov r14d, 0x10
00007b1fbf9e1c22  mov r12d, 0x200
00007b1fbf9e1c28  cmp r14, r12
00007b1fbf9e1c2b  cmc
00007b1fbf9e1c2c  lahf
00007b1fbf9e1c2d  seto al
00007b1fbf9e1c30  mov [r15+0x108], eax
00007b1fbf9e1c37  pextrq rax, xmm15, 0x01
00007b1fbf9e1c3e  movq xmm14, rax
00007b1fbf9e1c43  movaps [r15+0x130], xmm14
00007b1fbf9e1c4b  movq rax, xmm1
00007b1fbf9e1c50  movq r14, xmm15
00007b1fbf9e1c55  vmovq xmm1, rax
00007b1fbf9e1c5a  vmovq xmm15, r14
00007b1fbf9e1c5f  movaps xmm13, xmm1
00007b1fbf9e1c63  addsd xmm13, xmm15
00007b1fbf9e1c68  ucomisd xmm13, xmm13
00007b1fbf9e1c6d  jp 0x00007B1FBF9E1D86
00007b1fbf9e1c73  movq xmm13, xmm13
00007b1fbf9e1c78  movq rax, xmm13
00007b1fbf9e1c7d  movq r14, xmm14
00007b1fbf9e1c82  vmovq xmm1, rax
00007b1fbf9e1c87  vmovq xmm15, r14
00007b1fbf9e1c8c  movaps xmm14, xmm1
00007b1fbf9e1c90  addsd xmm14, xmm15
00007b1fbf9e1c95  ucomisd xmm14, xmm14
00007b1fbf9e1c9a  jp 0x00007B1FBF9E1DCE
00007b1fbf9e1ca0  movq xmm14, xmm14
00007b1fbf9e1ca5  movaps [r15+0x110], xmm14
00007b1fbf9e1cad  mov eax, [r15+0x108]
00007b1fbf9e1cb4  sahf
00007b1fbf9e1cb5  jnz 0x00007B1FBF9E1CE7
00007b1fbf9e1cb7  cmp dword ptr [r15+0x318], 0x00
00007b1fbf9e1cbf  jz 0x00007B1FBF9E1FE0
00007b1fbf9e1cc5  nop [rax+rax*1], ax
00007b1fbf9e1cce  nop [rax+rax*1], eax
00007b1fbf9e1cd6  mov eax, 0x410490
00007b1fbf9e1cdb  mov [r15+0x100], rax
00007b1fbf9e1ce2  jmp 0x00007B1FBF7FE110
00007b1fbf9e1ce7  cmp dword ptr [r15+0x318], 0x00
00007b1fbf9e1cef  jz 0x00007B1FBF9E1E20
00007b1fbf9e1cf5  nop [rax+rax*1], ax
00007b1fbf9e1cfe  nop [rax+rax*1], eax
00007b1fbf9e1d06  mov eax, 0x410474
00007b1fbf9e1d0b  mov [r15+0x100], rax
00007b1fbf9e1d12  jmp 0x00007B1FBF7FE110
00007b1fbf9e1d17  int3
00007b1fbf9e1d18  call 0x00007B1FBF8E27E0
00007b1fbf9e1d1d  jmp 0x00007B1FBF9E1AC3
00007b1fbf9e1d22  call 0x00007B1FBF8E27E0
00007b1fbf9e1d27  jmp 0x00007B1FBF9E1AD6
00007b1fbf9e1d2c  call 0x00007B1FBF8E1570
00007b1fbf9e1d31  jmp 0x00007B1FBF9E1AE2
00007b1fbf9e1d36  call 0x00007B1FBF8E27E0
00007b1fbf9e1d3b  jmp 0x00007B1FBF9E1B1A
00007b1fbf9e1d40  call 0x00007B1FBF8E1570
00007b1fbf9e1d45  jmp 0x00007B1FBF9E1B26
00007b1fbf9e1d4a  call 0x00007B1FBF8E27E0
00007b1fbf9e1d4f  jmp 0x00007B1FBF9E1B5E
00007b1fbf9e1d54  call 0x00007B1FBF8E1570
00007b1fbf9e1d59  jmp 0x00007B1FBF9E1B6A
00007b1fbf9e1d5e  call 0x00007B1FBF8E27E0
00007b1fbf9e1d63  jmp 0x00007B1FBF9E1BA2
00007b1fbf9e1d68  call 0x00007B1FBF8E1570
00007b1fbf9e1d6d  jmp 0x00007B1FBF9E1BAE
00007b1fbf9e1d72  call 0x00007B1FBF8E27E0
00007b1fbf9e1d77  jmp 0x00007B1FBF9E1BED
00007b1fbf9e1d7c  call 0x00007B1FBF80E760
00007b1fbf9e1d81  jmp 0x00007B1FBF9E1C0A
00007b1fbf9e1d86  ucomisd xmm1, xmm15
00007b1fbf9e1d8b  jp 0x00007B1FBF9E1D9A
00007b1fbf9e1d8d  movaps xmm13, [0x00007B1FBF5FE060]
00007b1fbf9e1d95  jmp 0x00007B1FBF9E1C73
00007b1fbf9e1d9a  vxorps xmm0, xmm1, xmm15
00007b1fbf9e1d9f  pextrw eax, xmm0, 0x03
00007b1fbf9e1da4  and eax, 0x7FF8
00007b1fbf9e1da9  cmp eax, 0x08
00007b1fbf9e1dac  jnz 0x00007B1FBF9E1C73
00007b1fbf9e1db2  movq rax, xmm15
00007b1fbf9e1db7  shl rax, 0x0D
00007b1fbf9e1dbb  jbe 0x00007B1FBF9E1C73
00007b1fbf9e1dc1  vorps xmm13, xmm15, [0x00007B1FBF5FE070]
00007b1fbf9e1dc9  jmp 0x00007B1FBF9E1C73
00007b1fbf9e1dce  ucomisd xmm1, xmm15
00007b1fbf9e1dd3  jp 0x00007B1FBF9E1DE2
00007b1fbf9e1dd5  movaps xmm14, [0x00007B1FBF5FE060]
00007b1fbf9e1ddd  jmp 0x00007B1FBF9E1CA0
00007b1fbf9e1de2  vxorps xmm0, xmm1, xmm15
00007b1fbf9e1de7  pextrw eax, xmm0, 0x03
00007b1fbf9e1dec  and eax, 0x7FF8
00007b1fbf9e1df1  cmp eax, 0x08
00007b1fbf9e1df4  jnz 0x00007B1FBF9E1CA0
00007b1fbf9e1dfa  movq rax, xmm15
00007b1fbf9e1dff  shl rax, 0x0D
00007b1fbf9e1e03  jbe 0x00007B1FBF9E1CA0
00007b1fbf9e1e09  vorps xmm14, xmm15, [0x00007B1FBF5FE070]
00007b1fbf9e1e11  jmp 0x00007B1FBF9E1CA0
00007b1fbf9e1e16  int3
00007b1fbf9e1e17  nop [rax+rax*1], ax
00007b1fbf9e1e20  mov rax, [r15+0x48]
00007b1fbf9e1e24  mov r14, [r15+0x50]
00007b1fbf9e1e28  lea r12, [r14+rax*1]
00007b1fbf9e1e2c  movups xmm1, [r13+r12*1]
00007b1fbf9e1e32  movaps [r15+0x120], xmm1
00007b1fbf9e1e3a  lea r14, [rax+0x10]
00007b1fbf9e1e3e  mov [r15+0x48], r14
00007b1fbf9e1e42  xor eax, eax
00007b1fbf9e1e44  mov r12d, 0x200
00007b1fbf9e1e4a  cmp r14, r12
00007b1fbf9e1e4d  cmc
00007b1fbf9e1e4e  lahf
00007b1fbf9e1e4f  seto al
00007b1fbf9e1e52  mov [r15+0x108], eax
00007b1fbf9e1e59  pextrq rax, xmm1, 0x01
00007b1fbf9e1e60  movq xmm15, rax
00007b1fbf9e1e65  movaps [r15+0x130], xmm15
00007b1fbf9e1e6d  movaps xmm14, [r15+0x110]
00007b1fbf9e1e75  movq rax, xmm14
00007b1fbf9e1e7a  movq r14, xmm1
00007b1fbf9e1e7f  vmovq xmm1, rax
00007b1fbf9e1e84  vmovq xmm14, r14
00007b1fbf9e1e89  movaps xmm13, xmm1
00007b1fbf9e1e8d  addsd xmm13, xmm14
00007b1fbf9e1e92  ucomisd xmm13, xmm13
00007b1fbf9e1e97  jp 0x00007B1FBF9E1F4C
00007b1fbf9e1e9d  movq xmm13, xmm13
00007b1fbf9e1ea2  movq rax, xmm13
00007b1fbf9e1ea7  movq r14, xmm15
00007b1fbf9e1eac  vmovq xmm1, rax
00007b1fbf9e1eb1  vmovq xmm15, r14
00007b1fbf9e1eb6  movaps xmm14, xmm1
00007b1fbf9e1eba  addsd xmm14, xmm15
00007b1fbf9e1ebf  ucomisd xmm14, xmm14
00007b1fbf9e1ec4  jp 0x00007B1FBF9E1F94
00007b1fbf9e1eca  movq xmm14, xmm14
00007b1fbf9e1ecf  movaps [r15+0x110], xmm14
00007b1fbf9e1ed7  mov eax, [r15+0x108]
00007b1fbf9e1ede  sahf
00007b1fbf9e1edf  jnz 0x00007B1FBF9E1F11
00007b1fbf9e1ee1  cmp dword ptr [r15+0x318], 0x00
00007b1fbf9e1ee9  jz 0x00007B1FBF9E1FE0
00007b1fbf9e1eef  nop [rax+rax*1], ax
00007b1fbf9e1ef8  nop [rax+rax*1], eax
00007b1fbf9e1f00  mov eax, 0x410490
00007b1fbf9e1f05  mov [r15+0x100], rax
00007b1fbf9e1f0c  jmp 0x00007B1FBF7FE110
00007b1fbf9e1f11  cmp dword ptr [r15+0x318], 0x00
00007b1fbf9e1f19  jz 0x00007B1FBF9E1E20
00007b1fbf9e1f1f  nop [rax+rax*1], ax
00007b1fbf9e1f28  nop [rax+rax*1], eax
00007b1fbf9e1f30  mov eax, 0x410474
00007b1fbf9e1f35  mov [r15+0x100], rax
00007b1fbf9e1f3c  jmp 0x00007B1FBF7FE110
00007b1fbf9e1f41  int3
00007b1fbf9e1f42  call 0x00007B1FBF8B52F0
00007b1fbf9e1f47  jmp 0x00007B1FBF9E1E32
00007b1fbf9e1f4c  ucomisd xmm1, xmm14
00007b1fbf9e1f51  jp 0x00007B1FBF9E1F60
00007b1fbf9e1f53  movaps xmm13, [0x00007B1FBF5FE060]
00007b1fbf9e1f5b  jmp 0x00007B1FBF9E1E9D
00007b1fbf9e1f60  vxorps xmm0, xmm1, xmm14
00007b1fbf9e1f65  pextrw eax, xmm0, 0x03
00007b1fbf9e1f6a  and eax, 0x7FF8
00007b1fbf9e1f6f  cmp eax, 0x08
00007b1fbf9e1f72  jnz 0x00007B1FBF9E1E9D
00007b1fbf9e1f78  movq rax, xmm14
00007b1fbf9e1f7d  shl rax, 0x0D
00007b1fbf9e1f81  jbe 0x00007B1FBF9E1E9D
00007b1fbf9e1f87  vorps xmm13, xmm14, [0x00007B1FBF5FE070]
00007b1fbf9e1f8f  jmp 0x00007B1FBF9E1E9D
00007b1fbf9e1f94  ucomisd xmm1, xmm15
00007b1fbf9e1f99  jp 0x00007B1FBF9E1FA8
00007b1fbf9e1f9b  movaps xmm14, [0x00007B1FBF5FE060]
00007b1fbf9e1fa3  jmp 0x00007B1FBF9E1ECA
00007b1fbf9e1fa8  vxorps xmm0, xmm1, xmm15
00007b1fbf9e1fad  pextrw eax, xmm0, 0x03
00007b1fbf9e1fb2  and eax, 0x7FF8
00007b1fbf9e1fb7  cmp eax, 0x08
00007b1fbf9e1fba  jnz 0x00007B1FBF9E1ECA
00007b1fbf9e1fc0  movq rax, xmm15
00007b1fbf9e1fc5  shl rax, 0x0D
00007b1fbf9e1fc9  jbe 0x00007B1FBF9E1ECA
00007b1fbf9e1fcf  vorps xmm14, xmm15, [0x00007B1FBF5FE070]
00007b1fbf9e1fd7  jmp 0x00007B1FBF9E1ECA
00007b1fbf9e1fdc  int3
00007b1fbf9e1fdd  nop [rax], eax
00007b1fbf9e1fe0  mov rax, [r15+0x40]
00007b1fbf9e1fe4  lea r14, [rax+0x510]
00007b1fbf9e1feb  movaps xmm1, [r15+0x110]
00007b1fbf9e1ff3  movq rax, xmm1
00007b1fbf9e1ff8  mov [r13+r14*1], rax
00007b1fbf9e1ffd  mov rax, [r15+0xF0]
00007b1fbf9e2004  mov [r15+0x100], rax
00007b1fbf9e200b  jmp 0x00007B1FBF9CE5C0
00007b1fbf9e2010  int3
00007b1fbf9e2011  call 0x00007B1FBF8D5EB0
00007b1fbf9e2016  jmp 0x00007B1FBF9E1FFD
00007b1fbf9e201b  int3
00007b1fbf9e201c  nop [rax], eax
00007b1fbf9e2020  mov qword ptr [r15+0x100], 0x04
00007b1fbf9e202b  mov esi, 0x00
00007b1fbf9e2030  mov edx, 0x09
00007b1fbf9e2035  mov rdi, 0x7FFFD8BE72D0
00007b1fbf9e203f  mov rax, 0x64AEE5DA5970
00007b1fbf9e2049  call rax
00007b1fbf9e204b  cmp dword ptr [r15+0x318], 0x00
00007b1fbf9e2053  jnz 0x00007B1FBF7FE110
00007b1fbf9e2059  jmp 0x00007B1FBF7FE0A0
00007b1fbf9e205e  int3
00007b1fbf9e205f  int3
