00007efc33fce69b  nop [rax+rax*1], eax
00007efc33fce6a0  vmovaps xmm1, [0x00007EFC33BFE010]
00007efc33fce6a8  movq xmm1, xmm1
00007efc33fce6ac  movaps [r15+0x110], xmm1
00007efc33fce6b4  vmovaps xmm1, [0x00007EFC33BFE020]
00007efc33fce6bc  movq xmm1, xmm1
00007efc33fce6c0  movaps [r15+0x120], xmm1
00007efc33fce6c8  mov eax, 0x4204C0
00007efc33fce6cd  mov r14, [r13+rax*1]
00007efc33fce6d2  movq xmm1, r14
00007efc33fce6d7  movaps [r15+0x130], xmm1
00007efc33fce6df  vmovaps xmm1, [0x00007EFC33BFE030]
00007efc33fce6e7  vpbroadcastq xmm1, xmm1
00007efc33fce6ec  movaps [r15+0x140], xmm1
00007efc33fce6f4  mov qword ptr [r15+0x40], 0x02
00007efc33fce6fc  vmovaps xmm15, [0x00007EFC33BFE040]
00007efc33fce704  movq xmm15, xmm15
00007efc33fce709  movaps [r15+0x150], xmm15
00007efc33fce711  mov qword ptr [r15+0x58], 0x420000
00007efc33fce719  vmovaps xmm15, [0x00007EFC33BFE050]
00007efc33fce721  vpbroadcastq xmm15, xmm15
00007efc33fce726  movaps [r15+0x160], xmm15
00007efc33fce72e  mov rax, [r15+0x40]
00007efc33fce732  vmovq xmm14, rax
00007efc33fce737  vpbroadcastq xmm14, xmm14
00007efc33fce73c  movaps [r15+0x170], xmm14
00007efc33fce744  mov eax, 0x4204D0
00007efc33fce749  movups xmm13, [r13+rax*1]
00007efc33fce74f  mov qword ptr [r15+0x40], 0x430518
00007efc33fce757  mov qword ptr [r15+0x50], 0x430720
00007efc33fce75f  vpmovqd xmm12, xmm13
00007efc33fce765  pxor xmm11, xmm11
00007efc33fce76a  punpcklqdq xmm12, xmm11
00007efc33fce76f  movaps [r15+0x210], xmm12
00007efc33fce777  movq xmm12, qword ptr [r15+0x120]
00007efc33fce780  movq xmm11, qword ptr [r15+0x130]
00007efc33fce789  psubd xmm12, xmm11
00007efc33fce78e  movq xmm12, xmm12
00007efc33fce793  paddq xmm13, xmm14
00007efc33fce798  movaps [r15+0x180], xmm13
00007efc33fce7a0  movq xmm14, qword ptr [r15+0x150]
00007efc33fce7a9  paddd xmm11, xmm14
00007efc33fce7ae  movq xmm11, xmm11
00007efc33fce7b3  movq xmm11, xmm11
00007efc33fce7b8  movaps [r15+0x130], xmm11
00007efc33fce7c0  pmovzxdq xmm12, xmm12
00007efc33fce7c6  psllq xmm12, 0x00
00007efc33fce7cc  movq xmm14, qword ptr [r15+0x210]
00007efc33fce7d5  movq xmm13, qword ptr [r15+0x110]
00007efc33fce7de  paddd xmm14, xmm13
00007efc33fce7e3  movq xmm14, xmm14
00007efc33fce7e8  vcvtuqq2pd xmm12, xmm12
00007efc33fce7ee  pmovzxdq xmm14, xmm14
00007efc33fce7f4  psllq xmm14, 0x00
00007efc33fce7fa  vcvtuqq2pd xmm14, xmm14
00007efc33fce800  movaps xmm13, xmm12
00007efc33fce804  mulpd xmm13, xmm1
00007efc33fce809  vcmppd xmm11, xmm13, xmm13, 0x03
00007efc33fce80f  ptest xmm11, xmm11
00007efc33fce815  jnz 0x00007EFC33FCE8FF
00007efc33fce81b  movaps [r15+0x220], xmm13
00007efc33fce823  mov eax, 0x430720
00007efc33fce828  movups [r13+rax*1], xmm13
00007efc33fce82e  movaps xmm1, xmm14
00007efc33fce832  mulpd xmm1, xmm15
00007efc33fce837  vcmppd xmm13, xmm1, xmm1, 0x03
00007efc33fce83c  ptest xmm13, xmm13
00007efc33fce842  jnz 0x00007EFC33FCEA4C
00007efc33fce848  movaps [r15+0x210], xmm1
00007efc33fce850  mov eax, 0x430518
00007efc33fce855  movups [r13+rax*1], xmm1
00007efc33fce85b  mov qword ptr [r15+0x48], 0x10
00007efc33fce863  xor eax, eax
00007efc33fce865  mov r14d, 0x10
00007efc33fce86b  mov r12d, 0x200
00007efc33fce871  cmp r14, r12
00007efc33fce874  cmc
00007efc33fce875  lahf
00007efc33fce876  seto al
00007efc33fce879  mov [r15+0x108], eax
00007efc33fce880  mov eax, [r15+0x108]
00007efc33fce887  sahf
00007efc33fce888  jnz 0x00007EFC33FCE8BA
00007efc33fce88a  cmp dword ptr [r15+0x318], 0x00
00007efc33fce892  jz 0x00007EFC33FCEFF0
00007efc33fce898  nop [rax+rax*1], ax
00007efc33fce8a1  nop [rax+rax*1], eax
00007efc33fce8a9  mov eax, 0x4101EC
00007efc33fce8ae  mov [r15+0x100], rax
00007efc33fce8b5  jmp 0x00007EFC33DFE110
00007efc33fce8ba  cmp dword ptr [r15+0x318], 0x00
00007efc33fce8c2  jz 0x00007EFC33FCEBA0
00007efc33fce8c8  nop [rax+rax*1], ax
00007efc33fce8d1  nop [rax+rax*1], eax
00007efc33fce8d9  mov eax, 0x4101AC
00007efc33fce8de  mov [r15+0x100], rax
00007efc33fce8e5  jmp 0x00007EFC33DFE110
00007efc33fce8ea  int3
00007efc33fce8eb  call 0x00007EFC33E0DC20
00007efc33fce8f0  jmp 0x00007EFC33FCE6D2
00007efc33fce8f5  call 0x00007EFC33E0C260
00007efc33fce8fa  jmp 0x00007EFC33FCE74F
00007efc33fce8ff  sub rsp, 0x08
00007efc33fce903  push rax
00007efc33fce904  push rcx
00007efc33fce905  push rdx
00007efc33fce906  push rdi
00007efc33fce907  push rsi
00007efc33fce908  push r8
00007efc33fce90a  push r9
00007efc33fce90c  push r10
00007efc33fce90e  push r11
00007efc33fce910  sub rsp, 0xF0
00007efc33fce917  vmovaps [rsp], xmm0
00007efc33fce91c  vmovaps [rsp+0x10], xmm1
00007efc33fce922  vmovaps [rsp+0x20], xmm2
00007efc33fce928  vmovaps [rsp+0x30], xmm3
00007efc33fce92e  vmovaps [rsp+0x40], xmm4
00007efc33fce934  vmovaps [rsp+0x50], xmm5
00007efc33fce93a  vmovaps [rsp+0x60], xmm6
00007efc33fce940  vmovaps [rsp+0x70], xmm7
00007efc33fce946  vmovaps [rsp+0x80], xmm8
00007efc33fce94f  vmovaps [rsp+0x90], xmm9
00007efc33fce958  vmovaps [rsp+0xA0], xmm10
00007efc33fce961  vmovaps [rsp+0xB0], xmm11
00007efc33fce96a  vmovaps [rsp+0xC0], xmm12
00007efc33fce973  vmovaps [rsp+0xD0], xmm14
00007efc33fce97c  vmovaps [rsp+0xE0], xmm15
00007efc33fce985  sub rsp, 0x30
00007efc33fce989  movaps [rsp], xmm13
00007efc33fce98e  movaps [rsp+0x10], xmm12
00007efc33fce994  movaps [rsp+0x20], xmm1
00007efc33fce999  lea rdi, [rsp]
00007efc33fce99d  mov esi, 0x00
00007efc33fce9a2  mov rax, 0x5D9448894530
00007efc33fce9ac  call rax
00007efc33fce9ae  movaps xmm13, [rsp]
00007efc33fce9b3  add rsp, 0x30
00007efc33fce9b7  vmovaps xmm0, [rsp]
00007efc33fce9bc  vmovaps xmm1, [rsp+0x10]
00007efc33fce9c2  vmovaps xmm2, [rsp+0x20]
00007efc33fce9c8  vmovaps xmm3, [rsp+0x30]
00007efc33fce9ce  vmovaps xmm4, [rsp+0x40]
00007efc33fce9d4  vmovaps xmm5, [rsp+0x50]
00007efc33fce9da  vmovaps xmm6, [rsp+0x60]
00007efc33fce9e0  vmovaps xmm7, [rsp+0x70]
00007efc33fce9e6  vmovaps xmm8, [rsp+0x80]
00007efc33fce9ef  vmovaps xmm9, [rsp+0x90]
00007efc33fce9f8  vmovaps xmm10, [rsp+0xA0]
00007efc33fcea01  vmovaps xmm11, [rsp+0xB0]
00007efc33fcea0a  vmovaps xmm12, [rsp+0xC0]
00007efc33fcea13  vmovaps xmm14, [rsp+0xD0]
00007efc33fcea1c  vmovaps xmm15, [rsp+0xE0]
00007efc33fcea25  add rsp, 0xF0
00007efc33fcea2c  pop r11
00007efc33fcea2e  pop r10
00007efc33fcea30  pop r9
00007efc33fcea32  pop r8
00007efc33fcea34  pop rsi
00007efc33fcea35  pop rdi
00007efc33fcea36  pop rdx
00007efc33fcea37  pop rcx
00007efc33fcea38  pop rax
00007efc33fcea39  add rsp, 0x08
00007efc33fcea3d  jmp 0x00007EFC33FCE81B
00007efc33fcea42  call 0x00007EFC33E0C380
00007efc33fcea47  jmp 0x00007EFC33FCE82E
00007efc33fcea4c  sub rsp, 0x08
00007efc33fcea50  push rax
00007efc33fcea51  push rcx
00007efc33fcea52  push rdx
00007efc33fcea53  push rdi
00007efc33fcea54  push rsi
00007efc33fcea55  push r8
00007efc33fcea57  push r9
00007efc33fcea59  push r10
00007efc33fcea5b  push r11
00007efc33fcea5d  sub rsp, 0xF0
00007efc33fcea64  vmovaps [rsp], xmm0
00007efc33fcea69  vmovaps [rsp+0x10], xmm2
00007efc33fcea6f  vmovaps [rsp+0x20], xmm3
00007efc33fcea75  vmovaps [rsp+0x30], xmm4
00007efc33fcea7b  vmovaps [rsp+0x40], xmm5
00007efc33fcea81  vmovaps [rsp+0x50], xmm6
00007efc33fcea87  vmovaps [rsp+0x60], xmm7
00007efc33fcea8d  vmovaps [rsp+0x70], xmm8
00007efc33fcea93  vmovaps [rsp+0x80], xmm9
00007efc33fcea9c  vmovaps [rsp+0x90], xmm10
00007efc33fceaa5  vmovaps [rsp+0xA0], xmm11
00007efc33fceaae  vmovaps [rsp+0xB0], xmm12
00007efc33fceab7  vmovaps [rsp+0xC0], xmm13
00007efc33fceac0  vmovaps [rsp+0xD0], xmm14
00007efc33fceac9  vmovaps [rsp+0xE0], xmm15
00007efc33fcead2  sub rsp, 0x30
00007efc33fcead6  movaps [rsp], xmm1
00007efc33fceada  movaps [rsp+0x10], xmm14
00007efc33fceae0  movaps [rsp+0x20], xmm15
00007efc33fceae6  lea rdi, [rsp]
00007efc33fceaea  mov esi, 0x00
00007efc33fceaef  mov rax, 0x5D9448894530
00007efc33fceaf9  call rax
00007efc33fceafb  movaps xmm1, [rsp]
00007efc33fceaff  add rsp, 0x30
00007efc33fceb03  vmovaps xmm0, [rsp]
00007efc33fceb08  vmovaps xmm2, [rsp+0x10]
00007efc33fceb0e  vmovaps xmm3, [rsp+0x20]
00007efc33fceb14  vmovaps xmm4, [rsp+0x30]
00007efc33fceb1a  vmovaps xmm5, [rsp+0x40]
00007efc33fceb20  vmovaps xmm6, [rsp+0x50]
00007efc33fceb26  vmovaps xmm7, [rsp+0x60]
00007efc33fceb2c  vmovaps xmm8, [rsp+0x70]
00007efc33fceb32  vmovaps xmm9, [rsp+0x80]
00007efc33fceb3b  vmovaps xmm10, [rsp+0x90]
00007efc33fceb44  vmovaps xmm11, [rsp+0xA0]
00007efc33fceb4d  vmovaps xmm12, [rsp+0xB0]
00007efc33fceb56  vmovaps xmm13, [rsp+0xC0]
00007efc33fceb5f  vmovaps xmm14, [rsp+0xD0]
00007efc33fceb68  vmovaps xmm15, [rsp+0xE0]
00007efc33fceb71  add rsp, 0xF0
00007efc33fceb78  pop r11
00007efc33fceb7a  pop r10
00007efc33fceb7c  pop r9
00007efc33fceb7e  pop r8
00007efc33fceb80  pop rsi
00007efc33fceb81  pop rdi
00007efc33fceb82  pop rdx
00007efc33fceb83  pop rcx
00007efc33fceb84  pop rax
00007efc33fceb85  add rsp, 0x08
00007efc33fceb89  jmp 0x00007EFC33FCE848
00007efc33fceb8e  call 0x00007EFC33DFF540
00007efc33fceb93  jmp 0x00007EFC33FCE85B
00007efc33fceb98  int3
00007efc33fceb99  nop [rax], eax
00007efc33fceba0  movaps xmm1, [r15+0x180]
00007efc33fceba8  vpmovqd xmm15, xmm1
00007efc33fcebae  pxor xmm14, xmm14
00007efc33fcebb3  punpcklqdq xmm15, xmm14
00007efc33fcebb8  movaps [r15+0x210], xmm15
00007efc33fcebc0  movq xmm15, qword ptr [r15+0x120]
00007efc33fcebc9  movq xmm14, qword ptr [r15+0x130]
00007efc33fcebd2  psubd xmm15, xmm14
00007efc33fcebd7  movq xmm15, xmm15
00007efc33fcebdc  movaps xmm13, [r15+0x170]
00007efc33fcebe4  paddq xmm1, xmm13
00007efc33fcebe9  movaps [r15+0x180], xmm1
00007efc33fcebf1  movq xmm1, qword ptr [r15+0x150]
00007efc33fcebfa  paddd xmm14, xmm1
00007efc33fcebff  movq xmm14, xmm14
00007efc33fcec04  movq xmm14, xmm14
00007efc33fcec09  movaps [r15+0x130], xmm14
00007efc33fcec11  pmovzxdq xmm15, xmm15
00007efc33fcec17  psllq xmm15, 0x00
00007efc33fcec1d  movq xmm1, qword ptr [r15+0x210]
00007efc33fcec26  movq xmm14, qword ptr [r15+0x110]
00007efc33fcec2f  paddd xmm1, xmm14
00007efc33fcec34  movq xmm1, xmm1
00007efc33fcec38  vcvtuqq2pd xmm15, xmm15
00007efc33fcec3e  pmovzxdq xmm1, xmm1
00007efc33fcec43  psllq xmm1, 0x00
00007efc33fcec48  vcvtuqq2pd xmm1, xmm1
00007efc33fcec4e  movaps xmm14, [r15+0x140]
00007efc33fcec56  movaps xmm13, xmm15
00007efc33fcec5a  mulpd xmm13, xmm14
00007efc33fcec5f  vcmppd xmm12, xmm13, xmm13, 0x03
00007efc33fcec65  ptest xmm12, xmm12
00007efc33fcec6b  jnz 0x00007EFC33FCED4E
00007efc33fcec71  movaps [r15+0x220], xmm13
00007efc33fcec79  mov rax, [r15+0x48]
00007efc33fcec7d  mov r14, [r15+0x50]
00007efc33fcec81  lea r12, [r14+rax*1]
00007efc33fcec85  movups [r13+r12*1], xmm13
00007efc33fcec8b  movaps xmm15, [r15+0x160]
00007efc33fcec93  movaps xmm14, xmm1
00007efc33fcec97  mulpd xmm14, xmm15
00007efc33fcec9c  vcmppd xmm13, xmm14, xmm14, 0x03
00007efc33fceca2  ptest xmm13, xmm13
00007efc33fceca8  jnz 0x00007EFC33FCEE9C
00007efc33fcecae  movaps [r15+0x210], xmm14
00007efc33fcecb6  mov r14, [r15+0x40]
00007efc33fcecba  lea r12, [r14+rax*1]
00007efc33fcecbe  movups [r13+r12*1], xmm14
00007efc33fcecc4  lea r14, [rax+0x10]
00007efc33fcecc8  mov [r15+0x48], r14
00007efc33fceccc  xor eax, eax
00007efc33fcecce  mov r12d, 0x200
00007efc33fcecd4  cmp r14, r12
00007efc33fcecd7  cmc
00007efc33fcecd8  lahf
00007efc33fcecd9  seto al
00007efc33fcecdc  mov [r15+0x108], eax
00007efc33fcece3  mov eax, [r15+0x108]
00007efc33fcecea  sahf
00007efc33fceceb  jnz 0x00007EFC33FCED1D
00007efc33fceced  cmp dword ptr [r15+0x318], 0x00
00007efc33fcecf5  jz 0x00007EFC33FCEFF0
00007efc33fcecfb  nop [rax+rax*1], ax
00007efc33fced04  nop [rax+rax*1], eax
00007efc33fced0c  mov eax, 0x4101EC
00007efc33fced11  mov [r15+0x100], rax
00007efc33fced18  jmp 0x00007EFC33DFE110
00007efc33fced1d  cmp dword ptr [r15+0x318], 0x00
00007efc33fced25  jz 0x00007EFC33FCEBA0
00007efc33fced2b  nop [rax+rax*1], ax
00007efc33fced34  nop [rax+rax*1], eax
00007efc33fced3c  mov eax, 0x4101AC
00007efc33fced41  mov [r15+0x100], rax
00007efc33fced48  jmp 0x00007EFC33DFE110
00007efc33fced4d  int3
00007efc33fced4e  sub rsp, 0x08
00007efc33fced52  push rax
00007efc33fced53  push rcx
00007efc33fced54  push rdx
00007efc33fced55  push rdi
00007efc33fced56  push rsi
00007efc33fced57  push r8
00007efc33fced59  push r9
00007efc33fced5b  push r10
00007efc33fced5d  push r11
00007efc33fced5f  sub rsp, 0xF0
00007efc33fced66  vmovaps [rsp], xmm0
00007efc33fced6b  vmovaps [rsp+0x10], xmm1
00007efc33fced71  vmovaps [rsp+0x20], xmm2
00007efc33fced77  vmovaps [rsp+0x30], xmm3
00007efc33fced7d  vmovaps [rsp+0x40], xmm4
00007efc33fced83  vmovaps [rsp+0x50], xmm5
00007efc33fced89  vmovaps [rsp+0x60], xmm6
00007efc33fced8f  vmovaps [rsp+0x70], xmm7
00007efc33fced95  vmovaps [rsp+0x80], xmm8
00007efc33fced9e  vmovaps [rsp+0x90], xmm9
00007efc33fceda7  vmovaps [rsp+0xA0], xmm10
00007efc33fcedb0  vmovaps [rsp+0xB0], xmm11
00007efc33fcedb9  vmovaps [rsp+0xC0], xmm12
00007efc33fcedc2  vmovaps [rsp+0xD0], xmm14
00007efc33fcedcb  vmovaps [rsp+0xE0], xmm15
00007efc33fcedd4  sub rsp, 0x30
00007efc33fcedd8  movaps [rsp], xmm13
00007efc33fceddd  movaps [rsp+0x10], xmm15
00007efc33fcede3  movaps [rsp+0x20], xmm14
00007efc33fcede9  lea rdi, [rsp]
00007efc33fceded  mov esi, 0x00
00007efc33fcedf2  mov rax, 0x5D9448894530
00007efc33fcedfc  call rax
00007efc33fcedfe  movaps xmm13, [rsp]
00007efc33fcee03  add rsp, 0x30
00007efc33fcee07  vmovaps xmm0, [rsp]
00007efc33fcee0c  vmovaps xmm1, [rsp+0x10]
00007efc33fcee12  vmovaps xmm2, [rsp+0x20]
00007efc33fcee18  vmovaps xmm3, [rsp+0x30]
00007efc33fcee1e  vmovaps xmm4, [rsp+0x40]
00007efc33fcee24  vmovaps xmm5, [rsp+0x50]
00007efc33fcee2a  vmovaps xmm6, [rsp+0x60]
00007efc33fcee30  vmovaps xmm7, [rsp+0x70]
00007efc33fcee36  vmovaps xmm8, [rsp+0x80]
00007efc33fcee3f  vmovaps xmm9, [rsp+0x90]
00007efc33fcee48  vmovaps xmm10, [rsp+0xA0]
00007efc33fcee51  vmovaps xmm11, [rsp+0xB0]
00007efc33fcee5a  vmovaps xmm12, [rsp+0xC0]
00007efc33fcee63  vmovaps xmm14, [rsp+0xD0]
00007efc33fcee6c  vmovaps xmm15, [rsp+0xE0]
00007efc33fcee75  add rsp, 0xF0
00007efc33fcee7c  pop r11
00007efc33fcee7e  pop r10
00007efc33fcee80  pop r9
00007efc33fcee82  pop r8
00007efc33fcee84  pop rsi
00007efc33fcee85  pop rdi
00007efc33fcee86  pop rdx
00007efc33fcee87  pop rcx
00007efc33fcee88  pop rax
00007efc33fcee89  add rsp, 0x08
00007efc33fcee8d  jmp 0x00007EFC33FCEC71
00007efc33fcee92  call 0x00007EFC33EC2240
00007efc33fcee97  jmp 0x00007EFC33FCEC8B
00007efc33fcee9c  sub rsp, 0x08
00007efc33fceea0  push rax
00007efc33fceea1  push rcx
00007efc33fceea2  push rdx
00007efc33fceea3  push rdi
00007efc33fceea4  push rsi
00007efc33fceea5  push r8
00007efc33fceea7  push r9
00007efc33fceea9  push r10
00007efc33fceeab  push r11
00007efc33fceead  sub rsp, 0xF0
00007efc33fceeb4  vmovaps [rsp], xmm0
00007efc33fceeb9  vmovaps [rsp+0x10], xmm1
00007efc33fceebf  vmovaps [rsp+0x20], xmm2
00007efc33fceec5  vmovaps [rsp+0x30], xmm3
00007efc33fceecb  vmovaps [rsp+0x40], xmm4
00007efc33fceed1  vmovaps [rsp+0x50], xmm5
00007efc33fceed7  vmovaps [rsp+0x60], xmm6
00007efc33fceedd  vmovaps [rsp+0x70], xmm7
00007efc33fceee3  vmovaps [rsp+0x80], xmm8
00007efc33fceeec  vmovaps [rsp+0x90], xmm9
00007efc33fceef5  vmovaps [rsp+0xA0], xmm10
00007efc33fceefe  vmovaps [rsp+0xB0], xmm11
00007efc33fcef07  vmovaps [rsp+0xC0], xmm12
00007efc33fcef10  vmovaps [rsp+0xD0], xmm13
00007efc33fcef19  vmovaps [rsp+0xE0], xmm15
00007efc33fcef22  sub rsp, 0x30
00007efc33fcef26  movaps [rsp], xmm14
00007efc33fcef2b  movaps [rsp+0x10], xmm1
00007efc33fcef30  movaps [rsp+0x20], xmm15
00007efc33fcef36  lea rdi, [rsp]
00007efc33fcef3a  mov esi, 0x00
00007efc33fcef3f  mov rax, 0x5D9448894530
00007efc33fcef49  call rax
00007efc33fcef4b  movaps xmm14, [rsp]
00007efc33fcef50  add rsp, 0x30
00007efc33fcef54  vmovaps xmm0, [rsp]
00007efc33fcef59  vmovaps xmm1, [rsp+0x10]
00007efc33fcef5f  vmovaps xmm2, [rsp+0x20]
00007efc33fcef65  vmovaps xmm3, [rsp+0x30]
00007efc33fcef6b  vmovaps xmm4, [rsp+0x40]
00007efc33fcef71  vmovaps xmm5, [rsp+0x50]
00007efc33fcef77  vmovaps xmm6, [rsp+0x60]
00007efc33fcef7d  vmovaps xmm7, [rsp+0x70]
00007efc33fcef83  vmovaps xmm8, [rsp+0x80]
00007efc33fcef8c  vmovaps xmm9, [rsp+0x90]
00007efc33fcef95  vmovaps xmm10, [rsp+0xA0]
00007efc33fcef9e  vmovaps xmm11, [rsp+0xB0]
00007efc33fcefa7  vmovaps xmm12, [rsp+0xC0]
00007efc33fcefb0  vmovaps xmm13, [rsp+0xD0]
00007efc33fcefb9  vmovaps xmm15, [rsp+0xE0]
00007efc33fcefc2  add rsp, 0xF0
00007efc33fcefc9  pop r11
00007efc33fcefcb  pop r10
00007efc33fcefcd  pop r9
00007efc33fcefcf  pop r8
00007efc33fcefd1  pop rsi
00007efc33fcefd2  pop rdi
00007efc33fcefd3  pop rdx
00007efc33fcefd4  pop rcx
00007efc33fcefd5  pop rax
00007efc33fcefd6  add rsp, 0x08
00007efc33fcefda  jmp 0x00007EFC33FCECAE
00007efc33fcefdf  call 0x00007EFC33EC34C0
00007efc33fcefe4  jmp 0x00007EFC33FCECC4
00007efc33fcefe9  int3
00007efc33fcefea  nop [rax+rax*1], ax
00007efc33fceff0  mov rax, [r15+0xF8]
00007efc33fceff7  lea r14, [rax-0x150]
00007efc33fceffe  mov [r15+0xF8], r14
00007efc33fcf005  mov rax, [r15+0x50]
00007efc33fcf009  lea r12, [rax+0x80]
00007efc33fcf010  movups xmm1, [r13+r12*1]
00007efc33fcf016  lea r12, [rax+0x90]
00007efc33fcf01d  movups xmm15, [r13+r12*1]
00007efc33fcf023  mov qword ptr [r15+0x48], 0x00
00007efc33fcf02b  lea r12, [rax+0x40]
00007efc33fcf02f  movups xmm14, [r13+r12*1]
00007efc33fcf035  lea r12, [rax+0x50]
00007efc33fcf039  movups xmm13, [r13+r12*1]
00007efc33fcf03f  lea r12, [r14+0x120]
00007efc33fcf046  movq xmm12, qword ptr [r15+0x1C0]
00007efc33fcf04f  movq xmm11, qword ptr [r15+0x1B0]
00007efc33fcf058  movq r11, xmm12
00007efc33fcf05d  movq r10, xmm11
00007efc33fcf062  mov [r13+r12*1], r11
00007efc33fcf067  lea r12, [r14+0x128]
00007efc33fcf06e  mov [r13+r12*1], r10
00007efc33fcf073  vxorps xmm12, xmm12, xmm12
00007efc33fcf078  vpbroadcastq xmm12, xmm12
00007efc33fcf07d  lea r12, [r14+0x100]
00007efc33fcf084  movq xmm11, qword ptr [r15+0x200]
00007efc33fcf08d  movq xmm10, qword ptr [r15+0x1F0]
00007efc33fcf096  movq r11, xmm11
00007efc33fcf09b  movq r10, xmm10
00007efc33fcf0a0  mov [r13+r12*1], r11
00007efc33fcf0a5  lea r12, [r14+0x108]
00007efc33fcf0ac  mov [r13+r12*1], r10
00007efc33fcf0b1  lea r12, [r14+0xE0]
00007efc33fcf0b8  movups [r13+r12*1], xmm15
00007efc33fcf0be  lea r12, [r14+0xF0]
00007efc33fcf0c5  movups [r13+r12*1], xmm1
00007efc33fcf0cb  lea r12, [rax+0xC0]
00007efc33fcf0d2  movups xmm1, [r13+r12*1]
00007efc33fcf0d8  lea r12, [rax+0xD0]
00007efc33fcf0df  movups xmm15, [r13+r12*1]
00007efc33fcf0e5  lea r12, [r14+0x110]
00007efc33fcf0ec  movq xmm11, qword ptr [r15+0x1E0]
00007efc33fcf0f5  movq xmm10, qword ptr [r15+0x1D0]
00007efc33fcf0fe  movq r11, xmm11
00007efc33fcf103  movq r10, xmm10
00007efc33fcf108  mov [r13+r12*1], r11
00007efc33fcf10d  lea r12, [r14+0x118]
00007efc33fcf114  mov [r13+r12*1], r10
00007efc33fcf119  movups xmm11, [r13+rax*1]
00007efc33fcf11f  lea r12, [rax+0x10]
00007efc33fcf123  movups xmm10, [r13+r12*1]
00007efc33fcf129  lea r12, [r14+0x130]
00007efc33fcf130  movq xmm9, qword ptr [r15+0x1A0]
00007efc33fcf139  movq xmm8, qword ptr [r15+0x190]
00007efc33fcf142  movq r11, xmm9
00007efc33fcf147  movq r10, xmm8
00007efc33fcf14c  mov [r13+r12*1], r11
00007efc33fcf151  lea r12, [r14+0x138]
00007efc33fcf158  mov [r13+r12*1], r10
00007efc33fcf15d  lea r12, [rax+0x140]
00007efc33fcf164  movups xmm9, [r13+r12*1]
00007efc33fcf16a  lea r12, [rax+0x150]
00007efc33fcf171  movups xmm8, [r13+r12*1]
00007efc33fcf177  lea r12, [r14+0xC0]
00007efc33fcf17e  movups [r13+r12*1], xmm15
00007efc33fcf184  lea r12, [r14+0xD0]
00007efc33fcf18b  movups [r13+r12*1], xmm1
00007efc33fcf191  lea r12, [rax+0x100]
00007efc33fcf198  movups xmm1, [r13+r12*1]
00007efc33fcf19e  lea r12, [rax+0x110]
00007efc33fcf1a5  movups xmm15, [r13+r12*1]
00007efc33fcf1ab  lea r12, [r14+0x140]
00007efc33fcf1b2  mov r11, [r15+0xE8]
00007efc33fcf1b9  mov [r13+r12*1], r11
00007efc33fcf1be  lea r12, [rax+0x180]
00007efc33fcf1c5  movups xmm7, [r13+r12*1]
00007efc33fcf1cb  lea r12, [rax+0x190]
00007efc33fcf1d2  movups xmm6, [r13+r12*1]
00007efc33fcf1d8  lea r12, [rax+0x1C0]
00007efc33fcf1df  movups xmm5, [r13+r12*1]
00007efc33fcf1e5  lea r12, [rax+0x1D0]
00007efc33fcf1ec  movups xmm4, [r13+r12*1]
00007efc33fcf1f2  lea r12, [r14+0x20]
00007efc33fcf1f6  movups [r13+r12*1], xmm1
00007efc33fcf1fc  lea r12, [r14+0x30]
00007efc33fcf200  movups [r13+r12*1], xmm13
00007efc33fcf206  lea r12, [rax+0x60]
00007efc33fcf20a  movups xmm1, [r13+r12*1]
00007efc33fcf210  lea r12, [rax+0x70]
00007efc33fcf214  movups xmm13, [r13+r12*1]
00007efc33fcf21a  lea r12, [rax+0x20]
00007efc33fcf21e  movups xmm3, [r13+r12*1]
00007efc33fcf224  lea r12, [rax+0x30]
00007efc33fcf228  movups xmm2, [r13+r12*1]
00007efc33fcf22e  movaps [r15+0x1F0], xmm2
00007efc33fcf236  lea r12, [r14+0x60]
00007efc33fcf23a  movups [r13+r12*1], xmm11
00007efc33fcf240  lea r12, [r14+0x70]
00007efc33fcf244  movups [r13+r12*1], xmm5
00007efc33fcf24a  lea r12, [rax+0xE0]
00007efc33fcf251  movups xmm11, [r13+r12*1]
00007efc33fcf257  lea r12, [rax+0xF0]
00007efc33fcf25e  movups xmm5, [r13+r12*1]
00007efc33fcf264  lea r12, [r14+0xA0]
00007efc33fcf26b  movups [r13+r12*1], xmm13
00007efc33fcf271  lea r12, [r14+0xB0]
00007efc33fcf278  movups [r13+r12*1], xmm1
00007efc33fcf27e  lea r12, [rax+0xA0]
00007efc33fcf285  movups xmm1, [r13+r12*1]
00007efc33fcf28b  lea r12, [rax+0xB0]
00007efc33fcf292  movups xmm13, [r13+r12*1]
00007efc33fcf298  lea r12, [rax+0x120]
00007efc33fcf29f  vmovaps [rsp+0x10], xmm1
00007efc33fcf2a5  movups xmm1, [r13+r12*1]
00007efc33fcf2ab  lea r12, [rax+0x130]
00007efc33fcf2b2  vmovaps [rsp+0x20], xmm1
00007efc33fcf2b8  movups xmm1, [r13+r12*1]
00007efc33fcf2be  lea r12, [rax+0x160]
00007efc33fcf2c5  vmovaps [rsp+0x30], xmm1
00007efc33fcf2cb  movups xmm1, [r13+r12*1]
00007efc33fcf2d1  lea r12, [rax+0x170]
00007efc33fcf2d8  vmovaps [rsp+0x40], xmm1
00007efc33fcf2de  movups xmm1, [r13+r12*1]
00007efc33fcf2e4  movaps [r15+0x2B0], xmm1
00007efc33fcf2ec  lea r12, [r14+0x80]
00007efc33fcf2f3  movups [r13+r12*1], xmm13
00007efc33fcf2f9  lea r12, [r14+0x90]
00007efc33fcf300  vmovaps xmm13, [rsp+0x10]
00007efc33fcf306  movups [r13+r12*1], xmm13
00007efc33fcf30c  lea r12, [rax+0x1A0]
00007efc33fcf313  movups xmm13, [r13+r12*1]
00007efc33fcf319  lea r12, [rax+0x1B0]
00007efc33fcf320  vmovaps [rsp+0x10], xmm1
00007efc33fcf326  movups xmm1, [r13+r12*1]
00007efc33fcf32c  movaps [r15+0x290], xmm13
00007efc33fcf334  movaps [r15+0x1E0], xmm1
00007efc33fcf33c  lea r12, [rax+0x1E0]
00007efc33fcf343  vmovaps [rsp+0x50], xmm1
00007efc33fcf349  movups xmm1, [r13+r12*1]
00007efc33fcf34f  lea r12, [rax+0x1F0]
00007efc33fcf356  vmovaps [rsp+0x60], xmm1
00007efc33fcf35c  movups xmm1, [r13+r12*1]
00007efc33fcf362  mov qword ptr [r15+0x50], 0x430920
00007efc33fcf36a  lea rax, [r14+0x40]
00007efc33fcf36e  vmovaps [rsp+0x70], xmm1
00007efc33fcf374  vmovaps xmm1, [rsp+0x40]
00007efc33fcf37a  movups [r13+rax*1], xmm1
00007efc33fcf380  lea rax, [r14+0x50]
00007efc33fcf384  movups [r13+rax*1], xmm10
00007efc33fcf38a  vmovaps xmm1, [rsp+0x70]
00007efc33fcf390  movups [r13+r14*1], xmm1
00007efc33fcf396  lea rax, [r14+0x10]
00007efc33fcf39a  vmovaps xmm1, [rsp+0x60]
00007efc33fcf3a0  movups [r13+rax*1], xmm1
00007efc33fcf3a6  mov rax, [r15+0x40]
00007efc33fcf3aa  vmovaps [rsp+0x40], xmm3
00007efc33fcf3b0  vmovaps xmm1, [rsp+0x40]
00007efc33fcf3b6  por xmm3, xmm1
00007efc33fcf3ba  vmovaps [rsp+0x40], xmm6
00007efc33fcf3c0  vmovaps xmm10, [rsp+0x40]
00007efc33fcf3c6  por xmm6, xmm10
00007efc33fcf3cb  lea r12, [rax+0x30]
00007efc33fcf3cf  mov r11, [r13+r12*1]
00007efc33fcf3d4  lea r12, [rax+0x38]
00007efc33fcf3d8  mov r10, [r13+r12*1]
00007efc33fcf3dd  movq xmm10, r11
00007efc33fcf3e2  vmovaps [rsp+0x40], xmm1
00007efc33fcf3e8  movq xmm1, r10
00007efc33fcf3ed  movq xmm10, xmm10
00007efc33fcf3f2  vmovaps [rsp+0x60], xmm10
00007efc33fcf3f8  movq xmm10, xmm10
00007efc33fcf3fd  movaps [r15+0x130], xmm10
00007efc33fcf405  movq xmm1, xmm1
00007efc33fcf409  vmovaps [rsp+0x70], xmm1
00007efc33fcf40f  movq xmm1, xmm1
00007efc33fcf413  movaps [r15+0x280], xmm1
00007efc33fcf41b  vmovaps [rsp+0x80], xmm9
00007efc33fcf424  vmovaps xmm1, [rsp+0x80]
00007efc33fcf42d  por xmm9, xmm1
00007efc33fcf432  lea r12, [rax+0x20]
00007efc33fcf436  mov r11, [r13+r12*1]
00007efc33fcf43b  lea r12, [rax+0x28]
00007efc33fcf43f  mov r10, [r13+r12*1]
00007efc33fcf444  movq xmm1, r11
00007efc33fcf449  movq xmm10, r10
00007efc33fcf44e  movq xmm1, xmm1
00007efc33fcf452  vmovaps [rsp+0x80], xmm1
00007efc33fcf45b  movq xmm1, xmm1
00007efc33fcf45f  movaps [r15+0x150], xmm1
00007efc33fcf467  movq xmm10, xmm10
00007efc33fcf46c  vmovaps [rsp+0x90], xmm10
00007efc33fcf475  movq xmm10, xmm10
00007efc33fcf47a  movaps [r15+0x140], xmm10
00007efc33fcf482  lea r12, [rax+0x10]
00007efc33fcf486  mov r11, [r13+r12*1]
00007efc33fcf48b  lea r12, [rax+0x18]
00007efc33fcf48f  mov r10, [r13+r12*1]
00007efc33fcf494  movq xmm1, r11
00007efc33fcf499  movq xmm10, r10
00007efc33fcf49e  movq xmm1, xmm1
00007efc33fcf4a2  vmovaps [rsp+0xA0], xmm1
00007efc33fcf4ab  movq xmm1, xmm1
00007efc33fcf4af  movaps [r15+0x170], xmm1
00007efc33fcf4b7  movq xmm10, xmm10
00007efc33fcf4bc  vmovaps [rsp+0xB0], xmm10
00007efc33fcf4c5  movq xmm10, xmm10
00007efc33fcf4ca  movaps [r15+0x160], xmm10
00007efc33fcf4d2  mov r12, [r13+rax*1]
00007efc33fcf4d7  vmovq xmm1, r12
00007efc33fcf4dc  vpbroadcastq xmm1, xmm1
00007efc33fcf4e1  lea r12, [rax+0x08]
00007efc33fcf4e5  mov rax, [r13+r12*1]
00007efc33fcf4ea  movq xmm10, rax
00007efc33fcf4ef  movaps [r15+0x230], xmm10
00007efc33fcf4f7  lea rax, [r14+0x50]
00007efc33fcf4fb  movups xmm10, [r13+rax*1]
00007efc33fcf501  lea rax, [r14+0x60]
00007efc33fcf505  vmovaps [rsp+0xC0], xmm1
00007efc33fcf50e  movups xmm1, [r13+rax*1]
00007efc33fcf514  lea rax, [r14+0x30]
00007efc33fcf518  vmovaps [rsp+0xD0], xmm1
00007efc33fcf521  movups xmm1, [r13+rax*1]
00007efc33fcf527  mov qword ptr [r15+0x60], 0x430920
00007efc33fcf52f  mov qword ptr [r15+0x58], 0x40
00007efc33fcf537  vmovaps [rsp+0xE0], xmm1
00007efc33fcf540  vmovaps [rsp+0xF0], xmm15
00007efc33fcf549  vmovaps xmm15, [rsp+0xC0]
00007efc33fcf552  vmovaps [rsp+0xC0], xmm14
00007efc33fcf55b  vmovaps xmm14, [rsp+0x40]
00007efc33fcf561  vmovaps [rsp+0x40], xmm13
00007efc33fcf567  movaps xmm1, xmm15
00007efc33fcf56b  mulpd xmm1, xmm14
00007efc33fcf570  vcmppd xmm13, xmm1, xmm1, 0x03
00007efc33fcf575  ptest xmm13, xmm13
00007efc33fcf57b  jnz 0x00007EFC33FD0682
00007efc33fcf581  movq xmm14, qword ptr [r15+0x230]
00007efc33fcf58a  vmovaps [rsp+0x100], xmm14
00007efc33fcf593  vpermilpd xmm14, xmm14, 0x00
00007efc33fcf599  vmovaps [rsp+0x110], xmm1
00007efc33fcf5a2  vmovaps xmm1, [rsp+0xE0]
00007efc33fcf5ab  vmovaps [rsp+0xE0], xmm15
00007efc33fcf5b4  movaps xmm13, xmm1
00007efc33fcf5b8  mulpd xmm13, xmm14
00007efc33fcf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
00007efc33fcf5c3  ptest xmm15, xmm15
00007efc33fcf5c9  jnz 0x00007EFC33FD07C4
00007efc33fcf5cf  vxorps xmm1, xmm1, xmm1
00007efc33fcf5d3  vpbroadcastq xmm1, xmm1
00007efc33fcf5d8  vmovaps xmm14, [rsp+0xE0]
00007efc33fcf5e1  vmovaps [rsp+0xE0], xmm1
00007efc33fcf5ea  vmovaps xmm1, [rsp+0xD0]
00007efc33fcf5f3  vmovaps [rsp+0xD0], xmm13
00007efc33fcf5fc  movaps xmm15, xmm14
00007efc33fcf600  mulpd xmm15, xmm1
00007efc33fcf605  vcmppd xmm13, xmm15, xmm15, 0x03
00007efc33fcf60b  ptest xmm13, xmm13
00007efc33fcf611  jnz 0x00007EFC33FD0907
00007efc33fcf617  movaps xmm1, xmm14
00007efc33fcf61b  mulpd xmm1, xmm10
00007efc33fcf620  vcmppd xmm13, xmm1, xmm1, 0x03
00007efc33fcf625  ptest xmm13, xmm13
00007efc33fcf62b  jnz 0x00007EFC33FD0A4A
00007efc33fcf631  movaps xmm13, xmm14
00007efc33fcf635  mulpd xmm13, xmm2
00007efc33fcf63a  vcmppd xmm10, xmm13, xmm13, 0x03
00007efc33fcf640  ptest xmm10, xmm10
00007efc33fcf646  jnz 0x00007EFC33FD0B8C
00007efc33fcf64c  vmovaps [rsp+0x120], xmm7
00007efc33fcf655  vmovaps xmm14, [rsp+0x120]
00007efc33fcf65e  por xmm7, xmm14
00007efc33fcf663  vmovaps xmm14, [rsp+0xC0]
00007efc33fcf66c  vmovaps xmm10, [rsp+0xC0]
00007efc33fcf675  por xmm14, xmm10
00007efc33fcf67a  vmovaps xmm2, [rsp+0x100]
00007efc33fcf683  vpermilpd xmm2, xmm2, 0x00
00007efc33fcf689  vmovaps [rsp+0xC0], xmm1
00007efc33fcf692  vmovaps [rsp+0x120], xmm15
00007efc33fcf69b  movaps xmm1, xmm10
00007efc33fcf69f  mulpd xmm1, xmm2
00007efc33fcf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
00007efc33fcf6a8  ptest xmm15, xmm15
00007efc33fcf6ae  jnz 0x00007EFC33FD0CCF
00007efc33fcf6b4  xor eax, eax
00007efc33fcf6b6  mov r12d, 0x40
00007efc33fcf6bc  mov r11d, 0x200
00007efc33fcf6c2  cmp r12, r11
00007efc33fcf6c5  cmc
00007efc33fcf6c6  lahf
00007efc33fcf6c7  seto al
00007efc33fcf6ca  mov [r15+0x108], eax
00007efc33fcf6d1  vmovaps xmm10, [rsp+0x110]
00007efc33fcf6da  vmovaps xmm2, [rsp+0xE0]
00007efc33fcf6e3  vmovaps [rsp+0xE0], xmm1
00007efc33fcf6ec  movaps xmm15, xmm10
00007efc33fcf6f0  addpd xmm15, xmm2
00007efc33fcf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
00007efc33fcf6fb  ptest xmm1, xmm1
00007efc33fcf700  jnz 0x00007EFC33FD0E10
00007efc33fcf706  vmovaps xmm10, [rsp+0x120]
00007efc33fcf70f  vmovaps [rsp+0x110], xmm15
00007efc33fcf718  movaps xmm1, xmm10
00007efc33fcf71c  addpd xmm1, xmm12
00007efc33fcf721  vcmppd xmm15, xmm1, xmm1, 0x03
00007efc33fcf726  ptest xmm15, xmm15
00007efc33fcf72c  jnz 0x00007EFC33FD0F53
00007efc33fcf732  vmovaps xmm10, [rsp+0xC0]
00007efc33fcf73b  vmovaps [rsp+0xC0], xmm1
00007efc33fcf744  movaps xmm15, xmm10
00007efc33fcf748  addpd xmm15, xmm12
00007efc33fcf74d  vcmppd xmm1, xmm15, xmm15, 0x03
00007efc33fcf753  ptest xmm1, xmm1
00007efc33fcf758  jnz 0x00007EFC33FD1095
00007efc33fcf75e  vmovaps xmm1, [rsp+0x30]
00007efc33fcf764  vmovaps xmm12, [rsp+0x30]
00007efc33fcf76a  por xmm1, xmm12
00007efc33fcf76f  vmovaps xmm12, [rsp+0x20]
00007efc33fcf775  vmovaps xmm10, [rsp+0x20]
00007efc33fcf77b  por xmm12, xmm10
00007efc33fcf780  vmovaps [rsp+0x20], xmm5
00007efc33fcf786  vmovaps xmm10, [rsp+0x20]
00007efc33fcf78c  por xmm5, xmm10
00007efc33fcf791  vmovaps [rsp+0x20], xmm11
00007efc33fcf797  vmovaps xmm10, [rsp+0x20]
00007efc33fcf79d  por xmm11, xmm10
00007efc33fcf7a2  vmovaps [rsp+0x20], xmm4
00007efc33fcf7a8  vmovaps xmm10, [rsp+0x20]
00007efc33fcf7ae  por xmm4, xmm10
00007efc33fcf7b3  vmovaps [rsp+0x20], xmm8
00007efc33fcf7b9  vmovaps xmm10, [rsp+0x20]
00007efc33fcf7bf  por xmm8, xmm10
00007efc33fcf7c4  vmovaps xmm10, [rsp+0xF0]
00007efc33fcf7cd  vmovaps [rsp+0x20], xmm1
00007efc33fcf7d3  vmovaps xmm1, [rsp+0xF0]
00007efc33fcf7dc  por xmm10, xmm1
00007efc33fcf7e1  lea rax, [r14+0xA0]
00007efc33fcf7e8  movups xmm1, [r13+rax*1]
00007efc33fcf7ee  lea rax, [r14+0xB0]
00007efc33fcf7f5  vmovaps [rsp+0x30], xmm1
00007efc33fcf7fb  movups xmm1, [r13+rax*1]
00007efc33fcf801  vmovaps [rsp+0xF0], xmm1
00007efc33fcf80a  vmovaps [rsp+0x120], xmm15
00007efc33fcf813  movaps xmm1, xmm13
00007efc33fcf817  addpd xmm1, xmm2
00007efc33fcf81b  vcmppd xmm15, xmm1, xmm1, 0x03
00007efc33fcf820  ptest xmm15, xmm15
00007efc33fcf826  jnz 0x00007EFC33FD11ED
00007efc33fcf82c  lea rax, [r14+0xF0]
00007efc33fcf833  movups xmm15, [r13+rax*1]
00007efc33fcf839  vmovaps xmm2, [rsp+0xC0]
00007efc33fcf842  vmovaps [rsp+0xC0], xmm1
00007efc33fcf84b  vmovaps xmm1, [rsp+0xE0]
00007efc33fcf854  vmovaps [rsp+0xE0], xmm15
00007efc33fcf85d  movaps xmm13, xmm2
00007efc33fcf861  addpd xmm13, xmm1
00007efc33fcf866  vcmppd xmm15, xmm13, xmm13, 0x03
00007efc33fcf86c  ptest xmm15, xmm15
00007efc33fcf872  jnz 0x00007EFC33FD1338
00007efc33fcf878  vmovaps xmm15, [rsp+0x120]
00007efc33fcf881  vmovaps xmm2, [rsp+0xD0]
00007efc33fcf88a  vmovaps [rsp+0xD0], xmm14
00007efc33fcf893  movaps xmm1, xmm15
00007efc33fcf897  addpd xmm1, xmm2
00007efc33fcf89b  vcmppd xmm14, xmm1, xmm1, 0x03
00007efc33fcf8a0  ptest xmm14, xmm14
00007efc33fcf8a6  jnz 0x00007EFC33FD147A
00007efc33fcf8ac  vmovaps xmm15, [rsp+0x100]
00007efc33fcf8b5  vpermilpd xmm15, xmm15, 0x00
00007efc33fcf8bb  vmovaps xmm2, [rsp+0xF0]
00007efc33fcf8c4  vmovaps [rsp+0xF0], xmm1
00007efc33fcf8cd  movaps xmm14, xmm2
00007efc33fcf8d1  mulpd xmm14, xmm15
00007efc33fcf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
00007efc33fcf8dc  ptest xmm1, xmm1
00007efc33fcf8e1  jnz 0x00007EFC33FD15BB
00007efc33fcf8e7  vmovaps xmm1, [rsp+0xA0]
00007efc33fcf8f0  vpermilpd xmm1, xmm1, 0x00
00007efc33fcf8f6  vmovaps xmm2, [rsp+0xE0]
00007efc33fcf8ff  vmovaps [rsp+0xE0], xmm14
00007efc33fcf908  movaps xmm15, xmm2
00007efc33fcf90c  mulpd xmm15, xmm1
00007efc33fcf911  vcmppd xmm14, xmm15, xmm15, 0x03
00007efc33fcf917  ptest xmm14, xmm14
00007efc33fcf91d  jnz 0x00007EFC33FD16FE
00007efc33fcf923  lea rax, [r14+0xE0]
00007efc33fcf92a  movups xmm1, [r13+rax*1]
00007efc33fcf930  vmovaps xmm14, [rsp+0x100]
00007efc33fcf939  vpermilpd xmm14, xmm14, 0x00
00007efc33fcf93f  vmovaps [rsp+0x100], xmm1
00007efc33fcf948  vmovaps xmm1, [rsp+0x30]
00007efc33fcf94e  vmovaps [rsp+0x30], xmm15
00007efc33fcf954  movaps xmm2, xmm1
00007efc33fcf957  mulpd xmm2, xmm14
00007efc33fcf95c  vcmppd xmm15, xmm2, xmm2, 0x03
00007efc33fcf961  ptest xmm15, xmm15
00007efc33fcf967  jnz 0x00007EFC33FD184A
00007efc33fcf96d  vmovaps [rsp+0x120], xmm10
00007efc33fcf976  vmovaps xmm1, [rsp+0x120]
00007efc33fcf97f  por xmm10, xmm1
00007efc33fcf984  movaps [r15+0x300], xmm10
00007efc33fcf98c  vmovaps [rsp+0x120], xmm8
00007efc33fcf995  vmovaps xmm1, [rsp+0x120]
00007efc33fcf99e  por xmm8, xmm1
00007efc33fcf9a3  movaps [r15+0x190], xmm8
00007efc33fcf9ab  vmovaps xmm1, [rsp+0xA0]
00007efc33fcf9b4  vpermilpd xmm1, xmm1, 0x00
00007efc33fcf9ba  vmovaps xmm14, [rsp+0x100]
00007efc33fcf9c3  vmovaps [rsp+0x100], xmm13
00007efc33fcf9cc  movaps xmm15, xmm14
00007efc33fcf9d0  mulpd xmm15, xmm1
00007efc33fcf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
00007efc33fcf9db  ptest xmm13, xmm13
00007efc33fcf9e1  jnz 0x00007EFC33FD198B
00007efc33fcf9e7  lea rax, [r14+0x90]
00007efc33fcf9ee  movups xmm1, [r13+rax*1]
00007efc33fcf9f4  vmovaps [rsp+0x120], xmm4
00007efc33fcf9fd  vmovaps xmm14, [rsp+0x120]
00007efc33fcfa06  por xmm4, xmm14
00007efc33fcfa0b  movaps [r15+0x1C0], xmm4
00007efc33fcfa13  vmovaps [rsp+0x120], xmm11
00007efc33fcfa1c  vmovaps xmm14, [rsp+0x120]
00007efc33fcfa25  por xmm11, xmm14
00007efc33fcfa2a  movaps [r15+0x200], xmm11
00007efc33fcfa32  vmovaps [rsp+0x120], xmm5
00007efc33fcfa3b  vmovaps xmm14, [rsp+0x120]
00007efc33fcfa44  por xmm5, xmm14
00007efc33fcfa49  movaps [r15+0x2D0], xmm5
00007efc33fcfa51  vmovaps [rsp+0x120], xmm12
00007efc33fcfa5a  vmovaps xmm14, [rsp+0x120]
00007efc33fcfa63  por xmm12, xmm14
00007efc33fcfa68  movaps [r15+0x2E0], xmm12
00007efc33fcfa70  vmovaps xmm13, [rsp+0x110]
00007efc33fcfa79  vmovaps [rsp+0x110], xmm1
00007efc33fcfa82  vmovaps xmm1, [rsp+0xE0]
00007efc33fcfa8b  vmovaps [rsp+0xE0], xmm15
00007efc33fcfa94  movaps xmm14, xmm13
00007efc33fcfa98  addpd xmm14, xmm1
00007efc33fcfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
00007efc33fcfaa3  ptest xmm15, xmm15
00007efc33fcfaa9  jnz 0x00007EFC33FD1AD8
00007efc33fcfaaf  vmovaps xmm1, [rsp+0xA0]
00007efc33fcfab8  vpermilpd xmm1, xmm1, 0x00
00007efc33fcfabe  vmovaps xmm13, [rsp+0x110]
00007efc33fcfac7  vmovaps [rsp+0x110], xmm14
00007efc33fcfad0  movaps xmm15, xmm13
00007efc33fcfad4  mulpd xmm15, xmm1
00007efc33fcfad9  vcmppd xmm14, xmm15, xmm15, 0x03
00007efc33fcfadf  ptest xmm14, xmm14
00007efc33fcfae5  jnz 0x00007EFC33FD1C1B
00007efc33fcfaeb  lea rax, [r14+0x80]
00007efc33fcfaf2  movups xmm1, [r13+rax*1]
00007efc33fcfaf8  vmovaps xmm13, [rsp+0xC0]
00007efc33fcfb01  vmovaps [rsp+0xC0], xmm1
00007efc33fcfb0a  movaps xmm14, xmm13
00007efc33fcfb0e  addpd xmm14, xmm2
00007efc33fcfb13  vcmppd xmm1, xmm14, xmm14, 0x03
00007efc33fcfb19  ptest xmm1, xmm1
00007efc33fcfb1e  jnz 0x00007EFC33FD1D68
00007efc33fcfb24  vmovaps xmm13, [rsp+0x100]
00007efc33fcfb2d  vmovaps xmm2, [rsp+0x30]
00007efc33fcfb33  vmovaps [rsp+0x30], xmm15
00007efc33fcfb39  movaps xmm1, xmm13
00007efc33fcfb3d  addpd xmm1, xmm2
00007efc33fcfb41  vcmppd xmm15, xmm1, xmm1, 0x03
00007efc33fcfb46  ptest xmm15, xmm15
00007efc33fcfb4c  jnz 0x00007EFC33FD1EAB
00007efc33fcfb52  vmovaps xmm15, [rsp+0x20]
00007efc33fcfb58  vmovaps xmm13, [rsp+0x20]
00007efc33fcfb5e  por xmm15, xmm13
00007efc33fcfb63  movaps [r15+0x2F0], xmm15
00007efc33fcfb6b  vmovaps xmm13, [rsp+0xA0]
00007efc33fcfb74  vpermilpd xmm13, xmm13, 0x00
00007efc33fcfb7a  vmovaps [rsp+0x20], xmm1
00007efc33fcfb80  vmovaps xmm1, [rsp+0xC0]
00007efc33fcfb89  vmovaps [rsp+0xA0], xmm15
00007efc33fcfb92  movaps xmm2, xmm1
00007efc33fcfb95  mulpd xmm2, xmm13
00007efc33fcfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
00007efc33fcfb9f  ptest xmm15, xmm15
00007efc33fcfba5  jnz 0x00007EFC33FD1FEC
00007efc33fcfbab  lea rax, [r14+0xD0]
00007efc33fcfbb2  movups xmm1, [r13+rax*1]
00007efc33fcfbb8  vmovaps xmm13, [rsp+0xF0]
00007efc33fcfbc1  vmovaps [rsp+0xC0], xmm1
00007efc33fcfbca  vmovaps xmm1, [rsp+0xE0]
00007efc33fcfbd3  vmovaps [rsp+0xE0], xmm14
00007efc33fcfbdc  movaps xmm15, xmm13
00007efc33fcfbe0  addpd xmm15, xmm1
00007efc33fcfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
00007efc33fcfbeb  ptest xmm14, xmm14
00007efc33fcfbf1  jnz 0x00007EFC33FD2137
00007efc33fcfbf7  vmovaps xmm1, [rsp+0xB0]
00007efc33fcfc00  vpermilpd xmm1, xmm1, 0x00
00007efc33fcfc06  movaps xmm14, xmm11
00007efc33fcfc0a  mulpd xmm14, xmm1
00007efc33fcfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
00007efc33fcfc15  ptest xmm13, xmm13
00007efc33fcfc1b  jnz 0x00007EFC33FD227A
00007efc33fcfc21  movaps [r15+0x260], xmm14
00007efc33fcfc29  vxorps xmm1, xmm1, xmm1
00007efc33fcfc2d  vpbroadcastq xmm1, xmm1
00007efc33fcfc32  movaps [r15+0x1B0], xmm1
00007efc33fcfc3a  vmovaps xmm1, [rsp+0xB0]
00007efc33fcfc43  vpermilpd xmm1, xmm1, 0x00
00007efc33fcfc49  vmovaps xmm11, [rsp+0xC0]
00007efc33fcfc52  vmovaps [rsp+0xC0], xmm15
00007efc33fcfc5b  movaps xmm13, xmm11
00007efc33fcfc5f  mulpd xmm13, xmm1
00007efc33fcfc64  vcmppd xmm15, xmm13, xmm13, 0x03
00007efc33fcfc6a  ptest xmm15, xmm15
00007efc33fcfc70  jnz 0x00007EFC33FD23BD
00007efc33fcfc76  lea rax, [r14+0xC0]
00007efc33fcfc7d  movups xmm1, [r13+rax*1]
00007efc33fcfc83  vmovaps xmm11, [rsp+0x110]
00007efc33fcfc8c  vmovaps [rsp+0xF0], xmm1
00007efc33fcfc95  vmovaps xmm1, [rsp+0x30]
00007efc33fcfc9b  vmovaps [rsp+0x30], xmm14
00007efc33fcfca1  movaps xmm15, xmm11
00007efc33fcfca5  addpd xmm15, xmm1
00007efc33fcfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
00007efc33fcfcb0  ptest xmm14, xmm14
00007efc33fcfcb6  jnz 0x00007EFC33FD250A
00007efc33fcfcbc  vmovaps [rsp+0x100], xmm9
00007efc33fcfcc5  vmovaps xmm1, [rsp+0x100]
00007efc33fcfcce  por xmm9, xmm1
00007efc33fcfcd3  movaps [r15+0x270], xmm9
00007efc33fcfcdb  vmovaps [rsp+0x100], xmm6
00007efc33fcfce4  vmovaps xmm1, [rsp+0x100]
00007efc33fcfced  por xmm6, xmm1
00007efc33fcfcf1  movaps [r15+0x1A0], xmm6
00007efc33fcfcf9  vmovaps xmm14, [rsp+0xB0]
00007efc33fcfd02  vpermilpd xmm14, xmm14, 0x00
00007efc33fcfd08  vmovaps xmm6, [rsp+0xF0]
00007efc33fcfd11  vmovaps [rsp+0xF0], xmm1
00007efc33fcfd1a  movaps xmm11, xmm6
00007efc33fcfd1e  mulpd xmm11, xmm14
00007efc33fcfd23  vcmppd xmm1, xmm11, xmm11, 0x03
00007efc33fcfd29  ptest xmm1, xmm1
00007efc33fcfd2e  jnz 0x00007EFC33FD264D
00007efc33fcfd34  lea rax, [r14+0x20]
00007efc33fcfd38  movups xmm1, [r13+rax*1]
00007efc33fcfd3e  movaps [r15+0x110], xmm1
00007efc33fcfd46  vmovaps xmm6, [rsp+0xE0]
00007efc33fcfd4f  vmovaps [rsp+0xE0], xmm1
00007efc33fcfd58  movaps xmm14, xmm6
00007efc33fcfd5c  addpd xmm14, xmm2
00007efc33fcfd61  vcmppd xmm1, xmm14, xmm14, 0x03
00007efc33fcfd67  ptest xmm1, xmm1
00007efc33fcfd6c  jnz 0x00007EFC33FD279A
00007efc33fcfd72  vmovaps xmm1, [rsp+0xB0]
00007efc33fcfd7b  vpermilpd xmm1, xmm1, 0x00
00007efc33fcfd81  movaps xmm6, xmm5
00007efc33fcfd84  mulpd xmm6, xmm1
00007efc33fcfd88  vcmppd xmm2, xmm6, xmm6, 0x03
00007efc33fcfd8d  ptest xmm2, xmm2
00007efc33fcfd92  jnz 0x00007EFC33FD28DC
00007efc33fcfd98  vmovaps xmm5, [rsp+0x20]
00007efc33fcfd9e  movaps xmm1, xmm5
00007efc33fcfda1  addpd xmm1, xmm13
00007efc33fcfda6  vcmppd xmm2, xmm1, xmm1, 0x03
00007efc33fcfdab  ptest xmm2, xmm2
00007efc33fcfdb0  jnz 0x00007EFC33FD2A1C
00007efc33fcfdb6  vmovaps xmm13, [rsp+0x80]
00007efc33fcfdbf  vpermilpd xmm13, xmm13, 0x00
00007efc33fcfdc5  vmovaps xmm2, [rsp+0xE0]
00007efc33fcfdce  vmovaps [rsp+0x20], xmm1
00007efc33fcfdd4  movaps xmm5, xmm2
00007efc33fcfdd7  mulpd xmm5, xmm13
00007efc33fcfddc  vcmppd xmm1, xmm5, xmm5, 0x03
00007efc33fcfde1  ptest xmm1, xmm1
00007efc33fcfde6  jnz 0x00007EFC33FD2B5D
00007efc33fcfdec  vmovaps xmm1, [rsp+0x80]
00007efc33fcfdf5  vpermilpd xmm1, xmm1, 0x00
00007efc33fcfdfb  movaps xmm13, xmm10
00007efc33fcfdff  mulpd xmm13, xmm1
00007efc33fcfe04  vcmppd xmm2, xmm13, xmm13, 0x03
00007efc33fcfe0a  ptest xmm2, xmm2
00007efc33fcfe0f  jnz 0x00007EFC33FD2C9E
00007efc33fcfe15  vmovaps xmm10, [rsp+0x30]
00007efc33fcfe1b  movaps xmm1, xmm15
00007efc33fcfe1f  addpd xmm1, xmm10
00007efc33fcfe24  vcmppd xmm2, xmm1, xmm1, 0x03
00007efc33fcfe29  ptest xmm2, xmm2
00007efc33fcfe2e  jnz 0x00007EFC33FD2DE1
00007efc33fcfe34  vmovaps xmm10, [rsp+0xC0]
00007efc33fcfe3d  movaps xmm15, xmm10
00007efc33fcfe41  addpd xmm15, xmm11
00007efc33fcfe46  vcmppd xmm2, xmm15, xmm15, 0x03
00007efc33fcfe4c  ptest xmm2, xmm2
00007efc33fcfe51  jnz 0x00007EFC33FD2F23
00007efc33fcfe57  vmovaps xmm11, [rsp+0x80]
00007efc33fcfe60  vpermilpd xmm11, xmm11, 0x00
00007efc33fcfe66  movaps xmm10, xmm12
00007efc33fcfe6a  mulpd xmm10, xmm11
00007efc33fcfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
00007efc33fcfe75  ptest xmm2, xmm2
00007efc33fcfe7a  jnz 0x00007EFC33FD3067
00007efc33fcfe80  vmovaps xmm12, [rsp+0x80]
00007efc33fcfe89  vpermilpd xmm12, xmm12, 0x00
00007efc33fcfe8f  vmovaps xmm2, [rsp+0xA0]
00007efc33fcfe98  vmovaps [rsp+0x30], xmm1
00007efc33fcfe9e  movaps xmm11, xmm2
00007efc33fcfea2  mulpd xmm11, xmm12
00007efc33fcfea7  vcmppd xmm1, xmm11, xmm11, 0x03
00007efc33fcfead  ptest xmm1, xmm1
00007efc33fcfeb2  jnz 0x00007EFC33FD31AB
00007efc33fcfeb8  movaps xmm1, xmm14
00007efc33fcfebc  addpd xmm1, xmm6
00007efc33fcfec0  vcmppd xmm12, xmm1, xmm1, 0x03
00007efc33fcfec5  ptest xmm12, xmm12
00007efc33fcfecb  jnz 0x00007EFC33FD32EE
00007efc33fcfed1  vmovaps xmm12, [rsp+0x20]
00007efc33fcfed7  movaps xmm14, xmm12
00007efc33fcfedb  addpd xmm14, xmm5
00007efc33fcfee0  vcmppd xmm6, xmm14, xmm14, 0x03
00007efc33fcfee6  ptest xmm6, xmm6
00007efc33fcfeeb  jnz 0x00007EFC33FD342F
00007efc33fcfef1  vmovaps xmm12, [rsp+0x90]
00007efc33fcfefa  vpermilpd xmm12, xmm12, 0x00
00007efc33fcff00  movaps xmm6, xmm9
00007efc33fcff04  mulpd xmm6, xmm12
00007efc33fcff09  vcmppd xmm5, xmm6, xmm6, 0x03
00007efc33fcff0e  ptest xmm5, xmm5
00007efc33fcff13  jnz 0x00007EFC33FD3572
00007efc33fcff19  movaps xmm12, xmm15
00007efc33fcff1d  addpd xmm12, xmm13
00007efc33fcff22  vcmppd xmm9, xmm12, xmm12, 0x03
00007efc33fcff28  ptest xmm9, xmm9
00007efc33fcff2e  jnz 0x00007EFC33FD36B4
00007efc33fcff34  vmovaps xmm13, [rsp+0x30]
00007efc33fcff3a  movaps xmm15, xmm13
00007efc33fcff3e  addpd xmm15, xmm10
00007efc33fcff43  vcmppd xmm9, xmm15, xmm15, 0x03
00007efc33fcff49  ptest xmm9, xmm9
00007efc33fcff4f  jnz 0x00007EFC33FD37F8
00007efc33fcff55  vmovaps xmm13, [rsp+0xD0]
00007efc33fcff5e  vmovaps xmm10, [rsp+0xD0]
00007efc33fcff67  por xmm13, xmm10
00007efc33fcff6c  movaps [r15+0x250], xmm13
00007efc33fcff74  vmovaps [rsp+0x20], xmm7
00007efc33fcff7a  vmovaps xmm13, [rsp+0x20]
00007efc33fcff80  por xmm7, xmm13
00007efc33fcff85  movaps [r15+0x2A0], xmm7
00007efc33fcff8d  vmovaps [rsp+0x20], xmm3
00007efc33fcff93  vmovaps xmm13, [rsp+0x20]
00007efc33fcff99  por xmm3, xmm13
00007efc33fcff9e  movaps [r15+0x1D0], xmm3
00007efc33fcffa6  lea rax, [r14+0x40]
00007efc33fcffaa  movups xmm13, [r13+rax*1]
00007efc33fcffb0  movaps [r15+0x2C0], xmm13
00007efc33fcffb8  vmovaps xmm10, [rsp+0x90]
00007efc33fcffc1  vpermilpd xmm10, xmm10, 0x00
00007efc33fcffc7  movaps xmm9, xmm8
00007efc33fcffcb  mulpd xmm9, xmm10
00007efc33fcffd0  vcmppd xmm5, xmm9, xmm9, 0x03
00007efc33fcffd6  ptest xmm5, xmm5
00007efc33fcffdb  jnz 0x00007EFC33FD3946
00007efc33fcffe1  movaps xmm10, xmm1
00007efc33fcffe5  addpd xmm10, xmm11
00007efc33fcffea  vcmppd xmm8, xmm10, xmm10, 0x03
00007efc33fcfff0  ptest xmm8, xmm8
00007efc33fcfff6  jnz 0x00007EFC33FD3A8A
00007efc33fcfffc  movaps xmm1, xmm14
00007efc33fd0000  addpd xmm1, xmm6
00007efc33fd0004  vcmppd xmm11, xmm1, xmm1, 0x03
00007efc33fd0009  ptest xmm11, xmm11
00007efc33fd000f  jnz 0x00007EFC33FD3BCD
00007efc33fd0015  vmovaps xmm14, [rsp+0x90]
00007efc33fd001e  vpermilpd xmm14, xmm14, 0x00
00007efc33fd0024  movaps xmm11, xmm13
00007efc33fd0028  mulpd xmm11, xmm14
00007efc33fd002d  vcmppd xmm8, xmm11, xmm11, 0x03
00007efc33fd0033  ptest xmm8, xmm8
00007efc33fd0039  jnz 0x00007EFC33FD3D0E
00007efc33fd003f  vmovaps xmm14, [rsp+0x90]
00007efc33fd0048  vpermilpd xmm14, xmm14, 0x00
00007efc33fd004e  vmovaps xmm8, [rsp+0x10]
00007efc33fd0054  movaps xmm13, xmm8
00007efc33fd0058  mulpd xmm13, xmm14
00007efc33fd005d  vcmppd xmm6, xmm13, xmm13, 0x03
00007efc33fd0063  ptest xmm6, xmm6
00007efc33fd0068  jnz 0x00007EFC33FD3E52
00007efc33fd006e  vmovaps xmm14, [rsp+0x60]
00007efc33fd0074  vpermilpd xmm14, xmm14, 0x00
00007efc33fd007a  movaps xmm8, xmm7
00007efc33fd007e  mulpd xmm8, xmm14
00007efc33fd0083  vcmppd xmm6, xmm8, xmm8, 0x03
00007efc33fd0089  ptest xmm6, xmm6
00007efc33fd008e  jnz 0x00007EFC33FD3F96
00007efc33fd0094  movaps xmm14, xmm12
00007efc33fd0098  addpd xmm14, xmm9
00007efc33fd009d  vcmppd xmm7, xmm14, xmm14, 0x03
00007efc33fd00a3  ptest xmm7, xmm7
00007efc33fd00a8  jnz 0x00007EFC33FD40D9
00007efc33fd00ae  vmovaps xmm12, [rsp+0x60]
00007efc33fd00b4  vpermilpd xmm12, xmm12, 0x00
00007efc33fd00ba  vmovaps xmm7, [rsp+0xF0]
00007efc33fd00c3  movaps xmm9, xmm7
00007efc33fd00c7  mulpd xmm9, xmm12
00007efc33fd00cc  vcmppd xmm6, xmm9, xmm9, 0x03
00007efc33fd00d2  ptest xmm6, xmm6
00007efc33fd00d7  jnz 0x00007EFC33FD421D
00007efc33fd00dd  movaps xmm12, xmm15
00007efc33fd00e1  addpd xmm12, xmm11
00007efc33fd00e6  vcmppd xmm7, xmm12, xmm12, 0x03
00007efc33fd00ec  ptest xmm7, xmm7
00007efc33fd00f1  jnz 0x00007EFC33FD4360
00007efc33fd00f7  vmovaps xmm15, [rsp+0x60]
00007efc33fd00fd  vpermilpd xmm15, xmm15, 0x00
00007efc33fd0103  vmovaps xmm7, [rsp+0x40]
00007efc33fd0109  movaps xmm11, xmm7
00007efc33fd010d  mulpd xmm11, xmm15
00007efc33fd0112  vcmppd xmm6, xmm11, xmm11, 0x03
00007efc33fd0118  ptest xmm6, xmm6
00007efc33fd011d  jnz 0x00007EFC33FD44A4
00007efc33fd0123  movaps xmm15, xmm10
00007efc33fd0127  addpd xmm15, xmm13
00007efc33fd012c  vcmppd xmm7, xmm15, xmm15, 0x03
00007efc33fd0132  ptest xmm7, xmm7
00007efc33fd0137  jnz 0x00007EFC33FD45E7
00007efc33fd013d  vmovaps xmm13, [rsp+0x60]
00007efc33fd0143  vpermilpd xmm13, xmm13, 0x00
00007efc33fd0149  vmovaps xmm7, [rsp+0x50]
00007efc33fd014f  movaps xmm10, xmm7
00007efc33fd0153  mulpd xmm10, xmm13
00007efc33fd0158  vcmppd xmm6, xmm10, xmm10, 0x03
00007efc33fd015e  ptest xmm6, xmm6
00007efc33fd0163  jnz 0x00007EFC33FD472B
00007efc33fd0169  movaps xmm13, xmm1
00007efc33fd016d  addpd xmm13, xmm8
00007efc33fd0172  vcmppd xmm7, xmm13, xmm13, 0x03
00007efc33fd0178  ptest xmm7, xmm7
00007efc33fd017d  jnz 0x00007EFC33FD486E
00007efc33fd0183  lea rax, [r14+0x70]
00007efc33fd0187  movups xmm1, [r13+rax*1]
00007efc33fd018d  movaps [r15+0x240], xmm1
00007efc33fd0195  movaps xmm8, xmm14
00007efc33fd0199  addpd xmm8, xmm9
00007efc33fd019e  vcmppd xmm7, xmm8, xmm8, 0x03
00007efc33fd01a4  ptest xmm7, xmm7
00007efc33fd01a9  jnz 0x00007EFC33FD49BB
00007efc33fd01af  movaps [r15+0x170], xmm8
00007efc33fd01b7  vmovaps xmm14, [rsp+0x70]
00007efc33fd01bd  vpermilpd xmm14, xmm14, 0x00
00007efc33fd01c3  movaps xmm9, xmm1
00007efc33fd01c7  mulpd xmm9, xmm14
00007efc33fd01cc  vcmppd xmm7, xmm9, xmm9, 0x03
00007efc33fd01d2  ptest xmm7, xmm7
00007efc33fd01d7  jnz 0x00007EFC33FD4AFF
00007efc33fd01dd  vmovaps xmm1, [rsp+0x70]
00007efc33fd01e3  vpermilpd xmm1, xmm1, 0x00
00007efc33fd01e9  movaps xmm14, xmm4
00007efc33fd01ed  mulpd xmm14, xmm1
00007efc33fd01f2  vcmppd xmm7, xmm14, xmm14, 0x03
00007efc33fd01f8  ptest xmm7, xmm7
00007efc33fd01fd  jnz 0x00007EFC33FD4C42
00007efc33fd0203  movaps [r15+0x180], xmm14
00007efc33fd020b  movaps xmm1, xmm12
00007efc33fd020f  addpd xmm1, xmm11
00007efc33fd0214  vcmppd xmm7, xmm1, xmm1, 0x03
00007efc33fd0219  ptest xmm7, xmm7
00007efc33fd021e  jnz 0x00007EFC33FD4D84
00007efc33fd0224  movaps [r15+0x210], xmm1
00007efc33fd022c  movups xmm12, [r13+r14*1]
00007efc33fd0232  lea rax, [r14+0x10]
00007efc33fd0236  movups xmm11, [r13+rax*1]
00007efc33fd023c  movaps [r15+0x230], xmm11
00007efc33fd0244  movaps xmm7, xmm15
00007efc33fd0248  addpd xmm7, xmm10
00007efc33fd024d  vcmppd xmm6, xmm7, xmm7, 0x03
00007efc33fd0252  ptest xmm6, xmm6
00007efc33fd0257  jnz 0x00007EFC33FD4EDA
00007efc33fd025d  movaps [r15+0x130], xmm7
00007efc33fd0265  vmovaps xmm15, [rsp+0x70]
00007efc33fd026b  vpermilpd xmm15, xmm15, 0x00
00007efc33fd0271  movaps xmm10, xmm11
00007efc33fd0275  mulpd xmm10, xmm15
00007efc33fd027a  vcmppd xmm6, xmm10, xmm10, 0x03
00007efc33fd0280  ptest xmm6, xmm6
00007efc33fd0285  jnz 0x00007EFC33FD501C
00007efc33fd028b  movaps [r15+0x220], xmm10
00007efc33fd0293  vmovaps xmm15, [rsp+0x70]
00007efc33fd0299  vpermilpd xmm15, xmm15, 0x00
00007efc33fd029f  movaps xmm11, xmm12
00007efc33fd02a3  mulpd xmm11, xmm15
00007efc33fd02a8  vcmppd xmm6, xmm11, xmm11, 0x03
00007efc33fd02ae  ptest xmm6, xmm6
00007efc33fd02b3  jnz 0x00007EFC33FD5160
00007efc33fd02b9  movaps xmm15, xmm13
00007efc33fd02bd  addpd xmm15, xmm9
00007efc33fd02c2  vcmppd xmm12, xmm15, xmm15, 0x03
00007efc33fd02c8  ptest xmm12, xmm12
00007efc33fd02ce  jnz 0x00007EFC33FD52A4
00007efc33fd02d4  movaps [r15+0x140], xmm15
00007efc33fd02dc  movaps xmm13, xmm8
00007efc33fd02e0  addpd xmm13, xmm14
00007efc33fd02e5  vcmppd xmm12, xmm13, xmm13, 0x03
00007efc33fd02eb  ptest xmm12, xmm12
00007efc33fd02f1  jnz 0x00007EFC33FD53E8
00007efc33fd02f7  movaps [r15+0x150], xmm13
00007efc33fd02ff  movaps xmm14, xmm1
00007efc33fd0303  addpd xmm14, xmm10
00007efc33fd0308  vcmppd xmm12, xmm14, xmm14, 0x03
00007efc33fd030e  ptest xmm12, xmm12
00007efc33fd0314  jnz 0x00007EFC33FD552C
00007efc33fd031a  movaps [r15+0x160], xmm14
00007efc33fd0322  movaps xmm1, xmm7
00007efc33fd0325  addpd xmm1, xmm11
00007efc33fd032a  vcmppd xmm12, xmm1, xmm1, 0x03
00007efc33fd032f  ptest xmm12, xmm12
00007efc33fd0335  jnz 0x00007EFC33FD566F
00007efc33fd033b  movaps [r15+0x120], xmm1
00007efc33fd0343  mov eax, 0x430920
00007efc33fd0348  movups [r13+rax*1], xmm15
00007efc33fd034e  mov eax, 0x430930
00007efc33fd0353  movups [r13+rax*1], xmm13
00007efc33fd0359  mov eax, 0x430940
00007efc33fd035e  movups [r13+rax*1], xmm14
00007efc33fd0364  mov eax, 0x430950
00007efc33fd0369  movups [r13+rax*1], xmm1
00007efc33fd036f  mov eax, [r15+0x108]
00007efc33fd0376  sahf
00007efc33fd0377  jnz 0x00007EFC33FD03A9
00007efc33fd0379  cmp dword ptr [r15+0x318], 0x00
00007efc33fd0381  jz 0x00007EFC33FDB900
00007efc33fd0387  nop [rax+rax*1], ax
00007efc33fd0390  nop [rax+rax*1], eax
00007efc33fd0398  mov eax, 0x410444
00007efc33fd039d  mov [r15+0x100], rax
00007efc33fd03a4  jmp 0x00007EFC33DFE110
00007efc33fd03a9  cmp dword ptr [r15+0x318], 0x00
00007efc33fd03b1  jz 0x00007EFC33FD57E0
00007efc33fd03b7  nop [rax+rax*1], ax
00007efc33fd03c0  nop [rax+rax*1], eax
00007efc33fd03c8  mov eax, 0x410278
00007efc33fd03cd  mov [r15+0x100], rax
00007efc33fd03d4  jmp 0x00007EFC33DFE110
00007efc33fd03d9  int3
00007efc33fd03da  call 0x00007EFC33EB52F0
00007efc33fd03df  jmp 0x00007EFC33FCF016
00007efc33fd03e4  call 0x00007EFC33EC4620
00007efc33fd03e9  jmp 0x00007EFC33FCF023
00007efc33fd03ee  call 0x00007EFC33EC33A0
00007efc33fd03f3  jmp 0x00007EFC33FCF035
00007efc33fd03f8  call 0x00007EFC33EC2120
00007efc33fd03fd  jmp 0x00007EFC33FCF03F
00007efc33fd0402  call 0x00007EFC33EC0860
00007efc33fd0407  jmp 0x00007EFC33FCF067
00007efc33fd040c  call 0x00007EFC33EBF5F0
00007efc33fd0411  jmp 0x00007EFC33FCF073
00007efc33fd0416  call 0x00007EFC33EC0860
00007efc33fd041b  jmp 0x00007EFC33FCF0A5
00007efc33fd0420  call 0x00007EFC33EBF5F0
00007efc33fd0425  jmp 0x00007EFC33FCF0B1
00007efc33fd042a  call 0x00007EFC33EC4740
00007efc33fd042f  jmp 0x00007EFC33FCF0BE
00007efc33fd0434  call 0x00007EFC33EB5400
00007efc33fd0439  jmp 0x00007EFC33FCF0CB
00007efc33fd043e  call 0x00007EFC33EB52F0
00007efc33fd0443  jmp 0x00007EFC33FCF0D8
00007efc33fd0448  call 0x00007EFC33EC4620
00007efc33fd044d  jmp 0x00007EFC33FCF0E5
00007efc33fd0452  call 0x00007EFC33EC0860
00007efc33fd0457  jmp 0x00007EFC33FCF10D
00007efc33fd045c  call 0x00007EFC33EBF5F0
00007efc33fd0461  jmp 0x00007EFC33FCF119
00007efc33fd0466  call 0x00007EFC33E09D70
00007efc33fd046b  jmp 0x00007EFC33FCF11F
00007efc33fd0470  call 0x00007EFC33EBE9C0
00007efc33fd0475  jmp 0x00007EFC33FCF129
00007efc33fd047a  call 0x00007EFC33EC0860
00007efc33fd047f  jmp 0x00007EFC33FCF151
00007efc33fd0484  call 0x00007EFC33EBF5F0
00007efc33fd0489  jmp 0x00007EFC33FCF15D
00007efc33fd048e  call 0x00007EFC33EBD750
00007efc33fd0493  jmp 0x00007EFC33FCF16A
00007efc33fd0498  call 0x00007EFC33EBC4E0
00007efc33fd049d  jmp 0x00007EFC33FCF177
00007efc33fd04a2  call 0x00007EFC33EC4740
00007efc33fd04a7  jmp 0x00007EFC33FCF184
00007efc33fd04ac  call 0x00007EFC33EB5400
00007efc33fd04b1  jmp 0x00007EFC33FCF191
00007efc33fd04b6  call 0x00007EFC33EB52F0
00007efc33fd04bb  jmp 0x00007EFC33FCF19E
00007efc33fd04c0  call 0x00007EFC33EC4620
00007efc33fd04c5  jmp 0x00007EFC33FCF1AB
00007efc33fd04ca  call 0x00007EFC33EC0860
00007efc33fd04cf  jmp 0x00007EFC33FCF1BE
00007efc33fd04d4  call 0x00007EFC33EBB270
00007efc33fd04d9  jmp 0x00007EFC33FCF1CB
00007efc33fd04de  call 0x00007EFC33EBA000
00007efc33fd04e3  jmp 0x00007EFC33FCF1D8
00007efc33fd04e8  call 0x00007EFC33EB8D90
00007efc33fd04ed  jmp 0x00007EFC33FCF1E5
00007efc33fd04f2  call 0x00007EFC33EB8A20
00007efc33fd04f7  jmp 0x00007EFC33FCF1F2
00007efc33fd04fc  call 0x00007EFC33EB5400
00007efc33fd0501  jmp 0x00007EFC33FCF1FC
00007efc33fd0506  call 0x00007EFC33EC2240
00007efc33fd050b  jmp 0x00007EFC33FCF206
00007efc33fd0510  call 0x00007EFC33EB52F0
00007efc33fd0515  jmp 0x00007EFC33FCF210
00007efc33fd051a  call 0x00007EFC33EC2120
00007efc33fd051f  jmp 0x00007EFC33FCF21A
00007efc33fd0524  call 0x00007EFC33EB77B0
00007efc33fd0529  jmp 0x00007EFC33FCF224
00007efc33fd052e  call 0x00007EFC33EB6550
00007efc33fd0533  jmp 0x00007EFC33FCF22E
00007efc33fd0538  call 0x00007EFC33EBFD50
00007efc33fd053d  jmp 0x00007EFC33FCF240
00007efc33fd0542  call 0x00007EFC33EB8EA0
00007efc33fd0547  jmp 0x00007EFC33FCF24A
00007efc33fd054c  call 0x00007EFC33EBFC30
00007efc33fd0551  jmp 0x00007EFC33FCF257
00007efc33fd0556  call 0x00007EFC33EB8D90
00007efc33fd055b  jmp 0x00007EFC33FCF264
00007efc33fd0560  call 0x00007EFC33EC2240
00007efc33fd0565  jmp 0x00007EFC33FCF271
00007efc33fd056a  call 0x00007EFC33EB5400
00007efc33fd056f  jmp 0x00007EFC33FCF27E
00007efc33fd0574  call 0x00007EFC33EB52F0
00007efc33fd0579  jmp 0x00007EFC33FCF28B
00007efc33fd057e  call 0x00007EFC33EC2120
00007efc33fd0583  jmp 0x00007EFC33FCF298
00007efc33fd0588  call 0x00007EFC33EB52F0
00007efc33fd058d  jmp 0x00007EFC33FCF2AB
00007efc33fd0592  call 0x00007EFC33EB52F0
00007efc33fd0597  jmp 0x00007EFC33FCF2BE
00007efc33fd059c  call 0x00007EFC33EB52F0
00007efc33fd05a1  jmp 0x00007EFC33FCF2D1
00007efc33fd05a6  call 0x00007EFC33EB52F0
00007efc33fd05ab  jmp 0x00007EFC33FCF2E4
00007efc33fd05b0  call 0x00007EFC33EC2240
00007efc33fd05b5  jmp 0x00007EFC33FCF2F9
00007efc33fd05ba  call 0x00007EFC33EC2240
00007efc33fd05bf  jmp 0x00007EFC33FCF30C
00007efc33fd05c4  call 0x00007EFC33EC2120
00007efc33fd05c9  jmp 0x00007EFC33FCF319
00007efc33fd05ce  call 0x00007EFC33EB52F0
00007efc33fd05d3  jmp 0x00007EFC33FCF32C
00007efc33fd05d8  call 0x00007EFC33EB52F0
00007efc33fd05dd  jmp 0x00007EFC33FCF34F
00007efc33fd05e2  call 0x00007EFC33EB52F0
00007efc33fd05e7  jmp 0x00007EFC33FCF362
00007efc33fd05ec  call 0x00007EFC33DFF540
00007efc33fd05f1  jmp 0x00007EFC33FCF380
00007efc33fd05f6  call 0x00007EFC33E08C20
00007efc33fd05fb  jmp 0x00007EFC33FCF38A
00007efc33fd0600  call 0x00007EFC33ED6600
00007efc33fd0605  jmp 0x00007EFC33FCF396
00007efc33fd060a  call 0x00007EFC33DFF540
00007efc33fd060f  jmp 0x00007EFC33FCF3A6
00007efc33fd0614  call 0x00007EFC33EC0370
00007efc33fd0619  jmp 0x00007EFC33FCF3D4
00007efc33fd061e  call 0x00007EFC33EBF100
00007efc33fd0623  jmp 0x00007EFC33FCF3DD
00007efc33fd0628  call 0x00007EFC33EC0370
00007efc33fd062d  jmp 0x00007EFC33FCF43B
00007efc33fd0632  call 0x00007EFC33EBF100
00007efc33fd0637  jmp 0x00007EFC33FCF444
00007efc33fd063c  call 0x00007EFC33EC0370
00007efc33fd0641  jmp 0x00007EFC33FCF48B
00007efc33fd0646  call 0x00007EFC33EBF100
00007efc33fd064b  jmp 0x00007EFC33FCF494
00007efc33fd0650  call 0x00007EFC33E0B720
00007efc33fd0655  jmp 0x00007EFC33FCF4D7
00007efc33fd065a  call 0x00007EFC33EB47C0
00007efc33fd065f  jmp 0x00007EFC33FCF4EA
00007efc33fd0664  call 0x00007EFC33E08B00
00007efc33fd0669  jmp 0x00007EFC33FCF501
00007efc33fd066e  call 0x00007EFC33DFF430
00007efc33fd0673  jmp 0x00007EFC33FCF514
00007efc33fd0678  call 0x00007EFC33DFF430
00007efc33fd067d  jmp 0x00007EFC33FCF527
00007efc33fd0682  sub rsp, 0x08
00007efc33fd0686  push rax
00007efc33fd0687  push rcx
00007efc33fd0688  push rdx
00007efc33fd0689  push rdi
00007efc33fd068a  push rsi
00007efc33fd068b  push r8
00007efc33fd068d  push r9
00007efc33fd068f  push r10
00007efc33fd0691  push r11
00007efc33fd0693  sub rsp, 0xF0
00007efc33fd069a  vmovaps [rsp], xmm0
00007efc33fd069f  vmovaps [rsp+0x10], xmm2
00007efc33fd06a5  vmovaps [rsp+0x20], xmm3
00007efc33fd06ab  vmovaps [rsp+0x30], xmm4
00007efc33fd06b1  vmovaps [rsp+0x40], xmm5
00007efc33fd06b7  vmovaps [rsp+0x50], xmm6
00007efc33fd06bd  vmovaps [rsp+0x60], xmm7
00007efc33fd06c3  vmovaps [rsp+0x70], xmm8
00007efc33fd06c9  vmovaps [rsp+0x80], xmm9
00007efc33fd06d2  vmovaps [rsp+0x90], xmm10
00007efc33fd06db  vmovaps [rsp+0xA0], xmm11
00007efc33fd06e4  vmovaps [rsp+0xB0], xmm12
00007efc33fd06ed  vmovaps [rsp+0xC0], xmm13
00007efc33fd06f6  vmovaps [rsp+0xD0], xmm14
00007efc33fd06ff  vmovaps [rsp+0xE0], xmm15
00007efc33fd0708  sub rsp, 0x30
00007efc33fd070c  movaps [rsp], xmm1
00007efc33fd0710  movaps [rsp+0x10], xmm15
00007efc33fd0716  movaps [rsp+0x20], xmm14
00007efc33fd071c  lea rdi, [rsp]
00007efc33fd0720  mov esi, 0x00
00007efc33fd0725  mov rax, 0x5D9448894530
00007efc33fd072f  call rax
00007efc33fd0731  movaps xmm1, [rsp]
00007efc33fd0735  add rsp, 0x30
00007efc33fd0739  vmovaps xmm0, [rsp]
00007efc33fd073e  vmovaps xmm2, [rsp+0x10]
00007efc33fd0744  vmovaps xmm3, [rsp+0x20]
00007efc33fd074a  vmovaps xmm4, [rsp+0x30]
00007efc33fd0750  vmovaps xmm5, [rsp+0x40]
00007efc33fd0756  vmovaps xmm6, [rsp+0x50]
00007efc33fd075c  vmovaps xmm7, [rsp+0x60]
00007efc33fd0762  vmovaps xmm8, [rsp+0x70]
00007efc33fd0768  vmovaps xmm9, [rsp+0x80]
00007efc33fd0771  vmovaps xmm10, [rsp+0x90]
00007efc33fd077a  vmovaps xmm11, [rsp+0xA0]
00007efc33fd0783  vmovaps xmm12, [rsp+0xB0]
00007efc33fd078c  vmovaps xmm13, [rsp+0xC0]
00007efc33fd0795  vmovaps xmm14, [rsp+0xD0]
00007efc33fd079e  vmovaps xmm15, [rsp+0xE0]
00007efc33fd07a7  add rsp, 0xF0
00007efc33fd07ae  pop r11
00007efc33fd07b0  pop r10
00007efc33fd07b2  pop r9
00007efc33fd07b4  pop r8
00007efc33fd07b6  pop rsi
00007efc33fd07b7  pop rdi
00007efc33fd07b8  pop rdx
00007efc33fd07b9  pop rcx
00007efc33fd07ba  pop rax
00007efc33fd07bb  add rsp, 0x08
00007efc33fd07bf  jmp 0x00007EFC33FCF581
00007efc33fd07c4  sub rsp, 0x08
00007efc33fd07c8  push rax
00007efc33fd07c9  push rcx
00007efc33fd07ca  push rdx
00007efc33fd07cb  push rdi
00007efc33fd07cc  push rsi
00007efc33fd07cd  push r8
00007efc33fd07cf  push r9
00007efc33fd07d1  push r10
00007efc33fd07d3  push r11
00007efc33fd07d5  sub rsp, 0xF0
00007efc33fd07dc  vmovaps [rsp], xmm0
00007efc33fd07e1  vmovaps [rsp+0x10], xmm1
00007efc33fd07e7  vmovaps [rsp+0x20], xmm2
00007efc33fd07ed  vmovaps [rsp+0x30], xmm3
00007efc33fd07f3  vmovaps [rsp+0x40], xmm4
00007efc33fd07f9  vmovaps [rsp+0x50], xmm5
00007efc33fd07ff  vmovaps [rsp+0x60], xmm6
00007efc33fd0805  vmovaps [rsp+0x70], xmm7
00007efc33fd080b  vmovaps [rsp+0x80], xmm8
00007efc33fd0814  vmovaps [rsp+0x90], xmm9
00007efc33fd081d  vmovaps [rsp+0xA0], xmm10
00007efc33fd0826  vmovaps [rsp+0xB0], xmm11
00007efc33fd082f  vmovaps [rsp+0xC0], xmm12
00007efc33fd0838  vmovaps [rsp+0xD0], xmm14
00007efc33fd0841  vmovaps [rsp+0xE0], xmm15
00007efc33fd084a  sub rsp, 0x30
00007efc33fd084e  movaps [rsp], xmm13
00007efc33fd0853  movaps [rsp+0x10], xmm1
00007efc33fd0858  movaps [rsp+0x20], xmm14
00007efc33fd085e  lea rdi, [rsp]
00007efc33fd0862  mov esi, 0x00
00007efc33fd0867  mov rax, 0x5D9448894530
00007efc33fd0871  call rax
00007efc33fd0873  movaps xmm13, [rsp]
00007efc33fd0878  add rsp, 0x30
00007efc33fd087c  vmovaps xmm0, [rsp]
00007efc33fd0881  vmovaps xmm1, [rsp+0x10]
00007efc33fd0887  vmovaps xmm2, [rsp+0x20]
00007efc33fd088d  vmovaps xmm3, [rsp+0x30]
00007efc33fd0893  vmovaps xmm4, [rsp+0x40]
00007efc33fd0899  vmovaps xmm5, [rsp+0x50]
00007efc33fd089f  vmovaps xmm6, [rsp+0x60]
00007efc33fd08a5  vmovaps xmm7, [rsp+0x70]
00007efc33fd08ab  vmovaps xmm8, [rsp+0x80]
00007efc33fd08b4  vmovaps xmm9, [rsp+0x90]
00007efc33fd08bd  vmovaps xmm10, [rsp+0xA0]
00007efc33fd08c6  vmovaps xmm11, [rsp+0xB0]
00007efc33fd08cf  vmovaps xmm12, [rsp+0xC0]
00007efc33fd08d8  vmovaps xmm14, [rsp+0xD0]
00007efc33fd08e1  vmovaps xmm15, [rsp+0xE0]
00007efc33fd08ea  add rsp, 0xF0
00007efc33fd08f1  pop r11
00007efc33fd08f3  pop r10
00007efc33fd08f5  pop r9
00007efc33fd08f7  pop r8
00007efc33fd08f9  pop rsi
00007efc33fd08fa  pop rdi
00007efc33fd08fb  pop rdx
00007efc33fd08fc  pop rcx
00007efc33fd08fd  pop rax
00007efc33fd08fe  add rsp, 0x08
00007efc33fd0902  jmp 0x00007EFC33FCF5CF
00007efc33fd0907  sub rsp, 0x08
00007efc33fd090b  push rax
00007efc33fd090c  push rcx
00007efc33fd090d  push rdx
00007efc33fd090e  push rdi
00007efc33fd090f  push rsi
00007efc33fd0910  push r8
00007efc33fd0912  push r9
00007efc33fd0914  push r10
00007efc33fd0916  push r11
00007efc33fd0918  sub rsp, 0xF0
00007efc33fd091f  vmovaps [rsp], xmm0
00007efc33fd0924  vmovaps [rsp+0x10], xmm1
00007efc33fd092a  vmovaps [rsp+0x20], xmm2
00007efc33fd0930  vmovaps [rsp+0x30], xmm3
00007efc33fd0936  vmovaps [rsp+0x40], xmm4
00007efc33fd093c  vmovaps [rsp+0x50], xmm5
00007efc33fd0942  vmovaps [rsp+0x60], xmm6
00007efc33fd0948  vmovaps [rsp+0x70], xmm7
00007efc33fd094e  vmovaps [rsp+0x80], xmm8
00007efc33fd0957  vmovaps [rsp+0x90], xmm9
00007efc33fd0960  vmovaps [rsp+0xA0], xmm10
00007efc33fd0969  vmovaps [rsp+0xB0], xmm11
00007efc33fd0972  vmovaps [rsp+0xC0], xmm12
00007efc33fd097b  vmovaps [rsp+0xD0], xmm13
00007efc33fd0984  vmovaps [rsp+0xE0], xmm14
00007efc33fd098d  sub rsp, 0x30
00007efc33fd0991  movaps [rsp], xmm15
00007efc33fd0996  movaps [rsp+0x10], xmm14
00007efc33fd099c  movaps [rsp+0x20], xmm1
00007efc33fd09a1  lea rdi, [rsp]
00007efc33fd09a5  mov esi, 0x00
00007efc33fd09aa  mov rax, 0x5D9448894530
00007efc33fd09b4  call rax
00007efc33fd09b6  movaps xmm15, [rsp]
00007efc33fd09bb  add rsp, 0x30
00007efc33fd09bf  vmovaps xmm0, [rsp]
00007efc33fd09c4  vmovaps xmm1, [rsp+0x10]
00007efc33fd09ca  vmovaps xmm2, [rsp+0x20]
00007efc33fd09d0  vmovaps xmm3, [rsp+0x30]
00007efc33fd09d6  vmovaps xmm4, [rsp+0x40]
00007efc33fd09dc  vmovaps xmm5, [rsp+0x50]
00007efc33fd09e2  vmovaps xmm6, [rsp+0x60]
00007efc33fd09e8  vmovaps xmm7, [rsp+0x70]
00007efc33fd09ee  vmovaps xmm8, [rsp+0x80]
00007efc33fd09f7  vmovaps xmm9, [rsp+0x90]
00007efc33fd0a00  vmovaps xmm10, [rsp+0xA0]
00007efc33fd0a09  vmovaps xmm11, [rsp+0xB0]
00007efc33fd0a12  vmovaps xmm12, [rsp+0xC0]
00007efc33fd0a1b  vmovaps xmm13, [rsp+0xD0]
00007efc33fd0a24  vmovaps xmm14, [rsp+0xE0]
00007efc33fd0a2d  add rsp, 0xF0
00007efc33fd0a34  pop r11
00007efc33fd0a36  pop r10
00007efc33fd0a38  pop r9
00007efc33fd0a3a  pop r8
00007efc33fd0a3c  pop rsi
00007efc33fd0a3d  pop rdi
00007efc33fd0a3e  pop rdx
00007efc33fd0a3f  pop rcx
00007efc33fd0a40  pop rax
00007efc33fd0a41  add rsp, 0x08
00007efc33fd0a45  jmp 0x00007EFC33FCF617
00007efc33fd0a4a  sub rsp, 0x08
00007efc33fd0a4e  push rax
00007efc33fd0a4f  push rcx
00007efc33fd0a50  push rdx
00007efc33fd0a51  push rdi
00007efc33fd0a52  push rsi
00007efc33fd0a53  push r8
00007efc33fd0a55  push r9
00007efc33fd0a57  push r10
00007efc33fd0a59  push r11
00007efc33fd0a5b  sub rsp, 0xF0
00007efc33fd0a62  vmovaps [rsp], xmm0
00007efc33fd0a67  vmovaps [rsp+0x10], xmm2
00007efc33fd0a6d  vmovaps [rsp+0x20], xmm3
00007efc33fd0a73  vmovaps [rsp+0x30], xmm4
00007efc33fd0a79  vmovaps [rsp+0x40], xmm5
00007efc33fd0a7f  vmovaps [rsp+0x50], xmm6
00007efc33fd0a85  vmovaps [rsp+0x60], xmm7
00007efc33fd0a8b  vmovaps [rsp+0x70], xmm8
00007efc33fd0a91  vmovaps [rsp+0x80], xmm9
00007efc33fd0a9a  vmovaps [rsp+0x90], xmm10
00007efc33fd0aa3  vmovaps [rsp+0xA0], xmm11
00007efc33fd0aac  vmovaps [rsp+0xB0], xmm12
00007efc33fd0ab5  vmovaps [rsp+0xC0], xmm13
00007efc33fd0abe  vmovaps [rsp+0xD0], xmm14
00007efc33fd0ac7  vmovaps [rsp+0xE0], xmm15
00007efc33fd0ad0  sub rsp, 0x30
00007efc33fd0ad4  movaps [rsp], xmm1
00007efc33fd0ad8  movaps [rsp+0x10], xmm14
00007efc33fd0ade  movaps [rsp+0x20], xmm10
00007efc33fd0ae4  lea rdi, [rsp]
00007efc33fd0ae8  mov esi, 0x00
00007efc33fd0aed  mov rax, 0x5D9448894530
00007efc33fd0af7  call rax
00007efc33fd0af9  movaps xmm1, [rsp]
00007efc33fd0afd  add rsp, 0x30
00007efc33fd0b01  vmovaps xmm0, [rsp]
00007efc33fd0b06  vmovaps xmm2, [rsp+0x10]
00007efc33fd0b0c  vmovaps xmm3, [rsp+0x20]
00007efc33fd0b12  vmovaps xmm4, [rsp+0x30]
00007efc33fd0b18  vmovaps xmm5, [rsp+0x40]
00007efc33fd0b1e  vmovaps xmm6, [rsp+0x50]
00007efc33fd0b24  vmovaps xmm7, [rsp+0x60]
00007efc33fd0b2a  vmovaps xmm8, [rsp+0x70]
00007efc33fd0b30  vmovaps xmm9, [rsp+0x80]
00007efc33fd0b39  vmovaps xmm10, [rsp+0x90]
00007efc33fd0b42  vmovaps xmm11, [rsp+0xA0]
00007efc33fd0b4b  vmovaps xmm12, [rsp+0xB0]
00007efc33fd0b54  vmovaps xmm13, [rsp+0xC0]
00007efc33fd0b5d  vmovaps xmm14, [rsp+0xD0]
00007efc33fd0b66  vmovaps xmm15, [rsp+0xE0]
00007efc33fd0b6f  add rsp, 0xF0
00007efc33fd0b76  pop r11
00007efc33fd0b78  pop r10
00007efc33fd0b7a  pop r9
00007efc33fd0b7c  pop r8
00007efc33fd0b7e  pop rsi
00007efc33fd0b7f  pop rdi
00007efc33fd0b80  pop rdx
00007efc33fd0b81  pop rcx
00007efc33fd0b82  pop rax
00007efc33fd0b83  add rsp, 0x08
00007efc33fd0b87  jmp 0x00007EFC33FCF631
00007efc33fd0b8c  sub rsp, 0x08
00007efc33fd0b90  push rax
00007efc33fd0b91  push rcx
00007efc33fd0b92  push rdx
00007efc33fd0b93  push rdi
00007efc33fd0b94  push rsi
00007efc33fd0b95  push r8
00007efc33fd0b97  push r9
00007efc33fd0b99  push r10
00007efc33fd0b9b  push r11
00007efc33fd0b9d  sub rsp, 0xF0
00007efc33fd0ba4  vmovaps [rsp], xmm0
00007efc33fd0ba9  vmovaps [rsp+0x10], xmm1
00007efc33fd0baf  vmovaps [rsp+0x20], xmm2
00007efc33fd0bb5  vmovaps [rsp+0x30], xmm3
00007efc33fd0bbb  vmovaps [rsp+0x40], xmm4
00007efc33fd0bc1  vmovaps [rsp+0x50], xmm5
00007efc33fd0bc7  vmovaps [rsp+0x60], xmm6
00007efc33fd0bcd  vmovaps [rsp+0x70], xmm7
00007efc33fd0bd3  vmovaps [rsp+0x80], xmm8
00007efc33fd0bdc  vmovaps [rsp+0x90], xmm9
00007efc33fd0be5  vmovaps [rsp+0xA0], xmm10
00007efc33fd0bee  vmovaps [rsp+0xB0], xmm11
00007efc33fd0bf7  vmovaps [rsp+0xC0], xmm12
00007efc33fd0c00  vmovaps [rsp+0xD0], xmm14
00007efc33fd0c09  vmovaps [rsp+0xE0], xmm15
00007efc33fd0c12  sub rsp, 0x30
00007efc33fd0c16  movaps [rsp], xmm13
00007efc33fd0c1b  movaps [rsp+0x10], xmm14
00007efc33fd0c21  movaps [rsp+0x20], xmm2
00007efc33fd0c26  lea rdi, [rsp]
00007efc33fd0c2a  mov esi, 0x00
00007efc33fd0c2f  mov rax, 0x5D9448894530
00007efc33fd0c39  call rax
00007efc33fd0c3b  movaps xmm13, [rsp]
00007efc33fd0c40  add rsp, 0x30
00007efc33fd0c44  vmovaps xmm0, [rsp]
00007efc33fd0c49  vmovaps xmm1, [rsp+0x10]
00007efc33fd0c4f  vmovaps xmm2, [rsp+0x20]
00007efc33fd0c55  vmovaps xmm3, [rsp+0x30]
00007efc33fd0c5b  vmovaps xmm4, [rsp+0x40]
00007efc33fd0c61  vmovaps xmm5, [rsp+0x50]
00007efc33fd0c67  vmovaps xmm6, [rsp+0x60]
00007efc33fd0c6d  vmovaps xmm7, [rsp+0x70]
00007efc33fd0c73  vmovaps xmm8, [rsp+0x80]
00007efc33fd0c7c  vmovaps xmm9, [rsp+0x90]
00007efc33fd0c85  vmovaps xmm10, [rsp+0xA0]
00007efc33fd0c8e  vmovaps xmm11, [rsp+0xB0]
00007efc33fd0c97  vmovaps xmm12, [rsp+0xC0]
00007efc33fd0ca0  vmovaps xmm14, [rsp+0xD0]
00007efc33fd0ca9  vmovaps xmm15, [rsp+0xE0]
00007efc33fd0cb2  add rsp, 0xF0
00007efc33fd0cb9  pop r11
00007efc33fd0cbb  pop r10
00007efc33fd0cbd  pop r9
00007efc33fd0cbf  pop r8
00007efc33fd0cc1  pop rsi
00007efc33fd0cc2  pop rdi
00007efc33fd0cc3  pop rdx
00007efc33fd0cc4  pop rcx
00007efc33fd0cc5  pop rax
00007efc33fd0cc6  add rsp, 0x08
00007efc33fd0cca  jmp 0x00007EFC33FCF64C
00007efc33fd0ccf  sub rsp, 0x08
00007efc33fd0cd3  push rax
00007efc33fd0cd4  push rcx
00007efc33fd0cd5  push rdx
00007efc33fd0cd6  push rdi
00007efc33fd0cd7  push rsi
00007efc33fd0cd8  push r8
00007efc33fd0cda  push r9
00007efc33fd0cdc  push r10
00007efc33fd0cde  push r11
00007efc33fd0ce0  sub rsp, 0xF0
00007efc33fd0ce7  vmovaps [rsp], xmm0
00007efc33fd0cec  vmovaps [rsp+0x10], xmm2
00007efc33fd0cf2  vmovaps [rsp+0x20], xmm3
00007efc33fd0cf8  vmovaps [rsp+0x30], xmm4
00007efc33fd0cfe  vmovaps [rsp+0x40], xmm5
00007efc33fd0d04  vmovaps [rsp+0x50], xmm6
00007efc33fd0d0a  vmovaps [rsp+0x60], xmm7
00007efc33fd0d10  vmovaps [rsp+0x70], xmm8
00007efc33fd0d16  vmovaps [rsp+0x80], xmm9
00007efc33fd0d1f  vmovaps [rsp+0x90], xmm10
00007efc33fd0d28  vmovaps [rsp+0xA0], xmm11
00007efc33fd0d31  vmovaps [rsp+0xB0], xmm12
00007efc33fd0d3a  vmovaps [rsp+0xC0], xmm13
00007efc33fd0d43  vmovaps [rsp+0xD0], xmm14
00007efc33fd0d4c  vmovaps [rsp+0xE0], xmm15
00007efc33fd0d55  sub rsp, 0x30
00007efc33fd0d59  movaps [rsp], xmm1
00007efc33fd0d5d  movaps [rsp+0x10], xmm10
00007efc33fd0d63  movaps [rsp+0x20], xmm2
00007efc33fd0d68  lea rdi, [rsp]
00007efc33fd0d6c  mov esi, 0x00
00007efc33fd0d71  mov rax, 0x5D9448894530
00007efc33fd0d7b  call rax
00007efc33fd0d7d  movaps xmm1, [rsp]
00007efc33fd0d81  add rsp, 0x30
00007efc33fd0d85  vmovaps xmm0, [rsp]
00007efc33fd0d8a  vmovaps xmm2, [rsp+0x10]
00007efc33fd0d90  vmovaps xmm3, [rsp+0x20]
00007efc33fd0d96  vmovaps xmm4, [rsp+0x30]
00007efc33fd0d9c  vmovaps xmm5, [rsp+0x40]
00007efc33fd0da2  vmovaps xmm6, [rsp+0x50]
00007efc33fd0da8  vmovaps xmm7, [rsp+0x60]
00007efc33fd0dae  vmovaps xmm8, [rsp+0x70]
00007efc33fd0db4  vmovaps xmm9, [rsp+0x80]
00007efc33fd0dbd  vmovaps xmm10, [rsp+0x90]
00007efc33fd0dc6  vmovaps xmm11, [rsp+0xA0]
00007efc33fd0dcf  vmovaps xmm12, [rsp+0xB0]
00007efc33fd0dd8  vmovaps xmm13, [rsp+0xC0]
00007efc33fd0de1  vmovaps xmm14, [rsp+0xD0]
00007efc33fd0dea  vmovaps xmm15, [rsp+0xE0]
00007efc33fd0df3  add rsp, 0xF0
00007efc33fd0dfa  pop r11
00007efc33fd0dfc  pop r10
00007efc33fd0dfe  pop r9
00007efc33fd0e00  pop r8
00007efc33fd0e02  pop rsi
00007efc33fd0e03  pop rdi
00007efc33fd0e04  pop rdx
00007efc33fd0e05  pop rcx
00007efc33fd0e06  pop rax
00007efc33fd0e07  add rsp, 0x08
00007efc33fd0e0b  jmp 0x00007EFC33FCF6B4
00007efc33fd0e10  sub rsp, 0x08
00007efc33fd0e14  push rax
00007efc33fd0e15  push rcx
00007efc33fd0e16  push rdx
00007efc33fd0e17  push rdi
00007efc33fd0e18  push rsi
00007efc33fd0e19  push r8
00007efc33fd0e1b  push r9
00007efc33fd0e1d  push r10
00007efc33fd0e1f  push r11
00007efc33fd0e21  sub rsp, 0xF0
00007efc33fd0e28  vmovaps [rsp], xmm0
00007efc33fd0e2d  vmovaps [rsp+0x10], xmm1
00007efc33fd0e33  vmovaps [rsp+0x20], xmm2
00007efc33fd0e39  vmovaps [rsp+0x30], xmm3
00007efc33fd0e3f  vmovaps [rsp+0x40], xmm4
00007efc33fd0e45  vmovaps [rsp+0x50], xmm5
00007efc33fd0e4b  vmovaps [rsp+0x60], xmm6
00007efc33fd0e51  vmovaps [rsp+0x70], xmm7
00007efc33fd0e57  vmovaps [rsp+0x80], xmm8
00007efc33fd0e60  vmovaps [rsp+0x90], xmm9
00007efc33fd0e69  vmovaps [rsp+0xA0], xmm10
00007efc33fd0e72  vmovaps [rsp+0xB0], xmm11
00007efc33fd0e7b  vmovaps [rsp+0xC0], xmm12
00007efc33fd0e84  vmovaps [rsp+0xD0], xmm13
00007efc33fd0e8d  vmovaps [rsp+0xE0], xmm14
00007efc33fd0e96  sub rsp, 0x30
00007efc33fd0e9a  movaps [rsp], xmm15
00007efc33fd0e9f  movaps [rsp+0x10], xmm10
00007efc33fd0ea5  movaps [rsp+0x20], xmm2
00007efc33fd0eaa  lea rdi, [rsp]
00007efc33fd0eae  mov esi, 0x00
00007efc33fd0eb3  mov rax, 0x5D9448894530
00007efc33fd0ebd  call rax
00007efc33fd0ebf  movaps xmm15, [rsp]
00007efc33fd0ec4  add rsp, 0x30
00007efc33fd0ec8  vmovaps xmm0, [rsp]
00007efc33fd0ecd  vmovaps xmm1, [rsp+0x10]
00007efc33fd0ed3  vmovaps xmm2, [rsp+0x20]
00007efc33fd0ed9  vmovaps xmm3, [rsp+0x30]
00007efc33fd0edf  vmovaps xmm4, [rsp+0x40]
00007efc33fd0ee5  vmovaps xmm5, [rsp+0x50]
00007efc33fd0eeb  vmovaps xmm6, [rsp+0x60]
00007efc33fd0ef1  vmovaps xmm7, [rsp+0x70]
00007efc33fd0ef7  vmovaps xmm8, [rsp+0x80]
00007efc33fd0f00  vmovaps xmm9, [rsp+0x90]
00007efc33fd0f09  vmovaps xmm10, [rsp+0xA0]
00007efc33fd0f12  vmovaps xmm11, [rsp+0xB0]
00007efc33fd0f1b  vmovaps xmm12, [rsp+0xC0]
00007efc33fd0f24  vmovaps xmm13, [rsp+0xD0]
00007efc33fd0f2d  vmovaps xmm14, [rsp+0xE0]
00007efc33fd0f36  add rsp, 0xF0
00007efc33fd0f3d  pop r11
00007efc33fd0f3f  pop r10
00007efc33fd0f41  pop r9
00007efc33fd0f43  pop r8
00007efc33fd0f45  pop rsi
00007efc33fd0f46  pop rdi
00007efc33fd0f47  pop rdx
00007efc33fd0f48  pop rcx
00007efc33fd0f49  pop rax
00007efc33fd0f4a  add rsp, 0x08
00007efc33fd0f4e  jmp 0x00007EFC33FCF706
00007efc33fd0f53  sub rsp, 0x08
00007efc33fd0f57  push rax
00007efc33fd0f58  push rcx
00007efc33fd0f59  push rdx
00007efc33fd0f5a  push rdi
00007efc33fd0f5b  push rsi
00007efc33fd0f5c  push r8
00007efc33fd0f5e  push r9
00007efc33fd0f60  push r10
00007efc33fd0f62  push r11
00007efc33fd0f64  sub rsp, 0xF0
00007efc33fd0f6b  vmovaps [rsp], xmm0
00007efc33fd0f70  vmovaps [rsp+0x10], xmm2
00007efc33fd0f76  vmovaps [rsp+0x20], xmm3
00007efc33fd0f7c  vmovaps [rsp+0x30], xmm4
00007efc33fd0f82  vmovaps [rsp+0x40], xmm5
00007efc33fd0f88  vmovaps [rsp+0x50], xmm6
00007efc33fd0f8e  vmovaps [rsp+0x60], xmm7
00007efc33fd0f94  vmovaps [rsp+0x70], xmm8
00007efc33fd0f9a  vmovaps [rsp+0x80], xmm9
00007efc33fd0fa3  vmovaps [rsp+0x90], xmm10
00007efc33fd0fac  vmovaps [rsp+0xA0], xmm11
00007efc33fd0fb5  vmovaps [rsp+0xB0], xmm12
00007efc33fd0fbe  vmovaps [rsp+0xC0], xmm13
00007efc33fd0fc7  vmovaps [rsp+0xD0], xmm14
00007efc33fd0fd0  vmovaps [rsp+0xE0], xmm15
00007efc33fd0fd9  sub rsp, 0x30
00007efc33fd0fdd  movaps [rsp], xmm1
00007efc33fd0fe1  movaps [rsp+0x10], xmm10
00007efc33fd0fe7  movaps [rsp+0x20], xmm12
00007efc33fd0fed  lea rdi, [rsp]
00007efc33fd0ff1  mov esi, 0x00
00007efc33fd0ff6  mov rax, 0x5D9448894530
00007efc33fd1000  call rax
00007efc33fd1002  movaps xmm1, [rsp]
00007efc33fd1006  add rsp, 0x30
00007efc33fd100a  vmovaps xmm0, [rsp]
00007efc33fd100f  vmovaps xmm2, [rsp+0x10]
00007efc33fd1015  vmovaps xmm3, [rsp+0x20]
00007efc33fd101b  vmovaps xmm4, [rsp+0x30]
00007efc33fd1021  vmovaps xmm5, [rsp+0x40]
00007efc33fd1027  vmovaps xmm6, [rsp+0x50]
00007efc33fd102d  vmovaps xmm7, [rsp+0x60]
00007efc33fd1033  vmovaps xmm8, [rsp+0x70]
00007efc33fd1039  vmovaps xmm9, [rsp+0x80]
00007efc33fd1042  vmovaps xmm10, [rsp+0x90]
00007efc33fd104b  vmovaps xmm11, [rsp+0xA0]
00007efc33fd1054  vmovaps xmm12, [rsp+0xB0]
00007efc33fd105d  vmovaps xmm13, [rsp+0xC0]
00007efc33fd1066  vmovaps xmm14, [rsp+0xD0]
00007efc33fd106f  vmovaps xmm15, [rsp+0xE0]
00007efc33fd1078  add rsp, 0xF0
00007efc33fd107f  pop r11
00007efc33fd1081  pop r10
00007efc33fd1083  pop r9
00007efc33fd1085  pop r8
00007efc33fd1087  pop rsi
00007efc33fd1088  pop rdi
00007efc33fd1089  pop rdx
00007efc33fd108a  pop rcx
00007efc33fd108b  pop rax
00007efc33fd108c  add rsp, 0x08
00007efc33fd1090  jmp 0x00007EFC33FCF732
00007efc33fd1095  sub rsp, 0x08
00007efc33fd1099  push rax
00007efc33fd109a  push rcx
00007efc33fd109b  push rdx
00007efc33fd109c  push rdi
00007efc33fd109d  push rsi
00007efc33fd109e  push r8
00007efc33fd10a0  push r9
00007efc33fd10a2  push r10
00007efc33fd10a4  push r11
00007efc33fd10a6  sub rsp, 0xF0
00007efc33fd10ad  vmovaps [rsp], xmm0
00007efc33fd10b2  vmovaps [rsp+0x10], xmm1
00007efc33fd10b8  vmovaps [rsp+0x20], xmm2
00007efc33fd10be  vmovaps [rsp+0x30], xmm3
00007efc33fd10c4  vmovaps [rsp+0x40], xmm4
00007efc33fd10ca  vmovaps [rsp+0x50], xmm5
00007efc33fd10d0  vmovaps [rsp+0x60], xmm6
00007efc33fd10d6  vmovaps [rsp+0x70], xmm7
00007efc33fd10dc  vmovaps [rsp+0x80], xmm8
00007efc33fd10e5  vmovaps [rsp+0x90], xmm9
00007efc33fd10ee  vmovaps [rsp+0xA0], xmm10
00007efc33fd10f7  vmovaps [rsp+0xB0], xmm11
00007efc33fd1100  vmovaps [rsp+0xC0], xmm12
00007efc33fd1109  vmovaps [rsp+0xD0], xmm13
00007efc33fd1112  vmovaps [rsp+0xE0], xmm14
00007efc33fd111b  sub rsp, 0x30
00007efc33fd111f  movaps [rsp], xmm15
00007efc33fd1124  movaps [rsp+0x10], xmm10
00007efc33fd112a  movaps [rsp+0x20], xmm12
00007efc33fd1130  lea rdi, [rsp]
00007efc33fd1134  mov esi, 0x00
00007efc33fd1139  mov rax, 0x5D9448894530
00007efc33fd1143  call rax
00007efc33fd1145  movaps xmm15, [rsp]
00007efc33fd114a  add rsp, 0x30
00007efc33fd114e  vmovaps xmm0, [rsp]
00007efc33fd1153  vmovaps xmm1, [rsp+0x10]
00007efc33fd1159  vmovaps xmm2, [rsp+0x20]
00007efc33fd115f  vmovaps xmm3, [rsp+0x30]
00007efc33fd1165  vmovaps xmm4, [rsp+0x40]
00007efc33fd116b  vmovaps xmm5, [rsp+0x50]
00007efc33fd1171  vmovaps xmm6, [rsp+0x60]
00007efc33fd1177  vmovaps xmm7, [rsp+0x70]
00007efc33fd117d  vmovaps xmm8, [rsp+0x80]
00007efc33fd1186  vmovaps xmm9, [rsp+0x90]
00007efc33fd118f  vmovaps xmm10, [rsp+0xA0]
00007efc33fd1198  vmovaps xmm11, [rsp+0xB0]
00007efc33fd11a1  vmovaps xmm12, [rsp+0xC0]
00007efc33fd11aa  vmovaps xmm13, [rsp+0xD0]
00007efc33fd11b3  vmovaps xmm14, [rsp+0xE0]
00007efc33fd11bc  add rsp, 0xF0
00007efc33fd11c3  pop r11
00007efc33fd11c5  pop r10
00007efc33fd11c7  pop r9
00007efc33fd11c9  pop r8
00007efc33fd11cb  pop rsi
00007efc33fd11cc  pop rdi
00007efc33fd11cd  pop rdx
00007efc33fd11ce  pop rcx
00007efc33fd11cf  pop rax
00007efc33fd11d0  add rsp, 0x08
00007efc33fd11d4  jmp 0x00007EFC33FCF75E
00007efc33fd11d9  call 0x00007EFC33DFF430
00007efc33fd11de  jmp 0x00007EFC33FCF7EE
00007efc33fd11e3  call 0x00007EFC33DFF430
00007efc33fd11e8  jmp 0x00007EFC33FCF801
00007efc33fd11ed  sub rsp, 0x08
00007efc33fd11f1  push rax
00007efc33fd11f2  push rcx
00007efc33fd11f3  push rdx
00007efc33fd11f4  push rdi
00007efc33fd11f5  push rsi
00007efc33fd11f6  push r8
00007efc33fd11f8  push r9
00007efc33fd11fa  push r10
00007efc33fd11fc  push r11
00007efc33fd11fe  sub rsp, 0xF0
00007efc33fd1205  vmovaps [rsp], xmm0
00007efc33fd120a  vmovaps [rsp+0x10], xmm2
00007efc33fd1210  vmovaps [rsp+0x20], xmm3
00007efc33fd1216  vmovaps [rsp+0x30], xmm4
00007efc33fd121c  vmovaps [rsp+0x40], xmm5
00007efc33fd1222  vmovaps [rsp+0x50], xmm6
00007efc33fd1228  vmovaps [rsp+0x60], xmm7
00007efc33fd122e  vmovaps [rsp+0x70], xmm8
00007efc33fd1234  vmovaps [rsp+0x80], xmm9
00007efc33fd123d  vmovaps [rsp+0x90], xmm10
00007efc33fd1246  vmovaps [rsp+0xA0], xmm11
00007efc33fd124f  vmovaps [rsp+0xB0], xmm12
00007efc33fd1258  vmovaps [rsp+0xC0], xmm13
00007efc33fd1261  vmovaps [rsp+0xD0], xmm14
00007efc33fd126a  vmovaps [rsp+0xE0], xmm15
00007efc33fd1273  sub rsp, 0x30
00007efc33fd1277  movaps [rsp], xmm1
00007efc33fd127b  movaps [rsp+0x10], xmm13
00007efc33fd1281  movaps [rsp+0x20], xmm2
00007efc33fd1286  lea rdi, [rsp]
00007efc33fd128a  mov esi, 0x00
00007efc33fd128f  mov rax, 0x5D9448894530
00007efc33fd1299  call rax
00007efc33fd129b  movaps xmm1, [rsp]
00007efc33fd129f  add rsp, 0x30
00007efc33fd12a3  vmovaps xmm0, [rsp]
00007efc33fd12a8  vmovaps xmm2, [rsp+0x10]
00007efc33fd12ae  vmovaps xmm3, [rsp+0x20]
00007efc33fd12b4  vmovaps xmm4, [rsp+0x30]
00007efc33fd12ba  vmovaps xmm5, [rsp+0x40]
00007efc33fd12c0  vmovaps xmm6, [rsp+0x50]
00007efc33fd12c6  vmovaps xmm7, [rsp+0x60]
00007efc33fd12cc  vmovaps xmm8, [rsp+0x70]
00007efc33fd12d2  vmovaps xmm9, [rsp+0x80]
00007efc33fd12db  vmovaps xmm10, [rsp+0x90]
00007efc33fd12e4  vmovaps xmm11, [rsp+0xA0]
00007efc33fd12ed  vmovaps xmm12, [rsp+0xB0]
00007efc33fd12f6  vmovaps xmm13, [rsp+0xC0]
00007efc33fd12ff  vmovaps xmm14, [rsp+0xD0]
00007efc33fd1308  vmovaps xmm15, [rsp+0xE0]
00007efc33fd1311  add rsp, 0xF0
00007efc33fd1318  pop r11
00007efc33fd131a  pop r10
00007efc33fd131c  pop r9
00007efc33fd131e  pop r8
00007efc33fd1320  pop rsi
00007efc33fd1321  pop rdi
00007efc33fd1322  pop rdx
00007efc33fd1323  pop rcx
00007efc33fd1324  pop rax
00007efc33fd1325  add rsp, 0x08
00007efc33fd1329  jmp 0x00007EFC33FCF82C
00007efc33fd132e  call 0x00007EFC33E0E760
00007efc33fd1333  jmp 0x00007EFC33FCF839
00007efc33fd1338  sub rsp, 0x08
00007efc33fd133c  push rax
00007efc33fd133d  push rcx
00007efc33fd133e  push rdx
00007efc33fd133f  push rdi
00007efc33fd1340  push rsi
00007efc33fd1341  push r8
00007efc33fd1343  push r9
00007efc33fd1345  push r10
00007efc33fd1347  push r11
00007efc33fd1349  sub rsp, 0xF0
00007efc33fd1350  vmovaps [rsp], xmm0
00007efc33fd1355  vmovaps [rsp+0x10], xmm1
00007efc33fd135b  vmovaps [rsp+0x20], xmm2
00007efc33fd1361  vmovaps [rsp+0x30], xmm3
00007efc33fd1367  vmovaps [rsp+0x40], xmm4
00007efc33fd136d  vmovaps [rsp+0x50], xmm5
00007efc33fd1373  vmovaps [rsp+0x60], xmm6
00007efc33fd1379  vmovaps [rsp+0x70], xmm7
00007efc33fd137f  vmovaps [rsp+0x80], xmm8
00007efc33fd1388  vmovaps [rsp+0x90], xmm9
00007efc33fd1391  vmovaps [rsp+0xA0], xmm10
00007efc33fd139a  vmovaps [rsp+0xB0], xmm11
00007efc33fd13a3  vmovaps [rsp+0xC0], xmm12
00007efc33fd13ac  vmovaps [rsp+0xD0], xmm14
00007efc33fd13b5  vmovaps [rsp+0xE0], xmm15
00007efc33fd13be  sub rsp, 0x30
00007efc33fd13c2  movaps [rsp], xmm13
00007efc33fd13c7  movaps [rsp+0x10], xmm2
00007efc33fd13cc  movaps [rsp+0x20], xmm1
00007efc33fd13d1  lea rdi, [rsp]
00007efc33fd13d5  mov esi, 0x00
00007efc33fd13da  mov rax, 0x5D9448894530
00007efc33fd13e4  call rax
00007efc33fd13e6  movaps xmm13, [rsp]
00007efc33fd13eb  add rsp, 0x30
00007efc33fd13ef  vmovaps xmm0, [rsp]
00007efc33fd13f4  vmovaps xmm1, [rsp+0x10]
00007efc33fd13fa  vmovaps xmm2, [rsp+0x20]
00007efc33fd1400  vmovaps xmm3, [rsp+0x30]
00007efc33fd1406  vmovaps xmm4, [rsp+0x40]
00007efc33fd140c  vmovaps xmm5, [rsp+0x50]
00007efc33fd1412  vmovaps xmm6, [rsp+0x60]
00007efc33fd1418  vmovaps xmm7, [rsp+0x70]
00007efc33fd141e  vmovaps xmm8, [rsp+0x80]
00007efc33fd1427  vmovaps xmm9, [rsp+0x90]
00007efc33fd1430  vmovaps xmm10, [rsp+0xA0]
00007efc33fd1439  vmovaps xmm11, [rsp+0xB0]
00007efc33fd1442  vmovaps xmm12, [rsp+0xC0]
00007efc33fd144b  vmovaps xmm14, [rsp+0xD0]
00007efc33fd1454  vmovaps xmm15, [rsp+0xE0]
00007efc33fd145d  add rsp, 0xF0
00007efc33fd1464  pop r11
00007efc33fd1466  pop r10
00007efc33fd1468  pop r9
00007efc33fd146a  pop r8
00007efc33fd146c  pop rsi
00007efc33fd146d  pop rdi
00007efc33fd146e  pop rdx
00007efc33fd146f  pop rcx
00007efc33fd1470  pop rax
00007efc33fd1471  add rsp, 0x08
00007efc33fd1475  jmp 0x00007EFC33FCF878
00007efc33fd147a  sub rsp, 0x08
00007efc33fd147e  push rax
00007efc33fd147f  push rcx
00007efc33fd1480  push rdx
00007efc33fd1481  push rdi
00007efc33fd1482  push rsi
00007efc33fd1483  push r8
00007efc33fd1485  push r9
00007efc33fd1487  push r10
00007efc33fd1489  push r11
00007efc33fd148b  sub rsp, 0xF0
00007efc33fd1492  vmovaps [rsp], xmm0
00007efc33fd1497  vmovaps [rsp+0x10], xmm2
00007efc33fd149d  vmovaps [rsp+0x20], xmm3
00007efc33fd14a3  vmovaps [rsp+0x30], xmm4
00007efc33fd14a9  vmovaps [rsp+0x40], xmm5
00007efc33fd14af  vmovaps [rsp+0x50], xmm6
00007efc33fd14b5  vmovaps [rsp+0x60], xmm7
00007efc33fd14bb  vmovaps [rsp+0x70], xmm8
00007efc33fd14c1  vmovaps [rsp+0x80], xmm9
00007efc33fd14ca  vmovaps [rsp+0x90], xmm10
00007efc33fd14d3  vmovaps [rsp+0xA0], xmm11
00007efc33fd14dc  vmovaps [rsp+0xB0], xmm12
00007efc33fd14e5  vmovaps [rsp+0xC0], xmm13
00007efc33fd14ee  vmovaps [rsp+0xD0], xmm14
00007efc33fd14f7  vmovaps [rsp+0xE0], xmm15
00007efc33fd1500  sub rsp, 0x30
00007efc33fd1504  movaps [rsp], xmm1
00007efc33fd1508  movaps [rsp+0x10], xmm15
00007efc33fd150e  movaps [rsp+0x20], xmm2
00007efc33fd1513  lea rdi, [rsp]
00007efc33fd1517  mov esi, 0x00
00007efc33fd151c  mov rax, 0x5D9448894530
00007efc33fd1526  call rax
00007efc33fd1528  movaps xmm1, [rsp]
00007efc33fd152c  add rsp, 0x30
00007efc33fd1530  vmovaps xmm0, [rsp]
00007efc33fd1535  vmovaps xmm2, [rsp+0x10]
00007efc33fd153b  vmovaps xmm3, [rsp+0x20]
00007efc33fd1541  vmovaps xmm4, [rsp+0x30]
00007efc33fd1547  vmovaps xmm5, [rsp+0x40]
00007efc33fd154d  vmovaps xmm6, [rsp+0x50]
00007efc33fd1553  vmovaps xmm7, [rsp+0x60]
00007efc33fd1559  vmovaps xmm8, [rsp+0x70]
00007efc33fd155f  vmovaps xmm9, [rsp+0x80]
00007efc33fd1568  vmovaps xmm10, [rsp+0x90]
00007efc33fd1571  vmovaps xmm11, [rsp+0xA0]
00007efc33fd157a  vmovaps xmm12, [rsp+0xB0]
00007efc33fd1583  vmovaps xmm13, [rsp+0xC0]
00007efc33fd158c  vmovaps xmm14, [rsp+0xD0]
00007efc33fd1595  vmovaps xmm15, [rsp+0xE0]
00007efc33fd159e  add rsp, 0xF0
00007efc33fd15a5  pop r11
00007efc33fd15a7  pop r10
00007efc33fd15a9  pop r9
00007efc33fd15ab  pop r8
00007efc33fd15ad  pop rsi
00007efc33fd15ae  pop rdi
00007efc33fd15af  pop rdx
00007efc33fd15b0  pop rcx
00007efc33fd15b1  pop rax
00007efc33fd15b2  add rsp, 0x08
00007efc33fd15b6  jmp 0x00007EFC33FCF8AC
00007efc33fd15bb  sub rsp, 0x08
00007efc33fd15bf  push rax
00007efc33fd15c0  push rcx
00007efc33fd15c1  push rdx
00007efc33fd15c2  push rdi
00007efc33fd15c3  push rsi
00007efc33fd15c4  push r8
00007efc33fd15c6  push r9
00007efc33fd15c8  push r10
00007efc33fd15ca  push r11
00007efc33fd15cc  sub rsp, 0xF0
00007efc33fd15d3  vmovaps [rsp], xmm0
00007efc33fd15d8  vmovaps [rsp+0x10], xmm1
00007efc33fd15de  vmovaps [rsp+0x20], xmm2
00007efc33fd15e4  vmovaps [rsp+0x30], xmm3
00007efc33fd15ea  vmovaps [rsp+0x40], xmm4
00007efc33fd15f0  vmovaps [rsp+0x50], xmm5
00007efc33fd15f6  vmovaps [rsp+0x60], xmm6
00007efc33fd15fc  vmovaps [rsp+0x70], xmm7
00007efc33fd1602  vmovaps [rsp+0x80], xmm8
00007efc33fd160b  vmovaps [rsp+0x90], xmm9
00007efc33fd1614  vmovaps [rsp+0xA0], xmm10
00007efc33fd161d  vmovaps [rsp+0xB0], xmm11
00007efc33fd1626  vmovaps [rsp+0xC0], xmm12
00007efc33fd162f  vmovaps [rsp+0xD0], xmm13
00007efc33fd1638  vmovaps [rsp+0xE0], xmm15
00007efc33fd1641  sub rsp, 0x30
00007efc33fd1645  movaps [rsp], xmm14
00007efc33fd164a  movaps [rsp+0x10], xmm2
00007efc33fd164f  movaps [rsp+0x20], xmm15
00007efc33fd1655  lea rdi, [rsp]
00007efc33fd1659  mov esi, 0x00
00007efc33fd165e  mov rax, 0x5D9448894530
00007efc33fd1668  call rax
00007efc33fd166a  movaps xmm14, [rsp]
00007efc33fd166f  add rsp, 0x30
00007efc33fd1673  vmovaps xmm0, [rsp]
00007efc33fd1678  vmovaps xmm1, [rsp+0x10]
00007efc33fd167e  vmovaps xmm2, [rsp+0x20]
00007efc33fd1684  vmovaps xmm3, [rsp+0x30]
00007efc33fd168a  vmovaps xmm4, [rsp+0x40]
00007efc33fd1690  vmovaps xmm5, [rsp+0x50]
00007efc33fd1696  vmovaps xmm6, [rsp+0x60]
00007efc33fd169c  vmovaps xmm7, [rsp+0x70]
00007efc33fd16a2  vmovaps xmm8, [rsp+0x80]
00007efc33fd16ab  vmovaps xmm9, [rsp+0x90]
00007efc33fd16b4  vmovaps xmm10, [rsp+0xA0]
00007efc33fd16bd  vmovaps xmm11, [rsp+0xB0]
00007efc33fd16c6  vmovaps xmm12, [rsp+0xC0]
00007efc33fd16cf  vmovaps xmm13, [rsp+0xD0]
00007efc33fd16d8  vmovaps xmm15, [rsp+0xE0]
00007efc33fd16e1  add rsp, 0xF0
00007efc33fd16e8  pop r11
00007efc33fd16ea  pop r10
00007efc33fd16ec  pop r9
00007efc33fd16ee  pop r8
00007efc33fd16f0  pop rsi
00007efc33fd16f1  pop rdi
00007efc33fd16f2  pop rdx
00007efc33fd16f3  pop rcx
00007efc33fd16f4  pop rax
00007efc33fd16f5  add rsp, 0x08
00007efc33fd16f9  jmp 0x00007EFC33FCF8E7
00007efc33fd16fe  sub rsp, 0x08
00007efc33fd1702  push rax
00007efc33fd1703  push rcx
00007efc33fd1704  push rdx
00007efc33fd1705  push rdi
00007efc33fd1706  push rsi
00007efc33fd1707  push r8
00007efc33fd1709  push r9
00007efc33fd170b  push r10
00007efc33fd170d  push r11
00007efc33fd170f  sub rsp, 0xF0
00007efc33fd1716  vmovaps [rsp], xmm0
00007efc33fd171b  vmovaps [rsp+0x10], xmm1
00007efc33fd1721  vmovaps [rsp+0x20], xmm2
00007efc33fd1727  vmovaps [rsp+0x30], xmm3
00007efc33fd172d  vmovaps [rsp+0x40], xmm4
00007efc33fd1733  vmovaps [rsp+0x50], xmm5
00007efc33fd1739  vmovaps [rsp+0x60], xmm6
00007efc33fd173f  vmovaps [rsp+0x70], xmm7
00007efc33fd1745  vmovaps [rsp+0x80], xmm8
00007efc33fd174e  vmovaps [rsp+0x90], xmm9
00007efc33fd1757  vmovaps [rsp+0xA0], xmm10
00007efc33fd1760  vmovaps [rsp+0xB0], xmm11
00007efc33fd1769  vmovaps [rsp+0xC0], xmm12
00007efc33fd1772  vmovaps [rsp+0xD0], xmm13
00007efc33fd177b  vmovaps [rsp+0xE0], xmm14
00007efc33fd1784  sub rsp, 0x30
00007efc33fd1788  movaps [rsp], xmm15
00007efc33fd178d  movaps [rsp+0x10], xmm2
00007efc33fd1792  movaps [rsp+0x20], xmm1
00007efc33fd1797  lea rdi, [rsp]
00007efc33fd179b  mov esi, 0x00
00007efc33fd17a0  mov rax, 0x5D9448894530
00007efc33fd17aa  call rax
00007efc33fd17ac  movaps xmm15, [rsp]
00007efc33fd17b1  add rsp, 0x30
00007efc33fd17b5  vmovaps xmm0, [rsp]
00007efc33fd17ba  vmovaps xmm1, [rsp+0x10]
00007efc33fd17c0  vmovaps xmm2, [rsp+0x20]
00007efc33fd17c6  vmovaps xmm3, [rsp+0x30]
00007efc33fd17cc  vmovaps xmm4, [rsp+0x40]
00007efc33fd17d2  vmovaps xmm5, [rsp+0x50]
00007efc33fd17d8  vmovaps xmm6, [rsp+0x60]
00007efc33fd17de  vmovaps xmm7, [rsp+0x70]
00007efc33fd17e4  vmovaps xmm8, [rsp+0x80]
00007efc33fd17ed  vmovaps xmm9, [rsp+0x90]
00007efc33fd17f6  vmovaps xmm10, [rsp+0xA0]
00007efc33fd17ff  vmovaps xmm11, [rsp+0xB0]
00007efc33fd1808  vmovaps xmm12, [rsp+0xC0]
00007efc33fd1811  vmovaps xmm13, [rsp+0xD0]
00007efc33fd181a  vmovaps xmm14, [rsp+0xE0]
00007efc33fd1823  add rsp, 0xF0
00007efc33fd182a  pop r11
00007efc33fd182c  pop r10
00007efc33fd182e  pop r9
00007efc33fd1830  pop r8
00007efc33fd1832  pop rsi
00007efc33fd1833  pop rdi
00007efc33fd1834  pop rdx
00007efc33fd1835  pop rcx
00007efc33fd1836  pop rax
00007efc33fd1837  add rsp, 0x08
00007efc33fd183b  jmp 0x00007EFC33FCF923
00007efc33fd1840  call 0x00007EFC33DFF430
00007efc33fd1845  jmp 0x00007EFC33FCF930
00007efc33fd184a  sub rsp, 0x08
00007efc33fd184e  push rax
00007efc33fd184f  push rcx
00007efc33fd1850  push rdx
00007efc33fd1851  push rdi
00007efc33fd1852  push rsi
00007efc33fd1853  push r8
00007efc33fd1855  push r9
00007efc33fd1857  push r10
00007efc33fd1859  push r11
00007efc33fd185b  sub rsp, 0xF0
00007efc33fd1862  vmovaps [rsp], xmm0
00007efc33fd1867  vmovaps [rsp+0x10], xmm1
00007efc33fd186d  vmovaps [rsp+0x20], xmm3
00007efc33fd1873  vmovaps [rsp+0x30], xmm4
00007efc33fd1879  vmovaps [rsp+0x40], xmm5
00007efc33fd187f  vmovaps [rsp+0x50], xmm6
00007efc33fd1885  vmovaps [rsp+0x60], xmm7
00007efc33fd188b  vmovaps [rsp+0x70], xmm8
00007efc33fd1891  vmovaps [rsp+0x80], xmm9
00007efc33fd189a  vmovaps [rsp+0x90], xmm10
00007efc33fd18a3  vmovaps [rsp+0xA0], xmm11
00007efc33fd18ac  vmovaps [rsp+0xB0], xmm12
00007efc33fd18b5  vmovaps [rsp+0xC0], xmm13
00007efc33fd18be  vmovaps [rsp+0xD0], xmm14
00007efc33fd18c7  vmovaps [rsp+0xE0], xmm15
00007efc33fd18d0  sub rsp, 0x30
00007efc33fd18d4  movaps [rsp], xmm2
00007efc33fd18d8  movaps [rsp+0x10], xmm1
00007efc33fd18dd  movaps [rsp+0x20], xmm14
00007efc33fd18e3  lea rdi, [rsp]
00007efc33fd18e7  mov esi, 0x00
00007efc33fd18ec  mov rax, 0x5D9448894530
00007efc33fd18f6  call rax
00007efc33fd18f8  movaps xmm2, [rsp]
00007efc33fd18fc  add rsp, 0x30
00007efc33fd1900  vmovaps xmm0, [rsp]
00007efc33fd1905  vmovaps xmm1, [rsp+0x10]
00007efc33fd190b  vmovaps xmm3, [rsp+0x20]
00007efc33fd1911  vmovaps xmm4, [rsp+0x30]
00007efc33fd1917  vmovaps xmm5, [rsp+0x40]
00007efc33fd191d  vmovaps xmm6, [rsp+0x50]
00007efc33fd1923  vmovaps xmm7, [rsp+0x60]
00007efc33fd1929  vmovaps xmm8, [rsp+0x70]
00007efc33fd192f  vmovaps xmm9, [rsp+0x80]
00007efc33fd1938  vmovaps xmm10, [rsp+0x90]
00007efc33fd1941  vmovaps xmm11, [rsp+0xA0]
00007efc33fd194a  vmovaps xmm12, [rsp+0xB0]
00007efc33fd1953  vmovaps xmm13, [rsp+0xC0]
00007efc33fd195c  vmovaps xmm14, [rsp+0xD0]
00007efc33fd1965  vmovaps xmm15, [rsp+0xE0]
00007efc33fd196e  add rsp, 0xF0
00007efc33fd1975  pop r11
00007efc33fd1977  pop r10
00007efc33fd1979  pop r9
00007efc33fd197b  pop r8
00007efc33fd197d  pop rsi
00007efc33fd197e  pop rdi
00007efc33fd197f  pop rdx
00007efc33fd1980  pop rcx
00007efc33fd1981  pop rax
00007efc33fd1982  add rsp, 0x08
00007efc33fd1986  jmp 0x00007EFC33FCF96D
00007efc33fd198b  sub rsp, 0x08
00007efc33fd198f  push rax
00007efc33fd1990  push rcx
00007efc33fd1991  push rdx
00007efc33fd1992  push rdi
00007efc33fd1993  push rsi
00007efc33fd1994  push r8
00007efc33fd1996  push r9
00007efc33fd1998  push r10
00007efc33fd199a  push r11
00007efc33fd199c  sub rsp, 0xF0
00007efc33fd19a3  vmovaps [rsp], xmm0
00007efc33fd19a8  vmovaps [rsp+0x10], xmm1
00007efc33fd19ae  vmovaps [rsp+0x20], xmm2
00007efc33fd19b4  vmovaps [rsp+0x30], xmm3
00007efc33fd19ba  vmovaps [rsp+0x40], xmm4
00007efc33fd19c0  vmovaps [rsp+0x50], xmm5
00007efc33fd19c6  vmovaps [rsp+0x60], xmm6
00007efc33fd19cc  vmovaps [rsp+0x70], xmm7
00007efc33fd19d2  vmovaps [rsp+0x80], xmm8
00007efc33fd19db  vmovaps [rsp+0x90], xmm9
00007efc33fd19e4  vmovaps [rsp+0xA0], xmm10
00007efc33fd19ed  vmovaps [rsp+0xB0], xmm11
00007efc33fd19f6  vmovaps [rsp+0xC0], xmm12
00007efc33fd19ff  vmovaps [rsp+0xD0], xmm13
00007efc33fd1a08  vmovaps [rsp+0xE0], xmm14
00007efc33fd1a11  sub rsp, 0x30
00007efc33fd1a15  movaps [rsp], xmm15
00007efc33fd1a1a  movaps [rsp+0x10], xmm14
00007efc33fd1a20  movaps [rsp+0x20], xmm1
00007efc33fd1a25  lea rdi, [rsp]
00007efc33fd1a29  mov esi, 0x00
00007efc33fd1a2e  mov rax, 0x5D9448894530
00007efc33fd1a38  call rax
00007efc33fd1a3a  movaps xmm15, [rsp]
00007efc33fd1a3f  add rsp, 0x30
00007efc33fd1a43  vmovaps xmm0, [rsp]
00007efc33fd1a48  vmovaps xmm1, [rsp+0x10]
00007efc33fd1a4e  vmovaps xmm2, [rsp+0x20]
00007efc33fd1a54  vmovaps xmm3, [rsp+0x30]
00007efc33fd1a5a  vmovaps xmm4, [rsp+0x40]
00007efc33fd1a60  vmovaps xmm5, [rsp+0x50]
00007efc33fd1a66  vmovaps xmm6, [rsp+0x60]
00007efc33fd1a6c  vmovaps xmm7, [rsp+0x70]
00007efc33fd1a72  vmovaps xmm8, [rsp+0x80]
00007efc33fd1a7b  vmovaps xmm9, [rsp+0x90]
00007efc33fd1a84  vmovaps xmm10, [rsp+0xA0]
00007efc33fd1a8d  vmovaps xmm11, [rsp+0xB0]
00007efc33fd1a96  vmovaps xmm12, [rsp+0xC0]
00007efc33fd1a9f  vmovaps xmm13, [rsp+0xD0]
00007efc33fd1aa8  vmovaps xmm14, [rsp+0xE0]
00007efc33fd1ab1  add rsp, 0xF0
00007efc33fd1ab8  pop r11
00007efc33fd1aba  pop r10
00007efc33fd1abc  pop r9
00007efc33fd1abe  pop r8
00007efc33fd1ac0  pop rsi
00007efc33fd1ac1  pop rdi
00007efc33fd1ac2  pop rdx
00007efc33fd1ac3  pop rcx
00007efc33fd1ac4  pop rax
00007efc33fd1ac5  add rsp, 0x08
00007efc33fd1ac9  jmp 0x00007EFC33FCF9E7
00007efc33fd1ace  call 0x00007EFC33DFF430
00007efc33fd1ad3  jmp 0x00007EFC33FCF9F4
00007efc33fd1ad8  sub rsp, 0x08
00007efc33fd1adc  push rax
00007efc33fd1add  push rcx
00007efc33fd1ade  push rdx
00007efc33fd1adf  push rdi
00007efc33fd1ae0  push rsi
00007efc33fd1ae1  push r8
00007efc33fd1ae3  push r9
00007efc33fd1ae5  push r10
00007efc33fd1ae7  push r11
00007efc33fd1ae9  sub rsp, 0xF0
00007efc33fd1af0  vmovaps [rsp], xmm0
00007efc33fd1af5  vmovaps [rsp+0x10], xmm1
00007efc33fd1afb  vmovaps [rsp+0x20], xmm2
00007efc33fd1b01  vmovaps [rsp+0x30], xmm3
00007efc33fd1b07  vmovaps [rsp+0x40], xmm4
00007efc33fd1b0d  vmovaps [rsp+0x50], xmm5
00007efc33fd1b13  vmovaps [rsp+0x60], xmm6
00007efc33fd1b19  vmovaps [rsp+0x70], xmm7
00007efc33fd1b1f  vmovaps [rsp+0x80], xmm8
00007efc33fd1b28  vmovaps [rsp+0x90], xmm9
00007efc33fd1b31  vmovaps [rsp+0xA0], xmm10
00007efc33fd1b3a  vmovaps [rsp+0xB0], xmm11
00007efc33fd1b43  vmovaps [rsp+0xC0], xmm12
00007efc33fd1b4c  vmovaps [rsp+0xD0], xmm13
00007efc33fd1b55  vmovaps [rsp+0xE0], xmm15
00007efc33fd1b5e  sub rsp, 0x30
00007efc33fd1b62  movaps [rsp], xmm14
00007efc33fd1b67  movaps [rsp+0x10], xmm13
00007efc33fd1b6d  movaps [rsp+0x20], xmm1
00007efc33fd1b72  lea rdi, [rsp]
00007efc33fd1b76  mov esi, 0x00
00007efc33fd1b7b  mov rax, 0x5D9448894530
00007efc33fd1b85  call rax
00007efc33fd1b87  movaps xmm14, [rsp]
00007efc33fd1b8c  add rsp, 0x30
00007efc33fd1b90  vmovaps xmm0, [rsp]
00007efc33fd1b95  vmovaps xmm1, [rsp+0x10]
00007efc33fd1b9b  vmovaps xmm2, [rsp+0x20]
00007efc33fd1ba1  vmovaps xmm3, [rsp+0x30]
00007efc33fd1ba7  vmovaps xmm4, [rsp+0x40]
00007efc33fd1bad  vmovaps xmm5, [rsp+0x50]
00007efc33fd1bb3  vmovaps xmm6, [rsp+0x60]
00007efc33fd1bb9  vmovaps xmm7, [rsp+0x70]
00007efc33fd1bbf  vmovaps xmm8, [rsp+0x80]
00007efc33fd1bc8  vmovaps xmm9, [rsp+0x90]
00007efc33fd1bd1  vmovaps xmm10, [rsp+0xA0]
00007efc33fd1bda  vmovaps xmm11, [rsp+0xB0]
00007efc33fd1be3  vmovaps xmm12, [rsp+0xC0]
00007efc33fd1bec  vmovaps xmm13, [rsp+0xD0]
00007efc33fd1bf5  vmovaps xmm15, [rsp+0xE0]
00007efc33fd1bfe  add rsp, 0xF0
00007efc33fd1c05  pop r11
00007efc33fd1c07  pop r10
00007efc33fd1c09  pop r9
00007efc33fd1c0b  pop r8
00007efc33fd1c0d  pop rsi
00007efc33fd1c0e  pop rdi
00007efc33fd1c0f  pop rdx
00007efc33fd1c10  pop rcx
00007efc33fd1c11  pop rax
00007efc33fd1c12  add rsp, 0x08
00007efc33fd1c16  jmp 0x00007EFC33FCFAAF
00007efc33fd1c1b  sub rsp, 0x08
00007efc33fd1c1f  push rax
00007efc33fd1c20  push rcx
00007efc33fd1c21  push rdx
00007efc33fd1c22  push rdi
00007efc33fd1c23  push rsi
00007efc33fd1c24  push r8
00007efc33fd1c26  push r9
00007efc33fd1c28  push r10
00007efc33fd1c2a  push r11
00007efc33fd1c2c  sub rsp, 0xF0
00007efc33fd1c33  vmovaps [rsp], xmm0
00007efc33fd1c38  vmovaps [rsp+0x10], xmm1
00007efc33fd1c3e  vmovaps [rsp+0x20], xmm2
00007efc33fd1c44  vmovaps [rsp+0x30], xmm3
00007efc33fd1c4a  vmovaps [rsp+0x40], xmm4
00007efc33fd1c50  vmovaps [rsp+0x50], xmm5
00007efc33fd1c56  vmovaps [rsp+0x60], xmm6
00007efc33fd1c5c  vmovaps [rsp+0x70], xmm7
00007efc33fd1c62  vmovaps [rsp+0x80], xmm8
00007efc33fd1c6b  vmovaps [rsp+0x90], xmm9
00007efc33fd1c74  vmovaps [rsp+0xA0], xmm10
00007efc33fd1c7d  vmovaps [rsp+0xB0], xmm11
00007efc33fd1c86  vmovaps [rsp+0xC0], xmm12
00007efc33fd1c8f  vmovaps [rsp+0xD0], xmm13
00007efc33fd1c98  vmovaps [rsp+0xE0], xmm14
00007efc33fd1ca1  sub rsp, 0x30
00007efc33fd1ca5  movaps [rsp], xmm15
00007efc33fd1caa  movaps [rsp+0x10], xmm13
00007efc33fd1cb0  movaps [rsp+0x20], xmm1
00007efc33fd1cb5  lea rdi, [rsp]
00007efc33fd1cb9  mov esi, 0x00
00007efc33fd1cbe  mov rax, 0x5D9448894530
00007efc33fd1cc8  call rax
00007efc33fd1cca  movaps xmm15, [rsp]
00007efc33fd1ccf  add rsp, 0x30
00007efc33fd1cd3  vmovaps xmm0, [rsp]
00007efc33fd1cd8  vmovaps xmm1, [rsp+0x10]
00007efc33fd1cde  vmovaps xmm2, [rsp+0x20]
00007efc33fd1ce4  vmovaps xmm3, [rsp+0x30]
00007efc33fd1cea  vmovaps xmm4, [rsp+0x40]
00007efc33fd1cf0  vmovaps xmm5, [rsp+0x50]
00007efc33fd1cf6  vmovaps xmm6, [rsp+0x60]
00007efc33fd1cfc  vmovaps xmm7, [rsp+0x70]
00007efc33fd1d02  vmovaps xmm8, [rsp+0x80]
00007efc33fd1d0b  vmovaps xmm9, [rsp+0x90]
00007efc33fd1d14  vmovaps xmm10, [rsp+0xA0]
00007efc33fd1d1d  vmovaps xmm11, [rsp+0xB0]
00007efc33fd1d26  vmovaps xmm12, [rsp+0xC0]
00007efc33fd1d2f  vmovaps xmm13, [rsp+0xD0]
00007efc33fd1d38  vmovaps xmm14, [rsp+0xE0]
00007efc33fd1d41  add rsp, 0xF0
00007efc33fd1d48  pop r11
00007efc33fd1d4a  pop r10
00007efc33fd1d4c  pop r9
00007efc33fd1d4e  pop r8
00007efc33fd1d50  pop rsi
00007efc33fd1d51  pop rdi
00007efc33fd1d52  pop rdx
00007efc33fd1d53  pop rcx
00007efc33fd1d54  pop rax
00007efc33fd1d55  add rsp, 0x08
00007efc33fd1d59  jmp 0x00007EFC33FCFAEB
00007efc33fd1d5e  call 0x00007EFC33DFF430
00007efc33fd1d63  jmp 0x00007EFC33FCFAF8
00007efc33fd1d68  sub rsp, 0x08
00007efc33fd1d6c  push rax
00007efc33fd1d6d  push rcx
00007efc33fd1d6e  push rdx
00007efc33fd1d6f  push rdi
00007efc33fd1d70  push rsi
00007efc33fd1d71  push r8
00007efc33fd1d73  push r9
00007efc33fd1d75  push r10
00007efc33fd1d77  push r11
00007efc33fd1d79  sub rsp, 0xF0
00007efc33fd1d80  vmovaps [rsp], xmm0
00007efc33fd1d85  vmovaps [rsp+0x10], xmm1
00007efc33fd1d8b  vmovaps [rsp+0x20], xmm2
00007efc33fd1d91  vmovaps [rsp+0x30], xmm3
00007efc33fd1d97  vmovaps [rsp+0x40], xmm4
00007efc33fd1d9d  vmovaps [rsp+0x50], xmm5
00007efc33fd1da3  vmovaps [rsp+0x60], xmm6
00007efc33fd1da9  vmovaps [rsp+0x70], xmm7
00007efc33fd1daf  vmovaps [rsp+0x80], xmm8
00007efc33fd1db8  vmovaps [rsp+0x90], xmm9
00007efc33fd1dc1  vmovaps [rsp+0xA0], xmm10
00007efc33fd1dca  vmovaps [rsp+0xB0], xmm11
00007efc33fd1dd3  vmovaps [rsp+0xC0], xmm12
00007efc33fd1ddc  vmovaps [rsp+0xD0], xmm13
00007efc33fd1de5  vmovaps [rsp+0xE0], xmm15
00007efc33fd1dee  sub rsp, 0x30
00007efc33fd1df2  movaps [rsp], xmm14
00007efc33fd1df7  movaps [rsp+0x10], xmm13
00007efc33fd1dfd  movaps [rsp+0x20], xmm2
00007efc33fd1e02  lea rdi, [rsp]
00007efc33fd1e06  mov esi, 0x00
00007efc33fd1e0b  mov rax, 0x5D9448894530
00007efc33fd1e15  call rax
00007efc33fd1e17  movaps xmm14, [rsp]
00007efc33fd1e1c  add rsp, 0x30
00007efc33fd1e20  vmovaps xmm0, [rsp]
00007efc33fd1e25  vmovaps xmm1, [rsp+0x10]
00007efc33fd1e2b  vmovaps xmm2, [rsp+0x20]
00007efc33fd1e31  vmovaps xmm3, [rsp+0x30]
00007efc33fd1e37  vmovaps xmm4, [rsp+0x40]
00007efc33fd1e3d  vmovaps xmm5, [rsp+0x50]
00007efc33fd1e43  vmovaps xmm6, [rsp+0x60]
00007efc33fd1e49  vmovaps xmm7, [rsp+0x70]
00007efc33fd1e4f  vmovaps xmm8, [rsp+0x80]
00007efc33fd1e58  vmovaps xmm9, [rsp+0x90]
00007efc33fd1e61  vmovaps xmm10, [rsp+0xA0]
00007efc33fd1e6a  vmovaps xmm11, [rsp+0xB0]
00007efc33fd1e73  vmovaps xmm12, [rsp+0xC0]
00007efc33fd1e7c  vmovaps xmm13, [rsp+0xD0]
00007efc33fd1e85  vmovaps xmm15, [rsp+0xE0]
00007efc33fd1e8e  add rsp, 0xF0
00007efc33fd1e95  pop r11
00007efc33fd1e97  pop r10
00007efc33fd1e99  pop r9
00007efc33fd1e9b  pop r8
00007efc33fd1e9d  pop rsi
00007efc33fd1e9e  pop rdi
00007efc33fd1e9f  pop rdx
00007efc33fd1ea0  pop rcx
00007efc33fd1ea1  pop rax
00007efc33fd1ea2  add rsp, 0x08
00007efc33fd1ea6  jmp 0x00007EFC33FCFB24
00007efc33fd1eab  sub rsp, 0x08
00007efc33fd1eaf  push rax
00007efc33fd1eb0  push rcx
00007efc33fd1eb1  push rdx
00007efc33fd1eb2  push rdi
00007efc33fd1eb3  push rsi
00007efc33fd1eb4  push r8
00007efc33fd1eb6  push r9
00007efc33fd1eb8  push r10
00007efc33fd1eba  push r11
00007efc33fd1ebc  sub rsp, 0xF0
00007efc33fd1ec3  vmovaps [rsp], xmm0
00007efc33fd1ec8  vmovaps [rsp+0x10], xmm2
00007efc33fd1ece  vmovaps [rsp+0x20], xmm3
00007efc33fd1ed4  vmovaps [rsp+0x30], xmm4
00007efc33fd1eda  vmovaps [rsp+0x40], xmm5
00007efc33fd1ee0  vmovaps [rsp+0x50], xmm6
00007efc33fd1ee6  vmovaps [rsp+0x60], xmm7
00007efc33fd1eec  vmovaps [rsp+0x70], xmm8
00007efc33fd1ef2  vmovaps [rsp+0x80], xmm9
00007efc33fd1efb  vmovaps [rsp+0x90], xmm10
00007efc33fd1f04  vmovaps [rsp+0xA0], xmm11
00007efc33fd1f0d  vmovaps [rsp+0xB0], xmm12
00007efc33fd1f16  vmovaps [rsp+0xC0], xmm13
00007efc33fd1f1f  vmovaps [rsp+0xD0], xmm14
00007efc33fd1f28  vmovaps [rsp+0xE0], xmm15
00007efc33fd1f31  sub rsp, 0x30
00007efc33fd1f35  movaps [rsp], xmm1
00007efc33fd1f39  movaps [rsp+0x10], xmm13
00007efc33fd1f3f  movaps [rsp+0x20], xmm2
00007efc33fd1f44  lea rdi, [rsp]
00007efc33fd1f48  mov esi, 0x00
00007efc33fd1f4d  mov rax, 0x5D9448894530
00007efc33fd1f57  call rax
00007efc33fd1f59  movaps xmm1, [rsp]
00007efc33fd1f5d  add rsp, 0x30
00007efc33fd1f61  vmovaps xmm0, [rsp]
00007efc33fd1f66  vmovaps xmm2, [rsp+0x10]
00007efc33fd1f6c  vmovaps xmm3, [rsp+0x20]
00007efc33fd1f72  vmovaps xmm4, [rsp+0x30]
00007efc33fd1f78  vmovaps xmm5, [rsp+0x40]
00007efc33fd1f7e  vmovaps xmm6, [rsp+0x50]
00007efc33fd1f84  vmovaps xmm7, [rsp+0x60]
00007efc33fd1f8a  vmovaps xmm8, [rsp+0x70]
00007efc33fd1f90  vmovaps xmm9, [rsp+0x80]
00007efc33fd1f99  vmovaps xmm10, [rsp+0x90]
00007efc33fd1fa2  vmovaps xmm11, [rsp+0xA0]
00007efc33fd1fab  vmovaps xmm12, [rsp+0xB0]
00007efc33fd1fb4  vmovaps xmm13, [rsp+0xC0]
00007efc33fd1fbd  vmovaps xmm14, [rsp+0xD0]
00007efc33fd1fc6  vmovaps xmm15, [rsp+0xE0]
00007efc33fd1fcf  add rsp, 0xF0
00007efc33fd1fd6  pop r11
00007efc33fd1fd8  pop r10
00007efc33fd1fda  pop r9
00007efc33fd1fdc  pop r8
00007efc33fd1fde  pop rsi
00007efc33fd1fdf  pop rdi
00007efc33fd1fe0  pop rdx
00007efc33fd1fe1  pop rcx
00007efc33fd1fe2  pop rax
00007efc33fd1fe3  add rsp, 0x08
00007efc33fd1fe7  jmp 0x00007EFC33FCFB52
00007efc33fd1fec  sub rsp, 0x08
00007efc33fd1ff0  push rax
00007efc33fd1ff1  push rcx
00007efc33fd1ff2  push rdx
00007efc33fd1ff3  push rdi
00007efc33fd1ff4  push rsi
00007efc33fd1ff5  push r8
00007efc33fd1ff7  push r9
00007efc33fd1ff9  push r10
00007efc33fd1ffb  push r11
00007efc33fd1ffd  sub rsp, 0xF0
00007efc33fd2004  vmovaps [rsp], xmm0
00007efc33fd2009  vmovaps [rsp+0x10], xmm1
00007efc33fd200f  vmovaps [rsp+0x20], xmm3
00007efc33fd2015  vmovaps [rsp+0x30], xmm4
00007efc33fd201b  vmovaps [rsp+0x40], xmm5
00007efc33fd2021  vmovaps [rsp+0x50], xmm6
00007efc33fd2027  vmovaps [rsp+0x60], xmm7
00007efc33fd202d  vmovaps [rsp+0x70], xmm8
00007efc33fd2033  vmovaps [rsp+0x80], xmm9
00007efc33fd203c  vmovaps [rsp+0x90], xmm10
00007efc33fd2045  vmovaps [rsp+0xA0], xmm11
00007efc33fd204e  vmovaps [rsp+0xB0], xmm12
00007efc33fd2057  vmovaps [rsp+0xC0], xmm13
00007efc33fd2060  vmovaps [rsp+0xD0], xmm14
00007efc33fd2069  vmovaps [rsp+0xE0], xmm15
00007efc33fd2072  sub rsp, 0x30
00007efc33fd2076  movaps [rsp], xmm2
00007efc33fd207a  movaps [rsp+0x10], xmm1
00007efc33fd207f  movaps [rsp+0x20], xmm13
00007efc33fd2085  lea rdi, [rsp]
00007efc33fd2089  mov esi, 0x00
00007efc33fd208e  mov rax, 0x5D9448894530
00007efc33fd2098  call rax
00007efc33fd209a  movaps xmm2, [rsp]
00007efc33fd209e  add rsp, 0x30
00007efc33fd20a2  vmovaps xmm0, [rsp]
00007efc33fd20a7  vmovaps xmm1, [rsp+0x10]
00007efc33fd20ad  vmovaps xmm3, [rsp+0x20]
00007efc33fd20b3  vmovaps xmm4, [rsp+0x30]
00007efc33fd20b9  vmovaps xmm5, [rsp+0x40]
00007efc33fd20bf  vmovaps xmm6, [rsp+0x50]
00007efc33fd20c5  vmovaps xmm7, [rsp+0x60]
00007efc33fd20cb  vmovaps xmm8, [rsp+0x70]
00007efc33fd20d1  vmovaps xmm9, [rsp+0x80]
00007efc33fd20da  vmovaps xmm10, [rsp+0x90]
00007efc33fd20e3  vmovaps xmm11, [rsp+0xA0]
00007efc33fd20ec  vmovaps xmm12, [rsp+0xB0]
00007efc33fd20f5  vmovaps xmm13, [rsp+0xC0]
00007efc33fd20fe  vmovaps xmm14, [rsp+0xD0]
00007efc33fd2107  vmovaps xmm15, [rsp+0xE0]
00007efc33fd2110  add rsp, 0xF0
00007efc33fd2117  pop r11
00007efc33fd2119  pop r10
00007efc33fd211b  pop r9
00007efc33fd211d  pop r8
00007efc33fd211f  pop rsi
00007efc33fd2120  pop rdi
00007efc33fd2121  pop rdx
00007efc33fd2122  pop rcx
00007efc33fd2123  pop rax
00007efc33fd2124  add rsp, 0x08
00007efc33fd2128  jmp 0x00007EFC33FCFBAB
00007efc33fd212d  call 0x00007EFC33DFF430
00007efc33fd2132  jmp 0x00007EFC33FCFBB8
00007efc33fd2137  sub rsp, 0x08
00007efc33fd213b  push rax
00007efc33fd213c  push rcx
00007efc33fd213d  push rdx
00007efc33fd213e  push rdi
00007efc33fd213f  push rsi
00007efc33fd2140  push r8
00007efc33fd2142  push r9
00007efc33fd2144  push r10
00007efc33fd2146  push r11
00007efc33fd2148  sub rsp, 0xF0
00007efc33fd214f  vmovaps [rsp], xmm0
00007efc33fd2154  vmovaps [rsp+0x10], xmm1
00007efc33fd215a  vmovaps [rsp+0x20], xmm2
00007efc33fd2160  vmovaps [rsp+0x30], xmm3
00007efc33fd2166  vmovaps [rsp+0x40], xmm4
00007efc33fd216c  vmovaps [rsp+0x50], xmm5
00007efc33fd2172  vmovaps [rsp+0x60], xmm6
00007efc33fd2178  vmovaps [rsp+0x70], xmm7
00007efc33fd217e  vmovaps [rsp+0x80], xmm8
00007efc33fd2187  vmovaps [rsp+0x90], xmm9
00007efc33fd2190  vmovaps [rsp+0xA0], xmm10
00007efc33fd2199  vmovaps [rsp+0xB0], xmm11
00007efc33fd21a2  vmovaps [rsp+0xC0], xmm12
00007efc33fd21ab  vmovaps [rsp+0xD0], xmm13
00007efc33fd21b4  vmovaps [rsp+0xE0], xmm14
00007efc33fd21bd  sub rsp, 0x30
00007efc33fd21c1  movaps [rsp], xmm15
00007efc33fd21c6  movaps [rsp+0x10], xmm13
00007efc33fd21cc  movaps [rsp+0x20], xmm1
00007efc33fd21d1  lea rdi, [rsp]
00007efc33fd21d5  mov esi, 0x00
00007efc33fd21da  mov rax, 0x5D9448894530
00007efc33fd21e4  call rax
00007efc33fd21e6  movaps xmm15, [rsp]
00007efc33fd21eb  add rsp, 0x30
00007efc33fd21ef  vmovaps xmm0, [rsp]
00007efc33fd21f4  vmovaps xmm1, [rsp+0x10]
00007efc33fd21fa  vmovaps xmm2, [rsp+0x20]
00007efc33fd2200  vmovaps xmm3, [rsp+0x30]
00007efc33fd2206  vmovaps xmm4, [rsp+0x40]
00007efc33fd220c  vmovaps xmm5, [rsp+0x50]
00007efc33fd2212  vmovaps xmm6, [rsp+0x60]
00007efc33fd2218  vmovaps xmm7, [rsp+0x70]
00007efc33fd221e  vmovaps xmm8, [rsp+0x80]
00007efc33fd2227  vmovaps xmm9, [rsp+0x90]
00007efc33fd2230  vmovaps xmm10, [rsp+0xA0]
00007efc33fd2239  vmovaps xmm11, [rsp+0xB0]
00007efc33fd2242  vmovaps xmm12, [rsp+0xC0]
00007efc33fd224b  vmovaps xmm13, [rsp+0xD0]
00007efc33fd2254  vmovaps xmm14, [rsp+0xE0]
00007efc33fd225d  add rsp, 0xF0
00007efc33fd2264  pop r11
00007efc33fd2266  pop r10
00007efc33fd2268  pop r9
00007efc33fd226a  pop r8
00007efc33fd226c  pop rsi
00007efc33fd226d  pop rdi
00007efc33fd226e  pop rdx
00007efc33fd226f  pop rcx
00007efc33fd2270  pop rax
00007efc33fd2271  add rsp, 0x08
00007efc33fd2275  jmp 0x00007EFC33FCFBF7
00007efc33fd227a  sub rsp, 0x08
00007efc33fd227e  push rax
00007efc33fd227f  push rcx
00007efc33fd2280  push rdx
00007efc33fd2281  push rdi
00007efc33fd2282  push rsi
00007efc33fd2283  push r8
00007efc33fd2285  push r9
00007efc33fd2287  push r10
00007efc33fd2289  push r11
00007efc33fd228b  sub rsp, 0xF0
00007efc33fd2292  vmovaps [rsp], xmm0
00007efc33fd2297  vmovaps [rsp+0x10], xmm1
00007efc33fd229d  vmovaps [rsp+0x20], xmm2
00007efc33fd22a3  vmovaps [rsp+0x30], xmm3
00007efc33fd22a9  vmovaps [rsp+0x40], xmm4
00007efc33fd22af  vmovaps [rsp+0x50], xmm5
00007efc33fd22b5  vmovaps [rsp+0x60], xmm6
00007efc33fd22bb  vmovaps [rsp+0x70], xmm7
00007efc33fd22c1  vmovaps [rsp+0x80], xmm8
00007efc33fd22ca  vmovaps [rsp+0x90], xmm9
00007efc33fd22d3  vmovaps [rsp+0xA0], xmm10
00007efc33fd22dc  vmovaps [rsp+0xB0], xmm11
00007efc33fd22e5  vmovaps [rsp+0xC0], xmm12
00007efc33fd22ee  vmovaps [rsp+0xD0], xmm13
00007efc33fd22f7  vmovaps [rsp+0xE0], xmm15
00007efc33fd2300  sub rsp, 0x30
00007efc33fd2304  movaps [rsp], xmm14
00007efc33fd2309  movaps [rsp+0x10], xmm11
00007efc33fd230f  movaps [rsp+0x20], xmm1
00007efc33fd2314  lea rdi, [rsp]
00007efc33fd2318  mov esi, 0x00
00007efc33fd231d  mov rax, 0x5D9448894530
00007efc33fd2327  call rax
00007efc33fd2329  movaps xmm14, [rsp]
00007efc33fd232e  add rsp, 0x30
00007efc33fd2332  vmovaps xmm0, [rsp]
00007efc33fd2337  vmovaps xmm1, [rsp+0x10]
00007efc33fd233d  vmovaps xmm2, [rsp+0x20]
00007efc33fd2343  vmovaps xmm3, [rsp+0x30]
00007efc33fd2349  vmovaps xmm4, [rsp+0x40]
00007efc33fd234f  vmovaps xmm5, [rsp+0x50]
00007efc33fd2355  vmovaps xmm6, [rsp+0x60]
00007efc33fd235b  vmovaps xmm7, [rsp+0x70]
00007efc33fd2361  vmovaps xmm8, [rsp+0x80]
00007efc33fd236a  vmovaps xmm9, [rsp+0x90]
00007efc33fd2373  vmovaps xmm10, [rsp+0xA0]
00007efc33fd237c  vmovaps xmm11, [rsp+0xB0]
00007efc33fd2385  vmovaps xmm12, [rsp+0xC0]
00007efc33fd238e  vmovaps xmm13, [rsp+0xD0]
00007efc33fd2397  vmovaps xmm15, [rsp+0xE0]
00007efc33fd23a0  add rsp, 0xF0
00007efc33fd23a7  pop r11
00007efc33fd23a9  pop r10
00007efc33fd23ab  pop r9
00007efc33fd23ad  pop r8
00007efc33fd23af  pop rsi
00007efc33fd23b0  pop rdi
00007efc33fd23b1  pop rdx
00007efc33fd23b2  pop rcx
00007efc33fd23b3  pop rax
00007efc33fd23b4  add rsp, 0x08
00007efc33fd23b8  jmp 0x00007EFC33FCFC21
00007efc33fd23bd  sub rsp, 0x08
00007efc33fd23c1  push rax
00007efc33fd23c2  push rcx
00007efc33fd23c3  push rdx
00007efc33fd23c4  push rdi
00007efc33fd23c5  push rsi
00007efc33fd23c6  push r8
00007efc33fd23c8  push r9
00007efc33fd23ca  push r10
00007efc33fd23cc  push r11
00007efc33fd23ce  sub rsp, 0xF0
00007efc33fd23d5  vmovaps [rsp], xmm0
00007efc33fd23da  vmovaps [rsp+0x10], xmm1
00007efc33fd23e0  vmovaps [rsp+0x20], xmm2
00007efc33fd23e6  vmovaps [rsp+0x30], xmm3
00007efc33fd23ec  vmovaps [rsp+0x40], xmm4
00007efc33fd23f2  vmovaps [rsp+0x50], xmm5
00007efc33fd23f8  vmovaps [rsp+0x60], xmm6
00007efc33fd23fe  vmovaps [rsp+0x70], xmm7
00007efc33fd2404  vmovaps [rsp+0x80], xmm8
00007efc33fd240d  vmovaps [rsp+0x90], xmm9
00007efc33fd2416  vmovaps [rsp+0xA0], xmm10
00007efc33fd241f  vmovaps [rsp+0xB0], xmm11
00007efc33fd2428  vmovaps [rsp+0xC0], xmm12
00007efc33fd2431  vmovaps [rsp+0xD0], xmm14
00007efc33fd243a  vmovaps [rsp+0xE0], xmm15
00007efc33fd2443  sub rsp, 0x30
00007efc33fd2447  movaps [rsp], xmm13
00007efc33fd244c  movaps [rsp+0x10], xmm11
00007efc33fd2452  movaps [rsp+0x20], xmm1
00007efc33fd2457  lea rdi, [rsp]
00007efc33fd245b  mov esi, 0x00
00007efc33fd2460  mov rax, 0x5D9448894530
00007efc33fd246a  call rax
00007efc33fd246c  movaps xmm13, [rsp]
00007efc33fd2471  add rsp, 0x30
00007efc33fd2475  vmovaps xmm0, [rsp]
00007efc33fd247a  vmovaps xmm1, [rsp+0x10]
00007efc33fd2480  vmovaps xmm2, [rsp+0x20]
00007efc33fd2486  vmovaps xmm3, [rsp+0x30]
00007efc33fd248c  vmovaps xmm4, [rsp+0x40]
00007efc33fd2492  vmovaps xmm5, [rsp+0x50]
00007efc33fd2498  vmovaps xmm6, [rsp+0x60]
00007efc33fd249e  vmovaps xmm7, [rsp+0x70]
00007efc33fd24a4  vmovaps xmm8, [rsp+0x80]
00007efc33fd24ad  vmovaps xmm9, [rsp+0x90]
00007efc33fd24b6  vmovaps xmm10, [rsp+0xA0]
00007efc33fd24bf  vmovaps xmm11, [rsp+0xB0]
00007efc33fd24c8  vmovaps xmm12, [rsp+0xC0]
00007efc33fd24d1  vmovaps xmm14, [rsp+0xD0]
00007efc33fd24da  vmovaps xmm15, [rsp+0xE0]
00007efc33fd24e3  add rsp, 0xF0
00007efc33fd24ea  pop r11
00007efc33fd24ec  pop r10
00007efc33fd24ee  pop r9
00007efc33fd24f0  pop r8
00007efc33fd24f2  pop rsi
00007efc33fd24f3  pop rdi
00007efc33fd24f4  pop rdx
00007efc33fd24f5  pop rcx
00007efc33fd24f6  pop rax
00007efc33fd24f7  add rsp, 0x08
00007efc33fd24fb  jmp 0x00007EFC33FCFC76
00007efc33fd2500  call 0x00007EFC33DFF430
00007efc33fd2505  jmp 0x00007EFC33FCFC83
00007efc33fd250a  sub rsp, 0x08
00007efc33fd250e  push rax
00007efc33fd250f  push rcx
00007efc33fd2510  push rdx
00007efc33fd2511  push rdi
00007efc33fd2512  push rsi
00007efc33fd2513  push r8
00007efc33fd2515  push r9
00007efc33fd2517  push r10
00007efc33fd2519  push r11
00007efc33fd251b  sub rsp, 0xF0
00007efc33fd2522  vmovaps [rsp], xmm0
00007efc33fd2527  vmovaps [rsp+0x10], xmm1
00007efc33fd252d  vmovaps [rsp+0x20], xmm2
00007efc33fd2533  vmovaps [rsp+0x30], xmm3
00007efc33fd2539  vmovaps [rsp+0x40], xmm4
00007efc33fd253f  vmovaps [rsp+0x50], xmm5
00007efc33fd2545  vmovaps [rsp+0x60], xmm6
00007efc33fd254b  vmovaps [rsp+0x70], xmm7
00007efc33fd2551  vmovaps [rsp+0x80], xmm8
00007efc33fd255a  vmovaps [rsp+0x90], xmm9
00007efc33fd2563  vmovaps [rsp+0xA0], xmm10
00007efc33fd256c  vmovaps [rsp+0xB0], xmm11
00007efc33fd2575  vmovaps [rsp+0xC0], xmm12
00007efc33fd257e  vmovaps [rsp+0xD0], xmm13
00007efc33fd2587  vmovaps [rsp+0xE0], xmm14
00007efc33fd2590  sub rsp, 0x30
00007efc33fd2594  movaps [rsp], xmm15
00007efc33fd2599  movaps [rsp+0x10], xmm11
00007efc33fd259f  movaps [rsp+0x20], xmm1
00007efc33fd25a4  lea rdi, [rsp]
00007efc33fd25a8  mov esi, 0x00
00007efc33fd25ad  mov rax, 0x5D9448894530
00007efc33fd25b7  call rax
00007efc33fd25b9  movaps xmm15, [rsp]
00007efc33fd25be  add rsp, 0x30
00007efc33fd25c2  vmovaps xmm0, [rsp]
00007efc33fd25c7  vmovaps xmm1, [rsp+0x10]
00007efc33fd25cd  vmovaps xmm2, [rsp+0x20]
00007efc33fd25d3  vmovaps xmm3, [rsp+0x30]
00007efc33fd25d9  vmovaps xmm4, [rsp+0x40]
00007efc33fd25df  vmovaps xmm5, [rsp+0x50]
00007efc33fd25e5  vmovaps xmm6, [rsp+0x60]
00007efc33fd25eb  vmovaps xmm7, [rsp+0x70]
00007efc33fd25f1  vmovaps xmm8, [rsp+0x80]
00007efc33fd25fa  vmovaps xmm9, [rsp+0x90]
00007efc33fd2603  vmovaps xmm10, [rsp+0xA0]
00007efc33fd260c  vmovaps xmm11, [rsp+0xB0]
00007efc33fd2615  vmovaps xmm12, [rsp+0xC0]
00007efc33fd261e  vmovaps xmm13, [rsp+0xD0]
00007efc33fd2627  vmovaps xmm14, [rsp+0xE0]
00007efc33fd2630  add rsp, 0xF0
00007efc33fd2637  pop r11
00007efc33fd2639  pop r10
00007efc33fd263b  pop r9
00007efc33fd263d  pop r8
00007efc33fd263f  pop rsi
00007efc33fd2640  pop rdi
00007efc33fd2641  pop rdx
00007efc33fd2642  pop rcx
00007efc33fd2643  pop rax
00007efc33fd2644  add rsp, 0x08
00007efc33fd2648  jmp 0x00007EFC33FCFCBC
00007efc33fd264d  sub rsp, 0x08
00007efc33fd2651  push rax
00007efc33fd2652  push rcx
00007efc33fd2653  push rdx
00007efc33fd2654  push rdi
00007efc33fd2655  push rsi
00007efc33fd2656  push r8
00007efc33fd2658  push r9
00007efc33fd265a  push r10
00007efc33fd265c  push r11
00007efc33fd265e  sub rsp, 0xF0
00007efc33fd2665  vmovaps [rsp], xmm0
00007efc33fd266a  vmovaps [rsp+0x10], xmm1
00007efc33fd2670  vmovaps [rsp+0x20], xmm2
00007efc33fd2676  vmovaps [rsp+0x30], xmm3
00007efc33fd267c  vmovaps [rsp+0x40], xmm4
00007efc33fd2682  vmovaps [rsp+0x50], xmm5
00007efc33fd2688  vmovaps [rsp+0x60], xmm6
00007efc33fd268e  vmovaps [rsp+0x70], xmm7
00007efc33fd2694  vmovaps [rsp+0x80], xmm8
00007efc33fd269d  vmovaps [rsp+0x90], xmm9
00007efc33fd26a6  vmovaps [rsp+0xA0], xmm10
00007efc33fd26af  vmovaps [rsp+0xB0], xmm12
00007efc33fd26b8  vmovaps [rsp+0xC0], xmm13
00007efc33fd26c1  vmovaps [rsp+0xD0], xmm14
00007efc33fd26ca  vmovaps [rsp+0xE0], xmm15
00007efc33fd26d3  sub rsp, 0x30
00007efc33fd26d7  movaps [rsp], xmm11
00007efc33fd26dc  movaps [rsp+0x10], xmm6
00007efc33fd26e1  movaps [rsp+0x20], xmm14
00007efc33fd26e7  lea rdi, [rsp]
00007efc33fd26eb  mov esi, 0x00
00007efc33fd26f0  mov rax, 0x5D9448894530
00007efc33fd26fa  call rax
00007efc33fd26fc  movaps xmm11, [rsp]
00007efc33fd2701  add rsp, 0x30
00007efc33fd2705  vmovaps xmm0, [rsp]
00007efc33fd270a  vmovaps xmm1, [rsp+0x10]
00007efc33fd2710  vmovaps xmm2, [rsp+0x20]
00007efc33fd2716  vmovaps xmm3, [rsp+0x30]
00007efc33fd271c  vmovaps xmm4, [rsp+0x40]
00007efc33fd2722  vmovaps xmm5, [rsp+0x50]
00007efc33fd2728  vmovaps xmm6, [rsp+0x60]
00007efc33fd272e  vmovaps xmm7, [rsp+0x70]
00007efc33fd2734  vmovaps xmm8, [rsp+0x80]
00007efc33fd273d  vmovaps xmm9, [rsp+0x90]
00007efc33fd2746  vmovaps xmm10, [rsp+0xA0]
00007efc33fd274f  vmovaps xmm12, [rsp+0xB0]
00007efc33fd2758  vmovaps xmm13, [rsp+0xC0]
00007efc33fd2761  vmovaps xmm14, [rsp+0xD0]
00007efc33fd276a  vmovaps xmm15, [rsp+0xE0]
00007efc33fd2773  add rsp, 0xF0
00007efc33fd277a  pop r11
00007efc33fd277c  pop r10
00007efc33fd277e  pop r9
00007efc33fd2780  pop r8
00007efc33fd2782  pop rsi
00007efc33fd2783  pop rdi
00007efc33fd2784  pop rdx
00007efc33fd2785  pop rcx
00007efc33fd2786  pop rax
00007efc33fd2787  add rsp, 0x08
00007efc33fd278b  jmp 0x00007EFC33FCFD34
00007efc33fd2790  call 0x00007EFC33DFF430
00007efc33fd2795  jmp 0x00007EFC33FCFD3E
00007efc33fd279a  sub rsp, 0x08
00007efc33fd279e  push rax
00007efc33fd279f  push rcx
00007efc33fd27a0  push rdx
00007efc33fd27a1  push rdi
00007efc33fd27a2  push rsi
00007efc33fd27a3  push r8
00007efc33fd27a5  push r9
00007efc33fd27a7  push r10
00007efc33fd27a9  push r11
00007efc33fd27ab  sub rsp, 0xF0
00007efc33fd27b2  vmovaps [rsp], xmm0
00007efc33fd27b7  vmovaps [rsp+0x10], xmm1
00007efc33fd27bd  vmovaps [rsp+0x20], xmm2
00007efc33fd27c3  vmovaps [rsp+0x30], xmm3
00007efc33fd27c9  vmovaps [rsp+0x40], xmm4
00007efc33fd27cf  vmovaps [rsp+0x50], xmm5
00007efc33fd27d5  vmovaps [rsp+0x60], xmm6
00007efc33fd27db  vmovaps [rsp+0x70], xmm7
00007efc33fd27e1  vmovaps [rsp+0x80], xmm8
00007efc33fd27ea  vmovaps [rsp+0x90], xmm9
00007efc33fd27f3  vmovaps [rsp+0xA0], xmm10
00007efc33fd27fc  vmovaps [rsp+0xB0], xmm11
00007efc33fd2805  vmovaps [rsp+0xC0], xmm12
00007efc33fd280e  vmovaps [rsp+0xD0], xmm13
00007efc33fd2817  vmovaps [rsp+0xE0], xmm15
00007efc33fd2820  sub rsp, 0x30
00007efc33fd2824  movaps [rsp], xmm14
00007efc33fd2829  movaps [rsp+0x10], xmm6
00007efc33fd282e  movaps [rsp+0x20], xmm2
00007efc33fd2833  lea rdi, [rsp]
00007efc33fd2837  mov esi, 0x00
00007efc33fd283c  mov rax, 0x5D9448894530
00007efc33fd2846  call rax
00007efc33fd2848  movaps xmm14, [rsp]
00007efc33fd284d  add rsp, 0x30
00007efc33fd2851  vmovaps xmm0, [rsp]
00007efc33fd2856  vmovaps xmm1, [rsp+0x10]
00007efc33fd285c  vmovaps xmm2, [rsp+0x20]
00007efc33fd2862  vmovaps xmm3, [rsp+0x30]
00007efc33fd2868  vmovaps xmm4, [rsp+0x40]
00007efc33fd286e  vmovaps xmm5, [rsp+0x50]
00007efc33fd2874  vmovaps xmm6, [rsp+0x60]
00007efc33fd287a  vmovaps xmm7, [rsp+0x70]
00007efc33fd2880  vmovaps xmm8, [rsp+0x80]
00007efc33fd2889  vmovaps xmm9, [rsp+0x90]
00007efc33fd2892  vmovaps xmm10, [rsp+0xA0]
00007efc33fd289b  vmovaps xmm11, [rsp+0xB0]
00007efc33fd28a4  vmovaps xmm12, [rsp+0xC0]
00007efc33fd28ad  vmovaps xmm13, [rsp+0xD0]
00007efc33fd28b6  vmovaps xmm15, [rsp+0xE0]
00007efc33fd28bf  add rsp, 0xF0
00007efc33fd28c6  pop r11
00007efc33fd28c8  pop r10
00007efc33fd28ca  pop r9
00007efc33fd28cc  pop r8
00007efc33fd28ce  pop rsi
00007efc33fd28cf  pop rdi
00007efc33fd28d0  pop rdx
00007efc33fd28d1  pop rcx
00007efc33fd28d2  pop rax
00007efc33fd28d3  add rsp, 0x08
00007efc33fd28d7  jmp 0x00007EFC33FCFD72
00007efc33fd28dc  sub rsp, 0x08
00007efc33fd28e0  push rax
00007efc33fd28e1  push rcx
00007efc33fd28e2  push rdx
00007efc33fd28e3  push rdi
00007efc33fd28e4  push rsi
00007efc33fd28e5  push r8
00007efc33fd28e7  push r9
00007efc33fd28e9  push r10
00007efc33fd28eb  push r11
00007efc33fd28ed  sub rsp, 0xF0
00007efc33fd28f4  vmovaps [rsp], xmm0
00007efc33fd28f9  vmovaps [rsp+0x10], xmm1
00007efc33fd28ff  vmovaps [rsp+0x20], xmm2
00007efc33fd2905  vmovaps [rsp+0x30], xmm3
00007efc33fd290b  vmovaps [rsp+0x40], xmm4
00007efc33fd2911  vmovaps [rsp+0x50], xmm5
00007efc33fd2917  vmovaps [rsp+0x60], xmm7
00007efc33fd291d  vmovaps [rsp+0x70], xmm8
00007efc33fd2923  vmovaps [rsp+0x80], xmm9
00007efc33fd292c  vmovaps [rsp+0x90], xmm10
00007efc33fd2935  vmovaps [rsp+0xA0], xmm11
00007efc33fd293e  vmovaps [rsp+0xB0], xmm12
00007efc33fd2947  vmovaps [rsp+0xC0], xmm13
00007efc33fd2950  vmovaps [rsp+0xD0], xmm14
00007efc33fd2959  vmovaps [rsp+0xE0], xmm15
00007efc33fd2962  sub rsp, 0x30
00007efc33fd2966  movaps [rsp], xmm6
00007efc33fd296a  movaps [rsp+0x10], xmm5
00007efc33fd296f  movaps [rsp+0x20], xmm1
00007efc33fd2974  lea rdi, [rsp]
00007efc33fd2978  mov esi, 0x00
00007efc33fd297d  mov rax, 0x5D9448894530
00007efc33fd2987  call rax
00007efc33fd2989  movaps xmm6, [rsp]
00007efc33fd298d  add rsp, 0x30
00007efc33fd2991  vmovaps xmm0, [rsp]
00007efc33fd2996  vmovaps xmm1, [rsp+0x10]
00007efc33fd299c  vmovaps xmm2, [rsp+0x20]
00007efc33fd29a2  vmovaps xmm3, [rsp+0x30]
00007efc33fd29a8  vmovaps xmm4, [rsp+0x40]
00007efc33fd29ae  vmovaps xmm5, [rsp+0x50]
00007efc33fd29b4  vmovaps xmm7, [rsp+0x60]
00007efc33fd29ba  vmovaps xmm8, [rsp+0x70]
00007efc33fd29c0  vmovaps xmm9, [rsp+0x80]
00007efc33fd29c9  vmovaps xmm10, [rsp+0x90]
00007efc33fd29d2  vmovaps xmm11, [rsp+0xA0]
00007efc33fd29db  vmovaps xmm12, [rsp+0xB0]
00007efc33fd29e4  vmovaps xmm13, [rsp+0xC0]
00007efc33fd29ed  vmovaps xmm14, [rsp+0xD0]
00007efc33fd29f6  vmovaps xmm15, [rsp+0xE0]
00007efc33fd29ff  add rsp, 0xF0
00007efc33fd2a06  pop r11
00007efc33fd2a08  pop r10
00007efc33fd2a0a  pop r9
00007efc33fd2a0c  pop r8
00007efc33fd2a0e  pop rsi
00007efc33fd2a0f  pop rdi
00007efc33fd2a10  pop rdx
00007efc33fd2a11  pop rcx
00007efc33fd2a12  pop rax
00007efc33fd2a13  add rsp, 0x08
00007efc33fd2a17  jmp 0x00007EFC33FCFD98
00007efc33fd2a1c  sub rsp, 0x08
00007efc33fd2a20  push rax
00007efc33fd2a21  push rcx
00007efc33fd2a22  push rdx
00007efc33fd2a23  push rdi
00007efc33fd2a24  push rsi
00007efc33fd2a25  push r8
00007efc33fd2a27  push r9
00007efc33fd2a29  push r10
00007efc33fd2a2b  push r11
00007efc33fd2a2d  sub rsp, 0xF0
00007efc33fd2a34  vmovaps [rsp], xmm0
00007efc33fd2a39  vmovaps [rsp+0x10], xmm2
00007efc33fd2a3f  vmovaps [rsp+0x20], xmm3
00007efc33fd2a45  vmovaps [rsp+0x30], xmm4
00007efc33fd2a4b  vmovaps [rsp+0x40], xmm5
00007efc33fd2a51  vmovaps [rsp+0x50], xmm6
00007efc33fd2a57  vmovaps [rsp+0x60], xmm7
00007efc33fd2a5d  vmovaps [rsp+0x70], xmm8
00007efc33fd2a63  vmovaps [rsp+0x80], xmm9
00007efc33fd2a6c  vmovaps [rsp+0x90], xmm10
00007efc33fd2a75  vmovaps [rsp+0xA0], xmm11
00007efc33fd2a7e  vmovaps [rsp+0xB0], xmm12
00007efc33fd2a87  vmovaps [rsp+0xC0], xmm13
00007efc33fd2a90  vmovaps [rsp+0xD0], xmm14
00007efc33fd2a99  vmovaps [rsp+0xE0], xmm15
00007efc33fd2aa2  sub rsp, 0x30
00007efc33fd2aa6  movaps [rsp], xmm1
00007efc33fd2aaa  movaps [rsp+0x10], xmm5
00007efc33fd2aaf  movaps [rsp+0x20], xmm13
00007efc33fd2ab5  lea rdi, [rsp]
00007efc33fd2ab9  mov esi, 0x00
00007efc33fd2abe  mov rax, 0x5D9448894530
00007efc33fd2ac8  call rax
00007efc33fd2aca  movaps xmm1, [rsp]
00007efc33fd2ace  add rsp, 0x30
00007efc33fd2ad2  vmovaps xmm0, [rsp]
00007efc33fd2ad7  vmovaps xmm2, [rsp+0x10]
00007efc33fd2add  vmovaps xmm3, [rsp+0x20]
00007efc33fd2ae3  vmovaps xmm4, [rsp+0x30]
00007efc33fd2ae9  vmovaps xmm5, [rsp+0x40]
00007efc33fd2aef  vmovaps xmm6, [rsp+0x50]
00007efc33fd2af5  vmovaps xmm7, [rsp+0x60]
00007efc33fd2afb  vmovaps xmm8, [rsp+0x70]
00007efc33fd2b01  vmovaps xmm9, [rsp+0x80]
00007efc33fd2b0a  vmovaps xmm10, [rsp+0x90]
00007efc33fd2b13  vmovaps xmm11, [rsp+0xA0]
00007efc33fd2b1c  vmovaps xmm12, [rsp+0xB0]
00007efc33fd2b25  vmovaps xmm13, [rsp+0xC0]
00007efc33fd2b2e  vmovaps xmm14, [rsp+0xD0]
00007efc33fd2b37  vmovaps xmm15, [rsp+0xE0]
00007efc33fd2b40  add rsp, 0xF0
00007efc33fd2b47  pop r11
00007efc33fd2b49  pop r10
00007efc33fd2b4b  pop r9
00007efc33fd2b4d  pop r8
00007efc33fd2b4f  pop rsi
00007efc33fd2b50  pop rdi
00007efc33fd2b51  pop rdx
00007efc33fd2b52  pop rcx
00007efc33fd2b53  pop rax
00007efc33fd2b54  add rsp, 0x08
00007efc33fd2b58  jmp 0x00007EFC33FCFDB6
00007efc33fd2b5d  sub rsp, 0x08
00007efc33fd2b61  push rax
00007efc33fd2b62  push rcx
00007efc33fd2b63  push rdx
00007efc33fd2b64  push rdi
00007efc33fd2b65  push rsi
00007efc33fd2b66  push r8
00007efc33fd2b68  push r9
00007efc33fd2b6a  push r10
00007efc33fd2b6c  push r11
00007efc33fd2b6e  sub rsp, 0xF0
00007efc33fd2b75  vmovaps [rsp], xmm0
00007efc33fd2b7a  vmovaps [rsp+0x10], xmm1
00007efc33fd2b80  vmovaps [rsp+0x20], xmm2
00007efc33fd2b86  vmovaps [rsp+0x30], xmm3
00007efc33fd2b8c  vmovaps [rsp+0x40], xmm4
00007efc33fd2b92  vmovaps [rsp+0x50], xmm6
00007efc33fd2b98  vmovaps [rsp+0x60], xmm7
00007efc33fd2b9e  vmovaps [rsp+0x70], xmm8
00007efc33fd2ba4  vmovaps [rsp+0x80], xmm9
00007efc33fd2bad  vmovaps [rsp+0x90], xmm10
00007efc33fd2bb6  vmovaps [rsp+0xA0], xmm11
00007efc33fd2bbf  vmovaps [rsp+0xB0], xmm12
00007efc33fd2bc8  vmovaps [rsp+0xC0], xmm13
00007efc33fd2bd1  vmovaps [rsp+0xD0], xmm14
00007efc33fd2bda  vmovaps [rsp+0xE0], xmm15
00007efc33fd2be3  sub rsp, 0x30
00007efc33fd2be7  movaps [rsp], xmm5
00007efc33fd2beb  movaps [rsp+0x10], xmm2
00007efc33fd2bf0  movaps [rsp+0x20], xmm13
00007efc33fd2bf6  lea rdi, [rsp]
00007efc33fd2bfa  mov esi, 0x00
00007efc33fd2bff  mov rax, 0x5D9448894530
00007efc33fd2c09  call rax
00007efc33fd2c0b  movaps xmm5, [rsp]
00007efc33fd2c0f  add rsp, 0x30
00007efc33fd2c13  vmovaps xmm0, [rsp]
00007efc33fd2c18  vmovaps xmm1, [rsp+0x10]
00007efc33fd2c1e  vmovaps xmm2, [rsp+0x20]
00007efc33fd2c24  vmovaps xmm3, [rsp+0x30]
00007efc33fd2c2a  vmovaps xmm4, [rsp+0x40]
00007efc33fd2c30  vmovaps xmm6, [rsp+0x50]
00007efc33fd2c36  vmovaps xmm7, [rsp+0x60]
00007efc33fd2c3c  vmovaps xmm8, [rsp+0x70]
00007efc33fd2c42  vmovaps xmm9, [rsp+0x80]
00007efc33fd2c4b  vmovaps xmm10, [rsp+0x90]
00007efc33fd2c54  vmovaps xmm11, [rsp+0xA0]
00007efc33fd2c5d  vmovaps xmm12, [rsp+0xB0]
00007efc33fd2c66  vmovaps xmm13, [rsp+0xC0]
00007efc33fd2c6f  vmovaps xmm14, [rsp+0xD0]
00007efc33fd2c78  vmovaps xmm15, [rsp+0xE0]
00007efc33fd2c81  add rsp, 0xF0
00007efc33fd2c88  pop r11
00007efc33fd2c8a  pop r10
00007efc33fd2c8c  pop r9
00007efc33fd2c8e  pop r8
00007efc33fd2c90  pop rsi
00007efc33fd2c91  pop rdi
00007efc33fd2c92  pop rdx
00007efc33fd2c93  pop rcx
00007efc33fd2c94  pop rax
00007efc33fd2c95  add rsp, 0x08
00007efc33fd2c99  jmp 0x00007EFC33FCFDEC
00007efc33fd2c9e  sub rsp, 0x08
00007efc33fd2ca2  push rax
00007efc33fd2ca3  push rcx
00007efc33fd2ca4  push rdx
00007efc33fd2ca5  push rdi
00007efc33fd2ca6  push rsi
00007efc33fd2ca7  push r8
00007efc33fd2ca9  push r9
00007efc33fd2cab  push r10
00007efc33fd2cad  push r11
00007efc33fd2caf  sub rsp, 0xF0
00007efc33fd2cb6  vmovaps [rsp], xmm0
00007efc33fd2cbb  vmovaps [rsp+0x10], xmm1
00007efc33fd2cc1  vmovaps [rsp+0x20], xmm2
00007efc33fd2cc7  vmovaps [rsp+0x30], xmm3
00007efc33fd2ccd  vmovaps [rsp+0x40], xmm4
00007efc33fd2cd3  vmovaps [rsp+0x50], xmm5
00007efc33fd2cd9  vmovaps [rsp+0x60], xmm6
00007efc33fd2cdf  vmovaps [rsp+0x70], xmm7
00007efc33fd2ce5  vmovaps [rsp+0x80], xmm8
00007efc33fd2cee  vmovaps [rsp+0x90], xmm9
00007efc33fd2cf7  vmovaps [rsp+0xA0], xmm10
00007efc33fd2d00  vmovaps [rsp+0xB0], xmm11
00007efc33fd2d09  vmovaps [rsp+0xC0], xmm12
00007efc33fd2d12  vmovaps [rsp+0xD0], xmm14
00007efc33fd2d1b  vmovaps [rsp+0xE0], xmm15
00007efc33fd2d24  sub rsp, 0x30
00007efc33fd2d28  movaps [rsp], xmm13
00007efc33fd2d2d  movaps [rsp+0x10], xmm10
00007efc33fd2d33  movaps [rsp+0x20], xmm1
00007efc33fd2d38  lea rdi, [rsp]
00007efc33fd2d3c  mov esi, 0x00
00007efc33fd2d41  mov rax, 0x5D9448894530
00007efc33fd2d4b  call rax
00007efc33fd2d4d  movaps xmm13, [rsp]
00007efc33fd2d52  add rsp, 0x30
00007efc33fd2d56  vmovaps xmm0, [rsp]
00007efc33fd2d5b  vmovaps xmm1, [rsp+0x10]
00007efc33fd2d61  vmovaps xmm2, [rsp+0x20]
00007efc33fd2d67  vmovaps xmm3, [rsp+0x30]
00007efc33fd2d6d  vmovaps xmm4, [rsp+0x40]
00007efc33fd2d73  vmovaps xmm5, [rsp+0x50]
00007efc33fd2d79  vmovaps xmm6, [rsp+0x60]
00007efc33fd2d7f  vmovaps xmm7, [rsp+0x70]
00007efc33fd2d85  vmovaps xmm8, [rsp+0x80]
00007efc33fd2d8e  vmovaps xmm9, [rsp+0x90]
00007efc33fd2d97  vmovaps xmm10, [rsp+0xA0]
00007efc33fd2da0  vmovaps xmm11, [rsp+0xB0]
00007efc33fd2da9  vmovaps xmm12, [rsp+0xC0]
00007efc33fd2db2  vmovaps xmm14, [rsp+0xD0]
00007efc33fd2dbb  vmovaps xmm15, [rsp+0xE0]
00007efc33fd2dc4  add rsp, 0xF0
00007efc33fd2dcb  pop r11
00007efc33fd2dcd  pop r10
00007efc33fd2dcf  pop r9
00007efc33fd2dd1  pop r8
00007efc33fd2dd3  pop rsi
00007efc33fd2dd4  pop rdi
00007efc33fd2dd5  pop rdx
00007efc33fd2dd6  pop rcx
00007efc33fd2dd7  pop rax
00007efc33fd2dd8  add rsp, 0x08
00007efc33fd2ddc  jmp 0x00007EFC33FCFE15
00007efc33fd2de1  sub rsp, 0x08
00007efc33fd2de5  push rax
00007efc33fd2de6  push rcx
00007efc33fd2de7  push rdx
00007efc33fd2de8  push rdi
00007efc33fd2de9  push rsi
00007efc33fd2dea  push r8
00007efc33fd2dec  push r9
00007efc33fd2dee  push r10
00007efc33fd2df0  push r11
00007efc33fd2df2  sub rsp, 0xF0
00007efc33fd2df9  vmovaps [rsp], xmm0
00007efc33fd2dfe  vmovaps [rsp+0x10], xmm2
00007efc33fd2e04  vmovaps [rsp+0x20], xmm3
00007efc33fd2e0a  vmovaps [rsp+0x30], xmm4
00007efc33fd2e10  vmovaps [rsp+0x40], xmm5
00007efc33fd2e16  vmovaps [rsp+0x50], xmm6
00007efc33fd2e1c  vmovaps [rsp+0x60], xmm7
00007efc33fd2e22  vmovaps [rsp+0x70], xmm8
00007efc33fd2e28  vmovaps [rsp+0x80], xmm9
00007efc33fd2e31  vmovaps [rsp+0x90], xmm10
00007efc33fd2e3a  vmovaps [rsp+0xA0], xmm11
00007efc33fd2e43  vmovaps [rsp+0xB0], xmm12
00007efc33fd2e4c  vmovaps [rsp+0xC0], xmm13
00007efc33fd2e55  vmovaps [rsp+0xD0], xmm14
00007efc33fd2e5e  vmovaps [rsp+0xE0], xmm15
00007efc33fd2e67  sub rsp, 0x30
00007efc33fd2e6b  movaps [rsp], xmm1
00007efc33fd2e6f  movaps [rsp+0x10], xmm15
00007efc33fd2e75  movaps [rsp+0x20], xmm10
00007efc33fd2e7b  lea rdi, [rsp]
00007efc33fd2e7f  mov esi, 0x00
00007efc33fd2e84  mov rax, 0x5D9448894530
00007efc33fd2e8e  call rax
00007efc33fd2e90  movaps xmm1, [rsp]
00007efc33fd2e94  add rsp, 0x30
00007efc33fd2e98  vmovaps xmm0, [rsp]
00007efc33fd2e9d  vmovaps xmm2, [rsp+0x10]
00007efc33fd2ea3  vmovaps xmm3, [rsp+0x20]
00007efc33fd2ea9  vmovaps xmm4, [rsp+0x30]
00007efc33fd2eaf  vmovaps xmm5, [rsp+0x40]
00007efc33fd2eb5  vmovaps xmm6, [rsp+0x50]
00007efc33fd2ebb  vmovaps xmm7, [rsp+0x60]
00007efc33fd2ec1  vmovaps xmm8, [rsp+0x70]
00007efc33fd2ec7  vmovaps xmm9, [rsp+0x80]
00007efc33fd2ed0  vmovaps xmm10, [rsp+0x90]
00007efc33fd2ed9  vmovaps xmm11, [rsp+0xA0]
00007efc33fd2ee2  vmovaps xmm12, [rsp+0xB0]
00007efc33fd2eeb  vmovaps xmm13, [rsp+0xC0]
00007efc33fd2ef4  vmovaps xmm14, [rsp+0xD0]
00007efc33fd2efd  vmovaps xmm15, [rsp+0xE0]
00007efc33fd2f06  add rsp, 0xF0
00007efc33fd2f0d  pop r11
00007efc33fd2f0f  pop r10
00007efc33fd2f11  pop r9
00007efc33fd2f13  pop r8
00007efc33fd2f15  pop rsi
00007efc33fd2f16  pop rdi
00007efc33fd2f17  pop rdx
00007efc33fd2f18  pop rcx
00007efc33fd2f19  pop rax
00007efc33fd2f1a  add rsp, 0x08
00007efc33fd2f1e  jmp 0x00007EFC33FCFE34
00007efc33fd2f23  sub rsp, 0x08
00007efc33fd2f27  push rax
00007efc33fd2f28  push rcx
00007efc33fd2f29  push rdx
00007efc33fd2f2a  push rdi
00007efc33fd2f2b  push rsi
00007efc33fd2f2c  push r8
00007efc33fd2f2e  push r9
00007efc33fd2f30  push r10
00007efc33fd2f32  push r11
00007efc33fd2f34  sub rsp, 0xF0
00007efc33fd2f3b  vmovaps [rsp], xmm0
00007efc33fd2f40  vmovaps [rsp+0x10], xmm1
00007efc33fd2f46  vmovaps [rsp+0x20], xmm2
00007efc33fd2f4c  vmovaps [rsp+0x30], xmm3
00007efc33fd2f52  vmovaps [rsp+0x40], xmm4
00007efc33fd2f58  vmovaps [rsp+0x50], xmm5
00007efc33fd2f5e  vmovaps [rsp+0x60], xmm6
00007efc33fd2f64  vmovaps [rsp+0x70], xmm7
00007efc33fd2f6a  vmovaps [rsp+0x80], xmm8
00007efc33fd2f73  vmovaps [rsp+0x90], xmm9
00007efc33fd2f7c  vmovaps [rsp+0xA0], xmm10
00007efc33fd2f85  vmovaps [rsp+0xB0], xmm11
00007efc33fd2f8e  vmovaps [rsp+0xC0], xmm12
00007efc33fd2f97  vmovaps [rsp+0xD0], xmm13
00007efc33fd2fa0  vmovaps [rsp+0xE0], xmm14
00007efc33fd2fa9  sub rsp, 0x30
00007efc33fd2fad  movaps [rsp], xmm15
00007efc33fd2fb2  movaps [rsp+0x10], xmm10
00007efc33fd2fb8  movaps [rsp+0x20], xmm11
00007efc33fd2fbe  lea rdi, [rsp]
00007efc33fd2fc2  mov esi, 0x00
00007efc33fd2fc7  mov rax, 0x5D9448894530
00007efc33fd2fd1  call rax
00007efc33fd2fd3  movaps xmm15, [rsp]
00007efc33fd2fd8  add rsp, 0x30
00007efc33fd2fdc  vmovaps xmm0, [rsp]
00007efc33fd2fe1  vmovaps xmm1, [rsp+0x10]
00007efc33fd2fe7  vmovaps xmm2, [rsp+0x20]
00007efc33fd2fed  vmovaps xmm3, [rsp+0x30]
00007efc33fd2ff3  vmovaps xmm4, [rsp+0x40]
00007efc33fd2ff9  vmovaps xmm5, [rsp+0x50]
00007efc33fd2fff  vmovaps xmm6, [rsp+0x60]
00007efc33fd3005  vmovaps xmm7, [rsp+0x70]
00007efc33fd300b  vmovaps xmm8, [rsp+0x80]
00007efc33fd3014  vmovaps xmm9, [rsp+0x90]
00007efc33fd301d  vmovaps xmm10, [rsp+0xA0]
00007efc33fd3026  vmovaps xmm11, [rsp+0xB0]
00007efc33fd302f  vmovaps xmm12, [rsp+0xC0]
00007efc33fd3038  vmovaps xmm13, [rsp+0xD0]
00007efc33fd3041  vmovaps xmm14, [rsp+0xE0]
00007efc33fd304a  add rsp, 0xF0
00007efc33fd3051  pop r11
00007efc33fd3053  pop r10
00007efc33fd3055  pop r9
00007efc33fd3057  pop r8
00007efc33fd3059  pop rsi
00007efc33fd305a  pop rdi
00007efc33fd305b  pop rdx
00007efc33fd305c  pop rcx
00007efc33fd305d  pop rax
00007efc33fd305e  add rsp, 0x08
00007efc33fd3062  jmp 0x00007EFC33FCFE57
00007efc33fd3067  sub rsp, 0x08
00007efc33fd306b  push rax
00007efc33fd306c  push rcx
00007efc33fd306d  push rdx
00007efc33fd306e  push rdi
00007efc33fd306f  push rsi
00007efc33fd3070  push r8
00007efc33fd3072  push r9
00007efc33fd3074  push r10
00007efc33fd3076  push r11
00007efc33fd3078  sub rsp, 0xF0
00007efc33fd307f  vmovaps [rsp], xmm0
00007efc33fd3084  vmovaps [rsp+0x10], xmm1
00007efc33fd308a  vmovaps [rsp+0x20], xmm2
00007efc33fd3090  vmovaps [rsp+0x30], xmm3
00007efc33fd3096  vmovaps [rsp+0x40], xmm4
00007efc33fd309c  vmovaps [rsp+0x50], xmm5
00007efc33fd30a2  vmovaps [rsp+0x60], xmm6
00007efc33fd30a8  vmovaps [rsp+0x70], xmm7
00007efc33fd30ae  vmovaps [rsp+0x80], xmm8
00007efc33fd30b7  vmovaps [rsp+0x90], xmm9
00007efc33fd30c0  vmovaps [rsp+0xA0], xmm11
00007efc33fd30c9  vmovaps [rsp+0xB0], xmm12
00007efc33fd30d2  vmovaps [rsp+0xC0], xmm13
00007efc33fd30db  vmovaps [rsp+0xD0], xmm14
00007efc33fd30e4  vmovaps [rsp+0xE0], xmm15
00007efc33fd30ed  sub rsp, 0x30
00007efc33fd30f1  movaps [rsp], xmm10
00007efc33fd30f6  movaps [rsp+0x10], xmm12
00007efc33fd30fc  movaps [rsp+0x20], xmm11
00007efc33fd3102  lea rdi, [rsp]
00007efc33fd3106  mov esi, 0x00
00007efc33fd310b  mov rax, 0x5D9448894530
00007efc33fd3115  call rax
00007efc33fd3117  movaps xmm10, [rsp]
00007efc33fd311c  add rsp, 0x30
00007efc33fd3120  vmovaps xmm0, [rsp]
00007efc33fd3125  vmovaps xmm1, [rsp+0x10]
00007efc33fd312b  vmovaps xmm2, [rsp+0x20]
00007efc33fd3131  vmovaps xmm3, [rsp+0x30]
00007efc33fd3137  vmovaps xmm4, [rsp+0x40]
00007efc33fd313d  vmovaps xmm5, [rsp+0x50]
00007efc33fd3143  vmovaps xmm6, [rsp+0x60]
00007efc33fd3149  vmovaps xmm7, [rsp+0x70]
00007efc33fd314f  vmovaps xmm8, [rsp+0x80]
00007efc33fd3158  vmovaps xmm9, [rsp+0x90]
00007efc33fd3161  vmovaps xmm11, [rsp+0xA0]
00007efc33fd316a  vmovaps xmm12, [rsp+0xB0]
00007efc33fd3173  vmovaps xmm13, [rsp+0xC0]
00007efc33fd317c  vmovaps xmm14, [rsp+0xD0]
00007efc33fd3185  vmovaps xmm15, [rsp+0xE0]
00007efc33fd318e  add rsp, 0xF0
00007efc33fd3195  pop r11
00007efc33fd3197  pop r10
00007efc33fd3199  pop r9
00007efc33fd319b  pop r8
00007efc33fd319d  pop rsi
00007efc33fd319e  pop rdi
00007efc33fd319f  pop rdx
00007efc33fd31a0  pop rcx
00007efc33fd31a1  pop rax
00007efc33fd31a2  add rsp, 0x08
00007efc33fd31a6  jmp 0x00007EFC33FCFE80
00007efc33fd31ab  sub rsp, 0x08
00007efc33fd31af  push rax
00007efc33fd31b0  push rcx
00007efc33fd31b1  push rdx
00007efc33fd31b2  push rdi
00007efc33fd31b3  push rsi
00007efc33fd31b4  push r8
00007efc33fd31b6  push r9
00007efc33fd31b8  push r10
00007efc33fd31ba  push r11
00007efc33fd31bc  sub rsp, 0xF0
00007efc33fd31c3  vmovaps [rsp], xmm0
00007efc33fd31c8  vmovaps [rsp+0x10], xmm1
00007efc33fd31ce  vmovaps [rsp+0x20], xmm2
00007efc33fd31d4  vmovaps [rsp+0x30], xmm3
00007efc33fd31da  vmovaps [rsp+0x40], xmm4
00007efc33fd31e0  vmovaps [rsp+0x50], xmm5
00007efc33fd31e6  vmovaps [rsp+0x60], xmm6
00007efc33fd31ec  vmovaps [rsp+0x70], xmm7
00007efc33fd31f2  vmovaps [rsp+0x80], xmm8
00007efc33fd31fb  vmovaps [rsp+0x90], xmm9
00007efc33fd3204  vmovaps [rsp+0xA0], xmm10
00007efc33fd320d  vmovaps [rsp+0xB0], xmm12
00007efc33fd3216  vmovaps [rsp+0xC0], xmm13
00007efc33fd321f  vmovaps [rsp+0xD0], xmm14
00007efc33fd3228  vmovaps [rsp+0xE0], xmm15
00007efc33fd3231  sub rsp, 0x30
00007efc33fd3235  movaps [rsp], xmm11
00007efc33fd323a  movaps [rsp+0x10], xmm2
00007efc33fd323f  movaps [rsp+0x20], xmm12
00007efc33fd3245  lea rdi, [rsp]
00007efc33fd3249  mov esi, 0x00
00007efc33fd324e  mov rax, 0x5D9448894530
00007efc33fd3258  call rax
00007efc33fd325a  movaps xmm11, [rsp]
00007efc33fd325f  add rsp, 0x30
00007efc33fd3263  vmovaps xmm0, [rsp]
00007efc33fd3268  vmovaps xmm1, [rsp+0x10]
00007efc33fd326e  vmovaps xmm2, [rsp+0x20]
00007efc33fd3274  vmovaps xmm3, [rsp+0x30]
00007efc33fd327a  vmovaps xmm4, [rsp+0x40]
00007efc33fd3280  vmovaps xmm5, [rsp+0x50]
00007efc33fd3286  vmovaps xmm6, [rsp+0x60]
00007efc33fd328c  vmovaps xmm7, [rsp+0x70]
00007efc33fd3292  vmovaps xmm8, [rsp+0x80]
00007efc33fd329b  vmovaps xmm9, [rsp+0x90]
00007efc33fd32a4  vmovaps xmm10, [rsp+0xA0]
00007efc33fd32ad  vmovaps xmm12, [rsp+0xB0]
00007efc33fd32b6  vmovaps xmm13, [rsp+0xC0]
00007efc33fd32bf  vmovaps xmm14, [rsp+0xD0]
00007efc33fd32c8  vmovaps xmm15, [rsp+0xE0]
00007efc33fd32d1  add rsp, 0xF0
00007efc33fd32d8  pop r11
00007efc33fd32da  pop r10
00007efc33fd32dc  pop r9
00007efc33fd32de  pop r8
00007efc33fd32e0  pop rsi
00007efc33fd32e1  pop rdi
00007efc33fd32e2  pop rdx
00007efc33fd32e3  pop rcx
00007efc33fd32e4  pop rax
00007efc33fd32e5  add rsp, 0x08
00007efc33fd32e9  jmp 0x00007EFC33FCFEB8
00007efc33fd32ee  sub rsp, 0x08
00007efc33fd32f2  push rax
00007efc33fd32f3  push rcx
00007efc33fd32f4  push rdx
00007efc33fd32f5  push rdi
00007efc33fd32f6  push rsi
00007efc33fd32f7  push r8
00007efc33fd32f9  push r9
00007efc33fd32fb  push r10
00007efc33fd32fd  push r11
00007efc33fd32ff  sub rsp, 0xF0
00007efc33fd3306  vmovaps [rsp], xmm0
00007efc33fd330b  vmovaps [rsp+0x10], xmm2
00007efc33fd3311  vmovaps [rsp+0x20], xmm3
00007efc33fd3317  vmovaps [rsp+0x30], xmm4
00007efc33fd331d  vmovaps [rsp+0x40], xmm5
00007efc33fd3323  vmovaps [rsp+0x50], xmm6
00007efc33fd3329  vmovaps [rsp+0x60], xmm7
00007efc33fd332f  vmovaps [rsp+0x70], xmm8
00007efc33fd3335  vmovaps [rsp+0x80], xmm9
00007efc33fd333e  vmovaps [rsp+0x90], xmm10
00007efc33fd3347  vmovaps [rsp+0xA0], xmm11
00007efc33fd3350  vmovaps [rsp+0xB0], xmm12
00007efc33fd3359  vmovaps [rsp+0xC0], xmm13
00007efc33fd3362  vmovaps [rsp+0xD0], xmm14
00007efc33fd336b  vmovaps [rsp+0xE0], xmm15
00007efc33fd3374  sub rsp, 0x30
00007efc33fd3378  movaps [rsp], xmm1
00007efc33fd337c  movaps [rsp+0x10], xmm14
00007efc33fd3382  movaps [rsp+0x20], xmm6
00007efc33fd3387  lea rdi, [rsp]
00007efc33fd338b  mov esi, 0x00
00007efc33fd3390  mov rax, 0x5D9448894530
00007efc33fd339a  call rax
00007efc33fd339c  movaps xmm1, [rsp]
00007efc33fd33a0  add rsp, 0x30
00007efc33fd33a4  vmovaps xmm0, [rsp]
00007efc33fd33a9  vmovaps xmm2, [rsp+0x10]
00007efc33fd33af  vmovaps xmm3, [rsp+0x20]
00007efc33fd33b5  vmovaps xmm4, [rsp+0x30]
00007efc33fd33bb  vmovaps xmm5, [rsp+0x40]
00007efc33fd33c1  vmovaps xmm6, [rsp+0x50]
00007efc33fd33c7  vmovaps xmm7, [rsp+0x60]
00007efc33fd33cd  vmovaps xmm8, [rsp+0x70]
00007efc33fd33d3  vmovaps xmm9, [rsp+0x80]
00007efc33fd33dc  vmovaps xmm10, [rsp+0x90]
00007efc33fd33e5  vmovaps xmm11, [rsp+0xA0]
00007efc33fd33ee  vmovaps xmm12, [rsp+0xB0]
00007efc33fd33f7  vmovaps xmm13, [rsp+0xC0]
00007efc33fd3400  vmovaps xmm14, [rsp+0xD0]
00007efc33fd3409  vmovaps xmm15, [rsp+0xE0]
00007efc33fd3412  add rsp, 0xF0
00007efc33fd3419  pop r11
00007efc33fd341b  pop r10
00007efc33fd341d  pop r9
00007efc33fd341f  pop r8
00007efc33fd3421  pop rsi
00007efc33fd3422  pop rdi
00007efc33fd3423  pop rdx
00007efc33fd3424  pop rcx
00007efc33fd3425  pop rax
00007efc33fd3426  add rsp, 0x08
00007efc33fd342a  jmp 0x00007EFC33FCFED1
00007efc33fd342f  sub rsp, 0x08
00007efc33fd3433  push rax
00007efc33fd3434  push rcx
00007efc33fd3435  push rdx
00007efc33fd3436  push rdi
00007efc33fd3437  push rsi
00007efc33fd3438  push r8
00007efc33fd343a  push r9
00007efc33fd343c  push r10
00007efc33fd343e  push r11
00007efc33fd3440  sub rsp, 0xF0
00007efc33fd3447  vmovaps [rsp], xmm0
00007efc33fd344c  vmovaps [rsp+0x10], xmm1
00007efc33fd3452  vmovaps [rsp+0x20], xmm2
00007efc33fd3458  vmovaps [rsp+0x30], xmm3
00007efc33fd345e  vmovaps [rsp+0x40], xmm4
00007efc33fd3464  vmovaps [rsp+0x50], xmm5
00007efc33fd346a  vmovaps [rsp+0x60], xmm6
00007efc33fd3470  vmovaps [rsp+0x70], xmm7
00007efc33fd3476  vmovaps [rsp+0x80], xmm8
00007efc33fd347f  vmovaps [rsp+0x90], xmm9
00007efc33fd3488  vmovaps [rsp+0xA0], xmm10
00007efc33fd3491  vmovaps [rsp+0xB0], xmm11
00007efc33fd349a  vmovaps [rsp+0xC0], xmm12
00007efc33fd34a3  vmovaps [rsp+0xD0], xmm13
00007efc33fd34ac  vmovaps [rsp+0xE0], xmm15
00007efc33fd34b5  sub rsp, 0x30
00007efc33fd34b9  movaps [rsp], xmm14
00007efc33fd34be  movaps [rsp+0x10], xmm12
00007efc33fd34c4  movaps [rsp+0x20], xmm5
00007efc33fd34c9  lea rdi, [rsp]
00007efc33fd34cd  mov esi, 0x00
00007efc33fd34d2  mov rax, 0x5D9448894530
00007efc33fd34dc  call rax
00007efc33fd34de  movaps xmm14, [rsp]
00007efc33fd34e3  add rsp, 0x30
00007efc33fd34e7  vmovaps xmm0, [rsp]
00007efc33fd34ec  vmovaps xmm1, [rsp+0x10]
00007efc33fd34f2  vmovaps xmm2, [rsp+0x20]
00007efc33fd34f8  vmovaps xmm3, [rsp+0x30]
00007efc33fd34fe  vmovaps xmm4, [rsp+0x40]
00007efc33fd3504  vmovaps xmm5, [rsp+0x50]
00007efc33fd350a  vmovaps xmm6, [rsp+0x60]
00007efc33fd3510  vmovaps xmm7, [rsp+0x70]
00007efc33fd3516  vmovaps xmm8, [rsp+0x80]
00007efc33fd351f  vmovaps xmm9, [rsp+0x90]
00007efc33fd3528  vmovaps xmm10, [rsp+0xA0]
00007efc33fd3531  vmovaps xmm11, [rsp+0xB0]
00007efc33fd353a  vmovaps xmm12, [rsp+0xC0]
00007efc33fd3543  vmovaps xmm13, [rsp+0xD0]
00007efc33fd354c  vmovaps xmm15, [rsp+0xE0]
00007efc33fd3555  add rsp, 0xF0
00007efc33fd355c  pop r11
00007efc33fd355e  pop r10
00007efc33fd3560  pop r9
00007efc33fd3562  pop r8
00007efc33fd3564  pop rsi
00007efc33fd3565  pop rdi
00007efc33fd3566  pop rdx
00007efc33fd3567  pop rcx
00007efc33fd3568  pop rax
00007efc33fd3569  add rsp, 0x08
00007efc33fd356d  jmp 0x00007EFC33FCFEF1
00007efc33fd3572  sub rsp, 0x08
00007efc33fd3576  push rax
00007efc33fd3577  push rcx
00007efc33fd3578  push rdx
00007efc33fd3579  push rdi
00007efc33fd357a  push rsi
00007efc33fd357b  push r8
00007efc33fd357d  push r9
00007efc33fd357f  push r10
00007efc33fd3581  push r11
00007efc33fd3583  sub rsp, 0xF0
00007efc33fd358a  vmovaps [rsp], xmm0
00007efc33fd358f  vmovaps [rsp+0x10], xmm1
00007efc33fd3595  vmovaps [rsp+0x20], xmm2
00007efc33fd359b  vmovaps [rsp+0x30], xmm3
00007efc33fd35a1  vmovaps [rsp+0x40], xmm4
00007efc33fd35a7  vmovaps [rsp+0x50], xmm5
00007efc33fd35ad  vmovaps [rsp+0x60], xmm7
00007efc33fd35b3  vmovaps [rsp+0x70], xmm8
00007efc33fd35b9  vmovaps [rsp+0x80], xmm9
00007efc33fd35c2  vmovaps [rsp+0x90], xmm10
00007efc33fd35cb  vmovaps [rsp+0xA0], xmm11
00007efc33fd35d4  vmovaps [rsp+0xB0], xmm12
00007efc33fd35dd  vmovaps [rsp+0xC0], xmm13
00007efc33fd35e6  vmovaps [rsp+0xD0], xmm14
00007efc33fd35ef  vmovaps [rsp+0xE0], xmm15
00007efc33fd35f8  sub rsp, 0x30
00007efc33fd35fc  movaps [rsp], xmm6
00007efc33fd3600  movaps [rsp+0x10], xmm9
00007efc33fd3606  movaps [rsp+0x20], xmm12
00007efc33fd360c  lea rdi, [rsp]
00007efc33fd3610  mov esi, 0x00
00007efc33fd3615  mov rax, 0x5D9448894530
00007efc33fd361f  call rax
00007efc33fd3621  movaps xmm6, [rsp]
00007efc33fd3625  add rsp, 0x30
00007efc33fd3629  vmovaps xmm0, [rsp]
00007efc33fd362e  vmovaps xmm1, [rsp+0x10]
00007efc33fd3634  vmovaps xmm2, [rsp+0x20]
00007efc33fd363a  vmovaps xmm3, [rsp+0x30]
00007efc33fd3640  vmovaps xmm4, [rsp+0x40]
00007efc33fd3646  vmovaps xmm5, [rsp+0x50]
00007efc33fd364c  vmovaps xmm7, [rsp+0x60]
00007efc33fd3652  vmovaps xmm8, [rsp+0x70]
00007efc33fd3658  vmovaps xmm9, [rsp+0x80]
00007efc33fd3661  vmovaps xmm10, [rsp+0x90]
00007efc33fd366a  vmovaps xmm11, [rsp+0xA0]
00007efc33fd3673  vmovaps xmm12, [rsp+0xB0]
00007efc33fd367c  vmovaps xmm13, [rsp+0xC0]
00007efc33fd3685  vmovaps xmm14, [rsp+0xD0]
00007efc33fd368e  vmovaps xmm15, [rsp+0xE0]
00007efc33fd3697  add rsp, 0xF0
00007efc33fd369e  pop r11
00007efc33fd36a0  pop r10
00007efc33fd36a2  pop r9
00007efc33fd36a4  pop r8
00007efc33fd36a6  pop rsi
00007efc33fd36a7  pop rdi
00007efc33fd36a8  pop rdx
00007efc33fd36a9  pop rcx
00007efc33fd36aa  pop rax
00007efc33fd36ab  add rsp, 0x08
00007efc33fd36af  jmp 0x00007EFC33FCFF19
00007efc33fd36b4  sub rsp, 0x08
00007efc33fd36b8  push rax
00007efc33fd36b9  push rcx
00007efc33fd36ba  push rdx
00007efc33fd36bb  push rdi
00007efc33fd36bc  push rsi
00007efc33fd36bd  push r8
00007efc33fd36bf  push r9
00007efc33fd36c1  push r10
00007efc33fd36c3  push r11
00007efc33fd36c5  sub rsp, 0xF0
00007efc33fd36cc  vmovaps [rsp], xmm0
00007efc33fd36d1  vmovaps [rsp+0x10], xmm1
00007efc33fd36d7  vmovaps [rsp+0x20], xmm2
00007efc33fd36dd  vmovaps [rsp+0x30], xmm3
00007efc33fd36e3  vmovaps [rsp+0x40], xmm4
00007efc33fd36e9  vmovaps [rsp+0x50], xmm5
00007efc33fd36ef  vmovaps [rsp+0x60], xmm6
00007efc33fd36f5  vmovaps [rsp+0x70], xmm7
00007efc33fd36fb  vmovaps [rsp+0x80], xmm8
00007efc33fd3704  vmovaps [rsp+0x90], xmm9
00007efc33fd370d  vmovaps [rsp+0xA0], xmm10
00007efc33fd3716  vmovaps [rsp+0xB0], xmm11
00007efc33fd371f  vmovaps [rsp+0xC0], xmm13
00007efc33fd3728  vmovaps [rsp+0xD0], xmm14
00007efc33fd3731  vmovaps [rsp+0xE0], xmm15
00007efc33fd373a  sub rsp, 0x30
00007efc33fd373e  movaps [rsp], xmm12
00007efc33fd3743  movaps [rsp+0x10], xmm15
00007efc33fd3749  movaps [rsp+0x20], xmm13
00007efc33fd374f  lea rdi, [rsp]
00007efc33fd3753  mov esi, 0x00
00007efc33fd3758  mov rax, 0x5D9448894530
00007efc33fd3762  call rax
00007efc33fd3764  movaps xmm12, [rsp]
00007efc33fd3769  add rsp, 0x30
00007efc33fd376d  vmovaps xmm0, [rsp]
00007efc33fd3772  vmovaps xmm1, [rsp+0x10]
00007efc33fd3778  vmovaps xmm2, [rsp+0x20]
00007efc33fd377e  vmovaps xmm3, [rsp+0x30]
00007efc33fd3784  vmovaps xmm4, [rsp+0x40]
00007efc33fd378a  vmovaps xmm5, [rsp+0x50]
00007efc33fd3790  vmovaps xmm6, [rsp+0x60]
00007efc33fd3796  vmovaps xmm7, [rsp+0x70]
00007efc33fd379c  vmovaps xmm8, [rsp+0x80]
00007efc33fd37a5  vmovaps xmm9, [rsp+0x90]
00007efc33fd37ae  vmovaps xmm10, [rsp+0xA0]
00007efc33fd37b7  vmovaps xmm11, [rsp+0xB0]
00007efc33fd37c0  vmovaps xmm13, [rsp+0xC0]
00007efc33fd37c9  vmovaps xmm14, [rsp+0xD0]
00007efc33fd37d2  vmovaps xmm15, [rsp+0xE0]
00007efc33fd37db  add rsp, 0xF0
00007efc33fd37e2  pop r11
00007efc33fd37e4  pop r10
00007efc33fd37e6  pop r9
00007efc33fd37e8  pop r8
00007efc33fd37ea  pop rsi
00007efc33fd37eb  pop rdi
00007efc33fd37ec  pop rdx
00007efc33fd37ed  pop rcx
00007efc33fd37ee  pop rax
00007efc33fd37ef  add rsp, 0x08
00007efc33fd37f3  jmp 0x00007EFC33FCFF34
00007efc33fd37f8  sub rsp, 0x08
00007efc33fd37fc  push rax
00007efc33fd37fd  push rcx
00007efc33fd37fe  push rdx
00007efc33fd37ff  push rdi
00007efc33fd3800  push rsi
00007efc33fd3801  push r8
00007efc33fd3803  push r9
00007efc33fd3805  push r10
00007efc33fd3807  push r11
00007efc33fd3809  sub rsp, 0xF0
00007efc33fd3810  vmovaps [rsp], xmm0
00007efc33fd3815  vmovaps [rsp+0x10], xmm1
00007efc33fd381b  vmovaps [rsp+0x20], xmm2
00007efc33fd3821  vmovaps [rsp+0x30], xmm3
00007efc33fd3827  vmovaps [rsp+0x40], xmm4
00007efc33fd382d  vmovaps [rsp+0x50], xmm5
00007efc33fd3833  vmovaps [rsp+0x60], xmm6
00007efc33fd3839  vmovaps [rsp+0x70], xmm7
00007efc33fd383f  vmovaps [rsp+0x80], xmm8
00007efc33fd3848  vmovaps [rsp+0x90], xmm9
00007efc33fd3851  vmovaps [rsp+0xA0], xmm10
00007efc33fd385a  vmovaps [rsp+0xB0], xmm11
00007efc33fd3863  vmovaps [rsp+0xC0], xmm12
00007efc33fd386c  vmovaps [rsp+0xD0], xmm13
00007efc33fd3875  vmovaps [rsp+0xE0], xmm14
00007efc33fd387e  sub rsp, 0x30
00007efc33fd3882  movaps [rsp], xmm15
00007efc33fd3887  movaps [rsp+0x10], xmm13
00007efc33fd388d  movaps [rsp+0x20], xmm10
00007efc33fd3893  lea rdi, [rsp]
00007efc33fd3897  mov esi, 0x00
00007efc33fd389c  mov rax, 0x5D9448894530
00007efc33fd38a6  call rax
00007efc33fd38a8  movaps xmm15, [rsp]
00007efc33fd38ad  add rsp, 0x30
00007efc33fd38b1  vmovaps xmm0, [rsp]
00007efc33fd38b6  vmovaps xmm1, [rsp+0x10]
00007efc33fd38bc  vmovaps xmm2, [rsp+0x20]
00007efc33fd38c2  vmovaps xmm3, [rsp+0x30]
00007efc33fd38c8  vmovaps xmm4, [rsp+0x40]
00007efc33fd38ce  vmovaps xmm5, [rsp+0x50]
00007efc33fd38d4  vmovaps xmm6, [rsp+0x60]
00007efc33fd38da  vmovaps xmm7, [rsp+0x70]
00007efc33fd38e0  vmovaps xmm8, [rsp+0x80]
00007efc33fd38e9  vmovaps xmm9, [rsp+0x90]
00007efc33fd38f2  vmovaps xmm10, [rsp+0xA0]
00007efc33fd38fb  vmovaps xmm11, [rsp+0xB0]
00007efc33fd3904  vmovaps xmm12, [rsp+0xC0]
00007efc33fd390d  vmovaps xmm13, [rsp+0xD0]
00007efc33fd3916  vmovaps xmm14, [rsp+0xE0]
00007efc33fd391f  add rsp, 0xF0
00007efc33fd3926  pop r11
00007efc33fd3928  pop r10
00007efc33fd392a  pop r9
00007efc33fd392c  pop r8
00007efc33fd392e  pop rsi
00007efc33fd392f  pop rdi
00007efc33fd3930  pop rdx
00007efc33fd3931  pop rcx
00007efc33fd3932  pop rax
00007efc33fd3933  add rsp, 0x08
00007efc33fd3937  jmp 0x00007EFC33FCFF55
00007efc33fd393c  call 0x00007EFC33E0C260
00007efc33fd3941  jmp 0x00007EFC33FCFFB0
00007efc33fd3946  sub rsp, 0x08
00007efc33fd394a  push rax
00007efc33fd394b  push rcx
00007efc33fd394c  push rdx
00007efc33fd394d  push rdi
00007efc33fd394e  push rsi
00007efc33fd394f  push r8
00007efc33fd3951  push r9
00007efc33fd3953  push r10
00007efc33fd3955  push r11
00007efc33fd3957  sub rsp, 0xF0
00007efc33fd395e  vmovaps [rsp], xmm0
00007efc33fd3963  vmovaps [rsp+0x10], xmm1
00007efc33fd3969  vmovaps [rsp+0x20], xmm2
00007efc33fd396f  vmovaps [rsp+0x30], xmm3
00007efc33fd3975  vmovaps [rsp+0x40], xmm4
00007efc33fd397b  vmovaps [rsp+0x50], xmm5
00007efc33fd3981  vmovaps [rsp+0x60], xmm6
00007efc33fd3987  vmovaps [rsp+0x70], xmm7
00007efc33fd398d  vmovaps [rsp+0x80], xmm8
00007efc33fd3996  vmovaps [rsp+0x90], xmm10
00007efc33fd399f  vmovaps [rsp+0xA0], xmm11
00007efc33fd39a8  vmovaps [rsp+0xB0], xmm12
00007efc33fd39b1  vmovaps [rsp+0xC0], xmm13
00007efc33fd39ba  vmovaps [rsp+0xD0], xmm14
00007efc33fd39c3  vmovaps [rsp+0xE0], xmm15
00007efc33fd39cc  sub rsp, 0x30
00007efc33fd39d0  movaps [rsp], xmm9
00007efc33fd39d5  movaps [rsp+0x10], xmm8
00007efc33fd39db  movaps [rsp+0x20], xmm10
00007efc33fd39e1  lea rdi, [rsp]
00007efc33fd39e5  mov esi, 0x00
00007efc33fd39ea  mov rax, 0x5D9448894530
00007efc33fd39f4  call rax
00007efc33fd39f6  movaps xmm9, [rsp]
00007efc33fd39fb  add rsp, 0x30
00007efc33fd39ff  vmovaps xmm0, [rsp]
00007efc33fd3a04  vmovaps xmm1, [rsp+0x10]
00007efc33fd3a0a  vmovaps xmm2, [rsp+0x20]
00007efc33fd3a10  vmovaps xmm3, [rsp+0x30]
00007efc33fd3a16  vmovaps xmm4, [rsp+0x40]
00007efc33fd3a1c  vmovaps xmm5, [rsp+0x50]
00007efc33fd3a22  vmovaps xmm6, [rsp+0x60]
00007efc33fd3a28  vmovaps xmm7, [rsp+0x70]
00007efc33fd3a2e  vmovaps xmm8, [rsp+0x80]
00007efc33fd3a37  vmovaps xmm10, [rsp+0x90]
00007efc33fd3a40  vmovaps xmm11, [rsp+0xA0]
00007efc33fd3a49  vmovaps xmm12, [rsp+0xB0]
00007efc33fd3a52  vmovaps xmm13, [rsp+0xC0]
00007efc33fd3a5b  vmovaps xmm14, [rsp+0xD0]
00007efc33fd3a64  vmovaps xmm15, [rsp+0xE0]
00007efc33fd3a6d  add rsp, 0xF0
00007efc33fd3a74  pop r11
00007efc33fd3a76  pop r10
00007efc33fd3a78  pop r9
00007efc33fd3a7a  pop r8
00007efc33fd3a7c  pop rsi
00007efc33fd3a7d  pop rdi
00007efc33fd3a7e  pop rdx
00007efc33fd3a7f  pop rcx
00007efc33fd3a80  pop rax
00007efc33fd3a81  add rsp, 0x08
00007efc33fd3a85  jmp 0x00007EFC33FCFFE1
00007efc33fd3a8a  sub rsp, 0x08
00007efc33fd3a8e  push rax
00007efc33fd3a8f  push rcx
00007efc33fd3a90  push rdx
00007efc33fd3a91  push rdi
00007efc33fd3a92  push rsi
00007efc33fd3a93  push r8
00007efc33fd3a95  push r9
00007efc33fd3a97  push r10
00007efc33fd3a99  push r11
00007efc33fd3a9b  sub rsp, 0xF0
00007efc33fd3aa2  vmovaps [rsp], xmm0
00007efc33fd3aa7  vmovaps [rsp+0x10], xmm1
00007efc33fd3aad  vmovaps [rsp+0x20], xmm2
00007efc33fd3ab3  vmovaps [rsp+0x30], xmm3
00007efc33fd3ab9  vmovaps [rsp+0x40], xmm4
00007efc33fd3abf  vmovaps [rsp+0x50], xmm5
00007efc33fd3ac5  vmovaps [rsp+0x60], xmm6
00007efc33fd3acb  vmovaps [rsp+0x70], xmm7
00007efc33fd3ad1  vmovaps [rsp+0x80], xmm8
00007efc33fd3ada  vmovaps [rsp+0x90], xmm9
00007efc33fd3ae3  vmovaps [rsp+0xA0], xmm11
00007efc33fd3aec  vmovaps [rsp+0xB0], xmm12
00007efc33fd3af5  vmovaps [rsp+0xC0], xmm13
00007efc33fd3afe  vmovaps [rsp+0xD0], xmm14
00007efc33fd3b07  vmovaps [rsp+0xE0], xmm15
00007efc33fd3b10  sub rsp, 0x30
00007efc33fd3b14  movaps [rsp], xmm10
00007efc33fd3b19  movaps [rsp+0x10], xmm1
00007efc33fd3b1e  movaps [rsp+0x20], xmm11
00007efc33fd3b24  lea rdi, [rsp]
00007efc33fd3b28  mov esi, 0x00
00007efc33fd3b2d  mov rax, 0x5D9448894530
00007efc33fd3b37  call rax
00007efc33fd3b39  movaps xmm10, [rsp]
00007efc33fd3b3e  add rsp, 0x30
00007efc33fd3b42  vmovaps xmm0, [rsp]
00007efc33fd3b47  vmovaps xmm1, [rsp+0x10]
00007efc33fd3b4d  vmovaps xmm2, [rsp+0x20]
00007efc33fd3b53  vmovaps xmm3, [rsp+0x30]
00007efc33fd3b59  vmovaps xmm4, [rsp+0x40]
00007efc33fd3b5f  vmovaps xmm5, [rsp+0x50]
00007efc33fd3b65  vmovaps xmm6, [rsp+0x60]
00007efc33fd3b6b  vmovaps xmm7, [rsp+0x70]
00007efc33fd3b71  vmovaps xmm8, [rsp+0x80]
00007efc33fd3b7a  vmovaps xmm9, [rsp+0x90]
00007efc33fd3b83  vmovaps xmm11, [rsp+0xA0]
00007efc33fd3b8c  vmovaps xmm12, [rsp+0xB0]
00007efc33fd3b95  vmovaps xmm13, [rsp+0xC0]
00007efc33fd3b9e  vmovaps xmm14, [rsp+0xD0]
00007efc33fd3ba7  vmovaps xmm15, [rsp+0xE0]
00007efc33fd3bb0  add rsp, 0xF0
00007efc33fd3bb7  pop r11
00007efc33fd3bb9  pop r10
00007efc33fd3bbb  pop r9
00007efc33fd3bbd  pop r8
00007efc33fd3bbf  pop rsi
00007efc33fd3bc0  pop rdi
00007efc33fd3bc1  pop rdx
00007efc33fd3bc2  pop rcx
00007efc33fd3bc3  pop rax
00007efc33fd3bc4  add rsp, 0x08
00007efc33fd3bc8  jmp 0x00007EFC33FCFFFC
00007efc33fd3bcd  sub rsp, 0x08
00007efc33fd3bd1  push rax
00007efc33fd3bd2  push rcx
00007efc33fd3bd3  push rdx
00007efc33fd3bd4  push rdi
00007efc33fd3bd5  push rsi
00007efc33fd3bd6  push r8
00007efc33fd3bd8  push r9
00007efc33fd3bda  push r10
00007efc33fd3bdc  push r11
00007efc33fd3bde  sub rsp, 0xF0
00007efc33fd3be5  vmovaps [rsp], xmm0
00007efc33fd3bea  vmovaps [rsp+0x10], xmm2
00007efc33fd3bf0  vmovaps [rsp+0x20], xmm3
00007efc33fd3bf6  vmovaps [rsp+0x30], xmm4
00007efc33fd3bfc  vmovaps [rsp+0x40], xmm5
00007efc33fd3c02  vmovaps [rsp+0x50], xmm6
00007efc33fd3c08  vmovaps [rsp+0x60], xmm7
00007efc33fd3c0e  vmovaps [rsp+0x70], xmm8
00007efc33fd3c14  vmovaps [rsp+0x80], xmm9
00007efc33fd3c1d  vmovaps [rsp+0x90], xmm10
00007efc33fd3c26  vmovaps [rsp+0xA0], xmm11
00007efc33fd3c2f  vmovaps [rsp+0xB0], xmm12
00007efc33fd3c38  vmovaps [rsp+0xC0], xmm13
00007efc33fd3c41  vmovaps [rsp+0xD0], xmm14
00007efc33fd3c4a  vmovaps [rsp+0xE0], xmm15
00007efc33fd3c53  sub rsp, 0x30
00007efc33fd3c57  movaps [rsp], xmm1
00007efc33fd3c5b  movaps [rsp+0x10], xmm14
00007efc33fd3c61  movaps [rsp+0x20], xmm6
00007efc33fd3c66  lea rdi, [rsp]
00007efc33fd3c6a  mov esi, 0x00
00007efc33fd3c6f  mov rax, 0x5D9448894530
00007efc33fd3c79  call rax
00007efc33fd3c7b  movaps xmm1, [rsp]
00007efc33fd3c7f  add rsp, 0x30
00007efc33fd3c83  vmovaps xmm0, [rsp]
00007efc33fd3c88  vmovaps xmm2, [rsp+0x10]
00007efc33fd3c8e  vmovaps xmm3, [rsp+0x20]
00007efc33fd3c94  vmovaps xmm4, [rsp+0x30]
00007efc33fd3c9a  vmovaps xmm5, [rsp+0x40]
00007efc33fd3ca0  vmovaps xmm6, [rsp+0x50]
00007efc33fd3ca6  vmovaps xmm7, [rsp+0x60]
00007efc33fd3cac  vmovaps xmm8, [rsp+0x70]
00007efc33fd3cb2  vmovaps xmm9, [rsp+0x80]
00007efc33fd3cbb  vmovaps xmm10, [rsp+0x90]
00007efc33fd3cc4  vmovaps xmm11, [rsp+0xA0]
00007efc33fd3ccd  vmovaps xmm12, [rsp+0xB0]
00007efc33fd3cd6  vmovaps xmm13, [rsp+0xC0]
00007efc33fd3cdf  vmovaps xmm14, [rsp+0xD0]
00007efc33fd3ce8  vmovaps xmm15, [rsp+0xE0]
00007efc33fd3cf1  add rsp, 0xF0
00007efc33fd3cf8  pop r11
00007efc33fd3cfa  pop r10
00007efc33fd3cfc  pop r9
00007efc33fd3cfe  pop r8
00007efc33fd3d00  pop rsi
00007efc33fd3d01  pop rdi
00007efc33fd3d02  pop rdx
00007efc33fd3d03  pop rcx
00007efc33fd3d04  pop rax
00007efc33fd3d05  add rsp, 0x08
00007efc33fd3d09  jmp 0x00007EFC33FD0015
00007efc33fd3d0e  sub rsp, 0x08
00007efc33fd3d12  push rax
00007efc33fd3d13  push rcx
00007efc33fd3d14  push rdx
00007efc33fd3d15  push rdi
00007efc33fd3d16  push rsi
00007efc33fd3d17  push r8
00007efc33fd3d19  push r9
00007efc33fd3d1b  push r10
00007efc33fd3d1d  push r11
00007efc33fd3d1f  sub rsp, 0xF0
00007efc33fd3d26  vmovaps [rsp], xmm0
00007efc33fd3d2b  vmovaps [rsp+0x10], xmm1
00007efc33fd3d31  vmovaps [rsp+0x20], xmm2
00007efc33fd3d37  vmovaps [rsp+0x30], xmm3
00007efc33fd3d3d  vmovaps [rsp+0x40], xmm4
00007efc33fd3d43  vmovaps [rsp+0x50], xmm5
00007efc33fd3d49  vmovaps [rsp+0x60], xmm6
00007efc33fd3d4f  vmovaps [rsp+0x70], xmm7
00007efc33fd3d55  vmovaps [rsp+0x80], xmm8
00007efc33fd3d5e  vmovaps [rsp+0x90], xmm9
00007efc33fd3d67  vmovaps [rsp+0xA0], xmm10
00007efc33fd3d70  vmovaps [rsp+0xB0], xmm12
00007efc33fd3d79  vmovaps [rsp+0xC0], xmm13
00007efc33fd3d82  vmovaps [rsp+0xD0], xmm14
00007efc33fd3d8b  vmovaps [rsp+0xE0], xmm15
00007efc33fd3d94  sub rsp, 0x30
00007efc33fd3d98  movaps [rsp], xmm11
00007efc33fd3d9d  movaps [rsp+0x10], xmm13
00007efc33fd3da3  movaps [rsp+0x20], xmm14
00007efc33fd3da9  lea rdi, [rsp]
00007efc33fd3dad  mov esi, 0x00
00007efc33fd3db2  mov rax, 0x5D9448894530
00007efc33fd3dbc  call rax
00007efc33fd3dbe  movaps xmm11, [rsp]
00007efc33fd3dc3  add rsp, 0x30
00007efc33fd3dc7  vmovaps xmm0, [rsp]
00007efc33fd3dcc  vmovaps xmm1, [rsp+0x10]
00007efc33fd3dd2  vmovaps xmm2, [rsp+0x20]
00007efc33fd3dd8  vmovaps xmm3, [rsp+0x30]
00007efc33fd3dde  vmovaps xmm4, [rsp+0x40]
00007efc33fd3de4  vmovaps xmm5, [rsp+0x50]
00007efc33fd3dea  vmovaps xmm6, [rsp+0x60]
00007efc33fd3df0  vmovaps xmm7, [rsp+0x70]
00007efc33fd3df6  vmovaps xmm8, [rsp+0x80]
00007efc33fd3dff  vmovaps xmm9, [rsp+0x90]
00007efc33fd3e08  vmovaps xmm10, [rsp+0xA0]
00007efc33fd3e11  vmovaps xmm12, [rsp+0xB0]
00007efc33fd3e1a  vmovaps xmm13, [rsp+0xC0]
00007efc33fd3e23  vmovaps xmm14, [rsp+0xD0]
00007efc33fd3e2c  vmovaps xmm15, [rsp+0xE0]
00007efc33fd3e35  add rsp, 0xF0
00007efc33fd3e3c  pop r11
00007efc33fd3e3e  pop r10
00007efc33fd3e40  pop r9
00007efc33fd3e42  pop r8
00007efc33fd3e44  pop rsi
00007efc33fd3e45  pop rdi
00007efc33fd3e46  pop rdx
00007efc33fd3e47  pop rcx
00007efc33fd3e48  pop rax
00007efc33fd3e49  add rsp, 0x08
00007efc33fd3e4d  jmp 0x00007EFC33FD003F
00007efc33fd3e52  sub rsp, 0x08
00007efc33fd3e56  push rax
00007efc33fd3e57  push rcx
00007efc33fd3e58  push rdx
00007efc33fd3e59  push rdi
00007efc33fd3e5a  push rsi
00007efc33fd3e5b  push r8
00007efc33fd3e5d  push r9
00007efc33fd3e5f  push r10
00007efc33fd3e61  push r11
00007efc33fd3e63  sub rsp, 0xF0
00007efc33fd3e6a  vmovaps [rsp], xmm0
00007efc33fd3e6f  vmovaps [rsp+0x10], xmm1
00007efc33fd3e75  vmovaps [rsp+0x20], xmm2
00007efc33fd3e7b  vmovaps [rsp+0x30], xmm3
00007efc33fd3e81  vmovaps [rsp+0x40], xmm4
00007efc33fd3e87  vmovaps [rsp+0x50], xmm5
00007efc33fd3e8d  vmovaps [rsp+0x60], xmm6
00007efc33fd3e93  vmovaps [rsp+0x70], xmm7
00007efc33fd3e99  vmovaps [rsp+0x80], xmm8
00007efc33fd3ea2  vmovaps [rsp+0x90], xmm9
00007efc33fd3eab  vmovaps [rsp+0xA0], xmm10
00007efc33fd3eb4  vmovaps [rsp+0xB0], xmm11
00007efc33fd3ebd  vmovaps [rsp+0xC0], xmm12
00007efc33fd3ec6  vmovaps [rsp+0xD0], xmm14
00007efc33fd3ecf  vmovaps [rsp+0xE0], xmm15
00007efc33fd3ed8  sub rsp, 0x30
00007efc33fd3edc  movaps [rsp], xmm13
00007efc33fd3ee1  movaps [rsp+0x10], xmm8
00007efc33fd3ee7  movaps [rsp+0x20], xmm14
00007efc33fd3eed  lea rdi, [rsp]
00007efc33fd3ef1  mov esi, 0x00
00007efc33fd3ef6  mov rax, 0x5D9448894530
00007efc33fd3f00  call rax
00007efc33fd3f02  movaps xmm13, [rsp]
00007efc33fd3f07  add rsp, 0x30
00007efc33fd3f0b  vmovaps xmm0, [rsp]
00007efc33fd3f10  vmovaps xmm1, [rsp+0x10]
00007efc33fd3f16  vmovaps xmm2, [rsp+0x20]
00007efc33fd3f1c  vmovaps xmm3, [rsp+0x30]
00007efc33fd3f22  vmovaps xmm4, [rsp+0x40]
00007efc33fd3f28  vmovaps xmm5, [rsp+0x50]
00007efc33fd3f2e  vmovaps xmm6, [rsp+0x60]
00007efc33fd3f34  vmovaps xmm7, [rsp+0x70]
00007efc33fd3f3a  vmovaps xmm8, [rsp+0x80]
00007efc33fd3f43  vmovaps xmm9, [rsp+0x90]
00007efc33fd3f4c  vmovaps xmm10, [rsp+0xA0]
00007efc33fd3f55  vmovaps xmm11, [rsp+0xB0]
00007efc33fd3f5e  vmovaps xmm12, [rsp+0xC0]
00007efc33fd3f67  vmovaps xmm14, [rsp+0xD0]
00007efc33fd3f70  vmovaps xmm15, [rsp+0xE0]
00007efc33fd3f79  add rsp, 0xF0
00007efc33fd3f80  pop r11
00007efc33fd3f82  pop r10
00007efc33fd3f84  pop r9
00007efc33fd3f86  pop r8
00007efc33fd3f88  pop rsi
00007efc33fd3f89  pop rdi
00007efc33fd3f8a  pop rdx
00007efc33fd3f8b  pop rcx
00007efc33fd3f8c  pop rax
00007efc33fd3f8d  add rsp, 0x08
00007efc33fd3f91  jmp 0x00007EFC33FD006E
00007efc33fd3f96  sub rsp, 0x08
00007efc33fd3f9a  push rax
00007efc33fd3f9b  push rcx
00007efc33fd3f9c  push rdx
00007efc33fd3f9d  push rdi
00007efc33fd3f9e  push rsi
00007efc33fd3f9f  push r8
00007efc33fd3fa1  push r9
00007efc33fd3fa3  push r10
00007efc33fd3fa5  push r11
00007efc33fd3fa7  sub rsp, 0xF0
00007efc33fd3fae  vmovaps [rsp], xmm0
00007efc33fd3fb3  vmovaps [rsp+0x10], xmm1
00007efc33fd3fb9  vmovaps [rsp+0x20], xmm2
00007efc33fd3fbf  vmovaps [rsp+0x30], xmm3
00007efc33fd3fc5  vmovaps [rsp+0x40], xmm4
00007efc33fd3fcb  vmovaps [rsp+0x50], xmm5
00007efc33fd3fd1  vmovaps [rsp+0x60], xmm6
00007efc33fd3fd7  vmovaps [rsp+0x70], xmm7
00007efc33fd3fdd  vmovaps [rsp+0x80], xmm9
00007efc33fd3fe6  vmovaps [rsp+0x90], xmm10
00007efc33fd3fef  vmovaps [rsp+0xA0], xmm11
00007efc33fd3ff8  vmovaps [rsp+0xB0], xmm12
00007efc33fd4001  vmovaps [rsp+0xC0], xmm13
00007efc33fd400a  vmovaps [rsp+0xD0], xmm14
00007efc33fd4013  vmovaps [rsp+0xE0], xmm15
00007efc33fd401c  sub rsp, 0x30
00007efc33fd4020  movaps [rsp], xmm8
00007efc33fd4025  movaps [rsp+0x10], xmm7
00007efc33fd402a  movaps [rsp+0x20], xmm14
00007efc33fd4030  lea rdi, [rsp]
00007efc33fd4034  mov esi, 0x00
00007efc33fd4039  mov rax, 0x5D9448894530
00007efc33fd4043  call rax
00007efc33fd4045  movaps xmm8, [rsp]
00007efc33fd404a  add rsp, 0x30
00007efc33fd404e  vmovaps xmm0, [rsp]
00007efc33fd4053  vmovaps xmm1, [rsp+0x10]
00007efc33fd4059  vmovaps xmm2, [rsp+0x20]
00007efc33fd405f  vmovaps xmm3, [rsp+0x30]
00007efc33fd4065  vmovaps xmm4, [rsp+0x40]
00007efc33fd406b  vmovaps xmm5, [rsp+0x50]
00007efc33fd4071  vmovaps xmm6, [rsp+0x60]
00007efc33fd4077  vmovaps xmm7, [rsp+0x70]
00007efc33fd407d  vmovaps xmm9, [rsp+0x80]
00007efc33fd4086  vmovaps xmm10, [rsp+0x90]
00007efc33fd408f  vmovaps xmm11, [rsp+0xA0]
00007efc33fd4098  vmovaps xmm12, [rsp+0xB0]
00007efc33fd40a1  vmovaps xmm13, [rsp+0xC0]
00007efc33fd40aa  vmovaps xmm14, [rsp+0xD0]
00007efc33fd40b3  vmovaps xmm15, [rsp+0xE0]
00007efc33fd40bc  add rsp, 0xF0
00007efc33fd40c3  pop r11
00007efc33fd40c5  pop r10
00007efc33fd40c7  pop r9
00007efc33fd40c9  pop r8
00007efc33fd40cb  pop rsi
00007efc33fd40cc  pop rdi
00007efc33fd40cd  pop rdx
00007efc33fd40ce  pop rcx
00007efc33fd40cf  pop rax
00007efc33fd40d0  add rsp, 0x08
00007efc33fd40d4  jmp 0x00007EFC33FD0094
00007efc33fd40d9  sub rsp, 0x08
00007efc33fd40dd  push rax
00007efc33fd40de  push rcx
00007efc33fd40df  push rdx
00007efc33fd40e0  push rdi
00007efc33fd40e1  push rsi
00007efc33fd40e2  push r8
00007efc33fd40e4  push r9
00007efc33fd40e6  push r10
00007efc33fd40e8  push r11
00007efc33fd40ea  sub rsp, 0xF0
00007efc33fd40f1  vmovaps [rsp], xmm0
00007efc33fd40f6  vmovaps [rsp+0x10], xmm1
00007efc33fd40fc  vmovaps [rsp+0x20], xmm2
00007efc33fd4102  vmovaps [rsp+0x30], xmm3
00007efc33fd4108  vmovaps [rsp+0x40], xmm4
00007efc33fd410e  vmovaps [rsp+0x50], xmm5
00007efc33fd4114  vmovaps [rsp+0x60], xmm6
00007efc33fd411a  vmovaps [rsp+0x70], xmm7
00007efc33fd4120  vmovaps [rsp+0x80], xmm8
00007efc33fd4129  vmovaps [rsp+0x90], xmm9
00007efc33fd4132  vmovaps [rsp+0xA0], xmm10
00007efc33fd413b  vmovaps [rsp+0xB0], xmm11
00007efc33fd4144  vmovaps [rsp+0xC0], xmm12
00007efc33fd414d  vmovaps [rsp+0xD0], xmm13
00007efc33fd4156  vmovaps [rsp+0xE0], xmm15
00007efc33fd415f  sub rsp, 0x30
00007efc33fd4163  movaps [rsp], xmm14
00007efc33fd4168  movaps [rsp+0x10], xmm12
00007efc33fd416e  movaps [rsp+0x20], xmm9
00007efc33fd4174  lea rdi, [rsp]
00007efc33fd4178  mov esi, 0x00
00007efc33fd417d  mov rax, 0x5D9448894530
00007efc33fd4187  call rax
00007efc33fd4189  movaps xmm14, [rsp]
00007efc33fd418e  add rsp, 0x30
00007efc33fd4192  vmovaps xmm0, [rsp]
00007efc33fd4197  vmovaps xmm1, [rsp+0x10]
00007efc33fd419d  vmovaps xmm2, [rsp+0x20]
00007efc33fd41a3  vmovaps xmm3, [rsp+0x30]
00007efc33fd41a9  vmovaps xmm4, [rsp+0x40]
00007efc33fd41af  vmovaps xmm5, [rsp+0x50]
00007efc33fd41b5  vmovaps xmm6, [rsp+0x60]
00007efc33fd41bb  vmovaps xmm7, [rsp+0x70]
00007efc33fd41c1  vmovaps xmm8, [rsp+0x80]
00007efc33fd41ca  vmovaps xmm9, [rsp+0x90]
00007efc33fd41d3  vmovaps xmm10, [rsp+0xA0]
00007efc33fd41dc  vmovaps xmm11, [rsp+0xB0]
00007efc33fd41e5  vmovaps xmm12, [rsp+0xC0]
00007efc33fd41ee  vmovaps xmm13, [rsp+0xD0]
00007efc33fd41f7  vmovaps xmm15, [rsp+0xE0]
00007efc33fd4200  add rsp, 0xF0
00007efc33fd4207  pop r11
00007efc33fd4209  pop r10
00007efc33fd420b  pop r9
00007efc33fd420d  pop r8
00007efc33fd420f  pop rsi
00007efc33fd4210  pop rdi
00007efc33fd4211  pop rdx
00007efc33fd4212  pop rcx
00007efc33fd4213  pop rax
00007efc33fd4214  add rsp, 0x08
00007efc33fd4218  jmp 0x00007EFC33FD00AE
00007efc33fd421d  sub rsp, 0x08
00007efc33fd4221  push rax
00007efc33fd4222  push rcx
00007efc33fd4223  push rdx
00007efc33fd4224  push rdi
00007efc33fd4225  push rsi
00007efc33fd4226  push r8
00007efc33fd4228  push r9
00007efc33fd422a  push r10
00007efc33fd422c  push r11
00007efc33fd422e  sub rsp, 0xF0
00007efc33fd4235  vmovaps [rsp], xmm0
00007efc33fd423a  vmovaps [rsp+0x10], xmm1
00007efc33fd4240  vmovaps [rsp+0x20], xmm2
00007efc33fd4246  vmovaps [rsp+0x30], xmm3
00007efc33fd424c  vmovaps [rsp+0x40], xmm4
00007efc33fd4252  vmovaps [rsp+0x50], xmm5
00007efc33fd4258  vmovaps [rsp+0x60], xmm6
00007efc33fd425e  vmovaps [rsp+0x70], xmm7
00007efc33fd4264  vmovaps [rsp+0x80], xmm8
00007efc33fd426d  vmovaps [rsp+0x90], xmm10
00007efc33fd4276  vmovaps [rsp+0xA0], xmm11
00007efc33fd427f  vmovaps [rsp+0xB0], xmm12
00007efc33fd4288  vmovaps [rsp+0xC0], xmm13
00007efc33fd4291  vmovaps [rsp+0xD0], xmm14
00007efc33fd429a  vmovaps [rsp+0xE0], xmm15
00007efc33fd42a3  sub rsp, 0x30
00007efc33fd42a7  movaps [rsp], xmm9
00007efc33fd42ac  movaps [rsp+0x10], xmm7
00007efc33fd42b1  movaps [rsp+0x20], xmm12
00007efc33fd42b7  lea rdi, [rsp]
00007efc33fd42bb  mov esi, 0x00
00007efc33fd42c0  mov rax, 0x5D9448894530
00007efc33fd42ca  call rax
00007efc33fd42cc  movaps xmm9, [rsp]
00007efc33fd42d1  add rsp, 0x30
00007efc33fd42d5  vmovaps xmm0, [rsp]
00007efc33fd42da  vmovaps xmm1, [rsp+0x10]
00007efc33fd42e0  vmovaps xmm2, [rsp+0x20]
00007efc33fd42e6  vmovaps xmm3, [rsp+0x30]
00007efc33fd42ec  vmovaps xmm4, [rsp+0x40]
00007efc33fd42f2  vmovaps xmm5, [rsp+0x50]
00007efc33fd42f8  vmovaps xmm6, [rsp+0x60]
00007efc33fd42fe  vmovaps xmm7, [rsp+0x70]
00007efc33fd4304  vmovaps xmm8, [rsp+0x80]
00007efc33fd430d  vmovaps xmm10, [rsp+0x90]
00007efc33fd4316  vmovaps xmm11, [rsp+0xA0]
00007efc33fd431f  vmovaps xmm12, [rsp+0xB0]
00007efc33fd4328  vmovaps xmm13, [rsp+0xC0]
00007efc33fd4331  vmovaps xmm14, [rsp+0xD0]
00007efc33fd433a  vmovaps xmm15, [rsp+0xE0]
00007efc33fd4343  add rsp, 0xF0
00007efc33fd434a  pop r11
00007efc33fd434c  pop r10
00007efc33fd434e  pop r9
00007efc33fd4350  pop r8
00007efc33fd4352  pop rsi
00007efc33fd4353  pop rdi
00007efc33fd4354  pop rdx
00007efc33fd4355  pop rcx
00007efc33fd4356  pop rax
00007efc33fd4357  add rsp, 0x08
00007efc33fd435b  jmp 0x00007EFC33FD00DD
00007efc33fd4360  sub rsp, 0x08
00007efc33fd4364  push rax
00007efc33fd4365  push rcx
00007efc33fd4366  push rdx
00007efc33fd4367  push rdi
00007efc33fd4368  push rsi
00007efc33fd4369  push r8
00007efc33fd436b  push r9
00007efc33fd436d  push r10
00007efc33fd436f  push r11
00007efc33fd4371  sub rsp, 0xF0
00007efc33fd4378  vmovaps [rsp], xmm0
00007efc33fd437d  vmovaps [rsp+0x10], xmm1
00007efc33fd4383  vmovaps [rsp+0x20], xmm2
00007efc33fd4389  vmovaps [rsp+0x30], xmm3
00007efc33fd438f  vmovaps [rsp+0x40], xmm4
00007efc33fd4395  vmovaps [rsp+0x50], xmm5
00007efc33fd439b  vmovaps [rsp+0x60], xmm6
00007efc33fd43a1  vmovaps [rsp+0x70], xmm7
00007efc33fd43a7  vmovaps [rsp+0x80], xmm8
00007efc33fd43b0  vmovaps [rsp+0x90], xmm9
00007efc33fd43b9  vmovaps [rsp+0xA0], xmm10
00007efc33fd43c2  vmovaps [rsp+0xB0], xmm11
00007efc33fd43cb  vmovaps [rsp+0xC0], xmm13
00007efc33fd43d4  vmovaps [rsp+0xD0], xmm14
00007efc33fd43dd  vmovaps [rsp+0xE0], xmm15
00007efc33fd43e6  sub rsp, 0x30
00007efc33fd43ea  movaps [rsp], xmm12
00007efc33fd43ef  movaps [rsp+0x10], xmm15
00007efc33fd43f5  movaps [rsp+0x20], xmm11
00007efc33fd43fb  lea rdi, [rsp]
00007efc33fd43ff  mov esi, 0x00
00007efc33fd4404  mov rax, 0x5D9448894530
00007efc33fd440e  call rax
00007efc33fd4410  movaps xmm12, [rsp]
00007efc33fd4415  add rsp, 0x30
00007efc33fd4419  vmovaps xmm0, [rsp]
00007efc33fd441e  vmovaps xmm1, [rsp+0x10]
00007efc33fd4424  vmovaps xmm2, [rsp+0x20]
00007efc33fd442a  vmovaps xmm3, [rsp+0x30]
00007efc33fd4430  vmovaps xmm4, [rsp+0x40]
00007efc33fd4436  vmovaps xmm5, [rsp+0x50]
00007efc33fd443c  vmovaps xmm6, [rsp+0x60]
00007efc33fd4442  vmovaps xmm7, [rsp+0x70]
00007efc33fd4448  vmovaps xmm8, [rsp+0x80]
00007efc33fd4451  vmovaps xmm9, [rsp+0x90]
00007efc33fd445a  vmovaps xmm10, [rsp+0xA0]
00007efc33fd4463  vmovaps xmm11, [rsp+0xB0]
00007efc33fd446c  vmovaps xmm13, [rsp+0xC0]
00007efc33fd4475  vmovaps xmm14, [rsp+0xD0]
00007efc33fd447e  vmovaps xmm15, [rsp+0xE0]
00007efc33fd4487  add rsp, 0xF0
00007efc33fd448e  pop r11
00007efc33fd4490  pop r10
00007efc33fd4492  pop r9
00007efc33fd4494  pop r8
00007efc33fd4496  pop rsi
00007efc33fd4497  pop rdi
00007efc33fd4498  pop rdx
00007efc33fd4499  pop rcx
00007efc33fd449a  pop rax
00007efc33fd449b  add rsp, 0x08
00007efc33fd449f  jmp 0x00007EFC33FD00F7
00007efc33fd44a4  sub rsp, 0x08
00007efc33fd44a8  push rax
00007efc33fd44a9  push rcx
00007efc33fd44aa  push rdx
00007efc33fd44ab  push rdi
00007efc33fd44ac  push rsi
00007efc33fd44ad  push r8
00007efc33fd44af  push r9
00007efc33fd44b1  push r10
00007efc33fd44b3  push r11
00007efc33fd44b5  sub rsp, 0xF0
00007efc33fd44bc  vmovaps [rsp], xmm0
00007efc33fd44c1  vmovaps [rsp+0x10], xmm1
00007efc33fd44c7  vmovaps [rsp+0x20], xmm2
00007efc33fd44cd  vmovaps [rsp+0x30], xmm3
00007efc33fd44d3  vmovaps [rsp+0x40], xmm4
00007efc33fd44d9  vmovaps [rsp+0x50], xmm5
00007efc33fd44df  vmovaps [rsp+0x60], xmm6
00007efc33fd44e5  vmovaps [rsp+0x70], xmm7
00007efc33fd44eb  vmovaps [rsp+0x80], xmm8
00007efc33fd44f4  vmovaps [rsp+0x90], xmm9
00007efc33fd44fd  vmovaps [rsp+0xA0], xmm10
00007efc33fd4506  vmovaps [rsp+0xB0], xmm12
00007efc33fd450f  vmovaps [rsp+0xC0], xmm13
00007efc33fd4518  vmovaps [rsp+0xD0], xmm14
00007efc33fd4521  vmovaps [rsp+0xE0], xmm15
00007efc33fd452a  sub rsp, 0x30
00007efc33fd452e  movaps [rsp], xmm11
00007efc33fd4533  movaps [rsp+0x10], xmm7
00007efc33fd4538  movaps [rsp+0x20], xmm15
00007efc33fd453e  lea rdi, [rsp]
00007efc33fd4542  mov esi, 0x00
00007efc33fd4547  mov rax, 0x5D9448894530
00007efc33fd4551  call rax
00007efc33fd4553  movaps xmm11, [rsp]
00007efc33fd4558  add rsp, 0x30
00007efc33fd455c  vmovaps xmm0, [rsp]
00007efc33fd4561  vmovaps xmm1, [rsp+0x10]
00007efc33fd4567  vmovaps xmm2, [rsp+0x20]
00007efc33fd456d  vmovaps xmm3, [rsp+0x30]
00007efc33fd4573  vmovaps xmm4, [rsp+0x40]
00007efc33fd4579  vmovaps xmm5, [rsp+0x50]
00007efc33fd457f  vmovaps xmm6, [rsp+0x60]
00007efc33fd4585  vmovaps xmm7, [rsp+0x70]
00007efc33fd458b  vmovaps xmm8, [rsp+0x80]
00007efc33fd4594  vmovaps xmm9, [rsp+0x90]
00007efc33fd459d  vmovaps xmm10, [rsp+0xA0]
00007efc33fd45a6  vmovaps xmm12, [rsp+0xB0]
00007efc33fd45af  vmovaps xmm13, [rsp+0xC0]
00007efc33fd45b8  vmovaps xmm14, [rsp+0xD0]
00007efc33fd45c1  vmovaps xmm15, [rsp+0xE0]
00007efc33fd45ca  add rsp, 0xF0
00007efc33fd45d1  pop r11
00007efc33fd45d3  pop r10
00007efc33fd45d5  pop r9
00007efc33fd45d7  pop r8
00007efc33fd45d9  pop rsi
00007efc33fd45da  pop rdi
00007efc33fd45db  pop rdx
00007efc33fd45dc  pop rcx
00007efc33fd45dd  pop rax
00007efc33fd45de  add rsp, 0x08
00007efc33fd45e2  jmp 0x00007EFC33FD0123
00007efc33fd45e7  sub rsp, 0x08
00007efc33fd45eb  push rax
00007efc33fd45ec  push rcx
00007efc33fd45ed  push rdx
00007efc33fd45ee  push rdi
00007efc33fd45ef  push rsi
00007efc33fd45f0  push r8
00007efc33fd45f2  push r9
00007efc33fd45f4  push r10
00007efc33fd45f6  push r11
00007efc33fd45f8  sub rsp, 0xF0
00007efc33fd45ff  vmovaps [rsp], xmm0
00007efc33fd4604  vmovaps [rsp+0x10], xmm1
00007efc33fd460a  vmovaps [rsp+0x20], xmm2
00007efc33fd4610  vmovaps [rsp+0x30], xmm3
00007efc33fd4616  vmovaps [rsp+0x40], xmm4
00007efc33fd461c  vmovaps [rsp+0x50], xmm5
00007efc33fd4622  vmovaps [rsp+0x60], xmm6
00007efc33fd4628  vmovaps [rsp+0x70], xmm7
00007efc33fd462e  vmovaps [rsp+0x80], xmm8
00007efc33fd4637  vmovaps [rsp+0x90], xmm9
00007efc33fd4640  vmovaps [rsp+0xA0], xmm10
00007efc33fd4649  vmovaps [rsp+0xB0], xmm11
00007efc33fd4652  vmovaps [rsp+0xC0], xmm12
00007efc33fd465b  vmovaps [rsp+0xD0], xmm13
00007efc33fd4664  vmovaps [rsp+0xE0], xmm14
00007efc33fd466d  sub rsp, 0x30
00007efc33fd4671  movaps [rsp], xmm15
00007efc33fd4676  movaps [rsp+0x10], xmm10
00007efc33fd467c  movaps [rsp+0x20], xmm13
00007efc33fd4682  lea rdi, [rsp]
00007efc33fd4686  mov esi, 0x00
00007efc33fd468b  mov rax, 0x5D9448894530
00007efc33fd4695  call rax
00007efc33fd4697  movaps xmm15, [rsp]
00007efc33fd469c  add rsp, 0x30
00007efc33fd46a0  vmovaps xmm0, [rsp]
00007efc33fd46a5  vmovaps xmm1, [rsp+0x10]
00007efc33fd46ab  vmovaps xmm2, [rsp+0x20]
00007efc33fd46b1  vmovaps xmm3, [rsp+0x30]
00007efc33fd46b7  vmovaps xmm4, [rsp+0x40]
00007efc33fd46bd  vmovaps xmm5, [rsp+0x50]
00007efc33fd46c3  vmovaps xmm6, [rsp+0x60]
00007efc33fd46c9  vmovaps xmm7, [rsp+0x70]
00007efc33fd46cf  vmovaps xmm8, [rsp+0x80]
00007efc33fd46d8  vmovaps xmm9, [rsp+0x90]
00007efc33fd46e1  vmovaps xmm10, [rsp+0xA0]
00007efc33fd46ea  vmovaps xmm11, [rsp+0xB0]
00007efc33fd46f3  vmovaps xmm12, [rsp+0xC0]
00007efc33fd46fc  vmovaps xmm13, [rsp+0xD0]
00007efc33fd4705  vmovaps xmm14, [rsp+0xE0]
00007efc33fd470e  add rsp, 0xF0
00007efc33fd4715  pop r11
00007efc33fd4717  pop r10
00007efc33fd4719  pop r9
00007efc33fd471b  pop r8
00007efc33fd471d  pop rsi
00007efc33fd471e  pop rdi
00007efc33fd471f  pop rdx
00007efc33fd4720  pop rcx
00007efc33fd4721  pop rax
00007efc33fd4722  add rsp, 0x08
00007efc33fd4726  jmp 0x00007EFC33FD013D
00007efc33fd472b  sub rsp, 0x08
00007efc33fd472f  push rax
00007efc33fd4730  push rcx
00007efc33fd4731  push rdx
00007efc33fd4732  push rdi
00007efc33fd4733  push rsi
00007efc33fd4734  push r8
00007efc33fd4736  push r9
00007efc33fd4738  push r10
00007efc33fd473a  push r11
00007efc33fd473c  sub rsp, 0xF0
00007efc33fd4743  vmovaps [rsp], xmm0
00007efc33fd4748  vmovaps [rsp+0x10], xmm1
00007efc33fd474e  vmovaps [rsp+0x20], xmm2
00007efc33fd4754  vmovaps [rsp+0x30], xmm3
00007efc33fd475a  vmovaps [rsp+0x40], xmm4
00007efc33fd4760  vmovaps [rsp+0x50], xmm5
00007efc33fd4766  vmovaps [rsp+0x60], xmm6
00007efc33fd476c  vmovaps [rsp+0x70], xmm7
00007efc33fd4772  vmovaps [rsp+0x80], xmm8
00007efc33fd477b  vmovaps [rsp+0x90], xmm9
00007efc33fd4784  vmovaps [rsp+0xA0], xmm11
00007efc33fd478d  vmovaps [rsp+0xB0], xmm12
00007efc33fd4796  vmovaps [rsp+0xC0], xmm13
00007efc33fd479f  vmovaps [rsp+0xD0], xmm14
00007efc33fd47a8  vmovaps [rsp+0xE0], xmm15
00007efc33fd47b1  sub rsp, 0x30
00007efc33fd47b5  movaps [rsp], xmm10
00007efc33fd47ba  movaps [rsp+0x10], xmm7
00007efc33fd47bf  movaps [rsp+0x20], xmm13
00007efc33fd47c5  lea rdi, [rsp]
00007efc33fd47c9  mov esi, 0x00
00007efc33fd47ce  mov rax, 0x5D9448894530
00007efc33fd47d8  call rax
00007efc33fd47da  movaps xmm10, [rsp]
00007efc33fd47df  add rsp, 0x30
00007efc33fd47e3  vmovaps xmm0, [rsp]
00007efc33fd47e8  vmovaps xmm1, [rsp+0x10]
00007efc33fd47ee  vmovaps xmm2, [rsp+0x20]
00007efc33fd47f4  vmovaps xmm3, [rsp+0x30]
00007efc33fd47fa  vmovaps xmm4, [rsp+0x40]
00007efc33fd4800  vmovaps xmm5, [rsp+0x50]
00007efc33fd4806  vmovaps xmm6, [rsp+0x60]
00007efc33fd480c  vmovaps xmm7, [rsp+0x70]
00007efc33fd4812  vmovaps xmm8, [rsp+0x80]
00007efc33fd481b  vmovaps xmm9, [rsp+0x90]
00007efc33fd4824  vmovaps xmm11, [rsp+0xA0]
00007efc33fd482d  vmovaps xmm12, [rsp+0xB0]
00007efc33fd4836  vmovaps xmm13, [rsp+0xC0]
00007efc33fd483f  vmovaps xmm14, [rsp+0xD0]
00007efc33fd4848  vmovaps xmm15, [rsp+0xE0]
00007efc33fd4851  add rsp, 0xF0
00007efc33fd4858  pop r11
00007efc33fd485a  pop r10
00007efc33fd485c  pop r9
00007efc33fd485e  pop r8
00007efc33fd4860  pop rsi
00007efc33fd4861  pop rdi
00007efc33fd4862  pop rdx
00007efc33fd4863  pop rcx
00007efc33fd4864  pop rax
00007efc33fd4865  add rsp, 0x08
00007efc33fd4869  jmp 0x00007EFC33FD0169
00007efc33fd486e  sub rsp, 0x08
00007efc33fd4872  push rax
00007efc33fd4873  push rcx
00007efc33fd4874  push rdx
00007efc33fd4875  push rdi
00007efc33fd4876  push rsi
00007efc33fd4877  push r8
00007efc33fd4879  push r9
00007efc33fd487b  push r10
00007efc33fd487d  push r11
00007efc33fd487f  sub rsp, 0xF0
00007efc33fd4886  vmovaps [rsp], xmm0
00007efc33fd488b  vmovaps [rsp+0x10], xmm1
00007efc33fd4891  vmovaps [rsp+0x20], xmm2
00007efc33fd4897  vmovaps [rsp+0x30], xmm3
00007efc33fd489d  vmovaps [rsp+0x40], xmm4
00007efc33fd48a3  vmovaps [rsp+0x50], xmm5
00007efc33fd48a9  vmovaps [rsp+0x60], xmm6
00007efc33fd48af  vmovaps [rsp+0x70], xmm7
00007efc33fd48b5  vmovaps [rsp+0x80], xmm8
00007efc33fd48be  vmovaps [rsp+0x90], xmm9
00007efc33fd48c7  vmovaps [rsp+0xA0], xmm10
00007efc33fd48d0  vmovaps [rsp+0xB0], xmm11
00007efc33fd48d9  vmovaps [rsp+0xC0], xmm12
00007efc33fd48e2  vmovaps [rsp+0xD0], xmm14
00007efc33fd48eb  vmovaps [rsp+0xE0], xmm15
00007efc33fd48f4  sub rsp, 0x30
00007efc33fd48f8  movaps [rsp], xmm13
00007efc33fd48fd  movaps [rsp+0x10], xmm1
00007efc33fd4902  movaps [rsp+0x20], xmm8
00007efc33fd4908  lea rdi, [rsp]
00007efc33fd490c  mov esi, 0x00
00007efc33fd4911  mov rax, 0x5D9448894530
00007efc33fd491b  call rax
00007efc33fd491d  movaps xmm13, [rsp]
00007efc33fd4922  add rsp, 0x30
00007efc33fd4926  vmovaps xmm0, [rsp]
00007efc33fd492b  vmovaps xmm1, [rsp+0x10]
00007efc33fd4931  vmovaps xmm2, [rsp+0x20]
00007efc33fd4937  vmovaps xmm3, [rsp+0x30]
00007efc33fd493d  vmovaps xmm4, [rsp+0x40]
00007efc33fd4943  vmovaps xmm5, [rsp+0x50]
00007efc33fd4949  vmovaps xmm6, [rsp+0x60]
00007efc33fd494f  vmovaps xmm7, [rsp+0x70]
00007efc33fd4955  vmovaps xmm8, [rsp+0x80]
00007efc33fd495e  vmovaps xmm9, [rsp+0x90]
00007efc33fd4967  vmovaps xmm10, [rsp+0xA0]
00007efc33fd4970  vmovaps xmm11, [rsp+0xB0]
00007efc33fd4979  vmovaps xmm12, [rsp+0xC0]
00007efc33fd4982  vmovaps xmm14, [rsp+0xD0]
00007efc33fd498b  vmovaps xmm15, [rsp+0xE0]
00007efc33fd4994  add rsp, 0xF0
00007efc33fd499b  pop r11
00007efc33fd499d  pop r10
00007efc33fd499f  pop r9
00007efc33fd49a1  pop r8
00007efc33fd49a3  pop rsi
00007efc33fd49a4  pop rdi
00007efc33fd49a5  pop rdx
00007efc33fd49a6  pop rcx
00007efc33fd49a7  pop rax
00007efc33fd49a8  add rsp, 0x08
00007efc33fd49ac  jmp 0x00007EFC33FD0183
00007efc33fd49b1  call 0x00007EFC33DFF430
00007efc33fd49b6  jmp 0x00007EFC33FD018D
00007efc33fd49bb  sub rsp, 0x08
00007efc33fd49bf  push rax
00007efc33fd49c0  push rcx
00007efc33fd49c1  push rdx
00007efc33fd49c2  push rdi
00007efc33fd49c3  push rsi
00007efc33fd49c4  push r8
00007efc33fd49c6  push r9
00007efc33fd49c8  push r10
00007efc33fd49ca  push r11
00007efc33fd49cc  sub rsp, 0xF0
00007efc33fd49d3  vmovaps [rsp], xmm0
00007efc33fd49d8  vmovaps [rsp+0x10], xmm1
00007efc33fd49de  vmovaps [rsp+0x20], xmm2
00007efc33fd49e4  vmovaps [rsp+0x30], xmm3
00007efc33fd49ea  vmovaps [rsp+0x40], xmm4
00007efc33fd49f0  vmovaps [rsp+0x50], xmm5
00007efc33fd49f6  vmovaps [rsp+0x60], xmm6
00007efc33fd49fc  vmovaps [rsp+0x70], xmm7
00007efc33fd4a02  vmovaps [rsp+0x80], xmm9
00007efc33fd4a0b  vmovaps [rsp+0x90], xmm10
00007efc33fd4a14  vmovaps [rsp+0xA0], xmm11
00007efc33fd4a1d  vmovaps [rsp+0xB0], xmm12
00007efc33fd4a26  vmovaps [rsp+0xC0], xmm13
00007efc33fd4a2f  vmovaps [rsp+0xD0], xmm14
00007efc33fd4a38  vmovaps [rsp+0xE0], xmm15
00007efc33fd4a41  sub rsp, 0x30
00007efc33fd4a45  movaps [rsp], xmm8
00007efc33fd4a4a  movaps [rsp+0x10], xmm14
00007efc33fd4a50  movaps [rsp+0x20], xmm9
00007efc33fd4a56  lea rdi, [rsp]
00007efc33fd4a5a  mov esi, 0x00
00007efc33fd4a5f  mov rax, 0x5D9448894530
00007efc33fd4a69  call rax
00007efc33fd4a6b  movaps xmm8, [rsp]
00007efc33fd4a70  add rsp, 0x30
00007efc33fd4a74  vmovaps xmm0, [rsp]
00007efc33fd4a79  vmovaps xmm1, [rsp+0x10]
00007efc33fd4a7f  vmovaps xmm2, [rsp+0x20]
00007efc33fd4a85  vmovaps xmm3, [rsp+0x30]
00007efc33fd4a8b  vmovaps xmm4, [rsp+0x40]
00007efc33fd4a91  vmovaps xmm5, [rsp+0x50]
00007efc33fd4a97  vmovaps xmm6, [rsp+0x60]
00007efc33fd4a9d  vmovaps xmm7, [rsp+0x70]
00007efc33fd4aa3  vmovaps xmm9, [rsp+0x80]
00007efc33fd4aac  vmovaps xmm10, [rsp+0x90]
00007efc33fd4ab5  vmovaps xmm11, [rsp+0xA0]
00007efc33fd4abe  vmovaps xmm12, [rsp+0xB0]
00007efc33fd4ac7  vmovaps xmm13, [rsp+0xC0]
00007efc33fd4ad0  vmovaps xmm14, [rsp+0xD0]
00007efc33fd4ad9  vmovaps xmm15, [rsp+0xE0]
00007efc33fd4ae2  add rsp, 0xF0
00007efc33fd4ae9  pop r11
00007efc33fd4aeb  pop r10
00007efc33fd4aed  pop r9
00007efc33fd4aef  pop r8
00007efc33fd4af1  pop rsi
00007efc33fd4af2  pop rdi
00007efc33fd4af3  pop rdx
00007efc33fd4af4  pop rcx
00007efc33fd4af5  pop rax
00007efc33fd4af6  add rsp, 0x08
00007efc33fd4afa  jmp 0x00007EFC33FD01AF
00007efc33fd4aff  sub rsp, 0x08
00007efc33fd4b03  push rax
00007efc33fd4b04  push rcx
00007efc33fd4b05  push rdx
00007efc33fd4b06  push rdi
00007efc33fd4b07  push rsi
00007efc33fd4b08  push r8
00007efc33fd4b0a  push r9
00007efc33fd4b0c  push r10
00007efc33fd4b0e  push r11
00007efc33fd4b10  sub rsp, 0xF0
00007efc33fd4b17  vmovaps [rsp], xmm0
00007efc33fd4b1c  vmovaps [rsp+0x10], xmm1
00007efc33fd4b22  vmovaps [rsp+0x20], xmm2
00007efc33fd4b28  vmovaps [rsp+0x30], xmm3
00007efc33fd4b2e  vmovaps [rsp+0x40], xmm4
00007efc33fd4b34  vmovaps [rsp+0x50], xmm5
00007efc33fd4b3a  vmovaps [rsp+0x60], xmm6
00007efc33fd4b40  vmovaps [rsp+0x70], xmm7
00007efc33fd4b46  vmovaps [rsp+0x80], xmm8
00007efc33fd4b4f  vmovaps [rsp+0x90], xmm10
00007efc33fd4b58  vmovaps [rsp+0xA0], xmm11
00007efc33fd4b61  vmovaps [rsp+0xB0], xmm12
00007efc33fd4b6a  vmovaps [rsp+0xC0], xmm13
00007efc33fd4b73  vmovaps [rsp+0xD0], xmm14
00007efc33fd4b7c  vmovaps [rsp+0xE0], xmm15
00007efc33fd4b85  sub rsp, 0x30
00007efc33fd4b89  movaps [rsp], xmm9
00007efc33fd4b8e  movaps [rsp+0x10], xmm1
00007efc33fd4b93  movaps [rsp+0x20], xmm14
00007efc33fd4b99  lea rdi, [rsp]
00007efc33fd4b9d  mov esi, 0x00
00007efc33fd4ba2  mov rax, 0x5D9448894530
00007efc33fd4bac  call rax
00007efc33fd4bae  movaps xmm9, [rsp]
00007efc33fd4bb3  add rsp, 0x30
00007efc33fd4bb7  vmovaps xmm0, [rsp]
00007efc33fd4bbc  vmovaps xmm1, [rsp+0x10]
00007efc33fd4bc2  vmovaps xmm2, [rsp+0x20]
00007efc33fd4bc8  vmovaps xmm3, [rsp+0x30]
00007efc33fd4bce  vmovaps xmm4, [rsp+0x40]
00007efc33fd4bd4  vmovaps xmm5, [rsp+0x50]
00007efc33fd4bda  vmovaps xmm6, [rsp+0x60]
00007efc33fd4be0  vmovaps xmm7, [rsp+0x70]
00007efc33fd4be6  vmovaps xmm8, [rsp+0x80]
00007efc33fd4bef  vmovaps xmm10, [rsp+0x90]
00007efc33fd4bf8  vmovaps xmm11, [rsp+0xA0]
00007efc33fd4c01  vmovaps xmm12, [rsp+0xB0]
00007efc33fd4c0a  vmovaps xmm13, [rsp+0xC0]
00007efc33fd4c13  vmovaps xmm14, [rsp+0xD0]
00007efc33fd4c1c  vmovaps xmm15, [rsp+0xE0]
00007efc33fd4c25  add rsp, 0xF0
00007efc33fd4c2c  pop r11
00007efc33fd4c2e  pop r10
00007efc33fd4c30  pop r9
00007efc33fd4c32  pop r8
00007efc33fd4c34  pop rsi
00007efc33fd4c35  pop rdi
00007efc33fd4c36  pop rdx
00007efc33fd4c37  pop rcx
00007efc33fd4c38  pop rax
00007efc33fd4c39  add rsp, 0x08
00007efc33fd4c3d  jmp 0x00007EFC33FD01DD
00007efc33fd4c42  sub rsp, 0x08
00007efc33fd4c46  push rax
00007efc33fd4c47  push rcx
00007efc33fd4c48  push rdx
00007efc33fd4c49  push rdi
00007efc33fd4c4a  push rsi
00007efc33fd4c4b  push r8
00007efc33fd4c4d  push r9
00007efc33fd4c4f  push r10
00007efc33fd4c51  push r11
00007efc33fd4c53  sub rsp, 0xF0
00007efc33fd4c5a  vmovaps [rsp], xmm0
00007efc33fd4c5f  vmovaps [rsp+0x10], xmm1
00007efc33fd4c65  vmovaps [rsp+0x20], xmm2
00007efc33fd4c6b  vmovaps [rsp+0x30], xmm3
00007efc33fd4c71  vmovaps [rsp+0x40], xmm4
00007efc33fd4c77  vmovaps [rsp+0x50], xmm5
00007efc33fd4c7d  vmovaps [rsp+0x60], xmm6
00007efc33fd4c83  vmovaps [rsp+0x70], xmm7
00007efc33fd4c89  vmovaps [rsp+0x80], xmm8
00007efc33fd4c92  vmovaps [rsp+0x90], xmm9
00007efc33fd4c9b  vmovaps [rsp+0xA0], xmm10
00007efc33fd4ca4  vmovaps [rsp+0xB0], xmm11
00007efc33fd4cad  vmovaps [rsp+0xC0], xmm12
00007efc33fd4cb6  vmovaps [rsp+0xD0], xmm13
00007efc33fd4cbf  vmovaps [rsp+0xE0], xmm15
00007efc33fd4cc8  sub rsp, 0x30
00007efc33fd4ccc  movaps [rsp], xmm14
00007efc33fd4cd1  movaps [rsp+0x10], xmm4
00007efc33fd4cd6  movaps [rsp+0x20], xmm1
00007efc33fd4cdb  lea rdi, [rsp]
00007efc33fd4cdf  mov esi, 0x00
00007efc33fd4ce4  mov rax, 0x5D9448894530
00007efc33fd4cee  call rax
00007efc33fd4cf0  movaps xmm14, [rsp]
00007efc33fd4cf5  add rsp, 0x30
00007efc33fd4cf9  vmovaps xmm0, [rsp]
00007efc33fd4cfe  vmovaps xmm1, [rsp+0x10]
00007efc33fd4d04  vmovaps xmm2, [rsp+0x20]
00007efc33fd4d0a  vmovaps xmm3, [rsp+0x30]
00007efc33fd4d10  vmovaps xmm4, [rsp+0x40]
00007efc33fd4d16  vmovaps xmm5, [rsp+0x50]
00007efc33fd4d1c  vmovaps xmm6, [rsp+0x60]
00007efc33fd4d22  vmovaps xmm7, [rsp+0x70]
00007efc33fd4d28  vmovaps xmm8, [rsp+0x80]
00007efc33fd4d31  vmovaps xmm9, [rsp+0x90]
00007efc33fd4d3a  vmovaps xmm10, [rsp+0xA0]
00007efc33fd4d43  vmovaps xmm11, [rsp+0xB0]
00007efc33fd4d4c  vmovaps xmm12, [rsp+0xC0]
00007efc33fd4d55  vmovaps xmm13, [rsp+0xD0]
00007efc33fd4d5e  vmovaps xmm15, [rsp+0xE0]
00007efc33fd4d67  add rsp, 0xF0
00007efc33fd4d6e  pop r11
00007efc33fd4d70  pop r10
00007efc33fd4d72  pop r9
00007efc33fd4d74  pop r8
00007efc33fd4d76  pop rsi
00007efc33fd4d77  pop rdi
00007efc33fd4d78  pop rdx
00007efc33fd4d79  pop rcx
00007efc33fd4d7a  pop rax
00007efc33fd4d7b  add rsp, 0x08
00007efc33fd4d7f  jmp 0x00007EFC33FD0203
00007efc33fd4d84  sub rsp, 0x08
00007efc33fd4d88  push rax
00007efc33fd4d89  push rcx
00007efc33fd4d8a  push rdx
00007efc33fd4d8b  push rdi
00007efc33fd4d8c  push rsi
00007efc33fd4d8d  push r8
00007efc33fd4d8f  push r9
00007efc33fd4d91  push r10
00007efc33fd4d93  push r11
00007efc33fd4d95  sub rsp, 0xF0
00007efc33fd4d9c  vmovaps [rsp], xmm0
00007efc33fd4da1  vmovaps [rsp+0x10], xmm2
00007efc33fd4da7  vmovaps [rsp+0x20], xmm3
00007efc33fd4dad  vmovaps [rsp+0x30], xmm4
00007efc33fd4db3  vmovaps [rsp+0x40], xmm5
00007efc33fd4db9  vmovaps [rsp+0x50], xmm6
00007efc33fd4dbf  vmovaps [rsp+0x60], xmm7
00007efc33fd4dc5  vmovaps [rsp+0x70], xmm8
00007efc33fd4dcb  vmovaps [rsp+0x80], xmm9
00007efc33fd4dd4  vmovaps [rsp+0x90], xmm10
00007efc33fd4ddd  vmovaps [rsp+0xA0], xmm11
00007efc33fd4de6  vmovaps [rsp+0xB0], xmm12
00007efc33fd4def  vmovaps [rsp+0xC0], xmm13
00007efc33fd4df8  vmovaps [rsp+0xD0], xmm14
00007efc33fd4e01  vmovaps [rsp+0xE0], xmm15
00007efc33fd4e0a  sub rsp, 0x30
00007efc33fd4e0e  movaps [rsp], xmm1
00007efc33fd4e12  movaps [rsp+0x10], xmm12
00007efc33fd4e18  movaps [rsp+0x20], xmm11
00007efc33fd4e1e  lea rdi, [rsp]
00007efc33fd4e22  mov esi, 0x00
00007efc33fd4e27  mov rax, 0x5D9448894530
00007efc33fd4e31  call rax
00007efc33fd4e33  movaps xmm1, [rsp]
00007efc33fd4e37  add rsp, 0x30
00007efc33fd4e3b  vmovaps xmm0, [rsp]
00007efc33fd4e40  vmovaps xmm2, [rsp+0x10]
00007efc33fd4e46  vmovaps xmm3, [rsp+0x20]
00007efc33fd4e4c  vmovaps xmm4, [rsp+0x30]
00007efc33fd4e52  vmovaps xmm5, [rsp+0x40]
00007efc33fd4e58  vmovaps xmm6, [rsp+0x50]
00007efc33fd4e5e  vmovaps xmm7, [rsp+0x60]
00007efc33fd4e64  vmovaps xmm8, [rsp+0x70]
00007efc33fd4e6a  vmovaps xmm9, [rsp+0x80]
00007efc33fd4e73  vmovaps xmm10, [rsp+0x90]
00007efc33fd4e7c  vmovaps xmm11, [rsp+0xA0]
00007efc33fd4e85  vmovaps xmm12, [rsp+0xB0]
00007efc33fd4e8e  vmovaps xmm13, [rsp+0xC0]
00007efc33fd4e97  vmovaps xmm14, [rsp+0xD0]
00007efc33fd4ea0  vmovaps xmm15, [rsp+0xE0]
00007efc33fd4ea9  add rsp, 0xF0
00007efc33fd4eb0  pop r11
00007efc33fd4eb2  pop r10
00007efc33fd4eb4  pop r9
00007efc33fd4eb6  pop r8
00007efc33fd4eb8  pop rsi
00007efc33fd4eb9  pop rdi
00007efc33fd4eba  pop rdx
00007efc33fd4ebb  pop rcx
00007efc33fd4ebc  pop rax
00007efc33fd4ebd  add rsp, 0x08
00007efc33fd4ec1  jmp 0x00007EFC33FD0224
00007efc33fd4ec6  call 0x00007EFC33EE20A0
00007efc33fd4ecb  jmp 0x00007EFC33FD0232
00007efc33fd4ed0  call 0x00007EFC33E09D70
00007efc33fd4ed5  jmp 0x00007EFC33FD023C
00007efc33fd4eda  sub rsp, 0x08
00007efc33fd4ede  push rax
00007efc33fd4edf  push rcx
00007efc33fd4ee0  push rdx
00007efc33fd4ee1  push rdi
00007efc33fd4ee2  push rsi
00007efc33fd4ee3  push r8
00007efc33fd4ee5  push r9
00007efc33fd4ee7  push r10
00007efc33fd4ee9  push r11
00007efc33fd4eeb  sub rsp, 0xF0
00007efc33fd4ef2  vmovaps [rsp], xmm0
00007efc33fd4ef7  vmovaps [rsp+0x10], xmm1
00007efc33fd4efd  vmovaps [rsp+0x20], xmm2
00007efc33fd4f03  vmovaps [rsp+0x30], xmm3
00007efc33fd4f09  vmovaps [rsp+0x40], xmm4
00007efc33fd4f0f  vmovaps [rsp+0x50], xmm5
00007efc33fd4f15  vmovaps [rsp+0x60], xmm6
00007efc33fd4f1b  vmovaps [rsp+0x70], xmm8
00007efc33fd4f21  vmovaps [rsp+0x80], xmm9
00007efc33fd4f2a  vmovaps [rsp+0x90], xmm10
00007efc33fd4f33  vmovaps [rsp+0xA0], xmm11
00007efc33fd4f3c  vmovaps [rsp+0xB0], xmm12
00007efc33fd4f45  vmovaps [rsp+0xC0], xmm13
00007efc33fd4f4e  vmovaps [rsp+0xD0], xmm14
00007efc33fd4f57  vmovaps [rsp+0xE0], xmm15
00007efc33fd4f60  sub rsp, 0x30
00007efc33fd4f64  movaps [rsp], xmm7
00007efc33fd4f68  movaps [rsp+0x10], xmm15
00007efc33fd4f6e  movaps [rsp+0x20], xmm10
00007efc33fd4f74  lea rdi, [rsp]
00007efc33fd4f78  mov esi, 0x00
00007efc33fd4f7d  mov rax, 0x5D9448894530
00007efc33fd4f87  call rax
00007efc33fd4f89  movaps xmm7, [rsp]
00007efc33fd4f8d  add rsp, 0x30
00007efc33fd4f91  vmovaps xmm0, [rsp]
00007efc33fd4f96  vmovaps xmm1, [rsp+0x10]
00007efc33fd4f9c  vmovaps xmm2, [rsp+0x20]
00007efc33fd4fa2  vmovaps xmm3, [rsp+0x30]
00007efc33fd4fa8  vmovaps xmm4, [rsp+0x40]
00007efc33fd4fae  vmovaps xmm5, [rsp+0x50]
00007efc33fd4fb4  vmovaps xmm6, [rsp+0x60]
00007efc33fd4fba  vmovaps xmm8, [rsp+0x70]
00007efc33fd4fc0  vmovaps xmm9, [rsp+0x80]
00007efc33fd4fc9  vmovaps xmm10, [rsp+0x90]
00007efc33fd4fd2  vmovaps xmm11, [rsp+0xA0]
00007efc33fd4fdb  vmovaps xmm12, [rsp+0xB0]
00007efc33fd4fe4  vmovaps xmm13, [rsp+0xC0]
00007efc33fd4fed  vmovaps xmm14, [rsp+0xD0]
00007efc33fd4ff6  vmovaps xmm15, [rsp+0xE0]
00007efc33fd4fff  add rsp, 0xF0
00007efc33fd5006  pop r11
00007efc33fd5008  pop r10
00007efc33fd500a  pop r9
00007efc33fd500c  pop r8
00007efc33fd500e  pop rsi
00007efc33fd500f  pop rdi
00007efc33fd5010  pop rdx
00007efc33fd5011  pop rcx
00007efc33fd5012  pop rax
00007efc33fd5013  add rsp, 0x08
00007efc33fd5017  jmp 0x00007EFC33FD025D
00007efc33fd501c  sub rsp, 0x08
00007efc33fd5020  push rax
00007efc33fd5021  push rcx
00007efc33fd5022  push rdx
00007efc33fd5023  push rdi
00007efc33fd5024  push rsi
00007efc33fd5025  push r8
00007efc33fd5027  push r9
00007efc33fd5029  push r10
00007efc33fd502b  push r11
00007efc33fd502d  sub rsp, 0xF0
00007efc33fd5034  vmovaps [rsp], xmm0
00007efc33fd5039  vmovaps [rsp+0x10], xmm1
00007efc33fd503f  vmovaps [rsp+0x20], xmm2
00007efc33fd5045  vmovaps [rsp+0x30], xmm3
00007efc33fd504b  vmovaps [rsp+0x40], xmm4
00007efc33fd5051  vmovaps [rsp+0x50], xmm5
00007efc33fd5057  vmovaps [rsp+0x60], xmm6
00007efc33fd505d  vmovaps [rsp+0x70], xmm7
00007efc33fd5063  vmovaps [rsp+0x80], xmm8
00007efc33fd506c  vmovaps [rsp+0x90], xmm9
00007efc33fd5075  vmovaps [rsp+0xA0], xmm11
00007efc33fd507e  vmovaps [rsp+0xB0], xmm12
00007efc33fd5087  vmovaps [rsp+0xC0], xmm13
00007efc33fd5090  vmovaps [rsp+0xD0], xmm14
00007efc33fd5099  vmovaps [rsp+0xE0], xmm15
00007efc33fd50a2  sub rsp, 0x30
00007efc33fd50a6  movaps [rsp], xmm10
00007efc33fd50ab  movaps [rsp+0x10], xmm11
00007efc33fd50b1  movaps [rsp+0x20], xmm15
00007efc33fd50b7  lea rdi, [rsp]
00007efc33fd50bb  mov esi, 0x00
00007efc33fd50c0  mov rax, 0x5D9448894530
00007efc33fd50ca  call rax
00007efc33fd50cc  movaps xmm10, [rsp]
00007efc33fd50d1  add rsp, 0x30
00007efc33fd50d5  vmovaps xmm0, [rsp]
00007efc33fd50da  vmovaps xmm1, [rsp+0x10]
00007efc33fd50e0  vmovaps xmm2, [rsp+0x20]
00007efc33fd50e6  vmovaps xmm3, [rsp+0x30]
00007efc33fd50ec  vmovaps xmm4, [rsp+0x40]
00007efc33fd50f2  vmovaps xmm5, [rsp+0x50]
00007efc33fd50f8  vmovaps xmm6, [rsp+0x60]
00007efc33fd50fe  vmovaps xmm7, [rsp+0x70]
00007efc33fd5104  vmovaps xmm8, [rsp+0x80]
00007efc33fd510d  vmovaps xmm9, [rsp+0x90]
00007efc33fd5116  vmovaps xmm11, [rsp+0xA0]
00007efc33fd511f  vmovaps xmm12, [rsp+0xB0]
00007efc33fd5128  vmovaps xmm13, [rsp+0xC0]
00007efc33fd5131  vmovaps xmm14, [rsp+0xD0]
00007efc33fd513a  vmovaps xmm15, [rsp+0xE0]
00007efc33fd5143  add rsp, 0xF0
00007efc33fd514a  pop r11
00007efc33fd514c  pop r10
00007efc33fd514e  pop r9
00007efc33fd5150  pop r8
00007efc33fd5152  pop rsi
00007efc33fd5153  pop rdi
00007efc33fd5154  pop rdx
00007efc33fd5155  pop rcx
00007efc33fd5156  pop rax
00007efc33fd5157  add rsp, 0x08
00007efc33fd515b  jmp 0x00007EFC33FD028B
00007efc33fd5160  sub rsp, 0x08
00007efc33fd5164  push rax
00007efc33fd5165  push rcx
00007efc33fd5166  push rdx
00007efc33fd5167  push rdi
00007efc33fd5168  push rsi
00007efc33fd5169  push r8
00007efc33fd516b  push r9
00007efc33fd516d  push r10
00007efc33fd516f  push r11
00007efc33fd5171  sub rsp, 0xF0
00007efc33fd5178  vmovaps [rsp], xmm0
00007efc33fd517d  vmovaps [rsp+0x10], xmm1
00007efc33fd5183  vmovaps [rsp+0x20], xmm2
00007efc33fd5189  vmovaps [rsp+0x30], xmm3
00007efc33fd518f  vmovaps [rsp+0x40], xmm4
00007efc33fd5195  vmovaps [rsp+0x50], xmm5
00007efc33fd519b  vmovaps [rsp+0x60], xmm6
00007efc33fd51a1  vmovaps [rsp+0x70], xmm7
00007efc33fd51a7  vmovaps [rsp+0x80], xmm8
00007efc33fd51b0  vmovaps [rsp+0x90], xmm9
00007efc33fd51b9  vmovaps [rsp+0xA0], xmm10
00007efc33fd51c2  vmovaps [rsp+0xB0], xmm12
00007efc33fd51cb  vmovaps [rsp+0xC0], xmm13
00007efc33fd51d4  vmovaps [rsp+0xD0], xmm14
00007efc33fd51dd  vmovaps [rsp+0xE0], xmm15
00007efc33fd51e6  sub rsp, 0x30
00007efc33fd51ea  movaps [rsp], xmm11
00007efc33fd51ef  movaps [rsp+0x10], xmm12
00007efc33fd51f5  movaps [rsp+0x20], xmm15
00007efc33fd51fb  lea rdi, [rsp]
00007efc33fd51ff  mov esi, 0x00
00007efc33fd5204  mov rax, 0x5D9448894530
00007efc33fd520e  call rax
00007efc33fd5210  movaps xmm11, [rsp]
00007efc33fd5215  add rsp, 0x30
00007efc33fd5219  vmovaps xmm0, [rsp]
00007efc33fd521e  vmovaps xmm1, [rsp+0x10]
00007efc33fd5224  vmovaps xmm2, [rsp+0x20]
00007efc33fd522a  vmovaps xmm3, [rsp+0x30]
00007efc33fd5230  vmovaps xmm4, [rsp+0x40]
00007efc33fd5236  vmovaps xmm5, [rsp+0x50]
00007efc33fd523c  vmovaps xmm6, [rsp+0x60]
00007efc33fd5242  vmovaps xmm7, [rsp+0x70]
00007efc33fd5248  vmovaps xmm8, [rsp+0x80]
00007efc33fd5251  vmovaps xmm9, [rsp+0x90]
00007efc33fd525a  vmovaps xmm10, [rsp+0xA0]
00007efc33fd5263  vmovaps xmm12, [rsp+0xB0]
00007efc33fd526c  vmovaps xmm13, [rsp+0xC0]
00007efc33fd5275  vmovaps xmm14, [rsp+0xD0]
00007efc33fd527e  vmovaps xmm15, [rsp+0xE0]
00007efc33fd5287  add rsp, 0xF0
00007efc33fd528e  pop r11
00007efc33fd5290  pop r10
00007efc33fd5292  pop r9
00007efc33fd5294  pop r8
00007efc33fd5296  pop rsi
00007efc33fd5297  pop rdi
00007efc33fd5298  pop rdx
00007efc33fd5299  pop rcx
00007efc33fd529a  pop rax
00007efc33fd529b  add rsp, 0x08
00007efc33fd529f  jmp 0x00007EFC33FD02B9
00007efc33fd52a4  sub rsp, 0x08
00007efc33fd52a8  push rax
00007efc33fd52a9  push rcx
00007efc33fd52aa  push rdx
00007efc33fd52ab  push rdi
00007efc33fd52ac  push rsi
00007efc33fd52ad  push r8
00007efc33fd52af  push r9
00007efc33fd52b1  push r10
00007efc33fd52b3  push r11
00007efc33fd52b5  sub rsp, 0xF0
00007efc33fd52bc  vmovaps [rsp], xmm0
00007efc33fd52c1  vmovaps [rsp+0x10], xmm1
00007efc33fd52c7  vmovaps [rsp+0x20], xmm2
00007efc33fd52cd  vmovaps [rsp+0x30], xmm3
00007efc33fd52d3  vmovaps [rsp+0x40], xmm4
00007efc33fd52d9  vmovaps [rsp+0x50], xmm5
00007efc33fd52df  vmovaps [rsp+0x60], xmm6
00007efc33fd52e5  vmovaps [rsp+0x70], xmm7
00007efc33fd52eb  vmovaps [rsp+0x80], xmm8
00007efc33fd52f4  vmovaps [rsp+0x90], xmm9
00007efc33fd52fd  vmovaps [rsp+0xA0], xmm10
00007efc33fd5306  vmovaps [rsp+0xB0], xmm11
00007efc33fd530f  vmovaps [rsp+0xC0], xmm12
00007efc33fd5318  vmovaps [rsp+0xD0], xmm13
00007efc33fd5321  vmovaps [rsp+0xE0], xmm14
00007efc33fd532a  sub rsp, 0x30
00007efc33fd532e  movaps [rsp], xmm15
00007efc33fd5333  movaps [rsp+0x10], xmm13
00007efc33fd5339  movaps [rsp+0x20], xmm9
00007efc33fd533f  lea rdi, [rsp]
00007efc33fd5343  mov esi, 0x00
00007efc33fd5348  mov rax, 0x5D9448894530
00007efc33fd5352  call rax
00007efc33fd5354  movaps xmm15, [rsp]
00007efc33fd5359  add rsp, 0x30
00007efc33fd535d  vmovaps xmm0, [rsp]
00007efc33fd5362  vmovaps xmm1, [rsp+0x10]
00007efc33fd5368  vmovaps xmm2, [rsp+0x20]
00007efc33fd536e  vmovaps xmm3, [rsp+0x30]
00007efc33fd5374  vmovaps xmm4, [rsp+0x40]
00007efc33fd537a  vmovaps xmm5, [rsp+0x50]
00007efc33fd5380  vmovaps xmm6, [rsp+0x60]
00007efc33fd5386  vmovaps xmm7, [rsp+0x70]
00007efc33fd538c  vmovaps xmm8, [rsp+0x80]
00007efc33fd5395  vmovaps xmm9, [rsp+0x90]
00007efc33fd539e  vmovaps xmm10, [rsp+0xA0]
00007efc33fd53a7  vmovaps xmm11, [rsp+0xB0]
00007efc33fd53b0  vmovaps xmm12, [rsp+0xC0]
00007efc33fd53b9  vmovaps xmm13, [rsp+0xD0]
00007efc33fd53c2  vmovaps xmm14, [rsp+0xE0]
00007efc33fd53cb  add rsp, 0xF0
00007efc33fd53d2  pop r11
00007efc33fd53d4  pop r10
00007efc33fd53d6  pop r9
00007efc33fd53d8  pop r8
00007efc33fd53da  pop rsi
00007efc33fd53db  pop rdi
00007efc33fd53dc  pop rdx
00007efc33fd53dd  pop rcx
00007efc33fd53de  pop rax
00007efc33fd53df  add rsp, 0x08
00007efc33fd53e3  jmp 0x00007EFC33FD02D4
00007efc33fd53e8  sub rsp, 0x08
00007efc33fd53ec  push rax
00007efc33fd53ed  push rcx
00007efc33fd53ee  push rdx
00007efc33fd53ef  push rdi
00007efc33fd53f0  push rsi
00007efc33fd53f1  push r8
00007efc33fd53f3  push r9
00007efc33fd53f5  push r10
00007efc33fd53f7  push r11
00007efc33fd53f9  sub rsp, 0xF0
00007efc33fd5400  vmovaps [rsp], xmm0
00007efc33fd5405  vmovaps [rsp+0x10], xmm1
00007efc33fd540b  vmovaps [rsp+0x20], xmm2
00007efc33fd5411  vmovaps [rsp+0x30], xmm3
00007efc33fd5417  vmovaps [rsp+0x40], xmm4
00007efc33fd541d  vmovaps [rsp+0x50], xmm5
00007efc33fd5423  vmovaps [rsp+0x60], xmm6
00007efc33fd5429  vmovaps [rsp+0x70], xmm7
00007efc33fd542f  vmovaps [rsp+0x80], xmm8
00007efc33fd5438  vmovaps [rsp+0x90], xmm9
00007efc33fd5441  vmovaps [rsp+0xA0], xmm10
00007efc33fd544a  vmovaps [rsp+0xB0], xmm11
00007efc33fd5453  vmovaps [rsp+0xC0], xmm12
00007efc33fd545c  vmovaps [rsp+0xD0], xmm14
00007efc33fd5465  vmovaps [rsp+0xE0], xmm15
00007efc33fd546e  sub rsp, 0x30
00007efc33fd5472  movaps [rsp], xmm13
00007efc33fd5477  movaps [rsp+0x10], xmm8
00007efc33fd547d  movaps [rsp+0x20], xmm14
00007efc33fd5483  lea rdi, [rsp]
00007efc33fd5487  mov esi, 0x00
00007efc33fd548c  mov rax, 0x5D9448894530
00007efc33fd5496  call rax
00007efc33fd5498  movaps xmm13, [rsp]
00007efc33fd549d  add rsp, 0x30
00007efc33fd54a1  vmovaps xmm0, [rsp]
00007efc33fd54a6  vmovaps xmm1, [rsp+0x10]
00007efc33fd54ac  vmovaps xmm2, [rsp+0x20]
00007efc33fd54b2  vmovaps xmm3, [rsp+0x30]
00007efc33fd54b8  vmovaps xmm4, [rsp+0x40]
00007efc33fd54be  vmovaps xmm5, [rsp+0x50]
00007efc33fd54c4  vmovaps xmm6, [rsp+0x60]
00007efc33fd54ca  vmovaps xmm7, [rsp+0x70]
00007efc33fd54d0  vmovaps xmm8, [rsp+0x80]
00007efc33fd54d9  vmovaps xmm9, [rsp+0x90]
00007efc33fd54e2  vmovaps xmm10, [rsp+0xA0]
00007efc33fd54eb  vmovaps xmm11, [rsp+0xB0]
00007efc33fd54f4  vmovaps xmm12, [rsp+0xC0]
00007efc33fd54fd  vmovaps xmm14, [rsp+0xD0]
00007efc33fd5506  vmovaps xmm15, [rsp+0xE0]
00007efc33fd550f  add rsp, 0xF0
00007efc33fd5516  pop r11
00007efc33fd5518  pop r10
00007efc33fd551a  pop r9
00007efc33fd551c  pop r8
00007efc33fd551e  pop rsi
00007efc33fd551f  pop rdi
00007efc33fd5520  pop rdx
00007efc33fd5521  pop rcx
00007efc33fd5522  pop rax
00007efc33fd5523  add rsp, 0x08
00007efc33fd5527  jmp 0x00007EFC33FD02F7
00007efc33fd552c  sub rsp, 0x08
00007efc33fd5530  push rax
00007efc33fd5531  push rcx
00007efc33fd5532  push rdx
00007efc33fd5533  push rdi
00007efc33fd5534  push rsi
00007efc33fd5535  push r8
00007efc33fd5537  push r9
00007efc33fd5539  push r10
00007efc33fd553b  push r11
00007efc33fd553d  sub rsp, 0xF0
00007efc33fd5544  vmovaps [rsp], xmm0
00007efc33fd5549  vmovaps [rsp+0x10], xmm1
00007efc33fd554f  vmovaps [rsp+0x20], xmm2
00007efc33fd5555  vmovaps [rsp+0x30], xmm3
00007efc33fd555b  vmovaps [rsp+0x40], xmm4
00007efc33fd5561  vmovaps [rsp+0x50], xmm5
00007efc33fd5567  vmovaps [rsp+0x60], xmm6
00007efc33fd556d  vmovaps [rsp+0x70], xmm7
00007efc33fd5573  vmovaps [rsp+0x80], xmm8
00007efc33fd557c  vmovaps [rsp+0x90], xmm9
00007efc33fd5585  vmovaps [rsp+0xA0], xmm10
00007efc33fd558e  vmovaps [rsp+0xB0], xmm11
00007efc33fd5597  vmovaps [rsp+0xC0], xmm12
00007efc33fd55a0  vmovaps [rsp+0xD0], xmm13
00007efc33fd55a9  vmovaps [rsp+0xE0], xmm15
00007efc33fd55b2  sub rsp, 0x30
00007efc33fd55b6  movaps [rsp], xmm14
00007efc33fd55bb  movaps [rsp+0x10], xmm1
00007efc33fd55c0  movaps [rsp+0x20], xmm10
00007efc33fd55c6  lea rdi, [rsp]
00007efc33fd55ca  mov esi, 0x00
00007efc33fd55cf  mov rax, 0x5D9448894530
00007efc33fd55d9  call rax
00007efc33fd55db  movaps xmm14, [rsp]
00007efc33fd55e0  add rsp, 0x30
00007efc33fd55e4  vmovaps xmm0, [rsp]
00007efc33fd55e9  vmovaps xmm1, [rsp+0x10]
00007efc33fd55ef  vmovaps xmm2, [rsp+0x20]
00007efc33fd55f5  vmovaps xmm3, [rsp+0x30]
00007efc33fd55fb  vmovaps xmm4, [rsp+0x40]
00007efc33fd5601  vmovaps xmm5, [rsp+0x50]
00007efc33fd5607  vmovaps xmm6, [rsp+0x60]
00007efc33fd560d  vmovaps xmm7, [rsp+0x70]
00007efc33fd5613  vmovaps xmm8, [rsp+0x80]
00007efc33fd561c  vmovaps xmm9, [rsp+0x90]
00007efc33fd5625  vmovaps xmm10, [rsp+0xA0]
00007efc33fd562e  vmovaps xmm11, [rsp+0xB0]
00007efc33fd5637  vmovaps xmm12, [rsp+0xC0]
00007efc33fd5640  vmovaps xmm13, [rsp+0xD0]
00007efc33fd5649  vmovaps xmm15, [rsp+0xE0]
00007efc33fd5652  add rsp, 0xF0
00007efc33fd5659  pop r11
00007efc33fd565b  pop r10
00007efc33fd565d  pop r9
00007efc33fd565f  pop r8
00007efc33fd5661  pop rsi
00007efc33fd5662  pop rdi
00007efc33fd5663  pop rdx
00007efc33fd5664  pop rcx
00007efc33fd5665  pop rax
00007efc33fd5666  add rsp, 0x08
00007efc33fd566a  jmp 0x00007EFC33FD031A
00007efc33fd566f  sub rsp, 0x08
00007efc33fd5673  push rax
00007efc33fd5674  push rcx
00007efc33fd5675  push rdx
00007efc33fd5676  push rdi
00007efc33fd5677  push rsi
00007efc33fd5678  push r8
00007efc33fd567a  push r9
00007efc33fd567c  push r10
00007efc33fd567e  push r11
00007efc33fd5680  sub rsp, 0xF0
00007efc33fd5687  vmovaps [rsp], xmm0
00007efc33fd568c  vmovaps [rsp+0x10], xmm2
00007efc33fd5692  vmovaps [rsp+0x20], xmm3
00007efc33fd5698  vmovaps [rsp+0x30], xmm4
00007efc33fd569e  vmovaps [rsp+0x40], xmm5
00007efc33fd56a4  vmovaps [rsp+0x50], xmm6
00007efc33fd56aa  vmovaps [rsp+0x60], xmm7
00007efc33fd56b0  vmovaps [rsp+0x70], xmm8
00007efc33fd56b6  vmovaps [rsp+0x80], xmm9
00007efc33fd56bf  vmovaps [rsp+0x90], xmm10
00007efc33fd56c8  vmovaps [rsp+0xA0], xmm11
00007efc33fd56d1  vmovaps [rsp+0xB0], xmm12
00007efc33fd56da  vmovaps [rsp+0xC0], xmm13
00007efc33fd56e3  vmovaps [rsp+0xD0], xmm14
00007efc33fd56ec  vmovaps [rsp+0xE0], xmm15
00007efc33fd56f5  sub rsp, 0x30
00007efc33fd56f9  movaps [rsp], xmm1
00007efc33fd56fd  movaps [rsp+0x10], xmm7
00007efc33fd5702  movaps [rsp+0x20], xmm11
00007efc33fd5708  lea rdi, [rsp]
00007efc33fd570c  mov esi, 0x00
00007efc33fd5711  mov rax, 0x5D9448894530
00007efc33fd571b  call rax
00007efc33fd571d  movaps xmm1, [rsp]
00007efc33fd5721  add rsp, 0x30
00007efc33fd5725  vmovaps xmm0, [rsp]
00007efc33fd572a  vmovaps xmm2, [rsp+0x10]
00007efc33fd5730  vmovaps xmm3, [rsp+0x20]
00007efc33fd5736  vmovaps xmm4, [rsp+0x30]
00007efc33fd573c  vmovaps xmm5, [rsp+0x40]
00007efc33fd5742  vmovaps xmm6, [rsp+0x50]
00007efc33fd5748  vmovaps xmm7, [rsp+0x60]
00007efc33fd574e  vmovaps xmm8, [rsp+0x70]
00007efc33fd5754  vmovaps xmm9, [rsp+0x80]
00007efc33fd575d  vmovaps xmm10, [rsp+0x90]
00007efc33fd5766  vmovaps xmm11, [rsp+0xA0]
00007efc33fd576f  vmovaps xmm12, [rsp+0xB0]
00007efc33fd5778  vmovaps xmm13, [rsp+0xC0]
00007efc33fd5781  vmovaps xmm14, [rsp+0xD0]
00007efc33fd578a  vmovaps xmm15, [rsp+0xE0]
00007efc33fd5793  add rsp, 0xF0
00007efc33fd579a  pop r11
00007efc33fd579c  pop r10
00007efc33fd579e  pop r9
00007efc33fd57a0  pop r8
00007efc33fd57a2  pop rsi
00007efc33fd57a3  pop rdi
00007efc33fd57a4  pop rdx
00007efc33fd57a5  pop rcx
00007efc33fd57a6  pop rax
00007efc33fd57a7  add rsp, 0x08
00007efc33fd57ab  jmp 0x00007EFC33FD033B
00007efc33fd57b0  call 0x00007EFC33E0E880
00007efc33fd57b5  jmp 0x00007EFC33FD034E
00007efc33fd57ba  call 0x00007EFC33E0C380
00007efc33fd57bf  jmp 0x00007EFC33FD0359
00007efc33fd57c4  call 0x00007EFC33E0D600
00007efc33fd57c9  jmp 0x00007EFC33FD0364
00007efc33fd57ce  call 0x00007EFC33DFF540
00007efc33fd57d3  jmp 0x00007EFC33FD036F
00007efc33fd57d8  int3
00007efc33fd57d9  nop [rax], eax
00007efc33fd57e0  mov rax, [r15+0x40]
00007efc33fd57e4  mov r14, [r15+0x58]
00007efc33fd57e8  lea r12, [rax+r14*1]
00007efc33fd57ec  movaps xmm1, [r15+0x1D0]
00007efc33fd57f4  vmovaps [rsp+0x10], xmm1
00007efc33fd57fa  vmovaps xmm15, [rsp+0x10]
00007efc33fd5800  por xmm1, xmm15
00007efc33fd5805  movaps xmm14, [r15+0x1A0]
00007efc33fd580d  vmovaps [rsp+0x10], xmm14
00007efc33fd5813  vmovaps xmm13, [rsp+0x10]
00007efc33fd5819  por xmm14, xmm13
00007efc33fd581e  lea rax, [r12+0x30]
00007efc33fd5823  mov r11, [r13+rax*1]
00007efc33fd5828  lea rax, [r12+0x38]
00007efc33fd582d  mov r10, [r13+rax*1]
00007efc33fd5832  movq xmm13, r11
00007efc33fd5837  movq xmm12, r10
00007efc33fd583c  movq xmm13, xmm13
00007efc33fd5841  vmovaps [rsp+0x10], xmm13
00007efc33fd5847  movq xmm13, xmm13
00007efc33fd584c  movaps [r15+0x130], xmm13
00007efc33fd5854  movq xmm12, xmm12
00007efc33fd5859  vmovaps [rsp+0x20], xmm12
00007efc33fd585f  movq xmm12, xmm12
00007efc33fd5864  movaps [r15+0x280], xmm12
00007efc33fd586c  movaps xmm13, [r15+0x270]
00007efc33fd5874  vmovaps [rsp+0x30], xmm13
00007efc33fd587a  vmovaps xmm12, [rsp+0x30]
00007efc33fd5880  por xmm13, xmm12
00007efc33fd5885  lea rax, [r12+0x20]
00007efc33fd588a  mov r11, [r13+rax*1]
00007efc33fd588f  lea rax, [r12+0x28]
00007efc33fd5894  mov r10, [r13+rax*1]
00007efc33fd5899  movq xmm12, r11
00007efc33fd589e  movq xmm11, r10
00007efc33fd58a3  movq xmm12, xmm12
00007efc33fd58a8  vmovaps [rsp+0x30], xmm12
00007efc33fd58ae  movq xmm12, xmm12
00007efc33fd58b3  movaps [r15+0x150], xmm12
00007efc33fd58bb  movq xmm11, xmm11
00007efc33fd58c0  vmovaps [rsp+0x40], xmm11
00007efc33fd58c6  movq xmm11, xmm11
00007efc33fd58cb  movaps [r15+0x140], xmm11
00007efc33fd58d3  lea rax, [r12+0x10]
00007efc33fd58d8  mov r11, [r13+rax*1]
00007efc33fd58dd  lea rax, [r12+0x18]
00007efc33fd58e2  mov r10, [r13+rax*1]
00007efc33fd58e7  movq xmm12, r11
00007efc33fd58ec  movq xmm11, r10
00007efc33fd58f1  movq xmm12, xmm12
00007efc33fd58f6  vmovaps [rsp+0x50], xmm12
00007efc33fd58fc  movq xmm12, xmm12
00007efc33fd5901  movaps [r15+0x170], xmm12
00007efc33fd5909  movq xmm11, xmm11
00007efc33fd590e  vmovaps [rsp+0x60], xmm11
00007efc33fd5914  movq xmm11, xmm11
00007efc33fd5919  movaps [r15+0x160], xmm11
00007efc33fd5921  mov rax, [r13+r12*1]
00007efc33fd5926  vmovq xmm12, rax
00007efc33fd592b  vpbroadcastq xmm12, xmm12
00007efc33fd5930  lea rax, [r12+0x08]
00007efc33fd5935  mov r12, [r13+rax*1]
00007efc33fd593a  movq xmm11, r12
00007efc33fd593f  movaps [r15+0x230], xmm11
00007efc33fd5947  mov rax, [r15+0xF8]
00007efc33fd594e  lea r12, [rax+0x50]
00007efc33fd5952  movups xmm11, [r13+r12*1]
00007efc33fd5958  lea r12, [rax+0x60]
00007efc33fd595c  movups xmm10, [r13+r12*1]
00007efc33fd5962  lea r12, [rax+0x30]
00007efc33fd5966  movups xmm9, [r13+r12*1]
00007efc33fd596c  mov r12, [r15+0x50]
00007efc33fd5970  lea r11, [r12+r14*1]
00007efc33fd5974  mov [r15+0x60], r11
00007efc33fd5978  lea r12, [r14+0x40]
00007efc33fd597c  mov [r15+0x58], r12
00007efc33fd5980  movaps xmm8, xmm12
00007efc33fd5984  mulpd xmm8, xmm15
00007efc33fd5989  vcmppd xmm7, xmm8, xmm8, 0x03
00007efc33fd598f  ptest xmm7, xmm7
00007efc33fd5994  jnz 0x00007EFC33FD67B7
00007efc33fd599a  movq xmm15, qword ptr [r15+0x230]
00007efc33fd59a3  vmovaps [rsp+0x70], xmm15
00007efc33fd59a9  vpermilpd xmm15, xmm15, 0x00
00007efc33fd59af  movaps xmm7, xmm9
00007efc33fd59b3  mulpd xmm7, xmm15
00007efc33fd59b8  vcmppd xmm6, xmm7, xmm7, 0x03
00007efc33fd59bd  ptest xmm6, xmm6
00007efc33fd59c2  jnz 0x00007EFC33FD68FB
00007efc33fd59c8  vxorps xmm15, xmm15, xmm15
00007efc33fd59cd  vpbroadcastq xmm15, xmm15
00007efc33fd59d2  movaps xmm9, xmm12
00007efc33fd59d6  mulpd xmm9, xmm10
00007efc33fd59db  vcmppd xmm6, xmm9, xmm9, 0x03
00007efc33fd59e1  ptest xmm6, xmm6
00007efc33fd59e6  jnz 0x00007EFC33FD6A3D
00007efc33fd59ec  movaps xmm10, xmm12
00007efc33fd59f0  mulpd xmm10, xmm11
00007efc33fd59f5  vcmppd xmm6, xmm10, xmm10, 0x03
00007efc33fd59fb  ptest xmm6, xmm6
00007efc33fd5a00  jnz 0x00007EFC33FD6B81
00007efc33fd5a06  movaps xmm11, [r15+0x1F0]
00007efc33fd5a0e  movaps xmm6, xmm12
00007efc33fd5a12  mulpd xmm6, xmm11
00007efc33fd5a17  vcmppd xmm5, xmm6, xmm6, 0x03
00007efc33fd5a1c  ptest xmm5, xmm5
00007efc33fd5a21  jnz 0x00007EFC33FD6CC5
00007efc33fd5a27  movaps xmm12, [r15+0x2A0]
00007efc33fd5a2f  vmovaps [rsp+0x80], xmm12
00007efc33fd5a38  vmovaps xmm11, [rsp+0x80]
00007efc33fd5a41  por xmm12, xmm11
00007efc33fd5a46  movaps xmm11, [r15+0x250]
00007efc33fd5a4e  vmovaps [rsp+0x80], xmm11
00007efc33fd5a57  vmovaps xmm5, [rsp+0x80]
00007efc33fd5a60  por xmm11, xmm5
00007efc33fd5a65  vmovaps xmm4, [rsp+0x70]
00007efc33fd5a6b  vpermilpd xmm4, xmm4, 0x00
00007efc33fd5a71  movaps xmm3, xmm5
00007efc33fd5a74  mulpd xmm3, xmm4
00007efc33fd5a78  vcmppd xmm2, xmm3, xmm3, 0x03
00007efc33fd5a7d  ptest xmm2, xmm2
00007efc33fd5a82  jnz 0x00007EFC33FD6E07
00007efc33fd5a88  mov [rsp+0x80], rax
00007efc33fd5a90  xor eax, eax
00007efc33fd5a92  mov r14d, 0x200
00007efc33fd5a98  cmp r12, r14
00007efc33fd5a9b  cmc
00007efc33fd5a9c  lahf
00007efc33fd5a9d  seto al
00007efc33fd5aa0  mov [r15+0x108], eax
00007efc33fd5aa7  movaps xmm5, xmm8
00007efc33fd5aab  addpd xmm5, xmm15
00007efc33fd5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
00007efc33fd5ab5  ptest xmm4, xmm4
00007efc33fd5aba  jnz 0x00007EFC33FD6F47
00007efc33fd5ac0  movaps xmm8, [r15+0x1B0]
00007efc33fd5ac8  movaps xmm4, xmm9
00007efc33fd5acc  addpd xmm4, xmm8
00007efc33fd5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
00007efc33fd5ad6  ptest xmm2, xmm2
00007efc33fd5adb  jnz 0x00007EFC33FD7089
00007efc33fd5ae1  movaps xmm9, xmm10
00007efc33fd5ae5  addpd xmm9, xmm8
00007efc33fd5aea  vcmppd xmm2, xmm9, xmm9, 0x03
00007efc33fd5af0  ptest xmm2, xmm2
00007efc33fd5af5  jnz 0x00007EFC33FD71CB
00007efc33fd5afb  movaps xmm10, [r15+0x2F0]
00007efc33fd5b03  vmovaps [rsp+0x90], xmm10
00007efc33fd5b0c  vmovaps xmm8, [rsp+0x90]
00007efc33fd5b15  por xmm10, xmm8
00007efc33fd5b1a  movaps xmm8, [r15+0x2E0]
00007efc33fd5b22  vmovaps [rsp+0x90], xmm8
00007efc33fd5b2b  vmovaps xmm2, [rsp+0x90]
00007efc33fd5b34  por xmm8, xmm2
00007efc33fd5b39  movaps xmm2, [r15+0x2D0]
00007efc33fd5b41  vmovaps [rsp+0x90], xmm2
00007efc33fd5b4a  vmovaps [rsp+0xA0], xmm1
00007efc33fd5b53  vmovaps xmm1, [rsp+0x90]
00007efc33fd5b5c  por xmm2, xmm1
00007efc33fd5b60  movaps xmm1, [r15+0x200]
00007efc33fd5b68  vmovaps [rsp+0x90], xmm1
00007efc33fd5b71  vmovaps [rsp+0xB0], xmm15
00007efc33fd5b7a  vmovaps xmm15, [rsp+0x90]
00007efc33fd5b83  por xmm1, xmm15
00007efc33fd5b88  movaps xmm15, [r15+0x1C0]
00007efc33fd5b90  vmovaps [rsp+0x90], xmm15
00007efc33fd5b99  vmovaps [rsp+0xC0], xmm1
00007efc33fd5ba2  vmovaps xmm1, [rsp+0x90]
00007efc33fd5bab  por xmm15, xmm1
00007efc33fd5bb0  movaps xmm1, [r15+0x190]
00007efc33fd5bb8  vmovaps [rsp+0x90], xmm1
00007efc33fd5bc1  vmovaps [rsp+0xD0], xmm15
00007efc33fd5bca  vmovaps xmm15, [rsp+0x90]
00007efc33fd5bd3  por xmm1, xmm15
00007efc33fd5bd8  movaps xmm15, [r15+0x300]
00007efc33fd5be0  vmovaps [rsp+0x90], xmm15
00007efc33fd5be9  vmovaps [rsp+0xE0], xmm1
00007efc33fd5bf2  vmovaps xmm1, [rsp+0x90]
00007efc33fd5bfb  por xmm15, xmm1
00007efc33fd5c00  mov rax, [rsp+0x80]
00007efc33fd5c08  lea r14, [rax+0xA0]
00007efc33fd5c0f  movups xmm1, [r13+r14*1]
00007efc33fd5c15  lea r14, [rax+0xB0]
00007efc33fd5c1c  vmovaps [rsp+0x80], xmm1
00007efc33fd5c25  movups xmm1, [r13+r14*1]
00007efc33fd5c2b  vmovaps [rsp+0x90], xmm1
00007efc33fd5c34  vmovaps [rsp+0xF0], xmm15
00007efc33fd5c3d  vmovaps xmm15, [rsp+0xB0]
00007efc33fd5c46  vmovaps [rsp+0xB0], xmm14
00007efc33fd5c4f  movaps xmm1, xmm6
00007efc33fd5c52  addpd xmm1, xmm15
00007efc33fd5c57  vcmppd xmm14, xmm1, xmm1, 0x03
00007efc33fd5c5c  ptest xmm14, xmm14
00007efc33fd5c62  jnz 0x00007EFC33FD7323
00007efc33fd5c68  lea r14, [rax+0xF0]
00007efc33fd5c6f  movups xmm15, [r13+r14*1]
00007efc33fd5c75  movaps xmm14, xmm4
00007efc33fd5c79  addpd xmm14, xmm3
00007efc33fd5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
00007efc33fd5c84  ptest xmm6, xmm6
00007efc33fd5c89  jnz 0x00007EFC33FD746E
00007efc33fd5c8f  movaps xmm6, xmm9
00007efc33fd5c93  addpd xmm6, xmm7
00007efc33fd5c97  vcmppd xmm4, xmm6, xmm6, 0x03
00007efc33fd5c9c  ptest xmm4, xmm4
00007efc33fd5ca1  jnz 0x00007EFC33FD75B0
00007efc33fd5ca7  vmovaps xmm9, [rsp+0x70]
00007efc33fd5cad  vpermilpd xmm9, xmm9, 0x00
00007efc33fd5cb3  vmovaps xmm4, [rsp+0x90]
00007efc33fd5cbc  movaps xmm7, xmm4
00007efc33fd5cbf  mulpd xmm7, xmm9
00007efc33fd5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
00007efc33fd5cc9  ptest xmm3, xmm3
00007efc33fd5cce  jnz 0x00007EFC33FD76F1
00007efc33fd5cd4  vmovaps xmm9, [rsp+0x50]
00007efc33fd5cda  vpermilpd xmm9, xmm9, 0x00
00007efc33fd5ce0  movaps xmm4, xmm15
00007efc33fd5ce4  mulpd xmm4, xmm9
00007efc33fd5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
00007efc33fd5cee  ptest xmm3, xmm3
00007efc33fd5cf3  jnz 0x00007EFC33FD7832
00007efc33fd5cf9  lea r14, [rax+0xE0]
00007efc33fd5d00  movups xmm15, [r13+r14*1]
00007efc33fd5d06  vmovaps xmm9, [rsp+0x70]
00007efc33fd5d0c  vpermilpd xmm9, xmm9, 0x00
00007efc33fd5d12  vmovaps [rsp+0x70], xmm1
00007efc33fd5d18  vmovaps xmm1, [rsp+0x80]
00007efc33fd5d21  vmovaps [rsp+0x80], xmm15
00007efc33fd5d2a  movaps xmm3, xmm1
00007efc33fd5d2d  mulpd xmm3, xmm9
00007efc33fd5d32  vcmppd xmm15, xmm3, xmm3, 0x03
00007efc33fd5d37  ptest xmm15, xmm15
00007efc33fd5d3d  jnz 0x00007EFC33FD797E
00007efc33fd5d43  vmovaps xmm1, [rsp+0xF0]
00007efc33fd5d4c  vmovaps xmm15, [rsp+0xF0]
00007efc33fd5d55  por xmm1, xmm15
00007efc33fd5d5a  movaps [r15+0x300], xmm1
00007efc33fd5d62  vmovaps xmm15, [rsp+0xE0]
00007efc33fd5d6b  vmovaps xmm9, [rsp+0xE0]
00007efc33fd5d74  por xmm15, xmm9
00007efc33fd5d79  movaps [r15+0x190], xmm15
00007efc33fd5d81  vmovaps xmm9, [rsp+0x50]
00007efc33fd5d87  vpermilpd xmm9, xmm9, 0x00
00007efc33fd5d8d  vmovaps [rsp+0x90], xmm1
00007efc33fd5d96  vmovaps [rsp+0xE0], xmm15
00007efc33fd5d9f  vmovaps xmm15, [rsp+0x80]
00007efc33fd5da8  vmovaps [rsp+0x80], xmm14
00007efc33fd5db1  movaps xmm1, xmm15
00007efc33fd5db5  mulpd xmm1, xmm9
00007efc33fd5dba  vcmppd xmm14, xmm1, xmm1, 0x03
00007efc33fd5dbf  ptest xmm14, xmm14
00007efc33fd5dc5  jnz 0x00007EFC33FD7ABF
00007efc33fd5dcb  lea r14, [rax+0x90]
00007efc33fd5dd2  movups xmm15, [r13+r14*1]
00007efc33fd5dd8  vmovaps xmm14, [rsp+0xD0]
00007efc33fd5de1  vmovaps xmm9, [rsp+0xD0]
00007efc33fd5dea  por xmm14, xmm9
00007efc33fd5def  movaps [r15+0x1C0], xmm14
00007efc33fd5df7  vmovaps xmm9, [rsp+0xC0]
00007efc33fd5e00  vmovaps [rsp+0xD0], xmm1
00007efc33fd5e09  vmovaps xmm1, [rsp+0xC0]
00007efc33fd5e12  por xmm9, xmm1
00007efc33fd5e17  movaps [r15+0x200], xmm9
00007efc33fd5e1f  vmovaps [rsp+0xC0], xmm2
00007efc33fd5e28  vmovaps xmm1, [rsp+0xC0]
00007efc33fd5e31  por xmm2, xmm1
00007efc33fd5e35  movaps [r15+0x2D0], xmm2
00007efc33fd5e3d  vmovaps [rsp+0xC0], xmm8
00007efc33fd5e46  vmovaps xmm1, [rsp+0xC0]
00007efc33fd5e4f  por xmm8, xmm1
00007efc33fd5e54  movaps [r15+0x2E0], xmm8
00007efc33fd5e5c  vmovaps [rsp+0xC0], xmm15
00007efc33fd5e65  movaps xmm1, xmm5
00007efc33fd5e68  addpd xmm1, xmm7
00007efc33fd5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
00007efc33fd5e71  ptest xmm15, xmm15
00007efc33fd5e77  jnz 0x00007EFC33FD7C0B
00007efc33fd5e7d  vmovaps xmm15, [rsp+0x50]
00007efc33fd5e83  vpermilpd xmm15, xmm15, 0x00
00007efc33fd5e89  vmovaps xmm5, [rsp+0xC0]
00007efc33fd5e92  vmovaps [rsp+0xC0], xmm1
00007efc33fd5e9b  movaps xmm7, xmm5
00007efc33fd5e9e  mulpd xmm7, xmm15
00007efc33fd5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
00007efc33fd5ea8  ptest xmm1, xmm1
00007efc33fd5ead  jnz 0x00007EFC33FD7D4B
00007efc33fd5eb3  lea r14, [rax+0x80]
00007efc33fd5eba  movups xmm1, [r13+r14*1]
00007efc33fd5ec0  vmovaps xmm5, [rsp+0x70]
00007efc33fd5ec6  vmovaps [rsp+0x70], xmm1
00007efc33fd5ecc  movaps xmm15, xmm5
00007efc33fd5ed0  addpd xmm15, xmm3
00007efc33fd5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
00007efc33fd5edb  ptest xmm1, xmm1
00007efc33fd5ee0  jnz 0x00007EFC33FD7E96
00007efc33fd5ee6  vmovaps xmm5, [rsp+0x80]
00007efc33fd5eef  movaps xmm1, xmm5
00007efc33fd5ef2  addpd xmm1, xmm4
00007efc33fd5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
00007efc33fd5efb  ptest xmm3, xmm3
00007efc33fd5f00  jnz 0x00007EFC33FD7FD8
00007efc33fd5f06  vmovaps [rsp+0x80], xmm10
00007efc33fd5f0f  vmovaps xmm5, [rsp+0x80]
00007efc33fd5f18  por xmm10, xmm5
00007efc33fd5f1d  movaps [r15+0x2F0], xmm10
00007efc33fd5f25  vmovaps xmm5, [rsp+0x50]
00007efc33fd5f2b  vpermilpd xmm5, xmm5, 0x00
00007efc33fd5f31  vmovaps xmm3, [rsp+0x70]
00007efc33fd5f37  vmovaps [rsp+0x50], xmm1
00007efc33fd5f3d  movaps xmm4, xmm3
00007efc33fd5f40  mulpd xmm4, xmm5
00007efc33fd5f44  vcmppd xmm1, xmm4, xmm4, 0x03
00007efc33fd5f49  ptest xmm1, xmm1
00007efc33fd5f4e  jnz 0x00007EFC33FD8118
00007efc33fd5f54  lea r14, [rax+0xD0]
00007efc33fd5f5b  movups xmm1, [r13+r14*1]
00007efc33fd5f61  vmovaps xmm3, [rsp+0xD0]
00007efc33fd5f6a  vmovaps [rsp+0x70], xmm1
00007efc33fd5f70  movaps xmm5, xmm6
00007efc33fd5f73  addpd xmm5, xmm3
00007efc33fd5f77  vcmppd xmm1, xmm5, xmm5, 0x03
00007efc33fd5f7c  ptest xmm1, xmm1
00007efc33fd5f81  jnz 0x00007EFC33FD8262
00007efc33fd5f87  vmovaps xmm1, [rsp+0x60]
00007efc33fd5f8d  vpermilpd xmm1, xmm1, 0x00
00007efc33fd5f93  movaps xmm6, xmm9
00007efc33fd5f97  mulpd xmm6, xmm1
00007efc33fd5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
00007efc33fd5fa0  ptest xmm3, xmm3
00007efc33fd5fa5  jnz 0x00007EFC33FD83A2
00007efc33fd5fab  movaps [r15+0x260], xmm6
00007efc33fd5fb3  vxorps xmm1, xmm1, xmm1
00007efc33fd5fb7  vpbroadcastq xmm1, xmm1
00007efc33fd5fbc  movaps [r15+0x1B0], xmm1
00007efc33fd5fc4  vmovaps xmm1, [rsp+0x60]
00007efc33fd5fca  vpermilpd xmm1, xmm1, 0x00
00007efc33fd5fd0  vmovaps xmm3, [rsp+0x70]
00007efc33fd5fd6  vmovaps [rsp+0x70], xmm15
00007efc33fd5fdc  movaps xmm9, xmm3
00007efc33fd5fe0  mulpd xmm9, xmm1
00007efc33fd5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
00007efc33fd5feb  ptest xmm15, xmm15
00007efc33fd5ff1  jnz 0x00007EFC33FD84E3
00007efc33fd5ff7  lea r14, [rax+0xC0]
00007efc33fd5ffe  movups xmm1, [r13+r14*1]
00007efc33fd6004  vmovaps xmm3, [rsp+0xC0]
00007efc33fd600d  vmovaps [rsp+0x80], xmm1
00007efc33fd6016  movaps xmm15, xmm3
00007efc33fd601a  addpd xmm15, xmm7
00007efc33fd601f  vcmppd xmm1, xmm15, xmm15, 0x03
00007efc33fd6025  ptest xmm1, xmm1
00007efc33fd602a  jnz 0x00007EFC33FD862F
00007efc33fd6030  vmovaps [rsp+0xC0], xmm13
00007efc33fd6039  vmovaps xmm1, [rsp+0xC0]
00007efc33fd6042  por xmm13, xmm1
00007efc33fd6047  movaps [r15+0x270], xmm13
00007efc33fd604f  vmovaps xmm1, [rsp+0xB0]
00007efc33fd6058  vmovaps xmm7, [rsp+0xB0]
00007efc33fd6061  por xmm1, xmm7
00007efc33fd6065  movaps [r15+0x1A0], xmm1
00007efc33fd606d  vmovaps xmm1, [rsp+0x60]
00007efc33fd6073  vpermilpd xmm1, xmm1, 0x00
00007efc33fd6079  vmovaps [rsp+0xB0], xmm1
00007efc33fd6082  vmovaps xmm1, [rsp+0x80]
00007efc33fd608b  vmovaps [rsp+0x80], xmm15
00007efc33fd6094  vmovaps xmm15, [rsp+0xB0]
00007efc33fd609d  vmovaps [rsp+0xB0], xmm14
00007efc33fd60a6  movaps xmm3, xmm1
00007efc33fd60a9  mulpd xmm3, xmm15
00007efc33fd60ae  vcmppd xmm14, xmm3, xmm3, 0x03
00007efc33fd60b3  ptest xmm14, xmm14
00007efc33fd60b9  jnz 0x00007EFC33FD8771
00007efc33fd60bf  lea r14, [rax+0x20]
00007efc33fd60c3  movups xmm1, [r13+r14*1]
00007efc33fd60c9  movaps [r15+0x110], xmm1
00007efc33fd60d1  vmovaps xmm14, [rsp+0x70]
00007efc33fd60d7  vmovaps [rsp+0x70], xmm1
00007efc33fd60dd  movaps xmm15, xmm14
00007efc33fd60e1  addpd xmm15, xmm4
00007efc33fd60e6  vcmppd xmm1, xmm15, xmm15, 0x03
00007efc33fd60ec  ptest xmm1, xmm1
00007efc33fd60f1  jnz 0x00007EFC33FD88BC
00007efc33fd60f7  vmovaps xmm1, [rsp+0x60]
00007efc33fd60fd  vpermilpd xmm1, xmm1, 0x00
00007efc33fd6103  movaps xmm14, xmm2
00007efc33fd6107  mulpd xmm14, xmm1
00007efc33fd610c  vcmppd xmm4, xmm14, xmm14, 0x03
00007efc33fd6112  ptest xmm4, xmm4
00007efc33fd6117  jnz 0x00007EFC33FD89FF
00007efc33fd611d  vmovaps xmm4, [rsp+0x50]
00007efc33fd6123  movaps xmm1, xmm4
00007efc33fd6126  addpd xmm1, xmm9
00007efc33fd612b  vcmppd xmm2, xmm1, xmm1, 0x03
00007efc33fd6130  ptest xmm2, xmm2
00007efc33fd6135  jnz 0x00007EFC33FD8B41
00007efc33fd613b  vmovaps xmm9, [rsp+0x30]
00007efc33fd6141  vpermilpd xmm9, xmm9, 0x00
00007efc33fd6147  vmovaps xmm2, [rsp+0x70]
00007efc33fd614d  vmovaps [rsp+0x50], xmm1
00007efc33fd6153  movaps xmm4, xmm2
00007efc33fd6156  mulpd xmm4, xmm9
00007efc33fd615b  vcmppd xmm1, xmm4, xmm4, 0x03
00007efc33fd6160  ptest xmm1, xmm1
00007efc33fd6165  jnz 0x00007EFC33FD8C82
00007efc33fd616b  vmovaps xmm1, [rsp+0x30]
00007efc33fd6171  vpermilpd xmm1, xmm1, 0x00
00007efc33fd6177  vmovaps xmm2, [rsp+0x90]
00007efc33fd6180  vmovaps [rsp+0x60], xmm15
00007efc33fd6186  movaps xmm9, xmm2
00007efc33fd618a  mulpd xmm9, xmm1
00007efc33fd618f  vcmppd xmm15, xmm9, xmm9, 0x03
00007efc33fd6195  ptest xmm15, xmm15
00007efc33fd619b  jnz 0x00007EFC33FD8DC3
00007efc33fd61a1  vmovaps xmm15, [rsp+0x80]
00007efc33fd61aa  movaps xmm1, xmm15
00007efc33fd61ae  addpd xmm1, xmm6
00007efc33fd61b2  vcmppd xmm2, xmm1, xmm1, 0x03
00007efc33fd61b7  ptest xmm2, xmm2
00007efc33fd61bc  jnz 0x00007EFC33FD8F05
00007efc33fd61c2  movaps xmm15, xmm5
00007efc33fd61c6  addpd xmm15, xmm3
00007efc33fd61cb  vcmppd xmm6, xmm15, xmm15, 0x03
00007efc33fd61d1  ptest xmm6, xmm6
00007efc33fd61d6  jnz 0x00007EFC33FD9046
00007efc33fd61dc  vmovaps xmm6, [rsp+0x30]
00007efc33fd61e2  vpermilpd xmm6, xmm6, 0x00
00007efc33fd61e8  movaps xmm5, xmm8
00007efc33fd61ec  mulpd xmm5, xmm6
00007efc33fd61f0  vcmppd xmm3, xmm5, xmm5, 0x03
00007efc33fd61f5  ptest xmm3, xmm3
00007efc33fd61fa  jnz 0x00007EFC33FD9188
00007efc33fd6200  vmovaps xmm8, [rsp+0x30]
00007efc33fd6206  vpermilpd xmm8, xmm8, 0x00
00007efc33fd620c  movaps xmm6, xmm10
00007efc33fd6210  mulpd xmm6, xmm8
00007efc33fd6215  vcmppd xmm3, xmm6, xmm6, 0x03
00007efc33fd621a  ptest xmm3, xmm3
00007efc33fd621f  jnz 0x00007EFC33FD92C9
00007efc33fd6225  vmovaps xmm8, [rsp+0x60]
00007efc33fd622b  movaps xmm10, xmm8
00007efc33fd622f  addpd xmm10, xmm14
00007efc33fd6234  vcmppd xmm3, xmm10, xmm10, 0x03
00007efc33fd623a  ptest xmm3, xmm3
00007efc33fd623f  jnz 0x00007EFC33FD940B
00007efc33fd6245  vmovaps xmm8, [rsp+0x50]
00007efc33fd624b  movaps xmm14, xmm8
00007efc33fd624f  addpd xmm14, xmm4
00007efc33fd6254  vcmppd xmm3, xmm14, xmm14, 0x03
00007efc33fd625a  ptest xmm3, xmm3
00007efc33fd625f  jnz 0x00007EFC33FD954F
00007efc33fd6265  vmovaps xmm8, [rsp+0x40]
00007efc33fd626b  vpermilpd xmm8, xmm8, 0x00
00007efc33fd6271  movaps xmm4, xmm13
00007efc33fd6275  mulpd xmm4, xmm8
00007efc33fd627a  vcmppd xmm3, xmm4, xmm4, 0x03
00007efc33fd627f  ptest xmm3, xmm3
00007efc33fd6284  jnz 0x00007EFC33FD9692
00007efc33fd628a  movaps xmm13, xmm15
00007efc33fd628e  addpd xmm13, xmm9
00007efc33fd6293  vcmppd xmm8, xmm13, xmm13, 0x03
00007efc33fd6299  ptest xmm8, xmm8
00007efc33fd629f  jnz 0x00007EFC33FD97D4
00007efc33fd62a5  movaps xmm15, xmm1
00007efc33fd62a9  addpd xmm15, xmm5
00007efc33fd62ae  vcmppd xmm9, xmm15, xmm15, 0x03
00007efc33fd62b4  ptest xmm9, xmm9
00007efc33fd62ba  jnz 0x00007EFC33FD9918
00007efc33fd62c0  vmovaps [rsp+0x30], xmm11
00007efc33fd62c6  vmovaps xmm1, [rsp+0x30]
00007efc33fd62cc  por xmm11, xmm1
00007efc33fd62d1  movaps [r15+0x250], xmm11
00007efc33fd62d9  vmovaps [rsp+0x30], xmm12
00007efc33fd62df  vmovaps xmm1, [rsp+0x30]
00007efc33fd62e5  por xmm12, xmm1
00007efc33fd62ea  movaps [r15+0x2A0], xmm12
00007efc33fd62f2  vmovaps xmm1, [rsp+0xA0]
00007efc33fd62fb  vmovaps xmm11, [rsp+0xA0]
00007efc33fd6304  por xmm1, xmm11
00007efc33fd6309  movaps [r15+0x1D0], xmm1
00007efc33fd6311  lea r14, [rax+0x40]
00007efc33fd6315  movups xmm1, [r13+r14*1]
00007efc33fd631b  movaps [r15+0x2C0], xmm1
00007efc33fd6323  vmovaps xmm11, [rsp+0x40]
00007efc33fd6329  vpermilpd xmm11, xmm11, 0x00
00007efc33fd632f  vmovaps xmm8, [rsp+0xE0]
00007efc33fd6338  movaps xmm9, xmm8
00007efc33fd633c  mulpd xmm9, xmm11
00007efc33fd6341  vcmppd xmm5, xmm9, xmm9, 0x03
00007efc33fd6347  ptest xmm5, xmm5
00007efc33fd634c  jnz 0x00007EFC33FD9A64
00007efc33fd6352  movaps xmm11, xmm10
00007efc33fd6356  addpd xmm11, xmm6
00007efc33fd635b  vcmppd xmm8, xmm11, xmm11, 0x03
00007efc33fd6361  ptest xmm8, xmm8
00007efc33fd6367  jnz 0x00007EFC33FD9BA8
00007efc33fd636d  movaps xmm10, xmm14
00007efc33fd6371  addpd xmm10, xmm4
00007efc33fd6376  vcmppd xmm8, xmm10, xmm10, 0x03
00007efc33fd637c  ptest xmm8, xmm8
00007efc33fd6382  jnz 0x00007EFC33FD9CEB
00007efc33fd6388  vmovaps xmm14, [rsp+0x40]
00007efc33fd638e  vpermilpd xmm14, xmm14, 0x00
00007efc33fd6394  movaps xmm8, xmm1
00007efc33fd6398  mulpd xmm8, xmm14
00007efc33fd639d  vcmppd xmm6, xmm8, xmm8, 0x03
00007efc33fd63a3  ptest xmm6, xmm6
00007efc33fd63a8  jnz 0x00007EFC33FD9E2E
00007efc33fd63ae  movaps xmm1, [r15+0x2B0]
00007efc33fd63b6  vmovaps xmm14, [rsp+0x40]
00007efc33fd63bc  vpermilpd xmm14, xmm14, 0x00
00007efc33fd63c2  movaps xmm6, xmm1
00007efc33fd63c5  mulpd xmm6, xmm14
00007efc33fd63ca  vcmppd xmm5, xmm6, xmm6, 0x03
00007efc33fd63cf  ptest xmm5, xmm5
00007efc33fd63d4  jnz 0x00007EFC33FD9F71
00007efc33fd63da  vmovaps xmm1, [rsp+0x10]
00007efc33fd63e0  vpermilpd xmm1, xmm1, 0x00
00007efc33fd63e6  movaps xmm14, xmm12
00007efc33fd63ea  mulpd xmm14, xmm1
00007efc33fd63ef  vcmppd xmm5, xmm14, xmm14, 0x03
00007efc33fd63f5  ptest xmm5, xmm5
00007efc33fd63fa  jnz 0x00007EFC33FDA0B2
00007efc33fd6400  movaps xmm1, xmm13
00007efc33fd6404  addpd xmm1, xmm9
00007efc33fd6409  vcmppd xmm12, xmm1, xmm1, 0x03
00007efc33fd640e  ptest xmm12, xmm12
00007efc33fd6414  jnz 0x00007EFC33FDA1F5
00007efc33fd641a  vmovaps xmm13, [rsp+0x10]
00007efc33fd6420  vpermilpd xmm13, xmm13, 0x00
00007efc33fd6426  movaps xmm12, xmm7
00007efc33fd642a  mulpd xmm12, xmm13
00007efc33fd642f  vcmppd xmm9, xmm12, xmm12, 0x03
00007efc33fd6435  ptest xmm9, xmm9
00007efc33fd643b  jnz 0x00007EFC33FDA337
00007efc33fd6441  movaps xmm13, xmm15
00007efc33fd6445  addpd xmm13, xmm8
00007efc33fd644a  vcmppd xmm9, xmm13, xmm13, 0x03
00007efc33fd6450  ptest xmm9, xmm9
00007efc33fd6456  jnz 0x00007EFC33FDA47A
00007efc33fd645c  movaps xmm15, [r15+0x290]
00007efc33fd6464  vmovaps xmm9, [rsp+0x10]
00007efc33fd646a  vpermilpd xmm9, xmm9, 0x00
00007efc33fd6470  movaps xmm8, xmm15
00007efc33fd6474  mulpd xmm8, xmm9
00007efc33fd6479  vcmppd xmm7, xmm8, xmm8, 0x03
00007efc33fd647f  ptest xmm7, xmm7
00007efc33fd6484  jnz 0x00007EFC33FDA5BE
00007efc33fd648a  movaps xmm15, xmm11
00007efc33fd648e  addpd xmm15, xmm6
00007efc33fd6493  vcmppd xmm9, xmm15, xmm15, 0x03
00007efc33fd6499  ptest xmm9, xmm9
00007efc33fd649f  jnz 0x00007EFC33FDA702
00007efc33fd64a5  movaps xmm11, [r15+0x1E0]
00007efc33fd64ad  vmovaps xmm9, [rsp+0x10]
00007efc33fd64b3  vpermilpd xmm9, xmm9, 0x00
00007efc33fd64b9  movaps xmm7, xmm11
00007efc33fd64bd  mulpd xmm7, xmm9
00007efc33fd64c2  vcmppd xmm6, xmm7, xmm7, 0x03
00007efc33fd64c7  ptest xmm6, xmm6
00007efc33fd64cc  jnz 0x00007EFC33FDA845
00007efc33fd64d2  movaps xmm11, xmm10
00007efc33fd64d6  addpd xmm11, xmm14
00007efc33fd64db  vcmppd xmm9, xmm11, xmm11, 0x03
00007efc33fd64e1  ptest xmm9, xmm9
00007efc33fd64e7  jnz 0x00007EFC33FDA987
00007efc33fd64ed  lea r14, [rax+0x70]
00007efc33fd64f1  movups xmm14, [r13+r14*1]
00007efc33fd64f7  movaps [r15+0x240], xmm14
00007efc33fd64ff  movaps xmm10, xmm1
00007efc33fd6503  addpd xmm10, xmm12
00007efc33fd6508  vcmppd xmm9, xmm10, xmm10, 0x03
00007efc33fd650e  ptest xmm9, xmm9
00007efc33fd6514  jnz 0x00007EFC33FDAAD5
00007efc33fd651a  movaps [r15+0x170], xmm10
00007efc33fd6522  vmovaps xmm1, [rsp+0x20]
00007efc33fd6528  vpermilpd xmm1, xmm1, 0x00
00007efc33fd652e  movaps xmm12, xmm14
00007efc33fd6532  mulpd xmm12, xmm1
00007efc33fd6537  vcmppd xmm9, xmm12, xmm12, 0x03
00007efc33fd653d  ptest xmm9, xmm9
00007efc33fd6543  jnz 0x00007EFC33FDAC18
00007efc33fd6549  vmovaps xmm1, [rsp+0x20]
00007efc33fd654f  vpermilpd xmm1, xmm1, 0x00
00007efc33fd6555  vmovaps xmm9, [rsp+0xB0]
00007efc33fd655e  movaps xmm14, xmm9
00007efc33fd6562  mulpd xmm14, xmm1
00007efc33fd6567  vcmppd xmm6, xmm14, xmm14, 0x03
00007efc33fd656d  ptest xmm6, xmm6
00007efc33fd6572  jnz 0x00007EFC33FDAD5B
00007efc33fd6578  movaps [r15+0x180], xmm14
00007efc33fd6580  movaps xmm1, xmm13
00007efc33fd6584  addpd xmm1, xmm8
00007efc33fd6589  vcmppd xmm9, xmm1, xmm1, 0x03
00007efc33fd658e  ptest xmm9, xmm9
00007efc33fd6594  jnz 0x00007EFC33FDAE9E
00007efc33fd659a  movaps [r15+0x210], xmm1
00007efc33fd65a2  movups xmm13, [r13+rax*1]
00007efc33fd65a8  lea r14, [rax+0x10]
00007efc33fd65ac  movups xmm9, [r13+r14*1]
00007efc33fd65b2  movaps [r15+0x230], xmm9
00007efc33fd65ba  movaps xmm8, xmm15
00007efc33fd65be  addpd xmm8, xmm7
00007efc33fd65c3  vcmppd xmm6, xmm8, xmm8, 0x03
00007efc33fd65c9  ptest xmm6, xmm6
00007efc33fd65ce  jnz 0x00007EFC33FDAFF4
00007efc33fd65d4  movaps [r15+0x130], xmm8
00007efc33fd65dc  vmovaps xmm15, [rsp+0x20]
00007efc33fd65e2  vpermilpd xmm15, xmm15, 0x00
00007efc33fd65e8  movaps xmm7, xmm9
00007efc33fd65ec  mulpd xmm7, xmm15
00007efc33fd65f1  vcmppd xmm6, xmm7, xmm7, 0x03
00007efc33fd65f6  ptest xmm6, xmm6
00007efc33fd65fb  jnz 0x00007EFC33FDB137
00007efc33fd6601  movaps [r15+0x220], xmm7
00007efc33fd6609  vmovaps xmm15, [rsp+0x20]
00007efc33fd660f  vpermilpd xmm15, xmm15, 0x00
00007efc33fd6615  movaps xmm9, xmm13
00007efc33fd6619  mulpd xmm9, xmm15
00007efc33fd661e  vcmppd xmm6, xmm9, xmm9, 0x03
00007efc33fd6624  ptest xmm6, xmm6
00007efc33fd6629  jnz 0x00007EFC33FDB279
00007efc33fd662f  movaps xmm15, xmm11
00007efc33fd6633  addpd xmm15, xmm12
00007efc33fd6638  vcmppd xmm13, xmm15, xmm15, 0x03
00007efc33fd663e  ptest xmm13, xmm13
00007efc33fd6644  jnz 0x00007EFC33FDB3BD
00007efc33fd664a  movaps [r15+0x140], xmm15
00007efc33fd6652  movaps xmm13, xmm10
00007efc33fd6656  addpd xmm13, xmm14
00007efc33fd665b  vcmppd xmm12, xmm13, xmm13, 0x03
00007efc33fd6661  ptest xmm12, xmm12
00007efc33fd6667  jnz 0x00007EFC33FDB501
00007efc33fd666d  movaps [r15+0x150], xmm13
00007efc33fd6675  movaps xmm14, xmm1
00007efc33fd6679  addpd xmm14, xmm7
00007efc33fd667e  vcmppd xmm12, xmm14, xmm14, 0x03
00007efc33fd6684  ptest xmm12, xmm12
00007efc33fd668a  jnz 0x00007EFC33FDB645
00007efc33fd6690  movaps [r15+0x160], xmm14
00007efc33fd6698  movaps xmm1, xmm8
00007efc33fd669c  addpd xmm1, xmm9
00007efc33fd66a1  vcmppd xmm12, xmm1, xmm1, 0x03
00007efc33fd66a6  ptest xmm12, xmm12
00007efc33fd66ac  jnz 0x00007EFC33FDB787
00007efc33fd66b2  movaps [r15+0x120], xmm1
00007efc33fd66ba  movups [r13+r11*1], xmm15
00007efc33fd66c0  lea rax, [r11+0x10]
00007efc33fd66c4  movups [r13+rax*1], xmm13
00007efc33fd66ca  lea rax, [r11+0x20]
00007efc33fd66ce  movups [r13+rax*1], xmm14
00007efc33fd66d4  lea rax, [r11+0x30]
00007efc33fd66d8  movups [r13+rax*1], xmm1
00007efc33fd66de  mov eax, [r15+0x108]
00007efc33fd66e5  sahf
00007efc33fd66e6  jnz 0x00007EFC33FD6718
00007efc33fd66e8  cmp dword ptr [r15+0x318], 0x00
00007efc33fd66f0  jz 0x00007EFC33FDB900
00007efc33fd66f6  nop [rax+rax*1], ax
00007efc33fd66ff  nop [rax+rax*1], eax
00007efc33fd6707  mov eax, 0x410444
00007efc33fd670c  mov [r15+0x100], rax
00007efc33fd6713  jmp 0x00007EFC33DFE110
00007efc33fd6718  cmp dword ptr [r15+0x318], 0x00
00007efc33fd6720  jz 0x00007EFC33FD57E0
00007efc33fd6726  nop [rax+rax*1], ax
00007efc33fd672f  nop [rax+rax*1], eax
00007efc33fd6737  mov eax, 0x410278
00007efc33fd673c  mov [r15+0x100], rax
00007efc33fd6743  jmp 0x00007EFC33DFE110
00007efc33fd6748  int3
00007efc33fd6749  call 0x00007EFC33E0A4B0
00007efc33fd674e  jmp 0x00007EFC33FD5828
00007efc33fd6753  call 0x00007EFC33E09240
00007efc33fd6758  jmp 0x00007EFC33FD5832
00007efc33fd675d  call 0x00007EFC33E0A4B0
00007efc33fd6762  jmp 0x00007EFC33FD588F
00007efc33fd6767  call 0x00007EFC33E09240
00007efc33fd676c  jmp 0x00007EFC33FD5899
00007efc33fd6771  call 0x00007EFC33E0A4B0
00007efc33fd6776  jmp 0x00007EFC33FD58DD
00007efc33fd677b  call 0x00007EFC33E09240
00007efc33fd6780  jmp 0x00007EFC33FD58E7
00007efc33fd6785  call 0x00007EFC33EB47C0
00007efc33fd678a  jmp 0x00007EFC33FD5926
00007efc33fd678f  call 0x00007EFC33E0B720
00007efc33fd6794  jmp 0x00007EFC33FD593A
00007efc33fd6799  call 0x00007EFC33EBFC30
00007efc33fd679e  jmp 0x00007EFC33FD5958
00007efc33fd67a3  call 0x00007EFC33EBE9C0
00007efc33fd67a8  jmp 0x00007EFC33FD5962
00007efc33fd67ad  call 0x00007EFC33EBD750
00007efc33fd67b2  jmp 0x00007EFC33FD596C
00007efc33fd67b7  sub rsp, 0x08
00007efc33fd67bb  push rax
00007efc33fd67bc  push rcx
00007efc33fd67bd  push rdx
00007efc33fd67be  push rdi
00007efc33fd67bf  push rsi
00007efc33fd67c0  push r8
00007efc33fd67c2  push r9
00007efc33fd67c4  push r10
00007efc33fd67c6  push r11
00007efc33fd67c8  sub rsp, 0xF0
00007efc33fd67cf  vmovaps [rsp], xmm0
00007efc33fd67d4  vmovaps [rsp+0x10], xmm1
00007efc33fd67da  vmovaps [rsp+0x20], xmm2
00007efc33fd67e0  vmovaps [rsp+0x30], xmm3
00007efc33fd67e6  vmovaps [rsp+0x40], xmm4
00007efc33fd67ec  vmovaps [rsp+0x50], xmm5
00007efc33fd67f2  vmovaps [rsp+0x60], xmm6
00007efc33fd67f8  vmovaps [rsp+0x70], xmm7
00007efc33fd67fe  vmovaps [rsp+0x80], xmm9
00007efc33fd6807  vmovaps [rsp+0x90], xmm10
00007efc33fd6810  vmovaps [rsp+0xA0], xmm11
00007efc33fd6819  vmovaps [rsp+0xB0], xmm12
00007efc33fd6822  vmovaps [rsp+0xC0], xmm13
00007efc33fd682b  vmovaps [rsp+0xD0], xmm14
00007efc33fd6834  vmovaps [rsp+0xE0], xmm15
00007efc33fd683d  sub rsp, 0x30
00007efc33fd6841  movaps [rsp], xmm8
00007efc33fd6846  movaps [rsp+0x10], xmm12
00007efc33fd684c  movaps [rsp+0x20], xmm15
00007efc33fd6852  lea rdi, [rsp]
00007efc33fd6856  mov esi, 0x00
00007efc33fd685b  mov rax, 0x5D9448894530
00007efc33fd6865  call rax
00007efc33fd6867  movaps xmm8, [rsp]
00007efc33fd686c  add rsp, 0x30
00007efc33fd6870  vmovaps xmm0, [rsp]
00007efc33fd6875  vmovaps xmm1, [rsp+0x10]
00007efc33fd687b  vmovaps xmm2, [rsp+0x20]
00007efc33fd6881  vmovaps xmm3, [rsp+0x30]
00007efc33fd6887  vmovaps xmm4, [rsp+0x40]
00007efc33fd688d  vmovaps xmm5, [rsp+0x50]
00007efc33fd6893  vmovaps xmm6, [rsp+0x60]
00007efc33fd6899  vmovaps xmm7, [rsp+0x70]
00007efc33fd689f  vmovaps xmm9, [rsp+0x80]
00007efc33fd68a8  vmovaps xmm10, [rsp+0x90]
00007efc33fd68b1  vmovaps xmm11, [rsp+0xA0]
00007efc33fd68ba  vmovaps xmm12, [rsp+0xB0]
00007efc33fd68c3  vmovaps xmm13, [rsp+0xC0]
00007efc33fd68cc  vmovaps xmm14, [rsp+0xD0]
00007efc33fd68d5  vmovaps xmm15, [rsp+0xE0]
00007efc33fd68de  add rsp, 0xF0
00007efc33fd68e5  pop r11
00007efc33fd68e7  pop r10
00007efc33fd68e9  pop r9
00007efc33fd68eb  pop r8
00007efc33fd68ed  pop rsi
00007efc33fd68ee  pop rdi
00007efc33fd68ef  pop rdx
00007efc33fd68f0  pop rcx
00007efc33fd68f1  pop rax
00007efc33fd68f2  add rsp, 0x08
00007efc33fd68f6  jmp 0x00007EFC33FD599A
00007efc33fd68fb  sub rsp, 0x08
00007efc33fd68ff  push rax
00007efc33fd6900  push rcx
00007efc33fd6901  push rdx
00007efc33fd6902  push rdi
00007efc33fd6903  push rsi
00007efc33fd6904  push r8
00007efc33fd6906  push r9
00007efc33fd6908  push r10
00007efc33fd690a  push r11
00007efc33fd690c  sub rsp, 0xF0
00007efc33fd6913  vmovaps [rsp], xmm0
00007efc33fd6918  vmovaps [rsp+0x10], xmm1
00007efc33fd691e  vmovaps [rsp+0x20], xmm2
00007efc33fd6924  vmovaps [rsp+0x30], xmm3
00007efc33fd692a  vmovaps [rsp+0x40], xmm4
00007efc33fd6930  vmovaps [rsp+0x50], xmm5
00007efc33fd6936  vmovaps [rsp+0x60], xmm6
00007efc33fd693c  vmovaps [rsp+0x70], xmm8
00007efc33fd6942  vmovaps [rsp+0x80], xmm9
00007efc33fd694b  vmovaps [rsp+0x90], xmm10
00007efc33fd6954  vmovaps [rsp+0xA0], xmm11
00007efc33fd695d  vmovaps [rsp+0xB0], xmm12
00007efc33fd6966  vmovaps [rsp+0xC0], xmm13
00007efc33fd696f  vmovaps [rsp+0xD0], xmm14
00007efc33fd6978  vmovaps [rsp+0xE0], xmm15
00007efc33fd6981  sub rsp, 0x30
00007efc33fd6985  movaps [rsp], xmm7
00007efc33fd6989  movaps [rsp+0x10], xmm9
00007efc33fd698f  movaps [rsp+0x20], xmm15
00007efc33fd6995  lea rdi, [rsp]
00007efc33fd6999  mov esi, 0x00
00007efc33fd699e  mov rax, 0x5D9448894530
00007efc33fd69a8  call rax
00007efc33fd69aa  movaps xmm7, [rsp]
00007efc33fd69ae  add rsp, 0x30
00007efc33fd69b2  vmovaps xmm0, [rsp]
00007efc33fd69b7  vmovaps xmm1, [rsp+0x10]
00007efc33fd69bd  vmovaps xmm2, [rsp+0x20]
00007efc33fd69c3  vmovaps xmm3, [rsp+0x30]
00007efc33fd69c9  vmovaps xmm4, [rsp+0x40]
00007efc33fd69cf  vmovaps xmm5, [rsp+0x50]
00007efc33fd69d5  vmovaps xmm6, [rsp+0x60]
00007efc33fd69db  vmovaps xmm8, [rsp+0x70]
00007efc33fd69e1  vmovaps xmm9, [rsp+0x80]
00007efc33fd69ea  vmovaps xmm10, [rsp+0x90]
00007efc33fd69f3  vmovaps xmm11, [rsp+0xA0]
00007efc33fd69fc  vmovaps xmm12, [rsp+0xB0]
00007efc33fd6a05  vmovaps xmm13, [rsp+0xC0]
00007efc33fd6a0e  vmovaps xmm14, [rsp+0xD0]
00007efc33fd6a17  vmovaps xmm15, [rsp+0xE0]
00007efc33fd6a20  add rsp, 0xF0
00007efc33fd6a27  pop r11
00007efc33fd6a29  pop r10
00007efc33fd6a2b  pop r9
00007efc33fd6a2d  pop r8
00007efc33fd6a2f  pop rsi
00007efc33fd6a30  pop rdi
00007efc33fd6a31  pop rdx
00007efc33fd6a32  pop rcx
00007efc33fd6a33  pop rax
00007efc33fd6a34  add rsp, 0x08
00007efc33fd6a38  jmp 0x00007EFC33FD59C8
00007efc33fd6a3d  sub rsp, 0x08
00007efc33fd6a41  push rax
00007efc33fd6a42  push rcx
00007efc33fd6a43  push rdx
00007efc33fd6a44  push rdi
00007efc33fd6a45  push rsi
00007efc33fd6a46  push r8
00007efc33fd6a48  push r9
00007efc33fd6a4a  push r10
00007efc33fd6a4c  push r11
00007efc33fd6a4e  sub rsp, 0xF0
00007efc33fd6a55  vmovaps [rsp], xmm0
00007efc33fd6a5a  vmovaps [rsp+0x10], xmm1
00007efc33fd6a60  vmovaps [rsp+0x20], xmm2
00007efc33fd6a66  vmovaps [rsp+0x30], xmm3
00007efc33fd6a6c  vmovaps [rsp+0x40], xmm4
00007efc33fd6a72  vmovaps [rsp+0x50], xmm5
00007efc33fd6a78  vmovaps [rsp+0x60], xmm6
00007efc33fd6a7e  vmovaps [rsp+0x70], xmm7
00007efc33fd6a84  vmovaps [rsp+0x80], xmm8
00007efc33fd6a8d  vmovaps [rsp+0x90], xmm10
00007efc33fd6a96  vmovaps [rsp+0xA0], xmm11
00007efc33fd6a9f  vmovaps [rsp+0xB0], xmm12
00007efc33fd6aa8  vmovaps [rsp+0xC0], xmm13
00007efc33fd6ab1  vmovaps [rsp+0xD0], xmm14
00007efc33fd6aba  vmovaps [rsp+0xE0], xmm15
00007efc33fd6ac3  sub rsp, 0x30
00007efc33fd6ac7  movaps [rsp], xmm9
00007efc33fd6acc  movaps [rsp+0x10], xmm12
00007efc33fd6ad2  movaps [rsp+0x20], xmm10
00007efc33fd6ad8  lea rdi, [rsp]
00007efc33fd6adc  mov esi, 0x00
00007efc33fd6ae1  mov rax, 0x5D9448894530
00007efc33fd6aeb  call rax
00007efc33fd6aed  movaps xmm9, [rsp]
00007efc33fd6af2  add rsp, 0x30
00007efc33fd6af6  vmovaps xmm0, [rsp]
00007efc33fd6afb  vmovaps xmm1, [rsp+0x10]
00007efc33fd6b01  vmovaps xmm2, [rsp+0x20]
00007efc33fd6b07  vmovaps xmm3, [rsp+0x30]
00007efc33fd6b0d  vmovaps xmm4, [rsp+0x40]
00007efc33fd6b13  vmovaps xmm5, [rsp+0x50]
00007efc33fd6b19  vmovaps xmm6, [rsp+0x60]
00007efc33fd6b1f  vmovaps xmm7, [rsp+0x70]
00007efc33fd6b25  vmovaps xmm8, [rsp+0x80]
00007efc33fd6b2e  vmovaps xmm10, [rsp+0x90]
00007efc33fd6b37  vmovaps xmm11, [rsp+0xA0]
00007efc33fd6b40  vmovaps xmm12, [rsp+0xB0]
00007efc33fd6b49  vmovaps xmm13, [rsp+0xC0]
00007efc33fd6b52  vmovaps xmm14, [rsp+0xD0]
00007efc33fd6b5b  vmovaps xmm15, [rsp+0xE0]
00007efc33fd6b64  add rsp, 0xF0
00007efc33fd6b6b  pop r11
00007efc33fd6b6d  pop r10
00007efc33fd6b6f  pop r9
00007efc33fd6b71  pop r8
00007efc33fd6b73  pop rsi
00007efc33fd6b74  pop rdi
00007efc33fd6b75  pop rdx
00007efc33fd6b76  pop rcx
00007efc33fd6b77  pop rax
00007efc33fd6b78  add rsp, 0x08
00007efc33fd6b7c  jmp 0x00007EFC33FD59EC
00007efc33fd6b81  sub rsp, 0x08
00007efc33fd6b85  push rax
00007efc33fd6b86  push rcx
00007efc33fd6b87  push rdx
00007efc33fd6b88  push rdi
00007efc33fd6b89  push rsi
00007efc33fd6b8a  push r8
00007efc33fd6b8c  push r9
00007efc33fd6b8e  push r10
00007efc33fd6b90  push r11
00007efc33fd6b92  sub rsp, 0xF0
00007efc33fd6b99  vmovaps [rsp], xmm0
00007efc33fd6b9e  vmovaps [rsp+0x10], xmm1
00007efc33fd6ba4  vmovaps [rsp+0x20], xmm2
00007efc33fd6baa  vmovaps [rsp+0x30], xmm3
00007efc33fd6bb0  vmovaps [rsp+0x40], xmm4
00007efc33fd6bb6  vmovaps [rsp+0x50], xmm5
00007efc33fd6bbc  vmovaps [rsp+0x60], xmm6
00007efc33fd6bc2  vmovaps [rsp+0x70], xmm7
00007efc33fd6bc8  vmovaps [rsp+0x80], xmm8
00007efc33fd6bd1  vmovaps [rsp+0x90], xmm9
00007efc33fd6bda  vmovaps [rsp+0xA0], xmm11
00007efc33fd6be3  vmovaps [rsp+0xB0], xmm12
00007efc33fd6bec  vmovaps [rsp+0xC0], xmm13
00007efc33fd6bf5  vmovaps [rsp+0xD0], xmm14
00007efc33fd6bfe  vmovaps [rsp+0xE0], xmm15
00007efc33fd6c07  sub rsp, 0x30
00007efc33fd6c0b  movaps [rsp], xmm10
00007efc33fd6c10  movaps [rsp+0x10], xmm12
00007efc33fd6c16  movaps [rsp+0x20], xmm11
00007efc33fd6c1c  lea rdi, [rsp]
00007efc33fd6c20  mov esi, 0x00
00007efc33fd6c25  mov rax, 0x5D9448894530
00007efc33fd6c2f  call rax
00007efc33fd6c31  movaps xmm10, [rsp]
00007efc33fd6c36  add rsp, 0x30
00007efc33fd6c3a  vmovaps xmm0, [rsp]
00007efc33fd6c3f  vmovaps xmm1, [rsp+0x10]
00007efc33fd6c45  vmovaps xmm2, [rsp+0x20]
00007efc33fd6c4b  vmovaps xmm3, [rsp+0x30]
00007efc33fd6c51  vmovaps xmm4, [rsp+0x40]
00007efc33fd6c57  vmovaps xmm5, [rsp+0x50]
00007efc33fd6c5d  vmovaps xmm6, [rsp+0x60]
00007efc33fd6c63  vmovaps xmm7, [rsp+0x70]
00007efc33fd6c69  vmovaps xmm8, [rsp+0x80]
00007efc33fd6c72  vmovaps xmm9, [rsp+0x90]
00007efc33fd6c7b  vmovaps xmm11, [rsp+0xA0]
00007efc33fd6c84  vmovaps xmm12, [rsp+0xB0]
00007efc33fd6c8d  vmovaps xmm13, [rsp+0xC0]
00007efc33fd6c96  vmovaps xmm14, [rsp+0xD0]
00007efc33fd6c9f  vmovaps xmm15, [rsp+0xE0]
00007efc33fd6ca8  add rsp, 0xF0
00007efc33fd6caf  pop r11
00007efc33fd6cb1  pop r10
00007efc33fd6cb3  pop r9
00007efc33fd6cb5  pop r8
00007efc33fd6cb7  pop rsi
00007efc33fd6cb8  pop rdi
00007efc33fd6cb9  pop rdx
00007efc33fd6cba  pop rcx
00007efc33fd6cbb  pop rax
00007efc33fd6cbc  add rsp, 0x08
00007efc33fd6cc0  jmp 0x00007EFC33FD5A06
00007efc33fd6cc5  sub rsp, 0x08
00007efc33fd6cc9  push rax
00007efc33fd6cca  push rcx
00007efc33fd6ccb  push rdx
00007efc33fd6ccc  push rdi
00007efc33fd6ccd  push rsi
00007efc33fd6cce  push r8
00007efc33fd6cd0  push r9
00007efc33fd6cd2  push r10
00007efc33fd6cd4  push r11
00007efc33fd6cd6  sub rsp, 0xF0
00007efc33fd6cdd  vmovaps [rsp], xmm0
00007efc33fd6ce2  vmovaps [rsp+0x10], xmm1
00007efc33fd6ce8  vmovaps [rsp+0x20], xmm2
00007efc33fd6cee  vmovaps [rsp+0x30], xmm3
00007efc33fd6cf4  vmovaps [rsp+0x40], xmm4
00007efc33fd6cfa  vmovaps [rsp+0x50], xmm5
00007efc33fd6d00  vmovaps [rsp+0x60], xmm7
00007efc33fd6d06  vmovaps [rsp+0x70], xmm8
00007efc33fd6d0c  vmovaps [rsp+0x80], xmm9
00007efc33fd6d15  vmovaps [rsp+0x90], xmm10
00007efc33fd6d1e  vmovaps [rsp+0xA0], xmm11
00007efc33fd6d27  vmovaps [rsp+0xB0], xmm12
00007efc33fd6d30  vmovaps [rsp+0xC0], xmm13
00007efc33fd6d39  vmovaps [rsp+0xD0], xmm14
00007efc33fd6d42  vmovaps [rsp+0xE0], xmm15
00007efc33fd6d4b  sub rsp, 0x30
00007efc33fd6d4f  movaps [rsp], xmm6
00007efc33fd6d53  movaps [rsp+0x10], xmm12
00007efc33fd6d59  movaps [rsp+0x20], xmm11
00007efc33fd6d5f  lea rdi, [rsp]
00007efc33fd6d63  mov esi, 0x00
00007efc33fd6d68  mov rax, 0x5D9448894530
00007efc33fd6d72  call rax
00007efc33fd6d74  movaps xmm6, [rsp]
00007efc33fd6d78  add rsp, 0x30
00007efc33fd6d7c  vmovaps xmm0, [rsp]
00007efc33fd6d81  vmovaps xmm1, [rsp+0x10]
00007efc33fd6d87  vmovaps xmm2, [rsp+0x20]
00007efc33fd6d8d  vmovaps xmm3, [rsp+0x30]
00007efc33fd6d93  vmovaps xmm4, [rsp+0x40]
00007efc33fd6d99  vmovaps xmm5, [rsp+0x50]
00007efc33fd6d9f  vmovaps xmm7, [rsp+0x60]
00007efc33fd6da5  vmovaps xmm8, [rsp+0x70]
00007efc33fd6dab  vmovaps xmm9, [rsp+0x80]
00007efc33fd6db4  vmovaps xmm10, [rsp+0x90]
00007efc33fd6dbd  vmovaps xmm11, [rsp+0xA0]
00007efc33fd6dc6  vmovaps xmm12, [rsp+0xB0]
00007efc33fd6dcf  vmovaps xmm13, [rsp+0xC0]
00007efc33fd6dd8  vmovaps xmm14, [rsp+0xD0]
00007efc33fd6de1  vmovaps xmm15, [rsp+0xE0]
00007efc33fd6dea  add rsp, 0xF0
00007efc33fd6df1  pop r11
00007efc33fd6df3  pop r10
00007efc33fd6df5  pop r9
00007efc33fd6df7  pop r8
00007efc33fd6df9  pop rsi
00007efc33fd6dfa  pop rdi
00007efc33fd6dfb  pop rdx
00007efc33fd6dfc  pop rcx
00007efc33fd6dfd  pop rax
00007efc33fd6dfe  add rsp, 0x08
00007efc33fd6e02  jmp 0x00007EFC33FD5A27
00007efc33fd6e07  sub rsp, 0x08
00007efc33fd6e0b  push rax
00007efc33fd6e0c  push rcx
00007efc33fd6e0d  push rdx
00007efc33fd6e0e  push rdi
00007efc33fd6e0f  push rsi
00007efc33fd6e10  push r8
00007efc33fd6e12  push r9
00007efc33fd6e14  push r10
00007efc33fd6e16  push r11
00007efc33fd6e18  sub rsp, 0xF0
00007efc33fd6e1f  vmovaps [rsp], xmm0
00007efc33fd6e24  vmovaps [rsp+0x10], xmm1
00007efc33fd6e2a  vmovaps [rsp+0x20], xmm2
00007efc33fd6e30  vmovaps [rsp+0x30], xmm4
00007efc33fd6e36  vmovaps [rsp+0x40], xmm5
00007efc33fd6e3c  vmovaps [rsp+0x50], xmm6
00007efc33fd6e42  vmovaps [rsp+0x60], xmm7
00007efc33fd6e48  vmovaps [rsp+0x70], xmm8
00007efc33fd6e4e  vmovaps [rsp+0x80], xmm9
00007efc33fd6e57  vmovaps [rsp+0x90], xmm10
00007efc33fd6e60  vmovaps [rsp+0xA0], xmm11
00007efc33fd6e69  vmovaps [rsp+0xB0], xmm12
00007efc33fd6e72  vmovaps [rsp+0xC0], xmm13
00007efc33fd6e7b  vmovaps [rsp+0xD0], xmm14
00007efc33fd6e84  vmovaps [rsp+0xE0], xmm15
00007efc33fd6e8d  sub rsp, 0x30
00007efc33fd6e91  movaps [rsp], xmm3
00007efc33fd6e95  movaps [rsp+0x10], xmm5
00007efc33fd6e9a  movaps [rsp+0x20], xmm4
00007efc33fd6e9f  lea rdi, [rsp]
00007efc33fd6ea3  mov esi, 0x00
00007efc33fd6ea8  mov rax, 0x5D9448894530
00007efc33fd6eb2  call rax
00007efc33fd6eb4  movaps xmm3, [rsp]
00007efc33fd6eb8  add rsp, 0x30
00007efc33fd6ebc  vmovaps xmm0, [rsp]
00007efc33fd6ec1  vmovaps xmm1, [rsp+0x10]
00007efc33fd6ec7  vmovaps xmm2, [rsp+0x20]
00007efc33fd6ecd  vmovaps xmm4, [rsp+0x30]
00007efc33fd6ed3  vmovaps xmm5, [rsp+0x40]
00007efc33fd6ed9  vmovaps xmm6, [rsp+0x50]
00007efc33fd6edf  vmovaps xmm7, [rsp+0x60]
00007efc33fd6ee5  vmovaps xmm8, [rsp+0x70]
00007efc33fd6eeb  vmovaps xmm9, [rsp+0x80]
00007efc33fd6ef4  vmovaps xmm10, [rsp+0x90]
00007efc33fd6efd  vmovaps xmm11, [rsp+0xA0]
00007efc33fd6f06  vmovaps xmm12, [rsp+0xB0]
00007efc33fd6f0f  vmovaps xmm13, [rsp+0xC0]
00007efc33fd6f18  vmovaps xmm14, [rsp+0xD0]
00007efc33fd6f21  vmovaps xmm15, [rsp+0xE0]
00007efc33fd6f2a  add rsp, 0xF0
00007efc33fd6f31  pop r11
00007efc33fd6f33  pop r10
00007efc33fd6f35  pop r9
00007efc33fd6f37  pop r8
00007efc33fd6f39  pop rsi
00007efc33fd6f3a  pop rdi
00007efc33fd6f3b  pop rdx
00007efc33fd6f3c  pop rcx
00007efc33fd6f3d  pop rax
00007efc33fd6f3e  add rsp, 0x08
00007efc33fd6f42  jmp 0x00007EFC33FD5A88
00007efc33fd6f47  sub rsp, 0x08
00007efc33fd6f4b  push rax
00007efc33fd6f4c  push rcx
00007efc33fd6f4d  push rdx
00007efc33fd6f4e  push rdi
00007efc33fd6f4f  push rsi
00007efc33fd6f50  push r8
00007efc33fd6f52  push r9
00007efc33fd6f54  push r10
00007efc33fd6f56  push r11
00007efc33fd6f58  sub rsp, 0xF0
00007efc33fd6f5f  vmovaps [rsp], xmm0
00007efc33fd6f64  vmovaps [rsp+0x10], xmm1
00007efc33fd6f6a  vmovaps [rsp+0x20], xmm2
00007efc33fd6f70  vmovaps [rsp+0x30], xmm3
00007efc33fd6f76  vmovaps [rsp+0x40], xmm4
00007efc33fd6f7c  vmovaps [rsp+0x50], xmm6
00007efc33fd6f82  vmovaps [rsp+0x60], xmm7
00007efc33fd6f88  vmovaps [rsp+0x70], xmm8
00007efc33fd6f8e  vmovaps [rsp+0x80], xmm9
00007efc33fd6f97  vmovaps [rsp+0x90], xmm10
00007efc33fd6fa0  vmovaps [rsp+0xA0], xmm11
00007efc33fd6fa9  vmovaps [rsp+0xB0], xmm12
00007efc33fd6fb2  vmovaps [rsp+0xC0], xmm13
00007efc33fd6fbb  vmovaps [rsp+0xD0], xmm14
00007efc33fd6fc4  vmovaps [rsp+0xE0], xmm15
00007efc33fd6fcd  sub rsp, 0x30
00007efc33fd6fd1  movaps [rsp], xmm5
00007efc33fd6fd5  movaps [rsp+0x10], xmm8
00007efc33fd6fdb  movaps [rsp+0x20], xmm15
00007efc33fd6fe1  lea rdi, [rsp]
00007efc33fd6fe5  mov esi, 0x00
00007efc33fd6fea  mov rax, 0x5D9448894530
00007efc33fd6ff4  call rax
00007efc33fd6ff6  movaps xmm5, [rsp]
00007efc33fd6ffa  add rsp, 0x30
00007efc33fd6ffe  vmovaps xmm0, [rsp]
00007efc33fd7003  vmovaps xmm1, [rsp+0x10]
00007efc33fd7009  vmovaps xmm2, [rsp+0x20]
00007efc33fd700f  vmovaps xmm3, [rsp+0x30]
00007efc33fd7015  vmovaps xmm4, [rsp+0x40]
00007efc33fd701b  vmovaps xmm6, [rsp+0x50]
00007efc33fd7021  vmovaps xmm7, [rsp+0x60]
00007efc33fd7027  vmovaps xmm8, [rsp+0x70]
00007efc33fd702d  vmovaps xmm9, [rsp+0x80]
00007efc33fd7036  vmovaps xmm10, [rsp+0x90]
00007efc33fd703f  vmovaps xmm11, [rsp+0xA0]
00007efc33fd7048  vmovaps xmm12, [rsp+0xB0]
00007efc33fd7051  vmovaps xmm13, [rsp+0xC0]
00007efc33fd705a  vmovaps xmm14, [rsp+0xD0]
00007efc33fd7063  vmovaps xmm15, [rsp+0xE0]
00007efc33fd706c  add rsp, 0xF0
00007efc33fd7073  pop r11
00007efc33fd7075  pop r10
00007efc33fd7077  pop r9
00007efc33fd7079  pop r8
00007efc33fd707b  pop rsi
00007efc33fd707c  pop rdi
00007efc33fd707d  pop rdx
00007efc33fd707e  pop rcx
00007efc33fd707f  pop rax
00007efc33fd7080  add rsp, 0x08
00007efc33fd7084  jmp 0x00007EFC33FD5AC0
00007efc33fd7089  sub rsp, 0x08
00007efc33fd708d  push rax
00007efc33fd708e  push rcx
00007efc33fd708f  push rdx
00007efc33fd7090  push rdi
00007efc33fd7091  push rsi
00007efc33fd7092  push r8
00007efc33fd7094  push r9
00007efc33fd7096  push r10
00007efc33fd7098  push r11
00007efc33fd709a  sub rsp, 0xF0
00007efc33fd70a1  vmovaps [rsp], xmm0
00007efc33fd70a6  vmovaps [rsp+0x10], xmm1
00007efc33fd70ac  vmovaps [rsp+0x20], xmm2
00007efc33fd70b2  vmovaps [rsp+0x30], xmm3
00007efc33fd70b8  vmovaps [rsp+0x40], xmm5
00007efc33fd70be  vmovaps [rsp+0x50], xmm6
00007efc33fd70c4  vmovaps [rsp+0x60], xmm7
00007efc33fd70ca  vmovaps [rsp+0x70], xmm8
00007efc33fd70d0  vmovaps [rsp+0x80], xmm9
00007efc33fd70d9  vmovaps [rsp+0x90], xmm10
00007efc33fd70e2  vmovaps [rsp+0xA0], xmm11
00007efc33fd70eb  vmovaps [rsp+0xB0], xmm12
00007efc33fd70f4  vmovaps [rsp+0xC0], xmm13
00007efc33fd70fd  vmovaps [rsp+0xD0], xmm14
00007efc33fd7106  vmovaps [rsp+0xE0], xmm15
00007efc33fd710f  sub rsp, 0x30
00007efc33fd7113  movaps [rsp], xmm4
00007efc33fd7117  movaps [rsp+0x10], xmm9
00007efc33fd711d  movaps [rsp+0x20], xmm8
00007efc33fd7123  lea rdi, [rsp]
00007efc33fd7127  mov esi, 0x00
00007efc33fd712c  mov rax, 0x5D9448894530
00007efc33fd7136  call rax
00007efc33fd7138  movaps xmm4, [rsp]
00007efc33fd713c  add rsp, 0x30
00007efc33fd7140  vmovaps xmm0, [rsp]
00007efc33fd7145  vmovaps xmm1, [rsp+0x10]
00007efc33fd714b  vmovaps xmm2, [rsp+0x20]
00007efc33fd7151  vmovaps xmm3, [rsp+0x30]
00007efc33fd7157  vmovaps xmm5, [rsp+0x40]
00007efc33fd715d  vmovaps xmm6, [rsp+0x50]
00007efc33fd7163  vmovaps xmm7, [rsp+0x60]
00007efc33fd7169  vmovaps xmm8, [rsp+0x70]
00007efc33fd716f  vmovaps xmm9, [rsp+0x80]
00007efc33fd7178  vmovaps xmm10, [rsp+0x90]
00007efc33fd7181  vmovaps xmm11, [rsp+0xA0]
00007efc33fd718a  vmovaps xmm12, [rsp+0xB0]
00007efc33fd7193  vmovaps xmm13, [rsp+0xC0]
00007efc33fd719c  vmovaps xmm14, [rsp+0xD0]
00007efc33fd71a5  vmovaps xmm15, [rsp+0xE0]
00007efc33fd71ae  add rsp, 0xF0
00007efc33fd71b5  pop r11
00007efc33fd71b7  pop r10
00007efc33fd71b9  pop r9
00007efc33fd71bb  pop r8
00007efc33fd71bd  pop rsi
00007efc33fd71be  pop rdi
00007efc33fd71bf  pop rdx
00007efc33fd71c0  pop rcx
00007efc33fd71c1  pop rax
00007efc33fd71c2  add rsp, 0x08
00007efc33fd71c6  jmp 0x00007EFC33FD5AE1
00007efc33fd71cb  sub rsp, 0x08
00007efc33fd71cf  push rax
00007efc33fd71d0  push rcx
00007efc33fd71d1  push rdx
00007efc33fd71d2  push rdi
00007efc33fd71d3  push rsi
00007efc33fd71d4  push r8
00007efc33fd71d6  push r9
00007efc33fd71d8  push r10
00007efc33fd71da  push r11
00007efc33fd71dc  sub rsp, 0xF0
00007efc33fd71e3  vmovaps [rsp], xmm0
00007efc33fd71e8  vmovaps [rsp+0x10], xmm1
00007efc33fd71ee  vmovaps [rsp+0x20], xmm2
00007efc33fd71f4  vmovaps [rsp+0x30], xmm3
00007efc33fd71fa  vmovaps [rsp+0x40], xmm4
00007efc33fd7200  vmovaps [rsp+0x50], xmm5
00007efc33fd7206  vmovaps [rsp+0x60], xmm6
00007efc33fd720c  vmovaps [rsp+0x70], xmm7
00007efc33fd7212  vmovaps [rsp+0x80], xmm8
00007efc33fd721b  vmovaps [rsp+0x90], xmm10
00007efc33fd7224  vmovaps [rsp+0xA0], xmm11
00007efc33fd722d  vmovaps [rsp+0xB0], xmm12
00007efc33fd7236  vmovaps [rsp+0xC0], xmm13
00007efc33fd723f  vmovaps [rsp+0xD0], xmm14
00007efc33fd7248  vmovaps [rsp+0xE0], xmm15
00007efc33fd7251  sub rsp, 0x30
00007efc33fd7255  movaps [rsp], xmm9
00007efc33fd725a  movaps [rsp+0x10], xmm10
00007efc33fd7260  movaps [rsp+0x20], xmm8
00007efc33fd7266  lea rdi, [rsp]
00007efc33fd726a  mov esi, 0x00
00007efc33fd726f  mov rax, 0x5D9448894530
00007efc33fd7279  call rax
00007efc33fd727b  movaps xmm9, [rsp]
00007efc33fd7280  add rsp, 0x30
00007efc33fd7284  vmovaps xmm0, [rsp]
00007efc33fd7289  vmovaps xmm1, [rsp+0x10]
00007efc33fd728f  vmovaps xmm2, [rsp+0x20]
00007efc33fd7295  vmovaps xmm3, [rsp+0x30]
00007efc33fd729b  vmovaps xmm4, [rsp+0x40]
00007efc33fd72a1  vmovaps xmm5, [rsp+0x50]
00007efc33fd72a7  vmovaps xmm6, [rsp+0x60]
00007efc33fd72ad  vmovaps xmm7, [rsp+0x70]
00007efc33fd72b3  vmovaps xmm8, [rsp+0x80]
00007efc33fd72bc  vmovaps xmm10, [rsp+0x90]
00007efc33fd72c5  vmovaps xmm11, [rsp+0xA0]
00007efc33fd72ce  vmovaps xmm12, [rsp+0xB0]
00007efc33fd72d7  vmovaps xmm13, [rsp+0xC0]
00007efc33fd72e0  vmovaps xmm14, [rsp+0xD0]
00007efc33fd72e9  vmovaps xmm15, [rsp+0xE0]
00007efc33fd72f2  add rsp, 0xF0
00007efc33fd72f9  pop r11
00007efc33fd72fb  pop r10
00007efc33fd72fd  pop r9
00007efc33fd72ff  pop r8
00007efc33fd7301  pop rsi
00007efc33fd7302  pop rdi
00007efc33fd7303  pop rdx
00007efc33fd7304  pop rcx
00007efc33fd7305  pop rax
00007efc33fd7306  add rsp, 0x08
00007efc33fd730a  jmp 0x00007EFC33FD5AFB
00007efc33fd730f  call 0x00007EFC33ED64F0
00007efc33fd7314  jmp 0x00007EFC33FD5C15
00007efc33fd7319  call 0x00007EFC33ED64F0
00007efc33fd731e  jmp 0x00007EFC33FD5C2B
00007efc33fd7323  sub rsp, 0x08
00007efc33fd7327  push rax
00007efc33fd7328  push rcx
00007efc33fd7329  push rdx
00007efc33fd732a  push rdi
00007efc33fd732b  push rsi
00007efc33fd732c  push r8
00007efc33fd732e  push r9
00007efc33fd7330  push r10
00007efc33fd7332  push r11
00007efc33fd7334  sub rsp, 0xF0
00007efc33fd733b  vmovaps [rsp], xmm0
00007efc33fd7340  vmovaps [rsp+0x10], xmm2
00007efc33fd7346  vmovaps [rsp+0x20], xmm3
00007efc33fd734c  vmovaps [rsp+0x30], xmm4
00007efc33fd7352  vmovaps [rsp+0x40], xmm5
00007efc33fd7358  vmovaps [rsp+0x50], xmm6
00007efc33fd735e  vmovaps [rsp+0x60], xmm7
00007efc33fd7364  vmovaps [rsp+0x70], xmm8
00007efc33fd736a  vmovaps [rsp+0x80], xmm9
00007efc33fd7373  vmovaps [rsp+0x90], xmm10
00007efc33fd737c  vmovaps [rsp+0xA0], xmm11
00007efc33fd7385  vmovaps [rsp+0xB0], xmm12
00007efc33fd738e  vmovaps [rsp+0xC0], xmm13
00007efc33fd7397  vmovaps [rsp+0xD0], xmm14
00007efc33fd73a0  vmovaps [rsp+0xE0], xmm15
00007efc33fd73a9  sub rsp, 0x30
00007efc33fd73ad  movaps [rsp], xmm1
00007efc33fd73b1  movaps [rsp+0x10], xmm6
00007efc33fd73b6  movaps [rsp+0x20], xmm15
00007efc33fd73bc  lea rdi, [rsp]
00007efc33fd73c0  mov esi, 0x00
00007efc33fd73c5  mov rax, 0x5D9448894530
00007efc33fd73cf  call rax
00007efc33fd73d1  movaps xmm1, [rsp]
00007efc33fd73d5  add rsp, 0x30
00007efc33fd73d9  vmovaps xmm0, [rsp]
00007efc33fd73de  vmovaps xmm2, [rsp+0x10]
00007efc33fd73e4  vmovaps xmm3, [rsp+0x20]
00007efc33fd73ea  vmovaps xmm4, [rsp+0x30]
00007efc33fd73f0  vmovaps xmm5, [rsp+0x40]
00007efc33fd73f6  vmovaps xmm6, [rsp+0x50]
00007efc33fd73fc  vmovaps xmm7, [rsp+0x60]
00007efc33fd7402  vmovaps xmm8, [rsp+0x70]
00007efc33fd7408  vmovaps xmm9, [rsp+0x80]
00007efc33fd7411  vmovaps xmm10, [rsp+0x90]
00007efc33fd741a  vmovaps xmm11, [rsp+0xA0]
00007efc33fd7423  vmovaps xmm12, [rsp+0xB0]
00007efc33fd742c  vmovaps xmm13, [rsp+0xC0]
00007efc33fd7435  vmovaps xmm14, [rsp+0xD0]
00007efc33fd743e  vmovaps xmm15, [rsp+0xE0]
00007efc33fd7447  add rsp, 0xF0
00007efc33fd744e  pop r11
00007efc33fd7450  pop r10
00007efc33fd7452  pop r9
00007efc33fd7454  pop r8
00007efc33fd7456  pop rsi
00007efc33fd7457  pop rdi
00007efc33fd7458  pop rdx
00007efc33fd7459  pop rcx
00007efc33fd745a  pop rax
00007efc33fd745b  add rsp, 0x08
00007efc33fd745f  jmp 0x00007EFC33FD5C68
00007efc33fd7464  call 0x00007EFC33EE5820
00007efc33fd7469  jmp 0x00007EFC33FD5C75
00007efc33fd746e  sub rsp, 0x08
00007efc33fd7472  push rax
00007efc33fd7473  push rcx
00007efc33fd7474  push rdx
00007efc33fd7475  push rdi
00007efc33fd7476  push rsi
00007efc33fd7477  push r8
00007efc33fd7479  push r9
00007efc33fd747b  push r10
00007efc33fd747d  push r11
00007efc33fd747f  sub rsp, 0xF0
00007efc33fd7486  vmovaps [rsp], xmm0
00007efc33fd748b  vmovaps [rsp+0x10], xmm1
00007efc33fd7491  vmovaps [rsp+0x20], xmm2
00007efc33fd7497  vmovaps [rsp+0x30], xmm3
00007efc33fd749d  vmovaps [rsp+0x40], xmm4
00007efc33fd74a3  vmovaps [rsp+0x50], xmm5
00007efc33fd74a9  vmovaps [rsp+0x60], xmm6
00007efc33fd74af  vmovaps [rsp+0x70], xmm7
00007efc33fd74b5  vmovaps [rsp+0x80], xmm8
00007efc33fd74be  vmovaps [rsp+0x90], xmm9
00007efc33fd74c7  vmovaps [rsp+0xA0], xmm10
00007efc33fd74d0  vmovaps [rsp+0xB0], xmm11
00007efc33fd74d9  vmovaps [rsp+0xC0], xmm12
00007efc33fd74e2  vmovaps [rsp+0xD0], xmm13
00007efc33fd74eb  vmovaps [rsp+0xE0], xmm15
00007efc33fd74f4  sub rsp, 0x30
00007efc33fd74f8  movaps [rsp], xmm14
00007efc33fd74fd  movaps [rsp+0x10], xmm4
00007efc33fd7502  movaps [rsp+0x20], xmm3
00007efc33fd7507  lea rdi, [rsp]
00007efc33fd750b  mov esi, 0x00
00007efc33fd7510  mov rax, 0x5D9448894530
00007efc33fd751a  call rax
00007efc33fd751c  movaps xmm14, [rsp]
00007efc33fd7521  add rsp, 0x30
00007efc33fd7525  vmovaps xmm0, [rsp]
00007efc33fd752a  vmovaps xmm1, [rsp+0x10]
00007efc33fd7530  vmovaps xmm2, [rsp+0x20]
00007efc33fd7536  vmovaps xmm3, [rsp+0x30]
00007efc33fd753c  vmovaps xmm4, [rsp+0x40]
00007efc33fd7542  vmovaps xmm5, [rsp+0x50]
00007efc33fd7548  vmovaps xmm6, [rsp+0x60]
00007efc33fd754e  vmovaps xmm7, [rsp+0x70]
00007efc33fd7554  vmovaps xmm8, [rsp+0x80]
00007efc33fd755d  vmovaps xmm9, [rsp+0x90]
00007efc33fd7566  vmovaps xmm10, [rsp+0xA0]
00007efc33fd756f  vmovaps xmm11, [rsp+0xB0]
00007efc33fd7578  vmovaps xmm12, [rsp+0xC0]
00007efc33fd7581  vmovaps xmm13, [rsp+0xD0]
00007efc33fd758a  vmovaps xmm15, [rsp+0xE0]
00007efc33fd7593  add rsp, 0xF0
00007efc33fd759a  pop r11
00007efc33fd759c  pop r10
00007efc33fd759e  pop r9
00007efc33fd75a0  pop r8
00007efc33fd75a2  pop rsi
00007efc33fd75a3  pop rdi
00007efc33fd75a4  pop rdx
00007efc33fd75a5  pop rcx
00007efc33fd75a6  pop rax
00007efc33fd75a7  add rsp, 0x08
00007efc33fd75ab  jmp 0x00007EFC33FD5C8F
00007efc33fd75b0  sub rsp, 0x08
00007efc33fd75b4  push rax
00007efc33fd75b5  push rcx
00007efc33fd75b6  push rdx
00007efc33fd75b7  push rdi
00007efc33fd75b8  push rsi
00007efc33fd75b9  push r8
00007efc33fd75bb  push r9
00007efc33fd75bd  push r10
00007efc33fd75bf  push r11
00007efc33fd75c1  sub rsp, 0xF0
00007efc33fd75c8  vmovaps [rsp], xmm0
00007efc33fd75cd  vmovaps [rsp+0x10], xmm1
00007efc33fd75d3  vmovaps [rsp+0x20], xmm2
00007efc33fd75d9  vmovaps [rsp+0x30], xmm3
00007efc33fd75df  vmovaps [rsp+0x40], xmm4
00007efc33fd75e5  vmovaps [rsp+0x50], xmm5
00007efc33fd75eb  vmovaps [rsp+0x60], xmm7
00007efc33fd75f1  vmovaps [rsp+0x70], xmm8
00007efc33fd75f7  vmovaps [rsp+0x80], xmm9
00007efc33fd7600  vmovaps [rsp+0x90], xmm10
00007efc33fd7609  vmovaps [rsp+0xA0], xmm11
00007efc33fd7612  vmovaps [rsp+0xB0], xmm12
00007efc33fd761b  vmovaps [rsp+0xC0], xmm13
00007efc33fd7624  vmovaps [rsp+0xD0], xmm14
00007efc33fd762d  vmovaps [rsp+0xE0], xmm15
00007efc33fd7636  sub rsp, 0x30
00007efc33fd763a  movaps [rsp], xmm6
00007efc33fd763e  movaps [rsp+0x10], xmm9
00007efc33fd7644  movaps [rsp+0x20], xmm7
00007efc33fd7649  lea rdi, [rsp]
00007efc33fd764d  mov esi, 0x00
00007efc33fd7652  mov rax, 0x5D9448894530
00007efc33fd765c  call rax
00007efc33fd765e  movaps xmm6, [rsp]
00007efc33fd7662  add rsp, 0x30
00007efc33fd7666  vmovaps xmm0, [rsp]
00007efc33fd766b  vmovaps xmm1, [rsp+0x10]
00007efc33fd7671  vmovaps xmm2, [rsp+0x20]
00007efc33fd7677  vmovaps xmm3, [rsp+0x30]
00007efc33fd767d  vmovaps xmm4, [rsp+0x40]
00007efc33fd7683  vmovaps xmm5, [rsp+0x50]
00007efc33fd7689  vmovaps xmm7, [rsp+0x60]
00007efc33fd768f  vmovaps xmm8, [rsp+0x70]
00007efc33fd7695  vmovaps xmm9, [rsp+0x80]
00007efc33fd769e  vmovaps xmm10, [rsp+0x90]
00007efc33fd76a7  vmovaps xmm11, [rsp+0xA0]
00007efc33fd76b0  vmovaps xmm12, [rsp+0xB0]
00007efc33fd76b9  vmovaps xmm13, [rsp+0xC0]
00007efc33fd76c2  vmovaps xmm14, [rsp+0xD0]
00007efc33fd76cb  vmovaps xmm15, [rsp+0xE0]
00007efc33fd76d4  add rsp, 0xF0
00007efc33fd76db  pop r11
00007efc33fd76dd  pop r10
00007efc33fd76df  pop r9
00007efc33fd76e1  pop r8
00007efc33fd76e3  pop rsi
00007efc33fd76e4  pop rdi
00007efc33fd76e5  pop rdx
00007efc33fd76e6  pop rcx
00007efc33fd76e7  pop rax
00007efc33fd76e8  add rsp, 0x08
00007efc33fd76ec  jmp 0x00007EFC33FD5CA7
00007efc33fd76f1  sub rsp, 0x08
00007efc33fd76f5  push rax
00007efc33fd76f6  push rcx
00007efc33fd76f7  push rdx
00007efc33fd76f8  push rdi
00007efc33fd76f9  push rsi
00007efc33fd76fa  push r8
00007efc33fd76fc  push r9
00007efc33fd76fe  push r10
00007efc33fd7700  push r11
00007efc33fd7702  sub rsp, 0xF0
00007efc33fd7709  vmovaps [rsp], xmm0
00007efc33fd770e  vmovaps [rsp+0x10], xmm1
00007efc33fd7714  vmovaps [rsp+0x20], xmm2
00007efc33fd771a  vmovaps [rsp+0x30], xmm3
00007efc33fd7720  vmovaps [rsp+0x40], xmm4
00007efc33fd7726  vmovaps [rsp+0x50], xmm5
00007efc33fd772c  vmovaps [rsp+0x60], xmm6
00007efc33fd7732  vmovaps [rsp+0x70], xmm8
00007efc33fd7738  vmovaps [rsp+0x80], xmm9
00007efc33fd7741  vmovaps [rsp+0x90], xmm10
00007efc33fd774a  vmovaps [rsp+0xA0], xmm11
00007efc33fd7753  vmovaps [rsp+0xB0], xmm12
00007efc33fd775c  vmovaps [rsp+0xC0], xmm13
00007efc33fd7765  vmovaps [rsp+0xD0], xmm14
00007efc33fd776e  vmovaps [rsp+0xE0], xmm15
00007efc33fd7777  sub rsp, 0x30
00007efc33fd777b  movaps [rsp], xmm7
00007efc33fd777f  movaps [rsp+0x10], xmm4
00007efc33fd7784  movaps [rsp+0x20], xmm9
00007efc33fd778a  lea rdi, [rsp]
00007efc33fd778e  mov esi, 0x00
00007efc33fd7793  mov rax, 0x5D9448894530
00007efc33fd779d  call rax
00007efc33fd779f  movaps xmm7, [rsp]
00007efc33fd77a3  add rsp, 0x30
00007efc33fd77a7  vmovaps xmm0, [rsp]
00007efc33fd77ac  vmovaps xmm1, [rsp+0x10]
00007efc33fd77b2  vmovaps xmm2, [rsp+0x20]
00007efc33fd77b8  vmovaps xmm3, [rsp+0x30]
00007efc33fd77be  vmovaps xmm4, [rsp+0x40]
00007efc33fd77c4  vmovaps xmm5, [rsp+0x50]
00007efc33fd77ca  vmovaps xmm6, [rsp+0x60]
00007efc33fd77d0  vmovaps xmm8, [rsp+0x70]
00007efc33fd77d6  vmovaps xmm9, [rsp+0x80]
00007efc33fd77df  vmovaps xmm10, [rsp+0x90]
00007efc33fd77e8  vmovaps xmm11, [rsp+0xA0]
00007efc33fd77f1  vmovaps xmm12, [rsp+0xB0]
00007efc33fd77fa  vmovaps xmm13, [rsp+0xC0]
00007efc33fd7803  vmovaps xmm14, [rsp+0xD0]
00007efc33fd780c  vmovaps xmm15, [rsp+0xE0]
00007efc33fd7815  add rsp, 0xF0
00007efc33fd781c  pop r11
00007efc33fd781e  pop r10
00007efc33fd7820  pop r9
00007efc33fd7822  pop r8
00007efc33fd7824  pop rsi
00007efc33fd7825  pop rdi
00007efc33fd7826  pop rdx
00007efc33fd7827  pop rcx
00007efc33fd7828  pop rax
00007efc33fd7829  add rsp, 0x08
00007efc33fd782d  jmp 0x00007EFC33FD5CD4
00007efc33fd7832  sub rsp, 0x08
00007efc33fd7836  push rax
00007efc33fd7837  push rcx
00007efc33fd7838  push rdx
00007efc33fd7839  push rdi
00007efc33fd783a  push rsi
00007efc33fd783b  push r8
00007efc33fd783d  push r9
00007efc33fd783f  push r10
00007efc33fd7841  push r11
00007efc33fd7843  sub rsp, 0xF0
00007efc33fd784a  vmovaps [rsp], xmm0
00007efc33fd784f  vmovaps [rsp+0x10], xmm1
00007efc33fd7855  vmovaps [rsp+0x20], xmm2
00007efc33fd785b  vmovaps [rsp+0x30], xmm3
00007efc33fd7861  vmovaps [rsp+0x40], xmm5
00007efc33fd7867  vmovaps [rsp+0x50], xmm6
00007efc33fd786d  vmovaps [rsp+0x60], xmm7
00007efc33fd7873  vmovaps [rsp+0x70], xmm8
00007efc33fd7879  vmovaps [rsp+0x80], xmm9
00007efc33fd7882  vmovaps [rsp+0x90], xmm10
00007efc33fd788b  vmovaps [rsp+0xA0], xmm11
00007efc33fd7894  vmovaps [rsp+0xB0], xmm12
00007efc33fd789d  vmovaps [rsp+0xC0], xmm13
00007efc33fd78a6  vmovaps [rsp+0xD0], xmm14
00007efc33fd78af  vmovaps [rsp+0xE0], xmm15
00007efc33fd78b8  sub rsp, 0x30
00007efc33fd78bc  movaps [rsp], xmm4
00007efc33fd78c0  movaps [rsp+0x10], xmm15
00007efc33fd78c6  movaps [rsp+0x20], xmm9
00007efc33fd78cc  lea rdi, [rsp]
00007efc33fd78d0  mov esi, 0x00
00007efc33fd78d5  mov rax, 0x5D9448894530
00007efc33fd78df  call rax
00007efc33fd78e1  movaps xmm4, [rsp]
00007efc33fd78e5  add rsp, 0x30
00007efc33fd78e9  vmovaps xmm0, [rsp]
00007efc33fd78ee  vmovaps xmm1, [rsp+0x10]
00007efc33fd78f4  vmovaps xmm2, [rsp+0x20]
00007efc33fd78fa  vmovaps xmm3, [rsp+0x30]
00007efc33fd7900  vmovaps xmm5, [rsp+0x40]
00007efc33fd7906  vmovaps xmm6, [rsp+0x50]
00007efc33fd790c  vmovaps xmm7, [rsp+0x60]
00007efc33fd7912  vmovaps xmm8, [rsp+0x70]
00007efc33fd7918  vmovaps xmm9, [rsp+0x80]
00007efc33fd7921  vmovaps xmm10, [rsp+0x90]
00007efc33fd792a  vmovaps xmm11, [rsp+0xA0]
00007efc33fd7933  vmovaps xmm12, [rsp+0xB0]
00007efc33fd793c  vmovaps xmm13, [rsp+0xC0]
00007efc33fd7945  vmovaps xmm14, [rsp+0xD0]
00007efc33fd794e  vmovaps xmm15, [rsp+0xE0]
00007efc33fd7957  add rsp, 0xF0
00007efc33fd795e  pop r11
00007efc33fd7960  pop r10
00007efc33fd7962  pop r9
00007efc33fd7964  pop r8
00007efc33fd7966  pop rsi
00007efc33fd7967  pop rdi
00007efc33fd7968  pop rdx
00007efc33fd7969  pop rcx
00007efc33fd796a  pop rax
00007efc33fd796b  add rsp, 0x08
00007efc33fd796f  jmp 0x00007EFC33FD5CF9
00007efc33fd7974  call 0x00007EFC33EE5820
00007efc33fd7979  jmp 0x00007EFC33FD5D06
00007efc33fd797e  sub rsp, 0x08
00007efc33fd7982  push rax
00007efc33fd7983  push rcx
00007efc33fd7984  push rdx
00007efc33fd7985  push rdi
00007efc33fd7986  push rsi
00007efc33fd7987  push r8
00007efc33fd7989  push r9
00007efc33fd798b  push r10
00007efc33fd798d  push r11
00007efc33fd798f  sub rsp, 0xF0
00007efc33fd7996  vmovaps [rsp], xmm0
00007efc33fd799b  vmovaps [rsp+0x10], xmm1
00007efc33fd79a1  vmovaps [rsp+0x20], xmm2
00007efc33fd79a7  vmovaps [rsp+0x30], xmm4
00007efc33fd79ad  vmovaps [rsp+0x40], xmm5
00007efc33fd79b3  vmovaps [rsp+0x50], xmm6
00007efc33fd79b9  vmovaps [rsp+0x60], xmm7
00007efc33fd79bf  vmovaps [rsp+0x70], xmm8
00007efc33fd79c5  vmovaps [rsp+0x80], xmm9
00007efc33fd79ce  vmovaps [rsp+0x90], xmm10
00007efc33fd79d7  vmovaps [rsp+0xA0], xmm11
00007efc33fd79e0  vmovaps [rsp+0xB0], xmm12
00007efc33fd79e9  vmovaps [rsp+0xC0], xmm13
00007efc33fd79f2  vmovaps [rsp+0xD0], xmm14
00007efc33fd79fb  vmovaps [rsp+0xE0], xmm15
00007efc33fd7a04  sub rsp, 0x30
00007efc33fd7a08  movaps [rsp], xmm3
00007efc33fd7a0c  movaps [rsp+0x10], xmm1
00007efc33fd7a11  movaps [rsp+0x20], xmm9
00007efc33fd7a17  lea rdi, [rsp]
00007efc33fd7a1b  mov esi, 0x00
00007efc33fd7a20  mov rax, 0x5D9448894530
00007efc33fd7a2a  call rax
00007efc33fd7a2c  movaps xmm3, [rsp]
00007efc33fd7a30  add rsp, 0x30
00007efc33fd7a34  vmovaps xmm0, [rsp]
00007efc33fd7a39  vmovaps xmm1, [rsp+0x10]
00007efc33fd7a3f  vmovaps xmm2, [rsp+0x20]
00007efc33fd7a45  vmovaps xmm4, [rsp+0x30]
00007efc33fd7a4b  vmovaps xmm5, [rsp+0x40]
00007efc33fd7a51  vmovaps xmm6, [rsp+0x50]
00007efc33fd7a57  vmovaps xmm7, [rsp+0x60]
00007efc33fd7a5d  vmovaps xmm8, [rsp+0x70]
00007efc33fd7a63  vmovaps xmm9, [rsp+0x80]
00007efc33fd7a6c  vmovaps xmm10, [rsp+0x90]
00007efc33fd7a75  vmovaps xmm11, [rsp+0xA0]
00007efc33fd7a7e  vmovaps xmm12, [rsp+0xB0]
00007efc33fd7a87  vmovaps xmm13, [rsp+0xC0]
00007efc33fd7a90  vmovaps xmm14, [rsp+0xD0]
00007efc33fd7a99  vmovaps xmm15, [rsp+0xE0]
00007efc33fd7aa2  add rsp, 0xF0
00007efc33fd7aa9  pop r11
00007efc33fd7aab  pop r10
00007efc33fd7aad  pop r9
00007efc33fd7aaf  pop r8
00007efc33fd7ab1  pop rsi
00007efc33fd7ab2  pop rdi
00007efc33fd7ab3  pop rdx
00007efc33fd7ab4  pop rcx
00007efc33fd7ab5  pop rax
00007efc33fd7ab6  add rsp, 0x08
00007efc33fd7aba  jmp 0x00007EFC33FD5D43
00007efc33fd7abf  sub rsp, 0x08
00007efc33fd7ac3  push rax
00007efc33fd7ac4  push rcx
00007efc33fd7ac5  push rdx
00007efc33fd7ac6  push rdi
00007efc33fd7ac7  push rsi
00007efc33fd7ac8  push r8
00007efc33fd7aca  push r9
00007efc33fd7acc  push r10
00007efc33fd7ace  push r11
00007efc33fd7ad0  sub rsp, 0xF0
00007efc33fd7ad7  vmovaps [rsp], xmm0
00007efc33fd7adc  vmovaps [rsp+0x10], xmm2
00007efc33fd7ae2  vmovaps [rsp+0x20], xmm3
00007efc33fd7ae8  vmovaps [rsp+0x30], xmm4
00007efc33fd7aee  vmovaps [rsp+0x40], xmm5
00007efc33fd7af4  vmovaps [rsp+0x50], xmm6
00007efc33fd7afa  vmovaps [rsp+0x60], xmm7
00007efc33fd7b00  vmovaps [rsp+0x70], xmm8
00007efc33fd7b06  vmovaps [rsp+0x80], xmm9
00007efc33fd7b0f  vmovaps [rsp+0x90], xmm10
00007efc33fd7b18  vmovaps [rsp+0xA0], xmm11
00007efc33fd7b21  vmovaps [rsp+0xB0], xmm12
00007efc33fd7b2a  vmovaps [rsp+0xC0], xmm13
00007efc33fd7b33  vmovaps [rsp+0xD0], xmm14
00007efc33fd7b3c  vmovaps [rsp+0xE0], xmm15
00007efc33fd7b45  sub rsp, 0x30
00007efc33fd7b49  movaps [rsp], xmm1
00007efc33fd7b4d  movaps [rsp+0x10], xmm15
00007efc33fd7b53  movaps [rsp+0x20], xmm9
00007efc33fd7b59  lea rdi, [rsp]
00007efc33fd7b5d  mov esi, 0x00
00007efc33fd7b62  mov rax, 0x5D9448894530
00007efc33fd7b6c  call rax
00007efc33fd7b6e  movaps xmm1, [rsp]
00007efc33fd7b72  add rsp, 0x30
00007efc33fd7b76  vmovaps xmm0, [rsp]
00007efc33fd7b7b  vmovaps xmm2, [rsp+0x10]
00007efc33fd7b81  vmovaps xmm3, [rsp+0x20]
00007efc33fd7b87  vmovaps xmm4, [rsp+0x30]
00007efc33fd7b8d  vmovaps xmm5, [rsp+0x40]
00007efc33fd7b93  vmovaps xmm6, [rsp+0x50]
00007efc33fd7b99  vmovaps xmm7, [rsp+0x60]
00007efc33fd7b9f  vmovaps xmm8, [rsp+0x70]
00007efc33fd7ba5  vmovaps xmm9, [rsp+0x80]
00007efc33fd7bae  vmovaps xmm10, [rsp+0x90]
00007efc33fd7bb7  vmovaps xmm11, [rsp+0xA0]
00007efc33fd7bc0  vmovaps xmm12, [rsp+0xB0]
00007efc33fd7bc9  vmovaps xmm13, [rsp+0xC0]
00007efc33fd7bd2  vmovaps xmm14, [rsp+0xD0]
00007efc33fd7bdb  vmovaps xmm15, [rsp+0xE0]
00007efc33fd7be4  add rsp, 0xF0
00007efc33fd7beb  pop r11
00007efc33fd7bed  pop r10
00007efc33fd7bef  pop r9
00007efc33fd7bf1  pop r8
00007efc33fd7bf3  pop rsi
00007efc33fd7bf4  pop rdi
00007efc33fd7bf5  pop rdx
00007efc33fd7bf6  pop rcx
00007efc33fd7bf7  pop rax
00007efc33fd7bf8  add rsp, 0x08
00007efc33fd7bfc  jmp 0x00007EFC33FD5DCB
00007efc33fd7c01  call 0x00007EFC33EE5820
00007efc33fd7c06  jmp 0x00007EFC33FD5DD8
00007efc33fd7c0b  sub rsp, 0x08
00007efc33fd7c0f  push rax
00007efc33fd7c10  push rcx
00007efc33fd7c11  push rdx
00007efc33fd7c12  push rdi
00007efc33fd7c13  push rsi
00007efc33fd7c14  push r8
00007efc33fd7c16  push r9
00007efc33fd7c18  push r10
00007efc33fd7c1a  push r11
00007efc33fd7c1c  sub rsp, 0xF0
00007efc33fd7c23  vmovaps [rsp], xmm0
00007efc33fd7c28  vmovaps [rsp+0x10], xmm2
00007efc33fd7c2e  vmovaps [rsp+0x20], xmm3
00007efc33fd7c34  vmovaps [rsp+0x30], xmm4
00007efc33fd7c3a  vmovaps [rsp+0x40], xmm5
00007efc33fd7c40  vmovaps [rsp+0x50], xmm6
00007efc33fd7c46  vmovaps [rsp+0x60], xmm7
00007efc33fd7c4c  vmovaps [rsp+0x70], xmm8
00007efc33fd7c52  vmovaps [rsp+0x80], xmm9
00007efc33fd7c5b  vmovaps [rsp+0x90], xmm10
00007efc33fd7c64  vmovaps [rsp+0xA0], xmm11
00007efc33fd7c6d  vmovaps [rsp+0xB0], xmm12
00007efc33fd7c76  vmovaps [rsp+0xC0], xmm13
00007efc33fd7c7f  vmovaps [rsp+0xD0], xmm14
00007efc33fd7c88  vmovaps [rsp+0xE0], xmm15
00007efc33fd7c91  sub rsp, 0x30
00007efc33fd7c95  movaps [rsp], xmm1
00007efc33fd7c99  movaps [rsp+0x10], xmm5
00007efc33fd7c9e  movaps [rsp+0x20], xmm7
00007efc33fd7ca3  lea rdi, [rsp]
00007efc33fd7ca7  mov esi, 0x00
00007efc33fd7cac  mov rax, 0x5D9448894530
00007efc33fd7cb6  call rax
00007efc33fd7cb8  movaps xmm1, [rsp]
00007efc33fd7cbc  add rsp, 0x30
00007efc33fd7cc0  vmovaps xmm0, [rsp]
00007efc33fd7cc5  vmovaps xmm2, [rsp+0x10]
00007efc33fd7ccb  vmovaps xmm3, [rsp+0x20]
00007efc33fd7cd1  vmovaps xmm4, [rsp+0x30]
00007efc33fd7cd7  vmovaps xmm5, [rsp+0x40]
00007efc33fd7cdd  vmovaps xmm6, [rsp+0x50]
00007efc33fd7ce3  vmovaps xmm7, [rsp+0x60]
00007efc33fd7ce9  vmovaps xmm8, [rsp+0x70]
00007efc33fd7cef  vmovaps xmm9, [rsp+0x80]
00007efc33fd7cf8  vmovaps xmm10, [rsp+0x90]
00007efc33fd7d01  vmovaps xmm11, [rsp+0xA0]
00007efc33fd7d0a  vmovaps xmm12, [rsp+0xB0]
00007efc33fd7d13  vmovaps xmm13, [rsp+0xC0]
00007efc33fd7d1c  vmovaps xmm14, [rsp+0xD0]
00007efc33fd7d25  vmovaps xmm15, [rsp+0xE0]
00007efc33fd7d2e  add rsp, 0xF0
00007efc33fd7d35  pop r11
00007efc33fd7d37  pop r10
00007efc33fd7d39  pop r9
00007efc33fd7d3b  pop r8
00007efc33fd7d3d  pop rsi
00007efc33fd7d3e  pop rdi
00007efc33fd7d3f  pop rdx
00007efc33fd7d40  pop rcx
00007efc33fd7d41  pop rax
00007efc33fd7d42  add rsp, 0x08
00007efc33fd7d46  jmp 0x00007EFC33FD5E7D
00007efc33fd7d4b  sub rsp, 0x08
00007efc33fd7d4f  push rax
00007efc33fd7d50  push rcx
00007efc33fd7d51  push rdx
00007efc33fd7d52  push rdi
00007efc33fd7d53  push rsi
00007efc33fd7d54  push r8
00007efc33fd7d56  push r9
00007efc33fd7d58  push r10
00007efc33fd7d5a  push r11
00007efc33fd7d5c  sub rsp, 0xF0
00007efc33fd7d63  vmovaps [rsp], xmm0
00007efc33fd7d68  vmovaps [rsp+0x10], xmm1
00007efc33fd7d6e  vmovaps [rsp+0x20], xmm2
00007efc33fd7d74  vmovaps [rsp+0x30], xmm3
00007efc33fd7d7a  vmovaps [rsp+0x40], xmm4
00007efc33fd7d80  vmovaps [rsp+0x50], xmm5
00007efc33fd7d86  vmovaps [rsp+0x60], xmm6
00007efc33fd7d8c  vmovaps [rsp+0x70], xmm8
00007efc33fd7d92  vmovaps [rsp+0x80], xmm9
00007efc33fd7d9b  vmovaps [rsp+0x90], xmm10
00007efc33fd7da4  vmovaps [rsp+0xA0], xmm11
00007efc33fd7dad  vmovaps [rsp+0xB0], xmm12
00007efc33fd7db6  vmovaps [rsp+0xC0], xmm13
00007efc33fd7dbf  vmovaps [rsp+0xD0], xmm14
00007efc33fd7dc8  vmovaps [rsp+0xE0], xmm15
00007efc33fd7dd1  sub rsp, 0x30
00007efc33fd7dd5  movaps [rsp], xmm7
00007efc33fd7dd9  movaps [rsp+0x10], xmm5
00007efc33fd7dde  movaps [rsp+0x20], xmm15
00007efc33fd7de4  lea rdi, [rsp]
00007efc33fd7de8  mov esi, 0x00
00007efc33fd7ded  mov rax, 0x5D9448894530
00007efc33fd7df7  call rax
00007efc33fd7df9  movaps xmm7, [rsp]
00007efc33fd7dfd  add rsp, 0x30
00007efc33fd7e01  vmovaps xmm0, [rsp]
00007efc33fd7e06  vmovaps xmm1, [rsp+0x10]
00007efc33fd7e0c  vmovaps xmm2, [rsp+0x20]
00007efc33fd7e12  vmovaps xmm3, [rsp+0x30]
00007efc33fd7e18  vmovaps xmm4, [rsp+0x40]
00007efc33fd7e1e  vmovaps xmm5, [rsp+0x50]
00007efc33fd7e24  vmovaps xmm6, [rsp+0x60]
00007efc33fd7e2a  vmovaps xmm8, [rsp+0x70]
00007efc33fd7e30  vmovaps xmm9, [rsp+0x80]
00007efc33fd7e39  vmovaps xmm10, [rsp+0x90]
00007efc33fd7e42  vmovaps xmm11, [rsp+0xA0]
00007efc33fd7e4b  vmovaps xmm12, [rsp+0xB0]
00007efc33fd7e54  vmovaps xmm13, [rsp+0xC0]
00007efc33fd7e5d  vmovaps xmm14, [rsp+0xD0]
00007efc33fd7e66  vmovaps xmm15, [rsp+0xE0]
00007efc33fd7e6f  add rsp, 0xF0
00007efc33fd7e76  pop r11
00007efc33fd7e78  pop r10
00007efc33fd7e7a  pop r9
00007efc33fd7e7c  pop r8
00007efc33fd7e7e  pop rsi
00007efc33fd7e7f  pop rdi
00007efc33fd7e80  pop rdx
00007efc33fd7e81  pop rcx
00007efc33fd7e82  pop rax
00007efc33fd7e83  add rsp, 0x08
00007efc33fd7e87  jmp 0x00007EFC33FD5EB3
00007efc33fd7e8c  call 0x00007EFC33ED64F0
00007efc33fd7e91  jmp 0x00007EFC33FD5EC0
00007efc33fd7e96  sub rsp, 0x08
00007efc33fd7e9a  push rax
00007efc33fd7e9b  push rcx
00007efc33fd7e9c  push rdx
00007efc33fd7e9d  push rdi
00007efc33fd7e9e  push rsi
00007efc33fd7e9f  push r8
00007efc33fd7ea1  push r9
00007efc33fd7ea3  push r10
00007efc33fd7ea5  push r11
00007efc33fd7ea7  sub rsp, 0xF0
00007efc33fd7eae  vmovaps [rsp], xmm0
00007efc33fd7eb3  vmovaps [rsp+0x10], xmm1
00007efc33fd7eb9  vmovaps [rsp+0x20], xmm2
00007efc33fd7ebf  vmovaps [rsp+0x30], xmm3
00007efc33fd7ec5  vmovaps [rsp+0x40], xmm4
00007efc33fd7ecb  vmovaps [rsp+0x50], xmm5
00007efc33fd7ed1  vmovaps [rsp+0x60], xmm6
00007efc33fd7ed7  vmovaps [rsp+0x70], xmm7
00007efc33fd7edd  vmovaps [rsp+0x80], xmm8
00007efc33fd7ee6  vmovaps [rsp+0x90], xmm9
00007efc33fd7eef  vmovaps [rsp+0xA0], xmm10
00007efc33fd7ef8  vmovaps [rsp+0xB0], xmm11
00007efc33fd7f01  vmovaps [rsp+0xC0], xmm12
00007efc33fd7f0a  vmovaps [rsp+0xD0], xmm13
00007efc33fd7f13  vmovaps [rsp+0xE0], xmm14
00007efc33fd7f1c  sub rsp, 0x30
00007efc33fd7f20  movaps [rsp], xmm15
00007efc33fd7f25  movaps [rsp+0x10], xmm5
00007efc33fd7f2a  movaps [rsp+0x20], xmm3
00007efc33fd7f2f  lea rdi, [rsp]
00007efc33fd7f33  mov esi, 0x00
00007efc33fd7f38  mov rax, 0x5D9448894530
00007efc33fd7f42  call rax
00007efc33fd7f44  movaps xmm15, [rsp]
00007efc33fd7f49  add rsp, 0x30
00007efc33fd7f4d  vmovaps xmm0, [rsp]
00007efc33fd7f52  vmovaps xmm1, [rsp+0x10]
00007efc33fd7f58  vmovaps xmm2, [rsp+0x20]
00007efc33fd7f5e  vmovaps xmm3, [rsp+0x30]
00007efc33fd7f64  vmovaps xmm4, [rsp+0x40]
00007efc33fd7f6a  vmovaps xmm5, [rsp+0x50]
00007efc33fd7f70  vmovaps xmm6, [rsp+0x60]
00007efc33fd7f76  vmovaps xmm7, [rsp+0x70]
00007efc33fd7f7c  vmovaps xmm8, [rsp+0x80]
00007efc33fd7f85  vmovaps xmm9, [rsp+0x90]
00007efc33fd7f8e  vmovaps xmm10, [rsp+0xA0]
00007efc33fd7f97  vmovaps xmm11, [rsp+0xB0]
00007efc33fd7fa0  vmovaps xmm12, [rsp+0xC0]
00007efc33fd7fa9  vmovaps xmm13, [rsp+0xD0]
00007efc33fd7fb2  vmovaps xmm14, [rsp+0xE0]
00007efc33fd7fbb  add rsp, 0xF0
00007efc33fd7fc2  pop r11
00007efc33fd7fc4  pop r10
00007efc33fd7fc6  pop r9
00007efc33fd7fc8  pop r8
00007efc33fd7fca  pop rsi
00007efc33fd7fcb  pop rdi
00007efc33fd7fcc  pop rdx
00007efc33fd7fcd  pop rcx
00007efc33fd7fce  pop rax
00007efc33fd7fcf  add rsp, 0x08
00007efc33fd7fd3  jmp 0x00007EFC33FD5EE6
00007efc33fd7fd8  sub rsp, 0x08
00007efc33fd7fdc  push rax
00007efc33fd7fdd  push rcx
00007efc33fd7fde  push rdx
00007efc33fd7fdf  push rdi
00007efc33fd7fe0  push rsi
00007efc33fd7fe1  push r8
00007efc33fd7fe3  push r9
00007efc33fd7fe5  push r10
00007efc33fd7fe7  push r11
00007efc33fd7fe9  sub rsp, 0xF0
00007efc33fd7ff0  vmovaps [rsp], xmm0
00007efc33fd7ff5  vmovaps [rsp+0x10], xmm2
00007efc33fd7ffb  vmovaps [rsp+0x20], xmm3
00007efc33fd8001  vmovaps [rsp+0x30], xmm4
00007efc33fd8007  vmovaps [rsp+0x40], xmm5
00007efc33fd800d  vmovaps [rsp+0x50], xmm6
00007efc33fd8013  vmovaps [rsp+0x60], xmm7
00007efc33fd8019  vmovaps [rsp+0x70], xmm8
00007efc33fd801f  vmovaps [rsp+0x80], xmm9
00007efc33fd8028  vmovaps [rsp+0x90], xmm10
00007efc33fd8031  vmovaps [rsp+0xA0], xmm11
00007efc33fd803a  vmovaps [rsp+0xB0], xmm12
00007efc33fd8043  vmovaps [rsp+0xC0], xmm13
00007efc33fd804c  vmovaps [rsp+0xD0], xmm14
00007efc33fd8055  vmovaps [rsp+0xE0], xmm15
00007efc33fd805e  sub rsp, 0x30
00007efc33fd8062  movaps [rsp], xmm1
00007efc33fd8066  movaps [rsp+0x10], xmm5
00007efc33fd806b  movaps [rsp+0x20], xmm4
00007efc33fd8070  lea rdi, [rsp]
00007efc33fd8074  mov esi, 0x00
00007efc33fd8079  mov rax, 0x5D9448894530
00007efc33fd8083  call rax
00007efc33fd8085  movaps xmm1, [rsp]
00007efc33fd8089  add rsp, 0x30
00007efc33fd808d  vmovaps xmm0, [rsp]
00007efc33fd8092  vmovaps xmm2, [rsp+0x10]
00007efc33fd8098  vmovaps xmm3, [rsp+0x20]
00007efc33fd809e  vmovaps xmm4, [rsp+0x30]
00007efc33fd80a4  vmovaps xmm5, [rsp+0x40]
00007efc33fd80aa  vmovaps xmm6, [rsp+0x50]
00007efc33fd80b0  vmovaps xmm7, [rsp+0x60]
00007efc33fd80b6  vmovaps xmm8, [rsp+0x70]
00007efc33fd80bc  vmovaps xmm9, [rsp+0x80]
00007efc33fd80c5  vmovaps xmm10, [rsp+0x90]
00007efc33fd80ce  vmovaps xmm11, [rsp+0xA0]
00007efc33fd80d7  vmovaps xmm12, [rsp+0xB0]
00007efc33fd80e0  vmovaps xmm13, [rsp+0xC0]
00007efc33fd80e9  vmovaps xmm14, [rsp+0xD0]
00007efc33fd80f2  vmovaps xmm15, [rsp+0xE0]
00007efc33fd80fb  add rsp, 0xF0
00007efc33fd8102  pop r11
00007efc33fd8104  pop r10
00007efc33fd8106  pop r9
00007efc33fd8108  pop r8
00007efc33fd810a  pop rsi
00007efc33fd810b  pop rdi
00007efc33fd810c  pop rdx
00007efc33fd810d  pop rcx
00007efc33fd810e  pop rax
00007efc33fd810f  add rsp, 0x08
00007efc33fd8113  jmp 0x00007EFC33FD5F06
00007efc33fd8118  sub rsp, 0x08
00007efc33fd811c  push rax
00007efc33fd811d  push rcx
00007efc33fd811e  push rdx
00007efc33fd811f  push rdi
00007efc33fd8120  push rsi
00007efc33fd8121  push r8
00007efc33fd8123  push r9
00007efc33fd8125  push r10
00007efc33fd8127  push r11
00007efc33fd8129  sub rsp, 0xF0
00007efc33fd8130  vmovaps [rsp], xmm0
00007efc33fd8135  vmovaps [rsp+0x10], xmm1
00007efc33fd813b  vmovaps [rsp+0x20], xmm2
00007efc33fd8141  vmovaps [rsp+0x30], xmm3
00007efc33fd8147  vmovaps [rsp+0x40], xmm5
00007efc33fd814d  vmovaps [rsp+0x50], xmm6
00007efc33fd8153  vmovaps [rsp+0x60], xmm7
00007efc33fd8159  vmovaps [rsp+0x70], xmm8
00007efc33fd815f  vmovaps [rsp+0x80], xmm9
00007efc33fd8168  vmovaps [rsp+0x90], xmm10
00007efc33fd8171  vmovaps [rsp+0xA0], xmm11
00007efc33fd817a  vmovaps [rsp+0xB0], xmm12
00007efc33fd8183  vmovaps [rsp+0xC0], xmm13
00007efc33fd818c  vmovaps [rsp+0xD0], xmm14
00007efc33fd8195  vmovaps [rsp+0xE0], xmm15
00007efc33fd819e  sub rsp, 0x30
00007efc33fd81a2  movaps [rsp], xmm4
00007efc33fd81a6  movaps [rsp+0x10], xmm3
00007efc33fd81ab  movaps [rsp+0x20], xmm5
00007efc33fd81b0  lea rdi, [rsp]
00007efc33fd81b4  mov esi, 0x00
00007efc33fd81b9  mov rax, 0x5D9448894530
00007efc33fd81c3  call rax
00007efc33fd81c5  movaps xmm4, [rsp]
00007efc33fd81c9  add rsp, 0x30
00007efc33fd81cd  vmovaps xmm0, [rsp]
00007efc33fd81d2  vmovaps xmm1, [rsp+0x10]
00007efc33fd81d8  vmovaps xmm2, [rsp+0x20]
00007efc33fd81de  vmovaps xmm3, [rsp+0x30]
00007efc33fd81e4  vmovaps xmm5, [rsp+0x40]
00007efc33fd81ea  vmovaps xmm6, [rsp+0x50]
00007efc33fd81f0  vmovaps xmm7, [rsp+0x60]
00007efc33fd81f6  vmovaps xmm8, [rsp+0x70]
00007efc33fd81fc  vmovaps xmm9, [rsp+0x80]
00007efc33fd8205  vmovaps xmm10, [rsp+0x90]
00007efc33fd820e  vmovaps xmm11, [rsp+0xA0]
00007efc33fd8217  vmovaps xmm12, [rsp+0xB0]
00007efc33fd8220  vmovaps xmm13, [rsp+0xC0]
00007efc33fd8229  vmovaps xmm14, [rsp+0xD0]
00007efc33fd8232  vmovaps xmm15, [rsp+0xE0]
00007efc33fd823b  add rsp, 0xF0
00007efc33fd8242  pop r11
00007efc33fd8244  pop r10
00007efc33fd8246  pop r9
00007efc33fd8248  pop r8
00007efc33fd824a  pop rsi
00007efc33fd824b  pop rdi
00007efc33fd824c  pop rdx
00007efc33fd824d  pop rcx
00007efc33fd824e  pop rax
00007efc33fd824f  add rsp, 0x08
00007efc33fd8253  jmp 0x00007EFC33FD5F54
00007efc33fd8258  call 0x00007EFC33ED64F0
00007efc33fd825d  jmp 0x00007EFC33FD5F61
00007efc33fd8262  sub rsp, 0x08
00007efc33fd8266  push rax
00007efc33fd8267  push rcx
00007efc33fd8268  push rdx
00007efc33fd8269  push rdi
00007efc33fd826a  push rsi
00007efc33fd826b  push r8
00007efc33fd826d  push r9
00007efc33fd826f  push r10
00007efc33fd8271  push r11
00007efc33fd8273  sub rsp, 0xF0
00007efc33fd827a  vmovaps [rsp], xmm0
00007efc33fd827f  vmovaps [rsp+0x10], xmm1
00007efc33fd8285  vmovaps [rsp+0x20], xmm2
00007efc33fd828b  vmovaps [rsp+0x30], xmm3
00007efc33fd8291  vmovaps [rsp+0x40], xmm4
00007efc33fd8297  vmovaps [rsp+0x50], xmm6
00007efc33fd829d  vmovaps [rsp+0x60], xmm7
00007efc33fd82a3  vmovaps [rsp+0x70], xmm8
00007efc33fd82a9  vmovaps [rsp+0x80], xmm9
00007efc33fd82b2  vmovaps [rsp+0x90], xmm10
00007efc33fd82bb  vmovaps [rsp+0xA0], xmm11
00007efc33fd82c4  vmovaps [rsp+0xB0], xmm12
00007efc33fd82cd  vmovaps [rsp+0xC0], xmm13
00007efc33fd82d6  vmovaps [rsp+0xD0], xmm14
00007efc33fd82df  vmovaps [rsp+0xE0], xmm15
00007efc33fd82e8  sub rsp, 0x30
00007efc33fd82ec  movaps [rsp], xmm5
00007efc33fd82f0  movaps [rsp+0x10], xmm6
00007efc33fd82f5  movaps [rsp+0x20], xmm3
00007efc33fd82fa  lea rdi, [rsp]
00007efc33fd82fe  mov esi, 0x00
00007efc33fd8303  mov rax, 0x5D9448894530
00007efc33fd830d  call rax
00007efc33fd830f  movaps xmm5, [rsp]
00007efc33fd8313  add rsp, 0x30
00007efc33fd8317  vmovaps xmm0, [rsp]
00007efc33fd831c  vmovaps xmm1, [rsp+0x10]
00007efc33fd8322  vmovaps xmm2, [rsp+0x20]
00007efc33fd8328  vmovaps xmm3, [rsp+0x30]
00007efc33fd832e  vmovaps xmm4, [rsp+0x40]
00007efc33fd8334  vmovaps xmm6, [rsp+0x50]
00007efc33fd833a  vmovaps xmm7, [rsp+0x60]
00007efc33fd8340  vmovaps xmm8, [rsp+0x70]
00007efc33fd8346  vmovaps xmm9, [rsp+0x80]
00007efc33fd834f  vmovaps xmm10, [rsp+0x90]
00007efc33fd8358  vmovaps xmm11, [rsp+0xA0]
00007efc33fd8361  vmovaps xmm12, [rsp+0xB0]
00007efc33fd836a  vmovaps xmm13, [rsp+0xC0]
00007efc33fd8373  vmovaps xmm14, [rsp+0xD0]
00007efc33fd837c  vmovaps xmm15, [rsp+0xE0]
00007efc33fd8385  add rsp, 0xF0
00007efc33fd838c  pop r11
00007efc33fd838e  pop r10
00007efc33fd8390  pop r9
00007efc33fd8392  pop r8
00007efc33fd8394  pop rsi
00007efc33fd8395  pop rdi
00007efc33fd8396  pop rdx
00007efc33fd8397  pop rcx
00007efc33fd8398  pop rax
00007efc33fd8399  add rsp, 0x08
00007efc33fd839d  jmp 0x00007EFC33FD5F87
00007efc33fd83a2  sub rsp, 0x08
00007efc33fd83a6  push rax
00007efc33fd83a7  push rcx
00007efc33fd83a8  push rdx
00007efc33fd83a9  push rdi
00007efc33fd83aa  push rsi
00007efc33fd83ab  push r8
00007efc33fd83ad  push r9
00007efc33fd83af  push r10
00007efc33fd83b1  push r11
00007efc33fd83b3  sub rsp, 0xF0
00007efc33fd83ba  vmovaps [rsp], xmm0
00007efc33fd83bf  vmovaps [rsp+0x10], xmm1
00007efc33fd83c5  vmovaps [rsp+0x20], xmm2
00007efc33fd83cb  vmovaps [rsp+0x30], xmm3
00007efc33fd83d1  vmovaps [rsp+0x40], xmm4
00007efc33fd83d7  vmovaps [rsp+0x50], xmm5
00007efc33fd83dd  vmovaps [rsp+0x60], xmm7
00007efc33fd83e3  vmovaps [rsp+0x70], xmm8
00007efc33fd83e9  vmovaps [rsp+0x80], xmm9
00007efc33fd83f2  vmovaps [rsp+0x90], xmm10
00007efc33fd83fb  vmovaps [rsp+0xA0], xmm11
00007efc33fd8404  vmovaps [rsp+0xB0], xmm12
00007efc33fd840d  vmovaps [rsp+0xC0], xmm13
00007efc33fd8416  vmovaps [rsp+0xD0], xmm14
00007efc33fd841f  vmovaps [rsp+0xE0], xmm15
00007efc33fd8428  sub rsp, 0x30
00007efc33fd842c  movaps [rsp], xmm6
00007efc33fd8430  movaps [rsp+0x10], xmm9
00007efc33fd8436  movaps [rsp+0x20], xmm1
00007efc33fd843b  lea rdi, [rsp]
00007efc33fd843f  mov esi, 0x00
00007efc33fd8444  mov rax, 0x5D9448894530
00007efc33fd844e  call rax
00007efc33fd8450  movaps xmm6, [rsp]
00007efc33fd8454  add rsp, 0x30
00007efc33fd8458  vmovaps xmm0, [rsp]
00007efc33fd845d  vmovaps xmm1, [rsp+0x10]
00007efc33fd8463  vmovaps xmm2, [rsp+0x20]
00007efc33fd8469  vmovaps xmm3, [rsp+0x30]
00007efc33fd846f  vmovaps xmm4, [rsp+0x40]
00007efc33fd8475  vmovaps xmm5, [rsp+0x50]
00007efc33fd847b  vmovaps xmm7, [rsp+0x60]
00007efc33fd8481  vmovaps xmm8, [rsp+0x70]
00007efc33fd8487  vmovaps xmm9, [rsp+0x80]
00007efc33fd8490  vmovaps xmm10, [rsp+0x90]
00007efc33fd8499  vmovaps xmm11, [rsp+0xA0]
00007efc33fd84a2  vmovaps xmm12, [rsp+0xB0]
00007efc33fd84ab  vmovaps xmm13, [rsp+0xC0]
00007efc33fd84b4  vmovaps xmm14, [rsp+0xD0]
00007efc33fd84bd  vmovaps xmm15, [rsp+0xE0]
00007efc33fd84c6  add rsp, 0xF0
00007efc33fd84cd  pop r11
00007efc33fd84cf  pop r10
00007efc33fd84d1  pop r9
00007efc33fd84d3  pop r8
00007efc33fd84d5  pop rsi
00007efc33fd84d6  pop rdi
00007efc33fd84d7  pop rdx
00007efc33fd84d8  pop rcx
00007efc33fd84d9  pop rax
00007efc33fd84da  add rsp, 0x08
00007efc33fd84de  jmp 0x00007EFC33FD5FAB
00007efc33fd84e3  sub rsp, 0x08
00007efc33fd84e7  push rax
00007efc33fd84e8  push rcx
00007efc33fd84e9  push rdx
00007efc33fd84ea  push rdi
00007efc33fd84eb  push rsi
00007efc33fd84ec  push r8
00007efc33fd84ee  push r9
00007efc33fd84f0  push r10
00007efc33fd84f2  push r11
00007efc33fd84f4  sub rsp, 0xF0
00007efc33fd84fb  vmovaps [rsp], xmm0
00007efc33fd8500  vmovaps [rsp+0x10], xmm1
00007efc33fd8506  vmovaps [rsp+0x20], xmm2
00007efc33fd850c  vmovaps [rsp+0x30], xmm3
00007efc33fd8512  vmovaps [rsp+0x40], xmm4
00007efc33fd8518  vmovaps [rsp+0x50], xmm5
00007efc33fd851e  vmovaps [rsp+0x60], xmm6
00007efc33fd8524  vmovaps [rsp+0x70], xmm7
00007efc33fd852a  vmovaps [rsp+0x80], xmm8
00007efc33fd8533  vmovaps [rsp+0x90], xmm10
00007efc33fd853c  vmovaps [rsp+0xA0], xmm11
00007efc33fd8545  vmovaps [rsp+0xB0], xmm12
00007efc33fd854e  vmovaps [rsp+0xC0], xmm13
00007efc33fd8557  vmovaps [rsp+0xD0], xmm14
00007efc33fd8560  vmovaps [rsp+0xE0], xmm15
00007efc33fd8569  sub rsp, 0x30
00007efc33fd856d  movaps [rsp], xmm9
00007efc33fd8572  movaps [rsp+0x10], xmm3
00007efc33fd8577  movaps [rsp+0x20], xmm1
00007efc33fd857c  lea rdi, [rsp]
00007efc33fd8580  mov esi, 0x00
00007efc33fd8585  mov rax, 0x5D9448894530
00007efc33fd858f  call rax
00007efc33fd8591  movaps xmm9, [rsp]
00007efc33fd8596  add rsp, 0x30
00007efc33fd859a  vmovaps xmm0, [rsp]
00007efc33fd859f  vmovaps xmm1, [rsp+0x10]
00007efc33fd85a5  vmovaps xmm2, [rsp+0x20]
00007efc33fd85ab  vmovaps xmm3, [rsp+0x30]
00007efc33fd85b1  vmovaps xmm4, [rsp+0x40]
00007efc33fd85b7  vmovaps xmm5, [rsp+0x50]
00007efc33fd85bd  vmovaps xmm6, [rsp+0x60]
00007efc33fd85c3  vmovaps xmm7, [rsp+0x70]
00007efc33fd85c9  vmovaps xmm8, [rsp+0x80]
00007efc33fd85d2  vmovaps xmm10, [rsp+0x90]
00007efc33fd85db  vmovaps xmm11, [rsp+0xA0]
00007efc33fd85e4  vmovaps xmm12, [rsp+0xB0]
00007efc33fd85ed  vmovaps xmm13, [rsp+0xC0]
00007efc33fd85f6  vmovaps xmm14, [rsp+0xD0]
00007efc33fd85ff  vmovaps xmm15, [rsp+0xE0]
00007efc33fd8608  add rsp, 0xF0
00007efc33fd860f  pop r11
00007efc33fd8611  pop r10
00007efc33fd8613  pop r9
00007efc33fd8615  pop r8
00007efc33fd8617  pop rsi
00007efc33fd8618  pop rdi
00007efc33fd8619  pop rdx
00007efc33fd861a  pop rcx
00007efc33fd861b  pop rax
00007efc33fd861c  add rsp, 0x08
00007efc33fd8620  jmp 0x00007EFC33FD5FF7
00007efc33fd8625  call 0x00007EFC33ED64F0
00007efc33fd862a  jmp 0x00007EFC33FD6004
00007efc33fd862f  sub rsp, 0x08
00007efc33fd8633  push rax
00007efc33fd8634  push rcx
00007efc33fd8635  push rdx
00007efc33fd8636  push rdi
00007efc33fd8637  push rsi
00007efc33fd8638  push r8
00007efc33fd863a  push r9
00007efc33fd863c  push r10
00007efc33fd863e  push r11
00007efc33fd8640  sub rsp, 0xF0
00007efc33fd8647  vmovaps [rsp], xmm0
00007efc33fd864c  vmovaps [rsp+0x10], xmm1
00007efc33fd8652  vmovaps [rsp+0x20], xmm2
00007efc33fd8658  vmovaps [rsp+0x30], xmm3
00007efc33fd865e  vmovaps [rsp+0x40], xmm4
00007efc33fd8664  vmovaps [rsp+0x50], xmm5
00007efc33fd866a  vmovaps [rsp+0x60], xmm6
00007efc33fd8670  vmovaps [rsp+0x70], xmm7
00007efc33fd8676  vmovaps [rsp+0x80], xmm8
00007efc33fd867f  vmovaps [rsp+0x90], xmm9
00007efc33fd8688  vmovaps [rsp+0xA0], xmm10
00007efc33fd8691  vmovaps [rsp+0xB0], xmm11
00007efc33fd869a  vmovaps [rsp+0xC0], xmm12
00007efc33fd86a3  vmovaps [rsp+0xD0], xmm13
00007efc33fd86ac  vmovaps [rsp+0xE0], xmm14
00007efc33fd86b5  sub rsp, 0x30
00007efc33fd86b9  movaps [rsp], xmm15
00007efc33fd86be  movaps [rsp+0x10], xmm3
00007efc33fd86c3  movaps [rsp+0x20], xmm7
00007efc33fd86c8  lea rdi, [rsp]
00007efc33fd86cc  mov esi, 0x00
00007efc33fd86d1  mov rax, 0x5D9448894530
00007efc33fd86db  call rax
00007efc33fd86dd  movaps xmm15, [rsp]
00007efc33fd86e2  add rsp, 0x30
00007efc33fd86e6  vmovaps xmm0, [rsp]
00007efc33fd86eb  vmovaps xmm1, [rsp+0x10]
00007efc33fd86f1  vmovaps xmm2, [rsp+0x20]
00007efc33fd86f7  vmovaps xmm3, [rsp+0x30]
00007efc33fd86fd  vmovaps xmm4, [rsp+0x40]
00007efc33fd8703  vmovaps xmm5, [rsp+0x50]
00007efc33fd8709  vmovaps xmm6, [rsp+0x60]
00007efc33fd870f  vmovaps xmm7, [rsp+0x70]
00007efc33fd8715  vmovaps xmm8, [rsp+0x80]
00007efc33fd871e  vmovaps xmm9, [rsp+0x90]
00007efc33fd8727  vmovaps xmm10, [rsp+0xA0]
00007efc33fd8730  vmovaps xmm11, [rsp+0xB0]
00007efc33fd8739  vmovaps xmm12, [rsp+0xC0]
00007efc33fd8742  vmovaps xmm13, [rsp+0xD0]
00007efc33fd874b  vmovaps xmm14, [rsp+0xE0]
00007efc33fd8754  add rsp, 0xF0
00007efc33fd875b  pop r11
00007efc33fd875d  pop r10
00007efc33fd875f  pop r9
00007efc33fd8761  pop r8
00007efc33fd8763  pop rsi
00007efc33fd8764  pop rdi
00007efc33fd8765  pop rdx
00007efc33fd8766  pop rcx
00007efc33fd8767  pop rax
00007efc33fd8768  add rsp, 0x08
00007efc33fd876c  jmp 0x00007EFC33FD6030
00007efc33fd8771  sub rsp, 0x08
00007efc33fd8775  push rax
00007efc33fd8776  push rcx
00007efc33fd8777  push rdx
00007efc33fd8778  push rdi
00007efc33fd8779  push rsi
00007efc33fd877a  push r8
00007efc33fd877c  push r9
00007efc33fd877e  push r10
00007efc33fd8780  push r11
00007efc33fd8782  sub rsp, 0xF0
00007efc33fd8789  vmovaps [rsp], xmm0
00007efc33fd878e  vmovaps [rsp+0x10], xmm1
00007efc33fd8794  vmovaps [rsp+0x20], xmm2
00007efc33fd879a  vmovaps [rsp+0x30], xmm4
00007efc33fd87a0  vmovaps [rsp+0x40], xmm5
00007efc33fd87a6  vmovaps [rsp+0x50], xmm6
00007efc33fd87ac  vmovaps [rsp+0x60], xmm7
00007efc33fd87b2  vmovaps [rsp+0x70], xmm8
00007efc33fd87b8  vmovaps [rsp+0x80], xmm9
00007efc33fd87c1  vmovaps [rsp+0x90], xmm10
00007efc33fd87ca  vmovaps [rsp+0xA0], xmm11
00007efc33fd87d3  vmovaps [rsp+0xB0], xmm12
00007efc33fd87dc  vmovaps [rsp+0xC0], xmm13
00007efc33fd87e5  vmovaps [rsp+0xD0], xmm14
00007efc33fd87ee  vmovaps [rsp+0xE0], xmm15
00007efc33fd87f7  sub rsp, 0x30
00007efc33fd87fb  movaps [rsp], xmm3
00007efc33fd87ff  movaps [rsp+0x10], xmm1
00007efc33fd8804  movaps [rsp+0x20], xmm15
00007efc33fd880a  lea rdi, [rsp]
00007efc33fd880e  mov esi, 0x00
00007efc33fd8813  mov rax, 0x5D9448894530
00007efc33fd881d  call rax
00007efc33fd881f  movaps xmm3, [rsp]
00007efc33fd8823  add rsp, 0x30
00007efc33fd8827  vmovaps xmm0, [rsp]
00007efc33fd882c  vmovaps xmm1, [rsp+0x10]
00007efc33fd8832  vmovaps xmm2, [rsp+0x20]
00007efc33fd8838  vmovaps xmm4, [rsp+0x30]
00007efc33fd883e  vmovaps xmm5, [rsp+0x40]
00007efc33fd8844  vmovaps xmm6, [rsp+0x50]
00007efc33fd884a  vmovaps xmm7, [rsp+0x60]
00007efc33fd8850  vmovaps xmm8, [rsp+0x70]
00007efc33fd8856  vmovaps xmm9, [rsp+0x80]
00007efc33fd885f  vmovaps xmm10, [rsp+0x90]
00007efc33fd8868  vmovaps xmm11, [rsp+0xA0]
00007efc33fd8871  vmovaps xmm12, [rsp+0xB0]
00007efc33fd887a  vmovaps xmm13, [rsp+0xC0]
00007efc33fd8883  vmovaps xmm14, [rsp+0xD0]
00007efc33fd888c  vmovaps xmm15, [rsp+0xE0]
00007efc33fd8895  add rsp, 0xF0
00007efc33fd889c  pop r11
00007efc33fd889e  pop r10
00007efc33fd88a0  pop r9
00007efc33fd88a2  pop r8
00007efc33fd88a4  pop rsi
00007efc33fd88a5  pop rdi
00007efc33fd88a6  pop rdx
00007efc33fd88a7  pop rcx
00007efc33fd88a8  pop rax
00007efc33fd88a9  add rsp, 0x08
00007efc33fd88ad  jmp 0x00007EFC33FD60BF
00007efc33fd88b2  call 0x00007EFC33ED64F0
00007efc33fd88b7  jmp 0x00007EFC33FD60C9
00007efc33fd88bc  sub rsp, 0x08
00007efc33fd88c0  push rax
00007efc33fd88c1  push rcx
00007efc33fd88c2  push rdx
00007efc33fd88c3  push rdi
00007efc33fd88c4  push rsi
00007efc33fd88c5  push r8
00007efc33fd88c7  push r9
00007efc33fd88c9  push r10
00007efc33fd88cb  push r11
00007efc33fd88cd  sub rsp, 0xF0
00007efc33fd88d4  vmovaps [rsp], xmm0
00007efc33fd88d9  vmovaps [rsp+0x10], xmm1
00007efc33fd88df  vmovaps [rsp+0x20], xmm2
00007efc33fd88e5  vmovaps [rsp+0x30], xmm3
00007efc33fd88eb  vmovaps [rsp+0x40], xmm4
00007efc33fd88f1  vmovaps [rsp+0x50], xmm5
00007efc33fd88f7  vmovaps [rsp+0x60], xmm6
00007efc33fd88fd  vmovaps [rsp+0x70], xmm7
00007efc33fd8903  vmovaps [rsp+0x80], xmm8
00007efc33fd890c  vmovaps [rsp+0x90], xmm9
00007efc33fd8915  vmovaps [rsp+0xA0], xmm10
00007efc33fd891e  vmovaps [rsp+0xB0], xmm11
00007efc33fd8927  vmovaps [rsp+0xC0], xmm12
00007efc33fd8930  vmovaps [rsp+0xD0], xmm13
00007efc33fd8939  vmovaps [rsp+0xE0], xmm14
00007efc33fd8942  sub rsp, 0x30
00007efc33fd8946  movaps [rsp], xmm15
00007efc33fd894b  movaps [rsp+0x10], xmm14
00007efc33fd8951  movaps [rsp+0x20], xmm4
00007efc33fd8956  lea rdi, [rsp]
00007efc33fd895a  mov esi, 0x00
00007efc33fd895f  mov rax, 0x5D9448894530
00007efc33fd8969  call rax
00007efc33fd896b  movaps xmm15, [rsp]
00007efc33fd8970  add rsp, 0x30
00007efc33fd8974  vmovaps xmm0, [rsp]
00007efc33fd8979  vmovaps xmm1, [rsp+0x10]
00007efc33fd897f  vmovaps xmm2, [rsp+0x20]
00007efc33fd8985  vmovaps xmm3, [rsp+0x30]
00007efc33fd898b  vmovaps xmm4, [rsp+0x40]
00007efc33fd8991  vmovaps xmm5, [rsp+0x50]
00007efc33fd8997  vmovaps xmm6, [rsp+0x60]
00007efc33fd899d  vmovaps xmm7, [rsp+0x70]
00007efc33fd89a3  vmovaps xmm8, [rsp+0x80]
00007efc33fd89ac  vmovaps xmm9, [rsp+0x90]
00007efc33fd89b5  vmovaps xmm10, [rsp+0xA0]
00007efc33fd89be  vmovaps xmm11, [rsp+0xB0]
00007efc33fd89c7  vmovaps xmm12, [rsp+0xC0]
00007efc33fd89d0  vmovaps xmm13, [rsp+0xD0]
00007efc33fd89d9  vmovaps xmm14, [rsp+0xE0]
00007efc33fd89e2  add rsp, 0xF0
00007efc33fd89e9  pop r11
00007efc33fd89eb  pop r10
00007efc33fd89ed  pop r9
00007efc33fd89ef  pop r8
00007efc33fd89f1  pop rsi
00007efc33fd89f2  pop rdi
00007efc33fd89f3  pop rdx
00007efc33fd89f4  pop rcx
00007efc33fd89f5  pop rax
00007efc33fd89f6  add rsp, 0x08
00007efc33fd89fa  jmp 0x00007EFC33FD60F7
00007efc33fd89ff  sub rsp, 0x08
00007efc33fd8a03  push rax
00007efc33fd8a04  push rcx
00007efc33fd8a05  push rdx
00007efc33fd8a06  push rdi
00007efc33fd8a07  push rsi
00007efc33fd8a08  push r8
00007efc33fd8a0a  push r9
00007efc33fd8a0c  push r10
00007efc33fd8a0e  push r11
00007efc33fd8a10  sub rsp, 0xF0
00007efc33fd8a17  vmovaps [rsp], xmm0
00007efc33fd8a1c  vmovaps [rsp+0x10], xmm1
00007efc33fd8a22  vmovaps [rsp+0x20], xmm2
00007efc33fd8a28  vmovaps [rsp+0x30], xmm3
00007efc33fd8a2e  vmovaps [rsp+0x40], xmm4
00007efc33fd8a34  vmovaps [rsp+0x50], xmm5
00007efc33fd8a3a  vmovaps [rsp+0x60], xmm6
00007efc33fd8a40  vmovaps [rsp+0x70], xmm7
00007efc33fd8a46  vmovaps [rsp+0x80], xmm8
00007efc33fd8a4f  vmovaps [rsp+0x90], xmm9
00007efc33fd8a58  vmovaps [rsp+0xA0], xmm10
00007efc33fd8a61  vmovaps [rsp+0xB0], xmm11
00007efc33fd8a6a  vmovaps [rsp+0xC0], xmm12
00007efc33fd8a73  vmovaps [rsp+0xD0], xmm13
00007efc33fd8a7c  vmovaps [rsp+0xE0], xmm15
00007efc33fd8a85  sub rsp, 0x30
00007efc33fd8a89  movaps [rsp], xmm14
00007efc33fd8a8e  movaps [rsp+0x10], xmm2
00007efc33fd8a93  movaps [rsp+0x20], xmm1
00007efc33fd8a98  lea rdi, [rsp]
00007efc33fd8a9c  mov esi, 0x00
00007efc33fd8aa1  mov rax, 0x5D9448894530
00007efc33fd8aab  call rax
00007efc33fd8aad  movaps xmm14, [rsp]
00007efc33fd8ab2  add rsp, 0x30
00007efc33fd8ab6  vmovaps xmm0, [rsp]
00007efc33fd8abb  vmovaps xmm1, [rsp+0x10]
00007efc33fd8ac1  vmovaps xmm2, [rsp+0x20]
00007efc33fd8ac7  vmovaps xmm3, [rsp+0x30]
00007efc33fd8acd  vmovaps xmm4, [rsp+0x40]
00007efc33fd8ad3  vmovaps xmm5, [rsp+0x50]
00007efc33fd8ad9  vmovaps xmm6, [rsp+0x60]
00007efc33fd8adf  vmovaps xmm7, [rsp+0x70]
00007efc33fd8ae5  vmovaps xmm8, [rsp+0x80]
00007efc33fd8aee  vmovaps xmm9, [rsp+0x90]
00007efc33fd8af7  vmovaps xmm10, [rsp+0xA0]
00007efc33fd8b00  vmovaps xmm11, [rsp+0xB0]
00007efc33fd8b09  vmovaps xmm12, [rsp+0xC0]
00007efc33fd8b12  vmovaps xmm13, [rsp+0xD0]
00007efc33fd8b1b  vmovaps xmm15, [rsp+0xE0]
00007efc33fd8b24  add rsp, 0xF0
00007efc33fd8b2b  pop r11
00007efc33fd8b2d  pop r10
00007efc33fd8b2f  pop r9
00007efc33fd8b31  pop r8
00007efc33fd8b33  pop rsi
00007efc33fd8b34  pop rdi
00007efc33fd8b35  pop rdx
00007efc33fd8b36  pop rcx
00007efc33fd8b37  pop rax
00007efc33fd8b38  add rsp, 0x08
00007efc33fd8b3c  jmp 0x00007EFC33FD611D
00007efc33fd8b41  sub rsp, 0x08
00007efc33fd8b45  push rax
00007efc33fd8b46  push rcx
00007efc33fd8b47  push rdx
00007efc33fd8b48  push rdi
00007efc33fd8b49  push rsi
00007efc33fd8b4a  push r8
00007efc33fd8b4c  push r9
00007efc33fd8b4e  push r10
00007efc33fd8b50  push r11
00007efc33fd8b52  sub rsp, 0xF0
00007efc33fd8b59  vmovaps [rsp], xmm0
00007efc33fd8b5e  vmovaps [rsp+0x10], xmm2
00007efc33fd8b64  vmovaps [rsp+0x20], xmm3
00007efc33fd8b6a  vmovaps [rsp+0x30], xmm4
00007efc33fd8b70  vmovaps [rsp+0x40], xmm5
00007efc33fd8b76  vmovaps [rsp+0x50], xmm6
00007efc33fd8b7c  vmovaps [rsp+0x60], xmm7
00007efc33fd8b82  vmovaps [rsp+0x70], xmm8
00007efc33fd8b88  vmovaps [rsp+0x80], xmm9
00007efc33fd8b91  vmovaps [rsp+0x90], xmm10
00007efc33fd8b9a  vmovaps [rsp+0xA0], xmm11
00007efc33fd8ba3  vmovaps [rsp+0xB0], xmm12
00007efc33fd8bac  vmovaps [rsp+0xC0], xmm13
00007efc33fd8bb5  vmovaps [rsp+0xD0], xmm14
00007efc33fd8bbe  vmovaps [rsp+0xE0], xmm15
00007efc33fd8bc7  sub rsp, 0x30
00007efc33fd8bcb  movaps [rsp], xmm1
00007efc33fd8bcf  movaps [rsp+0x10], xmm4
00007efc33fd8bd4  movaps [rsp+0x20], xmm9
00007efc33fd8bda  lea rdi, [rsp]
00007efc33fd8bde  mov esi, 0x00
00007efc33fd8be3  mov rax, 0x5D9448894530
00007efc33fd8bed  call rax
00007efc33fd8bef  movaps xmm1, [rsp]
00007efc33fd8bf3  add rsp, 0x30
00007efc33fd8bf7  vmovaps xmm0, [rsp]
00007efc33fd8bfc  vmovaps xmm2, [rsp+0x10]
00007efc33fd8c02  vmovaps xmm3, [rsp+0x20]
00007efc33fd8c08  vmovaps xmm4, [rsp+0x30]
00007efc33fd8c0e  vmovaps xmm5, [rsp+0x40]
00007efc33fd8c14  vmovaps xmm6, [rsp+0x50]
00007efc33fd8c1a  vmovaps xmm7, [rsp+0x60]
00007efc33fd8c20  vmovaps xmm8, [rsp+0x70]
00007efc33fd8c26  vmovaps xmm9, [rsp+0x80]
00007efc33fd8c2f  vmovaps xmm10, [rsp+0x90]
00007efc33fd8c38  vmovaps xmm11, [rsp+0xA0]
00007efc33fd8c41  vmovaps xmm12, [rsp+0xB0]
00007efc33fd8c4a  vmovaps xmm13, [rsp+0xC0]
00007efc33fd8c53  vmovaps xmm14, [rsp+0xD0]
00007efc33fd8c5c  vmovaps xmm15, [rsp+0xE0]
00007efc33fd8c65  add rsp, 0xF0
00007efc33fd8c6c  pop r11
00007efc33fd8c6e  pop r10
00007efc33fd8c70  pop r9
00007efc33fd8c72  pop r8
00007efc33fd8c74  pop rsi
00007efc33fd8c75  pop rdi
00007efc33fd8c76  pop rdx
00007efc33fd8c77  pop rcx
00007efc33fd8c78  pop rax
00007efc33fd8c79  add rsp, 0x08
00007efc33fd8c7d  jmp 0x00007EFC33FD613B
00007efc33fd8c82  sub rsp, 0x08
00007efc33fd8c86  push rax
00007efc33fd8c87  push rcx
00007efc33fd8c88  push rdx
00007efc33fd8c89  push rdi
00007efc33fd8c8a  push rsi
00007efc33fd8c8b  push r8
00007efc33fd8c8d  push r9
00007efc33fd8c8f  push r10
00007efc33fd8c91  push r11
00007efc33fd8c93  sub rsp, 0xF0
00007efc33fd8c9a  vmovaps [rsp], xmm0
00007efc33fd8c9f  vmovaps [rsp+0x10], xmm1
00007efc33fd8ca5  vmovaps [rsp+0x20], xmm2
00007efc33fd8cab  vmovaps [rsp+0x30], xmm3
00007efc33fd8cb1  vmovaps [rsp+0x40], xmm5
00007efc33fd8cb7  vmovaps [rsp+0x50], xmm6
00007efc33fd8cbd  vmovaps [rsp+0x60], xmm7
00007efc33fd8cc3  vmovaps [rsp+0x70], xmm8
00007efc33fd8cc9  vmovaps [rsp+0x80], xmm9
00007efc33fd8cd2  vmovaps [rsp+0x90], xmm10
00007efc33fd8cdb  vmovaps [rsp+0xA0], xmm11
00007efc33fd8ce4  vmovaps [rsp+0xB0], xmm12
00007efc33fd8ced  vmovaps [rsp+0xC0], xmm13
00007efc33fd8cf6  vmovaps [rsp+0xD0], xmm14
00007efc33fd8cff  vmovaps [rsp+0xE0], xmm15
00007efc33fd8d08  sub rsp, 0x30
00007efc33fd8d0c  movaps [rsp], xmm4
00007efc33fd8d10  movaps [rsp+0x10], xmm2
00007efc33fd8d15  movaps [rsp+0x20], xmm9
00007efc33fd8d1b  lea rdi, [rsp]
00007efc33fd8d1f  mov esi, 0x00
00007efc33fd8d24  mov rax, 0x5D9448894530
00007efc33fd8d2e  call rax
00007efc33fd8d30  movaps xmm4, [rsp]
00007efc33fd8d34  add rsp, 0x30
00007efc33fd8d38  vmovaps xmm0, [rsp]
00007efc33fd8d3d  vmovaps xmm1, [rsp+0x10]
00007efc33fd8d43  vmovaps xmm2, [rsp+0x20]
00007efc33fd8d49  vmovaps xmm3, [rsp+0x30]
00007efc33fd8d4f  vmovaps xmm5, [rsp+0x40]
00007efc33fd8d55  vmovaps xmm6, [rsp+0x50]
00007efc33fd8d5b  vmovaps xmm7, [rsp+0x60]
00007efc33fd8d61  vmovaps xmm8, [rsp+0x70]
00007efc33fd8d67  vmovaps xmm9, [rsp+0x80]
00007efc33fd8d70  vmovaps xmm10, [rsp+0x90]
00007efc33fd8d79  vmovaps xmm11, [rsp+0xA0]
00007efc33fd8d82  vmovaps xmm12, [rsp+0xB0]
00007efc33fd8d8b  vmovaps xmm13, [rsp+0xC0]
00007efc33fd8d94  vmovaps xmm14, [rsp+0xD0]
00007efc33fd8d9d  vmovaps xmm15, [rsp+0xE0]
00007efc33fd8da6  add rsp, 0xF0
00007efc33fd8dad  pop r11
00007efc33fd8daf  pop r10
00007efc33fd8db1  pop r9
00007efc33fd8db3  pop r8
00007efc33fd8db5  pop rsi
00007efc33fd8db6  pop rdi
00007efc33fd8db7  pop rdx
00007efc33fd8db8  pop rcx
00007efc33fd8db9  pop rax
00007efc33fd8dba  add rsp, 0x08
00007efc33fd8dbe  jmp 0x00007EFC33FD616B
00007efc33fd8dc3  sub rsp, 0x08
00007efc33fd8dc7  push rax
00007efc33fd8dc8  push rcx
00007efc33fd8dc9  push rdx
00007efc33fd8dca  push rdi
00007efc33fd8dcb  push rsi
00007efc33fd8dcc  push r8
00007efc33fd8dce  push r9
00007efc33fd8dd0  push r10
00007efc33fd8dd2  push r11
00007efc33fd8dd4  sub rsp, 0xF0
00007efc33fd8ddb  vmovaps [rsp], xmm0
00007efc33fd8de0  vmovaps [rsp+0x10], xmm1
00007efc33fd8de6  vmovaps [rsp+0x20], xmm2
00007efc33fd8dec  vmovaps [rsp+0x30], xmm3
00007efc33fd8df2  vmovaps [rsp+0x40], xmm4
00007efc33fd8df8  vmovaps [rsp+0x50], xmm5
00007efc33fd8dfe  vmovaps [rsp+0x60], xmm6
00007efc33fd8e04  vmovaps [rsp+0x70], xmm7
00007efc33fd8e0a  vmovaps [rsp+0x80], xmm8
00007efc33fd8e13  vmovaps [rsp+0x90], xmm10
00007efc33fd8e1c  vmovaps [rsp+0xA0], xmm11
00007efc33fd8e25  vmovaps [rsp+0xB0], xmm12
00007efc33fd8e2e  vmovaps [rsp+0xC0], xmm13
00007efc33fd8e37  vmovaps [rsp+0xD0], xmm14
00007efc33fd8e40  vmovaps [rsp+0xE0], xmm15
00007efc33fd8e49  sub rsp, 0x30
00007efc33fd8e4d  movaps [rsp], xmm9
00007efc33fd8e52  movaps [rsp+0x10], xmm2
00007efc33fd8e57  movaps [rsp+0x20], xmm1
00007efc33fd8e5c  lea rdi, [rsp]
00007efc33fd8e60  mov esi, 0x00
00007efc33fd8e65  mov rax, 0x5D9448894530
00007efc33fd8e6f  call rax
00007efc33fd8e71  movaps xmm9, [rsp]
00007efc33fd8e76  add rsp, 0x30
00007efc33fd8e7a  vmovaps xmm0, [rsp]
00007efc33fd8e7f  vmovaps xmm1, [rsp+0x10]
00007efc33fd8e85  vmovaps xmm2, [rsp+0x20]
00007efc33fd8e8b  vmovaps xmm3, [rsp+0x30]
00007efc33fd8e91  vmovaps xmm4, [rsp+0x40]
00007efc33fd8e97  vmovaps xmm5, [rsp+0x50]
00007efc33fd8e9d  vmovaps xmm6, [rsp+0x60]
00007efc33fd8ea3  vmovaps xmm7, [rsp+0x70]
00007efc33fd8ea9  vmovaps xmm8, [rsp+0x80]
00007efc33fd8eb2  vmovaps xmm10, [rsp+0x90]
00007efc33fd8ebb  vmovaps xmm11, [rsp+0xA0]
00007efc33fd8ec4  vmovaps xmm12, [rsp+0xB0]
00007efc33fd8ecd  vmovaps xmm13, [rsp+0xC0]
00007efc33fd8ed6  vmovaps xmm14, [rsp+0xD0]
00007efc33fd8edf  vmovaps xmm15, [rsp+0xE0]
00007efc33fd8ee8  add rsp, 0xF0
00007efc33fd8eef  pop r11
00007efc33fd8ef1  pop r10
00007efc33fd8ef3  pop r9
00007efc33fd8ef5  pop r8
00007efc33fd8ef7  pop rsi
00007efc33fd8ef8  pop rdi
00007efc33fd8ef9  pop rdx
00007efc33fd8efa  pop rcx
00007efc33fd8efb  pop rax
00007efc33fd8efc  add rsp, 0x08
00007efc33fd8f00  jmp 0x00007EFC33FD61A1
00007efc33fd8f05  sub rsp, 0x08
00007efc33fd8f09  push rax
00007efc33fd8f0a  push rcx
00007efc33fd8f0b  push rdx
00007efc33fd8f0c  push rdi
00007efc33fd8f0d  push rsi
00007efc33fd8f0e  push r8
00007efc33fd8f10  push r9
00007efc33fd8f12  push r10
00007efc33fd8f14  push r11
00007efc33fd8f16  sub rsp, 0xF0
00007efc33fd8f1d  vmovaps [rsp], xmm0
00007efc33fd8f22  vmovaps [rsp+0x10], xmm2
00007efc33fd8f28  vmovaps [rsp+0x20], xmm3
00007efc33fd8f2e  vmovaps [rsp+0x30], xmm4
00007efc33fd8f34  vmovaps [rsp+0x40], xmm5
00007efc33fd8f3a  vmovaps [rsp+0x50], xmm6
00007efc33fd8f40  vmovaps [rsp+0x60], xmm7
00007efc33fd8f46  vmovaps [rsp+0x70], xmm8
00007efc33fd8f4c  vmovaps [rsp+0x80], xmm9
00007efc33fd8f55  vmovaps [rsp+0x90], xmm10
00007efc33fd8f5e  vmovaps [rsp+0xA0], xmm11
00007efc33fd8f67  vmovaps [rsp+0xB0], xmm12
00007efc33fd8f70  vmovaps [rsp+0xC0], xmm13
00007efc33fd8f79  vmovaps [rsp+0xD0], xmm14
00007efc33fd8f82  vmovaps [rsp+0xE0], xmm15
00007efc33fd8f8b  sub rsp, 0x30
00007efc33fd8f8f  movaps [rsp], xmm1
00007efc33fd8f93  movaps [rsp+0x10], xmm15
00007efc33fd8f99  movaps [rsp+0x20], xmm6
00007efc33fd8f9e  lea rdi, [rsp]
00007efc33fd8fa2  mov esi, 0x00
00007efc33fd8fa7  mov rax, 0x5D9448894530
00007efc33fd8fb1  call rax
00007efc33fd8fb3  movaps xmm1, [rsp]
00007efc33fd8fb7  add rsp, 0x30
00007efc33fd8fbb  vmovaps xmm0, [rsp]
00007efc33fd8fc0  vmovaps xmm2, [rsp+0x10]
00007efc33fd8fc6  vmovaps xmm3, [rsp+0x20]
00007efc33fd8fcc  vmovaps xmm4, [rsp+0x30]
00007efc33fd8fd2  vmovaps xmm5, [rsp+0x40]
00007efc33fd8fd8  vmovaps xmm6, [rsp+0x50]
00007efc33fd8fde  vmovaps xmm7, [rsp+0x60]
00007efc33fd8fe4  vmovaps xmm8, [rsp+0x70]
00007efc33fd8fea  vmovaps xmm9, [rsp+0x80]
00007efc33fd8ff3  vmovaps xmm10, [rsp+0x90]
00007efc33fd8ffc  vmovaps xmm11, [rsp+0xA0]
00007efc33fd9005  vmovaps xmm12, [rsp+0xB0]
00007efc33fd900e  vmovaps xmm13, [rsp+0xC0]
00007efc33fd9017  vmovaps xmm14, [rsp+0xD0]
00007efc33fd9020  vmovaps xmm15, [rsp+0xE0]
00007efc33fd9029  add rsp, 0xF0
00007efc33fd9030  pop r11
00007efc33fd9032  pop r10
00007efc33fd9034  pop r9
00007efc33fd9036  pop r8
00007efc33fd9038  pop rsi
00007efc33fd9039  pop rdi
00007efc33fd903a  pop rdx
00007efc33fd903b  pop rcx
00007efc33fd903c  pop rax
00007efc33fd903d  add rsp, 0x08
00007efc33fd9041  jmp 0x00007EFC33FD61C2
00007efc33fd9046  sub rsp, 0x08
00007efc33fd904a  push rax
00007efc33fd904b  push rcx
00007efc33fd904c  push rdx
00007efc33fd904d  push rdi
00007efc33fd904e  push rsi
00007efc33fd904f  push r8
00007efc33fd9051  push r9
00007efc33fd9053  push r10
00007efc33fd9055  push r11
00007efc33fd9057  sub rsp, 0xF0
00007efc33fd905e  vmovaps [rsp], xmm0
00007efc33fd9063  vmovaps [rsp+0x10], xmm1
00007efc33fd9069  vmovaps [rsp+0x20], xmm2
00007efc33fd906f  vmovaps [rsp+0x30], xmm3
00007efc33fd9075  vmovaps [rsp+0x40], xmm4
00007efc33fd907b  vmovaps [rsp+0x50], xmm5
00007efc33fd9081  vmovaps [rsp+0x60], xmm6
00007efc33fd9087  vmovaps [rsp+0x70], xmm7
00007efc33fd908d  vmovaps [rsp+0x80], xmm8
00007efc33fd9096  vmovaps [rsp+0x90], xmm9
00007efc33fd909f  vmovaps [rsp+0xA0], xmm10
00007efc33fd90a8  vmovaps [rsp+0xB0], xmm11
00007efc33fd90b1  vmovaps [rsp+0xC0], xmm12
00007efc33fd90ba  vmovaps [rsp+0xD0], xmm13
00007efc33fd90c3  vmovaps [rsp+0xE0], xmm14
00007efc33fd90cc  sub rsp, 0x30
00007efc33fd90d0  movaps [rsp], xmm15
00007efc33fd90d5  movaps [rsp+0x10], xmm5
00007efc33fd90da  movaps [rsp+0x20], xmm3
00007efc33fd90df  lea rdi, [rsp]
00007efc33fd90e3  mov esi, 0x00
00007efc33fd90e8  mov rax, 0x5D9448894530
00007efc33fd90f2  call rax
00007efc33fd90f4  movaps xmm15, [rsp]
00007efc33fd90f9  add rsp, 0x30
00007efc33fd90fd  vmovaps xmm0, [rsp]
00007efc33fd9102  vmovaps xmm1, [rsp+0x10]
00007efc33fd9108  vmovaps xmm2, [rsp+0x20]
00007efc33fd910e  vmovaps xmm3, [rsp+0x30]
00007efc33fd9114  vmovaps xmm4, [rsp+0x40]
00007efc33fd911a  vmovaps xmm5, [rsp+0x50]
00007efc33fd9120  vmovaps xmm6, [rsp+0x60]
00007efc33fd9126  vmovaps xmm7, [rsp+0x70]
00007efc33fd912c  vmovaps xmm8, [rsp+0x80]
00007efc33fd9135  vmovaps xmm9, [rsp+0x90]
00007efc33fd913e  vmovaps xmm10, [rsp+0xA0]
00007efc33fd9147  vmovaps xmm11, [rsp+0xB0]
00007efc33fd9150  vmovaps xmm12, [rsp+0xC0]
00007efc33fd9159  vmovaps xmm13, [rsp+0xD0]
00007efc33fd9162  vmovaps xmm14, [rsp+0xE0]
00007efc33fd916b  add rsp, 0xF0
00007efc33fd9172  pop r11
00007efc33fd9174  pop r10
00007efc33fd9176  pop r9
00007efc33fd9178  pop r8
00007efc33fd917a  pop rsi
00007efc33fd917b  pop rdi
00007efc33fd917c  pop rdx
00007efc33fd917d  pop rcx
00007efc33fd917e  pop rax
00007efc33fd917f  add rsp, 0x08
00007efc33fd9183  jmp 0x00007EFC33FD61DC
00007efc33fd9188  sub rsp, 0x08
00007efc33fd918c  push rax
00007efc33fd918d  push rcx
00007efc33fd918e  push rdx
00007efc33fd918f  push rdi
00007efc33fd9190  push rsi
00007efc33fd9191  push r8
00007efc33fd9193  push r9
00007efc33fd9195  push r10
00007efc33fd9197  push r11
00007efc33fd9199  sub rsp, 0xF0
00007efc33fd91a0  vmovaps [rsp], xmm0
00007efc33fd91a5  vmovaps [rsp+0x10], xmm1
00007efc33fd91ab  vmovaps [rsp+0x20], xmm2
00007efc33fd91b1  vmovaps [rsp+0x30], xmm3
00007efc33fd91b7  vmovaps [rsp+0x40], xmm4
00007efc33fd91bd  vmovaps [rsp+0x50], xmm6
00007efc33fd91c3  vmovaps [rsp+0x60], xmm7
00007efc33fd91c9  vmovaps [rsp+0x70], xmm8
00007efc33fd91cf  vmovaps [rsp+0x80], xmm9
00007efc33fd91d8  vmovaps [rsp+0x90], xmm10
00007efc33fd91e1  vmovaps [rsp+0xA0], xmm11
00007efc33fd91ea  vmovaps [rsp+0xB0], xmm12
00007efc33fd91f3  vmovaps [rsp+0xC0], xmm13
00007efc33fd91fc  vmovaps [rsp+0xD0], xmm14
00007efc33fd9205  vmovaps [rsp+0xE0], xmm15
00007efc33fd920e  sub rsp, 0x30
00007efc33fd9212  movaps [rsp], xmm5
00007efc33fd9216  movaps [rsp+0x10], xmm8
00007efc33fd921c  movaps [rsp+0x20], xmm6
00007efc33fd9221  lea rdi, [rsp]
00007efc33fd9225  mov esi, 0x00
00007efc33fd922a  mov rax, 0x5D9448894530
00007efc33fd9234  call rax
00007efc33fd9236  movaps xmm5, [rsp]
00007efc33fd923a  add rsp, 0x30
00007efc33fd923e  vmovaps xmm0, [rsp]
00007efc33fd9243  vmovaps xmm1, [rsp+0x10]
00007efc33fd9249  vmovaps xmm2, [rsp+0x20]
00007efc33fd924f  vmovaps xmm3, [rsp+0x30]
00007efc33fd9255  vmovaps xmm4, [rsp+0x40]
00007efc33fd925b  vmovaps xmm6, [rsp+0x50]
00007efc33fd9261  vmovaps xmm7, [rsp+0x60]
00007efc33fd9267  vmovaps xmm8, [rsp+0x70]
00007efc33fd926d  vmovaps xmm9, [rsp+0x80]
00007efc33fd9276  vmovaps xmm10, [rsp+0x90]
00007efc33fd927f  vmovaps xmm11, [rsp+0xA0]
00007efc33fd9288  vmovaps xmm12, [rsp+0xB0]
00007efc33fd9291  vmovaps xmm13, [rsp+0xC0]
00007efc33fd929a  vmovaps xmm14, [rsp+0xD0]
00007efc33fd92a3  vmovaps xmm15, [rsp+0xE0]
00007efc33fd92ac  add rsp, 0xF0
00007efc33fd92b3  pop r11
00007efc33fd92b5  pop r10
00007efc33fd92b7  pop r9
00007efc33fd92b9  pop r8
00007efc33fd92bb  pop rsi
00007efc33fd92bc  pop rdi
00007efc33fd92bd  pop rdx
00007efc33fd92be  pop rcx
00007efc33fd92bf  pop rax
00007efc33fd92c0  add rsp, 0x08
00007efc33fd92c4  jmp 0x00007EFC33FD6200
00007efc33fd92c9  sub rsp, 0x08
00007efc33fd92cd  push rax
00007efc33fd92ce  push rcx
00007efc33fd92cf  push rdx
00007efc33fd92d0  push rdi
00007efc33fd92d1  push rsi
00007efc33fd92d2  push r8
00007efc33fd92d4  push r9
00007efc33fd92d6  push r10
00007efc33fd92d8  push r11
00007efc33fd92da  sub rsp, 0xF0
00007efc33fd92e1  vmovaps [rsp], xmm0
00007efc33fd92e6  vmovaps [rsp+0x10], xmm1
00007efc33fd92ec  vmovaps [rsp+0x20], xmm2
00007efc33fd92f2  vmovaps [rsp+0x30], xmm3
00007efc33fd92f8  vmovaps [rsp+0x40], xmm4
00007efc33fd92fe  vmovaps [rsp+0x50], xmm5
00007efc33fd9304  vmovaps [rsp+0x60], xmm7
00007efc33fd930a  vmovaps [rsp+0x70], xmm8
00007efc33fd9310  vmovaps [rsp+0x80], xmm9
00007efc33fd9319  vmovaps [rsp+0x90], xmm10
00007efc33fd9322  vmovaps [rsp+0xA0], xmm11
00007efc33fd932b  vmovaps [rsp+0xB0], xmm12
00007efc33fd9334  vmovaps [rsp+0xC0], xmm13
00007efc33fd933d  vmovaps [rsp+0xD0], xmm14
00007efc33fd9346  vmovaps [rsp+0xE0], xmm15
00007efc33fd934f  sub rsp, 0x30
00007efc33fd9353  movaps [rsp], xmm6
00007efc33fd9357  movaps [rsp+0x10], xmm10
00007efc33fd935d  movaps [rsp+0x20], xmm8
00007efc33fd9363  lea rdi, [rsp]
00007efc33fd9367  mov esi, 0x00
00007efc33fd936c  mov rax, 0x5D9448894530
00007efc33fd9376  call rax
00007efc33fd9378  movaps xmm6, [rsp]
00007efc33fd937c  add rsp, 0x30
00007efc33fd9380  vmovaps xmm0, [rsp]
00007efc33fd9385  vmovaps xmm1, [rsp+0x10]
00007efc33fd938b  vmovaps xmm2, [rsp+0x20]
00007efc33fd9391  vmovaps xmm3, [rsp+0x30]
00007efc33fd9397  vmovaps xmm4, [rsp+0x40]
00007efc33fd939d  vmovaps xmm5, [rsp+0x50]
00007efc33fd93a3  vmovaps xmm7, [rsp+0x60]
00007efc33fd93a9  vmovaps xmm8, [rsp+0x70]
00007efc33fd93af  vmovaps xmm9, [rsp+0x80]
00007efc33fd93b8  vmovaps xmm10, [rsp+0x90]
00007efc33fd93c1  vmovaps xmm11, [rsp+0xA0]
00007efc33fd93ca  vmovaps xmm12, [rsp+0xB0]
00007efc33fd93d3  vmovaps xmm13, [rsp+0xC0]
00007efc33fd93dc  vmovaps xmm14, [rsp+0xD0]
00007efc33fd93e5  vmovaps xmm15, [rsp+0xE0]
00007efc33fd93ee  add rsp, 0xF0
00007efc33fd93f5  pop r11
00007efc33fd93f7  pop r10
00007efc33fd93f9  pop r9
00007efc33fd93fb  pop r8
00007efc33fd93fd  pop rsi
00007efc33fd93fe  pop rdi
00007efc33fd93ff  pop rdx
00007efc33fd9400  pop rcx
00007efc33fd9401  pop rax
00007efc33fd9402  add rsp, 0x08
00007efc33fd9406  jmp 0x00007EFC33FD6225
00007efc33fd940b  sub rsp, 0x08
00007efc33fd940f  push rax
00007efc33fd9410  push rcx
00007efc33fd9411  push rdx
00007efc33fd9412  push rdi
00007efc33fd9413  push rsi
00007efc33fd9414  push r8
00007efc33fd9416  push r9
00007efc33fd9418  push r10
00007efc33fd941a  push r11
00007efc33fd941c  sub rsp, 0xF0
00007efc33fd9423  vmovaps [rsp], xmm0
00007efc33fd9428  vmovaps [rsp+0x10], xmm1
00007efc33fd942e  vmovaps [rsp+0x20], xmm2
00007efc33fd9434  vmovaps [rsp+0x30], xmm3
00007efc33fd943a  vmovaps [rsp+0x40], xmm4
00007efc33fd9440  vmovaps [rsp+0x50], xmm5
00007efc33fd9446  vmovaps [rsp+0x60], xmm6
00007efc33fd944c  vmovaps [rsp+0x70], xmm7
00007efc33fd9452  vmovaps [rsp+0x80], xmm8
00007efc33fd945b  vmovaps [rsp+0x90], xmm9
00007efc33fd9464  vmovaps [rsp+0xA0], xmm11
00007efc33fd946d  vmovaps [rsp+0xB0], xmm12
00007efc33fd9476  vmovaps [rsp+0xC0], xmm13
00007efc33fd947f  vmovaps [rsp+0xD0], xmm14
00007efc33fd9488  vmovaps [rsp+0xE0], xmm15
00007efc33fd9491  sub rsp, 0x30
00007efc33fd9495  movaps [rsp], xmm10
00007efc33fd949a  movaps [rsp+0x10], xmm8
00007efc33fd94a0  movaps [rsp+0x20], xmm14
00007efc33fd94a6  lea rdi, [rsp]
00007efc33fd94aa  mov esi, 0x00
00007efc33fd94af  mov rax, 0x5D9448894530
00007efc33fd94b9  call rax
00007efc33fd94bb  movaps xmm10, [rsp]
00007efc33fd94c0  add rsp, 0x30
00007efc33fd94c4  vmovaps xmm0, [rsp]
00007efc33fd94c9  vmovaps xmm1, [rsp+0x10]
00007efc33fd94cf  vmovaps xmm2, [rsp+0x20]
00007efc33fd94d5  vmovaps xmm3, [rsp+0x30]
00007efc33fd94db  vmovaps xmm4, [rsp+0x40]
00007efc33fd94e1  vmovaps xmm5, [rsp+0x50]
00007efc33fd94e7  vmovaps xmm6, [rsp+0x60]
00007efc33fd94ed  vmovaps xmm7, [rsp+0x70]
00007efc33fd94f3  vmovaps xmm8, [rsp+0x80]
00007efc33fd94fc  vmovaps xmm9, [rsp+0x90]
00007efc33fd9505  vmovaps xmm11, [rsp+0xA0]
00007efc33fd950e  vmovaps xmm12, [rsp+0xB0]
00007efc33fd9517  vmovaps xmm13, [rsp+0xC0]
00007efc33fd9520  vmovaps xmm14, [rsp+0xD0]
00007efc33fd9529  vmovaps xmm15, [rsp+0xE0]
00007efc33fd9532  add rsp, 0xF0
00007efc33fd9539  pop r11
00007efc33fd953b  pop r10
00007efc33fd953d  pop r9
00007efc33fd953f  pop r8
00007efc33fd9541  pop rsi
00007efc33fd9542  pop rdi
00007efc33fd9543  pop rdx
00007efc33fd9544  pop rcx
00007efc33fd9545  pop rax
00007efc33fd9546  add rsp, 0x08
00007efc33fd954a  jmp 0x00007EFC33FD6245
00007efc33fd954f  sub rsp, 0x08
00007efc33fd9553  push rax
00007efc33fd9554  push rcx
00007efc33fd9555  push rdx
00007efc33fd9556  push rdi
00007efc33fd9557  push rsi
00007efc33fd9558  push r8
00007efc33fd955a  push r9
00007efc33fd955c  push r10
00007efc33fd955e  push r11
00007efc33fd9560  sub rsp, 0xF0
00007efc33fd9567  vmovaps [rsp], xmm0
00007efc33fd956c  vmovaps [rsp+0x10], xmm1
00007efc33fd9572  vmovaps [rsp+0x20], xmm2
00007efc33fd9578  vmovaps [rsp+0x30], xmm3
00007efc33fd957e  vmovaps [rsp+0x40], xmm4
00007efc33fd9584  vmovaps [rsp+0x50], xmm5
00007efc33fd958a  vmovaps [rsp+0x60], xmm6
00007efc33fd9590  vmovaps [rsp+0x70], xmm7
00007efc33fd9596  vmovaps [rsp+0x80], xmm8
00007efc33fd959f  vmovaps [rsp+0x90], xmm9
00007efc33fd95a8  vmovaps [rsp+0xA0], xmm10
00007efc33fd95b1  vmovaps [rsp+0xB0], xmm11
00007efc33fd95ba  vmovaps [rsp+0xC0], xmm12
00007efc33fd95c3  vmovaps [rsp+0xD0], xmm13
00007efc33fd95cc  vmovaps [rsp+0xE0], xmm15
00007efc33fd95d5  sub rsp, 0x30
00007efc33fd95d9  movaps [rsp], xmm14
00007efc33fd95de  movaps [rsp+0x10], xmm8
00007efc33fd95e4  movaps [rsp+0x20], xmm4
00007efc33fd95e9  lea rdi, [rsp]
00007efc33fd95ed  mov esi, 0x00
00007efc33fd95f2  mov rax, 0x5D9448894530
00007efc33fd95fc  call rax
00007efc33fd95fe  movaps xmm14, [rsp]
00007efc33fd9603  add rsp, 0x30
00007efc33fd9607  vmovaps xmm0, [rsp]
00007efc33fd960c  vmovaps xmm1, [rsp+0x10]
00007efc33fd9612  vmovaps xmm2, [rsp+0x20]
00007efc33fd9618  vmovaps xmm3, [rsp+0x30]
00007efc33fd961e  vmovaps xmm4, [rsp+0x40]
00007efc33fd9624  vmovaps xmm5, [rsp+0x50]
00007efc33fd962a  vmovaps xmm6, [rsp+0x60]
00007efc33fd9630  vmovaps xmm7, [rsp+0x70]
00007efc33fd9636  vmovaps xmm8, [rsp+0x80]
00007efc33fd963f  vmovaps xmm9, [rsp+0x90]
00007efc33fd9648  vmovaps xmm10, [rsp+0xA0]
00007efc33fd9651  vmovaps xmm11, [rsp+0xB0]
00007efc33fd965a  vmovaps xmm12, [rsp+0xC0]
00007efc33fd9663  vmovaps xmm13, [rsp+0xD0]
00007efc33fd966c  vmovaps xmm15, [rsp+0xE0]
00007efc33fd9675  add rsp, 0xF0
00007efc33fd967c  pop r11
00007efc33fd967e  pop r10
00007efc33fd9680  pop r9
00007efc33fd9682  pop r8
00007efc33fd9684  pop rsi
00007efc33fd9685  pop rdi
00007efc33fd9686  pop rdx
00007efc33fd9687  pop rcx
00007efc33fd9688  pop rax
00007efc33fd9689  add rsp, 0x08
00007efc33fd968d  jmp 0x00007EFC33FD6265
00007efc33fd9692  sub rsp, 0x08
00007efc33fd9696  push rax
00007efc33fd9697  push rcx
00007efc33fd9698  push rdx
00007efc33fd9699  push rdi
00007efc33fd969a  push rsi
00007efc33fd969b  push r8
00007efc33fd969d  push r9
00007efc33fd969f  push r10
00007efc33fd96a1  push r11
00007efc33fd96a3  sub rsp, 0xF0
00007efc33fd96aa  vmovaps [rsp], xmm0
00007efc33fd96af  vmovaps [rsp+0x10], xmm1
00007efc33fd96b5  vmovaps [rsp+0x20], xmm2
00007efc33fd96bb  vmovaps [rsp+0x30], xmm3
00007efc33fd96c1  vmovaps [rsp+0x40], xmm5
00007efc33fd96c7  vmovaps [rsp+0x50], xmm6
00007efc33fd96cd  vmovaps [rsp+0x60], xmm7
00007efc33fd96d3  vmovaps [rsp+0x70], xmm8
00007efc33fd96d9  vmovaps [rsp+0x80], xmm9
00007efc33fd96e2  vmovaps [rsp+0x90], xmm10
00007efc33fd96eb  vmovaps [rsp+0xA0], xmm11
00007efc33fd96f4  vmovaps [rsp+0xB0], xmm12
00007efc33fd96fd  vmovaps [rsp+0xC0], xmm13
00007efc33fd9706  vmovaps [rsp+0xD0], xmm14
00007efc33fd970f  vmovaps [rsp+0xE0], xmm15
00007efc33fd9718  sub rsp, 0x30
00007efc33fd971c  movaps [rsp], xmm4
00007efc33fd9720  movaps [rsp+0x10], xmm13
00007efc33fd9726  movaps [rsp+0x20], xmm8
00007efc33fd972c  lea rdi, [rsp]
00007efc33fd9730  mov esi, 0x00
00007efc33fd9735  mov rax, 0x5D9448894530
00007efc33fd973f  call rax
00007efc33fd9741  movaps xmm4, [rsp]
00007efc33fd9745  add rsp, 0x30
00007efc33fd9749  vmovaps xmm0, [rsp]
00007efc33fd974e  vmovaps xmm1, [rsp+0x10]
00007efc33fd9754  vmovaps xmm2, [rsp+0x20]
00007efc33fd975a  vmovaps xmm3, [rsp+0x30]
00007efc33fd9760  vmovaps xmm5, [rsp+0x40]
00007efc33fd9766  vmovaps xmm6, [rsp+0x50]
00007efc33fd976c  vmovaps xmm7, [rsp+0x60]
00007efc33fd9772  vmovaps xmm8, [rsp+0x70]
00007efc33fd9778  vmovaps xmm9, [rsp+0x80]
00007efc33fd9781  vmovaps xmm10, [rsp+0x90]
00007efc33fd978a  vmovaps xmm11, [rsp+0xA0]
00007efc33fd9793  vmovaps xmm12, [rsp+0xB0]
00007efc33fd979c  vmovaps xmm13, [rsp+0xC0]
00007efc33fd97a5  vmovaps xmm14, [rsp+0xD0]
00007efc33fd97ae  vmovaps xmm15, [rsp+0xE0]
00007efc33fd97b7  add rsp, 0xF0
00007efc33fd97be  pop r11
00007efc33fd97c0  pop r10
00007efc33fd97c2  pop r9
00007efc33fd97c4  pop r8
00007efc33fd97c6  pop rsi
00007efc33fd97c7  pop rdi
00007efc33fd97c8  pop rdx
00007efc33fd97c9  pop rcx
00007efc33fd97ca  pop rax
00007efc33fd97cb  add rsp, 0x08
00007efc33fd97cf  jmp 0x00007EFC33FD628A
00007efc33fd97d4  sub rsp, 0x08
00007efc33fd97d8  push rax
00007efc33fd97d9  push rcx
00007efc33fd97da  push rdx
00007efc33fd97db  push rdi
00007efc33fd97dc  push rsi
00007efc33fd97dd  push r8
00007efc33fd97df  push r9
00007efc33fd97e1  push r10
00007efc33fd97e3  push r11
00007efc33fd97e5  sub rsp, 0xF0
00007efc33fd97ec  vmovaps [rsp], xmm0
00007efc33fd97f1  vmovaps [rsp+0x10], xmm1
00007efc33fd97f7  vmovaps [rsp+0x20], xmm2
00007efc33fd97fd  vmovaps [rsp+0x30], xmm3
00007efc33fd9803  vmovaps [rsp+0x40], xmm4
00007efc33fd9809  vmovaps [rsp+0x50], xmm5
00007efc33fd980f  vmovaps [rsp+0x60], xmm6
00007efc33fd9815  vmovaps [rsp+0x70], xmm7
00007efc33fd981b  vmovaps [rsp+0x80], xmm8
00007efc33fd9824  vmovaps [rsp+0x90], xmm9
00007efc33fd982d  vmovaps [rsp+0xA0], xmm10
00007efc33fd9836  vmovaps [rsp+0xB0], xmm11
00007efc33fd983f  vmovaps [rsp+0xC0], xmm12
00007efc33fd9848  vmovaps [rsp+0xD0], xmm14
00007efc33fd9851  vmovaps [rsp+0xE0], xmm15
00007efc33fd985a  sub rsp, 0x30
00007efc33fd985e  movaps [rsp], xmm13
00007efc33fd9863  movaps [rsp+0x10], xmm15
00007efc33fd9869  movaps [rsp+0x20], xmm9
00007efc33fd986f  lea rdi, [rsp]
00007efc33fd9873  mov esi, 0x00
00007efc33fd9878  mov rax, 0x5D9448894530
00007efc33fd9882  call rax
00007efc33fd9884  movaps xmm13, [rsp]
00007efc33fd9889  add rsp, 0x30
00007efc33fd988d  vmovaps xmm0, [rsp]
00007efc33fd9892  vmovaps xmm1, [rsp+0x10]
00007efc33fd9898  vmovaps xmm2, [rsp+0x20]
00007efc33fd989e  vmovaps xmm3, [rsp+0x30]
00007efc33fd98a4  vmovaps xmm4, [rsp+0x40]
00007efc33fd98aa  vmovaps xmm5, [rsp+0x50]
00007efc33fd98b0  vmovaps xmm6, [rsp+0x60]
00007efc33fd98b6  vmovaps xmm7, [rsp+0x70]
00007efc33fd98bc  vmovaps xmm8, [rsp+0x80]
00007efc33fd98c5  vmovaps xmm9, [rsp+0x90]
00007efc33fd98ce  vmovaps xmm10, [rsp+0xA0]
00007efc33fd98d7  vmovaps xmm11, [rsp+0xB0]
00007efc33fd98e0  vmovaps xmm12, [rsp+0xC0]
00007efc33fd98e9  vmovaps xmm14, [rsp+0xD0]
00007efc33fd98f2  vmovaps xmm15, [rsp+0xE0]
00007efc33fd98fb  add rsp, 0xF0
00007efc33fd9902  pop r11
00007efc33fd9904  pop r10
00007efc33fd9906  pop r9
00007efc33fd9908  pop r8
00007efc33fd990a  pop rsi
00007efc33fd990b  pop rdi
00007efc33fd990c  pop rdx
00007efc33fd990d  pop rcx
00007efc33fd990e  pop rax
00007efc33fd990f  add rsp, 0x08
00007efc33fd9913  jmp 0x00007EFC33FD62A5
00007efc33fd9918  sub rsp, 0x08
00007efc33fd991c  push rax
00007efc33fd991d  push rcx
00007efc33fd991e  push rdx
00007efc33fd991f  push rdi
00007efc33fd9920  push rsi
00007efc33fd9921  push r8
00007efc33fd9923  push r9
00007efc33fd9925  push r10
00007efc33fd9927  push r11
00007efc33fd9929  sub rsp, 0xF0
00007efc33fd9930  vmovaps [rsp], xmm0
00007efc33fd9935  vmovaps [rsp+0x10], xmm1
00007efc33fd993b  vmovaps [rsp+0x20], xmm2
00007efc33fd9941  vmovaps [rsp+0x30], xmm3
00007efc33fd9947  vmovaps [rsp+0x40], xmm4
00007efc33fd994d  vmovaps [rsp+0x50], xmm5
00007efc33fd9953  vmovaps [rsp+0x60], xmm6
00007efc33fd9959  vmovaps [rsp+0x70], xmm7
00007efc33fd995f  vmovaps [rsp+0x80], xmm8
00007efc33fd9968  vmovaps [rsp+0x90], xmm9
00007efc33fd9971  vmovaps [rsp+0xA0], xmm10
00007efc33fd997a  vmovaps [rsp+0xB0], xmm11
00007efc33fd9983  vmovaps [rsp+0xC0], xmm12
00007efc33fd998c  vmovaps [rsp+0xD0], xmm13
00007efc33fd9995  vmovaps [rsp+0xE0], xmm14
00007efc33fd999e  sub rsp, 0x30
00007efc33fd99a2  movaps [rsp], xmm15
00007efc33fd99a7  movaps [rsp+0x10], xmm1
00007efc33fd99ac  movaps [rsp+0x20], xmm5
00007efc33fd99b1  lea rdi, [rsp]
00007efc33fd99b5  mov esi, 0x00
00007efc33fd99ba  mov rax, 0x5D9448894530
00007efc33fd99c4  call rax
00007efc33fd99c6  movaps xmm15, [rsp]
00007efc33fd99cb  add rsp, 0x30
00007efc33fd99cf  vmovaps xmm0, [rsp]
00007efc33fd99d4  vmovaps xmm1, [rsp+0x10]
00007efc33fd99da  vmovaps xmm2, [rsp+0x20]
00007efc33fd99e0  vmovaps xmm3, [rsp+0x30]
00007efc33fd99e6  vmovaps xmm4, [rsp+0x40]
00007efc33fd99ec  vmovaps xmm5, [rsp+0x50]
00007efc33fd99f2  vmovaps xmm6, [rsp+0x60]
00007efc33fd99f8  vmovaps xmm7, [rsp+0x70]
00007efc33fd99fe  vmovaps xmm8, [rsp+0x80]
00007efc33fd9a07  vmovaps xmm9, [rsp+0x90]
00007efc33fd9a10  vmovaps xmm10, [rsp+0xA0]
00007efc33fd9a19  vmovaps xmm11, [rsp+0xB0]
00007efc33fd9a22  vmovaps xmm12, [rsp+0xC0]
00007efc33fd9a2b  vmovaps xmm13, [rsp+0xD0]
00007efc33fd9a34  vmovaps xmm14, [rsp+0xE0]
00007efc33fd9a3d  add rsp, 0xF0
00007efc33fd9a44  pop r11
00007efc33fd9a46  pop r10
00007efc33fd9a48  pop r9
00007efc33fd9a4a  pop r8
00007efc33fd9a4c  pop rsi
00007efc33fd9a4d  pop rdi
00007efc33fd9a4e  pop rdx
00007efc33fd9a4f  pop rcx
00007efc33fd9a50  pop rax
00007efc33fd9a51  add rsp, 0x08
00007efc33fd9a55  jmp 0x00007EFC33FD62C0
00007efc33fd9a5a  call 0x00007EFC33ED64F0
00007efc33fd9a5f  jmp 0x00007EFC33FD631B
00007efc33fd9a64  sub rsp, 0x08
00007efc33fd9a68  push rax
00007efc33fd9a69  push rcx
00007efc33fd9a6a  push rdx
00007efc33fd9a6b  push rdi
00007efc33fd9a6c  push rsi
00007efc33fd9a6d  push r8
00007efc33fd9a6f  push r9
00007efc33fd9a71  push r10
00007efc33fd9a73  push r11
00007efc33fd9a75  sub rsp, 0xF0
00007efc33fd9a7c  vmovaps [rsp], xmm0
00007efc33fd9a81  vmovaps [rsp+0x10], xmm1
00007efc33fd9a87  vmovaps [rsp+0x20], xmm2
00007efc33fd9a8d  vmovaps [rsp+0x30], xmm3
00007efc33fd9a93  vmovaps [rsp+0x40], xmm4
00007efc33fd9a99  vmovaps [rsp+0x50], xmm5
00007efc33fd9a9f  vmovaps [rsp+0x60], xmm6
00007efc33fd9aa5  vmovaps [rsp+0x70], xmm7
00007efc33fd9aab  vmovaps [rsp+0x80], xmm8
00007efc33fd9ab4  vmovaps [rsp+0x90], xmm10
00007efc33fd9abd  vmovaps [rsp+0xA0], xmm11
00007efc33fd9ac6  vmovaps [rsp+0xB0], xmm12
00007efc33fd9acf  vmovaps [rsp+0xC0], xmm13
00007efc33fd9ad8  vmovaps [rsp+0xD0], xmm14
00007efc33fd9ae1  vmovaps [rsp+0xE0], xmm15
00007efc33fd9aea  sub rsp, 0x30
00007efc33fd9aee  movaps [rsp], xmm9
00007efc33fd9af3  movaps [rsp+0x10], xmm8
00007efc33fd9af9  movaps [rsp+0x20], xmm11
00007efc33fd9aff  lea rdi, [rsp]
00007efc33fd9b03  mov esi, 0x00
00007efc33fd9b08  mov rax, 0x5D9448894530
00007efc33fd9b12  call rax
00007efc33fd9b14  movaps xmm9, [rsp]
00007efc33fd9b19  add rsp, 0x30
00007efc33fd9b1d  vmovaps xmm0, [rsp]
00007efc33fd9b22  vmovaps xmm1, [rsp+0x10]
00007efc33fd9b28  vmovaps xmm2, [rsp+0x20]
00007efc33fd9b2e  vmovaps xmm3, [rsp+0x30]
00007efc33fd9b34  vmovaps xmm4, [rsp+0x40]
00007efc33fd9b3a  vmovaps xmm5, [rsp+0x50]
00007efc33fd9b40  vmovaps xmm6, [rsp+0x60]
00007efc33fd9b46  vmovaps xmm7, [rsp+0x70]
00007efc33fd9b4c  vmovaps xmm8, [rsp+0x80]
00007efc33fd9b55  vmovaps xmm10, [rsp+0x90]
00007efc33fd9b5e  vmovaps xmm11, [rsp+0xA0]
00007efc33fd9b67  vmovaps xmm12, [rsp+0xB0]
00007efc33fd9b70  vmovaps xmm13, [rsp+0xC0]
00007efc33fd9b79  vmovaps xmm14, [rsp+0xD0]
00007efc33fd9b82  vmovaps xmm15, [rsp+0xE0]
00007efc33fd9b8b  add rsp, 0xF0
00007efc33fd9b92  pop r11
00007efc33fd9b94  pop r10
00007efc33fd9b96  pop r9
00007efc33fd9b98  pop r8
00007efc33fd9b9a  pop rsi
00007efc33fd9b9b  pop rdi
00007efc33fd9b9c  pop rdx
00007efc33fd9b9d  pop rcx
00007efc33fd9b9e  pop rax
00007efc33fd9b9f  add rsp, 0x08
00007efc33fd9ba3  jmp 0x00007EFC33FD6352
00007efc33fd9ba8  sub rsp, 0x08
00007efc33fd9bac  push rax
00007efc33fd9bad  push rcx
00007efc33fd9bae  push rdx
00007efc33fd9baf  push rdi
00007efc33fd9bb0  push rsi
00007efc33fd9bb1  push r8
00007efc33fd9bb3  push r9
00007efc33fd9bb5  push r10
00007efc33fd9bb7  push r11
00007efc33fd9bb9  sub rsp, 0xF0
00007efc33fd9bc0  vmovaps [rsp], xmm0
00007efc33fd9bc5  vmovaps [rsp+0x10], xmm1
00007efc33fd9bcb  vmovaps [rsp+0x20], xmm2
00007efc33fd9bd1  vmovaps [rsp+0x30], xmm3
00007efc33fd9bd7  vmovaps [rsp+0x40], xmm4
00007efc33fd9bdd  vmovaps [rsp+0x50], xmm5
00007efc33fd9be3  vmovaps [rsp+0x60], xmm6
00007efc33fd9be9  vmovaps [rsp+0x70], xmm7
00007efc33fd9bef  vmovaps [rsp+0x80], xmm8
00007efc33fd9bf8  vmovaps [rsp+0x90], xmm9
00007efc33fd9c01  vmovaps [rsp+0xA0], xmm10
00007efc33fd9c0a  vmovaps [rsp+0xB0], xmm12
00007efc33fd9c13  vmovaps [rsp+0xC0], xmm13
00007efc33fd9c1c  vmovaps [rsp+0xD0], xmm14
00007efc33fd9c25  vmovaps [rsp+0xE0], xmm15
00007efc33fd9c2e  sub rsp, 0x30
00007efc33fd9c32  movaps [rsp], xmm11
00007efc33fd9c37  movaps [rsp+0x10], xmm10
00007efc33fd9c3d  movaps [rsp+0x20], xmm6
00007efc33fd9c42  lea rdi, [rsp]
00007efc33fd9c46  mov esi, 0x00
00007efc33fd9c4b  mov rax, 0x5D9448894530
00007efc33fd9c55  call rax
00007efc33fd9c57  movaps xmm11, [rsp]
00007efc33fd9c5c  add rsp, 0x30
00007efc33fd9c60  vmovaps xmm0, [rsp]
00007efc33fd9c65  vmovaps xmm1, [rsp+0x10]
00007efc33fd9c6b  vmovaps xmm2, [rsp+0x20]
00007efc33fd9c71  vmovaps xmm3, [rsp+0x30]
00007efc33fd9c77  vmovaps xmm4, [rsp+0x40]
00007efc33fd9c7d  vmovaps xmm5, [rsp+0x50]
00007efc33fd9c83  vmovaps xmm6, [rsp+0x60]
00007efc33fd9c89  vmovaps xmm7, [rsp+0x70]
00007efc33fd9c8f  vmovaps xmm8, [rsp+0x80]
00007efc33fd9c98  vmovaps xmm9, [rsp+0x90]
00007efc33fd9ca1  vmovaps xmm10, [rsp+0xA0]
00007efc33fd9caa  vmovaps xmm12, [rsp+0xB0]
00007efc33fd9cb3  vmovaps xmm13, [rsp+0xC0]
00007efc33fd9cbc  vmovaps xmm14, [rsp+0xD0]
00007efc33fd9cc5  vmovaps xmm15, [rsp+0xE0]
00007efc33fd9cce  add rsp, 0xF0
00007efc33fd9cd5  pop r11
00007efc33fd9cd7  pop r10
00007efc33fd9cd9  pop r9
00007efc33fd9cdb  pop r8
00007efc33fd9cdd  pop rsi
00007efc33fd9cde  pop rdi
00007efc33fd9cdf  pop rdx
00007efc33fd9ce0  pop rcx
00007efc33fd9ce1  pop rax
00007efc33fd9ce2  add rsp, 0x08
00007efc33fd9ce6  jmp 0x00007EFC33FD636D
00007efc33fd9ceb  sub rsp, 0x08
00007efc33fd9cef  push rax
00007efc33fd9cf0  push rcx
00007efc33fd9cf1  push rdx
00007efc33fd9cf2  push rdi
00007efc33fd9cf3  push rsi
00007efc33fd9cf4  push r8
00007efc33fd9cf6  push r9
00007efc33fd9cf8  push r10
00007efc33fd9cfa  push r11
00007efc33fd9cfc  sub rsp, 0xF0
00007efc33fd9d03  vmovaps [rsp], xmm0
00007efc33fd9d08  vmovaps [rsp+0x10], xmm1
00007efc33fd9d0e  vmovaps [rsp+0x20], xmm2
00007efc33fd9d14  vmovaps [rsp+0x30], xmm3
00007efc33fd9d1a  vmovaps [rsp+0x40], xmm4
00007efc33fd9d20  vmovaps [rsp+0x50], xmm5
00007efc33fd9d26  vmovaps [rsp+0x60], xmm6
00007efc33fd9d2c  vmovaps [rsp+0x70], xmm7
00007efc33fd9d32  vmovaps [rsp+0x80], xmm8
00007efc33fd9d3b  vmovaps [rsp+0x90], xmm9
00007efc33fd9d44  vmovaps [rsp+0xA0], xmm11
00007efc33fd9d4d  vmovaps [rsp+0xB0], xmm12
00007efc33fd9d56  vmovaps [rsp+0xC0], xmm13
00007efc33fd9d5f  vmovaps [rsp+0xD0], xmm14
00007efc33fd9d68  vmovaps [rsp+0xE0], xmm15
00007efc33fd9d71  sub rsp, 0x30
00007efc33fd9d75  movaps [rsp], xmm10
00007efc33fd9d7a  movaps [rsp+0x10], xmm14
00007efc33fd9d80  movaps [rsp+0x20], xmm4
00007efc33fd9d85  lea rdi, [rsp]
00007efc33fd9d89  mov esi, 0x00
00007efc33fd9d8e  mov rax, 0x5D9448894530
00007efc33fd9d98  call rax
00007efc33fd9d9a  movaps xmm10, [rsp]
00007efc33fd9d9f  add rsp, 0x30
00007efc33fd9da3  vmovaps xmm0, [rsp]
00007efc33fd9da8  vmovaps xmm1, [rsp+0x10]
00007efc33fd9dae  vmovaps xmm2, [rsp+0x20]
00007efc33fd9db4  vmovaps xmm3, [rsp+0x30]
00007efc33fd9dba  vmovaps xmm4, [rsp+0x40]
00007efc33fd9dc0  vmovaps xmm5, [rsp+0x50]
00007efc33fd9dc6  vmovaps xmm6, [rsp+0x60]
00007efc33fd9dcc  vmovaps xmm7, [rsp+0x70]
00007efc33fd9dd2  vmovaps xmm8, [rsp+0x80]
00007efc33fd9ddb  vmovaps xmm9, [rsp+0x90]
00007efc33fd9de4  vmovaps xmm11, [rsp+0xA0]
00007efc33fd9ded  vmovaps xmm12, [rsp+0xB0]
00007efc33fd9df6  vmovaps xmm13, [rsp+0xC0]
00007efc33fd9dff  vmovaps xmm14, [rsp+0xD0]
00007efc33fd9e08  vmovaps xmm15, [rsp+0xE0]
00007efc33fd9e11  add rsp, 0xF0
00007efc33fd9e18  pop r11
00007efc33fd9e1a  pop r10
00007efc33fd9e1c  pop r9
00007efc33fd9e1e  pop r8
00007efc33fd9e20  pop rsi
00007efc33fd9e21  pop rdi
00007efc33fd9e22  pop rdx
00007efc33fd9e23  pop rcx
00007efc33fd9e24  pop rax
00007efc33fd9e25  add rsp, 0x08
00007efc33fd9e29  jmp 0x00007EFC33FD6388
00007efc33fd9e2e  sub rsp, 0x08
00007efc33fd9e32  push rax
00007efc33fd9e33  push rcx
00007efc33fd9e34  push rdx
00007efc33fd9e35  push rdi
00007efc33fd9e36  push rsi
00007efc33fd9e37  push r8
00007efc33fd9e39  push r9
00007efc33fd9e3b  push r10
00007efc33fd9e3d  push r11
00007efc33fd9e3f  sub rsp, 0xF0
00007efc33fd9e46  vmovaps [rsp], xmm0
00007efc33fd9e4b  vmovaps [rsp+0x10], xmm1
00007efc33fd9e51  vmovaps [rsp+0x20], xmm2
00007efc33fd9e57  vmovaps [rsp+0x30], xmm3
00007efc33fd9e5d  vmovaps [rsp+0x40], xmm4
00007efc33fd9e63  vmovaps [rsp+0x50], xmm5
00007efc33fd9e69  vmovaps [rsp+0x60], xmm6
00007efc33fd9e6f  vmovaps [rsp+0x70], xmm7
00007efc33fd9e75  vmovaps [rsp+0x80], xmm9
00007efc33fd9e7e  vmovaps [rsp+0x90], xmm10
00007efc33fd9e87  vmovaps [rsp+0xA0], xmm11
00007efc33fd9e90  vmovaps [rsp+0xB0], xmm12
00007efc33fd9e99  vmovaps [rsp+0xC0], xmm13
00007efc33fd9ea2  vmovaps [rsp+0xD0], xmm14
00007efc33fd9eab  vmovaps [rsp+0xE0], xmm15
00007efc33fd9eb4  sub rsp, 0x30
00007efc33fd9eb8  movaps [rsp], xmm8
00007efc33fd9ebd  movaps [rsp+0x10], xmm1
00007efc33fd9ec2  movaps [rsp+0x20], xmm14
00007efc33fd9ec8  lea rdi, [rsp]
00007efc33fd9ecc  mov esi, 0x00
00007efc33fd9ed1  mov rax, 0x5D9448894530
00007efc33fd9edb  call rax
00007efc33fd9edd  movaps xmm8, [rsp]
00007efc33fd9ee2  add rsp, 0x30
00007efc33fd9ee6  vmovaps xmm0, [rsp]
00007efc33fd9eeb  vmovaps xmm1, [rsp+0x10]
00007efc33fd9ef1  vmovaps xmm2, [rsp+0x20]
00007efc33fd9ef7  vmovaps xmm3, [rsp+0x30]
00007efc33fd9efd  vmovaps xmm4, [rsp+0x40]
00007efc33fd9f03  vmovaps xmm5, [rsp+0x50]
00007efc33fd9f09  vmovaps xmm6, [rsp+0x60]
00007efc33fd9f0f  vmovaps xmm7, [rsp+0x70]
00007efc33fd9f15  vmovaps xmm9, [rsp+0x80]
00007efc33fd9f1e  vmovaps xmm10, [rsp+0x90]
00007efc33fd9f27  vmovaps xmm11, [rsp+0xA0]
00007efc33fd9f30  vmovaps xmm12, [rsp+0xB0]
00007efc33fd9f39  vmovaps xmm13, [rsp+0xC0]
00007efc33fd9f42  vmovaps xmm14, [rsp+0xD0]
00007efc33fd9f4b  vmovaps xmm15, [rsp+0xE0]
00007efc33fd9f54  add rsp, 0xF0
00007efc33fd9f5b  pop r11
00007efc33fd9f5d  pop r10
00007efc33fd9f5f  pop r9
00007efc33fd9f61  pop r8
00007efc33fd9f63  pop rsi
00007efc33fd9f64  pop rdi
00007efc33fd9f65  pop rdx
00007efc33fd9f66  pop rcx
00007efc33fd9f67  pop rax
00007efc33fd9f68  add rsp, 0x08
00007efc33fd9f6c  jmp 0x00007EFC33FD63AE
00007efc33fd9f71  sub rsp, 0x08
00007efc33fd9f75  push rax
00007efc33fd9f76  push rcx
00007efc33fd9f77  push rdx
00007efc33fd9f78  push rdi
00007efc33fd9f79  push rsi
00007efc33fd9f7a  push r8
00007efc33fd9f7c  push r9
00007efc33fd9f7e  push r10
00007efc33fd9f80  push r11
00007efc33fd9f82  sub rsp, 0xF0
00007efc33fd9f89  vmovaps [rsp], xmm0
00007efc33fd9f8e  vmovaps [rsp+0x10], xmm1
00007efc33fd9f94  vmovaps [rsp+0x20], xmm2
00007efc33fd9f9a  vmovaps [rsp+0x30], xmm3
00007efc33fd9fa0  vmovaps [rsp+0x40], xmm4
00007efc33fd9fa6  vmovaps [rsp+0x50], xmm5
00007efc33fd9fac  vmovaps [rsp+0x60], xmm7
00007efc33fd9fb2  vmovaps [rsp+0x70], xmm8
00007efc33fd9fb8  vmovaps [rsp+0x80], xmm9
00007efc33fd9fc1  vmovaps [rsp+0x90], xmm10
00007efc33fd9fca  vmovaps [rsp+0xA0], xmm11
00007efc33fd9fd3  vmovaps [rsp+0xB0], xmm12
00007efc33fd9fdc  vmovaps [rsp+0xC0], xmm13
00007efc33fd9fe5  vmovaps [rsp+0xD0], xmm14
00007efc33fd9fee  vmovaps [rsp+0xE0], xmm15
00007efc33fd9ff7  sub rsp, 0x30
00007efc33fd9ffb  movaps [rsp], xmm6
00007efc33fd9fff  movaps [rsp+0x10], xmm1
00007efc33fda004  movaps [rsp+0x20], xmm14
00007efc33fda00a  lea rdi, [rsp]
00007efc33fda00e  mov esi, 0x00
00007efc33fda013  mov rax, 0x5D9448894530
00007efc33fda01d  call rax
00007efc33fda01f  movaps xmm6, [rsp]
00007efc33fda023  add rsp, 0x30
00007efc33fda027  vmovaps xmm0, [rsp]
00007efc33fda02c  vmovaps xmm1, [rsp+0x10]
00007efc33fda032  vmovaps xmm2, [rsp+0x20]
00007efc33fda038  vmovaps xmm3, [rsp+0x30]
00007efc33fda03e  vmovaps xmm4, [rsp+0x40]
00007efc33fda044  vmovaps xmm5, [rsp+0x50]
00007efc33fda04a  vmovaps xmm7, [rsp+0x60]
00007efc33fda050  vmovaps xmm8, [rsp+0x70]
00007efc33fda056  vmovaps xmm9, [rsp+0x80]
00007efc33fda05f  vmovaps xmm10, [rsp+0x90]
00007efc33fda068  vmovaps xmm11, [rsp+0xA0]
00007efc33fda071  vmovaps xmm12, [rsp+0xB0]
00007efc33fda07a  vmovaps xmm13, [rsp+0xC0]
00007efc33fda083  vmovaps xmm14, [rsp+0xD0]
00007efc33fda08c  vmovaps xmm15, [rsp+0xE0]
00007efc33fda095  add rsp, 0xF0
00007efc33fda09c  pop r11
00007efc33fda09e  pop r10
00007efc33fda0a0  pop r9
00007efc33fda0a2  pop r8
00007efc33fda0a4  pop rsi
00007efc33fda0a5  pop rdi
00007efc33fda0a6  pop rdx
00007efc33fda0a7  pop rcx
00007efc33fda0a8  pop rax
00007efc33fda0a9  add rsp, 0x08
00007efc33fda0ad  jmp 0x00007EFC33FD63DA
00007efc33fda0b2  sub rsp, 0x08
00007efc33fda0b6  push rax
00007efc33fda0b7  push rcx
00007efc33fda0b8  push rdx
00007efc33fda0b9  push rdi
00007efc33fda0ba  push rsi
00007efc33fda0bb  push r8
00007efc33fda0bd  push r9
00007efc33fda0bf  push r10
00007efc33fda0c1  push r11
00007efc33fda0c3  sub rsp, 0xF0
00007efc33fda0ca  vmovaps [rsp], xmm0
00007efc33fda0cf  vmovaps [rsp+0x10], xmm1
00007efc33fda0d5  vmovaps [rsp+0x20], xmm2
00007efc33fda0db  vmovaps [rsp+0x30], xmm3
00007efc33fda0e1  vmovaps [rsp+0x40], xmm4
00007efc33fda0e7  vmovaps [rsp+0x50], xmm5
00007efc33fda0ed  vmovaps [rsp+0x60], xmm6
00007efc33fda0f3  vmovaps [rsp+0x70], xmm7
00007efc33fda0f9  vmovaps [rsp+0x80], xmm8
00007efc33fda102  vmovaps [rsp+0x90], xmm9
00007efc33fda10b  vmovaps [rsp+0xA0], xmm10
00007efc33fda114  vmovaps [rsp+0xB0], xmm11
00007efc33fda11d  vmovaps [rsp+0xC0], xmm12
00007efc33fda126  vmovaps [rsp+0xD0], xmm13
00007efc33fda12f  vmovaps [rsp+0xE0], xmm15
00007efc33fda138  sub rsp, 0x30
00007efc33fda13c  movaps [rsp], xmm14
00007efc33fda141  movaps [rsp+0x10], xmm12
00007efc33fda147  movaps [rsp+0x20], xmm1
00007efc33fda14c  lea rdi, [rsp]
00007efc33fda150  mov esi, 0x00
00007efc33fda155  mov rax, 0x5D9448894530
00007efc33fda15f  call rax
00007efc33fda161  movaps xmm14, [rsp]
00007efc33fda166  add rsp, 0x30
00007efc33fda16a  vmovaps xmm0, [rsp]
00007efc33fda16f  vmovaps xmm1, [rsp+0x10]
00007efc33fda175  vmovaps xmm2, [rsp+0x20]
00007efc33fda17b  vmovaps xmm3, [rsp+0x30]
00007efc33fda181  vmovaps xmm4, [rsp+0x40]
00007efc33fda187  vmovaps xmm5, [rsp+0x50]
00007efc33fda18d  vmovaps xmm6, [rsp+0x60]
00007efc33fda193  vmovaps xmm7, [rsp+0x70]
00007efc33fda199  vmovaps xmm8, [rsp+0x80]
00007efc33fda1a2  vmovaps xmm9, [rsp+0x90]
00007efc33fda1ab  vmovaps xmm10, [rsp+0xA0]
00007efc33fda1b4  vmovaps xmm11, [rsp+0xB0]
00007efc33fda1bd  vmovaps xmm12, [rsp+0xC0]
00007efc33fda1c6  vmovaps xmm13, [rsp+0xD0]
00007efc33fda1cf  vmovaps xmm15, [rsp+0xE0]
00007efc33fda1d8  add rsp, 0xF0
00007efc33fda1df  pop r11
00007efc33fda1e1  pop r10
00007efc33fda1e3  pop r9
00007efc33fda1e5  pop r8
00007efc33fda1e7  pop rsi
00007efc33fda1e8  pop rdi
00007efc33fda1e9  pop rdx
00007efc33fda1ea  pop rcx
00007efc33fda1eb  pop rax
00007efc33fda1ec  add rsp, 0x08
00007efc33fda1f0  jmp 0x00007EFC33FD6400
00007efc33fda1f5  sub rsp, 0x08
00007efc33fda1f9  push rax
00007efc33fda1fa  push rcx
00007efc33fda1fb  push rdx
00007efc33fda1fc  push rdi
00007efc33fda1fd  push rsi
00007efc33fda1fe  push r8
00007efc33fda200  push r9
00007efc33fda202  push r10
00007efc33fda204  push r11
00007efc33fda206  sub rsp, 0xF0
00007efc33fda20d  vmovaps [rsp], xmm0
00007efc33fda212  vmovaps [rsp+0x10], xmm2
00007efc33fda218  vmovaps [rsp+0x20], xmm3
00007efc33fda21e  vmovaps [rsp+0x30], xmm4
00007efc33fda224  vmovaps [rsp+0x40], xmm5
00007efc33fda22a  vmovaps [rsp+0x50], xmm6
00007efc33fda230  vmovaps [rsp+0x60], xmm7
00007efc33fda236  vmovaps [rsp+0x70], xmm8
00007efc33fda23c  vmovaps [rsp+0x80], xmm9
00007efc33fda245  vmovaps [rsp+0x90], xmm10
00007efc33fda24e  vmovaps [rsp+0xA0], xmm11
00007efc33fda257  vmovaps [rsp+0xB0], xmm12
00007efc33fda260  vmovaps [rsp+0xC0], xmm13
00007efc33fda269  vmovaps [rsp+0xD0], xmm14
00007efc33fda272  vmovaps [rsp+0xE0], xmm15
00007efc33fda27b  sub rsp, 0x30
00007efc33fda27f  movaps [rsp], xmm1
00007efc33fda283  movaps [rsp+0x10], xmm13
00007efc33fda289  movaps [rsp+0x20], xmm9
00007efc33fda28f  lea rdi, [rsp]
00007efc33fda293  mov esi, 0x00
00007efc33fda298  mov rax, 0x5D9448894530
00007efc33fda2a2  call rax
00007efc33fda2a4  movaps xmm1, [rsp]
00007efc33fda2a8  add rsp, 0x30
00007efc33fda2ac  vmovaps xmm0, [rsp]
00007efc33fda2b1  vmovaps xmm2, [rsp+0x10]
00007efc33fda2b7  vmovaps xmm3, [rsp+0x20]
00007efc33fda2bd  vmovaps xmm4, [rsp+0x30]
00007efc33fda2c3  vmovaps xmm5, [rsp+0x40]
00007efc33fda2c9  vmovaps xmm6, [rsp+0x50]
00007efc33fda2cf  vmovaps xmm7, [rsp+0x60]
00007efc33fda2d5  vmovaps xmm8, [rsp+0x70]
00007efc33fda2db  vmovaps xmm9, [rsp+0x80]
00007efc33fda2e4  vmovaps xmm10, [rsp+0x90]
00007efc33fda2ed  vmovaps xmm11, [rsp+0xA0]
00007efc33fda2f6  vmovaps xmm12, [rsp+0xB0]
00007efc33fda2ff  vmovaps xmm13, [rsp+0xC0]
00007efc33fda308  vmovaps xmm14, [rsp+0xD0]
00007efc33fda311  vmovaps xmm15, [rsp+0xE0]
00007efc33fda31a  add rsp, 0xF0
00007efc33fda321  pop r11
00007efc33fda323  pop r10
00007efc33fda325  pop r9
00007efc33fda327  pop r8
00007efc33fda329  pop rsi
00007efc33fda32a  pop rdi
00007efc33fda32b  pop rdx
00007efc33fda32c  pop rcx
00007efc33fda32d  pop rax
00007efc33fda32e  add rsp, 0x08
00007efc33fda332  jmp 0x00007EFC33FD641A
00007efc33fda337  sub rsp, 0x08
00007efc33fda33b  push rax
00007efc33fda33c  push rcx
00007efc33fda33d  push rdx
00007efc33fda33e  push rdi
00007efc33fda33f  push rsi
00007efc33fda340  push r8
00007efc33fda342  push r9
00007efc33fda344  push r10
00007efc33fda346  push r11
00007efc33fda348  sub rsp, 0xF0
00007efc33fda34f  vmovaps [rsp], xmm0
00007efc33fda354  vmovaps [rsp+0x10], xmm1
00007efc33fda35a  vmovaps [rsp+0x20], xmm2
00007efc33fda360  vmovaps [rsp+0x30], xmm3
00007efc33fda366  vmovaps [rsp+0x40], xmm4
00007efc33fda36c  vmovaps [rsp+0x50], xmm5
00007efc33fda372  vmovaps [rsp+0x60], xmm6
00007efc33fda378  vmovaps [rsp+0x70], xmm7
00007efc33fda37e  vmovaps [rsp+0x80], xmm8
00007efc33fda387  vmovaps [rsp+0x90], xmm9
00007efc33fda390  vmovaps [rsp+0xA0], xmm10
00007efc33fda399  vmovaps [rsp+0xB0], xmm11
00007efc33fda3a2  vmovaps [rsp+0xC0], xmm13
00007efc33fda3ab  vmovaps [rsp+0xD0], xmm14
00007efc33fda3b4  vmovaps [rsp+0xE0], xmm15
00007efc33fda3bd  sub rsp, 0x30
00007efc33fda3c1  movaps [rsp], xmm12
00007efc33fda3c6  movaps [rsp+0x10], xmm7
00007efc33fda3cb  movaps [rsp+0x20], xmm13
00007efc33fda3d1  lea rdi, [rsp]
00007efc33fda3d5  mov esi, 0x00
00007efc33fda3da  mov rax, 0x5D9448894530
00007efc33fda3e4  call rax
00007efc33fda3e6  movaps xmm12, [rsp]
00007efc33fda3eb  add rsp, 0x30
00007efc33fda3ef  vmovaps xmm0, [rsp]
00007efc33fda3f4  vmovaps xmm1, [rsp+0x10]
00007efc33fda3fa  vmovaps xmm2, [rsp+0x20]
00007efc33fda400  vmovaps xmm3, [rsp+0x30]
00007efc33fda406  vmovaps xmm4, [rsp+0x40]
00007efc33fda40c  vmovaps xmm5, [rsp+0x50]
00007efc33fda412  vmovaps xmm6, [rsp+0x60]
00007efc33fda418  vmovaps xmm7, [rsp+0x70]
00007efc33fda41e  vmovaps xmm8, [rsp+0x80]
00007efc33fda427  vmovaps xmm9, [rsp+0x90]
00007efc33fda430  vmovaps xmm10, [rsp+0xA0]
00007efc33fda439  vmovaps xmm11, [rsp+0xB0]
00007efc33fda442  vmovaps xmm13, [rsp+0xC0]
00007efc33fda44b  vmovaps xmm14, [rsp+0xD0]
00007efc33fda454  vmovaps xmm15, [rsp+0xE0]
00007efc33fda45d  add rsp, 0xF0
00007efc33fda464  pop r11
00007efc33fda466  pop r10
00007efc33fda468  pop r9
00007efc33fda46a  pop r8
00007efc33fda46c  pop rsi
00007efc33fda46d  pop rdi
00007efc33fda46e  pop rdx
00007efc33fda46f  pop rcx
00007efc33fda470  pop rax
00007efc33fda471  add rsp, 0x08
00007efc33fda475  jmp 0x00007EFC33FD6441
00007efc33fda47a  sub rsp, 0x08
00007efc33fda47e  push rax
00007efc33fda47f  push rcx
00007efc33fda480  push rdx
00007efc33fda481  push rdi
00007efc33fda482  push rsi
00007efc33fda483  push r8
00007efc33fda485  push r9
00007efc33fda487  push r10
00007efc33fda489  push r11
00007efc33fda48b  sub rsp, 0xF0
00007efc33fda492  vmovaps [rsp], xmm0
00007efc33fda497  vmovaps [rsp+0x10], xmm1
00007efc33fda49d  vmovaps [rsp+0x20], xmm2
00007efc33fda4a3  vmovaps [rsp+0x30], xmm3
00007efc33fda4a9  vmovaps [rsp+0x40], xmm4
00007efc33fda4af  vmovaps [rsp+0x50], xmm5
00007efc33fda4b5  vmovaps [rsp+0x60], xmm6
00007efc33fda4bb  vmovaps [rsp+0x70], xmm7
00007efc33fda4c1  vmovaps [rsp+0x80], xmm8
00007efc33fda4ca  vmovaps [rsp+0x90], xmm9
00007efc33fda4d3  vmovaps [rsp+0xA0], xmm10
00007efc33fda4dc  vmovaps [rsp+0xB0], xmm11
00007efc33fda4e5  vmovaps [rsp+0xC0], xmm12
00007efc33fda4ee  vmovaps [rsp+0xD0], xmm14
00007efc33fda4f7  vmovaps [rsp+0xE0], xmm15
00007efc33fda500  sub rsp, 0x30
00007efc33fda504  movaps [rsp], xmm13
00007efc33fda509  movaps [rsp+0x10], xmm15
00007efc33fda50f  movaps [rsp+0x20], xmm8
00007efc33fda515  lea rdi, [rsp]
00007efc33fda519  mov esi, 0x00
00007efc33fda51e  mov rax, 0x5D9448894530
00007efc33fda528  call rax
00007efc33fda52a  movaps xmm13, [rsp]
00007efc33fda52f  add rsp, 0x30
00007efc33fda533  vmovaps xmm0, [rsp]
00007efc33fda538  vmovaps xmm1, [rsp+0x10]
00007efc33fda53e  vmovaps xmm2, [rsp+0x20]
00007efc33fda544  vmovaps xmm3, [rsp+0x30]
00007efc33fda54a  vmovaps xmm4, [rsp+0x40]
00007efc33fda550  vmovaps xmm5, [rsp+0x50]
00007efc33fda556  vmovaps xmm6, [rsp+0x60]
00007efc33fda55c  vmovaps xmm7, [rsp+0x70]
00007efc33fda562  vmovaps xmm8, [rsp+0x80]
00007efc33fda56b  vmovaps xmm9, [rsp+0x90]
00007efc33fda574  vmovaps xmm10, [rsp+0xA0]
00007efc33fda57d  vmovaps xmm11, [rsp+0xB0]
00007efc33fda586  vmovaps xmm12, [rsp+0xC0]
00007efc33fda58f  vmovaps xmm14, [rsp+0xD0]
00007efc33fda598  vmovaps xmm15, [rsp+0xE0]
00007efc33fda5a1  add rsp, 0xF0
00007efc33fda5a8  pop r11
00007efc33fda5aa  pop r10
00007efc33fda5ac  pop r9
00007efc33fda5ae  pop r8
00007efc33fda5b0  pop rsi
00007efc33fda5b1  pop rdi
00007efc33fda5b2  pop rdx
00007efc33fda5b3  pop rcx
00007efc33fda5b4  pop rax
00007efc33fda5b5  add rsp, 0x08
00007efc33fda5b9  jmp 0x00007EFC33FD645C
00007efc33fda5be  sub rsp, 0x08
00007efc33fda5c2  push rax
00007efc33fda5c3  push rcx
00007efc33fda5c4  push rdx
00007efc33fda5c5  push rdi
00007efc33fda5c6  push rsi
00007efc33fda5c7  push r8
00007efc33fda5c9  push r9
00007efc33fda5cb  push r10
00007efc33fda5cd  push r11
00007efc33fda5cf  sub rsp, 0xF0
00007efc33fda5d6  vmovaps [rsp], xmm0
00007efc33fda5db  vmovaps [rsp+0x10], xmm1
00007efc33fda5e1  vmovaps [rsp+0x20], xmm2
00007efc33fda5e7  vmovaps [rsp+0x30], xmm3
00007efc33fda5ed  vmovaps [rsp+0x40], xmm4
00007efc33fda5f3  vmovaps [rsp+0x50], xmm5
00007efc33fda5f9  vmovaps [rsp+0x60], xmm6
00007efc33fda5ff  vmovaps [rsp+0x70], xmm7
00007efc33fda605  vmovaps [rsp+0x80], xmm9
00007efc33fda60e  vmovaps [rsp+0x90], xmm10
00007efc33fda617  vmovaps [rsp+0xA0], xmm11
00007efc33fda620  vmovaps [rsp+0xB0], xmm12
00007efc33fda629  vmovaps [rsp+0xC0], xmm13
00007efc33fda632  vmovaps [rsp+0xD0], xmm14
00007efc33fda63b  vmovaps [rsp+0xE0], xmm15
00007efc33fda644  sub rsp, 0x30
00007efc33fda648  movaps [rsp], xmm8
00007efc33fda64d  movaps [rsp+0x10], xmm15
00007efc33fda653  movaps [rsp+0x20], xmm9
00007efc33fda659  lea rdi, [rsp]
00007efc33fda65d  mov esi, 0x00
00007efc33fda662  mov rax, 0x5D9448894530
00007efc33fda66c  call rax
00007efc33fda66e  movaps xmm8, [rsp]
00007efc33fda673  add rsp, 0x30
00007efc33fda677  vmovaps xmm0, [rsp]
00007efc33fda67c  vmovaps xmm1, [rsp+0x10]
00007efc33fda682  vmovaps xmm2, [rsp+0x20]
00007efc33fda688  vmovaps xmm3, [rsp+0x30]
00007efc33fda68e  vmovaps xmm4, [rsp+0x40]
00007efc33fda694  vmovaps xmm5, [rsp+0x50]
00007efc33fda69a  vmovaps xmm6, [rsp+0x60]
00007efc33fda6a0  vmovaps xmm7, [rsp+0x70]
00007efc33fda6a6  vmovaps xmm9, [rsp+0x80]
00007efc33fda6af  vmovaps xmm10, [rsp+0x90]
00007efc33fda6b8  vmovaps xmm11, [rsp+0xA0]
00007efc33fda6c1  vmovaps xmm12, [rsp+0xB0]
00007efc33fda6ca  vmovaps xmm13, [rsp+0xC0]
00007efc33fda6d3  vmovaps xmm14, [rsp+0xD0]
00007efc33fda6dc  vmovaps xmm15, [rsp+0xE0]
00007efc33fda6e5  add rsp, 0xF0
00007efc33fda6ec  pop r11
00007efc33fda6ee  pop r10
00007efc33fda6f0  pop r9
00007efc33fda6f2  pop r8
00007efc33fda6f4  pop rsi
00007efc33fda6f5  pop rdi
00007efc33fda6f6  pop rdx
00007efc33fda6f7  pop rcx
00007efc33fda6f8  pop rax
00007efc33fda6f9  add rsp, 0x08
00007efc33fda6fd  jmp 0x00007EFC33FD648A
00007efc33fda702  sub rsp, 0x08
00007efc33fda706  push rax
00007efc33fda707  push rcx
00007efc33fda708  push rdx
00007efc33fda709  push rdi
00007efc33fda70a  push rsi
00007efc33fda70b  push r8
00007efc33fda70d  push r9
00007efc33fda70f  push r10
00007efc33fda711  push r11
00007efc33fda713  sub rsp, 0xF0
00007efc33fda71a  vmovaps [rsp], xmm0
00007efc33fda71f  vmovaps [rsp+0x10], xmm1
00007efc33fda725  vmovaps [rsp+0x20], xmm2
00007efc33fda72b  vmovaps [rsp+0x30], xmm3
00007efc33fda731  vmovaps [rsp+0x40], xmm4
00007efc33fda737  vmovaps [rsp+0x50], xmm5
00007efc33fda73d  vmovaps [rsp+0x60], xmm6
00007efc33fda743  vmovaps [rsp+0x70], xmm7
00007efc33fda749  vmovaps [rsp+0x80], xmm8
00007efc33fda752  vmovaps [rsp+0x90], xmm9
00007efc33fda75b  vmovaps [rsp+0xA0], xmm10
00007efc33fda764  vmovaps [rsp+0xB0], xmm11
00007efc33fda76d  vmovaps [rsp+0xC0], xmm12
00007efc33fda776  vmovaps [rsp+0xD0], xmm13
00007efc33fda77f  vmovaps [rsp+0xE0], xmm14
00007efc33fda788  sub rsp, 0x30
00007efc33fda78c  movaps [rsp], xmm15
00007efc33fda791  movaps [rsp+0x10], xmm11
00007efc33fda797  movaps [rsp+0x20], xmm6
00007efc33fda79c  lea rdi, [rsp]
00007efc33fda7a0  mov esi, 0x00
00007efc33fda7a5  mov rax, 0x5D9448894530
00007efc33fda7af  call rax
00007efc33fda7b1  movaps xmm15, [rsp]
00007efc33fda7b6  add rsp, 0x30
00007efc33fda7ba  vmovaps xmm0, [rsp]
00007efc33fda7bf  vmovaps xmm1, [rsp+0x10]
00007efc33fda7c5  vmovaps xmm2, [rsp+0x20]
00007efc33fda7cb  vmovaps xmm3, [rsp+0x30]
00007efc33fda7d1  vmovaps xmm4, [rsp+0x40]
00007efc33fda7d7  vmovaps xmm5, [rsp+0x50]
00007efc33fda7dd  vmovaps xmm6, [rsp+0x60]
00007efc33fda7e3  vmovaps xmm7, [rsp+0x70]
00007efc33fda7e9  vmovaps xmm8, [rsp+0x80]
00007efc33fda7f2  vmovaps xmm9, [rsp+0x90]
00007efc33fda7fb  vmovaps xmm10, [rsp+0xA0]
00007efc33fda804  vmovaps xmm11, [rsp+0xB0]
00007efc33fda80d  vmovaps xmm12, [rsp+0xC0]
00007efc33fda816  vmovaps xmm13, [rsp+0xD0]
00007efc33fda81f  vmovaps xmm14, [rsp+0xE0]
00007efc33fda828  add rsp, 0xF0
00007efc33fda82f  pop r11
00007efc33fda831  pop r10
00007efc33fda833  pop r9
00007efc33fda835  pop r8
00007efc33fda837  pop rsi
00007efc33fda838  pop rdi
00007efc33fda839  pop rdx
00007efc33fda83a  pop rcx
00007efc33fda83b  pop rax
00007efc33fda83c  add rsp, 0x08
00007efc33fda840  jmp 0x00007EFC33FD64A5
00007efc33fda845  sub rsp, 0x08
00007efc33fda849  push rax
00007efc33fda84a  push rcx
00007efc33fda84b  push rdx
00007efc33fda84c  push rdi
00007efc33fda84d  push rsi
00007efc33fda84e  push r8
00007efc33fda850  push r9
00007efc33fda852  push r10
00007efc33fda854  push r11
00007efc33fda856  sub rsp, 0xF0
00007efc33fda85d  vmovaps [rsp], xmm0
00007efc33fda862  vmovaps [rsp+0x10], xmm1
00007efc33fda868  vmovaps [rsp+0x20], xmm2
00007efc33fda86e  vmovaps [rsp+0x30], xmm3
00007efc33fda874  vmovaps [rsp+0x40], xmm4
00007efc33fda87a  vmovaps [rsp+0x50], xmm5
00007efc33fda880  vmovaps [rsp+0x60], xmm6
00007efc33fda886  vmovaps [rsp+0x70], xmm8
00007efc33fda88c  vmovaps [rsp+0x80], xmm9
00007efc33fda895  vmovaps [rsp+0x90], xmm10
00007efc33fda89e  vmovaps [rsp+0xA0], xmm11
00007efc33fda8a7  vmovaps [rsp+0xB0], xmm12
00007efc33fda8b0  vmovaps [rsp+0xC0], xmm13
00007efc33fda8b9  vmovaps [rsp+0xD0], xmm14
00007efc33fda8c2  vmovaps [rsp+0xE0], xmm15
00007efc33fda8cb  sub rsp, 0x30
00007efc33fda8cf  movaps [rsp], xmm7
00007efc33fda8d3  movaps [rsp+0x10], xmm11
00007efc33fda8d9  movaps [rsp+0x20], xmm9
00007efc33fda8df  lea rdi, [rsp]
00007efc33fda8e3  mov esi, 0x00
00007efc33fda8e8  mov rax, 0x5D9448894530
00007efc33fda8f2  call rax
00007efc33fda8f4  movaps xmm7, [rsp]
00007efc33fda8f8  add rsp, 0x30
00007efc33fda8fc  vmovaps xmm0, [rsp]
00007efc33fda901  vmovaps xmm1, [rsp+0x10]
00007efc33fda907  vmovaps xmm2, [rsp+0x20]
00007efc33fda90d  vmovaps xmm3, [rsp+0x30]
00007efc33fda913  vmovaps xmm4, [rsp+0x40]
00007efc33fda919  vmovaps xmm5, [rsp+0x50]
00007efc33fda91f  vmovaps xmm6, [rsp+0x60]
00007efc33fda925  vmovaps xmm8, [rsp+0x70]
00007efc33fda92b  vmovaps xmm9, [rsp+0x80]
00007efc33fda934  vmovaps xmm10, [rsp+0x90]
00007efc33fda93d  vmovaps xmm11, [rsp+0xA0]
00007efc33fda946  vmovaps xmm12, [rsp+0xB0]
00007efc33fda94f  vmovaps xmm13, [rsp+0xC0]
00007efc33fda958  vmovaps xmm14, [rsp+0xD0]
00007efc33fda961  vmovaps xmm15, [rsp+0xE0]
00007efc33fda96a  add rsp, 0xF0
00007efc33fda971  pop r11
00007efc33fda973  pop r10
00007efc33fda975  pop r9
00007efc33fda977  pop r8
00007efc33fda979  pop rsi
00007efc33fda97a  pop rdi
00007efc33fda97b  pop rdx
00007efc33fda97c  pop rcx
00007efc33fda97d  pop rax
00007efc33fda97e  add rsp, 0x08
00007efc33fda982  jmp 0x00007EFC33FD64D2
00007efc33fda987  sub rsp, 0x08
00007efc33fda98b  push rax
00007efc33fda98c  push rcx
00007efc33fda98d  push rdx
00007efc33fda98e  push rdi
00007efc33fda98f  push rsi
00007efc33fda990  push r8
00007efc33fda992  push r9
00007efc33fda994  push r10
00007efc33fda996  push r11
00007efc33fda998  sub rsp, 0xF0
00007efc33fda99f  vmovaps [rsp], xmm0
00007efc33fda9a4  vmovaps [rsp+0x10], xmm1
00007efc33fda9aa  vmovaps [rsp+0x20], xmm2
00007efc33fda9b0  vmovaps [rsp+0x30], xmm3
00007efc33fda9b6  vmovaps [rsp+0x40], xmm4
00007efc33fda9bc  vmovaps [rsp+0x50], xmm5
00007efc33fda9c2  vmovaps [rsp+0x60], xmm6
00007efc33fda9c8  vmovaps [rsp+0x70], xmm7
00007efc33fda9ce  vmovaps [rsp+0x80], xmm8
00007efc33fda9d7  vmovaps [rsp+0x90], xmm9
00007efc33fda9e0  vmovaps [rsp+0xA0], xmm10
00007efc33fda9e9  vmovaps [rsp+0xB0], xmm12
00007efc33fda9f2  vmovaps [rsp+0xC0], xmm13
00007efc33fda9fb  vmovaps [rsp+0xD0], xmm14
00007efc33fdaa04  vmovaps [rsp+0xE0], xmm15
00007efc33fdaa0d  sub rsp, 0x30
00007efc33fdaa11  movaps [rsp], xmm11
00007efc33fdaa16  movaps [rsp+0x10], xmm10
00007efc33fdaa1c  movaps [rsp+0x20], xmm14
00007efc33fdaa22  lea rdi, [rsp]
00007efc33fdaa26  mov esi, 0x00
00007efc33fdaa2b  mov rax, 0x5D9448894530
00007efc33fdaa35  call rax
00007efc33fdaa37  movaps xmm11, [rsp]
00007efc33fdaa3c  add rsp, 0x30
00007efc33fdaa40  vmovaps xmm0, [rsp]
00007efc33fdaa45  vmovaps xmm1, [rsp+0x10]
00007efc33fdaa4b  vmovaps xmm2, [rsp+0x20]
00007efc33fdaa51  vmovaps xmm3, [rsp+0x30]
00007efc33fdaa57  vmovaps xmm4, [rsp+0x40]
00007efc33fdaa5d  vmovaps xmm5, [rsp+0x50]
00007efc33fdaa63  vmovaps xmm6, [rsp+0x60]
00007efc33fdaa69  vmovaps xmm7, [rsp+0x70]
00007efc33fdaa6f  vmovaps xmm8, [rsp+0x80]
00007efc33fdaa78  vmovaps xmm9, [rsp+0x90]
00007efc33fdaa81  vmovaps xmm10, [rsp+0xA0]
00007efc33fdaa8a  vmovaps xmm12, [rsp+0xB0]
00007efc33fdaa93  vmovaps xmm13, [rsp+0xC0]
00007efc33fdaa9c  vmovaps xmm14, [rsp+0xD0]
00007efc33fdaaa5  vmovaps xmm15, [rsp+0xE0]
00007efc33fdaaae  add rsp, 0xF0
00007efc33fdaab5  pop r11
00007efc33fdaab7  pop r10
00007efc33fdaab9  pop r9
00007efc33fdaabb  pop r8
00007efc33fdaabd  pop rsi
00007efc33fdaabe  pop rdi
00007efc33fdaabf  pop rdx
00007efc33fdaac0  pop rcx
00007efc33fdaac1  pop rax
00007efc33fdaac2  add rsp, 0x08
00007efc33fdaac6  jmp 0x00007EFC33FD64ED
00007efc33fdaacb  call 0x00007EFC33EE45A0
00007efc33fdaad0  jmp 0x00007EFC33FD64F7
00007efc33fdaad5  sub rsp, 0x08
00007efc33fdaad9  push rax
00007efc33fdaada  push rcx
00007efc33fdaadb  push rdx
00007efc33fdaadc  push rdi
00007efc33fdaadd  push rsi
00007efc33fdaade  push r8
00007efc33fdaae0  push r9
00007efc33fdaae2  push r10
00007efc33fdaae4  push r11
00007efc33fdaae6  sub rsp, 0xF0
00007efc33fdaaed  vmovaps [rsp], xmm0
00007efc33fdaaf2  vmovaps [rsp+0x10], xmm1
00007efc33fdaaf8  vmovaps [rsp+0x20], xmm2
00007efc33fdaafe  vmovaps [rsp+0x30], xmm3
00007efc33fdab04  vmovaps [rsp+0x40], xmm4
00007efc33fdab0a  vmovaps [rsp+0x50], xmm5
00007efc33fdab10  vmovaps [rsp+0x60], xmm6
00007efc33fdab16  vmovaps [rsp+0x70], xmm7
00007efc33fdab1c  vmovaps [rsp+0x80], xmm8
00007efc33fdab25  vmovaps [rsp+0x90], xmm9
00007efc33fdab2e  vmovaps [rsp+0xA0], xmm11
00007efc33fdab37  vmovaps [rsp+0xB0], xmm12
00007efc33fdab40  vmovaps [rsp+0xC0], xmm13
00007efc33fdab49  vmovaps [rsp+0xD0], xmm14
00007efc33fdab52  vmovaps [rsp+0xE0], xmm15
00007efc33fdab5b  sub rsp, 0x30
00007efc33fdab5f  movaps [rsp], xmm10
00007efc33fdab64  movaps [rsp+0x10], xmm1
00007efc33fdab69  movaps [rsp+0x20], xmm12
00007efc33fdab6f  lea rdi, [rsp]
00007efc33fdab73  mov esi, 0x00
00007efc33fdab78  mov rax, 0x5D9448894530
00007efc33fdab82  call rax
00007efc33fdab84  movaps xmm10, [rsp]
00007efc33fdab89  add rsp, 0x30
00007efc33fdab8d  vmovaps xmm0, [rsp]
00007efc33fdab92  vmovaps xmm1, [rsp+0x10]
00007efc33fdab98  vmovaps xmm2, [rsp+0x20]
00007efc33fdab9e  vmovaps xmm3, [rsp+0x30]
00007efc33fdaba4  vmovaps xmm4, [rsp+0x40]
00007efc33fdabaa  vmovaps xmm5, [rsp+0x50]
00007efc33fdabb0  vmovaps xmm6, [rsp+0x60]
00007efc33fdabb6  vmovaps xmm7, [rsp+0x70]
00007efc33fdabbc  vmovaps xmm8, [rsp+0x80]
00007efc33fdabc5  vmovaps xmm9, [rsp+0x90]
00007efc33fdabce  vmovaps xmm11, [rsp+0xA0]
00007efc33fdabd7  vmovaps xmm12, [rsp+0xB0]
00007efc33fdabe0  vmovaps xmm13, [rsp+0xC0]
00007efc33fdabe9  vmovaps xmm14, [rsp+0xD0]
00007efc33fdabf2  vmovaps xmm15, [rsp+0xE0]
00007efc33fdabfb  add rsp, 0xF0
00007efc33fdac02  pop r11
00007efc33fdac04  pop r10
00007efc33fdac06  pop r9
00007efc33fdac08  pop r8
00007efc33fdac0a  pop rsi
00007efc33fdac0b  pop rdi
00007efc33fdac0c  pop rdx
00007efc33fdac0d  pop rcx
00007efc33fdac0e  pop rax
00007efc33fdac0f  add rsp, 0x08
00007efc33fdac13  jmp 0x00007EFC33FD651A
00007efc33fdac18  sub rsp, 0x08
00007efc33fdac1c  push rax
00007efc33fdac1d  push rcx
00007efc33fdac1e  push rdx
00007efc33fdac1f  push rdi
00007efc33fdac20  push rsi
00007efc33fdac21  push r8
00007efc33fdac23  push r9
00007efc33fdac25  push r10
00007efc33fdac27  push r11
00007efc33fdac29  sub rsp, 0xF0
00007efc33fdac30  vmovaps [rsp], xmm0
00007efc33fdac35  vmovaps [rsp+0x10], xmm1
00007efc33fdac3b  vmovaps [rsp+0x20], xmm2
00007efc33fdac41  vmovaps [rsp+0x30], xmm3
00007efc33fdac47  vmovaps [rsp+0x40], xmm4
00007efc33fdac4d  vmovaps [rsp+0x50], xmm5
00007efc33fdac53  vmovaps [rsp+0x60], xmm6
00007efc33fdac59  vmovaps [rsp+0x70], xmm7
00007efc33fdac5f  vmovaps [rsp+0x80], xmm8
00007efc33fdac68  vmovaps [rsp+0x90], xmm9
00007efc33fdac71  vmovaps [rsp+0xA0], xmm10
00007efc33fdac7a  vmovaps [rsp+0xB0], xmm11
00007efc33fdac83  vmovaps [rsp+0xC0], xmm13
00007efc33fdac8c  vmovaps [rsp+0xD0], xmm14
00007efc33fdac95  vmovaps [rsp+0xE0], xmm15
00007efc33fdac9e  sub rsp, 0x30
00007efc33fdaca2  movaps [rsp], xmm12
00007efc33fdaca7  movaps [rsp+0x10], xmm14
00007efc33fdacad  movaps [rsp+0x20], xmm1
00007efc33fdacb2  lea rdi, [rsp]
00007efc33fdacb6  mov esi, 0x00
00007efc33fdacbb  mov rax, 0x5D9448894530
00007efc33fdacc5  call rax
00007efc33fdacc7  movaps xmm12, [rsp]
00007efc33fdaccc  add rsp, 0x30
00007efc33fdacd0  vmovaps xmm0, [rsp]
00007efc33fdacd5  vmovaps xmm1, [rsp+0x10]
00007efc33fdacdb  vmovaps xmm2, [rsp+0x20]
00007efc33fdace1  vmovaps xmm3, [rsp+0x30]
00007efc33fdace7  vmovaps xmm4, [rsp+0x40]
00007efc33fdaced  vmovaps xmm5, [rsp+0x50]
00007efc33fdacf3  vmovaps xmm6, [rsp+0x60]
00007efc33fdacf9  vmovaps xmm7, [rsp+0x70]
00007efc33fdacff  vmovaps xmm8, [rsp+0x80]
00007efc33fdad08  vmovaps xmm9, [rsp+0x90]
00007efc33fdad11  vmovaps xmm10, [rsp+0xA0]
00007efc33fdad1a  vmovaps xmm11, [rsp+0xB0]
00007efc33fdad23  vmovaps xmm13, [rsp+0xC0]
00007efc33fdad2c  vmovaps xmm14, [rsp+0xD0]
00007efc33fdad35  vmovaps xmm15, [rsp+0xE0]
00007efc33fdad3e  add rsp, 0xF0
00007efc33fdad45  pop r11
00007efc33fdad47  pop r10
00007efc33fdad49  pop r9
00007efc33fdad4b  pop r8
00007efc33fdad4d  pop rsi
00007efc33fdad4e  pop rdi
00007efc33fdad4f  pop rdx
00007efc33fdad50  pop rcx
00007efc33fdad51  pop rax
00007efc33fdad52  add rsp, 0x08
00007efc33fdad56  jmp 0x00007EFC33FD6549
00007efc33fdad5b  sub rsp, 0x08
00007efc33fdad5f  push rax
00007efc33fdad60  push rcx
00007efc33fdad61  push rdx
00007efc33fdad62  push rdi
00007efc33fdad63  push rsi
00007efc33fdad64  push r8
00007efc33fdad66  push r9
00007efc33fdad68  push r10
00007efc33fdad6a  push r11
00007efc33fdad6c  sub rsp, 0xF0
00007efc33fdad73  vmovaps [rsp], xmm0
00007efc33fdad78  vmovaps [rsp+0x10], xmm1
00007efc33fdad7e  vmovaps [rsp+0x20], xmm2
00007efc33fdad84  vmovaps [rsp+0x30], xmm3
00007efc33fdad8a  vmovaps [rsp+0x40], xmm4
00007efc33fdad90  vmovaps [rsp+0x50], xmm5
00007efc33fdad96  vmovaps [rsp+0x60], xmm6
00007efc33fdad9c  vmovaps [rsp+0x70], xmm7
00007efc33fdada2  vmovaps [rsp+0x80], xmm8
00007efc33fdadab  vmovaps [rsp+0x90], xmm9
00007efc33fdadb4  vmovaps [rsp+0xA0], xmm10
00007efc33fdadbd  vmovaps [rsp+0xB0], xmm11
00007efc33fdadc6  vmovaps [rsp+0xC0], xmm12
00007efc33fdadcf  vmovaps [rsp+0xD0], xmm13
00007efc33fdadd8  vmovaps [rsp+0xE0], xmm15
00007efc33fdade1  sub rsp, 0x30
00007efc33fdade5  movaps [rsp], xmm14
00007efc33fdadea  movaps [rsp+0x10], xmm9
00007efc33fdadf0  movaps [rsp+0x20], xmm1
00007efc33fdadf5  lea rdi, [rsp]
00007efc33fdadf9  mov esi, 0x00
00007efc33fdadfe  mov rax, 0x5D9448894530
00007efc33fdae08  call rax
00007efc33fdae0a  movaps xmm14, [rsp]
00007efc33fdae0f  add rsp, 0x30
00007efc33fdae13  vmovaps xmm0, [rsp]
00007efc33fdae18  vmovaps xmm1, [rsp+0x10]
00007efc33fdae1e  vmovaps xmm2, [rsp+0x20]
00007efc33fdae24  vmovaps xmm3, [rsp+0x30]
00007efc33fdae2a  vmovaps xmm4, [rsp+0x40]
00007efc33fdae30  vmovaps xmm5, [rsp+0x50]
00007efc33fdae36  vmovaps xmm6, [rsp+0x60]
00007efc33fdae3c  vmovaps xmm7, [rsp+0x70]
00007efc33fdae42  vmovaps xmm8, [rsp+0x80]
00007efc33fdae4b  vmovaps xmm9, [rsp+0x90]
00007efc33fdae54  vmovaps xmm10, [rsp+0xA0]
00007efc33fdae5d  vmovaps xmm11, [rsp+0xB0]
00007efc33fdae66  vmovaps xmm12, [rsp+0xC0]
00007efc33fdae6f  vmovaps xmm13, [rsp+0xD0]
00007efc33fdae78  vmovaps xmm15, [rsp+0xE0]
00007efc33fdae81  add rsp, 0xF0
00007efc33fdae88  pop r11
00007efc33fdae8a  pop r10
00007efc33fdae8c  pop r9
00007efc33fdae8e  pop r8
00007efc33fdae90  pop rsi
00007efc33fdae91  pop rdi
00007efc33fdae92  pop rdx
00007efc33fdae93  pop rcx
00007efc33fdae94  pop rax
00007efc33fdae95  add rsp, 0x08
00007efc33fdae99  jmp 0x00007EFC33FD6578
00007efc33fdae9e  sub rsp, 0x08
00007efc33fdaea2  push rax
00007efc33fdaea3  push rcx
00007efc33fdaea4  push rdx
00007efc33fdaea5  push rdi
00007efc33fdaea6  push rsi
00007efc33fdaea7  push r8
00007efc33fdaea9  push r9
00007efc33fdaeab  push r10
00007efc33fdaead  push r11
00007efc33fdaeaf  sub rsp, 0xF0
00007efc33fdaeb6  vmovaps [rsp], xmm0
00007efc33fdaebb  vmovaps [rsp+0x10], xmm2
00007efc33fdaec1  vmovaps [rsp+0x20], xmm3
00007efc33fdaec7  vmovaps [rsp+0x30], xmm4
00007efc33fdaecd  vmovaps [rsp+0x40], xmm5
00007efc33fdaed3  vmovaps [rsp+0x50], xmm6
00007efc33fdaed9  vmovaps [rsp+0x60], xmm7
00007efc33fdaedf  vmovaps [rsp+0x70], xmm8
00007efc33fdaee5  vmovaps [rsp+0x80], xmm9
00007efc33fdaeee  vmovaps [rsp+0x90], xmm10
00007efc33fdaef7  vmovaps [rsp+0xA0], xmm11
00007efc33fdaf00  vmovaps [rsp+0xB0], xmm12
00007efc33fdaf09  vmovaps [rsp+0xC0], xmm13
00007efc33fdaf12  vmovaps [rsp+0xD0], xmm14
00007efc33fdaf1b  vmovaps [rsp+0xE0], xmm15
00007efc33fdaf24  sub rsp, 0x30
00007efc33fdaf28  movaps [rsp], xmm1
00007efc33fdaf2c  movaps [rsp+0x10], xmm13
00007efc33fdaf32  movaps [rsp+0x20], xmm8
00007efc33fdaf38  lea rdi, [rsp]
00007efc33fdaf3c  mov esi, 0x00
00007efc33fdaf41  mov rax, 0x5D9448894530
00007efc33fdaf4b  call rax
00007efc33fdaf4d  movaps xmm1, [rsp]
00007efc33fdaf51  add rsp, 0x30
00007efc33fdaf55  vmovaps xmm0, [rsp]
00007efc33fdaf5a  vmovaps xmm2, [rsp+0x10]
00007efc33fdaf60  vmovaps xmm3, [rsp+0x20]
00007efc33fdaf66  vmovaps xmm4, [rsp+0x30]
00007efc33fdaf6c  vmovaps xmm5, [rsp+0x40]
00007efc33fdaf72  vmovaps xmm6, [rsp+0x50]
00007efc33fdaf78  vmovaps xmm7, [rsp+0x60]
00007efc33fdaf7e  vmovaps xmm8, [rsp+0x70]
00007efc33fdaf84  vmovaps xmm9, [rsp+0x80]
00007efc33fdaf8d  vmovaps xmm10, [rsp+0x90]
00007efc33fdaf96  vmovaps xmm11, [rsp+0xA0]
00007efc33fdaf9f  vmovaps xmm12, [rsp+0xB0]
00007efc33fdafa8  vmovaps xmm13, [rsp+0xC0]
00007efc33fdafb1  vmovaps xmm14, [rsp+0xD0]
00007efc33fdafba  vmovaps xmm15, [rsp+0xE0]
00007efc33fdafc3  add rsp, 0xF0
00007efc33fdafca  pop r11
00007efc33fdafcc  pop r10
00007efc33fdafce  pop r9
00007efc33fdafd0  pop r8
00007efc33fdafd2  pop rsi
00007efc33fdafd3  pop rdi
00007efc33fdafd4  pop rdx
00007efc33fdafd5  pop rcx
00007efc33fdafd6  pop rax
00007efc33fdafd7  add rsp, 0x08
00007efc33fdafdb  jmp 0x00007EFC33FD659A
00007efc33fdafe0  call 0x00007EFC33E0C260
00007efc33fdafe5  jmp 0x00007EFC33FD65A8
00007efc33fdafea  call 0x00007EFC33EDE950
00007efc33fdafef  jmp 0x00007EFC33FD65B2
00007efc33fdaff4  sub rsp, 0x08
00007efc33fdaff8  push rax
00007efc33fdaff9  push rcx
00007efc33fdaffa  push rdx
00007efc33fdaffb  push rdi
00007efc33fdaffc  push rsi
00007efc33fdaffd  push r8
00007efc33fdafff  push r9
00007efc33fdb001  push r10
00007efc33fdb003  push r11
00007efc33fdb005  sub rsp, 0xF0
00007efc33fdb00c  vmovaps [rsp], xmm0
00007efc33fdb011  vmovaps [rsp+0x10], xmm1
00007efc33fdb017  vmovaps [rsp+0x20], xmm2
00007efc33fdb01d  vmovaps [rsp+0x30], xmm3
00007efc33fdb023  vmovaps [rsp+0x40], xmm4
00007efc33fdb029  vmovaps [rsp+0x50], xmm5
00007efc33fdb02f  vmovaps [rsp+0x60], xmm6
00007efc33fdb035  vmovaps [rsp+0x70], xmm7
00007efc33fdb03b  vmovaps [rsp+0x80], xmm9
00007efc33fdb044  vmovaps [rsp+0x90], xmm10
00007efc33fdb04d  vmovaps [rsp+0xA0], xmm11
00007efc33fdb056  vmovaps [rsp+0xB0], xmm12
00007efc33fdb05f  vmovaps [rsp+0xC0], xmm13
00007efc33fdb068  vmovaps [rsp+0xD0], xmm14
00007efc33fdb071  vmovaps [rsp+0xE0], xmm15
00007efc33fdb07a  sub rsp, 0x30
00007efc33fdb07e  movaps [rsp], xmm8
00007efc33fdb083  movaps [rsp+0x10], xmm15
00007efc33fdb089  movaps [rsp+0x20], xmm7
00007efc33fdb08e  lea rdi, [rsp]
00007efc33fdb092  mov esi, 0x00
00007efc33fdb097  mov rax, 0x5D9448894530
00007efc33fdb0a1  call rax
00007efc33fdb0a3  movaps xmm8, [rsp]
00007efc33fdb0a8  add rsp, 0x30
00007efc33fdb0ac  vmovaps xmm0, [rsp]
00007efc33fdb0b1  vmovaps xmm1, [rsp+0x10]
00007efc33fdb0b7  vmovaps xmm2, [rsp+0x20]
00007efc33fdb0bd  vmovaps xmm3, [rsp+0x30]
00007efc33fdb0c3  vmovaps xmm4, [rsp+0x40]
00007efc33fdb0c9  vmovaps xmm5, [rsp+0x50]
00007efc33fdb0cf  vmovaps xmm6, [rsp+0x60]
00007efc33fdb0d5  vmovaps xmm7, [rsp+0x70]
00007efc33fdb0db  vmovaps xmm9, [rsp+0x80]
00007efc33fdb0e4  vmovaps xmm10, [rsp+0x90]
00007efc33fdb0ed  vmovaps xmm11, [rsp+0xA0]
00007efc33fdb0f6  vmovaps xmm12, [rsp+0xB0]
00007efc33fdb0ff  vmovaps xmm13, [rsp+0xC0]
00007efc33fdb108  vmovaps xmm14, [rsp+0xD0]
00007efc33fdb111  vmovaps xmm15, [rsp+0xE0]
00007efc33fdb11a  add rsp, 0xF0
00007efc33fdb121  pop r11
00007efc33fdb123  pop r10
00007efc33fdb125  pop r9
00007efc33fdb127  pop r8
00007efc33fdb129  pop rsi
00007efc33fdb12a  pop rdi
00007efc33fdb12b  pop rdx
00007efc33fdb12c  pop rcx
00007efc33fdb12d  pop rax
00007efc33fdb12e  add rsp, 0x08
00007efc33fdb132  jmp 0x00007EFC33FD65D4
00007efc33fdb137  sub rsp, 0x08
00007efc33fdb13b  push rax
00007efc33fdb13c  push rcx
00007efc33fdb13d  push rdx
00007efc33fdb13e  push rdi
00007efc33fdb13f  push rsi
00007efc33fdb140  push r8
00007efc33fdb142  push r9
00007efc33fdb144  push r10
00007efc33fdb146  push r11
00007efc33fdb148  sub rsp, 0xF0
00007efc33fdb14f  vmovaps [rsp], xmm0
00007efc33fdb154  vmovaps [rsp+0x10], xmm1
00007efc33fdb15a  vmovaps [rsp+0x20], xmm2
00007efc33fdb160  vmovaps [rsp+0x30], xmm3
00007efc33fdb166  vmovaps [rsp+0x40], xmm4
00007efc33fdb16c  vmovaps [rsp+0x50], xmm5
00007efc33fdb172  vmovaps [rsp+0x60], xmm6
00007efc33fdb178  vmovaps [rsp+0x70], xmm8
00007efc33fdb17e  vmovaps [rsp+0x80], xmm9
00007efc33fdb187  vmovaps [rsp+0x90], xmm10
00007efc33fdb190  vmovaps [rsp+0xA0], xmm11
00007efc33fdb199  vmovaps [rsp+0xB0], xmm12
00007efc33fdb1a2  vmovaps [rsp+0xC0], xmm13
00007efc33fdb1ab  vmovaps [rsp+0xD0], xmm14
00007efc33fdb1b4  vmovaps [rsp+0xE0], xmm15
00007efc33fdb1bd  sub rsp, 0x30
00007efc33fdb1c1  movaps [rsp], xmm7
00007efc33fdb1c5  movaps [rsp+0x10], xmm9
00007efc33fdb1cb  movaps [rsp+0x20], xmm15
00007efc33fdb1d1  lea rdi, [rsp]
00007efc33fdb1d5  mov esi, 0x00
00007efc33fdb1da  mov rax, 0x5D9448894530
00007efc33fdb1e4  call rax
00007efc33fdb1e6  movaps xmm7, [rsp]
00007efc33fdb1ea  add rsp, 0x30
00007efc33fdb1ee  vmovaps xmm0, [rsp]
00007efc33fdb1f3  vmovaps xmm1, [rsp+0x10]
00007efc33fdb1f9  vmovaps xmm2, [rsp+0x20]
00007efc33fdb1ff  vmovaps xmm3, [rsp+0x30]
00007efc33fdb205  vmovaps xmm4, [rsp+0x40]
00007efc33fdb20b  vmovaps xmm5, [rsp+0x50]
00007efc33fdb211  vmovaps xmm6, [rsp+0x60]
00007efc33fdb217  vmovaps xmm8, [rsp+0x70]
00007efc33fdb21d  vmovaps xmm9, [rsp+0x80]
00007efc33fdb226  vmovaps xmm10, [rsp+0x90]
00007efc33fdb22f  vmovaps xmm11, [rsp+0xA0]
00007efc33fdb238  vmovaps xmm12, [rsp+0xB0]
00007efc33fdb241  vmovaps xmm13, [rsp+0xC0]
00007efc33fdb24a  vmovaps xmm14, [rsp+0xD0]
00007efc33fdb253  vmovaps xmm15, [rsp+0xE0]
00007efc33fdb25c  add rsp, 0xF0
00007efc33fdb263  pop r11
00007efc33fdb265  pop r10
00007efc33fdb267  pop r9
00007efc33fdb269  pop r8
00007efc33fdb26b  pop rsi
00007efc33fdb26c  pop rdi
00007efc33fdb26d  pop rdx
00007efc33fdb26e  pop rcx
00007efc33fdb26f  pop rax
00007efc33fdb270  add rsp, 0x08
00007efc33fdb274  jmp 0x00007EFC33FD6601
00007efc33fdb279  sub rsp, 0x08
00007efc33fdb27d  push rax
00007efc33fdb27e  push rcx
00007efc33fdb27f  push rdx
00007efc33fdb280  push rdi
00007efc33fdb281  push rsi
00007efc33fdb282  push r8
00007efc33fdb284  push r9
00007efc33fdb286  push r10
00007efc33fdb288  push r11
00007efc33fdb28a  sub rsp, 0xF0
00007efc33fdb291  vmovaps [rsp], xmm0
00007efc33fdb296  vmovaps [rsp+0x10], xmm1
00007efc33fdb29c  vmovaps [rsp+0x20], xmm2
00007efc33fdb2a2  vmovaps [rsp+0x30], xmm3
00007efc33fdb2a8  vmovaps [rsp+0x40], xmm4
00007efc33fdb2ae  vmovaps [rsp+0x50], xmm5
00007efc33fdb2b4  vmovaps [rsp+0x60], xmm6
00007efc33fdb2ba  vmovaps [rsp+0x70], xmm7
00007efc33fdb2c0  vmovaps [rsp+0x80], xmm8
00007efc33fdb2c9  vmovaps [rsp+0x90], xmm10
00007efc33fdb2d2  vmovaps [rsp+0xA0], xmm11
00007efc33fdb2db  vmovaps [rsp+0xB0], xmm12
00007efc33fdb2e4  vmovaps [rsp+0xC0], xmm13
00007efc33fdb2ed  vmovaps [rsp+0xD0], xmm14
00007efc33fdb2f6  vmovaps [rsp+0xE0], xmm15
00007efc33fdb2ff  sub rsp, 0x30
00007efc33fdb303  movaps [rsp], xmm9
00007efc33fdb308  movaps [rsp+0x10], xmm13
00007efc33fdb30e  movaps [rsp+0x20], xmm15
00007efc33fdb314  lea rdi, [rsp]
00007efc33fdb318  mov esi, 0x00
00007efc33fdb31d  mov rax, 0x5D9448894530
00007efc33fdb327  call rax
00007efc33fdb329  movaps xmm9, [rsp]
00007efc33fdb32e  add rsp, 0x30
00007efc33fdb332  vmovaps xmm0, [rsp]
00007efc33fdb337  vmovaps xmm1, [rsp+0x10]
00007efc33fdb33d  vmovaps xmm2, [rsp+0x20]
00007efc33fdb343  vmovaps xmm3, [rsp+0x30]
00007efc33fdb349  vmovaps xmm4, [rsp+0x40]
00007efc33fdb34f  vmovaps xmm5, [rsp+0x50]
00007efc33fdb355  vmovaps xmm6, [rsp+0x60]
00007efc33fdb35b  vmovaps xmm7, [rsp+0x70]
00007efc33fdb361  vmovaps xmm8, [rsp+0x80]
00007efc33fdb36a  vmovaps xmm10, [rsp+0x90]
00007efc33fdb373  vmovaps xmm11, [rsp+0xA0]
00007efc33fdb37c  vmovaps xmm12, [rsp+0xB0]
00007efc33fdb385  vmovaps xmm13, [rsp+0xC0]
00007efc33fdb38e  vmovaps xmm14, [rsp+0xD0]
00007efc33fdb397  vmovaps xmm15, [rsp+0xE0]
00007efc33fdb3a0  add rsp, 0xF0
00007efc33fdb3a7  pop r11
00007efc33fdb3a9  pop r10
00007efc33fdb3ab  pop r9
00007efc33fdb3ad  pop r8
00007efc33fdb3af  pop rsi
00007efc33fdb3b0  pop rdi
00007efc33fdb3b1  pop rdx
00007efc33fdb3b2  pop rcx
00007efc33fdb3b3  pop rax
00007efc33fdb3b4  add rsp, 0x08
00007efc33fdb3b8  jmp 0x00007EFC33FD662F
00007efc33fdb3bd  sub rsp, 0x08
00007efc33fdb3c1  push rax
00007efc33fdb3c2  push rcx
00007efc33fdb3c3  push rdx
00007efc33fdb3c4  push rdi
00007efc33fdb3c5  push rsi
00007efc33fdb3c6  push r8
00007efc33fdb3c8  push r9
00007efc33fdb3ca  push r10
00007efc33fdb3cc  push r11
00007efc33fdb3ce  sub rsp, 0xF0
00007efc33fdb3d5  vmovaps [rsp], xmm0
00007efc33fdb3da  vmovaps [rsp+0x10], xmm1
00007efc33fdb3e0  vmovaps [rsp+0x20], xmm2
00007efc33fdb3e6  vmovaps [rsp+0x30], xmm3
00007efc33fdb3ec  vmovaps [rsp+0x40], xmm4
00007efc33fdb3f2  vmovaps [rsp+0x50], xmm5
00007efc33fdb3f8  vmovaps [rsp+0x60], xmm6
00007efc33fdb3fe  vmovaps [rsp+0x70], xmm7
00007efc33fdb404  vmovaps [rsp+0x80], xmm8
00007efc33fdb40d  vmovaps [rsp+0x90], xmm9
00007efc33fdb416  vmovaps [rsp+0xA0], xmm10
00007efc33fdb41f  vmovaps [rsp+0xB0], xmm11
00007efc33fdb428  vmovaps [rsp+0xC0], xmm12
00007efc33fdb431  vmovaps [rsp+0xD0], xmm13
00007efc33fdb43a  vmovaps [rsp+0xE0], xmm14
00007efc33fdb443  sub rsp, 0x30
00007efc33fdb447  movaps [rsp], xmm15
00007efc33fdb44c  movaps [rsp+0x10], xmm11
00007efc33fdb452  movaps [rsp+0x20], xmm12
00007efc33fdb458  lea rdi, [rsp]
00007efc33fdb45c  mov esi, 0x00
00007efc33fdb461  mov rax, 0x5D9448894530
00007efc33fdb46b  call rax
00007efc33fdb46d  movaps xmm15, [rsp]
00007efc33fdb472  add rsp, 0x30
00007efc33fdb476  vmovaps xmm0, [rsp]
00007efc33fdb47b  vmovaps xmm1, [rsp+0x10]
00007efc33fdb481  vmovaps xmm2, [rsp+0x20]
00007efc33fdb487  vmovaps xmm3, [rsp+0x30]
00007efc33fdb48d  vmovaps xmm4, [rsp+0x40]
00007efc33fdb493  vmovaps xmm5, [rsp+0x50]
00007efc33fdb499  vmovaps xmm6, [rsp+0x60]
00007efc33fdb49f  vmovaps xmm7, [rsp+0x70]
00007efc33fdb4a5  vmovaps xmm8, [rsp+0x80]
00007efc33fdb4ae  vmovaps xmm9, [rsp+0x90]
00007efc33fdb4b7  vmovaps xmm10, [rsp+0xA0]
00007efc33fdb4c0  vmovaps xmm11, [rsp+0xB0]
00007efc33fdb4c9  vmovaps xmm12, [rsp+0xC0]
00007efc33fdb4d2  vmovaps xmm13, [rsp+0xD0]
00007efc33fdb4db  vmovaps xmm14, [rsp+0xE0]
00007efc33fdb4e4  add rsp, 0xF0
00007efc33fdb4eb  pop r11
00007efc33fdb4ed  pop r10
00007efc33fdb4ef  pop r9
00007efc33fdb4f1  pop r8
00007efc33fdb4f3  pop rsi
00007efc33fdb4f4  pop rdi
00007efc33fdb4f5  pop rdx
00007efc33fdb4f6  pop rcx
00007efc33fdb4f7  pop rax
00007efc33fdb4f8  add rsp, 0x08
00007efc33fdb4fc  jmp 0x00007EFC33FD664A
00007efc33fdb501  sub rsp, 0x08
00007efc33fdb505  push rax
00007efc33fdb506  push rcx
00007efc33fdb507  push rdx
00007efc33fdb508  push rdi
00007efc33fdb509  push rsi
00007efc33fdb50a  push r8
00007efc33fdb50c  push r9
00007efc33fdb50e  push r10
00007efc33fdb510  push r11
00007efc33fdb512  sub rsp, 0xF0
00007efc33fdb519  vmovaps [rsp], xmm0
00007efc33fdb51e  vmovaps [rsp+0x10], xmm1
00007efc33fdb524  vmovaps [rsp+0x20], xmm2
00007efc33fdb52a  vmovaps [rsp+0x30], xmm3
00007efc33fdb530  vmovaps [rsp+0x40], xmm4
00007efc33fdb536  vmovaps [rsp+0x50], xmm5
00007efc33fdb53c  vmovaps [rsp+0x60], xmm6
00007efc33fdb542  vmovaps [rsp+0x70], xmm7
00007efc33fdb548  vmovaps [rsp+0x80], xmm8
00007efc33fdb551  vmovaps [rsp+0x90], xmm9
00007efc33fdb55a  vmovaps [rsp+0xA0], xmm10
00007efc33fdb563  vmovaps [rsp+0xB0], xmm11
00007efc33fdb56c  vmovaps [rsp+0xC0], xmm12
00007efc33fdb575  vmovaps [rsp+0xD0], xmm14
00007efc33fdb57e  vmovaps [rsp+0xE0], xmm15
00007efc33fdb587  sub rsp, 0x30
00007efc33fdb58b  movaps [rsp], xmm13
00007efc33fdb590  movaps [rsp+0x10], xmm10
00007efc33fdb596  movaps [rsp+0x20], xmm14
00007efc33fdb59c  lea rdi, [rsp]
00007efc33fdb5a0  mov esi, 0x00
00007efc33fdb5a5  mov rax, 0x5D9448894530
00007efc33fdb5af  call rax
00007efc33fdb5b1  movaps xmm13, [rsp]
00007efc33fdb5b6  add rsp, 0x30
00007efc33fdb5ba  vmovaps xmm0, [rsp]
00007efc33fdb5bf  vmovaps xmm1, [rsp+0x10]
00007efc33fdb5c5  vmovaps xmm2, [rsp+0x20]
00007efc33fdb5cb  vmovaps xmm3, [rsp+0x30]
00007efc33fdb5d1  vmovaps xmm4, [rsp+0x40]
00007efc33fdb5d7  vmovaps xmm5, [rsp+0x50]
00007efc33fdb5dd  vmovaps xmm6, [rsp+0x60]
00007efc33fdb5e3  vmovaps xmm7, [rsp+0x70]
00007efc33fdb5e9  vmovaps xmm8, [rsp+0x80]
00007efc33fdb5f2  vmovaps xmm9, [rsp+0x90]
00007efc33fdb5fb  vmovaps xmm10, [rsp+0xA0]
00007efc33fdb604  vmovaps xmm11, [rsp+0xB0]
00007efc33fdb60d  vmovaps xmm12, [rsp+0xC0]
00007efc33fdb616  vmovaps xmm14, [rsp+0xD0]
00007efc33fdb61f  vmovaps xmm15, [rsp+0xE0]
00007efc33fdb628  add rsp, 0xF0
00007efc33fdb62f  pop r11
00007efc33fdb631  pop r10
00007efc33fdb633  pop r9
00007efc33fdb635  pop r8
00007efc33fdb637  pop rsi
00007efc33fdb638  pop rdi
00007efc33fdb639  pop rdx
00007efc33fdb63a  pop rcx
00007efc33fdb63b  pop rax
00007efc33fdb63c  add rsp, 0x08
00007efc33fdb640  jmp 0x00007EFC33FD666D
00007efc33fdb645  sub rsp, 0x08
00007efc33fdb649  push rax
00007efc33fdb64a  push rcx
00007efc33fdb64b  push rdx
00007efc33fdb64c  push rdi
00007efc33fdb64d  push rsi
00007efc33fdb64e  push r8
00007efc33fdb650  push r9
00007efc33fdb652  push r10
00007efc33fdb654  push r11
00007efc33fdb656  sub rsp, 0xF0
00007efc33fdb65d  vmovaps [rsp], xmm0
00007efc33fdb662  vmovaps [rsp+0x10], xmm1
00007efc33fdb668  vmovaps [rsp+0x20], xmm2
00007efc33fdb66e  vmovaps [rsp+0x30], xmm3
00007efc33fdb674  vmovaps [rsp+0x40], xmm4
00007efc33fdb67a  vmovaps [rsp+0x50], xmm5
00007efc33fdb680  vmovaps [rsp+0x60], xmm6
00007efc33fdb686  vmovaps [rsp+0x70], xmm7
00007efc33fdb68c  vmovaps [rsp+0x80], xmm8
00007efc33fdb695  vmovaps [rsp+0x90], xmm9
00007efc33fdb69e  vmovaps [rsp+0xA0], xmm10
00007efc33fdb6a7  vmovaps [rsp+0xB0], xmm11
00007efc33fdb6b0  vmovaps [rsp+0xC0], xmm12
00007efc33fdb6b9  vmovaps [rsp+0xD0], xmm13
00007efc33fdb6c2  vmovaps [rsp+0xE0], xmm15
00007efc33fdb6cb  sub rsp, 0x30
00007efc33fdb6cf  movaps [rsp], xmm14
00007efc33fdb6d4  movaps [rsp+0x10], xmm1
00007efc33fdb6d9  movaps [rsp+0x20], xmm7
00007efc33fdb6de  lea rdi, [rsp]
00007efc33fdb6e2  mov esi, 0x00
00007efc33fdb6e7  mov rax, 0x5D9448894530
00007efc33fdb6f1  call rax
00007efc33fdb6f3  movaps xmm14, [rsp]
00007efc33fdb6f8  add rsp, 0x30
00007efc33fdb6fc  vmovaps xmm0, [rsp]
00007efc33fdb701  vmovaps xmm1, [rsp+0x10]
00007efc33fdb707  vmovaps xmm2, [rsp+0x20]
00007efc33fdb70d  vmovaps xmm3, [rsp+0x30]
00007efc33fdb713  vmovaps xmm4, [rsp+0x40]
00007efc33fdb719  vmovaps xmm5, [rsp+0x50]
00007efc33fdb71f  vmovaps xmm6, [rsp+0x60]
00007efc33fdb725  vmovaps xmm7, [rsp+0x70]
00007efc33fdb72b  vmovaps xmm8, [rsp+0x80]
00007efc33fdb734  vmovaps xmm9, [rsp+0x90]
00007efc33fdb73d  vmovaps xmm10, [rsp+0xA0]
00007efc33fdb746  vmovaps xmm11, [rsp+0xB0]
00007efc33fdb74f  vmovaps xmm12, [rsp+0xC0]
00007efc33fdb758  vmovaps xmm13, [rsp+0xD0]
00007efc33fdb761  vmovaps xmm15, [rsp+0xE0]
00007efc33fdb76a  add rsp, 0xF0
00007efc33fdb771  pop r11
00007efc33fdb773  pop r10
00007efc33fdb775  pop r9
00007efc33fdb777  pop r8
00007efc33fdb779  pop rsi
00007efc33fdb77a  pop rdi
00007efc33fdb77b  pop rdx
00007efc33fdb77c  pop rcx
00007efc33fdb77d  pop rax
00007efc33fdb77e  add rsp, 0x08
00007efc33fdb782  jmp 0x00007EFC33FD6690
00007efc33fdb787  sub rsp, 0x08
00007efc33fdb78b  push rax
00007efc33fdb78c  push rcx
00007efc33fdb78d  push rdx
00007efc33fdb78e  push rdi
00007efc33fdb78f  push rsi
00007efc33fdb790  push r8
00007efc33fdb792  push r9
00007efc33fdb794  push r10
00007efc33fdb796  push r11
00007efc33fdb798  sub rsp, 0xF0
00007efc33fdb79f  vmovaps [rsp], xmm0
00007efc33fdb7a4  vmovaps [rsp+0x10], xmm2
00007efc33fdb7aa  vmovaps [rsp+0x20], xmm3
00007efc33fdb7b0  vmovaps [rsp+0x30], xmm4
00007efc33fdb7b6  vmovaps [rsp+0x40], xmm5
00007efc33fdb7bc  vmovaps [rsp+0x50], xmm6
00007efc33fdb7c2  vmovaps [rsp+0x60], xmm7
00007efc33fdb7c8  vmovaps [rsp+0x70], xmm8
00007efc33fdb7ce  vmovaps [rsp+0x80], xmm9
00007efc33fdb7d7  vmovaps [rsp+0x90], xmm10
00007efc33fdb7e0  vmovaps [rsp+0xA0], xmm11
00007efc33fdb7e9  vmovaps [rsp+0xB0], xmm12
00007efc33fdb7f2  vmovaps [rsp+0xC0], xmm13
00007efc33fdb7fb  vmovaps [rsp+0xD0], xmm14
00007efc33fdb804  vmovaps [rsp+0xE0], xmm15
00007efc33fdb80d  sub rsp, 0x30
00007efc33fdb811  movaps [rsp], xmm1
00007efc33fdb815  movaps [rsp+0x10], xmm8
00007efc33fdb81b  movaps [rsp+0x20], xmm9
00007efc33fdb821  lea rdi, [rsp]
00007efc33fdb825  mov esi, 0x00
00007efc33fdb82a  mov rax, 0x5D9448894530
00007efc33fdb834  call rax
00007efc33fdb836  movaps xmm1, [rsp]
00007efc33fdb83a  add rsp, 0x30
00007efc33fdb83e  vmovaps xmm0, [rsp]
00007efc33fdb843  vmovaps xmm2, [rsp+0x10]
00007efc33fdb849  vmovaps xmm3, [rsp+0x20]
00007efc33fdb84f  vmovaps xmm4, [rsp+0x30]
00007efc33fdb855  vmovaps xmm5, [rsp+0x40]
00007efc33fdb85b  vmovaps xmm6, [rsp+0x50]
00007efc33fdb861  vmovaps xmm7, [rsp+0x60]
00007efc33fdb867  vmovaps xmm8, [rsp+0x70]
00007efc33fdb86d  vmovaps xmm9, [rsp+0x80]
00007efc33fdb876  vmovaps xmm10, [rsp+0x90]
00007efc33fdb87f  vmovaps xmm11, [rsp+0xA0]
00007efc33fdb888  vmovaps xmm12, [rsp+0xB0]
00007efc33fdb891  vmovaps xmm13, [rsp+0xC0]
00007efc33fdb89a  vmovaps xmm14, [rsp+0xD0]
00007efc33fdb8a3  vmovaps xmm15, [rsp+0xE0]
00007efc33fdb8ac  add rsp, 0xF0
00007efc33fdb8b3  pop r11
00007efc33fdb8b5  pop r10
00007efc33fdb8b7  pop r9
00007efc33fdb8b9  pop r8
00007efc33fdb8bb  pop rsi
00007efc33fdb8bc  pop rdi
00007efc33fdb8bd  pop rdx
00007efc33fdb8be  pop rcx
00007efc33fdb8bf  pop rax
00007efc33fdb8c0  add rsp, 0x08
00007efc33fdb8c4  jmp 0x00007EFC33FD66B2
00007efc33fdb8c9  call 0x00007EFC33EB3E40
00007efc33fdb8ce  jmp 0x00007EFC33FD66C0
00007efc33fdb8d3  call 0x00007EFC33E0C380
00007efc33fdb8d8  jmp 0x00007EFC33FD66CA
00007efc33fdb8dd  call 0x00007EFC33E0D600
00007efc33fdb8e2  jmp 0x00007EFC33FD66D4
00007efc33fdb8e7  call 0x00007EFC33DFF540
00007efc33fdb8ec  jmp 0x00007EFC33FD66DE
00007efc33fdb8f1  int3
00007efc33fdb8f2  nop [rax+rax*1], ax
00007efc33fdb8fb  nop [rax+rax*1], eax
00007efc33fdb900  mov eax, [r15+0x48]
00007efc33fdb904  lea r14d, [eax+0x01]
00007efc33fdb909  mov [rsp+0x10], r14d
00007efc33fdb90e  mov r14d, r14d
00007efc33fdb911  mov [r15+0x48], r14
00007efc33fdb915  xor eax, eax
00007efc33fdb917  mov r14d, [rsp+0x10]
00007efc33fdb91c  cmp r14d, 0x1F4
00007efc33fdb923  cmc
00007efc33fdb924  lahf
00007efc33fdb925  seto al
00007efc33fdb928  mov [r15+0x108], eax
00007efc33fdb92f  mov eax, [r15+0x108]
00007efc33fdb936  sahf
00007efc33fdb937  jnz 0x00007EFC33FDB969
00007efc33fdb939  cmp dword ptr [r15+0x318], 0x00
00007efc33fdb941  jz 0x00007EFC33FE1AB0
00007efc33fdb947  nop [rax+rax*1], ax
00007efc33fdb950  nop [rax+rax*1], eax
00007efc33fdb958  mov eax, 0x410450
00007efc33fdb95d  mov [r15+0x100], rax
00007efc33fdb964  jmp 0x00007EFC33DFE110
00007efc33fdb969  cmp dword ptr [r15+0x318], 0x00
00007efc33fdb971  jz 0x00007EFC33FDB9A0
00007efc33fdb977  nop [rax+rax*1], ax
00007efc33fdb980  nop [rax+rax*1], eax
00007efc33fdb988  mov eax, 0x410274
00007efc33fdb98d  mov [r15+0x100], rax
00007efc33fdb994  jmp 0x00007EFC33DFE110
00007efc33fdb999  int3
00007efc33fdb99a  int3
00007efc33fdb99b  nop [rax+rax*1], eax
00007efc33fdb9a0  mov rax, [r15+0x40]
00007efc33fdb9a4  movaps xmm1, [r15+0x1D0]
00007efc33fdb9ac  vmovaps [rsp+0x10], xmm1
00007efc33fdb9b2  vmovaps xmm15, [rsp+0x10]
00007efc33fdb9b8  por xmm1, xmm15
00007efc33fdb9bd  movaps xmm14, [r15+0x1A0]
00007efc33fdb9c5  vmovaps [rsp+0x10], xmm14
00007efc33fdb9cb  vmovaps xmm13, [rsp+0x10]
00007efc33fdb9d1  por xmm14, xmm13
00007efc33fdb9d6  lea r14, [rax+0x30]
00007efc33fdb9da  mov r12, [r13+r14*1]
00007efc33fdb9df  lea r14, [rax+0x38]
00007efc33fdb9e3  mov r11, [r13+r14*1]
00007efc33fdb9e8  movq xmm13, r12
00007efc33fdb9ed  movq xmm12, r11
00007efc33fdb9f2  movq xmm13, xmm13
00007efc33fdb9f7  vmovaps [rsp+0x10], xmm13
00007efc33fdb9fd  movq xmm13, xmm13
00007efc33fdba02  movaps [r15+0x130], xmm13
00007efc33fdba0a  movq xmm12, xmm12
00007efc33fdba0f  vmovaps [rsp+0x20], xmm12
00007efc33fdba15  movq xmm12, xmm12
00007efc33fdba1a  movaps [r15+0x280], xmm12
00007efc33fdba22  movaps xmm13, [r15+0x270]
00007efc33fdba2a  vmovaps [rsp+0x30], xmm13
00007efc33fdba30  vmovaps xmm12, [rsp+0x30]
00007efc33fdba36  por xmm13, xmm12
00007efc33fdba3b  lea r14, [rax+0x20]
00007efc33fdba3f  mov r12, [r13+r14*1]
00007efc33fdba44  lea r14, [rax+0x28]
00007efc33fdba48  mov r11, [r13+r14*1]
00007efc33fdba4d  movq xmm12, r12
00007efc33fdba52  movq xmm11, r11
00007efc33fdba57  movq xmm12, xmm12
00007efc33fdba5c  vmovaps [rsp+0x30], xmm12
00007efc33fdba62  movq xmm12, xmm12
00007efc33fdba67  movaps [r15+0x150], xmm12
00007efc33fdba6f  movq xmm11, xmm11
00007efc33fdba74  vmovaps [rsp+0x40], xmm11
00007efc33fdba7a  movq xmm11, xmm11
00007efc33fdba7f  movaps [r15+0x140], xmm11
00007efc33fdba87  lea r14, [rax+0x10]
00007efc33fdba8b  mov r12, [r13+r14*1]
00007efc33fdba90  lea r14, [rax+0x18]
00007efc33fdba94  mov r11, [r13+r14*1]
00007efc33fdba99  movq xmm12, r12
00007efc33fdba9e  movq xmm11, r11
00007efc33fdbaa3  movq xmm12, xmm12
00007efc33fdbaa8  vmovaps [rsp+0x50], xmm12
00007efc33fdbaae  movq xmm12, xmm12
00007efc33fdbab3  movaps [r15+0x170], xmm12
00007efc33fdbabb  movq xmm11, xmm11
00007efc33fdbac0  vmovaps [rsp+0x60], xmm11
00007efc33fdbac6  movq xmm11, xmm11
00007efc33fdbacb  movaps [r15+0x160], xmm11
00007efc33fdbad3  mov r14, [r13+rax*1]
00007efc33fdbad8  vmovq xmm12, r14
00007efc33fdbadd  vpbroadcastq xmm12, xmm12
00007efc33fdbae2  lea r14, [rax+0x08]
00007efc33fdbae6  mov rax, [r13+r14*1]
00007efc33fdbaeb  movq xmm11, rax
00007efc33fdbaf0  movaps [r15+0x230], xmm11
00007efc33fdbaf8  mov rax, [r15+0xF8]
00007efc33fdbaff  lea r14, [rax+0x50]
00007efc33fdbb03  movups xmm11, [r13+r14*1]
00007efc33fdbb09  lea r14, [rax+0x60]
00007efc33fdbb0d  movups xmm10, [r13+r14*1]
00007efc33fdbb13  lea r14, [rax+0x30]
00007efc33fdbb17  movups xmm9, [r13+r14*1]
00007efc33fdbb1d  mov r14, [r15+0x50]
00007efc33fdbb21  mov [r15+0x60], r14
00007efc33fdbb25  mov qword ptr [r15+0x58], 0x40
00007efc33fdbb2d  movaps xmm8, xmm12
00007efc33fdbb31  mulpd xmm8, xmm15
00007efc33fdbb36  vcmppd xmm7, xmm8, xmm8, 0x03
00007efc33fdbb3c  ptest xmm7, xmm7
00007efc33fdbb41  jnz 0x00007EFC33FDC96A
00007efc33fdbb47  movq xmm15, qword ptr [r15+0x230]
00007efc33fdbb50  vmovaps [rsp+0x70], xmm15
00007efc33fdbb56  vpermilpd xmm15, xmm15, 0x00
00007efc33fdbb5c  movaps xmm7, xmm9
00007efc33fdbb60  mulpd xmm7, xmm15
00007efc33fdbb65  vcmppd xmm6, xmm7, xmm7, 0x03
00007efc33fdbb6a  ptest xmm6, xmm6
00007efc33fdbb6f  jnz 0x00007EFC33FDCAAE
00007efc33fdbb75  vxorps xmm15, xmm15, xmm15
00007efc33fdbb7a  vpbroadcastq xmm15, xmm15
00007efc33fdbb7f  movaps xmm9, xmm12
00007efc33fdbb83  mulpd xmm9, xmm10
00007efc33fdbb88  vcmppd xmm6, xmm9, xmm9, 0x03
00007efc33fdbb8e  ptest xmm6, xmm6
00007efc33fdbb93  jnz 0x00007EFC33FDCBF0
00007efc33fdbb99  movaps xmm10, xmm12
00007efc33fdbb9d  mulpd xmm10, xmm11
00007efc33fdbba2  vcmppd xmm6, xmm10, xmm10, 0x03
00007efc33fdbba8  ptest xmm6, xmm6
00007efc33fdbbad  jnz 0x00007EFC33FDCD34
00007efc33fdbbb3  movaps xmm11, [r15+0x1F0]
00007efc33fdbbbb  movaps xmm6, xmm12
00007efc33fdbbbf  mulpd xmm6, xmm11
00007efc33fdbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
00007efc33fdbbc9  ptest xmm5, xmm5
00007efc33fdbbce  jnz 0x00007EFC33FDCE78
00007efc33fdbbd4  movaps xmm12, [r15+0x2A0]
00007efc33fdbbdc  vmovaps [rsp+0x80], xmm12
00007efc33fdbbe5  vmovaps xmm11, [rsp+0x80]
00007efc33fdbbee  por xmm12, xmm11
00007efc33fdbbf3  movaps xmm11, [r15+0x250]
00007efc33fdbbfb  vmovaps [rsp+0x80], xmm11
00007efc33fdbc04  vmovaps xmm5, [rsp+0x80]
00007efc33fdbc0d  por xmm11, xmm5
00007efc33fdbc12  vmovaps xmm4, [rsp+0x70]
00007efc33fdbc18  vpermilpd xmm4, xmm4, 0x00
00007efc33fdbc1e  movaps xmm3, xmm5
00007efc33fdbc21  mulpd xmm3, xmm4
00007efc33fdbc25  vcmppd xmm2, xmm3, xmm3, 0x03
00007efc33fdbc2a  ptest xmm2, xmm2
00007efc33fdbc2f  jnz 0x00007EFC33FDCFBA
00007efc33fdbc35  mov [rsp+0x80], rax
00007efc33fdbc3d  xor eax, eax
00007efc33fdbc3f  mov r12d, 0x40
00007efc33fdbc45  mov r11d, 0x200
00007efc33fdbc4b  cmp r12, r11
00007efc33fdbc4e  cmc
00007efc33fdbc4f  lahf
00007efc33fdbc50  seto al
00007efc33fdbc53  mov [r15+0x108], eax
00007efc33fdbc5a  movaps xmm5, xmm8
00007efc33fdbc5e  addpd xmm5, xmm15
00007efc33fdbc63  vcmppd xmm4, xmm5, xmm5, 0x03
00007efc33fdbc68  ptest xmm4, xmm4
00007efc33fdbc6d  jnz 0x00007EFC33FDD0FA
00007efc33fdbc73  movaps xmm8, [r15+0x1B0]
00007efc33fdbc7b  movaps xmm4, xmm9
00007efc33fdbc7f  addpd xmm4, xmm8
00007efc33fdbc84  vcmppd xmm2, xmm4, xmm4, 0x03
00007efc33fdbc89  ptest xmm2, xmm2
00007efc33fdbc8e  jnz 0x00007EFC33FDD23C
00007efc33fdbc94  movaps xmm9, xmm10
00007efc33fdbc98  addpd xmm9, xmm8
00007efc33fdbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
00007efc33fdbca3  ptest xmm2, xmm2
00007efc33fdbca8  jnz 0x00007EFC33FDD37E
00007efc33fdbcae  movaps xmm10, [r15+0x2F0]
00007efc33fdbcb6  vmovaps [rsp+0x90], xmm10
00007efc33fdbcbf  vmovaps xmm8, [rsp+0x90]
00007efc33fdbcc8  por xmm10, xmm8
00007efc33fdbccd  movaps xmm8, [r15+0x2E0]
00007efc33fdbcd5  vmovaps [rsp+0x90], xmm8
00007efc33fdbcde  vmovaps xmm2, [rsp+0x90]
00007efc33fdbce7  por xmm8, xmm2
00007efc33fdbcec  movaps xmm2, [r15+0x2D0]
00007efc33fdbcf4  vmovaps [rsp+0x90], xmm2
00007efc33fdbcfd  vmovaps [rsp+0xA0], xmm1
00007efc33fdbd06  vmovaps xmm1, [rsp+0x90]
00007efc33fdbd0f  por xmm2, xmm1
00007efc33fdbd13  movaps xmm1, [r15+0x200]
00007efc33fdbd1b  vmovaps [rsp+0x90], xmm1
00007efc33fdbd24  vmovaps [rsp+0xB0], xmm15
00007efc33fdbd2d  vmovaps xmm15, [rsp+0x90]
00007efc33fdbd36  por xmm1, xmm15
00007efc33fdbd3b  movaps xmm15, [r15+0x1C0]
00007efc33fdbd43  vmovaps [rsp+0x90], xmm15
00007efc33fdbd4c  vmovaps [rsp+0xC0], xmm1
00007efc33fdbd55  vmovaps xmm1, [rsp+0x90]
00007efc33fdbd5e  por xmm15, xmm1
00007efc33fdbd63  movaps xmm1, [r15+0x190]
00007efc33fdbd6b  vmovaps [rsp+0x90], xmm1
00007efc33fdbd74  vmovaps [rsp+0xD0], xmm15
00007efc33fdbd7d  vmovaps xmm15, [rsp+0x90]
00007efc33fdbd86  por xmm1, xmm15
00007efc33fdbd8b  movaps xmm15, [r15+0x300]
00007efc33fdbd93  vmovaps [rsp+0x90], xmm15
00007efc33fdbd9c  vmovaps [rsp+0xE0], xmm1
00007efc33fdbda5  vmovaps xmm1, [rsp+0x90]
00007efc33fdbdae  por xmm15, xmm1
00007efc33fdbdb3  mov rax, [rsp+0x80]
00007efc33fdbdbb  lea r12, [rax+0xA0]
00007efc33fdbdc2  movups xmm1, [r13+r12*1]
00007efc33fdbdc8  lea r12, [rax+0xB0]
00007efc33fdbdcf  vmovaps [rsp+0x80], xmm1
00007efc33fdbdd8  movups xmm1, [r13+r12*1]
00007efc33fdbdde  vmovaps [rsp+0x90], xmm1
00007efc33fdbde7  vmovaps [rsp+0xF0], xmm15
00007efc33fdbdf0  vmovaps xmm15, [rsp+0xB0]
00007efc33fdbdf9  vmovaps [rsp+0xB0], xmm14
00007efc33fdbe02  movaps xmm1, xmm6
00007efc33fdbe05  addpd xmm1, xmm15
00007efc33fdbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
00007efc33fdbe0f  ptest xmm14, xmm14
00007efc33fdbe15  jnz 0x00007EFC33FDD4D6
00007efc33fdbe1b  lea r12, [rax+0xF0]
00007efc33fdbe22  movups xmm15, [r13+r12*1]
00007efc33fdbe28  movaps xmm14, xmm4
00007efc33fdbe2c  addpd xmm14, xmm3
00007efc33fdbe31  vcmppd xmm6, xmm14, xmm14, 0x03
00007efc33fdbe37  ptest xmm6, xmm6
00007efc33fdbe3c  jnz 0x00007EFC33FDD621
00007efc33fdbe42  movaps xmm6, xmm9
00007efc33fdbe46  addpd xmm6, xmm7
00007efc33fdbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
00007efc33fdbe4f  ptest xmm4, xmm4
00007efc33fdbe54  jnz 0x00007EFC33FDD763
00007efc33fdbe5a  vmovaps xmm9, [rsp+0x70]
00007efc33fdbe60  vpermilpd xmm9, xmm9, 0x00
00007efc33fdbe66  vmovaps xmm4, [rsp+0x90]
00007efc33fdbe6f  movaps xmm7, xmm4
00007efc33fdbe72  mulpd xmm7, xmm9
00007efc33fdbe77  vcmppd xmm3, xmm7, xmm7, 0x03
00007efc33fdbe7c  ptest xmm3, xmm3
00007efc33fdbe81  jnz 0x00007EFC33FDD8A4
00007efc33fdbe87  vmovaps xmm9, [rsp+0x50]
00007efc33fdbe8d  vpermilpd xmm9, xmm9, 0x00
00007efc33fdbe93  movaps xmm4, xmm15
00007efc33fdbe97  mulpd xmm4, xmm9
00007efc33fdbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
00007efc33fdbea1  ptest xmm3, xmm3
00007efc33fdbea6  jnz 0x00007EFC33FDD9E5
00007efc33fdbeac  lea r12, [rax+0xE0]
00007efc33fdbeb3  movups xmm15, [r13+r12*1]
00007efc33fdbeb9  vmovaps xmm9, [rsp+0x70]
00007efc33fdbebf  vpermilpd xmm9, xmm9, 0x00
00007efc33fdbec5  vmovaps [rsp+0x70], xmm1
00007efc33fdbecb  vmovaps xmm1, [rsp+0x80]
00007efc33fdbed4  vmovaps [rsp+0x80], xmm15
00007efc33fdbedd  movaps xmm3, xmm1
00007efc33fdbee0  mulpd xmm3, xmm9
00007efc33fdbee5  vcmppd xmm15, xmm3, xmm3, 0x03
00007efc33fdbeea  ptest xmm15, xmm15
00007efc33fdbef0  jnz 0x00007EFC33FDDB31
00007efc33fdbef6  vmovaps xmm1, [rsp+0xF0]
00007efc33fdbeff  vmovaps xmm15, [rsp+0xF0]
00007efc33fdbf08  por xmm1, xmm15
00007efc33fdbf0d  movaps [r15+0x300], xmm1
00007efc33fdbf15  vmovaps xmm15, [rsp+0xE0]
00007efc33fdbf1e  vmovaps xmm9, [rsp+0xE0]
00007efc33fdbf27  por xmm15, xmm9
00007efc33fdbf2c  movaps [r15+0x190], xmm15
00007efc33fdbf34  vmovaps xmm9, [rsp+0x50]
00007efc33fdbf3a  vpermilpd xmm9, xmm9, 0x00
00007efc33fdbf40  vmovaps [rsp+0x90], xmm1
00007efc33fdbf49  vmovaps [rsp+0xE0], xmm15
00007efc33fdbf52  vmovaps xmm15, [rsp+0x80]
00007efc33fdbf5b  vmovaps [rsp+0x80], xmm14
00007efc33fdbf64  movaps xmm1, xmm15
00007efc33fdbf68  mulpd xmm1, xmm9
00007efc33fdbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
00007efc33fdbf72  ptest xmm14, xmm14
00007efc33fdbf78  jnz 0x00007EFC33FDDC72
00007efc33fdbf7e  lea r12, [rax+0x90]
00007efc33fdbf85  movups xmm15, [r13+r12*1]
00007efc33fdbf8b  vmovaps xmm14, [rsp+0xD0]
00007efc33fdbf94  vmovaps xmm9, [rsp+0xD0]
00007efc33fdbf9d  por xmm14, xmm9
00007efc33fdbfa2  movaps [r15+0x1C0], xmm14
00007efc33fdbfaa  vmovaps xmm9, [rsp+0xC0]
00007efc33fdbfb3  vmovaps [rsp+0xD0], xmm1
00007efc33fdbfbc  vmovaps xmm1, [rsp+0xC0]
00007efc33fdbfc5  por xmm9, xmm1
00007efc33fdbfca  movaps [r15+0x200], xmm9
00007efc33fdbfd2  vmovaps [rsp+0xC0], xmm2
00007efc33fdbfdb  vmovaps xmm1, [rsp+0xC0]
00007efc33fdbfe4  por xmm2, xmm1
00007efc33fdbfe8  movaps [r15+0x2D0], xmm2
00007efc33fdbff0  vmovaps [rsp+0xC0], xmm8
00007efc33fdbff9  vmovaps xmm1, [rsp+0xC0]
00007efc33fdc002  por xmm8, xmm1
00007efc33fdc007  movaps [r15+0x2E0], xmm8
00007efc33fdc00f  vmovaps [rsp+0xC0], xmm15
00007efc33fdc018  movaps xmm1, xmm5
00007efc33fdc01b  addpd xmm1, xmm7
00007efc33fdc01f  vcmppd xmm15, xmm1, xmm1, 0x03
00007efc33fdc024  ptest xmm15, xmm15
00007efc33fdc02a  jnz 0x00007EFC33FDDDBE
00007efc33fdc030  vmovaps xmm15, [rsp+0x50]
00007efc33fdc036  vpermilpd xmm15, xmm15, 0x00
00007efc33fdc03c  vmovaps xmm5, [rsp+0xC0]
00007efc33fdc045  vmovaps [rsp+0xC0], xmm1
00007efc33fdc04e  movaps xmm7, xmm5
00007efc33fdc051  mulpd xmm7, xmm15
00007efc33fdc056  vcmppd xmm1, xmm7, xmm7, 0x03
00007efc33fdc05b  ptest xmm1, xmm1
00007efc33fdc060  jnz 0x00007EFC33FDDEFE
00007efc33fdc066  lea r12, [rax+0x80]
00007efc33fdc06d  movups xmm1, [r13+r12*1]
00007efc33fdc073  vmovaps xmm5, [rsp+0x70]
00007efc33fdc079  vmovaps [rsp+0x70], xmm1
00007efc33fdc07f  movaps xmm15, xmm5
00007efc33fdc083  addpd xmm15, xmm3
00007efc33fdc088  vcmppd xmm1, xmm15, xmm15, 0x03
00007efc33fdc08e  ptest xmm1, xmm1
00007efc33fdc093  jnz 0x00007EFC33FDE049
00007efc33fdc099  vmovaps xmm5, [rsp+0x80]
00007efc33fdc0a2  movaps xmm1, xmm5
00007efc33fdc0a5  addpd xmm1, xmm4
00007efc33fdc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
00007efc33fdc0ae  ptest xmm3, xmm3
00007efc33fdc0b3  jnz 0x00007EFC33FDE18B
00007efc33fdc0b9  vmovaps [rsp+0x80], xmm10
00007efc33fdc0c2  vmovaps xmm5, [rsp+0x80]
00007efc33fdc0cb  por xmm10, xmm5
00007efc33fdc0d0  movaps [r15+0x2F0], xmm10
00007efc33fdc0d8  vmovaps xmm5, [rsp+0x50]
00007efc33fdc0de  vpermilpd xmm5, xmm5, 0x00
00007efc33fdc0e4  vmovaps xmm3, [rsp+0x70]
00007efc33fdc0ea  vmovaps [rsp+0x50], xmm1
00007efc33fdc0f0  movaps xmm4, xmm3
00007efc33fdc0f3  mulpd xmm4, xmm5
00007efc33fdc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
00007efc33fdc0fc  ptest xmm1, xmm1
00007efc33fdc101  jnz 0x00007EFC33FDE2CB
00007efc33fdc107  lea r12, [rax+0xD0]
00007efc33fdc10e  movups xmm1, [r13+r12*1]
00007efc33fdc114  vmovaps xmm3, [rsp+0xD0]
00007efc33fdc11d  vmovaps [rsp+0x70], xmm1
00007efc33fdc123  movaps xmm5, xmm6
00007efc33fdc126  addpd xmm5, xmm3
00007efc33fdc12a  vcmppd xmm1, xmm5, xmm5, 0x03
00007efc33fdc12f  ptest xmm1, xmm1
00007efc33fdc134  jnz 0x00007EFC33FDE415
00007efc33fdc13a  vmovaps xmm1, [rsp+0x60]
00007efc33fdc140  vpermilpd xmm1, xmm1, 0x00
00007efc33fdc146  movaps xmm6, xmm9
00007efc33fdc14a  mulpd xmm6, xmm1
00007efc33fdc14e  vcmppd xmm3, xmm6, xmm6, 0x03
00007efc33fdc153  ptest xmm3, xmm3
00007efc33fdc158  jnz 0x00007EFC33FDE555
00007efc33fdc15e  movaps [r15+0x260], xmm6
00007efc33fdc166  vxorps xmm1, xmm1, xmm1
00007efc33fdc16a  vpbroadcastq xmm1, xmm1
00007efc33fdc16f  movaps [r15+0x1B0], xmm1
00007efc33fdc177  vmovaps xmm1, [rsp+0x60]
00007efc33fdc17d  vpermilpd xmm1, xmm1, 0x00
00007efc33fdc183  vmovaps xmm3, [rsp+0x70]
00007efc33fdc189  vmovaps [rsp+0x70], xmm15
00007efc33fdc18f  movaps xmm9, xmm3
00007efc33fdc193  mulpd xmm9, xmm1
00007efc33fdc198  vcmppd xmm15, xmm9, xmm9, 0x03
00007efc33fdc19e  ptest xmm15, xmm15
00007efc33fdc1a4  jnz 0x00007EFC33FDE696
00007efc33fdc1aa  lea r12, [rax+0xC0]
00007efc33fdc1b1  movups xmm1, [r13+r12*1]
00007efc33fdc1b7  vmovaps xmm3, [rsp+0xC0]
00007efc33fdc1c0  vmovaps [rsp+0x80], xmm1
00007efc33fdc1c9  movaps xmm15, xmm3
00007efc33fdc1cd  addpd xmm15, xmm7
00007efc33fdc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
00007efc33fdc1d8  ptest xmm1, xmm1
00007efc33fdc1dd  jnz 0x00007EFC33FDE7E2
00007efc33fdc1e3  vmovaps [rsp+0xC0], xmm13
00007efc33fdc1ec  vmovaps xmm1, [rsp+0xC0]
00007efc33fdc1f5  por xmm13, xmm1
00007efc33fdc1fa  movaps [r15+0x270], xmm13
00007efc33fdc202  vmovaps xmm1, [rsp+0xB0]
00007efc33fdc20b  vmovaps xmm7, [rsp+0xB0]
00007efc33fdc214  por xmm1, xmm7
00007efc33fdc218  movaps [r15+0x1A0], xmm1
00007efc33fdc220  vmovaps xmm1, [rsp+0x60]
00007efc33fdc226  vpermilpd xmm1, xmm1, 0x00
00007efc33fdc22c  vmovaps [rsp+0xB0], xmm1
00007efc33fdc235  vmovaps xmm1, [rsp+0x80]
00007efc33fdc23e  vmovaps [rsp+0x80], xmm15
00007efc33fdc247  vmovaps xmm15, [rsp+0xB0]
00007efc33fdc250  vmovaps [rsp+0xB0], xmm14
00007efc33fdc259  movaps xmm3, xmm1
00007efc33fdc25c  mulpd xmm3, xmm15
00007efc33fdc261  vcmppd xmm14, xmm3, xmm3, 0x03
00007efc33fdc266  ptest xmm14, xmm14
00007efc33fdc26c  jnz 0x00007EFC33FDE924
00007efc33fdc272  lea r12, [rax+0x20]
00007efc33fdc276  movups xmm1, [r13+r12*1]
00007efc33fdc27c  movaps [r15+0x110], xmm1
00007efc33fdc284  vmovaps xmm14, [rsp+0x70]
00007efc33fdc28a  vmovaps [rsp+0x70], xmm1
00007efc33fdc290  movaps xmm15, xmm14
00007efc33fdc294  addpd xmm15, xmm4
00007efc33fdc299  vcmppd xmm1, xmm15, xmm15, 0x03
00007efc33fdc29f  ptest xmm1, xmm1
00007efc33fdc2a4  jnz 0x00007EFC33FDEA6F
00007efc33fdc2aa  vmovaps xmm1, [rsp+0x60]
00007efc33fdc2b0  vpermilpd xmm1, xmm1, 0x00
00007efc33fdc2b6  movaps xmm14, xmm2
00007efc33fdc2ba  mulpd xmm14, xmm1
00007efc33fdc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
00007efc33fdc2c5  ptest xmm4, xmm4
00007efc33fdc2ca  jnz 0x00007EFC33FDEBB2
00007efc33fdc2d0  vmovaps xmm4, [rsp+0x50]
00007efc33fdc2d6  movaps xmm1, xmm4
00007efc33fdc2d9  addpd xmm1, xmm9
00007efc33fdc2de  vcmppd xmm2, xmm1, xmm1, 0x03
00007efc33fdc2e3  ptest xmm2, xmm2
00007efc33fdc2e8  jnz 0x00007EFC33FDECF4
00007efc33fdc2ee  vmovaps xmm9, [rsp+0x30]
00007efc33fdc2f4  vpermilpd xmm9, xmm9, 0x00
00007efc33fdc2fa  vmovaps xmm2, [rsp+0x70]
00007efc33fdc300  vmovaps [rsp+0x50], xmm1
00007efc33fdc306  movaps xmm4, xmm2
00007efc33fdc309  mulpd xmm4, xmm9
00007efc33fdc30e  vcmppd xmm1, xmm4, xmm4, 0x03
00007efc33fdc313  ptest xmm1, xmm1
00007efc33fdc318  jnz 0x00007EFC33FDEE35
00007efc33fdc31e  vmovaps xmm1, [rsp+0x30]
00007efc33fdc324  vpermilpd xmm1, xmm1, 0x00
00007efc33fdc32a  vmovaps xmm2, [rsp+0x90]
00007efc33fdc333  vmovaps [rsp+0x60], xmm15
00007efc33fdc339  movaps xmm9, xmm2
00007efc33fdc33d  mulpd xmm9, xmm1
00007efc33fdc342  vcmppd xmm15, xmm9, xmm9, 0x03
00007efc33fdc348  ptest xmm15, xmm15
00007efc33fdc34e  jnz 0x00007EFC33FDEF76
00007efc33fdc354  vmovaps xmm15, [rsp+0x80]
00007efc33fdc35d  movaps xmm1, xmm15
00007efc33fdc361  addpd xmm1, xmm6
00007efc33fdc365  vcmppd xmm2, xmm1, xmm1, 0x03
00007efc33fdc36a  ptest xmm2, xmm2
00007efc33fdc36f  jnz 0x00007EFC33FDF0B8
00007efc33fdc375  movaps xmm15, xmm5
00007efc33fdc379  addpd xmm15, xmm3
00007efc33fdc37e  vcmppd xmm6, xmm15, xmm15, 0x03
00007efc33fdc384  ptest xmm6, xmm6
00007efc33fdc389  jnz 0x00007EFC33FDF1F9
00007efc33fdc38f  vmovaps xmm6, [rsp+0x30]
00007efc33fdc395  vpermilpd xmm6, xmm6, 0x00
00007efc33fdc39b  movaps xmm5, xmm8
00007efc33fdc39f  mulpd xmm5, xmm6
00007efc33fdc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
00007efc33fdc3a8  ptest xmm3, xmm3
00007efc33fdc3ad  jnz 0x00007EFC33FDF33B
00007efc33fdc3b3  vmovaps xmm8, [rsp+0x30]
00007efc33fdc3b9  vpermilpd xmm8, xmm8, 0x00
00007efc33fdc3bf  movaps xmm6, xmm10
00007efc33fdc3c3  mulpd xmm6, xmm8
00007efc33fdc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
00007efc33fdc3cd  ptest xmm3, xmm3
00007efc33fdc3d2  jnz 0x00007EFC33FDF47C
00007efc33fdc3d8  vmovaps xmm8, [rsp+0x60]
00007efc33fdc3de  movaps xmm10, xmm8
00007efc33fdc3e2  addpd xmm10, xmm14
00007efc33fdc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
00007efc33fdc3ed  ptest xmm3, xmm3
00007efc33fdc3f2  jnz 0x00007EFC33FDF5BE
00007efc33fdc3f8  vmovaps xmm8, [rsp+0x50]
00007efc33fdc3fe  movaps xmm14, xmm8
00007efc33fdc402  addpd xmm14, xmm4
00007efc33fdc407  vcmppd xmm3, xmm14, xmm14, 0x03
00007efc33fdc40d  ptest xmm3, xmm3
00007efc33fdc412  jnz 0x00007EFC33FDF702
00007efc33fdc418  vmovaps xmm8, [rsp+0x40]
00007efc33fdc41e  vpermilpd xmm8, xmm8, 0x00
00007efc33fdc424  movaps xmm4, xmm13
00007efc33fdc428  mulpd xmm4, xmm8
00007efc33fdc42d  vcmppd xmm3, xmm4, xmm4, 0x03
00007efc33fdc432  ptest xmm3, xmm3
00007efc33fdc437  jnz 0x00007EFC33FDF845
00007efc33fdc43d  movaps xmm13, xmm15
00007efc33fdc441  addpd xmm13, xmm9
00007efc33fdc446  vcmppd xmm8, xmm13, xmm13, 0x03
00007efc33fdc44c  ptest xmm8, xmm8
00007efc33fdc452  jnz 0x00007EFC33FDF987
00007efc33fdc458  movaps xmm15, xmm1
00007efc33fdc45c  addpd xmm15, xmm5
00007efc33fdc461  vcmppd xmm9, xmm15, xmm15, 0x03
00007efc33fdc467  ptest xmm9, xmm9
00007efc33fdc46d  jnz 0x00007EFC33FDFACB
00007efc33fdc473  vmovaps [rsp+0x30], xmm11
00007efc33fdc479  vmovaps xmm1, [rsp+0x30]
00007efc33fdc47f  por xmm11, xmm1
00007efc33fdc484  movaps [r15+0x250], xmm11
00007efc33fdc48c  vmovaps [rsp+0x30], xmm12
00007efc33fdc492  vmovaps xmm1, [rsp+0x30]
00007efc33fdc498  por xmm12, xmm1
00007efc33fdc49d  movaps [r15+0x2A0], xmm12
00007efc33fdc4a5  vmovaps xmm1, [rsp+0xA0]
00007efc33fdc4ae  vmovaps xmm11, [rsp+0xA0]
00007efc33fdc4b7  por xmm1, xmm11
00007efc33fdc4bc  movaps [r15+0x1D0], xmm1
00007efc33fdc4c4  lea r12, [rax+0x40]
00007efc33fdc4c8  movups xmm1, [r13+r12*1]
00007efc33fdc4ce  movaps [r15+0x2C0], xmm1
00007efc33fdc4d6  vmovaps xmm11, [rsp+0x40]
00007efc33fdc4dc  vpermilpd xmm11, xmm11, 0x00
00007efc33fdc4e2  vmovaps xmm8, [rsp+0xE0]
00007efc33fdc4eb  movaps xmm9, xmm8
00007efc33fdc4ef  mulpd xmm9, xmm11
00007efc33fdc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
00007efc33fdc4fa  ptest xmm5, xmm5
00007efc33fdc4ff  jnz 0x00007EFC33FDFC17
00007efc33fdc505  movaps xmm11, xmm10
00007efc33fdc509  addpd xmm11, xmm6
00007efc33fdc50e  vcmppd xmm8, xmm11, xmm11, 0x03
00007efc33fdc514  ptest xmm8, xmm8
00007efc33fdc51a  jnz 0x00007EFC33FDFD5B
00007efc33fdc520  movaps xmm10, xmm14
00007efc33fdc524  addpd xmm10, xmm4
00007efc33fdc529  vcmppd xmm8, xmm10, xmm10, 0x03
00007efc33fdc52f  ptest xmm8, xmm8
00007efc33fdc535  jnz 0x00007EFC33FDFE9E
00007efc33fdc53b  vmovaps xmm14, [rsp+0x40]
00007efc33fdc541  vpermilpd xmm14, xmm14, 0x00
00007efc33fdc547  movaps xmm8, xmm1
00007efc33fdc54b  mulpd xmm8, xmm14
00007efc33fdc550  vcmppd xmm6, xmm8, xmm8, 0x03
00007efc33fdc556  ptest xmm6, xmm6
00007efc33fdc55b  jnz 0x00007EFC33FDFFE1
00007efc33fdc561  movaps xmm1, [r15+0x2B0]
00007efc33fdc569  vmovaps xmm14, [rsp+0x40]
00007efc33fdc56f  vpermilpd xmm14, xmm14, 0x00
00007efc33fdc575  movaps xmm6, xmm1
00007efc33fdc578  mulpd xmm6, xmm14
00007efc33fdc57d  vcmppd xmm5, xmm6, xmm6, 0x03
00007efc33fdc582  ptest xmm5, xmm5
00007efc33fdc587  jnz 0x00007EFC33FE0124
00007efc33fdc58d  vmovaps xmm1, [rsp+0x10]
00007efc33fdc593  vpermilpd xmm1, xmm1, 0x00
00007efc33fdc599  movaps xmm14, xmm12
00007efc33fdc59d  mulpd xmm14, xmm1
00007efc33fdc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
00007efc33fdc5a8  ptest xmm5, xmm5
00007efc33fdc5ad  jnz 0x00007EFC33FE0265
00007efc33fdc5b3  movaps xmm1, xmm13
00007efc33fdc5b7  addpd xmm1, xmm9
00007efc33fdc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
00007efc33fdc5c1  ptest xmm12, xmm12
00007efc33fdc5c7  jnz 0x00007EFC33FE03A8
00007efc33fdc5cd  vmovaps xmm13, [rsp+0x10]
00007efc33fdc5d3  vpermilpd xmm13, xmm13, 0x00
00007efc33fdc5d9  movaps xmm12, xmm7
00007efc33fdc5dd  mulpd xmm12, xmm13
00007efc33fdc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
00007efc33fdc5e8  ptest xmm9, xmm9
00007efc33fdc5ee  jnz 0x00007EFC33FE04EA
00007efc33fdc5f4  movaps xmm13, xmm15
00007efc33fdc5f8  addpd xmm13, xmm8
00007efc33fdc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
00007efc33fdc603  ptest xmm9, xmm9
00007efc33fdc609  jnz 0x00007EFC33FE062D
00007efc33fdc60f  movaps xmm15, [r15+0x290]
00007efc33fdc617  vmovaps xmm9, [rsp+0x10]
00007efc33fdc61d  vpermilpd xmm9, xmm9, 0x00
00007efc33fdc623  movaps xmm8, xmm15
00007efc33fdc627  mulpd xmm8, xmm9
00007efc33fdc62c  vcmppd xmm7, xmm8, xmm8, 0x03
00007efc33fdc632  ptest xmm7, xmm7
00007efc33fdc637  jnz 0x00007EFC33FE0771
00007efc33fdc63d  movaps xmm15, xmm11
00007efc33fdc641  addpd xmm15, xmm6
00007efc33fdc646  vcmppd xmm9, xmm15, xmm15, 0x03
00007efc33fdc64c  ptest xmm9, xmm9
00007efc33fdc652  jnz 0x00007EFC33FE08B5
00007efc33fdc658  movaps xmm11, [r15+0x1E0]
00007efc33fdc660  vmovaps xmm9, [rsp+0x10]
00007efc33fdc666  vpermilpd xmm9, xmm9, 0x00
00007efc33fdc66c  movaps xmm7, xmm11
00007efc33fdc670  mulpd xmm7, xmm9
00007efc33fdc675  vcmppd xmm6, xmm7, xmm7, 0x03
00007efc33fdc67a  ptest xmm6, xmm6
00007efc33fdc67f  jnz 0x00007EFC33FE09F8
00007efc33fdc685  movaps xmm11, xmm10
00007efc33fdc689  addpd xmm11, xmm14
00007efc33fdc68e  vcmppd xmm9, xmm11, xmm11, 0x03
00007efc33fdc694  ptest xmm9, xmm9
00007efc33fdc69a  jnz 0x00007EFC33FE0B3A
00007efc33fdc6a0  lea r12, [rax+0x70]
00007efc33fdc6a4  movups xmm14, [r13+r12*1]
00007efc33fdc6aa  movaps [r15+0x240], xmm14
00007efc33fdc6b2  movaps xmm10, xmm1
00007efc33fdc6b6  addpd xmm10, xmm12
00007efc33fdc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
00007efc33fdc6c1  ptest xmm9, xmm9
00007efc33fdc6c7  jnz 0x00007EFC33FE0C88
00007efc33fdc6cd  movaps [r15+0x170], xmm10
00007efc33fdc6d5  vmovaps xmm1, [rsp+0x20]
00007efc33fdc6db  vpermilpd xmm1, xmm1, 0x00
00007efc33fdc6e1  movaps xmm12, xmm14
00007efc33fdc6e5  mulpd xmm12, xmm1
00007efc33fdc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
00007efc33fdc6f0  ptest xmm9, xmm9
00007efc33fdc6f6  jnz 0x00007EFC33FE0DCB
00007efc33fdc6fc  vmovaps xmm1, [rsp+0x20]
00007efc33fdc702  vpermilpd xmm1, xmm1, 0x00
00007efc33fdc708  vmovaps xmm9, [rsp+0xB0]
00007efc33fdc711  movaps xmm14, xmm9
00007efc33fdc715  mulpd xmm14, xmm1
00007efc33fdc71a  vcmppd xmm6, xmm14, xmm14, 0x03
00007efc33fdc720  ptest xmm6, xmm6
00007efc33fdc725  jnz 0x00007EFC33FE0F0E
00007efc33fdc72b  movaps [r15+0x180], xmm14
00007efc33fdc733  movaps xmm1, xmm13
00007efc33fdc737  addpd xmm1, xmm8
00007efc33fdc73c  vcmppd xmm9, xmm1, xmm1, 0x03
00007efc33fdc741  ptest xmm9, xmm9
00007efc33fdc747  jnz 0x00007EFC33FE1051
00007efc33fdc74d  movaps [r15+0x210], xmm1
00007efc33fdc755  movups xmm13, [r13+rax*1]
00007efc33fdc75b  lea r12, [rax+0x10]
00007efc33fdc75f  movups xmm9, [r13+r12*1]
00007efc33fdc765  movaps [r15+0x230], xmm9
00007efc33fdc76d  movaps xmm8, xmm15
00007efc33fdc771  addpd xmm8, xmm7
00007efc33fdc776  vcmppd xmm6, xmm8, xmm8, 0x03
00007efc33fdc77c  ptest xmm6, xmm6
00007efc33fdc781  jnz 0x00007EFC33FE11A7
00007efc33fdc787  movaps [r15+0x130], xmm8
00007efc33fdc78f  vmovaps xmm15, [rsp+0x20]
00007efc33fdc795  vpermilpd xmm15, xmm15, 0x00
00007efc33fdc79b  movaps xmm7, xmm9
00007efc33fdc79f  mulpd xmm7, xmm15
00007efc33fdc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
00007efc33fdc7a9  ptest xmm6, xmm6
00007efc33fdc7ae  jnz 0x00007EFC33FE12EA
00007efc33fdc7b4  movaps [r15+0x220], xmm7
00007efc33fdc7bc  vmovaps xmm15, [rsp+0x20]
00007efc33fdc7c2  vpermilpd xmm15, xmm15, 0x00
00007efc33fdc7c8  movaps xmm9, xmm13
00007efc33fdc7cc  mulpd xmm9, xmm15
00007efc33fdc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
00007efc33fdc7d7  ptest xmm6, xmm6
00007efc33fdc7dc  jnz 0x00007EFC33FE142C
00007efc33fdc7e2  movaps xmm15, xmm11
00007efc33fdc7e6  addpd xmm15, xmm12
00007efc33fdc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
00007efc33fdc7f1  ptest xmm13, xmm13
00007efc33fdc7f7  jnz 0x00007EFC33FE1570
00007efc33fdc7fd  movaps [r15+0x140], xmm15
00007efc33fdc805  movaps xmm13, xmm10
00007efc33fdc809  addpd xmm13, xmm14
00007efc33fdc80e  vcmppd xmm12, xmm13, xmm13, 0x03
00007efc33fdc814  ptest xmm12, xmm12
00007efc33fdc81a  jnz 0x00007EFC33FE16B4
00007efc33fdc820  movaps [r15+0x150], xmm13
00007efc33fdc828  movaps xmm14, xmm1
00007efc33fdc82c  addpd xmm14, xmm7
00007efc33fdc831  vcmppd xmm12, xmm14, xmm14, 0x03
00007efc33fdc837  ptest xmm12, xmm12
00007efc33fdc83d  jnz 0x00007EFC33FE17F8
00007efc33fdc843  movaps [r15+0x160], xmm14
00007efc33fdc84b  movaps xmm1, xmm8
00007efc33fdc84f  addpd xmm1, xmm9
00007efc33fdc854  vcmppd xmm12, xmm1, xmm1, 0x03
00007efc33fdc859  ptest xmm12, xmm12
00007efc33fdc85f  jnz 0x00007EFC33FE193A
00007efc33fdc865  movaps [r15+0x120], xmm1
00007efc33fdc86d  movups [r13+r14*1], xmm15
00007efc33fdc873  lea rax, [r14+0x10]
00007efc33fdc877  movups [r13+rax*1], xmm13
00007efc33fdc87d  lea rax, [r14+0x20]
00007efc33fdc881  movups [r13+rax*1], xmm14
00007efc33fdc887  lea rax, [r14+0x30]
00007efc33fdc88b  movups [r13+rax*1], xmm1
00007efc33fdc891  mov eax, [r15+0x108]
00007efc33fdc898  sahf
00007efc33fdc899  jnz 0x00007EFC33FDC8CB
00007efc33fdc89b  cmp dword ptr [r15+0x318], 0x00
00007efc33fdc8a3  jz 0x00007EFC33FDB900
00007efc33fdc8a9  nop [rax+rax*1], ax
00007efc33fdc8b2  nop [rax+rax*1], eax
00007efc33fdc8ba  mov eax, 0x410444
00007efc33fdc8bf  mov [r15+0x100], rax
00007efc33fdc8c6  jmp 0x00007EFC33DFE110
00007efc33fdc8cb  cmp dword ptr [r15+0x318], 0x00
00007efc33fdc8d3  jz 0x00007EFC33FD57E0
00007efc33fdc8d9  nop [rax+rax*1], ax
00007efc33fdc8e2  nop [rax+rax*1], eax
00007efc33fdc8ea  mov eax, 0x410278
00007efc33fdc8ef  mov [r15+0x100], rax
00007efc33fdc8f6  jmp 0x00007EFC33DFE110
00007efc33fdc8fb  int3
00007efc33fdc8fc  call 0x00007EFC33EE27E0
00007efc33fdc901  jmp 0x00007EFC33FDB9DF
00007efc33fdc906  call 0x00007EFC33EE1570
00007efc33fdc90b  jmp 0x00007EFC33FDB9E8
00007efc33fdc910  call 0x00007EFC33EE27E0
00007efc33fdc915  jmp 0x00007EFC33FDBA44
00007efc33fdc91a  call 0x00007EFC33EE1570
00007efc33fdc91f  jmp 0x00007EFC33FDBA4D
00007efc33fdc924  call 0x00007EFC33EE27E0
00007efc33fdc929  jmp 0x00007EFC33FDBA90
00007efc33fdc92e  call 0x00007EFC33EE1570
00007efc33fdc933  jmp 0x00007EFC33FDBA99
00007efc33fdc938  call 0x00007EFC33E0DC20
00007efc33fdc93d  jmp 0x00007EFC33FDBAD8
00007efc33fdc942  call 0x00007EFC33ED59C0
00007efc33fdc947  jmp 0x00007EFC33FDBAEB
00007efc33fdc94c  call 0x00007EFC33EE0E30
00007efc33fdc951  jmp 0x00007EFC33FDBB09
00007efc33fdc956  call 0x00007EFC33EDFBC0
00007efc33fdc95b  jmp 0x00007EFC33FDBB13
00007efc33fdc960  call 0x00007EFC33EDE950
00007efc33fdc965  jmp 0x00007EFC33FDBB1D
00007efc33fdc96a  sub rsp, 0x08
00007efc33fdc96e  push rax
00007efc33fdc96f  push rcx
00007efc33fdc970  push rdx
00007efc33fdc971  push rdi
00007efc33fdc972  push rsi
00007efc33fdc973  push r8
00007efc33fdc975  push r9
00007efc33fdc977  push r10
00007efc33fdc979  push r11
00007efc33fdc97b  sub rsp, 0xF0
00007efc33fdc982  vmovaps [rsp], xmm0
00007efc33fdc987  vmovaps [rsp+0x10], xmm1
00007efc33fdc98d  vmovaps [rsp+0x20], xmm2
00007efc33fdc993  vmovaps [rsp+0x30], xmm3
00007efc33fdc999  vmovaps [rsp+0x40], xmm4
00007efc33fdc99f  vmovaps [rsp+0x50], xmm5
00007efc33fdc9a5  vmovaps [rsp+0x60], xmm6
00007efc33fdc9ab  vmovaps [rsp+0x70], xmm7
00007efc33fdc9b1  vmovaps [rsp+0x80], xmm9
00007efc33fdc9ba  vmovaps [rsp+0x90], xmm10
00007efc33fdc9c3  vmovaps [rsp+0xA0], xmm11
00007efc33fdc9cc  vmovaps [rsp+0xB0], xmm12
00007efc33fdc9d5  vmovaps [rsp+0xC0], xmm13
00007efc33fdc9de  vmovaps [rsp+0xD0], xmm14
00007efc33fdc9e7  vmovaps [rsp+0xE0], xmm15
00007efc33fdc9f0  sub rsp, 0x30
00007efc33fdc9f4  movaps [rsp], xmm8
00007efc33fdc9f9  movaps [rsp+0x10], xmm12
00007efc33fdc9ff  movaps [rsp+0x20], xmm15
00007efc33fdca05  lea rdi, [rsp]
00007efc33fdca09  mov esi, 0x00
00007efc33fdca0e  mov rax, 0x5D9448894530
00007efc33fdca18  call rax
00007efc33fdca1a  movaps xmm8, [rsp]
00007efc33fdca1f  add rsp, 0x30
00007efc33fdca23  vmovaps xmm0, [rsp]
00007efc33fdca28  vmovaps xmm1, [rsp+0x10]
00007efc33fdca2e  vmovaps xmm2, [rsp+0x20]
00007efc33fdca34  vmovaps xmm3, [rsp+0x30]
00007efc33fdca3a  vmovaps xmm4, [rsp+0x40]
00007efc33fdca40  vmovaps xmm5, [rsp+0x50]
00007efc33fdca46  vmovaps xmm6, [rsp+0x60]
00007efc33fdca4c  vmovaps xmm7, [rsp+0x70]
00007efc33fdca52  vmovaps xmm9, [rsp+0x80]
00007efc33fdca5b  vmovaps xmm10, [rsp+0x90]
00007efc33fdca64  vmovaps xmm11, [rsp+0xA0]
00007efc33fdca6d  vmovaps xmm12, [rsp+0xB0]
00007efc33fdca76  vmovaps xmm13, [rsp+0xC0]
00007efc33fdca7f  vmovaps xmm14, [rsp+0xD0]
00007efc33fdca88  vmovaps xmm15, [rsp+0xE0]
00007efc33fdca91  add rsp, 0xF0
00007efc33fdca98  pop r11
00007efc33fdca9a  pop r10
00007efc33fdca9c  pop r9
00007efc33fdca9e  pop r8
00007efc33fdcaa0  pop rsi
00007efc33fdcaa1  pop rdi
00007efc33fdcaa2  pop rdx
00007efc33fdcaa3  pop rcx
00007efc33fdcaa4  pop rax
00007efc33fdcaa5  add rsp, 0x08
00007efc33fdcaa9  jmp 0x00007EFC33FDBB47
00007efc33fdcaae  sub rsp, 0x08
00007efc33fdcab2  push rax
00007efc33fdcab3  push rcx
00007efc33fdcab4  push rdx
00007efc33fdcab5  push rdi
00007efc33fdcab6  push rsi
00007efc33fdcab7  push r8
00007efc33fdcab9  push r9
00007efc33fdcabb  push r10
00007efc33fdcabd  push r11
00007efc33fdcabf  sub rsp, 0xF0
00007efc33fdcac6  vmovaps [rsp], xmm0
00007efc33fdcacb  vmovaps [rsp+0x10], xmm1
00007efc33fdcad1  vmovaps [rsp+0x20], xmm2
00007efc33fdcad7  vmovaps [rsp+0x30], xmm3
00007efc33fdcadd  vmovaps [rsp+0x40], xmm4
00007efc33fdcae3  vmovaps [rsp+0x50], xmm5
00007efc33fdcae9  vmovaps [rsp+0x60], xmm6
00007efc33fdcaef  vmovaps [rsp+0x70], xmm8
00007efc33fdcaf5  vmovaps [rsp+0x80], xmm9
00007efc33fdcafe  vmovaps [rsp+0x90], xmm10
00007efc33fdcb07  vmovaps [rsp+0xA0], xmm11
00007efc33fdcb10  vmovaps [rsp+0xB0], xmm12
00007efc33fdcb19  vmovaps [rsp+0xC0], xmm13
00007efc33fdcb22  vmovaps [rsp+0xD0], xmm14
00007efc33fdcb2b  vmovaps [rsp+0xE0], xmm15
00007efc33fdcb34  sub rsp, 0x30
00007efc33fdcb38  movaps [rsp], xmm7
00007efc33fdcb3c  movaps [rsp+0x10], xmm9
00007efc33fdcb42  movaps [rsp+0x20], xmm15
00007efc33fdcb48  lea rdi, [rsp]
00007efc33fdcb4c  mov esi, 0x00
00007efc33fdcb51  mov rax, 0x5D9448894530
00007efc33fdcb5b  call rax
00007efc33fdcb5d  movaps xmm7, [rsp]
00007efc33fdcb61  add rsp, 0x30
00007efc33fdcb65  vmovaps xmm0, [rsp]
00007efc33fdcb6a  vmovaps xmm1, [rsp+0x10]
00007efc33fdcb70  vmovaps xmm2, [rsp+0x20]
00007efc33fdcb76  vmovaps xmm3, [rsp+0x30]
00007efc33fdcb7c  vmovaps xmm4, [rsp+0x40]
00007efc33fdcb82  vmovaps xmm5, [rsp+0x50]
00007efc33fdcb88  vmovaps xmm6, [rsp+0x60]
00007efc33fdcb8e  vmovaps xmm8, [rsp+0x70]
00007efc33fdcb94  vmovaps xmm9, [rsp+0x80]
00007efc33fdcb9d  vmovaps xmm10, [rsp+0x90]
00007efc33fdcba6  vmovaps xmm11, [rsp+0xA0]
00007efc33fdcbaf  vmovaps xmm12, [rsp+0xB0]
00007efc33fdcbb8  vmovaps xmm13, [rsp+0xC0]
00007efc33fdcbc1  vmovaps xmm14, [rsp+0xD0]
00007efc33fdcbca  vmovaps xmm15, [rsp+0xE0]
00007efc33fdcbd3  add rsp, 0xF0
00007efc33fdcbda  pop r11
00007efc33fdcbdc  pop r10
00007efc33fdcbde  pop r9
00007efc33fdcbe0  pop r8
00007efc33fdcbe2  pop rsi
00007efc33fdcbe3  pop rdi
00007efc33fdcbe4  pop rdx
00007efc33fdcbe5  pop rcx
00007efc33fdcbe6  pop rax
00007efc33fdcbe7  add rsp, 0x08
00007efc33fdcbeb  jmp 0x00007EFC33FDBB75
00007efc33fdcbf0  sub rsp, 0x08
00007efc33fdcbf4  push rax
00007efc33fdcbf5  push rcx
00007efc33fdcbf6  push rdx
00007efc33fdcbf7  push rdi
00007efc33fdcbf8  push rsi
00007efc33fdcbf9  push r8
00007efc33fdcbfb  push r9
00007efc33fdcbfd  push r10
00007efc33fdcbff  push r11
00007efc33fdcc01  sub rsp, 0xF0
00007efc33fdcc08  vmovaps [rsp], xmm0
00007efc33fdcc0d  vmovaps [rsp+0x10], xmm1
00007efc33fdcc13  vmovaps [rsp+0x20], xmm2
00007efc33fdcc19  vmovaps [rsp+0x30], xmm3
00007efc33fdcc1f  vmovaps [rsp+0x40], xmm4
00007efc33fdcc25  vmovaps [rsp+0x50], xmm5
00007efc33fdcc2b  vmovaps [rsp+0x60], xmm6
00007efc33fdcc31  vmovaps [rsp+0x70], xmm7
00007efc33fdcc37  vmovaps [rsp+0x80], xmm8
00007efc33fdcc40  vmovaps [rsp+0x90], xmm10
00007efc33fdcc49  vmovaps [rsp+0xA0], xmm11
00007efc33fdcc52  vmovaps [rsp+0xB0], xmm12
00007efc33fdcc5b  vmovaps [rsp+0xC0], xmm13
00007efc33fdcc64  vmovaps [rsp+0xD0], xmm14
00007efc33fdcc6d  vmovaps [rsp+0xE0], xmm15
00007efc33fdcc76  sub rsp, 0x30
00007efc33fdcc7a  movaps [rsp], xmm9
00007efc33fdcc7f  movaps [rsp+0x10], xmm12
00007efc33fdcc85  movaps [rsp+0x20], xmm10
00007efc33fdcc8b  lea rdi, [rsp]
00007efc33fdcc8f  mov esi, 0x00
00007efc33fdcc94  mov rax, 0x5D9448894530
00007efc33fdcc9e  call rax
00007efc33fdcca0  movaps xmm9, [rsp]
00007efc33fdcca5  add rsp, 0x30
00007efc33fdcca9  vmovaps xmm0, [rsp]
00007efc33fdccae  vmovaps xmm1, [rsp+0x10]
00007efc33fdccb4  vmovaps xmm2, [rsp+0x20]
00007efc33fdccba  vmovaps xmm3, [rsp+0x30]
00007efc33fdccc0  vmovaps xmm4, [rsp+0x40]
00007efc33fdccc6  vmovaps xmm5, [rsp+0x50]
00007efc33fdcccc  vmovaps xmm6, [rsp+0x60]
00007efc33fdccd2  vmovaps xmm7, [rsp+0x70]
00007efc33fdccd8  vmovaps xmm8, [rsp+0x80]
00007efc33fdcce1  vmovaps xmm10, [rsp+0x90]
00007efc33fdccea  vmovaps xmm11, [rsp+0xA0]
00007efc33fdccf3  vmovaps xmm12, [rsp+0xB0]
00007efc33fdccfc  vmovaps xmm13, [rsp+0xC0]
00007efc33fdcd05  vmovaps xmm14, [rsp+0xD0]
00007efc33fdcd0e  vmovaps xmm15, [rsp+0xE0]
00007efc33fdcd17  add rsp, 0xF0
00007efc33fdcd1e  pop r11
00007efc33fdcd20  pop r10
00007efc33fdcd22  pop r9
00007efc33fdcd24  pop r8
00007efc33fdcd26  pop rsi
00007efc33fdcd27  pop rdi
00007efc33fdcd28  pop rdx
00007efc33fdcd29  pop rcx
00007efc33fdcd2a  pop rax
00007efc33fdcd2b  add rsp, 0x08
00007efc33fdcd2f  jmp 0x00007EFC33FDBB99
00007efc33fdcd34  sub rsp, 0x08
00007efc33fdcd38  push rax
00007efc33fdcd39  push rcx
00007efc33fdcd3a  push rdx
00007efc33fdcd3b  push rdi
00007efc33fdcd3c  push rsi
00007efc33fdcd3d  push r8
00007efc33fdcd3f  push r9
00007efc33fdcd41  push r10
00007efc33fdcd43  push r11
00007efc33fdcd45  sub rsp, 0xF0
00007efc33fdcd4c  vmovaps [rsp], xmm0
00007efc33fdcd51  vmovaps [rsp+0x10], xmm1
00007efc33fdcd57  vmovaps [rsp+0x20], xmm2
00007efc33fdcd5d  vmovaps [rsp+0x30], xmm3
00007efc33fdcd63  vmovaps [rsp+0x40], xmm4
00007efc33fdcd69  vmovaps [rsp+0x50], xmm5
00007efc33fdcd6f  vmovaps [rsp+0x60], xmm6
00007efc33fdcd75  vmovaps [rsp+0x70], xmm7
00007efc33fdcd7b  vmovaps [rsp+0x80], xmm8
00007efc33fdcd84  vmovaps [rsp+0x90], xmm9
00007efc33fdcd8d  vmovaps [rsp+0xA0], xmm11
00007efc33fdcd96  vmovaps [rsp+0xB0], xmm12
00007efc33fdcd9f  vmovaps [rsp+0xC0], xmm13
00007efc33fdcda8  vmovaps [rsp+0xD0], xmm14
00007efc33fdcdb1  vmovaps [rsp+0xE0], xmm15
00007efc33fdcdba  sub rsp, 0x30
00007efc33fdcdbe  movaps [rsp], xmm10
00007efc33fdcdc3  movaps [rsp+0x10], xmm12
00007efc33fdcdc9  movaps [rsp+0x20], xmm11
00007efc33fdcdcf  lea rdi, [rsp]
00007efc33fdcdd3  mov esi, 0x00
00007efc33fdcdd8  mov rax, 0x5D9448894530
00007efc33fdcde2  call rax
00007efc33fdcde4  movaps xmm10, [rsp]
00007efc33fdcde9  add rsp, 0x30
00007efc33fdcded  vmovaps xmm0, [rsp]
00007efc33fdcdf2  vmovaps xmm1, [rsp+0x10]
00007efc33fdcdf8  vmovaps xmm2, [rsp+0x20]
00007efc33fdcdfe  vmovaps xmm3, [rsp+0x30]
00007efc33fdce04  vmovaps xmm4, [rsp+0x40]
00007efc33fdce0a  vmovaps xmm5, [rsp+0x50]
00007efc33fdce10  vmovaps xmm6, [rsp+0x60]
00007efc33fdce16  vmovaps xmm7, [rsp+0x70]
00007efc33fdce1c  vmovaps xmm8, [rsp+0x80]
00007efc33fdce25  vmovaps xmm9, [rsp+0x90]
00007efc33fdce2e  vmovaps xmm11, [rsp+0xA0]
00007efc33fdce37  vmovaps xmm12, [rsp+0xB0]
00007efc33fdce40  vmovaps xmm13, [rsp+0xC0]
00007efc33fdce49  vmovaps xmm14, [rsp+0xD0]
00007efc33fdce52  vmovaps xmm15, [rsp+0xE0]
00007efc33fdce5b  add rsp, 0xF0
00007efc33fdce62  pop r11
00007efc33fdce64  pop r10
00007efc33fdce66  pop r9
00007efc33fdce68  pop r8
00007efc33fdce6a  pop rsi
00007efc33fdce6b  pop rdi
00007efc33fdce6c  pop rdx
00007efc33fdce6d  pop rcx
00007efc33fdce6e  pop rax
00007efc33fdce6f  add rsp, 0x08
00007efc33fdce73  jmp 0x00007EFC33FDBBB3
00007efc33fdce78  sub rsp, 0x08
00007efc33fdce7c  push rax
00007efc33fdce7d  push rcx
00007efc33fdce7e  push rdx
00007efc33fdce7f  push rdi
00007efc33fdce80  push rsi
00007efc33fdce81  push r8
00007efc33fdce83  push r9
00007efc33fdce85  push r10
00007efc33fdce87  push r11
00007efc33fdce89  sub rsp, 0xF0
00007efc33fdce90  vmovaps [rsp], xmm0
00007efc33fdce95  vmovaps [rsp+0x10], xmm1
00007efc33fdce9b  vmovaps [rsp+0x20], xmm2
00007efc33fdcea1  vmovaps [rsp+0x30], xmm3
00007efc33fdcea7  vmovaps [rsp+0x40], xmm4
00007efc33fdcead  vmovaps [rsp+0x50], xmm5
00007efc33fdceb3  vmovaps [rsp+0x60], xmm7
00007efc33fdceb9  vmovaps [rsp+0x70], xmm8
00007efc33fdcebf  vmovaps [rsp+0x80], xmm9
00007efc33fdcec8  vmovaps [rsp+0x90], xmm10
00007efc33fdced1  vmovaps [rsp+0xA0], xmm11
00007efc33fdceda  vmovaps [rsp+0xB0], xmm12
00007efc33fdcee3  vmovaps [rsp+0xC0], xmm13
00007efc33fdceec  vmovaps [rsp+0xD0], xmm14
00007efc33fdcef5  vmovaps [rsp+0xE0], xmm15
00007efc33fdcefe  sub rsp, 0x30
00007efc33fdcf02  movaps [rsp], xmm6
00007efc33fdcf06  movaps [rsp+0x10], xmm12
00007efc33fdcf0c  movaps [rsp+0x20], xmm11
00007efc33fdcf12  lea rdi, [rsp]
00007efc33fdcf16  mov esi, 0x00
00007efc33fdcf1b  mov rax, 0x5D9448894530
00007efc33fdcf25  call rax
00007efc33fdcf27  movaps xmm6, [rsp]
00007efc33fdcf2b  add rsp, 0x30
00007efc33fdcf2f  vmovaps xmm0, [rsp]
00007efc33fdcf34  vmovaps xmm1, [rsp+0x10]
00007efc33fdcf3a  vmovaps xmm2, [rsp+0x20]
00007efc33fdcf40  vmovaps xmm3, [rsp+0x30]
00007efc33fdcf46  vmovaps xmm4, [rsp+0x40]
00007efc33fdcf4c  vmovaps xmm5, [rsp+0x50]
00007efc33fdcf52  vmovaps xmm7, [rsp+0x60]
00007efc33fdcf58  vmovaps xmm8, [rsp+0x70]
00007efc33fdcf5e  vmovaps xmm9, [rsp+0x80]
00007efc33fdcf67  vmovaps xmm10, [rsp+0x90]
00007efc33fdcf70  vmovaps xmm11, [rsp+0xA0]
00007efc33fdcf79  vmovaps xmm12, [rsp+0xB0]
00007efc33fdcf82  vmovaps xmm13, [rsp+0xC0]
00007efc33fdcf8b  vmovaps xmm14, [rsp+0xD0]
00007efc33fdcf94  vmovaps xmm15, [rsp+0xE0]
00007efc33fdcf9d  add rsp, 0xF0
00007efc33fdcfa4  pop r11
00007efc33fdcfa6  pop r10
00007efc33fdcfa8  pop r9
00007efc33fdcfaa  pop r8
00007efc33fdcfac  pop rsi
00007efc33fdcfad  pop rdi
00007efc33fdcfae  pop rdx
00007efc33fdcfaf  pop rcx
00007efc33fdcfb0  pop rax
00007efc33fdcfb1  add rsp, 0x08
00007efc33fdcfb5  jmp 0x00007EFC33FDBBD4
00007efc33fdcfba  sub rsp, 0x08
00007efc33fdcfbe  push rax
00007efc33fdcfbf  push rcx
00007efc33fdcfc0  push rdx
00007efc33fdcfc1  push rdi
00007efc33fdcfc2  push rsi
00007efc33fdcfc3  push r8
00007efc33fdcfc5  push r9
00007efc33fdcfc7  push r10
00007efc33fdcfc9  push r11
00007efc33fdcfcb  sub rsp, 0xF0
00007efc33fdcfd2  vmovaps [rsp], xmm0
00007efc33fdcfd7  vmovaps [rsp+0x10], xmm1
00007efc33fdcfdd  vmovaps [rsp+0x20], xmm2
00007efc33fdcfe3  vmovaps [rsp+0x30], xmm4
00007efc33fdcfe9  vmovaps [rsp+0x40], xmm5
00007efc33fdcfef  vmovaps [rsp+0x50], xmm6
00007efc33fdcff5  vmovaps [rsp+0x60], xmm7
00007efc33fdcffb  vmovaps [rsp+0x70], xmm8
00007efc33fdd001  vmovaps [rsp+0x80], xmm9
00007efc33fdd00a  vmovaps [rsp+0x90], xmm10
00007efc33fdd013  vmovaps [rsp+0xA0], xmm11
00007efc33fdd01c  vmovaps [rsp+0xB0], xmm12
00007efc33fdd025  vmovaps [rsp+0xC0], xmm13
00007efc33fdd02e  vmovaps [rsp+0xD0], xmm14
00007efc33fdd037  vmovaps [rsp+0xE0], xmm15
00007efc33fdd040  sub rsp, 0x30
00007efc33fdd044  movaps [rsp], xmm3
00007efc33fdd048  movaps [rsp+0x10], xmm5
00007efc33fdd04d  movaps [rsp+0x20], xmm4
00007efc33fdd052  lea rdi, [rsp]
00007efc33fdd056  mov esi, 0x00
00007efc33fdd05b  mov rax, 0x5D9448894530
00007efc33fdd065  call rax
00007efc33fdd067  movaps xmm3, [rsp]
00007efc33fdd06b  add rsp, 0x30
00007efc33fdd06f  vmovaps xmm0, [rsp]
00007efc33fdd074  vmovaps xmm1, [rsp+0x10]
00007efc33fdd07a  vmovaps xmm2, [rsp+0x20]
00007efc33fdd080  vmovaps xmm4, [rsp+0x30]
00007efc33fdd086  vmovaps xmm5, [rsp+0x40]
00007efc33fdd08c  vmovaps xmm6, [rsp+0x50]
00007efc33fdd092  vmovaps xmm7, [rsp+0x60]
00007efc33fdd098  vmovaps xmm8, [rsp+0x70]
00007efc33fdd09e  vmovaps xmm9, [rsp+0x80]
00007efc33fdd0a7  vmovaps xmm10, [rsp+0x90]
00007efc33fdd0b0  vmovaps xmm11, [rsp+0xA0]
00007efc33fdd0b9  vmovaps xmm12, [rsp+0xB0]
00007efc33fdd0c2  vmovaps xmm13, [rsp+0xC0]
00007efc33fdd0cb  vmovaps xmm14, [rsp+0xD0]
00007efc33fdd0d4  vmovaps xmm15, [rsp+0xE0]
00007efc33fdd0dd  add rsp, 0xF0
00007efc33fdd0e4  pop r11
00007efc33fdd0e6  pop r10
00007efc33fdd0e8  pop r9
00007efc33fdd0ea  pop r8
00007efc33fdd0ec  pop rsi
00007efc33fdd0ed  pop rdi
00007efc33fdd0ee  pop rdx
00007efc33fdd0ef  pop rcx
00007efc33fdd0f0  pop rax
00007efc33fdd0f1  add rsp, 0x08
00007efc33fdd0f5  jmp 0x00007EFC33FDBC35
00007efc33fdd0fa  sub rsp, 0x08
00007efc33fdd0fe  push rax
00007efc33fdd0ff  push rcx
00007efc33fdd100  push rdx
00007efc33fdd101  push rdi
00007efc33fdd102  push rsi
00007efc33fdd103  push r8
00007efc33fdd105  push r9
00007efc33fdd107  push r10
00007efc33fdd109  push r11
00007efc33fdd10b  sub rsp, 0xF0
00007efc33fdd112  vmovaps [rsp], xmm0
00007efc33fdd117  vmovaps [rsp+0x10], xmm1
00007efc33fdd11d  vmovaps [rsp+0x20], xmm2
00007efc33fdd123  vmovaps [rsp+0x30], xmm3
00007efc33fdd129  vmovaps [rsp+0x40], xmm4
00007efc33fdd12f  vmovaps [rsp+0x50], xmm6
00007efc33fdd135  vmovaps [rsp+0x60], xmm7
00007efc33fdd13b  vmovaps [rsp+0x70], xmm8
00007efc33fdd141  vmovaps [rsp+0x80], xmm9
00007efc33fdd14a  vmovaps [rsp+0x90], xmm10
00007efc33fdd153  vmovaps [rsp+0xA0], xmm11
00007efc33fdd15c  vmovaps [rsp+0xB0], xmm12
00007efc33fdd165  vmovaps [rsp+0xC0], xmm13
00007efc33fdd16e  vmovaps [rsp+0xD0], xmm14
00007efc33fdd177  vmovaps [rsp+0xE0], xmm15
00007efc33fdd180  sub rsp, 0x30
00007efc33fdd184  movaps [rsp], xmm5
00007efc33fdd188  movaps [rsp+0x10], xmm8
00007efc33fdd18e  movaps [rsp+0x20], xmm15
00007efc33fdd194  lea rdi, [rsp]
00007efc33fdd198  mov esi, 0x00
00007efc33fdd19d  mov rax, 0x5D9448894530
00007efc33fdd1a7  call rax
00007efc33fdd1a9  movaps xmm5, [rsp]
00007efc33fdd1ad  add rsp, 0x30
00007efc33fdd1b1  vmovaps xmm0, [rsp]
00007efc33fdd1b6  vmovaps xmm1, [rsp+0x10]
00007efc33fdd1bc  vmovaps xmm2, [rsp+0x20]
00007efc33fdd1c2  vmovaps xmm3, [rsp+0x30]
00007efc33fdd1c8  vmovaps xmm4, [rsp+0x40]
00007efc33fdd1ce  vmovaps xmm6, [rsp+0x50]
00007efc33fdd1d4  vmovaps xmm7, [rsp+0x60]
00007efc33fdd1da  vmovaps xmm8, [rsp+0x70]
00007efc33fdd1e0  vmovaps xmm9, [rsp+0x80]
00007efc33fdd1e9  vmovaps xmm10, [rsp+0x90]
00007efc33fdd1f2  vmovaps xmm11, [rsp+0xA0]
00007efc33fdd1fb  vmovaps xmm12, [rsp+0xB0]
00007efc33fdd204  vmovaps xmm13, [rsp+0xC0]
00007efc33fdd20d  vmovaps xmm14, [rsp+0xD0]
00007efc33fdd216  vmovaps xmm15, [rsp+0xE0]
00007efc33fdd21f  add rsp, 0xF0
00007efc33fdd226  pop r11
00007efc33fdd228  pop r10
00007efc33fdd22a  pop r9
00007efc33fdd22c  pop r8
00007efc33fdd22e  pop rsi
00007efc33fdd22f  pop rdi
00007efc33fdd230  pop rdx
00007efc33fdd231  pop rcx
00007efc33fdd232  pop rax
00007efc33fdd233  add rsp, 0x08
00007efc33fdd237  jmp 0x00007EFC33FDBC73
00007efc33fdd23c  sub rsp, 0x08
00007efc33fdd240  push rax
00007efc33fdd241  push rcx
00007efc33fdd242  push rdx
00007efc33fdd243  push rdi
00007efc33fdd244  push rsi
00007efc33fdd245  push r8
00007efc33fdd247  push r9
00007efc33fdd249  push r10
00007efc33fdd24b  push r11
00007efc33fdd24d  sub rsp, 0xF0
00007efc33fdd254  vmovaps [rsp], xmm0
00007efc33fdd259  vmovaps [rsp+0x10], xmm1
00007efc33fdd25f  vmovaps [rsp+0x20], xmm2
00007efc33fdd265  vmovaps [rsp+0x30], xmm3
00007efc33fdd26b  vmovaps [rsp+0x40], xmm5
00007efc33fdd271  vmovaps [rsp+0x50], xmm6
00007efc33fdd277  vmovaps [rsp+0x60], xmm7
00007efc33fdd27d  vmovaps [rsp+0x70], xmm8
00007efc33fdd283  vmovaps [rsp+0x80], xmm9
00007efc33fdd28c  vmovaps [rsp+0x90], xmm10
00007efc33fdd295  vmovaps [rsp+0xA0], xmm11
00007efc33fdd29e  vmovaps [rsp+0xB0], xmm12
00007efc33fdd2a7  vmovaps [rsp+0xC0], xmm13
00007efc33fdd2b0  vmovaps [rsp+0xD0], xmm14
00007efc33fdd2b9  vmovaps [rsp+0xE0], xmm15
00007efc33fdd2c2  sub rsp, 0x30
00007efc33fdd2c6  movaps [rsp], xmm4
00007efc33fdd2ca  movaps [rsp+0x10], xmm9
00007efc33fdd2d0  movaps [rsp+0x20], xmm8
00007efc33fdd2d6  lea rdi, [rsp]
00007efc33fdd2da  mov esi, 0x00
00007efc33fdd2df  mov rax, 0x5D9448894530
00007efc33fdd2e9  call rax
00007efc33fdd2eb  movaps xmm4, [rsp]
00007efc33fdd2ef  add rsp, 0x30
00007efc33fdd2f3  vmovaps xmm0, [rsp]
00007efc33fdd2f8  vmovaps xmm1, [rsp+0x10]
00007efc33fdd2fe  vmovaps xmm2, [rsp+0x20]
00007efc33fdd304  vmovaps xmm3, [rsp+0x30]
00007efc33fdd30a  vmovaps xmm5, [rsp+0x40]
00007efc33fdd310  vmovaps xmm6, [rsp+0x50]
00007efc33fdd316  vmovaps xmm7, [rsp+0x60]
00007efc33fdd31c  vmovaps xmm8, [rsp+0x70]
00007efc33fdd322  vmovaps xmm9, [rsp+0x80]
00007efc33fdd32b  vmovaps xmm10, [rsp+0x90]
00007efc33fdd334  vmovaps xmm11, [rsp+0xA0]
00007efc33fdd33d  vmovaps xmm12, [rsp+0xB0]
00007efc33fdd346  vmovaps xmm13, [rsp+0xC0]
00007efc33fdd34f  vmovaps xmm14, [rsp+0xD0]
00007efc33fdd358  vmovaps xmm15, [rsp+0xE0]
00007efc33fdd361  add rsp, 0xF0
00007efc33fdd368  pop r11
00007efc33fdd36a  pop r10
00007efc33fdd36c  pop r9
00007efc33fdd36e  pop r8
00007efc33fdd370  pop rsi
00007efc33fdd371  pop rdi
00007efc33fdd372  pop rdx
00007efc33fdd373  pop rcx
00007efc33fdd374  pop rax
00007efc33fdd375  add rsp, 0x08
00007efc33fdd379  jmp 0x00007EFC33FDBC94
00007efc33fdd37e  sub rsp, 0x08
00007efc33fdd382  push rax
00007efc33fdd383  push rcx
00007efc33fdd384  push rdx
00007efc33fdd385  push rdi
00007efc33fdd386  push rsi
00007efc33fdd387  push r8
00007efc33fdd389  push r9
00007efc33fdd38b  push r10
00007efc33fdd38d  push r11
00007efc33fdd38f  sub rsp, 0xF0
00007efc33fdd396  vmovaps [rsp], xmm0
00007efc33fdd39b  vmovaps [rsp+0x10], xmm1
00007efc33fdd3a1  vmovaps [rsp+0x20], xmm2
00007efc33fdd3a7  vmovaps [rsp+0x30], xmm3
00007efc33fdd3ad  vmovaps [rsp+0x40], xmm4
00007efc33fdd3b3  vmovaps [rsp+0x50], xmm5
00007efc33fdd3b9  vmovaps [rsp+0x60], xmm6
00007efc33fdd3bf  vmovaps [rsp+0x70], xmm7
00007efc33fdd3c5  vmovaps [rsp+0x80], xmm8
00007efc33fdd3ce  vmovaps [rsp+0x90], xmm10
00007efc33fdd3d7  vmovaps [rsp+0xA0], xmm11
00007efc33fdd3e0  vmovaps [rsp+0xB0], xmm12
00007efc33fdd3e9  vmovaps [rsp+0xC0], xmm13
00007efc33fdd3f2  vmovaps [rsp+0xD0], xmm14
00007efc33fdd3fb  vmovaps [rsp+0xE0], xmm15
00007efc33fdd404  sub rsp, 0x30
00007efc33fdd408  movaps [rsp], xmm9
00007efc33fdd40d  movaps [rsp+0x10], xmm10
00007efc33fdd413  movaps [rsp+0x20], xmm8
00007efc33fdd419  lea rdi, [rsp]
00007efc33fdd41d  mov esi, 0x00
00007efc33fdd422  mov rax, 0x5D9448894530
00007efc33fdd42c  call rax
00007efc33fdd42e  movaps xmm9, [rsp]
00007efc33fdd433  add rsp, 0x30
00007efc33fdd437  vmovaps xmm0, [rsp]
00007efc33fdd43c  vmovaps xmm1, [rsp+0x10]
00007efc33fdd442  vmovaps xmm2, [rsp+0x20]
00007efc33fdd448  vmovaps xmm3, [rsp+0x30]
00007efc33fdd44e  vmovaps xmm4, [rsp+0x40]
00007efc33fdd454  vmovaps xmm5, [rsp+0x50]
00007efc33fdd45a  vmovaps xmm6, [rsp+0x60]
00007efc33fdd460  vmovaps xmm7, [rsp+0x70]
00007efc33fdd466  vmovaps xmm8, [rsp+0x80]
00007efc33fdd46f  vmovaps xmm10, [rsp+0x90]
00007efc33fdd478  vmovaps xmm11, [rsp+0xA0]
00007efc33fdd481  vmovaps xmm12, [rsp+0xB0]
00007efc33fdd48a  vmovaps xmm13, [rsp+0xC0]
00007efc33fdd493  vmovaps xmm14, [rsp+0xD0]
00007efc33fdd49c  vmovaps xmm15, [rsp+0xE0]
00007efc33fdd4a5  add rsp, 0xF0
00007efc33fdd4ac  pop r11
00007efc33fdd4ae  pop r10
00007efc33fdd4b0  pop r9
00007efc33fdd4b2  pop r8
00007efc33fdd4b4  pop rsi
00007efc33fdd4b5  pop rdi
00007efc33fdd4b6  pop rdx
00007efc33fdd4b7  pop rcx
00007efc33fdd4b8  pop rax
00007efc33fdd4b9  add rsp, 0x08
00007efc33fdd4bd  jmp 0x00007EFC33FDBCAE
00007efc33fdd4c2  call 0x00007EFC33EB52F0
00007efc33fdd4c7  jmp 0x00007EFC33FDBDC8
00007efc33fdd4cc  call 0x00007EFC33EB52F0
00007efc33fdd4d1  jmp 0x00007EFC33FDBDDE
00007efc33fdd4d6  sub rsp, 0x08
00007efc33fdd4da  push rax
00007efc33fdd4db  push rcx
00007efc33fdd4dc  push rdx
00007efc33fdd4dd  push rdi
00007efc33fdd4de  push rsi
00007efc33fdd4df  push r8
00007efc33fdd4e1  push r9
00007efc33fdd4e3  push r10
00007efc33fdd4e5  push r11
00007efc33fdd4e7  sub rsp, 0xF0
00007efc33fdd4ee  vmovaps [rsp], xmm0
00007efc33fdd4f3  vmovaps [rsp+0x10], xmm2
00007efc33fdd4f9  vmovaps [rsp+0x20], xmm3
00007efc33fdd4ff  vmovaps [rsp+0x30], xmm4
00007efc33fdd505  vmovaps [rsp+0x40], xmm5
00007efc33fdd50b  vmovaps [rsp+0x50], xmm6
00007efc33fdd511  vmovaps [rsp+0x60], xmm7
00007efc33fdd517  vmovaps [rsp+0x70], xmm8
00007efc33fdd51d  vmovaps [rsp+0x80], xmm9
00007efc33fdd526  vmovaps [rsp+0x90], xmm10
00007efc33fdd52f  vmovaps [rsp+0xA0], xmm11
00007efc33fdd538  vmovaps [rsp+0xB0], xmm12
00007efc33fdd541  vmovaps [rsp+0xC0], xmm13
00007efc33fdd54a  vmovaps [rsp+0xD0], xmm14
00007efc33fdd553  vmovaps [rsp+0xE0], xmm15
00007efc33fdd55c  sub rsp, 0x30
00007efc33fdd560  movaps [rsp], xmm1
00007efc33fdd564  movaps [rsp+0x10], xmm6
00007efc33fdd569  movaps [rsp+0x20], xmm15
00007efc33fdd56f  lea rdi, [rsp]
00007efc33fdd573  mov esi, 0x00
00007efc33fdd578  mov rax, 0x5D9448894530
00007efc33fdd582  call rax
00007efc33fdd584  movaps xmm1, [rsp]
00007efc33fdd588  add rsp, 0x30
00007efc33fdd58c  vmovaps xmm0, [rsp]
00007efc33fdd591  vmovaps xmm2, [rsp+0x10]
00007efc33fdd597  vmovaps xmm3, [rsp+0x20]
00007efc33fdd59d  vmovaps xmm4, [rsp+0x30]
00007efc33fdd5a3  vmovaps xmm5, [rsp+0x40]
00007efc33fdd5a9  vmovaps xmm6, [rsp+0x50]
00007efc33fdd5af  vmovaps xmm7, [rsp+0x60]
00007efc33fdd5b5  vmovaps xmm8, [rsp+0x70]
00007efc33fdd5bb  vmovaps xmm9, [rsp+0x80]
00007efc33fdd5c4  vmovaps xmm10, [rsp+0x90]
00007efc33fdd5cd  vmovaps xmm11, [rsp+0xA0]
00007efc33fdd5d6  vmovaps xmm12, [rsp+0xB0]
00007efc33fdd5df  vmovaps xmm13, [rsp+0xC0]
00007efc33fdd5e8  vmovaps xmm14, [rsp+0xD0]
00007efc33fdd5f1  vmovaps xmm15, [rsp+0xE0]
00007efc33fdd5fa  add rsp, 0xF0
00007efc33fdd601  pop r11
00007efc33fdd603  pop r10
00007efc33fdd605  pop r9
00007efc33fdd607  pop r8
00007efc33fdd609  pop rsi
00007efc33fdd60a  pop rdi
00007efc33fdd60b  pop rdx
00007efc33fdd60c  pop rcx
00007efc33fdd60d  pop rax
00007efc33fdd60e  add rsp, 0x08
00007efc33fdd612  jmp 0x00007EFC33FDBE1B
00007efc33fdd617  call 0x00007EFC33EC4620
00007efc33fdd61c  jmp 0x00007EFC33FDBE28
00007efc33fdd621  sub rsp, 0x08
00007efc33fdd625  push rax
00007efc33fdd626  push rcx
00007efc33fdd627  push rdx
00007efc33fdd628  push rdi
00007efc33fdd629  push rsi
00007efc33fdd62a  push r8
00007efc33fdd62c  push r9
00007efc33fdd62e  push r10
00007efc33fdd630  push r11
00007efc33fdd632  sub rsp, 0xF0
00007efc33fdd639  vmovaps [rsp], xmm0
00007efc33fdd63e  vmovaps [rsp+0x10], xmm1
00007efc33fdd644  vmovaps [rsp+0x20], xmm2
00007efc33fdd64a  vmovaps [rsp+0x30], xmm3
00007efc33fdd650  vmovaps [rsp+0x40], xmm4
00007efc33fdd656  vmovaps [rsp+0x50], xmm5
00007efc33fdd65c  vmovaps [rsp+0x60], xmm6
00007efc33fdd662  vmovaps [rsp+0x70], xmm7
00007efc33fdd668  vmovaps [rsp+0x80], xmm8
00007efc33fdd671  vmovaps [rsp+0x90], xmm9
00007efc33fdd67a  vmovaps [rsp+0xA0], xmm10
00007efc33fdd683  vmovaps [rsp+0xB0], xmm11
00007efc33fdd68c  vmovaps [rsp+0xC0], xmm12
00007efc33fdd695  vmovaps [rsp+0xD0], xmm13
00007efc33fdd69e  vmovaps [rsp+0xE0], xmm15
00007efc33fdd6a7  sub rsp, 0x30
00007efc33fdd6ab  movaps [rsp], xmm14
00007efc33fdd6b0  movaps [rsp+0x10], xmm4
00007efc33fdd6b5  movaps [rsp+0x20], xmm3
00007efc33fdd6ba  lea rdi, [rsp]
00007efc33fdd6be  mov esi, 0x00
00007efc33fdd6c3  mov rax, 0x5D9448894530
00007efc33fdd6cd  call rax
00007efc33fdd6cf  movaps xmm14, [rsp]
00007efc33fdd6d4  add rsp, 0x30
00007efc33fdd6d8  vmovaps xmm0, [rsp]
00007efc33fdd6dd  vmovaps xmm1, [rsp+0x10]
00007efc33fdd6e3  vmovaps xmm2, [rsp+0x20]
00007efc33fdd6e9  vmovaps xmm3, [rsp+0x30]
00007efc33fdd6ef  vmovaps xmm4, [rsp+0x40]
00007efc33fdd6f5  vmovaps xmm5, [rsp+0x50]
00007efc33fdd6fb  vmovaps xmm6, [rsp+0x60]
00007efc33fdd701  vmovaps xmm7, [rsp+0x70]
00007efc33fdd707  vmovaps xmm8, [rsp+0x80]
00007efc33fdd710  vmovaps xmm9, [rsp+0x90]
00007efc33fdd719  vmovaps xmm10, [rsp+0xA0]
00007efc33fdd722  vmovaps xmm11, [rsp+0xB0]
00007efc33fdd72b  vmovaps xmm12, [rsp+0xC0]
00007efc33fdd734  vmovaps xmm13, [rsp+0xD0]
00007efc33fdd73d  vmovaps xmm15, [rsp+0xE0]
00007efc33fdd746  add rsp, 0xF0
00007efc33fdd74d  pop r11
00007efc33fdd74f  pop r10
00007efc33fdd751  pop r9
00007efc33fdd753  pop r8
00007efc33fdd755  pop rsi
00007efc33fdd756  pop rdi
00007efc33fdd757  pop rdx
00007efc33fdd758  pop rcx
00007efc33fdd759  pop rax
00007efc33fdd75a  add rsp, 0x08
00007efc33fdd75e  jmp 0x00007EFC33FDBE42
00007efc33fdd763  sub rsp, 0x08
00007efc33fdd767  push rax
00007efc33fdd768  push rcx
00007efc33fdd769  push rdx
00007efc33fdd76a  push rdi
00007efc33fdd76b  push rsi
00007efc33fdd76c  push r8
00007efc33fdd76e  push r9
00007efc33fdd770  push r10
00007efc33fdd772  push r11
00007efc33fdd774  sub rsp, 0xF0
00007efc33fdd77b  vmovaps [rsp], xmm0
00007efc33fdd780  vmovaps [rsp+0x10], xmm1
00007efc33fdd786  vmovaps [rsp+0x20], xmm2
00007efc33fdd78c  vmovaps [rsp+0x30], xmm3
00007efc33fdd792  vmovaps [rsp+0x40], xmm4
00007efc33fdd798  vmovaps [rsp+0x50], xmm5
00007efc33fdd79e  vmovaps [rsp+0x60], xmm7
00007efc33fdd7a4  vmovaps [rsp+0x70], xmm8
00007efc33fdd7aa  vmovaps [rsp+0x80], xmm9
00007efc33fdd7b3  vmovaps [rsp+0x90], xmm10
00007efc33fdd7bc  vmovaps [rsp+0xA0], xmm11
00007efc33fdd7c5  vmovaps [rsp+0xB0], xmm12
00007efc33fdd7ce  vmovaps [rsp+0xC0], xmm13
00007efc33fdd7d7  vmovaps [rsp+0xD0], xmm14
00007efc33fdd7e0  vmovaps [rsp+0xE0], xmm15
00007efc33fdd7e9  sub rsp, 0x30
00007efc33fdd7ed  movaps [rsp], xmm6
00007efc33fdd7f1  movaps [rsp+0x10], xmm9
00007efc33fdd7f7  movaps [rsp+0x20], xmm7
00007efc33fdd7fc  lea rdi, [rsp]
00007efc33fdd800  mov esi, 0x00
00007efc33fdd805  mov rax, 0x5D9448894530
00007efc33fdd80f  call rax
00007efc33fdd811  movaps xmm6, [rsp]
00007efc33fdd815  add rsp, 0x30
00007efc33fdd819  vmovaps xmm0, [rsp]
00007efc33fdd81e  vmovaps xmm1, [rsp+0x10]
00007efc33fdd824  vmovaps xmm2, [rsp+0x20]
00007efc33fdd82a  vmovaps xmm3, [rsp+0x30]
00007efc33fdd830  vmovaps xmm4, [rsp+0x40]
00007efc33fdd836  vmovaps xmm5, [rsp+0x50]
00007efc33fdd83c  vmovaps xmm7, [rsp+0x60]
00007efc33fdd842  vmovaps xmm8, [rsp+0x70]
00007efc33fdd848  vmovaps xmm9, [rsp+0x80]
00007efc33fdd851  vmovaps xmm10, [rsp+0x90]
00007efc33fdd85a  vmovaps xmm11, [rsp+0xA0]
00007efc33fdd863  vmovaps xmm12, [rsp+0xB0]
00007efc33fdd86c  vmovaps xmm13, [rsp+0xC0]
00007efc33fdd875  vmovaps xmm14, [rsp+0xD0]
00007efc33fdd87e  vmovaps xmm15, [rsp+0xE0]
00007efc33fdd887  add rsp, 0xF0
00007efc33fdd88e  pop r11
00007efc33fdd890  pop r10
00007efc33fdd892  pop r9
00007efc33fdd894  pop r8
00007efc33fdd896  pop rsi
00007efc33fdd897  pop rdi
00007efc33fdd898  pop rdx
00007efc33fdd899  pop rcx
00007efc33fdd89a  pop rax
00007efc33fdd89b  add rsp, 0x08
00007efc33fdd89f  jmp 0x00007EFC33FDBE5A
00007efc33fdd8a4  sub rsp, 0x08
00007efc33fdd8a8  push rax
00007efc33fdd8a9  push rcx
00007efc33fdd8aa  push rdx
00007efc33fdd8ab  push rdi
00007efc33fdd8ac  push rsi
00007efc33fdd8ad  push r8
00007efc33fdd8af  push r9
00007efc33fdd8b1  push r10
00007efc33fdd8b3  push r11
00007efc33fdd8b5  sub rsp, 0xF0
00007efc33fdd8bc  vmovaps [rsp], xmm0
00007efc33fdd8c1  vmovaps [rsp+0x10], xmm1
00007efc33fdd8c7  vmovaps [rsp+0x20], xmm2
00007efc33fdd8cd  vmovaps [rsp+0x30], xmm3
00007efc33fdd8d3  vmovaps [rsp+0x40], xmm4
00007efc33fdd8d9  vmovaps [rsp+0x50], xmm5
00007efc33fdd8df  vmovaps [rsp+0x60], xmm6
00007efc33fdd8e5  vmovaps [rsp+0x70], xmm8
00007efc33fdd8eb  vmovaps [rsp+0x80], xmm9
00007efc33fdd8f4  vmovaps [rsp+0x90], xmm10
00007efc33fdd8fd  vmovaps [rsp+0xA0], xmm11
00007efc33fdd906  vmovaps [rsp+0xB0], xmm12
00007efc33fdd90f  vmovaps [rsp+0xC0], xmm13
00007efc33fdd918  vmovaps [rsp+0xD0], xmm14
00007efc33fdd921  vmovaps [rsp+0xE0], xmm15
00007efc33fdd92a  sub rsp, 0x30
00007efc33fdd92e  movaps [rsp], xmm7
00007efc33fdd932  movaps [rsp+0x10], xmm4
00007efc33fdd937  movaps [rsp+0x20], xmm9
00007efc33fdd93d  lea rdi, [rsp]
00007efc33fdd941  mov esi, 0x00
00007efc33fdd946  mov rax, 0x5D9448894530
00007efc33fdd950  call rax
00007efc33fdd952  movaps xmm7, [rsp]
00007efc33fdd956  add rsp, 0x30
00007efc33fdd95a  vmovaps xmm0, [rsp]
00007efc33fdd95f  vmovaps xmm1, [rsp+0x10]
00007efc33fdd965  vmovaps xmm2, [rsp+0x20]
00007efc33fdd96b  vmovaps xmm3, [rsp+0x30]
00007efc33fdd971  vmovaps xmm4, [rsp+0x40]
00007efc33fdd977  vmovaps xmm5, [rsp+0x50]
00007efc33fdd97d  vmovaps xmm6, [rsp+0x60]
00007efc33fdd983  vmovaps xmm8, [rsp+0x70]
00007efc33fdd989  vmovaps xmm9, [rsp+0x80]
00007efc33fdd992  vmovaps xmm10, [rsp+0x90]
00007efc33fdd99b  vmovaps xmm11, [rsp+0xA0]
00007efc33fdd9a4  vmovaps xmm12, [rsp+0xB0]
00007efc33fdd9ad  vmovaps xmm13, [rsp+0xC0]
00007efc33fdd9b6  vmovaps xmm14, [rsp+0xD0]
00007efc33fdd9bf  vmovaps xmm15, [rsp+0xE0]
00007efc33fdd9c8  add rsp, 0xF0
00007efc33fdd9cf  pop r11
00007efc33fdd9d1  pop r10
00007efc33fdd9d3  pop r9
00007efc33fdd9d5  pop r8
00007efc33fdd9d7  pop rsi
00007efc33fdd9d8  pop rdi
00007efc33fdd9d9  pop rdx
00007efc33fdd9da  pop rcx
00007efc33fdd9db  pop rax
00007efc33fdd9dc  add rsp, 0x08
00007efc33fdd9e0  jmp 0x00007EFC33FDBE87
00007efc33fdd9e5  sub rsp, 0x08
00007efc33fdd9e9  push rax
00007efc33fdd9ea  push rcx
00007efc33fdd9eb  push rdx
00007efc33fdd9ec  push rdi
00007efc33fdd9ed  push rsi
00007efc33fdd9ee  push r8
00007efc33fdd9f0  push r9
00007efc33fdd9f2  push r10
00007efc33fdd9f4  push r11
00007efc33fdd9f6  sub rsp, 0xF0
00007efc33fdd9fd  vmovaps [rsp], xmm0
00007efc33fdda02  vmovaps [rsp+0x10], xmm1
00007efc33fdda08  vmovaps [rsp+0x20], xmm2
00007efc33fdda0e  vmovaps [rsp+0x30], xmm3
00007efc33fdda14  vmovaps [rsp+0x40], xmm5
00007efc33fdda1a  vmovaps [rsp+0x50], xmm6
00007efc33fdda20  vmovaps [rsp+0x60], xmm7
00007efc33fdda26  vmovaps [rsp+0x70], xmm8
00007efc33fdda2c  vmovaps [rsp+0x80], xmm9
00007efc33fdda35  vmovaps [rsp+0x90], xmm10
00007efc33fdda3e  vmovaps [rsp+0xA0], xmm11
00007efc33fdda47  vmovaps [rsp+0xB0], xmm12
00007efc33fdda50  vmovaps [rsp+0xC0], xmm13
00007efc33fdda59  vmovaps [rsp+0xD0], xmm14
00007efc33fdda62  vmovaps [rsp+0xE0], xmm15
00007efc33fdda6b  sub rsp, 0x30
00007efc33fdda6f  movaps [rsp], xmm4
00007efc33fdda73  movaps [rsp+0x10], xmm15
00007efc33fdda79  movaps [rsp+0x20], xmm9
00007efc33fdda7f  lea rdi, [rsp]
00007efc33fdda83  mov esi, 0x00
00007efc33fdda88  mov rax, 0x5D9448894530
00007efc33fdda92  call rax
00007efc33fdda94  movaps xmm4, [rsp]
00007efc33fdda98  add rsp, 0x30
00007efc33fdda9c  vmovaps xmm0, [rsp]
00007efc33fddaa1  vmovaps xmm1, [rsp+0x10]
00007efc33fddaa7  vmovaps xmm2, [rsp+0x20]
00007efc33fddaad  vmovaps xmm3, [rsp+0x30]
00007efc33fddab3  vmovaps xmm5, [rsp+0x40]
00007efc33fddab9  vmovaps xmm6, [rsp+0x50]
00007efc33fddabf  vmovaps xmm7, [rsp+0x60]
00007efc33fddac5  vmovaps xmm8, [rsp+0x70]
00007efc33fddacb  vmovaps xmm9, [rsp+0x80]
00007efc33fddad4  vmovaps xmm10, [rsp+0x90]
00007efc33fddadd  vmovaps xmm11, [rsp+0xA0]
00007efc33fddae6  vmovaps xmm12, [rsp+0xB0]
00007efc33fddaef  vmovaps xmm13, [rsp+0xC0]
00007efc33fddaf8  vmovaps xmm14, [rsp+0xD0]
00007efc33fddb01  vmovaps xmm15, [rsp+0xE0]
00007efc33fddb0a  add rsp, 0xF0
00007efc33fddb11  pop r11
00007efc33fddb13  pop r10
00007efc33fddb15  pop r9
00007efc33fddb17  pop r8
00007efc33fddb19  pop rsi
00007efc33fddb1a  pop rdi
00007efc33fddb1b  pop rdx
00007efc33fddb1c  pop rcx
00007efc33fddb1d  pop rax
00007efc33fddb1e  add rsp, 0x08
00007efc33fddb22  jmp 0x00007EFC33FDBEAC
00007efc33fddb27  call 0x00007EFC33EC4620
00007efc33fddb2c  jmp 0x00007EFC33FDBEB9
00007efc33fddb31  sub rsp, 0x08
00007efc33fddb35  push rax
00007efc33fddb36  push rcx
00007efc33fddb37  push rdx
00007efc33fddb38  push rdi
00007efc33fddb39  push rsi
00007efc33fddb3a  push r8
00007efc33fddb3c  push r9
00007efc33fddb3e  push r10
00007efc33fddb40  push r11
00007efc33fddb42  sub rsp, 0xF0
00007efc33fddb49  vmovaps [rsp], xmm0
00007efc33fddb4e  vmovaps [rsp+0x10], xmm1
00007efc33fddb54  vmovaps [rsp+0x20], xmm2
00007efc33fddb5a  vmovaps [rsp+0x30], xmm4
00007efc33fddb60  vmovaps [rsp+0x40], xmm5
00007efc33fddb66  vmovaps [rsp+0x50], xmm6
00007efc33fddb6c  vmovaps [rsp+0x60], xmm7
00007efc33fddb72  vmovaps [rsp+0x70], xmm8
00007efc33fddb78  vmovaps [rsp+0x80], xmm9
00007efc33fddb81  vmovaps [rsp+0x90], xmm10
00007efc33fddb8a  vmovaps [rsp+0xA0], xmm11
00007efc33fddb93  vmovaps [rsp+0xB0], xmm12
00007efc33fddb9c  vmovaps [rsp+0xC0], xmm13
00007efc33fddba5  vmovaps [rsp+0xD0], xmm14
00007efc33fddbae  vmovaps [rsp+0xE0], xmm15
00007efc33fddbb7  sub rsp, 0x30
00007efc33fddbbb  movaps [rsp], xmm3
00007efc33fddbbf  movaps [rsp+0x10], xmm1
00007efc33fddbc4  movaps [rsp+0x20], xmm9
00007efc33fddbca  lea rdi, [rsp]
00007efc33fddbce  mov esi, 0x00
00007efc33fddbd3  mov rax, 0x5D9448894530
00007efc33fddbdd  call rax
00007efc33fddbdf  movaps xmm3, [rsp]
00007efc33fddbe3  add rsp, 0x30
00007efc33fddbe7  vmovaps xmm0, [rsp]
00007efc33fddbec  vmovaps xmm1, [rsp+0x10]
00007efc33fddbf2  vmovaps xmm2, [rsp+0x20]
00007efc33fddbf8  vmovaps xmm4, [rsp+0x30]
00007efc33fddbfe  vmovaps xmm5, [rsp+0x40]
00007efc33fddc04  vmovaps xmm6, [rsp+0x50]
00007efc33fddc0a  vmovaps xmm7, [rsp+0x60]
00007efc33fddc10  vmovaps xmm8, [rsp+0x70]
00007efc33fddc16  vmovaps xmm9, [rsp+0x80]
00007efc33fddc1f  vmovaps xmm10, [rsp+0x90]
00007efc33fddc28  vmovaps xmm11, [rsp+0xA0]
00007efc33fddc31  vmovaps xmm12, [rsp+0xB0]
00007efc33fddc3a  vmovaps xmm13, [rsp+0xC0]
00007efc33fddc43  vmovaps xmm14, [rsp+0xD0]
00007efc33fddc4c  vmovaps xmm15, [rsp+0xE0]
00007efc33fddc55  add rsp, 0xF0
00007efc33fddc5c  pop r11
00007efc33fddc5e  pop r10
00007efc33fddc60  pop r9
00007efc33fddc62  pop r8
00007efc33fddc64  pop rsi
00007efc33fddc65  pop rdi
00007efc33fddc66  pop rdx
00007efc33fddc67  pop rcx
00007efc33fddc68  pop rax
00007efc33fddc69  add rsp, 0x08
00007efc33fddc6d  jmp 0x00007EFC33FDBEF6
00007efc33fddc72  sub rsp, 0x08
00007efc33fddc76  push rax
00007efc33fddc77  push rcx
00007efc33fddc78  push rdx
00007efc33fddc79  push rdi
00007efc33fddc7a  push rsi
00007efc33fddc7b  push r8
00007efc33fddc7d  push r9
00007efc33fddc7f  push r10
00007efc33fddc81  push r11
00007efc33fddc83  sub rsp, 0xF0
00007efc33fddc8a  vmovaps [rsp], xmm0
00007efc33fddc8f  vmovaps [rsp+0x10], xmm2
00007efc33fddc95  vmovaps [rsp+0x20], xmm3
00007efc33fddc9b  vmovaps [rsp+0x30], xmm4
00007efc33fddca1  vmovaps [rsp+0x40], xmm5
00007efc33fddca7  vmovaps [rsp+0x50], xmm6
00007efc33fddcad  vmovaps [rsp+0x60], xmm7
00007efc33fddcb3  vmovaps [rsp+0x70], xmm8
00007efc33fddcb9  vmovaps [rsp+0x80], xmm9
00007efc33fddcc2  vmovaps [rsp+0x90], xmm10
00007efc33fddccb  vmovaps [rsp+0xA0], xmm11
00007efc33fddcd4  vmovaps [rsp+0xB0], xmm12
00007efc33fddcdd  vmovaps [rsp+0xC0], xmm13
00007efc33fddce6  vmovaps [rsp+0xD0], xmm14
00007efc33fddcef  vmovaps [rsp+0xE0], xmm15
00007efc33fddcf8  sub rsp, 0x30
00007efc33fddcfc  movaps [rsp], xmm1
00007efc33fddd00  movaps [rsp+0x10], xmm15
00007efc33fddd06  movaps [rsp+0x20], xmm9
00007efc33fddd0c  lea rdi, [rsp]
00007efc33fddd10  mov esi, 0x00
00007efc33fddd15  mov rax, 0x5D9448894530
00007efc33fddd1f  call rax
00007efc33fddd21  movaps xmm1, [rsp]
00007efc33fddd25  add rsp, 0x30
00007efc33fddd29  vmovaps xmm0, [rsp]
00007efc33fddd2e  vmovaps xmm2, [rsp+0x10]
00007efc33fddd34  vmovaps xmm3, [rsp+0x20]
00007efc33fddd3a  vmovaps xmm4, [rsp+0x30]
00007efc33fddd40  vmovaps xmm5, [rsp+0x40]
00007efc33fddd46  vmovaps xmm6, [rsp+0x50]
00007efc33fddd4c  vmovaps xmm7, [rsp+0x60]
00007efc33fddd52  vmovaps xmm8, [rsp+0x70]
00007efc33fddd58  vmovaps xmm9, [rsp+0x80]
00007efc33fddd61  vmovaps xmm10, [rsp+0x90]
00007efc33fddd6a  vmovaps xmm11, [rsp+0xA0]
00007efc33fddd73  vmovaps xmm12, [rsp+0xB0]
00007efc33fddd7c  vmovaps xmm13, [rsp+0xC0]
00007efc33fddd85  vmovaps xmm14, [rsp+0xD0]
00007efc33fddd8e  vmovaps xmm15, [rsp+0xE0]
00007efc33fddd97  add rsp, 0xF0
00007efc33fddd9e  pop r11
00007efc33fddda0  pop r10
00007efc33fddda2  pop r9
00007efc33fddda4  pop r8
00007efc33fddda6  pop rsi
00007efc33fddda7  pop rdi
00007efc33fddda8  pop rdx
00007efc33fddda9  pop rcx
00007efc33fdddaa  pop rax
00007efc33fdddab  add rsp, 0x08
00007efc33fdddaf  jmp 0x00007EFC33FDBF7E
00007efc33fdddb4  call 0x00007EFC33EC4620
00007efc33fdddb9  jmp 0x00007EFC33FDBF8B
00007efc33fdddbe  sub rsp, 0x08
00007efc33fdddc2  push rax
00007efc33fdddc3  push rcx
00007efc33fdddc4  push rdx
00007efc33fdddc5  push rdi
00007efc33fdddc6  push rsi
00007efc33fdddc7  push r8
00007efc33fdddc9  push r9
00007efc33fdddcb  push r10
00007efc33fdddcd  push r11
00007efc33fdddcf  sub rsp, 0xF0
00007efc33fdddd6  vmovaps [rsp], xmm0
00007efc33fddddb  vmovaps [rsp+0x10], xmm2
00007efc33fddde1  vmovaps [rsp+0x20], xmm3
00007efc33fddde7  vmovaps [rsp+0x30], xmm4
00007efc33fddded  vmovaps [rsp+0x40], xmm5
00007efc33fdddf3  vmovaps [rsp+0x50], xmm6
00007efc33fdddf9  vmovaps [rsp+0x60], xmm7
00007efc33fdddff  vmovaps [rsp+0x70], xmm8
00007efc33fdde05  vmovaps [rsp+0x80], xmm9
00007efc33fdde0e  vmovaps [rsp+0x90], xmm10
00007efc33fdde17  vmovaps [rsp+0xA0], xmm11
00007efc33fdde20  vmovaps [rsp+0xB0], xmm12
00007efc33fdde29  vmovaps [rsp+0xC0], xmm13
00007efc33fdde32  vmovaps [rsp+0xD0], xmm14
00007efc33fdde3b  vmovaps [rsp+0xE0], xmm15
00007efc33fdde44  sub rsp, 0x30
00007efc33fdde48  movaps [rsp], xmm1
00007efc33fdde4c  movaps [rsp+0x10], xmm5
00007efc33fdde51  movaps [rsp+0x20], xmm7
00007efc33fdde56  lea rdi, [rsp]
00007efc33fdde5a  mov esi, 0x00
00007efc33fdde5f  mov rax, 0x5D9448894530
00007efc33fdde69  call rax
00007efc33fdde6b  movaps xmm1, [rsp]
00007efc33fdde6f  add rsp, 0x30
00007efc33fdde73  vmovaps xmm0, [rsp]
00007efc33fdde78  vmovaps xmm2, [rsp+0x10]
00007efc33fdde7e  vmovaps xmm3, [rsp+0x20]
00007efc33fdde84  vmovaps xmm4, [rsp+0x30]
00007efc33fdde8a  vmovaps xmm5, [rsp+0x40]
00007efc33fdde90  vmovaps xmm6, [rsp+0x50]
00007efc33fdde96  vmovaps xmm7, [rsp+0x60]
00007efc33fdde9c  vmovaps xmm8, [rsp+0x70]
00007efc33fddea2  vmovaps xmm9, [rsp+0x80]
00007efc33fddeab  vmovaps xmm10, [rsp+0x90]
00007efc33fddeb4  vmovaps xmm11, [rsp+0xA0]
00007efc33fddebd  vmovaps xmm12, [rsp+0xB0]
00007efc33fddec6  vmovaps xmm13, [rsp+0xC0]
00007efc33fddecf  vmovaps xmm14, [rsp+0xD0]
00007efc33fdded8  vmovaps xmm15, [rsp+0xE0]
00007efc33fddee1  add rsp, 0xF0
00007efc33fddee8  pop r11
00007efc33fddeea  pop r10
00007efc33fddeec  pop r9
00007efc33fddeee  pop r8
00007efc33fddef0  pop rsi
00007efc33fddef1  pop rdi
00007efc33fddef2  pop rdx
00007efc33fddef3  pop rcx
00007efc33fddef4  pop rax
00007efc33fddef5  add rsp, 0x08
00007efc33fddef9  jmp 0x00007EFC33FDC030
00007efc33fddefe  sub rsp, 0x08
00007efc33fddf02  push rax
00007efc33fddf03  push rcx
00007efc33fddf04  push rdx
00007efc33fddf05  push rdi
00007efc33fddf06  push rsi
00007efc33fddf07  push r8
00007efc33fddf09  push r9
00007efc33fddf0b  push r10
00007efc33fddf0d  push r11
00007efc33fddf0f  sub rsp, 0xF0
00007efc33fddf16  vmovaps [rsp], xmm0
00007efc33fddf1b  vmovaps [rsp+0x10], xmm1
00007efc33fddf21  vmovaps [rsp+0x20], xmm2
00007efc33fddf27  vmovaps [rsp+0x30], xmm3
00007efc33fddf2d  vmovaps [rsp+0x40], xmm4
00007efc33fddf33  vmovaps [rsp+0x50], xmm5
00007efc33fddf39  vmovaps [rsp+0x60], xmm6
00007efc33fddf3f  vmovaps [rsp+0x70], xmm8
00007efc33fddf45  vmovaps [rsp+0x80], xmm9
00007efc33fddf4e  vmovaps [rsp+0x90], xmm10
00007efc33fddf57  vmovaps [rsp+0xA0], xmm11
00007efc33fddf60  vmovaps [rsp+0xB0], xmm12
00007efc33fddf69  vmovaps [rsp+0xC0], xmm13
00007efc33fddf72  vmovaps [rsp+0xD0], xmm14
00007efc33fddf7b  vmovaps [rsp+0xE0], xmm15
00007efc33fddf84  sub rsp, 0x30
00007efc33fddf88  movaps [rsp], xmm7
00007efc33fddf8c  movaps [rsp+0x10], xmm5
00007efc33fddf91  movaps [rsp+0x20], xmm15
00007efc33fddf97  lea rdi, [rsp]
00007efc33fddf9b  mov esi, 0x00
00007efc33fddfa0  mov rax, 0x5D9448894530
00007efc33fddfaa  call rax
00007efc33fddfac  movaps xmm7, [rsp]
00007efc33fddfb0  add rsp, 0x30
00007efc33fddfb4  vmovaps xmm0, [rsp]
00007efc33fddfb9  vmovaps xmm1, [rsp+0x10]
00007efc33fddfbf  vmovaps xmm2, [rsp+0x20]
00007efc33fddfc5  vmovaps xmm3, [rsp+0x30]
00007efc33fddfcb  vmovaps xmm4, [rsp+0x40]
00007efc33fddfd1  vmovaps xmm5, [rsp+0x50]
00007efc33fddfd7  vmovaps xmm6, [rsp+0x60]
00007efc33fddfdd  vmovaps xmm8, [rsp+0x70]
00007efc33fddfe3  vmovaps xmm9, [rsp+0x80]
00007efc33fddfec  vmovaps xmm10, [rsp+0x90]
00007efc33fddff5  vmovaps xmm11, [rsp+0xA0]
00007efc33fddffe  vmovaps xmm12, [rsp+0xB0]
00007efc33fde007  vmovaps xmm13, [rsp+0xC0]
00007efc33fde010  vmovaps xmm14, [rsp+0xD0]
00007efc33fde019  vmovaps xmm15, [rsp+0xE0]
00007efc33fde022  add rsp, 0xF0
00007efc33fde029  pop r11
00007efc33fde02b  pop r10
00007efc33fde02d  pop r9
00007efc33fde02f  pop r8
00007efc33fde031  pop rsi
00007efc33fde032  pop rdi
00007efc33fde033  pop rdx
00007efc33fde034  pop rcx
00007efc33fde035  pop rax
00007efc33fde036  add rsp, 0x08
00007efc33fde03a  jmp 0x00007EFC33FDC066
00007efc33fde03f  call 0x00007EFC33EB52F0
00007efc33fde044  jmp 0x00007EFC33FDC073
00007efc33fde049  sub rsp, 0x08
00007efc33fde04d  push rax
00007efc33fde04e  push rcx
00007efc33fde04f  push rdx
00007efc33fde050  push rdi
00007efc33fde051  push rsi
00007efc33fde052  push r8
00007efc33fde054  push r9
00007efc33fde056  push r10
00007efc33fde058  push r11
00007efc33fde05a  sub rsp, 0xF0
00007efc33fde061  vmovaps [rsp], xmm0
00007efc33fde066  vmovaps [rsp+0x10], xmm1
00007efc33fde06c  vmovaps [rsp+0x20], xmm2
00007efc33fde072  vmovaps [rsp+0x30], xmm3
00007efc33fde078  vmovaps [rsp+0x40], xmm4
00007efc33fde07e  vmovaps [rsp+0x50], xmm5
00007efc33fde084  vmovaps [rsp+0x60], xmm6
00007efc33fde08a  vmovaps [rsp+0x70], xmm7
00007efc33fde090  vmovaps [rsp+0x80], xmm8
00007efc33fde099  vmovaps [rsp+0x90], xmm9
00007efc33fde0a2  vmovaps [rsp+0xA0], xmm10
00007efc33fde0ab  vmovaps [rsp+0xB0], xmm11
00007efc33fde0b4  vmovaps [rsp+0xC0], xmm12
00007efc33fde0bd  vmovaps [rsp+0xD0], xmm13
00007efc33fde0c6  vmovaps [rsp+0xE0], xmm14
00007efc33fde0cf  sub rsp, 0x30
00007efc33fde0d3  movaps [rsp], xmm15
00007efc33fde0d8  movaps [rsp+0x10], xmm5
00007efc33fde0dd  movaps [rsp+0x20], xmm3
00007efc33fde0e2  lea rdi, [rsp]
00007efc33fde0e6  mov esi, 0x00
00007efc33fde0eb  mov rax, 0x5D9448894530
00007efc33fde0f5  call rax
00007efc33fde0f7  movaps xmm15, [rsp]
00007efc33fde0fc  add rsp, 0x30
00007efc33fde100  vmovaps xmm0, [rsp]
00007efc33fde105  vmovaps xmm1, [rsp+0x10]
00007efc33fde10b  vmovaps xmm2, [rsp+0x20]
00007efc33fde111  vmovaps xmm3, [rsp+0x30]
00007efc33fde117  vmovaps xmm4, [rsp+0x40]
00007efc33fde11d  vmovaps xmm5, [rsp+0x50]
00007efc33fde123  vmovaps xmm6, [rsp+0x60]
00007efc33fde129  vmovaps xmm7, [rsp+0x70]
00007efc33fde12f  vmovaps xmm8, [rsp+0x80]
00007efc33fde138  vmovaps xmm9, [rsp+0x90]
00007efc33fde141  vmovaps xmm10, [rsp+0xA0]
00007efc33fde14a  vmovaps xmm11, [rsp+0xB0]
00007efc33fde153  vmovaps xmm12, [rsp+0xC0]
00007efc33fde15c  vmovaps xmm13, [rsp+0xD0]
00007efc33fde165  vmovaps xmm14, [rsp+0xE0]
00007efc33fde16e  add rsp, 0xF0
00007efc33fde175  pop r11
00007efc33fde177  pop r10
00007efc33fde179  pop r9
00007efc33fde17b  pop r8
00007efc33fde17d  pop rsi
00007efc33fde17e  pop rdi
00007efc33fde17f  pop rdx
00007efc33fde180  pop rcx
00007efc33fde181  pop rax
00007efc33fde182  add rsp, 0x08
00007efc33fde186  jmp 0x00007EFC33FDC099
00007efc33fde18b  sub rsp, 0x08
00007efc33fde18f  push rax
00007efc33fde190  push rcx
00007efc33fde191  push rdx
00007efc33fde192  push rdi
00007efc33fde193  push rsi
00007efc33fde194  push r8
00007efc33fde196  push r9
00007efc33fde198  push r10
00007efc33fde19a  push r11
00007efc33fde19c  sub rsp, 0xF0
00007efc33fde1a3  vmovaps [rsp], xmm0
00007efc33fde1a8  vmovaps [rsp+0x10], xmm2
00007efc33fde1ae  vmovaps [rsp+0x20], xmm3
00007efc33fde1b4  vmovaps [rsp+0x30], xmm4
00007efc33fde1ba  vmovaps [rsp+0x40], xmm5
00007efc33fde1c0  vmovaps [rsp+0x50], xmm6
00007efc33fde1c6  vmovaps [rsp+0x60], xmm7
00007efc33fde1cc  vmovaps [rsp+0x70], xmm8
00007efc33fde1d2  vmovaps [rsp+0x80], xmm9
00007efc33fde1db  vmovaps [rsp+0x90], xmm10
00007efc33fde1e4  vmovaps [rsp+0xA0], xmm11
00007efc33fde1ed  vmovaps [rsp+0xB0], xmm12
00007efc33fde1f6  vmovaps [rsp+0xC0], xmm13
00007efc33fde1ff  vmovaps [rsp+0xD0], xmm14
00007efc33fde208  vmovaps [rsp+0xE0], xmm15
00007efc33fde211  sub rsp, 0x30
00007efc33fde215  movaps [rsp], xmm1
00007efc33fde219  movaps [rsp+0x10], xmm5
00007efc33fde21e  movaps [rsp+0x20], xmm4
00007efc33fde223  lea rdi, [rsp]
00007efc33fde227  mov esi, 0x00
00007efc33fde22c  mov rax, 0x5D9448894530
00007efc33fde236  call rax
00007efc33fde238  movaps xmm1, [rsp]
00007efc33fde23c  add rsp, 0x30
00007efc33fde240  vmovaps xmm0, [rsp]
00007efc33fde245  vmovaps xmm2, [rsp+0x10]
00007efc33fde24b  vmovaps xmm3, [rsp+0x20]
00007efc33fde251  vmovaps xmm4, [rsp+0x30]
00007efc33fde257  vmovaps xmm5, [rsp+0x40]
00007efc33fde25d  vmovaps xmm6, [rsp+0x50]
00007efc33fde263  vmovaps xmm7, [rsp+0x60]
00007efc33fde269  vmovaps xmm8, [rsp+0x70]
00007efc33fde26f  vmovaps xmm9, [rsp+0x80]
00007efc33fde278  vmovaps xmm10, [rsp+0x90]
00007efc33fde281  vmovaps xmm11, [rsp+0xA0]
00007efc33fde28a  vmovaps xmm12, [rsp+0xB0]
00007efc33fde293  vmovaps xmm13, [rsp+0xC0]
00007efc33fde29c  vmovaps xmm14, [rsp+0xD0]
00007efc33fde2a5  vmovaps xmm15, [rsp+0xE0]
00007efc33fde2ae  add rsp, 0xF0
00007efc33fde2b5  pop r11
00007efc33fde2b7  pop r10
00007efc33fde2b9  pop r9
00007efc33fde2bb  pop r8
00007efc33fde2bd  pop rsi
00007efc33fde2be  pop rdi
00007efc33fde2bf  pop rdx
00007efc33fde2c0  pop rcx
00007efc33fde2c1  pop rax
00007efc33fde2c2  add rsp, 0x08
00007efc33fde2c6  jmp 0x00007EFC33FDC0B9
00007efc33fde2cb  sub rsp, 0x08
00007efc33fde2cf  push rax
00007efc33fde2d0  push rcx
00007efc33fde2d1  push rdx
00007efc33fde2d2  push rdi
00007efc33fde2d3  push rsi
00007efc33fde2d4  push r8
00007efc33fde2d6  push r9
00007efc33fde2d8  push r10
00007efc33fde2da  push r11
00007efc33fde2dc  sub rsp, 0xF0
00007efc33fde2e3  vmovaps [rsp], xmm0
00007efc33fde2e8  vmovaps [rsp+0x10], xmm1
00007efc33fde2ee  vmovaps [rsp+0x20], xmm2
00007efc33fde2f4  vmovaps [rsp+0x30], xmm3
00007efc33fde2fa  vmovaps [rsp+0x40], xmm5
00007efc33fde300  vmovaps [rsp+0x50], xmm6
00007efc33fde306  vmovaps [rsp+0x60], xmm7
00007efc33fde30c  vmovaps [rsp+0x70], xmm8
00007efc33fde312  vmovaps [rsp+0x80], xmm9
00007efc33fde31b  vmovaps [rsp+0x90], xmm10
00007efc33fde324  vmovaps [rsp+0xA0], xmm11
00007efc33fde32d  vmovaps [rsp+0xB0], xmm12
00007efc33fde336  vmovaps [rsp+0xC0], xmm13
00007efc33fde33f  vmovaps [rsp+0xD0], xmm14
00007efc33fde348  vmovaps [rsp+0xE0], xmm15
00007efc33fde351  sub rsp, 0x30
00007efc33fde355  movaps [rsp], xmm4
00007efc33fde359  movaps [rsp+0x10], xmm3
00007efc33fde35e  movaps [rsp+0x20], xmm5
00007efc33fde363  lea rdi, [rsp]
00007efc33fde367  mov esi, 0x00
00007efc33fde36c  mov rax, 0x5D9448894530
00007efc33fde376  call rax
00007efc33fde378  movaps xmm4, [rsp]
00007efc33fde37c  add rsp, 0x30
00007efc33fde380  vmovaps xmm0, [rsp]
00007efc33fde385  vmovaps xmm1, [rsp+0x10]
00007efc33fde38b  vmovaps xmm2, [rsp+0x20]
00007efc33fde391  vmovaps xmm3, [rsp+0x30]
00007efc33fde397  vmovaps xmm5, [rsp+0x40]
00007efc33fde39d  vmovaps xmm6, [rsp+0x50]
00007efc33fde3a3  vmovaps xmm7, [rsp+0x60]
00007efc33fde3a9  vmovaps xmm8, [rsp+0x70]
00007efc33fde3af  vmovaps xmm9, [rsp+0x80]
00007efc33fde3b8  vmovaps xmm10, [rsp+0x90]
00007efc33fde3c1  vmovaps xmm11, [rsp+0xA0]
00007efc33fde3ca  vmovaps xmm12, [rsp+0xB0]
00007efc33fde3d3  vmovaps xmm13, [rsp+0xC0]
00007efc33fde3dc  vmovaps xmm14, [rsp+0xD0]
00007efc33fde3e5  vmovaps xmm15, [rsp+0xE0]
00007efc33fde3ee  add rsp, 0xF0
00007efc33fde3f5  pop r11
00007efc33fde3f7  pop r10
00007efc33fde3f9  pop r9
00007efc33fde3fb  pop r8
00007efc33fde3fd  pop rsi
00007efc33fde3fe  pop rdi
00007efc33fde3ff  pop rdx
00007efc33fde400  pop rcx
00007efc33fde401  pop rax
00007efc33fde402  add rsp, 0x08
00007efc33fde406  jmp 0x00007EFC33FDC107
00007efc33fde40b  call 0x00007EFC33EB52F0
00007efc33fde410  jmp 0x00007EFC33FDC114
00007efc33fde415  sub rsp, 0x08
00007efc33fde419  push rax
00007efc33fde41a  push rcx
00007efc33fde41b  push rdx
00007efc33fde41c  push rdi
00007efc33fde41d  push rsi
00007efc33fde41e  push r8
00007efc33fde420  push r9
00007efc33fde422  push r10
00007efc33fde424  push r11
00007efc33fde426  sub rsp, 0xF0
00007efc33fde42d  vmovaps [rsp], xmm0
00007efc33fde432  vmovaps [rsp+0x10], xmm1
00007efc33fde438  vmovaps [rsp+0x20], xmm2
00007efc33fde43e  vmovaps [rsp+0x30], xmm3
00007efc33fde444  vmovaps [rsp+0x40], xmm4
00007efc33fde44a  vmovaps [rsp+0x50], xmm6
00007efc33fde450  vmovaps [rsp+0x60], xmm7
00007efc33fde456  vmovaps [rsp+0x70], xmm8
00007efc33fde45c  vmovaps [rsp+0x80], xmm9
00007efc33fde465  vmovaps [rsp+0x90], xmm10
00007efc33fde46e  vmovaps [rsp+0xA0], xmm11
00007efc33fde477  vmovaps [rsp+0xB0], xmm12
00007efc33fde480  vmovaps [rsp+0xC0], xmm13
00007efc33fde489  vmovaps [rsp+0xD0], xmm14
00007efc33fde492  vmovaps [rsp+0xE0], xmm15
00007efc33fde49b  sub rsp, 0x30
00007efc33fde49f  movaps [rsp], xmm5
00007efc33fde4a3  movaps [rsp+0x10], xmm6
00007efc33fde4a8  movaps [rsp+0x20], xmm3
00007efc33fde4ad  lea rdi, [rsp]
00007efc33fde4b1  mov esi, 0x00
00007efc33fde4b6  mov rax, 0x5D9448894530
00007efc33fde4c0  call rax
00007efc33fde4c2  movaps xmm5, [rsp]
00007efc33fde4c6  add rsp, 0x30
00007efc33fde4ca  vmovaps xmm0, [rsp]
00007efc33fde4cf  vmovaps xmm1, [rsp+0x10]
00007efc33fde4d5  vmovaps xmm2, [rsp+0x20]
00007efc33fde4db  vmovaps xmm3, [rsp+0x30]
00007efc33fde4e1  vmovaps xmm4, [rsp+0x40]
00007efc33fde4e7  vmovaps xmm6, [rsp+0x50]
00007efc33fde4ed  vmovaps xmm7, [rsp+0x60]
00007efc33fde4f3  vmovaps xmm8, [rsp+0x70]
00007efc33fde4f9  vmovaps xmm9, [rsp+0x80]
00007efc33fde502  vmovaps xmm10, [rsp+0x90]
00007efc33fde50b  vmovaps xmm11, [rsp+0xA0]
00007efc33fde514  vmovaps xmm12, [rsp+0xB0]
00007efc33fde51d  vmovaps xmm13, [rsp+0xC0]
00007efc33fde526  vmovaps xmm14, [rsp+0xD0]
00007efc33fde52f  vmovaps xmm15, [rsp+0xE0]
00007efc33fde538  add rsp, 0xF0
00007efc33fde53f  pop r11
00007efc33fde541  pop r10
00007efc33fde543  pop r9
00007efc33fde545  pop r8
00007efc33fde547  pop rsi
00007efc33fde548  pop rdi
00007efc33fde549  pop rdx
00007efc33fde54a  pop rcx
00007efc33fde54b  pop rax
00007efc33fde54c  add rsp, 0x08
00007efc33fde550  jmp 0x00007EFC33FDC13A
00007efc33fde555  sub rsp, 0x08
00007efc33fde559  push rax
00007efc33fde55a  push rcx
00007efc33fde55b  push rdx
00007efc33fde55c  push rdi
00007efc33fde55d  push rsi
00007efc33fde55e  push r8
00007efc33fde560  push r9
00007efc33fde562  push r10
00007efc33fde564  push r11
00007efc33fde566  sub rsp, 0xF0
00007efc33fde56d  vmovaps [rsp], xmm0
00007efc33fde572  vmovaps [rsp+0x10], xmm1
00007efc33fde578  vmovaps [rsp+0x20], xmm2
00007efc33fde57e  vmovaps [rsp+0x30], xmm3
00007efc33fde584  vmovaps [rsp+0x40], xmm4
00007efc33fde58a  vmovaps [rsp+0x50], xmm5
00007efc33fde590  vmovaps [rsp+0x60], xmm7
00007efc33fde596  vmovaps [rsp+0x70], xmm8
00007efc33fde59c  vmovaps [rsp+0x80], xmm9
00007efc33fde5a5  vmovaps [rsp+0x90], xmm10
00007efc33fde5ae  vmovaps [rsp+0xA0], xmm11
00007efc33fde5b7  vmovaps [rsp+0xB0], xmm12
00007efc33fde5c0  vmovaps [rsp+0xC0], xmm13
00007efc33fde5c9  vmovaps [rsp+0xD0], xmm14
00007efc33fde5d2  vmovaps [rsp+0xE0], xmm15
00007efc33fde5db  sub rsp, 0x30
00007efc33fde5df  movaps [rsp], xmm6
00007efc33fde5e3  movaps [rsp+0x10], xmm9
00007efc33fde5e9  movaps [rsp+0x20], xmm1
00007efc33fde5ee  lea rdi, [rsp]
00007efc33fde5f2  mov esi, 0x00
00007efc33fde5f7  mov rax, 0x5D9448894530
00007efc33fde601  call rax
00007efc33fde603  movaps xmm6, [rsp]
00007efc33fde607  add rsp, 0x30
00007efc33fde60b  vmovaps xmm0, [rsp]
00007efc33fde610  vmovaps xmm1, [rsp+0x10]
00007efc33fde616  vmovaps xmm2, [rsp+0x20]
00007efc33fde61c  vmovaps xmm3, [rsp+0x30]
00007efc33fde622  vmovaps xmm4, [rsp+0x40]
00007efc33fde628  vmovaps xmm5, [rsp+0x50]
00007efc33fde62e  vmovaps xmm7, [rsp+0x60]
00007efc33fde634  vmovaps xmm8, [rsp+0x70]
00007efc33fde63a  vmovaps xmm9, [rsp+0x80]
00007efc33fde643  vmovaps xmm10, [rsp+0x90]
00007efc33fde64c  vmovaps xmm11, [rsp+0xA0]
00007efc33fde655  vmovaps xmm12, [rsp+0xB0]
00007efc33fde65e  vmovaps xmm13, [rsp+0xC0]
00007efc33fde667  vmovaps xmm14, [rsp+0xD0]
00007efc33fde670  vmovaps xmm15, [rsp+0xE0]
00007efc33fde679  add rsp, 0xF0
00007efc33fde680  pop r11
00007efc33fde682  pop r10
00007efc33fde684  pop r9
00007efc33fde686  pop r8
00007efc33fde688  pop rsi
00007efc33fde689  pop rdi
00007efc33fde68a  pop rdx
00007efc33fde68b  pop rcx
00007efc33fde68c  pop rax
00007efc33fde68d  add rsp, 0x08
00007efc33fde691  jmp 0x00007EFC33FDC15E
00007efc33fde696  sub rsp, 0x08
00007efc33fde69a  push rax
00007efc33fde69b  push rcx
00007efc33fde69c  push rdx
00007efc33fde69d  push rdi
00007efc33fde69e  push rsi
00007efc33fde69f  push r8
00007efc33fde6a1  push r9
00007efc33fde6a3  push r10
00007efc33fde6a5  push r11
00007efc33fde6a7  sub rsp, 0xF0
00007efc33fde6ae  vmovaps [rsp], xmm0
00007efc33fde6b3  vmovaps [rsp+0x10], xmm1
00007efc33fde6b9  vmovaps [rsp+0x20], xmm2
00007efc33fde6bf  vmovaps [rsp+0x30], xmm3
00007efc33fde6c5  vmovaps [rsp+0x40], xmm4
00007efc33fde6cb  vmovaps [rsp+0x50], xmm5
00007efc33fde6d1  vmovaps [rsp+0x60], xmm6
00007efc33fde6d7  vmovaps [rsp+0x70], xmm7
00007efc33fde6dd  vmovaps [rsp+0x80], xmm8
00007efc33fde6e6  vmovaps [rsp+0x90], xmm10
00007efc33fde6ef  vmovaps [rsp+0xA0], xmm11
00007efc33fde6f8  vmovaps [rsp+0xB0], xmm12
00007efc33fde701  vmovaps [rsp+0xC0], xmm13
00007efc33fde70a  vmovaps [rsp+0xD0], xmm14
00007efc33fde713  vmovaps [rsp+0xE0], xmm15
00007efc33fde71c  sub rsp, 0x30
00007efc33fde720  movaps [rsp], xmm9
00007efc33fde725  movaps [rsp+0x10], xmm3
00007efc33fde72a  movaps [rsp+0x20], xmm1
00007efc33fde72f  lea rdi, [rsp]
00007efc33fde733  mov esi, 0x00
00007efc33fde738  mov rax, 0x5D9448894530
00007efc33fde742  call rax
00007efc33fde744  movaps xmm9, [rsp]
00007efc33fde749  add rsp, 0x30
00007efc33fde74d  vmovaps xmm0, [rsp]
00007efc33fde752  vmovaps xmm1, [rsp+0x10]
00007efc33fde758  vmovaps xmm2, [rsp+0x20]
00007efc33fde75e  vmovaps xmm3, [rsp+0x30]
00007efc33fde764  vmovaps xmm4, [rsp+0x40]
00007efc33fde76a  vmovaps xmm5, [rsp+0x50]
00007efc33fde770  vmovaps xmm6, [rsp+0x60]
00007efc33fde776  vmovaps xmm7, [rsp+0x70]
00007efc33fde77c  vmovaps xmm8, [rsp+0x80]
00007efc33fde785  vmovaps xmm10, [rsp+0x90]
00007efc33fde78e  vmovaps xmm11, [rsp+0xA0]
00007efc33fde797  vmovaps xmm12, [rsp+0xB0]
00007efc33fde7a0  vmovaps xmm13, [rsp+0xC0]
00007efc33fde7a9  vmovaps xmm14, [rsp+0xD0]
00007efc33fde7b2  vmovaps xmm15, [rsp+0xE0]
00007efc33fde7bb  add rsp, 0xF0
00007efc33fde7c2  pop r11
00007efc33fde7c4  pop r10
00007efc33fde7c6  pop r9
00007efc33fde7c8  pop r8
00007efc33fde7ca  pop rsi
00007efc33fde7cb  pop rdi
00007efc33fde7cc  pop rdx
00007efc33fde7cd  pop rcx
00007efc33fde7ce  pop rax
00007efc33fde7cf  add rsp, 0x08
00007efc33fde7d3  jmp 0x00007EFC33FDC1AA
00007efc33fde7d8  call 0x00007EFC33EB52F0
00007efc33fde7dd  jmp 0x00007EFC33FDC1B7
00007efc33fde7e2  sub rsp, 0x08
00007efc33fde7e6  push rax
00007efc33fde7e7  push rcx
00007efc33fde7e8  push rdx
00007efc33fde7e9  push rdi
00007efc33fde7ea  push rsi
00007efc33fde7eb  push r8
00007efc33fde7ed  push r9
00007efc33fde7ef  push r10
00007efc33fde7f1  push r11
00007efc33fde7f3  sub rsp, 0xF0
00007efc33fde7fa  vmovaps [rsp], xmm0
00007efc33fde7ff  vmovaps [rsp+0x10], xmm1
00007efc33fde805  vmovaps [rsp+0x20], xmm2
00007efc33fde80b  vmovaps [rsp+0x30], xmm3
00007efc33fde811  vmovaps [rsp+0x40], xmm4
00007efc33fde817  vmovaps [rsp+0x50], xmm5
00007efc33fde81d  vmovaps [rsp+0x60], xmm6
00007efc33fde823  vmovaps [rsp+0x70], xmm7
00007efc33fde829  vmovaps [rsp+0x80], xmm8
00007efc33fde832  vmovaps [rsp+0x90], xmm9
00007efc33fde83b  vmovaps [rsp+0xA0], xmm10
00007efc33fde844  vmovaps [rsp+0xB0], xmm11
00007efc33fde84d  vmovaps [rsp+0xC0], xmm12
00007efc33fde856  vmovaps [rsp+0xD0], xmm13
00007efc33fde85f  vmovaps [rsp+0xE0], xmm14
00007efc33fde868  sub rsp, 0x30
00007efc33fde86c  movaps [rsp], xmm15
00007efc33fde871  movaps [rsp+0x10], xmm3
00007efc33fde876  movaps [rsp+0x20], xmm7
00007efc33fde87b  lea rdi, [rsp]
00007efc33fde87f  mov esi, 0x00
00007efc33fde884  mov rax, 0x5D9448894530
00007efc33fde88e  call rax
00007efc33fde890  movaps xmm15, [rsp]
00007efc33fde895  add rsp, 0x30
00007efc33fde899  vmovaps xmm0, [rsp]
00007efc33fde89e  vmovaps xmm1, [rsp+0x10]
00007efc33fde8a4  vmovaps xmm2, [rsp+0x20]
00007efc33fde8aa  vmovaps xmm3, [rsp+0x30]
00007efc33fde8b0  vmovaps xmm4, [rsp+0x40]
00007efc33fde8b6  vmovaps xmm5, [rsp+0x50]
00007efc33fde8bc  vmovaps xmm6, [rsp+0x60]
00007efc33fde8c2  vmovaps xmm7, [rsp+0x70]
00007efc33fde8c8  vmovaps xmm8, [rsp+0x80]
00007efc33fde8d1  vmovaps xmm9, [rsp+0x90]
00007efc33fde8da  vmovaps xmm10, [rsp+0xA0]
00007efc33fde8e3  vmovaps xmm11, [rsp+0xB0]
00007efc33fde8ec  vmovaps xmm12, [rsp+0xC0]
00007efc33fde8f5  vmovaps xmm13, [rsp+0xD0]
00007efc33fde8fe  vmovaps xmm14, [rsp+0xE0]
00007efc33fde907  add rsp, 0xF0
00007efc33fde90e  pop r11
00007efc33fde910  pop r10
00007efc33fde912  pop r9
00007efc33fde914  pop r8
00007efc33fde916  pop rsi
00007efc33fde917  pop rdi
00007efc33fde918  pop rdx
00007efc33fde919  pop rcx
00007efc33fde91a  pop rax
00007efc33fde91b  add rsp, 0x08
00007efc33fde91f  jmp 0x00007EFC33FDC1E3
00007efc33fde924  sub rsp, 0x08
00007efc33fde928  push rax
00007efc33fde929  push rcx
00007efc33fde92a  push rdx
00007efc33fde92b  push rdi
00007efc33fde92c  push rsi
00007efc33fde92d  push r8
00007efc33fde92f  push r9
00007efc33fde931  push r10
00007efc33fde933  push r11
00007efc33fde935  sub rsp, 0xF0
00007efc33fde93c  vmovaps [rsp], xmm0
00007efc33fde941  vmovaps [rsp+0x10], xmm1
00007efc33fde947  vmovaps [rsp+0x20], xmm2
00007efc33fde94d  vmovaps [rsp+0x30], xmm4
00007efc33fde953  vmovaps [rsp+0x40], xmm5
00007efc33fde959  vmovaps [rsp+0x50], xmm6
00007efc33fde95f  vmovaps [rsp+0x60], xmm7
00007efc33fde965  vmovaps [rsp+0x70], xmm8
00007efc33fde96b  vmovaps [rsp+0x80], xmm9
00007efc33fde974  vmovaps [rsp+0x90], xmm10
00007efc33fde97d  vmovaps [rsp+0xA0], xmm11
00007efc33fde986  vmovaps [rsp+0xB0], xmm12
00007efc33fde98f  vmovaps [rsp+0xC0], xmm13
00007efc33fde998  vmovaps [rsp+0xD0], xmm14
00007efc33fde9a1  vmovaps [rsp+0xE0], xmm15
00007efc33fde9aa  sub rsp, 0x30
00007efc33fde9ae  movaps [rsp], xmm3
00007efc33fde9b2  movaps [rsp+0x10], xmm1
00007efc33fde9b7  movaps [rsp+0x20], xmm15
00007efc33fde9bd  lea rdi, [rsp]
00007efc33fde9c1  mov esi, 0x00
00007efc33fde9c6  mov rax, 0x5D9448894530
00007efc33fde9d0  call rax
00007efc33fde9d2  movaps xmm3, [rsp]
00007efc33fde9d6  add rsp, 0x30
00007efc33fde9da  vmovaps xmm0, [rsp]
00007efc33fde9df  vmovaps xmm1, [rsp+0x10]
00007efc33fde9e5  vmovaps xmm2, [rsp+0x20]
00007efc33fde9eb  vmovaps xmm4, [rsp+0x30]
00007efc33fde9f1  vmovaps xmm5, [rsp+0x40]
00007efc33fde9f7  vmovaps xmm6, [rsp+0x50]
00007efc33fde9fd  vmovaps xmm7, [rsp+0x60]
00007efc33fdea03  vmovaps xmm8, [rsp+0x70]
00007efc33fdea09  vmovaps xmm9, [rsp+0x80]
00007efc33fdea12  vmovaps xmm10, [rsp+0x90]
00007efc33fdea1b  vmovaps xmm11, [rsp+0xA0]
00007efc33fdea24  vmovaps xmm12, [rsp+0xB0]
00007efc33fdea2d  vmovaps xmm13, [rsp+0xC0]
00007efc33fdea36  vmovaps xmm14, [rsp+0xD0]
00007efc33fdea3f  vmovaps xmm15, [rsp+0xE0]
00007efc33fdea48  add rsp, 0xF0
00007efc33fdea4f  pop r11
00007efc33fdea51  pop r10
00007efc33fdea53  pop r9
00007efc33fdea55  pop r8
00007efc33fdea57  pop rsi
00007efc33fdea58  pop rdi
00007efc33fdea59  pop rdx
00007efc33fdea5a  pop rcx
00007efc33fdea5b  pop rax
00007efc33fdea5c  add rsp, 0x08
00007efc33fdea60  jmp 0x00007EFC33FDC272
00007efc33fdea65  call 0x00007EFC33EB52F0
00007efc33fdea6a  jmp 0x00007EFC33FDC27C
00007efc33fdea6f  sub rsp, 0x08
00007efc33fdea73  push rax
00007efc33fdea74  push rcx
00007efc33fdea75  push rdx
00007efc33fdea76  push rdi
00007efc33fdea77  push rsi
00007efc33fdea78  push r8
00007efc33fdea7a  push r9
00007efc33fdea7c  push r10
00007efc33fdea7e  push r11
00007efc33fdea80  sub rsp, 0xF0
00007efc33fdea87  vmovaps [rsp], xmm0
00007efc33fdea8c  vmovaps [rsp+0x10], xmm1
00007efc33fdea92  vmovaps [rsp+0x20], xmm2
00007efc33fdea98  vmovaps [rsp+0x30], xmm3
00007efc33fdea9e  vmovaps [rsp+0x40], xmm4
00007efc33fdeaa4  vmovaps [rsp+0x50], xmm5
00007efc33fdeaaa  vmovaps [rsp+0x60], xmm6
00007efc33fdeab0  vmovaps [rsp+0x70], xmm7
00007efc33fdeab6  vmovaps [rsp+0x80], xmm8
00007efc33fdeabf  vmovaps [rsp+0x90], xmm9
00007efc33fdeac8  vmovaps [rsp+0xA0], xmm10
00007efc33fdead1  vmovaps [rsp+0xB0], xmm11
00007efc33fdeada  vmovaps [rsp+0xC0], xmm12
00007efc33fdeae3  vmovaps [rsp+0xD0], xmm13
00007efc33fdeaec  vmovaps [rsp+0xE0], xmm14
00007efc33fdeaf5  sub rsp, 0x30
00007efc33fdeaf9  movaps [rsp], xmm15
00007efc33fdeafe  movaps [rsp+0x10], xmm14
00007efc33fdeb04  movaps [rsp+0x20], xmm4
00007efc33fdeb09  lea rdi, [rsp]
00007efc33fdeb0d  mov esi, 0x00
00007efc33fdeb12  mov rax, 0x5D9448894530
00007efc33fdeb1c  call rax
00007efc33fdeb1e  movaps xmm15, [rsp]
00007efc33fdeb23  add rsp, 0x30
00007efc33fdeb27  vmovaps xmm0, [rsp]
00007efc33fdeb2c  vmovaps xmm1, [rsp+0x10]
00007efc33fdeb32  vmovaps xmm2, [rsp+0x20]
00007efc33fdeb38  vmovaps xmm3, [rsp+0x30]
00007efc33fdeb3e  vmovaps xmm4, [rsp+0x40]
00007efc33fdeb44  vmovaps xmm5, [rsp+0x50]
00007efc33fdeb4a  vmovaps xmm6, [rsp+0x60]
00007efc33fdeb50  vmovaps xmm7, [rsp+0x70]
00007efc33fdeb56  vmovaps xmm8, [rsp+0x80]
00007efc33fdeb5f  vmovaps xmm9, [rsp+0x90]
00007efc33fdeb68  vmovaps xmm10, [rsp+0xA0]
00007efc33fdeb71  vmovaps xmm11, [rsp+0xB0]
00007efc33fdeb7a  vmovaps xmm12, [rsp+0xC0]
00007efc33fdeb83  vmovaps xmm13, [rsp+0xD0]
00007efc33fdeb8c  vmovaps xmm14, [rsp+0xE0]
00007efc33fdeb95  add rsp, 0xF0
00007efc33fdeb9c  pop r11
00007efc33fdeb9e  pop r10
00007efc33fdeba0  pop r9
00007efc33fdeba2  pop r8
00007efc33fdeba4  pop rsi
00007efc33fdeba5  pop rdi
00007efc33fdeba6  pop rdx
00007efc33fdeba7  pop rcx
00007efc33fdeba8  pop rax
00007efc33fdeba9  add rsp, 0x08
00007efc33fdebad  jmp 0x00007EFC33FDC2AA
00007efc33fdebb2  sub rsp, 0x08
00007efc33fdebb6  push rax
00007efc33fdebb7  push rcx
00007efc33fdebb8  push rdx
00007efc33fdebb9  push rdi
00007efc33fdebba  push rsi
00007efc33fdebbb  push r8
00007efc33fdebbd  push r9
00007efc33fdebbf  push r10
00007efc33fdebc1  push r11
00007efc33fdebc3  sub rsp, 0xF0
00007efc33fdebca  vmovaps [rsp], xmm0
00007efc33fdebcf  vmovaps [rsp+0x10], xmm1
00007efc33fdebd5  vmovaps [rsp+0x20], xmm2
00007efc33fdebdb  vmovaps [rsp+0x30], xmm3
00007efc33fdebe1  vmovaps [rsp+0x40], xmm4
00007efc33fdebe7  vmovaps [rsp+0x50], xmm5
00007efc33fdebed  vmovaps [rsp+0x60], xmm6
00007efc33fdebf3  vmovaps [rsp+0x70], xmm7
00007efc33fdebf9  vmovaps [rsp+0x80], xmm8
00007efc33fdec02  vmovaps [rsp+0x90], xmm9
00007efc33fdec0b  vmovaps [rsp+0xA0], xmm10
00007efc33fdec14  vmovaps [rsp+0xB0], xmm11
00007efc33fdec1d  vmovaps [rsp+0xC0], xmm12
00007efc33fdec26  vmovaps [rsp+0xD0], xmm13
00007efc33fdec2f  vmovaps [rsp+0xE0], xmm15
00007efc33fdec38  sub rsp, 0x30
00007efc33fdec3c  movaps [rsp], xmm14
00007efc33fdec41  movaps [rsp+0x10], xmm2
00007efc33fdec46  movaps [rsp+0x20], xmm1
00007efc33fdec4b  lea rdi, [rsp]
00007efc33fdec4f  mov esi, 0x00
00007efc33fdec54  mov rax, 0x5D9448894530
00007efc33fdec5e  call rax
00007efc33fdec60  movaps xmm14, [rsp]
00007efc33fdec65  add rsp, 0x30
00007efc33fdec69  vmovaps xmm0, [rsp]
00007efc33fdec6e  vmovaps xmm1, [rsp+0x10]
00007efc33fdec74  vmovaps xmm2, [rsp+0x20]
00007efc33fdec7a  vmovaps xmm3, [rsp+0x30]
00007efc33fdec80  vmovaps xmm4, [rsp+0x40]
00007efc33fdec86  vmovaps xmm5, [rsp+0x50]
00007efc33fdec8c  vmovaps xmm6, [rsp+0x60]
00007efc33fdec92  vmovaps xmm7, [rsp+0x70]
00007efc33fdec98  vmovaps xmm8, [rsp+0x80]
00007efc33fdeca1  vmovaps xmm9, [rsp+0x90]
00007efc33fdecaa  vmovaps xmm10, [rsp+0xA0]
00007efc33fdecb3  vmovaps xmm11, [rsp+0xB0]
00007efc33fdecbc  vmovaps xmm12, [rsp+0xC0]
00007efc33fdecc5  vmovaps xmm13, [rsp+0xD0]
00007efc33fdecce  vmovaps xmm15, [rsp+0xE0]
00007efc33fdecd7  add rsp, 0xF0
00007efc33fdecde  pop r11
00007efc33fdece0  pop r10
00007efc33fdece2  pop r9
00007efc33fdece4  pop r8
00007efc33fdece6  pop rsi
00007efc33fdece7  pop rdi
00007efc33fdece8  pop rdx
00007efc33fdece9  pop rcx
00007efc33fdecea  pop rax
00007efc33fdeceb  add rsp, 0x08
00007efc33fdecef  jmp 0x00007EFC33FDC2D0
00007efc33fdecf4  sub rsp, 0x08
00007efc33fdecf8  push rax
00007efc33fdecf9  push rcx
00007efc33fdecfa  push rdx
00007efc33fdecfb  push rdi
00007efc33fdecfc  push rsi
00007efc33fdecfd  push r8
00007efc33fdecff  push r9
00007efc33fded01  push r10
00007efc33fded03  push r11
00007efc33fded05  sub rsp, 0xF0
00007efc33fded0c  vmovaps [rsp], xmm0
00007efc33fded11  vmovaps [rsp+0x10], xmm2
00007efc33fded17  vmovaps [rsp+0x20], xmm3
00007efc33fded1d  vmovaps [rsp+0x30], xmm4
00007efc33fded23  vmovaps [rsp+0x40], xmm5
00007efc33fded29  vmovaps [rsp+0x50], xmm6
00007efc33fded2f  vmovaps [rsp+0x60], xmm7
00007efc33fded35  vmovaps [rsp+0x70], xmm8
00007efc33fded3b  vmovaps [rsp+0x80], xmm9
00007efc33fded44  vmovaps [rsp+0x90], xmm10
00007efc33fded4d  vmovaps [rsp+0xA0], xmm11
00007efc33fded56  vmovaps [rsp+0xB0], xmm12
00007efc33fded5f  vmovaps [rsp+0xC0], xmm13
00007efc33fded68  vmovaps [rsp+0xD0], xmm14
00007efc33fded71  vmovaps [rsp+0xE0], xmm15
00007efc33fded7a  sub rsp, 0x30
00007efc33fded7e  movaps [rsp], xmm1
00007efc33fded82  movaps [rsp+0x10], xmm4
00007efc33fded87  movaps [rsp+0x20], xmm9
00007efc33fded8d  lea rdi, [rsp]
00007efc33fded91  mov esi, 0x00
00007efc33fded96  mov rax, 0x5D9448894530
00007efc33fdeda0  call rax
00007efc33fdeda2  movaps xmm1, [rsp]
00007efc33fdeda6  add rsp, 0x30
00007efc33fdedaa  vmovaps xmm0, [rsp]
00007efc33fdedaf  vmovaps xmm2, [rsp+0x10]
00007efc33fdedb5  vmovaps xmm3, [rsp+0x20]
00007efc33fdedbb  vmovaps xmm4, [rsp+0x30]
00007efc33fdedc1  vmovaps xmm5, [rsp+0x40]
00007efc33fdedc7  vmovaps xmm6, [rsp+0x50]
00007efc33fdedcd  vmovaps xmm7, [rsp+0x60]
00007efc33fdedd3  vmovaps xmm8, [rsp+0x70]
00007efc33fdedd9  vmovaps xmm9, [rsp+0x80]
00007efc33fdede2  vmovaps xmm10, [rsp+0x90]
00007efc33fdedeb  vmovaps xmm11, [rsp+0xA0]
00007efc33fdedf4  vmovaps xmm12, [rsp+0xB0]
00007efc33fdedfd  vmovaps xmm13, [rsp+0xC0]
00007efc33fdee06  vmovaps xmm14, [rsp+0xD0]
00007efc33fdee0f  vmovaps xmm15, [rsp+0xE0]
00007efc33fdee18  add rsp, 0xF0
00007efc33fdee1f  pop r11
00007efc33fdee21  pop r10
00007efc33fdee23  pop r9
00007efc33fdee25  pop r8
00007efc33fdee27  pop rsi
00007efc33fdee28  pop rdi
00007efc33fdee29  pop rdx
00007efc33fdee2a  pop rcx
00007efc33fdee2b  pop rax
00007efc33fdee2c  add rsp, 0x08
00007efc33fdee30  jmp 0x00007EFC33FDC2EE
00007efc33fdee35  sub rsp, 0x08
00007efc33fdee39  push rax
00007efc33fdee3a  push rcx
00007efc33fdee3b  push rdx
00007efc33fdee3c  push rdi
00007efc33fdee3d  push rsi
00007efc33fdee3e  push r8
00007efc33fdee40  push r9
00007efc33fdee42  push r10
00007efc33fdee44  push r11
00007efc33fdee46  sub rsp, 0xF0
00007efc33fdee4d  vmovaps [rsp], xmm0
00007efc33fdee52  vmovaps [rsp+0x10], xmm1
00007efc33fdee58  vmovaps [rsp+0x20], xmm2
00007efc33fdee5e  vmovaps [rsp+0x30], xmm3
00007efc33fdee64  vmovaps [rsp+0x40], xmm5
00007efc33fdee6a  vmovaps [rsp+0x50], xmm6
00007efc33fdee70  vmovaps [rsp+0x60], xmm7
00007efc33fdee76  vmovaps [rsp+0x70], xmm8
00007efc33fdee7c  vmovaps [rsp+0x80], xmm9
00007efc33fdee85  vmovaps [rsp+0x90], xmm10
00007efc33fdee8e  vmovaps [rsp+0xA0], xmm11
00007efc33fdee97  vmovaps [rsp+0xB0], xmm12
00007efc33fdeea0  vmovaps [rsp+0xC0], xmm13
00007efc33fdeea9  vmovaps [rsp+0xD0], xmm14
00007efc33fdeeb2  vmovaps [rsp+0xE0], xmm15
00007efc33fdeebb  sub rsp, 0x30
00007efc33fdeebf  movaps [rsp], xmm4
00007efc33fdeec3  movaps [rsp+0x10], xmm2
00007efc33fdeec8  movaps [rsp+0x20], xmm9
00007efc33fdeece  lea rdi, [rsp]
00007efc33fdeed2  mov esi, 0x00
00007efc33fdeed7  mov rax, 0x5D9448894530
00007efc33fdeee1  call rax
00007efc33fdeee3  movaps xmm4, [rsp]
00007efc33fdeee7  add rsp, 0x30
00007efc33fdeeeb  vmovaps xmm0, [rsp]
00007efc33fdeef0  vmovaps xmm1, [rsp+0x10]
00007efc33fdeef6  vmovaps xmm2, [rsp+0x20]
00007efc33fdeefc  vmovaps xmm3, [rsp+0x30]
00007efc33fdef02  vmovaps xmm5, [rsp+0x40]
00007efc33fdef08  vmovaps xmm6, [rsp+0x50]
00007efc33fdef0e  vmovaps xmm7, [rsp+0x60]
00007efc33fdef14  vmovaps xmm8, [rsp+0x70]
00007efc33fdef1a  vmovaps xmm9, [rsp+0x80]
00007efc33fdef23  vmovaps xmm10, [rsp+0x90]
00007efc33fdef2c  vmovaps xmm11, [rsp+0xA0]
00007efc33fdef35  vmovaps xmm12, [rsp+0xB0]
00007efc33fdef3e  vmovaps xmm13, [rsp+0xC0]
00007efc33fdef47  vmovaps xmm14, [rsp+0xD0]
00007efc33fdef50  vmovaps xmm15, [rsp+0xE0]
00007efc33fdef59  add rsp, 0xF0
00007efc33fdef60  pop r11
00007efc33fdef62  pop r10
00007efc33fdef64  pop r9
00007efc33fdef66  pop r8
00007efc33fdef68  pop rsi
00007efc33fdef69  pop rdi
00007efc33fdef6a  pop rdx
00007efc33fdef6b  pop rcx
00007efc33fdef6c  pop rax
00007efc33fdef6d  add rsp, 0x08
00007efc33fdef71  jmp 0x00007EFC33FDC31E
00007efc33fdef76  sub rsp, 0x08
00007efc33fdef7a  push rax
00007efc33fdef7b  push rcx
00007efc33fdef7c  push rdx
00007efc33fdef7d  push rdi
00007efc33fdef7e  push rsi
00007efc33fdef7f  push r8
00007efc33fdef81  push r9
00007efc33fdef83  push r10
00007efc33fdef85  push r11
00007efc33fdef87  sub rsp, 0xF0
00007efc33fdef8e  vmovaps [rsp], xmm0
00007efc33fdef93  vmovaps [rsp+0x10], xmm1
00007efc33fdef99  vmovaps [rsp+0x20], xmm2
00007efc33fdef9f  vmovaps [rsp+0x30], xmm3
00007efc33fdefa5  vmovaps [rsp+0x40], xmm4
00007efc33fdefab  vmovaps [rsp+0x50], xmm5
00007efc33fdefb1  vmovaps [rsp+0x60], xmm6
00007efc33fdefb7  vmovaps [rsp+0x70], xmm7
00007efc33fdefbd  vmovaps [rsp+0x80], xmm8
00007efc33fdefc6  vmovaps [rsp+0x90], xmm10
00007efc33fdefcf  vmovaps [rsp+0xA0], xmm11
00007efc33fdefd8  vmovaps [rsp+0xB0], xmm12
00007efc33fdefe1  vmovaps [rsp+0xC0], xmm13
00007efc33fdefea  vmovaps [rsp+0xD0], xmm14
00007efc33fdeff3  vmovaps [rsp+0xE0], xmm15
00007efc33fdeffc  sub rsp, 0x30
00007efc33fdf000  movaps [rsp], xmm9
00007efc33fdf005  movaps [rsp+0x10], xmm2
00007efc33fdf00a  movaps [rsp+0x20], xmm1
00007efc33fdf00f  lea rdi, [rsp]
00007efc33fdf013  mov esi, 0x00
00007efc33fdf018  mov rax, 0x5D9448894530
00007efc33fdf022  call rax
00007efc33fdf024  movaps xmm9, [rsp]
00007efc33fdf029  add rsp, 0x30
00007efc33fdf02d  vmovaps xmm0, [rsp]
00007efc33fdf032  vmovaps xmm1, [rsp+0x10]
00007efc33fdf038  vmovaps xmm2, [rsp+0x20]
00007efc33fdf03e  vmovaps xmm3, [rsp+0x30]
00007efc33fdf044  vmovaps xmm4, [rsp+0x40]
00007efc33fdf04a  vmovaps xmm5, [rsp+0x50]
00007efc33fdf050  vmovaps xmm6, [rsp+0x60]
00007efc33fdf056  vmovaps xmm7, [rsp+0x70]
00007efc33fdf05c  vmovaps xmm8, [rsp+0x80]
00007efc33fdf065  vmovaps xmm10, [rsp+0x90]
00007efc33fdf06e  vmovaps xmm11, [rsp+0xA0]
00007efc33fdf077  vmovaps xmm12, [rsp+0xB0]
00007efc33fdf080  vmovaps xmm13, [rsp+0xC0]
00007efc33fdf089  vmovaps xmm14, [rsp+0xD0]
00007efc33fdf092  vmovaps xmm15, [rsp+0xE0]
00007efc33fdf09b  add rsp, 0xF0
00007efc33fdf0a2  pop r11
00007efc33fdf0a4  pop r10
00007efc33fdf0a6  pop r9
00007efc33fdf0a8  pop r8
00007efc33fdf0aa  pop rsi
00007efc33fdf0ab  pop rdi
00007efc33fdf0ac  pop rdx
00007efc33fdf0ad  pop rcx
00007efc33fdf0ae  pop rax
00007efc33fdf0af  add rsp, 0x08
00007efc33fdf0b3  jmp 0x00007EFC33FDC354
00007efc33fdf0b8  sub rsp, 0x08
00007efc33fdf0bc  push rax
00007efc33fdf0bd  push rcx
00007efc33fdf0be  push rdx
00007efc33fdf0bf  push rdi
00007efc33fdf0c0  push rsi
00007efc33fdf0c1  push r8
00007efc33fdf0c3  push r9
00007efc33fdf0c5  push r10
00007efc33fdf0c7  push r11
00007efc33fdf0c9  sub rsp, 0xF0
00007efc33fdf0d0  vmovaps [rsp], xmm0
00007efc33fdf0d5  vmovaps [rsp+0x10], xmm2
00007efc33fdf0db  vmovaps [rsp+0x20], xmm3
00007efc33fdf0e1  vmovaps [rsp+0x30], xmm4
00007efc33fdf0e7  vmovaps [rsp+0x40], xmm5
00007efc33fdf0ed  vmovaps [rsp+0x50], xmm6
00007efc33fdf0f3  vmovaps [rsp+0x60], xmm7
00007efc33fdf0f9  vmovaps [rsp+0x70], xmm8
00007efc33fdf0ff  vmovaps [rsp+0x80], xmm9
00007efc33fdf108  vmovaps [rsp+0x90], xmm10
00007efc33fdf111  vmovaps [rsp+0xA0], xmm11
00007efc33fdf11a  vmovaps [rsp+0xB0], xmm12
00007efc33fdf123  vmovaps [rsp+0xC0], xmm13
00007efc33fdf12c  vmovaps [rsp+0xD0], xmm14
00007efc33fdf135  vmovaps [rsp+0xE0], xmm15
00007efc33fdf13e  sub rsp, 0x30
00007efc33fdf142  movaps [rsp], xmm1
00007efc33fdf146  movaps [rsp+0x10], xmm15
00007efc33fdf14c  movaps [rsp+0x20], xmm6
00007efc33fdf151  lea rdi, [rsp]
00007efc33fdf155  mov esi, 0x00
00007efc33fdf15a  mov rax, 0x5D9448894530
00007efc33fdf164  call rax
00007efc33fdf166  movaps xmm1, [rsp]
00007efc33fdf16a  add rsp, 0x30
00007efc33fdf16e  vmovaps xmm0, [rsp]
00007efc33fdf173  vmovaps xmm2, [rsp+0x10]
00007efc33fdf179  vmovaps xmm3, [rsp+0x20]
00007efc33fdf17f  vmovaps xmm4, [rsp+0x30]
00007efc33fdf185  vmovaps xmm5, [rsp+0x40]
00007efc33fdf18b  vmovaps xmm6, [rsp+0x50]
00007efc33fdf191  vmovaps xmm7, [rsp+0x60]
00007efc33fdf197  vmovaps xmm8, [rsp+0x70]
00007efc33fdf19d  vmovaps xmm9, [rsp+0x80]
00007efc33fdf1a6  vmovaps xmm10, [rsp+0x90]
00007efc33fdf1af  vmovaps xmm11, [rsp+0xA0]
00007efc33fdf1b8  vmovaps xmm12, [rsp+0xB0]
00007efc33fdf1c1  vmovaps xmm13, [rsp+0xC0]
00007efc33fdf1ca  vmovaps xmm14, [rsp+0xD0]
00007efc33fdf1d3  vmovaps xmm15, [rsp+0xE0]
00007efc33fdf1dc  add rsp, 0xF0
00007efc33fdf1e3  pop r11
00007efc33fdf1e5  pop r10
00007efc33fdf1e7  pop r9
00007efc33fdf1e9  pop r8
00007efc33fdf1eb  pop rsi
00007efc33fdf1ec  pop rdi
00007efc33fdf1ed  pop rdx
00007efc33fdf1ee  pop rcx
00007efc33fdf1ef  pop rax
00007efc33fdf1f0  add rsp, 0x08
00007efc33fdf1f4  jmp 0x00007EFC33FDC375
00007efc33fdf1f9  sub rsp, 0x08
00007efc33fdf1fd  push rax
00007efc33fdf1fe  push rcx
00007efc33fdf1ff  push rdx
00007efc33fdf200  push rdi
00007efc33fdf201  push rsi
00007efc33fdf202  push r8
00007efc33fdf204  push r9
00007efc33fdf206  push r10
00007efc33fdf208  push r11
00007efc33fdf20a  sub rsp, 0xF0
00007efc33fdf211  vmovaps [rsp], xmm0
00007efc33fdf216  vmovaps [rsp+0x10], xmm1
00007efc33fdf21c  vmovaps [rsp+0x20], xmm2
00007efc33fdf222  vmovaps [rsp+0x30], xmm3
00007efc33fdf228  vmovaps [rsp+0x40], xmm4
00007efc33fdf22e  vmovaps [rsp+0x50], xmm5
00007efc33fdf234  vmovaps [rsp+0x60], xmm6
00007efc33fdf23a  vmovaps [rsp+0x70], xmm7
00007efc33fdf240  vmovaps [rsp+0x80], xmm8
00007efc33fdf249  vmovaps [rsp+0x90], xmm9
00007efc33fdf252  vmovaps [rsp+0xA0], xmm10
00007efc33fdf25b  vmovaps [rsp+0xB0], xmm11
00007efc33fdf264  vmovaps [rsp+0xC0], xmm12
00007efc33fdf26d  vmovaps [rsp+0xD0], xmm13
00007efc33fdf276  vmovaps [rsp+0xE0], xmm14
00007efc33fdf27f  sub rsp, 0x30
00007efc33fdf283  movaps [rsp], xmm15
00007efc33fdf288  movaps [rsp+0x10], xmm5
00007efc33fdf28d  movaps [rsp+0x20], xmm3
00007efc33fdf292  lea rdi, [rsp]
00007efc33fdf296  mov esi, 0x00
00007efc33fdf29b  mov rax, 0x5D9448894530
00007efc33fdf2a5  call rax
00007efc33fdf2a7  movaps xmm15, [rsp]
00007efc33fdf2ac  add rsp, 0x30
00007efc33fdf2b0  vmovaps xmm0, [rsp]
00007efc33fdf2b5  vmovaps xmm1, [rsp+0x10]
00007efc33fdf2bb  vmovaps xmm2, [rsp+0x20]
00007efc33fdf2c1  vmovaps xmm3, [rsp+0x30]
00007efc33fdf2c7  vmovaps xmm4, [rsp+0x40]
00007efc33fdf2cd  vmovaps xmm5, [rsp+0x50]
00007efc33fdf2d3  vmovaps xmm6, [rsp+0x60]
00007efc33fdf2d9  vmovaps xmm7, [rsp+0x70]
00007efc33fdf2df  vmovaps xmm8, [rsp+0x80]
00007efc33fdf2e8  vmovaps xmm9, [rsp+0x90]
00007efc33fdf2f1  vmovaps xmm10, [rsp+0xA0]
00007efc33fdf2fa  vmovaps xmm11, [rsp+0xB0]
00007efc33fdf303  vmovaps xmm12, [rsp+0xC0]
00007efc33fdf30c  vmovaps xmm13, [rsp+0xD0]
00007efc33fdf315  vmovaps xmm14, [rsp+0xE0]
00007efc33fdf31e  add rsp, 0xF0
00007efc33fdf325  pop r11
00007efc33fdf327  pop r10
00007efc33fdf329  pop r9
00007efc33fdf32b  pop r8
00007efc33fdf32d  pop rsi
00007efc33fdf32e  pop rdi
00007efc33fdf32f  pop rdx
00007efc33fdf330  pop rcx
00007efc33fdf331  pop rax
00007efc33fdf332  add rsp, 0x08
00007efc33fdf336  jmp 0x00007EFC33FDC38F
00007efc33fdf33b  sub rsp, 0x08
00007efc33fdf33f  push rax
00007efc33fdf340  push rcx
00007efc33fdf341  push rdx
00007efc33fdf342  push rdi
00007efc33fdf343  push rsi
00007efc33fdf344  push r8
00007efc33fdf346  push r9
00007efc33fdf348  push r10
00007efc33fdf34a  push r11
00007efc33fdf34c  sub rsp, 0xF0
00007efc33fdf353  vmovaps [rsp], xmm0
00007efc33fdf358  vmovaps [rsp+0x10], xmm1
00007efc33fdf35e  vmovaps [rsp+0x20], xmm2
00007efc33fdf364  vmovaps [rsp+0x30], xmm3
00007efc33fdf36a  vmovaps [rsp+0x40], xmm4
00007efc33fdf370  vmovaps [rsp+0x50], xmm6
00007efc33fdf376  vmovaps [rsp+0x60], xmm7
00007efc33fdf37c  vmovaps [rsp+0x70], xmm8
00007efc33fdf382  vmovaps [rsp+0x80], xmm9
00007efc33fdf38b  vmovaps [rsp+0x90], xmm10
00007efc33fdf394  vmovaps [rsp+0xA0], xmm11
00007efc33fdf39d  vmovaps [rsp+0xB0], xmm12
00007efc33fdf3a6  vmovaps [rsp+0xC0], xmm13
00007efc33fdf3af  vmovaps [rsp+0xD0], xmm14
00007efc33fdf3b8  vmovaps [rsp+0xE0], xmm15
00007efc33fdf3c1  sub rsp, 0x30
00007efc33fdf3c5  movaps [rsp], xmm5
00007efc33fdf3c9  movaps [rsp+0x10], xmm8
00007efc33fdf3cf  movaps [rsp+0x20], xmm6
00007efc33fdf3d4  lea rdi, [rsp]
00007efc33fdf3d8  mov esi, 0x00
00007efc33fdf3dd  mov rax, 0x5D9448894530
00007efc33fdf3e7  call rax
00007efc33fdf3e9  movaps xmm5, [rsp]
00007efc33fdf3ed  add rsp, 0x30
00007efc33fdf3f1  vmovaps xmm0, [rsp]
00007efc33fdf3f6  vmovaps xmm1, [rsp+0x10]
00007efc33fdf3fc  vmovaps xmm2, [rsp+0x20]
00007efc33fdf402  vmovaps xmm3, [rsp+0x30]
00007efc33fdf408  vmovaps xmm4, [rsp+0x40]
00007efc33fdf40e  vmovaps xmm6, [rsp+0x50]
00007efc33fdf414  vmovaps xmm7, [rsp+0x60]
00007efc33fdf41a  vmovaps xmm8, [rsp+0x70]
00007efc33fdf420  vmovaps xmm9, [rsp+0x80]
00007efc33fdf429  vmovaps xmm10, [rsp+0x90]
00007efc33fdf432  vmovaps xmm11, [rsp+0xA0]
00007efc33fdf43b  vmovaps xmm12, [rsp+0xB0]
00007efc33fdf444  vmovaps xmm13, [rsp+0xC0]
00007efc33fdf44d  vmovaps xmm14, [rsp+0xD0]
00007efc33fdf456  vmovaps xmm15, [rsp+0xE0]
00007efc33fdf45f  add rsp, 0xF0
00007efc33fdf466  pop r11
00007efc33fdf468  pop r10
00007efc33fdf46a  pop r9
00007efc33fdf46c  pop r8
00007efc33fdf46e  pop rsi
00007efc33fdf46f  pop rdi
00007efc33fdf470  pop rdx
00007efc33fdf471  pop rcx
00007efc33fdf472  pop rax
00007efc33fdf473  add rsp, 0x08
00007efc33fdf477  jmp 0x00007EFC33FDC3B3
00007efc33fdf47c  sub rsp, 0x08
00007efc33fdf480  push rax
00007efc33fdf481  push rcx
00007efc33fdf482  push rdx
00007efc33fdf483  push rdi
00007efc33fdf484  push rsi
00007efc33fdf485  push r8
00007efc33fdf487  push r9
00007efc33fdf489  push r10
00007efc33fdf48b  push r11
00007efc33fdf48d  sub rsp, 0xF0
00007efc33fdf494  vmovaps [rsp], xmm0
00007efc33fdf499  vmovaps [rsp+0x10], xmm1
00007efc33fdf49f  vmovaps [rsp+0x20], xmm2
00007efc33fdf4a5  vmovaps [rsp+0x30], xmm3
00007efc33fdf4ab  vmovaps [rsp+0x40], xmm4
00007efc33fdf4b1  vmovaps [rsp+0x50], xmm5
00007efc33fdf4b7  vmovaps [rsp+0x60], xmm7
00007efc33fdf4bd  vmovaps [rsp+0x70], xmm8
00007efc33fdf4c3  vmovaps [rsp+0x80], xmm9
00007efc33fdf4cc  vmovaps [rsp+0x90], xmm10
00007efc33fdf4d5  vmovaps [rsp+0xA0], xmm11
00007efc33fdf4de  vmovaps [rsp+0xB0], xmm12
00007efc33fdf4e7  vmovaps [rsp+0xC0], xmm13
00007efc33fdf4f0  vmovaps [rsp+0xD0], xmm14
00007efc33fdf4f9  vmovaps [rsp+0xE0], xmm15
00007efc33fdf502  sub rsp, 0x30
00007efc33fdf506  movaps [rsp], xmm6
00007efc33fdf50a  movaps [rsp+0x10], xmm10
00007efc33fdf510  movaps [rsp+0x20], xmm8
00007efc33fdf516  lea rdi, [rsp]
00007efc33fdf51a  mov esi, 0x00
00007efc33fdf51f  mov rax, 0x5D9448894530
00007efc33fdf529  call rax
00007efc33fdf52b  movaps xmm6, [rsp]
00007efc33fdf52f  add rsp, 0x30
00007efc33fdf533  vmovaps xmm0, [rsp]
00007efc33fdf538  vmovaps xmm1, [rsp+0x10]
00007efc33fdf53e  vmovaps xmm2, [rsp+0x20]
00007efc33fdf544  vmovaps xmm3, [rsp+0x30]
00007efc33fdf54a  vmovaps xmm4, [rsp+0x40]
00007efc33fdf550  vmovaps xmm5, [rsp+0x50]
00007efc33fdf556  vmovaps xmm7, [rsp+0x60]
00007efc33fdf55c  vmovaps xmm8, [rsp+0x70]
00007efc33fdf562  vmovaps xmm9, [rsp+0x80]
00007efc33fdf56b  vmovaps xmm10, [rsp+0x90]
00007efc33fdf574  vmovaps xmm11, [rsp+0xA0]
00007efc33fdf57d  vmovaps xmm12, [rsp+0xB0]
00007efc33fdf586  vmovaps xmm13, [rsp+0xC0]
00007efc33fdf58f  vmovaps xmm14, [rsp+0xD0]
00007efc33fdf598  vmovaps xmm15, [rsp+0xE0]
00007efc33fdf5a1  add rsp, 0xF0
00007efc33fdf5a8  pop r11
00007efc33fdf5aa  pop r10
00007efc33fdf5ac  pop r9
00007efc33fdf5ae  pop r8
00007efc33fdf5b0  pop rsi
00007efc33fdf5b1  pop rdi
00007efc33fdf5b2  pop rdx
00007efc33fdf5b3  pop rcx
00007efc33fdf5b4  pop rax
00007efc33fdf5b5  add rsp, 0x08
00007efc33fdf5b9  jmp 0x00007EFC33FDC3D8
00007efc33fdf5be  sub rsp, 0x08
00007efc33fdf5c2  push rax
00007efc33fdf5c3  push rcx
00007efc33fdf5c4  push rdx
00007efc33fdf5c5  push rdi
00007efc33fdf5c6  push rsi
00007efc33fdf5c7  push r8
00007efc33fdf5c9  push r9
00007efc33fdf5cb  push r10
00007efc33fdf5cd  push r11
00007efc33fdf5cf  sub rsp, 0xF0
00007efc33fdf5d6  vmovaps [rsp], xmm0
00007efc33fdf5db  vmovaps [rsp+0x10], xmm1
00007efc33fdf5e1  vmovaps [rsp+0x20], xmm2
00007efc33fdf5e7  vmovaps [rsp+0x30], xmm3
00007efc33fdf5ed  vmovaps [rsp+0x40], xmm4
00007efc33fdf5f3  vmovaps [rsp+0x50], xmm5
00007efc33fdf5f9  vmovaps [rsp+0x60], xmm6
00007efc33fdf5ff  vmovaps [rsp+0x70], xmm7
00007efc33fdf605  vmovaps [rsp+0x80], xmm8
00007efc33fdf60e  vmovaps [rsp+0x90], xmm9
00007efc33fdf617  vmovaps [rsp+0xA0], xmm11
00007efc33fdf620  vmovaps [rsp+0xB0], xmm12
00007efc33fdf629  vmovaps [rsp+0xC0], xmm13
00007efc33fdf632  vmovaps [rsp+0xD0], xmm14
00007efc33fdf63b  vmovaps [rsp+0xE0], xmm15
00007efc33fdf644  sub rsp, 0x30
00007efc33fdf648  movaps [rsp], xmm10
00007efc33fdf64d  movaps [rsp+0x10], xmm8
00007efc33fdf653  movaps [rsp+0x20], xmm14
00007efc33fdf659  lea rdi, [rsp]
00007efc33fdf65d  mov esi, 0x00
00007efc33fdf662  mov rax, 0x5D9448894530
00007efc33fdf66c  call rax
00007efc33fdf66e  movaps xmm10, [rsp]
00007efc33fdf673  add rsp, 0x30
00007efc33fdf677  vmovaps xmm0, [rsp]
00007efc33fdf67c  vmovaps xmm1, [rsp+0x10]
00007efc33fdf682  vmovaps xmm2, [rsp+0x20]
00007efc33fdf688  vmovaps xmm3, [rsp+0x30]
00007efc33fdf68e  vmovaps xmm4, [rsp+0x40]
00007efc33fdf694  vmovaps xmm5, [rsp+0x50]
00007efc33fdf69a  vmovaps xmm6, [rsp+0x60]
00007efc33fdf6a0  vmovaps xmm7, [rsp+0x70]
00007efc33fdf6a6  vmovaps xmm8, [rsp+0x80]
00007efc33fdf6af  vmovaps xmm9, [rsp+0x90]
00007efc33fdf6b8  vmovaps xmm11, [rsp+0xA0]
00007efc33fdf6c1  vmovaps xmm12, [rsp+0xB0]
00007efc33fdf6ca  vmovaps xmm13, [rsp+0xC0]
00007efc33fdf6d3  vmovaps xmm14, [rsp+0xD0]
00007efc33fdf6dc  vmovaps xmm15, [rsp+0xE0]
00007efc33fdf6e5  add rsp, 0xF0
00007efc33fdf6ec  pop r11
00007efc33fdf6ee  pop r10
00007efc33fdf6f0  pop r9
00007efc33fdf6f2  pop r8
00007efc33fdf6f4  pop rsi
00007efc33fdf6f5  pop rdi
00007efc33fdf6f6  pop rdx
00007efc33fdf6f7  pop rcx
00007efc33fdf6f8  pop rax
00007efc33fdf6f9  add rsp, 0x08
00007efc33fdf6fd  jmp 0x00007EFC33FDC3F8
00007efc33fdf702  sub rsp, 0x08
00007efc33fdf706  push rax
00007efc33fdf707  push rcx
00007efc33fdf708  push rdx
00007efc33fdf709  push rdi
00007efc33fdf70a  push rsi
00007efc33fdf70b  push r8
00007efc33fdf70d  push r9
00007efc33fdf70f  push r10
00007efc33fdf711  push r11
00007efc33fdf713  sub rsp, 0xF0
00007efc33fdf71a  vmovaps [rsp], xmm0
00007efc33fdf71f  vmovaps [rsp+0x10], xmm1
00007efc33fdf725  vmovaps [rsp+0x20], xmm2
00007efc33fdf72b  vmovaps [rsp+0x30], xmm3
00007efc33fdf731  vmovaps [rsp+0x40], xmm4
00007efc33fdf737  vmovaps [rsp+0x50], xmm5
00007efc33fdf73d  vmovaps [rsp+0x60], xmm6
00007efc33fdf743  vmovaps [rsp+0x70], xmm7
00007efc33fdf749  vmovaps [rsp+0x80], xmm8
00007efc33fdf752  vmovaps [rsp+0x90], xmm9
00007efc33fdf75b  vmovaps [rsp+0xA0], xmm10
00007efc33fdf764  vmovaps [rsp+0xB0], xmm11
00007efc33fdf76d  vmovaps [rsp+0xC0], xmm12
00007efc33fdf776  vmovaps [rsp+0xD0], xmm13
00007efc33fdf77f  vmovaps [rsp+0xE0], xmm15
00007efc33fdf788  sub rsp, 0x30
00007efc33fdf78c  movaps [rsp], xmm14
00007efc33fdf791  movaps [rsp+0x10], xmm8
00007efc33fdf797  movaps [rsp+0x20], xmm4
00007efc33fdf79c  lea rdi, [rsp]
00007efc33fdf7a0  mov esi, 0x00
00007efc33fdf7a5  mov rax, 0x5D9448894530
00007efc33fdf7af  call rax
00007efc33fdf7b1  movaps xmm14, [rsp]
00007efc33fdf7b6  add rsp, 0x30
00007efc33fdf7ba  vmovaps xmm0, [rsp]
00007efc33fdf7bf  vmovaps xmm1, [rsp+0x10]
00007efc33fdf7c5  vmovaps xmm2, [rsp+0x20]
00007efc33fdf7cb  vmovaps xmm3, [rsp+0x30]
00007efc33fdf7d1  vmovaps xmm4, [rsp+0x40]
00007efc33fdf7d7  vmovaps xmm5, [rsp+0x50]
00007efc33fdf7dd  vmovaps xmm6, [rsp+0x60]
00007efc33fdf7e3  vmovaps xmm7, [rsp+0x70]
00007efc33fdf7e9  vmovaps xmm8, [rsp+0x80]
00007efc33fdf7f2  vmovaps xmm9, [rsp+0x90]
00007efc33fdf7fb  vmovaps xmm10, [rsp+0xA0]
00007efc33fdf804  vmovaps xmm11, [rsp+0xB0]
00007efc33fdf80d  vmovaps xmm12, [rsp+0xC0]
00007efc33fdf816  vmovaps xmm13, [rsp+0xD0]
00007efc33fdf81f  vmovaps xmm15, [rsp+0xE0]
00007efc33fdf828  add rsp, 0xF0
00007efc33fdf82f  pop r11
00007efc33fdf831  pop r10
00007efc33fdf833  pop r9
00007efc33fdf835  pop r8
00007efc33fdf837  pop rsi
00007efc33fdf838  pop rdi
00007efc33fdf839  pop rdx
00007efc33fdf83a  pop rcx
00007efc33fdf83b  pop rax
00007efc33fdf83c  add rsp, 0x08
00007efc33fdf840  jmp 0x00007EFC33FDC418
00007efc33fdf845  sub rsp, 0x08
00007efc33fdf849  push rax
00007efc33fdf84a  push rcx
00007efc33fdf84b  push rdx
00007efc33fdf84c  push rdi
00007efc33fdf84d  push rsi
00007efc33fdf84e  push r8
00007efc33fdf850  push r9
00007efc33fdf852  push r10
00007efc33fdf854  push r11
00007efc33fdf856  sub rsp, 0xF0
00007efc33fdf85d  vmovaps [rsp], xmm0
00007efc33fdf862  vmovaps [rsp+0x10], xmm1
00007efc33fdf868  vmovaps [rsp+0x20], xmm2
00007efc33fdf86e  vmovaps [rsp+0x30], xmm3
00007efc33fdf874  vmovaps [rsp+0x40], xmm5
00007efc33fdf87a  vmovaps [rsp+0x50], xmm6
00007efc33fdf880  vmovaps [rsp+0x60], xmm7
00007efc33fdf886  vmovaps [rsp+0x70], xmm8
00007efc33fdf88c  vmovaps [rsp+0x80], xmm9
00007efc33fdf895  vmovaps [rsp+0x90], xmm10
00007efc33fdf89e  vmovaps [rsp+0xA0], xmm11
00007efc33fdf8a7  vmovaps [rsp+0xB0], xmm12
00007efc33fdf8b0  vmovaps [rsp+0xC0], xmm13
00007efc33fdf8b9  vmovaps [rsp+0xD0], xmm14
00007efc33fdf8c2  vmovaps [rsp+0xE0], xmm15
00007efc33fdf8cb  sub rsp, 0x30
00007efc33fdf8cf  movaps [rsp], xmm4
00007efc33fdf8d3  movaps [rsp+0x10], xmm13
00007efc33fdf8d9  movaps [rsp+0x20], xmm8
00007efc33fdf8df  lea rdi, [rsp]
00007efc33fdf8e3  mov esi, 0x00
00007efc33fdf8e8  mov rax, 0x5D9448894530
00007efc33fdf8f2  call rax
00007efc33fdf8f4  movaps xmm4, [rsp]
00007efc33fdf8f8  add rsp, 0x30
00007efc33fdf8fc  vmovaps xmm0, [rsp]
00007efc33fdf901  vmovaps xmm1, [rsp+0x10]
00007efc33fdf907  vmovaps xmm2, [rsp+0x20]
00007efc33fdf90d  vmovaps xmm3, [rsp+0x30]
00007efc33fdf913  vmovaps xmm5, [rsp+0x40]
00007efc33fdf919  vmovaps xmm6, [rsp+0x50]
00007efc33fdf91f  vmovaps xmm7, [rsp+0x60]
00007efc33fdf925  vmovaps xmm8, [rsp+0x70]
00007efc33fdf92b  vmovaps xmm9, [rsp+0x80]
00007efc33fdf934  vmovaps xmm10, [rsp+0x90]
00007efc33fdf93d  vmovaps xmm11, [rsp+0xA0]
00007efc33fdf946  vmovaps xmm12, [rsp+0xB0]
00007efc33fdf94f  vmovaps xmm13, [rsp+0xC0]
00007efc33fdf958  vmovaps xmm14, [rsp+0xD0]
00007efc33fdf961  vmovaps xmm15, [rsp+0xE0]
00007efc33fdf96a  add rsp, 0xF0
00007efc33fdf971  pop r11
00007efc33fdf973  pop r10
00007efc33fdf975  pop r9
00007efc33fdf977  pop r8
00007efc33fdf979  pop rsi
00007efc33fdf97a  pop rdi
00007efc33fdf97b  pop rdx
00007efc33fdf97c  pop rcx
00007efc33fdf97d  pop rax
00007efc33fdf97e  add rsp, 0x08
00007efc33fdf982  jmp 0x00007EFC33FDC43D
00007efc33fdf987  sub rsp, 0x08
00007efc33fdf98b  push rax
00007efc33fdf98c  push rcx
00007efc33fdf98d  push rdx
00007efc33fdf98e  push rdi
00007efc33fdf98f  push rsi
00007efc33fdf990  push r8
00007efc33fdf992  push r9
00007efc33fdf994  push r10
00007efc33fdf996  push r11
00007efc33fdf998  sub rsp, 0xF0
00007efc33fdf99f  vmovaps [rsp], xmm0
00007efc33fdf9a4  vmovaps [rsp+0x10], xmm1
00007efc33fdf9aa  vmovaps [rsp+0x20], xmm2
00007efc33fdf9b0  vmovaps [rsp+0x30], xmm3
00007efc33fdf9b6  vmovaps [rsp+0x40], xmm4
00007efc33fdf9bc  vmovaps [rsp+0x50], xmm5
00007efc33fdf9c2  vmovaps [rsp+0x60], xmm6
00007efc33fdf9c8  vmovaps [rsp+0x70], xmm7
00007efc33fdf9ce  vmovaps [rsp+0x80], xmm8
00007efc33fdf9d7  vmovaps [rsp+0x90], xmm9
00007efc33fdf9e0  vmovaps [rsp+0xA0], xmm10
00007efc33fdf9e9  vmovaps [rsp+0xB0], xmm11
00007efc33fdf9f2  vmovaps [rsp+0xC0], xmm12
00007efc33fdf9fb  vmovaps [rsp+0xD0], xmm14
00007efc33fdfa04  vmovaps [rsp+0xE0], xmm15
00007efc33fdfa0d  sub rsp, 0x30
00007efc33fdfa11  movaps [rsp], xmm13
00007efc33fdfa16  movaps [rsp+0x10], xmm15
00007efc33fdfa1c  movaps [rsp+0x20], xmm9
00007efc33fdfa22  lea rdi, [rsp]
00007efc33fdfa26  mov esi, 0x00
00007efc33fdfa2b  mov rax, 0x5D9448894530
00007efc33fdfa35  call rax
00007efc33fdfa37  movaps xmm13, [rsp]
00007efc33fdfa3c  add rsp, 0x30
00007efc33fdfa40  vmovaps xmm0, [rsp]
00007efc33fdfa45  vmovaps xmm1, [rsp+0x10]
00007efc33fdfa4b  vmovaps xmm2, [rsp+0x20]
00007efc33fdfa51  vmovaps xmm3, [rsp+0x30]
00007efc33fdfa57  vmovaps xmm4, [rsp+0x40]
00007efc33fdfa5d  vmovaps xmm5, [rsp+0x50]
00007efc33fdfa63  vmovaps xmm6, [rsp+0x60]
00007efc33fdfa69  vmovaps xmm7, [rsp+0x70]
00007efc33fdfa6f  vmovaps xmm8, [rsp+0x80]
00007efc33fdfa78  vmovaps xmm9, [rsp+0x90]
00007efc33fdfa81  vmovaps xmm10, [rsp+0xA0]
00007efc33fdfa8a  vmovaps xmm11, [rsp+0xB0]
00007efc33fdfa93  vmovaps xmm12, [rsp+0xC0]
00007efc33fdfa9c  vmovaps xmm14, [rsp+0xD0]
00007efc33fdfaa5  vmovaps xmm15, [rsp+0xE0]
00007efc33fdfaae  add rsp, 0xF0
00007efc33fdfab5  pop r11
00007efc33fdfab7  pop r10
00007efc33fdfab9  pop r9
00007efc33fdfabb  pop r8
00007efc33fdfabd  pop rsi
00007efc33fdfabe  pop rdi
00007efc33fdfabf  pop rdx
00007efc33fdfac0  pop rcx
00007efc33fdfac1  pop rax
00007efc33fdfac2  add rsp, 0x08
00007efc33fdfac6  jmp 0x00007EFC33FDC458
00007efc33fdfacb  sub rsp, 0x08
00007efc33fdfacf  push rax
00007efc33fdfad0  push rcx
00007efc33fdfad1  push rdx
00007efc33fdfad2  push rdi
00007efc33fdfad3  push rsi
00007efc33fdfad4  push r8
00007efc33fdfad6  push r9
00007efc33fdfad8  push r10
00007efc33fdfada  push r11
00007efc33fdfadc  sub rsp, 0xF0
00007efc33fdfae3  vmovaps [rsp], xmm0
00007efc33fdfae8  vmovaps [rsp+0x10], xmm1
00007efc33fdfaee  vmovaps [rsp+0x20], xmm2
00007efc33fdfaf4  vmovaps [rsp+0x30], xmm3
00007efc33fdfafa  vmovaps [rsp+0x40], xmm4
00007efc33fdfb00  vmovaps [rsp+0x50], xmm5
00007efc33fdfb06  vmovaps [rsp+0x60], xmm6
00007efc33fdfb0c  vmovaps [rsp+0x70], xmm7
00007efc33fdfb12  vmovaps [rsp+0x80], xmm8
00007efc33fdfb1b  vmovaps [rsp+0x90], xmm9
00007efc33fdfb24  vmovaps [rsp+0xA0], xmm10
00007efc33fdfb2d  vmovaps [rsp+0xB0], xmm11
00007efc33fdfb36  vmovaps [rsp+0xC0], xmm12
00007efc33fdfb3f  vmovaps [rsp+0xD0], xmm13
00007efc33fdfb48  vmovaps [rsp+0xE0], xmm14
00007efc33fdfb51  sub rsp, 0x30
00007efc33fdfb55  movaps [rsp], xmm15
00007efc33fdfb5a  movaps [rsp+0x10], xmm1
00007efc33fdfb5f  movaps [rsp+0x20], xmm5
00007efc33fdfb64  lea rdi, [rsp]
00007efc33fdfb68  mov esi, 0x00
00007efc33fdfb6d  mov rax, 0x5D9448894530
00007efc33fdfb77  call rax
00007efc33fdfb79  movaps xmm15, [rsp]
00007efc33fdfb7e  add rsp, 0x30
00007efc33fdfb82  vmovaps xmm0, [rsp]
00007efc33fdfb87  vmovaps xmm1, [rsp+0x10]
00007efc33fdfb8d  vmovaps xmm2, [rsp+0x20]
00007efc33fdfb93  vmovaps xmm3, [rsp+0x30]
00007efc33fdfb99  vmovaps xmm4, [rsp+0x40]
00007efc33fdfb9f  vmovaps xmm5, [rsp+0x50]
00007efc33fdfba5  vmovaps xmm6, [rsp+0x60]
00007efc33fdfbab  vmovaps xmm7, [rsp+0x70]
00007efc33fdfbb1  vmovaps xmm8, [rsp+0x80]
00007efc33fdfbba  vmovaps xmm9, [rsp+0x90]
00007efc33fdfbc3  vmovaps xmm10, [rsp+0xA0]
00007efc33fdfbcc  vmovaps xmm11, [rsp+0xB0]
00007efc33fdfbd5  vmovaps xmm12, [rsp+0xC0]
00007efc33fdfbde  vmovaps xmm13, [rsp+0xD0]
00007efc33fdfbe7  vmovaps xmm14, [rsp+0xE0]
00007efc33fdfbf0  add rsp, 0xF0
00007efc33fdfbf7  pop r11
00007efc33fdfbf9  pop r10
00007efc33fdfbfb  pop r9
00007efc33fdfbfd  pop r8
00007efc33fdfbff  pop rsi
00007efc33fdfc00  pop rdi
00007efc33fdfc01  pop rdx
00007efc33fdfc02  pop rcx
00007efc33fdfc03  pop rax
00007efc33fdfc04  add rsp, 0x08
00007efc33fdfc08  jmp 0x00007EFC33FDC473
00007efc33fdfc0d  call 0x00007EFC33EB52F0
00007efc33fdfc12  jmp 0x00007EFC33FDC4CE
00007efc33fdfc17  sub rsp, 0x08
00007efc33fdfc1b  push rax
00007efc33fdfc1c  push rcx
00007efc33fdfc1d  push rdx
00007efc33fdfc1e  push rdi
00007efc33fdfc1f  push rsi
00007efc33fdfc20  push r8
00007efc33fdfc22  push r9
00007efc33fdfc24  push r10
00007efc33fdfc26  push r11
00007efc33fdfc28  sub rsp, 0xF0
00007efc33fdfc2f  vmovaps [rsp], xmm0
00007efc33fdfc34  vmovaps [rsp+0x10], xmm1
00007efc33fdfc3a  vmovaps [rsp+0x20], xmm2
00007efc33fdfc40  vmovaps [rsp+0x30], xmm3
00007efc33fdfc46  vmovaps [rsp+0x40], xmm4
00007efc33fdfc4c  vmovaps [rsp+0x50], xmm5
00007efc33fdfc52  vmovaps [rsp+0x60], xmm6
00007efc33fdfc58  vmovaps [rsp+0x70], xmm7
00007efc33fdfc5e  vmovaps [rsp+0x80], xmm8
00007efc33fdfc67  vmovaps [rsp+0x90], xmm10
00007efc33fdfc70  vmovaps [rsp+0xA0], xmm11
00007efc33fdfc79  vmovaps [rsp+0xB0], xmm12
00007efc33fdfc82  vmovaps [rsp+0xC0], xmm13
00007efc33fdfc8b  vmovaps [rsp+0xD0], xmm14
00007efc33fdfc94  vmovaps [rsp+0xE0], xmm15
00007efc33fdfc9d  sub rsp, 0x30
00007efc33fdfca1  movaps [rsp], xmm9
00007efc33fdfca6  movaps [rsp+0x10], xmm8
00007efc33fdfcac  movaps [rsp+0x20], xmm11
00007efc33fdfcb2  lea rdi, [rsp]
00007efc33fdfcb6  mov esi, 0x00
00007efc33fdfcbb  mov rax, 0x5D9448894530
00007efc33fdfcc5  call rax
00007efc33fdfcc7  movaps xmm9, [rsp]
00007efc33fdfccc  add rsp, 0x30
00007efc33fdfcd0  vmovaps xmm0, [rsp]
00007efc33fdfcd5  vmovaps xmm1, [rsp+0x10]
00007efc33fdfcdb  vmovaps xmm2, [rsp+0x20]
00007efc33fdfce1  vmovaps xmm3, [rsp+0x30]
00007efc33fdfce7  vmovaps xmm4, [rsp+0x40]
00007efc33fdfced  vmovaps xmm5, [rsp+0x50]
00007efc33fdfcf3  vmovaps xmm6, [rsp+0x60]
00007efc33fdfcf9  vmovaps xmm7, [rsp+0x70]
00007efc33fdfcff  vmovaps xmm8, [rsp+0x80]
00007efc33fdfd08  vmovaps xmm10, [rsp+0x90]
00007efc33fdfd11  vmovaps xmm11, [rsp+0xA0]
00007efc33fdfd1a  vmovaps xmm12, [rsp+0xB0]
00007efc33fdfd23  vmovaps xmm13, [rsp+0xC0]
00007efc33fdfd2c  vmovaps xmm14, [rsp+0xD0]
00007efc33fdfd35  vmovaps xmm15, [rsp+0xE0]
00007efc33fdfd3e  add rsp, 0xF0
00007efc33fdfd45  pop r11
00007efc33fdfd47  pop r10
00007efc33fdfd49  pop r9
00007efc33fdfd4b  pop r8
00007efc33fdfd4d  pop rsi
00007efc33fdfd4e  pop rdi
00007efc33fdfd4f  pop rdx
00007efc33fdfd50  pop rcx
00007efc33fdfd51  pop rax
00007efc33fdfd52  add rsp, 0x08
00007efc33fdfd56  jmp 0x00007EFC33FDC505
00007efc33fdfd5b  sub rsp, 0x08
00007efc33fdfd5f  push rax
00007efc33fdfd60  push rcx
00007efc33fdfd61  push rdx
00007efc33fdfd62  push rdi
00007efc33fdfd63  push rsi
00007efc33fdfd64  push r8
00007efc33fdfd66  push r9
00007efc33fdfd68  push r10
00007efc33fdfd6a  push r11
00007efc33fdfd6c  sub rsp, 0xF0
00007efc33fdfd73  vmovaps [rsp], xmm0
00007efc33fdfd78  vmovaps [rsp+0x10], xmm1
00007efc33fdfd7e  vmovaps [rsp+0x20], xmm2
00007efc33fdfd84  vmovaps [rsp+0x30], xmm3
00007efc33fdfd8a  vmovaps [rsp+0x40], xmm4
00007efc33fdfd90  vmovaps [rsp+0x50], xmm5
00007efc33fdfd96  vmovaps [rsp+0x60], xmm6
00007efc33fdfd9c  vmovaps [rsp+0x70], xmm7
00007efc33fdfda2  vmovaps [rsp+0x80], xmm8
00007efc33fdfdab  vmovaps [rsp+0x90], xmm9
00007efc33fdfdb4  vmovaps [rsp+0xA0], xmm10
00007efc33fdfdbd  vmovaps [rsp+0xB0], xmm12
00007efc33fdfdc6  vmovaps [rsp+0xC0], xmm13
00007efc33fdfdcf  vmovaps [rsp+0xD0], xmm14
00007efc33fdfdd8  vmovaps [rsp+0xE0], xmm15
00007efc33fdfde1  sub rsp, 0x30
00007efc33fdfde5  movaps [rsp], xmm11
00007efc33fdfdea  movaps [rsp+0x10], xmm10
00007efc33fdfdf0  movaps [rsp+0x20], xmm6
00007efc33fdfdf5  lea rdi, [rsp]
00007efc33fdfdf9  mov esi, 0x00
00007efc33fdfdfe  mov rax, 0x5D9448894530
00007efc33fdfe08  call rax
00007efc33fdfe0a  movaps xmm11, [rsp]
00007efc33fdfe0f  add rsp, 0x30
00007efc33fdfe13  vmovaps xmm0, [rsp]
00007efc33fdfe18  vmovaps xmm1, [rsp+0x10]
00007efc33fdfe1e  vmovaps xmm2, [rsp+0x20]
00007efc33fdfe24  vmovaps xmm3, [rsp+0x30]
00007efc33fdfe2a  vmovaps xmm4, [rsp+0x40]
00007efc33fdfe30  vmovaps xmm5, [rsp+0x50]
00007efc33fdfe36  vmovaps xmm6, [rsp+0x60]
00007efc33fdfe3c  vmovaps xmm7, [rsp+0x70]
00007efc33fdfe42  vmovaps xmm8, [rsp+0x80]
00007efc33fdfe4b  vmovaps xmm9, [rsp+0x90]
00007efc33fdfe54  vmovaps xmm10, [rsp+0xA0]
00007efc33fdfe5d  vmovaps xmm12, [rsp+0xB0]
00007efc33fdfe66  vmovaps xmm13, [rsp+0xC0]
00007efc33fdfe6f  vmovaps xmm14, [rsp+0xD0]
00007efc33fdfe78  vmovaps xmm15, [rsp+0xE0]
00007efc33fdfe81  add rsp, 0xF0
00007efc33fdfe88  pop r11
00007efc33fdfe8a  pop r10
00007efc33fdfe8c  pop r9
00007efc33fdfe8e  pop r8
00007efc33fdfe90  pop rsi
00007efc33fdfe91  pop rdi
00007efc33fdfe92  pop rdx
00007efc33fdfe93  pop rcx
00007efc33fdfe94  pop rax
00007efc33fdfe95  add rsp, 0x08
00007efc33fdfe99  jmp 0x00007EFC33FDC520
00007efc33fdfe9e  sub rsp, 0x08
00007efc33fdfea2  push rax
00007efc33fdfea3  push rcx
00007efc33fdfea4  push rdx
00007efc33fdfea5  push rdi
00007efc33fdfea6  push rsi
00007efc33fdfea7  push r8
00007efc33fdfea9  push r9
00007efc33fdfeab  push r10
00007efc33fdfead  push r11
00007efc33fdfeaf  sub rsp, 0xF0
00007efc33fdfeb6  vmovaps [rsp], xmm0
00007efc33fdfebb  vmovaps [rsp+0x10], xmm1
00007efc33fdfec1  vmovaps [rsp+0x20], xmm2
00007efc33fdfec7  vmovaps [rsp+0x30], xmm3
00007efc33fdfecd  vmovaps [rsp+0x40], xmm4
00007efc33fdfed3  vmovaps [rsp+0x50], xmm5
00007efc33fdfed9  vmovaps [rsp+0x60], xmm6
00007efc33fdfedf  vmovaps [rsp+0x70], xmm7
00007efc33fdfee5  vmovaps [rsp+0x80], xmm8
00007efc33fdfeee  vmovaps [rsp+0x90], xmm9
00007efc33fdfef7  vmovaps [rsp+0xA0], xmm11
00007efc33fdff00  vmovaps [rsp+0xB0], xmm12
00007efc33fdff09  vmovaps [rsp+0xC0], xmm13
00007efc33fdff12  vmovaps [rsp+0xD0], xmm14
00007efc33fdff1b  vmovaps [rsp+0xE0], xmm15
00007efc33fdff24  sub rsp, 0x30
00007efc33fdff28  movaps [rsp], xmm10
00007efc33fdff2d  movaps [rsp+0x10], xmm14
00007efc33fdff33  movaps [rsp+0x20], xmm4
00007efc33fdff38  lea rdi, [rsp]
00007efc33fdff3c  mov esi, 0x00
00007efc33fdff41  mov rax, 0x5D9448894530
00007efc33fdff4b  call rax
00007efc33fdff4d  movaps xmm10, [rsp]
00007efc33fdff52  add rsp, 0x30
00007efc33fdff56  vmovaps xmm0, [rsp]
00007efc33fdff5b  vmovaps xmm1, [rsp+0x10]
00007efc33fdff61  vmovaps xmm2, [rsp+0x20]
00007efc33fdff67  vmovaps xmm3, [rsp+0x30]
00007efc33fdff6d  vmovaps xmm4, [rsp+0x40]
00007efc33fdff73  vmovaps xmm5, [rsp+0x50]
00007efc33fdff79  vmovaps xmm6, [rsp+0x60]
00007efc33fdff7f  vmovaps xmm7, [rsp+0x70]
00007efc33fdff85  vmovaps xmm8, [rsp+0x80]
00007efc33fdff8e  vmovaps xmm9, [rsp+0x90]
00007efc33fdff97  vmovaps xmm11, [rsp+0xA0]
00007efc33fdffa0  vmovaps xmm12, [rsp+0xB0]
00007efc33fdffa9  vmovaps xmm13, [rsp+0xC0]
00007efc33fdffb2  vmovaps xmm14, [rsp+0xD0]
00007efc33fdffbb  vmovaps xmm15, [rsp+0xE0]
00007efc33fdffc4  add rsp, 0xF0
00007efc33fdffcb  pop r11
00007efc33fdffcd  pop r10
00007efc33fdffcf  pop r9
00007efc33fdffd1  pop r8
00007efc33fdffd3  pop rsi
00007efc33fdffd4  pop rdi
00007efc33fdffd5  pop rdx
00007efc33fdffd6  pop rcx
00007efc33fdffd7  pop rax
00007efc33fdffd8  add rsp, 0x08
00007efc33fdffdc  jmp 0x00007EFC33FDC53B
00007efc33fdffe1  sub rsp, 0x08
00007efc33fdffe5  push rax
00007efc33fdffe6  push rcx
00007efc33fdffe7  push rdx
00007efc33fdffe8  push rdi
00007efc33fdffe9  push rsi
00007efc33fdffea  push r8
00007efc33fdffec  push r9
00007efc33fdffee  push r10
00007efc33fdfff0  push r11
00007efc33fdfff2  sub rsp, 0xF0
00007efc33fdfff9  vmovaps [rsp], xmm0
00007efc33fdfffe  vmovaps [rsp+0x10], xmm1
00007efc33fe0004  vmovaps [rsp+0x20], xmm2
00007efc33fe000a  vmovaps [rsp+0x30], xmm3
00007efc33fe0010  vmovaps [rsp+0x40], xmm4
00007efc33fe0016  vmovaps [rsp+0x50], xmm5
00007efc33fe001c  vmovaps [rsp+0x60], xmm6
00007efc33fe0022  vmovaps [rsp+0x70], xmm7
00007efc33fe0028  vmovaps [rsp+0x80], xmm9
00007efc33fe0031  vmovaps [rsp+0x90], xmm10
00007efc33fe003a  vmovaps [rsp+0xA0], xmm11
00007efc33fe0043  vmovaps [rsp+0xB0], xmm12
00007efc33fe004c  vmovaps [rsp+0xC0], xmm13
00007efc33fe0055  vmovaps [rsp+0xD0], xmm14
00007efc33fe005e  vmovaps [rsp+0xE0], xmm15
00007efc33fe0067  sub rsp, 0x30
00007efc33fe006b  movaps [rsp], xmm8
00007efc33fe0070  movaps [rsp+0x10], xmm1
00007efc33fe0075  movaps [rsp+0x20], xmm14
00007efc33fe007b  lea rdi, [rsp]
00007efc33fe007f  mov esi, 0x00
00007efc33fe0084  mov rax, 0x5D9448894530
00007efc33fe008e  call rax
00007efc33fe0090  movaps xmm8, [rsp]
00007efc33fe0095  add rsp, 0x30
00007efc33fe0099  vmovaps xmm0, [rsp]
00007efc33fe009e  vmovaps xmm1, [rsp+0x10]
00007efc33fe00a4  vmovaps xmm2, [rsp+0x20]
00007efc33fe00aa  vmovaps xmm3, [rsp+0x30]
00007efc33fe00b0  vmovaps xmm4, [rsp+0x40]
00007efc33fe00b6  vmovaps xmm5, [rsp+0x50]
00007efc33fe00bc  vmovaps xmm6, [rsp+0x60]
00007efc33fe00c2  vmovaps xmm7, [rsp+0x70]
00007efc33fe00c8  vmovaps xmm9, [rsp+0x80]
00007efc33fe00d1  vmovaps xmm10, [rsp+0x90]
00007efc33fe00da  vmovaps xmm11, [rsp+0xA0]
00007efc33fe00e3  vmovaps xmm12, [rsp+0xB0]
00007efc33fe00ec  vmovaps xmm13, [rsp+0xC0]
00007efc33fe00f5  vmovaps xmm14, [rsp+0xD0]
00007efc33fe00fe  vmovaps xmm15, [rsp+0xE0]
00007efc33fe0107  add rsp, 0xF0
00007efc33fe010e  pop r11
00007efc33fe0110  pop r10
00007efc33fe0112  pop r9
00007efc33fe0114  pop r8
00007efc33fe0116  pop rsi
00007efc33fe0117  pop rdi
00007efc33fe0118  pop rdx
00007efc33fe0119  pop rcx
00007efc33fe011a  pop rax
00007efc33fe011b  add rsp, 0x08
00007efc33fe011f  jmp 0x00007EFC33FDC561
00007efc33fe0124  sub rsp, 0x08
00007efc33fe0128  push rax
00007efc33fe0129  push rcx
00007efc33fe012a  push rdx
00007efc33fe012b  push rdi
00007efc33fe012c  push rsi
00007efc33fe012d  push r8
00007efc33fe012f  push r9
00007efc33fe0131  push r10
00007efc33fe0133  push r11
00007efc33fe0135  sub rsp, 0xF0
00007efc33fe013c  vmovaps [rsp], xmm0
00007efc33fe0141  vmovaps [rsp+0x10], xmm1
00007efc33fe0147  vmovaps [rsp+0x20], xmm2
00007efc33fe014d  vmovaps [rsp+0x30], xmm3
00007efc33fe0153  vmovaps [rsp+0x40], xmm4
00007efc33fe0159  vmovaps [rsp+0x50], xmm5
00007efc33fe015f  vmovaps [rsp+0x60], xmm7
00007efc33fe0165  vmovaps [rsp+0x70], xmm8
00007efc33fe016b  vmovaps [rsp+0x80], xmm9
00007efc33fe0174  vmovaps [rsp+0x90], xmm10
00007efc33fe017d  vmovaps [rsp+0xA0], xmm11
00007efc33fe0186  vmovaps [rsp+0xB0], xmm12
00007efc33fe018f  vmovaps [rsp+0xC0], xmm13
00007efc33fe0198  vmovaps [rsp+0xD0], xmm14
00007efc33fe01a1  vmovaps [rsp+0xE0], xmm15
00007efc33fe01aa  sub rsp, 0x30
00007efc33fe01ae  movaps [rsp], xmm6
00007efc33fe01b2  movaps [rsp+0x10], xmm1
00007efc33fe01b7  movaps [rsp+0x20], xmm14
00007efc33fe01bd  lea rdi, [rsp]
00007efc33fe01c1  mov esi, 0x00
00007efc33fe01c6  mov rax, 0x5D9448894530
00007efc33fe01d0  call rax
00007efc33fe01d2  movaps xmm6, [rsp]
00007efc33fe01d6  add rsp, 0x30
00007efc33fe01da  vmovaps xmm0, [rsp]
00007efc33fe01df  vmovaps xmm1, [rsp+0x10]
00007efc33fe01e5  vmovaps xmm2, [rsp+0x20]
00007efc33fe01eb  vmovaps xmm3, [rsp+0x30]
00007efc33fe01f1  vmovaps xmm4, [rsp+0x40]
00007efc33fe01f7  vmovaps xmm5, [rsp+0x50]
00007efc33fe01fd  vmovaps xmm7, [rsp+0x60]
00007efc33fe0203  vmovaps xmm8, [rsp+0x70]
00007efc33fe0209  vmovaps xmm9, [rsp+0x80]
00007efc33fe0212  vmovaps xmm10, [rsp+0x90]
00007efc33fe021b  vmovaps xmm11, [rsp+0xA0]
00007efc33fe0224  vmovaps xmm12, [rsp+0xB0]
00007efc33fe022d  vmovaps xmm13, [rsp+0xC0]
00007efc33fe0236  vmovaps xmm14, [rsp+0xD0]
00007efc33fe023f  vmovaps xmm15, [rsp+0xE0]
00007efc33fe0248  add rsp, 0xF0
00007efc33fe024f  pop r11
00007efc33fe0251  pop r10
00007efc33fe0253  pop r9
00007efc33fe0255  pop r8
00007efc33fe0257  pop rsi
00007efc33fe0258  pop rdi
00007efc33fe0259  pop rdx
00007efc33fe025a  pop rcx
00007efc33fe025b  pop rax
00007efc33fe025c  add rsp, 0x08
00007efc33fe0260  jmp 0x00007EFC33FDC58D
00007efc33fe0265  sub rsp, 0x08
00007efc33fe0269  push rax
00007efc33fe026a  push rcx
00007efc33fe026b  push rdx
00007efc33fe026c  push rdi
00007efc33fe026d  push rsi
00007efc33fe026e  push r8
00007efc33fe0270  push r9
00007efc33fe0272  push r10
00007efc33fe0274  push r11
00007efc33fe0276  sub rsp, 0xF0
00007efc33fe027d  vmovaps [rsp], xmm0
00007efc33fe0282  vmovaps [rsp+0x10], xmm1
00007efc33fe0288  vmovaps [rsp+0x20], xmm2
00007efc33fe028e  vmovaps [rsp+0x30], xmm3
00007efc33fe0294  vmovaps [rsp+0x40], xmm4
00007efc33fe029a  vmovaps [rsp+0x50], xmm5
00007efc33fe02a0  vmovaps [rsp+0x60], xmm6
00007efc33fe02a6  vmovaps [rsp+0x70], xmm7
00007efc33fe02ac  vmovaps [rsp+0x80], xmm8
00007efc33fe02b5  vmovaps [rsp+0x90], xmm9
00007efc33fe02be  vmovaps [rsp+0xA0], xmm10
00007efc33fe02c7  vmovaps [rsp+0xB0], xmm11
00007efc33fe02d0  vmovaps [rsp+0xC0], xmm12
00007efc33fe02d9  vmovaps [rsp+0xD0], xmm13
00007efc33fe02e2  vmovaps [rsp+0xE0], xmm15
00007efc33fe02eb  sub rsp, 0x30
00007efc33fe02ef  movaps [rsp], xmm14
00007efc33fe02f4  movaps [rsp+0x10], xmm12
00007efc33fe02fa  movaps [rsp+0x20], xmm1
00007efc33fe02ff  lea rdi, [rsp]
00007efc33fe0303  mov esi, 0x00
00007efc33fe0308  mov rax, 0x5D9448894530
00007efc33fe0312  call rax
00007efc33fe0314  movaps xmm14, [rsp]
00007efc33fe0319  add rsp, 0x30
00007efc33fe031d  vmovaps xmm0, [rsp]
00007efc33fe0322  vmovaps xmm1, [rsp+0x10]
00007efc33fe0328  vmovaps xmm2, [rsp+0x20]
00007efc33fe032e  vmovaps xmm3, [rsp+0x30]
00007efc33fe0334  vmovaps xmm4, [rsp+0x40]
00007efc33fe033a  vmovaps xmm5, [rsp+0x50]
00007efc33fe0340  vmovaps xmm6, [rsp+0x60]
00007efc33fe0346  vmovaps xmm7, [rsp+0x70]
00007efc33fe034c  vmovaps xmm8, [rsp+0x80]
00007efc33fe0355  vmovaps xmm9, [rsp+0x90]
00007efc33fe035e  vmovaps xmm10, [rsp+0xA0]
00007efc33fe0367  vmovaps xmm11, [rsp+0xB0]
00007efc33fe0370  vmovaps xmm12, [rsp+0xC0]
00007efc33fe0379  vmovaps xmm13, [rsp+0xD0]
00007efc33fe0382  vmovaps xmm15, [rsp+0xE0]
00007efc33fe038b  add rsp, 0xF0
00007efc33fe0392  pop r11
00007efc33fe0394  pop r10
00007efc33fe0396  pop r9
00007efc33fe0398  pop r8
00007efc33fe039a  pop rsi
00007efc33fe039b  pop rdi
00007efc33fe039c  pop rdx
00007efc33fe039d  pop rcx
00007efc33fe039e  pop rax
00007efc33fe039f  add rsp, 0x08
00007efc33fe03a3  jmp 0x00007EFC33FDC5B3
00007efc33fe03a8  sub rsp, 0x08
00007efc33fe03ac  push rax
00007efc33fe03ad  push rcx
00007efc33fe03ae  push rdx
00007efc33fe03af  push rdi
00007efc33fe03b0  push rsi
00007efc33fe03b1  push r8
00007efc33fe03b3  push r9
00007efc33fe03b5  push r10
00007efc33fe03b7  push r11
00007efc33fe03b9  sub rsp, 0xF0
00007efc33fe03c0  vmovaps [rsp], xmm0
00007efc33fe03c5  vmovaps [rsp+0x10], xmm2
00007efc33fe03cb  vmovaps [rsp+0x20], xmm3
00007efc33fe03d1  vmovaps [rsp+0x30], xmm4
00007efc33fe03d7  vmovaps [rsp+0x40], xmm5
00007efc33fe03dd  vmovaps [rsp+0x50], xmm6
00007efc33fe03e3  vmovaps [rsp+0x60], xmm7
00007efc33fe03e9  vmovaps [rsp+0x70], xmm8
00007efc33fe03ef  vmovaps [rsp+0x80], xmm9
00007efc33fe03f8  vmovaps [rsp+0x90], xmm10
00007efc33fe0401  vmovaps [rsp+0xA0], xmm11
00007efc33fe040a  vmovaps [rsp+0xB0], xmm12
00007efc33fe0413  vmovaps [rsp+0xC0], xmm13
00007efc33fe041c  vmovaps [rsp+0xD0], xmm14
00007efc33fe0425  vmovaps [rsp+0xE0], xmm15
00007efc33fe042e  sub rsp, 0x30
00007efc33fe0432  movaps [rsp], xmm1
00007efc33fe0436  movaps [rsp+0x10], xmm13
00007efc33fe043c  movaps [rsp+0x20], xmm9
00007efc33fe0442  lea rdi, [rsp]
00007efc33fe0446  mov esi, 0x00
00007efc33fe044b  mov rax, 0x5D9448894530
00007efc33fe0455  call rax
00007efc33fe0457  movaps xmm1, [rsp]
00007efc33fe045b  add rsp, 0x30
00007efc33fe045f  vmovaps xmm0, [rsp]
00007efc33fe0464  vmovaps xmm2, [rsp+0x10]
00007efc33fe046a  vmovaps xmm3, [rsp+0x20]
00007efc33fe0470  vmovaps xmm4, [rsp+0x30]
00007efc33fe0476  vmovaps xmm5, [rsp+0x40]
00007efc33fe047c  vmovaps xmm6, [rsp+0x50]
00007efc33fe0482  vmovaps xmm7, [rsp+0x60]
00007efc33fe0488  vmovaps xmm8, [rsp+0x70]
00007efc33fe048e  vmovaps xmm9, [rsp+0x80]
00007efc33fe0497  vmovaps xmm10, [rsp+0x90]
00007efc33fe04a0  vmovaps xmm11, [rsp+0xA0]
00007efc33fe04a9  vmovaps xmm12, [rsp+0xB0]
00007efc33fe04b2  vmovaps xmm13, [rsp+0xC0]
00007efc33fe04bb  vmovaps xmm14, [rsp+0xD0]
00007efc33fe04c4  vmovaps xmm15, [rsp+0xE0]
00007efc33fe04cd  add rsp, 0xF0
00007efc33fe04d4  pop r11
00007efc33fe04d6  pop r10
00007efc33fe04d8  pop r9
00007efc33fe04da  pop r8
00007efc33fe04dc  pop rsi
00007efc33fe04dd  pop rdi
00007efc33fe04de  pop rdx
00007efc33fe04df  pop rcx
00007efc33fe04e0  pop rax
00007efc33fe04e1  add rsp, 0x08
00007efc33fe04e5  jmp 0x00007EFC33FDC5CD
00007efc33fe04ea  sub rsp, 0x08
00007efc33fe04ee  push rax
00007efc33fe04ef  push rcx
00007efc33fe04f0  push rdx
00007efc33fe04f1  push rdi
00007efc33fe04f2  push rsi
00007efc33fe04f3  push r8
00007efc33fe04f5  push r9
00007efc33fe04f7  push r10
00007efc33fe04f9  push r11
00007efc33fe04fb  sub rsp, 0xF0
00007efc33fe0502  vmovaps [rsp], xmm0
00007efc33fe0507  vmovaps [rsp+0x10], xmm1
00007efc33fe050d  vmovaps [rsp+0x20], xmm2
00007efc33fe0513  vmovaps [rsp+0x30], xmm3
00007efc33fe0519  vmovaps [rsp+0x40], xmm4
00007efc33fe051f  vmovaps [rsp+0x50], xmm5
00007efc33fe0525  vmovaps [rsp+0x60], xmm6
00007efc33fe052b  vmovaps [rsp+0x70], xmm7
00007efc33fe0531  vmovaps [rsp+0x80], xmm8
00007efc33fe053a  vmovaps [rsp+0x90], xmm9
00007efc33fe0543  vmovaps [rsp+0xA0], xmm10
00007efc33fe054c  vmovaps [rsp+0xB0], xmm11
00007efc33fe0555  vmovaps [rsp+0xC0], xmm13
00007efc33fe055e  vmovaps [rsp+0xD0], xmm14
00007efc33fe0567  vmovaps [rsp+0xE0], xmm15
00007efc33fe0570  sub rsp, 0x30
00007efc33fe0574  movaps [rsp], xmm12
00007efc33fe0579  movaps [rsp+0x10], xmm7
00007efc33fe057e  movaps [rsp+0x20], xmm13
00007efc33fe0584  lea rdi, [rsp]
00007efc33fe0588  mov esi, 0x00
00007efc33fe058d  mov rax, 0x5D9448894530
00007efc33fe0597  call rax
00007efc33fe0599  movaps xmm12, [rsp]
00007efc33fe059e  add rsp, 0x30
00007efc33fe05a2  vmovaps xmm0, [rsp]
00007efc33fe05a7  vmovaps xmm1, [rsp+0x10]
00007efc33fe05ad  vmovaps xmm2, [rsp+0x20]
00007efc33fe05b3  vmovaps xmm3, [rsp+0x30]
00007efc33fe05b9  vmovaps xmm4, [rsp+0x40]
00007efc33fe05bf  vmovaps xmm5, [rsp+0x50]
00007efc33fe05c5  vmovaps xmm6, [rsp+0x60]
00007efc33fe05cb  vmovaps xmm7, [rsp+0x70]
00007efc33fe05d1  vmovaps xmm8, [rsp+0x80]
00007efc33fe05da  vmovaps xmm9, [rsp+0x90]
00007efc33fe05e3  vmovaps xmm10, [rsp+0xA0]
00007efc33fe05ec  vmovaps xmm11, [rsp+0xB0]
00007efc33fe05f5  vmovaps xmm13, [rsp+0xC0]
00007efc33fe05fe  vmovaps xmm14, [rsp+0xD0]
00007efc33fe0607  vmovaps xmm15, [rsp+0xE0]
00007efc33fe0610  add rsp, 0xF0
00007efc33fe0617  pop r11
00007efc33fe0619  pop r10
00007efc33fe061b  pop r9
00007efc33fe061d  pop r8
00007efc33fe061f  pop rsi
00007efc33fe0620  pop rdi
00007efc33fe0621  pop rdx
00007efc33fe0622  pop rcx
00007efc33fe0623  pop rax
00007efc33fe0624  add rsp, 0x08
00007efc33fe0628  jmp 0x00007EFC33FDC5F4
00007efc33fe062d  sub rsp, 0x08
00007efc33fe0631  push rax
00007efc33fe0632  push rcx
00007efc33fe0633  push rdx
00007efc33fe0634  push rdi
00007efc33fe0635  push rsi
00007efc33fe0636  push r8
00007efc33fe0638  push r9
00007efc33fe063a  push r10
00007efc33fe063c  push r11
00007efc33fe063e  sub rsp, 0xF0
00007efc33fe0645  vmovaps [rsp], xmm0
00007efc33fe064a  vmovaps [rsp+0x10], xmm1
00007efc33fe0650  vmovaps [rsp+0x20], xmm2
00007efc33fe0656  vmovaps [rsp+0x30], xmm3
00007efc33fe065c  vmovaps [rsp+0x40], xmm4
00007efc33fe0662  vmovaps [rsp+0x50], xmm5
00007efc33fe0668  vmovaps [rsp+0x60], xmm6
00007efc33fe066e  vmovaps [rsp+0x70], xmm7
00007efc33fe0674  vmovaps [rsp+0x80], xmm8
00007efc33fe067d  vmovaps [rsp+0x90], xmm9
00007efc33fe0686  vmovaps [rsp+0xA0], xmm10
00007efc33fe068f  vmovaps [rsp+0xB0], xmm11
00007efc33fe0698  vmovaps [rsp+0xC0], xmm12
00007efc33fe06a1  vmovaps [rsp+0xD0], xmm14
00007efc33fe06aa  vmovaps [rsp+0xE0], xmm15
00007efc33fe06b3  sub rsp, 0x30
00007efc33fe06b7  movaps [rsp], xmm13
00007efc33fe06bc  movaps [rsp+0x10], xmm15
00007efc33fe06c2  movaps [rsp+0x20], xmm8
00007efc33fe06c8  lea rdi, [rsp]
00007efc33fe06cc  mov esi, 0x00
00007efc33fe06d1  mov rax, 0x5D9448894530
00007efc33fe06db  call rax
00007efc33fe06dd  movaps xmm13, [rsp]
00007efc33fe06e2  add rsp, 0x30
00007efc33fe06e6  vmovaps xmm0, [rsp]
00007efc33fe06eb  vmovaps xmm1, [rsp+0x10]
00007efc33fe06f1  vmovaps xmm2, [rsp+0x20]
00007efc33fe06f7  vmovaps xmm3, [rsp+0x30]
00007efc33fe06fd  vmovaps xmm4, [rsp+0x40]
00007efc33fe0703  vmovaps xmm5, [rsp+0x50]
00007efc33fe0709  vmovaps xmm6, [rsp+0x60]
00007efc33fe070f  vmovaps xmm7, [rsp+0x70]
00007efc33fe0715  vmovaps xmm8, [rsp+0x80]
00007efc33fe071e  vmovaps xmm9, [rsp+0x90]
00007efc33fe0727  vmovaps xmm10, [rsp+0xA0]
00007efc33fe0730  vmovaps xmm11, [rsp+0xB0]
00007efc33fe0739  vmovaps xmm12, [rsp+0xC0]
00007efc33fe0742  vmovaps xmm14, [rsp+0xD0]
00007efc33fe074b  vmovaps xmm15, [rsp+0xE0]
00007efc33fe0754  add rsp, 0xF0
00007efc33fe075b  pop r11
00007efc33fe075d  pop r10
00007efc33fe075f  pop r9
00007efc33fe0761  pop r8
00007efc33fe0763  pop rsi
00007efc33fe0764  pop rdi
00007efc33fe0765  pop rdx
00007efc33fe0766  pop rcx
00007efc33fe0767  pop rax
00007efc33fe0768  add rsp, 0x08
00007efc33fe076c  jmp 0x00007EFC33FDC60F
00007efc33fe0771  sub rsp, 0x08
00007efc33fe0775  push rax
00007efc33fe0776  push rcx
00007efc33fe0777  push rdx
00007efc33fe0778  push rdi
00007efc33fe0779  push rsi
00007efc33fe077a  push r8
00007efc33fe077c  push r9
00007efc33fe077e  push r10
00007efc33fe0780  push r11
00007efc33fe0782  sub rsp, 0xF0
00007efc33fe0789  vmovaps [rsp], xmm0
00007efc33fe078e  vmovaps [rsp+0x10], xmm1
00007efc33fe0794  vmovaps [rsp+0x20], xmm2
00007efc33fe079a  vmovaps [rsp+0x30], xmm3
00007efc33fe07a0  vmovaps [rsp+0x40], xmm4
00007efc33fe07a6  vmovaps [rsp+0x50], xmm5
00007efc33fe07ac  vmovaps [rsp+0x60], xmm6
00007efc33fe07b2  vmovaps [rsp+0x70], xmm7
00007efc33fe07b8  vmovaps [rsp+0x80], xmm9
00007efc33fe07c1  vmovaps [rsp+0x90], xmm10
00007efc33fe07ca  vmovaps [rsp+0xA0], xmm11
00007efc33fe07d3  vmovaps [rsp+0xB0], xmm12
00007efc33fe07dc  vmovaps [rsp+0xC0], xmm13
00007efc33fe07e5  vmovaps [rsp+0xD0], xmm14
00007efc33fe07ee  vmovaps [rsp+0xE0], xmm15
00007efc33fe07f7  sub rsp, 0x30
00007efc33fe07fb  movaps [rsp], xmm8
00007efc33fe0800  movaps [rsp+0x10], xmm15
00007efc33fe0806  movaps [rsp+0x20], xmm9
00007efc33fe080c  lea rdi, [rsp]
00007efc33fe0810  mov esi, 0x00
00007efc33fe0815  mov rax, 0x5D9448894530
00007efc33fe081f  call rax
00007efc33fe0821  movaps xmm8, [rsp]
00007efc33fe0826  add rsp, 0x30
00007efc33fe082a  vmovaps xmm0, [rsp]
00007efc33fe082f  vmovaps xmm1, [rsp+0x10]
00007efc33fe0835  vmovaps xmm2, [rsp+0x20]
00007efc33fe083b  vmovaps xmm3, [rsp+0x30]
00007efc33fe0841  vmovaps xmm4, [rsp+0x40]
00007efc33fe0847  vmovaps xmm5, [rsp+0x50]
00007efc33fe084d  vmovaps xmm6, [rsp+0x60]
00007efc33fe0853  vmovaps xmm7, [rsp+0x70]
00007efc33fe0859  vmovaps xmm9, [rsp+0x80]
00007efc33fe0862  vmovaps xmm10, [rsp+0x90]
00007efc33fe086b  vmovaps xmm11, [rsp+0xA0]
00007efc33fe0874  vmovaps xmm12, [rsp+0xB0]
00007efc33fe087d  vmovaps xmm13, [rsp+0xC0]
00007efc33fe0886  vmovaps xmm14, [rsp+0xD0]
00007efc33fe088f  vmovaps xmm15, [rsp+0xE0]
00007efc33fe0898  add rsp, 0xF0
00007efc33fe089f  pop r11
00007efc33fe08a1  pop r10
00007efc33fe08a3  pop r9
00007efc33fe08a5  pop r8
00007efc33fe08a7  pop rsi
00007efc33fe08a8  pop rdi
00007efc33fe08a9  pop rdx
00007efc33fe08aa  pop rcx
00007efc33fe08ab  pop rax
00007efc33fe08ac  add rsp, 0x08
00007efc33fe08b0  jmp 0x00007EFC33FDC63D
00007efc33fe08b5  sub rsp, 0x08
00007efc33fe08b9  push rax
00007efc33fe08ba  push rcx
00007efc33fe08bb  push rdx
00007efc33fe08bc  push rdi
00007efc33fe08bd  push rsi
00007efc33fe08be  push r8
00007efc33fe08c0  push r9
00007efc33fe08c2  push r10
00007efc33fe08c4  push r11
00007efc33fe08c6  sub rsp, 0xF0
00007efc33fe08cd  vmovaps [rsp], xmm0
00007efc33fe08d2  vmovaps [rsp+0x10], xmm1
00007efc33fe08d8  vmovaps [rsp+0x20], xmm2
00007efc33fe08de  vmovaps [rsp+0x30], xmm3
00007efc33fe08e4  vmovaps [rsp+0x40], xmm4
00007efc33fe08ea  vmovaps [rsp+0x50], xmm5
00007efc33fe08f0  vmovaps [rsp+0x60], xmm6
00007efc33fe08f6  vmovaps [rsp+0x70], xmm7
00007efc33fe08fc  vmovaps [rsp+0x80], xmm8
00007efc33fe0905  vmovaps [rsp+0x90], xmm9
00007efc33fe090e  vmovaps [rsp+0xA0], xmm10
00007efc33fe0917  vmovaps [rsp+0xB0], xmm11
00007efc33fe0920  vmovaps [rsp+0xC0], xmm12
00007efc33fe0929  vmovaps [rsp+0xD0], xmm13
00007efc33fe0932  vmovaps [rsp+0xE0], xmm14
00007efc33fe093b  sub rsp, 0x30
00007efc33fe093f  movaps [rsp], xmm15
00007efc33fe0944  movaps [rsp+0x10], xmm11
00007efc33fe094a  movaps [rsp+0x20], xmm6
00007efc33fe094f  lea rdi, [rsp]
00007efc33fe0953  mov esi, 0x00
00007efc33fe0958  mov rax, 0x5D9448894530
00007efc33fe0962  call rax
00007efc33fe0964  movaps xmm15, [rsp]
00007efc33fe0969  add rsp, 0x30
00007efc33fe096d  vmovaps xmm0, [rsp]
00007efc33fe0972  vmovaps xmm1, [rsp+0x10]
00007efc33fe0978  vmovaps xmm2, [rsp+0x20]
00007efc33fe097e  vmovaps xmm3, [rsp+0x30]
00007efc33fe0984  vmovaps xmm4, [rsp+0x40]
00007efc33fe098a  vmovaps xmm5, [rsp+0x50]
00007efc33fe0990  vmovaps xmm6, [rsp+0x60]
00007efc33fe0996  vmovaps xmm7, [rsp+0x70]
00007efc33fe099c  vmovaps xmm8, [rsp+0x80]
00007efc33fe09a5  vmovaps xmm9, [rsp+0x90]
00007efc33fe09ae  vmovaps xmm10, [rsp+0xA0]
00007efc33fe09b7  vmovaps xmm11, [rsp+0xB0]
00007efc33fe09c0  vmovaps xmm12, [rsp+0xC0]
00007efc33fe09c9  vmovaps xmm13, [rsp+0xD0]
00007efc33fe09d2  vmovaps xmm14, [rsp+0xE0]
00007efc33fe09db  add rsp, 0xF0
00007efc33fe09e2  pop r11
00007efc33fe09e4  pop r10
00007efc33fe09e6  pop r9
00007efc33fe09e8  pop r8
00007efc33fe09ea  pop rsi
00007efc33fe09eb  pop rdi
00007efc33fe09ec  pop rdx
00007efc33fe09ed  pop rcx
00007efc33fe09ee  pop rax
00007efc33fe09ef  add rsp, 0x08
00007efc33fe09f3  jmp 0x00007EFC33FDC658
00007efc33fe09f8  sub rsp, 0x08
00007efc33fe09fc  push rax
00007efc33fe09fd  push rcx
00007efc33fe09fe  push rdx
00007efc33fe09ff  push rdi
00007efc33fe0a00  push rsi
00007efc33fe0a01  push r8
00007efc33fe0a03  push r9
00007efc33fe0a05  push r10
00007efc33fe0a07  push r11
00007efc33fe0a09  sub rsp, 0xF0
00007efc33fe0a10  vmovaps [rsp], xmm0
00007efc33fe0a15  vmovaps [rsp+0x10], xmm1
00007efc33fe0a1b  vmovaps [rsp+0x20], xmm2
00007efc33fe0a21  vmovaps [rsp+0x30], xmm3
00007efc33fe0a27  vmovaps [rsp+0x40], xmm4
00007efc33fe0a2d  vmovaps [rsp+0x50], xmm5
00007efc33fe0a33  vmovaps [rsp+0x60], xmm6
00007efc33fe0a39  vmovaps [rsp+0x70], xmm8
00007efc33fe0a3f  vmovaps [rsp+0x80], xmm9
00007efc33fe0a48  vmovaps [rsp+0x90], xmm10
00007efc33fe0a51  vmovaps [rsp+0xA0], xmm11
00007efc33fe0a5a  vmovaps [rsp+0xB0], xmm12
00007efc33fe0a63  vmovaps [rsp+0xC0], xmm13
00007efc33fe0a6c  vmovaps [rsp+0xD0], xmm14
00007efc33fe0a75  vmovaps [rsp+0xE0], xmm15
00007efc33fe0a7e  sub rsp, 0x30
00007efc33fe0a82  movaps [rsp], xmm7
00007efc33fe0a86  movaps [rsp+0x10], xmm11
00007efc33fe0a8c  movaps [rsp+0x20], xmm9
00007efc33fe0a92  lea rdi, [rsp]
00007efc33fe0a96  mov esi, 0x00
00007efc33fe0a9b  mov rax, 0x5D9448894530
00007efc33fe0aa5  call rax
00007efc33fe0aa7  movaps xmm7, [rsp]
00007efc33fe0aab  add rsp, 0x30
00007efc33fe0aaf  vmovaps xmm0, [rsp]
00007efc33fe0ab4  vmovaps xmm1, [rsp+0x10]
00007efc33fe0aba  vmovaps xmm2, [rsp+0x20]
00007efc33fe0ac0  vmovaps xmm3, [rsp+0x30]
00007efc33fe0ac6  vmovaps xmm4, [rsp+0x40]
00007efc33fe0acc  vmovaps xmm5, [rsp+0x50]
00007efc33fe0ad2  vmovaps xmm6, [rsp+0x60]
00007efc33fe0ad8  vmovaps xmm8, [rsp+0x70]
00007efc33fe0ade  vmovaps xmm9, [rsp+0x80]
00007efc33fe0ae7  vmovaps xmm10, [rsp+0x90]
00007efc33fe0af0  vmovaps xmm11, [rsp+0xA0]
00007efc33fe0af9  vmovaps xmm12, [rsp+0xB0]
00007efc33fe0b02  vmovaps xmm13, [rsp+0xC0]
00007efc33fe0b0b  vmovaps xmm14, [rsp+0xD0]
00007efc33fe0b14  vmovaps xmm15, [rsp+0xE0]
00007efc33fe0b1d  add rsp, 0xF0
00007efc33fe0b24  pop r11
00007efc33fe0b26  pop r10
00007efc33fe0b28  pop r9
00007efc33fe0b2a  pop r8
00007efc33fe0b2c  pop rsi
00007efc33fe0b2d  pop rdi
00007efc33fe0b2e  pop rdx
00007efc33fe0b2f  pop rcx
00007efc33fe0b30  pop rax
00007efc33fe0b31  add rsp, 0x08
00007efc33fe0b35  jmp 0x00007EFC33FDC685
00007efc33fe0b3a  sub rsp, 0x08
00007efc33fe0b3e  push rax
00007efc33fe0b3f  push rcx
00007efc33fe0b40  push rdx
00007efc33fe0b41  push rdi
00007efc33fe0b42  push rsi
00007efc33fe0b43  push r8
00007efc33fe0b45  push r9
00007efc33fe0b47  push r10
00007efc33fe0b49  push r11
00007efc33fe0b4b  sub rsp, 0xF0
00007efc33fe0b52  vmovaps [rsp], xmm0
00007efc33fe0b57  vmovaps [rsp+0x10], xmm1
00007efc33fe0b5d  vmovaps [rsp+0x20], xmm2
00007efc33fe0b63  vmovaps [rsp+0x30], xmm3
00007efc33fe0b69  vmovaps [rsp+0x40], xmm4
00007efc33fe0b6f  vmovaps [rsp+0x50], xmm5
00007efc33fe0b75  vmovaps [rsp+0x60], xmm6
00007efc33fe0b7b  vmovaps [rsp+0x70], xmm7
00007efc33fe0b81  vmovaps [rsp+0x80], xmm8
00007efc33fe0b8a  vmovaps [rsp+0x90], xmm9
00007efc33fe0b93  vmovaps [rsp+0xA0], xmm10
00007efc33fe0b9c  vmovaps [rsp+0xB0], xmm12
00007efc33fe0ba5  vmovaps [rsp+0xC0], xmm13
00007efc33fe0bae  vmovaps [rsp+0xD0], xmm14
00007efc33fe0bb7  vmovaps [rsp+0xE0], xmm15
00007efc33fe0bc0  sub rsp, 0x30
00007efc33fe0bc4  movaps [rsp], xmm11
00007efc33fe0bc9  movaps [rsp+0x10], xmm10
00007efc33fe0bcf  movaps [rsp+0x20], xmm14
00007efc33fe0bd5  lea rdi, [rsp]
00007efc33fe0bd9  mov esi, 0x00
00007efc33fe0bde  mov rax, 0x5D9448894530
00007efc33fe0be8  call rax
00007efc33fe0bea  movaps xmm11, [rsp]
00007efc33fe0bef  add rsp, 0x30
00007efc33fe0bf3  vmovaps xmm0, [rsp]
00007efc33fe0bf8  vmovaps xmm1, [rsp+0x10]
00007efc33fe0bfe  vmovaps xmm2, [rsp+0x20]
00007efc33fe0c04  vmovaps xmm3, [rsp+0x30]
00007efc33fe0c0a  vmovaps xmm4, [rsp+0x40]
00007efc33fe0c10  vmovaps xmm5, [rsp+0x50]
00007efc33fe0c16  vmovaps xmm6, [rsp+0x60]
00007efc33fe0c1c  vmovaps xmm7, [rsp+0x70]
00007efc33fe0c22  vmovaps xmm8, [rsp+0x80]
00007efc33fe0c2b  vmovaps xmm9, [rsp+0x90]
00007efc33fe0c34  vmovaps xmm10, [rsp+0xA0]
00007efc33fe0c3d  vmovaps xmm12, [rsp+0xB0]
00007efc33fe0c46  vmovaps xmm13, [rsp+0xC0]
00007efc33fe0c4f  vmovaps xmm14, [rsp+0xD0]
00007efc33fe0c58  vmovaps xmm15, [rsp+0xE0]
00007efc33fe0c61  add rsp, 0xF0
00007efc33fe0c68  pop r11
00007efc33fe0c6a  pop r10
00007efc33fe0c6c  pop r9
00007efc33fe0c6e  pop r8
00007efc33fe0c70  pop rsi
00007efc33fe0c71  pop rdi
00007efc33fe0c72  pop rdx
00007efc33fe0c73  pop rcx
00007efc33fe0c74  pop rax
00007efc33fe0c75  add rsp, 0x08
00007efc33fe0c79  jmp 0x00007EFC33FDC6A0
00007efc33fe0c7e  call 0x00007EFC33EC33A0
00007efc33fe0c83  jmp 0x00007EFC33FDC6AA
00007efc33fe0c88  sub rsp, 0x08
00007efc33fe0c8c  push rax
00007efc33fe0c8d  push rcx
00007efc33fe0c8e  push rdx
00007efc33fe0c8f  push rdi
00007efc33fe0c90  push rsi
00007efc33fe0c91  push r8
00007efc33fe0c93  push r9
00007efc33fe0c95  push r10
00007efc33fe0c97  push r11
00007efc33fe0c99  sub rsp, 0xF0
00007efc33fe0ca0  vmovaps [rsp], xmm0
00007efc33fe0ca5  vmovaps [rsp+0x10], xmm1
00007efc33fe0cab  vmovaps [rsp+0x20], xmm2
00007efc33fe0cb1  vmovaps [rsp+0x30], xmm3
00007efc33fe0cb7  vmovaps [rsp+0x40], xmm4
00007efc33fe0cbd  vmovaps [rsp+0x50], xmm5
00007efc33fe0cc3  vmovaps [rsp+0x60], xmm6
00007efc33fe0cc9  vmovaps [rsp+0x70], xmm7
00007efc33fe0ccf  vmovaps [rsp+0x80], xmm8
00007efc33fe0cd8  vmovaps [rsp+0x90], xmm9
00007efc33fe0ce1  vmovaps [rsp+0xA0], xmm11
00007efc33fe0cea  vmovaps [rsp+0xB0], xmm12
00007efc33fe0cf3  vmovaps [rsp+0xC0], xmm13
00007efc33fe0cfc  vmovaps [rsp+0xD0], xmm14
00007efc33fe0d05  vmovaps [rsp+0xE0], xmm15
00007efc33fe0d0e  sub rsp, 0x30
00007efc33fe0d12  movaps [rsp], xmm10
00007efc33fe0d17  movaps [rsp+0x10], xmm1
00007efc33fe0d1c  movaps [rsp+0x20], xmm12
00007efc33fe0d22  lea rdi, [rsp]
00007efc33fe0d26  mov esi, 0x00
00007efc33fe0d2b  mov rax, 0x5D9448894530
00007efc33fe0d35  call rax
00007efc33fe0d37  movaps xmm10, [rsp]
00007efc33fe0d3c  add rsp, 0x30
00007efc33fe0d40  vmovaps xmm0, [rsp]
00007efc33fe0d45  vmovaps xmm1, [rsp+0x10]
00007efc33fe0d4b  vmovaps xmm2, [rsp+0x20]
00007efc33fe0d51  vmovaps xmm3, [rsp+0x30]
00007efc33fe0d57  vmovaps xmm4, [rsp+0x40]
00007efc33fe0d5d  vmovaps xmm5, [rsp+0x50]
00007efc33fe0d63  vmovaps xmm6, [rsp+0x60]
00007efc33fe0d69  vmovaps xmm7, [rsp+0x70]
00007efc33fe0d6f  vmovaps xmm8, [rsp+0x80]
00007efc33fe0d78  vmovaps xmm9, [rsp+0x90]
00007efc33fe0d81  vmovaps xmm11, [rsp+0xA0]
00007efc33fe0d8a  vmovaps xmm12, [rsp+0xB0]
00007efc33fe0d93  vmovaps xmm13, [rsp+0xC0]
00007efc33fe0d9c  vmovaps xmm14, [rsp+0xD0]
00007efc33fe0da5  vmovaps xmm15, [rsp+0xE0]
00007efc33fe0dae  add rsp, 0xF0
00007efc33fe0db5  pop r11
00007efc33fe0db7  pop r10
00007efc33fe0db9  pop r9
00007efc33fe0dbb  pop r8
00007efc33fe0dbd  pop rsi
00007efc33fe0dbe  pop rdi
00007efc33fe0dbf  pop rdx
00007efc33fe0dc0  pop rcx
00007efc33fe0dc1  pop rax
00007efc33fe0dc2  add rsp, 0x08
00007efc33fe0dc6  jmp 0x00007EFC33FDC6CD
00007efc33fe0dcb  sub rsp, 0x08
00007efc33fe0dcf  push rax
00007efc33fe0dd0  push rcx
00007efc33fe0dd1  push rdx
00007efc33fe0dd2  push rdi
00007efc33fe0dd3  push rsi
00007efc33fe0dd4  push r8
00007efc33fe0dd6  push r9
00007efc33fe0dd8  push r10
00007efc33fe0dda  push r11
00007efc33fe0ddc  sub rsp, 0xF0
00007efc33fe0de3  vmovaps [rsp], xmm0
00007efc33fe0de8  vmovaps [rsp+0x10], xmm1
00007efc33fe0dee  vmovaps [rsp+0x20], xmm2
00007efc33fe0df4  vmovaps [rsp+0x30], xmm3
00007efc33fe0dfa  vmovaps [rsp+0x40], xmm4
00007efc33fe0e00  vmovaps [rsp+0x50], xmm5
00007efc33fe0e06  vmovaps [rsp+0x60], xmm6
00007efc33fe0e0c  vmovaps [rsp+0x70], xmm7
00007efc33fe0e12  vmovaps [rsp+0x80], xmm8
00007efc33fe0e1b  vmovaps [rsp+0x90], xmm9
00007efc33fe0e24  vmovaps [rsp+0xA0], xmm10
00007efc33fe0e2d  vmovaps [rsp+0xB0], xmm11
00007efc33fe0e36  vmovaps [rsp+0xC0], xmm13
00007efc33fe0e3f  vmovaps [rsp+0xD0], xmm14
00007efc33fe0e48  vmovaps [rsp+0xE0], xmm15
00007efc33fe0e51  sub rsp, 0x30
00007efc33fe0e55  movaps [rsp], xmm12
00007efc33fe0e5a  movaps [rsp+0x10], xmm14
00007efc33fe0e60  movaps [rsp+0x20], xmm1
00007efc33fe0e65  lea rdi, [rsp]
00007efc33fe0e69  mov esi, 0x00
00007efc33fe0e6e  mov rax, 0x5D9448894530
00007efc33fe0e78  call rax
00007efc33fe0e7a  movaps xmm12, [rsp]
00007efc33fe0e7f  add rsp, 0x30
00007efc33fe0e83  vmovaps xmm0, [rsp]
00007efc33fe0e88  vmovaps xmm1, [rsp+0x10]
00007efc33fe0e8e  vmovaps xmm2, [rsp+0x20]
00007efc33fe0e94  vmovaps xmm3, [rsp+0x30]
00007efc33fe0e9a  vmovaps xmm4, [rsp+0x40]
00007efc33fe0ea0  vmovaps xmm5, [rsp+0x50]
00007efc33fe0ea6  vmovaps xmm6, [rsp+0x60]
00007efc33fe0eac  vmovaps xmm7, [rsp+0x70]
00007efc33fe0eb2  vmovaps xmm8, [rsp+0x80]
00007efc33fe0ebb  vmovaps xmm9, [rsp+0x90]
00007efc33fe0ec4  vmovaps xmm10, [rsp+0xA0]
00007efc33fe0ecd  vmovaps xmm11, [rsp+0xB0]
00007efc33fe0ed6  vmovaps xmm13, [rsp+0xC0]
00007efc33fe0edf  vmovaps xmm14, [rsp+0xD0]
00007efc33fe0ee8  vmovaps xmm15, [rsp+0xE0]
00007efc33fe0ef1  add rsp, 0xF0
00007efc33fe0ef8  pop r11
00007efc33fe0efa  pop r10
00007efc33fe0efc  pop r9
00007efc33fe0efe  pop r8
00007efc33fe0f00  pop rsi
00007efc33fe0f01  pop rdi
00007efc33fe0f02  pop rdx
00007efc33fe0f03  pop rcx
00007efc33fe0f04  pop rax
00007efc33fe0f05  add rsp, 0x08
00007efc33fe0f09  jmp 0x00007EFC33FDC6FC
00007efc33fe0f0e  sub rsp, 0x08
00007efc33fe0f12  push rax
00007efc33fe0f13  push rcx
00007efc33fe0f14  push rdx
00007efc33fe0f15  push rdi
00007efc33fe0f16  push rsi
00007efc33fe0f17  push r8
00007efc33fe0f19  push r9
00007efc33fe0f1b  push r10
00007efc33fe0f1d  push r11
00007efc33fe0f1f  sub rsp, 0xF0
00007efc33fe0f26  vmovaps [rsp], xmm0
00007efc33fe0f2b  vmovaps [rsp+0x10], xmm1
00007efc33fe0f31  vmovaps [rsp+0x20], xmm2
00007efc33fe0f37  vmovaps [rsp+0x30], xmm3
00007efc33fe0f3d  vmovaps [rsp+0x40], xmm4
00007efc33fe0f43  vmovaps [rsp+0x50], xmm5
00007efc33fe0f49  vmovaps [rsp+0x60], xmm6
00007efc33fe0f4f  vmovaps [rsp+0x70], xmm7
00007efc33fe0f55  vmovaps [rsp+0x80], xmm8
00007efc33fe0f5e  vmovaps [rsp+0x90], xmm9
00007efc33fe0f67  vmovaps [rsp+0xA0], xmm10
00007efc33fe0f70  vmovaps [rsp+0xB0], xmm11
00007efc33fe0f79  vmovaps [rsp+0xC0], xmm12
00007efc33fe0f82  vmovaps [rsp+0xD0], xmm13
00007efc33fe0f8b  vmovaps [rsp+0xE0], xmm15
00007efc33fe0f94  sub rsp, 0x30
00007efc33fe0f98  movaps [rsp], xmm14
00007efc33fe0f9d  movaps [rsp+0x10], xmm9
00007efc33fe0fa3  movaps [rsp+0x20], xmm1
00007efc33fe0fa8  lea rdi, [rsp]
00007efc33fe0fac  mov esi, 0x00
00007efc33fe0fb1  mov rax, 0x5D9448894530
00007efc33fe0fbb  call rax
00007efc33fe0fbd  movaps xmm14, [rsp]
00007efc33fe0fc2  add rsp, 0x30
00007efc33fe0fc6  vmovaps xmm0, [rsp]
00007efc33fe0fcb  vmovaps xmm1, [rsp+0x10]
00007efc33fe0fd1  vmovaps xmm2, [rsp+0x20]
00007efc33fe0fd7  vmovaps xmm3, [rsp+0x30]
00007efc33fe0fdd  vmovaps xmm4, [rsp+0x40]
00007efc33fe0fe3  vmovaps xmm5, [rsp+0x50]
00007efc33fe0fe9  vmovaps xmm6, [rsp+0x60]
00007efc33fe0fef  vmovaps xmm7, [rsp+0x70]
00007efc33fe0ff5  vmovaps xmm8, [rsp+0x80]
00007efc33fe0ffe  vmovaps xmm9, [rsp+0x90]
00007efc33fe1007  vmovaps xmm10, [rsp+0xA0]
00007efc33fe1010  vmovaps xmm11, [rsp+0xB0]
00007efc33fe1019  vmovaps xmm12, [rsp+0xC0]
00007efc33fe1022  vmovaps xmm13, [rsp+0xD0]
00007efc33fe102b  vmovaps xmm15, [rsp+0xE0]
00007efc33fe1034  add rsp, 0xF0
00007efc33fe103b  pop r11
00007efc33fe103d  pop r10
00007efc33fe103f  pop r9
00007efc33fe1041  pop r8
00007efc33fe1043  pop rsi
00007efc33fe1044  pop rdi
00007efc33fe1045  pop rdx
00007efc33fe1046  pop rcx
00007efc33fe1047  pop rax
00007efc33fe1048  add rsp, 0x08
00007efc33fe104c  jmp 0x00007EFC33FDC72B
00007efc33fe1051  sub rsp, 0x08
00007efc33fe1055  push rax
00007efc33fe1056  push rcx
00007efc33fe1057  push rdx
00007efc33fe1058  push rdi
00007efc33fe1059  push rsi
00007efc33fe105a  push r8
00007efc33fe105c  push r9
00007efc33fe105e  push r10
00007efc33fe1060  push r11
00007efc33fe1062  sub rsp, 0xF0
00007efc33fe1069  vmovaps [rsp], xmm0
00007efc33fe106e  vmovaps [rsp+0x10], xmm2
00007efc33fe1074  vmovaps [rsp+0x20], xmm3
00007efc33fe107a  vmovaps [rsp+0x30], xmm4
00007efc33fe1080  vmovaps [rsp+0x40], xmm5
00007efc33fe1086  vmovaps [rsp+0x50], xmm6
00007efc33fe108c  vmovaps [rsp+0x60], xmm7
00007efc33fe1092  vmovaps [rsp+0x70], xmm8
00007efc33fe1098  vmovaps [rsp+0x80], xmm9
00007efc33fe10a1  vmovaps [rsp+0x90], xmm10
00007efc33fe10aa  vmovaps [rsp+0xA0], xmm11
00007efc33fe10b3  vmovaps [rsp+0xB0], xmm12
00007efc33fe10bc  vmovaps [rsp+0xC0], xmm13
00007efc33fe10c5  vmovaps [rsp+0xD0], xmm14
00007efc33fe10ce  vmovaps [rsp+0xE0], xmm15
00007efc33fe10d7  sub rsp, 0x30
00007efc33fe10db  movaps [rsp], xmm1
00007efc33fe10df  movaps [rsp+0x10], xmm13
00007efc33fe10e5  movaps [rsp+0x20], xmm8
00007efc33fe10eb  lea rdi, [rsp]
00007efc33fe10ef  mov esi, 0x00
00007efc33fe10f4  mov rax, 0x5D9448894530
00007efc33fe10fe  call rax
00007efc33fe1100  movaps xmm1, [rsp]
00007efc33fe1104  add rsp, 0x30
00007efc33fe1108  vmovaps xmm0, [rsp]
00007efc33fe110d  vmovaps xmm2, [rsp+0x10]
00007efc33fe1113  vmovaps xmm3, [rsp+0x20]
00007efc33fe1119  vmovaps xmm4, [rsp+0x30]
00007efc33fe111f  vmovaps xmm5, [rsp+0x40]
00007efc33fe1125  vmovaps xmm6, [rsp+0x50]
00007efc33fe112b  vmovaps xmm7, [rsp+0x60]
00007efc33fe1131  vmovaps xmm8, [rsp+0x70]
00007efc33fe1137  vmovaps xmm9, [rsp+0x80]
00007efc33fe1140  vmovaps xmm10, [rsp+0x90]
00007efc33fe1149  vmovaps xmm11, [rsp+0xA0]
00007efc33fe1152  vmovaps xmm12, [rsp+0xB0]
00007efc33fe115b  vmovaps xmm13, [rsp+0xC0]
00007efc33fe1164  vmovaps xmm14, [rsp+0xD0]
00007efc33fe116d  vmovaps xmm15, [rsp+0xE0]
00007efc33fe1176  add rsp, 0xF0
00007efc33fe117d  pop r11
00007efc33fe117f  pop r10
00007efc33fe1181  pop r9
00007efc33fe1183  pop r8
00007efc33fe1185  pop rsi
00007efc33fe1186  pop rdi
00007efc33fe1187  pop rdx
00007efc33fe1188  pop rcx
00007efc33fe1189  pop rax
00007efc33fe118a  add rsp, 0x08
00007efc33fe118e  jmp 0x00007EFC33FDC74D
00007efc33fe1193  call 0x00007EFC33E0C260
00007efc33fe1198  jmp 0x00007EFC33FDC75B
00007efc33fe119d  call 0x00007EFC33EBD750
00007efc33fe11a2  jmp 0x00007EFC33FDC765
00007efc33fe11a7  sub rsp, 0x08
00007efc33fe11ab  push rax
00007efc33fe11ac  push rcx
00007efc33fe11ad  push rdx
00007efc33fe11ae  push rdi
00007efc33fe11af  push rsi
00007efc33fe11b0  push r8
00007efc33fe11b2  push r9
00007efc33fe11b4  push r10
00007efc33fe11b6  push r11
00007efc33fe11b8  sub rsp, 0xF0
00007efc33fe11bf  vmovaps [rsp], xmm0
00007efc33fe11c4  vmovaps [rsp+0x10], xmm1
00007efc33fe11ca  vmovaps [rsp+0x20], xmm2
00007efc33fe11d0  vmovaps [rsp+0x30], xmm3
00007efc33fe11d6  vmovaps [rsp+0x40], xmm4
00007efc33fe11dc  vmovaps [rsp+0x50], xmm5
00007efc33fe11e2  vmovaps [rsp+0x60], xmm6
00007efc33fe11e8  vmovaps [rsp+0x70], xmm7
00007efc33fe11ee  vmovaps [rsp+0x80], xmm9
00007efc33fe11f7  vmovaps [rsp+0x90], xmm10
00007efc33fe1200  vmovaps [rsp+0xA0], xmm11
00007efc33fe1209  vmovaps [rsp+0xB0], xmm12
00007efc33fe1212  vmovaps [rsp+0xC0], xmm13
00007efc33fe121b  vmovaps [rsp+0xD0], xmm14
00007efc33fe1224  vmovaps [rsp+0xE0], xmm15
00007efc33fe122d  sub rsp, 0x30
00007efc33fe1231  movaps [rsp], xmm8
00007efc33fe1236  movaps [rsp+0x10], xmm15
00007efc33fe123c  movaps [rsp+0x20], xmm7
00007efc33fe1241  lea rdi, [rsp]
00007efc33fe1245  mov esi, 0x00
00007efc33fe124a  mov rax, 0x5D9448894530
00007efc33fe1254  call rax
00007efc33fe1256  movaps xmm8, [rsp]
00007efc33fe125b  add rsp, 0x30
00007efc33fe125f  vmovaps xmm0, [rsp]
00007efc33fe1264  vmovaps xmm1, [rsp+0x10]
00007efc33fe126a  vmovaps xmm2, [rsp+0x20]
00007efc33fe1270  vmovaps xmm3, [rsp+0x30]
00007efc33fe1276  vmovaps xmm4, [rsp+0x40]
00007efc33fe127c  vmovaps xmm5, [rsp+0x50]
00007efc33fe1282  vmovaps xmm6, [rsp+0x60]
00007efc33fe1288  vmovaps xmm7, [rsp+0x70]
00007efc33fe128e  vmovaps xmm9, [rsp+0x80]
00007efc33fe1297  vmovaps xmm10, [rsp+0x90]
00007efc33fe12a0  vmovaps xmm11, [rsp+0xA0]
00007efc33fe12a9  vmovaps xmm12, [rsp+0xB0]
00007efc33fe12b2  vmovaps xmm13, [rsp+0xC0]
00007efc33fe12bb  vmovaps xmm14, [rsp+0xD0]
00007efc33fe12c4  vmovaps xmm15, [rsp+0xE0]
00007efc33fe12cd  add rsp, 0xF0
00007efc33fe12d4  pop r11
00007efc33fe12d6  pop r10
00007efc33fe12d8  pop r9
00007efc33fe12da  pop r8
00007efc33fe12dc  pop rsi
00007efc33fe12dd  pop rdi
00007efc33fe12de  pop rdx
00007efc33fe12df  pop rcx
00007efc33fe12e0  pop rax
00007efc33fe12e1  add rsp, 0x08
00007efc33fe12e5  jmp 0x00007EFC33FDC787
00007efc33fe12ea  sub rsp, 0x08
00007efc33fe12ee  push rax
00007efc33fe12ef  push rcx
00007efc33fe12f0  push rdx
00007efc33fe12f1  push rdi
00007efc33fe12f2  push rsi
00007efc33fe12f3  push r8
00007efc33fe12f5  push r9
00007efc33fe12f7  push r10
00007efc33fe12f9  push r11
00007efc33fe12fb  sub rsp, 0xF0
00007efc33fe1302  vmovaps [rsp], xmm0
00007efc33fe1307  vmovaps [rsp+0x10], xmm1
00007efc33fe130d  vmovaps [rsp+0x20], xmm2
00007efc33fe1313  vmovaps [rsp+0x30], xmm3
00007efc33fe1319  vmovaps [rsp+0x40], xmm4
00007efc33fe131f  vmovaps [rsp+0x50], xmm5
00007efc33fe1325  vmovaps [rsp+0x60], xmm6
00007efc33fe132b  vmovaps [rsp+0x70], xmm8
00007efc33fe1331  vmovaps [rsp+0x80], xmm9
00007efc33fe133a  vmovaps [rsp+0x90], xmm10
00007efc33fe1343  vmovaps [rsp+0xA0], xmm11
00007efc33fe134c  vmovaps [rsp+0xB0], xmm12
00007efc33fe1355  vmovaps [rsp+0xC0], xmm13
00007efc33fe135e  vmovaps [rsp+0xD0], xmm14
00007efc33fe1367  vmovaps [rsp+0xE0], xmm15
00007efc33fe1370  sub rsp, 0x30
00007efc33fe1374  movaps [rsp], xmm7
00007efc33fe1378  movaps [rsp+0x10], xmm9
00007efc33fe137e  movaps [rsp+0x20], xmm15
00007efc33fe1384  lea rdi, [rsp]
00007efc33fe1388  mov esi, 0x00
00007efc33fe138d  mov rax, 0x5D9448894530
00007efc33fe1397  call rax
00007efc33fe1399  movaps xmm7, [rsp]
00007efc33fe139d  add rsp, 0x30
00007efc33fe13a1  vmovaps xmm0, [rsp]
00007efc33fe13a6  vmovaps xmm1, [rsp+0x10]
00007efc33fe13ac  vmovaps xmm2, [rsp+0x20]
00007efc33fe13b2  vmovaps xmm3, [rsp+0x30]
00007efc33fe13b8  vmovaps xmm4, [rsp+0x40]
00007efc33fe13be  vmovaps xmm5, [rsp+0x50]
00007efc33fe13c4  vmovaps xmm6, [rsp+0x60]
00007efc33fe13ca  vmovaps xmm8, [rsp+0x70]
00007efc33fe13d0  vmovaps xmm9, [rsp+0x80]
00007efc33fe13d9  vmovaps xmm10, [rsp+0x90]
00007efc33fe13e2  vmovaps xmm11, [rsp+0xA0]
00007efc33fe13eb  vmovaps xmm12, [rsp+0xB0]
00007efc33fe13f4  vmovaps xmm13, [rsp+0xC0]
00007efc33fe13fd  vmovaps xmm14, [rsp+0xD0]
00007efc33fe1406  vmovaps xmm15, [rsp+0xE0]
00007efc33fe140f  add rsp, 0xF0
00007efc33fe1416  pop r11
00007efc33fe1418  pop r10
00007efc33fe141a  pop r9
00007efc33fe141c  pop r8
00007efc33fe141e  pop rsi
00007efc33fe141f  pop rdi
00007efc33fe1420  pop rdx
00007efc33fe1421  pop rcx
00007efc33fe1422  pop rax
00007efc33fe1423  add rsp, 0x08
00007efc33fe1427  jmp 0x00007EFC33FDC7B4
00007efc33fe142c  sub rsp, 0x08
00007efc33fe1430  push rax
00007efc33fe1431  push rcx
00007efc33fe1432  push rdx
00007efc33fe1433  push rdi
00007efc33fe1434  push rsi
00007efc33fe1435  push r8
00007efc33fe1437  push r9
00007efc33fe1439  push r10
00007efc33fe143b  push r11
00007efc33fe143d  sub rsp, 0xF0
00007efc33fe1444  vmovaps [rsp], xmm0
00007efc33fe1449  vmovaps [rsp+0x10], xmm1
00007efc33fe144f  vmovaps [rsp+0x20], xmm2
00007efc33fe1455  vmovaps [rsp+0x30], xmm3
00007efc33fe145b  vmovaps [rsp+0x40], xmm4
00007efc33fe1461  vmovaps [rsp+0x50], xmm5
00007efc33fe1467  vmovaps [rsp+0x60], xmm6
00007efc33fe146d  vmovaps [rsp+0x70], xmm7
00007efc33fe1473  vmovaps [rsp+0x80], xmm8
00007efc33fe147c  vmovaps [rsp+0x90], xmm10
00007efc33fe1485  vmovaps [rsp+0xA0], xmm11
00007efc33fe148e  vmovaps [rsp+0xB0], xmm12
00007efc33fe1497  vmovaps [rsp+0xC0], xmm13
00007efc33fe14a0  vmovaps [rsp+0xD0], xmm14
00007efc33fe14a9  vmovaps [rsp+0xE0], xmm15
00007efc33fe14b2  sub rsp, 0x30
00007efc33fe14b6  movaps [rsp], xmm9
00007efc33fe14bb  movaps [rsp+0x10], xmm13
00007efc33fe14c1  movaps [rsp+0x20], xmm15
00007efc33fe14c7  lea rdi, [rsp]
00007efc33fe14cb  mov esi, 0x00
00007efc33fe14d0  mov rax, 0x5D9448894530
00007efc33fe14da  call rax
00007efc33fe14dc  movaps xmm9, [rsp]
00007efc33fe14e1  add rsp, 0x30
00007efc33fe14e5  vmovaps xmm0, [rsp]
00007efc33fe14ea  vmovaps xmm1, [rsp+0x10]
00007efc33fe14f0  vmovaps xmm2, [rsp+0x20]
00007efc33fe14f6  vmovaps xmm3, [rsp+0x30]
00007efc33fe14fc  vmovaps xmm4, [rsp+0x40]
00007efc33fe1502  vmovaps xmm5, [rsp+0x50]
00007efc33fe1508  vmovaps xmm6, [rsp+0x60]
00007efc33fe150e  vmovaps xmm7, [rsp+0x70]
00007efc33fe1514  vmovaps xmm8, [rsp+0x80]
00007efc33fe151d  vmovaps xmm10, [rsp+0x90]
00007efc33fe1526  vmovaps xmm11, [rsp+0xA0]
00007efc33fe152f  vmovaps xmm12, [rsp+0xB0]
00007efc33fe1538  vmovaps xmm13, [rsp+0xC0]
00007efc33fe1541  vmovaps xmm14, [rsp+0xD0]
00007efc33fe154a  vmovaps xmm15, [rsp+0xE0]
00007efc33fe1553  add rsp, 0xF0
00007efc33fe155a  pop r11
00007efc33fe155c  pop r10
00007efc33fe155e  pop r9
00007efc33fe1560  pop r8
00007efc33fe1562  pop rsi
00007efc33fe1563  pop rdi
00007efc33fe1564  pop rdx
00007efc33fe1565  pop rcx
00007efc33fe1566  pop rax
00007efc33fe1567  add rsp, 0x08
00007efc33fe156b  jmp 0x00007EFC33FDC7E2
00007efc33fe1570  sub rsp, 0x08
00007efc33fe1574  push rax
00007efc33fe1575  push rcx
00007efc33fe1576  push rdx
00007efc33fe1577  push rdi
00007efc33fe1578  push rsi
00007efc33fe1579  push r8
00007efc33fe157b  push r9
00007efc33fe157d  push r10
00007efc33fe157f  push r11
00007efc33fe1581  sub rsp, 0xF0
00007efc33fe1588  vmovaps [rsp], xmm0
00007efc33fe158d  vmovaps [rsp+0x10], xmm1
00007efc33fe1593  vmovaps [rsp+0x20], xmm2
00007efc33fe1599  vmovaps [rsp+0x30], xmm3
00007efc33fe159f  vmovaps [rsp+0x40], xmm4
00007efc33fe15a5  vmovaps [rsp+0x50], xmm5
00007efc33fe15ab  vmovaps [rsp+0x60], xmm6
00007efc33fe15b1  vmovaps [rsp+0x70], xmm7
00007efc33fe15b7  vmovaps [rsp+0x80], xmm8
00007efc33fe15c0  vmovaps [rsp+0x90], xmm9
00007efc33fe15c9  vmovaps [rsp+0xA0], xmm10
00007efc33fe15d2  vmovaps [rsp+0xB0], xmm11
00007efc33fe15db  vmovaps [rsp+0xC0], xmm12
00007efc33fe15e4  vmovaps [rsp+0xD0], xmm13
00007efc33fe15ed  vmovaps [rsp+0xE0], xmm14
00007efc33fe15f6  sub rsp, 0x30
00007efc33fe15fa  movaps [rsp], xmm15
00007efc33fe15ff  movaps [rsp+0x10], xmm11
00007efc33fe1605  movaps [rsp+0x20], xmm12
00007efc33fe160b  lea rdi, [rsp]
00007efc33fe160f  mov esi, 0x00
00007efc33fe1614  mov rax, 0x5D9448894530
00007efc33fe161e  call rax
00007efc33fe1620  movaps xmm15, [rsp]
00007efc33fe1625  add rsp, 0x30
00007efc33fe1629  vmovaps xmm0, [rsp]
00007efc33fe162e  vmovaps xmm1, [rsp+0x10]
00007efc33fe1634  vmovaps xmm2, [rsp+0x20]
00007efc33fe163a  vmovaps xmm3, [rsp+0x30]
00007efc33fe1640  vmovaps xmm4, [rsp+0x40]
00007efc33fe1646  vmovaps xmm5, [rsp+0x50]
00007efc33fe164c  vmovaps xmm6, [rsp+0x60]
00007efc33fe1652  vmovaps xmm7, [rsp+0x70]
00007efc33fe1658  vmovaps xmm8, [rsp+0x80]
00007efc33fe1661  vmovaps xmm9, [rsp+0x90]
00007efc33fe166a  vmovaps xmm10, [rsp+0xA0]
00007efc33fe1673  vmovaps xmm11, [rsp+0xB0]
00007efc33fe167c  vmovaps xmm12, [rsp+0xC0]
00007efc33fe1685  vmovaps xmm13, [rsp+0xD0]
00007efc33fe168e  vmovaps xmm14, [rsp+0xE0]
00007efc33fe1697  add rsp, 0xF0
00007efc33fe169e  pop r11
00007efc33fe16a0  pop r10
00007efc33fe16a2  pop r9
00007efc33fe16a4  pop r8
00007efc33fe16a6  pop rsi
00007efc33fe16a7  pop rdi
00007efc33fe16a8  pop rdx
00007efc33fe16a9  pop rcx
00007efc33fe16aa  pop rax
00007efc33fe16ab  add rsp, 0x08
00007efc33fe16af  jmp 0x00007EFC33FDC7FD
00007efc33fe16b4  sub rsp, 0x08
00007efc33fe16b8  push rax
00007efc33fe16b9  push rcx
00007efc33fe16ba  push rdx
00007efc33fe16bb  push rdi
00007efc33fe16bc  push rsi
00007efc33fe16bd  push r8
00007efc33fe16bf  push r9
00007efc33fe16c1  push r10
00007efc33fe16c3  push r11
00007efc33fe16c5  sub rsp, 0xF0
00007efc33fe16cc  vmovaps [rsp], xmm0
00007efc33fe16d1  vmovaps [rsp+0x10], xmm1
00007efc33fe16d7  vmovaps [rsp+0x20], xmm2
00007efc33fe16dd  vmovaps [rsp+0x30], xmm3
00007efc33fe16e3  vmovaps [rsp+0x40], xmm4
00007efc33fe16e9  vmovaps [rsp+0x50], xmm5
00007efc33fe16ef  vmovaps [rsp+0x60], xmm6
00007efc33fe16f5  vmovaps [rsp+0x70], xmm7
00007efc33fe16fb  vmovaps [rsp+0x80], xmm8
00007efc33fe1704  vmovaps [rsp+0x90], xmm9
00007efc33fe170d  vmovaps [rsp+0xA0], xmm10
00007efc33fe1716  vmovaps [rsp+0xB0], xmm11
00007efc33fe171f  vmovaps [rsp+0xC0], xmm12
00007efc33fe1728  vmovaps [rsp+0xD0], xmm14
00007efc33fe1731  vmovaps [rsp+0xE0], xmm15
00007efc33fe173a  sub rsp, 0x30
00007efc33fe173e  movaps [rsp], xmm13
00007efc33fe1743  movaps [rsp+0x10], xmm10
00007efc33fe1749  movaps [rsp+0x20], xmm14
00007efc33fe174f  lea rdi, [rsp]
00007efc33fe1753  mov esi, 0x00
00007efc33fe1758  mov rax, 0x5D9448894530
00007efc33fe1762  call rax
00007efc33fe1764  movaps xmm13, [rsp]
00007efc33fe1769  add rsp, 0x30
00007efc33fe176d  vmovaps xmm0, [rsp]
00007efc33fe1772  vmovaps xmm1, [rsp+0x10]
00007efc33fe1778  vmovaps xmm2, [rsp+0x20]
00007efc33fe177e  vmovaps xmm3, [rsp+0x30]
00007efc33fe1784  vmovaps xmm4, [rsp+0x40]
00007efc33fe178a  vmovaps xmm5, [rsp+0x50]
00007efc33fe1790  vmovaps xmm6, [rsp+0x60]
00007efc33fe1796  vmovaps xmm7, [rsp+0x70]
00007efc33fe179c  vmovaps xmm8, [rsp+0x80]
00007efc33fe17a5  vmovaps xmm9, [rsp+0x90]
00007efc33fe17ae  vmovaps xmm10, [rsp+0xA0]
00007efc33fe17b7  vmovaps xmm11, [rsp+0xB0]
00007efc33fe17c0  vmovaps xmm12, [rsp+0xC0]
00007efc33fe17c9  vmovaps xmm14, [rsp+0xD0]
00007efc33fe17d2  vmovaps xmm15, [rsp+0xE0]
00007efc33fe17db  add rsp, 0xF0
00007efc33fe17e2  pop r11
00007efc33fe17e4  pop r10
00007efc33fe17e6  pop r9
00007efc33fe17e8  pop r8
00007efc33fe17ea  pop rsi
00007efc33fe17eb  pop rdi
00007efc33fe17ec  pop rdx
00007efc33fe17ed  pop rcx
00007efc33fe17ee  pop rax
00007efc33fe17ef  add rsp, 0x08
00007efc33fe17f3  jmp 0x00007EFC33FDC820
00007efc33fe17f8  sub rsp, 0x08
00007efc33fe17fc  push rax
00007efc33fe17fd  push rcx
00007efc33fe17fe  push rdx
00007efc33fe17ff  push rdi
00007efc33fe1800  push rsi
00007efc33fe1801  push r8
00007efc33fe1803  push r9
00007efc33fe1805  push r10
00007efc33fe1807  push r11
00007efc33fe1809  sub rsp, 0xF0
00007efc33fe1810  vmovaps [rsp], xmm0
00007efc33fe1815  vmovaps [rsp+0x10], xmm1
00007efc33fe181b  vmovaps [rsp+0x20], xmm2
00007efc33fe1821  vmovaps [rsp+0x30], xmm3
00007efc33fe1827  vmovaps [rsp+0x40], xmm4
00007efc33fe182d  vmovaps [rsp+0x50], xmm5
00007efc33fe1833  vmovaps [rsp+0x60], xmm6
00007efc33fe1839  vmovaps [rsp+0x70], xmm7
00007efc33fe183f  vmovaps [rsp+0x80], xmm8
00007efc33fe1848  vmovaps [rsp+0x90], xmm9
00007efc33fe1851  vmovaps [rsp+0xA0], xmm10
00007efc33fe185a  vmovaps [rsp+0xB0], xmm11
00007efc33fe1863  vmovaps [rsp+0xC0], xmm12
00007efc33fe186c  vmovaps [rsp+0xD0], xmm13
00007efc33fe1875  vmovaps [rsp+0xE0], xmm15
00007efc33fe187e  sub rsp, 0x30
00007efc33fe1882  movaps [rsp], xmm14
00007efc33fe1887  movaps [rsp+0x10], xmm1
00007efc33fe188c  movaps [rsp+0x20], xmm7
00007efc33fe1891  lea rdi, [rsp]
00007efc33fe1895  mov esi, 0x00
00007efc33fe189a  mov rax, 0x5D9448894530
00007efc33fe18a4  call rax
00007efc33fe18a6  movaps xmm14, [rsp]
00007efc33fe18ab  add rsp, 0x30
00007efc33fe18af  vmovaps xmm0, [rsp]
00007efc33fe18b4  vmovaps xmm1, [rsp+0x10]
00007efc33fe18ba  vmovaps xmm2, [rsp+0x20]
00007efc33fe18c0  vmovaps xmm3, [rsp+0x30]
00007efc33fe18c6  vmovaps xmm4, [rsp+0x40]
00007efc33fe18cc  vmovaps xmm5, [rsp+0x50]
00007efc33fe18d2  vmovaps xmm6, [rsp+0x60]
00007efc33fe18d8  vmovaps xmm7, [rsp+0x70]
00007efc33fe18de  vmovaps xmm8, [rsp+0x80]
00007efc33fe18e7  vmovaps xmm9, [rsp+0x90]
00007efc33fe18f0  vmovaps xmm10, [rsp+0xA0]
00007efc33fe18f9  vmovaps xmm11, [rsp+0xB0]
00007efc33fe1902  vmovaps xmm12, [rsp+0xC0]
00007efc33fe190b  vmovaps xmm13, [rsp+0xD0]
00007efc33fe1914  vmovaps xmm15, [rsp+0xE0]
00007efc33fe191d  add rsp, 0xF0
00007efc33fe1924  pop r11
00007efc33fe1926  pop r10
00007efc33fe1928  pop r9
00007efc33fe192a  pop r8
00007efc33fe192c  pop rsi
00007efc33fe192d  pop rdi
00007efc33fe192e  pop rdx
00007efc33fe192f  pop rcx
00007efc33fe1930  pop rax
00007efc33fe1931  add rsp, 0x08
00007efc33fe1935  jmp 0x00007EFC33FDC843
00007efc33fe193a  sub rsp, 0x08
00007efc33fe193e  push rax
00007efc33fe193f  push rcx
00007efc33fe1940  push rdx
00007efc33fe1941  push rdi
00007efc33fe1942  push rsi
00007efc33fe1943  push r8
00007efc33fe1945  push r9
00007efc33fe1947  push r10
00007efc33fe1949  push r11
00007efc33fe194b  sub rsp, 0xF0
00007efc33fe1952  vmovaps [rsp], xmm0
00007efc33fe1957  vmovaps [rsp+0x10], xmm2
00007efc33fe195d  vmovaps [rsp+0x20], xmm3
00007efc33fe1963  vmovaps [rsp+0x30], xmm4
00007efc33fe1969  vmovaps [rsp+0x40], xmm5
00007efc33fe196f  vmovaps [rsp+0x50], xmm6
00007efc33fe1975  vmovaps [rsp+0x60], xmm7
00007efc33fe197b  vmovaps [rsp+0x70], xmm8
00007efc33fe1981  vmovaps [rsp+0x80], xmm9
00007efc33fe198a  vmovaps [rsp+0x90], xmm10
00007efc33fe1993  vmovaps [rsp+0xA0], xmm11
00007efc33fe199c  vmovaps [rsp+0xB0], xmm12
00007efc33fe19a5  vmovaps [rsp+0xC0], xmm13
00007efc33fe19ae  vmovaps [rsp+0xD0], xmm14
00007efc33fe19b7  vmovaps [rsp+0xE0], xmm15
00007efc33fe19c0  sub rsp, 0x30
00007efc33fe19c4  movaps [rsp], xmm1
00007efc33fe19c8  movaps [rsp+0x10], xmm8
00007efc33fe19ce  movaps [rsp+0x20], xmm9
00007efc33fe19d4  lea rdi, [rsp]
00007efc33fe19d8  mov esi, 0x00
00007efc33fe19dd  mov rax, 0x5D9448894530
00007efc33fe19e7  call rax
00007efc33fe19e9  movaps xmm1, [rsp]
00007efc33fe19ed  add rsp, 0x30
00007efc33fe19f1  vmovaps xmm0, [rsp]
00007efc33fe19f6  vmovaps xmm2, [rsp+0x10]
00007efc33fe19fc  vmovaps xmm3, [rsp+0x20]
00007efc33fe1a02  vmovaps xmm4, [rsp+0x30]
00007efc33fe1a08  vmovaps xmm5, [rsp+0x40]
00007efc33fe1a0e  vmovaps xmm6, [rsp+0x50]
00007efc33fe1a14  vmovaps xmm7, [rsp+0x60]
00007efc33fe1a1a  vmovaps xmm8, [rsp+0x70]
00007efc33fe1a20  vmovaps xmm9, [rsp+0x80]
00007efc33fe1a29  vmovaps xmm10, [rsp+0x90]
00007efc33fe1a32  vmovaps xmm11, [rsp+0xA0]
00007efc33fe1a3b  vmovaps xmm12, [rsp+0xB0]
00007efc33fe1a44  vmovaps xmm13, [rsp+0xC0]
00007efc33fe1a4d  vmovaps xmm14, [rsp+0xD0]
00007efc33fe1a56  vmovaps xmm15, [rsp+0xE0]
00007efc33fe1a5f  add rsp, 0xF0
00007efc33fe1a66  pop r11
00007efc33fe1a68  pop r10
00007efc33fe1a6a  pop r9
00007efc33fe1a6c  pop r8
00007efc33fe1a6e  pop rsi
00007efc33fe1a6f  pop rdi
00007efc33fe1a70  pop rdx
00007efc33fe1a71  pop rcx
00007efc33fe1a72  pop rax
00007efc33fe1a73  add rsp, 0x08
00007efc33fe1a77  jmp 0x00007EFC33FDC865
00007efc33fe1a7c  call 0x00007EFC33EE5940
00007efc33fe1a81  jmp 0x00007EFC33FDC873
00007efc33fe1a86  call 0x00007EFC33E0C380
00007efc33fe1a8b  jmp 0x00007EFC33FDC87D
00007efc33fe1a90  call 0x00007EFC33E0D600
00007efc33fe1a95  jmp 0x00007EFC33FDC887
00007efc33fe1a9a  call 0x00007EFC33DFF540
00007efc33fe1a9f  jmp 0x00007EFC33FDC891
00007efc33fe1aa4  int3
00007efc33fe1aa5  nop [rax+rax*1], ax
00007efc33fe1aae  nop
00007efc33fe1ab0  mov rax, [r15+0xF8]
00007efc33fe1ab7  lea r14, [rax+0x140]
00007efc33fe1abe  mov r12, [r13+r14*1]
00007efc33fe1ac3  mov [r15+0xE8], r12
00007efc33fe1aca  lea r14, [rax+0x130]
00007efc33fe1ad1  mov r12, [r13+r14*1]
00007efc33fe1ad6  lea r14, [rax+0x138]
00007efc33fe1add  mov r11, [r13+r14*1]
00007efc33fe1ae2  movq xmm1, r12
00007efc33fe1ae7  movq xmm15, r11
00007efc33fe1aec  movq xmm1, xmm1
00007efc33fe1af0  movq xmm1, xmm1
00007efc33fe1af4  movaps [r15+0x1A0], xmm1
00007efc33fe1afc  movq xmm15, xmm15
00007efc33fe1b01  movq xmm15, xmm15
00007efc33fe1b06  movaps [r15+0x190], xmm15
00007efc33fe1b0e  lea r14, [rax+0x120]
00007efc33fe1b15  mov r12, [r13+r14*1]
00007efc33fe1b1a  lea r14, [rax+0x128]
00007efc33fe1b21  mov r11, [r13+r14*1]
00007efc33fe1b26  movq xmm1, r12
00007efc33fe1b2b  movq xmm15, r11
00007efc33fe1b30  movq xmm1, xmm1
00007efc33fe1b34  movq xmm1, xmm1
00007efc33fe1b38  movaps [r15+0x1C0], xmm1
00007efc33fe1b40  movq xmm15, xmm15
00007efc33fe1b45  movq xmm15, xmm15
00007efc33fe1b4a  movaps [r15+0x1B0], xmm15
00007efc33fe1b52  lea r14, [rax+0x110]
00007efc33fe1b59  mov r12, [r13+r14*1]
00007efc33fe1b5e  lea r14, [rax+0x118]
00007efc33fe1b65  mov r11, [r13+r14*1]
00007efc33fe1b6a  movq xmm1, r12
00007efc33fe1b6f  movq xmm15, r11
00007efc33fe1b74  movq xmm1, xmm1
00007efc33fe1b78  movq xmm1, xmm1
00007efc33fe1b7c  movaps [r15+0x1E0], xmm1
00007efc33fe1b84  movq xmm15, xmm15
00007efc33fe1b89  movq xmm15, xmm15
00007efc33fe1b8e  movaps [r15+0x1D0], xmm15
00007efc33fe1b96  lea r14, [rax+0x100]
00007efc33fe1b9d  mov r12, [r13+r14*1]
00007efc33fe1ba2  lea r14, [rax+0x108]
00007efc33fe1ba9  mov r11, [r13+r14*1]
00007efc33fe1bae  movq xmm1, r12
00007efc33fe1bb3  movq xmm15, r11
00007efc33fe1bb8  movq xmm1, xmm1
00007efc33fe1bbc  movq xmm1, xmm1
00007efc33fe1bc0  movaps [r15+0x200], xmm1
00007efc33fe1bc8  movq xmm15, xmm15
00007efc33fe1bcd  movq xmm15, xmm15
00007efc33fe1bd2  movaps [r15+0x1F0], xmm15
00007efc33fe1bda  mov qword ptr [r15+0x40], 0x430000
00007efc33fe1be2  mov r14d, 0x430510
00007efc33fe1be8  mov r12, [r13+r14*1]
00007efc33fe1bed  movq xmm1, r12
00007efc33fe1bf2  lea r14, [rax+0x150]
00007efc33fe1bf9  mov [r15+0xF8], r14
00007efc33fe1c00  mov rax, [r15+0x50]
00007efc33fe1c04  movups xmm15, [r13+rax*1]
00007efc33fe1c0a  movaps [r15+0x120], xmm15
00007efc33fe1c12  mov qword ptr [r15+0x48], 0x10
00007efc33fe1c1a  xor eax, eax
00007efc33fe1c1c  mov r14d, 0x10
00007efc33fe1c22  mov r12d, 0x200
00007efc33fe1c28  cmp r14, r12
00007efc33fe1c2b  cmc
00007efc33fe1c2c  lahf
00007efc33fe1c2d  seto al
00007efc33fe1c30  mov [r15+0x108], eax
00007efc33fe1c37  pextrq rax, xmm15, 0x01
00007efc33fe1c3e  movq xmm14, rax
00007efc33fe1c43  movaps [r15+0x130], xmm14
00007efc33fe1c4b  movq rax, xmm1
00007efc33fe1c50  movq r14, xmm15
00007efc33fe1c55  vmovq xmm1, rax
00007efc33fe1c5a  vmovq xmm15, r14
00007efc33fe1c5f  movaps xmm13, xmm1
00007efc33fe1c63  addsd xmm13, xmm15
00007efc33fe1c68  ucomisd xmm13, xmm13
00007efc33fe1c6d  jp 0x00007EFC33FE1D86
00007efc33fe1c73  movq xmm13, xmm13
00007efc33fe1c78  movq rax, xmm13
00007efc33fe1c7d  movq r14, xmm14
00007efc33fe1c82  vmovq xmm1, rax
00007efc33fe1c87  vmovq xmm15, r14
00007efc33fe1c8c  movaps xmm14, xmm1
00007efc33fe1c90  addsd xmm14, xmm15
00007efc33fe1c95  ucomisd xmm14, xmm14
00007efc33fe1c9a  jp 0x00007EFC33FE1DCE
00007efc33fe1ca0  movq xmm14, xmm14
00007efc33fe1ca5  movaps [r15+0x110], xmm14
00007efc33fe1cad  mov eax, [r15+0x108]
00007efc33fe1cb4  sahf
00007efc33fe1cb5  jnz 0x00007EFC33FE1CE7
00007efc33fe1cb7  cmp dword ptr [r15+0x318], 0x00
00007efc33fe1cbf  jz 0x00007EFC33FE1FE0
00007efc33fe1cc5  nop [rax+rax*1], ax
00007efc33fe1cce  nop [rax+rax*1], eax
00007efc33fe1cd6  mov eax, 0x410490
00007efc33fe1cdb  mov [r15+0x100], rax
00007efc33fe1ce2  jmp 0x00007EFC33DFE110
00007efc33fe1ce7  cmp dword ptr [r15+0x318], 0x00
00007efc33fe1cef  jz 0x00007EFC33FE1E20
00007efc33fe1cf5  nop [rax+rax*1], ax
00007efc33fe1cfe  nop [rax+rax*1], eax
00007efc33fe1d06  mov eax, 0x410474
00007efc33fe1d0b  mov [r15+0x100], rax
00007efc33fe1d12  jmp 0x00007EFC33DFE110
00007efc33fe1d17  int3
00007efc33fe1d18  call 0x00007EFC33EE27E0
00007efc33fe1d1d  jmp 0x00007EFC33FE1AC3
00007efc33fe1d22  call 0x00007EFC33EE27E0
00007efc33fe1d27  jmp 0x00007EFC33FE1AD6
00007efc33fe1d2c  call 0x00007EFC33EE1570
00007efc33fe1d31  jmp 0x00007EFC33FE1AE2
00007efc33fe1d36  call 0x00007EFC33EE27E0
00007efc33fe1d3b  jmp 0x00007EFC33FE1B1A
00007efc33fe1d40  call 0x00007EFC33EE1570
00007efc33fe1d45  jmp 0x00007EFC33FE1B26
00007efc33fe1d4a  call 0x00007EFC33EE27E0
00007efc33fe1d4f  jmp 0x00007EFC33FE1B5E
00007efc33fe1d54  call 0x00007EFC33EE1570
00007efc33fe1d59  jmp 0x00007EFC33FE1B6A
00007efc33fe1d5e  call 0x00007EFC33EE27E0
00007efc33fe1d63  jmp 0x00007EFC33FE1BA2
00007efc33fe1d68  call 0x00007EFC33EE1570
00007efc33fe1d6d  jmp 0x00007EFC33FE1BAE
00007efc33fe1d72  call 0x00007EFC33EE27E0
00007efc33fe1d77  jmp 0x00007EFC33FE1BED
00007efc33fe1d7c  call 0x00007EFC33E0E760
00007efc33fe1d81  jmp 0x00007EFC33FE1C0A
00007efc33fe1d86  ucomisd xmm1, xmm15
00007efc33fe1d8b  jp 0x00007EFC33FE1D9A
00007efc33fe1d8d  movaps xmm13, [0x00007EFC33BFE060]
00007efc33fe1d95  jmp 0x00007EFC33FE1C73
00007efc33fe1d9a  vxorps xmm0, xmm1, xmm15
00007efc33fe1d9f  pextrw eax, xmm0, 0x03
00007efc33fe1da4  and eax, 0x7FF8
00007efc33fe1da9  cmp eax, 0x08
00007efc33fe1dac  jnz 0x00007EFC33FE1C73
00007efc33fe1db2  movq rax, xmm15
00007efc33fe1db7  shl rax, 0x0D
00007efc33fe1dbb  jbe 0x00007EFC33FE1C73
00007efc33fe1dc1  vorps xmm13, xmm15, [0x00007EFC33BFE070]
00007efc33fe1dc9  jmp 0x00007EFC33FE1C73
00007efc33fe1dce  ucomisd xmm1, xmm15
00007efc33fe1dd3  jp 0x00007EFC33FE1DE2
00007efc33fe1dd5  movaps xmm14, [0x00007EFC33BFE060]
00007efc33fe1ddd  jmp 0x00007EFC33FE1CA0
00007efc33fe1de2  vxorps xmm0, xmm1, xmm15
00007efc33fe1de7  pextrw eax, xmm0, 0x03
00007efc33fe1dec  and eax, 0x7FF8
00007efc33fe1df1  cmp eax, 0x08
00007efc33fe1df4  jnz 0x00007EFC33FE1CA0
00007efc33fe1dfa  movq rax, xmm15
00007efc33fe1dff  shl rax, 0x0D
00007efc33fe1e03  jbe 0x00007EFC33FE1CA0
00007efc33fe1e09  vorps xmm14, xmm15, [0x00007EFC33BFE070]
00007efc33fe1e11  jmp 0x00007EFC33FE1CA0
00007efc33fe1e16  int3
00007efc33fe1e17  nop [rax+rax*1], ax
00007efc33fe1e20  mov rax, [r15+0x48]
00007efc33fe1e24  mov r14, [r15+0x50]
00007efc33fe1e28  lea r12, [r14+rax*1]
00007efc33fe1e2c  movups xmm1, [r13+r12*1]
00007efc33fe1e32  movaps [r15+0x120], xmm1
00007efc33fe1e3a  lea r14, [rax+0x10]
00007efc33fe1e3e  mov [r15+0x48], r14
00007efc33fe1e42  xor eax, eax
00007efc33fe1e44  mov r12d, 0x200
00007efc33fe1e4a  cmp r14, r12
00007efc33fe1e4d  cmc
00007efc33fe1e4e  lahf
00007efc33fe1e4f  seto al
00007efc33fe1e52  mov [r15+0x108], eax
00007efc33fe1e59  pextrq rax, xmm1, 0x01
00007efc33fe1e60  movq xmm15, rax
00007efc33fe1e65  movaps [r15+0x130], xmm15
00007efc33fe1e6d  movaps xmm14, [r15+0x110]
00007efc33fe1e75  movq rax, xmm14
00007efc33fe1e7a  movq r14, xmm1
00007efc33fe1e7f  vmovq xmm1, rax
00007efc33fe1e84  vmovq xmm14, r14
00007efc33fe1e89  movaps xmm13, xmm1
00007efc33fe1e8d  addsd xmm13, xmm14
00007efc33fe1e92  ucomisd xmm13, xmm13
00007efc33fe1e97  jp 0x00007EFC33FE1F4C
00007efc33fe1e9d  movq xmm13, xmm13
00007efc33fe1ea2  movq rax, xmm13
00007efc33fe1ea7  movq r14, xmm15
00007efc33fe1eac  vmovq xmm1, rax
00007efc33fe1eb1  vmovq xmm15, r14
00007efc33fe1eb6  movaps xmm14, xmm1
00007efc33fe1eba  addsd xmm14, xmm15
00007efc33fe1ebf  ucomisd xmm14, xmm14
00007efc33fe1ec4  jp 0x00007EFC33FE1F94
00007efc33fe1eca  movq xmm14, xmm14
00007efc33fe1ecf  movaps [r15+0x110], xmm14
00007efc33fe1ed7  mov eax, [r15+0x108]
00007efc33fe1ede  sahf
00007efc33fe1edf  jnz 0x00007EFC33FE1F11
00007efc33fe1ee1  cmp dword ptr [r15+0x318], 0x00
00007efc33fe1ee9  jz 0x00007EFC33FE1FE0
00007efc33fe1eef  nop [rax+rax*1], ax
00007efc33fe1ef8  nop [rax+rax*1], eax
00007efc33fe1f00  mov eax, 0x410490
00007efc33fe1f05  mov [r15+0x100], rax
00007efc33fe1f0c  jmp 0x00007EFC33DFE110
00007efc33fe1f11  cmp dword ptr [r15+0x318], 0x00
00007efc33fe1f19  jz 0x00007EFC33FE1E20
00007efc33fe1f1f  nop [rax+rax*1], ax
00007efc33fe1f28  nop [rax+rax*1], eax
00007efc33fe1f30  mov eax, 0x410474
00007efc33fe1f35  mov [r15+0x100], rax
00007efc33fe1f3c  jmp 0x00007EFC33DFE110
00007efc33fe1f41  int3
00007efc33fe1f42  call 0x00007EFC33EB52F0
00007efc33fe1f47  jmp 0x00007EFC33FE1E32
00007efc33fe1f4c  ucomisd xmm1, xmm14
00007efc33fe1f51  jp 0x00007EFC33FE1F60
00007efc33fe1f53  movaps xmm13, [0x00007EFC33BFE060]
00007efc33fe1f5b  jmp 0x00007EFC33FE1E9D
00007efc33fe1f60  vxorps xmm0, xmm1, xmm14
00007efc33fe1f65  pextrw eax, xmm0, 0x03
00007efc33fe1f6a  and eax, 0x7FF8
00007efc33fe1f6f  cmp eax, 0x08
00007efc33fe1f72  jnz 0x00007EFC33FE1E9D
00007efc33fe1f78  movq rax, xmm14
00007efc33fe1f7d  shl rax, 0x0D
00007efc33fe1f81  jbe 0x00007EFC33FE1E9D
00007efc33fe1f87  vorps xmm13, xmm14, [0x00007EFC33BFE070]
00007efc33fe1f8f  jmp 0x00007EFC33FE1E9D
00007efc33fe1f94  ucomisd xmm1, xmm15
00007efc33fe1f99  jp 0x00007EFC33FE1FA8
00007efc33fe1f9b  movaps xmm14, [0x00007EFC33BFE060]
00007efc33fe1fa3  jmp 0x00007EFC33FE1ECA
00007efc33fe1fa8  vxorps xmm0, xmm1, xmm15
00007efc33fe1fad  pextrw eax, xmm0, 0x03
00007efc33fe1fb2  and eax, 0x7FF8
00007efc33fe1fb7  cmp eax, 0x08
00007efc33fe1fba  jnz 0x00007EFC33FE1ECA
00007efc33fe1fc0  movq rax, xmm15
00007efc33fe1fc5  shl rax, 0x0D
00007efc33fe1fc9  jbe 0x00007EFC33FE1ECA
00007efc33fe1fcf  vorps xmm14, xmm15, [0x00007EFC33BFE070]
00007efc33fe1fd7  jmp 0x00007EFC33FE1ECA
00007efc33fe1fdc  int3
00007efc33fe1fdd  nop [rax], eax
00007efc33fe1fe0  mov rax, [r15+0x40]
00007efc33fe1fe4  lea r14, [rax+0x510]
00007efc33fe1feb  movaps xmm1, [r15+0x110]
00007efc33fe1ff3  movq rax, xmm1
00007efc33fe1ff8  mov [r13+r14*1], rax
00007efc33fe1ffd  mov rax, [r15+0xF0]
00007efc33fe2004  mov [r15+0x100], rax
00007efc33fe200b  jmp 0x00007EFC33FCE5C0
00007efc33fe2010  int3
00007efc33fe2011  call 0x00007EFC33ED5EB0
00007efc33fe2016  jmp 0x00007EFC33FE1FFD
00007efc33fe201b  int3
00007efc33fe201c  nop [rax], eax
00007efc33fe2020  mov qword ptr [r15+0x100], 0x04
00007efc33fe202b  mov esi, 0x00
00007efc33fe2030  mov edx, 0x09
00007efc33fe2035  mov rdi, 0x7FFCB9379B90
00007efc33fe203f  mov rax, 0x5D9448727970
00007efc33fe2049  call rax
00007efc33fe204b  cmp dword ptr [r15+0x318], 0x00
00007efc33fe2053  jnz 0x00007EFC33DFE110
00007efc33fe2059  jmp 0x00007EFC33DFE0A0
00007efc33fe205e  int3
00007efc33fe205f  int3
