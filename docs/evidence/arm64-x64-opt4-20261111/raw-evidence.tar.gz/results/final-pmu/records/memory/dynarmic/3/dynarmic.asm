0000741cbd7ce69b  nop [rax+rax*1], eax
0000741cbd7ce6a0  mov qword ptr [r15+0x20], 0x420060
0000741cbd7ce6a8  mov eax, 0x420060
0000741cbd7ce6ad  xor r14d, r14d
0000741cbd7ce6b0  mov [r13+rax*1], r14
0000741cbd7ce6b5  mov eax, 0x420060
0000741cbd7ce6ba  mov r14, [r13+rax*1]
0000741cbd7ce6bf  mov [r15+0x18], r14
0000741cbd7ce6c3  lea rax, [r14+0x03]
0000741cbd7ce6c7  mov [r15], rax
0000741cbd7ce6ca  xor eax, eax
0000741cbd7ce6cc  mov r14d, 0xB71B00
0000741cbd7ce6d2  mov r12d, 0x01
0000741cbd7ce6d8  sub r14, r12
0000741cbd7ce6db  cmc
0000741cbd7ce6dc  lahf
0000741cbd7ce6dd  seto al
0000741cbd7ce6e0  mov [r15+0x108], eax
0000741cbd7ce6e7  mov [r15+0x08], r14
0000741cbd7ce6eb  mov eax, [r15+0x108]
0000741cbd7ce6f2  sahf
0000741cbd7ce6f3  jnz 0x0000741CBD7CE725
0000741cbd7ce6f5  cmp dword ptr [r15+0x318], 0x00
0000741cbd7ce6fd  jz 0x0000741CBD7CE840
0000741cbd7ce703  nop [rax+rax*1], ax
0000741cbd7ce70c  nop [rax+rax*1], eax
0000741cbd7ce714  mov eax, 0x410050
0000741cbd7ce719  mov [r15+0x100], rax
0000741cbd7ce720  jmp 0x0000741CBD5FE110
0000741cbd7ce725  cmp dword ptr [r15+0x318], 0x00
0000741cbd7ce72d  jz 0x0000741CBD7CE770
0000741cbd7ce733  nop [rax+rax*1], ax
0000741cbd7ce73c  nop [rax+rax*1], eax
0000741cbd7ce744  mov eax, 0x41003C
0000741cbd7ce749  mov [r15+0x100], rax
0000741cbd7ce750  jmp 0x0000741CBD5FE110
0000741cbd7ce755  int3
0000741cbd7ce756  call 0x0000741CBD60E120
0000741cbd7ce75b  jmp 0x0000741CBD7CE6B5
0000741cbd7ce760  call 0x0000741CBD60DC20
0000741cbd7ce765  jmp 0x0000741CBD7CE6BF
0000741cbd7ce76a  int3
0000741cbd7ce76b  nop [rax+rax*1], eax
0000741cbd7ce770  mov rax, [r15+0x20]
0000741cbd7ce774  mov r14, [r15]
0000741cbd7ce777  mov [r13+rax*1], r14
0000741cbd7ce77c  mov r14, [r13+rax*1]
0000741cbd7ce781  mov [r15+0x18], r14
0000741cbd7ce785  lea rax, [r14+0x03]
0000741cbd7ce789  mov [r15], rax
0000741cbd7ce78c  mov rax, [r15+0x08]
0000741cbd7ce790  mov [rsp+0x10], rax
0000741cbd7ce795  xor eax, eax
0000741cbd7ce797  mov r14, [rsp+0x10]
0000741cbd7ce79c  mov r12d, 0x01
0000741cbd7ce7a2  sub r14, r12
0000741cbd7ce7a5  cmc
0000741cbd7ce7a6  lahf
0000741cbd7ce7a7  seto al
0000741cbd7ce7aa  mov [r15+0x108], eax
0000741cbd7ce7b1  mov [r15+0x08], r14
0000741cbd7ce7b5  mov eax, [r15+0x108]
0000741cbd7ce7bc  sahf
0000741cbd7ce7bd  jnz 0x0000741CBD7CE7EF
0000741cbd7ce7bf  cmp dword ptr [r15+0x318], 0x00
0000741cbd7ce7c7  jz 0x0000741CBD7CE840
0000741cbd7ce7cd  nop [rax+rax*1], ax
0000741cbd7ce7d6  nop [rax+rax*1], eax
0000741cbd7ce7de  mov eax, 0x410050
0000741cbd7ce7e3  mov [r15+0x100], rax
0000741cbd7ce7ea  jmp 0x0000741CBD5FE110
0000741cbd7ce7ef  cmp dword ptr [r15+0x318], 0x00
0000741cbd7ce7f7  jz 0x0000741CBD7CE770
0000741cbd7ce7fd  nop [rax+rax*1], ax
0000741cbd7ce806  nop [rax+rax*1], eax
0000741cbd7ce80e  mov eax, 0x41003C
0000741cbd7ce813  mov [r15+0x100], rax
0000741cbd7ce81a  jmp 0x0000741CBD5FE110
0000741cbd7ce81f  int3
0000741cbd7ce820  call 0x0000741CBD60E120
0000741cbd7ce825  jmp 0x0000741CBD7CE77C
0000741cbd7ce82a  call 0x0000741CBD60DC20
0000741cbd7ce82f  jmp 0x0000741CBD7CE781
0000741cbd7ce834  int3
0000741cbd7ce835  nop [rax+rax*1], ax
0000741cbd7ce83e  nop
0000741cbd7ce840  mov rax, [r15+0x20]
0000741cbd7ce844  mov r14, [r15]
0000741cbd7ce847  mov [r13+rax*1], r14
0000741cbd7ce84c  mov rax, [r15+0xF0]
0000741cbd7ce853  mov [r15+0x100], rax
0000741cbd7ce85a  jmp 0x0000741CBD7CE5C0
0000741cbd7ce85f  int3
0000741cbd7ce860  call 0x0000741CBD60E120
0000741cbd7ce865  jmp 0x0000741CBD7CE84C
0000741cbd7ce86a  int3
0000741cbd7ce86b  nop [rax+rax*1], eax
0000741cbd7ce870  mov qword ptr [r15+0x100], 0x04
0000741cbd7ce87b  mov esi, 0x00
0000741cbd7ce880  mov edx, 0x09
0000741cbd7ce885  mov rdi, 0x7FFE1F697640
0000741cbd7ce88f  mov rax, 0x5A4A7C0A5970
0000741cbd7ce899  call rax
0000741cbd7ce89b  cmp dword ptr [r15+0x318], 0x00
0000741cbd7ce8a3  jnz 0x0000741CBD5FE110
0000741cbd7ce8a9  jmp 0x0000741CBD5FE0A0
0000741cbd7ce8ae  int3
0000741cbd7ce8af  int3
