00007a83ed1ce69b  nop [rax+rax*1], eax
00007a83ed1ce6a0  mov qword ptr [r15+0x20], 0x420060
00007a83ed1ce6a8  mov eax, 0x420060
00007a83ed1ce6ad  xor r14d, r14d
00007a83ed1ce6b0  mov [r13+rax*1], r14
00007a83ed1ce6b5  mov eax, 0x420060
00007a83ed1ce6ba  mov r14, [r13+rax*1]
00007a83ed1ce6bf  mov [r15+0x18], r14
00007a83ed1ce6c3  lea rax, [r14+0x03]
00007a83ed1ce6c7  mov [r15], rax
00007a83ed1ce6ca  xor eax, eax
00007a83ed1ce6cc  mov r14d, 0xB71B00
00007a83ed1ce6d2  mov r12d, 0x01
00007a83ed1ce6d8  sub r14, r12
00007a83ed1ce6db  cmc
00007a83ed1ce6dc  lahf
00007a83ed1ce6dd  seto al
00007a83ed1ce6e0  mov [r15+0x108], eax
00007a83ed1ce6e7  mov [r15+0x08], r14
00007a83ed1ce6eb  mov eax, [r15+0x108]
00007a83ed1ce6f2  sahf
00007a83ed1ce6f3  jnz 0x00007A83ED1CE725
00007a83ed1ce6f5  cmp dword ptr [r15+0x318], 0x00
00007a83ed1ce6fd  jz 0x00007A83ED1CE840
00007a83ed1ce703  nop [rax+rax*1], ax
00007a83ed1ce70c  nop [rax+rax*1], eax
00007a83ed1ce714  mov eax, 0x410050
00007a83ed1ce719  mov [r15+0x100], rax
00007a83ed1ce720  jmp 0x00007A83ECFFE110
00007a83ed1ce725  cmp dword ptr [r15+0x318], 0x00
00007a83ed1ce72d  jz 0x00007A83ED1CE770
00007a83ed1ce733  nop [rax+rax*1], ax
00007a83ed1ce73c  nop [rax+rax*1], eax
00007a83ed1ce744  mov eax, 0x41003C
00007a83ed1ce749  mov [r15+0x100], rax
00007a83ed1ce750  jmp 0x00007A83ECFFE110
00007a83ed1ce755  int3
00007a83ed1ce756  call 0x00007A83ED00E120
00007a83ed1ce75b  jmp 0x00007A83ED1CE6B5
00007a83ed1ce760  call 0x00007A83ED00DC20
00007a83ed1ce765  jmp 0x00007A83ED1CE6BF
00007a83ed1ce76a  int3
00007a83ed1ce76b  nop [rax+rax*1], eax
00007a83ed1ce770  mov rax, [r15+0x20]
00007a83ed1ce774  mov r14, [r15]
00007a83ed1ce777  mov [r13+rax*1], r14
00007a83ed1ce77c  mov r14, [r13+rax*1]
00007a83ed1ce781  mov [r15+0x18], r14
00007a83ed1ce785  lea rax, [r14+0x03]
00007a83ed1ce789  mov [r15], rax
00007a83ed1ce78c  mov rax, [r15+0x08]
00007a83ed1ce790  mov [rsp+0x10], rax
00007a83ed1ce795  xor eax, eax
00007a83ed1ce797  mov r14, [rsp+0x10]
00007a83ed1ce79c  mov r12d, 0x01
00007a83ed1ce7a2  sub r14, r12
00007a83ed1ce7a5  cmc
00007a83ed1ce7a6  lahf
00007a83ed1ce7a7  seto al
00007a83ed1ce7aa  mov [r15+0x108], eax
00007a83ed1ce7b1  mov [r15+0x08], r14
00007a83ed1ce7b5  mov eax, [r15+0x108]
00007a83ed1ce7bc  sahf
00007a83ed1ce7bd  jnz 0x00007A83ED1CE7EF
00007a83ed1ce7bf  cmp dword ptr [r15+0x318], 0x00
00007a83ed1ce7c7  jz 0x00007A83ED1CE840
00007a83ed1ce7cd  nop [rax+rax*1], ax
00007a83ed1ce7d6  nop [rax+rax*1], eax
00007a83ed1ce7de  mov eax, 0x410050
00007a83ed1ce7e3  mov [r15+0x100], rax
00007a83ed1ce7ea  jmp 0x00007A83ECFFE110
00007a83ed1ce7ef  cmp dword ptr [r15+0x318], 0x00
00007a83ed1ce7f7  jz 0x00007A83ED1CE770
00007a83ed1ce7fd  nop [rax+rax*1], ax
00007a83ed1ce806  nop [rax+rax*1], eax
00007a83ed1ce80e  mov eax, 0x41003C
00007a83ed1ce813  mov [r15+0x100], rax
00007a83ed1ce81a  jmp 0x00007A83ECFFE110
00007a83ed1ce81f  int3
00007a83ed1ce820  call 0x00007A83ED00E120
00007a83ed1ce825  jmp 0x00007A83ED1CE77C
00007a83ed1ce82a  call 0x00007A83ED00DC20
00007a83ed1ce82f  jmp 0x00007A83ED1CE781
00007a83ed1ce834  int3
00007a83ed1ce835  nop [rax+rax*1], ax
00007a83ed1ce83e  nop
00007a83ed1ce840  mov rax, [r15+0x20]
00007a83ed1ce844  mov r14, [r15]
00007a83ed1ce847  mov [r13+rax*1], r14
00007a83ed1ce84c  mov rax, [r15+0xF0]
00007a83ed1ce853  mov [r15+0x100], rax
00007a83ed1ce85a  jmp 0x00007A83ED1CE5C0
00007a83ed1ce85f  int3
00007a83ed1ce860  call 0x00007A83ED00E120
00007a83ed1ce865  jmp 0x00007A83ED1CE84C
00007a83ed1ce86a  int3
00007a83ed1ce86b  nop [rax+rax*1], eax
00007a83ed1ce870  mov qword ptr [r15+0x100], 0x04
00007a83ed1ce87b  mov esi, 0x00
00007a83ed1ce880  mov edx, 0x09
00007a83ed1ce885  mov rdi, 0x7FFD34D5F620
00007a83ed1ce88f  mov rax, 0x5C67AD92D970
00007a83ed1ce899  call rax
00007a83ed1ce89b  cmp dword ptr [r15+0x318], 0x00
00007a83ed1ce8a3  jnz 0x00007A83ECFFE110
00007a83ed1ce8a9  jmp 0x00007A83ECFFE0A0
00007a83ed1ce8ae  int3
00007a83ed1ce8af  int3
