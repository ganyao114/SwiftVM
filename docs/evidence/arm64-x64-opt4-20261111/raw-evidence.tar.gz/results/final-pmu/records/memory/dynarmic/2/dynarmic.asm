000073c30fdce69b  nop [rax+rax*1], eax
000073c30fdce6a0  mov qword ptr [r15+0x20], 0x420060
000073c30fdce6a8  mov eax, 0x420060
000073c30fdce6ad  xor r14d, r14d
000073c30fdce6b0  mov [r13+rax*1], r14
000073c30fdce6b5  mov eax, 0x420060
000073c30fdce6ba  mov r14, [r13+rax*1]
000073c30fdce6bf  mov [r15+0x18], r14
000073c30fdce6c3  lea rax, [r14+0x03]
000073c30fdce6c7  mov [r15], rax
000073c30fdce6ca  xor eax, eax
000073c30fdce6cc  mov r14d, 0xB71B00
000073c30fdce6d2  mov r12d, 0x01
000073c30fdce6d8  sub r14, r12
000073c30fdce6db  cmc
000073c30fdce6dc  lahf
000073c30fdce6dd  seto al
000073c30fdce6e0  mov [r15+0x108], eax
000073c30fdce6e7  mov [r15+0x08], r14
000073c30fdce6eb  mov eax, [r15+0x108]
000073c30fdce6f2  sahf
000073c30fdce6f3  jnz 0x000073C30FDCE725
000073c30fdce6f5  cmp dword ptr [r15+0x318], 0x00
000073c30fdce6fd  jz 0x000073C30FDCE840
000073c30fdce703  nop [rax+rax*1], ax
000073c30fdce70c  nop [rax+rax*1], eax
000073c30fdce714  mov eax, 0x410050
000073c30fdce719  mov [r15+0x100], rax
000073c30fdce720  jmp 0x000073C30FBFE110
000073c30fdce725  cmp dword ptr [r15+0x318], 0x00
000073c30fdce72d  jz 0x000073C30FDCE770
000073c30fdce733  nop [rax+rax*1], ax
000073c30fdce73c  nop [rax+rax*1], eax
000073c30fdce744  mov eax, 0x41003C
000073c30fdce749  mov [r15+0x100], rax
000073c30fdce750  jmp 0x000073C30FBFE110
000073c30fdce755  int3
000073c30fdce756  call 0x000073C30FC0E120
000073c30fdce75b  jmp 0x000073C30FDCE6B5
000073c30fdce760  call 0x000073C30FC0DC20
000073c30fdce765  jmp 0x000073C30FDCE6BF
000073c30fdce76a  int3
000073c30fdce76b  nop [rax+rax*1], eax
000073c30fdce770  mov rax, [r15+0x20]
000073c30fdce774  mov r14, [r15]
000073c30fdce777  mov [r13+rax*1], r14
000073c30fdce77c  mov r14, [r13+rax*1]
000073c30fdce781  mov [r15+0x18], r14
000073c30fdce785  lea rax, [r14+0x03]
000073c30fdce789  mov [r15], rax
000073c30fdce78c  mov rax, [r15+0x08]
000073c30fdce790  mov [rsp+0x10], rax
000073c30fdce795  xor eax, eax
000073c30fdce797  mov r14, [rsp+0x10]
000073c30fdce79c  mov r12d, 0x01
000073c30fdce7a2  sub r14, r12
000073c30fdce7a5  cmc
000073c30fdce7a6  lahf
000073c30fdce7a7  seto al
000073c30fdce7aa  mov [r15+0x108], eax
000073c30fdce7b1  mov [r15+0x08], r14
000073c30fdce7b5  mov eax, [r15+0x108]
000073c30fdce7bc  sahf
000073c30fdce7bd  jnz 0x000073C30FDCE7EF
000073c30fdce7bf  cmp dword ptr [r15+0x318], 0x00
000073c30fdce7c7  jz 0x000073C30FDCE840
000073c30fdce7cd  nop [rax+rax*1], ax
000073c30fdce7d6  nop [rax+rax*1], eax
000073c30fdce7de  mov eax, 0x410050
000073c30fdce7e3  mov [r15+0x100], rax
000073c30fdce7ea  jmp 0x000073C30FBFE110
000073c30fdce7ef  cmp dword ptr [r15+0x318], 0x00
000073c30fdce7f7  jz 0x000073C30FDCE770
000073c30fdce7fd  nop [rax+rax*1], ax
000073c30fdce806  nop [rax+rax*1], eax
000073c30fdce80e  mov eax, 0x41003C
000073c30fdce813  mov [r15+0x100], rax
000073c30fdce81a  jmp 0x000073C30FBFE110
000073c30fdce81f  int3
000073c30fdce820  call 0x000073C30FC0E120
000073c30fdce825  jmp 0x000073C30FDCE77C
000073c30fdce82a  call 0x000073C30FC0DC20
000073c30fdce82f  jmp 0x000073C30FDCE781
000073c30fdce834  int3
000073c30fdce835  nop [rax+rax*1], ax
000073c30fdce83e  nop
000073c30fdce840  mov rax, [r15+0x20]
000073c30fdce844  mov r14, [r15]
000073c30fdce847  mov [r13+rax*1], r14
000073c30fdce84c  mov rax, [r15+0xF0]
000073c30fdce853  mov [r15+0x100], rax
000073c30fdce85a  jmp 0x000073C30FDCE5C0
000073c30fdce85f  int3
000073c30fdce860  call 0x000073C30FC0E120
000073c30fdce865  jmp 0x000073C30FDCE84C
000073c30fdce86a  int3
000073c30fdce86b  nop [rax+rax*1], eax
000073c30fdce870  mov qword ptr [r15+0x100], 0x04
000073c30fdce87b  mov esi, 0x00
000073c30fdce880  mov edx, 0x09
000073c30fdce885  mov rdi, 0x7FFC021F9A60
000073c30fdce88f  mov rax, 0x642B81E2C970
000073c30fdce899  call rax
000073c30fdce89b  cmp dword ptr [r15+0x318], 0x00
000073c30fdce8a3  jnz 0x000073C30FBFE110
000073c30fdce8a9  jmp 0x000073C30FBFE0A0
000073c30fdce8ae  int3
000073c30fdce8af  int3
