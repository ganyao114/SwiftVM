00007eeb7abce69b  nop [rax+rax*1], eax
00007eeb7abce6a0  mov qword ptr [r15+0x20], 0x4200B0
00007eeb7abce6a8  mov eax, 0x4200B0
00007eeb7abce6ad  xor r14d, r14d
00007eeb7abce6b0  mov [r13+rax*1], r14
00007eeb7abce6b5  mov eax, 0x4200B0
00007eeb7abce6ba  mov r14, [r13+rax*1]
00007eeb7abce6bf  lea rax, [r14+0x03]
00007eeb7abce6c3  mov r14d, 0x4200B0
00007eeb7abce6c9  mov [r13+r14*1], rax
00007eeb7abce6ce  mov eax, 0x4200B0
00007eeb7abce6d3  mov r14, [r13+rax*1]
00007eeb7abce6d8  lea rax, [r14+0x03]
00007eeb7abce6dc  mov r14d, 0x4200B0
00007eeb7abce6e2  mov [r13+r14*1], rax
00007eeb7abce6e7  mov eax, 0x4200B0
00007eeb7abce6ec  mov r14, [r13+rax*1]
00007eeb7abce6f1  lea rax, [r14+0x03]
00007eeb7abce6f5  mov r14d, 0x4200B0
00007eeb7abce6fb  mov [r13+r14*1], rax
00007eeb7abce700  mov eax, 0x4200B0
00007eeb7abce705  mov r14, [r13+rax*1]
00007eeb7abce70a  lea rax, [r14+0x03]
00007eeb7abce70e  mov r14d, 0x4200B0
00007eeb7abce714  mov [r13+r14*1], rax
00007eeb7abce719  mov eax, 0x4200B0
00007eeb7abce71e  mov r14, [r13+rax*1]
00007eeb7abce723  lea rax, [r14+0x03]
00007eeb7abce727  mov r14d, 0x4200B0
00007eeb7abce72d  mov [r13+r14*1], rax
00007eeb7abce732  mov eax, 0x4200B0
00007eeb7abce737  mov r14, [r13+rax*1]
00007eeb7abce73c  lea rax, [r14+0x03]
00007eeb7abce740  mov r14d, 0x4200B0
00007eeb7abce746  mov [r13+r14*1], rax
00007eeb7abce74b  mov eax, 0x4200B0
00007eeb7abce750  mov r14, [r13+rax*1]
00007eeb7abce755  lea rax, [r14+0x03]
00007eeb7abce759  mov r14d, 0x4200B0
00007eeb7abce75f  mov [r13+r14*1], rax
00007eeb7abce764  mov eax, 0x4200B0
00007eeb7abce769  mov r14, [r13+rax*1]
00007eeb7abce76e  mov [r15+0x18], r14
00007eeb7abce772  lea rax, [r14+0x03]
00007eeb7abce776  mov [r15], rax
00007eeb7abce779  xor eax, eax
00007eeb7abce77b  mov r14d, 0x16E360
00007eeb7abce781  mov r12d, 0x01
00007eeb7abce787  sub r14, r12
00007eeb7abce78a  cmc
00007eeb7abce78b  lahf
00007eeb7abce78c  seto al
00007eeb7abce78f  mov [r15+0x108], eax
00007eeb7abce796  mov [r15+0x08], r14
00007eeb7abce79a  mov eax, [r15+0x108]
00007eeb7abce7a1  sahf
00007eeb7abce7a2  jnz 0x00007EEB7ABCE7D4
00007eeb7abce7a4  cmp dword ptr [r15+0x318], 0x00
00007eeb7abce7ac  jz 0x00007EEB7ABCEA70
00007eeb7abce7b2  nop [rax+rax*1], ax
00007eeb7abce7bb  nop [rax+rax*1], eax
00007eeb7abce7c3  mov eax, 0x4100A4
00007eeb7abce7c8  mov [r15+0x100], rax
00007eeb7abce7cf  jmp 0x00007EEB7A9FE110
00007eeb7abce7d4  cmp dword ptr [r15+0x318], 0x00
00007eeb7abce7dc  jz 0x00007EEB7ABCE8B0
00007eeb7abce7e2  nop [rax+rax*1], ax
00007eeb7abce7eb  nop [rax+rax*1], eax
00007eeb7abce7f3  mov eax, 0x41003C
00007eeb7abce7f8  mov [r15+0x100], rax
00007eeb7abce7ff  jmp 0x00007EEB7A9FE110
00007eeb7abce804  int3
00007eeb7abce805  call 0x00007EEB7AA0E120
00007eeb7abce80a  jmp 0x00007EEB7ABCE6B5
00007eeb7abce80f  call 0x00007EEB7AA0DC20
00007eeb7abce814  jmp 0x00007EEB7ABCE6BF
00007eeb7abce819  call 0x00007EEB7AAD5EB0
00007eeb7abce81e  jmp 0x00007EEB7ABCE6CE
00007eeb7abce823  call 0x00007EEB7AA0DC20
00007eeb7abce828  jmp 0x00007EEB7ABCE6D8
00007eeb7abce82d  call 0x00007EEB7AAD5EB0
00007eeb7abce832  jmp 0x00007EEB7ABCE6E7
00007eeb7abce837  call 0x00007EEB7AA0DC20
00007eeb7abce83c  jmp 0x00007EEB7ABCE6F1
00007eeb7abce841  call 0x00007EEB7AAD5EB0
00007eeb7abce846  jmp 0x00007EEB7ABCE700
00007eeb7abce84b  call 0x00007EEB7AA0DC20
00007eeb7abce850  jmp 0x00007EEB7ABCE70A
00007eeb7abce855  call 0x00007EEB7AAD5EB0
00007eeb7abce85a  jmp 0x00007EEB7ABCE719
00007eeb7abce85f  call 0x00007EEB7AA0DC20
00007eeb7abce864  jmp 0x00007EEB7ABCE723
00007eeb7abce869  call 0x00007EEB7AAD5EB0
00007eeb7abce86e  jmp 0x00007EEB7ABCE732
00007eeb7abce873  call 0x00007EEB7AA0DC20
00007eeb7abce878  jmp 0x00007EEB7ABCE73C
00007eeb7abce87d  call 0x00007EEB7AAD5EB0
00007eeb7abce882  jmp 0x00007EEB7ABCE74B
00007eeb7abce887  call 0x00007EEB7AA0DC20
00007eeb7abce88c  jmp 0x00007EEB7ABCE755
00007eeb7abce891  call 0x00007EEB7AAD5EB0
00007eeb7abce896  jmp 0x00007EEB7ABCE764
00007eeb7abce89b  call 0x00007EEB7AA0DC20
00007eeb7abce8a0  jmp 0x00007EEB7ABCE76E
00007eeb7abce8a5  int3
00007eeb7abce8a6  nop [rax+rax*1], ax
00007eeb7abce8af  nop
00007eeb7abce8b0  mov rax, [r15+0x20]
00007eeb7abce8b4  mov r14, [r15]
00007eeb7abce8b7  mov [r13+rax*1], r14
00007eeb7abce8bc  mov r14, [r13+rax*1]
00007eeb7abce8c1  lea r12, [r14+0x03]
00007eeb7abce8c5  mov [r13+rax*1], r12
00007eeb7abce8ca  mov r14, [r13+rax*1]
00007eeb7abce8cf  lea r12, [r14+0x03]
00007eeb7abce8d3  mov [r13+rax*1], r12
00007eeb7abce8d8  mov r14, [r13+rax*1]
00007eeb7abce8dd  lea r12, [r14+0x03]
00007eeb7abce8e1  mov [r13+rax*1], r12
00007eeb7abce8e6  mov r14, [r13+rax*1]
00007eeb7abce8eb  lea r12, [r14+0x03]
00007eeb7abce8ef  mov [r13+rax*1], r12
00007eeb7abce8f4  mov r14, [r13+rax*1]
00007eeb7abce8f9  lea r12, [r14+0x03]
00007eeb7abce8fd  mov [r13+rax*1], r12
00007eeb7abce902  mov r14, [r13+rax*1]
00007eeb7abce907  lea r12, [r14+0x03]
00007eeb7abce90b  mov [r13+rax*1], r12
00007eeb7abce910  mov r14, [r13+rax*1]
00007eeb7abce915  lea r12, [r14+0x03]
00007eeb7abce919  mov [r13+rax*1], r12
00007eeb7abce91e  mov r14, [r13+rax*1]
00007eeb7abce923  mov [r15+0x18], r14
00007eeb7abce927  lea rax, [r14+0x03]
00007eeb7abce92b  mov [r15], rax
00007eeb7abce92e  mov rax, [r15+0x08]
00007eeb7abce932  mov [rsp+0x10], rax
00007eeb7abce937  xor eax, eax
00007eeb7abce939  mov r14, [rsp+0x10]
00007eeb7abce93e  mov r12d, 0x01
00007eeb7abce944  sub r14, r12
00007eeb7abce947  cmc
00007eeb7abce948  lahf
00007eeb7abce949  seto al
00007eeb7abce94c  mov [r15+0x108], eax
00007eeb7abce953  mov [r15+0x08], r14
00007eeb7abce957  mov eax, [r15+0x108]
00007eeb7abce95e  sahf
00007eeb7abce95f  jnz 0x00007EEB7ABCE991
00007eeb7abce961  cmp dword ptr [r15+0x318], 0x00
00007eeb7abce969  jz 0x00007EEB7ABCEA70
00007eeb7abce96f  nop [rax+rax*1], ax
00007eeb7abce978  nop [rax+rax*1], eax
00007eeb7abce980  mov eax, 0x4100A4
00007eeb7abce985  mov [r15+0x100], rax
00007eeb7abce98c  jmp 0x00007EEB7A9FE110
00007eeb7abce991  cmp dword ptr [r15+0x318], 0x00
00007eeb7abce999  jz 0x00007EEB7ABCE8B0
00007eeb7abce99f  nop [rax+rax*1], ax
00007eeb7abce9a8  nop [rax+rax*1], eax
00007eeb7abce9b0  mov eax, 0x41003C
00007eeb7abce9b5  mov [r15+0x100], rax
00007eeb7abce9bc  jmp 0x00007EEB7A9FE110
00007eeb7abce9c1  int3
00007eeb7abce9c2  call 0x00007EEB7AA0E120
00007eeb7abce9c7  jmp 0x00007EEB7ABCE8BC
00007eeb7abce9cc  call 0x00007EEB7AA0DC20
00007eeb7abce9d1  jmp 0x00007EEB7ABCE8C1
00007eeb7abce9d6  call 0x00007EEB7AA0BC20
00007eeb7abce9db  jmp 0x00007EEB7ABCE8CA
00007eeb7abce9e0  call 0x00007EEB7AA0DC20
00007eeb7abce9e5  jmp 0x00007EEB7ABCE8CF
00007eeb7abce9ea  call 0x00007EEB7AA0BC20
00007eeb7abce9ef  jmp 0x00007EEB7ABCE8D8
00007eeb7abce9f4  call 0x00007EEB7AA0DC20
00007eeb7abce9f9  jmp 0x00007EEB7ABCE8DD
00007eeb7abce9fe  call 0x00007EEB7AA0BC20
00007eeb7abcea03  jmp 0x00007EEB7ABCE8E6
00007eeb7abcea08  call 0x00007EEB7AA0DC20
00007eeb7abcea0d  jmp 0x00007EEB7ABCE8EB
00007eeb7abcea12  call 0x00007EEB7AA0BC20
00007eeb7abcea17  jmp 0x00007EEB7ABCE8F4
00007eeb7abcea1c  call 0x00007EEB7AA0DC20
00007eeb7abcea21  jmp 0x00007EEB7ABCE8F9
00007eeb7abcea26  call 0x00007EEB7AA0BC20
00007eeb7abcea2b  jmp 0x00007EEB7ABCE902
00007eeb7abcea30  call 0x00007EEB7AA0DC20
00007eeb7abcea35  jmp 0x00007EEB7ABCE907
00007eeb7abcea3a  call 0x00007EEB7AA0BC20
00007eeb7abcea3f  jmp 0x00007EEB7ABCE910
00007eeb7abcea44  call 0x00007EEB7AA0DC20
00007eeb7abcea49  jmp 0x00007EEB7ABCE915
00007eeb7abcea4e  call 0x00007EEB7AA0BC20
00007eeb7abcea53  jmp 0x00007EEB7ABCE91E
00007eeb7abcea58  call 0x00007EEB7AA0DC20
00007eeb7abcea5d  jmp 0x00007EEB7ABCE923
00007eeb7abcea62  int3
00007eeb7abcea63  nop [rax+rax*1], ax
00007eeb7abcea6c  nop [rax], eax
00007eeb7abcea70  mov rax, [r15+0x20]
00007eeb7abcea74  mov r14, [r15]
00007eeb7abcea77  mov [r13+rax*1], r14
00007eeb7abcea7c  mov rax, [r15+0xF0]
00007eeb7abcea83  mov [r15+0x100], rax
00007eeb7abcea8a  jmp 0x00007EEB7ABCE5C0
00007eeb7abcea8f  int3
00007eeb7abcea90  call 0x00007EEB7AA0E120
00007eeb7abcea95  jmp 0x00007EEB7ABCEA7C
00007eeb7abcea9a  int3
00007eeb7abcea9b  nop [rax+rax*1], eax
00007eeb7abceaa0  mov qword ptr [r15+0x100], 0x04
00007eeb7abceaab  mov esi, 0x00
00007eeb7abceab0  mov edx, 0x09
00007eeb7abceab5  mov rdi, 0x7FFD7204B310
00007eeb7abceabf  mov rax, 0x5900E31E5970
00007eeb7abceac9  call rax
00007eeb7abceacb  cmp dword ptr [r15+0x318], 0x00
00007eeb7abcead3  jnz 0x00007EEB7A9FE110
00007eeb7abcead9  jmp 0x00007EEB7A9FE0A0
00007eeb7abceade  int3
00007eeb7abceadf  int3
