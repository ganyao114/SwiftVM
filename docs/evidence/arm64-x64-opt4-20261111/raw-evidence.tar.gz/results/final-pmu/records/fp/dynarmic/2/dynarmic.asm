000071bde6dce69b  nop [rax+rax*1], eax
000071bde6dce6a0  mov qword ptr [r15+0x20], 0x420060
000071bde6dce6a8  mov qword ptr [r15], 0x00
000071bde6dce6af  vmovaps xmm1, [0x000071BDE69FE010]
000071bde6dce6b7  movq xmm1, xmm1
000071bde6dce6bb  vmovaps xmm15, [0x000071BDE69FE020]
000071bde6dce6c3  movq xmm15, xmm15
000071bde6dce6c8  movaps [r15+0x120], xmm15
000071bde6dce6d0  movq rax, xmm1
000071bde6dce6d5  movq r14, xmm15
000071bde6dce6da  vmovq xmm1, rax
000071bde6dce6df  vmovq xmm15, r14
000071bde6dce6e4  movaps xmm14, xmm1
000071bde6dce6e8  addsd xmm14, xmm15
000071bde6dce6ed  ucomisd xmm14, xmm14
000071bde6dce6f2  jp 0x000071BDE6DCE791
000071bde6dce6f8  movq xmm14, xmm14
000071bde6dce6fd  movaps [r15+0x110], xmm14
000071bde6dce705  xor eax, eax
000071bde6dce707  mov r14d, 0xF4240
000071bde6dce70d  mov r12d, 0x01
000071bde6dce713  sub r14, r12
000071bde6dce716  cmc
000071bde6dce717  lahf
000071bde6dce718  seto al
000071bde6dce71b  mov [r15+0x108], eax
000071bde6dce722  mov [r15+0x08], r14
000071bde6dce726  mov eax, [r15+0x108]
000071bde6dce72d  sahf
000071bde6dce72e  jnz 0x000071BDE6DCE760
000071bde6dce730  cmp dword ptr [r15+0x318], 0x00
000071bde6dce738  jz 0x000071BDE6DCE910
000071bde6dce73e  nop [rax+rax*1], ax
000071bde6dce747  nop [rax+rax*1], eax
000071bde6dce74f  mov eax, 0x410050
000071bde6dce754  mov [r15+0x100], rax
000071bde6dce75b  jmp 0x000071BDE6BFE110
000071bde6dce760  cmp dword ptr [r15+0x318], 0x00
000071bde6dce768  jz 0x000071BDE6DCE7E0
000071bde6dce76e  nop [rax+rax*1], ax
000071bde6dce777  nop [rax+rax*1], eax
000071bde6dce77f  mov eax, 0x410044
000071bde6dce784  mov [r15+0x100], rax
000071bde6dce78b  jmp 0x000071BDE6BFE110
000071bde6dce790  int3
000071bde6dce791  ucomisd xmm1, xmm15
000071bde6dce796  jp 0x000071BDE6DCE7A5
000071bde6dce798  movaps xmm14, [0x000071BDE69FE030]
000071bde6dce7a0  jmp 0x000071BDE6DCE6F8
000071bde6dce7a5  vxorps xmm0, xmm1, xmm15
000071bde6dce7aa  pextrw eax, xmm0, 0x03
000071bde6dce7af  and eax, 0x7FF8
000071bde6dce7b4  cmp eax, 0x08
000071bde6dce7b7  jnz 0x000071BDE6DCE6F8
000071bde6dce7bd  movq rax, xmm15
000071bde6dce7c2  shl rax, 0x0D
000071bde6dce7c6  jbe 0x000071BDE6DCE6F8
000071bde6dce7cc  vorps xmm14, xmm15, [0x000071BDE69FE040]
000071bde6dce7d4  jmp 0x000071BDE6DCE6F8
000071bde6dce7d9  int3
000071bde6dce7da  nop [rax+rax*1], ax
000071bde6dce7e0  movaps xmm1, [r15+0x110]
000071bde6dce7e8  movq rax, xmm1
000071bde6dce7ed  movaps xmm1, [r15+0x120]
000071bde6dce7f5  movq r14, xmm1
000071bde6dce7fa  vmovq xmm1, rax
000071bde6dce7ff  vmovq xmm15, r14
000071bde6dce804  movaps xmm14, xmm1
000071bde6dce808  addsd xmm14, xmm15
000071bde6dce80d  ucomisd xmm14, xmm14
000071bde6dce812  jp 0x000071BDE6DCE8B9
000071bde6dce818  movq xmm14, xmm14
000071bde6dce81d  movaps [r15+0x110], xmm14
000071bde6dce825  mov rax, [r15+0x08]
000071bde6dce829  mov [rsp+0x10], rax
000071bde6dce82e  xor eax, eax
000071bde6dce830  mov r14, [rsp+0x10]
000071bde6dce835  mov r12d, 0x01
000071bde6dce83b  sub r14, r12
000071bde6dce83e  cmc
000071bde6dce83f  lahf
000071bde6dce840  seto al
000071bde6dce843  mov [r15+0x108], eax
000071bde6dce84a  mov [r15+0x08], r14
000071bde6dce84e  mov eax, [r15+0x108]
000071bde6dce855  sahf
000071bde6dce856  jnz 0x000071BDE6DCE888
000071bde6dce858  cmp dword ptr [r15+0x318], 0x00
000071bde6dce860  jz 0x000071BDE6DCE910
000071bde6dce866  nop [rax+rax*1], ax
000071bde6dce86f  nop [rax+rax*1], eax
000071bde6dce877  mov eax, 0x410050
000071bde6dce87c  mov [r15+0x100], rax
000071bde6dce883  jmp 0x000071BDE6BFE110
000071bde6dce888  cmp dword ptr [r15+0x318], 0x00
000071bde6dce890  jz 0x000071BDE6DCE7E0
000071bde6dce896  nop [rax+rax*1], ax
000071bde6dce89f  nop [rax+rax*1], eax
000071bde6dce8a7  mov eax, 0x410044
000071bde6dce8ac  mov [r15+0x100], rax
000071bde6dce8b3  jmp 0x000071BDE6BFE110
000071bde6dce8b8  int3
000071bde6dce8b9  ucomisd xmm1, xmm15
000071bde6dce8be  jp 0x000071BDE6DCE8CD
000071bde6dce8c0  movaps xmm14, [0x000071BDE69FE030]
000071bde6dce8c8  jmp 0x000071BDE6DCE818
000071bde6dce8cd  vxorps xmm0, xmm1, xmm15
000071bde6dce8d2  pextrw eax, xmm0, 0x03
000071bde6dce8d7  and eax, 0x7FF8
000071bde6dce8dc  cmp eax, 0x08
000071bde6dce8df  jnz 0x000071BDE6DCE818
000071bde6dce8e5  movq rax, xmm15
000071bde6dce8ea  shl rax, 0x0D
000071bde6dce8ee  jbe 0x000071BDE6DCE818
000071bde6dce8f4  vorps xmm14, xmm15, [0x000071BDE69FE040]
000071bde6dce8fc  jmp 0x000071BDE6DCE818
000071bde6dce901  int3
000071bde6dce902  nop [rax+rax*1], ax
000071bde6dce90b  nop [rax+rax*1], eax
000071bde6dce910  mov rax, [r15+0x20]
000071bde6dce914  movaps xmm1, [r15+0x110]
000071bde6dce91c  movq r14, xmm1
000071bde6dce921  mov [r13+rax*1], r14
000071bde6dce926  mov rax, [r15+0xF0]
000071bde6dce92d  mov [r15+0x100], rax
000071bde6dce934  jmp 0x000071BDE6DCE5C0
000071bde6dce939  int3
000071bde6dce93a  call 0x000071BDE6C0E120
000071bde6dce93f  jmp 0x000071BDE6DCE926
000071bde6dce944  int3
000071bde6dce945  nop [rax+rax*1], ax
000071bde6dce94e  nop
000071bde6dce950  mov qword ptr [r15+0x100], 0x04
000071bde6dce95b  mov esi, 0x00
000071bde6dce960  mov edx, 0x09
000071bde6dce965  mov rdi, 0x7FFC183DC320
000071bde6dce96f  mov rax, 0x60022C965970
000071bde6dce979  call rax
000071bde6dce97b  cmp dword ptr [r15+0x318], 0x00
000071bde6dce983  jnz 0x000071BDE6BFE110
000071bde6dce989  jmp 0x000071BDE6BFE0A0
000071bde6dce98e  int3
000071bde6dce98f  int3
