000074acf51ce69b  nop [rax+rax*1], eax
000074acf51ce6a0  mov qword ptr [r15+0x20], 0x420060
000074acf51ce6a8  xor eax, eax
000074acf51ce6aa  xor r14d, r14d
000074acf51ce6ad  shrd rax, r14, 0x0D
000074acf51ce6b2  mov [rsp+0x10], rax
000074acf51ce6b7  shr rax, 0x07
000074acf51ce6bb  mov r14, [rsp+0x10]
000074acf51ce6c0  xor r14, rax
000074acf51ce6c3  lea rax, [r14+0x03]
000074acf51ce6c7  mov [r15], rax
000074acf51ce6ca  xor eax, eax
000074acf51ce6cc  mov r14d, 0xB71B00
000074acf51ce6d2  mov r12d, 0x01
000074acf51ce6d8  sub r14, r12
000074acf51ce6db  cmc
000074acf51ce6dc  lahf
000074acf51ce6dd  seto al
000074acf51ce6e0  mov [r15+0x108], eax
000074acf51ce6e7  mov [r15+0x08], r14
000074acf51ce6eb  mov eax, [r15+0x108]
000074acf51ce6f2  sahf
000074acf51ce6f3  jnz 0x000074ACF51CE725
000074acf51ce6f5  cmp dword ptr [r15+0x318], 0x00
000074acf51ce6fd  jz 0x000074ACF51CE820
000074acf51ce703  nop [rax+rax*1], ax
000074acf51ce70c  nop [rax+rax*1], eax
000074acf51ce714  mov eax, 0x410050
000074acf51ce719  mov [r15+0x100], rax
000074acf51ce720  jmp 0x000074ACF4FFE110
000074acf51ce725  cmp dword ptr [r15+0x318], 0x00
000074acf51ce72d  jz 0x000074ACF51CE760
000074acf51ce733  nop [rax+rax*1], ax
000074acf51ce73c  nop [rax+rax*1], eax
000074acf51ce744  mov eax, 0x41003C
000074acf51ce749  mov [r15+0x100], rax
000074acf51ce750  jmp 0x000074ACF4FFE110
000074acf51ce755  int3
000074acf51ce756  int3
000074acf51ce757  nop [rax+rax*1], ax
000074acf51ce760  mov rax, [r15]
000074acf51ce763  mov [rsp+0x10], rax
000074acf51ce768  mov r14, [rsp+0x10]
000074acf51ce76d  shrd rax, r14, 0x0D
000074acf51ce772  mov [rsp+0x10], rax
000074acf51ce777  shr rax, 0x07
000074acf51ce77b  mov r14, [rsp+0x10]
000074acf51ce780  xor r14, rax
000074acf51ce783  lea rax, [r14+0x03]
000074acf51ce787  mov [r15], rax
000074acf51ce78a  mov rax, [r15+0x08]
000074acf51ce78e  mov [rsp+0x10], rax
000074acf51ce793  xor eax, eax
000074acf51ce795  mov r14, [rsp+0x10]
000074acf51ce79a  mov r12d, 0x01
000074acf51ce7a0  sub r14, r12
000074acf51ce7a3  cmc
000074acf51ce7a4  lahf
000074acf51ce7a5  seto al
000074acf51ce7a8  mov [r15+0x108], eax
000074acf51ce7af  mov [r15+0x08], r14
000074acf51ce7b3  mov eax, [r15+0x108]
000074acf51ce7ba  sahf
000074acf51ce7bb  jnz 0x000074ACF51CE7ED
000074acf51ce7bd  cmp dword ptr [r15+0x318], 0x00
000074acf51ce7c5  jz 0x000074ACF51CE820
000074acf51ce7cb  nop [rax+rax*1], ax
000074acf51ce7d4  nop [rax+rax*1], eax
000074acf51ce7dc  mov eax, 0x410050
000074acf51ce7e1  mov [r15+0x100], rax
000074acf51ce7e8  jmp 0x000074ACF4FFE110
000074acf51ce7ed  cmp dword ptr [r15+0x318], 0x00
000074acf51ce7f5  jz 0x000074ACF51CE760
000074acf51ce7fb  nop [rax+rax*1], ax
000074acf51ce804  nop [rax+rax*1], eax
000074acf51ce80c  mov eax, 0x41003C
000074acf51ce811  mov [r15+0x100], rax
000074acf51ce818  jmp 0x000074ACF4FFE110
000074acf51ce81d  int3
000074acf51ce81e  int3
000074acf51ce81f  nop
000074acf51ce820  mov rax, [r15+0x20]
000074acf51ce824  mov r14, [r15]
000074acf51ce827  mov [r13+rax*1], r14
000074acf51ce82c  mov rax, [r15+0xF0]
000074acf51ce833  mov [r15+0x100], rax
000074acf51ce83a  jmp 0x000074ACF51CE5C0
000074acf51ce83f  int3
000074acf51ce840  call 0x000074ACF500E120
000074acf51ce845  jmp 0x000074ACF51CE82C
000074acf51ce84a  int3
000074acf51ce84b  nop [rax+rax*1], eax
000074acf51ce850  mov qword ptr [r15+0x100], 0x04
000074acf51ce85b  mov esi, 0x00
000074acf51ce860  mov edx, 0x09
000074acf51ce865  mov rdi, 0x7FFF3FE01870
000074acf51ce86f  mov rax, 0x55DD54381970
000074acf51ce879  call rax
000074acf51ce87b  cmp dword ptr [r15+0x318], 0x00
000074acf51ce883  jnz 0x000074ACF4FFE110
000074acf51ce889  jmp 0x000074ACF4FFE0A0
000074acf51ce88e  int3
000074acf51ce88f  int3
