0000750b3efce69b  nop [rax+rax*1], eax
0000750b3efce6a0  mov qword ptr [r15+0x20], 0x420060
0000750b3efce6a8  xor eax, eax
0000750b3efce6aa  xor r14d, r14d
0000750b3efce6ad  shrd rax, r14, 0x0D
0000750b3efce6b2  mov [rsp+0x10], rax
0000750b3efce6b7  shr rax, 0x07
0000750b3efce6bb  mov r14, [rsp+0x10]
0000750b3efce6c0  xor r14, rax
0000750b3efce6c3  lea rax, [r14+0x03]
0000750b3efce6c7  mov [r15], rax
0000750b3efce6ca  xor eax, eax
0000750b3efce6cc  mov r14d, 0xB71B00
0000750b3efce6d2  mov r12d, 0x01
0000750b3efce6d8  sub r14, r12
0000750b3efce6db  cmc
0000750b3efce6dc  lahf
0000750b3efce6dd  seto al
0000750b3efce6e0  mov [r15+0x108], eax
0000750b3efce6e7  mov [r15+0x08], r14
0000750b3efce6eb  mov eax, [r15+0x108]
0000750b3efce6f2  sahf
0000750b3efce6f3  jnz 0x0000750B3EFCE725
0000750b3efce6f5  cmp dword ptr [r15+0x318], 0x00
0000750b3efce6fd  jz 0x0000750B3EFCE820
0000750b3efce703  nop [rax+rax*1], ax
0000750b3efce70c  nop [rax+rax*1], eax
0000750b3efce714  mov eax, 0x410050
0000750b3efce719  mov [r15+0x100], rax
0000750b3efce720  jmp 0x0000750B3EDFE110
0000750b3efce725  cmp dword ptr [r15+0x318], 0x00
0000750b3efce72d  jz 0x0000750B3EFCE760
0000750b3efce733  nop [rax+rax*1], ax
0000750b3efce73c  nop [rax+rax*1], eax
0000750b3efce744  mov eax, 0x41003C
0000750b3efce749  mov [r15+0x100], rax
0000750b3efce750  jmp 0x0000750B3EDFE110
0000750b3efce755  int3
0000750b3efce756  int3
0000750b3efce757  nop [rax+rax*1], ax
0000750b3efce760  mov rax, [r15]
0000750b3efce763  mov [rsp+0x10], rax
0000750b3efce768  mov r14, [rsp+0x10]
0000750b3efce76d  shrd rax, r14, 0x0D
0000750b3efce772  mov [rsp+0x10], rax
0000750b3efce777  shr rax, 0x07
0000750b3efce77b  mov r14, [rsp+0x10]
0000750b3efce780  xor r14, rax
0000750b3efce783  lea rax, [r14+0x03]
0000750b3efce787  mov [r15], rax
0000750b3efce78a  mov rax, [r15+0x08]
0000750b3efce78e  mov [rsp+0x10], rax
0000750b3efce793  xor eax, eax
0000750b3efce795  mov r14, [rsp+0x10]
0000750b3efce79a  mov r12d, 0x01
0000750b3efce7a0  sub r14, r12
0000750b3efce7a3  cmc
0000750b3efce7a4  lahf
0000750b3efce7a5  seto al
0000750b3efce7a8  mov [r15+0x108], eax
0000750b3efce7af  mov [r15+0x08], r14
0000750b3efce7b3  mov eax, [r15+0x108]
0000750b3efce7ba  sahf
0000750b3efce7bb  jnz 0x0000750B3EFCE7ED
0000750b3efce7bd  cmp dword ptr [r15+0x318], 0x00
0000750b3efce7c5  jz 0x0000750B3EFCE820
0000750b3efce7cb  nop [rax+rax*1], ax
0000750b3efce7d4  nop [rax+rax*1], eax
0000750b3efce7dc  mov eax, 0x410050
0000750b3efce7e1  mov [r15+0x100], rax
0000750b3efce7e8  jmp 0x0000750B3EDFE110
0000750b3efce7ed  cmp dword ptr [r15+0x318], 0x00
0000750b3efce7f5  jz 0x0000750B3EFCE760
0000750b3efce7fb  nop [rax+rax*1], ax
0000750b3efce804  nop [rax+rax*1], eax
0000750b3efce80c  mov eax, 0x41003C
0000750b3efce811  mov [r15+0x100], rax
0000750b3efce818  jmp 0x0000750B3EDFE110
0000750b3efce81d  int3
0000750b3efce81e  int3
0000750b3efce81f  nop
0000750b3efce820  mov rax, [r15+0x20]
0000750b3efce824  mov r14, [r15]
0000750b3efce827  mov [r13+rax*1], r14
0000750b3efce82c  mov rax, [r15+0xF0]
0000750b3efce833  mov [r15+0x100], rax
0000750b3efce83a  jmp 0x0000750B3EFCE5C0
0000750b3efce83f  int3
0000750b3efce840  call 0x0000750B3EE0E120
0000750b3efce845  jmp 0x0000750B3EFCE82C
0000750b3efce84a  int3
0000750b3efce84b  nop [rax+rax*1], eax
0000750b3efce850  mov qword ptr [r15+0x100], 0x04
0000750b3efce85b  mov esi, 0x00
0000750b3efce860  mov edx, 0x09
0000750b3efce865  mov rdi, 0x7FFDD2DE7350
0000750b3efce86f  mov rax, 0x5F96DAAF1970
0000750b3efce879  call rax
0000750b3efce87b  cmp dword ptr [r15+0x318], 0x00
0000750b3efce883  jnz 0x0000750B3EDFE110
0000750b3efce889  jmp 0x0000750B3EDFE0A0
0000750b3efce88e  int3
0000750b3efce88f  int3
