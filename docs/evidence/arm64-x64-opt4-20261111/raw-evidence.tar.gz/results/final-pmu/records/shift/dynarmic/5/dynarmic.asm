000073e8ae5ce69b  nop [rax+rax*1], eax
000073e8ae5ce6a0  mov qword ptr [r15+0x20], 0x420060
000073e8ae5ce6a8  xor eax, eax
000073e8ae5ce6aa  xor r14d, r14d
000073e8ae5ce6ad  shrd rax, r14, 0x0D
000073e8ae5ce6b2  mov [rsp+0x10], rax
000073e8ae5ce6b7  shr rax, 0x07
000073e8ae5ce6bb  mov r14, [rsp+0x10]
000073e8ae5ce6c0  xor r14, rax
000073e8ae5ce6c3  lea rax, [r14+0x03]
000073e8ae5ce6c7  mov [r15], rax
000073e8ae5ce6ca  xor eax, eax
000073e8ae5ce6cc  mov r14d, 0xB71B00
000073e8ae5ce6d2  mov r12d, 0x01
000073e8ae5ce6d8  sub r14, r12
000073e8ae5ce6db  cmc
000073e8ae5ce6dc  lahf
000073e8ae5ce6dd  seto al
000073e8ae5ce6e0  mov [r15+0x108], eax
000073e8ae5ce6e7  mov [r15+0x08], r14
000073e8ae5ce6eb  mov eax, [r15+0x108]
000073e8ae5ce6f2  sahf
000073e8ae5ce6f3  jnz 0x000073E8AE5CE725
000073e8ae5ce6f5  cmp dword ptr [r15+0x318], 0x00
000073e8ae5ce6fd  jz 0x000073E8AE5CE820
000073e8ae5ce703  nop [rax+rax*1], ax
000073e8ae5ce70c  nop [rax+rax*1], eax
000073e8ae5ce714  mov eax, 0x410050
000073e8ae5ce719  mov [r15+0x100], rax
000073e8ae5ce720  jmp 0x000073E8AE3FE110
000073e8ae5ce725  cmp dword ptr [r15+0x318], 0x00
000073e8ae5ce72d  jz 0x000073E8AE5CE760
000073e8ae5ce733  nop [rax+rax*1], ax
000073e8ae5ce73c  nop [rax+rax*1], eax
000073e8ae5ce744  mov eax, 0x41003C
000073e8ae5ce749  mov [r15+0x100], rax
000073e8ae5ce750  jmp 0x000073E8AE3FE110
000073e8ae5ce755  int3
000073e8ae5ce756  int3
000073e8ae5ce757  nop [rax+rax*1], ax
000073e8ae5ce760  mov rax, [r15]
000073e8ae5ce763  mov [rsp+0x10], rax
000073e8ae5ce768  mov r14, [rsp+0x10]
000073e8ae5ce76d  shrd rax, r14, 0x0D
000073e8ae5ce772  mov [rsp+0x10], rax
000073e8ae5ce777  shr rax, 0x07
000073e8ae5ce77b  mov r14, [rsp+0x10]
000073e8ae5ce780  xor r14, rax
000073e8ae5ce783  lea rax, [r14+0x03]
000073e8ae5ce787  mov [r15], rax
000073e8ae5ce78a  mov rax, [r15+0x08]
000073e8ae5ce78e  mov [rsp+0x10], rax
000073e8ae5ce793  xor eax, eax
000073e8ae5ce795  mov r14, [rsp+0x10]
000073e8ae5ce79a  mov r12d, 0x01
000073e8ae5ce7a0  sub r14, r12
000073e8ae5ce7a3  cmc
000073e8ae5ce7a4  lahf
000073e8ae5ce7a5  seto al
000073e8ae5ce7a8  mov [r15+0x108], eax
000073e8ae5ce7af  mov [r15+0x08], r14
000073e8ae5ce7b3  mov eax, [r15+0x108]
000073e8ae5ce7ba  sahf
000073e8ae5ce7bb  jnz 0x000073E8AE5CE7ED
000073e8ae5ce7bd  cmp dword ptr [r15+0x318], 0x00
000073e8ae5ce7c5  jz 0x000073E8AE5CE820
000073e8ae5ce7cb  nop [rax+rax*1], ax
000073e8ae5ce7d4  nop [rax+rax*1], eax
000073e8ae5ce7dc  mov eax, 0x410050
000073e8ae5ce7e1  mov [r15+0x100], rax
000073e8ae5ce7e8  jmp 0x000073E8AE3FE110
000073e8ae5ce7ed  cmp dword ptr [r15+0x318], 0x00
000073e8ae5ce7f5  jz 0x000073E8AE5CE760
000073e8ae5ce7fb  nop [rax+rax*1], ax
000073e8ae5ce804  nop [rax+rax*1], eax
000073e8ae5ce80c  mov eax, 0x41003C
000073e8ae5ce811  mov [r15+0x100], rax
000073e8ae5ce818  jmp 0x000073E8AE3FE110
000073e8ae5ce81d  int3
000073e8ae5ce81e  int3
000073e8ae5ce81f  nop
000073e8ae5ce820  mov rax, [r15+0x20]
000073e8ae5ce824  mov r14, [r15]
000073e8ae5ce827  mov [r13+rax*1], r14
000073e8ae5ce82c  mov rax, [r15+0xF0]
000073e8ae5ce833  mov [r15+0x100], rax
000073e8ae5ce83a  jmp 0x000073E8AE5CE5C0
000073e8ae5ce83f  int3
000073e8ae5ce840  call 0x000073E8AE40E120
000073e8ae5ce845  jmp 0x000073E8AE5CE82C
000073e8ae5ce84a  int3
000073e8ae5ce84b  nop [rax+rax*1], eax
000073e8ae5ce850  mov qword ptr [r15+0x100], 0x04
000073e8ae5ce85b  mov esi, 0x00
000073e8ae5ce860  mov edx, 0x09
000073e8ae5ce865  mov rdi, 0x7FFC2199F490
000073e8ae5ce86f  mov rax, 0x605532ADF970
000073e8ae5ce879  call rax
000073e8ae5ce87b  cmp dword ptr [r15+0x318], 0x00
000073e8ae5ce883  jnz 0x000073E8AE3FE110
000073e8ae5ce889  jmp 0x000073E8AE3FE0A0
000073e8ae5ce88e  int3
000073e8ae5ce88f  int3
