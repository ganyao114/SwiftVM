00007f3ae0dce69b  nop [rax+rax*1], eax
00007f3ae0dce6a0  mov qword ptr [r15+0x20], 0x420060
00007f3ae0dce6a8  xor eax, eax
00007f3ae0dce6aa  xor r14d, r14d
00007f3ae0dce6ad  shrd rax, r14, 0x0D
00007f3ae0dce6b2  mov [rsp+0x10], rax
00007f3ae0dce6b7  shr rax, 0x07
00007f3ae0dce6bb  mov r14, [rsp+0x10]
00007f3ae0dce6c0  xor r14, rax
00007f3ae0dce6c3  lea rax, [r14+0x03]
00007f3ae0dce6c7  mov [r15], rax
00007f3ae0dce6ca  xor eax, eax
00007f3ae0dce6cc  mov r14d, 0xB71B00
00007f3ae0dce6d2  mov r12d, 0x01
00007f3ae0dce6d8  sub r14, r12
00007f3ae0dce6db  cmc
00007f3ae0dce6dc  lahf
00007f3ae0dce6dd  seto al
00007f3ae0dce6e0  mov [r15+0x108], eax
00007f3ae0dce6e7  mov [r15+0x08], r14
00007f3ae0dce6eb  mov eax, [r15+0x108]
00007f3ae0dce6f2  sahf
00007f3ae0dce6f3  jnz 0x00007F3AE0DCE725
00007f3ae0dce6f5  cmp dword ptr [r15+0x318], 0x00
00007f3ae0dce6fd  jz 0x00007F3AE0DCE820
00007f3ae0dce703  nop [rax+rax*1], ax
00007f3ae0dce70c  nop [rax+rax*1], eax
00007f3ae0dce714  mov eax, 0x410050
00007f3ae0dce719  mov [r15+0x100], rax
00007f3ae0dce720  jmp 0x00007F3AE0BFE110
00007f3ae0dce725  cmp dword ptr [r15+0x318], 0x00
00007f3ae0dce72d  jz 0x00007F3AE0DCE760
00007f3ae0dce733  nop [rax+rax*1], ax
00007f3ae0dce73c  nop [rax+rax*1], eax
00007f3ae0dce744  mov eax, 0x41003C
00007f3ae0dce749  mov [r15+0x100], rax
00007f3ae0dce750  jmp 0x00007F3AE0BFE110
00007f3ae0dce755  int3
00007f3ae0dce756  int3
00007f3ae0dce757  nop [rax+rax*1], ax
00007f3ae0dce760  mov rax, [r15]
00007f3ae0dce763  mov [rsp+0x10], rax
00007f3ae0dce768  mov r14, [rsp+0x10]
00007f3ae0dce76d  shrd rax, r14, 0x0D
00007f3ae0dce772  mov [rsp+0x10], rax
00007f3ae0dce777  shr rax, 0x07
00007f3ae0dce77b  mov r14, [rsp+0x10]
00007f3ae0dce780  xor r14, rax
00007f3ae0dce783  lea rax, [r14+0x03]
00007f3ae0dce787  mov [r15], rax
00007f3ae0dce78a  mov rax, [r15+0x08]
00007f3ae0dce78e  mov [rsp+0x10], rax
00007f3ae0dce793  xor eax, eax
00007f3ae0dce795  mov r14, [rsp+0x10]
00007f3ae0dce79a  mov r12d, 0x01
00007f3ae0dce7a0  sub r14, r12
00007f3ae0dce7a3  cmc
00007f3ae0dce7a4  lahf
00007f3ae0dce7a5  seto al
00007f3ae0dce7a8  mov [r15+0x108], eax
00007f3ae0dce7af  mov [r15+0x08], r14
00007f3ae0dce7b3  mov eax, [r15+0x108]
00007f3ae0dce7ba  sahf
00007f3ae0dce7bb  jnz 0x00007F3AE0DCE7ED
00007f3ae0dce7bd  cmp dword ptr [r15+0x318], 0x00
00007f3ae0dce7c5  jz 0x00007F3AE0DCE820
00007f3ae0dce7cb  nop [rax+rax*1], ax
00007f3ae0dce7d4  nop [rax+rax*1], eax
00007f3ae0dce7dc  mov eax, 0x410050
00007f3ae0dce7e1  mov [r15+0x100], rax
00007f3ae0dce7e8  jmp 0x00007F3AE0BFE110
00007f3ae0dce7ed  cmp dword ptr [r15+0x318], 0x00
00007f3ae0dce7f5  jz 0x00007F3AE0DCE760
00007f3ae0dce7fb  nop [rax+rax*1], ax
00007f3ae0dce804  nop [rax+rax*1], eax
00007f3ae0dce80c  mov eax, 0x41003C
00007f3ae0dce811  mov [r15+0x100], rax
00007f3ae0dce818  jmp 0x00007F3AE0BFE110
00007f3ae0dce81d  int3
00007f3ae0dce81e  int3
00007f3ae0dce81f  nop
00007f3ae0dce820  mov rax, [r15+0x20]
00007f3ae0dce824  mov r14, [r15]
00007f3ae0dce827  mov [r13+rax*1], r14
00007f3ae0dce82c  mov rax, [r15+0xF0]
00007f3ae0dce833  mov [r15+0x100], rax
00007f3ae0dce83a  jmp 0x00007F3AE0DCE5C0
00007f3ae0dce83f  int3
00007f3ae0dce840  call 0x00007F3AE0C0E120
00007f3ae0dce845  jmp 0x00007F3AE0DCE82C
00007f3ae0dce84a  int3
00007f3ae0dce84b  nop [rax+rax*1], eax
00007f3ae0dce850  mov qword ptr [r15+0x100], 0x04
00007f3ae0dce85b  mov esi, 0x00
00007f3ae0dce860  mov edx, 0x09
00007f3ae0dce865  mov rdi, 0x7FFF8C8DE400
00007f3ae0dce86f  mov rax, 0x5A1326E30970
00007f3ae0dce879  call rax
00007f3ae0dce87b  cmp dword ptr [r15+0x318], 0x00
00007f3ae0dce883  jnz 0x00007F3AE0BFE110
00007f3ae0dce889  jmp 0x00007F3AE0BFE0A0
00007f3ae0dce88e  int3
00007f3ae0dce88f  int3
