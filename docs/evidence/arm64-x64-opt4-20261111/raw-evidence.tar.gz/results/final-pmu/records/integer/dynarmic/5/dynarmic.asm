00007c1c6a5ce69b  nop [rax+rax*1], eax
00007c1c6a5ce6a0  mov qword ptr [r15+0x20], 0x420060
00007c1c6a5ce6a8  mov qword ptr [r15], 0x03
00007c1c6a5ce6af  xor eax, eax
00007c1c6a5ce6b1  mov r14d, 0xB71B00
00007c1c6a5ce6b7  mov r12d, 0x01
00007c1c6a5ce6bd  sub r14, r12
00007c1c6a5ce6c0  cmc
00007c1c6a5ce6c1  lahf
00007c1c6a5ce6c2  seto al
00007c1c6a5ce6c5  mov [r15+0x108], eax
00007c1c6a5ce6cc  mov [r15+0x08], r14
00007c1c6a5ce6d0  mov eax, [r15+0x108]
00007c1c6a5ce6d7  sahf
00007c1c6a5ce6d8  jnz 0x00007C1C6A5CE70A
00007c1c6a5ce6da  cmp dword ptr [r15+0x318], 0x00
00007c1c6a5ce6e2  jz 0x00007C1C6A5CE7F0
00007c1c6a5ce6e8  nop [rax+rax*1], ax
00007c1c6a5ce6f1  nop [rax+rax*1], eax
00007c1c6a5ce6f9  mov eax, 0x41004C
00007c1c6a5ce6fe  mov [r15+0x100], rax
00007c1c6a5ce705  jmp 0x00007C1C6A3FE110
00007c1c6a5ce70a  cmp dword ptr [r15+0x318], 0x00
00007c1c6a5ce712  jz 0x00007C1C6A5CE740
00007c1c6a5ce718  nop [rax+rax*1], ax
00007c1c6a5ce721  nop [rax+rax*1], eax
00007c1c6a5ce729  mov eax, 0x41003C
00007c1c6a5ce72e  mov [r15+0x100], rax
00007c1c6a5ce735  jmp 0x00007C1C6A3FE110
00007c1c6a5ce73a  int3
00007c1c6a5ce73b  int3
00007c1c6a5ce73c  nop [rax], eax
00007c1c6a5ce740  mov rax, [r15]
00007c1c6a5ce743  lea r14, [rax+0x03]
00007c1c6a5ce747  mov [rsp+0x10], r14
00007c1c6a5ce74c  shr r14, 0x07
00007c1c6a5ce750  mov rax, [rsp+0x10]
00007c1c6a5ce755  xor rax, r14
00007c1c6a5ce758  mov [r15], rax
00007c1c6a5ce75b  mov rax, [r15+0x08]
00007c1c6a5ce75f  mov [rsp+0x10], rax
00007c1c6a5ce764  xor eax, eax
00007c1c6a5ce766  mov r14, [rsp+0x10]
00007c1c6a5ce76b  mov r12d, 0x01
00007c1c6a5ce771  sub r14, r12
00007c1c6a5ce774  cmc
00007c1c6a5ce775  lahf
00007c1c6a5ce776  seto al
00007c1c6a5ce779  mov [r15+0x108], eax
00007c1c6a5ce780  mov [r15+0x08], r14
00007c1c6a5ce784  mov eax, [r15+0x108]
00007c1c6a5ce78b  sahf
00007c1c6a5ce78c  jnz 0x00007C1C6A5CE7BE
00007c1c6a5ce78e  cmp dword ptr [r15+0x318], 0x00
00007c1c6a5ce796  jz 0x00007C1C6A5CE7F0
00007c1c6a5ce79c  nop [rax+rax*1], ax
00007c1c6a5ce7a5  nop [rax+rax*1], eax
00007c1c6a5ce7ad  mov eax, 0x41004C
00007c1c6a5ce7b2  mov [r15+0x100], rax
00007c1c6a5ce7b9  jmp 0x00007C1C6A3FE110
00007c1c6a5ce7be  cmp dword ptr [r15+0x318], 0x00
00007c1c6a5ce7c6  jz 0x00007C1C6A5CE740
00007c1c6a5ce7cc  nop [rax+rax*1], ax
00007c1c6a5ce7d5  nop [rax+rax*1], eax
00007c1c6a5ce7dd  mov eax, 0x41003C
00007c1c6a5ce7e2  mov [r15+0x100], rax
00007c1c6a5ce7e9  jmp 0x00007C1C6A3FE110
00007c1c6a5ce7ee  int3
00007c1c6a5ce7ef  int3
00007c1c6a5ce7f0  mov rax, [r15+0x20]
00007c1c6a5ce7f4  mov r14, [r15]
00007c1c6a5ce7f7  mov [r13+rax*1], r14
00007c1c6a5ce7fc  mov rax, [r15+0xF0]
00007c1c6a5ce803  mov [r15+0x100], rax
00007c1c6a5ce80a  jmp 0x00007C1C6A5CE5C0
00007c1c6a5ce80f  int3
00007c1c6a5ce810  call 0x00007C1C6A40E120
00007c1c6a5ce815  jmp 0x00007C1C6A5CE7FC
00007c1c6a5ce81a  int3
00007c1c6a5ce81b  nop [rax+rax*1], eax
00007c1c6a5ce820  mov qword ptr [r15+0x100], 0x04
00007c1c6a5ce82b  mov esi, 0x00
00007c1c6a5ce830  mov edx, 0x09
00007c1c6a5ce835  mov rdi, 0x7FFD3CE6C700
00007c1c6a5ce83f  mov rax, 0x6107282EF970
00007c1c6a5ce849  call rax
00007c1c6a5ce84b  cmp dword ptr [r15+0x318], 0x00
00007c1c6a5ce853  jnz 0x00007C1C6A3FE110
00007c1c6a5ce859  jmp 0x00007C1C6A3FE0A0
00007c1c6a5ce85e  int3
00007c1c6a5ce85f  int3
