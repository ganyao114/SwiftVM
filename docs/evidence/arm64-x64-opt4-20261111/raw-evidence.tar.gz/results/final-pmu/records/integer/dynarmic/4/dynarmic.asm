000079eed27ce69b  nop [rax+rax*1], eax
000079eed27ce6a0  mov qword ptr [r15+0x20], 0x420060
000079eed27ce6a8  mov qword ptr [r15], 0x03
000079eed27ce6af  xor eax, eax
000079eed27ce6b1  mov r14d, 0xB71B00
000079eed27ce6b7  mov r12d, 0x01
000079eed27ce6bd  sub r14, r12
000079eed27ce6c0  cmc
000079eed27ce6c1  lahf
000079eed27ce6c2  seto al
000079eed27ce6c5  mov [r15+0x108], eax
000079eed27ce6cc  mov [r15+0x08], r14
000079eed27ce6d0  mov eax, [r15+0x108]
000079eed27ce6d7  sahf
000079eed27ce6d8  jnz 0x000079EED27CE70A
000079eed27ce6da  cmp dword ptr [r15+0x318], 0x00
000079eed27ce6e2  jz 0x000079EED27CE7F0
000079eed27ce6e8  nop [rax+rax*1], ax
000079eed27ce6f1  nop [rax+rax*1], eax
000079eed27ce6f9  mov eax, 0x41004C
000079eed27ce6fe  mov [r15+0x100], rax
000079eed27ce705  jmp 0x000079EED25FE110
000079eed27ce70a  cmp dword ptr [r15+0x318], 0x00
000079eed27ce712  jz 0x000079EED27CE740
000079eed27ce718  nop [rax+rax*1], ax
000079eed27ce721  nop [rax+rax*1], eax
000079eed27ce729  mov eax, 0x41003C
000079eed27ce72e  mov [r15+0x100], rax
000079eed27ce735  jmp 0x000079EED25FE110
000079eed27ce73a  int3
000079eed27ce73b  int3
000079eed27ce73c  nop [rax], eax
000079eed27ce740  mov rax, [r15]
000079eed27ce743  lea r14, [rax+0x03]
000079eed27ce747  mov [rsp+0x10], r14
000079eed27ce74c  shr r14, 0x07
000079eed27ce750  mov rax, [rsp+0x10]
000079eed27ce755  xor rax, r14
000079eed27ce758  mov [r15], rax
000079eed27ce75b  mov rax, [r15+0x08]
000079eed27ce75f  mov [rsp+0x10], rax
000079eed27ce764  xor eax, eax
000079eed27ce766  mov r14, [rsp+0x10]
000079eed27ce76b  mov r12d, 0x01
000079eed27ce771  sub r14, r12
000079eed27ce774  cmc
000079eed27ce775  lahf
000079eed27ce776  seto al
000079eed27ce779  mov [r15+0x108], eax
000079eed27ce780  mov [r15+0x08], r14
000079eed27ce784  mov eax, [r15+0x108]
000079eed27ce78b  sahf
000079eed27ce78c  jnz 0x000079EED27CE7BE
000079eed27ce78e  cmp dword ptr [r15+0x318], 0x00
000079eed27ce796  jz 0x000079EED27CE7F0
000079eed27ce79c  nop [rax+rax*1], ax
000079eed27ce7a5  nop [rax+rax*1], eax
000079eed27ce7ad  mov eax, 0x41004C
000079eed27ce7b2  mov [r15+0x100], rax
000079eed27ce7b9  jmp 0x000079EED25FE110
000079eed27ce7be  cmp dword ptr [r15+0x318], 0x00
000079eed27ce7c6  jz 0x000079EED27CE740
000079eed27ce7cc  nop [rax+rax*1], ax
000079eed27ce7d5  nop [rax+rax*1], eax
000079eed27ce7dd  mov eax, 0x41003C
000079eed27ce7e2  mov [r15+0x100], rax
000079eed27ce7e9  jmp 0x000079EED25FE110
000079eed27ce7ee  int3
000079eed27ce7ef  int3
000079eed27ce7f0  mov rax, [r15+0x20]
000079eed27ce7f4  mov r14, [r15]
000079eed27ce7f7  mov [r13+rax*1], r14
000079eed27ce7fc  mov rax, [r15+0xF0]
000079eed27ce803  mov [r15+0x100], rax
000079eed27ce80a  jmp 0x000079EED27CE5C0
000079eed27ce80f  int3
000079eed27ce810  call 0x000079EED260E120
000079eed27ce815  jmp 0x000079EED27CE7FC
000079eed27ce81a  int3
000079eed27ce81b  nop [rax+rax*1], eax
000079eed27ce820  mov qword ptr [r15+0x100], 0x04
000079eed27ce82b  mov esi, 0x00
000079eed27ce830  mov edx, 0x09
000079eed27ce835  mov rdi, 0x7FFFF1E360C0
000079eed27ce83f  mov rax, 0x5EA21A6D2970
000079eed27ce849  call rax
000079eed27ce84b  cmp dword ptr [r15+0x318], 0x00
000079eed27ce853  jnz 0x000079EED25FE110
000079eed27ce859  jmp 0x000079EED25FE0A0
000079eed27ce85e  int3
000079eed27ce85f  int3
