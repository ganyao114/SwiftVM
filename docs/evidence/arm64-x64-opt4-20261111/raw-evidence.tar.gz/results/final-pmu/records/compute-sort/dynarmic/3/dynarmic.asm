00007c86d4bce69b  nop [rax+rax*1], eax
00007c86d4bce6a0  mov rax, [r15+0xF8]
00007c86d4bce6a7  lea r14, [rax-0x20]
00007c86d4bce6ab  mov r12, [r15+0xF0]
00007c86d4bce6b2  mov [r13+r14*1], r12
00007c86d4bce6b7  mov [r15+0xF8], r14
00007c86d4bce6be  lea r14, [rax-0x10]
00007c86d4bce6c2  mov r12, [r15+0xA0]
00007c86d4bce6c9  mov r11, [r15+0x98]
00007c86d4bce6d0  mov [r13+r14*1], r12
00007c86d4bce6d5  lea r14, [rax-0x08]
00007c86d4bce6d9  mov [r13+r14*1], r11
00007c86d4bce6de  mov qword ptr [r15+0xA0], 0x00
00007c86d4bce6e9  mov qword ptr [r15+0x98], 0x4202A0
00007c86d4bce6f4  mov eax, [r15+0xA0]
00007c86d4bce6fb  lea r14d, [eax+0x11]
00007c86d4bce700  mov r14d, r14d
00007c86d4bce703  mov [r15], r14
00007c86d4bce706  mov qword ptr [r15+0xF0], 0x410184
00007c86d4bce711  mov r14d, [r15+0x320]
00007c86d4bce718  mov eax, 0x410184
00007c86d4bce71d  mov rcx, 0x7C86D4BCE800
00007c86d4bce727  mov [r15+r14*8+0x328], rax
00007c86d4bce72f  mov [r15+r14*8+0x368], rcx
00007c86d4bce737  add r14d, 0x01
00007c86d4bce73b  and r14d, 0x07
00007c86d4bce73f  mov [r15+0x320], r14d
00007c86d4bce746  cmp dword ptr [r15+0x318], 0x00
00007c86d4bce74e  jz 0x00007C86D4BCE7A0
00007c86d4bce754  nop [rax+rax*1], ax
00007c86d4bce75d  nop [rax+rax*1], eax
00007c86d4bce765  mov eax, 0x41021C
00007c86d4bce76a  mov [r15+0x100], rax
00007c86d4bce771  jmp 0x00007C86D49FE110
00007c86d4bce776  int3
00007c86d4bce777  call 0x00007C86D4AE2CE0
00007c86d4bce77c  jmp 0x00007C86D4BCE6B7
00007c86d4bce781  call 0x00007C86D4AE2CE0
00007c86d4bce786  jmp 0x00007C86D4BCE6D5
00007c86d4bce78b  call 0x00007C86D4AE1A60
00007c86d4bce790  jmp 0x00007C86D4BCE6DE
00007c86d4bce795  int3
00007c86d4bce796  nop [rax+rax*1], ax
00007c86d4bce79f  nop
00007c86d4bce7a0  mov eax, 0x846CA68B
00007c86d4bce7a5  mov eax, eax
00007c86d4bce7a7  mov [r15+0x48], rax
00007c86d4bce7ab  mov eax, [r15]
00007c86d4bce7ae  imul eax, eax, 0x7FEB352D
00007c86d4bce7b4  mov [rsp+0x10], eax
00007c86d4bce7b8  shr eax, 0x0F
00007c86d4bce7bb  mov r14d, [rsp+0x10]
00007c86d4bce7c0  xor r14d, eax
00007c86d4bce7c3  imul r14d, r14d, 0x846CA68B
00007c86d4bce7ca  mov [rsp+0x10], r14d
00007c86d4bce7cf  mov r14d, r14d
00007c86d4bce7d2  mov [r15+0x40], r14
00007c86d4bce7d6  mov eax, [rsp+0x10]
00007c86d4bce7da  shr eax, 0x10
00007c86d4bce7dd  mov r14d, [rsp+0x10]
00007c86d4bce7e2  xor r14d, eax
00007c86d4bce7e5  mov r14d, r14d
00007c86d4bce7e8  mov [r15], r14
00007c86d4bce7eb  mov rax, [r15+0xF0]
00007c86d4bce7f2  mov [r15+0x100], rax
00007c86d4bce7f9  jmp 0x00007C86D4BCE5C0
00007c86d4bce7fe  int3
00007c86d4bce7ff  int3
00007c86d4bce800  mov rax, [r15+0xA0]
00007c86d4bce807  mov [rsp+0x10], rax
00007c86d4bce80c  shl rax, 0x02
00007c86d4bce810  mov r14, [r15+0x98]
00007c86d4bce817  lea r12, [r14+rax*1]
00007c86d4bce81b  mov eax, [r15]
00007c86d4bce81e  mov [r13+r12*1], eax
00007c86d4bce823  mov rax, [rsp+0x10]
00007c86d4bce828  lea r14, [rax+0x01]
00007c86d4bce82c  mov [r15+0xA0], r14
00007c86d4bce833  xor eax, eax
00007c86d4bce835  mov r12d, 0x400
00007c86d4bce83b  cmp r14, r12
00007c86d4bce83e  cmc
00007c86d4bce83f  lahf
00007c86d4bce840  seto al
00007c86d4bce843  mov [r15+0x108], eax
00007c86d4bce84a  mov eax, [r15+0x108]
00007c86d4bce851  sahf
00007c86d4bce852  jnz 0x00007C86D4BCE884
00007c86d4bce854  cmp dword ptr [r15+0x318], 0x00
00007c86d4bce85c  jz 0x00007C86D4BCE950
00007c86d4bce862  nop [rax+rax*1], ax
00007c86d4bce86b  nop [rax+rax*1], eax
00007c86d4bce873  mov eax, 0x410194
00007c86d4bce878  mov [r15+0x100], rax
00007c86d4bce87f  jmp 0x00007C86D49FE110
00007c86d4bce884  cmp dword ptr [r15+0x318], 0x00
00007c86d4bce88c  jz 0x00007C86D4BCE8C0
00007c86d4bce892  nop [rax+rax*1], ax
00007c86d4bce89b  nop [rax+rax*1], eax
00007c86d4bce8a3  mov eax, 0x41017C
00007c86d4bce8a8  mov [r15+0x100], rax
00007c86d4bce8af  jmp 0x00007C86D49FE110
00007c86d4bce8b4  int3
00007c86d4bce8b5  call 0x00007C86D4AB4B70
00007c86d4bce8ba  jmp 0x00007C86D4BCE823
00007c86d4bce8bf  int3
00007c86d4bce8c0  mov eax, [r15+0xA0]
00007c86d4bce8c7  lea r14d, [eax+0x11]
00007c86d4bce8cc  mov r14d, r14d
00007c86d4bce8cf  mov [r15], r14
00007c86d4bce8d2  mov qword ptr [r15+0xF0], 0x410184
00007c86d4bce8dd  mov r14d, [r15+0x320]
00007c86d4bce8e4  mov eax, 0x410184
00007c86d4bce8e9  mov rcx, 0x7C86D4BCE800
00007c86d4bce8f3  mov [r15+r14*8+0x328], rax
00007c86d4bce8fb  mov [r15+r14*8+0x368], rcx
00007c86d4bce903  add r14d, 0x01
00007c86d4bce907  and r14d, 0x07
00007c86d4bce90b  mov [r15+0x320], r14d
00007c86d4bce912  cmp dword ptr [r15+0x318], 0x00
00007c86d4bce91a  jz 0x00007C86D4BCE7A0
00007c86d4bce920  nop [rax+rax*1], ax
00007c86d4bce929  nop [rax+rax*1], eax
00007c86d4bce931  mov eax, 0x41021C
00007c86d4bce936  mov [r15+0x100], rax
00007c86d4bce93d  jmp 0x00007C86D49FE110
00007c86d4bce942  int3
00007c86d4bce943  int3
00007c86d4bce944  nop [rax+rax*1], ax
00007c86d4bce94d  nop [rax], eax
00007c86d4bce950  mov qword ptr [r15+0x40], 0x01
00007c86d4bce958  cmp dword ptr [r15+0x318], 0x00
00007c86d4bce960  jz 0x00007C86D4BCE990
00007c86d4bce966  nop [rax+rax*1], ax
00007c86d4bce96f  nop [rax+rax*1], eax
00007c86d4bce977  mov eax, 0x4101B0
00007c86d4bce97c  mov [r15+0x100], rax
00007c86d4bce983  jmp 0x00007C86D49FE110
00007c86d4bce988  int3
00007c86d4bce989  int3
00007c86d4bce98a  nop [rax+rax*1], ax
00007c86d4bce990  mov rax, [r15+0x40]
00007c86d4bce994  mov [rsp+0x10], rax
00007c86d4bce999  shl rax, 0x02
00007c86d4bce99d  mov r14, [r15+0x98]
00007c86d4bce9a4  lea r12, [r14+rax*1]
00007c86d4bce9a8  mov eax, [r13+r12*1]
00007c86d4bce9ad  mov [rsp+0x20], eax
00007c86d4bce9b1  mov eax, eax
00007c86d4bce9b3  mov [r15+0x48], rax
00007c86d4bce9b7  mov rax, [rsp+0x10]
00007c86d4bce9bc  mov [r15+0x50], rax
00007c86d4bce9c0  mov eax, [r15+0x50]
00007c86d4bce9c4  lea r12d, [eax-0x01]
00007c86d4bce9c9  mov r12d, r12d
00007c86d4bce9cc  mov [r15+0x58], r12
00007c86d4bce9d0  mov rax, [r15+0x58]
00007c86d4bce9d4  mov r12d, eax
00007c86d4bce9d7  mov r12d, r12d
00007c86d4bce9da  shl r12, 0x02
00007c86d4bce9de  lea rax, [r14+r12*1]
00007c86d4bce9e2  mov r14d, [r13+rax*1]
00007c86d4bce9e7  mov [rsp+0x10], r14d
00007c86d4bce9ec  mov r14d, r14d
00007c86d4bce9ef  mov [r15+0x60], r14
00007c86d4bce9f3  xor eax, eax
00007c86d4bce9f5  mov r14d, [rsp+0x10]
00007c86d4bce9fa  mov r12d, [rsp+0x20]
00007c86d4bce9ff  cmp r14d, r12d
00007c86d4bcea02  cmc
00007c86d4bcea03  lahf
00007c86d4bcea04  seto al
00007c86d4bcea07  mov [r15+0x108], eax
00007c86d4bcea0e  mov eax, [r15+0x108]
00007c86d4bcea15  sahf
00007c86d4bcea16  cmc
00007c86d4bcea17  jbe 0x00007C86D4BCEA49
00007c86d4bcea19  cmp dword ptr [r15+0x318], 0x00
00007c86d4bcea21  jz 0x00007C86D4BCEA90
00007c86d4bcea27  nop [rax+rax*1], ax
00007c86d4bcea30  nop [rax+rax*1], eax
00007c86d4bcea38  mov eax, 0x4101C8
00007c86d4bcea3d  mov [r15+0x100], rax
00007c86d4bcea44  jmp 0x00007C86D49FE110
00007c86d4bcea49  cmp dword ptr [r15+0x318], 0x00
00007c86d4bcea51  jz 0x00007C86D4BCED30
00007c86d4bcea57  nop [rax+rax*1], ax
00007c86d4bcea60  nop [rax+rax*1], eax
00007c86d4bcea68  mov eax, 0x4101A0
00007c86d4bcea6d  mov [r15+0x100], rax
00007c86d4bcea74  jmp 0x00007C86D49FE110
00007c86d4bcea79  int3
00007c86d4bcea7a  call 0x00007C86D4AB4690
00007c86d4bcea7f  jmp 0x00007C86D4BCE9AD
00007c86d4bcea84  call 0x00007C86D4A0DAE0
00007c86d4bcea89  jmp 0x00007C86D4BCE9E7
00007c86d4bcea8e  int3
00007c86d4bcea8f  nop
00007c86d4bcea90  mov rax, [r15+0x50]
00007c86d4bcea94  mov [rsp+0x10], rax
00007c86d4bcea99  shl rax, 0x02
00007c86d4bcea9d  mov r14, [r15+0x98]
00007c86d4bceaa4  lea r12, [r14+rax*1]
00007c86d4bceaa8  mov eax, [r15+0x60]
00007c86d4bceaac  mov [r13+r12*1], eax
00007c86d4bceab1  mov rax, [rsp+0x10]
00007c86d4bceab6  lea r14, [rax-0x01]
00007c86d4bceaba  mov [r15+0x50], r14
00007c86d4bceabe  mov rax, [r15+0x58]
00007c86d4bceac2  test rax, rax
00007c86d4bceac5  setz al
00007c86d4bceac8  movzx rax, al
00007c86d4bceacc  mov [rsp+0x414], al
00007c86d4bcead3  cmp byte ptr [rsp+0x414], 0x00
00007c86d4bceadb  jz 0x00007C86D4BCEB0D
00007c86d4bceadd  cmp dword ptr [r15+0x318], 0x00
00007c86d4bceae5  jz 0x00007C86D4BCEB50
00007c86d4bceaeb  nop [rax+rax*1], ax
00007c86d4bceaf4  nop [rax+rax*1], eax
00007c86d4bceafc  mov eax, 0x4101D4
00007c86d4bceb01  mov [r15+0x100], rax
00007c86d4bceb08  jmp 0x00007C86D49FE110
00007c86d4bceb0d  cmp dword ptr [r15+0x318], 0x00
00007c86d4bceb15  jz 0x00007C86D4BCEC50
00007c86d4bceb1b  nop [rax+rax*1], ax
00007c86d4bceb24  nop [rax+rax*1], eax
00007c86d4bceb2c  mov eax, 0x4101B8
00007c86d4bceb31  mov [r15+0x100], rax
00007c86d4bceb38  jmp 0x00007C86D49FE110
00007c86d4bceb3d  int3
00007c86d4bceb3e  call 0x00007C86D4AB4B70
00007c86d4bceb43  jmp 0x00007C86D4BCEAB1
00007c86d4bceb48  int3
00007c86d4bceb49  nop [rax], eax
00007c86d4bceb50  cmp dword ptr [r15+0x318], 0x00
00007c86d4bceb58  jz 0x00007C86D4BCEB90
00007c86d4bceb5e  nop [rax+rax*1], ax
00007c86d4bceb67  nop [rax+rax*1], eax
00007c86d4bceb6f  mov eax, 0x41019C
00007c86d4bceb74  mov [r15+0x100], rax
00007c86d4bceb7b  jmp 0x00007C86D49FE110
00007c86d4bceb80  int3
00007c86d4bceb81  int3
00007c86d4bceb82  nop [rax+rax*1], ax
00007c86d4bceb8b  nop [rax+rax*1], eax
00007c86d4bceb90  mov qword ptr [r15+0x50], 0x00
00007c86d4bceb98  mov rax, [r15+0x40]
00007c86d4bceb9c  lea r14, [rax+0x01]
00007c86d4bceba0  mov [r15+0x40], r14
00007c86d4bceba4  mov rax, [r15+0x98]
00007c86d4bcebab  mov r12d, [r15+0x48]
00007c86d4bcebaf  mov [r13+rax*1], r12d
00007c86d4bcebb4  xor eax, eax
00007c86d4bcebb6  mov r12d, 0x400
00007c86d4bcebbc  cmp r14, r12
00007c86d4bcebbf  cmc
00007c86d4bcebc0  lahf
00007c86d4bcebc1  seto al
00007c86d4bcebc4  mov [r15+0x108], eax
00007c86d4bcebcb  mov eax, [r15+0x108]
00007c86d4bcebd2  sahf
00007c86d4bcebd3  jz 0x00007C86D4BCEC05
00007c86d4bcebd5  cmp dword ptr [r15+0x318], 0x00
00007c86d4bcebdd  jz 0x00007C86D4BCE990
00007c86d4bcebe3  nop [rax+rax*1], ax
00007c86d4bcebec  nop [rax+rax*1], eax
00007c86d4bcebf4  mov eax, 0x4101B0
00007c86d4bcebf9  mov [r15+0x100], rax
00007c86d4bcec00  jmp 0x00007C86D49FE110
00007c86d4bcec05  cmp dword ptr [r15+0x318], 0x00
00007c86d4bcec0d  jz 0x00007C86D4BCEDF0
00007c86d4bcec13  nop [rax+rax*1], ax
00007c86d4bcec1c  nop [rax+rax*1], eax
00007c86d4bcec24  mov eax, 0x4101D8
00007c86d4bcec29  mov [r15+0x100], rax
00007c86d4bcec30  jmp 0x00007C86D49FE110
00007c86d4bcec35  int3
00007c86d4bcec36  call 0x00007C86D4A0BAE0
00007c86d4bcec3b  jmp 0x00007C86D4BCEBB4
00007c86d4bcec40  int3
00007c86d4bcec41  nop [rax+rax*1], ax
00007c86d4bcec4a  nop [rax+rax*1], ax
00007c86d4bcec50  mov eax, [r15+0x50]
00007c86d4bcec54  lea r14d, [eax-0x01]
00007c86d4bcec59  mov r14d, r14d
00007c86d4bcec5c  mov [r15+0x58], r14
00007c86d4bcec60  mov rax, [r15+0x58]
00007c86d4bcec64  mov r14d, eax
00007c86d4bcec67  mov r14d, r14d
00007c86d4bcec6a  shl r14, 0x02
00007c86d4bcec6e  mov rax, [r15+0x98]
00007c86d4bcec75  lea r12, [rax+r14*1]
00007c86d4bcec79  mov eax, [r13+r12*1]
00007c86d4bcec7e  mov [rsp+0x10], eax
00007c86d4bcec82  mov eax, eax
00007c86d4bcec84  mov [r15+0x60], rax
00007c86d4bcec88  mov eax, [r15+0x48]
00007c86d4bcec8c  mov [rsp+0x20], eax
00007c86d4bcec90  xor eax, eax
00007c86d4bcec92  mov r14d, [rsp+0x10]
00007c86d4bcec97  mov r12d, [rsp+0x20]
00007c86d4bcec9c  cmp r14d, r12d
00007c86d4bcec9f  cmc
00007c86d4bceca0  lahf
00007c86d4bceca1  seto al
00007c86d4bceca4  mov [r15+0x108], eax
00007c86d4bcecab  mov eax, [r15+0x108]
00007c86d4bcecb2  sahf
00007c86d4bcecb3  cmc
00007c86d4bcecb4  jbe 0x00007C86D4BCECE6
00007c86d4bcecb6  cmp dword ptr [r15+0x318], 0x00
00007c86d4bcecbe  jz 0x00007C86D4BCEA90
00007c86d4bcecc4  nop [rax+rax*1], ax
00007c86d4bceccd  nop [rax+rax*1], eax
00007c86d4bcecd5  mov eax, 0x4101C8
00007c86d4bcecda  mov [r15+0x100], rax
00007c86d4bcece1  jmp 0x00007C86D49FE110
00007c86d4bcece6  cmp dword ptr [r15+0x318], 0x00
00007c86d4bcecee  jz 0x00007C86D4BCED30
00007c86d4bcecf4  nop [rax+rax*1], ax
00007c86d4bcecfd  nop [rax+rax*1], eax
00007c86d4bced05  mov eax, 0x4101A0
00007c86d4bced0a  mov [r15+0x100], rax
00007c86d4bced11  jmp 0x00007C86D49FE110
00007c86d4bced16  int3
00007c86d4bced17  call 0x00007C86D4AB4690
00007c86d4bced1c  jmp 0x00007C86D4BCEC7E
00007c86d4bced21  int3
00007c86d4bced22  nop [rax+rax*1], ax
00007c86d4bced2b  nop [rax+rax*1], eax
00007c86d4bced30  mov rax, [r15+0x40]
00007c86d4bced34  lea r14, [rax+0x01]
00007c86d4bced38  mov [r15+0x40], r14
00007c86d4bced3c  mov rax, [r15+0x50]
00007c86d4bced40  mov r12d, eax
00007c86d4bced43  mov r12d, r12d
00007c86d4bced46  shl r12, 0x02
00007c86d4bced4a  mov rax, [r15+0x98]
00007c86d4bced51  lea r11, [rax+r12*1]
00007c86d4bced55  mov eax, [r15+0x48]
00007c86d4bced59  mov [r13+r11*1], eax
00007c86d4bced5e  xor eax, eax
00007c86d4bced60  mov r12d, 0x400
00007c86d4bced66  cmp r14, r12
00007c86d4bced69  cmc
00007c86d4bced6a  lahf
00007c86d4bced6b  seto al
00007c86d4bced6e  mov [r15+0x108], eax
00007c86d4bced75  mov eax, [r15+0x108]
00007c86d4bced7c  sahf
00007c86d4bced7d  jz 0x00007C86D4BCEDAF
00007c86d4bced7f  cmp dword ptr [r15+0x318], 0x00
00007c86d4bced87  jz 0x00007C86D4BCE990
00007c86d4bced8d  nop [rax+rax*1], ax
00007c86d4bced96  nop [rax+rax*1], eax
00007c86d4bced9e  mov eax, 0x4101B0
00007c86d4bceda3  mov [r15+0x100], rax
00007c86d4bcedaa  jmp 0x00007C86D49FE110
00007c86d4bcedaf  cmp dword ptr [r15+0x318], 0x00
00007c86d4bcedb7  jz 0x00007C86D4BCEDF0
00007c86d4bcedbd  nop [rax+rax*1], ax
00007c86d4bcedc6  nop [rax+rax*1], eax
00007c86d4bcedce  mov eax, 0x4101D8
00007c86d4bcedd3  mov [r15+0x100], rax
00007c86d4bcedda  jmp 0x00007C86D49FE110
00007c86d4bceddf  int3
00007c86d4bcede0  call 0x00007C86D4AA4270
00007c86d4bcede5  jmp 0x00007C86D4BCED5E
00007c86d4bcedea  int3
00007c86d4bcedeb  nop [rax+rax*1], eax
00007c86d4bcedf0  mov qword ptr [r15+0x40], 0x420000
00007c86d4bcedf8  mov eax, 0x420288
00007c86d4bcedfd  mov r14, [r13+rax*1]
00007c86d4bcee02  mov rax, [r15+0x98]
00007c86d4bcee09  mov r12d, [r13+rax*1]
00007c86d4bcee0e  lea r11, [rax+0x04]
00007c86d4bcee12  mov eax, [r13+r11*1]
00007c86d4bcee17  mov r12d, r12d
00007c86d4bcee1a  mov [r15+0x68], r12
00007c86d4bcee1e  mov eax, eax
00007c86d4bcee20  mov [r15+0x60], rax
00007c86d4bcee24  mov rax, [r15+0x68]
00007c86d4bcee28  mov [r15+0x68], rax
00007c86d4bcee2c  mov qword ptr [r15+0x58], 0x02
00007c86d4bcee34  mov [rsp+0x10], rax
00007c86d4bcee39  xor eax, eax
00007c86d4bcee3b  mov r12d, 0x02
00007c86d4bcee41  mov r11d, 0x400
00007c86d4bcee47  cmp r12, r11
00007c86d4bcee4a  cmc
00007c86d4bcee4b  lahf
00007c86d4bcee4c  seto al
00007c86d4bcee4f  mov [r15+0x108], eax
00007c86d4bcee56  mov rax, [r15+0x60]
00007c86d4bcee5a  mov r12d, 0x02
00007c86d4bcee60  imul rax, r12
00007c86d4bcee64  mov [r15+0x50], rax
00007c86d4bcee68  mov rax, [rsp+0x10]
00007c86d4bcee6d  lea r12, [rax+r14*1]
00007c86d4bcee71  mov [r15+0x48], r12
00007c86d4bcee75  mov eax, [r15+0x108]
00007c86d4bcee7c  sahf
00007c86d4bcee7d  jnz 0x00007C86D4BCEEAF
00007c86d4bcee7f  cmp dword ptr [r15+0x318], 0x00
00007c86d4bcee87  jz 0x00007C86D4BCF020
00007c86d4bcee8d  nop [rax+rax*1], ax
00007c86d4bcee96  nop [rax+rax*1], eax
00007c86d4bcee9e  mov eax, 0x410208
00007c86d4bceea3  mov [r15+0x100], rax
00007c86d4bceeaa  jmp 0x00007C86D49FE110
00007c86d4bceeaf  cmp dword ptr [r15+0x318], 0x00
00007c86d4bceeb7  jz 0x00007C86D4BCEF00
00007c86d4bceebd  nop [rax+rax*1], ax
00007c86d4bceec6  nop [rax+rax*1], eax
00007c86d4bceece  mov eax, 0x4101E8
00007c86d4bceed3  mov [r15+0x100], rax
00007c86d4bceeda  jmp 0x00007C86D49FE110
00007c86d4bceedf  int3
00007c86d4bceee0  call 0x00007C86D4A0DC20
00007c86d4bceee5  jmp 0x00007C86D4BCEE02
00007c86d4bceeea  call 0x00007C86D4A0B5E0
00007c86d4bceeef  jmp 0x00007C86D4BCEE0E
00007c86d4bceef4  call 0x00007C86D4AA3D90
00007c86d4bceef9  jmp 0x00007C86D4BCEE17
00007c86d4bceefe  int3
00007c86d4bceeff  nop
00007c86d4bcef00  mov rax, [r15+0x98]
00007c86d4bcef07  mov r14, [r15+0x58]
00007c86d4bcef0b  mov [rsp+0x10], r14
00007c86d4bcef10  shl r14, 0x02
00007c86d4bcef14  lea r12, [rax+r14*1]
00007c86d4bcef18  mov eax, [r13+r12*1]
00007c86d4bcef1d  lea r14, [r12+0x04]
00007c86d4bcef22  mov r12d, [r13+r14*1]
00007c86d4bcef27  mov eax, eax
00007c86d4bcef29  mov [r15+0x68], rax
00007c86d4bcef2d  mov r12d, r12d
00007c86d4bcef30  mov [r15+0x60], r12
00007c86d4bcef34  mov rax, [r15+0x68]
00007c86d4bcef38  mov [rsp+0x20], rax
00007c86d4bcef3d  mov r14, [rsp+0x10]
00007c86d4bcef42  imul rax, r14
00007c86d4bcef46  mov r12, [rsp+0x20]
00007c86d4bcef4b  lea r11, [r12+rax*1]
00007c86d4bcef4f  mov [r15+0x68], r11
00007c86d4bcef53  lea rax, [r14+0x02]
00007c86d4bcef57  mov [r15+0x58], rax
00007c86d4bcef5b  mov [rsp+0x10], rax
00007c86d4bcef60  xor eax, eax
00007c86d4bcef62  mov r14, [rsp+0x10]
00007c86d4bcef67  mov r12d, 0x400
00007c86d4bcef6d  cmp r14, r12
00007c86d4bcef70  cmc
00007c86d4bcef71  lahf
00007c86d4bcef72  seto al
00007c86d4bcef75  mov [r15+0x108], eax
00007c86d4bcef7c  mov rax, [r15+0x50]
00007c86d4bcef80  mov r12, [r15+0x60]
00007c86d4bcef84  imul r14, r12
00007c86d4bcef88  lea r12, [rax+r14*1]
00007c86d4bcef8c  mov [r15+0x50], r12
00007c86d4bcef90  mov rax, [r15+0x48]
00007c86d4bcef94  lea r14, [r11+rax*1]
00007c86d4bcef98  mov [r15+0x48], r14
00007c86d4bcef9c  mov eax, [r15+0x108]
00007c86d4bcefa3  sahf
00007c86d4bcefa4  jnz 0x00007C86D4BCEFD6
00007c86d4bcefa6  cmp dword ptr [r15+0x318], 0x00
00007c86d4bcefae  jz 0x00007C86D4BCF020
00007c86d4bcefb4  nop [rax+rax*1], ax
00007c86d4bcefbd  nop [rax+rax*1], eax
00007c86d4bcefc5  mov eax, 0x410208
00007c86d4bcefca  mov [r15+0x100], rax
00007c86d4bcefd1  jmp 0x00007C86D49FE110
00007c86d4bcefd6  cmp dword ptr [r15+0x318], 0x00
00007c86d4bcefde  jz 0x00007C86D4BCEF00
00007c86d4bcefe4  nop [rax+rax*1], ax
00007c86d4bcefed  nop [rax+rax*1], eax
00007c86d4bceff5  mov eax, 0x4101E8
00007c86d4bceffa  mov [r15+0x100], rax
00007c86d4bcf001  jmp 0x00007C86D49FE110
00007c86d4bcf006  int3
00007c86d4bcf007  call 0x00007C86D4AB4690
00007c86d4bcf00c  jmp 0x00007C86D4BCEF1D
00007c86d4bcf011  call 0x00007C86D4AE26A0
00007c86d4bcf016  jmp 0x00007C86D4BCEF27
00007c86d4bcf01b  int3
00007c86d4bcf01c  nop [rax], eax
00007c86d4bcf020  mov rax, [r15+0xF8]
00007c86d4bcf027  lea r14, [rax+0x10]
00007c86d4bcf02b  mov r12, [r13+r14*1]
00007c86d4bcf030  lea r14, [rax+0x18]
00007c86d4bcf034  mov r11, [r13+r14*1]
00007c86d4bcf039  mov [r15+0xA0], r12
00007c86d4bcf040  mov [r15+0x98], r11
00007c86d4bcf047  mov r14, [r15+0x50]
00007c86d4bcf04b  mov r12, [r15+0x48]
00007c86d4bcf04f  lea r11, [r14+r12*1]
00007c86d4bcf053  mov [r15+0x48], r11
00007c86d4bcf057  mov r14, [r15+0x40]
00007c86d4bcf05b  lea r12, [r14+0x288]
00007c86d4bcf062  mov [r13+r12*1], r11
00007c86d4bcf067  mov r14, [r13+rax*1]
00007c86d4bcf06c  mov [r15+0xF0], r14
00007c86d4bcf073  lea r12, [rax+0x20]
00007c86d4bcf077  mov [r15+0xF8], r12
00007c86d4bcf07e  mov [r15+0x100], r14
00007c86d4bcf085  jmp 0x00007C86D4BCE5C0
00007c86d4bcf08a  int3
00007c86d4bcf08b  call 0x00007C86D4AE27E0
00007c86d4bcf090  jmp 0x00007C86D4BCF030
00007c86d4bcf095  call 0x00007C86D4AE1570
00007c86d4bcf09a  jmp 0x00007C86D4BCF039
00007c86d4bcf09f  call 0x00007C86D4AC0860
00007c86d4bcf0a4  jmp 0x00007C86D4BCF067
00007c86d4bcf0a9  call 0x00007C86D4A0DC20
00007c86d4bcf0ae  jmp 0x00007C86D4BCF06C
00007c86d4bcf0b3  int3
00007c86d4bcf0b4  nop [rax+rax*1], ax
00007c86d4bcf0bd  nop [rax], eax
00007c86d4bcf0c0  mov qword ptr [r15+0x100], 0x04
00007c86d4bcf0cb  mov esi, 0x00
00007c86d4bcf0d0  mov edx, 0x09
00007c86d4bcf0d5  mov rdi, 0x7FFD202CE1E0
00007c86d4bcf0df  mov rax, 0x5C5ED2F54970
00007c86d4bcf0e9  call rax
00007c86d4bcf0eb  cmp dword ptr [r15+0x318], 0x00
00007c86d4bcf0f3  jnz 0x00007C86D49FE110
00007c86d4bcf0f9  jmp 0x00007C86D49FE0A0
00007c86d4bcf0fe  int3
00007c86d4bcf0ff  int3
