0000748b9f9ce69b  nop [rax+rax*1], eax
0000748b9f9ce6a0  mov rax, [r15+0xF8]
0000748b9f9ce6a7  lea r14, [rax-0x20]
0000748b9f9ce6ab  mov r12, [r15+0xF0]
0000748b9f9ce6b2  mov [r13+r14*1], r12
0000748b9f9ce6b7  mov [r15+0xF8], r14
0000748b9f9ce6be  lea r14, [rax-0x10]
0000748b9f9ce6c2  mov r12, [r15+0xA0]
0000748b9f9ce6c9  mov r11, [r15+0x98]
0000748b9f9ce6d0  mov [r13+r14*1], r12
0000748b9f9ce6d5  lea r14, [rax-0x08]
0000748b9f9ce6d9  mov [r13+r14*1], r11
0000748b9f9ce6de  mov qword ptr [r15+0xA0], 0x00
0000748b9f9ce6e9  mov qword ptr [r15+0x98], 0x4202A0
0000748b9f9ce6f4  mov eax, [r15+0xA0]
0000748b9f9ce6fb  lea r14d, [eax+0x11]
0000748b9f9ce700  mov r14d, r14d
0000748b9f9ce703  mov [r15], r14
0000748b9f9ce706  mov qword ptr [r15+0xF0], 0x410184
0000748b9f9ce711  mov r14d, [r15+0x320]
0000748b9f9ce718  mov eax, 0x410184
0000748b9f9ce71d  mov rcx, 0x748B9F9CE800
0000748b9f9ce727  mov [r15+r14*8+0x328], rax
0000748b9f9ce72f  mov [r15+r14*8+0x368], rcx
0000748b9f9ce737  add r14d, 0x01
0000748b9f9ce73b  and r14d, 0x07
0000748b9f9ce73f  mov [r15+0x320], r14d
0000748b9f9ce746  cmp dword ptr [r15+0x318], 0x00
0000748b9f9ce74e  jz 0x0000748B9F9CE7A0
0000748b9f9ce754  nop [rax+rax*1], ax
0000748b9f9ce75d  nop [rax+rax*1], eax
0000748b9f9ce765  mov eax, 0x41021C
0000748b9f9ce76a  mov [r15+0x100], rax
0000748b9f9ce771  jmp 0x0000748B9F7FE110
0000748b9f9ce776  int3
0000748b9f9ce777  call 0x0000748B9F8E2CE0
0000748b9f9ce77c  jmp 0x0000748B9F9CE6B7
0000748b9f9ce781  call 0x0000748B9F8E2CE0
0000748b9f9ce786  jmp 0x0000748B9F9CE6D5
0000748b9f9ce78b  call 0x0000748B9F8E1A60
0000748b9f9ce790  jmp 0x0000748B9F9CE6DE
0000748b9f9ce795  int3
0000748b9f9ce796  nop [rax+rax*1], ax
0000748b9f9ce79f  nop
0000748b9f9ce7a0  mov eax, 0x846CA68B
0000748b9f9ce7a5  mov eax, eax
0000748b9f9ce7a7  mov [r15+0x48], rax
0000748b9f9ce7ab  mov eax, [r15]
0000748b9f9ce7ae  imul eax, eax, 0x7FEB352D
0000748b9f9ce7b4  mov [rsp+0x10], eax
0000748b9f9ce7b8  shr eax, 0x0F
0000748b9f9ce7bb  mov r14d, [rsp+0x10]
0000748b9f9ce7c0  xor r14d, eax
0000748b9f9ce7c3  imul r14d, r14d, 0x846CA68B
0000748b9f9ce7ca  mov [rsp+0x10], r14d
0000748b9f9ce7cf  mov r14d, r14d
0000748b9f9ce7d2  mov [r15+0x40], r14
0000748b9f9ce7d6  mov eax, [rsp+0x10]
0000748b9f9ce7da  shr eax, 0x10
0000748b9f9ce7dd  mov r14d, [rsp+0x10]
0000748b9f9ce7e2  xor r14d, eax
0000748b9f9ce7e5  mov r14d, r14d
0000748b9f9ce7e8  mov [r15], r14
0000748b9f9ce7eb  mov rax, [r15+0xF0]
0000748b9f9ce7f2  mov [r15+0x100], rax
0000748b9f9ce7f9  jmp 0x0000748B9F9CE5C0
0000748b9f9ce7fe  int3
0000748b9f9ce7ff  int3
0000748b9f9ce800  mov rax, [r15+0xA0]
0000748b9f9ce807  mov [rsp+0x10], rax
0000748b9f9ce80c  shl rax, 0x02
0000748b9f9ce810  mov r14, [r15+0x98]
0000748b9f9ce817  lea r12, [r14+rax*1]
0000748b9f9ce81b  mov eax, [r15]
0000748b9f9ce81e  mov [r13+r12*1], eax
0000748b9f9ce823  mov rax, [rsp+0x10]
0000748b9f9ce828  lea r14, [rax+0x01]
0000748b9f9ce82c  mov [r15+0xA0], r14
0000748b9f9ce833  xor eax, eax
0000748b9f9ce835  mov r12d, 0x400
0000748b9f9ce83b  cmp r14, r12
0000748b9f9ce83e  cmc
0000748b9f9ce83f  lahf
0000748b9f9ce840  seto al
0000748b9f9ce843  mov [r15+0x108], eax
0000748b9f9ce84a  mov eax, [r15+0x108]
0000748b9f9ce851  sahf
0000748b9f9ce852  jnz 0x0000748B9F9CE884
0000748b9f9ce854  cmp dword ptr [r15+0x318], 0x00
0000748b9f9ce85c  jz 0x0000748B9F9CE950
0000748b9f9ce862  nop [rax+rax*1], ax
0000748b9f9ce86b  nop [rax+rax*1], eax
0000748b9f9ce873  mov eax, 0x410194
0000748b9f9ce878  mov [r15+0x100], rax
0000748b9f9ce87f  jmp 0x0000748B9F7FE110
0000748b9f9ce884  cmp dword ptr [r15+0x318], 0x00
0000748b9f9ce88c  jz 0x0000748B9F9CE8C0
0000748b9f9ce892  nop [rax+rax*1], ax
0000748b9f9ce89b  nop [rax+rax*1], eax
0000748b9f9ce8a3  mov eax, 0x41017C
0000748b9f9ce8a8  mov [r15+0x100], rax
0000748b9f9ce8af  jmp 0x0000748B9F7FE110
0000748b9f9ce8b4  int3
0000748b9f9ce8b5  call 0x0000748B9F8B4B70
0000748b9f9ce8ba  jmp 0x0000748B9F9CE823
0000748b9f9ce8bf  int3
0000748b9f9ce8c0  mov eax, [r15+0xA0]
0000748b9f9ce8c7  lea r14d, [eax+0x11]
0000748b9f9ce8cc  mov r14d, r14d
0000748b9f9ce8cf  mov [r15], r14
0000748b9f9ce8d2  mov qword ptr [r15+0xF0], 0x410184
0000748b9f9ce8dd  mov r14d, [r15+0x320]
0000748b9f9ce8e4  mov eax, 0x410184
0000748b9f9ce8e9  mov rcx, 0x748B9F9CE800
0000748b9f9ce8f3  mov [r15+r14*8+0x328], rax
0000748b9f9ce8fb  mov [r15+r14*8+0x368], rcx
0000748b9f9ce903  add r14d, 0x01
0000748b9f9ce907  and r14d, 0x07
0000748b9f9ce90b  mov [r15+0x320], r14d
0000748b9f9ce912  cmp dword ptr [r15+0x318], 0x00
0000748b9f9ce91a  jz 0x0000748B9F9CE7A0
0000748b9f9ce920  nop [rax+rax*1], ax
0000748b9f9ce929  nop [rax+rax*1], eax
0000748b9f9ce931  mov eax, 0x41021C
0000748b9f9ce936  mov [r15+0x100], rax
0000748b9f9ce93d  jmp 0x0000748B9F7FE110
0000748b9f9ce942  int3
0000748b9f9ce943  int3
0000748b9f9ce944  nop [rax+rax*1], ax
0000748b9f9ce94d  nop [rax], eax
0000748b9f9ce950  mov qword ptr [r15+0x40], 0x01
0000748b9f9ce958  cmp dword ptr [r15+0x318], 0x00
0000748b9f9ce960  jz 0x0000748B9F9CE990
0000748b9f9ce966  nop [rax+rax*1], ax
0000748b9f9ce96f  nop [rax+rax*1], eax
0000748b9f9ce977  mov eax, 0x4101B0
0000748b9f9ce97c  mov [r15+0x100], rax
0000748b9f9ce983  jmp 0x0000748B9F7FE110
0000748b9f9ce988  int3
0000748b9f9ce989  int3
0000748b9f9ce98a  nop [rax+rax*1], ax
0000748b9f9ce990  mov rax, [r15+0x40]
0000748b9f9ce994  mov [rsp+0x10], rax
0000748b9f9ce999  shl rax, 0x02
0000748b9f9ce99d  mov r14, [r15+0x98]
0000748b9f9ce9a4  lea r12, [r14+rax*1]
0000748b9f9ce9a8  mov eax, [r13+r12*1]
0000748b9f9ce9ad  mov [rsp+0x20], eax
0000748b9f9ce9b1  mov eax, eax
0000748b9f9ce9b3  mov [r15+0x48], rax
0000748b9f9ce9b7  mov rax, [rsp+0x10]
0000748b9f9ce9bc  mov [r15+0x50], rax
0000748b9f9ce9c0  mov eax, [r15+0x50]
0000748b9f9ce9c4  lea r12d, [eax-0x01]
0000748b9f9ce9c9  mov r12d, r12d
0000748b9f9ce9cc  mov [r15+0x58], r12
0000748b9f9ce9d0  mov rax, [r15+0x58]
0000748b9f9ce9d4  mov r12d, eax
0000748b9f9ce9d7  mov r12d, r12d
0000748b9f9ce9da  shl r12, 0x02
0000748b9f9ce9de  lea rax, [r14+r12*1]
0000748b9f9ce9e2  mov r14d, [r13+rax*1]
0000748b9f9ce9e7  mov [rsp+0x10], r14d
0000748b9f9ce9ec  mov r14d, r14d
0000748b9f9ce9ef  mov [r15+0x60], r14
0000748b9f9ce9f3  xor eax, eax
0000748b9f9ce9f5  mov r14d, [rsp+0x10]
0000748b9f9ce9fa  mov r12d, [rsp+0x20]
0000748b9f9ce9ff  cmp r14d, r12d
0000748b9f9cea02  cmc
0000748b9f9cea03  lahf
0000748b9f9cea04  seto al
0000748b9f9cea07  mov [r15+0x108], eax
0000748b9f9cea0e  mov eax, [r15+0x108]
0000748b9f9cea15  sahf
0000748b9f9cea16  cmc
0000748b9f9cea17  jbe 0x0000748B9F9CEA49
0000748b9f9cea19  cmp dword ptr [r15+0x318], 0x00
0000748b9f9cea21  jz 0x0000748B9F9CEA90
0000748b9f9cea27  nop [rax+rax*1], ax
0000748b9f9cea30  nop [rax+rax*1], eax
0000748b9f9cea38  mov eax, 0x4101C8
0000748b9f9cea3d  mov [r15+0x100], rax
0000748b9f9cea44  jmp 0x0000748B9F7FE110
0000748b9f9cea49  cmp dword ptr [r15+0x318], 0x00
0000748b9f9cea51  jz 0x0000748B9F9CED30
0000748b9f9cea57  nop [rax+rax*1], ax
0000748b9f9cea60  nop [rax+rax*1], eax
0000748b9f9cea68  mov eax, 0x4101A0
0000748b9f9cea6d  mov [r15+0x100], rax
0000748b9f9cea74  jmp 0x0000748B9F7FE110
0000748b9f9cea79  int3
0000748b9f9cea7a  call 0x0000748B9F8B4690
0000748b9f9cea7f  jmp 0x0000748B9F9CE9AD
0000748b9f9cea84  call 0x0000748B9F80DAE0
0000748b9f9cea89  jmp 0x0000748B9F9CE9E7
0000748b9f9cea8e  int3
0000748b9f9cea8f  nop
0000748b9f9cea90  mov rax, [r15+0x50]
0000748b9f9cea94  mov [rsp+0x10], rax
0000748b9f9cea99  shl rax, 0x02
0000748b9f9cea9d  mov r14, [r15+0x98]
0000748b9f9ceaa4  lea r12, [r14+rax*1]
0000748b9f9ceaa8  mov eax, [r15+0x60]
0000748b9f9ceaac  mov [r13+r12*1], eax
0000748b9f9ceab1  mov rax, [rsp+0x10]
0000748b9f9ceab6  lea r14, [rax-0x01]
0000748b9f9ceaba  mov [r15+0x50], r14
0000748b9f9ceabe  mov rax, [r15+0x58]
0000748b9f9ceac2  test rax, rax
0000748b9f9ceac5  setz al
0000748b9f9ceac8  movzx rax, al
0000748b9f9ceacc  mov [rsp+0x414], al
0000748b9f9cead3  cmp byte ptr [rsp+0x414], 0x00
0000748b9f9ceadb  jz 0x0000748B9F9CEB0D
0000748b9f9ceadd  cmp dword ptr [r15+0x318], 0x00
0000748b9f9ceae5  jz 0x0000748B9F9CEB50
0000748b9f9ceaeb  nop [rax+rax*1], ax
0000748b9f9ceaf4  nop [rax+rax*1], eax
0000748b9f9ceafc  mov eax, 0x4101D4
0000748b9f9ceb01  mov [r15+0x100], rax
0000748b9f9ceb08  jmp 0x0000748B9F7FE110
0000748b9f9ceb0d  cmp dword ptr [r15+0x318], 0x00
0000748b9f9ceb15  jz 0x0000748B9F9CEC50
0000748b9f9ceb1b  nop [rax+rax*1], ax
0000748b9f9ceb24  nop [rax+rax*1], eax
0000748b9f9ceb2c  mov eax, 0x4101B8
0000748b9f9ceb31  mov [r15+0x100], rax
0000748b9f9ceb38  jmp 0x0000748B9F7FE110
0000748b9f9ceb3d  int3
0000748b9f9ceb3e  call 0x0000748B9F8B4B70
0000748b9f9ceb43  jmp 0x0000748B9F9CEAB1
0000748b9f9ceb48  int3
0000748b9f9ceb49  nop [rax], eax
0000748b9f9ceb50  cmp dword ptr [r15+0x318], 0x00
0000748b9f9ceb58  jz 0x0000748B9F9CEB90
0000748b9f9ceb5e  nop [rax+rax*1], ax
0000748b9f9ceb67  nop [rax+rax*1], eax
0000748b9f9ceb6f  mov eax, 0x41019C
0000748b9f9ceb74  mov [r15+0x100], rax
0000748b9f9ceb7b  jmp 0x0000748B9F7FE110
0000748b9f9ceb80  int3
0000748b9f9ceb81  int3
0000748b9f9ceb82  nop [rax+rax*1], ax
0000748b9f9ceb8b  nop [rax+rax*1], eax
0000748b9f9ceb90  mov qword ptr [r15+0x50], 0x00
0000748b9f9ceb98  mov rax, [r15+0x40]
0000748b9f9ceb9c  lea r14, [rax+0x01]
0000748b9f9ceba0  mov [r15+0x40], r14
0000748b9f9ceba4  mov rax, [r15+0x98]
0000748b9f9cebab  mov r12d, [r15+0x48]
0000748b9f9cebaf  mov [r13+rax*1], r12d
0000748b9f9cebb4  xor eax, eax
0000748b9f9cebb6  mov r12d, 0x400
0000748b9f9cebbc  cmp r14, r12
0000748b9f9cebbf  cmc
0000748b9f9cebc0  lahf
0000748b9f9cebc1  seto al
0000748b9f9cebc4  mov [r15+0x108], eax
0000748b9f9cebcb  mov eax, [r15+0x108]
0000748b9f9cebd2  sahf
0000748b9f9cebd3  jz 0x0000748B9F9CEC05
0000748b9f9cebd5  cmp dword ptr [r15+0x318], 0x00
0000748b9f9cebdd  jz 0x0000748B9F9CE990
0000748b9f9cebe3  nop [rax+rax*1], ax
0000748b9f9cebec  nop [rax+rax*1], eax
0000748b9f9cebf4  mov eax, 0x4101B0
0000748b9f9cebf9  mov [r15+0x100], rax
0000748b9f9cec00  jmp 0x0000748B9F7FE110
0000748b9f9cec05  cmp dword ptr [r15+0x318], 0x00
0000748b9f9cec0d  jz 0x0000748B9F9CEDF0
0000748b9f9cec13  nop [rax+rax*1], ax
0000748b9f9cec1c  nop [rax+rax*1], eax
0000748b9f9cec24  mov eax, 0x4101D8
0000748b9f9cec29  mov [r15+0x100], rax
0000748b9f9cec30  jmp 0x0000748B9F7FE110
0000748b9f9cec35  int3
0000748b9f9cec36  call 0x0000748B9F80BAE0
0000748b9f9cec3b  jmp 0x0000748B9F9CEBB4
0000748b9f9cec40  int3
0000748b9f9cec41  nop [rax+rax*1], ax
0000748b9f9cec4a  nop [rax+rax*1], ax
0000748b9f9cec50  mov eax, [r15+0x50]
0000748b9f9cec54  lea r14d, [eax-0x01]
0000748b9f9cec59  mov r14d, r14d
0000748b9f9cec5c  mov [r15+0x58], r14
0000748b9f9cec60  mov rax, [r15+0x58]
0000748b9f9cec64  mov r14d, eax
0000748b9f9cec67  mov r14d, r14d
0000748b9f9cec6a  shl r14, 0x02
0000748b9f9cec6e  mov rax, [r15+0x98]
0000748b9f9cec75  lea r12, [rax+r14*1]
0000748b9f9cec79  mov eax, [r13+r12*1]
0000748b9f9cec7e  mov [rsp+0x10], eax
0000748b9f9cec82  mov eax, eax
0000748b9f9cec84  mov [r15+0x60], rax
0000748b9f9cec88  mov eax, [r15+0x48]
0000748b9f9cec8c  mov [rsp+0x20], eax
0000748b9f9cec90  xor eax, eax
0000748b9f9cec92  mov r14d, [rsp+0x10]
0000748b9f9cec97  mov r12d, [rsp+0x20]
0000748b9f9cec9c  cmp r14d, r12d
0000748b9f9cec9f  cmc
0000748b9f9ceca0  lahf
0000748b9f9ceca1  seto al
0000748b9f9ceca4  mov [r15+0x108], eax
0000748b9f9cecab  mov eax, [r15+0x108]
0000748b9f9cecb2  sahf
0000748b9f9cecb3  cmc
0000748b9f9cecb4  jbe 0x0000748B9F9CECE6
0000748b9f9cecb6  cmp dword ptr [r15+0x318], 0x00
0000748b9f9cecbe  jz 0x0000748B9F9CEA90
0000748b9f9cecc4  nop [rax+rax*1], ax
0000748b9f9ceccd  nop [rax+rax*1], eax
0000748b9f9cecd5  mov eax, 0x4101C8
0000748b9f9cecda  mov [r15+0x100], rax
0000748b9f9cece1  jmp 0x0000748B9F7FE110
0000748b9f9cece6  cmp dword ptr [r15+0x318], 0x00
0000748b9f9cecee  jz 0x0000748B9F9CED30
0000748b9f9cecf4  nop [rax+rax*1], ax
0000748b9f9cecfd  nop [rax+rax*1], eax
0000748b9f9ced05  mov eax, 0x4101A0
0000748b9f9ced0a  mov [r15+0x100], rax
0000748b9f9ced11  jmp 0x0000748B9F7FE110
0000748b9f9ced16  int3
0000748b9f9ced17  call 0x0000748B9F8B4690
0000748b9f9ced1c  jmp 0x0000748B9F9CEC7E
0000748b9f9ced21  int3
0000748b9f9ced22  nop [rax+rax*1], ax
0000748b9f9ced2b  nop [rax+rax*1], eax
0000748b9f9ced30  mov rax, [r15+0x40]
0000748b9f9ced34  lea r14, [rax+0x01]
0000748b9f9ced38  mov [r15+0x40], r14
0000748b9f9ced3c  mov rax, [r15+0x50]
0000748b9f9ced40  mov r12d, eax
0000748b9f9ced43  mov r12d, r12d
0000748b9f9ced46  shl r12, 0x02
0000748b9f9ced4a  mov rax, [r15+0x98]
0000748b9f9ced51  lea r11, [rax+r12*1]
0000748b9f9ced55  mov eax, [r15+0x48]
0000748b9f9ced59  mov [r13+r11*1], eax
0000748b9f9ced5e  xor eax, eax
0000748b9f9ced60  mov r12d, 0x400
0000748b9f9ced66  cmp r14, r12
0000748b9f9ced69  cmc
0000748b9f9ced6a  lahf
0000748b9f9ced6b  seto al
0000748b9f9ced6e  mov [r15+0x108], eax
0000748b9f9ced75  mov eax, [r15+0x108]
0000748b9f9ced7c  sahf
0000748b9f9ced7d  jz 0x0000748B9F9CEDAF
0000748b9f9ced7f  cmp dword ptr [r15+0x318], 0x00
0000748b9f9ced87  jz 0x0000748B9F9CE990
0000748b9f9ced8d  nop [rax+rax*1], ax
0000748b9f9ced96  nop [rax+rax*1], eax
0000748b9f9ced9e  mov eax, 0x4101B0
0000748b9f9ceda3  mov [r15+0x100], rax
0000748b9f9cedaa  jmp 0x0000748B9F7FE110
0000748b9f9cedaf  cmp dword ptr [r15+0x318], 0x00
0000748b9f9cedb7  jz 0x0000748B9F9CEDF0
0000748b9f9cedbd  nop [rax+rax*1], ax
0000748b9f9cedc6  nop [rax+rax*1], eax
0000748b9f9cedce  mov eax, 0x4101D8
0000748b9f9cedd3  mov [r15+0x100], rax
0000748b9f9cedda  jmp 0x0000748B9F7FE110
0000748b9f9ceddf  int3
0000748b9f9cede0  call 0x0000748B9F8A4270
0000748b9f9cede5  jmp 0x0000748B9F9CED5E
0000748b9f9cedea  int3
0000748b9f9cedeb  nop [rax+rax*1], eax
0000748b9f9cedf0  mov qword ptr [r15+0x40], 0x420000
0000748b9f9cedf8  mov eax, 0x420288
0000748b9f9cedfd  mov r14, [r13+rax*1]
0000748b9f9cee02  mov rax, [r15+0x98]
0000748b9f9cee09  mov r12d, [r13+rax*1]
0000748b9f9cee0e  lea r11, [rax+0x04]
0000748b9f9cee12  mov eax, [r13+r11*1]
0000748b9f9cee17  mov r12d, r12d
0000748b9f9cee1a  mov [r15+0x68], r12
0000748b9f9cee1e  mov eax, eax
0000748b9f9cee20  mov [r15+0x60], rax
0000748b9f9cee24  mov rax, [r15+0x68]
0000748b9f9cee28  mov [r15+0x68], rax
0000748b9f9cee2c  mov qword ptr [r15+0x58], 0x02
0000748b9f9cee34  mov [rsp+0x10], rax
0000748b9f9cee39  xor eax, eax
0000748b9f9cee3b  mov r12d, 0x02
0000748b9f9cee41  mov r11d, 0x400
0000748b9f9cee47  cmp r12, r11
0000748b9f9cee4a  cmc
0000748b9f9cee4b  lahf
0000748b9f9cee4c  seto al
0000748b9f9cee4f  mov [r15+0x108], eax
0000748b9f9cee56  mov rax, [r15+0x60]
0000748b9f9cee5a  mov r12d, 0x02
0000748b9f9cee60  imul rax, r12
0000748b9f9cee64  mov [r15+0x50], rax
0000748b9f9cee68  mov rax, [rsp+0x10]
0000748b9f9cee6d  lea r12, [rax+r14*1]
0000748b9f9cee71  mov [r15+0x48], r12
0000748b9f9cee75  mov eax, [r15+0x108]
0000748b9f9cee7c  sahf
0000748b9f9cee7d  jnz 0x0000748B9F9CEEAF
0000748b9f9cee7f  cmp dword ptr [r15+0x318], 0x00
0000748b9f9cee87  jz 0x0000748B9F9CF020
0000748b9f9cee8d  nop [rax+rax*1], ax
0000748b9f9cee96  nop [rax+rax*1], eax
0000748b9f9cee9e  mov eax, 0x410208
0000748b9f9ceea3  mov [r15+0x100], rax
0000748b9f9ceeaa  jmp 0x0000748B9F7FE110
0000748b9f9ceeaf  cmp dword ptr [r15+0x318], 0x00
0000748b9f9ceeb7  jz 0x0000748B9F9CEF00
0000748b9f9ceebd  nop [rax+rax*1], ax
0000748b9f9ceec6  nop [rax+rax*1], eax
0000748b9f9ceece  mov eax, 0x4101E8
0000748b9f9ceed3  mov [r15+0x100], rax
0000748b9f9ceeda  jmp 0x0000748B9F7FE110
0000748b9f9ceedf  int3
0000748b9f9ceee0  call 0x0000748B9F80DC20
0000748b9f9ceee5  jmp 0x0000748B9F9CEE02
0000748b9f9ceeea  call 0x0000748B9F80B5E0
0000748b9f9ceeef  jmp 0x0000748B9F9CEE0E
0000748b9f9ceef4  call 0x0000748B9F8A3D90
0000748b9f9ceef9  jmp 0x0000748B9F9CEE17
0000748b9f9ceefe  int3
0000748b9f9ceeff  nop
0000748b9f9cef00  mov rax, [r15+0x98]
0000748b9f9cef07  mov r14, [r15+0x58]
0000748b9f9cef0b  mov [rsp+0x10], r14
0000748b9f9cef10  shl r14, 0x02
0000748b9f9cef14  lea r12, [rax+r14*1]
0000748b9f9cef18  mov eax, [r13+r12*1]
0000748b9f9cef1d  lea r14, [r12+0x04]
0000748b9f9cef22  mov r12d, [r13+r14*1]
0000748b9f9cef27  mov eax, eax
0000748b9f9cef29  mov [r15+0x68], rax
0000748b9f9cef2d  mov r12d, r12d
0000748b9f9cef30  mov [r15+0x60], r12
0000748b9f9cef34  mov rax, [r15+0x68]
0000748b9f9cef38  mov [rsp+0x20], rax
0000748b9f9cef3d  mov r14, [rsp+0x10]
0000748b9f9cef42  imul rax, r14
0000748b9f9cef46  mov r12, [rsp+0x20]
0000748b9f9cef4b  lea r11, [r12+rax*1]
0000748b9f9cef4f  mov [r15+0x68], r11
0000748b9f9cef53  lea rax, [r14+0x02]
0000748b9f9cef57  mov [r15+0x58], rax
0000748b9f9cef5b  mov [rsp+0x10], rax
0000748b9f9cef60  xor eax, eax
0000748b9f9cef62  mov r14, [rsp+0x10]
0000748b9f9cef67  mov r12d, 0x400
0000748b9f9cef6d  cmp r14, r12
0000748b9f9cef70  cmc
0000748b9f9cef71  lahf
0000748b9f9cef72  seto al
0000748b9f9cef75  mov [r15+0x108], eax
0000748b9f9cef7c  mov rax, [r15+0x50]
0000748b9f9cef80  mov r12, [r15+0x60]
0000748b9f9cef84  imul r14, r12
0000748b9f9cef88  lea r12, [rax+r14*1]
0000748b9f9cef8c  mov [r15+0x50], r12
0000748b9f9cef90  mov rax, [r15+0x48]
0000748b9f9cef94  lea r14, [r11+rax*1]
0000748b9f9cef98  mov [r15+0x48], r14
0000748b9f9cef9c  mov eax, [r15+0x108]
0000748b9f9cefa3  sahf
0000748b9f9cefa4  jnz 0x0000748B9F9CEFD6
0000748b9f9cefa6  cmp dword ptr [r15+0x318], 0x00
0000748b9f9cefae  jz 0x0000748B9F9CF020
0000748b9f9cefb4  nop [rax+rax*1], ax
0000748b9f9cefbd  nop [rax+rax*1], eax
0000748b9f9cefc5  mov eax, 0x410208
0000748b9f9cefca  mov [r15+0x100], rax
0000748b9f9cefd1  jmp 0x0000748B9F7FE110
0000748b9f9cefd6  cmp dword ptr [r15+0x318], 0x00
0000748b9f9cefde  jz 0x0000748B9F9CEF00
0000748b9f9cefe4  nop [rax+rax*1], ax
0000748b9f9cefed  nop [rax+rax*1], eax
0000748b9f9ceff5  mov eax, 0x4101E8
0000748b9f9ceffa  mov [r15+0x100], rax
0000748b9f9cf001  jmp 0x0000748B9F7FE110
0000748b9f9cf006  int3
0000748b9f9cf007  call 0x0000748B9F8B4690
0000748b9f9cf00c  jmp 0x0000748B9F9CEF1D
0000748b9f9cf011  call 0x0000748B9F8E26A0
0000748b9f9cf016  jmp 0x0000748B9F9CEF27
0000748b9f9cf01b  int3
0000748b9f9cf01c  nop [rax], eax
0000748b9f9cf020  mov rax, [r15+0xF8]
0000748b9f9cf027  lea r14, [rax+0x10]
0000748b9f9cf02b  mov r12, [r13+r14*1]
0000748b9f9cf030  lea r14, [rax+0x18]
0000748b9f9cf034  mov r11, [r13+r14*1]
0000748b9f9cf039  mov [r15+0xA0], r12
0000748b9f9cf040  mov [r15+0x98], r11
0000748b9f9cf047  mov r14, [r15+0x50]
0000748b9f9cf04b  mov r12, [r15+0x48]
0000748b9f9cf04f  lea r11, [r14+r12*1]
0000748b9f9cf053  mov [r15+0x48], r11
0000748b9f9cf057  mov r14, [r15+0x40]
0000748b9f9cf05b  lea r12, [r14+0x288]
0000748b9f9cf062  mov [r13+r12*1], r11
0000748b9f9cf067  mov r14, [r13+rax*1]
0000748b9f9cf06c  mov [r15+0xF0], r14
0000748b9f9cf073  lea r12, [rax+0x20]
0000748b9f9cf077  mov [r15+0xF8], r12
0000748b9f9cf07e  mov [r15+0x100], r14
0000748b9f9cf085  jmp 0x0000748B9F9CE5C0
0000748b9f9cf08a  int3
0000748b9f9cf08b  call 0x0000748B9F8E27E0
0000748b9f9cf090  jmp 0x0000748B9F9CF030
0000748b9f9cf095  call 0x0000748B9F8E1570
0000748b9f9cf09a  jmp 0x0000748B9F9CF039
0000748b9f9cf09f  call 0x0000748B9F8C0860
0000748b9f9cf0a4  jmp 0x0000748B9F9CF067
0000748b9f9cf0a9  call 0x0000748B9F80DC20
0000748b9f9cf0ae  jmp 0x0000748B9F9CF06C
0000748b9f9cf0b3  int3
0000748b9f9cf0b4  nop [rax+rax*1], ax
0000748b9f9cf0bd  nop [rax], eax
0000748b9f9cf0c0  mov qword ptr [r15+0x100], 0x04
0000748b9f9cf0cb  mov esi, 0x00
0000748b9f9cf0d0  mov edx, 0x09
0000748b9f9cf0d5  mov rdi, 0x7FFD1E88E9F0
0000748b9f9cf0df  mov rax, 0x5FFA8C08D970
0000748b9f9cf0e9  call rax
0000748b9f9cf0eb  cmp dword ptr [r15+0x318], 0x00
0000748b9f9cf0f3  jnz 0x0000748B9F7FE110
0000748b9f9cf0f9  jmp 0x0000748B9F7FE0A0
0000748b9f9cf0fe  int3
0000748b9f9cf0ff  int3
