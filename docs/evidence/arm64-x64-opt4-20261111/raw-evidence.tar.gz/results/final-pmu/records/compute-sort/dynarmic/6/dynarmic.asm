00007e37b4dce69b  nop [rax+rax*1], eax
00007e37b4dce6a0  mov rax, [r15+0xF8]
00007e37b4dce6a7  lea r14, [rax-0x20]
00007e37b4dce6ab  mov r12, [r15+0xF0]
00007e37b4dce6b2  mov [r13+r14*1], r12
00007e37b4dce6b7  mov [r15+0xF8], r14
00007e37b4dce6be  lea r14, [rax-0x10]
00007e37b4dce6c2  mov r12, [r15+0xA0]
00007e37b4dce6c9  mov r11, [r15+0x98]
00007e37b4dce6d0  mov [r13+r14*1], r12
00007e37b4dce6d5  lea r14, [rax-0x08]
00007e37b4dce6d9  mov [r13+r14*1], r11
00007e37b4dce6de  mov qword ptr [r15+0xA0], 0x00
00007e37b4dce6e9  mov qword ptr [r15+0x98], 0x4202A0
00007e37b4dce6f4  mov eax, [r15+0xA0]
00007e37b4dce6fb  lea r14d, [eax+0x11]
00007e37b4dce700  mov r14d, r14d
00007e37b4dce703  mov [r15], r14
00007e37b4dce706  mov qword ptr [r15+0xF0], 0x410184
00007e37b4dce711  mov r14d, [r15+0x320]
00007e37b4dce718  mov eax, 0x410184
00007e37b4dce71d  mov rcx, 0x7E37B4DCE800
00007e37b4dce727  mov [r15+r14*8+0x328], rax
00007e37b4dce72f  mov [r15+r14*8+0x368], rcx
00007e37b4dce737  add r14d, 0x01
00007e37b4dce73b  and r14d, 0x07
00007e37b4dce73f  mov [r15+0x320], r14d
00007e37b4dce746  cmp dword ptr [r15+0x318], 0x00
00007e37b4dce74e  jz 0x00007E37B4DCE7A0
00007e37b4dce754  nop [rax+rax*1], ax
00007e37b4dce75d  nop [rax+rax*1], eax
00007e37b4dce765  mov eax, 0x41021C
00007e37b4dce76a  mov [r15+0x100], rax
00007e37b4dce771  jmp 0x00007E37B4BFE110
00007e37b4dce776  int3
00007e37b4dce777  call 0x00007E37B4CE2CE0
00007e37b4dce77c  jmp 0x00007E37B4DCE6B7
00007e37b4dce781  call 0x00007E37B4CE2CE0
00007e37b4dce786  jmp 0x00007E37B4DCE6D5
00007e37b4dce78b  call 0x00007E37B4CE1A60
00007e37b4dce790  jmp 0x00007E37B4DCE6DE
00007e37b4dce795  int3
00007e37b4dce796  nop [rax+rax*1], ax
00007e37b4dce79f  nop
00007e37b4dce7a0  mov eax, 0x846CA68B
00007e37b4dce7a5  mov eax, eax
00007e37b4dce7a7  mov [r15+0x48], rax
00007e37b4dce7ab  mov eax, [r15]
00007e37b4dce7ae  imul eax, eax, 0x7FEB352D
00007e37b4dce7b4  mov [rsp+0x10], eax
00007e37b4dce7b8  shr eax, 0x0F
00007e37b4dce7bb  mov r14d, [rsp+0x10]
00007e37b4dce7c0  xor r14d, eax
00007e37b4dce7c3  imul r14d, r14d, 0x846CA68B
00007e37b4dce7ca  mov [rsp+0x10], r14d
00007e37b4dce7cf  mov r14d, r14d
00007e37b4dce7d2  mov [r15+0x40], r14
00007e37b4dce7d6  mov eax, [rsp+0x10]
00007e37b4dce7da  shr eax, 0x10
00007e37b4dce7dd  mov r14d, [rsp+0x10]
00007e37b4dce7e2  xor r14d, eax
00007e37b4dce7e5  mov r14d, r14d
00007e37b4dce7e8  mov [r15], r14
00007e37b4dce7eb  mov rax, [r15+0xF0]
00007e37b4dce7f2  mov [r15+0x100], rax
00007e37b4dce7f9  jmp 0x00007E37B4DCE5C0
00007e37b4dce7fe  int3
00007e37b4dce7ff  int3
00007e37b4dce800  mov rax, [r15+0xA0]
00007e37b4dce807  mov [rsp+0x10], rax
00007e37b4dce80c  shl rax, 0x02
00007e37b4dce810  mov r14, [r15+0x98]
00007e37b4dce817  lea r12, [r14+rax*1]
00007e37b4dce81b  mov eax, [r15]
00007e37b4dce81e  mov [r13+r12*1], eax
00007e37b4dce823  mov rax, [rsp+0x10]
00007e37b4dce828  lea r14, [rax+0x01]
00007e37b4dce82c  mov [r15+0xA0], r14
00007e37b4dce833  xor eax, eax
00007e37b4dce835  mov r12d, 0x400
00007e37b4dce83b  cmp r14, r12
00007e37b4dce83e  cmc
00007e37b4dce83f  lahf
00007e37b4dce840  seto al
00007e37b4dce843  mov [r15+0x108], eax
00007e37b4dce84a  mov eax, [r15+0x108]
00007e37b4dce851  sahf
00007e37b4dce852  jnz 0x00007E37B4DCE884
00007e37b4dce854  cmp dword ptr [r15+0x318], 0x00
00007e37b4dce85c  jz 0x00007E37B4DCE950
00007e37b4dce862  nop [rax+rax*1], ax
00007e37b4dce86b  nop [rax+rax*1], eax
00007e37b4dce873  mov eax, 0x410194
00007e37b4dce878  mov [r15+0x100], rax
00007e37b4dce87f  jmp 0x00007E37B4BFE110
00007e37b4dce884  cmp dword ptr [r15+0x318], 0x00
00007e37b4dce88c  jz 0x00007E37B4DCE8C0
00007e37b4dce892  nop [rax+rax*1], ax
00007e37b4dce89b  nop [rax+rax*1], eax
00007e37b4dce8a3  mov eax, 0x41017C
00007e37b4dce8a8  mov [r15+0x100], rax
00007e37b4dce8af  jmp 0x00007E37B4BFE110
00007e37b4dce8b4  int3
00007e37b4dce8b5  call 0x00007E37B4CB4B70
00007e37b4dce8ba  jmp 0x00007E37B4DCE823
00007e37b4dce8bf  int3
00007e37b4dce8c0  mov eax, [r15+0xA0]
00007e37b4dce8c7  lea r14d, [eax+0x11]
00007e37b4dce8cc  mov r14d, r14d
00007e37b4dce8cf  mov [r15], r14
00007e37b4dce8d2  mov qword ptr [r15+0xF0], 0x410184
00007e37b4dce8dd  mov r14d, [r15+0x320]
00007e37b4dce8e4  mov eax, 0x410184
00007e37b4dce8e9  mov rcx, 0x7E37B4DCE800
00007e37b4dce8f3  mov [r15+r14*8+0x328], rax
00007e37b4dce8fb  mov [r15+r14*8+0x368], rcx
00007e37b4dce903  add r14d, 0x01
00007e37b4dce907  and r14d, 0x07
00007e37b4dce90b  mov [r15+0x320], r14d
00007e37b4dce912  cmp dword ptr [r15+0x318], 0x00
00007e37b4dce91a  jz 0x00007E37B4DCE7A0
00007e37b4dce920  nop [rax+rax*1], ax
00007e37b4dce929  nop [rax+rax*1], eax
00007e37b4dce931  mov eax, 0x41021C
00007e37b4dce936  mov [r15+0x100], rax
00007e37b4dce93d  jmp 0x00007E37B4BFE110
00007e37b4dce942  int3
00007e37b4dce943  int3
00007e37b4dce944  nop [rax+rax*1], ax
00007e37b4dce94d  nop [rax], eax
00007e37b4dce950  mov qword ptr [r15+0x40], 0x01
00007e37b4dce958  cmp dword ptr [r15+0x318], 0x00
00007e37b4dce960  jz 0x00007E37B4DCE990
00007e37b4dce966  nop [rax+rax*1], ax
00007e37b4dce96f  nop [rax+rax*1], eax
00007e37b4dce977  mov eax, 0x4101B0
00007e37b4dce97c  mov [r15+0x100], rax
00007e37b4dce983  jmp 0x00007E37B4BFE110
00007e37b4dce988  int3
00007e37b4dce989  int3
00007e37b4dce98a  nop [rax+rax*1], ax
00007e37b4dce990  mov rax, [r15+0x40]
00007e37b4dce994  mov [rsp+0x10], rax
00007e37b4dce999  shl rax, 0x02
00007e37b4dce99d  mov r14, [r15+0x98]
00007e37b4dce9a4  lea r12, [r14+rax*1]
00007e37b4dce9a8  mov eax, [r13+r12*1]
00007e37b4dce9ad  mov [rsp+0x20], eax
00007e37b4dce9b1  mov eax, eax
00007e37b4dce9b3  mov [r15+0x48], rax
00007e37b4dce9b7  mov rax, [rsp+0x10]
00007e37b4dce9bc  mov [r15+0x50], rax
00007e37b4dce9c0  mov eax, [r15+0x50]
00007e37b4dce9c4  lea r12d, [eax-0x01]
00007e37b4dce9c9  mov r12d, r12d
00007e37b4dce9cc  mov [r15+0x58], r12
00007e37b4dce9d0  mov rax, [r15+0x58]
00007e37b4dce9d4  mov r12d, eax
00007e37b4dce9d7  mov r12d, r12d
00007e37b4dce9da  shl r12, 0x02
00007e37b4dce9de  lea rax, [r14+r12*1]
00007e37b4dce9e2  mov r14d, [r13+rax*1]
00007e37b4dce9e7  mov [rsp+0x10], r14d
00007e37b4dce9ec  mov r14d, r14d
00007e37b4dce9ef  mov [r15+0x60], r14
00007e37b4dce9f3  xor eax, eax
00007e37b4dce9f5  mov r14d, [rsp+0x10]
00007e37b4dce9fa  mov r12d, [rsp+0x20]
00007e37b4dce9ff  cmp r14d, r12d
00007e37b4dcea02  cmc
00007e37b4dcea03  lahf
00007e37b4dcea04  seto al
00007e37b4dcea07  mov [r15+0x108], eax
00007e37b4dcea0e  mov eax, [r15+0x108]
00007e37b4dcea15  sahf
00007e37b4dcea16  cmc
00007e37b4dcea17  jbe 0x00007E37B4DCEA49
00007e37b4dcea19  cmp dword ptr [r15+0x318], 0x00
00007e37b4dcea21  jz 0x00007E37B4DCEA90
00007e37b4dcea27  nop [rax+rax*1], ax
00007e37b4dcea30  nop [rax+rax*1], eax
00007e37b4dcea38  mov eax, 0x4101C8
00007e37b4dcea3d  mov [r15+0x100], rax
00007e37b4dcea44  jmp 0x00007E37B4BFE110
00007e37b4dcea49  cmp dword ptr [r15+0x318], 0x00
00007e37b4dcea51  jz 0x00007E37B4DCED30
00007e37b4dcea57  nop [rax+rax*1], ax
00007e37b4dcea60  nop [rax+rax*1], eax
00007e37b4dcea68  mov eax, 0x4101A0
00007e37b4dcea6d  mov [r15+0x100], rax
00007e37b4dcea74  jmp 0x00007E37B4BFE110
00007e37b4dcea79  int3
00007e37b4dcea7a  call 0x00007E37B4CB4690
00007e37b4dcea7f  jmp 0x00007E37B4DCE9AD
00007e37b4dcea84  call 0x00007E37B4C0DAE0
00007e37b4dcea89  jmp 0x00007E37B4DCE9E7
00007e37b4dcea8e  int3
00007e37b4dcea8f  nop
00007e37b4dcea90  mov rax, [r15+0x50]
00007e37b4dcea94  mov [rsp+0x10], rax
00007e37b4dcea99  shl rax, 0x02
00007e37b4dcea9d  mov r14, [r15+0x98]
00007e37b4dceaa4  lea r12, [r14+rax*1]
00007e37b4dceaa8  mov eax, [r15+0x60]
00007e37b4dceaac  mov [r13+r12*1], eax
00007e37b4dceab1  mov rax, [rsp+0x10]
00007e37b4dceab6  lea r14, [rax-0x01]
00007e37b4dceaba  mov [r15+0x50], r14
00007e37b4dceabe  mov rax, [r15+0x58]
00007e37b4dceac2  test rax, rax
00007e37b4dceac5  setz al
00007e37b4dceac8  movzx rax, al
00007e37b4dceacc  mov [rsp+0x414], al
00007e37b4dcead3  cmp byte ptr [rsp+0x414], 0x00
00007e37b4dceadb  jz 0x00007E37B4DCEB0D
00007e37b4dceadd  cmp dword ptr [r15+0x318], 0x00
00007e37b4dceae5  jz 0x00007E37B4DCEB50
00007e37b4dceaeb  nop [rax+rax*1], ax
00007e37b4dceaf4  nop [rax+rax*1], eax
00007e37b4dceafc  mov eax, 0x4101D4
00007e37b4dceb01  mov [r15+0x100], rax
00007e37b4dceb08  jmp 0x00007E37B4BFE110
00007e37b4dceb0d  cmp dword ptr [r15+0x318], 0x00
00007e37b4dceb15  jz 0x00007E37B4DCEC50
00007e37b4dceb1b  nop [rax+rax*1], ax
00007e37b4dceb24  nop [rax+rax*1], eax
00007e37b4dceb2c  mov eax, 0x4101B8
00007e37b4dceb31  mov [r15+0x100], rax
00007e37b4dceb38  jmp 0x00007E37B4BFE110
00007e37b4dceb3d  int3
00007e37b4dceb3e  call 0x00007E37B4CB4B70
00007e37b4dceb43  jmp 0x00007E37B4DCEAB1
00007e37b4dceb48  int3
00007e37b4dceb49  nop [rax], eax
00007e37b4dceb50  cmp dword ptr [r15+0x318], 0x00
00007e37b4dceb58  jz 0x00007E37B4DCEB90
00007e37b4dceb5e  nop [rax+rax*1], ax
00007e37b4dceb67  nop [rax+rax*1], eax
00007e37b4dceb6f  mov eax, 0x41019C
00007e37b4dceb74  mov [r15+0x100], rax
00007e37b4dceb7b  jmp 0x00007E37B4BFE110
00007e37b4dceb80  int3
00007e37b4dceb81  int3
00007e37b4dceb82  nop [rax+rax*1], ax
00007e37b4dceb8b  nop [rax+rax*1], eax
00007e37b4dceb90  mov qword ptr [r15+0x50], 0x00
00007e37b4dceb98  mov rax, [r15+0x40]
00007e37b4dceb9c  lea r14, [rax+0x01]
00007e37b4dceba0  mov [r15+0x40], r14
00007e37b4dceba4  mov rax, [r15+0x98]
00007e37b4dcebab  mov r12d, [r15+0x48]
00007e37b4dcebaf  mov [r13+rax*1], r12d
00007e37b4dcebb4  xor eax, eax
00007e37b4dcebb6  mov r12d, 0x400
00007e37b4dcebbc  cmp r14, r12
00007e37b4dcebbf  cmc
00007e37b4dcebc0  lahf
00007e37b4dcebc1  seto al
00007e37b4dcebc4  mov [r15+0x108], eax
00007e37b4dcebcb  mov eax, [r15+0x108]
00007e37b4dcebd2  sahf
00007e37b4dcebd3  jz 0x00007E37B4DCEC05
00007e37b4dcebd5  cmp dword ptr [r15+0x318], 0x00
00007e37b4dcebdd  jz 0x00007E37B4DCE990
00007e37b4dcebe3  nop [rax+rax*1], ax
00007e37b4dcebec  nop [rax+rax*1], eax
00007e37b4dcebf4  mov eax, 0x4101B0
00007e37b4dcebf9  mov [r15+0x100], rax
00007e37b4dcec00  jmp 0x00007E37B4BFE110
00007e37b4dcec05  cmp dword ptr [r15+0x318], 0x00
00007e37b4dcec0d  jz 0x00007E37B4DCEDF0
00007e37b4dcec13  nop [rax+rax*1], ax
00007e37b4dcec1c  nop [rax+rax*1], eax
00007e37b4dcec24  mov eax, 0x4101D8
00007e37b4dcec29  mov [r15+0x100], rax
00007e37b4dcec30  jmp 0x00007E37B4BFE110
00007e37b4dcec35  int3
00007e37b4dcec36  call 0x00007E37B4C0BAE0
00007e37b4dcec3b  jmp 0x00007E37B4DCEBB4
00007e37b4dcec40  int3
00007e37b4dcec41  nop [rax+rax*1], ax
00007e37b4dcec4a  nop [rax+rax*1], ax
00007e37b4dcec50  mov eax, [r15+0x50]
00007e37b4dcec54  lea r14d, [eax-0x01]
00007e37b4dcec59  mov r14d, r14d
00007e37b4dcec5c  mov [r15+0x58], r14
00007e37b4dcec60  mov rax, [r15+0x58]
00007e37b4dcec64  mov r14d, eax
00007e37b4dcec67  mov r14d, r14d
00007e37b4dcec6a  shl r14, 0x02
00007e37b4dcec6e  mov rax, [r15+0x98]
00007e37b4dcec75  lea r12, [rax+r14*1]
00007e37b4dcec79  mov eax, [r13+r12*1]
00007e37b4dcec7e  mov [rsp+0x10], eax
00007e37b4dcec82  mov eax, eax
00007e37b4dcec84  mov [r15+0x60], rax
00007e37b4dcec88  mov eax, [r15+0x48]
00007e37b4dcec8c  mov [rsp+0x20], eax
00007e37b4dcec90  xor eax, eax
00007e37b4dcec92  mov r14d, [rsp+0x10]
00007e37b4dcec97  mov r12d, [rsp+0x20]
00007e37b4dcec9c  cmp r14d, r12d
00007e37b4dcec9f  cmc
00007e37b4dceca0  lahf
00007e37b4dceca1  seto al
00007e37b4dceca4  mov [r15+0x108], eax
00007e37b4dcecab  mov eax, [r15+0x108]
00007e37b4dcecb2  sahf
00007e37b4dcecb3  cmc
00007e37b4dcecb4  jbe 0x00007E37B4DCECE6
00007e37b4dcecb6  cmp dword ptr [r15+0x318], 0x00
00007e37b4dcecbe  jz 0x00007E37B4DCEA90
00007e37b4dcecc4  nop [rax+rax*1], ax
00007e37b4dceccd  nop [rax+rax*1], eax
00007e37b4dcecd5  mov eax, 0x4101C8
00007e37b4dcecda  mov [r15+0x100], rax
00007e37b4dcece1  jmp 0x00007E37B4BFE110
00007e37b4dcece6  cmp dword ptr [r15+0x318], 0x00
00007e37b4dcecee  jz 0x00007E37B4DCED30
00007e37b4dcecf4  nop [rax+rax*1], ax
00007e37b4dcecfd  nop [rax+rax*1], eax
00007e37b4dced05  mov eax, 0x4101A0
00007e37b4dced0a  mov [r15+0x100], rax
00007e37b4dced11  jmp 0x00007E37B4BFE110
00007e37b4dced16  int3
00007e37b4dced17  call 0x00007E37B4CB4690
00007e37b4dced1c  jmp 0x00007E37B4DCEC7E
00007e37b4dced21  int3
00007e37b4dced22  nop [rax+rax*1], ax
00007e37b4dced2b  nop [rax+rax*1], eax
00007e37b4dced30  mov rax, [r15+0x40]
00007e37b4dced34  lea r14, [rax+0x01]
00007e37b4dced38  mov [r15+0x40], r14
00007e37b4dced3c  mov rax, [r15+0x50]
00007e37b4dced40  mov r12d, eax
00007e37b4dced43  mov r12d, r12d
00007e37b4dced46  shl r12, 0x02
00007e37b4dced4a  mov rax, [r15+0x98]
00007e37b4dced51  lea r11, [rax+r12*1]
00007e37b4dced55  mov eax, [r15+0x48]
00007e37b4dced59  mov [r13+r11*1], eax
00007e37b4dced5e  xor eax, eax
00007e37b4dced60  mov r12d, 0x400
00007e37b4dced66  cmp r14, r12
00007e37b4dced69  cmc
00007e37b4dced6a  lahf
00007e37b4dced6b  seto al
00007e37b4dced6e  mov [r15+0x108], eax
00007e37b4dced75  mov eax, [r15+0x108]
00007e37b4dced7c  sahf
00007e37b4dced7d  jz 0x00007E37B4DCEDAF
00007e37b4dced7f  cmp dword ptr [r15+0x318], 0x00
00007e37b4dced87  jz 0x00007E37B4DCE990
00007e37b4dced8d  nop [rax+rax*1], ax
00007e37b4dced96  nop [rax+rax*1], eax
00007e37b4dced9e  mov eax, 0x4101B0
00007e37b4dceda3  mov [r15+0x100], rax
00007e37b4dcedaa  jmp 0x00007E37B4BFE110
00007e37b4dcedaf  cmp dword ptr [r15+0x318], 0x00
00007e37b4dcedb7  jz 0x00007E37B4DCEDF0
00007e37b4dcedbd  nop [rax+rax*1], ax
00007e37b4dcedc6  nop [rax+rax*1], eax
00007e37b4dcedce  mov eax, 0x4101D8
00007e37b4dcedd3  mov [r15+0x100], rax
00007e37b4dcedda  jmp 0x00007E37B4BFE110
00007e37b4dceddf  int3
00007e37b4dcede0  call 0x00007E37B4CA4270
00007e37b4dcede5  jmp 0x00007E37B4DCED5E
00007e37b4dcedea  int3
00007e37b4dcedeb  nop [rax+rax*1], eax
00007e37b4dcedf0  mov qword ptr [r15+0x40], 0x420000
00007e37b4dcedf8  mov eax, 0x420288
00007e37b4dcedfd  mov r14, [r13+rax*1]
00007e37b4dcee02  mov rax, [r15+0x98]
00007e37b4dcee09  mov r12d, [r13+rax*1]
00007e37b4dcee0e  lea r11, [rax+0x04]
00007e37b4dcee12  mov eax, [r13+r11*1]
00007e37b4dcee17  mov r12d, r12d
00007e37b4dcee1a  mov [r15+0x68], r12
00007e37b4dcee1e  mov eax, eax
00007e37b4dcee20  mov [r15+0x60], rax
00007e37b4dcee24  mov rax, [r15+0x68]
00007e37b4dcee28  mov [r15+0x68], rax
00007e37b4dcee2c  mov qword ptr [r15+0x58], 0x02
00007e37b4dcee34  mov [rsp+0x10], rax
00007e37b4dcee39  xor eax, eax
00007e37b4dcee3b  mov r12d, 0x02
00007e37b4dcee41  mov r11d, 0x400
00007e37b4dcee47  cmp r12, r11
00007e37b4dcee4a  cmc
00007e37b4dcee4b  lahf
00007e37b4dcee4c  seto al
00007e37b4dcee4f  mov [r15+0x108], eax
00007e37b4dcee56  mov rax, [r15+0x60]
00007e37b4dcee5a  mov r12d, 0x02
00007e37b4dcee60  imul rax, r12
00007e37b4dcee64  mov [r15+0x50], rax
00007e37b4dcee68  mov rax, [rsp+0x10]
00007e37b4dcee6d  lea r12, [rax+r14*1]
00007e37b4dcee71  mov [r15+0x48], r12
00007e37b4dcee75  mov eax, [r15+0x108]
00007e37b4dcee7c  sahf
00007e37b4dcee7d  jnz 0x00007E37B4DCEEAF
00007e37b4dcee7f  cmp dword ptr [r15+0x318], 0x00
00007e37b4dcee87  jz 0x00007E37B4DCF020
00007e37b4dcee8d  nop [rax+rax*1], ax
00007e37b4dcee96  nop [rax+rax*1], eax
00007e37b4dcee9e  mov eax, 0x410208
00007e37b4dceea3  mov [r15+0x100], rax
00007e37b4dceeaa  jmp 0x00007E37B4BFE110
00007e37b4dceeaf  cmp dword ptr [r15+0x318], 0x00
00007e37b4dceeb7  jz 0x00007E37B4DCEF00
00007e37b4dceebd  nop [rax+rax*1], ax
00007e37b4dceec6  nop [rax+rax*1], eax
00007e37b4dceece  mov eax, 0x4101E8
00007e37b4dceed3  mov [r15+0x100], rax
00007e37b4dceeda  jmp 0x00007E37B4BFE110
00007e37b4dceedf  int3
00007e37b4dceee0  call 0x00007E37B4C0DC20
00007e37b4dceee5  jmp 0x00007E37B4DCEE02
00007e37b4dceeea  call 0x00007E37B4C0B5E0
00007e37b4dceeef  jmp 0x00007E37B4DCEE0E
00007e37b4dceef4  call 0x00007E37B4CA3D90
00007e37b4dceef9  jmp 0x00007E37B4DCEE17
00007e37b4dceefe  int3
00007e37b4dceeff  nop
00007e37b4dcef00  mov rax, [r15+0x98]
00007e37b4dcef07  mov r14, [r15+0x58]
00007e37b4dcef0b  mov [rsp+0x10], r14
00007e37b4dcef10  shl r14, 0x02
00007e37b4dcef14  lea r12, [rax+r14*1]
00007e37b4dcef18  mov eax, [r13+r12*1]
00007e37b4dcef1d  lea r14, [r12+0x04]
00007e37b4dcef22  mov r12d, [r13+r14*1]
00007e37b4dcef27  mov eax, eax
00007e37b4dcef29  mov [r15+0x68], rax
00007e37b4dcef2d  mov r12d, r12d
00007e37b4dcef30  mov [r15+0x60], r12
00007e37b4dcef34  mov rax, [r15+0x68]
00007e37b4dcef38  mov [rsp+0x20], rax
00007e37b4dcef3d  mov r14, [rsp+0x10]
00007e37b4dcef42  imul rax, r14
00007e37b4dcef46  mov r12, [rsp+0x20]
00007e37b4dcef4b  lea r11, [r12+rax*1]
00007e37b4dcef4f  mov [r15+0x68], r11
00007e37b4dcef53  lea rax, [r14+0x02]
00007e37b4dcef57  mov [r15+0x58], rax
00007e37b4dcef5b  mov [rsp+0x10], rax
00007e37b4dcef60  xor eax, eax
00007e37b4dcef62  mov r14, [rsp+0x10]
00007e37b4dcef67  mov r12d, 0x400
00007e37b4dcef6d  cmp r14, r12
00007e37b4dcef70  cmc
00007e37b4dcef71  lahf
00007e37b4dcef72  seto al
00007e37b4dcef75  mov [r15+0x108], eax
00007e37b4dcef7c  mov rax, [r15+0x50]
00007e37b4dcef80  mov r12, [r15+0x60]
00007e37b4dcef84  imul r14, r12
00007e37b4dcef88  lea r12, [rax+r14*1]
00007e37b4dcef8c  mov [r15+0x50], r12
00007e37b4dcef90  mov rax, [r15+0x48]
00007e37b4dcef94  lea r14, [r11+rax*1]
00007e37b4dcef98  mov [r15+0x48], r14
00007e37b4dcef9c  mov eax, [r15+0x108]
00007e37b4dcefa3  sahf
00007e37b4dcefa4  jnz 0x00007E37B4DCEFD6
00007e37b4dcefa6  cmp dword ptr [r15+0x318], 0x00
00007e37b4dcefae  jz 0x00007E37B4DCF020
00007e37b4dcefb4  nop [rax+rax*1], ax
00007e37b4dcefbd  nop [rax+rax*1], eax
00007e37b4dcefc5  mov eax, 0x410208
00007e37b4dcefca  mov [r15+0x100], rax
00007e37b4dcefd1  jmp 0x00007E37B4BFE110
00007e37b4dcefd6  cmp dword ptr [r15+0x318], 0x00
00007e37b4dcefde  jz 0x00007E37B4DCEF00
00007e37b4dcefe4  nop [rax+rax*1], ax
00007e37b4dcefed  nop [rax+rax*1], eax
00007e37b4dceff5  mov eax, 0x4101E8
00007e37b4dceffa  mov [r15+0x100], rax
00007e37b4dcf001  jmp 0x00007E37B4BFE110
00007e37b4dcf006  int3
00007e37b4dcf007  call 0x00007E37B4CB4690
00007e37b4dcf00c  jmp 0x00007E37B4DCEF1D
00007e37b4dcf011  call 0x00007E37B4CE26A0
00007e37b4dcf016  jmp 0x00007E37B4DCEF27
00007e37b4dcf01b  int3
00007e37b4dcf01c  nop [rax], eax
00007e37b4dcf020  mov rax, [r15+0xF8]
00007e37b4dcf027  lea r14, [rax+0x10]
00007e37b4dcf02b  mov r12, [r13+r14*1]
00007e37b4dcf030  lea r14, [rax+0x18]
00007e37b4dcf034  mov r11, [r13+r14*1]
00007e37b4dcf039  mov [r15+0xA0], r12
00007e37b4dcf040  mov [r15+0x98], r11
00007e37b4dcf047  mov r14, [r15+0x50]
00007e37b4dcf04b  mov r12, [r15+0x48]
00007e37b4dcf04f  lea r11, [r14+r12*1]
00007e37b4dcf053  mov [r15+0x48], r11
00007e37b4dcf057  mov r14, [r15+0x40]
00007e37b4dcf05b  lea r12, [r14+0x288]
00007e37b4dcf062  mov [r13+r12*1], r11
00007e37b4dcf067  mov r14, [r13+rax*1]
00007e37b4dcf06c  mov [r15+0xF0], r14
00007e37b4dcf073  lea r12, [rax+0x20]
00007e37b4dcf077  mov [r15+0xF8], r12
00007e37b4dcf07e  mov [r15+0x100], r14
00007e37b4dcf085  jmp 0x00007E37B4DCE5C0
00007e37b4dcf08a  int3
00007e37b4dcf08b  call 0x00007E37B4CE27E0
00007e37b4dcf090  jmp 0x00007E37B4DCF030
00007e37b4dcf095  call 0x00007E37B4CE1570
00007e37b4dcf09a  jmp 0x00007E37B4DCF039
00007e37b4dcf09f  call 0x00007E37B4CC0860
00007e37b4dcf0a4  jmp 0x00007E37B4DCF067
00007e37b4dcf0a9  call 0x00007E37B4C0DC20
00007e37b4dcf0ae  jmp 0x00007E37B4DCF06C
00007e37b4dcf0b3  int3
00007e37b4dcf0b4  nop [rax+rax*1], ax
00007e37b4dcf0bd  nop [rax], eax
00007e37b4dcf0c0  mov qword ptr [r15+0x100], 0x04
00007e37b4dcf0cb  mov esi, 0x00
00007e37b4dcf0d0  mov edx, 0x09
00007e37b4dcf0d5  mov rdi, 0x7FFC011B65D0
00007e37b4dcf0df  mov rax, 0x602CC678C970
00007e37b4dcf0e9  call rax
00007e37b4dcf0eb  cmp dword ptr [r15+0x318], 0x00
00007e37b4dcf0f3  jnz 0x00007E37B4BFE110
00007e37b4dcf0f9  jmp 0x00007E37B4BFE0A0
00007e37b4dcf0fe  int3
00007e37b4dcf0ff  int3
