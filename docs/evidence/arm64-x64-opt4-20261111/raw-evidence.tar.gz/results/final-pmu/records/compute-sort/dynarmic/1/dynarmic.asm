00007f99f67ce69b  nop [rax+rax*1], eax
00007f99f67ce6a0  mov rax, [r15+0xF8]
00007f99f67ce6a7  lea r14, [rax-0x20]
00007f99f67ce6ab  mov r12, [r15+0xF0]
00007f99f67ce6b2  mov [r13+r14*1], r12
00007f99f67ce6b7  mov [r15+0xF8], r14
00007f99f67ce6be  lea r14, [rax-0x10]
00007f99f67ce6c2  mov r12, [r15+0xA0]
00007f99f67ce6c9  mov r11, [r15+0x98]
00007f99f67ce6d0  mov [r13+r14*1], r12
00007f99f67ce6d5  lea r14, [rax-0x08]
00007f99f67ce6d9  mov [r13+r14*1], r11
00007f99f67ce6de  mov qword ptr [r15+0xA0], 0x00
00007f99f67ce6e9  mov qword ptr [r15+0x98], 0x4202A0
00007f99f67ce6f4  mov eax, [r15+0xA0]
00007f99f67ce6fb  lea r14d, [eax+0x11]
00007f99f67ce700  mov r14d, r14d
00007f99f67ce703  mov [r15], r14
00007f99f67ce706  mov qword ptr [r15+0xF0], 0x410184
00007f99f67ce711  mov r14d, [r15+0x320]
00007f99f67ce718  mov eax, 0x410184
00007f99f67ce71d  mov rcx, 0x7F99F67CE800
00007f99f67ce727  mov [r15+r14*8+0x328], rax
00007f99f67ce72f  mov [r15+r14*8+0x368], rcx
00007f99f67ce737  add r14d, 0x01
00007f99f67ce73b  and r14d, 0x07
00007f99f67ce73f  mov [r15+0x320], r14d
00007f99f67ce746  cmp dword ptr [r15+0x318], 0x00
00007f99f67ce74e  jz 0x00007F99F67CE7A0
00007f99f67ce754  nop [rax+rax*1], ax
00007f99f67ce75d  nop [rax+rax*1], eax
00007f99f67ce765  mov eax, 0x41021C
00007f99f67ce76a  mov [r15+0x100], rax
00007f99f67ce771  jmp 0x00007F99F65FE110
00007f99f67ce776  int3
00007f99f67ce777  call 0x00007F99F66E2CE0
00007f99f67ce77c  jmp 0x00007F99F67CE6B7
00007f99f67ce781  call 0x00007F99F66E2CE0
00007f99f67ce786  jmp 0x00007F99F67CE6D5
00007f99f67ce78b  call 0x00007F99F66E1A60
00007f99f67ce790  jmp 0x00007F99F67CE6DE
00007f99f67ce795  int3
00007f99f67ce796  nop [rax+rax*1], ax
00007f99f67ce79f  nop
00007f99f67ce7a0  mov eax, 0x846CA68B
00007f99f67ce7a5  mov eax, eax
00007f99f67ce7a7  mov [r15+0x48], rax
00007f99f67ce7ab  mov eax, [r15]
00007f99f67ce7ae  imul eax, eax, 0x7FEB352D
00007f99f67ce7b4  mov [rsp+0x10], eax
00007f99f67ce7b8  shr eax, 0x0F
00007f99f67ce7bb  mov r14d, [rsp+0x10]
00007f99f67ce7c0  xor r14d, eax
00007f99f67ce7c3  imul r14d, r14d, 0x846CA68B
00007f99f67ce7ca  mov [rsp+0x10], r14d
00007f99f67ce7cf  mov r14d, r14d
00007f99f67ce7d2  mov [r15+0x40], r14
00007f99f67ce7d6  mov eax, [rsp+0x10]
00007f99f67ce7da  shr eax, 0x10
00007f99f67ce7dd  mov r14d, [rsp+0x10]
00007f99f67ce7e2  xor r14d, eax
00007f99f67ce7e5  mov r14d, r14d
00007f99f67ce7e8  mov [r15], r14
00007f99f67ce7eb  mov rax, [r15+0xF0]
00007f99f67ce7f2  mov [r15+0x100], rax
00007f99f67ce7f9  jmp 0x00007F99F67CE5C0
00007f99f67ce7fe  int3
00007f99f67ce7ff  int3
00007f99f67ce800  mov rax, [r15+0xA0]
00007f99f67ce807  mov [rsp+0x10], rax
00007f99f67ce80c  shl rax, 0x02
00007f99f67ce810  mov r14, [r15+0x98]
00007f99f67ce817  lea r12, [r14+rax*1]
00007f99f67ce81b  mov eax, [r15]
00007f99f67ce81e  mov [r13+r12*1], eax
00007f99f67ce823  mov rax, [rsp+0x10]
00007f99f67ce828  lea r14, [rax+0x01]
00007f99f67ce82c  mov [r15+0xA0], r14
00007f99f67ce833  xor eax, eax
00007f99f67ce835  mov r12d, 0x400
00007f99f67ce83b  cmp r14, r12
00007f99f67ce83e  cmc
00007f99f67ce83f  lahf
00007f99f67ce840  seto al
00007f99f67ce843  mov [r15+0x108], eax
00007f99f67ce84a  mov eax, [r15+0x108]
00007f99f67ce851  sahf
00007f99f67ce852  jnz 0x00007F99F67CE884
00007f99f67ce854  cmp dword ptr [r15+0x318], 0x00
00007f99f67ce85c  jz 0x00007F99F67CE950
00007f99f67ce862  nop [rax+rax*1], ax
00007f99f67ce86b  nop [rax+rax*1], eax
00007f99f67ce873  mov eax, 0x410194
00007f99f67ce878  mov [r15+0x100], rax
00007f99f67ce87f  jmp 0x00007F99F65FE110
00007f99f67ce884  cmp dword ptr [r15+0x318], 0x00
00007f99f67ce88c  jz 0x00007F99F67CE8C0
00007f99f67ce892  nop [rax+rax*1], ax
00007f99f67ce89b  nop [rax+rax*1], eax
00007f99f67ce8a3  mov eax, 0x41017C
00007f99f67ce8a8  mov [r15+0x100], rax
00007f99f67ce8af  jmp 0x00007F99F65FE110
00007f99f67ce8b4  int3
00007f99f67ce8b5  call 0x00007F99F66B4B70
00007f99f67ce8ba  jmp 0x00007F99F67CE823
00007f99f67ce8bf  int3
00007f99f67ce8c0  mov eax, [r15+0xA0]
00007f99f67ce8c7  lea r14d, [eax+0x11]
00007f99f67ce8cc  mov r14d, r14d
00007f99f67ce8cf  mov [r15], r14
00007f99f67ce8d2  mov qword ptr [r15+0xF0], 0x410184
00007f99f67ce8dd  mov r14d, [r15+0x320]
00007f99f67ce8e4  mov eax, 0x410184
00007f99f67ce8e9  mov rcx, 0x7F99F67CE800
00007f99f67ce8f3  mov [r15+r14*8+0x328], rax
00007f99f67ce8fb  mov [r15+r14*8+0x368], rcx
00007f99f67ce903  add r14d, 0x01
00007f99f67ce907  and r14d, 0x07
00007f99f67ce90b  mov [r15+0x320], r14d
00007f99f67ce912  cmp dword ptr [r15+0x318], 0x00
00007f99f67ce91a  jz 0x00007F99F67CE7A0
00007f99f67ce920  nop [rax+rax*1], ax
00007f99f67ce929  nop [rax+rax*1], eax
00007f99f67ce931  mov eax, 0x41021C
00007f99f67ce936  mov [r15+0x100], rax
00007f99f67ce93d  jmp 0x00007F99F65FE110
00007f99f67ce942  int3
00007f99f67ce943  int3
00007f99f67ce944  nop [rax+rax*1], ax
00007f99f67ce94d  nop [rax], eax
00007f99f67ce950  mov qword ptr [r15+0x40], 0x01
00007f99f67ce958  cmp dword ptr [r15+0x318], 0x00
00007f99f67ce960  jz 0x00007F99F67CE990
00007f99f67ce966  nop [rax+rax*1], ax
00007f99f67ce96f  nop [rax+rax*1], eax
00007f99f67ce977  mov eax, 0x4101B0
00007f99f67ce97c  mov [r15+0x100], rax
00007f99f67ce983  jmp 0x00007F99F65FE110
00007f99f67ce988  int3
00007f99f67ce989  int3
00007f99f67ce98a  nop [rax+rax*1], ax
00007f99f67ce990  mov rax, [r15+0x40]
00007f99f67ce994  mov [rsp+0x10], rax
00007f99f67ce999  shl rax, 0x02
00007f99f67ce99d  mov r14, [r15+0x98]
00007f99f67ce9a4  lea r12, [r14+rax*1]
00007f99f67ce9a8  mov eax, [r13+r12*1]
00007f99f67ce9ad  mov [rsp+0x20], eax
00007f99f67ce9b1  mov eax, eax
00007f99f67ce9b3  mov [r15+0x48], rax
00007f99f67ce9b7  mov rax, [rsp+0x10]
00007f99f67ce9bc  mov [r15+0x50], rax
00007f99f67ce9c0  mov eax, [r15+0x50]
00007f99f67ce9c4  lea r12d, [eax-0x01]
00007f99f67ce9c9  mov r12d, r12d
00007f99f67ce9cc  mov [r15+0x58], r12
00007f99f67ce9d0  mov rax, [r15+0x58]
00007f99f67ce9d4  mov r12d, eax
00007f99f67ce9d7  mov r12d, r12d
00007f99f67ce9da  shl r12, 0x02
00007f99f67ce9de  lea rax, [r14+r12*1]
00007f99f67ce9e2  mov r14d, [r13+rax*1]
00007f99f67ce9e7  mov [rsp+0x10], r14d
00007f99f67ce9ec  mov r14d, r14d
00007f99f67ce9ef  mov [r15+0x60], r14
00007f99f67ce9f3  xor eax, eax
00007f99f67ce9f5  mov r14d, [rsp+0x10]
00007f99f67ce9fa  mov r12d, [rsp+0x20]
00007f99f67ce9ff  cmp r14d, r12d
00007f99f67cea02  cmc
00007f99f67cea03  lahf
00007f99f67cea04  seto al
00007f99f67cea07  mov [r15+0x108], eax
00007f99f67cea0e  mov eax, [r15+0x108]
00007f99f67cea15  sahf
00007f99f67cea16  cmc
00007f99f67cea17  jbe 0x00007F99F67CEA49
00007f99f67cea19  cmp dword ptr [r15+0x318], 0x00
00007f99f67cea21  jz 0x00007F99F67CEA90
00007f99f67cea27  nop [rax+rax*1], ax
00007f99f67cea30  nop [rax+rax*1], eax
00007f99f67cea38  mov eax, 0x4101C8
00007f99f67cea3d  mov [r15+0x100], rax
00007f99f67cea44  jmp 0x00007F99F65FE110
00007f99f67cea49  cmp dword ptr [r15+0x318], 0x00
00007f99f67cea51  jz 0x00007F99F67CED30
00007f99f67cea57  nop [rax+rax*1], ax
00007f99f67cea60  nop [rax+rax*1], eax
00007f99f67cea68  mov eax, 0x4101A0
00007f99f67cea6d  mov [r15+0x100], rax
00007f99f67cea74  jmp 0x00007F99F65FE110
00007f99f67cea79  int3
00007f99f67cea7a  call 0x00007F99F66B4690
00007f99f67cea7f  jmp 0x00007F99F67CE9AD
00007f99f67cea84  call 0x00007F99F660DAE0
00007f99f67cea89  jmp 0x00007F99F67CE9E7
00007f99f67cea8e  int3
00007f99f67cea8f  nop
00007f99f67cea90  mov rax, [r15+0x50]
00007f99f67cea94  mov [rsp+0x10], rax
00007f99f67cea99  shl rax, 0x02
00007f99f67cea9d  mov r14, [r15+0x98]
00007f99f67ceaa4  lea r12, [r14+rax*1]
00007f99f67ceaa8  mov eax, [r15+0x60]
00007f99f67ceaac  mov [r13+r12*1], eax
00007f99f67ceab1  mov rax, [rsp+0x10]
00007f99f67ceab6  lea r14, [rax-0x01]
00007f99f67ceaba  mov [r15+0x50], r14
00007f99f67ceabe  mov rax, [r15+0x58]
00007f99f67ceac2  test rax, rax
00007f99f67ceac5  setz al
00007f99f67ceac8  movzx rax, al
00007f99f67ceacc  mov [rsp+0x414], al
00007f99f67cead3  cmp byte ptr [rsp+0x414], 0x00
00007f99f67ceadb  jz 0x00007F99F67CEB0D
00007f99f67ceadd  cmp dword ptr [r15+0x318], 0x00
00007f99f67ceae5  jz 0x00007F99F67CEB50
00007f99f67ceaeb  nop [rax+rax*1], ax
00007f99f67ceaf4  nop [rax+rax*1], eax
00007f99f67ceafc  mov eax, 0x4101D4
00007f99f67ceb01  mov [r15+0x100], rax
00007f99f67ceb08  jmp 0x00007F99F65FE110
00007f99f67ceb0d  cmp dword ptr [r15+0x318], 0x00
00007f99f67ceb15  jz 0x00007F99F67CEC50
00007f99f67ceb1b  nop [rax+rax*1], ax
00007f99f67ceb24  nop [rax+rax*1], eax
00007f99f67ceb2c  mov eax, 0x4101B8
00007f99f67ceb31  mov [r15+0x100], rax
00007f99f67ceb38  jmp 0x00007F99F65FE110
00007f99f67ceb3d  int3
00007f99f67ceb3e  call 0x00007F99F66B4B70
00007f99f67ceb43  jmp 0x00007F99F67CEAB1
00007f99f67ceb48  int3
00007f99f67ceb49  nop [rax], eax
00007f99f67ceb50  cmp dword ptr [r15+0x318], 0x00
00007f99f67ceb58  jz 0x00007F99F67CEB90
00007f99f67ceb5e  nop [rax+rax*1], ax
00007f99f67ceb67  nop [rax+rax*1], eax
00007f99f67ceb6f  mov eax, 0x41019C
00007f99f67ceb74  mov [r15+0x100], rax
00007f99f67ceb7b  jmp 0x00007F99F65FE110
00007f99f67ceb80  int3
00007f99f67ceb81  int3
00007f99f67ceb82  nop [rax+rax*1], ax
00007f99f67ceb8b  nop [rax+rax*1], eax
00007f99f67ceb90  mov qword ptr [r15+0x50], 0x00
00007f99f67ceb98  mov rax, [r15+0x40]
00007f99f67ceb9c  lea r14, [rax+0x01]
00007f99f67ceba0  mov [r15+0x40], r14
00007f99f67ceba4  mov rax, [r15+0x98]
00007f99f67cebab  mov r12d, [r15+0x48]
00007f99f67cebaf  mov [r13+rax*1], r12d
00007f99f67cebb4  xor eax, eax
00007f99f67cebb6  mov r12d, 0x400
00007f99f67cebbc  cmp r14, r12
00007f99f67cebbf  cmc
00007f99f67cebc0  lahf
00007f99f67cebc1  seto al
00007f99f67cebc4  mov [r15+0x108], eax
00007f99f67cebcb  mov eax, [r15+0x108]
00007f99f67cebd2  sahf
00007f99f67cebd3  jz 0x00007F99F67CEC05
00007f99f67cebd5  cmp dword ptr [r15+0x318], 0x00
00007f99f67cebdd  jz 0x00007F99F67CE990
00007f99f67cebe3  nop [rax+rax*1], ax
00007f99f67cebec  nop [rax+rax*1], eax
00007f99f67cebf4  mov eax, 0x4101B0
00007f99f67cebf9  mov [r15+0x100], rax
00007f99f67cec00  jmp 0x00007F99F65FE110
00007f99f67cec05  cmp dword ptr [r15+0x318], 0x00
00007f99f67cec0d  jz 0x00007F99F67CEDF0
00007f99f67cec13  nop [rax+rax*1], ax
00007f99f67cec1c  nop [rax+rax*1], eax
00007f99f67cec24  mov eax, 0x4101D8
00007f99f67cec29  mov [r15+0x100], rax
00007f99f67cec30  jmp 0x00007F99F65FE110
00007f99f67cec35  int3
00007f99f67cec36  call 0x00007F99F660BAE0
00007f99f67cec3b  jmp 0x00007F99F67CEBB4
00007f99f67cec40  int3
00007f99f67cec41  nop [rax+rax*1], ax
00007f99f67cec4a  nop [rax+rax*1], ax
00007f99f67cec50  mov eax, [r15+0x50]
00007f99f67cec54  lea r14d, [eax-0x01]
00007f99f67cec59  mov r14d, r14d
00007f99f67cec5c  mov [r15+0x58], r14
00007f99f67cec60  mov rax, [r15+0x58]
00007f99f67cec64  mov r14d, eax
00007f99f67cec67  mov r14d, r14d
00007f99f67cec6a  shl r14, 0x02
00007f99f67cec6e  mov rax, [r15+0x98]
00007f99f67cec75  lea r12, [rax+r14*1]
00007f99f67cec79  mov eax, [r13+r12*1]
00007f99f67cec7e  mov [rsp+0x10], eax
00007f99f67cec82  mov eax, eax
00007f99f67cec84  mov [r15+0x60], rax
00007f99f67cec88  mov eax, [r15+0x48]
00007f99f67cec8c  mov [rsp+0x20], eax
00007f99f67cec90  xor eax, eax
00007f99f67cec92  mov r14d, [rsp+0x10]
00007f99f67cec97  mov r12d, [rsp+0x20]
00007f99f67cec9c  cmp r14d, r12d
00007f99f67cec9f  cmc
00007f99f67ceca0  lahf
00007f99f67ceca1  seto al
00007f99f67ceca4  mov [r15+0x108], eax
00007f99f67cecab  mov eax, [r15+0x108]
00007f99f67cecb2  sahf
00007f99f67cecb3  cmc
00007f99f67cecb4  jbe 0x00007F99F67CECE6
00007f99f67cecb6  cmp dword ptr [r15+0x318], 0x00
00007f99f67cecbe  jz 0x00007F99F67CEA90
00007f99f67cecc4  nop [rax+rax*1], ax
00007f99f67ceccd  nop [rax+rax*1], eax
00007f99f67cecd5  mov eax, 0x4101C8
00007f99f67cecda  mov [r15+0x100], rax
00007f99f67cece1  jmp 0x00007F99F65FE110
00007f99f67cece6  cmp dword ptr [r15+0x318], 0x00
00007f99f67cecee  jz 0x00007F99F67CED30
00007f99f67cecf4  nop [rax+rax*1], ax
00007f99f67cecfd  nop [rax+rax*1], eax
00007f99f67ced05  mov eax, 0x4101A0
00007f99f67ced0a  mov [r15+0x100], rax
00007f99f67ced11  jmp 0x00007F99F65FE110
00007f99f67ced16  int3
00007f99f67ced17  call 0x00007F99F66B4690
00007f99f67ced1c  jmp 0x00007F99F67CEC7E
00007f99f67ced21  int3
00007f99f67ced22  nop [rax+rax*1], ax
00007f99f67ced2b  nop [rax+rax*1], eax
00007f99f67ced30  mov rax, [r15+0x40]
00007f99f67ced34  lea r14, [rax+0x01]
00007f99f67ced38  mov [r15+0x40], r14
00007f99f67ced3c  mov rax, [r15+0x50]
00007f99f67ced40  mov r12d, eax
00007f99f67ced43  mov r12d, r12d
00007f99f67ced46  shl r12, 0x02
00007f99f67ced4a  mov rax, [r15+0x98]
00007f99f67ced51  lea r11, [rax+r12*1]
00007f99f67ced55  mov eax, [r15+0x48]
00007f99f67ced59  mov [r13+r11*1], eax
00007f99f67ced5e  xor eax, eax
00007f99f67ced60  mov r12d, 0x400
00007f99f67ced66  cmp r14, r12
00007f99f67ced69  cmc
00007f99f67ced6a  lahf
00007f99f67ced6b  seto al
00007f99f67ced6e  mov [r15+0x108], eax
00007f99f67ced75  mov eax, [r15+0x108]
00007f99f67ced7c  sahf
00007f99f67ced7d  jz 0x00007F99F67CEDAF
00007f99f67ced7f  cmp dword ptr [r15+0x318], 0x00
00007f99f67ced87  jz 0x00007F99F67CE990
00007f99f67ced8d  nop [rax+rax*1], ax
00007f99f67ced96  nop [rax+rax*1], eax
00007f99f67ced9e  mov eax, 0x4101B0
00007f99f67ceda3  mov [r15+0x100], rax
00007f99f67cedaa  jmp 0x00007F99F65FE110
00007f99f67cedaf  cmp dword ptr [r15+0x318], 0x00
00007f99f67cedb7  jz 0x00007F99F67CEDF0
00007f99f67cedbd  nop [rax+rax*1], ax
00007f99f67cedc6  nop [rax+rax*1], eax
00007f99f67cedce  mov eax, 0x4101D8
00007f99f67cedd3  mov [r15+0x100], rax
00007f99f67cedda  jmp 0x00007F99F65FE110
00007f99f67ceddf  int3
00007f99f67cede0  call 0x00007F99F66A4270
00007f99f67cede5  jmp 0x00007F99F67CED5E
00007f99f67cedea  int3
00007f99f67cedeb  nop [rax+rax*1], eax
00007f99f67cedf0  mov qword ptr [r15+0x40], 0x420000
00007f99f67cedf8  mov eax, 0x420288
00007f99f67cedfd  mov r14, [r13+rax*1]
00007f99f67cee02  mov rax, [r15+0x98]
00007f99f67cee09  mov r12d, [r13+rax*1]
00007f99f67cee0e  lea r11, [rax+0x04]
00007f99f67cee12  mov eax, [r13+r11*1]
00007f99f67cee17  mov r12d, r12d
00007f99f67cee1a  mov [r15+0x68], r12
00007f99f67cee1e  mov eax, eax
00007f99f67cee20  mov [r15+0x60], rax
00007f99f67cee24  mov rax, [r15+0x68]
00007f99f67cee28  mov [r15+0x68], rax
00007f99f67cee2c  mov qword ptr [r15+0x58], 0x02
00007f99f67cee34  mov [rsp+0x10], rax
00007f99f67cee39  xor eax, eax
00007f99f67cee3b  mov r12d, 0x02
00007f99f67cee41  mov r11d, 0x400
00007f99f67cee47  cmp r12, r11
00007f99f67cee4a  cmc
00007f99f67cee4b  lahf
00007f99f67cee4c  seto al
00007f99f67cee4f  mov [r15+0x108], eax
00007f99f67cee56  mov rax, [r15+0x60]
00007f99f67cee5a  mov r12d, 0x02
00007f99f67cee60  imul rax, r12
00007f99f67cee64  mov [r15+0x50], rax
00007f99f67cee68  mov rax, [rsp+0x10]
00007f99f67cee6d  lea r12, [rax+r14*1]
00007f99f67cee71  mov [r15+0x48], r12
00007f99f67cee75  mov eax, [r15+0x108]
00007f99f67cee7c  sahf
00007f99f67cee7d  jnz 0x00007F99F67CEEAF
00007f99f67cee7f  cmp dword ptr [r15+0x318], 0x00
00007f99f67cee87  jz 0x00007F99F67CF020
00007f99f67cee8d  nop [rax+rax*1], ax
00007f99f67cee96  nop [rax+rax*1], eax
00007f99f67cee9e  mov eax, 0x410208
00007f99f67ceea3  mov [r15+0x100], rax
00007f99f67ceeaa  jmp 0x00007F99F65FE110
00007f99f67ceeaf  cmp dword ptr [r15+0x318], 0x00
00007f99f67ceeb7  jz 0x00007F99F67CEF00
00007f99f67ceebd  nop [rax+rax*1], ax
00007f99f67ceec6  nop [rax+rax*1], eax
00007f99f67ceece  mov eax, 0x4101E8
00007f99f67ceed3  mov [r15+0x100], rax
00007f99f67ceeda  jmp 0x00007F99F65FE110
00007f99f67ceedf  int3
00007f99f67ceee0  call 0x00007F99F660DC20
00007f99f67ceee5  jmp 0x00007F99F67CEE02
00007f99f67ceeea  call 0x00007F99F660B5E0
00007f99f67ceeef  jmp 0x00007F99F67CEE0E
00007f99f67ceef4  call 0x00007F99F66A3D90
00007f99f67ceef9  jmp 0x00007F99F67CEE17
00007f99f67ceefe  int3
00007f99f67ceeff  nop
00007f99f67cef00  mov rax, [r15+0x98]
00007f99f67cef07  mov r14, [r15+0x58]
00007f99f67cef0b  mov [rsp+0x10], r14
00007f99f67cef10  shl r14, 0x02
00007f99f67cef14  lea r12, [rax+r14*1]
00007f99f67cef18  mov eax, [r13+r12*1]
00007f99f67cef1d  lea r14, [r12+0x04]
00007f99f67cef22  mov r12d, [r13+r14*1]
00007f99f67cef27  mov eax, eax
00007f99f67cef29  mov [r15+0x68], rax
00007f99f67cef2d  mov r12d, r12d
00007f99f67cef30  mov [r15+0x60], r12
00007f99f67cef34  mov rax, [r15+0x68]
00007f99f67cef38  mov [rsp+0x20], rax
00007f99f67cef3d  mov r14, [rsp+0x10]
00007f99f67cef42  imul rax, r14
00007f99f67cef46  mov r12, [rsp+0x20]
00007f99f67cef4b  lea r11, [r12+rax*1]
00007f99f67cef4f  mov [r15+0x68], r11
00007f99f67cef53  lea rax, [r14+0x02]
00007f99f67cef57  mov [r15+0x58], rax
00007f99f67cef5b  mov [rsp+0x10], rax
00007f99f67cef60  xor eax, eax
00007f99f67cef62  mov r14, [rsp+0x10]
00007f99f67cef67  mov r12d, 0x400
00007f99f67cef6d  cmp r14, r12
00007f99f67cef70  cmc
00007f99f67cef71  lahf
00007f99f67cef72  seto al
00007f99f67cef75  mov [r15+0x108], eax
00007f99f67cef7c  mov rax, [r15+0x50]
00007f99f67cef80  mov r12, [r15+0x60]
00007f99f67cef84  imul r14, r12
00007f99f67cef88  lea r12, [rax+r14*1]
00007f99f67cef8c  mov [r15+0x50], r12
00007f99f67cef90  mov rax, [r15+0x48]
00007f99f67cef94  lea r14, [r11+rax*1]
00007f99f67cef98  mov [r15+0x48], r14
00007f99f67cef9c  mov eax, [r15+0x108]
00007f99f67cefa3  sahf
00007f99f67cefa4  jnz 0x00007F99F67CEFD6
00007f99f67cefa6  cmp dword ptr [r15+0x318], 0x00
00007f99f67cefae  jz 0x00007F99F67CF020
00007f99f67cefb4  nop [rax+rax*1], ax
00007f99f67cefbd  nop [rax+rax*1], eax
00007f99f67cefc5  mov eax, 0x410208
00007f99f67cefca  mov [r15+0x100], rax
00007f99f67cefd1  jmp 0x00007F99F65FE110
00007f99f67cefd6  cmp dword ptr [r15+0x318], 0x00
00007f99f67cefde  jz 0x00007F99F67CEF00
00007f99f67cefe4  nop [rax+rax*1], ax
00007f99f67cefed  nop [rax+rax*1], eax
00007f99f67ceff5  mov eax, 0x4101E8
00007f99f67ceffa  mov [r15+0x100], rax
00007f99f67cf001  jmp 0x00007F99F65FE110
00007f99f67cf006  int3
00007f99f67cf007  call 0x00007F99F66B4690
00007f99f67cf00c  jmp 0x00007F99F67CEF1D
00007f99f67cf011  call 0x00007F99F66E26A0
00007f99f67cf016  jmp 0x00007F99F67CEF27
00007f99f67cf01b  int3
00007f99f67cf01c  nop [rax], eax
00007f99f67cf020  mov rax, [r15+0xF8]
00007f99f67cf027  lea r14, [rax+0x10]
00007f99f67cf02b  mov r12, [r13+r14*1]
00007f99f67cf030  lea r14, [rax+0x18]
00007f99f67cf034  mov r11, [r13+r14*1]
00007f99f67cf039  mov [r15+0xA0], r12
00007f99f67cf040  mov [r15+0x98], r11
00007f99f67cf047  mov r14, [r15+0x50]
00007f99f67cf04b  mov r12, [r15+0x48]
00007f99f67cf04f  lea r11, [r14+r12*1]
00007f99f67cf053  mov [r15+0x48], r11
00007f99f67cf057  mov r14, [r15+0x40]
00007f99f67cf05b  lea r12, [r14+0x288]
00007f99f67cf062  mov [r13+r12*1], r11
00007f99f67cf067  mov r14, [r13+rax*1]
00007f99f67cf06c  mov [r15+0xF0], r14
00007f99f67cf073  lea r12, [rax+0x20]
00007f99f67cf077  mov [r15+0xF8], r12
00007f99f67cf07e  mov [r15+0x100], r14
00007f99f67cf085  jmp 0x00007F99F67CE5C0
00007f99f67cf08a  int3
00007f99f67cf08b  call 0x00007F99F66E27E0
00007f99f67cf090  jmp 0x00007F99F67CF030
00007f99f67cf095  call 0x00007F99F66E1570
00007f99f67cf09a  jmp 0x00007F99F67CF039
00007f99f67cf09f  call 0x00007F99F66C0860
00007f99f67cf0a4  jmp 0x00007F99F67CF067
00007f99f67cf0a9  call 0x00007F99F660DC20
00007f99f67cf0ae  jmp 0x00007F99F67CF06C
00007f99f67cf0b3  int3
00007f99f67cf0b4  nop [rax+rax*1], ax
00007f99f67cf0bd  nop [rax], eax
00007f99f67cf0c0  mov qword ptr [r15+0x100], 0x04
00007f99f67cf0cb  mov esi, 0x00
00007f99f67cf0d0  mov edx, 0x09
00007f99f67cf0d5  mov rdi, 0x7FFDCBEC5540
00007f99f67cf0df  mov rax, 0x5588153A6970
00007f99f67cf0e9  call rax
00007f99f67cf0eb  cmp dword ptr [r15+0x318], 0x00
00007f99f67cf0f3  jnz 0x00007F99F65FE110
00007f99f67cf0f9  jmp 0x00007F99F65FE0A0
00007f99f67cf0fe  int3
00007f99f67cf0ff  int3
