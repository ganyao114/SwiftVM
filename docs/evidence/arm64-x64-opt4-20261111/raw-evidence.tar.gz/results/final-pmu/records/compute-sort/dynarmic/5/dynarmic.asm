000077334edce69b  nop [rax+rax*1], eax
000077334edce6a0  mov rax, [r15+0xF8]
000077334edce6a7  lea r14, [rax-0x20]
000077334edce6ab  mov r12, [r15+0xF0]
000077334edce6b2  mov [r13+r14*1], r12
000077334edce6b7  mov [r15+0xF8], r14
000077334edce6be  lea r14, [rax-0x10]
000077334edce6c2  mov r12, [r15+0xA0]
000077334edce6c9  mov r11, [r15+0x98]
000077334edce6d0  mov [r13+r14*1], r12
000077334edce6d5  lea r14, [rax-0x08]
000077334edce6d9  mov [r13+r14*1], r11
000077334edce6de  mov qword ptr [r15+0xA0], 0x00
000077334edce6e9  mov qword ptr [r15+0x98], 0x4202A0
000077334edce6f4  mov eax, [r15+0xA0]
000077334edce6fb  lea r14d, [eax+0x11]
000077334edce700  mov r14d, r14d
000077334edce703  mov [r15], r14
000077334edce706  mov qword ptr [r15+0xF0], 0x410184
000077334edce711  mov r14d, [r15+0x320]
000077334edce718  mov eax, 0x410184
000077334edce71d  mov rcx, 0x77334EDCE800
000077334edce727  mov [r15+r14*8+0x328], rax
000077334edce72f  mov [r15+r14*8+0x368], rcx
000077334edce737  add r14d, 0x01
000077334edce73b  and r14d, 0x07
000077334edce73f  mov [r15+0x320], r14d
000077334edce746  cmp dword ptr [r15+0x318], 0x00
000077334edce74e  jz 0x000077334EDCE7A0
000077334edce754  nop [rax+rax*1], ax
000077334edce75d  nop [rax+rax*1], eax
000077334edce765  mov eax, 0x41021C
000077334edce76a  mov [r15+0x100], rax
000077334edce771  jmp 0x000077334EBFE110
000077334edce776  int3
000077334edce777  call 0x000077334ECE2CE0
000077334edce77c  jmp 0x000077334EDCE6B7
000077334edce781  call 0x000077334ECE2CE0
000077334edce786  jmp 0x000077334EDCE6D5
000077334edce78b  call 0x000077334ECE1A60
000077334edce790  jmp 0x000077334EDCE6DE
000077334edce795  int3
000077334edce796  nop [rax+rax*1], ax
000077334edce79f  nop
000077334edce7a0  mov eax, 0x846CA68B
000077334edce7a5  mov eax, eax
000077334edce7a7  mov [r15+0x48], rax
000077334edce7ab  mov eax, [r15]
000077334edce7ae  imul eax, eax, 0x7FEB352D
000077334edce7b4  mov [rsp+0x10], eax
000077334edce7b8  shr eax, 0x0F
000077334edce7bb  mov r14d, [rsp+0x10]
000077334edce7c0  xor r14d, eax
000077334edce7c3  imul r14d, r14d, 0x846CA68B
000077334edce7ca  mov [rsp+0x10], r14d
000077334edce7cf  mov r14d, r14d
000077334edce7d2  mov [r15+0x40], r14
000077334edce7d6  mov eax, [rsp+0x10]
000077334edce7da  shr eax, 0x10
000077334edce7dd  mov r14d, [rsp+0x10]
000077334edce7e2  xor r14d, eax
000077334edce7e5  mov r14d, r14d
000077334edce7e8  mov [r15], r14
000077334edce7eb  mov rax, [r15+0xF0]
000077334edce7f2  mov [r15+0x100], rax
000077334edce7f9  jmp 0x000077334EDCE5C0
000077334edce7fe  int3
000077334edce7ff  int3
000077334edce800  mov rax, [r15+0xA0]
000077334edce807  mov [rsp+0x10], rax
000077334edce80c  shl rax, 0x02
000077334edce810  mov r14, [r15+0x98]
000077334edce817  lea r12, [r14+rax*1]
000077334edce81b  mov eax, [r15]
000077334edce81e  mov [r13+r12*1], eax
000077334edce823  mov rax, [rsp+0x10]
000077334edce828  lea r14, [rax+0x01]
000077334edce82c  mov [r15+0xA0], r14
000077334edce833  xor eax, eax
000077334edce835  mov r12d, 0x400
000077334edce83b  cmp r14, r12
000077334edce83e  cmc
000077334edce83f  lahf
000077334edce840  seto al
000077334edce843  mov [r15+0x108], eax
000077334edce84a  mov eax, [r15+0x108]
000077334edce851  sahf
000077334edce852  jnz 0x000077334EDCE884
000077334edce854  cmp dword ptr [r15+0x318], 0x00
000077334edce85c  jz 0x000077334EDCE950
000077334edce862  nop [rax+rax*1], ax
000077334edce86b  nop [rax+rax*1], eax
000077334edce873  mov eax, 0x410194
000077334edce878  mov [r15+0x100], rax
000077334edce87f  jmp 0x000077334EBFE110
000077334edce884  cmp dword ptr [r15+0x318], 0x00
000077334edce88c  jz 0x000077334EDCE8C0
000077334edce892  nop [rax+rax*1], ax
000077334edce89b  nop [rax+rax*1], eax
000077334edce8a3  mov eax, 0x41017C
000077334edce8a8  mov [r15+0x100], rax
000077334edce8af  jmp 0x000077334EBFE110
000077334edce8b4  int3
000077334edce8b5  call 0x000077334ECB4B70
000077334edce8ba  jmp 0x000077334EDCE823
000077334edce8bf  int3
000077334edce8c0  mov eax, [r15+0xA0]
000077334edce8c7  lea r14d, [eax+0x11]
000077334edce8cc  mov r14d, r14d
000077334edce8cf  mov [r15], r14
000077334edce8d2  mov qword ptr [r15+0xF0], 0x410184
000077334edce8dd  mov r14d, [r15+0x320]
000077334edce8e4  mov eax, 0x410184
000077334edce8e9  mov rcx, 0x77334EDCE800
000077334edce8f3  mov [r15+r14*8+0x328], rax
000077334edce8fb  mov [r15+r14*8+0x368], rcx
000077334edce903  add r14d, 0x01
000077334edce907  and r14d, 0x07
000077334edce90b  mov [r15+0x320], r14d
000077334edce912  cmp dword ptr [r15+0x318], 0x00
000077334edce91a  jz 0x000077334EDCE7A0
000077334edce920  nop [rax+rax*1], ax
000077334edce929  nop [rax+rax*1], eax
000077334edce931  mov eax, 0x41021C
000077334edce936  mov [r15+0x100], rax
000077334edce93d  jmp 0x000077334EBFE110
000077334edce942  int3
000077334edce943  int3
000077334edce944  nop [rax+rax*1], ax
000077334edce94d  nop [rax], eax
000077334edce950  mov qword ptr [r15+0x40], 0x01
000077334edce958  cmp dword ptr [r15+0x318], 0x00
000077334edce960  jz 0x000077334EDCE990
000077334edce966  nop [rax+rax*1], ax
000077334edce96f  nop [rax+rax*1], eax
000077334edce977  mov eax, 0x4101B0
000077334edce97c  mov [r15+0x100], rax
000077334edce983  jmp 0x000077334EBFE110
000077334edce988  int3
000077334edce989  int3
000077334edce98a  nop [rax+rax*1], ax
000077334edce990  mov rax, [r15+0x40]
000077334edce994  mov [rsp+0x10], rax
000077334edce999  shl rax, 0x02
000077334edce99d  mov r14, [r15+0x98]
000077334edce9a4  lea r12, [r14+rax*1]
000077334edce9a8  mov eax, [r13+r12*1]
000077334edce9ad  mov [rsp+0x20], eax
000077334edce9b1  mov eax, eax
000077334edce9b3  mov [r15+0x48], rax
000077334edce9b7  mov rax, [rsp+0x10]
000077334edce9bc  mov [r15+0x50], rax
000077334edce9c0  mov eax, [r15+0x50]
000077334edce9c4  lea r12d, [eax-0x01]
000077334edce9c9  mov r12d, r12d
000077334edce9cc  mov [r15+0x58], r12
000077334edce9d0  mov rax, [r15+0x58]
000077334edce9d4  mov r12d, eax
000077334edce9d7  mov r12d, r12d
000077334edce9da  shl r12, 0x02
000077334edce9de  lea rax, [r14+r12*1]
000077334edce9e2  mov r14d, [r13+rax*1]
000077334edce9e7  mov [rsp+0x10], r14d
000077334edce9ec  mov r14d, r14d
000077334edce9ef  mov [r15+0x60], r14
000077334edce9f3  xor eax, eax
000077334edce9f5  mov r14d, [rsp+0x10]
000077334edce9fa  mov r12d, [rsp+0x20]
000077334edce9ff  cmp r14d, r12d
000077334edcea02  cmc
000077334edcea03  lahf
000077334edcea04  seto al
000077334edcea07  mov [r15+0x108], eax
000077334edcea0e  mov eax, [r15+0x108]
000077334edcea15  sahf
000077334edcea16  cmc
000077334edcea17  jbe 0x000077334EDCEA49
000077334edcea19  cmp dword ptr [r15+0x318], 0x00
000077334edcea21  jz 0x000077334EDCEA90
000077334edcea27  nop [rax+rax*1], ax
000077334edcea30  nop [rax+rax*1], eax
000077334edcea38  mov eax, 0x4101C8
000077334edcea3d  mov [r15+0x100], rax
000077334edcea44  jmp 0x000077334EBFE110
000077334edcea49  cmp dword ptr [r15+0x318], 0x00
000077334edcea51  jz 0x000077334EDCED30
000077334edcea57  nop [rax+rax*1], ax
000077334edcea60  nop [rax+rax*1], eax
000077334edcea68  mov eax, 0x4101A0
000077334edcea6d  mov [r15+0x100], rax
000077334edcea74  jmp 0x000077334EBFE110
000077334edcea79  int3
000077334edcea7a  call 0x000077334ECB4690
000077334edcea7f  jmp 0x000077334EDCE9AD
000077334edcea84  call 0x000077334EC0DAE0
000077334edcea89  jmp 0x000077334EDCE9E7
000077334edcea8e  int3
000077334edcea8f  nop
000077334edcea90  mov rax, [r15+0x50]
000077334edcea94  mov [rsp+0x10], rax
000077334edcea99  shl rax, 0x02
000077334edcea9d  mov r14, [r15+0x98]
000077334edceaa4  lea r12, [r14+rax*1]
000077334edceaa8  mov eax, [r15+0x60]
000077334edceaac  mov [r13+r12*1], eax
000077334edceab1  mov rax, [rsp+0x10]
000077334edceab6  lea r14, [rax-0x01]
000077334edceaba  mov [r15+0x50], r14
000077334edceabe  mov rax, [r15+0x58]
000077334edceac2  test rax, rax
000077334edceac5  setz al
000077334edceac8  movzx rax, al
000077334edceacc  mov [rsp+0x414], al
000077334edcead3  cmp byte ptr [rsp+0x414], 0x00
000077334edceadb  jz 0x000077334EDCEB0D
000077334edceadd  cmp dword ptr [r15+0x318], 0x00
000077334edceae5  jz 0x000077334EDCEB50
000077334edceaeb  nop [rax+rax*1], ax
000077334edceaf4  nop [rax+rax*1], eax
000077334edceafc  mov eax, 0x4101D4
000077334edceb01  mov [r15+0x100], rax
000077334edceb08  jmp 0x000077334EBFE110
000077334edceb0d  cmp dword ptr [r15+0x318], 0x00
000077334edceb15  jz 0x000077334EDCEC50
000077334edceb1b  nop [rax+rax*1], ax
000077334edceb24  nop [rax+rax*1], eax
000077334edceb2c  mov eax, 0x4101B8
000077334edceb31  mov [r15+0x100], rax
000077334edceb38  jmp 0x000077334EBFE110
000077334edceb3d  int3
000077334edceb3e  call 0x000077334ECB4B70
000077334edceb43  jmp 0x000077334EDCEAB1
000077334edceb48  int3
000077334edceb49  nop [rax], eax
000077334edceb50  cmp dword ptr [r15+0x318], 0x00
000077334edceb58  jz 0x000077334EDCEB90
000077334edceb5e  nop [rax+rax*1], ax
000077334edceb67  nop [rax+rax*1], eax
000077334edceb6f  mov eax, 0x41019C
000077334edceb74  mov [r15+0x100], rax
000077334edceb7b  jmp 0x000077334EBFE110
000077334edceb80  int3
000077334edceb81  int3
000077334edceb82  nop [rax+rax*1], ax
000077334edceb8b  nop [rax+rax*1], eax
000077334edceb90  mov qword ptr [r15+0x50], 0x00
000077334edceb98  mov rax, [r15+0x40]
000077334edceb9c  lea r14, [rax+0x01]
000077334edceba0  mov [r15+0x40], r14
000077334edceba4  mov rax, [r15+0x98]
000077334edcebab  mov r12d, [r15+0x48]
000077334edcebaf  mov [r13+rax*1], r12d
000077334edcebb4  xor eax, eax
000077334edcebb6  mov r12d, 0x400
000077334edcebbc  cmp r14, r12
000077334edcebbf  cmc
000077334edcebc0  lahf
000077334edcebc1  seto al
000077334edcebc4  mov [r15+0x108], eax
000077334edcebcb  mov eax, [r15+0x108]
000077334edcebd2  sahf
000077334edcebd3  jz 0x000077334EDCEC05
000077334edcebd5  cmp dword ptr [r15+0x318], 0x00
000077334edcebdd  jz 0x000077334EDCE990
000077334edcebe3  nop [rax+rax*1], ax
000077334edcebec  nop [rax+rax*1], eax
000077334edcebf4  mov eax, 0x4101B0
000077334edcebf9  mov [r15+0x100], rax
000077334edcec00  jmp 0x000077334EBFE110
000077334edcec05  cmp dword ptr [r15+0x318], 0x00
000077334edcec0d  jz 0x000077334EDCEDF0
000077334edcec13  nop [rax+rax*1], ax
000077334edcec1c  nop [rax+rax*1], eax
000077334edcec24  mov eax, 0x4101D8
000077334edcec29  mov [r15+0x100], rax
000077334edcec30  jmp 0x000077334EBFE110
000077334edcec35  int3
000077334edcec36  call 0x000077334EC0BAE0
000077334edcec3b  jmp 0x000077334EDCEBB4
000077334edcec40  int3
000077334edcec41  nop [rax+rax*1], ax
000077334edcec4a  nop [rax+rax*1], ax
000077334edcec50  mov eax, [r15+0x50]
000077334edcec54  lea r14d, [eax-0x01]
000077334edcec59  mov r14d, r14d
000077334edcec5c  mov [r15+0x58], r14
000077334edcec60  mov rax, [r15+0x58]
000077334edcec64  mov r14d, eax
000077334edcec67  mov r14d, r14d
000077334edcec6a  shl r14, 0x02
000077334edcec6e  mov rax, [r15+0x98]
000077334edcec75  lea r12, [rax+r14*1]
000077334edcec79  mov eax, [r13+r12*1]
000077334edcec7e  mov [rsp+0x10], eax
000077334edcec82  mov eax, eax
000077334edcec84  mov [r15+0x60], rax
000077334edcec88  mov eax, [r15+0x48]
000077334edcec8c  mov [rsp+0x20], eax
000077334edcec90  xor eax, eax
000077334edcec92  mov r14d, [rsp+0x10]
000077334edcec97  mov r12d, [rsp+0x20]
000077334edcec9c  cmp r14d, r12d
000077334edcec9f  cmc
000077334edceca0  lahf
000077334edceca1  seto al
000077334edceca4  mov [r15+0x108], eax
000077334edcecab  mov eax, [r15+0x108]
000077334edcecb2  sahf
000077334edcecb3  cmc
000077334edcecb4  jbe 0x000077334EDCECE6
000077334edcecb6  cmp dword ptr [r15+0x318], 0x00
000077334edcecbe  jz 0x000077334EDCEA90
000077334edcecc4  nop [rax+rax*1], ax
000077334edceccd  nop [rax+rax*1], eax
000077334edcecd5  mov eax, 0x4101C8
000077334edcecda  mov [r15+0x100], rax
000077334edcece1  jmp 0x000077334EBFE110
000077334edcece6  cmp dword ptr [r15+0x318], 0x00
000077334edcecee  jz 0x000077334EDCED30
000077334edcecf4  nop [rax+rax*1], ax
000077334edcecfd  nop [rax+rax*1], eax
000077334edced05  mov eax, 0x4101A0
000077334edced0a  mov [r15+0x100], rax
000077334edced11  jmp 0x000077334EBFE110
000077334edced16  int3
000077334edced17  call 0x000077334ECB4690
000077334edced1c  jmp 0x000077334EDCEC7E
000077334edced21  int3
000077334edced22  nop [rax+rax*1], ax
000077334edced2b  nop [rax+rax*1], eax
000077334edced30  mov rax, [r15+0x40]
000077334edced34  lea r14, [rax+0x01]
000077334edced38  mov [r15+0x40], r14
000077334edced3c  mov rax, [r15+0x50]
000077334edced40  mov r12d, eax
000077334edced43  mov r12d, r12d
000077334edced46  shl r12, 0x02
000077334edced4a  mov rax, [r15+0x98]
000077334edced51  lea r11, [rax+r12*1]
000077334edced55  mov eax, [r15+0x48]
000077334edced59  mov [r13+r11*1], eax
000077334edced5e  xor eax, eax
000077334edced60  mov r12d, 0x400
000077334edced66  cmp r14, r12
000077334edced69  cmc
000077334edced6a  lahf
000077334edced6b  seto al
000077334edced6e  mov [r15+0x108], eax
000077334edced75  mov eax, [r15+0x108]
000077334edced7c  sahf
000077334edced7d  jz 0x000077334EDCEDAF
000077334edced7f  cmp dword ptr [r15+0x318], 0x00
000077334edced87  jz 0x000077334EDCE990
000077334edced8d  nop [rax+rax*1], ax
000077334edced96  nop [rax+rax*1], eax
000077334edced9e  mov eax, 0x4101B0
000077334edceda3  mov [r15+0x100], rax
000077334edcedaa  jmp 0x000077334EBFE110
000077334edcedaf  cmp dword ptr [r15+0x318], 0x00
000077334edcedb7  jz 0x000077334EDCEDF0
000077334edcedbd  nop [rax+rax*1], ax
000077334edcedc6  nop [rax+rax*1], eax
000077334edcedce  mov eax, 0x4101D8
000077334edcedd3  mov [r15+0x100], rax
000077334edcedda  jmp 0x000077334EBFE110
000077334edceddf  int3
000077334edcede0  call 0x000077334ECA4270
000077334edcede5  jmp 0x000077334EDCED5E
000077334edcedea  int3
000077334edcedeb  nop [rax+rax*1], eax
000077334edcedf0  mov qword ptr [r15+0x40], 0x420000
000077334edcedf8  mov eax, 0x420288
000077334edcedfd  mov r14, [r13+rax*1]
000077334edcee02  mov rax, [r15+0x98]
000077334edcee09  mov r12d, [r13+rax*1]
000077334edcee0e  lea r11, [rax+0x04]
000077334edcee12  mov eax, [r13+r11*1]
000077334edcee17  mov r12d, r12d
000077334edcee1a  mov [r15+0x68], r12
000077334edcee1e  mov eax, eax
000077334edcee20  mov [r15+0x60], rax
000077334edcee24  mov rax, [r15+0x68]
000077334edcee28  mov [r15+0x68], rax
000077334edcee2c  mov qword ptr [r15+0x58], 0x02
000077334edcee34  mov [rsp+0x10], rax
000077334edcee39  xor eax, eax
000077334edcee3b  mov r12d, 0x02
000077334edcee41  mov r11d, 0x400
000077334edcee47  cmp r12, r11
000077334edcee4a  cmc
000077334edcee4b  lahf
000077334edcee4c  seto al
000077334edcee4f  mov [r15+0x108], eax
000077334edcee56  mov rax, [r15+0x60]
000077334edcee5a  mov r12d, 0x02
000077334edcee60  imul rax, r12
000077334edcee64  mov [r15+0x50], rax
000077334edcee68  mov rax, [rsp+0x10]
000077334edcee6d  lea r12, [rax+r14*1]
000077334edcee71  mov [r15+0x48], r12
000077334edcee75  mov eax, [r15+0x108]
000077334edcee7c  sahf
000077334edcee7d  jnz 0x000077334EDCEEAF
000077334edcee7f  cmp dword ptr [r15+0x318], 0x00
000077334edcee87  jz 0x000077334EDCF020
000077334edcee8d  nop [rax+rax*1], ax
000077334edcee96  nop [rax+rax*1], eax
000077334edcee9e  mov eax, 0x410208
000077334edceea3  mov [r15+0x100], rax
000077334edceeaa  jmp 0x000077334EBFE110
000077334edceeaf  cmp dword ptr [r15+0x318], 0x00
000077334edceeb7  jz 0x000077334EDCEF00
000077334edceebd  nop [rax+rax*1], ax
000077334edceec6  nop [rax+rax*1], eax
000077334edceece  mov eax, 0x4101E8
000077334edceed3  mov [r15+0x100], rax
000077334edceeda  jmp 0x000077334EBFE110
000077334edceedf  int3
000077334edceee0  call 0x000077334EC0DC20
000077334edceee5  jmp 0x000077334EDCEE02
000077334edceeea  call 0x000077334EC0B5E0
000077334edceeef  jmp 0x000077334EDCEE0E
000077334edceef4  call 0x000077334ECA3D90
000077334edceef9  jmp 0x000077334EDCEE17
000077334edceefe  int3
000077334edceeff  nop
000077334edcef00  mov rax, [r15+0x98]
000077334edcef07  mov r14, [r15+0x58]
000077334edcef0b  mov [rsp+0x10], r14
000077334edcef10  shl r14, 0x02
000077334edcef14  lea r12, [rax+r14*1]
000077334edcef18  mov eax, [r13+r12*1]
000077334edcef1d  lea r14, [r12+0x04]
000077334edcef22  mov r12d, [r13+r14*1]
000077334edcef27  mov eax, eax
000077334edcef29  mov [r15+0x68], rax
000077334edcef2d  mov r12d, r12d
000077334edcef30  mov [r15+0x60], r12
000077334edcef34  mov rax, [r15+0x68]
000077334edcef38  mov [rsp+0x20], rax
000077334edcef3d  mov r14, [rsp+0x10]
000077334edcef42  imul rax, r14
000077334edcef46  mov r12, [rsp+0x20]
000077334edcef4b  lea r11, [r12+rax*1]
000077334edcef4f  mov [r15+0x68], r11
000077334edcef53  lea rax, [r14+0x02]
000077334edcef57  mov [r15+0x58], rax
000077334edcef5b  mov [rsp+0x10], rax
000077334edcef60  xor eax, eax
000077334edcef62  mov r14, [rsp+0x10]
000077334edcef67  mov r12d, 0x400
000077334edcef6d  cmp r14, r12
000077334edcef70  cmc
000077334edcef71  lahf
000077334edcef72  seto al
000077334edcef75  mov [r15+0x108], eax
000077334edcef7c  mov rax, [r15+0x50]
000077334edcef80  mov r12, [r15+0x60]
000077334edcef84  imul r14, r12
000077334edcef88  lea r12, [rax+r14*1]
000077334edcef8c  mov [r15+0x50], r12
000077334edcef90  mov rax, [r15+0x48]
000077334edcef94  lea r14, [r11+rax*1]
000077334edcef98  mov [r15+0x48], r14
000077334edcef9c  mov eax, [r15+0x108]
000077334edcefa3  sahf
000077334edcefa4  jnz 0x000077334EDCEFD6
000077334edcefa6  cmp dword ptr [r15+0x318], 0x00
000077334edcefae  jz 0x000077334EDCF020
000077334edcefb4  nop [rax+rax*1], ax
000077334edcefbd  nop [rax+rax*1], eax
000077334edcefc5  mov eax, 0x410208
000077334edcefca  mov [r15+0x100], rax
000077334edcefd1  jmp 0x000077334EBFE110
000077334edcefd6  cmp dword ptr [r15+0x318], 0x00
000077334edcefde  jz 0x000077334EDCEF00
000077334edcefe4  nop [rax+rax*1], ax
000077334edcefed  nop [rax+rax*1], eax
000077334edceff5  mov eax, 0x4101E8
000077334edceffa  mov [r15+0x100], rax
000077334edcf001  jmp 0x000077334EBFE110
000077334edcf006  int3
000077334edcf007  call 0x000077334ECB4690
000077334edcf00c  jmp 0x000077334EDCEF1D
000077334edcf011  call 0x000077334ECE26A0
000077334edcf016  jmp 0x000077334EDCEF27
000077334edcf01b  int3
000077334edcf01c  nop [rax], eax
000077334edcf020  mov rax, [r15+0xF8]
000077334edcf027  lea r14, [rax+0x10]
000077334edcf02b  mov r12, [r13+r14*1]
000077334edcf030  lea r14, [rax+0x18]
000077334edcf034  mov r11, [r13+r14*1]
000077334edcf039  mov [r15+0xA0], r12
000077334edcf040  mov [r15+0x98], r11
000077334edcf047  mov r14, [r15+0x50]
000077334edcf04b  mov r12, [r15+0x48]
000077334edcf04f  lea r11, [r14+r12*1]
000077334edcf053  mov [r15+0x48], r11
000077334edcf057  mov r14, [r15+0x40]
000077334edcf05b  lea r12, [r14+0x288]
000077334edcf062  mov [r13+r12*1], r11
000077334edcf067  mov r14, [r13+rax*1]
000077334edcf06c  mov [r15+0xF0], r14
000077334edcf073  lea r12, [rax+0x20]
000077334edcf077  mov [r15+0xF8], r12
000077334edcf07e  mov [r15+0x100], r14
000077334edcf085  jmp 0x000077334EDCE5C0
000077334edcf08a  int3
000077334edcf08b  call 0x000077334ECE27E0
000077334edcf090  jmp 0x000077334EDCF030
000077334edcf095  call 0x000077334ECE1570
000077334edcf09a  jmp 0x000077334EDCF039
000077334edcf09f  call 0x000077334ECC0860
000077334edcf0a4  jmp 0x000077334EDCF067
000077334edcf0a9  call 0x000077334EC0DC20
000077334edcf0ae  jmp 0x000077334EDCF06C
000077334edcf0b3  int3
000077334edcf0b4  nop [rax+rax*1], ax
000077334edcf0bd  nop [rax], eax
000077334edcf0c0  mov qword ptr [r15+0x100], 0x04
000077334edcf0cb  mov esi, 0x00
000077334edcf0d0  mov edx, 0x09
000077334edcf0d5  mov rdi, 0x7FFDC1B92350
000077334edcf0df  mov rax, 0x556F4D77F970
000077334edcf0e9  call rax
000077334edcf0eb  cmp dword ptr [r15+0x318], 0x00
000077334edcf0f3  jnz 0x000077334EBFE110
000077334edcf0f9  jmp 0x000077334EBFE0A0
000077334edcf0fe  int3
000077334edcf0ff  int3
