00007c74f29ce69b  nop [rax+rax*1], eax
00007c74f29ce6a0  mov qword ptr [r15+0x20], 0x420080
00007c74f29ce6a8  mov qword ptr [r15], 0x00
00007c74f29ce6af  vmovaps xmm1, [0x00007C74F25FE010]
00007c74f29ce6b7  movq xmm1, xmm1
00007c74f29ce6bb  vmovaps xmm15, [0x00007C74F25FE020]
00007c74f29ce6c3  movq xmm15, xmm15
00007c74f29ce6c8  movaps [r15+0x120], xmm15
00007c74f29ce6d0  movq rax, xmm1
00007c74f29ce6d5  movq r14, xmm15
00007c74f29ce6da  vmovq xmm1, rax
00007c74f29ce6df  vmovq xmm14, r14
00007c74f29ce6e4  movaps xmm13, xmm1
00007c74f29ce6e8  addsd xmm13, xmm14
00007c74f29ce6ed  ucomisd xmm13, xmm13
00007c74f29ce6f2  jp 0x00007C74F29CE8CC
00007c74f29ce6f8  movq xmm13, xmm13
00007c74f29ce6fd  movq rax, xmm13
00007c74f29ce702  movq r14, xmm15
00007c74f29ce707  vmovq xmm1, rax
00007c74f29ce70c  vmovq xmm14, r14
00007c74f29ce711  movaps xmm13, xmm1
00007c74f29ce715  addsd xmm13, xmm14
00007c74f29ce71a  ucomisd xmm13, xmm13
00007c74f29ce71f  jp 0x00007C74F29CE914
00007c74f29ce725  movq xmm13, xmm13
00007c74f29ce72a  movq rax, xmm13
00007c74f29ce72f  movq r14, xmm15
00007c74f29ce734  vmovq xmm1, rax
00007c74f29ce739  vmovq xmm14, r14
00007c74f29ce73e  movaps xmm13, xmm1
00007c74f29ce742  addsd xmm13, xmm14
00007c74f29ce747  ucomisd xmm13, xmm13
00007c74f29ce74c  jp 0x00007C74F29CE95C
00007c74f29ce752  movq xmm13, xmm13
00007c74f29ce757  movq rax, xmm13
00007c74f29ce75c  movq r14, xmm15
00007c74f29ce761  vmovq xmm1, rax
00007c74f29ce766  vmovq xmm14, r14
00007c74f29ce76b  movaps xmm13, xmm1
00007c74f29ce76f  addsd xmm13, xmm14
00007c74f29ce774  ucomisd xmm13, xmm13
00007c74f29ce779  jp 0x00007C74F29CE9A4
00007c74f29ce77f  movq xmm13, xmm13
00007c74f29ce784  movq rax, xmm13
00007c74f29ce789  movq r14, xmm15
00007c74f29ce78e  vmovq xmm1, rax
00007c74f29ce793  vmovq xmm14, r14
00007c74f29ce798  movaps xmm13, xmm1
00007c74f29ce79c  addsd xmm13, xmm14
00007c74f29ce7a1  ucomisd xmm13, xmm13
00007c74f29ce7a6  jp 0x00007C74F29CE9EC
00007c74f29ce7ac  movq xmm13, xmm13
00007c74f29ce7b1  movq rax, xmm13
00007c74f29ce7b6  movq r14, xmm15
00007c74f29ce7bb  vmovq xmm1, rax
00007c74f29ce7c0  vmovq xmm14, r14
00007c74f29ce7c5  movaps xmm13, xmm1
00007c74f29ce7c9  addsd xmm13, xmm14
00007c74f29ce7ce  ucomisd xmm13, xmm13
00007c74f29ce7d3  jp 0x00007C74F29CEA34
00007c74f29ce7d9  movq xmm13, xmm13
00007c74f29ce7de  movq rax, xmm13
00007c74f29ce7e3  movq r14, xmm15
00007c74f29ce7e8  vmovq xmm1, rax
00007c74f29ce7ed  vmovq xmm14, r14
00007c74f29ce7f2  movaps xmm13, xmm1
00007c74f29ce7f6  addsd xmm13, xmm14
00007c74f29ce7fb  ucomisd xmm13, xmm13
00007c74f29ce800  jp 0x00007C74F29CEA7C
00007c74f29ce806  movq xmm13, xmm13
00007c74f29ce80b  movq rax, xmm13
00007c74f29ce810  movq r14, xmm15
00007c74f29ce815  vmovq xmm1, rax
00007c74f29ce81a  vmovq xmm15, r14
00007c74f29ce81f  movaps xmm14, xmm1
00007c74f29ce823  addsd xmm14, xmm15
00007c74f29ce828  ucomisd xmm14, xmm14
00007c74f29ce82d  jp 0x00007C74F29CEAC4
00007c74f29ce833  movq xmm14, xmm14
00007c74f29ce838  movaps [r15+0x110], xmm14
00007c74f29ce840  xor eax, eax
00007c74f29ce842  mov r14d, 0x1E848
00007c74f29ce848  mov r12d, 0x01
00007c74f29ce84e  sub r14, r12
00007c74f29ce851  cmc
00007c74f29ce852  lahf
00007c74f29ce853  seto al
00007c74f29ce856  mov [r15+0x108], eax
00007c74f29ce85d  mov [r15+0x08], r14
00007c74f29ce861  mov eax, [r15+0x108]
00007c74f29ce868  sahf
00007c74f29ce869  jnz 0x00007C74F29CE89B
00007c74f29ce86b  cmp dword ptr [r15+0x318], 0x00
00007c74f29ce873  jz 0x00007C74F29CEF70
00007c74f29ce879  nop [rax+rax*1], ax
00007c74f29ce882  nop [rax+rax*1], eax
00007c74f29ce88a  mov eax, 0x41006C
00007c74f29ce88f  mov [r15+0x100], rax
00007c74f29ce896  jmp 0x00007C74F27FE110
00007c74f29ce89b  cmp dword ptr [r15+0x318], 0x00
00007c74f29ce8a3  jz 0x00007C74F29CEB10
00007c74f29ce8a9  nop [rax+rax*1], ax
00007c74f29ce8b2  nop [rax+rax*1], eax
00007c74f29ce8ba  mov eax, 0x410044
00007c74f29ce8bf  mov [r15+0x100], rax
00007c74f29ce8c6  jmp 0x00007C74F27FE110
00007c74f29ce8cb  int3
00007c74f29ce8cc  ucomisd xmm1, xmm14
00007c74f29ce8d1  jp 0x00007C74F29CE8E0
00007c74f29ce8d3  movaps xmm13, [0x00007C74F25FE030]
00007c74f29ce8db  jmp 0x00007C74F29CE6F8
00007c74f29ce8e0  vxorps xmm0, xmm1, xmm14
00007c74f29ce8e5  pextrw eax, xmm0, 0x03
00007c74f29ce8ea  and eax, 0x7FF8
00007c74f29ce8ef  cmp eax, 0x08
00007c74f29ce8f2  jnz 0x00007C74F29CE6F8
00007c74f29ce8f8  movq rax, xmm14
00007c74f29ce8fd  shl rax, 0x0D
00007c74f29ce901  jbe 0x00007C74F29CE6F8
00007c74f29ce907  vorps xmm13, xmm14, [0x00007C74F25FE040]
00007c74f29ce90f  jmp 0x00007C74F29CE6F8
00007c74f29ce914  ucomisd xmm1, xmm14
00007c74f29ce919  jp 0x00007C74F29CE928
00007c74f29ce91b  movaps xmm13, [0x00007C74F25FE030]
00007c74f29ce923  jmp 0x00007C74F29CE725
00007c74f29ce928  vxorps xmm0, xmm1, xmm14
00007c74f29ce92d  pextrw eax, xmm0, 0x03
00007c74f29ce932  and eax, 0x7FF8
00007c74f29ce937  cmp eax, 0x08
00007c74f29ce93a  jnz 0x00007C74F29CE725
00007c74f29ce940  movq rax, xmm14
00007c74f29ce945  shl rax, 0x0D
00007c74f29ce949  jbe 0x00007C74F29CE725
00007c74f29ce94f  vorps xmm13, xmm14, [0x00007C74F25FE040]
00007c74f29ce957  jmp 0x00007C74F29CE725
00007c74f29ce95c  ucomisd xmm1, xmm14
00007c74f29ce961  jp 0x00007C74F29CE970
00007c74f29ce963  movaps xmm13, [0x00007C74F25FE030]
00007c74f29ce96b  jmp 0x00007C74F29CE752
00007c74f29ce970  vxorps xmm0, xmm1, xmm14
00007c74f29ce975  pextrw eax, xmm0, 0x03
00007c74f29ce97a  and eax, 0x7FF8
00007c74f29ce97f  cmp eax, 0x08
00007c74f29ce982  jnz 0x00007C74F29CE752
00007c74f29ce988  movq rax, xmm14
00007c74f29ce98d  shl rax, 0x0D
00007c74f29ce991  jbe 0x00007C74F29CE752
00007c74f29ce997  vorps xmm13, xmm14, [0x00007C74F25FE040]
00007c74f29ce99f  jmp 0x00007C74F29CE752
00007c74f29ce9a4  ucomisd xmm1, xmm14
00007c74f29ce9a9  jp 0x00007C74F29CE9B8
00007c74f29ce9ab  movaps xmm13, [0x00007C74F25FE030]
00007c74f29ce9b3  jmp 0x00007C74F29CE77F
00007c74f29ce9b8  vxorps xmm0, xmm1, xmm14
00007c74f29ce9bd  pextrw eax, xmm0, 0x03
00007c74f29ce9c2  and eax, 0x7FF8
00007c74f29ce9c7  cmp eax, 0x08
00007c74f29ce9ca  jnz 0x00007C74F29CE77F
00007c74f29ce9d0  movq rax, xmm14
00007c74f29ce9d5  shl rax, 0x0D
00007c74f29ce9d9  jbe 0x00007C74F29CE77F
00007c74f29ce9df  vorps xmm13, xmm14, [0x00007C74F25FE040]
00007c74f29ce9e7  jmp 0x00007C74F29CE77F
00007c74f29ce9ec  ucomisd xmm1, xmm14
00007c74f29ce9f1  jp 0x00007C74F29CEA00
00007c74f29ce9f3  movaps xmm13, [0x00007C74F25FE030]
00007c74f29ce9fb  jmp 0x00007C74F29CE7AC
00007c74f29cea00  vxorps xmm0, xmm1, xmm14
00007c74f29cea05  pextrw eax, xmm0, 0x03
00007c74f29cea0a  and eax, 0x7FF8
00007c74f29cea0f  cmp eax, 0x08
00007c74f29cea12  jnz 0x00007C74F29CE7AC
00007c74f29cea18  movq rax, xmm14
00007c74f29cea1d  shl rax, 0x0D
00007c74f29cea21  jbe 0x00007C74F29CE7AC
00007c74f29cea27  vorps xmm13, xmm14, [0x00007C74F25FE040]
00007c74f29cea2f  jmp 0x00007C74F29CE7AC
00007c74f29cea34  ucomisd xmm1, xmm14
00007c74f29cea39  jp 0x00007C74F29CEA48
00007c74f29cea3b  movaps xmm13, [0x00007C74F25FE030]
00007c74f29cea43  jmp 0x00007C74F29CE7D9
00007c74f29cea48  vxorps xmm0, xmm1, xmm14
00007c74f29cea4d  pextrw eax, xmm0, 0x03
00007c74f29cea52  and eax, 0x7FF8
00007c74f29cea57  cmp eax, 0x08
00007c74f29cea5a  jnz 0x00007C74F29CE7D9
00007c74f29cea60  movq rax, xmm14
00007c74f29cea65  shl rax, 0x0D
00007c74f29cea69  jbe 0x00007C74F29CE7D9
00007c74f29cea6f  vorps xmm13, xmm14, [0x00007C74F25FE040]
00007c74f29cea77  jmp 0x00007C74F29CE7D9
00007c74f29cea7c  ucomisd xmm1, xmm14
00007c74f29cea81  jp 0x00007C74F29CEA90
00007c74f29cea83  movaps xmm13, [0x00007C74F25FE030]
00007c74f29cea8b  jmp 0x00007C74F29CE806
00007c74f29cea90  vxorps xmm0, xmm1, xmm14
00007c74f29cea95  pextrw eax, xmm0, 0x03
00007c74f29cea9a  and eax, 0x7FF8
00007c74f29cea9f  cmp eax, 0x08
00007c74f29ceaa2  jnz 0x00007C74F29CE806
00007c74f29ceaa8  movq rax, xmm14
00007c74f29ceaad  shl rax, 0x0D
00007c74f29ceab1  jbe 0x00007C74F29CE806
00007c74f29ceab7  vorps xmm13, xmm14, [0x00007C74F25FE040]
00007c74f29ceabf  jmp 0x00007C74F29CE806
00007c74f29ceac4  ucomisd xmm1, xmm15
00007c74f29ceac9  jp 0x00007C74F29CEAD8
00007c74f29ceacb  movaps xmm14, [0x00007C74F25FE030]
00007c74f29cead3  jmp 0x00007C74F29CE833
00007c74f29cead8  vxorps xmm0, xmm1, xmm15
00007c74f29ceadd  pextrw eax, xmm0, 0x03
00007c74f29ceae2  and eax, 0x7FF8
00007c74f29ceae7  cmp eax, 0x08
00007c74f29ceaea  jnz 0x00007C74F29CE833
00007c74f29ceaf0  movq rax, xmm15
00007c74f29ceaf5  shl rax, 0x0D
00007c74f29ceaf9  jbe 0x00007C74F29CE833
00007c74f29ceaff  vorps xmm14, xmm15, [0x00007C74F25FE040]
00007c74f29ceb07  jmp 0x00007C74F29CE833
00007c74f29ceb0c  int3
00007c74f29ceb0d  nop [rax], eax
00007c74f29ceb10  movaps xmm1, [r15+0x110]
00007c74f29ceb18  movq rax, xmm1
00007c74f29ceb1d  movaps xmm1, [r15+0x120]
00007c74f29ceb25  movq r14, xmm1
00007c74f29ceb2a  vmovq xmm15, rax
00007c74f29ceb2f  vmovq xmm14, r14
00007c74f29ceb34  movaps xmm13, xmm15
00007c74f29ceb38  addsd xmm13, xmm14
00007c74f29ceb3d  ucomisd xmm13, xmm13
00007c74f29ceb42  jp 0x00007C74F29CED24
00007c74f29ceb48  movq xmm13, xmm13
00007c74f29ceb4d  movq rax, xmm13
00007c74f29ceb52  movq r14, xmm1
00007c74f29ceb57  vmovq xmm15, rax
00007c74f29ceb5c  vmovq xmm14, r14
00007c74f29ceb61  movaps xmm13, xmm15
00007c74f29ceb65  addsd xmm13, xmm14
00007c74f29ceb6a  ucomisd xmm13, xmm13
00007c74f29ceb6f  jp 0x00007C74F29CED6C
00007c74f29ceb75  movq xmm13, xmm13
00007c74f29ceb7a  movq rax, xmm13
00007c74f29ceb7f  movq r14, xmm1
00007c74f29ceb84  vmovq xmm15, rax
00007c74f29ceb89  vmovq xmm14, r14
00007c74f29ceb8e  movaps xmm13, xmm15
00007c74f29ceb92  addsd xmm13, xmm14
00007c74f29ceb97  ucomisd xmm13, xmm13
00007c74f29ceb9c  jp 0x00007C74F29CEDB4
00007c74f29ceba2  movq xmm13, xmm13
00007c74f29ceba7  movq rax, xmm13
00007c74f29cebac  movq r14, xmm1
00007c74f29cebb1  vmovq xmm15, rax
00007c74f29cebb6  vmovq xmm14, r14
00007c74f29cebbb  movaps xmm13, xmm15
00007c74f29cebbf  addsd xmm13, xmm14
00007c74f29cebc4  ucomisd xmm13, xmm13
00007c74f29cebc9  jp 0x00007C74F29CEDFC
00007c74f29cebcf  movq xmm13, xmm13
00007c74f29cebd4  movq rax, xmm13
00007c74f29cebd9  movq r14, xmm1
00007c74f29cebde  vmovq xmm15, rax
00007c74f29cebe3  vmovq xmm14, r14
00007c74f29cebe8  movaps xmm13, xmm15
00007c74f29cebec  addsd xmm13, xmm14
00007c74f29cebf1  ucomisd xmm13, xmm13
00007c74f29cebf6  jp 0x00007C74F29CEE44
00007c74f29cebfc  movq xmm13, xmm13
00007c74f29cec01  movq rax, xmm13
00007c74f29cec06  movq r14, xmm1
00007c74f29cec0b  vmovq xmm15, rax
00007c74f29cec10  vmovq xmm14, r14
00007c74f29cec15  movaps xmm13, xmm15
00007c74f29cec19  addsd xmm13, xmm14
00007c74f29cec1e  ucomisd xmm13, xmm13
00007c74f29cec23  jp 0x00007C74F29CEE8C
00007c74f29cec29  movq xmm13, xmm13
00007c74f29cec2e  movq rax, xmm13
00007c74f29cec33  movq r14, xmm1
00007c74f29cec38  vmovq xmm15, rax
00007c74f29cec3d  vmovq xmm14, r14
00007c74f29cec42  movaps xmm13, xmm15
00007c74f29cec46  addsd xmm13, xmm14
00007c74f29cec4b  ucomisd xmm13, xmm13
00007c74f29cec50  jp 0x00007C74F29CEED4
00007c74f29cec56  movq xmm13, xmm13
00007c74f29cec5b  movq rax, xmm13
00007c74f29cec60  movq r14, xmm1
00007c74f29cec65  vmovq xmm1, rax
00007c74f29cec6a  vmovq xmm15, r14
00007c74f29cec6f  movaps xmm14, xmm1
00007c74f29cec73  addsd xmm14, xmm15
00007c74f29cec78  ucomisd xmm14, xmm14
00007c74f29cec7d  jp 0x00007C74F29CEF1C
00007c74f29cec83  movq xmm14, xmm14
00007c74f29cec88  movaps [r15+0x110], xmm14
00007c74f29cec90  mov rax, [r15+0x08]
00007c74f29cec94  mov [rsp+0x10], rax
00007c74f29cec99  xor eax, eax
00007c74f29cec9b  mov r14, [rsp+0x10]
00007c74f29ceca0  mov r12d, 0x01
00007c74f29ceca6  sub r14, r12
00007c74f29ceca9  cmc
00007c74f29cecaa  lahf
00007c74f29cecab  seto al
00007c74f29cecae  mov [r15+0x108], eax
00007c74f29cecb5  mov [r15+0x08], r14
00007c74f29cecb9  mov eax, [r15+0x108]
00007c74f29cecc0  sahf
00007c74f29cecc1  jnz 0x00007C74F29CECF3
00007c74f29cecc3  cmp dword ptr [r15+0x318], 0x00
00007c74f29ceccb  jz 0x00007C74F29CEF70
00007c74f29cecd1  nop [rax+rax*1], ax
00007c74f29cecda  nop [rax+rax*1], eax
00007c74f29cece2  mov eax, 0x41006C
00007c74f29cece7  mov [r15+0x100], rax
00007c74f29cecee  jmp 0x00007C74F27FE110
00007c74f29cecf3  cmp dword ptr [r15+0x318], 0x00
00007c74f29cecfb  jz 0x00007C74F29CEB10
00007c74f29ced01  nop [rax+rax*1], ax
00007c74f29ced0a  nop [rax+rax*1], eax
00007c74f29ced12  mov eax, 0x410044
00007c74f29ced17  mov [r15+0x100], rax
00007c74f29ced1e  jmp 0x00007C74F27FE110
00007c74f29ced23  int3
00007c74f29ced24  ucomisd xmm15, xmm14
00007c74f29ced29  jp 0x00007C74F29CED38
00007c74f29ced2b  movaps xmm13, [0x00007C74F25FE030]
00007c74f29ced33  jmp 0x00007C74F29CEB48
00007c74f29ced38  vxorps xmm0, xmm15, xmm14
00007c74f29ced3d  pextrw eax, xmm0, 0x03
00007c74f29ced42  and eax, 0x7FF8
00007c74f29ced47  cmp eax, 0x08
00007c74f29ced4a  jnz 0x00007C74F29CEB48
00007c74f29ced50  movq rax, xmm14
00007c74f29ced55  shl rax, 0x0D
00007c74f29ced59  jbe 0x00007C74F29CEB48
00007c74f29ced5f  vorps xmm13, xmm14, [0x00007C74F25FE040]
00007c74f29ced67  jmp 0x00007C74F29CEB48
00007c74f29ced6c  ucomisd xmm15, xmm14
00007c74f29ced71  jp 0x00007C74F29CED80
00007c74f29ced73  movaps xmm13, [0x00007C74F25FE030]
00007c74f29ced7b  jmp 0x00007C74F29CEB75
00007c74f29ced80  vxorps xmm0, xmm15, xmm14
00007c74f29ced85  pextrw eax, xmm0, 0x03
00007c74f29ced8a  and eax, 0x7FF8
00007c74f29ced8f  cmp eax, 0x08
00007c74f29ced92  jnz 0x00007C74F29CEB75
00007c74f29ced98  movq rax, xmm14
00007c74f29ced9d  shl rax, 0x0D
00007c74f29ceda1  jbe 0x00007C74F29CEB75
00007c74f29ceda7  vorps xmm13, xmm14, [0x00007C74F25FE040]
00007c74f29cedaf  jmp 0x00007C74F29CEB75
00007c74f29cedb4  ucomisd xmm15, xmm14
00007c74f29cedb9  jp 0x00007C74F29CEDC8
00007c74f29cedbb  movaps xmm13, [0x00007C74F25FE030]
00007c74f29cedc3  jmp 0x00007C74F29CEBA2
00007c74f29cedc8  vxorps xmm0, xmm15, xmm14
00007c74f29cedcd  pextrw eax, xmm0, 0x03
00007c74f29cedd2  and eax, 0x7FF8
00007c74f29cedd7  cmp eax, 0x08
00007c74f29cedda  jnz 0x00007C74F29CEBA2
00007c74f29cede0  movq rax, xmm14
00007c74f29cede5  shl rax, 0x0D
00007c74f29cede9  jbe 0x00007C74F29CEBA2
00007c74f29cedef  vorps xmm13, xmm14, [0x00007C74F25FE040]
00007c74f29cedf7  jmp 0x00007C74F29CEBA2
00007c74f29cedfc  ucomisd xmm15, xmm14
00007c74f29cee01  jp 0x00007C74F29CEE10
00007c74f29cee03  movaps xmm13, [0x00007C74F25FE030]
00007c74f29cee0b  jmp 0x00007C74F29CEBCF
00007c74f29cee10  vxorps xmm0, xmm15, xmm14
00007c74f29cee15  pextrw eax, xmm0, 0x03
00007c74f29cee1a  and eax, 0x7FF8
00007c74f29cee1f  cmp eax, 0x08
00007c74f29cee22  jnz 0x00007C74F29CEBCF
00007c74f29cee28  movq rax, xmm14
00007c74f29cee2d  shl rax, 0x0D
00007c74f29cee31  jbe 0x00007C74F29CEBCF
00007c74f29cee37  vorps xmm13, xmm14, [0x00007C74F25FE040]
00007c74f29cee3f  jmp 0x00007C74F29CEBCF
00007c74f29cee44  ucomisd xmm15, xmm14
00007c74f29cee49  jp 0x00007C74F29CEE58
00007c74f29cee4b  movaps xmm13, [0x00007C74F25FE030]
00007c74f29cee53  jmp 0x00007C74F29CEBFC
00007c74f29cee58  vxorps xmm0, xmm15, xmm14
00007c74f29cee5d  pextrw eax, xmm0, 0x03
00007c74f29cee62  and eax, 0x7FF8
00007c74f29cee67  cmp eax, 0x08
00007c74f29cee6a  jnz 0x00007C74F29CEBFC
00007c74f29cee70  movq rax, xmm14
00007c74f29cee75  shl rax, 0x0D
00007c74f29cee79  jbe 0x00007C74F29CEBFC
00007c74f29cee7f  vorps xmm13, xmm14, [0x00007C74F25FE040]
00007c74f29cee87  jmp 0x00007C74F29CEBFC
00007c74f29cee8c  ucomisd xmm15, xmm14
00007c74f29cee91  jp 0x00007C74F29CEEA0
00007c74f29cee93  movaps xmm13, [0x00007C74F25FE030]
00007c74f29cee9b  jmp 0x00007C74F29CEC29
00007c74f29ceea0  vxorps xmm0, xmm15, xmm14
00007c74f29ceea5  pextrw eax, xmm0, 0x03
00007c74f29ceeaa  and eax, 0x7FF8
00007c74f29ceeaf  cmp eax, 0x08
00007c74f29ceeb2  jnz 0x00007C74F29CEC29
00007c74f29ceeb8  movq rax, xmm14
00007c74f29ceebd  shl rax, 0x0D
00007c74f29ceec1  jbe 0x00007C74F29CEC29
00007c74f29ceec7  vorps xmm13, xmm14, [0x00007C74F25FE040]
00007c74f29ceecf  jmp 0x00007C74F29CEC29
00007c74f29ceed4  ucomisd xmm15, xmm14
00007c74f29ceed9  jp 0x00007C74F29CEEE8
00007c74f29ceedb  movaps xmm13, [0x00007C74F25FE030]
00007c74f29ceee3  jmp 0x00007C74F29CEC56
00007c74f29ceee8  vxorps xmm0, xmm15, xmm14
00007c74f29ceeed  pextrw eax, xmm0, 0x03
00007c74f29ceef2  and eax, 0x7FF8
00007c74f29ceef7  cmp eax, 0x08
00007c74f29ceefa  jnz 0x00007C74F29CEC56
00007c74f29cef00  movq rax, xmm14
00007c74f29cef05  shl rax, 0x0D
00007c74f29cef09  jbe 0x00007C74F29CEC56
00007c74f29cef0f  vorps xmm13, xmm14, [0x00007C74F25FE040]
00007c74f29cef17  jmp 0x00007C74F29CEC56
00007c74f29cef1c  ucomisd xmm1, xmm15
00007c74f29cef21  jp 0x00007C74F29CEF30
00007c74f29cef23  movaps xmm14, [0x00007C74F25FE030]
00007c74f29cef2b  jmp 0x00007C74F29CEC83
00007c74f29cef30  vxorps xmm0, xmm1, xmm15
00007c74f29cef35  pextrw eax, xmm0, 0x03
00007c74f29cef3a  and eax, 0x7FF8
00007c74f29cef3f  cmp eax, 0x08
00007c74f29cef42  jnz 0x00007C74F29CEC83
00007c74f29cef48  movq rax, xmm15
00007c74f29cef4d  shl rax, 0x0D
00007c74f29cef51  jbe 0x00007C74F29CEC83
00007c74f29cef57  vorps xmm14, xmm15, [0x00007C74F25FE040]
00007c74f29cef5f  jmp 0x00007C74F29CEC83
00007c74f29cef64  int3
00007c74f29cef65  nop [rax+rax*1], ax
00007c74f29cef6e  nop
00007c74f29cef70  mov rax, [r15+0x20]
00007c74f29cef74  movaps xmm1, [r15+0x110]
00007c74f29cef7c  movq r14, xmm1
00007c74f29cef81  mov [r13+rax*1], r14
00007c74f29cef86  mov rax, [r15+0xF0]
00007c74f29cef8d  mov [r15+0x100], rax
00007c74f29cef94  jmp 0x00007C74F29CE5C0
00007c74f29cef99  int3
00007c74f29cef9a  call 0x00007C74F280E120
00007c74f29cef9f  jmp 0x00007C74F29CEF86
00007c74f29cefa4  int3
00007c74f29cefa5  nop [rax+rax*1], ax
00007c74f29cefae  nop
00007c74f29cefb0  mov qword ptr [r15+0x100], 0x04
00007c74f29cefbb  mov esi, 0x00
00007c74f29cefc0  mov edx, 0x09
00007c74f29cefc5  mov rdi, 0x7FFCAD2BF870
00007c74f29cefcf  mov rax, 0x629E962BE970
00007c74f29cefd9  call rax
00007c74f29cefdb  cmp dword ptr [r15+0x318], 0x00
00007c74f29cefe3  jnz 0x00007C74F27FE110
00007c74f29cefe9  jmp 0x00007C74F27FE0A0
00007c74f29cefee  int3
00007c74f29cefef  int3
