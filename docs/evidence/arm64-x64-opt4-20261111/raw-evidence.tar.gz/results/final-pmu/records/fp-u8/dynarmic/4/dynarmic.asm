000071fad7dce69b  nop [rax+rax*1], eax
000071fad7dce6a0  mov qword ptr [r15+0x20], 0x420080
000071fad7dce6a8  mov qword ptr [r15], 0x00
000071fad7dce6af  vmovaps xmm1, [0x000071FAD79FE010]
000071fad7dce6b7  movq xmm1, xmm1
000071fad7dce6bb  vmovaps xmm15, [0x000071FAD79FE020]
000071fad7dce6c3  movq xmm15, xmm15
000071fad7dce6c8  movaps [r15+0x120], xmm15
000071fad7dce6d0  movq rax, xmm1
000071fad7dce6d5  movq r14, xmm15
000071fad7dce6da  vmovq xmm1, rax
000071fad7dce6df  vmovq xmm14, r14
000071fad7dce6e4  movaps xmm13, xmm1
000071fad7dce6e8  addsd xmm13, xmm14
000071fad7dce6ed  ucomisd xmm13, xmm13
000071fad7dce6f2  jp 0x000071FAD7DCE8CC
000071fad7dce6f8  movq xmm13, xmm13
000071fad7dce6fd  movq rax, xmm13
000071fad7dce702  movq r14, xmm15
000071fad7dce707  vmovq xmm1, rax
000071fad7dce70c  vmovq xmm14, r14
000071fad7dce711  movaps xmm13, xmm1
000071fad7dce715  addsd xmm13, xmm14
000071fad7dce71a  ucomisd xmm13, xmm13
000071fad7dce71f  jp 0x000071FAD7DCE914
000071fad7dce725  movq xmm13, xmm13
000071fad7dce72a  movq rax, xmm13
000071fad7dce72f  movq r14, xmm15
000071fad7dce734  vmovq xmm1, rax
000071fad7dce739  vmovq xmm14, r14
000071fad7dce73e  movaps xmm13, xmm1
000071fad7dce742  addsd xmm13, xmm14
000071fad7dce747  ucomisd xmm13, xmm13
000071fad7dce74c  jp 0x000071FAD7DCE95C
000071fad7dce752  movq xmm13, xmm13
000071fad7dce757  movq rax, xmm13
000071fad7dce75c  movq r14, xmm15
000071fad7dce761  vmovq xmm1, rax
000071fad7dce766  vmovq xmm14, r14
000071fad7dce76b  movaps xmm13, xmm1
000071fad7dce76f  addsd xmm13, xmm14
000071fad7dce774  ucomisd xmm13, xmm13
000071fad7dce779  jp 0x000071FAD7DCE9A4
000071fad7dce77f  movq xmm13, xmm13
000071fad7dce784  movq rax, xmm13
000071fad7dce789  movq r14, xmm15
000071fad7dce78e  vmovq xmm1, rax
000071fad7dce793  vmovq xmm14, r14
000071fad7dce798  movaps xmm13, xmm1
000071fad7dce79c  addsd xmm13, xmm14
000071fad7dce7a1  ucomisd xmm13, xmm13
000071fad7dce7a6  jp 0x000071FAD7DCE9EC
000071fad7dce7ac  movq xmm13, xmm13
000071fad7dce7b1  movq rax, xmm13
000071fad7dce7b6  movq r14, xmm15
000071fad7dce7bb  vmovq xmm1, rax
000071fad7dce7c0  vmovq xmm14, r14
000071fad7dce7c5  movaps xmm13, xmm1
000071fad7dce7c9  addsd xmm13, xmm14
000071fad7dce7ce  ucomisd xmm13, xmm13
000071fad7dce7d3  jp 0x000071FAD7DCEA34
000071fad7dce7d9  movq xmm13, xmm13
000071fad7dce7de  movq rax, xmm13
000071fad7dce7e3  movq r14, xmm15
000071fad7dce7e8  vmovq xmm1, rax
000071fad7dce7ed  vmovq xmm14, r14
000071fad7dce7f2  movaps xmm13, xmm1
000071fad7dce7f6  addsd xmm13, xmm14
000071fad7dce7fb  ucomisd xmm13, xmm13
000071fad7dce800  jp 0x000071FAD7DCEA7C
000071fad7dce806  movq xmm13, xmm13
000071fad7dce80b  movq rax, xmm13
000071fad7dce810  movq r14, xmm15
000071fad7dce815  vmovq xmm1, rax
000071fad7dce81a  vmovq xmm15, r14
000071fad7dce81f  movaps xmm14, xmm1
000071fad7dce823  addsd xmm14, xmm15
000071fad7dce828  ucomisd xmm14, xmm14
000071fad7dce82d  jp 0x000071FAD7DCEAC4
000071fad7dce833  movq xmm14, xmm14
000071fad7dce838  movaps [r15+0x110], xmm14
000071fad7dce840  xor eax, eax
000071fad7dce842  mov r14d, 0x1E848
000071fad7dce848  mov r12d, 0x01
000071fad7dce84e  sub r14, r12
000071fad7dce851  cmc
000071fad7dce852  lahf
000071fad7dce853  seto al
000071fad7dce856  mov [r15+0x108], eax
000071fad7dce85d  mov [r15+0x08], r14
000071fad7dce861  mov eax, [r15+0x108]
000071fad7dce868  sahf
000071fad7dce869  jnz 0x000071FAD7DCE89B
000071fad7dce86b  cmp dword ptr [r15+0x318], 0x00
000071fad7dce873  jz 0x000071FAD7DCEF70
000071fad7dce879  nop [rax+rax*1], ax
000071fad7dce882  nop [rax+rax*1], eax
000071fad7dce88a  mov eax, 0x41006C
000071fad7dce88f  mov [r15+0x100], rax
000071fad7dce896  jmp 0x000071FAD7BFE110
000071fad7dce89b  cmp dword ptr [r15+0x318], 0x00
000071fad7dce8a3  jz 0x000071FAD7DCEB10
000071fad7dce8a9  nop [rax+rax*1], ax
000071fad7dce8b2  nop [rax+rax*1], eax
000071fad7dce8ba  mov eax, 0x410044
000071fad7dce8bf  mov [r15+0x100], rax
000071fad7dce8c6  jmp 0x000071FAD7BFE110
000071fad7dce8cb  int3
000071fad7dce8cc  ucomisd xmm1, xmm14
000071fad7dce8d1  jp 0x000071FAD7DCE8E0
000071fad7dce8d3  movaps xmm13, [0x000071FAD79FE030]
000071fad7dce8db  jmp 0x000071FAD7DCE6F8
000071fad7dce8e0  vxorps xmm0, xmm1, xmm14
000071fad7dce8e5  pextrw eax, xmm0, 0x03
000071fad7dce8ea  and eax, 0x7FF8
000071fad7dce8ef  cmp eax, 0x08
000071fad7dce8f2  jnz 0x000071FAD7DCE6F8
000071fad7dce8f8  movq rax, xmm14
000071fad7dce8fd  shl rax, 0x0D
000071fad7dce901  jbe 0x000071FAD7DCE6F8
000071fad7dce907  vorps xmm13, xmm14, [0x000071FAD79FE040]
000071fad7dce90f  jmp 0x000071FAD7DCE6F8
000071fad7dce914  ucomisd xmm1, xmm14
000071fad7dce919  jp 0x000071FAD7DCE928
000071fad7dce91b  movaps xmm13, [0x000071FAD79FE030]
000071fad7dce923  jmp 0x000071FAD7DCE725
000071fad7dce928  vxorps xmm0, xmm1, xmm14
000071fad7dce92d  pextrw eax, xmm0, 0x03
000071fad7dce932  and eax, 0x7FF8
000071fad7dce937  cmp eax, 0x08
000071fad7dce93a  jnz 0x000071FAD7DCE725
000071fad7dce940  movq rax, xmm14
000071fad7dce945  shl rax, 0x0D
000071fad7dce949  jbe 0x000071FAD7DCE725
000071fad7dce94f  vorps xmm13, xmm14, [0x000071FAD79FE040]
000071fad7dce957  jmp 0x000071FAD7DCE725
000071fad7dce95c  ucomisd xmm1, xmm14
000071fad7dce961  jp 0x000071FAD7DCE970
000071fad7dce963  movaps xmm13, [0x000071FAD79FE030]
000071fad7dce96b  jmp 0x000071FAD7DCE752
000071fad7dce970  vxorps xmm0, xmm1, xmm14
000071fad7dce975  pextrw eax, xmm0, 0x03
000071fad7dce97a  and eax, 0x7FF8
000071fad7dce97f  cmp eax, 0x08
000071fad7dce982  jnz 0x000071FAD7DCE752
000071fad7dce988  movq rax, xmm14
000071fad7dce98d  shl rax, 0x0D
000071fad7dce991  jbe 0x000071FAD7DCE752
000071fad7dce997  vorps xmm13, xmm14, [0x000071FAD79FE040]
000071fad7dce99f  jmp 0x000071FAD7DCE752
000071fad7dce9a4  ucomisd xmm1, xmm14
000071fad7dce9a9  jp 0x000071FAD7DCE9B8
000071fad7dce9ab  movaps xmm13, [0x000071FAD79FE030]
000071fad7dce9b3  jmp 0x000071FAD7DCE77F
000071fad7dce9b8  vxorps xmm0, xmm1, xmm14
000071fad7dce9bd  pextrw eax, xmm0, 0x03
000071fad7dce9c2  and eax, 0x7FF8
000071fad7dce9c7  cmp eax, 0x08
000071fad7dce9ca  jnz 0x000071FAD7DCE77F
000071fad7dce9d0  movq rax, xmm14
000071fad7dce9d5  shl rax, 0x0D
000071fad7dce9d9  jbe 0x000071FAD7DCE77F
000071fad7dce9df  vorps xmm13, xmm14, [0x000071FAD79FE040]
000071fad7dce9e7  jmp 0x000071FAD7DCE77F
000071fad7dce9ec  ucomisd xmm1, xmm14
000071fad7dce9f1  jp 0x000071FAD7DCEA00
000071fad7dce9f3  movaps xmm13, [0x000071FAD79FE030]
000071fad7dce9fb  jmp 0x000071FAD7DCE7AC
000071fad7dcea00  vxorps xmm0, xmm1, xmm14
000071fad7dcea05  pextrw eax, xmm0, 0x03
000071fad7dcea0a  and eax, 0x7FF8
000071fad7dcea0f  cmp eax, 0x08
000071fad7dcea12  jnz 0x000071FAD7DCE7AC
000071fad7dcea18  movq rax, xmm14
000071fad7dcea1d  shl rax, 0x0D
000071fad7dcea21  jbe 0x000071FAD7DCE7AC
000071fad7dcea27  vorps xmm13, xmm14, [0x000071FAD79FE040]
000071fad7dcea2f  jmp 0x000071FAD7DCE7AC
000071fad7dcea34  ucomisd xmm1, xmm14
000071fad7dcea39  jp 0x000071FAD7DCEA48
000071fad7dcea3b  movaps xmm13, [0x000071FAD79FE030]
000071fad7dcea43  jmp 0x000071FAD7DCE7D9
000071fad7dcea48  vxorps xmm0, xmm1, xmm14
000071fad7dcea4d  pextrw eax, xmm0, 0x03
000071fad7dcea52  and eax, 0x7FF8
000071fad7dcea57  cmp eax, 0x08
000071fad7dcea5a  jnz 0x000071FAD7DCE7D9
000071fad7dcea60  movq rax, xmm14
000071fad7dcea65  shl rax, 0x0D
000071fad7dcea69  jbe 0x000071FAD7DCE7D9
000071fad7dcea6f  vorps xmm13, xmm14, [0x000071FAD79FE040]
000071fad7dcea77  jmp 0x000071FAD7DCE7D9
000071fad7dcea7c  ucomisd xmm1, xmm14
000071fad7dcea81  jp 0x000071FAD7DCEA90
000071fad7dcea83  movaps xmm13, [0x000071FAD79FE030]
000071fad7dcea8b  jmp 0x000071FAD7DCE806
000071fad7dcea90  vxorps xmm0, xmm1, xmm14
000071fad7dcea95  pextrw eax, xmm0, 0x03
000071fad7dcea9a  and eax, 0x7FF8
000071fad7dcea9f  cmp eax, 0x08
000071fad7dceaa2  jnz 0x000071FAD7DCE806
000071fad7dceaa8  movq rax, xmm14
000071fad7dceaad  shl rax, 0x0D
000071fad7dceab1  jbe 0x000071FAD7DCE806
000071fad7dceab7  vorps xmm13, xmm14, [0x000071FAD79FE040]
000071fad7dceabf  jmp 0x000071FAD7DCE806
000071fad7dceac4  ucomisd xmm1, xmm15
000071fad7dceac9  jp 0x000071FAD7DCEAD8
000071fad7dceacb  movaps xmm14, [0x000071FAD79FE030]
000071fad7dcead3  jmp 0x000071FAD7DCE833
000071fad7dcead8  vxorps xmm0, xmm1, xmm15
000071fad7dceadd  pextrw eax, xmm0, 0x03
000071fad7dceae2  and eax, 0x7FF8
000071fad7dceae7  cmp eax, 0x08
000071fad7dceaea  jnz 0x000071FAD7DCE833
000071fad7dceaf0  movq rax, xmm15
000071fad7dceaf5  shl rax, 0x0D
000071fad7dceaf9  jbe 0x000071FAD7DCE833
000071fad7dceaff  vorps xmm14, xmm15, [0x000071FAD79FE040]
000071fad7dceb07  jmp 0x000071FAD7DCE833
000071fad7dceb0c  int3
000071fad7dceb0d  nop [rax], eax
000071fad7dceb10  movaps xmm1, [r15+0x110]
000071fad7dceb18  movq rax, xmm1
000071fad7dceb1d  movaps xmm1, [r15+0x120]
000071fad7dceb25  movq r14, xmm1
000071fad7dceb2a  vmovq xmm15, rax
000071fad7dceb2f  vmovq xmm14, r14
000071fad7dceb34  movaps xmm13, xmm15
000071fad7dceb38  addsd xmm13, xmm14
000071fad7dceb3d  ucomisd xmm13, xmm13
000071fad7dceb42  jp 0x000071FAD7DCED24
000071fad7dceb48  movq xmm13, xmm13
000071fad7dceb4d  movq rax, xmm13
000071fad7dceb52  movq r14, xmm1
000071fad7dceb57  vmovq xmm15, rax
000071fad7dceb5c  vmovq xmm14, r14
000071fad7dceb61  movaps xmm13, xmm15
000071fad7dceb65  addsd xmm13, xmm14
000071fad7dceb6a  ucomisd xmm13, xmm13
000071fad7dceb6f  jp 0x000071FAD7DCED6C
000071fad7dceb75  movq xmm13, xmm13
000071fad7dceb7a  movq rax, xmm13
000071fad7dceb7f  movq r14, xmm1
000071fad7dceb84  vmovq xmm15, rax
000071fad7dceb89  vmovq xmm14, r14
000071fad7dceb8e  movaps xmm13, xmm15
000071fad7dceb92  addsd xmm13, xmm14
000071fad7dceb97  ucomisd xmm13, xmm13
000071fad7dceb9c  jp 0x000071FAD7DCEDB4
000071fad7dceba2  movq xmm13, xmm13
000071fad7dceba7  movq rax, xmm13
000071fad7dcebac  movq r14, xmm1
000071fad7dcebb1  vmovq xmm15, rax
000071fad7dcebb6  vmovq xmm14, r14
000071fad7dcebbb  movaps xmm13, xmm15
000071fad7dcebbf  addsd xmm13, xmm14
000071fad7dcebc4  ucomisd xmm13, xmm13
000071fad7dcebc9  jp 0x000071FAD7DCEDFC
000071fad7dcebcf  movq xmm13, xmm13
000071fad7dcebd4  movq rax, xmm13
000071fad7dcebd9  movq r14, xmm1
000071fad7dcebde  vmovq xmm15, rax
000071fad7dcebe3  vmovq xmm14, r14
000071fad7dcebe8  movaps xmm13, xmm15
000071fad7dcebec  addsd xmm13, xmm14
000071fad7dcebf1  ucomisd xmm13, xmm13
000071fad7dcebf6  jp 0x000071FAD7DCEE44
000071fad7dcebfc  movq xmm13, xmm13
000071fad7dcec01  movq rax, xmm13
000071fad7dcec06  movq r14, xmm1
000071fad7dcec0b  vmovq xmm15, rax
000071fad7dcec10  vmovq xmm14, r14
000071fad7dcec15  movaps xmm13, xmm15
000071fad7dcec19  addsd xmm13, xmm14
000071fad7dcec1e  ucomisd xmm13, xmm13
000071fad7dcec23  jp 0x000071FAD7DCEE8C
000071fad7dcec29  movq xmm13, xmm13
000071fad7dcec2e  movq rax, xmm13
000071fad7dcec33  movq r14, xmm1
000071fad7dcec38  vmovq xmm15, rax
000071fad7dcec3d  vmovq xmm14, r14
000071fad7dcec42  movaps xmm13, xmm15
000071fad7dcec46  addsd xmm13, xmm14
000071fad7dcec4b  ucomisd xmm13, xmm13
000071fad7dcec50  jp 0x000071FAD7DCEED4
000071fad7dcec56  movq xmm13, xmm13
000071fad7dcec5b  movq rax, xmm13
000071fad7dcec60  movq r14, xmm1
000071fad7dcec65  vmovq xmm1, rax
000071fad7dcec6a  vmovq xmm15, r14
000071fad7dcec6f  movaps xmm14, xmm1
000071fad7dcec73  addsd xmm14, xmm15
000071fad7dcec78  ucomisd xmm14, xmm14
000071fad7dcec7d  jp 0x000071FAD7DCEF1C
000071fad7dcec83  movq xmm14, xmm14
000071fad7dcec88  movaps [r15+0x110], xmm14
000071fad7dcec90  mov rax, [r15+0x08]
000071fad7dcec94  mov [rsp+0x10], rax
000071fad7dcec99  xor eax, eax
000071fad7dcec9b  mov r14, [rsp+0x10]
000071fad7dceca0  mov r12d, 0x01
000071fad7dceca6  sub r14, r12
000071fad7dceca9  cmc
000071fad7dcecaa  lahf
000071fad7dcecab  seto al
000071fad7dcecae  mov [r15+0x108], eax
000071fad7dcecb5  mov [r15+0x08], r14
000071fad7dcecb9  mov eax, [r15+0x108]
000071fad7dcecc0  sahf
000071fad7dcecc1  jnz 0x000071FAD7DCECF3
000071fad7dcecc3  cmp dword ptr [r15+0x318], 0x00
000071fad7dceccb  jz 0x000071FAD7DCEF70
000071fad7dcecd1  nop [rax+rax*1], ax
000071fad7dcecda  nop [rax+rax*1], eax
000071fad7dcece2  mov eax, 0x41006C
000071fad7dcece7  mov [r15+0x100], rax
000071fad7dcecee  jmp 0x000071FAD7BFE110
000071fad7dcecf3  cmp dword ptr [r15+0x318], 0x00
000071fad7dcecfb  jz 0x000071FAD7DCEB10
000071fad7dced01  nop [rax+rax*1], ax
000071fad7dced0a  nop [rax+rax*1], eax
000071fad7dced12  mov eax, 0x410044
000071fad7dced17  mov [r15+0x100], rax
000071fad7dced1e  jmp 0x000071FAD7BFE110
000071fad7dced23  int3
000071fad7dced24  ucomisd xmm15, xmm14
000071fad7dced29  jp 0x000071FAD7DCED38
000071fad7dced2b  movaps xmm13, [0x000071FAD79FE030]
000071fad7dced33  jmp 0x000071FAD7DCEB48
000071fad7dced38  vxorps xmm0, xmm15, xmm14
000071fad7dced3d  pextrw eax, xmm0, 0x03
000071fad7dced42  and eax, 0x7FF8
000071fad7dced47  cmp eax, 0x08
000071fad7dced4a  jnz 0x000071FAD7DCEB48
000071fad7dced50  movq rax, xmm14
000071fad7dced55  shl rax, 0x0D
000071fad7dced59  jbe 0x000071FAD7DCEB48
000071fad7dced5f  vorps xmm13, xmm14, [0x000071FAD79FE040]
000071fad7dced67  jmp 0x000071FAD7DCEB48
000071fad7dced6c  ucomisd xmm15, xmm14
000071fad7dced71  jp 0x000071FAD7DCED80
000071fad7dced73  movaps xmm13, [0x000071FAD79FE030]
000071fad7dced7b  jmp 0x000071FAD7DCEB75
000071fad7dced80  vxorps xmm0, xmm15, xmm14
000071fad7dced85  pextrw eax, xmm0, 0x03
000071fad7dced8a  and eax, 0x7FF8
000071fad7dced8f  cmp eax, 0x08
000071fad7dced92  jnz 0x000071FAD7DCEB75
000071fad7dced98  movq rax, xmm14
000071fad7dced9d  shl rax, 0x0D
000071fad7dceda1  jbe 0x000071FAD7DCEB75
000071fad7dceda7  vorps xmm13, xmm14, [0x000071FAD79FE040]
000071fad7dcedaf  jmp 0x000071FAD7DCEB75
000071fad7dcedb4  ucomisd xmm15, xmm14
000071fad7dcedb9  jp 0x000071FAD7DCEDC8
000071fad7dcedbb  movaps xmm13, [0x000071FAD79FE030]
000071fad7dcedc3  jmp 0x000071FAD7DCEBA2
000071fad7dcedc8  vxorps xmm0, xmm15, xmm14
000071fad7dcedcd  pextrw eax, xmm0, 0x03
000071fad7dcedd2  and eax, 0x7FF8
000071fad7dcedd7  cmp eax, 0x08
000071fad7dcedda  jnz 0x000071FAD7DCEBA2
000071fad7dcede0  movq rax, xmm14
000071fad7dcede5  shl rax, 0x0D
000071fad7dcede9  jbe 0x000071FAD7DCEBA2
000071fad7dcedef  vorps xmm13, xmm14, [0x000071FAD79FE040]
000071fad7dcedf7  jmp 0x000071FAD7DCEBA2
000071fad7dcedfc  ucomisd xmm15, xmm14
000071fad7dcee01  jp 0x000071FAD7DCEE10
000071fad7dcee03  movaps xmm13, [0x000071FAD79FE030]
000071fad7dcee0b  jmp 0x000071FAD7DCEBCF
000071fad7dcee10  vxorps xmm0, xmm15, xmm14
000071fad7dcee15  pextrw eax, xmm0, 0x03
000071fad7dcee1a  and eax, 0x7FF8
000071fad7dcee1f  cmp eax, 0x08
000071fad7dcee22  jnz 0x000071FAD7DCEBCF
000071fad7dcee28  movq rax, xmm14
000071fad7dcee2d  shl rax, 0x0D
000071fad7dcee31  jbe 0x000071FAD7DCEBCF
000071fad7dcee37  vorps xmm13, xmm14, [0x000071FAD79FE040]
000071fad7dcee3f  jmp 0x000071FAD7DCEBCF
000071fad7dcee44  ucomisd xmm15, xmm14
000071fad7dcee49  jp 0x000071FAD7DCEE58
000071fad7dcee4b  movaps xmm13, [0x000071FAD79FE030]
000071fad7dcee53  jmp 0x000071FAD7DCEBFC
000071fad7dcee58  vxorps xmm0, xmm15, xmm14
000071fad7dcee5d  pextrw eax, xmm0, 0x03
000071fad7dcee62  and eax, 0x7FF8
000071fad7dcee67  cmp eax, 0x08
000071fad7dcee6a  jnz 0x000071FAD7DCEBFC
000071fad7dcee70  movq rax, xmm14
000071fad7dcee75  shl rax, 0x0D
000071fad7dcee79  jbe 0x000071FAD7DCEBFC
000071fad7dcee7f  vorps xmm13, xmm14, [0x000071FAD79FE040]
000071fad7dcee87  jmp 0x000071FAD7DCEBFC
000071fad7dcee8c  ucomisd xmm15, xmm14
000071fad7dcee91  jp 0x000071FAD7DCEEA0
000071fad7dcee93  movaps xmm13, [0x000071FAD79FE030]
000071fad7dcee9b  jmp 0x000071FAD7DCEC29
000071fad7dceea0  vxorps xmm0, xmm15, xmm14
000071fad7dceea5  pextrw eax, xmm0, 0x03
000071fad7dceeaa  and eax, 0x7FF8
000071fad7dceeaf  cmp eax, 0x08
000071fad7dceeb2  jnz 0x000071FAD7DCEC29
000071fad7dceeb8  movq rax, xmm14
000071fad7dceebd  shl rax, 0x0D
000071fad7dceec1  jbe 0x000071FAD7DCEC29
000071fad7dceec7  vorps xmm13, xmm14, [0x000071FAD79FE040]
000071fad7dceecf  jmp 0x000071FAD7DCEC29
000071fad7dceed4  ucomisd xmm15, xmm14
000071fad7dceed9  jp 0x000071FAD7DCEEE8
000071fad7dceedb  movaps xmm13, [0x000071FAD79FE030]
000071fad7dceee3  jmp 0x000071FAD7DCEC56
000071fad7dceee8  vxorps xmm0, xmm15, xmm14
000071fad7dceeed  pextrw eax, xmm0, 0x03
000071fad7dceef2  and eax, 0x7FF8
000071fad7dceef7  cmp eax, 0x08
000071fad7dceefa  jnz 0x000071FAD7DCEC56
000071fad7dcef00  movq rax, xmm14
000071fad7dcef05  shl rax, 0x0D
000071fad7dcef09  jbe 0x000071FAD7DCEC56
000071fad7dcef0f  vorps xmm13, xmm14, [0x000071FAD79FE040]
000071fad7dcef17  jmp 0x000071FAD7DCEC56
000071fad7dcef1c  ucomisd xmm1, xmm15
000071fad7dcef21  jp 0x000071FAD7DCEF30
000071fad7dcef23  movaps xmm14, [0x000071FAD79FE030]
000071fad7dcef2b  jmp 0x000071FAD7DCEC83
000071fad7dcef30  vxorps xmm0, xmm1, xmm15
000071fad7dcef35  pextrw eax, xmm0, 0x03
000071fad7dcef3a  and eax, 0x7FF8
000071fad7dcef3f  cmp eax, 0x08
000071fad7dcef42  jnz 0x000071FAD7DCEC83
000071fad7dcef48  movq rax, xmm15
000071fad7dcef4d  shl rax, 0x0D
000071fad7dcef51  jbe 0x000071FAD7DCEC83
000071fad7dcef57  vorps xmm14, xmm15, [0x000071FAD79FE040]
000071fad7dcef5f  jmp 0x000071FAD7DCEC83
000071fad7dcef64  int3
000071fad7dcef65  nop [rax+rax*1], ax
000071fad7dcef6e  nop
000071fad7dcef70  mov rax, [r15+0x20]
000071fad7dcef74  movaps xmm1, [r15+0x110]
000071fad7dcef7c  movq r14, xmm1
000071fad7dcef81  mov [r13+rax*1], r14
000071fad7dcef86  mov rax, [r15+0xF0]
000071fad7dcef8d  mov [r15+0x100], rax
000071fad7dcef94  jmp 0x000071FAD7DCE5C0
000071fad7dcef99  int3
000071fad7dcef9a  call 0x000071FAD7C0E120
000071fad7dcef9f  jmp 0x000071FAD7DCEF86
000071fad7dcefa4  int3
000071fad7dcefa5  nop [rax+rax*1], ax
000071fad7dcefae  nop
000071fad7dcefb0  mov qword ptr [r15+0x100], 0x04
000071fad7dcefbb  mov esi, 0x00
000071fad7dcefc0  mov edx, 0x09
000071fad7dcefc5  mov rdi, 0x7FFEB5E43810
000071fad7dcefcf  mov rax, 0x5B817DB76970
000071fad7dcefd9  call rax
000071fad7dcefdb  cmp dword ptr [r15+0x318], 0x00
000071fad7dcefe3  jnz 0x000071FAD7BFE110
000071fad7dcefe9  jmp 0x000071FAD7BFE0A0
000071fad7dcefee  int3
000071fad7dcefef  int3
