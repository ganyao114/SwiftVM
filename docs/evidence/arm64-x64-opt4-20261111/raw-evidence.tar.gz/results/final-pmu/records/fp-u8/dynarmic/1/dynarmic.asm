00007074dd7ce69b  nop [rax+rax*1], eax
00007074dd7ce6a0  mov qword ptr [r15+0x20], 0x420080
00007074dd7ce6a8  mov qword ptr [r15], 0x00
00007074dd7ce6af  vmovaps xmm1, [0x00007074DD3FE010]
00007074dd7ce6b7  movq xmm1, xmm1
00007074dd7ce6bb  vmovaps xmm15, [0x00007074DD3FE020]
00007074dd7ce6c3  movq xmm15, xmm15
00007074dd7ce6c8  movaps [r15+0x120], xmm15
00007074dd7ce6d0  movq rax, xmm1
00007074dd7ce6d5  movq r14, xmm15
00007074dd7ce6da  vmovq xmm1, rax
00007074dd7ce6df  vmovq xmm14, r14
00007074dd7ce6e4  movaps xmm13, xmm1
00007074dd7ce6e8  addsd xmm13, xmm14
00007074dd7ce6ed  ucomisd xmm13, xmm13
00007074dd7ce6f2  jp 0x00007074DD7CE8CC
00007074dd7ce6f8  movq xmm13, xmm13
00007074dd7ce6fd  movq rax, xmm13
00007074dd7ce702  movq r14, xmm15
00007074dd7ce707  vmovq xmm1, rax
00007074dd7ce70c  vmovq xmm14, r14
00007074dd7ce711  movaps xmm13, xmm1
00007074dd7ce715  addsd xmm13, xmm14
00007074dd7ce71a  ucomisd xmm13, xmm13
00007074dd7ce71f  jp 0x00007074DD7CE914
00007074dd7ce725  movq xmm13, xmm13
00007074dd7ce72a  movq rax, xmm13
00007074dd7ce72f  movq r14, xmm15
00007074dd7ce734  vmovq xmm1, rax
00007074dd7ce739  vmovq xmm14, r14
00007074dd7ce73e  movaps xmm13, xmm1
00007074dd7ce742  addsd xmm13, xmm14
00007074dd7ce747  ucomisd xmm13, xmm13
00007074dd7ce74c  jp 0x00007074DD7CE95C
00007074dd7ce752  movq xmm13, xmm13
00007074dd7ce757  movq rax, xmm13
00007074dd7ce75c  movq r14, xmm15
00007074dd7ce761  vmovq xmm1, rax
00007074dd7ce766  vmovq xmm14, r14
00007074dd7ce76b  movaps xmm13, xmm1
00007074dd7ce76f  addsd xmm13, xmm14
00007074dd7ce774  ucomisd xmm13, xmm13
00007074dd7ce779  jp 0x00007074DD7CE9A4
00007074dd7ce77f  movq xmm13, xmm13
00007074dd7ce784  movq rax, xmm13
00007074dd7ce789  movq r14, xmm15
00007074dd7ce78e  vmovq xmm1, rax
00007074dd7ce793  vmovq xmm14, r14
00007074dd7ce798  movaps xmm13, xmm1
00007074dd7ce79c  addsd xmm13, xmm14
00007074dd7ce7a1  ucomisd xmm13, xmm13
00007074dd7ce7a6  jp 0x00007074DD7CE9EC
00007074dd7ce7ac  movq xmm13, xmm13
00007074dd7ce7b1  movq rax, xmm13
00007074dd7ce7b6  movq r14, xmm15
00007074dd7ce7bb  vmovq xmm1, rax
00007074dd7ce7c0  vmovq xmm14, r14
00007074dd7ce7c5  movaps xmm13, xmm1
00007074dd7ce7c9  addsd xmm13, xmm14
00007074dd7ce7ce  ucomisd xmm13, xmm13
00007074dd7ce7d3  jp 0x00007074DD7CEA34
00007074dd7ce7d9  movq xmm13, xmm13
00007074dd7ce7de  movq rax, xmm13
00007074dd7ce7e3  movq r14, xmm15
00007074dd7ce7e8  vmovq xmm1, rax
00007074dd7ce7ed  vmovq xmm14, r14
00007074dd7ce7f2  movaps xmm13, xmm1
00007074dd7ce7f6  addsd xmm13, xmm14
00007074dd7ce7fb  ucomisd xmm13, xmm13
00007074dd7ce800  jp 0x00007074DD7CEA7C
00007074dd7ce806  movq xmm13, xmm13
00007074dd7ce80b  movq rax, xmm13
00007074dd7ce810  movq r14, xmm15
00007074dd7ce815  vmovq xmm1, rax
00007074dd7ce81a  vmovq xmm15, r14
00007074dd7ce81f  movaps xmm14, xmm1
00007074dd7ce823  addsd xmm14, xmm15
00007074dd7ce828  ucomisd xmm14, xmm14
00007074dd7ce82d  jp 0x00007074DD7CEAC4
00007074dd7ce833  movq xmm14, xmm14
00007074dd7ce838  movaps [r15+0x110], xmm14
00007074dd7ce840  xor eax, eax
00007074dd7ce842  mov r14d, 0x1E848
00007074dd7ce848  mov r12d, 0x01
00007074dd7ce84e  sub r14, r12
00007074dd7ce851  cmc
00007074dd7ce852  lahf
00007074dd7ce853  seto al
00007074dd7ce856  mov [r15+0x108], eax
00007074dd7ce85d  mov [r15+0x08], r14
00007074dd7ce861  mov eax, [r15+0x108]
00007074dd7ce868  sahf
00007074dd7ce869  jnz 0x00007074DD7CE89B
00007074dd7ce86b  cmp dword ptr [r15+0x318], 0x00
00007074dd7ce873  jz 0x00007074DD7CEF70
00007074dd7ce879  nop [rax+rax*1], ax
00007074dd7ce882  nop [rax+rax*1], eax
00007074dd7ce88a  mov eax, 0x41006C
00007074dd7ce88f  mov [r15+0x100], rax
00007074dd7ce896  jmp 0x00007074DD5FE110
00007074dd7ce89b  cmp dword ptr [r15+0x318], 0x00
00007074dd7ce8a3  jz 0x00007074DD7CEB10
00007074dd7ce8a9  nop [rax+rax*1], ax
00007074dd7ce8b2  nop [rax+rax*1], eax
00007074dd7ce8ba  mov eax, 0x410044
00007074dd7ce8bf  mov [r15+0x100], rax
00007074dd7ce8c6  jmp 0x00007074DD5FE110
00007074dd7ce8cb  int3
00007074dd7ce8cc  ucomisd xmm1, xmm14
00007074dd7ce8d1  jp 0x00007074DD7CE8E0
00007074dd7ce8d3  movaps xmm13, [0x00007074DD3FE030]
00007074dd7ce8db  jmp 0x00007074DD7CE6F8
00007074dd7ce8e0  vxorps xmm0, xmm1, xmm14
00007074dd7ce8e5  pextrw eax, xmm0, 0x03
00007074dd7ce8ea  and eax, 0x7FF8
00007074dd7ce8ef  cmp eax, 0x08
00007074dd7ce8f2  jnz 0x00007074DD7CE6F8
00007074dd7ce8f8  movq rax, xmm14
00007074dd7ce8fd  shl rax, 0x0D
00007074dd7ce901  jbe 0x00007074DD7CE6F8
00007074dd7ce907  vorps xmm13, xmm14, [0x00007074DD3FE040]
00007074dd7ce90f  jmp 0x00007074DD7CE6F8
00007074dd7ce914  ucomisd xmm1, xmm14
00007074dd7ce919  jp 0x00007074DD7CE928
00007074dd7ce91b  movaps xmm13, [0x00007074DD3FE030]
00007074dd7ce923  jmp 0x00007074DD7CE725
00007074dd7ce928  vxorps xmm0, xmm1, xmm14
00007074dd7ce92d  pextrw eax, xmm0, 0x03
00007074dd7ce932  and eax, 0x7FF8
00007074dd7ce937  cmp eax, 0x08
00007074dd7ce93a  jnz 0x00007074DD7CE725
00007074dd7ce940  movq rax, xmm14
00007074dd7ce945  shl rax, 0x0D
00007074dd7ce949  jbe 0x00007074DD7CE725
00007074dd7ce94f  vorps xmm13, xmm14, [0x00007074DD3FE040]
00007074dd7ce957  jmp 0x00007074DD7CE725
00007074dd7ce95c  ucomisd xmm1, xmm14
00007074dd7ce961  jp 0x00007074DD7CE970
00007074dd7ce963  movaps xmm13, [0x00007074DD3FE030]
00007074dd7ce96b  jmp 0x00007074DD7CE752
00007074dd7ce970  vxorps xmm0, xmm1, xmm14
00007074dd7ce975  pextrw eax, xmm0, 0x03
00007074dd7ce97a  and eax, 0x7FF8
00007074dd7ce97f  cmp eax, 0x08
00007074dd7ce982  jnz 0x00007074DD7CE752
00007074dd7ce988  movq rax, xmm14
00007074dd7ce98d  shl rax, 0x0D
00007074dd7ce991  jbe 0x00007074DD7CE752
00007074dd7ce997  vorps xmm13, xmm14, [0x00007074DD3FE040]
00007074dd7ce99f  jmp 0x00007074DD7CE752
00007074dd7ce9a4  ucomisd xmm1, xmm14
00007074dd7ce9a9  jp 0x00007074DD7CE9B8
00007074dd7ce9ab  movaps xmm13, [0x00007074DD3FE030]
00007074dd7ce9b3  jmp 0x00007074DD7CE77F
00007074dd7ce9b8  vxorps xmm0, xmm1, xmm14
00007074dd7ce9bd  pextrw eax, xmm0, 0x03
00007074dd7ce9c2  and eax, 0x7FF8
00007074dd7ce9c7  cmp eax, 0x08
00007074dd7ce9ca  jnz 0x00007074DD7CE77F
00007074dd7ce9d0  movq rax, xmm14
00007074dd7ce9d5  shl rax, 0x0D
00007074dd7ce9d9  jbe 0x00007074DD7CE77F
00007074dd7ce9df  vorps xmm13, xmm14, [0x00007074DD3FE040]
00007074dd7ce9e7  jmp 0x00007074DD7CE77F
00007074dd7ce9ec  ucomisd xmm1, xmm14
00007074dd7ce9f1  jp 0x00007074DD7CEA00
00007074dd7ce9f3  movaps xmm13, [0x00007074DD3FE030]
00007074dd7ce9fb  jmp 0x00007074DD7CE7AC
00007074dd7cea00  vxorps xmm0, xmm1, xmm14
00007074dd7cea05  pextrw eax, xmm0, 0x03
00007074dd7cea0a  and eax, 0x7FF8
00007074dd7cea0f  cmp eax, 0x08
00007074dd7cea12  jnz 0x00007074DD7CE7AC
00007074dd7cea18  movq rax, xmm14
00007074dd7cea1d  shl rax, 0x0D
00007074dd7cea21  jbe 0x00007074DD7CE7AC
00007074dd7cea27  vorps xmm13, xmm14, [0x00007074DD3FE040]
00007074dd7cea2f  jmp 0x00007074DD7CE7AC
00007074dd7cea34  ucomisd xmm1, xmm14
00007074dd7cea39  jp 0x00007074DD7CEA48
00007074dd7cea3b  movaps xmm13, [0x00007074DD3FE030]
00007074dd7cea43  jmp 0x00007074DD7CE7D9
00007074dd7cea48  vxorps xmm0, xmm1, xmm14
00007074dd7cea4d  pextrw eax, xmm0, 0x03
00007074dd7cea52  and eax, 0x7FF8
00007074dd7cea57  cmp eax, 0x08
00007074dd7cea5a  jnz 0x00007074DD7CE7D9
00007074dd7cea60  movq rax, xmm14
00007074dd7cea65  shl rax, 0x0D
00007074dd7cea69  jbe 0x00007074DD7CE7D9
00007074dd7cea6f  vorps xmm13, xmm14, [0x00007074DD3FE040]
00007074dd7cea77  jmp 0x00007074DD7CE7D9
00007074dd7cea7c  ucomisd xmm1, xmm14
00007074dd7cea81  jp 0x00007074DD7CEA90
00007074dd7cea83  movaps xmm13, [0x00007074DD3FE030]
00007074dd7cea8b  jmp 0x00007074DD7CE806
00007074dd7cea90  vxorps xmm0, xmm1, xmm14
00007074dd7cea95  pextrw eax, xmm0, 0x03
00007074dd7cea9a  and eax, 0x7FF8
00007074dd7cea9f  cmp eax, 0x08
00007074dd7ceaa2  jnz 0x00007074DD7CE806
00007074dd7ceaa8  movq rax, xmm14
00007074dd7ceaad  shl rax, 0x0D
00007074dd7ceab1  jbe 0x00007074DD7CE806
00007074dd7ceab7  vorps xmm13, xmm14, [0x00007074DD3FE040]
00007074dd7ceabf  jmp 0x00007074DD7CE806
00007074dd7ceac4  ucomisd xmm1, xmm15
00007074dd7ceac9  jp 0x00007074DD7CEAD8
00007074dd7ceacb  movaps xmm14, [0x00007074DD3FE030]
00007074dd7cead3  jmp 0x00007074DD7CE833
00007074dd7cead8  vxorps xmm0, xmm1, xmm15
00007074dd7ceadd  pextrw eax, xmm0, 0x03
00007074dd7ceae2  and eax, 0x7FF8
00007074dd7ceae7  cmp eax, 0x08
00007074dd7ceaea  jnz 0x00007074DD7CE833
00007074dd7ceaf0  movq rax, xmm15
00007074dd7ceaf5  shl rax, 0x0D
00007074dd7ceaf9  jbe 0x00007074DD7CE833
00007074dd7ceaff  vorps xmm14, xmm15, [0x00007074DD3FE040]
00007074dd7ceb07  jmp 0x00007074DD7CE833
00007074dd7ceb0c  int3
00007074dd7ceb0d  nop [rax], eax
00007074dd7ceb10  movaps xmm1, [r15+0x110]
00007074dd7ceb18  movq rax, xmm1
00007074dd7ceb1d  movaps xmm1, [r15+0x120]
00007074dd7ceb25  movq r14, xmm1
00007074dd7ceb2a  vmovq xmm15, rax
00007074dd7ceb2f  vmovq xmm14, r14
00007074dd7ceb34  movaps xmm13, xmm15
00007074dd7ceb38  addsd xmm13, xmm14
00007074dd7ceb3d  ucomisd xmm13, xmm13
00007074dd7ceb42  jp 0x00007074DD7CED24
00007074dd7ceb48  movq xmm13, xmm13
00007074dd7ceb4d  movq rax, xmm13
00007074dd7ceb52  movq r14, xmm1
00007074dd7ceb57  vmovq xmm15, rax
00007074dd7ceb5c  vmovq xmm14, r14
00007074dd7ceb61  movaps xmm13, xmm15
00007074dd7ceb65  addsd xmm13, xmm14
00007074dd7ceb6a  ucomisd xmm13, xmm13
00007074dd7ceb6f  jp 0x00007074DD7CED6C
00007074dd7ceb75  movq xmm13, xmm13
00007074dd7ceb7a  movq rax, xmm13
00007074dd7ceb7f  movq r14, xmm1
00007074dd7ceb84  vmovq xmm15, rax
00007074dd7ceb89  vmovq xmm14, r14
00007074dd7ceb8e  movaps xmm13, xmm15
00007074dd7ceb92  addsd xmm13, xmm14
00007074dd7ceb97  ucomisd xmm13, xmm13
00007074dd7ceb9c  jp 0x00007074DD7CEDB4
00007074dd7ceba2  movq xmm13, xmm13
00007074dd7ceba7  movq rax, xmm13
00007074dd7cebac  movq r14, xmm1
00007074dd7cebb1  vmovq xmm15, rax
00007074dd7cebb6  vmovq xmm14, r14
00007074dd7cebbb  movaps xmm13, xmm15
00007074dd7cebbf  addsd xmm13, xmm14
00007074dd7cebc4  ucomisd xmm13, xmm13
00007074dd7cebc9  jp 0x00007074DD7CEDFC
00007074dd7cebcf  movq xmm13, xmm13
00007074dd7cebd4  movq rax, xmm13
00007074dd7cebd9  movq r14, xmm1
00007074dd7cebde  vmovq xmm15, rax
00007074dd7cebe3  vmovq xmm14, r14
00007074dd7cebe8  movaps xmm13, xmm15
00007074dd7cebec  addsd xmm13, xmm14
00007074dd7cebf1  ucomisd xmm13, xmm13
00007074dd7cebf6  jp 0x00007074DD7CEE44
00007074dd7cebfc  movq xmm13, xmm13
00007074dd7cec01  movq rax, xmm13
00007074dd7cec06  movq r14, xmm1
00007074dd7cec0b  vmovq xmm15, rax
00007074dd7cec10  vmovq xmm14, r14
00007074dd7cec15  movaps xmm13, xmm15
00007074dd7cec19  addsd xmm13, xmm14
00007074dd7cec1e  ucomisd xmm13, xmm13
00007074dd7cec23  jp 0x00007074DD7CEE8C
00007074dd7cec29  movq xmm13, xmm13
00007074dd7cec2e  movq rax, xmm13
00007074dd7cec33  movq r14, xmm1
00007074dd7cec38  vmovq xmm15, rax
00007074dd7cec3d  vmovq xmm14, r14
00007074dd7cec42  movaps xmm13, xmm15
00007074dd7cec46  addsd xmm13, xmm14
00007074dd7cec4b  ucomisd xmm13, xmm13
00007074dd7cec50  jp 0x00007074DD7CEED4
00007074dd7cec56  movq xmm13, xmm13
00007074dd7cec5b  movq rax, xmm13
00007074dd7cec60  movq r14, xmm1
00007074dd7cec65  vmovq xmm1, rax
00007074dd7cec6a  vmovq xmm15, r14
00007074dd7cec6f  movaps xmm14, xmm1
00007074dd7cec73  addsd xmm14, xmm15
00007074dd7cec78  ucomisd xmm14, xmm14
00007074dd7cec7d  jp 0x00007074DD7CEF1C
00007074dd7cec83  movq xmm14, xmm14
00007074dd7cec88  movaps [r15+0x110], xmm14
00007074dd7cec90  mov rax, [r15+0x08]
00007074dd7cec94  mov [rsp+0x10], rax
00007074dd7cec99  xor eax, eax
00007074dd7cec9b  mov r14, [rsp+0x10]
00007074dd7ceca0  mov r12d, 0x01
00007074dd7ceca6  sub r14, r12
00007074dd7ceca9  cmc
00007074dd7cecaa  lahf
00007074dd7cecab  seto al
00007074dd7cecae  mov [r15+0x108], eax
00007074dd7cecb5  mov [r15+0x08], r14
00007074dd7cecb9  mov eax, [r15+0x108]
00007074dd7cecc0  sahf
00007074dd7cecc1  jnz 0x00007074DD7CECF3
00007074dd7cecc3  cmp dword ptr [r15+0x318], 0x00
00007074dd7ceccb  jz 0x00007074DD7CEF70
00007074dd7cecd1  nop [rax+rax*1], ax
00007074dd7cecda  nop [rax+rax*1], eax
00007074dd7cece2  mov eax, 0x41006C
00007074dd7cece7  mov [r15+0x100], rax
00007074dd7cecee  jmp 0x00007074DD5FE110
00007074dd7cecf3  cmp dword ptr [r15+0x318], 0x00
00007074dd7cecfb  jz 0x00007074DD7CEB10
00007074dd7ced01  nop [rax+rax*1], ax
00007074dd7ced0a  nop [rax+rax*1], eax
00007074dd7ced12  mov eax, 0x410044
00007074dd7ced17  mov [r15+0x100], rax
00007074dd7ced1e  jmp 0x00007074DD5FE110
00007074dd7ced23  int3
00007074dd7ced24  ucomisd xmm15, xmm14
00007074dd7ced29  jp 0x00007074DD7CED38
00007074dd7ced2b  movaps xmm13, [0x00007074DD3FE030]
00007074dd7ced33  jmp 0x00007074DD7CEB48
00007074dd7ced38  vxorps xmm0, xmm15, xmm14
00007074dd7ced3d  pextrw eax, xmm0, 0x03
00007074dd7ced42  and eax, 0x7FF8
00007074dd7ced47  cmp eax, 0x08
00007074dd7ced4a  jnz 0x00007074DD7CEB48
00007074dd7ced50  movq rax, xmm14
00007074dd7ced55  shl rax, 0x0D
00007074dd7ced59  jbe 0x00007074DD7CEB48
00007074dd7ced5f  vorps xmm13, xmm14, [0x00007074DD3FE040]
00007074dd7ced67  jmp 0x00007074DD7CEB48
00007074dd7ced6c  ucomisd xmm15, xmm14
00007074dd7ced71  jp 0x00007074DD7CED80
00007074dd7ced73  movaps xmm13, [0x00007074DD3FE030]
00007074dd7ced7b  jmp 0x00007074DD7CEB75
00007074dd7ced80  vxorps xmm0, xmm15, xmm14
00007074dd7ced85  pextrw eax, xmm0, 0x03
00007074dd7ced8a  and eax, 0x7FF8
00007074dd7ced8f  cmp eax, 0x08
00007074dd7ced92  jnz 0x00007074DD7CEB75
00007074dd7ced98  movq rax, xmm14
00007074dd7ced9d  shl rax, 0x0D
00007074dd7ceda1  jbe 0x00007074DD7CEB75
00007074dd7ceda7  vorps xmm13, xmm14, [0x00007074DD3FE040]
00007074dd7cedaf  jmp 0x00007074DD7CEB75
00007074dd7cedb4  ucomisd xmm15, xmm14
00007074dd7cedb9  jp 0x00007074DD7CEDC8
00007074dd7cedbb  movaps xmm13, [0x00007074DD3FE030]
00007074dd7cedc3  jmp 0x00007074DD7CEBA2
00007074dd7cedc8  vxorps xmm0, xmm15, xmm14
00007074dd7cedcd  pextrw eax, xmm0, 0x03
00007074dd7cedd2  and eax, 0x7FF8
00007074dd7cedd7  cmp eax, 0x08
00007074dd7cedda  jnz 0x00007074DD7CEBA2
00007074dd7cede0  movq rax, xmm14
00007074dd7cede5  shl rax, 0x0D
00007074dd7cede9  jbe 0x00007074DD7CEBA2
00007074dd7cedef  vorps xmm13, xmm14, [0x00007074DD3FE040]
00007074dd7cedf7  jmp 0x00007074DD7CEBA2
00007074dd7cedfc  ucomisd xmm15, xmm14
00007074dd7cee01  jp 0x00007074DD7CEE10
00007074dd7cee03  movaps xmm13, [0x00007074DD3FE030]
00007074dd7cee0b  jmp 0x00007074DD7CEBCF
00007074dd7cee10  vxorps xmm0, xmm15, xmm14
00007074dd7cee15  pextrw eax, xmm0, 0x03
00007074dd7cee1a  and eax, 0x7FF8
00007074dd7cee1f  cmp eax, 0x08
00007074dd7cee22  jnz 0x00007074DD7CEBCF
00007074dd7cee28  movq rax, xmm14
00007074dd7cee2d  shl rax, 0x0D
00007074dd7cee31  jbe 0x00007074DD7CEBCF
00007074dd7cee37  vorps xmm13, xmm14, [0x00007074DD3FE040]
00007074dd7cee3f  jmp 0x00007074DD7CEBCF
00007074dd7cee44  ucomisd xmm15, xmm14
00007074dd7cee49  jp 0x00007074DD7CEE58
00007074dd7cee4b  movaps xmm13, [0x00007074DD3FE030]
00007074dd7cee53  jmp 0x00007074DD7CEBFC
00007074dd7cee58  vxorps xmm0, xmm15, xmm14
00007074dd7cee5d  pextrw eax, xmm0, 0x03
00007074dd7cee62  and eax, 0x7FF8
00007074dd7cee67  cmp eax, 0x08
00007074dd7cee6a  jnz 0x00007074DD7CEBFC
00007074dd7cee70  movq rax, xmm14
00007074dd7cee75  shl rax, 0x0D
00007074dd7cee79  jbe 0x00007074DD7CEBFC
00007074dd7cee7f  vorps xmm13, xmm14, [0x00007074DD3FE040]
00007074dd7cee87  jmp 0x00007074DD7CEBFC
00007074dd7cee8c  ucomisd xmm15, xmm14
00007074dd7cee91  jp 0x00007074DD7CEEA0
00007074dd7cee93  movaps xmm13, [0x00007074DD3FE030]
00007074dd7cee9b  jmp 0x00007074DD7CEC29
00007074dd7ceea0  vxorps xmm0, xmm15, xmm14
00007074dd7ceea5  pextrw eax, xmm0, 0x03
00007074dd7ceeaa  and eax, 0x7FF8
00007074dd7ceeaf  cmp eax, 0x08
00007074dd7ceeb2  jnz 0x00007074DD7CEC29
00007074dd7ceeb8  movq rax, xmm14
00007074dd7ceebd  shl rax, 0x0D
00007074dd7ceec1  jbe 0x00007074DD7CEC29
00007074dd7ceec7  vorps xmm13, xmm14, [0x00007074DD3FE040]
00007074dd7ceecf  jmp 0x00007074DD7CEC29
00007074dd7ceed4  ucomisd xmm15, xmm14
00007074dd7ceed9  jp 0x00007074DD7CEEE8
00007074dd7ceedb  movaps xmm13, [0x00007074DD3FE030]
00007074dd7ceee3  jmp 0x00007074DD7CEC56
00007074dd7ceee8  vxorps xmm0, xmm15, xmm14
00007074dd7ceeed  pextrw eax, xmm0, 0x03
00007074dd7ceef2  and eax, 0x7FF8
00007074dd7ceef7  cmp eax, 0x08
00007074dd7ceefa  jnz 0x00007074DD7CEC56
00007074dd7cef00  movq rax, xmm14
00007074dd7cef05  shl rax, 0x0D
00007074dd7cef09  jbe 0x00007074DD7CEC56
00007074dd7cef0f  vorps xmm13, xmm14, [0x00007074DD3FE040]
00007074dd7cef17  jmp 0x00007074DD7CEC56
00007074dd7cef1c  ucomisd xmm1, xmm15
00007074dd7cef21  jp 0x00007074DD7CEF30
00007074dd7cef23  movaps xmm14, [0x00007074DD3FE030]
00007074dd7cef2b  jmp 0x00007074DD7CEC83
00007074dd7cef30  vxorps xmm0, xmm1, xmm15
00007074dd7cef35  pextrw eax, xmm0, 0x03
00007074dd7cef3a  and eax, 0x7FF8
00007074dd7cef3f  cmp eax, 0x08
00007074dd7cef42  jnz 0x00007074DD7CEC83
00007074dd7cef48  movq rax, xmm15
00007074dd7cef4d  shl rax, 0x0D
00007074dd7cef51  jbe 0x00007074DD7CEC83
00007074dd7cef57  vorps xmm14, xmm15, [0x00007074DD3FE040]
00007074dd7cef5f  jmp 0x00007074DD7CEC83
00007074dd7cef64  int3
00007074dd7cef65  nop [rax+rax*1], ax
00007074dd7cef6e  nop
00007074dd7cef70  mov rax, [r15+0x20]
00007074dd7cef74  movaps xmm1, [r15+0x110]
00007074dd7cef7c  movq r14, xmm1
00007074dd7cef81  mov [r13+rax*1], r14
00007074dd7cef86  mov rax, [r15+0xF0]
00007074dd7cef8d  mov [r15+0x100], rax
00007074dd7cef94  jmp 0x00007074DD7CE5C0
00007074dd7cef99  int3
00007074dd7cef9a  call 0x00007074DD60E120
00007074dd7cef9f  jmp 0x00007074DD7CEF86
00007074dd7cefa4  int3
00007074dd7cefa5  nop [rax+rax*1], ax
00007074dd7cefae  nop
00007074dd7cefb0  mov qword ptr [r15+0x100], 0x04
00007074dd7cefbb  mov esi, 0x00
00007074dd7cefc0  mov edx, 0x09
00007074dd7cefc5  mov rdi, 0x7FFCFD5D58C0
00007074dd7cefcf  mov rax, 0x610C1BA9B970
00007074dd7cefd9  call rax
00007074dd7cefdb  cmp dword ptr [r15+0x318], 0x00
00007074dd7cefe3  jnz 0x00007074DD5FE110
00007074dd7cefe9  jmp 0x00007074DD5FE0A0
00007074dd7cefee  int3
00007074dd7cefef  int3
