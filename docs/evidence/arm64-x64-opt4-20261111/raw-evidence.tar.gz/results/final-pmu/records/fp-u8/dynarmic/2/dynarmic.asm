0000745cb6bce69b  nop [rax+rax*1], eax
0000745cb6bce6a0  mov qword ptr [r15+0x20], 0x420080
0000745cb6bce6a8  mov qword ptr [r15], 0x00
0000745cb6bce6af  vmovaps xmm1, [0x0000745CB67FE010]
0000745cb6bce6b7  movq xmm1, xmm1
0000745cb6bce6bb  vmovaps xmm15, [0x0000745CB67FE020]
0000745cb6bce6c3  movq xmm15, xmm15
0000745cb6bce6c8  movaps [r15+0x120], xmm15
0000745cb6bce6d0  movq rax, xmm1
0000745cb6bce6d5  movq r14, xmm15
0000745cb6bce6da  vmovq xmm1, rax
0000745cb6bce6df  vmovq xmm14, r14
0000745cb6bce6e4  movaps xmm13, xmm1
0000745cb6bce6e8  addsd xmm13, xmm14
0000745cb6bce6ed  ucomisd xmm13, xmm13
0000745cb6bce6f2  jp 0x0000745CB6BCE8CC
0000745cb6bce6f8  movq xmm13, xmm13
0000745cb6bce6fd  movq rax, xmm13
0000745cb6bce702  movq r14, xmm15
0000745cb6bce707  vmovq xmm1, rax
0000745cb6bce70c  vmovq xmm14, r14
0000745cb6bce711  movaps xmm13, xmm1
0000745cb6bce715  addsd xmm13, xmm14
0000745cb6bce71a  ucomisd xmm13, xmm13
0000745cb6bce71f  jp 0x0000745CB6BCE914
0000745cb6bce725  movq xmm13, xmm13
0000745cb6bce72a  movq rax, xmm13
0000745cb6bce72f  movq r14, xmm15
0000745cb6bce734  vmovq xmm1, rax
0000745cb6bce739  vmovq xmm14, r14
0000745cb6bce73e  movaps xmm13, xmm1
0000745cb6bce742  addsd xmm13, xmm14
0000745cb6bce747  ucomisd xmm13, xmm13
0000745cb6bce74c  jp 0x0000745CB6BCE95C
0000745cb6bce752  movq xmm13, xmm13
0000745cb6bce757  movq rax, xmm13
0000745cb6bce75c  movq r14, xmm15
0000745cb6bce761  vmovq xmm1, rax
0000745cb6bce766  vmovq xmm14, r14
0000745cb6bce76b  movaps xmm13, xmm1
0000745cb6bce76f  addsd xmm13, xmm14
0000745cb6bce774  ucomisd xmm13, xmm13
0000745cb6bce779  jp 0x0000745CB6BCE9A4
0000745cb6bce77f  movq xmm13, xmm13
0000745cb6bce784  movq rax, xmm13
0000745cb6bce789  movq r14, xmm15
0000745cb6bce78e  vmovq xmm1, rax
0000745cb6bce793  vmovq xmm14, r14
0000745cb6bce798  movaps xmm13, xmm1
0000745cb6bce79c  addsd xmm13, xmm14
0000745cb6bce7a1  ucomisd xmm13, xmm13
0000745cb6bce7a6  jp 0x0000745CB6BCE9EC
0000745cb6bce7ac  movq xmm13, xmm13
0000745cb6bce7b1  movq rax, xmm13
0000745cb6bce7b6  movq r14, xmm15
0000745cb6bce7bb  vmovq xmm1, rax
0000745cb6bce7c0  vmovq xmm14, r14
0000745cb6bce7c5  movaps xmm13, xmm1
0000745cb6bce7c9  addsd xmm13, xmm14
0000745cb6bce7ce  ucomisd xmm13, xmm13
0000745cb6bce7d3  jp 0x0000745CB6BCEA34
0000745cb6bce7d9  movq xmm13, xmm13
0000745cb6bce7de  movq rax, xmm13
0000745cb6bce7e3  movq r14, xmm15
0000745cb6bce7e8  vmovq xmm1, rax
0000745cb6bce7ed  vmovq xmm14, r14
0000745cb6bce7f2  movaps xmm13, xmm1
0000745cb6bce7f6  addsd xmm13, xmm14
0000745cb6bce7fb  ucomisd xmm13, xmm13
0000745cb6bce800  jp 0x0000745CB6BCEA7C
0000745cb6bce806  movq xmm13, xmm13
0000745cb6bce80b  movq rax, xmm13
0000745cb6bce810  movq r14, xmm15
0000745cb6bce815  vmovq xmm1, rax
0000745cb6bce81a  vmovq xmm15, r14
0000745cb6bce81f  movaps xmm14, xmm1
0000745cb6bce823  addsd xmm14, xmm15
0000745cb6bce828  ucomisd xmm14, xmm14
0000745cb6bce82d  jp 0x0000745CB6BCEAC4
0000745cb6bce833  movq xmm14, xmm14
0000745cb6bce838  movaps [r15+0x110], xmm14
0000745cb6bce840  xor eax, eax
0000745cb6bce842  mov r14d, 0x1E848
0000745cb6bce848  mov r12d, 0x01
0000745cb6bce84e  sub r14, r12
0000745cb6bce851  cmc
0000745cb6bce852  lahf
0000745cb6bce853  seto al
0000745cb6bce856  mov [r15+0x108], eax
0000745cb6bce85d  mov [r15+0x08], r14
0000745cb6bce861  mov eax, [r15+0x108]
0000745cb6bce868  sahf
0000745cb6bce869  jnz 0x0000745CB6BCE89B
0000745cb6bce86b  cmp dword ptr [r15+0x318], 0x00
0000745cb6bce873  jz 0x0000745CB6BCEF70
0000745cb6bce879  nop [rax+rax*1], ax
0000745cb6bce882  nop [rax+rax*1], eax
0000745cb6bce88a  mov eax, 0x41006C
0000745cb6bce88f  mov [r15+0x100], rax
0000745cb6bce896  jmp 0x0000745CB69FE110
0000745cb6bce89b  cmp dword ptr [r15+0x318], 0x00
0000745cb6bce8a3  jz 0x0000745CB6BCEB10
0000745cb6bce8a9  nop [rax+rax*1], ax
0000745cb6bce8b2  nop [rax+rax*1], eax
0000745cb6bce8ba  mov eax, 0x410044
0000745cb6bce8bf  mov [r15+0x100], rax
0000745cb6bce8c6  jmp 0x0000745CB69FE110
0000745cb6bce8cb  int3
0000745cb6bce8cc  ucomisd xmm1, xmm14
0000745cb6bce8d1  jp 0x0000745CB6BCE8E0
0000745cb6bce8d3  movaps xmm13, [0x0000745CB67FE030]
0000745cb6bce8db  jmp 0x0000745CB6BCE6F8
0000745cb6bce8e0  vxorps xmm0, xmm1, xmm14
0000745cb6bce8e5  pextrw eax, xmm0, 0x03
0000745cb6bce8ea  and eax, 0x7FF8
0000745cb6bce8ef  cmp eax, 0x08
0000745cb6bce8f2  jnz 0x0000745CB6BCE6F8
0000745cb6bce8f8  movq rax, xmm14
0000745cb6bce8fd  shl rax, 0x0D
0000745cb6bce901  jbe 0x0000745CB6BCE6F8
0000745cb6bce907  vorps xmm13, xmm14, [0x0000745CB67FE040]
0000745cb6bce90f  jmp 0x0000745CB6BCE6F8
0000745cb6bce914  ucomisd xmm1, xmm14
0000745cb6bce919  jp 0x0000745CB6BCE928
0000745cb6bce91b  movaps xmm13, [0x0000745CB67FE030]
0000745cb6bce923  jmp 0x0000745CB6BCE725
0000745cb6bce928  vxorps xmm0, xmm1, xmm14
0000745cb6bce92d  pextrw eax, xmm0, 0x03
0000745cb6bce932  and eax, 0x7FF8
0000745cb6bce937  cmp eax, 0x08
0000745cb6bce93a  jnz 0x0000745CB6BCE725
0000745cb6bce940  movq rax, xmm14
0000745cb6bce945  shl rax, 0x0D
0000745cb6bce949  jbe 0x0000745CB6BCE725
0000745cb6bce94f  vorps xmm13, xmm14, [0x0000745CB67FE040]
0000745cb6bce957  jmp 0x0000745CB6BCE725
0000745cb6bce95c  ucomisd xmm1, xmm14
0000745cb6bce961  jp 0x0000745CB6BCE970
0000745cb6bce963  movaps xmm13, [0x0000745CB67FE030]
0000745cb6bce96b  jmp 0x0000745CB6BCE752
0000745cb6bce970  vxorps xmm0, xmm1, xmm14
0000745cb6bce975  pextrw eax, xmm0, 0x03
0000745cb6bce97a  and eax, 0x7FF8
0000745cb6bce97f  cmp eax, 0x08
0000745cb6bce982  jnz 0x0000745CB6BCE752
0000745cb6bce988  movq rax, xmm14
0000745cb6bce98d  shl rax, 0x0D
0000745cb6bce991  jbe 0x0000745CB6BCE752
0000745cb6bce997  vorps xmm13, xmm14, [0x0000745CB67FE040]
0000745cb6bce99f  jmp 0x0000745CB6BCE752
0000745cb6bce9a4  ucomisd xmm1, xmm14
0000745cb6bce9a9  jp 0x0000745CB6BCE9B8
0000745cb6bce9ab  movaps xmm13, [0x0000745CB67FE030]
0000745cb6bce9b3  jmp 0x0000745CB6BCE77F
0000745cb6bce9b8  vxorps xmm0, xmm1, xmm14
0000745cb6bce9bd  pextrw eax, xmm0, 0x03
0000745cb6bce9c2  and eax, 0x7FF8
0000745cb6bce9c7  cmp eax, 0x08
0000745cb6bce9ca  jnz 0x0000745CB6BCE77F
0000745cb6bce9d0  movq rax, xmm14
0000745cb6bce9d5  shl rax, 0x0D
0000745cb6bce9d9  jbe 0x0000745CB6BCE77F
0000745cb6bce9df  vorps xmm13, xmm14, [0x0000745CB67FE040]
0000745cb6bce9e7  jmp 0x0000745CB6BCE77F
0000745cb6bce9ec  ucomisd xmm1, xmm14
0000745cb6bce9f1  jp 0x0000745CB6BCEA00
0000745cb6bce9f3  movaps xmm13, [0x0000745CB67FE030]
0000745cb6bce9fb  jmp 0x0000745CB6BCE7AC
0000745cb6bcea00  vxorps xmm0, xmm1, xmm14
0000745cb6bcea05  pextrw eax, xmm0, 0x03
0000745cb6bcea0a  and eax, 0x7FF8
0000745cb6bcea0f  cmp eax, 0x08
0000745cb6bcea12  jnz 0x0000745CB6BCE7AC
0000745cb6bcea18  movq rax, xmm14
0000745cb6bcea1d  shl rax, 0x0D
0000745cb6bcea21  jbe 0x0000745CB6BCE7AC
0000745cb6bcea27  vorps xmm13, xmm14, [0x0000745CB67FE040]
0000745cb6bcea2f  jmp 0x0000745CB6BCE7AC
0000745cb6bcea34  ucomisd xmm1, xmm14
0000745cb6bcea39  jp 0x0000745CB6BCEA48
0000745cb6bcea3b  movaps xmm13, [0x0000745CB67FE030]
0000745cb6bcea43  jmp 0x0000745CB6BCE7D9
0000745cb6bcea48  vxorps xmm0, xmm1, xmm14
0000745cb6bcea4d  pextrw eax, xmm0, 0x03
0000745cb6bcea52  and eax, 0x7FF8
0000745cb6bcea57  cmp eax, 0x08
0000745cb6bcea5a  jnz 0x0000745CB6BCE7D9
0000745cb6bcea60  movq rax, xmm14
0000745cb6bcea65  shl rax, 0x0D
0000745cb6bcea69  jbe 0x0000745CB6BCE7D9
0000745cb6bcea6f  vorps xmm13, xmm14, [0x0000745CB67FE040]
0000745cb6bcea77  jmp 0x0000745CB6BCE7D9
0000745cb6bcea7c  ucomisd xmm1, xmm14
0000745cb6bcea81  jp 0x0000745CB6BCEA90
0000745cb6bcea83  movaps xmm13, [0x0000745CB67FE030]
0000745cb6bcea8b  jmp 0x0000745CB6BCE806
0000745cb6bcea90  vxorps xmm0, xmm1, xmm14
0000745cb6bcea95  pextrw eax, xmm0, 0x03
0000745cb6bcea9a  and eax, 0x7FF8
0000745cb6bcea9f  cmp eax, 0x08
0000745cb6bceaa2  jnz 0x0000745CB6BCE806
0000745cb6bceaa8  movq rax, xmm14
0000745cb6bceaad  shl rax, 0x0D
0000745cb6bceab1  jbe 0x0000745CB6BCE806
0000745cb6bceab7  vorps xmm13, xmm14, [0x0000745CB67FE040]
0000745cb6bceabf  jmp 0x0000745CB6BCE806
0000745cb6bceac4  ucomisd xmm1, xmm15
0000745cb6bceac9  jp 0x0000745CB6BCEAD8
0000745cb6bceacb  movaps xmm14, [0x0000745CB67FE030]
0000745cb6bcead3  jmp 0x0000745CB6BCE833
0000745cb6bcead8  vxorps xmm0, xmm1, xmm15
0000745cb6bceadd  pextrw eax, xmm0, 0x03
0000745cb6bceae2  and eax, 0x7FF8
0000745cb6bceae7  cmp eax, 0x08
0000745cb6bceaea  jnz 0x0000745CB6BCE833
0000745cb6bceaf0  movq rax, xmm15
0000745cb6bceaf5  shl rax, 0x0D
0000745cb6bceaf9  jbe 0x0000745CB6BCE833
0000745cb6bceaff  vorps xmm14, xmm15, [0x0000745CB67FE040]
0000745cb6bceb07  jmp 0x0000745CB6BCE833
0000745cb6bceb0c  int3
0000745cb6bceb0d  nop [rax], eax
0000745cb6bceb10  movaps xmm1, [r15+0x110]
0000745cb6bceb18  movq rax, xmm1
0000745cb6bceb1d  movaps xmm1, [r15+0x120]
0000745cb6bceb25  movq r14, xmm1
0000745cb6bceb2a  vmovq xmm15, rax
0000745cb6bceb2f  vmovq xmm14, r14
0000745cb6bceb34  movaps xmm13, xmm15
0000745cb6bceb38  addsd xmm13, xmm14
0000745cb6bceb3d  ucomisd xmm13, xmm13
0000745cb6bceb42  jp 0x0000745CB6BCED24
0000745cb6bceb48  movq xmm13, xmm13
0000745cb6bceb4d  movq rax, xmm13
0000745cb6bceb52  movq r14, xmm1
0000745cb6bceb57  vmovq xmm15, rax
0000745cb6bceb5c  vmovq xmm14, r14
0000745cb6bceb61  movaps xmm13, xmm15
0000745cb6bceb65  addsd xmm13, xmm14
0000745cb6bceb6a  ucomisd xmm13, xmm13
0000745cb6bceb6f  jp 0x0000745CB6BCED6C
0000745cb6bceb75  movq xmm13, xmm13
0000745cb6bceb7a  movq rax, xmm13
0000745cb6bceb7f  movq r14, xmm1
0000745cb6bceb84  vmovq xmm15, rax
0000745cb6bceb89  vmovq xmm14, r14
0000745cb6bceb8e  movaps xmm13, xmm15
0000745cb6bceb92  addsd xmm13, xmm14
0000745cb6bceb97  ucomisd xmm13, xmm13
0000745cb6bceb9c  jp 0x0000745CB6BCEDB4
0000745cb6bceba2  movq xmm13, xmm13
0000745cb6bceba7  movq rax, xmm13
0000745cb6bcebac  movq r14, xmm1
0000745cb6bcebb1  vmovq xmm15, rax
0000745cb6bcebb6  vmovq xmm14, r14
0000745cb6bcebbb  movaps xmm13, xmm15
0000745cb6bcebbf  addsd xmm13, xmm14
0000745cb6bcebc4  ucomisd xmm13, xmm13
0000745cb6bcebc9  jp 0x0000745CB6BCEDFC
0000745cb6bcebcf  movq xmm13, xmm13
0000745cb6bcebd4  movq rax, xmm13
0000745cb6bcebd9  movq r14, xmm1
0000745cb6bcebde  vmovq xmm15, rax
0000745cb6bcebe3  vmovq xmm14, r14
0000745cb6bcebe8  movaps xmm13, xmm15
0000745cb6bcebec  addsd xmm13, xmm14
0000745cb6bcebf1  ucomisd xmm13, xmm13
0000745cb6bcebf6  jp 0x0000745CB6BCEE44
0000745cb6bcebfc  movq xmm13, xmm13
0000745cb6bcec01  movq rax, xmm13
0000745cb6bcec06  movq r14, xmm1
0000745cb6bcec0b  vmovq xmm15, rax
0000745cb6bcec10  vmovq xmm14, r14
0000745cb6bcec15  movaps xmm13, xmm15
0000745cb6bcec19  addsd xmm13, xmm14
0000745cb6bcec1e  ucomisd xmm13, xmm13
0000745cb6bcec23  jp 0x0000745CB6BCEE8C
0000745cb6bcec29  movq xmm13, xmm13
0000745cb6bcec2e  movq rax, xmm13
0000745cb6bcec33  movq r14, xmm1
0000745cb6bcec38  vmovq xmm15, rax
0000745cb6bcec3d  vmovq xmm14, r14
0000745cb6bcec42  movaps xmm13, xmm15
0000745cb6bcec46  addsd xmm13, xmm14
0000745cb6bcec4b  ucomisd xmm13, xmm13
0000745cb6bcec50  jp 0x0000745CB6BCEED4
0000745cb6bcec56  movq xmm13, xmm13
0000745cb6bcec5b  movq rax, xmm13
0000745cb6bcec60  movq r14, xmm1
0000745cb6bcec65  vmovq xmm1, rax
0000745cb6bcec6a  vmovq xmm15, r14
0000745cb6bcec6f  movaps xmm14, xmm1
0000745cb6bcec73  addsd xmm14, xmm15
0000745cb6bcec78  ucomisd xmm14, xmm14
0000745cb6bcec7d  jp 0x0000745CB6BCEF1C
0000745cb6bcec83  movq xmm14, xmm14
0000745cb6bcec88  movaps [r15+0x110], xmm14
0000745cb6bcec90  mov rax, [r15+0x08]
0000745cb6bcec94  mov [rsp+0x10], rax
0000745cb6bcec99  xor eax, eax
0000745cb6bcec9b  mov r14, [rsp+0x10]
0000745cb6bceca0  mov r12d, 0x01
0000745cb6bceca6  sub r14, r12
0000745cb6bceca9  cmc
0000745cb6bcecaa  lahf
0000745cb6bcecab  seto al
0000745cb6bcecae  mov [r15+0x108], eax
0000745cb6bcecb5  mov [r15+0x08], r14
0000745cb6bcecb9  mov eax, [r15+0x108]
0000745cb6bcecc0  sahf
0000745cb6bcecc1  jnz 0x0000745CB6BCECF3
0000745cb6bcecc3  cmp dword ptr [r15+0x318], 0x00
0000745cb6bceccb  jz 0x0000745CB6BCEF70
0000745cb6bcecd1  nop [rax+rax*1], ax
0000745cb6bcecda  nop [rax+rax*1], eax
0000745cb6bcece2  mov eax, 0x41006C
0000745cb6bcece7  mov [r15+0x100], rax
0000745cb6bcecee  jmp 0x0000745CB69FE110
0000745cb6bcecf3  cmp dword ptr [r15+0x318], 0x00
0000745cb6bcecfb  jz 0x0000745CB6BCEB10
0000745cb6bced01  nop [rax+rax*1], ax
0000745cb6bced0a  nop [rax+rax*1], eax
0000745cb6bced12  mov eax, 0x410044
0000745cb6bced17  mov [r15+0x100], rax
0000745cb6bced1e  jmp 0x0000745CB69FE110
0000745cb6bced23  int3
0000745cb6bced24  ucomisd xmm15, xmm14
0000745cb6bced29  jp 0x0000745CB6BCED38
0000745cb6bced2b  movaps xmm13, [0x0000745CB67FE030]
0000745cb6bced33  jmp 0x0000745CB6BCEB48
0000745cb6bced38  vxorps xmm0, xmm15, xmm14
0000745cb6bced3d  pextrw eax, xmm0, 0x03
0000745cb6bced42  and eax, 0x7FF8
0000745cb6bced47  cmp eax, 0x08
0000745cb6bced4a  jnz 0x0000745CB6BCEB48
0000745cb6bced50  movq rax, xmm14
0000745cb6bced55  shl rax, 0x0D
0000745cb6bced59  jbe 0x0000745CB6BCEB48
0000745cb6bced5f  vorps xmm13, xmm14, [0x0000745CB67FE040]
0000745cb6bced67  jmp 0x0000745CB6BCEB48
0000745cb6bced6c  ucomisd xmm15, xmm14
0000745cb6bced71  jp 0x0000745CB6BCED80
0000745cb6bced73  movaps xmm13, [0x0000745CB67FE030]
0000745cb6bced7b  jmp 0x0000745CB6BCEB75
0000745cb6bced80  vxorps xmm0, xmm15, xmm14
0000745cb6bced85  pextrw eax, xmm0, 0x03
0000745cb6bced8a  and eax, 0x7FF8
0000745cb6bced8f  cmp eax, 0x08
0000745cb6bced92  jnz 0x0000745CB6BCEB75
0000745cb6bced98  movq rax, xmm14
0000745cb6bced9d  shl rax, 0x0D
0000745cb6bceda1  jbe 0x0000745CB6BCEB75
0000745cb6bceda7  vorps xmm13, xmm14, [0x0000745CB67FE040]
0000745cb6bcedaf  jmp 0x0000745CB6BCEB75
0000745cb6bcedb4  ucomisd xmm15, xmm14
0000745cb6bcedb9  jp 0x0000745CB6BCEDC8
0000745cb6bcedbb  movaps xmm13, [0x0000745CB67FE030]
0000745cb6bcedc3  jmp 0x0000745CB6BCEBA2
0000745cb6bcedc8  vxorps xmm0, xmm15, xmm14
0000745cb6bcedcd  pextrw eax, xmm0, 0x03
0000745cb6bcedd2  and eax, 0x7FF8
0000745cb6bcedd7  cmp eax, 0x08
0000745cb6bcedda  jnz 0x0000745CB6BCEBA2
0000745cb6bcede0  movq rax, xmm14
0000745cb6bcede5  shl rax, 0x0D
0000745cb6bcede9  jbe 0x0000745CB6BCEBA2
0000745cb6bcedef  vorps xmm13, xmm14, [0x0000745CB67FE040]
0000745cb6bcedf7  jmp 0x0000745CB6BCEBA2
0000745cb6bcedfc  ucomisd xmm15, xmm14
0000745cb6bcee01  jp 0x0000745CB6BCEE10
0000745cb6bcee03  movaps xmm13, [0x0000745CB67FE030]
0000745cb6bcee0b  jmp 0x0000745CB6BCEBCF
0000745cb6bcee10  vxorps xmm0, xmm15, xmm14
0000745cb6bcee15  pextrw eax, xmm0, 0x03
0000745cb6bcee1a  and eax, 0x7FF8
0000745cb6bcee1f  cmp eax, 0x08
0000745cb6bcee22  jnz 0x0000745CB6BCEBCF
0000745cb6bcee28  movq rax, xmm14
0000745cb6bcee2d  shl rax, 0x0D
0000745cb6bcee31  jbe 0x0000745CB6BCEBCF
0000745cb6bcee37  vorps xmm13, xmm14, [0x0000745CB67FE040]
0000745cb6bcee3f  jmp 0x0000745CB6BCEBCF
0000745cb6bcee44  ucomisd xmm15, xmm14
0000745cb6bcee49  jp 0x0000745CB6BCEE58
0000745cb6bcee4b  movaps xmm13, [0x0000745CB67FE030]
0000745cb6bcee53  jmp 0x0000745CB6BCEBFC
0000745cb6bcee58  vxorps xmm0, xmm15, xmm14
0000745cb6bcee5d  pextrw eax, xmm0, 0x03
0000745cb6bcee62  and eax, 0x7FF8
0000745cb6bcee67  cmp eax, 0x08
0000745cb6bcee6a  jnz 0x0000745CB6BCEBFC
0000745cb6bcee70  movq rax, xmm14
0000745cb6bcee75  shl rax, 0x0D
0000745cb6bcee79  jbe 0x0000745CB6BCEBFC
0000745cb6bcee7f  vorps xmm13, xmm14, [0x0000745CB67FE040]
0000745cb6bcee87  jmp 0x0000745CB6BCEBFC
0000745cb6bcee8c  ucomisd xmm15, xmm14
0000745cb6bcee91  jp 0x0000745CB6BCEEA0
0000745cb6bcee93  movaps xmm13, [0x0000745CB67FE030]
0000745cb6bcee9b  jmp 0x0000745CB6BCEC29
0000745cb6bceea0  vxorps xmm0, xmm15, xmm14
0000745cb6bceea5  pextrw eax, xmm0, 0x03
0000745cb6bceeaa  and eax, 0x7FF8
0000745cb6bceeaf  cmp eax, 0x08
0000745cb6bceeb2  jnz 0x0000745CB6BCEC29
0000745cb6bceeb8  movq rax, xmm14
0000745cb6bceebd  shl rax, 0x0D
0000745cb6bceec1  jbe 0x0000745CB6BCEC29
0000745cb6bceec7  vorps xmm13, xmm14, [0x0000745CB67FE040]
0000745cb6bceecf  jmp 0x0000745CB6BCEC29
0000745cb6bceed4  ucomisd xmm15, xmm14
0000745cb6bceed9  jp 0x0000745CB6BCEEE8
0000745cb6bceedb  movaps xmm13, [0x0000745CB67FE030]
0000745cb6bceee3  jmp 0x0000745CB6BCEC56
0000745cb6bceee8  vxorps xmm0, xmm15, xmm14
0000745cb6bceeed  pextrw eax, xmm0, 0x03
0000745cb6bceef2  and eax, 0x7FF8
0000745cb6bceef7  cmp eax, 0x08
0000745cb6bceefa  jnz 0x0000745CB6BCEC56
0000745cb6bcef00  movq rax, xmm14
0000745cb6bcef05  shl rax, 0x0D
0000745cb6bcef09  jbe 0x0000745CB6BCEC56
0000745cb6bcef0f  vorps xmm13, xmm14, [0x0000745CB67FE040]
0000745cb6bcef17  jmp 0x0000745CB6BCEC56
0000745cb6bcef1c  ucomisd xmm1, xmm15
0000745cb6bcef21  jp 0x0000745CB6BCEF30
0000745cb6bcef23  movaps xmm14, [0x0000745CB67FE030]
0000745cb6bcef2b  jmp 0x0000745CB6BCEC83
0000745cb6bcef30  vxorps xmm0, xmm1, xmm15
0000745cb6bcef35  pextrw eax, xmm0, 0x03
0000745cb6bcef3a  and eax, 0x7FF8
0000745cb6bcef3f  cmp eax, 0x08
0000745cb6bcef42  jnz 0x0000745CB6BCEC83
0000745cb6bcef48  movq rax, xmm15
0000745cb6bcef4d  shl rax, 0x0D
0000745cb6bcef51  jbe 0x0000745CB6BCEC83
0000745cb6bcef57  vorps xmm14, xmm15, [0x0000745CB67FE040]
0000745cb6bcef5f  jmp 0x0000745CB6BCEC83
0000745cb6bcef64  int3
0000745cb6bcef65  nop [rax+rax*1], ax
0000745cb6bcef6e  nop
0000745cb6bcef70  mov rax, [r15+0x20]
0000745cb6bcef74  movaps xmm1, [r15+0x110]
0000745cb6bcef7c  movq r14, xmm1
0000745cb6bcef81  mov [r13+rax*1], r14
0000745cb6bcef86  mov rax, [r15+0xF0]
0000745cb6bcef8d  mov [r15+0x100], rax
0000745cb6bcef94  jmp 0x0000745CB6BCE5C0
0000745cb6bcef99  int3
0000745cb6bcef9a  call 0x0000745CB6A0E120
0000745cb6bcef9f  jmp 0x0000745CB6BCEF86
0000745cb6bcefa4  int3
0000745cb6bcefa5  nop [rax+rax*1], ax
0000745cb6bcefae  nop
0000745cb6bcefb0  mov qword ptr [r15+0x100], 0x04
0000745cb6bcefbb  mov esi, 0x00
0000745cb6bcefc0  mov edx, 0x09
0000745cb6bcefc5  mov rdi, 0x7FFFD15316A0
0000745cb6bcefcf  mov rax, 0x55F6EE100970
0000745cb6bcefd9  call rax
0000745cb6bcefdb  cmp dword ptr [r15+0x318], 0x00
0000745cb6bcefe3  jnz 0x0000745CB69FE110
0000745cb6bcefe9  jmp 0x0000745CB69FE0A0
0000745cb6bcefee  int3
0000745cb6bcefef  int3
