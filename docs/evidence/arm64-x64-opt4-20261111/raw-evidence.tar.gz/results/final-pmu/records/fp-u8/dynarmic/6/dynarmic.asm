000076f5e69ce69b  nop [rax+rax*1], eax
000076f5e69ce6a0  mov qword ptr [r15+0x20], 0x420080
000076f5e69ce6a8  mov qword ptr [r15], 0x00
000076f5e69ce6af  vmovaps xmm1, [0x000076F5E65FE010]
000076f5e69ce6b7  movq xmm1, xmm1
000076f5e69ce6bb  vmovaps xmm15, [0x000076F5E65FE020]
000076f5e69ce6c3  movq xmm15, xmm15
000076f5e69ce6c8  movaps [r15+0x120], xmm15
000076f5e69ce6d0  movq rax, xmm1
000076f5e69ce6d5  movq r14, xmm15
000076f5e69ce6da  vmovq xmm1, rax
000076f5e69ce6df  vmovq xmm14, r14
000076f5e69ce6e4  movaps xmm13, xmm1
000076f5e69ce6e8  addsd xmm13, xmm14
000076f5e69ce6ed  ucomisd xmm13, xmm13
000076f5e69ce6f2  jp 0x000076F5E69CE8CC
000076f5e69ce6f8  movq xmm13, xmm13
000076f5e69ce6fd  movq rax, xmm13
000076f5e69ce702  movq r14, xmm15
000076f5e69ce707  vmovq xmm1, rax
000076f5e69ce70c  vmovq xmm14, r14
000076f5e69ce711  movaps xmm13, xmm1
000076f5e69ce715  addsd xmm13, xmm14
000076f5e69ce71a  ucomisd xmm13, xmm13
000076f5e69ce71f  jp 0x000076F5E69CE914
000076f5e69ce725  movq xmm13, xmm13
000076f5e69ce72a  movq rax, xmm13
000076f5e69ce72f  movq r14, xmm15
000076f5e69ce734  vmovq xmm1, rax
000076f5e69ce739  vmovq xmm14, r14
000076f5e69ce73e  movaps xmm13, xmm1
000076f5e69ce742  addsd xmm13, xmm14
000076f5e69ce747  ucomisd xmm13, xmm13
000076f5e69ce74c  jp 0x000076F5E69CE95C
000076f5e69ce752  movq xmm13, xmm13
000076f5e69ce757  movq rax, xmm13
000076f5e69ce75c  movq r14, xmm15
000076f5e69ce761  vmovq xmm1, rax
000076f5e69ce766  vmovq xmm14, r14
000076f5e69ce76b  movaps xmm13, xmm1
000076f5e69ce76f  addsd xmm13, xmm14
000076f5e69ce774  ucomisd xmm13, xmm13
000076f5e69ce779  jp 0x000076F5E69CE9A4
000076f5e69ce77f  movq xmm13, xmm13
000076f5e69ce784  movq rax, xmm13
000076f5e69ce789  movq r14, xmm15
000076f5e69ce78e  vmovq xmm1, rax
000076f5e69ce793  vmovq xmm14, r14
000076f5e69ce798  movaps xmm13, xmm1
000076f5e69ce79c  addsd xmm13, xmm14
000076f5e69ce7a1  ucomisd xmm13, xmm13
000076f5e69ce7a6  jp 0x000076F5E69CE9EC
000076f5e69ce7ac  movq xmm13, xmm13
000076f5e69ce7b1  movq rax, xmm13
000076f5e69ce7b6  movq r14, xmm15
000076f5e69ce7bb  vmovq xmm1, rax
000076f5e69ce7c0  vmovq xmm14, r14
000076f5e69ce7c5  movaps xmm13, xmm1
000076f5e69ce7c9  addsd xmm13, xmm14
000076f5e69ce7ce  ucomisd xmm13, xmm13
000076f5e69ce7d3  jp 0x000076F5E69CEA34
000076f5e69ce7d9  movq xmm13, xmm13
000076f5e69ce7de  movq rax, xmm13
000076f5e69ce7e3  movq r14, xmm15
000076f5e69ce7e8  vmovq xmm1, rax
000076f5e69ce7ed  vmovq xmm14, r14
000076f5e69ce7f2  movaps xmm13, xmm1
000076f5e69ce7f6  addsd xmm13, xmm14
000076f5e69ce7fb  ucomisd xmm13, xmm13
000076f5e69ce800  jp 0x000076F5E69CEA7C
000076f5e69ce806  movq xmm13, xmm13
000076f5e69ce80b  movq rax, xmm13
000076f5e69ce810  movq r14, xmm15
000076f5e69ce815  vmovq xmm1, rax
000076f5e69ce81a  vmovq xmm15, r14
000076f5e69ce81f  movaps xmm14, xmm1
000076f5e69ce823  addsd xmm14, xmm15
000076f5e69ce828  ucomisd xmm14, xmm14
000076f5e69ce82d  jp 0x000076F5E69CEAC4
000076f5e69ce833  movq xmm14, xmm14
000076f5e69ce838  movaps [r15+0x110], xmm14
000076f5e69ce840  xor eax, eax
000076f5e69ce842  mov r14d, 0x1E848
000076f5e69ce848  mov r12d, 0x01
000076f5e69ce84e  sub r14, r12
000076f5e69ce851  cmc
000076f5e69ce852  lahf
000076f5e69ce853  seto al
000076f5e69ce856  mov [r15+0x108], eax
000076f5e69ce85d  mov [r15+0x08], r14
000076f5e69ce861  mov eax, [r15+0x108]
000076f5e69ce868  sahf
000076f5e69ce869  jnz 0x000076F5E69CE89B
000076f5e69ce86b  cmp dword ptr [r15+0x318], 0x00
000076f5e69ce873  jz 0x000076F5E69CEF70
000076f5e69ce879  nop [rax+rax*1], ax
000076f5e69ce882  nop [rax+rax*1], eax
000076f5e69ce88a  mov eax, 0x41006C
000076f5e69ce88f  mov [r15+0x100], rax
000076f5e69ce896  jmp 0x000076F5E67FE110
000076f5e69ce89b  cmp dword ptr [r15+0x318], 0x00
000076f5e69ce8a3  jz 0x000076F5E69CEB10
000076f5e69ce8a9  nop [rax+rax*1], ax
000076f5e69ce8b2  nop [rax+rax*1], eax
000076f5e69ce8ba  mov eax, 0x410044
000076f5e69ce8bf  mov [r15+0x100], rax
000076f5e69ce8c6  jmp 0x000076F5E67FE110
000076f5e69ce8cb  int3
000076f5e69ce8cc  ucomisd xmm1, xmm14
000076f5e69ce8d1  jp 0x000076F5E69CE8E0
000076f5e69ce8d3  movaps xmm13, [0x000076F5E65FE030]
000076f5e69ce8db  jmp 0x000076F5E69CE6F8
000076f5e69ce8e0  vxorps xmm0, xmm1, xmm14
000076f5e69ce8e5  pextrw eax, xmm0, 0x03
000076f5e69ce8ea  and eax, 0x7FF8
000076f5e69ce8ef  cmp eax, 0x08
000076f5e69ce8f2  jnz 0x000076F5E69CE6F8
000076f5e69ce8f8  movq rax, xmm14
000076f5e69ce8fd  shl rax, 0x0D
000076f5e69ce901  jbe 0x000076F5E69CE6F8
000076f5e69ce907  vorps xmm13, xmm14, [0x000076F5E65FE040]
000076f5e69ce90f  jmp 0x000076F5E69CE6F8
000076f5e69ce914  ucomisd xmm1, xmm14
000076f5e69ce919  jp 0x000076F5E69CE928
000076f5e69ce91b  movaps xmm13, [0x000076F5E65FE030]
000076f5e69ce923  jmp 0x000076F5E69CE725
000076f5e69ce928  vxorps xmm0, xmm1, xmm14
000076f5e69ce92d  pextrw eax, xmm0, 0x03
000076f5e69ce932  and eax, 0x7FF8
000076f5e69ce937  cmp eax, 0x08
000076f5e69ce93a  jnz 0x000076F5E69CE725
000076f5e69ce940  movq rax, xmm14
000076f5e69ce945  shl rax, 0x0D
000076f5e69ce949  jbe 0x000076F5E69CE725
000076f5e69ce94f  vorps xmm13, xmm14, [0x000076F5E65FE040]
000076f5e69ce957  jmp 0x000076F5E69CE725
000076f5e69ce95c  ucomisd xmm1, xmm14
000076f5e69ce961  jp 0x000076F5E69CE970
000076f5e69ce963  movaps xmm13, [0x000076F5E65FE030]
000076f5e69ce96b  jmp 0x000076F5E69CE752
000076f5e69ce970  vxorps xmm0, xmm1, xmm14
000076f5e69ce975  pextrw eax, xmm0, 0x03
000076f5e69ce97a  and eax, 0x7FF8
000076f5e69ce97f  cmp eax, 0x08
000076f5e69ce982  jnz 0x000076F5E69CE752
000076f5e69ce988  movq rax, xmm14
000076f5e69ce98d  shl rax, 0x0D
000076f5e69ce991  jbe 0x000076F5E69CE752
000076f5e69ce997  vorps xmm13, xmm14, [0x000076F5E65FE040]
000076f5e69ce99f  jmp 0x000076F5E69CE752
000076f5e69ce9a4  ucomisd xmm1, xmm14
000076f5e69ce9a9  jp 0x000076F5E69CE9B8
000076f5e69ce9ab  movaps xmm13, [0x000076F5E65FE030]
000076f5e69ce9b3  jmp 0x000076F5E69CE77F
000076f5e69ce9b8  vxorps xmm0, xmm1, xmm14
000076f5e69ce9bd  pextrw eax, xmm0, 0x03
000076f5e69ce9c2  and eax, 0x7FF8
000076f5e69ce9c7  cmp eax, 0x08
000076f5e69ce9ca  jnz 0x000076F5E69CE77F
000076f5e69ce9d0  movq rax, xmm14
000076f5e69ce9d5  shl rax, 0x0D
000076f5e69ce9d9  jbe 0x000076F5E69CE77F
000076f5e69ce9df  vorps xmm13, xmm14, [0x000076F5E65FE040]
000076f5e69ce9e7  jmp 0x000076F5E69CE77F
000076f5e69ce9ec  ucomisd xmm1, xmm14
000076f5e69ce9f1  jp 0x000076F5E69CEA00
000076f5e69ce9f3  movaps xmm13, [0x000076F5E65FE030]
000076f5e69ce9fb  jmp 0x000076F5E69CE7AC
000076f5e69cea00  vxorps xmm0, xmm1, xmm14
000076f5e69cea05  pextrw eax, xmm0, 0x03
000076f5e69cea0a  and eax, 0x7FF8
000076f5e69cea0f  cmp eax, 0x08
000076f5e69cea12  jnz 0x000076F5E69CE7AC
000076f5e69cea18  movq rax, xmm14
000076f5e69cea1d  shl rax, 0x0D
000076f5e69cea21  jbe 0x000076F5E69CE7AC
000076f5e69cea27  vorps xmm13, xmm14, [0x000076F5E65FE040]
000076f5e69cea2f  jmp 0x000076F5E69CE7AC
000076f5e69cea34  ucomisd xmm1, xmm14
000076f5e69cea39  jp 0x000076F5E69CEA48
000076f5e69cea3b  movaps xmm13, [0x000076F5E65FE030]
000076f5e69cea43  jmp 0x000076F5E69CE7D9
000076f5e69cea48  vxorps xmm0, xmm1, xmm14
000076f5e69cea4d  pextrw eax, xmm0, 0x03
000076f5e69cea52  and eax, 0x7FF8
000076f5e69cea57  cmp eax, 0x08
000076f5e69cea5a  jnz 0x000076F5E69CE7D9
000076f5e69cea60  movq rax, xmm14
000076f5e69cea65  shl rax, 0x0D
000076f5e69cea69  jbe 0x000076F5E69CE7D9
000076f5e69cea6f  vorps xmm13, xmm14, [0x000076F5E65FE040]
000076f5e69cea77  jmp 0x000076F5E69CE7D9
000076f5e69cea7c  ucomisd xmm1, xmm14
000076f5e69cea81  jp 0x000076F5E69CEA90
000076f5e69cea83  movaps xmm13, [0x000076F5E65FE030]
000076f5e69cea8b  jmp 0x000076F5E69CE806
000076f5e69cea90  vxorps xmm0, xmm1, xmm14
000076f5e69cea95  pextrw eax, xmm0, 0x03
000076f5e69cea9a  and eax, 0x7FF8
000076f5e69cea9f  cmp eax, 0x08
000076f5e69ceaa2  jnz 0x000076F5E69CE806
000076f5e69ceaa8  movq rax, xmm14
000076f5e69ceaad  shl rax, 0x0D
000076f5e69ceab1  jbe 0x000076F5E69CE806
000076f5e69ceab7  vorps xmm13, xmm14, [0x000076F5E65FE040]
000076f5e69ceabf  jmp 0x000076F5E69CE806
000076f5e69ceac4  ucomisd xmm1, xmm15
000076f5e69ceac9  jp 0x000076F5E69CEAD8
000076f5e69ceacb  movaps xmm14, [0x000076F5E65FE030]
000076f5e69cead3  jmp 0x000076F5E69CE833
000076f5e69cead8  vxorps xmm0, xmm1, xmm15
000076f5e69ceadd  pextrw eax, xmm0, 0x03
000076f5e69ceae2  and eax, 0x7FF8
000076f5e69ceae7  cmp eax, 0x08
000076f5e69ceaea  jnz 0x000076F5E69CE833
000076f5e69ceaf0  movq rax, xmm15
000076f5e69ceaf5  shl rax, 0x0D
000076f5e69ceaf9  jbe 0x000076F5E69CE833
000076f5e69ceaff  vorps xmm14, xmm15, [0x000076F5E65FE040]
000076f5e69ceb07  jmp 0x000076F5E69CE833
000076f5e69ceb0c  int3
000076f5e69ceb0d  nop [rax], eax
000076f5e69ceb10  movaps xmm1, [r15+0x110]
000076f5e69ceb18  movq rax, xmm1
000076f5e69ceb1d  movaps xmm1, [r15+0x120]
000076f5e69ceb25  movq r14, xmm1
000076f5e69ceb2a  vmovq xmm15, rax
000076f5e69ceb2f  vmovq xmm14, r14
000076f5e69ceb34  movaps xmm13, xmm15
000076f5e69ceb38  addsd xmm13, xmm14
000076f5e69ceb3d  ucomisd xmm13, xmm13
000076f5e69ceb42  jp 0x000076F5E69CED24
000076f5e69ceb48  movq xmm13, xmm13
000076f5e69ceb4d  movq rax, xmm13
000076f5e69ceb52  movq r14, xmm1
000076f5e69ceb57  vmovq xmm15, rax
000076f5e69ceb5c  vmovq xmm14, r14
000076f5e69ceb61  movaps xmm13, xmm15
000076f5e69ceb65  addsd xmm13, xmm14
000076f5e69ceb6a  ucomisd xmm13, xmm13
000076f5e69ceb6f  jp 0x000076F5E69CED6C
000076f5e69ceb75  movq xmm13, xmm13
000076f5e69ceb7a  movq rax, xmm13
000076f5e69ceb7f  movq r14, xmm1
000076f5e69ceb84  vmovq xmm15, rax
000076f5e69ceb89  vmovq xmm14, r14
000076f5e69ceb8e  movaps xmm13, xmm15
000076f5e69ceb92  addsd xmm13, xmm14
000076f5e69ceb97  ucomisd xmm13, xmm13
000076f5e69ceb9c  jp 0x000076F5E69CEDB4
000076f5e69ceba2  movq xmm13, xmm13
000076f5e69ceba7  movq rax, xmm13
000076f5e69cebac  movq r14, xmm1
000076f5e69cebb1  vmovq xmm15, rax
000076f5e69cebb6  vmovq xmm14, r14
000076f5e69cebbb  movaps xmm13, xmm15
000076f5e69cebbf  addsd xmm13, xmm14
000076f5e69cebc4  ucomisd xmm13, xmm13
000076f5e69cebc9  jp 0x000076F5E69CEDFC
000076f5e69cebcf  movq xmm13, xmm13
000076f5e69cebd4  movq rax, xmm13
000076f5e69cebd9  movq r14, xmm1
000076f5e69cebde  vmovq xmm15, rax
000076f5e69cebe3  vmovq xmm14, r14
000076f5e69cebe8  movaps xmm13, xmm15
000076f5e69cebec  addsd xmm13, xmm14
000076f5e69cebf1  ucomisd xmm13, xmm13
000076f5e69cebf6  jp 0x000076F5E69CEE44
000076f5e69cebfc  movq xmm13, xmm13
000076f5e69cec01  movq rax, xmm13
000076f5e69cec06  movq r14, xmm1
000076f5e69cec0b  vmovq xmm15, rax
000076f5e69cec10  vmovq xmm14, r14
000076f5e69cec15  movaps xmm13, xmm15
000076f5e69cec19  addsd xmm13, xmm14
000076f5e69cec1e  ucomisd xmm13, xmm13
000076f5e69cec23  jp 0x000076F5E69CEE8C
000076f5e69cec29  movq xmm13, xmm13
000076f5e69cec2e  movq rax, xmm13
000076f5e69cec33  movq r14, xmm1
000076f5e69cec38  vmovq xmm15, rax
000076f5e69cec3d  vmovq xmm14, r14
000076f5e69cec42  movaps xmm13, xmm15
000076f5e69cec46  addsd xmm13, xmm14
000076f5e69cec4b  ucomisd xmm13, xmm13
000076f5e69cec50  jp 0x000076F5E69CEED4
000076f5e69cec56  movq xmm13, xmm13
000076f5e69cec5b  movq rax, xmm13
000076f5e69cec60  movq r14, xmm1
000076f5e69cec65  vmovq xmm1, rax
000076f5e69cec6a  vmovq xmm15, r14
000076f5e69cec6f  movaps xmm14, xmm1
000076f5e69cec73  addsd xmm14, xmm15
000076f5e69cec78  ucomisd xmm14, xmm14
000076f5e69cec7d  jp 0x000076F5E69CEF1C
000076f5e69cec83  movq xmm14, xmm14
000076f5e69cec88  movaps [r15+0x110], xmm14
000076f5e69cec90  mov rax, [r15+0x08]
000076f5e69cec94  mov [rsp+0x10], rax
000076f5e69cec99  xor eax, eax
000076f5e69cec9b  mov r14, [rsp+0x10]
000076f5e69ceca0  mov r12d, 0x01
000076f5e69ceca6  sub r14, r12
000076f5e69ceca9  cmc
000076f5e69cecaa  lahf
000076f5e69cecab  seto al
000076f5e69cecae  mov [r15+0x108], eax
000076f5e69cecb5  mov [r15+0x08], r14
000076f5e69cecb9  mov eax, [r15+0x108]
000076f5e69cecc0  sahf
000076f5e69cecc1  jnz 0x000076F5E69CECF3
000076f5e69cecc3  cmp dword ptr [r15+0x318], 0x00
000076f5e69ceccb  jz 0x000076F5E69CEF70
000076f5e69cecd1  nop [rax+rax*1], ax
000076f5e69cecda  nop [rax+rax*1], eax
000076f5e69cece2  mov eax, 0x41006C
000076f5e69cece7  mov [r15+0x100], rax
000076f5e69cecee  jmp 0x000076F5E67FE110
000076f5e69cecf3  cmp dword ptr [r15+0x318], 0x00
000076f5e69cecfb  jz 0x000076F5E69CEB10
000076f5e69ced01  nop [rax+rax*1], ax
000076f5e69ced0a  nop [rax+rax*1], eax
000076f5e69ced12  mov eax, 0x410044
000076f5e69ced17  mov [r15+0x100], rax
000076f5e69ced1e  jmp 0x000076F5E67FE110
000076f5e69ced23  int3
000076f5e69ced24  ucomisd xmm15, xmm14
000076f5e69ced29  jp 0x000076F5E69CED38
000076f5e69ced2b  movaps xmm13, [0x000076F5E65FE030]
000076f5e69ced33  jmp 0x000076F5E69CEB48
000076f5e69ced38  vxorps xmm0, xmm15, xmm14
000076f5e69ced3d  pextrw eax, xmm0, 0x03
000076f5e69ced42  and eax, 0x7FF8
000076f5e69ced47  cmp eax, 0x08
000076f5e69ced4a  jnz 0x000076F5E69CEB48
000076f5e69ced50  movq rax, xmm14
000076f5e69ced55  shl rax, 0x0D
000076f5e69ced59  jbe 0x000076F5E69CEB48
000076f5e69ced5f  vorps xmm13, xmm14, [0x000076F5E65FE040]
000076f5e69ced67  jmp 0x000076F5E69CEB48
000076f5e69ced6c  ucomisd xmm15, xmm14
000076f5e69ced71  jp 0x000076F5E69CED80
000076f5e69ced73  movaps xmm13, [0x000076F5E65FE030]
000076f5e69ced7b  jmp 0x000076F5E69CEB75
000076f5e69ced80  vxorps xmm0, xmm15, xmm14
000076f5e69ced85  pextrw eax, xmm0, 0x03
000076f5e69ced8a  and eax, 0x7FF8
000076f5e69ced8f  cmp eax, 0x08
000076f5e69ced92  jnz 0x000076F5E69CEB75
000076f5e69ced98  movq rax, xmm14
000076f5e69ced9d  shl rax, 0x0D
000076f5e69ceda1  jbe 0x000076F5E69CEB75
000076f5e69ceda7  vorps xmm13, xmm14, [0x000076F5E65FE040]
000076f5e69cedaf  jmp 0x000076F5E69CEB75
000076f5e69cedb4  ucomisd xmm15, xmm14
000076f5e69cedb9  jp 0x000076F5E69CEDC8
000076f5e69cedbb  movaps xmm13, [0x000076F5E65FE030]
000076f5e69cedc3  jmp 0x000076F5E69CEBA2
000076f5e69cedc8  vxorps xmm0, xmm15, xmm14
000076f5e69cedcd  pextrw eax, xmm0, 0x03
000076f5e69cedd2  and eax, 0x7FF8
000076f5e69cedd7  cmp eax, 0x08
000076f5e69cedda  jnz 0x000076F5E69CEBA2
000076f5e69cede0  movq rax, xmm14
000076f5e69cede5  shl rax, 0x0D
000076f5e69cede9  jbe 0x000076F5E69CEBA2
000076f5e69cedef  vorps xmm13, xmm14, [0x000076F5E65FE040]
000076f5e69cedf7  jmp 0x000076F5E69CEBA2
000076f5e69cedfc  ucomisd xmm15, xmm14
000076f5e69cee01  jp 0x000076F5E69CEE10
000076f5e69cee03  movaps xmm13, [0x000076F5E65FE030]
000076f5e69cee0b  jmp 0x000076F5E69CEBCF
000076f5e69cee10  vxorps xmm0, xmm15, xmm14
000076f5e69cee15  pextrw eax, xmm0, 0x03
000076f5e69cee1a  and eax, 0x7FF8
000076f5e69cee1f  cmp eax, 0x08
000076f5e69cee22  jnz 0x000076F5E69CEBCF
000076f5e69cee28  movq rax, xmm14
000076f5e69cee2d  shl rax, 0x0D
000076f5e69cee31  jbe 0x000076F5E69CEBCF
000076f5e69cee37  vorps xmm13, xmm14, [0x000076F5E65FE040]
000076f5e69cee3f  jmp 0x000076F5E69CEBCF
000076f5e69cee44  ucomisd xmm15, xmm14
000076f5e69cee49  jp 0x000076F5E69CEE58
000076f5e69cee4b  movaps xmm13, [0x000076F5E65FE030]
000076f5e69cee53  jmp 0x000076F5E69CEBFC
000076f5e69cee58  vxorps xmm0, xmm15, xmm14
000076f5e69cee5d  pextrw eax, xmm0, 0x03
000076f5e69cee62  and eax, 0x7FF8
000076f5e69cee67  cmp eax, 0x08
000076f5e69cee6a  jnz 0x000076F5E69CEBFC
000076f5e69cee70  movq rax, xmm14
000076f5e69cee75  shl rax, 0x0D
000076f5e69cee79  jbe 0x000076F5E69CEBFC
000076f5e69cee7f  vorps xmm13, xmm14, [0x000076F5E65FE040]
000076f5e69cee87  jmp 0x000076F5E69CEBFC
000076f5e69cee8c  ucomisd xmm15, xmm14
000076f5e69cee91  jp 0x000076F5E69CEEA0
000076f5e69cee93  movaps xmm13, [0x000076F5E65FE030]
000076f5e69cee9b  jmp 0x000076F5E69CEC29
000076f5e69ceea0  vxorps xmm0, xmm15, xmm14
000076f5e69ceea5  pextrw eax, xmm0, 0x03
000076f5e69ceeaa  and eax, 0x7FF8
000076f5e69ceeaf  cmp eax, 0x08
000076f5e69ceeb2  jnz 0x000076F5E69CEC29
000076f5e69ceeb8  movq rax, xmm14
000076f5e69ceebd  shl rax, 0x0D
000076f5e69ceec1  jbe 0x000076F5E69CEC29
000076f5e69ceec7  vorps xmm13, xmm14, [0x000076F5E65FE040]
000076f5e69ceecf  jmp 0x000076F5E69CEC29
000076f5e69ceed4  ucomisd xmm15, xmm14
000076f5e69ceed9  jp 0x000076F5E69CEEE8
000076f5e69ceedb  movaps xmm13, [0x000076F5E65FE030]
000076f5e69ceee3  jmp 0x000076F5E69CEC56
000076f5e69ceee8  vxorps xmm0, xmm15, xmm14
000076f5e69ceeed  pextrw eax, xmm0, 0x03
000076f5e69ceef2  and eax, 0x7FF8
000076f5e69ceef7  cmp eax, 0x08
000076f5e69ceefa  jnz 0x000076F5E69CEC56
000076f5e69cef00  movq rax, xmm14
000076f5e69cef05  shl rax, 0x0D
000076f5e69cef09  jbe 0x000076F5E69CEC56
000076f5e69cef0f  vorps xmm13, xmm14, [0x000076F5E65FE040]
000076f5e69cef17  jmp 0x000076F5E69CEC56
000076f5e69cef1c  ucomisd xmm1, xmm15
000076f5e69cef21  jp 0x000076F5E69CEF30
000076f5e69cef23  movaps xmm14, [0x000076F5E65FE030]
000076f5e69cef2b  jmp 0x000076F5E69CEC83
000076f5e69cef30  vxorps xmm0, xmm1, xmm15
000076f5e69cef35  pextrw eax, xmm0, 0x03
000076f5e69cef3a  and eax, 0x7FF8
000076f5e69cef3f  cmp eax, 0x08
000076f5e69cef42  jnz 0x000076F5E69CEC83
000076f5e69cef48  movq rax, xmm15
000076f5e69cef4d  shl rax, 0x0D
000076f5e69cef51  jbe 0x000076F5E69CEC83
000076f5e69cef57  vorps xmm14, xmm15, [0x000076F5E65FE040]
000076f5e69cef5f  jmp 0x000076F5E69CEC83
000076f5e69cef64  int3
000076f5e69cef65  nop [rax+rax*1], ax
000076f5e69cef6e  nop
000076f5e69cef70  mov rax, [r15+0x20]
000076f5e69cef74  movaps xmm1, [r15+0x110]
000076f5e69cef7c  movq r14, xmm1
000076f5e69cef81  mov [r13+rax*1], r14
000076f5e69cef86  mov rax, [r15+0xF0]
000076f5e69cef8d  mov [r15+0x100], rax
000076f5e69cef94  jmp 0x000076F5E69CE5C0
000076f5e69cef99  int3
000076f5e69cef9a  call 0x000076F5E680E120
000076f5e69cef9f  jmp 0x000076F5E69CEF86
000076f5e69cefa4  int3
000076f5e69cefa5  nop [rax+rax*1], ax
000076f5e69cefae  nop
000076f5e69cefb0  mov qword ptr [r15+0x100], 0x04
000076f5e69cefbb  mov esi, 0x00
000076f5e69cefc0  mov edx, 0x09
000076f5e69cefc5  mov rdi, 0x7FFDB09E0980
000076f5e69cefcf  mov rax, 0x5A521F614970
000076f5e69cefd9  call rax
000076f5e69cefdb  cmp dword ptr [r15+0x318], 0x00
000076f5e69cefe3  jnz 0x000076F5E67FE110
000076f5e69cefe9  jmp 0x000076F5E67FE0A0
000076f5e69cefee  int3
000076f5e69cefef  int3
