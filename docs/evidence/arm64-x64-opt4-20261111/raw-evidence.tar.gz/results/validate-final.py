from pathlib import Path
import subprocess,os,sys,json,time,collections,itertools
r=Path('/mnt/d/Dev/SwiftVM');w=Path.home()/'.cache/SwiftVM/arm64-x64-opt4-20261111'
old=Path.home()/'.cache/SwiftVM/wsl-arm-x64-20261111';sys.path.insert(0,str(r/'tools/correctness'));import oracle
os.sched_setaffinity(0,{4})
dut=w/'final_correctness'
summary={'binary_sha256':oracle.sha256(dut),'configs':{},'oracle_selftest':oracle.self_test()}
for group,corpus,expected,configs in [
 ('basic-a64',old/'corpus/arm64',old/'post-fp-matrix/oracle/arm64',list(itertools.product(['block','function'],['known','unknown','early_off'],[True,False],[True]))),
 ('basic-a32',old/'corpus/arm32',old/'post-fp-matrix/oracle/arm32',list(itertools.product(['block','function'],['known','unknown','early_off'],[True,False],[True]))),
 ('fp',old/'fp-corpus',old/'fp-validation/oracle',[('block','known',True,True),('function','known',True,True),('block','known',False,True)]),
 ('neon',w/'neon-corpus',w/'neon-oracle',[('block','known',True,True),('function','known',True,True),('block','known',False,True)])]:
 expected.mkdir(exist_ok=True,parents=True);cases=sorted(corpus.glob('*.svmcase'))
 for p in cases:
  dest=expected/(p.stem+'.json')
  if not dest.exists():oracle.write_json(dest,oracle.execute(oracle.read_case(p)))
 print('oracle ready',group,len(cases),flush=True)
 for scope,target,opt,pin in configs:
  name=f'{group}-{scope}-{target}-opt{int(opt)}-pin{int(pin)}';directory=w/'final-correctness'/name;directory.mkdir(exist_ok=True,parents=True)
  config={'backend':'x64','scope':scope,'target':target,'optimize':opt,'pin':pin,'compile_only':False}
  oracle.write_json(directory/'config.json',config)
  with (directory/'worker.log').open('w') as log:
   result=subprocess.run([str(dut),'worker','--input-dir',str(corpus),'--output-dir',str(directory/'actual'),'--config',str(directory/'config.json')],stdout=log,stderr=log,timeout=300)
  if result.returncode:raise RuntimeError(f'worker {name}: {result.returncode}')
  command=[str(w/'batch_compare'),str(corpus),str(expected),str(directory/'actual'),str(directory/'comparisons.jsonl')]
  compared=subprocess.run(command,capture_output=True,text=True,timeout=120)
  if compared.returncode not in (0,1):raise RuntimeError(compared.stderr[-2000:])
  row=json.loads(compared.stdout);summary['configs'][name]=row
  oracle.write_json(w/'final-correctness-summary.json',summary);print(name,row,flush=True)
  if compared.returncode:raise RuntimeError(f"comparison failed: {name} {row}")
print('DONE',sum(v['total'] for v in summary['configs'].values()),flush=True)
