#include <algorithm>
#include <cstring>
#include "emit.h"

namespace swift::runtime::backend::x64::detail {
Writer::Writer(const Program& s, const Allocation& a, CompileResult& o, CompileOptions c)
        : CodeGenerator(0, DontSetProtectRWE, nullptr, &o.words)
        , source(s)
        , allocation(a)
        , output(o)
        , options(c)
        , guest_pc(c.entry_pc)
        , blocks(s.Blocks().size())
        , locals(s.Operations().size()) {
    scalar_residents.fill(NodeId::invalid);
    vector_residents.fill(NodeId::invalid);
    frame_bytes = a.spill_bytes + (Linked() ? 0 : 24);
    mxcsr_slot = a.spill_bytes;
    output.frame_bytes = frame_bytes + (Linked() ? 0 : 48);
    output.spill_slots = a.spill_bytes / 8;
}

void Writer::Reject(CompileError e) { throw Rejected{e, current, block}; }

void Writer::PublishFlags() {
    if (options.flags_offset != UINT32_MAX) mov(qword[r12 + options.flags_offset], rbx);
}

int Writer::PinnedSlot(std::uint64_t offset, unsigned bytes) const {
    if (!Pinned() || options.pinned_uniform_offset == UINT32_MAX || !bytes) return -1;
    const auto begin = options.pinned_uniform_offset;
    if (offset < begin) return -1;
    const auto relative = offset - begin;
    if (relative >= std::uint64_t{options.pinned_uniform_slots} * 8 ||
        relative + bytes > std::uint64_t{options.pinned_uniform_slots} * 8)
        return -1;
    return static_cast<int>(relative / 8);
}

void Writer::PublishPinned() {
    if (!Pinned()) return;
    for (unsigned i = 0; i < options.pinned_uniform_slots; ++i)
        mov(qword[r12 + options.pinned_uniform_offset + i * 8], Reg64(PinnedRegister(i)));
}

void Writer::ReloadPinned() {
    if (!Pinned()) return;
    for (unsigned i = 0; i < options.pinned_uniform_slots; ++i)
        mov(Reg64(PinnedRegister(i)), qword[r12 + options.pinned_uniform_offset + i * 8]);
}

void Writer::Prologue() {
    if (!Linked()) {
        push(rbx);
        push(rbp);
        push(r12);
        push(r13);
        push(r14);
        push(r15);
        mov(r12, rdi);
    }
    if (frame_bytes) sub(rsp, frame_bytes);
    if (!Linked()) {
        stmxcsr(dword[rsp + mxcsr_slot]);
        if (options.native_fp_environment && options.mxcsr_offset != UINT32_MAX) {
            mov(eax, dword[r12 + options.mxcsr_offset]);
            and_(eax, 0xe040);
            or_(eax, 0x1f80);
            mov(dword[rsp + mxcsr_slot + 4], eax);
            ldmxcsr(dword[rsp + mxcsr_slot + 4]);
        }
        if (options.flags_offset != UINT32_MAX)
            mov(rbx, qword[r12 + options.flags_offset]);
        else
            xor_(ebx, ebx);
    }
}

void Writer::Restore() {
    if (!Linked()) {
        if (options.native_fp_environment && options.mxcsr_offset != UINT32_MAX) {
            stmxcsr(dword[rsp + mxcsr_slot + 4]);
            mov(r11d, dword[rsp + mxcsr_slot + 4]);
            and_(r11d, 63);
            or_(dword[r12 + options.mxcsr_offset], r11d);
        }
        ldmxcsr(dword[rsp + mxcsr_slot]);
    }
    if (frame_bytes) add(rsp, frame_bytes);
    if (!Linked()) {
        pop(r15);
        pop(r14);
        pop(r13);
        pop(r12);
        pop(rbp);
        pop(rbx);
    }
}

void Writer::Exit(u64 reason) {
    PublishFlags();
    const auto kind = static_cast<NativeExit>(reason & 0xff);
    if (reason && kind != NativeExit::GuestException && kind != NativeExit::GuestEvents &&
        kind != NativeExit::SemanticException && options.pc_offset != UINT32_MAX) {
        mov(rax, guest_pc);
        mov(qword[r12 + options.pc_offset], rax);
    }
    Restore();
    mov(rax, reason);
    if (Linked()) {
        HostAddress(r11, options.exit_handler, HostSymbol::Exit);
        jmp(r11);
    } else
        ret();
}

void Writer::StaticExit(u64 pc) {
    PublishFlags();
    mov(rdi, pc);
    if (options.pc_offset != UINT32_MAX) mov(qword[r12 + options.pc_offset], rdi);
    Restore();
    if (!Linked()) {
        xor_(eax, eax);
        ret();
        return;
    }
    align(8);
    backend::LinkSite site;
    site.target_pc = pc;
    site.branch_offset = getSize();
    Label data;
    jmp(ptr[rip + data]);
    nop(2);
    L(data);
    site.data_offset = getSize();
    dq(0);
    dq(0);
    site.fallback_offset = getSize();
    HostAddress(r11, options.dispatcher, HostSymbol::Dispatcher);
    jmp(r11);
    output.links.push_back(site);
}

void Writer::Terminal(const StoredTerminal& t) {
    if (t.kind == TerminalKind::Jump) {
        jmp(blocks[t.first.value], T_NEAR);
        return;
    }
    if (t.kind == TerminalKind::Branch) {
        const auto& h = allocation.homes[t.value.value];
        if (h.terminal_only) {
            const auto& operation = source.Operations()[t.value.value];
            const auto mask = PackedFlagMask(source.Operands(t.value).front().Payload());
            if (mask <= UINT32_MAX)
                test(ebx, static_cast<u32>(mask));
            else {
                mov(rax, mask);
                test(rbx, rax);
            }
            if (operation.opcode == OpCode::TestNotFlags)
                jz(blocks[t.first.value], T_NEAR);
            else
                jnz(blocks[t.first.value], T_NEAR);
            jmp(blocks[t.second.value], T_NEAR);
            return;
        }
        if (h.spilled)
            mov(rax, qword[rsp + h.stack_offset]);
        else
            mov(rax, Reg64(h.reg));
        const auto ty = t.value_type == ir::Type::Void ? source.Operations()[t.value.value].type
                                                       : t.value_type;
        Mask(rax, TypeBits(ty));
        test(rax, rax);
        jnz(blocks[t.first.value], T_NEAR);
        jmp(blocks[t.second.value], T_NEAR);
        return;
    }
    if (t.kind == TerminalKind::Return) {
        if (t.HasValue()) {
            if (source.Operations()[t.value.value].type == ir::Type::V128)
                Reject(CompileError::UnsupportedType);
            const auto& h = allocation.homes[t.value.value];
            if (h.spilled)
                mov(rax, qword[rsp + h.stack_offset]);
            else
                mov(rax, Reg64(h.reg));
            Mask(rax,
                 TypeBits(t.value_type == ir::Type::Void ? source.Operations()[t.value.value].type
                                                         : t.value_type));
        } else
            xor_(eax, eax);
        if (Linked()) {
            PublishFlags();
            Restore();
            HostAddress(r11, options.exit_handler, HostSymbol::Exit);
            jmp(r11);
        } else {
            PublishFlags();
            Restore();
            ret();
        }
        return;
    }
    if (t.kind != TerminalKind::Dispatch) Reject(CompileError::UnsupportedControlFlow);
    if (static_pc_known) {
        StaticExit(static_pc);
        return;
    }
    PublishFlags();
    if (options.pc_offset != UINT32_MAX)
        mov(rdi, qword[r12 + options.pc_offset]);
    else
        xor_(edi, edi);
    Restore();
    if (Linked()) {
        output.has_indirect_dispatch = true;
        HostAddress(r11, options.dispatcher, HostSymbol::Dispatcher);
        jmp(r11);
    } else {
        xor_(eax, eax);
        ret();
    }
}

void Writer::WriteResult(OpContext& c) {
    if (c.saved || c.operation.type == ir::Type::Void) return;
    const auto& h = allocation.homes[c.node.value];
    if (h.terminal_only) return;
    if (c.vector_result) {
        if (h.spilled)
            movdqu(ptr[rsp + h.stack_offset], c.vector);
        else if (c.vector.getIdx() != h.reg)
            movdqa(Xmm(h.reg), c.vector);
        if (!h.spilled) vector_residents[h.reg] = c.node.value;
    } else {
        if (!c.scalar_normalized && c.width == 32 && !h.spilled)
            mov(Reg32(h.reg), c.destination.cvt32());
        else {
            if (!c.scalar_normalized) Mask(c.destination, std::min(64u, c.width));
            if (h.spilled)
                mov(qword[rsp + h.stack_offset], c.destination);
            else if (c.destination.getIdx() != h.reg)
                mov(Reg64(h.reg), c.destination);
        }
        if (!h.spilled) scalar_residents[h.reg] = c.node.value;
    }
}

void Writer::Dispatch(OpContext& c) {
    switch (c.operation.opcode) {
#define INST(name, ...)                                                                            \
    case OpCode::name:                                                                             \
        Handle(Op<OpCode::name>{}, c);                                                             \
        break;
#include "runtime/ir/opcodes.inc"
#undef INST
        default:
            Reject(CompileError::UnsupportedOpcode);
    }
}

void Writer::Run() {
    if (Pinned()) {
        if (!Linked() || options.pinned_uniform_slots != 2 ||
            options.pinned_uniform_offset == UINT32_MAX ||
            options.pinned_uniform_offset > UINT32_MAX - (options.pinned_uniform_slots * 8u - 1))
            Reject(CompileError::UnsupportedOperand);
        const auto bytes = options.pinned_uniform_slots * 8u;
        const auto overlaps = [&](std::uint32_t field) {
            return field != UINT32_MAX &&
                   std::uint64_t{field} < std::uint64_t{options.pinned_uniform_offset} + bytes &&
                   options.pinned_uniform_offset < std::uint64_t{field} + 8;
        };
        if (overlaps(options.pc_offset) || overlaps(options.flags_offset) ||
            overlaps(options.mxcsr_offset))
            Reject(CompileError::UnsupportedOperand);
    }
    Prologue();
    std::vector<std::pair<unsigned, unsigned>> extra;
    for (auto b : allocation.block_order) {
        block = BlockId{b};
        L(blocks[b]);
        static_pc_known = false;
        has_fault_location = false;
        terminated = false;
        const auto& body = source.Blocks()[b];
        for (u32 i = body.first_node; i < body.first_node + body.node_count; ++i) {
            current = NodeId{i};
            const auto& op = source.Operations()[i];
            if (op.opcode == OpCode::FaultLocation) {
                guest_pc = source.Operands(current).front().Payload();
                has_fault_location = true;
                continue;
            }
            if (op.opcode == OpCode::EntryPoint) {
                if (!Linked()) Reject(CompileError::UnsupportedControlFlow);
                const auto entry_pc = source.Operands(current).front().Payload();
                if (entry_pc == options.entry_pc) continue;
                output.entries.push_back({entry_pc, 0});
                extra.push_back({unsigned(output.entries.size() - 1), b});
                continue;
            }
            OpContext c{op, current, source.Operands(current)};
            for (auto cell : c.operands) {
                if (c.count < c.args.size()) c.args[c.count] = cell;
                ++c.count;
            }
            c.width = TypeBits(op.type);
            c.vector_result = op.type == ir::Type::V128;
            c.destination = rax;
            c.vector = xmm0;
            fault_committed_flags = false;
            if (allocation.homes[i].terminal_only) continue;
            Dispatch(c);
            WriteResult(c);
            if (op.flag_outputs && op.opcode != OpCode::Add && op.opcode != OpCode::Sub &&
                op.opcode != OpCode::Adc && op.opcode != OpCode::Sbb && op.opcode != OpCode::Neg &&
                op.opcode != OpCode::And && op.opcode != OpCode::Or && op.opcode != OpCode::Xor &&
                op.opcode != OpCode::AndNot && op.opcode != OpCode::Not)
                Reject(CompileError::UnsupportedFlags);
        }
        if (!terminated) Terminal(body.terminal);
    }
    for (auto [index, b] : extra) {
        align(16);
        output.entries[index].offset = getSize();
        Prologue();
        jmp(blocks[b], T_NEAR);
    }
    while (getSize() & 3) db(0x90);
    ready(PROTECT_RW);
}
}  // namespace swift::runtime::backend::x64::detail
