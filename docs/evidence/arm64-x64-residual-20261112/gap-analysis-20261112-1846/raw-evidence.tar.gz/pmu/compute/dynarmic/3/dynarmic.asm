00007871bd3ce69b  nop [rax+rax*1], eax
00007871bd3ce6a0  mov rax, [r15+0xF8]
00007871bd3ce6a7  lea r14, [rax-0x1E0]
00007871bd3ce6ae  mov [r15+0xF8], r14
00007871bd3ce6b5  lea rax, [r14+0x1D0]
00007871bd3ce6bc  mov r12, [r15+0xA0]
00007871bd3ce6c3  mov r11, [r15+0x98]
00007871bd3ce6ca  mov [r13+rax*1], r12
00007871bd3ce6cf  lea rax, [r14+0x1D8]
00007871bd3ce6d6  mov [r13+rax*1], r11
00007871bd3ce6db  mov eax, 0x420AA0
00007871bd3ce6e0  movups xmm1, [r13+rax*1]
00007871bd3ce6e6  mov eax, 0x420A30
00007871bd3ce6eb  movups xmm15, [r13+rax*1]
00007871bd3ce6f1  mov eax, 0x420AC0
00007871bd3ce6f6  movups xmm14, [r13+rax*1]
00007871bd3ce6fc  mov eax, 0x420A60
00007871bd3ce701  movups xmm13, [r13+rax*1]
00007871bd3ce707  mov qword ptr [r15+0x98], 0x430CD0
00007871bd3ce712  mov eax, 0x420AD0
00007871bd3ce717  movups xmm12, [r13+rax*1]
00007871bd3ce71d  mov eax, 0x430CD0
00007871bd3ce722  movups [r13+rax*1], xmm1
00007871bd3ce728  mov eax, 0x430CE0
00007871bd3ce72d  movups [r13+rax*1], xmm15
00007871bd3ce733  mov eax, 0x430CF0
00007871bd3ce738  movups [r13+rax*1], xmm14
00007871bd3ce73e  mov eax, 0x430D00
00007871bd3ce743  movups [r13+rax*1], xmm13
00007871bd3ce749  mov eax, 0x420A20
00007871bd3ce74e  movups xmm14, [r13+rax*1]
00007871bd3ce754  mov eax, 0x420A10
00007871bd3ce759  movups xmm13, [r13+rax*1]
00007871bd3ce75f  mov eax, 0x430DD0
00007871bd3ce764  movups [r13+rax*1], xmm1
00007871bd3ce76a  mov eax, 0x430DE0
00007871bd3ce76f  movups [r13+rax*1], xmm15
00007871bd3ce775  mov eax, 0x430D10
00007871bd3ce77a  movups [r13+rax*1], xmm12
00007871bd3ce780  mov eax, 0x430D20
00007871bd3ce785  movups [r13+rax*1], xmm14
00007871bd3ce78b  mov eax, 0x420A00
00007871bd3ce790  movups xmm1, [r13+rax*1]
00007871bd3ce796  mov eax, 0x420A70
00007871bd3ce79b  movups xmm15, [r13+rax*1]
00007871bd3ce7a1  mov eax, 0x430D30
00007871bd3ce7a6  movups [r13+rax*1], xmm13
00007871bd3ce7ac  mov eax, 0x430D40
00007871bd3ce7b1  movups [r13+rax*1], xmm1
00007871bd3ce7b7  mov eax, 0x420A80
00007871bd3ce7bc  movups xmm1, [r13+rax*1]
00007871bd3ce7c2  mov eax, 0x420A50
00007871bd3ce7c7  movups xmm14, [r13+rax*1]
00007871bd3ce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
00007871bd3ce7d5  mov eax, 0x430D50
00007871bd3ce7da  movups [r13+rax*1], xmm15
00007871bd3ce7e0  mov eax, 0x430D60
00007871bd3ce7e5  movups [r13+rax*1], xmm1
00007871bd3ce7eb  mov eax, 0x420AF0
00007871bd3ce7f0  movups xmm1, [r13+rax*1]
00007871bd3ce7f6  mov eax, 0x420B00
00007871bd3ce7fb  movups xmm15, [r13+rax*1]
00007871bd3ce801  movaps [r15+0x150], xmm15
00007871bd3ce809  mov qword ptr [r15+0xA0], 0x3E8
00007871bd3ce814  mov eax, 0x430D70
00007871bd3ce819  movups [r13+rax*1], xmm14
00007871bd3ce81f  mov eax, 0x430D80
00007871bd3ce824  movups [r13+rax*1], xmm1
00007871bd3ce82a  mov eax, 0x420AE0
00007871bd3ce82f  movups xmm1, [r13+rax*1]
00007871bd3ce835  mov eax, 0x420A90
00007871bd3ce83a  movups xmm14, [r13+rax*1]
00007871bd3ce840  movaps [r15+0x140], xmm14
00007871bd3ce848  lea rax, [r14+0x180]
00007871bd3ce84f  movq xmm13, qword ptr [r15+0x200]
00007871bd3ce858  movq xmm12, qword ptr [r15+0x1F0]
00007871bd3ce861  movq r12, xmm13
00007871bd3ce866  movq r11, xmm12
00007871bd3ce86b  mov [r13+rax*1], r12
00007871bd3ce870  lea rax, [r14+0x188]
00007871bd3ce877  mov [r13+rax*1], r11
00007871bd3ce87c  mov eax, 0x430D90
00007871bd3ce881  movups [r13+rax*1], xmm15
00007871bd3ce887  mov eax, 0x430DA0
00007871bd3ce88c  movups [r13+rax*1], xmm1
00007871bd3ce892  mov eax, 0x420AB0
00007871bd3ce897  movups xmm1, [r13+rax*1]
00007871bd3ce89d  mov eax, 0x420B18
00007871bd3ce8a2  mov r12, [r13+rax*1]
00007871bd3ce8a7  movq xmm15, r12
00007871bd3ce8ac  mov qword ptr [r15+0x40], 0x420B20
00007871bd3ce8b4  mov eax, 0x430DB0
00007871bd3ce8b9  movups [r13+rax*1], xmm14
00007871bd3ce8bf  mov eax, 0x430DC0
00007871bd3ce8c4  movups [r13+rax*1], xmm1
00007871bd3ce8ca  mov eax, 0x420B80
00007871bd3ce8cf  movups xmm1, [r13+rax*1]
00007871bd3ce8d5  movq rax, xmm15
00007871bd3ce8da  mov r12d, 0x430DF0
00007871bd3ce8e0  mov [r13+r12*1], rax
00007871bd3ce8e5  mov eax, 0x420B60
00007871bd3ce8ea  movups xmm15, [r13+rax*1]
00007871bd3ce8f0  mov eax, 0x420B70
00007871bd3ce8f5  movups xmm14, [r13+rax*1]
00007871bd3ce8fb  lea rax, [r14+0x160]
00007871bd3ce902  movups [r13+rax*1], xmm1
00007871bd3ce908  lea rax, [r14+0x190]
00007871bd3ce90f  movq xmm1, qword ptr [r15+0x1E0]
00007871bd3ce918  movq xmm13, qword ptr [r15+0x1D0]
00007871bd3ce921  movq r12, xmm1
00007871bd3ce926  movq r11, xmm13
00007871bd3ce92b  mov [r13+rax*1], r12
00007871bd3ce930  lea rax, [r14+0x198]
00007871bd3ce937  mov [r13+rax*1], r11
00007871bd3ce93c  lea rax, [r14+0x140]
00007871bd3ce943  movups [r13+rax*1], xmm15
00007871bd3ce949  lea rax, [r14+0x150]
00007871bd3ce950  movups [r13+rax*1], xmm14
00007871bd3ce956  mov eax, 0x420B20
00007871bd3ce95b  movups xmm1, [r13+rax*1]
00007871bd3ce961  mov eax, 0x420B30
00007871bd3ce966  movups xmm15, [r13+rax*1]
00007871bd3ce96c  movaps [r15+0x120], xmm15
00007871bd3ce974  lea rax, [r14+0x1A0]
00007871bd3ce97b  movq xmm14, qword ptr [r15+0x1C0]
00007871bd3ce984  movq xmm13, qword ptr [r15+0x1B0]
00007871bd3ce98d  movq r12, xmm14
00007871bd3ce992  movq r11, xmm13
00007871bd3ce997  mov [r13+rax*1], r12
00007871bd3ce99c  lea rax, [r14+0x1A8]
00007871bd3ce9a3  mov [r13+rax*1], r11
00007871bd3ce9a8  lea rax, [r14+0x1B0]
00007871bd3ce9af  movq xmm14, qword ptr [r15+0x1A0]
00007871bd3ce9b8  movq xmm13, qword ptr [r15+0x190]
00007871bd3ce9c1  movq r12, xmm14
00007871bd3ce9c6  movq r11, xmm13
00007871bd3ce9cb  mov [r13+rax*1], r12
00007871bd3ce9d0  lea rax, [r14+0x1B8]
00007871bd3ce9d7  mov [r13+rax*1], r11
00007871bd3ce9dc  lea rax, [r14+0x100]
00007871bd3ce9e3  movups [r13+rax*1], xmm1
00007871bd3ce9e9  lea rax, [r14+0x110]
00007871bd3ce9f0  movups [r13+rax*1], xmm15
00007871bd3ce9f6  mov eax, 0x420B40
00007871bd3ce9fb  movups xmm1, [r13+rax*1]
00007871bd3cea01  mov eax, 0x420B50
00007871bd3cea06  movups xmm15, [r13+rax*1]
00007871bd3cea0c  movaps [r15+0x110], xmm1
00007871bd3cea14  movaps [r15+0x130], xmm15
00007871bd3cea1c  lea rax, [r14+0x1C0]
00007871bd3cea23  mov r12, [r15+0xE8]
00007871bd3cea2a  mov r11, [r15+0xF0]
00007871bd3cea31  mov [r13+rax*1], r12
00007871bd3cea36  lea rax, [r14+0x1C8]
00007871bd3cea3d  mov [r13+rax*1], r11
00007871bd3cea42  mov eax, 0x430DF8
00007871bd3cea47  mov r12d, 0x421DF8D3
00007871bd3cea4d  mov [r13+rax*1], r12d
00007871bd3cea52  lea rax, [r14+0x120]
00007871bd3cea59  movups [r13+rax*1], xmm1
00007871bd3cea5f  lea rax, [r14+0x130]
00007871bd3cea66  movups [r13+rax*1], xmm15
00007871bd3cea6c  lea rax, [r14+0x100]
00007871bd3cea73  mov [r15], rax
00007871bd3cea76  mov qword ptr [r15+0x08], 0x430CD0
00007871bd3cea7e  mov qword ptr [r15+0x10], 0x12C
00007871bd3cea86  mov qword ptr [r15+0xF0], 0x410284
00007871bd3cea91  mov r14d, [r15+0x320]
00007871bd3cea98  mov eax, 0x410284
00007871bd3cea9d  mov rcx, 0x7871BD3D07C0
00007871bd3ceaa7  mov [r15+r14*8+0x328], rax
00007871bd3ceaaf  mov [r15+r14*8+0x368], rcx
00007871bd3ceab7  add r14d, 0x01
00007871bd3ceabb  and r14d, 0x07
00007871bd3ceabf  mov [r15+0x320], r14d
00007871bd3ceac6  cmp dword ptr [r15+0x318], 0x00
00007871bd3ceace  jz 0x00007871BD3CED70
00007871bd3cead4  nop [rax+rax*1], ax
00007871bd3ceadd  nop [rax+rax*1], eax
00007871bd3ceae5  mov eax, 0x410728
00007871bd3ceaea  mov [r15+0x100], rax
00007871bd3ceaf1  jmp 0x00007871BD1FE110
00007871bd3ceaf6  int3
00007871bd3ceaf7  call 0x00007871BD20BC20
00007871bd3ceafc  jmp 0x00007871BD3CE6CF
00007871bd3ceb01  call 0x00007871BD20A9A0
00007871bd3ceb06  jmp 0x00007871BD3CE6DB
00007871bd3ceb0b  call 0x00007871BD1FF430
00007871bd3ceb10  jmp 0x00007871BD3CE6E6
00007871bd3ceb15  call 0x00007871BD20E760
00007871bd3ceb1a  jmp 0x00007871BD3CE6F1
00007871bd3ceb1f  call 0x00007871BD20D4E0
00007871bd3ceb24  jmp 0x00007871BD3CE6FC
00007871bd3ceb29  call 0x00007871BD20C260
00007871bd3ceb2e  jmp 0x00007871BD3CE707
00007871bd3ceb33  call 0x00007871BD20AFE0
00007871bd3ceb38  jmp 0x00007871BD3CE71D
00007871bd3ceb3d  call 0x00007871BD1FF540
00007871bd3ceb42  jmp 0x00007871BD3CE728
00007871bd3ceb47  call 0x00007871BD20E880
00007871bd3ceb4c  jmp 0x00007871BD3CE733
00007871bd3ceb51  call 0x00007871BD20D600
00007871bd3ceb56  jmp 0x00007871BD3CE73E
00007871bd3ceb5b  call 0x00007871BD20C380
00007871bd3ceb60  jmp 0x00007871BD3CE749
00007871bd3ceb65  call 0x00007871BD20D4E0
00007871bd3ceb6a  jmp 0x00007871BD3CE754
00007871bd3ceb6f  call 0x00007871BD20C260
00007871bd3ceb74  jmp 0x00007871BD3CE75F
00007871bd3ceb79  call 0x00007871BD1FF540
00007871bd3ceb7e  jmp 0x00007871BD3CE76A
00007871bd3ceb83  call 0x00007871BD20E880
00007871bd3ceb88  jmp 0x00007871BD3CE775
00007871bd3ceb8d  call 0x00007871BD20B100
00007871bd3ceb92  jmp 0x00007871BD3CE780
00007871bd3ceb97  call 0x00007871BD20D600
00007871bd3ceb9c  jmp 0x00007871BD3CE78B
00007871bd3ceba1  call 0x00007871BD1FF430
00007871bd3ceba6  jmp 0x00007871BD3CE796
00007871bd3cebab  call 0x00007871BD20E760
00007871bd3cebb0  jmp 0x00007871BD3CE7A1
00007871bd3cebb5  call 0x00007871BD20C380
00007871bd3cebba  jmp 0x00007871BD3CE7AC
00007871bd3cebbf  call 0x00007871BD1FF540
00007871bd3cebc4  jmp 0x00007871BD3CE7B7
00007871bd3cebc9  call 0x00007871BD1FF430
00007871bd3cebce  jmp 0x00007871BD3CE7C2
00007871bd3cebd3  call 0x00007871BD20D4E0
00007871bd3cebd8  jmp 0x00007871BD3CE7CD
00007871bd3cebdd  call 0x00007871BD20E880
00007871bd3cebe2  jmp 0x00007871BD3CE7E0
00007871bd3cebe7  call 0x00007871BD1FF540
00007871bd3cebec  jmp 0x00007871BD3CE7EB
00007871bd3cebf1  call 0x00007871BD1FF430
00007871bd3cebf6  jmp 0x00007871BD3CE7F6
00007871bd3cebfb  call 0x00007871BD20E760
00007871bd3cec00  jmp 0x00007871BD3CE801
00007871bd3cec05  call 0x00007871BD20D600
00007871bd3cec0a  jmp 0x00007871BD3CE81F
00007871bd3cec0f  call 0x00007871BD1FF540
00007871bd3cec14  jmp 0x00007871BD3CE82A
00007871bd3cec19  call 0x00007871BD1FF430
00007871bd3cec1e  jmp 0x00007871BD3CE835
00007871bd3cec23  call 0x00007871BD20D4E0
00007871bd3cec28  jmp 0x00007871BD3CE840
00007871bd3cec2d  call 0x00007871BD20BC20
00007871bd3cec32  jmp 0x00007871BD3CE870
00007871bd3cec37  call 0x00007871BD20A9A0
00007871bd3cec3c  jmp 0x00007871BD3CE87C
00007871bd3cec41  call 0x00007871BD20E880
00007871bd3cec46  jmp 0x00007871BD3CE887
00007871bd3cec4b  call 0x00007871BD1FF540
00007871bd3cec50  jmp 0x00007871BD3CE892
00007871bd3cec55  call 0x00007871BD1FF430
00007871bd3cec5a  jmp 0x00007871BD3CE89D
00007871bd3cec5f  call 0x00007871BD20B720
00007871bd3cec64  jmp 0x00007871BD3CE8A7
00007871bd3cec69  call 0x00007871BD20D600
00007871bd3cec6e  jmp 0x00007871BD3CE8BF
00007871bd3cec73  call 0x00007871BD1FF540
00007871bd3cec78  jmp 0x00007871BD3CE8CA
00007871bd3cec7d  call 0x00007871BD1FF430
00007871bd3cec82  jmp 0x00007871BD3CE8D5
00007871bd3cec87  call 0x00007871BD2B4CB0
00007871bd3cec8c  jmp 0x00007871BD3CE8E5
00007871bd3cec91  call 0x00007871BD20E760
00007871bd3cec96  jmp 0x00007871BD3CE8F0
00007871bd3cec9b  call 0x00007871BD20D4E0
00007871bd3ceca0  jmp 0x00007871BD3CE8FB
00007871bd3ceca5  call 0x00007871BD1FF540
00007871bd3cecaa  jmp 0x00007871BD3CE908
00007871bd3cecaf  call 0x00007871BD20BC20
00007871bd3cecb4  jmp 0x00007871BD3CE930
00007871bd3cecb9  call 0x00007871BD20A9A0
00007871bd3cecbe  jmp 0x00007871BD3CE93C
00007871bd3cecc3  call 0x00007871BD20E880
00007871bd3cecc8  jmp 0x00007871BD3CE949
00007871bd3ceccd  call 0x00007871BD20D600
00007871bd3cecd2  jmp 0x00007871BD3CE956
00007871bd3cecd7  call 0x00007871BD1FF430
00007871bd3cecdc  jmp 0x00007871BD3CE961
00007871bd3cece1  call 0x00007871BD20E760
00007871bd3cece6  jmp 0x00007871BD3CE96C
00007871bd3ceceb  call 0x00007871BD20BC20
00007871bd3cecf0  jmp 0x00007871BD3CE99C
00007871bd3cecf5  call 0x00007871BD20A9A0
00007871bd3cecfa  jmp 0x00007871BD3CE9A8
00007871bd3cecff  call 0x00007871BD20BC20
00007871bd3ced04  jmp 0x00007871BD3CE9D0
00007871bd3ced09  call 0x00007871BD20A9A0
00007871bd3ced0e  jmp 0x00007871BD3CE9DC
00007871bd3ced13  call 0x00007871BD1FF540
00007871bd3ced18  jmp 0x00007871BD3CE9E9
00007871bd3ced1d  call 0x00007871BD20E880
00007871bd3ced22  jmp 0x00007871BD3CE9F6
00007871bd3ced27  call 0x00007871BD1FF430
00007871bd3ced2c  jmp 0x00007871BD3CEA01
00007871bd3ced31  call 0x00007871BD20E760
00007871bd3ced36  jmp 0x00007871BD3CEA0C
00007871bd3ced3b  call 0x00007871BD20BC20
00007871bd3ced40  jmp 0x00007871BD3CEA36
00007871bd3ced45  call 0x00007871BD20A9A0
00007871bd3ced4a  jmp 0x00007871BD3CEA42
00007871bd3ced4f  call 0x00007871BD20BAE0
00007871bd3ced54  jmp 0x00007871BD3CEA52
00007871bd3ced59  call 0x00007871BD1FF540
00007871bd3ced5e  jmp 0x00007871BD3CEA5F
00007871bd3ced63  call 0x00007871BD20E880
00007871bd3ced68  jmp 0x00007871BD3CEA6C
00007871bd3ced6d  int3
00007871bd3ced6e  nop
00007871bd3ced70  mov rax, [r15]
00007871bd3ced73  lea r14, [rax+0x20]
00007871bd3ced77  mov r12, [r13+r14*1]
00007871bd3ced7c  mov r14, [r15+0x10]
00007871bd3ced80  lea r11, [r12+r14*1]
00007871bd3ced84  mov [r15+0x40], r11
00007871bd3ced88  lea r12, [rax+0x20]
00007871bd3ced8c  mov [r13+r12*1], r11
00007871bd3ced91  test r14, r14
00007871bd3ced94  setz r14b
00007871bd3ced98  movzx r14, r14b
00007871bd3ced9c  mov [rsp+0x414], r14b
00007871bd3ceda4  cmp byte ptr [rsp+0x414], 0x00
00007871bd3cedac  jz 0x00007871BD3CEDDE
00007871bd3cedae  cmp dword ptr [r15+0x318], 0x00
00007871bd3cedb6  mov eax, 0x4109A0
00007871bd3cedbb  mov [r15+0x100], rax
00007871bd3cedc2  jz 0x00007871BD1FE0A0
00007871bd3cedc8  nop [rax+rax*1], eax
00007871bd3cedcd  mov eax, 0x4109A0
00007871bd3cedd2  mov [r15+0x100], rax
00007871bd3cedd9  jmp 0x00007871BD1FE110
00007871bd3cedde  cmp dword ptr [r15+0x318], 0x00
00007871bd3cede6  jz 0x00007871BD3CEE30
00007871bd3cedec  nop [rax+rax*1], ax
00007871bd3cedf5  nop [rax+rax*1], eax
00007871bd3cedfd  mov eax, 0x410738
00007871bd3cee02  mov [r15+0x100], rax
00007871bd3cee09  jmp 0x00007871BD1FE110
00007871bd3cee0e  int3
00007871bd3cee0f  call 0x00007871BD2E27E0
00007871bd3cee14  jmp 0x00007871BD3CED7C
00007871bd3cee19  call 0x00007871BD2C0860
00007871bd3cee1e  jmp 0x00007871BD3CED91
00007871bd3cee23  int3
00007871bd3cee24  nop [rax+rax*1], ax
00007871bd3cee2d  nop [rax], eax
00007871bd3cee30  mov rax, [r15+0xF8]
00007871bd3cee37  lea r14, [rax-0x150]
00007871bd3cee3e  mov [r15+0xF8], r14
00007871bd3cee45  mov rax, [r15]
00007871bd3cee48  lea r12, [rax+0x68]
00007871bd3cee4c  mov r11, [r13+r12*1]
00007871bd3cee51  mov [r15+0x88], r11
00007871bd3cee58  lea r12, [rax+0x28]
00007871bd3cee5c  mov [r15+0x40], r12
00007871bd3cee60  mov [r15+0x48], r14
00007871bd3cee64  mov qword ptr [r15+0x50], 0x420B90
00007871bd3cee6c  lea rax, [r14+0x100]
00007871bd3cee73  mov r12, [r15+0xE8]
00007871bd3cee7a  mov r11, [r15+0xD8]
00007871bd3cee81  mov [r13+rax*1], r12
00007871bd3cee86  lea rax, [r14+0x108]
00007871bd3cee8d  mov [r13+rax*1], r11
00007871bd3cee92  lea rax, [r14+0x110]
00007871bd3cee99  mov r12, [r15+0xD0]
00007871bd3ceea0  mov r11, [r15+0xC8]
00007871bd3ceea7  mov [r13+rax*1], r12
00007871bd3ceeac  lea rax, [r14+0x118]
00007871bd3ceeb3  mov [r13+rax*1], r11
00007871bd3ceeb8  lea rax, [r14+0x120]
00007871bd3ceebf  mov r12, [r15+0xC0]
00007871bd3ceec6  mov r11, [r15+0xB8]
00007871bd3ceecd  mov [r13+rax*1], r12
00007871bd3ceed2  lea rax, [r14+0x128]
00007871bd3ceed9  mov [r13+rax*1], r11
00007871bd3ceede  lea rax, [r14+0x130]
00007871bd3ceee5  mov r12, [r15+0xB0]
00007871bd3ceeec  mov r11, [r15+0xA8]
00007871bd3ceef3  mov [r13+rax*1], r12
00007871bd3ceef8  lea rax, [r14+0x138]
00007871bd3ceeff  mov [r13+rax*1], r11
00007871bd3cef04  lea rax, [r14+0x140]
00007871bd3cef0b  mov r12, [r15+0xA0]
00007871bd3cef12  mov r11, [r15+0x98]
00007871bd3cef19  mov [r13+rax*1], r12
00007871bd3cef1e  lea rax, [r14+0x148]
00007871bd3cef25  mov [r13+rax*1], r11
00007871bd3cef2a  cmp dword ptr [r15+0x318], 0x00
00007871bd3cef32  jz 0x00007871BD3CEFD0
00007871bd3cef38  nop [rax+rax*1], ax
00007871bd3cef41  nop [rax+rax*1], eax
00007871bd3cef49  mov eax, 0x410770
00007871bd3cef4e  mov [r15+0x100], rax
00007871bd3cef55  jmp 0x00007871BD1FE110
00007871bd3cef5a  int3
00007871bd3cef5b  call 0x00007871BD2C0370
00007871bd3cef60  jmp 0x00007871BD3CEE51
00007871bd3cef65  call 0x00007871BD20BC20
00007871bd3cef6a  jmp 0x00007871BD3CEE86
00007871bd3cef6f  call 0x00007871BD20A9A0
00007871bd3cef74  jmp 0x00007871BD3CEE92
00007871bd3cef79  call 0x00007871BD20BC20
00007871bd3cef7e  jmp 0x00007871BD3CEEAC
00007871bd3cef83  call 0x00007871BD20A9A0
00007871bd3cef88  jmp 0x00007871BD3CEEB8
00007871bd3cef8d  call 0x00007871BD20BC20
00007871bd3cef92  jmp 0x00007871BD3CEED2
00007871bd3cef97  call 0x00007871BD20A9A0
00007871bd3cef9c  jmp 0x00007871BD3CEEDE
00007871bd3cefa1  call 0x00007871BD20BC20
00007871bd3cefa6  jmp 0x00007871BD3CEEF8
00007871bd3cefab  call 0x00007871BD20A9A0
00007871bd3cefb0  jmp 0x00007871BD3CEF04
00007871bd3cefb5  call 0x00007871BD20BC20
00007871bd3cefba  jmp 0x00007871BD3CEF1E
00007871bd3cefbf  call 0x00007871BD20A9A0
00007871bd3cefc4  jmp 0x00007871BD3CEF2A
00007871bd3cefc9  int3
00007871bd3cefca  nop [rax+rax*1], ax
00007871bd3cefd0  mov rax, [r15+0x08]
00007871bd3cefd4  movzx r14d, byte ptr [r13+rax*1]
00007871bd3cefda  movzx r14d, r14b
00007871bd3cefde  mov [rsp+0x10], r14d
00007871bd3cefe3  mov r14d, r14d
00007871bd3cefe6  mov [r15+0x58], r14
00007871bd3cefea  lea r14, [rax+0x01]
00007871bd3cefee  mov [r15+0x08], r14
00007871bd3ceff2  mov rax, [r15+0x88]
00007871bd3ceff9  lea r14, [rax+0x01]
00007871bd3ceffd  mov r12, [r15]
00007871bd3cf000  lea r11, [r12+0x68]
00007871bd3cf005  mov [r13+r11*1], r14
00007871bd3cf00a  lea r14, [r12+rax*1]
00007871bd3cf00e  mov [r15+0x60], r14
00007871bd3cf012  lea rax, [r14+0x28]
00007871bd3cf016  mov r11d, [rsp+0x10]
00007871bd3cf01b  movzx r14d, r11b
00007871bd3cf01f  mov [r13+rax*1], r14b
00007871bd3cf024  lea rax, [r12+0x68]
00007871bd3cf029  mov r14, [r13+rax*1]
00007871bd3cf02e  mov [r15+0x88], r14
00007871bd3cf035  xor eax, eax
00007871bd3cf037  mov r12d, 0x40
00007871bd3cf03d  cmp r14, r12
00007871bd3cf040  cmc
00007871bd3cf041  lahf
00007871bd3cf042  seto al
00007871bd3cf045  mov [r15+0x108], eax
00007871bd3cf04c  mov eax, [r15+0x108]
00007871bd3cf053  sahf
00007871bd3cf054  jnz 0x00007871BD3CF086
00007871bd3cf056  cmp dword ptr [r15+0x318], 0x00
00007871bd3cf05e  jz 0x00007871BD3CF170
00007871bd3cf064  nop [rax+rax*1], ax
00007871bd3cf06d  nop [rax+rax*1], eax
00007871bd3cf075  mov eax, 0x410790
00007871bd3cf07a  mov [r15+0x100], rax
00007871bd3cf081  jmp 0x00007871BD1FE110
00007871bd3cf086  cmp dword ptr [r15+0x318], 0x00
00007871bd3cf08e  jz 0x00007871BD3CF0E0
00007871bd3cf094  nop [rax+rax*1], ax
00007871bd3cf09d  nop [rax+rax*1], eax
00007871bd3cf0a5  mov eax, 0x410768
00007871bd3cf0aa  mov [r15+0x100], rax
00007871bd3cf0b1  jmp 0x00007871BD1FE110
00007871bd3cf0b6  int3
00007871bd3cf0b7  call 0x00007871BD20D860
00007871bd3cf0bc  jmp 0x00007871BD3CEFDA
00007871bd3cf0c1  call 0x00007871BD2B36E0
00007871bd3cf0c6  jmp 0x00007871BD3CF00A
00007871bd3cf0cb  call 0x00007871BD20DD60
00007871bd3cf0d0  jmp 0x00007871BD3CF024
00007871bd3cf0d5  call 0x00007871BD20DC20
00007871bd3cf0da  jmp 0x00007871BD3CF02E
00007871bd3cf0df  int3
00007871bd3cf0e0  mov rax, [r15+0x10]
00007871bd3cf0e4  lea r14, [rax-0x01]
00007871bd3cf0e8  mov [r15+0x10], r14
00007871bd3cf0ec  test r14, r14
00007871bd3cf0ef  setz r14b
00007871bd3cf0f3  movzx r14, r14b
00007871bd3cf0f7  mov [rsp+0x414], r14b
00007871bd3cf0ff  cmp byte ptr [rsp+0x414], 0x00
00007871bd3cf107  jz 0x00007871BD3CF139
00007871bd3cf109  cmp dword ptr [r15+0x318], 0x00
00007871bd3cf111  jz 0x00007871BD3D0670
00007871bd3cf117  nop [rax+rax*1], ax
00007871bd3cf120  nop [rax+rax*1], eax
00007871bd3cf128  mov eax, 0x410988
00007871bd3cf12d  mov [r15+0x100], rax
00007871bd3cf134  jmp 0x00007871BD1FE110
00007871bd3cf139  cmp dword ptr [r15+0x318], 0x00
00007871bd3cf141  jz 0x00007871BD3CEFD0
00007871bd3cf147  nop [rax+rax*1], ax
00007871bd3cf150  nop [rax+rax*1], eax
00007871bd3cf158  mov eax, 0x410770
00007871bd3cf15d  mov [r15+0x100], rax
00007871bd3cf164  jmp 0x00007871BD1FE110
00007871bd3cf169  int3
00007871bd3cf16a  int3
00007871bd3cf16b  nop [rax+rax*1], eax
00007871bd3cf170  mov rax, [r15+0x40]
00007871bd3cf174  movzx r14d, byte ptr [r13+rax*1]
00007871bd3cf17a  movaps xmm1, [r15+0x110]
00007871bd3cf182  pinsrb xmm1, r14d, 0x00
00007871bd3cf189  lea r14, [rax+0x01]
00007871bd3cf18d  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf193  movaps xmm15, [r15+0x120]
00007871bd3cf19b  pinsrb xmm15, r12d, 0x00
00007871bd3cf1a2  lea r14, [rax+0x02]
00007871bd3cf1a6  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf1ac  movaps xmm14, [r15+0x130]
00007871bd3cf1b4  pinsrb xmm14, r12d, 0x00
00007871bd3cf1bb  lea r14, [rax+0x03]
00007871bd3cf1bf  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf1c5  movaps xmm13, [r15+0x140]
00007871bd3cf1cd  pinsrb xmm13, r12d, 0x00
00007871bd3cf1d4  lea r14, [rax+0x04]
00007871bd3cf1d8  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf1de  pinsrb xmm1, r12d, 0x01
00007871bd3cf1e5  lea r14, [rax+0x05]
00007871bd3cf1e9  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf1ef  pinsrb xmm15, r12d, 0x01
00007871bd3cf1f6  lea r14, [rax+0x06]
00007871bd3cf1fa  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf200  pinsrb xmm14, r12d, 0x01
00007871bd3cf207  lea r14, [rax+0x07]
00007871bd3cf20b  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf211  pinsrb xmm13, r12d, 0x01
00007871bd3cf218  lea r14, [rax+0x08]
00007871bd3cf21c  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf222  pinsrb xmm1, r12d, 0x02
00007871bd3cf229  lea r14, [rax+0x09]
00007871bd3cf22d  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf233  pinsrb xmm15, r12d, 0x02
00007871bd3cf23a  lea r14, [rax+0x0A]
00007871bd3cf23e  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf244  pinsrb xmm14, r12d, 0x02
00007871bd3cf24b  lea r14, [rax+0x0B]
00007871bd3cf24f  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf255  pinsrb xmm13, r12d, 0x02
00007871bd3cf25c  lea r14, [rax+0x0C]
00007871bd3cf260  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf266  pinsrb xmm1, r12d, 0x03
00007871bd3cf26d  lea r14, [rax+0x0D]
00007871bd3cf271  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf277  pinsrb xmm15, r12d, 0x03
00007871bd3cf27e  lea r14, [rax+0x0E]
00007871bd3cf282  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf288  pinsrb xmm14, r12d, 0x03
00007871bd3cf28f  lea r14, [rax+0x0F]
00007871bd3cf293  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf299  pinsrb xmm13, r12d, 0x03
00007871bd3cf2a0  lea r14, [rax+0x10]
00007871bd3cf2a4  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf2aa  pinsrb xmm1, r12d, 0x04
00007871bd3cf2b1  lea r14, [rax+0x11]
00007871bd3cf2b5  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf2bb  pinsrb xmm15, r12d, 0x04
00007871bd3cf2c2  lea r14, [rax+0x12]
00007871bd3cf2c6  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf2cc  pinsrb xmm14, r12d, 0x04
00007871bd3cf2d3  lea r14, [rax+0x13]
00007871bd3cf2d7  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf2dd  pinsrb xmm13, r12d, 0x04
00007871bd3cf2e4  lea r14, [rax+0x14]
00007871bd3cf2e8  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf2ee  pinsrb xmm1, r12d, 0x05
00007871bd3cf2f5  lea r14, [rax+0x15]
00007871bd3cf2f9  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf2ff  pinsrb xmm15, r12d, 0x05
00007871bd3cf306  lea r14, [rax+0x16]
00007871bd3cf30a  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf310  pinsrb xmm14, r12d, 0x05
00007871bd3cf317  lea r14, [rax+0x17]
00007871bd3cf31b  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf321  pinsrb xmm13, r12d, 0x05
00007871bd3cf328  lea r14, [rax+0x18]
00007871bd3cf32c  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf332  pinsrb xmm1, r12d, 0x06
00007871bd3cf339  lea r14, [rax+0x19]
00007871bd3cf33d  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf343  pinsrb xmm15, r12d, 0x06
00007871bd3cf34a  lea r14, [rax+0x1A]
00007871bd3cf34e  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf354  pinsrb xmm14, r12d, 0x06
00007871bd3cf35b  lea r14, [rax+0x1B]
00007871bd3cf35f  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf365  pinsrb xmm13, r12d, 0x06
00007871bd3cf36c  lea r14, [rax+0x1C]
00007871bd3cf370  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf376  pinsrb xmm1, r12d, 0x07
00007871bd3cf37d  lea r14, [rax+0x1D]
00007871bd3cf381  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf387  pinsrb xmm15, r12d, 0x07
00007871bd3cf38e  lea r14, [rax+0x1E]
00007871bd3cf392  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf398  pinsrb xmm14, r12d, 0x07
00007871bd3cf39f  lea r14, [rax+0x1F]
00007871bd3cf3a3  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf3a9  pinsrb xmm13, r12d, 0x07
00007871bd3cf3b0  lea r14, [rax+0x20]
00007871bd3cf3b4  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf3ba  pinsrb xmm1, r12d, 0x08
00007871bd3cf3c1  lea r14, [rax+0x21]
00007871bd3cf3c5  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf3cb  pinsrb xmm15, r12d, 0x08
00007871bd3cf3d2  lea r14, [rax+0x22]
00007871bd3cf3d6  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf3dc  pinsrb xmm14, r12d, 0x08
00007871bd3cf3e3  lea r14, [rax+0x23]
00007871bd3cf3e7  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf3ed  pinsrb xmm13, r12d, 0x08
00007871bd3cf3f4  lea r14, [rax+0x24]
00007871bd3cf3f8  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf3fe  pinsrb xmm1, r12d, 0x09
00007871bd3cf405  lea r14, [rax+0x25]
00007871bd3cf409  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf40f  pinsrb xmm15, r12d, 0x09
00007871bd3cf416  lea r14, [rax+0x26]
00007871bd3cf41a  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf420  pinsrb xmm14, r12d, 0x09
00007871bd3cf427  lea r14, [rax+0x27]
00007871bd3cf42b  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf431  pinsrb xmm13, r12d, 0x09
00007871bd3cf438  lea r14, [rax+0x28]
00007871bd3cf43c  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf442  pinsrb xmm1, r12d, 0x0A
00007871bd3cf449  lea r14, [rax+0x29]
00007871bd3cf44d  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf453  pinsrb xmm15, r12d, 0x0A
00007871bd3cf45a  lea r14, [rax+0x2A]
00007871bd3cf45e  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf464  pinsrb xmm14, r12d, 0x0A
00007871bd3cf46b  lea r14, [rax+0x2B]
00007871bd3cf46f  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf475  pinsrb xmm13, r12d, 0x0A
00007871bd3cf47c  lea r14, [rax+0x2C]
00007871bd3cf480  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf486  pinsrb xmm1, r12d, 0x0B
00007871bd3cf48d  lea r14, [rax+0x2D]
00007871bd3cf491  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf497  pinsrb xmm15, r12d, 0x0B
00007871bd3cf49e  lea r14, [rax+0x2E]
00007871bd3cf4a2  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf4a8  pinsrb xmm14, r12d, 0x0B
00007871bd3cf4af  lea r14, [rax+0x2F]
00007871bd3cf4b3  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf4b9  pinsrb xmm13, r12d, 0x0B
00007871bd3cf4c0  lea r14, [rax+0x30]
00007871bd3cf4c4  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf4ca  pinsrb xmm1, r12d, 0x0C
00007871bd3cf4d1  lea r14, [rax+0x31]
00007871bd3cf4d5  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf4db  pinsrb xmm15, r12d, 0x0C
00007871bd3cf4e2  lea r14, [rax+0x32]
00007871bd3cf4e6  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf4ec  pinsrb xmm14, r12d, 0x0C
00007871bd3cf4f3  lea r14, [rax+0x33]
00007871bd3cf4f7  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf4fd  pinsrb xmm13, r12d, 0x0C
00007871bd3cf504  lea r14, [rax+0x34]
00007871bd3cf508  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf50e  pinsrb xmm1, r12d, 0x0D
00007871bd3cf515  lea r14, [rax+0x35]
00007871bd3cf519  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf51f  pinsrb xmm15, r12d, 0x0D
00007871bd3cf526  lea r14, [rax+0x36]
00007871bd3cf52a  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf530  pinsrb xmm14, r12d, 0x0D
00007871bd3cf537  lea r14, [rax+0x37]
00007871bd3cf53b  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf541  pinsrb xmm13, r12d, 0x0D
00007871bd3cf548  lea r14, [rax+0x38]
00007871bd3cf54c  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf552  pinsrb xmm1, r12d, 0x0E
00007871bd3cf559  lea r14, [rax+0x39]
00007871bd3cf55d  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf563  pinsrb xmm15, r12d, 0x0E
00007871bd3cf56a  lea r14, [rax+0x3A]
00007871bd3cf56e  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf574  pinsrb xmm14, r12d, 0x0E
00007871bd3cf57b  lea r14, [rax+0x3B]
00007871bd3cf57f  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf585  pinsrb xmm13, r12d, 0x0E
00007871bd3cf58c  lea r14, [rax+0x3C]
00007871bd3cf590  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf596  pinsrb xmm1, r12d, 0x0F
00007871bd3cf59d  movaps [r15+0x110], xmm1
00007871bd3cf5a5  lea r14, [rax+0x3D]
00007871bd3cf5a9  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf5af  pinsrb xmm15, r12d, 0x0F
00007871bd3cf5b6  movaps [r15+0x120], xmm15
00007871bd3cf5be  lea r14, [rax+0x3E]
00007871bd3cf5c2  movzx r12d, byte ptr [r13+r14*1]
00007871bd3cf5c8  pinsrb xmm14, r12d, 0x0F
00007871bd3cf5cf  movaps [r15+0x130], xmm14
00007871bd3cf5d7  lea r14, [rax+0x3F]
00007871bd3cf5db  movzx eax, byte ptr [r13+r14*1]
00007871bd3cf5e1  pinsrb xmm13, eax, 0x0F
00007871bd3cf5e8  movaps [r15+0x140], xmm13
00007871bd3cf5f0  movq xmm1, qword ptr [r15+0x120]
00007871bd3cf5f9  pmovzxbw xmm1, xmm1
00007871bd3cf5fe  psllw xmm1, 0x00
00007871bd3cf603  movaps [r15+0x150], xmm1
00007871bd3cf60b  movq xmm1, qword ptr [r15+0x130]
00007871bd3cf614  pmovzxbw xmm1, xmm1
00007871bd3cf619  psllw xmm1, 0x00
00007871bd3cf61e  movaps [r15+0x160], xmm1
00007871bd3cf626  movq xmm1, qword ptr [r15+0x110]
00007871bd3cf62f  pmovzxbw xmm1, xmm1
00007871bd3cf634  psllw xmm1, 0x00
00007871bd3cf639  movaps [r15+0x170], xmm1
00007871bd3cf641  movaps xmm15, [r15+0x110]
00007871bd3cf649  pextrq rax, xmm15, 0x01
00007871bd3cf650  movq xmm15, rax
00007871bd3cf655  pmovzxbw xmm15, xmm15
00007871bd3cf65b  psllw xmm15, 0x00
00007871bd3cf661  movaps [r15+0x180], xmm15
00007871bd3cf669  movaps xmm14, [r15+0x120]
00007871bd3cf671  pextrq rax, xmm14, 0x01
00007871bd3cf678  movq xmm14, rax
00007871bd3cf67d  pmovzxbw xmm14, xmm14
00007871bd3cf683  psllw xmm14, 0x00
00007871bd3cf689  movaps [r15+0x210], xmm14
00007871bd3cf691  movaps xmm13, [r15+0x130]
00007871bd3cf699  pextrq rax, xmm13, 0x01
00007871bd3cf6a0  movq xmm13, rax
00007871bd3cf6a5  pmovzxbw xmm13, xmm13
00007871bd3cf6ab  psllw xmm13, 0x00
00007871bd3cf6b1  movaps [r15+0x220], xmm13
00007871bd3cf6b9  movq xmm12, qword ptr [r15+0x140]
00007871bd3cf6c2  pmovzxbw xmm12, xmm12
00007871bd3cf6c8  psllw xmm12, 0x00
00007871bd3cf6ce  movaps [r15+0x250], xmm12
00007871bd3cf6d6  movaps xmm12, [r15+0x140]
00007871bd3cf6de  pextrq rax, xmm12, 0x01
00007871bd3cf6e5  movq xmm12, rax
00007871bd3cf6ea  pmovzxbw xmm12, xmm12
00007871bd3cf6f0  psllw xmm12, 0x00
00007871bd3cf6f6  movaps [r15+0x110], xmm12
00007871bd3cf6fe  movq xmm11, qword ptr [r15+0x150]
00007871bd3cf707  pmovzxwd xmm11, xmm11
00007871bd3cf70d  pslld xmm11, 0x10
00007871bd3cf713  movq xmm10, qword ptr [r15+0x160]
00007871bd3cf71c  pmovzxwd xmm10, xmm10
00007871bd3cf722  pslld xmm10, 0x08
00007871bd3cf728  pextrq rax, xmm1, 0x01
00007871bd3cf72f  movq xmm1, rax
00007871bd3cf734  pmovzxwd xmm1, xmm1
00007871bd3cf739  pslld xmm1, 0x00
00007871bd3cf73e  movaps [r15+0x260], xmm1
00007871bd3cf746  pextrq rax, xmm15, 0x01
00007871bd3cf74d  movq xmm15, rax
00007871bd3cf752  pmovzxwd xmm15, xmm15
00007871bd3cf758  pslld xmm15, 0x00
00007871bd3cf75e  movaps [r15+0x270], xmm15
00007871bd3cf766  movq xmm9, qword ptr [r15+0x170]
00007871bd3cf76f  pmovzxwd xmm9, xmm9
00007871bd3cf775  pslld xmm9, 0x00
00007871bd3cf77b  pextrq rax, xmm14, 0x01
00007871bd3cf782  movq xmm14, rax
00007871bd3cf787  pmovzxwd xmm14, xmm14
00007871bd3cf78d  pslld xmm14, 0x10
00007871bd3cf793  movaps [r15+0x280], xmm14
00007871bd3cf79b  movq xmm8, qword ptr [r15+0x180]
00007871bd3cf7a4  pmovzxwd xmm8, xmm8
00007871bd3cf7aa  pslld xmm8, 0x00
00007871bd3cf7b0  movq xmm7, qword ptr [r15+0x210]
00007871bd3cf7b9  pmovzxwd xmm7, xmm7
00007871bd3cf7be  pslld xmm7, 0x10
00007871bd3cf7c3  movaps xmm6, [r15+0x150]
00007871bd3cf7cb  pextrq rax, xmm6, 0x01
00007871bd3cf7d2  movq xmm6, rax
00007871bd3cf7d7  pmovzxwd xmm6, xmm6
00007871bd3cf7dc  pslld xmm6, 0x10
00007871bd3cf7e1  por xmm11, xmm10
00007871bd3cf7e6  movaps [r15+0x230], xmm11
00007871bd3cf7ee  pextrq rax, xmm13, 0x01
00007871bd3cf7f5  movq xmm13, rax
00007871bd3cf7fa  pmovzxwd xmm13, xmm13
00007871bd3cf800  pslld xmm13, 0x08
00007871bd3cf806  movaps [r15+0x240], xmm13
00007871bd3cf80e  movq xmm10, qword ptr [r15+0x220]
00007871bd3cf817  pmovzxwd xmm10, xmm10
00007871bd3cf81d  pslld xmm10, 0x08
00007871bd3cf823  movaps xmm5, [r15+0x160]
00007871bd3cf82b  pextrq rax, xmm5, 0x01
00007871bd3cf832  movq xmm5, rax
00007871bd3cf837  pmovzxwd xmm5, xmm5
00007871bd3cf83c  pslld xmm5, 0x08
00007871bd3cf841  pslld xmm9, 0x18
00007871bd3cf847  pslld xmm15, 0x18
00007871bd3cf84d  pslld xmm8, 0x18
00007871bd3cf853  movq xmm4, qword ptr [r15+0x250]
00007871bd3cf85c  pmovzxwd xmm4, xmm4
00007871bd3cf861  pslld xmm4, 0x00
00007871bd3cf866  por xmm14, xmm13
00007871bd3cf86b  por xmm7, xmm10
00007871bd3cf870  movaps [r15+0x210], xmm7
00007871bd3cf878  pslld xmm1, 0x18
00007871bd3cf87d  movaps [r15+0x220], xmm1
00007871bd3cf885  por xmm6, xmm5
00007871bd3cf889  por xmm11, xmm9
00007871bd3cf88e  movaps [r15+0x160], xmm11
00007871bd3cf896  pextrq rax, xmm12, 0x01
00007871bd3cf89d  movq xmm13, rax
00007871bd3cf8a2  pmovzxwd xmm13, xmm13
00007871bd3cf8a8  pslld xmm13, 0x00
00007871bd3cf8ae  movaps [r15+0x170], xmm13
00007871bd3cf8b6  movq xmm12, qword ptr [r15+0x110]
00007871bd3cf8bf  pmovzxwd xmm12, xmm12
00007871bd3cf8c5  pslld xmm12, 0x00
00007871bd3cf8cb  por xmm14, xmm15
00007871bd3cf8d0  por xmm7, xmm8
00007871bd3cf8d5  movaps xmm15, [r15+0x250]
00007871bd3cf8dd  pextrq rax, xmm15, 0x01
00007871bd3cf8e4  movq xmm15, rax
00007871bd3cf8e9  pmovzxwd xmm15, xmm15
00007871bd3cf8ef  pslld xmm15, 0x00
00007871bd3cf8f5  movaps [r15+0x180], xmm15
00007871bd3cf8fd  por xmm6, xmm1
00007871bd3cf901  movaps [r15+0x150], xmm6
00007871bd3cf909  por xmm11, xmm4
00007871bd3cf90e  movaps [r15+0x140], xmm11
00007871bd3cf916  por xmm7, xmm12
00007871bd3cf91b  movaps [r15+0x110], xmm7
00007871bd3cf923  por xmm14, xmm13
00007871bd3cf928  movaps [r15+0x120], xmm14
00007871bd3cf930  por xmm6, xmm15
00007871bd3cf935  movaps [r15+0x130], xmm6
00007871bd3cf93d  mov rax, [r15+0xF8]
00007871bd3cf944  lea r14, [rax+0x20]
00007871bd3cf948  movups [r13+r14*1], xmm7
00007871bd3cf94e  lea r14, [rax+0x30]
00007871bd3cf952  movups [r13+r14*1], xmm14
00007871bd3cf958  movups [r13+rax*1], xmm11
00007871bd3cf95e  lea r14, [rax+0x10]
00007871bd3cf962  movups [r13+r14*1], xmm6
00007871bd3cf968  mov r14d, [r13+rax*1]
00007871bd3cf96d  mov rax, [r15+0x48]
00007871bd3cf971  mov [r15+0x68], rax
00007871bd3cf975  mov qword ptr [r15+0x58], 0x04
00007871bd3cf97d  lea r12, [rax+0x04]
00007871bd3cf981  mov r11d, [r13+r12*1]
00007871bd3cf986  mov [rsp+0x10], r11d
00007871bd3cf98b  mov r11d, r11d
00007871bd3cf98e  mov [r15+0x70], r11
00007871bd3cf992  lea r12, [rax+0x38]
00007871bd3cf996  mov r11d, [r13+r12*1]
00007871bd3cf99b  lea r12, [rax+0x24]
00007871bd3cf99f  mov r10d, [r13+r12*1]
00007871bd3cf9a4  mov [rsp+0x20], r10d
00007871bd3cf9a9  mov r10d, r10d
00007871bd3cf9ac  mov [r15+0x90], r10
00007871bd3cf9b3  mov [rsp+0x30], rax
00007871bd3cf9b8  xor eax, eax
00007871bd3cf9ba  mov r12d, 0x04
00007871bd3cf9c0  mov r10d, 0xC0
00007871bd3cf9c6  cmp r12, r10
00007871bd3cf9c9  cmc
00007871bd3cf9ca  lahf
00007871bd3cf9cb  seto al
00007871bd3cf9ce  mov [r15+0x108], eax
00007871bd3cf9d5  mov eax, [rsp+0x10]
00007871bd3cf9d9  mov r12d, [rsp+0x10]
00007871bd3cf9de  shrd eax, r12d, 0x07
00007871bd3cf9e3  mov [rsp+0x10], r11d
00007871bd3cf9e8  mov r10d, [rsp+0x10]
00007871bd3cf9ed  shrd r11d, r10d, 0x11
00007871bd3cf9f2  mov r9d, [rsp+0x20]
00007871bd3cf9f7  lea r8d, [r9d+r14d*1]
00007871bd3cf9fc  rorx r14d, r12d, 0x12
00007871bd3cfa02  xor eax, r14d
00007871bd3cfa05  rorx r14d, r10d, 0x13
00007871bd3cfa0b  xor r11d, r14d
00007871bd3cfa0e  mov [rsp+0x10], r11d
00007871bd3cfa13  mov r11d, r11d
00007871bd3cfa16  mov [r15+0x88], r11
00007871bd3cfa1d  mov [rsp+0x20], r12d
00007871bd3cfa22  shr r12d, 0x03
00007871bd3cfa26  xor eax, r12d
00007871bd3cfa29  mov [rsp+0x40], eax
00007871bd3cfa2d  mov eax, eax
00007871bd3cfa2f  mov [r15+0x80], rax
00007871bd3cfa36  shr r10d, 0x0A
00007871bd3cfa3a  mov eax, [rsp+0x10]
00007871bd3cfa3e  xor eax, r10d
00007871bd3cfa41  mov [rsp+0x10], eax
00007871bd3cfa45  mov eax, eax
00007871bd3cfa47  mov [r15+0x78], rax
00007871bd3cfa4b  mov eax, [rsp+0x40]
00007871bd3cfa4f  lea r14d, [r8d+eax*1]
00007871bd3cfa54  mov eax, [rsp+0x10]
00007871bd3cfa58  lea r12d, [r14d+eax*1]
00007871bd3cfa5d  mov rax, [rsp+0x30]
00007871bd3cfa62  lea r14, [rax+0x40]
00007871bd3cfa66  mov [r13+r14*1], r12d
00007871bd3cfa6b  mov eax, [rsp+0x20]
00007871bd3cfa6f  mov eax, eax
00007871bd3cfa71  mov [r15+0x60], rax
00007871bd3cfa75  mov eax, [r15+0x108]
00007871bd3cfa7c  sahf
00007871bd3cfa7d  jnz 0x00007871BD3CFAAF
00007871bd3cfa7f  cmp dword ptr [r15+0x318], 0x00
00007871bd3cfa87  jz 0x00007871BD3CFF70
00007871bd3cfa8d  nop [rax+rax*1], ax
00007871bd3cfa96  nop [rax+rax*1], eax
00007871bd3cfa9e  mov eax, 0x41088C
00007871bd3cfaa3  mov [r15+0x100], rax
00007871bd3cfaaa  jmp 0x00007871BD1FE110
00007871bd3cfaaf  cmp dword ptr [r15+0x318], 0x00
00007871bd3cfab7  jz 0x00007871BD3CFDC0
00007871bd3cfabd  nop [rax+rax*1], ax
00007871bd3cfac6  nop [rax+rax*1], eax
00007871bd3cface  mov eax, 0x410844
00007871bd3cfad3  mov [r15+0x100], rax
00007871bd3cfada  jmp 0x00007871BD1FE110
00007871bd3cfadf  int3
00007871bd3cfae0  call 0x00007871BD20D860
00007871bd3cfae5  jmp 0x00007871BD3CF17A
00007871bd3cfaea  call 0x00007871BD2E2420
00007871bd3cfaef  jmp 0x00007871BD3CF193
00007871bd3cfaf4  call 0x00007871BD2E2420
00007871bd3cfaf9  jmp 0x00007871BD3CF1AC
00007871bd3cfafe  call 0x00007871BD2E2420
00007871bd3cfb03  jmp 0x00007871BD3CF1C5
00007871bd3cfb08  call 0x00007871BD2E2420
00007871bd3cfb0d  jmp 0x00007871BD3CF1DE
00007871bd3cfb12  call 0x00007871BD2E2420
00007871bd3cfb17  jmp 0x00007871BD3CF1EF
00007871bd3cfb1c  call 0x00007871BD2E2420
00007871bd3cfb21  jmp 0x00007871BD3CF200
00007871bd3cfb26  call 0x00007871BD2E2420
00007871bd3cfb2b  jmp 0x00007871BD3CF211
00007871bd3cfb30  call 0x00007871BD2E2420
00007871bd3cfb35  jmp 0x00007871BD3CF222
00007871bd3cfb3a  call 0x00007871BD2E2420
00007871bd3cfb3f  jmp 0x00007871BD3CF233
00007871bd3cfb44  call 0x00007871BD2E2420
00007871bd3cfb49  jmp 0x00007871BD3CF244
00007871bd3cfb4e  call 0x00007871BD2E2420
00007871bd3cfb53  jmp 0x00007871BD3CF255
00007871bd3cfb58  call 0x00007871BD2E2420
00007871bd3cfb5d  jmp 0x00007871BD3CF266
00007871bd3cfb62  call 0x00007871BD2E2420
00007871bd3cfb67  jmp 0x00007871BD3CF277
00007871bd3cfb6c  call 0x00007871BD2E2420
00007871bd3cfb71  jmp 0x00007871BD3CF288
00007871bd3cfb76  call 0x00007871BD2E2420
00007871bd3cfb7b  jmp 0x00007871BD3CF299
00007871bd3cfb80  call 0x00007871BD2E2420
00007871bd3cfb85  jmp 0x00007871BD3CF2AA
00007871bd3cfb8a  call 0x00007871BD2E2420
00007871bd3cfb8f  jmp 0x00007871BD3CF2BB
00007871bd3cfb94  call 0x00007871BD2E2420
00007871bd3cfb99  jmp 0x00007871BD3CF2CC
00007871bd3cfb9e  call 0x00007871BD2E2420
00007871bd3cfba3  jmp 0x00007871BD3CF2DD
00007871bd3cfba8  call 0x00007871BD2E2420
00007871bd3cfbad  jmp 0x00007871BD3CF2EE
00007871bd3cfbb2  call 0x00007871BD2E2420
00007871bd3cfbb7  jmp 0x00007871BD3CF2FF
00007871bd3cfbbc  call 0x00007871BD2E2420
00007871bd3cfbc1  jmp 0x00007871BD3CF310
00007871bd3cfbc6  call 0x00007871BD2E2420
00007871bd3cfbcb  jmp 0x00007871BD3CF321
00007871bd3cfbd0  call 0x00007871BD2E2420
00007871bd3cfbd5  jmp 0x00007871BD3CF332
00007871bd3cfbda  call 0x00007871BD2E2420
00007871bd3cfbdf  jmp 0x00007871BD3CF343
00007871bd3cfbe4  call 0x00007871BD2E2420
00007871bd3cfbe9  jmp 0x00007871BD3CF354
00007871bd3cfbee  call 0x00007871BD2E2420
00007871bd3cfbf3  jmp 0x00007871BD3CF365
00007871bd3cfbf8  call 0x00007871BD2E2420
00007871bd3cfbfd  jmp 0x00007871BD3CF376
00007871bd3cfc02  call 0x00007871BD2E2420
00007871bd3cfc07  jmp 0x00007871BD3CF387
00007871bd3cfc0c  call 0x00007871BD2E2420
00007871bd3cfc11  jmp 0x00007871BD3CF398
00007871bd3cfc16  call 0x00007871BD2E2420
00007871bd3cfc1b  jmp 0x00007871BD3CF3A9
00007871bd3cfc20  call 0x00007871BD2E2420
00007871bd3cfc25  jmp 0x00007871BD3CF3BA
00007871bd3cfc2a  call 0x00007871BD2E2420
00007871bd3cfc2f  jmp 0x00007871BD3CF3CB
00007871bd3cfc34  call 0x00007871BD2E2420
00007871bd3cfc39  jmp 0x00007871BD3CF3DC
00007871bd3cfc3e  call 0x00007871BD2E2420
00007871bd3cfc43  jmp 0x00007871BD3CF3ED
00007871bd3cfc48  call 0x00007871BD2E2420
00007871bd3cfc4d  jmp 0x00007871BD3CF3FE
00007871bd3cfc52  call 0x00007871BD2E2420
00007871bd3cfc57  jmp 0x00007871BD3CF40F
00007871bd3cfc5c  call 0x00007871BD2E2420
00007871bd3cfc61  jmp 0x00007871BD3CF420
00007871bd3cfc66  call 0x00007871BD2E2420
00007871bd3cfc6b  jmp 0x00007871BD3CF431
00007871bd3cfc70  call 0x00007871BD2E2420
00007871bd3cfc75  jmp 0x00007871BD3CF442
00007871bd3cfc7a  call 0x00007871BD2E2420
00007871bd3cfc7f  jmp 0x00007871BD3CF453
00007871bd3cfc84  call 0x00007871BD2E2420
00007871bd3cfc89  jmp 0x00007871BD3CF464
00007871bd3cfc8e  call 0x00007871BD2E2420
00007871bd3cfc93  jmp 0x00007871BD3CF475
00007871bd3cfc98  call 0x00007871BD2E2420
00007871bd3cfc9d  jmp 0x00007871BD3CF486
00007871bd3cfca2  call 0x00007871BD2E2420
00007871bd3cfca7  jmp 0x00007871BD3CF497
00007871bd3cfcac  call 0x00007871BD2E2420
00007871bd3cfcb1  jmp 0x00007871BD3CF4A8
00007871bd3cfcb6  call 0x00007871BD2E2420
00007871bd3cfcbb  jmp 0x00007871BD3CF4B9
00007871bd3cfcc0  call 0x00007871BD2E2420
00007871bd3cfcc5  jmp 0x00007871BD3CF4CA
00007871bd3cfcca  call 0x00007871BD2E2420
00007871bd3cfccf  jmp 0x00007871BD3CF4DB
00007871bd3cfcd4  call 0x00007871BD2E2420
00007871bd3cfcd9  jmp 0x00007871BD3CF4EC
00007871bd3cfcde  call 0x00007871BD2E2420
00007871bd3cfce3  jmp 0x00007871BD3CF4FD
00007871bd3cfce8  call 0x00007871BD2E2420
00007871bd3cfced  jmp 0x00007871BD3CF50E
00007871bd3cfcf2  call 0x00007871BD2E2420
00007871bd3cfcf7  jmp 0x00007871BD3CF51F
00007871bd3cfcfc  call 0x00007871BD2E2420
00007871bd3cfd01  jmp 0x00007871BD3CF530
00007871bd3cfd06  call 0x00007871BD2E2420
00007871bd3cfd0b  jmp 0x00007871BD3CF541
00007871bd3cfd10  call 0x00007871BD2E2420
00007871bd3cfd15  jmp 0x00007871BD3CF552
00007871bd3cfd1a  call 0x00007871BD2E2420
00007871bd3cfd1f  jmp 0x00007871BD3CF563
00007871bd3cfd24  call 0x00007871BD2E2420
00007871bd3cfd29  jmp 0x00007871BD3CF574
00007871bd3cfd2e  call 0x00007871BD2E2420
00007871bd3cfd33  jmp 0x00007871BD3CF585
00007871bd3cfd38  call 0x00007871BD2E2420
00007871bd3cfd3d  jmp 0x00007871BD3CF596
00007871bd3cfd42  call 0x00007871BD2E2420
00007871bd3cfd47  jmp 0x00007871BD3CF5AF
00007871bd3cfd4c  call 0x00007871BD2E2420
00007871bd3cfd51  jmp 0x00007871BD3CF5C8
00007871bd3cfd56  call 0x00007871BD2D5610
00007871bd3cfd5b  jmp 0x00007871BD3CF5E1
00007871bd3cfd60  call 0x00007871BD2DC580
00007871bd3cfd65  jmp 0x00007871BD3CF94E
00007871bd3cfd6a  call 0x00007871BD2E46C0
00007871bd3cfd6f  jmp 0x00007871BD3CF958
00007871bd3cfd74  call 0x00007871BD209E90
00007871bd3cfd79  jmp 0x00007871BD3CF95E
00007871bd3cfd7e  call 0x00007871BD2DB310
00007871bd3cfd83  jmp 0x00007871BD3CF968
00007871bd3cfd88  call 0x00007871BD20DAE0
00007871bd3cfd8d  jmp 0x00007871BD3CF96D
00007871bd3cfd92  call 0x00007871BD2C0230
00007871bd3cfd97  jmp 0x00007871BD3CF986
00007871bd3cfd9c  call 0x00007871BD2C0230
00007871bd3cfda1  jmp 0x00007871BD3CF99B
00007871bd3cfda6  call 0x00007871BD2BEFC0
00007871bd3cfdab  jmp 0x00007871BD3CF9A4
00007871bd3cfdb0  call 0x00007871BD2E2BA0
00007871bd3cfdb5  jmp 0x00007871BD3CFA6B
00007871bd3cfdba  int3
00007871bd3cfdbb  nop [rax+rax*1], eax
00007871bd3cfdc0  mov rax, [r15+0x48]
00007871bd3cfdc4  mov r14, [r15+0x58]
00007871bd3cfdc8  lea r12, [rax+r14*1]
00007871bd3cfdcc  mov [r15+0x68], r12
00007871bd3cfdd0  lea rax, [r14+0x04]
00007871bd3cfdd4  mov [r15+0x58], rax
00007871bd3cfdd8  lea r14, [r12+0x04]
00007871bd3cfddd  mov r11d, [r13+r14*1]
00007871bd3cfde2  mov [rsp+0x10], r11d
00007871bd3cfde7  mov r11d, r11d
00007871bd3cfdea  mov [r15+0x70], r11
00007871bd3cfdee  lea r14, [r12+0x38]
00007871bd3cfdf3  mov r11d, [r13+r14*1]
00007871bd3cfdf8  lea r14, [r12+0x24]
00007871bd3cfdfd  mov r10d, [r13+r14*1]
00007871bd3cfe02  mov [rsp+0x20], r10d
00007871bd3cfe07  mov r10d, r10d
00007871bd3cfe0a  mov [r15+0x90], r10
00007871bd3cfe11  mov [rsp+0x30], rax
00007871bd3cfe16  xor eax, eax
00007871bd3cfe18  mov r14, [rsp+0x30]
00007871bd3cfe1d  mov r10d, 0xC0
00007871bd3cfe23  cmp r14, r10
00007871bd3cfe26  cmc
00007871bd3cfe27  lahf
00007871bd3cfe28  seto al
00007871bd3cfe2b  mov [r15+0x108], eax
00007871bd3cfe32  mov eax, [rsp+0x10]
00007871bd3cfe36  mov r14d, [rsp+0x10]
00007871bd3cfe3b  shrd eax, r14d, 0x07
00007871bd3cfe40  mov [rsp+0x10], r11d
00007871bd3cfe45  mov r10d, [rsp+0x10]
00007871bd3cfe4a  shrd r11d, r10d, 0x11
00007871bd3cfe4f  mov r9d, [r15+0x60]
00007871bd3cfe53  mov r8d, [rsp+0x20]
00007871bd3cfe58  lea ebp, [r8d+r9d*1]
00007871bd3cfe5d  rorx r9d, r14d, 0x12
00007871bd3cfe63  xor eax, r9d
00007871bd3cfe66  rorx r9d, r10d, 0x13
00007871bd3cfe6c  xor r11d, r9d
00007871bd3cfe6f  mov [rsp+0x10], r11d
00007871bd3cfe74  mov r11d, r11d
00007871bd3cfe77  mov [r15+0x88], r11
00007871bd3cfe7e  mov [rsp+0x20], r14d
00007871bd3cfe83  shr r14d, 0x03
00007871bd3cfe87  xor eax, r14d
00007871bd3cfe8a  mov [rsp+0x30], eax
00007871bd3cfe8e  mov eax, eax
00007871bd3cfe90  mov [r15+0x80], rax
00007871bd3cfe97  shr r10d, 0x0A
00007871bd3cfe9b  mov eax, [rsp+0x10]
00007871bd3cfe9f  xor eax, r10d
00007871bd3cfea2  mov [rsp+0x10], eax
00007871bd3cfea6  mov eax, eax
00007871bd3cfea8  mov [r15+0x78], rax
00007871bd3cfeac  mov eax, [rsp+0x30]
00007871bd3cfeb0  lea r14d, [ebp+eax*1]
00007871bd3cfeb6  mov eax, [rsp+0x10]
00007871bd3cfeba  lea r11d, [r14d+eax*1]
00007871bd3cfebf  lea rax, [r12+0x40]
00007871bd3cfec4  mov [r13+rax*1], r11d
00007871bd3cfec9  mov eax, [rsp+0x20]
00007871bd3cfecd  mov eax, eax
00007871bd3cfecf  mov [r15+0x60], rax
00007871bd3cfed3  mov eax, [r15+0x108]
00007871bd3cfeda  sahf
00007871bd3cfedb  jnz 0x00007871BD3CFF0D
00007871bd3cfedd  cmp dword ptr [r15+0x318], 0x00
00007871bd3cfee5  jz 0x00007871BD3CFF70
00007871bd3cfeeb  nop [rax+rax*1], ax
00007871bd3cfef4  nop [rax+rax*1], eax
00007871bd3cfefc  mov eax, 0x41088C
00007871bd3cff01  mov [r15+0x100], rax
00007871bd3cff08  jmp 0x00007871BD1FE110
00007871bd3cff0d  cmp dword ptr [r15+0x318], 0x00
00007871bd3cff15  jz 0x00007871BD3CFDC0
00007871bd3cff1b  nop [rax+rax*1], ax
00007871bd3cff24  nop [rax+rax*1], eax
00007871bd3cff2c  mov eax, 0x410844
00007871bd3cff31  mov [r15+0x100], rax
00007871bd3cff38  jmp 0x00007871BD1FE110
00007871bd3cff3d  int3
00007871bd3cff3e  call 0x00007871BD2E1430
00007871bd3cff43  jmp 0x00007871BD3CFDE2
00007871bd3cff48  call 0x00007871BD2E1430
00007871bd3cff4d  jmp 0x00007871BD3CFDF8
00007871bd3cff52  call 0x00007871BD2E01C0
00007871bd3cff57  jmp 0x00007871BD3CFE02
00007871bd3cff5c  call 0x00007871BD20A860
00007871bd3cff61  jmp 0x00007871BD3CFEC9
00007871bd3cff66  int3
00007871bd3cff67  nop [rax+rax*1], ax
00007871bd3cff70  mov rax, [r15]
00007871bd3cff73  mov r14d, [r13+rax*1]
00007871bd3cff78  lea r12, [rax+0x04]
00007871bd3cff7c  mov r11d, [r13+r12*1]
00007871bd3cff81  mov [rsp+0x10], r14d
00007871bd3cff86  mov r14d, r14d
00007871bd3cff89  mov [r15+0x78], r14
00007871bd3cff8d  mov [rsp+0x20], r11d
00007871bd3cff92  mov r11d, r11d
00007871bd3cff95  mov [r15+0x80], r11
00007871bd3cff9c  lea r14, [rax+0x08]
00007871bd3cffa0  mov r12d, [r13+r14*1]
00007871bd3cffa5  lea r14, [rax+0x0C]
00007871bd3cffa9  mov r11d, [r13+r14*1]
00007871bd3cffae  mov [rsp+0x30], r12d
00007871bd3cffb3  mov r12d, r12d
00007871bd3cffb6  mov [r15+0x70], r12
00007871bd3cffba  mov [rsp+0x40], r11d
00007871bd3cffbf  mov r11d, r11d
00007871bd3cffc2  mov [r15+0x68], r11
00007871bd3cffc6  lea r14, [rax+0x18]
00007871bd3cffca  mov r12d, [r13+r14*1]
00007871bd3cffcf  lea r14, [rax+0x1C]
00007871bd3cffd3  mov r11d, [r13+r14*1]
00007871bd3cffd8  mov [rsp+0x50], r12d
00007871bd3cffdd  mov r12d, r12d
00007871bd3cffe0  mov [r15+0x58], r12
00007871bd3cffe4  mov [rsp+0x60], r11d
00007871bd3cffe9  mov r11d, r11d
00007871bd3cffec  mov [r15+0x60], r11
00007871bd3cfff0  lea r14, [rax+0x10]
00007871bd3cfff4  mov r12d, [r13+r14*1]
00007871bd3cfff9  lea r14, [rax+0x14]
00007871bd3cfffd  mov eax, [r13+r14*1]
00007871bd3d0002  mov [rsp+0x70], r12d
00007871bd3d0007  mov r12d, r12d
00007871bd3d000a  mov [r15+0x18], r12
00007871bd3d000e  mov [rsp+0x80], eax
00007871bd3d0015  mov eax, eax
00007871bd3d0017  mov [r15+0x90], rax
00007871bd3d001e  mov eax, [rsp+0x70]
00007871bd3d0022  mov eax, eax
00007871bd3d0024  mov [r15+0x30], rax
00007871bd3d0028  mov eax, [rsp+0x50]
00007871bd3d002c  mov eax, eax
00007871bd3d002e  mov [r15+0xA0], rax
00007871bd3d0035  mov eax, [rsp+0x30]
00007871bd3d0039  mov eax, eax
00007871bd3d003b  mov [r15+0x28], rax
00007871bd3d003f  mov eax, [rsp+0x20]
00007871bd3d0043  mov eax, eax
00007871bd3d0045  mov [r15+0x98], rax
00007871bd3d004c  mov eax, [rsp+0x10]
00007871bd3d0050  mov eax, eax
00007871bd3d0052  mov [r15+0x38], rax
00007871bd3d0056  mov eax, [rsp+0x70]
00007871bd3d005a  mov r14d, [rsp+0x70]
00007871bd3d005f  shrd eax, r14d, 0x06
00007871bd3d0064  mov [rsp+0x70], r14d
00007871bd3d0069  mov r12d, [rsp+0x80]
00007871bd3d0071  and r14d, r12d
00007871bd3d0074  mov r11d, [rsp+0x10]
00007871bd3d0079  mov r10d, [rsp+0x10]
00007871bd3d007e  shrd r11d, r10d, 0x02
00007871bd3d0083  mov [rsp+0x10], r12d
00007871bd3d0088  mov r12d, r12d
00007871bd3d008b  mov [r15+0x20], r12
00007871bd3d008f  mov r12, [r15+0x50]
00007871bd3d0093  mov r9d, [r13+r12*1]
00007871bd3d0098  mov r12d, [rsp+0x50]
00007871bd3d009d  mov r8d, [rsp+0x70]
00007871bd3d00a2  andn ebp, r8d, r12d
00007871bd3d00a7  mov edi, [rsp+0x60]
00007871bd3d00ab  lea esi, [r14d+edi*1]
00007871bd3d00b0  rorx r14d, r8d, 0x0B
00007871bd3d00b6  xor eax, r14d
00007871bd3d00b9  rorx r14d, r10d, 0x0D
00007871bd3d00bf  xor r11d, r14d
00007871bd3d00c2  lea edi, [esi+ebp*1]
00007871bd3d00c6  mov r14, [r15+0x48]
00007871bd3d00ca  mov ebp, [r13+r14*1]
00007871bd3d00cf  mov r14d, [rsp+0x30]
00007871bd3d00d4  mov esi, [rsp+0x20]
00007871bd3d00d8  and r14d, esi
00007871bd3d00db  mov [rsp+0x20], r14d
00007871bd3d00e0  mov r14d, r14d
00007871bd3d00e3  mov [r15+0xD8], r14
00007871bd3d00ea  lea r14d, [edi+r9d*1]
00007871bd3d00ef  mov r9d, [rsp+0x30]
00007871bd3d00f4  xor r9d, esi
00007871bd3d00f7  rorx edi, r8d, 0x19
00007871bd3d00fd  xor eax, edi
00007871bd3d00ff  and r9d, r10d
00007871bd3d0102  rorx edi, r10d, 0x16
00007871bd3d0108  xor r11d, edi
00007871bd3d010b  mov [rsp+0x30], r11d
00007871bd3d0110  mov r11d, r11d
00007871bd3d0113  mov [r15+0xD0], r11
00007871bd3d011a  lea r11d, [r14d+ebp*1]
00007871bd3d011f  mov r10d, [rsp+0x20]
00007871bd3d0124  xor r9d, r10d
00007871bd3d0127  lea r14d, [r11d+eax*1]
00007871bd3d012c  mov qword ptr [r15+0x88], 0x04
00007871bd3d0137  mov eax, [rsp+0x30]
00007871bd3d013b  lea r11d, [r9d+eax*1]
00007871bd3d0140  mov eax, [rsp+0x40]
00007871bd3d0144  lea r10d, [r14d+eax*1]
00007871bd3d0149  mov r10d, r10d
00007871bd3d014c  mov [r15+0xB8], r10
00007871bd3d0153  xor eax, eax
00007871bd3d0155  mov r10d, 0x04
00007871bd3d015b  mov r9d, 0x100
00007871bd3d0161  cmp r10, r9
00007871bd3d0164  cmc
00007871bd3d0165  lahf
00007871bd3d0166  seto al
00007871bd3d0169  mov [r15+0x108], eax
00007871bd3d0170  lea eax, [r11d+r14d*1]
00007871bd3d0175  mov eax, eax
00007871bd3d0177  mov [r15+0xA8], rax
00007871bd3d017e  mov r12d, r12d
00007871bd3d0181  mov [r15+0xB0], r12
00007871bd3d0188  mov eax, [rsp+0x10]
00007871bd3d018c  mov eax, eax
00007871bd3d018e  mov [r15+0xC0], rax
00007871bd3d0195  mov r8d, r8d
00007871bd3d0198  mov [r15+0xC8], r8
00007871bd3d019f  mov eax, [r15+0x108]
00007871bd3d01a6  sahf
00007871bd3d01a7  jnz 0x00007871BD3D01D9
00007871bd3d01a9  cmp dword ptr [r15+0x318], 0x00
00007871bd3d01b1  jz 0x00007871BD3D04A0
00007871bd3d01b7  nop [rax+rax*1], ax
00007871bd3d01c0  nop [rax+rax*1], eax
00007871bd3d01c8  mov eax, 0x41094C
00007871bd3d01cd  mov [r15+0x100], rax
00007871bd3d01d4  jmp 0x00007871BD1FE110
00007871bd3d01d9  cmp dword ptr [r15+0x318], 0x00
00007871bd3d01e1  jz 0x00007871BD3D0270
00007871bd3d01e7  nop [rax+rax*1], ax
00007871bd3d01f0  nop [rax+rax*1], eax
00007871bd3d01f8  mov eax, 0x4108C0
00007871bd3d01fd  mov [r15+0x100], rax
00007871bd3d0204  jmp 0x00007871BD1FE110
00007871bd3d0209  int3
00007871bd3d020a  call 0x00007871BD20DAE0
00007871bd3d020f  jmp 0x00007871BD3CFF78
00007871bd3d0214  call 0x00007871BD2C0230
00007871bd3d0219  jmp 0x00007871BD3CFF81
00007871bd3d021e  call 0x00007871BD2E26A0
00007871bd3d0223  jmp 0x00007871BD3CFFA5
00007871bd3d0228  call 0x00007871BD2E1430
00007871bd3d022d  jmp 0x00007871BD3CFFAE
00007871bd3d0232  call 0x00007871BD2E26A0
00007871bd3d0237  jmp 0x00007871BD3CFFCF
00007871bd3d023c  call 0x00007871BD2E1430
00007871bd3d0241  jmp 0x00007871BD3CFFD8
00007871bd3d0246  call 0x00007871BD2E26A0
00007871bd3d024b  jmp 0x00007871BD3CFFF9
00007871bd3d0250  call 0x00007871BD2D5890
00007871bd3d0255  jmp 0x00007871BD3D0002
00007871bd3d025a  call 0x00007871BD2BDD50
00007871bd3d025f  jmp 0x00007871BD3D0098
00007871bd3d0264  call 0x00007871BD2DA580
00007871bd3d0269  jmp 0x00007871BD3D00CF
00007871bd3d026e  int3
00007871bd3d026f  nop
00007871bd3d0270  mov eax, [r15+0xB8]
00007871bd3d0277  mov [rsp+0x10], eax
00007871bd3d027b  mov eax, eax
00007871bd3d027d  mov [r15+0x30], rax
00007871bd3d0281  mov eax, [r15+0xC0]
00007871bd3d0288  mov [rsp+0x20], eax
00007871bd3d028c  mov eax, eax
00007871bd3d028e  mov [r15+0xA0], rax
00007871bd3d0295  mov eax, [r15+0x28]
00007871bd3d0299  mov r14d, [r15+0x98]
00007871bd3d02a0  mov [rsp+0x30], r14d
00007871bd3d02a5  mov r14d, r14d
00007871bd3d02a8  mov [r15+0x28], r14
00007871bd3d02ac  mov r14d, [r15+0x38]
00007871bd3d02b0  mov [rsp+0x40], r14d
00007871bd3d02b5  mov r14d, r14d
00007871bd3d02b8  mov [r15+0x98], r14
00007871bd3d02bf  mov r14d, [r15+0xA8]
00007871bd3d02c6  mov [rsp+0x50], r14d
00007871bd3d02cb  mov r14d, r14d
00007871bd3d02ce  mov [r15+0x38], r14
00007871bd3d02d2  mov r14d, [rsp+0x10]
00007871bd3d02d7  mov r12d, [rsp+0x10]
00007871bd3d02dc  shrd r14d, r12d, 0x06
00007871bd3d02e1  mov r11d, [r15+0xC8]
00007871bd3d02e8  mov [rsp+0x10], r12d
00007871bd3d02ed  and r12d, r11d
00007871bd3d02f0  mov r10d, [rsp+0x50]
00007871bd3d02f5  mov r9d, [rsp+0x50]
00007871bd3d02fa  shrd r10d, r9d, 0x02
00007871bd3d02ff  mov [rsp+0x50], r11d
00007871bd3d0304  mov r11d, r11d
00007871bd3d0307  mov [r15+0x20], r11
00007871bd3d030b  mov r11, [r15+0x88]
00007871bd3d0312  mov r8, [r15+0x50]
00007871bd3d0316  lea rbp, [r8+r11*1]
00007871bd3d031a  mov r8d, [r13+rbp*1]
00007871bd3d031f  mov ebp, [rsp+0x20]
00007871bd3d0323  mov edi, [rsp+0x10]
00007871bd3d0327  andn esi, edi, ebp
00007871bd3d032c  mov edx, [r15+0xB0]
00007871bd3d0333  lea ecx, [r12d+edx*1]
00007871bd3d0338  rorx r12d, edi, 0x0B
00007871bd3d033e  xor r14d, r12d
00007871bd3d0341  rorx r12d, r9d, 0x0D
00007871bd3d0347  xor r10d, r12d
00007871bd3d034a  lea r12d, [ecx+esi*1]
00007871bd3d034f  mov rsi, [r15+0x48]
00007871bd3d0353  lea rdx, [rsi+r11*1]
00007871bd3d0357  mov esi, [r13+rdx*1]
00007871bd3d035c  mov edx, [rsp+0x30]
00007871bd3d0360  mov ecx, [rsp+0x40]
00007871bd3d0364  and edx, ecx
00007871bd3d0366  mov [rsp+0x10], edx
00007871bd3d036a  mov edx, edx
00007871bd3d036c  mov [r15+0xD8], rdx
00007871bd3d0373  lea edx, [r12d+r8d*1]
00007871bd3d0378  mov r12d, [rsp+0x30]
00007871bd3d037d  xor r12d, ecx
00007871bd3d0380  rorx r8d, edi, 0x19
00007871bd3d0386  xor r14d, r8d
00007871bd3d0389  and r12d, r9d
00007871bd3d038c  rorx r8d, r9d, 0x16
00007871bd3d0392  xor r10d, r8d
00007871bd3d0395  mov [rsp+0x20], r10d
00007871bd3d039a  mov r10d, r10d
00007871bd3d039d  mov [r15+0xD0], r10
00007871bd3d03a4  lea r10d, [edx+esi*1]
00007871bd3d03a9  mov r9d, [rsp+0x10]
00007871bd3d03ae  xor r12d, r9d
00007871bd3d03b1  lea r9d, [r10d+r14d*1]
00007871bd3d03b6  lea r14, [r11+0x04]
00007871bd3d03ba  mov [r15+0x88], r14
00007871bd3d03c1  mov r11d, [rsp+0x20]
00007871bd3d03c6  lea r10d, [r12d+r11d*1]
00007871bd3d03cb  lea r11d, [r9d+eax*1]
00007871bd3d03d0  mov r11d, r11d
00007871bd3d03d3  mov [r15+0xB8], r11
00007871bd3d03da  xor eax, eax
00007871bd3d03dc  mov r12d, 0x100
00007871bd3d03e2  cmp r14, r12
00007871bd3d03e5  cmc
00007871bd3d03e6  lahf
00007871bd3d03e7  seto al
00007871bd3d03ea  mov [r15+0x108], eax
00007871bd3d03f1  lea eax, [r10d+r9d*1]
00007871bd3d03f6  mov eax, eax
00007871bd3d03f8  mov [r15+0xA8], rax
00007871bd3d03ff  mov ebp, ebp
00007871bd3d0401  mov [r15+0xB0], rbp
00007871bd3d0408  mov eax, [rsp+0x50]
00007871bd3d040c  mov eax, eax
00007871bd3d040e  mov [r15+0xC0], rax
00007871bd3d0415  mov edi, edi
00007871bd3d0417  mov [r15+0xC8], rdi
00007871bd3d041e  mov eax, [r15+0x108]
00007871bd3d0425  sahf
00007871bd3d0426  jnz 0x00007871BD3D0458
00007871bd3d0428  cmp dword ptr [r15+0x318], 0x00
00007871bd3d0430  jz 0x00007871BD3D04A0
00007871bd3d0436  nop [rax+rax*1], ax
00007871bd3d043f  nop [rax+rax*1], eax
00007871bd3d0447  mov eax, 0x41094C
00007871bd3d044c  mov [r15+0x100], rax
00007871bd3d0453  jmp 0x00007871BD1FE110
00007871bd3d0458  cmp dword ptr [r15+0x318], 0x00
00007871bd3d0460  jz 0x00007871BD3D0270
00007871bd3d0466  nop [rax+rax*1], ax
00007871bd3d046f  nop [rax+rax*1], eax
00007871bd3d0477  mov eax, 0x4108C0
00007871bd3d047c  mov [r15+0x100], rax
00007871bd3d0483  jmp 0x00007871BD1FE110
00007871bd3d0488  int3
00007871bd3d0489  call 0x00007871BD249010
00007871bd3d048e  jmp 0x00007871BD3D031F
00007871bd3d0493  call 0x00007871BD225930
00007871bd3d0498  jmp 0x00007871BD3D035C
00007871bd3d049d  int3
00007871bd3d049e  nop
00007871bd3d04a0  mov eax, [r15+0x98]
00007871bd3d04a7  mov r14d, [r15+0x70]
00007871bd3d04ab  lea r12d, [eax+r14d*1]
00007871bd3d04b0  mov eax, [r15+0x28]
00007871bd3d04b4  mov r14d, [r15+0x68]
00007871bd3d04b8  lea r11d, [eax+r14d*1]
00007871bd3d04bd  mov qword ptr [r15+0x88], 0x00
00007871bd3d04c8  mov eax, [r15+0xA8]
00007871bd3d04cf  mov r14d, [r15+0x78]
00007871bd3d04d3  lea r10d, [eax+r14d*1]
00007871bd3d04d8  mov [rsp+0x10], r10d
00007871bd3d04dd  mov r10d, r10d
00007871bd3d04e0  mov [r15+0x78], r10
00007871bd3d04e4  mov eax, [r15+0x38]
00007871bd3d04e8  mov r14d, [r15+0x80]
00007871bd3d04ef  lea r10d, [eax+r14d*1]
00007871bd3d04f4  mov [rsp+0x20], r10d
00007871bd3d04f9  mov r10d, r10d
00007871bd3d04fc  mov [r15+0x80], r10
00007871bd3d0503  mov rax, [r15]
00007871bd3d0506  lea r14, [rax+0x08]
00007871bd3d050a  mov [r13+r14*1], r12d
00007871bd3d050f  lea r14, [rax+0x0C]
00007871bd3d0513  mov [r13+r14*1], r11d
00007871bd3d0518  mov r14d, [r15+0xB8]
00007871bd3d051f  mov r12d, [r15+0x18]
00007871bd3d0523  lea r11d, [r14d+r12d*1]
00007871bd3d0528  mov [rsp+0x30], r11d
00007871bd3d052d  mov r11d, r11d
00007871bd3d0530  mov [r15+0x68], r11
00007871bd3d0534  mov r14d, [r15+0x30]
00007871bd3d0538  mov r12d, [r15+0x90]
00007871bd3d053f  lea r11d, [r14d+r12d*1]
00007871bd3d0544  mov [rsp+0x40], r11d
00007871bd3d0549  mov r11d, r11d
00007871bd3d054c  mov [r15+0x70], r11
00007871bd3d0550  mov r14d, [r15+0x20]
00007871bd3d0554  mov r12d, [r15+0x58]
00007871bd3d0558  lea r11d, [r14d+r12d*1]
00007871bd3d055d  mov [rsp+0x50], r11d
00007871bd3d0562  mov r11d, r11d
00007871bd3d0565  mov [r15+0x58], r11
00007871bd3d0569  mov r14d, [r15+0xA0]
00007871bd3d0570  mov r12d, [r15+0x60]
00007871bd3d0574  lea r11d, [r14d+r12d*1]
00007871bd3d0579  mov [rsp+0x60], r11d
00007871bd3d057e  mov r11d, r11d
00007871bd3d0581  mov [r15+0x60], r11
00007871bd3d0585  mov r14d, [rsp+0x10]
00007871bd3d058a  mov [r13+rax*1], r14d
00007871bd3d058f  lea r14, [rax+0x04]
00007871bd3d0593  mov r12d, [rsp+0x20]
00007871bd3d0598  mov [r13+r14*1], r12d
00007871bd3d059d  lea r14, [rax+0x10]
00007871bd3d05a1  mov r12d, [rsp+0x30]
00007871bd3d05a6  mov [r13+r14*1], r12d
00007871bd3d05ab  lea r14, [rax+0x14]
00007871bd3d05af  mov r12d, [rsp+0x40]
00007871bd3d05b4  mov [r13+r14*1], r12d
00007871bd3d05b9  lea r14, [rax+0x18]
00007871bd3d05bd  mov r12d, [rsp+0x50]
00007871bd3d05c2  mov [r13+r14*1], r12d
00007871bd3d05c7  lea r14, [rax+0x1C]
00007871bd3d05cb  mov r12d, [rsp+0x60]
00007871bd3d05d0  mov [r13+r14*1], r12d
00007871bd3d05d5  lea r14, [rax+0x68]
00007871bd3d05d9  xor eax, eax
00007871bd3d05db  mov [r13+r14*1], rax
00007871bd3d05e0  cmp dword ptr [r15+0x318], 0x00
00007871bd3d05e8  jz 0x00007871BD3CF0E0
00007871bd3d05ee  nop [rax+rax*1], ax
00007871bd3d05f7  nop [rax+rax*1], eax
00007871bd3d05ff  mov eax, 0x410768
00007871bd3d0604  mov [r15+0x100], rax
00007871bd3d060b  jmp 0x00007871BD1FE110
00007871bd3d0610  int3
00007871bd3d0611  call 0x00007871BD2E2BA0
00007871bd3d0616  jmp 0x00007871BD3D050F
00007871bd3d061b  call 0x00007871BD2E1920
00007871bd3d0620  jmp 0x00007871BD3D0518
00007871bd3d0625  call 0x00007871BD20DFE0
00007871bd3d062a  jmp 0x00007871BD3D058F
00007871bd3d062f  call 0x00007871BD2E2BA0
00007871bd3d0634  jmp 0x00007871BD3D059D
00007871bd3d0639  call 0x00007871BD2E2BA0
00007871bd3d063e  jmp 0x00007871BD3D05AB
00007871bd3d0643  call 0x00007871BD2E2BA0
00007871bd3d0648  jmp 0x00007871BD3D05B9
00007871bd3d064d  call 0x00007871BD2E2BA0
00007871bd3d0652  jmp 0x00007871BD3D05C7
00007871bd3d0657  call 0x00007871BD2E2BA0
00007871bd3d065c  jmp 0x00007871BD3D05D5
00007871bd3d0661  call 0x00007871BD2D5EB0
00007871bd3d0666  jmp 0x00007871BD3D05E0
00007871bd3d066b  int3
00007871bd3d066c  nop [rax], eax
00007871bd3d0670  mov rax, [r15+0xF8]
00007871bd3d0677  lea r14, [rax+0x140]
00007871bd3d067e  mov r12, [r13+r14*1]
00007871bd3d0683  lea r14, [rax+0x148]
00007871bd3d068a  mov r11, [r13+r14*1]
00007871bd3d068f  mov [r15+0xA0], r12
00007871bd3d0696  mov [r15+0x98], r11
00007871bd3d069d  lea r14, [rax+0x130]
00007871bd3d06a4  mov r12, [r13+r14*1]
00007871bd3d06a9  lea r14, [rax+0x138]
00007871bd3d06b0  mov r11, [r13+r14*1]
00007871bd3d06b5  mov [r15+0xB0], r12
00007871bd3d06bc  mov [r15+0xA8], r11
00007871bd3d06c3  lea r14, [rax+0x120]
00007871bd3d06ca  mov r12, [r13+r14*1]
00007871bd3d06cf  lea r14, [rax+0x128]
00007871bd3d06d6  mov r11, [r13+r14*1]
00007871bd3d06db  mov [r15+0xC0], r12
00007871bd3d06e2  mov [r15+0xB8], r11
00007871bd3d06e9  lea r14, [rax+0x110]
00007871bd3d06f0  mov r12, [r13+r14*1]
00007871bd3d06f5  lea r14, [rax+0x118]
00007871bd3d06fc  mov r11, [r13+r14*1]
00007871bd3d0701  mov [r15+0xD0], r12
00007871bd3d0708  mov [r15+0xC8], r11
00007871bd3d070f  lea r14, [rax+0x100]
00007871bd3d0716  mov r12, [r13+r14*1]
00007871bd3d071b  lea r14, [rax+0x108]
00007871bd3d0722  mov r11, [r13+r14*1]
00007871bd3d0727  mov [r15+0xE8], r12
00007871bd3d072e  mov [r15+0xD8], r11
00007871bd3d0735  lea r14, [rax+0x150]
00007871bd3d073c  mov [r15+0xF8], r14
00007871bd3d0743  mov rax, [r15+0xF0]
00007871bd3d074a  mov [r15+0x100], rax
00007871bd3d0751  jmp 0x00007871BD3CE5C0
00007871bd3d0756  int3
00007871bd3d0757  call 0x00007871BD2E27E0
00007871bd3d075c  jmp 0x00007871BD3D0683
00007871bd3d0761  call 0x00007871BD2E1570
00007871bd3d0766  jmp 0x00007871BD3D068F
00007871bd3d076b  call 0x00007871BD2E27E0
00007871bd3d0770  jmp 0x00007871BD3D06A9
00007871bd3d0775  call 0x00007871BD2E1570
00007871bd3d077a  jmp 0x00007871BD3D06B5
00007871bd3d077f  call 0x00007871BD2E27E0
00007871bd3d0784  jmp 0x00007871BD3D06CF
00007871bd3d0789  call 0x00007871BD2E1570
00007871bd3d078e  jmp 0x00007871BD3D06DB
00007871bd3d0793  call 0x00007871BD2E27E0
00007871bd3d0798  jmp 0x00007871BD3D06F5
00007871bd3d079d  call 0x00007871BD2E1570
00007871bd3d07a2  jmp 0x00007871BD3D0701
00007871bd3d07a7  call 0x00007871BD2E27E0
00007871bd3d07ac  jmp 0x00007871BD3D071B
00007871bd3d07b1  call 0x00007871BD2E1570
00007871bd3d07b6  jmp 0x00007871BD3D0727
00007871bd3d07bb  int3
00007871bd3d07bc  nop [rax], eax
00007871bd3d07c0  mov eax, [r15+0xA0]
00007871bd3d07c7  mov [rsp+0x10], eax
00007871bd3d07cb  xor eax, eax
00007871bd3d07cd  mov r14d, [rsp+0x10]
00007871bd3d07d2  sub r14d, 0x01
00007871bd3d07d6  cmc
00007871bd3d07d7  lahf
00007871bd3d07d8  seto al
00007871bd3d07db  mov [r15+0x108], eax
00007871bd3d07e2  mov r14d, r14d
00007871bd3d07e5  mov [r15+0xA0], r14
00007871bd3d07ec  mov eax, [r15+0x108]
00007871bd3d07f3  sahf
00007871bd3d07f4  jnz 0x00007871BD3D0826
00007871bd3d07f6  cmp dword ptr [r15+0x318], 0x00
00007871bd3d07fe  jz 0x00007871BD3D0900
00007871bd3d0804  nop [rax+rax*1], ax
00007871bd3d080d  nop [rax+rax*1], eax
00007871bd3d0815  mov eax, 0x41028C
00007871bd3d081a  mov [r15+0x100], rax
00007871bd3d0821  jmp 0x00007871BD1FE110
00007871bd3d0826  cmp dword ptr [r15+0x318], 0x00
00007871bd3d082e  jz 0x00007871BD3D0860
00007871bd3d0834  nop [rax+rax*1], ax
00007871bd3d083d  nop [rax+rax*1], eax
00007871bd3d0845  mov eax, 0x410274
00007871bd3d084a  mov [r15+0x100], rax
00007871bd3d0851  jmp 0x00007871BD1FE110
00007871bd3d0856  int3
00007871bd3d0857  int3
00007871bd3d0858  nop [rax+rax*1], eax
00007871bd3d0860  mov rax, [r15+0xF8]
00007871bd3d0867  lea r14, [rax+0x100]
00007871bd3d086e  mov [r15], r14
00007871bd3d0871  mov rax, [r15+0x98]
00007871bd3d0878  mov [r15+0x08], rax
00007871bd3d087c  mov qword ptr [r15+0x10], 0x12C
00007871bd3d0884  mov qword ptr [r15+0xF0], 0x410284
00007871bd3d088f  mov r14d, [r15+0x320]
00007871bd3d0896  mov eax, 0x410284
00007871bd3d089b  mov rcx, 0x7871BD3D07C0
00007871bd3d08a5  mov [r15+r14*8+0x328], rax
00007871bd3d08ad  mov [r15+r14*8+0x368], rcx
00007871bd3d08b5  add r14d, 0x01
00007871bd3d08b9  and r14d, 0x07
00007871bd3d08bd  mov [r15+0x320], r14d
00007871bd3d08c4  cmp dword ptr [r15+0x318], 0x00
00007871bd3d08cc  jz 0x00007871BD3CED70
00007871bd3d08d2  nop [rax+rax*1], ax
00007871bd3d08db  nop [rax+rax*1], eax
00007871bd3d08e3  mov eax, 0x410728
00007871bd3d08e8  mov [r15+0x100], rax
00007871bd3d08ef  jmp 0x00007871BD1FE110
00007871bd3d08f4  int3
00007871bd3d08f5  int3
00007871bd3d08f6  nop [rax+rax*1], ax
00007871bd3d08ff  nop
00007871bd3d0900  mov rax, [r15+0xF8]
00007871bd3d0907  lea r14, [rax+0x120]
00007871bd3d090e  mov r12, [r13+r14*1]
00007871bd3d0913  mov [r15+0x98], r12
00007871bd3d091a  mov qword ptr [r15+0x40], 0x80
00007871bd3d0922  lea r14, [rax+0x100]
00007871bd3d0929  mov [r15], r14
00007871bd3d092c  lea r14, [rax+0x17C]
00007871bd3d0933  mov [r15+0x08], r14
00007871bd3d0937  mov qword ptr [r15+0x10], 0x01
00007871bd3d093f  lea r14, [rax+0x17C]
00007871bd3d0946  mov eax, 0x80
00007871bd3d094b  mov [r13+r14*1], al
00007871bd3d0950  mov qword ptr [r15+0xF0], 0x4102A8
00007871bd3d095b  mov r14d, [r15+0x320]
00007871bd3d0962  mov eax, 0x4102A8
00007871bd3d0967  mov rcx, 0x7871BD3D09E0
00007871bd3d0971  mov [r15+r14*8+0x328], rax
00007871bd3d0979  mov [r15+r14*8+0x368], rcx
00007871bd3d0981  add r14d, 0x01
00007871bd3d0985  and r14d, 0x07
00007871bd3d0989  mov [r15+0x320], r14d
00007871bd3d0990  cmp dword ptr [r15+0x318], 0x00
00007871bd3d0998  jz 0x00007871BD3CED70
00007871bd3d099e  nop [rax+rax*1], ax
00007871bd3d09a7  nop [rax+rax*1], eax
00007871bd3d09af  mov eax, 0x410728
00007871bd3d09b4  mov [r15+0x100], rax
00007871bd3d09bb  jmp 0x00007871BD1FE110
00007871bd3d09c0  int3
00007871bd3d09c1  call 0x00007871BD2E27E0
00007871bd3d09c6  jmp 0x00007871BD3D0913
00007871bd3d09cb  call 0x00007871BD2D5AF0
00007871bd3d09d0  jmp 0x00007871BD3D0950
00007871bd3d09d5  int3
00007871bd3d09d6  nop [rax+rax*1], ax
00007871bd3d09df  nop
00007871bd3d09e0  mov rax, [r15+0xF8]
00007871bd3d09e7  lea r14, [rax+0x168]
00007871bd3d09ee  mov r12, [r13+r14*1]
00007871bd3d09f3  mov [r15+0x40], r12
00007871bd3d09f7  lea r14, [rax+0x178]
00007871bd3d09fe  xor eax, eax
00007871bd3d0a00  mov [r13+r14*1], al
00007871bd3d0a05  xor eax, eax
00007871bd3d0a07  mov r14d, 0x38
00007871bd3d0a0d  cmp r12, r14
00007871bd3d0a10  cmc
00007871bd3d0a11  lahf
00007871bd3d0a12  seto al
00007871bd3d0a15  mov [r15+0x108], eax
00007871bd3d0a1c  mov eax, [r15+0x108]
00007871bd3d0a23  sahf
00007871bd3d0a24  jz 0x00007871BD3D0A56
00007871bd3d0a26  cmp dword ptr [r15+0x318], 0x00
00007871bd3d0a2e  jz 0x00007871BD3D0AA0
00007871bd3d0a34  nop [rax+rax*1], ax
00007871bd3d0a3d  nop [rax+rax*1], eax
00007871bd3d0a45  mov eax, 0x4102B8
00007871bd3d0a4a  mov [r15+0x100], rax
00007871bd3d0a51  jmp 0x00007871BD1FE110
00007871bd3d0a56  cmp dword ptr [r15+0x318], 0x00
00007871bd3d0a5e  jz 0x00007871BD3D0BF0
00007871bd3d0a64  nop [rax+rax*1], ax
00007871bd3d0a6d  nop [rax+rax*1], eax
00007871bd3d0a75  mov eax, 0x4102D4
00007871bd3d0a7a  mov [r15+0x100], rax
00007871bd3d0a81  jmp 0x00007871BD1FE110
00007871bd3d0a86  int3
00007871bd3d0a87  call 0x00007871BD2E27E0
00007871bd3d0a8c  jmp 0x00007871BD3D09F3
00007871bd3d0a91  call 0x00007871BD2D5AF0
00007871bd3d0a96  jmp 0x00007871BD3D0A05
00007871bd3d0a9b  int3
00007871bd3d0a9c  nop [rax], eax
00007871bd3d0aa0  mov rax, [r15+0xF8]
00007871bd3d0aa7  lea r14, [rax+0x100]
00007871bd3d0aae  mov [r15], r14
00007871bd3d0ab1  lea r14, [rax+0x178]
00007871bd3d0ab8  mov [r15+0x08], r14
00007871bd3d0abc  mov qword ptr [r15+0x10], 0x01
00007871bd3d0ac4  mov qword ptr [r15+0xF0], 0x4102C8
00007871bd3d0acf  mov r14d, [r15+0x320]
00007871bd3d0ad6  mov eax, 0x4102C8
00007871bd3d0adb  mov rcx, 0x7871BD3D0B40
00007871bd3d0ae5  mov [r15+r14*8+0x328], rax
00007871bd3d0aed  mov [r15+r14*8+0x368], rcx
00007871bd3d0af5  add r14d, 0x01
00007871bd3d0af9  and r14d, 0x07
00007871bd3d0afd  mov [r15+0x320], r14d
00007871bd3d0b04  cmp dword ptr [r15+0x318], 0x00
00007871bd3d0b0c  jz 0x00007871BD3CED70
00007871bd3d0b12  nop [rax+rax*1], ax
00007871bd3d0b1b  nop [rax+rax*1], eax
00007871bd3d0b23  mov eax, 0x410728
00007871bd3d0b28  mov [r15+0x100], rax
00007871bd3d0b2f  jmp 0x00007871BD1FE110
00007871bd3d0b34  int3
00007871bd3d0b35  int3
00007871bd3d0b36  nop [rax+rax*1], ax
00007871bd3d0b3f  nop
00007871bd3d0b40  mov rax, [r15+0xF8]
00007871bd3d0b47  lea r14, [rax+0x168]
00007871bd3d0b4e  mov rax, [r13+r14*1]
00007871bd3d0b53  mov [r15+0x40], rax
00007871bd3d0b57  mov [rsp+0x10], rax
00007871bd3d0b5c  xor eax, eax
00007871bd3d0b5e  mov r14, [rsp+0x10]
00007871bd3d0b63  mov r12d, 0x38
00007871bd3d0b69  cmp r14, r12
00007871bd3d0b6c  cmc
00007871bd3d0b6d  lahf
00007871bd3d0b6e  seto al
00007871bd3d0b71  mov [r15+0x108], eax
00007871bd3d0b78  mov eax, [r15+0x108]
00007871bd3d0b7f  sahf
00007871bd3d0b80  jnz 0x00007871BD3D0BB2
00007871bd3d0b82  cmp dword ptr [r15+0x318], 0x00
00007871bd3d0b8a  jz 0x00007871BD3D0BF0
00007871bd3d0b90  nop [rax+rax*1], ax
00007871bd3d0b99  nop [rax+rax*1], eax
00007871bd3d0ba1  mov eax, 0x4102D4
00007871bd3d0ba6  mov [r15+0x100], rax
00007871bd3d0bad  jmp 0x00007871BD1FE110
00007871bd3d0bb2  cmp dword ptr [r15+0x318], 0x00
00007871bd3d0bba  jz 0x00007871BD3D0AA0
00007871bd3d0bc0  nop [rax+rax*1], ax
00007871bd3d0bc9  nop [rax+rax*1], eax
00007871bd3d0bd1  mov eax, 0x4102B8
00007871bd3d0bd6  mov [r15+0x100], rax
00007871bd3d0bdd  jmp 0x00007871BD1FE110
00007871bd3d0be2  int3
00007871bd3d0be3  call 0x00007871BD2D59C0
00007871bd3d0be8  jmp 0x00007871BD3D0B53
00007871bd3d0bed  int3
00007871bd3d0bee  nop
00007871bd3d0bf0  mov rax, [r15+0x98]
00007871bd3d0bf7  rorx r14, rax, 0x3D
00007871bd3d0bfd  and r14, 0xFFFFFFFFFFFFFFF8
00007871bd3d0c01  mov rax, [r15+0xF8]
00007871bd3d0c08  lea r12, [rax+0x100]
00007871bd3d0c0f  mov [r15], r12
00007871bd3d0c12  lea r12, [rax+0x170]
00007871bd3d0c19  mov [r15+0x08], r12
00007871bd3d0c1d  mov qword ptr [r15+0x10], 0x08
00007871bd3d0c25  bswap r14
00007871bd3d0c28  mov [r15+0x40], r14
00007871bd3d0c2c  lea r12, [rax+0x170]
00007871bd3d0c33  mov [r13+r12*1], r14
00007871bd3d0c38  mov qword ptr [r15+0xF0], 0x4102F0
00007871bd3d0c43  mov r14d, [r15+0x320]
00007871bd3d0c4a  mov eax, 0x4102F0
00007871bd3d0c4f  mov rcx, 0x7871BD3D0CC0
00007871bd3d0c59  mov [r15+r14*8+0x328], rax
00007871bd3d0c61  mov [r15+r14*8+0x368], rcx
00007871bd3d0c69  add r14d, 0x01
00007871bd3d0c6d  and r14d, 0x07
00007871bd3d0c71  mov [r15+0x320], r14d
00007871bd3d0c78  cmp dword ptr [r15+0x318], 0x00
00007871bd3d0c80  jz 0x00007871BD3CED70
00007871bd3d0c86  nop [rax+rax*1], ax
00007871bd3d0c8f  nop [rax+rax*1], eax
00007871bd3d0c97  mov eax, 0x410728
00007871bd3d0c9c  mov [r15+0x100], rax
00007871bd3d0ca3  jmp 0x00007871BD1FE110
00007871bd3d0ca8  int3
00007871bd3d0ca9  call 0x00007871BD2C3FE0
00007871bd3d0cae  jmp 0x00007871BD3D0C38
00007871bd3d0cb3  int3
00007871bd3d0cb4  nop [rax+rax*1], ax
00007871bd3d0cbd  nop [rax], eax
00007871bd3d0cc0  mov rax, [r15+0xF8]
00007871bd3d0cc7  lea r14, [rax+0x100]
00007871bd3d0cce  mov r12d, [r13+r14*1]
00007871bd3d0cd3  lea r14, [rax+0x104]
00007871bd3d0cda  mov r11d, [r13+r14*1]
00007871bd3d0cdf  mov qword ptr [r15+0x48], 0x430C90
00007871bd3d0ce7  lea r14, [rax+0x108]
00007871bd3d0cee  mov r10d, [r13+r14*1]
00007871bd3d0cf3  lea r14, [rax+0x10C]
00007871bd3d0cfa  mov r9d, [r13+r14*1]
00007871bd3d0cff  bswap r12d
00007871bd3d0d02  bswap r11d
00007871bd3d0d05  mov qword ptr [r15+0xA0], 0x00
00007871bd3d0d10  mov r14d, 0x430C90
00007871bd3d0d16  mov [r13+r14*1], r12d
00007871bd3d0d1b  mov r14d, 0x430C94
00007871bd3d0d21  mov [r13+r14*1], r11d
00007871bd3d0d26  bswap r10d
00007871bd3d0d29  lea r14, [rax+0x110]
00007871bd3d0d30  mov r12d, [r13+r14*1]
00007871bd3d0d35  bswap r9d
00007871bd3d0d38  lea r14, [rax+0x114]
00007871bd3d0d3f  mov r11d, [r13+r14*1]
00007871bd3d0d44  mov qword ptr [r15+0x98], 0x430DFC
00007871bd3d0d4f  mov r14d, 0x430C98
00007871bd3d0d55  mov [r13+r14*1], r10d
00007871bd3d0d5a  mov r14d, 0x430C9C
00007871bd3d0d60  mov [r13+r14*1], r9d
00007871bd3d0d65  bswap r12d
00007871bd3d0d68  lea r14, [rax+0x118]
00007871bd3d0d6f  mov r10d, [r13+r14*1]
00007871bd3d0d74  bswap r11d
00007871bd3d0d77  mov [rsp+0x10], r11d
00007871bd3d0d7c  mov r11d, r11d
00007871bd3d0d7f  mov [r15+0x58], r11
00007871bd3d0d83  lea r14, [rax+0x11C]
00007871bd3d0d8a  mov eax, [r13+r14*1]
00007871bd3d0d8f  mov [rsp+0x20], eax
00007871bd3d0d93  mov eax, eax
00007871bd3d0d95  mov [r15+0x60], rax
00007871bd3d0d99  mov eax, 0x430CA0
00007871bd3d0d9e  mov [r13+rax*1], r12d
00007871bd3d0da3  mov eax, 0x430CA4
00007871bd3d0da8  mov r14d, [rsp+0x10]
00007871bd3d0dad  mov [r13+rax*1], r14d
00007871bd3d0db2  bswap r10d
00007871bd3d0db5  mov [rsp+0x10], r10d
00007871bd3d0dba  mov r10d, r10d
00007871bd3d0dbd  mov [r15+0x40], r10
00007871bd3d0dc1  mov eax, [rsp+0x20]
00007871bd3d0dc5  bswap eax
00007871bd3d0dc7  mov [rsp+0x20], eax
00007871bd3d0dcb  mov eax, eax
00007871bd3d0dcd  mov [r15+0x50], rax
00007871bd3d0dd1  mov eax, 0x430CA8
00007871bd3d0dd6  mov r14d, [rsp+0x10]
00007871bd3d0ddb  mov [r13+rax*1], r14d
00007871bd3d0de0  mov eax, 0x430CAC
00007871bd3d0de5  mov r14d, [rsp+0x20]
00007871bd3d0dea  mov [r13+rax*1], r14d
00007871bd3d0def  mov eax, [r15+0xA0]
00007871bd3d0df6  lea r14d, [eax+0x11]
00007871bd3d0dfb  mov r14d, r14d
00007871bd3d0dfe  mov [r15], r14
00007871bd3d0e01  mov qword ptr [r15+0xF0], 0x41035C
00007871bd3d0e0c  mov r14d, [r15+0x320]
00007871bd3d0e13  mov eax, 0x41035C
00007871bd3d0e18  mov rcx, 0x7871BD3D0F90
00007871bd3d0e22  mov [r15+r14*8+0x328], rax
00007871bd3d0e2a  mov [r15+r14*8+0x368], rcx
00007871bd3d0e32  add r14d, 0x01
00007871bd3d0e36  and r14d, 0x07
00007871bd3d0e3a  mov [r15+0x320], r14d
00007871bd3d0e41  cmp dword ptr [r15+0x318], 0x00
00007871bd3d0e49  jz 0x00007871BD3D0F20
00007871bd3d0e4f  nop [rax+rax*1], ax
00007871bd3d0e58  nop [rax+rax*1], eax
00007871bd3d0e60  mov eax, 0x4109A4
00007871bd3d0e65  mov [r15+0x100], rax
00007871bd3d0e6c  jmp 0x00007871BD1FE110
00007871bd3d0e71  int3
00007871bd3d0e72  call 0x00007871BD2E26A0
00007871bd3d0e77  jmp 0x00007871BD3D0CD3
00007871bd3d0e7c  call 0x00007871BD2E1430
00007871bd3d0e81  jmp 0x00007871BD3D0CDF
00007871bd3d0e86  call 0x00007871BD2E01C0
00007871bd3d0e8b  jmp 0x00007871BD3D0CF3
00007871bd3d0e90  call 0x00007871BD2DEF50
00007871bd3d0e95  jmp 0x00007871BD3D0CFF
00007871bd3d0e9a  call 0x00007871BD2E2BA0
00007871bd3d0e9f  jmp 0x00007871BD3D0D1B
00007871bd3d0ea4  call 0x00007871BD2E1920
00007871bd3d0ea9  jmp 0x00007871BD3D0D26
00007871bd3d0eae  call 0x00007871BD2E26A0
00007871bd3d0eb3  jmp 0x00007871BD3D0D35
00007871bd3d0eb8  call 0x00007871BD2E1430
00007871bd3d0ebd  jmp 0x00007871BD3D0D44
00007871bd3d0ec2  call 0x00007871BD2E06B0
00007871bd3d0ec7  jmp 0x00007871BD3D0D5A
00007871bd3d0ecc  call 0x00007871BD2DF440
00007871bd3d0ed1  jmp 0x00007871BD3D0D65
00007871bd3d0ed6  call 0x00007871BD2E01C0
00007871bd3d0edb  jmp 0x00007871BD3D0D74
00007871bd3d0ee0  call 0x00007871BD2D5890
00007871bd3d0ee5  jmp 0x00007871BD3D0D8F
00007871bd3d0eea  call 0x00007871BD20BAE0
00007871bd3d0eef  jmp 0x00007871BD3D0DA3
00007871bd3d0ef4  call 0x00007871BD20DFE0
00007871bd3d0ef9  jmp 0x00007871BD3D0DB2
00007871bd3d0efe  call 0x00007871BD20DFE0
00007871bd3d0f03  jmp 0x00007871BD3D0DE0
00007871bd3d0f08  call 0x00007871BD20DFE0
00007871bd3d0f0d  jmp 0x00007871BD3D0DEF
00007871bd3d0f12  int3
00007871bd3d0f13  nop [rax+rax*1], ax
00007871bd3d0f1c  nop [rax], eax
00007871bd3d0f20  mov eax, [r15]
00007871bd3d0f23  mov [rsp+0x10], eax
00007871bd3d0f27  shr eax, 0x10
00007871bd3d0f2a  mov r14d, [rsp+0x10]
00007871bd3d0f2f  xor r14d, eax
00007871bd3d0f32  imul r14d, r14d, 0x7FEB352D
00007871bd3d0f39  mov eax, 0x846CA68B
00007871bd3d0f3e  mov eax, eax
00007871bd3d0f40  mov [r15+0x48], rax
00007871bd3d0f44  mov [rsp+0x10], r14d
00007871bd3d0f49  shr r14d, 0x0F
00007871bd3d0f4d  mov eax, [rsp+0x10]
00007871bd3d0f51  xor eax, r14d
00007871bd3d0f54  imul eax, eax, 0x846CA68B
00007871bd3d0f5a  mov [rsp+0x10], eax
00007871bd3d0f5e  mov eax, eax
00007871bd3d0f60  mov [r15+0x40], rax
00007871bd3d0f64  mov eax, [rsp+0x10]
00007871bd3d0f68  shr eax, 0x10
00007871bd3d0f6b  mov r14d, [rsp+0x10]
00007871bd3d0f70  xor r14d, eax
00007871bd3d0f73  mov r14d, r14d
00007871bd3d0f76  mov [r15], r14
00007871bd3d0f79  mov rax, [r15+0xF0]
00007871bd3d0f80  mov [r15+0x100], rax
00007871bd3d0f87  jmp 0x00007871BD3CE5C0
00007871bd3d0f8c  int3
00007871bd3d0f8d  int3
00007871bd3d0f8e  nop
00007871bd3d0f90  mov rax, [r15+0xA0]
00007871bd3d0f97  mov [rsp+0x10], rax
00007871bd3d0f9c  shl rax, 0x02
00007871bd3d0fa0  mov r14, [r15+0x98]
00007871bd3d0fa7  lea r12, [r14+rax*1]
00007871bd3d0fab  mov eax, [r15]
00007871bd3d0fae  mov [r13+r12*1], eax
00007871bd3d0fb3  mov rax, [rsp+0x10]
00007871bd3d0fb8  lea r14, [rax+0x01]
00007871bd3d0fbc  mov [r15+0xA0], r14
00007871bd3d0fc3  xor eax, eax
00007871bd3d0fc5  mov r12d, 0x400
00007871bd3d0fcb  cmp r14, r12
00007871bd3d0fce  cmc
00007871bd3d0fcf  lahf
00007871bd3d0fd0  seto al
00007871bd3d0fd3  mov [r15+0x108], eax
00007871bd3d0fda  mov eax, [r15+0x108]
00007871bd3d0fe1  sahf
00007871bd3d0fe2  jnz 0x00007871BD3D1014
00007871bd3d0fe4  cmp dword ptr [r15+0x318], 0x00
00007871bd3d0fec  jz 0x00007871BD3D10E0
00007871bd3d0ff2  nop [rax+rax*1], ax
00007871bd3d0ffb  nop [rax+rax*1], eax
00007871bd3d1003  mov eax, 0x41036C
00007871bd3d1008  mov [r15+0x100], rax
00007871bd3d100f  jmp 0x00007871BD1FE110
00007871bd3d1014  cmp dword ptr [r15+0x318], 0x00
00007871bd3d101c  jz 0x00007871BD3D1050
00007871bd3d1022  nop [rax+rax*1], ax
00007871bd3d102b  nop [rax+rax*1], eax
00007871bd3d1033  mov eax, 0x410354
00007871bd3d1038  mov [r15+0x100], rax
00007871bd3d103f  jmp 0x00007871BD1FE110
00007871bd3d1044  int3
00007871bd3d1045  call 0x00007871BD2B4B70
00007871bd3d104a  jmp 0x00007871BD3D0FB3
00007871bd3d104f  int3
00007871bd3d1050  mov eax, [r15+0xA0]
00007871bd3d1057  lea r14d, [eax+0x11]
00007871bd3d105c  mov r14d, r14d
00007871bd3d105f  mov [r15], r14
00007871bd3d1062  mov qword ptr [r15+0xF0], 0x41035C
00007871bd3d106d  mov r14d, [r15+0x320]
00007871bd3d1074  mov eax, 0x41035C
00007871bd3d1079  mov rcx, 0x7871BD3D0F90
00007871bd3d1083  mov [r15+r14*8+0x328], rax
00007871bd3d108b  mov [r15+r14*8+0x368], rcx
00007871bd3d1093  add r14d, 0x01
00007871bd3d1097  and r14d, 0x07
00007871bd3d109b  mov [r15+0x320], r14d
00007871bd3d10a2  cmp dword ptr [r15+0x318], 0x00
00007871bd3d10aa  jz 0x00007871BD3D0F20
00007871bd3d10b0  nop [rax+rax*1], ax
00007871bd3d10b9  nop [rax+rax*1], eax
00007871bd3d10c1  mov eax, 0x4109A4
00007871bd3d10c6  mov [r15+0x100], rax
00007871bd3d10cd  jmp 0x00007871BD1FE110
00007871bd3d10d2  int3
00007871bd3d10d3  int3
00007871bd3d10d4  nop [rax+rax*1], ax
00007871bd3d10dd  nop [rax], eax
00007871bd3d10e0  mov qword ptr [r15+0x40], 0x01
00007871bd3d10e8  cmp dword ptr [r15+0x318], 0x00
00007871bd3d10f0  jz 0x00007871BD3D1120
00007871bd3d10f6  nop [rax+rax*1], ax
00007871bd3d10ff  nop [rax+rax*1], eax
00007871bd3d1107  mov eax, 0x410388
00007871bd3d110c  mov [r15+0x100], rax
00007871bd3d1113  jmp 0x00007871BD1FE110
00007871bd3d1118  int3
00007871bd3d1119  int3
00007871bd3d111a  nop [rax+rax*1], ax
00007871bd3d1120  mov rax, [r15+0x40]
00007871bd3d1124  mov [rsp+0x10], rax
00007871bd3d1129  shl rax, 0x02
00007871bd3d112d  mov r14, [r15+0x98]
00007871bd3d1134  lea r12, [r14+rax*1]
00007871bd3d1138  mov eax, [r13+r12*1]
00007871bd3d113d  mov [rsp+0x20], eax
00007871bd3d1141  mov eax, eax
00007871bd3d1143  mov [r15+0x48], rax
00007871bd3d1147  mov rax, [rsp+0x10]
00007871bd3d114c  mov [r15+0x50], rax
00007871bd3d1150  mov eax, [r15+0x50]
00007871bd3d1154  lea r12d, [eax-0x01]
00007871bd3d1159  mov r12d, r12d
00007871bd3d115c  mov [r15+0x58], r12
00007871bd3d1160  mov rax, [r15+0x58]
00007871bd3d1164  mov r12d, eax
00007871bd3d1167  mov r12d, r12d
00007871bd3d116a  shl r12, 0x02
00007871bd3d116e  lea rax, [r14+r12*1]
00007871bd3d1172  mov r14d, [r13+rax*1]
00007871bd3d1177  mov [rsp+0x10], r14d
00007871bd3d117c  mov r14d, r14d
00007871bd3d117f  mov [r15+0x60], r14
00007871bd3d1183  xor eax, eax
00007871bd3d1185  mov r14d, [rsp+0x10]
00007871bd3d118a  mov r12d, [rsp+0x20]
00007871bd3d118f  cmp r14d, r12d
00007871bd3d1192  cmc
00007871bd3d1193  lahf
00007871bd3d1194  seto al
00007871bd3d1197  mov [r15+0x108], eax
00007871bd3d119e  mov eax, [r15+0x108]
00007871bd3d11a5  sahf
00007871bd3d11a6  cmc
00007871bd3d11a7  jbe 0x00007871BD3D11D9
00007871bd3d11a9  cmp dword ptr [r15+0x318], 0x00
00007871bd3d11b1  jz 0x00007871BD3D1220
00007871bd3d11b7  nop [rax+rax*1], ax
00007871bd3d11c0  nop [rax+rax*1], eax
00007871bd3d11c8  mov eax, 0x4103A0
00007871bd3d11cd  mov [r15+0x100], rax
00007871bd3d11d4  jmp 0x00007871BD1FE110
00007871bd3d11d9  cmp dword ptr [r15+0x318], 0x00
00007871bd3d11e1  jz 0x00007871BD3D14C0
00007871bd3d11e7  nop [rax+rax*1], ax
00007871bd3d11f0  nop [rax+rax*1], eax
00007871bd3d11f8  mov eax, 0x410378
00007871bd3d11fd  mov [r15+0x100], rax
00007871bd3d1204  jmp 0x00007871BD1FE110
00007871bd3d1209  int3
00007871bd3d120a  call 0x00007871BD2B4690
00007871bd3d120f  jmp 0x00007871BD3D113D
00007871bd3d1214  call 0x00007871BD20DAE0
00007871bd3d1219  jmp 0x00007871BD3D1177
00007871bd3d121e  int3
00007871bd3d121f  nop
00007871bd3d1220  mov rax, [r15+0x50]
00007871bd3d1224  mov [rsp+0x10], rax
00007871bd3d1229  shl rax, 0x02
00007871bd3d122d  mov r14, [r15+0x98]
00007871bd3d1234  lea r12, [r14+rax*1]
00007871bd3d1238  mov eax, [r15+0x60]
00007871bd3d123c  mov [r13+r12*1], eax
00007871bd3d1241  mov rax, [rsp+0x10]
00007871bd3d1246  lea r14, [rax-0x01]
00007871bd3d124a  mov [r15+0x50], r14
00007871bd3d124e  mov rax, [r15+0x58]
00007871bd3d1252  test rax, rax
00007871bd3d1255  setz al
00007871bd3d1258  movzx rax, al
00007871bd3d125c  mov [rsp+0x414], al
00007871bd3d1263  cmp byte ptr [rsp+0x414], 0x00
00007871bd3d126b  jz 0x00007871BD3D129D
00007871bd3d126d  cmp dword ptr [r15+0x318], 0x00
00007871bd3d1275  jz 0x00007871BD3D12E0
00007871bd3d127b  nop [rax+rax*1], ax
00007871bd3d1284  nop [rax+rax*1], eax
00007871bd3d128c  mov eax, 0x4103AC
00007871bd3d1291  mov [r15+0x100], rax
00007871bd3d1298  jmp 0x00007871BD1FE110
00007871bd3d129d  cmp dword ptr [r15+0x318], 0x00
00007871bd3d12a5  jz 0x00007871BD3D13E0
00007871bd3d12ab  nop [rax+rax*1], ax
00007871bd3d12b4  nop [rax+rax*1], eax
00007871bd3d12bc  mov eax, 0x410390
00007871bd3d12c1  mov [r15+0x100], rax
00007871bd3d12c8  jmp 0x00007871BD1FE110
00007871bd3d12cd  int3
00007871bd3d12ce  call 0x00007871BD2B4B70
00007871bd3d12d3  jmp 0x00007871BD3D1241
00007871bd3d12d8  int3
00007871bd3d12d9  nop [rax], eax
00007871bd3d12e0  cmp dword ptr [r15+0x318], 0x00
00007871bd3d12e8  jz 0x00007871BD3D1320
00007871bd3d12ee  nop [rax+rax*1], ax
00007871bd3d12f7  nop [rax+rax*1], eax
00007871bd3d12ff  mov eax, 0x410374
00007871bd3d1304  mov [r15+0x100], rax
00007871bd3d130b  jmp 0x00007871BD1FE110
00007871bd3d1310  int3
00007871bd3d1311  int3
00007871bd3d1312  nop [rax+rax*1], ax
00007871bd3d131b  nop [rax+rax*1], eax
00007871bd3d1320  mov qword ptr [r15+0x50], 0x00
00007871bd3d1328  mov rax, [r15+0x40]
00007871bd3d132c  lea r14, [rax+0x01]
00007871bd3d1330  mov [r15+0x40], r14
00007871bd3d1334  mov rax, [r15+0x98]
00007871bd3d133b  mov r12d, [r15+0x48]
00007871bd3d133f  mov [r13+rax*1], r12d
00007871bd3d1344  xor eax, eax
00007871bd3d1346  mov r12d, 0x400
00007871bd3d134c  cmp r14, r12
00007871bd3d134f  cmc
00007871bd3d1350  lahf
00007871bd3d1351  seto al
00007871bd3d1354  mov [r15+0x108], eax
00007871bd3d135b  mov eax, [r15+0x108]
00007871bd3d1362  sahf
00007871bd3d1363  jz 0x00007871BD3D1395
00007871bd3d1365  cmp dword ptr [r15+0x318], 0x00
00007871bd3d136d  jz 0x00007871BD3D1120
00007871bd3d1373  nop [rax+rax*1], ax
00007871bd3d137c  nop [rax+rax*1], eax
00007871bd3d1384  mov eax, 0x410388
00007871bd3d1389  mov [r15+0x100], rax
00007871bd3d1390  jmp 0x00007871BD1FE110
00007871bd3d1395  cmp dword ptr [r15+0x318], 0x00
00007871bd3d139d  jz 0x00007871BD3D1580
00007871bd3d13a3  nop [rax+rax*1], ax
00007871bd3d13ac  nop [rax+rax*1], eax
00007871bd3d13b4  mov eax, 0x4103B0
00007871bd3d13b9  mov [r15+0x100], rax
00007871bd3d13c0  jmp 0x00007871BD1FE110
00007871bd3d13c5  int3
00007871bd3d13c6  call 0x00007871BD20BAE0
00007871bd3d13cb  jmp 0x00007871BD3D1344
00007871bd3d13d0  int3
00007871bd3d13d1  nop [rax+rax*1], ax
00007871bd3d13da  nop [rax+rax*1], ax
00007871bd3d13e0  mov eax, [r15+0x50]
00007871bd3d13e4  lea r14d, [eax-0x01]
00007871bd3d13e9  mov r14d, r14d
00007871bd3d13ec  mov [r15+0x58], r14
00007871bd3d13f0  mov rax, [r15+0x58]
00007871bd3d13f4  mov r14d, eax
00007871bd3d13f7  mov r14d, r14d
00007871bd3d13fa  shl r14, 0x02
00007871bd3d13fe  mov rax, [r15+0x98]
00007871bd3d1405  lea r12, [rax+r14*1]
00007871bd3d1409  mov eax, [r13+r12*1]
00007871bd3d140e  mov [rsp+0x10], eax
00007871bd3d1412  mov eax, eax
00007871bd3d1414  mov [r15+0x60], rax
00007871bd3d1418  mov eax, [r15+0x48]
00007871bd3d141c  mov [rsp+0x20], eax
00007871bd3d1420  xor eax, eax
00007871bd3d1422  mov r14d, [rsp+0x10]
00007871bd3d1427  mov r12d, [rsp+0x20]
00007871bd3d142c  cmp r14d, r12d
00007871bd3d142f  cmc
00007871bd3d1430  lahf
00007871bd3d1431  seto al
00007871bd3d1434  mov [r15+0x108], eax
00007871bd3d143b  mov eax, [r15+0x108]
00007871bd3d1442  sahf
00007871bd3d1443  cmc
00007871bd3d1444  jbe 0x00007871BD3D1476
00007871bd3d1446  cmp dword ptr [r15+0x318], 0x00
00007871bd3d144e  jz 0x00007871BD3D1220
00007871bd3d1454  nop [rax+rax*1], ax
00007871bd3d145d  nop [rax+rax*1], eax
00007871bd3d1465  mov eax, 0x4103A0
00007871bd3d146a  mov [r15+0x100], rax
00007871bd3d1471  jmp 0x00007871BD1FE110
00007871bd3d1476  cmp dword ptr [r15+0x318], 0x00
00007871bd3d147e  jz 0x00007871BD3D14C0
00007871bd3d1484  nop [rax+rax*1], ax
00007871bd3d148d  nop [rax+rax*1], eax
00007871bd3d1495  mov eax, 0x410378
00007871bd3d149a  mov [r15+0x100], rax
00007871bd3d14a1  jmp 0x00007871BD1FE110
00007871bd3d14a6  int3
00007871bd3d14a7  call 0x00007871BD2B4690
00007871bd3d14ac  jmp 0x00007871BD3D140E
00007871bd3d14b1  int3
00007871bd3d14b2  nop [rax+rax*1], ax
00007871bd3d14bb  nop [rax+rax*1], eax
00007871bd3d14c0  mov rax, [r15+0x40]
00007871bd3d14c4  lea r14, [rax+0x01]
00007871bd3d14c8  mov [r15+0x40], r14
00007871bd3d14cc  mov rax, [r15+0x50]
00007871bd3d14d0  mov r12d, eax
00007871bd3d14d3  mov r12d, r12d
00007871bd3d14d6  shl r12, 0x02
00007871bd3d14da  mov rax, [r15+0x98]
00007871bd3d14e1  lea r11, [rax+r12*1]
00007871bd3d14e5  mov eax, [r15+0x48]
00007871bd3d14e9  mov [r13+r11*1], eax
00007871bd3d14ee  xor eax, eax
00007871bd3d14f0  mov r12d, 0x400
00007871bd3d14f6  cmp r14, r12
00007871bd3d14f9  cmc
00007871bd3d14fa  lahf
00007871bd3d14fb  seto al
00007871bd3d14fe  mov [r15+0x108], eax
00007871bd3d1505  mov eax, [r15+0x108]
00007871bd3d150c  sahf
00007871bd3d150d  jz 0x00007871BD3D153F
00007871bd3d150f  cmp dword ptr [r15+0x318], 0x00
00007871bd3d1517  jz 0x00007871BD3D1120
00007871bd3d151d  nop [rax+rax*1], ax
00007871bd3d1526  nop [rax+rax*1], eax
00007871bd3d152e  mov eax, 0x410388
00007871bd3d1533  mov [r15+0x100], rax
00007871bd3d153a  jmp 0x00007871BD1FE110
00007871bd3d153f  cmp dword ptr [r15+0x318], 0x00
00007871bd3d1547  jz 0x00007871BD3D1580
00007871bd3d154d  nop [rax+rax*1], ax
00007871bd3d1556  nop [rax+rax*1], eax
00007871bd3d155e  mov eax, 0x4103B0
00007871bd3d1563  mov [r15+0x100], rax
00007871bd3d156a  jmp 0x00007871BD1FE110
00007871bd3d156f  int3
00007871bd3d1570  call 0x00007871BD2A4270
00007871bd3d1575  jmp 0x00007871BD3D14EE
00007871bd3d157a  int3
00007871bd3d157b  nop [rax+rax*1], eax
00007871bd3d1580  mov qword ptr [r15+0x40], 0x430000
00007871bd3d1588  mov eax, 0x430CB0
00007871bd3d158d  mov r14, [r13+rax*1]
00007871bd3d1592  mov rax, [r15+0x98]
00007871bd3d1599  mov r12d, [r13+rax*1]
00007871bd3d159e  lea r11, [rax+0x04]
00007871bd3d15a2  mov eax, [r13+r11*1]
00007871bd3d15a7  mov r12d, r12d
00007871bd3d15aa  mov [r15+0x68], r12
00007871bd3d15ae  mov eax, eax
00007871bd3d15b0  mov [r15+0x60], rax
00007871bd3d15b4  mov rax, [r15+0x68]
00007871bd3d15b8  mov [r15+0x68], rax
00007871bd3d15bc  mov qword ptr [r15+0x58], 0x02
00007871bd3d15c4  mov [rsp+0x10], rax
00007871bd3d15c9  xor eax, eax
00007871bd3d15cb  mov r12d, 0x02
00007871bd3d15d1  mov r11d, 0x400
00007871bd3d15d7  cmp r12, r11
00007871bd3d15da  cmc
00007871bd3d15db  lahf
00007871bd3d15dc  seto al
00007871bd3d15df  mov [r15+0x108], eax
00007871bd3d15e6  mov rax, [r15+0x60]
00007871bd3d15ea  mov r12d, 0x02
00007871bd3d15f0  imul rax, r12
00007871bd3d15f4  mov [r15+0x50], rax
00007871bd3d15f8  mov rax, [rsp+0x10]
00007871bd3d15fd  lea r12, [rax+r14*1]
00007871bd3d1601  mov [r15+0x48], r12
00007871bd3d1605  mov eax, [r15+0x108]
00007871bd3d160c  sahf
00007871bd3d160d  jnz 0x00007871BD3D163F
00007871bd3d160f  cmp dword ptr [r15+0x318], 0x00
00007871bd3d1617  jz 0x00007871BD3D17B0
00007871bd3d161d  nop [rax+rax*1], ax
00007871bd3d1626  nop [rax+rax*1], eax
00007871bd3d162e  mov eax, 0x4103E0
00007871bd3d1633  mov [r15+0x100], rax
00007871bd3d163a  jmp 0x00007871BD1FE110
00007871bd3d163f  cmp dword ptr [r15+0x318], 0x00
00007871bd3d1647  jz 0x00007871BD3D1690
00007871bd3d164d  nop [rax+rax*1], ax
00007871bd3d1656  nop [rax+rax*1], eax
00007871bd3d165e  mov eax, 0x4103C0
00007871bd3d1663  mov [r15+0x100], rax
00007871bd3d166a  jmp 0x00007871BD1FE110
00007871bd3d166f  int3
00007871bd3d1670  call 0x00007871BD20DC20
00007871bd3d1675  jmp 0x00007871BD3D1592
00007871bd3d167a  call 0x00007871BD20B5E0
00007871bd3d167f  jmp 0x00007871BD3D159E
00007871bd3d1684  call 0x00007871BD2A3D90
00007871bd3d1689  jmp 0x00007871BD3D15A7
00007871bd3d168e  int3
00007871bd3d168f  nop
00007871bd3d1690  mov rax, [r15+0x98]
00007871bd3d1697  mov r14, [r15+0x58]
00007871bd3d169b  mov [rsp+0x10], r14
00007871bd3d16a0  shl r14, 0x02
00007871bd3d16a4  lea r12, [rax+r14*1]
00007871bd3d16a8  mov eax, [r13+r12*1]
00007871bd3d16ad  lea r14, [r12+0x04]
00007871bd3d16b2  mov r12d, [r13+r14*1]
00007871bd3d16b7  mov eax, eax
00007871bd3d16b9  mov [r15+0x68], rax
00007871bd3d16bd  mov r12d, r12d
00007871bd3d16c0  mov [r15+0x60], r12
00007871bd3d16c4  mov rax, [r15+0x68]
00007871bd3d16c8  mov [rsp+0x20], rax
00007871bd3d16cd  mov r14, [rsp+0x10]
00007871bd3d16d2  imul rax, r14
00007871bd3d16d6  mov r12, [rsp+0x20]
00007871bd3d16db  lea r11, [r12+rax*1]
00007871bd3d16df  mov [r15+0x68], r11
00007871bd3d16e3  lea rax, [r14+0x02]
00007871bd3d16e7  mov [r15+0x58], rax
00007871bd3d16eb  mov [rsp+0x10], rax
00007871bd3d16f0  xor eax, eax
00007871bd3d16f2  mov r14, [rsp+0x10]
00007871bd3d16f7  mov r12d, 0x400
00007871bd3d16fd  cmp r14, r12
00007871bd3d1700  cmc
00007871bd3d1701  lahf
00007871bd3d1702  seto al
00007871bd3d1705  mov [r15+0x108], eax
00007871bd3d170c  mov rax, [r15+0x50]
00007871bd3d1710  mov r12, [r15+0x60]
00007871bd3d1714  imul r14, r12
00007871bd3d1718  lea r12, [rax+r14*1]
00007871bd3d171c  mov [r15+0x50], r12
00007871bd3d1720  mov rax, [r15+0x48]
00007871bd3d1724  lea r14, [r11+rax*1]
00007871bd3d1728  mov [r15+0x48], r14
00007871bd3d172c  mov eax, [r15+0x108]
00007871bd3d1733  sahf
00007871bd3d1734  jnz 0x00007871BD3D1766
00007871bd3d1736  cmp dword ptr [r15+0x318], 0x00
00007871bd3d173e  jz 0x00007871BD3D17B0
00007871bd3d1744  nop [rax+rax*1], ax
00007871bd3d174d  nop [rax+rax*1], eax
00007871bd3d1755  mov eax, 0x4103E0
00007871bd3d175a  mov [r15+0x100], rax
00007871bd3d1761  jmp 0x00007871BD1FE110
00007871bd3d1766  cmp dword ptr [r15+0x318], 0x00
00007871bd3d176e  jz 0x00007871BD3D1690
00007871bd3d1774  nop [rax+rax*1], ax
00007871bd3d177d  nop [rax+rax*1], eax
00007871bd3d1785  mov eax, 0x4103C0
00007871bd3d178a  mov [r15+0x100], rax
00007871bd3d1791  jmp 0x00007871BD1FE110
00007871bd3d1796  int3
00007871bd3d1797  call 0x00007871BD2B4690
00007871bd3d179c  jmp 0x00007871BD3D16AD
00007871bd3d17a1  call 0x00007871BD2E26A0
00007871bd3d17a6  jmp 0x00007871BD3D16B7
00007871bd3d17ab  int3
00007871bd3d17ac  nop [rax], eax
00007871bd3d17b0  mov qword ptr [r15+0x98], 0x00
00007871bd3d17bb  mov rax, [r15+0x50]
00007871bd3d17bf  mov r14, [r15+0x48]
00007871bd3d17c3  lea r12, [rax+r14*1]
00007871bd3d17c7  mov [r15+0x48], r12
00007871bd3d17cb  mov rax, [r15+0x40]
00007871bd3d17cf  lea r14, [rax+0xCB0]
00007871bd3d17d6  mov [r13+r14*1], r12
00007871bd3d17db  mov qword ptr [r15], 0x01
00007871bd3d17e2  mov qword ptr [r15+0xF0], 0x4103F8
00007871bd3d17ed  mov r14d, [r15+0x320]
00007871bd3d17f4  mov eax, 0x4103F8
00007871bd3d17f9  mov rcx, 0x7871BD3D1860
00007871bd3d1803  mov [r15+r14*8+0x328], rax
00007871bd3d180b  mov [r15+r14*8+0x368], rcx
00007871bd3d1813  add r14d, 0x01
00007871bd3d1817  and r14d, 0x07
00007871bd3d181b  mov [r15+0x320], r14d
00007871bd3d1822  cmp dword ptr [r15+0x318], 0x00
00007871bd3d182a  jz 0x00007871BD3D0F20
00007871bd3d1830  nop [rax+rax*1], ax
00007871bd3d1839  nop [rax+rax*1], eax
00007871bd3d1841  mov eax, 0x4109A4
00007871bd3d1846  mov [r15+0x100], rax
00007871bd3d184d  jmp 0x00007871BD1FE110
00007871bd3d1852  int3
00007871bd3d1853  call 0x00007871BD2E2CE0
00007871bd3d1858  jmp 0x00007871BD3D17DB
00007871bd3d185d  int3
00007871bd3d185e  nop
00007871bd3d1860  mov eax, [r15+0x98]
00007871bd3d1867  lea r14d, [eax+0x01]
00007871bd3d186c  mov [rsp+0x10], r14d
00007871bd3d1871  mov r14d, r14d
00007871bd3d1874  mov [r15+0x98], r14
00007871bd3d187b  xor eax, eax
00007871bd3d187d  mov r14d, [rsp+0x10]
00007871bd3d1882  cmp r14d, 0x10000
00007871bd3d1889  cmc
00007871bd3d188a  lahf
00007871bd3d188b  seto al
00007871bd3d188e  mov [r15+0x108], eax
00007871bd3d1895  mov eax, [r15+0x108]
00007871bd3d189c  sahf
00007871bd3d189d  jnz 0x00007871BD3D18CF
00007871bd3d189f  cmp dword ptr [r15+0x318], 0x00
00007871bd3d18a7  jz 0x00007871BD3D19A0
00007871bd3d18ad  nop [rax+rax*1], ax
00007871bd3d18b6  nop [rax+rax*1], eax
00007871bd3d18be  mov eax, 0x410404
00007871bd3d18c3  mov [r15+0x100], rax
00007871bd3d18ca  jmp 0x00007871BD1FE110
00007871bd3d18cf  cmp dword ptr [r15+0x318], 0x00
00007871bd3d18d7  jz 0x00007871BD3D1910
00007871bd3d18dd  nop [rax+rax*1], ax
00007871bd3d18e6  nop [rax+rax*1], eax
00007871bd3d18ee  mov eax, 0x4103F0
00007871bd3d18f3  mov [r15+0x100], rax
00007871bd3d18fa  jmp 0x00007871BD1FE110
00007871bd3d18ff  int3
00007871bd3d1900  int3
00007871bd3d1901  nop [rax+rax*1], ax
00007871bd3d190a  nop [rax+rax*1], ax
00007871bd3d1910  mov eax, [r15]
00007871bd3d1913  mov r14d, [r15+0x98]
00007871bd3d191a  lea r12d, [eax+r14d*1]
00007871bd3d191f  mov r12d, r12d
00007871bd3d1922  mov [r15], r12
00007871bd3d1925  mov qword ptr [r15+0xF0], 0x4103F8
00007871bd3d1930  mov r14d, [r15+0x320]
00007871bd3d1937  mov eax, 0x4103F8
00007871bd3d193c  mov rcx, 0x7871BD3D1860
00007871bd3d1946  mov [r15+r14*8+0x328], rax
00007871bd3d194e  mov [r15+r14*8+0x368], rcx
00007871bd3d1956  add r14d, 0x01
00007871bd3d195a  and r14d, 0x07
00007871bd3d195e  mov [r15+0x320], r14d
00007871bd3d1965  cmp dword ptr [r15+0x318], 0x00
00007871bd3d196d  jz 0x00007871BD3D0F20
00007871bd3d1973  nop [rax+rax*1], ax
00007871bd3d197c  nop [rax+rax*1], eax
00007871bd3d1984  mov eax, 0x4109A4
00007871bd3d1989  mov [r15+0x100], rax
00007871bd3d1990  jmp 0x00007871BD1FE110
00007871bd3d1995  int3
00007871bd3d1996  int3
00007871bd3d1997  nop [rax+rax*1], ax
00007871bd3d19a0  vmovaps xmm1, [0x00007871BCFFE010]
00007871bd3d19a8  movq xmm1, xmm1
00007871bd3d19ac  movaps [r15+0x110], xmm1
00007871bd3d19b4  mov eax, 0x420B10
00007871bd3d19b9  mov r14, [r13+rax*1]
00007871bd3d19be  movq xmm1, r14
00007871bd3d19c3  movaps [r15+0x120], xmm1
00007871bd3d19cb  vmovaps xmm1, [0x00007871BCFFE020]
00007871bd3d19d3  movq xmm1, xmm1
00007871bd3d19d7  movaps [r15+0x140], xmm1
00007871bd3d19df  vmovaps xmm1, [0x00007871BCFFE030]
00007871bd3d19e7  vpbroadcastq xmm1, xmm1
00007871bd3d19ec  movaps [r15+0x150], xmm1
00007871bd3d19f4  mov qword ptr [r15+0x40], 0x02
00007871bd3d19fc  vmovaps xmm15, [0x00007871BCFFE040]
00007871bd3d1a04  movq xmm15, xmm15
00007871bd3d1a09  movaps [r15+0x160], xmm15
00007871bd3d1a11  vmovaps xmm15, [0x00007871BCFFE050]
00007871bd3d1a19  vpbroadcastq xmm15, xmm15
00007871bd3d1a1e  movaps [r15+0x130], xmm15
00007871bd3d1a26  mov rax, [r15+0x40]
00007871bd3d1a2a  vmovq xmm14, rax
00007871bd3d1a2f  vpbroadcastq xmm14, xmm14
00007871bd3d1a34  movaps [r15+0x170], xmm14
00007871bd3d1a3c  mov eax, 0x420A40
00007871bd3d1a41  movups xmm13, [r13+rax*1]
00007871bd3d1a47  mov qword ptr [r15+0x40], 0x431E00
00007871bd3d1a4f  mov eax, [r15]
00007871bd3d1a52  mov r14d, 0x430CB8
00007871bd3d1a58  mov [r13+r14*1], eax
00007871bd3d1a5d  mov qword ptr [r15+0x50], 0x432000
00007871bd3d1a65  vpmovqd xmm12, xmm13
00007871bd3d1a6b  pxor xmm11, xmm11
00007871bd3d1a70  punpcklqdq xmm12, xmm11
00007871bd3d1a75  movaps [r15+0x210], xmm12
00007871bd3d1a7d  movq xmm12, qword ptr [r15+0x140]
00007871bd3d1a86  movq xmm11, qword ptr [r15+0x120]
00007871bd3d1a8f  psubd xmm12, xmm11
00007871bd3d1a94  movq xmm12, xmm12
00007871bd3d1a99  paddq xmm13, xmm14
00007871bd3d1a9e  movaps [r15+0x180], xmm13
00007871bd3d1aa6  movq xmm14, qword ptr [r15+0x160]
00007871bd3d1aaf  paddd xmm11, xmm14
00007871bd3d1ab4  movq xmm11, xmm11
00007871bd3d1ab9  movq xmm11, xmm11
00007871bd3d1abe  movaps [r15+0x120], xmm11
00007871bd3d1ac6  pmovzxdq xmm12, xmm12
00007871bd3d1acc  psllq xmm12, 0x00
00007871bd3d1ad2  movq xmm14, qword ptr [r15+0x210]
00007871bd3d1adb  movq xmm13, qword ptr [r15+0x110]
00007871bd3d1ae4  paddd xmm14, xmm13
00007871bd3d1ae9  movq xmm14, xmm14
00007871bd3d1aee  vcvtuqq2pd xmm12, xmm12
00007871bd3d1af4  pmovzxdq xmm14, xmm14
00007871bd3d1afa  psllq xmm14, 0x00
00007871bd3d1b00  vcvtuqq2pd xmm14, xmm14
00007871bd3d1b06  movaps xmm13, xmm12
00007871bd3d1b0a  mulpd xmm13, xmm1
00007871bd3d1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
00007871bd3d1b15  ptest xmm11, xmm11
00007871bd3d1b1b  jnz 0x00007871BD3D1C0F
00007871bd3d1b21  movaps [r15+0x220], xmm13
00007871bd3d1b29  mov eax, 0x432000
00007871bd3d1b2e  movups [r13+rax*1], xmm13
00007871bd3d1b34  movaps xmm1, xmm14
00007871bd3d1b38  mulpd xmm1, xmm15
00007871bd3d1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
00007871bd3d1b42  ptest xmm13, xmm13
00007871bd3d1b48  jnz 0x00007871BD3D1D5C
00007871bd3d1b4e  movaps [r15+0x210], xmm1
00007871bd3d1b56  mov eax, 0x431E00
00007871bd3d1b5b  movups [r13+rax*1], xmm1
00007871bd3d1b61  mov qword ptr [r15+0x48], 0x10
00007871bd3d1b69  xor eax, eax
00007871bd3d1b6b  mov r14d, 0x10
00007871bd3d1b71  mov r12d, 0x200
00007871bd3d1b77  cmp r14, r12
00007871bd3d1b7a  cmc
00007871bd3d1b7b  lahf
00007871bd3d1b7c  seto al
00007871bd3d1b7f  mov [r15+0x108], eax
00007871bd3d1b86  mov eax, [r15+0x108]
00007871bd3d1b8d  sahf
00007871bd3d1b8e  jnz 0x00007871BD3D1BC0
00007871bd3d1b90  cmp dword ptr [r15+0x318], 0x00
00007871bd3d1b98  jz 0x00007871BD3D2300
00007871bd3d1b9e  nop [rax+rax*1], ax
00007871bd3d1ba7  nop [rax+rax*1], eax
00007871bd3d1baf  mov eax, 0x410490
00007871bd3d1bb4  mov [r15+0x100], rax
00007871bd3d1bbb  jmp 0x00007871BD1FE110
00007871bd3d1bc0  cmp dword ptr [r15+0x318], 0x00
00007871bd3d1bc8  jz 0x00007871BD3D1EB0
00007871bd3d1bce  nop [rax+rax*1], ax
00007871bd3d1bd7  nop [rax+rax*1], eax
00007871bd3d1bdf  mov eax, 0x410450
00007871bd3d1be4  mov [r15+0x100], rax
00007871bd3d1beb  jmp 0x00007871BD1FE110
00007871bd3d1bf0  int3
00007871bd3d1bf1  call 0x00007871BD20DC20
00007871bd3d1bf6  jmp 0x00007871BD3D19BE
00007871bd3d1bfb  call 0x00007871BD20C260
00007871bd3d1c00  jmp 0x00007871BD3D1A47
00007871bd3d1c05  call 0x00007871BD2D5D70
00007871bd3d1c0a  jmp 0x00007871BD3D1A5D
00007871bd3d1c0f  sub rsp, 0x08
00007871bd3d1c13  push rax
00007871bd3d1c14  push rcx
00007871bd3d1c15  push rdx
00007871bd3d1c16  push rdi
00007871bd3d1c17  push rsi
00007871bd3d1c18  push r8
00007871bd3d1c1a  push r9
00007871bd3d1c1c  push r10
00007871bd3d1c1e  push r11
00007871bd3d1c20  sub rsp, 0xF0
00007871bd3d1c27  vmovaps [rsp], xmm0
00007871bd3d1c2c  vmovaps [rsp+0x10], xmm1
00007871bd3d1c32  vmovaps [rsp+0x20], xmm2
00007871bd3d1c38  vmovaps [rsp+0x30], xmm3
00007871bd3d1c3e  vmovaps [rsp+0x40], xmm4
00007871bd3d1c44  vmovaps [rsp+0x50], xmm5
00007871bd3d1c4a  vmovaps [rsp+0x60], xmm6
00007871bd3d1c50  vmovaps [rsp+0x70], xmm7
00007871bd3d1c56  vmovaps [rsp+0x80], xmm8
00007871bd3d1c5f  vmovaps [rsp+0x90], xmm9
00007871bd3d1c68  vmovaps [rsp+0xA0], xmm10
00007871bd3d1c71  vmovaps [rsp+0xB0], xmm11
00007871bd3d1c7a  vmovaps [rsp+0xC0], xmm12
00007871bd3d1c83  vmovaps [rsp+0xD0], xmm14
00007871bd3d1c8c  vmovaps [rsp+0xE0], xmm15
00007871bd3d1c95  sub rsp, 0x30
00007871bd3d1c99  movaps [rsp], xmm13
00007871bd3d1c9e  movaps [rsp+0x10], xmm12
00007871bd3d1ca4  movaps [rsp+0x20], xmm1
00007871bd3d1ca9  lea rdi, [rsp]
00007871bd3d1cad  mov esi, 0x00
00007871bd3d1cb2  mov rax, 0x5BA2FDD2A530
00007871bd3d1cbc  call rax
00007871bd3d1cbe  movaps xmm13, [rsp]
00007871bd3d1cc3  add rsp, 0x30
00007871bd3d1cc7  vmovaps xmm0, [rsp]
00007871bd3d1ccc  vmovaps xmm1, [rsp+0x10]
00007871bd3d1cd2  vmovaps xmm2, [rsp+0x20]
00007871bd3d1cd8  vmovaps xmm3, [rsp+0x30]
00007871bd3d1cde  vmovaps xmm4, [rsp+0x40]
00007871bd3d1ce4  vmovaps xmm5, [rsp+0x50]
00007871bd3d1cea  vmovaps xmm6, [rsp+0x60]
00007871bd3d1cf0  vmovaps xmm7, [rsp+0x70]
00007871bd3d1cf6  vmovaps xmm8, [rsp+0x80]
00007871bd3d1cff  vmovaps xmm9, [rsp+0x90]
00007871bd3d1d08  vmovaps xmm10, [rsp+0xA0]
00007871bd3d1d11  vmovaps xmm11, [rsp+0xB0]
00007871bd3d1d1a  vmovaps xmm12, [rsp+0xC0]
00007871bd3d1d23  vmovaps xmm14, [rsp+0xD0]
00007871bd3d1d2c  vmovaps xmm15, [rsp+0xE0]
00007871bd3d1d35  add rsp, 0xF0
00007871bd3d1d3c  pop r11
00007871bd3d1d3e  pop r10
00007871bd3d1d40  pop r9
00007871bd3d1d42  pop r8
00007871bd3d1d44  pop rsi
00007871bd3d1d45  pop rdi
00007871bd3d1d46  pop rdx
00007871bd3d1d47  pop rcx
00007871bd3d1d48  pop rax
00007871bd3d1d49  add rsp, 0x08
00007871bd3d1d4d  jmp 0x00007871BD3D1B21
00007871bd3d1d52  call 0x00007871BD20C380
00007871bd3d1d57  jmp 0x00007871BD3D1B34
00007871bd3d1d5c  sub rsp, 0x08
00007871bd3d1d60  push rax
00007871bd3d1d61  push rcx
00007871bd3d1d62  push rdx
00007871bd3d1d63  push rdi
00007871bd3d1d64  push rsi
00007871bd3d1d65  push r8
00007871bd3d1d67  push r9
00007871bd3d1d69  push r10
00007871bd3d1d6b  push r11
00007871bd3d1d6d  sub rsp, 0xF0
00007871bd3d1d74  vmovaps [rsp], xmm0
00007871bd3d1d79  vmovaps [rsp+0x10], xmm2
00007871bd3d1d7f  vmovaps [rsp+0x20], xmm3
00007871bd3d1d85  vmovaps [rsp+0x30], xmm4
00007871bd3d1d8b  vmovaps [rsp+0x40], xmm5
00007871bd3d1d91  vmovaps [rsp+0x50], xmm6
00007871bd3d1d97  vmovaps [rsp+0x60], xmm7
00007871bd3d1d9d  vmovaps [rsp+0x70], xmm8
00007871bd3d1da3  vmovaps [rsp+0x80], xmm9
00007871bd3d1dac  vmovaps [rsp+0x90], xmm10
00007871bd3d1db5  vmovaps [rsp+0xA0], xmm11
00007871bd3d1dbe  vmovaps [rsp+0xB0], xmm12
00007871bd3d1dc7  vmovaps [rsp+0xC0], xmm13
00007871bd3d1dd0  vmovaps [rsp+0xD0], xmm14
00007871bd3d1dd9  vmovaps [rsp+0xE0], xmm15
00007871bd3d1de2  sub rsp, 0x30
00007871bd3d1de6  movaps [rsp], xmm1
00007871bd3d1dea  movaps [rsp+0x10], xmm14
00007871bd3d1df0  movaps [rsp+0x20], xmm15
00007871bd3d1df6  lea rdi, [rsp]
00007871bd3d1dfa  mov esi, 0x00
00007871bd3d1dff  mov rax, 0x5BA2FDD2A530
00007871bd3d1e09  call rax
00007871bd3d1e0b  movaps xmm1, [rsp]
00007871bd3d1e0f  add rsp, 0x30
00007871bd3d1e13  vmovaps xmm0, [rsp]
00007871bd3d1e18  vmovaps xmm2, [rsp+0x10]
00007871bd3d1e1e  vmovaps xmm3, [rsp+0x20]
00007871bd3d1e24  vmovaps xmm4, [rsp+0x30]
00007871bd3d1e2a  vmovaps xmm5, [rsp+0x40]
00007871bd3d1e30  vmovaps xmm6, [rsp+0x50]
00007871bd3d1e36  vmovaps xmm7, [rsp+0x60]
00007871bd3d1e3c  vmovaps xmm8, [rsp+0x70]
00007871bd3d1e42  vmovaps xmm9, [rsp+0x80]
00007871bd3d1e4b  vmovaps xmm10, [rsp+0x90]
00007871bd3d1e54  vmovaps xmm11, [rsp+0xA0]
00007871bd3d1e5d  vmovaps xmm12, [rsp+0xB0]
00007871bd3d1e66  vmovaps xmm13, [rsp+0xC0]
00007871bd3d1e6f  vmovaps xmm14, [rsp+0xD0]
00007871bd3d1e78  vmovaps xmm15, [rsp+0xE0]
00007871bd3d1e81  add rsp, 0xF0
00007871bd3d1e88  pop r11
00007871bd3d1e8a  pop r10
00007871bd3d1e8c  pop r9
00007871bd3d1e8e  pop r8
00007871bd3d1e90  pop rsi
00007871bd3d1e91  pop rdi
00007871bd3d1e92  pop rdx
00007871bd3d1e93  pop rcx
00007871bd3d1e94  pop rax
00007871bd3d1e95  add rsp, 0x08
00007871bd3d1e99  jmp 0x00007871BD3D1B4E
00007871bd3d1e9e  call 0x00007871BD1FF540
00007871bd3d1ea3  jmp 0x00007871BD3D1B61
00007871bd3d1ea8  int3
00007871bd3d1ea9  nop [rax], eax
00007871bd3d1eb0  movaps xmm1, [r15+0x180]
00007871bd3d1eb8  vpmovqd xmm15, xmm1
00007871bd3d1ebe  pxor xmm14, xmm14
00007871bd3d1ec3  punpcklqdq xmm15, xmm14
00007871bd3d1ec8  movaps [r15+0x210], xmm15
00007871bd3d1ed0  movq xmm15, qword ptr [r15+0x140]
00007871bd3d1ed9  movq xmm14, qword ptr [r15+0x120]
00007871bd3d1ee2  psubd xmm15, xmm14
00007871bd3d1ee7  movq xmm15, xmm15
00007871bd3d1eec  movaps xmm13, [r15+0x170]
00007871bd3d1ef4  paddq xmm1, xmm13
00007871bd3d1ef9  movaps [r15+0x180], xmm1
00007871bd3d1f01  movq xmm1, qword ptr [r15+0x160]
00007871bd3d1f0a  paddd xmm14, xmm1
00007871bd3d1f0f  movq xmm14, xmm14
00007871bd3d1f14  movq xmm14, xmm14
00007871bd3d1f19  movaps [r15+0x120], xmm14
00007871bd3d1f21  pmovzxdq xmm15, xmm15
00007871bd3d1f27  psllq xmm15, 0x00
00007871bd3d1f2d  movq xmm1, qword ptr [r15+0x210]
00007871bd3d1f36  movq xmm14, qword ptr [r15+0x110]
00007871bd3d1f3f  paddd xmm1, xmm14
00007871bd3d1f44  movq xmm1, xmm1
00007871bd3d1f48  vcvtuqq2pd xmm15, xmm15
00007871bd3d1f4e  pmovzxdq xmm1, xmm1
00007871bd3d1f53  psllq xmm1, 0x00
00007871bd3d1f58  vcvtuqq2pd xmm1, xmm1
00007871bd3d1f5e  movaps xmm14, [r15+0x150]
00007871bd3d1f66  movaps xmm13, xmm15
00007871bd3d1f6a  mulpd xmm13, xmm14
00007871bd3d1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
00007871bd3d1f75  ptest xmm12, xmm12
00007871bd3d1f7b  jnz 0x00007871BD3D205E
00007871bd3d1f81  movaps [r15+0x220], xmm13
00007871bd3d1f89  mov rax, [r15+0x48]
00007871bd3d1f8d  mov r14, [r15+0x50]
00007871bd3d1f91  lea r12, [r14+rax*1]
00007871bd3d1f95  movups [r13+r12*1], xmm13
00007871bd3d1f9b  movaps xmm15, [r15+0x130]
00007871bd3d1fa3  movaps xmm14, xmm1
00007871bd3d1fa7  mulpd xmm14, xmm15
00007871bd3d1fac  vcmppd xmm13, xmm14, xmm14, 0x03
00007871bd3d1fb2  ptest xmm13, xmm13
00007871bd3d1fb8  jnz 0x00007871BD3D21AC
00007871bd3d1fbe  movaps [r15+0x210], xmm14
00007871bd3d1fc6  mov r14, [r15+0x40]
00007871bd3d1fca  lea r12, [r14+rax*1]
00007871bd3d1fce  movups [r13+r12*1], xmm14
00007871bd3d1fd4  lea r14, [rax+0x10]
00007871bd3d1fd8  mov [r15+0x48], r14
00007871bd3d1fdc  xor eax, eax
00007871bd3d1fde  mov r12d, 0x200
00007871bd3d1fe4  cmp r14, r12
00007871bd3d1fe7  cmc
00007871bd3d1fe8  lahf
00007871bd3d1fe9  seto al
00007871bd3d1fec  mov [r15+0x108], eax
00007871bd3d1ff3  mov eax, [r15+0x108]
00007871bd3d1ffa  sahf
00007871bd3d1ffb  jnz 0x00007871BD3D202D
00007871bd3d1ffd  cmp dword ptr [r15+0x318], 0x00
00007871bd3d2005  jz 0x00007871BD3D2300
00007871bd3d200b  nop [rax+rax*1], ax
00007871bd3d2014  nop [rax+rax*1], eax
00007871bd3d201c  mov eax, 0x410490
00007871bd3d2021  mov [r15+0x100], rax
00007871bd3d2028  jmp 0x00007871BD1FE110
00007871bd3d202d  cmp dword ptr [r15+0x318], 0x00
00007871bd3d2035  jz 0x00007871BD3D1EB0
00007871bd3d203b  nop [rax+rax*1], ax
00007871bd3d2044  nop [rax+rax*1], eax
00007871bd3d204c  mov eax, 0x410450
00007871bd3d2051  mov [r15+0x100], rax
00007871bd3d2058  jmp 0x00007871BD1FE110
00007871bd3d205d  int3
00007871bd3d205e  sub rsp, 0x08
00007871bd3d2062  push rax
00007871bd3d2063  push rcx
00007871bd3d2064  push rdx
00007871bd3d2065  push rdi
00007871bd3d2066  push rsi
00007871bd3d2067  push r8
00007871bd3d2069  push r9
00007871bd3d206b  push r10
00007871bd3d206d  push r11
00007871bd3d206f  sub rsp, 0xF0
00007871bd3d2076  vmovaps [rsp], xmm0
00007871bd3d207b  vmovaps [rsp+0x10], xmm1
00007871bd3d2081  vmovaps [rsp+0x20], xmm2
00007871bd3d2087  vmovaps [rsp+0x30], xmm3
00007871bd3d208d  vmovaps [rsp+0x40], xmm4
00007871bd3d2093  vmovaps [rsp+0x50], xmm5
00007871bd3d2099  vmovaps [rsp+0x60], xmm6
00007871bd3d209f  vmovaps [rsp+0x70], xmm7
00007871bd3d20a5  vmovaps [rsp+0x80], xmm8
00007871bd3d20ae  vmovaps [rsp+0x90], xmm9
00007871bd3d20b7  vmovaps [rsp+0xA0], xmm10
00007871bd3d20c0  vmovaps [rsp+0xB0], xmm11
00007871bd3d20c9  vmovaps [rsp+0xC0], xmm12
00007871bd3d20d2  vmovaps [rsp+0xD0], xmm14
00007871bd3d20db  vmovaps [rsp+0xE0], xmm15
00007871bd3d20e4  sub rsp, 0x30
00007871bd3d20e8  movaps [rsp], xmm13
00007871bd3d20ed  movaps [rsp+0x10], xmm15
00007871bd3d20f3  movaps [rsp+0x20], xmm14
00007871bd3d20f9  lea rdi, [rsp]
00007871bd3d20fd  mov esi, 0x00
00007871bd3d2102  mov rax, 0x5BA2FDD2A530
00007871bd3d210c  call rax
00007871bd3d210e  movaps xmm13, [rsp]
00007871bd3d2113  add rsp, 0x30
00007871bd3d2117  vmovaps xmm0, [rsp]
00007871bd3d211c  vmovaps xmm1, [rsp+0x10]
00007871bd3d2122  vmovaps xmm2, [rsp+0x20]
00007871bd3d2128  vmovaps xmm3, [rsp+0x30]
00007871bd3d212e  vmovaps xmm4, [rsp+0x40]
00007871bd3d2134  vmovaps xmm5, [rsp+0x50]
00007871bd3d213a  vmovaps xmm6, [rsp+0x60]
00007871bd3d2140  vmovaps xmm7, [rsp+0x70]
00007871bd3d2146  vmovaps xmm8, [rsp+0x80]
00007871bd3d214f  vmovaps xmm9, [rsp+0x90]
00007871bd3d2158  vmovaps xmm10, [rsp+0xA0]
00007871bd3d2161  vmovaps xmm11, [rsp+0xB0]
00007871bd3d216a  vmovaps xmm12, [rsp+0xC0]
00007871bd3d2173  vmovaps xmm14, [rsp+0xD0]
00007871bd3d217c  vmovaps xmm15, [rsp+0xE0]
00007871bd3d2185  add rsp, 0xF0
00007871bd3d218c  pop r11
00007871bd3d218e  pop r10
00007871bd3d2190  pop r9
00007871bd3d2192  pop r8
00007871bd3d2194  pop rsi
00007871bd3d2195  pop rdi
00007871bd3d2196  pop rdx
00007871bd3d2197  pop rcx
00007871bd3d2198  pop rax
00007871bd3d2199  add rsp, 0x08
00007871bd3d219d  jmp 0x00007871BD3D1F81
00007871bd3d21a2  call 0x00007871BD2C2240
00007871bd3d21a7  jmp 0x00007871BD3D1F9B
00007871bd3d21ac  sub rsp, 0x08
00007871bd3d21b0  push rax
00007871bd3d21b1  push rcx
00007871bd3d21b2  push rdx
00007871bd3d21b3  push rdi
00007871bd3d21b4  push rsi
00007871bd3d21b5  push r8
00007871bd3d21b7  push r9
00007871bd3d21b9  push r10
00007871bd3d21bb  push r11
00007871bd3d21bd  sub rsp, 0xF0
00007871bd3d21c4  vmovaps [rsp], xmm0
00007871bd3d21c9  vmovaps [rsp+0x10], xmm1
00007871bd3d21cf  vmovaps [rsp+0x20], xmm2
00007871bd3d21d5  vmovaps [rsp+0x30], xmm3
00007871bd3d21db  vmovaps [rsp+0x40], xmm4
00007871bd3d21e1  vmovaps [rsp+0x50], xmm5
00007871bd3d21e7  vmovaps [rsp+0x60], xmm6
00007871bd3d21ed  vmovaps [rsp+0x70], xmm7
00007871bd3d21f3  vmovaps [rsp+0x80], xmm8
00007871bd3d21fc  vmovaps [rsp+0x90], xmm9
00007871bd3d2205  vmovaps [rsp+0xA0], xmm10
00007871bd3d220e  vmovaps [rsp+0xB0], xmm11
00007871bd3d2217  vmovaps [rsp+0xC0], xmm12
00007871bd3d2220  vmovaps [rsp+0xD0], xmm13
00007871bd3d2229  vmovaps [rsp+0xE0], xmm15
00007871bd3d2232  sub rsp, 0x30
00007871bd3d2236  movaps [rsp], xmm14
00007871bd3d223b  movaps [rsp+0x10], xmm1
00007871bd3d2240  movaps [rsp+0x20], xmm15
00007871bd3d2246  lea rdi, [rsp]
00007871bd3d224a  mov esi, 0x00
00007871bd3d224f  mov rax, 0x5BA2FDD2A530
00007871bd3d2259  call rax
00007871bd3d225b  movaps xmm14, [rsp]
00007871bd3d2260  add rsp, 0x30
00007871bd3d2264  vmovaps xmm0, [rsp]
00007871bd3d2269  vmovaps xmm1, [rsp+0x10]
00007871bd3d226f  vmovaps xmm2, [rsp+0x20]
00007871bd3d2275  vmovaps xmm3, [rsp+0x30]
00007871bd3d227b  vmovaps xmm4, [rsp+0x40]
00007871bd3d2281  vmovaps xmm5, [rsp+0x50]
00007871bd3d2287  vmovaps xmm6, [rsp+0x60]
00007871bd3d228d  vmovaps xmm7, [rsp+0x70]
00007871bd3d2293  vmovaps xmm8, [rsp+0x80]
00007871bd3d229c  vmovaps xmm9, [rsp+0x90]
00007871bd3d22a5  vmovaps xmm10, [rsp+0xA0]
00007871bd3d22ae  vmovaps xmm11, [rsp+0xB0]
00007871bd3d22b7  vmovaps xmm12, [rsp+0xC0]
00007871bd3d22c0  vmovaps xmm13, [rsp+0xD0]
00007871bd3d22c9  vmovaps xmm15, [rsp+0xE0]
00007871bd3d22d2  add rsp, 0xF0
00007871bd3d22d9  pop r11
00007871bd3d22db  pop r10
00007871bd3d22dd  pop r9
00007871bd3d22df  pop r8
00007871bd3d22e1  pop rsi
00007871bd3d22e2  pop rdi
00007871bd3d22e3  pop rdx
00007871bd3d22e4  pop rcx
00007871bd3d22e5  pop rax
00007871bd3d22e6  add rsp, 0x08
00007871bd3d22ea  jmp 0x00007871BD3D1FBE
00007871bd3d22ef  call 0x00007871BD2C34C0
00007871bd3d22f4  jmp 0x00007871BD3D1FD4
00007871bd3d22f9  int3
00007871bd3d22fa  nop [rax+rax*1], ax
00007871bd3d2300  mov rax, [r15+0x50]
00007871bd3d2304  lea r14, [rax+0x80]
00007871bd3d230b  movups xmm1, [r13+r14*1]
00007871bd3d2311  lea r14, [rax+0x90]
00007871bd3d2318  movups xmm15, [r13+r14*1]
00007871bd3d231e  vxorps xmm14, xmm14, xmm14
00007871bd3d2323  vpbroadcastq xmm14, xmm14
00007871bd3d2328  lea r14, [rax+0x40]
00007871bd3d232c  movups xmm13, [r13+r14*1]
00007871bd3d2332  lea r14, [rax+0x50]
00007871bd3d2336  movups xmm12, [r13+r14*1]
00007871bd3d233c  mov qword ptr [r15+0x48], 0x00
00007871bd3d2344  movups xmm11, [r13+rax*1]
00007871bd3d234a  lea r14, [rax+0x10]
00007871bd3d234e  movups xmm10, [r13+r14*1]
00007871bd3d2354  mov r14, [r15+0xF8]
00007871bd3d235b  lea r12, [r14+0xE0]
00007871bd3d2362  movups [r13+r12*1], xmm15
00007871bd3d2368  lea r12, [r14+0xF0]
00007871bd3d236f  movups [r13+r12*1], xmm1
00007871bd3d2375  lea r12, [rax+0xC0]
00007871bd3d237c  movups xmm1, [r13+r12*1]
00007871bd3d2382  lea r12, [rax+0xD0]
00007871bd3d2389  movups xmm15, [r13+r12*1]
00007871bd3d238f  lea r12, [rax+0x140]
00007871bd3d2396  movups xmm9, [r13+r12*1]
00007871bd3d239c  lea r12, [rax+0x150]
00007871bd3d23a3  movups xmm8, [r13+r12*1]
00007871bd3d23a9  lea r12, [rax+0x180]
00007871bd3d23b0  movups xmm7, [r13+r12*1]
00007871bd3d23b6  lea r12, [rax+0x190]
00007871bd3d23bd  movups xmm6, [r13+r12*1]
00007871bd3d23c3  lea r12, [r14+0xC0]
00007871bd3d23ca  movups [r13+r12*1], xmm15
00007871bd3d23d0  lea r12, [r14+0xD0]
00007871bd3d23d7  movups [r13+r12*1], xmm1
00007871bd3d23dd  lea r12, [rax+0x100]
00007871bd3d23e4  movups xmm1, [r13+r12*1]
00007871bd3d23ea  lea r12, [rax+0x110]
00007871bd3d23f1  movups xmm15, [r13+r12*1]
00007871bd3d23f7  lea r12, [rax+0x1C0]
00007871bd3d23fe  movups xmm5, [r13+r12*1]
00007871bd3d2404  lea r12, [rax+0x1D0]
00007871bd3d240b  movups xmm4, [r13+r12*1]
00007871bd3d2411  lea r12, [rax+0x20]
00007871bd3d2415  movups xmm3, [r13+r12*1]
00007871bd3d241b  lea r12, [rax+0x30]
00007871bd3d241f  movups xmm2, [r13+r12*1]
00007871bd3d2425  movaps [r15+0x1F0], xmm2
00007871bd3d242d  lea r12, [r14+0x20]
00007871bd3d2431  movups [r13+r12*1], xmm1
00007871bd3d2437  lea r12, [r14+0x30]
00007871bd3d243b  movups [r13+r12*1], xmm12
00007871bd3d2441  lea r12, [rax+0x60]
00007871bd3d2445  movups xmm1, [r13+r12*1]
00007871bd3d244b  lea r12, [rax+0x70]
00007871bd3d244f  movups xmm12, [r13+r12*1]
00007871bd3d2455  lea r12, [r14+0x60]
00007871bd3d2459  movups [r13+r12*1], xmm11
00007871bd3d245f  lea r12, [r14+0x70]
00007871bd3d2463  movups [r13+r12*1], xmm5
00007871bd3d2469  lea r12, [rax+0xE0]
00007871bd3d2470  movups xmm11, [r13+r12*1]
00007871bd3d2476  lea r12, [rax+0xF0]
00007871bd3d247d  movups xmm5, [r13+r12*1]
00007871bd3d2483  lea r12, [rax+0x120]
00007871bd3d248a  vmovaps [rsp+0x10], xmm1
00007871bd3d2490  movups xmm1, [r13+r12*1]
00007871bd3d2496  lea r12, [rax+0x130]
00007871bd3d249d  vmovaps [rsp+0x20], xmm1
00007871bd3d24a3  movups xmm1, [r13+r12*1]
00007871bd3d24a9  lea r12, [r14+0xA0]
00007871bd3d24b0  movups [r13+r12*1], xmm12
00007871bd3d24b6  lea r12, [r14+0xB0]
00007871bd3d24bd  vmovaps xmm12, [rsp+0x10]
00007871bd3d24c3  movups [r13+r12*1], xmm12
00007871bd3d24c9  lea r12, [rax+0xA0]
00007871bd3d24d0  movups xmm12, [r13+r12*1]
00007871bd3d24d6  lea r12, [rax+0xB0]
00007871bd3d24dd  vmovaps [rsp+0x10], xmm1
00007871bd3d24e3  movups xmm1, [r13+r12*1]
00007871bd3d24e9  lea r12, [rax+0x160]
00007871bd3d24f0  vmovaps [rsp+0x30], xmm1
00007871bd3d24f6  movups xmm1, [r13+r12*1]
00007871bd3d24fc  lea r12, [rax+0x170]
00007871bd3d2503  vmovaps [rsp+0x40], xmm1
00007871bd3d2509  movups xmm1, [r13+r12*1]
00007871bd3d250f  movaps [r15+0x2B0], xmm1
00007871bd3d2517  lea r12, [rax+0x1A0]
00007871bd3d251e  vmovaps [rsp+0x50], xmm1
00007871bd3d2524  movups xmm1, [r13+r12*1]
00007871bd3d252a  lea r12, [rax+0x1B0]
00007871bd3d2531  vmovaps [rsp+0x60], xmm1
00007871bd3d2537  movups xmm1, [r13+r12*1]
00007871bd3d253d  vmovaps [rsp+0x70], xmm1
00007871bd3d2543  vmovaps xmm1, [rsp+0x60]
00007871bd3d2549  movaps [r15+0x290], xmm1
00007871bd3d2551  vmovaps [rsp+0x60], xmm1
00007871bd3d2557  vmovaps xmm1, [rsp+0x70]
00007871bd3d255d  movaps [r15+0x1E0], xmm1
00007871bd3d2565  lea r12, [r14+0x80]
00007871bd3d256c  vmovaps [rsp+0x70], xmm1
00007871bd3d2572  vmovaps xmm1, [rsp+0x30]
00007871bd3d2578  movups [r13+r12*1], xmm1
00007871bd3d257e  lea r12, [r14+0x90]
00007871bd3d2585  movups [r13+r12*1], xmm12
00007871bd3d258b  lea r12, [rax+0x1E0]
00007871bd3d2592  movups xmm1, [r13+r12*1]
00007871bd3d2598  lea r12, [rax+0x1F0]
00007871bd3d259f  movups xmm12, [r13+r12*1]
00007871bd3d25a5  mov qword ptr [r15+0x50], 0x432200
00007871bd3d25ad  lea rax, [r14+0x40]
00007871bd3d25b1  vmovaps [rsp+0x30], xmm1
00007871bd3d25b7  vmovaps xmm1, [rsp+0x40]
00007871bd3d25bd  movups [r13+rax*1], xmm1
00007871bd3d25c3  lea rax, [r14+0x50]
00007871bd3d25c7  movups [r13+rax*1], xmm10
00007871bd3d25cd  movups [r13+r14*1], xmm12
00007871bd3d25d3  lea rax, [r14+0x10]
00007871bd3d25d7  vmovaps xmm1, [rsp+0x30]
00007871bd3d25dd  movups [r13+rax*1], xmm1
00007871bd3d25e3  mov rax, [r15+0x40]
00007871bd3d25e7  vmovaps [rsp+0x30], xmm3
00007871bd3d25ed  vmovaps xmm1, [rsp+0x30]
00007871bd3d25f3  por xmm3, xmm1
00007871bd3d25f7  vmovaps [rsp+0x30], xmm6
00007871bd3d25fd  vmovaps xmm12, [rsp+0x30]
00007871bd3d2603  por xmm6, xmm12
00007871bd3d2608  lea r12, [rax+0x30]
00007871bd3d260c  mov r11, [r13+r12*1]
00007871bd3d2611  lea r12, [rax+0x38]
00007871bd3d2615  mov r10, [r13+r12*1]
00007871bd3d261a  movq xmm12, r11
00007871bd3d261f  movq xmm10, r10
00007871bd3d2624  movq xmm12, xmm12
00007871bd3d2629  vmovaps [rsp+0x30], xmm12
00007871bd3d262f  movq xmm12, xmm12
00007871bd3d2634  movaps [r15+0x130], xmm12
00007871bd3d263c  movq xmm10, xmm10
00007871bd3d2641  vmovaps [rsp+0x40], xmm10
00007871bd3d2647  movq xmm10, xmm10
00007871bd3d264c  movaps [r15+0x280], xmm10
00007871bd3d2654  vmovaps [rsp+0x80], xmm9
00007871bd3d265d  vmovaps xmm12, [rsp+0x80]
00007871bd3d2666  por xmm9, xmm12
00007871bd3d266b  lea r12, [rax+0x20]
00007871bd3d266f  mov r11, [r13+r12*1]
00007871bd3d2674  lea r12, [rax+0x28]
00007871bd3d2678  mov r10, [r13+r12*1]
00007871bd3d267d  movq xmm12, r11
00007871bd3d2682  movq xmm10, r10
00007871bd3d2687  movq xmm12, xmm12
00007871bd3d268c  vmovaps [rsp+0x80], xmm12
00007871bd3d2695  movq xmm12, xmm12
00007871bd3d269a  movaps [r15+0x150], xmm12
00007871bd3d26a2  movq xmm10, xmm10
00007871bd3d26a7  vmovaps [rsp+0x90], xmm10
00007871bd3d26b0  movq xmm10, xmm10
00007871bd3d26b5  movaps [r15+0x140], xmm10
00007871bd3d26bd  lea r12, [rax+0x10]
00007871bd3d26c1  mov r11, [r13+r12*1]
00007871bd3d26c6  lea r12, [rax+0x18]
00007871bd3d26ca  mov r10, [r13+r12*1]
00007871bd3d26cf  movq xmm12, r11
00007871bd3d26d4  movq xmm10, r10
00007871bd3d26d9  movq xmm12, xmm12
00007871bd3d26de  vmovaps [rsp+0xA0], xmm12
00007871bd3d26e7  movq xmm12, xmm12
00007871bd3d26ec  movaps [r15+0x170], xmm12
00007871bd3d26f4  movq xmm10, xmm10
00007871bd3d26f9  vmovaps [rsp+0xB0], xmm10
00007871bd3d2702  movq xmm10, xmm10
00007871bd3d2707  movaps [r15+0x160], xmm10
00007871bd3d270f  mov r12, [r13+rax*1]
00007871bd3d2714  vmovq xmm12, r12
00007871bd3d2719  vpbroadcastq xmm12, xmm12
00007871bd3d271e  lea r12, [rax+0x08]
00007871bd3d2722  mov rax, [r13+r12*1]
00007871bd3d2727  movq xmm10, rax
00007871bd3d272c  movaps [r15+0x230], xmm10
00007871bd3d2734  lea rax, [r14+0x50]
00007871bd3d2738  movups xmm10, [r13+rax*1]
00007871bd3d273e  lea rax, [r14+0x60]
00007871bd3d2742  vmovaps [rsp+0xC0], xmm1
00007871bd3d274b  movups xmm1, [r13+rax*1]
00007871bd3d2751  lea rax, [r14+0x30]
00007871bd3d2755  vmovaps [rsp+0xD0], xmm1
00007871bd3d275e  movups xmm1, [r13+rax*1]
00007871bd3d2764  mov qword ptr [r15+0x60], 0x432200
00007871bd3d276c  mov qword ptr [r15+0x58], 0x40
00007871bd3d2774  vmovaps [rsp+0xE0], xmm1
00007871bd3d277d  vmovaps [rsp+0xF0], xmm15
00007871bd3d2786  vmovaps xmm15, [rsp+0xC0]
00007871bd3d278f  vmovaps [rsp+0xC0], xmm14
00007871bd3d2798  movaps xmm1, xmm12
00007871bd3d279c  mulpd xmm1, xmm15
00007871bd3d27a1  vcmppd xmm14, xmm1, xmm1, 0x03
00007871bd3d27a6  ptest xmm14, xmm14
00007871bd3d27ac  jnz 0x00007871BD3D3863
00007871bd3d27b2  movq xmm15, qword ptr [r15+0x230]
00007871bd3d27bb  vmovaps [rsp+0x100], xmm15
00007871bd3d27c4  vpermilpd xmm15, xmm15, 0x00
00007871bd3d27ca  vmovaps [rsp+0x110], xmm1
00007871bd3d27d3  vmovaps xmm1, [rsp+0xE0]
00007871bd3d27dc  vmovaps [rsp+0xE0], xmm13
00007871bd3d27e5  movaps xmm14, xmm1
00007871bd3d27e9  mulpd xmm14, xmm15
00007871bd3d27ee  vcmppd xmm13, xmm14, xmm14, 0x03
00007871bd3d27f4  ptest xmm13, xmm13
00007871bd3d27fa  jnz 0x00007871BD3D39A5
00007871bd3d2800  vxorps xmm1, xmm1, xmm1
00007871bd3d2804  vpbroadcastq xmm1, xmm1
00007871bd3d2809  vmovaps xmm13, [rsp+0xD0]
00007871bd3d2812  vmovaps [rsp+0xD0], xmm1
00007871bd3d281b  movaps xmm15, xmm12
00007871bd3d281f  mulpd xmm15, xmm13
00007871bd3d2824  vcmppd xmm1, xmm15, xmm15, 0x03
00007871bd3d282a  ptest xmm1, xmm1
00007871bd3d282f  jnz 0x00007871BD3D3AE8
00007871bd3d2835  movaps xmm1, xmm12
00007871bd3d2839  mulpd xmm1, xmm10
00007871bd3d283e  vcmppd xmm13, xmm1, xmm1, 0x03
00007871bd3d2843  ptest xmm13, xmm13
00007871bd3d2849  jnz 0x00007871BD3D3C2C
00007871bd3d284f  movaps xmm13, xmm12
00007871bd3d2853  mulpd xmm13, xmm2
00007871bd3d2858  vcmppd xmm10, xmm13, xmm13, 0x03
00007871bd3d285e  ptest xmm10, xmm10
00007871bd3d2864  jnz 0x00007871BD3D3D6E
00007871bd3d286a  vmovaps [rsp+0x120], xmm7
00007871bd3d2873  vmovaps xmm12, [rsp+0x120]
00007871bd3d287c  por xmm7, xmm12
00007871bd3d2881  vmovaps xmm12, [rsp+0xE0]
00007871bd3d288a  vmovaps xmm10, [rsp+0xE0]
00007871bd3d2893  por xmm12, xmm10
00007871bd3d2898  vmovaps xmm2, [rsp+0x100]
00007871bd3d28a1  vpermilpd xmm2, xmm2, 0x00
00007871bd3d28a7  vmovaps [rsp+0xE0], xmm1
00007871bd3d28b0  vmovaps [rsp+0x120], xmm15
00007871bd3d28b9  movaps xmm1, xmm10
00007871bd3d28bd  mulpd xmm1, xmm2
00007871bd3d28c1  vcmppd xmm15, xmm1, xmm1, 0x03
00007871bd3d28c6  ptest xmm15, xmm15
00007871bd3d28cc  jnz 0x00007871BD3D3EB1
00007871bd3d28d2  xor eax, eax
00007871bd3d28d4  mov r12d, 0x40
00007871bd3d28da  mov r11d, 0x200
00007871bd3d28e0  cmp r12, r11
00007871bd3d28e3  cmc
00007871bd3d28e4  lahf
00007871bd3d28e5  seto al
00007871bd3d28e8  mov [r15+0x108], eax
00007871bd3d28ef  vmovaps xmm10, [rsp+0x110]
00007871bd3d28f8  vmovaps xmm2, [rsp+0xD0]
00007871bd3d2901  vmovaps [rsp+0xD0], xmm1
00007871bd3d290a  movaps xmm15, xmm10
00007871bd3d290e  addpd xmm15, xmm2
00007871bd3d2913  vcmppd xmm1, xmm15, xmm15, 0x03
00007871bd3d2919  ptest xmm1, xmm1
00007871bd3d291e  jnz 0x00007871BD3D3FF2
00007871bd3d2924  vmovaps xmm10, [rsp+0x120]
00007871bd3d292d  vmovaps [rsp+0x110], xmm15
00007871bd3d2936  vmovaps xmm15, [rsp+0xC0]
00007871bd3d293f  vmovaps [rsp+0xC0], xmm14
00007871bd3d2948  movaps xmm1, xmm10
00007871bd3d294c  addpd xmm1, xmm15
00007871bd3d2951  vcmppd xmm14, xmm1, xmm1, 0x03
00007871bd3d2956  ptest xmm14, xmm14
00007871bd3d295c  jnz 0x00007871BD3D4135
00007871bd3d2962  vmovaps xmm10, [rsp+0xE0]
00007871bd3d296b  vmovaps [rsp+0xE0], xmm1
00007871bd3d2974  movaps xmm14, xmm10
00007871bd3d2978  addpd xmm14, xmm15
00007871bd3d297d  vcmppd xmm1, xmm14, xmm14, 0x03
00007871bd3d2983  ptest xmm1, xmm1
00007871bd3d2988  jnz 0x00007871BD3D4277
00007871bd3d298e  vmovaps xmm1, [rsp+0x10]
00007871bd3d2994  vmovaps xmm15, [rsp+0x10]
00007871bd3d299a  por xmm1, xmm15
00007871bd3d299f  vmovaps xmm15, [rsp+0x20]
00007871bd3d29a5  vmovaps xmm10, [rsp+0x20]
00007871bd3d29ab  por xmm15, xmm10
00007871bd3d29b0  vmovaps [rsp+0x10], xmm5
00007871bd3d29b6  vmovaps xmm10, [rsp+0x10]
00007871bd3d29bc  por xmm5, xmm10
00007871bd3d29c1  vmovaps [rsp+0x10], xmm11
00007871bd3d29c7  vmovaps xmm10, [rsp+0x10]
00007871bd3d29cd  por xmm11, xmm10
00007871bd3d29d2  vmovaps [rsp+0x10], xmm4
00007871bd3d29d8  vmovaps xmm10, [rsp+0x10]
00007871bd3d29de  por xmm4, xmm10
00007871bd3d29e3  vmovaps [rsp+0x10], xmm8
00007871bd3d29e9  vmovaps xmm10, [rsp+0x10]
00007871bd3d29ef  por xmm8, xmm10
00007871bd3d29f4  vmovaps xmm10, [rsp+0xF0]
00007871bd3d29fd  vmovaps [rsp+0x10], xmm1
00007871bd3d2a03  vmovaps xmm1, [rsp+0xF0]
00007871bd3d2a0c  por xmm10, xmm1
00007871bd3d2a11  lea rax, [r14+0xA0]
00007871bd3d2a18  movups xmm1, [r13+rax*1]
00007871bd3d2a1e  lea rax, [r14+0xB0]
00007871bd3d2a25  vmovaps [rsp+0x20], xmm1
00007871bd3d2a2b  movups xmm1, [r13+rax*1]
00007871bd3d2a31  vmovaps [rsp+0xF0], xmm1
00007871bd3d2a3a  vmovaps [rsp+0x120], xmm15
00007871bd3d2a43  movaps xmm1, xmm13
00007871bd3d2a47  addpd xmm1, xmm2
00007871bd3d2a4b  vcmppd xmm15, xmm1, xmm1, 0x03
00007871bd3d2a50  ptest xmm15, xmm15
00007871bd3d2a56  jnz 0x00007871BD3D43CF
00007871bd3d2a5c  lea rax, [r14+0xF0]
00007871bd3d2a63  movups xmm15, [r13+rax*1]
00007871bd3d2a69  vmovaps xmm2, [rsp+0xE0]
00007871bd3d2a72  vmovaps [rsp+0xE0], xmm1
00007871bd3d2a7b  vmovaps xmm1, [rsp+0xD0]
00007871bd3d2a84  vmovaps [rsp+0xD0], xmm15
00007871bd3d2a8d  movaps xmm13, xmm2
00007871bd3d2a91  addpd xmm13, xmm1
00007871bd3d2a96  vcmppd xmm15, xmm13, xmm13, 0x03
00007871bd3d2a9c  ptest xmm15, xmm15
00007871bd3d2aa2  jnz 0x00007871BD3D451A
00007871bd3d2aa8  vmovaps xmm15, [rsp+0xC0]
00007871bd3d2ab1  movaps xmm1, xmm14
00007871bd3d2ab5  addpd xmm1, xmm15
00007871bd3d2aba  vcmppd xmm2, xmm1, xmm1, 0x03
00007871bd3d2abf  ptest xmm2, xmm2
00007871bd3d2ac4  jnz 0x00007871BD3D465C
00007871bd3d2aca  vmovaps xmm15, [rsp+0x100]
00007871bd3d2ad3  vpermilpd xmm15, xmm15, 0x00
00007871bd3d2ad9  vmovaps xmm2, [rsp+0xF0]
00007871bd3d2ae2  vmovaps [rsp+0xC0], xmm1
00007871bd3d2aeb  movaps xmm14, xmm2
00007871bd3d2aef  mulpd xmm14, xmm15
00007871bd3d2af4  vcmppd xmm1, xmm14, xmm14, 0x03
00007871bd3d2afa  ptest xmm1, xmm1
00007871bd3d2aff  jnz 0x00007871BD3D479E
00007871bd3d2b05  vmovaps xmm1, [rsp+0xA0]
00007871bd3d2b0e  vpermilpd xmm1, xmm1, 0x00
00007871bd3d2b14  vmovaps xmm2, [rsp+0xD0]
00007871bd3d2b1d  vmovaps [rsp+0xD0], xmm14
00007871bd3d2b26  movaps xmm15, xmm2
00007871bd3d2b2a  mulpd xmm15, xmm1
00007871bd3d2b2f  vcmppd xmm14, xmm15, xmm15, 0x03
00007871bd3d2b35  ptest xmm14, xmm14
00007871bd3d2b3b  jnz 0x00007871BD3D48E1
00007871bd3d2b41  lea rax, [r14+0xE0]
00007871bd3d2b48  movups xmm1, [r13+rax*1]
00007871bd3d2b4e  vmovaps xmm14, [rsp+0x100]
00007871bd3d2b57  vpermilpd xmm14, xmm14, 0x00
00007871bd3d2b5d  vmovaps [rsp+0xF0], xmm1
00007871bd3d2b66  vmovaps xmm1, [rsp+0x20]
00007871bd3d2b6c  vmovaps [rsp+0x20], xmm15
00007871bd3d2b72  movaps xmm2, xmm1
00007871bd3d2b75  mulpd xmm2, xmm14
00007871bd3d2b7a  vcmppd xmm15, xmm2, xmm2, 0x03
00007871bd3d2b7f  ptest xmm15, xmm15
00007871bd3d2b85  jnz 0x00007871BD3D4A2D
00007871bd3d2b8b  vmovaps [rsp+0x100], xmm10
00007871bd3d2b94  vmovaps xmm1, [rsp+0x100]
00007871bd3d2b9d  por xmm10, xmm1
00007871bd3d2ba2  movaps [r15+0x300], xmm10
00007871bd3d2baa  vmovaps [rsp+0x100], xmm8
00007871bd3d2bb3  vmovaps xmm1, [rsp+0x100]
00007871bd3d2bbc  por xmm8, xmm1
00007871bd3d2bc1  movaps [r15+0x190], xmm8
00007871bd3d2bc9  vmovaps xmm1, [rsp+0xA0]
00007871bd3d2bd2  vpermilpd xmm1, xmm1, 0x00
00007871bd3d2bd8  vmovaps xmm14, [rsp+0xF0]
00007871bd3d2be1  vmovaps [rsp+0xF0], xmm13
00007871bd3d2bea  movaps xmm15, xmm14
00007871bd3d2bee  mulpd xmm15, xmm1
00007871bd3d2bf3  vcmppd xmm13, xmm15, xmm15, 0x03
00007871bd3d2bf9  ptest xmm13, xmm13
00007871bd3d2bff  jnz 0x00007871BD3D4B6E
00007871bd3d2c05  lea rax, [r14+0x90]
00007871bd3d2c0c  movups xmm1, [r13+rax*1]
00007871bd3d2c12  vmovaps [rsp+0x100], xmm4
00007871bd3d2c1b  vmovaps xmm14, [rsp+0x100]
00007871bd3d2c24  por xmm4, xmm14
00007871bd3d2c29  movaps [r15+0x1C0], xmm4
00007871bd3d2c31  vmovaps [rsp+0x100], xmm11
00007871bd3d2c3a  vmovaps xmm14, [rsp+0x100]
00007871bd3d2c43  por xmm11, xmm14
00007871bd3d2c48  movaps [r15+0x200], xmm11
00007871bd3d2c50  vmovaps [rsp+0x100], xmm5
00007871bd3d2c59  vmovaps xmm14, [rsp+0x100]
00007871bd3d2c62  por xmm5, xmm14
00007871bd3d2c67  movaps [r15+0x2D0], xmm5
00007871bd3d2c6f  vmovaps xmm14, [rsp+0x120]
00007871bd3d2c78  vmovaps xmm13, [rsp+0x120]
00007871bd3d2c81  por xmm14, xmm13
00007871bd3d2c86  movaps [r15+0x2E0], xmm14
00007871bd3d2c8e  vmovaps [rsp+0x100], xmm1
00007871bd3d2c97  vmovaps xmm1, [rsp+0x110]
00007871bd3d2ca0  vmovaps [rsp+0x110], xmm15
00007871bd3d2ca9  vmovaps xmm15, [rsp+0xD0]
00007871bd3d2cb2  vmovaps [rsp+0xD0], xmm14
00007871bd3d2cbb  movaps xmm13, xmm1
00007871bd3d2cbf  addpd xmm13, xmm15
00007871bd3d2cc4  vcmppd xmm14, xmm13, xmm13, 0x03
00007871bd3d2cca  ptest xmm14, xmm14
00007871bd3d2cd0  jnz 0x00007871BD3D4CBB
00007871bd3d2cd6  vmovaps xmm1, [rsp+0xA0]
00007871bd3d2cdf  vpermilpd xmm1, xmm1, 0x00
00007871bd3d2ce5  vmovaps xmm14, [rsp+0x100]
00007871bd3d2cee  vmovaps [rsp+0x100], xmm13
00007871bd3d2cf7  movaps xmm15, xmm14
00007871bd3d2cfb  mulpd xmm15, xmm1
00007871bd3d2d00  vcmppd xmm13, xmm15, xmm15, 0x03
00007871bd3d2d06  ptest xmm13, xmm13
00007871bd3d2d0c  jnz 0x00007871BD3D4DFE
00007871bd3d2d12  lea rax, [r14+0x80]
00007871bd3d2d19  movups xmm1, [r13+rax*1]
00007871bd3d2d1f  vmovaps xmm13, [rsp+0xE0]
00007871bd3d2d28  vmovaps [rsp+0xE0], xmm1
00007871bd3d2d31  movaps xmm14, xmm13
00007871bd3d2d35  addpd xmm14, xmm2
00007871bd3d2d3a  vcmppd xmm1, xmm14, xmm14, 0x03
00007871bd3d2d40  ptest xmm1, xmm1
00007871bd3d2d45  jnz 0x00007871BD3D4F4B
00007871bd3d2d4b  vmovaps xmm13, [rsp+0xF0]
00007871bd3d2d54  vmovaps xmm2, [rsp+0x20]
00007871bd3d2d5a  vmovaps [rsp+0x20], xmm15
00007871bd3d2d60  movaps xmm1, xmm13
00007871bd3d2d64  addpd xmm1, xmm2
00007871bd3d2d68  vcmppd xmm15, xmm1, xmm1, 0x03
00007871bd3d2d6d  ptest xmm15, xmm15
00007871bd3d2d73  jnz 0x00007871BD3D508E
00007871bd3d2d79  vmovaps xmm15, [rsp+0x10]
00007871bd3d2d7f  vmovaps xmm13, [rsp+0x10]
00007871bd3d2d85  por xmm15, xmm13
00007871bd3d2d8a  movaps [r15+0x2F0], xmm15
00007871bd3d2d92  vmovaps xmm13, [rsp+0xA0]
00007871bd3d2d9b  vpermilpd xmm13, xmm13, 0x00
00007871bd3d2da1  vmovaps [rsp+0x10], xmm1
00007871bd3d2da7  vmovaps xmm1, [rsp+0xE0]
00007871bd3d2db0  vmovaps [rsp+0xA0], xmm15
00007871bd3d2db9  movaps xmm2, xmm1
00007871bd3d2dbc  mulpd xmm2, xmm13
00007871bd3d2dc1  vcmppd xmm15, xmm2, xmm2, 0x03
00007871bd3d2dc6  ptest xmm15, xmm15
00007871bd3d2dcc  jnz 0x00007871BD3D51CF
00007871bd3d2dd2  lea rax, [r14+0xD0]
00007871bd3d2dd9  movups xmm1, [r13+rax*1]
00007871bd3d2ddf  vmovaps xmm13, [rsp+0xC0]
00007871bd3d2de8  vmovaps [rsp+0xC0], xmm1
00007871bd3d2df1  vmovaps xmm1, [rsp+0x110]
00007871bd3d2dfa  vmovaps [rsp+0xE0], xmm14
00007871bd3d2e03  movaps xmm15, xmm13
00007871bd3d2e07  addpd xmm15, xmm1
00007871bd3d2e0c  vcmppd xmm14, xmm15, xmm15, 0x03
00007871bd3d2e12  ptest xmm14, xmm14
00007871bd3d2e18  jnz 0x00007871BD3D531A
00007871bd3d2e1e  vmovaps xmm1, [rsp+0xB0]
00007871bd3d2e27  vpermilpd xmm1, xmm1, 0x00
00007871bd3d2e2d  movaps xmm14, xmm11
00007871bd3d2e31  mulpd xmm14, xmm1
00007871bd3d2e36  vcmppd xmm13, xmm14, xmm14, 0x03
00007871bd3d2e3c  ptest xmm13, xmm13
00007871bd3d2e42  jnz 0x00007871BD3D545D
00007871bd3d2e48  movaps [r15+0x260], xmm14
00007871bd3d2e50  vxorps xmm1, xmm1, xmm1
00007871bd3d2e54  vpbroadcastq xmm1, xmm1
00007871bd3d2e59  movaps [r15+0x1B0], xmm1
00007871bd3d2e61  vmovaps xmm1, [rsp+0xB0]
00007871bd3d2e6a  vpermilpd xmm1, xmm1, 0x00
00007871bd3d2e70  vmovaps xmm11, [rsp+0xC0]
00007871bd3d2e79  vmovaps [rsp+0xC0], xmm15
00007871bd3d2e82  movaps xmm13, xmm11
00007871bd3d2e86  mulpd xmm13, xmm1
00007871bd3d2e8b  vcmppd xmm15, xmm13, xmm13, 0x03
00007871bd3d2e91  ptest xmm15, xmm15
00007871bd3d2e97  jnz 0x00007871BD3D55A0
00007871bd3d2e9d  lea rax, [r14+0xC0]
00007871bd3d2ea4  movups xmm1, [r13+rax*1]
00007871bd3d2eaa  vmovaps xmm11, [rsp+0x100]
00007871bd3d2eb3  vmovaps [rsp+0xF0], xmm1
00007871bd3d2ebc  vmovaps xmm1, [rsp+0x20]
00007871bd3d2ec2  vmovaps [rsp+0x20], xmm14
00007871bd3d2ec8  movaps xmm15, xmm11
00007871bd3d2ecc  addpd xmm15, xmm1
00007871bd3d2ed1  vcmppd xmm14, xmm15, xmm15, 0x03
00007871bd3d2ed7  ptest xmm14, xmm14
00007871bd3d2edd  jnz 0x00007871BD3D56ED
00007871bd3d2ee3  vmovaps [rsp+0x100], xmm9
00007871bd3d2eec  vmovaps xmm1, [rsp+0x100]
00007871bd3d2ef5  por xmm9, xmm1
00007871bd3d2efa  movaps [r15+0x270], xmm9
00007871bd3d2f02  vmovaps [rsp+0x100], xmm6
00007871bd3d2f0b  vmovaps xmm1, [rsp+0x100]
00007871bd3d2f14  por xmm6, xmm1
00007871bd3d2f18  movaps [r15+0x1A0], xmm6
00007871bd3d2f20  vmovaps xmm14, [rsp+0xB0]
00007871bd3d2f29  vpermilpd xmm14, xmm14, 0x00
00007871bd3d2f2f  vmovaps xmm6, [rsp+0xF0]
00007871bd3d2f38  vmovaps [rsp+0xF0], xmm1
00007871bd3d2f41  movaps xmm11, xmm6
00007871bd3d2f45  mulpd xmm11, xmm14
00007871bd3d2f4a  vcmppd xmm1, xmm11, xmm11, 0x03
00007871bd3d2f50  ptest xmm1, xmm1
00007871bd3d2f55  jnz 0x00007871BD3D5830
00007871bd3d2f5b  lea rax, [r14+0x20]
00007871bd3d2f5f  movups xmm1, [r13+rax*1]
00007871bd3d2f65  movaps [r15+0x110], xmm1
00007871bd3d2f6d  vmovaps xmm6, [rsp+0xE0]
00007871bd3d2f76  vmovaps [rsp+0xE0], xmm1
00007871bd3d2f7f  movaps xmm14, xmm6
00007871bd3d2f83  addpd xmm14, xmm2
00007871bd3d2f88  vcmppd xmm1, xmm14, xmm14, 0x03
00007871bd3d2f8e  ptest xmm1, xmm1
00007871bd3d2f93  jnz 0x00007871BD3D597D
00007871bd3d2f99  vmovaps xmm1, [rsp+0xB0]
00007871bd3d2fa2  vpermilpd xmm1, xmm1, 0x00
00007871bd3d2fa8  movaps xmm6, xmm5
00007871bd3d2fab  mulpd xmm6, xmm1
00007871bd3d2faf  vcmppd xmm2, xmm6, xmm6, 0x03
00007871bd3d2fb4  ptest xmm2, xmm2
00007871bd3d2fb9  jnz 0x00007871BD3D5ABF
00007871bd3d2fbf  vmovaps xmm5, [rsp+0x10]
00007871bd3d2fc5  movaps xmm1, xmm5
00007871bd3d2fc8  addpd xmm1, xmm13
00007871bd3d2fcd  vcmppd xmm2, xmm1, xmm1, 0x03
00007871bd3d2fd2  ptest xmm2, xmm2
00007871bd3d2fd7  jnz 0x00007871BD3D5BFF
00007871bd3d2fdd  vmovaps xmm13, [rsp+0x80]
00007871bd3d2fe6  vpermilpd xmm13, xmm13, 0x00
00007871bd3d2fec  vmovaps xmm2, [rsp+0xE0]
00007871bd3d2ff5  vmovaps [rsp+0x10], xmm1
00007871bd3d2ffb  movaps xmm5, xmm2
00007871bd3d2ffe  mulpd xmm5, xmm13
00007871bd3d3003  vcmppd xmm1, xmm5, xmm5, 0x03
00007871bd3d3008  ptest xmm1, xmm1
00007871bd3d300d  jnz 0x00007871BD3D5D40
00007871bd3d3013  vmovaps xmm1, [rsp+0x80]
00007871bd3d301c  vpermilpd xmm1, xmm1, 0x00
00007871bd3d3022  movaps xmm13, xmm10
00007871bd3d3026  mulpd xmm13, xmm1
00007871bd3d302b  vcmppd xmm2, xmm13, xmm13, 0x03
00007871bd3d3031  ptest xmm2, xmm2
00007871bd3d3036  jnz 0x00007871BD3D5E81
00007871bd3d303c  vmovaps xmm10, [rsp+0x20]
00007871bd3d3042  movaps xmm1, xmm15
00007871bd3d3046  addpd xmm1, xmm10
00007871bd3d304b  vcmppd xmm2, xmm1, xmm1, 0x03
00007871bd3d3050  ptest xmm2, xmm2
00007871bd3d3055  jnz 0x00007871BD3D5FC4
00007871bd3d305b  vmovaps xmm10, [rsp+0xC0]
00007871bd3d3064  movaps xmm15, xmm10
00007871bd3d3068  addpd xmm15, xmm11
00007871bd3d306d  vcmppd xmm2, xmm15, xmm15, 0x03
00007871bd3d3073  ptest xmm2, xmm2
00007871bd3d3078  jnz 0x00007871BD3D6106
00007871bd3d307e  vmovaps xmm11, [rsp+0x80]
00007871bd3d3087  vpermilpd xmm11, xmm11, 0x00
00007871bd3d308d  vmovaps xmm2, [rsp+0xD0]
00007871bd3d3096  vmovaps [rsp+0x20], xmm1
00007871bd3d309c  movaps xmm10, xmm2
00007871bd3d30a0  mulpd xmm10, xmm11
00007871bd3d30a5  vcmppd xmm1, xmm10, xmm10, 0x03
00007871bd3d30ab  ptest xmm1, xmm1
00007871bd3d30b0  jnz 0x00007871BD3D624A
00007871bd3d30b6  vmovaps xmm1, [rsp+0x80]
00007871bd3d30bf  vpermilpd xmm1, xmm1, 0x00
00007871bd3d30c5  vmovaps xmm2, [rsp+0xA0]
00007871bd3d30ce  vmovaps [rsp+0x80], xmm15
00007871bd3d30d7  movaps xmm11, xmm2
00007871bd3d30db  mulpd xmm11, xmm1
00007871bd3d30e0  vcmppd xmm15, xmm11, xmm11, 0x03
00007871bd3d30e6  ptest xmm15, xmm15
00007871bd3d30ec  jnz 0x00007871BD3D638D
00007871bd3d30f2  movaps xmm1, xmm14
00007871bd3d30f6  addpd xmm1, xmm6
00007871bd3d30fa  vcmppd xmm15, xmm1, xmm1, 0x03
00007871bd3d30ff  ptest xmm15, xmm15
00007871bd3d3105  jnz 0x00007871BD3D64CF
00007871bd3d310b  vmovaps xmm14, [rsp+0x10]
00007871bd3d3111  movaps xmm15, xmm14
00007871bd3d3115  addpd xmm15, xmm5
00007871bd3d311a  vcmppd xmm6, xmm15, xmm15, 0x03
00007871bd3d3120  ptest xmm6, xmm6
00007871bd3d3125  jnz 0x00007871BD3D6610
00007871bd3d312b  vmovaps xmm14, [rsp+0x90]
00007871bd3d3134  vpermilpd xmm14, xmm14, 0x00
00007871bd3d313a  movaps xmm6, xmm9
00007871bd3d313e  mulpd xmm6, xmm14
00007871bd3d3143  vcmppd xmm5, xmm6, xmm6, 0x03
00007871bd3d3148  ptest xmm5, xmm5
00007871bd3d314d  jnz 0x00007871BD3D6753
00007871bd3d3153  vmovaps xmm9, [rsp+0x80]
00007871bd3d315c  movaps xmm14, xmm9
00007871bd3d3160  addpd xmm14, xmm13
00007871bd3d3165  vcmppd xmm5, xmm14, xmm14, 0x03
00007871bd3d316b  ptest xmm5, xmm5
00007871bd3d3170  jnz 0x00007871BD3D6895
00007871bd3d3176  vmovaps xmm9, [rsp+0x20]
00007871bd3d317c  movaps xmm13, xmm9
00007871bd3d3180  addpd xmm13, xmm10
00007871bd3d3185  vcmppd xmm5, xmm13, xmm13, 0x03
00007871bd3d318b  ptest xmm5, xmm5
00007871bd3d3190  jnz 0x00007871BD3D69D9
00007871bd3d3196  vmovaps [rsp+0x10], xmm12
00007871bd3d319c  vmovaps xmm10, [rsp+0x10]
00007871bd3d31a2  por xmm12, xmm10
00007871bd3d31a7  movaps [r15+0x250], xmm12
00007871bd3d31af  vmovaps [rsp+0x10], xmm7
00007871bd3d31b5  vmovaps xmm12, [rsp+0x10]
00007871bd3d31bb  por xmm7, xmm12
00007871bd3d31c0  movaps [r15+0x2A0], xmm7
00007871bd3d31c8  vmovaps [rsp+0x10], xmm3
00007871bd3d31ce  vmovaps xmm12, [rsp+0x10]
00007871bd3d31d4  por xmm3, xmm12
00007871bd3d31d9  movaps [r15+0x1D0], xmm3
00007871bd3d31e1  lea rax, [r14+0x40]
00007871bd3d31e5  movups xmm12, [r13+rax*1]
00007871bd3d31eb  movaps [r15+0x2C0], xmm12
00007871bd3d31f3  vmovaps xmm10, [rsp+0x90]
00007871bd3d31fc  vpermilpd xmm10, xmm10, 0x00
00007871bd3d3202  movaps xmm9, xmm8
00007871bd3d3206  mulpd xmm9, xmm10
00007871bd3d320b  vcmppd xmm5, xmm9, xmm9, 0x03
00007871bd3d3211  ptest xmm5, xmm5
00007871bd3d3216  jnz 0x00007871BD3D6B27
00007871bd3d321c  movaps xmm10, xmm1
00007871bd3d3220  addpd xmm10, xmm11
00007871bd3d3225  vcmppd xmm8, xmm10, xmm10, 0x03
00007871bd3d322b  ptest xmm8, xmm8
00007871bd3d3231  jnz 0x00007871BD3D6C6B
00007871bd3d3237  movaps xmm1, xmm15
00007871bd3d323b  addpd xmm1, xmm6
00007871bd3d323f  vcmppd xmm11, xmm1, xmm1, 0x03
00007871bd3d3244  ptest xmm11, xmm11
00007871bd3d324a  jnz 0x00007871BD3D6DAE
00007871bd3d3250  vmovaps xmm15, [rsp+0x90]
00007871bd3d3259  vpermilpd xmm15, xmm15, 0x00
00007871bd3d325f  movaps xmm11, xmm12
00007871bd3d3263  mulpd xmm11, xmm15
00007871bd3d3268  vcmppd xmm8, xmm11, xmm11, 0x03
00007871bd3d326e  ptest xmm8, xmm8
00007871bd3d3274  jnz 0x00007871BD3D6EEF
00007871bd3d327a  vmovaps xmm15, [rsp+0x90]
00007871bd3d3283  vpermilpd xmm15, xmm15, 0x00
00007871bd3d3289  vmovaps xmm8, [rsp+0x50]
00007871bd3d328f  movaps xmm12, xmm8
00007871bd3d3293  mulpd xmm12, xmm15
00007871bd3d3298  vcmppd xmm6, xmm12, xmm12, 0x03
00007871bd3d329e  ptest xmm6, xmm6
00007871bd3d32a3  jnz 0x00007871BD3D7033
00007871bd3d32a9  vmovaps xmm15, [rsp+0x30]
00007871bd3d32af  vpermilpd xmm15, xmm15, 0x00
00007871bd3d32b5  movaps xmm8, xmm7
00007871bd3d32b9  mulpd xmm8, xmm15
00007871bd3d32be  vcmppd xmm6, xmm8, xmm8, 0x03
00007871bd3d32c4  ptest xmm6, xmm6
00007871bd3d32c9  jnz 0x00007871BD3D7177
00007871bd3d32cf  movaps xmm15, xmm14
00007871bd3d32d3  addpd xmm15, xmm9
00007871bd3d32d8  vcmppd xmm7, xmm15, xmm15, 0x03
00007871bd3d32de  ptest xmm7, xmm7
00007871bd3d32e3  jnz 0x00007871BD3D72BA
00007871bd3d32e9  vmovaps xmm14, [rsp+0x30]
00007871bd3d32ef  vpermilpd xmm14, xmm14, 0x00
00007871bd3d32f5  vmovaps xmm7, [rsp+0xF0]
00007871bd3d32fe  movaps xmm9, xmm7
00007871bd3d3302  mulpd xmm9, xmm14
00007871bd3d3307  vcmppd xmm6, xmm9, xmm9, 0x03
00007871bd3d330d  ptest xmm6, xmm6
00007871bd3d3312  jnz 0x00007871BD3D73FE
00007871bd3d3318  movaps xmm14, xmm13
00007871bd3d331c  addpd xmm14, xmm11
00007871bd3d3321  vcmppd xmm7, xmm14, xmm14, 0x03
00007871bd3d3327  ptest xmm7, xmm7
00007871bd3d332c  jnz 0x00007871BD3D7541
00007871bd3d3332  vmovaps xmm13, [rsp+0x30]
00007871bd3d3338  vpermilpd xmm13, xmm13, 0x00
00007871bd3d333e  vmovaps xmm7, [rsp+0x60]
00007871bd3d3344  movaps xmm11, xmm7
00007871bd3d3348  mulpd xmm11, xmm13
00007871bd3d334d  vcmppd xmm6, xmm11, xmm11, 0x03
00007871bd3d3353  ptest xmm6, xmm6
00007871bd3d3358  jnz 0x00007871BD3D7685
00007871bd3d335e  movaps xmm13, xmm10
00007871bd3d3362  addpd xmm13, xmm12
00007871bd3d3367  vcmppd xmm7, xmm13, xmm13, 0x03
00007871bd3d336d  ptest xmm7, xmm7
00007871bd3d3372  jnz 0x00007871BD3D77C8
00007871bd3d3378  vmovaps xmm12, [rsp+0x30]
00007871bd3d337e  vpermilpd xmm12, xmm12, 0x00
00007871bd3d3384  vmovaps xmm7, [rsp+0x70]
00007871bd3d338a  movaps xmm10, xmm7
00007871bd3d338e  mulpd xmm10, xmm12
00007871bd3d3393  vcmppd xmm6, xmm10, xmm10, 0x03
00007871bd3d3399  ptest xmm6, xmm6
00007871bd3d339e  jnz 0x00007871BD3D790C
00007871bd3d33a4  movaps xmm12, xmm1
00007871bd3d33a8  addpd xmm12, xmm8
00007871bd3d33ad  vcmppd xmm7, xmm12, xmm12, 0x03
00007871bd3d33b3  ptest xmm7, xmm7
00007871bd3d33b8  jnz 0x00007871BD3D7A4F
00007871bd3d33be  lea rax, [r14+0x70]
00007871bd3d33c2  movups xmm1, [r13+rax*1]
00007871bd3d33c8  movaps [r15+0x240], xmm1
00007871bd3d33d0  movaps xmm8, xmm15
00007871bd3d33d4  addpd xmm8, xmm9
00007871bd3d33d9  vcmppd xmm7, xmm8, xmm8, 0x03
00007871bd3d33df  ptest xmm7, xmm7
00007871bd3d33e4  jnz 0x00007871BD3D7B9C
00007871bd3d33ea  movaps [r15+0x170], xmm8
00007871bd3d33f2  vmovaps xmm15, [rsp+0x40]
00007871bd3d33f8  vpermilpd xmm15, xmm15, 0x00
00007871bd3d33fe  movaps xmm9, xmm1
00007871bd3d3402  mulpd xmm9, xmm15
00007871bd3d3407  vcmppd xmm7, xmm9, xmm9, 0x03
00007871bd3d340d  ptest xmm7, xmm7
00007871bd3d3412  jnz 0x00007871BD3D7CE0
00007871bd3d3418  vmovaps xmm1, [rsp+0x40]
00007871bd3d341e  vpermilpd xmm1, xmm1, 0x00
00007871bd3d3424  movaps xmm15, xmm4
00007871bd3d3428  mulpd xmm15, xmm1
00007871bd3d342d  vcmppd xmm7, xmm15, xmm15, 0x03
00007871bd3d3433  ptest xmm7, xmm7
00007871bd3d3438  jnz 0x00007871BD3D7E23
00007871bd3d343e  movaps [r15+0x180], xmm15
00007871bd3d3446  movaps xmm1, xmm14
00007871bd3d344a  addpd xmm1, xmm11
00007871bd3d344f  vcmppd xmm7, xmm1, xmm1, 0x03
00007871bd3d3454  ptest xmm7, xmm7
00007871bd3d3459  jnz 0x00007871BD3D7F65
00007871bd3d345f  movaps [r15+0x210], xmm1
00007871bd3d3467  movups xmm14, [r13+r14*1]
00007871bd3d346d  lea rax, [r14+0x10]
00007871bd3d3471  movups xmm11, [r13+rax*1]
00007871bd3d3477  movaps [r15+0x230], xmm11
00007871bd3d347f  movaps xmm7, xmm13
00007871bd3d3483  addpd xmm7, xmm10
00007871bd3d3488  vcmppd xmm6, xmm7, xmm7, 0x03
00007871bd3d348d  ptest xmm6, xmm6
00007871bd3d3492  jnz 0x00007871BD3D80BB
00007871bd3d3498  movaps [r15+0x130], xmm7
00007871bd3d34a0  vmovaps xmm13, [rsp+0x40]
00007871bd3d34a6  vpermilpd xmm13, xmm13, 0x00
00007871bd3d34ac  movaps xmm10, xmm11
00007871bd3d34b0  mulpd xmm10, xmm13
00007871bd3d34b5  vcmppd xmm6, xmm10, xmm10, 0x03
00007871bd3d34bb  ptest xmm6, xmm6
00007871bd3d34c0  jnz 0x00007871BD3D81FD
00007871bd3d34c6  movaps [r15+0x220], xmm10
00007871bd3d34ce  vmovaps xmm13, [rsp+0x40]
00007871bd3d34d4  vpermilpd xmm13, xmm13, 0x00
00007871bd3d34da  movaps xmm11, xmm14
00007871bd3d34de  mulpd xmm11, xmm13
00007871bd3d34e3  vcmppd xmm6, xmm11, xmm11, 0x03
00007871bd3d34e9  ptest xmm6, xmm6
00007871bd3d34ee  jnz 0x00007871BD3D8341
00007871bd3d34f4  movaps xmm14, xmm12
00007871bd3d34f8  addpd xmm14, xmm9
00007871bd3d34fd  vcmppd xmm13, xmm14, xmm14, 0x03
00007871bd3d3503  ptest xmm13, xmm13
00007871bd3d3509  jnz 0x00007871BD3D8485
00007871bd3d350f  movaps [r15+0x140], xmm14
00007871bd3d3517  movaps xmm13, xmm8
00007871bd3d351b  addpd xmm13, xmm15
00007871bd3d3520  vcmppd xmm12, xmm13, xmm13, 0x03
00007871bd3d3526  ptest xmm12, xmm12
00007871bd3d352c  jnz 0x00007871BD3D85C9
00007871bd3d3532  movaps [r15+0x150], xmm13
00007871bd3d353a  movaps xmm15, xmm1
00007871bd3d353e  addpd xmm15, xmm10
00007871bd3d3543  vcmppd xmm12, xmm15, xmm15, 0x03
00007871bd3d3549  ptest xmm12, xmm12
00007871bd3d354f  jnz 0x00007871BD3D870D
00007871bd3d3555  movaps [r15+0x160], xmm15
00007871bd3d355d  movaps xmm1, xmm7
00007871bd3d3560  addpd xmm1, xmm11
00007871bd3d3565  vcmppd xmm12, xmm1, xmm1, 0x03
00007871bd3d356a  ptest xmm12, xmm12
00007871bd3d3570  jnz 0x00007871BD3D8850
00007871bd3d3576  movaps [r15+0x120], xmm1
00007871bd3d357e  mov eax, 0x432200
00007871bd3d3583  movups [r13+rax*1], xmm14
00007871bd3d3589  mov eax, 0x432210
00007871bd3d358e  movups [r13+rax*1], xmm13
00007871bd3d3594  mov eax, 0x432220
00007871bd3d3599  movups [r13+rax*1], xmm15
00007871bd3d359f  mov eax, 0x432230
00007871bd3d35a4  movups [r13+rax*1], xmm1
00007871bd3d35aa  mov eax, [r15+0x108]
00007871bd3d35b1  sahf
00007871bd3d35b2  jnz 0x00007871BD3D35E4
00007871bd3d35b4  cmp dword ptr [r15+0x318], 0x00
00007871bd3d35bc  jz 0x00007871BD3DEAE0
00007871bd3d35c2  nop [rax+rax*1], ax
00007871bd3d35cb  nop [rax+rax*1], eax
00007871bd3d35d3  mov eax, 0x4106D0
00007871bd3d35d8  mov [r15+0x100], rax
00007871bd3d35df  jmp 0x00007871BD1FE110
00007871bd3d35e4  cmp dword ptr [r15+0x318], 0x00
00007871bd3d35ec  jz 0x00007871BD3D89C0
00007871bd3d35f2  nop [rax+rax*1], ax
00007871bd3d35fb  nop [rax+rax*1], eax
00007871bd3d3603  mov eax, 0x410504
00007871bd3d3608  mov [r15+0x100], rax
00007871bd3d360f  jmp 0x00007871BD1FE110
00007871bd3d3614  int3
00007871bd3d3615  call 0x00007871BD2D64F0
00007871bd3d361a  jmp 0x00007871BD3D2311
00007871bd3d361f  call 0x00007871BD2E5820
00007871bd3d3624  jmp 0x00007871BD3D231E
00007871bd3d3629  call 0x00007871BD2E3320
00007871bd3d362e  jmp 0x00007871BD3D2332
00007871bd3d3633  call 0x00007871BD2E20A0
00007871bd3d3638  jmp 0x00007871BD3D233C
00007871bd3d363d  call 0x00007871BD209D70
00007871bd3d3642  jmp 0x00007871BD3D234A
00007871bd3d3647  call 0x00007871BD2DFBC0
00007871bd3d364c  jmp 0x00007871BD3D2354
00007871bd3d3651  call 0x00007871BD2C4740
00007871bd3d3656  jmp 0x00007871BD3D2368
00007871bd3d365b  call 0x00007871BD2B5400
00007871bd3d3660  jmp 0x00007871BD3D2375
00007871bd3d3665  call 0x00007871BD2B52F0
00007871bd3d366a  jmp 0x00007871BD3D2382
00007871bd3d366f  call 0x00007871BD2C4620
00007871bd3d3674  jmp 0x00007871BD3D238F
00007871bd3d3679  call 0x00007871BD2BD750
00007871bd3d367e  jmp 0x00007871BD3D239C
00007871bd3d3683  call 0x00007871BD2BC4E0
00007871bd3d3688  jmp 0x00007871BD3D23A9
00007871bd3d368d  call 0x00007871BD2BB270
00007871bd3d3692  jmp 0x00007871BD3D23B6
00007871bd3d3697  call 0x00007871BD2BA000
00007871bd3d369c  jmp 0x00007871BD3D23C3
00007871bd3d36a1  call 0x00007871BD2C4740
00007871bd3d36a6  jmp 0x00007871BD3D23D0
00007871bd3d36ab  call 0x00007871BD2B5400
00007871bd3d36b0  jmp 0x00007871BD3D23DD
00007871bd3d36b5  call 0x00007871BD2B52F0
00007871bd3d36ba  jmp 0x00007871BD3D23EA
00007871bd3d36bf  call 0x00007871BD2C4620
00007871bd3d36c4  jmp 0x00007871BD3D23F7
00007871bd3d36c9  call 0x00007871BD2B8D90
00007871bd3d36ce  jmp 0x00007871BD3D2404
00007871bd3d36d3  call 0x00007871BD2B8A20
00007871bd3d36d8  jmp 0x00007871BD3D2411
00007871bd3d36dd  call 0x00007871BD2B77B0
00007871bd3d36e2  jmp 0x00007871BD3D241B
00007871bd3d36e7  call 0x00007871BD2B6550
00007871bd3d36ec  jmp 0x00007871BD3D2425
00007871bd3d36f1  call 0x00007871BD2B5400
00007871bd3d36f6  jmp 0x00007871BD3D2437
00007871bd3d36fb  call 0x00007871BD2C0FC0
00007871bd3d3700  jmp 0x00007871BD3D2441
00007871bd3d3705  call 0x00007871BD2B52F0
00007871bd3d370a  jmp 0x00007871BD3D244B
00007871bd3d370f  call 0x00007871BD2C0EA0
00007871bd3d3714  jmp 0x00007871BD3D2455
00007871bd3d3719  call 0x00007871BD2BFD50
00007871bd3d371e  jmp 0x00007871BD3D245F
00007871bd3d3723  call 0x00007871BD2B8EA0
00007871bd3d3728  jmp 0x00007871BD3D2469
00007871bd3d372d  call 0x00007871BD2BFC30
00007871bd3d3732  jmp 0x00007871BD3D2476
00007871bd3d3737  call 0x00007871BD2B8D90
00007871bd3d373c  jmp 0x00007871BD3D2483
00007871bd3d3741  call 0x00007871BD2B52F0
00007871bd3d3746  jmp 0x00007871BD3D2496
00007871bd3d374b  call 0x00007871BD2B52F0
00007871bd3d3750  jmp 0x00007871BD3D24A9
00007871bd3d3755  call 0x00007871BD2C0FC0
00007871bd3d375a  jmp 0x00007871BD3D24B6
00007871bd3d375f  call 0x00007871BD2C0FC0
00007871bd3d3764  jmp 0x00007871BD3D24C9
00007871bd3d3769  call 0x00007871BD2C0EA0
00007871bd3d376e  jmp 0x00007871BD3D24D6
00007871bd3d3773  call 0x00007871BD2B52F0
00007871bd3d3778  jmp 0x00007871BD3D24E9
00007871bd3d377d  call 0x00007871BD2B52F0
00007871bd3d3782  jmp 0x00007871BD3D24FC
00007871bd3d3787  call 0x00007871BD2B52F0
00007871bd3d378c  jmp 0x00007871BD3D250F
00007871bd3d3791  call 0x00007871BD2B52F0
00007871bd3d3796  jmp 0x00007871BD3D252A
00007871bd3d379b  call 0x00007871BD2B52F0
00007871bd3d37a0  jmp 0x00007871BD3D253D
00007871bd3d37a5  call 0x00007871BD2B5400
00007871bd3d37aa  jmp 0x00007871BD3D257E
00007871bd3d37af  call 0x00007871BD2C0FC0
00007871bd3d37b4  jmp 0x00007871BD3D258B
00007871bd3d37b9  call 0x00007871BD2B52F0
00007871bd3d37be  jmp 0x00007871BD3D2598
00007871bd3d37c3  call 0x00007871BD2C0EA0
00007871bd3d37c8  jmp 0x00007871BD3D25A5
00007871bd3d37cd  call 0x00007871BD1FF540
00007871bd3d37d2  jmp 0x00007871BD3D25C3
00007871bd3d37d7  call 0x00007871BD208C20
00007871bd3d37dc  jmp 0x00007871BD3D25CD
00007871bd3d37e1  call 0x00007871BD2E21C0
00007871bd3d37e6  jmp 0x00007871BD3D25D3
00007871bd3d37eb  call 0x00007871BD1FF540
00007871bd3d37f0  jmp 0x00007871BD3D25E3
00007871bd3d37f5  call 0x00007871BD2C0370
00007871bd3d37fa  jmp 0x00007871BD3D2611
00007871bd3d37ff  call 0x00007871BD2BF100
00007871bd3d3804  jmp 0x00007871BD3D261A
00007871bd3d3809  call 0x00007871BD2C0370
00007871bd3d380e  jmp 0x00007871BD3D2674
00007871bd3d3813  call 0x00007871BD2BF100
00007871bd3d3818  jmp 0x00007871BD3D267D
00007871bd3d381d  call 0x00007871BD2C0370
00007871bd3d3822  jmp 0x00007871BD3D26C6
00007871bd3d3827  call 0x00007871BD2BF100
00007871bd3d382c  jmp 0x00007871BD3D26CF
00007871bd3d3831  call 0x00007871BD20B720
00007871bd3d3836  jmp 0x00007871BD3D2714
00007871bd3d383b  call 0x00007871BD2B47C0
00007871bd3d3840  jmp 0x00007871BD3D2727
00007871bd3d3845  call 0x00007871BD208B00
00007871bd3d384a  jmp 0x00007871BD3D273E
00007871bd3d384f  call 0x00007871BD1FF430
00007871bd3d3854  jmp 0x00007871BD3D2751
00007871bd3d3859  call 0x00007871BD1FF430
00007871bd3d385e  jmp 0x00007871BD3D2764
00007871bd3d3863  sub rsp, 0x08
00007871bd3d3867  push rax
00007871bd3d3868  push rcx
00007871bd3d3869  push rdx
00007871bd3d386a  push rdi
00007871bd3d386b  push rsi
00007871bd3d386c  push r8
00007871bd3d386e  push r9
00007871bd3d3870  push r10
00007871bd3d3872  push r11
00007871bd3d3874  sub rsp, 0xF0
00007871bd3d387b  vmovaps [rsp], xmm0
00007871bd3d3880  vmovaps [rsp+0x10], xmm2
00007871bd3d3886  vmovaps [rsp+0x20], xmm3
00007871bd3d388c  vmovaps [rsp+0x30], xmm4
00007871bd3d3892  vmovaps [rsp+0x40], xmm5
00007871bd3d3898  vmovaps [rsp+0x50], xmm6
00007871bd3d389e  vmovaps [rsp+0x60], xmm7
00007871bd3d38a4  vmovaps [rsp+0x70], xmm8
00007871bd3d38aa  vmovaps [rsp+0x80], xmm9
00007871bd3d38b3  vmovaps [rsp+0x90], xmm10
00007871bd3d38bc  vmovaps [rsp+0xA0], xmm11
00007871bd3d38c5  vmovaps [rsp+0xB0], xmm12
00007871bd3d38ce  vmovaps [rsp+0xC0], xmm13
00007871bd3d38d7  vmovaps [rsp+0xD0], xmm14
00007871bd3d38e0  vmovaps [rsp+0xE0], xmm15
00007871bd3d38e9  sub rsp, 0x30
00007871bd3d38ed  movaps [rsp], xmm1
00007871bd3d38f1  movaps [rsp+0x10], xmm12
00007871bd3d38f7  movaps [rsp+0x20], xmm15
00007871bd3d38fd  lea rdi, [rsp]
00007871bd3d3901  mov esi, 0x00
00007871bd3d3906  mov rax, 0x5BA2FDD2A530
00007871bd3d3910  call rax
00007871bd3d3912  movaps xmm1, [rsp]
00007871bd3d3916  add rsp, 0x30
00007871bd3d391a  vmovaps xmm0, [rsp]
00007871bd3d391f  vmovaps xmm2, [rsp+0x10]
00007871bd3d3925  vmovaps xmm3, [rsp+0x20]
00007871bd3d392b  vmovaps xmm4, [rsp+0x30]
00007871bd3d3931  vmovaps xmm5, [rsp+0x40]
00007871bd3d3937  vmovaps xmm6, [rsp+0x50]
00007871bd3d393d  vmovaps xmm7, [rsp+0x60]
00007871bd3d3943  vmovaps xmm8, [rsp+0x70]
00007871bd3d3949  vmovaps xmm9, [rsp+0x80]
00007871bd3d3952  vmovaps xmm10, [rsp+0x90]
00007871bd3d395b  vmovaps xmm11, [rsp+0xA0]
00007871bd3d3964  vmovaps xmm12, [rsp+0xB0]
00007871bd3d396d  vmovaps xmm13, [rsp+0xC0]
00007871bd3d3976  vmovaps xmm14, [rsp+0xD0]
00007871bd3d397f  vmovaps xmm15, [rsp+0xE0]
00007871bd3d3988  add rsp, 0xF0
00007871bd3d398f  pop r11
00007871bd3d3991  pop r10
00007871bd3d3993  pop r9
00007871bd3d3995  pop r8
00007871bd3d3997  pop rsi
00007871bd3d3998  pop rdi
00007871bd3d3999  pop rdx
00007871bd3d399a  pop rcx
00007871bd3d399b  pop rax
00007871bd3d399c  add rsp, 0x08
00007871bd3d39a0  jmp 0x00007871BD3D27B2
00007871bd3d39a5  sub rsp, 0x08
00007871bd3d39a9  push rax
00007871bd3d39aa  push rcx
00007871bd3d39ab  push rdx
00007871bd3d39ac  push rdi
00007871bd3d39ad  push rsi
00007871bd3d39ae  push r8
00007871bd3d39b0  push r9
00007871bd3d39b2  push r10
00007871bd3d39b4  push r11
00007871bd3d39b6  sub rsp, 0xF0
00007871bd3d39bd  vmovaps [rsp], xmm0
00007871bd3d39c2  vmovaps [rsp+0x10], xmm1
00007871bd3d39c8  vmovaps [rsp+0x20], xmm2
00007871bd3d39ce  vmovaps [rsp+0x30], xmm3
00007871bd3d39d4  vmovaps [rsp+0x40], xmm4
00007871bd3d39da  vmovaps [rsp+0x50], xmm5
00007871bd3d39e0  vmovaps [rsp+0x60], xmm6
00007871bd3d39e6  vmovaps [rsp+0x70], xmm7
00007871bd3d39ec  vmovaps [rsp+0x80], xmm8
00007871bd3d39f5  vmovaps [rsp+0x90], xmm9
00007871bd3d39fe  vmovaps [rsp+0xA0], xmm10
00007871bd3d3a07  vmovaps [rsp+0xB0], xmm11
00007871bd3d3a10  vmovaps [rsp+0xC0], xmm12
00007871bd3d3a19  vmovaps [rsp+0xD0], xmm13
00007871bd3d3a22  vmovaps [rsp+0xE0], xmm15
00007871bd3d3a2b  sub rsp, 0x30
00007871bd3d3a2f  movaps [rsp], xmm14
00007871bd3d3a34  movaps [rsp+0x10], xmm1
00007871bd3d3a39  movaps [rsp+0x20], xmm15
00007871bd3d3a3f  lea rdi, [rsp]
00007871bd3d3a43  mov esi, 0x00
00007871bd3d3a48  mov rax, 0x5BA2FDD2A530
00007871bd3d3a52  call rax
00007871bd3d3a54  movaps xmm14, [rsp]
00007871bd3d3a59  add rsp, 0x30
00007871bd3d3a5d  vmovaps xmm0, [rsp]
00007871bd3d3a62  vmovaps xmm1, [rsp+0x10]
00007871bd3d3a68  vmovaps xmm2, [rsp+0x20]
00007871bd3d3a6e  vmovaps xmm3, [rsp+0x30]
00007871bd3d3a74  vmovaps xmm4, [rsp+0x40]
00007871bd3d3a7a  vmovaps xmm5, [rsp+0x50]
00007871bd3d3a80  vmovaps xmm6, [rsp+0x60]
00007871bd3d3a86  vmovaps xmm7, [rsp+0x70]
00007871bd3d3a8c  vmovaps xmm8, [rsp+0x80]
00007871bd3d3a95  vmovaps xmm9, [rsp+0x90]
00007871bd3d3a9e  vmovaps xmm10, [rsp+0xA0]
00007871bd3d3aa7  vmovaps xmm11, [rsp+0xB0]
00007871bd3d3ab0  vmovaps xmm12, [rsp+0xC0]
00007871bd3d3ab9  vmovaps xmm13, [rsp+0xD0]
00007871bd3d3ac2  vmovaps xmm15, [rsp+0xE0]
00007871bd3d3acb  add rsp, 0xF0
00007871bd3d3ad2  pop r11
00007871bd3d3ad4  pop r10
00007871bd3d3ad6  pop r9
00007871bd3d3ad8  pop r8
00007871bd3d3ada  pop rsi
00007871bd3d3adb  pop rdi
00007871bd3d3adc  pop rdx
00007871bd3d3add  pop rcx
00007871bd3d3ade  pop rax
00007871bd3d3adf  add rsp, 0x08
00007871bd3d3ae3  jmp 0x00007871BD3D2800
00007871bd3d3ae8  sub rsp, 0x08
00007871bd3d3aec  push rax
00007871bd3d3aed  push rcx
00007871bd3d3aee  push rdx
00007871bd3d3aef  push rdi
00007871bd3d3af0  push rsi
00007871bd3d3af1  push r8
00007871bd3d3af3  push r9
00007871bd3d3af5  push r10
00007871bd3d3af7  push r11
00007871bd3d3af9  sub rsp, 0xF0
00007871bd3d3b00  vmovaps [rsp], xmm0
00007871bd3d3b05  vmovaps [rsp+0x10], xmm1
00007871bd3d3b0b  vmovaps [rsp+0x20], xmm2
00007871bd3d3b11  vmovaps [rsp+0x30], xmm3
00007871bd3d3b17  vmovaps [rsp+0x40], xmm4
00007871bd3d3b1d  vmovaps [rsp+0x50], xmm5
00007871bd3d3b23  vmovaps [rsp+0x60], xmm6
00007871bd3d3b29  vmovaps [rsp+0x70], xmm7
00007871bd3d3b2f  vmovaps [rsp+0x80], xmm8
00007871bd3d3b38  vmovaps [rsp+0x90], xmm9
00007871bd3d3b41  vmovaps [rsp+0xA0], xmm10
00007871bd3d3b4a  vmovaps [rsp+0xB0], xmm11
00007871bd3d3b53  vmovaps [rsp+0xC0], xmm12
00007871bd3d3b5c  vmovaps [rsp+0xD0], xmm13
00007871bd3d3b65  vmovaps [rsp+0xE0], xmm14
00007871bd3d3b6e  sub rsp, 0x30
00007871bd3d3b72  movaps [rsp], xmm15
00007871bd3d3b77  movaps [rsp+0x10], xmm12
00007871bd3d3b7d  movaps [rsp+0x20], xmm13
00007871bd3d3b83  lea rdi, [rsp]
00007871bd3d3b87  mov esi, 0x00
00007871bd3d3b8c  mov rax, 0x5BA2FDD2A530
00007871bd3d3b96  call rax
00007871bd3d3b98  movaps xmm15, [rsp]
00007871bd3d3b9d  add rsp, 0x30
00007871bd3d3ba1  vmovaps xmm0, [rsp]
00007871bd3d3ba6  vmovaps xmm1, [rsp+0x10]
00007871bd3d3bac  vmovaps xmm2, [rsp+0x20]
00007871bd3d3bb2  vmovaps xmm3, [rsp+0x30]
00007871bd3d3bb8  vmovaps xmm4, [rsp+0x40]
00007871bd3d3bbe  vmovaps xmm5, [rsp+0x50]
00007871bd3d3bc4  vmovaps xmm6, [rsp+0x60]
00007871bd3d3bca  vmovaps xmm7, [rsp+0x70]
00007871bd3d3bd0  vmovaps xmm8, [rsp+0x80]
00007871bd3d3bd9  vmovaps xmm9, [rsp+0x90]
00007871bd3d3be2  vmovaps xmm10, [rsp+0xA0]
00007871bd3d3beb  vmovaps xmm11, [rsp+0xB0]
00007871bd3d3bf4  vmovaps xmm12, [rsp+0xC0]
00007871bd3d3bfd  vmovaps xmm13, [rsp+0xD0]
00007871bd3d3c06  vmovaps xmm14, [rsp+0xE0]
00007871bd3d3c0f  add rsp, 0xF0
00007871bd3d3c16  pop r11
00007871bd3d3c18  pop r10
00007871bd3d3c1a  pop r9
00007871bd3d3c1c  pop r8
00007871bd3d3c1e  pop rsi
00007871bd3d3c1f  pop rdi
00007871bd3d3c20  pop rdx
00007871bd3d3c21  pop rcx
00007871bd3d3c22  pop rax
00007871bd3d3c23  add rsp, 0x08
00007871bd3d3c27  jmp 0x00007871BD3D2835
00007871bd3d3c2c  sub rsp, 0x08
00007871bd3d3c30  push rax
00007871bd3d3c31  push rcx
00007871bd3d3c32  push rdx
00007871bd3d3c33  push rdi
00007871bd3d3c34  push rsi
00007871bd3d3c35  push r8
00007871bd3d3c37  push r9
00007871bd3d3c39  push r10
00007871bd3d3c3b  push r11
00007871bd3d3c3d  sub rsp, 0xF0
00007871bd3d3c44  vmovaps [rsp], xmm0
00007871bd3d3c49  vmovaps [rsp+0x10], xmm2
00007871bd3d3c4f  vmovaps [rsp+0x20], xmm3
00007871bd3d3c55  vmovaps [rsp+0x30], xmm4
00007871bd3d3c5b  vmovaps [rsp+0x40], xmm5
00007871bd3d3c61  vmovaps [rsp+0x50], xmm6
00007871bd3d3c67  vmovaps [rsp+0x60], xmm7
00007871bd3d3c6d  vmovaps [rsp+0x70], xmm8
00007871bd3d3c73  vmovaps [rsp+0x80], xmm9
00007871bd3d3c7c  vmovaps [rsp+0x90], xmm10
00007871bd3d3c85  vmovaps [rsp+0xA0], xmm11
00007871bd3d3c8e  vmovaps [rsp+0xB0], xmm12
00007871bd3d3c97  vmovaps [rsp+0xC0], xmm13
00007871bd3d3ca0  vmovaps [rsp+0xD0], xmm14
00007871bd3d3ca9  vmovaps [rsp+0xE0], xmm15
00007871bd3d3cb2  sub rsp, 0x30
00007871bd3d3cb6  movaps [rsp], xmm1
00007871bd3d3cba  movaps [rsp+0x10], xmm12
00007871bd3d3cc0  movaps [rsp+0x20], xmm10
00007871bd3d3cc6  lea rdi, [rsp]
00007871bd3d3cca  mov esi, 0x00
00007871bd3d3ccf  mov rax, 0x5BA2FDD2A530
00007871bd3d3cd9  call rax
00007871bd3d3cdb  movaps xmm1, [rsp]
00007871bd3d3cdf  add rsp, 0x30
00007871bd3d3ce3  vmovaps xmm0, [rsp]
00007871bd3d3ce8  vmovaps xmm2, [rsp+0x10]
00007871bd3d3cee  vmovaps xmm3, [rsp+0x20]
00007871bd3d3cf4  vmovaps xmm4, [rsp+0x30]
00007871bd3d3cfa  vmovaps xmm5, [rsp+0x40]
00007871bd3d3d00  vmovaps xmm6, [rsp+0x50]
00007871bd3d3d06  vmovaps xmm7, [rsp+0x60]
00007871bd3d3d0c  vmovaps xmm8, [rsp+0x70]
00007871bd3d3d12  vmovaps xmm9, [rsp+0x80]
00007871bd3d3d1b  vmovaps xmm10, [rsp+0x90]
00007871bd3d3d24  vmovaps xmm11, [rsp+0xA0]
00007871bd3d3d2d  vmovaps xmm12, [rsp+0xB0]
00007871bd3d3d36  vmovaps xmm13, [rsp+0xC0]
00007871bd3d3d3f  vmovaps xmm14, [rsp+0xD0]
00007871bd3d3d48  vmovaps xmm15, [rsp+0xE0]
00007871bd3d3d51  add rsp, 0xF0
00007871bd3d3d58  pop r11
00007871bd3d3d5a  pop r10
00007871bd3d3d5c  pop r9
00007871bd3d3d5e  pop r8
00007871bd3d3d60  pop rsi
00007871bd3d3d61  pop rdi
00007871bd3d3d62  pop rdx
00007871bd3d3d63  pop rcx
00007871bd3d3d64  pop rax
00007871bd3d3d65  add rsp, 0x08
00007871bd3d3d69  jmp 0x00007871BD3D284F
00007871bd3d3d6e  sub rsp, 0x08
00007871bd3d3d72  push rax
00007871bd3d3d73  push rcx
00007871bd3d3d74  push rdx
00007871bd3d3d75  push rdi
00007871bd3d3d76  push rsi
00007871bd3d3d77  push r8
00007871bd3d3d79  push r9
00007871bd3d3d7b  push r10
00007871bd3d3d7d  push r11
00007871bd3d3d7f  sub rsp, 0xF0
00007871bd3d3d86  vmovaps [rsp], xmm0
00007871bd3d3d8b  vmovaps [rsp+0x10], xmm1
00007871bd3d3d91  vmovaps [rsp+0x20], xmm2
00007871bd3d3d97  vmovaps [rsp+0x30], xmm3
00007871bd3d3d9d  vmovaps [rsp+0x40], xmm4
00007871bd3d3da3  vmovaps [rsp+0x50], xmm5
00007871bd3d3da9  vmovaps [rsp+0x60], xmm6
00007871bd3d3daf  vmovaps [rsp+0x70], xmm7
00007871bd3d3db5  vmovaps [rsp+0x80], xmm8
00007871bd3d3dbe  vmovaps [rsp+0x90], xmm9
00007871bd3d3dc7  vmovaps [rsp+0xA0], xmm10
00007871bd3d3dd0  vmovaps [rsp+0xB0], xmm11
00007871bd3d3dd9  vmovaps [rsp+0xC0], xmm12
00007871bd3d3de2  vmovaps [rsp+0xD0], xmm14
00007871bd3d3deb  vmovaps [rsp+0xE0], xmm15
00007871bd3d3df4  sub rsp, 0x30
00007871bd3d3df8  movaps [rsp], xmm13
00007871bd3d3dfd  movaps [rsp+0x10], xmm12
00007871bd3d3e03  movaps [rsp+0x20], xmm2
00007871bd3d3e08  lea rdi, [rsp]
00007871bd3d3e0c  mov esi, 0x00
00007871bd3d3e11  mov rax, 0x5BA2FDD2A530
00007871bd3d3e1b  call rax
00007871bd3d3e1d  movaps xmm13, [rsp]
00007871bd3d3e22  add rsp, 0x30
00007871bd3d3e26  vmovaps xmm0, [rsp]
00007871bd3d3e2b  vmovaps xmm1, [rsp+0x10]
00007871bd3d3e31  vmovaps xmm2, [rsp+0x20]
00007871bd3d3e37  vmovaps xmm3, [rsp+0x30]
00007871bd3d3e3d  vmovaps xmm4, [rsp+0x40]
00007871bd3d3e43  vmovaps xmm5, [rsp+0x50]
00007871bd3d3e49  vmovaps xmm6, [rsp+0x60]
00007871bd3d3e4f  vmovaps xmm7, [rsp+0x70]
00007871bd3d3e55  vmovaps xmm8, [rsp+0x80]
00007871bd3d3e5e  vmovaps xmm9, [rsp+0x90]
00007871bd3d3e67  vmovaps xmm10, [rsp+0xA0]
00007871bd3d3e70  vmovaps xmm11, [rsp+0xB0]
00007871bd3d3e79  vmovaps xmm12, [rsp+0xC0]
00007871bd3d3e82  vmovaps xmm14, [rsp+0xD0]
00007871bd3d3e8b  vmovaps xmm15, [rsp+0xE0]
00007871bd3d3e94  add rsp, 0xF0
00007871bd3d3e9b  pop r11
00007871bd3d3e9d  pop r10
00007871bd3d3e9f  pop r9
00007871bd3d3ea1  pop r8
00007871bd3d3ea3  pop rsi
00007871bd3d3ea4  pop rdi
00007871bd3d3ea5  pop rdx
00007871bd3d3ea6  pop rcx
00007871bd3d3ea7  pop rax
00007871bd3d3ea8  add rsp, 0x08
00007871bd3d3eac  jmp 0x00007871BD3D286A
00007871bd3d3eb1  sub rsp, 0x08
00007871bd3d3eb5  push rax
00007871bd3d3eb6  push rcx
00007871bd3d3eb7  push rdx
00007871bd3d3eb8  push rdi
00007871bd3d3eb9  push rsi
00007871bd3d3eba  push r8
00007871bd3d3ebc  push r9
00007871bd3d3ebe  push r10
00007871bd3d3ec0  push r11
00007871bd3d3ec2  sub rsp, 0xF0
00007871bd3d3ec9  vmovaps [rsp], xmm0
00007871bd3d3ece  vmovaps [rsp+0x10], xmm2
00007871bd3d3ed4  vmovaps [rsp+0x20], xmm3
00007871bd3d3eda  vmovaps [rsp+0x30], xmm4
00007871bd3d3ee0  vmovaps [rsp+0x40], xmm5
00007871bd3d3ee6  vmovaps [rsp+0x50], xmm6
00007871bd3d3eec  vmovaps [rsp+0x60], xmm7
00007871bd3d3ef2  vmovaps [rsp+0x70], xmm8
00007871bd3d3ef8  vmovaps [rsp+0x80], xmm9
00007871bd3d3f01  vmovaps [rsp+0x90], xmm10
00007871bd3d3f0a  vmovaps [rsp+0xA0], xmm11
00007871bd3d3f13  vmovaps [rsp+0xB0], xmm12
00007871bd3d3f1c  vmovaps [rsp+0xC0], xmm13
00007871bd3d3f25  vmovaps [rsp+0xD0], xmm14
00007871bd3d3f2e  vmovaps [rsp+0xE0], xmm15
00007871bd3d3f37  sub rsp, 0x30
00007871bd3d3f3b  movaps [rsp], xmm1
00007871bd3d3f3f  movaps [rsp+0x10], xmm10
00007871bd3d3f45  movaps [rsp+0x20], xmm2
00007871bd3d3f4a  lea rdi, [rsp]
00007871bd3d3f4e  mov esi, 0x00
00007871bd3d3f53  mov rax, 0x5BA2FDD2A530
00007871bd3d3f5d  call rax
00007871bd3d3f5f  movaps xmm1, [rsp]
00007871bd3d3f63  add rsp, 0x30
00007871bd3d3f67  vmovaps xmm0, [rsp]
00007871bd3d3f6c  vmovaps xmm2, [rsp+0x10]
00007871bd3d3f72  vmovaps xmm3, [rsp+0x20]
00007871bd3d3f78  vmovaps xmm4, [rsp+0x30]
00007871bd3d3f7e  vmovaps xmm5, [rsp+0x40]
00007871bd3d3f84  vmovaps xmm6, [rsp+0x50]
00007871bd3d3f8a  vmovaps xmm7, [rsp+0x60]
00007871bd3d3f90  vmovaps xmm8, [rsp+0x70]
00007871bd3d3f96  vmovaps xmm9, [rsp+0x80]
00007871bd3d3f9f  vmovaps xmm10, [rsp+0x90]
00007871bd3d3fa8  vmovaps xmm11, [rsp+0xA0]
00007871bd3d3fb1  vmovaps xmm12, [rsp+0xB0]
00007871bd3d3fba  vmovaps xmm13, [rsp+0xC0]
00007871bd3d3fc3  vmovaps xmm14, [rsp+0xD0]
00007871bd3d3fcc  vmovaps xmm15, [rsp+0xE0]
00007871bd3d3fd5  add rsp, 0xF0
00007871bd3d3fdc  pop r11
00007871bd3d3fde  pop r10
00007871bd3d3fe0  pop r9
00007871bd3d3fe2  pop r8
00007871bd3d3fe4  pop rsi
00007871bd3d3fe5  pop rdi
00007871bd3d3fe6  pop rdx
00007871bd3d3fe7  pop rcx
00007871bd3d3fe8  pop rax
00007871bd3d3fe9  add rsp, 0x08
00007871bd3d3fed  jmp 0x00007871BD3D28D2
00007871bd3d3ff2  sub rsp, 0x08
00007871bd3d3ff6  push rax
00007871bd3d3ff7  push rcx
00007871bd3d3ff8  push rdx
00007871bd3d3ff9  push rdi
00007871bd3d3ffa  push rsi
00007871bd3d3ffb  push r8
00007871bd3d3ffd  push r9
00007871bd3d3fff  push r10
00007871bd3d4001  push r11
00007871bd3d4003  sub rsp, 0xF0
00007871bd3d400a  vmovaps [rsp], xmm0
00007871bd3d400f  vmovaps [rsp+0x10], xmm1
00007871bd3d4015  vmovaps [rsp+0x20], xmm2
00007871bd3d401b  vmovaps [rsp+0x30], xmm3
00007871bd3d4021  vmovaps [rsp+0x40], xmm4
00007871bd3d4027  vmovaps [rsp+0x50], xmm5
00007871bd3d402d  vmovaps [rsp+0x60], xmm6
00007871bd3d4033  vmovaps [rsp+0x70], xmm7
00007871bd3d4039  vmovaps [rsp+0x80], xmm8
00007871bd3d4042  vmovaps [rsp+0x90], xmm9
00007871bd3d404b  vmovaps [rsp+0xA0], xmm10
00007871bd3d4054  vmovaps [rsp+0xB0], xmm11
00007871bd3d405d  vmovaps [rsp+0xC0], xmm12
00007871bd3d4066  vmovaps [rsp+0xD0], xmm13
00007871bd3d406f  vmovaps [rsp+0xE0], xmm14
00007871bd3d4078  sub rsp, 0x30
00007871bd3d407c  movaps [rsp], xmm15
00007871bd3d4081  movaps [rsp+0x10], xmm10
00007871bd3d4087  movaps [rsp+0x20], xmm2
00007871bd3d408c  lea rdi, [rsp]
00007871bd3d4090  mov esi, 0x00
00007871bd3d4095  mov rax, 0x5BA2FDD2A530
00007871bd3d409f  call rax
00007871bd3d40a1  movaps xmm15, [rsp]
00007871bd3d40a6  add rsp, 0x30
00007871bd3d40aa  vmovaps xmm0, [rsp]
00007871bd3d40af  vmovaps xmm1, [rsp+0x10]
00007871bd3d40b5  vmovaps xmm2, [rsp+0x20]
00007871bd3d40bb  vmovaps xmm3, [rsp+0x30]
00007871bd3d40c1  vmovaps xmm4, [rsp+0x40]
00007871bd3d40c7  vmovaps xmm5, [rsp+0x50]
00007871bd3d40cd  vmovaps xmm6, [rsp+0x60]
00007871bd3d40d3  vmovaps xmm7, [rsp+0x70]
00007871bd3d40d9  vmovaps xmm8, [rsp+0x80]
00007871bd3d40e2  vmovaps xmm9, [rsp+0x90]
00007871bd3d40eb  vmovaps xmm10, [rsp+0xA0]
00007871bd3d40f4  vmovaps xmm11, [rsp+0xB0]
00007871bd3d40fd  vmovaps xmm12, [rsp+0xC0]
00007871bd3d4106  vmovaps xmm13, [rsp+0xD0]
00007871bd3d410f  vmovaps xmm14, [rsp+0xE0]
00007871bd3d4118  add rsp, 0xF0
00007871bd3d411f  pop r11
00007871bd3d4121  pop r10
00007871bd3d4123  pop r9
00007871bd3d4125  pop r8
00007871bd3d4127  pop rsi
00007871bd3d4128  pop rdi
00007871bd3d4129  pop rdx
00007871bd3d412a  pop rcx
00007871bd3d412b  pop rax
00007871bd3d412c  add rsp, 0x08
00007871bd3d4130  jmp 0x00007871BD3D2924
00007871bd3d4135  sub rsp, 0x08
00007871bd3d4139  push rax
00007871bd3d413a  push rcx
00007871bd3d413b  push rdx
00007871bd3d413c  push rdi
00007871bd3d413d  push rsi
00007871bd3d413e  push r8
00007871bd3d4140  push r9
00007871bd3d4142  push r10
00007871bd3d4144  push r11
00007871bd3d4146  sub rsp, 0xF0
00007871bd3d414d  vmovaps [rsp], xmm0
00007871bd3d4152  vmovaps [rsp+0x10], xmm2
00007871bd3d4158  vmovaps [rsp+0x20], xmm3
00007871bd3d415e  vmovaps [rsp+0x30], xmm4
00007871bd3d4164  vmovaps [rsp+0x40], xmm5
00007871bd3d416a  vmovaps [rsp+0x50], xmm6
00007871bd3d4170  vmovaps [rsp+0x60], xmm7
00007871bd3d4176  vmovaps [rsp+0x70], xmm8
00007871bd3d417c  vmovaps [rsp+0x80], xmm9
00007871bd3d4185  vmovaps [rsp+0x90], xmm10
00007871bd3d418e  vmovaps [rsp+0xA0], xmm11
00007871bd3d4197  vmovaps [rsp+0xB0], xmm12
00007871bd3d41a0  vmovaps [rsp+0xC0], xmm13
00007871bd3d41a9  vmovaps [rsp+0xD0], xmm14
00007871bd3d41b2  vmovaps [rsp+0xE0], xmm15
00007871bd3d41bb  sub rsp, 0x30
00007871bd3d41bf  movaps [rsp], xmm1
00007871bd3d41c3  movaps [rsp+0x10], xmm10
00007871bd3d41c9  movaps [rsp+0x20], xmm15
00007871bd3d41cf  lea rdi, [rsp]
00007871bd3d41d3  mov esi, 0x00
00007871bd3d41d8  mov rax, 0x5BA2FDD2A530
00007871bd3d41e2  call rax
00007871bd3d41e4  movaps xmm1, [rsp]
00007871bd3d41e8  add rsp, 0x30
00007871bd3d41ec  vmovaps xmm0, [rsp]
00007871bd3d41f1  vmovaps xmm2, [rsp+0x10]
00007871bd3d41f7  vmovaps xmm3, [rsp+0x20]
00007871bd3d41fd  vmovaps xmm4, [rsp+0x30]
00007871bd3d4203  vmovaps xmm5, [rsp+0x40]
00007871bd3d4209  vmovaps xmm6, [rsp+0x50]
00007871bd3d420f  vmovaps xmm7, [rsp+0x60]
00007871bd3d4215  vmovaps xmm8, [rsp+0x70]
00007871bd3d421b  vmovaps xmm9, [rsp+0x80]
00007871bd3d4224  vmovaps xmm10, [rsp+0x90]
00007871bd3d422d  vmovaps xmm11, [rsp+0xA0]
00007871bd3d4236  vmovaps xmm12, [rsp+0xB0]
00007871bd3d423f  vmovaps xmm13, [rsp+0xC0]
00007871bd3d4248  vmovaps xmm14, [rsp+0xD0]
00007871bd3d4251  vmovaps xmm15, [rsp+0xE0]
00007871bd3d425a  add rsp, 0xF0
00007871bd3d4261  pop r11
00007871bd3d4263  pop r10
00007871bd3d4265  pop r9
00007871bd3d4267  pop r8
00007871bd3d4269  pop rsi
00007871bd3d426a  pop rdi
00007871bd3d426b  pop rdx
00007871bd3d426c  pop rcx
00007871bd3d426d  pop rax
00007871bd3d426e  add rsp, 0x08
00007871bd3d4272  jmp 0x00007871BD3D2962
00007871bd3d4277  sub rsp, 0x08
00007871bd3d427b  push rax
00007871bd3d427c  push rcx
00007871bd3d427d  push rdx
00007871bd3d427e  push rdi
00007871bd3d427f  push rsi
00007871bd3d4280  push r8
00007871bd3d4282  push r9
00007871bd3d4284  push r10
00007871bd3d4286  push r11
00007871bd3d4288  sub rsp, 0xF0
00007871bd3d428f  vmovaps [rsp], xmm0
00007871bd3d4294  vmovaps [rsp+0x10], xmm1
00007871bd3d429a  vmovaps [rsp+0x20], xmm2
00007871bd3d42a0  vmovaps [rsp+0x30], xmm3
00007871bd3d42a6  vmovaps [rsp+0x40], xmm4
00007871bd3d42ac  vmovaps [rsp+0x50], xmm5
00007871bd3d42b2  vmovaps [rsp+0x60], xmm6
00007871bd3d42b8  vmovaps [rsp+0x70], xmm7
00007871bd3d42be  vmovaps [rsp+0x80], xmm8
00007871bd3d42c7  vmovaps [rsp+0x90], xmm9
00007871bd3d42d0  vmovaps [rsp+0xA0], xmm10
00007871bd3d42d9  vmovaps [rsp+0xB0], xmm11
00007871bd3d42e2  vmovaps [rsp+0xC0], xmm12
00007871bd3d42eb  vmovaps [rsp+0xD0], xmm13
00007871bd3d42f4  vmovaps [rsp+0xE0], xmm15
00007871bd3d42fd  sub rsp, 0x30
00007871bd3d4301  movaps [rsp], xmm14
00007871bd3d4306  movaps [rsp+0x10], xmm10
00007871bd3d430c  movaps [rsp+0x20], xmm15
00007871bd3d4312  lea rdi, [rsp]
00007871bd3d4316  mov esi, 0x00
00007871bd3d431b  mov rax, 0x5BA2FDD2A530
00007871bd3d4325  call rax
00007871bd3d4327  movaps xmm14, [rsp]
00007871bd3d432c  add rsp, 0x30
00007871bd3d4330  vmovaps xmm0, [rsp]
00007871bd3d4335  vmovaps xmm1, [rsp+0x10]
00007871bd3d433b  vmovaps xmm2, [rsp+0x20]
00007871bd3d4341  vmovaps xmm3, [rsp+0x30]
00007871bd3d4347  vmovaps xmm4, [rsp+0x40]
00007871bd3d434d  vmovaps xmm5, [rsp+0x50]
00007871bd3d4353  vmovaps xmm6, [rsp+0x60]
00007871bd3d4359  vmovaps xmm7, [rsp+0x70]
00007871bd3d435f  vmovaps xmm8, [rsp+0x80]
00007871bd3d4368  vmovaps xmm9, [rsp+0x90]
00007871bd3d4371  vmovaps xmm10, [rsp+0xA0]
00007871bd3d437a  vmovaps xmm11, [rsp+0xB0]
00007871bd3d4383  vmovaps xmm12, [rsp+0xC0]
00007871bd3d438c  vmovaps xmm13, [rsp+0xD0]
00007871bd3d4395  vmovaps xmm15, [rsp+0xE0]
00007871bd3d439e  add rsp, 0xF0
00007871bd3d43a5  pop r11
00007871bd3d43a7  pop r10
00007871bd3d43a9  pop r9
00007871bd3d43ab  pop r8
00007871bd3d43ad  pop rsi
00007871bd3d43ae  pop rdi
00007871bd3d43af  pop rdx
00007871bd3d43b0  pop rcx
00007871bd3d43b1  pop rax
00007871bd3d43b2  add rsp, 0x08
00007871bd3d43b6  jmp 0x00007871BD3D298E
00007871bd3d43bb  call 0x00007871BD1FF430
00007871bd3d43c0  jmp 0x00007871BD3D2A1E
00007871bd3d43c5  call 0x00007871BD1FF430
00007871bd3d43ca  jmp 0x00007871BD3D2A31
00007871bd3d43cf  sub rsp, 0x08
00007871bd3d43d3  push rax
00007871bd3d43d4  push rcx
00007871bd3d43d5  push rdx
00007871bd3d43d6  push rdi
00007871bd3d43d7  push rsi
00007871bd3d43d8  push r8
00007871bd3d43da  push r9
00007871bd3d43dc  push r10
00007871bd3d43de  push r11
00007871bd3d43e0  sub rsp, 0xF0
00007871bd3d43e7  vmovaps [rsp], xmm0
00007871bd3d43ec  vmovaps [rsp+0x10], xmm2
00007871bd3d43f2  vmovaps [rsp+0x20], xmm3
00007871bd3d43f8  vmovaps [rsp+0x30], xmm4
00007871bd3d43fe  vmovaps [rsp+0x40], xmm5
00007871bd3d4404  vmovaps [rsp+0x50], xmm6
00007871bd3d440a  vmovaps [rsp+0x60], xmm7
00007871bd3d4410  vmovaps [rsp+0x70], xmm8
00007871bd3d4416  vmovaps [rsp+0x80], xmm9
00007871bd3d441f  vmovaps [rsp+0x90], xmm10
00007871bd3d4428  vmovaps [rsp+0xA0], xmm11
00007871bd3d4431  vmovaps [rsp+0xB0], xmm12
00007871bd3d443a  vmovaps [rsp+0xC0], xmm13
00007871bd3d4443  vmovaps [rsp+0xD0], xmm14
00007871bd3d444c  vmovaps [rsp+0xE0], xmm15
00007871bd3d4455  sub rsp, 0x30
00007871bd3d4459  movaps [rsp], xmm1
00007871bd3d445d  movaps [rsp+0x10], xmm13
00007871bd3d4463  movaps [rsp+0x20], xmm2
00007871bd3d4468  lea rdi, [rsp]
00007871bd3d446c  mov esi, 0x00
00007871bd3d4471  mov rax, 0x5BA2FDD2A530
00007871bd3d447b  call rax
00007871bd3d447d  movaps xmm1, [rsp]
00007871bd3d4481  add rsp, 0x30
00007871bd3d4485  vmovaps xmm0, [rsp]
00007871bd3d448a  vmovaps xmm2, [rsp+0x10]
00007871bd3d4490  vmovaps xmm3, [rsp+0x20]
00007871bd3d4496  vmovaps xmm4, [rsp+0x30]
00007871bd3d449c  vmovaps xmm5, [rsp+0x40]
00007871bd3d44a2  vmovaps xmm6, [rsp+0x50]
00007871bd3d44a8  vmovaps xmm7, [rsp+0x60]
00007871bd3d44ae  vmovaps xmm8, [rsp+0x70]
00007871bd3d44b4  vmovaps xmm9, [rsp+0x80]
00007871bd3d44bd  vmovaps xmm10, [rsp+0x90]
00007871bd3d44c6  vmovaps xmm11, [rsp+0xA0]
00007871bd3d44cf  vmovaps xmm12, [rsp+0xB0]
00007871bd3d44d8  vmovaps xmm13, [rsp+0xC0]
00007871bd3d44e1  vmovaps xmm14, [rsp+0xD0]
00007871bd3d44ea  vmovaps xmm15, [rsp+0xE0]
00007871bd3d44f3  add rsp, 0xF0
00007871bd3d44fa  pop r11
00007871bd3d44fc  pop r10
00007871bd3d44fe  pop r9
00007871bd3d4500  pop r8
00007871bd3d4502  pop rsi
00007871bd3d4503  pop rdi
00007871bd3d4504  pop rdx
00007871bd3d4505  pop rcx
00007871bd3d4506  pop rax
00007871bd3d4507  add rsp, 0x08
00007871bd3d450b  jmp 0x00007871BD3D2A5C
00007871bd3d4510  call 0x00007871BD20E760
00007871bd3d4515  jmp 0x00007871BD3D2A69
00007871bd3d451a  sub rsp, 0x08
00007871bd3d451e  push rax
00007871bd3d451f  push rcx
00007871bd3d4520  push rdx
00007871bd3d4521  push rdi
00007871bd3d4522  push rsi
00007871bd3d4523  push r8
00007871bd3d4525  push r9
00007871bd3d4527  push r10
00007871bd3d4529  push r11
00007871bd3d452b  sub rsp, 0xF0
00007871bd3d4532  vmovaps [rsp], xmm0
00007871bd3d4537  vmovaps [rsp+0x10], xmm1
00007871bd3d453d  vmovaps [rsp+0x20], xmm2
00007871bd3d4543  vmovaps [rsp+0x30], xmm3
00007871bd3d4549  vmovaps [rsp+0x40], xmm4
00007871bd3d454f  vmovaps [rsp+0x50], xmm5
00007871bd3d4555  vmovaps [rsp+0x60], xmm6
00007871bd3d455b  vmovaps [rsp+0x70], xmm7
00007871bd3d4561  vmovaps [rsp+0x80], xmm8
00007871bd3d456a  vmovaps [rsp+0x90], xmm9
00007871bd3d4573  vmovaps [rsp+0xA0], xmm10
00007871bd3d457c  vmovaps [rsp+0xB0], xmm11
00007871bd3d4585  vmovaps [rsp+0xC0], xmm12
00007871bd3d458e  vmovaps [rsp+0xD0], xmm14
00007871bd3d4597  vmovaps [rsp+0xE0], xmm15
00007871bd3d45a0  sub rsp, 0x30
00007871bd3d45a4  movaps [rsp], xmm13
00007871bd3d45a9  movaps [rsp+0x10], xmm2
00007871bd3d45ae  movaps [rsp+0x20], xmm1
00007871bd3d45b3  lea rdi, [rsp]
00007871bd3d45b7  mov esi, 0x00
00007871bd3d45bc  mov rax, 0x5BA2FDD2A530
00007871bd3d45c6  call rax
00007871bd3d45c8  movaps xmm13, [rsp]
00007871bd3d45cd  add rsp, 0x30
00007871bd3d45d1  vmovaps xmm0, [rsp]
00007871bd3d45d6  vmovaps xmm1, [rsp+0x10]
00007871bd3d45dc  vmovaps xmm2, [rsp+0x20]
00007871bd3d45e2  vmovaps xmm3, [rsp+0x30]
00007871bd3d45e8  vmovaps xmm4, [rsp+0x40]
00007871bd3d45ee  vmovaps xmm5, [rsp+0x50]
00007871bd3d45f4  vmovaps xmm6, [rsp+0x60]
00007871bd3d45fa  vmovaps xmm7, [rsp+0x70]
00007871bd3d4600  vmovaps xmm8, [rsp+0x80]
00007871bd3d4609  vmovaps xmm9, [rsp+0x90]
00007871bd3d4612  vmovaps xmm10, [rsp+0xA0]
00007871bd3d461b  vmovaps xmm11, [rsp+0xB0]
00007871bd3d4624  vmovaps xmm12, [rsp+0xC0]
00007871bd3d462d  vmovaps xmm14, [rsp+0xD0]
00007871bd3d4636  vmovaps xmm15, [rsp+0xE0]
00007871bd3d463f  add rsp, 0xF0
00007871bd3d4646  pop r11
00007871bd3d4648  pop r10
00007871bd3d464a  pop r9
00007871bd3d464c  pop r8
00007871bd3d464e  pop rsi
00007871bd3d464f  pop rdi
00007871bd3d4650  pop rdx
00007871bd3d4651  pop rcx
00007871bd3d4652  pop rax
00007871bd3d4653  add rsp, 0x08
00007871bd3d4657  jmp 0x00007871BD3D2AA8
00007871bd3d465c  sub rsp, 0x08
00007871bd3d4660  push rax
00007871bd3d4661  push rcx
00007871bd3d4662  push rdx
00007871bd3d4663  push rdi
00007871bd3d4664  push rsi
00007871bd3d4665  push r8
00007871bd3d4667  push r9
00007871bd3d4669  push r10
00007871bd3d466b  push r11
00007871bd3d466d  sub rsp, 0xF0
00007871bd3d4674  vmovaps [rsp], xmm0
00007871bd3d4679  vmovaps [rsp+0x10], xmm2
00007871bd3d467f  vmovaps [rsp+0x20], xmm3
00007871bd3d4685  vmovaps [rsp+0x30], xmm4
00007871bd3d468b  vmovaps [rsp+0x40], xmm5
00007871bd3d4691  vmovaps [rsp+0x50], xmm6
00007871bd3d4697  vmovaps [rsp+0x60], xmm7
00007871bd3d469d  vmovaps [rsp+0x70], xmm8
00007871bd3d46a3  vmovaps [rsp+0x80], xmm9
00007871bd3d46ac  vmovaps [rsp+0x90], xmm10
00007871bd3d46b5  vmovaps [rsp+0xA0], xmm11
00007871bd3d46be  vmovaps [rsp+0xB0], xmm12
00007871bd3d46c7  vmovaps [rsp+0xC0], xmm13
00007871bd3d46d0  vmovaps [rsp+0xD0], xmm14
00007871bd3d46d9  vmovaps [rsp+0xE0], xmm15
00007871bd3d46e2  sub rsp, 0x30
00007871bd3d46e6  movaps [rsp], xmm1
00007871bd3d46ea  movaps [rsp+0x10], xmm14
00007871bd3d46f0  movaps [rsp+0x20], xmm15
00007871bd3d46f6  lea rdi, [rsp]
00007871bd3d46fa  mov esi, 0x00
00007871bd3d46ff  mov rax, 0x5BA2FDD2A530
00007871bd3d4709  call rax
00007871bd3d470b  movaps xmm1, [rsp]
00007871bd3d470f  add rsp, 0x30
00007871bd3d4713  vmovaps xmm0, [rsp]
00007871bd3d4718  vmovaps xmm2, [rsp+0x10]
00007871bd3d471e  vmovaps xmm3, [rsp+0x20]
00007871bd3d4724  vmovaps xmm4, [rsp+0x30]
00007871bd3d472a  vmovaps xmm5, [rsp+0x40]
00007871bd3d4730  vmovaps xmm6, [rsp+0x50]
00007871bd3d4736  vmovaps xmm7, [rsp+0x60]
00007871bd3d473c  vmovaps xmm8, [rsp+0x70]
00007871bd3d4742  vmovaps xmm9, [rsp+0x80]
00007871bd3d474b  vmovaps xmm10, [rsp+0x90]
00007871bd3d4754  vmovaps xmm11, [rsp+0xA0]
00007871bd3d475d  vmovaps xmm12, [rsp+0xB0]
00007871bd3d4766  vmovaps xmm13, [rsp+0xC0]
00007871bd3d476f  vmovaps xmm14, [rsp+0xD0]
00007871bd3d4778  vmovaps xmm15, [rsp+0xE0]
00007871bd3d4781  add rsp, 0xF0
00007871bd3d4788  pop r11
00007871bd3d478a  pop r10
00007871bd3d478c  pop r9
00007871bd3d478e  pop r8
00007871bd3d4790  pop rsi
00007871bd3d4791  pop rdi
00007871bd3d4792  pop rdx
00007871bd3d4793  pop rcx
00007871bd3d4794  pop rax
00007871bd3d4795  add rsp, 0x08
00007871bd3d4799  jmp 0x00007871BD3D2ACA
00007871bd3d479e  sub rsp, 0x08
00007871bd3d47a2  push rax
00007871bd3d47a3  push rcx
00007871bd3d47a4  push rdx
00007871bd3d47a5  push rdi
00007871bd3d47a6  push rsi
00007871bd3d47a7  push r8
00007871bd3d47a9  push r9
00007871bd3d47ab  push r10
00007871bd3d47ad  push r11
00007871bd3d47af  sub rsp, 0xF0
00007871bd3d47b6  vmovaps [rsp], xmm0
00007871bd3d47bb  vmovaps [rsp+0x10], xmm1
00007871bd3d47c1  vmovaps [rsp+0x20], xmm2
00007871bd3d47c7  vmovaps [rsp+0x30], xmm3
00007871bd3d47cd  vmovaps [rsp+0x40], xmm4
00007871bd3d47d3  vmovaps [rsp+0x50], xmm5
00007871bd3d47d9  vmovaps [rsp+0x60], xmm6
00007871bd3d47df  vmovaps [rsp+0x70], xmm7
00007871bd3d47e5  vmovaps [rsp+0x80], xmm8
00007871bd3d47ee  vmovaps [rsp+0x90], xmm9
00007871bd3d47f7  vmovaps [rsp+0xA0], xmm10
00007871bd3d4800  vmovaps [rsp+0xB0], xmm11
00007871bd3d4809  vmovaps [rsp+0xC0], xmm12
00007871bd3d4812  vmovaps [rsp+0xD0], xmm13
00007871bd3d481b  vmovaps [rsp+0xE0], xmm15
00007871bd3d4824  sub rsp, 0x30
00007871bd3d4828  movaps [rsp], xmm14
00007871bd3d482d  movaps [rsp+0x10], xmm2
00007871bd3d4832  movaps [rsp+0x20], xmm15
00007871bd3d4838  lea rdi, [rsp]
00007871bd3d483c  mov esi, 0x00
00007871bd3d4841  mov rax, 0x5BA2FDD2A530
00007871bd3d484b  call rax
00007871bd3d484d  movaps xmm14, [rsp]
00007871bd3d4852  add rsp, 0x30
00007871bd3d4856  vmovaps xmm0, [rsp]
00007871bd3d485b  vmovaps xmm1, [rsp+0x10]
00007871bd3d4861  vmovaps xmm2, [rsp+0x20]
00007871bd3d4867  vmovaps xmm3, [rsp+0x30]
00007871bd3d486d  vmovaps xmm4, [rsp+0x40]
00007871bd3d4873  vmovaps xmm5, [rsp+0x50]
00007871bd3d4879  vmovaps xmm6, [rsp+0x60]
00007871bd3d487f  vmovaps xmm7, [rsp+0x70]
00007871bd3d4885  vmovaps xmm8, [rsp+0x80]
00007871bd3d488e  vmovaps xmm9, [rsp+0x90]
00007871bd3d4897  vmovaps xmm10, [rsp+0xA0]
00007871bd3d48a0  vmovaps xmm11, [rsp+0xB0]
00007871bd3d48a9  vmovaps xmm12, [rsp+0xC0]
00007871bd3d48b2  vmovaps xmm13, [rsp+0xD0]
00007871bd3d48bb  vmovaps xmm15, [rsp+0xE0]
00007871bd3d48c4  add rsp, 0xF0
00007871bd3d48cb  pop r11
00007871bd3d48cd  pop r10
00007871bd3d48cf  pop r9
00007871bd3d48d1  pop r8
00007871bd3d48d3  pop rsi
00007871bd3d48d4  pop rdi
00007871bd3d48d5  pop rdx
00007871bd3d48d6  pop rcx
00007871bd3d48d7  pop rax
00007871bd3d48d8  add rsp, 0x08
00007871bd3d48dc  jmp 0x00007871BD3D2B05
00007871bd3d48e1  sub rsp, 0x08
00007871bd3d48e5  push rax
00007871bd3d48e6  push rcx
00007871bd3d48e7  push rdx
00007871bd3d48e8  push rdi
00007871bd3d48e9  push rsi
00007871bd3d48ea  push r8
00007871bd3d48ec  push r9
00007871bd3d48ee  push r10
00007871bd3d48f0  push r11
00007871bd3d48f2  sub rsp, 0xF0
00007871bd3d48f9  vmovaps [rsp], xmm0
00007871bd3d48fe  vmovaps [rsp+0x10], xmm1
00007871bd3d4904  vmovaps [rsp+0x20], xmm2
00007871bd3d490a  vmovaps [rsp+0x30], xmm3
00007871bd3d4910  vmovaps [rsp+0x40], xmm4
00007871bd3d4916  vmovaps [rsp+0x50], xmm5
00007871bd3d491c  vmovaps [rsp+0x60], xmm6
00007871bd3d4922  vmovaps [rsp+0x70], xmm7
00007871bd3d4928  vmovaps [rsp+0x80], xmm8
00007871bd3d4931  vmovaps [rsp+0x90], xmm9
00007871bd3d493a  vmovaps [rsp+0xA0], xmm10
00007871bd3d4943  vmovaps [rsp+0xB0], xmm11
00007871bd3d494c  vmovaps [rsp+0xC0], xmm12
00007871bd3d4955  vmovaps [rsp+0xD0], xmm13
00007871bd3d495e  vmovaps [rsp+0xE0], xmm14
00007871bd3d4967  sub rsp, 0x30
00007871bd3d496b  movaps [rsp], xmm15
00007871bd3d4970  movaps [rsp+0x10], xmm2
00007871bd3d4975  movaps [rsp+0x20], xmm1
00007871bd3d497a  lea rdi, [rsp]
00007871bd3d497e  mov esi, 0x00
00007871bd3d4983  mov rax, 0x5BA2FDD2A530
00007871bd3d498d  call rax
00007871bd3d498f  movaps xmm15, [rsp]
00007871bd3d4994  add rsp, 0x30
00007871bd3d4998  vmovaps xmm0, [rsp]
00007871bd3d499d  vmovaps xmm1, [rsp+0x10]
00007871bd3d49a3  vmovaps xmm2, [rsp+0x20]
00007871bd3d49a9  vmovaps xmm3, [rsp+0x30]
00007871bd3d49af  vmovaps xmm4, [rsp+0x40]
00007871bd3d49b5  vmovaps xmm5, [rsp+0x50]
00007871bd3d49bb  vmovaps xmm6, [rsp+0x60]
00007871bd3d49c1  vmovaps xmm7, [rsp+0x70]
00007871bd3d49c7  vmovaps xmm8, [rsp+0x80]
00007871bd3d49d0  vmovaps xmm9, [rsp+0x90]
00007871bd3d49d9  vmovaps xmm10, [rsp+0xA0]
00007871bd3d49e2  vmovaps xmm11, [rsp+0xB0]
00007871bd3d49eb  vmovaps xmm12, [rsp+0xC0]
00007871bd3d49f4  vmovaps xmm13, [rsp+0xD0]
00007871bd3d49fd  vmovaps xmm14, [rsp+0xE0]
00007871bd3d4a06  add rsp, 0xF0
00007871bd3d4a0d  pop r11
00007871bd3d4a0f  pop r10
00007871bd3d4a11  pop r9
00007871bd3d4a13  pop r8
00007871bd3d4a15  pop rsi
00007871bd3d4a16  pop rdi
00007871bd3d4a17  pop rdx
00007871bd3d4a18  pop rcx
00007871bd3d4a19  pop rax
00007871bd3d4a1a  add rsp, 0x08
00007871bd3d4a1e  jmp 0x00007871BD3D2B41
00007871bd3d4a23  call 0x00007871BD1FF430
00007871bd3d4a28  jmp 0x00007871BD3D2B4E
00007871bd3d4a2d  sub rsp, 0x08
00007871bd3d4a31  push rax
00007871bd3d4a32  push rcx
00007871bd3d4a33  push rdx
00007871bd3d4a34  push rdi
00007871bd3d4a35  push rsi
00007871bd3d4a36  push r8
00007871bd3d4a38  push r9
00007871bd3d4a3a  push r10
00007871bd3d4a3c  push r11
00007871bd3d4a3e  sub rsp, 0xF0
00007871bd3d4a45  vmovaps [rsp], xmm0
00007871bd3d4a4a  vmovaps [rsp+0x10], xmm1
00007871bd3d4a50  vmovaps [rsp+0x20], xmm3
00007871bd3d4a56  vmovaps [rsp+0x30], xmm4
00007871bd3d4a5c  vmovaps [rsp+0x40], xmm5
00007871bd3d4a62  vmovaps [rsp+0x50], xmm6
00007871bd3d4a68  vmovaps [rsp+0x60], xmm7
00007871bd3d4a6e  vmovaps [rsp+0x70], xmm8
00007871bd3d4a74  vmovaps [rsp+0x80], xmm9
00007871bd3d4a7d  vmovaps [rsp+0x90], xmm10
00007871bd3d4a86  vmovaps [rsp+0xA0], xmm11
00007871bd3d4a8f  vmovaps [rsp+0xB0], xmm12
00007871bd3d4a98  vmovaps [rsp+0xC0], xmm13
00007871bd3d4aa1  vmovaps [rsp+0xD0], xmm14
00007871bd3d4aaa  vmovaps [rsp+0xE0], xmm15
00007871bd3d4ab3  sub rsp, 0x30
00007871bd3d4ab7  movaps [rsp], xmm2
00007871bd3d4abb  movaps [rsp+0x10], xmm1
00007871bd3d4ac0  movaps [rsp+0x20], xmm14
00007871bd3d4ac6  lea rdi, [rsp]
00007871bd3d4aca  mov esi, 0x00
00007871bd3d4acf  mov rax, 0x5BA2FDD2A530
00007871bd3d4ad9  call rax
00007871bd3d4adb  movaps xmm2, [rsp]
00007871bd3d4adf  add rsp, 0x30
00007871bd3d4ae3  vmovaps xmm0, [rsp]
00007871bd3d4ae8  vmovaps xmm1, [rsp+0x10]
00007871bd3d4aee  vmovaps xmm3, [rsp+0x20]
00007871bd3d4af4  vmovaps xmm4, [rsp+0x30]
00007871bd3d4afa  vmovaps xmm5, [rsp+0x40]
00007871bd3d4b00  vmovaps xmm6, [rsp+0x50]
00007871bd3d4b06  vmovaps xmm7, [rsp+0x60]
00007871bd3d4b0c  vmovaps xmm8, [rsp+0x70]
00007871bd3d4b12  vmovaps xmm9, [rsp+0x80]
00007871bd3d4b1b  vmovaps xmm10, [rsp+0x90]
00007871bd3d4b24  vmovaps xmm11, [rsp+0xA0]
00007871bd3d4b2d  vmovaps xmm12, [rsp+0xB0]
00007871bd3d4b36  vmovaps xmm13, [rsp+0xC0]
00007871bd3d4b3f  vmovaps xmm14, [rsp+0xD0]
00007871bd3d4b48  vmovaps xmm15, [rsp+0xE0]
00007871bd3d4b51  add rsp, 0xF0
00007871bd3d4b58  pop r11
00007871bd3d4b5a  pop r10
00007871bd3d4b5c  pop r9
00007871bd3d4b5e  pop r8
00007871bd3d4b60  pop rsi
00007871bd3d4b61  pop rdi
00007871bd3d4b62  pop rdx
00007871bd3d4b63  pop rcx
00007871bd3d4b64  pop rax
00007871bd3d4b65  add rsp, 0x08
00007871bd3d4b69  jmp 0x00007871BD3D2B8B
00007871bd3d4b6e  sub rsp, 0x08
00007871bd3d4b72  push rax
00007871bd3d4b73  push rcx
00007871bd3d4b74  push rdx
00007871bd3d4b75  push rdi
00007871bd3d4b76  push rsi
00007871bd3d4b77  push r8
00007871bd3d4b79  push r9
00007871bd3d4b7b  push r10
00007871bd3d4b7d  push r11
00007871bd3d4b7f  sub rsp, 0xF0
00007871bd3d4b86  vmovaps [rsp], xmm0
00007871bd3d4b8b  vmovaps [rsp+0x10], xmm1
00007871bd3d4b91  vmovaps [rsp+0x20], xmm2
00007871bd3d4b97  vmovaps [rsp+0x30], xmm3
00007871bd3d4b9d  vmovaps [rsp+0x40], xmm4
00007871bd3d4ba3  vmovaps [rsp+0x50], xmm5
00007871bd3d4ba9  vmovaps [rsp+0x60], xmm6
00007871bd3d4baf  vmovaps [rsp+0x70], xmm7
00007871bd3d4bb5  vmovaps [rsp+0x80], xmm8
00007871bd3d4bbe  vmovaps [rsp+0x90], xmm9
00007871bd3d4bc7  vmovaps [rsp+0xA0], xmm10
00007871bd3d4bd0  vmovaps [rsp+0xB0], xmm11
00007871bd3d4bd9  vmovaps [rsp+0xC0], xmm12
00007871bd3d4be2  vmovaps [rsp+0xD0], xmm13
00007871bd3d4beb  vmovaps [rsp+0xE0], xmm14
00007871bd3d4bf4  sub rsp, 0x30
00007871bd3d4bf8  movaps [rsp], xmm15
00007871bd3d4bfd  movaps [rsp+0x10], xmm14
00007871bd3d4c03  movaps [rsp+0x20], xmm1
00007871bd3d4c08  lea rdi, [rsp]
00007871bd3d4c0c  mov esi, 0x00
00007871bd3d4c11  mov rax, 0x5BA2FDD2A530
00007871bd3d4c1b  call rax
00007871bd3d4c1d  movaps xmm15, [rsp]
00007871bd3d4c22  add rsp, 0x30
00007871bd3d4c26  vmovaps xmm0, [rsp]
00007871bd3d4c2b  vmovaps xmm1, [rsp+0x10]
00007871bd3d4c31  vmovaps xmm2, [rsp+0x20]
00007871bd3d4c37  vmovaps xmm3, [rsp+0x30]
00007871bd3d4c3d  vmovaps xmm4, [rsp+0x40]
00007871bd3d4c43  vmovaps xmm5, [rsp+0x50]
00007871bd3d4c49  vmovaps xmm6, [rsp+0x60]
00007871bd3d4c4f  vmovaps xmm7, [rsp+0x70]
00007871bd3d4c55  vmovaps xmm8, [rsp+0x80]
00007871bd3d4c5e  vmovaps xmm9, [rsp+0x90]
00007871bd3d4c67  vmovaps xmm10, [rsp+0xA0]
00007871bd3d4c70  vmovaps xmm11, [rsp+0xB0]
00007871bd3d4c79  vmovaps xmm12, [rsp+0xC0]
00007871bd3d4c82  vmovaps xmm13, [rsp+0xD0]
00007871bd3d4c8b  vmovaps xmm14, [rsp+0xE0]
00007871bd3d4c94  add rsp, 0xF0
00007871bd3d4c9b  pop r11
00007871bd3d4c9d  pop r10
00007871bd3d4c9f  pop r9
00007871bd3d4ca1  pop r8
00007871bd3d4ca3  pop rsi
00007871bd3d4ca4  pop rdi
00007871bd3d4ca5  pop rdx
00007871bd3d4ca6  pop rcx
00007871bd3d4ca7  pop rax
00007871bd3d4ca8  add rsp, 0x08
00007871bd3d4cac  jmp 0x00007871BD3D2C05
00007871bd3d4cb1  call 0x00007871BD1FF430
00007871bd3d4cb6  jmp 0x00007871BD3D2C12
00007871bd3d4cbb  sub rsp, 0x08
00007871bd3d4cbf  push rax
00007871bd3d4cc0  push rcx
00007871bd3d4cc1  push rdx
00007871bd3d4cc2  push rdi
00007871bd3d4cc3  push rsi
00007871bd3d4cc4  push r8
00007871bd3d4cc6  push r9
00007871bd3d4cc8  push r10
00007871bd3d4cca  push r11
00007871bd3d4ccc  sub rsp, 0xF0
00007871bd3d4cd3  vmovaps [rsp], xmm0
00007871bd3d4cd8  vmovaps [rsp+0x10], xmm1
00007871bd3d4cde  vmovaps [rsp+0x20], xmm2
00007871bd3d4ce4  vmovaps [rsp+0x30], xmm3
00007871bd3d4cea  vmovaps [rsp+0x40], xmm4
00007871bd3d4cf0  vmovaps [rsp+0x50], xmm5
00007871bd3d4cf6  vmovaps [rsp+0x60], xmm6
00007871bd3d4cfc  vmovaps [rsp+0x70], xmm7
00007871bd3d4d02  vmovaps [rsp+0x80], xmm8
00007871bd3d4d0b  vmovaps [rsp+0x90], xmm9
00007871bd3d4d14  vmovaps [rsp+0xA0], xmm10
00007871bd3d4d1d  vmovaps [rsp+0xB0], xmm11
00007871bd3d4d26  vmovaps [rsp+0xC0], xmm12
00007871bd3d4d2f  vmovaps [rsp+0xD0], xmm14
00007871bd3d4d38  vmovaps [rsp+0xE0], xmm15
00007871bd3d4d41  sub rsp, 0x30
00007871bd3d4d45  movaps [rsp], xmm13
00007871bd3d4d4a  movaps [rsp+0x10], xmm1
00007871bd3d4d4f  movaps [rsp+0x20], xmm15
00007871bd3d4d55  lea rdi, [rsp]
00007871bd3d4d59  mov esi, 0x00
00007871bd3d4d5e  mov rax, 0x5BA2FDD2A530
00007871bd3d4d68  call rax
00007871bd3d4d6a  movaps xmm13, [rsp]
00007871bd3d4d6f  add rsp, 0x30
00007871bd3d4d73  vmovaps xmm0, [rsp]
00007871bd3d4d78  vmovaps xmm1, [rsp+0x10]
00007871bd3d4d7e  vmovaps xmm2, [rsp+0x20]
00007871bd3d4d84  vmovaps xmm3, [rsp+0x30]
00007871bd3d4d8a  vmovaps xmm4, [rsp+0x40]
00007871bd3d4d90  vmovaps xmm5, [rsp+0x50]
00007871bd3d4d96  vmovaps xmm6, [rsp+0x60]
00007871bd3d4d9c  vmovaps xmm7, [rsp+0x70]
00007871bd3d4da2  vmovaps xmm8, [rsp+0x80]
00007871bd3d4dab  vmovaps xmm9, [rsp+0x90]
00007871bd3d4db4  vmovaps xmm10, [rsp+0xA0]
00007871bd3d4dbd  vmovaps xmm11, [rsp+0xB0]
00007871bd3d4dc6  vmovaps xmm12, [rsp+0xC0]
00007871bd3d4dcf  vmovaps xmm14, [rsp+0xD0]
00007871bd3d4dd8  vmovaps xmm15, [rsp+0xE0]
00007871bd3d4de1  add rsp, 0xF0
00007871bd3d4de8  pop r11
00007871bd3d4dea  pop r10
00007871bd3d4dec  pop r9
00007871bd3d4dee  pop r8
00007871bd3d4df0  pop rsi
00007871bd3d4df1  pop rdi
00007871bd3d4df2  pop rdx
00007871bd3d4df3  pop rcx
00007871bd3d4df4  pop rax
00007871bd3d4df5  add rsp, 0x08
00007871bd3d4df9  jmp 0x00007871BD3D2CD6
00007871bd3d4dfe  sub rsp, 0x08
00007871bd3d4e02  push rax
00007871bd3d4e03  push rcx
00007871bd3d4e04  push rdx
00007871bd3d4e05  push rdi
00007871bd3d4e06  push rsi
00007871bd3d4e07  push r8
00007871bd3d4e09  push r9
00007871bd3d4e0b  push r10
00007871bd3d4e0d  push r11
00007871bd3d4e0f  sub rsp, 0xF0
00007871bd3d4e16  vmovaps [rsp], xmm0
00007871bd3d4e1b  vmovaps [rsp+0x10], xmm1
00007871bd3d4e21  vmovaps [rsp+0x20], xmm2
00007871bd3d4e27  vmovaps [rsp+0x30], xmm3
00007871bd3d4e2d  vmovaps [rsp+0x40], xmm4
00007871bd3d4e33  vmovaps [rsp+0x50], xmm5
00007871bd3d4e39  vmovaps [rsp+0x60], xmm6
00007871bd3d4e3f  vmovaps [rsp+0x70], xmm7
00007871bd3d4e45  vmovaps [rsp+0x80], xmm8
00007871bd3d4e4e  vmovaps [rsp+0x90], xmm9
00007871bd3d4e57  vmovaps [rsp+0xA0], xmm10
00007871bd3d4e60  vmovaps [rsp+0xB0], xmm11
00007871bd3d4e69  vmovaps [rsp+0xC0], xmm12
00007871bd3d4e72  vmovaps [rsp+0xD0], xmm13
00007871bd3d4e7b  vmovaps [rsp+0xE0], xmm14
00007871bd3d4e84  sub rsp, 0x30
00007871bd3d4e88  movaps [rsp], xmm15
00007871bd3d4e8d  movaps [rsp+0x10], xmm14
00007871bd3d4e93  movaps [rsp+0x20], xmm1
00007871bd3d4e98  lea rdi, [rsp]
00007871bd3d4e9c  mov esi, 0x00
00007871bd3d4ea1  mov rax, 0x5BA2FDD2A530
00007871bd3d4eab  call rax
00007871bd3d4ead  movaps xmm15, [rsp]
00007871bd3d4eb2  add rsp, 0x30
00007871bd3d4eb6  vmovaps xmm0, [rsp]
00007871bd3d4ebb  vmovaps xmm1, [rsp+0x10]
00007871bd3d4ec1  vmovaps xmm2, [rsp+0x20]
00007871bd3d4ec7  vmovaps xmm3, [rsp+0x30]
00007871bd3d4ecd  vmovaps xmm4, [rsp+0x40]
00007871bd3d4ed3  vmovaps xmm5, [rsp+0x50]
00007871bd3d4ed9  vmovaps xmm6, [rsp+0x60]
00007871bd3d4edf  vmovaps xmm7, [rsp+0x70]
00007871bd3d4ee5  vmovaps xmm8, [rsp+0x80]
00007871bd3d4eee  vmovaps xmm9, [rsp+0x90]
00007871bd3d4ef7  vmovaps xmm10, [rsp+0xA0]
00007871bd3d4f00  vmovaps xmm11, [rsp+0xB0]
00007871bd3d4f09  vmovaps xmm12, [rsp+0xC0]
00007871bd3d4f12  vmovaps xmm13, [rsp+0xD0]
00007871bd3d4f1b  vmovaps xmm14, [rsp+0xE0]
00007871bd3d4f24  add rsp, 0xF0
00007871bd3d4f2b  pop r11
00007871bd3d4f2d  pop r10
00007871bd3d4f2f  pop r9
00007871bd3d4f31  pop r8
00007871bd3d4f33  pop rsi
00007871bd3d4f34  pop rdi
00007871bd3d4f35  pop rdx
00007871bd3d4f36  pop rcx
00007871bd3d4f37  pop rax
00007871bd3d4f38  add rsp, 0x08
00007871bd3d4f3c  jmp 0x00007871BD3D2D12
00007871bd3d4f41  call 0x00007871BD1FF430
00007871bd3d4f46  jmp 0x00007871BD3D2D1F
00007871bd3d4f4b  sub rsp, 0x08
00007871bd3d4f4f  push rax
00007871bd3d4f50  push rcx
00007871bd3d4f51  push rdx
00007871bd3d4f52  push rdi
00007871bd3d4f53  push rsi
00007871bd3d4f54  push r8
00007871bd3d4f56  push r9
00007871bd3d4f58  push r10
00007871bd3d4f5a  push r11
00007871bd3d4f5c  sub rsp, 0xF0
00007871bd3d4f63  vmovaps [rsp], xmm0
00007871bd3d4f68  vmovaps [rsp+0x10], xmm1
00007871bd3d4f6e  vmovaps [rsp+0x20], xmm2
00007871bd3d4f74  vmovaps [rsp+0x30], xmm3
00007871bd3d4f7a  vmovaps [rsp+0x40], xmm4
00007871bd3d4f80  vmovaps [rsp+0x50], xmm5
00007871bd3d4f86  vmovaps [rsp+0x60], xmm6
00007871bd3d4f8c  vmovaps [rsp+0x70], xmm7
00007871bd3d4f92  vmovaps [rsp+0x80], xmm8
00007871bd3d4f9b  vmovaps [rsp+0x90], xmm9
00007871bd3d4fa4  vmovaps [rsp+0xA0], xmm10
00007871bd3d4fad  vmovaps [rsp+0xB0], xmm11
00007871bd3d4fb6  vmovaps [rsp+0xC0], xmm12
00007871bd3d4fbf  vmovaps [rsp+0xD0], xmm13
00007871bd3d4fc8  vmovaps [rsp+0xE0], xmm15
00007871bd3d4fd1  sub rsp, 0x30
00007871bd3d4fd5  movaps [rsp], xmm14
00007871bd3d4fda  movaps [rsp+0x10], xmm13
00007871bd3d4fe0  movaps [rsp+0x20], xmm2
00007871bd3d4fe5  lea rdi, [rsp]
00007871bd3d4fe9  mov esi, 0x00
00007871bd3d4fee  mov rax, 0x5BA2FDD2A530
00007871bd3d4ff8  call rax
00007871bd3d4ffa  movaps xmm14, [rsp]
00007871bd3d4fff  add rsp, 0x30
00007871bd3d5003  vmovaps xmm0, [rsp]
00007871bd3d5008  vmovaps xmm1, [rsp+0x10]
00007871bd3d500e  vmovaps xmm2, [rsp+0x20]
00007871bd3d5014  vmovaps xmm3, [rsp+0x30]
00007871bd3d501a  vmovaps xmm4, [rsp+0x40]
00007871bd3d5020  vmovaps xmm5, [rsp+0x50]
00007871bd3d5026  vmovaps xmm6, [rsp+0x60]
00007871bd3d502c  vmovaps xmm7, [rsp+0x70]
00007871bd3d5032  vmovaps xmm8, [rsp+0x80]
00007871bd3d503b  vmovaps xmm9, [rsp+0x90]
00007871bd3d5044  vmovaps xmm10, [rsp+0xA0]
00007871bd3d504d  vmovaps xmm11, [rsp+0xB0]
00007871bd3d5056  vmovaps xmm12, [rsp+0xC0]
00007871bd3d505f  vmovaps xmm13, [rsp+0xD0]
00007871bd3d5068  vmovaps xmm15, [rsp+0xE0]
00007871bd3d5071  add rsp, 0xF0
00007871bd3d5078  pop r11
00007871bd3d507a  pop r10
00007871bd3d507c  pop r9
00007871bd3d507e  pop r8
00007871bd3d5080  pop rsi
00007871bd3d5081  pop rdi
00007871bd3d5082  pop rdx
00007871bd3d5083  pop rcx
00007871bd3d5084  pop rax
00007871bd3d5085  add rsp, 0x08
00007871bd3d5089  jmp 0x00007871BD3D2D4B
00007871bd3d508e  sub rsp, 0x08
00007871bd3d5092  push rax
00007871bd3d5093  push rcx
00007871bd3d5094  push rdx
00007871bd3d5095  push rdi
00007871bd3d5096  push rsi
00007871bd3d5097  push r8
00007871bd3d5099  push r9
00007871bd3d509b  push r10
00007871bd3d509d  push r11
00007871bd3d509f  sub rsp, 0xF0
00007871bd3d50a6  vmovaps [rsp], xmm0
00007871bd3d50ab  vmovaps [rsp+0x10], xmm2
00007871bd3d50b1  vmovaps [rsp+0x20], xmm3
00007871bd3d50b7  vmovaps [rsp+0x30], xmm4
00007871bd3d50bd  vmovaps [rsp+0x40], xmm5
00007871bd3d50c3  vmovaps [rsp+0x50], xmm6
00007871bd3d50c9  vmovaps [rsp+0x60], xmm7
00007871bd3d50cf  vmovaps [rsp+0x70], xmm8
00007871bd3d50d5  vmovaps [rsp+0x80], xmm9
00007871bd3d50de  vmovaps [rsp+0x90], xmm10
00007871bd3d50e7  vmovaps [rsp+0xA0], xmm11
00007871bd3d50f0  vmovaps [rsp+0xB0], xmm12
00007871bd3d50f9  vmovaps [rsp+0xC0], xmm13
00007871bd3d5102  vmovaps [rsp+0xD0], xmm14
00007871bd3d510b  vmovaps [rsp+0xE0], xmm15
00007871bd3d5114  sub rsp, 0x30
00007871bd3d5118  movaps [rsp], xmm1
00007871bd3d511c  movaps [rsp+0x10], xmm13
00007871bd3d5122  movaps [rsp+0x20], xmm2
00007871bd3d5127  lea rdi, [rsp]
00007871bd3d512b  mov esi, 0x00
00007871bd3d5130  mov rax, 0x5BA2FDD2A530
00007871bd3d513a  call rax
00007871bd3d513c  movaps xmm1, [rsp]
00007871bd3d5140  add rsp, 0x30
00007871bd3d5144  vmovaps xmm0, [rsp]
00007871bd3d5149  vmovaps xmm2, [rsp+0x10]
00007871bd3d514f  vmovaps xmm3, [rsp+0x20]
00007871bd3d5155  vmovaps xmm4, [rsp+0x30]
00007871bd3d515b  vmovaps xmm5, [rsp+0x40]
00007871bd3d5161  vmovaps xmm6, [rsp+0x50]
00007871bd3d5167  vmovaps xmm7, [rsp+0x60]
00007871bd3d516d  vmovaps xmm8, [rsp+0x70]
00007871bd3d5173  vmovaps xmm9, [rsp+0x80]
00007871bd3d517c  vmovaps xmm10, [rsp+0x90]
00007871bd3d5185  vmovaps xmm11, [rsp+0xA0]
00007871bd3d518e  vmovaps xmm12, [rsp+0xB0]
00007871bd3d5197  vmovaps xmm13, [rsp+0xC0]
00007871bd3d51a0  vmovaps xmm14, [rsp+0xD0]
00007871bd3d51a9  vmovaps xmm15, [rsp+0xE0]
00007871bd3d51b2  add rsp, 0xF0
00007871bd3d51b9  pop r11
00007871bd3d51bb  pop r10
00007871bd3d51bd  pop r9
00007871bd3d51bf  pop r8
00007871bd3d51c1  pop rsi
00007871bd3d51c2  pop rdi
00007871bd3d51c3  pop rdx
00007871bd3d51c4  pop rcx
00007871bd3d51c5  pop rax
00007871bd3d51c6  add rsp, 0x08
00007871bd3d51ca  jmp 0x00007871BD3D2D79
00007871bd3d51cf  sub rsp, 0x08
00007871bd3d51d3  push rax
00007871bd3d51d4  push rcx
00007871bd3d51d5  push rdx
00007871bd3d51d6  push rdi
00007871bd3d51d7  push rsi
00007871bd3d51d8  push r8
00007871bd3d51da  push r9
00007871bd3d51dc  push r10
00007871bd3d51de  push r11
00007871bd3d51e0  sub rsp, 0xF0
00007871bd3d51e7  vmovaps [rsp], xmm0
00007871bd3d51ec  vmovaps [rsp+0x10], xmm1
00007871bd3d51f2  vmovaps [rsp+0x20], xmm3
00007871bd3d51f8  vmovaps [rsp+0x30], xmm4
00007871bd3d51fe  vmovaps [rsp+0x40], xmm5
00007871bd3d5204  vmovaps [rsp+0x50], xmm6
00007871bd3d520a  vmovaps [rsp+0x60], xmm7
00007871bd3d5210  vmovaps [rsp+0x70], xmm8
00007871bd3d5216  vmovaps [rsp+0x80], xmm9
00007871bd3d521f  vmovaps [rsp+0x90], xmm10
00007871bd3d5228  vmovaps [rsp+0xA0], xmm11
00007871bd3d5231  vmovaps [rsp+0xB0], xmm12
00007871bd3d523a  vmovaps [rsp+0xC0], xmm13
00007871bd3d5243  vmovaps [rsp+0xD0], xmm14
00007871bd3d524c  vmovaps [rsp+0xE0], xmm15
00007871bd3d5255  sub rsp, 0x30
00007871bd3d5259  movaps [rsp], xmm2
00007871bd3d525d  movaps [rsp+0x10], xmm1
00007871bd3d5262  movaps [rsp+0x20], xmm13
00007871bd3d5268  lea rdi, [rsp]
00007871bd3d526c  mov esi, 0x00
00007871bd3d5271  mov rax, 0x5BA2FDD2A530
00007871bd3d527b  call rax
00007871bd3d527d  movaps xmm2, [rsp]
00007871bd3d5281  add rsp, 0x30
00007871bd3d5285  vmovaps xmm0, [rsp]
00007871bd3d528a  vmovaps xmm1, [rsp+0x10]
00007871bd3d5290  vmovaps xmm3, [rsp+0x20]
00007871bd3d5296  vmovaps xmm4, [rsp+0x30]
00007871bd3d529c  vmovaps xmm5, [rsp+0x40]
00007871bd3d52a2  vmovaps xmm6, [rsp+0x50]
00007871bd3d52a8  vmovaps xmm7, [rsp+0x60]
00007871bd3d52ae  vmovaps xmm8, [rsp+0x70]
00007871bd3d52b4  vmovaps xmm9, [rsp+0x80]
00007871bd3d52bd  vmovaps xmm10, [rsp+0x90]
00007871bd3d52c6  vmovaps xmm11, [rsp+0xA0]
00007871bd3d52cf  vmovaps xmm12, [rsp+0xB0]
00007871bd3d52d8  vmovaps xmm13, [rsp+0xC0]
00007871bd3d52e1  vmovaps xmm14, [rsp+0xD0]
00007871bd3d52ea  vmovaps xmm15, [rsp+0xE0]
00007871bd3d52f3  add rsp, 0xF0
00007871bd3d52fa  pop r11
00007871bd3d52fc  pop r10
00007871bd3d52fe  pop r9
00007871bd3d5300  pop r8
00007871bd3d5302  pop rsi
00007871bd3d5303  pop rdi
00007871bd3d5304  pop rdx
00007871bd3d5305  pop rcx
00007871bd3d5306  pop rax
00007871bd3d5307  add rsp, 0x08
00007871bd3d530b  jmp 0x00007871BD3D2DD2
00007871bd3d5310  call 0x00007871BD1FF430
00007871bd3d5315  jmp 0x00007871BD3D2DDF
00007871bd3d531a  sub rsp, 0x08
00007871bd3d531e  push rax
00007871bd3d531f  push rcx
00007871bd3d5320  push rdx
00007871bd3d5321  push rdi
00007871bd3d5322  push rsi
00007871bd3d5323  push r8
00007871bd3d5325  push r9
00007871bd3d5327  push r10
00007871bd3d5329  push r11
00007871bd3d532b  sub rsp, 0xF0
00007871bd3d5332  vmovaps [rsp], xmm0
00007871bd3d5337  vmovaps [rsp+0x10], xmm1
00007871bd3d533d  vmovaps [rsp+0x20], xmm2
00007871bd3d5343  vmovaps [rsp+0x30], xmm3
00007871bd3d5349  vmovaps [rsp+0x40], xmm4
00007871bd3d534f  vmovaps [rsp+0x50], xmm5
00007871bd3d5355  vmovaps [rsp+0x60], xmm6
00007871bd3d535b  vmovaps [rsp+0x70], xmm7
00007871bd3d5361  vmovaps [rsp+0x80], xmm8
00007871bd3d536a  vmovaps [rsp+0x90], xmm9
00007871bd3d5373  vmovaps [rsp+0xA0], xmm10
00007871bd3d537c  vmovaps [rsp+0xB0], xmm11
00007871bd3d5385  vmovaps [rsp+0xC0], xmm12
00007871bd3d538e  vmovaps [rsp+0xD0], xmm13
00007871bd3d5397  vmovaps [rsp+0xE0], xmm14
00007871bd3d53a0  sub rsp, 0x30
00007871bd3d53a4  movaps [rsp], xmm15
00007871bd3d53a9  movaps [rsp+0x10], xmm13
00007871bd3d53af  movaps [rsp+0x20], xmm1
00007871bd3d53b4  lea rdi, [rsp]
00007871bd3d53b8  mov esi, 0x00
00007871bd3d53bd  mov rax, 0x5BA2FDD2A530
00007871bd3d53c7  call rax
00007871bd3d53c9  movaps xmm15, [rsp]
00007871bd3d53ce  add rsp, 0x30
00007871bd3d53d2  vmovaps xmm0, [rsp]
00007871bd3d53d7  vmovaps xmm1, [rsp+0x10]
00007871bd3d53dd  vmovaps xmm2, [rsp+0x20]
00007871bd3d53e3  vmovaps xmm3, [rsp+0x30]
00007871bd3d53e9  vmovaps xmm4, [rsp+0x40]
00007871bd3d53ef  vmovaps xmm5, [rsp+0x50]
00007871bd3d53f5  vmovaps xmm6, [rsp+0x60]
00007871bd3d53fb  vmovaps xmm7, [rsp+0x70]
00007871bd3d5401  vmovaps xmm8, [rsp+0x80]
00007871bd3d540a  vmovaps xmm9, [rsp+0x90]
00007871bd3d5413  vmovaps xmm10, [rsp+0xA0]
00007871bd3d541c  vmovaps xmm11, [rsp+0xB0]
00007871bd3d5425  vmovaps xmm12, [rsp+0xC0]
00007871bd3d542e  vmovaps xmm13, [rsp+0xD0]
00007871bd3d5437  vmovaps xmm14, [rsp+0xE0]
00007871bd3d5440  add rsp, 0xF0
00007871bd3d5447  pop r11
00007871bd3d5449  pop r10
00007871bd3d544b  pop r9
00007871bd3d544d  pop r8
00007871bd3d544f  pop rsi
00007871bd3d5450  pop rdi
00007871bd3d5451  pop rdx
00007871bd3d5452  pop rcx
00007871bd3d5453  pop rax
00007871bd3d5454  add rsp, 0x08
00007871bd3d5458  jmp 0x00007871BD3D2E1E
00007871bd3d545d  sub rsp, 0x08
00007871bd3d5461  push rax
00007871bd3d5462  push rcx
00007871bd3d5463  push rdx
00007871bd3d5464  push rdi
00007871bd3d5465  push rsi
00007871bd3d5466  push r8
00007871bd3d5468  push r9
00007871bd3d546a  push r10
00007871bd3d546c  push r11
00007871bd3d546e  sub rsp, 0xF0
00007871bd3d5475  vmovaps [rsp], xmm0
00007871bd3d547a  vmovaps [rsp+0x10], xmm1
00007871bd3d5480  vmovaps [rsp+0x20], xmm2
00007871bd3d5486  vmovaps [rsp+0x30], xmm3
00007871bd3d548c  vmovaps [rsp+0x40], xmm4
00007871bd3d5492  vmovaps [rsp+0x50], xmm5
00007871bd3d5498  vmovaps [rsp+0x60], xmm6
00007871bd3d549e  vmovaps [rsp+0x70], xmm7
00007871bd3d54a4  vmovaps [rsp+0x80], xmm8
00007871bd3d54ad  vmovaps [rsp+0x90], xmm9
00007871bd3d54b6  vmovaps [rsp+0xA0], xmm10
00007871bd3d54bf  vmovaps [rsp+0xB0], xmm11
00007871bd3d54c8  vmovaps [rsp+0xC0], xmm12
00007871bd3d54d1  vmovaps [rsp+0xD0], xmm13
00007871bd3d54da  vmovaps [rsp+0xE0], xmm15
00007871bd3d54e3  sub rsp, 0x30
00007871bd3d54e7  movaps [rsp], xmm14
00007871bd3d54ec  movaps [rsp+0x10], xmm11
00007871bd3d54f2  movaps [rsp+0x20], xmm1
00007871bd3d54f7  lea rdi, [rsp]
00007871bd3d54fb  mov esi, 0x00
00007871bd3d5500  mov rax, 0x5BA2FDD2A530
00007871bd3d550a  call rax
00007871bd3d550c  movaps xmm14, [rsp]
00007871bd3d5511  add rsp, 0x30
00007871bd3d5515  vmovaps xmm0, [rsp]
00007871bd3d551a  vmovaps xmm1, [rsp+0x10]
00007871bd3d5520  vmovaps xmm2, [rsp+0x20]
00007871bd3d5526  vmovaps xmm3, [rsp+0x30]
00007871bd3d552c  vmovaps xmm4, [rsp+0x40]
00007871bd3d5532  vmovaps xmm5, [rsp+0x50]
00007871bd3d5538  vmovaps xmm6, [rsp+0x60]
00007871bd3d553e  vmovaps xmm7, [rsp+0x70]
00007871bd3d5544  vmovaps xmm8, [rsp+0x80]
00007871bd3d554d  vmovaps xmm9, [rsp+0x90]
00007871bd3d5556  vmovaps xmm10, [rsp+0xA0]
00007871bd3d555f  vmovaps xmm11, [rsp+0xB0]
00007871bd3d5568  vmovaps xmm12, [rsp+0xC0]
00007871bd3d5571  vmovaps xmm13, [rsp+0xD0]
00007871bd3d557a  vmovaps xmm15, [rsp+0xE0]
00007871bd3d5583  add rsp, 0xF0
00007871bd3d558a  pop r11
00007871bd3d558c  pop r10
00007871bd3d558e  pop r9
00007871bd3d5590  pop r8
00007871bd3d5592  pop rsi
00007871bd3d5593  pop rdi
00007871bd3d5594  pop rdx
00007871bd3d5595  pop rcx
00007871bd3d5596  pop rax
00007871bd3d5597  add rsp, 0x08
00007871bd3d559b  jmp 0x00007871BD3D2E48
00007871bd3d55a0  sub rsp, 0x08
00007871bd3d55a4  push rax
00007871bd3d55a5  push rcx
00007871bd3d55a6  push rdx
00007871bd3d55a7  push rdi
00007871bd3d55a8  push rsi
00007871bd3d55a9  push r8
00007871bd3d55ab  push r9
00007871bd3d55ad  push r10
00007871bd3d55af  push r11
00007871bd3d55b1  sub rsp, 0xF0
00007871bd3d55b8  vmovaps [rsp], xmm0
00007871bd3d55bd  vmovaps [rsp+0x10], xmm1
00007871bd3d55c3  vmovaps [rsp+0x20], xmm2
00007871bd3d55c9  vmovaps [rsp+0x30], xmm3
00007871bd3d55cf  vmovaps [rsp+0x40], xmm4
00007871bd3d55d5  vmovaps [rsp+0x50], xmm5
00007871bd3d55db  vmovaps [rsp+0x60], xmm6
00007871bd3d55e1  vmovaps [rsp+0x70], xmm7
00007871bd3d55e7  vmovaps [rsp+0x80], xmm8
00007871bd3d55f0  vmovaps [rsp+0x90], xmm9
00007871bd3d55f9  vmovaps [rsp+0xA0], xmm10
00007871bd3d5602  vmovaps [rsp+0xB0], xmm11
00007871bd3d560b  vmovaps [rsp+0xC0], xmm12
00007871bd3d5614  vmovaps [rsp+0xD0], xmm14
00007871bd3d561d  vmovaps [rsp+0xE0], xmm15
00007871bd3d5626  sub rsp, 0x30
00007871bd3d562a  movaps [rsp], xmm13
00007871bd3d562f  movaps [rsp+0x10], xmm11
00007871bd3d5635  movaps [rsp+0x20], xmm1
00007871bd3d563a  lea rdi, [rsp]
00007871bd3d563e  mov esi, 0x00
00007871bd3d5643  mov rax, 0x5BA2FDD2A530
00007871bd3d564d  call rax
00007871bd3d564f  movaps xmm13, [rsp]
00007871bd3d5654  add rsp, 0x30
00007871bd3d5658  vmovaps xmm0, [rsp]
00007871bd3d565d  vmovaps xmm1, [rsp+0x10]
00007871bd3d5663  vmovaps xmm2, [rsp+0x20]
00007871bd3d5669  vmovaps xmm3, [rsp+0x30]
00007871bd3d566f  vmovaps xmm4, [rsp+0x40]
00007871bd3d5675  vmovaps xmm5, [rsp+0x50]
00007871bd3d567b  vmovaps xmm6, [rsp+0x60]
00007871bd3d5681  vmovaps xmm7, [rsp+0x70]
00007871bd3d5687  vmovaps xmm8, [rsp+0x80]
00007871bd3d5690  vmovaps xmm9, [rsp+0x90]
00007871bd3d5699  vmovaps xmm10, [rsp+0xA0]
00007871bd3d56a2  vmovaps xmm11, [rsp+0xB0]
00007871bd3d56ab  vmovaps xmm12, [rsp+0xC0]
00007871bd3d56b4  vmovaps xmm14, [rsp+0xD0]
00007871bd3d56bd  vmovaps xmm15, [rsp+0xE0]
00007871bd3d56c6  add rsp, 0xF0
00007871bd3d56cd  pop r11
00007871bd3d56cf  pop r10
00007871bd3d56d1  pop r9
00007871bd3d56d3  pop r8
00007871bd3d56d5  pop rsi
00007871bd3d56d6  pop rdi
00007871bd3d56d7  pop rdx
00007871bd3d56d8  pop rcx
00007871bd3d56d9  pop rax
00007871bd3d56da  add rsp, 0x08
00007871bd3d56de  jmp 0x00007871BD3D2E9D
00007871bd3d56e3  call 0x00007871BD1FF430
00007871bd3d56e8  jmp 0x00007871BD3D2EAA
00007871bd3d56ed  sub rsp, 0x08
00007871bd3d56f1  push rax
00007871bd3d56f2  push rcx
00007871bd3d56f3  push rdx
00007871bd3d56f4  push rdi
00007871bd3d56f5  push rsi
00007871bd3d56f6  push r8
00007871bd3d56f8  push r9
00007871bd3d56fa  push r10
00007871bd3d56fc  push r11
00007871bd3d56fe  sub rsp, 0xF0
00007871bd3d5705  vmovaps [rsp], xmm0
00007871bd3d570a  vmovaps [rsp+0x10], xmm1
00007871bd3d5710  vmovaps [rsp+0x20], xmm2
00007871bd3d5716  vmovaps [rsp+0x30], xmm3
00007871bd3d571c  vmovaps [rsp+0x40], xmm4
00007871bd3d5722  vmovaps [rsp+0x50], xmm5
00007871bd3d5728  vmovaps [rsp+0x60], xmm6
00007871bd3d572e  vmovaps [rsp+0x70], xmm7
00007871bd3d5734  vmovaps [rsp+0x80], xmm8
00007871bd3d573d  vmovaps [rsp+0x90], xmm9
00007871bd3d5746  vmovaps [rsp+0xA0], xmm10
00007871bd3d574f  vmovaps [rsp+0xB0], xmm11
00007871bd3d5758  vmovaps [rsp+0xC0], xmm12
00007871bd3d5761  vmovaps [rsp+0xD0], xmm13
00007871bd3d576a  vmovaps [rsp+0xE0], xmm14
00007871bd3d5773  sub rsp, 0x30
00007871bd3d5777  movaps [rsp], xmm15
00007871bd3d577c  movaps [rsp+0x10], xmm11
00007871bd3d5782  movaps [rsp+0x20], xmm1
00007871bd3d5787  lea rdi, [rsp]
00007871bd3d578b  mov esi, 0x00
00007871bd3d5790  mov rax, 0x5BA2FDD2A530
00007871bd3d579a  call rax
00007871bd3d579c  movaps xmm15, [rsp]
00007871bd3d57a1  add rsp, 0x30
00007871bd3d57a5  vmovaps xmm0, [rsp]
00007871bd3d57aa  vmovaps xmm1, [rsp+0x10]
00007871bd3d57b0  vmovaps xmm2, [rsp+0x20]
00007871bd3d57b6  vmovaps xmm3, [rsp+0x30]
00007871bd3d57bc  vmovaps xmm4, [rsp+0x40]
00007871bd3d57c2  vmovaps xmm5, [rsp+0x50]
00007871bd3d57c8  vmovaps xmm6, [rsp+0x60]
00007871bd3d57ce  vmovaps xmm7, [rsp+0x70]
00007871bd3d57d4  vmovaps xmm8, [rsp+0x80]
00007871bd3d57dd  vmovaps xmm9, [rsp+0x90]
00007871bd3d57e6  vmovaps xmm10, [rsp+0xA0]
00007871bd3d57ef  vmovaps xmm11, [rsp+0xB0]
00007871bd3d57f8  vmovaps xmm12, [rsp+0xC0]
00007871bd3d5801  vmovaps xmm13, [rsp+0xD0]
00007871bd3d580a  vmovaps xmm14, [rsp+0xE0]
00007871bd3d5813  add rsp, 0xF0
00007871bd3d581a  pop r11
00007871bd3d581c  pop r10
00007871bd3d581e  pop r9
00007871bd3d5820  pop r8
00007871bd3d5822  pop rsi
00007871bd3d5823  pop rdi
00007871bd3d5824  pop rdx
00007871bd3d5825  pop rcx
00007871bd3d5826  pop rax
00007871bd3d5827  add rsp, 0x08
00007871bd3d582b  jmp 0x00007871BD3D2EE3
00007871bd3d5830  sub rsp, 0x08
00007871bd3d5834  push rax
00007871bd3d5835  push rcx
00007871bd3d5836  push rdx
00007871bd3d5837  push rdi
00007871bd3d5838  push rsi
00007871bd3d5839  push r8
00007871bd3d583b  push r9
00007871bd3d583d  push r10
00007871bd3d583f  push r11
00007871bd3d5841  sub rsp, 0xF0
00007871bd3d5848  vmovaps [rsp], xmm0
00007871bd3d584d  vmovaps [rsp+0x10], xmm1
00007871bd3d5853  vmovaps [rsp+0x20], xmm2
00007871bd3d5859  vmovaps [rsp+0x30], xmm3
00007871bd3d585f  vmovaps [rsp+0x40], xmm4
00007871bd3d5865  vmovaps [rsp+0x50], xmm5
00007871bd3d586b  vmovaps [rsp+0x60], xmm6
00007871bd3d5871  vmovaps [rsp+0x70], xmm7
00007871bd3d5877  vmovaps [rsp+0x80], xmm8
00007871bd3d5880  vmovaps [rsp+0x90], xmm9
00007871bd3d5889  vmovaps [rsp+0xA0], xmm10
00007871bd3d5892  vmovaps [rsp+0xB0], xmm12
00007871bd3d589b  vmovaps [rsp+0xC0], xmm13
00007871bd3d58a4  vmovaps [rsp+0xD0], xmm14
00007871bd3d58ad  vmovaps [rsp+0xE0], xmm15
00007871bd3d58b6  sub rsp, 0x30
00007871bd3d58ba  movaps [rsp], xmm11
00007871bd3d58bf  movaps [rsp+0x10], xmm6
00007871bd3d58c4  movaps [rsp+0x20], xmm14
00007871bd3d58ca  lea rdi, [rsp]
00007871bd3d58ce  mov esi, 0x00
00007871bd3d58d3  mov rax, 0x5BA2FDD2A530
00007871bd3d58dd  call rax
00007871bd3d58df  movaps xmm11, [rsp]
00007871bd3d58e4  add rsp, 0x30
00007871bd3d58e8  vmovaps xmm0, [rsp]
00007871bd3d58ed  vmovaps xmm1, [rsp+0x10]
00007871bd3d58f3  vmovaps xmm2, [rsp+0x20]
00007871bd3d58f9  vmovaps xmm3, [rsp+0x30]
00007871bd3d58ff  vmovaps xmm4, [rsp+0x40]
00007871bd3d5905  vmovaps xmm5, [rsp+0x50]
00007871bd3d590b  vmovaps xmm6, [rsp+0x60]
00007871bd3d5911  vmovaps xmm7, [rsp+0x70]
00007871bd3d5917  vmovaps xmm8, [rsp+0x80]
00007871bd3d5920  vmovaps xmm9, [rsp+0x90]
00007871bd3d5929  vmovaps xmm10, [rsp+0xA0]
00007871bd3d5932  vmovaps xmm12, [rsp+0xB0]
00007871bd3d593b  vmovaps xmm13, [rsp+0xC0]
00007871bd3d5944  vmovaps xmm14, [rsp+0xD0]
00007871bd3d594d  vmovaps xmm15, [rsp+0xE0]
00007871bd3d5956  add rsp, 0xF0
00007871bd3d595d  pop r11
00007871bd3d595f  pop r10
00007871bd3d5961  pop r9
00007871bd3d5963  pop r8
00007871bd3d5965  pop rsi
00007871bd3d5966  pop rdi
00007871bd3d5967  pop rdx
00007871bd3d5968  pop rcx
00007871bd3d5969  pop rax
00007871bd3d596a  add rsp, 0x08
00007871bd3d596e  jmp 0x00007871BD3D2F5B
00007871bd3d5973  call 0x00007871BD1FF430
00007871bd3d5978  jmp 0x00007871BD3D2F65
00007871bd3d597d  sub rsp, 0x08
00007871bd3d5981  push rax
00007871bd3d5982  push rcx
00007871bd3d5983  push rdx
00007871bd3d5984  push rdi
00007871bd3d5985  push rsi
00007871bd3d5986  push r8
00007871bd3d5988  push r9
00007871bd3d598a  push r10
00007871bd3d598c  push r11
00007871bd3d598e  sub rsp, 0xF0
00007871bd3d5995  vmovaps [rsp], xmm0
00007871bd3d599a  vmovaps [rsp+0x10], xmm1
00007871bd3d59a0  vmovaps [rsp+0x20], xmm2
00007871bd3d59a6  vmovaps [rsp+0x30], xmm3
00007871bd3d59ac  vmovaps [rsp+0x40], xmm4
00007871bd3d59b2  vmovaps [rsp+0x50], xmm5
00007871bd3d59b8  vmovaps [rsp+0x60], xmm6
00007871bd3d59be  vmovaps [rsp+0x70], xmm7
00007871bd3d59c4  vmovaps [rsp+0x80], xmm8
00007871bd3d59cd  vmovaps [rsp+0x90], xmm9
00007871bd3d59d6  vmovaps [rsp+0xA0], xmm10
00007871bd3d59df  vmovaps [rsp+0xB0], xmm11
00007871bd3d59e8  vmovaps [rsp+0xC0], xmm12
00007871bd3d59f1  vmovaps [rsp+0xD0], xmm13
00007871bd3d59fa  vmovaps [rsp+0xE0], xmm15
00007871bd3d5a03  sub rsp, 0x30
00007871bd3d5a07  movaps [rsp], xmm14
00007871bd3d5a0c  movaps [rsp+0x10], xmm6
00007871bd3d5a11  movaps [rsp+0x20], xmm2
00007871bd3d5a16  lea rdi, [rsp]
00007871bd3d5a1a  mov esi, 0x00
00007871bd3d5a1f  mov rax, 0x5BA2FDD2A530
00007871bd3d5a29  call rax
00007871bd3d5a2b  movaps xmm14, [rsp]
00007871bd3d5a30  add rsp, 0x30
00007871bd3d5a34  vmovaps xmm0, [rsp]
00007871bd3d5a39  vmovaps xmm1, [rsp+0x10]
00007871bd3d5a3f  vmovaps xmm2, [rsp+0x20]
00007871bd3d5a45  vmovaps xmm3, [rsp+0x30]
00007871bd3d5a4b  vmovaps xmm4, [rsp+0x40]
00007871bd3d5a51  vmovaps xmm5, [rsp+0x50]
00007871bd3d5a57  vmovaps xmm6, [rsp+0x60]
00007871bd3d5a5d  vmovaps xmm7, [rsp+0x70]
00007871bd3d5a63  vmovaps xmm8, [rsp+0x80]
00007871bd3d5a6c  vmovaps xmm9, [rsp+0x90]
00007871bd3d5a75  vmovaps xmm10, [rsp+0xA0]
00007871bd3d5a7e  vmovaps xmm11, [rsp+0xB0]
00007871bd3d5a87  vmovaps xmm12, [rsp+0xC0]
00007871bd3d5a90  vmovaps xmm13, [rsp+0xD0]
00007871bd3d5a99  vmovaps xmm15, [rsp+0xE0]
00007871bd3d5aa2  add rsp, 0xF0
00007871bd3d5aa9  pop r11
00007871bd3d5aab  pop r10
00007871bd3d5aad  pop r9
00007871bd3d5aaf  pop r8
00007871bd3d5ab1  pop rsi
00007871bd3d5ab2  pop rdi
00007871bd3d5ab3  pop rdx
00007871bd3d5ab4  pop rcx
00007871bd3d5ab5  pop rax
00007871bd3d5ab6  add rsp, 0x08
00007871bd3d5aba  jmp 0x00007871BD3D2F99
00007871bd3d5abf  sub rsp, 0x08
00007871bd3d5ac3  push rax
00007871bd3d5ac4  push rcx
00007871bd3d5ac5  push rdx
00007871bd3d5ac6  push rdi
00007871bd3d5ac7  push rsi
00007871bd3d5ac8  push r8
00007871bd3d5aca  push r9
00007871bd3d5acc  push r10
00007871bd3d5ace  push r11
00007871bd3d5ad0  sub rsp, 0xF0
00007871bd3d5ad7  vmovaps [rsp], xmm0
00007871bd3d5adc  vmovaps [rsp+0x10], xmm1
00007871bd3d5ae2  vmovaps [rsp+0x20], xmm2
00007871bd3d5ae8  vmovaps [rsp+0x30], xmm3
00007871bd3d5aee  vmovaps [rsp+0x40], xmm4
00007871bd3d5af4  vmovaps [rsp+0x50], xmm5
00007871bd3d5afa  vmovaps [rsp+0x60], xmm7
00007871bd3d5b00  vmovaps [rsp+0x70], xmm8
00007871bd3d5b06  vmovaps [rsp+0x80], xmm9
00007871bd3d5b0f  vmovaps [rsp+0x90], xmm10
00007871bd3d5b18  vmovaps [rsp+0xA0], xmm11
00007871bd3d5b21  vmovaps [rsp+0xB0], xmm12
00007871bd3d5b2a  vmovaps [rsp+0xC0], xmm13
00007871bd3d5b33  vmovaps [rsp+0xD0], xmm14
00007871bd3d5b3c  vmovaps [rsp+0xE0], xmm15
00007871bd3d5b45  sub rsp, 0x30
00007871bd3d5b49  movaps [rsp], xmm6
00007871bd3d5b4d  movaps [rsp+0x10], xmm5
00007871bd3d5b52  movaps [rsp+0x20], xmm1
00007871bd3d5b57  lea rdi, [rsp]
00007871bd3d5b5b  mov esi, 0x00
00007871bd3d5b60  mov rax, 0x5BA2FDD2A530
00007871bd3d5b6a  call rax
00007871bd3d5b6c  movaps xmm6, [rsp]
00007871bd3d5b70  add rsp, 0x30
00007871bd3d5b74  vmovaps xmm0, [rsp]
00007871bd3d5b79  vmovaps xmm1, [rsp+0x10]
00007871bd3d5b7f  vmovaps xmm2, [rsp+0x20]
00007871bd3d5b85  vmovaps xmm3, [rsp+0x30]
00007871bd3d5b8b  vmovaps xmm4, [rsp+0x40]
00007871bd3d5b91  vmovaps xmm5, [rsp+0x50]
00007871bd3d5b97  vmovaps xmm7, [rsp+0x60]
00007871bd3d5b9d  vmovaps xmm8, [rsp+0x70]
00007871bd3d5ba3  vmovaps xmm9, [rsp+0x80]
00007871bd3d5bac  vmovaps xmm10, [rsp+0x90]
00007871bd3d5bb5  vmovaps xmm11, [rsp+0xA0]
00007871bd3d5bbe  vmovaps xmm12, [rsp+0xB0]
00007871bd3d5bc7  vmovaps xmm13, [rsp+0xC0]
00007871bd3d5bd0  vmovaps xmm14, [rsp+0xD0]
00007871bd3d5bd9  vmovaps xmm15, [rsp+0xE0]
00007871bd3d5be2  add rsp, 0xF0
00007871bd3d5be9  pop r11
00007871bd3d5beb  pop r10
00007871bd3d5bed  pop r9
00007871bd3d5bef  pop r8
00007871bd3d5bf1  pop rsi
00007871bd3d5bf2  pop rdi
00007871bd3d5bf3  pop rdx
00007871bd3d5bf4  pop rcx
00007871bd3d5bf5  pop rax
00007871bd3d5bf6  add rsp, 0x08
00007871bd3d5bfa  jmp 0x00007871BD3D2FBF
00007871bd3d5bff  sub rsp, 0x08
00007871bd3d5c03  push rax
00007871bd3d5c04  push rcx
00007871bd3d5c05  push rdx
00007871bd3d5c06  push rdi
00007871bd3d5c07  push rsi
00007871bd3d5c08  push r8
00007871bd3d5c0a  push r9
00007871bd3d5c0c  push r10
00007871bd3d5c0e  push r11
00007871bd3d5c10  sub rsp, 0xF0
00007871bd3d5c17  vmovaps [rsp], xmm0
00007871bd3d5c1c  vmovaps [rsp+0x10], xmm2
00007871bd3d5c22  vmovaps [rsp+0x20], xmm3
00007871bd3d5c28  vmovaps [rsp+0x30], xmm4
00007871bd3d5c2e  vmovaps [rsp+0x40], xmm5
00007871bd3d5c34  vmovaps [rsp+0x50], xmm6
00007871bd3d5c3a  vmovaps [rsp+0x60], xmm7
00007871bd3d5c40  vmovaps [rsp+0x70], xmm8
00007871bd3d5c46  vmovaps [rsp+0x80], xmm9
00007871bd3d5c4f  vmovaps [rsp+0x90], xmm10
00007871bd3d5c58  vmovaps [rsp+0xA0], xmm11
00007871bd3d5c61  vmovaps [rsp+0xB0], xmm12
00007871bd3d5c6a  vmovaps [rsp+0xC0], xmm13
00007871bd3d5c73  vmovaps [rsp+0xD0], xmm14
00007871bd3d5c7c  vmovaps [rsp+0xE0], xmm15
00007871bd3d5c85  sub rsp, 0x30
00007871bd3d5c89  movaps [rsp], xmm1
00007871bd3d5c8d  movaps [rsp+0x10], xmm5
00007871bd3d5c92  movaps [rsp+0x20], xmm13
00007871bd3d5c98  lea rdi, [rsp]
00007871bd3d5c9c  mov esi, 0x00
00007871bd3d5ca1  mov rax, 0x5BA2FDD2A530
00007871bd3d5cab  call rax
00007871bd3d5cad  movaps xmm1, [rsp]
00007871bd3d5cb1  add rsp, 0x30
00007871bd3d5cb5  vmovaps xmm0, [rsp]
00007871bd3d5cba  vmovaps xmm2, [rsp+0x10]
00007871bd3d5cc0  vmovaps xmm3, [rsp+0x20]
00007871bd3d5cc6  vmovaps xmm4, [rsp+0x30]
00007871bd3d5ccc  vmovaps xmm5, [rsp+0x40]
00007871bd3d5cd2  vmovaps xmm6, [rsp+0x50]
00007871bd3d5cd8  vmovaps xmm7, [rsp+0x60]
00007871bd3d5cde  vmovaps xmm8, [rsp+0x70]
00007871bd3d5ce4  vmovaps xmm9, [rsp+0x80]
00007871bd3d5ced  vmovaps xmm10, [rsp+0x90]
00007871bd3d5cf6  vmovaps xmm11, [rsp+0xA0]
00007871bd3d5cff  vmovaps xmm12, [rsp+0xB0]
00007871bd3d5d08  vmovaps xmm13, [rsp+0xC0]
00007871bd3d5d11  vmovaps xmm14, [rsp+0xD0]
00007871bd3d5d1a  vmovaps xmm15, [rsp+0xE0]
00007871bd3d5d23  add rsp, 0xF0
00007871bd3d5d2a  pop r11
00007871bd3d5d2c  pop r10
00007871bd3d5d2e  pop r9
00007871bd3d5d30  pop r8
00007871bd3d5d32  pop rsi
00007871bd3d5d33  pop rdi
00007871bd3d5d34  pop rdx
00007871bd3d5d35  pop rcx
00007871bd3d5d36  pop rax
00007871bd3d5d37  add rsp, 0x08
00007871bd3d5d3b  jmp 0x00007871BD3D2FDD
00007871bd3d5d40  sub rsp, 0x08
00007871bd3d5d44  push rax
00007871bd3d5d45  push rcx
00007871bd3d5d46  push rdx
00007871bd3d5d47  push rdi
00007871bd3d5d48  push rsi
00007871bd3d5d49  push r8
00007871bd3d5d4b  push r9
00007871bd3d5d4d  push r10
00007871bd3d5d4f  push r11
00007871bd3d5d51  sub rsp, 0xF0
00007871bd3d5d58  vmovaps [rsp], xmm0
00007871bd3d5d5d  vmovaps [rsp+0x10], xmm1
00007871bd3d5d63  vmovaps [rsp+0x20], xmm2
00007871bd3d5d69  vmovaps [rsp+0x30], xmm3
00007871bd3d5d6f  vmovaps [rsp+0x40], xmm4
00007871bd3d5d75  vmovaps [rsp+0x50], xmm6
00007871bd3d5d7b  vmovaps [rsp+0x60], xmm7
00007871bd3d5d81  vmovaps [rsp+0x70], xmm8
00007871bd3d5d87  vmovaps [rsp+0x80], xmm9
00007871bd3d5d90  vmovaps [rsp+0x90], xmm10
00007871bd3d5d99  vmovaps [rsp+0xA0], xmm11
00007871bd3d5da2  vmovaps [rsp+0xB0], xmm12
00007871bd3d5dab  vmovaps [rsp+0xC0], xmm13
00007871bd3d5db4  vmovaps [rsp+0xD0], xmm14
00007871bd3d5dbd  vmovaps [rsp+0xE0], xmm15
00007871bd3d5dc6  sub rsp, 0x30
00007871bd3d5dca  movaps [rsp], xmm5
00007871bd3d5dce  movaps [rsp+0x10], xmm2
00007871bd3d5dd3  movaps [rsp+0x20], xmm13
00007871bd3d5dd9  lea rdi, [rsp]
00007871bd3d5ddd  mov esi, 0x00
00007871bd3d5de2  mov rax, 0x5BA2FDD2A530
00007871bd3d5dec  call rax
00007871bd3d5dee  movaps xmm5, [rsp]
00007871bd3d5df2  add rsp, 0x30
00007871bd3d5df6  vmovaps xmm0, [rsp]
00007871bd3d5dfb  vmovaps xmm1, [rsp+0x10]
00007871bd3d5e01  vmovaps xmm2, [rsp+0x20]
00007871bd3d5e07  vmovaps xmm3, [rsp+0x30]
00007871bd3d5e0d  vmovaps xmm4, [rsp+0x40]
00007871bd3d5e13  vmovaps xmm6, [rsp+0x50]
00007871bd3d5e19  vmovaps xmm7, [rsp+0x60]
00007871bd3d5e1f  vmovaps xmm8, [rsp+0x70]
00007871bd3d5e25  vmovaps xmm9, [rsp+0x80]
00007871bd3d5e2e  vmovaps xmm10, [rsp+0x90]
00007871bd3d5e37  vmovaps xmm11, [rsp+0xA0]
00007871bd3d5e40  vmovaps xmm12, [rsp+0xB0]
00007871bd3d5e49  vmovaps xmm13, [rsp+0xC0]
00007871bd3d5e52  vmovaps xmm14, [rsp+0xD0]
00007871bd3d5e5b  vmovaps xmm15, [rsp+0xE0]
00007871bd3d5e64  add rsp, 0xF0
00007871bd3d5e6b  pop r11
00007871bd3d5e6d  pop r10
00007871bd3d5e6f  pop r9
00007871bd3d5e71  pop r8
00007871bd3d5e73  pop rsi
00007871bd3d5e74  pop rdi
00007871bd3d5e75  pop rdx
00007871bd3d5e76  pop rcx
00007871bd3d5e77  pop rax
00007871bd3d5e78  add rsp, 0x08
00007871bd3d5e7c  jmp 0x00007871BD3D3013
00007871bd3d5e81  sub rsp, 0x08
00007871bd3d5e85  push rax
00007871bd3d5e86  push rcx
00007871bd3d5e87  push rdx
00007871bd3d5e88  push rdi
00007871bd3d5e89  push rsi
00007871bd3d5e8a  push r8
00007871bd3d5e8c  push r9
00007871bd3d5e8e  push r10
00007871bd3d5e90  push r11
00007871bd3d5e92  sub rsp, 0xF0
00007871bd3d5e99  vmovaps [rsp], xmm0
00007871bd3d5e9e  vmovaps [rsp+0x10], xmm1
00007871bd3d5ea4  vmovaps [rsp+0x20], xmm2
00007871bd3d5eaa  vmovaps [rsp+0x30], xmm3
00007871bd3d5eb0  vmovaps [rsp+0x40], xmm4
00007871bd3d5eb6  vmovaps [rsp+0x50], xmm5
00007871bd3d5ebc  vmovaps [rsp+0x60], xmm6
00007871bd3d5ec2  vmovaps [rsp+0x70], xmm7
00007871bd3d5ec8  vmovaps [rsp+0x80], xmm8
00007871bd3d5ed1  vmovaps [rsp+0x90], xmm9
00007871bd3d5eda  vmovaps [rsp+0xA0], xmm10
00007871bd3d5ee3  vmovaps [rsp+0xB0], xmm11
00007871bd3d5eec  vmovaps [rsp+0xC0], xmm12
00007871bd3d5ef5  vmovaps [rsp+0xD0], xmm14
00007871bd3d5efe  vmovaps [rsp+0xE0], xmm15
00007871bd3d5f07  sub rsp, 0x30
00007871bd3d5f0b  movaps [rsp], xmm13
00007871bd3d5f10  movaps [rsp+0x10], xmm10
00007871bd3d5f16  movaps [rsp+0x20], xmm1
00007871bd3d5f1b  lea rdi, [rsp]
00007871bd3d5f1f  mov esi, 0x00
00007871bd3d5f24  mov rax, 0x5BA2FDD2A530
00007871bd3d5f2e  call rax
00007871bd3d5f30  movaps xmm13, [rsp]
00007871bd3d5f35  add rsp, 0x30
00007871bd3d5f39  vmovaps xmm0, [rsp]
00007871bd3d5f3e  vmovaps xmm1, [rsp+0x10]
00007871bd3d5f44  vmovaps xmm2, [rsp+0x20]
00007871bd3d5f4a  vmovaps xmm3, [rsp+0x30]
00007871bd3d5f50  vmovaps xmm4, [rsp+0x40]
00007871bd3d5f56  vmovaps xmm5, [rsp+0x50]
00007871bd3d5f5c  vmovaps xmm6, [rsp+0x60]
00007871bd3d5f62  vmovaps xmm7, [rsp+0x70]
00007871bd3d5f68  vmovaps xmm8, [rsp+0x80]
00007871bd3d5f71  vmovaps xmm9, [rsp+0x90]
00007871bd3d5f7a  vmovaps xmm10, [rsp+0xA0]
00007871bd3d5f83  vmovaps xmm11, [rsp+0xB0]
00007871bd3d5f8c  vmovaps xmm12, [rsp+0xC0]
00007871bd3d5f95  vmovaps xmm14, [rsp+0xD0]
00007871bd3d5f9e  vmovaps xmm15, [rsp+0xE0]
00007871bd3d5fa7  add rsp, 0xF0
00007871bd3d5fae  pop r11
00007871bd3d5fb0  pop r10
00007871bd3d5fb2  pop r9
00007871bd3d5fb4  pop r8
00007871bd3d5fb6  pop rsi
00007871bd3d5fb7  pop rdi
00007871bd3d5fb8  pop rdx
00007871bd3d5fb9  pop rcx
00007871bd3d5fba  pop rax
00007871bd3d5fbb  add rsp, 0x08
00007871bd3d5fbf  jmp 0x00007871BD3D303C
00007871bd3d5fc4  sub rsp, 0x08
00007871bd3d5fc8  push rax
00007871bd3d5fc9  push rcx
00007871bd3d5fca  push rdx
00007871bd3d5fcb  push rdi
00007871bd3d5fcc  push rsi
00007871bd3d5fcd  push r8
00007871bd3d5fcf  push r9
00007871bd3d5fd1  push r10
00007871bd3d5fd3  push r11
00007871bd3d5fd5  sub rsp, 0xF0
00007871bd3d5fdc  vmovaps [rsp], xmm0
00007871bd3d5fe1  vmovaps [rsp+0x10], xmm2
00007871bd3d5fe7  vmovaps [rsp+0x20], xmm3
00007871bd3d5fed  vmovaps [rsp+0x30], xmm4
00007871bd3d5ff3  vmovaps [rsp+0x40], xmm5
00007871bd3d5ff9  vmovaps [rsp+0x50], xmm6
00007871bd3d5fff  vmovaps [rsp+0x60], xmm7
00007871bd3d6005  vmovaps [rsp+0x70], xmm8
00007871bd3d600b  vmovaps [rsp+0x80], xmm9
00007871bd3d6014  vmovaps [rsp+0x90], xmm10
00007871bd3d601d  vmovaps [rsp+0xA0], xmm11
00007871bd3d6026  vmovaps [rsp+0xB0], xmm12
00007871bd3d602f  vmovaps [rsp+0xC0], xmm13
00007871bd3d6038  vmovaps [rsp+0xD0], xmm14
00007871bd3d6041  vmovaps [rsp+0xE0], xmm15
00007871bd3d604a  sub rsp, 0x30
00007871bd3d604e  movaps [rsp], xmm1
00007871bd3d6052  movaps [rsp+0x10], xmm15
00007871bd3d6058  movaps [rsp+0x20], xmm10
00007871bd3d605e  lea rdi, [rsp]
00007871bd3d6062  mov esi, 0x00
00007871bd3d6067  mov rax, 0x5BA2FDD2A530
00007871bd3d6071  call rax
00007871bd3d6073  movaps xmm1, [rsp]
00007871bd3d6077  add rsp, 0x30
00007871bd3d607b  vmovaps xmm0, [rsp]
00007871bd3d6080  vmovaps xmm2, [rsp+0x10]
00007871bd3d6086  vmovaps xmm3, [rsp+0x20]
00007871bd3d608c  vmovaps xmm4, [rsp+0x30]
00007871bd3d6092  vmovaps xmm5, [rsp+0x40]
00007871bd3d6098  vmovaps xmm6, [rsp+0x50]
00007871bd3d609e  vmovaps xmm7, [rsp+0x60]
00007871bd3d60a4  vmovaps xmm8, [rsp+0x70]
00007871bd3d60aa  vmovaps xmm9, [rsp+0x80]
00007871bd3d60b3  vmovaps xmm10, [rsp+0x90]
00007871bd3d60bc  vmovaps xmm11, [rsp+0xA0]
00007871bd3d60c5  vmovaps xmm12, [rsp+0xB0]
00007871bd3d60ce  vmovaps xmm13, [rsp+0xC0]
00007871bd3d60d7  vmovaps xmm14, [rsp+0xD0]
00007871bd3d60e0  vmovaps xmm15, [rsp+0xE0]
00007871bd3d60e9  add rsp, 0xF0
00007871bd3d60f0  pop r11
00007871bd3d60f2  pop r10
00007871bd3d60f4  pop r9
00007871bd3d60f6  pop r8
00007871bd3d60f8  pop rsi
00007871bd3d60f9  pop rdi
00007871bd3d60fa  pop rdx
00007871bd3d60fb  pop rcx
00007871bd3d60fc  pop rax
00007871bd3d60fd  add rsp, 0x08
00007871bd3d6101  jmp 0x00007871BD3D305B
00007871bd3d6106  sub rsp, 0x08
00007871bd3d610a  push rax
00007871bd3d610b  push rcx
00007871bd3d610c  push rdx
00007871bd3d610d  push rdi
00007871bd3d610e  push rsi
00007871bd3d610f  push r8
00007871bd3d6111  push r9
00007871bd3d6113  push r10
00007871bd3d6115  push r11
00007871bd3d6117  sub rsp, 0xF0
00007871bd3d611e  vmovaps [rsp], xmm0
00007871bd3d6123  vmovaps [rsp+0x10], xmm1
00007871bd3d6129  vmovaps [rsp+0x20], xmm2
00007871bd3d612f  vmovaps [rsp+0x30], xmm3
00007871bd3d6135  vmovaps [rsp+0x40], xmm4
00007871bd3d613b  vmovaps [rsp+0x50], xmm5
00007871bd3d6141  vmovaps [rsp+0x60], xmm6
00007871bd3d6147  vmovaps [rsp+0x70], xmm7
00007871bd3d614d  vmovaps [rsp+0x80], xmm8
00007871bd3d6156  vmovaps [rsp+0x90], xmm9
00007871bd3d615f  vmovaps [rsp+0xA0], xmm10
00007871bd3d6168  vmovaps [rsp+0xB0], xmm11
00007871bd3d6171  vmovaps [rsp+0xC0], xmm12
00007871bd3d617a  vmovaps [rsp+0xD0], xmm13
00007871bd3d6183  vmovaps [rsp+0xE0], xmm14
00007871bd3d618c  sub rsp, 0x30
00007871bd3d6190  movaps [rsp], xmm15
00007871bd3d6195  movaps [rsp+0x10], xmm10
00007871bd3d619b  movaps [rsp+0x20], xmm11
00007871bd3d61a1  lea rdi, [rsp]
00007871bd3d61a5  mov esi, 0x00
00007871bd3d61aa  mov rax, 0x5BA2FDD2A530
00007871bd3d61b4  call rax
00007871bd3d61b6  movaps xmm15, [rsp]
00007871bd3d61bb  add rsp, 0x30
00007871bd3d61bf  vmovaps xmm0, [rsp]
00007871bd3d61c4  vmovaps xmm1, [rsp+0x10]
00007871bd3d61ca  vmovaps xmm2, [rsp+0x20]
00007871bd3d61d0  vmovaps xmm3, [rsp+0x30]
00007871bd3d61d6  vmovaps xmm4, [rsp+0x40]
00007871bd3d61dc  vmovaps xmm5, [rsp+0x50]
00007871bd3d61e2  vmovaps xmm6, [rsp+0x60]
00007871bd3d61e8  vmovaps xmm7, [rsp+0x70]
00007871bd3d61ee  vmovaps xmm8, [rsp+0x80]
00007871bd3d61f7  vmovaps xmm9, [rsp+0x90]
00007871bd3d6200  vmovaps xmm10, [rsp+0xA0]
00007871bd3d6209  vmovaps xmm11, [rsp+0xB0]
00007871bd3d6212  vmovaps xmm12, [rsp+0xC0]
00007871bd3d621b  vmovaps xmm13, [rsp+0xD0]
00007871bd3d6224  vmovaps xmm14, [rsp+0xE0]
00007871bd3d622d  add rsp, 0xF0
00007871bd3d6234  pop r11
00007871bd3d6236  pop r10
00007871bd3d6238  pop r9
00007871bd3d623a  pop r8
00007871bd3d623c  pop rsi
00007871bd3d623d  pop rdi
00007871bd3d623e  pop rdx
00007871bd3d623f  pop rcx
00007871bd3d6240  pop rax
00007871bd3d6241  add rsp, 0x08
00007871bd3d6245  jmp 0x00007871BD3D307E
00007871bd3d624a  sub rsp, 0x08
00007871bd3d624e  push rax
00007871bd3d624f  push rcx
00007871bd3d6250  push rdx
00007871bd3d6251  push rdi
00007871bd3d6252  push rsi
00007871bd3d6253  push r8
00007871bd3d6255  push r9
00007871bd3d6257  push r10
00007871bd3d6259  push r11
00007871bd3d625b  sub rsp, 0xF0
00007871bd3d6262  vmovaps [rsp], xmm0
00007871bd3d6267  vmovaps [rsp+0x10], xmm1
00007871bd3d626d  vmovaps [rsp+0x20], xmm2
00007871bd3d6273  vmovaps [rsp+0x30], xmm3
00007871bd3d6279  vmovaps [rsp+0x40], xmm4
00007871bd3d627f  vmovaps [rsp+0x50], xmm5
00007871bd3d6285  vmovaps [rsp+0x60], xmm6
00007871bd3d628b  vmovaps [rsp+0x70], xmm7
00007871bd3d6291  vmovaps [rsp+0x80], xmm8
00007871bd3d629a  vmovaps [rsp+0x90], xmm9
00007871bd3d62a3  vmovaps [rsp+0xA0], xmm11
00007871bd3d62ac  vmovaps [rsp+0xB0], xmm12
00007871bd3d62b5  vmovaps [rsp+0xC0], xmm13
00007871bd3d62be  vmovaps [rsp+0xD0], xmm14
00007871bd3d62c7  vmovaps [rsp+0xE0], xmm15
00007871bd3d62d0  sub rsp, 0x30
00007871bd3d62d4  movaps [rsp], xmm10
00007871bd3d62d9  movaps [rsp+0x10], xmm2
00007871bd3d62de  movaps [rsp+0x20], xmm11
00007871bd3d62e4  lea rdi, [rsp]
00007871bd3d62e8  mov esi, 0x00
00007871bd3d62ed  mov rax, 0x5BA2FDD2A530
00007871bd3d62f7  call rax
00007871bd3d62f9  movaps xmm10, [rsp]
00007871bd3d62fe  add rsp, 0x30
00007871bd3d6302  vmovaps xmm0, [rsp]
00007871bd3d6307  vmovaps xmm1, [rsp+0x10]
00007871bd3d630d  vmovaps xmm2, [rsp+0x20]
00007871bd3d6313  vmovaps xmm3, [rsp+0x30]
00007871bd3d6319  vmovaps xmm4, [rsp+0x40]
00007871bd3d631f  vmovaps xmm5, [rsp+0x50]
00007871bd3d6325  vmovaps xmm6, [rsp+0x60]
00007871bd3d632b  vmovaps xmm7, [rsp+0x70]
00007871bd3d6331  vmovaps xmm8, [rsp+0x80]
00007871bd3d633a  vmovaps xmm9, [rsp+0x90]
00007871bd3d6343  vmovaps xmm11, [rsp+0xA0]
00007871bd3d634c  vmovaps xmm12, [rsp+0xB0]
00007871bd3d6355  vmovaps xmm13, [rsp+0xC0]
00007871bd3d635e  vmovaps xmm14, [rsp+0xD0]
00007871bd3d6367  vmovaps xmm15, [rsp+0xE0]
00007871bd3d6370  add rsp, 0xF0
00007871bd3d6377  pop r11
00007871bd3d6379  pop r10
00007871bd3d637b  pop r9
00007871bd3d637d  pop r8
00007871bd3d637f  pop rsi
00007871bd3d6380  pop rdi
00007871bd3d6381  pop rdx
00007871bd3d6382  pop rcx
00007871bd3d6383  pop rax
00007871bd3d6384  add rsp, 0x08
00007871bd3d6388  jmp 0x00007871BD3D30B6
00007871bd3d638d  sub rsp, 0x08
00007871bd3d6391  push rax
00007871bd3d6392  push rcx
00007871bd3d6393  push rdx
00007871bd3d6394  push rdi
00007871bd3d6395  push rsi
00007871bd3d6396  push r8
00007871bd3d6398  push r9
00007871bd3d639a  push r10
00007871bd3d639c  push r11
00007871bd3d639e  sub rsp, 0xF0
00007871bd3d63a5  vmovaps [rsp], xmm0
00007871bd3d63aa  vmovaps [rsp+0x10], xmm1
00007871bd3d63b0  vmovaps [rsp+0x20], xmm2
00007871bd3d63b6  vmovaps [rsp+0x30], xmm3
00007871bd3d63bc  vmovaps [rsp+0x40], xmm4
00007871bd3d63c2  vmovaps [rsp+0x50], xmm5
00007871bd3d63c8  vmovaps [rsp+0x60], xmm6
00007871bd3d63ce  vmovaps [rsp+0x70], xmm7
00007871bd3d63d4  vmovaps [rsp+0x80], xmm8
00007871bd3d63dd  vmovaps [rsp+0x90], xmm9
00007871bd3d63e6  vmovaps [rsp+0xA0], xmm10
00007871bd3d63ef  vmovaps [rsp+0xB0], xmm12
00007871bd3d63f8  vmovaps [rsp+0xC0], xmm13
00007871bd3d6401  vmovaps [rsp+0xD0], xmm14
00007871bd3d640a  vmovaps [rsp+0xE0], xmm15
00007871bd3d6413  sub rsp, 0x30
00007871bd3d6417  movaps [rsp], xmm11
00007871bd3d641c  movaps [rsp+0x10], xmm2
00007871bd3d6421  movaps [rsp+0x20], xmm1
00007871bd3d6426  lea rdi, [rsp]
00007871bd3d642a  mov esi, 0x00
00007871bd3d642f  mov rax, 0x5BA2FDD2A530
00007871bd3d6439  call rax
00007871bd3d643b  movaps xmm11, [rsp]
00007871bd3d6440  add rsp, 0x30
00007871bd3d6444  vmovaps xmm0, [rsp]
00007871bd3d6449  vmovaps xmm1, [rsp+0x10]
00007871bd3d644f  vmovaps xmm2, [rsp+0x20]
00007871bd3d6455  vmovaps xmm3, [rsp+0x30]
00007871bd3d645b  vmovaps xmm4, [rsp+0x40]
00007871bd3d6461  vmovaps xmm5, [rsp+0x50]
00007871bd3d6467  vmovaps xmm6, [rsp+0x60]
00007871bd3d646d  vmovaps xmm7, [rsp+0x70]
00007871bd3d6473  vmovaps xmm8, [rsp+0x80]
00007871bd3d647c  vmovaps xmm9, [rsp+0x90]
00007871bd3d6485  vmovaps xmm10, [rsp+0xA0]
00007871bd3d648e  vmovaps xmm12, [rsp+0xB0]
00007871bd3d6497  vmovaps xmm13, [rsp+0xC0]
00007871bd3d64a0  vmovaps xmm14, [rsp+0xD0]
00007871bd3d64a9  vmovaps xmm15, [rsp+0xE0]
00007871bd3d64b2  add rsp, 0xF0
00007871bd3d64b9  pop r11
00007871bd3d64bb  pop r10
00007871bd3d64bd  pop r9
00007871bd3d64bf  pop r8
00007871bd3d64c1  pop rsi
00007871bd3d64c2  pop rdi
00007871bd3d64c3  pop rdx
00007871bd3d64c4  pop rcx
00007871bd3d64c5  pop rax
00007871bd3d64c6  add rsp, 0x08
00007871bd3d64ca  jmp 0x00007871BD3D30F2
00007871bd3d64cf  sub rsp, 0x08
00007871bd3d64d3  push rax
00007871bd3d64d4  push rcx
00007871bd3d64d5  push rdx
00007871bd3d64d6  push rdi
00007871bd3d64d7  push rsi
00007871bd3d64d8  push r8
00007871bd3d64da  push r9
00007871bd3d64dc  push r10
00007871bd3d64de  push r11
00007871bd3d64e0  sub rsp, 0xF0
00007871bd3d64e7  vmovaps [rsp], xmm0
00007871bd3d64ec  vmovaps [rsp+0x10], xmm2
00007871bd3d64f2  vmovaps [rsp+0x20], xmm3
00007871bd3d64f8  vmovaps [rsp+0x30], xmm4
00007871bd3d64fe  vmovaps [rsp+0x40], xmm5
00007871bd3d6504  vmovaps [rsp+0x50], xmm6
00007871bd3d650a  vmovaps [rsp+0x60], xmm7
00007871bd3d6510  vmovaps [rsp+0x70], xmm8
00007871bd3d6516  vmovaps [rsp+0x80], xmm9
00007871bd3d651f  vmovaps [rsp+0x90], xmm10
00007871bd3d6528  vmovaps [rsp+0xA0], xmm11
00007871bd3d6531  vmovaps [rsp+0xB0], xmm12
00007871bd3d653a  vmovaps [rsp+0xC0], xmm13
00007871bd3d6543  vmovaps [rsp+0xD0], xmm14
00007871bd3d654c  vmovaps [rsp+0xE0], xmm15
00007871bd3d6555  sub rsp, 0x30
00007871bd3d6559  movaps [rsp], xmm1
00007871bd3d655d  movaps [rsp+0x10], xmm14
00007871bd3d6563  movaps [rsp+0x20], xmm6
00007871bd3d6568  lea rdi, [rsp]
00007871bd3d656c  mov esi, 0x00
00007871bd3d6571  mov rax, 0x5BA2FDD2A530
00007871bd3d657b  call rax
00007871bd3d657d  movaps xmm1, [rsp]
00007871bd3d6581  add rsp, 0x30
00007871bd3d6585  vmovaps xmm0, [rsp]
00007871bd3d658a  vmovaps xmm2, [rsp+0x10]
00007871bd3d6590  vmovaps xmm3, [rsp+0x20]
00007871bd3d6596  vmovaps xmm4, [rsp+0x30]
00007871bd3d659c  vmovaps xmm5, [rsp+0x40]
00007871bd3d65a2  vmovaps xmm6, [rsp+0x50]
00007871bd3d65a8  vmovaps xmm7, [rsp+0x60]
00007871bd3d65ae  vmovaps xmm8, [rsp+0x70]
00007871bd3d65b4  vmovaps xmm9, [rsp+0x80]
00007871bd3d65bd  vmovaps xmm10, [rsp+0x90]
00007871bd3d65c6  vmovaps xmm11, [rsp+0xA0]
00007871bd3d65cf  vmovaps xmm12, [rsp+0xB0]
00007871bd3d65d8  vmovaps xmm13, [rsp+0xC0]
00007871bd3d65e1  vmovaps xmm14, [rsp+0xD0]
00007871bd3d65ea  vmovaps xmm15, [rsp+0xE0]
00007871bd3d65f3  add rsp, 0xF0
00007871bd3d65fa  pop r11
00007871bd3d65fc  pop r10
00007871bd3d65fe  pop r9
00007871bd3d6600  pop r8
00007871bd3d6602  pop rsi
00007871bd3d6603  pop rdi
00007871bd3d6604  pop rdx
00007871bd3d6605  pop rcx
00007871bd3d6606  pop rax
00007871bd3d6607  add rsp, 0x08
00007871bd3d660b  jmp 0x00007871BD3D310B
00007871bd3d6610  sub rsp, 0x08
00007871bd3d6614  push rax
00007871bd3d6615  push rcx
00007871bd3d6616  push rdx
00007871bd3d6617  push rdi
00007871bd3d6618  push rsi
00007871bd3d6619  push r8
00007871bd3d661b  push r9
00007871bd3d661d  push r10
00007871bd3d661f  push r11
00007871bd3d6621  sub rsp, 0xF0
00007871bd3d6628  vmovaps [rsp], xmm0
00007871bd3d662d  vmovaps [rsp+0x10], xmm1
00007871bd3d6633  vmovaps [rsp+0x20], xmm2
00007871bd3d6639  vmovaps [rsp+0x30], xmm3
00007871bd3d663f  vmovaps [rsp+0x40], xmm4
00007871bd3d6645  vmovaps [rsp+0x50], xmm5
00007871bd3d664b  vmovaps [rsp+0x60], xmm6
00007871bd3d6651  vmovaps [rsp+0x70], xmm7
00007871bd3d6657  vmovaps [rsp+0x80], xmm8
00007871bd3d6660  vmovaps [rsp+0x90], xmm9
00007871bd3d6669  vmovaps [rsp+0xA0], xmm10
00007871bd3d6672  vmovaps [rsp+0xB0], xmm11
00007871bd3d667b  vmovaps [rsp+0xC0], xmm12
00007871bd3d6684  vmovaps [rsp+0xD0], xmm13
00007871bd3d668d  vmovaps [rsp+0xE0], xmm14
00007871bd3d6696  sub rsp, 0x30
00007871bd3d669a  movaps [rsp], xmm15
00007871bd3d669f  movaps [rsp+0x10], xmm14
00007871bd3d66a5  movaps [rsp+0x20], xmm5
00007871bd3d66aa  lea rdi, [rsp]
00007871bd3d66ae  mov esi, 0x00
00007871bd3d66b3  mov rax, 0x5BA2FDD2A530
00007871bd3d66bd  call rax
00007871bd3d66bf  movaps xmm15, [rsp]
00007871bd3d66c4  add rsp, 0x30
00007871bd3d66c8  vmovaps xmm0, [rsp]
00007871bd3d66cd  vmovaps xmm1, [rsp+0x10]
00007871bd3d66d3  vmovaps xmm2, [rsp+0x20]
00007871bd3d66d9  vmovaps xmm3, [rsp+0x30]
00007871bd3d66df  vmovaps xmm4, [rsp+0x40]
00007871bd3d66e5  vmovaps xmm5, [rsp+0x50]
00007871bd3d66eb  vmovaps xmm6, [rsp+0x60]
00007871bd3d66f1  vmovaps xmm7, [rsp+0x70]
00007871bd3d66f7  vmovaps xmm8, [rsp+0x80]
00007871bd3d6700  vmovaps xmm9, [rsp+0x90]
00007871bd3d6709  vmovaps xmm10, [rsp+0xA0]
00007871bd3d6712  vmovaps xmm11, [rsp+0xB0]
00007871bd3d671b  vmovaps xmm12, [rsp+0xC0]
00007871bd3d6724  vmovaps xmm13, [rsp+0xD0]
00007871bd3d672d  vmovaps xmm14, [rsp+0xE0]
00007871bd3d6736  add rsp, 0xF0
00007871bd3d673d  pop r11
00007871bd3d673f  pop r10
00007871bd3d6741  pop r9
00007871bd3d6743  pop r8
00007871bd3d6745  pop rsi
00007871bd3d6746  pop rdi
00007871bd3d6747  pop rdx
00007871bd3d6748  pop rcx
00007871bd3d6749  pop rax
00007871bd3d674a  add rsp, 0x08
00007871bd3d674e  jmp 0x00007871BD3D312B
00007871bd3d6753  sub rsp, 0x08
00007871bd3d6757  push rax
00007871bd3d6758  push rcx
00007871bd3d6759  push rdx
00007871bd3d675a  push rdi
00007871bd3d675b  push rsi
00007871bd3d675c  push r8
00007871bd3d675e  push r9
00007871bd3d6760  push r10
00007871bd3d6762  push r11
00007871bd3d6764  sub rsp, 0xF0
00007871bd3d676b  vmovaps [rsp], xmm0
00007871bd3d6770  vmovaps [rsp+0x10], xmm1
00007871bd3d6776  vmovaps [rsp+0x20], xmm2
00007871bd3d677c  vmovaps [rsp+0x30], xmm3
00007871bd3d6782  vmovaps [rsp+0x40], xmm4
00007871bd3d6788  vmovaps [rsp+0x50], xmm5
00007871bd3d678e  vmovaps [rsp+0x60], xmm7
00007871bd3d6794  vmovaps [rsp+0x70], xmm8
00007871bd3d679a  vmovaps [rsp+0x80], xmm9
00007871bd3d67a3  vmovaps [rsp+0x90], xmm10
00007871bd3d67ac  vmovaps [rsp+0xA0], xmm11
00007871bd3d67b5  vmovaps [rsp+0xB0], xmm12
00007871bd3d67be  vmovaps [rsp+0xC0], xmm13
00007871bd3d67c7  vmovaps [rsp+0xD0], xmm14
00007871bd3d67d0  vmovaps [rsp+0xE0], xmm15
00007871bd3d67d9  sub rsp, 0x30
00007871bd3d67dd  movaps [rsp], xmm6
00007871bd3d67e1  movaps [rsp+0x10], xmm9
00007871bd3d67e7  movaps [rsp+0x20], xmm14
00007871bd3d67ed  lea rdi, [rsp]
00007871bd3d67f1  mov esi, 0x00
00007871bd3d67f6  mov rax, 0x5BA2FDD2A530
00007871bd3d6800  call rax
00007871bd3d6802  movaps xmm6, [rsp]
00007871bd3d6806  add rsp, 0x30
00007871bd3d680a  vmovaps xmm0, [rsp]
00007871bd3d680f  vmovaps xmm1, [rsp+0x10]
00007871bd3d6815  vmovaps xmm2, [rsp+0x20]
00007871bd3d681b  vmovaps xmm3, [rsp+0x30]
00007871bd3d6821  vmovaps xmm4, [rsp+0x40]
00007871bd3d6827  vmovaps xmm5, [rsp+0x50]
00007871bd3d682d  vmovaps xmm7, [rsp+0x60]
00007871bd3d6833  vmovaps xmm8, [rsp+0x70]
00007871bd3d6839  vmovaps xmm9, [rsp+0x80]
00007871bd3d6842  vmovaps xmm10, [rsp+0x90]
00007871bd3d684b  vmovaps xmm11, [rsp+0xA0]
00007871bd3d6854  vmovaps xmm12, [rsp+0xB0]
00007871bd3d685d  vmovaps xmm13, [rsp+0xC0]
00007871bd3d6866  vmovaps xmm14, [rsp+0xD0]
00007871bd3d686f  vmovaps xmm15, [rsp+0xE0]
00007871bd3d6878  add rsp, 0xF0
00007871bd3d687f  pop r11
00007871bd3d6881  pop r10
00007871bd3d6883  pop r9
00007871bd3d6885  pop r8
00007871bd3d6887  pop rsi
00007871bd3d6888  pop rdi
00007871bd3d6889  pop rdx
00007871bd3d688a  pop rcx
00007871bd3d688b  pop rax
00007871bd3d688c  add rsp, 0x08
00007871bd3d6890  jmp 0x00007871BD3D3153
00007871bd3d6895  sub rsp, 0x08
00007871bd3d6899  push rax
00007871bd3d689a  push rcx
00007871bd3d689b  push rdx
00007871bd3d689c  push rdi
00007871bd3d689d  push rsi
00007871bd3d689e  push r8
00007871bd3d68a0  push r9
00007871bd3d68a2  push r10
00007871bd3d68a4  push r11
00007871bd3d68a6  sub rsp, 0xF0
00007871bd3d68ad  vmovaps [rsp], xmm0
00007871bd3d68b2  vmovaps [rsp+0x10], xmm1
00007871bd3d68b8  vmovaps [rsp+0x20], xmm2
00007871bd3d68be  vmovaps [rsp+0x30], xmm3
00007871bd3d68c4  vmovaps [rsp+0x40], xmm4
00007871bd3d68ca  vmovaps [rsp+0x50], xmm5
00007871bd3d68d0  vmovaps [rsp+0x60], xmm6
00007871bd3d68d6  vmovaps [rsp+0x70], xmm7
00007871bd3d68dc  vmovaps [rsp+0x80], xmm8
00007871bd3d68e5  vmovaps [rsp+0x90], xmm9
00007871bd3d68ee  vmovaps [rsp+0xA0], xmm10
00007871bd3d68f7  vmovaps [rsp+0xB0], xmm11
00007871bd3d6900  vmovaps [rsp+0xC0], xmm12
00007871bd3d6909  vmovaps [rsp+0xD0], xmm13
00007871bd3d6912  vmovaps [rsp+0xE0], xmm15
00007871bd3d691b  sub rsp, 0x30
00007871bd3d691f  movaps [rsp], xmm14
00007871bd3d6924  movaps [rsp+0x10], xmm9
00007871bd3d692a  movaps [rsp+0x20], xmm13
00007871bd3d6930  lea rdi, [rsp]
00007871bd3d6934  mov esi, 0x00
00007871bd3d6939  mov rax, 0x5BA2FDD2A530
00007871bd3d6943  call rax
00007871bd3d6945  movaps xmm14, [rsp]
00007871bd3d694a  add rsp, 0x30
00007871bd3d694e  vmovaps xmm0, [rsp]
00007871bd3d6953  vmovaps xmm1, [rsp+0x10]
00007871bd3d6959  vmovaps xmm2, [rsp+0x20]
00007871bd3d695f  vmovaps xmm3, [rsp+0x30]
00007871bd3d6965  vmovaps xmm4, [rsp+0x40]
00007871bd3d696b  vmovaps xmm5, [rsp+0x50]
00007871bd3d6971  vmovaps xmm6, [rsp+0x60]
00007871bd3d6977  vmovaps xmm7, [rsp+0x70]
00007871bd3d697d  vmovaps xmm8, [rsp+0x80]
00007871bd3d6986  vmovaps xmm9, [rsp+0x90]
00007871bd3d698f  vmovaps xmm10, [rsp+0xA0]
00007871bd3d6998  vmovaps xmm11, [rsp+0xB0]
00007871bd3d69a1  vmovaps xmm12, [rsp+0xC0]
00007871bd3d69aa  vmovaps xmm13, [rsp+0xD0]
00007871bd3d69b3  vmovaps xmm15, [rsp+0xE0]
00007871bd3d69bc  add rsp, 0xF0
00007871bd3d69c3  pop r11
00007871bd3d69c5  pop r10
00007871bd3d69c7  pop r9
00007871bd3d69c9  pop r8
00007871bd3d69cb  pop rsi
00007871bd3d69cc  pop rdi
00007871bd3d69cd  pop rdx
00007871bd3d69ce  pop rcx
00007871bd3d69cf  pop rax
00007871bd3d69d0  add rsp, 0x08
00007871bd3d69d4  jmp 0x00007871BD3D3176
00007871bd3d69d9  sub rsp, 0x08
00007871bd3d69dd  push rax
00007871bd3d69de  push rcx
00007871bd3d69df  push rdx
00007871bd3d69e0  push rdi
00007871bd3d69e1  push rsi
00007871bd3d69e2  push r8
00007871bd3d69e4  push r9
00007871bd3d69e6  push r10
00007871bd3d69e8  push r11
00007871bd3d69ea  sub rsp, 0xF0
00007871bd3d69f1  vmovaps [rsp], xmm0
00007871bd3d69f6  vmovaps [rsp+0x10], xmm1
00007871bd3d69fc  vmovaps [rsp+0x20], xmm2
00007871bd3d6a02  vmovaps [rsp+0x30], xmm3
00007871bd3d6a08  vmovaps [rsp+0x40], xmm4
00007871bd3d6a0e  vmovaps [rsp+0x50], xmm5
00007871bd3d6a14  vmovaps [rsp+0x60], xmm6
00007871bd3d6a1a  vmovaps [rsp+0x70], xmm7
00007871bd3d6a20  vmovaps [rsp+0x80], xmm8
00007871bd3d6a29  vmovaps [rsp+0x90], xmm9
00007871bd3d6a32  vmovaps [rsp+0xA0], xmm10
00007871bd3d6a3b  vmovaps [rsp+0xB0], xmm11
00007871bd3d6a44  vmovaps [rsp+0xC0], xmm12
00007871bd3d6a4d  vmovaps [rsp+0xD0], xmm14
00007871bd3d6a56  vmovaps [rsp+0xE0], xmm15
00007871bd3d6a5f  sub rsp, 0x30
00007871bd3d6a63  movaps [rsp], xmm13
00007871bd3d6a68  movaps [rsp+0x10], xmm9
00007871bd3d6a6e  movaps [rsp+0x20], xmm10
00007871bd3d6a74  lea rdi, [rsp]
00007871bd3d6a78  mov esi, 0x00
00007871bd3d6a7d  mov rax, 0x5BA2FDD2A530
00007871bd3d6a87  call rax
00007871bd3d6a89  movaps xmm13, [rsp]
00007871bd3d6a8e  add rsp, 0x30
00007871bd3d6a92  vmovaps xmm0, [rsp]
00007871bd3d6a97  vmovaps xmm1, [rsp+0x10]
00007871bd3d6a9d  vmovaps xmm2, [rsp+0x20]
00007871bd3d6aa3  vmovaps xmm3, [rsp+0x30]
00007871bd3d6aa9  vmovaps xmm4, [rsp+0x40]
00007871bd3d6aaf  vmovaps xmm5, [rsp+0x50]
00007871bd3d6ab5  vmovaps xmm6, [rsp+0x60]
00007871bd3d6abb  vmovaps xmm7, [rsp+0x70]
00007871bd3d6ac1  vmovaps xmm8, [rsp+0x80]
00007871bd3d6aca  vmovaps xmm9, [rsp+0x90]
00007871bd3d6ad3  vmovaps xmm10, [rsp+0xA0]
00007871bd3d6adc  vmovaps xmm11, [rsp+0xB0]
00007871bd3d6ae5  vmovaps xmm12, [rsp+0xC0]
00007871bd3d6aee  vmovaps xmm14, [rsp+0xD0]
00007871bd3d6af7  vmovaps xmm15, [rsp+0xE0]
00007871bd3d6b00  add rsp, 0xF0
00007871bd3d6b07  pop r11
00007871bd3d6b09  pop r10
00007871bd3d6b0b  pop r9
00007871bd3d6b0d  pop r8
00007871bd3d6b0f  pop rsi
00007871bd3d6b10  pop rdi
00007871bd3d6b11  pop rdx
00007871bd3d6b12  pop rcx
00007871bd3d6b13  pop rax
00007871bd3d6b14  add rsp, 0x08
00007871bd3d6b18  jmp 0x00007871BD3D3196
00007871bd3d6b1d  call 0x00007871BD20AFE0
00007871bd3d6b22  jmp 0x00007871BD3D31EB
00007871bd3d6b27  sub rsp, 0x08
00007871bd3d6b2b  push rax
00007871bd3d6b2c  push rcx
00007871bd3d6b2d  push rdx
00007871bd3d6b2e  push rdi
00007871bd3d6b2f  push rsi
00007871bd3d6b30  push r8
00007871bd3d6b32  push r9
00007871bd3d6b34  push r10
00007871bd3d6b36  push r11
00007871bd3d6b38  sub rsp, 0xF0
00007871bd3d6b3f  vmovaps [rsp], xmm0
00007871bd3d6b44  vmovaps [rsp+0x10], xmm1
00007871bd3d6b4a  vmovaps [rsp+0x20], xmm2
00007871bd3d6b50  vmovaps [rsp+0x30], xmm3
00007871bd3d6b56  vmovaps [rsp+0x40], xmm4
00007871bd3d6b5c  vmovaps [rsp+0x50], xmm5
00007871bd3d6b62  vmovaps [rsp+0x60], xmm6
00007871bd3d6b68  vmovaps [rsp+0x70], xmm7
00007871bd3d6b6e  vmovaps [rsp+0x80], xmm8
00007871bd3d6b77  vmovaps [rsp+0x90], xmm10
00007871bd3d6b80  vmovaps [rsp+0xA0], xmm11
00007871bd3d6b89  vmovaps [rsp+0xB0], xmm12
00007871bd3d6b92  vmovaps [rsp+0xC0], xmm13
00007871bd3d6b9b  vmovaps [rsp+0xD0], xmm14
00007871bd3d6ba4  vmovaps [rsp+0xE0], xmm15
00007871bd3d6bad  sub rsp, 0x30
00007871bd3d6bb1  movaps [rsp], xmm9
00007871bd3d6bb6  movaps [rsp+0x10], xmm8
00007871bd3d6bbc  movaps [rsp+0x20], xmm10
00007871bd3d6bc2  lea rdi, [rsp]
00007871bd3d6bc6  mov esi, 0x00
00007871bd3d6bcb  mov rax, 0x5BA2FDD2A530
00007871bd3d6bd5  call rax
00007871bd3d6bd7  movaps xmm9, [rsp]
00007871bd3d6bdc  add rsp, 0x30
00007871bd3d6be0  vmovaps xmm0, [rsp]
00007871bd3d6be5  vmovaps xmm1, [rsp+0x10]
00007871bd3d6beb  vmovaps xmm2, [rsp+0x20]
00007871bd3d6bf1  vmovaps xmm3, [rsp+0x30]
00007871bd3d6bf7  vmovaps xmm4, [rsp+0x40]
00007871bd3d6bfd  vmovaps xmm5, [rsp+0x50]
00007871bd3d6c03  vmovaps xmm6, [rsp+0x60]
00007871bd3d6c09  vmovaps xmm7, [rsp+0x70]
00007871bd3d6c0f  vmovaps xmm8, [rsp+0x80]
00007871bd3d6c18  vmovaps xmm10, [rsp+0x90]
00007871bd3d6c21  vmovaps xmm11, [rsp+0xA0]
00007871bd3d6c2a  vmovaps xmm12, [rsp+0xB0]
00007871bd3d6c33  vmovaps xmm13, [rsp+0xC0]
00007871bd3d6c3c  vmovaps xmm14, [rsp+0xD0]
00007871bd3d6c45  vmovaps xmm15, [rsp+0xE0]
00007871bd3d6c4e  add rsp, 0xF0
00007871bd3d6c55  pop r11
00007871bd3d6c57  pop r10
00007871bd3d6c59  pop r9
00007871bd3d6c5b  pop r8
00007871bd3d6c5d  pop rsi
00007871bd3d6c5e  pop rdi
00007871bd3d6c5f  pop rdx
00007871bd3d6c60  pop rcx
00007871bd3d6c61  pop rax
00007871bd3d6c62  add rsp, 0x08
00007871bd3d6c66  jmp 0x00007871BD3D321C
00007871bd3d6c6b  sub rsp, 0x08
00007871bd3d6c6f  push rax
00007871bd3d6c70  push rcx
00007871bd3d6c71  push rdx
00007871bd3d6c72  push rdi
00007871bd3d6c73  push rsi
00007871bd3d6c74  push r8
00007871bd3d6c76  push r9
00007871bd3d6c78  push r10
00007871bd3d6c7a  push r11
00007871bd3d6c7c  sub rsp, 0xF0
00007871bd3d6c83  vmovaps [rsp], xmm0
00007871bd3d6c88  vmovaps [rsp+0x10], xmm1
00007871bd3d6c8e  vmovaps [rsp+0x20], xmm2
00007871bd3d6c94  vmovaps [rsp+0x30], xmm3
00007871bd3d6c9a  vmovaps [rsp+0x40], xmm4
00007871bd3d6ca0  vmovaps [rsp+0x50], xmm5
00007871bd3d6ca6  vmovaps [rsp+0x60], xmm6
00007871bd3d6cac  vmovaps [rsp+0x70], xmm7
00007871bd3d6cb2  vmovaps [rsp+0x80], xmm8
00007871bd3d6cbb  vmovaps [rsp+0x90], xmm9
00007871bd3d6cc4  vmovaps [rsp+0xA0], xmm11
00007871bd3d6ccd  vmovaps [rsp+0xB0], xmm12
00007871bd3d6cd6  vmovaps [rsp+0xC0], xmm13
00007871bd3d6cdf  vmovaps [rsp+0xD0], xmm14
00007871bd3d6ce8  vmovaps [rsp+0xE0], xmm15
00007871bd3d6cf1  sub rsp, 0x30
00007871bd3d6cf5  movaps [rsp], xmm10
00007871bd3d6cfa  movaps [rsp+0x10], xmm1
00007871bd3d6cff  movaps [rsp+0x20], xmm11
00007871bd3d6d05  lea rdi, [rsp]
00007871bd3d6d09  mov esi, 0x00
00007871bd3d6d0e  mov rax, 0x5BA2FDD2A530
00007871bd3d6d18  call rax
00007871bd3d6d1a  movaps xmm10, [rsp]
00007871bd3d6d1f  add rsp, 0x30
00007871bd3d6d23  vmovaps xmm0, [rsp]
00007871bd3d6d28  vmovaps xmm1, [rsp+0x10]
00007871bd3d6d2e  vmovaps xmm2, [rsp+0x20]
00007871bd3d6d34  vmovaps xmm3, [rsp+0x30]
00007871bd3d6d3a  vmovaps xmm4, [rsp+0x40]
00007871bd3d6d40  vmovaps xmm5, [rsp+0x50]
00007871bd3d6d46  vmovaps xmm6, [rsp+0x60]
00007871bd3d6d4c  vmovaps xmm7, [rsp+0x70]
00007871bd3d6d52  vmovaps xmm8, [rsp+0x80]
00007871bd3d6d5b  vmovaps xmm9, [rsp+0x90]
00007871bd3d6d64  vmovaps xmm11, [rsp+0xA0]
00007871bd3d6d6d  vmovaps xmm12, [rsp+0xB0]
00007871bd3d6d76  vmovaps xmm13, [rsp+0xC0]
00007871bd3d6d7f  vmovaps xmm14, [rsp+0xD0]
00007871bd3d6d88  vmovaps xmm15, [rsp+0xE0]
00007871bd3d6d91  add rsp, 0xF0
00007871bd3d6d98  pop r11
00007871bd3d6d9a  pop r10
00007871bd3d6d9c  pop r9
00007871bd3d6d9e  pop r8
00007871bd3d6da0  pop rsi
00007871bd3d6da1  pop rdi
00007871bd3d6da2  pop rdx
00007871bd3d6da3  pop rcx
00007871bd3d6da4  pop rax
00007871bd3d6da5  add rsp, 0x08
00007871bd3d6da9  jmp 0x00007871BD3D3237
00007871bd3d6dae  sub rsp, 0x08
00007871bd3d6db2  push rax
00007871bd3d6db3  push rcx
00007871bd3d6db4  push rdx
00007871bd3d6db5  push rdi
00007871bd3d6db6  push rsi
00007871bd3d6db7  push r8
00007871bd3d6db9  push r9
00007871bd3d6dbb  push r10
00007871bd3d6dbd  push r11
00007871bd3d6dbf  sub rsp, 0xF0
00007871bd3d6dc6  vmovaps [rsp], xmm0
00007871bd3d6dcb  vmovaps [rsp+0x10], xmm2
00007871bd3d6dd1  vmovaps [rsp+0x20], xmm3
00007871bd3d6dd7  vmovaps [rsp+0x30], xmm4
00007871bd3d6ddd  vmovaps [rsp+0x40], xmm5
00007871bd3d6de3  vmovaps [rsp+0x50], xmm6
00007871bd3d6de9  vmovaps [rsp+0x60], xmm7
00007871bd3d6def  vmovaps [rsp+0x70], xmm8
00007871bd3d6df5  vmovaps [rsp+0x80], xmm9
00007871bd3d6dfe  vmovaps [rsp+0x90], xmm10
00007871bd3d6e07  vmovaps [rsp+0xA0], xmm11
00007871bd3d6e10  vmovaps [rsp+0xB0], xmm12
00007871bd3d6e19  vmovaps [rsp+0xC0], xmm13
00007871bd3d6e22  vmovaps [rsp+0xD0], xmm14
00007871bd3d6e2b  vmovaps [rsp+0xE0], xmm15
00007871bd3d6e34  sub rsp, 0x30
00007871bd3d6e38  movaps [rsp], xmm1
00007871bd3d6e3c  movaps [rsp+0x10], xmm15
00007871bd3d6e42  movaps [rsp+0x20], xmm6
00007871bd3d6e47  lea rdi, [rsp]
00007871bd3d6e4b  mov esi, 0x00
00007871bd3d6e50  mov rax, 0x5BA2FDD2A530
00007871bd3d6e5a  call rax
00007871bd3d6e5c  movaps xmm1, [rsp]
00007871bd3d6e60  add rsp, 0x30
00007871bd3d6e64  vmovaps xmm0, [rsp]
00007871bd3d6e69  vmovaps xmm2, [rsp+0x10]
00007871bd3d6e6f  vmovaps xmm3, [rsp+0x20]
00007871bd3d6e75  vmovaps xmm4, [rsp+0x30]
00007871bd3d6e7b  vmovaps xmm5, [rsp+0x40]
00007871bd3d6e81  vmovaps xmm6, [rsp+0x50]
00007871bd3d6e87  vmovaps xmm7, [rsp+0x60]
00007871bd3d6e8d  vmovaps xmm8, [rsp+0x70]
00007871bd3d6e93  vmovaps xmm9, [rsp+0x80]
00007871bd3d6e9c  vmovaps xmm10, [rsp+0x90]
00007871bd3d6ea5  vmovaps xmm11, [rsp+0xA0]
00007871bd3d6eae  vmovaps xmm12, [rsp+0xB0]
00007871bd3d6eb7  vmovaps xmm13, [rsp+0xC0]
00007871bd3d6ec0  vmovaps xmm14, [rsp+0xD0]
00007871bd3d6ec9  vmovaps xmm15, [rsp+0xE0]
00007871bd3d6ed2  add rsp, 0xF0
00007871bd3d6ed9  pop r11
00007871bd3d6edb  pop r10
00007871bd3d6edd  pop r9
00007871bd3d6edf  pop r8
00007871bd3d6ee1  pop rsi
00007871bd3d6ee2  pop rdi
00007871bd3d6ee3  pop rdx
00007871bd3d6ee4  pop rcx
00007871bd3d6ee5  pop rax
00007871bd3d6ee6  add rsp, 0x08
00007871bd3d6eea  jmp 0x00007871BD3D3250
00007871bd3d6eef  sub rsp, 0x08
00007871bd3d6ef3  push rax
00007871bd3d6ef4  push rcx
00007871bd3d6ef5  push rdx
00007871bd3d6ef6  push rdi
00007871bd3d6ef7  push rsi
00007871bd3d6ef8  push r8
00007871bd3d6efa  push r9
00007871bd3d6efc  push r10
00007871bd3d6efe  push r11
00007871bd3d6f00  sub rsp, 0xF0
00007871bd3d6f07  vmovaps [rsp], xmm0
00007871bd3d6f0c  vmovaps [rsp+0x10], xmm1
00007871bd3d6f12  vmovaps [rsp+0x20], xmm2
00007871bd3d6f18  vmovaps [rsp+0x30], xmm3
00007871bd3d6f1e  vmovaps [rsp+0x40], xmm4
00007871bd3d6f24  vmovaps [rsp+0x50], xmm5
00007871bd3d6f2a  vmovaps [rsp+0x60], xmm6
00007871bd3d6f30  vmovaps [rsp+0x70], xmm7
00007871bd3d6f36  vmovaps [rsp+0x80], xmm8
00007871bd3d6f3f  vmovaps [rsp+0x90], xmm9
00007871bd3d6f48  vmovaps [rsp+0xA0], xmm10
00007871bd3d6f51  vmovaps [rsp+0xB0], xmm12
00007871bd3d6f5a  vmovaps [rsp+0xC0], xmm13
00007871bd3d6f63  vmovaps [rsp+0xD0], xmm14
00007871bd3d6f6c  vmovaps [rsp+0xE0], xmm15
00007871bd3d6f75  sub rsp, 0x30
00007871bd3d6f79  movaps [rsp], xmm11
00007871bd3d6f7e  movaps [rsp+0x10], xmm12
00007871bd3d6f84  movaps [rsp+0x20], xmm15
00007871bd3d6f8a  lea rdi, [rsp]
00007871bd3d6f8e  mov esi, 0x00
00007871bd3d6f93  mov rax, 0x5BA2FDD2A530
00007871bd3d6f9d  call rax
00007871bd3d6f9f  movaps xmm11, [rsp]
00007871bd3d6fa4  add rsp, 0x30
00007871bd3d6fa8  vmovaps xmm0, [rsp]
00007871bd3d6fad  vmovaps xmm1, [rsp+0x10]
00007871bd3d6fb3  vmovaps xmm2, [rsp+0x20]
00007871bd3d6fb9  vmovaps xmm3, [rsp+0x30]
00007871bd3d6fbf  vmovaps xmm4, [rsp+0x40]
00007871bd3d6fc5  vmovaps xmm5, [rsp+0x50]
00007871bd3d6fcb  vmovaps xmm6, [rsp+0x60]
00007871bd3d6fd1  vmovaps xmm7, [rsp+0x70]
00007871bd3d6fd7  vmovaps xmm8, [rsp+0x80]
00007871bd3d6fe0  vmovaps xmm9, [rsp+0x90]
00007871bd3d6fe9  vmovaps xmm10, [rsp+0xA0]
00007871bd3d6ff2  vmovaps xmm12, [rsp+0xB0]
00007871bd3d6ffb  vmovaps xmm13, [rsp+0xC0]
00007871bd3d7004  vmovaps xmm14, [rsp+0xD0]
00007871bd3d700d  vmovaps xmm15, [rsp+0xE0]
00007871bd3d7016  add rsp, 0xF0
00007871bd3d701d  pop r11
00007871bd3d701f  pop r10
00007871bd3d7021  pop r9
00007871bd3d7023  pop r8
00007871bd3d7025  pop rsi
00007871bd3d7026  pop rdi
00007871bd3d7027  pop rdx
00007871bd3d7028  pop rcx
00007871bd3d7029  pop rax
00007871bd3d702a  add rsp, 0x08
00007871bd3d702e  jmp 0x00007871BD3D327A
00007871bd3d7033  sub rsp, 0x08
00007871bd3d7037  push rax
00007871bd3d7038  push rcx
00007871bd3d7039  push rdx
00007871bd3d703a  push rdi
00007871bd3d703b  push rsi
00007871bd3d703c  push r8
00007871bd3d703e  push r9
00007871bd3d7040  push r10
00007871bd3d7042  push r11
00007871bd3d7044  sub rsp, 0xF0
00007871bd3d704b  vmovaps [rsp], xmm0
00007871bd3d7050  vmovaps [rsp+0x10], xmm1
00007871bd3d7056  vmovaps [rsp+0x20], xmm2
00007871bd3d705c  vmovaps [rsp+0x30], xmm3
00007871bd3d7062  vmovaps [rsp+0x40], xmm4
00007871bd3d7068  vmovaps [rsp+0x50], xmm5
00007871bd3d706e  vmovaps [rsp+0x60], xmm6
00007871bd3d7074  vmovaps [rsp+0x70], xmm7
00007871bd3d707a  vmovaps [rsp+0x80], xmm8
00007871bd3d7083  vmovaps [rsp+0x90], xmm9
00007871bd3d708c  vmovaps [rsp+0xA0], xmm10
00007871bd3d7095  vmovaps [rsp+0xB0], xmm11
00007871bd3d709e  vmovaps [rsp+0xC0], xmm13
00007871bd3d70a7  vmovaps [rsp+0xD0], xmm14
00007871bd3d70b0  vmovaps [rsp+0xE0], xmm15
00007871bd3d70b9  sub rsp, 0x30
00007871bd3d70bd  movaps [rsp], xmm12
00007871bd3d70c2  movaps [rsp+0x10], xmm8
00007871bd3d70c8  movaps [rsp+0x20], xmm15
00007871bd3d70ce  lea rdi, [rsp]
00007871bd3d70d2  mov esi, 0x00
00007871bd3d70d7  mov rax, 0x5BA2FDD2A530
00007871bd3d70e1  call rax
00007871bd3d70e3  movaps xmm12, [rsp]
00007871bd3d70e8  add rsp, 0x30
00007871bd3d70ec  vmovaps xmm0, [rsp]
00007871bd3d70f1  vmovaps xmm1, [rsp+0x10]
00007871bd3d70f7  vmovaps xmm2, [rsp+0x20]
00007871bd3d70fd  vmovaps xmm3, [rsp+0x30]
00007871bd3d7103  vmovaps xmm4, [rsp+0x40]
00007871bd3d7109  vmovaps xmm5, [rsp+0x50]
00007871bd3d710f  vmovaps xmm6, [rsp+0x60]
00007871bd3d7115  vmovaps xmm7, [rsp+0x70]
00007871bd3d711b  vmovaps xmm8, [rsp+0x80]
00007871bd3d7124  vmovaps xmm9, [rsp+0x90]
00007871bd3d712d  vmovaps xmm10, [rsp+0xA0]
00007871bd3d7136  vmovaps xmm11, [rsp+0xB0]
00007871bd3d713f  vmovaps xmm13, [rsp+0xC0]
00007871bd3d7148  vmovaps xmm14, [rsp+0xD0]
00007871bd3d7151  vmovaps xmm15, [rsp+0xE0]
00007871bd3d715a  add rsp, 0xF0
00007871bd3d7161  pop r11
00007871bd3d7163  pop r10
00007871bd3d7165  pop r9
00007871bd3d7167  pop r8
00007871bd3d7169  pop rsi
00007871bd3d716a  pop rdi
00007871bd3d716b  pop rdx
00007871bd3d716c  pop rcx
00007871bd3d716d  pop rax
00007871bd3d716e  add rsp, 0x08
00007871bd3d7172  jmp 0x00007871BD3D32A9
00007871bd3d7177  sub rsp, 0x08
00007871bd3d717b  push rax
00007871bd3d717c  push rcx
00007871bd3d717d  push rdx
00007871bd3d717e  push rdi
00007871bd3d717f  push rsi
00007871bd3d7180  push r8
00007871bd3d7182  push r9
00007871bd3d7184  push r10
00007871bd3d7186  push r11
00007871bd3d7188  sub rsp, 0xF0
00007871bd3d718f  vmovaps [rsp], xmm0
00007871bd3d7194  vmovaps [rsp+0x10], xmm1
00007871bd3d719a  vmovaps [rsp+0x20], xmm2
00007871bd3d71a0  vmovaps [rsp+0x30], xmm3
00007871bd3d71a6  vmovaps [rsp+0x40], xmm4
00007871bd3d71ac  vmovaps [rsp+0x50], xmm5
00007871bd3d71b2  vmovaps [rsp+0x60], xmm6
00007871bd3d71b8  vmovaps [rsp+0x70], xmm7
00007871bd3d71be  vmovaps [rsp+0x80], xmm9
00007871bd3d71c7  vmovaps [rsp+0x90], xmm10
00007871bd3d71d0  vmovaps [rsp+0xA0], xmm11
00007871bd3d71d9  vmovaps [rsp+0xB0], xmm12
00007871bd3d71e2  vmovaps [rsp+0xC0], xmm13
00007871bd3d71eb  vmovaps [rsp+0xD0], xmm14
00007871bd3d71f4  vmovaps [rsp+0xE0], xmm15
00007871bd3d71fd  sub rsp, 0x30
00007871bd3d7201  movaps [rsp], xmm8
00007871bd3d7206  movaps [rsp+0x10], xmm7
00007871bd3d720b  movaps [rsp+0x20], xmm15
00007871bd3d7211  lea rdi, [rsp]
00007871bd3d7215  mov esi, 0x00
00007871bd3d721a  mov rax, 0x5BA2FDD2A530
00007871bd3d7224  call rax
00007871bd3d7226  movaps xmm8, [rsp]
00007871bd3d722b  add rsp, 0x30
00007871bd3d722f  vmovaps xmm0, [rsp]
00007871bd3d7234  vmovaps xmm1, [rsp+0x10]
00007871bd3d723a  vmovaps xmm2, [rsp+0x20]
00007871bd3d7240  vmovaps xmm3, [rsp+0x30]
00007871bd3d7246  vmovaps xmm4, [rsp+0x40]
00007871bd3d724c  vmovaps xmm5, [rsp+0x50]
00007871bd3d7252  vmovaps xmm6, [rsp+0x60]
00007871bd3d7258  vmovaps xmm7, [rsp+0x70]
00007871bd3d725e  vmovaps xmm9, [rsp+0x80]
00007871bd3d7267  vmovaps xmm10, [rsp+0x90]
00007871bd3d7270  vmovaps xmm11, [rsp+0xA0]
00007871bd3d7279  vmovaps xmm12, [rsp+0xB0]
00007871bd3d7282  vmovaps xmm13, [rsp+0xC0]
00007871bd3d728b  vmovaps xmm14, [rsp+0xD0]
00007871bd3d7294  vmovaps xmm15, [rsp+0xE0]
00007871bd3d729d  add rsp, 0xF0
00007871bd3d72a4  pop r11
00007871bd3d72a6  pop r10
00007871bd3d72a8  pop r9
00007871bd3d72aa  pop r8
00007871bd3d72ac  pop rsi
00007871bd3d72ad  pop rdi
00007871bd3d72ae  pop rdx
00007871bd3d72af  pop rcx
00007871bd3d72b0  pop rax
00007871bd3d72b1  add rsp, 0x08
00007871bd3d72b5  jmp 0x00007871BD3D32CF
00007871bd3d72ba  sub rsp, 0x08
00007871bd3d72be  push rax
00007871bd3d72bf  push rcx
00007871bd3d72c0  push rdx
00007871bd3d72c1  push rdi
00007871bd3d72c2  push rsi
00007871bd3d72c3  push r8
00007871bd3d72c5  push r9
00007871bd3d72c7  push r10
00007871bd3d72c9  push r11
00007871bd3d72cb  sub rsp, 0xF0
00007871bd3d72d2  vmovaps [rsp], xmm0
00007871bd3d72d7  vmovaps [rsp+0x10], xmm1
00007871bd3d72dd  vmovaps [rsp+0x20], xmm2
00007871bd3d72e3  vmovaps [rsp+0x30], xmm3
00007871bd3d72e9  vmovaps [rsp+0x40], xmm4
00007871bd3d72ef  vmovaps [rsp+0x50], xmm5
00007871bd3d72f5  vmovaps [rsp+0x60], xmm6
00007871bd3d72fb  vmovaps [rsp+0x70], xmm7
00007871bd3d7301  vmovaps [rsp+0x80], xmm8
00007871bd3d730a  vmovaps [rsp+0x90], xmm9
00007871bd3d7313  vmovaps [rsp+0xA0], xmm10
00007871bd3d731c  vmovaps [rsp+0xB0], xmm11
00007871bd3d7325  vmovaps [rsp+0xC0], xmm12
00007871bd3d732e  vmovaps [rsp+0xD0], xmm13
00007871bd3d7337  vmovaps [rsp+0xE0], xmm14
00007871bd3d7340  sub rsp, 0x30
00007871bd3d7344  movaps [rsp], xmm15
00007871bd3d7349  movaps [rsp+0x10], xmm14
00007871bd3d734f  movaps [rsp+0x20], xmm9
00007871bd3d7355  lea rdi, [rsp]
00007871bd3d7359  mov esi, 0x00
00007871bd3d735e  mov rax, 0x5BA2FDD2A530
00007871bd3d7368  call rax
00007871bd3d736a  movaps xmm15, [rsp]
00007871bd3d736f  add rsp, 0x30
00007871bd3d7373  vmovaps xmm0, [rsp]
00007871bd3d7378  vmovaps xmm1, [rsp+0x10]
00007871bd3d737e  vmovaps xmm2, [rsp+0x20]
00007871bd3d7384  vmovaps xmm3, [rsp+0x30]
00007871bd3d738a  vmovaps xmm4, [rsp+0x40]
00007871bd3d7390  vmovaps xmm5, [rsp+0x50]
00007871bd3d7396  vmovaps xmm6, [rsp+0x60]
00007871bd3d739c  vmovaps xmm7, [rsp+0x70]
00007871bd3d73a2  vmovaps xmm8, [rsp+0x80]
00007871bd3d73ab  vmovaps xmm9, [rsp+0x90]
00007871bd3d73b4  vmovaps xmm10, [rsp+0xA0]
00007871bd3d73bd  vmovaps xmm11, [rsp+0xB0]
00007871bd3d73c6  vmovaps xmm12, [rsp+0xC0]
00007871bd3d73cf  vmovaps xmm13, [rsp+0xD0]
00007871bd3d73d8  vmovaps xmm14, [rsp+0xE0]
00007871bd3d73e1  add rsp, 0xF0
00007871bd3d73e8  pop r11
00007871bd3d73ea  pop r10
00007871bd3d73ec  pop r9
00007871bd3d73ee  pop r8
00007871bd3d73f0  pop rsi
00007871bd3d73f1  pop rdi
00007871bd3d73f2  pop rdx
00007871bd3d73f3  pop rcx
00007871bd3d73f4  pop rax
00007871bd3d73f5  add rsp, 0x08
00007871bd3d73f9  jmp 0x00007871BD3D32E9
00007871bd3d73fe  sub rsp, 0x08
00007871bd3d7402  push rax
00007871bd3d7403  push rcx
00007871bd3d7404  push rdx
00007871bd3d7405  push rdi
00007871bd3d7406  push rsi
00007871bd3d7407  push r8
00007871bd3d7409  push r9
00007871bd3d740b  push r10
00007871bd3d740d  push r11
00007871bd3d740f  sub rsp, 0xF0
00007871bd3d7416  vmovaps [rsp], xmm0
00007871bd3d741b  vmovaps [rsp+0x10], xmm1
00007871bd3d7421  vmovaps [rsp+0x20], xmm2
00007871bd3d7427  vmovaps [rsp+0x30], xmm3
00007871bd3d742d  vmovaps [rsp+0x40], xmm4
00007871bd3d7433  vmovaps [rsp+0x50], xmm5
00007871bd3d7439  vmovaps [rsp+0x60], xmm6
00007871bd3d743f  vmovaps [rsp+0x70], xmm7
00007871bd3d7445  vmovaps [rsp+0x80], xmm8
00007871bd3d744e  vmovaps [rsp+0x90], xmm10
00007871bd3d7457  vmovaps [rsp+0xA0], xmm11
00007871bd3d7460  vmovaps [rsp+0xB0], xmm12
00007871bd3d7469  vmovaps [rsp+0xC0], xmm13
00007871bd3d7472  vmovaps [rsp+0xD0], xmm14
00007871bd3d747b  vmovaps [rsp+0xE0], xmm15
00007871bd3d7484  sub rsp, 0x30
00007871bd3d7488  movaps [rsp], xmm9
00007871bd3d748d  movaps [rsp+0x10], xmm7
00007871bd3d7492  movaps [rsp+0x20], xmm14
00007871bd3d7498  lea rdi, [rsp]
00007871bd3d749c  mov esi, 0x00
00007871bd3d74a1  mov rax, 0x5BA2FDD2A530
00007871bd3d74ab  call rax
00007871bd3d74ad  movaps xmm9, [rsp]
00007871bd3d74b2  add rsp, 0x30
00007871bd3d74b6  vmovaps xmm0, [rsp]
00007871bd3d74bb  vmovaps xmm1, [rsp+0x10]
00007871bd3d74c1  vmovaps xmm2, [rsp+0x20]
00007871bd3d74c7  vmovaps xmm3, [rsp+0x30]
00007871bd3d74cd  vmovaps xmm4, [rsp+0x40]
00007871bd3d74d3  vmovaps xmm5, [rsp+0x50]
00007871bd3d74d9  vmovaps xmm6, [rsp+0x60]
00007871bd3d74df  vmovaps xmm7, [rsp+0x70]
00007871bd3d74e5  vmovaps xmm8, [rsp+0x80]
00007871bd3d74ee  vmovaps xmm10, [rsp+0x90]
00007871bd3d74f7  vmovaps xmm11, [rsp+0xA0]
00007871bd3d7500  vmovaps xmm12, [rsp+0xB0]
00007871bd3d7509  vmovaps xmm13, [rsp+0xC0]
00007871bd3d7512  vmovaps xmm14, [rsp+0xD0]
00007871bd3d751b  vmovaps xmm15, [rsp+0xE0]
00007871bd3d7524  add rsp, 0xF0
00007871bd3d752b  pop r11
00007871bd3d752d  pop r10
00007871bd3d752f  pop r9
00007871bd3d7531  pop r8
00007871bd3d7533  pop rsi
00007871bd3d7534  pop rdi
00007871bd3d7535  pop rdx
00007871bd3d7536  pop rcx
00007871bd3d7537  pop rax
00007871bd3d7538  add rsp, 0x08
00007871bd3d753c  jmp 0x00007871BD3D3318
00007871bd3d7541  sub rsp, 0x08
00007871bd3d7545  push rax
00007871bd3d7546  push rcx
00007871bd3d7547  push rdx
00007871bd3d7548  push rdi
00007871bd3d7549  push rsi
00007871bd3d754a  push r8
00007871bd3d754c  push r9
00007871bd3d754e  push r10
00007871bd3d7550  push r11
00007871bd3d7552  sub rsp, 0xF0
00007871bd3d7559  vmovaps [rsp], xmm0
00007871bd3d755e  vmovaps [rsp+0x10], xmm1
00007871bd3d7564  vmovaps [rsp+0x20], xmm2
00007871bd3d756a  vmovaps [rsp+0x30], xmm3
00007871bd3d7570  vmovaps [rsp+0x40], xmm4
00007871bd3d7576  vmovaps [rsp+0x50], xmm5
00007871bd3d757c  vmovaps [rsp+0x60], xmm6
00007871bd3d7582  vmovaps [rsp+0x70], xmm7
00007871bd3d7588  vmovaps [rsp+0x80], xmm8
00007871bd3d7591  vmovaps [rsp+0x90], xmm9
00007871bd3d759a  vmovaps [rsp+0xA0], xmm10
00007871bd3d75a3  vmovaps [rsp+0xB0], xmm11
00007871bd3d75ac  vmovaps [rsp+0xC0], xmm12
00007871bd3d75b5  vmovaps [rsp+0xD0], xmm13
00007871bd3d75be  vmovaps [rsp+0xE0], xmm15
00007871bd3d75c7  sub rsp, 0x30
00007871bd3d75cb  movaps [rsp], xmm14
00007871bd3d75d0  movaps [rsp+0x10], xmm13
00007871bd3d75d6  movaps [rsp+0x20], xmm11
00007871bd3d75dc  lea rdi, [rsp]
00007871bd3d75e0  mov esi, 0x00
00007871bd3d75e5  mov rax, 0x5BA2FDD2A530
00007871bd3d75ef  call rax
00007871bd3d75f1  movaps xmm14, [rsp]
00007871bd3d75f6  add rsp, 0x30
00007871bd3d75fa  vmovaps xmm0, [rsp]
00007871bd3d75ff  vmovaps xmm1, [rsp+0x10]
00007871bd3d7605  vmovaps xmm2, [rsp+0x20]
00007871bd3d760b  vmovaps xmm3, [rsp+0x30]
00007871bd3d7611  vmovaps xmm4, [rsp+0x40]
00007871bd3d7617  vmovaps xmm5, [rsp+0x50]
00007871bd3d761d  vmovaps xmm6, [rsp+0x60]
00007871bd3d7623  vmovaps xmm7, [rsp+0x70]
00007871bd3d7629  vmovaps xmm8, [rsp+0x80]
00007871bd3d7632  vmovaps xmm9, [rsp+0x90]
00007871bd3d763b  vmovaps xmm10, [rsp+0xA0]
00007871bd3d7644  vmovaps xmm11, [rsp+0xB0]
00007871bd3d764d  vmovaps xmm12, [rsp+0xC0]
00007871bd3d7656  vmovaps xmm13, [rsp+0xD0]
00007871bd3d765f  vmovaps xmm15, [rsp+0xE0]
00007871bd3d7668  add rsp, 0xF0
00007871bd3d766f  pop r11
00007871bd3d7671  pop r10
00007871bd3d7673  pop r9
00007871bd3d7675  pop r8
00007871bd3d7677  pop rsi
00007871bd3d7678  pop rdi
00007871bd3d7679  pop rdx
00007871bd3d767a  pop rcx
00007871bd3d767b  pop rax
00007871bd3d767c  add rsp, 0x08
00007871bd3d7680  jmp 0x00007871BD3D3332
00007871bd3d7685  sub rsp, 0x08
00007871bd3d7689  push rax
00007871bd3d768a  push rcx
00007871bd3d768b  push rdx
00007871bd3d768c  push rdi
00007871bd3d768d  push rsi
00007871bd3d768e  push r8
00007871bd3d7690  push r9
00007871bd3d7692  push r10
00007871bd3d7694  push r11
00007871bd3d7696  sub rsp, 0xF0
00007871bd3d769d  vmovaps [rsp], xmm0
00007871bd3d76a2  vmovaps [rsp+0x10], xmm1
00007871bd3d76a8  vmovaps [rsp+0x20], xmm2
00007871bd3d76ae  vmovaps [rsp+0x30], xmm3
00007871bd3d76b4  vmovaps [rsp+0x40], xmm4
00007871bd3d76ba  vmovaps [rsp+0x50], xmm5
00007871bd3d76c0  vmovaps [rsp+0x60], xmm6
00007871bd3d76c6  vmovaps [rsp+0x70], xmm7
00007871bd3d76cc  vmovaps [rsp+0x80], xmm8
00007871bd3d76d5  vmovaps [rsp+0x90], xmm9
00007871bd3d76de  vmovaps [rsp+0xA0], xmm10
00007871bd3d76e7  vmovaps [rsp+0xB0], xmm12
00007871bd3d76f0  vmovaps [rsp+0xC0], xmm13
00007871bd3d76f9  vmovaps [rsp+0xD0], xmm14
00007871bd3d7702  vmovaps [rsp+0xE0], xmm15
00007871bd3d770b  sub rsp, 0x30
00007871bd3d770f  movaps [rsp], xmm11
00007871bd3d7714  movaps [rsp+0x10], xmm7
00007871bd3d7719  movaps [rsp+0x20], xmm13
00007871bd3d771f  lea rdi, [rsp]
00007871bd3d7723  mov esi, 0x00
00007871bd3d7728  mov rax, 0x5BA2FDD2A530
00007871bd3d7732  call rax
00007871bd3d7734  movaps xmm11, [rsp]
00007871bd3d7739  add rsp, 0x30
00007871bd3d773d  vmovaps xmm0, [rsp]
00007871bd3d7742  vmovaps xmm1, [rsp+0x10]
00007871bd3d7748  vmovaps xmm2, [rsp+0x20]
00007871bd3d774e  vmovaps xmm3, [rsp+0x30]
00007871bd3d7754  vmovaps xmm4, [rsp+0x40]
00007871bd3d775a  vmovaps xmm5, [rsp+0x50]
00007871bd3d7760  vmovaps xmm6, [rsp+0x60]
00007871bd3d7766  vmovaps xmm7, [rsp+0x70]
00007871bd3d776c  vmovaps xmm8, [rsp+0x80]
00007871bd3d7775  vmovaps xmm9, [rsp+0x90]
00007871bd3d777e  vmovaps xmm10, [rsp+0xA0]
00007871bd3d7787  vmovaps xmm12, [rsp+0xB0]
00007871bd3d7790  vmovaps xmm13, [rsp+0xC0]
00007871bd3d7799  vmovaps xmm14, [rsp+0xD0]
00007871bd3d77a2  vmovaps xmm15, [rsp+0xE0]
00007871bd3d77ab  add rsp, 0xF0
00007871bd3d77b2  pop r11
00007871bd3d77b4  pop r10
00007871bd3d77b6  pop r9
00007871bd3d77b8  pop r8
00007871bd3d77ba  pop rsi
00007871bd3d77bb  pop rdi
00007871bd3d77bc  pop rdx
00007871bd3d77bd  pop rcx
00007871bd3d77be  pop rax
00007871bd3d77bf  add rsp, 0x08
00007871bd3d77c3  jmp 0x00007871BD3D335E
00007871bd3d77c8  sub rsp, 0x08
00007871bd3d77cc  push rax
00007871bd3d77cd  push rcx
00007871bd3d77ce  push rdx
00007871bd3d77cf  push rdi
00007871bd3d77d0  push rsi
00007871bd3d77d1  push r8
00007871bd3d77d3  push r9
00007871bd3d77d5  push r10
00007871bd3d77d7  push r11
00007871bd3d77d9  sub rsp, 0xF0
00007871bd3d77e0  vmovaps [rsp], xmm0
00007871bd3d77e5  vmovaps [rsp+0x10], xmm1
00007871bd3d77eb  vmovaps [rsp+0x20], xmm2
00007871bd3d77f1  vmovaps [rsp+0x30], xmm3
00007871bd3d77f7  vmovaps [rsp+0x40], xmm4
00007871bd3d77fd  vmovaps [rsp+0x50], xmm5
00007871bd3d7803  vmovaps [rsp+0x60], xmm6
00007871bd3d7809  vmovaps [rsp+0x70], xmm7
00007871bd3d780f  vmovaps [rsp+0x80], xmm8
00007871bd3d7818  vmovaps [rsp+0x90], xmm9
00007871bd3d7821  vmovaps [rsp+0xA0], xmm10
00007871bd3d782a  vmovaps [rsp+0xB0], xmm11
00007871bd3d7833  vmovaps [rsp+0xC0], xmm12
00007871bd3d783c  vmovaps [rsp+0xD0], xmm14
00007871bd3d7845  vmovaps [rsp+0xE0], xmm15
00007871bd3d784e  sub rsp, 0x30
00007871bd3d7852  movaps [rsp], xmm13
00007871bd3d7857  movaps [rsp+0x10], xmm10
00007871bd3d785d  movaps [rsp+0x20], xmm12
00007871bd3d7863  lea rdi, [rsp]
00007871bd3d7867  mov esi, 0x00
00007871bd3d786c  mov rax, 0x5BA2FDD2A530
00007871bd3d7876  call rax
00007871bd3d7878  movaps xmm13, [rsp]
00007871bd3d787d  add rsp, 0x30
00007871bd3d7881  vmovaps xmm0, [rsp]
00007871bd3d7886  vmovaps xmm1, [rsp+0x10]
00007871bd3d788c  vmovaps xmm2, [rsp+0x20]
00007871bd3d7892  vmovaps xmm3, [rsp+0x30]
00007871bd3d7898  vmovaps xmm4, [rsp+0x40]
00007871bd3d789e  vmovaps xmm5, [rsp+0x50]
00007871bd3d78a4  vmovaps xmm6, [rsp+0x60]
00007871bd3d78aa  vmovaps xmm7, [rsp+0x70]
00007871bd3d78b0  vmovaps xmm8, [rsp+0x80]
00007871bd3d78b9  vmovaps xmm9, [rsp+0x90]
00007871bd3d78c2  vmovaps xmm10, [rsp+0xA0]
00007871bd3d78cb  vmovaps xmm11, [rsp+0xB0]
00007871bd3d78d4  vmovaps xmm12, [rsp+0xC0]
00007871bd3d78dd  vmovaps xmm14, [rsp+0xD0]
00007871bd3d78e6  vmovaps xmm15, [rsp+0xE0]
00007871bd3d78ef  add rsp, 0xF0
00007871bd3d78f6  pop r11
00007871bd3d78f8  pop r10
00007871bd3d78fa  pop r9
00007871bd3d78fc  pop r8
00007871bd3d78fe  pop rsi
00007871bd3d78ff  pop rdi
00007871bd3d7900  pop rdx
00007871bd3d7901  pop rcx
00007871bd3d7902  pop rax
00007871bd3d7903  add rsp, 0x08
00007871bd3d7907  jmp 0x00007871BD3D3378
00007871bd3d790c  sub rsp, 0x08
00007871bd3d7910  push rax
00007871bd3d7911  push rcx
00007871bd3d7912  push rdx
00007871bd3d7913  push rdi
00007871bd3d7914  push rsi
00007871bd3d7915  push r8
00007871bd3d7917  push r9
00007871bd3d7919  push r10
00007871bd3d791b  push r11
00007871bd3d791d  sub rsp, 0xF0
00007871bd3d7924  vmovaps [rsp], xmm0
00007871bd3d7929  vmovaps [rsp+0x10], xmm1
00007871bd3d792f  vmovaps [rsp+0x20], xmm2
00007871bd3d7935  vmovaps [rsp+0x30], xmm3
00007871bd3d793b  vmovaps [rsp+0x40], xmm4
00007871bd3d7941  vmovaps [rsp+0x50], xmm5
00007871bd3d7947  vmovaps [rsp+0x60], xmm6
00007871bd3d794d  vmovaps [rsp+0x70], xmm7
00007871bd3d7953  vmovaps [rsp+0x80], xmm8
00007871bd3d795c  vmovaps [rsp+0x90], xmm9
00007871bd3d7965  vmovaps [rsp+0xA0], xmm11
00007871bd3d796e  vmovaps [rsp+0xB0], xmm12
00007871bd3d7977  vmovaps [rsp+0xC0], xmm13
00007871bd3d7980  vmovaps [rsp+0xD0], xmm14
00007871bd3d7989  vmovaps [rsp+0xE0], xmm15
00007871bd3d7992  sub rsp, 0x30
00007871bd3d7996  movaps [rsp], xmm10
00007871bd3d799b  movaps [rsp+0x10], xmm7
00007871bd3d79a0  movaps [rsp+0x20], xmm12
00007871bd3d79a6  lea rdi, [rsp]
00007871bd3d79aa  mov esi, 0x00
00007871bd3d79af  mov rax, 0x5BA2FDD2A530
00007871bd3d79b9  call rax
00007871bd3d79bb  movaps xmm10, [rsp]
00007871bd3d79c0  add rsp, 0x30
00007871bd3d79c4  vmovaps xmm0, [rsp]
00007871bd3d79c9  vmovaps xmm1, [rsp+0x10]
00007871bd3d79cf  vmovaps xmm2, [rsp+0x20]
00007871bd3d79d5  vmovaps xmm3, [rsp+0x30]
00007871bd3d79db  vmovaps xmm4, [rsp+0x40]
00007871bd3d79e1  vmovaps xmm5, [rsp+0x50]
00007871bd3d79e7  vmovaps xmm6, [rsp+0x60]
00007871bd3d79ed  vmovaps xmm7, [rsp+0x70]
00007871bd3d79f3  vmovaps xmm8, [rsp+0x80]
00007871bd3d79fc  vmovaps xmm9, [rsp+0x90]
00007871bd3d7a05  vmovaps xmm11, [rsp+0xA0]
00007871bd3d7a0e  vmovaps xmm12, [rsp+0xB0]
00007871bd3d7a17  vmovaps xmm13, [rsp+0xC0]
00007871bd3d7a20  vmovaps xmm14, [rsp+0xD0]
00007871bd3d7a29  vmovaps xmm15, [rsp+0xE0]
00007871bd3d7a32  add rsp, 0xF0
00007871bd3d7a39  pop r11
00007871bd3d7a3b  pop r10
00007871bd3d7a3d  pop r9
00007871bd3d7a3f  pop r8
00007871bd3d7a41  pop rsi
00007871bd3d7a42  pop rdi
00007871bd3d7a43  pop rdx
00007871bd3d7a44  pop rcx
00007871bd3d7a45  pop rax
00007871bd3d7a46  add rsp, 0x08
00007871bd3d7a4a  jmp 0x00007871BD3D33A4
00007871bd3d7a4f  sub rsp, 0x08
00007871bd3d7a53  push rax
00007871bd3d7a54  push rcx
00007871bd3d7a55  push rdx
00007871bd3d7a56  push rdi
00007871bd3d7a57  push rsi
00007871bd3d7a58  push r8
00007871bd3d7a5a  push r9
00007871bd3d7a5c  push r10
00007871bd3d7a5e  push r11
00007871bd3d7a60  sub rsp, 0xF0
00007871bd3d7a67  vmovaps [rsp], xmm0
00007871bd3d7a6c  vmovaps [rsp+0x10], xmm1
00007871bd3d7a72  vmovaps [rsp+0x20], xmm2
00007871bd3d7a78  vmovaps [rsp+0x30], xmm3
00007871bd3d7a7e  vmovaps [rsp+0x40], xmm4
00007871bd3d7a84  vmovaps [rsp+0x50], xmm5
00007871bd3d7a8a  vmovaps [rsp+0x60], xmm6
00007871bd3d7a90  vmovaps [rsp+0x70], xmm7
00007871bd3d7a96  vmovaps [rsp+0x80], xmm8
00007871bd3d7a9f  vmovaps [rsp+0x90], xmm9
00007871bd3d7aa8  vmovaps [rsp+0xA0], xmm10
00007871bd3d7ab1  vmovaps [rsp+0xB0], xmm11
00007871bd3d7aba  vmovaps [rsp+0xC0], xmm13
00007871bd3d7ac3  vmovaps [rsp+0xD0], xmm14
00007871bd3d7acc  vmovaps [rsp+0xE0], xmm15
00007871bd3d7ad5  sub rsp, 0x30
00007871bd3d7ad9  movaps [rsp], xmm12
00007871bd3d7ade  movaps [rsp+0x10], xmm1
00007871bd3d7ae3  movaps [rsp+0x20], xmm8
00007871bd3d7ae9  lea rdi, [rsp]
00007871bd3d7aed  mov esi, 0x00
00007871bd3d7af2  mov rax, 0x5BA2FDD2A530
00007871bd3d7afc  call rax
00007871bd3d7afe  movaps xmm12, [rsp]
00007871bd3d7b03  add rsp, 0x30
00007871bd3d7b07  vmovaps xmm0, [rsp]
00007871bd3d7b0c  vmovaps xmm1, [rsp+0x10]
00007871bd3d7b12  vmovaps xmm2, [rsp+0x20]
00007871bd3d7b18  vmovaps xmm3, [rsp+0x30]
00007871bd3d7b1e  vmovaps xmm4, [rsp+0x40]
00007871bd3d7b24  vmovaps xmm5, [rsp+0x50]
00007871bd3d7b2a  vmovaps xmm6, [rsp+0x60]
00007871bd3d7b30  vmovaps xmm7, [rsp+0x70]
00007871bd3d7b36  vmovaps xmm8, [rsp+0x80]
00007871bd3d7b3f  vmovaps xmm9, [rsp+0x90]
00007871bd3d7b48  vmovaps xmm10, [rsp+0xA0]
00007871bd3d7b51  vmovaps xmm11, [rsp+0xB0]
00007871bd3d7b5a  vmovaps xmm13, [rsp+0xC0]
00007871bd3d7b63  vmovaps xmm14, [rsp+0xD0]
00007871bd3d7b6c  vmovaps xmm15, [rsp+0xE0]
00007871bd3d7b75  add rsp, 0xF0
00007871bd3d7b7c  pop r11
00007871bd3d7b7e  pop r10
00007871bd3d7b80  pop r9
00007871bd3d7b82  pop r8
00007871bd3d7b84  pop rsi
00007871bd3d7b85  pop rdi
00007871bd3d7b86  pop rdx
00007871bd3d7b87  pop rcx
00007871bd3d7b88  pop rax
00007871bd3d7b89  add rsp, 0x08
00007871bd3d7b8d  jmp 0x00007871BD3D33BE
00007871bd3d7b92  call 0x00007871BD1FF430
00007871bd3d7b97  jmp 0x00007871BD3D33C8
00007871bd3d7b9c  sub rsp, 0x08
00007871bd3d7ba0  push rax
00007871bd3d7ba1  push rcx
00007871bd3d7ba2  push rdx
00007871bd3d7ba3  push rdi
00007871bd3d7ba4  push rsi
00007871bd3d7ba5  push r8
00007871bd3d7ba7  push r9
00007871bd3d7ba9  push r10
00007871bd3d7bab  push r11
00007871bd3d7bad  sub rsp, 0xF0
00007871bd3d7bb4  vmovaps [rsp], xmm0
00007871bd3d7bb9  vmovaps [rsp+0x10], xmm1
00007871bd3d7bbf  vmovaps [rsp+0x20], xmm2
00007871bd3d7bc5  vmovaps [rsp+0x30], xmm3
00007871bd3d7bcb  vmovaps [rsp+0x40], xmm4
00007871bd3d7bd1  vmovaps [rsp+0x50], xmm5
00007871bd3d7bd7  vmovaps [rsp+0x60], xmm6
00007871bd3d7bdd  vmovaps [rsp+0x70], xmm7
00007871bd3d7be3  vmovaps [rsp+0x80], xmm9
00007871bd3d7bec  vmovaps [rsp+0x90], xmm10
00007871bd3d7bf5  vmovaps [rsp+0xA0], xmm11
00007871bd3d7bfe  vmovaps [rsp+0xB0], xmm12
00007871bd3d7c07  vmovaps [rsp+0xC0], xmm13
00007871bd3d7c10  vmovaps [rsp+0xD0], xmm14
00007871bd3d7c19  vmovaps [rsp+0xE0], xmm15
00007871bd3d7c22  sub rsp, 0x30
00007871bd3d7c26  movaps [rsp], xmm8
00007871bd3d7c2b  movaps [rsp+0x10], xmm15
00007871bd3d7c31  movaps [rsp+0x20], xmm9
00007871bd3d7c37  lea rdi, [rsp]
00007871bd3d7c3b  mov esi, 0x00
00007871bd3d7c40  mov rax, 0x5BA2FDD2A530
00007871bd3d7c4a  call rax
00007871bd3d7c4c  movaps xmm8, [rsp]
00007871bd3d7c51  add rsp, 0x30
00007871bd3d7c55  vmovaps xmm0, [rsp]
00007871bd3d7c5a  vmovaps xmm1, [rsp+0x10]
00007871bd3d7c60  vmovaps xmm2, [rsp+0x20]
00007871bd3d7c66  vmovaps xmm3, [rsp+0x30]
00007871bd3d7c6c  vmovaps xmm4, [rsp+0x40]
00007871bd3d7c72  vmovaps xmm5, [rsp+0x50]
00007871bd3d7c78  vmovaps xmm6, [rsp+0x60]
00007871bd3d7c7e  vmovaps xmm7, [rsp+0x70]
00007871bd3d7c84  vmovaps xmm9, [rsp+0x80]
00007871bd3d7c8d  vmovaps xmm10, [rsp+0x90]
00007871bd3d7c96  vmovaps xmm11, [rsp+0xA0]
00007871bd3d7c9f  vmovaps xmm12, [rsp+0xB0]
00007871bd3d7ca8  vmovaps xmm13, [rsp+0xC0]
00007871bd3d7cb1  vmovaps xmm14, [rsp+0xD0]
00007871bd3d7cba  vmovaps xmm15, [rsp+0xE0]
00007871bd3d7cc3  add rsp, 0xF0
00007871bd3d7cca  pop r11
00007871bd3d7ccc  pop r10
00007871bd3d7cce  pop r9
00007871bd3d7cd0  pop r8
00007871bd3d7cd2  pop rsi
00007871bd3d7cd3  pop rdi
00007871bd3d7cd4  pop rdx
00007871bd3d7cd5  pop rcx
00007871bd3d7cd6  pop rax
00007871bd3d7cd7  add rsp, 0x08
00007871bd3d7cdb  jmp 0x00007871BD3D33EA
00007871bd3d7ce0  sub rsp, 0x08
00007871bd3d7ce4  push rax
00007871bd3d7ce5  push rcx
00007871bd3d7ce6  push rdx
00007871bd3d7ce7  push rdi
00007871bd3d7ce8  push rsi
00007871bd3d7ce9  push r8
00007871bd3d7ceb  push r9
00007871bd3d7ced  push r10
00007871bd3d7cef  push r11
00007871bd3d7cf1  sub rsp, 0xF0
00007871bd3d7cf8  vmovaps [rsp], xmm0
00007871bd3d7cfd  vmovaps [rsp+0x10], xmm1
00007871bd3d7d03  vmovaps [rsp+0x20], xmm2
00007871bd3d7d09  vmovaps [rsp+0x30], xmm3
00007871bd3d7d0f  vmovaps [rsp+0x40], xmm4
00007871bd3d7d15  vmovaps [rsp+0x50], xmm5
00007871bd3d7d1b  vmovaps [rsp+0x60], xmm6
00007871bd3d7d21  vmovaps [rsp+0x70], xmm7
00007871bd3d7d27  vmovaps [rsp+0x80], xmm8
00007871bd3d7d30  vmovaps [rsp+0x90], xmm10
00007871bd3d7d39  vmovaps [rsp+0xA0], xmm11
00007871bd3d7d42  vmovaps [rsp+0xB0], xmm12
00007871bd3d7d4b  vmovaps [rsp+0xC0], xmm13
00007871bd3d7d54  vmovaps [rsp+0xD0], xmm14
00007871bd3d7d5d  vmovaps [rsp+0xE0], xmm15
00007871bd3d7d66  sub rsp, 0x30
00007871bd3d7d6a  movaps [rsp], xmm9
00007871bd3d7d6f  movaps [rsp+0x10], xmm1
00007871bd3d7d74  movaps [rsp+0x20], xmm15
00007871bd3d7d7a  lea rdi, [rsp]
00007871bd3d7d7e  mov esi, 0x00
00007871bd3d7d83  mov rax, 0x5BA2FDD2A530
00007871bd3d7d8d  call rax
00007871bd3d7d8f  movaps xmm9, [rsp]
00007871bd3d7d94  add rsp, 0x30
00007871bd3d7d98  vmovaps xmm0, [rsp]
00007871bd3d7d9d  vmovaps xmm1, [rsp+0x10]
00007871bd3d7da3  vmovaps xmm2, [rsp+0x20]
00007871bd3d7da9  vmovaps xmm3, [rsp+0x30]
00007871bd3d7daf  vmovaps xmm4, [rsp+0x40]
00007871bd3d7db5  vmovaps xmm5, [rsp+0x50]
00007871bd3d7dbb  vmovaps xmm6, [rsp+0x60]
00007871bd3d7dc1  vmovaps xmm7, [rsp+0x70]
00007871bd3d7dc7  vmovaps xmm8, [rsp+0x80]
00007871bd3d7dd0  vmovaps xmm10, [rsp+0x90]
00007871bd3d7dd9  vmovaps xmm11, [rsp+0xA0]
00007871bd3d7de2  vmovaps xmm12, [rsp+0xB0]
00007871bd3d7deb  vmovaps xmm13, [rsp+0xC0]
00007871bd3d7df4  vmovaps xmm14, [rsp+0xD0]
00007871bd3d7dfd  vmovaps xmm15, [rsp+0xE0]
00007871bd3d7e06  add rsp, 0xF0
00007871bd3d7e0d  pop r11
00007871bd3d7e0f  pop r10
00007871bd3d7e11  pop r9
00007871bd3d7e13  pop r8
00007871bd3d7e15  pop rsi
00007871bd3d7e16  pop rdi
00007871bd3d7e17  pop rdx
00007871bd3d7e18  pop rcx
00007871bd3d7e19  pop rax
00007871bd3d7e1a  add rsp, 0x08
00007871bd3d7e1e  jmp 0x00007871BD3D3418
00007871bd3d7e23  sub rsp, 0x08
00007871bd3d7e27  push rax
00007871bd3d7e28  push rcx
00007871bd3d7e29  push rdx
00007871bd3d7e2a  push rdi
00007871bd3d7e2b  push rsi
00007871bd3d7e2c  push r8
00007871bd3d7e2e  push r9
00007871bd3d7e30  push r10
00007871bd3d7e32  push r11
00007871bd3d7e34  sub rsp, 0xF0
00007871bd3d7e3b  vmovaps [rsp], xmm0
00007871bd3d7e40  vmovaps [rsp+0x10], xmm1
00007871bd3d7e46  vmovaps [rsp+0x20], xmm2
00007871bd3d7e4c  vmovaps [rsp+0x30], xmm3
00007871bd3d7e52  vmovaps [rsp+0x40], xmm4
00007871bd3d7e58  vmovaps [rsp+0x50], xmm5
00007871bd3d7e5e  vmovaps [rsp+0x60], xmm6
00007871bd3d7e64  vmovaps [rsp+0x70], xmm7
00007871bd3d7e6a  vmovaps [rsp+0x80], xmm8
00007871bd3d7e73  vmovaps [rsp+0x90], xmm9
00007871bd3d7e7c  vmovaps [rsp+0xA0], xmm10
00007871bd3d7e85  vmovaps [rsp+0xB0], xmm11
00007871bd3d7e8e  vmovaps [rsp+0xC0], xmm12
00007871bd3d7e97  vmovaps [rsp+0xD0], xmm13
00007871bd3d7ea0  vmovaps [rsp+0xE0], xmm14
00007871bd3d7ea9  sub rsp, 0x30
00007871bd3d7ead  movaps [rsp], xmm15
00007871bd3d7eb2  movaps [rsp+0x10], xmm4
00007871bd3d7eb7  movaps [rsp+0x20], xmm1
00007871bd3d7ebc  lea rdi, [rsp]
00007871bd3d7ec0  mov esi, 0x00
00007871bd3d7ec5  mov rax, 0x5BA2FDD2A530
00007871bd3d7ecf  call rax
00007871bd3d7ed1  movaps xmm15, [rsp]
00007871bd3d7ed6  add rsp, 0x30
00007871bd3d7eda  vmovaps xmm0, [rsp]
00007871bd3d7edf  vmovaps xmm1, [rsp+0x10]
00007871bd3d7ee5  vmovaps xmm2, [rsp+0x20]
00007871bd3d7eeb  vmovaps xmm3, [rsp+0x30]
00007871bd3d7ef1  vmovaps xmm4, [rsp+0x40]
00007871bd3d7ef7  vmovaps xmm5, [rsp+0x50]
00007871bd3d7efd  vmovaps xmm6, [rsp+0x60]
00007871bd3d7f03  vmovaps xmm7, [rsp+0x70]
00007871bd3d7f09  vmovaps xmm8, [rsp+0x80]
00007871bd3d7f12  vmovaps xmm9, [rsp+0x90]
00007871bd3d7f1b  vmovaps xmm10, [rsp+0xA0]
00007871bd3d7f24  vmovaps xmm11, [rsp+0xB0]
00007871bd3d7f2d  vmovaps xmm12, [rsp+0xC0]
00007871bd3d7f36  vmovaps xmm13, [rsp+0xD0]
00007871bd3d7f3f  vmovaps xmm14, [rsp+0xE0]
00007871bd3d7f48  add rsp, 0xF0
00007871bd3d7f4f  pop r11
00007871bd3d7f51  pop r10
00007871bd3d7f53  pop r9
00007871bd3d7f55  pop r8
00007871bd3d7f57  pop rsi
00007871bd3d7f58  pop rdi
00007871bd3d7f59  pop rdx
00007871bd3d7f5a  pop rcx
00007871bd3d7f5b  pop rax
00007871bd3d7f5c  add rsp, 0x08
00007871bd3d7f60  jmp 0x00007871BD3D343E
00007871bd3d7f65  sub rsp, 0x08
00007871bd3d7f69  push rax
00007871bd3d7f6a  push rcx
00007871bd3d7f6b  push rdx
00007871bd3d7f6c  push rdi
00007871bd3d7f6d  push rsi
00007871bd3d7f6e  push r8
00007871bd3d7f70  push r9
00007871bd3d7f72  push r10
00007871bd3d7f74  push r11
00007871bd3d7f76  sub rsp, 0xF0
00007871bd3d7f7d  vmovaps [rsp], xmm0
00007871bd3d7f82  vmovaps [rsp+0x10], xmm2
00007871bd3d7f88  vmovaps [rsp+0x20], xmm3
00007871bd3d7f8e  vmovaps [rsp+0x30], xmm4
00007871bd3d7f94  vmovaps [rsp+0x40], xmm5
00007871bd3d7f9a  vmovaps [rsp+0x50], xmm6
00007871bd3d7fa0  vmovaps [rsp+0x60], xmm7
00007871bd3d7fa6  vmovaps [rsp+0x70], xmm8
00007871bd3d7fac  vmovaps [rsp+0x80], xmm9
00007871bd3d7fb5  vmovaps [rsp+0x90], xmm10
00007871bd3d7fbe  vmovaps [rsp+0xA0], xmm11
00007871bd3d7fc7  vmovaps [rsp+0xB0], xmm12
00007871bd3d7fd0  vmovaps [rsp+0xC0], xmm13
00007871bd3d7fd9  vmovaps [rsp+0xD0], xmm14
00007871bd3d7fe2  vmovaps [rsp+0xE0], xmm15
00007871bd3d7feb  sub rsp, 0x30
00007871bd3d7fef  movaps [rsp], xmm1
00007871bd3d7ff3  movaps [rsp+0x10], xmm14
00007871bd3d7ff9  movaps [rsp+0x20], xmm11
00007871bd3d7fff  lea rdi, [rsp]
00007871bd3d8003  mov esi, 0x00
00007871bd3d8008  mov rax, 0x5BA2FDD2A530
00007871bd3d8012  call rax
00007871bd3d8014  movaps xmm1, [rsp]
00007871bd3d8018  add rsp, 0x30
00007871bd3d801c  vmovaps xmm0, [rsp]
00007871bd3d8021  vmovaps xmm2, [rsp+0x10]
00007871bd3d8027  vmovaps xmm3, [rsp+0x20]
00007871bd3d802d  vmovaps xmm4, [rsp+0x30]
00007871bd3d8033  vmovaps xmm5, [rsp+0x40]
00007871bd3d8039  vmovaps xmm6, [rsp+0x50]
00007871bd3d803f  vmovaps xmm7, [rsp+0x60]
00007871bd3d8045  vmovaps xmm8, [rsp+0x70]
00007871bd3d804b  vmovaps xmm9, [rsp+0x80]
00007871bd3d8054  vmovaps xmm10, [rsp+0x90]
00007871bd3d805d  vmovaps xmm11, [rsp+0xA0]
00007871bd3d8066  vmovaps xmm12, [rsp+0xB0]
00007871bd3d806f  vmovaps xmm13, [rsp+0xC0]
00007871bd3d8078  vmovaps xmm14, [rsp+0xD0]
00007871bd3d8081  vmovaps xmm15, [rsp+0xE0]
00007871bd3d808a  add rsp, 0xF0
00007871bd3d8091  pop r11
00007871bd3d8093  pop r10
00007871bd3d8095  pop r9
00007871bd3d8097  pop r8
00007871bd3d8099  pop rsi
00007871bd3d809a  pop rdi
00007871bd3d809b  pop rdx
00007871bd3d809c  pop rcx
00007871bd3d809d  pop rax
00007871bd3d809e  add rsp, 0x08
00007871bd3d80a2  jmp 0x00007871BD3D345F
00007871bd3d80a7  call 0x00007871BD2E45A0
00007871bd3d80ac  jmp 0x00007871BD3D346D
00007871bd3d80b1  call 0x00007871BD209D70
00007871bd3d80b6  jmp 0x00007871BD3D3477
00007871bd3d80bb  sub rsp, 0x08
00007871bd3d80bf  push rax
00007871bd3d80c0  push rcx
00007871bd3d80c1  push rdx
00007871bd3d80c2  push rdi
00007871bd3d80c3  push rsi
00007871bd3d80c4  push r8
00007871bd3d80c6  push r9
00007871bd3d80c8  push r10
00007871bd3d80ca  push r11
00007871bd3d80cc  sub rsp, 0xF0
00007871bd3d80d3  vmovaps [rsp], xmm0
00007871bd3d80d8  vmovaps [rsp+0x10], xmm1
00007871bd3d80de  vmovaps [rsp+0x20], xmm2
00007871bd3d80e4  vmovaps [rsp+0x30], xmm3
00007871bd3d80ea  vmovaps [rsp+0x40], xmm4
00007871bd3d80f0  vmovaps [rsp+0x50], xmm5
00007871bd3d80f6  vmovaps [rsp+0x60], xmm6
00007871bd3d80fc  vmovaps [rsp+0x70], xmm8
00007871bd3d8102  vmovaps [rsp+0x80], xmm9
00007871bd3d810b  vmovaps [rsp+0x90], xmm10
00007871bd3d8114  vmovaps [rsp+0xA0], xmm11
00007871bd3d811d  vmovaps [rsp+0xB0], xmm12
00007871bd3d8126  vmovaps [rsp+0xC0], xmm13
00007871bd3d812f  vmovaps [rsp+0xD0], xmm14
00007871bd3d8138  vmovaps [rsp+0xE0], xmm15
00007871bd3d8141  sub rsp, 0x30
00007871bd3d8145  movaps [rsp], xmm7
00007871bd3d8149  movaps [rsp+0x10], xmm13
00007871bd3d814f  movaps [rsp+0x20], xmm10
00007871bd3d8155  lea rdi, [rsp]
00007871bd3d8159  mov esi, 0x00
00007871bd3d815e  mov rax, 0x5BA2FDD2A530
00007871bd3d8168  call rax
00007871bd3d816a  movaps xmm7, [rsp]
00007871bd3d816e  add rsp, 0x30
00007871bd3d8172  vmovaps xmm0, [rsp]
00007871bd3d8177  vmovaps xmm1, [rsp+0x10]
00007871bd3d817d  vmovaps xmm2, [rsp+0x20]
00007871bd3d8183  vmovaps xmm3, [rsp+0x30]
00007871bd3d8189  vmovaps xmm4, [rsp+0x40]
00007871bd3d818f  vmovaps xmm5, [rsp+0x50]
00007871bd3d8195  vmovaps xmm6, [rsp+0x60]
00007871bd3d819b  vmovaps xmm8, [rsp+0x70]
00007871bd3d81a1  vmovaps xmm9, [rsp+0x80]
00007871bd3d81aa  vmovaps xmm10, [rsp+0x90]
00007871bd3d81b3  vmovaps xmm11, [rsp+0xA0]
00007871bd3d81bc  vmovaps xmm12, [rsp+0xB0]
00007871bd3d81c5  vmovaps xmm13, [rsp+0xC0]
00007871bd3d81ce  vmovaps xmm14, [rsp+0xD0]
00007871bd3d81d7  vmovaps xmm15, [rsp+0xE0]
00007871bd3d81e0  add rsp, 0xF0
00007871bd3d81e7  pop r11
00007871bd3d81e9  pop r10
00007871bd3d81eb  pop r9
00007871bd3d81ed  pop r8
00007871bd3d81ef  pop rsi
00007871bd3d81f0  pop rdi
00007871bd3d81f1  pop rdx
00007871bd3d81f2  pop rcx
00007871bd3d81f3  pop rax
00007871bd3d81f4  add rsp, 0x08
00007871bd3d81f8  jmp 0x00007871BD3D3498
00007871bd3d81fd  sub rsp, 0x08
00007871bd3d8201  push rax
00007871bd3d8202  push rcx
00007871bd3d8203  push rdx
00007871bd3d8204  push rdi
00007871bd3d8205  push rsi
00007871bd3d8206  push r8
00007871bd3d8208  push r9
00007871bd3d820a  push r10
00007871bd3d820c  push r11
00007871bd3d820e  sub rsp, 0xF0
00007871bd3d8215  vmovaps [rsp], xmm0
00007871bd3d821a  vmovaps [rsp+0x10], xmm1
00007871bd3d8220  vmovaps [rsp+0x20], xmm2
00007871bd3d8226  vmovaps [rsp+0x30], xmm3
00007871bd3d822c  vmovaps [rsp+0x40], xmm4
00007871bd3d8232  vmovaps [rsp+0x50], xmm5
00007871bd3d8238  vmovaps [rsp+0x60], xmm6
00007871bd3d823e  vmovaps [rsp+0x70], xmm7
00007871bd3d8244  vmovaps [rsp+0x80], xmm8
00007871bd3d824d  vmovaps [rsp+0x90], xmm9
00007871bd3d8256  vmovaps [rsp+0xA0], xmm11
00007871bd3d825f  vmovaps [rsp+0xB0], xmm12
00007871bd3d8268  vmovaps [rsp+0xC0], xmm13
00007871bd3d8271  vmovaps [rsp+0xD0], xmm14
00007871bd3d827a  vmovaps [rsp+0xE0], xmm15
00007871bd3d8283  sub rsp, 0x30
00007871bd3d8287  movaps [rsp], xmm10
00007871bd3d828c  movaps [rsp+0x10], xmm11
00007871bd3d8292  movaps [rsp+0x20], xmm13
00007871bd3d8298  lea rdi, [rsp]
00007871bd3d829c  mov esi, 0x00
00007871bd3d82a1  mov rax, 0x5BA2FDD2A530
00007871bd3d82ab  call rax
00007871bd3d82ad  movaps xmm10, [rsp]
00007871bd3d82b2  add rsp, 0x30
00007871bd3d82b6  vmovaps xmm0, [rsp]
00007871bd3d82bb  vmovaps xmm1, [rsp+0x10]
00007871bd3d82c1  vmovaps xmm2, [rsp+0x20]
00007871bd3d82c7  vmovaps xmm3, [rsp+0x30]
00007871bd3d82cd  vmovaps xmm4, [rsp+0x40]
00007871bd3d82d3  vmovaps xmm5, [rsp+0x50]
00007871bd3d82d9  vmovaps xmm6, [rsp+0x60]
00007871bd3d82df  vmovaps xmm7, [rsp+0x70]
00007871bd3d82e5  vmovaps xmm8, [rsp+0x80]
00007871bd3d82ee  vmovaps xmm9, [rsp+0x90]
00007871bd3d82f7  vmovaps xmm11, [rsp+0xA0]
00007871bd3d8300  vmovaps xmm12, [rsp+0xB0]
00007871bd3d8309  vmovaps xmm13, [rsp+0xC0]
00007871bd3d8312  vmovaps xmm14, [rsp+0xD0]
00007871bd3d831b  vmovaps xmm15, [rsp+0xE0]
00007871bd3d8324  add rsp, 0xF0
00007871bd3d832b  pop r11
00007871bd3d832d  pop r10
00007871bd3d832f  pop r9
00007871bd3d8331  pop r8
00007871bd3d8333  pop rsi
00007871bd3d8334  pop rdi
00007871bd3d8335  pop rdx
00007871bd3d8336  pop rcx
00007871bd3d8337  pop rax
00007871bd3d8338  add rsp, 0x08
00007871bd3d833c  jmp 0x00007871BD3D34C6
00007871bd3d8341  sub rsp, 0x08
00007871bd3d8345  push rax
00007871bd3d8346  push rcx
00007871bd3d8347  push rdx
00007871bd3d8348  push rdi
00007871bd3d8349  push rsi
00007871bd3d834a  push r8
00007871bd3d834c  push r9
00007871bd3d834e  push r10
00007871bd3d8350  push r11
00007871bd3d8352  sub rsp, 0xF0
00007871bd3d8359  vmovaps [rsp], xmm0
00007871bd3d835e  vmovaps [rsp+0x10], xmm1
00007871bd3d8364  vmovaps [rsp+0x20], xmm2
00007871bd3d836a  vmovaps [rsp+0x30], xmm3
00007871bd3d8370  vmovaps [rsp+0x40], xmm4
00007871bd3d8376  vmovaps [rsp+0x50], xmm5
00007871bd3d837c  vmovaps [rsp+0x60], xmm6
00007871bd3d8382  vmovaps [rsp+0x70], xmm7
00007871bd3d8388  vmovaps [rsp+0x80], xmm8
00007871bd3d8391  vmovaps [rsp+0x90], xmm9
00007871bd3d839a  vmovaps [rsp+0xA0], xmm10
00007871bd3d83a3  vmovaps [rsp+0xB0], xmm12
00007871bd3d83ac  vmovaps [rsp+0xC0], xmm13
00007871bd3d83b5  vmovaps [rsp+0xD0], xmm14
00007871bd3d83be  vmovaps [rsp+0xE0], xmm15
00007871bd3d83c7  sub rsp, 0x30
00007871bd3d83cb  movaps [rsp], xmm11
00007871bd3d83d0  movaps [rsp+0x10], xmm14
00007871bd3d83d6  movaps [rsp+0x20], xmm13
00007871bd3d83dc  lea rdi, [rsp]
00007871bd3d83e0  mov esi, 0x00
00007871bd3d83e5  mov rax, 0x5BA2FDD2A530
00007871bd3d83ef  call rax
00007871bd3d83f1  movaps xmm11, [rsp]
00007871bd3d83f6  add rsp, 0x30
00007871bd3d83fa  vmovaps xmm0, [rsp]
00007871bd3d83ff  vmovaps xmm1, [rsp+0x10]
00007871bd3d8405  vmovaps xmm2, [rsp+0x20]
00007871bd3d840b  vmovaps xmm3, [rsp+0x30]
00007871bd3d8411  vmovaps xmm4, [rsp+0x40]
00007871bd3d8417  vmovaps xmm5, [rsp+0x50]
00007871bd3d841d  vmovaps xmm6, [rsp+0x60]
00007871bd3d8423  vmovaps xmm7, [rsp+0x70]
00007871bd3d8429  vmovaps xmm8, [rsp+0x80]
00007871bd3d8432  vmovaps xmm9, [rsp+0x90]
00007871bd3d843b  vmovaps xmm10, [rsp+0xA0]
00007871bd3d8444  vmovaps xmm12, [rsp+0xB0]
00007871bd3d844d  vmovaps xmm13, [rsp+0xC0]
00007871bd3d8456  vmovaps xmm14, [rsp+0xD0]
00007871bd3d845f  vmovaps xmm15, [rsp+0xE0]
00007871bd3d8468  add rsp, 0xF0
00007871bd3d846f  pop r11
00007871bd3d8471  pop r10
00007871bd3d8473  pop r9
00007871bd3d8475  pop r8
00007871bd3d8477  pop rsi
00007871bd3d8478  pop rdi
00007871bd3d8479  pop rdx
00007871bd3d847a  pop rcx
00007871bd3d847b  pop rax
00007871bd3d847c  add rsp, 0x08
00007871bd3d8480  jmp 0x00007871BD3D34F4
00007871bd3d8485  sub rsp, 0x08
00007871bd3d8489  push rax
00007871bd3d848a  push rcx
00007871bd3d848b  push rdx
00007871bd3d848c  push rdi
00007871bd3d848d  push rsi
00007871bd3d848e  push r8
00007871bd3d8490  push r9
00007871bd3d8492  push r10
00007871bd3d8494  push r11
00007871bd3d8496  sub rsp, 0xF0
00007871bd3d849d  vmovaps [rsp], xmm0
00007871bd3d84a2  vmovaps [rsp+0x10], xmm1
00007871bd3d84a8  vmovaps [rsp+0x20], xmm2
00007871bd3d84ae  vmovaps [rsp+0x30], xmm3
00007871bd3d84b4  vmovaps [rsp+0x40], xmm4
00007871bd3d84ba  vmovaps [rsp+0x50], xmm5
00007871bd3d84c0  vmovaps [rsp+0x60], xmm6
00007871bd3d84c6  vmovaps [rsp+0x70], xmm7
00007871bd3d84cc  vmovaps [rsp+0x80], xmm8
00007871bd3d84d5  vmovaps [rsp+0x90], xmm9
00007871bd3d84de  vmovaps [rsp+0xA0], xmm10
00007871bd3d84e7  vmovaps [rsp+0xB0], xmm11
00007871bd3d84f0  vmovaps [rsp+0xC0], xmm12
00007871bd3d84f9  vmovaps [rsp+0xD0], xmm13
00007871bd3d8502  vmovaps [rsp+0xE0], xmm15
00007871bd3d850b  sub rsp, 0x30
00007871bd3d850f  movaps [rsp], xmm14
00007871bd3d8514  movaps [rsp+0x10], xmm12
00007871bd3d851a  movaps [rsp+0x20], xmm9
00007871bd3d8520  lea rdi, [rsp]
00007871bd3d8524  mov esi, 0x00
00007871bd3d8529  mov rax, 0x5BA2FDD2A530
00007871bd3d8533  call rax
00007871bd3d8535  movaps xmm14, [rsp]
00007871bd3d853a  add rsp, 0x30
00007871bd3d853e  vmovaps xmm0, [rsp]
00007871bd3d8543  vmovaps xmm1, [rsp+0x10]
00007871bd3d8549  vmovaps xmm2, [rsp+0x20]
00007871bd3d854f  vmovaps xmm3, [rsp+0x30]
00007871bd3d8555  vmovaps xmm4, [rsp+0x40]
00007871bd3d855b  vmovaps xmm5, [rsp+0x50]
00007871bd3d8561  vmovaps xmm6, [rsp+0x60]
00007871bd3d8567  vmovaps xmm7, [rsp+0x70]
00007871bd3d856d  vmovaps xmm8, [rsp+0x80]
00007871bd3d8576  vmovaps xmm9, [rsp+0x90]
00007871bd3d857f  vmovaps xmm10, [rsp+0xA0]
00007871bd3d8588  vmovaps xmm11, [rsp+0xB0]
00007871bd3d8591  vmovaps xmm12, [rsp+0xC0]
00007871bd3d859a  vmovaps xmm13, [rsp+0xD0]
00007871bd3d85a3  vmovaps xmm15, [rsp+0xE0]
00007871bd3d85ac  add rsp, 0xF0
00007871bd3d85b3  pop r11
00007871bd3d85b5  pop r10
00007871bd3d85b7  pop r9
00007871bd3d85b9  pop r8
00007871bd3d85bb  pop rsi
00007871bd3d85bc  pop rdi
00007871bd3d85bd  pop rdx
00007871bd3d85be  pop rcx
00007871bd3d85bf  pop rax
00007871bd3d85c0  add rsp, 0x08
00007871bd3d85c4  jmp 0x00007871BD3D350F
00007871bd3d85c9  sub rsp, 0x08
00007871bd3d85cd  push rax
00007871bd3d85ce  push rcx
00007871bd3d85cf  push rdx
00007871bd3d85d0  push rdi
00007871bd3d85d1  push rsi
00007871bd3d85d2  push r8
00007871bd3d85d4  push r9
00007871bd3d85d6  push r10
00007871bd3d85d8  push r11
00007871bd3d85da  sub rsp, 0xF0
00007871bd3d85e1  vmovaps [rsp], xmm0
00007871bd3d85e6  vmovaps [rsp+0x10], xmm1
00007871bd3d85ec  vmovaps [rsp+0x20], xmm2
00007871bd3d85f2  vmovaps [rsp+0x30], xmm3
00007871bd3d85f8  vmovaps [rsp+0x40], xmm4
00007871bd3d85fe  vmovaps [rsp+0x50], xmm5
00007871bd3d8604  vmovaps [rsp+0x60], xmm6
00007871bd3d860a  vmovaps [rsp+0x70], xmm7
00007871bd3d8610  vmovaps [rsp+0x80], xmm8
00007871bd3d8619  vmovaps [rsp+0x90], xmm9
00007871bd3d8622  vmovaps [rsp+0xA0], xmm10
00007871bd3d862b  vmovaps [rsp+0xB0], xmm11
00007871bd3d8634  vmovaps [rsp+0xC0], xmm12
00007871bd3d863d  vmovaps [rsp+0xD0], xmm14
00007871bd3d8646  vmovaps [rsp+0xE0], xmm15
00007871bd3d864f  sub rsp, 0x30
00007871bd3d8653  movaps [rsp], xmm13
00007871bd3d8658  movaps [rsp+0x10], xmm8
00007871bd3d865e  movaps [rsp+0x20], xmm15
00007871bd3d8664  lea rdi, [rsp]
00007871bd3d8668  mov esi, 0x00
00007871bd3d866d  mov rax, 0x5BA2FDD2A530
00007871bd3d8677  call rax
00007871bd3d8679  movaps xmm13, [rsp]
00007871bd3d867e  add rsp, 0x30
00007871bd3d8682  vmovaps xmm0, [rsp]
00007871bd3d8687  vmovaps xmm1, [rsp+0x10]
00007871bd3d868d  vmovaps xmm2, [rsp+0x20]
00007871bd3d8693  vmovaps xmm3, [rsp+0x30]
00007871bd3d8699  vmovaps xmm4, [rsp+0x40]
00007871bd3d869f  vmovaps xmm5, [rsp+0x50]
00007871bd3d86a5  vmovaps xmm6, [rsp+0x60]
00007871bd3d86ab  vmovaps xmm7, [rsp+0x70]
00007871bd3d86b1  vmovaps xmm8, [rsp+0x80]
00007871bd3d86ba  vmovaps xmm9, [rsp+0x90]
00007871bd3d86c3  vmovaps xmm10, [rsp+0xA0]
00007871bd3d86cc  vmovaps xmm11, [rsp+0xB0]
00007871bd3d86d5  vmovaps xmm12, [rsp+0xC0]
00007871bd3d86de  vmovaps xmm14, [rsp+0xD0]
00007871bd3d86e7  vmovaps xmm15, [rsp+0xE0]
00007871bd3d86f0  add rsp, 0xF0
00007871bd3d86f7  pop r11
00007871bd3d86f9  pop r10
00007871bd3d86fb  pop r9
00007871bd3d86fd  pop r8
00007871bd3d86ff  pop rsi
00007871bd3d8700  pop rdi
00007871bd3d8701  pop rdx
00007871bd3d8702  pop rcx
00007871bd3d8703  pop rax
00007871bd3d8704  add rsp, 0x08
00007871bd3d8708  jmp 0x00007871BD3D3532
00007871bd3d870d  sub rsp, 0x08
00007871bd3d8711  push rax
00007871bd3d8712  push rcx
00007871bd3d8713  push rdx
00007871bd3d8714  push rdi
00007871bd3d8715  push rsi
00007871bd3d8716  push r8
00007871bd3d8718  push r9
00007871bd3d871a  push r10
00007871bd3d871c  push r11
00007871bd3d871e  sub rsp, 0xF0
00007871bd3d8725  vmovaps [rsp], xmm0
00007871bd3d872a  vmovaps [rsp+0x10], xmm1
00007871bd3d8730  vmovaps [rsp+0x20], xmm2
00007871bd3d8736  vmovaps [rsp+0x30], xmm3
00007871bd3d873c  vmovaps [rsp+0x40], xmm4
00007871bd3d8742  vmovaps [rsp+0x50], xmm5
00007871bd3d8748  vmovaps [rsp+0x60], xmm6
00007871bd3d874e  vmovaps [rsp+0x70], xmm7
00007871bd3d8754  vmovaps [rsp+0x80], xmm8
00007871bd3d875d  vmovaps [rsp+0x90], xmm9
00007871bd3d8766  vmovaps [rsp+0xA0], xmm10
00007871bd3d876f  vmovaps [rsp+0xB0], xmm11
00007871bd3d8778  vmovaps [rsp+0xC0], xmm12
00007871bd3d8781  vmovaps [rsp+0xD0], xmm13
00007871bd3d878a  vmovaps [rsp+0xE0], xmm14
00007871bd3d8793  sub rsp, 0x30
00007871bd3d8797  movaps [rsp], xmm15
00007871bd3d879c  movaps [rsp+0x10], xmm1
00007871bd3d87a1  movaps [rsp+0x20], xmm10
00007871bd3d87a7  lea rdi, [rsp]
00007871bd3d87ab  mov esi, 0x00
00007871bd3d87b0  mov rax, 0x5BA2FDD2A530
00007871bd3d87ba  call rax
00007871bd3d87bc  movaps xmm15, [rsp]
00007871bd3d87c1  add rsp, 0x30
00007871bd3d87c5  vmovaps xmm0, [rsp]
00007871bd3d87ca  vmovaps xmm1, [rsp+0x10]
00007871bd3d87d0  vmovaps xmm2, [rsp+0x20]
00007871bd3d87d6  vmovaps xmm3, [rsp+0x30]
00007871bd3d87dc  vmovaps xmm4, [rsp+0x40]
00007871bd3d87e2  vmovaps xmm5, [rsp+0x50]
00007871bd3d87e8  vmovaps xmm6, [rsp+0x60]
00007871bd3d87ee  vmovaps xmm7, [rsp+0x70]
00007871bd3d87f4  vmovaps xmm8, [rsp+0x80]
00007871bd3d87fd  vmovaps xmm9, [rsp+0x90]
00007871bd3d8806  vmovaps xmm10, [rsp+0xA0]
00007871bd3d880f  vmovaps xmm11, [rsp+0xB0]
00007871bd3d8818  vmovaps xmm12, [rsp+0xC0]
00007871bd3d8821  vmovaps xmm13, [rsp+0xD0]
00007871bd3d882a  vmovaps xmm14, [rsp+0xE0]
00007871bd3d8833  add rsp, 0xF0
00007871bd3d883a  pop r11
00007871bd3d883c  pop r10
00007871bd3d883e  pop r9
00007871bd3d8840  pop r8
00007871bd3d8842  pop rsi
00007871bd3d8843  pop rdi
00007871bd3d8844  pop rdx
00007871bd3d8845  pop rcx
00007871bd3d8846  pop rax
00007871bd3d8847  add rsp, 0x08
00007871bd3d884b  jmp 0x00007871BD3D3555
00007871bd3d8850  sub rsp, 0x08
00007871bd3d8854  push rax
00007871bd3d8855  push rcx
00007871bd3d8856  push rdx
00007871bd3d8857  push rdi
00007871bd3d8858  push rsi
00007871bd3d8859  push r8
00007871bd3d885b  push r9
00007871bd3d885d  push r10
00007871bd3d885f  push r11
00007871bd3d8861  sub rsp, 0xF0
00007871bd3d8868  vmovaps [rsp], xmm0
00007871bd3d886d  vmovaps [rsp+0x10], xmm2
00007871bd3d8873  vmovaps [rsp+0x20], xmm3
00007871bd3d8879  vmovaps [rsp+0x30], xmm4
00007871bd3d887f  vmovaps [rsp+0x40], xmm5
00007871bd3d8885  vmovaps [rsp+0x50], xmm6
00007871bd3d888b  vmovaps [rsp+0x60], xmm7
00007871bd3d8891  vmovaps [rsp+0x70], xmm8
00007871bd3d8897  vmovaps [rsp+0x80], xmm9
00007871bd3d88a0  vmovaps [rsp+0x90], xmm10
00007871bd3d88a9  vmovaps [rsp+0xA0], xmm11
00007871bd3d88b2  vmovaps [rsp+0xB0], xmm12
00007871bd3d88bb  vmovaps [rsp+0xC0], xmm13
00007871bd3d88c4  vmovaps [rsp+0xD0], xmm14
00007871bd3d88cd  vmovaps [rsp+0xE0], xmm15
00007871bd3d88d6  sub rsp, 0x30
00007871bd3d88da  movaps [rsp], xmm1
00007871bd3d88de  movaps [rsp+0x10], xmm7
00007871bd3d88e3  movaps [rsp+0x20], xmm11
00007871bd3d88e9  lea rdi, [rsp]
00007871bd3d88ed  mov esi, 0x00
00007871bd3d88f2  mov rax, 0x5BA2FDD2A530
00007871bd3d88fc  call rax
00007871bd3d88fe  movaps xmm1, [rsp]
00007871bd3d8902  add rsp, 0x30
00007871bd3d8906  vmovaps xmm0, [rsp]
00007871bd3d890b  vmovaps xmm2, [rsp+0x10]
00007871bd3d8911  vmovaps xmm3, [rsp+0x20]
00007871bd3d8917  vmovaps xmm4, [rsp+0x30]
00007871bd3d891d  vmovaps xmm5, [rsp+0x40]
00007871bd3d8923  vmovaps xmm6, [rsp+0x50]
00007871bd3d8929  vmovaps xmm7, [rsp+0x60]
00007871bd3d892f  vmovaps xmm8, [rsp+0x70]
00007871bd3d8935  vmovaps xmm9, [rsp+0x80]
00007871bd3d893e  vmovaps xmm10, [rsp+0x90]
00007871bd3d8947  vmovaps xmm11, [rsp+0xA0]
00007871bd3d8950  vmovaps xmm12, [rsp+0xB0]
00007871bd3d8959  vmovaps xmm13, [rsp+0xC0]
00007871bd3d8962  vmovaps xmm14, [rsp+0xD0]
00007871bd3d896b  vmovaps xmm15, [rsp+0xE0]
00007871bd3d8974  add rsp, 0xF0
00007871bd3d897b  pop r11
00007871bd3d897d  pop r10
00007871bd3d897f  pop r9
00007871bd3d8981  pop r8
00007871bd3d8983  pop rsi
00007871bd3d8984  pop rdi
00007871bd3d8985  pop rdx
00007871bd3d8986  pop rcx
00007871bd3d8987  pop rax
00007871bd3d8988  add rsp, 0x08
00007871bd3d898c  jmp 0x00007871BD3D3576
00007871bd3d8991  call 0x00007871BD20D600
00007871bd3d8996  jmp 0x00007871BD3D3589
00007871bd3d899b  call 0x00007871BD20C380
00007871bd3d89a0  jmp 0x00007871BD3D3594
00007871bd3d89a5  call 0x00007871BD20E880
00007871bd3d89aa  jmp 0x00007871BD3D359F
00007871bd3d89af  call 0x00007871BD1FF540
00007871bd3d89b4  jmp 0x00007871BD3D35AA
00007871bd3d89b9  int3
00007871bd3d89ba  nop [rax+rax*1], ax
00007871bd3d89c0  mov rax, [r15+0x40]
00007871bd3d89c4  mov r14, [r15+0x58]
00007871bd3d89c8  lea r12, [rax+r14*1]
00007871bd3d89cc  movaps xmm1, [r15+0x1D0]
00007871bd3d89d4  vmovaps [rsp+0x10], xmm1
00007871bd3d89da  vmovaps xmm15, [rsp+0x10]
00007871bd3d89e0  por xmm1, xmm15
00007871bd3d89e5  movaps xmm14, [r15+0x1A0]
00007871bd3d89ed  vmovaps [rsp+0x10], xmm14
00007871bd3d89f3  vmovaps xmm13, [rsp+0x10]
00007871bd3d89f9  por xmm14, xmm13
00007871bd3d89fe  lea rax, [r12+0x30]
00007871bd3d8a03  mov r11, [r13+rax*1]
00007871bd3d8a08  lea rax, [r12+0x38]
00007871bd3d8a0d  mov r10, [r13+rax*1]
00007871bd3d8a12  movq xmm13, r11
00007871bd3d8a17  movq xmm12, r10
00007871bd3d8a1c  movq xmm13, xmm13
00007871bd3d8a21  vmovaps [rsp+0x10], xmm13
00007871bd3d8a27  movq xmm13, xmm13
00007871bd3d8a2c  movaps [r15+0x130], xmm13
00007871bd3d8a34  movq xmm12, xmm12
00007871bd3d8a39  vmovaps [rsp+0x20], xmm12
00007871bd3d8a3f  movq xmm12, xmm12
00007871bd3d8a44  movaps [r15+0x280], xmm12
00007871bd3d8a4c  movaps xmm13, [r15+0x270]
00007871bd3d8a54  vmovaps [rsp+0x30], xmm13
00007871bd3d8a5a  vmovaps xmm12, [rsp+0x30]
00007871bd3d8a60  por xmm13, xmm12
00007871bd3d8a65  lea rax, [r12+0x20]
00007871bd3d8a6a  mov r11, [r13+rax*1]
00007871bd3d8a6f  lea rax, [r12+0x28]
00007871bd3d8a74  mov r10, [r13+rax*1]
00007871bd3d8a79  movq xmm12, r11
00007871bd3d8a7e  movq xmm11, r10
00007871bd3d8a83  movq xmm12, xmm12
00007871bd3d8a88  vmovaps [rsp+0x30], xmm12
00007871bd3d8a8e  movq xmm12, xmm12
00007871bd3d8a93  movaps [r15+0x150], xmm12
00007871bd3d8a9b  movq xmm11, xmm11
00007871bd3d8aa0  vmovaps [rsp+0x40], xmm11
00007871bd3d8aa6  movq xmm11, xmm11
00007871bd3d8aab  movaps [r15+0x140], xmm11
00007871bd3d8ab3  lea rax, [r12+0x10]
00007871bd3d8ab8  mov r11, [r13+rax*1]
00007871bd3d8abd  lea rax, [r12+0x18]
00007871bd3d8ac2  mov r10, [r13+rax*1]
00007871bd3d8ac7  movq xmm12, r11
00007871bd3d8acc  movq xmm11, r10
00007871bd3d8ad1  movq xmm12, xmm12
00007871bd3d8ad6  vmovaps [rsp+0x50], xmm12
00007871bd3d8adc  movq xmm12, xmm12
00007871bd3d8ae1  movaps [r15+0x170], xmm12
00007871bd3d8ae9  movq xmm11, xmm11
00007871bd3d8aee  vmovaps [rsp+0x60], xmm11
00007871bd3d8af4  movq xmm11, xmm11
00007871bd3d8af9  movaps [r15+0x160], xmm11
00007871bd3d8b01  mov rax, [r13+r12*1]
00007871bd3d8b06  vmovq xmm12, rax
00007871bd3d8b0b  vpbroadcastq xmm12, xmm12
00007871bd3d8b10  lea rax, [r12+0x08]
00007871bd3d8b15  mov r12, [r13+rax*1]
00007871bd3d8b1a  movq xmm11, r12
00007871bd3d8b1f  movaps [r15+0x230], xmm11
00007871bd3d8b27  mov rax, [r15+0xF8]
00007871bd3d8b2e  lea r12, [rax+0x50]
00007871bd3d8b32  movups xmm11, [r13+r12*1]
00007871bd3d8b38  lea r12, [rax+0x60]
00007871bd3d8b3c  movups xmm10, [r13+r12*1]
00007871bd3d8b42  lea r12, [rax+0x30]
00007871bd3d8b46  movups xmm9, [r13+r12*1]
00007871bd3d8b4c  mov r12, [r15+0x50]
00007871bd3d8b50  lea r11, [r12+r14*1]
00007871bd3d8b54  mov [r15+0x60], r11
00007871bd3d8b58  lea r12, [r14+0x40]
00007871bd3d8b5c  mov [r15+0x58], r12
00007871bd3d8b60  movaps xmm8, xmm12
00007871bd3d8b64  mulpd xmm8, xmm15
00007871bd3d8b69  vcmppd xmm7, xmm8, xmm8, 0x03
00007871bd3d8b6f  ptest xmm7, xmm7
00007871bd3d8b74  jnz 0x00007871BD3D9997
00007871bd3d8b7a  movq xmm15, qword ptr [r15+0x230]
00007871bd3d8b83  vmovaps [rsp+0x70], xmm15
00007871bd3d8b89  vpermilpd xmm15, xmm15, 0x00
00007871bd3d8b8f  movaps xmm7, xmm9
00007871bd3d8b93  mulpd xmm7, xmm15
00007871bd3d8b98  vcmppd xmm6, xmm7, xmm7, 0x03
00007871bd3d8b9d  ptest xmm6, xmm6
00007871bd3d8ba2  jnz 0x00007871BD3D9ADB
00007871bd3d8ba8  vxorps xmm15, xmm15, xmm15
00007871bd3d8bad  vpbroadcastq xmm15, xmm15
00007871bd3d8bb2  movaps xmm9, xmm12
00007871bd3d8bb6  mulpd xmm9, xmm10
00007871bd3d8bbb  vcmppd xmm6, xmm9, xmm9, 0x03
00007871bd3d8bc1  ptest xmm6, xmm6
00007871bd3d8bc6  jnz 0x00007871BD3D9C1D
00007871bd3d8bcc  movaps xmm10, xmm12
00007871bd3d8bd0  mulpd xmm10, xmm11
00007871bd3d8bd5  vcmppd xmm6, xmm10, xmm10, 0x03
00007871bd3d8bdb  ptest xmm6, xmm6
00007871bd3d8be0  jnz 0x00007871BD3D9D61
00007871bd3d8be6  movaps xmm11, [r15+0x1F0]
00007871bd3d8bee  movaps xmm6, xmm12
00007871bd3d8bf2  mulpd xmm6, xmm11
00007871bd3d8bf7  vcmppd xmm5, xmm6, xmm6, 0x03
00007871bd3d8bfc  ptest xmm5, xmm5
00007871bd3d8c01  jnz 0x00007871BD3D9EA5
00007871bd3d8c07  movaps xmm12, [r15+0x2A0]
00007871bd3d8c0f  vmovaps [rsp+0x80], xmm12
00007871bd3d8c18  vmovaps xmm11, [rsp+0x80]
00007871bd3d8c21  por xmm12, xmm11
00007871bd3d8c26  movaps xmm11, [r15+0x250]
00007871bd3d8c2e  vmovaps [rsp+0x80], xmm11
00007871bd3d8c37  vmovaps xmm5, [rsp+0x80]
00007871bd3d8c40  por xmm11, xmm5
00007871bd3d8c45  vmovaps xmm4, [rsp+0x70]
00007871bd3d8c4b  vpermilpd xmm4, xmm4, 0x00
00007871bd3d8c51  movaps xmm3, xmm5
00007871bd3d8c54  mulpd xmm3, xmm4
00007871bd3d8c58  vcmppd xmm2, xmm3, xmm3, 0x03
00007871bd3d8c5d  ptest xmm2, xmm2
00007871bd3d8c62  jnz 0x00007871BD3D9FE7
00007871bd3d8c68  mov [rsp+0x80], rax
00007871bd3d8c70  xor eax, eax
00007871bd3d8c72  mov r14d, 0x200
00007871bd3d8c78  cmp r12, r14
00007871bd3d8c7b  cmc
00007871bd3d8c7c  lahf
00007871bd3d8c7d  seto al
00007871bd3d8c80  mov [r15+0x108], eax
00007871bd3d8c87  movaps xmm5, xmm8
00007871bd3d8c8b  addpd xmm5, xmm15
00007871bd3d8c90  vcmppd xmm4, xmm5, xmm5, 0x03
00007871bd3d8c95  ptest xmm4, xmm4
00007871bd3d8c9a  jnz 0x00007871BD3DA127
00007871bd3d8ca0  movaps xmm8, [r15+0x1B0]
00007871bd3d8ca8  movaps xmm4, xmm9
00007871bd3d8cac  addpd xmm4, xmm8
00007871bd3d8cb1  vcmppd xmm2, xmm4, xmm4, 0x03
00007871bd3d8cb6  ptest xmm2, xmm2
00007871bd3d8cbb  jnz 0x00007871BD3DA269
00007871bd3d8cc1  movaps xmm9, xmm10
00007871bd3d8cc5  addpd xmm9, xmm8
00007871bd3d8cca  vcmppd xmm2, xmm9, xmm9, 0x03
00007871bd3d8cd0  ptest xmm2, xmm2
00007871bd3d8cd5  jnz 0x00007871BD3DA3AB
00007871bd3d8cdb  movaps xmm10, [r15+0x2F0]
00007871bd3d8ce3  vmovaps [rsp+0x90], xmm10
00007871bd3d8cec  vmovaps xmm8, [rsp+0x90]
00007871bd3d8cf5  por xmm10, xmm8
00007871bd3d8cfa  movaps xmm8, [r15+0x2E0]
00007871bd3d8d02  vmovaps [rsp+0x90], xmm8
00007871bd3d8d0b  vmovaps xmm2, [rsp+0x90]
00007871bd3d8d14  por xmm8, xmm2
00007871bd3d8d19  movaps xmm2, [r15+0x2D0]
00007871bd3d8d21  vmovaps [rsp+0x90], xmm2
00007871bd3d8d2a  vmovaps [rsp+0xA0], xmm1
00007871bd3d8d33  vmovaps xmm1, [rsp+0x90]
00007871bd3d8d3c  por xmm2, xmm1
00007871bd3d8d40  movaps xmm1, [r15+0x200]
00007871bd3d8d48  vmovaps [rsp+0x90], xmm1
00007871bd3d8d51  vmovaps [rsp+0xB0], xmm15
00007871bd3d8d5a  vmovaps xmm15, [rsp+0x90]
00007871bd3d8d63  por xmm1, xmm15
00007871bd3d8d68  movaps xmm15, [r15+0x1C0]
00007871bd3d8d70  vmovaps [rsp+0x90], xmm15
00007871bd3d8d79  vmovaps [rsp+0xC0], xmm1
00007871bd3d8d82  vmovaps xmm1, [rsp+0x90]
00007871bd3d8d8b  por xmm15, xmm1
00007871bd3d8d90  movaps xmm1, [r15+0x190]
00007871bd3d8d98  vmovaps [rsp+0x90], xmm1
00007871bd3d8da1  vmovaps [rsp+0xD0], xmm15
00007871bd3d8daa  vmovaps xmm15, [rsp+0x90]
00007871bd3d8db3  por xmm1, xmm15
00007871bd3d8db8  movaps xmm15, [r15+0x300]
00007871bd3d8dc0  vmovaps [rsp+0x90], xmm15
00007871bd3d8dc9  vmovaps [rsp+0xE0], xmm1
00007871bd3d8dd2  vmovaps xmm1, [rsp+0x90]
00007871bd3d8ddb  por xmm15, xmm1
00007871bd3d8de0  mov rax, [rsp+0x80]
00007871bd3d8de8  lea r14, [rax+0xA0]
00007871bd3d8def  movups xmm1, [r13+r14*1]
00007871bd3d8df5  lea r14, [rax+0xB0]
00007871bd3d8dfc  vmovaps [rsp+0x80], xmm1
00007871bd3d8e05  movups xmm1, [r13+r14*1]
00007871bd3d8e0b  vmovaps [rsp+0x90], xmm1
00007871bd3d8e14  vmovaps [rsp+0xF0], xmm15
00007871bd3d8e1d  vmovaps xmm15, [rsp+0xB0]
00007871bd3d8e26  vmovaps [rsp+0xB0], xmm14
00007871bd3d8e2f  movaps xmm1, xmm6
00007871bd3d8e32  addpd xmm1, xmm15
00007871bd3d8e37  vcmppd xmm14, xmm1, xmm1, 0x03
00007871bd3d8e3c  ptest xmm14, xmm14
00007871bd3d8e42  jnz 0x00007871BD3DA503
00007871bd3d8e48  lea r14, [rax+0xF0]
00007871bd3d8e4f  movups xmm15, [r13+r14*1]
00007871bd3d8e55  movaps xmm14, xmm4
00007871bd3d8e59  addpd xmm14, xmm3
00007871bd3d8e5e  vcmppd xmm6, xmm14, xmm14, 0x03
00007871bd3d8e64  ptest xmm6, xmm6
00007871bd3d8e69  jnz 0x00007871BD3DA64E
00007871bd3d8e6f  movaps xmm6, xmm9
00007871bd3d8e73  addpd xmm6, xmm7
00007871bd3d8e77  vcmppd xmm4, xmm6, xmm6, 0x03
00007871bd3d8e7c  ptest xmm4, xmm4
00007871bd3d8e81  jnz 0x00007871BD3DA790
00007871bd3d8e87  vmovaps xmm9, [rsp+0x70]
00007871bd3d8e8d  vpermilpd xmm9, xmm9, 0x00
00007871bd3d8e93  vmovaps xmm4, [rsp+0x90]
00007871bd3d8e9c  movaps xmm7, xmm4
00007871bd3d8e9f  mulpd xmm7, xmm9
00007871bd3d8ea4  vcmppd xmm3, xmm7, xmm7, 0x03
00007871bd3d8ea9  ptest xmm3, xmm3
00007871bd3d8eae  jnz 0x00007871BD3DA8D1
00007871bd3d8eb4  vmovaps xmm9, [rsp+0x50]
00007871bd3d8eba  vpermilpd xmm9, xmm9, 0x00
00007871bd3d8ec0  movaps xmm4, xmm15
00007871bd3d8ec4  mulpd xmm4, xmm9
00007871bd3d8ec9  vcmppd xmm3, xmm4, xmm4, 0x03
00007871bd3d8ece  ptest xmm3, xmm3
00007871bd3d8ed3  jnz 0x00007871BD3DAA12
00007871bd3d8ed9  lea r14, [rax+0xE0]
00007871bd3d8ee0  movups xmm15, [r13+r14*1]
00007871bd3d8ee6  vmovaps xmm9, [rsp+0x70]
00007871bd3d8eec  vpermilpd xmm9, xmm9, 0x00
00007871bd3d8ef2  vmovaps [rsp+0x70], xmm1
00007871bd3d8ef8  vmovaps xmm1, [rsp+0x80]
00007871bd3d8f01  vmovaps [rsp+0x80], xmm15
00007871bd3d8f0a  movaps xmm3, xmm1
00007871bd3d8f0d  mulpd xmm3, xmm9
00007871bd3d8f12  vcmppd xmm15, xmm3, xmm3, 0x03
00007871bd3d8f17  ptest xmm15, xmm15
00007871bd3d8f1d  jnz 0x00007871BD3DAB5E
00007871bd3d8f23  vmovaps xmm1, [rsp+0xF0]
00007871bd3d8f2c  vmovaps xmm15, [rsp+0xF0]
00007871bd3d8f35  por xmm1, xmm15
00007871bd3d8f3a  movaps [r15+0x300], xmm1
00007871bd3d8f42  vmovaps xmm15, [rsp+0xE0]
00007871bd3d8f4b  vmovaps xmm9, [rsp+0xE0]
00007871bd3d8f54  por xmm15, xmm9
00007871bd3d8f59  movaps [r15+0x190], xmm15
00007871bd3d8f61  vmovaps xmm9, [rsp+0x50]
00007871bd3d8f67  vpermilpd xmm9, xmm9, 0x00
00007871bd3d8f6d  vmovaps [rsp+0x90], xmm1
00007871bd3d8f76  vmovaps [rsp+0xE0], xmm15
00007871bd3d8f7f  vmovaps xmm15, [rsp+0x80]
00007871bd3d8f88  vmovaps [rsp+0x80], xmm14
00007871bd3d8f91  movaps xmm1, xmm15
00007871bd3d8f95  mulpd xmm1, xmm9
00007871bd3d8f9a  vcmppd xmm14, xmm1, xmm1, 0x03
00007871bd3d8f9f  ptest xmm14, xmm14
00007871bd3d8fa5  jnz 0x00007871BD3DAC9F
00007871bd3d8fab  lea r14, [rax+0x90]
00007871bd3d8fb2  movups xmm15, [r13+r14*1]
00007871bd3d8fb8  vmovaps xmm14, [rsp+0xD0]
00007871bd3d8fc1  vmovaps xmm9, [rsp+0xD0]
00007871bd3d8fca  por xmm14, xmm9
00007871bd3d8fcf  movaps [r15+0x1C0], xmm14
00007871bd3d8fd7  vmovaps xmm9, [rsp+0xC0]
00007871bd3d8fe0  vmovaps [rsp+0xD0], xmm1
00007871bd3d8fe9  vmovaps xmm1, [rsp+0xC0]
00007871bd3d8ff2  por xmm9, xmm1
00007871bd3d8ff7  movaps [r15+0x200], xmm9
00007871bd3d8fff  vmovaps [rsp+0xC0], xmm2
00007871bd3d9008  vmovaps xmm1, [rsp+0xC0]
00007871bd3d9011  por xmm2, xmm1
00007871bd3d9015  movaps [r15+0x2D0], xmm2
00007871bd3d901d  vmovaps [rsp+0xC0], xmm8
00007871bd3d9026  vmovaps xmm1, [rsp+0xC0]
00007871bd3d902f  por xmm8, xmm1
00007871bd3d9034  movaps [r15+0x2E0], xmm8
00007871bd3d903c  vmovaps [rsp+0xC0], xmm15
00007871bd3d9045  movaps xmm1, xmm5
00007871bd3d9048  addpd xmm1, xmm7
00007871bd3d904c  vcmppd xmm15, xmm1, xmm1, 0x03
00007871bd3d9051  ptest xmm15, xmm15
00007871bd3d9057  jnz 0x00007871BD3DADEB
00007871bd3d905d  vmovaps xmm15, [rsp+0x50]
00007871bd3d9063  vpermilpd xmm15, xmm15, 0x00
00007871bd3d9069  vmovaps xmm5, [rsp+0xC0]
00007871bd3d9072  vmovaps [rsp+0xC0], xmm1
00007871bd3d907b  movaps xmm7, xmm5
00007871bd3d907e  mulpd xmm7, xmm15
00007871bd3d9083  vcmppd xmm1, xmm7, xmm7, 0x03
00007871bd3d9088  ptest xmm1, xmm1
00007871bd3d908d  jnz 0x00007871BD3DAF2B
00007871bd3d9093  lea r14, [rax+0x80]
00007871bd3d909a  movups xmm1, [r13+r14*1]
00007871bd3d90a0  vmovaps xmm5, [rsp+0x70]
00007871bd3d90a6  vmovaps [rsp+0x70], xmm1
00007871bd3d90ac  movaps xmm15, xmm5
00007871bd3d90b0  addpd xmm15, xmm3
00007871bd3d90b5  vcmppd xmm1, xmm15, xmm15, 0x03
00007871bd3d90bb  ptest xmm1, xmm1
00007871bd3d90c0  jnz 0x00007871BD3DB076
00007871bd3d90c6  vmovaps xmm5, [rsp+0x80]
00007871bd3d90cf  movaps xmm1, xmm5
00007871bd3d90d2  addpd xmm1, xmm4
00007871bd3d90d6  vcmppd xmm3, xmm1, xmm1, 0x03
00007871bd3d90db  ptest xmm3, xmm3
00007871bd3d90e0  jnz 0x00007871BD3DB1B8
00007871bd3d90e6  vmovaps [rsp+0x80], xmm10
00007871bd3d90ef  vmovaps xmm5, [rsp+0x80]
00007871bd3d90f8  por xmm10, xmm5
00007871bd3d90fd  movaps [r15+0x2F0], xmm10
00007871bd3d9105  vmovaps xmm5, [rsp+0x50]
00007871bd3d910b  vpermilpd xmm5, xmm5, 0x00
00007871bd3d9111  vmovaps xmm3, [rsp+0x70]
00007871bd3d9117  vmovaps [rsp+0x50], xmm1
00007871bd3d911d  movaps xmm4, xmm3
00007871bd3d9120  mulpd xmm4, xmm5
00007871bd3d9124  vcmppd xmm1, xmm4, xmm4, 0x03
00007871bd3d9129  ptest xmm1, xmm1
00007871bd3d912e  jnz 0x00007871BD3DB2F8
00007871bd3d9134  lea r14, [rax+0xD0]
00007871bd3d913b  movups xmm1, [r13+r14*1]
00007871bd3d9141  vmovaps xmm3, [rsp+0xD0]
00007871bd3d914a  vmovaps [rsp+0x70], xmm1
00007871bd3d9150  movaps xmm5, xmm6
00007871bd3d9153  addpd xmm5, xmm3
00007871bd3d9157  vcmppd xmm1, xmm5, xmm5, 0x03
00007871bd3d915c  ptest xmm1, xmm1
00007871bd3d9161  jnz 0x00007871BD3DB442
00007871bd3d9167  vmovaps xmm1, [rsp+0x60]
00007871bd3d916d  vpermilpd xmm1, xmm1, 0x00
00007871bd3d9173  movaps xmm6, xmm9
00007871bd3d9177  mulpd xmm6, xmm1
00007871bd3d917b  vcmppd xmm3, xmm6, xmm6, 0x03
00007871bd3d9180  ptest xmm3, xmm3
00007871bd3d9185  jnz 0x00007871BD3DB582
00007871bd3d918b  movaps [r15+0x260], xmm6
00007871bd3d9193  vxorps xmm1, xmm1, xmm1
00007871bd3d9197  vpbroadcastq xmm1, xmm1
00007871bd3d919c  movaps [r15+0x1B0], xmm1
00007871bd3d91a4  vmovaps xmm1, [rsp+0x60]
00007871bd3d91aa  vpermilpd xmm1, xmm1, 0x00
00007871bd3d91b0  vmovaps xmm3, [rsp+0x70]
00007871bd3d91b6  vmovaps [rsp+0x70], xmm15
00007871bd3d91bc  movaps xmm9, xmm3
00007871bd3d91c0  mulpd xmm9, xmm1
00007871bd3d91c5  vcmppd xmm15, xmm9, xmm9, 0x03
00007871bd3d91cb  ptest xmm15, xmm15
00007871bd3d91d1  jnz 0x00007871BD3DB6C3
00007871bd3d91d7  lea r14, [rax+0xC0]
00007871bd3d91de  movups xmm1, [r13+r14*1]
00007871bd3d91e4  vmovaps xmm3, [rsp+0xC0]
00007871bd3d91ed  vmovaps [rsp+0x80], xmm1
00007871bd3d91f6  movaps xmm15, xmm3
00007871bd3d91fa  addpd xmm15, xmm7
00007871bd3d91ff  vcmppd xmm1, xmm15, xmm15, 0x03
00007871bd3d9205  ptest xmm1, xmm1
00007871bd3d920a  jnz 0x00007871BD3DB80F
00007871bd3d9210  vmovaps [rsp+0xC0], xmm13
00007871bd3d9219  vmovaps xmm1, [rsp+0xC0]
00007871bd3d9222  por xmm13, xmm1
00007871bd3d9227  movaps [r15+0x270], xmm13
00007871bd3d922f  vmovaps xmm1, [rsp+0xB0]
00007871bd3d9238  vmovaps xmm7, [rsp+0xB0]
00007871bd3d9241  por xmm1, xmm7
00007871bd3d9245  movaps [r15+0x1A0], xmm1
00007871bd3d924d  vmovaps xmm1, [rsp+0x60]
00007871bd3d9253  vpermilpd xmm1, xmm1, 0x00
00007871bd3d9259  vmovaps [rsp+0xB0], xmm1
00007871bd3d9262  vmovaps xmm1, [rsp+0x80]
00007871bd3d926b  vmovaps [rsp+0x80], xmm15
00007871bd3d9274  vmovaps xmm15, [rsp+0xB0]
00007871bd3d927d  vmovaps [rsp+0xB0], xmm14
00007871bd3d9286  movaps xmm3, xmm1
00007871bd3d9289  mulpd xmm3, xmm15
00007871bd3d928e  vcmppd xmm14, xmm3, xmm3, 0x03
00007871bd3d9293  ptest xmm14, xmm14
00007871bd3d9299  jnz 0x00007871BD3DB951
00007871bd3d929f  lea r14, [rax+0x20]
00007871bd3d92a3  movups xmm1, [r13+r14*1]
00007871bd3d92a9  movaps [r15+0x110], xmm1
00007871bd3d92b1  vmovaps xmm14, [rsp+0x70]
00007871bd3d92b7  vmovaps [rsp+0x70], xmm1
00007871bd3d92bd  movaps xmm15, xmm14
00007871bd3d92c1  addpd xmm15, xmm4
00007871bd3d92c6  vcmppd xmm1, xmm15, xmm15, 0x03
00007871bd3d92cc  ptest xmm1, xmm1
00007871bd3d92d1  jnz 0x00007871BD3DBA9C
00007871bd3d92d7  vmovaps xmm1, [rsp+0x60]
00007871bd3d92dd  vpermilpd xmm1, xmm1, 0x00
00007871bd3d92e3  movaps xmm14, xmm2
00007871bd3d92e7  mulpd xmm14, xmm1
00007871bd3d92ec  vcmppd xmm4, xmm14, xmm14, 0x03
00007871bd3d92f2  ptest xmm4, xmm4
00007871bd3d92f7  jnz 0x00007871BD3DBBDF
00007871bd3d92fd  vmovaps xmm4, [rsp+0x50]
00007871bd3d9303  movaps xmm1, xmm4
00007871bd3d9306  addpd xmm1, xmm9
00007871bd3d930b  vcmppd xmm2, xmm1, xmm1, 0x03
00007871bd3d9310  ptest xmm2, xmm2
00007871bd3d9315  jnz 0x00007871BD3DBD21
00007871bd3d931b  vmovaps xmm9, [rsp+0x30]
00007871bd3d9321  vpermilpd xmm9, xmm9, 0x00
00007871bd3d9327  vmovaps xmm2, [rsp+0x70]
00007871bd3d932d  vmovaps [rsp+0x50], xmm1
00007871bd3d9333  movaps xmm4, xmm2
00007871bd3d9336  mulpd xmm4, xmm9
00007871bd3d933b  vcmppd xmm1, xmm4, xmm4, 0x03
00007871bd3d9340  ptest xmm1, xmm1
00007871bd3d9345  jnz 0x00007871BD3DBE62
00007871bd3d934b  vmovaps xmm1, [rsp+0x30]
00007871bd3d9351  vpermilpd xmm1, xmm1, 0x00
00007871bd3d9357  vmovaps xmm2, [rsp+0x90]
00007871bd3d9360  vmovaps [rsp+0x60], xmm15
00007871bd3d9366  movaps xmm9, xmm2
00007871bd3d936a  mulpd xmm9, xmm1
00007871bd3d936f  vcmppd xmm15, xmm9, xmm9, 0x03
00007871bd3d9375  ptest xmm15, xmm15
00007871bd3d937b  jnz 0x00007871BD3DBFA3
00007871bd3d9381  vmovaps xmm15, [rsp+0x80]
00007871bd3d938a  movaps xmm1, xmm15
00007871bd3d938e  addpd xmm1, xmm6
00007871bd3d9392  vcmppd xmm2, xmm1, xmm1, 0x03
00007871bd3d9397  ptest xmm2, xmm2
00007871bd3d939c  jnz 0x00007871BD3DC0E5
00007871bd3d93a2  movaps xmm15, xmm5
00007871bd3d93a6  addpd xmm15, xmm3
00007871bd3d93ab  vcmppd xmm6, xmm15, xmm15, 0x03
00007871bd3d93b1  ptest xmm6, xmm6
00007871bd3d93b6  jnz 0x00007871BD3DC226
00007871bd3d93bc  vmovaps xmm6, [rsp+0x30]
00007871bd3d93c2  vpermilpd xmm6, xmm6, 0x00
00007871bd3d93c8  movaps xmm5, xmm8
00007871bd3d93cc  mulpd xmm5, xmm6
00007871bd3d93d0  vcmppd xmm3, xmm5, xmm5, 0x03
00007871bd3d93d5  ptest xmm3, xmm3
00007871bd3d93da  jnz 0x00007871BD3DC368
00007871bd3d93e0  vmovaps xmm8, [rsp+0x30]
00007871bd3d93e6  vpermilpd xmm8, xmm8, 0x00
00007871bd3d93ec  movaps xmm6, xmm10
00007871bd3d93f0  mulpd xmm6, xmm8
00007871bd3d93f5  vcmppd xmm3, xmm6, xmm6, 0x03
00007871bd3d93fa  ptest xmm3, xmm3
00007871bd3d93ff  jnz 0x00007871BD3DC4A9
00007871bd3d9405  vmovaps xmm8, [rsp+0x60]
00007871bd3d940b  movaps xmm10, xmm8
00007871bd3d940f  addpd xmm10, xmm14
00007871bd3d9414  vcmppd xmm3, xmm10, xmm10, 0x03
00007871bd3d941a  ptest xmm3, xmm3
00007871bd3d941f  jnz 0x00007871BD3DC5EB
00007871bd3d9425  vmovaps xmm8, [rsp+0x50]
00007871bd3d942b  movaps xmm14, xmm8
00007871bd3d942f  addpd xmm14, xmm4
00007871bd3d9434  vcmppd xmm3, xmm14, xmm14, 0x03
00007871bd3d943a  ptest xmm3, xmm3
00007871bd3d943f  jnz 0x00007871BD3DC72F
00007871bd3d9445  vmovaps xmm8, [rsp+0x40]
00007871bd3d944b  vpermilpd xmm8, xmm8, 0x00
00007871bd3d9451  movaps xmm4, xmm13
00007871bd3d9455  mulpd xmm4, xmm8
00007871bd3d945a  vcmppd xmm3, xmm4, xmm4, 0x03
00007871bd3d945f  ptest xmm3, xmm3
00007871bd3d9464  jnz 0x00007871BD3DC872
00007871bd3d946a  movaps xmm13, xmm15
00007871bd3d946e  addpd xmm13, xmm9
00007871bd3d9473  vcmppd xmm8, xmm13, xmm13, 0x03
00007871bd3d9479  ptest xmm8, xmm8
00007871bd3d947f  jnz 0x00007871BD3DC9B4
00007871bd3d9485  movaps xmm15, xmm1
00007871bd3d9489  addpd xmm15, xmm5
00007871bd3d948e  vcmppd xmm9, xmm15, xmm15, 0x03
00007871bd3d9494  ptest xmm9, xmm9
00007871bd3d949a  jnz 0x00007871BD3DCAF8
00007871bd3d94a0  vmovaps [rsp+0x30], xmm11
00007871bd3d94a6  vmovaps xmm1, [rsp+0x30]
00007871bd3d94ac  por xmm11, xmm1
00007871bd3d94b1  movaps [r15+0x250], xmm11
00007871bd3d94b9  vmovaps [rsp+0x30], xmm12
00007871bd3d94bf  vmovaps xmm1, [rsp+0x30]
00007871bd3d94c5  por xmm12, xmm1
00007871bd3d94ca  movaps [r15+0x2A0], xmm12
00007871bd3d94d2  vmovaps xmm1, [rsp+0xA0]
00007871bd3d94db  vmovaps xmm11, [rsp+0xA0]
00007871bd3d94e4  por xmm1, xmm11
00007871bd3d94e9  movaps [r15+0x1D0], xmm1
00007871bd3d94f1  lea r14, [rax+0x40]
00007871bd3d94f5  movups xmm1, [r13+r14*1]
00007871bd3d94fb  movaps [r15+0x2C0], xmm1
00007871bd3d9503  vmovaps xmm11, [rsp+0x40]
00007871bd3d9509  vpermilpd xmm11, xmm11, 0x00
00007871bd3d950f  vmovaps xmm8, [rsp+0xE0]
00007871bd3d9518  movaps xmm9, xmm8
00007871bd3d951c  mulpd xmm9, xmm11
00007871bd3d9521  vcmppd xmm5, xmm9, xmm9, 0x03
00007871bd3d9527  ptest xmm5, xmm5
00007871bd3d952c  jnz 0x00007871BD3DCC44
00007871bd3d9532  movaps xmm11, xmm10
00007871bd3d9536  addpd xmm11, xmm6
00007871bd3d953b  vcmppd xmm8, xmm11, xmm11, 0x03
00007871bd3d9541  ptest xmm8, xmm8
00007871bd3d9547  jnz 0x00007871BD3DCD88
00007871bd3d954d  movaps xmm10, xmm14
00007871bd3d9551  addpd xmm10, xmm4
00007871bd3d9556  vcmppd xmm8, xmm10, xmm10, 0x03
00007871bd3d955c  ptest xmm8, xmm8
00007871bd3d9562  jnz 0x00007871BD3DCECB
00007871bd3d9568  vmovaps xmm14, [rsp+0x40]
00007871bd3d956e  vpermilpd xmm14, xmm14, 0x00
00007871bd3d9574  movaps xmm8, xmm1
00007871bd3d9578  mulpd xmm8, xmm14
00007871bd3d957d  vcmppd xmm6, xmm8, xmm8, 0x03
00007871bd3d9583  ptest xmm6, xmm6
00007871bd3d9588  jnz 0x00007871BD3DD00E
00007871bd3d958e  movaps xmm1, [r15+0x2B0]
00007871bd3d9596  vmovaps xmm14, [rsp+0x40]
00007871bd3d959c  vpermilpd xmm14, xmm14, 0x00
00007871bd3d95a2  movaps xmm6, xmm1
00007871bd3d95a5  mulpd xmm6, xmm14
00007871bd3d95aa  vcmppd xmm5, xmm6, xmm6, 0x03
00007871bd3d95af  ptest xmm5, xmm5
00007871bd3d95b4  jnz 0x00007871BD3DD151
00007871bd3d95ba  vmovaps xmm1, [rsp+0x10]
00007871bd3d95c0  vpermilpd xmm1, xmm1, 0x00
00007871bd3d95c6  movaps xmm14, xmm12
00007871bd3d95ca  mulpd xmm14, xmm1
00007871bd3d95cf  vcmppd xmm5, xmm14, xmm14, 0x03
00007871bd3d95d5  ptest xmm5, xmm5
00007871bd3d95da  jnz 0x00007871BD3DD292
00007871bd3d95e0  movaps xmm1, xmm13
00007871bd3d95e4  addpd xmm1, xmm9
00007871bd3d95e9  vcmppd xmm12, xmm1, xmm1, 0x03
00007871bd3d95ee  ptest xmm12, xmm12
00007871bd3d95f4  jnz 0x00007871BD3DD3D5
00007871bd3d95fa  vmovaps xmm13, [rsp+0x10]
00007871bd3d9600  vpermilpd xmm13, xmm13, 0x00
00007871bd3d9606  movaps xmm12, xmm7
00007871bd3d960a  mulpd xmm12, xmm13
00007871bd3d960f  vcmppd xmm9, xmm12, xmm12, 0x03
00007871bd3d9615  ptest xmm9, xmm9
00007871bd3d961b  jnz 0x00007871BD3DD517
00007871bd3d9621  movaps xmm13, xmm15
00007871bd3d9625  addpd xmm13, xmm8
00007871bd3d962a  vcmppd xmm9, xmm13, xmm13, 0x03
00007871bd3d9630  ptest xmm9, xmm9
00007871bd3d9636  jnz 0x00007871BD3DD65A
00007871bd3d963c  movaps xmm15, [r15+0x290]
00007871bd3d9644  vmovaps xmm9, [rsp+0x10]
00007871bd3d964a  vpermilpd xmm9, xmm9, 0x00
00007871bd3d9650  movaps xmm8, xmm15
00007871bd3d9654  mulpd xmm8, xmm9
00007871bd3d9659  vcmppd xmm7, xmm8, xmm8, 0x03
00007871bd3d965f  ptest xmm7, xmm7
00007871bd3d9664  jnz 0x00007871BD3DD79E
00007871bd3d966a  movaps xmm15, xmm11
00007871bd3d966e  addpd xmm15, xmm6
00007871bd3d9673  vcmppd xmm9, xmm15, xmm15, 0x03
00007871bd3d9679  ptest xmm9, xmm9
00007871bd3d967f  jnz 0x00007871BD3DD8E2
00007871bd3d9685  movaps xmm11, [r15+0x1E0]
00007871bd3d968d  vmovaps xmm9, [rsp+0x10]
00007871bd3d9693  vpermilpd xmm9, xmm9, 0x00
00007871bd3d9699  movaps xmm7, xmm11
00007871bd3d969d  mulpd xmm7, xmm9
00007871bd3d96a2  vcmppd xmm6, xmm7, xmm7, 0x03
00007871bd3d96a7  ptest xmm6, xmm6
00007871bd3d96ac  jnz 0x00007871BD3DDA25
00007871bd3d96b2  movaps xmm11, xmm10
00007871bd3d96b6  addpd xmm11, xmm14
00007871bd3d96bb  vcmppd xmm9, xmm11, xmm11, 0x03
00007871bd3d96c1  ptest xmm9, xmm9
00007871bd3d96c7  jnz 0x00007871BD3DDB67
00007871bd3d96cd  lea r14, [rax+0x70]
00007871bd3d96d1  movups xmm14, [r13+r14*1]
00007871bd3d96d7  movaps [r15+0x240], xmm14
00007871bd3d96df  movaps xmm10, xmm1
00007871bd3d96e3  addpd xmm10, xmm12
00007871bd3d96e8  vcmppd xmm9, xmm10, xmm10, 0x03
00007871bd3d96ee  ptest xmm9, xmm9
00007871bd3d96f4  jnz 0x00007871BD3DDCB5
00007871bd3d96fa  movaps [r15+0x170], xmm10
00007871bd3d9702  vmovaps xmm1, [rsp+0x20]
00007871bd3d9708  vpermilpd xmm1, xmm1, 0x00
00007871bd3d970e  movaps xmm12, xmm14
00007871bd3d9712  mulpd xmm12, xmm1
00007871bd3d9717  vcmppd xmm9, xmm12, xmm12, 0x03
00007871bd3d971d  ptest xmm9, xmm9
00007871bd3d9723  jnz 0x00007871BD3DDDF8
00007871bd3d9729  vmovaps xmm1, [rsp+0x20]
00007871bd3d972f  vpermilpd xmm1, xmm1, 0x00
00007871bd3d9735  vmovaps xmm9, [rsp+0xB0]
00007871bd3d973e  movaps xmm14, xmm9
00007871bd3d9742  mulpd xmm14, xmm1
00007871bd3d9747  vcmppd xmm6, xmm14, xmm14, 0x03
00007871bd3d974d  ptest xmm6, xmm6
00007871bd3d9752  jnz 0x00007871BD3DDF3B
00007871bd3d9758  movaps [r15+0x180], xmm14
00007871bd3d9760  movaps xmm1, xmm13
00007871bd3d9764  addpd xmm1, xmm8
00007871bd3d9769  vcmppd xmm9, xmm1, xmm1, 0x03
00007871bd3d976e  ptest xmm9, xmm9
00007871bd3d9774  jnz 0x00007871BD3DE07E
00007871bd3d977a  movaps [r15+0x210], xmm1
00007871bd3d9782  movups xmm13, [r13+rax*1]
00007871bd3d9788  lea r14, [rax+0x10]
00007871bd3d978c  movups xmm9, [r13+r14*1]
00007871bd3d9792  movaps [r15+0x230], xmm9
00007871bd3d979a  movaps xmm8, xmm15
00007871bd3d979e  addpd xmm8, xmm7
00007871bd3d97a3  vcmppd xmm6, xmm8, xmm8, 0x03
00007871bd3d97a9  ptest xmm6, xmm6
00007871bd3d97ae  jnz 0x00007871BD3DE1D4
00007871bd3d97b4  movaps [r15+0x130], xmm8
00007871bd3d97bc  vmovaps xmm15, [rsp+0x20]
00007871bd3d97c2  vpermilpd xmm15, xmm15, 0x00
00007871bd3d97c8  movaps xmm7, xmm9
00007871bd3d97cc  mulpd xmm7, xmm15
00007871bd3d97d1  vcmppd xmm6, xmm7, xmm7, 0x03
00007871bd3d97d6  ptest xmm6, xmm6
00007871bd3d97db  jnz 0x00007871BD3DE317
00007871bd3d97e1  movaps [r15+0x220], xmm7
00007871bd3d97e9  vmovaps xmm15, [rsp+0x20]
00007871bd3d97ef  vpermilpd xmm15, xmm15, 0x00
00007871bd3d97f5  movaps xmm9, xmm13
00007871bd3d97f9  mulpd xmm9, xmm15
00007871bd3d97fe  vcmppd xmm6, xmm9, xmm9, 0x03
00007871bd3d9804  ptest xmm6, xmm6
00007871bd3d9809  jnz 0x00007871BD3DE459
00007871bd3d980f  movaps xmm15, xmm11
00007871bd3d9813  addpd xmm15, xmm12
00007871bd3d9818  vcmppd xmm13, xmm15, xmm15, 0x03
00007871bd3d981e  ptest xmm13, xmm13
00007871bd3d9824  jnz 0x00007871BD3DE59D
00007871bd3d982a  movaps [r15+0x140], xmm15
00007871bd3d9832  movaps xmm13, xmm10
00007871bd3d9836  addpd xmm13, xmm14
00007871bd3d983b  vcmppd xmm12, xmm13, xmm13, 0x03
00007871bd3d9841  ptest xmm12, xmm12
00007871bd3d9847  jnz 0x00007871BD3DE6E1
00007871bd3d984d  movaps [r15+0x150], xmm13
00007871bd3d9855  movaps xmm14, xmm1
00007871bd3d9859  addpd xmm14, xmm7
00007871bd3d985e  vcmppd xmm12, xmm14, xmm14, 0x03
00007871bd3d9864  ptest xmm12, xmm12
00007871bd3d986a  jnz 0x00007871BD3DE825
00007871bd3d9870  movaps [r15+0x160], xmm14
00007871bd3d9878  movaps xmm1, xmm8
00007871bd3d987c  addpd xmm1, xmm9
00007871bd3d9881  vcmppd xmm12, xmm1, xmm1, 0x03
00007871bd3d9886  ptest xmm12, xmm12
00007871bd3d988c  jnz 0x00007871BD3DE967
00007871bd3d9892  movaps [r15+0x120], xmm1
00007871bd3d989a  movups [r13+r11*1], xmm15
00007871bd3d98a0  lea rax, [r11+0x10]
00007871bd3d98a4  movups [r13+rax*1], xmm13
00007871bd3d98aa  lea rax, [r11+0x20]
00007871bd3d98ae  movups [r13+rax*1], xmm14
00007871bd3d98b4  lea rax, [r11+0x30]
00007871bd3d98b8  movups [r13+rax*1], xmm1
00007871bd3d98be  mov eax, [r15+0x108]
00007871bd3d98c5  sahf
00007871bd3d98c6  jnz 0x00007871BD3D98F8
00007871bd3d98c8  cmp dword ptr [r15+0x318], 0x00
00007871bd3d98d0  jz 0x00007871BD3DEAE0
00007871bd3d98d6  nop [rax+rax*1], ax
00007871bd3d98df  nop [rax+rax*1], eax
00007871bd3d98e7  mov eax, 0x4106D0
00007871bd3d98ec  mov [r15+0x100], rax
00007871bd3d98f3  jmp 0x00007871BD1FE110
00007871bd3d98f8  cmp dword ptr [r15+0x318], 0x00
00007871bd3d9900  jz 0x00007871BD3D89C0
00007871bd3d9906  nop [rax+rax*1], ax
00007871bd3d990f  nop [rax+rax*1], eax
00007871bd3d9917  mov eax, 0x410504
00007871bd3d991c  mov [r15+0x100], rax
00007871bd3d9923  jmp 0x00007871BD1FE110
00007871bd3d9928  int3
00007871bd3d9929  call 0x00007871BD20A4B0
00007871bd3d992e  jmp 0x00007871BD3D8A08
00007871bd3d9933  call 0x00007871BD209240
00007871bd3d9938  jmp 0x00007871BD3D8A12
00007871bd3d993d  call 0x00007871BD20A4B0
00007871bd3d9942  jmp 0x00007871BD3D8A6F
00007871bd3d9947  call 0x00007871BD209240
00007871bd3d994c  jmp 0x00007871BD3D8A79
00007871bd3d9951  call 0x00007871BD20A4B0
00007871bd3d9956  jmp 0x00007871BD3D8ABD
00007871bd3d995b  call 0x00007871BD209240
00007871bd3d9960  jmp 0x00007871BD3D8AC7
00007871bd3d9965  call 0x00007871BD2B47C0
00007871bd3d996a  jmp 0x00007871BD3D8B06
00007871bd3d996f  call 0x00007871BD20B720
00007871bd3d9974  jmp 0x00007871BD3D8B1A
00007871bd3d9979  call 0x00007871BD2BFC30
00007871bd3d997e  jmp 0x00007871BD3D8B38
00007871bd3d9983  call 0x00007871BD2BE9C0
00007871bd3d9988  jmp 0x00007871BD3D8B42
00007871bd3d998d  call 0x00007871BD2BD750
00007871bd3d9992  jmp 0x00007871BD3D8B4C
00007871bd3d9997  sub rsp, 0x08
00007871bd3d999b  push rax
00007871bd3d999c  push rcx
00007871bd3d999d  push rdx
00007871bd3d999e  push rdi
00007871bd3d999f  push rsi
00007871bd3d99a0  push r8
00007871bd3d99a2  push r9
00007871bd3d99a4  push r10
00007871bd3d99a6  push r11
00007871bd3d99a8  sub rsp, 0xF0
00007871bd3d99af  vmovaps [rsp], xmm0
00007871bd3d99b4  vmovaps [rsp+0x10], xmm1
00007871bd3d99ba  vmovaps [rsp+0x20], xmm2
00007871bd3d99c0  vmovaps [rsp+0x30], xmm3
00007871bd3d99c6  vmovaps [rsp+0x40], xmm4
00007871bd3d99cc  vmovaps [rsp+0x50], xmm5
00007871bd3d99d2  vmovaps [rsp+0x60], xmm6
00007871bd3d99d8  vmovaps [rsp+0x70], xmm7
00007871bd3d99de  vmovaps [rsp+0x80], xmm9
00007871bd3d99e7  vmovaps [rsp+0x90], xmm10
00007871bd3d99f0  vmovaps [rsp+0xA0], xmm11
00007871bd3d99f9  vmovaps [rsp+0xB0], xmm12
00007871bd3d9a02  vmovaps [rsp+0xC0], xmm13
00007871bd3d9a0b  vmovaps [rsp+0xD0], xmm14
00007871bd3d9a14  vmovaps [rsp+0xE0], xmm15
00007871bd3d9a1d  sub rsp, 0x30
00007871bd3d9a21  movaps [rsp], xmm8
00007871bd3d9a26  movaps [rsp+0x10], xmm12
00007871bd3d9a2c  movaps [rsp+0x20], xmm15
00007871bd3d9a32  lea rdi, [rsp]
00007871bd3d9a36  mov esi, 0x00
00007871bd3d9a3b  mov rax, 0x5BA2FDD2A530
00007871bd3d9a45  call rax
00007871bd3d9a47  movaps xmm8, [rsp]
00007871bd3d9a4c  add rsp, 0x30
00007871bd3d9a50  vmovaps xmm0, [rsp]
00007871bd3d9a55  vmovaps xmm1, [rsp+0x10]
00007871bd3d9a5b  vmovaps xmm2, [rsp+0x20]
00007871bd3d9a61  vmovaps xmm3, [rsp+0x30]
00007871bd3d9a67  vmovaps xmm4, [rsp+0x40]
00007871bd3d9a6d  vmovaps xmm5, [rsp+0x50]
00007871bd3d9a73  vmovaps xmm6, [rsp+0x60]
00007871bd3d9a79  vmovaps xmm7, [rsp+0x70]
00007871bd3d9a7f  vmovaps xmm9, [rsp+0x80]
00007871bd3d9a88  vmovaps xmm10, [rsp+0x90]
00007871bd3d9a91  vmovaps xmm11, [rsp+0xA0]
00007871bd3d9a9a  vmovaps xmm12, [rsp+0xB0]
00007871bd3d9aa3  vmovaps xmm13, [rsp+0xC0]
00007871bd3d9aac  vmovaps xmm14, [rsp+0xD0]
00007871bd3d9ab5  vmovaps xmm15, [rsp+0xE0]
00007871bd3d9abe  add rsp, 0xF0
00007871bd3d9ac5  pop r11
00007871bd3d9ac7  pop r10
00007871bd3d9ac9  pop r9
00007871bd3d9acb  pop r8
00007871bd3d9acd  pop rsi
00007871bd3d9ace  pop rdi
00007871bd3d9acf  pop rdx
00007871bd3d9ad0  pop rcx
00007871bd3d9ad1  pop rax
00007871bd3d9ad2  add rsp, 0x08
00007871bd3d9ad6  jmp 0x00007871BD3D8B7A
00007871bd3d9adb  sub rsp, 0x08
00007871bd3d9adf  push rax
00007871bd3d9ae0  push rcx
00007871bd3d9ae1  push rdx
00007871bd3d9ae2  push rdi
00007871bd3d9ae3  push rsi
00007871bd3d9ae4  push r8
00007871bd3d9ae6  push r9
00007871bd3d9ae8  push r10
00007871bd3d9aea  push r11
00007871bd3d9aec  sub rsp, 0xF0
00007871bd3d9af3  vmovaps [rsp], xmm0
00007871bd3d9af8  vmovaps [rsp+0x10], xmm1
00007871bd3d9afe  vmovaps [rsp+0x20], xmm2
00007871bd3d9b04  vmovaps [rsp+0x30], xmm3
00007871bd3d9b0a  vmovaps [rsp+0x40], xmm4
00007871bd3d9b10  vmovaps [rsp+0x50], xmm5
00007871bd3d9b16  vmovaps [rsp+0x60], xmm6
00007871bd3d9b1c  vmovaps [rsp+0x70], xmm8
00007871bd3d9b22  vmovaps [rsp+0x80], xmm9
00007871bd3d9b2b  vmovaps [rsp+0x90], xmm10
00007871bd3d9b34  vmovaps [rsp+0xA0], xmm11
00007871bd3d9b3d  vmovaps [rsp+0xB0], xmm12
00007871bd3d9b46  vmovaps [rsp+0xC0], xmm13
00007871bd3d9b4f  vmovaps [rsp+0xD0], xmm14
00007871bd3d9b58  vmovaps [rsp+0xE0], xmm15
00007871bd3d9b61  sub rsp, 0x30
00007871bd3d9b65  movaps [rsp], xmm7
00007871bd3d9b69  movaps [rsp+0x10], xmm9
00007871bd3d9b6f  movaps [rsp+0x20], xmm15
00007871bd3d9b75  lea rdi, [rsp]
00007871bd3d9b79  mov esi, 0x00
00007871bd3d9b7e  mov rax, 0x5BA2FDD2A530
00007871bd3d9b88  call rax
00007871bd3d9b8a  movaps xmm7, [rsp]
00007871bd3d9b8e  add rsp, 0x30
00007871bd3d9b92  vmovaps xmm0, [rsp]
00007871bd3d9b97  vmovaps xmm1, [rsp+0x10]
00007871bd3d9b9d  vmovaps xmm2, [rsp+0x20]
00007871bd3d9ba3  vmovaps xmm3, [rsp+0x30]
00007871bd3d9ba9  vmovaps xmm4, [rsp+0x40]
00007871bd3d9baf  vmovaps xmm5, [rsp+0x50]
00007871bd3d9bb5  vmovaps xmm6, [rsp+0x60]
00007871bd3d9bbb  vmovaps xmm8, [rsp+0x70]
00007871bd3d9bc1  vmovaps xmm9, [rsp+0x80]
00007871bd3d9bca  vmovaps xmm10, [rsp+0x90]
00007871bd3d9bd3  vmovaps xmm11, [rsp+0xA0]
00007871bd3d9bdc  vmovaps xmm12, [rsp+0xB0]
00007871bd3d9be5  vmovaps xmm13, [rsp+0xC0]
00007871bd3d9bee  vmovaps xmm14, [rsp+0xD0]
00007871bd3d9bf7  vmovaps xmm15, [rsp+0xE0]
00007871bd3d9c00  add rsp, 0xF0
00007871bd3d9c07  pop r11
00007871bd3d9c09  pop r10
00007871bd3d9c0b  pop r9
00007871bd3d9c0d  pop r8
00007871bd3d9c0f  pop rsi
00007871bd3d9c10  pop rdi
00007871bd3d9c11  pop rdx
00007871bd3d9c12  pop rcx
00007871bd3d9c13  pop rax
00007871bd3d9c14  add rsp, 0x08
00007871bd3d9c18  jmp 0x00007871BD3D8BA8
00007871bd3d9c1d  sub rsp, 0x08
00007871bd3d9c21  push rax
00007871bd3d9c22  push rcx
00007871bd3d9c23  push rdx
00007871bd3d9c24  push rdi
00007871bd3d9c25  push rsi
00007871bd3d9c26  push r8
00007871bd3d9c28  push r9
00007871bd3d9c2a  push r10
00007871bd3d9c2c  push r11
00007871bd3d9c2e  sub rsp, 0xF0
00007871bd3d9c35  vmovaps [rsp], xmm0
00007871bd3d9c3a  vmovaps [rsp+0x10], xmm1
00007871bd3d9c40  vmovaps [rsp+0x20], xmm2
00007871bd3d9c46  vmovaps [rsp+0x30], xmm3
00007871bd3d9c4c  vmovaps [rsp+0x40], xmm4
00007871bd3d9c52  vmovaps [rsp+0x50], xmm5
00007871bd3d9c58  vmovaps [rsp+0x60], xmm6
00007871bd3d9c5e  vmovaps [rsp+0x70], xmm7
00007871bd3d9c64  vmovaps [rsp+0x80], xmm8
00007871bd3d9c6d  vmovaps [rsp+0x90], xmm10
00007871bd3d9c76  vmovaps [rsp+0xA0], xmm11
00007871bd3d9c7f  vmovaps [rsp+0xB0], xmm12
00007871bd3d9c88  vmovaps [rsp+0xC0], xmm13
00007871bd3d9c91  vmovaps [rsp+0xD0], xmm14
00007871bd3d9c9a  vmovaps [rsp+0xE0], xmm15
00007871bd3d9ca3  sub rsp, 0x30
00007871bd3d9ca7  movaps [rsp], xmm9
00007871bd3d9cac  movaps [rsp+0x10], xmm12
00007871bd3d9cb2  movaps [rsp+0x20], xmm10
00007871bd3d9cb8  lea rdi, [rsp]
00007871bd3d9cbc  mov esi, 0x00
00007871bd3d9cc1  mov rax, 0x5BA2FDD2A530
00007871bd3d9ccb  call rax
00007871bd3d9ccd  movaps xmm9, [rsp]
00007871bd3d9cd2  add rsp, 0x30
00007871bd3d9cd6  vmovaps xmm0, [rsp]
00007871bd3d9cdb  vmovaps xmm1, [rsp+0x10]
00007871bd3d9ce1  vmovaps xmm2, [rsp+0x20]
00007871bd3d9ce7  vmovaps xmm3, [rsp+0x30]
00007871bd3d9ced  vmovaps xmm4, [rsp+0x40]
00007871bd3d9cf3  vmovaps xmm5, [rsp+0x50]
00007871bd3d9cf9  vmovaps xmm6, [rsp+0x60]
00007871bd3d9cff  vmovaps xmm7, [rsp+0x70]
00007871bd3d9d05  vmovaps xmm8, [rsp+0x80]
00007871bd3d9d0e  vmovaps xmm10, [rsp+0x90]
00007871bd3d9d17  vmovaps xmm11, [rsp+0xA0]
00007871bd3d9d20  vmovaps xmm12, [rsp+0xB0]
00007871bd3d9d29  vmovaps xmm13, [rsp+0xC0]
00007871bd3d9d32  vmovaps xmm14, [rsp+0xD0]
00007871bd3d9d3b  vmovaps xmm15, [rsp+0xE0]
00007871bd3d9d44  add rsp, 0xF0
00007871bd3d9d4b  pop r11
00007871bd3d9d4d  pop r10
00007871bd3d9d4f  pop r9
00007871bd3d9d51  pop r8
00007871bd3d9d53  pop rsi
00007871bd3d9d54  pop rdi
00007871bd3d9d55  pop rdx
00007871bd3d9d56  pop rcx
00007871bd3d9d57  pop rax
00007871bd3d9d58  add rsp, 0x08
00007871bd3d9d5c  jmp 0x00007871BD3D8BCC
00007871bd3d9d61  sub rsp, 0x08
00007871bd3d9d65  push rax
00007871bd3d9d66  push rcx
00007871bd3d9d67  push rdx
00007871bd3d9d68  push rdi
00007871bd3d9d69  push rsi
00007871bd3d9d6a  push r8
00007871bd3d9d6c  push r9
00007871bd3d9d6e  push r10
00007871bd3d9d70  push r11
00007871bd3d9d72  sub rsp, 0xF0
00007871bd3d9d79  vmovaps [rsp], xmm0
00007871bd3d9d7e  vmovaps [rsp+0x10], xmm1
00007871bd3d9d84  vmovaps [rsp+0x20], xmm2
00007871bd3d9d8a  vmovaps [rsp+0x30], xmm3
00007871bd3d9d90  vmovaps [rsp+0x40], xmm4
00007871bd3d9d96  vmovaps [rsp+0x50], xmm5
00007871bd3d9d9c  vmovaps [rsp+0x60], xmm6
00007871bd3d9da2  vmovaps [rsp+0x70], xmm7
00007871bd3d9da8  vmovaps [rsp+0x80], xmm8
00007871bd3d9db1  vmovaps [rsp+0x90], xmm9
00007871bd3d9dba  vmovaps [rsp+0xA0], xmm11
00007871bd3d9dc3  vmovaps [rsp+0xB0], xmm12
00007871bd3d9dcc  vmovaps [rsp+0xC0], xmm13
00007871bd3d9dd5  vmovaps [rsp+0xD0], xmm14
00007871bd3d9dde  vmovaps [rsp+0xE0], xmm15
00007871bd3d9de7  sub rsp, 0x30
00007871bd3d9deb  movaps [rsp], xmm10
00007871bd3d9df0  movaps [rsp+0x10], xmm12
00007871bd3d9df6  movaps [rsp+0x20], xmm11
00007871bd3d9dfc  lea rdi, [rsp]
00007871bd3d9e00  mov esi, 0x00
00007871bd3d9e05  mov rax, 0x5BA2FDD2A530
00007871bd3d9e0f  call rax
00007871bd3d9e11  movaps xmm10, [rsp]
00007871bd3d9e16  add rsp, 0x30
00007871bd3d9e1a  vmovaps xmm0, [rsp]
00007871bd3d9e1f  vmovaps xmm1, [rsp+0x10]
00007871bd3d9e25  vmovaps xmm2, [rsp+0x20]
00007871bd3d9e2b  vmovaps xmm3, [rsp+0x30]
00007871bd3d9e31  vmovaps xmm4, [rsp+0x40]
00007871bd3d9e37  vmovaps xmm5, [rsp+0x50]
00007871bd3d9e3d  vmovaps xmm6, [rsp+0x60]
00007871bd3d9e43  vmovaps xmm7, [rsp+0x70]
00007871bd3d9e49  vmovaps xmm8, [rsp+0x80]
00007871bd3d9e52  vmovaps xmm9, [rsp+0x90]
00007871bd3d9e5b  vmovaps xmm11, [rsp+0xA0]
00007871bd3d9e64  vmovaps xmm12, [rsp+0xB0]
00007871bd3d9e6d  vmovaps xmm13, [rsp+0xC0]
00007871bd3d9e76  vmovaps xmm14, [rsp+0xD0]
00007871bd3d9e7f  vmovaps xmm15, [rsp+0xE0]
00007871bd3d9e88  add rsp, 0xF0
00007871bd3d9e8f  pop r11
00007871bd3d9e91  pop r10
00007871bd3d9e93  pop r9
00007871bd3d9e95  pop r8
00007871bd3d9e97  pop rsi
00007871bd3d9e98  pop rdi
00007871bd3d9e99  pop rdx
00007871bd3d9e9a  pop rcx
00007871bd3d9e9b  pop rax
00007871bd3d9e9c  add rsp, 0x08
00007871bd3d9ea0  jmp 0x00007871BD3D8BE6
00007871bd3d9ea5  sub rsp, 0x08
00007871bd3d9ea9  push rax
00007871bd3d9eaa  push rcx
00007871bd3d9eab  push rdx
00007871bd3d9eac  push rdi
00007871bd3d9ead  push rsi
00007871bd3d9eae  push r8
00007871bd3d9eb0  push r9
00007871bd3d9eb2  push r10
00007871bd3d9eb4  push r11
00007871bd3d9eb6  sub rsp, 0xF0
00007871bd3d9ebd  vmovaps [rsp], xmm0
00007871bd3d9ec2  vmovaps [rsp+0x10], xmm1
00007871bd3d9ec8  vmovaps [rsp+0x20], xmm2
00007871bd3d9ece  vmovaps [rsp+0x30], xmm3
00007871bd3d9ed4  vmovaps [rsp+0x40], xmm4
00007871bd3d9eda  vmovaps [rsp+0x50], xmm5
00007871bd3d9ee0  vmovaps [rsp+0x60], xmm7
00007871bd3d9ee6  vmovaps [rsp+0x70], xmm8
00007871bd3d9eec  vmovaps [rsp+0x80], xmm9
00007871bd3d9ef5  vmovaps [rsp+0x90], xmm10
00007871bd3d9efe  vmovaps [rsp+0xA0], xmm11
00007871bd3d9f07  vmovaps [rsp+0xB0], xmm12
00007871bd3d9f10  vmovaps [rsp+0xC0], xmm13
00007871bd3d9f19  vmovaps [rsp+0xD0], xmm14
00007871bd3d9f22  vmovaps [rsp+0xE0], xmm15
00007871bd3d9f2b  sub rsp, 0x30
00007871bd3d9f2f  movaps [rsp], xmm6
00007871bd3d9f33  movaps [rsp+0x10], xmm12
00007871bd3d9f39  movaps [rsp+0x20], xmm11
00007871bd3d9f3f  lea rdi, [rsp]
00007871bd3d9f43  mov esi, 0x00
00007871bd3d9f48  mov rax, 0x5BA2FDD2A530
00007871bd3d9f52  call rax
00007871bd3d9f54  movaps xmm6, [rsp]
00007871bd3d9f58  add rsp, 0x30
00007871bd3d9f5c  vmovaps xmm0, [rsp]
00007871bd3d9f61  vmovaps xmm1, [rsp+0x10]
00007871bd3d9f67  vmovaps xmm2, [rsp+0x20]
00007871bd3d9f6d  vmovaps xmm3, [rsp+0x30]
00007871bd3d9f73  vmovaps xmm4, [rsp+0x40]
00007871bd3d9f79  vmovaps xmm5, [rsp+0x50]
00007871bd3d9f7f  vmovaps xmm7, [rsp+0x60]
00007871bd3d9f85  vmovaps xmm8, [rsp+0x70]
00007871bd3d9f8b  vmovaps xmm9, [rsp+0x80]
00007871bd3d9f94  vmovaps xmm10, [rsp+0x90]
00007871bd3d9f9d  vmovaps xmm11, [rsp+0xA0]
00007871bd3d9fa6  vmovaps xmm12, [rsp+0xB0]
00007871bd3d9faf  vmovaps xmm13, [rsp+0xC0]
00007871bd3d9fb8  vmovaps xmm14, [rsp+0xD0]
00007871bd3d9fc1  vmovaps xmm15, [rsp+0xE0]
00007871bd3d9fca  add rsp, 0xF0
00007871bd3d9fd1  pop r11
00007871bd3d9fd3  pop r10
00007871bd3d9fd5  pop r9
00007871bd3d9fd7  pop r8
00007871bd3d9fd9  pop rsi
00007871bd3d9fda  pop rdi
00007871bd3d9fdb  pop rdx
00007871bd3d9fdc  pop rcx
00007871bd3d9fdd  pop rax
00007871bd3d9fde  add rsp, 0x08
00007871bd3d9fe2  jmp 0x00007871BD3D8C07
00007871bd3d9fe7  sub rsp, 0x08
00007871bd3d9feb  push rax
00007871bd3d9fec  push rcx
00007871bd3d9fed  push rdx
00007871bd3d9fee  push rdi
00007871bd3d9fef  push rsi
00007871bd3d9ff0  push r8
00007871bd3d9ff2  push r9
00007871bd3d9ff4  push r10
00007871bd3d9ff6  push r11
00007871bd3d9ff8  sub rsp, 0xF0
00007871bd3d9fff  vmovaps [rsp], xmm0
00007871bd3da004  vmovaps [rsp+0x10], xmm1
00007871bd3da00a  vmovaps [rsp+0x20], xmm2
00007871bd3da010  vmovaps [rsp+0x30], xmm4
00007871bd3da016  vmovaps [rsp+0x40], xmm5
00007871bd3da01c  vmovaps [rsp+0x50], xmm6
00007871bd3da022  vmovaps [rsp+0x60], xmm7
00007871bd3da028  vmovaps [rsp+0x70], xmm8
00007871bd3da02e  vmovaps [rsp+0x80], xmm9
00007871bd3da037  vmovaps [rsp+0x90], xmm10
00007871bd3da040  vmovaps [rsp+0xA0], xmm11
00007871bd3da049  vmovaps [rsp+0xB0], xmm12
00007871bd3da052  vmovaps [rsp+0xC0], xmm13
00007871bd3da05b  vmovaps [rsp+0xD0], xmm14
00007871bd3da064  vmovaps [rsp+0xE0], xmm15
00007871bd3da06d  sub rsp, 0x30
00007871bd3da071  movaps [rsp], xmm3
00007871bd3da075  movaps [rsp+0x10], xmm5
00007871bd3da07a  movaps [rsp+0x20], xmm4
00007871bd3da07f  lea rdi, [rsp]
00007871bd3da083  mov esi, 0x00
00007871bd3da088  mov rax, 0x5BA2FDD2A530
00007871bd3da092  call rax
00007871bd3da094  movaps xmm3, [rsp]
00007871bd3da098  add rsp, 0x30
00007871bd3da09c  vmovaps xmm0, [rsp]
00007871bd3da0a1  vmovaps xmm1, [rsp+0x10]
00007871bd3da0a7  vmovaps xmm2, [rsp+0x20]
00007871bd3da0ad  vmovaps xmm4, [rsp+0x30]
00007871bd3da0b3  vmovaps xmm5, [rsp+0x40]
00007871bd3da0b9  vmovaps xmm6, [rsp+0x50]
00007871bd3da0bf  vmovaps xmm7, [rsp+0x60]
00007871bd3da0c5  vmovaps xmm8, [rsp+0x70]
00007871bd3da0cb  vmovaps xmm9, [rsp+0x80]
00007871bd3da0d4  vmovaps xmm10, [rsp+0x90]
00007871bd3da0dd  vmovaps xmm11, [rsp+0xA0]
00007871bd3da0e6  vmovaps xmm12, [rsp+0xB0]
00007871bd3da0ef  vmovaps xmm13, [rsp+0xC0]
00007871bd3da0f8  vmovaps xmm14, [rsp+0xD0]
00007871bd3da101  vmovaps xmm15, [rsp+0xE0]
00007871bd3da10a  add rsp, 0xF0
00007871bd3da111  pop r11
00007871bd3da113  pop r10
00007871bd3da115  pop r9
00007871bd3da117  pop r8
00007871bd3da119  pop rsi
00007871bd3da11a  pop rdi
00007871bd3da11b  pop rdx
00007871bd3da11c  pop rcx
00007871bd3da11d  pop rax
00007871bd3da11e  add rsp, 0x08
00007871bd3da122  jmp 0x00007871BD3D8C68
00007871bd3da127  sub rsp, 0x08
00007871bd3da12b  push rax
00007871bd3da12c  push rcx
00007871bd3da12d  push rdx
00007871bd3da12e  push rdi
00007871bd3da12f  push rsi
00007871bd3da130  push r8
00007871bd3da132  push r9
00007871bd3da134  push r10
00007871bd3da136  push r11
00007871bd3da138  sub rsp, 0xF0
00007871bd3da13f  vmovaps [rsp], xmm0
00007871bd3da144  vmovaps [rsp+0x10], xmm1
00007871bd3da14a  vmovaps [rsp+0x20], xmm2
00007871bd3da150  vmovaps [rsp+0x30], xmm3
00007871bd3da156  vmovaps [rsp+0x40], xmm4
00007871bd3da15c  vmovaps [rsp+0x50], xmm6
00007871bd3da162  vmovaps [rsp+0x60], xmm7
00007871bd3da168  vmovaps [rsp+0x70], xmm8
00007871bd3da16e  vmovaps [rsp+0x80], xmm9
00007871bd3da177  vmovaps [rsp+0x90], xmm10
00007871bd3da180  vmovaps [rsp+0xA0], xmm11
00007871bd3da189  vmovaps [rsp+0xB0], xmm12
00007871bd3da192  vmovaps [rsp+0xC0], xmm13
00007871bd3da19b  vmovaps [rsp+0xD0], xmm14
00007871bd3da1a4  vmovaps [rsp+0xE0], xmm15
00007871bd3da1ad  sub rsp, 0x30
00007871bd3da1b1  movaps [rsp], xmm5
00007871bd3da1b5  movaps [rsp+0x10], xmm8
00007871bd3da1bb  movaps [rsp+0x20], xmm15
00007871bd3da1c1  lea rdi, [rsp]
00007871bd3da1c5  mov esi, 0x00
00007871bd3da1ca  mov rax, 0x5BA2FDD2A530
00007871bd3da1d4  call rax
00007871bd3da1d6  movaps xmm5, [rsp]
00007871bd3da1da  add rsp, 0x30
00007871bd3da1de  vmovaps xmm0, [rsp]
00007871bd3da1e3  vmovaps xmm1, [rsp+0x10]
00007871bd3da1e9  vmovaps xmm2, [rsp+0x20]
00007871bd3da1ef  vmovaps xmm3, [rsp+0x30]
00007871bd3da1f5  vmovaps xmm4, [rsp+0x40]
00007871bd3da1fb  vmovaps xmm6, [rsp+0x50]
00007871bd3da201  vmovaps xmm7, [rsp+0x60]
00007871bd3da207  vmovaps xmm8, [rsp+0x70]
00007871bd3da20d  vmovaps xmm9, [rsp+0x80]
00007871bd3da216  vmovaps xmm10, [rsp+0x90]
00007871bd3da21f  vmovaps xmm11, [rsp+0xA0]
00007871bd3da228  vmovaps xmm12, [rsp+0xB0]
00007871bd3da231  vmovaps xmm13, [rsp+0xC0]
00007871bd3da23a  vmovaps xmm14, [rsp+0xD0]
00007871bd3da243  vmovaps xmm15, [rsp+0xE0]
00007871bd3da24c  add rsp, 0xF0
00007871bd3da253  pop r11
00007871bd3da255  pop r10
00007871bd3da257  pop r9
00007871bd3da259  pop r8
00007871bd3da25b  pop rsi
00007871bd3da25c  pop rdi
00007871bd3da25d  pop rdx
00007871bd3da25e  pop rcx
00007871bd3da25f  pop rax
00007871bd3da260  add rsp, 0x08
00007871bd3da264  jmp 0x00007871BD3D8CA0
00007871bd3da269  sub rsp, 0x08
00007871bd3da26d  push rax
00007871bd3da26e  push rcx
00007871bd3da26f  push rdx
00007871bd3da270  push rdi
00007871bd3da271  push rsi
00007871bd3da272  push r8
00007871bd3da274  push r9
00007871bd3da276  push r10
00007871bd3da278  push r11
00007871bd3da27a  sub rsp, 0xF0
00007871bd3da281  vmovaps [rsp], xmm0
00007871bd3da286  vmovaps [rsp+0x10], xmm1
00007871bd3da28c  vmovaps [rsp+0x20], xmm2
00007871bd3da292  vmovaps [rsp+0x30], xmm3
00007871bd3da298  vmovaps [rsp+0x40], xmm5
00007871bd3da29e  vmovaps [rsp+0x50], xmm6
00007871bd3da2a4  vmovaps [rsp+0x60], xmm7
00007871bd3da2aa  vmovaps [rsp+0x70], xmm8
00007871bd3da2b0  vmovaps [rsp+0x80], xmm9
00007871bd3da2b9  vmovaps [rsp+0x90], xmm10
00007871bd3da2c2  vmovaps [rsp+0xA0], xmm11
00007871bd3da2cb  vmovaps [rsp+0xB0], xmm12
00007871bd3da2d4  vmovaps [rsp+0xC0], xmm13
00007871bd3da2dd  vmovaps [rsp+0xD0], xmm14
00007871bd3da2e6  vmovaps [rsp+0xE0], xmm15
00007871bd3da2ef  sub rsp, 0x30
00007871bd3da2f3  movaps [rsp], xmm4
00007871bd3da2f7  movaps [rsp+0x10], xmm9
00007871bd3da2fd  movaps [rsp+0x20], xmm8
00007871bd3da303  lea rdi, [rsp]
00007871bd3da307  mov esi, 0x00
00007871bd3da30c  mov rax, 0x5BA2FDD2A530
00007871bd3da316  call rax
00007871bd3da318  movaps xmm4, [rsp]
00007871bd3da31c  add rsp, 0x30
00007871bd3da320  vmovaps xmm0, [rsp]
00007871bd3da325  vmovaps xmm1, [rsp+0x10]
00007871bd3da32b  vmovaps xmm2, [rsp+0x20]
00007871bd3da331  vmovaps xmm3, [rsp+0x30]
00007871bd3da337  vmovaps xmm5, [rsp+0x40]
00007871bd3da33d  vmovaps xmm6, [rsp+0x50]
00007871bd3da343  vmovaps xmm7, [rsp+0x60]
00007871bd3da349  vmovaps xmm8, [rsp+0x70]
00007871bd3da34f  vmovaps xmm9, [rsp+0x80]
00007871bd3da358  vmovaps xmm10, [rsp+0x90]
00007871bd3da361  vmovaps xmm11, [rsp+0xA0]
00007871bd3da36a  vmovaps xmm12, [rsp+0xB0]
00007871bd3da373  vmovaps xmm13, [rsp+0xC0]
00007871bd3da37c  vmovaps xmm14, [rsp+0xD0]
00007871bd3da385  vmovaps xmm15, [rsp+0xE0]
00007871bd3da38e  add rsp, 0xF0
00007871bd3da395  pop r11
00007871bd3da397  pop r10
00007871bd3da399  pop r9
00007871bd3da39b  pop r8
00007871bd3da39d  pop rsi
00007871bd3da39e  pop rdi
00007871bd3da39f  pop rdx
00007871bd3da3a0  pop rcx
00007871bd3da3a1  pop rax
00007871bd3da3a2  add rsp, 0x08
00007871bd3da3a6  jmp 0x00007871BD3D8CC1
00007871bd3da3ab  sub rsp, 0x08
00007871bd3da3af  push rax
00007871bd3da3b0  push rcx
00007871bd3da3b1  push rdx
00007871bd3da3b2  push rdi
00007871bd3da3b3  push rsi
00007871bd3da3b4  push r8
00007871bd3da3b6  push r9
00007871bd3da3b8  push r10
00007871bd3da3ba  push r11
00007871bd3da3bc  sub rsp, 0xF0
00007871bd3da3c3  vmovaps [rsp], xmm0
00007871bd3da3c8  vmovaps [rsp+0x10], xmm1
00007871bd3da3ce  vmovaps [rsp+0x20], xmm2
00007871bd3da3d4  vmovaps [rsp+0x30], xmm3
00007871bd3da3da  vmovaps [rsp+0x40], xmm4
00007871bd3da3e0  vmovaps [rsp+0x50], xmm5
00007871bd3da3e6  vmovaps [rsp+0x60], xmm6
00007871bd3da3ec  vmovaps [rsp+0x70], xmm7
00007871bd3da3f2  vmovaps [rsp+0x80], xmm8
00007871bd3da3fb  vmovaps [rsp+0x90], xmm10
00007871bd3da404  vmovaps [rsp+0xA0], xmm11
00007871bd3da40d  vmovaps [rsp+0xB0], xmm12
00007871bd3da416  vmovaps [rsp+0xC0], xmm13
00007871bd3da41f  vmovaps [rsp+0xD0], xmm14
00007871bd3da428  vmovaps [rsp+0xE0], xmm15
00007871bd3da431  sub rsp, 0x30
00007871bd3da435  movaps [rsp], xmm9
00007871bd3da43a  movaps [rsp+0x10], xmm10
00007871bd3da440  movaps [rsp+0x20], xmm8
00007871bd3da446  lea rdi, [rsp]
00007871bd3da44a  mov esi, 0x00
00007871bd3da44f  mov rax, 0x5BA2FDD2A530
00007871bd3da459  call rax
00007871bd3da45b  movaps xmm9, [rsp]
00007871bd3da460  add rsp, 0x30
00007871bd3da464  vmovaps xmm0, [rsp]
00007871bd3da469  vmovaps xmm1, [rsp+0x10]
00007871bd3da46f  vmovaps xmm2, [rsp+0x20]
00007871bd3da475  vmovaps xmm3, [rsp+0x30]
00007871bd3da47b  vmovaps xmm4, [rsp+0x40]
00007871bd3da481  vmovaps xmm5, [rsp+0x50]
00007871bd3da487  vmovaps xmm6, [rsp+0x60]
00007871bd3da48d  vmovaps xmm7, [rsp+0x70]
00007871bd3da493  vmovaps xmm8, [rsp+0x80]
00007871bd3da49c  vmovaps xmm10, [rsp+0x90]
00007871bd3da4a5  vmovaps xmm11, [rsp+0xA0]
00007871bd3da4ae  vmovaps xmm12, [rsp+0xB0]
00007871bd3da4b7  vmovaps xmm13, [rsp+0xC0]
00007871bd3da4c0  vmovaps xmm14, [rsp+0xD0]
00007871bd3da4c9  vmovaps xmm15, [rsp+0xE0]
00007871bd3da4d2  add rsp, 0xF0
00007871bd3da4d9  pop r11
00007871bd3da4db  pop r10
00007871bd3da4dd  pop r9
00007871bd3da4df  pop r8
00007871bd3da4e1  pop rsi
00007871bd3da4e2  pop rdi
00007871bd3da4e3  pop rdx
00007871bd3da4e4  pop rcx
00007871bd3da4e5  pop rax
00007871bd3da4e6  add rsp, 0x08
00007871bd3da4ea  jmp 0x00007871BD3D8CDB
00007871bd3da4ef  call 0x00007871BD2D64F0
00007871bd3da4f4  jmp 0x00007871BD3D8DF5
00007871bd3da4f9  call 0x00007871BD2D64F0
00007871bd3da4fe  jmp 0x00007871BD3D8E0B
00007871bd3da503  sub rsp, 0x08
00007871bd3da507  push rax
00007871bd3da508  push rcx
00007871bd3da509  push rdx
00007871bd3da50a  push rdi
00007871bd3da50b  push rsi
00007871bd3da50c  push r8
00007871bd3da50e  push r9
00007871bd3da510  push r10
00007871bd3da512  push r11
00007871bd3da514  sub rsp, 0xF0
00007871bd3da51b  vmovaps [rsp], xmm0
00007871bd3da520  vmovaps [rsp+0x10], xmm2
00007871bd3da526  vmovaps [rsp+0x20], xmm3
00007871bd3da52c  vmovaps [rsp+0x30], xmm4
00007871bd3da532  vmovaps [rsp+0x40], xmm5
00007871bd3da538  vmovaps [rsp+0x50], xmm6
00007871bd3da53e  vmovaps [rsp+0x60], xmm7
00007871bd3da544  vmovaps [rsp+0x70], xmm8
00007871bd3da54a  vmovaps [rsp+0x80], xmm9
00007871bd3da553  vmovaps [rsp+0x90], xmm10
00007871bd3da55c  vmovaps [rsp+0xA0], xmm11
00007871bd3da565  vmovaps [rsp+0xB0], xmm12
00007871bd3da56e  vmovaps [rsp+0xC0], xmm13
00007871bd3da577  vmovaps [rsp+0xD0], xmm14
00007871bd3da580  vmovaps [rsp+0xE0], xmm15
00007871bd3da589  sub rsp, 0x30
00007871bd3da58d  movaps [rsp], xmm1
00007871bd3da591  movaps [rsp+0x10], xmm6
00007871bd3da596  movaps [rsp+0x20], xmm15
00007871bd3da59c  lea rdi, [rsp]
00007871bd3da5a0  mov esi, 0x00
00007871bd3da5a5  mov rax, 0x5BA2FDD2A530
00007871bd3da5af  call rax
00007871bd3da5b1  movaps xmm1, [rsp]
00007871bd3da5b5  add rsp, 0x30
00007871bd3da5b9  vmovaps xmm0, [rsp]
00007871bd3da5be  vmovaps xmm2, [rsp+0x10]
00007871bd3da5c4  vmovaps xmm3, [rsp+0x20]
00007871bd3da5ca  vmovaps xmm4, [rsp+0x30]
00007871bd3da5d0  vmovaps xmm5, [rsp+0x40]
00007871bd3da5d6  vmovaps xmm6, [rsp+0x50]
00007871bd3da5dc  vmovaps xmm7, [rsp+0x60]
00007871bd3da5e2  vmovaps xmm8, [rsp+0x70]
00007871bd3da5e8  vmovaps xmm9, [rsp+0x80]
00007871bd3da5f1  vmovaps xmm10, [rsp+0x90]
00007871bd3da5fa  vmovaps xmm11, [rsp+0xA0]
00007871bd3da603  vmovaps xmm12, [rsp+0xB0]
00007871bd3da60c  vmovaps xmm13, [rsp+0xC0]
00007871bd3da615  vmovaps xmm14, [rsp+0xD0]
00007871bd3da61e  vmovaps xmm15, [rsp+0xE0]
00007871bd3da627  add rsp, 0xF0
00007871bd3da62e  pop r11
00007871bd3da630  pop r10
00007871bd3da632  pop r9
00007871bd3da634  pop r8
00007871bd3da636  pop rsi
00007871bd3da637  pop rdi
00007871bd3da638  pop rdx
00007871bd3da639  pop rcx
00007871bd3da63a  pop rax
00007871bd3da63b  add rsp, 0x08
00007871bd3da63f  jmp 0x00007871BD3D8E48
00007871bd3da644  call 0x00007871BD2E5820
00007871bd3da649  jmp 0x00007871BD3D8E55
00007871bd3da64e  sub rsp, 0x08
00007871bd3da652  push rax
00007871bd3da653  push rcx
00007871bd3da654  push rdx
00007871bd3da655  push rdi
00007871bd3da656  push rsi
00007871bd3da657  push r8
00007871bd3da659  push r9
00007871bd3da65b  push r10
00007871bd3da65d  push r11
00007871bd3da65f  sub rsp, 0xF0
00007871bd3da666  vmovaps [rsp], xmm0
00007871bd3da66b  vmovaps [rsp+0x10], xmm1
00007871bd3da671  vmovaps [rsp+0x20], xmm2
00007871bd3da677  vmovaps [rsp+0x30], xmm3
00007871bd3da67d  vmovaps [rsp+0x40], xmm4
00007871bd3da683  vmovaps [rsp+0x50], xmm5
00007871bd3da689  vmovaps [rsp+0x60], xmm6
00007871bd3da68f  vmovaps [rsp+0x70], xmm7
00007871bd3da695  vmovaps [rsp+0x80], xmm8
00007871bd3da69e  vmovaps [rsp+0x90], xmm9
00007871bd3da6a7  vmovaps [rsp+0xA0], xmm10
00007871bd3da6b0  vmovaps [rsp+0xB0], xmm11
00007871bd3da6b9  vmovaps [rsp+0xC0], xmm12
00007871bd3da6c2  vmovaps [rsp+0xD0], xmm13
00007871bd3da6cb  vmovaps [rsp+0xE0], xmm15
00007871bd3da6d4  sub rsp, 0x30
00007871bd3da6d8  movaps [rsp], xmm14
00007871bd3da6dd  movaps [rsp+0x10], xmm4
00007871bd3da6e2  movaps [rsp+0x20], xmm3
00007871bd3da6e7  lea rdi, [rsp]
00007871bd3da6eb  mov esi, 0x00
00007871bd3da6f0  mov rax, 0x5BA2FDD2A530
00007871bd3da6fa  call rax
00007871bd3da6fc  movaps xmm14, [rsp]
00007871bd3da701  add rsp, 0x30
00007871bd3da705  vmovaps xmm0, [rsp]
00007871bd3da70a  vmovaps xmm1, [rsp+0x10]
00007871bd3da710  vmovaps xmm2, [rsp+0x20]
00007871bd3da716  vmovaps xmm3, [rsp+0x30]
00007871bd3da71c  vmovaps xmm4, [rsp+0x40]
00007871bd3da722  vmovaps xmm5, [rsp+0x50]
00007871bd3da728  vmovaps xmm6, [rsp+0x60]
00007871bd3da72e  vmovaps xmm7, [rsp+0x70]
00007871bd3da734  vmovaps xmm8, [rsp+0x80]
00007871bd3da73d  vmovaps xmm9, [rsp+0x90]
00007871bd3da746  vmovaps xmm10, [rsp+0xA0]
00007871bd3da74f  vmovaps xmm11, [rsp+0xB0]
00007871bd3da758  vmovaps xmm12, [rsp+0xC0]
00007871bd3da761  vmovaps xmm13, [rsp+0xD0]
00007871bd3da76a  vmovaps xmm15, [rsp+0xE0]
00007871bd3da773  add rsp, 0xF0
00007871bd3da77a  pop r11
00007871bd3da77c  pop r10
00007871bd3da77e  pop r9
00007871bd3da780  pop r8
00007871bd3da782  pop rsi
00007871bd3da783  pop rdi
00007871bd3da784  pop rdx
00007871bd3da785  pop rcx
00007871bd3da786  pop rax
00007871bd3da787  add rsp, 0x08
00007871bd3da78b  jmp 0x00007871BD3D8E6F
00007871bd3da790  sub rsp, 0x08
00007871bd3da794  push rax
00007871bd3da795  push rcx
00007871bd3da796  push rdx
00007871bd3da797  push rdi
00007871bd3da798  push rsi
00007871bd3da799  push r8
00007871bd3da79b  push r9
00007871bd3da79d  push r10
00007871bd3da79f  push r11
00007871bd3da7a1  sub rsp, 0xF0
00007871bd3da7a8  vmovaps [rsp], xmm0
00007871bd3da7ad  vmovaps [rsp+0x10], xmm1
00007871bd3da7b3  vmovaps [rsp+0x20], xmm2
00007871bd3da7b9  vmovaps [rsp+0x30], xmm3
00007871bd3da7bf  vmovaps [rsp+0x40], xmm4
00007871bd3da7c5  vmovaps [rsp+0x50], xmm5
00007871bd3da7cb  vmovaps [rsp+0x60], xmm7
00007871bd3da7d1  vmovaps [rsp+0x70], xmm8
00007871bd3da7d7  vmovaps [rsp+0x80], xmm9
00007871bd3da7e0  vmovaps [rsp+0x90], xmm10
00007871bd3da7e9  vmovaps [rsp+0xA0], xmm11
00007871bd3da7f2  vmovaps [rsp+0xB0], xmm12
00007871bd3da7fb  vmovaps [rsp+0xC0], xmm13
00007871bd3da804  vmovaps [rsp+0xD0], xmm14
00007871bd3da80d  vmovaps [rsp+0xE0], xmm15
00007871bd3da816  sub rsp, 0x30
00007871bd3da81a  movaps [rsp], xmm6
00007871bd3da81e  movaps [rsp+0x10], xmm9
00007871bd3da824  movaps [rsp+0x20], xmm7
00007871bd3da829  lea rdi, [rsp]
00007871bd3da82d  mov esi, 0x00
00007871bd3da832  mov rax, 0x5BA2FDD2A530
00007871bd3da83c  call rax
00007871bd3da83e  movaps xmm6, [rsp]
00007871bd3da842  add rsp, 0x30
00007871bd3da846  vmovaps xmm0, [rsp]
00007871bd3da84b  vmovaps xmm1, [rsp+0x10]
00007871bd3da851  vmovaps xmm2, [rsp+0x20]
00007871bd3da857  vmovaps xmm3, [rsp+0x30]
00007871bd3da85d  vmovaps xmm4, [rsp+0x40]
00007871bd3da863  vmovaps xmm5, [rsp+0x50]
00007871bd3da869  vmovaps xmm7, [rsp+0x60]
00007871bd3da86f  vmovaps xmm8, [rsp+0x70]
00007871bd3da875  vmovaps xmm9, [rsp+0x80]
00007871bd3da87e  vmovaps xmm10, [rsp+0x90]
00007871bd3da887  vmovaps xmm11, [rsp+0xA0]
00007871bd3da890  vmovaps xmm12, [rsp+0xB0]
00007871bd3da899  vmovaps xmm13, [rsp+0xC0]
00007871bd3da8a2  vmovaps xmm14, [rsp+0xD0]
00007871bd3da8ab  vmovaps xmm15, [rsp+0xE0]
00007871bd3da8b4  add rsp, 0xF0
00007871bd3da8bb  pop r11
00007871bd3da8bd  pop r10
00007871bd3da8bf  pop r9
00007871bd3da8c1  pop r8
00007871bd3da8c3  pop rsi
00007871bd3da8c4  pop rdi
00007871bd3da8c5  pop rdx
00007871bd3da8c6  pop rcx
00007871bd3da8c7  pop rax
00007871bd3da8c8  add rsp, 0x08
00007871bd3da8cc  jmp 0x00007871BD3D8E87
00007871bd3da8d1  sub rsp, 0x08
00007871bd3da8d5  push rax
00007871bd3da8d6  push rcx
00007871bd3da8d7  push rdx
00007871bd3da8d8  push rdi
00007871bd3da8d9  push rsi
00007871bd3da8da  push r8
00007871bd3da8dc  push r9
00007871bd3da8de  push r10
00007871bd3da8e0  push r11
00007871bd3da8e2  sub rsp, 0xF0
00007871bd3da8e9  vmovaps [rsp], xmm0
00007871bd3da8ee  vmovaps [rsp+0x10], xmm1
00007871bd3da8f4  vmovaps [rsp+0x20], xmm2
00007871bd3da8fa  vmovaps [rsp+0x30], xmm3
00007871bd3da900  vmovaps [rsp+0x40], xmm4
00007871bd3da906  vmovaps [rsp+0x50], xmm5
00007871bd3da90c  vmovaps [rsp+0x60], xmm6
00007871bd3da912  vmovaps [rsp+0x70], xmm8
00007871bd3da918  vmovaps [rsp+0x80], xmm9
00007871bd3da921  vmovaps [rsp+0x90], xmm10
00007871bd3da92a  vmovaps [rsp+0xA0], xmm11
00007871bd3da933  vmovaps [rsp+0xB0], xmm12
00007871bd3da93c  vmovaps [rsp+0xC0], xmm13
00007871bd3da945  vmovaps [rsp+0xD0], xmm14
00007871bd3da94e  vmovaps [rsp+0xE0], xmm15
00007871bd3da957  sub rsp, 0x30
00007871bd3da95b  movaps [rsp], xmm7
00007871bd3da95f  movaps [rsp+0x10], xmm4
00007871bd3da964  movaps [rsp+0x20], xmm9
00007871bd3da96a  lea rdi, [rsp]
00007871bd3da96e  mov esi, 0x00
00007871bd3da973  mov rax, 0x5BA2FDD2A530
00007871bd3da97d  call rax
00007871bd3da97f  movaps xmm7, [rsp]
00007871bd3da983  add rsp, 0x30
00007871bd3da987  vmovaps xmm0, [rsp]
00007871bd3da98c  vmovaps xmm1, [rsp+0x10]
00007871bd3da992  vmovaps xmm2, [rsp+0x20]
00007871bd3da998  vmovaps xmm3, [rsp+0x30]
00007871bd3da99e  vmovaps xmm4, [rsp+0x40]
00007871bd3da9a4  vmovaps xmm5, [rsp+0x50]
00007871bd3da9aa  vmovaps xmm6, [rsp+0x60]
00007871bd3da9b0  vmovaps xmm8, [rsp+0x70]
00007871bd3da9b6  vmovaps xmm9, [rsp+0x80]
00007871bd3da9bf  vmovaps xmm10, [rsp+0x90]
00007871bd3da9c8  vmovaps xmm11, [rsp+0xA0]
00007871bd3da9d1  vmovaps xmm12, [rsp+0xB0]
00007871bd3da9da  vmovaps xmm13, [rsp+0xC0]
00007871bd3da9e3  vmovaps xmm14, [rsp+0xD0]
00007871bd3da9ec  vmovaps xmm15, [rsp+0xE0]
00007871bd3da9f5  add rsp, 0xF0
00007871bd3da9fc  pop r11
00007871bd3da9fe  pop r10
00007871bd3daa00  pop r9
00007871bd3daa02  pop r8
00007871bd3daa04  pop rsi
00007871bd3daa05  pop rdi
00007871bd3daa06  pop rdx
00007871bd3daa07  pop rcx
00007871bd3daa08  pop rax
00007871bd3daa09  add rsp, 0x08
00007871bd3daa0d  jmp 0x00007871BD3D8EB4
00007871bd3daa12  sub rsp, 0x08
00007871bd3daa16  push rax
00007871bd3daa17  push rcx
00007871bd3daa18  push rdx
00007871bd3daa19  push rdi
00007871bd3daa1a  push rsi
00007871bd3daa1b  push r8
00007871bd3daa1d  push r9
00007871bd3daa1f  push r10
00007871bd3daa21  push r11
00007871bd3daa23  sub rsp, 0xF0
00007871bd3daa2a  vmovaps [rsp], xmm0
00007871bd3daa2f  vmovaps [rsp+0x10], xmm1
00007871bd3daa35  vmovaps [rsp+0x20], xmm2
00007871bd3daa3b  vmovaps [rsp+0x30], xmm3
00007871bd3daa41  vmovaps [rsp+0x40], xmm5
00007871bd3daa47  vmovaps [rsp+0x50], xmm6
00007871bd3daa4d  vmovaps [rsp+0x60], xmm7
00007871bd3daa53  vmovaps [rsp+0x70], xmm8
00007871bd3daa59  vmovaps [rsp+0x80], xmm9
00007871bd3daa62  vmovaps [rsp+0x90], xmm10
00007871bd3daa6b  vmovaps [rsp+0xA0], xmm11
00007871bd3daa74  vmovaps [rsp+0xB0], xmm12
00007871bd3daa7d  vmovaps [rsp+0xC0], xmm13
00007871bd3daa86  vmovaps [rsp+0xD0], xmm14
00007871bd3daa8f  vmovaps [rsp+0xE0], xmm15
00007871bd3daa98  sub rsp, 0x30
00007871bd3daa9c  movaps [rsp], xmm4
00007871bd3daaa0  movaps [rsp+0x10], xmm15
00007871bd3daaa6  movaps [rsp+0x20], xmm9
00007871bd3daaac  lea rdi, [rsp]
00007871bd3daab0  mov esi, 0x00
00007871bd3daab5  mov rax, 0x5BA2FDD2A530
00007871bd3daabf  call rax
00007871bd3daac1  movaps xmm4, [rsp]
00007871bd3daac5  add rsp, 0x30
00007871bd3daac9  vmovaps xmm0, [rsp]
00007871bd3daace  vmovaps xmm1, [rsp+0x10]
00007871bd3daad4  vmovaps xmm2, [rsp+0x20]
00007871bd3daada  vmovaps xmm3, [rsp+0x30]
00007871bd3daae0  vmovaps xmm5, [rsp+0x40]
00007871bd3daae6  vmovaps xmm6, [rsp+0x50]
00007871bd3daaec  vmovaps xmm7, [rsp+0x60]
00007871bd3daaf2  vmovaps xmm8, [rsp+0x70]
00007871bd3daaf8  vmovaps xmm9, [rsp+0x80]
00007871bd3dab01  vmovaps xmm10, [rsp+0x90]
00007871bd3dab0a  vmovaps xmm11, [rsp+0xA0]
00007871bd3dab13  vmovaps xmm12, [rsp+0xB0]
00007871bd3dab1c  vmovaps xmm13, [rsp+0xC0]
00007871bd3dab25  vmovaps xmm14, [rsp+0xD0]
00007871bd3dab2e  vmovaps xmm15, [rsp+0xE0]
00007871bd3dab37  add rsp, 0xF0
00007871bd3dab3e  pop r11
00007871bd3dab40  pop r10
00007871bd3dab42  pop r9
00007871bd3dab44  pop r8
00007871bd3dab46  pop rsi
00007871bd3dab47  pop rdi
00007871bd3dab48  pop rdx
00007871bd3dab49  pop rcx
00007871bd3dab4a  pop rax
00007871bd3dab4b  add rsp, 0x08
00007871bd3dab4f  jmp 0x00007871BD3D8ED9
00007871bd3dab54  call 0x00007871BD2E5820
00007871bd3dab59  jmp 0x00007871BD3D8EE6
00007871bd3dab5e  sub rsp, 0x08
00007871bd3dab62  push rax
00007871bd3dab63  push rcx
00007871bd3dab64  push rdx
00007871bd3dab65  push rdi
00007871bd3dab66  push rsi
00007871bd3dab67  push r8
00007871bd3dab69  push r9
00007871bd3dab6b  push r10
00007871bd3dab6d  push r11
00007871bd3dab6f  sub rsp, 0xF0
00007871bd3dab76  vmovaps [rsp], xmm0
00007871bd3dab7b  vmovaps [rsp+0x10], xmm1
00007871bd3dab81  vmovaps [rsp+0x20], xmm2
00007871bd3dab87  vmovaps [rsp+0x30], xmm4
00007871bd3dab8d  vmovaps [rsp+0x40], xmm5
00007871bd3dab93  vmovaps [rsp+0x50], xmm6
00007871bd3dab99  vmovaps [rsp+0x60], xmm7
00007871bd3dab9f  vmovaps [rsp+0x70], xmm8
00007871bd3daba5  vmovaps [rsp+0x80], xmm9
00007871bd3dabae  vmovaps [rsp+0x90], xmm10
00007871bd3dabb7  vmovaps [rsp+0xA0], xmm11
00007871bd3dabc0  vmovaps [rsp+0xB0], xmm12
00007871bd3dabc9  vmovaps [rsp+0xC0], xmm13
00007871bd3dabd2  vmovaps [rsp+0xD0], xmm14
00007871bd3dabdb  vmovaps [rsp+0xE0], xmm15
00007871bd3dabe4  sub rsp, 0x30
00007871bd3dabe8  movaps [rsp], xmm3
00007871bd3dabec  movaps [rsp+0x10], xmm1
00007871bd3dabf1  movaps [rsp+0x20], xmm9
00007871bd3dabf7  lea rdi, [rsp]
00007871bd3dabfb  mov esi, 0x00
00007871bd3dac00  mov rax, 0x5BA2FDD2A530
00007871bd3dac0a  call rax
00007871bd3dac0c  movaps xmm3, [rsp]
00007871bd3dac10  add rsp, 0x30
00007871bd3dac14  vmovaps xmm0, [rsp]
00007871bd3dac19  vmovaps xmm1, [rsp+0x10]
00007871bd3dac1f  vmovaps xmm2, [rsp+0x20]
00007871bd3dac25  vmovaps xmm4, [rsp+0x30]
00007871bd3dac2b  vmovaps xmm5, [rsp+0x40]
00007871bd3dac31  vmovaps xmm6, [rsp+0x50]
00007871bd3dac37  vmovaps xmm7, [rsp+0x60]
00007871bd3dac3d  vmovaps xmm8, [rsp+0x70]
00007871bd3dac43  vmovaps xmm9, [rsp+0x80]
00007871bd3dac4c  vmovaps xmm10, [rsp+0x90]
00007871bd3dac55  vmovaps xmm11, [rsp+0xA0]
00007871bd3dac5e  vmovaps xmm12, [rsp+0xB0]
00007871bd3dac67  vmovaps xmm13, [rsp+0xC0]
00007871bd3dac70  vmovaps xmm14, [rsp+0xD0]
00007871bd3dac79  vmovaps xmm15, [rsp+0xE0]
00007871bd3dac82  add rsp, 0xF0
00007871bd3dac89  pop r11
00007871bd3dac8b  pop r10
00007871bd3dac8d  pop r9
00007871bd3dac8f  pop r8
00007871bd3dac91  pop rsi
00007871bd3dac92  pop rdi
00007871bd3dac93  pop rdx
00007871bd3dac94  pop rcx
00007871bd3dac95  pop rax
00007871bd3dac96  add rsp, 0x08
00007871bd3dac9a  jmp 0x00007871BD3D8F23
00007871bd3dac9f  sub rsp, 0x08
00007871bd3daca3  push rax
00007871bd3daca4  push rcx
00007871bd3daca5  push rdx
00007871bd3daca6  push rdi
00007871bd3daca7  push rsi
00007871bd3daca8  push r8
00007871bd3dacaa  push r9
00007871bd3dacac  push r10
00007871bd3dacae  push r11
00007871bd3dacb0  sub rsp, 0xF0
00007871bd3dacb7  vmovaps [rsp], xmm0
00007871bd3dacbc  vmovaps [rsp+0x10], xmm2
00007871bd3dacc2  vmovaps [rsp+0x20], xmm3
00007871bd3dacc8  vmovaps [rsp+0x30], xmm4
00007871bd3dacce  vmovaps [rsp+0x40], xmm5
00007871bd3dacd4  vmovaps [rsp+0x50], xmm6
00007871bd3dacda  vmovaps [rsp+0x60], xmm7
00007871bd3dace0  vmovaps [rsp+0x70], xmm8
00007871bd3dace6  vmovaps [rsp+0x80], xmm9
00007871bd3dacef  vmovaps [rsp+0x90], xmm10
00007871bd3dacf8  vmovaps [rsp+0xA0], xmm11
00007871bd3dad01  vmovaps [rsp+0xB0], xmm12
00007871bd3dad0a  vmovaps [rsp+0xC0], xmm13
00007871bd3dad13  vmovaps [rsp+0xD0], xmm14
00007871bd3dad1c  vmovaps [rsp+0xE0], xmm15
00007871bd3dad25  sub rsp, 0x30
00007871bd3dad29  movaps [rsp], xmm1
00007871bd3dad2d  movaps [rsp+0x10], xmm15
00007871bd3dad33  movaps [rsp+0x20], xmm9
00007871bd3dad39  lea rdi, [rsp]
00007871bd3dad3d  mov esi, 0x00
00007871bd3dad42  mov rax, 0x5BA2FDD2A530
00007871bd3dad4c  call rax
00007871bd3dad4e  movaps xmm1, [rsp]
00007871bd3dad52  add rsp, 0x30
00007871bd3dad56  vmovaps xmm0, [rsp]
00007871bd3dad5b  vmovaps xmm2, [rsp+0x10]
00007871bd3dad61  vmovaps xmm3, [rsp+0x20]
00007871bd3dad67  vmovaps xmm4, [rsp+0x30]
00007871bd3dad6d  vmovaps xmm5, [rsp+0x40]
00007871bd3dad73  vmovaps xmm6, [rsp+0x50]
00007871bd3dad79  vmovaps xmm7, [rsp+0x60]
00007871bd3dad7f  vmovaps xmm8, [rsp+0x70]
00007871bd3dad85  vmovaps xmm9, [rsp+0x80]
00007871bd3dad8e  vmovaps xmm10, [rsp+0x90]
00007871bd3dad97  vmovaps xmm11, [rsp+0xA0]
00007871bd3dada0  vmovaps xmm12, [rsp+0xB0]
00007871bd3dada9  vmovaps xmm13, [rsp+0xC0]
00007871bd3dadb2  vmovaps xmm14, [rsp+0xD0]
00007871bd3dadbb  vmovaps xmm15, [rsp+0xE0]
00007871bd3dadc4  add rsp, 0xF0
00007871bd3dadcb  pop r11
00007871bd3dadcd  pop r10
00007871bd3dadcf  pop r9
00007871bd3dadd1  pop r8
00007871bd3dadd3  pop rsi
00007871bd3dadd4  pop rdi
00007871bd3dadd5  pop rdx
00007871bd3dadd6  pop rcx
00007871bd3dadd7  pop rax
00007871bd3dadd8  add rsp, 0x08
00007871bd3daddc  jmp 0x00007871BD3D8FAB
00007871bd3dade1  call 0x00007871BD2E5820
00007871bd3dade6  jmp 0x00007871BD3D8FB8
00007871bd3dadeb  sub rsp, 0x08
00007871bd3dadef  push rax
00007871bd3dadf0  push rcx
00007871bd3dadf1  push rdx
00007871bd3dadf2  push rdi
00007871bd3dadf3  push rsi
00007871bd3dadf4  push r8
00007871bd3dadf6  push r9
00007871bd3dadf8  push r10
00007871bd3dadfa  push r11
00007871bd3dadfc  sub rsp, 0xF0
00007871bd3dae03  vmovaps [rsp], xmm0
00007871bd3dae08  vmovaps [rsp+0x10], xmm2
00007871bd3dae0e  vmovaps [rsp+0x20], xmm3
00007871bd3dae14  vmovaps [rsp+0x30], xmm4
00007871bd3dae1a  vmovaps [rsp+0x40], xmm5
00007871bd3dae20  vmovaps [rsp+0x50], xmm6
00007871bd3dae26  vmovaps [rsp+0x60], xmm7
00007871bd3dae2c  vmovaps [rsp+0x70], xmm8
00007871bd3dae32  vmovaps [rsp+0x80], xmm9
00007871bd3dae3b  vmovaps [rsp+0x90], xmm10
00007871bd3dae44  vmovaps [rsp+0xA0], xmm11
00007871bd3dae4d  vmovaps [rsp+0xB0], xmm12
00007871bd3dae56  vmovaps [rsp+0xC0], xmm13
00007871bd3dae5f  vmovaps [rsp+0xD0], xmm14
00007871bd3dae68  vmovaps [rsp+0xE0], xmm15
00007871bd3dae71  sub rsp, 0x30
00007871bd3dae75  movaps [rsp], xmm1
00007871bd3dae79  movaps [rsp+0x10], xmm5
00007871bd3dae7e  movaps [rsp+0x20], xmm7
00007871bd3dae83  lea rdi, [rsp]
00007871bd3dae87  mov esi, 0x00
00007871bd3dae8c  mov rax, 0x5BA2FDD2A530
00007871bd3dae96  call rax
00007871bd3dae98  movaps xmm1, [rsp]
00007871bd3dae9c  add rsp, 0x30
00007871bd3daea0  vmovaps xmm0, [rsp]
00007871bd3daea5  vmovaps xmm2, [rsp+0x10]
00007871bd3daeab  vmovaps xmm3, [rsp+0x20]
00007871bd3daeb1  vmovaps xmm4, [rsp+0x30]
00007871bd3daeb7  vmovaps xmm5, [rsp+0x40]
00007871bd3daebd  vmovaps xmm6, [rsp+0x50]
00007871bd3daec3  vmovaps xmm7, [rsp+0x60]
00007871bd3daec9  vmovaps xmm8, [rsp+0x70]
00007871bd3daecf  vmovaps xmm9, [rsp+0x80]
00007871bd3daed8  vmovaps xmm10, [rsp+0x90]
00007871bd3daee1  vmovaps xmm11, [rsp+0xA0]
00007871bd3daeea  vmovaps xmm12, [rsp+0xB0]
00007871bd3daef3  vmovaps xmm13, [rsp+0xC0]
00007871bd3daefc  vmovaps xmm14, [rsp+0xD0]
00007871bd3daf05  vmovaps xmm15, [rsp+0xE0]
00007871bd3daf0e  add rsp, 0xF0
00007871bd3daf15  pop r11
00007871bd3daf17  pop r10
00007871bd3daf19  pop r9
00007871bd3daf1b  pop r8
00007871bd3daf1d  pop rsi
00007871bd3daf1e  pop rdi
00007871bd3daf1f  pop rdx
00007871bd3daf20  pop rcx
00007871bd3daf21  pop rax
00007871bd3daf22  add rsp, 0x08
00007871bd3daf26  jmp 0x00007871BD3D905D
00007871bd3daf2b  sub rsp, 0x08
00007871bd3daf2f  push rax
00007871bd3daf30  push rcx
00007871bd3daf31  push rdx
00007871bd3daf32  push rdi
00007871bd3daf33  push rsi
00007871bd3daf34  push r8
00007871bd3daf36  push r9
00007871bd3daf38  push r10
00007871bd3daf3a  push r11
00007871bd3daf3c  sub rsp, 0xF0
00007871bd3daf43  vmovaps [rsp], xmm0
00007871bd3daf48  vmovaps [rsp+0x10], xmm1
00007871bd3daf4e  vmovaps [rsp+0x20], xmm2
00007871bd3daf54  vmovaps [rsp+0x30], xmm3
00007871bd3daf5a  vmovaps [rsp+0x40], xmm4
00007871bd3daf60  vmovaps [rsp+0x50], xmm5
00007871bd3daf66  vmovaps [rsp+0x60], xmm6
00007871bd3daf6c  vmovaps [rsp+0x70], xmm8
00007871bd3daf72  vmovaps [rsp+0x80], xmm9
00007871bd3daf7b  vmovaps [rsp+0x90], xmm10
00007871bd3daf84  vmovaps [rsp+0xA0], xmm11
00007871bd3daf8d  vmovaps [rsp+0xB0], xmm12
00007871bd3daf96  vmovaps [rsp+0xC0], xmm13
00007871bd3daf9f  vmovaps [rsp+0xD0], xmm14
00007871bd3dafa8  vmovaps [rsp+0xE0], xmm15
00007871bd3dafb1  sub rsp, 0x30
00007871bd3dafb5  movaps [rsp], xmm7
00007871bd3dafb9  movaps [rsp+0x10], xmm5
00007871bd3dafbe  movaps [rsp+0x20], xmm15
00007871bd3dafc4  lea rdi, [rsp]
00007871bd3dafc8  mov esi, 0x00
00007871bd3dafcd  mov rax, 0x5BA2FDD2A530
00007871bd3dafd7  call rax
00007871bd3dafd9  movaps xmm7, [rsp]
00007871bd3dafdd  add rsp, 0x30
00007871bd3dafe1  vmovaps xmm0, [rsp]
00007871bd3dafe6  vmovaps xmm1, [rsp+0x10]
00007871bd3dafec  vmovaps xmm2, [rsp+0x20]
00007871bd3daff2  vmovaps xmm3, [rsp+0x30]
00007871bd3daff8  vmovaps xmm4, [rsp+0x40]
00007871bd3daffe  vmovaps xmm5, [rsp+0x50]
00007871bd3db004  vmovaps xmm6, [rsp+0x60]
00007871bd3db00a  vmovaps xmm8, [rsp+0x70]
00007871bd3db010  vmovaps xmm9, [rsp+0x80]
00007871bd3db019  vmovaps xmm10, [rsp+0x90]
00007871bd3db022  vmovaps xmm11, [rsp+0xA0]
00007871bd3db02b  vmovaps xmm12, [rsp+0xB0]
00007871bd3db034  vmovaps xmm13, [rsp+0xC0]
00007871bd3db03d  vmovaps xmm14, [rsp+0xD0]
00007871bd3db046  vmovaps xmm15, [rsp+0xE0]
00007871bd3db04f  add rsp, 0xF0
00007871bd3db056  pop r11
00007871bd3db058  pop r10
00007871bd3db05a  pop r9
00007871bd3db05c  pop r8
00007871bd3db05e  pop rsi
00007871bd3db05f  pop rdi
00007871bd3db060  pop rdx
00007871bd3db061  pop rcx
00007871bd3db062  pop rax
00007871bd3db063  add rsp, 0x08
00007871bd3db067  jmp 0x00007871BD3D9093
00007871bd3db06c  call 0x00007871BD2D64F0
00007871bd3db071  jmp 0x00007871BD3D90A0
00007871bd3db076  sub rsp, 0x08
00007871bd3db07a  push rax
00007871bd3db07b  push rcx
00007871bd3db07c  push rdx
00007871bd3db07d  push rdi
00007871bd3db07e  push rsi
00007871bd3db07f  push r8
00007871bd3db081  push r9
00007871bd3db083  push r10
00007871bd3db085  push r11
00007871bd3db087  sub rsp, 0xF0
00007871bd3db08e  vmovaps [rsp], xmm0
00007871bd3db093  vmovaps [rsp+0x10], xmm1
00007871bd3db099  vmovaps [rsp+0x20], xmm2
00007871bd3db09f  vmovaps [rsp+0x30], xmm3
00007871bd3db0a5  vmovaps [rsp+0x40], xmm4
00007871bd3db0ab  vmovaps [rsp+0x50], xmm5
00007871bd3db0b1  vmovaps [rsp+0x60], xmm6
00007871bd3db0b7  vmovaps [rsp+0x70], xmm7
00007871bd3db0bd  vmovaps [rsp+0x80], xmm8
00007871bd3db0c6  vmovaps [rsp+0x90], xmm9
00007871bd3db0cf  vmovaps [rsp+0xA0], xmm10
00007871bd3db0d8  vmovaps [rsp+0xB0], xmm11
00007871bd3db0e1  vmovaps [rsp+0xC0], xmm12
00007871bd3db0ea  vmovaps [rsp+0xD0], xmm13
00007871bd3db0f3  vmovaps [rsp+0xE0], xmm14
00007871bd3db0fc  sub rsp, 0x30
00007871bd3db100  movaps [rsp], xmm15
00007871bd3db105  movaps [rsp+0x10], xmm5
00007871bd3db10a  movaps [rsp+0x20], xmm3
00007871bd3db10f  lea rdi, [rsp]
00007871bd3db113  mov esi, 0x00
00007871bd3db118  mov rax, 0x5BA2FDD2A530
00007871bd3db122  call rax
00007871bd3db124  movaps xmm15, [rsp]
00007871bd3db129  add rsp, 0x30
00007871bd3db12d  vmovaps xmm0, [rsp]
00007871bd3db132  vmovaps xmm1, [rsp+0x10]
00007871bd3db138  vmovaps xmm2, [rsp+0x20]
00007871bd3db13e  vmovaps xmm3, [rsp+0x30]
00007871bd3db144  vmovaps xmm4, [rsp+0x40]
00007871bd3db14a  vmovaps xmm5, [rsp+0x50]
00007871bd3db150  vmovaps xmm6, [rsp+0x60]
00007871bd3db156  vmovaps xmm7, [rsp+0x70]
00007871bd3db15c  vmovaps xmm8, [rsp+0x80]
00007871bd3db165  vmovaps xmm9, [rsp+0x90]
00007871bd3db16e  vmovaps xmm10, [rsp+0xA0]
00007871bd3db177  vmovaps xmm11, [rsp+0xB0]
00007871bd3db180  vmovaps xmm12, [rsp+0xC0]
00007871bd3db189  vmovaps xmm13, [rsp+0xD0]
00007871bd3db192  vmovaps xmm14, [rsp+0xE0]
00007871bd3db19b  add rsp, 0xF0
00007871bd3db1a2  pop r11
00007871bd3db1a4  pop r10
00007871bd3db1a6  pop r9
00007871bd3db1a8  pop r8
00007871bd3db1aa  pop rsi
00007871bd3db1ab  pop rdi
00007871bd3db1ac  pop rdx
00007871bd3db1ad  pop rcx
00007871bd3db1ae  pop rax
00007871bd3db1af  add rsp, 0x08
00007871bd3db1b3  jmp 0x00007871BD3D90C6
00007871bd3db1b8  sub rsp, 0x08
00007871bd3db1bc  push rax
00007871bd3db1bd  push rcx
00007871bd3db1be  push rdx
00007871bd3db1bf  push rdi
00007871bd3db1c0  push rsi
00007871bd3db1c1  push r8
00007871bd3db1c3  push r9
00007871bd3db1c5  push r10
00007871bd3db1c7  push r11
00007871bd3db1c9  sub rsp, 0xF0
00007871bd3db1d0  vmovaps [rsp], xmm0
00007871bd3db1d5  vmovaps [rsp+0x10], xmm2
00007871bd3db1db  vmovaps [rsp+0x20], xmm3
00007871bd3db1e1  vmovaps [rsp+0x30], xmm4
00007871bd3db1e7  vmovaps [rsp+0x40], xmm5
00007871bd3db1ed  vmovaps [rsp+0x50], xmm6
00007871bd3db1f3  vmovaps [rsp+0x60], xmm7
00007871bd3db1f9  vmovaps [rsp+0x70], xmm8
00007871bd3db1ff  vmovaps [rsp+0x80], xmm9
00007871bd3db208  vmovaps [rsp+0x90], xmm10
00007871bd3db211  vmovaps [rsp+0xA0], xmm11
00007871bd3db21a  vmovaps [rsp+0xB0], xmm12
00007871bd3db223  vmovaps [rsp+0xC0], xmm13
00007871bd3db22c  vmovaps [rsp+0xD0], xmm14
00007871bd3db235  vmovaps [rsp+0xE0], xmm15
00007871bd3db23e  sub rsp, 0x30
00007871bd3db242  movaps [rsp], xmm1
00007871bd3db246  movaps [rsp+0x10], xmm5
00007871bd3db24b  movaps [rsp+0x20], xmm4
00007871bd3db250  lea rdi, [rsp]
00007871bd3db254  mov esi, 0x00
00007871bd3db259  mov rax, 0x5BA2FDD2A530
00007871bd3db263  call rax
00007871bd3db265  movaps xmm1, [rsp]
00007871bd3db269  add rsp, 0x30
00007871bd3db26d  vmovaps xmm0, [rsp]
00007871bd3db272  vmovaps xmm2, [rsp+0x10]
00007871bd3db278  vmovaps xmm3, [rsp+0x20]
00007871bd3db27e  vmovaps xmm4, [rsp+0x30]
00007871bd3db284  vmovaps xmm5, [rsp+0x40]
00007871bd3db28a  vmovaps xmm6, [rsp+0x50]
00007871bd3db290  vmovaps xmm7, [rsp+0x60]
00007871bd3db296  vmovaps xmm8, [rsp+0x70]
00007871bd3db29c  vmovaps xmm9, [rsp+0x80]
00007871bd3db2a5  vmovaps xmm10, [rsp+0x90]
00007871bd3db2ae  vmovaps xmm11, [rsp+0xA0]
00007871bd3db2b7  vmovaps xmm12, [rsp+0xB0]
00007871bd3db2c0  vmovaps xmm13, [rsp+0xC0]
00007871bd3db2c9  vmovaps xmm14, [rsp+0xD0]
00007871bd3db2d2  vmovaps xmm15, [rsp+0xE0]
00007871bd3db2db  add rsp, 0xF0
00007871bd3db2e2  pop r11
00007871bd3db2e4  pop r10
00007871bd3db2e6  pop r9
00007871bd3db2e8  pop r8
00007871bd3db2ea  pop rsi
00007871bd3db2eb  pop rdi
00007871bd3db2ec  pop rdx
00007871bd3db2ed  pop rcx
00007871bd3db2ee  pop rax
00007871bd3db2ef  add rsp, 0x08
00007871bd3db2f3  jmp 0x00007871BD3D90E6
00007871bd3db2f8  sub rsp, 0x08
00007871bd3db2fc  push rax
00007871bd3db2fd  push rcx
00007871bd3db2fe  push rdx
00007871bd3db2ff  push rdi
00007871bd3db300  push rsi
00007871bd3db301  push r8
00007871bd3db303  push r9
00007871bd3db305  push r10
00007871bd3db307  push r11
00007871bd3db309  sub rsp, 0xF0
00007871bd3db310  vmovaps [rsp], xmm0
00007871bd3db315  vmovaps [rsp+0x10], xmm1
00007871bd3db31b  vmovaps [rsp+0x20], xmm2
00007871bd3db321  vmovaps [rsp+0x30], xmm3
00007871bd3db327  vmovaps [rsp+0x40], xmm5
00007871bd3db32d  vmovaps [rsp+0x50], xmm6
00007871bd3db333  vmovaps [rsp+0x60], xmm7
00007871bd3db339  vmovaps [rsp+0x70], xmm8
00007871bd3db33f  vmovaps [rsp+0x80], xmm9
00007871bd3db348  vmovaps [rsp+0x90], xmm10
00007871bd3db351  vmovaps [rsp+0xA0], xmm11
00007871bd3db35a  vmovaps [rsp+0xB0], xmm12
00007871bd3db363  vmovaps [rsp+0xC0], xmm13
00007871bd3db36c  vmovaps [rsp+0xD0], xmm14
00007871bd3db375  vmovaps [rsp+0xE0], xmm15
00007871bd3db37e  sub rsp, 0x30
00007871bd3db382  movaps [rsp], xmm4
00007871bd3db386  movaps [rsp+0x10], xmm3
00007871bd3db38b  movaps [rsp+0x20], xmm5
00007871bd3db390  lea rdi, [rsp]
00007871bd3db394  mov esi, 0x00
00007871bd3db399  mov rax, 0x5BA2FDD2A530
00007871bd3db3a3  call rax
00007871bd3db3a5  movaps xmm4, [rsp]
00007871bd3db3a9  add rsp, 0x30
00007871bd3db3ad  vmovaps xmm0, [rsp]
00007871bd3db3b2  vmovaps xmm1, [rsp+0x10]
00007871bd3db3b8  vmovaps xmm2, [rsp+0x20]
00007871bd3db3be  vmovaps xmm3, [rsp+0x30]
00007871bd3db3c4  vmovaps xmm5, [rsp+0x40]
00007871bd3db3ca  vmovaps xmm6, [rsp+0x50]
00007871bd3db3d0  vmovaps xmm7, [rsp+0x60]
00007871bd3db3d6  vmovaps xmm8, [rsp+0x70]
00007871bd3db3dc  vmovaps xmm9, [rsp+0x80]
00007871bd3db3e5  vmovaps xmm10, [rsp+0x90]
00007871bd3db3ee  vmovaps xmm11, [rsp+0xA0]
00007871bd3db3f7  vmovaps xmm12, [rsp+0xB0]
00007871bd3db400  vmovaps xmm13, [rsp+0xC0]
00007871bd3db409  vmovaps xmm14, [rsp+0xD0]
00007871bd3db412  vmovaps xmm15, [rsp+0xE0]
00007871bd3db41b  add rsp, 0xF0
00007871bd3db422  pop r11
00007871bd3db424  pop r10
00007871bd3db426  pop r9
00007871bd3db428  pop r8
00007871bd3db42a  pop rsi
00007871bd3db42b  pop rdi
00007871bd3db42c  pop rdx
00007871bd3db42d  pop rcx
00007871bd3db42e  pop rax
00007871bd3db42f  add rsp, 0x08
00007871bd3db433  jmp 0x00007871BD3D9134
00007871bd3db438  call 0x00007871BD2D64F0
00007871bd3db43d  jmp 0x00007871BD3D9141
00007871bd3db442  sub rsp, 0x08
00007871bd3db446  push rax
00007871bd3db447  push rcx
00007871bd3db448  push rdx
00007871bd3db449  push rdi
00007871bd3db44a  push rsi
00007871bd3db44b  push r8
00007871bd3db44d  push r9
00007871bd3db44f  push r10
00007871bd3db451  push r11
00007871bd3db453  sub rsp, 0xF0
00007871bd3db45a  vmovaps [rsp], xmm0
00007871bd3db45f  vmovaps [rsp+0x10], xmm1
00007871bd3db465  vmovaps [rsp+0x20], xmm2
00007871bd3db46b  vmovaps [rsp+0x30], xmm3
00007871bd3db471  vmovaps [rsp+0x40], xmm4
00007871bd3db477  vmovaps [rsp+0x50], xmm6
00007871bd3db47d  vmovaps [rsp+0x60], xmm7
00007871bd3db483  vmovaps [rsp+0x70], xmm8
00007871bd3db489  vmovaps [rsp+0x80], xmm9
00007871bd3db492  vmovaps [rsp+0x90], xmm10
00007871bd3db49b  vmovaps [rsp+0xA0], xmm11
00007871bd3db4a4  vmovaps [rsp+0xB0], xmm12
00007871bd3db4ad  vmovaps [rsp+0xC0], xmm13
00007871bd3db4b6  vmovaps [rsp+0xD0], xmm14
00007871bd3db4bf  vmovaps [rsp+0xE0], xmm15
00007871bd3db4c8  sub rsp, 0x30
00007871bd3db4cc  movaps [rsp], xmm5
00007871bd3db4d0  movaps [rsp+0x10], xmm6
00007871bd3db4d5  movaps [rsp+0x20], xmm3
00007871bd3db4da  lea rdi, [rsp]
00007871bd3db4de  mov esi, 0x00
00007871bd3db4e3  mov rax, 0x5BA2FDD2A530
00007871bd3db4ed  call rax
00007871bd3db4ef  movaps xmm5, [rsp]
00007871bd3db4f3  add rsp, 0x30
00007871bd3db4f7  vmovaps xmm0, [rsp]
00007871bd3db4fc  vmovaps xmm1, [rsp+0x10]
00007871bd3db502  vmovaps xmm2, [rsp+0x20]
00007871bd3db508  vmovaps xmm3, [rsp+0x30]
00007871bd3db50e  vmovaps xmm4, [rsp+0x40]
00007871bd3db514  vmovaps xmm6, [rsp+0x50]
00007871bd3db51a  vmovaps xmm7, [rsp+0x60]
00007871bd3db520  vmovaps xmm8, [rsp+0x70]
00007871bd3db526  vmovaps xmm9, [rsp+0x80]
00007871bd3db52f  vmovaps xmm10, [rsp+0x90]
00007871bd3db538  vmovaps xmm11, [rsp+0xA0]
00007871bd3db541  vmovaps xmm12, [rsp+0xB0]
00007871bd3db54a  vmovaps xmm13, [rsp+0xC0]
00007871bd3db553  vmovaps xmm14, [rsp+0xD0]
00007871bd3db55c  vmovaps xmm15, [rsp+0xE0]
00007871bd3db565  add rsp, 0xF0
00007871bd3db56c  pop r11
00007871bd3db56e  pop r10
00007871bd3db570  pop r9
00007871bd3db572  pop r8
00007871bd3db574  pop rsi
00007871bd3db575  pop rdi
00007871bd3db576  pop rdx
00007871bd3db577  pop rcx
00007871bd3db578  pop rax
00007871bd3db579  add rsp, 0x08
00007871bd3db57d  jmp 0x00007871BD3D9167
00007871bd3db582  sub rsp, 0x08
00007871bd3db586  push rax
00007871bd3db587  push rcx
00007871bd3db588  push rdx
00007871bd3db589  push rdi
00007871bd3db58a  push rsi
00007871bd3db58b  push r8
00007871bd3db58d  push r9
00007871bd3db58f  push r10
00007871bd3db591  push r11
00007871bd3db593  sub rsp, 0xF0
00007871bd3db59a  vmovaps [rsp], xmm0
00007871bd3db59f  vmovaps [rsp+0x10], xmm1
00007871bd3db5a5  vmovaps [rsp+0x20], xmm2
00007871bd3db5ab  vmovaps [rsp+0x30], xmm3
00007871bd3db5b1  vmovaps [rsp+0x40], xmm4
00007871bd3db5b7  vmovaps [rsp+0x50], xmm5
00007871bd3db5bd  vmovaps [rsp+0x60], xmm7
00007871bd3db5c3  vmovaps [rsp+0x70], xmm8
00007871bd3db5c9  vmovaps [rsp+0x80], xmm9
00007871bd3db5d2  vmovaps [rsp+0x90], xmm10
00007871bd3db5db  vmovaps [rsp+0xA0], xmm11
00007871bd3db5e4  vmovaps [rsp+0xB0], xmm12
00007871bd3db5ed  vmovaps [rsp+0xC0], xmm13
00007871bd3db5f6  vmovaps [rsp+0xD0], xmm14
00007871bd3db5ff  vmovaps [rsp+0xE0], xmm15
00007871bd3db608  sub rsp, 0x30
00007871bd3db60c  movaps [rsp], xmm6
00007871bd3db610  movaps [rsp+0x10], xmm9
00007871bd3db616  movaps [rsp+0x20], xmm1
00007871bd3db61b  lea rdi, [rsp]
00007871bd3db61f  mov esi, 0x00
00007871bd3db624  mov rax, 0x5BA2FDD2A530
00007871bd3db62e  call rax
00007871bd3db630  movaps xmm6, [rsp]
00007871bd3db634  add rsp, 0x30
00007871bd3db638  vmovaps xmm0, [rsp]
00007871bd3db63d  vmovaps xmm1, [rsp+0x10]
00007871bd3db643  vmovaps xmm2, [rsp+0x20]
00007871bd3db649  vmovaps xmm3, [rsp+0x30]
00007871bd3db64f  vmovaps xmm4, [rsp+0x40]
00007871bd3db655  vmovaps xmm5, [rsp+0x50]
00007871bd3db65b  vmovaps xmm7, [rsp+0x60]
00007871bd3db661  vmovaps xmm8, [rsp+0x70]
00007871bd3db667  vmovaps xmm9, [rsp+0x80]
00007871bd3db670  vmovaps xmm10, [rsp+0x90]
00007871bd3db679  vmovaps xmm11, [rsp+0xA0]
00007871bd3db682  vmovaps xmm12, [rsp+0xB0]
00007871bd3db68b  vmovaps xmm13, [rsp+0xC0]
00007871bd3db694  vmovaps xmm14, [rsp+0xD0]
00007871bd3db69d  vmovaps xmm15, [rsp+0xE0]
00007871bd3db6a6  add rsp, 0xF0
00007871bd3db6ad  pop r11
00007871bd3db6af  pop r10
00007871bd3db6b1  pop r9
00007871bd3db6b3  pop r8
00007871bd3db6b5  pop rsi
00007871bd3db6b6  pop rdi
00007871bd3db6b7  pop rdx
00007871bd3db6b8  pop rcx
00007871bd3db6b9  pop rax
00007871bd3db6ba  add rsp, 0x08
00007871bd3db6be  jmp 0x00007871BD3D918B
00007871bd3db6c3  sub rsp, 0x08
00007871bd3db6c7  push rax
00007871bd3db6c8  push rcx
00007871bd3db6c9  push rdx
00007871bd3db6ca  push rdi
00007871bd3db6cb  push rsi
00007871bd3db6cc  push r8
00007871bd3db6ce  push r9
00007871bd3db6d0  push r10
00007871bd3db6d2  push r11
00007871bd3db6d4  sub rsp, 0xF0
00007871bd3db6db  vmovaps [rsp], xmm0
00007871bd3db6e0  vmovaps [rsp+0x10], xmm1
00007871bd3db6e6  vmovaps [rsp+0x20], xmm2
00007871bd3db6ec  vmovaps [rsp+0x30], xmm3
00007871bd3db6f2  vmovaps [rsp+0x40], xmm4
00007871bd3db6f8  vmovaps [rsp+0x50], xmm5
00007871bd3db6fe  vmovaps [rsp+0x60], xmm6
00007871bd3db704  vmovaps [rsp+0x70], xmm7
00007871bd3db70a  vmovaps [rsp+0x80], xmm8
00007871bd3db713  vmovaps [rsp+0x90], xmm10
00007871bd3db71c  vmovaps [rsp+0xA0], xmm11
00007871bd3db725  vmovaps [rsp+0xB0], xmm12
00007871bd3db72e  vmovaps [rsp+0xC0], xmm13
00007871bd3db737  vmovaps [rsp+0xD0], xmm14
00007871bd3db740  vmovaps [rsp+0xE0], xmm15
00007871bd3db749  sub rsp, 0x30
00007871bd3db74d  movaps [rsp], xmm9
00007871bd3db752  movaps [rsp+0x10], xmm3
00007871bd3db757  movaps [rsp+0x20], xmm1
00007871bd3db75c  lea rdi, [rsp]
00007871bd3db760  mov esi, 0x00
00007871bd3db765  mov rax, 0x5BA2FDD2A530
00007871bd3db76f  call rax
00007871bd3db771  movaps xmm9, [rsp]
00007871bd3db776  add rsp, 0x30
00007871bd3db77a  vmovaps xmm0, [rsp]
00007871bd3db77f  vmovaps xmm1, [rsp+0x10]
00007871bd3db785  vmovaps xmm2, [rsp+0x20]
00007871bd3db78b  vmovaps xmm3, [rsp+0x30]
00007871bd3db791  vmovaps xmm4, [rsp+0x40]
00007871bd3db797  vmovaps xmm5, [rsp+0x50]
00007871bd3db79d  vmovaps xmm6, [rsp+0x60]
00007871bd3db7a3  vmovaps xmm7, [rsp+0x70]
00007871bd3db7a9  vmovaps xmm8, [rsp+0x80]
00007871bd3db7b2  vmovaps xmm10, [rsp+0x90]
00007871bd3db7bb  vmovaps xmm11, [rsp+0xA0]
00007871bd3db7c4  vmovaps xmm12, [rsp+0xB0]
00007871bd3db7cd  vmovaps xmm13, [rsp+0xC0]
00007871bd3db7d6  vmovaps xmm14, [rsp+0xD0]
00007871bd3db7df  vmovaps xmm15, [rsp+0xE0]
00007871bd3db7e8  add rsp, 0xF0
00007871bd3db7ef  pop r11
00007871bd3db7f1  pop r10
00007871bd3db7f3  pop r9
00007871bd3db7f5  pop r8
00007871bd3db7f7  pop rsi
00007871bd3db7f8  pop rdi
00007871bd3db7f9  pop rdx
00007871bd3db7fa  pop rcx
00007871bd3db7fb  pop rax
00007871bd3db7fc  add rsp, 0x08
00007871bd3db800  jmp 0x00007871BD3D91D7
00007871bd3db805  call 0x00007871BD2D64F0
00007871bd3db80a  jmp 0x00007871BD3D91E4
00007871bd3db80f  sub rsp, 0x08
00007871bd3db813  push rax
00007871bd3db814  push rcx
00007871bd3db815  push rdx
00007871bd3db816  push rdi
00007871bd3db817  push rsi
00007871bd3db818  push r8
00007871bd3db81a  push r9
00007871bd3db81c  push r10
00007871bd3db81e  push r11
00007871bd3db820  sub rsp, 0xF0
00007871bd3db827  vmovaps [rsp], xmm0
00007871bd3db82c  vmovaps [rsp+0x10], xmm1
00007871bd3db832  vmovaps [rsp+0x20], xmm2
00007871bd3db838  vmovaps [rsp+0x30], xmm3
00007871bd3db83e  vmovaps [rsp+0x40], xmm4
00007871bd3db844  vmovaps [rsp+0x50], xmm5
00007871bd3db84a  vmovaps [rsp+0x60], xmm6
00007871bd3db850  vmovaps [rsp+0x70], xmm7
00007871bd3db856  vmovaps [rsp+0x80], xmm8
00007871bd3db85f  vmovaps [rsp+0x90], xmm9
00007871bd3db868  vmovaps [rsp+0xA0], xmm10
00007871bd3db871  vmovaps [rsp+0xB0], xmm11
00007871bd3db87a  vmovaps [rsp+0xC0], xmm12
00007871bd3db883  vmovaps [rsp+0xD0], xmm13
00007871bd3db88c  vmovaps [rsp+0xE0], xmm14
00007871bd3db895  sub rsp, 0x30
00007871bd3db899  movaps [rsp], xmm15
00007871bd3db89e  movaps [rsp+0x10], xmm3
00007871bd3db8a3  movaps [rsp+0x20], xmm7
00007871bd3db8a8  lea rdi, [rsp]
00007871bd3db8ac  mov esi, 0x00
00007871bd3db8b1  mov rax, 0x5BA2FDD2A530
00007871bd3db8bb  call rax
00007871bd3db8bd  movaps xmm15, [rsp]
00007871bd3db8c2  add rsp, 0x30
00007871bd3db8c6  vmovaps xmm0, [rsp]
00007871bd3db8cb  vmovaps xmm1, [rsp+0x10]
00007871bd3db8d1  vmovaps xmm2, [rsp+0x20]
00007871bd3db8d7  vmovaps xmm3, [rsp+0x30]
00007871bd3db8dd  vmovaps xmm4, [rsp+0x40]
00007871bd3db8e3  vmovaps xmm5, [rsp+0x50]
00007871bd3db8e9  vmovaps xmm6, [rsp+0x60]
00007871bd3db8ef  vmovaps xmm7, [rsp+0x70]
00007871bd3db8f5  vmovaps xmm8, [rsp+0x80]
00007871bd3db8fe  vmovaps xmm9, [rsp+0x90]
00007871bd3db907  vmovaps xmm10, [rsp+0xA0]
00007871bd3db910  vmovaps xmm11, [rsp+0xB0]
00007871bd3db919  vmovaps xmm12, [rsp+0xC0]
00007871bd3db922  vmovaps xmm13, [rsp+0xD0]
00007871bd3db92b  vmovaps xmm14, [rsp+0xE0]
00007871bd3db934  add rsp, 0xF0
00007871bd3db93b  pop r11
00007871bd3db93d  pop r10
00007871bd3db93f  pop r9
00007871bd3db941  pop r8
00007871bd3db943  pop rsi
00007871bd3db944  pop rdi
00007871bd3db945  pop rdx
00007871bd3db946  pop rcx
00007871bd3db947  pop rax
00007871bd3db948  add rsp, 0x08
00007871bd3db94c  jmp 0x00007871BD3D9210
00007871bd3db951  sub rsp, 0x08
00007871bd3db955  push rax
00007871bd3db956  push rcx
00007871bd3db957  push rdx
00007871bd3db958  push rdi
00007871bd3db959  push rsi
00007871bd3db95a  push r8
00007871bd3db95c  push r9
00007871bd3db95e  push r10
00007871bd3db960  push r11
00007871bd3db962  sub rsp, 0xF0
00007871bd3db969  vmovaps [rsp], xmm0
00007871bd3db96e  vmovaps [rsp+0x10], xmm1
00007871bd3db974  vmovaps [rsp+0x20], xmm2
00007871bd3db97a  vmovaps [rsp+0x30], xmm4
00007871bd3db980  vmovaps [rsp+0x40], xmm5
00007871bd3db986  vmovaps [rsp+0x50], xmm6
00007871bd3db98c  vmovaps [rsp+0x60], xmm7
00007871bd3db992  vmovaps [rsp+0x70], xmm8
00007871bd3db998  vmovaps [rsp+0x80], xmm9
00007871bd3db9a1  vmovaps [rsp+0x90], xmm10
00007871bd3db9aa  vmovaps [rsp+0xA0], xmm11
00007871bd3db9b3  vmovaps [rsp+0xB0], xmm12
00007871bd3db9bc  vmovaps [rsp+0xC0], xmm13
00007871bd3db9c5  vmovaps [rsp+0xD0], xmm14
00007871bd3db9ce  vmovaps [rsp+0xE0], xmm15
00007871bd3db9d7  sub rsp, 0x30
00007871bd3db9db  movaps [rsp], xmm3
00007871bd3db9df  movaps [rsp+0x10], xmm1
00007871bd3db9e4  movaps [rsp+0x20], xmm15
00007871bd3db9ea  lea rdi, [rsp]
00007871bd3db9ee  mov esi, 0x00
00007871bd3db9f3  mov rax, 0x5BA2FDD2A530
00007871bd3db9fd  call rax
00007871bd3db9ff  movaps xmm3, [rsp]
00007871bd3dba03  add rsp, 0x30
00007871bd3dba07  vmovaps xmm0, [rsp]
00007871bd3dba0c  vmovaps xmm1, [rsp+0x10]
00007871bd3dba12  vmovaps xmm2, [rsp+0x20]
00007871bd3dba18  vmovaps xmm4, [rsp+0x30]
00007871bd3dba1e  vmovaps xmm5, [rsp+0x40]
00007871bd3dba24  vmovaps xmm6, [rsp+0x50]
00007871bd3dba2a  vmovaps xmm7, [rsp+0x60]
00007871bd3dba30  vmovaps xmm8, [rsp+0x70]
00007871bd3dba36  vmovaps xmm9, [rsp+0x80]
00007871bd3dba3f  vmovaps xmm10, [rsp+0x90]
00007871bd3dba48  vmovaps xmm11, [rsp+0xA0]
00007871bd3dba51  vmovaps xmm12, [rsp+0xB0]
00007871bd3dba5a  vmovaps xmm13, [rsp+0xC0]
00007871bd3dba63  vmovaps xmm14, [rsp+0xD0]
00007871bd3dba6c  vmovaps xmm15, [rsp+0xE0]
00007871bd3dba75  add rsp, 0xF0
00007871bd3dba7c  pop r11
00007871bd3dba7e  pop r10
00007871bd3dba80  pop r9
00007871bd3dba82  pop r8
00007871bd3dba84  pop rsi
00007871bd3dba85  pop rdi
00007871bd3dba86  pop rdx
00007871bd3dba87  pop rcx
00007871bd3dba88  pop rax
00007871bd3dba89  add rsp, 0x08
00007871bd3dba8d  jmp 0x00007871BD3D929F
00007871bd3dba92  call 0x00007871BD2D64F0
00007871bd3dba97  jmp 0x00007871BD3D92A9
00007871bd3dba9c  sub rsp, 0x08
00007871bd3dbaa0  push rax
00007871bd3dbaa1  push rcx
00007871bd3dbaa2  push rdx
00007871bd3dbaa3  push rdi
00007871bd3dbaa4  push rsi
00007871bd3dbaa5  push r8
00007871bd3dbaa7  push r9
00007871bd3dbaa9  push r10
00007871bd3dbaab  push r11
00007871bd3dbaad  sub rsp, 0xF0
00007871bd3dbab4  vmovaps [rsp], xmm0
00007871bd3dbab9  vmovaps [rsp+0x10], xmm1
00007871bd3dbabf  vmovaps [rsp+0x20], xmm2
00007871bd3dbac5  vmovaps [rsp+0x30], xmm3
00007871bd3dbacb  vmovaps [rsp+0x40], xmm4
00007871bd3dbad1  vmovaps [rsp+0x50], xmm5
00007871bd3dbad7  vmovaps [rsp+0x60], xmm6
00007871bd3dbadd  vmovaps [rsp+0x70], xmm7
00007871bd3dbae3  vmovaps [rsp+0x80], xmm8
00007871bd3dbaec  vmovaps [rsp+0x90], xmm9
00007871bd3dbaf5  vmovaps [rsp+0xA0], xmm10
00007871bd3dbafe  vmovaps [rsp+0xB0], xmm11
00007871bd3dbb07  vmovaps [rsp+0xC0], xmm12
00007871bd3dbb10  vmovaps [rsp+0xD0], xmm13
00007871bd3dbb19  vmovaps [rsp+0xE0], xmm14
00007871bd3dbb22  sub rsp, 0x30
00007871bd3dbb26  movaps [rsp], xmm15
00007871bd3dbb2b  movaps [rsp+0x10], xmm14
00007871bd3dbb31  movaps [rsp+0x20], xmm4
00007871bd3dbb36  lea rdi, [rsp]
00007871bd3dbb3a  mov esi, 0x00
00007871bd3dbb3f  mov rax, 0x5BA2FDD2A530
00007871bd3dbb49  call rax
00007871bd3dbb4b  movaps xmm15, [rsp]
00007871bd3dbb50  add rsp, 0x30
00007871bd3dbb54  vmovaps xmm0, [rsp]
00007871bd3dbb59  vmovaps xmm1, [rsp+0x10]
00007871bd3dbb5f  vmovaps xmm2, [rsp+0x20]
00007871bd3dbb65  vmovaps xmm3, [rsp+0x30]
00007871bd3dbb6b  vmovaps xmm4, [rsp+0x40]
00007871bd3dbb71  vmovaps xmm5, [rsp+0x50]
00007871bd3dbb77  vmovaps xmm6, [rsp+0x60]
00007871bd3dbb7d  vmovaps xmm7, [rsp+0x70]
00007871bd3dbb83  vmovaps xmm8, [rsp+0x80]
00007871bd3dbb8c  vmovaps xmm9, [rsp+0x90]
00007871bd3dbb95  vmovaps xmm10, [rsp+0xA0]
00007871bd3dbb9e  vmovaps xmm11, [rsp+0xB0]
00007871bd3dbba7  vmovaps xmm12, [rsp+0xC0]
00007871bd3dbbb0  vmovaps xmm13, [rsp+0xD0]
00007871bd3dbbb9  vmovaps xmm14, [rsp+0xE0]
00007871bd3dbbc2  add rsp, 0xF0
00007871bd3dbbc9  pop r11
00007871bd3dbbcb  pop r10
00007871bd3dbbcd  pop r9
00007871bd3dbbcf  pop r8
00007871bd3dbbd1  pop rsi
00007871bd3dbbd2  pop rdi
00007871bd3dbbd3  pop rdx
00007871bd3dbbd4  pop rcx
00007871bd3dbbd5  pop rax
00007871bd3dbbd6  add rsp, 0x08
00007871bd3dbbda  jmp 0x00007871BD3D92D7
00007871bd3dbbdf  sub rsp, 0x08
00007871bd3dbbe3  push rax
00007871bd3dbbe4  push rcx
00007871bd3dbbe5  push rdx
00007871bd3dbbe6  push rdi
00007871bd3dbbe7  push rsi
00007871bd3dbbe8  push r8
00007871bd3dbbea  push r9
00007871bd3dbbec  push r10
00007871bd3dbbee  push r11
00007871bd3dbbf0  sub rsp, 0xF0
00007871bd3dbbf7  vmovaps [rsp], xmm0
00007871bd3dbbfc  vmovaps [rsp+0x10], xmm1
00007871bd3dbc02  vmovaps [rsp+0x20], xmm2
00007871bd3dbc08  vmovaps [rsp+0x30], xmm3
00007871bd3dbc0e  vmovaps [rsp+0x40], xmm4
00007871bd3dbc14  vmovaps [rsp+0x50], xmm5
00007871bd3dbc1a  vmovaps [rsp+0x60], xmm6
00007871bd3dbc20  vmovaps [rsp+0x70], xmm7
00007871bd3dbc26  vmovaps [rsp+0x80], xmm8
00007871bd3dbc2f  vmovaps [rsp+0x90], xmm9
00007871bd3dbc38  vmovaps [rsp+0xA0], xmm10
00007871bd3dbc41  vmovaps [rsp+0xB0], xmm11
00007871bd3dbc4a  vmovaps [rsp+0xC0], xmm12
00007871bd3dbc53  vmovaps [rsp+0xD0], xmm13
00007871bd3dbc5c  vmovaps [rsp+0xE0], xmm15
00007871bd3dbc65  sub rsp, 0x30
00007871bd3dbc69  movaps [rsp], xmm14
00007871bd3dbc6e  movaps [rsp+0x10], xmm2
00007871bd3dbc73  movaps [rsp+0x20], xmm1
00007871bd3dbc78  lea rdi, [rsp]
00007871bd3dbc7c  mov esi, 0x00
00007871bd3dbc81  mov rax, 0x5BA2FDD2A530
00007871bd3dbc8b  call rax
00007871bd3dbc8d  movaps xmm14, [rsp]
00007871bd3dbc92  add rsp, 0x30
00007871bd3dbc96  vmovaps xmm0, [rsp]
00007871bd3dbc9b  vmovaps xmm1, [rsp+0x10]
00007871bd3dbca1  vmovaps xmm2, [rsp+0x20]
00007871bd3dbca7  vmovaps xmm3, [rsp+0x30]
00007871bd3dbcad  vmovaps xmm4, [rsp+0x40]
00007871bd3dbcb3  vmovaps xmm5, [rsp+0x50]
00007871bd3dbcb9  vmovaps xmm6, [rsp+0x60]
00007871bd3dbcbf  vmovaps xmm7, [rsp+0x70]
00007871bd3dbcc5  vmovaps xmm8, [rsp+0x80]
00007871bd3dbcce  vmovaps xmm9, [rsp+0x90]
00007871bd3dbcd7  vmovaps xmm10, [rsp+0xA0]
00007871bd3dbce0  vmovaps xmm11, [rsp+0xB0]
00007871bd3dbce9  vmovaps xmm12, [rsp+0xC0]
00007871bd3dbcf2  vmovaps xmm13, [rsp+0xD0]
00007871bd3dbcfb  vmovaps xmm15, [rsp+0xE0]
00007871bd3dbd04  add rsp, 0xF0
00007871bd3dbd0b  pop r11
00007871bd3dbd0d  pop r10
00007871bd3dbd0f  pop r9
00007871bd3dbd11  pop r8
00007871bd3dbd13  pop rsi
00007871bd3dbd14  pop rdi
00007871bd3dbd15  pop rdx
00007871bd3dbd16  pop rcx
00007871bd3dbd17  pop rax
00007871bd3dbd18  add rsp, 0x08
00007871bd3dbd1c  jmp 0x00007871BD3D92FD
00007871bd3dbd21  sub rsp, 0x08
00007871bd3dbd25  push rax
00007871bd3dbd26  push rcx
00007871bd3dbd27  push rdx
00007871bd3dbd28  push rdi
00007871bd3dbd29  push rsi
00007871bd3dbd2a  push r8
00007871bd3dbd2c  push r9
00007871bd3dbd2e  push r10
00007871bd3dbd30  push r11
00007871bd3dbd32  sub rsp, 0xF0
00007871bd3dbd39  vmovaps [rsp], xmm0
00007871bd3dbd3e  vmovaps [rsp+0x10], xmm2
00007871bd3dbd44  vmovaps [rsp+0x20], xmm3
00007871bd3dbd4a  vmovaps [rsp+0x30], xmm4
00007871bd3dbd50  vmovaps [rsp+0x40], xmm5
00007871bd3dbd56  vmovaps [rsp+0x50], xmm6
00007871bd3dbd5c  vmovaps [rsp+0x60], xmm7
00007871bd3dbd62  vmovaps [rsp+0x70], xmm8
00007871bd3dbd68  vmovaps [rsp+0x80], xmm9
00007871bd3dbd71  vmovaps [rsp+0x90], xmm10
00007871bd3dbd7a  vmovaps [rsp+0xA0], xmm11
00007871bd3dbd83  vmovaps [rsp+0xB0], xmm12
00007871bd3dbd8c  vmovaps [rsp+0xC0], xmm13
00007871bd3dbd95  vmovaps [rsp+0xD0], xmm14
00007871bd3dbd9e  vmovaps [rsp+0xE0], xmm15
00007871bd3dbda7  sub rsp, 0x30
00007871bd3dbdab  movaps [rsp], xmm1
00007871bd3dbdaf  movaps [rsp+0x10], xmm4
00007871bd3dbdb4  movaps [rsp+0x20], xmm9
00007871bd3dbdba  lea rdi, [rsp]
00007871bd3dbdbe  mov esi, 0x00
00007871bd3dbdc3  mov rax, 0x5BA2FDD2A530
00007871bd3dbdcd  call rax
00007871bd3dbdcf  movaps xmm1, [rsp]
00007871bd3dbdd3  add rsp, 0x30
00007871bd3dbdd7  vmovaps xmm0, [rsp]
00007871bd3dbddc  vmovaps xmm2, [rsp+0x10]
00007871bd3dbde2  vmovaps xmm3, [rsp+0x20]
00007871bd3dbde8  vmovaps xmm4, [rsp+0x30]
00007871bd3dbdee  vmovaps xmm5, [rsp+0x40]
00007871bd3dbdf4  vmovaps xmm6, [rsp+0x50]
00007871bd3dbdfa  vmovaps xmm7, [rsp+0x60]
00007871bd3dbe00  vmovaps xmm8, [rsp+0x70]
00007871bd3dbe06  vmovaps xmm9, [rsp+0x80]
00007871bd3dbe0f  vmovaps xmm10, [rsp+0x90]
00007871bd3dbe18  vmovaps xmm11, [rsp+0xA0]
00007871bd3dbe21  vmovaps xmm12, [rsp+0xB0]
00007871bd3dbe2a  vmovaps xmm13, [rsp+0xC0]
00007871bd3dbe33  vmovaps xmm14, [rsp+0xD0]
00007871bd3dbe3c  vmovaps xmm15, [rsp+0xE0]
00007871bd3dbe45  add rsp, 0xF0
00007871bd3dbe4c  pop r11
00007871bd3dbe4e  pop r10
00007871bd3dbe50  pop r9
00007871bd3dbe52  pop r8
00007871bd3dbe54  pop rsi
00007871bd3dbe55  pop rdi
00007871bd3dbe56  pop rdx
00007871bd3dbe57  pop rcx
00007871bd3dbe58  pop rax
00007871bd3dbe59  add rsp, 0x08
00007871bd3dbe5d  jmp 0x00007871BD3D931B
00007871bd3dbe62  sub rsp, 0x08
00007871bd3dbe66  push rax
00007871bd3dbe67  push rcx
00007871bd3dbe68  push rdx
00007871bd3dbe69  push rdi
00007871bd3dbe6a  push rsi
00007871bd3dbe6b  push r8
00007871bd3dbe6d  push r9
00007871bd3dbe6f  push r10
00007871bd3dbe71  push r11
00007871bd3dbe73  sub rsp, 0xF0
00007871bd3dbe7a  vmovaps [rsp], xmm0
00007871bd3dbe7f  vmovaps [rsp+0x10], xmm1
00007871bd3dbe85  vmovaps [rsp+0x20], xmm2
00007871bd3dbe8b  vmovaps [rsp+0x30], xmm3
00007871bd3dbe91  vmovaps [rsp+0x40], xmm5
00007871bd3dbe97  vmovaps [rsp+0x50], xmm6
00007871bd3dbe9d  vmovaps [rsp+0x60], xmm7
00007871bd3dbea3  vmovaps [rsp+0x70], xmm8
00007871bd3dbea9  vmovaps [rsp+0x80], xmm9
00007871bd3dbeb2  vmovaps [rsp+0x90], xmm10
00007871bd3dbebb  vmovaps [rsp+0xA0], xmm11
00007871bd3dbec4  vmovaps [rsp+0xB0], xmm12
00007871bd3dbecd  vmovaps [rsp+0xC0], xmm13
00007871bd3dbed6  vmovaps [rsp+0xD0], xmm14
00007871bd3dbedf  vmovaps [rsp+0xE0], xmm15
00007871bd3dbee8  sub rsp, 0x30
00007871bd3dbeec  movaps [rsp], xmm4
00007871bd3dbef0  movaps [rsp+0x10], xmm2
00007871bd3dbef5  movaps [rsp+0x20], xmm9
00007871bd3dbefb  lea rdi, [rsp]
00007871bd3dbeff  mov esi, 0x00
00007871bd3dbf04  mov rax, 0x5BA2FDD2A530
00007871bd3dbf0e  call rax
00007871bd3dbf10  movaps xmm4, [rsp]
00007871bd3dbf14  add rsp, 0x30
00007871bd3dbf18  vmovaps xmm0, [rsp]
00007871bd3dbf1d  vmovaps xmm1, [rsp+0x10]
00007871bd3dbf23  vmovaps xmm2, [rsp+0x20]
00007871bd3dbf29  vmovaps xmm3, [rsp+0x30]
00007871bd3dbf2f  vmovaps xmm5, [rsp+0x40]
00007871bd3dbf35  vmovaps xmm6, [rsp+0x50]
00007871bd3dbf3b  vmovaps xmm7, [rsp+0x60]
00007871bd3dbf41  vmovaps xmm8, [rsp+0x70]
00007871bd3dbf47  vmovaps xmm9, [rsp+0x80]
00007871bd3dbf50  vmovaps xmm10, [rsp+0x90]
00007871bd3dbf59  vmovaps xmm11, [rsp+0xA0]
00007871bd3dbf62  vmovaps xmm12, [rsp+0xB0]
00007871bd3dbf6b  vmovaps xmm13, [rsp+0xC0]
00007871bd3dbf74  vmovaps xmm14, [rsp+0xD0]
00007871bd3dbf7d  vmovaps xmm15, [rsp+0xE0]
00007871bd3dbf86  add rsp, 0xF0
00007871bd3dbf8d  pop r11
00007871bd3dbf8f  pop r10
00007871bd3dbf91  pop r9
00007871bd3dbf93  pop r8
00007871bd3dbf95  pop rsi
00007871bd3dbf96  pop rdi
00007871bd3dbf97  pop rdx
00007871bd3dbf98  pop rcx
00007871bd3dbf99  pop rax
00007871bd3dbf9a  add rsp, 0x08
00007871bd3dbf9e  jmp 0x00007871BD3D934B
00007871bd3dbfa3  sub rsp, 0x08
00007871bd3dbfa7  push rax
00007871bd3dbfa8  push rcx
00007871bd3dbfa9  push rdx
00007871bd3dbfaa  push rdi
00007871bd3dbfab  push rsi
00007871bd3dbfac  push r8
00007871bd3dbfae  push r9
00007871bd3dbfb0  push r10
00007871bd3dbfb2  push r11
00007871bd3dbfb4  sub rsp, 0xF0
00007871bd3dbfbb  vmovaps [rsp], xmm0
00007871bd3dbfc0  vmovaps [rsp+0x10], xmm1
00007871bd3dbfc6  vmovaps [rsp+0x20], xmm2
00007871bd3dbfcc  vmovaps [rsp+0x30], xmm3
00007871bd3dbfd2  vmovaps [rsp+0x40], xmm4
00007871bd3dbfd8  vmovaps [rsp+0x50], xmm5
00007871bd3dbfde  vmovaps [rsp+0x60], xmm6
00007871bd3dbfe4  vmovaps [rsp+0x70], xmm7
00007871bd3dbfea  vmovaps [rsp+0x80], xmm8
00007871bd3dbff3  vmovaps [rsp+0x90], xmm10
00007871bd3dbffc  vmovaps [rsp+0xA0], xmm11
00007871bd3dc005  vmovaps [rsp+0xB0], xmm12
00007871bd3dc00e  vmovaps [rsp+0xC0], xmm13
00007871bd3dc017  vmovaps [rsp+0xD0], xmm14
00007871bd3dc020  vmovaps [rsp+0xE0], xmm15
00007871bd3dc029  sub rsp, 0x30
00007871bd3dc02d  movaps [rsp], xmm9
00007871bd3dc032  movaps [rsp+0x10], xmm2
00007871bd3dc037  movaps [rsp+0x20], xmm1
00007871bd3dc03c  lea rdi, [rsp]
00007871bd3dc040  mov esi, 0x00
00007871bd3dc045  mov rax, 0x5BA2FDD2A530
00007871bd3dc04f  call rax
00007871bd3dc051  movaps xmm9, [rsp]
00007871bd3dc056  add rsp, 0x30
00007871bd3dc05a  vmovaps xmm0, [rsp]
00007871bd3dc05f  vmovaps xmm1, [rsp+0x10]
00007871bd3dc065  vmovaps xmm2, [rsp+0x20]
00007871bd3dc06b  vmovaps xmm3, [rsp+0x30]
00007871bd3dc071  vmovaps xmm4, [rsp+0x40]
00007871bd3dc077  vmovaps xmm5, [rsp+0x50]
00007871bd3dc07d  vmovaps xmm6, [rsp+0x60]
00007871bd3dc083  vmovaps xmm7, [rsp+0x70]
00007871bd3dc089  vmovaps xmm8, [rsp+0x80]
00007871bd3dc092  vmovaps xmm10, [rsp+0x90]
00007871bd3dc09b  vmovaps xmm11, [rsp+0xA0]
00007871bd3dc0a4  vmovaps xmm12, [rsp+0xB0]
00007871bd3dc0ad  vmovaps xmm13, [rsp+0xC0]
00007871bd3dc0b6  vmovaps xmm14, [rsp+0xD0]
00007871bd3dc0bf  vmovaps xmm15, [rsp+0xE0]
00007871bd3dc0c8  add rsp, 0xF0
00007871bd3dc0cf  pop r11
00007871bd3dc0d1  pop r10
00007871bd3dc0d3  pop r9
00007871bd3dc0d5  pop r8
00007871bd3dc0d7  pop rsi
00007871bd3dc0d8  pop rdi
00007871bd3dc0d9  pop rdx
00007871bd3dc0da  pop rcx
00007871bd3dc0db  pop rax
00007871bd3dc0dc  add rsp, 0x08
00007871bd3dc0e0  jmp 0x00007871BD3D9381
00007871bd3dc0e5  sub rsp, 0x08
00007871bd3dc0e9  push rax
00007871bd3dc0ea  push rcx
00007871bd3dc0eb  push rdx
00007871bd3dc0ec  push rdi
00007871bd3dc0ed  push rsi
00007871bd3dc0ee  push r8
00007871bd3dc0f0  push r9
00007871bd3dc0f2  push r10
00007871bd3dc0f4  push r11
00007871bd3dc0f6  sub rsp, 0xF0
00007871bd3dc0fd  vmovaps [rsp], xmm0
00007871bd3dc102  vmovaps [rsp+0x10], xmm2
00007871bd3dc108  vmovaps [rsp+0x20], xmm3
00007871bd3dc10e  vmovaps [rsp+0x30], xmm4
00007871bd3dc114  vmovaps [rsp+0x40], xmm5
00007871bd3dc11a  vmovaps [rsp+0x50], xmm6
00007871bd3dc120  vmovaps [rsp+0x60], xmm7
00007871bd3dc126  vmovaps [rsp+0x70], xmm8
00007871bd3dc12c  vmovaps [rsp+0x80], xmm9
00007871bd3dc135  vmovaps [rsp+0x90], xmm10
00007871bd3dc13e  vmovaps [rsp+0xA0], xmm11
00007871bd3dc147  vmovaps [rsp+0xB0], xmm12
00007871bd3dc150  vmovaps [rsp+0xC0], xmm13
00007871bd3dc159  vmovaps [rsp+0xD0], xmm14
00007871bd3dc162  vmovaps [rsp+0xE0], xmm15
00007871bd3dc16b  sub rsp, 0x30
00007871bd3dc16f  movaps [rsp], xmm1
00007871bd3dc173  movaps [rsp+0x10], xmm15
00007871bd3dc179  movaps [rsp+0x20], xmm6
00007871bd3dc17e  lea rdi, [rsp]
00007871bd3dc182  mov esi, 0x00
00007871bd3dc187  mov rax, 0x5BA2FDD2A530
00007871bd3dc191  call rax
00007871bd3dc193  movaps xmm1, [rsp]
00007871bd3dc197  add rsp, 0x30
00007871bd3dc19b  vmovaps xmm0, [rsp]
00007871bd3dc1a0  vmovaps xmm2, [rsp+0x10]
00007871bd3dc1a6  vmovaps xmm3, [rsp+0x20]
00007871bd3dc1ac  vmovaps xmm4, [rsp+0x30]
00007871bd3dc1b2  vmovaps xmm5, [rsp+0x40]
00007871bd3dc1b8  vmovaps xmm6, [rsp+0x50]
00007871bd3dc1be  vmovaps xmm7, [rsp+0x60]
00007871bd3dc1c4  vmovaps xmm8, [rsp+0x70]
00007871bd3dc1ca  vmovaps xmm9, [rsp+0x80]
00007871bd3dc1d3  vmovaps xmm10, [rsp+0x90]
00007871bd3dc1dc  vmovaps xmm11, [rsp+0xA0]
00007871bd3dc1e5  vmovaps xmm12, [rsp+0xB0]
00007871bd3dc1ee  vmovaps xmm13, [rsp+0xC0]
00007871bd3dc1f7  vmovaps xmm14, [rsp+0xD0]
00007871bd3dc200  vmovaps xmm15, [rsp+0xE0]
00007871bd3dc209  add rsp, 0xF0
00007871bd3dc210  pop r11
00007871bd3dc212  pop r10
00007871bd3dc214  pop r9
00007871bd3dc216  pop r8
00007871bd3dc218  pop rsi
00007871bd3dc219  pop rdi
00007871bd3dc21a  pop rdx
00007871bd3dc21b  pop rcx
00007871bd3dc21c  pop rax
00007871bd3dc21d  add rsp, 0x08
00007871bd3dc221  jmp 0x00007871BD3D93A2
00007871bd3dc226  sub rsp, 0x08
00007871bd3dc22a  push rax
00007871bd3dc22b  push rcx
00007871bd3dc22c  push rdx
00007871bd3dc22d  push rdi
00007871bd3dc22e  push rsi
00007871bd3dc22f  push r8
00007871bd3dc231  push r9
00007871bd3dc233  push r10
00007871bd3dc235  push r11
00007871bd3dc237  sub rsp, 0xF0
00007871bd3dc23e  vmovaps [rsp], xmm0
00007871bd3dc243  vmovaps [rsp+0x10], xmm1
00007871bd3dc249  vmovaps [rsp+0x20], xmm2
00007871bd3dc24f  vmovaps [rsp+0x30], xmm3
00007871bd3dc255  vmovaps [rsp+0x40], xmm4
00007871bd3dc25b  vmovaps [rsp+0x50], xmm5
00007871bd3dc261  vmovaps [rsp+0x60], xmm6
00007871bd3dc267  vmovaps [rsp+0x70], xmm7
00007871bd3dc26d  vmovaps [rsp+0x80], xmm8
00007871bd3dc276  vmovaps [rsp+0x90], xmm9
00007871bd3dc27f  vmovaps [rsp+0xA0], xmm10
00007871bd3dc288  vmovaps [rsp+0xB0], xmm11
00007871bd3dc291  vmovaps [rsp+0xC0], xmm12
00007871bd3dc29a  vmovaps [rsp+0xD0], xmm13
00007871bd3dc2a3  vmovaps [rsp+0xE0], xmm14
00007871bd3dc2ac  sub rsp, 0x30
00007871bd3dc2b0  movaps [rsp], xmm15
00007871bd3dc2b5  movaps [rsp+0x10], xmm5
00007871bd3dc2ba  movaps [rsp+0x20], xmm3
00007871bd3dc2bf  lea rdi, [rsp]
00007871bd3dc2c3  mov esi, 0x00
00007871bd3dc2c8  mov rax, 0x5BA2FDD2A530
00007871bd3dc2d2  call rax
00007871bd3dc2d4  movaps xmm15, [rsp]
00007871bd3dc2d9  add rsp, 0x30
00007871bd3dc2dd  vmovaps xmm0, [rsp]
00007871bd3dc2e2  vmovaps xmm1, [rsp+0x10]
00007871bd3dc2e8  vmovaps xmm2, [rsp+0x20]
00007871bd3dc2ee  vmovaps xmm3, [rsp+0x30]
00007871bd3dc2f4  vmovaps xmm4, [rsp+0x40]
00007871bd3dc2fa  vmovaps xmm5, [rsp+0x50]
00007871bd3dc300  vmovaps xmm6, [rsp+0x60]
00007871bd3dc306  vmovaps xmm7, [rsp+0x70]
00007871bd3dc30c  vmovaps xmm8, [rsp+0x80]
00007871bd3dc315  vmovaps xmm9, [rsp+0x90]
00007871bd3dc31e  vmovaps xmm10, [rsp+0xA0]
00007871bd3dc327  vmovaps xmm11, [rsp+0xB0]
00007871bd3dc330  vmovaps xmm12, [rsp+0xC0]
00007871bd3dc339  vmovaps xmm13, [rsp+0xD0]
00007871bd3dc342  vmovaps xmm14, [rsp+0xE0]
00007871bd3dc34b  add rsp, 0xF0
00007871bd3dc352  pop r11
00007871bd3dc354  pop r10
00007871bd3dc356  pop r9
00007871bd3dc358  pop r8
00007871bd3dc35a  pop rsi
00007871bd3dc35b  pop rdi
00007871bd3dc35c  pop rdx
00007871bd3dc35d  pop rcx
00007871bd3dc35e  pop rax
00007871bd3dc35f  add rsp, 0x08
00007871bd3dc363  jmp 0x00007871BD3D93BC
00007871bd3dc368  sub rsp, 0x08
00007871bd3dc36c  push rax
00007871bd3dc36d  push rcx
00007871bd3dc36e  push rdx
00007871bd3dc36f  push rdi
00007871bd3dc370  push rsi
00007871bd3dc371  push r8
00007871bd3dc373  push r9
00007871bd3dc375  push r10
00007871bd3dc377  push r11
00007871bd3dc379  sub rsp, 0xF0
00007871bd3dc380  vmovaps [rsp], xmm0
00007871bd3dc385  vmovaps [rsp+0x10], xmm1
00007871bd3dc38b  vmovaps [rsp+0x20], xmm2
00007871bd3dc391  vmovaps [rsp+0x30], xmm3
00007871bd3dc397  vmovaps [rsp+0x40], xmm4
00007871bd3dc39d  vmovaps [rsp+0x50], xmm6
00007871bd3dc3a3  vmovaps [rsp+0x60], xmm7
00007871bd3dc3a9  vmovaps [rsp+0x70], xmm8
00007871bd3dc3af  vmovaps [rsp+0x80], xmm9
00007871bd3dc3b8  vmovaps [rsp+0x90], xmm10
00007871bd3dc3c1  vmovaps [rsp+0xA0], xmm11
00007871bd3dc3ca  vmovaps [rsp+0xB0], xmm12
00007871bd3dc3d3  vmovaps [rsp+0xC0], xmm13
00007871bd3dc3dc  vmovaps [rsp+0xD0], xmm14
00007871bd3dc3e5  vmovaps [rsp+0xE0], xmm15
00007871bd3dc3ee  sub rsp, 0x30
00007871bd3dc3f2  movaps [rsp], xmm5
00007871bd3dc3f6  movaps [rsp+0x10], xmm8
00007871bd3dc3fc  movaps [rsp+0x20], xmm6
00007871bd3dc401  lea rdi, [rsp]
00007871bd3dc405  mov esi, 0x00
00007871bd3dc40a  mov rax, 0x5BA2FDD2A530
00007871bd3dc414  call rax
00007871bd3dc416  movaps xmm5, [rsp]
00007871bd3dc41a  add rsp, 0x30
00007871bd3dc41e  vmovaps xmm0, [rsp]
00007871bd3dc423  vmovaps xmm1, [rsp+0x10]
00007871bd3dc429  vmovaps xmm2, [rsp+0x20]
00007871bd3dc42f  vmovaps xmm3, [rsp+0x30]
00007871bd3dc435  vmovaps xmm4, [rsp+0x40]
00007871bd3dc43b  vmovaps xmm6, [rsp+0x50]
00007871bd3dc441  vmovaps xmm7, [rsp+0x60]
00007871bd3dc447  vmovaps xmm8, [rsp+0x70]
00007871bd3dc44d  vmovaps xmm9, [rsp+0x80]
00007871bd3dc456  vmovaps xmm10, [rsp+0x90]
00007871bd3dc45f  vmovaps xmm11, [rsp+0xA0]
00007871bd3dc468  vmovaps xmm12, [rsp+0xB0]
00007871bd3dc471  vmovaps xmm13, [rsp+0xC0]
00007871bd3dc47a  vmovaps xmm14, [rsp+0xD0]
00007871bd3dc483  vmovaps xmm15, [rsp+0xE0]
00007871bd3dc48c  add rsp, 0xF0
00007871bd3dc493  pop r11
00007871bd3dc495  pop r10
00007871bd3dc497  pop r9
00007871bd3dc499  pop r8
00007871bd3dc49b  pop rsi
00007871bd3dc49c  pop rdi
00007871bd3dc49d  pop rdx
00007871bd3dc49e  pop rcx
00007871bd3dc49f  pop rax
00007871bd3dc4a0  add rsp, 0x08
00007871bd3dc4a4  jmp 0x00007871BD3D93E0
00007871bd3dc4a9  sub rsp, 0x08
00007871bd3dc4ad  push rax
00007871bd3dc4ae  push rcx
00007871bd3dc4af  push rdx
00007871bd3dc4b0  push rdi
00007871bd3dc4b1  push rsi
00007871bd3dc4b2  push r8
00007871bd3dc4b4  push r9
00007871bd3dc4b6  push r10
00007871bd3dc4b8  push r11
00007871bd3dc4ba  sub rsp, 0xF0
00007871bd3dc4c1  vmovaps [rsp], xmm0
00007871bd3dc4c6  vmovaps [rsp+0x10], xmm1
00007871bd3dc4cc  vmovaps [rsp+0x20], xmm2
00007871bd3dc4d2  vmovaps [rsp+0x30], xmm3
00007871bd3dc4d8  vmovaps [rsp+0x40], xmm4
00007871bd3dc4de  vmovaps [rsp+0x50], xmm5
00007871bd3dc4e4  vmovaps [rsp+0x60], xmm7
00007871bd3dc4ea  vmovaps [rsp+0x70], xmm8
00007871bd3dc4f0  vmovaps [rsp+0x80], xmm9
00007871bd3dc4f9  vmovaps [rsp+0x90], xmm10
00007871bd3dc502  vmovaps [rsp+0xA0], xmm11
00007871bd3dc50b  vmovaps [rsp+0xB0], xmm12
00007871bd3dc514  vmovaps [rsp+0xC0], xmm13
00007871bd3dc51d  vmovaps [rsp+0xD0], xmm14
00007871bd3dc526  vmovaps [rsp+0xE0], xmm15
00007871bd3dc52f  sub rsp, 0x30
00007871bd3dc533  movaps [rsp], xmm6
00007871bd3dc537  movaps [rsp+0x10], xmm10
00007871bd3dc53d  movaps [rsp+0x20], xmm8
00007871bd3dc543  lea rdi, [rsp]
00007871bd3dc547  mov esi, 0x00
00007871bd3dc54c  mov rax, 0x5BA2FDD2A530
00007871bd3dc556  call rax
00007871bd3dc558  movaps xmm6, [rsp]
00007871bd3dc55c  add rsp, 0x30
00007871bd3dc560  vmovaps xmm0, [rsp]
00007871bd3dc565  vmovaps xmm1, [rsp+0x10]
00007871bd3dc56b  vmovaps xmm2, [rsp+0x20]
00007871bd3dc571  vmovaps xmm3, [rsp+0x30]
00007871bd3dc577  vmovaps xmm4, [rsp+0x40]
00007871bd3dc57d  vmovaps xmm5, [rsp+0x50]
00007871bd3dc583  vmovaps xmm7, [rsp+0x60]
00007871bd3dc589  vmovaps xmm8, [rsp+0x70]
00007871bd3dc58f  vmovaps xmm9, [rsp+0x80]
00007871bd3dc598  vmovaps xmm10, [rsp+0x90]
00007871bd3dc5a1  vmovaps xmm11, [rsp+0xA0]
00007871bd3dc5aa  vmovaps xmm12, [rsp+0xB0]
00007871bd3dc5b3  vmovaps xmm13, [rsp+0xC0]
00007871bd3dc5bc  vmovaps xmm14, [rsp+0xD0]
00007871bd3dc5c5  vmovaps xmm15, [rsp+0xE0]
00007871bd3dc5ce  add rsp, 0xF0
00007871bd3dc5d5  pop r11
00007871bd3dc5d7  pop r10
00007871bd3dc5d9  pop r9
00007871bd3dc5db  pop r8
00007871bd3dc5dd  pop rsi
00007871bd3dc5de  pop rdi
00007871bd3dc5df  pop rdx
00007871bd3dc5e0  pop rcx
00007871bd3dc5e1  pop rax
00007871bd3dc5e2  add rsp, 0x08
00007871bd3dc5e6  jmp 0x00007871BD3D9405
00007871bd3dc5eb  sub rsp, 0x08
00007871bd3dc5ef  push rax
00007871bd3dc5f0  push rcx
00007871bd3dc5f1  push rdx
00007871bd3dc5f2  push rdi
00007871bd3dc5f3  push rsi
00007871bd3dc5f4  push r8
00007871bd3dc5f6  push r9
00007871bd3dc5f8  push r10
00007871bd3dc5fa  push r11
00007871bd3dc5fc  sub rsp, 0xF0
00007871bd3dc603  vmovaps [rsp], xmm0
00007871bd3dc608  vmovaps [rsp+0x10], xmm1
00007871bd3dc60e  vmovaps [rsp+0x20], xmm2
00007871bd3dc614  vmovaps [rsp+0x30], xmm3
00007871bd3dc61a  vmovaps [rsp+0x40], xmm4
00007871bd3dc620  vmovaps [rsp+0x50], xmm5
00007871bd3dc626  vmovaps [rsp+0x60], xmm6
00007871bd3dc62c  vmovaps [rsp+0x70], xmm7
00007871bd3dc632  vmovaps [rsp+0x80], xmm8
00007871bd3dc63b  vmovaps [rsp+0x90], xmm9
00007871bd3dc644  vmovaps [rsp+0xA0], xmm11
00007871bd3dc64d  vmovaps [rsp+0xB0], xmm12
00007871bd3dc656  vmovaps [rsp+0xC0], xmm13
00007871bd3dc65f  vmovaps [rsp+0xD0], xmm14
00007871bd3dc668  vmovaps [rsp+0xE0], xmm15
00007871bd3dc671  sub rsp, 0x30
00007871bd3dc675  movaps [rsp], xmm10
00007871bd3dc67a  movaps [rsp+0x10], xmm8
00007871bd3dc680  movaps [rsp+0x20], xmm14
00007871bd3dc686  lea rdi, [rsp]
00007871bd3dc68a  mov esi, 0x00
00007871bd3dc68f  mov rax, 0x5BA2FDD2A530
00007871bd3dc699  call rax
00007871bd3dc69b  movaps xmm10, [rsp]
00007871bd3dc6a0  add rsp, 0x30
00007871bd3dc6a4  vmovaps xmm0, [rsp]
00007871bd3dc6a9  vmovaps xmm1, [rsp+0x10]
00007871bd3dc6af  vmovaps xmm2, [rsp+0x20]
00007871bd3dc6b5  vmovaps xmm3, [rsp+0x30]
00007871bd3dc6bb  vmovaps xmm4, [rsp+0x40]
00007871bd3dc6c1  vmovaps xmm5, [rsp+0x50]
00007871bd3dc6c7  vmovaps xmm6, [rsp+0x60]
00007871bd3dc6cd  vmovaps xmm7, [rsp+0x70]
00007871bd3dc6d3  vmovaps xmm8, [rsp+0x80]
00007871bd3dc6dc  vmovaps xmm9, [rsp+0x90]
00007871bd3dc6e5  vmovaps xmm11, [rsp+0xA0]
00007871bd3dc6ee  vmovaps xmm12, [rsp+0xB0]
00007871bd3dc6f7  vmovaps xmm13, [rsp+0xC0]
00007871bd3dc700  vmovaps xmm14, [rsp+0xD0]
00007871bd3dc709  vmovaps xmm15, [rsp+0xE0]
00007871bd3dc712  add rsp, 0xF0
00007871bd3dc719  pop r11
00007871bd3dc71b  pop r10
00007871bd3dc71d  pop r9
00007871bd3dc71f  pop r8
00007871bd3dc721  pop rsi
00007871bd3dc722  pop rdi
00007871bd3dc723  pop rdx
00007871bd3dc724  pop rcx
00007871bd3dc725  pop rax
00007871bd3dc726  add rsp, 0x08
00007871bd3dc72a  jmp 0x00007871BD3D9425
00007871bd3dc72f  sub rsp, 0x08
00007871bd3dc733  push rax
00007871bd3dc734  push rcx
00007871bd3dc735  push rdx
00007871bd3dc736  push rdi
00007871bd3dc737  push rsi
00007871bd3dc738  push r8
00007871bd3dc73a  push r9
00007871bd3dc73c  push r10
00007871bd3dc73e  push r11
00007871bd3dc740  sub rsp, 0xF0
00007871bd3dc747  vmovaps [rsp], xmm0
00007871bd3dc74c  vmovaps [rsp+0x10], xmm1
00007871bd3dc752  vmovaps [rsp+0x20], xmm2
00007871bd3dc758  vmovaps [rsp+0x30], xmm3
00007871bd3dc75e  vmovaps [rsp+0x40], xmm4
00007871bd3dc764  vmovaps [rsp+0x50], xmm5
00007871bd3dc76a  vmovaps [rsp+0x60], xmm6
00007871bd3dc770  vmovaps [rsp+0x70], xmm7
00007871bd3dc776  vmovaps [rsp+0x80], xmm8
00007871bd3dc77f  vmovaps [rsp+0x90], xmm9
00007871bd3dc788  vmovaps [rsp+0xA0], xmm10
00007871bd3dc791  vmovaps [rsp+0xB0], xmm11
00007871bd3dc79a  vmovaps [rsp+0xC0], xmm12
00007871bd3dc7a3  vmovaps [rsp+0xD0], xmm13
00007871bd3dc7ac  vmovaps [rsp+0xE0], xmm15
00007871bd3dc7b5  sub rsp, 0x30
00007871bd3dc7b9  movaps [rsp], xmm14
00007871bd3dc7be  movaps [rsp+0x10], xmm8
00007871bd3dc7c4  movaps [rsp+0x20], xmm4
00007871bd3dc7c9  lea rdi, [rsp]
00007871bd3dc7cd  mov esi, 0x00
00007871bd3dc7d2  mov rax, 0x5BA2FDD2A530
00007871bd3dc7dc  call rax
00007871bd3dc7de  movaps xmm14, [rsp]
00007871bd3dc7e3  add rsp, 0x30
00007871bd3dc7e7  vmovaps xmm0, [rsp]
00007871bd3dc7ec  vmovaps xmm1, [rsp+0x10]
00007871bd3dc7f2  vmovaps xmm2, [rsp+0x20]
00007871bd3dc7f8  vmovaps xmm3, [rsp+0x30]
00007871bd3dc7fe  vmovaps xmm4, [rsp+0x40]
00007871bd3dc804  vmovaps xmm5, [rsp+0x50]
00007871bd3dc80a  vmovaps xmm6, [rsp+0x60]
00007871bd3dc810  vmovaps xmm7, [rsp+0x70]
00007871bd3dc816  vmovaps xmm8, [rsp+0x80]
00007871bd3dc81f  vmovaps xmm9, [rsp+0x90]
00007871bd3dc828  vmovaps xmm10, [rsp+0xA0]
00007871bd3dc831  vmovaps xmm11, [rsp+0xB0]
00007871bd3dc83a  vmovaps xmm12, [rsp+0xC0]
00007871bd3dc843  vmovaps xmm13, [rsp+0xD0]
00007871bd3dc84c  vmovaps xmm15, [rsp+0xE0]
00007871bd3dc855  add rsp, 0xF0
00007871bd3dc85c  pop r11
00007871bd3dc85e  pop r10
00007871bd3dc860  pop r9
00007871bd3dc862  pop r8
00007871bd3dc864  pop rsi
00007871bd3dc865  pop rdi
00007871bd3dc866  pop rdx
00007871bd3dc867  pop rcx
00007871bd3dc868  pop rax
00007871bd3dc869  add rsp, 0x08
00007871bd3dc86d  jmp 0x00007871BD3D9445
00007871bd3dc872  sub rsp, 0x08
00007871bd3dc876  push rax
00007871bd3dc877  push rcx
00007871bd3dc878  push rdx
00007871bd3dc879  push rdi
00007871bd3dc87a  push rsi
00007871bd3dc87b  push r8
00007871bd3dc87d  push r9
00007871bd3dc87f  push r10
00007871bd3dc881  push r11
00007871bd3dc883  sub rsp, 0xF0
00007871bd3dc88a  vmovaps [rsp], xmm0
00007871bd3dc88f  vmovaps [rsp+0x10], xmm1
00007871bd3dc895  vmovaps [rsp+0x20], xmm2
00007871bd3dc89b  vmovaps [rsp+0x30], xmm3
00007871bd3dc8a1  vmovaps [rsp+0x40], xmm5
00007871bd3dc8a7  vmovaps [rsp+0x50], xmm6
00007871bd3dc8ad  vmovaps [rsp+0x60], xmm7
00007871bd3dc8b3  vmovaps [rsp+0x70], xmm8
00007871bd3dc8b9  vmovaps [rsp+0x80], xmm9
00007871bd3dc8c2  vmovaps [rsp+0x90], xmm10
00007871bd3dc8cb  vmovaps [rsp+0xA0], xmm11
00007871bd3dc8d4  vmovaps [rsp+0xB0], xmm12
00007871bd3dc8dd  vmovaps [rsp+0xC0], xmm13
00007871bd3dc8e6  vmovaps [rsp+0xD0], xmm14
00007871bd3dc8ef  vmovaps [rsp+0xE0], xmm15
00007871bd3dc8f8  sub rsp, 0x30
00007871bd3dc8fc  movaps [rsp], xmm4
00007871bd3dc900  movaps [rsp+0x10], xmm13
00007871bd3dc906  movaps [rsp+0x20], xmm8
00007871bd3dc90c  lea rdi, [rsp]
00007871bd3dc910  mov esi, 0x00
00007871bd3dc915  mov rax, 0x5BA2FDD2A530
00007871bd3dc91f  call rax
00007871bd3dc921  movaps xmm4, [rsp]
00007871bd3dc925  add rsp, 0x30
00007871bd3dc929  vmovaps xmm0, [rsp]
00007871bd3dc92e  vmovaps xmm1, [rsp+0x10]
00007871bd3dc934  vmovaps xmm2, [rsp+0x20]
00007871bd3dc93a  vmovaps xmm3, [rsp+0x30]
00007871bd3dc940  vmovaps xmm5, [rsp+0x40]
00007871bd3dc946  vmovaps xmm6, [rsp+0x50]
00007871bd3dc94c  vmovaps xmm7, [rsp+0x60]
00007871bd3dc952  vmovaps xmm8, [rsp+0x70]
00007871bd3dc958  vmovaps xmm9, [rsp+0x80]
00007871bd3dc961  vmovaps xmm10, [rsp+0x90]
00007871bd3dc96a  vmovaps xmm11, [rsp+0xA0]
00007871bd3dc973  vmovaps xmm12, [rsp+0xB0]
00007871bd3dc97c  vmovaps xmm13, [rsp+0xC0]
00007871bd3dc985  vmovaps xmm14, [rsp+0xD0]
00007871bd3dc98e  vmovaps xmm15, [rsp+0xE0]
00007871bd3dc997  add rsp, 0xF0
00007871bd3dc99e  pop r11
00007871bd3dc9a0  pop r10
00007871bd3dc9a2  pop r9
00007871bd3dc9a4  pop r8
00007871bd3dc9a6  pop rsi
00007871bd3dc9a7  pop rdi
00007871bd3dc9a8  pop rdx
00007871bd3dc9a9  pop rcx
00007871bd3dc9aa  pop rax
00007871bd3dc9ab  add rsp, 0x08
00007871bd3dc9af  jmp 0x00007871BD3D946A
00007871bd3dc9b4  sub rsp, 0x08
00007871bd3dc9b8  push rax
00007871bd3dc9b9  push rcx
00007871bd3dc9ba  push rdx
00007871bd3dc9bb  push rdi
00007871bd3dc9bc  push rsi
00007871bd3dc9bd  push r8
00007871bd3dc9bf  push r9
00007871bd3dc9c1  push r10
00007871bd3dc9c3  push r11
00007871bd3dc9c5  sub rsp, 0xF0
00007871bd3dc9cc  vmovaps [rsp], xmm0
00007871bd3dc9d1  vmovaps [rsp+0x10], xmm1
00007871bd3dc9d7  vmovaps [rsp+0x20], xmm2
00007871bd3dc9dd  vmovaps [rsp+0x30], xmm3
00007871bd3dc9e3  vmovaps [rsp+0x40], xmm4
00007871bd3dc9e9  vmovaps [rsp+0x50], xmm5
00007871bd3dc9ef  vmovaps [rsp+0x60], xmm6
00007871bd3dc9f5  vmovaps [rsp+0x70], xmm7
00007871bd3dc9fb  vmovaps [rsp+0x80], xmm8
00007871bd3dca04  vmovaps [rsp+0x90], xmm9
00007871bd3dca0d  vmovaps [rsp+0xA0], xmm10
00007871bd3dca16  vmovaps [rsp+0xB0], xmm11
00007871bd3dca1f  vmovaps [rsp+0xC0], xmm12
00007871bd3dca28  vmovaps [rsp+0xD0], xmm14
00007871bd3dca31  vmovaps [rsp+0xE0], xmm15
00007871bd3dca3a  sub rsp, 0x30
00007871bd3dca3e  movaps [rsp], xmm13
00007871bd3dca43  movaps [rsp+0x10], xmm15
00007871bd3dca49  movaps [rsp+0x20], xmm9
00007871bd3dca4f  lea rdi, [rsp]
00007871bd3dca53  mov esi, 0x00
00007871bd3dca58  mov rax, 0x5BA2FDD2A530
00007871bd3dca62  call rax
00007871bd3dca64  movaps xmm13, [rsp]
00007871bd3dca69  add rsp, 0x30
00007871bd3dca6d  vmovaps xmm0, [rsp]
00007871bd3dca72  vmovaps xmm1, [rsp+0x10]
00007871bd3dca78  vmovaps xmm2, [rsp+0x20]
00007871bd3dca7e  vmovaps xmm3, [rsp+0x30]
00007871bd3dca84  vmovaps xmm4, [rsp+0x40]
00007871bd3dca8a  vmovaps xmm5, [rsp+0x50]
00007871bd3dca90  vmovaps xmm6, [rsp+0x60]
00007871bd3dca96  vmovaps xmm7, [rsp+0x70]
00007871bd3dca9c  vmovaps xmm8, [rsp+0x80]
00007871bd3dcaa5  vmovaps xmm9, [rsp+0x90]
00007871bd3dcaae  vmovaps xmm10, [rsp+0xA0]
00007871bd3dcab7  vmovaps xmm11, [rsp+0xB0]
00007871bd3dcac0  vmovaps xmm12, [rsp+0xC0]
00007871bd3dcac9  vmovaps xmm14, [rsp+0xD0]
00007871bd3dcad2  vmovaps xmm15, [rsp+0xE0]
00007871bd3dcadb  add rsp, 0xF0
00007871bd3dcae2  pop r11
00007871bd3dcae4  pop r10
00007871bd3dcae6  pop r9
00007871bd3dcae8  pop r8
00007871bd3dcaea  pop rsi
00007871bd3dcaeb  pop rdi
00007871bd3dcaec  pop rdx
00007871bd3dcaed  pop rcx
00007871bd3dcaee  pop rax
00007871bd3dcaef  add rsp, 0x08
00007871bd3dcaf3  jmp 0x00007871BD3D9485
00007871bd3dcaf8  sub rsp, 0x08
00007871bd3dcafc  push rax
00007871bd3dcafd  push rcx
00007871bd3dcafe  push rdx
00007871bd3dcaff  push rdi
00007871bd3dcb00  push rsi
00007871bd3dcb01  push r8
00007871bd3dcb03  push r9
00007871bd3dcb05  push r10
00007871bd3dcb07  push r11
00007871bd3dcb09  sub rsp, 0xF0
00007871bd3dcb10  vmovaps [rsp], xmm0
00007871bd3dcb15  vmovaps [rsp+0x10], xmm1
00007871bd3dcb1b  vmovaps [rsp+0x20], xmm2
00007871bd3dcb21  vmovaps [rsp+0x30], xmm3
00007871bd3dcb27  vmovaps [rsp+0x40], xmm4
00007871bd3dcb2d  vmovaps [rsp+0x50], xmm5
00007871bd3dcb33  vmovaps [rsp+0x60], xmm6
00007871bd3dcb39  vmovaps [rsp+0x70], xmm7
00007871bd3dcb3f  vmovaps [rsp+0x80], xmm8
00007871bd3dcb48  vmovaps [rsp+0x90], xmm9
00007871bd3dcb51  vmovaps [rsp+0xA0], xmm10
00007871bd3dcb5a  vmovaps [rsp+0xB0], xmm11
00007871bd3dcb63  vmovaps [rsp+0xC0], xmm12
00007871bd3dcb6c  vmovaps [rsp+0xD0], xmm13
00007871bd3dcb75  vmovaps [rsp+0xE0], xmm14
00007871bd3dcb7e  sub rsp, 0x30
00007871bd3dcb82  movaps [rsp], xmm15
00007871bd3dcb87  movaps [rsp+0x10], xmm1
00007871bd3dcb8c  movaps [rsp+0x20], xmm5
00007871bd3dcb91  lea rdi, [rsp]
00007871bd3dcb95  mov esi, 0x00
00007871bd3dcb9a  mov rax, 0x5BA2FDD2A530
00007871bd3dcba4  call rax
00007871bd3dcba6  movaps xmm15, [rsp]
00007871bd3dcbab  add rsp, 0x30
00007871bd3dcbaf  vmovaps xmm0, [rsp]
00007871bd3dcbb4  vmovaps xmm1, [rsp+0x10]
00007871bd3dcbba  vmovaps xmm2, [rsp+0x20]
00007871bd3dcbc0  vmovaps xmm3, [rsp+0x30]
00007871bd3dcbc6  vmovaps xmm4, [rsp+0x40]
00007871bd3dcbcc  vmovaps xmm5, [rsp+0x50]
00007871bd3dcbd2  vmovaps xmm6, [rsp+0x60]
00007871bd3dcbd8  vmovaps xmm7, [rsp+0x70]
00007871bd3dcbde  vmovaps xmm8, [rsp+0x80]
00007871bd3dcbe7  vmovaps xmm9, [rsp+0x90]
00007871bd3dcbf0  vmovaps xmm10, [rsp+0xA0]
00007871bd3dcbf9  vmovaps xmm11, [rsp+0xB0]
00007871bd3dcc02  vmovaps xmm12, [rsp+0xC0]
00007871bd3dcc0b  vmovaps xmm13, [rsp+0xD0]
00007871bd3dcc14  vmovaps xmm14, [rsp+0xE0]
00007871bd3dcc1d  add rsp, 0xF0
00007871bd3dcc24  pop r11
00007871bd3dcc26  pop r10
00007871bd3dcc28  pop r9
00007871bd3dcc2a  pop r8
00007871bd3dcc2c  pop rsi
00007871bd3dcc2d  pop rdi
00007871bd3dcc2e  pop rdx
00007871bd3dcc2f  pop rcx
00007871bd3dcc30  pop rax
00007871bd3dcc31  add rsp, 0x08
00007871bd3dcc35  jmp 0x00007871BD3D94A0
00007871bd3dcc3a  call 0x00007871BD2D64F0
00007871bd3dcc3f  jmp 0x00007871BD3D94FB
00007871bd3dcc44  sub rsp, 0x08
00007871bd3dcc48  push rax
00007871bd3dcc49  push rcx
00007871bd3dcc4a  push rdx
00007871bd3dcc4b  push rdi
00007871bd3dcc4c  push rsi
00007871bd3dcc4d  push r8
00007871bd3dcc4f  push r9
00007871bd3dcc51  push r10
00007871bd3dcc53  push r11
00007871bd3dcc55  sub rsp, 0xF0
00007871bd3dcc5c  vmovaps [rsp], xmm0
00007871bd3dcc61  vmovaps [rsp+0x10], xmm1
00007871bd3dcc67  vmovaps [rsp+0x20], xmm2
00007871bd3dcc6d  vmovaps [rsp+0x30], xmm3
00007871bd3dcc73  vmovaps [rsp+0x40], xmm4
00007871bd3dcc79  vmovaps [rsp+0x50], xmm5
00007871bd3dcc7f  vmovaps [rsp+0x60], xmm6
00007871bd3dcc85  vmovaps [rsp+0x70], xmm7
00007871bd3dcc8b  vmovaps [rsp+0x80], xmm8
00007871bd3dcc94  vmovaps [rsp+0x90], xmm10
00007871bd3dcc9d  vmovaps [rsp+0xA0], xmm11
00007871bd3dcca6  vmovaps [rsp+0xB0], xmm12
00007871bd3dccaf  vmovaps [rsp+0xC0], xmm13
00007871bd3dccb8  vmovaps [rsp+0xD0], xmm14
00007871bd3dccc1  vmovaps [rsp+0xE0], xmm15
00007871bd3dccca  sub rsp, 0x30
00007871bd3dccce  movaps [rsp], xmm9
00007871bd3dccd3  movaps [rsp+0x10], xmm8
00007871bd3dccd9  movaps [rsp+0x20], xmm11
00007871bd3dccdf  lea rdi, [rsp]
00007871bd3dcce3  mov esi, 0x00
00007871bd3dcce8  mov rax, 0x5BA2FDD2A530
00007871bd3dccf2  call rax
00007871bd3dccf4  movaps xmm9, [rsp]
00007871bd3dccf9  add rsp, 0x30
00007871bd3dccfd  vmovaps xmm0, [rsp]
00007871bd3dcd02  vmovaps xmm1, [rsp+0x10]
00007871bd3dcd08  vmovaps xmm2, [rsp+0x20]
00007871bd3dcd0e  vmovaps xmm3, [rsp+0x30]
00007871bd3dcd14  vmovaps xmm4, [rsp+0x40]
00007871bd3dcd1a  vmovaps xmm5, [rsp+0x50]
00007871bd3dcd20  vmovaps xmm6, [rsp+0x60]
00007871bd3dcd26  vmovaps xmm7, [rsp+0x70]
00007871bd3dcd2c  vmovaps xmm8, [rsp+0x80]
00007871bd3dcd35  vmovaps xmm10, [rsp+0x90]
00007871bd3dcd3e  vmovaps xmm11, [rsp+0xA0]
00007871bd3dcd47  vmovaps xmm12, [rsp+0xB0]
00007871bd3dcd50  vmovaps xmm13, [rsp+0xC0]
00007871bd3dcd59  vmovaps xmm14, [rsp+0xD0]
00007871bd3dcd62  vmovaps xmm15, [rsp+0xE0]
00007871bd3dcd6b  add rsp, 0xF0
00007871bd3dcd72  pop r11
00007871bd3dcd74  pop r10
00007871bd3dcd76  pop r9
00007871bd3dcd78  pop r8
00007871bd3dcd7a  pop rsi
00007871bd3dcd7b  pop rdi
00007871bd3dcd7c  pop rdx
00007871bd3dcd7d  pop rcx
00007871bd3dcd7e  pop rax
00007871bd3dcd7f  add rsp, 0x08
00007871bd3dcd83  jmp 0x00007871BD3D9532
00007871bd3dcd88  sub rsp, 0x08
00007871bd3dcd8c  push rax
00007871bd3dcd8d  push rcx
00007871bd3dcd8e  push rdx
00007871bd3dcd8f  push rdi
00007871bd3dcd90  push rsi
00007871bd3dcd91  push r8
00007871bd3dcd93  push r9
00007871bd3dcd95  push r10
00007871bd3dcd97  push r11
00007871bd3dcd99  sub rsp, 0xF0
00007871bd3dcda0  vmovaps [rsp], xmm0
00007871bd3dcda5  vmovaps [rsp+0x10], xmm1
00007871bd3dcdab  vmovaps [rsp+0x20], xmm2
00007871bd3dcdb1  vmovaps [rsp+0x30], xmm3
00007871bd3dcdb7  vmovaps [rsp+0x40], xmm4
00007871bd3dcdbd  vmovaps [rsp+0x50], xmm5
00007871bd3dcdc3  vmovaps [rsp+0x60], xmm6
00007871bd3dcdc9  vmovaps [rsp+0x70], xmm7
00007871bd3dcdcf  vmovaps [rsp+0x80], xmm8
00007871bd3dcdd8  vmovaps [rsp+0x90], xmm9
00007871bd3dcde1  vmovaps [rsp+0xA0], xmm10
00007871bd3dcdea  vmovaps [rsp+0xB0], xmm12
00007871bd3dcdf3  vmovaps [rsp+0xC0], xmm13
00007871bd3dcdfc  vmovaps [rsp+0xD0], xmm14
00007871bd3dce05  vmovaps [rsp+0xE0], xmm15
00007871bd3dce0e  sub rsp, 0x30
00007871bd3dce12  movaps [rsp], xmm11
00007871bd3dce17  movaps [rsp+0x10], xmm10
00007871bd3dce1d  movaps [rsp+0x20], xmm6
00007871bd3dce22  lea rdi, [rsp]
00007871bd3dce26  mov esi, 0x00
00007871bd3dce2b  mov rax, 0x5BA2FDD2A530
00007871bd3dce35  call rax
00007871bd3dce37  movaps xmm11, [rsp]
00007871bd3dce3c  add rsp, 0x30
00007871bd3dce40  vmovaps xmm0, [rsp]
00007871bd3dce45  vmovaps xmm1, [rsp+0x10]
00007871bd3dce4b  vmovaps xmm2, [rsp+0x20]
00007871bd3dce51  vmovaps xmm3, [rsp+0x30]
00007871bd3dce57  vmovaps xmm4, [rsp+0x40]
00007871bd3dce5d  vmovaps xmm5, [rsp+0x50]
00007871bd3dce63  vmovaps xmm6, [rsp+0x60]
00007871bd3dce69  vmovaps xmm7, [rsp+0x70]
00007871bd3dce6f  vmovaps xmm8, [rsp+0x80]
00007871bd3dce78  vmovaps xmm9, [rsp+0x90]
00007871bd3dce81  vmovaps xmm10, [rsp+0xA0]
00007871bd3dce8a  vmovaps xmm12, [rsp+0xB0]
00007871bd3dce93  vmovaps xmm13, [rsp+0xC0]
00007871bd3dce9c  vmovaps xmm14, [rsp+0xD0]
00007871bd3dcea5  vmovaps xmm15, [rsp+0xE0]
00007871bd3dceae  add rsp, 0xF0
00007871bd3dceb5  pop r11
00007871bd3dceb7  pop r10
00007871bd3dceb9  pop r9
00007871bd3dcebb  pop r8
00007871bd3dcebd  pop rsi
00007871bd3dcebe  pop rdi
00007871bd3dcebf  pop rdx
00007871bd3dcec0  pop rcx
00007871bd3dcec1  pop rax
00007871bd3dcec2  add rsp, 0x08
00007871bd3dcec6  jmp 0x00007871BD3D954D
00007871bd3dcecb  sub rsp, 0x08
00007871bd3dcecf  push rax
00007871bd3dced0  push rcx
00007871bd3dced1  push rdx
00007871bd3dced2  push rdi
00007871bd3dced3  push rsi
00007871bd3dced4  push r8
00007871bd3dced6  push r9
00007871bd3dced8  push r10
00007871bd3dceda  push r11
00007871bd3dcedc  sub rsp, 0xF0
00007871bd3dcee3  vmovaps [rsp], xmm0
00007871bd3dcee8  vmovaps [rsp+0x10], xmm1
00007871bd3dceee  vmovaps [rsp+0x20], xmm2
00007871bd3dcef4  vmovaps [rsp+0x30], xmm3
00007871bd3dcefa  vmovaps [rsp+0x40], xmm4
00007871bd3dcf00  vmovaps [rsp+0x50], xmm5
00007871bd3dcf06  vmovaps [rsp+0x60], xmm6
00007871bd3dcf0c  vmovaps [rsp+0x70], xmm7
00007871bd3dcf12  vmovaps [rsp+0x80], xmm8
00007871bd3dcf1b  vmovaps [rsp+0x90], xmm9
00007871bd3dcf24  vmovaps [rsp+0xA0], xmm11
00007871bd3dcf2d  vmovaps [rsp+0xB0], xmm12
00007871bd3dcf36  vmovaps [rsp+0xC0], xmm13
00007871bd3dcf3f  vmovaps [rsp+0xD0], xmm14
00007871bd3dcf48  vmovaps [rsp+0xE0], xmm15
00007871bd3dcf51  sub rsp, 0x30
00007871bd3dcf55  movaps [rsp], xmm10
00007871bd3dcf5a  movaps [rsp+0x10], xmm14
00007871bd3dcf60  movaps [rsp+0x20], xmm4
00007871bd3dcf65  lea rdi, [rsp]
00007871bd3dcf69  mov esi, 0x00
00007871bd3dcf6e  mov rax, 0x5BA2FDD2A530
00007871bd3dcf78  call rax
00007871bd3dcf7a  movaps xmm10, [rsp]
00007871bd3dcf7f  add rsp, 0x30
00007871bd3dcf83  vmovaps xmm0, [rsp]
00007871bd3dcf88  vmovaps xmm1, [rsp+0x10]
00007871bd3dcf8e  vmovaps xmm2, [rsp+0x20]
00007871bd3dcf94  vmovaps xmm3, [rsp+0x30]
00007871bd3dcf9a  vmovaps xmm4, [rsp+0x40]
00007871bd3dcfa0  vmovaps xmm5, [rsp+0x50]
00007871bd3dcfa6  vmovaps xmm6, [rsp+0x60]
00007871bd3dcfac  vmovaps xmm7, [rsp+0x70]
00007871bd3dcfb2  vmovaps xmm8, [rsp+0x80]
00007871bd3dcfbb  vmovaps xmm9, [rsp+0x90]
00007871bd3dcfc4  vmovaps xmm11, [rsp+0xA0]
00007871bd3dcfcd  vmovaps xmm12, [rsp+0xB0]
00007871bd3dcfd6  vmovaps xmm13, [rsp+0xC0]
00007871bd3dcfdf  vmovaps xmm14, [rsp+0xD0]
00007871bd3dcfe8  vmovaps xmm15, [rsp+0xE0]
00007871bd3dcff1  add rsp, 0xF0
00007871bd3dcff8  pop r11
00007871bd3dcffa  pop r10
00007871bd3dcffc  pop r9
00007871bd3dcffe  pop r8
00007871bd3dd000  pop rsi
00007871bd3dd001  pop rdi
00007871bd3dd002  pop rdx
00007871bd3dd003  pop rcx
00007871bd3dd004  pop rax
00007871bd3dd005  add rsp, 0x08
00007871bd3dd009  jmp 0x00007871BD3D9568
00007871bd3dd00e  sub rsp, 0x08
00007871bd3dd012  push rax
00007871bd3dd013  push rcx
00007871bd3dd014  push rdx
00007871bd3dd015  push rdi
00007871bd3dd016  push rsi
00007871bd3dd017  push r8
00007871bd3dd019  push r9
00007871bd3dd01b  push r10
00007871bd3dd01d  push r11
00007871bd3dd01f  sub rsp, 0xF0
00007871bd3dd026  vmovaps [rsp], xmm0
00007871bd3dd02b  vmovaps [rsp+0x10], xmm1
00007871bd3dd031  vmovaps [rsp+0x20], xmm2
00007871bd3dd037  vmovaps [rsp+0x30], xmm3
00007871bd3dd03d  vmovaps [rsp+0x40], xmm4
00007871bd3dd043  vmovaps [rsp+0x50], xmm5
00007871bd3dd049  vmovaps [rsp+0x60], xmm6
00007871bd3dd04f  vmovaps [rsp+0x70], xmm7
00007871bd3dd055  vmovaps [rsp+0x80], xmm9
00007871bd3dd05e  vmovaps [rsp+0x90], xmm10
00007871bd3dd067  vmovaps [rsp+0xA0], xmm11
00007871bd3dd070  vmovaps [rsp+0xB0], xmm12
00007871bd3dd079  vmovaps [rsp+0xC0], xmm13
00007871bd3dd082  vmovaps [rsp+0xD0], xmm14
00007871bd3dd08b  vmovaps [rsp+0xE0], xmm15
00007871bd3dd094  sub rsp, 0x30
00007871bd3dd098  movaps [rsp], xmm8
00007871bd3dd09d  movaps [rsp+0x10], xmm1
00007871bd3dd0a2  movaps [rsp+0x20], xmm14
00007871bd3dd0a8  lea rdi, [rsp]
00007871bd3dd0ac  mov esi, 0x00
00007871bd3dd0b1  mov rax, 0x5BA2FDD2A530
00007871bd3dd0bb  call rax
00007871bd3dd0bd  movaps xmm8, [rsp]
00007871bd3dd0c2  add rsp, 0x30
00007871bd3dd0c6  vmovaps xmm0, [rsp]
00007871bd3dd0cb  vmovaps xmm1, [rsp+0x10]
00007871bd3dd0d1  vmovaps xmm2, [rsp+0x20]
00007871bd3dd0d7  vmovaps xmm3, [rsp+0x30]
00007871bd3dd0dd  vmovaps xmm4, [rsp+0x40]
00007871bd3dd0e3  vmovaps xmm5, [rsp+0x50]
00007871bd3dd0e9  vmovaps xmm6, [rsp+0x60]
00007871bd3dd0ef  vmovaps xmm7, [rsp+0x70]
00007871bd3dd0f5  vmovaps xmm9, [rsp+0x80]
00007871bd3dd0fe  vmovaps xmm10, [rsp+0x90]
00007871bd3dd107  vmovaps xmm11, [rsp+0xA0]
00007871bd3dd110  vmovaps xmm12, [rsp+0xB0]
00007871bd3dd119  vmovaps xmm13, [rsp+0xC0]
00007871bd3dd122  vmovaps xmm14, [rsp+0xD0]
00007871bd3dd12b  vmovaps xmm15, [rsp+0xE0]
00007871bd3dd134  add rsp, 0xF0
00007871bd3dd13b  pop r11
00007871bd3dd13d  pop r10
00007871bd3dd13f  pop r9
00007871bd3dd141  pop r8
00007871bd3dd143  pop rsi
00007871bd3dd144  pop rdi
00007871bd3dd145  pop rdx
00007871bd3dd146  pop rcx
00007871bd3dd147  pop rax
00007871bd3dd148  add rsp, 0x08
00007871bd3dd14c  jmp 0x00007871BD3D958E
00007871bd3dd151  sub rsp, 0x08
00007871bd3dd155  push rax
00007871bd3dd156  push rcx
00007871bd3dd157  push rdx
00007871bd3dd158  push rdi
00007871bd3dd159  push rsi
00007871bd3dd15a  push r8
00007871bd3dd15c  push r9
00007871bd3dd15e  push r10
00007871bd3dd160  push r11
00007871bd3dd162  sub rsp, 0xF0
00007871bd3dd169  vmovaps [rsp], xmm0
00007871bd3dd16e  vmovaps [rsp+0x10], xmm1
00007871bd3dd174  vmovaps [rsp+0x20], xmm2
00007871bd3dd17a  vmovaps [rsp+0x30], xmm3
00007871bd3dd180  vmovaps [rsp+0x40], xmm4
00007871bd3dd186  vmovaps [rsp+0x50], xmm5
00007871bd3dd18c  vmovaps [rsp+0x60], xmm7
00007871bd3dd192  vmovaps [rsp+0x70], xmm8
00007871bd3dd198  vmovaps [rsp+0x80], xmm9
00007871bd3dd1a1  vmovaps [rsp+0x90], xmm10
00007871bd3dd1aa  vmovaps [rsp+0xA0], xmm11
00007871bd3dd1b3  vmovaps [rsp+0xB0], xmm12
00007871bd3dd1bc  vmovaps [rsp+0xC0], xmm13
00007871bd3dd1c5  vmovaps [rsp+0xD0], xmm14
00007871bd3dd1ce  vmovaps [rsp+0xE0], xmm15
00007871bd3dd1d7  sub rsp, 0x30
00007871bd3dd1db  movaps [rsp], xmm6
00007871bd3dd1df  movaps [rsp+0x10], xmm1
00007871bd3dd1e4  movaps [rsp+0x20], xmm14
00007871bd3dd1ea  lea rdi, [rsp]
00007871bd3dd1ee  mov esi, 0x00
00007871bd3dd1f3  mov rax, 0x5BA2FDD2A530
00007871bd3dd1fd  call rax
00007871bd3dd1ff  movaps xmm6, [rsp]
00007871bd3dd203  add rsp, 0x30
00007871bd3dd207  vmovaps xmm0, [rsp]
00007871bd3dd20c  vmovaps xmm1, [rsp+0x10]
00007871bd3dd212  vmovaps xmm2, [rsp+0x20]
00007871bd3dd218  vmovaps xmm3, [rsp+0x30]
00007871bd3dd21e  vmovaps xmm4, [rsp+0x40]
00007871bd3dd224  vmovaps xmm5, [rsp+0x50]
00007871bd3dd22a  vmovaps xmm7, [rsp+0x60]
00007871bd3dd230  vmovaps xmm8, [rsp+0x70]
00007871bd3dd236  vmovaps xmm9, [rsp+0x80]
00007871bd3dd23f  vmovaps xmm10, [rsp+0x90]
00007871bd3dd248  vmovaps xmm11, [rsp+0xA0]
00007871bd3dd251  vmovaps xmm12, [rsp+0xB0]
00007871bd3dd25a  vmovaps xmm13, [rsp+0xC0]
00007871bd3dd263  vmovaps xmm14, [rsp+0xD0]
00007871bd3dd26c  vmovaps xmm15, [rsp+0xE0]
00007871bd3dd275  add rsp, 0xF0
00007871bd3dd27c  pop r11
00007871bd3dd27e  pop r10
00007871bd3dd280  pop r9
00007871bd3dd282  pop r8
00007871bd3dd284  pop rsi
00007871bd3dd285  pop rdi
00007871bd3dd286  pop rdx
00007871bd3dd287  pop rcx
00007871bd3dd288  pop rax
00007871bd3dd289  add rsp, 0x08
00007871bd3dd28d  jmp 0x00007871BD3D95BA
00007871bd3dd292  sub rsp, 0x08
00007871bd3dd296  push rax
00007871bd3dd297  push rcx
00007871bd3dd298  push rdx
00007871bd3dd299  push rdi
00007871bd3dd29a  push rsi
00007871bd3dd29b  push r8
00007871bd3dd29d  push r9
00007871bd3dd29f  push r10
00007871bd3dd2a1  push r11
00007871bd3dd2a3  sub rsp, 0xF0
00007871bd3dd2aa  vmovaps [rsp], xmm0
00007871bd3dd2af  vmovaps [rsp+0x10], xmm1
00007871bd3dd2b5  vmovaps [rsp+0x20], xmm2
00007871bd3dd2bb  vmovaps [rsp+0x30], xmm3
00007871bd3dd2c1  vmovaps [rsp+0x40], xmm4
00007871bd3dd2c7  vmovaps [rsp+0x50], xmm5
00007871bd3dd2cd  vmovaps [rsp+0x60], xmm6
00007871bd3dd2d3  vmovaps [rsp+0x70], xmm7
00007871bd3dd2d9  vmovaps [rsp+0x80], xmm8
00007871bd3dd2e2  vmovaps [rsp+0x90], xmm9
00007871bd3dd2eb  vmovaps [rsp+0xA0], xmm10
00007871bd3dd2f4  vmovaps [rsp+0xB0], xmm11
00007871bd3dd2fd  vmovaps [rsp+0xC0], xmm12
00007871bd3dd306  vmovaps [rsp+0xD0], xmm13
00007871bd3dd30f  vmovaps [rsp+0xE0], xmm15
00007871bd3dd318  sub rsp, 0x30
00007871bd3dd31c  movaps [rsp], xmm14
00007871bd3dd321  movaps [rsp+0x10], xmm12
00007871bd3dd327  movaps [rsp+0x20], xmm1
00007871bd3dd32c  lea rdi, [rsp]
00007871bd3dd330  mov esi, 0x00
00007871bd3dd335  mov rax, 0x5BA2FDD2A530
00007871bd3dd33f  call rax
00007871bd3dd341  movaps xmm14, [rsp]
00007871bd3dd346  add rsp, 0x30
00007871bd3dd34a  vmovaps xmm0, [rsp]
00007871bd3dd34f  vmovaps xmm1, [rsp+0x10]
00007871bd3dd355  vmovaps xmm2, [rsp+0x20]
00007871bd3dd35b  vmovaps xmm3, [rsp+0x30]
00007871bd3dd361  vmovaps xmm4, [rsp+0x40]
00007871bd3dd367  vmovaps xmm5, [rsp+0x50]
00007871bd3dd36d  vmovaps xmm6, [rsp+0x60]
00007871bd3dd373  vmovaps xmm7, [rsp+0x70]
00007871bd3dd379  vmovaps xmm8, [rsp+0x80]
00007871bd3dd382  vmovaps xmm9, [rsp+0x90]
00007871bd3dd38b  vmovaps xmm10, [rsp+0xA0]
00007871bd3dd394  vmovaps xmm11, [rsp+0xB0]
00007871bd3dd39d  vmovaps xmm12, [rsp+0xC0]
00007871bd3dd3a6  vmovaps xmm13, [rsp+0xD0]
00007871bd3dd3af  vmovaps xmm15, [rsp+0xE0]
00007871bd3dd3b8  add rsp, 0xF0
00007871bd3dd3bf  pop r11
00007871bd3dd3c1  pop r10
00007871bd3dd3c3  pop r9
00007871bd3dd3c5  pop r8
00007871bd3dd3c7  pop rsi
00007871bd3dd3c8  pop rdi
00007871bd3dd3c9  pop rdx
00007871bd3dd3ca  pop rcx
00007871bd3dd3cb  pop rax
00007871bd3dd3cc  add rsp, 0x08
00007871bd3dd3d0  jmp 0x00007871BD3D95E0
00007871bd3dd3d5  sub rsp, 0x08
00007871bd3dd3d9  push rax
00007871bd3dd3da  push rcx
00007871bd3dd3db  push rdx
00007871bd3dd3dc  push rdi
00007871bd3dd3dd  push rsi
00007871bd3dd3de  push r8
00007871bd3dd3e0  push r9
00007871bd3dd3e2  push r10
00007871bd3dd3e4  push r11
00007871bd3dd3e6  sub rsp, 0xF0
00007871bd3dd3ed  vmovaps [rsp], xmm0
00007871bd3dd3f2  vmovaps [rsp+0x10], xmm2
00007871bd3dd3f8  vmovaps [rsp+0x20], xmm3
00007871bd3dd3fe  vmovaps [rsp+0x30], xmm4
00007871bd3dd404  vmovaps [rsp+0x40], xmm5
00007871bd3dd40a  vmovaps [rsp+0x50], xmm6
00007871bd3dd410  vmovaps [rsp+0x60], xmm7
00007871bd3dd416  vmovaps [rsp+0x70], xmm8
00007871bd3dd41c  vmovaps [rsp+0x80], xmm9
00007871bd3dd425  vmovaps [rsp+0x90], xmm10
00007871bd3dd42e  vmovaps [rsp+0xA0], xmm11
00007871bd3dd437  vmovaps [rsp+0xB0], xmm12
00007871bd3dd440  vmovaps [rsp+0xC0], xmm13
00007871bd3dd449  vmovaps [rsp+0xD0], xmm14
00007871bd3dd452  vmovaps [rsp+0xE0], xmm15
00007871bd3dd45b  sub rsp, 0x30
00007871bd3dd45f  movaps [rsp], xmm1
00007871bd3dd463  movaps [rsp+0x10], xmm13
00007871bd3dd469  movaps [rsp+0x20], xmm9
00007871bd3dd46f  lea rdi, [rsp]
00007871bd3dd473  mov esi, 0x00
00007871bd3dd478  mov rax, 0x5BA2FDD2A530
00007871bd3dd482  call rax
00007871bd3dd484  movaps xmm1, [rsp]
00007871bd3dd488  add rsp, 0x30
00007871bd3dd48c  vmovaps xmm0, [rsp]
00007871bd3dd491  vmovaps xmm2, [rsp+0x10]
00007871bd3dd497  vmovaps xmm3, [rsp+0x20]
00007871bd3dd49d  vmovaps xmm4, [rsp+0x30]
00007871bd3dd4a3  vmovaps xmm5, [rsp+0x40]
00007871bd3dd4a9  vmovaps xmm6, [rsp+0x50]
00007871bd3dd4af  vmovaps xmm7, [rsp+0x60]
00007871bd3dd4b5  vmovaps xmm8, [rsp+0x70]
00007871bd3dd4bb  vmovaps xmm9, [rsp+0x80]
00007871bd3dd4c4  vmovaps xmm10, [rsp+0x90]
00007871bd3dd4cd  vmovaps xmm11, [rsp+0xA0]
00007871bd3dd4d6  vmovaps xmm12, [rsp+0xB0]
00007871bd3dd4df  vmovaps xmm13, [rsp+0xC0]
00007871bd3dd4e8  vmovaps xmm14, [rsp+0xD0]
00007871bd3dd4f1  vmovaps xmm15, [rsp+0xE0]
00007871bd3dd4fa  add rsp, 0xF0
00007871bd3dd501  pop r11
00007871bd3dd503  pop r10
00007871bd3dd505  pop r9
00007871bd3dd507  pop r8
00007871bd3dd509  pop rsi
00007871bd3dd50a  pop rdi
00007871bd3dd50b  pop rdx
00007871bd3dd50c  pop rcx
00007871bd3dd50d  pop rax
00007871bd3dd50e  add rsp, 0x08
00007871bd3dd512  jmp 0x00007871BD3D95FA
00007871bd3dd517  sub rsp, 0x08
00007871bd3dd51b  push rax
00007871bd3dd51c  push rcx
00007871bd3dd51d  push rdx
00007871bd3dd51e  push rdi
00007871bd3dd51f  push rsi
00007871bd3dd520  push r8
00007871bd3dd522  push r9
00007871bd3dd524  push r10
00007871bd3dd526  push r11
00007871bd3dd528  sub rsp, 0xF0
00007871bd3dd52f  vmovaps [rsp], xmm0
00007871bd3dd534  vmovaps [rsp+0x10], xmm1
00007871bd3dd53a  vmovaps [rsp+0x20], xmm2
00007871bd3dd540  vmovaps [rsp+0x30], xmm3
00007871bd3dd546  vmovaps [rsp+0x40], xmm4
00007871bd3dd54c  vmovaps [rsp+0x50], xmm5
00007871bd3dd552  vmovaps [rsp+0x60], xmm6
00007871bd3dd558  vmovaps [rsp+0x70], xmm7
00007871bd3dd55e  vmovaps [rsp+0x80], xmm8
00007871bd3dd567  vmovaps [rsp+0x90], xmm9
00007871bd3dd570  vmovaps [rsp+0xA0], xmm10
00007871bd3dd579  vmovaps [rsp+0xB0], xmm11
00007871bd3dd582  vmovaps [rsp+0xC0], xmm13
00007871bd3dd58b  vmovaps [rsp+0xD0], xmm14
00007871bd3dd594  vmovaps [rsp+0xE0], xmm15
00007871bd3dd59d  sub rsp, 0x30
00007871bd3dd5a1  movaps [rsp], xmm12
00007871bd3dd5a6  movaps [rsp+0x10], xmm7
00007871bd3dd5ab  movaps [rsp+0x20], xmm13
00007871bd3dd5b1  lea rdi, [rsp]
00007871bd3dd5b5  mov esi, 0x00
00007871bd3dd5ba  mov rax, 0x5BA2FDD2A530
00007871bd3dd5c4  call rax
00007871bd3dd5c6  movaps xmm12, [rsp]
00007871bd3dd5cb  add rsp, 0x30
00007871bd3dd5cf  vmovaps xmm0, [rsp]
00007871bd3dd5d4  vmovaps xmm1, [rsp+0x10]
00007871bd3dd5da  vmovaps xmm2, [rsp+0x20]
00007871bd3dd5e0  vmovaps xmm3, [rsp+0x30]
00007871bd3dd5e6  vmovaps xmm4, [rsp+0x40]
00007871bd3dd5ec  vmovaps xmm5, [rsp+0x50]
00007871bd3dd5f2  vmovaps xmm6, [rsp+0x60]
00007871bd3dd5f8  vmovaps xmm7, [rsp+0x70]
00007871bd3dd5fe  vmovaps xmm8, [rsp+0x80]
00007871bd3dd607  vmovaps xmm9, [rsp+0x90]
00007871bd3dd610  vmovaps xmm10, [rsp+0xA0]
00007871bd3dd619  vmovaps xmm11, [rsp+0xB0]
00007871bd3dd622  vmovaps xmm13, [rsp+0xC0]
00007871bd3dd62b  vmovaps xmm14, [rsp+0xD0]
00007871bd3dd634  vmovaps xmm15, [rsp+0xE0]
00007871bd3dd63d  add rsp, 0xF0
00007871bd3dd644  pop r11
00007871bd3dd646  pop r10
00007871bd3dd648  pop r9
00007871bd3dd64a  pop r8
00007871bd3dd64c  pop rsi
00007871bd3dd64d  pop rdi
00007871bd3dd64e  pop rdx
00007871bd3dd64f  pop rcx
00007871bd3dd650  pop rax
00007871bd3dd651  add rsp, 0x08
00007871bd3dd655  jmp 0x00007871BD3D9621
00007871bd3dd65a  sub rsp, 0x08
00007871bd3dd65e  push rax
00007871bd3dd65f  push rcx
00007871bd3dd660  push rdx
00007871bd3dd661  push rdi
00007871bd3dd662  push rsi
00007871bd3dd663  push r8
00007871bd3dd665  push r9
00007871bd3dd667  push r10
00007871bd3dd669  push r11
00007871bd3dd66b  sub rsp, 0xF0
00007871bd3dd672  vmovaps [rsp], xmm0
00007871bd3dd677  vmovaps [rsp+0x10], xmm1
00007871bd3dd67d  vmovaps [rsp+0x20], xmm2
00007871bd3dd683  vmovaps [rsp+0x30], xmm3
00007871bd3dd689  vmovaps [rsp+0x40], xmm4
00007871bd3dd68f  vmovaps [rsp+0x50], xmm5
00007871bd3dd695  vmovaps [rsp+0x60], xmm6
00007871bd3dd69b  vmovaps [rsp+0x70], xmm7
00007871bd3dd6a1  vmovaps [rsp+0x80], xmm8
00007871bd3dd6aa  vmovaps [rsp+0x90], xmm9
00007871bd3dd6b3  vmovaps [rsp+0xA0], xmm10
00007871bd3dd6bc  vmovaps [rsp+0xB0], xmm11
00007871bd3dd6c5  vmovaps [rsp+0xC0], xmm12
00007871bd3dd6ce  vmovaps [rsp+0xD0], xmm14
00007871bd3dd6d7  vmovaps [rsp+0xE0], xmm15
00007871bd3dd6e0  sub rsp, 0x30
00007871bd3dd6e4  movaps [rsp], xmm13
00007871bd3dd6e9  movaps [rsp+0x10], xmm15
00007871bd3dd6ef  movaps [rsp+0x20], xmm8
00007871bd3dd6f5  lea rdi, [rsp]
00007871bd3dd6f9  mov esi, 0x00
00007871bd3dd6fe  mov rax, 0x5BA2FDD2A530
00007871bd3dd708  call rax
00007871bd3dd70a  movaps xmm13, [rsp]
00007871bd3dd70f  add rsp, 0x30
00007871bd3dd713  vmovaps xmm0, [rsp]
00007871bd3dd718  vmovaps xmm1, [rsp+0x10]
00007871bd3dd71e  vmovaps xmm2, [rsp+0x20]
00007871bd3dd724  vmovaps xmm3, [rsp+0x30]
00007871bd3dd72a  vmovaps xmm4, [rsp+0x40]
00007871bd3dd730  vmovaps xmm5, [rsp+0x50]
00007871bd3dd736  vmovaps xmm6, [rsp+0x60]
00007871bd3dd73c  vmovaps xmm7, [rsp+0x70]
00007871bd3dd742  vmovaps xmm8, [rsp+0x80]
00007871bd3dd74b  vmovaps xmm9, [rsp+0x90]
00007871bd3dd754  vmovaps xmm10, [rsp+0xA0]
00007871bd3dd75d  vmovaps xmm11, [rsp+0xB0]
00007871bd3dd766  vmovaps xmm12, [rsp+0xC0]
00007871bd3dd76f  vmovaps xmm14, [rsp+0xD0]
00007871bd3dd778  vmovaps xmm15, [rsp+0xE0]
00007871bd3dd781  add rsp, 0xF0
00007871bd3dd788  pop r11
00007871bd3dd78a  pop r10
00007871bd3dd78c  pop r9
00007871bd3dd78e  pop r8
00007871bd3dd790  pop rsi
00007871bd3dd791  pop rdi
00007871bd3dd792  pop rdx
00007871bd3dd793  pop rcx
00007871bd3dd794  pop rax
00007871bd3dd795  add rsp, 0x08
00007871bd3dd799  jmp 0x00007871BD3D963C
00007871bd3dd79e  sub rsp, 0x08
00007871bd3dd7a2  push rax
00007871bd3dd7a3  push rcx
00007871bd3dd7a4  push rdx
00007871bd3dd7a5  push rdi
00007871bd3dd7a6  push rsi
00007871bd3dd7a7  push r8
00007871bd3dd7a9  push r9
00007871bd3dd7ab  push r10
00007871bd3dd7ad  push r11
00007871bd3dd7af  sub rsp, 0xF0
00007871bd3dd7b6  vmovaps [rsp], xmm0
00007871bd3dd7bb  vmovaps [rsp+0x10], xmm1
00007871bd3dd7c1  vmovaps [rsp+0x20], xmm2
00007871bd3dd7c7  vmovaps [rsp+0x30], xmm3
00007871bd3dd7cd  vmovaps [rsp+0x40], xmm4
00007871bd3dd7d3  vmovaps [rsp+0x50], xmm5
00007871bd3dd7d9  vmovaps [rsp+0x60], xmm6
00007871bd3dd7df  vmovaps [rsp+0x70], xmm7
00007871bd3dd7e5  vmovaps [rsp+0x80], xmm9
00007871bd3dd7ee  vmovaps [rsp+0x90], xmm10
00007871bd3dd7f7  vmovaps [rsp+0xA0], xmm11
00007871bd3dd800  vmovaps [rsp+0xB0], xmm12
00007871bd3dd809  vmovaps [rsp+0xC0], xmm13
00007871bd3dd812  vmovaps [rsp+0xD0], xmm14
00007871bd3dd81b  vmovaps [rsp+0xE0], xmm15
00007871bd3dd824  sub rsp, 0x30
00007871bd3dd828  movaps [rsp], xmm8
00007871bd3dd82d  movaps [rsp+0x10], xmm15
00007871bd3dd833  movaps [rsp+0x20], xmm9
00007871bd3dd839  lea rdi, [rsp]
00007871bd3dd83d  mov esi, 0x00
00007871bd3dd842  mov rax, 0x5BA2FDD2A530
00007871bd3dd84c  call rax
00007871bd3dd84e  movaps xmm8, [rsp]
00007871bd3dd853  add rsp, 0x30
00007871bd3dd857  vmovaps xmm0, [rsp]
00007871bd3dd85c  vmovaps xmm1, [rsp+0x10]
00007871bd3dd862  vmovaps xmm2, [rsp+0x20]
00007871bd3dd868  vmovaps xmm3, [rsp+0x30]
00007871bd3dd86e  vmovaps xmm4, [rsp+0x40]
00007871bd3dd874  vmovaps xmm5, [rsp+0x50]
00007871bd3dd87a  vmovaps xmm6, [rsp+0x60]
00007871bd3dd880  vmovaps xmm7, [rsp+0x70]
00007871bd3dd886  vmovaps xmm9, [rsp+0x80]
00007871bd3dd88f  vmovaps xmm10, [rsp+0x90]
00007871bd3dd898  vmovaps xmm11, [rsp+0xA0]
00007871bd3dd8a1  vmovaps xmm12, [rsp+0xB0]
00007871bd3dd8aa  vmovaps xmm13, [rsp+0xC0]
00007871bd3dd8b3  vmovaps xmm14, [rsp+0xD0]
00007871bd3dd8bc  vmovaps xmm15, [rsp+0xE0]
00007871bd3dd8c5  add rsp, 0xF0
00007871bd3dd8cc  pop r11
00007871bd3dd8ce  pop r10
00007871bd3dd8d0  pop r9
00007871bd3dd8d2  pop r8
00007871bd3dd8d4  pop rsi
00007871bd3dd8d5  pop rdi
00007871bd3dd8d6  pop rdx
00007871bd3dd8d7  pop rcx
00007871bd3dd8d8  pop rax
00007871bd3dd8d9  add rsp, 0x08
00007871bd3dd8dd  jmp 0x00007871BD3D966A
00007871bd3dd8e2  sub rsp, 0x08
00007871bd3dd8e6  push rax
00007871bd3dd8e7  push rcx
00007871bd3dd8e8  push rdx
00007871bd3dd8e9  push rdi
00007871bd3dd8ea  push rsi
00007871bd3dd8eb  push r8
00007871bd3dd8ed  push r9
00007871bd3dd8ef  push r10
00007871bd3dd8f1  push r11
00007871bd3dd8f3  sub rsp, 0xF0
00007871bd3dd8fa  vmovaps [rsp], xmm0
00007871bd3dd8ff  vmovaps [rsp+0x10], xmm1
00007871bd3dd905  vmovaps [rsp+0x20], xmm2
00007871bd3dd90b  vmovaps [rsp+0x30], xmm3
00007871bd3dd911  vmovaps [rsp+0x40], xmm4
00007871bd3dd917  vmovaps [rsp+0x50], xmm5
00007871bd3dd91d  vmovaps [rsp+0x60], xmm6
00007871bd3dd923  vmovaps [rsp+0x70], xmm7
00007871bd3dd929  vmovaps [rsp+0x80], xmm8
00007871bd3dd932  vmovaps [rsp+0x90], xmm9
00007871bd3dd93b  vmovaps [rsp+0xA0], xmm10
00007871bd3dd944  vmovaps [rsp+0xB0], xmm11
00007871bd3dd94d  vmovaps [rsp+0xC0], xmm12
00007871bd3dd956  vmovaps [rsp+0xD0], xmm13
00007871bd3dd95f  vmovaps [rsp+0xE0], xmm14
00007871bd3dd968  sub rsp, 0x30
00007871bd3dd96c  movaps [rsp], xmm15
00007871bd3dd971  movaps [rsp+0x10], xmm11
00007871bd3dd977  movaps [rsp+0x20], xmm6
00007871bd3dd97c  lea rdi, [rsp]
00007871bd3dd980  mov esi, 0x00
00007871bd3dd985  mov rax, 0x5BA2FDD2A530
00007871bd3dd98f  call rax
00007871bd3dd991  movaps xmm15, [rsp]
00007871bd3dd996  add rsp, 0x30
00007871bd3dd99a  vmovaps xmm0, [rsp]
00007871bd3dd99f  vmovaps xmm1, [rsp+0x10]
00007871bd3dd9a5  vmovaps xmm2, [rsp+0x20]
00007871bd3dd9ab  vmovaps xmm3, [rsp+0x30]
00007871bd3dd9b1  vmovaps xmm4, [rsp+0x40]
00007871bd3dd9b7  vmovaps xmm5, [rsp+0x50]
00007871bd3dd9bd  vmovaps xmm6, [rsp+0x60]
00007871bd3dd9c3  vmovaps xmm7, [rsp+0x70]
00007871bd3dd9c9  vmovaps xmm8, [rsp+0x80]
00007871bd3dd9d2  vmovaps xmm9, [rsp+0x90]
00007871bd3dd9db  vmovaps xmm10, [rsp+0xA0]
00007871bd3dd9e4  vmovaps xmm11, [rsp+0xB0]
00007871bd3dd9ed  vmovaps xmm12, [rsp+0xC0]
00007871bd3dd9f6  vmovaps xmm13, [rsp+0xD0]
00007871bd3dd9ff  vmovaps xmm14, [rsp+0xE0]
00007871bd3dda08  add rsp, 0xF0
00007871bd3dda0f  pop r11
00007871bd3dda11  pop r10
00007871bd3dda13  pop r9
00007871bd3dda15  pop r8
00007871bd3dda17  pop rsi
00007871bd3dda18  pop rdi
00007871bd3dda19  pop rdx
00007871bd3dda1a  pop rcx
00007871bd3dda1b  pop rax
00007871bd3dda1c  add rsp, 0x08
00007871bd3dda20  jmp 0x00007871BD3D9685
00007871bd3dda25  sub rsp, 0x08
00007871bd3dda29  push rax
00007871bd3dda2a  push rcx
00007871bd3dda2b  push rdx
00007871bd3dda2c  push rdi
00007871bd3dda2d  push rsi
00007871bd3dda2e  push r8
00007871bd3dda30  push r9
00007871bd3dda32  push r10
00007871bd3dda34  push r11
00007871bd3dda36  sub rsp, 0xF0
00007871bd3dda3d  vmovaps [rsp], xmm0
00007871bd3dda42  vmovaps [rsp+0x10], xmm1
00007871bd3dda48  vmovaps [rsp+0x20], xmm2
00007871bd3dda4e  vmovaps [rsp+0x30], xmm3
00007871bd3dda54  vmovaps [rsp+0x40], xmm4
00007871bd3dda5a  vmovaps [rsp+0x50], xmm5
00007871bd3dda60  vmovaps [rsp+0x60], xmm6
00007871bd3dda66  vmovaps [rsp+0x70], xmm8
00007871bd3dda6c  vmovaps [rsp+0x80], xmm9
00007871bd3dda75  vmovaps [rsp+0x90], xmm10
00007871bd3dda7e  vmovaps [rsp+0xA0], xmm11
00007871bd3dda87  vmovaps [rsp+0xB0], xmm12
00007871bd3dda90  vmovaps [rsp+0xC0], xmm13
00007871bd3dda99  vmovaps [rsp+0xD0], xmm14
00007871bd3ddaa2  vmovaps [rsp+0xE0], xmm15
00007871bd3ddaab  sub rsp, 0x30
00007871bd3ddaaf  movaps [rsp], xmm7
00007871bd3ddab3  movaps [rsp+0x10], xmm11
00007871bd3ddab9  movaps [rsp+0x20], xmm9
00007871bd3ddabf  lea rdi, [rsp]
00007871bd3ddac3  mov esi, 0x00
00007871bd3ddac8  mov rax, 0x5BA2FDD2A530
00007871bd3ddad2  call rax
00007871bd3ddad4  movaps xmm7, [rsp]
00007871bd3ddad8  add rsp, 0x30
00007871bd3ddadc  vmovaps xmm0, [rsp]
00007871bd3ddae1  vmovaps xmm1, [rsp+0x10]
00007871bd3ddae7  vmovaps xmm2, [rsp+0x20]
00007871bd3ddaed  vmovaps xmm3, [rsp+0x30]
00007871bd3ddaf3  vmovaps xmm4, [rsp+0x40]
00007871bd3ddaf9  vmovaps xmm5, [rsp+0x50]
00007871bd3ddaff  vmovaps xmm6, [rsp+0x60]
00007871bd3ddb05  vmovaps xmm8, [rsp+0x70]
00007871bd3ddb0b  vmovaps xmm9, [rsp+0x80]
00007871bd3ddb14  vmovaps xmm10, [rsp+0x90]
00007871bd3ddb1d  vmovaps xmm11, [rsp+0xA0]
00007871bd3ddb26  vmovaps xmm12, [rsp+0xB0]
00007871bd3ddb2f  vmovaps xmm13, [rsp+0xC0]
00007871bd3ddb38  vmovaps xmm14, [rsp+0xD0]
00007871bd3ddb41  vmovaps xmm15, [rsp+0xE0]
00007871bd3ddb4a  add rsp, 0xF0
00007871bd3ddb51  pop r11
00007871bd3ddb53  pop r10
00007871bd3ddb55  pop r9
00007871bd3ddb57  pop r8
00007871bd3ddb59  pop rsi
00007871bd3ddb5a  pop rdi
00007871bd3ddb5b  pop rdx
00007871bd3ddb5c  pop rcx
00007871bd3ddb5d  pop rax
00007871bd3ddb5e  add rsp, 0x08
00007871bd3ddb62  jmp 0x00007871BD3D96B2
00007871bd3ddb67  sub rsp, 0x08
00007871bd3ddb6b  push rax
00007871bd3ddb6c  push rcx
00007871bd3ddb6d  push rdx
00007871bd3ddb6e  push rdi
00007871bd3ddb6f  push rsi
00007871bd3ddb70  push r8
00007871bd3ddb72  push r9
00007871bd3ddb74  push r10
00007871bd3ddb76  push r11
00007871bd3ddb78  sub rsp, 0xF0
00007871bd3ddb7f  vmovaps [rsp], xmm0
00007871bd3ddb84  vmovaps [rsp+0x10], xmm1
00007871bd3ddb8a  vmovaps [rsp+0x20], xmm2
00007871bd3ddb90  vmovaps [rsp+0x30], xmm3
00007871bd3ddb96  vmovaps [rsp+0x40], xmm4
00007871bd3ddb9c  vmovaps [rsp+0x50], xmm5
00007871bd3ddba2  vmovaps [rsp+0x60], xmm6
00007871bd3ddba8  vmovaps [rsp+0x70], xmm7
00007871bd3ddbae  vmovaps [rsp+0x80], xmm8
00007871bd3ddbb7  vmovaps [rsp+0x90], xmm9
00007871bd3ddbc0  vmovaps [rsp+0xA0], xmm10
00007871bd3ddbc9  vmovaps [rsp+0xB0], xmm12
00007871bd3ddbd2  vmovaps [rsp+0xC0], xmm13
00007871bd3ddbdb  vmovaps [rsp+0xD0], xmm14
00007871bd3ddbe4  vmovaps [rsp+0xE0], xmm15
00007871bd3ddbed  sub rsp, 0x30
00007871bd3ddbf1  movaps [rsp], xmm11
00007871bd3ddbf6  movaps [rsp+0x10], xmm10
00007871bd3ddbfc  movaps [rsp+0x20], xmm14
00007871bd3ddc02  lea rdi, [rsp]
00007871bd3ddc06  mov esi, 0x00
00007871bd3ddc0b  mov rax, 0x5BA2FDD2A530
00007871bd3ddc15  call rax
00007871bd3ddc17  movaps xmm11, [rsp]
00007871bd3ddc1c  add rsp, 0x30
00007871bd3ddc20  vmovaps xmm0, [rsp]
00007871bd3ddc25  vmovaps xmm1, [rsp+0x10]
00007871bd3ddc2b  vmovaps xmm2, [rsp+0x20]
00007871bd3ddc31  vmovaps xmm3, [rsp+0x30]
00007871bd3ddc37  vmovaps xmm4, [rsp+0x40]
00007871bd3ddc3d  vmovaps xmm5, [rsp+0x50]
00007871bd3ddc43  vmovaps xmm6, [rsp+0x60]
00007871bd3ddc49  vmovaps xmm7, [rsp+0x70]
00007871bd3ddc4f  vmovaps xmm8, [rsp+0x80]
00007871bd3ddc58  vmovaps xmm9, [rsp+0x90]
00007871bd3ddc61  vmovaps xmm10, [rsp+0xA0]
00007871bd3ddc6a  vmovaps xmm12, [rsp+0xB0]
00007871bd3ddc73  vmovaps xmm13, [rsp+0xC0]
00007871bd3ddc7c  vmovaps xmm14, [rsp+0xD0]
00007871bd3ddc85  vmovaps xmm15, [rsp+0xE0]
00007871bd3ddc8e  add rsp, 0xF0
00007871bd3ddc95  pop r11
00007871bd3ddc97  pop r10
00007871bd3ddc99  pop r9
00007871bd3ddc9b  pop r8
00007871bd3ddc9d  pop rsi
00007871bd3ddc9e  pop rdi
00007871bd3ddc9f  pop rdx
00007871bd3ddca0  pop rcx
00007871bd3ddca1  pop rax
00007871bd3ddca2  add rsp, 0x08
00007871bd3ddca6  jmp 0x00007871BD3D96CD
00007871bd3ddcab  call 0x00007871BD2E45A0
00007871bd3ddcb0  jmp 0x00007871BD3D96D7
00007871bd3ddcb5  sub rsp, 0x08
00007871bd3ddcb9  push rax
00007871bd3ddcba  push rcx
00007871bd3ddcbb  push rdx
00007871bd3ddcbc  push rdi
00007871bd3ddcbd  push rsi
00007871bd3ddcbe  push r8
00007871bd3ddcc0  push r9
00007871bd3ddcc2  push r10
00007871bd3ddcc4  push r11
00007871bd3ddcc6  sub rsp, 0xF0
00007871bd3ddccd  vmovaps [rsp], xmm0
00007871bd3ddcd2  vmovaps [rsp+0x10], xmm1
00007871bd3ddcd8  vmovaps [rsp+0x20], xmm2
00007871bd3ddcde  vmovaps [rsp+0x30], xmm3
00007871bd3ddce4  vmovaps [rsp+0x40], xmm4
00007871bd3ddcea  vmovaps [rsp+0x50], xmm5
00007871bd3ddcf0  vmovaps [rsp+0x60], xmm6
00007871bd3ddcf6  vmovaps [rsp+0x70], xmm7
00007871bd3ddcfc  vmovaps [rsp+0x80], xmm8
00007871bd3ddd05  vmovaps [rsp+0x90], xmm9
00007871bd3ddd0e  vmovaps [rsp+0xA0], xmm11
00007871bd3ddd17  vmovaps [rsp+0xB0], xmm12
00007871bd3ddd20  vmovaps [rsp+0xC0], xmm13
00007871bd3ddd29  vmovaps [rsp+0xD0], xmm14
00007871bd3ddd32  vmovaps [rsp+0xE0], xmm15
00007871bd3ddd3b  sub rsp, 0x30
00007871bd3ddd3f  movaps [rsp], xmm10
00007871bd3ddd44  movaps [rsp+0x10], xmm1
00007871bd3ddd49  movaps [rsp+0x20], xmm12
00007871bd3ddd4f  lea rdi, [rsp]
00007871bd3ddd53  mov esi, 0x00
00007871bd3ddd58  mov rax, 0x5BA2FDD2A530
00007871bd3ddd62  call rax
00007871bd3ddd64  movaps xmm10, [rsp]
00007871bd3ddd69  add rsp, 0x30
00007871bd3ddd6d  vmovaps xmm0, [rsp]
00007871bd3ddd72  vmovaps xmm1, [rsp+0x10]
00007871bd3ddd78  vmovaps xmm2, [rsp+0x20]
00007871bd3ddd7e  vmovaps xmm3, [rsp+0x30]
00007871bd3ddd84  vmovaps xmm4, [rsp+0x40]
00007871bd3ddd8a  vmovaps xmm5, [rsp+0x50]
00007871bd3ddd90  vmovaps xmm6, [rsp+0x60]
00007871bd3ddd96  vmovaps xmm7, [rsp+0x70]
00007871bd3ddd9c  vmovaps xmm8, [rsp+0x80]
00007871bd3ddda5  vmovaps xmm9, [rsp+0x90]
00007871bd3dddae  vmovaps xmm11, [rsp+0xA0]
00007871bd3dddb7  vmovaps xmm12, [rsp+0xB0]
00007871bd3dddc0  vmovaps xmm13, [rsp+0xC0]
00007871bd3dddc9  vmovaps xmm14, [rsp+0xD0]
00007871bd3dddd2  vmovaps xmm15, [rsp+0xE0]
00007871bd3ddddb  add rsp, 0xF0
00007871bd3ddde2  pop r11
00007871bd3ddde4  pop r10
00007871bd3ddde6  pop r9
00007871bd3ddde8  pop r8
00007871bd3dddea  pop rsi
00007871bd3dddeb  pop rdi
00007871bd3dddec  pop rdx
00007871bd3ddded  pop rcx
00007871bd3dddee  pop rax
00007871bd3dddef  add rsp, 0x08
00007871bd3dddf3  jmp 0x00007871BD3D96FA
00007871bd3dddf8  sub rsp, 0x08
00007871bd3dddfc  push rax
00007871bd3dddfd  push rcx
00007871bd3dddfe  push rdx
00007871bd3dddff  push rdi
00007871bd3dde00  push rsi
00007871bd3dde01  push r8
00007871bd3dde03  push r9
00007871bd3dde05  push r10
00007871bd3dde07  push r11
00007871bd3dde09  sub rsp, 0xF0
00007871bd3dde10  vmovaps [rsp], xmm0
00007871bd3dde15  vmovaps [rsp+0x10], xmm1
00007871bd3dde1b  vmovaps [rsp+0x20], xmm2
00007871bd3dde21  vmovaps [rsp+0x30], xmm3
00007871bd3dde27  vmovaps [rsp+0x40], xmm4
00007871bd3dde2d  vmovaps [rsp+0x50], xmm5
00007871bd3dde33  vmovaps [rsp+0x60], xmm6
00007871bd3dde39  vmovaps [rsp+0x70], xmm7
00007871bd3dde3f  vmovaps [rsp+0x80], xmm8
00007871bd3dde48  vmovaps [rsp+0x90], xmm9
00007871bd3dde51  vmovaps [rsp+0xA0], xmm10
00007871bd3dde5a  vmovaps [rsp+0xB0], xmm11
00007871bd3dde63  vmovaps [rsp+0xC0], xmm13
00007871bd3dde6c  vmovaps [rsp+0xD0], xmm14
00007871bd3dde75  vmovaps [rsp+0xE0], xmm15
00007871bd3dde7e  sub rsp, 0x30
00007871bd3dde82  movaps [rsp], xmm12
00007871bd3dde87  movaps [rsp+0x10], xmm14
00007871bd3dde8d  movaps [rsp+0x20], xmm1
00007871bd3dde92  lea rdi, [rsp]
00007871bd3dde96  mov esi, 0x00
00007871bd3dde9b  mov rax, 0x5BA2FDD2A530
00007871bd3ddea5  call rax
00007871bd3ddea7  movaps xmm12, [rsp]
00007871bd3ddeac  add rsp, 0x30
00007871bd3ddeb0  vmovaps xmm0, [rsp]
00007871bd3ddeb5  vmovaps xmm1, [rsp+0x10]
00007871bd3ddebb  vmovaps xmm2, [rsp+0x20]
00007871bd3ddec1  vmovaps xmm3, [rsp+0x30]
00007871bd3ddec7  vmovaps xmm4, [rsp+0x40]
00007871bd3ddecd  vmovaps xmm5, [rsp+0x50]
00007871bd3dded3  vmovaps xmm6, [rsp+0x60]
00007871bd3dded9  vmovaps xmm7, [rsp+0x70]
00007871bd3ddedf  vmovaps xmm8, [rsp+0x80]
00007871bd3ddee8  vmovaps xmm9, [rsp+0x90]
00007871bd3ddef1  vmovaps xmm10, [rsp+0xA0]
00007871bd3ddefa  vmovaps xmm11, [rsp+0xB0]
00007871bd3ddf03  vmovaps xmm13, [rsp+0xC0]
00007871bd3ddf0c  vmovaps xmm14, [rsp+0xD0]
00007871bd3ddf15  vmovaps xmm15, [rsp+0xE0]
00007871bd3ddf1e  add rsp, 0xF0
00007871bd3ddf25  pop r11
00007871bd3ddf27  pop r10
00007871bd3ddf29  pop r9
00007871bd3ddf2b  pop r8
00007871bd3ddf2d  pop rsi
00007871bd3ddf2e  pop rdi
00007871bd3ddf2f  pop rdx
00007871bd3ddf30  pop rcx
00007871bd3ddf31  pop rax
00007871bd3ddf32  add rsp, 0x08
00007871bd3ddf36  jmp 0x00007871BD3D9729
00007871bd3ddf3b  sub rsp, 0x08
00007871bd3ddf3f  push rax
00007871bd3ddf40  push rcx
00007871bd3ddf41  push rdx
00007871bd3ddf42  push rdi
00007871bd3ddf43  push rsi
00007871bd3ddf44  push r8
00007871bd3ddf46  push r9
00007871bd3ddf48  push r10
00007871bd3ddf4a  push r11
00007871bd3ddf4c  sub rsp, 0xF0
00007871bd3ddf53  vmovaps [rsp], xmm0
00007871bd3ddf58  vmovaps [rsp+0x10], xmm1
00007871bd3ddf5e  vmovaps [rsp+0x20], xmm2
00007871bd3ddf64  vmovaps [rsp+0x30], xmm3
00007871bd3ddf6a  vmovaps [rsp+0x40], xmm4
00007871bd3ddf70  vmovaps [rsp+0x50], xmm5
00007871bd3ddf76  vmovaps [rsp+0x60], xmm6
00007871bd3ddf7c  vmovaps [rsp+0x70], xmm7
00007871bd3ddf82  vmovaps [rsp+0x80], xmm8
00007871bd3ddf8b  vmovaps [rsp+0x90], xmm9
00007871bd3ddf94  vmovaps [rsp+0xA0], xmm10
00007871bd3ddf9d  vmovaps [rsp+0xB0], xmm11
00007871bd3ddfa6  vmovaps [rsp+0xC0], xmm12
00007871bd3ddfaf  vmovaps [rsp+0xD0], xmm13
00007871bd3ddfb8  vmovaps [rsp+0xE0], xmm15
00007871bd3ddfc1  sub rsp, 0x30
00007871bd3ddfc5  movaps [rsp], xmm14
00007871bd3ddfca  movaps [rsp+0x10], xmm9
00007871bd3ddfd0  movaps [rsp+0x20], xmm1
00007871bd3ddfd5  lea rdi, [rsp]
00007871bd3ddfd9  mov esi, 0x00
00007871bd3ddfde  mov rax, 0x5BA2FDD2A530
00007871bd3ddfe8  call rax
00007871bd3ddfea  movaps xmm14, [rsp]
00007871bd3ddfef  add rsp, 0x30
00007871bd3ddff3  vmovaps xmm0, [rsp]
00007871bd3ddff8  vmovaps xmm1, [rsp+0x10]
00007871bd3ddffe  vmovaps xmm2, [rsp+0x20]
00007871bd3de004  vmovaps xmm3, [rsp+0x30]
00007871bd3de00a  vmovaps xmm4, [rsp+0x40]
00007871bd3de010  vmovaps xmm5, [rsp+0x50]
00007871bd3de016  vmovaps xmm6, [rsp+0x60]
00007871bd3de01c  vmovaps xmm7, [rsp+0x70]
00007871bd3de022  vmovaps xmm8, [rsp+0x80]
00007871bd3de02b  vmovaps xmm9, [rsp+0x90]
00007871bd3de034  vmovaps xmm10, [rsp+0xA0]
00007871bd3de03d  vmovaps xmm11, [rsp+0xB0]
00007871bd3de046  vmovaps xmm12, [rsp+0xC0]
00007871bd3de04f  vmovaps xmm13, [rsp+0xD0]
00007871bd3de058  vmovaps xmm15, [rsp+0xE0]
00007871bd3de061  add rsp, 0xF0
00007871bd3de068  pop r11
00007871bd3de06a  pop r10
00007871bd3de06c  pop r9
00007871bd3de06e  pop r8
00007871bd3de070  pop rsi
00007871bd3de071  pop rdi
00007871bd3de072  pop rdx
00007871bd3de073  pop rcx
00007871bd3de074  pop rax
00007871bd3de075  add rsp, 0x08
00007871bd3de079  jmp 0x00007871BD3D9758
00007871bd3de07e  sub rsp, 0x08
00007871bd3de082  push rax
00007871bd3de083  push rcx
00007871bd3de084  push rdx
00007871bd3de085  push rdi
00007871bd3de086  push rsi
00007871bd3de087  push r8
00007871bd3de089  push r9
00007871bd3de08b  push r10
00007871bd3de08d  push r11
00007871bd3de08f  sub rsp, 0xF0
00007871bd3de096  vmovaps [rsp], xmm0
00007871bd3de09b  vmovaps [rsp+0x10], xmm2
00007871bd3de0a1  vmovaps [rsp+0x20], xmm3
00007871bd3de0a7  vmovaps [rsp+0x30], xmm4
00007871bd3de0ad  vmovaps [rsp+0x40], xmm5
00007871bd3de0b3  vmovaps [rsp+0x50], xmm6
00007871bd3de0b9  vmovaps [rsp+0x60], xmm7
00007871bd3de0bf  vmovaps [rsp+0x70], xmm8
00007871bd3de0c5  vmovaps [rsp+0x80], xmm9
00007871bd3de0ce  vmovaps [rsp+0x90], xmm10
00007871bd3de0d7  vmovaps [rsp+0xA0], xmm11
00007871bd3de0e0  vmovaps [rsp+0xB0], xmm12
00007871bd3de0e9  vmovaps [rsp+0xC0], xmm13
00007871bd3de0f2  vmovaps [rsp+0xD0], xmm14
00007871bd3de0fb  vmovaps [rsp+0xE0], xmm15
00007871bd3de104  sub rsp, 0x30
00007871bd3de108  movaps [rsp], xmm1
00007871bd3de10c  movaps [rsp+0x10], xmm13
00007871bd3de112  movaps [rsp+0x20], xmm8
00007871bd3de118  lea rdi, [rsp]
00007871bd3de11c  mov esi, 0x00
00007871bd3de121  mov rax, 0x5BA2FDD2A530
00007871bd3de12b  call rax
00007871bd3de12d  movaps xmm1, [rsp]
00007871bd3de131  add rsp, 0x30
00007871bd3de135  vmovaps xmm0, [rsp]
00007871bd3de13a  vmovaps xmm2, [rsp+0x10]
00007871bd3de140  vmovaps xmm3, [rsp+0x20]
00007871bd3de146  vmovaps xmm4, [rsp+0x30]
00007871bd3de14c  vmovaps xmm5, [rsp+0x40]
00007871bd3de152  vmovaps xmm6, [rsp+0x50]
00007871bd3de158  vmovaps xmm7, [rsp+0x60]
00007871bd3de15e  vmovaps xmm8, [rsp+0x70]
00007871bd3de164  vmovaps xmm9, [rsp+0x80]
00007871bd3de16d  vmovaps xmm10, [rsp+0x90]
00007871bd3de176  vmovaps xmm11, [rsp+0xA0]
00007871bd3de17f  vmovaps xmm12, [rsp+0xB0]
00007871bd3de188  vmovaps xmm13, [rsp+0xC0]
00007871bd3de191  vmovaps xmm14, [rsp+0xD0]
00007871bd3de19a  vmovaps xmm15, [rsp+0xE0]
00007871bd3de1a3  add rsp, 0xF0
00007871bd3de1aa  pop r11
00007871bd3de1ac  pop r10
00007871bd3de1ae  pop r9
00007871bd3de1b0  pop r8
00007871bd3de1b2  pop rsi
00007871bd3de1b3  pop rdi
00007871bd3de1b4  pop rdx
00007871bd3de1b5  pop rcx
00007871bd3de1b6  pop rax
00007871bd3de1b7  add rsp, 0x08
00007871bd3de1bb  jmp 0x00007871BD3D977A
00007871bd3de1c0  call 0x00007871BD20C260
00007871bd3de1c5  jmp 0x00007871BD3D9788
00007871bd3de1ca  call 0x00007871BD2DE950
00007871bd3de1cf  jmp 0x00007871BD3D9792
00007871bd3de1d4  sub rsp, 0x08
00007871bd3de1d8  push rax
00007871bd3de1d9  push rcx
00007871bd3de1da  push rdx
00007871bd3de1db  push rdi
00007871bd3de1dc  push rsi
00007871bd3de1dd  push r8
00007871bd3de1df  push r9
00007871bd3de1e1  push r10
00007871bd3de1e3  push r11
00007871bd3de1e5  sub rsp, 0xF0
00007871bd3de1ec  vmovaps [rsp], xmm0
00007871bd3de1f1  vmovaps [rsp+0x10], xmm1
00007871bd3de1f7  vmovaps [rsp+0x20], xmm2
00007871bd3de1fd  vmovaps [rsp+0x30], xmm3
00007871bd3de203  vmovaps [rsp+0x40], xmm4
00007871bd3de209  vmovaps [rsp+0x50], xmm5
00007871bd3de20f  vmovaps [rsp+0x60], xmm6
00007871bd3de215  vmovaps [rsp+0x70], xmm7
00007871bd3de21b  vmovaps [rsp+0x80], xmm9
00007871bd3de224  vmovaps [rsp+0x90], xmm10
00007871bd3de22d  vmovaps [rsp+0xA0], xmm11
00007871bd3de236  vmovaps [rsp+0xB0], xmm12
00007871bd3de23f  vmovaps [rsp+0xC0], xmm13
00007871bd3de248  vmovaps [rsp+0xD0], xmm14
00007871bd3de251  vmovaps [rsp+0xE0], xmm15
00007871bd3de25a  sub rsp, 0x30
00007871bd3de25e  movaps [rsp], xmm8
00007871bd3de263  movaps [rsp+0x10], xmm15
00007871bd3de269  movaps [rsp+0x20], xmm7
00007871bd3de26e  lea rdi, [rsp]
00007871bd3de272  mov esi, 0x00
00007871bd3de277  mov rax, 0x5BA2FDD2A530
00007871bd3de281  call rax
00007871bd3de283  movaps xmm8, [rsp]
00007871bd3de288  add rsp, 0x30
00007871bd3de28c  vmovaps xmm0, [rsp]
00007871bd3de291  vmovaps xmm1, [rsp+0x10]
00007871bd3de297  vmovaps xmm2, [rsp+0x20]
00007871bd3de29d  vmovaps xmm3, [rsp+0x30]
00007871bd3de2a3  vmovaps xmm4, [rsp+0x40]
00007871bd3de2a9  vmovaps xmm5, [rsp+0x50]
00007871bd3de2af  vmovaps xmm6, [rsp+0x60]
00007871bd3de2b5  vmovaps xmm7, [rsp+0x70]
00007871bd3de2bb  vmovaps xmm9, [rsp+0x80]
00007871bd3de2c4  vmovaps xmm10, [rsp+0x90]
00007871bd3de2cd  vmovaps xmm11, [rsp+0xA0]
00007871bd3de2d6  vmovaps xmm12, [rsp+0xB0]
00007871bd3de2df  vmovaps xmm13, [rsp+0xC0]
00007871bd3de2e8  vmovaps xmm14, [rsp+0xD0]
00007871bd3de2f1  vmovaps xmm15, [rsp+0xE0]
00007871bd3de2fa  add rsp, 0xF0
00007871bd3de301  pop r11
00007871bd3de303  pop r10
00007871bd3de305  pop r9
00007871bd3de307  pop r8
00007871bd3de309  pop rsi
00007871bd3de30a  pop rdi
00007871bd3de30b  pop rdx
00007871bd3de30c  pop rcx
00007871bd3de30d  pop rax
00007871bd3de30e  add rsp, 0x08
00007871bd3de312  jmp 0x00007871BD3D97B4
00007871bd3de317  sub rsp, 0x08
00007871bd3de31b  push rax
00007871bd3de31c  push rcx
00007871bd3de31d  push rdx
00007871bd3de31e  push rdi
00007871bd3de31f  push rsi
00007871bd3de320  push r8
00007871bd3de322  push r9
00007871bd3de324  push r10
00007871bd3de326  push r11
00007871bd3de328  sub rsp, 0xF0
00007871bd3de32f  vmovaps [rsp], xmm0
00007871bd3de334  vmovaps [rsp+0x10], xmm1
00007871bd3de33a  vmovaps [rsp+0x20], xmm2
00007871bd3de340  vmovaps [rsp+0x30], xmm3
00007871bd3de346  vmovaps [rsp+0x40], xmm4
00007871bd3de34c  vmovaps [rsp+0x50], xmm5
00007871bd3de352  vmovaps [rsp+0x60], xmm6
00007871bd3de358  vmovaps [rsp+0x70], xmm8
00007871bd3de35e  vmovaps [rsp+0x80], xmm9
00007871bd3de367  vmovaps [rsp+0x90], xmm10
00007871bd3de370  vmovaps [rsp+0xA0], xmm11
00007871bd3de379  vmovaps [rsp+0xB0], xmm12
00007871bd3de382  vmovaps [rsp+0xC0], xmm13
00007871bd3de38b  vmovaps [rsp+0xD0], xmm14
00007871bd3de394  vmovaps [rsp+0xE0], xmm15
00007871bd3de39d  sub rsp, 0x30
00007871bd3de3a1  movaps [rsp], xmm7
00007871bd3de3a5  movaps [rsp+0x10], xmm9
00007871bd3de3ab  movaps [rsp+0x20], xmm15
00007871bd3de3b1  lea rdi, [rsp]
00007871bd3de3b5  mov esi, 0x00
00007871bd3de3ba  mov rax, 0x5BA2FDD2A530
00007871bd3de3c4  call rax
00007871bd3de3c6  movaps xmm7, [rsp]
00007871bd3de3ca  add rsp, 0x30
00007871bd3de3ce  vmovaps xmm0, [rsp]
00007871bd3de3d3  vmovaps xmm1, [rsp+0x10]
00007871bd3de3d9  vmovaps xmm2, [rsp+0x20]
00007871bd3de3df  vmovaps xmm3, [rsp+0x30]
00007871bd3de3e5  vmovaps xmm4, [rsp+0x40]
00007871bd3de3eb  vmovaps xmm5, [rsp+0x50]
00007871bd3de3f1  vmovaps xmm6, [rsp+0x60]
00007871bd3de3f7  vmovaps xmm8, [rsp+0x70]
00007871bd3de3fd  vmovaps xmm9, [rsp+0x80]
00007871bd3de406  vmovaps xmm10, [rsp+0x90]
00007871bd3de40f  vmovaps xmm11, [rsp+0xA0]
00007871bd3de418  vmovaps xmm12, [rsp+0xB0]
00007871bd3de421  vmovaps xmm13, [rsp+0xC0]
00007871bd3de42a  vmovaps xmm14, [rsp+0xD0]
00007871bd3de433  vmovaps xmm15, [rsp+0xE0]
00007871bd3de43c  add rsp, 0xF0
00007871bd3de443  pop r11
00007871bd3de445  pop r10
00007871bd3de447  pop r9
00007871bd3de449  pop r8
00007871bd3de44b  pop rsi
00007871bd3de44c  pop rdi
00007871bd3de44d  pop rdx
00007871bd3de44e  pop rcx
00007871bd3de44f  pop rax
00007871bd3de450  add rsp, 0x08
00007871bd3de454  jmp 0x00007871BD3D97E1
00007871bd3de459  sub rsp, 0x08
00007871bd3de45d  push rax
00007871bd3de45e  push rcx
00007871bd3de45f  push rdx
00007871bd3de460  push rdi
00007871bd3de461  push rsi
00007871bd3de462  push r8
00007871bd3de464  push r9
00007871bd3de466  push r10
00007871bd3de468  push r11
00007871bd3de46a  sub rsp, 0xF0
00007871bd3de471  vmovaps [rsp], xmm0
00007871bd3de476  vmovaps [rsp+0x10], xmm1
00007871bd3de47c  vmovaps [rsp+0x20], xmm2
00007871bd3de482  vmovaps [rsp+0x30], xmm3
00007871bd3de488  vmovaps [rsp+0x40], xmm4
00007871bd3de48e  vmovaps [rsp+0x50], xmm5
00007871bd3de494  vmovaps [rsp+0x60], xmm6
00007871bd3de49a  vmovaps [rsp+0x70], xmm7
00007871bd3de4a0  vmovaps [rsp+0x80], xmm8
00007871bd3de4a9  vmovaps [rsp+0x90], xmm10
00007871bd3de4b2  vmovaps [rsp+0xA0], xmm11
00007871bd3de4bb  vmovaps [rsp+0xB0], xmm12
00007871bd3de4c4  vmovaps [rsp+0xC0], xmm13
00007871bd3de4cd  vmovaps [rsp+0xD0], xmm14
00007871bd3de4d6  vmovaps [rsp+0xE0], xmm15
00007871bd3de4df  sub rsp, 0x30
00007871bd3de4e3  movaps [rsp], xmm9
00007871bd3de4e8  movaps [rsp+0x10], xmm13
00007871bd3de4ee  movaps [rsp+0x20], xmm15
00007871bd3de4f4  lea rdi, [rsp]
00007871bd3de4f8  mov esi, 0x00
00007871bd3de4fd  mov rax, 0x5BA2FDD2A530
00007871bd3de507  call rax
00007871bd3de509  movaps xmm9, [rsp]
00007871bd3de50e  add rsp, 0x30
00007871bd3de512  vmovaps xmm0, [rsp]
00007871bd3de517  vmovaps xmm1, [rsp+0x10]
00007871bd3de51d  vmovaps xmm2, [rsp+0x20]
00007871bd3de523  vmovaps xmm3, [rsp+0x30]
00007871bd3de529  vmovaps xmm4, [rsp+0x40]
00007871bd3de52f  vmovaps xmm5, [rsp+0x50]
00007871bd3de535  vmovaps xmm6, [rsp+0x60]
00007871bd3de53b  vmovaps xmm7, [rsp+0x70]
00007871bd3de541  vmovaps xmm8, [rsp+0x80]
00007871bd3de54a  vmovaps xmm10, [rsp+0x90]
00007871bd3de553  vmovaps xmm11, [rsp+0xA0]
00007871bd3de55c  vmovaps xmm12, [rsp+0xB0]
00007871bd3de565  vmovaps xmm13, [rsp+0xC0]
00007871bd3de56e  vmovaps xmm14, [rsp+0xD0]
00007871bd3de577  vmovaps xmm15, [rsp+0xE0]
00007871bd3de580  add rsp, 0xF0
00007871bd3de587  pop r11
00007871bd3de589  pop r10
00007871bd3de58b  pop r9
00007871bd3de58d  pop r8
00007871bd3de58f  pop rsi
00007871bd3de590  pop rdi
00007871bd3de591  pop rdx
00007871bd3de592  pop rcx
00007871bd3de593  pop rax
00007871bd3de594  add rsp, 0x08
00007871bd3de598  jmp 0x00007871BD3D980F
00007871bd3de59d  sub rsp, 0x08
00007871bd3de5a1  push rax
00007871bd3de5a2  push rcx
00007871bd3de5a3  push rdx
00007871bd3de5a4  push rdi
00007871bd3de5a5  push rsi
00007871bd3de5a6  push r8
00007871bd3de5a8  push r9
00007871bd3de5aa  push r10
00007871bd3de5ac  push r11
00007871bd3de5ae  sub rsp, 0xF0
00007871bd3de5b5  vmovaps [rsp], xmm0
00007871bd3de5ba  vmovaps [rsp+0x10], xmm1
00007871bd3de5c0  vmovaps [rsp+0x20], xmm2
00007871bd3de5c6  vmovaps [rsp+0x30], xmm3
00007871bd3de5cc  vmovaps [rsp+0x40], xmm4
00007871bd3de5d2  vmovaps [rsp+0x50], xmm5
00007871bd3de5d8  vmovaps [rsp+0x60], xmm6
00007871bd3de5de  vmovaps [rsp+0x70], xmm7
00007871bd3de5e4  vmovaps [rsp+0x80], xmm8
00007871bd3de5ed  vmovaps [rsp+0x90], xmm9
00007871bd3de5f6  vmovaps [rsp+0xA0], xmm10
00007871bd3de5ff  vmovaps [rsp+0xB0], xmm11
00007871bd3de608  vmovaps [rsp+0xC0], xmm12
00007871bd3de611  vmovaps [rsp+0xD0], xmm13
00007871bd3de61a  vmovaps [rsp+0xE0], xmm14
00007871bd3de623  sub rsp, 0x30
00007871bd3de627  movaps [rsp], xmm15
00007871bd3de62c  movaps [rsp+0x10], xmm11
00007871bd3de632  movaps [rsp+0x20], xmm12
00007871bd3de638  lea rdi, [rsp]
00007871bd3de63c  mov esi, 0x00
00007871bd3de641  mov rax, 0x5BA2FDD2A530
00007871bd3de64b  call rax
00007871bd3de64d  movaps xmm15, [rsp]
00007871bd3de652  add rsp, 0x30
00007871bd3de656  vmovaps xmm0, [rsp]
00007871bd3de65b  vmovaps xmm1, [rsp+0x10]
00007871bd3de661  vmovaps xmm2, [rsp+0x20]
00007871bd3de667  vmovaps xmm3, [rsp+0x30]
00007871bd3de66d  vmovaps xmm4, [rsp+0x40]
00007871bd3de673  vmovaps xmm5, [rsp+0x50]
00007871bd3de679  vmovaps xmm6, [rsp+0x60]
00007871bd3de67f  vmovaps xmm7, [rsp+0x70]
00007871bd3de685  vmovaps xmm8, [rsp+0x80]
00007871bd3de68e  vmovaps xmm9, [rsp+0x90]
00007871bd3de697  vmovaps xmm10, [rsp+0xA0]
00007871bd3de6a0  vmovaps xmm11, [rsp+0xB0]
00007871bd3de6a9  vmovaps xmm12, [rsp+0xC0]
00007871bd3de6b2  vmovaps xmm13, [rsp+0xD0]
00007871bd3de6bb  vmovaps xmm14, [rsp+0xE0]
00007871bd3de6c4  add rsp, 0xF0
00007871bd3de6cb  pop r11
00007871bd3de6cd  pop r10
00007871bd3de6cf  pop r9
00007871bd3de6d1  pop r8
00007871bd3de6d3  pop rsi
00007871bd3de6d4  pop rdi
00007871bd3de6d5  pop rdx
00007871bd3de6d6  pop rcx
00007871bd3de6d7  pop rax
00007871bd3de6d8  add rsp, 0x08
00007871bd3de6dc  jmp 0x00007871BD3D982A
00007871bd3de6e1  sub rsp, 0x08
00007871bd3de6e5  push rax
00007871bd3de6e6  push rcx
00007871bd3de6e7  push rdx
00007871bd3de6e8  push rdi
00007871bd3de6e9  push rsi
00007871bd3de6ea  push r8
00007871bd3de6ec  push r9
00007871bd3de6ee  push r10
00007871bd3de6f0  push r11
00007871bd3de6f2  sub rsp, 0xF0
00007871bd3de6f9  vmovaps [rsp], xmm0
00007871bd3de6fe  vmovaps [rsp+0x10], xmm1
00007871bd3de704  vmovaps [rsp+0x20], xmm2
00007871bd3de70a  vmovaps [rsp+0x30], xmm3
00007871bd3de710  vmovaps [rsp+0x40], xmm4
00007871bd3de716  vmovaps [rsp+0x50], xmm5
00007871bd3de71c  vmovaps [rsp+0x60], xmm6
00007871bd3de722  vmovaps [rsp+0x70], xmm7
00007871bd3de728  vmovaps [rsp+0x80], xmm8
00007871bd3de731  vmovaps [rsp+0x90], xmm9
00007871bd3de73a  vmovaps [rsp+0xA0], xmm10
00007871bd3de743  vmovaps [rsp+0xB0], xmm11
00007871bd3de74c  vmovaps [rsp+0xC0], xmm12
00007871bd3de755  vmovaps [rsp+0xD0], xmm14
00007871bd3de75e  vmovaps [rsp+0xE0], xmm15
00007871bd3de767  sub rsp, 0x30
00007871bd3de76b  movaps [rsp], xmm13
00007871bd3de770  movaps [rsp+0x10], xmm10
00007871bd3de776  movaps [rsp+0x20], xmm14
00007871bd3de77c  lea rdi, [rsp]
00007871bd3de780  mov esi, 0x00
00007871bd3de785  mov rax, 0x5BA2FDD2A530
00007871bd3de78f  call rax
00007871bd3de791  movaps xmm13, [rsp]
00007871bd3de796  add rsp, 0x30
00007871bd3de79a  vmovaps xmm0, [rsp]
00007871bd3de79f  vmovaps xmm1, [rsp+0x10]
00007871bd3de7a5  vmovaps xmm2, [rsp+0x20]
00007871bd3de7ab  vmovaps xmm3, [rsp+0x30]
00007871bd3de7b1  vmovaps xmm4, [rsp+0x40]
00007871bd3de7b7  vmovaps xmm5, [rsp+0x50]
00007871bd3de7bd  vmovaps xmm6, [rsp+0x60]
00007871bd3de7c3  vmovaps xmm7, [rsp+0x70]
00007871bd3de7c9  vmovaps xmm8, [rsp+0x80]
00007871bd3de7d2  vmovaps xmm9, [rsp+0x90]
00007871bd3de7db  vmovaps xmm10, [rsp+0xA0]
00007871bd3de7e4  vmovaps xmm11, [rsp+0xB0]
00007871bd3de7ed  vmovaps xmm12, [rsp+0xC0]
00007871bd3de7f6  vmovaps xmm14, [rsp+0xD0]
00007871bd3de7ff  vmovaps xmm15, [rsp+0xE0]
00007871bd3de808  add rsp, 0xF0
00007871bd3de80f  pop r11
00007871bd3de811  pop r10
00007871bd3de813  pop r9
00007871bd3de815  pop r8
00007871bd3de817  pop rsi
00007871bd3de818  pop rdi
00007871bd3de819  pop rdx
00007871bd3de81a  pop rcx
00007871bd3de81b  pop rax
00007871bd3de81c  add rsp, 0x08
00007871bd3de820  jmp 0x00007871BD3D984D
00007871bd3de825  sub rsp, 0x08
00007871bd3de829  push rax
00007871bd3de82a  push rcx
00007871bd3de82b  push rdx
00007871bd3de82c  push rdi
00007871bd3de82d  push rsi
00007871bd3de82e  push r8
00007871bd3de830  push r9
00007871bd3de832  push r10
00007871bd3de834  push r11
00007871bd3de836  sub rsp, 0xF0
00007871bd3de83d  vmovaps [rsp], xmm0
00007871bd3de842  vmovaps [rsp+0x10], xmm1
00007871bd3de848  vmovaps [rsp+0x20], xmm2
00007871bd3de84e  vmovaps [rsp+0x30], xmm3
00007871bd3de854  vmovaps [rsp+0x40], xmm4
00007871bd3de85a  vmovaps [rsp+0x50], xmm5
00007871bd3de860  vmovaps [rsp+0x60], xmm6
00007871bd3de866  vmovaps [rsp+0x70], xmm7
00007871bd3de86c  vmovaps [rsp+0x80], xmm8
00007871bd3de875  vmovaps [rsp+0x90], xmm9
00007871bd3de87e  vmovaps [rsp+0xA0], xmm10
00007871bd3de887  vmovaps [rsp+0xB0], xmm11
00007871bd3de890  vmovaps [rsp+0xC0], xmm12
00007871bd3de899  vmovaps [rsp+0xD0], xmm13
00007871bd3de8a2  vmovaps [rsp+0xE0], xmm15
00007871bd3de8ab  sub rsp, 0x30
00007871bd3de8af  movaps [rsp], xmm14
00007871bd3de8b4  movaps [rsp+0x10], xmm1
00007871bd3de8b9  movaps [rsp+0x20], xmm7
00007871bd3de8be  lea rdi, [rsp]
00007871bd3de8c2  mov esi, 0x00
00007871bd3de8c7  mov rax, 0x5BA2FDD2A530
00007871bd3de8d1  call rax
00007871bd3de8d3  movaps xmm14, [rsp]
00007871bd3de8d8  add rsp, 0x30
00007871bd3de8dc  vmovaps xmm0, [rsp]
00007871bd3de8e1  vmovaps xmm1, [rsp+0x10]
00007871bd3de8e7  vmovaps xmm2, [rsp+0x20]
00007871bd3de8ed  vmovaps xmm3, [rsp+0x30]
00007871bd3de8f3  vmovaps xmm4, [rsp+0x40]
00007871bd3de8f9  vmovaps xmm5, [rsp+0x50]
00007871bd3de8ff  vmovaps xmm6, [rsp+0x60]
00007871bd3de905  vmovaps xmm7, [rsp+0x70]
00007871bd3de90b  vmovaps xmm8, [rsp+0x80]
00007871bd3de914  vmovaps xmm9, [rsp+0x90]
00007871bd3de91d  vmovaps xmm10, [rsp+0xA0]
00007871bd3de926  vmovaps xmm11, [rsp+0xB0]
00007871bd3de92f  vmovaps xmm12, [rsp+0xC0]
00007871bd3de938  vmovaps xmm13, [rsp+0xD0]
00007871bd3de941  vmovaps xmm15, [rsp+0xE0]
00007871bd3de94a  add rsp, 0xF0
00007871bd3de951  pop r11
00007871bd3de953  pop r10
00007871bd3de955  pop r9
00007871bd3de957  pop r8
00007871bd3de959  pop rsi
00007871bd3de95a  pop rdi
00007871bd3de95b  pop rdx
00007871bd3de95c  pop rcx
00007871bd3de95d  pop rax
00007871bd3de95e  add rsp, 0x08
00007871bd3de962  jmp 0x00007871BD3D9870
00007871bd3de967  sub rsp, 0x08
00007871bd3de96b  push rax
00007871bd3de96c  push rcx
00007871bd3de96d  push rdx
00007871bd3de96e  push rdi
00007871bd3de96f  push rsi
00007871bd3de970  push r8
00007871bd3de972  push r9
00007871bd3de974  push r10
00007871bd3de976  push r11
00007871bd3de978  sub rsp, 0xF0
00007871bd3de97f  vmovaps [rsp], xmm0
00007871bd3de984  vmovaps [rsp+0x10], xmm2
00007871bd3de98a  vmovaps [rsp+0x20], xmm3
00007871bd3de990  vmovaps [rsp+0x30], xmm4
00007871bd3de996  vmovaps [rsp+0x40], xmm5
00007871bd3de99c  vmovaps [rsp+0x50], xmm6
00007871bd3de9a2  vmovaps [rsp+0x60], xmm7
00007871bd3de9a8  vmovaps [rsp+0x70], xmm8
00007871bd3de9ae  vmovaps [rsp+0x80], xmm9
00007871bd3de9b7  vmovaps [rsp+0x90], xmm10
00007871bd3de9c0  vmovaps [rsp+0xA0], xmm11
00007871bd3de9c9  vmovaps [rsp+0xB0], xmm12
00007871bd3de9d2  vmovaps [rsp+0xC0], xmm13
00007871bd3de9db  vmovaps [rsp+0xD0], xmm14
00007871bd3de9e4  vmovaps [rsp+0xE0], xmm15
00007871bd3de9ed  sub rsp, 0x30
00007871bd3de9f1  movaps [rsp], xmm1
00007871bd3de9f5  movaps [rsp+0x10], xmm8
00007871bd3de9fb  movaps [rsp+0x20], xmm9
00007871bd3dea01  lea rdi, [rsp]
00007871bd3dea05  mov esi, 0x00
00007871bd3dea0a  mov rax, 0x5BA2FDD2A530
00007871bd3dea14  call rax
00007871bd3dea16  movaps xmm1, [rsp]
00007871bd3dea1a  add rsp, 0x30
00007871bd3dea1e  vmovaps xmm0, [rsp]
00007871bd3dea23  vmovaps xmm2, [rsp+0x10]
00007871bd3dea29  vmovaps xmm3, [rsp+0x20]
00007871bd3dea2f  vmovaps xmm4, [rsp+0x30]
00007871bd3dea35  vmovaps xmm5, [rsp+0x40]
00007871bd3dea3b  vmovaps xmm6, [rsp+0x50]
00007871bd3dea41  vmovaps xmm7, [rsp+0x60]
00007871bd3dea47  vmovaps xmm8, [rsp+0x70]
00007871bd3dea4d  vmovaps xmm9, [rsp+0x80]
00007871bd3dea56  vmovaps xmm10, [rsp+0x90]
00007871bd3dea5f  vmovaps xmm11, [rsp+0xA0]
00007871bd3dea68  vmovaps xmm12, [rsp+0xB0]
00007871bd3dea71  vmovaps xmm13, [rsp+0xC0]
00007871bd3dea7a  vmovaps xmm14, [rsp+0xD0]
00007871bd3dea83  vmovaps xmm15, [rsp+0xE0]
00007871bd3dea8c  add rsp, 0xF0
00007871bd3dea93  pop r11
00007871bd3dea95  pop r10
00007871bd3dea97  pop r9
00007871bd3dea99  pop r8
00007871bd3dea9b  pop rsi
00007871bd3dea9c  pop rdi
00007871bd3dea9d  pop rdx
00007871bd3dea9e  pop rcx
00007871bd3dea9f  pop rax
00007871bd3deaa0  add rsp, 0x08
00007871bd3deaa4  jmp 0x00007871BD3D9892
00007871bd3deaa9  call 0x00007871BD2B3E40
00007871bd3deaae  jmp 0x00007871BD3D98A0
00007871bd3deab3  call 0x00007871BD20C380
00007871bd3deab8  jmp 0x00007871BD3D98AA
00007871bd3deabd  call 0x00007871BD20D600
00007871bd3deac2  jmp 0x00007871BD3D98B4
00007871bd3deac7  call 0x00007871BD1FF540
00007871bd3deacc  jmp 0x00007871BD3D98BE
00007871bd3dead1  int3
00007871bd3dead2  nop [rax+rax*1], ax
00007871bd3deadb  nop [rax+rax*1], eax
00007871bd3deae0  mov eax, [r15+0x48]
00007871bd3deae4  lea r14d, [eax+0x01]
00007871bd3deae9  mov [rsp+0x10], r14d
00007871bd3deaee  mov r14d, r14d
00007871bd3deaf1  mov [r15+0x48], r14
00007871bd3deaf5  xor eax, eax
00007871bd3deaf7  mov r14d, [rsp+0x10]
00007871bd3deafc  cmp r14d, 0x1F4
00007871bd3deb03  cmc
00007871bd3deb04  lahf
00007871bd3deb05  seto al
00007871bd3deb08  mov [r15+0x108], eax
00007871bd3deb0f  mov eax, [r15+0x108]
00007871bd3deb16  sahf
00007871bd3deb17  jnz 0x00007871BD3DEB49
00007871bd3deb19  cmp dword ptr [r15+0x318], 0x00
00007871bd3deb21  jz 0x00007871BD3E4C90
00007871bd3deb27  nop [rax+rax*1], ax
00007871bd3deb30  nop [rax+rax*1], eax
00007871bd3deb38  mov eax, 0x4106DC
00007871bd3deb3d  mov [r15+0x100], rax
00007871bd3deb44  jmp 0x00007871BD1FE110
00007871bd3deb49  cmp dword ptr [r15+0x318], 0x00
00007871bd3deb51  jz 0x00007871BD3DEB80
00007871bd3deb57  nop [rax+rax*1], ax
00007871bd3deb60  nop [rax+rax*1], eax
00007871bd3deb68  mov eax, 0x410500
00007871bd3deb6d  mov [r15+0x100], rax
00007871bd3deb74  jmp 0x00007871BD1FE110
00007871bd3deb79  int3
00007871bd3deb7a  int3
00007871bd3deb7b  nop [rax+rax*1], eax
00007871bd3deb80  mov rax, [r15+0x40]
00007871bd3deb84  movaps xmm1, [r15+0x1D0]
00007871bd3deb8c  vmovaps [rsp+0x10], xmm1
00007871bd3deb92  vmovaps xmm15, [rsp+0x10]
00007871bd3deb98  por xmm1, xmm15
00007871bd3deb9d  movaps xmm14, [r15+0x1A0]
00007871bd3deba5  vmovaps [rsp+0x10], xmm14
00007871bd3debab  vmovaps xmm13, [rsp+0x10]
00007871bd3debb1  por xmm14, xmm13
00007871bd3debb6  lea r14, [rax+0x30]
00007871bd3debba  mov r12, [r13+r14*1]
00007871bd3debbf  lea r14, [rax+0x38]
00007871bd3debc3  mov r11, [r13+r14*1]
00007871bd3debc8  movq xmm13, r12
00007871bd3debcd  movq xmm12, r11
00007871bd3debd2  movq xmm13, xmm13
00007871bd3debd7  vmovaps [rsp+0x10], xmm13
00007871bd3debdd  movq xmm13, xmm13
00007871bd3debe2  movaps [r15+0x130], xmm13
00007871bd3debea  movq xmm12, xmm12
00007871bd3debef  vmovaps [rsp+0x20], xmm12
00007871bd3debf5  movq xmm12, xmm12
00007871bd3debfa  movaps [r15+0x280], xmm12
00007871bd3dec02  movaps xmm13, [r15+0x270]
00007871bd3dec0a  vmovaps [rsp+0x30], xmm13
00007871bd3dec10  vmovaps xmm12, [rsp+0x30]
00007871bd3dec16  por xmm13, xmm12
00007871bd3dec1b  lea r14, [rax+0x20]
00007871bd3dec1f  mov r12, [r13+r14*1]
00007871bd3dec24  lea r14, [rax+0x28]
00007871bd3dec28  mov r11, [r13+r14*1]
00007871bd3dec2d  movq xmm12, r12
00007871bd3dec32  movq xmm11, r11
00007871bd3dec37  movq xmm12, xmm12
00007871bd3dec3c  vmovaps [rsp+0x30], xmm12
00007871bd3dec42  movq xmm12, xmm12
00007871bd3dec47  movaps [r15+0x150], xmm12
00007871bd3dec4f  movq xmm11, xmm11
00007871bd3dec54  vmovaps [rsp+0x40], xmm11
00007871bd3dec5a  movq xmm11, xmm11
00007871bd3dec5f  movaps [r15+0x140], xmm11
00007871bd3dec67  lea r14, [rax+0x10]
00007871bd3dec6b  mov r12, [r13+r14*1]
00007871bd3dec70  lea r14, [rax+0x18]
00007871bd3dec74  mov r11, [r13+r14*1]
00007871bd3dec79  movq xmm12, r12
00007871bd3dec7e  movq xmm11, r11
00007871bd3dec83  movq xmm12, xmm12
00007871bd3dec88  vmovaps [rsp+0x50], xmm12
00007871bd3dec8e  movq xmm12, xmm12
00007871bd3dec93  movaps [r15+0x170], xmm12
00007871bd3dec9b  movq xmm11, xmm11
00007871bd3deca0  vmovaps [rsp+0x60], xmm11
00007871bd3deca6  movq xmm11, xmm11
00007871bd3decab  movaps [r15+0x160], xmm11
00007871bd3decb3  mov r14, [r13+rax*1]
00007871bd3decb8  vmovq xmm12, r14
00007871bd3decbd  vpbroadcastq xmm12, xmm12
00007871bd3decc2  lea r14, [rax+0x08]
00007871bd3decc6  mov rax, [r13+r14*1]
00007871bd3deccb  movq xmm11, rax
00007871bd3decd0  movaps [r15+0x230], xmm11
00007871bd3decd8  mov rax, [r15+0xF8]
00007871bd3decdf  lea r14, [rax+0x50]
00007871bd3dece3  movups xmm11, [r13+r14*1]
00007871bd3dece9  lea r14, [rax+0x60]
00007871bd3deced  movups xmm10, [r13+r14*1]
00007871bd3decf3  lea r14, [rax+0x30]
00007871bd3decf7  movups xmm9, [r13+r14*1]
00007871bd3decfd  mov r14, [r15+0x50]
00007871bd3ded01  mov [r15+0x60], r14
00007871bd3ded05  mov qword ptr [r15+0x58], 0x40
00007871bd3ded0d  movaps xmm8, xmm12
00007871bd3ded11  mulpd xmm8, xmm15
00007871bd3ded16  vcmppd xmm7, xmm8, xmm8, 0x03
00007871bd3ded1c  ptest xmm7, xmm7
00007871bd3ded21  jnz 0x00007871BD3DFB4A
00007871bd3ded27  movq xmm15, qword ptr [r15+0x230]
00007871bd3ded30  vmovaps [rsp+0x70], xmm15
00007871bd3ded36  vpermilpd xmm15, xmm15, 0x00
00007871bd3ded3c  movaps xmm7, xmm9
00007871bd3ded40  mulpd xmm7, xmm15
00007871bd3ded45  vcmppd xmm6, xmm7, xmm7, 0x03
00007871bd3ded4a  ptest xmm6, xmm6
00007871bd3ded4f  jnz 0x00007871BD3DFC8E
00007871bd3ded55  vxorps xmm15, xmm15, xmm15
00007871bd3ded5a  vpbroadcastq xmm15, xmm15
00007871bd3ded5f  movaps xmm9, xmm12
00007871bd3ded63  mulpd xmm9, xmm10
00007871bd3ded68  vcmppd xmm6, xmm9, xmm9, 0x03
00007871bd3ded6e  ptest xmm6, xmm6
00007871bd3ded73  jnz 0x00007871BD3DFDD0
00007871bd3ded79  movaps xmm10, xmm12
00007871bd3ded7d  mulpd xmm10, xmm11
00007871bd3ded82  vcmppd xmm6, xmm10, xmm10, 0x03
00007871bd3ded88  ptest xmm6, xmm6
00007871bd3ded8d  jnz 0x00007871BD3DFF14
00007871bd3ded93  movaps xmm11, [r15+0x1F0]
00007871bd3ded9b  movaps xmm6, xmm12
00007871bd3ded9f  mulpd xmm6, xmm11
00007871bd3deda4  vcmppd xmm5, xmm6, xmm6, 0x03
00007871bd3deda9  ptest xmm5, xmm5
00007871bd3dedae  jnz 0x00007871BD3E0058
00007871bd3dedb4  movaps xmm12, [r15+0x2A0]
00007871bd3dedbc  vmovaps [rsp+0x80], xmm12
00007871bd3dedc5  vmovaps xmm11, [rsp+0x80]
00007871bd3dedce  por xmm12, xmm11
00007871bd3dedd3  movaps xmm11, [r15+0x250]
00007871bd3deddb  vmovaps [rsp+0x80], xmm11
00007871bd3dede4  vmovaps xmm5, [rsp+0x80]
00007871bd3deded  por xmm11, xmm5
00007871bd3dedf2  vmovaps xmm4, [rsp+0x70]
00007871bd3dedf8  vpermilpd xmm4, xmm4, 0x00
00007871bd3dedfe  movaps xmm3, xmm5
00007871bd3dee01  mulpd xmm3, xmm4
00007871bd3dee05  vcmppd xmm2, xmm3, xmm3, 0x03
00007871bd3dee0a  ptest xmm2, xmm2
00007871bd3dee0f  jnz 0x00007871BD3E019A
00007871bd3dee15  mov [rsp+0x80], rax
00007871bd3dee1d  xor eax, eax
00007871bd3dee1f  mov r12d, 0x40
00007871bd3dee25  mov r11d, 0x200
00007871bd3dee2b  cmp r12, r11
00007871bd3dee2e  cmc
00007871bd3dee2f  lahf
00007871bd3dee30  seto al
00007871bd3dee33  mov [r15+0x108], eax
00007871bd3dee3a  movaps xmm5, xmm8
00007871bd3dee3e  addpd xmm5, xmm15
00007871bd3dee43  vcmppd xmm4, xmm5, xmm5, 0x03
00007871bd3dee48  ptest xmm4, xmm4
00007871bd3dee4d  jnz 0x00007871BD3E02DA
00007871bd3dee53  movaps xmm8, [r15+0x1B0]
00007871bd3dee5b  movaps xmm4, xmm9
00007871bd3dee5f  addpd xmm4, xmm8
00007871bd3dee64  vcmppd xmm2, xmm4, xmm4, 0x03
00007871bd3dee69  ptest xmm2, xmm2
00007871bd3dee6e  jnz 0x00007871BD3E041C
00007871bd3dee74  movaps xmm9, xmm10
00007871bd3dee78  addpd xmm9, xmm8
00007871bd3dee7d  vcmppd xmm2, xmm9, xmm9, 0x03
00007871bd3dee83  ptest xmm2, xmm2
00007871bd3dee88  jnz 0x00007871BD3E055E
00007871bd3dee8e  movaps xmm10, [r15+0x2F0]
00007871bd3dee96  vmovaps [rsp+0x90], xmm10
00007871bd3dee9f  vmovaps xmm8, [rsp+0x90]
00007871bd3deea8  por xmm10, xmm8
00007871bd3deead  movaps xmm8, [r15+0x2E0]
00007871bd3deeb5  vmovaps [rsp+0x90], xmm8
00007871bd3deebe  vmovaps xmm2, [rsp+0x90]
00007871bd3deec7  por xmm8, xmm2
00007871bd3deecc  movaps xmm2, [r15+0x2D0]
00007871bd3deed4  vmovaps [rsp+0x90], xmm2
00007871bd3deedd  vmovaps [rsp+0xA0], xmm1
00007871bd3deee6  vmovaps xmm1, [rsp+0x90]
00007871bd3deeef  por xmm2, xmm1
00007871bd3deef3  movaps xmm1, [r15+0x200]
00007871bd3deefb  vmovaps [rsp+0x90], xmm1
00007871bd3def04  vmovaps [rsp+0xB0], xmm15
00007871bd3def0d  vmovaps xmm15, [rsp+0x90]
00007871bd3def16  por xmm1, xmm15
00007871bd3def1b  movaps xmm15, [r15+0x1C0]
00007871bd3def23  vmovaps [rsp+0x90], xmm15
00007871bd3def2c  vmovaps [rsp+0xC0], xmm1
00007871bd3def35  vmovaps xmm1, [rsp+0x90]
00007871bd3def3e  por xmm15, xmm1
00007871bd3def43  movaps xmm1, [r15+0x190]
00007871bd3def4b  vmovaps [rsp+0x90], xmm1
00007871bd3def54  vmovaps [rsp+0xD0], xmm15
00007871bd3def5d  vmovaps xmm15, [rsp+0x90]
00007871bd3def66  por xmm1, xmm15
00007871bd3def6b  movaps xmm15, [r15+0x300]
00007871bd3def73  vmovaps [rsp+0x90], xmm15
00007871bd3def7c  vmovaps [rsp+0xE0], xmm1
00007871bd3def85  vmovaps xmm1, [rsp+0x90]
00007871bd3def8e  por xmm15, xmm1
00007871bd3def93  mov rax, [rsp+0x80]
00007871bd3def9b  lea r12, [rax+0xA0]
00007871bd3defa2  movups xmm1, [r13+r12*1]
00007871bd3defa8  lea r12, [rax+0xB0]
00007871bd3defaf  vmovaps [rsp+0x80], xmm1
00007871bd3defb8  movups xmm1, [r13+r12*1]
00007871bd3defbe  vmovaps [rsp+0x90], xmm1
00007871bd3defc7  vmovaps [rsp+0xF0], xmm15
00007871bd3defd0  vmovaps xmm15, [rsp+0xB0]
00007871bd3defd9  vmovaps [rsp+0xB0], xmm14
00007871bd3defe2  movaps xmm1, xmm6
00007871bd3defe5  addpd xmm1, xmm15
00007871bd3defea  vcmppd xmm14, xmm1, xmm1, 0x03
00007871bd3defef  ptest xmm14, xmm14
00007871bd3deff5  jnz 0x00007871BD3E06B6
00007871bd3deffb  lea r12, [rax+0xF0]
00007871bd3df002  movups xmm15, [r13+r12*1]
00007871bd3df008  movaps xmm14, xmm4
00007871bd3df00c  addpd xmm14, xmm3
00007871bd3df011  vcmppd xmm6, xmm14, xmm14, 0x03
00007871bd3df017  ptest xmm6, xmm6
00007871bd3df01c  jnz 0x00007871BD3E0801
00007871bd3df022  movaps xmm6, xmm9
00007871bd3df026  addpd xmm6, xmm7
00007871bd3df02a  vcmppd xmm4, xmm6, xmm6, 0x03
00007871bd3df02f  ptest xmm4, xmm4
00007871bd3df034  jnz 0x00007871BD3E0943
00007871bd3df03a  vmovaps xmm9, [rsp+0x70]
00007871bd3df040  vpermilpd xmm9, xmm9, 0x00
00007871bd3df046  vmovaps xmm4, [rsp+0x90]
00007871bd3df04f  movaps xmm7, xmm4
00007871bd3df052  mulpd xmm7, xmm9
00007871bd3df057  vcmppd xmm3, xmm7, xmm7, 0x03
00007871bd3df05c  ptest xmm3, xmm3
00007871bd3df061  jnz 0x00007871BD3E0A84
00007871bd3df067  vmovaps xmm9, [rsp+0x50]
00007871bd3df06d  vpermilpd xmm9, xmm9, 0x00
00007871bd3df073  movaps xmm4, xmm15
00007871bd3df077  mulpd xmm4, xmm9
00007871bd3df07c  vcmppd xmm3, xmm4, xmm4, 0x03
00007871bd3df081  ptest xmm3, xmm3
00007871bd3df086  jnz 0x00007871BD3E0BC5
00007871bd3df08c  lea r12, [rax+0xE0]
00007871bd3df093  movups xmm15, [r13+r12*1]
00007871bd3df099  vmovaps xmm9, [rsp+0x70]
00007871bd3df09f  vpermilpd xmm9, xmm9, 0x00
00007871bd3df0a5  vmovaps [rsp+0x70], xmm1
00007871bd3df0ab  vmovaps xmm1, [rsp+0x80]
00007871bd3df0b4  vmovaps [rsp+0x80], xmm15
00007871bd3df0bd  movaps xmm3, xmm1
00007871bd3df0c0  mulpd xmm3, xmm9
00007871bd3df0c5  vcmppd xmm15, xmm3, xmm3, 0x03
00007871bd3df0ca  ptest xmm15, xmm15
00007871bd3df0d0  jnz 0x00007871BD3E0D11
00007871bd3df0d6  vmovaps xmm1, [rsp+0xF0]
00007871bd3df0df  vmovaps xmm15, [rsp+0xF0]
00007871bd3df0e8  por xmm1, xmm15
00007871bd3df0ed  movaps [r15+0x300], xmm1
00007871bd3df0f5  vmovaps xmm15, [rsp+0xE0]
00007871bd3df0fe  vmovaps xmm9, [rsp+0xE0]
00007871bd3df107  por xmm15, xmm9
00007871bd3df10c  movaps [r15+0x190], xmm15
00007871bd3df114  vmovaps xmm9, [rsp+0x50]
00007871bd3df11a  vpermilpd xmm9, xmm9, 0x00
00007871bd3df120  vmovaps [rsp+0x90], xmm1
00007871bd3df129  vmovaps [rsp+0xE0], xmm15
00007871bd3df132  vmovaps xmm15, [rsp+0x80]
00007871bd3df13b  vmovaps [rsp+0x80], xmm14
00007871bd3df144  movaps xmm1, xmm15
00007871bd3df148  mulpd xmm1, xmm9
00007871bd3df14d  vcmppd xmm14, xmm1, xmm1, 0x03
00007871bd3df152  ptest xmm14, xmm14
00007871bd3df158  jnz 0x00007871BD3E0E52
00007871bd3df15e  lea r12, [rax+0x90]
00007871bd3df165  movups xmm15, [r13+r12*1]
00007871bd3df16b  vmovaps xmm14, [rsp+0xD0]
00007871bd3df174  vmovaps xmm9, [rsp+0xD0]
00007871bd3df17d  por xmm14, xmm9
00007871bd3df182  movaps [r15+0x1C0], xmm14
00007871bd3df18a  vmovaps xmm9, [rsp+0xC0]
00007871bd3df193  vmovaps [rsp+0xD0], xmm1
00007871bd3df19c  vmovaps xmm1, [rsp+0xC0]
00007871bd3df1a5  por xmm9, xmm1
00007871bd3df1aa  movaps [r15+0x200], xmm9
00007871bd3df1b2  vmovaps [rsp+0xC0], xmm2
00007871bd3df1bb  vmovaps xmm1, [rsp+0xC0]
00007871bd3df1c4  por xmm2, xmm1
00007871bd3df1c8  movaps [r15+0x2D0], xmm2
00007871bd3df1d0  vmovaps [rsp+0xC0], xmm8
00007871bd3df1d9  vmovaps xmm1, [rsp+0xC0]
00007871bd3df1e2  por xmm8, xmm1
00007871bd3df1e7  movaps [r15+0x2E0], xmm8
00007871bd3df1ef  vmovaps [rsp+0xC0], xmm15
00007871bd3df1f8  movaps xmm1, xmm5
00007871bd3df1fb  addpd xmm1, xmm7
00007871bd3df1ff  vcmppd xmm15, xmm1, xmm1, 0x03
00007871bd3df204  ptest xmm15, xmm15
00007871bd3df20a  jnz 0x00007871BD3E0F9E
00007871bd3df210  vmovaps xmm15, [rsp+0x50]
00007871bd3df216  vpermilpd xmm15, xmm15, 0x00
00007871bd3df21c  vmovaps xmm5, [rsp+0xC0]
00007871bd3df225  vmovaps [rsp+0xC0], xmm1
00007871bd3df22e  movaps xmm7, xmm5
00007871bd3df231  mulpd xmm7, xmm15
00007871bd3df236  vcmppd xmm1, xmm7, xmm7, 0x03
00007871bd3df23b  ptest xmm1, xmm1
00007871bd3df240  jnz 0x00007871BD3E10DE
00007871bd3df246  lea r12, [rax+0x80]
00007871bd3df24d  movups xmm1, [r13+r12*1]
00007871bd3df253  vmovaps xmm5, [rsp+0x70]
00007871bd3df259  vmovaps [rsp+0x70], xmm1
00007871bd3df25f  movaps xmm15, xmm5
00007871bd3df263  addpd xmm15, xmm3
00007871bd3df268  vcmppd xmm1, xmm15, xmm15, 0x03
00007871bd3df26e  ptest xmm1, xmm1
00007871bd3df273  jnz 0x00007871BD3E1229
00007871bd3df279  vmovaps xmm5, [rsp+0x80]
00007871bd3df282  movaps xmm1, xmm5
00007871bd3df285  addpd xmm1, xmm4
00007871bd3df289  vcmppd xmm3, xmm1, xmm1, 0x03
00007871bd3df28e  ptest xmm3, xmm3
00007871bd3df293  jnz 0x00007871BD3E136B
00007871bd3df299  vmovaps [rsp+0x80], xmm10
00007871bd3df2a2  vmovaps xmm5, [rsp+0x80]
00007871bd3df2ab  por xmm10, xmm5
00007871bd3df2b0  movaps [r15+0x2F0], xmm10
00007871bd3df2b8  vmovaps xmm5, [rsp+0x50]
00007871bd3df2be  vpermilpd xmm5, xmm5, 0x00
00007871bd3df2c4  vmovaps xmm3, [rsp+0x70]
00007871bd3df2ca  vmovaps [rsp+0x50], xmm1
00007871bd3df2d0  movaps xmm4, xmm3
00007871bd3df2d3  mulpd xmm4, xmm5
00007871bd3df2d7  vcmppd xmm1, xmm4, xmm4, 0x03
00007871bd3df2dc  ptest xmm1, xmm1
00007871bd3df2e1  jnz 0x00007871BD3E14AB
00007871bd3df2e7  lea r12, [rax+0xD0]
00007871bd3df2ee  movups xmm1, [r13+r12*1]
00007871bd3df2f4  vmovaps xmm3, [rsp+0xD0]
00007871bd3df2fd  vmovaps [rsp+0x70], xmm1
00007871bd3df303  movaps xmm5, xmm6
00007871bd3df306  addpd xmm5, xmm3
00007871bd3df30a  vcmppd xmm1, xmm5, xmm5, 0x03
00007871bd3df30f  ptest xmm1, xmm1
00007871bd3df314  jnz 0x00007871BD3E15F5
00007871bd3df31a  vmovaps xmm1, [rsp+0x60]
00007871bd3df320  vpermilpd xmm1, xmm1, 0x00
00007871bd3df326  movaps xmm6, xmm9
00007871bd3df32a  mulpd xmm6, xmm1
00007871bd3df32e  vcmppd xmm3, xmm6, xmm6, 0x03
00007871bd3df333  ptest xmm3, xmm3
00007871bd3df338  jnz 0x00007871BD3E1735
00007871bd3df33e  movaps [r15+0x260], xmm6
00007871bd3df346  vxorps xmm1, xmm1, xmm1
00007871bd3df34a  vpbroadcastq xmm1, xmm1
00007871bd3df34f  movaps [r15+0x1B0], xmm1
00007871bd3df357  vmovaps xmm1, [rsp+0x60]
00007871bd3df35d  vpermilpd xmm1, xmm1, 0x00
00007871bd3df363  vmovaps xmm3, [rsp+0x70]
00007871bd3df369  vmovaps [rsp+0x70], xmm15
00007871bd3df36f  movaps xmm9, xmm3
00007871bd3df373  mulpd xmm9, xmm1
00007871bd3df378  vcmppd xmm15, xmm9, xmm9, 0x03
00007871bd3df37e  ptest xmm15, xmm15
00007871bd3df384  jnz 0x00007871BD3E1876
00007871bd3df38a  lea r12, [rax+0xC0]
00007871bd3df391  movups xmm1, [r13+r12*1]
00007871bd3df397  vmovaps xmm3, [rsp+0xC0]
00007871bd3df3a0  vmovaps [rsp+0x80], xmm1
00007871bd3df3a9  movaps xmm15, xmm3
00007871bd3df3ad  addpd xmm15, xmm7
00007871bd3df3b2  vcmppd xmm1, xmm15, xmm15, 0x03
00007871bd3df3b8  ptest xmm1, xmm1
00007871bd3df3bd  jnz 0x00007871BD3E19C2
00007871bd3df3c3  vmovaps [rsp+0xC0], xmm13
00007871bd3df3cc  vmovaps xmm1, [rsp+0xC0]
00007871bd3df3d5  por xmm13, xmm1
00007871bd3df3da  movaps [r15+0x270], xmm13
00007871bd3df3e2  vmovaps xmm1, [rsp+0xB0]
00007871bd3df3eb  vmovaps xmm7, [rsp+0xB0]
00007871bd3df3f4  por xmm1, xmm7
00007871bd3df3f8  movaps [r15+0x1A0], xmm1
00007871bd3df400  vmovaps xmm1, [rsp+0x60]
00007871bd3df406  vpermilpd xmm1, xmm1, 0x00
00007871bd3df40c  vmovaps [rsp+0xB0], xmm1
00007871bd3df415  vmovaps xmm1, [rsp+0x80]
00007871bd3df41e  vmovaps [rsp+0x80], xmm15
00007871bd3df427  vmovaps xmm15, [rsp+0xB0]
00007871bd3df430  vmovaps [rsp+0xB0], xmm14
00007871bd3df439  movaps xmm3, xmm1
00007871bd3df43c  mulpd xmm3, xmm15
00007871bd3df441  vcmppd xmm14, xmm3, xmm3, 0x03
00007871bd3df446  ptest xmm14, xmm14
00007871bd3df44c  jnz 0x00007871BD3E1B04
00007871bd3df452  lea r12, [rax+0x20]
00007871bd3df456  movups xmm1, [r13+r12*1]
00007871bd3df45c  movaps [r15+0x110], xmm1
00007871bd3df464  vmovaps xmm14, [rsp+0x70]
00007871bd3df46a  vmovaps [rsp+0x70], xmm1
00007871bd3df470  movaps xmm15, xmm14
00007871bd3df474  addpd xmm15, xmm4
00007871bd3df479  vcmppd xmm1, xmm15, xmm15, 0x03
00007871bd3df47f  ptest xmm1, xmm1
00007871bd3df484  jnz 0x00007871BD3E1C4F
00007871bd3df48a  vmovaps xmm1, [rsp+0x60]
00007871bd3df490  vpermilpd xmm1, xmm1, 0x00
00007871bd3df496  movaps xmm14, xmm2
00007871bd3df49a  mulpd xmm14, xmm1
00007871bd3df49f  vcmppd xmm4, xmm14, xmm14, 0x03
00007871bd3df4a5  ptest xmm4, xmm4
00007871bd3df4aa  jnz 0x00007871BD3E1D92
00007871bd3df4b0  vmovaps xmm4, [rsp+0x50]
00007871bd3df4b6  movaps xmm1, xmm4
00007871bd3df4b9  addpd xmm1, xmm9
00007871bd3df4be  vcmppd xmm2, xmm1, xmm1, 0x03
00007871bd3df4c3  ptest xmm2, xmm2
00007871bd3df4c8  jnz 0x00007871BD3E1ED4
00007871bd3df4ce  vmovaps xmm9, [rsp+0x30]
00007871bd3df4d4  vpermilpd xmm9, xmm9, 0x00
00007871bd3df4da  vmovaps xmm2, [rsp+0x70]
00007871bd3df4e0  vmovaps [rsp+0x50], xmm1
00007871bd3df4e6  movaps xmm4, xmm2
00007871bd3df4e9  mulpd xmm4, xmm9
00007871bd3df4ee  vcmppd xmm1, xmm4, xmm4, 0x03
00007871bd3df4f3  ptest xmm1, xmm1
00007871bd3df4f8  jnz 0x00007871BD3E2015
00007871bd3df4fe  vmovaps xmm1, [rsp+0x30]
00007871bd3df504  vpermilpd xmm1, xmm1, 0x00
00007871bd3df50a  vmovaps xmm2, [rsp+0x90]
00007871bd3df513  vmovaps [rsp+0x60], xmm15
00007871bd3df519  movaps xmm9, xmm2
00007871bd3df51d  mulpd xmm9, xmm1
00007871bd3df522  vcmppd xmm15, xmm9, xmm9, 0x03
00007871bd3df528  ptest xmm15, xmm15
00007871bd3df52e  jnz 0x00007871BD3E2156
00007871bd3df534  vmovaps xmm15, [rsp+0x80]
00007871bd3df53d  movaps xmm1, xmm15
00007871bd3df541  addpd xmm1, xmm6
00007871bd3df545  vcmppd xmm2, xmm1, xmm1, 0x03
00007871bd3df54a  ptest xmm2, xmm2
00007871bd3df54f  jnz 0x00007871BD3E2298
00007871bd3df555  movaps xmm15, xmm5
00007871bd3df559  addpd xmm15, xmm3
00007871bd3df55e  vcmppd xmm6, xmm15, xmm15, 0x03
00007871bd3df564  ptest xmm6, xmm6
00007871bd3df569  jnz 0x00007871BD3E23D9
00007871bd3df56f  vmovaps xmm6, [rsp+0x30]
00007871bd3df575  vpermilpd xmm6, xmm6, 0x00
00007871bd3df57b  movaps xmm5, xmm8
00007871bd3df57f  mulpd xmm5, xmm6
00007871bd3df583  vcmppd xmm3, xmm5, xmm5, 0x03
00007871bd3df588  ptest xmm3, xmm3
00007871bd3df58d  jnz 0x00007871BD3E251B
00007871bd3df593  vmovaps xmm8, [rsp+0x30]
00007871bd3df599  vpermilpd xmm8, xmm8, 0x00
00007871bd3df59f  movaps xmm6, xmm10
00007871bd3df5a3  mulpd xmm6, xmm8
00007871bd3df5a8  vcmppd xmm3, xmm6, xmm6, 0x03
00007871bd3df5ad  ptest xmm3, xmm3
00007871bd3df5b2  jnz 0x00007871BD3E265C
00007871bd3df5b8  vmovaps xmm8, [rsp+0x60]
00007871bd3df5be  movaps xmm10, xmm8
00007871bd3df5c2  addpd xmm10, xmm14
00007871bd3df5c7  vcmppd xmm3, xmm10, xmm10, 0x03
00007871bd3df5cd  ptest xmm3, xmm3
00007871bd3df5d2  jnz 0x00007871BD3E279E
00007871bd3df5d8  vmovaps xmm8, [rsp+0x50]
00007871bd3df5de  movaps xmm14, xmm8
00007871bd3df5e2  addpd xmm14, xmm4
00007871bd3df5e7  vcmppd xmm3, xmm14, xmm14, 0x03
00007871bd3df5ed  ptest xmm3, xmm3
00007871bd3df5f2  jnz 0x00007871BD3E28E2
00007871bd3df5f8  vmovaps xmm8, [rsp+0x40]
00007871bd3df5fe  vpermilpd xmm8, xmm8, 0x00
00007871bd3df604  movaps xmm4, xmm13
00007871bd3df608  mulpd xmm4, xmm8
00007871bd3df60d  vcmppd xmm3, xmm4, xmm4, 0x03
00007871bd3df612  ptest xmm3, xmm3
00007871bd3df617  jnz 0x00007871BD3E2A25
00007871bd3df61d  movaps xmm13, xmm15
00007871bd3df621  addpd xmm13, xmm9
00007871bd3df626  vcmppd xmm8, xmm13, xmm13, 0x03
00007871bd3df62c  ptest xmm8, xmm8
00007871bd3df632  jnz 0x00007871BD3E2B67
00007871bd3df638  movaps xmm15, xmm1
00007871bd3df63c  addpd xmm15, xmm5
00007871bd3df641  vcmppd xmm9, xmm15, xmm15, 0x03
00007871bd3df647  ptest xmm9, xmm9
00007871bd3df64d  jnz 0x00007871BD3E2CAB
00007871bd3df653  vmovaps [rsp+0x30], xmm11
00007871bd3df659  vmovaps xmm1, [rsp+0x30]
00007871bd3df65f  por xmm11, xmm1
00007871bd3df664  movaps [r15+0x250], xmm11
00007871bd3df66c  vmovaps [rsp+0x30], xmm12
00007871bd3df672  vmovaps xmm1, [rsp+0x30]
00007871bd3df678  por xmm12, xmm1
00007871bd3df67d  movaps [r15+0x2A0], xmm12
00007871bd3df685  vmovaps xmm1, [rsp+0xA0]
00007871bd3df68e  vmovaps xmm11, [rsp+0xA0]
00007871bd3df697  por xmm1, xmm11
00007871bd3df69c  movaps [r15+0x1D0], xmm1
00007871bd3df6a4  lea r12, [rax+0x40]
00007871bd3df6a8  movups xmm1, [r13+r12*1]
00007871bd3df6ae  movaps [r15+0x2C0], xmm1
00007871bd3df6b6  vmovaps xmm11, [rsp+0x40]
00007871bd3df6bc  vpermilpd xmm11, xmm11, 0x00
00007871bd3df6c2  vmovaps xmm8, [rsp+0xE0]
00007871bd3df6cb  movaps xmm9, xmm8
00007871bd3df6cf  mulpd xmm9, xmm11
00007871bd3df6d4  vcmppd xmm5, xmm9, xmm9, 0x03
00007871bd3df6da  ptest xmm5, xmm5
00007871bd3df6df  jnz 0x00007871BD3E2DF7
00007871bd3df6e5  movaps xmm11, xmm10
00007871bd3df6e9  addpd xmm11, xmm6
00007871bd3df6ee  vcmppd xmm8, xmm11, xmm11, 0x03
00007871bd3df6f4  ptest xmm8, xmm8
00007871bd3df6fa  jnz 0x00007871BD3E2F3B
00007871bd3df700  movaps xmm10, xmm14
00007871bd3df704  addpd xmm10, xmm4
00007871bd3df709  vcmppd xmm8, xmm10, xmm10, 0x03
00007871bd3df70f  ptest xmm8, xmm8
00007871bd3df715  jnz 0x00007871BD3E307E
00007871bd3df71b  vmovaps xmm14, [rsp+0x40]
00007871bd3df721  vpermilpd xmm14, xmm14, 0x00
00007871bd3df727  movaps xmm8, xmm1
00007871bd3df72b  mulpd xmm8, xmm14
00007871bd3df730  vcmppd xmm6, xmm8, xmm8, 0x03
00007871bd3df736  ptest xmm6, xmm6
00007871bd3df73b  jnz 0x00007871BD3E31C1
00007871bd3df741  movaps xmm1, [r15+0x2B0]
00007871bd3df749  vmovaps xmm14, [rsp+0x40]
00007871bd3df74f  vpermilpd xmm14, xmm14, 0x00
00007871bd3df755  movaps xmm6, xmm1
00007871bd3df758  mulpd xmm6, xmm14
00007871bd3df75d  vcmppd xmm5, xmm6, xmm6, 0x03
00007871bd3df762  ptest xmm5, xmm5
00007871bd3df767  jnz 0x00007871BD3E3304
00007871bd3df76d  vmovaps xmm1, [rsp+0x10]
00007871bd3df773  vpermilpd xmm1, xmm1, 0x00
00007871bd3df779  movaps xmm14, xmm12
00007871bd3df77d  mulpd xmm14, xmm1
00007871bd3df782  vcmppd xmm5, xmm14, xmm14, 0x03
00007871bd3df788  ptest xmm5, xmm5
00007871bd3df78d  jnz 0x00007871BD3E3445
00007871bd3df793  movaps xmm1, xmm13
00007871bd3df797  addpd xmm1, xmm9
00007871bd3df79c  vcmppd xmm12, xmm1, xmm1, 0x03
00007871bd3df7a1  ptest xmm12, xmm12
00007871bd3df7a7  jnz 0x00007871BD3E3588
00007871bd3df7ad  vmovaps xmm13, [rsp+0x10]
00007871bd3df7b3  vpermilpd xmm13, xmm13, 0x00
00007871bd3df7b9  movaps xmm12, xmm7
00007871bd3df7bd  mulpd xmm12, xmm13
00007871bd3df7c2  vcmppd xmm9, xmm12, xmm12, 0x03
00007871bd3df7c8  ptest xmm9, xmm9
00007871bd3df7ce  jnz 0x00007871BD3E36CA
00007871bd3df7d4  movaps xmm13, xmm15
00007871bd3df7d8  addpd xmm13, xmm8
00007871bd3df7dd  vcmppd xmm9, xmm13, xmm13, 0x03
00007871bd3df7e3  ptest xmm9, xmm9
00007871bd3df7e9  jnz 0x00007871BD3E380D
00007871bd3df7ef  movaps xmm15, [r15+0x290]
00007871bd3df7f7  vmovaps xmm9, [rsp+0x10]
00007871bd3df7fd  vpermilpd xmm9, xmm9, 0x00
00007871bd3df803  movaps xmm8, xmm15
00007871bd3df807  mulpd xmm8, xmm9
00007871bd3df80c  vcmppd xmm7, xmm8, xmm8, 0x03
00007871bd3df812  ptest xmm7, xmm7
00007871bd3df817  jnz 0x00007871BD3E3951
00007871bd3df81d  movaps xmm15, xmm11
00007871bd3df821  addpd xmm15, xmm6
00007871bd3df826  vcmppd xmm9, xmm15, xmm15, 0x03
00007871bd3df82c  ptest xmm9, xmm9
00007871bd3df832  jnz 0x00007871BD3E3A95
00007871bd3df838  movaps xmm11, [r15+0x1E0]
00007871bd3df840  vmovaps xmm9, [rsp+0x10]
00007871bd3df846  vpermilpd xmm9, xmm9, 0x00
00007871bd3df84c  movaps xmm7, xmm11
00007871bd3df850  mulpd xmm7, xmm9
00007871bd3df855  vcmppd xmm6, xmm7, xmm7, 0x03
00007871bd3df85a  ptest xmm6, xmm6
00007871bd3df85f  jnz 0x00007871BD3E3BD8
00007871bd3df865  movaps xmm11, xmm10
00007871bd3df869  addpd xmm11, xmm14
00007871bd3df86e  vcmppd xmm9, xmm11, xmm11, 0x03
00007871bd3df874  ptest xmm9, xmm9
00007871bd3df87a  jnz 0x00007871BD3E3D1A
00007871bd3df880  lea r12, [rax+0x70]
00007871bd3df884  movups xmm14, [r13+r12*1]
00007871bd3df88a  movaps [r15+0x240], xmm14
00007871bd3df892  movaps xmm10, xmm1
00007871bd3df896  addpd xmm10, xmm12
00007871bd3df89b  vcmppd xmm9, xmm10, xmm10, 0x03
00007871bd3df8a1  ptest xmm9, xmm9
00007871bd3df8a7  jnz 0x00007871BD3E3E68
00007871bd3df8ad  movaps [r15+0x170], xmm10
00007871bd3df8b5  vmovaps xmm1, [rsp+0x20]
00007871bd3df8bb  vpermilpd xmm1, xmm1, 0x00
00007871bd3df8c1  movaps xmm12, xmm14
00007871bd3df8c5  mulpd xmm12, xmm1
00007871bd3df8ca  vcmppd xmm9, xmm12, xmm12, 0x03
00007871bd3df8d0  ptest xmm9, xmm9
00007871bd3df8d6  jnz 0x00007871BD3E3FAB
00007871bd3df8dc  vmovaps xmm1, [rsp+0x20]
00007871bd3df8e2  vpermilpd xmm1, xmm1, 0x00
00007871bd3df8e8  vmovaps xmm9, [rsp+0xB0]
00007871bd3df8f1  movaps xmm14, xmm9
00007871bd3df8f5  mulpd xmm14, xmm1
00007871bd3df8fa  vcmppd xmm6, xmm14, xmm14, 0x03
00007871bd3df900  ptest xmm6, xmm6
00007871bd3df905  jnz 0x00007871BD3E40EE
00007871bd3df90b  movaps [r15+0x180], xmm14
00007871bd3df913  movaps xmm1, xmm13
00007871bd3df917  addpd xmm1, xmm8
00007871bd3df91c  vcmppd xmm9, xmm1, xmm1, 0x03
00007871bd3df921  ptest xmm9, xmm9
00007871bd3df927  jnz 0x00007871BD3E4231
00007871bd3df92d  movaps [r15+0x210], xmm1
00007871bd3df935  movups xmm13, [r13+rax*1]
00007871bd3df93b  lea r12, [rax+0x10]
00007871bd3df93f  movups xmm9, [r13+r12*1]
00007871bd3df945  movaps [r15+0x230], xmm9
00007871bd3df94d  movaps xmm8, xmm15
00007871bd3df951  addpd xmm8, xmm7
00007871bd3df956  vcmppd xmm6, xmm8, xmm8, 0x03
00007871bd3df95c  ptest xmm6, xmm6
00007871bd3df961  jnz 0x00007871BD3E4387
00007871bd3df967  movaps [r15+0x130], xmm8
00007871bd3df96f  vmovaps xmm15, [rsp+0x20]
00007871bd3df975  vpermilpd xmm15, xmm15, 0x00
00007871bd3df97b  movaps xmm7, xmm9
00007871bd3df97f  mulpd xmm7, xmm15
00007871bd3df984  vcmppd xmm6, xmm7, xmm7, 0x03
00007871bd3df989  ptest xmm6, xmm6
00007871bd3df98e  jnz 0x00007871BD3E44CA
00007871bd3df994  movaps [r15+0x220], xmm7
00007871bd3df99c  vmovaps xmm15, [rsp+0x20]
00007871bd3df9a2  vpermilpd xmm15, xmm15, 0x00
00007871bd3df9a8  movaps xmm9, xmm13
00007871bd3df9ac  mulpd xmm9, xmm15
00007871bd3df9b1  vcmppd xmm6, xmm9, xmm9, 0x03
00007871bd3df9b7  ptest xmm6, xmm6
00007871bd3df9bc  jnz 0x00007871BD3E460C
00007871bd3df9c2  movaps xmm15, xmm11
00007871bd3df9c6  addpd xmm15, xmm12
00007871bd3df9cb  vcmppd xmm13, xmm15, xmm15, 0x03
00007871bd3df9d1  ptest xmm13, xmm13
00007871bd3df9d7  jnz 0x00007871BD3E4750
00007871bd3df9dd  movaps [r15+0x140], xmm15
00007871bd3df9e5  movaps xmm13, xmm10
00007871bd3df9e9  addpd xmm13, xmm14
00007871bd3df9ee  vcmppd xmm12, xmm13, xmm13, 0x03
00007871bd3df9f4  ptest xmm12, xmm12
00007871bd3df9fa  jnz 0x00007871BD3E4894
00007871bd3dfa00  movaps [r15+0x150], xmm13
00007871bd3dfa08  movaps xmm14, xmm1
00007871bd3dfa0c  addpd xmm14, xmm7
00007871bd3dfa11  vcmppd xmm12, xmm14, xmm14, 0x03
00007871bd3dfa17  ptest xmm12, xmm12
00007871bd3dfa1d  jnz 0x00007871BD3E49D8
00007871bd3dfa23  movaps [r15+0x160], xmm14
00007871bd3dfa2b  movaps xmm1, xmm8
00007871bd3dfa2f  addpd xmm1, xmm9
00007871bd3dfa34  vcmppd xmm12, xmm1, xmm1, 0x03
00007871bd3dfa39  ptest xmm12, xmm12
00007871bd3dfa3f  jnz 0x00007871BD3E4B1A
00007871bd3dfa45  movaps [r15+0x120], xmm1
00007871bd3dfa4d  movups [r13+r14*1], xmm15
00007871bd3dfa53  lea rax, [r14+0x10]
00007871bd3dfa57  movups [r13+rax*1], xmm13
00007871bd3dfa5d  lea rax, [r14+0x20]
00007871bd3dfa61  movups [r13+rax*1], xmm14
00007871bd3dfa67  lea rax, [r14+0x30]
00007871bd3dfa6b  movups [r13+rax*1], xmm1
00007871bd3dfa71  mov eax, [r15+0x108]
00007871bd3dfa78  sahf
00007871bd3dfa79  jnz 0x00007871BD3DFAAB
00007871bd3dfa7b  cmp dword ptr [r15+0x318], 0x00
00007871bd3dfa83  jz 0x00007871BD3DEAE0
00007871bd3dfa89  nop [rax+rax*1], ax
00007871bd3dfa92  nop [rax+rax*1], eax
00007871bd3dfa9a  mov eax, 0x4106D0
00007871bd3dfa9f  mov [r15+0x100], rax
00007871bd3dfaa6  jmp 0x00007871BD1FE110
00007871bd3dfaab  cmp dword ptr [r15+0x318], 0x00
00007871bd3dfab3  jz 0x00007871BD3D89C0
00007871bd3dfab9  nop [rax+rax*1], ax
00007871bd3dfac2  nop [rax+rax*1], eax
00007871bd3dfaca  mov eax, 0x410504
00007871bd3dfacf  mov [r15+0x100], rax
00007871bd3dfad6  jmp 0x00007871BD1FE110
00007871bd3dfadb  int3
00007871bd3dfadc  call 0x00007871BD2E27E0
00007871bd3dfae1  jmp 0x00007871BD3DEBBF
00007871bd3dfae6  call 0x00007871BD2E1570
00007871bd3dfaeb  jmp 0x00007871BD3DEBC8
00007871bd3dfaf0  call 0x00007871BD2E27E0
00007871bd3dfaf5  jmp 0x00007871BD3DEC24
00007871bd3dfafa  call 0x00007871BD2E1570
00007871bd3dfaff  jmp 0x00007871BD3DEC2D
00007871bd3dfb04  call 0x00007871BD2E27E0
00007871bd3dfb09  jmp 0x00007871BD3DEC70
00007871bd3dfb0e  call 0x00007871BD2E1570
00007871bd3dfb13  jmp 0x00007871BD3DEC79
00007871bd3dfb18  call 0x00007871BD20DC20
00007871bd3dfb1d  jmp 0x00007871BD3DECB8
00007871bd3dfb22  call 0x00007871BD2D59C0
00007871bd3dfb27  jmp 0x00007871BD3DECCB
00007871bd3dfb2c  call 0x00007871BD2E0E30
00007871bd3dfb31  jmp 0x00007871BD3DECE9
00007871bd3dfb36  call 0x00007871BD2DFBC0
00007871bd3dfb3b  jmp 0x00007871BD3DECF3
00007871bd3dfb40  call 0x00007871BD2DE950
00007871bd3dfb45  jmp 0x00007871BD3DECFD
00007871bd3dfb4a  sub rsp, 0x08
00007871bd3dfb4e  push rax
00007871bd3dfb4f  push rcx
00007871bd3dfb50  push rdx
00007871bd3dfb51  push rdi
00007871bd3dfb52  push rsi
00007871bd3dfb53  push r8
00007871bd3dfb55  push r9
00007871bd3dfb57  push r10
00007871bd3dfb59  push r11
00007871bd3dfb5b  sub rsp, 0xF0
00007871bd3dfb62  vmovaps [rsp], xmm0
00007871bd3dfb67  vmovaps [rsp+0x10], xmm1
00007871bd3dfb6d  vmovaps [rsp+0x20], xmm2
00007871bd3dfb73  vmovaps [rsp+0x30], xmm3
00007871bd3dfb79  vmovaps [rsp+0x40], xmm4
00007871bd3dfb7f  vmovaps [rsp+0x50], xmm5
00007871bd3dfb85  vmovaps [rsp+0x60], xmm6
00007871bd3dfb8b  vmovaps [rsp+0x70], xmm7
00007871bd3dfb91  vmovaps [rsp+0x80], xmm9
00007871bd3dfb9a  vmovaps [rsp+0x90], xmm10
00007871bd3dfba3  vmovaps [rsp+0xA0], xmm11
00007871bd3dfbac  vmovaps [rsp+0xB0], xmm12
00007871bd3dfbb5  vmovaps [rsp+0xC0], xmm13
00007871bd3dfbbe  vmovaps [rsp+0xD0], xmm14
00007871bd3dfbc7  vmovaps [rsp+0xE0], xmm15
00007871bd3dfbd0  sub rsp, 0x30
00007871bd3dfbd4  movaps [rsp], xmm8
00007871bd3dfbd9  movaps [rsp+0x10], xmm12
00007871bd3dfbdf  movaps [rsp+0x20], xmm15
00007871bd3dfbe5  lea rdi, [rsp]
00007871bd3dfbe9  mov esi, 0x00
00007871bd3dfbee  mov rax, 0x5BA2FDD2A530
00007871bd3dfbf8  call rax
00007871bd3dfbfa  movaps xmm8, [rsp]
00007871bd3dfbff  add rsp, 0x30
00007871bd3dfc03  vmovaps xmm0, [rsp]
00007871bd3dfc08  vmovaps xmm1, [rsp+0x10]
00007871bd3dfc0e  vmovaps xmm2, [rsp+0x20]
00007871bd3dfc14  vmovaps xmm3, [rsp+0x30]
00007871bd3dfc1a  vmovaps xmm4, [rsp+0x40]
00007871bd3dfc20  vmovaps xmm5, [rsp+0x50]
00007871bd3dfc26  vmovaps xmm6, [rsp+0x60]
00007871bd3dfc2c  vmovaps xmm7, [rsp+0x70]
00007871bd3dfc32  vmovaps xmm9, [rsp+0x80]
00007871bd3dfc3b  vmovaps xmm10, [rsp+0x90]
00007871bd3dfc44  vmovaps xmm11, [rsp+0xA0]
00007871bd3dfc4d  vmovaps xmm12, [rsp+0xB0]
00007871bd3dfc56  vmovaps xmm13, [rsp+0xC0]
00007871bd3dfc5f  vmovaps xmm14, [rsp+0xD0]
00007871bd3dfc68  vmovaps xmm15, [rsp+0xE0]
00007871bd3dfc71  add rsp, 0xF0
00007871bd3dfc78  pop r11
00007871bd3dfc7a  pop r10
00007871bd3dfc7c  pop r9
00007871bd3dfc7e  pop r8
00007871bd3dfc80  pop rsi
00007871bd3dfc81  pop rdi
00007871bd3dfc82  pop rdx
00007871bd3dfc83  pop rcx
00007871bd3dfc84  pop rax
00007871bd3dfc85  add rsp, 0x08
00007871bd3dfc89  jmp 0x00007871BD3DED27
00007871bd3dfc8e  sub rsp, 0x08
00007871bd3dfc92  push rax
00007871bd3dfc93  push rcx
00007871bd3dfc94  push rdx
00007871bd3dfc95  push rdi
00007871bd3dfc96  push rsi
00007871bd3dfc97  push r8
00007871bd3dfc99  push r9
00007871bd3dfc9b  push r10
00007871bd3dfc9d  push r11
00007871bd3dfc9f  sub rsp, 0xF0
00007871bd3dfca6  vmovaps [rsp], xmm0
00007871bd3dfcab  vmovaps [rsp+0x10], xmm1
00007871bd3dfcb1  vmovaps [rsp+0x20], xmm2
00007871bd3dfcb7  vmovaps [rsp+0x30], xmm3
00007871bd3dfcbd  vmovaps [rsp+0x40], xmm4
00007871bd3dfcc3  vmovaps [rsp+0x50], xmm5
00007871bd3dfcc9  vmovaps [rsp+0x60], xmm6
00007871bd3dfccf  vmovaps [rsp+0x70], xmm8
00007871bd3dfcd5  vmovaps [rsp+0x80], xmm9
00007871bd3dfcde  vmovaps [rsp+0x90], xmm10
00007871bd3dfce7  vmovaps [rsp+0xA0], xmm11
00007871bd3dfcf0  vmovaps [rsp+0xB0], xmm12
00007871bd3dfcf9  vmovaps [rsp+0xC0], xmm13
00007871bd3dfd02  vmovaps [rsp+0xD0], xmm14
00007871bd3dfd0b  vmovaps [rsp+0xE0], xmm15
00007871bd3dfd14  sub rsp, 0x30
00007871bd3dfd18  movaps [rsp], xmm7
00007871bd3dfd1c  movaps [rsp+0x10], xmm9
00007871bd3dfd22  movaps [rsp+0x20], xmm15
00007871bd3dfd28  lea rdi, [rsp]
00007871bd3dfd2c  mov esi, 0x00
00007871bd3dfd31  mov rax, 0x5BA2FDD2A530
00007871bd3dfd3b  call rax
00007871bd3dfd3d  movaps xmm7, [rsp]
00007871bd3dfd41  add rsp, 0x30
00007871bd3dfd45  vmovaps xmm0, [rsp]
00007871bd3dfd4a  vmovaps xmm1, [rsp+0x10]
00007871bd3dfd50  vmovaps xmm2, [rsp+0x20]
00007871bd3dfd56  vmovaps xmm3, [rsp+0x30]
00007871bd3dfd5c  vmovaps xmm4, [rsp+0x40]
00007871bd3dfd62  vmovaps xmm5, [rsp+0x50]
00007871bd3dfd68  vmovaps xmm6, [rsp+0x60]
00007871bd3dfd6e  vmovaps xmm8, [rsp+0x70]
00007871bd3dfd74  vmovaps xmm9, [rsp+0x80]
00007871bd3dfd7d  vmovaps xmm10, [rsp+0x90]
00007871bd3dfd86  vmovaps xmm11, [rsp+0xA0]
00007871bd3dfd8f  vmovaps xmm12, [rsp+0xB0]
00007871bd3dfd98  vmovaps xmm13, [rsp+0xC0]
00007871bd3dfda1  vmovaps xmm14, [rsp+0xD0]
00007871bd3dfdaa  vmovaps xmm15, [rsp+0xE0]
00007871bd3dfdb3  add rsp, 0xF0
00007871bd3dfdba  pop r11
00007871bd3dfdbc  pop r10
00007871bd3dfdbe  pop r9
00007871bd3dfdc0  pop r8
00007871bd3dfdc2  pop rsi
00007871bd3dfdc3  pop rdi
00007871bd3dfdc4  pop rdx
00007871bd3dfdc5  pop rcx
00007871bd3dfdc6  pop rax
00007871bd3dfdc7  add rsp, 0x08
00007871bd3dfdcb  jmp 0x00007871BD3DED55
00007871bd3dfdd0  sub rsp, 0x08
00007871bd3dfdd4  push rax
00007871bd3dfdd5  push rcx
00007871bd3dfdd6  push rdx
00007871bd3dfdd7  push rdi
00007871bd3dfdd8  push rsi
00007871bd3dfdd9  push r8
00007871bd3dfddb  push r9
00007871bd3dfddd  push r10
00007871bd3dfddf  push r11
00007871bd3dfde1  sub rsp, 0xF0
00007871bd3dfde8  vmovaps [rsp], xmm0
00007871bd3dfded  vmovaps [rsp+0x10], xmm1
00007871bd3dfdf3  vmovaps [rsp+0x20], xmm2
00007871bd3dfdf9  vmovaps [rsp+0x30], xmm3
00007871bd3dfdff  vmovaps [rsp+0x40], xmm4
00007871bd3dfe05  vmovaps [rsp+0x50], xmm5
00007871bd3dfe0b  vmovaps [rsp+0x60], xmm6
00007871bd3dfe11  vmovaps [rsp+0x70], xmm7
00007871bd3dfe17  vmovaps [rsp+0x80], xmm8
00007871bd3dfe20  vmovaps [rsp+0x90], xmm10
00007871bd3dfe29  vmovaps [rsp+0xA0], xmm11
00007871bd3dfe32  vmovaps [rsp+0xB0], xmm12
00007871bd3dfe3b  vmovaps [rsp+0xC0], xmm13
00007871bd3dfe44  vmovaps [rsp+0xD0], xmm14
00007871bd3dfe4d  vmovaps [rsp+0xE0], xmm15
00007871bd3dfe56  sub rsp, 0x30
00007871bd3dfe5a  movaps [rsp], xmm9
00007871bd3dfe5f  movaps [rsp+0x10], xmm12
00007871bd3dfe65  movaps [rsp+0x20], xmm10
00007871bd3dfe6b  lea rdi, [rsp]
00007871bd3dfe6f  mov esi, 0x00
00007871bd3dfe74  mov rax, 0x5BA2FDD2A530
00007871bd3dfe7e  call rax
00007871bd3dfe80  movaps xmm9, [rsp]
00007871bd3dfe85  add rsp, 0x30
00007871bd3dfe89  vmovaps xmm0, [rsp]
00007871bd3dfe8e  vmovaps xmm1, [rsp+0x10]
00007871bd3dfe94  vmovaps xmm2, [rsp+0x20]
00007871bd3dfe9a  vmovaps xmm3, [rsp+0x30]
00007871bd3dfea0  vmovaps xmm4, [rsp+0x40]
00007871bd3dfea6  vmovaps xmm5, [rsp+0x50]
00007871bd3dfeac  vmovaps xmm6, [rsp+0x60]
00007871bd3dfeb2  vmovaps xmm7, [rsp+0x70]
00007871bd3dfeb8  vmovaps xmm8, [rsp+0x80]
00007871bd3dfec1  vmovaps xmm10, [rsp+0x90]
00007871bd3dfeca  vmovaps xmm11, [rsp+0xA0]
00007871bd3dfed3  vmovaps xmm12, [rsp+0xB0]
00007871bd3dfedc  vmovaps xmm13, [rsp+0xC0]
00007871bd3dfee5  vmovaps xmm14, [rsp+0xD0]
00007871bd3dfeee  vmovaps xmm15, [rsp+0xE0]
00007871bd3dfef7  add rsp, 0xF0
00007871bd3dfefe  pop r11
00007871bd3dff00  pop r10
00007871bd3dff02  pop r9
00007871bd3dff04  pop r8
00007871bd3dff06  pop rsi
00007871bd3dff07  pop rdi
00007871bd3dff08  pop rdx
00007871bd3dff09  pop rcx
00007871bd3dff0a  pop rax
00007871bd3dff0b  add rsp, 0x08
00007871bd3dff0f  jmp 0x00007871BD3DED79
00007871bd3dff14  sub rsp, 0x08
00007871bd3dff18  push rax
00007871bd3dff19  push rcx
00007871bd3dff1a  push rdx
00007871bd3dff1b  push rdi
00007871bd3dff1c  push rsi
00007871bd3dff1d  push r8
00007871bd3dff1f  push r9
00007871bd3dff21  push r10
00007871bd3dff23  push r11
00007871bd3dff25  sub rsp, 0xF0
00007871bd3dff2c  vmovaps [rsp], xmm0
00007871bd3dff31  vmovaps [rsp+0x10], xmm1
00007871bd3dff37  vmovaps [rsp+0x20], xmm2
00007871bd3dff3d  vmovaps [rsp+0x30], xmm3
00007871bd3dff43  vmovaps [rsp+0x40], xmm4
00007871bd3dff49  vmovaps [rsp+0x50], xmm5
00007871bd3dff4f  vmovaps [rsp+0x60], xmm6
00007871bd3dff55  vmovaps [rsp+0x70], xmm7
00007871bd3dff5b  vmovaps [rsp+0x80], xmm8
00007871bd3dff64  vmovaps [rsp+0x90], xmm9
00007871bd3dff6d  vmovaps [rsp+0xA0], xmm11
00007871bd3dff76  vmovaps [rsp+0xB0], xmm12
00007871bd3dff7f  vmovaps [rsp+0xC0], xmm13
00007871bd3dff88  vmovaps [rsp+0xD0], xmm14
00007871bd3dff91  vmovaps [rsp+0xE0], xmm15
00007871bd3dff9a  sub rsp, 0x30
00007871bd3dff9e  movaps [rsp], xmm10
00007871bd3dffa3  movaps [rsp+0x10], xmm12
00007871bd3dffa9  movaps [rsp+0x20], xmm11
00007871bd3dffaf  lea rdi, [rsp]
00007871bd3dffb3  mov esi, 0x00
00007871bd3dffb8  mov rax, 0x5BA2FDD2A530
00007871bd3dffc2  call rax
00007871bd3dffc4  movaps xmm10, [rsp]
00007871bd3dffc9  add rsp, 0x30
00007871bd3dffcd  vmovaps xmm0, [rsp]
00007871bd3dffd2  vmovaps xmm1, [rsp+0x10]
00007871bd3dffd8  vmovaps xmm2, [rsp+0x20]
00007871bd3dffde  vmovaps xmm3, [rsp+0x30]
00007871bd3dffe4  vmovaps xmm4, [rsp+0x40]
00007871bd3dffea  vmovaps xmm5, [rsp+0x50]
00007871bd3dfff0  vmovaps xmm6, [rsp+0x60]
00007871bd3dfff6  vmovaps xmm7, [rsp+0x70]
00007871bd3dfffc  vmovaps xmm8, [rsp+0x80]
00007871bd3e0005  vmovaps xmm9, [rsp+0x90]
00007871bd3e000e  vmovaps xmm11, [rsp+0xA0]
00007871bd3e0017  vmovaps xmm12, [rsp+0xB0]
00007871bd3e0020  vmovaps xmm13, [rsp+0xC0]
00007871bd3e0029  vmovaps xmm14, [rsp+0xD0]
00007871bd3e0032  vmovaps xmm15, [rsp+0xE0]
00007871bd3e003b  add rsp, 0xF0
00007871bd3e0042  pop r11
00007871bd3e0044  pop r10
00007871bd3e0046  pop r9
00007871bd3e0048  pop r8
00007871bd3e004a  pop rsi
00007871bd3e004b  pop rdi
00007871bd3e004c  pop rdx
00007871bd3e004d  pop rcx
00007871bd3e004e  pop rax
00007871bd3e004f  add rsp, 0x08
00007871bd3e0053  jmp 0x00007871BD3DED93
00007871bd3e0058  sub rsp, 0x08
00007871bd3e005c  push rax
00007871bd3e005d  push rcx
00007871bd3e005e  push rdx
00007871bd3e005f  push rdi
00007871bd3e0060  push rsi
00007871bd3e0061  push r8
00007871bd3e0063  push r9
00007871bd3e0065  push r10
00007871bd3e0067  push r11
00007871bd3e0069  sub rsp, 0xF0
00007871bd3e0070  vmovaps [rsp], xmm0
00007871bd3e0075  vmovaps [rsp+0x10], xmm1
00007871bd3e007b  vmovaps [rsp+0x20], xmm2
00007871bd3e0081  vmovaps [rsp+0x30], xmm3
00007871bd3e0087  vmovaps [rsp+0x40], xmm4
00007871bd3e008d  vmovaps [rsp+0x50], xmm5
00007871bd3e0093  vmovaps [rsp+0x60], xmm7
00007871bd3e0099  vmovaps [rsp+0x70], xmm8
00007871bd3e009f  vmovaps [rsp+0x80], xmm9
00007871bd3e00a8  vmovaps [rsp+0x90], xmm10
00007871bd3e00b1  vmovaps [rsp+0xA0], xmm11
00007871bd3e00ba  vmovaps [rsp+0xB0], xmm12
00007871bd3e00c3  vmovaps [rsp+0xC0], xmm13
00007871bd3e00cc  vmovaps [rsp+0xD0], xmm14
00007871bd3e00d5  vmovaps [rsp+0xE0], xmm15
00007871bd3e00de  sub rsp, 0x30
00007871bd3e00e2  movaps [rsp], xmm6
00007871bd3e00e6  movaps [rsp+0x10], xmm12
00007871bd3e00ec  movaps [rsp+0x20], xmm11
00007871bd3e00f2  lea rdi, [rsp]
00007871bd3e00f6  mov esi, 0x00
00007871bd3e00fb  mov rax, 0x5BA2FDD2A530
00007871bd3e0105  call rax
00007871bd3e0107  movaps xmm6, [rsp]
00007871bd3e010b  add rsp, 0x30
00007871bd3e010f  vmovaps xmm0, [rsp]
00007871bd3e0114  vmovaps xmm1, [rsp+0x10]
00007871bd3e011a  vmovaps xmm2, [rsp+0x20]
00007871bd3e0120  vmovaps xmm3, [rsp+0x30]
00007871bd3e0126  vmovaps xmm4, [rsp+0x40]
00007871bd3e012c  vmovaps xmm5, [rsp+0x50]
00007871bd3e0132  vmovaps xmm7, [rsp+0x60]
00007871bd3e0138  vmovaps xmm8, [rsp+0x70]
00007871bd3e013e  vmovaps xmm9, [rsp+0x80]
00007871bd3e0147  vmovaps xmm10, [rsp+0x90]
00007871bd3e0150  vmovaps xmm11, [rsp+0xA0]
00007871bd3e0159  vmovaps xmm12, [rsp+0xB0]
00007871bd3e0162  vmovaps xmm13, [rsp+0xC0]
00007871bd3e016b  vmovaps xmm14, [rsp+0xD0]
00007871bd3e0174  vmovaps xmm15, [rsp+0xE0]
00007871bd3e017d  add rsp, 0xF0
00007871bd3e0184  pop r11
00007871bd3e0186  pop r10
00007871bd3e0188  pop r9
00007871bd3e018a  pop r8
00007871bd3e018c  pop rsi
00007871bd3e018d  pop rdi
00007871bd3e018e  pop rdx
00007871bd3e018f  pop rcx
00007871bd3e0190  pop rax
00007871bd3e0191  add rsp, 0x08
00007871bd3e0195  jmp 0x00007871BD3DEDB4
00007871bd3e019a  sub rsp, 0x08
00007871bd3e019e  push rax
00007871bd3e019f  push rcx
00007871bd3e01a0  push rdx
00007871bd3e01a1  push rdi
00007871bd3e01a2  push rsi
00007871bd3e01a3  push r8
00007871bd3e01a5  push r9
00007871bd3e01a7  push r10
00007871bd3e01a9  push r11
00007871bd3e01ab  sub rsp, 0xF0
00007871bd3e01b2  vmovaps [rsp], xmm0
00007871bd3e01b7  vmovaps [rsp+0x10], xmm1
00007871bd3e01bd  vmovaps [rsp+0x20], xmm2
00007871bd3e01c3  vmovaps [rsp+0x30], xmm4
00007871bd3e01c9  vmovaps [rsp+0x40], xmm5
00007871bd3e01cf  vmovaps [rsp+0x50], xmm6
00007871bd3e01d5  vmovaps [rsp+0x60], xmm7
00007871bd3e01db  vmovaps [rsp+0x70], xmm8
00007871bd3e01e1  vmovaps [rsp+0x80], xmm9
00007871bd3e01ea  vmovaps [rsp+0x90], xmm10
00007871bd3e01f3  vmovaps [rsp+0xA0], xmm11
00007871bd3e01fc  vmovaps [rsp+0xB0], xmm12
00007871bd3e0205  vmovaps [rsp+0xC0], xmm13
00007871bd3e020e  vmovaps [rsp+0xD0], xmm14
00007871bd3e0217  vmovaps [rsp+0xE0], xmm15
00007871bd3e0220  sub rsp, 0x30
00007871bd3e0224  movaps [rsp], xmm3
00007871bd3e0228  movaps [rsp+0x10], xmm5
00007871bd3e022d  movaps [rsp+0x20], xmm4
00007871bd3e0232  lea rdi, [rsp]
00007871bd3e0236  mov esi, 0x00
00007871bd3e023b  mov rax, 0x5BA2FDD2A530
00007871bd3e0245  call rax
00007871bd3e0247  movaps xmm3, [rsp]
00007871bd3e024b  add rsp, 0x30
00007871bd3e024f  vmovaps xmm0, [rsp]
00007871bd3e0254  vmovaps xmm1, [rsp+0x10]
00007871bd3e025a  vmovaps xmm2, [rsp+0x20]
00007871bd3e0260  vmovaps xmm4, [rsp+0x30]
00007871bd3e0266  vmovaps xmm5, [rsp+0x40]
00007871bd3e026c  vmovaps xmm6, [rsp+0x50]
00007871bd3e0272  vmovaps xmm7, [rsp+0x60]
00007871bd3e0278  vmovaps xmm8, [rsp+0x70]
00007871bd3e027e  vmovaps xmm9, [rsp+0x80]
00007871bd3e0287  vmovaps xmm10, [rsp+0x90]
00007871bd3e0290  vmovaps xmm11, [rsp+0xA0]
00007871bd3e0299  vmovaps xmm12, [rsp+0xB0]
00007871bd3e02a2  vmovaps xmm13, [rsp+0xC0]
00007871bd3e02ab  vmovaps xmm14, [rsp+0xD0]
00007871bd3e02b4  vmovaps xmm15, [rsp+0xE0]
00007871bd3e02bd  add rsp, 0xF0
00007871bd3e02c4  pop r11
00007871bd3e02c6  pop r10
00007871bd3e02c8  pop r9
00007871bd3e02ca  pop r8
00007871bd3e02cc  pop rsi
00007871bd3e02cd  pop rdi
00007871bd3e02ce  pop rdx
00007871bd3e02cf  pop rcx
00007871bd3e02d0  pop rax
00007871bd3e02d1  add rsp, 0x08
00007871bd3e02d5  jmp 0x00007871BD3DEE15
00007871bd3e02da  sub rsp, 0x08
00007871bd3e02de  push rax
00007871bd3e02df  push rcx
00007871bd3e02e0  push rdx
00007871bd3e02e1  push rdi
00007871bd3e02e2  push rsi
00007871bd3e02e3  push r8
00007871bd3e02e5  push r9
00007871bd3e02e7  push r10
00007871bd3e02e9  push r11
00007871bd3e02eb  sub rsp, 0xF0
00007871bd3e02f2  vmovaps [rsp], xmm0
00007871bd3e02f7  vmovaps [rsp+0x10], xmm1
00007871bd3e02fd  vmovaps [rsp+0x20], xmm2
00007871bd3e0303  vmovaps [rsp+0x30], xmm3
00007871bd3e0309  vmovaps [rsp+0x40], xmm4
00007871bd3e030f  vmovaps [rsp+0x50], xmm6
00007871bd3e0315  vmovaps [rsp+0x60], xmm7
00007871bd3e031b  vmovaps [rsp+0x70], xmm8
00007871bd3e0321  vmovaps [rsp+0x80], xmm9
00007871bd3e032a  vmovaps [rsp+0x90], xmm10
00007871bd3e0333  vmovaps [rsp+0xA0], xmm11
00007871bd3e033c  vmovaps [rsp+0xB0], xmm12
00007871bd3e0345  vmovaps [rsp+0xC0], xmm13
00007871bd3e034e  vmovaps [rsp+0xD0], xmm14
00007871bd3e0357  vmovaps [rsp+0xE0], xmm15
00007871bd3e0360  sub rsp, 0x30
00007871bd3e0364  movaps [rsp], xmm5
00007871bd3e0368  movaps [rsp+0x10], xmm8
00007871bd3e036e  movaps [rsp+0x20], xmm15
00007871bd3e0374  lea rdi, [rsp]
00007871bd3e0378  mov esi, 0x00
00007871bd3e037d  mov rax, 0x5BA2FDD2A530
00007871bd3e0387  call rax
00007871bd3e0389  movaps xmm5, [rsp]
00007871bd3e038d  add rsp, 0x30
00007871bd3e0391  vmovaps xmm0, [rsp]
00007871bd3e0396  vmovaps xmm1, [rsp+0x10]
00007871bd3e039c  vmovaps xmm2, [rsp+0x20]
00007871bd3e03a2  vmovaps xmm3, [rsp+0x30]
00007871bd3e03a8  vmovaps xmm4, [rsp+0x40]
00007871bd3e03ae  vmovaps xmm6, [rsp+0x50]
00007871bd3e03b4  vmovaps xmm7, [rsp+0x60]
00007871bd3e03ba  vmovaps xmm8, [rsp+0x70]
00007871bd3e03c0  vmovaps xmm9, [rsp+0x80]
00007871bd3e03c9  vmovaps xmm10, [rsp+0x90]
00007871bd3e03d2  vmovaps xmm11, [rsp+0xA0]
00007871bd3e03db  vmovaps xmm12, [rsp+0xB0]
00007871bd3e03e4  vmovaps xmm13, [rsp+0xC0]
00007871bd3e03ed  vmovaps xmm14, [rsp+0xD0]
00007871bd3e03f6  vmovaps xmm15, [rsp+0xE0]
00007871bd3e03ff  add rsp, 0xF0
00007871bd3e0406  pop r11
00007871bd3e0408  pop r10
00007871bd3e040a  pop r9
00007871bd3e040c  pop r8
00007871bd3e040e  pop rsi
00007871bd3e040f  pop rdi
00007871bd3e0410  pop rdx
00007871bd3e0411  pop rcx
00007871bd3e0412  pop rax
00007871bd3e0413  add rsp, 0x08
00007871bd3e0417  jmp 0x00007871BD3DEE53
00007871bd3e041c  sub rsp, 0x08
00007871bd3e0420  push rax
00007871bd3e0421  push rcx
00007871bd3e0422  push rdx
00007871bd3e0423  push rdi
00007871bd3e0424  push rsi
00007871bd3e0425  push r8
00007871bd3e0427  push r9
00007871bd3e0429  push r10
00007871bd3e042b  push r11
00007871bd3e042d  sub rsp, 0xF0
00007871bd3e0434  vmovaps [rsp], xmm0
00007871bd3e0439  vmovaps [rsp+0x10], xmm1
00007871bd3e043f  vmovaps [rsp+0x20], xmm2
00007871bd3e0445  vmovaps [rsp+0x30], xmm3
00007871bd3e044b  vmovaps [rsp+0x40], xmm5
00007871bd3e0451  vmovaps [rsp+0x50], xmm6
00007871bd3e0457  vmovaps [rsp+0x60], xmm7
00007871bd3e045d  vmovaps [rsp+0x70], xmm8
00007871bd3e0463  vmovaps [rsp+0x80], xmm9
00007871bd3e046c  vmovaps [rsp+0x90], xmm10
00007871bd3e0475  vmovaps [rsp+0xA0], xmm11
00007871bd3e047e  vmovaps [rsp+0xB0], xmm12
00007871bd3e0487  vmovaps [rsp+0xC0], xmm13
00007871bd3e0490  vmovaps [rsp+0xD0], xmm14
00007871bd3e0499  vmovaps [rsp+0xE0], xmm15
00007871bd3e04a2  sub rsp, 0x30
00007871bd3e04a6  movaps [rsp], xmm4
00007871bd3e04aa  movaps [rsp+0x10], xmm9
00007871bd3e04b0  movaps [rsp+0x20], xmm8
00007871bd3e04b6  lea rdi, [rsp]
00007871bd3e04ba  mov esi, 0x00
00007871bd3e04bf  mov rax, 0x5BA2FDD2A530
00007871bd3e04c9  call rax
00007871bd3e04cb  movaps xmm4, [rsp]
00007871bd3e04cf  add rsp, 0x30
00007871bd3e04d3  vmovaps xmm0, [rsp]
00007871bd3e04d8  vmovaps xmm1, [rsp+0x10]
00007871bd3e04de  vmovaps xmm2, [rsp+0x20]
00007871bd3e04e4  vmovaps xmm3, [rsp+0x30]
00007871bd3e04ea  vmovaps xmm5, [rsp+0x40]
00007871bd3e04f0  vmovaps xmm6, [rsp+0x50]
00007871bd3e04f6  vmovaps xmm7, [rsp+0x60]
00007871bd3e04fc  vmovaps xmm8, [rsp+0x70]
00007871bd3e0502  vmovaps xmm9, [rsp+0x80]
00007871bd3e050b  vmovaps xmm10, [rsp+0x90]
00007871bd3e0514  vmovaps xmm11, [rsp+0xA0]
00007871bd3e051d  vmovaps xmm12, [rsp+0xB0]
00007871bd3e0526  vmovaps xmm13, [rsp+0xC0]
00007871bd3e052f  vmovaps xmm14, [rsp+0xD0]
00007871bd3e0538  vmovaps xmm15, [rsp+0xE0]
00007871bd3e0541  add rsp, 0xF0
00007871bd3e0548  pop r11
00007871bd3e054a  pop r10
00007871bd3e054c  pop r9
00007871bd3e054e  pop r8
00007871bd3e0550  pop rsi
00007871bd3e0551  pop rdi
00007871bd3e0552  pop rdx
00007871bd3e0553  pop rcx
00007871bd3e0554  pop rax
00007871bd3e0555  add rsp, 0x08
00007871bd3e0559  jmp 0x00007871BD3DEE74
00007871bd3e055e  sub rsp, 0x08
00007871bd3e0562  push rax
00007871bd3e0563  push rcx
00007871bd3e0564  push rdx
00007871bd3e0565  push rdi
00007871bd3e0566  push rsi
00007871bd3e0567  push r8
00007871bd3e0569  push r9
00007871bd3e056b  push r10
00007871bd3e056d  push r11
00007871bd3e056f  sub rsp, 0xF0
00007871bd3e0576  vmovaps [rsp], xmm0
00007871bd3e057b  vmovaps [rsp+0x10], xmm1
00007871bd3e0581  vmovaps [rsp+0x20], xmm2
00007871bd3e0587  vmovaps [rsp+0x30], xmm3
00007871bd3e058d  vmovaps [rsp+0x40], xmm4
00007871bd3e0593  vmovaps [rsp+0x50], xmm5
00007871bd3e0599  vmovaps [rsp+0x60], xmm6
00007871bd3e059f  vmovaps [rsp+0x70], xmm7
00007871bd3e05a5  vmovaps [rsp+0x80], xmm8
00007871bd3e05ae  vmovaps [rsp+0x90], xmm10
00007871bd3e05b7  vmovaps [rsp+0xA0], xmm11
00007871bd3e05c0  vmovaps [rsp+0xB0], xmm12
00007871bd3e05c9  vmovaps [rsp+0xC0], xmm13
00007871bd3e05d2  vmovaps [rsp+0xD0], xmm14
00007871bd3e05db  vmovaps [rsp+0xE0], xmm15
00007871bd3e05e4  sub rsp, 0x30
00007871bd3e05e8  movaps [rsp], xmm9
00007871bd3e05ed  movaps [rsp+0x10], xmm10
00007871bd3e05f3  movaps [rsp+0x20], xmm8
00007871bd3e05f9  lea rdi, [rsp]
00007871bd3e05fd  mov esi, 0x00
00007871bd3e0602  mov rax, 0x5BA2FDD2A530
00007871bd3e060c  call rax
00007871bd3e060e  movaps xmm9, [rsp]
00007871bd3e0613  add rsp, 0x30
00007871bd3e0617  vmovaps xmm0, [rsp]
00007871bd3e061c  vmovaps xmm1, [rsp+0x10]
00007871bd3e0622  vmovaps xmm2, [rsp+0x20]
00007871bd3e0628  vmovaps xmm3, [rsp+0x30]
00007871bd3e062e  vmovaps xmm4, [rsp+0x40]
00007871bd3e0634  vmovaps xmm5, [rsp+0x50]
00007871bd3e063a  vmovaps xmm6, [rsp+0x60]
00007871bd3e0640  vmovaps xmm7, [rsp+0x70]
00007871bd3e0646  vmovaps xmm8, [rsp+0x80]
00007871bd3e064f  vmovaps xmm10, [rsp+0x90]
00007871bd3e0658  vmovaps xmm11, [rsp+0xA0]
00007871bd3e0661  vmovaps xmm12, [rsp+0xB0]
00007871bd3e066a  vmovaps xmm13, [rsp+0xC0]
00007871bd3e0673  vmovaps xmm14, [rsp+0xD0]
00007871bd3e067c  vmovaps xmm15, [rsp+0xE0]
00007871bd3e0685  add rsp, 0xF0
00007871bd3e068c  pop r11
00007871bd3e068e  pop r10
00007871bd3e0690  pop r9
00007871bd3e0692  pop r8
00007871bd3e0694  pop rsi
00007871bd3e0695  pop rdi
00007871bd3e0696  pop rdx
00007871bd3e0697  pop rcx
00007871bd3e0698  pop rax
00007871bd3e0699  add rsp, 0x08
00007871bd3e069d  jmp 0x00007871BD3DEE8E
00007871bd3e06a2  call 0x00007871BD2B52F0
00007871bd3e06a7  jmp 0x00007871BD3DEFA8
00007871bd3e06ac  call 0x00007871BD2B52F0
00007871bd3e06b1  jmp 0x00007871BD3DEFBE
00007871bd3e06b6  sub rsp, 0x08
00007871bd3e06ba  push rax
00007871bd3e06bb  push rcx
00007871bd3e06bc  push rdx
00007871bd3e06bd  push rdi
00007871bd3e06be  push rsi
00007871bd3e06bf  push r8
00007871bd3e06c1  push r9
00007871bd3e06c3  push r10
00007871bd3e06c5  push r11
00007871bd3e06c7  sub rsp, 0xF0
00007871bd3e06ce  vmovaps [rsp], xmm0
00007871bd3e06d3  vmovaps [rsp+0x10], xmm2
00007871bd3e06d9  vmovaps [rsp+0x20], xmm3
00007871bd3e06df  vmovaps [rsp+0x30], xmm4
00007871bd3e06e5  vmovaps [rsp+0x40], xmm5
00007871bd3e06eb  vmovaps [rsp+0x50], xmm6
00007871bd3e06f1  vmovaps [rsp+0x60], xmm7
00007871bd3e06f7  vmovaps [rsp+0x70], xmm8
00007871bd3e06fd  vmovaps [rsp+0x80], xmm9
00007871bd3e0706  vmovaps [rsp+0x90], xmm10
00007871bd3e070f  vmovaps [rsp+0xA0], xmm11
00007871bd3e0718  vmovaps [rsp+0xB0], xmm12
00007871bd3e0721  vmovaps [rsp+0xC0], xmm13
00007871bd3e072a  vmovaps [rsp+0xD0], xmm14
00007871bd3e0733  vmovaps [rsp+0xE0], xmm15
00007871bd3e073c  sub rsp, 0x30
00007871bd3e0740  movaps [rsp], xmm1
00007871bd3e0744  movaps [rsp+0x10], xmm6
00007871bd3e0749  movaps [rsp+0x20], xmm15
00007871bd3e074f  lea rdi, [rsp]
00007871bd3e0753  mov esi, 0x00
00007871bd3e0758  mov rax, 0x5BA2FDD2A530
00007871bd3e0762  call rax
00007871bd3e0764  movaps xmm1, [rsp]
00007871bd3e0768  add rsp, 0x30
00007871bd3e076c  vmovaps xmm0, [rsp]
00007871bd3e0771  vmovaps xmm2, [rsp+0x10]
00007871bd3e0777  vmovaps xmm3, [rsp+0x20]
00007871bd3e077d  vmovaps xmm4, [rsp+0x30]
00007871bd3e0783  vmovaps xmm5, [rsp+0x40]
00007871bd3e0789  vmovaps xmm6, [rsp+0x50]
00007871bd3e078f  vmovaps xmm7, [rsp+0x60]
00007871bd3e0795  vmovaps xmm8, [rsp+0x70]
00007871bd3e079b  vmovaps xmm9, [rsp+0x80]
00007871bd3e07a4  vmovaps xmm10, [rsp+0x90]
00007871bd3e07ad  vmovaps xmm11, [rsp+0xA0]
00007871bd3e07b6  vmovaps xmm12, [rsp+0xB0]
00007871bd3e07bf  vmovaps xmm13, [rsp+0xC0]
00007871bd3e07c8  vmovaps xmm14, [rsp+0xD0]
00007871bd3e07d1  vmovaps xmm15, [rsp+0xE0]
00007871bd3e07da  add rsp, 0xF0
00007871bd3e07e1  pop r11
00007871bd3e07e3  pop r10
00007871bd3e07e5  pop r9
00007871bd3e07e7  pop r8
00007871bd3e07e9  pop rsi
00007871bd3e07ea  pop rdi
00007871bd3e07eb  pop rdx
00007871bd3e07ec  pop rcx
00007871bd3e07ed  pop rax
00007871bd3e07ee  add rsp, 0x08
00007871bd3e07f2  jmp 0x00007871BD3DEFFB
00007871bd3e07f7  call 0x00007871BD2C4620
00007871bd3e07fc  jmp 0x00007871BD3DF008
00007871bd3e0801  sub rsp, 0x08
00007871bd3e0805  push rax
00007871bd3e0806  push rcx
00007871bd3e0807  push rdx
00007871bd3e0808  push rdi
00007871bd3e0809  push rsi
00007871bd3e080a  push r8
00007871bd3e080c  push r9
00007871bd3e080e  push r10
00007871bd3e0810  push r11
00007871bd3e0812  sub rsp, 0xF0
00007871bd3e0819  vmovaps [rsp], xmm0
00007871bd3e081e  vmovaps [rsp+0x10], xmm1
00007871bd3e0824  vmovaps [rsp+0x20], xmm2
00007871bd3e082a  vmovaps [rsp+0x30], xmm3
00007871bd3e0830  vmovaps [rsp+0x40], xmm4
00007871bd3e0836  vmovaps [rsp+0x50], xmm5
00007871bd3e083c  vmovaps [rsp+0x60], xmm6
00007871bd3e0842  vmovaps [rsp+0x70], xmm7
00007871bd3e0848  vmovaps [rsp+0x80], xmm8
00007871bd3e0851  vmovaps [rsp+0x90], xmm9
00007871bd3e085a  vmovaps [rsp+0xA0], xmm10
00007871bd3e0863  vmovaps [rsp+0xB0], xmm11
00007871bd3e086c  vmovaps [rsp+0xC0], xmm12
00007871bd3e0875  vmovaps [rsp+0xD0], xmm13
00007871bd3e087e  vmovaps [rsp+0xE0], xmm15
00007871bd3e0887  sub rsp, 0x30
00007871bd3e088b  movaps [rsp], xmm14
00007871bd3e0890  movaps [rsp+0x10], xmm4
00007871bd3e0895  movaps [rsp+0x20], xmm3
00007871bd3e089a  lea rdi, [rsp]
00007871bd3e089e  mov esi, 0x00
00007871bd3e08a3  mov rax, 0x5BA2FDD2A530
00007871bd3e08ad  call rax
00007871bd3e08af  movaps xmm14, [rsp]
00007871bd3e08b4  add rsp, 0x30
00007871bd3e08b8  vmovaps xmm0, [rsp]
00007871bd3e08bd  vmovaps xmm1, [rsp+0x10]
00007871bd3e08c3  vmovaps xmm2, [rsp+0x20]
00007871bd3e08c9  vmovaps xmm3, [rsp+0x30]
00007871bd3e08cf  vmovaps xmm4, [rsp+0x40]
00007871bd3e08d5  vmovaps xmm5, [rsp+0x50]
00007871bd3e08db  vmovaps xmm6, [rsp+0x60]
00007871bd3e08e1  vmovaps xmm7, [rsp+0x70]
00007871bd3e08e7  vmovaps xmm8, [rsp+0x80]
00007871bd3e08f0  vmovaps xmm9, [rsp+0x90]
00007871bd3e08f9  vmovaps xmm10, [rsp+0xA0]
00007871bd3e0902  vmovaps xmm11, [rsp+0xB0]
00007871bd3e090b  vmovaps xmm12, [rsp+0xC0]
00007871bd3e0914  vmovaps xmm13, [rsp+0xD0]
00007871bd3e091d  vmovaps xmm15, [rsp+0xE0]
00007871bd3e0926  add rsp, 0xF0
00007871bd3e092d  pop r11
00007871bd3e092f  pop r10
00007871bd3e0931  pop r9
00007871bd3e0933  pop r8
00007871bd3e0935  pop rsi
00007871bd3e0936  pop rdi
00007871bd3e0937  pop rdx
00007871bd3e0938  pop rcx
00007871bd3e0939  pop rax
00007871bd3e093a  add rsp, 0x08
00007871bd3e093e  jmp 0x00007871BD3DF022
00007871bd3e0943  sub rsp, 0x08
00007871bd3e0947  push rax
00007871bd3e0948  push rcx
00007871bd3e0949  push rdx
00007871bd3e094a  push rdi
00007871bd3e094b  push rsi
00007871bd3e094c  push r8
00007871bd3e094e  push r9
00007871bd3e0950  push r10
00007871bd3e0952  push r11
00007871bd3e0954  sub rsp, 0xF0
00007871bd3e095b  vmovaps [rsp], xmm0
00007871bd3e0960  vmovaps [rsp+0x10], xmm1
00007871bd3e0966  vmovaps [rsp+0x20], xmm2
00007871bd3e096c  vmovaps [rsp+0x30], xmm3
00007871bd3e0972  vmovaps [rsp+0x40], xmm4
00007871bd3e0978  vmovaps [rsp+0x50], xmm5
00007871bd3e097e  vmovaps [rsp+0x60], xmm7
00007871bd3e0984  vmovaps [rsp+0x70], xmm8
00007871bd3e098a  vmovaps [rsp+0x80], xmm9
00007871bd3e0993  vmovaps [rsp+0x90], xmm10
00007871bd3e099c  vmovaps [rsp+0xA0], xmm11
00007871bd3e09a5  vmovaps [rsp+0xB0], xmm12
00007871bd3e09ae  vmovaps [rsp+0xC0], xmm13
00007871bd3e09b7  vmovaps [rsp+0xD0], xmm14
00007871bd3e09c0  vmovaps [rsp+0xE0], xmm15
00007871bd3e09c9  sub rsp, 0x30
00007871bd3e09cd  movaps [rsp], xmm6
00007871bd3e09d1  movaps [rsp+0x10], xmm9
00007871bd3e09d7  movaps [rsp+0x20], xmm7
00007871bd3e09dc  lea rdi, [rsp]
00007871bd3e09e0  mov esi, 0x00
00007871bd3e09e5  mov rax, 0x5BA2FDD2A530
00007871bd3e09ef  call rax
00007871bd3e09f1  movaps xmm6, [rsp]
00007871bd3e09f5  add rsp, 0x30
00007871bd3e09f9  vmovaps xmm0, [rsp]
00007871bd3e09fe  vmovaps xmm1, [rsp+0x10]
00007871bd3e0a04  vmovaps xmm2, [rsp+0x20]
00007871bd3e0a0a  vmovaps xmm3, [rsp+0x30]
00007871bd3e0a10  vmovaps xmm4, [rsp+0x40]
00007871bd3e0a16  vmovaps xmm5, [rsp+0x50]
00007871bd3e0a1c  vmovaps xmm7, [rsp+0x60]
00007871bd3e0a22  vmovaps xmm8, [rsp+0x70]
00007871bd3e0a28  vmovaps xmm9, [rsp+0x80]
00007871bd3e0a31  vmovaps xmm10, [rsp+0x90]
00007871bd3e0a3a  vmovaps xmm11, [rsp+0xA0]
00007871bd3e0a43  vmovaps xmm12, [rsp+0xB0]
00007871bd3e0a4c  vmovaps xmm13, [rsp+0xC0]
00007871bd3e0a55  vmovaps xmm14, [rsp+0xD0]
00007871bd3e0a5e  vmovaps xmm15, [rsp+0xE0]
00007871bd3e0a67  add rsp, 0xF0
00007871bd3e0a6e  pop r11
00007871bd3e0a70  pop r10
00007871bd3e0a72  pop r9
00007871bd3e0a74  pop r8
00007871bd3e0a76  pop rsi
00007871bd3e0a77  pop rdi
00007871bd3e0a78  pop rdx
00007871bd3e0a79  pop rcx
00007871bd3e0a7a  pop rax
00007871bd3e0a7b  add rsp, 0x08
00007871bd3e0a7f  jmp 0x00007871BD3DF03A
00007871bd3e0a84  sub rsp, 0x08
00007871bd3e0a88  push rax
00007871bd3e0a89  push rcx
00007871bd3e0a8a  push rdx
00007871bd3e0a8b  push rdi
00007871bd3e0a8c  push rsi
00007871bd3e0a8d  push r8
00007871bd3e0a8f  push r9
00007871bd3e0a91  push r10
00007871bd3e0a93  push r11
00007871bd3e0a95  sub rsp, 0xF0
00007871bd3e0a9c  vmovaps [rsp], xmm0
00007871bd3e0aa1  vmovaps [rsp+0x10], xmm1
00007871bd3e0aa7  vmovaps [rsp+0x20], xmm2
00007871bd3e0aad  vmovaps [rsp+0x30], xmm3
00007871bd3e0ab3  vmovaps [rsp+0x40], xmm4
00007871bd3e0ab9  vmovaps [rsp+0x50], xmm5
00007871bd3e0abf  vmovaps [rsp+0x60], xmm6
00007871bd3e0ac5  vmovaps [rsp+0x70], xmm8
00007871bd3e0acb  vmovaps [rsp+0x80], xmm9
00007871bd3e0ad4  vmovaps [rsp+0x90], xmm10
00007871bd3e0add  vmovaps [rsp+0xA0], xmm11
00007871bd3e0ae6  vmovaps [rsp+0xB0], xmm12
00007871bd3e0aef  vmovaps [rsp+0xC0], xmm13
00007871bd3e0af8  vmovaps [rsp+0xD0], xmm14
00007871bd3e0b01  vmovaps [rsp+0xE0], xmm15
00007871bd3e0b0a  sub rsp, 0x30
00007871bd3e0b0e  movaps [rsp], xmm7
00007871bd3e0b12  movaps [rsp+0x10], xmm4
00007871bd3e0b17  movaps [rsp+0x20], xmm9
00007871bd3e0b1d  lea rdi, [rsp]
00007871bd3e0b21  mov esi, 0x00
00007871bd3e0b26  mov rax, 0x5BA2FDD2A530
00007871bd3e0b30  call rax
00007871bd3e0b32  movaps xmm7, [rsp]
00007871bd3e0b36  add rsp, 0x30
00007871bd3e0b3a  vmovaps xmm0, [rsp]
00007871bd3e0b3f  vmovaps xmm1, [rsp+0x10]
00007871bd3e0b45  vmovaps xmm2, [rsp+0x20]
00007871bd3e0b4b  vmovaps xmm3, [rsp+0x30]
00007871bd3e0b51  vmovaps xmm4, [rsp+0x40]
00007871bd3e0b57  vmovaps xmm5, [rsp+0x50]
00007871bd3e0b5d  vmovaps xmm6, [rsp+0x60]
00007871bd3e0b63  vmovaps xmm8, [rsp+0x70]
00007871bd3e0b69  vmovaps xmm9, [rsp+0x80]
00007871bd3e0b72  vmovaps xmm10, [rsp+0x90]
00007871bd3e0b7b  vmovaps xmm11, [rsp+0xA0]
00007871bd3e0b84  vmovaps xmm12, [rsp+0xB0]
00007871bd3e0b8d  vmovaps xmm13, [rsp+0xC0]
00007871bd3e0b96  vmovaps xmm14, [rsp+0xD0]
00007871bd3e0b9f  vmovaps xmm15, [rsp+0xE0]
00007871bd3e0ba8  add rsp, 0xF0
00007871bd3e0baf  pop r11
00007871bd3e0bb1  pop r10
00007871bd3e0bb3  pop r9
00007871bd3e0bb5  pop r8
00007871bd3e0bb7  pop rsi
00007871bd3e0bb8  pop rdi
00007871bd3e0bb9  pop rdx
00007871bd3e0bba  pop rcx
00007871bd3e0bbb  pop rax
00007871bd3e0bbc  add rsp, 0x08
00007871bd3e0bc0  jmp 0x00007871BD3DF067
00007871bd3e0bc5  sub rsp, 0x08
00007871bd3e0bc9  push rax
00007871bd3e0bca  push rcx
00007871bd3e0bcb  push rdx
00007871bd3e0bcc  push rdi
00007871bd3e0bcd  push rsi
00007871bd3e0bce  push r8
00007871bd3e0bd0  push r9
00007871bd3e0bd2  push r10
00007871bd3e0bd4  push r11
00007871bd3e0bd6  sub rsp, 0xF0
00007871bd3e0bdd  vmovaps [rsp], xmm0
00007871bd3e0be2  vmovaps [rsp+0x10], xmm1
00007871bd3e0be8  vmovaps [rsp+0x20], xmm2
00007871bd3e0bee  vmovaps [rsp+0x30], xmm3
00007871bd3e0bf4  vmovaps [rsp+0x40], xmm5
00007871bd3e0bfa  vmovaps [rsp+0x50], xmm6
00007871bd3e0c00  vmovaps [rsp+0x60], xmm7
00007871bd3e0c06  vmovaps [rsp+0x70], xmm8
00007871bd3e0c0c  vmovaps [rsp+0x80], xmm9
00007871bd3e0c15  vmovaps [rsp+0x90], xmm10
00007871bd3e0c1e  vmovaps [rsp+0xA0], xmm11
00007871bd3e0c27  vmovaps [rsp+0xB0], xmm12
00007871bd3e0c30  vmovaps [rsp+0xC0], xmm13
00007871bd3e0c39  vmovaps [rsp+0xD0], xmm14
00007871bd3e0c42  vmovaps [rsp+0xE0], xmm15
00007871bd3e0c4b  sub rsp, 0x30
00007871bd3e0c4f  movaps [rsp], xmm4
00007871bd3e0c53  movaps [rsp+0x10], xmm15
00007871bd3e0c59  movaps [rsp+0x20], xmm9
00007871bd3e0c5f  lea rdi, [rsp]
00007871bd3e0c63  mov esi, 0x00
00007871bd3e0c68  mov rax, 0x5BA2FDD2A530
00007871bd3e0c72  call rax
00007871bd3e0c74  movaps xmm4, [rsp]
00007871bd3e0c78  add rsp, 0x30
00007871bd3e0c7c  vmovaps xmm0, [rsp]
00007871bd3e0c81  vmovaps xmm1, [rsp+0x10]
00007871bd3e0c87  vmovaps xmm2, [rsp+0x20]
00007871bd3e0c8d  vmovaps xmm3, [rsp+0x30]
00007871bd3e0c93  vmovaps xmm5, [rsp+0x40]
00007871bd3e0c99  vmovaps xmm6, [rsp+0x50]
00007871bd3e0c9f  vmovaps xmm7, [rsp+0x60]
00007871bd3e0ca5  vmovaps xmm8, [rsp+0x70]
00007871bd3e0cab  vmovaps xmm9, [rsp+0x80]
00007871bd3e0cb4  vmovaps xmm10, [rsp+0x90]
00007871bd3e0cbd  vmovaps xmm11, [rsp+0xA0]
00007871bd3e0cc6  vmovaps xmm12, [rsp+0xB0]
00007871bd3e0ccf  vmovaps xmm13, [rsp+0xC0]
00007871bd3e0cd8  vmovaps xmm14, [rsp+0xD0]
00007871bd3e0ce1  vmovaps xmm15, [rsp+0xE0]
00007871bd3e0cea  add rsp, 0xF0
00007871bd3e0cf1  pop r11
00007871bd3e0cf3  pop r10
00007871bd3e0cf5  pop r9
00007871bd3e0cf7  pop r8
00007871bd3e0cf9  pop rsi
00007871bd3e0cfa  pop rdi
00007871bd3e0cfb  pop rdx
00007871bd3e0cfc  pop rcx
00007871bd3e0cfd  pop rax
00007871bd3e0cfe  add rsp, 0x08
00007871bd3e0d02  jmp 0x00007871BD3DF08C
00007871bd3e0d07  call 0x00007871BD2C4620
00007871bd3e0d0c  jmp 0x00007871BD3DF099
00007871bd3e0d11  sub rsp, 0x08
00007871bd3e0d15  push rax
00007871bd3e0d16  push rcx
00007871bd3e0d17  push rdx
00007871bd3e0d18  push rdi
00007871bd3e0d19  push rsi
00007871bd3e0d1a  push r8
00007871bd3e0d1c  push r9
00007871bd3e0d1e  push r10
00007871bd3e0d20  push r11
00007871bd3e0d22  sub rsp, 0xF0
00007871bd3e0d29  vmovaps [rsp], xmm0
00007871bd3e0d2e  vmovaps [rsp+0x10], xmm1
00007871bd3e0d34  vmovaps [rsp+0x20], xmm2
00007871bd3e0d3a  vmovaps [rsp+0x30], xmm4
00007871bd3e0d40  vmovaps [rsp+0x40], xmm5
00007871bd3e0d46  vmovaps [rsp+0x50], xmm6
00007871bd3e0d4c  vmovaps [rsp+0x60], xmm7
00007871bd3e0d52  vmovaps [rsp+0x70], xmm8
00007871bd3e0d58  vmovaps [rsp+0x80], xmm9
00007871bd3e0d61  vmovaps [rsp+0x90], xmm10
00007871bd3e0d6a  vmovaps [rsp+0xA0], xmm11
00007871bd3e0d73  vmovaps [rsp+0xB0], xmm12
00007871bd3e0d7c  vmovaps [rsp+0xC0], xmm13
00007871bd3e0d85  vmovaps [rsp+0xD0], xmm14
00007871bd3e0d8e  vmovaps [rsp+0xE0], xmm15
00007871bd3e0d97  sub rsp, 0x30
00007871bd3e0d9b  movaps [rsp], xmm3
00007871bd3e0d9f  movaps [rsp+0x10], xmm1
00007871bd3e0da4  movaps [rsp+0x20], xmm9
00007871bd3e0daa  lea rdi, [rsp]
00007871bd3e0dae  mov esi, 0x00
00007871bd3e0db3  mov rax, 0x5BA2FDD2A530
00007871bd3e0dbd  call rax
00007871bd3e0dbf  movaps xmm3, [rsp]
00007871bd3e0dc3  add rsp, 0x30
00007871bd3e0dc7  vmovaps xmm0, [rsp]
00007871bd3e0dcc  vmovaps xmm1, [rsp+0x10]
00007871bd3e0dd2  vmovaps xmm2, [rsp+0x20]
00007871bd3e0dd8  vmovaps xmm4, [rsp+0x30]
00007871bd3e0dde  vmovaps xmm5, [rsp+0x40]
00007871bd3e0de4  vmovaps xmm6, [rsp+0x50]
00007871bd3e0dea  vmovaps xmm7, [rsp+0x60]
00007871bd3e0df0  vmovaps xmm8, [rsp+0x70]
00007871bd3e0df6  vmovaps xmm9, [rsp+0x80]
00007871bd3e0dff  vmovaps xmm10, [rsp+0x90]
00007871bd3e0e08  vmovaps xmm11, [rsp+0xA0]
00007871bd3e0e11  vmovaps xmm12, [rsp+0xB0]
00007871bd3e0e1a  vmovaps xmm13, [rsp+0xC0]
00007871bd3e0e23  vmovaps xmm14, [rsp+0xD0]
00007871bd3e0e2c  vmovaps xmm15, [rsp+0xE0]
00007871bd3e0e35  add rsp, 0xF0
00007871bd3e0e3c  pop r11
00007871bd3e0e3e  pop r10
00007871bd3e0e40  pop r9
00007871bd3e0e42  pop r8
00007871bd3e0e44  pop rsi
00007871bd3e0e45  pop rdi
00007871bd3e0e46  pop rdx
00007871bd3e0e47  pop rcx
00007871bd3e0e48  pop rax
00007871bd3e0e49  add rsp, 0x08
00007871bd3e0e4d  jmp 0x00007871BD3DF0D6
00007871bd3e0e52  sub rsp, 0x08
00007871bd3e0e56  push rax
00007871bd3e0e57  push rcx
00007871bd3e0e58  push rdx
00007871bd3e0e59  push rdi
00007871bd3e0e5a  push rsi
00007871bd3e0e5b  push r8
00007871bd3e0e5d  push r9
00007871bd3e0e5f  push r10
00007871bd3e0e61  push r11
00007871bd3e0e63  sub rsp, 0xF0
00007871bd3e0e6a  vmovaps [rsp], xmm0
00007871bd3e0e6f  vmovaps [rsp+0x10], xmm2
00007871bd3e0e75  vmovaps [rsp+0x20], xmm3
00007871bd3e0e7b  vmovaps [rsp+0x30], xmm4
00007871bd3e0e81  vmovaps [rsp+0x40], xmm5
00007871bd3e0e87  vmovaps [rsp+0x50], xmm6
00007871bd3e0e8d  vmovaps [rsp+0x60], xmm7
00007871bd3e0e93  vmovaps [rsp+0x70], xmm8
00007871bd3e0e99  vmovaps [rsp+0x80], xmm9
00007871bd3e0ea2  vmovaps [rsp+0x90], xmm10
00007871bd3e0eab  vmovaps [rsp+0xA0], xmm11
00007871bd3e0eb4  vmovaps [rsp+0xB0], xmm12
00007871bd3e0ebd  vmovaps [rsp+0xC0], xmm13
00007871bd3e0ec6  vmovaps [rsp+0xD0], xmm14
00007871bd3e0ecf  vmovaps [rsp+0xE0], xmm15
00007871bd3e0ed8  sub rsp, 0x30
00007871bd3e0edc  movaps [rsp], xmm1
00007871bd3e0ee0  movaps [rsp+0x10], xmm15
00007871bd3e0ee6  movaps [rsp+0x20], xmm9
00007871bd3e0eec  lea rdi, [rsp]
00007871bd3e0ef0  mov esi, 0x00
00007871bd3e0ef5  mov rax, 0x5BA2FDD2A530
00007871bd3e0eff  call rax
00007871bd3e0f01  movaps xmm1, [rsp]
00007871bd3e0f05  add rsp, 0x30
00007871bd3e0f09  vmovaps xmm0, [rsp]
00007871bd3e0f0e  vmovaps xmm2, [rsp+0x10]
00007871bd3e0f14  vmovaps xmm3, [rsp+0x20]
00007871bd3e0f1a  vmovaps xmm4, [rsp+0x30]
00007871bd3e0f20  vmovaps xmm5, [rsp+0x40]
00007871bd3e0f26  vmovaps xmm6, [rsp+0x50]
00007871bd3e0f2c  vmovaps xmm7, [rsp+0x60]
00007871bd3e0f32  vmovaps xmm8, [rsp+0x70]
00007871bd3e0f38  vmovaps xmm9, [rsp+0x80]
00007871bd3e0f41  vmovaps xmm10, [rsp+0x90]
00007871bd3e0f4a  vmovaps xmm11, [rsp+0xA0]
00007871bd3e0f53  vmovaps xmm12, [rsp+0xB0]
00007871bd3e0f5c  vmovaps xmm13, [rsp+0xC0]
00007871bd3e0f65  vmovaps xmm14, [rsp+0xD0]
00007871bd3e0f6e  vmovaps xmm15, [rsp+0xE0]
00007871bd3e0f77  add rsp, 0xF0
00007871bd3e0f7e  pop r11
00007871bd3e0f80  pop r10
00007871bd3e0f82  pop r9
00007871bd3e0f84  pop r8
00007871bd3e0f86  pop rsi
00007871bd3e0f87  pop rdi
00007871bd3e0f88  pop rdx
00007871bd3e0f89  pop rcx
00007871bd3e0f8a  pop rax
00007871bd3e0f8b  add rsp, 0x08
00007871bd3e0f8f  jmp 0x00007871BD3DF15E
00007871bd3e0f94  call 0x00007871BD2C4620
00007871bd3e0f99  jmp 0x00007871BD3DF16B
00007871bd3e0f9e  sub rsp, 0x08
00007871bd3e0fa2  push rax
00007871bd3e0fa3  push rcx
00007871bd3e0fa4  push rdx
00007871bd3e0fa5  push rdi
00007871bd3e0fa6  push rsi
00007871bd3e0fa7  push r8
00007871bd3e0fa9  push r9
00007871bd3e0fab  push r10
00007871bd3e0fad  push r11
00007871bd3e0faf  sub rsp, 0xF0
00007871bd3e0fb6  vmovaps [rsp], xmm0
00007871bd3e0fbb  vmovaps [rsp+0x10], xmm2
00007871bd3e0fc1  vmovaps [rsp+0x20], xmm3
00007871bd3e0fc7  vmovaps [rsp+0x30], xmm4
00007871bd3e0fcd  vmovaps [rsp+0x40], xmm5
00007871bd3e0fd3  vmovaps [rsp+0x50], xmm6
00007871bd3e0fd9  vmovaps [rsp+0x60], xmm7
00007871bd3e0fdf  vmovaps [rsp+0x70], xmm8
00007871bd3e0fe5  vmovaps [rsp+0x80], xmm9
00007871bd3e0fee  vmovaps [rsp+0x90], xmm10
00007871bd3e0ff7  vmovaps [rsp+0xA0], xmm11
00007871bd3e1000  vmovaps [rsp+0xB0], xmm12
00007871bd3e1009  vmovaps [rsp+0xC0], xmm13
00007871bd3e1012  vmovaps [rsp+0xD0], xmm14
00007871bd3e101b  vmovaps [rsp+0xE0], xmm15
00007871bd3e1024  sub rsp, 0x30
00007871bd3e1028  movaps [rsp], xmm1
00007871bd3e102c  movaps [rsp+0x10], xmm5
00007871bd3e1031  movaps [rsp+0x20], xmm7
00007871bd3e1036  lea rdi, [rsp]
00007871bd3e103a  mov esi, 0x00
00007871bd3e103f  mov rax, 0x5BA2FDD2A530
00007871bd3e1049  call rax
00007871bd3e104b  movaps xmm1, [rsp]
00007871bd3e104f  add rsp, 0x30
00007871bd3e1053  vmovaps xmm0, [rsp]
00007871bd3e1058  vmovaps xmm2, [rsp+0x10]
00007871bd3e105e  vmovaps xmm3, [rsp+0x20]
00007871bd3e1064  vmovaps xmm4, [rsp+0x30]
00007871bd3e106a  vmovaps xmm5, [rsp+0x40]
00007871bd3e1070  vmovaps xmm6, [rsp+0x50]
00007871bd3e1076  vmovaps xmm7, [rsp+0x60]
00007871bd3e107c  vmovaps xmm8, [rsp+0x70]
00007871bd3e1082  vmovaps xmm9, [rsp+0x80]
00007871bd3e108b  vmovaps xmm10, [rsp+0x90]
00007871bd3e1094  vmovaps xmm11, [rsp+0xA0]
00007871bd3e109d  vmovaps xmm12, [rsp+0xB0]
00007871bd3e10a6  vmovaps xmm13, [rsp+0xC0]
00007871bd3e10af  vmovaps xmm14, [rsp+0xD0]
00007871bd3e10b8  vmovaps xmm15, [rsp+0xE0]
00007871bd3e10c1  add rsp, 0xF0
00007871bd3e10c8  pop r11
00007871bd3e10ca  pop r10
00007871bd3e10cc  pop r9
00007871bd3e10ce  pop r8
00007871bd3e10d0  pop rsi
00007871bd3e10d1  pop rdi
00007871bd3e10d2  pop rdx
00007871bd3e10d3  pop rcx
00007871bd3e10d4  pop rax
00007871bd3e10d5  add rsp, 0x08
00007871bd3e10d9  jmp 0x00007871BD3DF210
00007871bd3e10de  sub rsp, 0x08
00007871bd3e10e2  push rax
00007871bd3e10e3  push rcx
00007871bd3e10e4  push rdx
00007871bd3e10e5  push rdi
00007871bd3e10e6  push rsi
00007871bd3e10e7  push r8
00007871bd3e10e9  push r9
00007871bd3e10eb  push r10
00007871bd3e10ed  push r11
00007871bd3e10ef  sub rsp, 0xF0
00007871bd3e10f6  vmovaps [rsp], xmm0
00007871bd3e10fb  vmovaps [rsp+0x10], xmm1
00007871bd3e1101  vmovaps [rsp+0x20], xmm2
00007871bd3e1107  vmovaps [rsp+0x30], xmm3
00007871bd3e110d  vmovaps [rsp+0x40], xmm4
00007871bd3e1113  vmovaps [rsp+0x50], xmm5
00007871bd3e1119  vmovaps [rsp+0x60], xmm6
00007871bd3e111f  vmovaps [rsp+0x70], xmm8
00007871bd3e1125  vmovaps [rsp+0x80], xmm9
00007871bd3e112e  vmovaps [rsp+0x90], xmm10
00007871bd3e1137  vmovaps [rsp+0xA0], xmm11
00007871bd3e1140  vmovaps [rsp+0xB0], xmm12
00007871bd3e1149  vmovaps [rsp+0xC0], xmm13
00007871bd3e1152  vmovaps [rsp+0xD0], xmm14
00007871bd3e115b  vmovaps [rsp+0xE0], xmm15
00007871bd3e1164  sub rsp, 0x30
00007871bd3e1168  movaps [rsp], xmm7
00007871bd3e116c  movaps [rsp+0x10], xmm5
00007871bd3e1171  movaps [rsp+0x20], xmm15
00007871bd3e1177  lea rdi, [rsp]
00007871bd3e117b  mov esi, 0x00
00007871bd3e1180  mov rax, 0x5BA2FDD2A530
00007871bd3e118a  call rax
00007871bd3e118c  movaps xmm7, [rsp]
00007871bd3e1190  add rsp, 0x30
00007871bd3e1194  vmovaps xmm0, [rsp]
00007871bd3e1199  vmovaps xmm1, [rsp+0x10]
00007871bd3e119f  vmovaps xmm2, [rsp+0x20]
00007871bd3e11a5  vmovaps xmm3, [rsp+0x30]
00007871bd3e11ab  vmovaps xmm4, [rsp+0x40]
00007871bd3e11b1  vmovaps xmm5, [rsp+0x50]
00007871bd3e11b7  vmovaps xmm6, [rsp+0x60]
00007871bd3e11bd  vmovaps xmm8, [rsp+0x70]
00007871bd3e11c3  vmovaps xmm9, [rsp+0x80]
00007871bd3e11cc  vmovaps xmm10, [rsp+0x90]
00007871bd3e11d5  vmovaps xmm11, [rsp+0xA0]
00007871bd3e11de  vmovaps xmm12, [rsp+0xB0]
00007871bd3e11e7  vmovaps xmm13, [rsp+0xC0]
00007871bd3e11f0  vmovaps xmm14, [rsp+0xD0]
00007871bd3e11f9  vmovaps xmm15, [rsp+0xE0]
00007871bd3e1202  add rsp, 0xF0
00007871bd3e1209  pop r11
00007871bd3e120b  pop r10
00007871bd3e120d  pop r9
00007871bd3e120f  pop r8
00007871bd3e1211  pop rsi
00007871bd3e1212  pop rdi
00007871bd3e1213  pop rdx
00007871bd3e1214  pop rcx
00007871bd3e1215  pop rax
00007871bd3e1216  add rsp, 0x08
00007871bd3e121a  jmp 0x00007871BD3DF246
00007871bd3e121f  call 0x00007871BD2B52F0
00007871bd3e1224  jmp 0x00007871BD3DF253
00007871bd3e1229  sub rsp, 0x08
00007871bd3e122d  push rax
00007871bd3e122e  push rcx
00007871bd3e122f  push rdx
00007871bd3e1230  push rdi
00007871bd3e1231  push rsi
00007871bd3e1232  push r8
00007871bd3e1234  push r9
00007871bd3e1236  push r10
00007871bd3e1238  push r11
00007871bd3e123a  sub rsp, 0xF0
00007871bd3e1241  vmovaps [rsp], xmm0
00007871bd3e1246  vmovaps [rsp+0x10], xmm1
00007871bd3e124c  vmovaps [rsp+0x20], xmm2
00007871bd3e1252  vmovaps [rsp+0x30], xmm3
00007871bd3e1258  vmovaps [rsp+0x40], xmm4
00007871bd3e125e  vmovaps [rsp+0x50], xmm5
00007871bd3e1264  vmovaps [rsp+0x60], xmm6
00007871bd3e126a  vmovaps [rsp+0x70], xmm7
00007871bd3e1270  vmovaps [rsp+0x80], xmm8
00007871bd3e1279  vmovaps [rsp+0x90], xmm9
00007871bd3e1282  vmovaps [rsp+0xA0], xmm10
00007871bd3e128b  vmovaps [rsp+0xB0], xmm11
00007871bd3e1294  vmovaps [rsp+0xC0], xmm12
00007871bd3e129d  vmovaps [rsp+0xD0], xmm13
00007871bd3e12a6  vmovaps [rsp+0xE0], xmm14
00007871bd3e12af  sub rsp, 0x30
00007871bd3e12b3  movaps [rsp], xmm15
00007871bd3e12b8  movaps [rsp+0x10], xmm5
00007871bd3e12bd  movaps [rsp+0x20], xmm3
00007871bd3e12c2  lea rdi, [rsp]
00007871bd3e12c6  mov esi, 0x00
00007871bd3e12cb  mov rax, 0x5BA2FDD2A530
00007871bd3e12d5  call rax
00007871bd3e12d7  movaps xmm15, [rsp]
00007871bd3e12dc  add rsp, 0x30
00007871bd3e12e0  vmovaps xmm0, [rsp]
00007871bd3e12e5  vmovaps xmm1, [rsp+0x10]
00007871bd3e12eb  vmovaps xmm2, [rsp+0x20]
00007871bd3e12f1  vmovaps xmm3, [rsp+0x30]
00007871bd3e12f7  vmovaps xmm4, [rsp+0x40]
00007871bd3e12fd  vmovaps xmm5, [rsp+0x50]
00007871bd3e1303  vmovaps xmm6, [rsp+0x60]
00007871bd3e1309  vmovaps xmm7, [rsp+0x70]
00007871bd3e130f  vmovaps xmm8, [rsp+0x80]
00007871bd3e1318  vmovaps xmm9, [rsp+0x90]
00007871bd3e1321  vmovaps xmm10, [rsp+0xA0]
00007871bd3e132a  vmovaps xmm11, [rsp+0xB0]
00007871bd3e1333  vmovaps xmm12, [rsp+0xC0]
00007871bd3e133c  vmovaps xmm13, [rsp+0xD0]
00007871bd3e1345  vmovaps xmm14, [rsp+0xE0]
00007871bd3e134e  add rsp, 0xF0
00007871bd3e1355  pop r11
00007871bd3e1357  pop r10
00007871bd3e1359  pop r9
00007871bd3e135b  pop r8
00007871bd3e135d  pop rsi
00007871bd3e135e  pop rdi
00007871bd3e135f  pop rdx
00007871bd3e1360  pop rcx
00007871bd3e1361  pop rax
00007871bd3e1362  add rsp, 0x08
00007871bd3e1366  jmp 0x00007871BD3DF279
00007871bd3e136b  sub rsp, 0x08
00007871bd3e136f  push rax
00007871bd3e1370  push rcx
00007871bd3e1371  push rdx
00007871bd3e1372  push rdi
00007871bd3e1373  push rsi
00007871bd3e1374  push r8
00007871bd3e1376  push r9
00007871bd3e1378  push r10
00007871bd3e137a  push r11
00007871bd3e137c  sub rsp, 0xF0
00007871bd3e1383  vmovaps [rsp], xmm0
00007871bd3e1388  vmovaps [rsp+0x10], xmm2
00007871bd3e138e  vmovaps [rsp+0x20], xmm3
00007871bd3e1394  vmovaps [rsp+0x30], xmm4
00007871bd3e139a  vmovaps [rsp+0x40], xmm5
00007871bd3e13a0  vmovaps [rsp+0x50], xmm6
00007871bd3e13a6  vmovaps [rsp+0x60], xmm7
00007871bd3e13ac  vmovaps [rsp+0x70], xmm8
00007871bd3e13b2  vmovaps [rsp+0x80], xmm9
00007871bd3e13bb  vmovaps [rsp+0x90], xmm10
00007871bd3e13c4  vmovaps [rsp+0xA0], xmm11
00007871bd3e13cd  vmovaps [rsp+0xB0], xmm12
00007871bd3e13d6  vmovaps [rsp+0xC0], xmm13
00007871bd3e13df  vmovaps [rsp+0xD0], xmm14
00007871bd3e13e8  vmovaps [rsp+0xE0], xmm15
00007871bd3e13f1  sub rsp, 0x30
00007871bd3e13f5  movaps [rsp], xmm1
00007871bd3e13f9  movaps [rsp+0x10], xmm5
00007871bd3e13fe  movaps [rsp+0x20], xmm4
00007871bd3e1403  lea rdi, [rsp]
00007871bd3e1407  mov esi, 0x00
00007871bd3e140c  mov rax, 0x5BA2FDD2A530
00007871bd3e1416  call rax
00007871bd3e1418  movaps xmm1, [rsp]
00007871bd3e141c  add rsp, 0x30
00007871bd3e1420  vmovaps xmm0, [rsp]
00007871bd3e1425  vmovaps xmm2, [rsp+0x10]
00007871bd3e142b  vmovaps xmm3, [rsp+0x20]
00007871bd3e1431  vmovaps xmm4, [rsp+0x30]
00007871bd3e1437  vmovaps xmm5, [rsp+0x40]
00007871bd3e143d  vmovaps xmm6, [rsp+0x50]
00007871bd3e1443  vmovaps xmm7, [rsp+0x60]
00007871bd3e1449  vmovaps xmm8, [rsp+0x70]
00007871bd3e144f  vmovaps xmm9, [rsp+0x80]
00007871bd3e1458  vmovaps xmm10, [rsp+0x90]
00007871bd3e1461  vmovaps xmm11, [rsp+0xA0]
00007871bd3e146a  vmovaps xmm12, [rsp+0xB0]
00007871bd3e1473  vmovaps xmm13, [rsp+0xC0]
00007871bd3e147c  vmovaps xmm14, [rsp+0xD0]
00007871bd3e1485  vmovaps xmm15, [rsp+0xE0]
00007871bd3e148e  add rsp, 0xF0
00007871bd3e1495  pop r11
00007871bd3e1497  pop r10
00007871bd3e1499  pop r9
00007871bd3e149b  pop r8
00007871bd3e149d  pop rsi
00007871bd3e149e  pop rdi
00007871bd3e149f  pop rdx
00007871bd3e14a0  pop rcx
00007871bd3e14a1  pop rax
00007871bd3e14a2  add rsp, 0x08
00007871bd3e14a6  jmp 0x00007871BD3DF299
00007871bd3e14ab  sub rsp, 0x08
00007871bd3e14af  push rax
00007871bd3e14b0  push rcx
00007871bd3e14b1  push rdx
00007871bd3e14b2  push rdi
00007871bd3e14b3  push rsi
00007871bd3e14b4  push r8
00007871bd3e14b6  push r9
00007871bd3e14b8  push r10
00007871bd3e14ba  push r11
00007871bd3e14bc  sub rsp, 0xF0
00007871bd3e14c3  vmovaps [rsp], xmm0
00007871bd3e14c8  vmovaps [rsp+0x10], xmm1
00007871bd3e14ce  vmovaps [rsp+0x20], xmm2
00007871bd3e14d4  vmovaps [rsp+0x30], xmm3
00007871bd3e14da  vmovaps [rsp+0x40], xmm5
00007871bd3e14e0  vmovaps [rsp+0x50], xmm6
00007871bd3e14e6  vmovaps [rsp+0x60], xmm7
00007871bd3e14ec  vmovaps [rsp+0x70], xmm8
00007871bd3e14f2  vmovaps [rsp+0x80], xmm9
00007871bd3e14fb  vmovaps [rsp+0x90], xmm10
00007871bd3e1504  vmovaps [rsp+0xA0], xmm11
00007871bd3e150d  vmovaps [rsp+0xB0], xmm12
00007871bd3e1516  vmovaps [rsp+0xC0], xmm13
00007871bd3e151f  vmovaps [rsp+0xD0], xmm14
00007871bd3e1528  vmovaps [rsp+0xE0], xmm15
00007871bd3e1531  sub rsp, 0x30
00007871bd3e1535  movaps [rsp], xmm4
00007871bd3e1539  movaps [rsp+0x10], xmm3
00007871bd3e153e  movaps [rsp+0x20], xmm5
00007871bd3e1543  lea rdi, [rsp]
00007871bd3e1547  mov esi, 0x00
00007871bd3e154c  mov rax, 0x5BA2FDD2A530
00007871bd3e1556  call rax
00007871bd3e1558  movaps xmm4, [rsp]
00007871bd3e155c  add rsp, 0x30
00007871bd3e1560  vmovaps xmm0, [rsp]
00007871bd3e1565  vmovaps xmm1, [rsp+0x10]
00007871bd3e156b  vmovaps xmm2, [rsp+0x20]
00007871bd3e1571  vmovaps xmm3, [rsp+0x30]
00007871bd3e1577  vmovaps xmm5, [rsp+0x40]
00007871bd3e157d  vmovaps xmm6, [rsp+0x50]
00007871bd3e1583  vmovaps xmm7, [rsp+0x60]
00007871bd3e1589  vmovaps xmm8, [rsp+0x70]
00007871bd3e158f  vmovaps xmm9, [rsp+0x80]
00007871bd3e1598  vmovaps xmm10, [rsp+0x90]
00007871bd3e15a1  vmovaps xmm11, [rsp+0xA0]
00007871bd3e15aa  vmovaps xmm12, [rsp+0xB0]
00007871bd3e15b3  vmovaps xmm13, [rsp+0xC0]
00007871bd3e15bc  vmovaps xmm14, [rsp+0xD0]
00007871bd3e15c5  vmovaps xmm15, [rsp+0xE0]
00007871bd3e15ce  add rsp, 0xF0
00007871bd3e15d5  pop r11
00007871bd3e15d7  pop r10
00007871bd3e15d9  pop r9
00007871bd3e15db  pop r8
00007871bd3e15dd  pop rsi
00007871bd3e15de  pop rdi
00007871bd3e15df  pop rdx
00007871bd3e15e0  pop rcx
00007871bd3e15e1  pop rax
00007871bd3e15e2  add rsp, 0x08
00007871bd3e15e6  jmp 0x00007871BD3DF2E7
00007871bd3e15eb  call 0x00007871BD2B52F0
00007871bd3e15f0  jmp 0x00007871BD3DF2F4
00007871bd3e15f5  sub rsp, 0x08
00007871bd3e15f9  push rax
00007871bd3e15fa  push rcx
00007871bd3e15fb  push rdx
00007871bd3e15fc  push rdi
00007871bd3e15fd  push rsi
00007871bd3e15fe  push r8
00007871bd3e1600  push r9
00007871bd3e1602  push r10
00007871bd3e1604  push r11
00007871bd3e1606  sub rsp, 0xF0
00007871bd3e160d  vmovaps [rsp], xmm0
00007871bd3e1612  vmovaps [rsp+0x10], xmm1
00007871bd3e1618  vmovaps [rsp+0x20], xmm2
00007871bd3e161e  vmovaps [rsp+0x30], xmm3
00007871bd3e1624  vmovaps [rsp+0x40], xmm4
00007871bd3e162a  vmovaps [rsp+0x50], xmm6
00007871bd3e1630  vmovaps [rsp+0x60], xmm7
00007871bd3e1636  vmovaps [rsp+0x70], xmm8
00007871bd3e163c  vmovaps [rsp+0x80], xmm9
00007871bd3e1645  vmovaps [rsp+0x90], xmm10
00007871bd3e164e  vmovaps [rsp+0xA0], xmm11
00007871bd3e1657  vmovaps [rsp+0xB0], xmm12
00007871bd3e1660  vmovaps [rsp+0xC0], xmm13
00007871bd3e1669  vmovaps [rsp+0xD0], xmm14
00007871bd3e1672  vmovaps [rsp+0xE0], xmm15
00007871bd3e167b  sub rsp, 0x30
00007871bd3e167f  movaps [rsp], xmm5
00007871bd3e1683  movaps [rsp+0x10], xmm6
00007871bd3e1688  movaps [rsp+0x20], xmm3
00007871bd3e168d  lea rdi, [rsp]
00007871bd3e1691  mov esi, 0x00
00007871bd3e1696  mov rax, 0x5BA2FDD2A530
00007871bd3e16a0  call rax
00007871bd3e16a2  movaps xmm5, [rsp]
00007871bd3e16a6  add rsp, 0x30
00007871bd3e16aa  vmovaps xmm0, [rsp]
00007871bd3e16af  vmovaps xmm1, [rsp+0x10]
00007871bd3e16b5  vmovaps xmm2, [rsp+0x20]
00007871bd3e16bb  vmovaps xmm3, [rsp+0x30]
00007871bd3e16c1  vmovaps xmm4, [rsp+0x40]
00007871bd3e16c7  vmovaps xmm6, [rsp+0x50]
00007871bd3e16cd  vmovaps xmm7, [rsp+0x60]
00007871bd3e16d3  vmovaps xmm8, [rsp+0x70]
00007871bd3e16d9  vmovaps xmm9, [rsp+0x80]
00007871bd3e16e2  vmovaps xmm10, [rsp+0x90]
00007871bd3e16eb  vmovaps xmm11, [rsp+0xA0]
00007871bd3e16f4  vmovaps xmm12, [rsp+0xB0]
00007871bd3e16fd  vmovaps xmm13, [rsp+0xC0]
00007871bd3e1706  vmovaps xmm14, [rsp+0xD0]
00007871bd3e170f  vmovaps xmm15, [rsp+0xE0]
00007871bd3e1718  add rsp, 0xF0
00007871bd3e171f  pop r11
00007871bd3e1721  pop r10
00007871bd3e1723  pop r9
00007871bd3e1725  pop r8
00007871bd3e1727  pop rsi
00007871bd3e1728  pop rdi
00007871bd3e1729  pop rdx
00007871bd3e172a  pop rcx
00007871bd3e172b  pop rax
00007871bd3e172c  add rsp, 0x08
00007871bd3e1730  jmp 0x00007871BD3DF31A
00007871bd3e1735  sub rsp, 0x08
00007871bd3e1739  push rax
00007871bd3e173a  push rcx
00007871bd3e173b  push rdx
00007871bd3e173c  push rdi
00007871bd3e173d  push rsi
00007871bd3e173e  push r8
00007871bd3e1740  push r9
00007871bd3e1742  push r10
00007871bd3e1744  push r11
00007871bd3e1746  sub rsp, 0xF0
00007871bd3e174d  vmovaps [rsp], xmm0
00007871bd3e1752  vmovaps [rsp+0x10], xmm1
00007871bd3e1758  vmovaps [rsp+0x20], xmm2
00007871bd3e175e  vmovaps [rsp+0x30], xmm3
00007871bd3e1764  vmovaps [rsp+0x40], xmm4
00007871bd3e176a  vmovaps [rsp+0x50], xmm5
00007871bd3e1770  vmovaps [rsp+0x60], xmm7
00007871bd3e1776  vmovaps [rsp+0x70], xmm8
00007871bd3e177c  vmovaps [rsp+0x80], xmm9
00007871bd3e1785  vmovaps [rsp+0x90], xmm10
00007871bd3e178e  vmovaps [rsp+0xA0], xmm11
00007871bd3e1797  vmovaps [rsp+0xB0], xmm12
00007871bd3e17a0  vmovaps [rsp+0xC0], xmm13
00007871bd3e17a9  vmovaps [rsp+0xD0], xmm14
00007871bd3e17b2  vmovaps [rsp+0xE0], xmm15
00007871bd3e17bb  sub rsp, 0x30
00007871bd3e17bf  movaps [rsp], xmm6
00007871bd3e17c3  movaps [rsp+0x10], xmm9
00007871bd3e17c9  movaps [rsp+0x20], xmm1
00007871bd3e17ce  lea rdi, [rsp]
00007871bd3e17d2  mov esi, 0x00
00007871bd3e17d7  mov rax, 0x5BA2FDD2A530
00007871bd3e17e1  call rax
00007871bd3e17e3  movaps xmm6, [rsp]
00007871bd3e17e7  add rsp, 0x30
00007871bd3e17eb  vmovaps xmm0, [rsp]
00007871bd3e17f0  vmovaps xmm1, [rsp+0x10]
00007871bd3e17f6  vmovaps xmm2, [rsp+0x20]
00007871bd3e17fc  vmovaps xmm3, [rsp+0x30]
00007871bd3e1802  vmovaps xmm4, [rsp+0x40]
00007871bd3e1808  vmovaps xmm5, [rsp+0x50]
00007871bd3e180e  vmovaps xmm7, [rsp+0x60]
00007871bd3e1814  vmovaps xmm8, [rsp+0x70]
00007871bd3e181a  vmovaps xmm9, [rsp+0x80]
00007871bd3e1823  vmovaps xmm10, [rsp+0x90]
00007871bd3e182c  vmovaps xmm11, [rsp+0xA0]
00007871bd3e1835  vmovaps xmm12, [rsp+0xB0]
00007871bd3e183e  vmovaps xmm13, [rsp+0xC0]
00007871bd3e1847  vmovaps xmm14, [rsp+0xD0]
00007871bd3e1850  vmovaps xmm15, [rsp+0xE0]
00007871bd3e1859  add rsp, 0xF0
00007871bd3e1860  pop r11
00007871bd3e1862  pop r10
00007871bd3e1864  pop r9
00007871bd3e1866  pop r8
00007871bd3e1868  pop rsi
00007871bd3e1869  pop rdi
00007871bd3e186a  pop rdx
00007871bd3e186b  pop rcx
00007871bd3e186c  pop rax
00007871bd3e186d  add rsp, 0x08
00007871bd3e1871  jmp 0x00007871BD3DF33E
00007871bd3e1876  sub rsp, 0x08
00007871bd3e187a  push rax
00007871bd3e187b  push rcx
00007871bd3e187c  push rdx
00007871bd3e187d  push rdi
00007871bd3e187e  push rsi
00007871bd3e187f  push r8
00007871bd3e1881  push r9
00007871bd3e1883  push r10
00007871bd3e1885  push r11
00007871bd3e1887  sub rsp, 0xF0
00007871bd3e188e  vmovaps [rsp], xmm0
00007871bd3e1893  vmovaps [rsp+0x10], xmm1
00007871bd3e1899  vmovaps [rsp+0x20], xmm2
00007871bd3e189f  vmovaps [rsp+0x30], xmm3
00007871bd3e18a5  vmovaps [rsp+0x40], xmm4
00007871bd3e18ab  vmovaps [rsp+0x50], xmm5
00007871bd3e18b1  vmovaps [rsp+0x60], xmm6
00007871bd3e18b7  vmovaps [rsp+0x70], xmm7
00007871bd3e18bd  vmovaps [rsp+0x80], xmm8
00007871bd3e18c6  vmovaps [rsp+0x90], xmm10
00007871bd3e18cf  vmovaps [rsp+0xA0], xmm11
00007871bd3e18d8  vmovaps [rsp+0xB0], xmm12
00007871bd3e18e1  vmovaps [rsp+0xC0], xmm13
00007871bd3e18ea  vmovaps [rsp+0xD0], xmm14
00007871bd3e18f3  vmovaps [rsp+0xE0], xmm15
00007871bd3e18fc  sub rsp, 0x30
00007871bd3e1900  movaps [rsp], xmm9
00007871bd3e1905  movaps [rsp+0x10], xmm3
00007871bd3e190a  movaps [rsp+0x20], xmm1
00007871bd3e190f  lea rdi, [rsp]
00007871bd3e1913  mov esi, 0x00
00007871bd3e1918  mov rax, 0x5BA2FDD2A530
00007871bd3e1922  call rax
00007871bd3e1924  movaps xmm9, [rsp]
00007871bd3e1929  add rsp, 0x30
00007871bd3e192d  vmovaps xmm0, [rsp]
00007871bd3e1932  vmovaps xmm1, [rsp+0x10]
00007871bd3e1938  vmovaps xmm2, [rsp+0x20]
00007871bd3e193e  vmovaps xmm3, [rsp+0x30]
00007871bd3e1944  vmovaps xmm4, [rsp+0x40]
00007871bd3e194a  vmovaps xmm5, [rsp+0x50]
00007871bd3e1950  vmovaps xmm6, [rsp+0x60]
00007871bd3e1956  vmovaps xmm7, [rsp+0x70]
00007871bd3e195c  vmovaps xmm8, [rsp+0x80]
00007871bd3e1965  vmovaps xmm10, [rsp+0x90]
00007871bd3e196e  vmovaps xmm11, [rsp+0xA0]
00007871bd3e1977  vmovaps xmm12, [rsp+0xB0]
00007871bd3e1980  vmovaps xmm13, [rsp+0xC0]
00007871bd3e1989  vmovaps xmm14, [rsp+0xD0]
00007871bd3e1992  vmovaps xmm15, [rsp+0xE0]
00007871bd3e199b  add rsp, 0xF0
00007871bd3e19a2  pop r11
00007871bd3e19a4  pop r10
00007871bd3e19a6  pop r9
00007871bd3e19a8  pop r8
00007871bd3e19aa  pop rsi
00007871bd3e19ab  pop rdi
00007871bd3e19ac  pop rdx
00007871bd3e19ad  pop rcx
00007871bd3e19ae  pop rax
00007871bd3e19af  add rsp, 0x08
00007871bd3e19b3  jmp 0x00007871BD3DF38A
00007871bd3e19b8  call 0x00007871BD2B52F0
00007871bd3e19bd  jmp 0x00007871BD3DF397
00007871bd3e19c2  sub rsp, 0x08
00007871bd3e19c6  push rax
00007871bd3e19c7  push rcx
00007871bd3e19c8  push rdx
00007871bd3e19c9  push rdi
00007871bd3e19ca  push rsi
00007871bd3e19cb  push r8
00007871bd3e19cd  push r9
00007871bd3e19cf  push r10
00007871bd3e19d1  push r11
00007871bd3e19d3  sub rsp, 0xF0
00007871bd3e19da  vmovaps [rsp], xmm0
00007871bd3e19df  vmovaps [rsp+0x10], xmm1
00007871bd3e19e5  vmovaps [rsp+0x20], xmm2
00007871bd3e19eb  vmovaps [rsp+0x30], xmm3
00007871bd3e19f1  vmovaps [rsp+0x40], xmm4
00007871bd3e19f7  vmovaps [rsp+0x50], xmm5
00007871bd3e19fd  vmovaps [rsp+0x60], xmm6
00007871bd3e1a03  vmovaps [rsp+0x70], xmm7
00007871bd3e1a09  vmovaps [rsp+0x80], xmm8
00007871bd3e1a12  vmovaps [rsp+0x90], xmm9
00007871bd3e1a1b  vmovaps [rsp+0xA0], xmm10
00007871bd3e1a24  vmovaps [rsp+0xB0], xmm11
00007871bd3e1a2d  vmovaps [rsp+0xC0], xmm12
00007871bd3e1a36  vmovaps [rsp+0xD0], xmm13
00007871bd3e1a3f  vmovaps [rsp+0xE0], xmm14
00007871bd3e1a48  sub rsp, 0x30
00007871bd3e1a4c  movaps [rsp], xmm15
00007871bd3e1a51  movaps [rsp+0x10], xmm3
00007871bd3e1a56  movaps [rsp+0x20], xmm7
00007871bd3e1a5b  lea rdi, [rsp]
00007871bd3e1a5f  mov esi, 0x00
00007871bd3e1a64  mov rax, 0x5BA2FDD2A530
00007871bd3e1a6e  call rax
00007871bd3e1a70  movaps xmm15, [rsp]
00007871bd3e1a75  add rsp, 0x30
00007871bd3e1a79  vmovaps xmm0, [rsp]
00007871bd3e1a7e  vmovaps xmm1, [rsp+0x10]
00007871bd3e1a84  vmovaps xmm2, [rsp+0x20]
00007871bd3e1a8a  vmovaps xmm3, [rsp+0x30]
00007871bd3e1a90  vmovaps xmm4, [rsp+0x40]
00007871bd3e1a96  vmovaps xmm5, [rsp+0x50]
00007871bd3e1a9c  vmovaps xmm6, [rsp+0x60]
00007871bd3e1aa2  vmovaps xmm7, [rsp+0x70]
00007871bd3e1aa8  vmovaps xmm8, [rsp+0x80]
00007871bd3e1ab1  vmovaps xmm9, [rsp+0x90]
00007871bd3e1aba  vmovaps xmm10, [rsp+0xA0]
00007871bd3e1ac3  vmovaps xmm11, [rsp+0xB0]
00007871bd3e1acc  vmovaps xmm12, [rsp+0xC0]
00007871bd3e1ad5  vmovaps xmm13, [rsp+0xD0]
00007871bd3e1ade  vmovaps xmm14, [rsp+0xE0]
00007871bd3e1ae7  add rsp, 0xF0
00007871bd3e1aee  pop r11
00007871bd3e1af0  pop r10
00007871bd3e1af2  pop r9
00007871bd3e1af4  pop r8
00007871bd3e1af6  pop rsi
00007871bd3e1af7  pop rdi
00007871bd3e1af8  pop rdx
00007871bd3e1af9  pop rcx
00007871bd3e1afa  pop rax
00007871bd3e1afb  add rsp, 0x08
00007871bd3e1aff  jmp 0x00007871BD3DF3C3
00007871bd3e1b04  sub rsp, 0x08
00007871bd3e1b08  push rax
00007871bd3e1b09  push rcx
00007871bd3e1b0a  push rdx
00007871bd3e1b0b  push rdi
00007871bd3e1b0c  push rsi
00007871bd3e1b0d  push r8
00007871bd3e1b0f  push r9
00007871bd3e1b11  push r10
00007871bd3e1b13  push r11
00007871bd3e1b15  sub rsp, 0xF0
00007871bd3e1b1c  vmovaps [rsp], xmm0
00007871bd3e1b21  vmovaps [rsp+0x10], xmm1
00007871bd3e1b27  vmovaps [rsp+0x20], xmm2
00007871bd3e1b2d  vmovaps [rsp+0x30], xmm4
00007871bd3e1b33  vmovaps [rsp+0x40], xmm5
00007871bd3e1b39  vmovaps [rsp+0x50], xmm6
00007871bd3e1b3f  vmovaps [rsp+0x60], xmm7
00007871bd3e1b45  vmovaps [rsp+0x70], xmm8
00007871bd3e1b4b  vmovaps [rsp+0x80], xmm9
00007871bd3e1b54  vmovaps [rsp+0x90], xmm10
00007871bd3e1b5d  vmovaps [rsp+0xA0], xmm11
00007871bd3e1b66  vmovaps [rsp+0xB0], xmm12
00007871bd3e1b6f  vmovaps [rsp+0xC0], xmm13
00007871bd3e1b78  vmovaps [rsp+0xD0], xmm14
00007871bd3e1b81  vmovaps [rsp+0xE0], xmm15
00007871bd3e1b8a  sub rsp, 0x30
00007871bd3e1b8e  movaps [rsp], xmm3
00007871bd3e1b92  movaps [rsp+0x10], xmm1
00007871bd3e1b97  movaps [rsp+0x20], xmm15
00007871bd3e1b9d  lea rdi, [rsp]
00007871bd3e1ba1  mov esi, 0x00
00007871bd3e1ba6  mov rax, 0x5BA2FDD2A530
00007871bd3e1bb0  call rax
00007871bd3e1bb2  movaps xmm3, [rsp]
00007871bd3e1bb6  add rsp, 0x30
00007871bd3e1bba  vmovaps xmm0, [rsp]
00007871bd3e1bbf  vmovaps xmm1, [rsp+0x10]
00007871bd3e1bc5  vmovaps xmm2, [rsp+0x20]
00007871bd3e1bcb  vmovaps xmm4, [rsp+0x30]
00007871bd3e1bd1  vmovaps xmm5, [rsp+0x40]
00007871bd3e1bd7  vmovaps xmm6, [rsp+0x50]
00007871bd3e1bdd  vmovaps xmm7, [rsp+0x60]
00007871bd3e1be3  vmovaps xmm8, [rsp+0x70]
00007871bd3e1be9  vmovaps xmm9, [rsp+0x80]
00007871bd3e1bf2  vmovaps xmm10, [rsp+0x90]
00007871bd3e1bfb  vmovaps xmm11, [rsp+0xA0]
00007871bd3e1c04  vmovaps xmm12, [rsp+0xB0]
00007871bd3e1c0d  vmovaps xmm13, [rsp+0xC0]
00007871bd3e1c16  vmovaps xmm14, [rsp+0xD0]
00007871bd3e1c1f  vmovaps xmm15, [rsp+0xE0]
00007871bd3e1c28  add rsp, 0xF0
00007871bd3e1c2f  pop r11
00007871bd3e1c31  pop r10
00007871bd3e1c33  pop r9
00007871bd3e1c35  pop r8
00007871bd3e1c37  pop rsi
00007871bd3e1c38  pop rdi
00007871bd3e1c39  pop rdx
00007871bd3e1c3a  pop rcx
00007871bd3e1c3b  pop rax
00007871bd3e1c3c  add rsp, 0x08
00007871bd3e1c40  jmp 0x00007871BD3DF452
00007871bd3e1c45  call 0x00007871BD2B52F0
00007871bd3e1c4a  jmp 0x00007871BD3DF45C
00007871bd3e1c4f  sub rsp, 0x08
00007871bd3e1c53  push rax
00007871bd3e1c54  push rcx
00007871bd3e1c55  push rdx
00007871bd3e1c56  push rdi
00007871bd3e1c57  push rsi
00007871bd3e1c58  push r8
00007871bd3e1c5a  push r9
00007871bd3e1c5c  push r10
00007871bd3e1c5e  push r11
00007871bd3e1c60  sub rsp, 0xF0
00007871bd3e1c67  vmovaps [rsp], xmm0
00007871bd3e1c6c  vmovaps [rsp+0x10], xmm1
00007871bd3e1c72  vmovaps [rsp+0x20], xmm2
00007871bd3e1c78  vmovaps [rsp+0x30], xmm3
00007871bd3e1c7e  vmovaps [rsp+0x40], xmm4
00007871bd3e1c84  vmovaps [rsp+0x50], xmm5
00007871bd3e1c8a  vmovaps [rsp+0x60], xmm6
00007871bd3e1c90  vmovaps [rsp+0x70], xmm7
00007871bd3e1c96  vmovaps [rsp+0x80], xmm8
00007871bd3e1c9f  vmovaps [rsp+0x90], xmm9
00007871bd3e1ca8  vmovaps [rsp+0xA0], xmm10
00007871bd3e1cb1  vmovaps [rsp+0xB0], xmm11
00007871bd3e1cba  vmovaps [rsp+0xC0], xmm12
00007871bd3e1cc3  vmovaps [rsp+0xD0], xmm13
00007871bd3e1ccc  vmovaps [rsp+0xE0], xmm14
00007871bd3e1cd5  sub rsp, 0x30
00007871bd3e1cd9  movaps [rsp], xmm15
00007871bd3e1cde  movaps [rsp+0x10], xmm14
00007871bd3e1ce4  movaps [rsp+0x20], xmm4
00007871bd3e1ce9  lea rdi, [rsp]
00007871bd3e1ced  mov esi, 0x00
00007871bd3e1cf2  mov rax, 0x5BA2FDD2A530
00007871bd3e1cfc  call rax
00007871bd3e1cfe  movaps xmm15, [rsp]
00007871bd3e1d03  add rsp, 0x30
00007871bd3e1d07  vmovaps xmm0, [rsp]
00007871bd3e1d0c  vmovaps xmm1, [rsp+0x10]
00007871bd3e1d12  vmovaps xmm2, [rsp+0x20]
00007871bd3e1d18  vmovaps xmm3, [rsp+0x30]
00007871bd3e1d1e  vmovaps xmm4, [rsp+0x40]
00007871bd3e1d24  vmovaps xmm5, [rsp+0x50]
00007871bd3e1d2a  vmovaps xmm6, [rsp+0x60]
00007871bd3e1d30  vmovaps xmm7, [rsp+0x70]
00007871bd3e1d36  vmovaps xmm8, [rsp+0x80]
00007871bd3e1d3f  vmovaps xmm9, [rsp+0x90]
00007871bd3e1d48  vmovaps xmm10, [rsp+0xA0]
00007871bd3e1d51  vmovaps xmm11, [rsp+0xB0]
00007871bd3e1d5a  vmovaps xmm12, [rsp+0xC0]
00007871bd3e1d63  vmovaps xmm13, [rsp+0xD0]
00007871bd3e1d6c  vmovaps xmm14, [rsp+0xE0]
00007871bd3e1d75  add rsp, 0xF0
00007871bd3e1d7c  pop r11
00007871bd3e1d7e  pop r10
00007871bd3e1d80  pop r9
00007871bd3e1d82  pop r8
00007871bd3e1d84  pop rsi
00007871bd3e1d85  pop rdi
00007871bd3e1d86  pop rdx
00007871bd3e1d87  pop rcx
00007871bd3e1d88  pop rax
00007871bd3e1d89  add rsp, 0x08
00007871bd3e1d8d  jmp 0x00007871BD3DF48A
00007871bd3e1d92  sub rsp, 0x08
00007871bd3e1d96  push rax
00007871bd3e1d97  push rcx
00007871bd3e1d98  push rdx
00007871bd3e1d99  push rdi
00007871bd3e1d9a  push rsi
00007871bd3e1d9b  push r8
00007871bd3e1d9d  push r9
00007871bd3e1d9f  push r10
00007871bd3e1da1  push r11
00007871bd3e1da3  sub rsp, 0xF0
00007871bd3e1daa  vmovaps [rsp], xmm0
00007871bd3e1daf  vmovaps [rsp+0x10], xmm1
00007871bd3e1db5  vmovaps [rsp+0x20], xmm2
00007871bd3e1dbb  vmovaps [rsp+0x30], xmm3
00007871bd3e1dc1  vmovaps [rsp+0x40], xmm4
00007871bd3e1dc7  vmovaps [rsp+0x50], xmm5
00007871bd3e1dcd  vmovaps [rsp+0x60], xmm6
00007871bd3e1dd3  vmovaps [rsp+0x70], xmm7
00007871bd3e1dd9  vmovaps [rsp+0x80], xmm8
00007871bd3e1de2  vmovaps [rsp+0x90], xmm9
00007871bd3e1deb  vmovaps [rsp+0xA0], xmm10
00007871bd3e1df4  vmovaps [rsp+0xB0], xmm11
00007871bd3e1dfd  vmovaps [rsp+0xC0], xmm12
00007871bd3e1e06  vmovaps [rsp+0xD0], xmm13
00007871bd3e1e0f  vmovaps [rsp+0xE0], xmm15
00007871bd3e1e18  sub rsp, 0x30
00007871bd3e1e1c  movaps [rsp], xmm14
00007871bd3e1e21  movaps [rsp+0x10], xmm2
00007871bd3e1e26  movaps [rsp+0x20], xmm1
00007871bd3e1e2b  lea rdi, [rsp]
00007871bd3e1e2f  mov esi, 0x00
00007871bd3e1e34  mov rax, 0x5BA2FDD2A530
00007871bd3e1e3e  call rax
00007871bd3e1e40  movaps xmm14, [rsp]
00007871bd3e1e45  add rsp, 0x30
00007871bd3e1e49  vmovaps xmm0, [rsp]
00007871bd3e1e4e  vmovaps xmm1, [rsp+0x10]
00007871bd3e1e54  vmovaps xmm2, [rsp+0x20]
00007871bd3e1e5a  vmovaps xmm3, [rsp+0x30]
00007871bd3e1e60  vmovaps xmm4, [rsp+0x40]
00007871bd3e1e66  vmovaps xmm5, [rsp+0x50]
00007871bd3e1e6c  vmovaps xmm6, [rsp+0x60]
00007871bd3e1e72  vmovaps xmm7, [rsp+0x70]
00007871bd3e1e78  vmovaps xmm8, [rsp+0x80]
00007871bd3e1e81  vmovaps xmm9, [rsp+0x90]
00007871bd3e1e8a  vmovaps xmm10, [rsp+0xA0]
00007871bd3e1e93  vmovaps xmm11, [rsp+0xB0]
00007871bd3e1e9c  vmovaps xmm12, [rsp+0xC0]
00007871bd3e1ea5  vmovaps xmm13, [rsp+0xD0]
00007871bd3e1eae  vmovaps xmm15, [rsp+0xE0]
00007871bd3e1eb7  add rsp, 0xF0
00007871bd3e1ebe  pop r11
00007871bd3e1ec0  pop r10
00007871bd3e1ec2  pop r9
00007871bd3e1ec4  pop r8
00007871bd3e1ec6  pop rsi
00007871bd3e1ec7  pop rdi
00007871bd3e1ec8  pop rdx
00007871bd3e1ec9  pop rcx
00007871bd3e1eca  pop rax
00007871bd3e1ecb  add rsp, 0x08
00007871bd3e1ecf  jmp 0x00007871BD3DF4B0
00007871bd3e1ed4  sub rsp, 0x08
00007871bd3e1ed8  push rax
00007871bd3e1ed9  push rcx
00007871bd3e1eda  push rdx
00007871bd3e1edb  push rdi
00007871bd3e1edc  push rsi
00007871bd3e1edd  push r8
00007871bd3e1edf  push r9
00007871bd3e1ee1  push r10
00007871bd3e1ee3  push r11
00007871bd3e1ee5  sub rsp, 0xF0
00007871bd3e1eec  vmovaps [rsp], xmm0
00007871bd3e1ef1  vmovaps [rsp+0x10], xmm2
00007871bd3e1ef7  vmovaps [rsp+0x20], xmm3
00007871bd3e1efd  vmovaps [rsp+0x30], xmm4
00007871bd3e1f03  vmovaps [rsp+0x40], xmm5
00007871bd3e1f09  vmovaps [rsp+0x50], xmm6
00007871bd3e1f0f  vmovaps [rsp+0x60], xmm7
00007871bd3e1f15  vmovaps [rsp+0x70], xmm8
00007871bd3e1f1b  vmovaps [rsp+0x80], xmm9
00007871bd3e1f24  vmovaps [rsp+0x90], xmm10
00007871bd3e1f2d  vmovaps [rsp+0xA0], xmm11
00007871bd3e1f36  vmovaps [rsp+0xB0], xmm12
00007871bd3e1f3f  vmovaps [rsp+0xC0], xmm13
00007871bd3e1f48  vmovaps [rsp+0xD0], xmm14
00007871bd3e1f51  vmovaps [rsp+0xE0], xmm15
00007871bd3e1f5a  sub rsp, 0x30
00007871bd3e1f5e  movaps [rsp], xmm1
00007871bd3e1f62  movaps [rsp+0x10], xmm4
00007871bd3e1f67  movaps [rsp+0x20], xmm9
00007871bd3e1f6d  lea rdi, [rsp]
00007871bd3e1f71  mov esi, 0x00
00007871bd3e1f76  mov rax, 0x5BA2FDD2A530
00007871bd3e1f80  call rax
00007871bd3e1f82  movaps xmm1, [rsp]
00007871bd3e1f86  add rsp, 0x30
00007871bd3e1f8a  vmovaps xmm0, [rsp]
00007871bd3e1f8f  vmovaps xmm2, [rsp+0x10]
00007871bd3e1f95  vmovaps xmm3, [rsp+0x20]
00007871bd3e1f9b  vmovaps xmm4, [rsp+0x30]
00007871bd3e1fa1  vmovaps xmm5, [rsp+0x40]
00007871bd3e1fa7  vmovaps xmm6, [rsp+0x50]
00007871bd3e1fad  vmovaps xmm7, [rsp+0x60]
00007871bd3e1fb3  vmovaps xmm8, [rsp+0x70]
00007871bd3e1fb9  vmovaps xmm9, [rsp+0x80]
00007871bd3e1fc2  vmovaps xmm10, [rsp+0x90]
00007871bd3e1fcb  vmovaps xmm11, [rsp+0xA0]
00007871bd3e1fd4  vmovaps xmm12, [rsp+0xB0]
00007871bd3e1fdd  vmovaps xmm13, [rsp+0xC0]
00007871bd3e1fe6  vmovaps xmm14, [rsp+0xD0]
00007871bd3e1fef  vmovaps xmm15, [rsp+0xE0]
00007871bd3e1ff8  add rsp, 0xF0
00007871bd3e1fff  pop r11
00007871bd3e2001  pop r10
00007871bd3e2003  pop r9
00007871bd3e2005  pop r8
00007871bd3e2007  pop rsi
00007871bd3e2008  pop rdi
00007871bd3e2009  pop rdx
00007871bd3e200a  pop rcx
00007871bd3e200b  pop rax
00007871bd3e200c  add rsp, 0x08
00007871bd3e2010  jmp 0x00007871BD3DF4CE
00007871bd3e2015  sub rsp, 0x08
00007871bd3e2019  push rax
00007871bd3e201a  push rcx
00007871bd3e201b  push rdx
00007871bd3e201c  push rdi
00007871bd3e201d  push rsi
00007871bd3e201e  push r8
00007871bd3e2020  push r9
00007871bd3e2022  push r10
00007871bd3e2024  push r11
00007871bd3e2026  sub rsp, 0xF0
00007871bd3e202d  vmovaps [rsp], xmm0
00007871bd3e2032  vmovaps [rsp+0x10], xmm1
00007871bd3e2038  vmovaps [rsp+0x20], xmm2
00007871bd3e203e  vmovaps [rsp+0x30], xmm3
00007871bd3e2044  vmovaps [rsp+0x40], xmm5
00007871bd3e204a  vmovaps [rsp+0x50], xmm6
00007871bd3e2050  vmovaps [rsp+0x60], xmm7
00007871bd3e2056  vmovaps [rsp+0x70], xmm8
00007871bd3e205c  vmovaps [rsp+0x80], xmm9
00007871bd3e2065  vmovaps [rsp+0x90], xmm10
00007871bd3e206e  vmovaps [rsp+0xA0], xmm11
00007871bd3e2077  vmovaps [rsp+0xB0], xmm12
00007871bd3e2080  vmovaps [rsp+0xC0], xmm13
00007871bd3e2089  vmovaps [rsp+0xD0], xmm14
00007871bd3e2092  vmovaps [rsp+0xE0], xmm15
00007871bd3e209b  sub rsp, 0x30
00007871bd3e209f  movaps [rsp], xmm4
00007871bd3e20a3  movaps [rsp+0x10], xmm2
00007871bd3e20a8  movaps [rsp+0x20], xmm9
00007871bd3e20ae  lea rdi, [rsp]
00007871bd3e20b2  mov esi, 0x00
00007871bd3e20b7  mov rax, 0x5BA2FDD2A530
00007871bd3e20c1  call rax
00007871bd3e20c3  movaps xmm4, [rsp]
00007871bd3e20c7  add rsp, 0x30
00007871bd3e20cb  vmovaps xmm0, [rsp]
00007871bd3e20d0  vmovaps xmm1, [rsp+0x10]
00007871bd3e20d6  vmovaps xmm2, [rsp+0x20]
00007871bd3e20dc  vmovaps xmm3, [rsp+0x30]
00007871bd3e20e2  vmovaps xmm5, [rsp+0x40]
00007871bd3e20e8  vmovaps xmm6, [rsp+0x50]
00007871bd3e20ee  vmovaps xmm7, [rsp+0x60]
00007871bd3e20f4  vmovaps xmm8, [rsp+0x70]
00007871bd3e20fa  vmovaps xmm9, [rsp+0x80]
00007871bd3e2103  vmovaps xmm10, [rsp+0x90]
00007871bd3e210c  vmovaps xmm11, [rsp+0xA0]
00007871bd3e2115  vmovaps xmm12, [rsp+0xB0]
00007871bd3e211e  vmovaps xmm13, [rsp+0xC0]
00007871bd3e2127  vmovaps xmm14, [rsp+0xD0]
00007871bd3e2130  vmovaps xmm15, [rsp+0xE0]
00007871bd3e2139  add rsp, 0xF0
00007871bd3e2140  pop r11
00007871bd3e2142  pop r10
00007871bd3e2144  pop r9
00007871bd3e2146  pop r8
00007871bd3e2148  pop rsi
00007871bd3e2149  pop rdi
00007871bd3e214a  pop rdx
00007871bd3e214b  pop rcx
00007871bd3e214c  pop rax
00007871bd3e214d  add rsp, 0x08
00007871bd3e2151  jmp 0x00007871BD3DF4FE
00007871bd3e2156  sub rsp, 0x08
00007871bd3e215a  push rax
00007871bd3e215b  push rcx
00007871bd3e215c  push rdx
00007871bd3e215d  push rdi
00007871bd3e215e  push rsi
00007871bd3e215f  push r8
00007871bd3e2161  push r9
00007871bd3e2163  push r10
00007871bd3e2165  push r11
00007871bd3e2167  sub rsp, 0xF0
00007871bd3e216e  vmovaps [rsp], xmm0
00007871bd3e2173  vmovaps [rsp+0x10], xmm1
00007871bd3e2179  vmovaps [rsp+0x20], xmm2
00007871bd3e217f  vmovaps [rsp+0x30], xmm3
00007871bd3e2185  vmovaps [rsp+0x40], xmm4
00007871bd3e218b  vmovaps [rsp+0x50], xmm5
00007871bd3e2191  vmovaps [rsp+0x60], xmm6
00007871bd3e2197  vmovaps [rsp+0x70], xmm7
00007871bd3e219d  vmovaps [rsp+0x80], xmm8
00007871bd3e21a6  vmovaps [rsp+0x90], xmm10
00007871bd3e21af  vmovaps [rsp+0xA0], xmm11
00007871bd3e21b8  vmovaps [rsp+0xB0], xmm12
00007871bd3e21c1  vmovaps [rsp+0xC0], xmm13
00007871bd3e21ca  vmovaps [rsp+0xD0], xmm14
00007871bd3e21d3  vmovaps [rsp+0xE0], xmm15
00007871bd3e21dc  sub rsp, 0x30
00007871bd3e21e0  movaps [rsp], xmm9
00007871bd3e21e5  movaps [rsp+0x10], xmm2
00007871bd3e21ea  movaps [rsp+0x20], xmm1
00007871bd3e21ef  lea rdi, [rsp]
00007871bd3e21f3  mov esi, 0x00
00007871bd3e21f8  mov rax, 0x5BA2FDD2A530
00007871bd3e2202  call rax
00007871bd3e2204  movaps xmm9, [rsp]
00007871bd3e2209  add rsp, 0x30
00007871bd3e220d  vmovaps xmm0, [rsp]
00007871bd3e2212  vmovaps xmm1, [rsp+0x10]
00007871bd3e2218  vmovaps xmm2, [rsp+0x20]
00007871bd3e221e  vmovaps xmm3, [rsp+0x30]
00007871bd3e2224  vmovaps xmm4, [rsp+0x40]
00007871bd3e222a  vmovaps xmm5, [rsp+0x50]
00007871bd3e2230  vmovaps xmm6, [rsp+0x60]
00007871bd3e2236  vmovaps xmm7, [rsp+0x70]
00007871bd3e223c  vmovaps xmm8, [rsp+0x80]
00007871bd3e2245  vmovaps xmm10, [rsp+0x90]
00007871bd3e224e  vmovaps xmm11, [rsp+0xA0]
00007871bd3e2257  vmovaps xmm12, [rsp+0xB0]
00007871bd3e2260  vmovaps xmm13, [rsp+0xC0]
00007871bd3e2269  vmovaps xmm14, [rsp+0xD0]
00007871bd3e2272  vmovaps xmm15, [rsp+0xE0]
00007871bd3e227b  add rsp, 0xF0
00007871bd3e2282  pop r11
00007871bd3e2284  pop r10
00007871bd3e2286  pop r9
00007871bd3e2288  pop r8
00007871bd3e228a  pop rsi
00007871bd3e228b  pop rdi
00007871bd3e228c  pop rdx
00007871bd3e228d  pop rcx
00007871bd3e228e  pop rax
00007871bd3e228f  add rsp, 0x08
00007871bd3e2293  jmp 0x00007871BD3DF534
00007871bd3e2298  sub rsp, 0x08
00007871bd3e229c  push rax
00007871bd3e229d  push rcx
00007871bd3e229e  push rdx
00007871bd3e229f  push rdi
00007871bd3e22a0  push rsi
00007871bd3e22a1  push r8
00007871bd3e22a3  push r9
00007871bd3e22a5  push r10
00007871bd3e22a7  push r11
00007871bd3e22a9  sub rsp, 0xF0
00007871bd3e22b0  vmovaps [rsp], xmm0
00007871bd3e22b5  vmovaps [rsp+0x10], xmm2
00007871bd3e22bb  vmovaps [rsp+0x20], xmm3
00007871bd3e22c1  vmovaps [rsp+0x30], xmm4
00007871bd3e22c7  vmovaps [rsp+0x40], xmm5
00007871bd3e22cd  vmovaps [rsp+0x50], xmm6
00007871bd3e22d3  vmovaps [rsp+0x60], xmm7
00007871bd3e22d9  vmovaps [rsp+0x70], xmm8
00007871bd3e22df  vmovaps [rsp+0x80], xmm9
00007871bd3e22e8  vmovaps [rsp+0x90], xmm10
00007871bd3e22f1  vmovaps [rsp+0xA0], xmm11
00007871bd3e22fa  vmovaps [rsp+0xB0], xmm12
00007871bd3e2303  vmovaps [rsp+0xC0], xmm13
00007871bd3e230c  vmovaps [rsp+0xD0], xmm14
00007871bd3e2315  vmovaps [rsp+0xE0], xmm15
00007871bd3e231e  sub rsp, 0x30
00007871bd3e2322  movaps [rsp], xmm1
00007871bd3e2326  movaps [rsp+0x10], xmm15
00007871bd3e232c  movaps [rsp+0x20], xmm6
00007871bd3e2331  lea rdi, [rsp]
00007871bd3e2335  mov esi, 0x00
00007871bd3e233a  mov rax, 0x5BA2FDD2A530
00007871bd3e2344  call rax
00007871bd3e2346  movaps xmm1, [rsp]
00007871bd3e234a  add rsp, 0x30
00007871bd3e234e  vmovaps xmm0, [rsp]
00007871bd3e2353  vmovaps xmm2, [rsp+0x10]
00007871bd3e2359  vmovaps xmm3, [rsp+0x20]
00007871bd3e235f  vmovaps xmm4, [rsp+0x30]
00007871bd3e2365  vmovaps xmm5, [rsp+0x40]
00007871bd3e236b  vmovaps xmm6, [rsp+0x50]
00007871bd3e2371  vmovaps xmm7, [rsp+0x60]
00007871bd3e2377  vmovaps xmm8, [rsp+0x70]
00007871bd3e237d  vmovaps xmm9, [rsp+0x80]
00007871bd3e2386  vmovaps xmm10, [rsp+0x90]
00007871bd3e238f  vmovaps xmm11, [rsp+0xA0]
00007871bd3e2398  vmovaps xmm12, [rsp+0xB0]
00007871bd3e23a1  vmovaps xmm13, [rsp+0xC0]
00007871bd3e23aa  vmovaps xmm14, [rsp+0xD0]
00007871bd3e23b3  vmovaps xmm15, [rsp+0xE0]
00007871bd3e23bc  add rsp, 0xF0
00007871bd3e23c3  pop r11
00007871bd3e23c5  pop r10
00007871bd3e23c7  pop r9
00007871bd3e23c9  pop r8
00007871bd3e23cb  pop rsi
00007871bd3e23cc  pop rdi
00007871bd3e23cd  pop rdx
00007871bd3e23ce  pop rcx
00007871bd3e23cf  pop rax
00007871bd3e23d0  add rsp, 0x08
00007871bd3e23d4  jmp 0x00007871BD3DF555
00007871bd3e23d9  sub rsp, 0x08
00007871bd3e23dd  push rax
00007871bd3e23de  push rcx
00007871bd3e23df  push rdx
00007871bd3e23e0  push rdi
00007871bd3e23e1  push rsi
00007871bd3e23e2  push r8
00007871bd3e23e4  push r9
00007871bd3e23e6  push r10
00007871bd3e23e8  push r11
00007871bd3e23ea  sub rsp, 0xF0
00007871bd3e23f1  vmovaps [rsp], xmm0
00007871bd3e23f6  vmovaps [rsp+0x10], xmm1
00007871bd3e23fc  vmovaps [rsp+0x20], xmm2
00007871bd3e2402  vmovaps [rsp+0x30], xmm3
00007871bd3e2408  vmovaps [rsp+0x40], xmm4
00007871bd3e240e  vmovaps [rsp+0x50], xmm5
00007871bd3e2414  vmovaps [rsp+0x60], xmm6
00007871bd3e241a  vmovaps [rsp+0x70], xmm7
00007871bd3e2420  vmovaps [rsp+0x80], xmm8
00007871bd3e2429  vmovaps [rsp+0x90], xmm9
00007871bd3e2432  vmovaps [rsp+0xA0], xmm10
00007871bd3e243b  vmovaps [rsp+0xB0], xmm11
00007871bd3e2444  vmovaps [rsp+0xC0], xmm12
00007871bd3e244d  vmovaps [rsp+0xD0], xmm13
00007871bd3e2456  vmovaps [rsp+0xE0], xmm14
00007871bd3e245f  sub rsp, 0x30
00007871bd3e2463  movaps [rsp], xmm15
00007871bd3e2468  movaps [rsp+0x10], xmm5
00007871bd3e246d  movaps [rsp+0x20], xmm3
00007871bd3e2472  lea rdi, [rsp]
00007871bd3e2476  mov esi, 0x00
00007871bd3e247b  mov rax, 0x5BA2FDD2A530
00007871bd3e2485  call rax
00007871bd3e2487  movaps xmm15, [rsp]
00007871bd3e248c  add rsp, 0x30
00007871bd3e2490  vmovaps xmm0, [rsp]
00007871bd3e2495  vmovaps xmm1, [rsp+0x10]
00007871bd3e249b  vmovaps xmm2, [rsp+0x20]
00007871bd3e24a1  vmovaps xmm3, [rsp+0x30]
00007871bd3e24a7  vmovaps xmm4, [rsp+0x40]
00007871bd3e24ad  vmovaps xmm5, [rsp+0x50]
00007871bd3e24b3  vmovaps xmm6, [rsp+0x60]
00007871bd3e24b9  vmovaps xmm7, [rsp+0x70]
00007871bd3e24bf  vmovaps xmm8, [rsp+0x80]
00007871bd3e24c8  vmovaps xmm9, [rsp+0x90]
00007871bd3e24d1  vmovaps xmm10, [rsp+0xA0]
00007871bd3e24da  vmovaps xmm11, [rsp+0xB0]
00007871bd3e24e3  vmovaps xmm12, [rsp+0xC0]
00007871bd3e24ec  vmovaps xmm13, [rsp+0xD0]
00007871bd3e24f5  vmovaps xmm14, [rsp+0xE0]
00007871bd3e24fe  add rsp, 0xF0
00007871bd3e2505  pop r11
00007871bd3e2507  pop r10
00007871bd3e2509  pop r9
00007871bd3e250b  pop r8
00007871bd3e250d  pop rsi
00007871bd3e250e  pop rdi
00007871bd3e250f  pop rdx
00007871bd3e2510  pop rcx
00007871bd3e2511  pop rax
00007871bd3e2512  add rsp, 0x08
00007871bd3e2516  jmp 0x00007871BD3DF56F
00007871bd3e251b  sub rsp, 0x08
00007871bd3e251f  push rax
00007871bd3e2520  push rcx
00007871bd3e2521  push rdx
00007871bd3e2522  push rdi
00007871bd3e2523  push rsi
00007871bd3e2524  push r8
00007871bd3e2526  push r9
00007871bd3e2528  push r10
00007871bd3e252a  push r11
00007871bd3e252c  sub rsp, 0xF0
00007871bd3e2533  vmovaps [rsp], xmm0
00007871bd3e2538  vmovaps [rsp+0x10], xmm1
00007871bd3e253e  vmovaps [rsp+0x20], xmm2
00007871bd3e2544  vmovaps [rsp+0x30], xmm3
00007871bd3e254a  vmovaps [rsp+0x40], xmm4
00007871bd3e2550  vmovaps [rsp+0x50], xmm6
00007871bd3e2556  vmovaps [rsp+0x60], xmm7
00007871bd3e255c  vmovaps [rsp+0x70], xmm8
00007871bd3e2562  vmovaps [rsp+0x80], xmm9
00007871bd3e256b  vmovaps [rsp+0x90], xmm10
00007871bd3e2574  vmovaps [rsp+0xA0], xmm11
00007871bd3e257d  vmovaps [rsp+0xB0], xmm12
00007871bd3e2586  vmovaps [rsp+0xC0], xmm13
00007871bd3e258f  vmovaps [rsp+0xD0], xmm14
00007871bd3e2598  vmovaps [rsp+0xE0], xmm15
00007871bd3e25a1  sub rsp, 0x30
00007871bd3e25a5  movaps [rsp], xmm5
00007871bd3e25a9  movaps [rsp+0x10], xmm8
00007871bd3e25af  movaps [rsp+0x20], xmm6
00007871bd3e25b4  lea rdi, [rsp]
00007871bd3e25b8  mov esi, 0x00
00007871bd3e25bd  mov rax, 0x5BA2FDD2A530
00007871bd3e25c7  call rax
00007871bd3e25c9  movaps xmm5, [rsp]
00007871bd3e25cd  add rsp, 0x30
00007871bd3e25d1  vmovaps xmm0, [rsp]
00007871bd3e25d6  vmovaps xmm1, [rsp+0x10]
00007871bd3e25dc  vmovaps xmm2, [rsp+0x20]
00007871bd3e25e2  vmovaps xmm3, [rsp+0x30]
00007871bd3e25e8  vmovaps xmm4, [rsp+0x40]
00007871bd3e25ee  vmovaps xmm6, [rsp+0x50]
00007871bd3e25f4  vmovaps xmm7, [rsp+0x60]
00007871bd3e25fa  vmovaps xmm8, [rsp+0x70]
00007871bd3e2600  vmovaps xmm9, [rsp+0x80]
00007871bd3e2609  vmovaps xmm10, [rsp+0x90]
00007871bd3e2612  vmovaps xmm11, [rsp+0xA0]
00007871bd3e261b  vmovaps xmm12, [rsp+0xB0]
00007871bd3e2624  vmovaps xmm13, [rsp+0xC0]
00007871bd3e262d  vmovaps xmm14, [rsp+0xD0]
00007871bd3e2636  vmovaps xmm15, [rsp+0xE0]
00007871bd3e263f  add rsp, 0xF0
00007871bd3e2646  pop r11
00007871bd3e2648  pop r10
00007871bd3e264a  pop r9
00007871bd3e264c  pop r8
00007871bd3e264e  pop rsi
00007871bd3e264f  pop rdi
00007871bd3e2650  pop rdx
00007871bd3e2651  pop rcx
00007871bd3e2652  pop rax
00007871bd3e2653  add rsp, 0x08
00007871bd3e2657  jmp 0x00007871BD3DF593
00007871bd3e265c  sub rsp, 0x08
00007871bd3e2660  push rax
00007871bd3e2661  push rcx
00007871bd3e2662  push rdx
00007871bd3e2663  push rdi
00007871bd3e2664  push rsi
00007871bd3e2665  push r8
00007871bd3e2667  push r9
00007871bd3e2669  push r10
00007871bd3e266b  push r11
00007871bd3e266d  sub rsp, 0xF0
00007871bd3e2674  vmovaps [rsp], xmm0
00007871bd3e2679  vmovaps [rsp+0x10], xmm1
00007871bd3e267f  vmovaps [rsp+0x20], xmm2
00007871bd3e2685  vmovaps [rsp+0x30], xmm3
00007871bd3e268b  vmovaps [rsp+0x40], xmm4
00007871bd3e2691  vmovaps [rsp+0x50], xmm5
00007871bd3e2697  vmovaps [rsp+0x60], xmm7
00007871bd3e269d  vmovaps [rsp+0x70], xmm8
00007871bd3e26a3  vmovaps [rsp+0x80], xmm9
00007871bd3e26ac  vmovaps [rsp+0x90], xmm10
00007871bd3e26b5  vmovaps [rsp+0xA0], xmm11
00007871bd3e26be  vmovaps [rsp+0xB0], xmm12
00007871bd3e26c7  vmovaps [rsp+0xC0], xmm13
00007871bd3e26d0  vmovaps [rsp+0xD0], xmm14
00007871bd3e26d9  vmovaps [rsp+0xE0], xmm15
00007871bd3e26e2  sub rsp, 0x30
00007871bd3e26e6  movaps [rsp], xmm6
00007871bd3e26ea  movaps [rsp+0x10], xmm10
00007871bd3e26f0  movaps [rsp+0x20], xmm8
00007871bd3e26f6  lea rdi, [rsp]
00007871bd3e26fa  mov esi, 0x00
00007871bd3e26ff  mov rax, 0x5BA2FDD2A530
00007871bd3e2709  call rax
00007871bd3e270b  movaps xmm6, [rsp]
00007871bd3e270f  add rsp, 0x30
00007871bd3e2713  vmovaps xmm0, [rsp]
00007871bd3e2718  vmovaps xmm1, [rsp+0x10]
00007871bd3e271e  vmovaps xmm2, [rsp+0x20]
00007871bd3e2724  vmovaps xmm3, [rsp+0x30]
00007871bd3e272a  vmovaps xmm4, [rsp+0x40]
00007871bd3e2730  vmovaps xmm5, [rsp+0x50]
00007871bd3e2736  vmovaps xmm7, [rsp+0x60]
00007871bd3e273c  vmovaps xmm8, [rsp+0x70]
00007871bd3e2742  vmovaps xmm9, [rsp+0x80]
00007871bd3e274b  vmovaps xmm10, [rsp+0x90]
00007871bd3e2754  vmovaps xmm11, [rsp+0xA0]
00007871bd3e275d  vmovaps xmm12, [rsp+0xB0]
00007871bd3e2766  vmovaps xmm13, [rsp+0xC0]
00007871bd3e276f  vmovaps xmm14, [rsp+0xD0]
00007871bd3e2778  vmovaps xmm15, [rsp+0xE0]
00007871bd3e2781  add rsp, 0xF0
00007871bd3e2788  pop r11
00007871bd3e278a  pop r10
00007871bd3e278c  pop r9
00007871bd3e278e  pop r8
00007871bd3e2790  pop rsi
00007871bd3e2791  pop rdi
00007871bd3e2792  pop rdx
00007871bd3e2793  pop rcx
00007871bd3e2794  pop rax
00007871bd3e2795  add rsp, 0x08
00007871bd3e2799  jmp 0x00007871BD3DF5B8
00007871bd3e279e  sub rsp, 0x08
00007871bd3e27a2  push rax
00007871bd3e27a3  push rcx
00007871bd3e27a4  push rdx
00007871bd3e27a5  push rdi
00007871bd3e27a6  push rsi
00007871bd3e27a7  push r8
00007871bd3e27a9  push r9
00007871bd3e27ab  push r10
00007871bd3e27ad  push r11
00007871bd3e27af  sub rsp, 0xF0
00007871bd3e27b6  vmovaps [rsp], xmm0
00007871bd3e27bb  vmovaps [rsp+0x10], xmm1
00007871bd3e27c1  vmovaps [rsp+0x20], xmm2
00007871bd3e27c7  vmovaps [rsp+0x30], xmm3
00007871bd3e27cd  vmovaps [rsp+0x40], xmm4
00007871bd3e27d3  vmovaps [rsp+0x50], xmm5
00007871bd3e27d9  vmovaps [rsp+0x60], xmm6
00007871bd3e27df  vmovaps [rsp+0x70], xmm7
00007871bd3e27e5  vmovaps [rsp+0x80], xmm8
00007871bd3e27ee  vmovaps [rsp+0x90], xmm9
00007871bd3e27f7  vmovaps [rsp+0xA0], xmm11
00007871bd3e2800  vmovaps [rsp+0xB0], xmm12
00007871bd3e2809  vmovaps [rsp+0xC0], xmm13
00007871bd3e2812  vmovaps [rsp+0xD0], xmm14
00007871bd3e281b  vmovaps [rsp+0xE0], xmm15
00007871bd3e2824  sub rsp, 0x30
00007871bd3e2828  movaps [rsp], xmm10
00007871bd3e282d  movaps [rsp+0x10], xmm8
00007871bd3e2833  movaps [rsp+0x20], xmm14
00007871bd3e2839  lea rdi, [rsp]
00007871bd3e283d  mov esi, 0x00
00007871bd3e2842  mov rax, 0x5BA2FDD2A530
00007871bd3e284c  call rax
00007871bd3e284e  movaps xmm10, [rsp]
00007871bd3e2853  add rsp, 0x30
00007871bd3e2857  vmovaps xmm0, [rsp]
00007871bd3e285c  vmovaps xmm1, [rsp+0x10]
00007871bd3e2862  vmovaps xmm2, [rsp+0x20]
00007871bd3e2868  vmovaps xmm3, [rsp+0x30]
00007871bd3e286e  vmovaps xmm4, [rsp+0x40]
00007871bd3e2874  vmovaps xmm5, [rsp+0x50]
00007871bd3e287a  vmovaps xmm6, [rsp+0x60]
00007871bd3e2880  vmovaps xmm7, [rsp+0x70]
00007871bd3e2886  vmovaps xmm8, [rsp+0x80]
00007871bd3e288f  vmovaps xmm9, [rsp+0x90]
00007871bd3e2898  vmovaps xmm11, [rsp+0xA0]
00007871bd3e28a1  vmovaps xmm12, [rsp+0xB0]
00007871bd3e28aa  vmovaps xmm13, [rsp+0xC0]
00007871bd3e28b3  vmovaps xmm14, [rsp+0xD0]
00007871bd3e28bc  vmovaps xmm15, [rsp+0xE0]
00007871bd3e28c5  add rsp, 0xF0
00007871bd3e28cc  pop r11
00007871bd3e28ce  pop r10
00007871bd3e28d0  pop r9
00007871bd3e28d2  pop r8
00007871bd3e28d4  pop rsi
00007871bd3e28d5  pop rdi
00007871bd3e28d6  pop rdx
00007871bd3e28d7  pop rcx
00007871bd3e28d8  pop rax
00007871bd3e28d9  add rsp, 0x08
00007871bd3e28dd  jmp 0x00007871BD3DF5D8
00007871bd3e28e2  sub rsp, 0x08
00007871bd3e28e6  push rax
00007871bd3e28e7  push rcx
00007871bd3e28e8  push rdx
00007871bd3e28e9  push rdi
00007871bd3e28ea  push rsi
00007871bd3e28eb  push r8
00007871bd3e28ed  push r9
00007871bd3e28ef  push r10
00007871bd3e28f1  push r11
00007871bd3e28f3  sub rsp, 0xF0
00007871bd3e28fa  vmovaps [rsp], xmm0
00007871bd3e28ff  vmovaps [rsp+0x10], xmm1
00007871bd3e2905  vmovaps [rsp+0x20], xmm2
00007871bd3e290b  vmovaps [rsp+0x30], xmm3
00007871bd3e2911  vmovaps [rsp+0x40], xmm4
00007871bd3e2917  vmovaps [rsp+0x50], xmm5
00007871bd3e291d  vmovaps [rsp+0x60], xmm6
00007871bd3e2923  vmovaps [rsp+0x70], xmm7
00007871bd3e2929  vmovaps [rsp+0x80], xmm8
00007871bd3e2932  vmovaps [rsp+0x90], xmm9
00007871bd3e293b  vmovaps [rsp+0xA0], xmm10
00007871bd3e2944  vmovaps [rsp+0xB0], xmm11
00007871bd3e294d  vmovaps [rsp+0xC0], xmm12
00007871bd3e2956  vmovaps [rsp+0xD0], xmm13
00007871bd3e295f  vmovaps [rsp+0xE0], xmm15
00007871bd3e2968  sub rsp, 0x30
00007871bd3e296c  movaps [rsp], xmm14
00007871bd3e2971  movaps [rsp+0x10], xmm8
00007871bd3e2977  movaps [rsp+0x20], xmm4
00007871bd3e297c  lea rdi, [rsp]
00007871bd3e2980  mov esi, 0x00
00007871bd3e2985  mov rax, 0x5BA2FDD2A530
00007871bd3e298f  call rax
00007871bd3e2991  movaps xmm14, [rsp]
00007871bd3e2996  add rsp, 0x30
00007871bd3e299a  vmovaps xmm0, [rsp]
00007871bd3e299f  vmovaps xmm1, [rsp+0x10]
00007871bd3e29a5  vmovaps xmm2, [rsp+0x20]
00007871bd3e29ab  vmovaps xmm3, [rsp+0x30]
00007871bd3e29b1  vmovaps xmm4, [rsp+0x40]
00007871bd3e29b7  vmovaps xmm5, [rsp+0x50]
00007871bd3e29bd  vmovaps xmm6, [rsp+0x60]
00007871bd3e29c3  vmovaps xmm7, [rsp+0x70]
00007871bd3e29c9  vmovaps xmm8, [rsp+0x80]
00007871bd3e29d2  vmovaps xmm9, [rsp+0x90]
00007871bd3e29db  vmovaps xmm10, [rsp+0xA0]
00007871bd3e29e4  vmovaps xmm11, [rsp+0xB0]
00007871bd3e29ed  vmovaps xmm12, [rsp+0xC0]
00007871bd3e29f6  vmovaps xmm13, [rsp+0xD0]
00007871bd3e29ff  vmovaps xmm15, [rsp+0xE0]
00007871bd3e2a08  add rsp, 0xF0
00007871bd3e2a0f  pop r11
00007871bd3e2a11  pop r10
00007871bd3e2a13  pop r9
00007871bd3e2a15  pop r8
00007871bd3e2a17  pop rsi
00007871bd3e2a18  pop rdi
00007871bd3e2a19  pop rdx
00007871bd3e2a1a  pop rcx
00007871bd3e2a1b  pop rax
00007871bd3e2a1c  add rsp, 0x08
00007871bd3e2a20  jmp 0x00007871BD3DF5F8
00007871bd3e2a25  sub rsp, 0x08
00007871bd3e2a29  push rax
00007871bd3e2a2a  push rcx
00007871bd3e2a2b  push rdx
00007871bd3e2a2c  push rdi
00007871bd3e2a2d  push rsi
00007871bd3e2a2e  push r8
00007871bd3e2a30  push r9
00007871bd3e2a32  push r10
00007871bd3e2a34  push r11
00007871bd3e2a36  sub rsp, 0xF0
00007871bd3e2a3d  vmovaps [rsp], xmm0
00007871bd3e2a42  vmovaps [rsp+0x10], xmm1
00007871bd3e2a48  vmovaps [rsp+0x20], xmm2
00007871bd3e2a4e  vmovaps [rsp+0x30], xmm3
00007871bd3e2a54  vmovaps [rsp+0x40], xmm5
00007871bd3e2a5a  vmovaps [rsp+0x50], xmm6
00007871bd3e2a60  vmovaps [rsp+0x60], xmm7
00007871bd3e2a66  vmovaps [rsp+0x70], xmm8
00007871bd3e2a6c  vmovaps [rsp+0x80], xmm9
00007871bd3e2a75  vmovaps [rsp+0x90], xmm10
00007871bd3e2a7e  vmovaps [rsp+0xA0], xmm11
00007871bd3e2a87  vmovaps [rsp+0xB0], xmm12
00007871bd3e2a90  vmovaps [rsp+0xC0], xmm13
00007871bd3e2a99  vmovaps [rsp+0xD0], xmm14
00007871bd3e2aa2  vmovaps [rsp+0xE0], xmm15
00007871bd3e2aab  sub rsp, 0x30
00007871bd3e2aaf  movaps [rsp], xmm4
00007871bd3e2ab3  movaps [rsp+0x10], xmm13
00007871bd3e2ab9  movaps [rsp+0x20], xmm8
00007871bd3e2abf  lea rdi, [rsp]
00007871bd3e2ac3  mov esi, 0x00
00007871bd3e2ac8  mov rax, 0x5BA2FDD2A530
00007871bd3e2ad2  call rax
00007871bd3e2ad4  movaps xmm4, [rsp]
00007871bd3e2ad8  add rsp, 0x30
00007871bd3e2adc  vmovaps xmm0, [rsp]
00007871bd3e2ae1  vmovaps xmm1, [rsp+0x10]
00007871bd3e2ae7  vmovaps xmm2, [rsp+0x20]
00007871bd3e2aed  vmovaps xmm3, [rsp+0x30]
00007871bd3e2af3  vmovaps xmm5, [rsp+0x40]
00007871bd3e2af9  vmovaps xmm6, [rsp+0x50]
00007871bd3e2aff  vmovaps xmm7, [rsp+0x60]
00007871bd3e2b05  vmovaps xmm8, [rsp+0x70]
00007871bd3e2b0b  vmovaps xmm9, [rsp+0x80]
00007871bd3e2b14  vmovaps xmm10, [rsp+0x90]
00007871bd3e2b1d  vmovaps xmm11, [rsp+0xA0]
00007871bd3e2b26  vmovaps xmm12, [rsp+0xB0]
00007871bd3e2b2f  vmovaps xmm13, [rsp+0xC0]
00007871bd3e2b38  vmovaps xmm14, [rsp+0xD0]
00007871bd3e2b41  vmovaps xmm15, [rsp+0xE0]
00007871bd3e2b4a  add rsp, 0xF0
00007871bd3e2b51  pop r11
00007871bd3e2b53  pop r10
00007871bd3e2b55  pop r9
00007871bd3e2b57  pop r8
00007871bd3e2b59  pop rsi
00007871bd3e2b5a  pop rdi
00007871bd3e2b5b  pop rdx
00007871bd3e2b5c  pop rcx
00007871bd3e2b5d  pop rax
00007871bd3e2b5e  add rsp, 0x08
00007871bd3e2b62  jmp 0x00007871BD3DF61D
00007871bd3e2b67  sub rsp, 0x08
00007871bd3e2b6b  push rax
00007871bd3e2b6c  push rcx
00007871bd3e2b6d  push rdx
00007871bd3e2b6e  push rdi
00007871bd3e2b6f  push rsi
00007871bd3e2b70  push r8
00007871bd3e2b72  push r9
00007871bd3e2b74  push r10
00007871bd3e2b76  push r11
00007871bd3e2b78  sub rsp, 0xF0
00007871bd3e2b7f  vmovaps [rsp], xmm0
00007871bd3e2b84  vmovaps [rsp+0x10], xmm1
00007871bd3e2b8a  vmovaps [rsp+0x20], xmm2
00007871bd3e2b90  vmovaps [rsp+0x30], xmm3
00007871bd3e2b96  vmovaps [rsp+0x40], xmm4
00007871bd3e2b9c  vmovaps [rsp+0x50], xmm5
00007871bd3e2ba2  vmovaps [rsp+0x60], xmm6
00007871bd3e2ba8  vmovaps [rsp+0x70], xmm7
00007871bd3e2bae  vmovaps [rsp+0x80], xmm8
00007871bd3e2bb7  vmovaps [rsp+0x90], xmm9
00007871bd3e2bc0  vmovaps [rsp+0xA0], xmm10
00007871bd3e2bc9  vmovaps [rsp+0xB0], xmm11
00007871bd3e2bd2  vmovaps [rsp+0xC0], xmm12
00007871bd3e2bdb  vmovaps [rsp+0xD0], xmm14
00007871bd3e2be4  vmovaps [rsp+0xE0], xmm15
00007871bd3e2bed  sub rsp, 0x30
00007871bd3e2bf1  movaps [rsp], xmm13
00007871bd3e2bf6  movaps [rsp+0x10], xmm15
00007871bd3e2bfc  movaps [rsp+0x20], xmm9
00007871bd3e2c02  lea rdi, [rsp]
00007871bd3e2c06  mov esi, 0x00
00007871bd3e2c0b  mov rax, 0x5BA2FDD2A530
00007871bd3e2c15  call rax
00007871bd3e2c17  movaps xmm13, [rsp]
00007871bd3e2c1c  add rsp, 0x30
00007871bd3e2c20  vmovaps xmm0, [rsp]
00007871bd3e2c25  vmovaps xmm1, [rsp+0x10]
00007871bd3e2c2b  vmovaps xmm2, [rsp+0x20]
00007871bd3e2c31  vmovaps xmm3, [rsp+0x30]
00007871bd3e2c37  vmovaps xmm4, [rsp+0x40]
00007871bd3e2c3d  vmovaps xmm5, [rsp+0x50]
00007871bd3e2c43  vmovaps xmm6, [rsp+0x60]
00007871bd3e2c49  vmovaps xmm7, [rsp+0x70]
00007871bd3e2c4f  vmovaps xmm8, [rsp+0x80]
00007871bd3e2c58  vmovaps xmm9, [rsp+0x90]
00007871bd3e2c61  vmovaps xmm10, [rsp+0xA0]
00007871bd3e2c6a  vmovaps xmm11, [rsp+0xB0]
00007871bd3e2c73  vmovaps xmm12, [rsp+0xC0]
00007871bd3e2c7c  vmovaps xmm14, [rsp+0xD0]
00007871bd3e2c85  vmovaps xmm15, [rsp+0xE0]
00007871bd3e2c8e  add rsp, 0xF0
00007871bd3e2c95  pop r11
00007871bd3e2c97  pop r10
00007871bd3e2c99  pop r9
00007871bd3e2c9b  pop r8
00007871bd3e2c9d  pop rsi
00007871bd3e2c9e  pop rdi
00007871bd3e2c9f  pop rdx
00007871bd3e2ca0  pop rcx
00007871bd3e2ca1  pop rax
00007871bd3e2ca2  add rsp, 0x08
00007871bd3e2ca6  jmp 0x00007871BD3DF638
00007871bd3e2cab  sub rsp, 0x08
00007871bd3e2caf  push rax
00007871bd3e2cb0  push rcx
00007871bd3e2cb1  push rdx
00007871bd3e2cb2  push rdi
00007871bd3e2cb3  push rsi
00007871bd3e2cb4  push r8
00007871bd3e2cb6  push r9
00007871bd3e2cb8  push r10
00007871bd3e2cba  push r11
00007871bd3e2cbc  sub rsp, 0xF0
00007871bd3e2cc3  vmovaps [rsp], xmm0
00007871bd3e2cc8  vmovaps [rsp+0x10], xmm1
00007871bd3e2cce  vmovaps [rsp+0x20], xmm2
00007871bd3e2cd4  vmovaps [rsp+0x30], xmm3
00007871bd3e2cda  vmovaps [rsp+0x40], xmm4
00007871bd3e2ce0  vmovaps [rsp+0x50], xmm5
00007871bd3e2ce6  vmovaps [rsp+0x60], xmm6
00007871bd3e2cec  vmovaps [rsp+0x70], xmm7
00007871bd3e2cf2  vmovaps [rsp+0x80], xmm8
00007871bd3e2cfb  vmovaps [rsp+0x90], xmm9
00007871bd3e2d04  vmovaps [rsp+0xA0], xmm10
00007871bd3e2d0d  vmovaps [rsp+0xB0], xmm11
00007871bd3e2d16  vmovaps [rsp+0xC0], xmm12
00007871bd3e2d1f  vmovaps [rsp+0xD0], xmm13
00007871bd3e2d28  vmovaps [rsp+0xE0], xmm14
00007871bd3e2d31  sub rsp, 0x30
00007871bd3e2d35  movaps [rsp], xmm15
00007871bd3e2d3a  movaps [rsp+0x10], xmm1
00007871bd3e2d3f  movaps [rsp+0x20], xmm5
00007871bd3e2d44  lea rdi, [rsp]
00007871bd3e2d48  mov esi, 0x00
00007871bd3e2d4d  mov rax, 0x5BA2FDD2A530
00007871bd3e2d57  call rax
00007871bd3e2d59  movaps xmm15, [rsp]
00007871bd3e2d5e  add rsp, 0x30
00007871bd3e2d62  vmovaps xmm0, [rsp]
00007871bd3e2d67  vmovaps xmm1, [rsp+0x10]
00007871bd3e2d6d  vmovaps xmm2, [rsp+0x20]
00007871bd3e2d73  vmovaps xmm3, [rsp+0x30]
00007871bd3e2d79  vmovaps xmm4, [rsp+0x40]
00007871bd3e2d7f  vmovaps xmm5, [rsp+0x50]
00007871bd3e2d85  vmovaps xmm6, [rsp+0x60]
00007871bd3e2d8b  vmovaps xmm7, [rsp+0x70]
00007871bd3e2d91  vmovaps xmm8, [rsp+0x80]
00007871bd3e2d9a  vmovaps xmm9, [rsp+0x90]
00007871bd3e2da3  vmovaps xmm10, [rsp+0xA0]
00007871bd3e2dac  vmovaps xmm11, [rsp+0xB0]
00007871bd3e2db5  vmovaps xmm12, [rsp+0xC0]
00007871bd3e2dbe  vmovaps xmm13, [rsp+0xD0]
00007871bd3e2dc7  vmovaps xmm14, [rsp+0xE0]
00007871bd3e2dd0  add rsp, 0xF0
00007871bd3e2dd7  pop r11
00007871bd3e2dd9  pop r10
00007871bd3e2ddb  pop r9
00007871bd3e2ddd  pop r8
00007871bd3e2ddf  pop rsi
00007871bd3e2de0  pop rdi
00007871bd3e2de1  pop rdx
00007871bd3e2de2  pop rcx
00007871bd3e2de3  pop rax
00007871bd3e2de4  add rsp, 0x08
00007871bd3e2de8  jmp 0x00007871BD3DF653
00007871bd3e2ded  call 0x00007871BD2B52F0
00007871bd3e2df2  jmp 0x00007871BD3DF6AE
00007871bd3e2df7  sub rsp, 0x08
00007871bd3e2dfb  push rax
00007871bd3e2dfc  push rcx
00007871bd3e2dfd  push rdx
00007871bd3e2dfe  push rdi
00007871bd3e2dff  push rsi
00007871bd3e2e00  push r8
00007871bd3e2e02  push r9
00007871bd3e2e04  push r10
00007871bd3e2e06  push r11
00007871bd3e2e08  sub rsp, 0xF0
00007871bd3e2e0f  vmovaps [rsp], xmm0
00007871bd3e2e14  vmovaps [rsp+0x10], xmm1
00007871bd3e2e1a  vmovaps [rsp+0x20], xmm2
00007871bd3e2e20  vmovaps [rsp+0x30], xmm3
00007871bd3e2e26  vmovaps [rsp+0x40], xmm4
00007871bd3e2e2c  vmovaps [rsp+0x50], xmm5
00007871bd3e2e32  vmovaps [rsp+0x60], xmm6
00007871bd3e2e38  vmovaps [rsp+0x70], xmm7
00007871bd3e2e3e  vmovaps [rsp+0x80], xmm8
00007871bd3e2e47  vmovaps [rsp+0x90], xmm10
00007871bd3e2e50  vmovaps [rsp+0xA0], xmm11
00007871bd3e2e59  vmovaps [rsp+0xB0], xmm12
00007871bd3e2e62  vmovaps [rsp+0xC0], xmm13
00007871bd3e2e6b  vmovaps [rsp+0xD0], xmm14
00007871bd3e2e74  vmovaps [rsp+0xE0], xmm15
00007871bd3e2e7d  sub rsp, 0x30
00007871bd3e2e81  movaps [rsp], xmm9
00007871bd3e2e86  movaps [rsp+0x10], xmm8
00007871bd3e2e8c  movaps [rsp+0x20], xmm11
00007871bd3e2e92  lea rdi, [rsp]
00007871bd3e2e96  mov esi, 0x00
00007871bd3e2e9b  mov rax, 0x5BA2FDD2A530
00007871bd3e2ea5  call rax
00007871bd3e2ea7  movaps xmm9, [rsp]
00007871bd3e2eac  add rsp, 0x30
00007871bd3e2eb0  vmovaps xmm0, [rsp]
00007871bd3e2eb5  vmovaps xmm1, [rsp+0x10]
00007871bd3e2ebb  vmovaps xmm2, [rsp+0x20]
00007871bd3e2ec1  vmovaps xmm3, [rsp+0x30]
00007871bd3e2ec7  vmovaps xmm4, [rsp+0x40]
00007871bd3e2ecd  vmovaps xmm5, [rsp+0x50]
00007871bd3e2ed3  vmovaps xmm6, [rsp+0x60]
00007871bd3e2ed9  vmovaps xmm7, [rsp+0x70]
00007871bd3e2edf  vmovaps xmm8, [rsp+0x80]
00007871bd3e2ee8  vmovaps xmm10, [rsp+0x90]
00007871bd3e2ef1  vmovaps xmm11, [rsp+0xA0]
00007871bd3e2efa  vmovaps xmm12, [rsp+0xB0]
00007871bd3e2f03  vmovaps xmm13, [rsp+0xC0]
00007871bd3e2f0c  vmovaps xmm14, [rsp+0xD0]
00007871bd3e2f15  vmovaps xmm15, [rsp+0xE0]
00007871bd3e2f1e  add rsp, 0xF0
00007871bd3e2f25  pop r11
00007871bd3e2f27  pop r10
00007871bd3e2f29  pop r9
00007871bd3e2f2b  pop r8
00007871bd3e2f2d  pop rsi
00007871bd3e2f2e  pop rdi
00007871bd3e2f2f  pop rdx
00007871bd3e2f30  pop rcx
00007871bd3e2f31  pop rax
00007871bd3e2f32  add rsp, 0x08
00007871bd3e2f36  jmp 0x00007871BD3DF6E5
00007871bd3e2f3b  sub rsp, 0x08
00007871bd3e2f3f  push rax
00007871bd3e2f40  push rcx
00007871bd3e2f41  push rdx
00007871bd3e2f42  push rdi
00007871bd3e2f43  push rsi
00007871bd3e2f44  push r8
00007871bd3e2f46  push r9
00007871bd3e2f48  push r10
00007871bd3e2f4a  push r11
00007871bd3e2f4c  sub rsp, 0xF0
00007871bd3e2f53  vmovaps [rsp], xmm0
00007871bd3e2f58  vmovaps [rsp+0x10], xmm1
00007871bd3e2f5e  vmovaps [rsp+0x20], xmm2
00007871bd3e2f64  vmovaps [rsp+0x30], xmm3
00007871bd3e2f6a  vmovaps [rsp+0x40], xmm4
00007871bd3e2f70  vmovaps [rsp+0x50], xmm5
00007871bd3e2f76  vmovaps [rsp+0x60], xmm6
00007871bd3e2f7c  vmovaps [rsp+0x70], xmm7
00007871bd3e2f82  vmovaps [rsp+0x80], xmm8
00007871bd3e2f8b  vmovaps [rsp+0x90], xmm9
00007871bd3e2f94  vmovaps [rsp+0xA0], xmm10
00007871bd3e2f9d  vmovaps [rsp+0xB0], xmm12
00007871bd3e2fa6  vmovaps [rsp+0xC0], xmm13
00007871bd3e2faf  vmovaps [rsp+0xD0], xmm14
00007871bd3e2fb8  vmovaps [rsp+0xE0], xmm15
00007871bd3e2fc1  sub rsp, 0x30
00007871bd3e2fc5  movaps [rsp], xmm11
00007871bd3e2fca  movaps [rsp+0x10], xmm10
00007871bd3e2fd0  movaps [rsp+0x20], xmm6
00007871bd3e2fd5  lea rdi, [rsp]
00007871bd3e2fd9  mov esi, 0x00
00007871bd3e2fde  mov rax, 0x5BA2FDD2A530
00007871bd3e2fe8  call rax
00007871bd3e2fea  movaps xmm11, [rsp]
00007871bd3e2fef  add rsp, 0x30
00007871bd3e2ff3  vmovaps xmm0, [rsp]
00007871bd3e2ff8  vmovaps xmm1, [rsp+0x10]
00007871bd3e2ffe  vmovaps xmm2, [rsp+0x20]
00007871bd3e3004  vmovaps xmm3, [rsp+0x30]
00007871bd3e300a  vmovaps xmm4, [rsp+0x40]
00007871bd3e3010  vmovaps xmm5, [rsp+0x50]
00007871bd3e3016  vmovaps xmm6, [rsp+0x60]
00007871bd3e301c  vmovaps xmm7, [rsp+0x70]
00007871bd3e3022  vmovaps xmm8, [rsp+0x80]
00007871bd3e302b  vmovaps xmm9, [rsp+0x90]
00007871bd3e3034  vmovaps xmm10, [rsp+0xA0]
00007871bd3e303d  vmovaps xmm12, [rsp+0xB0]
00007871bd3e3046  vmovaps xmm13, [rsp+0xC0]
00007871bd3e304f  vmovaps xmm14, [rsp+0xD0]
00007871bd3e3058  vmovaps xmm15, [rsp+0xE0]
00007871bd3e3061  add rsp, 0xF0
00007871bd3e3068  pop r11
00007871bd3e306a  pop r10
00007871bd3e306c  pop r9
00007871bd3e306e  pop r8
00007871bd3e3070  pop rsi
00007871bd3e3071  pop rdi
00007871bd3e3072  pop rdx
00007871bd3e3073  pop rcx
00007871bd3e3074  pop rax
00007871bd3e3075  add rsp, 0x08
00007871bd3e3079  jmp 0x00007871BD3DF700
00007871bd3e307e  sub rsp, 0x08
00007871bd3e3082  push rax
00007871bd3e3083  push rcx
00007871bd3e3084  push rdx
00007871bd3e3085  push rdi
00007871bd3e3086  push rsi
00007871bd3e3087  push r8
00007871bd3e3089  push r9
00007871bd3e308b  push r10
00007871bd3e308d  push r11
00007871bd3e308f  sub rsp, 0xF0
00007871bd3e3096  vmovaps [rsp], xmm0
00007871bd3e309b  vmovaps [rsp+0x10], xmm1
00007871bd3e30a1  vmovaps [rsp+0x20], xmm2
00007871bd3e30a7  vmovaps [rsp+0x30], xmm3
00007871bd3e30ad  vmovaps [rsp+0x40], xmm4
00007871bd3e30b3  vmovaps [rsp+0x50], xmm5
00007871bd3e30b9  vmovaps [rsp+0x60], xmm6
00007871bd3e30bf  vmovaps [rsp+0x70], xmm7
00007871bd3e30c5  vmovaps [rsp+0x80], xmm8
00007871bd3e30ce  vmovaps [rsp+0x90], xmm9
00007871bd3e30d7  vmovaps [rsp+0xA0], xmm11
00007871bd3e30e0  vmovaps [rsp+0xB0], xmm12
00007871bd3e30e9  vmovaps [rsp+0xC0], xmm13
00007871bd3e30f2  vmovaps [rsp+0xD0], xmm14
00007871bd3e30fb  vmovaps [rsp+0xE0], xmm15
00007871bd3e3104  sub rsp, 0x30
00007871bd3e3108  movaps [rsp], xmm10
00007871bd3e310d  movaps [rsp+0x10], xmm14
00007871bd3e3113  movaps [rsp+0x20], xmm4
00007871bd3e3118  lea rdi, [rsp]
00007871bd3e311c  mov esi, 0x00
00007871bd3e3121  mov rax, 0x5BA2FDD2A530
00007871bd3e312b  call rax
00007871bd3e312d  movaps xmm10, [rsp]
00007871bd3e3132  add rsp, 0x30
00007871bd3e3136  vmovaps xmm0, [rsp]
00007871bd3e313b  vmovaps xmm1, [rsp+0x10]
00007871bd3e3141  vmovaps xmm2, [rsp+0x20]
00007871bd3e3147  vmovaps xmm3, [rsp+0x30]
00007871bd3e314d  vmovaps xmm4, [rsp+0x40]
00007871bd3e3153  vmovaps xmm5, [rsp+0x50]
00007871bd3e3159  vmovaps xmm6, [rsp+0x60]
00007871bd3e315f  vmovaps xmm7, [rsp+0x70]
00007871bd3e3165  vmovaps xmm8, [rsp+0x80]
00007871bd3e316e  vmovaps xmm9, [rsp+0x90]
00007871bd3e3177  vmovaps xmm11, [rsp+0xA0]
00007871bd3e3180  vmovaps xmm12, [rsp+0xB0]
00007871bd3e3189  vmovaps xmm13, [rsp+0xC0]
00007871bd3e3192  vmovaps xmm14, [rsp+0xD0]
00007871bd3e319b  vmovaps xmm15, [rsp+0xE0]
00007871bd3e31a4  add rsp, 0xF0
00007871bd3e31ab  pop r11
00007871bd3e31ad  pop r10
00007871bd3e31af  pop r9
00007871bd3e31b1  pop r8
00007871bd3e31b3  pop rsi
00007871bd3e31b4  pop rdi
00007871bd3e31b5  pop rdx
00007871bd3e31b6  pop rcx
00007871bd3e31b7  pop rax
00007871bd3e31b8  add rsp, 0x08
00007871bd3e31bc  jmp 0x00007871BD3DF71B
00007871bd3e31c1  sub rsp, 0x08
00007871bd3e31c5  push rax
00007871bd3e31c6  push rcx
00007871bd3e31c7  push rdx
00007871bd3e31c8  push rdi
00007871bd3e31c9  push rsi
00007871bd3e31ca  push r8
00007871bd3e31cc  push r9
00007871bd3e31ce  push r10
00007871bd3e31d0  push r11
00007871bd3e31d2  sub rsp, 0xF0
00007871bd3e31d9  vmovaps [rsp], xmm0
00007871bd3e31de  vmovaps [rsp+0x10], xmm1
00007871bd3e31e4  vmovaps [rsp+0x20], xmm2
00007871bd3e31ea  vmovaps [rsp+0x30], xmm3
00007871bd3e31f0  vmovaps [rsp+0x40], xmm4
00007871bd3e31f6  vmovaps [rsp+0x50], xmm5
00007871bd3e31fc  vmovaps [rsp+0x60], xmm6
00007871bd3e3202  vmovaps [rsp+0x70], xmm7
00007871bd3e3208  vmovaps [rsp+0x80], xmm9
00007871bd3e3211  vmovaps [rsp+0x90], xmm10
00007871bd3e321a  vmovaps [rsp+0xA0], xmm11
00007871bd3e3223  vmovaps [rsp+0xB0], xmm12
00007871bd3e322c  vmovaps [rsp+0xC0], xmm13
00007871bd3e3235  vmovaps [rsp+0xD0], xmm14
00007871bd3e323e  vmovaps [rsp+0xE0], xmm15
00007871bd3e3247  sub rsp, 0x30
00007871bd3e324b  movaps [rsp], xmm8
00007871bd3e3250  movaps [rsp+0x10], xmm1
00007871bd3e3255  movaps [rsp+0x20], xmm14
00007871bd3e325b  lea rdi, [rsp]
00007871bd3e325f  mov esi, 0x00
00007871bd3e3264  mov rax, 0x5BA2FDD2A530
00007871bd3e326e  call rax
00007871bd3e3270  movaps xmm8, [rsp]
00007871bd3e3275  add rsp, 0x30
00007871bd3e3279  vmovaps xmm0, [rsp]
00007871bd3e327e  vmovaps xmm1, [rsp+0x10]
00007871bd3e3284  vmovaps xmm2, [rsp+0x20]
00007871bd3e328a  vmovaps xmm3, [rsp+0x30]
00007871bd3e3290  vmovaps xmm4, [rsp+0x40]
00007871bd3e3296  vmovaps xmm5, [rsp+0x50]
00007871bd3e329c  vmovaps xmm6, [rsp+0x60]
00007871bd3e32a2  vmovaps xmm7, [rsp+0x70]
00007871bd3e32a8  vmovaps xmm9, [rsp+0x80]
00007871bd3e32b1  vmovaps xmm10, [rsp+0x90]
00007871bd3e32ba  vmovaps xmm11, [rsp+0xA0]
00007871bd3e32c3  vmovaps xmm12, [rsp+0xB0]
00007871bd3e32cc  vmovaps xmm13, [rsp+0xC0]
00007871bd3e32d5  vmovaps xmm14, [rsp+0xD0]
00007871bd3e32de  vmovaps xmm15, [rsp+0xE0]
00007871bd3e32e7  add rsp, 0xF0
00007871bd3e32ee  pop r11
00007871bd3e32f0  pop r10
00007871bd3e32f2  pop r9
00007871bd3e32f4  pop r8
00007871bd3e32f6  pop rsi
00007871bd3e32f7  pop rdi
00007871bd3e32f8  pop rdx
00007871bd3e32f9  pop rcx
00007871bd3e32fa  pop rax
00007871bd3e32fb  add rsp, 0x08
00007871bd3e32ff  jmp 0x00007871BD3DF741
00007871bd3e3304  sub rsp, 0x08
00007871bd3e3308  push rax
00007871bd3e3309  push rcx
00007871bd3e330a  push rdx
00007871bd3e330b  push rdi
00007871bd3e330c  push rsi
00007871bd3e330d  push r8
00007871bd3e330f  push r9
00007871bd3e3311  push r10
00007871bd3e3313  push r11
00007871bd3e3315  sub rsp, 0xF0
00007871bd3e331c  vmovaps [rsp], xmm0
00007871bd3e3321  vmovaps [rsp+0x10], xmm1
00007871bd3e3327  vmovaps [rsp+0x20], xmm2
00007871bd3e332d  vmovaps [rsp+0x30], xmm3
00007871bd3e3333  vmovaps [rsp+0x40], xmm4
00007871bd3e3339  vmovaps [rsp+0x50], xmm5
00007871bd3e333f  vmovaps [rsp+0x60], xmm7
00007871bd3e3345  vmovaps [rsp+0x70], xmm8
00007871bd3e334b  vmovaps [rsp+0x80], xmm9
00007871bd3e3354  vmovaps [rsp+0x90], xmm10
00007871bd3e335d  vmovaps [rsp+0xA0], xmm11
00007871bd3e3366  vmovaps [rsp+0xB0], xmm12
00007871bd3e336f  vmovaps [rsp+0xC0], xmm13
00007871bd3e3378  vmovaps [rsp+0xD0], xmm14
00007871bd3e3381  vmovaps [rsp+0xE0], xmm15
00007871bd3e338a  sub rsp, 0x30
00007871bd3e338e  movaps [rsp], xmm6
00007871bd3e3392  movaps [rsp+0x10], xmm1
00007871bd3e3397  movaps [rsp+0x20], xmm14
00007871bd3e339d  lea rdi, [rsp]
00007871bd3e33a1  mov esi, 0x00
00007871bd3e33a6  mov rax, 0x5BA2FDD2A530
00007871bd3e33b0  call rax
00007871bd3e33b2  movaps xmm6, [rsp]
00007871bd3e33b6  add rsp, 0x30
00007871bd3e33ba  vmovaps xmm0, [rsp]
00007871bd3e33bf  vmovaps xmm1, [rsp+0x10]
00007871bd3e33c5  vmovaps xmm2, [rsp+0x20]
00007871bd3e33cb  vmovaps xmm3, [rsp+0x30]
00007871bd3e33d1  vmovaps xmm4, [rsp+0x40]
00007871bd3e33d7  vmovaps xmm5, [rsp+0x50]
00007871bd3e33dd  vmovaps xmm7, [rsp+0x60]
00007871bd3e33e3  vmovaps xmm8, [rsp+0x70]
00007871bd3e33e9  vmovaps xmm9, [rsp+0x80]
00007871bd3e33f2  vmovaps xmm10, [rsp+0x90]
00007871bd3e33fb  vmovaps xmm11, [rsp+0xA0]
00007871bd3e3404  vmovaps xmm12, [rsp+0xB0]
00007871bd3e340d  vmovaps xmm13, [rsp+0xC0]
00007871bd3e3416  vmovaps xmm14, [rsp+0xD0]
00007871bd3e341f  vmovaps xmm15, [rsp+0xE0]
00007871bd3e3428  add rsp, 0xF0
00007871bd3e342f  pop r11
00007871bd3e3431  pop r10
00007871bd3e3433  pop r9
00007871bd3e3435  pop r8
00007871bd3e3437  pop rsi
00007871bd3e3438  pop rdi
00007871bd3e3439  pop rdx
00007871bd3e343a  pop rcx
00007871bd3e343b  pop rax
00007871bd3e343c  add rsp, 0x08
00007871bd3e3440  jmp 0x00007871BD3DF76D
00007871bd3e3445  sub rsp, 0x08
00007871bd3e3449  push rax
00007871bd3e344a  push rcx
00007871bd3e344b  push rdx
00007871bd3e344c  push rdi
00007871bd3e344d  push rsi
00007871bd3e344e  push r8
00007871bd3e3450  push r9
00007871bd3e3452  push r10
00007871bd3e3454  push r11
00007871bd3e3456  sub rsp, 0xF0
00007871bd3e345d  vmovaps [rsp], xmm0
00007871bd3e3462  vmovaps [rsp+0x10], xmm1
00007871bd3e3468  vmovaps [rsp+0x20], xmm2
00007871bd3e346e  vmovaps [rsp+0x30], xmm3
00007871bd3e3474  vmovaps [rsp+0x40], xmm4
00007871bd3e347a  vmovaps [rsp+0x50], xmm5
00007871bd3e3480  vmovaps [rsp+0x60], xmm6
00007871bd3e3486  vmovaps [rsp+0x70], xmm7
00007871bd3e348c  vmovaps [rsp+0x80], xmm8
00007871bd3e3495  vmovaps [rsp+0x90], xmm9
00007871bd3e349e  vmovaps [rsp+0xA0], xmm10
00007871bd3e34a7  vmovaps [rsp+0xB0], xmm11
00007871bd3e34b0  vmovaps [rsp+0xC0], xmm12
00007871bd3e34b9  vmovaps [rsp+0xD0], xmm13
00007871bd3e34c2  vmovaps [rsp+0xE0], xmm15
00007871bd3e34cb  sub rsp, 0x30
00007871bd3e34cf  movaps [rsp], xmm14
00007871bd3e34d4  movaps [rsp+0x10], xmm12
00007871bd3e34da  movaps [rsp+0x20], xmm1
00007871bd3e34df  lea rdi, [rsp]
00007871bd3e34e3  mov esi, 0x00
00007871bd3e34e8  mov rax, 0x5BA2FDD2A530
00007871bd3e34f2  call rax
00007871bd3e34f4  movaps xmm14, [rsp]
00007871bd3e34f9  add rsp, 0x30
00007871bd3e34fd  vmovaps xmm0, [rsp]
00007871bd3e3502  vmovaps xmm1, [rsp+0x10]
00007871bd3e3508  vmovaps xmm2, [rsp+0x20]
00007871bd3e350e  vmovaps xmm3, [rsp+0x30]
00007871bd3e3514  vmovaps xmm4, [rsp+0x40]
00007871bd3e351a  vmovaps xmm5, [rsp+0x50]
00007871bd3e3520  vmovaps xmm6, [rsp+0x60]
00007871bd3e3526  vmovaps xmm7, [rsp+0x70]
00007871bd3e352c  vmovaps xmm8, [rsp+0x80]
00007871bd3e3535  vmovaps xmm9, [rsp+0x90]
00007871bd3e353e  vmovaps xmm10, [rsp+0xA0]
00007871bd3e3547  vmovaps xmm11, [rsp+0xB0]
00007871bd3e3550  vmovaps xmm12, [rsp+0xC0]
00007871bd3e3559  vmovaps xmm13, [rsp+0xD0]
00007871bd3e3562  vmovaps xmm15, [rsp+0xE0]
00007871bd3e356b  add rsp, 0xF0
00007871bd3e3572  pop r11
00007871bd3e3574  pop r10
00007871bd3e3576  pop r9
00007871bd3e3578  pop r8
00007871bd3e357a  pop rsi
00007871bd3e357b  pop rdi
00007871bd3e357c  pop rdx
00007871bd3e357d  pop rcx
00007871bd3e357e  pop rax
00007871bd3e357f  add rsp, 0x08
00007871bd3e3583  jmp 0x00007871BD3DF793
00007871bd3e3588  sub rsp, 0x08
00007871bd3e358c  push rax
00007871bd3e358d  push rcx
00007871bd3e358e  push rdx
00007871bd3e358f  push rdi
00007871bd3e3590  push rsi
00007871bd3e3591  push r8
00007871bd3e3593  push r9
00007871bd3e3595  push r10
00007871bd3e3597  push r11
00007871bd3e3599  sub rsp, 0xF0
00007871bd3e35a0  vmovaps [rsp], xmm0
00007871bd3e35a5  vmovaps [rsp+0x10], xmm2
00007871bd3e35ab  vmovaps [rsp+0x20], xmm3
00007871bd3e35b1  vmovaps [rsp+0x30], xmm4
00007871bd3e35b7  vmovaps [rsp+0x40], xmm5
00007871bd3e35bd  vmovaps [rsp+0x50], xmm6
00007871bd3e35c3  vmovaps [rsp+0x60], xmm7
00007871bd3e35c9  vmovaps [rsp+0x70], xmm8
00007871bd3e35cf  vmovaps [rsp+0x80], xmm9
00007871bd3e35d8  vmovaps [rsp+0x90], xmm10
00007871bd3e35e1  vmovaps [rsp+0xA0], xmm11
00007871bd3e35ea  vmovaps [rsp+0xB0], xmm12
00007871bd3e35f3  vmovaps [rsp+0xC0], xmm13
00007871bd3e35fc  vmovaps [rsp+0xD0], xmm14
00007871bd3e3605  vmovaps [rsp+0xE0], xmm15
00007871bd3e360e  sub rsp, 0x30
00007871bd3e3612  movaps [rsp], xmm1
00007871bd3e3616  movaps [rsp+0x10], xmm13
00007871bd3e361c  movaps [rsp+0x20], xmm9
00007871bd3e3622  lea rdi, [rsp]
00007871bd3e3626  mov esi, 0x00
00007871bd3e362b  mov rax, 0x5BA2FDD2A530
00007871bd3e3635  call rax
00007871bd3e3637  movaps xmm1, [rsp]
00007871bd3e363b  add rsp, 0x30
00007871bd3e363f  vmovaps xmm0, [rsp]
00007871bd3e3644  vmovaps xmm2, [rsp+0x10]
00007871bd3e364a  vmovaps xmm3, [rsp+0x20]
00007871bd3e3650  vmovaps xmm4, [rsp+0x30]
00007871bd3e3656  vmovaps xmm5, [rsp+0x40]
00007871bd3e365c  vmovaps xmm6, [rsp+0x50]
00007871bd3e3662  vmovaps xmm7, [rsp+0x60]
00007871bd3e3668  vmovaps xmm8, [rsp+0x70]
00007871bd3e366e  vmovaps xmm9, [rsp+0x80]
00007871bd3e3677  vmovaps xmm10, [rsp+0x90]
00007871bd3e3680  vmovaps xmm11, [rsp+0xA0]
00007871bd3e3689  vmovaps xmm12, [rsp+0xB0]
00007871bd3e3692  vmovaps xmm13, [rsp+0xC0]
00007871bd3e369b  vmovaps xmm14, [rsp+0xD0]
00007871bd3e36a4  vmovaps xmm15, [rsp+0xE0]
00007871bd3e36ad  add rsp, 0xF0
00007871bd3e36b4  pop r11
00007871bd3e36b6  pop r10
00007871bd3e36b8  pop r9
00007871bd3e36ba  pop r8
00007871bd3e36bc  pop rsi
00007871bd3e36bd  pop rdi
00007871bd3e36be  pop rdx
00007871bd3e36bf  pop rcx
00007871bd3e36c0  pop rax
00007871bd3e36c1  add rsp, 0x08
00007871bd3e36c5  jmp 0x00007871BD3DF7AD
00007871bd3e36ca  sub rsp, 0x08
00007871bd3e36ce  push rax
00007871bd3e36cf  push rcx
00007871bd3e36d0  push rdx
00007871bd3e36d1  push rdi
00007871bd3e36d2  push rsi
00007871bd3e36d3  push r8
00007871bd3e36d5  push r9
00007871bd3e36d7  push r10
00007871bd3e36d9  push r11
00007871bd3e36db  sub rsp, 0xF0
00007871bd3e36e2  vmovaps [rsp], xmm0
00007871bd3e36e7  vmovaps [rsp+0x10], xmm1
00007871bd3e36ed  vmovaps [rsp+0x20], xmm2
00007871bd3e36f3  vmovaps [rsp+0x30], xmm3
00007871bd3e36f9  vmovaps [rsp+0x40], xmm4
00007871bd3e36ff  vmovaps [rsp+0x50], xmm5
00007871bd3e3705  vmovaps [rsp+0x60], xmm6
00007871bd3e370b  vmovaps [rsp+0x70], xmm7
00007871bd3e3711  vmovaps [rsp+0x80], xmm8
00007871bd3e371a  vmovaps [rsp+0x90], xmm9
00007871bd3e3723  vmovaps [rsp+0xA0], xmm10
00007871bd3e372c  vmovaps [rsp+0xB0], xmm11
00007871bd3e3735  vmovaps [rsp+0xC0], xmm13
00007871bd3e373e  vmovaps [rsp+0xD0], xmm14
00007871bd3e3747  vmovaps [rsp+0xE0], xmm15
00007871bd3e3750  sub rsp, 0x30
00007871bd3e3754  movaps [rsp], xmm12
00007871bd3e3759  movaps [rsp+0x10], xmm7
00007871bd3e375e  movaps [rsp+0x20], xmm13
00007871bd3e3764  lea rdi, [rsp]
00007871bd3e3768  mov esi, 0x00
00007871bd3e376d  mov rax, 0x5BA2FDD2A530
00007871bd3e3777  call rax
00007871bd3e3779  movaps xmm12, [rsp]
00007871bd3e377e  add rsp, 0x30
00007871bd3e3782  vmovaps xmm0, [rsp]
00007871bd3e3787  vmovaps xmm1, [rsp+0x10]
00007871bd3e378d  vmovaps xmm2, [rsp+0x20]
00007871bd3e3793  vmovaps xmm3, [rsp+0x30]
00007871bd3e3799  vmovaps xmm4, [rsp+0x40]
00007871bd3e379f  vmovaps xmm5, [rsp+0x50]
00007871bd3e37a5  vmovaps xmm6, [rsp+0x60]
00007871bd3e37ab  vmovaps xmm7, [rsp+0x70]
00007871bd3e37b1  vmovaps xmm8, [rsp+0x80]
00007871bd3e37ba  vmovaps xmm9, [rsp+0x90]
00007871bd3e37c3  vmovaps xmm10, [rsp+0xA0]
00007871bd3e37cc  vmovaps xmm11, [rsp+0xB0]
00007871bd3e37d5  vmovaps xmm13, [rsp+0xC0]
00007871bd3e37de  vmovaps xmm14, [rsp+0xD0]
00007871bd3e37e7  vmovaps xmm15, [rsp+0xE0]
00007871bd3e37f0  add rsp, 0xF0
00007871bd3e37f7  pop r11
00007871bd3e37f9  pop r10
00007871bd3e37fb  pop r9
00007871bd3e37fd  pop r8
00007871bd3e37ff  pop rsi
00007871bd3e3800  pop rdi
00007871bd3e3801  pop rdx
00007871bd3e3802  pop rcx
00007871bd3e3803  pop rax
00007871bd3e3804  add rsp, 0x08
00007871bd3e3808  jmp 0x00007871BD3DF7D4
00007871bd3e380d  sub rsp, 0x08
00007871bd3e3811  push rax
00007871bd3e3812  push rcx
00007871bd3e3813  push rdx
00007871bd3e3814  push rdi
00007871bd3e3815  push rsi
00007871bd3e3816  push r8
00007871bd3e3818  push r9
00007871bd3e381a  push r10
00007871bd3e381c  push r11
00007871bd3e381e  sub rsp, 0xF0
00007871bd3e3825  vmovaps [rsp], xmm0
00007871bd3e382a  vmovaps [rsp+0x10], xmm1
00007871bd3e3830  vmovaps [rsp+0x20], xmm2
00007871bd3e3836  vmovaps [rsp+0x30], xmm3
00007871bd3e383c  vmovaps [rsp+0x40], xmm4
00007871bd3e3842  vmovaps [rsp+0x50], xmm5
00007871bd3e3848  vmovaps [rsp+0x60], xmm6
00007871bd3e384e  vmovaps [rsp+0x70], xmm7
00007871bd3e3854  vmovaps [rsp+0x80], xmm8
00007871bd3e385d  vmovaps [rsp+0x90], xmm9
00007871bd3e3866  vmovaps [rsp+0xA0], xmm10
00007871bd3e386f  vmovaps [rsp+0xB0], xmm11
00007871bd3e3878  vmovaps [rsp+0xC0], xmm12
00007871bd3e3881  vmovaps [rsp+0xD0], xmm14
00007871bd3e388a  vmovaps [rsp+0xE0], xmm15
00007871bd3e3893  sub rsp, 0x30
00007871bd3e3897  movaps [rsp], xmm13
00007871bd3e389c  movaps [rsp+0x10], xmm15
00007871bd3e38a2  movaps [rsp+0x20], xmm8
00007871bd3e38a8  lea rdi, [rsp]
00007871bd3e38ac  mov esi, 0x00
00007871bd3e38b1  mov rax, 0x5BA2FDD2A530
00007871bd3e38bb  call rax
00007871bd3e38bd  movaps xmm13, [rsp]
00007871bd3e38c2  add rsp, 0x30
00007871bd3e38c6  vmovaps xmm0, [rsp]
00007871bd3e38cb  vmovaps xmm1, [rsp+0x10]
00007871bd3e38d1  vmovaps xmm2, [rsp+0x20]
00007871bd3e38d7  vmovaps xmm3, [rsp+0x30]
00007871bd3e38dd  vmovaps xmm4, [rsp+0x40]
00007871bd3e38e3  vmovaps xmm5, [rsp+0x50]
00007871bd3e38e9  vmovaps xmm6, [rsp+0x60]
00007871bd3e38ef  vmovaps xmm7, [rsp+0x70]
00007871bd3e38f5  vmovaps xmm8, [rsp+0x80]
00007871bd3e38fe  vmovaps xmm9, [rsp+0x90]
00007871bd3e3907  vmovaps xmm10, [rsp+0xA0]
00007871bd3e3910  vmovaps xmm11, [rsp+0xB0]
00007871bd3e3919  vmovaps xmm12, [rsp+0xC0]
00007871bd3e3922  vmovaps xmm14, [rsp+0xD0]
00007871bd3e392b  vmovaps xmm15, [rsp+0xE0]
00007871bd3e3934  add rsp, 0xF0
00007871bd3e393b  pop r11
00007871bd3e393d  pop r10
00007871bd3e393f  pop r9
00007871bd3e3941  pop r8
00007871bd3e3943  pop rsi
00007871bd3e3944  pop rdi
00007871bd3e3945  pop rdx
00007871bd3e3946  pop rcx
00007871bd3e3947  pop rax
00007871bd3e3948  add rsp, 0x08
00007871bd3e394c  jmp 0x00007871BD3DF7EF
00007871bd3e3951  sub rsp, 0x08
00007871bd3e3955  push rax
00007871bd3e3956  push rcx
00007871bd3e3957  push rdx
00007871bd3e3958  push rdi
00007871bd3e3959  push rsi
00007871bd3e395a  push r8
00007871bd3e395c  push r9
00007871bd3e395e  push r10
00007871bd3e3960  push r11
00007871bd3e3962  sub rsp, 0xF0
00007871bd3e3969  vmovaps [rsp], xmm0
00007871bd3e396e  vmovaps [rsp+0x10], xmm1
00007871bd3e3974  vmovaps [rsp+0x20], xmm2
00007871bd3e397a  vmovaps [rsp+0x30], xmm3
00007871bd3e3980  vmovaps [rsp+0x40], xmm4
00007871bd3e3986  vmovaps [rsp+0x50], xmm5
00007871bd3e398c  vmovaps [rsp+0x60], xmm6
00007871bd3e3992  vmovaps [rsp+0x70], xmm7
00007871bd3e3998  vmovaps [rsp+0x80], xmm9
00007871bd3e39a1  vmovaps [rsp+0x90], xmm10
00007871bd3e39aa  vmovaps [rsp+0xA0], xmm11
00007871bd3e39b3  vmovaps [rsp+0xB0], xmm12
00007871bd3e39bc  vmovaps [rsp+0xC0], xmm13
00007871bd3e39c5  vmovaps [rsp+0xD0], xmm14
00007871bd3e39ce  vmovaps [rsp+0xE0], xmm15
00007871bd3e39d7  sub rsp, 0x30
00007871bd3e39db  movaps [rsp], xmm8
00007871bd3e39e0  movaps [rsp+0x10], xmm15
00007871bd3e39e6  movaps [rsp+0x20], xmm9
00007871bd3e39ec  lea rdi, [rsp]
00007871bd3e39f0  mov esi, 0x00
00007871bd3e39f5  mov rax, 0x5BA2FDD2A530
00007871bd3e39ff  call rax
00007871bd3e3a01  movaps xmm8, [rsp]
00007871bd3e3a06  add rsp, 0x30
00007871bd3e3a0a  vmovaps xmm0, [rsp]
00007871bd3e3a0f  vmovaps xmm1, [rsp+0x10]
00007871bd3e3a15  vmovaps xmm2, [rsp+0x20]
00007871bd3e3a1b  vmovaps xmm3, [rsp+0x30]
00007871bd3e3a21  vmovaps xmm4, [rsp+0x40]
00007871bd3e3a27  vmovaps xmm5, [rsp+0x50]
00007871bd3e3a2d  vmovaps xmm6, [rsp+0x60]
00007871bd3e3a33  vmovaps xmm7, [rsp+0x70]
00007871bd3e3a39  vmovaps xmm9, [rsp+0x80]
00007871bd3e3a42  vmovaps xmm10, [rsp+0x90]
00007871bd3e3a4b  vmovaps xmm11, [rsp+0xA0]
00007871bd3e3a54  vmovaps xmm12, [rsp+0xB0]
00007871bd3e3a5d  vmovaps xmm13, [rsp+0xC0]
00007871bd3e3a66  vmovaps xmm14, [rsp+0xD0]
00007871bd3e3a6f  vmovaps xmm15, [rsp+0xE0]
00007871bd3e3a78  add rsp, 0xF0
00007871bd3e3a7f  pop r11
00007871bd3e3a81  pop r10
00007871bd3e3a83  pop r9
00007871bd3e3a85  pop r8
00007871bd3e3a87  pop rsi
00007871bd3e3a88  pop rdi
00007871bd3e3a89  pop rdx
00007871bd3e3a8a  pop rcx
00007871bd3e3a8b  pop rax
00007871bd3e3a8c  add rsp, 0x08
00007871bd3e3a90  jmp 0x00007871BD3DF81D
00007871bd3e3a95  sub rsp, 0x08
00007871bd3e3a99  push rax
00007871bd3e3a9a  push rcx
00007871bd3e3a9b  push rdx
00007871bd3e3a9c  push rdi
00007871bd3e3a9d  push rsi
00007871bd3e3a9e  push r8
00007871bd3e3aa0  push r9
00007871bd3e3aa2  push r10
00007871bd3e3aa4  push r11
00007871bd3e3aa6  sub rsp, 0xF0
00007871bd3e3aad  vmovaps [rsp], xmm0
00007871bd3e3ab2  vmovaps [rsp+0x10], xmm1
00007871bd3e3ab8  vmovaps [rsp+0x20], xmm2
00007871bd3e3abe  vmovaps [rsp+0x30], xmm3
00007871bd3e3ac4  vmovaps [rsp+0x40], xmm4
00007871bd3e3aca  vmovaps [rsp+0x50], xmm5
00007871bd3e3ad0  vmovaps [rsp+0x60], xmm6
00007871bd3e3ad6  vmovaps [rsp+0x70], xmm7
00007871bd3e3adc  vmovaps [rsp+0x80], xmm8
00007871bd3e3ae5  vmovaps [rsp+0x90], xmm9
00007871bd3e3aee  vmovaps [rsp+0xA0], xmm10
00007871bd3e3af7  vmovaps [rsp+0xB0], xmm11
00007871bd3e3b00  vmovaps [rsp+0xC0], xmm12
00007871bd3e3b09  vmovaps [rsp+0xD0], xmm13
00007871bd3e3b12  vmovaps [rsp+0xE0], xmm14
00007871bd3e3b1b  sub rsp, 0x30
00007871bd3e3b1f  movaps [rsp], xmm15
00007871bd3e3b24  movaps [rsp+0x10], xmm11
00007871bd3e3b2a  movaps [rsp+0x20], xmm6
00007871bd3e3b2f  lea rdi, [rsp]
00007871bd3e3b33  mov esi, 0x00
00007871bd3e3b38  mov rax, 0x5BA2FDD2A530
00007871bd3e3b42  call rax
00007871bd3e3b44  movaps xmm15, [rsp]
00007871bd3e3b49  add rsp, 0x30
00007871bd3e3b4d  vmovaps xmm0, [rsp]
00007871bd3e3b52  vmovaps xmm1, [rsp+0x10]
00007871bd3e3b58  vmovaps xmm2, [rsp+0x20]
00007871bd3e3b5e  vmovaps xmm3, [rsp+0x30]
00007871bd3e3b64  vmovaps xmm4, [rsp+0x40]
00007871bd3e3b6a  vmovaps xmm5, [rsp+0x50]
00007871bd3e3b70  vmovaps xmm6, [rsp+0x60]
00007871bd3e3b76  vmovaps xmm7, [rsp+0x70]
00007871bd3e3b7c  vmovaps xmm8, [rsp+0x80]
00007871bd3e3b85  vmovaps xmm9, [rsp+0x90]
00007871bd3e3b8e  vmovaps xmm10, [rsp+0xA0]
00007871bd3e3b97  vmovaps xmm11, [rsp+0xB0]
00007871bd3e3ba0  vmovaps xmm12, [rsp+0xC0]
00007871bd3e3ba9  vmovaps xmm13, [rsp+0xD0]
00007871bd3e3bb2  vmovaps xmm14, [rsp+0xE0]
00007871bd3e3bbb  add rsp, 0xF0
00007871bd3e3bc2  pop r11
00007871bd3e3bc4  pop r10
00007871bd3e3bc6  pop r9
00007871bd3e3bc8  pop r8
00007871bd3e3bca  pop rsi
00007871bd3e3bcb  pop rdi
00007871bd3e3bcc  pop rdx
00007871bd3e3bcd  pop rcx
00007871bd3e3bce  pop rax
00007871bd3e3bcf  add rsp, 0x08
00007871bd3e3bd3  jmp 0x00007871BD3DF838
00007871bd3e3bd8  sub rsp, 0x08
00007871bd3e3bdc  push rax
00007871bd3e3bdd  push rcx
00007871bd3e3bde  push rdx
00007871bd3e3bdf  push rdi
00007871bd3e3be0  push rsi
00007871bd3e3be1  push r8
00007871bd3e3be3  push r9
00007871bd3e3be5  push r10
00007871bd3e3be7  push r11
00007871bd3e3be9  sub rsp, 0xF0
00007871bd3e3bf0  vmovaps [rsp], xmm0
00007871bd3e3bf5  vmovaps [rsp+0x10], xmm1
00007871bd3e3bfb  vmovaps [rsp+0x20], xmm2
00007871bd3e3c01  vmovaps [rsp+0x30], xmm3
00007871bd3e3c07  vmovaps [rsp+0x40], xmm4
00007871bd3e3c0d  vmovaps [rsp+0x50], xmm5
00007871bd3e3c13  vmovaps [rsp+0x60], xmm6
00007871bd3e3c19  vmovaps [rsp+0x70], xmm8
00007871bd3e3c1f  vmovaps [rsp+0x80], xmm9
00007871bd3e3c28  vmovaps [rsp+0x90], xmm10
00007871bd3e3c31  vmovaps [rsp+0xA0], xmm11
00007871bd3e3c3a  vmovaps [rsp+0xB0], xmm12
00007871bd3e3c43  vmovaps [rsp+0xC0], xmm13
00007871bd3e3c4c  vmovaps [rsp+0xD0], xmm14
00007871bd3e3c55  vmovaps [rsp+0xE0], xmm15
00007871bd3e3c5e  sub rsp, 0x30
00007871bd3e3c62  movaps [rsp], xmm7
00007871bd3e3c66  movaps [rsp+0x10], xmm11
00007871bd3e3c6c  movaps [rsp+0x20], xmm9
00007871bd3e3c72  lea rdi, [rsp]
00007871bd3e3c76  mov esi, 0x00
00007871bd3e3c7b  mov rax, 0x5BA2FDD2A530
00007871bd3e3c85  call rax
00007871bd3e3c87  movaps xmm7, [rsp]
00007871bd3e3c8b  add rsp, 0x30
00007871bd3e3c8f  vmovaps xmm0, [rsp]
00007871bd3e3c94  vmovaps xmm1, [rsp+0x10]
00007871bd3e3c9a  vmovaps xmm2, [rsp+0x20]
00007871bd3e3ca0  vmovaps xmm3, [rsp+0x30]
00007871bd3e3ca6  vmovaps xmm4, [rsp+0x40]
00007871bd3e3cac  vmovaps xmm5, [rsp+0x50]
00007871bd3e3cb2  vmovaps xmm6, [rsp+0x60]
00007871bd3e3cb8  vmovaps xmm8, [rsp+0x70]
00007871bd3e3cbe  vmovaps xmm9, [rsp+0x80]
00007871bd3e3cc7  vmovaps xmm10, [rsp+0x90]
00007871bd3e3cd0  vmovaps xmm11, [rsp+0xA0]
00007871bd3e3cd9  vmovaps xmm12, [rsp+0xB0]
00007871bd3e3ce2  vmovaps xmm13, [rsp+0xC0]
00007871bd3e3ceb  vmovaps xmm14, [rsp+0xD0]
00007871bd3e3cf4  vmovaps xmm15, [rsp+0xE0]
00007871bd3e3cfd  add rsp, 0xF0
00007871bd3e3d04  pop r11
00007871bd3e3d06  pop r10
00007871bd3e3d08  pop r9
00007871bd3e3d0a  pop r8
00007871bd3e3d0c  pop rsi
00007871bd3e3d0d  pop rdi
00007871bd3e3d0e  pop rdx
00007871bd3e3d0f  pop rcx
00007871bd3e3d10  pop rax
00007871bd3e3d11  add rsp, 0x08
00007871bd3e3d15  jmp 0x00007871BD3DF865
00007871bd3e3d1a  sub rsp, 0x08
00007871bd3e3d1e  push rax
00007871bd3e3d1f  push rcx
00007871bd3e3d20  push rdx
00007871bd3e3d21  push rdi
00007871bd3e3d22  push rsi
00007871bd3e3d23  push r8
00007871bd3e3d25  push r9
00007871bd3e3d27  push r10
00007871bd3e3d29  push r11
00007871bd3e3d2b  sub rsp, 0xF0
00007871bd3e3d32  vmovaps [rsp], xmm0
00007871bd3e3d37  vmovaps [rsp+0x10], xmm1
00007871bd3e3d3d  vmovaps [rsp+0x20], xmm2
00007871bd3e3d43  vmovaps [rsp+0x30], xmm3
00007871bd3e3d49  vmovaps [rsp+0x40], xmm4
00007871bd3e3d4f  vmovaps [rsp+0x50], xmm5
00007871bd3e3d55  vmovaps [rsp+0x60], xmm6
00007871bd3e3d5b  vmovaps [rsp+0x70], xmm7
00007871bd3e3d61  vmovaps [rsp+0x80], xmm8
00007871bd3e3d6a  vmovaps [rsp+0x90], xmm9
00007871bd3e3d73  vmovaps [rsp+0xA0], xmm10
00007871bd3e3d7c  vmovaps [rsp+0xB0], xmm12
00007871bd3e3d85  vmovaps [rsp+0xC0], xmm13
00007871bd3e3d8e  vmovaps [rsp+0xD0], xmm14
00007871bd3e3d97  vmovaps [rsp+0xE0], xmm15
00007871bd3e3da0  sub rsp, 0x30
00007871bd3e3da4  movaps [rsp], xmm11
00007871bd3e3da9  movaps [rsp+0x10], xmm10
00007871bd3e3daf  movaps [rsp+0x20], xmm14
00007871bd3e3db5  lea rdi, [rsp]
00007871bd3e3db9  mov esi, 0x00
00007871bd3e3dbe  mov rax, 0x5BA2FDD2A530
00007871bd3e3dc8  call rax
00007871bd3e3dca  movaps xmm11, [rsp]
00007871bd3e3dcf  add rsp, 0x30
00007871bd3e3dd3  vmovaps xmm0, [rsp]
00007871bd3e3dd8  vmovaps xmm1, [rsp+0x10]
00007871bd3e3dde  vmovaps xmm2, [rsp+0x20]
00007871bd3e3de4  vmovaps xmm3, [rsp+0x30]
00007871bd3e3dea  vmovaps xmm4, [rsp+0x40]
00007871bd3e3df0  vmovaps xmm5, [rsp+0x50]
00007871bd3e3df6  vmovaps xmm6, [rsp+0x60]
00007871bd3e3dfc  vmovaps xmm7, [rsp+0x70]
00007871bd3e3e02  vmovaps xmm8, [rsp+0x80]
00007871bd3e3e0b  vmovaps xmm9, [rsp+0x90]
00007871bd3e3e14  vmovaps xmm10, [rsp+0xA0]
00007871bd3e3e1d  vmovaps xmm12, [rsp+0xB0]
00007871bd3e3e26  vmovaps xmm13, [rsp+0xC0]
00007871bd3e3e2f  vmovaps xmm14, [rsp+0xD0]
00007871bd3e3e38  vmovaps xmm15, [rsp+0xE0]
00007871bd3e3e41  add rsp, 0xF0
00007871bd3e3e48  pop r11
00007871bd3e3e4a  pop r10
00007871bd3e3e4c  pop r9
00007871bd3e3e4e  pop r8
00007871bd3e3e50  pop rsi
00007871bd3e3e51  pop rdi
00007871bd3e3e52  pop rdx
00007871bd3e3e53  pop rcx
00007871bd3e3e54  pop rax
00007871bd3e3e55  add rsp, 0x08
00007871bd3e3e59  jmp 0x00007871BD3DF880
00007871bd3e3e5e  call 0x00007871BD2C33A0
00007871bd3e3e63  jmp 0x00007871BD3DF88A
00007871bd3e3e68  sub rsp, 0x08
00007871bd3e3e6c  push rax
00007871bd3e3e6d  push rcx
00007871bd3e3e6e  push rdx
00007871bd3e3e6f  push rdi
00007871bd3e3e70  push rsi
00007871bd3e3e71  push r8
00007871bd3e3e73  push r9
00007871bd3e3e75  push r10
00007871bd3e3e77  push r11
00007871bd3e3e79  sub rsp, 0xF0
00007871bd3e3e80  vmovaps [rsp], xmm0
00007871bd3e3e85  vmovaps [rsp+0x10], xmm1
00007871bd3e3e8b  vmovaps [rsp+0x20], xmm2
00007871bd3e3e91  vmovaps [rsp+0x30], xmm3
00007871bd3e3e97  vmovaps [rsp+0x40], xmm4
00007871bd3e3e9d  vmovaps [rsp+0x50], xmm5
00007871bd3e3ea3  vmovaps [rsp+0x60], xmm6
00007871bd3e3ea9  vmovaps [rsp+0x70], xmm7
00007871bd3e3eaf  vmovaps [rsp+0x80], xmm8
00007871bd3e3eb8  vmovaps [rsp+0x90], xmm9
00007871bd3e3ec1  vmovaps [rsp+0xA0], xmm11
00007871bd3e3eca  vmovaps [rsp+0xB0], xmm12
00007871bd3e3ed3  vmovaps [rsp+0xC0], xmm13
00007871bd3e3edc  vmovaps [rsp+0xD0], xmm14
00007871bd3e3ee5  vmovaps [rsp+0xE0], xmm15
00007871bd3e3eee  sub rsp, 0x30
00007871bd3e3ef2  movaps [rsp], xmm10
00007871bd3e3ef7  movaps [rsp+0x10], xmm1
00007871bd3e3efc  movaps [rsp+0x20], xmm12
00007871bd3e3f02  lea rdi, [rsp]
00007871bd3e3f06  mov esi, 0x00
00007871bd3e3f0b  mov rax, 0x5BA2FDD2A530
00007871bd3e3f15  call rax
00007871bd3e3f17  movaps xmm10, [rsp]
00007871bd3e3f1c  add rsp, 0x30
00007871bd3e3f20  vmovaps xmm0, [rsp]
00007871bd3e3f25  vmovaps xmm1, [rsp+0x10]
00007871bd3e3f2b  vmovaps xmm2, [rsp+0x20]
00007871bd3e3f31  vmovaps xmm3, [rsp+0x30]
00007871bd3e3f37  vmovaps xmm4, [rsp+0x40]
00007871bd3e3f3d  vmovaps xmm5, [rsp+0x50]
00007871bd3e3f43  vmovaps xmm6, [rsp+0x60]
00007871bd3e3f49  vmovaps xmm7, [rsp+0x70]
00007871bd3e3f4f  vmovaps xmm8, [rsp+0x80]
00007871bd3e3f58  vmovaps xmm9, [rsp+0x90]
00007871bd3e3f61  vmovaps xmm11, [rsp+0xA0]
00007871bd3e3f6a  vmovaps xmm12, [rsp+0xB0]
00007871bd3e3f73  vmovaps xmm13, [rsp+0xC0]
00007871bd3e3f7c  vmovaps xmm14, [rsp+0xD0]
00007871bd3e3f85  vmovaps xmm15, [rsp+0xE0]
00007871bd3e3f8e  add rsp, 0xF0
00007871bd3e3f95  pop r11
00007871bd3e3f97  pop r10
00007871bd3e3f99  pop r9
00007871bd3e3f9b  pop r8
00007871bd3e3f9d  pop rsi
00007871bd3e3f9e  pop rdi
00007871bd3e3f9f  pop rdx
00007871bd3e3fa0  pop rcx
00007871bd3e3fa1  pop rax
00007871bd3e3fa2  add rsp, 0x08
00007871bd3e3fa6  jmp 0x00007871BD3DF8AD
00007871bd3e3fab  sub rsp, 0x08
00007871bd3e3faf  push rax
00007871bd3e3fb0  push rcx
00007871bd3e3fb1  push rdx
00007871bd3e3fb2  push rdi
00007871bd3e3fb3  push rsi
00007871bd3e3fb4  push r8
00007871bd3e3fb6  push r9
00007871bd3e3fb8  push r10
00007871bd3e3fba  push r11
00007871bd3e3fbc  sub rsp, 0xF0
00007871bd3e3fc3  vmovaps [rsp], xmm0
00007871bd3e3fc8  vmovaps [rsp+0x10], xmm1
00007871bd3e3fce  vmovaps [rsp+0x20], xmm2
00007871bd3e3fd4  vmovaps [rsp+0x30], xmm3
00007871bd3e3fda  vmovaps [rsp+0x40], xmm4
00007871bd3e3fe0  vmovaps [rsp+0x50], xmm5
00007871bd3e3fe6  vmovaps [rsp+0x60], xmm6
00007871bd3e3fec  vmovaps [rsp+0x70], xmm7
00007871bd3e3ff2  vmovaps [rsp+0x80], xmm8
00007871bd3e3ffb  vmovaps [rsp+0x90], xmm9
00007871bd3e4004  vmovaps [rsp+0xA0], xmm10
00007871bd3e400d  vmovaps [rsp+0xB0], xmm11
00007871bd3e4016  vmovaps [rsp+0xC0], xmm13
00007871bd3e401f  vmovaps [rsp+0xD0], xmm14
00007871bd3e4028  vmovaps [rsp+0xE0], xmm15
00007871bd3e4031  sub rsp, 0x30
00007871bd3e4035  movaps [rsp], xmm12
00007871bd3e403a  movaps [rsp+0x10], xmm14
00007871bd3e4040  movaps [rsp+0x20], xmm1
00007871bd3e4045  lea rdi, [rsp]
00007871bd3e4049  mov esi, 0x00
00007871bd3e404e  mov rax, 0x5BA2FDD2A530
00007871bd3e4058  call rax
00007871bd3e405a  movaps xmm12, [rsp]
00007871bd3e405f  add rsp, 0x30
00007871bd3e4063  vmovaps xmm0, [rsp]
00007871bd3e4068  vmovaps xmm1, [rsp+0x10]
00007871bd3e406e  vmovaps xmm2, [rsp+0x20]
00007871bd3e4074  vmovaps xmm3, [rsp+0x30]
00007871bd3e407a  vmovaps xmm4, [rsp+0x40]
00007871bd3e4080  vmovaps xmm5, [rsp+0x50]
00007871bd3e4086  vmovaps xmm6, [rsp+0x60]
00007871bd3e408c  vmovaps xmm7, [rsp+0x70]
00007871bd3e4092  vmovaps xmm8, [rsp+0x80]
00007871bd3e409b  vmovaps xmm9, [rsp+0x90]
00007871bd3e40a4  vmovaps xmm10, [rsp+0xA0]
00007871bd3e40ad  vmovaps xmm11, [rsp+0xB0]
00007871bd3e40b6  vmovaps xmm13, [rsp+0xC0]
00007871bd3e40bf  vmovaps xmm14, [rsp+0xD0]
00007871bd3e40c8  vmovaps xmm15, [rsp+0xE0]
00007871bd3e40d1  add rsp, 0xF0
00007871bd3e40d8  pop r11
00007871bd3e40da  pop r10
00007871bd3e40dc  pop r9
00007871bd3e40de  pop r8
00007871bd3e40e0  pop rsi
00007871bd3e40e1  pop rdi
00007871bd3e40e2  pop rdx
00007871bd3e40e3  pop rcx
00007871bd3e40e4  pop rax
00007871bd3e40e5  add rsp, 0x08
00007871bd3e40e9  jmp 0x00007871BD3DF8DC
00007871bd3e40ee  sub rsp, 0x08
00007871bd3e40f2  push rax
00007871bd3e40f3  push rcx
00007871bd3e40f4  push rdx
00007871bd3e40f5  push rdi
00007871bd3e40f6  push rsi
00007871bd3e40f7  push r8
00007871bd3e40f9  push r9
00007871bd3e40fb  push r10
00007871bd3e40fd  push r11
00007871bd3e40ff  sub rsp, 0xF0
00007871bd3e4106  vmovaps [rsp], xmm0
00007871bd3e410b  vmovaps [rsp+0x10], xmm1
00007871bd3e4111  vmovaps [rsp+0x20], xmm2
00007871bd3e4117  vmovaps [rsp+0x30], xmm3
00007871bd3e411d  vmovaps [rsp+0x40], xmm4
00007871bd3e4123  vmovaps [rsp+0x50], xmm5
00007871bd3e4129  vmovaps [rsp+0x60], xmm6
00007871bd3e412f  vmovaps [rsp+0x70], xmm7
00007871bd3e4135  vmovaps [rsp+0x80], xmm8
00007871bd3e413e  vmovaps [rsp+0x90], xmm9
00007871bd3e4147  vmovaps [rsp+0xA0], xmm10
00007871bd3e4150  vmovaps [rsp+0xB0], xmm11
00007871bd3e4159  vmovaps [rsp+0xC0], xmm12
00007871bd3e4162  vmovaps [rsp+0xD0], xmm13
00007871bd3e416b  vmovaps [rsp+0xE0], xmm15
00007871bd3e4174  sub rsp, 0x30
00007871bd3e4178  movaps [rsp], xmm14
00007871bd3e417d  movaps [rsp+0x10], xmm9
00007871bd3e4183  movaps [rsp+0x20], xmm1
00007871bd3e4188  lea rdi, [rsp]
00007871bd3e418c  mov esi, 0x00
00007871bd3e4191  mov rax, 0x5BA2FDD2A530
00007871bd3e419b  call rax
00007871bd3e419d  movaps xmm14, [rsp]
00007871bd3e41a2  add rsp, 0x30
00007871bd3e41a6  vmovaps xmm0, [rsp]
00007871bd3e41ab  vmovaps xmm1, [rsp+0x10]
00007871bd3e41b1  vmovaps xmm2, [rsp+0x20]
00007871bd3e41b7  vmovaps xmm3, [rsp+0x30]
00007871bd3e41bd  vmovaps xmm4, [rsp+0x40]
00007871bd3e41c3  vmovaps xmm5, [rsp+0x50]
00007871bd3e41c9  vmovaps xmm6, [rsp+0x60]
00007871bd3e41cf  vmovaps xmm7, [rsp+0x70]
00007871bd3e41d5  vmovaps xmm8, [rsp+0x80]
00007871bd3e41de  vmovaps xmm9, [rsp+0x90]
00007871bd3e41e7  vmovaps xmm10, [rsp+0xA0]
00007871bd3e41f0  vmovaps xmm11, [rsp+0xB0]
00007871bd3e41f9  vmovaps xmm12, [rsp+0xC0]
00007871bd3e4202  vmovaps xmm13, [rsp+0xD0]
00007871bd3e420b  vmovaps xmm15, [rsp+0xE0]
00007871bd3e4214  add rsp, 0xF0
00007871bd3e421b  pop r11
00007871bd3e421d  pop r10
00007871bd3e421f  pop r9
00007871bd3e4221  pop r8
00007871bd3e4223  pop rsi
00007871bd3e4224  pop rdi
00007871bd3e4225  pop rdx
00007871bd3e4226  pop rcx
00007871bd3e4227  pop rax
00007871bd3e4228  add rsp, 0x08
00007871bd3e422c  jmp 0x00007871BD3DF90B
00007871bd3e4231  sub rsp, 0x08
00007871bd3e4235  push rax
00007871bd3e4236  push rcx
00007871bd3e4237  push rdx
00007871bd3e4238  push rdi
00007871bd3e4239  push rsi
00007871bd3e423a  push r8
00007871bd3e423c  push r9
00007871bd3e423e  push r10
00007871bd3e4240  push r11
00007871bd3e4242  sub rsp, 0xF0
00007871bd3e4249  vmovaps [rsp], xmm0
00007871bd3e424e  vmovaps [rsp+0x10], xmm2
00007871bd3e4254  vmovaps [rsp+0x20], xmm3
00007871bd3e425a  vmovaps [rsp+0x30], xmm4
00007871bd3e4260  vmovaps [rsp+0x40], xmm5
00007871bd3e4266  vmovaps [rsp+0x50], xmm6
00007871bd3e426c  vmovaps [rsp+0x60], xmm7
00007871bd3e4272  vmovaps [rsp+0x70], xmm8
00007871bd3e4278  vmovaps [rsp+0x80], xmm9
00007871bd3e4281  vmovaps [rsp+0x90], xmm10
00007871bd3e428a  vmovaps [rsp+0xA0], xmm11
00007871bd3e4293  vmovaps [rsp+0xB0], xmm12
00007871bd3e429c  vmovaps [rsp+0xC0], xmm13
00007871bd3e42a5  vmovaps [rsp+0xD0], xmm14
00007871bd3e42ae  vmovaps [rsp+0xE0], xmm15
00007871bd3e42b7  sub rsp, 0x30
00007871bd3e42bb  movaps [rsp], xmm1
00007871bd3e42bf  movaps [rsp+0x10], xmm13
00007871bd3e42c5  movaps [rsp+0x20], xmm8
00007871bd3e42cb  lea rdi, [rsp]
00007871bd3e42cf  mov esi, 0x00
00007871bd3e42d4  mov rax, 0x5BA2FDD2A530
00007871bd3e42de  call rax
00007871bd3e42e0  movaps xmm1, [rsp]
00007871bd3e42e4  add rsp, 0x30
00007871bd3e42e8  vmovaps xmm0, [rsp]
00007871bd3e42ed  vmovaps xmm2, [rsp+0x10]
00007871bd3e42f3  vmovaps xmm3, [rsp+0x20]
00007871bd3e42f9  vmovaps xmm4, [rsp+0x30]
00007871bd3e42ff  vmovaps xmm5, [rsp+0x40]
00007871bd3e4305  vmovaps xmm6, [rsp+0x50]
00007871bd3e430b  vmovaps xmm7, [rsp+0x60]
00007871bd3e4311  vmovaps xmm8, [rsp+0x70]
00007871bd3e4317  vmovaps xmm9, [rsp+0x80]
00007871bd3e4320  vmovaps xmm10, [rsp+0x90]
00007871bd3e4329  vmovaps xmm11, [rsp+0xA0]
00007871bd3e4332  vmovaps xmm12, [rsp+0xB0]
00007871bd3e433b  vmovaps xmm13, [rsp+0xC0]
00007871bd3e4344  vmovaps xmm14, [rsp+0xD0]
00007871bd3e434d  vmovaps xmm15, [rsp+0xE0]
00007871bd3e4356  add rsp, 0xF0
00007871bd3e435d  pop r11
00007871bd3e435f  pop r10
00007871bd3e4361  pop r9
00007871bd3e4363  pop r8
00007871bd3e4365  pop rsi
00007871bd3e4366  pop rdi
00007871bd3e4367  pop rdx
00007871bd3e4368  pop rcx
00007871bd3e4369  pop rax
00007871bd3e436a  add rsp, 0x08
00007871bd3e436e  jmp 0x00007871BD3DF92D
00007871bd3e4373  call 0x00007871BD20C260
00007871bd3e4378  jmp 0x00007871BD3DF93B
00007871bd3e437d  call 0x00007871BD2BD750
00007871bd3e4382  jmp 0x00007871BD3DF945
00007871bd3e4387  sub rsp, 0x08
00007871bd3e438b  push rax
00007871bd3e438c  push rcx
00007871bd3e438d  push rdx
00007871bd3e438e  push rdi
00007871bd3e438f  push rsi
00007871bd3e4390  push r8
00007871bd3e4392  push r9
00007871bd3e4394  push r10
00007871bd3e4396  push r11
00007871bd3e4398  sub rsp, 0xF0
00007871bd3e439f  vmovaps [rsp], xmm0
00007871bd3e43a4  vmovaps [rsp+0x10], xmm1
00007871bd3e43aa  vmovaps [rsp+0x20], xmm2
00007871bd3e43b0  vmovaps [rsp+0x30], xmm3
00007871bd3e43b6  vmovaps [rsp+0x40], xmm4
00007871bd3e43bc  vmovaps [rsp+0x50], xmm5
00007871bd3e43c2  vmovaps [rsp+0x60], xmm6
00007871bd3e43c8  vmovaps [rsp+0x70], xmm7
00007871bd3e43ce  vmovaps [rsp+0x80], xmm9
00007871bd3e43d7  vmovaps [rsp+0x90], xmm10
00007871bd3e43e0  vmovaps [rsp+0xA0], xmm11
00007871bd3e43e9  vmovaps [rsp+0xB0], xmm12
00007871bd3e43f2  vmovaps [rsp+0xC0], xmm13
00007871bd3e43fb  vmovaps [rsp+0xD0], xmm14
00007871bd3e4404  vmovaps [rsp+0xE0], xmm15
00007871bd3e440d  sub rsp, 0x30
00007871bd3e4411  movaps [rsp], xmm8
00007871bd3e4416  movaps [rsp+0x10], xmm15
00007871bd3e441c  movaps [rsp+0x20], xmm7
00007871bd3e4421  lea rdi, [rsp]
00007871bd3e4425  mov esi, 0x00
00007871bd3e442a  mov rax, 0x5BA2FDD2A530
00007871bd3e4434  call rax
00007871bd3e4436  movaps xmm8, [rsp]
00007871bd3e443b  add rsp, 0x30
00007871bd3e443f  vmovaps xmm0, [rsp]
00007871bd3e4444  vmovaps xmm1, [rsp+0x10]
00007871bd3e444a  vmovaps xmm2, [rsp+0x20]
00007871bd3e4450  vmovaps xmm3, [rsp+0x30]
00007871bd3e4456  vmovaps xmm4, [rsp+0x40]
00007871bd3e445c  vmovaps xmm5, [rsp+0x50]
00007871bd3e4462  vmovaps xmm6, [rsp+0x60]
00007871bd3e4468  vmovaps xmm7, [rsp+0x70]
00007871bd3e446e  vmovaps xmm9, [rsp+0x80]
00007871bd3e4477  vmovaps xmm10, [rsp+0x90]
00007871bd3e4480  vmovaps xmm11, [rsp+0xA0]
00007871bd3e4489  vmovaps xmm12, [rsp+0xB0]
00007871bd3e4492  vmovaps xmm13, [rsp+0xC0]
00007871bd3e449b  vmovaps xmm14, [rsp+0xD0]
00007871bd3e44a4  vmovaps xmm15, [rsp+0xE0]
00007871bd3e44ad  add rsp, 0xF0
00007871bd3e44b4  pop r11
00007871bd3e44b6  pop r10
00007871bd3e44b8  pop r9
00007871bd3e44ba  pop r8
00007871bd3e44bc  pop rsi
00007871bd3e44bd  pop rdi
00007871bd3e44be  pop rdx
00007871bd3e44bf  pop rcx
00007871bd3e44c0  pop rax
00007871bd3e44c1  add rsp, 0x08
00007871bd3e44c5  jmp 0x00007871BD3DF967
00007871bd3e44ca  sub rsp, 0x08
00007871bd3e44ce  push rax
00007871bd3e44cf  push rcx
00007871bd3e44d0  push rdx
00007871bd3e44d1  push rdi
00007871bd3e44d2  push rsi
00007871bd3e44d3  push r8
00007871bd3e44d5  push r9
00007871bd3e44d7  push r10
00007871bd3e44d9  push r11
00007871bd3e44db  sub rsp, 0xF0
00007871bd3e44e2  vmovaps [rsp], xmm0
00007871bd3e44e7  vmovaps [rsp+0x10], xmm1
00007871bd3e44ed  vmovaps [rsp+0x20], xmm2
00007871bd3e44f3  vmovaps [rsp+0x30], xmm3
00007871bd3e44f9  vmovaps [rsp+0x40], xmm4
00007871bd3e44ff  vmovaps [rsp+0x50], xmm5
00007871bd3e4505  vmovaps [rsp+0x60], xmm6
00007871bd3e450b  vmovaps [rsp+0x70], xmm8
00007871bd3e4511  vmovaps [rsp+0x80], xmm9
00007871bd3e451a  vmovaps [rsp+0x90], xmm10
00007871bd3e4523  vmovaps [rsp+0xA0], xmm11
00007871bd3e452c  vmovaps [rsp+0xB0], xmm12
00007871bd3e4535  vmovaps [rsp+0xC0], xmm13
00007871bd3e453e  vmovaps [rsp+0xD0], xmm14
00007871bd3e4547  vmovaps [rsp+0xE0], xmm15
00007871bd3e4550  sub rsp, 0x30
00007871bd3e4554  movaps [rsp], xmm7
00007871bd3e4558  movaps [rsp+0x10], xmm9
00007871bd3e455e  movaps [rsp+0x20], xmm15
00007871bd3e4564  lea rdi, [rsp]
00007871bd3e4568  mov esi, 0x00
00007871bd3e456d  mov rax, 0x5BA2FDD2A530
00007871bd3e4577  call rax
00007871bd3e4579  movaps xmm7, [rsp]
00007871bd3e457d  add rsp, 0x30
00007871bd3e4581  vmovaps xmm0, [rsp]
00007871bd3e4586  vmovaps xmm1, [rsp+0x10]
00007871bd3e458c  vmovaps xmm2, [rsp+0x20]
00007871bd3e4592  vmovaps xmm3, [rsp+0x30]
00007871bd3e4598  vmovaps xmm4, [rsp+0x40]
00007871bd3e459e  vmovaps xmm5, [rsp+0x50]
00007871bd3e45a4  vmovaps xmm6, [rsp+0x60]
00007871bd3e45aa  vmovaps xmm8, [rsp+0x70]
00007871bd3e45b0  vmovaps xmm9, [rsp+0x80]
00007871bd3e45b9  vmovaps xmm10, [rsp+0x90]
00007871bd3e45c2  vmovaps xmm11, [rsp+0xA0]
00007871bd3e45cb  vmovaps xmm12, [rsp+0xB0]
00007871bd3e45d4  vmovaps xmm13, [rsp+0xC0]
00007871bd3e45dd  vmovaps xmm14, [rsp+0xD0]
00007871bd3e45e6  vmovaps xmm15, [rsp+0xE0]
00007871bd3e45ef  add rsp, 0xF0
00007871bd3e45f6  pop r11
00007871bd3e45f8  pop r10
00007871bd3e45fa  pop r9
00007871bd3e45fc  pop r8
00007871bd3e45fe  pop rsi
00007871bd3e45ff  pop rdi
00007871bd3e4600  pop rdx
00007871bd3e4601  pop rcx
00007871bd3e4602  pop rax
00007871bd3e4603  add rsp, 0x08
00007871bd3e4607  jmp 0x00007871BD3DF994
00007871bd3e460c  sub rsp, 0x08
00007871bd3e4610  push rax
00007871bd3e4611  push rcx
00007871bd3e4612  push rdx
00007871bd3e4613  push rdi
00007871bd3e4614  push rsi
00007871bd3e4615  push r8
00007871bd3e4617  push r9
00007871bd3e4619  push r10
00007871bd3e461b  push r11
00007871bd3e461d  sub rsp, 0xF0
00007871bd3e4624  vmovaps [rsp], xmm0
00007871bd3e4629  vmovaps [rsp+0x10], xmm1
00007871bd3e462f  vmovaps [rsp+0x20], xmm2
00007871bd3e4635  vmovaps [rsp+0x30], xmm3
00007871bd3e463b  vmovaps [rsp+0x40], xmm4
00007871bd3e4641  vmovaps [rsp+0x50], xmm5
00007871bd3e4647  vmovaps [rsp+0x60], xmm6
00007871bd3e464d  vmovaps [rsp+0x70], xmm7
00007871bd3e4653  vmovaps [rsp+0x80], xmm8
00007871bd3e465c  vmovaps [rsp+0x90], xmm10
00007871bd3e4665  vmovaps [rsp+0xA0], xmm11
00007871bd3e466e  vmovaps [rsp+0xB0], xmm12
00007871bd3e4677  vmovaps [rsp+0xC0], xmm13
00007871bd3e4680  vmovaps [rsp+0xD0], xmm14
00007871bd3e4689  vmovaps [rsp+0xE0], xmm15
00007871bd3e4692  sub rsp, 0x30
00007871bd3e4696  movaps [rsp], xmm9
00007871bd3e469b  movaps [rsp+0x10], xmm13
00007871bd3e46a1  movaps [rsp+0x20], xmm15
00007871bd3e46a7  lea rdi, [rsp]
00007871bd3e46ab  mov esi, 0x00
00007871bd3e46b0  mov rax, 0x5BA2FDD2A530
00007871bd3e46ba  call rax
00007871bd3e46bc  movaps xmm9, [rsp]
00007871bd3e46c1  add rsp, 0x30
00007871bd3e46c5  vmovaps xmm0, [rsp]
00007871bd3e46ca  vmovaps xmm1, [rsp+0x10]
00007871bd3e46d0  vmovaps xmm2, [rsp+0x20]
00007871bd3e46d6  vmovaps xmm3, [rsp+0x30]
00007871bd3e46dc  vmovaps xmm4, [rsp+0x40]
00007871bd3e46e2  vmovaps xmm5, [rsp+0x50]
00007871bd3e46e8  vmovaps xmm6, [rsp+0x60]
00007871bd3e46ee  vmovaps xmm7, [rsp+0x70]
00007871bd3e46f4  vmovaps xmm8, [rsp+0x80]
00007871bd3e46fd  vmovaps xmm10, [rsp+0x90]
00007871bd3e4706  vmovaps xmm11, [rsp+0xA0]
00007871bd3e470f  vmovaps xmm12, [rsp+0xB0]
00007871bd3e4718  vmovaps xmm13, [rsp+0xC0]
00007871bd3e4721  vmovaps xmm14, [rsp+0xD0]
00007871bd3e472a  vmovaps xmm15, [rsp+0xE0]
00007871bd3e4733  add rsp, 0xF0
00007871bd3e473a  pop r11
00007871bd3e473c  pop r10
00007871bd3e473e  pop r9
00007871bd3e4740  pop r8
00007871bd3e4742  pop rsi
00007871bd3e4743  pop rdi
00007871bd3e4744  pop rdx
00007871bd3e4745  pop rcx
00007871bd3e4746  pop rax
00007871bd3e4747  add rsp, 0x08
00007871bd3e474b  jmp 0x00007871BD3DF9C2
00007871bd3e4750  sub rsp, 0x08
00007871bd3e4754  push rax
00007871bd3e4755  push rcx
00007871bd3e4756  push rdx
00007871bd3e4757  push rdi
00007871bd3e4758  push rsi
00007871bd3e4759  push r8
00007871bd3e475b  push r9
00007871bd3e475d  push r10
00007871bd3e475f  push r11
00007871bd3e4761  sub rsp, 0xF0
00007871bd3e4768  vmovaps [rsp], xmm0
00007871bd3e476d  vmovaps [rsp+0x10], xmm1
00007871bd3e4773  vmovaps [rsp+0x20], xmm2
00007871bd3e4779  vmovaps [rsp+0x30], xmm3
00007871bd3e477f  vmovaps [rsp+0x40], xmm4
00007871bd3e4785  vmovaps [rsp+0x50], xmm5
00007871bd3e478b  vmovaps [rsp+0x60], xmm6
00007871bd3e4791  vmovaps [rsp+0x70], xmm7
00007871bd3e4797  vmovaps [rsp+0x80], xmm8
00007871bd3e47a0  vmovaps [rsp+0x90], xmm9
00007871bd3e47a9  vmovaps [rsp+0xA0], xmm10
00007871bd3e47b2  vmovaps [rsp+0xB0], xmm11
00007871bd3e47bb  vmovaps [rsp+0xC0], xmm12
00007871bd3e47c4  vmovaps [rsp+0xD0], xmm13
00007871bd3e47cd  vmovaps [rsp+0xE0], xmm14
00007871bd3e47d6  sub rsp, 0x30
00007871bd3e47da  movaps [rsp], xmm15
00007871bd3e47df  movaps [rsp+0x10], xmm11
00007871bd3e47e5  movaps [rsp+0x20], xmm12
00007871bd3e47eb  lea rdi, [rsp]
00007871bd3e47ef  mov esi, 0x00
00007871bd3e47f4  mov rax, 0x5BA2FDD2A530
00007871bd3e47fe  call rax
00007871bd3e4800  movaps xmm15, [rsp]
00007871bd3e4805  add rsp, 0x30
00007871bd3e4809  vmovaps xmm0, [rsp]
00007871bd3e480e  vmovaps xmm1, [rsp+0x10]
00007871bd3e4814  vmovaps xmm2, [rsp+0x20]
00007871bd3e481a  vmovaps xmm3, [rsp+0x30]
00007871bd3e4820  vmovaps xmm4, [rsp+0x40]
00007871bd3e4826  vmovaps xmm5, [rsp+0x50]
00007871bd3e482c  vmovaps xmm6, [rsp+0x60]
00007871bd3e4832  vmovaps xmm7, [rsp+0x70]
00007871bd3e4838  vmovaps xmm8, [rsp+0x80]
00007871bd3e4841  vmovaps xmm9, [rsp+0x90]
00007871bd3e484a  vmovaps xmm10, [rsp+0xA0]
00007871bd3e4853  vmovaps xmm11, [rsp+0xB0]
00007871bd3e485c  vmovaps xmm12, [rsp+0xC0]
00007871bd3e4865  vmovaps xmm13, [rsp+0xD0]
00007871bd3e486e  vmovaps xmm14, [rsp+0xE0]
00007871bd3e4877  add rsp, 0xF0
00007871bd3e487e  pop r11
00007871bd3e4880  pop r10
00007871bd3e4882  pop r9
00007871bd3e4884  pop r8
00007871bd3e4886  pop rsi
00007871bd3e4887  pop rdi
00007871bd3e4888  pop rdx
00007871bd3e4889  pop rcx
00007871bd3e488a  pop rax
00007871bd3e488b  add rsp, 0x08
00007871bd3e488f  jmp 0x00007871BD3DF9DD
00007871bd3e4894  sub rsp, 0x08
00007871bd3e4898  push rax
00007871bd3e4899  push rcx
00007871bd3e489a  push rdx
00007871bd3e489b  push rdi
00007871bd3e489c  push rsi
00007871bd3e489d  push r8
00007871bd3e489f  push r9
00007871bd3e48a1  push r10
00007871bd3e48a3  push r11
00007871bd3e48a5  sub rsp, 0xF0
00007871bd3e48ac  vmovaps [rsp], xmm0
00007871bd3e48b1  vmovaps [rsp+0x10], xmm1
00007871bd3e48b7  vmovaps [rsp+0x20], xmm2
00007871bd3e48bd  vmovaps [rsp+0x30], xmm3
00007871bd3e48c3  vmovaps [rsp+0x40], xmm4
00007871bd3e48c9  vmovaps [rsp+0x50], xmm5
00007871bd3e48cf  vmovaps [rsp+0x60], xmm6
00007871bd3e48d5  vmovaps [rsp+0x70], xmm7
00007871bd3e48db  vmovaps [rsp+0x80], xmm8
00007871bd3e48e4  vmovaps [rsp+0x90], xmm9
00007871bd3e48ed  vmovaps [rsp+0xA0], xmm10
00007871bd3e48f6  vmovaps [rsp+0xB0], xmm11
00007871bd3e48ff  vmovaps [rsp+0xC0], xmm12
00007871bd3e4908  vmovaps [rsp+0xD0], xmm14
00007871bd3e4911  vmovaps [rsp+0xE0], xmm15
00007871bd3e491a  sub rsp, 0x30
00007871bd3e491e  movaps [rsp], xmm13
00007871bd3e4923  movaps [rsp+0x10], xmm10
00007871bd3e4929  movaps [rsp+0x20], xmm14
00007871bd3e492f  lea rdi, [rsp]
00007871bd3e4933  mov esi, 0x00
00007871bd3e4938  mov rax, 0x5BA2FDD2A530
00007871bd3e4942  call rax
00007871bd3e4944  movaps xmm13, [rsp]
00007871bd3e4949  add rsp, 0x30
00007871bd3e494d  vmovaps xmm0, [rsp]
00007871bd3e4952  vmovaps xmm1, [rsp+0x10]
00007871bd3e4958  vmovaps xmm2, [rsp+0x20]
00007871bd3e495e  vmovaps xmm3, [rsp+0x30]
00007871bd3e4964  vmovaps xmm4, [rsp+0x40]
00007871bd3e496a  vmovaps xmm5, [rsp+0x50]
00007871bd3e4970  vmovaps xmm6, [rsp+0x60]
00007871bd3e4976  vmovaps xmm7, [rsp+0x70]
00007871bd3e497c  vmovaps xmm8, [rsp+0x80]
00007871bd3e4985  vmovaps xmm9, [rsp+0x90]
00007871bd3e498e  vmovaps xmm10, [rsp+0xA0]
00007871bd3e4997  vmovaps xmm11, [rsp+0xB0]
00007871bd3e49a0  vmovaps xmm12, [rsp+0xC0]
00007871bd3e49a9  vmovaps xmm14, [rsp+0xD0]
00007871bd3e49b2  vmovaps xmm15, [rsp+0xE0]
00007871bd3e49bb  add rsp, 0xF0
00007871bd3e49c2  pop r11
00007871bd3e49c4  pop r10
00007871bd3e49c6  pop r9
00007871bd3e49c8  pop r8
00007871bd3e49ca  pop rsi
00007871bd3e49cb  pop rdi
00007871bd3e49cc  pop rdx
00007871bd3e49cd  pop rcx
00007871bd3e49ce  pop rax
00007871bd3e49cf  add rsp, 0x08
00007871bd3e49d3  jmp 0x00007871BD3DFA00
00007871bd3e49d8  sub rsp, 0x08
00007871bd3e49dc  push rax
00007871bd3e49dd  push rcx
00007871bd3e49de  push rdx
00007871bd3e49df  push rdi
00007871bd3e49e0  push rsi
00007871bd3e49e1  push r8
00007871bd3e49e3  push r9
00007871bd3e49e5  push r10
00007871bd3e49e7  push r11
00007871bd3e49e9  sub rsp, 0xF0
00007871bd3e49f0  vmovaps [rsp], xmm0
00007871bd3e49f5  vmovaps [rsp+0x10], xmm1
00007871bd3e49fb  vmovaps [rsp+0x20], xmm2
00007871bd3e4a01  vmovaps [rsp+0x30], xmm3
00007871bd3e4a07  vmovaps [rsp+0x40], xmm4
00007871bd3e4a0d  vmovaps [rsp+0x50], xmm5
00007871bd3e4a13  vmovaps [rsp+0x60], xmm6
00007871bd3e4a19  vmovaps [rsp+0x70], xmm7
00007871bd3e4a1f  vmovaps [rsp+0x80], xmm8
00007871bd3e4a28  vmovaps [rsp+0x90], xmm9
00007871bd3e4a31  vmovaps [rsp+0xA0], xmm10
00007871bd3e4a3a  vmovaps [rsp+0xB0], xmm11
00007871bd3e4a43  vmovaps [rsp+0xC0], xmm12
00007871bd3e4a4c  vmovaps [rsp+0xD0], xmm13
00007871bd3e4a55  vmovaps [rsp+0xE0], xmm15
00007871bd3e4a5e  sub rsp, 0x30
00007871bd3e4a62  movaps [rsp], xmm14
00007871bd3e4a67  movaps [rsp+0x10], xmm1
00007871bd3e4a6c  movaps [rsp+0x20], xmm7
00007871bd3e4a71  lea rdi, [rsp]
00007871bd3e4a75  mov esi, 0x00
00007871bd3e4a7a  mov rax, 0x5BA2FDD2A530
00007871bd3e4a84  call rax
00007871bd3e4a86  movaps xmm14, [rsp]
00007871bd3e4a8b  add rsp, 0x30
00007871bd3e4a8f  vmovaps xmm0, [rsp]
00007871bd3e4a94  vmovaps xmm1, [rsp+0x10]
00007871bd3e4a9a  vmovaps xmm2, [rsp+0x20]
00007871bd3e4aa0  vmovaps xmm3, [rsp+0x30]
00007871bd3e4aa6  vmovaps xmm4, [rsp+0x40]
00007871bd3e4aac  vmovaps xmm5, [rsp+0x50]
00007871bd3e4ab2  vmovaps xmm6, [rsp+0x60]
00007871bd3e4ab8  vmovaps xmm7, [rsp+0x70]
00007871bd3e4abe  vmovaps xmm8, [rsp+0x80]
00007871bd3e4ac7  vmovaps xmm9, [rsp+0x90]
00007871bd3e4ad0  vmovaps xmm10, [rsp+0xA0]
00007871bd3e4ad9  vmovaps xmm11, [rsp+0xB0]
00007871bd3e4ae2  vmovaps xmm12, [rsp+0xC0]
00007871bd3e4aeb  vmovaps xmm13, [rsp+0xD0]
00007871bd3e4af4  vmovaps xmm15, [rsp+0xE0]
00007871bd3e4afd  add rsp, 0xF0
00007871bd3e4b04  pop r11
00007871bd3e4b06  pop r10
00007871bd3e4b08  pop r9
00007871bd3e4b0a  pop r8
00007871bd3e4b0c  pop rsi
00007871bd3e4b0d  pop rdi
00007871bd3e4b0e  pop rdx
00007871bd3e4b0f  pop rcx
00007871bd3e4b10  pop rax
00007871bd3e4b11  add rsp, 0x08
00007871bd3e4b15  jmp 0x00007871BD3DFA23
00007871bd3e4b1a  sub rsp, 0x08
00007871bd3e4b1e  push rax
00007871bd3e4b1f  push rcx
00007871bd3e4b20  push rdx
00007871bd3e4b21  push rdi
00007871bd3e4b22  push rsi
00007871bd3e4b23  push r8
00007871bd3e4b25  push r9
00007871bd3e4b27  push r10
00007871bd3e4b29  push r11
00007871bd3e4b2b  sub rsp, 0xF0
00007871bd3e4b32  vmovaps [rsp], xmm0
00007871bd3e4b37  vmovaps [rsp+0x10], xmm2
00007871bd3e4b3d  vmovaps [rsp+0x20], xmm3
00007871bd3e4b43  vmovaps [rsp+0x30], xmm4
00007871bd3e4b49  vmovaps [rsp+0x40], xmm5
00007871bd3e4b4f  vmovaps [rsp+0x50], xmm6
00007871bd3e4b55  vmovaps [rsp+0x60], xmm7
00007871bd3e4b5b  vmovaps [rsp+0x70], xmm8
00007871bd3e4b61  vmovaps [rsp+0x80], xmm9
00007871bd3e4b6a  vmovaps [rsp+0x90], xmm10
00007871bd3e4b73  vmovaps [rsp+0xA0], xmm11
00007871bd3e4b7c  vmovaps [rsp+0xB0], xmm12
00007871bd3e4b85  vmovaps [rsp+0xC0], xmm13
00007871bd3e4b8e  vmovaps [rsp+0xD0], xmm14
00007871bd3e4b97  vmovaps [rsp+0xE0], xmm15
00007871bd3e4ba0  sub rsp, 0x30
00007871bd3e4ba4  movaps [rsp], xmm1
00007871bd3e4ba8  movaps [rsp+0x10], xmm8
00007871bd3e4bae  movaps [rsp+0x20], xmm9
00007871bd3e4bb4  lea rdi, [rsp]
00007871bd3e4bb8  mov esi, 0x00
00007871bd3e4bbd  mov rax, 0x5BA2FDD2A530
00007871bd3e4bc7  call rax
00007871bd3e4bc9  movaps xmm1, [rsp]
00007871bd3e4bcd  add rsp, 0x30
00007871bd3e4bd1  vmovaps xmm0, [rsp]
00007871bd3e4bd6  vmovaps xmm2, [rsp+0x10]
00007871bd3e4bdc  vmovaps xmm3, [rsp+0x20]
00007871bd3e4be2  vmovaps xmm4, [rsp+0x30]
00007871bd3e4be8  vmovaps xmm5, [rsp+0x40]
00007871bd3e4bee  vmovaps xmm6, [rsp+0x50]
00007871bd3e4bf4  vmovaps xmm7, [rsp+0x60]
00007871bd3e4bfa  vmovaps xmm8, [rsp+0x70]
00007871bd3e4c00  vmovaps xmm9, [rsp+0x80]
00007871bd3e4c09  vmovaps xmm10, [rsp+0x90]
00007871bd3e4c12  vmovaps xmm11, [rsp+0xA0]
00007871bd3e4c1b  vmovaps xmm12, [rsp+0xB0]
00007871bd3e4c24  vmovaps xmm13, [rsp+0xC0]
00007871bd3e4c2d  vmovaps xmm14, [rsp+0xD0]
00007871bd3e4c36  vmovaps xmm15, [rsp+0xE0]
00007871bd3e4c3f  add rsp, 0xF0
00007871bd3e4c46  pop r11
00007871bd3e4c48  pop r10
00007871bd3e4c4a  pop r9
00007871bd3e4c4c  pop r8
00007871bd3e4c4e  pop rsi
00007871bd3e4c4f  pop rdi
00007871bd3e4c50  pop rdx
00007871bd3e4c51  pop rcx
00007871bd3e4c52  pop rax
00007871bd3e4c53  add rsp, 0x08
00007871bd3e4c57  jmp 0x00007871BD3DFA45
00007871bd3e4c5c  call 0x00007871BD2E5940
00007871bd3e4c61  jmp 0x00007871BD3DFA53
00007871bd3e4c66  call 0x00007871BD20C380
00007871bd3e4c6b  jmp 0x00007871BD3DFA5D
00007871bd3e4c70  call 0x00007871BD20D600
00007871bd3e4c75  jmp 0x00007871BD3DFA67
00007871bd3e4c7a  call 0x00007871BD1FF540
00007871bd3e4c7f  jmp 0x00007871BD3DFA71
00007871bd3e4c84  int3
00007871bd3e4c85  nop [rax+rax*1], ax
00007871bd3e4c8e  nop
00007871bd3e4c90  mov qword ptr [r15+0x40], 0x430000
00007871bd3e4c98  mov eax, 0x430CC0
00007871bd3e4c9d  mov r14, [r13+rax*1]
00007871bd3e4ca2  movq xmm1, r14
00007871bd3e4ca7  mov rax, [r15+0x50]
00007871bd3e4cab  movups xmm15, [r13+rax*1]
00007871bd3e4cb1  movaps [r15+0x120], xmm15
00007871bd3e4cb9  mov qword ptr [r15+0x48], 0x10
00007871bd3e4cc1  xor eax, eax
00007871bd3e4cc3  mov r14d, 0x10
00007871bd3e4cc9  mov r12d, 0x200
00007871bd3e4ccf  cmp r14, r12
00007871bd3e4cd2  cmc
00007871bd3e4cd3  lahf
00007871bd3e4cd4  seto al
00007871bd3e4cd7  mov [r15+0x108], eax
00007871bd3e4cde  pextrq rax, xmm15, 0x01
00007871bd3e4ce5  movq xmm14, rax
00007871bd3e4cea  movaps [r15+0x130], xmm14
00007871bd3e4cf2  movq rax, xmm1
00007871bd3e4cf7  movq r14, xmm15
00007871bd3e4cfc  vmovq xmm1, rax
00007871bd3e4d01  vmovq xmm15, r14
00007871bd3e4d06  movaps xmm13, xmm1
00007871bd3e4d0a  addsd xmm13, xmm15
00007871bd3e4d0f  ucomisd xmm13, xmm13
00007871bd3e4d14  jp 0x00007871BD3E4DD3
00007871bd3e4d1a  movq xmm13, xmm13
00007871bd3e4d1f  movq rax, xmm13
00007871bd3e4d24  movq r14, xmm14
00007871bd3e4d29  vmovq xmm1, rax
00007871bd3e4d2e  vmovq xmm15, r14
00007871bd3e4d33  movaps xmm14, xmm1
00007871bd3e4d37  addsd xmm14, xmm15
00007871bd3e4d3c  ucomisd xmm14, xmm14
00007871bd3e4d41  jp 0x00007871BD3E4E1B
00007871bd3e4d47  movq xmm14, xmm14
00007871bd3e4d4c  movaps [r15+0x110], xmm14
00007871bd3e4d54  mov eax, [r15+0x108]
00007871bd3e4d5b  sahf
00007871bd3e4d5c  jnz 0x00007871BD3E4D8E
00007871bd3e4d5e  cmp dword ptr [r15+0x318], 0x00
00007871bd3e4d66  jz 0x00007871BD3E5030
00007871bd3e4d6c  nop [rax+rax*1], ax
00007871bd3e4d75  nop [rax+rax*1], eax
00007871bd3e4d7d  mov eax, 0x410704
00007871bd3e4d82  mov [r15+0x100], rax
00007871bd3e4d89  jmp 0x00007871BD1FE110
00007871bd3e4d8e  cmp dword ptr [r15+0x318], 0x00
00007871bd3e4d96  jz 0x00007871BD3E4E70
00007871bd3e4d9c  nop [rax+rax*1], ax
00007871bd3e4da5  nop [rax+rax*1], eax
00007871bd3e4dad  mov eax, 0x4106E8
00007871bd3e4db2  mov [r15+0x100], rax
00007871bd3e4db9  jmp 0x00007871BD1FE110
00007871bd3e4dbe  int3
00007871bd3e4dbf  call 0x00007871BD20DC20
00007871bd3e4dc4  jmp 0x00007871BD3E4CA2
00007871bd3e4dc9  call 0x00007871BD20E760
00007871bd3e4dce  jmp 0x00007871BD3E4CB1
00007871bd3e4dd3  ucomisd xmm1, xmm15
00007871bd3e4dd8  jp 0x00007871BD3E4DE7
00007871bd3e4dda  movaps xmm13, [0x00007871BCFFE060]
00007871bd3e4de2  jmp 0x00007871BD3E4D1A
00007871bd3e4de7  vxorps xmm0, xmm1, xmm15
00007871bd3e4dec  pextrw eax, xmm0, 0x03
00007871bd3e4df1  and eax, 0x7FF8
00007871bd3e4df6  cmp eax, 0x08
00007871bd3e4df9  jnz 0x00007871BD3E4D1A
00007871bd3e4dff  movq rax, xmm15
00007871bd3e4e04  shl rax, 0x0D
00007871bd3e4e08  jbe 0x00007871BD3E4D1A
00007871bd3e4e0e  vorps xmm13, xmm15, [0x00007871BCFFE070]
00007871bd3e4e16  jmp 0x00007871BD3E4D1A
00007871bd3e4e1b  ucomisd xmm1, xmm15
00007871bd3e4e20  jp 0x00007871BD3E4E2F
00007871bd3e4e22  movaps xmm14, [0x00007871BCFFE060]
00007871bd3e4e2a  jmp 0x00007871BD3E4D47
00007871bd3e4e2f  vxorps xmm0, xmm1, xmm15
00007871bd3e4e34  pextrw eax, xmm0, 0x03
00007871bd3e4e39  and eax, 0x7FF8
00007871bd3e4e3e  cmp eax, 0x08
00007871bd3e4e41  jnz 0x00007871BD3E4D47
00007871bd3e4e47  movq rax, xmm15
00007871bd3e4e4c  shl rax, 0x0D
00007871bd3e4e50  jbe 0x00007871BD3E4D47
00007871bd3e4e56  vorps xmm14, xmm15, [0x00007871BCFFE070]
00007871bd3e4e5e  jmp 0x00007871BD3E4D47
00007871bd3e4e63  int3
00007871bd3e4e64  nop [rax+rax*1], ax
00007871bd3e4e6d  nop [rax], eax
00007871bd3e4e70  mov rax, [r15+0x48]
00007871bd3e4e74  mov r14, [r15+0x50]
00007871bd3e4e78  lea r12, [r14+rax*1]
00007871bd3e4e7c  movups xmm1, [r13+r12*1]
00007871bd3e4e82  movaps [r15+0x120], xmm1
00007871bd3e4e8a  lea r14, [rax+0x10]
00007871bd3e4e8e  mov [r15+0x48], r14
00007871bd3e4e92  xor eax, eax
00007871bd3e4e94  mov r12d, 0x200
00007871bd3e4e9a  cmp r14, r12
00007871bd3e4e9d  cmc
00007871bd3e4e9e  lahf
00007871bd3e4e9f  seto al
00007871bd3e4ea2  mov [r15+0x108], eax
00007871bd3e4ea9  pextrq rax, xmm1, 0x01
00007871bd3e4eb0  movq xmm15, rax
00007871bd3e4eb5  movaps [r15+0x130], xmm15
00007871bd3e4ebd  movaps xmm14, [r15+0x110]
00007871bd3e4ec5  movq rax, xmm14
00007871bd3e4eca  movq r14, xmm1
00007871bd3e4ecf  vmovq xmm1, rax
00007871bd3e4ed4  vmovq xmm14, r14
00007871bd3e4ed9  movaps xmm13, xmm1
00007871bd3e4edd  addsd xmm13, xmm14
00007871bd3e4ee2  ucomisd xmm13, xmm13
00007871bd3e4ee7  jp 0x00007871BD3E4F9C
00007871bd3e4eed  movq xmm13, xmm13
00007871bd3e4ef2  movq rax, xmm13
00007871bd3e4ef7  movq r14, xmm15
00007871bd3e4efc  vmovq xmm1, rax
00007871bd3e4f01  vmovq xmm15, r14
00007871bd3e4f06  movaps xmm14, xmm1
00007871bd3e4f0a  addsd xmm14, xmm15
00007871bd3e4f0f  ucomisd xmm14, xmm14
00007871bd3e4f14  jp 0x00007871BD3E4FE4
00007871bd3e4f1a  movq xmm14, xmm14
00007871bd3e4f1f  movaps [r15+0x110], xmm14
00007871bd3e4f27  mov eax, [r15+0x108]
00007871bd3e4f2e  sahf
00007871bd3e4f2f  jnz 0x00007871BD3E4F61
00007871bd3e4f31  cmp dword ptr [r15+0x318], 0x00
00007871bd3e4f39  jz 0x00007871BD3E5030
00007871bd3e4f3f  nop [rax+rax*1], ax
00007871bd3e4f48  nop [rax+rax*1], eax
00007871bd3e4f50  mov eax, 0x410704
00007871bd3e4f55  mov [r15+0x100], rax
00007871bd3e4f5c  jmp 0x00007871BD1FE110
00007871bd3e4f61  cmp dword ptr [r15+0x318], 0x00
00007871bd3e4f69  jz 0x00007871BD3E4E70
00007871bd3e4f6f  nop [rax+rax*1], ax
00007871bd3e4f78  nop [rax+rax*1], eax
00007871bd3e4f80  mov eax, 0x4106E8
00007871bd3e4f85  mov [r15+0x100], rax
00007871bd3e4f8c  jmp 0x00007871BD1FE110
00007871bd3e4f91  int3
00007871bd3e4f92  call 0x00007871BD2B52F0
00007871bd3e4f97  jmp 0x00007871BD3E4E82
00007871bd3e4f9c  ucomisd xmm1, xmm14
00007871bd3e4fa1  jp 0x00007871BD3E4FB0
00007871bd3e4fa3  movaps xmm13, [0x00007871BCFFE060]
00007871bd3e4fab  jmp 0x00007871BD3E4EED
00007871bd3e4fb0  vxorps xmm0, xmm1, xmm14
00007871bd3e4fb5  pextrw eax, xmm0, 0x03
00007871bd3e4fba  and eax, 0x7FF8
00007871bd3e4fbf  cmp eax, 0x08
00007871bd3e4fc2  jnz 0x00007871BD3E4EED
00007871bd3e4fc8  movq rax, xmm14
00007871bd3e4fcd  shl rax, 0x0D
00007871bd3e4fd1  jbe 0x00007871BD3E4EED
00007871bd3e4fd7  vorps xmm13, xmm14, [0x00007871BCFFE070]
00007871bd3e4fdf  jmp 0x00007871BD3E4EED
00007871bd3e4fe4  ucomisd xmm1, xmm15
00007871bd3e4fe9  jp 0x00007871BD3E4FF8
00007871bd3e4feb  movaps xmm14, [0x00007871BCFFE060]
00007871bd3e4ff3  jmp 0x00007871BD3E4F1A
00007871bd3e4ff8  vxorps xmm0, xmm1, xmm15
00007871bd3e4ffd  pextrw eax, xmm0, 0x03
00007871bd3e5002  and eax, 0x7FF8
00007871bd3e5007  cmp eax, 0x08
00007871bd3e500a  jnz 0x00007871BD3E4F1A
00007871bd3e5010  movq rax, xmm15
00007871bd3e5015  shl rax, 0x0D
00007871bd3e5019  jbe 0x00007871BD3E4F1A
00007871bd3e501f  vorps xmm14, xmm15, [0x00007871BCFFE070]
00007871bd3e5027  jmp 0x00007871BD3E4F1A
00007871bd3e502c  int3
00007871bd3e502d  nop [rax], eax
00007871bd3e5030  mov rax, [r15+0xF8]
00007871bd3e5037  lea r14, [rax+0x1D0]
00007871bd3e503e  mov r12, [r13+r14*1]
00007871bd3e5043  lea r14, [rax+0x1D8]
00007871bd3e504a  mov r11, [r13+r14*1]
00007871bd3e504f  mov [r15+0xA0], r12
00007871bd3e5056  mov [r15+0x98], r11
00007871bd3e505d  mov r14, [r15+0x40]
00007871bd3e5061  lea r12, [r14+0xCC0]
00007871bd3e5068  movaps xmm1, [r15+0x110]
00007871bd3e5070  movq r14, xmm1
00007871bd3e5075  mov [r13+r12*1], r14
00007871bd3e507a  lea r14, [rax+0x1C0]
00007871bd3e5081  mov r12, [r13+r14*1]
00007871bd3e5086  lea r14, [rax+0x1C8]
00007871bd3e508d  mov r11, [r13+r14*1]
00007871bd3e5092  mov [r15+0xE8], r12
00007871bd3e5099  mov [r15+0xF0], r11
00007871bd3e50a0  lea r14, [rax+0x1B0]
00007871bd3e50a7  mov r12, [r13+r14*1]
00007871bd3e50ac  lea r14, [rax+0x1B8]
00007871bd3e50b3  mov r10, [r13+r14*1]
00007871bd3e50b8  movq xmm1, r12
00007871bd3e50bd  movq xmm15, r10
00007871bd3e50c2  movq xmm1, xmm1
00007871bd3e50c6  movq xmm1, xmm1
00007871bd3e50ca  movaps [r15+0x1A0], xmm1
00007871bd3e50d2  movq xmm15, xmm15
00007871bd3e50d7  movq xmm15, xmm15
00007871bd3e50dc  movaps [r15+0x190], xmm15
00007871bd3e50e4  lea r14, [rax+0x1A0]
00007871bd3e50eb  mov r12, [r13+r14*1]
00007871bd3e50f0  lea r14, [rax+0x1A8]
00007871bd3e50f7  mov r10, [r13+r14*1]
00007871bd3e50fc  movq xmm1, r12
00007871bd3e5101  movq xmm15, r10
00007871bd3e5106  movq xmm1, xmm1
00007871bd3e510a  movq xmm1, xmm1
00007871bd3e510e  movaps [r15+0x1C0], xmm1
00007871bd3e5116  movq xmm15, xmm15
00007871bd3e511b  movq xmm15, xmm15
00007871bd3e5120  movaps [r15+0x1B0], xmm15
00007871bd3e5128  lea r14, [rax+0x190]
00007871bd3e512f  mov r12, [r13+r14*1]
00007871bd3e5134  lea r14, [rax+0x198]
00007871bd3e513b  mov r10, [r13+r14*1]
00007871bd3e5140  movq xmm1, r12
00007871bd3e5145  movq xmm15, r10
00007871bd3e514a  movq xmm1, xmm1
00007871bd3e514e  movq xmm1, xmm1
00007871bd3e5152  movaps [r15+0x1E0], xmm1
00007871bd3e515a  movq xmm15, xmm15
00007871bd3e515f  movq xmm15, xmm15
00007871bd3e5164  movaps [r15+0x1D0], xmm15
00007871bd3e516c  lea r14, [rax+0x180]
00007871bd3e5173  mov r12, [r13+r14*1]
00007871bd3e5178  lea r14, [rax+0x188]
00007871bd3e517f  mov r10, [r13+r14*1]
00007871bd3e5184  movq xmm1, r12
00007871bd3e5189  movq xmm15, r10
00007871bd3e518e  movq xmm1, xmm1
00007871bd3e5192  movq xmm1, xmm1
00007871bd3e5196  movaps [r15+0x200], xmm1
00007871bd3e519e  movq xmm15, xmm15
00007871bd3e51a3  movq xmm15, xmm15
00007871bd3e51a8  movaps [r15+0x1F0], xmm15
00007871bd3e51b0  lea r14, [rax+0x1E0]
00007871bd3e51b7  mov [r15+0xF8], r14
00007871bd3e51be  mov [r15+0x100], r11
00007871bd3e51c5  jmp 0x00007871BD3CE5C0
00007871bd3e51ca  int3
00007871bd3e51cb  call 0x00007871BD2E27E0
00007871bd3e51d0  jmp 0x00007871BD3E5043
00007871bd3e51d5  call 0x00007871BD2E1570
00007871bd3e51da  jmp 0x00007871BD3E504F
00007871bd3e51df  call 0x00007871BD2C3FE0
00007871bd3e51e4  jmp 0x00007871BD3E507A
00007871bd3e51e9  call 0x00007871BD2E27E0
00007871bd3e51ee  jmp 0x00007871BD3E5086
00007871bd3e51f3  call 0x00007871BD2E1570
00007871bd3e51f8  jmp 0x00007871BD3E5092
00007871bd3e51fd  call 0x00007871BD2E27E0
00007871bd3e5202  jmp 0x00007871BD3E50AC
00007871bd3e5207  call 0x00007871BD2E0300
00007871bd3e520c  jmp 0x00007871BD3E50B8
00007871bd3e5211  call 0x00007871BD2E27E0
00007871bd3e5216  jmp 0x00007871BD3E50F0
00007871bd3e521b  call 0x00007871BD2E0300
00007871bd3e5220  jmp 0x00007871BD3E50FC
00007871bd3e5225  call 0x00007871BD2E27E0
00007871bd3e522a  jmp 0x00007871BD3E5134
00007871bd3e522f  call 0x00007871BD2E0300
00007871bd3e5234  jmp 0x00007871BD3E5140
00007871bd3e5239  call 0x00007871BD2E27E0
00007871bd3e523e  jmp 0x00007871BD3E5178
00007871bd3e5243  call 0x00007871BD2E0300
00007871bd3e5248  jmp 0x00007871BD3E5184
00007871bd3e524d  int3
00007871bd3e524e  nop
00007871bd3e5250  mov qword ptr [r15+0x100], 0x04
00007871bd3e525b  mov esi, 0x00
00007871bd3e5260  mov edx, 0x09
00007871bd3e5265  mov rdi, 0x7FFEC252BA90
00007871bd3e526f  mov rax, 0x5BA2FDBBD970
00007871bd3e5279  call rax
00007871bd3e527b  cmp dword ptr [r15+0x318], 0x00
00007871bd3e5283  jnz 0x00007871BD1FE110
00007871bd3e5289  jmp 0x00007871BD1FE0A0
00007871bd3e528e  int3
00007871bd3e528f  int3
