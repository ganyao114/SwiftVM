000078af20bce69b  nop [rax+rax*1], eax
000078af20bce6a0  mov rax, [r15+0xF8]
000078af20bce6a7  lea r14, [rax-0x1E0]
000078af20bce6ae  mov [r15+0xF8], r14
000078af20bce6b5  lea rax, [r14+0x1D0]
000078af20bce6bc  mov r12, [r15+0xA0]
000078af20bce6c3  mov r11, [r15+0x98]
000078af20bce6ca  mov [r13+rax*1], r12
000078af20bce6cf  lea rax, [r14+0x1D8]
000078af20bce6d6  mov [r13+rax*1], r11
000078af20bce6db  mov eax, 0x420AA0
000078af20bce6e0  movups xmm1, [r13+rax*1]
000078af20bce6e6  mov eax, 0x420A30
000078af20bce6eb  movups xmm15, [r13+rax*1]
000078af20bce6f1  mov eax, 0x420AC0
000078af20bce6f6  movups xmm14, [r13+rax*1]
000078af20bce6fc  mov eax, 0x420A60
000078af20bce701  movups xmm13, [r13+rax*1]
000078af20bce707  mov qword ptr [r15+0x98], 0x430CD0
000078af20bce712  mov eax, 0x420AD0
000078af20bce717  movups xmm12, [r13+rax*1]
000078af20bce71d  mov eax, 0x430CD0
000078af20bce722  movups [r13+rax*1], xmm1
000078af20bce728  mov eax, 0x430CE0
000078af20bce72d  movups [r13+rax*1], xmm15
000078af20bce733  mov eax, 0x430CF0
000078af20bce738  movups [r13+rax*1], xmm14
000078af20bce73e  mov eax, 0x430D00
000078af20bce743  movups [r13+rax*1], xmm13
000078af20bce749  mov eax, 0x420A20
000078af20bce74e  movups xmm14, [r13+rax*1]
000078af20bce754  mov eax, 0x420A10
000078af20bce759  movups xmm13, [r13+rax*1]
000078af20bce75f  mov eax, 0x430DD0
000078af20bce764  movups [r13+rax*1], xmm1
000078af20bce76a  mov eax, 0x430DE0
000078af20bce76f  movups [r13+rax*1], xmm15
000078af20bce775  mov eax, 0x430D10
000078af20bce77a  movups [r13+rax*1], xmm12
000078af20bce780  mov eax, 0x430D20
000078af20bce785  movups [r13+rax*1], xmm14
000078af20bce78b  mov eax, 0x420A00
000078af20bce790  movups xmm1, [r13+rax*1]
000078af20bce796  mov eax, 0x420A70
000078af20bce79b  movups xmm15, [r13+rax*1]
000078af20bce7a1  mov eax, 0x430D30
000078af20bce7a6  movups [r13+rax*1], xmm13
000078af20bce7ac  mov eax, 0x430D40
000078af20bce7b1  movups [r13+rax*1], xmm1
000078af20bce7b7  mov eax, 0x420A80
000078af20bce7bc  movups xmm1, [r13+rax*1]
000078af20bce7c2  mov eax, 0x420A50
000078af20bce7c7  movups xmm14, [r13+rax*1]
000078af20bce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
000078af20bce7d5  mov eax, 0x430D50
000078af20bce7da  movups [r13+rax*1], xmm15
000078af20bce7e0  mov eax, 0x430D60
000078af20bce7e5  movups [r13+rax*1], xmm1
000078af20bce7eb  mov eax, 0x420AF0
000078af20bce7f0  movups xmm1, [r13+rax*1]
000078af20bce7f6  mov eax, 0x420B00
000078af20bce7fb  movups xmm15, [r13+rax*1]
000078af20bce801  movaps [r15+0x150], xmm15
000078af20bce809  mov qword ptr [r15+0xA0], 0x3E8
000078af20bce814  mov eax, 0x430D70
000078af20bce819  movups [r13+rax*1], xmm14
000078af20bce81f  mov eax, 0x430D80
000078af20bce824  movups [r13+rax*1], xmm1
000078af20bce82a  mov eax, 0x420AE0
000078af20bce82f  movups xmm1, [r13+rax*1]
000078af20bce835  mov eax, 0x420A90
000078af20bce83a  movups xmm14, [r13+rax*1]
000078af20bce840  movaps [r15+0x140], xmm14
000078af20bce848  lea rax, [r14+0x180]
000078af20bce84f  movq xmm13, qword ptr [r15+0x200]
000078af20bce858  movq xmm12, qword ptr [r15+0x1F0]
000078af20bce861  movq r12, xmm13
000078af20bce866  movq r11, xmm12
000078af20bce86b  mov [r13+rax*1], r12
000078af20bce870  lea rax, [r14+0x188]
000078af20bce877  mov [r13+rax*1], r11
000078af20bce87c  mov eax, 0x430D90
000078af20bce881  movups [r13+rax*1], xmm15
000078af20bce887  mov eax, 0x430DA0
000078af20bce88c  movups [r13+rax*1], xmm1
000078af20bce892  mov eax, 0x420AB0
000078af20bce897  movups xmm1, [r13+rax*1]
000078af20bce89d  mov eax, 0x420B18
000078af20bce8a2  mov r12, [r13+rax*1]
000078af20bce8a7  movq xmm15, r12
000078af20bce8ac  mov qword ptr [r15+0x40], 0x420B20
000078af20bce8b4  mov eax, 0x430DB0
000078af20bce8b9  movups [r13+rax*1], xmm14
000078af20bce8bf  mov eax, 0x430DC0
000078af20bce8c4  movups [r13+rax*1], xmm1
000078af20bce8ca  mov eax, 0x420B80
000078af20bce8cf  movups xmm1, [r13+rax*1]
000078af20bce8d5  movq rax, xmm15
000078af20bce8da  mov r12d, 0x430DF0
000078af20bce8e0  mov [r13+r12*1], rax
000078af20bce8e5  mov eax, 0x420B60
000078af20bce8ea  movups xmm15, [r13+rax*1]
000078af20bce8f0  mov eax, 0x420B70
000078af20bce8f5  movups xmm14, [r13+rax*1]
000078af20bce8fb  lea rax, [r14+0x160]
000078af20bce902  movups [r13+rax*1], xmm1
000078af20bce908  lea rax, [r14+0x190]
000078af20bce90f  movq xmm1, qword ptr [r15+0x1E0]
000078af20bce918  movq xmm13, qword ptr [r15+0x1D0]
000078af20bce921  movq r12, xmm1
000078af20bce926  movq r11, xmm13
000078af20bce92b  mov [r13+rax*1], r12
000078af20bce930  lea rax, [r14+0x198]
000078af20bce937  mov [r13+rax*1], r11
000078af20bce93c  lea rax, [r14+0x140]
000078af20bce943  movups [r13+rax*1], xmm15
000078af20bce949  lea rax, [r14+0x150]
000078af20bce950  movups [r13+rax*1], xmm14
000078af20bce956  mov eax, 0x420B20
000078af20bce95b  movups xmm1, [r13+rax*1]
000078af20bce961  mov eax, 0x420B30
000078af20bce966  movups xmm15, [r13+rax*1]
000078af20bce96c  movaps [r15+0x120], xmm15
000078af20bce974  lea rax, [r14+0x1A0]
000078af20bce97b  movq xmm14, qword ptr [r15+0x1C0]
000078af20bce984  movq xmm13, qword ptr [r15+0x1B0]
000078af20bce98d  movq r12, xmm14
000078af20bce992  movq r11, xmm13
000078af20bce997  mov [r13+rax*1], r12
000078af20bce99c  lea rax, [r14+0x1A8]
000078af20bce9a3  mov [r13+rax*1], r11
000078af20bce9a8  lea rax, [r14+0x1B0]
000078af20bce9af  movq xmm14, qword ptr [r15+0x1A0]
000078af20bce9b8  movq xmm13, qword ptr [r15+0x190]
000078af20bce9c1  movq r12, xmm14
000078af20bce9c6  movq r11, xmm13
000078af20bce9cb  mov [r13+rax*1], r12
000078af20bce9d0  lea rax, [r14+0x1B8]
000078af20bce9d7  mov [r13+rax*1], r11
000078af20bce9dc  lea rax, [r14+0x100]
000078af20bce9e3  movups [r13+rax*1], xmm1
000078af20bce9e9  lea rax, [r14+0x110]
000078af20bce9f0  movups [r13+rax*1], xmm15
000078af20bce9f6  mov eax, 0x420B40
000078af20bce9fb  movups xmm1, [r13+rax*1]
000078af20bcea01  mov eax, 0x420B50
000078af20bcea06  movups xmm15, [r13+rax*1]
000078af20bcea0c  movaps [r15+0x110], xmm1
000078af20bcea14  movaps [r15+0x130], xmm15
000078af20bcea1c  lea rax, [r14+0x1C0]
000078af20bcea23  mov r12, [r15+0xE8]
000078af20bcea2a  mov r11, [r15+0xF0]
000078af20bcea31  mov [r13+rax*1], r12
000078af20bcea36  lea rax, [r14+0x1C8]
000078af20bcea3d  mov [r13+rax*1], r11
000078af20bcea42  mov eax, 0x430DF8
000078af20bcea47  mov r12d, 0x421DF8D3
000078af20bcea4d  mov [r13+rax*1], r12d
000078af20bcea52  lea rax, [r14+0x120]
000078af20bcea59  movups [r13+rax*1], xmm1
000078af20bcea5f  lea rax, [r14+0x130]
000078af20bcea66  movups [r13+rax*1], xmm15
000078af20bcea6c  lea rax, [r14+0x100]
000078af20bcea73  mov [r15], rax
000078af20bcea76  mov qword ptr [r15+0x08], 0x430CD0
000078af20bcea7e  mov qword ptr [r15+0x10], 0x12C
000078af20bcea86  mov qword ptr [r15+0xF0], 0x410284
000078af20bcea91  mov r14d, [r15+0x320]
000078af20bcea98  mov eax, 0x410284
000078af20bcea9d  mov rcx, 0x78AF20BD07C0
000078af20bceaa7  mov [r15+r14*8+0x328], rax
000078af20bceaaf  mov [r15+r14*8+0x368], rcx
000078af20bceab7  add r14d, 0x01
000078af20bceabb  and r14d, 0x07
000078af20bceabf  mov [r15+0x320], r14d
000078af20bceac6  cmp dword ptr [r15+0x318], 0x00
000078af20bceace  jz 0x000078AF20BCED70
000078af20bcead4  nop [rax+rax*1], ax
000078af20bceadd  nop [rax+rax*1], eax
000078af20bceae5  mov eax, 0x410728
000078af20bceaea  mov [r15+0x100], rax
000078af20bceaf1  jmp 0x000078AF209FE110
000078af20bceaf6  int3
000078af20bceaf7  call 0x000078AF20A0BC20
000078af20bceafc  jmp 0x000078AF20BCE6CF
000078af20bceb01  call 0x000078AF20A0A9A0
000078af20bceb06  jmp 0x000078AF20BCE6DB
000078af20bceb0b  call 0x000078AF209FF430
000078af20bceb10  jmp 0x000078AF20BCE6E6
000078af20bceb15  call 0x000078AF20A0E760
000078af20bceb1a  jmp 0x000078AF20BCE6F1
000078af20bceb1f  call 0x000078AF20A0D4E0
000078af20bceb24  jmp 0x000078AF20BCE6FC
000078af20bceb29  call 0x000078AF20A0C260
000078af20bceb2e  jmp 0x000078AF20BCE707
000078af20bceb33  call 0x000078AF20A0AFE0
000078af20bceb38  jmp 0x000078AF20BCE71D
000078af20bceb3d  call 0x000078AF209FF540
000078af20bceb42  jmp 0x000078AF20BCE728
000078af20bceb47  call 0x000078AF20A0E880
000078af20bceb4c  jmp 0x000078AF20BCE733
000078af20bceb51  call 0x000078AF20A0D600
000078af20bceb56  jmp 0x000078AF20BCE73E
000078af20bceb5b  call 0x000078AF20A0C380
000078af20bceb60  jmp 0x000078AF20BCE749
000078af20bceb65  call 0x000078AF20A0D4E0
000078af20bceb6a  jmp 0x000078AF20BCE754
000078af20bceb6f  call 0x000078AF20A0C260
000078af20bceb74  jmp 0x000078AF20BCE75F
000078af20bceb79  call 0x000078AF209FF540
000078af20bceb7e  jmp 0x000078AF20BCE76A
000078af20bceb83  call 0x000078AF20A0E880
000078af20bceb88  jmp 0x000078AF20BCE775
000078af20bceb8d  call 0x000078AF20A0B100
000078af20bceb92  jmp 0x000078AF20BCE780
000078af20bceb97  call 0x000078AF20A0D600
000078af20bceb9c  jmp 0x000078AF20BCE78B
000078af20bceba1  call 0x000078AF209FF430
000078af20bceba6  jmp 0x000078AF20BCE796
000078af20bcebab  call 0x000078AF20A0E760
000078af20bcebb0  jmp 0x000078AF20BCE7A1
000078af20bcebb5  call 0x000078AF20A0C380
000078af20bcebba  jmp 0x000078AF20BCE7AC
000078af20bcebbf  call 0x000078AF209FF540
000078af20bcebc4  jmp 0x000078AF20BCE7B7
000078af20bcebc9  call 0x000078AF209FF430
000078af20bcebce  jmp 0x000078AF20BCE7C2
000078af20bcebd3  call 0x000078AF20A0D4E0
000078af20bcebd8  jmp 0x000078AF20BCE7CD
000078af20bcebdd  call 0x000078AF20A0E880
000078af20bcebe2  jmp 0x000078AF20BCE7E0
000078af20bcebe7  call 0x000078AF209FF540
000078af20bcebec  jmp 0x000078AF20BCE7EB
000078af20bcebf1  call 0x000078AF209FF430
000078af20bcebf6  jmp 0x000078AF20BCE7F6
000078af20bcebfb  call 0x000078AF20A0E760
000078af20bcec00  jmp 0x000078AF20BCE801
000078af20bcec05  call 0x000078AF20A0D600
000078af20bcec0a  jmp 0x000078AF20BCE81F
000078af20bcec0f  call 0x000078AF209FF540
000078af20bcec14  jmp 0x000078AF20BCE82A
000078af20bcec19  call 0x000078AF209FF430
000078af20bcec1e  jmp 0x000078AF20BCE835
000078af20bcec23  call 0x000078AF20A0D4E0
000078af20bcec28  jmp 0x000078AF20BCE840
000078af20bcec2d  call 0x000078AF20A0BC20
000078af20bcec32  jmp 0x000078AF20BCE870
000078af20bcec37  call 0x000078AF20A0A9A0
000078af20bcec3c  jmp 0x000078AF20BCE87C
000078af20bcec41  call 0x000078AF20A0E880
000078af20bcec46  jmp 0x000078AF20BCE887
000078af20bcec4b  call 0x000078AF209FF540
000078af20bcec50  jmp 0x000078AF20BCE892
000078af20bcec55  call 0x000078AF209FF430
000078af20bcec5a  jmp 0x000078AF20BCE89D
000078af20bcec5f  call 0x000078AF20A0B720
000078af20bcec64  jmp 0x000078AF20BCE8A7
000078af20bcec69  call 0x000078AF20A0D600
000078af20bcec6e  jmp 0x000078AF20BCE8BF
000078af20bcec73  call 0x000078AF209FF540
000078af20bcec78  jmp 0x000078AF20BCE8CA
000078af20bcec7d  call 0x000078AF209FF430
000078af20bcec82  jmp 0x000078AF20BCE8D5
000078af20bcec87  call 0x000078AF20AB4CB0
000078af20bcec8c  jmp 0x000078AF20BCE8E5
000078af20bcec91  call 0x000078AF20A0E760
000078af20bcec96  jmp 0x000078AF20BCE8F0
000078af20bcec9b  call 0x000078AF20A0D4E0
000078af20bceca0  jmp 0x000078AF20BCE8FB
000078af20bceca5  call 0x000078AF209FF540
000078af20bcecaa  jmp 0x000078AF20BCE908
000078af20bcecaf  call 0x000078AF20A0BC20
000078af20bcecb4  jmp 0x000078AF20BCE930
000078af20bcecb9  call 0x000078AF20A0A9A0
000078af20bcecbe  jmp 0x000078AF20BCE93C
000078af20bcecc3  call 0x000078AF20A0E880
000078af20bcecc8  jmp 0x000078AF20BCE949
000078af20bceccd  call 0x000078AF20A0D600
000078af20bcecd2  jmp 0x000078AF20BCE956
000078af20bcecd7  call 0x000078AF209FF430
000078af20bcecdc  jmp 0x000078AF20BCE961
000078af20bcece1  call 0x000078AF20A0E760
000078af20bcece6  jmp 0x000078AF20BCE96C
000078af20bceceb  call 0x000078AF20A0BC20
000078af20bcecf0  jmp 0x000078AF20BCE99C
000078af20bcecf5  call 0x000078AF20A0A9A0
000078af20bcecfa  jmp 0x000078AF20BCE9A8
000078af20bcecff  call 0x000078AF20A0BC20
000078af20bced04  jmp 0x000078AF20BCE9D0
000078af20bced09  call 0x000078AF20A0A9A0
000078af20bced0e  jmp 0x000078AF20BCE9DC
000078af20bced13  call 0x000078AF209FF540
000078af20bced18  jmp 0x000078AF20BCE9E9
000078af20bced1d  call 0x000078AF20A0E880
000078af20bced22  jmp 0x000078AF20BCE9F6
000078af20bced27  call 0x000078AF209FF430
000078af20bced2c  jmp 0x000078AF20BCEA01
000078af20bced31  call 0x000078AF20A0E760
000078af20bced36  jmp 0x000078AF20BCEA0C
000078af20bced3b  call 0x000078AF20A0BC20
000078af20bced40  jmp 0x000078AF20BCEA36
000078af20bced45  call 0x000078AF20A0A9A0
000078af20bced4a  jmp 0x000078AF20BCEA42
000078af20bced4f  call 0x000078AF20A0BAE0
000078af20bced54  jmp 0x000078AF20BCEA52
000078af20bced59  call 0x000078AF209FF540
000078af20bced5e  jmp 0x000078AF20BCEA5F
000078af20bced63  call 0x000078AF20A0E880
000078af20bced68  jmp 0x000078AF20BCEA6C
000078af20bced6d  int3
000078af20bced6e  nop
000078af20bced70  mov rax, [r15]
000078af20bced73  lea r14, [rax+0x20]
000078af20bced77  mov r12, [r13+r14*1]
000078af20bced7c  mov r14, [r15+0x10]
000078af20bced80  lea r11, [r12+r14*1]
000078af20bced84  mov [r15+0x40], r11
000078af20bced88  lea r12, [rax+0x20]
000078af20bced8c  mov [r13+r12*1], r11
000078af20bced91  test r14, r14
000078af20bced94  setz r14b
000078af20bced98  movzx r14, r14b
000078af20bced9c  mov [rsp+0x414], r14b
000078af20bceda4  cmp byte ptr [rsp+0x414], 0x00
000078af20bcedac  jz 0x000078AF20BCEDDE
000078af20bcedae  cmp dword ptr [r15+0x318], 0x00
000078af20bcedb6  mov eax, 0x4109A0
000078af20bcedbb  mov [r15+0x100], rax
000078af20bcedc2  jz 0x000078AF209FE0A0
000078af20bcedc8  nop [rax+rax*1], eax
000078af20bcedcd  mov eax, 0x4109A0
000078af20bcedd2  mov [r15+0x100], rax
000078af20bcedd9  jmp 0x000078AF209FE110
000078af20bcedde  cmp dword ptr [r15+0x318], 0x00
000078af20bcede6  jz 0x000078AF20BCEE30
000078af20bcedec  nop [rax+rax*1], ax
000078af20bcedf5  nop [rax+rax*1], eax
000078af20bcedfd  mov eax, 0x410738
000078af20bcee02  mov [r15+0x100], rax
000078af20bcee09  jmp 0x000078AF209FE110
000078af20bcee0e  int3
000078af20bcee0f  call 0x000078AF20AE27E0
000078af20bcee14  jmp 0x000078AF20BCED7C
000078af20bcee19  call 0x000078AF20AC0860
000078af20bcee1e  jmp 0x000078AF20BCED91
000078af20bcee23  int3
000078af20bcee24  nop [rax+rax*1], ax
000078af20bcee2d  nop [rax], eax
000078af20bcee30  mov rax, [r15+0xF8]
000078af20bcee37  lea r14, [rax-0x150]
000078af20bcee3e  mov [r15+0xF8], r14
000078af20bcee45  mov rax, [r15]
000078af20bcee48  lea r12, [rax+0x68]
000078af20bcee4c  mov r11, [r13+r12*1]
000078af20bcee51  mov [r15+0x88], r11
000078af20bcee58  lea r12, [rax+0x28]
000078af20bcee5c  mov [r15+0x40], r12
000078af20bcee60  mov [r15+0x48], r14
000078af20bcee64  mov qword ptr [r15+0x50], 0x420B90
000078af20bcee6c  lea rax, [r14+0x100]
000078af20bcee73  mov r12, [r15+0xE8]
000078af20bcee7a  mov r11, [r15+0xD8]
000078af20bcee81  mov [r13+rax*1], r12
000078af20bcee86  lea rax, [r14+0x108]
000078af20bcee8d  mov [r13+rax*1], r11
000078af20bcee92  lea rax, [r14+0x110]
000078af20bcee99  mov r12, [r15+0xD0]
000078af20bceea0  mov r11, [r15+0xC8]
000078af20bceea7  mov [r13+rax*1], r12
000078af20bceeac  lea rax, [r14+0x118]
000078af20bceeb3  mov [r13+rax*1], r11
000078af20bceeb8  lea rax, [r14+0x120]
000078af20bceebf  mov r12, [r15+0xC0]
000078af20bceec6  mov r11, [r15+0xB8]
000078af20bceecd  mov [r13+rax*1], r12
000078af20bceed2  lea rax, [r14+0x128]
000078af20bceed9  mov [r13+rax*1], r11
000078af20bceede  lea rax, [r14+0x130]
000078af20bceee5  mov r12, [r15+0xB0]
000078af20bceeec  mov r11, [r15+0xA8]
000078af20bceef3  mov [r13+rax*1], r12
000078af20bceef8  lea rax, [r14+0x138]
000078af20bceeff  mov [r13+rax*1], r11
000078af20bcef04  lea rax, [r14+0x140]
000078af20bcef0b  mov r12, [r15+0xA0]
000078af20bcef12  mov r11, [r15+0x98]
000078af20bcef19  mov [r13+rax*1], r12
000078af20bcef1e  lea rax, [r14+0x148]
000078af20bcef25  mov [r13+rax*1], r11
000078af20bcef2a  cmp dword ptr [r15+0x318], 0x00
000078af20bcef32  jz 0x000078AF20BCEFD0
000078af20bcef38  nop [rax+rax*1], ax
000078af20bcef41  nop [rax+rax*1], eax
000078af20bcef49  mov eax, 0x410770
000078af20bcef4e  mov [r15+0x100], rax
000078af20bcef55  jmp 0x000078AF209FE110
000078af20bcef5a  int3
000078af20bcef5b  call 0x000078AF20AC0370
000078af20bcef60  jmp 0x000078AF20BCEE51
000078af20bcef65  call 0x000078AF20A0BC20
000078af20bcef6a  jmp 0x000078AF20BCEE86
000078af20bcef6f  call 0x000078AF20A0A9A0
000078af20bcef74  jmp 0x000078AF20BCEE92
000078af20bcef79  call 0x000078AF20A0BC20
000078af20bcef7e  jmp 0x000078AF20BCEEAC
000078af20bcef83  call 0x000078AF20A0A9A0
000078af20bcef88  jmp 0x000078AF20BCEEB8
000078af20bcef8d  call 0x000078AF20A0BC20
000078af20bcef92  jmp 0x000078AF20BCEED2
000078af20bcef97  call 0x000078AF20A0A9A0
000078af20bcef9c  jmp 0x000078AF20BCEEDE
000078af20bcefa1  call 0x000078AF20A0BC20
000078af20bcefa6  jmp 0x000078AF20BCEEF8
000078af20bcefab  call 0x000078AF20A0A9A0
000078af20bcefb0  jmp 0x000078AF20BCEF04
000078af20bcefb5  call 0x000078AF20A0BC20
000078af20bcefba  jmp 0x000078AF20BCEF1E
000078af20bcefbf  call 0x000078AF20A0A9A0
000078af20bcefc4  jmp 0x000078AF20BCEF2A
000078af20bcefc9  int3
000078af20bcefca  nop [rax+rax*1], ax
000078af20bcefd0  mov rax, [r15+0x08]
000078af20bcefd4  movzx r14d, byte ptr [r13+rax*1]
000078af20bcefda  movzx r14d, r14b
000078af20bcefde  mov [rsp+0x10], r14d
000078af20bcefe3  mov r14d, r14d
000078af20bcefe6  mov [r15+0x58], r14
000078af20bcefea  lea r14, [rax+0x01]
000078af20bcefee  mov [r15+0x08], r14
000078af20bceff2  mov rax, [r15+0x88]
000078af20bceff9  lea r14, [rax+0x01]
000078af20bceffd  mov r12, [r15]
000078af20bcf000  lea r11, [r12+0x68]
000078af20bcf005  mov [r13+r11*1], r14
000078af20bcf00a  lea r14, [r12+rax*1]
000078af20bcf00e  mov [r15+0x60], r14
000078af20bcf012  lea rax, [r14+0x28]
000078af20bcf016  mov r11d, [rsp+0x10]
000078af20bcf01b  movzx r14d, r11b
000078af20bcf01f  mov [r13+rax*1], r14b
000078af20bcf024  lea rax, [r12+0x68]
000078af20bcf029  mov r14, [r13+rax*1]
000078af20bcf02e  mov [r15+0x88], r14
000078af20bcf035  xor eax, eax
000078af20bcf037  mov r12d, 0x40
000078af20bcf03d  cmp r14, r12
000078af20bcf040  cmc
000078af20bcf041  lahf
000078af20bcf042  seto al
000078af20bcf045  mov [r15+0x108], eax
000078af20bcf04c  mov eax, [r15+0x108]
000078af20bcf053  sahf
000078af20bcf054  jnz 0x000078AF20BCF086
000078af20bcf056  cmp dword ptr [r15+0x318], 0x00
000078af20bcf05e  jz 0x000078AF20BCF170
000078af20bcf064  nop [rax+rax*1], ax
000078af20bcf06d  nop [rax+rax*1], eax
000078af20bcf075  mov eax, 0x410790
000078af20bcf07a  mov [r15+0x100], rax
000078af20bcf081  jmp 0x000078AF209FE110
000078af20bcf086  cmp dword ptr [r15+0x318], 0x00
000078af20bcf08e  jz 0x000078AF20BCF0E0
000078af20bcf094  nop [rax+rax*1], ax
000078af20bcf09d  nop [rax+rax*1], eax
000078af20bcf0a5  mov eax, 0x410768
000078af20bcf0aa  mov [r15+0x100], rax
000078af20bcf0b1  jmp 0x000078AF209FE110
000078af20bcf0b6  int3
000078af20bcf0b7  call 0x000078AF20A0D860
000078af20bcf0bc  jmp 0x000078AF20BCEFDA
000078af20bcf0c1  call 0x000078AF20AB36E0
000078af20bcf0c6  jmp 0x000078AF20BCF00A
000078af20bcf0cb  call 0x000078AF20A0DD60
000078af20bcf0d0  jmp 0x000078AF20BCF024
000078af20bcf0d5  call 0x000078AF20A0DC20
000078af20bcf0da  jmp 0x000078AF20BCF02E
000078af20bcf0df  int3
000078af20bcf0e0  mov rax, [r15+0x10]
000078af20bcf0e4  lea r14, [rax-0x01]
000078af20bcf0e8  mov [r15+0x10], r14
000078af20bcf0ec  test r14, r14
000078af20bcf0ef  setz r14b
000078af20bcf0f3  movzx r14, r14b
000078af20bcf0f7  mov [rsp+0x414], r14b
000078af20bcf0ff  cmp byte ptr [rsp+0x414], 0x00
000078af20bcf107  jz 0x000078AF20BCF139
000078af20bcf109  cmp dword ptr [r15+0x318], 0x00
000078af20bcf111  jz 0x000078AF20BD0670
000078af20bcf117  nop [rax+rax*1], ax
000078af20bcf120  nop [rax+rax*1], eax
000078af20bcf128  mov eax, 0x410988
000078af20bcf12d  mov [r15+0x100], rax
000078af20bcf134  jmp 0x000078AF209FE110
000078af20bcf139  cmp dword ptr [r15+0x318], 0x00
000078af20bcf141  jz 0x000078AF20BCEFD0
000078af20bcf147  nop [rax+rax*1], ax
000078af20bcf150  nop [rax+rax*1], eax
000078af20bcf158  mov eax, 0x410770
000078af20bcf15d  mov [r15+0x100], rax
000078af20bcf164  jmp 0x000078AF209FE110
000078af20bcf169  int3
000078af20bcf16a  int3
000078af20bcf16b  nop [rax+rax*1], eax
000078af20bcf170  mov rax, [r15+0x40]
000078af20bcf174  movzx r14d, byte ptr [r13+rax*1]
000078af20bcf17a  movaps xmm1, [r15+0x110]
000078af20bcf182  pinsrb xmm1, r14d, 0x00
000078af20bcf189  lea r14, [rax+0x01]
000078af20bcf18d  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf193  movaps xmm15, [r15+0x120]
000078af20bcf19b  pinsrb xmm15, r12d, 0x00
000078af20bcf1a2  lea r14, [rax+0x02]
000078af20bcf1a6  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf1ac  movaps xmm14, [r15+0x130]
000078af20bcf1b4  pinsrb xmm14, r12d, 0x00
000078af20bcf1bb  lea r14, [rax+0x03]
000078af20bcf1bf  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf1c5  movaps xmm13, [r15+0x140]
000078af20bcf1cd  pinsrb xmm13, r12d, 0x00
000078af20bcf1d4  lea r14, [rax+0x04]
000078af20bcf1d8  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf1de  pinsrb xmm1, r12d, 0x01
000078af20bcf1e5  lea r14, [rax+0x05]
000078af20bcf1e9  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf1ef  pinsrb xmm15, r12d, 0x01
000078af20bcf1f6  lea r14, [rax+0x06]
000078af20bcf1fa  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf200  pinsrb xmm14, r12d, 0x01
000078af20bcf207  lea r14, [rax+0x07]
000078af20bcf20b  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf211  pinsrb xmm13, r12d, 0x01
000078af20bcf218  lea r14, [rax+0x08]
000078af20bcf21c  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf222  pinsrb xmm1, r12d, 0x02
000078af20bcf229  lea r14, [rax+0x09]
000078af20bcf22d  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf233  pinsrb xmm15, r12d, 0x02
000078af20bcf23a  lea r14, [rax+0x0A]
000078af20bcf23e  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf244  pinsrb xmm14, r12d, 0x02
000078af20bcf24b  lea r14, [rax+0x0B]
000078af20bcf24f  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf255  pinsrb xmm13, r12d, 0x02
000078af20bcf25c  lea r14, [rax+0x0C]
000078af20bcf260  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf266  pinsrb xmm1, r12d, 0x03
000078af20bcf26d  lea r14, [rax+0x0D]
000078af20bcf271  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf277  pinsrb xmm15, r12d, 0x03
000078af20bcf27e  lea r14, [rax+0x0E]
000078af20bcf282  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf288  pinsrb xmm14, r12d, 0x03
000078af20bcf28f  lea r14, [rax+0x0F]
000078af20bcf293  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf299  pinsrb xmm13, r12d, 0x03
000078af20bcf2a0  lea r14, [rax+0x10]
000078af20bcf2a4  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf2aa  pinsrb xmm1, r12d, 0x04
000078af20bcf2b1  lea r14, [rax+0x11]
000078af20bcf2b5  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf2bb  pinsrb xmm15, r12d, 0x04
000078af20bcf2c2  lea r14, [rax+0x12]
000078af20bcf2c6  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf2cc  pinsrb xmm14, r12d, 0x04
000078af20bcf2d3  lea r14, [rax+0x13]
000078af20bcf2d7  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf2dd  pinsrb xmm13, r12d, 0x04
000078af20bcf2e4  lea r14, [rax+0x14]
000078af20bcf2e8  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf2ee  pinsrb xmm1, r12d, 0x05
000078af20bcf2f5  lea r14, [rax+0x15]
000078af20bcf2f9  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf2ff  pinsrb xmm15, r12d, 0x05
000078af20bcf306  lea r14, [rax+0x16]
000078af20bcf30a  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf310  pinsrb xmm14, r12d, 0x05
000078af20bcf317  lea r14, [rax+0x17]
000078af20bcf31b  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf321  pinsrb xmm13, r12d, 0x05
000078af20bcf328  lea r14, [rax+0x18]
000078af20bcf32c  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf332  pinsrb xmm1, r12d, 0x06
000078af20bcf339  lea r14, [rax+0x19]
000078af20bcf33d  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf343  pinsrb xmm15, r12d, 0x06
000078af20bcf34a  lea r14, [rax+0x1A]
000078af20bcf34e  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf354  pinsrb xmm14, r12d, 0x06
000078af20bcf35b  lea r14, [rax+0x1B]
000078af20bcf35f  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf365  pinsrb xmm13, r12d, 0x06
000078af20bcf36c  lea r14, [rax+0x1C]
000078af20bcf370  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf376  pinsrb xmm1, r12d, 0x07
000078af20bcf37d  lea r14, [rax+0x1D]
000078af20bcf381  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf387  pinsrb xmm15, r12d, 0x07
000078af20bcf38e  lea r14, [rax+0x1E]
000078af20bcf392  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf398  pinsrb xmm14, r12d, 0x07
000078af20bcf39f  lea r14, [rax+0x1F]
000078af20bcf3a3  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf3a9  pinsrb xmm13, r12d, 0x07
000078af20bcf3b0  lea r14, [rax+0x20]
000078af20bcf3b4  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf3ba  pinsrb xmm1, r12d, 0x08
000078af20bcf3c1  lea r14, [rax+0x21]
000078af20bcf3c5  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf3cb  pinsrb xmm15, r12d, 0x08
000078af20bcf3d2  lea r14, [rax+0x22]
000078af20bcf3d6  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf3dc  pinsrb xmm14, r12d, 0x08
000078af20bcf3e3  lea r14, [rax+0x23]
000078af20bcf3e7  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf3ed  pinsrb xmm13, r12d, 0x08
000078af20bcf3f4  lea r14, [rax+0x24]
000078af20bcf3f8  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf3fe  pinsrb xmm1, r12d, 0x09
000078af20bcf405  lea r14, [rax+0x25]
000078af20bcf409  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf40f  pinsrb xmm15, r12d, 0x09
000078af20bcf416  lea r14, [rax+0x26]
000078af20bcf41a  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf420  pinsrb xmm14, r12d, 0x09
000078af20bcf427  lea r14, [rax+0x27]
000078af20bcf42b  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf431  pinsrb xmm13, r12d, 0x09
000078af20bcf438  lea r14, [rax+0x28]
000078af20bcf43c  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf442  pinsrb xmm1, r12d, 0x0A
000078af20bcf449  lea r14, [rax+0x29]
000078af20bcf44d  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf453  pinsrb xmm15, r12d, 0x0A
000078af20bcf45a  lea r14, [rax+0x2A]
000078af20bcf45e  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf464  pinsrb xmm14, r12d, 0x0A
000078af20bcf46b  lea r14, [rax+0x2B]
000078af20bcf46f  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf475  pinsrb xmm13, r12d, 0x0A
000078af20bcf47c  lea r14, [rax+0x2C]
000078af20bcf480  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf486  pinsrb xmm1, r12d, 0x0B
000078af20bcf48d  lea r14, [rax+0x2D]
000078af20bcf491  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf497  pinsrb xmm15, r12d, 0x0B
000078af20bcf49e  lea r14, [rax+0x2E]
000078af20bcf4a2  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf4a8  pinsrb xmm14, r12d, 0x0B
000078af20bcf4af  lea r14, [rax+0x2F]
000078af20bcf4b3  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf4b9  pinsrb xmm13, r12d, 0x0B
000078af20bcf4c0  lea r14, [rax+0x30]
000078af20bcf4c4  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf4ca  pinsrb xmm1, r12d, 0x0C
000078af20bcf4d1  lea r14, [rax+0x31]
000078af20bcf4d5  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf4db  pinsrb xmm15, r12d, 0x0C
000078af20bcf4e2  lea r14, [rax+0x32]
000078af20bcf4e6  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf4ec  pinsrb xmm14, r12d, 0x0C
000078af20bcf4f3  lea r14, [rax+0x33]
000078af20bcf4f7  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf4fd  pinsrb xmm13, r12d, 0x0C
000078af20bcf504  lea r14, [rax+0x34]
000078af20bcf508  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf50e  pinsrb xmm1, r12d, 0x0D
000078af20bcf515  lea r14, [rax+0x35]
000078af20bcf519  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf51f  pinsrb xmm15, r12d, 0x0D
000078af20bcf526  lea r14, [rax+0x36]
000078af20bcf52a  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf530  pinsrb xmm14, r12d, 0x0D
000078af20bcf537  lea r14, [rax+0x37]
000078af20bcf53b  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf541  pinsrb xmm13, r12d, 0x0D
000078af20bcf548  lea r14, [rax+0x38]
000078af20bcf54c  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf552  pinsrb xmm1, r12d, 0x0E
000078af20bcf559  lea r14, [rax+0x39]
000078af20bcf55d  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf563  pinsrb xmm15, r12d, 0x0E
000078af20bcf56a  lea r14, [rax+0x3A]
000078af20bcf56e  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf574  pinsrb xmm14, r12d, 0x0E
000078af20bcf57b  lea r14, [rax+0x3B]
000078af20bcf57f  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf585  pinsrb xmm13, r12d, 0x0E
000078af20bcf58c  lea r14, [rax+0x3C]
000078af20bcf590  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf596  pinsrb xmm1, r12d, 0x0F
000078af20bcf59d  movaps [r15+0x110], xmm1
000078af20bcf5a5  lea r14, [rax+0x3D]
000078af20bcf5a9  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf5af  pinsrb xmm15, r12d, 0x0F
000078af20bcf5b6  movaps [r15+0x120], xmm15
000078af20bcf5be  lea r14, [rax+0x3E]
000078af20bcf5c2  movzx r12d, byte ptr [r13+r14*1]
000078af20bcf5c8  pinsrb xmm14, r12d, 0x0F
000078af20bcf5cf  movaps [r15+0x130], xmm14
000078af20bcf5d7  lea r14, [rax+0x3F]
000078af20bcf5db  movzx eax, byte ptr [r13+r14*1]
000078af20bcf5e1  pinsrb xmm13, eax, 0x0F
000078af20bcf5e8  movaps [r15+0x140], xmm13
000078af20bcf5f0  movq xmm1, qword ptr [r15+0x120]
000078af20bcf5f9  pmovzxbw xmm1, xmm1
000078af20bcf5fe  psllw xmm1, 0x00
000078af20bcf603  movaps [r15+0x150], xmm1
000078af20bcf60b  movq xmm1, qword ptr [r15+0x130]
000078af20bcf614  pmovzxbw xmm1, xmm1
000078af20bcf619  psllw xmm1, 0x00
000078af20bcf61e  movaps [r15+0x160], xmm1
000078af20bcf626  movq xmm1, qword ptr [r15+0x110]
000078af20bcf62f  pmovzxbw xmm1, xmm1
000078af20bcf634  psllw xmm1, 0x00
000078af20bcf639  movaps [r15+0x170], xmm1
000078af20bcf641  movaps xmm15, [r15+0x110]
000078af20bcf649  pextrq rax, xmm15, 0x01
000078af20bcf650  movq xmm15, rax
000078af20bcf655  pmovzxbw xmm15, xmm15
000078af20bcf65b  psllw xmm15, 0x00
000078af20bcf661  movaps [r15+0x180], xmm15
000078af20bcf669  movaps xmm14, [r15+0x120]
000078af20bcf671  pextrq rax, xmm14, 0x01
000078af20bcf678  movq xmm14, rax
000078af20bcf67d  pmovzxbw xmm14, xmm14
000078af20bcf683  psllw xmm14, 0x00
000078af20bcf689  movaps [r15+0x210], xmm14
000078af20bcf691  movaps xmm13, [r15+0x130]
000078af20bcf699  pextrq rax, xmm13, 0x01
000078af20bcf6a0  movq xmm13, rax
000078af20bcf6a5  pmovzxbw xmm13, xmm13
000078af20bcf6ab  psllw xmm13, 0x00
000078af20bcf6b1  movaps [r15+0x220], xmm13
000078af20bcf6b9  movq xmm12, qword ptr [r15+0x140]
000078af20bcf6c2  pmovzxbw xmm12, xmm12
000078af20bcf6c8  psllw xmm12, 0x00
000078af20bcf6ce  movaps [r15+0x250], xmm12
000078af20bcf6d6  movaps xmm12, [r15+0x140]
000078af20bcf6de  pextrq rax, xmm12, 0x01
000078af20bcf6e5  movq xmm12, rax
000078af20bcf6ea  pmovzxbw xmm12, xmm12
000078af20bcf6f0  psllw xmm12, 0x00
000078af20bcf6f6  movaps [r15+0x110], xmm12
000078af20bcf6fe  movq xmm11, qword ptr [r15+0x150]
000078af20bcf707  pmovzxwd xmm11, xmm11
000078af20bcf70d  pslld xmm11, 0x10
000078af20bcf713  movq xmm10, qword ptr [r15+0x160]
000078af20bcf71c  pmovzxwd xmm10, xmm10
000078af20bcf722  pslld xmm10, 0x08
000078af20bcf728  pextrq rax, xmm1, 0x01
000078af20bcf72f  movq xmm1, rax
000078af20bcf734  pmovzxwd xmm1, xmm1
000078af20bcf739  pslld xmm1, 0x00
000078af20bcf73e  movaps [r15+0x260], xmm1
000078af20bcf746  pextrq rax, xmm15, 0x01
000078af20bcf74d  movq xmm15, rax
000078af20bcf752  pmovzxwd xmm15, xmm15
000078af20bcf758  pslld xmm15, 0x00
000078af20bcf75e  movaps [r15+0x270], xmm15
000078af20bcf766  movq xmm9, qword ptr [r15+0x170]
000078af20bcf76f  pmovzxwd xmm9, xmm9
000078af20bcf775  pslld xmm9, 0x00
000078af20bcf77b  pextrq rax, xmm14, 0x01
000078af20bcf782  movq xmm14, rax
000078af20bcf787  pmovzxwd xmm14, xmm14
000078af20bcf78d  pslld xmm14, 0x10
000078af20bcf793  movaps [r15+0x280], xmm14
000078af20bcf79b  movq xmm8, qword ptr [r15+0x180]
000078af20bcf7a4  pmovzxwd xmm8, xmm8
000078af20bcf7aa  pslld xmm8, 0x00
000078af20bcf7b0  movq xmm7, qword ptr [r15+0x210]
000078af20bcf7b9  pmovzxwd xmm7, xmm7
000078af20bcf7be  pslld xmm7, 0x10
000078af20bcf7c3  movaps xmm6, [r15+0x150]
000078af20bcf7cb  pextrq rax, xmm6, 0x01
000078af20bcf7d2  movq xmm6, rax
000078af20bcf7d7  pmovzxwd xmm6, xmm6
000078af20bcf7dc  pslld xmm6, 0x10
000078af20bcf7e1  por xmm11, xmm10
000078af20bcf7e6  movaps [r15+0x230], xmm11
000078af20bcf7ee  pextrq rax, xmm13, 0x01
000078af20bcf7f5  movq xmm13, rax
000078af20bcf7fa  pmovzxwd xmm13, xmm13
000078af20bcf800  pslld xmm13, 0x08
000078af20bcf806  movaps [r15+0x240], xmm13
000078af20bcf80e  movq xmm10, qword ptr [r15+0x220]
000078af20bcf817  pmovzxwd xmm10, xmm10
000078af20bcf81d  pslld xmm10, 0x08
000078af20bcf823  movaps xmm5, [r15+0x160]
000078af20bcf82b  pextrq rax, xmm5, 0x01
000078af20bcf832  movq xmm5, rax
000078af20bcf837  pmovzxwd xmm5, xmm5
000078af20bcf83c  pslld xmm5, 0x08
000078af20bcf841  pslld xmm9, 0x18
000078af20bcf847  pslld xmm15, 0x18
000078af20bcf84d  pslld xmm8, 0x18
000078af20bcf853  movq xmm4, qword ptr [r15+0x250]
000078af20bcf85c  pmovzxwd xmm4, xmm4
000078af20bcf861  pslld xmm4, 0x00
000078af20bcf866  por xmm14, xmm13
000078af20bcf86b  por xmm7, xmm10
000078af20bcf870  movaps [r15+0x210], xmm7
000078af20bcf878  pslld xmm1, 0x18
000078af20bcf87d  movaps [r15+0x220], xmm1
000078af20bcf885  por xmm6, xmm5
000078af20bcf889  por xmm11, xmm9
000078af20bcf88e  movaps [r15+0x160], xmm11
000078af20bcf896  pextrq rax, xmm12, 0x01
000078af20bcf89d  movq xmm13, rax
000078af20bcf8a2  pmovzxwd xmm13, xmm13
000078af20bcf8a8  pslld xmm13, 0x00
000078af20bcf8ae  movaps [r15+0x170], xmm13
000078af20bcf8b6  movq xmm12, qword ptr [r15+0x110]
000078af20bcf8bf  pmovzxwd xmm12, xmm12
000078af20bcf8c5  pslld xmm12, 0x00
000078af20bcf8cb  por xmm14, xmm15
000078af20bcf8d0  por xmm7, xmm8
000078af20bcf8d5  movaps xmm15, [r15+0x250]
000078af20bcf8dd  pextrq rax, xmm15, 0x01
000078af20bcf8e4  movq xmm15, rax
000078af20bcf8e9  pmovzxwd xmm15, xmm15
000078af20bcf8ef  pslld xmm15, 0x00
000078af20bcf8f5  movaps [r15+0x180], xmm15
000078af20bcf8fd  por xmm6, xmm1
000078af20bcf901  movaps [r15+0x150], xmm6
000078af20bcf909  por xmm11, xmm4
000078af20bcf90e  movaps [r15+0x140], xmm11
000078af20bcf916  por xmm7, xmm12
000078af20bcf91b  movaps [r15+0x110], xmm7
000078af20bcf923  por xmm14, xmm13
000078af20bcf928  movaps [r15+0x120], xmm14
000078af20bcf930  por xmm6, xmm15
000078af20bcf935  movaps [r15+0x130], xmm6
000078af20bcf93d  mov rax, [r15+0xF8]
000078af20bcf944  lea r14, [rax+0x20]
000078af20bcf948  movups [r13+r14*1], xmm7
000078af20bcf94e  lea r14, [rax+0x30]
000078af20bcf952  movups [r13+r14*1], xmm14
000078af20bcf958  movups [r13+rax*1], xmm11
000078af20bcf95e  lea r14, [rax+0x10]
000078af20bcf962  movups [r13+r14*1], xmm6
000078af20bcf968  mov r14d, [r13+rax*1]
000078af20bcf96d  mov rax, [r15+0x48]
000078af20bcf971  mov [r15+0x68], rax
000078af20bcf975  mov qword ptr [r15+0x58], 0x04
000078af20bcf97d  lea r12, [rax+0x04]
000078af20bcf981  mov r11d, [r13+r12*1]
000078af20bcf986  mov [rsp+0x10], r11d
000078af20bcf98b  mov r11d, r11d
000078af20bcf98e  mov [r15+0x70], r11
000078af20bcf992  lea r12, [rax+0x38]
000078af20bcf996  mov r11d, [r13+r12*1]
000078af20bcf99b  lea r12, [rax+0x24]
000078af20bcf99f  mov r10d, [r13+r12*1]
000078af20bcf9a4  mov [rsp+0x20], r10d
000078af20bcf9a9  mov r10d, r10d
000078af20bcf9ac  mov [r15+0x90], r10
000078af20bcf9b3  mov [rsp+0x30], rax
000078af20bcf9b8  xor eax, eax
000078af20bcf9ba  mov r12d, 0x04
000078af20bcf9c0  mov r10d, 0xC0
000078af20bcf9c6  cmp r12, r10
000078af20bcf9c9  cmc
000078af20bcf9ca  lahf
000078af20bcf9cb  seto al
000078af20bcf9ce  mov [r15+0x108], eax
000078af20bcf9d5  mov eax, [rsp+0x10]
000078af20bcf9d9  mov r12d, [rsp+0x10]
000078af20bcf9de  shrd eax, r12d, 0x07
000078af20bcf9e3  mov [rsp+0x10], r11d
000078af20bcf9e8  mov r10d, [rsp+0x10]
000078af20bcf9ed  shrd r11d, r10d, 0x11
000078af20bcf9f2  mov r9d, [rsp+0x20]
000078af20bcf9f7  lea r8d, [r9d+r14d*1]
000078af20bcf9fc  rorx r14d, r12d, 0x12
000078af20bcfa02  xor eax, r14d
000078af20bcfa05  rorx r14d, r10d, 0x13
000078af20bcfa0b  xor r11d, r14d
000078af20bcfa0e  mov [rsp+0x10], r11d
000078af20bcfa13  mov r11d, r11d
000078af20bcfa16  mov [r15+0x88], r11
000078af20bcfa1d  mov [rsp+0x20], r12d
000078af20bcfa22  shr r12d, 0x03
000078af20bcfa26  xor eax, r12d
000078af20bcfa29  mov [rsp+0x40], eax
000078af20bcfa2d  mov eax, eax
000078af20bcfa2f  mov [r15+0x80], rax
000078af20bcfa36  shr r10d, 0x0A
000078af20bcfa3a  mov eax, [rsp+0x10]
000078af20bcfa3e  xor eax, r10d
000078af20bcfa41  mov [rsp+0x10], eax
000078af20bcfa45  mov eax, eax
000078af20bcfa47  mov [r15+0x78], rax
000078af20bcfa4b  mov eax, [rsp+0x40]
000078af20bcfa4f  lea r14d, [r8d+eax*1]
000078af20bcfa54  mov eax, [rsp+0x10]
000078af20bcfa58  lea r12d, [r14d+eax*1]
000078af20bcfa5d  mov rax, [rsp+0x30]
000078af20bcfa62  lea r14, [rax+0x40]
000078af20bcfa66  mov [r13+r14*1], r12d
000078af20bcfa6b  mov eax, [rsp+0x20]
000078af20bcfa6f  mov eax, eax
000078af20bcfa71  mov [r15+0x60], rax
000078af20bcfa75  mov eax, [r15+0x108]
000078af20bcfa7c  sahf
000078af20bcfa7d  jnz 0x000078AF20BCFAAF
000078af20bcfa7f  cmp dword ptr [r15+0x318], 0x00
000078af20bcfa87  jz 0x000078AF20BCFF70
000078af20bcfa8d  nop [rax+rax*1], ax
000078af20bcfa96  nop [rax+rax*1], eax
000078af20bcfa9e  mov eax, 0x41088C
000078af20bcfaa3  mov [r15+0x100], rax
000078af20bcfaaa  jmp 0x000078AF209FE110
000078af20bcfaaf  cmp dword ptr [r15+0x318], 0x00
000078af20bcfab7  jz 0x000078AF20BCFDC0
000078af20bcfabd  nop [rax+rax*1], ax
000078af20bcfac6  nop [rax+rax*1], eax
000078af20bcface  mov eax, 0x410844
000078af20bcfad3  mov [r15+0x100], rax
000078af20bcfada  jmp 0x000078AF209FE110
000078af20bcfadf  int3
000078af20bcfae0  call 0x000078AF20A0D860
000078af20bcfae5  jmp 0x000078AF20BCF17A
000078af20bcfaea  call 0x000078AF20AE2420
000078af20bcfaef  jmp 0x000078AF20BCF193
000078af20bcfaf4  call 0x000078AF20AE2420
000078af20bcfaf9  jmp 0x000078AF20BCF1AC
000078af20bcfafe  call 0x000078AF20AE2420
000078af20bcfb03  jmp 0x000078AF20BCF1C5
000078af20bcfb08  call 0x000078AF20AE2420
000078af20bcfb0d  jmp 0x000078AF20BCF1DE
000078af20bcfb12  call 0x000078AF20AE2420
000078af20bcfb17  jmp 0x000078AF20BCF1EF
000078af20bcfb1c  call 0x000078AF20AE2420
000078af20bcfb21  jmp 0x000078AF20BCF200
000078af20bcfb26  call 0x000078AF20AE2420
000078af20bcfb2b  jmp 0x000078AF20BCF211
000078af20bcfb30  call 0x000078AF20AE2420
000078af20bcfb35  jmp 0x000078AF20BCF222
000078af20bcfb3a  call 0x000078AF20AE2420
000078af20bcfb3f  jmp 0x000078AF20BCF233
000078af20bcfb44  call 0x000078AF20AE2420
000078af20bcfb49  jmp 0x000078AF20BCF244
000078af20bcfb4e  call 0x000078AF20AE2420
000078af20bcfb53  jmp 0x000078AF20BCF255
000078af20bcfb58  call 0x000078AF20AE2420
000078af20bcfb5d  jmp 0x000078AF20BCF266
000078af20bcfb62  call 0x000078AF20AE2420
000078af20bcfb67  jmp 0x000078AF20BCF277
000078af20bcfb6c  call 0x000078AF20AE2420
000078af20bcfb71  jmp 0x000078AF20BCF288
000078af20bcfb76  call 0x000078AF20AE2420
000078af20bcfb7b  jmp 0x000078AF20BCF299
000078af20bcfb80  call 0x000078AF20AE2420
000078af20bcfb85  jmp 0x000078AF20BCF2AA
000078af20bcfb8a  call 0x000078AF20AE2420
000078af20bcfb8f  jmp 0x000078AF20BCF2BB
000078af20bcfb94  call 0x000078AF20AE2420
000078af20bcfb99  jmp 0x000078AF20BCF2CC
000078af20bcfb9e  call 0x000078AF20AE2420
000078af20bcfba3  jmp 0x000078AF20BCF2DD
000078af20bcfba8  call 0x000078AF20AE2420
000078af20bcfbad  jmp 0x000078AF20BCF2EE
000078af20bcfbb2  call 0x000078AF20AE2420
000078af20bcfbb7  jmp 0x000078AF20BCF2FF
000078af20bcfbbc  call 0x000078AF20AE2420
000078af20bcfbc1  jmp 0x000078AF20BCF310
000078af20bcfbc6  call 0x000078AF20AE2420
000078af20bcfbcb  jmp 0x000078AF20BCF321
000078af20bcfbd0  call 0x000078AF20AE2420
000078af20bcfbd5  jmp 0x000078AF20BCF332
000078af20bcfbda  call 0x000078AF20AE2420
000078af20bcfbdf  jmp 0x000078AF20BCF343
000078af20bcfbe4  call 0x000078AF20AE2420
000078af20bcfbe9  jmp 0x000078AF20BCF354
000078af20bcfbee  call 0x000078AF20AE2420
000078af20bcfbf3  jmp 0x000078AF20BCF365
000078af20bcfbf8  call 0x000078AF20AE2420
000078af20bcfbfd  jmp 0x000078AF20BCF376
000078af20bcfc02  call 0x000078AF20AE2420
000078af20bcfc07  jmp 0x000078AF20BCF387
000078af20bcfc0c  call 0x000078AF20AE2420
000078af20bcfc11  jmp 0x000078AF20BCF398
000078af20bcfc16  call 0x000078AF20AE2420
000078af20bcfc1b  jmp 0x000078AF20BCF3A9
000078af20bcfc20  call 0x000078AF20AE2420
000078af20bcfc25  jmp 0x000078AF20BCF3BA
000078af20bcfc2a  call 0x000078AF20AE2420
000078af20bcfc2f  jmp 0x000078AF20BCF3CB
000078af20bcfc34  call 0x000078AF20AE2420
000078af20bcfc39  jmp 0x000078AF20BCF3DC
000078af20bcfc3e  call 0x000078AF20AE2420
000078af20bcfc43  jmp 0x000078AF20BCF3ED
000078af20bcfc48  call 0x000078AF20AE2420
000078af20bcfc4d  jmp 0x000078AF20BCF3FE
000078af20bcfc52  call 0x000078AF20AE2420
000078af20bcfc57  jmp 0x000078AF20BCF40F
000078af20bcfc5c  call 0x000078AF20AE2420
000078af20bcfc61  jmp 0x000078AF20BCF420
000078af20bcfc66  call 0x000078AF20AE2420
000078af20bcfc6b  jmp 0x000078AF20BCF431
000078af20bcfc70  call 0x000078AF20AE2420
000078af20bcfc75  jmp 0x000078AF20BCF442
000078af20bcfc7a  call 0x000078AF20AE2420
000078af20bcfc7f  jmp 0x000078AF20BCF453
000078af20bcfc84  call 0x000078AF20AE2420
000078af20bcfc89  jmp 0x000078AF20BCF464
000078af20bcfc8e  call 0x000078AF20AE2420
000078af20bcfc93  jmp 0x000078AF20BCF475
000078af20bcfc98  call 0x000078AF20AE2420
000078af20bcfc9d  jmp 0x000078AF20BCF486
000078af20bcfca2  call 0x000078AF20AE2420
000078af20bcfca7  jmp 0x000078AF20BCF497
000078af20bcfcac  call 0x000078AF20AE2420
000078af20bcfcb1  jmp 0x000078AF20BCF4A8
000078af20bcfcb6  call 0x000078AF20AE2420
000078af20bcfcbb  jmp 0x000078AF20BCF4B9
000078af20bcfcc0  call 0x000078AF20AE2420
000078af20bcfcc5  jmp 0x000078AF20BCF4CA
000078af20bcfcca  call 0x000078AF20AE2420
000078af20bcfccf  jmp 0x000078AF20BCF4DB
000078af20bcfcd4  call 0x000078AF20AE2420
000078af20bcfcd9  jmp 0x000078AF20BCF4EC
000078af20bcfcde  call 0x000078AF20AE2420
000078af20bcfce3  jmp 0x000078AF20BCF4FD
000078af20bcfce8  call 0x000078AF20AE2420
000078af20bcfced  jmp 0x000078AF20BCF50E
000078af20bcfcf2  call 0x000078AF20AE2420
000078af20bcfcf7  jmp 0x000078AF20BCF51F
000078af20bcfcfc  call 0x000078AF20AE2420
000078af20bcfd01  jmp 0x000078AF20BCF530
000078af20bcfd06  call 0x000078AF20AE2420
000078af20bcfd0b  jmp 0x000078AF20BCF541
000078af20bcfd10  call 0x000078AF20AE2420
000078af20bcfd15  jmp 0x000078AF20BCF552
000078af20bcfd1a  call 0x000078AF20AE2420
000078af20bcfd1f  jmp 0x000078AF20BCF563
000078af20bcfd24  call 0x000078AF20AE2420
000078af20bcfd29  jmp 0x000078AF20BCF574
000078af20bcfd2e  call 0x000078AF20AE2420
000078af20bcfd33  jmp 0x000078AF20BCF585
000078af20bcfd38  call 0x000078AF20AE2420
000078af20bcfd3d  jmp 0x000078AF20BCF596
000078af20bcfd42  call 0x000078AF20AE2420
000078af20bcfd47  jmp 0x000078AF20BCF5AF
000078af20bcfd4c  call 0x000078AF20AE2420
000078af20bcfd51  jmp 0x000078AF20BCF5C8
000078af20bcfd56  call 0x000078AF20AD5610
000078af20bcfd5b  jmp 0x000078AF20BCF5E1
000078af20bcfd60  call 0x000078AF20ADC580
000078af20bcfd65  jmp 0x000078AF20BCF94E
000078af20bcfd6a  call 0x000078AF20AE46C0
000078af20bcfd6f  jmp 0x000078AF20BCF958
000078af20bcfd74  call 0x000078AF20A09E90
000078af20bcfd79  jmp 0x000078AF20BCF95E
000078af20bcfd7e  call 0x000078AF20ADB310
000078af20bcfd83  jmp 0x000078AF20BCF968
000078af20bcfd88  call 0x000078AF20A0DAE0
000078af20bcfd8d  jmp 0x000078AF20BCF96D
000078af20bcfd92  call 0x000078AF20AC0230
000078af20bcfd97  jmp 0x000078AF20BCF986
000078af20bcfd9c  call 0x000078AF20AC0230
000078af20bcfda1  jmp 0x000078AF20BCF99B
000078af20bcfda6  call 0x000078AF20ABEFC0
000078af20bcfdab  jmp 0x000078AF20BCF9A4
000078af20bcfdb0  call 0x000078AF20AE2BA0
000078af20bcfdb5  jmp 0x000078AF20BCFA6B
000078af20bcfdba  int3
000078af20bcfdbb  nop [rax+rax*1], eax
000078af20bcfdc0  mov rax, [r15+0x48]
000078af20bcfdc4  mov r14, [r15+0x58]
000078af20bcfdc8  lea r12, [rax+r14*1]
000078af20bcfdcc  mov [r15+0x68], r12
000078af20bcfdd0  lea rax, [r14+0x04]
000078af20bcfdd4  mov [r15+0x58], rax
000078af20bcfdd8  lea r14, [r12+0x04]
000078af20bcfddd  mov r11d, [r13+r14*1]
000078af20bcfde2  mov [rsp+0x10], r11d
000078af20bcfde7  mov r11d, r11d
000078af20bcfdea  mov [r15+0x70], r11
000078af20bcfdee  lea r14, [r12+0x38]
000078af20bcfdf3  mov r11d, [r13+r14*1]
000078af20bcfdf8  lea r14, [r12+0x24]
000078af20bcfdfd  mov r10d, [r13+r14*1]
000078af20bcfe02  mov [rsp+0x20], r10d
000078af20bcfe07  mov r10d, r10d
000078af20bcfe0a  mov [r15+0x90], r10
000078af20bcfe11  mov [rsp+0x30], rax
000078af20bcfe16  xor eax, eax
000078af20bcfe18  mov r14, [rsp+0x30]
000078af20bcfe1d  mov r10d, 0xC0
000078af20bcfe23  cmp r14, r10
000078af20bcfe26  cmc
000078af20bcfe27  lahf
000078af20bcfe28  seto al
000078af20bcfe2b  mov [r15+0x108], eax
000078af20bcfe32  mov eax, [rsp+0x10]
000078af20bcfe36  mov r14d, [rsp+0x10]
000078af20bcfe3b  shrd eax, r14d, 0x07
000078af20bcfe40  mov [rsp+0x10], r11d
000078af20bcfe45  mov r10d, [rsp+0x10]
000078af20bcfe4a  shrd r11d, r10d, 0x11
000078af20bcfe4f  mov r9d, [r15+0x60]
000078af20bcfe53  mov r8d, [rsp+0x20]
000078af20bcfe58  lea ebp, [r8d+r9d*1]
000078af20bcfe5d  rorx r9d, r14d, 0x12
000078af20bcfe63  xor eax, r9d
000078af20bcfe66  rorx r9d, r10d, 0x13
000078af20bcfe6c  xor r11d, r9d
000078af20bcfe6f  mov [rsp+0x10], r11d
000078af20bcfe74  mov r11d, r11d
000078af20bcfe77  mov [r15+0x88], r11
000078af20bcfe7e  mov [rsp+0x20], r14d
000078af20bcfe83  shr r14d, 0x03
000078af20bcfe87  xor eax, r14d
000078af20bcfe8a  mov [rsp+0x30], eax
000078af20bcfe8e  mov eax, eax
000078af20bcfe90  mov [r15+0x80], rax
000078af20bcfe97  shr r10d, 0x0A
000078af20bcfe9b  mov eax, [rsp+0x10]
000078af20bcfe9f  xor eax, r10d
000078af20bcfea2  mov [rsp+0x10], eax
000078af20bcfea6  mov eax, eax
000078af20bcfea8  mov [r15+0x78], rax
000078af20bcfeac  mov eax, [rsp+0x30]
000078af20bcfeb0  lea r14d, [ebp+eax*1]
000078af20bcfeb6  mov eax, [rsp+0x10]
000078af20bcfeba  lea r11d, [r14d+eax*1]
000078af20bcfebf  lea rax, [r12+0x40]
000078af20bcfec4  mov [r13+rax*1], r11d
000078af20bcfec9  mov eax, [rsp+0x20]
000078af20bcfecd  mov eax, eax
000078af20bcfecf  mov [r15+0x60], rax
000078af20bcfed3  mov eax, [r15+0x108]
000078af20bcfeda  sahf
000078af20bcfedb  jnz 0x000078AF20BCFF0D
000078af20bcfedd  cmp dword ptr [r15+0x318], 0x00
000078af20bcfee5  jz 0x000078AF20BCFF70
000078af20bcfeeb  nop [rax+rax*1], ax
000078af20bcfef4  nop [rax+rax*1], eax
000078af20bcfefc  mov eax, 0x41088C
000078af20bcff01  mov [r15+0x100], rax
000078af20bcff08  jmp 0x000078AF209FE110
000078af20bcff0d  cmp dword ptr [r15+0x318], 0x00
000078af20bcff15  jz 0x000078AF20BCFDC0
000078af20bcff1b  nop [rax+rax*1], ax
000078af20bcff24  nop [rax+rax*1], eax
000078af20bcff2c  mov eax, 0x410844
000078af20bcff31  mov [r15+0x100], rax
000078af20bcff38  jmp 0x000078AF209FE110
000078af20bcff3d  int3
000078af20bcff3e  call 0x000078AF20AE1430
000078af20bcff43  jmp 0x000078AF20BCFDE2
000078af20bcff48  call 0x000078AF20AE1430
000078af20bcff4d  jmp 0x000078AF20BCFDF8
000078af20bcff52  call 0x000078AF20AE01C0
000078af20bcff57  jmp 0x000078AF20BCFE02
000078af20bcff5c  call 0x000078AF20A0A860
000078af20bcff61  jmp 0x000078AF20BCFEC9
000078af20bcff66  int3
000078af20bcff67  nop [rax+rax*1], ax
000078af20bcff70  mov rax, [r15]
000078af20bcff73  mov r14d, [r13+rax*1]
000078af20bcff78  lea r12, [rax+0x04]
000078af20bcff7c  mov r11d, [r13+r12*1]
000078af20bcff81  mov [rsp+0x10], r14d
000078af20bcff86  mov r14d, r14d
000078af20bcff89  mov [r15+0x78], r14
000078af20bcff8d  mov [rsp+0x20], r11d
000078af20bcff92  mov r11d, r11d
000078af20bcff95  mov [r15+0x80], r11
000078af20bcff9c  lea r14, [rax+0x08]
000078af20bcffa0  mov r12d, [r13+r14*1]
000078af20bcffa5  lea r14, [rax+0x0C]
000078af20bcffa9  mov r11d, [r13+r14*1]
000078af20bcffae  mov [rsp+0x30], r12d
000078af20bcffb3  mov r12d, r12d
000078af20bcffb6  mov [r15+0x70], r12
000078af20bcffba  mov [rsp+0x40], r11d
000078af20bcffbf  mov r11d, r11d
000078af20bcffc2  mov [r15+0x68], r11
000078af20bcffc6  lea r14, [rax+0x18]
000078af20bcffca  mov r12d, [r13+r14*1]
000078af20bcffcf  lea r14, [rax+0x1C]
000078af20bcffd3  mov r11d, [r13+r14*1]
000078af20bcffd8  mov [rsp+0x50], r12d
000078af20bcffdd  mov r12d, r12d
000078af20bcffe0  mov [r15+0x58], r12
000078af20bcffe4  mov [rsp+0x60], r11d
000078af20bcffe9  mov r11d, r11d
000078af20bcffec  mov [r15+0x60], r11
000078af20bcfff0  lea r14, [rax+0x10]
000078af20bcfff4  mov r12d, [r13+r14*1]
000078af20bcfff9  lea r14, [rax+0x14]
000078af20bcfffd  mov eax, [r13+r14*1]
000078af20bd0002  mov [rsp+0x70], r12d
000078af20bd0007  mov r12d, r12d
000078af20bd000a  mov [r15+0x18], r12
000078af20bd000e  mov [rsp+0x80], eax
000078af20bd0015  mov eax, eax
000078af20bd0017  mov [r15+0x90], rax
000078af20bd001e  mov eax, [rsp+0x70]
000078af20bd0022  mov eax, eax
000078af20bd0024  mov [r15+0x30], rax
000078af20bd0028  mov eax, [rsp+0x50]
000078af20bd002c  mov eax, eax
000078af20bd002e  mov [r15+0xA0], rax
000078af20bd0035  mov eax, [rsp+0x30]
000078af20bd0039  mov eax, eax
000078af20bd003b  mov [r15+0x28], rax
000078af20bd003f  mov eax, [rsp+0x20]
000078af20bd0043  mov eax, eax
000078af20bd0045  mov [r15+0x98], rax
000078af20bd004c  mov eax, [rsp+0x10]
000078af20bd0050  mov eax, eax
000078af20bd0052  mov [r15+0x38], rax
000078af20bd0056  mov eax, [rsp+0x70]
000078af20bd005a  mov r14d, [rsp+0x70]
000078af20bd005f  shrd eax, r14d, 0x06
000078af20bd0064  mov [rsp+0x70], r14d
000078af20bd0069  mov r12d, [rsp+0x80]
000078af20bd0071  and r14d, r12d
000078af20bd0074  mov r11d, [rsp+0x10]
000078af20bd0079  mov r10d, [rsp+0x10]
000078af20bd007e  shrd r11d, r10d, 0x02
000078af20bd0083  mov [rsp+0x10], r12d
000078af20bd0088  mov r12d, r12d
000078af20bd008b  mov [r15+0x20], r12
000078af20bd008f  mov r12, [r15+0x50]
000078af20bd0093  mov r9d, [r13+r12*1]
000078af20bd0098  mov r12d, [rsp+0x50]
000078af20bd009d  mov r8d, [rsp+0x70]
000078af20bd00a2  andn ebp, r8d, r12d
000078af20bd00a7  mov edi, [rsp+0x60]
000078af20bd00ab  lea esi, [r14d+edi*1]
000078af20bd00b0  rorx r14d, r8d, 0x0B
000078af20bd00b6  xor eax, r14d
000078af20bd00b9  rorx r14d, r10d, 0x0D
000078af20bd00bf  xor r11d, r14d
000078af20bd00c2  lea edi, [esi+ebp*1]
000078af20bd00c6  mov r14, [r15+0x48]
000078af20bd00ca  mov ebp, [r13+r14*1]
000078af20bd00cf  mov r14d, [rsp+0x30]
000078af20bd00d4  mov esi, [rsp+0x20]
000078af20bd00d8  and r14d, esi
000078af20bd00db  mov [rsp+0x20], r14d
000078af20bd00e0  mov r14d, r14d
000078af20bd00e3  mov [r15+0xD8], r14
000078af20bd00ea  lea r14d, [edi+r9d*1]
000078af20bd00ef  mov r9d, [rsp+0x30]
000078af20bd00f4  xor r9d, esi
000078af20bd00f7  rorx edi, r8d, 0x19
000078af20bd00fd  xor eax, edi
000078af20bd00ff  and r9d, r10d
000078af20bd0102  rorx edi, r10d, 0x16
000078af20bd0108  xor r11d, edi
000078af20bd010b  mov [rsp+0x30], r11d
000078af20bd0110  mov r11d, r11d
000078af20bd0113  mov [r15+0xD0], r11
000078af20bd011a  lea r11d, [r14d+ebp*1]
000078af20bd011f  mov r10d, [rsp+0x20]
000078af20bd0124  xor r9d, r10d
000078af20bd0127  lea r14d, [r11d+eax*1]
000078af20bd012c  mov qword ptr [r15+0x88], 0x04
000078af20bd0137  mov eax, [rsp+0x30]
000078af20bd013b  lea r11d, [r9d+eax*1]
000078af20bd0140  mov eax, [rsp+0x40]
000078af20bd0144  lea r10d, [r14d+eax*1]
000078af20bd0149  mov r10d, r10d
000078af20bd014c  mov [r15+0xB8], r10
000078af20bd0153  xor eax, eax
000078af20bd0155  mov r10d, 0x04
000078af20bd015b  mov r9d, 0x100
000078af20bd0161  cmp r10, r9
000078af20bd0164  cmc
000078af20bd0165  lahf
000078af20bd0166  seto al
000078af20bd0169  mov [r15+0x108], eax
000078af20bd0170  lea eax, [r11d+r14d*1]
000078af20bd0175  mov eax, eax
000078af20bd0177  mov [r15+0xA8], rax
000078af20bd017e  mov r12d, r12d
000078af20bd0181  mov [r15+0xB0], r12
000078af20bd0188  mov eax, [rsp+0x10]
000078af20bd018c  mov eax, eax
000078af20bd018e  mov [r15+0xC0], rax
000078af20bd0195  mov r8d, r8d
000078af20bd0198  mov [r15+0xC8], r8
000078af20bd019f  mov eax, [r15+0x108]
000078af20bd01a6  sahf
000078af20bd01a7  jnz 0x000078AF20BD01D9
000078af20bd01a9  cmp dword ptr [r15+0x318], 0x00
000078af20bd01b1  jz 0x000078AF20BD04A0
000078af20bd01b7  nop [rax+rax*1], ax
000078af20bd01c0  nop [rax+rax*1], eax
000078af20bd01c8  mov eax, 0x41094C
000078af20bd01cd  mov [r15+0x100], rax
000078af20bd01d4  jmp 0x000078AF209FE110
000078af20bd01d9  cmp dword ptr [r15+0x318], 0x00
000078af20bd01e1  jz 0x000078AF20BD0270
000078af20bd01e7  nop [rax+rax*1], ax
000078af20bd01f0  nop [rax+rax*1], eax
000078af20bd01f8  mov eax, 0x4108C0
000078af20bd01fd  mov [r15+0x100], rax
000078af20bd0204  jmp 0x000078AF209FE110
000078af20bd0209  int3
000078af20bd020a  call 0x000078AF20A0DAE0
000078af20bd020f  jmp 0x000078AF20BCFF78
000078af20bd0214  call 0x000078AF20AC0230
000078af20bd0219  jmp 0x000078AF20BCFF81
000078af20bd021e  call 0x000078AF20AE26A0
000078af20bd0223  jmp 0x000078AF20BCFFA5
000078af20bd0228  call 0x000078AF20AE1430
000078af20bd022d  jmp 0x000078AF20BCFFAE
000078af20bd0232  call 0x000078AF20AE26A0
000078af20bd0237  jmp 0x000078AF20BCFFCF
000078af20bd023c  call 0x000078AF20AE1430
000078af20bd0241  jmp 0x000078AF20BCFFD8
000078af20bd0246  call 0x000078AF20AE26A0
000078af20bd024b  jmp 0x000078AF20BCFFF9
000078af20bd0250  call 0x000078AF20AD5890
000078af20bd0255  jmp 0x000078AF20BD0002
000078af20bd025a  call 0x000078AF20ABDD50
000078af20bd025f  jmp 0x000078AF20BD0098
000078af20bd0264  call 0x000078AF20ADA580
000078af20bd0269  jmp 0x000078AF20BD00CF
000078af20bd026e  int3
000078af20bd026f  nop
000078af20bd0270  mov eax, [r15+0xB8]
000078af20bd0277  mov [rsp+0x10], eax
000078af20bd027b  mov eax, eax
000078af20bd027d  mov [r15+0x30], rax
000078af20bd0281  mov eax, [r15+0xC0]
000078af20bd0288  mov [rsp+0x20], eax
000078af20bd028c  mov eax, eax
000078af20bd028e  mov [r15+0xA0], rax
000078af20bd0295  mov eax, [r15+0x28]
000078af20bd0299  mov r14d, [r15+0x98]
000078af20bd02a0  mov [rsp+0x30], r14d
000078af20bd02a5  mov r14d, r14d
000078af20bd02a8  mov [r15+0x28], r14
000078af20bd02ac  mov r14d, [r15+0x38]
000078af20bd02b0  mov [rsp+0x40], r14d
000078af20bd02b5  mov r14d, r14d
000078af20bd02b8  mov [r15+0x98], r14
000078af20bd02bf  mov r14d, [r15+0xA8]
000078af20bd02c6  mov [rsp+0x50], r14d
000078af20bd02cb  mov r14d, r14d
000078af20bd02ce  mov [r15+0x38], r14
000078af20bd02d2  mov r14d, [rsp+0x10]
000078af20bd02d7  mov r12d, [rsp+0x10]
000078af20bd02dc  shrd r14d, r12d, 0x06
000078af20bd02e1  mov r11d, [r15+0xC8]
000078af20bd02e8  mov [rsp+0x10], r12d
000078af20bd02ed  and r12d, r11d
000078af20bd02f0  mov r10d, [rsp+0x50]
000078af20bd02f5  mov r9d, [rsp+0x50]
000078af20bd02fa  shrd r10d, r9d, 0x02
000078af20bd02ff  mov [rsp+0x50], r11d
000078af20bd0304  mov r11d, r11d
000078af20bd0307  mov [r15+0x20], r11
000078af20bd030b  mov r11, [r15+0x88]
000078af20bd0312  mov r8, [r15+0x50]
000078af20bd0316  lea rbp, [r8+r11*1]
000078af20bd031a  mov r8d, [r13+rbp*1]
000078af20bd031f  mov ebp, [rsp+0x20]
000078af20bd0323  mov edi, [rsp+0x10]
000078af20bd0327  andn esi, edi, ebp
000078af20bd032c  mov edx, [r15+0xB0]
000078af20bd0333  lea ecx, [r12d+edx*1]
000078af20bd0338  rorx r12d, edi, 0x0B
000078af20bd033e  xor r14d, r12d
000078af20bd0341  rorx r12d, r9d, 0x0D
000078af20bd0347  xor r10d, r12d
000078af20bd034a  lea r12d, [ecx+esi*1]
000078af20bd034f  mov rsi, [r15+0x48]
000078af20bd0353  lea rdx, [rsi+r11*1]
000078af20bd0357  mov esi, [r13+rdx*1]
000078af20bd035c  mov edx, [rsp+0x30]
000078af20bd0360  mov ecx, [rsp+0x40]
000078af20bd0364  and edx, ecx
000078af20bd0366  mov [rsp+0x10], edx
000078af20bd036a  mov edx, edx
000078af20bd036c  mov [r15+0xD8], rdx
000078af20bd0373  lea edx, [r12d+r8d*1]
000078af20bd0378  mov r12d, [rsp+0x30]
000078af20bd037d  xor r12d, ecx
000078af20bd0380  rorx r8d, edi, 0x19
000078af20bd0386  xor r14d, r8d
000078af20bd0389  and r12d, r9d
000078af20bd038c  rorx r8d, r9d, 0x16
000078af20bd0392  xor r10d, r8d
000078af20bd0395  mov [rsp+0x20], r10d
000078af20bd039a  mov r10d, r10d
000078af20bd039d  mov [r15+0xD0], r10
000078af20bd03a4  lea r10d, [edx+esi*1]
000078af20bd03a9  mov r9d, [rsp+0x10]
000078af20bd03ae  xor r12d, r9d
000078af20bd03b1  lea r9d, [r10d+r14d*1]
000078af20bd03b6  lea r14, [r11+0x04]
000078af20bd03ba  mov [r15+0x88], r14
000078af20bd03c1  mov r11d, [rsp+0x20]
000078af20bd03c6  lea r10d, [r12d+r11d*1]
000078af20bd03cb  lea r11d, [r9d+eax*1]
000078af20bd03d0  mov r11d, r11d
000078af20bd03d3  mov [r15+0xB8], r11
000078af20bd03da  xor eax, eax
000078af20bd03dc  mov r12d, 0x100
000078af20bd03e2  cmp r14, r12
000078af20bd03e5  cmc
000078af20bd03e6  lahf
000078af20bd03e7  seto al
000078af20bd03ea  mov [r15+0x108], eax
000078af20bd03f1  lea eax, [r10d+r9d*1]
000078af20bd03f6  mov eax, eax
000078af20bd03f8  mov [r15+0xA8], rax
000078af20bd03ff  mov ebp, ebp
000078af20bd0401  mov [r15+0xB0], rbp
000078af20bd0408  mov eax, [rsp+0x50]
000078af20bd040c  mov eax, eax
000078af20bd040e  mov [r15+0xC0], rax
000078af20bd0415  mov edi, edi
000078af20bd0417  mov [r15+0xC8], rdi
000078af20bd041e  mov eax, [r15+0x108]
000078af20bd0425  sahf
000078af20bd0426  jnz 0x000078AF20BD0458
000078af20bd0428  cmp dword ptr [r15+0x318], 0x00
000078af20bd0430  jz 0x000078AF20BD04A0
000078af20bd0436  nop [rax+rax*1], ax
000078af20bd043f  nop [rax+rax*1], eax
000078af20bd0447  mov eax, 0x41094C
000078af20bd044c  mov [r15+0x100], rax
000078af20bd0453  jmp 0x000078AF209FE110
000078af20bd0458  cmp dword ptr [r15+0x318], 0x00
000078af20bd0460  jz 0x000078AF20BD0270
000078af20bd0466  nop [rax+rax*1], ax
000078af20bd046f  nop [rax+rax*1], eax
000078af20bd0477  mov eax, 0x4108C0
000078af20bd047c  mov [r15+0x100], rax
000078af20bd0483  jmp 0x000078AF209FE110
000078af20bd0488  int3
000078af20bd0489  call 0x000078AF20A49010
000078af20bd048e  jmp 0x000078AF20BD031F
000078af20bd0493  call 0x000078AF20A25930
000078af20bd0498  jmp 0x000078AF20BD035C
000078af20bd049d  int3
000078af20bd049e  nop
000078af20bd04a0  mov eax, [r15+0x98]
000078af20bd04a7  mov r14d, [r15+0x70]
000078af20bd04ab  lea r12d, [eax+r14d*1]
000078af20bd04b0  mov eax, [r15+0x28]
000078af20bd04b4  mov r14d, [r15+0x68]
000078af20bd04b8  lea r11d, [eax+r14d*1]
000078af20bd04bd  mov qword ptr [r15+0x88], 0x00
000078af20bd04c8  mov eax, [r15+0xA8]
000078af20bd04cf  mov r14d, [r15+0x78]
000078af20bd04d3  lea r10d, [eax+r14d*1]
000078af20bd04d8  mov [rsp+0x10], r10d
000078af20bd04dd  mov r10d, r10d
000078af20bd04e0  mov [r15+0x78], r10
000078af20bd04e4  mov eax, [r15+0x38]
000078af20bd04e8  mov r14d, [r15+0x80]
000078af20bd04ef  lea r10d, [eax+r14d*1]
000078af20bd04f4  mov [rsp+0x20], r10d
000078af20bd04f9  mov r10d, r10d
000078af20bd04fc  mov [r15+0x80], r10
000078af20bd0503  mov rax, [r15]
000078af20bd0506  lea r14, [rax+0x08]
000078af20bd050a  mov [r13+r14*1], r12d
000078af20bd050f  lea r14, [rax+0x0C]
000078af20bd0513  mov [r13+r14*1], r11d
000078af20bd0518  mov r14d, [r15+0xB8]
000078af20bd051f  mov r12d, [r15+0x18]
000078af20bd0523  lea r11d, [r14d+r12d*1]
000078af20bd0528  mov [rsp+0x30], r11d
000078af20bd052d  mov r11d, r11d
000078af20bd0530  mov [r15+0x68], r11
000078af20bd0534  mov r14d, [r15+0x30]
000078af20bd0538  mov r12d, [r15+0x90]
000078af20bd053f  lea r11d, [r14d+r12d*1]
000078af20bd0544  mov [rsp+0x40], r11d
000078af20bd0549  mov r11d, r11d
000078af20bd054c  mov [r15+0x70], r11
000078af20bd0550  mov r14d, [r15+0x20]
000078af20bd0554  mov r12d, [r15+0x58]
000078af20bd0558  lea r11d, [r14d+r12d*1]
000078af20bd055d  mov [rsp+0x50], r11d
000078af20bd0562  mov r11d, r11d
000078af20bd0565  mov [r15+0x58], r11
000078af20bd0569  mov r14d, [r15+0xA0]
000078af20bd0570  mov r12d, [r15+0x60]
000078af20bd0574  lea r11d, [r14d+r12d*1]
000078af20bd0579  mov [rsp+0x60], r11d
000078af20bd057e  mov r11d, r11d
000078af20bd0581  mov [r15+0x60], r11
000078af20bd0585  mov r14d, [rsp+0x10]
000078af20bd058a  mov [r13+rax*1], r14d
000078af20bd058f  lea r14, [rax+0x04]
000078af20bd0593  mov r12d, [rsp+0x20]
000078af20bd0598  mov [r13+r14*1], r12d
000078af20bd059d  lea r14, [rax+0x10]
000078af20bd05a1  mov r12d, [rsp+0x30]
000078af20bd05a6  mov [r13+r14*1], r12d
000078af20bd05ab  lea r14, [rax+0x14]
000078af20bd05af  mov r12d, [rsp+0x40]
000078af20bd05b4  mov [r13+r14*1], r12d
000078af20bd05b9  lea r14, [rax+0x18]
000078af20bd05bd  mov r12d, [rsp+0x50]
000078af20bd05c2  mov [r13+r14*1], r12d
000078af20bd05c7  lea r14, [rax+0x1C]
000078af20bd05cb  mov r12d, [rsp+0x60]
000078af20bd05d0  mov [r13+r14*1], r12d
000078af20bd05d5  lea r14, [rax+0x68]
000078af20bd05d9  xor eax, eax
000078af20bd05db  mov [r13+r14*1], rax
000078af20bd05e0  cmp dword ptr [r15+0x318], 0x00
000078af20bd05e8  jz 0x000078AF20BCF0E0
000078af20bd05ee  nop [rax+rax*1], ax
000078af20bd05f7  nop [rax+rax*1], eax
000078af20bd05ff  mov eax, 0x410768
000078af20bd0604  mov [r15+0x100], rax
000078af20bd060b  jmp 0x000078AF209FE110
000078af20bd0610  int3
000078af20bd0611  call 0x000078AF20AE2BA0
000078af20bd0616  jmp 0x000078AF20BD050F
000078af20bd061b  call 0x000078AF20AE1920
000078af20bd0620  jmp 0x000078AF20BD0518
000078af20bd0625  call 0x000078AF20A0DFE0
000078af20bd062a  jmp 0x000078AF20BD058F
000078af20bd062f  call 0x000078AF20AE2BA0
000078af20bd0634  jmp 0x000078AF20BD059D
000078af20bd0639  call 0x000078AF20AE2BA0
000078af20bd063e  jmp 0x000078AF20BD05AB
000078af20bd0643  call 0x000078AF20AE2BA0
000078af20bd0648  jmp 0x000078AF20BD05B9
000078af20bd064d  call 0x000078AF20AE2BA0
000078af20bd0652  jmp 0x000078AF20BD05C7
000078af20bd0657  call 0x000078AF20AE2BA0
000078af20bd065c  jmp 0x000078AF20BD05D5
000078af20bd0661  call 0x000078AF20AD5EB0
000078af20bd0666  jmp 0x000078AF20BD05E0
000078af20bd066b  int3
000078af20bd066c  nop [rax], eax
000078af20bd0670  mov rax, [r15+0xF8]
000078af20bd0677  lea r14, [rax+0x140]
000078af20bd067e  mov r12, [r13+r14*1]
000078af20bd0683  lea r14, [rax+0x148]
000078af20bd068a  mov r11, [r13+r14*1]
000078af20bd068f  mov [r15+0xA0], r12
000078af20bd0696  mov [r15+0x98], r11
000078af20bd069d  lea r14, [rax+0x130]
000078af20bd06a4  mov r12, [r13+r14*1]
000078af20bd06a9  lea r14, [rax+0x138]
000078af20bd06b0  mov r11, [r13+r14*1]
000078af20bd06b5  mov [r15+0xB0], r12
000078af20bd06bc  mov [r15+0xA8], r11
000078af20bd06c3  lea r14, [rax+0x120]
000078af20bd06ca  mov r12, [r13+r14*1]
000078af20bd06cf  lea r14, [rax+0x128]
000078af20bd06d6  mov r11, [r13+r14*1]
000078af20bd06db  mov [r15+0xC0], r12
000078af20bd06e2  mov [r15+0xB8], r11
000078af20bd06e9  lea r14, [rax+0x110]
000078af20bd06f0  mov r12, [r13+r14*1]
000078af20bd06f5  lea r14, [rax+0x118]
000078af20bd06fc  mov r11, [r13+r14*1]
000078af20bd0701  mov [r15+0xD0], r12
000078af20bd0708  mov [r15+0xC8], r11
000078af20bd070f  lea r14, [rax+0x100]
000078af20bd0716  mov r12, [r13+r14*1]
000078af20bd071b  lea r14, [rax+0x108]
000078af20bd0722  mov r11, [r13+r14*1]
000078af20bd0727  mov [r15+0xE8], r12
000078af20bd072e  mov [r15+0xD8], r11
000078af20bd0735  lea r14, [rax+0x150]
000078af20bd073c  mov [r15+0xF8], r14
000078af20bd0743  mov rax, [r15+0xF0]
000078af20bd074a  mov [r15+0x100], rax
000078af20bd0751  jmp 0x000078AF20BCE5C0
000078af20bd0756  int3
000078af20bd0757  call 0x000078AF20AE27E0
000078af20bd075c  jmp 0x000078AF20BD0683
000078af20bd0761  call 0x000078AF20AE1570
000078af20bd0766  jmp 0x000078AF20BD068F
000078af20bd076b  call 0x000078AF20AE27E0
000078af20bd0770  jmp 0x000078AF20BD06A9
000078af20bd0775  call 0x000078AF20AE1570
000078af20bd077a  jmp 0x000078AF20BD06B5
000078af20bd077f  call 0x000078AF20AE27E0
000078af20bd0784  jmp 0x000078AF20BD06CF
000078af20bd0789  call 0x000078AF20AE1570
000078af20bd078e  jmp 0x000078AF20BD06DB
000078af20bd0793  call 0x000078AF20AE27E0
000078af20bd0798  jmp 0x000078AF20BD06F5
000078af20bd079d  call 0x000078AF20AE1570
000078af20bd07a2  jmp 0x000078AF20BD0701
000078af20bd07a7  call 0x000078AF20AE27E0
000078af20bd07ac  jmp 0x000078AF20BD071B
000078af20bd07b1  call 0x000078AF20AE1570
000078af20bd07b6  jmp 0x000078AF20BD0727
000078af20bd07bb  int3
000078af20bd07bc  nop [rax], eax
000078af20bd07c0  mov eax, [r15+0xA0]
000078af20bd07c7  mov [rsp+0x10], eax
000078af20bd07cb  xor eax, eax
000078af20bd07cd  mov r14d, [rsp+0x10]
000078af20bd07d2  sub r14d, 0x01
000078af20bd07d6  cmc
000078af20bd07d7  lahf
000078af20bd07d8  seto al
000078af20bd07db  mov [r15+0x108], eax
000078af20bd07e2  mov r14d, r14d
000078af20bd07e5  mov [r15+0xA0], r14
000078af20bd07ec  mov eax, [r15+0x108]
000078af20bd07f3  sahf
000078af20bd07f4  jnz 0x000078AF20BD0826
000078af20bd07f6  cmp dword ptr [r15+0x318], 0x00
000078af20bd07fe  jz 0x000078AF20BD0900
000078af20bd0804  nop [rax+rax*1], ax
000078af20bd080d  nop [rax+rax*1], eax
000078af20bd0815  mov eax, 0x41028C
000078af20bd081a  mov [r15+0x100], rax
000078af20bd0821  jmp 0x000078AF209FE110
000078af20bd0826  cmp dword ptr [r15+0x318], 0x00
000078af20bd082e  jz 0x000078AF20BD0860
000078af20bd0834  nop [rax+rax*1], ax
000078af20bd083d  nop [rax+rax*1], eax
000078af20bd0845  mov eax, 0x410274
000078af20bd084a  mov [r15+0x100], rax
000078af20bd0851  jmp 0x000078AF209FE110
000078af20bd0856  int3
000078af20bd0857  int3
000078af20bd0858  nop [rax+rax*1], eax
000078af20bd0860  mov rax, [r15+0xF8]
000078af20bd0867  lea r14, [rax+0x100]
000078af20bd086e  mov [r15], r14
000078af20bd0871  mov rax, [r15+0x98]
000078af20bd0878  mov [r15+0x08], rax
000078af20bd087c  mov qword ptr [r15+0x10], 0x12C
000078af20bd0884  mov qword ptr [r15+0xF0], 0x410284
000078af20bd088f  mov r14d, [r15+0x320]
000078af20bd0896  mov eax, 0x410284
000078af20bd089b  mov rcx, 0x78AF20BD07C0
000078af20bd08a5  mov [r15+r14*8+0x328], rax
000078af20bd08ad  mov [r15+r14*8+0x368], rcx
000078af20bd08b5  add r14d, 0x01
000078af20bd08b9  and r14d, 0x07
000078af20bd08bd  mov [r15+0x320], r14d
000078af20bd08c4  cmp dword ptr [r15+0x318], 0x00
000078af20bd08cc  jz 0x000078AF20BCED70
000078af20bd08d2  nop [rax+rax*1], ax
000078af20bd08db  nop [rax+rax*1], eax
000078af20bd08e3  mov eax, 0x410728
000078af20bd08e8  mov [r15+0x100], rax
000078af20bd08ef  jmp 0x000078AF209FE110
000078af20bd08f4  int3
000078af20bd08f5  int3
000078af20bd08f6  nop [rax+rax*1], ax
000078af20bd08ff  nop
000078af20bd0900  mov rax, [r15+0xF8]
000078af20bd0907  lea r14, [rax+0x120]
000078af20bd090e  mov r12, [r13+r14*1]
000078af20bd0913  mov [r15+0x98], r12
000078af20bd091a  mov qword ptr [r15+0x40], 0x80
000078af20bd0922  lea r14, [rax+0x100]
000078af20bd0929  mov [r15], r14
000078af20bd092c  lea r14, [rax+0x17C]
000078af20bd0933  mov [r15+0x08], r14
000078af20bd0937  mov qword ptr [r15+0x10], 0x01
000078af20bd093f  lea r14, [rax+0x17C]
000078af20bd0946  mov eax, 0x80
000078af20bd094b  mov [r13+r14*1], al
000078af20bd0950  mov qword ptr [r15+0xF0], 0x4102A8
000078af20bd095b  mov r14d, [r15+0x320]
000078af20bd0962  mov eax, 0x4102A8
000078af20bd0967  mov rcx, 0x78AF20BD09E0
000078af20bd0971  mov [r15+r14*8+0x328], rax
000078af20bd0979  mov [r15+r14*8+0x368], rcx
000078af20bd0981  add r14d, 0x01
000078af20bd0985  and r14d, 0x07
000078af20bd0989  mov [r15+0x320], r14d
000078af20bd0990  cmp dword ptr [r15+0x318], 0x00
000078af20bd0998  jz 0x000078AF20BCED70
000078af20bd099e  nop [rax+rax*1], ax
000078af20bd09a7  nop [rax+rax*1], eax
000078af20bd09af  mov eax, 0x410728
000078af20bd09b4  mov [r15+0x100], rax
000078af20bd09bb  jmp 0x000078AF209FE110
000078af20bd09c0  int3
000078af20bd09c1  call 0x000078AF20AE27E0
000078af20bd09c6  jmp 0x000078AF20BD0913
000078af20bd09cb  call 0x000078AF20AD5AF0
000078af20bd09d0  jmp 0x000078AF20BD0950
000078af20bd09d5  int3
000078af20bd09d6  nop [rax+rax*1], ax
000078af20bd09df  nop
000078af20bd09e0  mov rax, [r15+0xF8]
000078af20bd09e7  lea r14, [rax+0x168]
000078af20bd09ee  mov r12, [r13+r14*1]
000078af20bd09f3  mov [r15+0x40], r12
000078af20bd09f7  lea r14, [rax+0x178]
000078af20bd09fe  xor eax, eax
000078af20bd0a00  mov [r13+r14*1], al
000078af20bd0a05  xor eax, eax
000078af20bd0a07  mov r14d, 0x38
000078af20bd0a0d  cmp r12, r14
000078af20bd0a10  cmc
000078af20bd0a11  lahf
000078af20bd0a12  seto al
000078af20bd0a15  mov [r15+0x108], eax
000078af20bd0a1c  mov eax, [r15+0x108]
000078af20bd0a23  sahf
000078af20bd0a24  jz 0x000078AF20BD0A56
000078af20bd0a26  cmp dword ptr [r15+0x318], 0x00
000078af20bd0a2e  jz 0x000078AF20BD0AA0
000078af20bd0a34  nop [rax+rax*1], ax
000078af20bd0a3d  nop [rax+rax*1], eax
000078af20bd0a45  mov eax, 0x4102B8
000078af20bd0a4a  mov [r15+0x100], rax
000078af20bd0a51  jmp 0x000078AF209FE110
000078af20bd0a56  cmp dword ptr [r15+0x318], 0x00
000078af20bd0a5e  jz 0x000078AF20BD0BF0
000078af20bd0a64  nop [rax+rax*1], ax
000078af20bd0a6d  nop [rax+rax*1], eax
000078af20bd0a75  mov eax, 0x4102D4
000078af20bd0a7a  mov [r15+0x100], rax
000078af20bd0a81  jmp 0x000078AF209FE110
000078af20bd0a86  int3
000078af20bd0a87  call 0x000078AF20AE27E0
000078af20bd0a8c  jmp 0x000078AF20BD09F3
000078af20bd0a91  call 0x000078AF20AD5AF0
000078af20bd0a96  jmp 0x000078AF20BD0A05
000078af20bd0a9b  int3
000078af20bd0a9c  nop [rax], eax
000078af20bd0aa0  mov rax, [r15+0xF8]
000078af20bd0aa7  lea r14, [rax+0x100]
000078af20bd0aae  mov [r15], r14
000078af20bd0ab1  lea r14, [rax+0x178]
000078af20bd0ab8  mov [r15+0x08], r14
000078af20bd0abc  mov qword ptr [r15+0x10], 0x01
000078af20bd0ac4  mov qword ptr [r15+0xF0], 0x4102C8
000078af20bd0acf  mov r14d, [r15+0x320]
000078af20bd0ad6  mov eax, 0x4102C8
000078af20bd0adb  mov rcx, 0x78AF20BD0B40
000078af20bd0ae5  mov [r15+r14*8+0x328], rax
000078af20bd0aed  mov [r15+r14*8+0x368], rcx
000078af20bd0af5  add r14d, 0x01
000078af20bd0af9  and r14d, 0x07
000078af20bd0afd  mov [r15+0x320], r14d
000078af20bd0b04  cmp dword ptr [r15+0x318], 0x00
000078af20bd0b0c  jz 0x000078AF20BCED70
000078af20bd0b12  nop [rax+rax*1], ax
000078af20bd0b1b  nop [rax+rax*1], eax
000078af20bd0b23  mov eax, 0x410728
000078af20bd0b28  mov [r15+0x100], rax
000078af20bd0b2f  jmp 0x000078AF209FE110
000078af20bd0b34  int3
000078af20bd0b35  int3
000078af20bd0b36  nop [rax+rax*1], ax
000078af20bd0b3f  nop
000078af20bd0b40  mov rax, [r15+0xF8]
000078af20bd0b47  lea r14, [rax+0x168]
000078af20bd0b4e  mov rax, [r13+r14*1]
000078af20bd0b53  mov [r15+0x40], rax
000078af20bd0b57  mov [rsp+0x10], rax
000078af20bd0b5c  xor eax, eax
000078af20bd0b5e  mov r14, [rsp+0x10]
000078af20bd0b63  mov r12d, 0x38
000078af20bd0b69  cmp r14, r12
000078af20bd0b6c  cmc
000078af20bd0b6d  lahf
000078af20bd0b6e  seto al
000078af20bd0b71  mov [r15+0x108], eax
000078af20bd0b78  mov eax, [r15+0x108]
000078af20bd0b7f  sahf
000078af20bd0b80  jnz 0x000078AF20BD0BB2
000078af20bd0b82  cmp dword ptr [r15+0x318], 0x00
000078af20bd0b8a  jz 0x000078AF20BD0BF0
000078af20bd0b90  nop [rax+rax*1], ax
000078af20bd0b99  nop [rax+rax*1], eax
000078af20bd0ba1  mov eax, 0x4102D4
000078af20bd0ba6  mov [r15+0x100], rax
000078af20bd0bad  jmp 0x000078AF209FE110
000078af20bd0bb2  cmp dword ptr [r15+0x318], 0x00
000078af20bd0bba  jz 0x000078AF20BD0AA0
000078af20bd0bc0  nop [rax+rax*1], ax
000078af20bd0bc9  nop [rax+rax*1], eax
000078af20bd0bd1  mov eax, 0x4102B8
000078af20bd0bd6  mov [r15+0x100], rax
000078af20bd0bdd  jmp 0x000078AF209FE110
000078af20bd0be2  int3
000078af20bd0be3  call 0x000078AF20AD59C0
000078af20bd0be8  jmp 0x000078AF20BD0B53
000078af20bd0bed  int3
000078af20bd0bee  nop
000078af20bd0bf0  mov rax, [r15+0x98]
000078af20bd0bf7  rorx r14, rax, 0x3D
000078af20bd0bfd  and r14, 0xFFFFFFFFFFFFFFF8
000078af20bd0c01  mov rax, [r15+0xF8]
000078af20bd0c08  lea r12, [rax+0x100]
000078af20bd0c0f  mov [r15], r12
000078af20bd0c12  lea r12, [rax+0x170]
000078af20bd0c19  mov [r15+0x08], r12
000078af20bd0c1d  mov qword ptr [r15+0x10], 0x08
000078af20bd0c25  bswap r14
000078af20bd0c28  mov [r15+0x40], r14
000078af20bd0c2c  lea r12, [rax+0x170]
000078af20bd0c33  mov [r13+r12*1], r14
000078af20bd0c38  mov qword ptr [r15+0xF0], 0x4102F0
000078af20bd0c43  mov r14d, [r15+0x320]
000078af20bd0c4a  mov eax, 0x4102F0
000078af20bd0c4f  mov rcx, 0x78AF20BD0CC0
000078af20bd0c59  mov [r15+r14*8+0x328], rax
000078af20bd0c61  mov [r15+r14*8+0x368], rcx
000078af20bd0c69  add r14d, 0x01
000078af20bd0c6d  and r14d, 0x07
000078af20bd0c71  mov [r15+0x320], r14d
000078af20bd0c78  cmp dword ptr [r15+0x318], 0x00
000078af20bd0c80  jz 0x000078AF20BCED70
000078af20bd0c86  nop [rax+rax*1], ax
000078af20bd0c8f  nop [rax+rax*1], eax
000078af20bd0c97  mov eax, 0x410728
000078af20bd0c9c  mov [r15+0x100], rax
000078af20bd0ca3  jmp 0x000078AF209FE110
000078af20bd0ca8  int3
000078af20bd0ca9  call 0x000078AF20AC3FE0
000078af20bd0cae  jmp 0x000078AF20BD0C38
000078af20bd0cb3  int3
000078af20bd0cb4  nop [rax+rax*1], ax
000078af20bd0cbd  nop [rax], eax
000078af20bd0cc0  mov rax, [r15+0xF8]
000078af20bd0cc7  lea r14, [rax+0x100]
000078af20bd0cce  mov r12d, [r13+r14*1]
000078af20bd0cd3  lea r14, [rax+0x104]
000078af20bd0cda  mov r11d, [r13+r14*1]
000078af20bd0cdf  mov qword ptr [r15+0x48], 0x430C90
000078af20bd0ce7  lea r14, [rax+0x108]
000078af20bd0cee  mov r10d, [r13+r14*1]
000078af20bd0cf3  lea r14, [rax+0x10C]
000078af20bd0cfa  mov r9d, [r13+r14*1]
000078af20bd0cff  bswap r12d
000078af20bd0d02  bswap r11d
000078af20bd0d05  mov qword ptr [r15+0xA0], 0x00
000078af20bd0d10  mov r14d, 0x430C90
000078af20bd0d16  mov [r13+r14*1], r12d
000078af20bd0d1b  mov r14d, 0x430C94
000078af20bd0d21  mov [r13+r14*1], r11d
000078af20bd0d26  bswap r10d
000078af20bd0d29  lea r14, [rax+0x110]
000078af20bd0d30  mov r12d, [r13+r14*1]
000078af20bd0d35  bswap r9d
000078af20bd0d38  lea r14, [rax+0x114]
000078af20bd0d3f  mov r11d, [r13+r14*1]
000078af20bd0d44  mov qword ptr [r15+0x98], 0x430DFC
000078af20bd0d4f  mov r14d, 0x430C98
000078af20bd0d55  mov [r13+r14*1], r10d
000078af20bd0d5a  mov r14d, 0x430C9C
000078af20bd0d60  mov [r13+r14*1], r9d
000078af20bd0d65  bswap r12d
000078af20bd0d68  lea r14, [rax+0x118]
000078af20bd0d6f  mov r10d, [r13+r14*1]
000078af20bd0d74  bswap r11d
000078af20bd0d77  mov [rsp+0x10], r11d
000078af20bd0d7c  mov r11d, r11d
000078af20bd0d7f  mov [r15+0x58], r11
000078af20bd0d83  lea r14, [rax+0x11C]
000078af20bd0d8a  mov eax, [r13+r14*1]
000078af20bd0d8f  mov [rsp+0x20], eax
000078af20bd0d93  mov eax, eax
000078af20bd0d95  mov [r15+0x60], rax
000078af20bd0d99  mov eax, 0x430CA0
000078af20bd0d9e  mov [r13+rax*1], r12d
000078af20bd0da3  mov eax, 0x430CA4
000078af20bd0da8  mov r14d, [rsp+0x10]
000078af20bd0dad  mov [r13+rax*1], r14d
000078af20bd0db2  bswap r10d
000078af20bd0db5  mov [rsp+0x10], r10d
000078af20bd0dba  mov r10d, r10d
000078af20bd0dbd  mov [r15+0x40], r10
000078af20bd0dc1  mov eax, [rsp+0x20]
000078af20bd0dc5  bswap eax
000078af20bd0dc7  mov [rsp+0x20], eax
000078af20bd0dcb  mov eax, eax
000078af20bd0dcd  mov [r15+0x50], rax
000078af20bd0dd1  mov eax, 0x430CA8
000078af20bd0dd6  mov r14d, [rsp+0x10]
000078af20bd0ddb  mov [r13+rax*1], r14d
000078af20bd0de0  mov eax, 0x430CAC
000078af20bd0de5  mov r14d, [rsp+0x20]
000078af20bd0dea  mov [r13+rax*1], r14d
000078af20bd0def  mov eax, [r15+0xA0]
000078af20bd0df6  lea r14d, [eax+0x11]
000078af20bd0dfb  mov r14d, r14d
000078af20bd0dfe  mov [r15], r14
000078af20bd0e01  mov qword ptr [r15+0xF0], 0x41035C
000078af20bd0e0c  mov r14d, [r15+0x320]
000078af20bd0e13  mov eax, 0x41035C
000078af20bd0e18  mov rcx, 0x78AF20BD0F90
000078af20bd0e22  mov [r15+r14*8+0x328], rax
000078af20bd0e2a  mov [r15+r14*8+0x368], rcx
000078af20bd0e32  add r14d, 0x01
000078af20bd0e36  and r14d, 0x07
000078af20bd0e3a  mov [r15+0x320], r14d
000078af20bd0e41  cmp dword ptr [r15+0x318], 0x00
000078af20bd0e49  jz 0x000078AF20BD0F20
000078af20bd0e4f  nop [rax+rax*1], ax
000078af20bd0e58  nop [rax+rax*1], eax
000078af20bd0e60  mov eax, 0x4109A4
000078af20bd0e65  mov [r15+0x100], rax
000078af20bd0e6c  jmp 0x000078AF209FE110
000078af20bd0e71  int3
000078af20bd0e72  call 0x000078AF20AE26A0
000078af20bd0e77  jmp 0x000078AF20BD0CD3
000078af20bd0e7c  call 0x000078AF20AE1430
000078af20bd0e81  jmp 0x000078AF20BD0CDF
000078af20bd0e86  call 0x000078AF20AE01C0
000078af20bd0e8b  jmp 0x000078AF20BD0CF3
000078af20bd0e90  call 0x000078AF20ADEF50
000078af20bd0e95  jmp 0x000078AF20BD0CFF
000078af20bd0e9a  call 0x000078AF20AE2BA0
000078af20bd0e9f  jmp 0x000078AF20BD0D1B
000078af20bd0ea4  call 0x000078AF20AE1920
000078af20bd0ea9  jmp 0x000078AF20BD0D26
000078af20bd0eae  call 0x000078AF20AE26A0
000078af20bd0eb3  jmp 0x000078AF20BD0D35
000078af20bd0eb8  call 0x000078AF20AE1430
000078af20bd0ebd  jmp 0x000078AF20BD0D44
000078af20bd0ec2  call 0x000078AF20AE06B0
000078af20bd0ec7  jmp 0x000078AF20BD0D5A
000078af20bd0ecc  call 0x000078AF20ADF440
000078af20bd0ed1  jmp 0x000078AF20BD0D65
000078af20bd0ed6  call 0x000078AF20AE01C0
000078af20bd0edb  jmp 0x000078AF20BD0D74
000078af20bd0ee0  call 0x000078AF20AD5890
000078af20bd0ee5  jmp 0x000078AF20BD0D8F
000078af20bd0eea  call 0x000078AF20A0BAE0
000078af20bd0eef  jmp 0x000078AF20BD0DA3
000078af20bd0ef4  call 0x000078AF20A0DFE0
000078af20bd0ef9  jmp 0x000078AF20BD0DB2
000078af20bd0efe  call 0x000078AF20A0DFE0
000078af20bd0f03  jmp 0x000078AF20BD0DE0
000078af20bd0f08  call 0x000078AF20A0DFE0
000078af20bd0f0d  jmp 0x000078AF20BD0DEF
000078af20bd0f12  int3
000078af20bd0f13  nop [rax+rax*1], ax
000078af20bd0f1c  nop [rax], eax
000078af20bd0f20  mov eax, [r15]
000078af20bd0f23  mov [rsp+0x10], eax
000078af20bd0f27  shr eax, 0x10
000078af20bd0f2a  mov r14d, [rsp+0x10]
000078af20bd0f2f  xor r14d, eax
000078af20bd0f32  imul r14d, r14d, 0x7FEB352D
000078af20bd0f39  mov eax, 0x846CA68B
000078af20bd0f3e  mov eax, eax
000078af20bd0f40  mov [r15+0x48], rax
000078af20bd0f44  mov [rsp+0x10], r14d
000078af20bd0f49  shr r14d, 0x0F
000078af20bd0f4d  mov eax, [rsp+0x10]
000078af20bd0f51  xor eax, r14d
000078af20bd0f54  imul eax, eax, 0x846CA68B
000078af20bd0f5a  mov [rsp+0x10], eax
000078af20bd0f5e  mov eax, eax
000078af20bd0f60  mov [r15+0x40], rax
000078af20bd0f64  mov eax, [rsp+0x10]
000078af20bd0f68  shr eax, 0x10
000078af20bd0f6b  mov r14d, [rsp+0x10]
000078af20bd0f70  xor r14d, eax
000078af20bd0f73  mov r14d, r14d
000078af20bd0f76  mov [r15], r14
000078af20bd0f79  mov rax, [r15+0xF0]
000078af20bd0f80  mov [r15+0x100], rax
000078af20bd0f87  jmp 0x000078AF20BCE5C0
000078af20bd0f8c  int3
000078af20bd0f8d  int3
000078af20bd0f8e  nop
000078af20bd0f90  mov rax, [r15+0xA0]
000078af20bd0f97  mov [rsp+0x10], rax
000078af20bd0f9c  shl rax, 0x02
000078af20bd0fa0  mov r14, [r15+0x98]
000078af20bd0fa7  lea r12, [r14+rax*1]
000078af20bd0fab  mov eax, [r15]
000078af20bd0fae  mov [r13+r12*1], eax
000078af20bd0fb3  mov rax, [rsp+0x10]
000078af20bd0fb8  lea r14, [rax+0x01]
000078af20bd0fbc  mov [r15+0xA0], r14
000078af20bd0fc3  xor eax, eax
000078af20bd0fc5  mov r12d, 0x400
000078af20bd0fcb  cmp r14, r12
000078af20bd0fce  cmc
000078af20bd0fcf  lahf
000078af20bd0fd0  seto al
000078af20bd0fd3  mov [r15+0x108], eax
000078af20bd0fda  mov eax, [r15+0x108]
000078af20bd0fe1  sahf
000078af20bd0fe2  jnz 0x000078AF20BD1014
000078af20bd0fe4  cmp dword ptr [r15+0x318], 0x00
000078af20bd0fec  jz 0x000078AF20BD10E0
000078af20bd0ff2  nop [rax+rax*1], ax
000078af20bd0ffb  nop [rax+rax*1], eax
000078af20bd1003  mov eax, 0x41036C
000078af20bd1008  mov [r15+0x100], rax
000078af20bd100f  jmp 0x000078AF209FE110
000078af20bd1014  cmp dword ptr [r15+0x318], 0x00
000078af20bd101c  jz 0x000078AF20BD1050
000078af20bd1022  nop [rax+rax*1], ax
000078af20bd102b  nop [rax+rax*1], eax
000078af20bd1033  mov eax, 0x410354
000078af20bd1038  mov [r15+0x100], rax
000078af20bd103f  jmp 0x000078AF209FE110
000078af20bd1044  int3
000078af20bd1045  call 0x000078AF20AB4B70
000078af20bd104a  jmp 0x000078AF20BD0FB3
000078af20bd104f  int3
000078af20bd1050  mov eax, [r15+0xA0]
000078af20bd1057  lea r14d, [eax+0x11]
000078af20bd105c  mov r14d, r14d
000078af20bd105f  mov [r15], r14
000078af20bd1062  mov qword ptr [r15+0xF0], 0x41035C
000078af20bd106d  mov r14d, [r15+0x320]
000078af20bd1074  mov eax, 0x41035C
000078af20bd1079  mov rcx, 0x78AF20BD0F90
000078af20bd1083  mov [r15+r14*8+0x328], rax
000078af20bd108b  mov [r15+r14*8+0x368], rcx
000078af20bd1093  add r14d, 0x01
000078af20bd1097  and r14d, 0x07
000078af20bd109b  mov [r15+0x320], r14d
000078af20bd10a2  cmp dword ptr [r15+0x318], 0x00
000078af20bd10aa  jz 0x000078AF20BD0F20
000078af20bd10b0  nop [rax+rax*1], ax
000078af20bd10b9  nop [rax+rax*1], eax
000078af20bd10c1  mov eax, 0x4109A4
000078af20bd10c6  mov [r15+0x100], rax
000078af20bd10cd  jmp 0x000078AF209FE110
000078af20bd10d2  int3
000078af20bd10d3  int3
000078af20bd10d4  nop [rax+rax*1], ax
000078af20bd10dd  nop [rax], eax
000078af20bd10e0  mov qword ptr [r15+0x40], 0x01
000078af20bd10e8  cmp dword ptr [r15+0x318], 0x00
000078af20bd10f0  jz 0x000078AF20BD1120
000078af20bd10f6  nop [rax+rax*1], ax
000078af20bd10ff  nop [rax+rax*1], eax
000078af20bd1107  mov eax, 0x410388
000078af20bd110c  mov [r15+0x100], rax
000078af20bd1113  jmp 0x000078AF209FE110
000078af20bd1118  int3
000078af20bd1119  int3
000078af20bd111a  nop [rax+rax*1], ax
000078af20bd1120  mov rax, [r15+0x40]
000078af20bd1124  mov [rsp+0x10], rax
000078af20bd1129  shl rax, 0x02
000078af20bd112d  mov r14, [r15+0x98]
000078af20bd1134  lea r12, [r14+rax*1]
000078af20bd1138  mov eax, [r13+r12*1]
000078af20bd113d  mov [rsp+0x20], eax
000078af20bd1141  mov eax, eax
000078af20bd1143  mov [r15+0x48], rax
000078af20bd1147  mov rax, [rsp+0x10]
000078af20bd114c  mov [r15+0x50], rax
000078af20bd1150  mov eax, [r15+0x50]
000078af20bd1154  lea r12d, [eax-0x01]
000078af20bd1159  mov r12d, r12d
000078af20bd115c  mov [r15+0x58], r12
000078af20bd1160  mov rax, [r15+0x58]
000078af20bd1164  mov r12d, eax
000078af20bd1167  mov r12d, r12d
000078af20bd116a  shl r12, 0x02
000078af20bd116e  lea rax, [r14+r12*1]
000078af20bd1172  mov r14d, [r13+rax*1]
000078af20bd1177  mov [rsp+0x10], r14d
000078af20bd117c  mov r14d, r14d
000078af20bd117f  mov [r15+0x60], r14
000078af20bd1183  xor eax, eax
000078af20bd1185  mov r14d, [rsp+0x10]
000078af20bd118a  mov r12d, [rsp+0x20]
000078af20bd118f  cmp r14d, r12d
000078af20bd1192  cmc
000078af20bd1193  lahf
000078af20bd1194  seto al
000078af20bd1197  mov [r15+0x108], eax
000078af20bd119e  mov eax, [r15+0x108]
000078af20bd11a5  sahf
000078af20bd11a6  cmc
000078af20bd11a7  jbe 0x000078AF20BD11D9
000078af20bd11a9  cmp dword ptr [r15+0x318], 0x00
000078af20bd11b1  jz 0x000078AF20BD1220
000078af20bd11b7  nop [rax+rax*1], ax
000078af20bd11c0  nop [rax+rax*1], eax
000078af20bd11c8  mov eax, 0x4103A0
000078af20bd11cd  mov [r15+0x100], rax
000078af20bd11d4  jmp 0x000078AF209FE110
000078af20bd11d9  cmp dword ptr [r15+0x318], 0x00
000078af20bd11e1  jz 0x000078AF20BD14C0
000078af20bd11e7  nop [rax+rax*1], ax
000078af20bd11f0  nop [rax+rax*1], eax
000078af20bd11f8  mov eax, 0x410378
000078af20bd11fd  mov [r15+0x100], rax
000078af20bd1204  jmp 0x000078AF209FE110
000078af20bd1209  int3
000078af20bd120a  call 0x000078AF20AB4690
000078af20bd120f  jmp 0x000078AF20BD113D
000078af20bd1214  call 0x000078AF20A0DAE0
000078af20bd1219  jmp 0x000078AF20BD1177
000078af20bd121e  int3
000078af20bd121f  nop
000078af20bd1220  mov rax, [r15+0x50]
000078af20bd1224  mov [rsp+0x10], rax
000078af20bd1229  shl rax, 0x02
000078af20bd122d  mov r14, [r15+0x98]
000078af20bd1234  lea r12, [r14+rax*1]
000078af20bd1238  mov eax, [r15+0x60]
000078af20bd123c  mov [r13+r12*1], eax
000078af20bd1241  mov rax, [rsp+0x10]
000078af20bd1246  lea r14, [rax-0x01]
000078af20bd124a  mov [r15+0x50], r14
000078af20bd124e  mov rax, [r15+0x58]
000078af20bd1252  test rax, rax
000078af20bd1255  setz al
000078af20bd1258  movzx rax, al
000078af20bd125c  mov [rsp+0x414], al
000078af20bd1263  cmp byte ptr [rsp+0x414], 0x00
000078af20bd126b  jz 0x000078AF20BD129D
000078af20bd126d  cmp dword ptr [r15+0x318], 0x00
000078af20bd1275  jz 0x000078AF20BD12E0
000078af20bd127b  nop [rax+rax*1], ax
000078af20bd1284  nop [rax+rax*1], eax
000078af20bd128c  mov eax, 0x4103AC
000078af20bd1291  mov [r15+0x100], rax
000078af20bd1298  jmp 0x000078AF209FE110
000078af20bd129d  cmp dword ptr [r15+0x318], 0x00
000078af20bd12a5  jz 0x000078AF20BD13E0
000078af20bd12ab  nop [rax+rax*1], ax
000078af20bd12b4  nop [rax+rax*1], eax
000078af20bd12bc  mov eax, 0x410390
000078af20bd12c1  mov [r15+0x100], rax
000078af20bd12c8  jmp 0x000078AF209FE110
000078af20bd12cd  int3
000078af20bd12ce  call 0x000078AF20AB4B70
000078af20bd12d3  jmp 0x000078AF20BD1241
000078af20bd12d8  int3
000078af20bd12d9  nop [rax], eax
000078af20bd12e0  cmp dword ptr [r15+0x318], 0x00
000078af20bd12e8  jz 0x000078AF20BD1320
000078af20bd12ee  nop [rax+rax*1], ax
000078af20bd12f7  nop [rax+rax*1], eax
000078af20bd12ff  mov eax, 0x410374
000078af20bd1304  mov [r15+0x100], rax
000078af20bd130b  jmp 0x000078AF209FE110
000078af20bd1310  int3
000078af20bd1311  int3
000078af20bd1312  nop [rax+rax*1], ax
000078af20bd131b  nop [rax+rax*1], eax
000078af20bd1320  mov qword ptr [r15+0x50], 0x00
000078af20bd1328  mov rax, [r15+0x40]
000078af20bd132c  lea r14, [rax+0x01]
000078af20bd1330  mov [r15+0x40], r14
000078af20bd1334  mov rax, [r15+0x98]
000078af20bd133b  mov r12d, [r15+0x48]
000078af20bd133f  mov [r13+rax*1], r12d
000078af20bd1344  xor eax, eax
000078af20bd1346  mov r12d, 0x400
000078af20bd134c  cmp r14, r12
000078af20bd134f  cmc
000078af20bd1350  lahf
000078af20bd1351  seto al
000078af20bd1354  mov [r15+0x108], eax
000078af20bd135b  mov eax, [r15+0x108]
000078af20bd1362  sahf
000078af20bd1363  jz 0x000078AF20BD1395
000078af20bd1365  cmp dword ptr [r15+0x318], 0x00
000078af20bd136d  jz 0x000078AF20BD1120
000078af20bd1373  nop [rax+rax*1], ax
000078af20bd137c  nop [rax+rax*1], eax
000078af20bd1384  mov eax, 0x410388
000078af20bd1389  mov [r15+0x100], rax
000078af20bd1390  jmp 0x000078AF209FE110
000078af20bd1395  cmp dword ptr [r15+0x318], 0x00
000078af20bd139d  jz 0x000078AF20BD1580
000078af20bd13a3  nop [rax+rax*1], ax
000078af20bd13ac  nop [rax+rax*1], eax
000078af20bd13b4  mov eax, 0x4103B0
000078af20bd13b9  mov [r15+0x100], rax
000078af20bd13c0  jmp 0x000078AF209FE110
000078af20bd13c5  int3
000078af20bd13c6  call 0x000078AF20A0BAE0
000078af20bd13cb  jmp 0x000078AF20BD1344
000078af20bd13d0  int3
000078af20bd13d1  nop [rax+rax*1], ax
000078af20bd13da  nop [rax+rax*1], ax
000078af20bd13e0  mov eax, [r15+0x50]
000078af20bd13e4  lea r14d, [eax-0x01]
000078af20bd13e9  mov r14d, r14d
000078af20bd13ec  mov [r15+0x58], r14
000078af20bd13f0  mov rax, [r15+0x58]
000078af20bd13f4  mov r14d, eax
000078af20bd13f7  mov r14d, r14d
000078af20bd13fa  shl r14, 0x02
000078af20bd13fe  mov rax, [r15+0x98]
000078af20bd1405  lea r12, [rax+r14*1]
000078af20bd1409  mov eax, [r13+r12*1]
000078af20bd140e  mov [rsp+0x10], eax
000078af20bd1412  mov eax, eax
000078af20bd1414  mov [r15+0x60], rax
000078af20bd1418  mov eax, [r15+0x48]
000078af20bd141c  mov [rsp+0x20], eax
000078af20bd1420  xor eax, eax
000078af20bd1422  mov r14d, [rsp+0x10]
000078af20bd1427  mov r12d, [rsp+0x20]
000078af20bd142c  cmp r14d, r12d
000078af20bd142f  cmc
000078af20bd1430  lahf
000078af20bd1431  seto al
000078af20bd1434  mov [r15+0x108], eax
000078af20bd143b  mov eax, [r15+0x108]
000078af20bd1442  sahf
000078af20bd1443  cmc
000078af20bd1444  jbe 0x000078AF20BD1476
000078af20bd1446  cmp dword ptr [r15+0x318], 0x00
000078af20bd144e  jz 0x000078AF20BD1220
000078af20bd1454  nop [rax+rax*1], ax
000078af20bd145d  nop [rax+rax*1], eax
000078af20bd1465  mov eax, 0x4103A0
000078af20bd146a  mov [r15+0x100], rax
000078af20bd1471  jmp 0x000078AF209FE110
000078af20bd1476  cmp dword ptr [r15+0x318], 0x00
000078af20bd147e  jz 0x000078AF20BD14C0
000078af20bd1484  nop [rax+rax*1], ax
000078af20bd148d  nop [rax+rax*1], eax
000078af20bd1495  mov eax, 0x410378
000078af20bd149a  mov [r15+0x100], rax
000078af20bd14a1  jmp 0x000078AF209FE110
000078af20bd14a6  int3
000078af20bd14a7  call 0x000078AF20AB4690
000078af20bd14ac  jmp 0x000078AF20BD140E
000078af20bd14b1  int3
000078af20bd14b2  nop [rax+rax*1], ax
000078af20bd14bb  nop [rax+rax*1], eax
000078af20bd14c0  mov rax, [r15+0x40]
000078af20bd14c4  lea r14, [rax+0x01]
000078af20bd14c8  mov [r15+0x40], r14
000078af20bd14cc  mov rax, [r15+0x50]
000078af20bd14d0  mov r12d, eax
000078af20bd14d3  mov r12d, r12d
000078af20bd14d6  shl r12, 0x02
000078af20bd14da  mov rax, [r15+0x98]
000078af20bd14e1  lea r11, [rax+r12*1]
000078af20bd14e5  mov eax, [r15+0x48]
000078af20bd14e9  mov [r13+r11*1], eax
000078af20bd14ee  xor eax, eax
000078af20bd14f0  mov r12d, 0x400
000078af20bd14f6  cmp r14, r12
000078af20bd14f9  cmc
000078af20bd14fa  lahf
000078af20bd14fb  seto al
000078af20bd14fe  mov [r15+0x108], eax
000078af20bd1505  mov eax, [r15+0x108]
000078af20bd150c  sahf
000078af20bd150d  jz 0x000078AF20BD153F
000078af20bd150f  cmp dword ptr [r15+0x318], 0x00
000078af20bd1517  jz 0x000078AF20BD1120
000078af20bd151d  nop [rax+rax*1], ax
000078af20bd1526  nop [rax+rax*1], eax
000078af20bd152e  mov eax, 0x410388
000078af20bd1533  mov [r15+0x100], rax
000078af20bd153a  jmp 0x000078AF209FE110
000078af20bd153f  cmp dword ptr [r15+0x318], 0x00
000078af20bd1547  jz 0x000078AF20BD1580
000078af20bd154d  nop [rax+rax*1], ax
000078af20bd1556  nop [rax+rax*1], eax
000078af20bd155e  mov eax, 0x4103B0
000078af20bd1563  mov [r15+0x100], rax
000078af20bd156a  jmp 0x000078AF209FE110
000078af20bd156f  int3
000078af20bd1570  call 0x000078AF20AA4270
000078af20bd1575  jmp 0x000078AF20BD14EE
000078af20bd157a  int3
000078af20bd157b  nop [rax+rax*1], eax
000078af20bd1580  mov qword ptr [r15+0x40], 0x430000
000078af20bd1588  mov eax, 0x430CB0
000078af20bd158d  mov r14, [r13+rax*1]
000078af20bd1592  mov rax, [r15+0x98]
000078af20bd1599  mov r12d, [r13+rax*1]
000078af20bd159e  lea r11, [rax+0x04]
000078af20bd15a2  mov eax, [r13+r11*1]
000078af20bd15a7  mov r12d, r12d
000078af20bd15aa  mov [r15+0x68], r12
000078af20bd15ae  mov eax, eax
000078af20bd15b0  mov [r15+0x60], rax
000078af20bd15b4  mov rax, [r15+0x68]
000078af20bd15b8  mov [r15+0x68], rax
000078af20bd15bc  mov qword ptr [r15+0x58], 0x02
000078af20bd15c4  mov [rsp+0x10], rax
000078af20bd15c9  xor eax, eax
000078af20bd15cb  mov r12d, 0x02
000078af20bd15d1  mov r11d, 0x400
000078af20bd15d7  cmp r12, r11
000078af20bd15da  cmc
000078af20bd15db  lahf
000078af20bd15dc  seto al
000078af20bd15df  mov [r15+0x108], eax
000078af20bd15e6  mov rax, [r15+0x60]
000078af20bd15ea  mov r12d, 0x02
000078af20bd15f0  imul rax, r12
000078af20bd15f4  mov [r15+0x50], rax
000078af20bd15f8  mov rax, [rsp+0x10]
000078af20bd15fd  lea r12, [rax+r14*1]
000078af20bd1601  mov [r15+0x48], r12
000078af20bd1605  mov eax, [r15+0x108]
000078af20bd160c  sahf
000078af20bd160d  jnz 0x000078AF20BD163F
000078af20bd160f  cmp dword ptr [r15+0x318], 0x00
000078af20bd1617  jz 0x000078AF20BD17B0
000078af20bd161d  nop [rax+rax*1], ax
000078af20bd1626  nop [rax+rax*1], eax
000078af20bd162e  mov eax, 0x4103E0
000078af20bd1633  mov [r15+0x100], rax
000078af20bd163a  jmp 0x000078AF209FE110
000078af20bd163f  cmp dword ptr [r15+0x318], 0x00
000078af20bd1647  jz 0x000078AF20BD1690
000078af20bd164d  nop [rax+rax*1], ax
000078af20bd1656  nop [rax+rax*1], eax
000078af20bd165e  mov eax, 0x4103C0
000078af20bd1663  mov [r15+0x100], rax
000078af20bd166a  jmp 0x000078AF209FE110
000078af20bd166f  int3
000078af20bd1670  call 0x000078AF20A0DC20
000078af20bd1675  jmp 0x000078AF20BD1592
000078af20bd167a  call 0x000078AF20A0B5E0
000078af20bd167f  jmp 0x000078AF20BD159E
000078af20bd1684  call 0x000078AF20AA3D90
000078af20bd1689  jmp 0x000078AF20BD15A7
000078af20bd168e  int3
000078af20bd168f  nop
000078af20bd1690  mov rax, [r15+0x98]
000078af20bd1697  mov r14, [r15+0x58]
000078af20bd169b  mov [rsp+0x10], r14
000078af20bd16a0  shl r14, 0x02
000078af20bd16a4  lea r12, [rax+r14*1]
000078af20bd16a8  mov eax, [r13+r12*1]
000078af20bd16ad  lea r14, [r12+0x04]
000078af20bd16b2  mov r12d, [r13+r14*1]
000078af20bd16b7  mov eax, eax
000078af20bd16b9  mov [r15+0x68], rax
000078af20bd16bd  mov r12d, r12d
000078af20bd16c0  mov [r15+0x60], r12
000078af20bd16c4  mov rax, [r15+0x68]
000078af20bd16c8  mov [rsp+0x20], rax
000078af20bd16cd  mov r14, [rsp+0x10]
000078af20bd16d2  imul rax, r14
000078af20bd16d6  mov r12, [rsp+0x20]
000078af20bd16db  lea r11, [r12+rax*1]
000078af20bd16df  mov [r15+0x68], r11
000078af20bd16e3  lea rax, [r14+0x02]
000078af20bd16e7  mov [r15+0x58], rax
000078af20bd16eb  mov [rsp+0x10], rax
000078af20bd16f0  xor eax, eax
000078af20bd16f2  mov r14, [rsp+0x10]
000078af20bd16f7  mov r12d, 0x400
000078af20bd16fd  cmp r14, r12
000078af20bd1700  cmc
000078af20bd1701  lahf
000078af20bd1702  seto al
000078af20bd1705  mov [r15+0x108], eax
000078af20bd170c  mov rax, [r15+0x50]
000078af20bd1710  mov r12, [r15+0x60]
000078af20bd1714  imul r14, r12
000078af20bd1718  lea r12, [rax+r14*1]
000078af20bd171c  mov [r15+0x50], r12
000078af20bd1720  mov rax, [r15+0x48]
000078af20bd1724  lea r14, [r11+rax*1]
000078af20bd1728  mov [r15+0x48], r14
000078af20bd172c  mov eax, [r15+0x108]
000078af20bd1733  sahf
000078af20bd1734  jnz 0x000078AF20BD1766
000078af20bd1736  cmp dword ptr [r15+0x318], 0x00
000078af20bd173e  jz 0x000078AF20BD17B0
000078af20bd1744  nop [rax+rax*1], ax
000078af20bd174d  nop [rax+rax*1], eax
000078af20bd1755  mov eax, 0x4103E0
000078af20bd175a  mov [r15+0x100], rax
000078af20bd1761  jmp 0x000078AF209FE110
000078af20bd1766  cmp dword ptr [r15+0x318], 0x00
000078af20bd176e  jz 0x000078AF20BD1690
000078af20bd1774  nop [rax+rax*1], ax
000078af20bd177d  nop [rax+rax*1], eax
000078af20bd1785  mov eax, 0x4103C0
000078af20bd178a  mov [r15+0x100], rax
000078af20bd1791  jmp 0x000078AF209FE110
000078af20bd1796  int3
000078af20bd1797  call 0x000078AF20AB4690
000078af20bd179c  jmp 0x000078AF20BD16AD
000078af20bd17a1  call 0x000078AF20AE26A0
000078af20bd17a6  jmp 0x000078AF20BD16B7
000078af20bd17ab  int3
000078af20bd17ac  nop [rax], eax
000078af20bd17b0  mov qword ptr [r15+0x98], 0x00
000078af20bd17bb  mov rax, [r15+0x50]
000078af20bd17bf  mov r14, [r15+0x48]
000078af20bd17c3  lea r12, [rax+r14*1]
000078af20bd17c7  mov [r15+0x48], r12
000078af20bd17cb  mov rax, [r15+0x40]
000078af20bd17cf  lea r14, [rax+0xCB0]
000078af20bd17d6  mov [r13+r14*1], r12
000078af20bd17db  mov qword ptr [r15], 0x01
000078af20bd17e2  mov qword ptr [r15+0xF0], 0x4103F8
000078af20bd17ed  mov r14d, [r15+0x320]
000078af20bd17f4  mov eax, 0x4103F8
000078af20bd17f9  mov rcx, 0x78AF20BD1860
000078af20bd1803  mov [r15+r14*8+0x328], rax
000078af20bd180b  mov [r15+r14*8+0x368], rcx
000078af20bd1813  add r14d, 0x01
000078af20bd1817  and r14d, 0x07
000078af20bd181b  mov [r15+0x320], r14d
000078af20bd1822  cmp dword ptr [r15+0x318], 0x00
000078af20bd182a  jz 0x000078AF20BD0F20
000078af20bd1830  nop [rax+rax*1], ax
000078af20bd1839  nop [rax+rax*1], eax
000078af20bd1841  mov eax, 0x4109A4
000078af20bd1846  mov [r15+0x100], rax
000078af20bd184d  jmp 0x000078AF209FE110
000078af20bd1852  int3
000078af20bd1853  call 0x000078AF20AE2CE0
000078af20bd1858  jmp 0x000078AF20BD17DB
000078af20bd185d  int3
000078af20bd185e  nop
000078af20bd1860  mov eax, [r15+0x98]
000078af20bd1867  lea r14d, [eax+0x01]
000078af20bd186c  mov [rsp+0x10], r14d
000078af20bd1871  mov r14d, r14d
000078af20bd1874  mov [r15+0x98], r14
000078af20bd187b  xor eax, eax
000078af20bd187d  mov r14d, [rsp+0x10]
000078af20bd1882  cmp r14d, 0x10000
000078af20bd1889  cmc
000078af20bd188a  lahf
000078af20bd188b  seto al
000078af20bd188e  mov [r15+0x108], eax
000078af20bd1895  mov eax, [r15+0x108]
000078af20bd189c  sahf
000078af20bd189d  jnz 0x000078AF20BD18CF
000078af20bd189f  cmp dword ptr [r15+0x318], 0x00
000078af20bd18a7  jz 0x000078AF20BD19A0
000078af20bd18ad  nop [rax+rax*1], ax
000078af20bd18b6  nop [rax+rax*1], eax
000078af20bd18be  mov eax, 0x410404
000078af20bd18c3  mov [r15+0x100], rax
000078af20bd18ca  jmp 0x000078AF209FE110
000078af20bd18cf  cmp dword ptr [r15+0x318], 0x00
000078af20bd18d7  jz 0x000078AF20BD1910
000078af20bd18dd  nop [rax+rax*1], ax
000078af20bd18e6  nop [rax+rax*1], eax
000078af20bd18ee  mov eax, 0x4103F0
000078af20bd18f3  mov [r15+0x100], rax
000078af20bd18fa  jmp 0x000078AF209FE110
000078af20bd18ff  int3
000078af20bd1900  int3
000078af20bd1901  nop [rax+rax*1], ax
000078af20bd190a  nop [rax+rax*1], ax
000078af20bd1910  mov eax, [r15]
000078af20bd1913  mov r14d, [r15+0x98]
000078af20bd191a  lea r12d, [eax+r14d*1]
000078af20bd191f  mov r12d, r12d
000078af20bd1922  mov [r15], r12
000078af20bd1925  mov qword ptr [r15+0xF0], 0x4103F8
000078af20bd1930  mov r14d, [r15+0x320]
000078af20bd1937  mov eax, 0x4103F8
000078af20bd193c  mov rcx, 0x78AF20BD1860
000078af20bd1946  mov [r15+r14*8+0x328], rax
000078af20bd194e  mov [r15+r14*8+0x368], rcx
000078af20bd1956  add r14d, 0x01
000078af20bd195a  and r14d, 0x07
000078af20bd195e  mov [r15+0x320], r14d
000078af20bd1965  cmp dword ptr [r15+0x318], 0x00
000078af20bd196d  jz 0x000078AF20BD0F20
000078af20bd1973  nop [rax+rax*1], ax
000078af20bd197c  nop [rax+rax*1], eax
000078af20bd1984  mov eax, 0x4109A4
000078af20bd1989  mov [r15+0x100], rax
000078af20bd1990  jmp 0x000078AF209FE110
000078af20bd1995  int3
000078af20bd1996  int3
000078af20bd1997  nop [rax+rax*1], ax
000078af20bd19a0  vmovaps xmm1, [0x000078AF207FE010]
000078af20bd19a8  movq xmm1, xmm1
000078af20bd19ac  movaps [r15+0x110], xmm1
000078af20bd19b4  mov eax, 0x420B10
000078af20bd19b9  mov r14, [r13+rax*1]
000078af20bd19be  movq xmm1, r14
000078af20bd19c3  movaps [r15+0x120], xmm1
000078af20bd19cb  vmovaps xmm1, [0x000078AF207FE020]
000078af20bd19d3  movq xmm1, xmm1
000078af20bd19d7  movaps [r15+0x140], xmm1
000078af20bd19df  vmovaps xmm1, [0x000078AF207FE030]
000078af20bd19e7  vpbroadcastq xmm1, xmm1
000078af20bd19ec  movaps [r15+0x150], xmm1
000078af20bd19f4  mov qword ptr [r15+0x40], 0x02
000078af20bd19fc  vmovaps xmm15, [0x000078AF207FE040]
000078af20bd1a04  movq xmm15, xmm15
000078af20bd1a09  movaps [r15+0x160], xmm15
000078af20bd1a11  vmovaps xmm15, [0x000078AF207FE050]
000078af20bd1a19  vpbroadcastq xmm15, xmm15
000078af20bd1a1e  movaps [r15+0x130], xmm15
000078af20bd1a26  mov rax, [r15+0x40]
000078af20bd1a2a  vmovq xmm14, rax
000078af20bd1a2f  vpbroadcastq xmm14, xmm14
000078af20bd1a34  movaps [r15+0x170], xmm14
000078af20bd1a3c  mov eax, 0x420A40
000078af20bd1a41  movups xmm13, [r13+rax*1]
000078af20bd1a47  mov qword ptr [r15+0x40], 0x431E00
000078af20bd1a4f  mov eax, [r15]
000078af20bd1a52  mov r14d, 0x430CB8
000078af20bd1a58  mov [r13+r14*1], eax
000078af20bd1a5d  mov qword ptr [r15+0x50], 0x432000
000078af20bd1a65  vpmovqd xmm12, xmm13
000078af20bd1a6b  pxor xmm11, xmm11
000078af20bd1a70  punpcklqdq xmm12, xmm11
000078af20bd1a75  movaps [r15+0x210], xmm12
000078af20bd1a7d  movq xmm12, qword ptr [r15+0x140]
000078af20bd1a86  movq xmm11, qword ptr [r15+0x120]
000078af20bd1a8f  psubd xmm12, xmm11
000078af20bd1a94  movq xmm12, xmm12
000078af20bd1a99  paddq xmm13, xmm14
000078af20bd1a9e  movaps [r15+0x180], xmm13
000078af20bd1aa6  movq xmm14, qword ptr [r15+0x160]
000078af20bd1aaf  paddd xmm11, xmm14
000078af20bd1ab4  movq xmm11, xmm11
000078af20bd1ab9  movq xmm11, xmm11
000078af20bd1abe  movaps [r15+0x120], xmm11
000078af20bd1ac6  pmovzxdq xmm12, xmm12
000078af20bd1acc  psllq xmm12, 0x00
000078af20bd1ad2  movq xmm14, qword ptr [r15+0x210]
000078af20bd1adb  movq xmm13, qword ptr [r15+0x110]
000078af20bd1ae4  paddd xmm14, xmm13
000078af20bd1ae9  movq xmm14, xmm14
000078af20bd1aee  vcvtuqq2pd xmm12, xmm12
000078af20bd1af4  pmovzxdq xmm14, xmm14
000078af20bd1afa  psllq xmm14, 0x00
000078af20bd1b00  vcvtuqq2pd xmm14, xmm14
000078af20bd1b06  movaps xmm13, xmm12
000078af20bd1b0a  mulpd xmm13, xmm1
000078af20bd1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
000078af20bd1b15  ptest xmm11, xmm11
000078af20bd1b1b  jnz 0x000078AF20BD1C0F
000078af20bd1b21  movaps [r15+0x220], xmm13
000078af20bd1b29  mov eax, 0x432000
000078af20bd1b2e  movups [r13+rax*1], xmm13
000078af20bd1b34  movaps xmm1, xmm14
000078af20bd1b38  mulpd xmm1, xmm15
000078af20bd1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
000078af20bd1b42  ptest xmm13, xmm13
000078af20bd1b48  jnz 0x000078AF20BD1D5C
000078af20bd1b4e  movaps [r15+0x210], xmm1
000078af20bd1b56  mov eax, 0x431E00
000078af20bd1b5b  movups [r13+rax*1], xmm1
000078af20bd1b61  mov qword ptr [r15+0x48], 0x10
000078af20bd1b69  xor eax, eax
000078af20bd1b6b  mov r14d, 0x10
000078af20bd1b71  mov r12d, 0x200
000078af20bd1b77  cmp r14, r12
000078af20bd1b7a  cmc
000078af20bd1b7b  lahf
000078af20bd1b7c  seto al
000078af20bd1b7f  mov [r15+0x108], eax
000078af20bd1b86  mov eax, [r15+0x108]
000078af20bd1b8d  sahf
000078af20bd1b8e  jnz 0x000078AF20BD1BC0
000078af20bd1b90  cmp dword ptr [r15+0x318], 0x00
000078af20bd1b98  jz 0x000078AF20BD2300
000078af20bd1b9e  nop [rax+rax*1], ax
000078af20bd1ba7  nop [rax+rax*1], eax
000078af20bd1baf  mov eax, 0x410490
000078af20bd1bb4  mov [r15+0x100], rax
000078af20bd1bbb  jmp 0x000078AF209FE110
000078af20bd1bc0  cmp dword ptr [r15+0x318], 0x00
000078af20bd1bc8  jz 0x000078AF20BD1EB0
000078af20bd1bce  nop [rax+rax*1], ax
000078af20bd1bd7  nop [rax+rax*1], eax
000078af20bd1bdf  mov eax, 0x410450
000078af20bd1be4  mov [r15+0x100], rax
000078af20bd1beb  jmp 0x000078AF209FE110
000078af20bd1bf0  int3
000078af20bd1bf1  call 0x000078AF20A0DC20
000078af20bd1bf6  jmp 0x000078AF20BD19BE
000078af20bd1bfb  call 0x000078AF20A0C260
000078af20bd1c00  jmp 0x000078AF20BD1A47
000078af20bd1c05  call 0x000078AF20AD5D70
000078af20bd1c0a  jmp 0x000078AF20BD1A5D
000078af20bd1c0f  sub rsp, 0x08
000078af20bd1c13  push rax
000078af20bd1c14  push rcx
000078af20bd1c15  push rdx
000078af20bd1c16  push rdi
000078af20bd1c17  push rsi
000078af20bd1c18  push r8
000078af20bd1c1a  push r9
000078af20bd1c1c  push r10
000078af20bd1c1e  push r11
000078af20bd1c20  sub rsp, 0xF0
000078af20bd1c27  vmovaps [rsp], xmm0
000078af20bd1c2c  vmovaps [rsp+0x10], xmm1
000078af20bd1c32  vmovaps [rsp+0x20], xmm2
000078af20bd1c38  vmovaps [rsp+0x30], xmm3
000078af20bd1c3e  vmovaps [rsp+0x40], xmm4
000078af20bd1c44  vmovaps [rsp+0x50], xmm5
000078af20bd1c4a  vmovaps [rsp+0x60], xmm6
000078af20bd1c50  vmovaps [rsp+0x70], xmm7
000078af20bd1c56  vmovaps [rsp+0x80], xmm8
000078af20bd1c5f  vmovaps [rsp+0x90], xmm9
000078af20bd1c68  vmovaps [rsp+0xA0], xmm10
000078af20bd1c71  vmovaps [rsp+0xB0], xmm11
000078af20bd1c7a  vmovaps [rsp+0xC0], xmm12
000078af20bd1c83  vmovaps [rsp+0xD0], xmm14
000078af20bd1c8c  vmovaps [rsp+0xE0], xmm15
000078af20bd1c95  sub rsp, 0x30
000078af20bd1c99  movaps [rsp], xmm13
000078af20bd1c9e  movaps [rsp+0x10], xmm12
000078af20bd1ca4  movaps [rsp+0x20], xmm1
000078af20bd1ca9  lea rdi, [rsp]
000078af20bd1cad  mov esi, 0x00
000078af20bd1cb2  mov rax, 0x65452FFB8530
000078af20bd1cbc  call rax
000078af20bd1cbe  movaps xmm13, [rsp]
000078af20bd1cc3  add rsp, 0x30
000078af20bd1cc7  vmovaps xmm0, [rsp]
000078af20bd1ccc  vmovaps xmm1, [rsp+0x10]
000078af20bd1cd2  vmovaps xmm2, [rsp+0x20]
000078af20bd1cd8  vmovaps xmm3, [rsp+0x30]
000078af20bd1cde  vmovaps xmm4, [rsp+0x40]
000078af20bd1ce4  vmovaps xmm5, [rsp+0x50]
000078af20bd1cea  vmovaps xmm6, [rsp+0x60]
000078af20bd1cf0  vmovaps xmm7, [rsp+0x70]
000078af20bd1cf6  vmovaps xmm8, [rsp+0x80]
000078af20bd1cff  vmovaps xmm9, [rsp+0x90]
000078af20bd1d08  vmovaps xmm10, [rsp+0xA0]
000078af20bd1d11  vmovaps xmm11, [rsp+0xB0]
000078af20bd1d1a  vmovaps xmm12, [rsp+0xC0]
000078af20bd1d23  vmovaps xmm14, [rsp+0xD0]
000078af20bd1d2c  vmovaps xmm15, [rsp+0xE0]
000078af20bd1d35  add rsp, 0xF0
000078af20bd1d3c  pop r11
000078af20bd1d3e  pop r10
000078af20bd1d40  pop r9
000078af20bd1d42  pop r8
000078af20bd1d44  pop rsi
000078af20bd1d45  pop rdi
000078af20bd1d46  pop rdx
000078af20bd1d47  pop rcx
000078af20bd1d48  pop rax
000078af20bd1d49  add rsp, 0x08
000078af20bd1d4d  jmp 0x000078AF20BD1B21
000078af20bd1d52  call 0x000078AF20A0C380
000078af20bd1d57  jmp 0x000078AF20BD1B34
000078af20bd1d5c  sub rsp, 0x08
000078af20bd1d60  push rax
000078af20bd1d61  push rcx
000078af20bd1d62  push rdx
000078af20bd1d63  push rdi
000078af20bd1d64  push rsi
000078af20bd1d65  push r8
000078af20bd1d67  push r9
000078af20bd1d69  push r10
000078af20bd1d6b  push r11
000078af20bd1d6d  sub rsp, 0xF0
000078af20bd1d74  vmovaps [rsp], xmm0
000078af20bd1d79  vmovaps [rsp+0x10], xmm2
000078af20bd1d7f  vmovaps [rsp+0x20], xmm3
000078af20bd1d85  vmovaps [rsp+0x30], xmm4
000078af20bd1d8b  vmovaps [rsp+0x40], xmm5
000078af20bd1d91  vmovaps [rsp+0x50], xmm6
000078af20bd1d97  vmovaps [rsp+0x60], xmm7
000078af20bd1d9d  vmovaps [rsp+0x70], xmm8
000078af20bd1da3  vmovaps [rsp+0x80], xmm9
000078af20bd1dac  vmovaps [rsp+0x90], xmm10
000078af20bd1db5  vmovaps [rsp+0xA0], xmm11
000078af20bd1dbe  vmovaps [rsp+0xB0], xmm12
000078af20bd1dc7  vmovaps [rsp+0xC0], xmm13
000078af20bd1dd0  vmovaps [rsp+0xD0], xmm14
000078af20bd1dd9  vmovaps [rsp+0xE0], xmm15
000078af20bd1de2  sub rsp, 0x30
000078af20bd1de6  movaps [rsp], xmm1
000078af20bd1dea  movaps [rsp+0x10], xmm14
000078af20bd1df0  movaps [rsp+0x20], xmm15
000078af20bd1df6  lea rdi, [rsp]
000078af20bd1dfa  mov esi, 0x00
000078af20bd1dff  mov rax, 0x65452FFB8530
000078af20bd1e09  call rax
000078af20bd1e0b  movaps xmm1, [rsp]
000078af20bd1e0f  add rsp, 0x30
000078af20bd1e13  vmovaps xmm0, [rsp]
000078af20bd1e18  vmovaps xmm2, [rsp+0x10]
000078af20bd1e1e  vmovaps xmm3, [rsp+0x20]
000078af20bd1e24  vmovaps xmm4, [rsp+0x30]
000078af20bd1e2a  vmovaps xmm5, [rsp+0x40]
000078af20bd1e30  vmovaps xmm6, [rsp+0x50]
000078af20bd1e36  vmovaps xmm7, [rsp+0x60]
000078af20bd1e3c  vmovaps xmm8, [rsp+0x70]
000078af20bd1e42  vmovaps xmm9, [rsp+0x80]
000078af20bd1e4b  vmovaps xmm10, [rsp+0x90]
000078af20bd1e54  vmovaps xmm11, [rsp+0xA0]
000078af20bd1e5d  vmovaps xmm12, [rsp+0xB0]
000078af20bd1e66  vmovaps xmm13, [rsp+0xC0]
000078af20bd1e6f  vmovaps xmm14, [rsp+0xD0]
000078af20bd1e78  vmovaps xmm15, [rsp+0xE0]
000078af20bd1e81  add rsp, 0xF0
000078af20bd1e88  pop r11
000078af20bd1e8a  pop r10
000078af20bd1e8c  pop r9
000078af20bd1e8e  pop r8
000078af20bd1e90  pop rsi
000078af20bd1e91  pop rdi
000078af20bd1e92  pop rdx
000078af20bd1e93  pop rcx
000078af20bd1e94  pop rax
000078af20bd1e95  add rsp, 0x08
000078af20bd1e99  jmp 0x000078AF20BD1B4E
000078af20bd1e9e  call 0x000078AF209FF540
000078af20bd1ea3  jmp 0x000078AF20BD1B61
000078af20bd1ea8  int3
000078af20bd1ea9  nop [rax], eax
000078af20bd1eb0  movaps xmm1, [r15+0x180]
000078af20bd1eb8  vpmovqd xmm15, xmm1
000078af20bd1ebe  pxor xmm14, xmm14
000078af20bd1ec3  punpcklqdq xmm15, xmm14
000078af20bd1ec8  movaps [r15+0x210], xmm15
000078af20bd1ed0  movq xmm15, qword ptr [r15+0x140]
000078af20bd1ed9  movq xmm14, qword ptr [r15+0x120]
000078af20bd1ee2  psubd xmm15, xmm14
000078af20bd1ee7  movq xmm15, xmm15
000078af20bd1eec  movaps xmm13, [r15+0x170]
000078af20bd1ef4  paddq xmm1, xmm13
000078af20bd1ef9  movaps [r15+0x180], xmm1
000078af20bd1f01  movq xmm1, qword ptr [r15+0x160]
000078af20bd1f0a  paddd xmm14, xmm1
000078af20bd1f0f  movq xmm14, xmm14
000078af20bd1f14  movq xmm14, xmm14
000078af20bd1f19  movaps [r15+0x120], xmm14
000078af20bd1f21  pmovzxdq xmm15, xmm15
000078af20bd1f27  psllq xmm15, 0x00
000078af20bd1f2d  movq xmm1, qword ptr [r15+0x210]
000078af20bd1f36  movq xmm14, qword ptr [r15+0x110]
000078af20bd1f3f  paddd xmm1, xmm14
000078af20bd1f44  movq xmm1, xmm1
000078af20bd1f48  vcvtuqq2pd xmm15, xmm15
000078af20bd1f4e  pmovzxdq xmm1, xmm1
000078af20bd1f53  psllq xmm1, 0x00
000078af20bd1f58  vcvtuqq2pd xmm1, xmm1
000078af20bd1f5e  movaps xmm14, [r15+0x150]
000078af20bd1f66  movaps xmm13, xmm15
000078af20bd1f6a  mulpd xmm13, xmm14
000078af20bd1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
000078af20bd1f75  ptest xmm12, xmm12
000078af20bd1f7b  jnz 0x000078AF20BD205E
000078af20bd1f81  movaps [r15+0x220], xmm13
000078af20bd1f89  mov rax, [r15+0x48]
000078af20bd1f8d  mov r14, [r15+0x50]
000078af20bd1f91  lea r12, [r14+rax*1]
000078af20bd1f95  movups [r13+r12*1], xmm13
000078af20bd1f9b  movaps xmm15, [r15+0x130]
000078af20bd1fa3  movaps xmm14, xmm1
000078af20bd1fa7  mulpd xmm14, xmm15
000078af20bd1fac  vcmppd xmm13, xmm14, xmm14, 0x03
000078af20bd1fb2  ptest xmm13, xmm13
000078af20bd1fb8  jnz 0x000078AF20BD21AC
000078af20bd1fbe  movaps [r15+0x210], xmm14
000078af20bd1fc6  mov r14, [r15+0x40]
000078af20bd1fca  lea r12, [r14+rax*1]
000078af20bd1fce  movups [r13+r12*1], xmm14
000078af20bd1fd4  lea r14, [rax+0x10]
000078af20bd1fd8  mov [r15+0x48], r14
000078af20bd1fdc  xor eax, eax
000078af20bd1fde  mov r12d, 0x200
000078af20bd1fe4  cmp r14, r12
000078af20bd1fe7  cmc
000078af20bd1fe8  lahf
000078af20bd1fe9  seto al
000078af20bd1fec  mov [r15+0x108], eax
000078af20bd1ff3  mov eax, [r15+0x108]
000078af20bd1ffa  sahf
000078af20bd1ffb  jnz 0x000078AF20BD202D
000078af20bd1ffd  cmp dword ptr [r15+0x318], 0x00
000078af20bd2005  jz 0x000078AF20BD2300
000078af20bd200b  nop [rax+rax*1], ax
000078af20bd2014  nop [rax+rax*1], eax
000078af20bd201c  mov eax, 0x410490
000078af20bd2021  mov [r15+0x100], rax
000078af20bd2028  jmp 0x000078AF209FE110
000078af20bd202d  cmp dword ptr [r15+0x318], 0x00
000078af20bd2035  jz 0x000078AF20BD1EB0
000078af20bd203b  nop [rax+rax*1], ax
000078af20bd2044  nop [rax+rax*1], eax
000078af20bd204c  mov eax, 0x410450
000078af20bd2051  mov [r15+0x100], rax
000078af20bd2058  jmp 0x000078AF209FE110
000078af20bd205d  int3
000078af20bd205e  sub rsp, 0x08
000078af20bd2062  push rax
000078af20bd2063  push rcx
000078af20bd2064  push rdx
000078af20bd2065  push rdi
000078af20bd2066  push rsi
000078af20bd2067  push r8
000078af20bd2069  push r9
000078af20bd206b  push r10
000078af20bd206d  push r11
000078af20bd206f  sub rsp, 0xF0
000078af20bd2076  vmovaps [rsp], xmm0
000078af20bd207b  vmovaps [rsp+0x10], xmm1
000078af20bd2081  vmovaps [rsp+0x20], xmm2
000078af20bd2087  vmovaps [rsp+0x30], xmm3
000078af20bd208d  vmovaps [rsp+0x40], xmm4
000078af20bd2093  vmovaps [rsp+0x50], xmm5
000078af20bd2099  vmovaps [rsp+0x60], xmm6
000078af20bd209f  vmovaps [rsp+0x70], xmm7
000078af20bd20a5  vmovaps [rsp+0x80], xmm8
000078af20bd20ae  vmovaps [rsp+0x90], xmm9
000078af20bd20b7  vmovaps [rsp+0xA0], xmm10
000078af20bd20c0  vmovaps [rsp+0xB0], xmm11
000078af20bd20c9  vmovaps [rsp+0xC0], xmm12
000078af20bd20d2  vmovaps [rsp+0xD0], xmm14
000078af20bd20db  vmovaps [rsp+0xE0], xmm15
000078af20bd20e4  sub rsp, 0x30
000078af20bd20e8  movaps [rsp], xmm13
000078af20bd20ed  movaps [rsp+0x10], xmm15
000078af20bd20f3  movaps [rsp+0x20], xmm14
000078af20bd20f9  lea rdi, [rsp]
000078af20bd20fd  mov esi, 0x00
000078af20bd2102  mov rax, 0x65452FFB8530
000078af20bd210c  call rax
000078af20bd210e  movaps xmm13, [rsp]
000078af20bd2113  add rsp, 0x30
000078af20bd2117  vmovaps xmm0, [rsp]
000078af20bd211c  vmovaps xmm1, [rsp+0x10]
000078af20bd2122  vmovaps xmm2, [rsp+0x20]
000078af20bd2128  vmovaps xmm3, [rsp+0x30]
000078af20bd212e  vmovaps xmm4, [rsp+0x40]
000078af20bd2134  vmovaps xmm5, [rsp+0x50]
000078af20bd213a  vmovaps xmm6, [rsp+0x60]
000078af20bd2140  vmovaps xmm7, [rsp+0x70]
000078af20bd2146  vmovaps xmm8, [rsp+0x80]
000078af20bd214f  vmovaps xmm9, [rsp+0x90]
000078af20bd2158  vmovaps xmm10, [rsp+0xA0]
000078af20bd2161  vmovaps xmm11, [rsp+0xB0]
000078af20bd216a  vmovaps xmm12, [rsp+0xC0]
000078af20bd2173  vmovaps xmm14, [rsp+0xD0]
000078af20bd217c  vmovaps xmm15, [rsp+0xE0]
000078af20bd2185  add rsp, 0xF0
000078af20bd218c  pop r11
000078af20bd218e  pop r10
000078af20bd2190  pop r9
000078af20bd2192  pop r8
000078af20bd2194  pop rsi
000078af20bd2195  pop rdi
000078af20bd2196  pop rdx
000078af20bd2197  pop rcx
000078af20bd2198  pop rax
000078af20bd2199  add rsp, 0x08
000078af20bd219d  jmp 0x000078AF20BD1F81
000078af20bd21a2  call 0x000078AF20AC2240
000078af20bd21a7  jmp 0x000078AF20BD1F9B
000078af20bd21ac  sub rsp, 0x08
000078af20bd21b0  push rax
000078af20bd21b1  push rcx
000078af20bd21b2  push rdx
000078af20bd21b3  push rdi
000078af20bd21b4  push rsi
000078af20bd21b5  push r8
000078af20bd21b7  push r9
000078af20bd21b9  push r10
000078af20bd21bb  push r11
000078af20bd21bd  sub rsp, 0xF0
000078af20bd21c4  vmovaps [rsp], xmm0
000078af20bd21c9  vmovaps [rsp+0x10], xmm1
000078af20bd21cf  vmovaps [rsp+0x20], xmm2
000078af20bd21d5  vmovaps [rsp+0x30], xmm3
000078af20bd21db  vmovaps [rsp+0x40], xmm4
000078af20bd21e1  vmovaps [rsp+0x50], xmm5
000078af20bd21e7  vmovaps [rsp+0x60], xmm6
000078af20bd21ed  vmovaps [rsp+0x70], xmm7
000078af20bd21f3  vmovaps [rsp+0x80], xmm8
000078af20bd21fc  vmovaps [rsp+0x90], xmm9
000078af20bd2205  vmovaps [rsp+0xA0], xmm10
000078af20bd220e  vmovaps [rsp+0xB0], xmm11
000078af20bd2217  vmovaps [rsp+0xC0], xmm12
000078af20bd2220  vmovaps [rsp+0xD0], xmm13
000078af20bd2229  vmovaps [rsp+0xE0], xmm15
000078af20bd2232  sub rsp, 0x30
000078af20bd2236  movaps [rsp], xmm14
000078af20bd223b  movaps [rsp+0x10], xmm1
000078af20bd2240  movaps [rsp+0x20], xmm15
000078af20bd2246  lea rdi, [rsp]
000078af20bd224a  mov esi, 0x00
000078af20bd224f  mov rax, 0x65452FFB8530
000078af20bd2259  call rax
000078af20bd225b  movaps xmm14, [rsp]
000078af20bd2260  add rsp, 0x30
000078af20bd2264  vmovaps xmm0, [rsp]
000078af20bd2269  vmovaps xmm1, [rsp+0x10]
000078af20bd226f  vmovaps xmm2, [rsp+0x20]
000078af20bd2275  vmovaps xmm3, [rsp+0x30]
000078af20bd227b  vmovaps xmm4, [rsp+0x40]
000078af20bd2281  vmovaps xmm5, [rsp+0x50]
000078af20bd2287  vmovaps xmm6, [rsp+0x60]
000078af20bd228d  vmovaps xmm7, [rsp+0x70]
000078af20bd2293  vmovaps xmm8, [rsp+0x80]
000078af20bd229c  vmovaps xmm9, [rsp+0x90]
000078af20bd22a5  vmovaps xmm10, [rsp+0xA0]
000078af20bd22ae  vmovaps xmm11, [rsp+0xB0]
000078af20bd22b7  vmovaps xmm12, [rsp+0xC0]
000078af20bd22c0  vmovaps xmm13, [rsp+0xD0]
000078af20bd22c9  vmovaps xmm15, [rsp+0xE0]
000078af20bd22d2  add rsp, 0xF0
000078af20bd22d9  pop r11
000078af20bd22db  pop r10
000078af20bd22dd  pop r9
000078af20bd22df  pop r8
000078af20bd22e1  pop rsi
000078af20bd22e2  pop rdi
000078af20bd22e3  pop rdx
000078af20bd22e4  pop rcx
000078af20bd22e5  pop rax
000078af20bd22e6  add rsp, 0x08
000078af20bd22ea  jmp 0x000078AF20BD1FBE
000078af20bd22ef  call 0x000078AF20AC34C0
000078af20bd22f4  jmp 0x000078AF20BD1FD4
000078af20bd22f9  int3
000078af20bd22fa  nop [rax+rax*1], ax
000078af20bd2300  mov rax, [r15+0x50]
000078af20bd2304  lea r14, [rax+0x80]
000078af20bd230b  movups xmm1, [r13+r14*1]
000078af20bd2311  lea r14, [rax+0x90]
000078af20bd2318  movups xmm15, [r13+r14*1]
000078af20bd231e  vxorps xmm14, xmm14, xmm14
000078af20bd2323  vpbroadcastq xmm14, xmm14
000078af20bd2328  lea r14, [rax+0x40]
000078af20bd232c  movups xmm13, [r13+r14*1]
000078af20bd2332  lea r14, [rax+0x50]
000078af20bd2336  movups xmm12, [r13+r14*1]
000078af20bd233c  mov qword ptr [r15+0x48], 0x00
000078af20bd2344  movups xmm11, [r13+rax*1]
000078af20bd234a  lea r14, [rax+0x10]
000078af20bd234e  movups xmm10, [r13+r14*1]
000078af20bd2354  mov r14, [r15+0xF8]
000078af20bd235b  lea r12, [r14+0xE0]
000078af20bd2362  movups [r13+r12*1], xmm15
000078af20bd2368  lea r12, [r14+0xF0]
000078af20bd236f  movups [r13+r12*1], xmm1
000078af20bd2375  lea r12, [rax+0xC0]
000078af20bd237c  movups xmm1, [r13+r12*1]
000078af20bd2382  lea r12, [rax+0xD0]
000078af20bd2389  movups xmm15, [r13+r12*1]
000078af20bd238f  lea r12, [rax+0x140]
000078af20bd2396  movups xmm9, [r13+r12*1]
000078af20bd239c  lea r12, [rax+0x150]
000078af20bd23a3  movups xmm8, [r13+r12*1]
000078af20bd23a9  lea r12, [rax+0x180]
000078af20bd23b0  movups xmm7, [r13+r12*1]
000078af20bd23b6  lea r12, [rax+0x190]
000078af20bd23bd  movups xmm6, [r13+r12*1]
000078af20bd23c3  lea r12, [r14+0xC0]
000078af20bd23ca  movups [r13+r12*1], xmm15
000078af20bd23d0  lea r12, [r14+0xD0]
000078af20bd23d7  movups [r13+r12*1], xmm1
000078af20bd23dd  lea r12, [rax+0x100]
000078af20bd23e4  movups xmm1, [r13+r12*1]
000078af20bd23ea  lea r12, [rax+0x110]
000078af20bd23f1  movups xmm15, [r13+r12*1]
000078af20bd23f7  lea r12, [rax+0x1C0]
000078af20bd23fe  movups xmm5, [r13+r12*1]
000078af20bd2404  lea r12, [rax+0x1D0]
000078af20bd240b  movups xmm4, [r13+r12*1]
000078af20bd2411  lea r12, [rax+0x20]
000078af20bd2415  movups xmm3, [r13+r12*1]
000078af20bd241b  lea r12, [rax+0x30]
000078af20bd241f  movups xmm2, [r13+r12*1]
000078af20bd2425  movaps [r15+0x1F0], xmm2
000078af20bd242d  lea r12, [r14+0x20]
000078af20bd2431  movups [r13+r12*1], xmm1
000078af20bd2437  lea r12, [r14+0x30]
000078af20bd243b  movups [r13+r12*1], xmm12
000078af20bd2441  lea r12, [rax+0x60]
000078af20bd2445  movups xmm1, [r13+r12*1]
000078af20bd244b  lea r12, [rax+0x70]
000078af20bd244f  movups xmm12, [r13+r12*1]
000078af20bd2455  lea r12, [r14+0x60]
000078af20bd2459  movups [r13+r12*1], xmm11
000078af20bd245f  lea r12, [r14+0x70]
000078af20bd2463  movups [r13+r12*1], xmm5
000078af20bd2469  lea r12, [rax+0xE0]
000078af20bd2470  movups xmm11, [r13+r12*1]
000078af20bd2476  lea r12, [rax+0xF0]
000078af20bd247d  movups xmm5, [r13+r12*1]
000078af20bd2483  lea r12, [rax+0x120]
000078af20bd248a  vmovaps [rsp+0x10], xmm1
000078af20bd2490  movups xmm1, [r13+r12*1]
000078af20bd2496  lea r12, [rax+0x130]
000078af20bd249d  vmovaps [rsp+0x20], xmm1
000078af20bd24a3  movups xmm1, [r13+r12*1]
000078af20bd24a9  lea r12, [r14+0xA0]
000078af20bd24b0  movups [r13+r12*1], xmm12
000078af20bd24b6  lea r12, [r14+0xB0]
000078af20bd24bd  vmovaps xmm12, [rsp+0x10]
000078af20bd24c3  movups [r13+r12*1], xmm12
000078af20bd24c9  lea r12, [rax+0xA0]
000078af20bd24d0  movups xmm12, [r13+r12*1]
000078af20bd24d6  lea r12, [rax+0xB0]
000078af20bd24dd  vmovaps [rsp+0x10], xmm1
000078af20bd24e3  movups xmm1, [r13+r12*1]
000078af20bd24e9  lea r12, [rax+0x160]
000078af20bd24f0  vmovaps [rsp+0x30], xmm1
000078af20bd24f6  movups xmm1, [r13+r12*1]
000078af20bd24fc  lea r12, [rax+0x170]
000078af20bd2503  vmovaps [rsp+0x40], xmm1
000078af20bd2509  movups xmm1, [r13+r12*1]
000078af20bd250f  movaps [r15+0x2B0], xmm1
000078af20bd2517  lea r12, [rax+0x1A0]
000078af20bd251e  vmovaps [rsp+0x50], xmm1
000078af20bd2524  movups xmm1, [r13+r12*1]
000078af20bd252a  lea r12, [rax+0x1B0]
000078af20bd2531  vmovaps [rsp+0x60], xmm1
000078af20bd2537  movups xmm1, [r13+r12*1]
000078af20bd253d  vmovaps [rsp+0x70], xmm1
000078af20bd2543  vmovaps xmm1, [rsp+0x60]
000078af20bd2549  movaps [r15+0x290], xmm1
000078af20bd2551  vmovaps [rsp+0x60], xmm1
000078af20bd2557  vmovaps xmm1, [rsp+0x70]
000078af20bd255d  movaps [r15+0x1E0], xmm1
000078af20bd2565  lea r12, [r14+0x80]
000078af20bd256c  vmovaps [rsp+0x70], xmm1
000078af20bd2572  vmovaps xmm1, [rsp+0x30]
000078af20bd2578  movups [r13+r12*1], xmm1
000078af20bd257e  lea r12, [r14+0x90]
000078af20bd2585  movups [r13+r12*1], xmm12
000078af20bd258b  lea r12, [rax+0x1E0]
000078af20bd2592  movups xmm1, [r13+r12*1]
000078af20bd2598  lea r12, [rax+0x1F0]
000078af20bd259f  movups xmm12, [r13+r12*1]
000078af20bd25a5  mov qword ptr [r15+0x50], 0x432200
000078af20bd25ad  lea rax, [r14+0x40]
000078af20bd25b1  vmovaps [rsp+0x30], xmm1
000078af20bd25b7  vmovaps xmm1, [rsp+0x40]
000078af20bd25bd  movups [r13+rax*1], xmm1
000078af20bd25c3  lea rax, [r14+0x50]
000078af20bd25c7  movups [r13+rax*1], xmm10
000078af20bd25cd  movups [r13+r14*1], xmm12
000078af20bd25d3  lea rax, [r14+0x10]
000078af20bd25d7  vmovaps xmm1, [rsp+0x30]
000078af20bd25dd  movups [r13+rax*1], xmm1
000078af20bd25e3  mov rax, [r15+0x40]
000078af20bd25e7  vmovaps [rsp+0x30], xmm3
000078af20bd25ed  vmovaps xmm1, [rsp+0x30]
000078af20bd25f3  por xmm3, xmm1
000078af20bd25f7  vmovaps [rsp+0x30], xmm6
000078af20bd25fd  vmovaps xmm12, [rsp+0x30]
000078af20bd2603  por xmm6, xmm12
000078af20bd2608  lea r12, [rax+0x30]
000078af20bd260c  mov r11, [r13+r12*1]
000078af20bd2611  lea r12, [rax+0x38]
000078af20bd2615  mov r10, [r13+r12*1]
000078af20bd261a  movq xmm12, r11
000078af20bd261f  movq xmm10, r10
000078af20bd2624  movq xmm12, xmm12
000078af20bd2629  vmovaps [rsp+0x30], xmm12
000078af20bd262f  movq xmm12, xmm12
000078af20bd2634  movaps [r15+0x130], xmm12
000078af20bd263c  movq xmm10, xmm10
000078af20bd2641  vmovaps [rsp+0x40], xmm10
000078af20bd2647  movq xmm10, xmm10
000078af20bd264c  movaps [r15+0x280], xmm10
000078af20bd2654  vmovaps [rsp+0x80], xmm9
000078af20bd265d  vmovaps xmm12, [rsp+0x80]
000078af20bd2666  por xmm9, xmm12
000078af20bd266b  lea r12, [rax+0x20]
000078af20bd266f  mov r11, [r13+r12*1]
000078af20bd2674  lea r12, [rax+0x28]
000078af20bd2678  mov r10, [r13+r12*1]
000078af20bd267d  movq xmm12, r11
000078af20bd2682  movq xmm10, r10
000078af20bd2687  movq xmm12, xmm12
000078af20bd268c  vmovaps [rsp+0x80], xmm12
000078af20bd2695  movq xmm12, xmm12
000078af20bd269a  movaps [r15+0x150], xmm12
000078af20bd26a2  movq xmm10, xmm10
000078af20bd26a7  vmovaps [rsp+0x90], xmm10
000078af20bd26b0  movq xmm10, xmm10
000078af20bd26b5  movaps [r15+0x140], xmm10
000078af20bd26bd  lea r12, [rax+0x10]
000078af20bd26c1  mov r11, [r13+r12*1]
000078af20bd26c6  lea r12, [rax+0x18]
000078af20bd26ca  mov r10, [r13+r12*1]
000078af20bd26cf  movq xmm12, r11
000078af20bd26d4  movq xmm10, r10
000078af20bd26d9  movq xmm12, xmm12
000078af20bd26de  vmovaps [rsp+0xA0], xmm12
000078af20bd26e7  movq xmm12, xmm12
000078af20bd26ec  movaps [r15+0x170], xmm12
000078af20bd26f4  movq xmm10, xmm10
000078af20bd26f9  vmovaps [rsp+0xB0], xmm10
000078af20bd2702  movq xmm10, xmm10
000078af20bd2707  movaps [r15+0x160], xmm10
000078af20bd270f  mov r12, [r13+rax*1]
000078af20bd2714  vmovq xmm12, r12
000078af20bd2719  vpbroadcastq xmm12, xmm12
000078af20bd271e  lea r12, [rax+0x08]
000078af20bd2722  mov rax, [r13+r12*1]
000078af20bd2727  movq xmm10, rax
000078af20bd272c  movaps [r15+0x230], xmm10
000078af20bd2734  lea rax, [r14+0x50]
000078af20bd2738  movups xmm10, [r13+rax*1]
000078af20bd273e  lea rax, [r14+0x60]
000078af20bd2742  vmovaps [rsp+0xC0], xmm1
000078af20bd274b  movups xmm1, [r13+rax*1]
000078af20bd2751  lea rax, [r14+0x30]
000078af20bd2755  vmovaps [rsp+0xD0], xmm1
000078af20bd275e  movups xmm1, [r13+rax*1]
000078af20bd2764  mov qword ptr [r15+0x60], 0x432200
000078af20bd276c  mov qword ptr [r15+0x58], 0x40
000078af20bd2774  vmovaps [rsp+0xE0], xmm1
000078af20bd277d  vmovaps [rsp+0xF0], xmm15
000078af20bd2786  vmovaps xmm15, [rsp+0xC0]
000078af20bd278f  vmovaps [rsp+0xC0], xmm14
000078af20bd2798  movaps xmm1, xmm12
000078af20bd279c  mulpd xmm1, xmm15
000078af20bd27a1  vcmppd xmm14, xmm1, xmm1, 0x03
000078af20bd27a6  ptest xmm14, xmm14
000078af20bd27ac  jnz 0x000078AF20BD3863
000078af20bd27b2  movq xmm15, qword ptr [r15+0x230]
000078af20bd27bb  vmovaps [rsp+0x100], xmm15
000078af20bd27c4  vpermilpd xmm15, xmm15, 0x00
000078af20bd27ca  vmovaps [rsp+0x110], xmm1
000078af20bd27d3  vmovaps xmm1, [rsp+0xE0]
000078af20bd27dc  vmovaps [rsp+0xE0], xmm13
000078af20bd27e5  movaps xmm14, xmm1
000078af20bd27e9  mulpd xmm14, xmm15
000078af20bd27ee  vcmppd xmm13, xmm14, xmm14, 0x03
000078af20bd27f4  ptest xmm13, xmm13
000078af20bd27fa  jnz 0x000078AF20BD39A5
000078af20bd2800  vxorps xmm1, xmm1, xmm1
000078af20bd2804  vpbroadcastq xmm1, xmm1
000078af20bd2809  vmovaps xmm13, [rsp+0xD0]
000078af20bd2812  vmovaps [rsp+0xD0], xmm1
000078af20bd281b  movaps xmm15, xmm12
000078af20bd281f  mulpd xmm15, xmm13
000078af20bd2824  vcmppd xmm1, xmm15, xmm15, 0x03
000078af20bd282a  ptest xmm1, xmm1
000078af20bd282f  jnz 0x000078AF20BD3AE8
000078af20bd2835  movaps xmm1, xmm12
000078af20bd2839  mulpd xmm1, xmm10
000078af20bd283e  vcmppd xmm13, xmm1, xmm1, 0x03
000078af20bd2843  ptest xmm13, xmm13
000078af20bd2849  jnz 0x000078AF20BD3C2C
000078af20bd284f  movaps xmm13, xmm12
000078af20bd2853  mulpd xmm13, xmm2
000078af20bd2858  vcmppd xmm10, xmm13, xmm13, 0x03
000078af20bd285e  ptest xmm10, xmm10
000078af20bd2864  jnz 0x000078AF20BD3D6E
000078af20bd286a  vmovaps [rsp+0x120], xmm7
000078af20bd2873  vmovaps xmm12, [rsp+0x120]
000078af20bd287c  por xmm7, xmm12
000078af20bd2881  vmovaps xmm12, [rsp+0xE0]
000078af20bd288a  vmovaps xmm10, [rsp+0xE0]
000078af20bd2893  por xmm12, xmm10
000078af20bd2898  vmovaps xmm2, [rsp+0x100]
000078af20bd28a1  vpermilpd xmm2, xmm2, 0x00
000078af20bd28a7  vmovaps [rsp+0xE0], xmm1
000078af20bd28b0  vmovaps [rsp+0x120], xmm15
000078af20bd28b9  movaps xmm1, xmm10
000078af20bd28bd  mulpd xmm1, xmm2
000078af20bd28c1  vcmppd xmm15, xmm1, xmm1, 0x03
000078af20bd28c6  ptest xmm15, xmm15
000078af20bd28cc  jnz 0x000078AF20BD3EB1
000078af20bd28d2  xor eax, eax
000078af20bd28d4  mov r12d, 0x40
000078af20bd28da  mov r11d, 0x200
000078af20bd28e0  cmp r12, r11
000078af20bd28e3  cmc
000078af20bd28e4  lahf
000078af20bd28e5  seto al
000078af20bd28e8  mov [r15+0x108], eax
000078af20bd28ef  vmovaps xmm10, [rsp+0x110]
000078af20bd28f8  vmovaps xmm2, [rsp+0xD0]
000078af20bd2901  vmovaps [rsp+0xD0], xmm1
000078af20bd290a  movaps xmm15, xmm10
000078af20bd290e  addpd xmm15, xmm2
000078af20bd2913  vcmppd xmm1, xmm15, xmm15, 0x03
000078af20bd2919  ptest xmm1, xmm1
000078af20bd291e  jnz 0x000078AF20BD3FF2
000078af20bd2924  vmovaps xmm10, [rsp+0x120]
000078af20bd292d  vmovaps [rsp+0x110], xmm15
000078af20bd2936  vmovaps xmm15, [rsp+0xC0]
000078af20bd293f  vmovaps [rsp+0xC0], xmm14
000078af20bd2948  movaps xmm1, xmm10
000078af20bd294c  addpd xmm1, xmm15
000078af20bd2951  vcmppd xmm14, xmm1, xmm1, 0x03
000078af20bd2956  ptest xmm14, xmm14
000078af20bd295c  jnz 0x000078AF20BD4135
000078af20bd2962  vmovaps xmm10, [rsp+0xE0]
000078af20bd296b  vmovaps [rsp+0xE0], xmm1
000078af20bd2974  movaps xmm14, xmm10
000078af20bd2978  addpd xmm14, xmm15
000078af20bd297d  vcmppd xmm1, xmm14, xmm14, 0x03
000078af20bd2983  ptest xmm1, xmm1
000078af20bd2988  jnz 0x000078AF20BD4277
000078af20bd298e  vmovaps xmm1, [rsp+0x10]
000078af20bd2994  vmovaps xmm15, [rsp+0x10]
000078af20bd299a  por xmm1, xmm15
000078af20bd299f  vmovaps xmm15, [rsp+0x20]
000078af20bd29a5  vmovaps xmm10, [rsp+0x20]
000078af20bd29ab  por xmm15, xmm10
000078af20bd29b0  vmovaps [rsp+0x10], xmm5
000078af20bd29b6  vmovaps xmm10, [rsp+0x10]
000078af20bd29bc  por xmm5, xmm10
000078af20bd29c1  vmovaps [rsp+0x10], xmm11
000078af20bd29c7  vmovaps xmm10, [rsp+0x10]
000078af20bd29cd  por xmm11, xmm10
000078af20bd29d2  vmovaps [rsp+0x10], xmm4
000078af20bd29d8  vmovaps xmm10, [rsp+0x10]
000078af20bd29de  por xmm4, xmm10
000078af20bd29e3  vmovaps [rsp+0x10], xmm8
000078af20bd29e9  vmovaps xmm10, [rsp+0x10]
000078af20bd29ef  por xmm8, xmm10
000078af20bd29f4  vmovaps xmm10, [rsp+0xF0]
000078af20bd29fd  vmovaps [rsp+0x10], xmm1
000078af20bd2a03  vmovaps xmm1, [rsp+0xF0]
000078af20bd2a0c  por xmm10, xmm1
000078af20bd2a11  lea rax, [r14+0xA0]
000078af20bd2a18  movups xmm1, [r13+rax*1]
000078af20bd2a1e  lea rax, [r14+0xB0]
000078af20bd2a25  vmovaps [rsp+0x20], xmm1
000078af20bd2a2b  movups xmm1, [r13+rax*1]
000078af20bd2a31  vmovaps [rsp+0xF0], xmm1
000078af20bd2a3a  vmovaps [rsp+0x120], xmm15
000078af20bd2a43  movaps xmm1, xmm13
000078af20bd2a47  addpd xmm1, xmm2
000078af20bd2a4b  vcmppd xmm15, xmm1, xmm1, 0x03
000078af20bd2a50  ptest xmm15, xmm15
000078af20bd2a56  jnz 0x000078AF20BD43CF
000078af20bd2a5c  lea rax, [r14+0xF0]
000078af20bd2a63  movups xmm15, [r13+rax*1]
000078af20bd2a69  vmovaps xmm2, [rsp+0xE0]
000078af20bd2a72  vmovaps [rsp+0xE0], xmm1
000078af20bd2a7b  vmovaps xmm1, [rsp+0xD0]
000078af20bd2a84  vmovaps [rsp+0xD0], xmm15
000078af20bd2a8d  movaps xmm13, xmm2
000078af20bd2a91  addpd xmm13, xmm1
000078af20bd2a96  vcmppd xmm15, xmm13, xmm13, 0x03
000078af20bd2a9c  ptest xmm15, xmm15
000078af20bd2aa2  jnz 0x000078AF20BD451A
000078af20bd2aa8  vmovaps xmm15, [rsp+0xC0]
000078af20bd2ab1  movaps xmm1, xmm14
000078af20bd2ab5  addpd xmm1, xmm15
000078af20bd2aba  vcmppd xmm2, xmm1, xmm1, 0x03
000078af20bd2abf  ptest xmm2, xmm2
000078af20bd2ac4  jnz 0x000078AF20BD465C
000078af20bd2aca  vmovaps xmm15, [rsp+0x100]
000078af20bd2ad3  vpermilpd xmm15, xmm15, 0x00
000078af20bd2ad9  vmovaps xmm2, [rsp+0xF0]
000078af20bd2ae2  vmovaps [rsp+0xC0], xmm1
000078af20bd2aeb  movaps xmm14, xmm2
000078af20bd2aef  mulpd xmm14, xmm15
000078af20bd2af4  vcmppd xmm1, xmm14, xmm14, 0x03
000078af20bd2afa  ptest xmm1, xmm1
000078af20bd2aff  jnz 0x000078AF20BD479E
000078af20bd2b05  vmovaps xmm1, [rsp+0xA0]
000078af20bd2b0e  vpermilpd xmm1, xmm1, 0x00
000078af20bd2b14  vmovaps xmm2, [rsp+0xD0]
000078af20bd2b1d  vmovaps [rsp+0xD0], xmm14
000078af20bd2b26  movaps xmm15, xmm2
000078af20bd2b2a  mulpd xmm15, xmm1
000078af20bd2b2f  vcmppd xmm14, xmm15, xmm15, 0x03
000078af20bd2b35  ptest xmm14, xmm14
000078af20bd2b3b  jnz 0x000078AF20BD48E1
000078af20bd2b41  lea rax, [r14+0xE0]
000078af20bd2b48  movups xmm1, [r13+rax*1]
000078af20bd2b4e  vmovaps xmm14, [rsp+0x100]
000078af20bd2b57  vpermilpd xmm14, xmm14, 0x00
000078af20bd2b5d  vmovaps [rsp+0xF0], xmm1
000078af20bd2b66  vmovaps xmm1, [rsp+0x20]
000078af20bd2b6c  vmovaps [rsp+0x20], xmm15
000078af20bd2b72  movaps xmm2, xmm1
000078af20bd2b75  mulpd xmm2, xmm14
000078af20bd2b7a  vcmppd xmm15, xmm2, xmm2, 0x03
000078af20bd2b7f  ptest xmm15, xmm15
000078af20bd2b85  jnz 0x000078AF20BD4A2D
000078af20bd2b8b  vmovaps [rsp+0x100], xmm10
000078af20bd2b94  vmovaps xmm1, [rsp+0x100]
000078af20bd2b9d  por xmm10, xmm1
000078af20bd2ba2  movaps [r15+0x300], xmm10
000078af20bd2baa  vmovaps [rsp+0x100], xmm8
000078af20bd2bb3  vmovaps xmm1, [rsp+0x100]
000078af20bd2bbc  por xmm8, xmm1
000078af20bd2bc1  movaps [r15+0x190], xmm8
000078af20bd2bc9  vmovaps xmm1, [rsp+0xA0]
000078af20bd2bd2  vpermilpd xmm1, xmm1, 0x00
000078af20bd2bd8  vmovaps xmm14, [rsp+0xF0]
000078af20bd2be1  vmovaps [rsp+0xF0], xmm13
000078af20bd2bea  movaps xmm15, xmm14
000078af20bd2bee  mulpd xmm15, xmm1
000078af20bd2bf3  vcmppd xmm13, xmm15, xmm15, 0x03
000078af20bd2bf9  ptest xmm13, xmm13
000078af20bd2bff  jnz 0x000078AF20BD4B6E
000078af20bd2c05  lea rax, [r14+0x90]
000078af20bd2c0c  movups xmm1, [r13+rax*1]
000078af20bd2c12  vmovaps [rsp+0x100], xmm4
000078af20bd2c1b  vmovaps xmm14, [rsp+0x100]
000078af20bd2c24  por xmm4, xmm14
000078af20bd2c29  movaps [r15+0x1C0], xmm4
000078af20bd2c31  vmovaps [rsp+0x100], xmm11
000078af20bd2c3a  vmovaps xmm14, [rsp+0x100]
000078af20bd2c43  por xmm11, xmm14
000078af20bd2c48  movaps [r15+0x200], xmm11
000078af20bd2c50  vmovaps [rsp+0x100], xmm5
000078af20bd2c59  vmovaps xmm14, [rsp+0x100]
000078af20bd2c62  por xmm5, xmm14
000078af20bd2c67  movaps [r15+0x2D0], xmm5
000078af20bd2c6f  vmovaps xmm14, [rsp+0x120]
000078af20bd2c78  vmovaps xmm13, [rsp+0x120]
000078af20bd2c81  por xmm14, xmm13
000078af20bd2c86  movaps [r15+0x2E0], xmm14
000078af20bd2c8e  vmovaps [rsp+0x100], xmm1
000078af20bd2c97  vmovaps xmm1, [rsp+0x110]
000078af20bd2ca0  vmovaps [rsp+0x110], xmm15
000078af20bd2ca9  vmovaps xmm15, [rsp+0xD0]
000078af20bd2cb2  vmovaps [rsp+0xD0], xmm14
000078af20bd2cbb  movaps xmm13, xmm1
000078af20bd2cbf  addpd xmm13, xmm15
000078af20bd2cc4  vcmppd xmm14, xmm13, xmm13, 0x03
000078af20bd2cca  ptest xmm14, xmm14
000078af20bd2cd0  jnz 0x000078AF20BD4CBB
000078af20bd2cd6  vmovaps xmm1, [rsp+0xA0]
000078af20bd2cdf  vpermilpd xmm1, xmm1, 0x00
000078af20bd2ce5  vmovaps xmm14, [rsp+0x100]
000078af20bd2cee  vmovaps [rsp+0x100], xmm13
000078af20bd2cf7  movaps xmm15, xmm14
000078af20bd2cfb  mulpd xmm15, xmm1
000078af20bd2d00  vcmppd xmm13, xmm15, xmm15, 0x03
000078af20bd2d06  ptest xmm13, xmm13
000078af20bd2d0c  jnz 0x000078AF20BD4DFE
000078af20bd2d12  lea rax, [r14+0x80]
000078af20bd2d19  movups xmm1, [r13+rax*1]
000078af20bd2d1f  vmovaps xmm13, [rsp+0xE0]
000078af20bd2d28  vmovaps [rsp+0xE0], xmm1
000078af20bd2d31  movaps xmm14, xmm13
000078af20bd2d35  addpd xmm14, xmm2
000078af20bd2d3a  vcmppd xmm1, xmm14, xmm14, 0x03
000078af20bd2d40  ptest xmm1, xmm1
000078af20bd2d45  jnz 0x000078AF20BD4F4B
000078af20bd2d4b  vmovaps xmm13, [rsp+0xF0]
000078af20bd2d54  vmovaps xmm2, [rsp+0x20]
000078af20bd2d5a  vmovaps [rsp+0x20], xmm15
000078af20bd2d60  movaps xmm1, xmm13
000078af20bd2d64  addpd xmm1, xmm2
000078af20bd2d68  vcmppd xmm15, xmm1, xmm1, 0x03
000078af20bd2d6d  ptest xmm15, xmm15
000078af20bd2d73  jnz 0x000078AF20BD508E
000078af20bd2d79  vmovaps xmm15, [rsp+0x10]
000078af20bd2d7f  vmovaps xmm13, [rsp+0x10]
000078af20bd2d85  por xmm15, xmm13
000078af20bd2d8a  movaps [r15+0x2F0], xmm15
000078af20bd2d92  vmovaps xmm13, [rsp+0xA0]
000078af20bd2d9b  vpermilpd xmm13, xmm13, 0x00
000078af20bd2da1  vmovaps [rsp+0x10], xmm1
000078af20bd2da7  vmovaps xmm1, [rsp+0xE0]
000078af20bd2db0  vmovaps [rsp+0xA0], xmm15
000078af20bd2db9  movaps xmm2, xmm1
000078af20bd2dbc  mulpd xmm2, xmm13
000078af20bd2dc1  vcmppd xmm15, xmm2, xmm2, 0x03
000078af20bd2dc6  ptest xmm15, xmm15
000078af20bd2dcc  jnz 0x000078AF20BD51CF
000078af20bd2dd2  lea rax, [r14+0xD0]
000078af20bd2dd9  movups xmm1, [r13+rax*1]
000078af20bd2ddf  vmovaps xmm13, [rsp+0xC0]
000078af20bd2de8  vmovaps [rsp+0xC0], xmm1
000078af20bd2df1  vmovaps xmm1, [rsp+0x110]
000078af20bd2dfa  vmovaps [rsp+0xE0], xmm14
000078af20bd2e03  movaps xmm15, xmm13
000078af20bd2e07  addpd xmm15, xmm1
000078af20bd2e0c  vcmppd xmm14, xmm15, xmm15, 0x03
000078af20bd2e12  ptest xmm14, xmm14
000078af20bd2e18  jnz 0x000078AF20BD531A
000078af20bd2e1e  vmovaps xmm1, [rsp+0xB0]
000078af20bd2e27  vpermilpd xmm1, xmm1, 0x00
000078af20bd2e2d  movaps xmm14, xmm11
000078af20bd2e31  mulpd xmm14, xmm1
000078af20bd2e36  vcmppd xmm13, xmm14, xmm14, 0x03
000078af20bd2e3c  ptest xmm13, xmm13
000078af20bd2e42  jnz 0x000078AF20BD545D
000078af20bd2e48  movaps [r15+0x260], xmm14
000078af20bd2e50  vxorps xmm1, xmm1, xmm1
000078af20bd2e54  vpbroadcastq xmm1, xmm1
000078af20bd2e59  movaps [r15+0x1B0], xmm1
000078af20bd2e61  vmovaps xmm1, [rsp+0xB0]
000078af20bd2e6a  vpermilpd xmm1, xmm1, 0x00
000078af20bd2e70  vmovaps xmm11, [rsp+0xC0]
000078af20bd2e79  vmovaps [rsp+0xC0], xmm15
000078af20bd2e82  movaps xmm13, xmm11
000078af20bd2e86  mulpd xmm13, xmm1
000078af20bd2e8b  vcmppd xmm15, xmm13, xmm13, 0x03
000078af20bd2e91  ptest xmm15, xmm15
000078af20bd2e97  jnz 0x000078AF20BD55A0
000078af20bd2e9d  lea rax, [r14+0xC0]
000078af20bd2ea4  movups xmm1, [r13+rax*1]
000078af20bd2eaa  vmovaps xmm11, [rsp+0x100]
000078af20bd2eb3  vmovaps [rsp+0xF0], xmm1
000078af20bd2ebc  vmovaps xmm1, [rsp+0x20]
000078af20bd2ec2  vmovaps [rsp+0x20], xmm14
000078af20bd2ec8  movaps xmm15, xmm11
000078af20bd2ecc  addpd xmm15, xmm1
000078af20bd2ed1  vcmppd xmm14, xmm15, xmm15, 0x03
000078af20bd2ed7  ptest xmm14, xmm14
000078af20bd2edd  jnz 0x000078AF20BD56ED
000078af20bd2ee3  vmovaps [rsp+0x100], xmm9
000078af20bd2eec  vmovaps xmm1, [rsp+0x100]
000078af20bd2ef5  por xmm9, xmm1
000078af20bd2efa  movaps [r15+0x270], xmm9
000078af20bd2f02  vmovaps [rsp+0x100], xmm6
000078af20bd2f0b  vmovaps xmm1, [rsp+0x100]
000078af20bd2f14  por xmm6, xmm1
000078af20bd2f18  movaps [r15+0x1A0], xmm6
000078af20bd2f20  vmovaps xmm14, [rsp+0xB0]
000078af20bd2f29  vpermilpd xmm14, xmm14, 0x00
000078af20bd2f2f  vmovaps xmm6, [rsp+0xF0]
000078af20bd2f38  vmovaps [rsp+0xF0], xmm1
000078af20bd2f41  movaps xmm11, xmm6
000078af20bd2f45  mulpd xmm11, xmm14
000078af20bd2f4a  vcmppd xmm1, xmm11, xmm11, 0x03
000078af20bd2f50  ptest xmm1, xmm1
000078af20bd2f55  jnz 0x000078AF20BD5830
000078af20bd2f5b  lea rax, [r14+0x20]
000078af20bd2f5f  movups xmm1, [r13+rax*1]
000078af20bd2f65  movaps [r15+0x110], xmm1
000078af20bd2f6d  vmovaps xmm6, [rsp+0xE0]
000078af20bd2f76  vmovaps [rsp+0xE0], xmm1
000078af20bd2f7f  movaps xmm14, xmm6
000078af20bd2f83  addpd xmm14, xmm2
000078af20bd2f88  vcmppd xmm1, xmm14, xmm14, 0x03
000078af20bd2f8e  ptest xmm1, xmm1
000078af20bd2f93  jnz 0x000078AF20BD597D
000078af20bd2f99  vmovaps xmm1, [rsp+0xB0]
000078af20bd2fa2  vpermilpd xmm1, xmm1, 0x00
000078af20bd2fa8  movaps xmm6, xmm5
000078af20bd2fab  mulpd xmm6, xmm1
000078af20bd2faf  vcmppd xmm2, xmm6, xmm6, 0x03
000078af20bd2fb4  ptest xmm2, xmm2
000078af20bd2fb9  jnz 0x000078AF20BD5ABF
000078af20bd2fbf  vmovaps xmm5, [rsp+0x10]
000078af20bd2fc5  movaps xmm1, xmm5
000078af20bd2fc8  addpd xmm1, xmm13
000078af20bd2fcd  vcmppd xmm2, xmm1, xmm1, 0x03
000078af20bd2fd2  ptest xmm2, xmm2
000078af20bd2fd7  jnz 0x000078AF20BD5BFF
000078af20bd2fdd  vmovaps xmm13, [rsp+0x80]
000078af20bd2fe6  vpermilpd xmm13, xmm13, 0x00
000078af20bd2fec  vmovaps xmm2, [rsp+0xE0]
000078af20bd2ff5  vmovaps [rsp+0x10], xmm1
000078af20bd2ffb  movaps xmm5, xmm2
000078af20bd2ffe  mulpd xmm5, xmm13
000078af20bd3003  vcmppd xmm1, xmm5, xmm5, 0x03
000078af20bd3008  ptest xmm1, xmm1
000078af20bd300d  jnz 0x000078AF20BD5D40
000078af20bd3013  vmovaps xmm1, [rsp+0x80]
000078af20bd301c  vpermilpd xmm1, xmm1, 0x00
000078af20bd3022  movaps xmm13, xmm10
000078af20bd3026  mulpd xmm13, xmm1
000078af20bd302b  vcmppd xmm2, xmm13, xmm13, 0x03
000078af20bd3031  ptest xmm2, xmm2
000078af20bd3036  jnz 0x000078AF20BD5E81
000078af20bd303c  vmovaps xmm10, [rsp+0x20]
000078af20bd3042  movaps xmm1, xmm15
000078af20bd3046  addpd xmm1, xmm10
000078af20bd304b  vcmppd xmm2, xmm1, xmm1, 0x03
000078af20bd3050  ptest xmm2, xmm2
000078af20bd3055  jnz 0x000078AF20BD5FC4
000078af20bd305b  vmovaps xmm10, [rsp+0xC0]
000078af20bd3064  movaps xmm15, xmm10
000078af20bd3068  addpd xmm15, xmm11
000078af20bd306d  vcmppd xmm2, xmm15, xmm15, 0x03
000078af20bd3073  ptest xmm2, xmm2
000078af20bd3078  jnz 0x000078AF20BD6106
000078af20bd307e  vmovaps xmm11, [rsp+0x80]
000078af20bd3087  vpermilpd xmm11, xmm11, 0x00
000078af20bd308d  vmovaps xmm2, [rsp+0xD0]
000078af20bd3096  vmovaps [rsp+0x20], xmm1
000078af20bd309c  movaps xmm10, xmm2
000078af20bd30a0  mulpd xmm10, xmm11
000078af20bd30a5  vcmppd xmm1, xmm10, xmm10, 0x03
000078af20bd30ab  ptest xmm1, xmm1
000078af20bd30b0  jnz 0x000078AF20BD624A
000078af20bd30b6  vmovaps xmm1, [rsp+0x80]
000078af20bd30bf  vpermilpd xmm1, xmm1, 0x00
000078af20bd30c5  vmovaps xmm2, [rsp+0xA0]
000078af20bd30ce  vmovaps [rsp+0x80], xmm15
000078af20bd30d7  movaps xmm11, xmm2
000078af20bd30db  mulpd xmm11, xmm1
000078af20bd30e0  vcmppd xmm15, xmm11, xmm11, 0x03
000078af20bd30e6  ptest xmm15, xmm15
000078af20bd30ec  jnz 0x000078AF20BD638D
000078af20bd30f2  movaps xmm1, xmm14
000078af20bd30f6  addpd xmm1, xmm6
000078af20bd30fa  vcmppd xmm15, xmm1, xmm1, 0x03
000078af20bd30ff  ptest xmm15, xmm15
000078af20bd3105  jnz 0x000078AF20BD64CF
000078af20bd310b  vmovaps xmm14, [rsp+0x10]
000078af20bd3111  movaps xmm15, xmm14
000078af20bd3115  addpd xmm15, xmm5
000078af20bd311a  vcmppd xmm6, xmm15, xmm15, 0x03
000078af20bd3120  ptest xmm6, xmm6
000078af20bd3125  jnz 0x000078AF20BD6610
000078af20bd312b  vmovaps xmm14, [rsp+0x90]
000078af20bd3134  vpermilpd xmm14, xmm14, 0x00
000078af20bd313a  movaps xmm6, xmm9
000078af20bd313e  mulpd xmm6, xmm14
000078af20bd3143  vcmppd xmm5, xmm6, xmm6, 0x03
000078af20bd3148  ptest xmm5, xmm5
000078af20bd314d  jnz 0x000078AF20BD6753
000078af20bd3153  vmovaps xmm9, [rsp+0x80]
000078af20bd315c  movaps xmm14, xmm9
000078af20bd3160  addpd xmm14, xmm13
000078af20bd3165  vcmppd xmm5, xmm14, xmm14, 0x03
000078af20bd316b  ptest xmm5, xmm5
000078af20bd3170  jnz 0x000078AF20BD6895
000078af20bd3176  vmovaps xmm9, [rsp+0x20]
000078af20bd317c  movaps xmm13, xmm9
000078af20bd3180  addpd xmm13, xmm10
000078af20bd3185  vcmppd xmm5, xmm13, xmm13, 0x03
000078af20bd318b  ptest xmm5, xmm5
000078af20bd3190  jnz 0x000078AF20BD69D9
000078af20bd3196  vmovaps [rsp+0x10], xmm12
000078af20bd319c  vmovaps xmm10, [rsp+0x10]
000078af20bd31a2  por xmm12, xmm10
000078af20bd31a7  movaps [r15+0x250], xmm12
000078af20bd31af  vmovaps [rsp+0x10], xmm7
000078af20bd31b5  vmovaps xmm12, [rsp+0x10]
000078af20bd31bb  por xmm7, xmm12
000078af20bd31c0  movaps [r15+0x2A0], xmm7
000078af20bd31c8  vmovaps [rsp+0x10], xmm3
000078af20bd31ce  vmovaps xmm12, [rsp+0x10]
000078af20bd31d4  por xmm3, xmm12
000078af20bd31d9  movaps [r15+0x1D0], xmm3
000078af20bd31e1  lea rax, [r14+0x40]
000078af20bd31e5  movups xmm12, [r13+rax*1]
000078af20bd31eb  movaps [r15+0x2C0], xmm12
000078af20bd31f3  vmovaps xmm10, [rsp+0x90]
000078af20bd31fc  vpermilpd xmm10, xmm10, 0x00
000078af20bd3202  movaps xmm9, xmm8
000078af20bd3206  mulpd xmm9, xmm10
000078af20bd320b  vcmppd xmm5, xmm9, xmm9, 0x03
000078af20bd3211  ptest xmm5, xmm5
000078af20bd3216  jnz 0x000078AF20BD6B27
000078af20bd321c  movaps xmm10, xmm1
000078af20bd3220  addpd xmm10, xmm11
000078af20bd3225  vcmppd xmm8, xmm10, xmm10, 0x03
000078af20bd322b  ptest xmm8, xmm8
000078af20bd3231  jnz 0x000078AF20BD6C6B
000078af20bd3237  movaps xmm1, xmm15
000078af20bd323b  addpd xmm1, xmm6
000078af20bd323f  vcmppd xmm11, xmm1, xmm1, 0x03
000078af20bd3244  ptest xmm11, xmm11
000078af20bd324a  jnz 0x000078AF20BD6DAE
000078af20bd3250  vmovaps xmm15, [rsp+0x90]
000078af20bd3259  vpermilpd xmm15, xmm15, 0x00
000078af20bd325f  movaps xmm11, xmm12
000078af20bd3263  mulpd xmm11, xmm15
000078af20bd3268  vcmppd xmm8, xmm11, xmm11, 0x03
000078af20bd326e  ptest xmm8, xmm8
000078af20bd3274  jnz 0x000078AF20BD6EEF
000078af20bd327a  vmovaps xmm15, [rsp+0x90]
000078af20bd3283  vpermilpd xmm15, xmm15, 0x00
000078af20bd3289  vmovaps xmm8, [rsp+0x50]
000078af20bd328f  movaps xmm12, xmm8
000078af20bd3293  mulpd xmm12, xmm15
000078af20bd3298  vcmppd xmm6, xmm12, xmm12, 0x03
000078af20bd329e  ptest xmm6, xmm6
000078af20bd32a3  jnz 0x000078AF20BD7033
000078af20bd32a9  vmovaps xmm15, [rsp+0x30]
000078af20bd32af  vpermilpd xmm15, xmm15, 0x00
000078af20bd32b5  movaps xmm8, xmm7
000078af20bd32b9  mulpd xmm8, xmm15
000078af20bd32be  vcmppd xmm6, xmm8, xmm8, 0x03
000078af20bd32c4  ptest xmm6, xmm6
000078af20bd32c9  jnz 0x000078AF20BD7177
000078af20bd32cf  movaps xmm15, xmm14
000078af20bd32d3  addpd xmm15, xmm9
000078af20bd32d8  vcmppd xmm7, xmm15, xmm15, 0x03
000078af20bd32de  ptest xmm7, xmm7
000078af20bd32e3  jnz 0x000078AF20BD72BA
000078af20bd32e9  vmovaps xmm14, [rsp+0x30]
000078af20bd32ef  vpermilpd xmm14, xmm14, 0x00
000078af20bd32f5  vmovaps xmm7, [rsp+0xF0]
000078af20bd32fe  movaps xmm9, xmm7
000078af20bd3302  mulpd xmm9, xmm14
000078af20bd3307  vcmppd xmm6, xmm9, xmm9, 0x03
000078af20bd330d  ptest xmm6, xmm6
000078af20bd3312  jnz 0x000078AF20BD73FE
000078af20bd3318  movaps xmm14, xmm13
000078af20bd331c  addpd xmm14, xmm11
000078af20bd3321  vcmppd xmm7, xmm14, xmm14, 0x03
000078af20bd3327  ptest xmm7, xmm7
000078af20bd332c  jnz 0x000078AF20BD7541
000078af20bd3332  vmovaps xmm13, [rsp+0x30]
000078af20bd3338  vpermilpd xmm13, xmm13, 0x00
000078af20bd333e  vmovaps xmm7, [rsp+0x60]
000078af20bd3344  movaps xmm11, xmm7
000078af20bd3348  mulpd xmm11, xmm13
000078af20bd334d  vcmppd xmm6, xmm11, xmm11, 0x03
000078af20bd3353  ptest xmm6, xmm6
000078af20bd3358  jnz 0x000078AF20BD7685
000078af20bd335e  movaps xmm13, xmm10
000078af20bd3362  addpd xmm13, xmm12
000078af20bd3367  vcmppd xmm7, xmm13, xmm13, 0x03
000078af20bd336d  ptest xmm7, xmm7
000078af20bd3372  jnz 0x000078AF20BD77C8
000078af20bd3378  vmovaps xmm12, [rsp+0x30]
000078af20bd337e  vpermilpd xmm12, xmm12, 0x00
000078af20bd3384  vmovaps xmm7, [rsp+0x70]
000078af20bd338a  movaps xmm10, xmm7
000078af20bd338e  mulpd xmm10, xmm12
000078af20bd3393  vcmppd xmm6, xmm10, xmm10, 0x03
000078af20bd3399  ptest xmm6, xmm6
000078af20bd339e  jnz 0x000078AF20BD790C
000078af20bd33a4  movaps xmm12, xmm1
000078af20bd33a8  addpd xmm12, xmm8
000078af20bd33ad  vcmppd xmm7, xmm12, xmm12, 0x03
000078af20bd33b3  ptest xmm7, xmm7
000078af20bd33b8  jnz 0x000078AF20BD7A4F
000078af20bd33be  lea rax, [r14+0x70]
000078af20bd33c2  movups xmm1, [r13+rax*1]
000078af20bd33c8  movaps [r15+0x240], xmm1
000078af20bd33d0  movaps xmm8, xmm15
000078af20bd33d4  addpd xmm8, xmm9
000078af20bd33d9  vcmppd xmm7, xmm8, xmm8, 0x03
000078af20bd33df  ptest xmm7, xmm7
000078af20bd33e4  jnz 0x000078AF20BD7B9C
000078af20bd33ea  movaps [r15+0x170], xmm8
000078af20bd33f2  vmovaps xmm15, [rsp+0x40]
000078af20bd33f8  vpermilpd xmm15, xmm15, 0x00
000078af20bd33fe  movaps xmm9, xmm1
000078af20bd3402  mulpd xmm9, xmm15
000078af20bd3407  vcmppd xmm7, xmm9, xmm9, 0x03
000078af20bd340d  ptest xmm7, xmm7
000078af20bd3412  jnz 0x000078AF20BD7CE0
000078af20bd3418  vmovaps xmm1, [rsp+0x40]
000078af20bd341e  vpermilpd xmm1, xmm1, 0x00
000078af20bd3424  movaps xmm15, xmm4
000078af20bd3428  mulpd xmm15, xmm1
000078af20bd342d  vcmppd xmm7, xmm15, xmm15, 0x03
000078af20bd3433  ptest xmm7, xmm7
000078af20bd3438  jnz 0x000078AF20BD7E23
000078af20bd343e  movaps [r15+0x180], xmm15
000078af20bd3446  movaps xmm1, xmm14
000078af20bd344a  addpd xmm1, xmm11
000078af20bd344f  vcmppd xmm7, xmm1, xmm1, 0x03
000078af20bd3454  ptest xmm7, xmm7
000078af20bd3459  jnz 0x000078AF20BD7F65
000078af20bd345f  movaps [r15+0x210], xmm1
000078af20bd3467  movups xmm14, [r13+r14*1]
000078af20bd346d  lea rax, [r14+0x10]
000078af20bd3471  movups xmm11, [r13+rax*1]
000078af20bd3477  movaps [r15+0x230], xmm11
000078af20bd347f  movaps xmm7, xmm13
000078af20bd3483  addpd xmm7, xmm10
000078af20bd3488  vcmppd xmm6, xmm7, xmm7, 0x03
000078af20bd348d  ptest xmm6, xmm6
000078af20bd3492  jnz 0x000078AF20BD80BB
000078af20bd3498  movaps [r15+0x130], xmm7
000078af20bd34a0  vmovaps xmm13, [rsp+0x40]
000078af20bd34a6  vpermilpd xmm13, xmm13, 0x00
000078af20bd34ac  movaps xmm10, xmm11
000078af20bd34b0  mulpd xmm10, xmm13
000078af20bd34b5  vcmppd xmm6, xmm10, xmm10, 0x03
000078af20bd34bb  ptest xmm6, xmm6
000078af20bd34c0  jnz 0x000078AF20BD81FD
000078af20bd34c6  movaps [r15+0x220], xmm10
000078af20bd34ce  vmovaps xmm13, [rsp+0x40]
000078af20bd34d4  vpermilpd xmm13, xmm13, 0x00
000078af20bd34da  movaps xmm11, xmm14
000078af20bd34de  mulpd xmm11, xmm13
000078af20bd34e3  vcmppd xmm6, xmm11, xmm11, 0x03
000078af20bd34e9  ptest xmm6, xmm6
000078af20bd34ee  jnz 0x000078AF20BD8341
000078af20bd34f4  movaps xmm14, xmm12
000078af20bd34f8  addpd xmm14, xmm9
000078af20bd34fd  vcmppd xmm13, xmm14, xmm14, 0x03
000078af20bd3503  ptest xmm13, xmm13
000078af20bd3509  jnz 0x000078AF20BD8485
000078af20bd350f  movaps [r15+0x140], xmm14
000078af20bd3517  movaps xmm13, xmm8
000078af20bd351b  addpd xmm13, xmm15
000078af20bd3520  vcmppd xmm12, xmm13, xmm13, 0x03
000078af20bd3526  ptest xmm12, xmm12
000078af20bd352c  jnz 0x000078AF20BD85C9
000078af20bd3532  movaps [r15+0x150], xmm13
000078af20bd353a  movaps xmm15, xmm1
000078af20bd353e  addpd xmm15, xmm10
000078af20bd3543  vcmppd xmm12, xmm15, xmm15, 0x03
000078af20bd3549  ptest xmm12, xmm12
000078af20bd354f  jnz 0x000078AF20BD870D
000078af20bd3555  movaps [r15+0x160], xmm15
000078af20bd355d  movaps xmm1, xmm7
000078af20bd3560  addpd xmm1, xmm11
000078af20bd3565  vcmppd xmm12, xmm1, xmm1, 0x03
000078af20bd356a  ptest xmm12, xmm12
000078af20bd3570  jnz 0x000078AF20BD8850
000078af20bd3576  movaps [r15+0x120], xmm1
000078af20bd357e  mov eax, 0x432200
000078af20bd3583  movups [r13+rax*1], xmm14
000078af20bd3589  mov eax, 0x432210
000078af20bd358e  movups [r13+rax*1], xmm13
000078af20bd3594  mov eax, 0x432220
000078af20bd3599  movups [r13+rax*1], xmm15
000078af20bd359f  mov eax, 0x432230
000078af20bd35a4  movups [r13+rax*1], xmm1
000078af20bd35aa  mov eax, [r15+0x108]
000078af20bd35b1  sahf
000078af20bd35b2  jnz 0x000078AF20BD35E4
000078af20bd35b4  cmp dword ptr [r15+0x318], 0x00
000078af20bd35bc  jz 0x000078AF20BDEAE0
000078af20bd35c2  nop [rax+rax*1], ax
000078af20bd35cb  nop [rax+rax*1], eax
000078af20bd35d3  mov eax, 0x4106D0
000078af20bd35d8  mov [r15+0x100], rax
000078af20bd35df  jmp 0x000078AF209FE110
000078af20bd35e4  cmp dword ptr [r15+0x318], 0x00
000078af20bd35ec  jz 0x000078AF20BD89C0
000078af20bd35f2  nop [rax+rax*1], ax
000078af20bd35fb  nop [rax+rax*1], eax
000078af20bd3603  mov eax, 0x410504
000078af20bd3608  mov [r15+0x100], rax
000078af20bd360f  jmp 0x000078AF209FE110
000078af20bd3614  int3
000078af20bd3615  call 0x000078AF20AD64F0
000078af20bd361a  jmp 0x000078AF20BD2311
000078af20bd361f  call 0x000078AF20AE5820
000078af20bd3624  jmp 0x000078AF20BD231E
000078af20bd3629  call 0x000078AF20AE3320
000078af20bd362e  jmp 0x000078AF20BD2332
000078af20bd3633  call 0x000078AF20AE20A0
000078af20bd3638  jmp 0x000078AF20BD233C
000078af20bd363d  call 0x000078AF20A09D70
000078af20bd3642  jmp 0x000078AF20BD234A
000078af20bd3647  call 0x000078AF20ADFBC0
000078af20bd364c  jmp 0x000078AF20BD2354
000078af20bd3651  call 0x000078AF20AC4740
000078af20bd3656  jmp 0x000078AF20BD2368
000078af20bd365b  call 0x000078AF20AB5400
000078af20bd3660  jmp 0x000078AF20BD2375
000078af20bd3665  call 0x000078AF20AB52F0
000078af20bd366a  jmp 0x000078AF20BD2382
000078af20bd366f  call 0x000078AF20AC4620
000078af20bd3674  jmp 0x000078AF20BD238F
000078af20bd3679  call 0x000078AF20ABD750
000078af20bd367e  jmp 0x000078AF20BD239C
000078af20bd3683  call 0x000078AF20ABC4E0
000078af20bd3688  jmp 0x000078AF20BD23A9
000078af20bd368d  call 0x000078AF20ABB270
000078af20bd3692  jmp 0x000078AF20BD23B6
000078af20bd3697  call 0x000078AF20ABA000
000078af20bd369c  jmp 0x000078AF20BD23C3
000078af20bd36a1  call 0x000078AF20AC4740
000078af20bd36a6  jmp 0x000078AF20BD23D0
000078af20bd36ab  call 0x000078AF20AB5400
000078af20bd36b0  jmp 0x000078AF20BD23DD
000078af20bd36b5  call 0x000078AF20AB52F0
000078af20bd36ba  jmp 0x000078AF20BD23EA
000078af20bd36bf  call 0x000078AF20AC4620
000078af20bd36c4  jmp 0x000078AF20BD23F7
000078af20bd36c9  call 0x000078AF20AB8D90
000078af20bd36ce  jmp 0x000078AF20BD2404
000078af20bd36d3  call 0x000078AF20AB8A20
000078af20bd36d8  jmp 0x000078AF20BD2411
000078af20bd36dd  call 0x000078AF20AB77B0
000078af20bd36e2  jmp 0x000078AF20BD241B
000078af20bd36e7  call 0x000078AF20AB6550
000078af20bd36ec  jmp 0x000078AF20BD2425
000078af20bd36f1  call 0x000078AF20AB5400
000078af20bd36f6  jmp 0x000078AF20BD2437
000078af20bd36fb  call 0x000078AF20AC0FC0
000078af20bd3700  jmp 0x000078AF20BD2441
000078af20bd3705  call 0x000078AF20AB52F0
000078af20bd370a  jmp 0x000078AF20BD244B
000078af20bd370f  call 0x000078AF20AC0EA0
000078af20bd3714  jmp 0x000078AF20BD2455
000078af20bd3719  call 0x000078AF20ABFD50
000078af20bd371e  jmp 0x000078AF20BD245F
000078af20bd3723  call 0x000078AF20AB8EA0
000078af20bd3728  jmp 0x000078AF20BD2469
000078af20bd372d  call 0x000078AF20ABFC30
000078af20bd3732  jmp 0x000078AF20BD2476
000078af20bd3737  call 0x000078AF20AB8D90
000078af20bd373c  jmp 0x000078AF20BD2483
000078af20bd3741  call 0x000078AF20AB52F0
000078af20bd3746  jmp 0x000078AF20BD2496
000078af20bd374b  call 0x000078AF20AB52F0
000078af20bd3750  jmp 0x000078AF20BD24A9
000078af20bd3755  call 0x000078AF20AC0FC0
000078af20bd375a  jmp 0x000078AF20BD24B6
000078af20bd375f  call 0x000078AF20AC0FC0
000078af20bd3764  jmp 0x000078AF20BD24C9
000078af20bd3769  call 0x000078AF20AC0EA0
000078af20bd376e  jmp 0x000078AF20BD24D6
000078af20bd3773  call 0x000078AF20AB52F0
000078af20bd3778  jmp 0x000078AF20BD24E9
000078af20bd377d  call 0x000078AF20AB52F0
000078af20bd3782  jmp 0x000078AF20BD24FC
000078af20bd3787  call 0x000078AF20AB52F0
000078af20bd378c  jmp 0x000078AF20BD250F
000078af20bd3791  call 0x000078AF20AB52F0
000078af20bd3796  jmp 0x000078AF20BD252A
000078af20bd379b  call 0x000078AF20AB52F0
000078af20bd37a0  jmp 0x000078AF20BD253D
000078af20bd37a5  call 0x000078AF20AB5400
000078af20bd37aa  jmp 0x000078AF20BD257E
000078af20bd37af  call 0x000078AF20AC0FC0
000078af20bd37b4  jmp 0x000078AF20BD258B
000078af20bd37b9  call 0x000078AF20AB52F0
000078af20bd37be  jmp 0x000078AF20BD2598
000078af20bd37c3  call 0x000078AF20AC0EA0
000078af20bd37c8  jmp 0x000078AF20BD25A5
000078af20bd37cd  call 0x000078AF209FF540
000078af20bd37d2  jmp 0x000078AF20BD25C3
000078af20bd37d7  call 0x000078AF20A08C20
000078af20bd37dc  jmp 0x000078AF20BD25CD
000078af20bd37e1  call 0x000078AF20AE21C0
000078af20bd37e6  jmp 0x000078AF20BD25D3
000078af20bd37eb  call 0x000078AF209FF540
000078af20bd37f0  jmp 0x000078AF20BD25E3
000078af20bd37f5  call 0x000078AF20AC0370
000078af20bd37fa  jmp 0x000078AF20BD2611
000078af20bd37ff  call 0x000078AF20ABF100
000078af20bd3804  jmp 0x000078AF20BD261A
000078af20bd3809  call 0x000078AF20AC0370
000078af20bd380e  jmp 0x000078AF20BD2674
000078af20bd3813  call 0x000078AF20ABF100
000078af20bd3818  jmp 0x000078AF20BD267D
000078af20bd381d  call 0x000078AF20AC0370
000078af20bd3822  jmp 0x000078AF20BD26C6
000078af20bd3827  call 0x000078AF20ABF100
000078af20bd382c  jmp 0x000078AF20BD26CF
000078af20bd3831  call 0x000078AF20A0B720
000078af20bd3836  jmp 0x000078AF20BD2714
000078af20bd383b  call 0x000078AF20AB47C0
000078af20bd3840  jmp 0x000078AF20BD2727
000078af20bd3845  call 0x000078AF20A08B00
000078af20bd384a  jmp 0x000078AF20BD273E
000078af20bd384f  call 0x000078AF209FF430
000078af20bd3854  jmp 0x000078AF20BD2751
000078af20bd3859  call 0x000078AF209FF430
000078af20bd385e  jmp 0x000078AF20BD2764
000078af20bd3863  sub rsp, 0x08
000078af20bd3867  push rax
000078af20bd3868  push rcx
000078af20bd3869  push rdx
000078af20bd386a  push rdi
000078af20bd386b  push rsi
000078af20bd386c  push r8
000078af20bd386e  push r9
000078af20bd3870  push r10
000078af20bd3872  push r11
000078af20bd3874  sub rsp, 0xF0
000078af20bd387b  vmovaps [rsp], xmm0
000078af20bd3880  vmovaps [rsp+0x10], xmm2
000078af20bd3886  vmovaps [rsp+0x20], xmm3
000078af20bd388c  vmovaps [rsp+0x30], xmm4
000078af20bd3892  vmovaps [rsp+0x40], xmm5
000078af20bd3898  vmovaps [rsp+0x50], xmm6
000078af20bd389e  vmovaps [rsp+0x60], xmm7
000078af20bd38a4  vmovaps [rsp+0x70], xmm8
000078af20bd38aa  vmovaps [rsp+0x80], xmm9
000078af20bd38b3  vmovaps [rsp+0x90], xmm10
000078af20bd38bc  vmovaps [rsp+0xA0], xmm11
000078af20bd38c5  vmovaps [rsp+0xB0], xmm12
000078af20bd38ce  vmovaps [rsp+0xC0], xmm13
000078af20bd38d7  vmovaps [rsp+0xD0], xmm14
000078af20bd38e0  vmovaps [rsp+0xE0], xmm15
000078af20bd38e9  sub rsp, 0x30
000078af20bd38ed  movaps [rsp], xmm1
000078af20bd38f1  movaps [rsp+0x10], xmm12
000078af20bd38f7  movaps [rsp+0x20], xmm15
000078af20bd38fd  lea rdi, [rsp]
000078af20bd3901  mov esi, 0x00
000078af20bd3906  mov rax, 0x65452FFB8530
000078af20bd3910  call rax
000078af20bd3912  movaps xmm1, [rsp]
000078af20bd3916  add rsp, 0x30
000078af20bd391a  vmovaps xmm0, [rsp]
000078af20bd391f  vmovaps xmm2, [rsp+0x10]
000078af20bd3925  vmovaps xmm3, [rsp+0x20]
000078af20bd392b  vmovaps xmm4, [rsp+0x30]
000078af20bd3931  vmovaps xmm5, [rsp+0x40]
000078af20bd3937  vmovaps xmm6, [rsp+0x50]
000078af20bd393d  vmovaps xmm7, [rsp+0x60]
000078af20bd3943  vmovaps xmm8, [rsp+0x70]
000078af20bd3949  vmovaps xmm9, [rsp+0x80]
000078af20bd3952  vmovaps xmm10, [rsp+0x90]
000078af20bd395b  vmovaps xmm11, [rsp+0xA0]
000078af20bd3964  vmovaps xmm12, [rsp+0xB0]
000078af20bd396d  vmovaps xmm13, [rsp+0xC0]
000078af20bd3976  vmovaps xmm14, [rsp+0xD0]
000078af20bd397f  vmovaps xmm15, [rsp+0xE0]
000078af20bd3988  add rsp, 0xF0
000078af20bd398f  pop r11
000078af20bd3991  pop r10
000078af20bd3993  pop r9
000078af20bd3995  pop r8
000078af20bd3997  pop rsi
000078af20bd3998  pop rdi
000078af20bd3999  pop rdx
000078af20bd399a  pop rcx
000078af20bd399b  pop rax
000078af20bd399c  add rsp, 0x08
000078af20bd39a0  jmp 0x000078AF20BD27B2
000078af20bd39a5  sub rsp, 0x08
000078af20bd39a9  push rax
000078af20bd39aa  push rcx
000078af20bd39ab  push rdx
000078af20bd39ac  push rdi
000078af20bd39ad  push rsi
000078af20bd39ae  push r8
000078af20bd39b0  push r9
000078af20bd39b2  push r10
000078af20bd39b4  push r11
000078af20bd39b6  sub rsp, 0xF0
000078af20bd39bd  vmovaps [rsp], xmm0
000078af20bd39c2  vmovaps [rsp+0x10], xmm1
000078af20bd39c8  vmovaps [rsp+0x20], xmm2
000078af20bd39ce  vmovaps [rsp+0x30], xmm3
000078af20bd39d4  vmovaps [rsp+0x40], xmm4
000078af20bd39da  vmovaps [rsp+0x50], xmm5
000078af20bd39e0  vmovaps [rsp+0x60], xmm6
000078af20bd39e6  vmovaps [rsp+0x70], xmm7
000078af20bd39ec  vmovaps [rsp+0x80], xmm8
000078af20bd39f5  vmovaps [rsp+0x90], xmm9
000078af20bd39fe  vmovaps [rsp+0xA0], xmm10
000078af20bd3a07  vmovaps [rsp+0xB0], xmm11
000078af20bd3a10  vmovaps [rsp+0xC0], xmm12
000078af20bd3a19  vmovaps [rsp+0xD0], xmm13
000078af20bd3a22  vmovaps [rsp+0xE0], xmm15
000078af20bd3a2b  sub rsp, 0x30
000078af20bd3a2f  movaps [rsp], xmm14
000078af20bd3a34  movaps [rsp+0x10], xmm1
000078af20bd3a39  movaps [rsp+0x20], xmm15
000078af20bd3a3f  lea rdi, [rsp]
000078af20bd3a43  mov esi, 0x00
000078af20bd3a48  mov rax, 0x65452FFB8530
000078af20bd3a52  call rax
000078af20bd3a54  movaps xmm14, [rsp]
000078af20bd3a59  add rsp, 0x30
000078af20bd3a5d  vmovaps xmm0, [rsp]
000078af20bd3a62  vmovaps xmm1, [rsp+0x10]
000078af20bd3a68  vmovaps xmm2, [rsp+0x20]
000078af20bd3a6e  vmovaps xmm3, [rsp+0x30]
000078af20bd3a74  vmovaps xmm4, [rsp+0x40]
000078af20bd3a7a  vmovaps xmm5, [rsp+0x50]
000078af20bd3a80  vmovaps xmm6, [rsp+0x60]
000078af20bd3a86  vmovaps xmm7, [rsp+0x70]
000078af20bd3a8c  vmovaps xmm8, [rsp+0x80]
000078af20bd3a95  vmovaps xmm9, [rsp+0x90]
000078af20bd3a9e  vmovaps xmm10, [rsp+0xA0]
000078af20bd3aa7  vmovaps xmm11, [rsp+0xB0]
000078af20bd3ab0  vmovaps xmm12, [rsp+0xC0]
000078af20bd3ab9  vmovaps xmm13, [rsp+0xD0]
000078af20bd3ac2  vmovaps xmm15, [rsp+0xE0]
000078af20bd3acb  add rsp, 0xF0
000078af20bd3ad2  pop r11
000078af20bd3ad4  pop r10
000078af20bd3ad6  pop r9
000078af20bd3ad8  pop r8
000078af20bd3ada  pop rsi
000078af20bd3adb  pop rdi
000078af20bd3adc  pop rdx
000078af20bd3add  pop rcx
000078af20bd3ade  pop rax
000078af20bd3adf  add rsp, 0x08
000078af20bd3ae3  jmp 0x000078AF20BD2800
000078af20bd3ae8  sub rsp, 0x08
000078af20bd3aec  push rax
000078af20bd3aed  push rcx
000078af20bd3aee  push rdx
000078af20bd3aef  push rdi
000078af20bd3af0  push rsi
000078af20bd3af1  push r8
000078af20bd3af3  push r9
000078af20bd3af5  push r10
000078af20bd3af7  push r11
000078af20bd3af9  sub rsp, 0xF0
000078af20bd3b00  vmovaps [rsp], xmm0
000078af20bd3b05  vmovaps [rsp+0x10], xmm1
000078af20bd3b0b  vmovaps [rsp+0x20], xmm2
000078af20bd3b11  vmovaps [rsp+0x30], xmm3
000078af20bd3b17  vmovaps [rsp+0x40], xmm4
000078af20bd3b1d  vmovaps [rsp+0x50], xmm5
000078af20bd3b23  vmovaps [rsp+0x60], xmm6
000078af20bd3b29  vmovaps [rsp+0x70], xmm7
000078af20bd3b2f  vmovaps [rsp+0x80], xmm8
000078af20bd3b38  vmovaps [rsp+0x90], xmm9
000078af20bd3b41  vmovaps [rsp+0xA0], xmm10
000078af20bd3b4a  vmovaps [rsp+0xB0], xmm11
000078af20bd3b53  vmovaps [rsp+0xC0], xmm12
000078af20bd3b5c  vmovaps [rsp+0xD0], xmm13
000078af20bd3b65  vmovaps [rsp+0xE0], xmm14
000078af20bd3b6e  sub rsp, 0x30
000078af20bd3b72  movaps [rsp], xmm15
000078af20bd3b77  movaps [rsp+0x10], xmm12
000078af20bd3b7d  movaps [rsp+0x20], xmm13
000078af20bd3b83  lea rdi, [rsp]
000078af20bd3b87  mov esi, 0x00
000078af20bd3b8c  mov rax, 0x65452FFB8530
000078af20bd3b96  call rax
000078af20bd3b98  movaps xmm15, [rsp]
000078af20bd3b9d  add rsp, 0x30
000078af20bd3ba1  vmovaps xmm0, [rsp]
000078af20bd3ba6  vmovaps xmm1, [rsp+0x10]
000078af20bd3bac  vmovaps xmm2, [rsp+0x20]
000078af20bd3bb2  vmovaps xmm3, [rsp+0x30]
000078af20bd3bb8  vmovaps xmm4, [rsp+0x40]
000078af20bd3bbe  vmovaps xmm5, [rsp+0x50]
000078af20bd3bc4  vmovaps xmm6, [rsp+0x60]
000078af20bd3bca  vmovaps xmm7, [rsp+0x70]
000078af20bd3bd0  vmovaps xmm8, [rsp+0x80]
000078af20bd3bd9  vmovaps xmm9, [rsp+0x90]
000078af20bd3be2  vmovaps xmm10, [rsp+0xA0]
000078af20bd3beb  vmovaps xmm11, [rsp+0xB0]
000078af20bd3bf4  vmovaps xmm12, [rsp+0xC0]
000078af20bd3bfd  vmovaps xmm13, [rsp+0xD0]
000078af20bd3c06  vmovaps xmm14, [rsp+0xE0]
000078af20bd3c0f  add rsp, 0xF0
000078af20bd3c16  pop r11
000078af20bd3c18  pop r10
000078af20bd3c1a  pop r9
000078af20bd3c1c  pop r8
000078af20bd3c1e  pop rsi
000078af20bd3c1f  pop rdi
000078af20bd3c20  pop rdx
000078af20bd3c21  pop rcx
000078af20bd3c22  pop rax
000078af20bd3c23  add rsp, 0x08
000078af20bd3c27  jmp 0x000078AF20BD2835
000078af20bd3c2c  sub rsp, 0x08
000078af20bd3c30  push rax
000078af20bd3c31  push rcx
000078af20bd3c32  push rdx
000078af20bd3c33  push rdi
000078af20bd3c34  push rsi
000078af20bd3c35  push r8
000078af20bd3c37  push r9
000078af20bd3c39  push r10
000078af20bd3c3b  push r11
000078af20bd3c3d  sub rsp, 0xF0
000078af20bd3c44  vmovaps [rsp], xmm0
000078af20bd3c49  vmovaps [rsp+0x10], xmm2
000078af20bd3c4f  vmovaps [rsp+0x20], xmm3
000078af20bd3c55  vmovaps [rsp+0x30], xmm4
000078af20bd3c5b  vmovaps [rsp+0x40], xmm5
000078af20bd3c61  vmovaps [rsp+0x50], xmm6
000078af20bd3c67  vmovaps [rsp+0x60], xmm7
000078af20bd3c6d  vmovaps [rsp+0x70], xmm8
000078af20bd3c73  vmovaps [rsp+0x80], xmm9
000078af20bd3c7c  vmovaps [rsp+0x90], xmm10
000078af20bd3c85  vmovaps [rsp+0xA0], xmm11
000078af20bd3c8e  vmovaps [rsp+0xB0], xmm12
000078af20bd3c97  vmovaps [rsp+0xC0], xmm13
000078af20bd3ca0  vmovaps [rsp+0xD0], xmm14
000078af20bd3ca9  vmovaps [rsp+0xE0], xmm15
000078af20bd3cb2  sub rsp, 0x30
000078af20bd3cb6  movaps [rsp], xmm1
000078af20bd3cba  movaps [rsp+0x10], xmm12
000078af20bd3cc0  movaps [rsp+0x20], xmm10
000078af20bd3cc6  lea rdi, [rsp]
000078af20bd3cca  mov esi, 0x00
000078af20bd3ccf  mov rax, 0x65452FFB8530
000078af20bd3cd9  call rax
000078af20bd3cdb  movaps xmm1, [rsp]
000078af20bd3cdf  add rsp, 0x30
000078af20bd3ce3  vmovaps xmm0, [rsp]
000078af20bd3ce8  vmovaps xmm2, [rsp+0x10]
000078af20bd3cee  vmovaps xmm3, [rsp+0x20]
000078af20bd3cf4  vmovaps xmm4, [rsp+0x30]
000078af20bd3cfa  vmovaps xmm5, [rsp+0x40]
000078af20bd3d00  vmovaps xmm6, [rsp+0x50]
000078af20bd3d06  vmovaps xmm7, [rsp+0x60]
000078af20bd3d0c  vmovaps xmm8, [rsp+0x70]
000078af20bd3d12  vmovaps xmm9, [rsp+0x80]
000078af20bd3d1b  vmovaps xmm10, [rsp+0x90]
000078af20bd3d24  vmovaps xmm11, [rsp+0xA0]
000078af20bd3d2d  vmovaps xmm12, [rsp+0xB0]
000078af20bd3d36  vmovaps xmm13, [rsp+0xC0]
000078af20bd3d3f  vmovaps xmm14, [rsp+0xD0]
000078af20bd3d48  vmovaps xmm15, [rsp+0xE0]
000078af20bd3d51  add rsp, 0xF0
000078af20bd3d58  pop r11
000078af20bd3d5a  pop r10
000078af20bd3d5c  pop r9
000078af20bd3d5e  pop r8
000078af20bd3d60  pop rsi
000078af20bd3d61  pop rdi
000078af20bd3d62  pop rdx
000078af20bd3d63  pop rcx
000078af20bd3d64  pop rax
000078af20bd3d65  add rsp, 0x08
000078af20bd3d69  jmp 0x000078AF20BD284F
000078af20bd3d6e  sub rsp, 0x08
000078af20bd3d72  push rax
000078af20bd3d73  push rcx
000078af20bd3d74  push rdx
000078af20bd3d75  push rdi
000078af20bd3d76  push rsi
000078af20bd3d77  push r8
000078af20bd3d79  push r9
000078af20bd3d7b  push r10
000078af20bd3d7d  push r11
000078af20bd3d7f  sub rsp, 0xF0
000078af20bd3d86  vmovaps [rsp], xmm0
000078af20bd3d8b  vmovaps [rsp+0x10], xmm1
000078af20bd3d91  vmovaps [rsp+0x20], xmm2
000078af20bd3d97  vmovaps [rsp+0x30], xmm3
000078af20bd3d9d  vmovaps [rsp+0x40], xmm4
000078af20bd3da3  vmovaps [rsp+0x50], xmm5
000078af20bd3da9  vmovaps [rsp+0x60], xmm6
000078af20bd3daf  vmovaps [rsp+0x70], xmm7
000078af20bd3db5  vmovaps [rsp+0x80], xmm8
000078af20bd3dbe  vmovaps [rsp+0x90], xmm9
000078af20bd3dc7  vmovaps [rsp+0xA0], xmm10
000078af20bd3dd0  vmovaps [rsp+0xB0], xmm11
000078af20bd3dd9  vmovaps [rsp+0xC0], xmm12
000078af20bd3de2  vmovaps [rsp+0xD0], xmm14
000078af20bd3deb  vmovaps [rsp+0xE0], xmm15
000078af20bd3df4  sub rsp, 0x30
000078af20bd3df8  movaps [rsp], xmm13
000078af20bd3dfd  movaps [rsp+0x10], xmm12
000078af20bd3e03  movaps [rsp+0x20], xmm2
000078af20bd3e08  lea rdi, [rsp]
000078af20bd3e0c  mov esi, 0x00
000078af20bd3e11  mov rax, 0x65452FFB8530
000078af20bd3e1b  call rax
000078af20bd3e1d  movaps xmm13, [rsp]
000078af20bd3e22  add rsp, 0x30
000078af20bd3e26  vmovaps xmm0, [rsp]
000078af20bd3e2b  vmovaps xmm1, [rsp+0x10]
000078af20bd3e31  vmovaps xmm2, [rsp+0x20]
000078af20bd3e37  vmovaps xmm3, [rsp+0x30]
000078af20bd3e3d  vmovaps xmm4, [rsp+0x40]
000078af20bd3e43  vmovaps xmm5, [rsp+0x50]
000078af20bd3e49  vmovaps xmm6, [rsp+0x60]
000078af20bd3e4f  vmovaps xmm7, [rsp+0x70]
000078af20bd3e55  vmovaps xmm8, [rsp+0x80]
000078af20bd3e5e  vmovaps xmm9, [rsp+0x90]
000078af20bd3e67  vmovaps xmm10, [rsp+0xA0]
000078af20bd3e70  vmovaps xmm11, [rsp+0xB0]
000078af20bd3e79  vmovaps xmm12, [rsp+0xC0]
000078af20bd3e82  vmovaps xmm14, [rsp+0xD0]
000078af20bd3e8b  vmovaps xmm15, [rsp+0xE0]
000078af20bd3e94  add rsp, 0xF0
000078af20bd3e9b  pop r11
000078af20bd3e9d  pop r10
000078af20bd3e9f  pop r9
000078af20bd3ea1  pop r8
000078af20bd3ea3  pop rsi
000078af20bd3ea4  pop rdi
000078af20bd3ea5  pop rdx
000078af20bd3ea6  pop rcx
000078af20bd3ea7  pop rax
000078af20bd3ea8  add rsp, 0x08
000078af20bd3eac  jmp 0x000078AF20BD286A
000078af20bd3eb1  sub rsp, 0x08
000078af20bd3eb5  push rax
000078af20bd3eb6  push rcx
000078af20bd3eb7  push rdx
000078af20bd3eb8  push rdi
000078af20bd3eb9  push rsi
000078af20bd3eba  push r8
000078af20bd3ebc  push r9
000078af20bd3ebe  push r10
000078af20bd3ec0  push r11
000078af20bd3ec2  sub rsp, 0xF0
000078af20bd3ec9  vmovaps [rsp], xmm0
000078af20bd3ece  vmovaps [rsp+0x10], xmm2
000078af20bd3ed4  vmovaps [rsp+0x20], xmm3
000078af20bd3eda  vmovaps [rsp+0x30], xmm4
000078af20bd3ee0  vmovaps [rsp+0x40], xmm5
000078af20bd3ee6  vmovaps [rsp+0x50], xmm6
000078af20bd3eec  vmovaps [rsp+0x60], xmm7
000078af20bd3ef2  vmovaps [rsp+0x70], xmm8
000078af20bd3ef8  vmovaps [rsp+0x80], xmm9
000078af20bd3f01  vmovaps [rsp+0x90], xmm10
000078af20bd3f0a  vmovaps [rsp+0xA0], xmm11
000078af20bd3f13  vmovaps [rsp+0xB0], xmm12
000078af20bd3f1c  vmovaps [rsp+0xC0], xmm13
000078af20bd3f25  vmovaps [rsp+0xD0], xmm14
000078af20bd3f2e  vmovaps [rsp+0xE0], xmm15
000078af20bd3f37  sub rsp, 0x30
000078af20bd3f3b  movaps [rsp], xmm1
000078af20bd3f3f  movaps [rsp+0x10], xmm10
000078af20bd3f45  movaps [rsp+0x20], xmm2
000078af20bd3f4a  lea rdi, [rsp]
000078af20bd3f4e  mov esi, 0x00
000078af20bd3f53  mov rax, 0x65452FFB8530
000078af20bd3f5d  call rax
000078af20bd3f5f  movaps xmm1, [rsp]
000078af20bd3f63  add rsp, 0x30
000078af20bd3f67  vmovaps xmm0, [rsp]
000078af20bd3f6c  vmovaps xmm2, [rsp+0x10]
000078af20bd3f72  vmovaps xmm3, [rsp+0x20]
000078af20bd3f78  vmovaps xmm4, [rsp+0x30]
000078af20bd3f7e  vmovaps xmm5, [rsp+0x40]
000078af20bd3f84  vmovaps xmm6, [rsp+0x50]
000078af20bd3f8a  vmovaps xmm7, [rsp+0x60]
000078af20bd3f90  vmovaps xmm8, [rsp+0x70]
000078af20bd3f96  vmovaps xmm9, [rsp+0x80]
000078af20bd3f9f  vmovaps xmm10, [rsp+0x90]
000078af20bd3fa8  vmovaps xmm11, [rsp+0xA0]
000078af20bd3fb1  vmovaps xmm12, [rsp+0xB0]
000078af20bd3fba  vmovaps xmm13, [rsp+0xC0]
000078af20bd3fc3  vmovaps xmm14, [rsp+0xD0]
000078af20bd3fcc  vmovaps xmm15, [rsp+0xE0]
000078af20bd3fd5  add rsp, 0xF0
000078af20bd3fdc  pop r11
000078af20bd3fde  pop r10
000078af20bd3fe0  pop r9
000078af20bd3fe2  pop r8
000078af20bd3fe4  pop rsi
000078af20bd3fe5  pop rdi
000078af20bd3fe6  pop rdx
000078af20bd3fe7  pop rcx
000078af20bd3fe8  pop rax
000078af20bd3fe9  add rsp, 0x08
000078af20bd3fed  jmp 0x000078AF20BD28D2
000078af20bd3ff2  sub rsp, 0x08
000078af20bd3ff6  push rax
000078af20bd3ff7  push rcx
000078af20bd3ff8  push rdx
000078af20bd3ff9  push rdi
000078af20bd3ffa  push rsi
000078af20bd3ffb  push r8
000078af20bd3ffd  push r9
000078af20bd3fff  push r10
000078af20bd4001  push r11
000078af20bd4003  sub rsp, 0xF0
000078af20bd400a  vmovaps [rsp], xmm0
000078af20bd400f  vmovaps [rsp+0x10], xmm1
000078af20bd4015  vmovaps [rsp+0x20], xmm2
000078af20bd401b  vmovaps [rsp+0x30], xmm3
000078af20bd4021  vmovaps [rsp+0x40], xmm4
000078af20bd4027  vmovaps [rsp+0x50], xmm5
000078af20bd402d  vmovaps [rsp+0x60], xmm6
000078af20bd4033  vmovaps [rsp+0x70], xmm7
000078af20bd4039  vmovaps [rsp+0x80], xmm8
000078af20bd4042  vmovaps [rsp+0x90], xmm9
000078af20bd404b  vmovaps [rsp+0xA0], xmm10
000078af20bd4054  vmovaps [rsp+0xB0], xmm11
000078af20bd405d  vmovaps [rsp+0xC0], xmm12
000078af20bd4066  vmovaps [rsp+0xD0], xmm13
000078af20bd406f  vmovaps [rsp+0xE0], xmm14
000078af20bd4078  sub rsp, 0x30
000078af20bd407c  movaps [rsp], xmm15
000078af20bd4081  movaps [rsp+0x10], xmm10
000078af20bd4087  movaps [rsp+0x20], xmm2
000078af20bd408c  lea rdi, [rsp]
000078af20bd4090  mov esi, 0x00
000078af20bd4095  mov rax, 0x65452FFB8530
000078af20bd409f  call rax
000078af20bd40a1  movaps xmm15, [rsp]
000078af20bd40a6  add rsp, 0x30
000078af20bd40aa  vmovaps xmm0, [rsp]
000078af20bd40af  vmovaps xmm1, [rsp+0x10]
000078af20bd40b5  vmovaps xmm2, [rsp+0x20]
000078af20bd40bb  vmovaps xmm3, [rsp+0x30]
000078af20bd40c1  vmovaps xmm4, [rsp+0x40]
000078af20bd40c7  vmovaps xmm5, [rsp+0x50]
000078af20bd40cd  vmovaps xmm6, [rsp+0x60]
000078af20bd40d3  vmovaps xmm7, [rsp+0x70]
000078af20bd40d9  vmovaps xmm8, [rsp+0x80]
000078af20bd40e2  vmovaps xmm9, [rsp+0x90]
000078af20bd40eb  vmovaps xmm10, [rsp+0xA0]
000078af20bd40f4  vmovaps xmm11, [rsp+0xB0]
000078af20bd40fd  vmovaps xmm12, [rsp+0xC0]
000078af20bd4106  vmovaps xmm13, [rsp+0xD0]
000078af20bd410f  vmovaps xmm14, [rsp+0xE0]
000078af20bd4118  add rsp, 0xF0
000078af20bd411f  pop r11
000078af20bd4121  pop r10
000078af20bd4123  pop r9
000078af20bd4125  pop r8
000078af20bd4127  pop rsi
000078af20bd4128  pop rdi
000078af20bd4129  pop rdx
000078af20bd412a  pop rcx
000078af20bd412b  pop rax
000078af20bd412c  add rsp, 0x08
000078af20bd4130  jmp 0x000078AF20BD2924
000078af20bd4135  sub rsp, 0x08
000078af20bd4139  push rax
000078af20bd413a  push rcx
000078af20bd413b  push rdx
000078af20bd413c  push rdi
000078af20bd413d  push rsi
000078af20bd413e  push r8
000078af20bd4140  push r9
000078af20bd4142  push r10
000078af20bd4144  push r11
000078af20bd4146  sub rsp, 0xF0
000078af20bd414d  vmovaps [rsp], xmm0
000078af20bd4152  vmovaps [rsp+0x10], xmm2
000078af20bd4158  vmovaps [rsp+0x20], xmm3
000078af20bd415e  vmovaps [rsp+0x30], xmm4
000078af20bd4164  vmovaps [rsp+0x40], xmm5
000078af20bd416a  vmovaps [rsp+0x50], xmm6
000078af20bd4170  vmovaps [rsp+0x60], xmm7
000078af20bd4176  vmovaps [rsp+0x70], xmm8
000078af20bd417c  vmovaps [rsp+0x80], xmm9
000078af20bd4185  vmovaps [rsp+0x90], xmm10
000078af20bd418e  vmovaps [rsp+0xA0], xmm11
000078af20bd4197  vmovaps [rsp+0xB0], xmm12
000078af20bd41a0  vmovaps [rsp+0xC0], xmm13
000078af20bd41a9  vmovaps [rsp+0xD0], xmm14
000078af20bd41b2  vmovaps [rsp+0xE0], xmm15
000078af20bd41bb  sub rsp, 0x30
000078af20bd41bf  movaps [rsp], xmm1
000078af20bd41c3  movaps [rsp+0x10], xmm10
000078af20bd41c9  movaps [rsp+0x20], xmm15
000078af20bd41cf  lea rdi, [rsp]
000078af20bd41d3  mov esi, 0x00
000078af20bd41d8  mov rax, 0x65452FFB8530
000078af20bd41e2  call rax
000078af20bd41e4  movaps xmm1, [rsp]
000078af20bd41e8  add rsp, 0x30
000078af20bd41ec  vmovaps xmm0, [rsp]
000078af20bd41f1  vmovaps xmm2, [rsp+0x10]
000078af20bd41f7  vmovaps xmm3, [rsp+0x20]
000078af20bd41fd  vmovaps xmm4, [rsp+0x30]
000078af20bd4203  vmovaps xmm5, [rsp+0x40]
000078af20bd4209  vmovaps xmm6, [rsp+0x50]
000078af20bd420f  vmovaps xmm7, [rsp+0x60]
000078af20bd4215  vmovaps xmm8, [rsp+0x70]
000078af20bd421b  vmovaps xmm9, [rsp+0x80]
000078af20bd4224  vmovaps xmm10, [rsp+0x90]
000078af20bd422d  vmovaps xmm11, [rsp+0xA0]
000078af20bd4236  vmovaps xmm12, [rsp+0xB0]
000078af20bd423f  vmovaps xmm13, [rsp+0xC0]
000078af20bd4248  vmovaps xmm14, [rsp+0xD0]
000078af20bd4251  vmovaps xmm15, [rsp+0xE0]
000078af20bd425a  add rsp, 0xF0
000078af20bd4261  pop r11
000078af20bd4263  pop r10
000078af20bd4265  pop r9
000078af20bd4267  pop r8
000078af20bd4269  pop rsi
000078af20bd426a  pop rdi
000078af20bd426b  pop rdx
000078af20bd426c  pop rcx
000078af20bd426d  pop rax
000078af20bd426e  add rsp, 0x08
000078af20bd4272  jmp 0x000078AF20BD2962
000078af20bd4277  sub rsp, 0x08
000078af20bd427b  push rax
000078af20bd427c  push rcx
000078af20bd427d  push rdx
000078af20bd427e  push rdi
000078af20bd427f  push rsi
000078af20bd4280  push r8
000078af20bd4282  push r9
000078af20bd4284  push r10
000078af20bd4286  push r11
000078af20bd4288  sub rsp, 0xF0
000078af20bd428f  vmovaps [rsp], xmm0
000078af20bd4294  vmovaps [rsp+0x10], xmm1
000078af20bd429a  vmovaps [rsp+0x20], xmm2
000078af20bd42a0  vmovaps [rsp+0x30], xmm3
000078af20bd42a6  vmovaps [rsp+0x40], xmm4
000078af20bd42ac  vmovaps [rsp+0x50], xmm5
000078af20bd42b2  vmovaps [rsp+0x60], xmm6
000078af20bd42b8  vmovaps [rsp+0x70], xmm7
000078af20bd42be  vmovaps [rsp+0x80], xmm8
000078af20bd42c7  vmovaps [rsp+0x90], xmm9
000078af20bd42d0  vmovaps [rsp+0xA0], xmm10
000078af20bd42d9  vmovaps [rsp+0xB0], xmm11
000078af20bd42e2  vmovaps [rsp+0xC0], xmm12
000078af20bd42eb  vmovaps [rsp+0xD0], xmm13
000078af20bd42f4  vmovaps [rsp+0xE0], xmm15
000078af20bd42fd  sub rsp, 0x30
000078af20bd4301  movaps [rsp], xmm14
000078af20bd4306  movaps [rsp+0x10], xmm10
000078af20bd430c  movaps [rsp+0x20], xmm15
000078af20bd4312  lea rdi, [rsp]
000078af20bd4316  mov esi, 0x00
000078af20bd431b  mov rax, 0x65452FFB8530
000078af20bd4325  call rax
000078af20bd4327  movaps xmm14, [rsp]
000078af20bd432c  add rsp, 0x30
000078af20bd4330  vmovaps xmm0, [rsp]
000078af20bd4335  vmovaps xmm1, [rsp+0x10]
000078af20bd433b  vmovaps xmm2, [rsp+0x20]
000078af20bd4341  vmovaps xmm3, [rsp+0x30]
000078af20bd4347  vmovaps xmm4, [rsp+0x40]
000078af20bd434d  vmovaps xmm5, [rsp+0x50]
000078af20bd4353  vmovaps xmm6, [rsp+0x60]
000078af20bd4359  vmovaps xmm7, [rsp+0x70]
000078af20bd435f  vmovaps xmm8, [rsp+0x80]
000078af20bd4368  vmovaps xmm9, [rsp+0x90]
000078af20bd4371  vmovaps xmm10, [rsp+0xA0]
000078af20bd437a  vmovaps xmm11, [rsp+0xB0]
000078af20bd4383  vmovaps xmm12, [rsp+0xC0]
000078af20bd438c  vmovaps xmm13, [rsp+0xD0]
000078af20bd4395  vmovaps xmm15, [rsp+0xE0]
000078af20bd439e  add rsp, 0xF0
000078af20bd43a5  pop r11
000078af20bd43a7  pop r10
000078af20bd43a9  pop r9
000078af20bd43ab  pop r8
000078af20bd43ad  pop rsi
000078af20bd43ae  pop rdi
000078af20bd43af  pop rdx
000078af20bd43b0  pop rcx
000078af20bd43b1  pop rax
000078af20bd43b2  add rsp, 0x08
000078af20bd43b6  jmp 0x000078AF20BD298E
000078af20bd43bb  call 0x000078AF209FF430
000078af20bd43c0  jmp 0x000078AF20BD2A1E
000078af20bd43c5  call 0x000078AF209FF430
000078af20bd43ca  jmp 0x000078AF20BD2A31
000078af20bd43cf  sub rsp, 0x08
000078af20bd43d3  push rax
000078af20bd43d4  push rcx
000078af20bd43d5  push rdx
000078af20bd43d6  push rdi
000078af20bd43d7  push rsi
000078af20bd43d8  push r8
000078af20bd43da  push r9
000078af20bd43dc  push r10
000078af20bd43de  push r11
000078af20bd43e0  sub rsp, 0xF0
000078af20bd43e7  vmovaps [rsp], xmm0
000078af20bd43ec  vmovaps [rsp+0x10], xmm2
000078af20bd43f2  vmovaps [rsp+0x20], xmm3
000078af20bd43f8  vmovaps [rsp+0x30], xmm4
000078af20bd43fe  vmovaps [rsp+0x40], xmm5
000078af20bd4404  vmovaps [rsp+0x50], xmm6
000078af20bd440a  vmovaps [rsp+0x60], xmm7
000078af20bd4410  vmovaps [rsp+0x70], xmm8
000078af20bd4416  vmovaps [rsp+0x80], xmm9
000078af20bd441f  vmovaps [rsp+0x90], xmm10
000078af20bd4428  vmovaps [rsp+0xA0], xmm11
000078af20bd4431  vmovaps [rsp+0xB0], xmm12
000078af20bd443a  vmovaps [rsp+0xC0], xmm13
000078af20bd4443  vmovaps [rsp+0xD0], xmm14
000078af20bd444c  vmovaps [rsp+0xE0], xmm15
000078af20bd4455  sub rsp, 0x30
000078af20bd4459  movaps [rsp], xmm1
000078af20bd445d  movaps [rsp+0x10], xmm13
000078af20bd4463  movaps [rsp+0x20], xmm2
000078af20bd4468  lea rdi, [rsp]
000078af20bd446c  mov esi, 0x00
000078af20bd4471  mov rax, 0x65452FFB8530
000078af20bd447b  call rax
000078af20bd447d  movaps xmm1, [rsp]
000078af20bd4481  add rsp, 0x30
000078af20bd4485  vmovaps xmm0, [rsp]
000078af20bd448a  vmovaps xmm2, [rsp+0x10]
000078af20bd4490  vmovaps xmm3, [rsp+0x20]
000078af20bd4496  vmovaps xmm4, [rsp+0x30]
000078af20bd449c  vmovaps xmm5, [rsp+0x40]
000078af20bd44a2  vmovaps xmm6, [rsp+0x50]
000078af20bd44a8  vmovaps xmm7, [rsp+0x60]
000078af20bd44ae  vmovaps xmm8, [rsp+0x70]
000078af20bd44b4  vmovaps xmm9, [rsp+0x80]
000078af20bd44bd  vmovaps xmm10, [rsp+0x90]
000078af20bd44c6  vmovaps xmm11, [rsp+0xA0]
000078af20bd44cf  vmovaps xmm12, [rsp+0xB0]
000078af20bd44d8  vmovaps xmm13, [rsp+0xC0]
000078af20bd44e1  vmovaps xmm14, [rsp+0xD0]
000078af20bd44ea  vmovaps xmm15, [rsp+0xE0]
000078af20bd44f3  add rsp, 0xF0
000078af20bd44fa  pop r11
000078af20bd44fc  pop r10
000078af20bd44fe  pop r9
000078af20bd4500  pop r8
000078af20bd4502  pop rsi
000078af20bd4503  pop rdi
000078af20bd4504  pop rdx
000078af20bd4505  pop rcx
000078af20bd4506  pop rax
000078af20bd4507  add rsp, 0x08
000078af20bd450b  jmp 0x000078AF20BD2A5C
000078af20bd4510  call 0x000078AF20A0E760
000078af20bd4515  jmp 0x000078AF20BD2A69
000078af20bd451a  sub rsp, 0x08
000078af20bd451e  push rax
000078af20bd451f  push rcx
000078af20bd4520  push rdx
000078af20bd4521  push rdi
000078af20bd4522  push rsi
000078af20bd4523  push r8
000078af20bd4525  push r9
000078af20bd4527  push r10
000078af20bd4529  push r11
000078af20bd452b  sub rsp, 0xF0
000078af20bd4532  vmovaps [rsp], xmm0
000078af20bd4537  vmovaps [rsp+0x10], xmm1
000078af20bd453d  vmovaps [rsp+0x20], xmm2
000078af20bd4543  vmovaps [rsp+0x30], xmm3
000078af20bd4549  vmovaps [rsp+0x40], xmm4
000078af20bd454f  vmovaps [rsp+0x50], xmm5
000078af20bd4555  vmovaps [rsp+0x60], xmm6
000078af20bd455b  vmovaps [rsp+0x70], xmm7
000078af20bd4561  vmovaps [rsp+0x80], xmm8
000078af20bd456a  vmovaps [rsp+0x90], xmm9
000078af20bd4573  vmovaps [rsp+0xA0], xmm10
000078af20bd457c  vmovaps [rsp+0xB0], xmm11
000078af20bd4585  vmovaps [rsp+0xC0], xmm12
000078af20bd458e  vmovaps [rsp+0xD0], xmm14
000078af20bd4597  vmovaps [rsp+0xE0], xmm15
000078af20bd45a0  sub rsp, 0x30
000078af20bd45a4  movaps [rsp], xmm13
000078af20bd45a9  movaps [rsp+0x10], xmm2
000078af20bd45ae  movaps [rsp+0x20], xmm1
000078af20bd45b3  lea rdi, [rsp]
000078af20bd45b7  mov esi, 0x00
000078af20bd45bc  mov rax, 0x65452FFB8530
000078af20bd45c6  call rax
000078af20bd45c8  movaps xmm13, [rsp]
000078af20bd45cd  add rsp, 0x30
000078af20bd45d1  vmovaps xmm0, [rsp]
000078af20bd45d6  vmovaps xmm1, [rsp+0x10]
000078af20bd45dc  vmovaps xmm2, [rsp+0x20]
000078af20bd45e2  vmovaps xmm3, [rsp+0x30]
000078af20bd45e8  vmovaps xmm4, [rsp+0x40]
000078af20bd45ee  vmovaps xmm5, [rsp+0x50]
000078af20bd45f4  vmovaps xmm6, [rsp+0x60]
000078af20bd45fa  vmovaps xmm7, [rsp+0x70]
000078af20bd4600  vmovaps xmm8, [rsp+0x80]
000078af20bd4609  vmovaps xmm9, [rsp+0x90]
000078af20bd4612  vmovaps xmm10, [rsp+0xA0]
000078af20bd461b  vmovaps xmm11, [rsp+0xB0]
000078af20bd4624  vmovaps xmm12, [rsp+0xC0]
000078af20bd462d  vmovaps xmm14, [rsp+0xD0]
000078af20bd4636  vmovaps xmm15, [rsp+0xE0]
000078af20bd463f  add rsp, 0xF0
000078af20bd4646  pop r11
000078af20bd4648  pop r10
000078af20bd464a  pop r9
000078af20bd464c  pop r8
000078af20bd464e  pop rsi
000078af20bd464f  pop rdi
000078af20bd4650  pop rdx
000078af20bd4651  pop rcx
000078af20bd4652  pop rax
000078af20bd4653  add rsp, 0x08
000078af20bd4657  jmp 0x000078AF20BD2AA8
000078af20bd465c  sub rsp, 0x08
000078af20bd4660  push rax
000078af20bd4661  push rcx
000078af20bd4662  push rdx
000078af20bd4663  push rdi
000078af20bd4664  push rsi
000078af20bd4665  push r8
000078af20bd4667  push r9
000078af20bd4669  push r10
000078af20bd466b  push r11
000078af20bd466d  sub rsp, 0xF0
000078af20bd4674  vmovaps [rsp], xmm0
000078af20bd4679  vmovaps [rsp+0x10], xmm2
000078af20bd467f  vmovaps [rsp+0x20], xmm3
000078af20bd4685  vmovaps [rsp+0x30], xmm4
000078af20bd468b  vmovaps [rsp+0x40], xmm5
000078af20bd4691  vmovaps [rsp+0x50], xmm6
000078af20bd4697  vmovaps [rsp+0x60], xmm7
000078af20bd469d  vmovaps [rsp+0x70], xmm8
000078af20bd46a3  vmovaps [rsp+0x80], xmm9
000078af20bd46ac  vmovaps [rsp+0x90], xmm10
000078af20bd46b5  vmovaps [rsp+0xA0], xmm11
000078af20bd46be  vmovaps [rsp+0xB0], xmm12
000078af20bd46c7  vmovaps [rsp+0xC0], xmm13
000078af20bd46d0  vmovaps [rsp+0xD0], xmm14
000078af20bd46d9  vmovaps [rsp+0xE0], xmm15
000078af20bd46e2  sub rsp, 0x30
000078af20bd46e6  movaps [rsp], xmm1
000078af20bd46ea  movaps [rsp+0x10], xmm14
000078af20bd46f0  movaps [rsp+0x20], xmm15
000078af20bd46f6  lea rdi, [rsp]
000078af20bd46fa  mov esi, 0x00
000078af20bd46ff  mov rax, 0x65452FFB8530
000078af20bd4709  call rax
000078af20bd470b  movaps xmm1, [rsp]
000078af20bd470f  add rsp, 0x30
000078af20bd4713  vmovaps xmm0, [rsp]
000078af20bd4718  vmovaps xmm2, [rsp+0x10]
000078af20bd471e  vmovaps xmm3, [rsp+0x20]
000078af20bd4724  vmovaps xmm4, [rsp+0x30]
000078af20bd472a  vmovaps xmm5, [rsp+0x40]
000078af20bd4730  vmovaps xmm6, [rsp+0x50]
000078af20bd4736  vmovaps xmm7, [rsp+0x60]
000078af20bd473c  vmovaps xmm8, [rsp+0x70]
000078af20bd4742  vmovaps xmm9, [rsp+0x80]
000078af20bd474b  vmovaps xmm10, [rsp+0x90]
000078af20bd4754  vmovaps xmm11, [rsp+0xA0]
000078af20bd475d  vmovaps xmm12, [rsp+0xB0]
000078af20bd4766  vmovaps xmm13, [rsp+0xC0]
000078af20bd476f  vmovaps xmm14, [rsp+0xD0]
000078af20bd4778  vmovaps xmm15, [rsp+0xE0]
000078af20bd4781  add rsp, 0xF0
000078af20bd4788  pop r11
000078af20bd478a  pop r10
000078af20bd478c  pop r9
000078af20bd478e  pop r8
000078af20bd4790  pop rsi
000078af20bd4791  pop rdi
000078af20bd4792  pop rdx
000078af20bd4793  pop rcx
000078af20bd4794  pop rax
000078af20bd4795  add rsp, 0x08
000078af20bd4799  jmp 0x000078AF20BD2ACA
000078af20bd479e  sub rsp, 0x08
000078af20bd47a2  push rax
000078af20bd47a3  push rcx
000078af20bd47a4  push rdx
000078af20bd47a5  push rdi
000078af20bd47a6  push rsi
000078af20bd47a7  push r8
000078af20bd47a9  push r9
000078af20bd47ab  push r10
000078af20bd47ad  push r11
000078af20bd47af  sub rsp, 0xF0
000078af20bd47b6  vmovaps [rsp], xmm0
000078af20bd47bb  vmovaps [rsp+0x10], xmm1
000078af20bd47c1  vmovaps [rsp+0x20], xmm2
000078af20bd47c7  vmovaps [rsp+0x30], xmm3
000078af20bd47cd  vmovaps [rsp+0x40], xmm4
000078af20bd47d3  vmovaps [rsp+0x50], xmm5
000078af20bd47d9  vmovaps [rsp+0x60], xmm6
000078af20bd47df  vmovaps [rsp+0x70], xmm7
000078af20bd47e5  vmovaps [rsp+0x80], xmm8
000078af20bd47ee  vmovaps [rsp+0x90], xmm9
000078af20bd47f7  vmovaps [rsp+0xA0], xmm10
000078af20bd4800  vmovaps [rsp+0xB0], xmm11
000078af20bd4809  vmovaps [rsp+0xC0], xmm12
000078af20bd4812  vmovaps [rsp+0xD0], xmm13
000078af20bd481b  vmovaps [rsp+0xE0], xmm15
000078af20bd4824  sub rsp, 0x30
000078af20bd4828  movaps [rsp], xmm14
000078af20bd482d  movaps [rsp+0x10], xmm2
000078af20bd4832  movaps [rsp+0x20], xmm15
000078af20bd4838  lea rdi, [rsp]
000078af20bd483c  mov esi, 0x00
000078af20bd4841  mov rax, 0x65452FFB8530
000078af20bd484b  call rax
000078af20bd484d  movaps xmm14, [rsp]
000078af20bd4852  add rsp, 0x30
000078af20bd4856  vmovaps xmm0, [rsp]
000078af20bd485b  vmovaps xmm1, [rsp+0x10]
000078af20bd4861  vmovaps xmm2, [rsp+0x20]
000078af20bd4867  vmovaps xmm3, [rsp+0x30]
000078af20bd486d  vmovaps xmm4, [rsp+0x40]
000078af20bd4873  vmovaps xmm5, [rsp+0x50]
000078af20bd4879  vmovaps xmm6, [rsp+0x60]
000078af20bd487f  vmovaps xmm7, [rsp+0x70]
000078af20bd4885  vmovaps xmm8, [rsp+0x80]
000078af20bd488e  vmovaps xmm9, [rsp+0x90]
000078af20bd4897  vmovaps xmm10, [rsp+0xA0]
000078af20bd48a0  vmovaps xmm11, [rsp+0xB0]
000078af20bd48a9  vmovaps xmm12, [rsp+0xC0]
000078af20bd48b2  vmovaps xmm13, [rsp+0xD0]
000078af20bd48bb  vmovaps xmm15, [rsp+0xE0]
000078af20bd48c4  add rsp, 0xF0
000078af20bd48cb  pop r11
000078af20bd48cd  pop r10
000078af20bd48cf  pop r9
000078af20bd48d1  pop r8
000078af20bd48d3  pop rsi
000078af20bd48d4  pop rdi
000078af20bd48d5  pop rdx
000078af20bd48d6  pop rcx
000078af20bd48d7  pop rax
000078af20bd48d8  add rsp, 0x08
000078af20bd48dc  jmp 0x000078AF20BD2B05
000078af20bd48e1  sub rsp, 0x08
000078af20bd48e5  push rax
000078af20bd48e6  push rcx
000078af20bd48e7  push rdx
000078af20bd48e8  push rdi
000078af20bd48e9  push rsi
000078af20bd48ea  push r8
000078af20bd48ec  push r9
000078af20bd48ee  push r10
000078af20bd48f0  push r11
000078af20bd48f2  sub rsp, 0xF0
000078af20bd48f9  vmovaps [rsp], xmm0
000078af20bd48fe  vmovaps [rsp+0x10], xmm1
000078af20bd4904  vmovaps [rsp+0x20], xmm2
000078af20bd490a  vmovaps [rsp+0x30], xmm3
000078af20bd4910  vmovaps [rsp+0x40], xmm4
000078af20bd4916  vmovaps [rsp+0x50], xmm5
000078af20bd491c  vmovaps [rsp+0x60], xmm6
000078af20bd4922  vmovaps [rsp+0x70], xmm7
000078af20bd4928  vmovaps [rsp+0x80], xmm8
000078af20bd4931  vmovaps [rsp+0x90], xmm9
000078af20bd493a  vmovaps [rsp+0xA0], xmm10
000078af20bd4943  vmovaps [rsp+0xB0], xmm11
000078af20bd494c  vmovaps [rsp+0xC0], xmm12
000078af20bd4955  vmovaps [rsp+0xD0], xmm13
000078af20bd495e  vmovaps [rsp+0xE0], xmm14
000078af20bd4967  sub rsp, 0x30
000078af20bd496b  movaps [rsp], xmm15
000078af20bd4970  movaps [rsp+0x10], xmm2
000078af20bd4975  movaps [rsp+0x20], xmm1
000078af20bd497a  lea rdi, [rsp]
000078af20bd497e  mov esi, 0x00
000078af20bd4983  mov rax, 0x65452FFB8530
000078af20bd498d  call rax
000078af20bd498f  movaps xmm15, [rsp]
000078af20bd4994  add rsp, 0x30
000078af20bd4998  vmovaps xmm0, [rsp]
000078af20bd499d  vmovaps xmm1, [rsp+0x10]
000078af20bd49a3  vmovaps xmm2, [rsp+0x20]
000078af20bd49a9  vmovaps xmm3, [rsp+0x30]
000078af20bd49af  vmovaps xmm4, [rsp+0x40]
000078af20bd49b5  vmovaps xmm5, [rsp+0x50]
000078af20bd49bb  vmovaps xmm6, [rsp+0x60]
000078af20bd49c1  vmovaps xmm7, [rsp+0x70]
000078af20bd49c7  vmovaps xmm8, [rsp+0x80]
000078af20bd49d0  vmovaps xmm9, [rsp+0x90]
000078af20bd49d9  vmovaps xmm10, [rsp+0xA0]
000078af20bd49e2  vmovaps xmm11, [rsp+0xB0]
000078af20bd49eb  vmovaps xmm12, [rsp+0xC0]
000078af20bd49f4  vmovaps xmm13, [rsp+0xD0]
000078af20bd49fd  vmovaps xmm14, [rsp+0xE0]
000078af20bd4a06  add rsp, 0xF0
000078af20bd4a0d  pop r11
000078af20bd4a0f  pop r10
000078af20bd4a11  pop r9
000078af20bd4a13  pop r8
000078af20bd4a15  pop rsi
000078af20bd4a16  pop rdi
000078af20bd4a17  pop rdx
000078af20bd4a18  pop rcx
000078af20bd4a19  pop rax
000078af20bd4a1a  add rsp, 0x08
000078af20bd4a1e  jmp 0x000078AF20BD2B41
000078af20bd4a23  call 0x000078AF209FF430
000078af20bd4a28  jmp 0x000078AF20BD2B4E
000078af20bd4a2d  sub rsp, 0x08
000078af20bd4a31  push rax
000078af20bd4a32  push rcx
000078af20bd4a33  push rdx
000078af20bd4a34  push rdi
000078af20bd4a35  push rsi
000078af20bd4a36  push r8
000078af20bd4a38  push r9
000078af20bd4a3a  push r10
000078af20bd4a3c  push r11
000078af20bd4a3e  sub rsp, 0xF0
000078af20bd4a45  vmovaps [rsp], xmm0
000078af20bd4a4a  vmovaps [rsp+0x10], xmm1
000078af20bd4a50  vmovaps [rsp+0x20], xmm3
000078af20bd4a56  vmovaps [rsp+0x30], xmm4
000078af20bd4a5c  vmovaps [rsp+0x40], xmm5
000078af20bd4a62  vmovaps [rsp+0x50], xmm6
000078af20bd4a68  vmovaps [rsp+0x60], xmm7
000078af20bd4a6e  vmovaps [rsp+0x70], xmm8
000078af20bd4a74  vmovaps [rsp+0x80], xmm9
000078af20bd4a7d  vmovaps [rsp+0x90], xmm10
000078af20bd4a86  vmovaps [rsp+0xA0], xmm11
000078af20bd4a8f  vmovaps [rsp+0xB0], xmm12
000078af20bd4a98  vmovaps [rsp+0xC0], xmm13
000078af20bd4aa1  vmovaps [rsp+0xD0], xmm14
000078af20bd4aaa  vmovaps [rsp+0xE0], xmm15
000078af20bd4ab3  sub rsp, 0x30
000078af20bd4ab7  movaps [rsp], xmm2
000078af20bd4abb  movaps [rsp+0x10], xmm1
000078af20bd4ac0  movaps [rsp+0x20], xmm14
000078af20bd4ac6  lea rdi, [rsp]
000078af20bd4aca  mov esi, 0x00
000078af20bd4acf  mov rax, 0x65452FFB8530
000078af20bd4ad9  call rax
000078af20bd4adb  movaps xmm2, [rsp]
000078af20bd4adf  add rsp, 0x30
000078af20bd4ae3  vmovaps xmm0, [rsp]
000078af20bd4ae8  vmovaps xmm1, [rsp+0x10]
000078af20bd4aee  vmovaps xmm3, [rsp+0x20]
000078af20bd4af4  vmovaps xmm4, [rsp+0x30]
000078af20bd4afa  vmovaps xmm5, [rsp+0x40]
000078af20bd4b00  vmovaps xmm6, [rsp+0x50]
000078af20bd4b06  vmovaps xmm7, [rsp+0x60]
000078af20bd4b0c  vmovaps xmm8, [rsp+0x70]
000078af20bd4b12  vmovaps xmm9, [rsp+0x80]
000078af20bd4b1b  vmovaps xmm10, [rsp+0x90]
000078af20bd4b24  vmovaps xmm11, [rsp+0xA0]
000078af20bd4b2d  vmovaps xmm12, [rsp+0xB0]
000078af20bd4b36  vmovaps xmm13, [rsp+0xC0]
000078af20bd4b3f  vmovaps xmm14, [rsp+0xD0]
000078af20bd4b48  vmovaps xmm15, [rsp+0xE0]
000078af20bd4b51  add rsp, 0xF0
000078af20bd4b58  pop r11
000078af20bd4b5a  pop r10
000078af20bd4b5c  pop r9
000078af20bd4b5e  pop r8
000078af20bd4b60  pop rsi
000078af20bd4b61  pop rdi
000078af20bd4b62  pop rdx
000078af20bd4b63  pop rcx
000078af20bd4b64  pop rax
000078af20bd4b65  add rsp, 0x08
000078af20bd4b69  jmp 0x000078AF20BD2B8B
000078af20bd4b6e  sub rsp, 0x08
000078af20bd4b72  push rax
000078af20bd4b73  push rcx
000078af20bd4b74  push rdx
000078af20bd4b75  push rdi
000078af20bd4b76  push rsi
000078af20bd4b77  push r8
000078af20bd4b79  push r9
000078af20bd4b7b  push r10
000078af20bd4b7d  push r11
000078af20bd4b7f  sub rsp, 0xF0
000078af20bd4b86  vmovaps [rsp], xmm0
000078af20bd4b8b  vmovaps [rsp+0x10], xmm1
000078af20bd4b91  vmovaps [rsp+0x20], xmm2
000078af20bd4b97  vmovaps [rsp+0x30], xmm3
000078af20bd4b9d  vmovaps [rsp+0x40], xmm4
000078af20bd4ba3  vmovaps [rsp+0x50], xmm5
000078af20bd4ba9  vmovaps [rsp+0x60], xmm6
000078af20bd4baf  vmovaps [rsp+0x70], xmm7
000078af20bd4bb5  vmovaps [rsp+0x80], xmm8
000078af20bd4bbe  vmovaps [rsp+0x90], xmm9
000078af20bd4bc7  vmovaps [rsp+0xA0], xmm10
000078af20bd4bd0  vmovaps [rsp+0xB0], xmm11
000078af20bd4bd9  vmovaps [rsp+0xC0], xmm12
000078af20bd4be2  vmovaps [rsp+0xD0], xmm13
000078af20bd4beb  vmovaps [rsp+0xE0], xmm14
000078af20bd4bf4  sub rsp, 0x30
000078af20bd4bf8  movaps [rsp], xmm15
000078af20bd4bfd  movaps [rsp+0x10], xmm14
000078af20bd4c03  movaps [rsp+0x20], xmm1
000078af20bd4c08  lea rdi, [rsp]
000078af20bd4c0c  mov esi, 0x00
000078af20bd4c11  mov rax, 0x65452FFB8530
000078af20bd4c1b  call rax
000078af20bd4c1d  movaps xmm15, [rsp]
000078af20bd4c22  add rsp, 0x30
000078af20bd4c26  vmovaps xmm0, [rsp]
000078af20bd4c2b  vmovaps xmm1, [rsp+0x10]
000078af20bd4c31  vmovaps xmm2, [rsp+0x20]
000078af20bd4c37  vmovaps xmm3, [rsp+0x30]
000078af20bd4c3d  vmovaps xmm4, [rsp+0x40]
000078af20bd4c43  vmovaps xmm5, [rsp+0x50]
000078af20bd4c49  vmovaps xmm6, [rsp+0x60]
000078af20bd4c4f  vmovaps xmm7, [rsp+0x70]
000078af20bd4c55  vmovaps xmm8, [rsp+0x80]
000078af20bd4c5e  vmovaps xmm9, [rsp+0x90]
000078af20bd4c67  vmovaps xmm10, [rsp+0xA0]
000078af20bd4c70  vmovaps xmm11, [rsp+0xB0]
000078af20bd4c79  vmovaps xmm12, [rsp+0xC0]
000078af20bd4c82  vmovaps xmm13, [rsp+0xD0]
000078af20bd4c8b  vmovaps xmm14, [rsp+0xE0]
000078af20bd4c94  add rsp, 0xF0
000078af20bd4c9b  pop r11
000078af20bd4c9d  pop r10
000078af20bd4c9f  pop r9
000078af20bd4ca1  pop r8
000078af20bd4ca3  pop rsi
000078af20bd4ca4  pop rdi
000078af20bd4ca5  pop rdx
000078af20bd4ca6  pop rcx
000078af20bd4ca7  pop rax
000078af20bd4ca8  add rsp, 0x08
000078af20bd4cac  jmp 0x000078AF20BD2C05
000078af20bd4cb1  call 0x000078AF209FF430
000078af20bd4cb6  jmp 0x000078AF20BD2C12
000078af20bd4cbb  sub rsp, 0x08
000078af20bd4cbf  push rax
000078af20bd4cc0  push rcx
000078af20bd4cc1  push rdx
000078af20bd4cc2  push rdi
000078af20bd4cc3  push rsi
000078af20bd4cc4  push r8
000078af20bd4cc6  push r9
000078af20bd4cc8  push r10
000078af20bd4cca  push r11
000078af20bd4ccc  sub rsp, 0xF0
000078af20bd4cd3  vmovaps [rsp], xmm0
000078af20bd4cd8  vmovaps [rsp+0x10], xmm1
000078af20bd4cde  vmovaps [rsp+0x20], xmm2
000078af20bd4ce4  vmovaps [rsp+0x30], xmm3
000078af20bd4cea  vmovaps [rsp+0x40], xmm4
000078af20bd4cf0  vmovaps [rsp+0x50], xmm5
000078af20bd4cf6  vmovaps [rsp+0x60], xmm6
000078af20bd4cfc  vmovaps [rsp+0x70], xmm7
000078af20bd4d02  vmovaps [rsp+0x80], xmm8
000078af20bd4d0b  vmovaps [rsp+0x90], xmm9
000078af20bd4d14  vmovaps [rsp+0xA0], xmm10
000078af20bd4d1d  vmovaps [rsp+0xB0], xmm11
000078af20bd4d26  vmovaps [rsp+0xC0], xmm12
000078af20bd4d2f  vmovaps [rsp+0xD0], xmm14
000078af20bd4d38  vmovaps [rsp+0xE0], xmm15
000078af20bd4d41  sub rsp, 0x30
000078af20bd4d45  movaps [rsp], xmm13
000078af20bd4d4a  movaps [rsp+0x10], xmm1
000078af20bd4d4f  movaps [rsp+0x20], xmm15
000078af20bd4d55  lea rdi, [rsp]
000078af20bd4d59  mov esi, 0x00
000078af20bd4d5e  mov rax, 0x65452FFB8530
000078af20bd4d68  call rax
000078af20bd4d6a  movaps xmm13, [rsp]
000078af20bd4d6f  add rsp, 0x30
000078af20bd4d73  vmovaps xmm0, [rsp]
000078af20bd4d78  vmovaps xmm1, [rsp+0x10]
000078af20bd4d7e  vmovaps xmm2, [rsp+0x20]
000078af20bd4d84  vmovaps xmm3, [rsp+0x30]
000078af20bd4d8a  vmovaps xmm4, [rsp+0x40]
000078af20bd4d90  vmovaps xmm5, [rsp+0x50]
000078af20bd4d96  vmovaps xmm6, [rsp+0x60]
000078af20bd4d9c  vmovaps xmm7, [rsp+0x70]
000078af20bd4da2  vmovaps xmm8, [rsp+0x80]
000078af20bd4dab  vmovaps xmm9, [rsp+0x90]
000078af20bd4db4  vmovaps xmm10, [rsp+0xA0]
000078af20bd4dbd  vmovaps xmm11, [rsp+0xB0]
000078af20bd4dc6  vmovaps xmm12, [rsp+0xC0]
000078af20bd4dcf  vmovaps xmm14, [rsp+0xD0]
000078af20bd4dd8  vmovaps xmm15, [rsp+0xE0]
000078af20bd4de1  add rsp, 0xF0
000078af20bd4de8  pop r11
000078af20bd4dea  pop r10
000078af20bd4dec  pop r9
000078af20bd4dee  pop r8
000078af20bd4df0  pop rsi
000078af20bd4df1  pop rdi
000078af20bd4df2  pop rdx
000078af20bd4df3  pop rcx
000078af20bd4df4  pop rax
000078af20bd4df5  add rsp, 0x08
000078af20bd4df9  jmp 0x000078AF20BD2CD6
000078af20bd4dfe  sub rsp, 0x08
000078af20bd4e02  push rax
000078af20bd4e03  push rcx
000078af20bd4e04  push rdx
000078af20bd4e05  push rdi
000078af20bd4e06  push rsi
000078af20bd4e07  push r8
000078af20bd4e09  push r9
000078af20bd4e0b  push r10
000078af20bd4e0d  push r11
000078af20bd4e0f  sub rsp, 0xF0
000078af20bd4e16  vmovaps [rsp], xmm0
000078af20bd4e1b  vmovaps [rsp+0x10], xmm1
000078af20bd4e21  vmovaps [rsp+0x20], xmm2
000078af20bd4e27  vmovaps [rsp+0x30], xmm3
000078af20bd4e2d  vmovaps [rsp+0x40], xmm4
000078af20bd4e33  vmovaps [rsp+0x50], xmm5
000078af20bd4e39  vmovaps [rsp+0x60], xmm6
000078af20bd4e3f  vmovaps [rsp+0x70], xmm7
000078af20bd4e45  vmovaps [rsp+0x80], xmm8
000078af20bd4e4e  vmovaps [rsp+0x90], xmm9
000078af20bd4e57  vmovaps [rsp+0xA0], xmm10
000078af20bd4e60  vmovaps [rsp+0xB0], xmm11
000078af20bd4e69  vmovaps [rsp+0xC0], xmm12
000078af20bd4e72  vmovaps [rsp+0xD0], xmm13
000078af20bd4e7b  vmovaps [rsp+0xE0], xmm14
000078af20bd4e84  sub rsp, 0x30
000078af20bd4e88  movaps [rsp], xmm15
000078af20bd4e8d  movaps [rsp+0x10], xmm14
000078af20bd4e93  movaps [rsp+0x20], xmm1
000078af20bd4e98  lea rdi, [rsp]
000078af20bd4e9c  mov esi, 0x00
000078af20bd4ea1  mov rax, 0x65452FFB8530
000078af20bd4eab  call rax
000078af20bd4ead  movaps xmm15, [rsp]
000078af20bd4eb2  add rsp, 0x30
000078af20bd4eb6  vmovaps xmm0, [rsp]
000078af20bd4ebb  vmovaps xmm1, [rsp+0x10]
000078af20bd4ec1  vmovaps xmm2, [rsp+0x20]
000078af20bd4ec7  vmovaps xmm3, [rsp+0x30]
000078af20bd4ecd  vmovaps xmm4, [rsp+0x40]
000078af20bd4ed3  vmovaps xmm5, [rsp+0x50]
000078af20bd4ed9  vmovaps xmm6, [rsp+0x60]
000078af20bd4edf  vmovaps xmm7, [rsp+0x70]
000078af20bd4ee5  vmovaps xmm8, [rsp+0x80]
000078af20bd4eee  vmovaps xmm9, [rsp+0x90]
000078af20bd4ef7  vmovaps xmm10, [rsp+0xA0]
000078af20bd4f00  vmovaps xmm11, [rsp+0xB0]
000078af20bd4f09  vmovaps xmm12, [rsp+0xC0]
000078af20bd4f12  vmovaps xmm13, [rsp+0xD0]
000078af20bd4f1b  vmovaps xmm14, [rsp+0xE0]
000078af20bd4f24  add rsp, 0xF0
000078af20bd4f2b  pop r11
000078af20bd4f2d  pop r10
000078af20bd4f2f  pop r9
000078af20bd4f31  pop r8
000078af20bd4f33  pop rsi
000078af20bd4f34  pop rdi
000078af20bd4f35  pop rdx
000078af20bd4f36  pop rcx
000078af20bd4f37  pop rax
000078af20bd4f38  add rsp, 0x08
000078af20bd4f3c  jmp 0x000078AF20BD2D12
000078af20bd4f41  call 0x000078AF209FF430
000078af20bd4f46  jmp 0x000078AF20BD2D1F
000078af20bd4f4b  sub rsp, 0x08
000078af20bd4f4f  push rax
000078af20bd4f50  push rcx
000078af20bd4f51  push rdx
000078af20bd4f52  push rdi
000078af20bd4f53  push rsi
000078af20bd4f54  push r8
000078af20bd4f56  push r9
000078af20bd4f58  push r10
000078af20bd4f5a  push r11
000078af20bd4f5c  sub rsp, 0xF0
000078af20bd4f63  vmovaps [rsp], xmm0
000078af20bd4f68  vmovaps [rsp+0x10], xmm1
000078af20bd4f6e  vmovaps [rsp+0x20], xmm2
000078af20bd4f74  vmovaps [rsp+0x30], xmm3
000078af20bd4f7a  vmovaps [rsp+0x40], xmm4
000078af20bd4f80  vmovaps [rsp+0x50], xmm5
000078af20bd4f86  vmovaps [rsp+0x60], xmm6
000078af20bd4f8c  vmovaps [rsp+0x70], xmm7
000078af20bd4f92  vmovaps [rsp+0x80], xmm8
000078af20bd4f9b  vmovaps [rsp+0x90], xmm9
000078af20bd4fa4  vmovaps [rsp+0xA0], xmm10
000078af20bd4fad  vmovaps [rsp+0xB0], xmm11
000078af20bd4fb6  vmovaps [rsp+0xC0], xmm12
000078af20bd4fbf  vmovaps [rsp+0xD0], xmm13
000078af20bd4fc8  vmovaps [rsp+0xE0], xmm15
000078af20bd4fd1  sub rsp, 0x30
000078af20bd4fd5  movaps [rsp], xmm14
000078af20bd4fda  movaps [rsp+0x10], xmm13
000078af20bd4fe0  movaps [rsp+0x20], xmm2
000078af20bd4fe5  lea rdi, [rsp]
000078af20bd4fe9  mov esi, 0x00
000078af20bd4fee  mov rax, 0x65452FFB8530
000078af20bd4ff8  call rax
000078af20bd4ffa  movaps xmm14, [rsp]
000078af20bd4fff  add rsp, 0x30
000078af20bd5003  vmovaps xmm0, [rsp]
000078af20bd5008  vmovaps xmm1, [rsp+0x10]
000078af20bd500e  vmovaps xmm2, [rsp+0x20]
000078af20bd5014  vmovaps xmm3, [rsp+0x30]
000078af20bd501a  vmovaps xmm4, [rsp+0x40]
000078af20bd5020  vmovaps xmm5, [rsp+0x50]
000078af20bd5026  vmovaps xmm6, [rsp+0x60]
000078af20bd502c  vmovaps xmm7, [rsp+0x70]
000078af20bd5032  vmovaps xmm8, [rsp+0x80]
000078af20bd503b  vmovaps xmm9, [rsp+0x90]
000078af20bd5044  vmovaps xmm10, [rsp+0xA0]
000078af20bd504d  vmovaps xmm11, [rsp+0xB0]
000078af20bd5056  vmovaps xmm12, [rsp+0xC0]
000078af20bd505f  vmovaps xmm13, [rsp+0xD0]
000078af20bd5068  vmovaps xmm15, [rsp+0xE0]
000078af20bd5071  add rsp, 0xF0
000078af20bd5078  pop r11
000078af20bd507a  pop r10
000078af20bd507c  pop r9
000078af20bd507e  pop r8
000078af20bd5080  pop rsi
000078af20bd5081  pop rdi
000078af20bd5082  pop rdx
000078af20bd5083  pop rcx
000078af20bd5084  pop rax
000078af20bd5085  add rsp, 0x08
000078af20bd5089  jmp 0x000078AF20BD2D4B
000078af20bd508e  sub rsp, 0x08
000078af20bd5092  push rax
000078af20bd5093  push rcx
000078af20bd5094  push rdx
000078af20bd5095  push rdi
000078af20bd5096  push rsi
000078af20bd5097  push r8
000078af20bd5099  push r9
000078af20bd509b  push r10
000078af20bd509d  push r11
000078af20bd509f  sub rsp, 0xF0
000078af20bd50a6  vmovaps [rsp], xmm0
000078af20bd50ab  vmovaps [rsp+0x10], xmm2
000078af20bd50b1  vmovaps [rsp+0x20], xmm3
000078af20bd50b7  vmovaps [rsp+0x30], xmm4
000078af20bd50bd  vmovaps [rsp+0x40], xmm5
000078af20bd50c3  vmovaps [rsp+0x50], xmm6
000078af20bd50c9  vmovaps [rsp+0x60], xmm7
000078af20bd50cf  vmovaps [rsp+0x70], xmm8
000078af20bd50d5  vmovaps [rsp+0x80], xmm9
000078af20bd50de  vmovaps [rsp+0x90], xmm10
000078af20bd50e7  vmovaps [rsp+0xA0], xmm11
000078af20bd50f0  vmovaps [rsp+0xB0], xmm12
000078af20bd50f9  vmovaps [rsp+0xC0], xmm13
000078af20bd5102  vmovaps [rsp+0xD0], xmm14
000078af20bd510b  vmovaps [rsp+0xE0], xmm15
000078af20bd5114  sub rsp, 0x30
000078af20bd5118  movaps [rsp], xmm1
000078af20bd511c  movaps [rsp+0x10], xmm13
000078af20bd5122  movaps [rsp+0x20], xmm2
000078af20bd5127  lea rdi, [rsp]
000078af20bd512b  mov esi, 0x00
000078af20bd5130  mov rax, 0x65452FFB8530
000078af20bd513a  call rax
000078af20bd513c  movaps xmm1, [rsp]
000078af20bd5140  add rsp, 0x30
000078af20bd5144  vmovaps xmm0, [rsp]
000078af20bd5149  vmovaps xmm2, [rsp+0x10]
000078af20bd514f  vmovaps xmm3, [rsp+0x20]
000078af20bd5155  vmovaps xmm4, [rsp+0x30]
000078af20bd515b  vmovaps xmm5, [rsp+0x40]
000078af20bd5161  vmovaps xmm6, [rsp+0x50]
000078af20bd5167  vmovaps xmm7, [rsp+0x60]
000078af20bd516d  vmovaps xmm8, [rsp+0x70]
000078af20bd5173  vmovaps xmm9, [rsp+0x80]
000078af20bd517c  vmovaps xmm10, [rsp+0x90]
000078af20bd5185  vmovaps xmm11, [rsp+0xA0]
000078af20bd518e  vmovaps xmm12, [rsp+0xB0]
000078af20bd5197  vmovaps xmm13, [rsp+0xC0]
000078af20bd51a0  vmovaps xmm14, [rsp+0xD0]
000078af20bd51a9  vmovaps xmm15, [rsp+0xE0]
000078af20bd51b2  add rsp, 0xF0
000078af20bd51b9  pop r11
000078af20bd51bb  pop r10
000078af20bd51bd  pop r9
000078af20bd51bf  pop r8
000078af20bd51c1  pop rsi
000078af20bd51c2  pop rdi
000078af20bd51c3  pop rdx
000078af20bd51c4  pop rcx
000078af20bd51c5  pop rax
000078af20bd51c6  add rsp, 0x08
000078af20bd51ca  jmp 0x000078AF20BD2D79
000078af20bd51cf  sub rsp, 0x08
000078af20bd51d3  push rax
000078af20bd51d4  push rcx
000078af20bd51d5  push rdx
000078af20bd51d6  push rdi
000078af20bd51d7  push rsi
000078af20bd51d8  push r8
000078af20bd51da  push r9
000078af20bd51dc  push r10
000078af20bd51de  push r11
000078af20bd51e0  sub rsp, 0xF0
000078af20bd51e7  vmovaps [rsp], xmm0
000078af20bd51ec  vmovaps [rsp+0x10], xmm1
000078af20bd51f2  vmovaps [rsp+0x20], xmm3
000078af20bd51f8  vmovaps [rsp+0x30], xmm4
000078af20bd51fe  vmovaps [rsp+0x40], xmm5
000078af20bd5204  vmovaps [rsp+0x50], xmm6
000078af20bd520a  vmovaps [rsp+0x60], xmm7
000078af20bd5210  vmovaps [rsp+0x70], xmm8
000078af20bd5216  vmovaps [rsp+0x80], xmm9
000078af20bd521f  vmovaps [rsp+0x90], xmm10
000078af20bd5228  vmovaps [rsp+0xA0], xmm11
000078af20bd5231  vmovaps [rsp+0xB0], xmm12
000078af20bd523a  vmovaps [rsp+0xC0], xmm13
000078af20bd5243  vmovaps [rsp+0xD0], xmm14
000078af20bd524c  vmovaps [rsp+0xE0], xmm15
000078af20bd5255  sub rsp, 0x30
000078af20bd5259  movaps [rsp], xmm2
000078af20bd525d  movaps [rsp+0x10], xmm1
000078af20bd5262  movaps [rsp+0x20], xmm13
000078af20bd5268  lea rdi, [rsp]
000078af20bd526c  mov esi, 0x00
000078af20bd5271  mov rax, 0x65452FFB8530
000078af20bd527b  call rax
000078af20bd527d  movaps xmm2, [rsp]
000078af20bd5281  add rsp, 0x30
000078af20bd5285  vmovaps xmm0, [rsp]
000078af20bd528a  vmovaps xmm1, [rsp+0x10]
000078af20bd5290  vmovaps xmm3, [rsp+0x20]
000078af20bd5296  vmovaps xmm4, [rsp+0x30]
000078af20bd529c  vmovaps xmm5, [rsp+0x40]
000078af20bd52a2  vmovaps xmm6, [rsp+0x50]
000078af20bd52a8  vmovaps xmm7, [rsp+0x60]
000078af20bd52ae  vmovaps xmm8, [rsp+0x70]
000078af20bd52b4  vmovaps xmm9, [rsp+0x80]
000078af20bd52bd  vmovaps xmm10, [rsp+0x90]
000078af20bd52c6  vmovaps xmm11, [rsp+0xA0]
000078af20bd52cf  vmovaps xmm12, [rsp+0xB0]
000078af20bd52d8  vmovaps xmm13, [rsp+0xC0]
000078af20bd52e1  vmovaps xmm14, [rsp+0xD0]
000078af20bd52ea  vmovaps xmm15, [rsp+0xE0]
000078af20bd52f3  add rsp, 0xF0
000078af20bd52fa  pop r11
000078af20bd52fc  pop r10
000078af20bd52fe  pop r9
000078af20bd5300  pop r8
000078af20bd5302  pop rsi
000078af20bd5303  pop rdi
000078af20bd5304  pop rdx
000078af20bd5305  pop rcx
000078af20bd5306  pop rax
000078af20bd5307  add rsp, 0x08
000078af20bd530b  jmp 0x000078AF20BD2DD2
000078af20bd5310  call 0x000078AF209FF430
000078af20bd5315  jmp 0x000078AF20BD2DDF
000078af20bd531a  sub rsp, 0x08
000078af20bd531e  push rax
000078af20bd531f  push rcx
000078af20bd5320  push rdx
000078af20bd5321  push rdi
000078af20bd5322  push rsi
000078af20bd5323  push r8
000078af20bd5325  push r9
000078af20bd5327  push r10
000078af20bd5329  push r11
000078af20bd532b  sub rsp, 0xF0
000078af20bd5332  vmovaps [rsp], xmm0
000078af20bd5337  vmovaps [rsp+0x10], xmm1
000078af20bd533d  vmovaps [rsp+0x20], xmm2
000078af20bd5343  vmovaps [rsp+0x30], xmm3
000078af20bd5349  vmovaps [rsp+0x40], xmm4
000078af20bd534f  vmovaps [rsp+0x50], xmm5
000078af20bd5355  vmovaps [rsp+0x60], xmm6
000078af20bd535b  vmovaps [rsp+0x70], xmm7
000078af20bd5361  vmovaps [rsp+0x80], xmm8
000078af20bd536a  vmovaps [rsp+0x90], xmm9
000078af20bd5373  vmovaps [rsp+0xA0], xmm10
000078af20bd537c  vmovaps [rsp+0xB0], xmm11
000078af20bd5385  vmovaps [rsp+0xC0], xmm12
000078af20bd538e  vmovaps [rsp+0xD0], xmm13
000078af20bd5397  vmovaps [rsp+0xE0], xmm14
000078af20bd53a0  sub rsp, 0x30
000078af20bd53a4  movaps [rsp], xmm15
000078af20bd53a9  movaps [rsp+0x10], xmm13
000078af20bd53af  movaps [rsp+0x20], xmm1
000078af20bd53b4  lea rdi, [rsp]
000078af20bd53b8  mov esi, 0x00
000078af20bd53bd  mov rax, 0x65452FFB8530
000078af20bd53c7  call rax
000078af20bd53c9  movaps xmm15, [rsp]
000078af20bd53ce  add rsp, 0x30
000078af20bd53d2  vmovaps xmm0, [rsp]
000078af20bd53d7  vmovaps xmm1, [rsp+0x10]
000078af20bd53dd  vmovaps xmm2, [rsp+0x20]
000078af20bd53e3  vmovaps xmm3, [rsp+0x30]
000078af20bd53e9  vmovaps xmm4, [rsp+0x40]
000078af20bd53ef  vmovaps xmm5, [rsp+0x50]
000078af20bd53f5  vmovaps xmm6, [rsp+0x60]
000078af20bd53fb  vmovaps xmm7, [rsp+0x70]
000078af20bd5401  vmovaps xmm8, [rsp+0x80]
000078af20bd540a  vmovaps xmm9, [rsp+0x90]
000078af20bd5413  vmovaps xmm10, [rsp+0xA0]
000078af20bd541c  vmovaps xmm11, [rsp+0xB0]
000078af20bd5425  vmovaps xmm12, [rsp+0xC0]
000078af20bd542e  vmovaps xmm13, [rsp+0xD0]
000078af20bd5437  vmovaps xmm14, [rsp+0xE0]
000078af20bd5440  add rsp, 0xF0
000078af20bd5447  pop r11
000078af20bd5449  pop r10
000078af20bd544b  pop r9
000078af20bd544d  pop r8
000078af20bd544f  pop rsi
000078af20bd5450  pop rdi
000078af20bd5451  pop rdx
000078af20bd5452  pop rcx
000078af20bd5453  pop rax
000078af20bd5454  add rsp, 0x08
000078af20bd5458  jmp 0x000078AF20BD2E1E
000078af20bd545d  sub rsp, 0x08
000078af20bd5461  push rax
000078af20bd5462  push rcx
000078af20bd5463  push rdx
000078af20bd5464  push rdi
000078af20bd5465  push rsi
000078af20bd5466  push r8
000078af20bd5468  push r9
000078af20bd546a  push r10
000078af20bd546c  push r11
000078af20bd546e  sub rsp, 0xF0
000078af20bd5475  vmovaps [rsp], xmm0
000078af20bd547a  vmovaps [rsp+0x10], xmm1
000078af20bd5480  vmovaps [rsp+0x20], xmm2
000078af20bd5486  vmovaps [rsp+0x30], xmm3
000078af20bd548c  vmovaps [rsp+0x40], xmm4
000078af20bd5492  vmovaps [rsp+0x50], xmm5
000078af20bd5498  vmovaps [rsp+0x60], xmm6
000078af20bd549e  vmovaps [rsp+0x70], xmm7
000078af20bd54a4  vmovaps [rsp+0x80], xmm8
000078af20bd54ad  vmovaps [rsp+0x90], xmm9
000078af20bd54b6  vmovaps [rsp+0xA0], xmm10
000078af20bd54bf  vmovaps [rsp+0xB0], xmm11
000078af20bd54c8  vmovaps [rsp+0xC0], xmm12
000078af20bd54d1  vmovaps [rsp+0xD0], xmm13
000078af20bd54da  vmovaps [rsp+0xE0], xmm15
000078af20bd54e3  sub rsp, 0x30
000078af20bd54e7  movaps [rsp], xmm14
000078af20bd54ec  movaps [rsp+0x10], xmm11
000078af20bd54f2  movaps [rsp+0x20], xmm1
000078af20bd54f7  lea rdi, [rsp]
000078af20bd54fb  mov esi, 0x00
000078af20bd5500  mov rax, 0x65452FFB8530
000078af20bd550a  call rax
000078af20bd550c  movaps xmm14, [rsp]
000078af20bd5511  add rsp, 0x30
000078af20bd5515  vmovaps xmm0, [rsp]
000078af20bd551a  vmovaps xmm1, [rsp+0x10]
000078af20bd5520  vmovaps xmm2, [rsp+0x20]
000078af20bd5526  vmovaps xmm3, [rsp+0x30]
000078af20bd552c  vmovaps xmm4, [rsp+0x40]
000078af20bd5532  vmovaps xmm5, [rsp+0x50]
000078af20bd5538  vmovaps xmm6, [rsp+0x60]
000078af20bd553e  vmovaps xmm7, [rsp+0x70]
000078af20bd5544  vmovaps xmm8, [rsp+0x80]
000078af20bd554d  vmovaps xmm9, [rsp+0x90]
000078af20bd5556  vmovaps xmm10, [rsp+0xA0]
000078af20bd555f  vmovaps xmm11, [rsp+0xB0]
000078af20bd5568  vmovaps xmm12, [rsp+0xC0]
000078af20bd5571  vmovaps xmm13, [rsp+0xD0]
000078af20bd557a  vmovaps xmm15, [rsp+0xE0]
000078af20bd5583  add rsp, 0xF0
000078af20bd558a  pop r11
000078af20bd558c  pop r10
000078af20bd558e  pop r9
000078af20bd5590  pop r8
000078af20bd5592  pop rsi
000078af20bd5593  pop rdi
000078af20bd5594  pop rdx
000078af20bd5595  pop rcx
000078af20bd5596  pop rax
000078af20bd5597  add rsp, 0x08
000078af20bd559b  jmp 0x000078AF20BD2E48
000078af20bd55a0  sub rsp, 0x08
000078af20bd55a4  push rax
000078af20bd55a5  push rcx
000078af20bd55a6  push rdx
000078af20bd55a7  push rdi
000078af20bd55a8  push rsi
000078af20bd55a9  push r8
000078af20bd55ab  push r9
000078af20bd55ad  push r10
000078af20bd55af  push r11
000078af20bd55b1  sub rsp, 0xF0
000078af20bd55b8  vmovaps [rsp], xmm0
000078af20bd55bd  vmovaps [rsp+0x10], xmm1
000078af20bd55c3  vmovaps [rsp+0x20], xmm2
000078af20bd55c9  vmovaps [rsp+0x30], xmm3
000078af20bd55cf  vmovaps [rsp+0x40], xmm4
000078af20bd55d5  vmovaps [rsp+0x50], xmm5
000078af20bd55db  vmovaps [rsp+0x60], xmm6
000078af20bd55e1  vmovaps [rsp+0x70], xmm7
000078af20bd55e7  vmovaps [rsp+0x80], xmm8
000078af20bd55f0  vmovaps [rsp+0x90], xmm9
000078af20bd55f9  vmovaps [rsp+0xA0], xmm10
000078af20bd5602  vmovaps [rsp+0xB0], xmm11
000078af20bd560b  vmovaps [rsp+0xC0], xmm12
000078af20bd5614  vmovaps [rsp+0xD0], xmm14
000078af20bd561d  vmovaps [rsp+0xE0], xmm15
000078af20bd5626  sub rsp, 0x30
000078af20bd562a  movaps [rsp], xmm13
000078af20bd562f  movaps [rsp+0x10], xmm11
000078af20bd5635  movaps [rsp+0x20], xmm1
000078af20bd563a  lea rdi, [rsp]
000078af20bd563e  mov esi, 0x00
000078af20bd5643  mov rax, 0x65452FFB8530
000078af20bd564d  call rax
000078af20bd564f  movaps xmm13, [rsp]
000078af20bd5654  add rsp, 0x30
000078af20bd5658  vmovaps xmm0, [rsp]
000078af20bd565d  vmovaps xmm1, [rsp+0x10]
000078af20bd5663  vmovaps xmm2, [rsp+0x20]
000078af20bd5669  vmovaps xmm3, [rsp+0x30]
000078af20bd566f  vmovaps xmm4, [rsp+0x40]
000078af20bd5675  vmovaps xmm5, [rsp+0x50]
000078af20bd567b  vmovaps xmm6, [rsp+0x60]
000078af20bd5681  vmovaps xmm7, [rsp+0x70]
000078af20bd5687  vmovaps xmm8, [rsp+0x80]
000078af20bd5690  vmovaps xmm9, [rsp+0x90]
000078af20bd5699  vmovaps xmm10, [rsp+0xA0]
000078af20bd56a2  vmovaps xmm11, [rsp+0xB0]
000078af20bd56ab  vmovaps xmm12, [rsp+0xC0]
000078af20bd56b4  vmovaps xmm14, [rsp+0xD0]
000078af20bd56bd  vmovaps xmm15, [rsp+0xE0]
000078af20bd56c6  add rsp, 0xF0
000078af20bd56cd  pop r11
000078af20bd56cf  pop r10
000078af20bd56d1  pop r9
000078af20bd56d3  pop r8
000078af20bd56d5  pop rsi
000078af20bd56d6  pop rdi
000078af20bd56d7  pop rdx
000078af20bd56d8  pop rcx
000078af20bd56d9  pop rax
000078af20bd56da  add rsp, 0x08
000078af20bd56de  jmp 0x000078AF20BD2E9D
000078af20bd56e3  call 0x000078AF209FF430
000078af20bd56e8  jmp 0x000078AF20BD2EAA
000078af20bd56ed  sub rsp, 0x08
000078af20bd56f1  push rax
000078af20bd56f2  push rcx
000078af20bd56f3  push rdx
000078af20bd56f4  push rdi
000078af20bd56f5  push rsi
000078af20bd56f6  push r8
000078af20bd56f8  push r9
000078af20bd56fa  push r10
000078af20bd56fc  push r11
000078af20bd56fe  sub rsp, 0xF0
000078af20bd5705  vmovaps [rsp], xmm0
000078af20bd570a  vmovaps [rsp+0x10], xmm1
000078af20bd5710  vmovaps [rsp+0x20], xmm2
000078af20bd5716  vmovaps [rsp+0x30], xmm3
000078af20bd571c  vmovaps [rsp+0x40], xmm4
000078af20bd5722  vmovaps [rsp+0x50], xmm5
000078af20bd5728  vmovaps [rsp+0x60], xmm6
000078af20bd572e  vmovaps [rsp+0x70], xmm7
000078af20bd5734  vmovaps [rsp+0x80], xmm8
000078af20bd573d  vmovaps [rsp+0x90], xmm9
000078af20bd5746  vmovaps [rsp+0xA0], xmm10
000078af20bd574f  vmovaps [rsp+0xB0], xmm11
000078af20bd5758  vmovaps [rsp+0xC0], xmm12
000078af20bd5761  vmovaps [rsp+0xD0], xmm13
000078af20bd576a  vmovaps [rsp+0xE0], xmm14
000078af20bd5773  sub rsp, 0x30
000078af20bd5777  movaps [rsp], xmm15
000078af20bd577c  movaps [rsp+0x10], xmm11
000078af20bd5782  movaps [rsp+0x20], xmm1
000078af20bd5787  lea rdi, [rsp]
000078af20bd578b  mov esi, 0x00
000078af20bd5790  mov rax, 0x65452FFB8530
000078af20bd579a  call rax
000078af20bd579c  movaps xmm15, [rsp]
000078af20bd57a1  add rsp, 0x30
000078af20bd57a5  vmovaps xmm0, [rsp]
000078af20bd57aa  vmovaps xmm1, [rsp+0x10]
000078af20bd57b0  vmovaps xmm2, [rsp+0x20]
000078af20bd57b6  vmovaps xmm3, [rsp+0x30]
000078af20bd57bc  vmovaps xmm4, [rsp+0x40]
000078af20bd57c2  vmovaps xmm5, [rsp+0x50]
000078af20bd57c8  vmovaps xmm6, [rsp+0x60]
000078af20bd57ce  vmovaps xmm7, [rsp+0x70]
000078af20bd57d4  vmovaps xmm8, [rsp+0x80]
000078af20bd57dd  vmovaps xmm9, [rsp+0x90]
000078af20bd57e6  vmovaps xmm10, [rsp+0xA0]
000078af20bd57ef  vmovaps xmm11, [rsp+0xB0]
000078af20bd57f8  vmovaps xmm12, [rsp+0xC0]
000078af20bd5801  vmovaps xmm13, [rsp+0xD0]
000078af20bd580a  vmovaps xmm14, [rsp+0xE0]
000078af20bd5813  add rsp, 0xF0
000078af20bd581a  pop r11
000078af20bd581c  pop r10
000078af20bd581e  pop r9
000078af20bd5820  pop r8
000078af20bd5822  pop rsi
000078af20bd5823  pop rdi
000078af20bd5824  pop rdx
000078af20bd5825  pop rcx
000078af20bd5826  pop rax
000078af20bd5827  add rsp, 0x08
000078af20bd582b  jmp 0x000078AF20BD2EE3
000078af20bd5830  sub rsp, 0x08
000078af20bd5834  push rax
000078af20bd5835  push rcx
000078af20bd5836  push rdx
000078af20bd5837  push rdi
000078af20bd5838  push rsi
000078af20bd5839  push r8
000078af20bd583b  push r9
000078af20bd583d  push r10
000078af20bd583f  push r11
000078af20bd5841  sub rsp, 0xF0
000078af20bd5848  vmovaps [rsp], xmm0
000078af20bd584d  vmovaps [rsp+0x10], xmm1
000078af20bd5853  vmovaps [rsp+0x20], xmm2
000078af20bd5859  vmovaps [rsp+0x30], xmm3
000078af20bd585f  vmovaps [rsp+0x40], xmm4
000078af20bd5865  vmovaps [rsp+0x50], xmm5
000078af20bd586b  vmovaps [rsp+0x60], xmm6
000078af20bd5871  vmovaps [rsp+0x70], xmm7
000078af20bd5877  vmovaps [rsp+0x80], xmm8
000078af20bd5880  vmovaps [rsp+0x90], xmm9
000078af20bd5889  vmovaps [rsp+0xA0], xmm10
000078af20bd5892  vmovaps [rsp+0xB0], xmm12
000078af20bd589b  vmovaps [rsp+0xC0], xmm13
000078af20bd58a4  vmovaps [rsp+0xD0], xmm14
000078af20bd58ad  vmovaps [rsp+0xE0], xmm15
000078af20bd58b6  sub rsp, 0x30
000078af20bd58ba  movaps [rsp], xmm11
000078af20bd58bf  movaps [rsp+0x10], xmm6
000078af20bd58c4  movaps [rsp+0x20], xmm14
000078af20bd58ca  lea rdi, [rsp]
000078af20bd58ce  mov esi, 0x00
000078af20bd58d3  mov rax, 0x65452FFB8530
000078af20bd58dd  call rax
000078af20bd58df  movaps xmm11, [rsp]
000078af20bd58e4  add rsp, 0x30
000078af20bd58e8  vmovaps xmm0, [rsp]
000078af20bd58ed  vmovaps xmm1, [rsp+0x10]
000078af20bd58f3  vmovaps xmm2, [rsp+0x20]
000078af20bd58f9  vmovaps xmm3, [rsp+0x30]
000078af20bd58ff  vmovaps xmm4, [rsp+0x40]
000078af20bd5905  vmovaps xmm5, [rsp+0x50]
000078af20bd590b  vmovaps xmm6, [rsp+0x60]
000078af20bd5911  vmovaps xmm7, [rsp+0x70]
000078af20bd5917  vmovaps xmm8, [rsp+0x80]
000078af20bd5920  vmovaps xmm9, [rsp+0x90]
000078af20bd5929  vmovaps xmm10, [rsp+0xA0]
000078af20bd5932  vmovaps xmm12, [rsp+0xB0]
000078af20bd593b  vmovaps xmm13, [rsp+0xC0]
000078af20bd5944  vmovaps xmm14, [rsp+0xD0]
000078af20bd594d  vmovaps xmm15, [rsp+0xE0]
000078af20bd5956  add rsp, 0xF0
000078af20bd595d  pop r11
000078af20bd595f  pop r10
000078af20bd5961  pop r9
000078af20bd5963  pop r8
000078af20bd5965  pop rsi
000078af20bd5966  pop rdi
000078af20bd5967  pop rdx
000078af20bd5968  pop rcx
000078af20bd5969  pop rax
000078af20bd596a  add rsp, 0x08
000078af20bd596e  jmp 0x000078AF20BD2F5B
000078af20bd5973  call 0x000078AF209FF430
000078af20bd5978  jmp 0x000078AF20BD2F65
000078af20bd597d  sub rsp, 0x08
000078af20bd5981  push rax
000078af20bd5982  push rcx
000078af20bd5983  push rdx
000078af20bd5984  push rdi
000078af20bd5985  push rsi
000078af20bd5986  push r8
000078af20bd5988  push r9
000078af20bd598a  push r10
000078af20bd598c  push r11
000078af20bd598e  sub rsp, 0xF0
000078af20bd5995  vmovaps [rsp], xmm0
000078af20bd599a  vmovaps [rsp+0x10], xmm1
000078af20bd59a0  vmovaps [rsp+0x20], xmm2
000078af20bd59a6  vmovaps [rsp+0x30], xmm3
000078af20bd59ac  vmovaps [rsp+0x40], xmm4
000078af20bd59b2  vmovaps [rsp+0x50], xmm5
000078af20bd59b8  vmovaps [rsp+0x60], xmm6
000078af20bd59be  vmovaps [rsp+0x70], xmm7
000078af20bd59c4  vmovaps [rsp+0x80], xmm8
000078af20bd59cd  vmovaps [rsp+0x90], xmm9
000078af20bd59d6  vmovaps [rsp+0xA0], xmm10
000078af20bd59df  vmovaps [rsp+0xB0], xmm11
000078af20bd59e8  vmovaps [rsp+0xC0], xmm12
000078af20bd59f1  vmovaps [rsp+0xD0], xmm13
000078af20bd59fa  vmovaps [rsp+0xE0], xmm15
000078af20bd5a03  sub rsp, 0x30
000078af20bd5a07  movaps [rsp], xmm14
000078af20bd5a0c  movaps [rsp+0x10], xmm6
000078af20bd5a11  movaps [rsp+0x20], xmm2
000078af20bd5a16  lea rdi, [rsp]
000078af20bd5a1a  mov esi, 0x00
000078af20bd5a1f  mov rax, 0x65452FFB8530
000078af20bd5a29  call rax
000078af20bd5a2b  movaps xmm14, [rsp]
000078af20bd5a30  add rsp, 0x30
000078af20bd5a34  vmovaps xmm0, [rsp]
000078af20bd5a39  vmovaps xmm1, [rsp+0x10]
000078af20bd5a3f  vmovaps xmm2, [rsp+0x20]
000078af20bd5a45  vmovaps xmm3, [rsp+0x30]
000078af20bd5a4b  vmovaps xmm4, [rsp+0x40]
000078af20bd5a51  vmovaps xmm5, [rsp+0x50]
000078af20bd5a57  vmovaps xmm6, [rsp+0x60]
000078af20bd5a5d  vmovaps xmm7, [rsp+0x70]
000078af20bd5a63  vmovaps xmm8, [rsp+0x80]
000078af20bd5a6c  vmovaps xmm9, [rsp+0x90]
000078af20bd5a75  vmovaps xmm10, [rsp+0xA0]
000078af20bd5a7e  vmovaps xmm11, [rsp+0xB0]
000078af20bd5a87  vmovaps xmm12, [rsp+0xC0]
000078af20bd5a90  vmovaps xmm13, [rsp+0xD0]
000078af20bd5a99  vmovaps xmm15, [rsp+0xE0]
000078af20bd5aa2  add rsp, 0xF0
000078af20bd5aa9  pop r11
000078af20bd5aab  pop r10
000078af20bd5aad  pop r9
000078af20bd5aaf  pop r8
000078af20bd5ab1  pop rsi
000078af20bd5ab2  pop rdi
000078af20bd5ab3  pop rdx
000078af20bd5ab4  pop rcx
000078af20bd5ab5  pop rax
000078af20bd5ab6  add rsp, 0x08
000078af20bd5aba  jmp 0x000078AF20BD2F99
000078af20bd5abf  sub rsp, 0x08
000078af20bd5ac3  push rax
000078af20bd5ac4  push rcx
000078af20bd5ac5  push rdx
000078af20bd5ac6  push rdi
000078af20bd5ac7  push rsi
000078af20bd5ac8  push r8
000078af20bd5aca  push r9
000078af20bd5acc  push r10
000078af20bd5ace  push r11
000078af20bd5ad0  sub rsp, 0xF0
000078af20bd5ad7  vmovaps [rsp], xmm0
000078af20bd5adc  vmovaps [rsp+0x10], xmm1
000078af20bd5ae2  vmovaps [rsp+0x20], xmm2
000078af20bd5ae8  vmovaps [rsp+0x30], xmm3
000078af20bd5aee  vmovaps [rsp+0x40], xmm4
000078af20bd5af4  vmovaps [rsp+0x50], xmm5
000078af20bd5afa  vmovaps [rsp+0x60], xmm7
000078af20bd5b00  vmovaps [rsp+0x70], xmm8
000078af20bd5b06  vmovaps [rsp+0x80], xmm9
000078af20bd5b0f  vmovaps [rsp+0x90], xmm10
000078af20bd5b18  vmovaps [rsp+0xA0], xmm11
000078af20bd5b21  vmovaps [rsp+0xB0], xmm12
000078af20bd5b2a  vmovaps [rsp+0xC0], xmm13
000078af20bd5b33  vmovaps [rsp+0xD0], xmm14
000078af20bd5b3c  vmovaps [rsp+0xE0], xmm15
000078af20bd5b45  sub rsp, 0x30
000078af20bd5b49  movaps [rsp], xmm6
000078af20bd5b4d  movaps [rsp+0x10], xmm5
000078af20bd5b52  movaps [rsp+0x20], xmm1
000078af20bd5b57  lea rdi, [rsp]
000078af20bd5b5b  mov esi, 0x00
000078af20bd5b60  mov rax, 0x65452FFB8530
000078af20bd5b6a  call rax
000078af20bd5b6c  movaps xmm6, [rsp]
000078af20bd5b70  add rsp, 0x30
000078af20bd5b74  vmovaps xmm0, [rsp]
000078af20bd5b79  vmovaps xmm1, [rsp+0x10]
000078af20bd5b7f  vmovaps xmm2, [rsp+0x20]
000078af20bd5b85  vmovaps xmm3, [rsp+0x30]
000078af20bd5b8b  vmovaps xmm4, [rsp+0x40]
000078af20bd5b91  vmovaps xmm5, [rsp+0x50]
000078af20bd5b97  vmovaps xmm7, [rsp+0x60]
000078af20bd5b9d  vmovaps xmm8, [rsp+0x70]
000078af20bd5ba3  vmovaps xmm9, [rsp+0x80]
000078af20bd5bac  vmovaps xmm10, [rsp+0x90]
000078af20bd5bb5  vmovaps xmm11, [rsp+0xA0]
000078af20bd5bbe  vmovaps xmm12, [rsp+0xB0]
000078af20bd5bc7  vmovaps xmm13, [rsp+0xC0]
000078af20bd5bd0  vmovaps xmm14, [rsp+0xD0]
000078af20bd5bd9  vmovaps xmm15, [rsp+0xE0]
000078af20bd5be2  add rsp, 0xF0
000078af20bd5be9  pop r11
000078af20bd5beb  pop r10
000078af20bd5bed  pop r9
000078af20bd5bef  pop r8
000078af20bd5bf1  pop rsi
000078af20bd5bf2  pop rdi
000078af20bd5bf3  pop rdx
000078af20bd5bf4  pop rcx
000078af20bd5bf5  pop rax
000078af20bd5bf6  add rsp, 0x08
000078af20bd5bfa  jmp 0x000078AF20BD2FBF
000078af20bd5bff  sub rsp, 0x08
000078af20bd5c03  push rax
000078af20bd5c04  push rcx
000078af20bd5c05  push rdx
000078af20bd5c06  push rdi
000078af20bd5c07  push rsi
000078af20bd5c08  push r8
000078af20bd5c0a  push r9
000078af20bd5c0c  push r10
000078af20bd5c0e  push r11
000078af20bd5c10  sub rsp, 0xF0
000078af20bd5c17  vmovaps [rsp], xmm0
000078af20bd5c1c  vmovaps [rsp+0x10], xmm2
000078af20bd5c22  vmovaps [rsp+0x20], xmm3
000078af20bd5c28  vmovaps [rsp+0x30], xmm4
000078af20bd5c2e  vmovaps [rsp+0x40], xmm5
000078af20bd5c34  vmovaps [rsp+0x50], xmm6
000078af20bd5c3a  vmovaps [rsp+0x60], xmm7
000078af20bd5c40  vmovaps [rsp+0x70], xmm8
000078af20bd5c46  vmovaps [rsp+0x80], xmm9
000078af20bd5c4f  vmovaps [rsp+0x90], xmm10
000078af20bd5c58  vmovaps [rsp+0xA0], xmm11
000078af20bd5c61  vmovaps [rsp+0xB0], xmm12
000078af20bd5c6a  vmovaps [rsp+0xC0], xmm13
000078af20bd5c73  vmovaps [rsp+0xD0], xmm14
000078af20bd5c7c  vmovaps [rsp+0xE0], xmm15
000078af20bd5c85  sub rsp, 0x30
000078af20bd5c89  movaps [rsp], xmm1
000078af20bd5c8d  movaps [rsp+0x10], xmm5
000078af20bd5c92  movaps [rsp+0x20], xmm13
000078af20bd5c98  lea rdi, [rsp]
000078af20bd5c9c  mov esi, 0x00
000078af20bd5ca1  mov rax, 0x65452FFB8530
000078af20bd5cab  call rax
000078af20bd5cad  movaps xmm1, [rsp]
000078af20bd5cb1  add rsp, 0x30
000078af20bd5cb5  vmovaps xmm0, [rsp]
000078af20bd5cba  vmovaps xmm2, [rsp+0x10]
000078af20bd5cc0  vmovaps xmm3, [rsp+0x20]
000078af20bd5cc6  vmovaps xmm4, [rsp+0x30]
000078af20bd5ccc  vmovaps xmm5, [rsp+0x40]
000078af20bd5cd2  vmovaps xmm6, [rsp+0x50]
000078af20bd5cd8  vmovaps xmm7, [rsp+0x60]
000078af20bd5cde  vmovaps xmm8, [rsp+0x70]
000078af20bd5ce4  vmovaps xmm9, [rsp+0x80]
000078af20bd5ced  vmovaps xmm10, [rsp+0x90]
000078af20bd5cf6  vmovaps xmm11, [rsp+0xA0]
000078af20bd5cff  vmovaps xmm12, [rsp+0xB0]
000078af20bd5d08  vmovaps xmm13, [rsp+0xC0]
000078af20bd5d11  vmovaps xmm14, [rsp+0xD0]
000078af20bd5d1a  vmovaps xmm15, [rsp+0xE0]
000078af20bd5d23  add rsp, 0xF0
000078af20bd5d2a  pop r11
000078af20bd5d2c  pop r10
000078af20bd5d2e  pop r9
000078af20bd5d30  pop r8
000078af20bd5d32  pop rsi
000078af20bd5d33  pop rdi
000078af20bd5d34  pop rdx
000078af20bd5d35  pop rcx
000078af20bd5d36  pop rax
000078af20bd5d37  add rsp, 0x08
000078af20bd5d3b  jmp 0x000078AF20BD2FDD
000078af20bd5d40  sub rsp, 0x08
000078af20bd5d44  push rax
000078af20bd5d45  push rcx
000078af20bd5d46  push rdx
000078af20bd5d47  push rdi
000078af20bd5d48  push rsi
000078af20bd5d49  push r8
000078af20bd5d4b  push r9
000078af20bd5d4d  push r10
000078af20bd5d4f  push r11
000078af20bd5d51  sub rsp, 0xF0
000078af20bd5d58  vmovaps [rsp], xmm0
000078af20bd5d5d  vmovaps [rsp+0x10], xmm1
000078af20bd5d63  vmovaps [rsp+0x20], xmm2
000078af20bd5d69  vmovaps [rsp+0x30], xmm3
000078af20bd5d6f  vmovaps [rsp+0x40], xmm4
000078af20bd5d75  vmovaps [rsp+0x50], xmm6
000078af20bd5d7b  vmovaps [rsp+0x60], xmm7
000078af20bd5d81  vmovaps [rsp+0x70], xmm8
000078af20bd5d87  vmovaps [rsp+0x80], xmm9
000078af20bd5d90  vmovaps [rsp+0x90], xmm10
000078af20bd5d99  vmovaps [rsp+0xA0], xmm11
000078af20bd5da2  vmovaps [rsp+0xB0], xmm12
000078af20bd5dab  vmovaps [rsp+0xC0], xmm13
000078af20bd5db4  vmovaps [rsp+0xD0], xmm14
000078af20bd5dbd  vmovaps [rsp+0xE0], xmm15
000078af20bd5dc6  sub rsp, 0x30
000078af20bd5dca  movaps [rsp], xmm5
000078af20bd5dce  movaps [rsp+0x10], xmm2
000078af20bd5dd3  movaps [rsp+0x20], xmm13
000078af20bd5dd9  lea rdi, [rsp]
000078af20bd5ddd  mov esi, 0x00
000078af20bd5de2  mov rax, 0x65452FFB8530
000078af20bd5dec  call rax
000078af20bd5dee  movaps xmm5, [rsp]
000078af20bd5df2  add rsp, 0x30
000078af20bd5df6  vmovaps xmm0, [rsp]
000078af20bd5dfb  vmovaps xmm1, [rsp+0x10]
000078af20bd5e01  vmovaps xmm2, [rsp+0x20]
000078af20bd5e07  vmovaps xmm3, [rsp+0x30]
000078af20bd5e0d  vmovaps xmm4, [rsp+0x40]
000078af20bd5e13  vmovaps xmm6, [rsp+0x50]
000078af20bd5e19  vmovaps xmm7, [rsp+0x60]
000078af20bd5e1f  vmovaps xmm8, [rsp+0x70]
000078af20bd5e25  vmovaps xmm9, [rsp+0x80]
000078af20bd5e2e  vmovaps xmm10, [rsp+0x90]
000078af20bd5e37  vmovaps xmm11, [rsp+0xA0]
000078af20bd5e40  vmovaps xmm12, [rsp+0xB0]
000078af20bd5e49  vmovaps xmm13, [rsp+0xC0]
000078af20bd5e52  vmovaps xmm14, [rsp+0xD0]
000078af20bd5e5b  vmovaps xmm15, [rsp+0xE0]
000078af20bd5e64  add rsp, 0xF0
000078af20bd5e6b  pop r11
000078af20bd5e6d  pop r10
000078af20bd5e6f  pop r9
000078af20bd5e71  pop r8
000078af20bd5e73  pop rsi
000078af20bd5e74  pop rdi
000078af20bd5e75  pop rdx
000078af20bd5e76  pop rcx
000078af20bd5e77  pop rax
000078af20bd5e78  add rsp, 0x08
000078af20bd5e7c  jmp 0x000078AF20BD3013
000078af20bd5e81  sub rsp, 0x08
000078af20bd5e85  push rax
000078af20bd5e86  push rcx
000078af20bd5e87  push rdx
000078af20bd5e88  push rdi
000078af20bd5e89  push rsi
000078af20bd5e8a  push r8
000078af20bd5e8c  push r9
000078af20bd5e8e  push r10
000078af20bd5e90  push r11
000078af20bd5e92  sub rsp, 0xF0
000078af20bd5e99  vmovaps [rsp], xmm0
000078af20bd5e9e  vmovaps [rsp+0x10], xmm1
000078af20bd5ea4  vmovaps [rsp+0x20], xmm2
000078af20bd5eaa  vmovaps [rsp+0x30], xmm3
000078af20bd5eb0  vmovaps [rsp+0x40], xmm4
000078af20bd5eb6  vmovaps [rsp+0x50], xmm5
000078af20bd5ebc  vmovaps [rsp+0x60], xmm6
000078af20bd5ec2  vmovaps [rsp+0x70], xmm7
000078af20bd5ec8  vmovaps [rsp+0x80], xmm8
000078af20bd5ed1  vmovaps [rsp+0x90], xmm9
000078af20bd5eda  vmovaps [rsp+0xA0], xmm10
000078af20bd5ee3  vmovaps [rsp+0xB0], xmm11
000078af20bd5eec  vmovaps [rsp+0xC0], xmm12
000078af20bd5ef5  vmovaps [rsp+0xD0], xmm14
000078af20bd5efe  vmovaps [rsp+0xE0], xmm15
000078af20bd5f07  sub rsp, 0x30
000078af20bd5f0b  movaps [rsp], xmm13
000078af20bd5f10  movaps [rsp+0x10], xmm10
000078af20bd5f16  movaps [rsp+0x20], xmm1
000078af20bd5f1b  lea rdi, [rsp]
000078af20bd5f1f  mov esi, 0x00
000078af20bd5f24  mov rax, 0x65452FFB8530
000078af20bd5f2e  call rax
000078af20bd5f30  movaps xmm13, [rsp]
000078af20bd5f35  add rsp, 0x30
000078af20bd5f39  vmovaps xmm0, [rsp]
000078af20bd5f3e  vmovaps xmm1, [rsp+0x10]
000078af20bd5f44  vmovaps xmm2, [rsp+0x20]
000078af20bd5f4a  vmovaps xmm3, [rsp+0x30]
000078af20bd5f50  vmovaps xmm4, [rsp+0x40]
000078af20bd5f56  vmovaps xmm5, [rsp+0x50]
000078af20bd5f5c  vmovaps xmm6, [rsp+0x60]
000078af20bd5f62  vmovaps xmm7, [rsp+0x70]
000078af20bd5f68  vmovaps xmm8, [rsp+0x80]
000078af20bd5f71  vmovaps xmm9, [rsp+0x90]
000078af20bd5f7a  vmovaps xmm10, [rsp+0xA0]
000078af20bd5f83  vmovaps xmm11, [rsp+0xB0]
000078af20bd5f8c  vmovaps xmm12, [rsp+0xC0]
000078af20bd5f95  vmovaps xmm14, [rsp+0xD0]
000078af20bd5f9e  vmovaps xmm15, [rsp+0xE0]
000078af20bd5fa7  add rsp, 0xF0
000078af20bd5fae  pop r11
000078af20bd5fb0  pop r10
000078af20bd5fb2  pop r9
000078af20bd5fb4  pop r8
000078af20bd5fb6  pop rsi
000078af20bd5fb7  pop rdi
000078af20bd5fb8  pop rdx
000078af20bd5fb9  pop rcx
000078af20bd5fba  pop rax
000078af20bd5fbb  add rsp, 0x08
000078af20bd5fbf  jmp 0x000078AF20BD303C
000078af20bd5fc4  sub rsp, 0x08
000078af20bd5fc8  push rax
000078af20bd5fc9  push rcx
000078af20bd5fca  push rdx
000078af20bd5fcb  push rdi
000078af20bd5fcc  push rsi
000078af20bd5fcd  push r8
000078af20bd5fcf  push r9
000078af20bd5fd1  push r10
000078af20bd5fd3  push r11
000078af20bd5fd5  sub rsp, 0xF0
000078af20bd5fdc  vmovaps [rsp], xmm0
000078af20bd5fe1  vmovaps [rsp+0x10], xmm2
000078af20bd5fe7  vmovaps [rsp+0x20], xmm3
000078af20bd5fed  vmovaps [rsp+0x30], xmm4
000078af20bd5ff3  vmovaps [rsp+0x40], xmm5
000078af20bd5ff9  vmovaps [rsp+0x50], xmm6
000078af20bd5fff  vmovaps [rsp+0x60], xmm7
000078af20bd6005  vmovaps [rsp+0x70], xmm8
000078af20bd600b  vmovaps [rsp+0x80], xmm9
000078af20bd6014  vmovaps [rsp+0x90], xmm10
000078af20bd601d  vmovaps [rsp+0xA0], xmm11
000078af20bd6026  vmovaps [rsp+0xB0], xmm12
000078af20bd602f  vmovaps [rsp+0xC0], xmm13
000078af20bd6038  vmovaps [rsp+0xD0], xmm14
000078af20bd6041  vmovaps [rsp+0xE0], xmm15
000078af20bd604a  sub rsp, 0x30
000078af20bd604e  movaps [rsp], xmm1
000078af20bd6052  movaps [rsp+0x10], xmm15
000078af20bd6058  movaps [rsp+0x20], xmm10
000078af20bd605e  lea rdi, [rsp]
000078af20bd6062  mov esi, 0x00
000078af20bd6067  mov rax, 0x65452FFB8530
000078af20bd6071  call rax
000078af20bd6073  movaps xmm1, [rsp]
000078af20bd6077  add rsp, 0x30
000078af20bd607b  vmovaps xmm0, [rsp]
000078af20bd6080  vmovaps xmm2, [rsp+0x10]
000078af20bd6086  vmovaps xmm3, [rsp+0x20]
000078af20bd608c  vmovaps xmm4, [rsp+0x30]
000078af20bd6092  vmovaps xmm5, [rsp+0x40]
000078af20bd6098  vmovaps xmm6, [rsp+0x50]
000078af20bd609e  vmovaps xmm7, [rsp+0x60]
000078af20bd60a4  vmovaps xmm8, [rsp+0x70]
000078af20bd60aa  vmovaps xmm9, [rsp+0x80]
000078af20bd60b3  vmovaps xmm10, [rsp+0x90]
000078af20bd60bc  vmovaps xmm11, [rsp+0xA0]
000078af20bd60c5  vmovaps xmm12, [rsp+0xB0]
000078af20bd60ce  vmovaps xmm13, [rsp+0xC0]
000078af20bd60d7  vmovaps xmm14, [rsp+0xD0]
000078af20bd60e0  vmovaps xmm15, [rsp+0xE0]
000078af20bd60e9  add rsp, 0xF0
000078af20bd60f0  pop r11
000078af20bd60f2  pop r10
000078af20bd60f4  pop r9
000078af20bd60f6  pop r8
000078af20bd60f8  pop rsi
000078af20bd60f9  pop rdi
000078af20bd60fa  pop rdx
000078af20bd60fb  pop rcx
000078af20bd60fc  pop rax
000078af20bd60fd  add rsp, 0x08
000078af20bd6101  jmp 0x000078AF20BD305B
000078af20bd6106  sub rsp, 0x08
000078af20bd610a  push rax
000078af20bd610b  push rcx
000078af20bd610c  push rdx
000078af20bd610d  push rdi
000078af20bd610e  push rsi
000078af20bd610f  push r8
000078af20bd6111  push r9
000078af20bd6113  push r10
000078af20bd6115  push r11
000078af20bd6117  sub rsp, 0xF0
000078af20bd611e  vmovaps [rsp], xmm0
000078af20bd6123  vmovaps [rsp+0x10], xmm1
000078af20bd6129  vmovaps [rsp+0x20], xmm2
000078af20bd612f  vmovaps [rsp+0x30], xmm3
000078af20bd6135  vmovaps [rsp+0x40], xmm4
000078af20bd613b  vmovaps [rsp+0x50], xmm5
000078af20bd6141  vmovaps [rsp+0x60], xmm6
000078af20bd6147  vmovaps [rsp+0x70], xmm7
000078af20bd614d  vmovaps [rsp+0x80], xmm8
000078af20bd6156  vmovaps [rsp+0x90], xmm9
000078af20bd615f  vmovaps [rsp+0xA0], xmm10
000078af20bd6168  vmovaps [rsp+0xB0], xmm11
000078af20bd6171  vmovaps [rsp+0xC0], xmm12
000078af20bd617a  vmovaps [rsp+0xD0], xmm13
000078af20bd6183  vmovaps [rsp+0xE0], xmm14
000078af20bd618c  sub rsp, 0x30
000078af20bd6190  movaps [rsp], xmm15
000078af20bd6195  movaps [rsp+0x10], xmm10
000078af20bd619b  movaps [rsp+0x20], xmm11
000078af20bd61a1  lea rdi, [rsp]
000078af20bd61a5  mov esi, 0x00
000078af20bd61aa  mov rax, 0x65452FFB8530
000078af20bd61b4  call rax
000078af20bd61b6  movaps xmm15, [rsp]
000078af20bd61bb  add rsp, 0x30
000078af20bd61bf  vmovaps xmm0, [rsp]
000078af20bd61c4  vmovaps xmm1, [rsp+0x10]
000078af20bd61ca  vmovaps xmm2, [rsp+0x20]
000078af20bd61d0  vmovaps xmm3, [rsp+0x30]
000078af20bd61d6  vmovaps xmm4, [rsp+0x40]
000078af20bd61dc  vmovaps xmm5, [rsp+0x50]
000078af20bd61e2  vmovaps xmm6, [rsp+0x60]
000078af20bd61e8  vmovaps xmm7, [rsp+0x70]
000078af20bd61ee  vmovaps xmm8, [rsp+0x80]
000078af20bd61f7  vmovaps xmm9, [rsp+0x90]
000078af20bd6200  vmovaps xmm10, [rsp+0xA0]
000078af20bd6209  vmovaps xmm11, [rsp+0xB0]
000078af20bd6212  vmovaps xmm12, [rsp+0xC0]
000078af20bd621b  vmovaps xmm13, [rsp+0xD0]
000078af20bd6224  vmovaps xmm14, [rsp+0xE0]
000078af20bd622d  add rsp, 0xF0
000078af20bd6234  pop r11
000078af20bd6236  pop r10
000078af20bd6238  pop r9
000078af20bd623a  pop r8
000078af20bd623c  pop rsi
000078af20bd623d  pop rdi
000078af20bd623e  pop rdx
000078af20bd623f  pop rcx
000078af20bd6240  pop rax
000078af20bd6241  add rsp, 0x08
000078af20bd6245  jmp 0x000078AF20BD307E
000078af20bd624a  sub rsp, 0x08
000078af20bd624e  push rax
000078af20bd624f  push rcx
000078af20bd6250  push rdx
000078af20bd6251  push rdi
000078af20bd6252  push rsi
000078af20bd6253  push r8
000078af20bd6255  push r9
000078af20bd6257  push r10
000078af20bd6259  push r11
000078af20bd625b  sub rsp, 0xF0
000078af20bd6262  vmovaps [rsp], xmm0
000078af20bd6267  vmovaps [rsp+0x10], xmm1
000078af20bd626d  vmovaps [rsp+0x20], xmm2
000078af20bd6273  vmovaps [rsp+0x30], xmm3
000078af20bd6279  vmovaps [rsp+0x40], xmm4
000078af20bd627f  vmovaps [rsp+0x50], xmm5
000078af20bd6285  vmovaps [rsp+0x60], xmm6
000078af20bd628b  vmovaps [rsp+0x70], xmm7
000078af20bd6291  vmovaps [rsp+0x80], xmm8
000078af20bd629a  vmovaps [rsp+0x90], xmm9
000078af20bd62a3  vmovaps [rsp+0xA0], xmm11
000078af20bd62ac  vmovaps [rsp+0xB0], xmm12
000078af20bd62b5  vmovaps [rsp+0xC0], xmm13
000078af20bd62be  vmovaps [rsp+0xD0], xmm14
000078af20bd62c7  vmovaps [rsp+0xE0], xmm15
000078af20bd62d0  sub rsp, 0x30
000078af20bd62d4  movaps [rsp], xmm10
000078af20bd62d9  movaps [rsp+0x10], xmm2
000078af20bd62de  movaps [rsp+0x20], xmm11
000078af20bd62e4  lea rdi, [rsp]
000078af20bd62e8  mov esi, 0x00
000078af20bd62ed  mov rax, 0x65452FFB8530
000078af20bd62f7  call rax
000078af20bd62f9  movaps xmm10, [rsp]
000078af20bd62fe  add rsp, 0x30
000078af20bd6302  vmovaps xmm0, [rsp]
000078af20bd6307  vmovaps xmm1, [rsp+0x10]
000078af20bd630d  vmovaps xmm2, [rsp+0x20]
000078af20bd6313  vmovaps xmm3, [rsp+0x30]
000078af20bd6319  vmovaps xmm4, [rsp+0x40]
000078af20bd631f  vmovaps xmm5, [rsp+0x50]
000078af20bd6325  vmovaps xmm6, [rsp+0x60]
000078af20bd632b  vmovaps xmm7, [rsp+0x70]
000078af20bd6331  vmovaps xmm8, [rsp+0x80]
000078af20bd633a  vmovaps xmm9, [rsp+0x90]
000078af20bd6343  vmovaps xmm11, [rsp+0xA0]
000078af20bd634c  vmovaps xmm12, [rsp+0xB0]
000078af20bd6355  vmovaps xmm13, [rsp+0xC0]
000078af20bd635e  vmovaps xmm14, [rsp+0xD0]
000078af20bd6367  vmovaps xmm15, [rsp+0xE0]
000078af20bd6370  add rsp, 0xF0
000078af20bd6377  pop r11
000078af20bd6379  pop r10
000078af20bd637b  pop r9
000078af20bd637d  pop r8
000078af20bd637f  pop rsi
000078af20bd6380  pop rdi
000078af20bd6381  pop rdx
000078af20bd6382  pop rcx
000078af20bd6383  pop rax
000078af20bd6384  add rsp, 0x08
000078af20bd6388  jmp 0x000078AF20BD30B6
000078af20bd638d  sub rsp, 0x08
000078af20bd6391  push rax
000078af20bd6392  push rcx
000078af20bd6393  push rdx
000078af20bd6394  push rdi
000078af20bd6395  push rsi
000078af20bd6396  push r8
000078af20bd6398  push r9
000078af20bd639a  push r10
000078af20bd639c  push r11
000078af20bd639e  sub rsp, 0xF0
000078af20bd63a5  vmovaps [rsp], xmm0
000078af20bd63aa  vmovaps [rsp+0x10], xmm1
000078af20bd63b0  vmovaps [rsp+0x20], xmm2
000078af20bd63b6  vmovaps [rsp+0x30], xmm3
000078af20bd63bc  vmovaps [rsp+0x40], xmm4
000078af20bd63c2  vmovaps [rsp+0x50], xmm5
000078af20bd63c8  vmovaps [rsp+0x60], xmm6
000078af20bd63ce  vmovaps [rsp+0x70], xmm7
000078af20bd63d4  vmovaps [rsp+0x80], xmm8
000078af20bd63dd  vmovaps [rsp+0x90], xmm9
000078af20bd63e6  vmovaps [rsp+0xA0], xmm10
000078af20bd63ef  vmovaps [rsp+0xB0], xmm12
000078af20bd63f8  vmovaps [rsp+0xC0], xmm13
000078af20bd6401  vmovaps [rsp+0xD0], xmm14
000078af20bd640a  vmovaps [rsp+0xE0], xmm15
000078af20bd6413  sub rsp, 0x30
000078af20bd6417  movaps [rsp], xmm11
000078af20bd641c  movaps [rsp+0x10], xmm2
000078af20bd6421  movaps [rsp+0x20], xmm1
000078af20bd6426  lea rdi, [rsp]
000078af20bd642a  mov esi, 0x00
000078af20bd642f  mov rax, 0x65452FFB8530
000078af20bd6439  call rax
000078af20bd643b  movaps xmm11, [rsp]
000078af20bd6440  add rsp, 0x30
000078af20bd6444  vmovaps xmm0, [rsp]
000078af20bd6449  vmovaps xmm1, [rsp+0x10]
000078af20bd644f  vmovaps xmm2, [rsp+0x20]
000078af20bd6455  vmovaps xmm3, [rsp+0x30]
000078af20bd645b  vmovaps xmm4, [rsp+0x40]
000078af20bd6461  vmovaps xmm5, [rsp+0x50]
000078af20bd6467  vmovaps xmm6, [rsp+0x60]
000078af20bd646d  vmovaps xmm7, [rsp+0x70]
000078af20bd6473  vmovaps xmm8, [rsp+0x80]
000078af20bd647c  vmovaps xmm9, [rsp+0x90]
000078af20bd6485  vmovaps xmm10, [rsp+0xA0]
000078af20bd648e  vmovaps xmm12, [rsp+0xB0]
000078af20bd6497  vmovaps xmm13, [rsp+0xC0]
000078af20bd64a0  vmovaps xmm14, [rsp+0xD0]
000078af20bd64a9  vmovaps xmm15, [rsp+0xE0]
000078af20bd64b2  add rsp, 0xF0
000078af20bd64b9  pop r11
000078af20bd64bb  pop r10
000078af20bd64bd  pop r9
000078af20bd64bf  pop r8
000078af20bd64c1  pop rsi
000078af20bd64c2  pop rdi
000078af20bd64c3  pop rdx
000078af20bd64c4  pop rcx
000078af20bd64c5  pop rax
000078af20bd64c6  add rsp, 0x08
000078af20bd64ca  jmp 0x000078AF20BD30F2
000078af20bd64cf  sub rsp, 0x08
000078af20bd64d3  push rax
000078af20bd64d4  push rcx
000078af20bd64d5  push rdx
000078af20bd64d6  push rdi
000078af20bd64d7  push rsi
000078af20bd64d8  push r8
000078af20bd64da  push r9
000078af20bd64dc  push r10
000078af20bd64de  push r11
000078af20bd64e0  sub rsp, 0xF0
000078af20bd64e7  vmovaps [rsp], xmm0
000078af20bd64ec  vmovaps [rsp+0x10], xmm2
000078af20bd64f2  vmovaps [rsp+0x20], xmm3
000078af20bd64f8  vmovaps [rsp+0x30], xmm4
000078af20bd64fe  vmovaps [rsp+0x40], xmm5
000078af20bd6504  vmovaps [rsp+0x50], xmm6
000078af20bd650a  vmovaps [rsp+0x60], xmm7
000078af20bd6510  vmovaps [rsp+0x70], xmm8
000078af20bd6516  vmovaps [rsp+0x80], xmm9
000078af20bd651f  vmovaps [rsp+0x90], xmm10
000078af20bd6528  vmovaps [rsp+0xA0], xmm11
000078af20bd6531  vmovaps [rsp+0xB0], xmm12
000078af20bd653a  vmovaps [rsp+0xC0], xmm13
000078af20bd6543  vmovaps [rsp+0xD0], xmm14
000078af20bd654c  vmovaps [rsp+0xE0], xmm15
000078af20bd6555  sub rsp, 0x30
000078af20bd6559  movaps [rsp], xmm1
000078af20bd655d  movaps [rsp+0x10], xmm14
000078af20bd6563  movaps [rsp+0x20], xmm6
000078af20bd6568  lea rdi, [rsp]
000078af20bd656c  mov esi, 0x00
000078af20bd6571  mov rax, 0x65452FFB8530
000078af20bd657b  call rax
000078af20bd657d  movaps xmm1, [rsp]
000078af20bd6581  add rsp, 0x30
000078af20bd6585  vmovaps xmm0, [rsp]
000078af20bd658a  vmovaps xmm2, [rsp+0x10]
000078af20bd6590  vmovaps xmm3, [rsp+0x20]
000078af20bd6596  vmovaps xmm4, [rsp+0x30]
000078af20bd659c  vmovaps xmm5, [rsp+0x40]
000078af20bd65a2  vmovaps xmm6, [rsp+0x50]
000078af20bd65a8  vmovaps xmm7, [rsp+0x60]
000078af20bd65ae  vmovaps xmm8, [rsp+0x70]
000078af20bd65b4  vmovaps xmm9, [rsp+0x80]
000078af20bd65bd  vmovaps xmm10, [rsp+0x90]
000078af20bd65c6  vmovaps xmm11, [rsp+0xA0]
000078af20bd65cf  vmovaps xmm12, [rsp+0xB0]
000078af20bd65d8  vmovaps xmm13, [rsp+0xC0]
000078af20bd65e1  vmovaps xmm14, [rsp+0xD0]
000078af20bd65ea  vmovaps xmm15, [rsp+0xE0]
000078af20bd65f3  add rsp, 0xF0
000078af20bd65fa  pop r11
000078af20bd65fc  pop r10
000078af20bd65fe  pop r9
000078af20bd6600  pop r8
000078af20bd6602  pop rsi
000078af20bd6603  pop rdi
000078af20bd6604  pop rdx
000078af20bd6605  pop rcx
000078af20bd6606  pop rax
000078af20bd6607  add rsp, 0x08
000078af20bd660b  jmp 0x000078AF20BD310B
000078af20bd6610  sub rsp, 0x08
000078af20bd6614  push rax
000078af20bd6615  push rcx
000078af20bd6616  push rdx
000078af20bd6617  push rdi
000078af20bd6618  push rsi
000078af20bd6619  push r8
000078af20bd661b  push r9
000078af20bd661d  push r10
000078af20bd661f  push r11
000078af20bd6621  sub rsp, 0xF0
000078af20bd6628  vmovaps [rsp], xmm0
000078af20bd662d  vmovaps [rsp+0x10], xmm1
000078af20bd6633  vmovaps [rsp+0x20], xmm2
000078af20bd6639  vmovaps [rsp+0x30], xmm3
000078af20bd663f  vmovaps [rsp+0x40], xmm4
000078af20bd6645  vmovaps [rsp+0x50], xmm5
000078af20bd664b  vmovaps [rsp+0x60], xmm6
000078af20bd6651  vmovaps [rsp+0x70], xmm7
000078af20bd6657  vmovaps [rsp+0x80], xmm8
000078af20bd6660  vmovaps [rsp+0x90], xmm9
000078af20bd6669  vmovaps [rsp+0xA0], xmm10
000078af20bd6672  vmovaps [rsp+0xB0], xmm11
000078af20bd667b  vmovaps [rsp+0xC0], xmm12
000078af20bd6684  vmovaps [rsp+0xD0], xmm13
000078af20bd668d  vmovaps [rsp+0xE0], xmm14
000078af20bd6696  sub rsp, 0x30
000078af20bd669a  movaps [rsp], xmm15
000078af20bd669f  movaps [rsp+0x10], xmm14
000078af20bd66a5  movaps [rsp+0x20], xmm5
000078af20bd66aa  lea rdi, [rsp]
000078af20bd66ae  mov esi, 0x00
000078af20bd66b3  mov rax, 0x65452FFB8530
000078af20bd66bd  call rax
000078af20bd66bf  movaps xmm15, [rsp]
000078af20bd66c4  add rsp, 0x30
000078af20bd66c8  vmovaps xmm0, [rsp]
000078af20bd66cd  vmovaps xmm1, [rsp+0x10]
000078af20bd66d3  vmovaps xmm2, [rsp+0x20]
000078af20bd66d9  vmovaps xmm3, [rsp+0x30]
000078af20bd66df  vmovaps xmm4, [rsp+0x40]
000078af20bd66e5  vmovaps xmm5, [rsp+0x50]
000078af20bd66eb  vmovaps xmm6, [rsp+0x60]
000078af20bd66f1  vmovaps xmm7, [rsp+0x70]
000078af20bd66f7  vmovaps xmm8, [rsp+0x80]
000078af20bd6700  vmovaps xmm9, [rsp+0x90]
000078af20bd6709  vmovaps xmm10, [rsp+0xA0]
000078af20bd6712  vmovaps xmm11, [rsp+0xB0]
000078af20bd671b  vmovaps xmm12, [rsp+0xC0]
000078af20bd6724  vmovaps xmm13, [rsp+0xD0]
000078af20bd672d  vmovaps xmm14, [rsp+0xE0]
000078af20bd6736  add rsp, 0xF0
000078af20bd673d  pop r11
000078af20bd673f  pop r10
000078af20bd6741  pop r9
000078af20bd6743  pop r8
000078af20bd6745  pop rsi
000078af20bd6746  pop rdi
000078af20bd6747  pop rdx
000078af20bd6748  pop rcx
000078af20bd6749  pop rax
000078af20bd674a  add rsp, 0x08
000078af20bd674e  jmp 0x000078AF20BD312B
000078af20bd6753  sub rsp, 0x08
000078af20bd6757  push rax
000078af20bd6758  push rcx
000078af20bd6759  push rdx
000078af20bd675a  push rdi
000078af20bd675b  push rsi
000078af20bd675c  push r8
000078af20bd675e  push r9
000078af20bd6760  push r10
000078af20bd6762  push r11
000078af20bd6764  sub rsp, 0xF0
000078af20bd676b  vmovaps [rsp], xmm0
000078af20bd6770  vmovaps [rsp+0x10], xmm1
000078af20bd6776  vmovaps [rsp+0x20], xmm2
000078af20bd677c  vmovaps [rsp+0x30], xmm3
000078af20bd6782  vmovaps [rsp+0x40], xmm4
000078af20bd6788  vmovaps [rsp+0x50], xmm5
000078af20bd678e  vmovaps [rsp+0x60], xmm7
000078af20bd6794  vmovaps [rsp+0x70], xmm8
000078af20bd679a  vmovaps [rsp+0x80], xmm9
000078af20bd67a3  vmovaps [rsp+0x90], xmm10
000078af20bd67ac  vmovaps [rsp+0xA0], xmm11
000078af20bd67b5  vmovaps [rsp+0xB0], xmm12
000078af20bd67be  vmovaps [rsp+0xC0], xmm13
000078af20bd67c7  vmovaps [rsp+0xD0], xmm14
000078af20bd67d0  vmovaps [rsp+0xE0], xmm15
000078af20bd67d9  sub rsp, 0x30
000078af20bd67dd  movaps [rsp], xmm6
000078af20bd67e1  movaps [rsp+0x10], xmm9
000078af20bd67e7  movaps [rsp+0x20], xmm14
000078af20bd67ed  lea rdi, [rsp]
000078af20bd67f1  mov esi, 0x00
000078af20bd67f6  mov rax, 0x65452FFB8530
000078af20bd6800  call rax
000078af20bd6802  movaps xmm6, [rsp]
000078af20bd6806  add rsp, 0x30
000078af20bd680a  vmovaps xmm0, [rsp]
000078af20bd680f  vmovaps xmm1, [rsp+0x10]
000078af20bd6815  vmovaps xmm2, [rsp+0x20]
000078af20bd681b  vmovaps xmm3, [rsp+0x30]
000078af20bd6821  vmovaps xmm4, [rsp+0x40]
000078af20bd6827  vmovaps xmm5, [rsp+0x50]
000078af20bd682d  vmovaps xmm7, [rsp+0x60]
000078af20bd6833  vmovaps xmm8, [rsp+0x70]
000078af20bd6839  vmovaps xmm9, [rsp+0x80]
000078af20bd6842  vmovaps xmm10, [rsp+0x90]
000078af20bd684b  vmovaps xmm11, [rsp+0xA0]
000078af20bd6854  vmovaps xmm12, [rsp+0xB0]
000078af20bd685d  vmovaps xmm13, [rsp+0xC0]
000078af20bd6866  vmovaps xmm14, [rsp+0xD0]
000078af20bd686f  vmovaps xmm15, [rsp+0xE0]
000078af20bd6878  add rsp, 0xF0
000078af20bd687f  pop r11
000078af20bd6881  pop r10
000078af20bd6883  pop r9
000078af20bd6885  pop r8
000078af20bd6887  pop rsi
000078af20bd6888  pop rdi
000078af20bd6889  pop rdx
000078af20bd688a  pop rcx
000078af20bd688b  pop rax
000078af20bd688c  add rsp, 0x08
000078af20bd6890  jmp 0x000078AF20BD3153
000078af20bd6895  sub rsp, 0x08
000078af20bd6899  push rax
000078af20bd689a  push rcx
000078af20bd689b  push rdx
000078af20bd689c  push rdi
000078af20bd689d  push rsi
000078af20bd689e  push r8
000078af20bd68a0  push r9
000078af20bd68a2  push r10
000078af20bd68a4  push r11
000078af20bd68a6  sub rsp, 0xF0
000078af20bd68ad  vmovaps [rsp], xmm0
000078af20bd68b2  vmovaps [rsp+0x10], xmm1
000078af20bd68b8  vmovaps [rsp+0x20], xmm2
000078af20bd68be  vmovaps [rsp+0x30], xmm3
000078af20bd68c4  vmovaps [rsp+0x40], xmm4
000078af20bd68ca  vmovaps [rsp+0x50], xmm5
000078af20bd68d0  vmovaps [rsp+0x60], xmm6
000078af20bd68d6  vmovaps [rsp+0x70], xmm7
000078af20bd68dc  vmovaps [rsp+0x80], xmm8
000078af20bd68e5  vmovaps [rsp+0x90], xmm9
000078af20bd68ee  vmovaps [rsp+0xA0], xmm10
000078af20bd68f7  vmovaps [rsp+0xB0], xmm11
000078af20bd6900  vmovaps [rsp+0xC0], xmm12
000078af20bd6909  vmovaps [rsp+0xD0], xmm13
000078af20bd6912  vmovaps [rsp+0xE0], xmm15
000078af20bd691b  sub rsp, 0x30
000078af20bd691f  movaps [rsp], xmm14
000078af20bd6924  movaps [rsp+0x10], xmm9
000078af20bd692a  movaps [rsp+0x20], xmm13
000078af20bd6930  lea rdi, [rsp]
000078af20bd6934  mov esi, 0x00
000078af20bd6939  mov rax, 0x65452FFB8530
000078af20bd6943  call rax
000078af20bd6945  movaps xmm14, [rsp]
000078af20bd694a  add rsp, 0x30
000078af20bd694e  vmovaps xmm0, [rsp]
000078af20bd6953  vmovaps xmm1, [rsp+0x10]
000078af20bd6959  vmovaps xmm2, [rsp+0x20]
000078af20bd695f  vmovaps xmm3, [rsp+0x30]
000078af20bd6965  vmovaps xmm4, [rsp+0x40]
000078af20bd696b  vmovaps xmm5, [rsp+0x50]
000078af20bd6971  vmovaps xmm6, [rsp+0x60]
000078af20bd6977  vmovaps xmm7, [rsp+0x70]
000078af20bd697d  vmovaps xmm8, [rsp+0x80]
000078af20bd6986  vmovaps xmm9, [rsp+0x90]
000078af20bd698f  vmovaps xmm10, [rsp+0xA0]
000078af20bd6998  vmovaps xmm11, [rsp+0xB0]
000078af20bd69a1  vmovaps xmm12, [rsp+0xC0]
000078af20bd69aa  vmovaps xmm13, [rsp+0xD0]
000078af20bd69b3  vmovaps xmm15, [rsp+0xE0]
000078af20bd69bc  add rsp, 0xF0
000078af20bd69c3  pop r11
000078af20bd69c5  pop r10
000078af20bd69c7  pop r9
000078af20bd69c9  pop r8
000078af20bd69cb  pop rsi
000078af20bd69cc  pop rdi
000078af20bd69cd  pop rdx
000078af20bd69ce  pop rcx
000078af20bd69cf  pop rax
000078af20bd69d0  add rsp, 0x08
000078af20bd69d4  jmp 0x000078AF20BD3176
000078af20bd69d9  sub rsp, 0x08
000078af20bd69dd  push rax
000078af20bd69de  push rcx
000078af20bd69df  push rdx
000078af20bd69e0  push rdi
000078af20bd69e1  push rsi
000078af20bd69e2  push r8
000078af20bd69e4  push r9
000078af20bd69e6  push r10
000078af20bd69e8  push r11
000078af20bd69ea  sub rsp, 0xF0
000078af20bd69f1  vmovaps [rsp], xmm0
000078af20bd69f6  vmovaps [rsp+0x10], xmm1
000078af20bd69fc  vmovaps [rsp+0x20], xmm2
000078af20bd6a02  vmovaps [rsp+0x30], xmm3
000078af20bd6a08  vmovaps [rsp+0x40], xmm4
000078af20bd6a0e  vmovaps [rsp+0x50], xmm5
000078af20bd6a14  vmovaps [rsp+0x60], xmm6
000078af20bd6a1a  vmovaps [rsp+0x70], xmm7
000078af20bd6a20  vmovaps [rsp+0x80], xmm8
000078af20bd6a29  vmovaps [rsp+0x90], xmm9
000078af20bd6a32  vmovaps [rsp+0xA0], xmm10
000078af20bd6a3b  vmovaps [rsp+0xB0], xmm11
000078af20bd6a44  vmovaps [rsp+0xC0], xmm12
000078af20bd6a4d  vmovaps [rsp+0xD0], xmm14
000078af20bd6a56  vmovaps [rsp+0xE0], xmm15
000078af20bd6a5f  sub rsp, 0x30
000078af20bd6a63  movaps [rsp], xmm13
000078af20bd6a68  movaps [rsp+0x10], xmm9
000078af20bd6a6e  movaps [rsp+0x20], xmm10
000078af20bd6a74  lea rdi, [rsp]
000078af20bd6a78  mov esi, 0x00
000078af20bd6a7d  mov rax, 0x65452FFB8530
000078af20bd6a87  call rax
000078af20bd6a89  movaps xmm13, [rsp]
000078af20bd6a8e  add rsp, 0x30
000078af20bd6a92  vmovaps xmm0, [rsp]
000078af20bd6a97  vmovaps xmm1, [rsp+0x10]
000078af20bd6a9d  vmovaps xmm2, [rsp+0x20]
000078af20bd6aa3  vmovaps xmm3, [rsp+0x30]
000078af20bd6aa9  vmovaps xmm4, [rsp+0x40]
000078af20bd6aaf  vmovaps xmm5, [rsp+0x50]
000078af20bd6ab5  vmovaps xmm6, [rsp+0x60]
000078af20bd6abb  vmovaps xmm7, [rsp+0x70]
000078af20bd6ac1  vmovaps xmm8, [rsp+0x80]
000078af20bd6aca  vmovaps xmm9, [rsp+0x90]
000078af20bd6ad3  vmovaps xmm10, [rsp+0xA0]
000078af20bd6adc  vmovaps xmm11, [rsp+0xB0]
000078af20bd6ae5  vmovaps xmm12, [rsp+0xC0]
000078af20bd6aee  vmovaps xmm14, [rsp+0xD0]
000078af20bd6af7  vmovaps xmm15, [rsp+0xE0]
000078af20bd6b00  add rsp, 0xF0
000078af20bd6b07  pop r11
000078af20bd6b09  pop r10
000078af20bd6b0b  pop r9
000078af20bd6b0d  pop r8
000078af20bd6b0f  pop rsi
000078af20bd6b10  pop rdi
000078af20bd6b11  pop rdx
000078af20bd6b12  pop rcx
000078af20bd6b13  pop rax
000078af20bd6b14  add rsp, 0x08
000078af20bd6b18  jmp 0x000078AF20BD3196
000078af20bd6b1d  call 0x000078AF20A0AFE0
000078af20bd6b22  jmp 0x000078AF20BD31EB
000078af20bd6b27  sub rsp, 0x08
000078af20bd6b2b  push rax
000078af20bd6b2c  push rcx
000078af20bd6b2d  push rdx
000078af20bd6b2e  push rdi
000078af20bd6b2f  push rsi
000078af20bd6b30  push r8
000078af20bd6b32  push r9
000078af20bd6b34  push r10
000078af20bd6b36  push r11
000078af20bd6b38  sub rsp, 0xF0
000078af20bd6b3f  vmovaps [rsp], xmm0
000078af20bd6b44  vmovaps [rsp+0x10], xmm1
000078af20bd6b4a  vmovaps [rsp+0x20], xmm2
000078af20bd6b50  vmovaps [rsp+0x30], xmm3
000078af20bd6b56  vmovaps [rsp+0x40], xmm4
000078af20bd6b5c  vmovaps [rsp+0x50], xmm5
000078af20bd6b62  vmovaps [rsp+0x60], xmm6
000078af20bd6b68  vmovaps [rsp+0x70], xmm7
000078af20bd6b6e  vmovaps [rsp+0x80], xmm8
000078af20bd6b77  vmovaps [rsp+0x90], xmm10
000078af20bd6b80  vmovaps [rsp+0xA0], xmm11
000078af20bd6b89  vmovaps [rsp+0xB0], xmm12
000078af20bd6b92  vmovaps [rsp+0xC0], xmm13
000078af20bd6b9b  vmovaps [rsp+0xD0], xmm14
000078af20bd6ba4  vmovaps [rsp+0xE0], xmm15
000078af20bd6bad  sub rsp, 0x30
000078af20bd6bb1  movaps [rsp], xmm9
000078af20bd6bb6  movaps [rsp+0x10], xmm8
000078af20bd6bbc  movaps [rsp+0x20], xmm10
000078af20bd6bc2  lea rdi, [rsp]
000078af20bd6bc6  mov esi, 0x00
000078af20bd6bcb  mov rax, 0x65452FFB8530
000078af20bd6bd5  call rax
000078af20bd6bd7  movaps xmm9, [rsp]
000078af20bd6bdc  add rsp, 0x30
000078af20bd6be0  vmovaps xmm0, [rsp]
000078af20bd6be5  vmovaps xmm1, [rsp+0x10]
000078af20bd6beb  vmovaps xmm2, [rsp+0x20]
000078af20bd6bf1  vmovaps xmm3, [rsp+0x30]
000078af20bd6bf7  vmovaps xmm4, [rsp+0x40]
000078af20bd6bfd  vmovaps xmm5, [rsp+0x50]
000078af20bd6c03  vmovaps xmm6, [rsp+0x60]
000078af20bd6c09  vmovaps xmm7, [rsp+0x70]
000078af20bd6c0f  vmovaps xmm8, [rsp+0x80]
000078af20bd6c18  vmovaps xmm10, [rsp+0x90]
000078af20bd6c21  vmovaps xmm11, [rsp+0xA0]
000078af20bd6c2a  vmovaps xmm12, [rsp+0xB0]
000078af20bd6c33  vmovaps xmm13, [rsp+0xC0]
000078af20bd6c3c  vmovaps xmm14, [rsp+0xD0]
000078af20bd6c45  vmovaps xmm15, [rsp+0xE0]
000078af20bd6c4e  add rsp, 0xF0
000078af20bd6c55  pop r11
000078af20bd6c57  pop r10
000078af20bd6c59  pop r9
000078af20bd6c5b  pop r8
000078af20bd6c5d  pop rsi
000078af20bd6c5e  pop rdi
000078af20bd6c5f  pop rdx
000078af20bd6c60  pop rcx
000078af20bd6c61  pop rax
000078af20bd6c62  add rsp, 0x08
000078af20bd6c66  jmp 0x000078AF20BD321C
000078af20bd6c6b  sub rsp, 0x08
000078af20bd6c6f  push rax
000078af20bd6c70  push rcx
000078af20bd6c71  push rdx
000078af20bd6c72  push rdi
000078af20bd6c73  push rsi
000078af20bd6c74  push r8
000078af20bd6c76  push r9
000078af20bd6c78  push r10
000078af20bd6c7a  push r11
000078af20bd6c7c  sub rsp, 0xF0
000078af20bd6c83  vmovaps [rsp], xmm0
000078af20bd6c88  vmovaps [rsp+0x10], xmm1
000078af20bd6c8e  vmovaps [rsp+0x20], xmm2
000078af20bd6c94  vmovaps [rsp+0x30], xmm3
000078af20bd6c9a  vmovaps [rsp+0x40], xmm4
000078af20bd6ca0  vmovaps [rsp+0x50], xmm5
000078af20bd6ca6  vmovaps [rsp+0x60], xmm6
000078af20bd6cac  vmovaps [rsp+0x70], xmm7
000078af20bd6cb2  vmovaps [rsp+0x80], xmm8
000078af20bd6cbb  vmovaps [rsp+0x90], xmm9
000078af20bd6cc4  vmovaps [rsp+0xA0], xmm11
000078af20bd6ccd  vmovaps [rsp+0xB0], xmm12
000078af20bd6cd6  vmovaps [rsp+0xC0], xmm13
000078af20bd6cdf  vmovaps [rsp+0xD0], xmm14
000078af20bd6ce8  vmovaps [rsp+0xE0], xmm15
000078af20bd6cf1  sub rsp, 0x30
000078af20bd6cf5  movaps [rsp], xmm10
000078af20bd6cfa  movaps [rsp+0x10], xmm1
000078af20bd6cff  movaps [rsp+0x20], xmm11
000078af20bd6d05  lea rdi, [rsp]
000078af20bd6d09  mov esi, 0x00
000078af20bd6d0e  mov rax, 0x65452FFB8530
000078af20bd6d18  call rax
000078af20bd6d1a  movaps xmm10, [rsp]
000078af20bd6d1f  add rsp, 0x30
000078af20bd6d23  vmovaps xmm0, [rsp]
000078af20bd6d28  vmovaps xmm1, [rsp+0x10]
000078af20bd6d2e  vmovaps xmm2, [rsp+0x20]
000078af20bd6d34  vmovaps xmm3, [rsp+0x30]
000078af20bd6d3a  vmovaps xmm4, [rsp+0x40]
000078af20bd6d40  vmovaps xmm5, [rsp+0x50]
000078af20bd6d46  vmovaps xmm6, [rsp+0x60]
000078af20bd6d4c  vmovaps xmm7, [rsp+0x70]
000078af20bd6d52  vmovaps xmm8, [rsp+0x80]
000078af20bd6d5b  vmovaps xmm9, [rsp+0x90]
000078af20bd6d64  vmovaps xmm11, [rsp+0xA0]
000078af20bd6d6d  vmovaps xmm12, [rsp+0xB0]
000078af20bd6d76  vmovaps xmm13, [rsp+0xC0]
000078af20bd6d7f  vmovaps xmm14, [rsp+0xD0]
000078af20bd6d88  vmovaps xmm15, [rsp+0xE0]
000078af20bd6d91  add rsp, 0xF0
000078af20bd6d98  pop r11
000078af20bd6d9a  pop r10
000078af20bd6d9c  pop r9
000078af20bd6d9e  pop r8
000078af20bd6da0  pop rsi
000078af20bd6da1  pop rdi
000078af20bd6da2  pop rdx
000078af20bd6da3  pop rcx
000078af20bd6da4  pop rax
000078af20bd6da5  add rsp, 0x08
000078af20bd6da9  jmp 0x000078AF20BD3237
000078af20bd6dae  sub rsp, 0x08
000078af20bd6db2  push rax
000078af20bd6db3  push rcx
000078af20bd6db4  push rdx
000078af20bd6db5  push rdi
000078af20bd6db6  push rsi
000078af20bd6db7  push r8
000078af20bd6db9  push r9
000078af20bd6dbb  push r10
000078af20bd6dbd  push r11
000078af20bd6dbf  sub rsp, 0xF0
000078af20bd6dc6  vmovaps [rsp], xmm0
000078af20bd6dcb  vmovaps [rsp+0x10], xmm2
000078af20bd6dd1  vmovaps [rsp+0x20], xmm3
000078af20bd6dd7  vmovaps [rsp+0x30], xmm4
000078af20bd6ddd  vmovaps [rsp+0x40], xmm5
000078af20bd6de3  vmovaps [rsp+0x50], xmm6
000078af20bd6de9  vmovaps [rsp+0x60], xmm7
000078af20bd6def  vmovaps [rsp+0x70], xmm8
000078af20bd6df5  vmovaps [rsp+0x80], xmm9
000078af20bd6dfe  vmovaps [rsp+0x90], xmm10
000078af20bd6e07  vmovaps [rsp+0xA0], xmm11
000078af20bd6e10  vmovaps [rsp+0xB0], xmm12
000078af20bd6e19  vmovaps [rsp+0xC0], xmm13
000078af20bd6e22  vmovaps [rsp+0xD0], xmm14
000078af20bd6e2b  vmovaps [rsp+0xE0], xmm15
000078af20bd6e34  sub rsp, 0x30
000078af20bd6e38  movaps [rsp], xmm1
000078af20bd6e3c  movaps [rsp+0x10], xmm15
000078af20bd6e42  movaps [rsp+0x20], xmm6
000078af20bd6e47  lea rdi, [rsp]
000078af20bd6e4b  mov esi, 0x00
000078af20bd6e50  mov rax, 0x65452FFB8530
000078af20bd6e5a  call rax
000078af20bd6e5c  movaps xmm1, [rsp]
000078af20bd6e60  add rsp, 0x30
000078af20bd6e64  vmovaps xmm0, [rsp]
000078af20bd6e69  vmovaps xmm2, [rsp+0x10]
000078af20bd6e6f  vmovaps xmm3, [rsp+0x20]
000078af20bd6e75  vmovaps xmm4, [rsp+0x30]
000078af20bd6e7b  vmovaps xmm5, [rsp+0x40]
000078af20bd6e81  vmovaps xmm6, [rsp+0x50]
000078af20bd6e87  vmovaps xmm7, [rsp+0x60]
000078af20bd6e8d  vmovaps xmm8, [rsp+0x70]
000078af20bd6e93  vmovaps xmm9, [rsp+0x80]
000078af20bd6e9c  vmovaps xmm10, [rsp+0x90]
000078af20bd6ea5  vmovaps xmm11, [rsp+0xA0]
000078af20bd6eae  vmovaps xmm12, [rsp+0xB0]
000078af20bd6eb7  vmovaps xmm13, [rsp+0xC0]
000078af20bd6ec0  vmovaps xmm14, [rsp+0xD0]
000078af20bd6ec9  vmovaps xmm15, [rsp+0xE0]
000078af20bd6ed2  add rsp, 0xF0
000078af20bd6ed9  pop r11
000078af20bd6edb  pop r10
000078af20bd6edd  pop r9
000078af20bd6edf  pop r8
000078af20bd6ee1  pop rsi
000078af20bd6ee2  pop rdi
000078af20bd6ee3  pop rdx
000078af20bd6ee4  pop rcx
000078af20bd6ee5  pop rax
000078af20bd6ee6  add rsp, 0x08
000078af20bd6eea  jmp 0x000078AF20BD3250
000078af20bd6eef  sub rsp, 0x08
000078af20bd6ef3  push rax
000078af20bd6ef4  push rcx
000078af20bd6ef5  push rdx
000078af20bd6ef6  push rdi
000078af20bd6ef7  push rsi
000078af20bd6ef8  push r8
000078af20bd6efa  push r9
000078af20bd6efc  push r10
000078af20bd6efe  push r11
000078af20bd6f00  sub rsp, 0xF0
000078af20bd6f07  vmovaps [rsp], xmm0
000078af20bd6f0c  vmovaps [rsp+0x10], xmm1
000078af20bd6f12  vmovaps [rsp+0x20], xmm2
000078af20bd6f18  vmovaps [rsp+0x30], xmm3
000078af20bd6f1e  vmovaps [rsp+0x40], xmm4
000078af20bd6f24  vmovaps [rsp+0x50], xmm5
000078af20bd6f2a  vmovaps [rsp+0x60], xmm6
000078af20bd6f30  vmovaps [rsp+0x70], xmm7
000078af20bd6f36  vmovaps [rsp+0x80], xmm8
000078af20bd6f3f  vmovaps [rsp+0x90], xmm9
000078af20bd6f48  vmovaps [rsp+0xA0], xmm10
000078af20bd6f51  vmovaps [rsp+0xB0], xmm12
000078af20bd6f5a  vmovaps [rsp+0xC0], xmm13
000078af20bd6f63  vmovaps [rsp+0xD0], xmm14
000078af20bd6f6c  vmovaps [rsp+0xE0], xmm15
000078af20bd6f75  sub rsp, 0x30
000078af20bd6f79  movaps [rsp], xmm11
000078af20bd6f7e  movaps [rsp+0x10], xmm12
000078af20bd6f84  movaps [rsp+0x20], xmm15
000078af20bd6f8a  lea rdi, [rsp]
000078af20bd6f8e  mov esi, 0x00
000078af20bd6f93  mov rax, 0x65452FFB8530
000078af20bd6f9d  call rax
000078af20bd6f9f  movaps xmm11, [rsp]
000078af20bd6fa4  add rsp, 0x30
000078af20bd6fa8  vmovaps xmm0, [rsp]
000078af20bd6fad  vmovaps xmm1, [rsp+0x10]
000078af20bd6fb3  vmovaps xmm2, [rsp+0x20]
000078af20bd6fb9  vmovaps xmm3, [rsp+0x30]
000078af20bd6fbf  vmovaps xmm4, [rsp+0x40]
000078af20bd6fc5  vmovaps xmm5, [rsp+0x50]
000078af20bd6fcb  vmovaps xmm6, [rsp+0x60]
000078af20bd6fd1  vmovaps xmm7, [rsp+0x70]
000078af20bd6fd7  vmovaps xmm8, [rsp+0x80]
000078af20bd6fe0  vmovaps xmm9, [rsp+0x90]
000078af20bd6fe9  vmovaps xmm10, [rsp+0xA0]
000078af20bd6ff2  vmovaps xmm12, [rsp+0xB0]
000078af20bd6ffb  vmovaps xmm13, [rsp+0xC0]
000078af20bd7004  vmovaps xmm14, [rsp+0xD0]
000078af20bd700d  vmovaps xmm15, [rsp+0xE0]
000078af20bd7016  add rsp, 0xF0
000078af20bd701d  pop r11
000078af20bd701f  pop r10
000078af20bd7021  pop r9
000078af20bd7023  pop r8
000078af20bd7025  pop rsi
000078af20bd7026  pop rdi
000078af20bd7027  pop rdx
000078af20bd7028  pop rcx
000078af20bd7029  pop rax
000078af20bd702a  add rsp, 0x08
000078af20bd702e  jmp 0x000078AF20BD327A
000078af20bd7033  sub rsp, 0x08
000078af20bd7037  push rax
000078af20bd7038  push rcx
000078af20bd7039  push rdx
000078af20bd703a  push rdi
000078af20bd703b  push rsi
000078af20bd703c  push r8
000078af20bd703e  push r9
000078af20bd7040  push r10
000078af20bd7042  push r11
000078af20bd7044  sub rsp, 0xF0
000078af20bd704b  vmovaps [rsp], xmm0
000078af20bd7050  vmovaps [rsp+0x10], xmm1
000078af20bd7056  vmovaps [rsp+0x20], xmm2
000078af20bd705c  vmovaps [rsp+0x30], xmm3
000078af20bd7062  vmovaps [rsp+0x40], xmm4
000078af20bd7068  vmovaps [rsp+0x50], xmm5
000078af20bd706e  vmovaps [rsp+0x60], xmm6
000078af20bd7074  vmovaps [rsp+0x70], xmm7
000078af20bd707a  vmovaps [rsp+0x80], xmm8
000078af20bd7083  vmovaps [rsp+0x90], xmm9
000078af20bd708c  vmovaps [rsp+0xA0], xmm10
000078af20bd7095  vmovaps [rsp+0xB0], xmm11
000078af20bd709e  vmovaps [rsp+0xC0], xmm13
000078af20bd70a7  vmovaps [rsp+0xD0], xmm14
000078af20bd70b0  vmovaps [rsp+0xE0], xmm15
000078af20bd70b9  sub rsp, 0x30
000078af20bd70bd  movaps [rsp], xmm12
000078af20bd70c2  movaps [rsp+0x10], xmm8
000078af20bd70c8  movaps [rsp+0x20], xmm15
000078af20bd70ce  lea rdi, [rsp]
000078af20bd70d2  mov esi, 0x00
000078af20bd70d7  mov rax, 0x65452FFB8530
000078af20bd70e1  call rax
000078af20bd70e3  movaps xmm12, [rsp]
000078af20bd70e8  add rsp, 0x30
000078af20bd70ec  vmovaps xmm0, [rsp]
000078af20bd70f1  vmovaps xmm1, [rsp+0x10]
000078af20bd70f7  vmovaps xmm2, [rsp+0x20]
000078af20bd70fd  vmovaps xmm3, [rsp+0x30]
000078af20bd7103  vmovaps xmm4, [rsp+0x40]
000078af20bd7109  vmovaps xmm5, [rsp+0x50]
000078af20bd710f  vmovaps xmm6, [rsp+0x60]
000078af20bd7115  vmovaps xmm7, [rsp+0x70]
000078af20bd711b  vmovaps xmm8, [rsp+0x80]
000078af20bd7124  vmovaps xmm9, [rsp+0x90]
000078af20bd712d  vmovaps xmm10, [rsp+0xA0]
000078af20bd7136  vmovaps xmm11, [rsp+0xB0]
000078af20bd713f  vmovaps xmm13, [rsp+0xC0]
000078af20bd7148  vmovaps xmm14, [rsp+0xD0]
000078af20bd7151  vmovaps xmm15, [rsp+0xE0]
000078af20bd715a  add rsp, 0xF0
000078af20bd7161  pop r11
000078af20bd7163  pop r10
000078af20bd7165  pop r9
000078af20bd7167  pop r8
000078af20bd7169  pop rsi
000078af20bd716a  pop rdi
000078af20bd716b  pop rdx
000078af20bd716c  pop rcx
000078af20bd716d  pop rax
000078af20bd716e  add rsp, 0x08
000078af20bd7172  jmp 0x000078AF20BD32A9
000078af20bd7177  sub rsp, 0x08
000078af20bd717b  push rax
000078af20bd717c  push rcx
000078af20bd717d  push rdx
000078af20bd717e  push rdi
000078af20bd717f  push rsi
000078af20bd7180  push r8
000078af20bd7182  push r9
000078af20bd7184  push r10
000078af20bd7186  push r11
000078af20bd7188  sub rsp, 0xF0
000078af20bd718f  vmovaps [rsp], xmm0
000078af20bd7194  vmovaps [rsp+0x10], xmm1
000078af20bd719a  vmovaps [rsp+0x20], xmm2
000078af20bd71a0  vmovaps [rsp+0x30], xmm3
000078af20bd71a6  vmovaps [rsp+0x40], xmm4
000078af20bd71ac  vmovaps [rsp+0x50], xmm5
000078af20bd71b2  vmovaps [rsp+0x60], xmm6
000078af20bd71b8  vmovaps [rsp+0x70], xmm7
000078af20bd71be  vmovaps [rsp+0x80], xmm9
000078af20bd71c7  vmovaps [rsp+0x90], xmm10
000078af20bd71d0  vmovaps [rsp+0xA0], xmm11
000078af20bd71d9  vmovaps [rsp+0xB0], xmm12
000078af20bd71e2  vmovaps [rsp+0xC0], xmm13
000078af20bd71eb  vmovaps [rsp+0xD0], xmm14
000078af20bd71f4  vmovaps [rsp+0xE0], xmm15
000078af20bd71fd  sub rsp, 0x30
000078af20bd7201  movaps [rsp], xmm8
000078af20bd7206  movaps [rsp+0x10], xmm7
000078af20bd720b  movaps [rsp+0x20], xmm15
000078af20bd7211  lea rdi, [rsp]
000078af20bd7215  mov esi, 0x00
000078af20bd721a  mov rax, 0x65452FFB8530
000078af20bd7224  call rax
000078af20bd7226  movaps xmm8, [rsp]
000078af20bd722b  add rsp, 0x30
000078af20bd722f  vmovaps xmm0, [rsp]
000078af20bd7234  vmovaps xmm1, [rsp+0x10]
000078af20bd723a  vmovaps xmm2, [rsp+0x20]
000078af20bd7240  vmovaps xmm3, [rsp+0x30]
000078af20bd7246  vmovaps xmm4, [rsp+0x40]
000078af20bd724c  vmovaps xmm5, [rsp+0x50]
000078af20bd7252  vmovaps xmm6, [rsp+0x60]
000078af20bd7258  vmovaps xmm7, [rsp+0x70]
000078af20bd725e  vmovaps xmm9, [rsp+0x80]
000078af20bd7267  vmovaps xmm10, [rsp+0x90]
000078af20bd7270  vmovaps xmm11, [rsp+0xA0]
000078af20bd7279  vmovaps xmm12, [rsp+0xB0]
000078af20bd7282  vmovaps xmm13, [rsp+0xC0]
000078af20bd728b  vmovaps xmm14, [rsp+0xD0]
000078af20bd7294  vmovaps xmm15, [rsp+0xE0]
000078af20bd729d  add rsp, 0xF0
000078af20bd72a4  pop r11
000078af20bd72a6  pop r10
000078af20bd72a8  pop r9
000078af20bd72aa  pop r8
000078af20bd72ac  pop rsi
000078af20bd72ad  pop rdi
000078af20bd72ae  pop rdx
000078af20bd72af  pop rcx
000078af20bd72b0  pop rax
000078af20bd72b1  add rsp, 0x08
000078af20bd72b5  jmp 0x000078AF20BD32CF
000078af20bd72ba  sub rsp, 0x08
000078af20bd72be  push rax
000078af20bd72bf  push rcx
000078af20bd72c0  push rdx
000078af20bd72c1  push rdi
000078af20bd72c2  push rsi
000078af20bd72c3  push r8
000078af20bd72c5  push r9
000078af20bd72c7  push r10
000078af20bd72c9  push r11
000078af20bd72cb  sub rsp, 0xF0
000078af20bd72d2  vmovaps [rsp], xmm0
000078af20bd72d7  vmovaps [rsp+0x10], xmm1
000078af20bd72dd  vmovaps [rsp+0x20], xmm2
000078af20bd72e3  vmovaps [rsp+0x30], xmm3
000078af20bd72e9  vmovaps [rsp+0x40], xmm4
000078af20bd72ef  vmovaps [rsp+0x50], xmm5
000078af20bd72f5  vmovaps [rsp+0x60], xmm6
000078af20bd72fb  vmovaps [rsp+0x70], xmm7
000078af20bd7301  vmovaps [rsp+0x80], xmm8
000078af20bd730a  vmovaps [rsp+0x90], xmm9
000078af20bd7313  vmovaps [rsp+0xA0], xmm10
000078af20bd731c  vmovaps [rsp+0xB0], xmm11
000078af20bd7325  vmovaps [rsp+0xC0], xmm12
000078af20bd732e  vmovaps [rsp+0xD0], xmm13
000078af20bd7337  vmovaps [rsp+0xE0], xmm14
000078af20bd7340  sub rsp, 0x30
000078af20bd7344  movaps [rsp], xmm15
000078af20bd7349  movaps [rsp+0x10], xmm14
000078af20bd734f  movaps [rsp+0x20], xmm9
000078af20bd7355  lea rdi, [rsp]
000078af20bd7359  mov esi, 0x00
000078af20bd735e  mov rax, 0x65452FFB8530
000078af20bd7368  call rax
000078af20bd736a  movaps xmm15, [rsp]
000078af20bd736f  add rsp, 0x30
000078af20bd7373  vmovaps xmm0, [rsp]
000078af20bd7378  vmovaps xmm1, [rsp+0x10]
000078af20bd737e  vmovaps xmm2, [rsp+0x20]
000078af20bd7384  vmovaps xmm3, [rsp+0x30]
000078af20bd738a  vmovaps xmm4, [rsp+0x40]
000078af20bd7390  vmovaps xmm5, [rsp+0x50]
000078af20bd7396  vmovaps xmm6, [rsp+0x60]
000078af20bd739c  vmovaps xmm7, [rsp+0x70]
000078af20bd73a2  vmovaps xmm8, [rsp+0x80]
000078af20bd73ab  vmovaps xmm9, [rsp+0x90]
000078af20bd73b4  vmovaps xmm10, [rsp+0xA0]
000078af20bd73bd  vmovaps xmm11, [rsp+0xB0]
000078af20bd73c6  vmovaps xmm12, [rsp+0xC0]
000078af20bd73cf  vmovaps xmm13, [rsp+0xD0]
000078af20bd73d8  vmovaps xmm14, [rsp+0xE0]
000078af20bd73e1  add rsp, 0xF0
000078af20bd73e8  pop r11
000078af20bd73ea  pop r10
000078af20bd73ec  pop r9
000078af20bd73ee  pop r8
000078af20bd73f0  pop rsi
000078af20bd73f1  pop rdi
000078af20bd73f2  pop rdx
000078af20bd73f3  pop rcx
000078af20bd73f4  pop rax
000078af20bd73f5  add rsp, 0x08
000078af20bd73f9  jmp 0x000078AF20BD32E9
000078af20bd73fe  sub rsp, 0x08
000078af20bd7402  push rax
000078af20bd7403  push rcx
000078af20bd7404  push rdx
000078af20bd7405  push rdi
000078af20bd7406  push rsi
000078af20bd7407  push r8
000078af20bd7409  push r9
000078af20bd740b  push r10
000078af20bd740d  push r11
000078af20bd740f  sub rsp, 0xF0
000078af20bd7416  vmovaps [rsp], xmm0
000078af20bd741b  vmovaps [rsp+0x10], xmm1
000078af20bd7421  vmovaps [rsp+0x20], xmm2
000078af20bd7427  vmovaps [rsp+0x30], xmm3
000078af20bd742d  vmovaps [rsp+0x40], xmm4
000078af20bd7433  vmovaps [rsp+0x50], xmm5
000078af20bd7439  vmovaps [rsp+0x60], xmm6
000078af20bd743f  vmovaps [rsp+0x70], xmm7
000078af20bd7445  vmovaps [rsp+0x80], xmm8
000078af20bd744e  vmovaps [rsp+0x90], xmm10
000078af20bd7457  vmovaps [rsp+0xA0], xmm11
000078af20bd7460  vmovaps [rsp+0xB0], xmm12
000078af20bd7469  vmovaps [rsp+0xC0], xmm13
000078af20bd7472  vmovaps [rsp+0xD0], xmm14
000078af20bd747b  vmovaps [rsp+0xE0], xmm15
000078af20bd7484  sub rsp, 0x30
000078af20bd7488  movaps [rsp], xmm9
000078af20bd748d  movaps [rsp+0x10], xmm7
000078af20bd7492  movaps [rsp+0x20], xmm14
000078af20bd7498  lea rdi, [rsp]
000078af20bd749c  mov esi, 0x00
000078af20bd74a1  mov rax, 0x65452FFB8530
000078af20bd74ab  call rax
000078af20bd74ad  movaps xmm9, [rsp]
000078af20bd74b2  add rsp, 0x30
000078af20bd74b6  vmovaps xmm0, [rsp]
000078af20bd74bb  vmovaps xmm1, [rsp+0x10]
000078af20bd74c1  vmovaps xmm2, [rsp+0x20]
000078af20bd74c7  vmovaps xmm3, [rsp+0x30]
000078af20bd74cd  vmovaps xmm4, [rsp+0x40]
000078af20bd74d3  vmovaps xmm5, [rsp+0x50]
000078af20bd74d9  vmovaps xmm6, [rsp+0x60]
000078af20bd74df  vmovaps xmm7, [rsp+0x70]
000078af20bd74e5  vmovaps xmm8, [rsp+0x80]
000078af20bd74ee  vmovaps xmm10, [rsp+0x90]
000078af20bd74f7  vmovaps xmm11, [rsp+0xA0]
000078af20bd7500  vmovaps xmm12, [rsp+0xB0]
000078af20bd7509  vmovaps xmm13, [rsp+0xC0]
000078af20bd7512  vmovaps xmm14, [rsp+0xD0]
000078af20bd751b  vmovaps xmm15, [rsp+0xE0]
000078af20bd7524  add rsp, 0xF0
000078af20bd752b  pop r11
000078af20bd752d  pop r10
000078af20bd752f  pop r9
000078af20bd7531  pop r8
000078af20bd7533  pop rsi
000078af20bd7534  pop rdi
000078af20bd7535  pop rdx
000078af20bd7536  pop rcx
000078af20bd7537  pop rax
000078af20bd7538  add rsp, 0x08
000078af20bd753c  jmp 0x000078AF20BD3318
000078af20bd7541  sub rsp, 0x08
000078af20bd7545  push rax
000078af20bd7546  push rcx
000078af20bd7547  push rdx
000078af20bd7548  push rdi
000078af20bd7549  push rsi
000078af20bd754a  push r8
000078af20bd754c  push r9
000078af20bd754e  push r10
000078af20bd7550  push r11
000078af20bd7552  sub rsp, 0xF0
000078af20bd7559  vmovaps [rsp], xmm0
000078af20bd755e  vmovaps [rsp+0x10], xmm1
000078af20bd7564  vmovaps [rsp+0x20], xmm2
000078af20bd756a  vmovaps [rsp+0x30], xmm3
000078af20bd7570  vmovaps [rsp+0x40], xmm4
000078af20bd7576  vmovaps [rsp+0x50], xmm5
000078af20bd757c  vmovaps [rsp+0x60], xmm6
000078af20bd7582  vmovaps [rsp+0x70], xmm7
000078af20bd7588  vmovaps [rsp+0x80], xmm8
000078af20bd7591  vmovaps [rsp+0x90], xmm9
000078af20bd759a  vmovaps [rsp+0xA0], xmm10
000078af20bd75a3  vmovaps [rsp+0xB0], xmm11
000078af20bd75ac  vmovaps [rsp+0xC0], xmm12
000078af20bd75b5  vmovaps [rsp+0xD0], xmm13
000078af20bd75be  vmovaps [rsp+0xE0], xmm15
000078af20bd75c7  sub rsp, 0x30
000078af20bd75cb  movaps [rsp], xmm14
000078af20bd75d0  movaps [rsp+0x10], xmm13
000078af20bd75d6  movaps [rsp+0x20], xmm11
000078af20bd75dc  lea rdi, [rsp]
000078af20bd75e0  mov esi, 0x00
000078af20bd75e5  mov rax, 0x65452FFB8530
000078af20bd75ef  call rax
000078af20bd75f1  movaps xmm14, [rsp]
000078af20bd75f6  add rsp, 0x30
000078af20bd75fa  vmovaps xmm0, [rsp]
000078af20bd75ff  vmovaps xmm1, [rsp+0x10]
000078af20bd7605  vmovaps xmm2, [rsp+0x20]
000078af20bd760b  vmovaps xmm3, [rsp+0x30]
000078af20bd7611  vmovaps xmm4, [rsp+0x40]
000078af20bd7617  vmovaps xmm5, [rsp+0x50]
000078af20bd761d  vmovaps xmm6, [rsp+0x60]
000078af20bd7623  vmovaps xmm7, [rsp+0x70]
000078af20bd7629  vmovaps xmm8, [rsp+0x80]
000078af20bd7632  vmovaps xmm9, [rsp+0x90]
000078af20bd763b  vmovaps xmm10, [rsp+0xA0]
000078af20bd7644  vmovaps xmm11, [rsp+0xB0]
000078af20bd764d  vmovaps xmm12, [rsp+0xC0]
000078af20bd7656  vmovaps xmm13, [rsp+0xD0]
000078af20bd765f  vmovaps xmm15, [rsp+0xE0]
000078af20bd7668  add rsp, 0xF0
000078af20bd766f  pop r11
000078af20bd7671  pop r10
000078af20bd7673  pop r9
000078af20bd7675  pop r8
000078af20bd7677  pop rsi
000078af20bd7678  pop rdi
000078af20bd7679  pop rdx
000078af20bd767a  pop rcx
000078af20bd767b  pop rax
000078af20bd767c  add rsp, 0x08
000078af20bd7680  jmp 0x000078AF20BD3332
000078af20bd7685  sub rsp, 0x08
000078af20bd7689  push rax
000078af20bd768a  push rcx
000078af20bd768b  push rdx
000078af20bd768c  push rdi
000078af20bd768d  push rsi
000078af20bd768e  push r8
000078af20bd7690  push r9
000078af20bd7692  push r10
000078af20bd7694  push r11
000078af20bd7696  sub rsp, 0xF0
000078af20bd769d  vmovaps [rsp], xmm0
000078af20bd76a2  vmovaps [rsp+0x10], xmm1
000078af20bd76a8  vmovaps [rsp+0x20], xmm2
000078af20bd76ae  vmovaps [rsp+0x30], xmm3
000078af20bd76b4  vmovaps [rsp+0x40], xmm4
000078af20bd76ba  vmovaps [rsp+0x50], xmm5
000078af20bd76c0  vmovaps [rsp+0x60], xmm6
000078af20bd76c6  vmovaps [rsp+0x70], xmm7
000078af20bd76cc  vmovaps [rsp+0x80], xmm8
000078af20bd76d5  vmovaps [rsp+0x90], xmm9
000078af20bd76de  vmovaps [rsp+0xA0], xmm10
000078af20bd76e7  vmovaps [rsp+0xB0], xmm12
000078af20bd76f0  vmovaps [rsp+0xC0], xmm13
000078af20bd76f9  vmovaps [rsp+0xD0], xmm14
000078af20bd7702  vmovaps [rsp+0xE0], xmm15
000078af20bd770b  sub rsp, 0x30
000078af20bd770f  movaps [rsp], xmm11
000078af20bd7714  movaps [rsp+0x10], xmm7
000078af20bd7719  movaps [rsp+0x20], xmm13
000078af20bd771f  lea rdi, [rsp]
000078af20bd7723  mov esi, 0x00
000078af20bd7728  mov rax, 0x65452FFB8530
000078af20bd7732  call rax
000078af20bd7734  movaps xmm11, [rsp]
000078af20bd7739  add rsp, 0x30
000078af20bd773d  vmovaps xmm0, [rsp]
000078af20bd7742  vmovaps xmm1, [rsp+0x10]
000078af20bd7748  vmovaps xmm2, [rsp+0x20]
000078af20bd774e  vmovaps xmm3, [rsp+0x30]
000078af20bd7754  vmovaps xmm4, [rsp+0x40]
000078af20bd775a  vmovaps xmm5, [rsp+0x50]
000078af20bd7760  vmovaps xmm6, [rsp+0x60]
000078af20bd7766  vmovaps xmm7, [rsp+0x70]
000078af20bd776c  vmovaps xmm8, [rsp+0x80]
000078af20bd7775  vmovaps xmm9, [rsp+0x90]
000078af20bd777e  vmovaps xmm10, [rsp+0xA0]
000078af20bd7787  vmovaps xmm12, [rsp+0xB0]
000078af20bd7790  vmovaps xmm13, [rsp+0xC0]
000078af20bd7799  vmovaps xmm14, [rsp+0xD0]
000078af20bd77a2  vmovaps xmm15, [rsp+0xE0]
000078af20bd77ab  add rsp, 0xF0
000078af20bd77b2  pop r11
000078af20bd77b4  pop r10
000078af20bd77b6  pop r9
000078af20bd77b8  pop r8
000078af20bd77ba  pop rsi
000078af20bd77bb  pop rdi
000078af20bd77bc  pop rdx
000078af20bd77bd  pop rcx
000078af20bd77be  pop rax
000078af20bd77bf  add rsp, 0x08
000078af20bd77c3  jmp 0x000078AF20BD335E
000078af20bd77c8  sub rsp, 0x08
000078af20bd77cc  push rax
000078af20bd77cd  push rcx
000078af20bd77ce  push rdx
000078af20bd77cf  push rdi
000078af20bd77d0  push rsi
000078af20bd77d1  push r8
000078af20bd77d3  push r9
000078af20bd77d5  push r10
000078af20bd77d7  push r11
000078af20bd77d9  sub rsp, 0xF0
000078af20bd77e0  vmovaps [rsp], xmm0
000078af20bd77e5  vmovaps [rsp+0x10], xmm1
000078af20bd77eb  vmovaps [rsp+0x20], xmm2
000078af20bd77f1  vmovaps [rsp+0x30], xmm3
000078af20bd77f7  vmovaps [rsp+0x40], xmm4
000078af20bd77fd  vmovaps [rsp+0x50], xmm5
000078af20bd7803  vmovaps [rsp+0x60], xmm6
000078af20bd7809  vmovaps [rsp+0x70], xmm7
000078af20bd780f  vmovaps [rsp+0x80], xmm8
000078af20bd7818  vmovaps [rsp+0x90], xmm9
000078af20bd7821  vmovaps [rsp+0xA0], xmm10
000078af20bd782a  vmovaps [rsp+0xB0], xmm11
000078af20bd7833  vmovaps [rsp+0xC0], xmm12
000078af20bd783c  vmovaps [rsp+0xD0], xmm14
000078af20bd7845  vmovaps [rsp+0xE0], xmm15
000078af20bd784e  sub rsp, 0x30
000078af20bd7852  movaps [rsp], xmm13
000078af20bd7857  movaps [rsp+0x10], xmm10
000078af20bd785d  movaps [rsp+0x20], xmm12
000078af20bd7863  lea rdi, [rsp]
000078af20bd7867  mov esi, 0x00
000078af20bd786c  mov rax, 0x65452FFB8530
000078af20bd7876  call rax
000078af20bd7878  movaps xmm13, [rsp]
000078af20bd787d  add rsp, 0x30
000078af20bd7881  vmovaps xmm0, [rsp]
000078af20bd7886  vmovaps xmm1, [rsp+0x10]
000078af20bd788c  vmovaps xmm2, [rsp+0x20]
000078af20bd7892  vmovaps xmm3, [rsp+0x30]
000078af20bd7898  vmovaps xmm4, [rsp+0x40]
000078af20bd789e  vmovaps xmm5, [rsp+0x50]
000078af20bd78a4  vmovaps xmm6, [rsp+0x60]
000078af20bd78aa  vmovaps xmm7, [rsp+0x70]
000078af20bd78b0  vmovaps xmm8, [rsp+0x80]
000078af20bd78b9  vmovaps xmm9, [rsp+0x90]
000078af20bd78c2  vmovaps xmm10, [rsp+0xA0]
000078af20bd78cb  vmovaps xmm11, [rsp+0xB0]
000078af20bd78d4  vmovaps xmm12, [rsp+0xC0]
000078af20bd78dd  vmovaps xmm14, [rsp+0xD0]
000078af20bd78e6  vmovaps xmm15, [rsp+0xE0]
000078af20bd78ef  add rsp, 0xF0
000078af20bd78f6  pop r11
000078af20bd78f8  pop r10
000078af20bd78fa  pop r9
000078af20bd78fc  pop r8
000078af20bd78fe  pop rsi
000078af20bd78ff  pop rdi
000078af20bd7900  pop rdx
000078af20bd7901  pop rcx
000078af20bd7902  pop rax
000078af20bd7903  add rsp, 0x08
000078af20bd7907  jmp 0x000078AF20BD3378
000078af20bd790c  sub rsp, 0x08
000078af20bd7910  push rax
000078af20bd7911  push rcx
000078af20bd7912  push rdx
000078af20bd7913  push rdi
000078af20bd7914  push rsi
000078af20bd7915  push r8
000078af20bd7917  push r9
000078af20bd7919  push r10
000078af20bd791b  push r11
000078af20bd791d  sub rsp, 0xF0
000078af20bd7924  vmovaps [rsp], xmm0
000078af20bd7929  vmovaps [rsp+0x10], xmm1
000078af20bd792f  vmovaps [rsp+0x20], xmm2
000078af20bd7935  vmovaps [rsp+0x30], xmm3
000078af20bd793b  vmovaps [rsp+0x40], xmm4
000078af20bd7941  vmovaps [rsp+0x50], xmm5
000078af20bd7947  vmovaps [rsp+0x60], xmm6
000078af20bd794d  vmovaps [rsp+0x70], xmm7
000078af20bd7953  vmovaps [rsp+0x80], xmm8
000078af20bd795c  vmovaps [rsp+0x90], xmm9
000078af20bd7965  vmovaps [rsp+0xA0], xmm11
000078af20bd796e  vmovaps [rsp+0xB0], xmm12
000078af20bd7977  vmovaps [rsp+0xC0], xmm13
000078af20bd7980  vmovaps [rsp+0xD0], xmm14
000078af20bd7989  vmovaps [rsp+0xE0], xmm15
000078af20bd7992  sub rsp, 0x30
000078af20bd7996  movaps [rsp], xmm10
000078af20bd799b  movaps [rsp+0x10], xmm7
000078af20bd79a0  movaps [rsp+0x20], xmm12
000078af20bd79a6  lea rdi, [rsp]
000078af20bd79aa  mov esi, 0x00
000078af20bd79af  mov rax, 0x65452FFB8530
000078af20bd79b9  call rax
000078af20bd79bb  movaps xmm10, [rsp]
000078af20bd79c0  add rsp, 0x30
000078af20bd79c4  vmovaps xmm0, [rsp]
000078af20bd79c9  vmovaps xmm1, [rsp+0x10]
000078af20bd79cf  vmovaps xmm2, [rsp+0x20]
000078af20bd79d5  vmovaps xmm3, [rsp+0x30]
000078af20bd79db  vmovaps xmm4, [rsp+0x40]
000078af20bd79e1  vmovaps xmm5, [rsp+0x50]
000078af20bd79e7  vmovaps xmm6, [rsp+0x60]
000078af20bd79ed  vmovaps xmm7, [rsp+0x70]
000078af20bd79f3  vmovaps xmm8, [rsp+0x80]
000078af20bd79fc  vmovaps xmm9, [rsp+0x90]
000078af20bd7a05  vmovaps xmm11, [rsp+0xA0]
000078af20bd7a0e  vmovaps xmm12, [rsp+0xB0]
000078af20bd7a17  vmovaps xmm13, [rsp+0xC0]
000078af20bd7a20  vmovaps xmm14, [rsp+0xD0]
000078af20bd7a29  vmovaps xmm15, [rsp+0xE0]
000078af20bd7a32  add rsp, 0xF0
000078af20bd7a39  pop r11
000078af20bd7a3b  pop r10
000078af20bd7a3d  pop r9
000078af20bd7a3f  pop r8
000078af20bd7a41  pop rsi
000078af20bd7a42  pop rdi
000078af20bd7a43  pop rdx
000078af20bd7a44  pop rcx
000078af20bd7a45  pop rax
000078af20bd7a46  add rsp, 0x08
000078af20bd7a4a  jmp 0x000078AF20BD33A4
000078af20bd7a4f  sub rsp, 0x08
000078af20bd7a53  push rax
000078af20bd7a54  push rcx
000078af20bd7a55  push rdx
000078af20bd7a56  push rdi
000078af20bd7a57  push rsi
000078af20bd7a58  push r8
000078af20bd7a5a  push r9
000078af20bd7a5c  push r10
000078af20bd7a5e  push r11
000078af20bd7a60  sub rsp, 0xF0
000078af20bd7a67  vmovaps [rsp], xmm0
000078af20bd7a6c  vmovaps [rsp+0x10], xmm1
000078af20bd7a72  vmovaps [rsp+0x20], xmm2
000078af20bd7a78  vmovaps [rsp+0x30], xmm3
000078af20bd7a7e  vmovaps [rsp+0x40], xmm4
000078af20bd7a84  vmovaps [rsp+0x50], xmm5
000078af20bd7a8a  vmovaps [rsp+0x60], xmm6
000078af20bd7a90  vmovaps [rsp+0x70], xmm7
000078af20bd7a96  vmovaps [rsp+0x80], xmm8
000078af20bd7a9f  vmovaps [rsp+0x90], xmm9
000078af20bd7aa8  vmovaps [rsp+0xA0], xmm10
000078af20bd7ab1  vmovaps [rsp+0xB0], xmm11
000078af20bd7aba  vmovaps [rsp+0xC0], xmm13
000078af20bd7ac3  vmovaps [rsp+0xD0], xmm14
000078af20bd7acc  vmovaps [rsp+0xE0], xmm15
000078af20bd7ad5  sub rsp, 0x30
000078af20bd7ad9  movaps [rsp], xmm12
000078af20bd7ade  movaps [rsp+0x10], xmm1
000078af20bd7ae3  movaps [rsp+0x20], xmm8
000078af20bd7ae9  lea rdi, [rsp]
000078af20bd7aed  mov esi, 0x00
000078af20bd7af2  mov rax, 0x65452FFB8530
000078af20bd7afc  call rax
000078af20bd7afe  movaps xmm12, [rsp]
000078af20bd7b03  add rsp, 0x30
000078af20bd7b07  vmovaps xmm0, [rsp]
000078af20bd7b0c  vmovaps xmm1, [rsp+0x10]
000078af20bd7b12  vmovaps xmm2, [rsp+0x20]
000078af20bd7b18  vmovaps xmm3, [rsp+0x30]
000078af20bd7b1e  vmovaps xmm4, [rsp+0x40]
000078af20bd7b24  vmovaps xmm5, [rsp+0x50]
000078af20bd7b2a  vmovaps xmm6, [rsp+0x60]
000078af20bd7b30  vmovaps xmm7, [rsp+0x70]
000078af20bd7b36  vmovaps xmm8, [rsp+0x80]
000078af20bd7b3f  vmovaps xmm9, [rsp+0x90]
000078af20bd7b48  vmovaps xmm10, [rsp+0xA0]
000078af20bd7b51  vmovaps xmm11, [rsp+0xB0]
000078af20bd7b5a  vmovaps xmm13, [rsp+0xC0]
000078af20bd7b63  vmovaps xmm14, [rsp+0xD0]
000078af20bd7b6c  vmovaps xmm15, [rsp+0xE0]
000078af20bd7b75  add rsp, 0xF0
000078af20bd7b7c  pop r11
000078af20bd7b7e  pop r10
000078af20bd7b80  pop r9
000078af20bd7b82  pop r8
000078af20bd7b84  pop rsi
000078af20bd7b85  pop rdi
000078af20bd7b86  pop rdx
000078af20bd7b87  pop rcx
000078af20bd7b88  pop rax
000078af20bd7b89  add rsp, 0x08
000078af20bd7b8d  jmp 0x000078AF20BD33BE
000078af20bd7b92  call 0x000078AF209FF430
000078af20bd7b97  jmp 0x000078AF20BD33C8
000078af20bd7b9c  sub rsp, 0x08
000078af20bd7ba0  push rax
000078af20bd7ba1  push rcx
000078af20bd7ba2  push rdx
000078af20bd7ba3  push rdi
000078af20bd7ba4  push rsi
000078af20bd7ba5  push r8
000078af20bd7ba7  push r9
000078af20bd7ba9  push r10
000078af20bd7bab  push r11
000078af20bd7bad  sub rsp, 0xF0
000078af20bd7bb4  vmovaps [rsp], xmm0
000078af20bd7bb9  vmovaps [rsp+0x10], xmm1
000078af20bd7bbf  vmovaps [rsp+0x20], xmm2
000078af20bd7bc5  vmovaps [rsp+0x30], xmm3
000078af20bd7bcb  vmovaps [rsp+0x40], xmm4
000078af20bd7bd1  vmovaps [rsp+0x50], xmm5
000078af20bd7bd7  vmovaps [rsp+0x60], xmm6
000078af20bd7bdd  vmovaps [rsp+0x70], xmm7
000078af20bd7be3  vmovaps [rsp+0x80], xmm9
000078af20bd7bec  vmovaps [rsp+0x90], xmm10
000078af20bd7bf5  vmovaps [rsp+0xA0], xmm11
000078af20bd7bfe  vmovaps [rsp+0xB0], xmm12
000078af20bd7c07  vmovaps [rsp+0xC0], xmm13
000078af20bd7c10  vmovaps [rsp+0xD0], xmm14
000078af20bd7c19  vmovaps [rsp+0xE0], xmm15
000078af20bd7c22  sub rsp, 0x30
000078af20bd7c26  movaps [rsp], xmm8
000078af20bd7c2b  movaps [rsp+0x10], xmm15
000078af20bd7c31  movaps [rsp+0x20], xmm9
000078af20bd7c37  lea rdi, [rsp]
000078af20bd7c3b  mov esi, 0x00
000078af20bd7c40  mov rax, 0x65452FFB8530
000078af20bd7c4a  call rax
000078af20bd7c4c  movaps xmm8, [rsp]
000078af20bd7c51  add rsp, 0x30
000078af20bd7c55  vmovaps xmm0, [rsp]
000078af20bd7c5a  vmovaps xmm1, [rsp+0x10]
000078af20bd7c60  vmovaps xmm2, [rsp+0x20]
000078af20bd7c66  vmovaps xmm3, [rsp+0x30]
000078af20bd7c6c  vmovaps xmm4, [rsp+0x40]
000078af20bd7c72  vmovaps xmm5, [rsp+0x50]
000078af20bd7c78  vmovaps xmm6, [rsp+0x60]
000078af20bd7c7e  vmovaps xmm7, [rsp+0x70]
000078af20bd7c84  vmovaps xmm9, [rsp+0x80]
000078af20bd7c8d  vmovaps xmm10, [rsp+0x90]
000078af20bd7c96  vmovaps xmm11, [rsp+0xA0]
000078af20bd7c9f  vmovaps xmm12, [rsp+0xB0]
000078af20bd7ca8  vmovaps xmm13, [rsp+0xC0]
000078af20bd7cb1  vmovaps xmm14, [rsp+0xD0]
000078af20bd7cba  vmovaps xmm15, [rsp+0xE0]
000078af20bd7cc3  add rsp, 0xF0
000078af20bd7cca  pop r11
000078af20bd7ccc  pop r10
000078af20bd7cce  pop r9
000078af20bd7cd0  pop r8
000078af20bd7cd2  pop rsi
000078af20bd7cd3  pop rdi
000078af20bd7cd4  pop rdx
000078af20bd7cd5  pop rcx
000078af20bd7cd6  pop rax
000078af20bd7cd7  add rsp, 0x08
000078af20bd7cdb  jmp 0x000078AF20BD33EA
000078af20bd7ce0  sub rsp, 0x08
000078af20bd7ce4  push rax
000078af20bd7ce5  push rcx
000078af20bd7ce6  push rdx
000078af20bd7ce7  push rdi
000078af20bd7ce8  push rsi
000078af20bd7ce9  push r8
000078af20bd7ceb  push r9
000078af20bd7ced  push r10
000078af20bd7cef  push r11
000078af20bd7cf1  sub rsp, 0xF0
000078af20bd7cf8  vmovaps [rsp], xmm0
000078af20bd7cfd  vmovaps [rsp+0x10], xmm1
000078af20bd7d03  vmovaps [rsp+0x20], xmm2
000078af20bd7d09  vmovaps [rsp+0x30], xmm3
000078af20bd7d0f  vmovaps [rsp+0x40], xmm4
000078af20bd7d15  vmovaps [rsp+0x50], xmm5
000078af20bd7d1b  vmovaps [rsp+0x60], xmm6
000078af20bd7d21  vmovaps [rsp+0x70], xmm7
000078af20bd7d27  vmovaps [rsp+0x80], xmm8
000078af20bd7d30  vmovaps [rsp+0x90], xmm10
000078af20bd7d39  vmovaps [rsp+0xA0], xmm11
000078af20bd7d42  vmovaps [rsp+0xB0], xmm12
000078af20bd7d4b  vmovaps [rsp+0xC0], xmm13
000078af20bd7d54  vmovaps [rsp+0xD0], xmm14
000078af20bd7d5d  vmovaps [rsp+0xE0], xmm15
000078af20bd7d66  sub rsp, 0x30
000078af20bd7d6a  movaps [rsp], xmm9
000078af20bd7d6f  movaps [rsp+0x10], xmm1
000078af20bd7d74  movaps [rsp+0x20], xmm15
000078af20bd7d7a  lea rdi, [rsp]
000078af20bd7d7e  mov esi, 0x00
000078af20bd7d83  mov rax, 0x65452FFB8530
000078af20bd7d8d  call rax
000078af20bd7d8f  movaps xmm9, [rsp]
000078af20bd7d94  add rsp, 0x30
000078af20bd7d98  vmovaps xmm0, [rsp]
000078af20bd7d9d  vmovaps xmm1, [rsp+0x10]
000078af20bd7da3  vmovaps xmm2, [rsp+0x20]
000078af20bd7da9  vmovaps xmm3, [rsp+0x30]
000078af20bd7daf  vmovaps xmm4, [rsp+0x40]
000078af20bd7db5  vmovaps xmm5, [rsp+0x50]
000078af20bd7dbb  vmovaps xmm6, [rsp+0x60]
000078af20bd7dc1  vmovaps xmm7, [rsp+0x70]
000078af20bd7dc7  vmovaps xmm8, [rsp+0x80]
000078af20bd7dd0  vmovaps xmm10, [rsp+0x90]
000078af20bd7dd9  vmovaps xmm11, [rsp+0xA0]
000078af20bd7de2  vmovaps xmm12, [rsp+0xB0]
000078af20bd7deb  vmovaps xmm13, [rsp+0xC0]
000078af20bd7df4  vmovaps xmm14, [rsp+0xD0]
000078af20bd7dfd  vmovaps xmm15, [rsp+0xE0]
000078af20bd7e06  add rsp, 0xF0
000078af20bd7e0d  pop r11
000078af20bd7e0f  pop r10
000078af20bd7e11  pop r9
000078af20bd7e13  pop r8
000078af20bd7e15  pop rsi
000078af20bd7e16  pop rdi
000078af20bd7e17  pop rdx
000078af20bd7e18  pop rcx
000078af20bd7e19  pop rax
000078af20bd7e1a  add rsp, 0x08
000078af20bd7e1e  jmp 0x000078AF20BD3418
000078af20bd7e23  sub rsp, 0x08
000078af20bd7e27  push rax
000078af20bd7e28  push rcx
000078af20bd7e29  push rdx
000078af20bd7e2a  push rdi
000078af20bd7e2b  push rsi
000078af20bd7e2c  push r8
000078af20bd7e2e  push r9
000078af20bd7e30  push r10
000078af20bd7e32  push r11
000078af20bd7e34  sub rsp, 0xF0
000078af20bd7e3b  vmovaps [rsp], xmm0
000078af20bd7e40  vmovaps [rsp+0x10], xmm1
000078af20bd7e46  vmovaps [rsp+0x20], xmm2
000078af20bd7e4c  vmovaps [rsp+0x30], xmm3
000078af20bd7e52  vmovaps [rsp+0x40], xmm4
000078af20bd7e58  vmovaps [rsp+0x50], xmm5
000078af20bd7e5e  vmovaps [rsp+0x60], xmm6
000078af20bd7e64  vmovaps [rsp+0x70], xmm7
000078af20bd7e6a  vmovaps [rsp+0x80], xmm8
000078af20bd7e73  vmovaps [rsp+0x90], xmm9
000078af20bd7e7c  vmovaps [rsp+0xA0], xmm10
000078af20bd7e85  vmovaps [rsp+0xB0], xmm11
000078af20bd7e8e  vmovaps [rsp+0xC0], xmm12
000078af20bd7e97  vmovaps [rsp+0xD0], xmm13
000078af20bd7ea0  vmovaps [rsp+0xE0], xmm14
000078af20bd7ea9  sub rsp, 0x30
000078af20bd7ead  movaps [rsp], xmm15
000078af20bd7eb2  movaps [rsp+0x10], xmm4
000078af20bd7eb7  movaps [rsp+0x20], xmm1
000078af20bd7ebc  lea rdi, [rsp]
000078af20bd7ec0  mov esi, 0x00
000078af20bd7ec5  mov rax, 0x65452FFB8530
000078af20bd7ecf  call rax
000078af20bd7ed1  movaps xmm15, [rsp]
000078af20bd7ed6  add rsp, 0x30
000078af20bd7eda  vmovaps xmm0, [rsp]
000078af20bd7edf  vmovaps xmm1, [rsp+0x10]
000078af20bd7ee5  vmovaps xmm2, [rsp+0x20]
000078af20bd7eeb  vmovaps xmm3, [rsp+0x30]
000078af20bd7ef1  vmovaps xmm4, [rsp+0x40]
000078af20bd7ef7  vmovaps xmm5, [rsp+0x50]
000078af20bd7efd  vmovaps xmm6, [rsp+0x60]
000078af20bd7f03  vmovaps xmm7, [rsp+0x70]
000078af20bd7f09  vmovaps xmm8, [rsp+0x80]
000078af20bd7f12  vmovaps xmm9, [rsp+0x90]
000078af20bd7f1b  vmovaps xmm10, [rsp+0xA0]
000078af20bd7f24  vmovaps xmm11, [rsp+0xB0]
000078af20bd7f2d  vmovaps xmm12, [rsp+0xC0]
000078af20bd7f36  vmovaps xmm13, [rsp+0xD0]
000078af20bd7f3f  vmovaps xmm14, [rsp+0xE0]
000078af20bd7f48  add rsp, 0xF0
000078af20bd7f4f  pop r11
000078af20bd7f51  pop r10
000078af20bd7f53  pop r9
000078af20bd7f55  pop r8
000078af20bd7f57  pop rsi
000078af20bd7f58  pop rdi
000078af20bd7f59  pop rdx
000078af20bd7f5a  pop rcx
000078af20bd7f5b  pop rax
000078af20bd7f5c  add rsp, 0x08
000078af20bd7f60  jmp 0x000078AF20BD343E
000078af20bd7f65  sub rsp, 0x08
000078af20bd7f69  push rax
000078af20bd7f6a  push rcx
000078af20bd7f6b  push rdx
000078af20bd7f6c  push rdi
000078af20bd7f6d  push rsi
000078af20bd7f6e  push r8
000078af20bd7f70  push r9
000078af20bd7f72  push r10
000078af20bd7f74  push r11
000078af20bd7f76  sub rsp, 0xF0
000078af20bd7f7d  vmovaps [rsp], xmm0
000078af20bd7f82  vmovaps [rsp+0x10], xmm2
000078af20bd7f88  vmovaps [rsp+0x20], xmm3
000078af20bd7f8e  vmovaps [rsp+0x30], xmm4
000078af20bd7f94  vmovaps [rsp+0x40], xmm5
000078af20bd7f9a  vmovaps [rsp+0x50], xmm6
000078af20bd7fa0  vmovaps [rsp+0x60], xmm7
000078af20bd7fa6  vmovaps [rsp+0x70], xmm8
000078af20bd7fac  vmovaps [rsp+0x80], xmm9
000078af20bd7fb5  vmovaps [rsp+0x90], xmm10
000078af20bd7fbe  vmovaps [rsp+0xA0], xmm11
000078af20bd7fc7  vmovaps [rsp+0xB0], xmm12
000078af20bd7fd0  vmovaps [rsp+0xC0], xmm13
000078af20bd7fd9  vmovaps [rsp+0xD0], xmm14
000078af20bd7fe2  vmovaps [rsp+0xE0], xmm15
000078af20bd7feb  sub rsp, 0x30
000078af20bd7fef  movaps [rsp], xmm1
000078af20bd7ff3  movaps [rsp+0x10], xmm14
000078af20bd7ff9  movaps [rsp+0x20], xmm11
000078af20bd7fff  lea rdi, [rsp]
000078af20bd8003  mov esi, 0x00
000078af20bd8008  mov rax, 0x65452FFB8530
000078af20bd8012  call rax
000078af20bd8014  movaps xmm1, [rsp]
000078af20bd8018  add rsp, 0x30
000078af20bd801c  vmovaps xmm0, [rsp]
000078af20bd8021  vmovaps xmm2, [rsp+0x10]
000078af20bd8027  vmovaps xmm3, [rsp+0x20]
000078af20bd802d  vmovaps xmm4, [rsp+0x30]
000078af20bd8033  vmovaps xmm5, [rsp+0x40]
000078af20bd8039  vmovaps xmm6, [rsp+0x50]
000078af20bd803f  vmovaps xmm7, [rsp+0x60]
000078af20bd8045  vmovaps xmm8, [rsp+0x70]
000078af20bd804b  vmovaps xmm9, [rsp+0x80]
000078af20bd8054  vmovaps xmm10, [rsp+0x90]
000078af20bd805d  vmovaps xmm11, [rsp+0xA0]
000078af20bd8066  vmovaps xmm12, [rsp+0xB0]
000078af20bd806f  vmovaps xmm13, [rsp+0xC0]
000078af20bd8078  vmovaps xmm14, [rsp+0xD0]
000078af20bd8081  vmovaps xmm15, [rsp+0xE0]
000078af20bd808a  add rsp, 0xF0
000078af20bd8091  pop r11
000078af20bd8093  pop r10
000078af20bd8095  pop r9
000078af20bd8097  pop r8
000078af20bd8099  pop rsi
000078af20bd809a  pop rdi
000078af20bd809b  pop rdx
000078af20bd809c  pop rcx
000078af20bd809d  pop rax
000078af20bd809e  add rsp, 0x08
000078af20bd80a2  jmp 0x000078AF20BD345F
000078af20bd80a7  call 0x000078AF20AE45A0
000078af20bd80ac  jmp 0x000078AF20BD346D
000078af20bd80b1  call 0x000078AF20A09D70
000078af20bd80b6  jmp 0x000078AF20BD3477
000078af20bd80bb  sub rsp, 0x08
000078af20bd80bf  push rax
000078af20bd80c0  push rcx
000078af20bd80c1  push rdx
000078af20bd80c2  push rdi
000078af20bd80c3  push rsi
000078af20bd80c4  push r8
000078af20bd80c6  push r9
000078af20bd80c8  push r10
000078af20bd80ca  push r11
000078af20bd80cc  sub rsp, 0xF0
000078af20bd80d3  vmovaps [rsp], xmm0
000078af20bd80d8  vmovaps [rsp+0x10], xmm1
000078af20bd80de  vmovaps [rsp+0x20], xmm2
000078af20bd80e4  vmovaps [rsp+0x30], xmm3
000078af20bd80ea  vmovaps [rsp+0x40], xmm4
000078af20bd80f0  vmovaps [rsp+0x50], xmm5
000078af20bd80f6  vmovaps [rsp+0x60], xmm6
000078af20bd80fc  vmovaps [rsp+0x70], xmm8
000078af20bd8102  vmovaps [rsp+0x80], xmm9
000078af20bd810b  vmovaps [rsp+0x90], xmm10
000078af20bd8114  vmovaps [rsp+0xA0], xmm11
000078af20bd811d  vmovaps [rsp+0xB0], xmm12
000078af20bd8126  vmovaps [rsp+0xC0], xmm13
000078af20bd812f  vmovaps [rsp+0xD0], xmm14
000078af20bd8138  vmovaps [rsp+0xE0], xmm15
000078af20bd8141  sub rsp, 0x30
000078af20bd8145  movaps [rsp], xmm7
000078af20bd8149  movaps [rsp+0x10], xmm13
000078af20bd814f  movaps [rsp+0x20], xmm10
000078af20bd8155  lea rdi, [rsp]
000078af20bd8159  mov esi, 0x00
000078af20bd815e  mov rax, 0x65452FFB8530
000078af20bd8168  call rax
000078af20bd816a  movaps xmm7, [rsp]
000078af20bd816e  add rsp, 0x30
000078af20bd8172  vmovaps xmm0, [rsp]
000078af20bd8177  vmovaps xmm1, [rsp+0x10]
000078af20bd817d  vmovaps xmm2, [rsp+0x20]
000078af20bd8183  vmovaps xmm3, [rsp+0x30]
000078af20bd8189  vmovaps xmm4, [rsp+0x40]
000078af20bd818f  vmovaps xmm5, [rsp+0x50]
000078af20bd8195  vmovaps xmm6, [rsp+0x60]
000078af20bd819b  vmovaps xmm8, [rsp+0x70]
000078af20bd81a1  vmovaps xmm9, [rsp+0x80]
000078af20bd81aa  vmovaps xmm10, [rsp+0x90]
000078af20bd81b3  vmovaps xmm11, [rsp+0xA0]
000078af20bd81bc  vmovaps xmm12, [rsp+0xB0]
000078af20bd81c5  vmovaps xmm13, [rsp+0xC0]
000078af20bd81ce  vmovaps xmm14, [rsp+0xD0]
000078af20bd81d7  vmovaps xmm15, [rsp+0xE0]
000078af20bd81e0  add rsp, 0xF0
000078af20bd81e7  pop r11
000078af20bd81e9  pop r10
000078af20bd81eb  pop r9
000078af20bd81ed  pop r8
000078af20bd81ef  pop rsi
000078af20bd81f0  pop rdi
000078af20bd81f1  pop rdx
000078af20bd81f2  pop rcx
000078af20bd81f3  pop rax
000078af20bd81f4  add rsp, 0x08
000078af20bd81f8  jmp 0x000078AF20BD3498
000078af20bd81fd  sub rsp, 0x08
000078af20bd8201  push rax
000078af20bd8202  push rcx
000078af20bd8203  push rdx
000078af20bd8204  push rdi
000078af20bd8205  push rsi
000078af20bd8206  push r8
000078af20bd8208  push r9
000078af20bd820a  push r10
000078af20bd820c  push r11
000078af20bd820e  sub rsp, 0xF0
000078af20bd8215  vmovaps [rsp], xmm0
000078af20bd821a  vmovaps [rsp+0x10], xmm1
000078af20bd8220  vmovaps [rsp+0x20], xmm2
000078af20bd8226  vmovaps [rsp+0x30], xmm3
000078af20bd822c  vmovaps [rsp+0x40], xmm4
000078af20bd8232  vmovaps [rsp+0x50], xmm5
000078af20bd8238  vmovaps [rsp+0x60], xmm6
000078af20bd823e  vmovaps [rsp+0x70], xmm7
000078af20bd8244  vmovaps [rsp+0x80], xmm8
000078af20bd824d  vmovaps [rsp+0x90], xmm9
000078af20bd8256  vmovaps [rsp+0xA0], xmm11
000078af20bd825f  vmovaps [rsp+0xB0], xmm12
000078af20bd8268  vmovaps [rsp+0xC0], xmm13
000078af20bd8271  vmovaps [rsp+0xD0], xmm14
000078af20bd827a  vmovaps [rsp+0xE0], xmm15
000078af20bd8283  sub rsp, 0x30
000078af20bd8287  movaps [rsp], xmm10
000078af20bd828c  movaps [rsp+0x10], xmm11
000078af20bd8292  movaps [rsp+0x20], xmm13
000078af20bd8298  lea rdi, [rsp]
000078af20bd829c  mov esi, 0x00
000078af20bd82a1  mov rax, 0x65452FFB8530
000078af20bd82ab  call rax
000078af20bd82ad  movaps xmm10, [rsp]
000078af20bd82b2  add rsp, 0x30
000078af20bd82b6  vmovaps xmm0, [rsp]
000078af20bd82bb  vmovaps xmm1, [rsp+0x10]
000078af20bd82c1  vmovaps xmm2, [rsp+0x20]
000078af20bd82c7  vmovaps xmm3, [rsp+0x30]
000078af20bd82cd  vmovaps xmm4, [rsp+0x40]
000078af20bd82d3  vmovaps xmm5, [rsp+0x50]
000078af20bd82d9  vmovaps xmm6, [rsp+0x60]
000078af20bd82df  vmovaps xmm7, [rsp+0x70]
000078af20bd82e5  vmovaps xmm8, [rsp+0x80]
000078af20bd82ee  vmovaps xmm9, [rsp+0x90]
000078af20bd82f7  vmovaps xmm11, [rsp+0xA0]
000078af20bd8300  vmovaps xmm12, [rsp+0xB0]
000078af20bd8309  vmovaps xmm13, [rsp+0xC0]
000078af20bd8312  vmovaps xmm14, [rsp+0xD0]
000078af20bd831b  vmovaps xmm15, [rsp+0xE0]
000078af20bd8324  add rsp, 0xF0
000078af20bd832b  pop r11
000078af20bd832d  pop r10
000078af20bd832f  pop r9
000078af20bd8331  pop r8
000078af20bd8333  pop rsi
000078af20bd8334  pop rdi
000078af20bd8335  pop rdx
000078af20bd8336  pop rcx
000078af20bd8337  pop rax
000078af20bd8338  add rsp, 0x08
000078af20bd833c  jmp 0x000078AF20BD34C6
000078af20bd8341  sub rsp, 0x08
000078af20bd8345  push rax
000078af20bd8346  push rcx
000078af20bd8347  push rdx
000078af20bd8348  push rdi
000078af20bd8349  push rsi
000078af20bd834a  push r8
000078af20bd834c  push r9
000078af20bd834e  push r10
000078af20bd8350  push r11
000078af20bd8352  sub rsp, 0xF0
000078af20bd8359  vmovaps [rsp], xmm0
000078af20bd835e  vmovaps [rsp+0x10], xmm1
000078af20bd8364  vmovaps [rsp+0x20], xmm2
000078af20bd836a  vmovaps [rsp+0x30], xmm3
000078af20bd8370  vmovaps [rsp+0x40], xmm4
000078af20bd8376  vmovaps [rsp+0x50], xmm5
000078af20bd837c  vmovaps [rsp+0x60], xmm6
000078af20bd8382  vmovaps [rsp+0x70], xmm7
000078af20bd8388  vmovaps [rsp+0x80], xmm8
000078af20bd8391  vmovaps [rsp+0x90], xmm9
000078af20bd839a  vmovaps [rsp+0xA0], xmm10
000078af20bd83a3  vmovaps [rsp+0xB0], xmm12
000078af20bd83ac  vmovaps [rsp+0xC0], xmm13
000078af20bd83b5  vmovaps [rsp+0xD0], xmm14
000078af20bd83be  vmovaps [rsp+0xE0], xmm15
000078af20bd83c7  sub rsp, 0x30
000078af20bd83cb  movaps [rsp], xmm11
000078af20bd83d0  movaps [rsp+0x10], xmm14
000078af20bd83d6  movaps [rsp+0x20], xmm13
000078af20bd83dc  lea rdi, [rsp]
000078af20bd83e0  mov esi, 0x00
000078af20bd83e5  mov rax, 0x65452FFB8530
000078af20bd83ef  call rax
000078af20bd83f1  movaps xmm11, [rsp]
000078af20bd83f6  add rsp, 0x30
000078af20bd83fa  vmovaps xmm0, [rsp]
000078af20bd83ff  vmovaps xmm1, [rsp+0x10]
000078af20bd8405  vmovaps xmm2, [rsp+0x20]
000078af20bd840b  vmovaps xmm3, [rsp+0x30]
000078af20bd8411  vmovaps xmm4, [rsp+0x40]
000078af20bd8417  vmovaps xmm5, [rsp+0x50]
000078af20bd841d  vmovaps xmm6, [rsp+0x60]
000078af20bd8423  vmovaps xmm7, [rsp+0x70]
000078af20bd8429  vmovaps xmm8, [rsp+0x80]
000078af20bd8432  vmovaps xmm9, [rsp+0x90]
000078af20bd843b  vmovaps xmm10, [rsp+0xA0]
000078af20bd8444  vmovaps xmm12, [rsp+0xB0]
000078af20bd844d  vmovaps xmm13, [rsp+0xC0]
000078af20bd8456  vmovaps xmm14, [rsp+0xD0]
000078af20bd845f  vmovaps xmm15, [rsp+0xE0]
000078af20bd8468  add rsp, 0xF0
000078af20bd846f  pop r11
000078af20bd8471  pop r10
000078af20bd8473  pop r9
000078af20bd8475  pop r8
000078af20bd8477  pop rsi
000078af20bd8478  pop rdi
000078af20bd8479  pop rdx
000078af20bd847a  pop rcx
000078af20bd847b  pop rax
000078af20bd847c  add rsp, 0x08
000078af20bd8480  jmp 0x000078AF20BD34F4
000078af20bd8485  sub rsp, 0x08
000078af20bd8489  push rax
000078af20bd848a  push rcx
000078af20bd848b  push rdx
000078af20bd848c  push rdi
000078af20bd848d  push rsi
000078af20bd848e  push r8
000078af20bd8490  push r9
000078af20bd8492  push r10
000078af20bd8494  push r11
000078af20bd8496  sub rsp, 0xF0
000078af20bd849d  vmovaps [rsp], xmm0
000078af20bd84a2  vmovaps [rsp+0x10], xmm1
000078af20bd84a8  vmovaps [rsp+0x20], xmm2
000078af20bd84ae  vmovaps [rsp+0x30], xmm3
000078af20bd84b4  vmovaps [rsp+0x40], xmm4
000078af20bd84ba  vmovaps [rsp+0x50], xmm5
000078af20bd84c0  vmovaps [rsp+0x60], xmm6
000078af20bd84c6  vmovaps [rsp+0x70], xmm7
000078af20bd84cc  vmovaps [rsp+0x80], xmm8
000078af20bd84d5  vmovaps [rsp+0x90], xmm9
000078af20bd84de  vmovaps [rsp+0xA0], xmm10
000078af20bd84e7  vmovaps [rsp+0xB0], xmm11
000078af20bd84f0  vmovaps [rsp+0xC0], xmm12
000078af20bd84f9  vmovaps [rsp+0xD0], xmm13
000078af20bd8502  vmovaps [rsp+0xE0], xmm15
000078af20bd850b  sub rsp, 0x30
000078af20bd850f  movaps [rsp], xmm14
000078af20bd8514  movaps [rsp+0x10], xmm12
000078af20bd851a  movaps [rsp+0x20], xmm9
000078af20bd8520  lea rdi, [rsp]
000078af20bd8524  mov esi, 0x00
000078af20bd8529  mov rax, 0x65452FFB8530
000078af20bd8533  call rax
000078af20bd8535  movaps xmm14, [rsp]
000078af20bd853a  add rsp, 0x30
000078af20bd853e  vmovaps xmm0, [rsp]
000078af20bd8543  vmovaps xmm1, [rsp+0x10]
000078af20bd8549  vmovaps xmm2, [rsp+0x20]
000078af20bd854f  vmovaps xmm3, [rsp+0x30]
000078af20bd8555  vmovaps xmm4, [rsp+0x40]
000078af20bd855b  vmovaps xmm5, [rsp+0x50]
000078af20bd8561  vmovaps xmm6, [rsp+0x60]
000078af20bd8567  vmovaps xmm7, [rsp+0x70]
000078af20bd856d  vmovaps xmm8, [rsp+0x80]
000078af20bd8576  vmovaps xmm9, [rsp+0x90]
000078af20bd857f  vmovaps xmm10, [rsp+0xA0]
000078af20bd8588  vmovaps xmm11, [rsp+0xB0]
000078af20bd8591  vmovaps xmm12, [rsp+0xC0]
000078af20bd859a  vmovaps xmm13, [rsp+0xD0]
000078af20bd85a3  vmovaps xmm15, [rsp+0xE0]
000078af20bd85ac  add rsp, 0xF0
000078af20bd85b3  pop r11
000078af20bd85b5  pop r10
000078af20bd85b7  pop r9
000078af20bd85b9  pop r8
000078af20bd85bb  pop rsi
000078af20bd85bc  pop rdi
000078af20bd85bd  pop rdx
000078af20bd85be  pop rcx
000078af20bd85bf  pop rax
000078af20bd85c0  add rsp, 0x08
000078af20bd85c4  jmp 0x000078AF20BD350F
000078af20bd85c9  sub rsp, 0x08
000078af20bd85cd  push rax
000078af20bd85ce  push rcx
000078af20bd85cf  push rdx
000078af20bd85d0  push rdi
000078af20bd85d1  push rsi
000078af20bd85d2  push r8
000078af20bd85d4  push r9
000078af20bd85d6  push r10
000078af20bd85d8  push r11
000078af20bd85da  sub rsp, 0xF0
000078af20bd85e1  vmovaps [rsp], xmm0
000078af20bd85e6  vmovaps [rsp+0x10], xmm1
000078af20bd85ec  vmovaps [rsp+0x20], xmm2
000078af20bd85f2  vmovaps [rsp+0x30], xmm3
000078af20bd85f8  vmovaps [rsp+0x40], xmm4
000078af20bd85fe  vmovaps [rsp+0x50], xmm5
000078af20bd8604  vmovaps [rsp+0x60], xmm6
000078af20bd860a  vmovaps [rsp+0x70], xmm7
000078af20bd8610  vmovaps [rsp+0x80], xmm8
000078af20bd8619  vmovaps [rsp+0x90], xmm9
000078af20bd8622  vmovaps [rsp+0xA0], xmm10
000078af20bd862b  vmovaps [rsp+0xB0], xmm11
000078af20bd8634  vmovaps [rsp+0xC0], xmm12
000078af20bd863d  vmovaps [rsp+0xD0], xmm14
000078af20bd8646  vmovaps [rsp+0xE0], xmm15
000078af20bd864f  sub rsp, 0x30
000078af20bd8653  movaps [rsp], xmm13
000078af20bd8658  movaps [rsp+0x10], xmm8
000078af20bd865e  movaps [rsp+0x20], xmm15
000078af20bd8664  lea rdi, [rsp]
000078af20bd8668  mov esi, 0x00
000078af20bd866d  mov rax, 0x65452FFB8530
000078af20bd8677  call rax
000078af20bd8679  movaps xmm13, [rsp]
000078af20bd867e  add rsp, 0x30
000078af20bd8682  vmovaps xmm0, [rsp]
000078af20bd8687  vmovaps xmm1, [rsp+0x10]
000078af20bd868d  vmovaps xmm2, [rsp+0x20]
000078af20bd8693  vmovaps xmm3, [rsp+0x30]
000078af20bd8699  vmovaps xmm4, [rsp+0x40]
000078af20bd869f  vmovaps xmm5, [rsp+0x50]
000078af20bd86a5  vmovaps xmm6, [rsp+0x60]
000078af20bd86ab  vmovaps xmm7, [rsp+0x70]
000078af20bd86b1  vmovaps xmm8, [rsp+0x80]
000078af20bd86ba  vmovaps xmm9, [rsp+0x90]
000078af20bd86c3  vmovaps xmm10, [rsp+0xA0]
000078af20bd86cc  vmovaps xmm11, [rsp+0xB0]
000078af20bd86d5  vmovaps xmm12, [rsp+0xC0]
000078af20bd86de  vmovaps xmm14, [rsp+0xD0]
000078af20bd86e7  vmovaps xmm15, [rsp+0xE0]
000078af20bd86f0  add rsp, 0xF0
000078af20bd86f7  pop r11
000078af20bd86f9  pop r10
000078af20bd86fb  pop r9
000078af20bd86fd  pop r8
000078af20bd86ff  pop rsi
000078af20bd8700  pop rdi
000078af20bd8701  pop rdx
000078af20bd8702  pop rcx
000078af20bd8703  pop rax
000078af20bd8704  add rsp, 0x08
000078af20bd8708  jmp 0x000078AF20BD3532
000078af20bd870d  sub rsp, 0x08
000078af20bd8711  push rax
000078af20bd8712  push rcx
000078af20bd8713  push rdx
000078af20bd8714  push rdi
000078af20bd8715  push rsi
000078af20bd8716  push r8
000078af20bd8718  push r9
000078af20bd871a  push r10
000078af20bd871c  push r11
000078af20bd871e  sub rsp, 0xF0
000078af20bd8725  vmovaps [rsp], xmm0
000078af20bd872a  vmovaps [rsp+0x10], xmm1
000078af20bd8730  vmovaps [rsp+0x20], xmm2
000078af20bd8736  vmovaps [rsp+0x30], xmm3
000078af20bd873c  vmovaps [rsp+0x40], xmm4
000078af20bd8742  vmovaps [rsp+0x50], xmm5
000078af20bd8748  vmovaps [rsp+0x60], xmm6
000078af20bd874e  vmovaps [rsp+0x70], xmm7
000078af20bd8754  vmovaps [rsp+0x80], xmm8
000078af20bd875d  vmovaps [rsp+0x90], xmm9
000078af20bd8766  vmovaps [rsp+0xA0], xmm10
000078af20bd876f  vmovaps [rsp+0xB0], xmm11
000078af20bd8778  vmovaps [rsp+0xC0], xmm12
000078af20bd8781  vmovaps [rsp+0xD0], xmm13
000078af20bd878a  vmovaps [rsp+0xE0], xmm14
000078af20bd8793  sub rsp, 0x30
000078af20bd8797  movaps [rsp], xmm15
000078af20bd879c  movaps [rsp+0x10], xmm1
000078af20bd87a1  movaps [rsp+0x20], xmm10
000078af20bd87a7  lea rdi, [rsp]
000078af20bd87ab  mov esi, 0x00
000078af20bd87b0  mov rax, 0x65452FFB8530
000078af20bd87ba  call rax
000078af20bd87bc  movaps xmm15, [rsp]
000078af20bd87c1  add rsp, 0x30
000078af20bd87c5  vmovaps xmm0, [rsp]
000078af20bd87ca  vmovaps xmm1, [rsp+0x10]
000078af20bd87d0  vmovaps xmm2, [rsp+0x20]
000078af20bd87d6  vmovaps xmm3, [rsp+0x30]
000078af20bd87dc  vmovaps xmm4, [rsp+0x40]
000078af20bd87e2  vmovaps xmm5, [rsp+0x50]
000078af20bd87e8  vmovaps xmm6, [rsp+0x60]
000078af20bd87ee  vmovaps xmm7, [rsp+0x70]
000078af20bd87f4  vmovaps xmm8, [rsp+0x80]
000078af20bd87fd  vmovaps xmm9, [rsp+0x90]
000078af20bd8806  vmovaps xmm10, [rsp+0xA0]
000078af20bd880f  vmovaps xmm11, [rsp+0xB0]
000078af20bd8818  vmovaps xmm12, [rsp+0xC0]
000078af20bd8821  vmovaps xmm13, [rsp+0xD0]
000078af20bd882a  vmovaps xmm14, [rsp+0xE0]
000078af20bd8833  add rsp, 0xF0
000078af20bd883a  pop r11
000078af20bd883c  pop r10
000078af20bd883e  pop r9
000078af20bd8840  pop r8
000078af20bd8842  pop rsi
000078af20bd8843  pop rdi
000078af20bd8844  pop rdx
000078af20bd8845  pop rcx
000078af20bd8846  pop rax
000078af20bd8847  add rsp, 0x08
000078af20bd884b  jmp 0x000078AF20BD3555
000078af20bd8850  sub rsp, 0x08
000078af20bd8854  push rax
000078af20bd8855  push rcx
000078af20bd8856  push rdx
000078af20bd8857  push rdi
000078af20bd8858  push rsi
000078af20bd8859  push r8
000078af20bd885b  push r9
000078af20bd885d  push r10
000078af20bd885f  push r11
000078af20bd8861  sub rsp, 0xF0
000078af20bd8868  vmovaps [rsp], xmm0
000078af20bd886d  vmovaps [rsp+0x10], xmm2
000078af20bd8873  vmovaps [rsp+0x20], xmm3
000078af20bd8879  vmovaps [rsp+0x30], xmm4
000078af20bd887f  vmovaps [rsp+0x40], xmm5
000078af20bd8885  vmovaps [rsp+0x50], xmm6
000078af20bd888b  vmovaps [rsp+0x60], xmm7
000078af20bd8891  vmovaps [rsp+0x70], xmm8
000078af20bd8897  vmovaps [rsp+0x80], xmm9
000078af20bd88a0  vmovaps [rsp+0x90], xmm10
000078af20bd88a9  vmovaps [rsp+0xA0], xmm11
000078af20bd88b2  vmovaps [rsp+0xB0], xmm12
000078af20bd88bb  vmovaps [rsp+0xC0], xmm13
000078af20bd88c4  vmovaps [rsp+0xD0], xmm14
000078af20bd88cd  vmovaps [rsp+0xE0], xmm15
000078af20bd88d6  sub rsp, 0x30
000078af20bd88da  movaps [rsp], xmm1
000078af20bd88de  movaps [rsp+0x10], xmm7
000078af20bd88e3  movaps [rsp+0x20], xmm11
000078af20bd88e9  lea rdi, [rsp]
000078af20bd88ed  mov esi, 0x00
000078af20bd88f2  mov rax, 0x65452FFB8530
000078af20bd88fc  call rax
000078af20bd88fe  movaps xmm1, [rsp]
000078af20bd8902  add rsp, 0x30
000078af20bd8906  vmovaps xmm0, [rsp]
000078af20bd890b  vmovaps xmm2, [rsp+0x10]
000078af20bd8911  vmovaps xmm3, [rsp+0x20]
000078af20bd8917  vmovaps xmm4, [rsp+0x30]
000078af20bd891d  vmovaps xmm5, [rsp+0x40]
000078af20bd8923  vmovaps xmm6, [rsp+0x50]
000078af20bd8929  vmovaps xmm7, [rsp+0x60]
000078af20bd892f  vmovaps xmm8, [rsp+0x70]
000078af20bd8935  vmovaps xmm9, [rsp+0x80]
000078af20bd893e  vmovaps xmm10, [rsp+0x90]
000078af20bd8947  vmovaps xmm11, [rsp+0xA0]
000078af20bd8950  vmovaps xmm12, [rsp+0xB0]
000078af20bd8959  vmovaps xmm13, [rsp+0xC0]
000078af20bd8962  vmovaps xmm14, [rsp+0xD0]
000078af20bd896b  vmovaps xmm15, [rsp+0xE0]
000078af20bd8974  add rsp, 0xF0
000078af20bd897b  pop r11
000078af20bd897d  pop r10
000078af20bd897f  pop r9
000078af20bd8981  pop r8
000078af20bd8983  pop rsi
000078af20bd8984  pop rdi
000078af20bd8985  pop rdx
000078af20bd8986  pop rcx
000078af20bd8987  pop rax
000078af20bd8988  add rsp, 0x08
000078af20bd898c  jmp 0x000078AF20BD3576
000078af20bd8991  call 0x000078AF20A0D600
000078af20bd8996  jmp 0x000078AF20BD3589
000078af20bd899b  call 0x000078AF20A0C380
000078af20bd89a0  jmp 0x000078AF20BD3594
000078af20bd89a5  call 0x000078AF20A0E880
000078af20bd89aa  jmp 0x000078AF20BD359F
000078af20bd89af  call 0x000078AF209FF540
000078af20bd89b4  jmp 0x000078AF20BD35AA
000078af20bd89b9  int3
000078af20bd89ba  nop [rax+rax*1], ax
000078af20bd89c0  mov rax, [r15+0x40]
000078af20bd89c4  mov r14, [r15+0x58]
000078af20bd89c8  lea r12, [rax+r14*1]
000078af20bd89cc  movaps xmm1, [r15+0x1D0]
000078af20bd89d4  vmovaps [rsp+0x10], xmm1
000078af20bd89da  vmovaps xmm15, [rsp+0x10]
000078af20bd89e0  por xmm1, xmm15
000078af20bd89e5  movaps xmm14, [r15+0x1A0]
000078af20bd89ed  vmovaps [rsp+0x10], xmm14
000078af20bd89f3  vmovaps xmm13, [rsp+0x10]
000078af20bd89f9  por xmm14, xmm13
000078af20bd89fe  lea rax, [r12+0x30]
000078af20bd8a03  mov r11, [r13+rax*1]
000078af20bd8a08  lea rax, [r12+0x38]
000078af20bd8a0d  mov r10, [r13+rax*1]
000078af20bd8a12  movq xmm13, r11
000078af20bd8a17  movq xmm12, r10
000078af20bd8a1c  movq xmm13, xmm13
000078af20bd8a21  vmovaps [rsp+0x10], xmm13
000078af20bd8a27  movq xmm13, xmm13
000078af20bd8a2c  movaps [r15+0x130], xmm13
000078af20bd8a34  movq xmm12, xmm12
000078af20bd8a39  vmovaps [rsp+0x20], xmm12
000078af20bd8a3f  movq xmm12, xmm12
000078af20bd8a44  movaps [r15+0x280], xmm12
000078af20bd8a4c  movaps xmm13, [r15+0x270]
000078af20bd8a54  vmovaps [rsp+0x30], xmm13
000078af20bd8a5a  vmovaps xmm12, [rsp+0x30]
000078af20bd8a60  por xmm13, xmm12
000078af20bd8a65  lea rax, [r12+0x20]
000078af20bd8a6a  mov r11, [r13+rax*1]
000078af20bd8a6f  lea rax, [r12+0x28]
000078af20bd8a74  mov r10, [r13+rax*1]
000078af20bd8a79  movq xmm12, r11
000078af20bd8a7e  movq xmm11, r10
000078af20bd8a83  movq xmm12, xmm12
000078af20bd8a88  vmovaps [rsp+0x30], xmm12
000078af20bd8a8e  movq xmm12, xmm12
000078af20bd8a93  movaps [r15+0x150], xmm12
000078af20bd8a9b  movq xmm11, xmm11
000078af20bd8aa0  vmovaps [rsp+0x40], xmm11
000078af20bd8aa6  movq xmm11, xmm11
000078af20bd8aab  movaps [r15+0x140], xmm11
000078af20bd8ab3  lea rax, [r12+0x10]
000078af20bd8ab8  mov r11, [r13+rax*1]
000078af20bd8abd  lea rax, [r12+0x18]
000078af20bd8ac2  mov r10, [r13+rax*1]
000078af20bd8ac7  movq xmm12, r11
000078af20bd8acc  movq xmm11, r10
000078af20bd8ad1  movq xmm12, xmm12
000078af20bd8ad6  vmovaps [rsp+0x50], xmm12
000078af20bd8adc  movq xmm12, xmm12
000078af20bd8ae1  movaps [r15+0x170], xmm12
000078af20bd8ae9  movq xmm11, xmm11
000078af20bd8aee  vmovaps [rsp+0x60], xmm11
000078af20bd8af4  movq xmm11, xmm11
000078af20bd8af9  movaps [r15+0x160], xmm11
000078af20bd8b01  mov rax, [r13+r12*1]
000078af20bd8b06  vmovq xmm12, rax
000078af20bd8b0b  vpbroadcastq xmm12, xmm12
000078af20bd8b10  lea rax, [r12+0x08]
000078af20bd8b15  mov r12, [r13+rax*1]
000078af20bd8b1a  movq xmm11, r12
000078af20bd8b1f  movaps [r15+0x230], xmm11
000078af20bd8b27  mov rax, [r15+0xF8]
000078af20bd8b2e  lea r12, [rax+0x50]
000078af20bd8b32  movups xmm11, [r13+r12*1]
000078af20bd8b38  lea r12, [rax+0x60]
000078af20bd8b3c  movups xmm10, [r13+r12*1]
000078af20bd8b42  lea r12, [rax+0x30]
000078af20bd8b46  movups xmm9, [r13+r12*1]
000078af20bd8b4c  mov r12, [r15+0x50]
000078af20bd8b50  lea r11, [r12+r14*1]
000078af20bd8b54  mov [r15+0x60], r11
000078af20bd8b58  lea r12, [r14+0x40]
000078af20bd8b5c  mov [r15+0x58], r12
000078af20bd8b60  movaps xmm8, xmm12
000078af20bd8b64  mulpd xmm8, xmm15
000078af20bd8b69  vcmppd xmm7, xmm8, xmm8, 0x03
000078af20bd8b6f  ptest xmm7, xmm7
000078af20bd8b74  jnz 0x000078AF20BD9997
000078af20bd8b7a  movq xmm15, qword ptr [r15+0x230]
000078af20bd8b83  vmovaps [rsp+0x70], xmm15
000078af20bd8b89  vpermilpd xmm15, xmm15, 0x00
000078af20bd8b8f  movaps xmm7, xmm9
000078af20bd8b93  mulpd xmm7, xmm15
000078af20bd8b98  vcmppd xmm6, xmm7, xmm7, 0x03
000078af20bd8b9d  ptest xmm6, xmm6
000078af20bd8ba2  jnz 0x000078AF20BD9ADB
000078af20bd8ba8  vxorps xmm15, xmm15, xmm15
000078af20bd8bad  vpbroadcastq xmm15, xmm15
000078af20bd8bb2  movaps xmm9, xmm12
000078af20bd8bb6  mulpd xmm9, xmm10
000078af20bd8bbb  vcmppd xmm6, xmm9, xmm9, 0x03
000078af20bd8bc1  ptest xmm6, xmm6
000078af20bd8bc6  jnz 0x000078AF20BD9C1D
000078af20bd8bcc  movaps xmm10, xmm12
000078af20bd8bd0  mulpd xmm10, xmm11
000078af20bd8bd5  vcmppd xmm6, xmm10, xmm10, 0x03
000078af20bd8bdb  ptest xmm6, xmm6
000078af20bd8be0  jnz 0x000078AF20BD9D61
000078af20bd8be6  movaps xmm11, [r15+0x1F0]
000078af20bd8bee  movaps xmm6, xmm12
000078af20bd8bf2  mulpd xmm6, xmm11
000078af20bd8bf7  vcmppd xmm5, xmm6, xmm6, 0x03
000078af20bd8bfc  ptest xmm5, xmm5
000078af20bd8c01  jnz 0x000078AF20BD9EA5
000078af20bd8c07  movaps xmm12, [r15+0x2A0]
000078af20bd8c0f  vmovaps [rsp+0x80], xmm12
000078af20bd8c18  vmovaps xmm11, [rsp+0x80]
000078af20bd8c21  por xmm12, xmm11
000078af20bd8c26  movaps xmm11, [r15+0x250]
000078af20bd8c2e  vmovaps [rsp+0x80], xmm11
000078af20bd8c37  vmovaps xmm5, [rsp+0x80]
000078af20bd8c40  por xmm11, xmm5
000078af20bd8c45  vmovaps xmm4, [rsp+0x70]
000078af20bd8c4b  vpermilpd xmm4, xmm4, 0x00
000078af20bd8c51  movaps xmm3, xmm5
000078af20bd8c54  mulpd xmm3, xmm4
000078af20bd8c58  vcmppd xmm2, xmm3, xmm3, 0x03
000078af20bd8c5d  ptest xmm2, xmm2
000078af20bd8c62  jnz 0x000078AF20BD9FE7
000078af20bd8c68  mov [rsp+0x80], rax
000078af20bd8c70  xor eax, eax
000078af20bd8c72  mov r14d, 0x200
000078af20bd8c78  cmp r12, r14
000078af20bd8c7b  cmc
000078af20bd8c7c  lahf
000078af20bd8c7d  seto al
000078af20bd8c80  mov [r15+0x108], eax
000078af20bd8c87  movaps xmm5, xmm8
000078af20bd8c8b  addpd xmm5, xmm15
000078af20bd8c90  vcmppd xmm4, xmm5, xmm5, 0x03
000078af20bd8c95  ptest xmm4, xmm4
000078af20bd8c9a  jnz 0x000078AF20BDA127
000078af20bd8ca0  movaps xmm8, [r15+0x1B0]
000078af20bd8ca8  movaps xmm4, xmm9
000078af20bd8cac  addpd xmm4, xmm8
000078af20bd8cb1  vcmppd xmm2, xmm4, xmm4, 0x03
000078af20bd8cb6  ptest xmm2, xmm2
000078af20bd8cbb  jnz 0x000078AF20BDA269
000078af20bd8cc1  movaps xmm9, xmm10
000078af20bd8cc5  addpd xmm9, xmm8
000078af20bd8cca  vcmppd xmm2, xmm9, xmm9, 0x03
000078af20bd8cd0  ptest xmm2, xmm2
000078af20bd8cd5  jnz 0x000078AF20BDA3AB
000078af20bd8cdb  movaps xmm10, [r15+0x2F0]
000078af20bd8ce3  vmovaps [rsp+0x90], xmm10
000078af20bd8cec  vmovaps xmm8, [rsp+0x90]
000078af20bd8cf5  por xmm10, xmm8
000078af20bd8cfa  movaps xmm8, [r15+0x2E0]
000078af20bd8d02  vmovaps [rsp+0x90], xmm8
000078af20bd8d0b  vmovaps xmm2, [rsp+0x90]
000078af20bd8d14  por xmm8, xmm2
000078af20bd8d19  movaps xmm2, [r15+0x2D0]
000078af20bd8d21  vmovaps [rsp+0x90], xmm2
000078af20bd8d2a  vmovaps [rsp+0xA0], xmm1
000078af20bd8d33  vmovaps xmm1, [rsp+0x90]
000078af20bd8d3c  por xmm2, xmm1
000078af20bd8d40  movaps xmm1, [r15+0x200]
000078af20bd8d48  vmovaps [rsp+0x90], xmm1
000078af20bd8d51  vmovaps [rsp+0xB0], xmm15
000078af20bd8d5a  vmovaps xmm15, [rsp+0x90]
000078af20bd8d63  por xmm1, xmm15
000078af20bd8d68  movaps xmm15, [r15+0x1C0]
000078af20bd8d70  vmovaps [rsp+0x90], xmm15
000078af20bd8d79  vmovaps [rsp+0xC0], xmm1
000078af20bd8d82  vmovaps xmm1, [rsp+0x90]
000078af20bd8d8b  por xmm15, xmm1
000078af20bd8d90  movaps xmm1, [r15+0x190]
000078af20bd8d98  vmovaps [rsp+0x90], xmm1
000078af20bd8da1  vmovaps [rsp+0xD0], xmm15
000078af20bd8daa  vmovaps xmm15, [rsp+0x90]
000078af20bd8db3  por xmm1, xmm15
000078af20bd8db8  movaps xmm15, [r15+0x300]
000078af20bd8dc0  vmovaps [rsp+0x90], xmm15
000078af20bd8dc9  vmovaps [rsp+0xE0], xmm1
000078af20bd8dd2  vmovaps xmm1, [rsp+0x90]
000078af20bd8ddb  por xmm15, xmm1
000078af20bd8de0  mov rax, [rsp+0x80]
000078af20bd8de8  lea r14, [rax+0xA0]
000078af20bd8def  movups xmm1, [r13+r14*1]
000078af20bd8df5  lea r14, [rax+0xB0]
000078af20bd8dfc  vmovaps [rsp+0x80], xmm1
000078af20bd8e05  movups xmm1, [r13+r14*1]
000078af20bd8e0b  vmovaps [rsp+0x90], xmm1
000078af20bd8e14  vmovaps [rsp+0xF0], xmm15
000078af20bd8e1d  vmovaps xmm15, [rsp+0xB0]
000078af20bd8e26  vmovaps [rsp+0xB0], xmm14
000078af20bd8e2f  movaps xmm1, xmm6
000078af20bd8e32  addpd xmm1, xmm15
000078af20bd8e37  vcmppd xmm14, xmm1, xmm1, 0x03
000078af20bd8e3c  ptest xmm14, xmm14
000078af20bd8e42  jnz 0x000078AF20BDA503
000078af20bd8e48  lea r14, [rax+0xF0]
000078af20bd8e4f  movups xmm15, [r13+r14*1]
000078af20bd8e55  movaps xmm14, xmm4
000078af20bd8e59  addpd xmm14, xmm3
000078af20bd8e5e  vcmppd xmm6, xmm14, xmm14, 0x03
000078af20bd8e64  ptest xmm6, xmm6
000078af20bd8e69  jnz 0x000078AF20BDA64E
000078af20bd8e6f  movaps xmm6, xmm9
000078af20bd8e73  addpd xmm6, xmm7
000078af20bd8e77  vcmppd xmm4, xmm6, xmm6, 0x03
000078af20bd8e7c  ptest xmm4, xmm4
000078af20bd8e81  jnz 0x000078AF20BDA790
000078af20bd8e87  vmovaps xmm9, [rsp+0x70]
000078af20bd8e8d  vpermilpd xmm9, xmm9, 0x00
000078af20bd8e93  vmovaps xmm4, [rsp+0x90]
000078af20bd8e9c  movaps xmm7, xmm4
000078af20bd8e9f  mulpd xmm7, xmm9
000078af20bd8ea4  vcmppd xmm3, xmm7, xmm7, 0x03
000078af20bd8ea9  ptest xmm3, xmm3
000078af20bd8eae  jnz 0x000078AF20BDA8D1
000078af20bd8eb4  vmovaps xmm9, [rsp+0x50]
000078af20bd8eba  vpermilpd xmm9, xmm9, 0x00
000078af20bd8ec0  movaps xmm4, xmm15
000078af20bd8ec4  mulpd xmm4, xmm9
000078af20bd8ec9  vcmppd xmm3, xmm4, xmm4, 0x03
000078af20bd8ece  ptest xmm3, xmm3
000078af20bd8ed3  jnz 0x000078AF20BDAA12
000078af20bd8ed9  lea r14, [rax+0xE0]
000078af20bd8ee0  movups xmm15, [r13+r14*1]
000078af20bd8ee6  vmovaps xmm9, [rsp+0x70]
000078af20bd8eec  vpermilpd xmm9, xmm9, 0x00
000078af20bd8ef2  vmovaps [rsp+0x70], xmm1
000078af20bd8ef8  vmovaps xmm1, [rsp+0x80]
000078af20bd8f01  vmovaps [rsp+0x80], xmm15
000078af20bd8f0a  movaps xmm3, xmm1
000078af20bd8f0d  mulpd xmm3, xmm9
000078af20bd8f12  vcmppd xmm15, xmm3, xmm3, 0x03
000078af20bd8f17  ptest xmm15, xmm15
000078af20bd8f1d  jnz 0x000078AF20BDAB5E
000078af20bd8f23  vmovaps xmm1, [rsp+0xF0]
000078af20bd8f2c  vmovaps xmm15, [rsp+0xF0]
000078af20bd8f35  por xmm1, xmm15
000078af20bd8f3a  movaps [r15+0x300], xmm1
000078af20bd8f42  vmovaps xmm15, [rsp+0xE0]
000078af20bd8f4b  vmovaps xmm9, [rsp+0xE0]
000078af20bd8f54  por xmm15, xmm9
000078af20bd8f59  movaps [r15+0x190], xmm15
000078af20bd8f61  vmovaps xmm9, [rsp+0x50]
000078af20bd8f67  vpermilpd xmm9, xmm9, 0x00
000078af20bd8f6d  vmovaps [rsp+0x90], xmm1
000078af20bd8f76  vmovaps [rsp+0xE0], xmm15
000078af20bd8f7f  vmovaps xmm15, [rsp+0x80]
000078af20bd8f88  vmovaps [rsp+0x80], xmm14
000078af20bd8f91  movaps xmm1, xmm15
000078af20bd8f95  mulpd xmm1, xmm9
000078af20bd8f9a  vcmppd xmm14, xmm1, xmm1, 0x03
000078af20bd8f9f  ptest xmm14, xmm14
000078af20bd8fa5  jnz 0x000078AF20BDAC9F
000078af20bd8fab  lea r14, [rax+0x90]
000078af20bd8fb2  movups xmm15, [r13+r14*1]
000078af20bd8fb8  vmovaps xmm14, [rsp+0xD0]
000078af20bd8fc1  vmovaps xmm9, [rsp+0xD0]
000078af20bd8fca  por xmm14, xmm9
000078af20bd8fcf  movaps [r15+0x1C0], xmm14
000078af20bd8fd7  vmovaps xmm9, [rsp+0xC0]
000078af20bd8fe0  vmovaps [rsp+0xD0], xmm1
000078af20bd8fe9  vmovaps xmm1, [rsp+0xC0]
000078af20bd8ff2  por xmm9, xmm1
000078af20bd8ff7  movaps [r15+0x200], xmm9
000078af20bd8fff  vmovaps [rsp+0xC0], xmm2
000078af20bd9008  vmovaps xmm1, [rsp+0xC0]
000078af20bd9011  por xmm2, xmm1
000078af20bd9015  movaps [r15+0x2D0], xmm2
000078af20bd901d  vmovaps [rsp+0xC0], xmm8
000078af20bd9026  vmovaps xmm1, [rsp+0xC0]
000078af20bd902f  por xmm8, xmm1
000078af20bd9034  movaps [r15+0x2E0], xmm8
000078af20bd903c  vmovaps [rsp+0xC0], xmm15
000078af20bd9045  movaps xmm1, xmm5
000078af20bd9048  addpd xmm1, xmm7
000078af20bd904c  vcmppd xmm15, xmm1, xmm1, 0x03
000078af20bd9051  ptest xmm15, xmm15
000078af20bd9057  jnz 0x000078AF20BDADEB
000078af20bd905d  vmovaps xmm15, [rsp+0x50]
000078af20bd9063  vpermilpd xmm15, xmm15, 0x00
000078af20bd9069  vmovaps xmm5, [rsp+0xC0]
000078af20bd9072  vmovaps [rsp+0xC0], xmm1
000078af20bd907b  movaps xmm7, xmm5
000078af20bd907e  mulpd xmm7, xmm15
000078af20bd9083  vcmppd xmm1, xmm7, xmm7, 0x03
000078af20bd9088  ptest xmm1, xmm1
000078af20bd908d  jnz 0x000078AF20BDAF2B
000078af20bd9093  lea r14, [rax+0x80]
000078af20bd909a  movups xmm1, [r13+r14*1]
000078af20bd90a0  vmovaps xmm5, [rsp+0x70]
000078af20bd90a6  vmovaps [rsp+0x70], xmm1
000078af20bd90ac  movaps xmm15, xmm5
000078af20bd90b0  addpd xmm15, xmm3
000078af20bd90b5  vcmppd xmm1, xmm15, xmm15, 0x03
000078af20bd90bb  ptest xmm1, xmm1
000078af20bd90c0  jnz 0x000078AF20BDB076
000078af20bd90c6  vmovaps xmm5, [rsp+0x80]
000078af20bd90cf  movaps xmm1, xmm5
000078af20bd90d2  addpd xmm1, xmm4
000078af20bd90d6  vcmppd xmm3, xmm1, xmm1, 0x03
000078af20bd90db  ptest xmm3, xmm3
000078af20bd90e0  jnz 0x000078AF20BDB1B8
000078af20bd90e6  vmovaps [rsp+0x80], xmm10
000078af20bd90ef  vmovaps xmm5, [rsp+0x80]
000078af20bd90f8  por xmm10, xmm5
000078af20bd90fd  movaps [r15+0x2F0], xmm10
000078af20bd9105  vmovaps xmm5, [rsp+0x50]
000078af20bd910b  vpermilpd xmm5, xmm5, 0x00
000078af20bd9111  vmovaps xmm3, [rsp+0x70]
000078af20bd9117  vmovaps [rsp+0x50], xmm1
000078af20bd911d  movaps xmm4, xmm3
000078af20bd9120  mulpd xmm4, xmm5
000078af20bd9124  vcmppd xmm1, xmm4, xmm4, 0x03
000078af20bd9129  ptest xmm1, xmm1
000078af20bd912e  jnz 0x000078AF20BDB2F8
000078af20bd9134  lea r14, [rax+0xD0]
000078af20bd913b  movups xmm1, [r13+r14*1]
000078af20bd9141  vmovaps xmm3, [rsp+0xD0]
000078af20bd914a  vmovaps [rsp+0x70], xmm1
000078af20bd9150  movaps xmm5, xmm6
000078af20bd9153  addpd xmm5, xmm3
000078af20bd9157  vcmppd xmm1, xmm5, xmm5, 0x03
000078af20bd915c  ptest xmm1, xmm1
000078af20bd9161  jnz 0x000078AF20BDB442
000078af20bd9167  vmovaps xmm1, [rsp+0x60]
000078af20bd916d  vpermilpd xmm1, xmm1, 0x00
000078af20bd9173  movaps xmm6, xmm9
000078af20bd9177  mulpd xmm6, xmm1
000078af20bd917b  vcmppd xmm3, xmm6, xmm6, 0x03
000078af20bd9180  ptest xmm3, xmm3
000078af20bd9185  jnz 0x000078AF20BDB582
000078af20bd918b  movaps [r15+0x260], xmm6
000078af20bd9193  vxorps xmm1, xmm1, xmm1
000078af20bd9197  vpbroadcastq xmm1, xmm1
000078af20bd919c  movaps [r15+0x1B0], xmm1
000078af20bd91a4  vmovaps xmm1, [rsp+0x60]
000078af20bd91aa  vpermilpd xmm1, xmm1, 0x00
000078af20bd91b0  vmovaps xmm3, [rsp+0x70]
000078af20bd91b6  vmovaps [rsp+0x70], xmm15
000078af20bd91bc  movaps xmm9, xmm3
000078af20bd91c0  mulpd xmm9, xmm1
000078af20bd91c5  vcmppd xmm15, xmm9, xmm9, 0x03
000078af20bd91cb  ptest xmm15, xmm15
000078af20bd91d1  jnz 0x000078AF20BDB6C3
000078af20bd91d7  lea r14, [rax+0xC0]
000078af20bd91de  movups xmm1, [r13+r14*1]
000078af20bd91e4  vmovaps xmm3, [rsp+0xC0]
000078af20bd91ed  vmovaps [rsp+0x80], xmm1
000078af20bd91f6  movaps xmm15, xmm3
000078af20bd91fa  addpd xmm15, xmm7
000078af20bd91ff  vcmppd xmm1, xmm15, xmm15, 0x03
000078af20bd9205  ptest xmm1, xmm1
000078af20bd920a  jnz 0x000078AF20BDB80F
000078af20bd9210  vmovaps [rsp+0xC0], xmm13
000078af20bd9219  vmovaps xmm1, [rsp+0xC0]
000078af20bd9222  por xmm13, xmm1
000078af20bd9227  movaps [r15+0x270], xmm13
000078af20bd922f  vmovaps xmm1, [rsp+0xB0]
000078af20bd9238  vmovaps xmm7, [rsp+0xB0]
000078af20bd9241  por xmm1, xmm7
000078af20bd9245  movaps [r15+0x1A0], xmm1
000078af20bd924d  vmovaps xmm1, [rsp+0x60]
000078af20bd9253  vpermilpd xmm1, xmm1, 0x00
000078af20bd9259  vmovaps [rsp+0xB0], xmm1
000078af20bd9262  vmovaps xmm1, [rsp+0x80]
000078af20bd926b  vmovaps [rsp+0x80], xmm15
000078af20bd9274  vmovaps xmm15, [rsp+0xB0]
000078af20bd927d  vmovaps [rsp+0xB0], xmm14
000078af20bd9286  movaps xmm3, xmm1
000078af20bd9289  mulpd xmm3, xmm15
000078af20bd928e  vcmppd xmm14, xmm3, xmm3, 0x03
000078af20bd9293  ptest xmm14, xmm14
000078af20bd9299  jnz 0x000078AF20BDB951
000078af20bd929f  lea r14, [rax+0x20]
000078af20bd92a3  movups xmm1, [r13+r14*1]
000078af20bd92a9  movaps [r15+0x110], xmm1
000078af20bd92b1  vmovaps xmm14, [rsp+0x70]
000078af20bd92b7  vmovaps [rsp+0x70], xmm1
000078af20bd92bd  movaps xmm15, xmm14
000078af20bd92c1  addpd xmm15, xmm4
000078af20bd92c6  vcmppd xmm1, xmm15, xmm15, 0x03
000078af20bd92cc  ptest xmm1, xmm1
000078af20bd92d1  jnz 0x000078AF20BDBA9C
000078af20bd92d7  vmovaps xmm1, [rsp+0x60]
000078af20bd92dd  vpermilpd xmm1, xmm1, 0x00
000078af20bd92e3  movaps xmm14, xmm2
000078af20bd92e7  mulpd xmm14, xmm1
000078af20bd92ec  vcmppd xmm4, xmm14, xmm14, 0x03
000078af20bd92f2  ptest xmm4, xmm4
000078af20bd92f7  jnz 0x000078AF20BDBBDF
000078af20bd92fd  vmovaps xmm4, [rsp+0x50]
000078af20bd9303  movaps xmm1, xmm4
000078af20bd9306  addpd xmm1, xmm9
000078af20bd930b  vcmppd xmm2, xmm1, xmm1, 0x03
000078af20bd9310  ptest xmm2, xmm2
000078af20bd9315  jnz 0x000078AF20BDBD21
000078af20bd931b  vmovaps xmm9, [rsp+0x30]
000078af20bd9321  vpermilpd xmm9, xmm9, 0x00
000078af20bd9327  vmovaps xmm2, [rsp+0x70]
000078af20bd932d  vmovaps [rsp+0x50], xmm1
000078af20bd9333  movaps xmm4, xmm2
000078af20bd9336  mulpd xmm4, xmm9
000078af20bd933b  vcmppd xmm1, xmm4, xmm4, 0x03
000078af20bd9340  ptest xmm1, xmm1
000078af20bd9345  jnz 0x000078AF20BDBE62
000078af20bd934b  vmovaps xmm1, [rsp+0x30]
000078af20bd9351  vpermilpd xmm1, xmm1, 0x00
000078af20bd9357  vmovaps xmm2, [rsp+0x90]
000078af20bd9360  vmovaps [rsp+0x60], xmm15
000078af20bd9366  movaps xmm9, xmm2
000078af20bd936a  mulpd xmm9, xmm1
000078af20bd936f  vcmppd xmm15, xmm9, xmm9, 0x03
000078af20bd9375  ptest xmm15, xmm15
000078af20bd937b  jnz 0x000078AF20BDBFA3
000078af20bd9381  vmovaps xmm15, [rsp+0x80]
000078af20bd938a  movaps xmm1, xmm15
000078af20bd938e  addpd xmm1, xmm6
000078af20bd9392  vcmppd xmm2, xmm1, xmm1, 0x03
000078af20bd9397  ptest xmm2, xmm2
000078af20bd939c  jnz 0x000078AF20BDC0E5
000078af20bd93a2  movaps xmm15, xmm5
000078af20bd93a6  addpd xmm15, xmm3
000078af20bd93ab  vcmppd xmm6, xmm15, xmm15, 0x03
000078af20bd93b1  ptest xmm6, xmm6
000078af20bd93b6  jnz 0x000078AF20BDC226
000078af20bd93bc  vmovaps xmm6, [rsp+0x30]
000078af20bd93c2  vpermilpd xmm6, xmm6, 0x00
000078af20bd93c8  movaps xmm5, xmm8
000078af20bd93cc  mulpd xmm5, xmm6
000078af20bd93d0  vcmppd xmm3, xmm5, xmm5, 0x03
000078af20bd93d5  ptest xmm3, xmm3
000078af20bd93da  jnz 0x000078AF20BDC368
000078af20bd93e0  vmovaps xmm8, [rsp+0x30]
000078af20bd93e6  vpermilpd xmm8, xmm8, 0x00
000078af20bd93ec  movaps xmm6, xmm10
000078af20bd93f0  mulpd xmm6, xmm8
000078af20bd93f5  vcmppd xmm3, xmm6, xmm6, 0x03
000078af20bd93fa  ptest xmm3, xmm3
000078af20bd93ff  jnz 0x000078AF20BDC4A9
000078af20bd9405  vmovaps xmm8, [rsp+0x60]
000078af20bd940b  movaps xmm10, xmm8
000078af20bd940f  addpd xmm10, xmm14
000078af20bd9414  vcmppd xmm3, xmm10, xmm10, 0x03
000078af20bd941a  ptest xmm3, xmm3
000078af20bd941f  jnz 0x000078AF20BDC5EB
000078af20bd9425  vmovaps xmm8, [rsp+0x50]
000078af20bd942b  movaps xmm14, xmm8
000078af20bd942f  addpd xmm14, xmm4
000078af20bd9434  vcmppd xmm3, xmm14, xmm14, 0x03
000078af20bd943a  ptest xmm3, xmm3
000078af20bd943f  jnz 0x000078AF20BDC72F
000078af20bd9445  vmovaps xmm8, [rsp+0x40]
000078af20bd944b  vpermilpd xmm8, xmm8, 0x00
000078af20bd9451  movaps xmm4, xmm13
000078af20bd9455  mulpd xmm4, xmm8
000078af20bd945a  vcmppd xmm3, xmm4, xmm4, 0x03
000078af20bd945f  ptest xmm3, xmm3
000078af20bd9464  jnz 0x000078AF20BDC872
000078af20bd946a  movaps xmm13, xmm15
000078af20bd946e  addpd xmm13, xmm9
000078af20bd9473  vcmppd xmm8, xmm13, xmm13, 0x03
000078af20bd9479  ptest xmm8, xmm8
000078af20bd947f  jnz 0x000078AF20BDC9B4
000078af20bd9485  movaps xmm15, xmm1
000078af20bd9489  addpd xmm15, xmm5
000078af20bd948e  vcmppd xmm9, xmm15, xmm15, 0x03
000078af20bd9494  ptest xmm9, xmm9
000078af20bd949a  jnz 0x000078AF20BDCAF8
000078af20bd94a0  vmovaps [rsp+0x30], xmm11
000078af20bd94a6  vmovaps xmm1, [rsp+0x30]
000078af20bd94ac  por xmm11, xmm1
000078af20bd94b1  movaps [r15+0x250], xmm11
000078af20bd94b9  vmovaps [rsp+0x30], xmm12
000078af20bd94bf  vmovaps xmm1, [rsp+0x30]
000078af20bd94c5  por xmm12, xmm1
000078af20bd94ca  movaps [r15+0x2A0], xmm12
000078af20bd94d2  vmovaps xmm1, [rsp+0xA0]
000078af20bd94db  vmovaps xmm11, [rsp+0xA0]
000078af20bd94e4  por xmm1, xmm11
000078af20bd94e9  movaps [r15+0x1D0], xmm1
000078af20bd94f1  lea r14, [rax+0x40]
000078af20bd94f5  movups xmm1, [r13+r14*1]
000078af20bd94fb  movaps [r15+0x2C0], xmm1
000078af20bd9503  vmovaps xmm11, [rsp+0x40]
000078af20bd9509  vpermilpd xmm11, xmm11, 0x00
000078af20bd950f  vmovaps xmm8, [rsp+0xE0]
000078af20bd9518  movaps xmm9, xmm8
000078af20bd951c  mulpd xmm9, xmm11
000078af20bd9521  vcmppd xmm5, xmm9, xmm9, 0x03
000078af20bd9527  ptest xmm5, xmm5
000078af20bd952c  jnz 0x000078AF20BDCC44
000078af20bd9532  movaps xmm11, xmm10
000078af20bd9536  addpd xmm11, xmm6
000078af20bd953b  vcmppd xmm8, xmm11, xmm11, 0x03
000078af20bd9541  ptest xmm8, xmm8
000078af20bd9547  jnz 0x000078AF20BDCD88
000078af20bd954d  movaps xmm10, xmm14
000078af20bd9551  addpd xmm10, xmm4
000078af20bd9556  vcmppd xmm8, xmm10, xmm10, 0x03
000078af20bd955c  ptest xmm8, xmm8
000078af20bd9562  jnz 0x000078AF20BDCECB
000078af20bd9568  vmovaps xmm14, [rsp+0x40]
000078af20bd956e  vpermilpd xmm14, xmm14, 0x00
000078af20bd9574  movaps xmm8, xmm1
000078af20bd9578  mulpd xmm8, xmm14
000078af20bd957d  vcmppd xmm6, xmm8, xmm8, 0x03
000078af20bd9583  ptest xmm6, xmm6
000078af20bd9588  jnz 0x000078AF20BDD00E
000078af20bd958e  movaps xmm1, [r15+0x2B0]
000078af20bd9596  vmovaps xmm14, [rsp+0x40]
000078af20bd959c  vpermilpd xmm14, xmm14, 0x00
000078af20bd95a2  movaps xmm6, xmm1
000078af20bd95a5  mulpd xmm6, xmm14
000078af20bd95aa  vcmppd xmm5, xmm6, xmm6, 0x03
000078af20bd95af  ptest xmm5, xmm5
000078af20bd95b4  jnz 0x000078AF20BDD151
000078af20bd95ba  vmovaps xmm1, [rsp+0x10]
000078af20bd95c0  vpermilpd xmm1, xmm1, 0x00
000078af20bd95c6  movaps xmm14, xmm12
000078af20bd95ca  mulpd xmm14, xmm1
000078af20bd95cf  vcmppd xmm5, xmm14, xmm14, 0x03
000078af20bd95d5  ptest xmm5, xmm5
000078af20bd95da  jnz 0x000078AF20BDD292
000078af20bd95e0  movaps xmm1, xmm13
000078af20bd95e4  addpd xmm1, xmm9
000078af20bd95e9  vcmppd xmm12, xmm1, xmm1, 0x03
000078af20bd95ee  ptest xmm12, xmm12
000078af20bd95f4  jnz 0x000078AF20BDD3D5
000078af20bd95fa  vmovaps xmm13, [rsp+0x10]
000078af20bd9600  vpermilpd xmm13, xmm13, 0x00
000078af20bd9606  movaps xmm12, xmm7
000078af20bd960a  mulpd xmm12, xmm13
000078af20bd960f  vcmppd xmm9, xmm12, xmm12, 0x03
000078af20bd9615  ptest xmm9, xmm9
000078af20bd961b  jnz 0x000078AF20BDD517
000078af20bd9621  movaps xmm13, xmm15
000078af20bd9625  addpd xmm13, xmm8
000078af20bd962a  vcmppd xmm9, xmm13, xmm13, 0x03
000078af20bd9630  ptest xmm9, xmm9
000078af20bd9636  jnz 0x000078AF20BDD65A
000078af20bd963c  movaps xmm15, [r15+0x290]
000078af20bd9644  vmovaps xmm9, [rsp+0x10]
000078af20bd964a  vpermilpd xmm9, xmm9, 0x00
000078af20bd9650  movaps xmm8, xmm15
000078af20bd9654  mulpd xmm8, xmm9
000078af20bd9659  vcmppd xmm7, xmm8, xmm8, 0x03
000078af20bd965f  ptest xmm7, xmm7
000078af20bd9664  jnz 0x000078AF20BDD79E
000078af20bd966a  movaps xmm15, xmm11
000078af20bd966e  addpd xmm15, xmm6
000078af20bd9673  vcmppd xmm9, xmm15, xmm15, 0x03
000078af20bd9679  ptest xmm9, xmm9
000078af20bd967f  jnz 0x000078AF20BDD8E2
000078af20bd9685  movaps xmm11, [r15+0x1E0]
000078af20bd968d  vmovaps xmm9, [rsp+0x10]
000078af20bd9693  vpermilpd xmm9, xmm9, 0x00
000078af20bd9699  movaps xmm7, xmm11
000078af20bd969d  mulpd xmm7, xmm9
000078af20bd96a2  vcmppd xmm6, xmm7, xmm7, 0x03
000078af20bd96a7  ptest xmm6, xmm6
000078af20bd96ac  jnz 0x000078AF20BDDA25
000078af20bd96b2  movaps xmm11, xmm10
000078af20bd96b6  addpd xmm11, xmm14
000078af20bd96bb  vcmppd xmm9, xmm11, xmm11, 0x03
000078af20bd96c1  ptest xmm9, xmm9
000078af20bd96c7  jnz 0x000078AF20BDDB67
000078af20bd96cd  lea r14, [rax+0x70]
000078af20bd96d1  movups xmm14, [r13+r14*1]
000078af20bd96d7  movaps [r15+0x240], xmm14
000078af20bd96df  movaps xmm10, xmm1
000078af20bd96e3  addpd xmm10, xmm12
000078af20bd96e8  vcmppd xmm9, xmm10, xmm10, 0x03
000078af20bd96ee  ptest xmm9, xmm9
000078af20bd96f4  jnz 0x000078AF20BDDCB5
000078af20bd96fa  movaps [r15+0x170], xmm10
000078af20bd9702  vmovaps xmm1, [rsp+0x20]
000078af20bd9708  vpermilpd xmm1, xmm1, 0x00
000078af20bd970e  movaps xmm12, xmm14
000078af20bd9712  mulpd xmm12, xmm1
000078af20bd9717  vcmppd xmm9, xmm12, xmm12, 0x03
000078af20bd971d  ptest xmm9, xmm9
000078af20bd9723  jnz 0x000078AF20BDDDF8
000078af20bd9729  vmovaps xmm1, [rsp+0x20]
000078af20bd972f  vpermilpd xmm1, xmm1, 0x00
000078af20bd9735  vmovaps xmm9, [rsp+0xB0]
000078af20bd973e  movaps xmm14, xmm9
000078af20bd9742  mulpd xmm14, xmm1
000078af20bd9747  vcmppd xmm6, xmm14, xmm14, 0x03
000078af20bd974d  ptest xmm6, xmm6
000078af20bd9752  jnz 0x000078AF20BDDF3B
000078af20bd9758  movaps [r15+0x180], xmm14
000078af20bd9760  movaps xmm1, xmm13
000078af20bd9764  addpd xmm1, xmm8
000078af20bd9769  vcmppd xmm9, xmm1, xmm1, 0x03
000078af20bd976e  ptest xmm9, xmm9
000078af20bd9774  jnz 0x000078AF20BDE07E
000078af20bd977a  movaps [r15+0x210], xmm1
000078af20bd9782  movups xmm13, [r13+rax*1]
000078af20bd9788  lea r14, [rax+0x10]
000078af20bd978c  movups xmm9, [r13+r14*1]
000078af20bd9792  movaps [r15+0x230], xmm9
000078af20bd979a  movaps xmm8, xmm15
000078af20bd979e  addpd xmm8, xmm7
000078af20bd97a3  vcmppd xmm6, xmm8, xmm8, 0x03
000078af20bd97a9  ptest xmm6, xmm6
000078af20bd97ae  jnz 0x000078AF20BDE1D4
000078af20bd97b4  movaps [r15+0x130], xmm8
000078af20bd97bc  vmovaps xmm15, [rsp+0x20]
000078af20bd97c2  vpermilpd xmm15, xmm15, 0x00
000078af20bd97c8  movaps xmm7, xmm9
000078af20bd97cc  mulpd xmm7, xmm15
000078af20bd97d1  vcmppd xmm6, xmm7, xmm7, 0x03
000078af20bd97d6  ptest xmm6, xmm6
000078af20bd97db  jnz 0x000078AF20BDE317
000078af20bd97e1  movaps [r15+0x220], xmm7
000078af20bd97e9  vmovaps xmm15, [rsp+0x20]
000078af20bd97ef  vpermilpd xmm15, xmm15, 0x00
000078af20bd97f5  movaps xmm9, xmm13
000078af20bd97f9  mulpd xmm9, xmm15
000078af20bd97fe  vcmppd xmm6, xmm9, xmm9, 0x03
000078af20bd9804  ptest xmm6, xmm6
000078af20bd9809  jnz 0x000078AF20BDE459
000078af20bd980f  movaps xmm15, xmm11
000078af20bd9813  addpd xmm15, xmm12
000078af20bd9818  vcmppd xmm13, xmm15, xmm15, 0x03
000078af20bd981e  ptest xmm13, xmm13
000078af20bd9824  jnz 0x000078AF20BDE59D
000078af20bd982a  movaps [r15+0x140], xmm15
000078af20bd9832  movaps xmm13, xmm10
000078af20bd9836  addpd xmm13, xmm14
000078af20bd983b  vcmppd xmm12, xmm13, xmm13, 0x03
000078af20bd9841  ptest xmm12, xmm12
000078af20bd9847  jnz 0x000078AF20BDE6E1
000078af20bd984d  movaps [r15+0x150], xmm13
000078af20bd9855  movaps xmm14, xmm1
000078af20bd9859  addpd xmm14, xmm7
000078af20bd985e  vcmppd xmm12, xmm14, xmm14, 0x03
000078af20bd9864  ptest xmm12, xmm12
000078af20bd986a  jnz 0x000078AF20BDE825
000078af20bd9870  movaps [r15+0x160], xmm14
000078af20bd9878  movaps xmm1, xmm8
000078af20bd987c  addpd xmm1, xmm9
000078af20bd9881  vcmppd xmm12, xmm1, xmm1, 0x03
000078af20bd9886  ptest xmm12, xmm12
000078af20bd988c  jnz 0x000078AF20BDE967
000078af20bd9892  movaps [r15+0x120], xmm1
000078af20bd989a  movups [r13+r11*1], xmm15
000078af20bd98a0  lea rax, [r11+0x10]
000078af20bd98a4  movups [r13+rax*1], xmm13
000078af20bd98aa  lea rax, [r11+0x20]
000078af20bd98ae  movups [r13+rax*1], xmm14
000078af20bd98b4  lea rax, [r11+0x30]
000078af20bd98b8  movups [r13+rax*1], xmm1
000078af20bd98be  mov eax, [r15+0x108]
000078af20bd98c5  sahf
000078af20bd98c6  jnz 0x000078AF20BD98F8
000078af20bd98c8  cmp dword ptr [r15+0x318], 0x00
000078af20bd98d0  jz 0x000078AF20BDEAE0
000078af20bd98d6  nop [rax+rax*1], ax
000078af20bd98df  nop [rax+rax*1], eax
000078af20bd98e7  mov eax, 0x4106D0
000078af20bd98ec  mov [r15+0x100], rax
000078af20bd98f3  jmp 0x000078AF209FE110
000078af20bd98f8  cmp dword ptr [r15+0x318], 0x00
000078af20bd9900  jz 0x000078AF20BD89C0
000078af20bd9906  nop [rax+rax*1], ax
000078af20bd990f  nop [rax+rax*1], eax
000078af20bd9917  mov eax, 0x410504
000078af20bd991c  mov [r15+0x100], rax
000078af20bd9923  jmp 0x000078AF209FE110
000078af20bd9928  int3
000078af20bd9929  call 0x000078AF20A0A4B0
000078af20bd992e  jmp 0x000078AF20BD8A08
000078af20bd9933  call 0x000078AF20A09240
000078af20bd9938  jmp 0x000078AF20BD8A12
000078af20bd993d  call 0x000078AF20A0A4B0
000078af20bd9942  jmp 0x000078AF20BD8A6F
000078af20bd9947  call 0x000078AF20A09240
000078af20bd994c  jmp 0x000078AF20BD8A79
000078af20bd9951  call 0x000078AF20A0A4B0
000078af20bd9956  jmp 0x000078AF20BD8ABD
000078af20bd995b  call 0x000078AF20A09240
000078af20bd9960  jmp 0x000078AF20BD8AC7
000078af20bd9965  call 0x000078AF20AB47C0
000078af20bd996a  jmp 0x000078AF20BD8B06
000078af20bd996f  call 0x000078AF20A0B720
000078af20bd9974  jmp 0x000078AF20BD8B1A
000078af20bd9979  call 0x000078AF20ABFC30
000078af20bd997e  jmp 0x000078AF20BD8B38
000078af20bd9983  call 0x000078AF20ABE9C0
000078af20bd9988  jmp 0x000078AF20BD8B42
000078af20bd998d  call 0x000078AF20ABD750
000078af20bd9992  jmp 0x000078AF20BD8B4C
000078af20bd9997  sub rsp, 0x08
000078af20bd999b  push rax
000078af20bd999c  push rcx
000078af20bd999d  push rdx
000078af20bd999e  push rdi
000078af20bd999f  push rsi
000078af20bd99a0  push r8
000078af20bd99a2  push r9
000078af20bd99a4  push r10
000078af20bd99a6  push r11
000078af20bd99a8  sub rsp, 0xF0
000078af20bd99af  vmovaps [rsp], xmm0
000078af20bd99b4  vmovaps [rsp+0x10], xmm1
000078af20bd99ba  vmovaps [rsp+0x20], xmm2
000078af20bd99c0  vmovaps [rsp+0x30], xmm3
000078af20bd99c6  vmovaps [rsp+0x40], xmm4
000078af20bd99cc  vmovaps [rsp+0x50], xmm5
000078af20bd99d2  vmovaps [rsp+0x60], xmm6
000078af20bd99d8  vmovaps [rsp+0x70], xmm7
000078af20bd99de  vmovaps [rsp+0x80], xmm9
000078af20bd99e7  vmovaps [rsp+0x90], xmm10
000078af20bd99f0  vmovaps [rsp+0xA0], xmm11
000078af20bd99f9  vmovaps [rsp+0xB0], xmm12
000078af20bd9a02  vmovaps [rsp+0xC0], xmm13
000078af20bd9a0b  vmovaps [rsp+0xD0], xmm14
000078af20bd9a14  vmovaps [rsp+0xE0], xmm15
000078af20bd9a1d  sub rsp, 0x30
000078af20bd9a21  movaps [rsp], xmm8
000078af20bd9a26  movaps [rsp+0x10], xmm12
000078af20bd9a2c  movaps [rsp+0x20], xmm15
000078af20bd9a32  lea rdi, [rsp]
000078af20bd9a36  mov esi, 0x00
000078af20bd9a3b  mov rax, 0x65452FFB8530
000078af20bd9a45  call rax
000078af20bd9a47  movaps xmm8, [rsp]
000078af20bd9a4c  add rsp, 0x30
000078af20bd9a50  vmovaps xmm0, [rsp]
000078af20bd9a55  vmovaps xmm1, [rsp+0x10]
000078af20bd9a5b  vmovaps xmm2, [rsp+0x20]
000078af20bd9a61  vmovaps xmm3, [rsp+0x30]
000078af20bd9a67  vmovaps xmm4, [rsp+0x40]
000078af20bd9a6d  vmovaps xmm5, [rsp+0x50]
000078af20bd9a73  vmovaps xmm6, [rsp+0x60]
000078af20bd9a79  vmovaps xmm7, [rsp+0x70]
000078af20bd9a7f  vmovaps xmm9, [rsp+0x80]
000078af20bd9a88  vmovaps xmm10, [rsp+0x90]
000078af20bd9a91  vmovaps xmm11, [rsp+0xA0]
000078af20bd9a9a  vmovaps xmm12, [rsp+0xB0]
000078af20bd9aa3  vmovaps xmm13, [rsp+0xC0]
000078af20bd9aac  vmovaps xmm14, [rsp+0xD0]
000078af20bd9ab5  vmovaps xmm15, [rsp+0xE0]
000078af20bd9abe  add rsp, 0xF0
000078af20bd9ac5  pop r11
000078af20bd9ac7  pop r10
000078af20bd9ac9  pop r9
000078af20bd9acb  pop r8
000078af20bd9acd  pop rsi
000078af20bd9ace  pop rdi
000078af20bd9acf  pop rdx
000078af20bd9ad0  pop rcx
000078af20bd9ad1  pop rax
000078af20bd9ad2  add rsp, 0x08
000078af20bd9ad6  jmp 0x000078AF20BD8B7A
000078af20bd9adb  sub rsp, 0x08
000078af20bd9adf  push rax
000078af20bd9ae0  push rcx
000078af20bd9ae1  push rdx
000078af20bd9ae2  push rdi
000078af20bd9ae3  push rsi
000078af20bd9ae4  push r8
000078af20bd9ae6  push r9
000078af20bd9ae8  push r10
000078af20bd9aea  push r11
000078af20bd9aec  sub rsp, 0xF0
000078af20bd9af3  vmovaps [rsp], xmm0
000078af20bd9af8  vmovaps [rsp+0x10], xmm1
000078af20bd9afe  vmovaps [rsp+0x20], xmm2
000078af20bd9b04  vmovaps [rsp+0x30], xmm3
000078af20bd9b0a  vmovaps [rsp+0x40], xmm4
000078af20bd9b10  vmovaps [rsp+0x50], xmm5
000078af20bd9b16  vmovaps [rsp+0x60], xmm6
000078af20bd9b1c  vmovaps [rsp+0x70], xmm8
000078af20bd9b22  vmovaps [rsp+0x80], xmm9
000078af20bd9b2b  vmovaps [rsp+0x90], xmm10
000078af20bd9b34  vmovaps [rsp+0xA0], xmm11
000078af20bd9b3d  vmovaps [rsp+0xB0], xmm12
000078af20bd9b46  vmovaps [rsp+0xC0], xmm13
000078af20bd9b4f  vmovaps [rsp+0xD0], xmm14
000078af20bd9b58  vmovaps [rsp+0xE0], xmm15
000078af20bd9b61  sub rsp, 0x30
000078af20bd9b65  movaps [rsp], xmm7
000078af20bd9b69  movaps [rsp+0x10], xmm9
000078af20bd9b6f  movaps [rsp+0x20], xmm15
000078af20bd9b75  lea rdi, [rsp]
000078af20bd9b79  mov esi, 0x00
000078af20bd9b7e  mov rax, 0x65452FFB8530
000078af20bd9b88  call rax
000078af20bd9b8a  movaps xmm7, [rsp]
000078af20bd9b8e  add rsp, 0x30
000078af20bd9b92  vmovaps xmm0, [rsp]
000078af20bd9b97  vmovaps xmm1, [rsp+0x10]
000078af20bd9b9d  vmovaps xmm2, [rsp+0x20]
000078af20bd9ba3  vmovaps xmm3, [rsp+0x30]
000078af20bd9ba9  vmovaps xmm4, [rsp+0x40]
000078af20bd9baf  vmovaps xmm5, [rsp+0x50]
000078af20bd9bb5  vmovaps xmm6, [rsp+0x60]
000078af20bd9bbb  vmovaps xmm8, [rsp+0x70]
000078af20bd9bc1  vmovaps xmm9, [rsp+0x80]
000078af20bd9bca  vmovaps xmm10, [rsp+0x90]
000078af20bd9bd3  vmovaps xmm11, [rsp+0xA0]
000078af20bd9bdc  vmovaps xmm12, [rsp+0xB0]
000078af20bd9be5  vmovaps xmm13, [rsp+0xC0]
000078af20bd9bee  vmovaps xmm14, [rsp+0xD0]
000078af20bd9bf7  vmovaps xmm15, [rsp+0xE0]
000078af20bd9c00  add rsp, 0xF0
000078af20bd9c07  pop r11
000078af20bd9c09  pop r10
000078af20bd9c0b  pop r9
000078af20bd9c0d  pop r8
000078af20bd9c0f  pop rsi
000078af20bd9c10  pop rdi
000078af20bd9c11  pop rdx
000078af20bd9c12  pop rcx
000078af20bd9c13  pop rax
000078af20bd9c14  add rsp, 0x08
000078af20bd9c18  jmp 0x000078AF20BD8BA8
000078af20bd9c1d  sub rsp, 0x08
000078af20bd9c21  push rax
000078af20bd9c22  push rcx
000078af20bd9c23  push rdx
000078af20bd9c24  push rdi
000078af20bd9c25  push rsi
000078af20bd9c26  push r8
000078af20bd9c28  push r9
000078af20bd9c2a  push r10
000078af20bd9c2c  push r11
000078af20bd9c2e  sub rsp, 0xF0
000078af20bd9c35  vmovaps [rsp], xmm0
000078af20bd9c3a  vmovaps [rsp+0x10], xmm1
000078af20bd9c40  vmovaps [rsp+0x20], xmm2
000078af20bd9c46  vmovaps [rsp+0x30], xmm3
000078af20bd9c4c  vmovaps [rsp+0x40], xmm4
000078af20bd9c52  vmovaps [rsp+0x50], xmm5
000078af20bd9c58  vmovaps [rsp+0x60], xmm6
000078af20bd9c5e  vmovaps [rsp+0x70], xmm7
000078af20bd9c64  vmovaps [rsp+0x80], xmm8
000078af20bd9c6d  vmovaps [rsp+0x90], xmm10
000078af20bd9c76  vmovaps [rsp+0xA0], xmm11
000078af20bd9c7f  vmovaps [rsp+0xB0], xmm12
000078af20bd9c88  vmovaps [rsp+0xC0], xmm13
000078af20bd9c91  vmovaps [rsp+0xD0], xmm14
000078af20bd9c9a  vmovaps [rsp+0xE0], xmm15
000078af20bd9ca3  sub rsp, 0x30
000078af20bd9ca7  movaps [rsp], xmm9
000078af20bd9cac  movaps [rsp+0x10], xmm12
000078af20bd9cb2  movaps [rsp+0x20], xmm10
000078af20bd9cb8  lea rdi, [rsp]
000078af20bd9cbc  mov esi, 0x00
000078af20bd9cc1  mov rax, 0x65452FFB8530
000078af20bd9ccb  call rax
000078af20bd9ccd  movaps xmm9, [rsp]
000078af20bd9cd2  add rsp, 0x30
000078af20bd9cd6  vmovaps xmm0, [rsp]
000078af20bd9cdb  vmovaps xmm1, [rsp+0x10]
000078af20bd9ce1  vmovaps xmm2, [rsp+0x20]
000078af20bd9ce7  vmovaps xmm3, [rsp+0x30]
000078af20bd9ced  vmovaps xmm4, [rsp+0x40]
000078af20bd9cf3  vmovaps xmm5, [rsp+0x50]
000078af20bd9cf9  vmovaps xmm6, [rsp+0x60]
000078af20bd9cff  vmovaps xmm7, [rsp+0x70]
000078af20bd9d05  vmovaps xmm8, [rsp+0x80]
000078af20bd9d0e  vmovaps xmm10, [rsp+0x90]
000078af20bd9d17  vmovaps xmm11, [rsp+0xA0]
000078af20bd9d20  vmovaps xmm12, [rsp+0xB0]
000078af20bd9d29  vmovaps xmm13, [rsp+0xC0]
000078af20bd9d32  vmovaps xmm14, [rsp+0xD0]
000078af20bd9d3b  vmovaps xmm15, [rsp+0xE0]
000078af20bd9d44  add rsp, 0xF0
000078af20bd9d4b  pop r11
000078af20bd9d4d  pop r10
000078af20bd9d4f  pop r9
000078af20bd9d51  pop r8
000078af20bd9d53  pop rsi
000078af20bd9d54  pop rdi
000078af20bd9d55  pop rdx
000078af20bd9d56  pop rcx
000078af20bd9d57  pop rax
000078af20bd9d58  add rsp, 0x08
000078af20bd9d5c  jmp 0x000078AF20BD8BCC
000078af20bd9d61  sub rsp, 0x08
000078af20bd9d65  push rax
000078af20bd9d66  push rcx
000078af20bd9d67  push rdx
000078af20bd9d68  push rdi
000078af20bd9d69  push rsi
000078af20bd9d6a  push r8
000078af20bd9d6c  push r9
000078af20bd9d6e  push r10
000078af20bd9d70  push r11
000078af20bd9d72  sub rsp, 0xF0
000078af20bd9d79  vmovaps [rsp], xmm0
000078af20bd9d7e  vmovaps [rsp+0x10], xmm1
000078af20bd9d84  vmovaps [rsp+0x20], xmm2
000078af20bd9d8a  vmovaps [rsp+0x30], xmm3
000078af20bd9d90  vmovaps [rsp+0x40], xmm4
000078af20bd9d96  vmovaps [rsp+0x50], xmm5
000078af20bd9d9c  vmovaps [rsp+0x60], xmm6
000078af20bd9da2  vmovaps [rsp+0x70], xmm7
000078af20bd9da8  vmovaps [rsp+0x80], xmm8
000078af20bd9db1  vmovaps [rsp+0x90], xmm9
000078af20bd9dba  vmovaps [rsp+0xA0], xmm11
000078af20bd9dc3  vmovaps [rsp+0xB0], xmm12
000078af20bd9dcc  vmovaps [rsp+0xC0], xmm13
000078af20bd9dd5  vmovaps [rsp+0xD0], xmm14
000078af20bd9dde  vmovaps [rsp+0xE0], xmm15
000078af20bd9de7  sub rsp, 0x30
000078af20bd9deb  movaps [rsp], xmm10
000078af20bd9df0  movaps [rsp+0x10], xmm12
000078af20bd9df6  movaps [rsp+0x20], xmm11
000078af20bd9dfc  lea rdi, [rsp]
000078af20bd9e00  mov esi, 0x00
000078af20bd9e05  mov rax, 0x65452FFB8530
000078af20bd9e0f  call rax
000078af20bd9e11  movaps xmm10, [rsp]
000078af20bd9e16  add rsp, 0x30
000078af20bd9e1a  vmovaps xmm0, [rsp]
000078af20bd9e1f  vmovaps xmm1, [rsp+0x10]
000078af20bd9e25  vmovaps xmm2, [rsp+0x20]
000078af20bd9e2b  vmovaps xmm3, [rsp+0x30]
000078af20bd9e31  vmovaps xmm4, [rsp+0x40]
000078af20bd9e37  vmovaps xmm5, [rsp+0x50]
000078af20bd9e3d  vmovaps xmm6, [rsp+0x60]
000078af20bd9e43  vmovaps xmm7, [rsp+0x70]
000078af20bd9e49  vmovaps xmm8, [rsp+0x80]
000078af20bd9e52  vmovaps xmm9, [rsp+0x90]
000078af20bd9e5b  vmovaps xmm11, [rsp+0xA0]
000078af20bd9e64  vmovaps xmm12, [rsp+0xB0]
000078af20bd9e6d  vmovaps xmm13, [rsp+0xC0]
000078af20bd9e76  vmovaps xmm14, [rsp+0xD0]
000078af20bd9e7f  vmovaps xmm15, [rsp+0xE0]
000078af20bd9e88  add rsp, 0xF0
000078af20bd9e8f  pop r11
000078af20bd9e91  pop r10
000078af20bd9e93  pop r9
000078af20bd9e95  pop r8
000078af20bd9e97  pop rsi
000078af20bd9e98  pop rdi
000078af20bd9e99  pop rdx
000078af20bd9e9a  pop rcx
000078af20bd9e9b  pop rax
000078af20bd9e9c  add rsp, 0x08
000078af20bd9ea0  jmp 0x000078AF20BD8BE6
000078af20bd9ea5  sub rsp, 0x08
000078af20bd9ea9  push rax
000078af20bd9eaa  push rcx
000078af20bd9eab  push rdx
000078af20bd9eac  push rdi
000078af20bd9ead  push rsi
000078af20bd9eae  push r8
000078af20bd9eb0  push r9
000078af20bd9eb2  push r10
000078af20bd9eb4  push r11
000078af20bd9eb6  sub rsp, 0xF0
000078af20bd9ebd  vmovaps [rsp], xmm0
000078af20bd9ec2  vmovaps [rsp+0x10], xmm1
000078af20bd9ec8  vmovaps [rsp+0x20], xmm2
000078af20bd9ece  vmovaps [rsp+0x30], xmm3
000078af20bd9ed4  vmovaps [rsp+0x40], xmm4
000078af20bd9eda  vmovaps [rsp+0x50], xmm5
000078af20bd9ee0  vmovaps [rsp+0x60], xmm7
000078af20bd9ee6  vmovaps [rsp+0x70], xmm8
000078af20bd9eec  vmovaps [rsp+0x80], xmm9
000078af20bd9ef5  vmovaps [rsp+0x90], xmm10
000078af20bd9efe  vmovaps [rsp+0xA0], xmm11
000078af20bd9f07  vmovaps [rsp+0xB0], xmm12
000078af20bd9f10  vmovaps [rsp+0xC0], xmm13
000078af20bd9f19  vmovaps [rsp+0xD0], xmm14
000078af20bd9f22  vmovaps [rsp+0xE0], xmm15
000078af20bd9f2b  sub rsp, 0x30
000078af20bd9f2f  movaps [rsp], xmm6
000078af20bd9f33  movaps [rsp+0x10], xmm12
000078af20bd9f39  movaps [rsp+0x20], xmm11
000078af20bd9f3f  lea rdi, [rsp]
000078af20bd9f43  mov esi, 0x00
000078af20bd9f48  mov rax, 0x65452FFB8530
000078af20bd9f52  call rax
000078af20bd9f54  movaps xmm6, [rsp]
000078af20bd9f58  add rsp, 0x30
000078af20bd9f5c  vmovaps xmm0, [rsp]
000078af20bd9f61  vmovaps xmm1, [rsp+0x10]
000078af20bd9f67  vmovaps xmm2, [rsp+0x20]
000078af20bd9f6d  vmovaps xmm3, [rsp+0x30]
000078af20bd9f73  vmovaps xmm4, [rsp+0x40]
000078af20bd9f79  vmovaps xmm5, [rsp+0x50]
000078af20bd9f7f  vmovaps xmm7, [rsp+0x60]
000078af20bd9f85  vmovaps xmm8, [rsp+0x70]
000078af20bd9f8b  vmovaps xmm9, [rsp+0x80]
000078af20bd9f94  vmovaps xmm10, [rsp+0x90]
000078af20bd9f9d  vmovaps xmm11, [rsp+0xA0]
000078af20bd9fa6  vmovaps xmm12, [rsp+0xB0]
000078af20bd9faf  vmovaps xmm13, [rsp+0xC0]
000078af20bd9fb8  vmovaps xmm14, [rsp+0xD0]
000078af20bd9fc1  vmovaps xmm15, [rsp+0xE0]
000078af20bd9fca  add rsp, 0xF0
000078af20bd9fd1  pop r11
000078af20bd9fd3  pop r10
000078af20bd9fd5  pop r9
000078af20bd9fd7  pop r8
000078af20bd9fd9  pop rsi
000078af20bd9fda  pop rdi
000078af20bd9fdb  pop rdx
000078af20bd9fdc  pop rcx
000078af20bd9fdd  pop rax
000078af20bd9fde  add rsp, 0x08
000078af20bd9fe2  jmp 0x000078AF20BD8C07
000078af20bd9fe7  sub rsp, 0x08
000078af20bd9feb  push rax
000078af20bd9fec  push rcx
000078af20bd9fed  push rdx
000078af20bd9fee  push rdi
000078af20bd9fef  push rsi
000078af20bd9ff0  push r8
000078af20bd9ff2  push r9
000078af20bd9ff4  push r10
000078af20bd9ff6  push r11
000078af20bd9ff8  sub rsp, 0xF0
000078af20bd9fff  vmovaps [rsp], xmm0
000078af20bda004  vmovaps [rsp+0x10], xmm1
000078af20bda00a  vmovaps [rsp+0x20], xmm2
000078af20bda010  vmovaps [rsp+0x30], xmm4
000078af20bda016  vmovaps [rsp+0x40], xmm5
000078af20bda01c  vmovaps [rsp+0x50], xmm6
000078af20bda022  vmovaps [rsp+0x60], xmm7
000078af20bda028  vmovaps [rsp+0x70], xmm8
000078af20bda02e  vmovaps [rsp+0x80], xmm9
000078af20bda037  vmovaps [rsp+0x90], xmm10
000078af20bda040  vmovaps [rsp+0xA0], xmm11
000078af20bda049  vmovaps [rsp+0xB0], xmm12
000078af20bda052  vmovaps [rsp+0xC0], xmm13
000078af20bda05b  vmovaps [rsp+0xD0], xmm14
000078af20bda064  vmovaps [rsp+0xE0], xmm15
000078af20bda06d  sub rsp, 0x30
000078af20bda071  movaps [rsp], xmm3
000078af20bda075  movaps [rsp+0x10], xmm5
000078af20bda07a  movaps [rsp+0x20], xmm4
000078af20bda07f  lea rdi, [rsp]
000078af20bda083  mov esi, 0x00
000078af20bda088  mov rax, 0x65452FFB8530
000078af20bda092  call rax
000078af20bda094  movaps xmm3, [rsp]
000078af20bda098  add rsp, 0x30
000078af20bda09c  vmovaps xmm0, [rsp]
000078af20bda0a1  vmovaps xmm1, [rsp+0x10]
000078af20bda0a7  vmovaps xmm2, [rsp+0x20]
000078af20bda0ad  vmovaps xmm4, [rsp+0x30]
000078af20bda0b3  vmovaps xmm5, [rsp+0x40]
000078af20bda0b9  vmovaps xmm6, [rsp+0x50]
000078af20bda0bf  vmovaps xmm7, [rsp+0x60]
000078af20bda0c5  vmovaps xmm8, [rsp+0x70]
000078af20bda0cb  vmovaps xmm9, [rsp+0x80]
000078af20bda0d4  vmovaps xmm10, [rsp+0x90]
000078af20bda0dd  vmovaps xmm11, [rsp+0xA0]
000078af20bda0e6  vmovaps xmm12, [rsp+0xB0]
000078af20bda0ef  vmovaps xmm13, [rsp+0xC0]
000078af20bda0f8  vmovaps xmm14, [rsp+0xD0]
000078af20bda101  vmovaps xmm15, [rsp+0xE0]
000078af20bda10a  add rsp, 0xF0
000078af20bda111  pop r11
000078af20bda113  pop r10
000078af20bda115  pop r9
000078af20bda117  pop r8
000078af20bda119  pop rsi
000078af20bda11a  pop rdi
000078af20bda11b  pop rdx
000078af20bda11c  pop rcx
000078af20bda11d  pop rax
000078af20bda11e  add rsp, 0x08
000078af20bda122  jmp 0x000078AF20BD8C68
000078af20bda127  sub rsp, 0x08
000078af20bda12b  push rax
000078af20bda12c  push rcx
000078af20bda12d  push rdx
000078af20bda12e  push rdi
000078af20bda12f  push rsi
000078af20bda130  push r8
000078af20bda132  push r9
000078af20bda134  push r10
000078af20bda136  push r11
000078af20bda138  sub rsp, 0xF0
000078af20bda13f  vmovaps [rsp], xmm0
000078af20bda144  vmovaps [rsp+0x10], xmm1
000078af20bda14a  vmovaps [rsp+0x20], xmm2
000078af20bda150  vmovaps [rsp+0x30], xmm3
000078af20bda156  vmovaps [rsp+0x40], xmm4
000078af20bda15c  vmovaps [rsp+0x50], xmm6
000078af20bda162  vmovaps [rsp+0x60], xmm7
000078af20bda168  vmovaps [rsp+0x70], xmm8
000078af20bda16e  vmovaps [rsp+0x80], xmm9
000078af20bda177  vmovaps [rsp+0x90], xmm10
000078af20bda180  vmovaps [rsp+0xA0], xmm11
000078af20bda189  vmovaps [rsp+0xB0], xmm12
000078af20bda192  vmovaps [rsp+0xC0], xmm13
000078af20bda19b  vmovaps [rsp+0xD0], xmm14
000078af20bda1a4  vmovaps [rsp+0xE0], xmm15
000078af20bda1ad  sub rsp, 0x30
000078af20bda1b1  movaps [rsp], xmm5
000078af20bda1b5  movaps [rsp+0x10], xmm8
000078af20bda1bb  movaps [rsp+0x20], xmm15
000078af20bda1c1  lea rdi, [rsp]
000078af20bda1c5  mov esi, 0x00
000078af20bda1ca  mov rax, 0x65452FFB8530
000078af20bda1d4  call rax
000078af20bda1d6  movaps xmm5, [rsp]
000078af20bda1da  add rsp, 0x30
000078af20bda1de  vmovaps xmm0, [rsp]
000078af20bda1e3  vmovaps xmm1, [rsp+0x10]
000078af20bda1e9  vmovaps xmm2, [rsp+0x20]
000078af20bda1ef  vmovaps xmm3, [rsp+0x30]
000078af20bda1f5  vmovaps xmm4, [rsp+0x40]
000078af20bda1fb  vmovaps xmm6, [rsp+0x50]
000078af20bda201  vmovaps xmm7, [rsp+0x60]
000078af20bda207  vmovaps xmm8, [rsp+0x70]
000078af20bda20d  vmovaps xmm9, [rsp+0x80]
000078af20bda216  vmovaps xmm10, [rsp+0x90]
000078af20bda21f  vmovaps xmm11, [rsp+0xA0]
000078af20bda228  vmovaps xmm12, [rsp+0xB0]
000078af20bda231  vmovaps xmm13, [rsp+0xC0]
000078af20bda23a  vmovaps xmm14, [rsp+0xD0]
000078af20bda243  vmovaps xmm15, [rsp+0xE0]
000078af20bda24c  add rsp, 0xF0
000078af20bda253  pop r11
000078af20bda255  pop r10
000078af20bda257  pop r9
000078af20bda259  pop r8
000078af20bda25b  pop rsi
000078af20bda25c  pop rdi
000078af20bda25d  pop rdx
000078af20bda25e  pop rcx
000078af20bda25f  pop rax
000078af20bda260  add rsp, 0x08
000078af20bda264  jmp 0x000078AF20BD8CA0
000078af20bda269  sub rsp, 0x08
000078af20bda26d  push rax
000078af20bda26e  push rcx
000078af20bda26f  push rdx
000078af20bda270  push rdi
000078af20bda271  push rsi
000078af20bda272  push r8
000078af20bda274  push r9
000078af20bda276  push r10
000078af20bda278  push r11
000078af20bda27a  sub rsp, 0xF0
000078af20bda281  vmovaps [rsp], xmm0
000078af20bda286  vmovaps [rsp+0x10], xmm1
000078af20bda28c  vmovaps [rsp+0x20], xmm2
000078af20bda292  vmovaps [rsp+0x30], xmm3
000078af20bda298  vmovaps [rsp+0x40], xmm5
000078af20bda29e  vmovaps [rsp+0x50], xmm6
000078af20bda2a4  vmovaps [rsp+0x60], xmm7
000078af20bda2aa  vmovaps [rsp+0x70], xmm8
000078af20bda2b0  vmovaps [rsp+0x80], xmm9
000078af20bda2b9  vmovaps [rsp+0x90], xmm10
000078af20bda2c2  vmovaps [rsp+0xA0], xmm11
000078af20bda2cb  vmovaps [rsp+0xB0], xmm12
000078af20bda2d4  vmovaps [rsp+0xC0], xmm13
000078af20bda2dd  vmovaps [rsp+0xD0], xmm14
000078af20bda2e6  vmovaps [rsp+0xE0], xmm15
000078af20bda2ef  sub rsp, 0x30
000078af20bda2f3  movaps [rsp], xmm4
000078af20bda2f7  movaps [rsp+0x10], xmm9
000078af20bda2fd  movaps [rsp+0x20], xmm8
000078af20bda303  lea rdi, [rsp]
000078af20bda307  mov esi, 0x00
000078af20bda30c  mov rax, 0x65452FFB8530
000078af20bda316  call rax
000078af20bda318  movaps xmm4, [rsp]
000078af20bda31c  add rsp, 0x30
000078af20bda320  vmovaps xmm0, [rsp]
000078af20bda325  vmovaps xmm1, [rsp+0x10]
000078af20bda32b  vmovaps xmm2, [rsp+0x20]
000078af20bda331  vmovaps xmm3, [rsp+0x30]
000078af20bda337  vmovaps xmm5, [rsp+0x40]
000078af20bda33d  vmovaps xmm6, [rsp+0x50]
000078af20bda343  vmovaps xmm7, [rsp+0x60]
000078af20bda349  vmovaps xmm8, [rsp+0x70]
000078af20bda34f  vmovaps xmm9, [rsp+0x80]
000078af20bda358  vmovaps xmm10, [rsp+0x90]
000078af20bda361  vmovaps xmm11, [rsp+0xA0]
000078af20bda36a  vmovaps xmm12, [rsp+0xB0]
000078af20bda373  vmovaps xmm13, [rsp+0xC0]
000078af20bda37c  vmovaps xmm14, [rsp+0xD0]
000078af20bda385  vmovaps xmm15, [rsp+0xE0]
000078af20bda38e  add rsp, 0xF0
000078af20bda395  pop r11
000078af20bda397  pop r10
000078af20bda399  pop r9
000078af20bda39b  pop r8
000078af20bda39d  pop rsi
000078af20bda39e  pop rdi
000078af20bda39f  pop rdx
000078af20bda3a0  pop rcx
000078af20bda3a1  pop rax
000078af20bda3a2  add rsp, 0x08
000078af20bda3a6  jmp 0x000078AF20BD8CC1
000078af20bda3ab  sub rsp, 0x08
000078af20bda3af  push rax
000078af20bda3b0  push rcx
000078af20bda3b1  push rdx
000078af20bda3b2  push rdi
000078af20bda3b3  push rsi
000078af20bda3b4  push r8
000078af20bda3b6  push r9
000078af20bda3b8  push r10
000078af20bda3ba  push r11
000078af20bda3bc  sub rsp, 0xF0
000078af20bda3c3  vmovaps [rsp], xmm0
000078af20bda3c8  vmovaps [rsp+0x10], xmm1
000078af20bda3ce  vmovaps [rsp+0x20], xmm2
000078af20bda3d4  vmovaps [rsp+0x30], xmm3
000078af20bda3da  vmovaps [rsp+0x40], xmm4
000078af20bda3e0  vmovaps [rsp+0x50], xmm5
000078af20bda3e6  vmovaps [rsp+0x60], xmm6
000078af20bda3ec  vmovaps [rsp+0x70], xmm7
000078af20bda3f2  vmovaps [rsp+0x80], xmm8
000078af20bda3fb  vmovaps [rsp+0x90], xmm10
000078af20bda404  vmovaps [rsp+0xA0], xmm11
000078af20bda40d  vmovaps [rsp+0xB0], xmm12
000078af20bda416  vmovaps [rsp+0xC0], xmm13
000078af20bda41f  vmovaps [rsp+0xD0], xmm14
000078af20bda428  vmovaps [rsp+0xE0], xmm15
000078af20bda431  sub rsp, 0x30
000078af20bda435  movaps [rsp], xmm9
000078af20bda43a  movaps [rsp+0x10], xmm10
000078af20bda440  movaps [rsp+0x20], xmm8
000078af20bda446  lea rdi, [rsp]
000078af20bda44a  mov esi, 0x00
000078af20bda44f  mov rax, 0x65452FFB8530
000078af20bda459  call rax
000078af20bda45b  movaps xmm9, [rsp]
000078af20bda460  add rsp, 0x30
000078af20bda464  vmovaps xmm0, [rsp]
000078af20bda469  vmovaps xmm1, [rsp+0x10]
000078af20bda46f  vmovaps xmm2, [rsp+0x20]
000078af20bda475  vmovaps xmm3, [rsp+0x30]
000078af20bda47b  vmovaps xmm4, [rsp+0x40]
000078af20bda481  vmovaps xmm5, [rsp+0x50]
000078af20bda487  vmovaps xmm6, [rsp+0x60]
000078af20bda48d  vmovaps xmm7, [rsp+0x70]
000078af20bda493  vmovaps xmm8, [rsp+0x80]
000078af20bda49c  vmovaps xmm10, [rsp+0x90]
000078af20bda4a5  vmovaps xmm11, [rsp+0xA0]
000078af20bda4ae  vmovaps xmm12, [rsp+0xB0]
000078af20bda4b7  vmovaps xmm13, [rsp+0xC0]
000078af20bda4c0  vmovaps xmm14, [rsp+0xD0]
000078af20bda4c9  vmovaps xmm15, [rsp+0xE0]
000078af20bda4d2  add rsp, 0xF0
000078af20bda4d9  pop r11
000078af20bda4db  pop r10
000078af20bda4dd  pop r9
000078af20bda4df  pop r8
000078af20bda4e1  pop rsi
000078af20bda4e2  pop rdi
000078af20bda4e3  pop rdx
000078af20bda4e4  pop rcx
000078af20bda4e5  pop rax
000078af20bda4e6  add rsp, 0x08
000078af20bda4ea  jmp 0x000078AF20BD8CDB
000078af20bda4ef  call 0x000078AF20AD64F0
000078af20bda4f4  jmp 0x000078AF20BD8DF5
000078af20bda4f9  call 0x000078AF20AD64F0
000078af20bda4fe  jmp 0x000078AF20BD8E0B
000078af20bda503  sub rsp, 0x08
000078af20bda507  push rax
000078af20bda508  push rcx
000078af20bda509  push rdx
000078af20bda50a  push rdi
000078af20bda50b  push rsi
000078af20bda50c  push r8
000078af20bda50e  push r9
000078af20bda510  push r10
000078af20bda512  push r11
000078af20bda514  sub rsp, 0xF0
000078af20bda51b  vmovaps [rsp], xmm0
000078af20bda520  vmovaps [rsp+0x10], xmm2
000078af20bda526  vmovaps [rsp+0x20], xmm3
000078af20bda52c  vmovaps [rsp+0x30], xmm4
000078af20bda532  vmovaps [rsp+0x40], xmm5
000078af20bda538  vmovaps [rsp+0x50], xmm6
000078af20bda53e  vmovaps [rsp+0x60], xmm7
000078af20bda544  vmovaps [rsp+0x70], xmm8
000078af20bda54a  vmovaps [rsp+0x80], xmm9
000078af20bda553  vmovaps [rsp+0x90], xmm10
000078af20bda55c  vmovaps [rsp+0xA0], xmm11
000078af20bda565  vmovaps [rsp+0xB0], xmm12
000078af20bda56e  vmovaps [rsp+0xC0], xmm13
000078af20bda577  vmovaps [rsp+0xD0], xmm14
000078af20bda580  vmovaps [rsp+0xE0], xmm15
000078af20bda589  sub rsp, 0x30
000078af20bda58d  movaps [rsp], xmm1
000078af20bda591  movaps [rsp+0x10], xmm6
000078af20bda596  movaps [rsp+0x20], xmm15
000078af20bda59c  lea rdi, [rsp]
000078af20bda5a0  mov esi, 0x00
000078af20bda5a5  mov rax, 0x65452FFB8530
000078af20bda5af  call rax
000078af20bda5b1  movaps xmm1, [rsp]
000078af20bda5b5  add rsp, 0x30
000078af20bda5b9  vmovaps xmm0, [rsp]
000078af20bda5be  vmovaps xmm2, [rsp+0x10]
000078af20bda5c4  vmovaps xmm3, [rsp+0x20]
000078af20bda5ca  vmovaps xmm4, [rsp+0x30]
000078af20bda5d0  vmovaps xmm5, [rsp+0x40]
000078af20bda5d6  vmovaps xmm6, [rsp+0x50]
000078af20bda5dc  vmovaps xmm7, [rsp+0x60]
000078af20bda5e2  vmovaps xmm8, [rsp+0x70]
000078af20bda5e8  vmovaps xmm9, [rsp+0x80]
000078af20bda5f1  vmovaps xmm10, [rsp+0x90]
000078af20bda5fa  vmovaps xmm11, [rsp+0xA0]
000078af20bda603  vmovaps xmm12, [rsp+0xB0]
000078af20bda60c  vmovaps xmm13, [rsp+0xC0]
000078af20bda615  vmovaps xmm14, [rsp+0xD0]
000078af20bda61e  vmovaps xmm15, [rsp+0xE0]
000078af20bda627  add rsp, 0xF0
000078af20bda62e  pop r11
000078af20bda630  pop r10
000078af20bda632  pop r9
000078af20bda634  pop r8
000078af20bda636  pop rsi
000078af20bda637  pop rdi
000078af20bda638  pop rdx
000078af20bda639  pop rcx
000078af20bda63a  pop rax
000078af20bda63b  add rsp, 0x08
000078af20bda63f  jmp 0x000078AF20BD8E48
000078af20bda644  call 0x000078AF20AE5820
000078af20bda649  jmp 0x000078AF20BD8E55
000078af20bda64e  sub rsp, 0x08
000078af20bda652  push rax
000078af20bda653  push rcx
000078af20bda654  push rdx
000078af20bda655  push rdi
000078af20bda656  push rsi
000078af20bda657  push r8
000078af20bda659  push r9
000078af20bda65b  push r10
000078af20bda65d  push r11
000078af20bda65f  sub rsp, 0xF0
000078af20bda666  vmovaps [rsp], xmm0
000078af20bda66b  vmovaps [rsp+0x10], xmm1
000078af20bda671  vmovaps [rsp+0x20], xmm2
000078af20bda677  vmovaps [rsp+0x30], xmm3
000078af20bda67d  vmovaps [rsp+0x40], xmm4
000078af20bda683  vmovaps [rsp+0x50], xmm5
000078af20bda689  vmovaps [rsp+0x60], xmm6
000078af20bda68f  vmovaps [rsp+0x70], xmm7
000078af20bda695  vmovaps [rsp+0x80], xmm8
000078af20bda69e  vmovaps [rsp+0x90], xmm9
000078af20bda6a7  vmovaps [rsp+0xA0], xmm10
000078af20bda6b0  vmovaps [rsp+0xB0], xmm11
000078af20bda6b9  vmovaps [rsp+0xC0], xmm12
000078af20bda6c2  vmovaps [rsp+0xD0], xmm13
000078af20bda6cb  vmovaps [rsp+0xE0], xmm15
000078af20bda6d4  sub rsp, 0x30
000078af20bda6d8  movaps [rsp], xmm14
000078af20bda6dd  movaps [rsp+0x10], xmm4
000078af20bda6e2  movaps [rsp+0x20], xmm3
000078af20bda6e7  lea rdi, [rsp]
000078af20bda6eb  mov esi, 0x00
000078af20bda6f0  mov rax, 0x65452FFB8530
000078af20bda6fa  call rax
000078af20bda6fc  movaps xmm14, [rsp]
000078af20bda701  add rsp, 0x30
000078af20bda705  vmovaps xmm0, [rsp]
000078af20bda70a  vmovaps xmm1, [rsp+0x10]
000078af20bda710  vmovaps xmm2, [rsp+0x20]
000078af20bda716  vmovaps xmm3, [rsp+0x30]
000078af20bda71c  vmovaps xmm4, [rsp+0x40]
000078af20bda722  vmovaps xmm5, [rsp+0x50]
000078af20bda728  vmovaps xmm6, [rsp+0x60]
000078af20bda72e  vmovaps xmm7, [rsp+0x70]
000078af20bda734  vmovaps xmm8, [rsp+0x80]
000078af20bda73d  vmovaps xmm9, [rsp+0x90]
000078af20bda746  vmovaps xmm10, [rsp+0xA0]
000078af20bda74f  vmovaps xmm11, [rsp+0xB0]
000078af20bda758  vmovaps xmm12, [rsp+0xC0]
000078af20bda761  vmovaps xmm13, [rsp+0xD0]
000078af20bda76a  vmovaps xmm15, [rsp+0xE0]
000078af20bda773  add rsp, 0xF0
000078af20bda77a  pop r11
000078af20bda77c  pop r10
000078af20bda77e  pop r9
000078af20bda780  pop r8
000078af20bda782  pop rsi
000078af20bda783  pop rdi
000078af20bda784  pop rdx
000078af20bda785  pop rcx
000078af20bda786  pop rax
000078af20bda787  add rsp, 0x08
000078af20bda78b  jmp 0x000078AF20BD8E6F
000078af20bda790  sub rsp, 0x08
000078af20bda794  push rax
000078af20bda795  push rcx
000078af20bda796  push rdx
000078af20bda797  push rdi
000078af20bda798  push rsi
000078af20bda799  push r8
000078af20bda79b  push r9
000078af20bda79d  push r10
000078af20bda79f  push r11
000078af20bda7a1  sub rsp, 0xF0
000078af20bda7a8  vmovaps [rsp], xmm0
000078af20bda7ad  vmovaps [rsp+0x10], xmm1
000078af20bda7b3  vmovaps [rsp+0x20], xmm2
000078af20bda7b9  vmovaps [rsp+0x30], xmm3
000078af20bda7bf  vmovaps [rsp+0x40], xmm4
000078af20bda7c5  vmovaps [rsp+0x50], xmm5
000078af20bda7cb  vmovaps [rsp+0x60], xmm7
000078af20bda7d1  vmovaps [rsp+0x70], xmm8
000078af20bda7d7  vmovaps [rsp+0x80], xmm9
000078af20bda7e0  vmovaps [rsp+0x90], xmm10
000078af20bda7e9  vmovaps [rsp+0xA0], xmm11
000078af20bda7f2  vmovaps [rsp+0xB0], xmm12
000078af20bda7fb  vmovaps [rsp+0xC0], xmm13
000078af20bda804  vmovaps [rsp+0xD0], xmm14
000078af20bda80d  vmovaps [rsp+0xE0], xmm15
000078af20bda816  sub rsp, 0x30
000078af20bda81a  movaps [rsp], xmm6
000078af20bda81e  movaps [rsp+0x10], xmm9
000078af20bda824  movaps [rsp+0x20], xmm7
000078af20bda829  lea rdi, [rsp]
000078af20bda82d  mov esi, 0x00
000078af20bda832  mov rax, 0x65452FFB8530
000078af20bda83c  call rax
000078af20bda83e  movaps xmm6, [rsp]
000078af20bda842  add rsp, 0x30
000078af20bda846  vmovaps xmm0, [rsp]
000078af20bda84b  vmovaps xmm1, [rsp+0x10]
000078af20bda851  vmovaps xmm2, [rsp+0x20]
000078af20bda857  vmovaps xmm3, [rsp+0x30]
000078af20bda85d  vmovaps xmm4, [rsp+0x40]
000078af20bda863  vmovaps xmm5, [rsp+0x50]
000078af20bda869  vmovaps xmm7, [rsp+0x60]
000078af20bda86f  vmovaps xmm8, [rsp+0x70]
000078af20bda875  vmovaps xmm9, [rsp+0x80]
000078af20bda87e  vmovaps xmm10, [rsp+0x90]
000078af20bda887  vmovaps xmm11, [rsp+0xA0]
000078af20bda890  vmovaps xmm12, [rsp+0xB0]
000078af20bda899  vmovaps xmm13, [rsp+0xC0]
000078af20bda8a2  vmovaps xmm14, [rsp+0xD0]
000078af20bda8ab  vmovaps xmm15, [rsp+0xE0]
000078af20bda8b4  add rsp, 0xF0
000078af20bda8bb  pop r11
000078af20bda8bd  pop r10
000078af20bda8bf  pop r9
000078af20bda8c1  pop r8
000078af20bda8c3  pop rsi
000078af20bda8c4  pop rdi
000078af20bda8c5  pop rdx
000078af20bda8c6  pop rcx
000078af20bda8c7  pop rax
000078af20bda8c8  add rsp, 0x08
000078af20bda8cc  jmp 0x000078AF20BD8E87
000078af20bda8d1  sub rsp, 0x08
000078af20bda8d5  push rax
000078af20bda8d6  push rcx
000078af20bda8d7  push rdx
000078af20bda8d8  push rdi
000078af20bda8d9  push rsi
000078af20bda8da  push r8
000078af20bda8dc  push r9
000078af20bda8de  push r10
000078af20bda8e0  push r11
000078af20bda8e2  sub rsp, 0xF0
000078af20bda8e9  vmovaps [rsp], xmm0
000078af20bda8ee  vmovaps [rsp+0x10], xmm1
000078af20bda8f4  vmovaps [rsp+0x20], xmm2
000078af20bda8fa  vmovaps [rsp+0x30], xmm3
000078af20bda900  vmovaps [rsp+0x40], xmm4
000078af20bda906  vmovaps [rsp+0x50], xmm5
000078af20bda90c  vmovaps [rsp+0x60], xmm6
000078af20bda912  vmovaps [rsp+0x70], xmm8
000078af20bda918  vmovaps [rsp+0x80], xmm9
000078af20bda921  vmovaps [rsp+0x90], xmm10
000078af20bda92a  vmovaps [rsp+0xA0], xmm11
000078af20bda933  vmovaps [rsp+0xB0], xmm12
000078af20bda93c  vmovaps [rsp+0xC0], xmm13
000078af20bda945  vmovaps [rsp+0xD0], xmm14
000078af20bda94e  vmovaps [rsp+0xE0], xmm15
000078af20bda957  sub rsp, 0x30
000078af20bda95b  movaps [rsp], xmm7
000078af20bda95f  movaps [rsp+0x10], xmm4
000078af20bda964  movaps [rsp+0x20], xmm9
000078af20bda96a  lea rdi, [rsp]
000078af20bda96e  mov esi, 0x00
000078af20bda973  mov rax, 0x65452FFB8530
000078af20bda97d  call rax
000078af20bda97f  movaps xmm7, [rsp]
000078af20bda983  add rsp, 0x30
000078af20bda987  vmovaps xmm0, [rsp]
000078af20bda98c  vmovaps xmm1, [rsp+0x10]
000078af20bda992  vmovaps xmm2, [rsp+0x20]
000078af20bda998  vmovaps xmm3, [rsp+0x30]
000078af20bda99e  vmovaps xmm4, [rsp+0x40]
000078af20bda9a4  vmovaps xmm5, [rsp+0x50]
000078af20bda9aa  vmovaps xmm6, [rsp+0x60]
000078af20bda9b0  vmovaps xmm8, [rsp+0x70]
000078af20bda9b6  vmovaps xmm9, [rsp+0x80]
000078af20bda9bf  vmovaps xmm10, [rsp+0x90]
000078af20bda9c8  vmovaps xmm11, [rsp+0xA0]
000078af20bda9d1  vmovaps xmm12, [rsp+0xB0]
000078af20bda9da  vmovaps xmm13, [rsp+0xC0]
000078af20bda9e3  vmovaps xmm14, [rsp+0xD0]
000078af20bda9ec  vmovaps xmm15, [rsp+0xE0]
000078af20bda9f5  add rsp, 0xF0
000078af20bda9fc  pop r11
000078af20bda9fe  pop r10
000078af20bdaa00  pop r9
000078af20bdaa02  pop r8
000078af20bdaa04  pop rsi
000078af20bdaa05  pop rdi
000078af20bdaa06  pop rdx
000078af20bdaa07  pop rcx
000078af20bdaa08  pop rax
000078af20bdaa09  add rsp, 0x08
000078af20bdaa0d  jmp 0x000078AF20BD8EB4
000078af20bdaa12  sub rsp, 0x08
000078af20bdaa16  push rax
000078af20bdaa17  push rcx
000078af20bdaa18  push rdx
000078af20bdaa19  push rdi
000078af20bdaa1a  push rsi
000078af20bdaa1b  push r8
000078af20bdaa1d  push r9
000078af20bdaa1f  push r10
000078af20bdaa21  push r11
000078af20bdaa23  sub rsp, 0xF0
000078af20bdaa2a  vmovaps [rsp], xmm0
000078af20bdaa2f  vmovaps [rsp+0x10], xmm1
000078af20bdaa35  vmovaps [rsp+0x20], xmm2
000078af20bdaa3b  vmovaps [rsp+0x30], xmm3
000078af20bdaa41  vmovaps [rsp+0x40], xmm5
000078af20bdaa47  vmovaps [rsp+0x50], xmm6
000078af20bdaa4d  vmovaps [rsp+0x60], xmm7
000078af20bdaa53  vmovaps [rsp+0x70], xmm8
000078af20bdaa59  vmovaps [rsp+0x80], xmm9
000078af20bdaa62  vmovaps [rsp+0x90], xmm10
000078af20bdaa6b  vmovaps [rsp+0xA0], xmm11
000078af20bdaa74  vmovaps [rsp+0xB0], xmm12
000078af20bdaa7d  vmovaps [rsp+0xC0], xmm13
000078af20bdaa86  vmovaps [rsp+0xD0], xmm14
000078af20bdaa8f  vmovaps [rsp+0xE0], xmm15
000078af20bdaa98  sub rsp, 0x30
000078af20bdaa9c  movaps [rsp], xmm4
000078af20bdaaa0  movaps [rsp+0x10], xmm15
000078af20bdaaa6  movaps [rsp+0x20], xmm9
000078af20bdaaac  lea rdi, [rsp]
000078af20bdaab0  mov esi, 0x00
000078af20bdaab5  mov rax, 0x65452FFB8530
000078af20bdaabf  call rax
000078af20bdaac1  movaps xmm4, [rsp]
000078af20bdaac5  add rsp, 0x30
000078af20bdaac9  vmovaps xmm0, [rsp]
000078af20bdaace  vmovaps xmm1, [rsp+0x10]
000078af20bdaad4  vmovaps xmm2, [rsp+0x20]
000078af20bdaada  vmovaps xmm3, [rsp+0x30]
000078af20bdaae0  vmovaps xmm5, [rsp+0x40]
000078af20bdaae6  vmovaps xmm6, [rsp+0x50]
000078af20bdaaec  vmovaps xmm7, [rsp+0x60]
000078af20bdaaf2  vmovaps xmm8, [rsp+0x70]
000078af20bdaaf8  vmovaps xmm9, [rsp+0x80]
000078af20bdab01  vmovaps xmm10, [rsp+0x90]
000078af20bdab0a  vmovaps xmm11, [rsp+0xA0]
000078af20bdab13  vmovaps xmm12, [rsp+0xB0]
000078af20bdab1c  vmovaps xmm13, [rsp+0xC0]
000078af20bdab25  vmovaps xmm14, [rsp+0xD0]
000078af20bdab2e  vmovaps xmm15, [rsp+0xE0]
000078af20bdab37  add rsp, 0xF0
000078af20bdab3e  pop r11
000078af20bdab40  pop r10
000078af20bdab42  pop r9
000078af20bdab44  pop r8
000078af20bdab46  pop rsi
000078af20bdab47  pop rdi
000078af20bdab48  pop rdx
000078af20bdab49  pop rcx
000078af20bdab4a  pop rax
000078af20bdab4b  add rsp, 0x08
000078af20bdab4f  jmp 0x000078AF20BD8ED9
000078af20bdab54  call 0x000078AF20AE5820
000078af20bdab59  jmp 0x000078AF20BD8EE6
000078af20bdab5e  sub rsp, 0x08
000078af20bdab62  push rax
000078af20bdab63  push rcx
000078af20bdab64  push rdx
000078af20bdab65  push rdi
000078af20bdab66  push rsi
000078af20bdab67  push r8
000078af20bdab69  push r9
000078af20bdab6b  push r10
000078af20bdab6d  push r11
000078af20bdab6f  sub rsp, 0xF0
000078af20bdab76  vmovaps [rsp], xmm0
000078af20bdab7b  vmovaps [rsp+0x10], xmm1
000078af20bdab81  vmovaps [rsp+0x20], xmm2
000078af20bdab87  vmovaps [rsp+0x30], xmm4
000078af20bdab8d  vmovaps [rsp+0x40], xmm5
000078af20bdab93  vmovaps [rsp+0x50], xmm6
000078af20bdab99  vmovaps [rsp+0x60], xmm7
000078af20bdab9f  vmovaps [rsp+0x70], xmm8
000078af20bdaba5  vmovaps [rsp+0x80], xmm9
000078af20bdabae  vmovaps [rsp+0x90], xmm10
000078af20bdabb7  vmovaps [rsp+0xA0], xmm11
000078af20bdabc0  vmovaps [rsp+0xB0], xmm12
000078af20bdabc9  vmovaps [rsp+0xC0], xmm13
000078af20bdabd2  vmovaps [rsp+0xD0], xmm14
000078af20bdabdb  vmovaps [rsp+0xE0], xmm15
000078af20bdabe4  sub rsp, 0x30
000078af20bdabe8  movaps [rsp], xmm3
000078af20bdabec  movaps [rsp+0x10], xmm1
000078af20bdabf1  movaps [rsp+0x20], xmm9
000078af20bdabf7  lea rdi, [rsp]
000078af20bdabfb  mov esi, 0x00
000078af20bdac00  mov rax, 0x65452FFB8530
000078af20bdac0a  call rax
000078af20bdac0c  movaps xmm3, [rsp]
000078af20bdac10  add rsp, 0x30
000078af20bdac14  vmovaps xmm0, [rsp]
000078af20bdac19  vmovaps xmm1, [rsp+0x10]
000078af20bdac1f  vmovaps xmm2, [rsp+0x20]
000078af20bdac25  vmovaps xmm4, [rsp+0x30]
000078af20bdac2b  vmovaps xmm5, [rsp+0x40]
000078af20bdac31  vmovaps xmm6, [rsp+0x50]
000078af20bdac37  vmovaps xmm7, [rsp+0x60]
000078af20bdac3d  vmovaps xmm8, [rsp+0x70]
000078af20bdac43  vmovaps xmm9, [rsp+0x80]
000078af20bdac4c  vmovaps xmm10, [rsp+0x90]
000078af20bdac55  vmovaps xmm11, [rsp+0xA0]
000078af20bdac5e  vmovaps xmm12, [rsp+0xB0]
000078af20bdac67  vmovaps xmm13, [rsp+0xC0]
000078af20bdac70  vmovaps xmm14, [rsp+0xD0]
000078af20bdac79  vmovaps xmm15, [rsp+0xE0]
000078af20bdac82  add rsp, 0xF0
000078af20bdac89  pop r11
000078af20bdac8b  pop r10
000078af20bdac8d  pop r9
000078af20bdac8f  pop r8
000078af20bdac91  pop rsi
000078af20bdac92  pop rdi
000078af20bdac93  pop rdx
000078af20bdac94  pop rcx
000078af20bdac95  pop rax
000078af20bdac96  add rsp, 0x08
000078af20bdac9a  jmp 0x000078AF20BD8F23
000078af20bdac9f  sub rsp, 0x08
000078af20bdaca3  push rax
000078af20bdaca4  push rcx
000078af20bdaca5  push rdx
000078af20bdaca6  push rdi
000078af20bdaca7  push rsi
000078af20bdaca8  push r8
000078af20bdacaa  push r9
000078af20bdacac  push r10
000078af20bdacae  push r11
000078af20bdacb0  sub rsp, 0xF0
000078af20bdacb7  vmovaps [rsp], xmm0
000078af20bdacbc  vmovaps [rsp+0x10], xmm2
000078af20bdacc2  vmovaps [rsp+0x20], xmm3
000078af20bdacc8  vmovaps [rsp+0x30], xmm4
000078af20bdacce  vmovaps [rsp+0x40], xmm5
000078af20bdacd4  vmovaps [rsp+0x50], xmm6
000078af20bdacda  vmovaps [rsp+0x60], xmm7
000078af20bdace0  vmovaps [rsp+0x70], xmm8
000078af20bdace6  vmovaps [rsp+0x80], xmm9
000078af20bdacef  vmovaps [rsp+0x90], xmm10
000078af20bdacf8  vmovaps [rsp+0xA0], xmm11
000078af20bdad01  vmovaps [rsp+0xB0], xmm12
000078af20bdad0a  vmovaps [rsp+0xC0], xmm13
000078af20bdad13  vmovaps [rsp+0xD0], xmm14
000078af20bdad1c  vmovaps [rsp+0xE0], xmm15
000078af20bdad25  sub rsp, 0x30
000078af20bdad29  movaps [rsp], xmm1
000078af20bdad2d  movaps [rsp+0x10], xmm15
000078af20bdad33  movaps [rsp+0x20], xmm9
000078af20bdad39  lea rdi, [rsp]
000078af20bdad3d  mov esi, 0x00
000078af20bdad42  mov rax, 0x65452FFB8530
000078af20bdad4c  call rax
000078af20bdad4e  movaps xmm1, [rsp]
000078af20bdad52  add rsp, 0x30
000078af20bdad56  vmovaps xmm0, [rsp]
000078af20bdad5b  vmovaps xmm2, [rsp+0x10]
000078af20bdad61  vmovaps xmm3, [rsp+0x20]
000078af20bdad67  vmovaps xmm4, [rsp+0x30]
000078af20bdad6d  vmovaps xmm5, [rsp+0x40]
000078af20bdad73  vmovaps xmm6, [rsp+0x50]
000078af20bdad79  vmovaps xmm7, [rsp+0x60]
000078af20bdad7f  vmovaps xmm8, [rsp+0x70]
000078af20bdad85  vmovaps xmm9, [rsp+0x80]
000078af20bdad8e  vmovaps xmm10, [rsp+0x90]
000078af20bdad97  vmovaps xmm11, [rsp+0xA0]
000078af20bdada0  vmovaps xmm12, [rsp+0xB0]
000078af20bdada9  vmovaps xmm13, [rsp+0xC0]
000078af20bdadb2  vmovaps xmm14, [rsp+0xD0]
000078af20bdadbb  vmovaps xmm15, [rsp+0xE0]
000078af20bdadc4  add rsp, 0xF0
000078af20bdadcb  pop r11
000078af20bdadcd  pop r10
000078af20bdadcf  pop r9
000078af20bdadd1  pop r8
000078af20bdadd3  pop rsi
000078af20bdadd4  pop rdi
000078af20bdadd5  pop rdx
000078af20bdadd6  pop rcx
000078af20bdadd7  pop rax
000078af20bdadd8  add rsp, 0x08
000078af20bdaddc  jmp 0x000078AF20BD8FAB
000078af20bdade1  call 0x000078AF20AE5820
000078af20bdade6  jmp 0x000078AF20BD8FB8
000078af20bdadeb  sub rsp, 0x08
000078af20bdadef  push rax
000078af20bdadf0  push rcx
000078af20bdadf1  push rdx
000078af20bdadf2  push rdi
000078af20bdadf3  push rsi
000078af20bdadf4  push r8
000078af20bdadf6  push r9
000078af20bdadf8  push r10
000078af20bdadfa  push r11
000078af20bdadfc  sub rsp, 0xF0
000078af20bdae03  vmovaps [rsp], xmm0
000078af20bdae08  vmovaps [rsp+0x10], xmm2
000078af20bdae0e  vmovaps [rsp+0x20], xmm3
000078af20bdae14  vmovaps [rsp+0x30], xmm4
000078af20bdae1a  vmovaps [rsp+0x40], xmm5
000078af20bdae20  vmovaps [rsp+0x50], xmm6
000078af20bdae26  vmovaps [rsp+0x60], xmm7
000078af20bdae2c  vmovaps [rsp+0x70], xmm8
000078af20bdae32  vmovaps [rsp+0x80], xmm9
000078af20bdae3b  vmovaps [rsp+0x90], xmm10
000078af20bdae44  vmovaps [rsp+0xA0], xmm11
000078af20bdae4d  vmovaps [rsp+0xB0], xmm12
000078af20bdae56  vmovaps [rsp+0xC0], xmm13
000078af20bdae5f  vmovaps [rsp+0xD0], xmm14
000078af20bdae68  vmovaps [rsp+0xE0], xmm15
000078af20bdae71  sub rsp, 0x30
000078af20bdae75  movaps [rsp], xmm1
000078af20bdae79  movaps [rsp+0x10], xmm5
000078af20bdae7e  movaps [rsp+0x20], xmm7
000078af20bdae83  lea rdi, [rsp]
000078af20bdae87  mov esi, 0x00
000078af20bdae8c  mov rax, 0x65452FFB8530
000078af20bdae96  call rax
000078af20bdae98  movaps xmm1, [rsp]
000078af20bdae9c  add rsp, 0x30
000078af20bdaea0  vmovaps xmm0, [rsp]
000078af20bdaea5  vmovaps xmm2, [rsp+0x10]
000078af20bdaeab  vmovaps xmm3, [rsp+0x20]
000078af20bdaeb1  vmovaps xmm4, [rsp+0x30]
000078af20bdaeb7  vmovaps xmm5, [rsp+0x40]
000078af20bdaebd  vmovaps xmm6, [rsp+0x50]
000078af20bdaec3  vmovaps xmm7, [rsp+0x60]
000078af20bdaec9  vmovaps xmm8, [rsp+0x70]
000078af20bdaecf  vmovaps xmm9, [rsp+0x80]
000078af20bdaed8  vmovaps xmm10, [rsp+0x90]
000078af20bdaee1  vmovaps xmm11, [rsp+0xA0]
000078af20bdaeea  vmovaps xmm12, [rsp+0xB0]
000078af20bdaef3  vmovaps xmm13, [rsp+0xC0]
000078af20bdaefc  vmovaps xmm14, [rsp+0xD0]
000078af20bdaf05  vmovaps xmm15, [rsp+0xE0]
000078af20bdaf0e  add rsp, 0xF0
000078af20bdaf15  pop r11
000078af20bdaf17  pop r10
000078af20bdaf19  pop r9
000078af20bdaf1b  pop r8
000078af20bdaf1d  pop rsi
000078af20bdaf1e  pop rdi
000078af20bdaf1f  pop rdx
000078af20bdaf20  pop rcx
000078af20bdaf21  pop rax
000078af20bdaf22  add rsp, 0x08
000078af20bdaf26  jmp 0x000078AF20BD905D
000078af20bdaf2b  sub rsp, 0x08
000078af20bdaf2f  push rax
000078af20bdaf30  push rcx
000078af20bdaf31  push rdx
000078af20bdaf32  push rdi
000078af20bdaf33  push rsi
000078af20bdaf34  push r8
000078af20bdaf36  push r9
000078af20bdaf38  push r10
000078af20bdaf3a  push r11
000078af20bdaf3c  sub rsp, 0xF0
000078af20bdaf43  vmovaps [rsp], xmm0
000078af20bdaf48  vmovaps [rsp+0x10], xmm1
000078af20bdaf4e  vmovaps [rsp+0x20], xmm2
000078af20bdaf54  vmovaps [rsp+0x30], xmm3
000078af20bdaf5a  vmovaps [rsp+0x40], xmm4
000078af20bdaf60  vmovaps [rsp+0x50], xmm5
000078af20bdaf66  vmovaps [rsp+0x60], xmm6
000078af20bdaf6c  vmovaps [rsp+0x70], xmm8
000078af20bdaf72  vmovaps [rsp+0x80], xmm9
000078af20bdaf7b  vmovaps [rsp+0x90], xmm10
000078af20bdaf84  vmovaps [rsp+0xA0], xmm11
000078af20bdaf8d  vmovaps [rsp+0xB0], xmm12
000078af20bdaf96  vmovaps [rsp+0xC0], xmm13
000078af20bdaf9f  vmovaps [rsp+0xD0], xmm14
000078af20bdafa8  vmovaps [rsp+0xE0], xmm15
000078af20bdafb1  sub rsp, 0x30
000078af20bdafb5  movaps [rsp], xmm7
000078af20bdafb9  movaps [rsp+0x10], xmm5
000078af20bdafbe  movaps [rsp+0x20], xmm15
000078af20bdafc4  lea rdi, [rsp]
000078af20bdafc8  mov esi, 0x00
000078af20bdafcd  mov rax, 0x65452FFB8530
000078af20bdafd7  call rax
000078af20bdafd9  movaps xmm7, [rsp]
000078af20bdafdd  add rsp, 0x30
000078af20bdafe1  vmovaps xmm0, [rsp]
000078af20bdafe6  vmovaps xmm1, [rsp+0x10]
000078af20bdafec  vmovaps xmm2, [rsp+0x20]
000078af20bdaff2  vmovaps xmm3, [rsp+0x30]
000078af20bdaff8  vmovaps xmm4, [rsp+0x40]
000078af20bdaffe  vmovaps xmm5, [rsp+0x50]
000078af20bdb004  vmovaps xmm6, [rsp+0x60]
000078af20bdb00a  vmovaps xmm8, [rsp+0x70]
000078af20bdb010  vmovaps xmm9, [rsp+0x80]
000078af20bdb019  vmovaps xmm10, [rsp+0x90]
000078af20bdb022  vmovaps xmm11, [rsp+0xA0]
000078af20bdb02b  vmovaps xmm12, [rsp+0xB0]
000078af20bdb034  vmovaps xmm13, [rsp+0xC0]
000078af20bdb03d  vmovaps xmm14, [rsp+0xD0]
000078af20bdb046  vmovaps xmm15, [rsp+0xE0]
000078af20bdb04f  add rsp, 0xF0
000078af20bdb056  pop r11
000078af20bdb058  pop r10
000078af20bdb05a  pop r9
000078af20bdb05c  pop r8
000078af20bdb05e  pop rsi
000078af20bdb05f  pop rdi
000078af20bdb060  pop rdx
000078af20bdb061  pop rcx
000078af20bdb062  pop rax
000078af20bdb063  add rsp, 0x08
000078af20bdb067  jmp 0x000078AF20BD9093
000078af20bdb06c  call 0x000078AF20AD64F0
000078af20bdb071  jmp 0x000078AF20BD90A0
000078af20bdb076  sub rsp, 0x08
000078af20bdb07a  push rax
000078af20bdb07b  push rcx
000078af20bdb07c  push rdx
000078af20bdb07d  push rdi
000078af20bdb07e  push rsi
000078af20bdb07f  push r8
000078af20bdb081  push r9
000078af20bdb083  push r10
000078af20bdb085  push r11
000078af20bdb087  sub rsp, 0xF0
000078af20bdb08e  vmovaps [rsp], xmm0
000078af20bdb093  vmovaps [rsp+0x10], xmm1
000078af20bdb099  vmovaps [rsp+0x20], xmm2
000078af20bdb09f  vmovaps [rsp+0x30], xmm3
000078af20bdb0a5  vmovaps [rsp+0x40], xmm4
000078af20bdb0ab  vmovaps [rsp+0x50], xmm5
000078af20bdb0b1  vmovaps [rsp+0x60], xmm6
000078af20bdb0b7  vmovaps [rsp+0x70], xmm7
000078af20bdb0bd  vmovaps [rsp+0x80], xmm8
000078af20bdb0c6  vmovaps [rsp+0x90], xmm9
000078af20bdb0cf  vmovaps [rsp+0xA0], xmm10
000078af20bdb0d8  vmovaps [rsp+0xB0], xmm11
000078af20bdb0e1  vmovaps [rsp+0xC0], xmm12
000078af20bdb0ea  vmovaps [rsp+0xD0], xmm13
000078af20bdb0f3  vmovaps [rsp+0xE0], xmm14
000078af20bdb0fc  sub rsp, 0x30
000078af20bdb100  movaps [rsp], xmm15
000078af20bdb105  movaps [rsp+0x10], xmm5
000078af20bdb10a  movaps [rsp+0x20], xmm3
000078af20bdb10f  lea rdi, [rsp]
000078af20bdb113  mov esi, 0x00
000078af20bdb118  mov rax, 0x65452FFB8530
000078af20bdb122  call rax
000078af20bdb124  movaps xmm15, [rsp]
000078af20bdb129  add rsp, 0x30
000078af20bdb12d  vmovaps xmm0, [rsp]
000078af20bdb132  vmovaps xmm1, [rsp+0x10]
000078af20bdb138  vmovaps xmm2, [rsp+0x20]
000078af20bdb13e  vmovaps xmm3, [rsp+0x30]
000078af20bdb144  vmovaps xmm4, [rsp+0x40]
000078af20bdb14a  vmovaps xmm5, [rsp+0x50]
000078af20bdb150  vmovaps xmm6, [rsp+0x60]
000078af20bdb156  vmovaps xmm7, [rsp+0x70]
000078af20bdb15c  vmovaps xmm8, [rsp+0x80]
000078af20bdb165  vmovaps xmm9, [rsp+0x90]
000078af20bdb16e  vmovaps xmm10, [rsp+0xA0]
000078af20bdb177  vmovaps xmm11, [rsp+0xB0]
000078af20bdb180  vmovaps xmm12, [rsp+0xC0]
000078af20bdb189  vmovaps xmm13, [rsp+0xD0]
000078af20bdb192  vmovaps xmm14, [rsp+0xE0]
000078af20bdb19b  add rsp, 0xF0
000078af20bdb1a2  pop r11
000078af20bdb1a4  pop r10
000078af20bdb1a6  pop r9
000078af20bdb1a8  pop r8
000078af20bdb1aa  pop rsi
000078af20bdb1ab  pop rdi
000078af20bdb1ac  pop rdx
000078af20bdb1ad  pop rcx
000078af20bdb1ae  pop rax
000078af20bdb1af  add rsp, 0x08
000078af20bdb1b3  jmp 0x000078AF20BD90C6
000078af20bdb1b8  sub rsp, 0x08
000078af20bdb1bc  push rax
000078af20bdb1bd  push rcx
000078af20bdb1be  push rdx
000078af20bdb1bf  push rdi
000078af20bdb1c0  push rsi
000078af20bdb1c1  push r8
000078af20bdb1c3  push r9
000078af20bdb1c5  push r10
000078af20bdb1c7  push r11
000078af20bdb1c9  sub rsp, 0xF0
000078af20bdb1d0  vmovaps [rsp], xmm0
000078af20bdb1d5  vmovaps [rsp+0x10], xmm2
000078af20bdb1db  vmovaps [rsp+0x20], xmm3
000078af20bdb1e1  vmovaps [rsp+0x30], xmm4
000078af20bdb1e7  vmovaps [rsp+0x40], xmm5
000078af20bdb1ed  vmovaps [rsp+0x50], xmm6
000078af20bdb1f3  vmovaps [rsp+0x60], xmm7
000078af20bdb1f9  vmovaps [rsp+0x70], xmm8
000078af20bdb1ff  vmovaps [rsp+0x80], xmm9
000078af20bdb208  vmovaps [rsp+0x90], xmm10
000078af20bdb211  vmovaps [rsp+0xA0], xmm11
000078af20bdb21a  vmovaps [rsp+0xB0], xmm12
000078af20bdb223  vmovaps [rsp+0xC0], xmm13
000078af20bdb22c  vmovaps [rsp+0xD0], xmm14
000078af20bdb235  vmovaps [rsp+0xE0], xmm15
000078af20bdb23e  sub rsp, 0x30
000078af20bdb242  movaps [rsp], xmm1
000078af20bdb246  movaps [rsp+0x10], xmm5
000078af20bdb24b  movaps [rsp+0x20], xmm4
000078af20bdb250  lea rdi, [rsp]
000078af20bdb254  mov esi, 0x00
000078af20bdb259  mov rax, 0x65452FFB8530
000078af20bdb263  call rax
000078af20bdb265  movaps xmm1, [rsp]
000078af20bdb269  add rsp, 0x30
000078af20bdb26d  vmovaps xmm0, [rsp]
000078af20bdb272  vmovaps xmm2, [rsp+0x10]
000078af20bdb278  vmovaps xmm3, [rsp+0x20]
000078af20bdb27e  vmovaps xmm4, [rsp+0x30]
000078af20bdb284  vmovaps xmm5, [rsp+0x40]
000078af20bdb28a  vmovaps xmm6, [rsp+0x50]
000078af20bdb290  vmovaps xmm7, [rsp+0x60]
000078af20bdb296  vmovaps xmm8, [rsp+0x70]
000078af20bdb29c  vmovaps xmm9, [rsp+0x80]
000078af20bdb2a5  vmovaps xmm10, [rsp+0x90]
000078af20bdb2ae  vmovaps xmm11, [rsp+0xA0]
000078af20bdb2b7  vmovaps xmm12, [rsp+0xB0]
000078af20bdb2c0  vmovaps xmm13, [rsp+0xC0]
000078af20bdb2c9  vmovaps xmm14, [rsp+0xD0]
000078af20bdb2d2  vmovaps xmm15, [rsp+0xE0]
000078af20bdb2db  add rsp, 0xF0
000078af20bdb2e2  pop r11
000078af20bdb2e4  pop r10
000078af20bdb2e6  pop r9
000078af20bdb2e8  pop r8
000078af20bdb2ea  pop rsi
000078af20bdb2eb  pop rdi
000078af20bdb2ec  pop rdx
000078af20bdb2ed  pop rcx
000078af20bdb2ee  pop rax
000078af20bdb2ef  add rsp, 0x08
000078af20bdb2f3  jmp 0x000078AF20BD90E6
000078af20bdb2f8  sub rsp, 0x08
000078af20bdb2fc  push rax
000078af20bdb2fd  push rcx
000078af20bdb2fe  push rdx
000078af20bdb2ff  push rdi
000078af20bdb300  push rsi
000078af20bdb301  push r8
000078af20bdb303  push r9
000078af20bdb305  push r10
000078af20bdb307  push r11
000078af20bdb309  sub rsp, 0xF0
000078af20bdb310  vmovaps [rsp], xmm0
000078af20bdb315  vmovaps [rsp+0x10], xmm1
000078af20bdb31b  vmovaps [rsp+0x20], xmm2
000078af20bdb321  vmovaps [rsp+0x30], xmm3
000078af20bdb327  vmovaps [rsp+0x40], xmm5
000078af20bdb32d  vmovaps [rsp+0x50], xmm6
000078af20bdb333  vmovaps [rsp+0x60], xmm7
000078af20bdb339  vmovaps [rsp+0x70], xmm8
000078af20bdb33f  vmovaps [rsp+0x80], xmm9
000078af20bdb348  vmovaps [rsp+0x90], xmm10
000078af20bdb351  vmovaps [rsp+0xA0], xmm11
000078af20bdb35a  vmovaps [rsp+0xB0], xmm12
000078af20bdb363  vmovaps [rsp+0xC0], xmm13
000078af20bdb36c  vmovaps [rsp+0xD0], xmm14
000078af20bdb375  vmovaps [rsp+0xE0], xmm15
000078af20bdb37e  sub rsp, 0x30
000078af20bdb382  movaps [rsp], xmm4
000078af20bdb386  movaps [rsp+0x10], xmm3
000078af20bdb38b  movaps [rsp+0x20], xmm5
000078af20bdb390  lea rdi, [rsp]
000078af20bdb394  mov esi, 0x00
000078af20bdb399  mov rax, 0x65452FFB8530
000078af20bdb3a3  call rax
000078af20bdb3a5  movaps xmm4, [rsp]
000078af20bdb3a9  add rsp, 0x30
000078af20bdb3ad  vmovaps xmm0, [rsp]
000078af20bdb3b2  vmovaps xmm1, [rsp+0x10]
000078af20bdb3b8  vmovaps xmm2, [rsp+0x20]
000078af20bdb3be  vmovaps xmm3, [rsp+0x30]
000078af20bdb3c4  vmovaps xmm5, [rsp+0x40]
000078af20bdb3ca  vmovaps xmm6, [rsp+0x50]
000078af20bdb3d0  vmovaps xmm7, [rsp+0x60]
000078af20bdb3d6  vmovaps xmm8, [rsp+0x70]
000078af20bdb3dc  vmovaps xmm9, [rsp+0x80]
000078af20bdb3e5  vmovaps xmm10, [rsp+0x90]
000078af20bdb3ee  vmovaps xmm11, [rsp+0xA0]
000078af20bdb3f7  vmovaps xmm12, [rsp+0xB0]
000078af20bdb400  vmovaps xmm13, [rsp+0xC0]
000078af20bdb409  vmovaps xmm14, [rsp+0xD0]
000078af20bdb412  vmovaps xmm15, [rsp+0xE0]
000078af20bdb41b  add rsp, 0xF0
000078af20bdb422  pop r11
000078af20bdb424  pop r10
000078af20bdb426  pop r9
000078af20bdb428  pop r8
000078af20bdb42a  pop rsi
000078af20bdb42b  pop rdi
000078af20bdb42c  pop rdx
000078af20bdb42d  pop rcx
000078af20bdb42e  pop rax
000078af20bdb42f  add rsp, 0x08
000078af20bdb433  jmp 0x000078AF20BD9134
000078af20bdb438  call 0x000078AF20AD64F0
000078af20bdb43d  jmp 0x000078AF20BD9141
000078af20bdb442  sub rsp, 0x08
000078af20bdb446  push rax
000078af20bdb447  push rcx
000078af20bdb448  push rdx
000078af20bdb449  push rdi
000078af20bdb44a  push rsi
000078af20bdb44b  push r8
000078af20bdb44d  push r9
000078af20bdb44f  push r10
000078af20bdb451  push r11
000078af20bdb453  sub rsp, 0xF0
000078af20bdb45a  vmovaps [rsp], xmm0
000078af20bdb45f  vmovaps [rsp+0x10], xmm1
000078af20bdb465  vmovaps [rsp+0x20], xmm2
000078af20bdb46b  vmovaps [rsp+0x30], xmm3
000078af20bdb471  vmovaps [rsp+0x40], xmm4
000078af20bdb477  vmovaps [rsp+0x50], xmm6
000078af20bdb47d  vmovaps [rsp+0x60], xmm7
000078af20bdb483  vmovaps [rsp+0x70], xmm8
000078af20bdb489  vmovaps [rsp+0x80], xmm9
000078af20bdb492  vmovaps [rsp+0x90], xmm10
000078af20bdb49b  vmovaps [rsp+0xA0], xmm11
000078af20bdb4a4  vmovaps [rsp+0xB0], xmm12
000078af20bdb4ad  vmovaps [rsp+0xC0], xmm13
000078af20bdb4b6  vmovaps [rsp+0xD0], xmm14
000078af20bdb4bf  vmovaps [rsp+0xE0], xmm15
000078af20bdb4c8  sub rsp, 0x30
000078af20bdb4cc  movaps [rsp], xmm5
000078af20bdb4d0  movaps [rsp+0x10], xmm6
000078af20bdb4d5  movaps [rsp+0x20], xmm3
000078af20bdb4da  lea rdi, [rsp]
000078af20bdb4de  mov esi, 0x00
000078af20bdb4e3  mov rax, 0x65452FFB8530
000078af20bdb4ed  call rax
000078af20bdb4ef  movaps xmm5, [rsp]
000078af20bdb4f3  add rsp, 0x30
000078af20bdb4f7  vmovaps xmm0, [rsp]
000078af20bdb4fc  vmovaps xmm1, [rsp+0x10]
000078af20bdb502  vmovaps xmm2, [rsp+0x20]
000078af20bdb508  vmovaps xmm3, [rsp+0x30]
000078af20bdb50e  vmovaps xmm4, [rsp+0x40]
000078af20bdb514  vmovaps xmm6, [rsp+0x50]
000078af20bdb51a  vmovaps xmm7, [rsp+0x60]
000078af20bdb520  vmovaps xmm8, [rsp+0x70]
000078af20bdb526  vmovaps xmm9, [rsp+0x80]
000078af20bdb52f  vmovaps xmm10, [rsp+0x90]
000078af20bdb538  vmovaps xmm11, [rsp+0xA0]
000078af20bdb541  vmovaps xmm12, [rsp+0xB0]
000078af20bdb54a  vmovaps xmm13, [rsp+0xC0]
000078af20bdb553  vmovaps xmm14, [rsp+0xD0]
000078af20bdb55c  vmovaps xmm15, [rsp+0xE0]
000078af20bdb565  add rsp, 0xF0
000078af20bdb56c  pop r11
000078af20bdb56e  pop r10
000078af20bdb570  pop r9
000078af20bdb572  pop r8
000078af20bdb574  pop rsi
000078af20bdb575  pop rdi
000078af20bdb576  pop rdx
000078af20bdb577  pop rcx
000078af20bdb578  pop rax
000078af20bdb579  add rsp, 0x08
000078af20bdb57d  jmp 0x000078AF20BD9167
000078af20bdb582  sub rsp, 0x08
000078af20bdb586  push rax
000078af20bdb587  push rcx
000078af20bdb588  push rdx
000078af20bdb589  push rdi
000078af20bdb58a  push rsi
000078af20bdb58b  push r8
000078af20bdb58d  push r9
000078af20bdb58f  push r10
000078af20bdb591  push r11
000078af20bdb593  sub rsp, 0xF0
000078af20bdb59a  vmovaps [rsp], xmm0
000078af20bdb59f  vmovaps [rsp+0x10], xmm1
000078af20bdb5a5  vmovaps [rsp+0x20], xmm2
000078af20bdb5ab  vmovaps [rsp+0x30], xmm3
000078af20bdb5b1  vmovaps [rsp+0x40], xmm4
000078af20bdb5b7  vmovaps [rsp+0x50], xmm5
000078af20bdb5bd  vmovaps [rsp+0x60], xmm7
000078af20bdb5c3  vmovaps [rsp+0x70], xmm8
000078af20bdb5c9  vmovaps [rsp+0x80], xmm9
000078af20bdb5d2  vmovaps [rsp+0x90], xmm10
000078af20bdb5db  vmovaps [rsp+0xA0], xmm11
000078af20bdb5e4  vmovaps [rsp+0xB0], xmm12
000078af20bdb5ed  vmovaps [rsp+0xC0], xmm13
000078af20bdb5f6  vmovaps [rsp+0xD0], xmm14
000078af20bdb5ff  vmovaps [rsp+0xE0], xmm15
000078af20bdb608  sub rsp, 0x30
000078af20bdb60c  movaps [rsp], xmm6
000078af20bdb610  movaps [rsp+0x10], xmm9
000078af20bdb616  movaps [rsp+0x20], xmm1
000078af20bdb61b  lea rdi, [rsp]
000078af20bdb61f  mov esi, 0x00
000078af20bdb624  mov rax, 0x65452FFB8530
000078af20bdb62e  call rax
000078af20bdb630  movaps xmm6, [rsp]
000078af20bdb634  add rsp, 0x30
000078af20bdb638  vmovaps xmm0, [rsp]
000078af20bdb63d  vmovaps xmm1, [rsp+0x10]
000078af20bdb643  vmovaps xmm2, [rsp+0x20]
000078af20bdb649  vmovaps xmm3, [rsp+0x30]
000078af20bdb64f  vmovaps xmm4, [rsp+0x40]
000078af20bdb655  vmovaps xmm5, [rsp+0x50]
000078af20bdb65b  vmovaps xmm7, [rsp+0x60]
000078af20bdb661  vmovaps xmm8, [rsp+0x70]
000078af20bdb667  vmovaps xmm9, [rsp+0x80]
000078af20bdb670  vmovaps xmm10, [rsp+0x90]
000078af20bdb679  vmovaps xmm11, [rsp+0xA0]
000078af20bdb682  vmovaps xmm12, [rsp+0xB0]
000078af20bdb68b  vmovaps xmm13, [rsp+0xC0]
000078af20bdb694  vmovaps xmm14, [rsp+0xD0]
000078af20bdb69d  vmovaps xmm15, [rsp+0xE0]
000078af20bdb6a6  add rsp, 0xF0
000078af20bdb6ad  pop r11
000078af20bdb6af  pop r10
000078af20bdb6b1  pop r9
000078af20bdb6b3  pop r8
000078af20bdb6b5  pop rsi
000078af20bdb6b6  pop rdi
000078af20bdb6b7  pop rdx
000078af20bdb6b8  pop rcx
000078af20bdb6b9  pop rax
000078af20bdb6ba  add rsp, 0x08
000078af20bdb6be  jmp 0x000078AF20BD918B
000078af20bdb6c3  sub rsp, 0x08
000078af20bdb6c7  push rax
000078af20bdb6c8  push rcx
000078af20bdb6c9  push rdx
000078af20bdb6ca  push rdi
000078af20bdb6cb  push rsi
000078af20bdb6cc  push r8
000078af20bdb6ce  push r9
000078af20bdb6d0  push r10
000078af20bdb6d2  push r11
000078af20bdb6d4  sub rsp, 0xF0
000078af20bdb6db  vmovaps [rsp], xmm0
000078af20bdb6e0  vmovaps [rsp+0x10], xmm1
000078af20bdb6e6  vmovaps [rsp+0x20], xmm2
000078af20bdb6ec  vmovaps [rsp+0x30], xmm3
000078af20bdb6f2  vmovaps [rsp+0x40], xmm4
000078af20bdb6f8  vmovaps [rsp+0x50], xmm5
000078af20bdb6fe  vmovaps [rsp+0x60], xmm6
000078af20bdb704  vmovaps [rsp+0x70], xmm7
000078af20bdb70a  vmovaps [rsp+0x80], xmm8
000078af20bdb713  vmovaps [rsp+0x90], xmm10
000078af20bdb71c  vmovaps [rsp+0xA0], xmm11
000078af20bdb725  vmovaps [rsp+0xB0], xmm12
000078af20bdb72e  vmovaps [rsp+0xC0], xmm13
000078af20bdb737  vmovaps [rsp+0xD0], xmm14
000078af20bdb740  vmovaps [rsp+0xE0], xmm15
000078af20bdb749  sub rsp, 0x30
000078af20bdb74d  movaps [rsp], xmm9
000078af20bdb752  movaps [rsp+0x10], xmm3
000078af20bdb757  movaps [rsp+0x20], xmm1
000078af20bdb75c  lea rdi, [rsp]
000078af20bdb760  mov esi, 0x00
000078af20bdb765  mov rax, 0x65452FFB8530
000078af20bdb76f  call rax
000078af20bdb771  movaps xmm9, [rsp]
000078af20bdb776  add rsp, 0x30
000078af20bdb77a  vmovaps xmm0, [rsp]
000078af20bdb77f  vmovaps xmm1, [rsp+0x10]
000078af20bdb785  vmovaps xmm2, [rsp+0x20]
000078af20bdb78b  vmovaps xmm3, [rsp+0x30]
000078af20bdb791  vmovaps xmm4, [rsp+0x40]
000078af20bdb797  vmovaps xmm5, [rsp+0x50]
000078af20bdb79d  vmovaps xmm6, [rsp+0x60]
000078af20bdb7a3  vmovaps xmm7, [rsp+0x70]
000078af20bdb7a9  vmovaps xmm8, [rsp+0x80]
000078af20bdb7b2  vmovaps xmm10, [rsp+0x90]
000078af20bdb7bb  vmovaps xmm11, [rsp+0xA0]
000078af20bdb7c4  vmovaps xmm12, [rsp+0xB0]
000078af20bdb7cd  vmovaps xmm13, [rsp+0xC0]
000078af20bdb7d6  vmovaps xmm14, [rsp+0xD0]
000078af20bdb7df  vmovaps xmm15, [rsp+0xE0]
000078af20bdb7e8  add rsp, 0xF0
000078af20bdb7ef  pop r11
000078af20bdb7f1  pop r10
000078af20bdb7f3  pop r9
000078af20bdb7f5  pop r8
000078af20bdb7f7  pop rsi
000078af20bdb7f8  pop rdi
000078af20bdb7f9  pop rdx
000078af20bdb7fa  pop rcx
000078af20bdb7fb  pop rax
000078af20bdb7fc  add rsp, 0x08
000078af20bdb800  jmp 0x000078AF20BD91D7
000078af20bdb805  call 0x000078AF20AD64F0
000078af20bdb80a  jmp 0x000078AF20BD91E4
000078af20bdb80f  sub rsp, 0x08
000078af20bdb813  push rax
000078af20bdb814  push rcx
000078af20bdb815  push rdx
000078af20bdb816  push rdi
000078af20bdb817  push rsi
000078af20bdb818  push r8
000078af20bdb81a  push r9
000078af20bdb81c  push r10
000078af20bdb81e  push r11
000078af20bdb820  sub rsp, 0xF0
000078af20bdb827  vmovaps [rsp], xmm0
000078af20bdb82c  vmovaps [rsp+0x10], xmm1
000078af20bdb832  vmovaps [rsp+0x20], xmm2
000078af20bdb838  vmovaps [rsp+0x30], xmm3
000078af20bdb83e  vmovaps [rsp+0x40], xmm4
000078af20bdb844  vmovaps [rsp+0x50], xmm5
000078af20bdb84a  vmovaps [rsp+0x60], xmm6
000078af20bdb850  vmovaps [rsp+0x70], xmm7
000078af20bdb856  vmovaps [rsp+0x80], xmm8
000078af20bdb85f  vmovaps [rsp+0x90], xmm9
000078af20bdb868  vmovaps [rsp+0xA0], xmm10
000078af20bdb871  vmovaps [rsp+0xB0], xmm11
000078af20bdb87a  vmovaps [rsp+0xC0], xmm12
000078af20bdb883  vmovaps [rsp+0xD0], xmm13
000078af20bdb88c  vmovaps [rsp+0xE0], xmm14
000078af20bdb895  sub rsp, 0x30
000078af20bdb899  movaps [rsp], xmm15
000078af20bdb89e  movaps [rsp+0x10], xmm3
000078af20bdb8a3  movaps [rsp+0x20], xmm7
000078af20bdb8a8  lea rdi, [rsp]
000078af20bdb8ac  mov esi, 0x00
000078af20bdb8b1  mov rax, 0x65452FFB8530
000078af20bdb8bb  call rax
000078af20bdb8bd  movaps xmm15, [rsp]
000078af20bdb8c2  add rsp, 0x30
000078af20bdb8c6  vmovaps xmm0, [rsp]
000078af20bdb8cb  vmovaps xmm1, [rsp+0x10]
000078af20bdb8d1  vmovaps xmm2, [rsp+0x20]
000078af20bdb8d7  vmovaps xmm3, [rsp+0x30]
000078af20bdb8dd  vmovaps xmm4, [rsp+0x40]
000078af20bdb8e3  vmovaps xmm5, [rsp+0x50]
000078af20bdb8e9  vmovaps xmm6, [rsp+0x60]
000078af20bdb8ef  vmovaps xmm7, [rsp+0x70]
000078af20bdb8f5  vmovaps xmm8, [rsp+0x80]
000078af20bdb8fe  vmovaps xmm9, [rsp+0x90]
000078af20bdb907  vmovaps xmm10, [rsp+0xA0]
000078af20bdb910  vmovaps xmm11, [rsp+0xB0]
000078af20bdb919  vmovaps xmm12, [rsp+0xC0]
000078af20bdb922  vmovaps xmm13, [rsp+0xD0]
000078af20bdb92b  vmovaps xmm14, [rsp+0xE0]
000078af20bdb934  add rsp, 0xF0
000078af20bdb93b  pop r11
000078af20bdb93d  pop r10
000078af20bdb93f  pop r9
000078af20bdb941  pop r8
000078af20bdb943  pop rsi
000078af20bdb944  pop rdi
000078af20bdb945  pop rdx
000078af20bdb946  pop rcx
000078af20bdb947  pop rax
000078af20bdb948  add rsp, 0x08
000078af20bdb94c  jmp 0x000078AF20BD9210
000078af20bdb951  sub rsp, 0x08
000078af20bdb955  push rax
000078af20bdb956  push rcx
000078af20bdb957  push rdx
000078af20bdb958  push rdi
000078af20bdb959  push rsi
000078af20bdb95a  push r8
000078af20bdb95c  push r9
000078af20bdb95e  push r10
000078af20bdb960  push r11
000078af20bdb962  sub rsp, 0xF0
000078af20bdb969  vmovaps [rsp], xmm0
000078af20bdb96e  vmovaps [rsp+0x10], xmm1
000078af20bdb974  vmovaps [rsp+0x20], xmm2
000078af20bdb97a  vmovaps [rsp+0x30], xmm4
000078af20bdb980  vmovaps [rsp+0x40], xmm5
000078af20bdb986  vmovaps [rsp+0x50], xmm6
000078af20bdb98c  vmovaps [rsp+0x60], xmm7
000078af20bdb992  vmovaps [rsp+0x70], xmm8
000078af20bdb998  vmovaps [rsp+0x80], xmm9
000078af20bdb9a1  vmovaps [rsp+0x90], xmm10
000078af20bdb9aa  vmovaps [rsp+0xA0], xmm11
000078af20bdb9b3  vmovaps [rsp+0xB0], xmm12
000078af20bdb9bc  vmovaps [rsp+0xC0], xmm13
000078af20bdb9c5  vmovaps [rsp+0xD0], xmm14
000078af20bdb9ce  vmovaps [rsp+0xE0], xmm15
000078af20bdb9d7  sub rsp, 0x30
000078af20bdb9db  movaps [rsp], xmm3
000078af20bdb9df  movaps [rsp+0x10], xmm1
000078af20bdb9e4  movaps [rsp+0x20], xmm15
000078af20bdb9ea  lea rdi, [rsp]
000078af20bdb9ee  mov esi, 0x00
000078af20bdb9f3  mov rax, 0x65452FFB8530
000078af20bdb9fd  call rax
000078af20bdb9ff  movaps xmm3, [rsp]
000078af20bdba03  add rsp, 0x30
000078af20bdba07  vmovaps xmm0, [rsp]
000078af20bdba0c  vmovaps xmm1, [rsp+0x10]
000078af20bdba12  vmovaps xmm2, [rsp+0x20]
000078af20bdba18  vmovaps xmm4, [rsp+0x30]
000078af20bdba1e  vmovaps xmm5, [rsp+0x40]
000078af20bdba24  vmovaps xmm6, [rsp+0x50]
000078af20bdba2a  vmovaps xmm7, [rsp+0x60]
000078af20bdba30  vmovaps xmm8, [rsp+0x70]
000078af20bdba36  vmovaps xmm9, [rsp+0x80]
000078af20bdba3f  vmovaps xmm10, [rsp+0x90]
000078af20bdba48  vmovaps xmm11, [rsp+0xA0]
000078af20bdba51  vmovaps xmm12, [rsp+0xB0]
000078af20bdba5a  vmovaps xmm13, [rsp+0xC0]
000078af20bdba63  vmovaps xmm14, [rsp+0xD0]
000078af20bdba6c  vmovaps xmm15, [rsp+0xE0]
000078af20bdba75  add rsp, 0xF0
000078af20bdba7c  pop r11
000078af20bdba7e  pop r10
000078af20bdba80  pop r9
000078af20bdba82  pop r8
000078af20bdba84  pop rsi
000078af20bdba85  pop rdi
000078af20bdba86  pop rdx
000078af20bdba87  pop rcx
000078af20bdba88  pop rax
000078af20bdba89  add rsp, 0x08
000078af20bdba8d  jmp 0x000078AF20BD929F
000078af20bdba92  call 0x000078AF20AD64F0
000078af20bdba97  jmp 0x000078AF20BD92A9
000078af20bdba9c  sub rsp, 0x08
000078af20bdbaa0  push rax
000078af20bdbaa1  push rcx
000078af20bdbaa2  push rdx
000078af20bdbaa3  push rdi
000078af20bdbaa4  push rsi
000078af20bdbaa5  push r8
000078af20bdbaa7  push r9
000078af20bdbaa9  push r10
000078af20bdbaab  push r11
000078af20bdbaad  sub rsp, 0xF0
000078af20bdbab4  vmovaps [rsp], xmm0
000078af20bdbab9  vmovaps [rsp+0x10], xmm1
000078af20bdbabf  vmovaps [rsp+0x20], xmm2
000078af20bdbac5  vmovaps [rsp+0x30], xmm3
000078af20bdbacb  vmovaps [rsp+0x40], xmm4
000078af20bdbad1  vmovaps [rsp+0x50], xmm5
000078af20bdbad7  vmovaps [rsp+0x60], xmm6
000078af20bdbadd  vmovaps [rsp+0x70], xmm7
000078af20bdbae3  vmovaps [rsp+0x80], xmm8
000078af20bdbaec  vmovaps [rsp+0x90], xmm9
000078af20bdbaf5  vmovaps [rsp+0xA0], xmm10
000078af20bdbafe  vmovaps [rsp+0xB0], xmm11
000078af20bdbb07  vmovaps [rsp+0xC0], xmm12
000078af20bdbb10  vmovaps [rsp+0xD0], xmm13
000078af20bdbb19  vmovaps [rsp+0xE0], xmm14
000078af20bdbb22  sub rsp, 0x30
000078af20bdbb26  movaps [rsp], xmm15
000078af20bdbb2b  movaps [rsp+0x10], xmm14
000078af20bdbb31  movaps [rsp+0x20], xmm4
000078af20bdbb36  lea rdi, [rsp]
000078af20bdbb3a  mov esi, 0x00
000078af20bdbb3f  mov rax, 0x65452FFB8530
000078af20bdbb49  call rax
000078af20bdbb4b  movaps xmm15, [rsp]
000078af20bdbb50  add rsp, 0x30
000078af20bdbb54  vmovaps xmm0, [rsp]
000078af20bdbb59  vmovaps xmm1, [rsp+0x10]
000078af20bdbb5f  vmovaps xmm2, [rsp+0x20]
000078af20bdbb65  vmovaps xmm3, [rsp+0x30]
000078af20bdbb6b  vmovaps xmm4, [rsp+0x40]
000078af20bdbb71  vmovaps xmm5, [rsp+0x50]
000078af20bdbb77  vmovaps xmm6, [rsp+0x60]
000078af20bdbb7d  vmovaps xmm7, [rsp+0x70]
000078af20bdbb83  vmovaps xmm8, [rsp+0x80]
000078af20bdbb8c  vmovaps xmm9, [rsp+0x90]
000078af20bdbb95  vmovaps xmm10, [rsp+0xA0]
000078af20bdbb9e  vmovaps xmm11, [rsp+0xB0]
000078af20bdbba7  vmovaps xmm12, [rsp+0xC0]
000078af20bdbbb0  vmovaps xmm13, [rsp+0xD0]
000078af20bdbbb9  vmovaps xmm14, [rsp+0xE0]
000078af20bdbbc2  add rsp, 0xF0
000078af20bdbbc9  pop r11
000078af20bdbbcb  pop r10
000078af20bdbbcd  pop r9
000078af20bdbbcf  pop r8
000078af20bdbbd1  pop rsi
000078af20bdbbd2  pop rdi
000078af20bdbbd3  pop rdx
000078af20bdbbd4  pop rcx
000078af20bdbbd5  pop rax
000078af20bdbbd6  add rsp, 0x08
000078af20bdbbda  jmp 0x000078AF20BD92D7
000078af20bdbbdf  sub rsp, 0x08
000078af20bdbbe3  push rax
000078af20bdbbe4  push rcx
000078af20bdbbe5  push rdx
000078af20bdbbe6  push rdi
000078af20bdbbe7  push rsi
000078af20bdbbe8  push r8
000078af20bdbbea  push r9
000078af20bdbbec  push r10
000078af20bdbbee  push r11
000078af20bdbbf0  sub rsp, 0xF0
000078af20bdbbf7  vmovaps [rsp], xmm0
000078af20bdbbfc  vmovaps [rsp+0x10], xmm1
000078af20bdbc02  vmovaps [rsp+0x20], xmm2
000078af20bdbc08  vmovaps [rsp+0x30], xmm3
000078af20bdbc0e  vmovaps [rsp+0x40], xmm4
000078af20bdbc14  vmovaps [rsp+0x50], xmm5
000078af20bdbc1a  vmovaps [rsp+0x60], xmm6
000078af20bdbc20  vmovaps [rsp+0x70], xmm7
000078af20bdbc26  vmovaps [rsp+0x80], xmm8
000078af20bdbc2f  vmovaps [rsp+0x90], xmm9
000078af20bdbc38  vmovaps [rsp+0xA0], xmm10
000078af20bdbc41  vmovaps [rsp+0xB0], xmm11
000078af20bdbc4a  vmovaps [rsp+0xC0], xmm12
000078af20bdbc53  vmovaps [rsp+0xD0], xmm13
000078af20bdbc5c  vmovaps [rsp+0xE0], xmm15
000078af20bdbc65  sub rsp, 0x30
000078af20bdbc69  movaps [rsp], xmm14
000078af20bdbc6e  movaps [rsp+0x10], xmm2
000078af20bdbc73  movaps [rsp+0x20], xmm1
000078af20bdbc78  lea rdi, [rsp]
000078af20bdbc7c  mov esi, 0x00
000078af20bdbc81  mov rax, 0x65452FFB8530
000078af20bdbc8b  call rax
000078af20bdbc8d  movaps xmm14, [rsp]
000078af20bdbc92  add rsp, 0x30
000078af20bdbc96  vmovaps xmm0, [rsp]
000078af20bdbc9b  vmovaps xmm1, [rsp+0x10]
000078af20bdbca1  vmovaps xmm2, [rsp+0x20]
000078af20bdbca7  vmovaps xmm3, [rsp+0x30]
000078af20bdbcad  vmovaps xmm4, [rsp+0x40]
000078af20bdbcb3  vmovaps xmm5, [rsp+0x50]
000078af20bdbcb9  vmovaps xmm6, [rsp+0x60]
000078af20bdbcbf  vmovaps xmm7, [rsp+0x70]
000078af20bdbcc5  vmovaps xmm8, [rsp+0x80]
000078af20bdbcce  vmovaps xmm9, [rsp+0x90]
000078af20bdbcd7  vmovaps xmm10, [rsp+0xA0]
000078af20bdbce0  vmovaps xmm11, [rsp+0xB0]
000078af20bdbce9  vmovaps xmm12, [rsp+0xC0]
000078af20bdbcf2  vmovaps xmm13, [rsp+0xD0]
000078af20bdbcfb  vmovaps xmm15, [rsp+0xE0]
000078af20bdbd04  add rsp, 0xF0
000078af20bdbd0b  pop r11
000078af20bdbd0d  pop r10
000078af20bdbd0f  pop r9
000078af20bdbd11  pop r8
000078af20bdbd13  pop rsi
000078af20bdbd14  pop rdi
000078af20bdbd15  pop rdx
000078af20bdbd16  pop rcx
000078af20bdbd17  pop rax
000078af20bdbd18  add rsp, 0x08
000078af20bdbd1c  jmp 0x000078AF20BD92FD
000078af20bdbd21  sub rsp, 0x08
000078af20bdbd25  push rax
000078af20bdbd26  push rcx
000078af20bdbd27  push rdx
000078af20bdbd28  push rdi
000078af20bdbd29  push rsi
000078af20bdbd2a  push r8
000078af20bdbd2c  push r9
000078af20bdbd2e  push r10
000078af20bdbd30  push r11
000078af20bdbd32  sub rsp, 0xF0
000078af20bdbd39  vmovaps [rsp], xmm0
000078af20bdbd3e  vmovaps [rsp+0x10], xmm2
000078af20bdbd44  vmovaps [rsp+0x20], xmm3
000078af20bdbd4a  vmovaps [rsp+0x30], xmm4
000078af20bdbd50  vmovaps [rsp+0x40], xmm5
000078af20bdbd56  vmovaps [rsp+0x50], xmm6
000078af20bdbd5c  vmovaps [rsp+0x60], xmm7
000078af20bdbd62  vmovaps [rsp+0x70], xmm8
000078af20bdbd68  vmovaps [rsp+0x80], xmm9
000078af20bdbd71  vmovaps [rsp+0x90], xmm10
000078af20bdbd7a  vmovaps [rsp+0xA0], xmm11
000078af20bdbd83  vmovaps [rsp+0xB0], xmm12
000078af20bdbd8c  vmovaps [rsp+0xC0], xmm13
000078af20bdbd95  vmovaps [rsp+0xD0], xmm14
000078af20bdbd9e  vmovaps [rsp+0xE0], xmm15
000078af20bdbda7  sub rsp, 0x30
000078af20bdbdab  movaps [rsp], xmm1
000078af20bdbdaf  movaps [rsp+0x10], xmm4
000078af20bdbdb4  movaps [rsp+0x20], xmm9
000078af20bdbdba  lea rdi, [rsp]
000078af20bdbdbe  mov esi, 0x00
000078af20bdbdc3  mov rax, 0x65452FFB8530
000078af20bdbdcd  call rax
000078af20bdbdcf  movaps xmm1, [rsp]
000078af20bdbdd3  add rsp, 0x30
000078af20bdbdd7  vmovaps xmm0, [rsp]
000078af20bdbddc  vmovaps xmm2, [rsp+0x10]
000078af20bdbde2  vmovaps xmm3, [rsp+0x20]
000078af20bdbde8  vmovaps xmm4, [rsp+0x30]
000078af20bdbdee  vmovaps xmm5, [rsp+0x40]
000078af20bdbdf4  vmovaps xmm6, [rsp+0x50]
000078af20bdbdfa  vmovaps xmm7, [rsp+0x60]
000078af20bdbe00  vmovaps xmm8, [rsp+0x70]
000078af20bdbe06  vmovaps xmm9, [rsp+0x80]
000078af20bdbe0f  vmovaps xmm10, [rsp+0x90]
000078af20bdbe18  vmovaps xmm11, [rsp+0xA0]
000078af20bdbe21  vmovaps xmm12, [rsp+0xB0]
000078af20bdbe2a  vmovaps xmm13, [rsp+0xC0]
000078af20bdbe33  vmovaps xmm14, [rsp+0xD0]
000078af20bdbe3c  vmovaps xmm15, [rsp+0xE0]
000078af20bdbe45  add rsp, 0xF0
000078af20bdbe4c  pop r11
000078af20bdbe4e  pop r10
000078af20bdbe50  pop r9
000078af20bdbe52  pop r8
000078af20bdbe54  pop rsi
000078af20bdbe55  pop rdi
000078af20bdbe56  pop rdx
000078af20bdbe57  pop rcx
000078af20bdbe58  pop rax
000078af20bdbe59  add rsp, 0x08
000078af20bdbe5d  jmp 0x000078AF20BD931B
000078af20bdbe62  sub rsp, 0x08
000078af20bdbe66  push rax
000078af20bdbe67  push rcx
000078af20bdbe68  push rdx
000078af20bdbe69  push rdi
000078af20bdbe6a  push rsi
000078af20bdbe6b  push r8
000078af20bdbe6d  push r9
000078af20bdbe6f  push r10
000078af20bdbe71  push r11
000078af20bdbe73  sub rsp, 0xF0
000078af20bdbe7a  vmovaps [rsp], xmm0
000078af20bdbe7f  vmovaps [rsp+0x10], xmm1
000078af20bdbe85  vmovaps [rsp+0x20], xmm2
000078af20bdbe8b  vmovaps [rsp+0x30], xmm3
000078af20bdbe91  vmovaps [rsp+0x40], xmm5
000078af20bdbe97  vmovaps [rsp+0x50], xmm6
000078af20bdbe9d  vmovaps [rsp+0x60], xmm7
000078af20bdbea3  vmovaps [rsp+0x70], xmm8
000078af20bdbea9  vmovaps [rsp+0x80], xmm9
000078af20bdbeb2  vmovaps [rsp+0x90], xmm10
000078af20bdbebb  vmovaps [rsp+0xA0], xmm11
000078af20bdbec4  vmovaps [rsp+0xB0], xmm12
000078af20bdbecd  vmovaps [rsp+0xC0], xmm13
000078af20bdbed6  vmovaps [rsp+0xD0], xmm14
000078af20bdbedf  vmovaps [rsp+0xE0], xmm15
000078af20bdbee8  sub rsp, 0x30
000078af20bdbeec  movaps [rsp], xmm4
000078af20bdbef0  movaps [rsp+0x10], xmm2
000078af20bdbef5  movaps [rsp+0x20], xmm9
000078af20bdbefb  lea rdi, [rsp]
000078af20bdbeff  mov esi, 0x00
000078af20bdbf04  mov rax, 0x65452FFB8530
000078af20bdbf0e  call rax
000078af20bdbf10  movaps xmm4, [rsp]
000078af20bdbf14  add rsp, 0x30
000078af20bdbf18  vmovaps xmm0, [rsp]
000078af20bdbf1d  vmovaps xmm1, [rsp+0x10]
000078af20bdbf23  vmovaps xmm2, [rsp+0x20]
000078af20bdbf29  vmovaps xmm3, [rsp+0x30]
000078af20bdbf2f  vmovaps xmm5, [rsp+0x40]
000078af20bdbf35  vmovaps xmm6, [rsp+0x50]
000078af20bdbf3b  vmovaps xmm7, [rsp+0x60]
000078af20bdbf41  vmovaps xmm8, [rsp+0x70]
000078af20bdbf47  vmovaps xmm9, [rsp+0x80]
000078af20bdbf50  vmovaps xmm10, [rsp+0x90]
000078af20bdbf59  vmovaps xmm11, [rsp+0xA0]
000078af20bdbf62  vmovaps xmm12, [rsp+0xB0]
000078af20bdbf6b  vmovaps xmm13, [rsp+0xC0]
000078af20bdbf74  vmovaps xmm14, [rsp+0xD0]
000078af20bdbf7d  vmovaps xmm15, [rsp+0xE0]
000078af20bdbf86  add rsp, 0xF0
000078af20bdbf8d  pop r11
000078af20bdbf8f  pop r10
000078af20bdbf91  pop r9
000078af20bdbf93  pop r8
000078af20bdbf95  pop rsi
000078af20bdbf96  pop rdi
000078af20bdbf97  pop rdx
000078af20bdbf98  pop rcx
000078af20bdbf99  pop rax
000078af20bdbf9a  add rsp, 0x08
000078af20bdbf9e  jmp 0x000078AF20BD934B
000078af20bdbfa3  sub rsp, 0x08
000078af20bdbfa7  push rax
000078af20bdbfa8  push rcx
000078af20bdbfa9  push rdx
000078af20bdbfaa  push rdi
000078af20bdbfab  push rsi
000078af20bdbfac  push r8
000078af20bdbfae  push r9
000078af20bdbfb0  push r10
000078af20bdbfb2  push r11
000078af20bdbfb4  sub rsp, 0xF0
000078af20bdbfbb  vmovaps [rsp], xmm0
000078af20bdbfc0  vmovaps [rsp+0x10], xmm1
000078af20bdbfc6  vmovaps [rsp+0x20], xmm2
000078af20bdbfcc  vmovaps [rsp+0x30], xmm3
000078af20bdbfd2  vmovaps [rsp+0x40], xmm4
000078af20bdbfd8  vmovaps [rsp+0x50], xmm5
000078af20bdbfde  vmovaps [rsp+0x60], xmm6
000078af20bdbfe4  vmovaps [rsp+0x70], xmm7
000078af20bdbfea  vmovaps [rsp+0x80], xmm8
000078af20bdbff3  vmovaps [rsp+0x90], xmm10
000078af20bdbffc  vmovaps [rsp+0xA0], xmm11
000078af20bdc005  vmovaps [rsp+0xB0], xmm12
000078af20bdc00e  vmovaps [rsp+0xC0], xmm13
000078af20bdc017  vmovaps [rsp+0xD0], xmm14
000078af20bdc020  vmovaps [rsp+0xE0], xmm15
000078af20bdc029  sub rsp, 0x30
000078af20bdc02d  movaps [rsp], xmm9
000078af20bdc032  movaps [rsp+0x10], xmm2
000078af20bdc037  movaps [rsp+0x20], xmm1
000078af20bdc03c  lea rdi, [rsp]
000078af20bdc040  mov esi, 0x00
000078af20bdc045  mov rax, 0x65452FFB8530
000078af20bdc04f  call rax
000078af20bdc051  movaps xmm9, [rsp]
000078af20bdc056  add rsp, 0x30
000078af20bdc05a  vmovaps xmm0, [rsp]
000078af20bdc05f  vmovaps xmm1, [rsp+0x10]
000078af20bdc065  vmovaps xmm2, [rsp+0x20]
000078af20bdc06b  vmovaps xmm3, [rsp+0x30]
000078af20bdc071  vmovaps xmm4, [rsp+0x40]
000078af20bdc077  vmovaps xmm5, [rsp+0x50]
000078af20bdc07d  vmovaps xmm6, [rsp+0x60]
000078af20bdc083  vmovaps xmm7, [rsp+0x70]
000078af20bdc089  vmovaps xmm8, [rsp+0x80]
000078af20bdc092  vmovaps xmm10, [rsp+0x90]
000078af20bdc09b  vmovaps xmm11, [rsp+0xA0]
000078af20bdc0a4  vmovaps xmm12, [rsp+0xB0]
000078af20bdc0ad  vmovaps xmm13, [rsp+0xC0]
000078af20bdc0b6  vmovaps xmm14, [rsp+0xD0]
000078af20bdc0bf  vmovaps xmm15, [rsp+0xE0]
000078af20bdc0c8  add rsp, 0xF0
000078af20bdc0cf  pop r11
000078af20bdc0d1  pop r10
000078af20bdc0d3  pop r9
000078af20bdc0d5  pop r8
000078af20bdc0d7  pop rsi
000078af20bdc0d8  pop rdi
000078af20bdc0d9  pop rdx
000078af20bdc0da  pop rcx
000078af20bdc0db  pop rax
000078af20bdc0dc  add rsp, 0x08
000078af20bdc0e0  jmp 0x000078AF20BD9381
000078af20bdc0e5  sub rsp, 0x08
000078af20bdc0e9  push rax
000078af20bdc0ea  push rcx
000078af20bdc0eb  push rdx
000078af20bdc0ec  push rdi
000078af20bdc0ed  push rsi
000078af20bdc0ee  push r8
000078af20bdc0f0  push r9
000078af20bdc0f2  push r10
000078af20bdc0f4  push r11
000078af20bdc0f6  sub rsp, 0xF0
000078af20bdc0fd  vmovaps [rsp], xmm0
000078af20bdc102  vmovaps [rsp+0x10], xmm2
000078af20bdc108  vmovaps [rsp+0x20], xmm3
000078af20bdc10e  vmovaps [rsp+0x30], xmm4
000078af20bdc114  vmovaps [rsp+0x40], xmm5
000078af20bdc11a  vmovaps [rsp+0x50], xmm6
000078af20bdc120  vmovaps [rsp+0x60], xmm7
000078af20bdc126  vmovaps [rsp+0x70], xmm8
000078af20bdc12c  vmovaps [rsp+0x80], xmm9
000078af20bdc135  vmovaps [rsp+0x90], xmm10
000078af20bdc13e  vmovaps [rsp+0xA0], xmm11
000078af20bdc147  vmovaps [rsp+0xB0], xmm12
000078af20bdc150  vmovaps [rsp+0xC0], xmm13
000078af20bdc159  vmovaps [rsp+0xD0], xmm14
000078af20bdc162  vmovaps [rsp+0xE0], xmm15
000078af20bdc16b  sub rsp, 0x30
000078af20bdc16f  movaps [rsp], xmm1
000078af20bdc173  movaps [rsp+0x10], xmm15
000078af20bdc179  movaps [rsp+0x20], xmm6
000078af20bdc17e  lea rdi, [rsp]
000078af20bdc182  mov esi, 0x00
000078af20bdc187  mov rax, 0x65452FFB8530
000078af20bdc191  call rax
000078af20bdc193  movaps xmm1, [rsp]
000078af20bdc197  add rsp, 0x30
000078af20bdc19b  vmovaps xmm0, [rsp]
000078af20bdc1a0  vmovaps xmm2, [rsp+0x10]
000078af20bdc1a6  vmovaps xmm3, [rsp+0x20]
000078af20bdc1ac  vmovaps xmm4, [rsp+0x30]
000078af20bdc1b2  vmovaps xmm5, [rsp+0x40]
000078af20bdc1b8  vmovaps xmm6, [rsp+0x50]
000078af20bdc1be  vmovaps xmm7, [rsp+0x60]
000078af20bdc1c4  vmovaps xmm8, [rsp+0x70]
000078af20bdc1ca  vmovaps xmm9, [rsp+0x80]
000078af20bdc1d3  vmovaps xmm10, [rsp+0x90]
000078af20bdc1dc  vmovaps xmm11, [rsp+0xA0]
000078af20bdc1e5  vmovaps xmm12, [rsp+0xB0]
000078af20bdc1ee  vmovaps xmm13, [rsp+0xC0]
000078af20bdc1f7  vmovaps xmm14, [rsp+0xD0]
000078af20bdc200  vmovaps xmm15, [rsp+0xE0]
000078af20bdc209  add rsp, 0xF0
000078af20bdc210  pop r11
000078af20bdc212  pop r10
000078af20bdc214  pop r9
000078af20bdc216  pop r8
000078af20bdc218  pop rsi
000078af20bdc219  pop rdi
000078af20bdc21a  pop rdx
000078af20bdc21b  pop rcx
000078af20bdc21c  pop rax
000078af20bdc21d  add rsp, 0x08
000078af20bdc221  jmp 0x000078AF20BD93A2
000078af20bdc226  sub rsp, 0x08
000078af20bdc22a  push rax
000078af20bdc22b  push rcx
000078af20bdc22c  push rdx
000078af20bdc22d  push rdi
000078af20bdc22e  push rsi
000078af20bdc22f  push r8
000078af20bdc231  push r9
000078af20bdc233  push r10
000078af20bdc235  push r11
000078af20bdc237  sub rsp, 0xF0
000078af20bdc23e  vmovaps [rsp], xmm0
000078af20bdc243  vmovaps [rsp+0x10], xmm1
000078af20bdc249  vmovaps [rsp+0x20], xmm2
000078af20bdc24f  vmovaps [rsp+0x30], xmm3
000078af20bdc255  vmovaps [rsp+0x40], xmm4
000078af20bdc25b  vmovaps [rsp+0x50], xmm5
000078af20bdc261  vmovaps [rsp+0x60], xmm6
000078af20bdc267  vmovaps [rsp+0x70], xmm7
000078af20bdc26d  vmovaps [rsp+0x80], xmm8
000078af20bdc276  vmovaps [rsp+0x90], xmm9
000078af20bdc27f  vmovaps [rsp+0xA0], xmm10
000078af20bdc288  vmovaps [rsp+0xB0], xmm11
000078af20bdc291  vmovaps [rsp+0xC0], xmm12
000078af20bdc29a  vmovaps [rsp+0xD0], xmm13
000078af20bdc2a3  vmovaps [rsp+0xE0], xmm14
000078af20bdc2ac  sub rsp, 0x30
000078af20bdc2b0  movaps [rsp], xmm15
000078af20bdc2b5  movaps [rsp+0x10], xmm5
000078af20bdc2ba  movaps [rsp+0x20], xmm3
000078af20bdc2bf  lea rdi, [rsp]
000078af20bdc2c3  mov esi, 0x00
000078af20bdc2c8  mov rax, 0x65452FFB8530
000078af20bdc2d2  call rax
000078af20bdc2d4  movaps xmm15, [rsp]
000078af20bdc2d9  add rsp, 0x30
000078af20bdc2dd  vmovaps xmm0, [rsp]
000078af20bdc2e2  vmovaps xmm1, [rsp+0x10]
000078af20bdc2e8  vmovaps xmm2, [rsp+0x20]
000078af20bdc2ee  vmovaps xmm3, [rsp+0x30]
000078af20bdc2f4  vmovaps xmm4, [rsp+0x40]
000078af20bdc2fa  vmovaps xmm5, [rsp+0x50]
000078af20bdc300  vmovaps xmm6, [rsp+0x60]
000078af20bdc306  vmovaps xmm7, [rsp+0x70]
000078af20bdc30c  vmovaps xmm8, [rsp+0x80]
000078af20bdc315  vmovaps xmm9, [rsp+0x90]
000078af20bdc31e  vmovaps xmm10, [rsp+0xA0]
000078af20bdc327  vmovaps xmm11, [rsp+0xB0]
000078af20bdc330  vmovaps xmm12, [rsp+0xC0]
000078af20bdc339  vmovaps xmm13, [rsp+0xD0]
000078af20bdc342  vmovaps xmm14, [rsp+0xE0]
000078af20bdc34b  add rsp, 0xF0
000078af20bdc352  pop r11
000078af20bdc354  pop r10
000078af20bdc356  pop r9
000078af20bdc358  pop r8
000078af20bdc35a  pop rsi
000078af20bdc35b  pop rdi
000078af20bdc35c  pop rdx
000078af20bdc35d  pop rcx
000078af20bdc35e  pop rax
000078af20bdc35f  add rsp, 0x08
000078af20bdc363  jmp 0x000078AF20BD93BC
000078af20bdc368  sub rsp, 0x08
000078af20bdc36c  push rax
000078af20bdc36d  push rcx
000078af20bdc36e  push rdx
000078af20bdc36f  push rdi
000078af20bdc370  push rsi
000078af20bdc371  push r8
000078af20bdc373  push r9
000078af20bdc375  push r10
000078af20bdc377  push r11
000078af20bdc379  sub rsp, 0xF0
000078af20bdc380  vmovaps [rsp], xmm0
000078af20bdc385  vmovaps [rsp+0x10], xmm1
000078af20bdc38b  vmovaps [rsp+0x20], xmm2
000078af20bdc391  vmovaps [rsp+0x30], xmm3
000078af20bdc397  vmovaps [rsp+0x40], xmm4
000078af20bdc39d  vmovaps [rsp+0x50], xmm6
000078af20bdc3a3  vmovaps [rsp+0x60], xmm7
000078af20bdc3a9  vmovaps [rsp+0x70], xmm8
000078af20bdc3af  vmovaps [rsp+0x80], xmm9
000078af20bdc3b8  vmovaps [rsp+0x90], xmm10
000078af20bdc3c1  vmovaps [rsp+0xA0], xmm11
000078af20bdc3ca  vmovaps [rsp+0xB0], xmm12
000078af20bdc3d3  vmovaps [rsp+0xC0], xmm13
000078af20bdc3dc  vmovaps [rsp+0xD0], xmm14
000078af20bdc3e5  vmovaps [rsp+0xE0], xmm15
000078af20bdc3ee  sub rsp, 0x30
000078af20bdc3f2  movaps [rsp], xmm5
000078af20bdc3f6  movaps [rsp+0x10], xmm8
000078af20bdc3fc  movaps [rsp+0x20], xmm6
000078af20bdc401  lea rdi, [rsp]
000078af20bdc405  mov esi, 0x00
000078af20bdc40a  mov rax, 0x65452FFB8530
000078af20bdc414  call rax
000078af20bdc416  movaps xmm5, [rsp]
000078af20bdc41a  add rsp, 0x30
000078af20bdc41e  vmovaps xmm0, [rsp]
000078af20bdc423  vmovaps xmm1, [rsp+0x10]
000078af20bdc429  vmovaps xmm2, [rsp+0x20]
000078af20bdc42f  vmovaps xmm3, [rsp+0x30]
000078af20bdc435  vmovaps xmm4, [rsp+0x40]
000078af20bdc43b  vmovaps xmm6, [rsp+0x50]
000078af20bdc441  vmovaps xmm7, [rsp+0x60]
000078af20bdc447  vmovaps xmm8, [rsp+0x70]
000078af20bdc44d  vmovaps xmm9, [rsp+0x80]
000078af20bdc456  vmovaps xmm10, [rsp+0x90]
000078af20bdc45f  vmovaps xmm11, [rsp+0xA0]
000078af20bdc468  vmovaps xmm12, [rsp+0xB0]
000078af20bdc471  vmovaps xmm13, [rsp+0xC0]
000078af20bdc47a  vmovaps xmm14, [rsp+0xD0]
000078af20bdc483  vmovaps xmm15, [rsp+0xE0]
000078af20bdc48c  add rsp, 0xF0
000078af20bdc493  pop r11
000078af20bdc495  pop r10
000078af20bdc497  pop r9
000078af20bdc499  pop r8
000078af20bdc49b  pop rsi
000078af20bdc49c  pop rdi
000078af20bdc49d  pop rdx
000078af20bdc49e  pop rcx
000078af20bdc49f  pop rax
000078af20bdc4a0  add rsp, 0x08
000078af20bdc4a4  jmp 0x000078AF20BD93E0
000078af20bdc4a9  sub rsp, 0x08
000078af20bdc4ad  push rax
000078af20bdc4ae  push rcx
000078af20bdc4af  push rdx
000078af20bdc4b0  push rdi
000078af20bdc4b1  push rsi
000078af20bdc4b2  push r8
000078af20bdc4b4  push r9
000078af20bdc4b6  push r10
000078af20bdc4b8  push r11
000078af20bdc4ba  sub rsp, 0xF0
000078af20bdc4c1  vmovaps [rsp], xmm0
000078af20bdc4c6  vmovaps [rsp+0x10], xmm1
000078af20bdc4cc  vmovaps [rsp+0x20], xmm2
000078af20bdc4d2  vmovaps [rsp+0x30], xmm3
000078af20bdc4d8  vmovaps [rsp+0x40], xmm4
000078af20bdc4de  vmovaps [rsp+0x50], xmm5
000078af20bdc4e4  vmovaps [rsp+0x60], xmm7
000078af20bdc4ea  vmovaps [rsp+0x70], xmm8
000078af20bdc4f0  vmovaps [rsp+0x80], xmm9
000078af20bdc4f9  vmovaps [rsp+0x90], xmm10
000078af20bdc502  vmovaps [rsp+0xA0], xmm11
000078af20bdc50b  vmovaps [rsp+0xB0], xmm12
000078af20bdc514  vmovaps [rsp+0xC0], xmm13
000078af20bdc51d  vmovaps [rsp+0xD0], xmm14
000078af20bdc526  vmovaps [rsp+0xE0], xmm15
000078af20bdc52f  sub rsp, 0x30
000078af20bdc533  movaps [rsp], xmm6
000078af20bdc537  movaps [rsp+0x10], xmm10
000078af20bdc53d  movaps [rsp+0x20], xmm8
000078af20bdc543  lea rdi, [rsp]
000078af20bdc547  mov esi, 0x00
000078af20bdc54c  mov rax, 0x65452FFB8530
000078af20bdc556  call rax
000078af20bdc558  movaps xmm6, [rsp]
000078af20bdc55c  add rsp, 0x30
000078af20bdc560  vmovaps xmm0, [rsp]
000078af20bdc565  vmovaps xmm1, [rsp+0x10]
000078af20bdc56b  vmovaps xmm2, [rsp+0x20]
000078af20bdc571  vmovaps xmm3, [rsp+0x30]
000078af20bdc577  vmovaps xmm4, [rsp+0x40]
000078af20bdc57d  vmovaps xmm5, [rsp+0x50]
000078af20bdc583  vmovaps xmm7, [rsp+0x60]
000078af20bdc589  vmovaps xmm8, [rsp+0x70]
000078af20bdc58f  vmovaps xmm9, [rsp+0x80]
000078af20bdc598  vmovaps xmm10, [rsp+0x90]
000078af20bdc5a1  vmovaps xmm11, [rsp+0xA0]
000078af20bdc5aa  vmovaps xmm12, [rsp+0xB0]
000078af20bdc5b3  vmovaps xmm13, [rsp+0xC0]
000078af20bdc5bc  vmovaps xmm14, [rsp+0xD0]
000078af20bdc5c5  vmovaps xmm15, [rsp+0xE0]
000078af20bdc5ce  add rsp, 0xF0
000078af20bdc5d5  pop r11
000078af20bdc5d7  pop r10
000078af20bdc5d9  pop r9
000078af20bdc5db  pop r8
000078af20bdc5dd  pop rsi
000078af20bdc5de  pop rdi
000078af20bdc5df  pop rdx
000078af20bdc5e0  pop rcx
000078af20bdc5e1  pop rax
000078af20bdc5e2  add rsp, 0x08
000078af20bdc5e6  jmp 0x000078AF20BD9405
000078af20bdc5eb  sub rsp, 0x08
000078af20bdc5ef  push rax
000078af20bdc5f0  push rcx
000078af20bdc5f1  push rdx
000078af20bdc5f2  push rdi
000078af20bdc5f3  push rsi
000078af20bdc5f4  push r8
000078af20bdc5f6  push r9
000078af20bdc5f8  push r10
000078af20bdc5fa  push r11
000078af20bdc5fc  sub rsp, 0xF0
000078af20bdc603  vmovaps [rsp], xmm0
000078af20bdc608  vmovaps [rsp+0x10], xmm1
000078af20bdc60e  vmovaps [rsp+0x20], xmm2
000078af20bdc614  vmovaps [rsp+0x30], xmm3
000078af20bdc61a  vmovaps [rsp+0x40], xmm4
000078af20bdc620  vmovaps [rsp+0x50], xmm5
000078af20bdc626  vmovaps [rsp+0x60], xmm6
000078af20bdc62c  vmovaps [rsp+0x70], xmm7
000078af20bdc632  vmovaps [rsp+0x80], xmm8
000078af20bdc63b  vmovaps [rsp+0x90], xmm9
000078af20bdc644  vmovaps [rsp+0xA0], xmm11
000078af20bdc64d  vmovaps [rsp+0xB0], xmm12
000078af20bdc656  vmovaps [rsp+0xC0], xmm13
000078af20bdc65f  vmovaps [rsp+0xD0], xmm14
000078af20bdc668  vmovaps [rsp+0xE0], xmm15
000078af20bdc671  sub rsp, 0x30
000078af20bdc675  movaps [rsp], xmm10
000078af20bdc67a  movaps [rsp+0x10], xmm8
000078af20bdc680  movaps [rsp+0x20], xmm14
000078af20bdc686  lea rdi, [rsp]
000078af20bdc68a  mov esi, 0x00
000078af20bdc68f  mov rax, 0x65452FFB8530
000078af20bdc699  call rax
000078af20bdc69b  movaps xmm10, [rsp]
000078af20bdc6a0  add rsp, 0x30
000078af20bdc6a4  vmovaps xmm0, [rsp]
000078af20bdc6a9  vmovaps xmm1, [rsp+0x10]
000078af20bdc6af  vmovaps xmm2, [rsp+0x20]
000078af20bdc6b5  vmovaps xmm3, [rsp+0x30]
000078af20bdc6bb  vmovaps xmm4, [rsp+0x40]
000078af20bdc6c1  vmovaps xmm5, [rsp+0x50]
000078af20bdc6c7  vmovaps xmm6, [rsp+0x60]
000078af20bdc6cd  vmovaps xmm7, [rsp+0x70]
000078af20bdc6d3  vmovaps xmm8, [rsp+0x80]
000078af20bdc6dc  vmovaps xmm9, [rsp+0x90]
000078af20bdc6e5  vmovaps xmm11, [rsp+0xA0]
000078af20bdc6ee  vmovaps xmm12, [rsp+0xB0]
000078af20bdc6f7  vmovaps xmm13, [rsp+0xC0]
000078af20bdc700  vmovaps xmm14, [rsp+0xD0]
000078af20bdc709  vmovaps xmm15, [rsp+0xE0]
000078af20bdc712  add rsp, 0xF0
000078af20bdc719  pop r11
000078af20bdc71b  pop r10
000078af20bdc71d  pop r9
000078af20bdc71f  pop r8
000078af20bdc721  pop rsi
000078af20bdc722  pop rdi
000078af20bdc723  pop rdx
000078af20bdc724  pop rcx
000078af20bdc725  pop rax
000078af20bdc726  add rsp, 0x08
000078af20bdc72a  jmp 0x000078AF20BD9425
000078af20bdc72f  sub rsp, 0x08
000078af20bdc733  push rax
000078af20bdc734  push rcx
000078af20bdc735  push rdx
000078af20bdc736  push rdi
000078af20bdc737  push rsi
000078af20bdc738  push r8
000078af20bdc73a  push r9
000078af20bdc73c  push r10
000078af20bdc73e  push r11
000078af20bdc740  sub rsp, 0xF0
000078af20bdc747  vmovaps [rsp], xmm0
000078af20bdc74c  vmovaps [rsp+0x10], xmm1
000078af20bdc752  vmovaps [rsp+0x20], xmm2
000078af20bdc758  vmovaps [rsp+0x30], xmm3
000078af20bdc75e  vmovaps [rsp+0x40], xmm4
000078af20bdc764  vmovaps [rsp+0x50], xmm5
000078af20bdc76a  vmovaps [rsp+0x60], xmm6
000078af20bdc770  vmovaps [rsp+0x70], xmm7
000078af20bdc776  vmovaps [rsp+0x80], xmm8
000078af20bdc77f  vmovaps [rsp+0x90], xmm9
000078af20bdc788  vmovaps [rsp+0xA0], xmm10
000078af20bdc791  vmovaps [rsp+0xB0], xmm11
000078af20bdc79a  vmovaps [rsp+0xC0], xmm12
000078af20bdc7a3  vmovaps [rsp+0xD0], xmm13
000078af20bdc7ac  vmovaps [rsp+0xE0], xmm15
000078af20bdc7b5  sub rsp, 0x30
000078af20bdc7b9  movaps [rsp], xmm14
000078af20bdc7be  movaps [rsp+0x10], xmm8
000078af20bdc7c4  movaps [rsp+0x20], xmm4
000078af20bdc7c9  lea rdi, [rsp]
000078af20bdc7cd  mov esi, 0x00
000078af20bdc7d2  mov rax, 0x65452FFB8530
000078af20bdc7dc  call rax
000078af20bdc7de  movaps xmm14, [rsp]
000078af20bdc7e3  add rsp, 0x30
000078af20bdc7e7  vmovaps xmm0, [rsp]
000078af20bdc7ec  vmovaps xmm1, [rsp+0x10]
000078af20bdc7f2  vmovaps xmm2, [rsp+0x20]
000078af20bdc7f8  vmovaps xmm3, [rsp+0x30]
000078af20bdc7fe  vmovaps xmm4, [rsp+0x40]
000078af20bdc804  vmovaps xmm5, [rsp+0x50]
000078af20bdc80a  vmovaps xmm6, [rsp+0x60]
000078af20bdc810  vmovaps xmm7, [rsp+0x70]
000078af20bdc816  vmovaps xmm8, [rsp+0x80]
000078af20bdc81f  vmovaps xmm9, [rsp+0x90]
000078af20bdc828  vmovaps xmm10, [rsp+0xA0]
000078af20bdc831  vmovaps xmm11, [rsp+0xB0]
000078af20bdc83a  vmovaps xmm12, [rsp+0xC0]
000078af20bdc843  vmovaps xmm13, [rsp+0xD0]
000078af20bdc84c  vmovaps xmm15, [rsp+0xE0]
000078af20bdc855  add rsp, 0xF0
000078af20bdc85c  pop r11
000078af20bdc85e  pop r10
000078af20bdc860  pop r9
000078af20bdc862  pop r8
000078af20bdc864  pop rsi
000078af20bdc865  pop rdi
000078af20bdc866  pop rdx
000078af20bdc867  pop rcx
000078af20bdc868  pop rax
000078af20bdc869  add rsp, 0x08
000078af20bdc86d  jmp 0x000078AF20BD9445
000078af20bdc872  sub rsp, 0x08
000078af20bdc876  push rax
000078af20bdc877  push rcx
000078af20bdc878  push rdx
000078af20bdc879  push rdi
000078af20bdc87a  push rsi
000078af20bdc87b  push r8
000078af20bdc87d  push r9
000078af20bdc87f  push r10
000078af20bdc881  push r11
000078af20bdc883  sub rsp, 0xF0
000078af20bdc88a  vmovaps [rsp], xmm0
000078af20bdc88f  vmovaps [rsp+0x10], xmm1
000078af20bdc895  vmovaps [rsp+0x20], xmm2
000078af20bdc89b  vmovaps [rsp+0x30], xmm3
000078af20bdc8a1  vmovaps [rsp+0x40], xmm5
000078af20bdc8a7  vmovaps [rsp+0x50], xmm6
000078af20bdc8ad  vmovaps [rsp+0x60], xmm7
000078af20bdc8b3  vmovaps [rsp+0x70], xmm8
000078af20bdc8b9  vmovaps [rsp+0x80], xmm9
000078af20bdc8c2  vmovaps [rsp+0x90], xmm10
000078af20bdc8cb  vmovaps [rsp+0xA0], xmm11
000078af20bdc8d4  vmovaps [rsp+0xB0], xmm12
000078af20bdc8dd  vmovaps [rsp+0xC0], xmm13
000078af20bdc8e6  vmovaps [rsp+0xD0], xmm14
000078af20bdc8ef  vmovaps [rsp+0xE0], xmm15
000078af20bdc8f8  sub rsp, 0x30
000078af20bdc8fc  movaps [rsp], xmm4
000078af20bdc900  movaps [rsp+0x10], xmm13
000078af20bdc906  movaps [rsp+0x20], xmm8
000078af20bdc90c  lea rdi, [rsp]
000078af20bdc910  mov esi, 0x00
000078af20bdc915  mov rax, 0x65452FFB8530
000078af20bdc91f  call rax
000078af20bdc921  movaps xmm4, [rsp]
000078af20bdc925  add rsp, 0x30
000078af20bdc929  vmovaps xmm0, [rsp]
000078af20bdc92e  vmovaps xmm1, [rsp+0x10]
000078af20bdc934  vmovaps xmm2, [rsp+0x20]
000078af20bdc93a  vmovaps xmm3, [rsp+0x30]
000078af20bdc940  vmovaps xmm5, [rsp+0x40]
000078af20bdc946  vmovaps xmm6, [rsp+0x50]
000078af20bdc94c  vmovaps xmm7, [rsp+0x60]
000078af20bdc952  vmovaps xmm8, [rsp+0x70]
000078af20bdc958  vmovaps xmm9, [rsp+0x80]
000078af20bdc961  vmovaps xmm10, [rsp+0x90]
000078af20bdc96a  vmovaps xmm11, [rsp+0xA0]
000078af20bdc973  vmovaps xmm12, [rsp+0xB0]
000078af20bdc97c  vmovaps xmm13, [rsp+0xC0]
000078af20bdc985  vmovaps xmm14, [rsp+0xD0]
000078af20bdc98e  vmovaps xmm15, [rsp+0xE0]
000078af20bdc997  add rsp, 0xF0
000078af20bdc99e  pop r11
000078af20bdc9a0  pop r10
000078af20bdc9a2  pop r9
000078af20bdc9a4  pop r8
000078af20bdc9a6  pop rsi
000078af20bdc9a7  pop rdi
000078af20bdc9a8  pop rdx
000078af20bdc9a9  pop rcx
000078af20bdc9aa  pop rax
000078af20bdc9ab  add rsp, 0x08
000078af20bdc9af  jmp 0x000078AF20BD946A
000078af20bdc9b4  sub rsp, 0x08
000078af20bdc9b8  push rax
000078af20bdc9b9  push rcx
000078af20bdc9ba  push rdx
000078af20bdc9bb  push rdi
000078af20bdc9bc  push rsi
000078af20bdc9bd  push r8
000078af20bdc9bf  push r9
000078af20bdc9c1  push r10
000078af20bdc9c3  push r11
000078af20bdc9c5  sub rsp, 0xF0
000078af20bdc9cc  vmovaps [rsp], xmm0
000078af20bdc9d1  vmovaps [rsp+0x10], xmm1
000078af20bdc9d7  vmovaps [rsp+0x20], xmm2
000078af20bdc9dd  vmovaps [rsp+0x30], xmm3
000078af20bdc9e3  vmovaps [rsp+0x40], xmm4
000078af20bdc9e9  vmovaps [rsp+0x50], xmm5
000078af20bdc9ef  vmovaps [rsp+0x60], xmm6
000078af20bdc9f5  vmovaps [rsp+0x70], xmm7
000078af20bdc9fb  vmovaps [rsp+0x80], xmm8
000078af20bdca04  vmovaps [rsp+0x90], xmm9
000078af20bdca0d  vmovaps [rsp+0xA0], xmm10
000078af20bdca16  vmovaps [rsp+0xB0], xmm11
000078af20bdca1f  vmovaps [rsp+0xC0], xmm12
000078af20bdca28  vmovaps [rsp+0xD0], xmm14
000078af20bdca31  vmovaps [rsp+0xE0], xmm15
000078af20bdca3a  sub rsp, 0x30
000078af20bdca3e  movaps [rsp], xmm13
000078af20bdca43  movaps [rsp+0x10], xmm15
000078af20bdca49  movaps [rsp+0x20], xmm9
000078af20bdca4f  lea rdi, [rsp]
000078af20bdca53  mov esi, 0x00
000078af20bdca58  mov rax, 0x65452FFB8530
000078af20bdca62  call rax
000078af20bdca64  movaps xmm13, [rsp]
000078af20bdca69  add rsp, 0x30
000078af20bdca6d  vmovaps xmm0, [rsp]
000078af20bdca72  vmovaps xmm1, [rsp+0x10]
000078af20bdca78  vmovaps xmm2, [rsp+0x20]
000078af20bdca7e  vmovaps xmm3, [rsp+0x30]
000078af20bdca84  vmovaps xmm4, [rsp+0x40]
000078af20bdca8a  vmovaps xmm5, [rsp+0x50]
000078af20bdca90  vmovaps xmm6, [rsp+0x60]
000078af20bdca96  vmovaps xmm7, [rsp+0x70]
000078af20bdca9c  vmovaps xmm8, [rsp+0x80]
000078af20bdcaa5  vmovaps xmm9, [rsp+0x90]
000078af20bdcaae  vmovaps xmm10, [rsp+0xA0]
000078af20bdcab7  vmovaps xmm11, [rsp+0xB0]
000078af20bdcac0  vmovaps xmm12, [rsp+0xC0]
000078af20bdcac9  vmovaps xmm14, [rsp+0xD0]
000078af20bdcad2  vmovaps xmm15, [rsp+0xE0]
000078af20bdcadb  add rsp, 0xF0
000078af20bdcae2  pop r11
000078af20bdcae4  pop r10
000078af20bdcae6  pop r9
000078af20bdcae8  pop r8
000078af20bdcaea  pop rsi
000078af20bdcaeb  pop rdi
000078af20bdcaec  pop rdx
000078af20bdcaed  pop rcx
000078af20bdcaee  pop rax
000078af20bdcaef  add rsp, 0x08
000078af20bdcaf3  jmp 0x000078AF20BD9485
000078af20bdcaf8  sub rsp, 0x08
000078af20bdcafc  push rax
000078af20bdcafd  push rcx
000078af20bdcafe  push rdx
000078af20bdcaff  push rdi
000078af20bdcb00  push rsi
000078af20bdcb01  push r8
000078af20bdcb03  push r9
000078af20bdcb05  push r10
000078af20bdcb07  push r11
000078af20bdcb09  sub rsp, 0xF0
000078af20bdcb10  vmovaps [rsp], xmm0
000078af20bdcb15  vmovaps [rsp+0x10], xmm1
000078af20bdcb1b  vmovaps [rsp+0x20], xmm2
000078af20bdcb21  vmovaps [rsp+0x30], xmm3
000078af20bdcb27  vmovaps [rsp+0x40], xmm4
000078af20bdcb2d  vmovaps [rsp+0x50], xmm5
000078af20bdcb33  vmovaps [rsp+0x60], xmm6
000078af20bdcb39  vmovaps [rsp+0x70], xmm7
000078af20bdcb3f  vmovaps [rsp+0x80], xmm8
000078af20bdcb48  vmovaps [rsp+0x90], xmm9
000078af20bdcb51  vmovaps [rsp+0xA0], xmm10
000078af20bdcb5a  vmovaps [rsp+0xB0], xmm11
000078af20bdcb63  vmovaps [rsp+0xC0], xmm12
000078af20bdcb6c  vmovaps [rsp+0xD0], xmm13
000078af20bdcb75  vmovaps [rsp+0xE0], xmm14
000078af20bdcb7e  sub rsp, 0x30
000078af20bdcb82  movaps [rsp], xmm15
000078af20bdcb87  movaps [rsp+0x10], xmm1
000078af20bdcb8c  movaps [rsp+0x20], xmm5
000078af20bdcb91  lea rdi, [rsp]
000078af20bdcb95  mov esi, 0x00
000078af20bdcb9a  mov rax, 0x65452FFB8530
000078af20bdcba4  call rax
000078af20bdcba6  movaps xmm15, [rsp]
000078af20bdcbab  add rsp, 0x30
000078af20bdcbaf  vmovaps xmm0, [rsp]
000078af20bdcbb4  vmovaps xmm1, [rsp+0x10]
000078af20bdcbba  vmovaps xmm2, [rsp+0x20]
000078af20bdcbc0  vmovaps xmm3, [rsp+0x30]
000078af20bdcbc6  vmovaps xmm4, [rsp+0x40]
000078af20bdcbcc  vmovaps xmm5, [rsp+0x50]
000078af20bdcbd2  vmovaps xmm6, [rsp+0x60]
000078af20bdcbd8  vmovaps xmm7, [rsp+0x70]
000078af20bdcbde  vmovaps xmm8, [rsp+0x80]
000078af20bdcbe7  vmovaps xmm9, [rsp+0x90]
000078af20bdcbf0  vmovaps xmm10, [rsp+0xA0]
000078af20bdcbf9  vmovaps xmm11, [rsp+0xB0]
000078af20bdcc02  vmovaps xmm12, [rsp+0xC0]
000078af20bdcc0b  vmovaps xmm13, [rsp+0xD0]
000078af20bdcc14  vmovaps xmm14, [rsp+0xE0]
000078af20bdcc1d  add rsp, 0xF0
000078af20bdcc24  pop r11
000078af20bdcc26  pop r10
000078af20bdcc28  pop r9
000078af20bdcc2a  pop r8
000078af20bdcc2c  pop rsi
000078af20bdcc2d  pop rdi
000078af20bdcc2e  pop rdx
000078af20bdcc2f  pop rcx
000078af20bdcc30  pop rax
000078af20bdcc31  add rsp, 0x08
000078af20bdcc35  jmp 0x000078AF20BD94A0
000078af20bdcc3a  call 0x000078AF20AD64F0
000078af20bdcc3f  jmp 0x000078AF20BD94FB
000078af20bdcc44  sub rsp, 0x08
000078af20bdcc48  push rax
000078af20bdcc49  push rcx
000078af20bdcc4a  push rdx
000078af20bdcc4b  push rdi
000078af20bdcc4c  push rsi
000078af20bdcc4d  push r8
000078af20bdcc4f  push r9
000078af20bdcc51  push r10
000078af20bdcc53  push r11
000078af20bdcc55  sub rsp, 0xF0
000078af20bdcc5c  vmovaps [rsp], xmm0
000078af20bdcc61  vmovaps [rsp+0x10], xmm1
000078af20bdcc67  vmovaps [rsp+0x20], xmm2
000078af20bdcc6d  vmovaps [rsp+0x30], xmm3
000078af20bdcc73  vmovaps [rsp+0x40], xmm4
000078af20bdcc79  vmovaps [rsp+0x50], xmm5
000078af20bdcc7f  vmovaps [rsp+0x60], xmm6
000078af20bdcc85  vmovaps [rsp+0x70], xmm7
000078af20bdcc8b  vmovaps [rsp+0x80], xmm8
000078af20bdcc94  vmovaps [rsp+0x90], xmm10
000078af20bdcc9d  vmovaps [rsp+0xA0], xmm11
000078af20bdcca6  vmovaps [rsp+0xB0], xmm12
000078af20bdccaf  vmovaps [rsp+0xC0], xmm13
000078af20bdccb8  vmovaps [rsp+0xD0], xmm14
000078af20bdccc1  vmovaps [rsp+0xE0], xmm15
000078af20bdccca  sub rsp, 0x30
000078af20bdccce  movaps [rsp], xmm9
000078af20bdccd3  movaps [rsp+0x10], xmm8
000078af20bdccd9  movaps [rsp+0x20], xmm11
000078af20bdccdf  lea rdi, [rsp]
000078af20bdcce3  mov esi, 0x00
000078af20bdcce8  mov rax, 0x65452FFB8530
000078af20bdccf2  call rax
000078af20bdccf4  movaps xmm9, [rsp]
000078af20bdccf9  add rsp, 0x30
000078af20bdccfd  vmovaps xmm0, [rsp]
000078af20bdcd02  vmovaps xmm1, [rsp+0x10]
000078af20bdcd08  vmovaps xmm2, [rsp+0x20]
000078af20bdcd0e  vmovaps xmm3, [rsp+0x30]
000078af20bdcd14  vmovaps xmm4, [rsp+0x40]
000078af20bdcd1a  vmovaps xmm5, [rsp+0x50]
000078af20bdcd20  vmovaps xmm6, [rsp+0x60]
000078af20bdcd26  vmovaps xmm7, [rsp+0x70]
000078af20bdcd2c  vmovaps xmm8, [rsp+0x80]
000078af20bdcd35  vmovaps xmm10, [rsp+0x90]
000078af20bdcd3e  vmovaps xmm11, [rsp+0xA0]
000078af20bdcd47  vmovaps xmm12, [rsp+0xB0]
000078af20bdcd50  vmovaps xmm13, [rsp+0xC0]
000078af20bdcd59  vmovaps xmm14, [rsp+0xD0]
000078af20bdcd62  vmovaps xmm15, [rsp+0xE0]
000078af20bdcd6b  add rsp, 0xF0
000078af20bdcd72  pop r11
000078af20bdcd74  pop r10
000078af20bdcd76  pop r9
000078af20bdcd78  pop r8
000078af20bdcd7a  pop rsi
000078af20bdcd7b  pop rdi
000078af20bdcd7c  pop rdx
000078af20bdcd7d  pop rcx
000078af20bdcd7e  pop rax
000078af20bdcd7f  add rsp, 0x08
000078af20bdcd83  jmp 0x000078AF20BD9532
000078af20bdcd88  sub rsp, 0x08
000078af20bdcd8c  push rax
000078af20bdcd8d  push rcx
000078af20bdcd8e  push rdx
000078af20bdcd8f  push rdi
000078af20bdcd90  push rsi
000078af20bdcd91  push r8
000078af20bdcd93  push r9
000078af20bdcd95  push r10
000078af20bdcd97  push r11
000078af20bdcd99  sub rsp, 0xF0
000078af20bdcda0  vmovaps [rsp], xmm0
000078af20bdcda5  vmovaps [rsp+0x10], xmm1
000078af20bdcdab  vmovaps [rsp+0x20], xmm2
000078af20bdcdb1  vmovaps [rsp+0x30], xmm3
000078af20bdcdb7  vmovaps [rsp+0x40], xmm4
000078af20bdcdbd  vmovaps [rsp+0x50], xmm5
000078af20bdcdc3  vmovaps [rsp+0x60], xmm6
000078af20bdcdc9  vmovaps [rsp+0x70], xmm7
000078af20bdcdcf  vmovaps [rsp+0x80], xmm8
000078af20bdcdd8  vmovaps [rsp+0x90], xmm9
000078af20bdcde1  vmovaps [rsp+0xA0], xmm10
000078af20bdcdea  vmovaps [rsp+0xB0], xmm12
000078af20bdcdf3  vmovaps [rsp+0xC0], xmm13
000078af20bdcdfc  vmovaps [rsp+0xD0], xmm14
000078af20bdce05  vmovaps [rsp+0xE0], xmm15
000078af20bdce0e  sub rsp, 0x30
000078af20bdce12  movaps [rsp], xmm11
000078af20bdce17  movaps [rsp+0x10], xmm10
000078af20bdce1d  movaps [rsp+0x20], xmm6
000078af20bdce22  lea rdi, [rsp]
000078af20bdce26  mov esi, 0x00
000078af20bdce2b  mov rax, 0x65452FFB8530
000078af20bdce35  call rax
000078af20bdce37  movaps xmm11, [rsp]
000078af20bdce3c  add rsp, 0x30
000078af20bdce40  vmovaps xmm0, [rsp]
000078af20bdce45  vmovaps xmm1, [rsp+0x10]
000078af20bdce4b  vmovaps xmm2, [rsp+0x20]
000078af20bdce51  vmovaps xmm3, [rsp+0x30]
000078af20bdce57  vmovaps xmm4, [rsp+0x40]
000078af20bdce5d  vmovaps xmm5, [rsp+0x50]
000078af20bdce63  vmovaps xmm6, [rsp+0x60]
000078af20bdce69  vmovaps xmm7, [rsp+0x70]
000078af20bdce6f  vmovaps xmm8, [rsp+0x80]
000078af20bdce78  vmovaps xmm9, [rsp+0x90]
000078af20bdce81  vmovaps xmm10, [rsp+0xA0]
000078af20bdce8a  vmovaps xmm12, [rsp+0xB0]
000078af20bdce93  vmovaps xmm13, [rsp+0xC0]
000078af20bdce9c  vmovaps xmm14, [rsp+0xD0]
000078af20bdcea5  vmovaps xmm15, [rsp+0xE0]
000078af20bdceae  add rsp, 0xF0
000078af20bdceb5  pop r11
000078af20bdceb7  pop r10
000078af20bdceb9  pop r9
000078af20bdcebb  pop r8
000078af20bdcebd  pop rsi
000078af20bdcebe  pop rdi
000078af20bdcebf  pop rdx
000078af20bdcec0  pop rcx
000078af20bdcec1  pop rax
000078af20bdcec2  add rsp, 0x08
000078af20bdcec6  jmp 0x000078AF20BD954D
000078af20bdcecb  sub rsp, 0x08
000078af20bdcecf  push rax
000078af20bdced0  push rcx
000078af20bdced1  push rdx
000078af20bdced2  push rdi
000078af20bdced3  push rsi
000078af20bdced4  push r8
000078af20bdced6  push r9
000078af20bdced8  push r10
000078af20bdceda  push r11
000078af20bdcedc  sub rsp, 0xF0
000078af20bdcee3  vmovaps [rsp], xmm0
000078af20bdcee8  vmovaps [rsp+0x10], xmm1
000078af20bdceee  vmovaps [rsp+0x20], xmm2
000078af20bdcef4  vmovaps [rsp+0x30], xmm3
000078af20bdcefa  vmovaps [rsp+0x40], xmm4
000078af20bdcf00  vmovaps [rsp+0x50], xmm5
000078af20bdcf06  vmovaps [rsp+0x60], xmm6
000078af20bdcf0c  vmovaps [rsp+0x70], xmm7
000078af20bdcf12  vmovaps [rsp+0x80], xmm8
000078af20bdcf1b  vmovaps [rsp+0x90], xmm9
000078af20bdcf24  vmovaps [rsp+0xA0], xmm11
000078af20bdcf2d  vmovaps [rsp+0xB0], xmm12
000078af20bdcf36  vmovaps [rsp+0xC0], xmm13
000078af20bdcf3f  vmovaps [rsp+0xD0], xmm14
000078af20bdcf48  vmovaps [rsp+0xE0], xmm15
000078af20bdcf51  sub rsp, 0x30
000078af20bdcf55  movaps [rsp], xmm10
000078af20bdcf5a  movaps [rsp+0x10], xmm14
000078af20bdcf60  movaps [rsp+0x20], xmm4
000078af20bdcf65  lea rdi, [rsp]
000078af20bdcf69  mov esi, 0x00
000078af20bdcf6e  mov rax, 0x65452FFB8530
000078af20bdcf78  call rax
000078af20bdcf7a  movaps xmm10, [rsp]
000078af20bdcf7f  add rsp, 0x30
000078af20bdcf83  vmovaps xmm0, [rsp]
000078af20bdcf88  vmovaps xmm1, [rsp+0x10]
000078af20bdcf8e  vmovaps xmm2, [rsp+0x20]
000078af20bdcf94  vmovaps xmm3, [rsp+0x30]
000078af20bdcf9a  vmovaps xmm4, [rsp+0x40]
000078af20bdcfa0  vmovaps xmm5, [rsp+0x50]
000078af20bdcfa6  vmovaps xmm6, [rsp+0x60]
000078af20bdcfac  vmovaps xmm7, [rsp+0x70]
000078af20bdcfb2  vmovaps xmm8, [rsp+0x80]
000078af20bdcfbb  vmovaps xmm9, [rsp+0x90]
000078af20bdcfc4  vmovaps xmm11, [rsp+0xA0]
000078af20bdcfcd  vmovaps xmm12, [rsp+0xB0]
000078af20bdcfd6  vmovaps xmm13, [rsp+0xC0]
000078af20bdcfdf  vmovaps xmm14, [rsp+0xD0]
000078af20bdcfe8  vmovaps xmm15, [rsp+0xE0]
000078af20bdcff1  add rsp, 0xF0
000078af20bdcff8  pop r11
000078af20bdcffa  pop r10
000078af20bdcffc  pop r9
000078af20bdcffe  pop r8
000078af20bdd000  pop rsi
000078af20bdd001  pop rdi
000078af20bdd002  pop rdx
000078af20bdd003  pop rcx
000078af20bdd004  pop rax
000078af20bdd005  add rsp, 0x08
000078af20bdd009  jmp 0x000078AF20BD9568
000078af20bdd00e  sub rsp, 0x08
000078af20bdd012  push rax
000078af20bdd013  push rcx
000078af20bdd014  push rdx
000078af20bdd015  push rdi
000078af20bdd016  push rsi
000078af20bdd017  push r8
000078af20bdd019  push r9
000078af20bdd01b  push r10
000078af20bdd01d  push r11
000078af20bdd01f  sub rsp, 0xF0
000078af20bdd026  vmovaps [rsp], xmm0
000078af20bdd02b  vmovaps [rsp+0x10], xmm1
000078af20bdd031  vmovaps [rsp+0x20], xmm2
000078af20bdd037  vmovaps [rsp+0x30], xmm3
000078af20bdd03d  vmovaps [rsp+0x40], xmm4
000078af20bdd043  vmovaps [rsp+0x50], xmm5
000078af20bdd049  vmovaps [rsp+0x60], xmm6
000078af20bdd04f  vmovaps [rsp+0x70], xmm7
000078af20bdd055  vmovaps [rsp+0x80], xmm9
000078af20bdd05e  vmovaps [rsp+0x90], xmm10
000078af20bdd067  vmovaps [rsp+0xA0], xmm11
000078af20bdd070  vmovaps [rsp+0xB0], xmm12
000078af20bdd079  vmovaps [rsp+0xC0], xmm13
000078af20bdd082  vmovaps [rsp+0xD0], xmm14
000078af20bdd08b  vmovaps [rsp+0xE0], xmm15
000078af20bdd094  sub rsp, 0x30
000078af20bdd098  movaps [rsp], xmm8
000078af20bdd09d  movaps [rsp+0x10], xmm1
000078af20bdd0a2  movaps [rsp+0x20], xmm14
000078af20bdd0a8  lea rdi, [rsp]
000078af20bdd0ac  mov esi, 0x00
000078af20bdd0b1  mov rax, 0x65452FFB8530
000078af20bdd0bb  call rax
000078af20bdd0bd  movaps xmm8, [rsp]
000078af20bdd0c2  add rsp, 0x30
000078af20bdd0c6  vmovaps xmm0, [rsp]
000078af20bdd0cb  vmovaps xmm1, [rsp+0x10]
000078af20bdd0d1  vmovaps xmm2, [rsp+0x20]
000078af20bdd0d7  vmovaps xmm3, [rsp+0x30]
000078af20bdd0dd  vmovaps xmm4, [rsp+0x40]
000078af20bdd0e3  vmovaps xmm5, [rsp+0x50]
000078af20bdd0e9  vmovaps xmm6, [rsp+0x60]
000078af20bdd0ef  vmovaps xmm7, [rsp+0x70]
000078af20bdd0f5  vmovaps xmm9, [rsp+0x80]
000078af20bdd0fe  vmovaps xmm10, [rsp+0x90]
000078af20bdd107  vmovaps xmm11, [rsp+0xA0]
000078af20bdd110  vmovaps xmm12, [rsp+0xB0]
000078af20bdd119  vmovaps xmm13, [rsp+0xC0]
000078af20bdd122  vmovaps xmm14, [rsp+0xD0]
000078af20bdd12b  vmovaps xmm15, [rsp+0xE0]
000078af20bdd134  add rsp, 0xF0
000078af20bdd13b  pop r11
000078af20bdd13d  pop r10
000078af20bdd13f  pop r9
000078af20bdd141  pop r8
000078af20bdd143  pop rsi
000078af20bdd144  pop rdi
000078af20bdd145  pop rdx
000078af20bdd146  pop rcx
000078af20bdd147  pop rax
000078af20bdd148  add rsp, 0x08
000078af20bdd14c  jmp 0x000078AF20BD958E
000078af20bdd151  sub rsp, 0x08
000078af20bdd155  push rax
000078af20bdd156  push rcx
000078af20bdd157  push rdx
000078af20bdd158  push rdi
000078af20bdd159  push rsi
000078af20bdd15a  push r8
000078af20bdd15c  push r9
000078af20bdd15e  push r10
000078af20bdd160  push r11
000078af20bdd162  sub rsp, 0xF0
000078af20bdd169  vmovaps [rsp], xmm0
000078af20bdd16e  vmovaps [rsp+0x10], xmm1
000078af20bdd174  vmovaps [rsp+0x20], xmm2
000078af20bdd17a  vmovaps [rsp+0x30], xmm3
000078af20bdd180  vmovaps [rsp+0x40], xmm4
000078af20bdd186  vmovaps [rsp+0x50], xmm5
000078af20bdd18c  vmovaps [rsp+0x60], xmm7
000078af20bdd192  vmovaps [rsp+0x70], xmm8
000078af20bdd198  vmovaps [rsp+0x80], xmm9
000078af20bdd1a1  vmovaps [rsp+0x90], xmm10
000078af20bdd1aa  vmovaps [rsp+0xA0], xmm11
000078af20bdd1b3  vmovaps [rsp+0xB0], xmm12
000078af20bdd1bc  vmovaps [rsp+0xC0], xmm13
000078af20bdd1c5  vmovaps [rsp+0xD0], xmm14
000078af20bdd1ce  vmovaps [rsp+0xE0], xmm15
000078af20bdd1d7  sub rsp, 0x30
000078af20bdd1db  movaps [rsp], xmm6
000078af20bdd1df  movaps [rsp+0x10], xmm1
000078af20bdd1e4  movaps [rsp+0x20], xmm14
000078af20bdd1ea  lea rdi, [rsp]
000078af20bdd1ee  mov esi, 0x00
000078af20bdd1f3  mov rax, 0x65452FFB8530
000078af20bdd1fd  call rax
000078af20bdd1ff  movaps xmm6, [rsp]
000078af20bdd203  add rsp, 0x30
000078af20bdd207  vmovaps xmm0, [rsp]
000078af20bdd20c  vmovaps xmm1, [rsp+0x10]
000078af20bdd212  vmovaps xmm2, [rsp+0x20]
000078af20bdd218  vmovaps xmm3, [rsp+0x30]
000078af20bdd21e  vmovaps xmm4, [rsp+0x40]
000078af20bdd224  vmovaps xmm5, [rsp+0x50]
000078af20bdd22a  vmovaps xmm7, [rsp+0x60]
000078af20bdd230  vmovaps xmm8, [rsp+0x70]
000078af20bdd236  vmovaps xmm9, [rsp+0x80]
000078af20bdd23f  vmovaps xmm10, [rsp+0x90]
000078af20bdd248  vmovaps xmm11, [rsp+0xA0]
000078af20bdd251  vmovaps xmm12, [rsp+0xB0]
000078af20bdd25a  vmovaps xmm13, [rsp+0xC0]
000078af20bdd263  vmovaps xmm14, [rsp+0xD0]
000078af20bdd26c  vmovaps xmm15, [rsp+0xE0]
000078af20bdd275  add rsp, 0xF0
000078af20bdd27c  pop r11
000078af20bdd27e  pop r10
000078af20bdd280  pop r9
000078af20bdd282  pop r8
000078af20bdd284  pop rsi
000078af20bdd285  pop rdi
000078af20bdd286  pop rdx
000078af20bdd287  pop rcx
000078af20bdd288  pop rax
000078af20bdd289  add rsp, 0x08
000078af20bdd28d  jmp 0x000078AF20BD95BA
000078af20bdd292  sub rsp, 0x08
000078af20bdd296  push rax
000078af20bdd297  push rcx
000078af20bdd298  push rdx
000078af20bdd299  push rdi
000078af20bdd29a  push rsi
000078af20bdd29b  push r8
000078af20bdd29d  push r9
000078af20bdd29f  push r10
000078af20bdd2a1  push r11
000078af20bdd2a3  sub rsp, 0xF0
000078af20bdd2aa  vmovaps [rsp], xmm0
000078af20bdd2af  vmovaps [rsp+0x10], xmm1
000078af20bdd2b5  vmovaps [rsp+0x20], xmm2
000078af20bdd2bb  vmovaps [rsp+0x30], xmm3
000078af20bdd2c1  vmovaps [rsp+0x40], xmm4
000078af20bdd2c7  vmovaps [rsp+0x50], xmm5
000078af20bdd2cd  vmovaps [rsp+0x60], xmm6
000078af20bdd2d3  vmovaps [rsp+0x70], xmm7
000078af20bdd2d9  vmovaps [rsp+0x80], xmm8
000078af20bdd2e2  vmovaps [rsp+0x90], xmm9
000078af20bdd2eb  vmovaps [rsp+0xA0], xmm10
000078af20bdd2f4  vmovaps [rsp+0xB0], xmm11
000078af20bdd2fd  vmovaps [rsp+0xC0], xmm12
000078af20bdd306  vmovaps [rsp+0xD0], xmm13
000078af20bdd30f  vmovaps [rsp+0xE0], xmm15
000078af20bdd318  sub rsp, 0x30
000078af20bdd31c  movaps [rsp], xmm14
000078af20bdd321  movaps [rsp+0x10], xmm12
000078af20bdd327  movaps [rsp+0x20], xmm1
000078af20bdd32c  lea rdi, [rsp]
000078af20bdd330  mov esi, 0x00
000078af20bdd335  mov rax, 0x65452FFB8530
000078af20bdd33f  call rax
000078af20bdd341  movaps xmm14, [rsp]
000078af20bdd346  add rsp, 0x30
000078af20bdd34a  vmovaps xmm0, [rsp]
000078af20bdd34f  vmovaps xmm1, [rsp+0x10]
000078af20bdd355  vmovaps xmm2, [rsp+0x20]
000078af20bdd35b  vmovaps xmm3, [rsp+0x30]
000078af20bdd361  vmovaps xmm4, [rsp+0x40]
000078af20bdd367  vmovaps xmm5, [rsp+0x50]
000078af20bdd36d  vmovaps xmm6, [rsp+0x60]
000078af20bdd373  vmovaps xmm7, [rsp+0x70]
000078af20bdd379  vmovaps xmm8, [rsp+0x80]
000078af20bdd382  vmovaps xmm9, [rsp+0x90]
000078af20bdd38b  vmovaps xmm10, [rsp+0xA0]
000078af20bdd394  vmovaps xmm11, [rsp+0xB0]
000078af20bdd39d  vmovaps xmm12, [rsp+0xC0]
000078af20bdd3a6  vmovaps xmm13, [rsp+0xD0]
000078af20bdd3af  vmovaps xmm15, [rsp+0xE0]
000078af20bdd3b8  add rsp, 0xF0
000078af20bdd3bf  pop r11
000078af20bdd3c1  pop r10
000078af20bdd3c3  pop r9
000078af20bdd3c5  pop r8
000078af20bdd3c7  pop rsi
000078af20bdd3c8  pop rdi
000078af20bdd3c9  pop rdx
000078af20bdd3ca  pop rcx
000078af20bdd3cb  pop rax
000078af20bdd3cc  add rsp, 0x08
000078af20bdd3d0  jmp 0x000078AF20BD95E0
000078af20bdd3d5  sub rsp, 0x08
000078af20bdd3d9  push rax
000078af20bdd3da  push rcx
000078af20bdd3db  push rdx
000078af20bdd3dc  push rdi
000078af20bdd3dd  push rsi
000078af20bdd3de  push r8
000078af20bdd3e0  push r9
000078af20bdd3e2  push r10
000078af20bdd3e4  push r11
000078af20bdd3e6  sub rsp, 0xF0
000078af20bdd3ed  vmovaps [rsp], xmm0
000078af20bdd3f2  vmovaps [rsp+0x10], xmm2
000078af20bdd3f8  vmovaps [rsp+0x20], xmm3
000078af20bdd3fe  vmovaps [rsp+0x30], xmm4
000078af20bdd404  vmovaps [rsp+0x40], xmm5
000078af20bdd40a  vmovaps [rsp+0x50], xmm6
000078af20bdd410  vmovaps [rsp+0x60], xmm7
000078af20bdd416  vmovaps [rsp+0x70], xmm8
000078af20bdd41c  vmovaps [rsp+0x80], xmm9
000078af20bdd425  vmovaps [rsp+0x90], xmm10
000078af20bdd42e  vmovaps [rsp+0xA0], xmm11
000078af20bdd437  vmovaps [rsp+0xB0], xmm12
000078af20bdd440  vmovaps [rsp+0xC0], xmm13
000078af20bdd449  vmovaps [rsp+0xD0], xmm14
000078af20bdd452  vmovaps [rsp+0xE0], xmm15
000078af20bdd45b  sub rsp, 0x30
000078af20bdd45f  movaps [rsp], xmm1
000078af20bdd463  movaps [rsp+0x10], xmm13
000078af20bdd469  movaps [rsp+0x20], xmm9
000078af20bdd46f  lea rdi, [rsp]
000078af20bdd473  mov esi, 0x00
000078af20bdd478  mov rax, 0x65452FFB8530
000078af20bdd482  call rax
000078af20bdd484  movaps xmm1, [rsp]
000078af20bdd488  add rsp, 0x30
000078af20bdd48c  vmovaps xmm0, [rsp]
000078af20bdd491  vmovaps xmm2, [rsp+0x10]
000078af20bdd497  vmovaps xmm3, [rsp+0x20]
000078af20bdd49d  vmovaps xmm4, [rsp+0x30]
000078af20bdd4a3  vmovaps xmm5, [rsp+0x40]
000078af20bdd4a9  vmovaps xmm6, [rsp+0x50]
000078af20bdd4af  vmovaps xmm7, [rsp+0x60]
000078af20bdd4b5  vmovaps xmm8, [rsp+0x70]
000078af20bdd4bb  vmovaps xmm9, [rsp+0x80]
000078af20bdd4c4  vmovaps xmm10, [rsp+0x90]
000078af20bdd4cd  vmovaps xmm11, [rsp+0xA0]
000078af20bdd4d6  vmovaps xmm12, [rsp+0xB0]
000078af20bdd4df  vmovaps xmm13, [rsp+0xC0]
000078af20bdd4e8  vmovaps xmm14, [rsp+0xD0]
000078af20bdd4f1  vmovaps xmm15, [rsp+0xE0]
000078af20bdd4fa  add rsp, 0xF0
000078af20bdd501  pop r11
000078af20bdd503  pop r10
000078af20bdd505  pop r9
000078af20bdd507  pop r8
000078af20bdd509  pop rsi
000078af20bdd50a  pop rdi
000078af20bdd50b  pop rdx
000078af20bdd50c  pop rcx
000078af20bdd50d  pop rax
000078af20bdd50e  add rsp, 0x08
000078af20bdd512  jmp 0x000078AF20BD95FA
000078af20bdd517  sub rsp, 0x08
000078af20bdd51b  push rax
000078af20bdd51c  push rcx
000078af20bdd51d  push rdx
000078af20bdd51e  push rdi
000078af20bdd51f  push rsi
000078af20bdd520  push r8
000078af20bdd522  push r9
000078af20bdd524  push r10
000078af20bdd526  push r11
000078af20bdd528  sub rsp, 0xF0
000078af20bdd52f  vmovaps [rsp], xmm0
000078af20bdd534  vmovaps [rsp+0x10], xmm1
000078af20bdd53a  vmovaps [rsp+0x20], xmm2
000078af20bdd540  vmovaps [rsp+0x30], xmm3
000078af20bdd546  vmovaps [rsp+0x40], xmm4
000078af20bdd54c  vmovaps [rsp+0x50], xmm5
000078af20bdd552  vmovaps [rsp+0x60], xmm6
000078af20bdd558  vmovaps [rsp+0x70], xmm7
000078af20bdd55e  vmovaps [rsp+0x80], xmm8
000078af20bdd567  vmovaps [rsp+0x90], xmm9
000078af20bdd570  vmovaps [rsp+0xA0], xmm10
000078af20bdd579  vmovaps [rsp+0xB0], xmm11
000078af20bdd582  vmovaps [rsp+0xC0], xmm13
000078af20bdd58b  vmovaps [rsp+0xD0], xmm14
000078af20bdd594  vmovaps [rsp+0xE0], xmm15
000078af20bdd59d  sub rsp, 0x30
000078af20bdd5a1  movaps [rsp], xmm12
000078af20bdd5a6  movaps [rsp+0x10], xmm7
000078af20bdd5ab  movaps [rsp+0x20], xmm13
000078af20bdd5b1  lea rdi, [rsp]
000078af20bdd5b5  mov esi, 0x00
000078af20bdd5ba  mov rax, 0x65452FFB8530
000078af20bdd5c4  call rax
000078af20bdd5c6  movaps xmm12, [rsp]
000078af20bdd5cb  add rsp, 0x30
000078af20bdd5cf  vmovaps xmm0, [rsp]
000078af20bdd5d4  vmovaps xmm1, [rsp+0x10]
000078af20bdd5da  vmovaps xmm2, [rsp+0x20]
000078af20bdd5e0  vmovaps xmm3, [rsp+0x30]
000078af20bdd5e6  vmovaps xmm4, [rsp+0x40]
000078af20bdd5ec  vmovaps xmm5, [rsp+0x50]
000078af20bdd5f2  vmovaps xmm6, [rsp+0x60]
000078af20bdd5f8  vmovaps xmm7, [rsp+0x70]
000078af20bdd5fe  vmovaps xmm8, [rsp+0x80]
000078af20bdd607  vmovaps xmm9, [rsp+0x90]
000078af20bdd610  vmovaps xmm10, [rsp+0xA0]
000078af20bdd619  vmovaps xmm11, [rsp+0xB0]
000078af20bdd622  vmovaps xmm13, [rsp+0xC0]
000078af20bdd62b  vmovaps xmm14, [rsp+0xD0]
000078af20bdd634  vmovaps xmm15, [rsp+0xE0]
000078af20bdd63d  add rsp, 0xF0
000078af20bdd644  pop r11
000078af20bdd646  pop r10
000078af20bdd648  pop r9
000078af20bdd64a  pop r8
000078af20bdd64c  pop rsi
000078af20bdd64d  pop rdi
000078af20bdd64e  pop rdx
000078af20bdd64f  pop rcx
000078af20bdd650  pop rax
000078af20bdd651  add rsp, 0x08
000078af20bdd655  jmp 0x000078AF20BD9621
000078af20bdd65a  sub rsp, 0x08
000078af20bdd65e  push rax
000078af20bdd65f  push rcx
000078af20bdd660  push rdx
000078af20bdd661  push rdi
000078af20bdd662  push rsi
000078af20bdd663  push r8
000078af20bdd665  push r9
000078af20bdd667  push r10
000078af20bdd669  push r11
000078af20bdd66b  sub rsp, 0xF0
000078af20bdd672  vmovaps [rsp], xmm0
000078af20bdd677  vmovaps [rsp+0x10], xmm1
000078af20bdd67d  vmovaps [rsp+0x20], xmm2
000078af20bdd683  vmovaps [rsp+0x30], xmm3
000078af20bdd689  vmovaps [rsp+0x40], xmm4
000078af20bdd68f  vmovaps [rsp+0x50], xmm5
000078af20bdd695  vmovaps [rsp+0x60], xmm6
000078af20bdd69b  vmovaps [rsp+0x70], xmm7
000078af20bdd6a1  vmovaps [rsp+0x80], xmm8
000078af20bdd6aa  vmovaps [rsp+0x90], xmm9
000078af20bdd6b3  vmovaps [rsp+0xA0], xmm10
000078af20bdd6bc  vmovaps [rsp+0xB0], xmm11
000078af20bdd6c5  vmovaps [rsp+0xC0], xmm12
000078af20bdd6ce  vmovaps [rsp+0xD0], xmm14
000078af20bdd6d7  vmovaps [rsp+0xE0], xmm15
000078af20bdd6e0  sub rsp, 0x30
000078af20bdd6e4  movaps [rsp], xmm13
000078af20bdd6e9  movaps [rsp+0x10], xmm15
000078af20bdd6ef  movaps [rsp+0x20], xmm8
000078af20bdd6f5  lea rdi, [rsp]
000078af20bdd6f9  mov esi, 0x00
000078af20bdd6fe  mov rax, 0x65452FFB8530
000078af20bdd708  call rax
000078af20bdd70a  movaps xmm13, [rsp]
000078af20bdd70f  add rsp, 0x30
000078af20bdd713  vmovaps xmm0, [rsp]
000078af20bdd718  vmovaps xmm1, [rsp+0x10]
000078af20bdd71e  vmovaps xmm2, [rsp+0x20]
000078af20bdd724  vmovaps xmm3, [rsp+0x30]
000078af20bdd72a  vmovaps xmm4, [rsp+0x40]
000078af20bdd730  vmovaps xmm5, [rsp+0x50]
000078af20bdd736  vmovaps xmm6, [rsp+0x60]
000078af20bdd73c  vmovaps xmm7, [rsp+0x70]
000078af20bdd742  vmovaps xmm8, [rsp+0x80]
000078af20bdd74b  vmovaps xmm9, [rsp+0x90]
000078af20bdd754  vmovaps xmm10, [rsp+0xA0]
000078af20bdd75d  vmovaps xmm11, [rsp+0xB0]
000078af20bdd766  vmovaps xmm12, [rsp+0xC0]
000078af20bdd76f  vmovaps xmm14, [rsp+0xD0]
000078af20bdd778  vmovaps xmm15, [rsp+0xE0]
000078af20bdd781  add rsp, 0xF0
000078af20bdd788  pop r11
000078af20bdd78a  pop r10
000078af20bdd78c  pop r9
000078af20bdd78e  pop r8
000078af20bdd790  pop rsi
000078af20bdd791  pop rdi
000078af20bdd792  pop rdx
000078af20bdd793  pop rcx
000078af20bdd794  pop rax
000078af20bdd795  add rsp, 0x08
000078af20bdd799  jmp 0x000078AF20BD963C
000078af20bdd79e  sub rsp, 0x08
000078af20bdd7a2  push rax
000078af20bdd7a3  push rcx
000078af20bdd7a4  push rdx
000078af20bdd7a5  push rdi
000078af20bdd7a6  push rsi
000078af20bdd7a7  push r8
000078af20bdd7a9  push r9
000078af20bdd7ab  push r10
000078af20bdd7ad  push r11
000078af20bdd7af  sub rsp, 0xF0
000078af20bdd7b6  vmovaps [rsp], xmm0
000078af20bdd7bb  vmovaps [rsp+0x10], xmm1
000078af20bdd7c1  vmovaps [rsp+0x20], xmm2
000078af20bdd7c7  vmovaps [rsp+0x30], xmm3
000078af20bdd7cd  vmovaps [rsp+0x40], xmm4
000078af20bdd7d3  vmovaps [rsp+0x50], xmm5
000078af20bdd7d9  vmovaps [rsp+0x60], xmm6
000078af20bdd7df  vmovaps [rsp+0x70], xmm7
000078af20bdd7e5  vmovaps [rsp+0x80], xmm9
000078af20bdd7ee  vmovaps [rsp+0x90], xmm10
000078af20bdd7f7  vmovaps [rsp+0xA0], xmm11
000078af20bdd800  vmovaps [rsp+0xB0], xmm12
000078af20bdd809  vmovaps [rsp+0xC0], xmm13
000078af20bdd812  vmovaps [rsp+0xD0], xmm14
000078af20bdd81b  vmovaps [rsp+0xE0], xmm15
000078af20bdd824  sub rsp, 0x30
000078af20bdd828  movaps [rsp], xmm8
000078af20bdd82d  movaps [rsp+0x10], xmm15
000078af20bdd833  movaps [rsp+0x20], xmm9
000078af20bdd839  lea rdi, [rsp]
000078af20bdd83d  mov esi, 0x00
000078af20bdd842  mov rax, 0x65452FFB8530
000078af20bdd84c  call rax
000078af20bdd84e  movaps xmm8, [rsp]
000078af20bdd853  add rsp, 0x30
000078af20bdd857  vmovaps xmm0, [rsp]
000078af20bdd85c  vmovaps xmm1, [rsp+0x10]
000078af20bdd862  vmovaps xmm2, [rsp+0x20]
000078af20bdd868  vmovaps xmm3, [rsp+0x30]
000078af20bdd86e  vmovaps xmm4, [rsp+0x40]
000078af20bdd874  vmovaps xmm5, [rsp+0x50]
000078af20bdd87a  vmovaps xmm6, [rsp+0x60]
000078af20bdd880  vmovaps xmm7, [rsp+0x70]
000078af20bdd886  vmovaps xmm9, [rsp+0x80]
000078af20bdd88f  vmovaps xmm10, [rsp+0x90]
000078af20bdd898  vmovaps xmm11, [rsp+0xA0]
000078af20bdd8a1  vmovaps xmm12, [rsp+0xB0]
000078af20bdd8aa  vmovaps xmm13, [rsp+0xC0]
000078af20bdd8b3  vmovaps xmm14, [rsp+0xD0]
000078af20bdd8bc  vmovaps xmm15, [rsp+0xE0]
000078af20bdd8c5  add rsp, 0xF0
000078af20bdd8cc  pop r11
000078af20bdd8ce  pop r10
000078af20bdd8d0  pop r9
000078af20bdd8d2  pop r8
000078af20bdd8d4  pop rsi
000078af20bdd8d5  pop rdi
000078af20bdd8d6  pop rdx
000078af20bdd8d7  pop rcx
000078af20bdd8d8  pop rax
000078af20bdd8d9  add rsp, 0x08
000078af20bdd8dd  jmp 0x000078AF20BD966A
000078af20bdd8e2  sub rsp, 0x08
000078af20bdd8e6  push rax
000078af20bdd8e7  push rcx
000078af20bdd8e8  push rdx
000078af20bdd8e9  push rdi
000078af20bdd8ea  push rsi
000078af20bdd8eb  push r8
000078af20bdd8ed  push r9
000078af20bdd8ef  push r10
000078af20bdd8f1  push r11
000078af20bdd8f3  sub rsp, 0xF0
000078af20bdd8fa  vmovaps [rsp], xmm0
000078af20bdd8ff  vmovaps [rsp+0x10], xmm1
000078af20bdd905  vmovaps [rsp+0x20], xmm2
000078af20bdd90b  vmovaps [rsp+0x30], xmm3
000078af20bdd911  vmovaps [rsp+0x40], xmm4
000078af20bdd917  vmovaps [rsp+0x50], xmm5
000078af20bdd91d  vmovaps [rsp+0x60], xmm6
000078af20bdd923  vmovaps [rsp+0x70], xmm7
000078af20bdd929  vmovaps [rsp+0x80], xmm8
000078af20bdd932  vmovaps [rsp+0x90], xmm9
000078af20bdd93b  vmovaps [rsp+0xA0], xmm10
000078af20bdd944  vmovaps [rsp+0xB0], xmm11
000078af20bdd94d  vmovaps [rsp+0xC0], xmm12
000078af20bdd956  vmovaps [rsp+0xD0], xmm13
000078af20bdd95f  vmovaps [rsp+0xE0], xmm14
000078af20bdd968  sub rsp, 0x30
000078af20bdd96c  movaps [rsp], xmm15
000078af20bdd971  movaps [rsp+0x10], xmm11
000078af20bdd977  movaps [rsp+0x20], xmm6
000078af20bdd97c  lea rdi, [rsp]
000078af20bdd980  mov esi, 0x00
000078af20bdd985  mov rax, 0x65452FFB8530
000078af20bdd98f  call rax
000078af20bdd991  movaps xmm15, [rsp]
000078af20bdd996  add rsp, 0x30
000078af20bdd99a  vmovaps xmm0, [rsp]
000078af20bdd99f  vmovaps xmm1, [rsp+0x10]
000078af20bdd9a5  vmovaps xmm2, [rsp+0x20]
000078af20bdd9ab  vmovaps xmm3, [rsp+0x30]
000078af20bdd9b1  vmovaps xmm4, [rsp+0x40]
000078af20bdd9b7  vmovaps xmm5, [rsp+0x50]
000078af20bdd9bd  vmovaps xmm6, [rsp+0x60]
000078af20bdd9c3  vmovaps xmm7, [rsp+0x70]
000078af20bdd9c9  vmovaps xmm8, [rsp+0x80]
000078af20bdd9d2  vmovaps xmm9, [rsp+0x90]
000078af20bdd9db  vmovaps xmm10, [rsp+0xA0]
000078af20bdd9e4  vmovaps xmm11, [rsp+0xB0]
000078af20bdd9ed  vmovaps xmm12, [rsp+0xC0]
000078af20bdd9f6  vmovaps xmm13, [rsp+0xD0]
000078af20bdd9ff  vmovaps xmm14, [rsp+0xE0]
000078af20bdda08  add rsp, 0xF0
000078af20bdda0f  pop r11
000078af20bdda11  pop r10
000078af20bdda13  pop r9
000078af20bdda15  pop r8
000078af20bdda17  pop rsi
000078af20bdda18  pop rdi
000078af20bdda19  pop rdx
000078af20bdda1a  pop rcx
000078af20bdda1b  pop rax
000078af20bdda1c  add rsp, 0x08
000078af20bdda20  jmp 0x000078AF20BD9685
000078af20bdda25  sub rsp, 0x08
000078af20bdda29  push rax
000078af20bdda2a  push rcx
000078af20bdda2b  push rdx
000078af20bdda2c  push rdi
000078af20bdda2d  push rsi
000078af20bdda2e  push r8
000078af20bdda30  push r9
000078af20bdda32  push r10
000078af20bdda34  push r11
000078af20bdda36  sub rsp, 0xF0
000078af20bdda3d  vmovaps [rsp], xmm0
000078af20bdda42  vmovaps [rsp+0x10], xmm1
000078af20bdda48  vmovaps [rsp+0x20], xmm2
000078af20bdda4e  vmovaps [rsp+0x30], xmm3
000078af20bdda54  vmovaps [rsp+0x40], xmm4
000078af20bdda5a  vmovaps [rsp+0x50], xmm5
000078af20bdda60  vmovaps [rsp+0x60], xmm6
000078af20bdda66  vmovaps [rsp+0x70], xmm8
000078af20bdda6c  vmovaps [rsp+0x80], xmm9
000078af20bdda75  vmovaps [rsp+0x90], xmm10
000078af20bdda7e  vmovaps [rsp+0xA0], xmm11
000078af20bdda87  vmovaps [rsp+0xB0], xmm12
000078af20bdda90  vmovaps [rsp+0xC0], xmm13
000078af20bdda99  vmovaps [rsp+0xD0], xmm14
000078af20bddaa2  vmovaps [rsp+0xE0], xmm15
000078af20bddaab  sub rsp, 0x30
000078af20bddaaf  movaps [rsp], xmm7
000078af20bddab3  movaps [rsp+0x10], xmm11
000078af20bddab9  movaps [rsp+0x20], xmm9
000078af20bddabf  lea rdi, [rsp]
000078af20bddac3  mov esi, 0x00
000078af20bddac8  mov rax, 0x65452FFB8530
000078af20bddad2  call rax
000078af20bddad4  movaps xmm7, [rsp]
000078af20bddad8  add rsp, 0x30
000078af20bddadc  vmovaps xmm0, [rsp]
000078af20bddae1  vmovaps xmm1, [rsp+0x10]
000078af20bddae7  vmovaps xmm2, [rsp+0x20]
000078af20bddaed  vmovaps xmm3, [rsp+0x30]
000078af20bddaf3  vmovaps xmm4, [rsp+0x40]
000078af20bddaf9  vmovaps xmm5, [rsp+0x50]
000078af20bddaff  vmovaps xmm6, [rsp+0x60]
000078af20bddb05  vmovaps xmm8, [rsp+0x70]
000078af20bddb0b  vmovaps xmm9, [rsp+0x80]
000078af20bddb14  vmovaps xmm10, [rsp+0x90]
000078af20bddb1d  vmovaps xmm11, [rsp+0xA0]
000078af20bddb26  vmovaps xmm12, [rsp+0xB0]
000078af20bddb2f  vmovaps xmm13, [rsp+0xC0]
000078af20bddb38  vmovaps xmm14, [rsp+0xD0]
000078af20bddb41  vmovaps xmm15, [rsp+0xE0]
000078af20bddb4a  add rsp, 0xF0
000078af20bddb51  pop r11
000078af20bddb53  pop r10
000078af20bddb55  pop r9
000078af20bddb57  pop r8
000078af20bddb59  pop rsi
000078af20bddb5a  pop rdi
000078af20bddb5b  pop rdx
000078af20bddb5c  pop rcx
000078af20bddb5d  pop rax
000078af20bddb5e  add rsp, 0x08
000078af20bddb62  jmp 0x000078AF20BD96B2
000078af20bddb67  sub rsp, 0x08
000078af20bddb6b  push rax
000078af20bddb6c  push rcx
000078af20bddb6d  push rdx
000078af20bddb6e  push rdi
000078af20bddb6f  push rsi
000078af20bddb70  push r8
000078af20bddb72  push r9
000078af20bddb74  push r10
000078af20bddb76  push r11
000078af20bddb78  sub rsp, 0xF0
000078af20bddb7f  vmovaps [rsp], xmm0
000078af20bddb84  vmovaps [rsp+0x10], xmm1
000078af20bddb8a  vmovaps [rsp+0x20], xmm2
000078af20bddb90  vmovaps [rsp+0x30], xmm3
000078af20bddb96  vmovaps [rsp+0x40], xmm4
000078af20bddb9c  vmovaps [rsp+0x50], xmm5
000078af20bddba2  vmovaps [rsp+0x60], xmm6
000078af20bddba8  vmovaps [rsp+0x70], xmm7
000078af20bddbae  vmovaps [rsp+0x80], xmm8
000078af20bddbb7  vmovaps [rsp+0x90], xmm9
000078af20bddbc0  vmovaps [rsp+0xA0], xmm10
000078af20bddbc9  vmovaps [rsp+0xB0], xmm12
000078af20bddbd2  vmovaps [rsp+0xC0], xmm13
000078af20bddbdb  vmovaps [rsp+0xD0], xmm14
000078af20bddbe4  vmovaps [rsp+0xE0], xmm15
000078af20bddbed  sub rsp, 0x30
000078af20bddbf1  movaps [rsp], xmm11
000078af20bddbf6  movaps [rsp+0x10], xmm10
000078af20bddbfc  movaps [rsp+0x20], xmm14
000078af20bddc02  lea rdi, [rsp]
000078af20bddc06  mov esi, 0x00
000078af20bddc0b  mov rax, 0x65452FFB8530
000078af20bddc15  call rax
000078af20bddc17  movaps xmm11, [rsp]
000078af20bddc1c  add rsp, 0x30
000078af20bddc20  vmovaps xmm0, [rsp]
000078af20bddc25  vmovaps xmm1, [rsp+0x10]
000078af20bddc2b  vmovaps xmm2, [rsp+0x20]
000078af20bddc31  vmovaps xmm3, [rsp+0x30]
000078af20bddc37  vmovaps xmm4, [rsp+0x40]
000078af20bddc3d  vmovaps xmm5, [rsp+0x50]
000078af20bddc43  vmovaps xmm6, [rsp+0x60]
000078af20bddc49  vmovaps xmm7, [rsp+0x70]
000078af20bddc4f  vmovaps xmm8, [rsp+0x80]
000078af20bddc58  vmovaps xmm9, [rsp+0x90]
000078af20bddc61  vmovaps xmm10, [rsp+0xA0]
000078af20bddc6a  vmovaps xmm12, [rsp+0xB0]
000078af20bddc73  vmovaps xmm13, [rsp+0xC0]
000078af20bddc7c  vmovaps xmm14, [rsp+0xD0]
000078af20bddc85  vmovaps xmm15, [rsp+0xE0]
000078af20bddc8e  add rsp, 0xF0
000078af20bddc95  pop r11
000078af20bddc97  pop r10
000078af20bddc99  pop r9
000078af20bddc9b  pop r8
000078af20bddc9d  pop rsi
000078af20bddc9e  pop rdi
000078af20bddc9f  pop rdx
000078af20bddca0  pop rcx
000078af20bddca1  pop rax
000078af20bddca2  add rsp, 0x08
000078af20bddca6  jmp 0x000078AF20BD96CD
000078af20bddcab  call 0x000078AF20AE45A0
000078af20bddcb0  jmp 0x000078AF20BD96D7
000078af20bddcb5  sub rsp, 0x08
000078af20bddcb9  push rax
000078af20bddcba  push rcx
000078af20bddcbb  push rdx
000078af20bddcbc  push rdi
000078af20bddcbd  push rsi
000078af20bddcbe  push r8
000078af20bddcc0  push r9
000078af20bddcc2  push r10
000078af20bddcc4  push r11
000078af20bddcc6  sub rsp, 0xF0
000078af20bddccd  vmovaps [rsp], xmm0
000078af20bddcd2  vmovaps [rsp+0x10], xmm1
000078af20bddcd8  vmovaps [rsp+0x20], xmm2
000078af20bddcde  vmovaps [rsp+0x30], xmm3
000078af20bddce4  vmovaps [rsp+0x40], xmm4
000078af20bddcea  vmovaps [rsp+0x50], xmm5
000078af20bddcf0  vmovaps [rsp+0x60], xmm6
000078af20bddcf6  vmovaps [rsp+0x70], xmm7
000078af20bddcfc  vmovaps [rsp+0x80], xmm8
000078af20bddd05  vmovaps [rsp+0x90], xmm9
000078af20bddd0e  vmovaps [rsp+0xA0], xmm11
000078af20bddd17  vmovaps [rsp+0xB0], xmm12
000078af20bddd20  vmovaps [rsp+0xC0], xmm13
000078af20bddd29  vmovaps [rsp+0xD0], xmm14
000078af20bddd32  vmovaps [rsp+0xE0], xmm15
000078af20bddd3b  sub rsp, 0x30
000078af20bddd3f  movaps [rsp], xmm10
000078af20bddd44  movaps [rsp+0x10], xmm1
000078af20bddd49  movaps [rsp+0x20], xmm12
000078af20bddd4f  lea rdi, [rsp]
000078af20bddd53  mov esi, 0x00
000078af20bddd58  mov rax, 0x65452FFB8530
000078af20bddd62  call rax
000078af20bddd64  movaps xmm10, [rsp]
000078af20bddd69  add rsp, 0x30
000078af20bddd6d  vmovaps xmm0, [rsp]
000078af20bddd72  vmovaps xmm1, [rsp+0x10]
000078af20bddd78  vmovaps xmm2, [rsp+0x20]
000078af20bddd7e  vmovaps xmm3, [rsp+0x30]
000078af20bddd84  vmovaps xmm4, [rsp+0x40]
000078af20bddd8a  vmovaps xmm5, [rsp+0x50]
000078af20bddd90  vmovaps xmm6, [rsp+0x60]
000078af20bddd96  vmovaps xmm7, [rsp+0x70]
000078af20bddd9c  vmovaps xmm8, [rsp+0x80]
000078af20bddda5  vmovaps xmm9, [rsp+0x90]
000078af20bdddae  vmovaps xmm11, [rsp+0xA0]
000078af20bdddb7  vmovaps xmm12, [rsp+0xB0]
000078af20bdddc0  vmovaps xmm13, [rsp+0xC0]
000078af20bdddc9  vmovaps xmm14, [rsp+0xD0]
000078af20bdddd2  vmovaps xmm15, [rsp+0xE0]
000078af20bddddb  add rsp, 0xF0
000078af20bddde2  pop r11
000078af20bddde4  pop r10
000078af20bddde6  pop r9
000078af20bddde8  pop r8
000078af20bdddea  pop rsi
000078af20bdddeb  pop rdi
000078af20bdddec  pop rdx
000078af20bddded  pop rcx
000078af20bdddee  pop rax
000078af20bdddef  add rsp, 0x08
000078af20bdddf3  jmp 0x000078AF20BD96FA
000078af20bdddf8  sub rsp, 0x08
000078af20bdddfc  push rax
000078af20bdddfd  push rcx
000078af20bdddfe  push rdx
000078af20bdddff  push rdi
000078af20bdde00  push rsi
000078af20bdde01  push r8
000078af20bdde03  push r9
000078af20bdde05  push r10
000078af20bdde07  push r11
000078af20bdde09  sub rsp, 0xF0
000078af20bdde10  vmovaps [rsp], xmm0
000078af20bdde15  vmovaps [rsp+0x10], xmm1
000078af20bdde1b  vmovaps [rsp+0x20], xmm2
000078af20bdde21  vmovaps [rsp+0x30], xmm3
000078af20bdde27  vmovaps [rsp+0x40], xmm4
000078af20bdde2d  vmovaps [rsp+0x50], xmm5
000078af20bdde33  vmovaps [rsp+0x60], xmm6
000078af20bdde39  vmovaps [rsp+0x70], xmm7
000078af20bdde3f  vmovaps [rsp+0x80], xmm8
000078af20bdde48  vmovaps [rsp+0x90], xmm9
000078af20bdde51  vmovaps [rsp+0xA0], xmm10
000078af20bdde5a  vmovaps [rsp+0xB0], xmm11
000078af20bdde63  vmovaps [rsp+0xC0], xmm13
000078af20bdde6c  vmovaps [rsp+0xD0], xmm14
000078af20bdde75  vmovaps [rsp+0xE0], xmm15
000078af20bdde7e  sub rsp, 0x30
000078af20bdde82  movaps [rsp], xmm12
000078af20bdde87  movaps [rsp+0x10], xmm14
000078af20bdde8d  movaps [rsp+0x20], xmm1
000078af20bdde92  lea rdi, [rsp]
000078af20bdde96  mov esi, 0x00
000078af20bdde9b  mov rax, 0x65452FFB8530
000078af20bddea5  call rax
000078af20bddea7  movaps xmm12, [rsp]
000078af20bddeac  add rsp, 0x30
000078af20bddeb0  vmovaps xmm0, [rsp]
000078af20bddeb5  vmovaps xmm1, [rsp+0x10]
000078af20bddebb  vmovaps xmm2, [rsp+0x20]
000078af20bddec1  vmovaps xmm3, [rsp+0x30]
000078af20bddec7  vmovaps xmm4, [rsp+0x40]
000078af20bddecd  vmovaps xmm5, [rsp+0x50]
000078af20bdded3  vmovaps xmm6, [rsp+0x60]
000078af20bdded9  vmovaps xmm7, [rsp+0x70]
000078af20bddedf  vmovaps xmm8, [rsp+0x80]
000078af20bddee8  vmovaps xmm9, [rsp+0x90]
000078af20bddef1  vmovaps xmm10, [rsp+0xA0]
000078af20bddefa  vmovaps xmm11, [rsp+0xB0]
000078af20bddf03  vmovaps xmm13, [rsp+0xC0]
000078af20bddf0c  vmovaps xmm14, [rsp+0xD0]
000078af20bddf15  vmovaps xmm15, [rsp+0xE0]
000078af20bddf1e  add rsp, 0xF0
000078af20bddf25  pop r11
000078af20bddf27  pop r10
000078af20bddf29  pop r9
000078af20bddf2b  pop r8
000078af20bddf2d  pop rsi
000078af20bddf2e  pop rdi
000078af20bddf2f  pop rdx
000078af20bddf30  pop rcx
000078af20bddf31  pop rax
000078af20bddf32  add rsp, 0x08
000078af20bddf36  jmp 0x000078AF20BD9729
000078af20bddf3b  sub rsp, 0x08
000078af20bddf3f  push rax
000078af20bddf40  push rcx
000078af20bddf41  push rdx
000078af20bddf42  push rdi
000078af20bddf43  push rsi
000078af20bddf44  push r8
000078af20bddf46  push r9
000078af20bddf48  push r10
000078af20bddf4a  push r11
000078af20bddf4c  sub rsp, 0xF0
000078af20bddf53  vmovaps [rsp], xmm0
000078af20bddf58  vmovaps [rsp+0x10], xmm1
000078af20bddf5e  vmovaps [rsp+0x20], xmm2
000078af20bddf64  vmovaps [rsp+0x30], xmm3
000078af20bddf6a  vmovaps [rsp+0x40], xmm4
000078af20bddf70  vmovaps [rsp+0x50], xmm5
000078af20bddf76  vmovaps [rsp+0x60], xmm6
000078af20bddf7c  vmovaps [rsp+0x70], xmm7
000078af20bddf82  vmovaps [rsp+0x80], xmm8
000078af20bddf8b  vmovaps [rsp+0x90], xmm9
000078af20bddf94  vmovaps [rsp+0xA0], xmm10
000078af20bddf9d  vmovaps [rsp+0xB0], xmm11
000078af20bddfa6  vmovaps [rsp+0xC0], xmm12
000078af20bddfaf  vmovaps [rsp+0xD0], xmm13
000078af20bddfb8  vmovaps [rsp+0xE0], xmm15
000078af20bddfc1  sub rsp, 0x30
000078af20bddfc5  movaps [rsp], xmm14
000078af20bddfca  movaps [rsp+0x10], xmm9
000078af20bddfd0  movaps [rsp+0x20], xmm1
000078af20bddfd5  lea rdi, [rsp]
000078af20bddfd9  mov esi, 0x00
000078af20bddfde  mov rax, 0x65452FFB8530
000078af20bddfe8  call rax
000078af20bddfea  movaps xmm14, [rsp]
000078af20bddfef  add rsp, 0x30
000078af20bddff3  vmovaps xmm0, [rsp]
000078af20bddff8  vmovaps xmm1, [rsp+0x10]
000078af20bddffe  vmovaps xmm2, [rsp+0x20]
000078af20bde004  vmovaps xmm3, [rsp+0x30]
000078af20bde00a  vmovaps xmm4, [rsp+0x40]
000078af20bde010  vmovaps xmm5, [rsp+0x50]
000078af20bde016  vmovaps xmm6, [rsp+0x60]
000078af20bde01c  vmovaps xmm7, [rsp+0x70]
000078af20bde022  vmovaps xmm8, [rsp+0x80]
000078af20bde02b  vmovaps xmm9, [rsp+0x90]
000078af20bde034  vmovaps xmm10, [rsp+0xA0]
000078af20bde03d  vmovaps xmm11, [rsp+0xB0]
000078af20bde046  vmovaps xmm12, [rsp+0xC0]
000078af20bde04f  vmovaps xmm13, [rsp+0xD0]
000078af20bde058  vmovaps xmm15, [rsp+0xE0]
000078af20bde061  add rsp, 0xF0
000078af20bde068  pop r11
000078af20bde06a  pop r10
000078af20bde06c  pop r9
000078af20bde06e  pop r8
000078af20bde070  pop rsi
000078af20bde071  pop rdi
000078af20bde072  pop rdx
000078af20bde073  pop rcx
000078af20bde074  pop rax
000078af20bde075  add rsp, 0x08
000078af20bde079  jmp 0x000078AF20BD9758
000078af20bde07e  sub rsp, 0x08
000078af20bde082  push rax
000078af20bde083  push rcx
000078af20bde084  push rdx
000078af20bde085  push rdi
000078af20bde086  push rsi
000078af20bde087  push r8
000078af20bde089  push r9
000078af20bde08b  push r10
000078af20bde08d  push r11
000078af20bde08f  sub rsp, 0xF0
000078af20bde096  vmovaps [rsp], xmm0
000078af20bde09b  vmovaps [rsp+0x10], xmm2
000078af20bde0a1  vmovaps [rsp+0x20], xmm3
000078af20bde0a7  vmovaps [rsp+0x30], xmm4
000078af20bde0ad  vmovaps [rsp+0x40], xmm5
000078af20bde0b3  vmovaps [rsp+0x50], xmm6
000078af20bde0b9  vmovaps [rsp+0x60], xmm7
000078af20bde0bf  vmovaps [rsp+0x70], xmm8
000078af20bde0c5  vmovaps [rsp+0x80], xmm9
000078af20bde0ce  vmovaps [rsp+0x90], xmm10
000078af20bde0d7  vmovaps [rsp+0xA0], xmm11
000078af20bde0e0  vmovaps [rsp+0xB0], xmm12
000078af20bde0e9  vmovaps [rsp+0xC0], xmm13
000078af20bde0f2  vmovaps [rsp+0xD0], xmm14
000078af20bde0fb  vmovaps [rsp+0xE0], xmm15
000078af20bde104  sub rsp, 0x30
000078af20bde108  movaps [rsp], xmm1
000078af20bde10c  movaps [rsp+0x10], xmm13
000078af20bde112  movaps [rsp+0x20], xmm8
000078af20bde118  lea rdi, [rsp]
000078af20bde11c  mov esi, 0x00
000078af20bde121  mov rax, 0x65452FFB8530
000078af20bde12b  call rax
000078af20bde12d  movaps xmm1, [rsp]
000078af20bde131  add rsp, 0x30
000078af20bde135  vmovaps xmm0, [rsp]
000078af20bde13a  vmovaps xmm2, [rsp+0x10]
000078af20bde140  vmovaps xmm3, [rsp+0x20]
000078af20bde146  vmovaps xmm4, [rsp+0x30]
000078af20bde14c  vmovaps xmm5, [rsp+0x40]
000078af20bde152  vmovaps xmm6, [rsp+0x50]
000078af20bde158  vmovaps xmm7, [rsp+0x60]
000078af20bde15e  vmovaps xmm8, [rsp+0x70]
000078af20bde164  vmovaps xmm9, [rsp+0x80]
000078af20bde16d  vmovaps xmm10, [rsp+0x90]
000078af20bde176  vmovaps xmm11, [rsp+0xA0]
000078af20bde17f  vmovaps xmm12, [rsp+0xB0]
000078af20bde188  vmovaps xmm13, [rsp+0xC0]
000078af20bde191  vmovaps xmm14, [rsp+0xD0]
000078af20bde19a  vmovaps xmm15, [rsp+0xE0]
000078af20bde1a3  add rsp, 0xF0
000078af20bde1aa  pop r11
000078af20bde1ac  pop r10
000078af20bde1ae  pop r9
000078af20bde1b0  pop r8
000078af20bde1b2  pop rsi
000078af20bde1b3  pop rdi
000078af20bde1b4  pop rdx
000078af20bde1b5  pop rcx
000078af20bde1b6  pop rax
000078af20bde1b7  add rsp, 0x08
000078af20bde1bb  jmp 0x000078AF20BD977A
000078af20bde1c0  call 0x000078AF20A0C260
000078af20bde1c5  jmp 0x000078AF20BD9788
000078af20bde1ca  call 0x000078AF20ADE950
000078af20bde1cf  jmp 0x000078AF20BD9792
000078af20bde1d4  sub rsp, 0x08
000078af20bde1d8  push rax
000078af20bde1d9  push rcx
000078af20bde1da  push rdx
000078af20bde1db  push rdi
000078af20bde1dc  push rsi
000078af20bde1dd  push r8
000078af20bde1df  push r9
000078af20bde1e1  push r10
000078af20bde1e3  push r11
000078af20bde1e5  sub rsp, 0xF0
000078af20bde1ec  vmovaps [rsp], xmm0
000078af20bde1f1  vmovaps [rsp+0x10], xmm1
000078af20bde1f7  vmovaps [rsp+0x20], xmm2
000078af20bde1fd  vmovaps [rsp+0x30], xmm3
000078af20bde203  vmovaps [rsp+0x40], xmm4
000078af20bde209  vmovaps [rsp+0x50], xmm5
000078af20bde20f  vmovaps [rsp+0x60], xmm6
000078af20bde215  vmovaps [rsp+0x70], xmm7
000078af20bde21b  vmovaps [rsp+0x80], xmm9
000078af20bde224  vmovaps [rsp+0x90], xmm10
000078af20bde22d  vmovaps [rsp+0xA0], xmm11
000078af20bde236  vmovaps [rsp+0xB0], xmm12
000078af20bde23f  vmovaps [rsp+0xC0], xmm13
000078af20bde248  vmovaps [rsp+0xD0], xmm14
000078af20bde251  vmovaps [rsp+0xE0], xmm15
000078af20bde25a  sub rsp, 0x30
000078af20bde25e  movaps [rsp], xmm8
000078af20bde263  movaps [rsp+0x10], xmm15
000078af20bde269  movaps [rsp+0x20], xmm7
000078af20bde26e  lea rdi, [rsp]
000078af20bde272  mov esi, 0x00
000078af20bde277  mov rax, 0x65452FFB8530
000078af20bde281  call rax
000078af20bde283  movaps xmm8, [rsp]
000078af20bde288  add rsp, 0x30
000078af20bde28c  vmovaps xmm0, [rsp]
000078af20bde291  vmovaps xmm1, [rsp+0x10]
000078af20bde297  vmovaps xmm2, [rsp+0x20]
000078af20bde29d  vmovaps xmm3, [rsp+0x30]
000078af20bde2a3  vmovaps xmm4, [rsp+0x40]
000078af20bde2a9  vmovaps xmm5, [rsp+0x50]
000078af20bde2af  vmovaps xmm6, [rsp+0x60]
000078af20bde2b5  vmovaps xmm7, [rsp+0x70]
000078af20bde2bb  vmovaps xmm9, [rsp+0x80]
000078af20bde2c4  vmovaps xmm10, [rsp+0x90]
000078af20bde2cd  vmovaps xmm11, [rsp+0xA0]
000078af20bde2d6  vmovaps xmm12, [rsp+0xB0]
000078af20bde2df  vmovaps xmm13, [rsp+0xC0]
000078af20bde2e8  vmovaps xmm14, [rsp+0xD0]
000078af20bde2f1  vmovaps xmm15, [rsp+0xE0]
000078af20bde2fa  add rsp, 0xF0
000078af20bde301  pop r11
000078af20bde303  pop r10
000078af20bde305  pop r9
000078af20bde307  pop r8
000078af20bde309  pop rsi
000078af20bde30a  pop rdi
000078af20bde30b  pop rdx
000078af20bde30c  pop rcx
000078af20bde30d  pop rax
000078af20bde30e  add rsp, 0x08
000078af20bde312  jmp 0x000078AF20BD97B4
000078af20bde317  sub rsp, 0x08
000078af20bde31b  push rax
000078af20bde31c  push rcx
000078af20bde31d  push rdx
000078af20bde31e  push rdi
000078af20bde31f  push rsi
000078af20bde320  push r8
000078af20bde322  push r9
000078af20bde324  push r10
000078af20bde326  push r11
000078af20bde328  sub rsp, 0xF0
000078af20bde32f  vmovaps [rsp], xmm0
000078af20bde334  vmovaps [rsp+0x10], xmm1
000078af20bde33a  vmovaps [rsp+0x20], xmm2
000078af20bde340  vmovaps [rsp+0x30], xmm3
000078af20bde346  vmovaps [rsp+0x40], xmm4
000078af20bde34c  vmovaps [rsp+0x50], xmm5
000078af20bde352  vmovaps [rsp+0x60], xmm6
000078af20bde358  vmovaps [rsp+0x70], xmm8
000078af20bde35e  vmovaps [rsp+0x80], xmm9
000078af20bde367  vmovaps [rsp+0x90], xmm10
000078af20bde370  vmovaps [rsp+0xA0], xmm11
000078af20bde379  vmovaps [rsp+0xB0], xmm12
000078af20bde382  vmovaps [rsp+0xC0], xmm13
000078af20bde38b  vmovaps [rsp+0xD0], xmm14
000078af20bde394  vmovaps [rsp+0xE0], xmm15
000078af20bde39d  sub rsp, 0x30
000078af20bde3a1  movaps [rsp], xmm7
000078af20bde3a5  movaps [rsp+0x10], xmm9
000078af20bde3ab  movaps [rsp+0x20], xmm15
000078af20bde3b1  lea rdi, [rsp]
000078af20bde3b5  mov esi, 0x00
000078af20bde3ba  mov rax, 0x65452FFB8530
000078af20bde3c4  call rax
000078af20bde3c6  movaps xmm7, [rsp]
000078af20bde3ca  add rsp, 0x30
000078af20bde3ce  vmovaps xmm0, [rsp]
000078af20bde3d3  vmovaps xmm1, [rsp+0x10]
000078af20bde3d9  vmovaps xmm2, [rsp+0x20]
000078af20bde3df  vmovaps xmm3, [rsp+0x30]
000078af20bde3e5  vmovaps xmm4, [rsp+0x40]
000078af20bde3eb  vmovaps xmm5, [rsp+0x50]
000078af20bde3f1  vmovaps xmm6, [rsp+0x60]
000078af20bde3f7  vmovaps xmm8, [rsp+0x70]
000078af20bde3fd  vmovaps xmm9, [rsp+0x80]
000078af20bde406  vmovaps xmm10, [rsp+0x90]
000078af20bde40f  vmovaps xmm11, [rsp+0xA0]
000078af20bde418  vmovaps xmm12, [rsp+0xB0]
000078af20bde421  vmovaps xmm13, [rsp+0xC0]
000078af20bde42a  vmovaps xmm14, [rsp+0xD0]
000078af20bde433  vmovaps xmm15, [rsp+0xE0]
000078af20bde43c  add rsp, 0xF0
000078af20bde443  pop r11
000078af20bde445  pop r10
000078af20bde447  pop r9
000078af20bde449  pop r8
000078af20bde44b  pop rsi
000078af20bde44c  pop rdi
000078af20bde44d  pop rdx
000078af20bde44e  pop rcx
000078af20bde44f  pop rax
000078af20bde450  add rsp, 0x08
000078af20bde454  jmp 0x000078AF20BD97E1
000078af20bde459  sub rsp, 0x08
000078af20bde45d  push rax
000078af20bde45e  push rcx
000078af20bde45f  push rdx
000078af20bde460  push rdi
000078af20bde461  push rsi
000078af20bde462  push r8
000078af20bde464  push r9
000078af20bde466  push r10
000078af20bde468  push r11
000078af20bde46a  sub rsp, 0xF0
000078af20bde471  vmovaps [rsp], xmm0
000078af20bde476  vmovaps [rsp+0x10], xmm1
000078af20bde47c  vmovaps [rsp+0x20], xmm2
000078af20bde482  vmovaps [rsp+0x30], xmm3
000078af20bde488  vmovaps [rsp+0x40], xmm4
000078af20bde48e  vmovaps [rsp+0x50], xmm5
000078af20bde494  vmovaps [rsp+0x60], xmm6
000078af20bde49a  vmovaps [rsp+0x70], xmm7
000078af20bde4a0  vmovaps [rsp+0x80], xmm8
000078af20bde4a9  vmovaps [rsp+0x90], xmm10
000078af20bde4b2  vmovaps [rsp+0xA0], xmm11
000078af20bde4bb  vmovaps [rsp+0xB0], xmm12
000078af20bde4c4  vmovaps [rsp+0xC0], xmm13
000078af20bde4cd  vmovaps [rsp+0xD0], xmm14
000078af20bde4d6  vmovaps [rsp+0xE0], xmm15
000078af20bde4df  sub rsp, 0x30
000078af20bde4e3  movaps [rsp], xmm9
000078af20bde4e8  movaps [rsp+0x10], xmm13
000078af20bde4ee  movaps [rsp+0x20], xmm15
000078af20bde4f4  lea rdi, [rsp]
000078af20bde4f8  mov esi, 0x00
000078af20bde4fd  mov rax, 0x65452FFB8530
000078af20bde507  call rax
000078af20bde509  movaps xmm9, [rsp]
000078af20bde50e  add rsp, 0x30
000078af20bde512  vmovaps xmm0, [rsp]
000078af20bde517  vmovaps xmm1, [rsp+0x10]
000078af20bde51d  vmovaps xmm2, [rsp+0x20]
000078af20bde523  vmovaps xmm3, [rsp+0x30]
000078af20bde529  vmovaps xmm4, [rsp+0x40]
000078af20bde52f  vmovaps xmm5, [rsp+0x50]
000078af20bde535  vmovaps xmm6, [rsp+0x60]
000078af20bde53b  vmovaps xmm7, [rsp+0x70]
000078af20bde541  vmovaps xmm8, [rsp+0x80]
000078af20bde54a  vmovaps xmm10, [rsp+0x90]
000078af20bde553  vmovaps xmm11, [rsp+0xA0]
000078af20bde55c  vmovaps xmm12, [rsp+0xB0]
000078af20bde565  vmovaps xmm13, [rsp+0xC0]
000078af20bde56e  vmovaps xmm14, [rsp+0xD0]
000078af20bde577  vmovaps xmm15, [rsp+0xE0]
000078af20bde580  add rsp, 0xF0
000078af20bde587  pop r11
000078af20bde589  pop r10
000078af20bde58b  pop r9
000078af20bde58d  pop r8
000078af20bde58f  pop rsi
000078af20bde590  pop rdi
000078af20bde591  pop rdx
000078af20bde592  pop rcx
000078af20bde593  pop rax
000078af20bde594  add rsp, 0x08
000078af20bde598  jmp 0x000078AF20BD980F
000078af20bde59d  sub rsp, 0x08
000078af20bde5a1  push rax
000078af20bde5a2  push rcx
000078af20bde5a3  push rdx
000078af20bde5a4  push rdi
000078af20bde5a5  push rsi
000078af20bde5a6  push r8
000078af20bde5a8  push r9
000078af20bde5aa  push r10
000078af20bde5ac  push r11
000078af20bde5ae  sub rsp, 0xF0
000078af20bde5b5  vmovaps [rsp], xmm0
000078af20bde5ba  vmovaps [rsp+0x10], xmm1
000078af20bde5c0  vmovaps [rsp+0x20], xmm2
000078af20bde5c6  vmovaps [rsp+0x30], xmm3
000078af20bde5cc  vmovaps [rsp+0x40], xmm4
000078af20bde5d2  vmovaps [rsp+0x50], xmm5
000078af20bde5d8  vmovaps [rsp+0x60], xmm6
000078af20bde5de  vmovaps [rsp+0x70], xmm7
000078af20bde5e4  vmovaps [rsp+0x80], xmm8
000078af20bde5ed  vmovaps [rsp+0x90], xmm9
000078af20bde5f6  vmovaps [rsp+0xA0], xmm10
000078af20bde5ff  vmovaps [rsp+0xB0], xmm11
000078af20bde608  vmovaps [rsp+0xC0], xmm12
000078af20bde611  vmovaps [rsp+0xD0], xmm13
000078af20bde61a  vmovaps [rsp+0xE0], xmm14
000078af20bde623  sub rsp, 0x30
000078af20bde627  movaps [rsp], xmm15
000078af20bde62c  movaps [rsp+0x10], xmm11
000078af20bde632  movaps [rsp+0x20], xmm12
000078af20bde638  lea rdi, [rsp]
000078af20bde63c  mov esi, 0x00
000078af20bde641  mov rax, 0x65452FFB8530
000078af20bde64b  call rax
000078af20bde64d  movaps xmm15, [rsp]
000078af20bde652  add rsp, 0x30
000078af20bde656  vmovaps xmm0, [rsp]
000078af20bde65b  vmovaps xmm1, [rsp+0x10]
000078af20bde661  vmovaps xmm2, [rsp+0x20]
000078af20bde667  vmovaps xmm3, [rsp+0x30]
000078af20bde66d  vmovaps xmm4, [rsp+0x40]
000078af20bde673  vmovaps xmm5, [rsp+0x50]
000078af20bde679  vmovaps xmm6, [rsp+0x60]
000078af20bde67f  vmovaps xmm7, [rsp+0x70]
000078af20bde685  vmovaps xmm8, [rsp+0x80]
000078af20bde68e  vmovaps xmm9, [rsp+0x90]
000078af20bde697  vmovaps xmm10, [rsp+0xA0]
000078af20bde6a0  vmovaps xmm11, [rsp+0xB0]
000078af20bde6a9  vmovaps xmm12, [rsp+0xC0]
000078af20bde6b2  vmovaps xmm13, [rsp+0xD0]
000078af20bde6bb  vmovaps xmm14, [rsp+0xE0]
000078af20bde6c4  add rsp, 0xF0
000078af20bde6cb  pop r11
000078af20bde6cd  pop r10
000078af20bde6cf  pop r9
000078af20bde6d1  pop r8
000078af20bde6d3  pop rsi
000078af20bde6d4  pop rdi
000078af20bde6d5  pop rdx
000078af20bde6d6  pop rcx
000078af20bde6d7  pop rax
000078af20bde6d8  add rsp, 0x08
000078af20bde6dc  jmp 0x000078AF20BD982A
000078af20bde6e1  sub rsp, 0x08
000078af20bde6e5  push rax
000078af20bde6e6  push rcx
000078af20bde6e7  push rdx
000078af20bde6e8  push rdi
000078af20bde6e9  push rsi
000078af20bde6ea  push r8
000078af20bde6ec  push r9
000078af20bde6ee  push r10
000078af20bde6f0  push r11
000078af20bde6f2  sub rsp, 0xF0
000078af20bde6f9  vmovaps [rsp], xmm0
000078af20bde6fe  vmovaps [rsp+0x10], xmm1
000078af20bde704  vmovaps [rsp+0x20], xmm2
000078af20bde70a  vmovaps [rsp+0x30], xmm3
000078af20bde710  vmovaps [rsp+0x40], xmm4
000078af20bde716  vmovaps [rsp+0x50], xmm5
000078af20bde71c  vmovaps [rsp+0x60], xmm6
000078af20bde722  vmovaps [rsp+0x70], xmm7
000078af20bde728  vmovaps [rsp+0x80], xmm8
000078af20bde731  vmovaps [rsp+0x90], xmm9
000078af20bde73a  vmovaps [rsp+0xA0], xmm10
000078af20bde743  vmovaps [rsp+0xB0], xmm11
000078af20bde74c  vmovaps [rsp+0xC0], xmm12
000078af20bde755  vmovaps [rsp+0xD0], xmm14
000078af20bde75e  vmovaps [rsp+0xE0], xmm15
000078af20bde767  sub rsp, 0x30
000078af20bde76b  movaps [rsp], xmm13
000078af20bde770  movaps [rsp+0x10], xmm10
000078af20bde776  movaps [rsp+0x20], xmm14
000078af20bde77c  lea rdi, [rsp]
000078af20bde780  mov esi, 0x00
000078af20bde785  mov rax, 0x65452FFB8530
000078af20bde78f  call rax
000078af20bde791  movaps xmm13, [rsp]
000078af20bde796  add rsp, 0x30
000078af20bde79a  vmovaps xmm0, [rsp]
000078af20bde79f  vmovaps xmm1, [rsp+0x10]
000078af20bde7a5  vmovaps xmm2, [rsp+0x20]
000078af20bde7ab  vmovaps xmm3, [rsp+0x30]
000078af20bde7b1  vmovaps xmm4, [rsp+0x40]
000078af20bde7b7  vmovaps xmm5, [rsp+0x50]
000078af20bde7bd  vmovaps xmm6, [rsp+0x60]
000078af20bde7c3  vmovaps xmm7, [rsp+0x70]
000078af20bde7c9  vmovaps xmm8, [rsp+0x80]
000078af20bde7d2  vmovaps xmm9, [rsp+0x90]
000078af20bde7db  vmovaps xmm10, [rsp+0xA0]
000078af20bde7e4  vmovaps xmm11, [rsp+0xB0]
000078af20bde7ed  vmovaps xmm12, [rsp+0xC0]
000078af20bde7f6  vmovaps xmm14, [rsp+0xD0]
000078af20bde7ff  vmovaps xmm15, [rsp+0xE0]
000078af20bde808  add rsp, 0xF0
000078af20bde80f  pop r11
000078af20bde811  pop r10
000078af20bde813  pop r9
000078af20bde815  pop r8
000078af20bde817  pop rsi
000078af20bde818  pop rdi
000078af20bde819  pop rdx
000078af20bde81a  pop rcx
000078af20bde81b  pop rax
000078af20bde81c  add rsp, 0x08
000078af20bde820  jmp 0x000078AF20BD984D
000078af20bde825  sub rsp, 0x08
000078af20bde829  push rax
000078af20bde82a  push rcx
000078af20bde82b  push rdx
000078af20bde82c  push rdi
000078af20bde82d  push rsi
000078af20bde82e  push r8
000078af20bde830  push r9
000078af20bde832  push r10
000078af20bde834  push r11
000078af20bde836  sub rsp, 0xF0
000078af20bde83d  vmovaps [rsp], xmm0
000078af20bde842  vmovaps [rsp+0x10], xmm1
000078af20bde848  vmovaps [rsp+0x20], xmm2
000078af20bde84e  vmovaps [rsp+0x30], xmm3
000078af20bde854  vmovaps [rsp+0x40], xmm4
000078af20bde85a  vmovaps [rsp+0x50], xmm5
000078af20bde860  vmovaps [rsp+0x60], xmm6
000078af20bde866  vmovaps [rsp+0x70], xmm7
000078af20bde86c  vmovaps [rsp+0x80], xmm8
000078af20bde875  vmovaps [rsp+0x90], xmm9
000078af20bde87e  vmovaps [rsp+0xA0], xmm10
000078af20bde887  vmovaps [rsp+0xB0], xmm11
000078af20bde890  vmovaps [rsp+0xC0], xmm12
000078af20bde899  vmovaps [rsp+0xD0], xmm13
000078af20bde8a2  vmovaps [rsp+0xE0], xmm15
000078af20bde8ab  sub rsp, 0x30
000078af20bde8af  movaps [rsp], xmm14
000078af20bde8b4  movaps [rsp+0x10], xmm1
000078af20bde8b9  movaps [rsp+0x20], xmm7
000078af20bde8be  lea rdi, [rsp]
000078af20bde8c2  mov esi, 0x00
000078af20bde8c7  mov rax, 0x65452FFB8530
000078af20bde8d1  call rax
000078af20bde8d3  movaps xmm14, [rsp]
000078af20bde8d8  add rsp, 0x30
000078af20bde8dc  vmovaps xmm0, [rsp]
000078af20bde8e1  vmovaps xmm1, [rsp+0x10]
000078af20bde8e7  vmovaps xmm2, [rsp+0x20]
000078af20bde8ed  vmovaps xmm3, [rsp+0x30]
000078af20bde8f3  vmovaps xmm4, [rsp+0x40]
000078af20bde8f9  vmovaps xmm5, [rsp+0x50]
000078af20bde8ff  vmovaps xmm6, [rsp+0x60]
000078af20bde905  vmovaps xmm7, [rsp+0x70]
000078af20bde90b  vmovaps xmm8, [rsp+0x80]
000078af20bde914  vmovaps xmm9, [rsp+0x90]
000078af20bde91d  vmovaps xmm10, [rsp+0xA0]
000078af20bde926  vmovaps xmm11, [rsp+0xB0]
000078af20bde92f  vmovaps xmm12, [rsp+0xC0]
000078af20bde938  vmovaps xmm13, [rsp+0xD0]
000078af20bde941  vmovaps xmm15, [rsp+0xE0]
000078af20bde94a  add rsp, 0xF0
000078af20bde951  pop r11
000078af20bde953  pop r10
000078af20bde955  pop r9
000078af20bde957  pop r8
000078af20bde959  pop rsi
000078af20bde95a  pop rdi
000078af20bde95b  pop rdx
000078af20bde95c  pop rcx
000078af20bde95d  pop rax
000078af20bde95e  add rsp, 0x08
000078af20bde962  jmp 0x000078AF20BD9870
000078af20bde967  sub rsp, 0x08
000078af20bde96b  push rax
000078af20bde96c  push rcx
000078af20bde96d  push rdx
000078af20bde96e  push rdi
000078af20bde96f  push rsi
000078af20bde970  push r8
000078af20bde972  push r9
000078af20bde974  push r10
000078af20bde976  push r11
000078af20bde978  sub rsp, 0xF0
000078af20bde97f  vmovaps [rsp], xmm0
000078af20bde984  vmovaps [rsp+0x10], xmm2
000078af20bde98a  vmovaps [rsp+0x20], xmm3
000078af20bde990  vmovaps [rsp+0x30], xmm4
000078af20bde996  vmovaps [rsp+0x40], xmm5
000078af20bde99c  vmovaps [rsp+0x50], xmm6
000078af20bde9a2  vmovaps [rsp+0x60], xmm7
000078af20bde9a8  vmovaps [rsp+0x70], xmm8
000078af20bde9ae  vmovaps [rsp+0x80], xmm9
000078af20bde9b7  vmovaps [rsp+0x90], xmm10
000078af20bde9c0  vmovaps [rsp+0xA0], xmm11
000078af20bde9c9  vmovaps [rsp+0xB0], xmm12
000078af20bde9d2  vmovaps [rsp+0xC0], xmm13
000078af20bde9db  vmovaps [rsp+0xD0], xmm14
000078af20bde9e4  vmovaps [rsp+0xE0], xmm15
000078af20bde9ed  sub rsp, 0x30
000078af20bde9f1  movaps [rsp], xmm1
000078af20bde9f5  movaps [rsp+0x10], xmm8
000078af20bde9fb  movaps [rsp+0x20], xmm9
000078af20bdea01  lea rdi, [rsp]
000078af20bdea05  mov esi, 0x00
000078af20bdea0a  mov rax, 0x65452FFB8530
000078af20bdea14  call rax
000078af20bdea16  movaps xmm1, [rsp]
000078af20bdea1a  add rsp, 0x30
000078af20bdea1e  vmovaps xmm0, [rsp]
000078af20bdea23  vmovaps xmm2, [rsp+0x10]
000078af20bdea29  vmovaps xmm3, [rsp+0x20]
000078af20bdea2f  vmovaps xmm4, [rsp+0x30]
000078af20bdea35  vmovaps xmm5, [rsp+0x40]
000078af20bdea3b  vmovaps xmm6, [rsp+0x50]
000078af20bdea41  vmovaps xmm7, [rsp+0x60]
000078af20bdea47  vmovaps xmm8, [rsp+0x70]
000078af20bdea4d  vmovaps xmm9, [rsp+0x80]
000078af20bdea56  vmovaps xmm10, [rsp+0x90]
000078af20bdea5f  vmovaps xmm11, [rsp+0xA0]
000078af20bdea68  vmovaps xmm12, [rsp+0xB0]
000078af20bdea71  vmovaps xmm13, [rsp+0xC0]
000078af20bdea7a  vmovaps xmm14, [rsp+0xD0]
000078af20bdea83  vmovaps xmm15, [rsp+0xE0]
000078af20bdea8c  add rsp, 0xF0
000078af20bdea93  pop r11
000078af20bdea95  pop r10
000078af20bdea97  pop r9
000078af20bdea99  pop r8
000078af20bdea9b  pop rsi
000078af20bdea9c  pop rdi
000078af20bdea9d  pop rdx
000078af20bdea9e  pop rcx
000078af20bdea9f  pop rax
000078af20bdeaa0  add rsp, 0x08
000078af20bdeaa4  jmp 0x000078AF20BD9892
000078af20bdeaa9  call 0x000078AF20AB3E40
000078af20bdeaae  jmp 0x000078AF20BD98A0
000078af20bdeab3  call 0x000078AF20A0C380
000078af20bdeab8  jmp 0x000078AF20BD98AA
000078af20bdeabd  call 0x000078AF20A0D600
000078af20bdeac2  jmp 0x000078AF20BD98B4
000078af20bdeac7  call 0x000078AF209FF540
000078af20bdeacc  jmp 0x000078AF20BD98BE
000078af20bdead1  int3
000078af20bdead2  nop [rax+rax*1], ax
000078af20bdeadb  nop [rax+rax*1], eax
000078af20bdeae0  mov eax, [r15+0x48]
000078af20bdeae4  lea r14d, [eax+0x01]
000078af20bdeae9  mov [rsp+0x10], r14d
000078af20bdeaee  mov r14d, r14d
000078af20bdeaf1  mov [r15+0x48], r14
000078af20bdeaf5  xor eax, eax
000078af20bdeaf7  mov r14d, [rsp+0x10]
000078af20bdeafc  cmp r14d, 0x1F4
000078af20bdeb03  cmc
000078af20bdeb04  lahf
000078af20bdeb05  seto al
000078af20bdeb08  mov [r15+0x108], eax
000078af20bdeb0f  mov eax, [r15+0x108]
000078af20bdeb16  sahf
000078af20bdeb17  jnz 0x000078AF20BDEB49
000078af20bdeb19  cmp dword ptr [r15+0x318], 0x00
000078af20bdeb21  jz 0x000078AF20BE4C90
000078af20bdeb27  nop [rax+rax*1], ax
000078af20bdeb30  nop [rax+rax*1], eax
000078af20bdeb38  mov eax, 0x4106DC
000078af20bdeb3d  mov [r15+0x100], rax
000078af20bdeb44  jmp 0x000078AF209FE110
000078af20bdeb49  cmp dword ptr [r15+0x318], 0x00
000078af20bdeb51  jz 0x000078AF20BDEB80
000078af20bdeb57  nop [rax+rax*1], ax
000078af20bdeb60  nop [rax+rax*1], eax
000078af20bdeb68  mov eax, 0x410500
000078af20bdeb6d  mov [r15+0x100], rax
000078af20bdeb74  jmp 0x000078AF209FE110
000078af20bdeb79  int3
000078af20bdeb7a  int3
000078af20bdeb7b  nop [rax+rax*1], eax
000078af20bdeb80  mov rax, [r15+0x40]
000078af20bdeb84  movaps xmm1, [r15+0x1D0]
000078af20bdeb8c  vmovaps [rsp+0x10], xmm1
000078af20bdeb92  vmovaps xmm15, [rsp+0x10]
000078af20bdeb98  por xmm1, xmm15
000078af20bdeb9d  movaps xmm14, [r15+0x1A0]
000078af20bdeba5  vmovaps [rsp+0x10], xmm14
000078af20bdebab  vmovaps xmm13, [rsp+0x10]
000078af20bdebb1  por xmm14, xmm13
000078af20bdebb6  lea r14, [rax+0x30]
000078af20bdebba  mov r12, [r13+r14*1]
000078af20bdebbf  lea r14, [rax+0x38]
000078af20bdebc3  mov r11, [r13+r14*1]
000078af20bdebc8  movq xmm13, r12
000078af20bdebcd  movq xmm12, r11
000078af20bdebd2  movq xmm13, xmm13
000078af20bdebd7  vmovaps [rsp+0x10], xmm13
000078af20bdebdd  movq xmm13, xmm13
000078af20bdebe2  movaps [r15+0x130], xmm13
000078af20bdebea  movq xmm12, xmm12
000078af20bdebef  vmovaps [rsp+0x20], xmm12
000078af20bdebf5  movq xmm12, xmm12
000078af20bdebfa  movaps [r15+0x280], xmm12
000078af20bdec02  movaps xmm13, [r15+0x270]
000078af20bdec0a  vmovaps [rsp+0x30], xmm13
000078af20bdec10  vmovaps xmm12, [rsp+0x30]
000078af20bdec16  por xmm13, xmm12
000078af20bdec1b  lea r14, [rax+0x20]
000078af20bdec1f  mov r12, [r13+r14*1]
000078af20bdec24  lea r14, [rax+0x28]
000078af20bdec28  mov r11, [r13+r14*1]
000078af20bdec2d  movq xmm12, r12
000078af20bdec32  movq xmm11, r11
000078af20bdec37  movq xmm12, xmm12
000078af20bdec3c  vmovaps [rsp+0x30], xmm12
000078af20bdec42  movq xmm12, xmm12
000078af20bdec47  movaps [r15+0x150], xmm12
000078af20bdec4f  movq xmm11, xmm11
000078af20bdec54  vmovaps [rsp+0x40], xmm11
000078af20bdec5a  movq xmm11, xmm11
000078af20bdec5f  movaps [r15+0x140], xmm11
000078af20bdec67  lea r14, [rax+0x10]
000078af20bdec6b  mov r12, [r13+r14*1]
000078af20bdec70  lea r14, [rax+0x18]
000078af20bdec74  mov r11, [r13+r14*1]
000078af20bdec79  movq xmm12, r12
000078af20bdec7e  movq xmm11, r11
000078af20bdec83  movq xmm12, xmm12
000078af20bdec88  vmovaps [rsp+0x50], xmm12
000078af20bdec8e  movq xmm12, xmm12
000078af20bdec93  movaps [r15+0x170], xmm12
000078af20bdec9b  movq xmm11, xmm11
000078af20bdeca0  vmovaps [rsp+0x60], xmm11
000078af20bdeca6  movq xmm11, xmm11
000078af20bdecab  movaps [r15+0x160], xmm11
000078af20bdecb3  mov r14, [r13+rax*1]
000078af20bdecb8  vmovq xmm12, r14
000078af20bdecbd  vpbroadcastq xmm12, xmm12
000078af20bdecc2  lea r14, [rax+0x08]
000078af20bdecc6  mov rax, [r13+r14*1]
000078af20bdeccb  movq xmm11, rax
000078af20bdecd0  movaps [r15+0x230], xmm11
000078af20bdecd8  mov rax, [r15+0xF8]
000078af20bdecdf  lea r14, [rax+0x50]
000078af20bdece3  movups xmm11, [r13+r14*1]
000078af20bdece9  lea r14, [rax+0x60]
000078af20bdeced  movups xmm10, [r13+r14*1]
000078af20bdecf3  lea r14, [rax+0x30]
000078af20bdecf7  movups xmm9, [r13+r14*1]
000078af20bdecfd  mov r14, [r15+0x50]
000078af20bded01  mov [r15+0x60], r14
000078af20bded05  mov qword ptr [r15+0x58], 0x40
000078af20bded0d  movaps xmm8, xmm12
000078af20bded11  mulpd xmm8, xmm15
000078af20bded16  vcmppd xmm7, xmm8, xmm8, 0x03
000078af20bded1c  ptest xmm7, xmm7
000078af20bded21  jnz 0x000078AF20BDFB4A
000078af20bded27  movq xmm15, qword ptr [r15+0x230]
000078af20bded30  vmovaps [rsp+0x70], xmm15
000078af20bded36  vpermilpd xmm15, xmm15, 0x00
000078af20bded3c  movaps xmm7, xmm9
000078af20bded40  mulpd xmm7, xmm15
000078af20bded45  vcmppd xmm6, xmm7, xmm7, 0x03
000078af20bded4a  ptest xmm6, xmm6
000078af20bded4f  jnz 0x000078AF20BDFC8E
000078af20bded55  vxorps xmm15, xmm15, xmm15
000078af20bded5a  vpbroadcastq xmm15, xmm15
000078af20bded5f  movaps xmm9, xmm12
000078af20bded63  mulpd xmm9, xmm10
000078af20bded68  vcmppd xmm6, xmm9, xmm9, 0x03
000078af20bded6e  ptest xmm6, xmm6
000078af20bded73  jnz 0x000078AF20BDFDD0
000078af20bded79  movaps xmm10, xmm12
000078af20bded7d  mulpd xmm10, xmm11
000078af20bded82  vcmppd xmm6, xmm10, xmm10, 0x03
000078af20bded88  ptest xmm6, xmm6
000078af20bded8d  jnz 0x000078AF20BDFF14
000078af20bded93  movaps xmm11, [r15+0x1F0]
000078af20bded9b  movaps xmm6, xmm12
000078af20bded9f  mulpd xmm6, xmm11
000078af20bdeda4  vcmppd xmm5, xmm6, xmm6, 0x03
000078af20bdeda9  ptest xmm5, xmm5
000078af20bdedae  jnz 0x000078AF20BE0058
000078af20bdedb4  movaps xmm12, [r15+0x2A0]
000078af20bdedbc  vmovaps [rsp+0x80], xmm12
000078af20bdedc5  vmovaps xmm11, [rsp+0x80]
000078af20bdedce  por xmm12, xmm11
000078af20bdedd3  movaps xmm11, [r15+0x250]
000078af20bdeddb  vmovaps [rsp+0x80], xmm11
000078af20bdede4  vmovaps xmm5, [rsp+0x80]
000078af20bdeded  por xmm11, xmm5
000078af20bdedf2  vmovaps xmm4, [rsp+0x70]
000078af20bdedf8  vpermilpd xmm4, xmm4, 0x00
000078af20bdedfe  movaps xmm3, xmm5
000078af20bdee01  mulpd xmm3, xmm4
000078af20bdee05  vcmppd xmm2, xmm3, xmm3, 0x03
000078af20bdee0a  ptest xmm2, xmm2
000078af20bdee0f  jnz 0x000078AF20BE019A
000078af20bdee15  mov [rsp+0x80], rax
000078af20bdee1d  xor eax, eax
000078af20bdee1f  mov r12d, 0x40
000078af20bdee25  mov r11d, 0x200
000078af20bdee2b  cmp r12, r11
000078af20bdee2e  cmc
000078af20bdee2f  lahf
000078af20bdee30  seto al
000078af20bdee33  mov [r15+0x108], eax
000078af20bdee3a  movaps xmm5, xmm8
000078af20bdee3e  addpd xmm5, xmm15
000078af20bdee43  vcmppd xmm4, xmm5, xmm5, 0x03
000078af20bdee48  ptest xmm4, xmm4
000078af20bdee4d  jnz 0x000078AF20BE02DA
000078af20bdee53  movaps xmm8, [r15+0x1B0]
000078af20bdee5b  movaps xmm4, xmm9
000078af20bdee5f  addpd xmm4, xmm8
000078af20bdee64  vcmppd xmm2, xmm4, xmm4, 0x03
000078af20bdee69  ptest xmm2, xmm2
000078af20bdee6e  jnz 0x000078AF20BE041C
000078af20bdee74  movaps xmm9, xmm10
000078af20bdee78  addpd xmm9, xmm8
000078af20bdee7d  vcmppd xmm2, xmm9, xmm9, 0x03
000078af20bdee83  ptest xmm2, xmm2
000078af20bdee88  jnz 0x000078AF20BE055E
000078af20bdee8e  movaps xmm10, [r15+0x2F0]
000078af20bdee96  vmovaps [rsp+0x90], xmm10
000078af20bdee9f  vmovaps xmm8, [rsp+0x90]
000078af20bdeea8  por xmm10, xmm8
000078af20bdeead  movaps xmm8, [r15+0x2E0]
000078af20bdeeb5  vmovaps [rsp+0x90], xmm8
000078af20bdeebe  vmovaps xmm2, [rsp+0x90]
000078af20bdeec7  por xmm8, xmm2
000078af20bdeecc  movaps xmm2, [r15+0x2D0]
000078af20bdeed4  vmovaps [rsp+0x90], xmm2
000078af20bdeedd  vmovaps [rsp+0xA0], xmm1
000078af20bdeee6  vmovaps xmm1, [rsp+0x90]
000078af20bdeeef  por xmm2, xmm1
000078af20bdeef3  movaps xmm1, [r15+0x200]
000078af20bdeefb  vmovaps [rsp+0x90], xmm1
000078af20bdef04  vmovaps [rsp+0xB0], xmm15
000078af20bdef0d  vmovaps xmm15, [rsp+0x90]
000078af20bdef16  por xmm1, xmm15
000078af20bdef1b  movaps xmm15, [r15+0x1C0]
000078af20bdef23  vmovaps [rsp+0x90], xmm15
000078af20bdef2c  vmovaps [rsp+0xC0], xmm1
000078af20bdef35  vmovaps xmm1, [rsp+0x90]
000078af20bdef3e  por xmm15, xmm1
000078af20bdef43  movaps xmm1, [r15+0x190]
000078af20bdef4b  vmovaps [rsp+0x90], xmm1
000078af20bdef54  vmovaps [rsp+0xD0], xmm15
000078af20bdef5d  vmovaps xmm15, [rsp+0x90]
000078af20bdef66  por xmm1, xmm15
000078af20bdef6b  movaps xmm15, [r15+0x300]
000078af20bdef73  vmovaps [rsp+0x90], xmm15
000078af20bdef7c  vmovaps [rsp+0xE0], xmm1
000078af20bdef85  vmovaps xmm1, [rsp+0x90]
000078af20bdef8e  por xmm15, xmm1
000078af20bdef93  mov rax, [rsp+0x80]
000078af20bdef9b  lea r12, [rax+0xA0]
000078af20bdefa2  movups xmm1, [r13+r12*1]
000078af20bdefa8  lea r12, [rax+0xB0]
000078af20bdefaf  vmovaps [rsp+0x80], xmm1
000078af20bdefb8  movups xmm1, [r13+r12*1]
000078af20bdefbe  vmovaps [rsp+0x90], xmm1
000078af20bdefc7  vmovaps [rsp+0xF0], xmm15
000078af20bdefd0  vmovaps xmm15, [rsp+0xB0]
000078af20bdefd9  vmovaps [rsp+0xB0], xmm14
000078af20bdefe2  movaps xmm1, xmm6
000078af20bdefe5  addpd xmm1, xmm15
000078af20bdefea  vcmppd xmm14, xmm1, xmm1, 0x03
000078af20bdefef  ptest xmm14, xmm14
000078af20bdeff5  jnz 0x000078AF20BE06B6
000078af20bdeffb  lea r12, [rax+0xF0]
000078af20bdf002  movups xmm15, [r13+r12*1]
000078af20bdf008  movaps xmm14, xmm4
000078af20bdf00c  addpd xmm14, xmm3
000078af20bdf011  vcmppd xmm6, xmm14, xmm14, 0x03
000078af20bdf017  ptest xmm6, xmm6
000078af20bdf01c  jnz 0x000078AF20BE0801
000078af20bdf022  movaps xmm6, xmm9
000078af20bdf026  addpd xmm6, xmm7
000078af20bdf02a  vcmppd xmm4, xmm6, xmm6, 0x03
000078af20bdf02f  ptest xmm4, xmm4
000078af20bdf034  jnz 0x000078AF20BE0943
000078af20bdf03a  vmovaps xmm9, [rsp+0x70]
000078af20bdf040  vpermilpd xmm9, xmm9, 0x00
000078af20bdf046  vmovaps xmm4, [rsp+0x90]
000078af20bdf04f  movaps xmm7, xmm4
000078af20bdf052  mulpd xmm7, xmm9
000078af20bdf057  vcmppd xmm3, xmm7, xmm7, 0x03
000078af20bdf05c  ptest xmm3, xmm3
000078af20bdf061  jnz 0x000078AF20BE0A84
000078af20bdf067  vmovaps xmm9, [rsp+0x50]
000078af20bdf06d  vpermilpd xmm9, xmm9, 0x00
000078af20bdf073  movaps xmm4, xmm15
000078af20bdf077  mulpd xmm4, xmm9
000078af20bdf07c  vcmppd xmm3, xmm4, xmm4, 0x03
000078af20bdf081  ptest xmm3, xmm3
000078af20bdf086  jnz 0x000078AF20BE0BC5
000078af20bdf08c  lea r12, [rax+0xE0]
000078af20bdf093  movups xmm15, [r13+r12*1]
000078af20bdf099  vmovaps xmm9, [rsp+0x70]
000078af20bdf09f  vpermilpd xmm9, xmm9, 0x00
000078af20bdf0a5  vmovaps [rsp+0x70], xmm1
000078af20bdf0ab  vmovaps xmm1, [rsp+0x80]
000078af20bdf0b4  vmovaps [rsp+0x80], xmm15
000078af20bdf0bd  movaps xmm3, xmm1
000078af20bdf0c0  mulpd xmm3, xmm9
000078af20bdf0c5  vcmppd xmm15, xmm3, xmm3, 0x03
000078af20bdf0ca  ptest xmm15, xmm15
000078af20bdf0d0  jnz 0x000078AF20BE0D11
000078af20bdf0d6  vmovaps xmm1, [rsp+0xF0]
000078af20bdf0df  vmovaps xmm15, [rsp+0xF0]
000078af20bdf0e8  por xmm1, xmm15
000078af20bdf0ed  movaps [r15+0x300], xmm1
000078af20bdf0f5  vmovaps xmm15, [rsp+0xE0]
000078af20bdf0fe  vmovaps xmm9, [rsp+0xE0]
000078af20bdf107  por xmm15, xmm9
000078af20bdf10c  movaps [r15+0x190], xmm15
000078af20bdf114  vmovaps xmm9, [rsp+0x50]
000078af20bdf11a  vpermilpd xmm9, xmm9, 0x00
000078af20bdf120  vmovaps [rsp+0x90], xmm1
000078af20bdf129  vmovaps [rsp+0xE0], xmm15
000078af20bdf132  vmovaps xmm15, [rsp+0x80]
000078af20bdf13b  vmovaps [rsp+0x80], xmm14
000078af20bdf144  movaps xmm1, xmm15
000078af20bdf148  mulpd xmm1, xmm9
000078af20bdf14d  vcmppd xmm14, xmm1, xmm1, 0x03
000078af20bdf152  ptest xmm14, xmm14
000078af20bdf158  jnz 0x000078AF20BE0E52
000078af20bdf15e  lea r12, [rax+0x90]
000078af20bdf165  movups xmm15, [r13+r12*1]
000078af20bdf16b  vmovaps xmm14, [rsp+0xD0]
000078af20bdf174  vmovaps xmm9, [rsp+0xD0]
000078af20bdf17d  por xmm14, xmm9
000078af20bdf182  movaps [r15+0x1C0], xmm14
000078af20bdf18a  vmovaps xmm9, [rsp+0xC0]
000078af20bdf193  vmovaps [rsp+0xD0], xmm1
000078af20bdf19c  vmovaps xmm1, [rsp+0xC0]
000078af20bdf1a5  por xmm9, xmm1
000078af20bdf1aa  movaps [r15+0x200], xmm9
000078af20bdf1b2  vmovaps [rsp+0xC0], xmm2
000078af20bdf1bb  vmovaps xmm1, [rsp+0xC0]
000078af20bdf1c4  por xmm2, xmm1
000078af20bdf1c8  movaps [r15+0x2D0], xmm2
000078af20bdf1d0  vmovaps [rsp+0xC0], xmm8
000078af20bdf1d9  vmovaps xmm1, [rsp+0xC0]
000078af20bdf1e2  por xmm8, xmm1
000078af20bdf1e7  movaps [r15+0x2E0], xmm8
000078af20bdf1ef  vmovaps [rsp+0xC0], xmm15
000078af20bdf1f8  movaps xmm1, xmm5
000078af20bdf1fb  addpd xmm1, xmm7
000078af20bdf1ff  vcmppd xmm15, xmm1, xmm1, 0x03
000078af20bdf204  ptest xmm15, xmm15
000078af20bdf20a  jnz 0x000078AF20BE0F9E
000078af20bdf210  vmovaps xmm15, [rsp+0x50]
000078af20bdf216  vpermilpd xmm15, xmm15, 0x00
000078af20bdf21c  vmovaps xmm5, [rsp+0xC0]
000078af20bdf225  vmovaps [rsp+0xC0], xmm1
000078af20bdf22e  movaps xmm7, xmm5
000078af20bdf231  mulpd xmm7, xmm15
000078af20bdf236  vcmppd xmm1, xmm7, xmm7, 0x03
000078af20bdf23b  ptest xmm1, xmm1
000078af20bdf240  jnz 0x000078AF20BE10DE
000078af20bdf246  lea r12, [rax+0x80]
000078af20bdf24d  movups xmm1, [r13+r12*1]
000078af20bdf253  vmovaps xmm5, [rsp+0x70]
000078af20bdf259  vmovaps [rsp+0x70], xmm1
000078af20bdf25f  movaps xmm15, xmm5
000078af20bdf263  addpd xmm15, xmm3
000078af20bdf268  vcmppd xmm1, xmm15, xmm15, 0x03
000078af20bdf26e  ptest xmm1, xmm1
000078af20bdf273  jnz 0x000078AF20BE1229
000078af20bdf279  vmovaps xmm5, [rsp+0x80]
000078af20bdf282  movaps xmm1, xmm5
000078af20bdf285  addpd xmm1, xmm4
000078af20bdf289  vcmppd xmm3, xmm1, xmm1, 0x03
000078af20bdf28e  ptest xmm3, xmm3
000078af20bdf293  jnz 0x000078AF20BE136B
000078af20bdf299  vmovaps [rsp+0x80], xmm10
000078af20bdf2a2  vmovaps xmm5, [rsp+0x80]
000078af20bdf2ab  por xmm10, xmm5
000078af20bdf2b0  movaps [r15+0x2F0], xmm10
000078af20bdf2b8  vmovaps xmm5, [rsp+0x50]
000078af20bdf2be  vpermilpd xmm5, xmm5, 0x00
000078af20bdf2c4  vmovaps xmm3, [rsp+0x70]
000078af20bdf2ca  vmovaps [rsp+0x50], xmm1
000078af20bdf2d0  movaps xmm4, xmm3
000078af20bdf2d3  mulpd xmm4, xmm5
000078af20bdf2d7  vcmppd xmm1, xmm4, xmm4, 0x03
000078af20bdf2dc  ptest xmm1, xmm1
000078af20bdf2e1  jnz 0x000078AF20BE14AB
000078af20bdf2e7  lea r12, [rax+0xD0]
000078af20bdf2ee  movups xmm1, [r13+r12*1]
000078af20bdf2f4  vmovaps xmm3, [rsp+0xD0]
000078af20bdf2fd  vmovaps [rsp+0x70], xmm1
000078af20bdf303  movaps xmm5, xmm6
000078af20bdf306  addpd xmm5, xmm3
000078af20bdf30a  vcmppd xmm1, xmm5, xmm5, 0x03
000078af20bdf30f  ptest xmm1, xmm1
000078af20bdf314  jnz 0x000078AF20BE15F5
000078af20bdf31a  vmovaps xmm1, [rsp+0x60]
000078af20bdf320  vpermilpd xmm1, xmm1, 0x00
000078af20bdf326  movaps xmm6, xmm9
000078af20bdf32a  mulpd xmm6, xmm1
000078af20bdf32e  vcmppd xmm3, xmm6, xmm6, 0x03
000078af20bdf333  ptest xmm3, xmm3
000078af20bdf338  jnz 0x000078AF20BE1735
000078af20bdf33e  movaps [r15+0x260], xmm6
000078af20bdf346  vxorps xmm1, xmm1, xmm1
000078af20bdf34a  vpbroadcastq xmm1, xmm1
000078af20bdf34f  movaps [r15+0x1B0], xmm1
000078af20bdf357  vmovaps xmm1, [rsp+0x60]
000078af20bdf35d  vpermilpd xmm1, xmm1, 0x00
000078af20bdf363  vmovaps xmm3, [rsp+0x70]
000078af20bdf369  vmovaps [rsp+0x70], xmm15
000078af20bdf36f  movaps xmm9, xmm3
000078af20bdf373  mulpd xmm9, xmm1
000078af20bdf378  vcmppd xmm15, xmm9, xmm9, 0x03
000078af20bdf37e  ptest xmm15, xmm15
000078af20bdf384  jnz 0x000078AF20BE1876
000078af20bdf38a  lea r12, [rax+0xC0]
000078af20bdf391  movups xmm1, [r13+r12*1]
000078af20bdf397  vmovaps xmm3, [rsp+0xC0]
000078af20bdf3a0  vmovaps [rsp+0x80], xmm1
000078af20bdf3a9  movaps xmm15, xmm3
000078af20bdf3ad  addpd xmm15, xmm7
000078af20bdf3b2  vcmppd xmm1, xmm15, xmm15, 0x03
000078af20bdf3b8  ptest xmm1, xmm1
000078af20bdf3bd  jnz 0x000078AF20BE19C2
000078af20bdf3c3  vmovaps [rsp+0xC0], xmm13
000078af20bdf3cc  vmovaps xmm1, [rsp+0xC0]
000078af20bdf3d5  por xmm13, xmm1
000078af20bdf3da  movaps [r15+0x270], xmm13
000078af20bdf3e2  vmovaps xmm1, [rsp+0xB0]
000078af20bdf3eb  vmovaps xmm7, [rsp+0xB0]
000078af20bdf3f4  por xmm1, xmm7
000078af20bdf3f8  movaps [r15+0x1A0], xmm1
000078af20bdf400  vmovaps xmm1, [rsp+0x60]
000078af20bdf406  vpermilpd xmm1, xmm1, 0x00
000078af20bdf40c  vmovaps [rsp+0xB0], xmm1
000078af20bdf415  vmovaps xmm1, [rsp+0x80]
000078af20bdf41e  vmovaps [rsp+0x80], xmm15
000078af20bdf427  vmovaps xmm15, [rsp+0xB0]
000078af20bdf430  vmovaps [rsp+0xB0], xmm14
000078af20bdf439  movaps xmm3, xmm1
000078af20bdf43c  mulpd xmm3, xmm15
000078af20bdf441  vcmppd xmm14, xmm3, xmm3, 0x03
000078af20bdf446  ptest xmm14, xmm14
000078af20bdf44c  jnz 0x000078AF20BE1B04
000078af20bdf452  lea r12, [rax+0x20]
000078af20bdf456  movups xmm1, [r13+r12*1]
000078af20bdf45c  movaps [r15+0x110], xmm1
000078af20bdf464  vmovaps xmm14, [rsp+0x70]
000078af20bdf46a  vmovaps [rsp+0x70], xmm1
000078af20bdf470  movaps xmm15, xmm14
000078af20bdf474  addpd xmm15, xmm4
000078af20bdf479  vcmppd xmm1, xmm15, xmm15, 0x03
000078af20bdf47f  ptest xmm1, xmm1
000078af20bdf484  jnz 0x000078AF20BE1C4F
000078af20bdf48a  vmovaps xmm1, [rsp+0x60]
000078af20bdf490  vpermilpd xmm1, xmm1, 0x00
000078af20bdf496  movaps xmm14, xmm2
000078af20bdf49a  mulpd xmm14, xmm1
000078af20bdf49f  vcmppd xmm4, xmm14, xmm14, 0x03
000078af20bdf4a5  ptest xmm4, xmm4
000078af20bdf4aa  jnz 0x000078AF20BE1D92
000078af20bdf4b0  vmovaps xmm4, [rsp+0x50]
000078af20bdf4b6  movaps xmm1, xmm4
000078af20bdf4b9  addpd xmm1, xmm9
000078af20bdf4be  vcmppd xmm2, xmm1, xmm1, 0x03
000078af20bdf4c3  ptest xmm2, xmm2
000078af20bdf4c8  jnz 0x000078AF20BE1ED4
000078af20bdf4ce  vmovaps xmm9, [rsp+0x30]
000078af20bdf4d4  vpermilpd xmm9, xmm9, 0x00
000078af20bdf4da  vmovaps xmm2, [rsp+0x70]
000078af20bdf4e0  vmovaps [rsp+0x50], xmm1
000078af20bdf4e6  movaps xmm4, xmm2
000078af20bdf4e9  mulpd xmm4, xmm9
000078af20bdf4ee  vcmppd xmm1, xmm4, xmm4, 0x03
000078af20bdf4f3  ptest xmm1, xmm1
000078af20bdf4f8  jnz 0x000078AF20BE2015
000078af20bdf4fe  vmovaps xmm1, [rsp+0x30]
000078af20bdf504  vpermilpd xmm1, xmm1, 0x00
000078af20bdf50a  vmovaps xmm2, [rsp+0x90]
000078af20bdf513  vmovaps [rsp+0x60], xmm15
000078af20bdf519  movaps xmm9, xmm2
000078af20bdf51d  mulpd xmm9, xmm1
000078af20bdf522  vcmppd xmm15, xmm9, xmm9, 0x03
000078af20bdf528  ptest xmm15, xmm15
000078af20bdf52e  jnz 0x000078AF20BE2156
000078af20bdf534  vmovaps xmm15, [rsp+0x80]
000078af20bdf53d  movaps xmm1, xmm15
000078af20bdf541  addpd xmm1, xmm6
000078af20bdf545  vcmppd xmm2, xmm1, xmm1, 0x03
000078af20bdf54a  ptest xmm2, xmm2
000078af20bdf54f  jnz 0x000078AF20BE2298
000078af20bdf555  movaps xmm15, xmm5
000078af20bdf559  addpd xmm15, xmm3
000078af20bdf55e  vcmppd xmm6, xmm15, xmm15, 0x03
000078af20bdf564  ptest xmm6, xmm6
000078af20bdf569  jnz 0x000078AF20BE23D9
000078af20bdf56f  vmovaps xmm6, [rsp+0x30]
000078af20bdf575  vpermilpd xmm6, xmm6, 0x00
000078af20bdf57b  movaps xmm5, xmm8
000078af20bdf57f  mulpd xmm5, xmm6
000078af20bdf583  vcmppd xmm3, xmm5, xmm5, 0x03
000078af20bdf588  ptest xmm3, xmm3
000078af20bdf58d  jnz 0x000078AF20BE251B
000078af20bdf593  vmovaps xmm8, [rsp+0x30]
000078af20bdf599  vpermilpd xmm8, xmm8, 0x00
000078af20bdf59f  movaps xmm6, xmm10
000078af20bdf5a3  mulpd xmm6, xmm8
000078af20bdf5a8  vcmppd xmm3, xmm6, xmm6, 0x03
000078af20bdf5ad  ptest xmm3, xmm3
000078af20bdf5b2  jnz 0x000078AF20BE265C
000078af20bdf5b8  vmovaps xmm8, [rsp+0x60]
000078af20bdf5be  movaps xmm10, xmm8
000078af20bdf5c2  addpd xmm10, xmm14
000078af20bdf5c7  vcmppd xmm3, xmm10, xmm10, 0x03
000078af20bdf5cd  ptest xmm3, xmm3
000078af20bdf5d2  jnz 0x000078AF20BE279E
000078af20bdf5d8  vmovaps xmm8, [rsp+0x50]
000078af20bdf5de  movaps xmm14, xmm8
000078af20bdf5e2  addpd xmm14, xmm4
000078af20bdf5e7  vcmppd xmm3, xmm14, xmm14, 0x03
000078af20bdf5ed  ptest xmm3, xmm3
000078af20bdf5f2  jnz 0x000078AF20BE28E2
000078af20bdf5f8  vmovaps xmm8, [rsp+0x40]
000078af20bdf5fe  vpermilpd xmm8, xmm8, 0x00
000078af20bdf604  movaps xmm4, xmm13
000078af20bdf608  mulpd xmm4, xmm8
000078af20bdf60d  vcmppd xmm3, xmm4, xmm4, 0x03
000078af20bdf612  ptest xmm3, xmm3
000078af20bdf617  jnz 0x000078AF20BE2A25
000078af20bdf61d  movaps xmm13, xmm15
000078af20bdf621  addpd xmm13, xmm9
000078af20bdf626  vcmppd xmm8, xmm13, xmm13, 0x03
000078af20bdf62c  ptest xmm8, xmm8
000078af20bdf632  jnz 0x000078AF20BE2B67
000078af20bdf638  movaps xmm15, xmm1
000078af20bdf63c  addpd xmm15, xmm5
000078af20bdf641  vcmppd xmm9, xmm15, xmm15, 0x03
000078af20bdf647  ptest xmm9, xmm9
000078af20bdf64d  jnz 0x000078AF20BE2CAB
000078af20bdf653  vmovaps [rsp+0x30], xmm11
000078af20bdf659  vmovaps xmm1, [rsp+0x30]
000078af20bdf65f  por xmm11, xmm1
000078af20bdf664  movaps [r15+0x250], xmm11
000078af20bdf66c  vmovaps [rsp+0x30], xmm12
000078af20bdf672  vmovaps xmm1, [rsp+0x30]
000078af20bdf678  por xmm12, xmm1
000078af20bdf67d  movaps [r15+0x2A0], xmm12
000078af20bdf685  vmovaps xmm1, [rsp+0xA0]
000078af20bdf68e  vmovaps xmm11, [rsp+0xA0]
000078af20bdf697  por xmm1, xmm11
000078af20bdf69c  movaps [r15+0x1D0], xmm1
000078af20bdf6a4  lea r12, [rax+0x40]
000078af20bdf6a8  movups xmm1, [r13+r12*1]
000078af20bdf6ae  movaps [r15+0x2C0], xmm1
000078af20bdf6b6  vmovaps xmm11, [rsp+0x40]
000078af20bdf6bc  vpermilpd xmm11, xmm11, 0x00
000078af20bdf6c2  vmovaps xmm8, [rsp+0xE0]
000078af20bdf6cb  movaps xmm9, xmm8
000078af20bdf6cf  mulpd xmm9, xmm11
000078af20bdf6d4  vcmppd xmm5, xmm9, xmm9, 0x03
000078af20bdf6da  ptest xmm5, xmm5
000078af20bdf6df  jnz 0x000078AF20BE2DF7
000078af20bdf6e5  movaps xmm11, xmm10
000078af20bdf6e9  addpd xmm11, xmm6
000078af20bdf6ee  vcmppd xmm8, xmm11, xmm11, 0x03
000078af20bdf6f4  ptest xmm8, xmm8
000078af20bdf6fa  jnz 0x000078AF20BE2F3B
000078af20bdf700  movaps xmm10, xmm14
000078af20bdf704  addpd xmm10, xmm4
000078af20bdf709  vcmppd xmm8, xmm10, xmm10, 0x03
000078af20bdf70f  ptest xmm8, xmm8
000078af20bdf715  jnz 0x000078AF20BE307E
000078af20bdf71b  vmovaps xmm14, [rsp+0x40]
000078af20bdf721  vpermilpd xmm14, xmm14, 0x00
000078af20bdf727  movaps xmm8, xmm1
000078af20bdf72b  mulpd xmm8, xmm14
000078af20bdf730  vcmppd xmm6, xmm8, xmm8, 0x03
000078af20bdf736  ptest xmm6, xmm6
000078af20bdf73b  jnz 0x000078AF20BE31C1
000078af20bdf741  movaps xmm1, [r15+0x2B0]
000078af20bdf749  vmovaps xmm14, [rsp+0x40]
000078af20bdf74f  vpermilpd xmm14, xmm14, 0x00
000078af20bdf755  movaps xmm6, xmm1
000078af20bdf758  mulpd xmm6, xmm14
000078af20bdf75d  vcmppd xmm5, xmm6, xmm6, 0x03
000078af20bdf762  ptest xmm5, xmm5
000078af20bdf767  jnz 0x000078AF20BE3304
000078af20bdf76d  vmovaps xmm1, [rsp+0x10]
000078af20bdf773  vpermilpd xmm1, xmm1, 0x00
000078af20bdf779  movaps xmm14, xmm12
000078af20bdf77d  mulpd xmm14, xmm1
000078af20bdf782  vcmppd xmm5, xmm14, xmm14, 0x03
000078af20bdf788  ptest xmm5, xmm5
000078af20bdf78d  jnz 0x000078AF20BE3445
000078af20bdf793  movaps xmm1, xmm13
000078af20bdf797  addpd xmm1, xmm9
000078af20bdf79c  vcmppd xmm12, xmm1, xmm1, 0x03
000078af20bdf7a1  ptest xmm12, xmm12
000078af20bdf7a7  jnz 0x000078AF20BE3588
000078af20bdf7ad  vmovaps xmm13, [rsp+0x10]
000078af20bdf7b3  vpermilpd xmm13, xmm13, 0x00
000078af20bdf7b9  movaps xmm12, xmm7
000078af20bdf7bd  mulpd xmm12, xmm13
000078af20bdf7c2  vcmppd xmm9, xmm12, xmm12, 0x03
000078af20bdf7c8  ptest xmm9, xmm9
000078af20bdf7ce  jnz 0x000078AF20BE36CA
000078af20bdf7d4  movaps xmm13, xmm15
000078af20bdf7d8  addpd xmm13, xmm8
000078af20bdf7dd  vcmppd xmm9, xmm13, xmm13, 0x03
000078af20bdf7e3  ptest xmm9, xmm9
000078af20bdf7e9  jnz 0x000078AF20BE380D
000078af20bdf7ef  movaps xmm15, [r15+0x290]
000078af20bdf7f7  vmovaps xmm9, [rsp+0x10]
000078af20bdf7fd  vpermilpd xmm9, xmm9, 0x00
000078af20bdf803  movaps xmm8, xmm15
000078af20bdf807  mulpd xmm8, xmm9
000078af20bdf80c  vcmppd xmm7, xmm8, xmm8, 0x03
000078af20bdf812  ptest xmm7, xmm7
000078af20bdf817  jnz 0x000078AF20BE3951
000078af20bdf81d  movaps xmm15, xmm11
000078af20bdf821  addpd xmm15, xmm6
000078af20bdf826  vcmppd xmm9, xmm15, xmm15, 0x03
000078af20bdf82c  ptest xmm9, xmm9
000078af20bdf832  jnz 0x000078AF20BE3A95
000078af20bdf838  movaps xmm11, [r15+0x1E0]
000078af20bdf840  vmovaps xmm9, [rsp+0x10]
000078af20bdf846  vpermilpd xmm9, xmm9, 0x00
000078af20bdf84c  movaps xmm7, xmm11
000078af20bdf850  mulpd xmm7, xmm9
000078af20bdf855  vcmppd xmm6, xmm7, xmm7, 0x03
000078af20bdf85a  ptest xmm6, xmm6
000078af20bdf85f  jnz 0x000078AF20BE3BD8
000078af20bdf865  movaps xmm11, xmm10
000078af20bdf869  addpd xmm11, xmm14
000078af20bdf86e  vcmppd xmm9, xmm11, xmm11, 0x03
000078af20bdf874  ptest xmm9, xmm9
000078af20bdf87a  jnz 0x000078AF20BE3D1A
000078af20bdf880  lea r12, [rax+0x70]
000078af20bdf884  movups xmm14, [r13+r12*1]
000078af20bdf88a  movaps [r15+0x240], xmm14
000078af20bdf892  movaps xmm10, xmm1
000078af20bdf896  addpd xmm10, xmm12
000078af20bdf89b  vcmppd xmm9, xmm10, xmm10, 0x03
000078af20bdf8a1  ptest xmm9, xmm9
000078af20bdf8a7  jnz 0x000078AF20BE3E68
000078af20bdf8ad  movaps [r15+0x170], xmm10
000078af20bdf8b5  vmovaps xmm1, [rsp+0x20]
000078af20bdf8bb  vpermilpd xmm1, xmm1, 0x00
000078af20bdf8c1  movaps xmm12, xmm14
000078af20bdf8c5  mulpd xmm12, xmm1
000078af20bdf8ca  vcmppd xmm9, xmm12, xmm12, 0x03
000078af20bdf8d0  ptest xmm9, xmm9
000078af20bdf8d6  jnz 0x000078AF20BE3FAB
000078af20bdf8dc  vmovaps xmm1, [rsp+0x20]
000078af20bdf8e2  vpermilpd xmm1, xmm1, 0x00
000078af20bdf8e8  vmovaps xmm9, [rsp+0xB0]
000078af20bdf8f1  movaps xmm14, xmm9
000078af20bdf8f5  mulpd xmm14, xmm1
000078af20bdf8fa  vcmppd xmm6, xmm14, xmm14, 0x03
000078af20bdf900  ptest xmm6, xmm6
000078af20bdf905  jnz 0x000078AF20BE40EE
000078af20bdf90b  movaps [r15+0x180], xmm14
000078af20bdf913  movaps xmm1, xmm13
000078af20bdf917  addpd xmm1, xmm8
000078af20bdf91c  vcmppd xmm9, xmm1, xmm1, 0x03
000078af20bdf921  ptest xmm9, xmm9
000078af20bdf927  jnz 0x000078AF20BE4231
000078af20bdf92d  movaps [r15+0x210], xmm1
000078af20bdf935  movups xmm13, [r13+rax*1]
000078af20bdf93b  lea r12, [rax+0x10]
000078af20bdf93f  movups xmm9, [r13+r12*1]
000078af20bdf945  movaps [r15+0x230], xmm9
000078af20bdf94d  movaps xmm8, xmm15
000078af20bdf951  addpd xmm8, xmm7
000078af20bdf956  vcmppd xmm6, xmm8, xmm8, 0x03
000078af20bdf95c  ptest xmm6, xmm6
000078af20bdf961  jnz 0x000078AF20BE4387
000078af20bdf967  movaps [r15+0x130], xmm8
000078af20bdf96f  vmovaps xmm15, [rsp+0x20]
000078af20bdf975  vpermilpd xmm15, xmm15, 0x00
000078af20bdf97b  movaps xmm7, xmm9
000078af20bdf97f  mulpd xmm7, xmm15
000078af20bdf984  vcmppd xmm6, xmm7, xmm7, 0x03
000078af20bdf989  ptest xmm6, xmm6
000078af20bdf98e  jnz 0x000078AF20BE44CA
000078af20bdf994  movaps [r15+0x220], xmm7
000078af20bdf99c  vmovaps xmm15, [rsp+0x20]
000078af20bdf9a2  vpermilpd xmm15, xmm15, 0x00
000078af20bdf9a8  movaps xmm9, xmm13
000078af20bdf9ac  mulpd xmm9, xmm15
000078af20bdf9b1  vcmppd xmm6, xmm9, xmm9, 0x03
000078af20bdf9b7  ptest xmm6, xmm6
000078af20bdf9bc  jnz 0x000078AF20BE460C
000078af20bdf9c2  movaps xmm15, xmm11
000078af20bdf9c6  addpd xmm15, xmm12
000078af20bdf9cb  vcmppd xmm13, xmm15, xmm15, 0x03
000078af20bdf9d1  ptest xmm13, xmm13
000078af20bdf9d7  jnz 0x000078AF20BE4750
000078af20bdf9dd  movaps [r15+0x140], xmm15
000078af20bdf9e5  movaps xmm13, xmm10
000078af20bdf9e9  addpd xmm13, xmm14
000078af20bdf9ee  vcmppd xmm12, xmm13, xmm13, 0x03
000078af20bdf9f4  ptest xmm12, xmm12
000078af20bdf9fa  jnz 0x000078AF20BE4894
000078af20bdfa00  movaps [r15+0x150], xmm13
000078af20bdfa08  movaps xmm14, xmm1
000078af20bdfa0c  addpd xmm14, xmm7
000078af20bdfa11  vcmppd xmm12, xmm14, xmm14, 0x03
000078af20bdfa17  ptest xmm12, xmm12
000078af20bdfa1d  jnz 0x000078AF20BE49D8
000078af20bdfa23  movaps [r15+0x160], xmm14
000078af20bdfa2b  movaps xmm1, xmm8
000078af20bdfa2f  addpd xmm1, xmm9
000078af20bdfa34  vcmppd xmm12, xmm1, xmm1, 0x03
000078af20bdfa39  ptest xmm12, xmm12
000078af20bdfa3f  jnz 0x000078AF20BE4B1A
000078af20bdfa45  movaps [r15+0x120], xmm1
000078af20bdfa4d  movups [r13+r14*1], xmm15
000078af20bdfa53  lea rax, [r14+0x10]
000078af20bdfa57  movups [r13+rax*1], xmm13
000078af20bdfa5d  lea rax, [r14+0x20]
000078af20bdfa61  movups [r13+rax*1], xmm14
000078af20bdfa67  lea rax, [r14+0x30]
000078af20bdfa6b  movups [r13+rax*1], xmm1
000078af20bdfa71  mov eax, [r15+0x108]
000078af20bdfa78  sahf
000078af20bdfa79  jnz 0x000078AF20BDFAAB
000078af20bdfa7b  cmp dword ptr [r15+0x318], 0x00
000078af20bdfa83  jz 0x000078AF20BDEAE0
000078af20bdfa89  nop [rax+rax*1], ax
000078af20bdfa92  nop [rax+rax*1], eax
000078af20bdfa9a  mov eax, 0x4106D0
000078af20bdfa9f  mov [r15+0x100], rax
000078af20bdfaa6  jmp 0x000078AF209FE110
000078af20bdfaab  cmp dword ptr [r15+0x318], 0x00
000078af20bdfab3  jz 0x000078AF20BD89C0
000078af20bdfab9  nop [rax+rax*1], ax
000078af20bdfac2  nop [rax+rax*1], eax
000078af20bdfaca  mov eax, 0x410504
000078af20bdfacf  mov [r15+0x100], rax
000078af20bdfad6  jmp 0x000078AF209FE110
000078af20bdfadb  int3
000078af20bdfadc  call 0x000078AF20AE27E0
000078af20bdfae1  jmp 0x000078AF20BDEBBF
000078af20bdfae6  call 0x000078AF20AE1570
000078af20bdfaeb  jmp 0x000078AF20BDEBC8
000078af20bdfaf0  call 0x000078AF20AE27E0
000078af20bdfaf5  jmp 0x000078AF20BDEC24
000078af20bdfafa  call 0x000078AF20AE1570
000078af20bdfaff  jmp 0x000078AF20BDEC2D
000078af20bdfb04  call 0x000078AF20AE27E0
000078af20bdfb09  jmp 0x000078AF20BDEC70
000078af20bdfb0e  call 0x000078AF20AE1570
000078af20bdfb13  jmp 0x000078AF20BDEC79
000078af20bdfb18  call 0x000078AF20A0DC20
000078af20bdfb1d  jmp 0x000078AF20BDECB8
000078af20bdfb22  call 0x000078AF20AD59C0
000078af20bdfb27  jmp 0x000078AF20BDECCB
000078af20bdfb2c  call 0x000078AF20AE0E30
000078af20bdfb31  jmp 0x000078AF20BDECE9
000078af20bdfb36  call 0x000078AF20ADFBC0
000078af20bdfb3b  jmp 0x000078AF20BDECF3
000078af20bdfb40  call 0x000078AF20ADE950
000078af20bdfb45  jmp 0x000078AF20BDECFD
000078af20bdfb4a  sub rsp, 0x08
000078af20bdfb4e  push rax
000078af20bdfb4f  push rcx
000078af20bdfb50  push rdx
000078af20bdfb51  push rdi
000078af20bdfb52  push rsi
000078af20bdfb53  push r8
000078af20bdfb55  push r9
000078af20bdfb57  push r10
000078af20bdfb59  push r11
000078af20bdfb5b  sub rsp, 0xF0
000078af20bdfb62  vmovaps [rsp], xmm0
000078af20bdfb67  vmovaps [rsp+0x10], xmm1
000078af20bdfb6d  vmovaps [rsp+0x20], xmm2
000078af20bdfb73  vmovaps [rsp+0x30], xmm3
000078af20bdfb79  vmovaps [rsp+0x40], xmm4
000078af20bdfb7f  vmovaps [rsp+0x50], xmm5
000078af20bdfb85  vmovaps [rsp+0x60], xmm6
000078af20bdfb8b  vmovaps [rsp+0x70], xmm7
000078af20bdfb91  vmovaps [rsp+0x80], xmm9
000078af20bdfb9a  vmovaps [rsp+0x90], xmm10
000078af20bdfba3  vmovaps [rsp+0xA0], xmm11
000078af20bdfbac  vmovaps [rsp+0xB0], xmm12
000078af20bdfbb5  vmovaps [rsp+0xC0], xmm13
000078af20bdfbbe  vmovaps [rsp+0xD0], xmm14
000078af20bdfbc7  vmovaps [rsp+0xE0], xmm15
000078af20bdfbd0  sub rsp, 0x30
000078af20bdfbd4  movaps [rsp], xmm8
000078af20bdfbd9  movaps [rsp+0x10], xmm12
000078af20bdfbdf  movaps [rsp+0x20], xmm15
000078af20bdfbe5  lea rdi, [rsp]
000078af20bdfbe9  mov esi, 0x00
000078af20bdfbee  mov rax, 0x65452FFB8530
000078af20bdfbf8  call rax
000078af20bdfbfa  movaps xmm8, [rsp]
000078af20bdfbff  add rsp, 0x30
000078af20bdfc03  vmovaps xmm0, [rsp]
000078af20bdfc08  vmovaps xmm1, [rsp+0x10]
000078af20bdfc0e  vmovaps xmm2, [rsp+0x20]
000078af20bdfc14  vmovaps xmm3, [rsp+0x30]
000078af20bdfc1a  vmovaps xmm4, [rsp+0x40]
000078af20bdfc20  vmovaps xmm5, [rsp+0x50]
000078af20bdfc26  vmovaps xmm6, [rsp+0x60]
000078af20bdfc2c  vmovaps xmm7, [rsp+0x70]
000078af20bdfc32  vmovaps xmm9, [rsp+0x80]
000078af20bdfc3b  vmovaps xmm10, [rsp+0x90]
000078af20bdfc44  vmovaps xmm11, [rsp+0xA0]
000078af20bdfc4d  vmovaps xmm12, [rsp+0xB0]
000078af20bdfc56  vmovaps xmm13, [rsp+0xC0]
000078af20bdfc5f  vmovaps xmm14, [rsp+0xD0]
000078af20bdfc68  vmovaps xmm15, [rsp+0xE0]
000078af20bdfc71  add rsp, 0xF0
000078af20bdfc78  pop r11
000078af20bdfc7a  pop r10
000078af20bdfc7c  pop r9
000078af20bdfc7e  pop r8
000078af20bdfc80  pop rsi
000078af20bdfc81  pop rdi
000078af20bdfc82  pop rdx
000078af20bdfc83  pop rcx
000078af20bdfc84  pop rax
000078af20bdfc85  add rsp, 0x08
000078af20bdfc89  jmp 0x000078AF20BDED27
000078af20bdfc8e  sub rsp, 0x08
000078af20bdfc92  push rax
000078af20bdfc93  push rcx
000078af20bdfc94  push rdx
000078af20bdfc95  push rdi
000078af20bdfc96  push rsi
000078af20bdfc97  push r8
000078af20bdfc99  push r9
000078af20bdfc9b  push r10
000078af20bdfc9d  push r11
000078af20bdfc9f  sub rsp, 0xF0
000078af20bdfca6  vmovaps [rsp], xmm0
000078af20bdfcab  vmovaps [rsp+0x10], xmm1
000078af20bdfcb1  vmovaps [rsp+0x20], xmm2
000078af20bdfcb7  vmovaps [rsp+0x30], xmm3
000078af20bdfcbd  vmovaps [rsp+0x40], xmm4
000078af20bdfcc3  vmovaps [rsp+0x50], xmm5
000078af20bdfcc9  vmovaps [rsp+0x60], xmm6
000078af20bdfccf  vmovaps [rsp+0x70], xmm8
000078af20bdfcd5  vmovaps [rsp+0x80], xmm9
000078af20bdfcde  vmovaps [rsp+0x90], xmm10
000078af20bdfce7  vmovaps [rsp+0xA0], xmm11
000078af20bdfcf0  vmovaps [rsp+0xB0], xmm12
000078af20bdfcf9  vmovaps [rsp+0xC0], xmm13
000078af20bdfd02  vmovaps [rsp+0xD0], xmm14
000078af20bdfd0b  vmovaps [rsp+0xE0], xmm15
000078af20bdfd14  sub rsp, 0x30
000078af20bdfd18  movaps [rsp], xmm7
000078af20bdfd1c  movaps [rsp+0x10], xmm9
000078af20bdfd22  movaps [rsp+0x20], xmm15
000078af20bdfd28  lea rdi, [rsp]
000078af20bdfd2c  mov esi, 0x00
000078af20bdfd31  mov rax, 0x65452FFB8530
000078af20bdfd3b  call rax
000078af20bdfd3d  movaps xmm7, [rsp]
000078af20bdfd41  add rsp, 0x30
000078af20bdfd45  vmovaps xmm0, [rsp]
000078af20bdfd4a  vmovaps xmm1, [rsp+0x10]
000078af20bdfd50  vmovaps xmm2, [rsp+0x20]
000078af20bdfd56  vmovaps xmm3, [rsp+0x30]
000078af20bdfd5c  vmovaps xmm4, [rsp+0x40]
000078af20bdfd62  vmovaps xmm5, [rsp+0x50]
000078af20bdfd68  vmovaps xmm6, [rsp+0x60]
000078af20bdfd6e  vmovaps xmm8, [rsp+0x70]
000078af20bdfd74  vmovaps xmm9, [rsp+0x80]
000078af20bdfd7d  vmovaps xmm10, [rsp+0x90]
000078af20bdfd86  vmovaps xmm11, [rsp+0xA0]
000078af20bdfd8f  vmovaps xmm12, [rsp+0xB0]
000078af20bdfd98  vmovaps xmm13, [rsp+0xC0]
000078af20bdfda1  vmovaps xmm14, [rsp+0xD0]
000078af20bdfdaa  vmovaps xmm15, [rsp+0xE0]
000078af20bdfdb3  add rsp, 0xF0
000078af20bdfdba  pop r11
000078af20bdfdbc  pop r10
000078af20bdfdbe  pop r9
000078af20bdfdc0  pop r8
000078af20bdfdc2  pop rsi
000078af20bdfdc3  pop rdi
000078af20bdfdc4  pop rdx
000078af20bdfdc5  pop rcx
000078af20bdfdc6  pop rax
000078af20bdfdc7  add rsp, 0x08
000078af20bdfdcb  jmp 0x000078AF20BDED55
000078af20bdfdd0  sub rsp, 0x08
000078af20bdfdd4  push rax
000078af20bdfdd5  push rcx
000078af20bdfdd6  push rdx
000078af20bdfdd7  push rdi
000078af20bdfdd8  push rsi
000078af20bdfdd9  push r8
000078af20bdfddb  push r9
000078af20bdfddd  push r10
000078af20bdfddf  push r11
000078af20bdfde1  sub rsp, 0xF0
000078af20bdfde8  vmovaps [rsp], xmm0
000078af20bdfded  vmovaps [rsp+0x10], xmm1
000078af20bdfdf3  vmovaps [rsp+0x20], xmm2
000078af20bdfdf9  vmovaps [rsp+0x30], xmm3
000078af20bdfdff  vmovaps [rsp+0x40], xmm4
000078af20bdfe05  vmovaps [rsp+0x50], xmm5
000078af20bdfe0b  vmovaps [rsp+0x60], xmm6
000078af20bdfe11  vmovaps [rsp+0x70], xmm7
000078af20bdfe17  vmovaps [rsp+0x80], xmm8
000078af20bdfe20  vmovaps [rsp+0x90], xmm10
000078af20bdfe29  vmovaps [rsp+0xA0], xmm11
000078af20bdfe32  vmovaps [rsp+0xB0], xmm12
000078af20bdfe3b  vmovaps [rsp+0xC0], xmm13
000078af20bdfe44  vmovaps [rsp+0xD0], xmm14
000078af20bdfe4d  vmovaps [rsp+0xE0], xmm15
000078af20bdfe56  sub rsp, 0x30
000078af20bdfe5a  movaps [rsp], xmm9
000078af20bdfe5f  movaps [rsp+0x10], xmm12
000078af20bdfe65  movaps [rsp+0x20], xmm10
000078af20bdfe6b  lea rdi, [rsp]
000078af20bdfe6f  mov esi, 0x00
000078af20bdfe74  mov rax, 0x65452FFB8530
000078af20bdfe7e  call rax
000078af20bdfe80  movaps xmm9, [rsp]
000078af20bdfe85  add rsp, 0x30
000078af20bdfe89  vmovaps xmm0, [rsp]
000078af20bdfe8e  vmovaps xmm1, [rsp+0x10]
000078af20bdfe94  vmovaps xmm2, [rsp+0x20]
000078af20bdfe9a  vmovaps xmm3, [rsp+0x30]
000078af20bdfea0  vmovaps xmm4, [rsp+0x40]
000078af20bdfea6  vmovaps xmm5, [rsp+0x50]
000078af20bdfeac  vmovaps xmm6, [rsp+0x60]
000078af20bdfeb2  vmovaps xmm7, [rsp+0x70]
000078af20bdfeb8  vmovaps xmm8, [rsp+0x80]
000078af20bdfec1  vmovaps xmm10, [rsp+0x90]
000078af20bdfeca  vmovaps xmm11, [rsp+0xA0]
000078af20bdfed3  vmovaps xmm12, [rsp+0xB0]
000078af20bdfedc  vmovaps xmm13, [rsp+0xC0]
000078af20bdfee5  vmovaps xmm14, [rsp+0xD0]
000078af20bdfeee  vmovaps xmm15, [rsp+0xE0]
000078af20bdfef7  add rsp, 0xF0
000078af20bdfefe  pop r11
000078af20bdff00  pop r10
000078af20bdff02  pop r9
000078af20bdff04  pop r8
000078af20bdff06  pop rsi
000078af20bdff07  pop rdi
000078af20bdff08  pop rdx
000078af20bdff09  pop rcx
000078af20bdff0a  pop rax
000078af20bdff0b  add rsp, 0x08
000078af20bdff0f  jmp 0x000078AF20BDED79
000078af20bdff14  sub rsp, 0x08
000078af20bdff18  push rax
000078af20bdff19  push rcx
000078af20bdff1a  push rdx
000078af20bdff1b  push rdi
000078af20bdff1c  push rsi
000078af20bdff1d  push r8
000078af20bdff1f  push r9
000078af20bdff21  push r10
000078af20bdff23  push r11
000078af20bdff25  sub rsp, 0xF0
000078af20bdff2c  vmovaps [rsp], xmm0
000078af20bdff31  vmovaps [rsp+0x10], xmm1
000078af20bdff37  vmovaps [rsp+0x20], xmm2
000078af20bdff3d  vmovaps [rsp+0x30], xmm3
000078af20bdff43  vmovaps [rsp+0x40], xmm4
000078af20bdff49  vmovaps [rsp+0x50], xmm5
000078af20bdff4f  vmovaps [rsp+0x60], xmm6
000078af20bdff55  vmovaps [rsp+0x70], xmm7
000078af20bdff5b  vmovaps [rsp+0x80], xmm8
000078af20bdff64  vmovaps [rsp+0x90], xmm9
000078af20bdff6d  vmovaps [rsp+0xA0], xmm11
000078af20bdff76  vmovaps [rsp+0xB0], xmm12
000078af20bdff7f  vmovaps [rsp+0xC0], xmm13
000078af20bdff88  vmovaps [rsp+0xD0], xmm14
000078af20bdff91  vmovaps [rsp+0xE0], xmm15
000078af20bdff9a  sub rsp, 0x30
000078af20bdff9e  movaps [rsp], xmm10
000078af20bdffa3  movaps [rsp+0x10], xmm12
000078af20bdffa9  movaps [rsp+0x20], xmm11
000078af20bdffaf  lea rdi, [rsp]
000078af20bdffb3  mov esi, 0x00
000078af20bdffb8  mov rax, 0x65452FFB8530
000078af20bdffc2  call rax
000078af20bdffc4  movaps xmm10, [rsp]
000078af20bdffc9  add rsp, 0x30
000078af20bdffcd  vmovaps xmm0, [rsp]
000078af20bdffd2  vmovaps xmm1, [rsp+0x10]
000078af20bdffd8  vmovaps xmm2, [rsp+0x20]
000078af20bdffde  vmovaps xmm3, [rsp+0x30]
000078af20bdffe4  vmovaps xmm4, [rsp+0x40]
000078af20bdffea  vmovaps xmm5, [rsp+0x50]
000078af20bdfff0  vmovaps xmm6, [rsp+0x60]
000078af20bdfff6  vmovaps xmm7, [rsp+0x70]
000078af20bdfffc  vmovaps xmm8, [rsp+0x80]
000078af20be0005  vmovaps xmm9, [rsp+0x90]
000078af20be000e  vmovaps xmm11, [rsp+0xA0]
000078af20be0017  vmovaps xmm12, [rsp+0xB0]
000078af20be0020  vmovaps xmm13, [rsp+0xC0]
000078af20be0029  vmovaps xmm14, [rsp+0xD0]
000078af20be0032  vmovaps xmm15, [rsp+0xE0]
000078af20be003b  add rsp, 0xF0
000078af20be0042  pop r11
000078af20be0044  pop r10
000078af20be0046  pop r9
000078af20be0048  pop r8
000078af20be004a  pop rsi
000078af20be004b  pop rdi
000078af20be004c  pop rdx
000078af20be004d  pop rcx
000078af20be004e  pop rax
000078af20be004f  add rsp, 0x08
000078af20be0053  jmp 0x000078AF20BDED93
000078af20be0058  sub rsp, 0x08
000078af20be005c  push rax
000078af20be005d  push rcx
000078af20be005e  push rdx
000078af20be005f  push rdi
000078af20be0060  push rsi
000078af20be0061  push r8
000078af20be0063  push r9
000078af20be0065  push r10
000078af20be0067  push r11
000078af20be0069  sub rsp, 0xF0
000078af20be0070  vmovaps [rsp], xmm0
000078af20be0075  vmovaps [rsp+0x10], xmm1
000078af20be007b  vmovaps [rsp+0x20], xmm2
000078af20be0081  vmovaps [rsp+0x30], xmm3
000078af20be0087  vmovaps [rsp+0x40], xmm4
000078af20be008d  vmovaps [rsp+0x50], xmm5
000078af20be0093  vmovaps [rsp+0x60], xmm7
000078af20be0099  vmovaps [rsp+0x70], xmm8
000078af20be009f  vmovaps [rsp+0x80], xmm9
000078af20be00a8  vmovaps [rsp+0x90], xmm10
000078af20be00b1  vmovaps [rsp+0xA0], xmm11
000078af20be00ba  vmovaps [rsp+0xB0], xmm12
000078af20be00c3  vmovaps [rsp+0xC0], xmm13
000078af20be00cc  vmovaps [rsp+0xD0], xmm14
000078af20be00d5  vmovaps [rsp+0xE0], xmm15
000078af20be00de  sub rsp, 0x30
000078af20be00e2  movaps [rsp], xmm6
000078af20be00e6  movaps [rsp+0x10], xmm12
000078af20be00ec  movaps [rsp+0x20], xmm11
000078af20be00f2  lea rdi, [rsp]
000078af20be00f6  mov esi, 0x00
000078af20be00fb  mov rax, 0x65452FFB8530
000078af20be0105  call rax
000078af20be0107  movaps xmm6, [rsp]
000078af20be010b  add rsp, 0x30
000078af20be010f  vmovaps xmm0, [rsp]
000078af20be0114  vmovaps xmm1, [rsp+0x10]
000078af20be011a  vmovaps xmm2, [rsp+0x20]
000078af20be0120  vmovaps xmm3, [rsp+0x30]
000078af20be0126  vmovaps xmm4, [rsp+0x40]
000078af20be012c  vmovaps xmm5, [rsp+0x50]
000078af20be0132  vmovaps xmm7, [rsp+0x60]
000078af20be0138  vmovaps xmm8, [rsp+0x70]
000078af20be013e  vmovaps xmm9, [rsp+0x80]
000078af20be0147  vmovaps xmm10, [rsp+0x90]
000078af20be0150  vmovaps xmm11, [rsp+0xA0]
000078af20be0159  vmovaps xmm12, [rsp+0xB0]
000078af20be0162  vmovaps xmm13, [rsp+0xC0]
000078af20be016b  vmovaps xmm14, [rsp+0xD0]
000078af20be0174  vmovaps xmm15, [rsp+0xE0]
000078af20be017d  add rsp, 0xF0
000078af20be0184  pop r11
000078af20be0186  pop r10
000078af20be0188  pop r9
000078af20be018a  pop r8
000078af20be018c  pop rsi
000078af20be018d  pop rdi
000078af20be018e  pop rdx
000078af20be018f  pop rcx
000078af20be0190  pop rax
000078af20be0191  add rsp, 0x08
000078af20be0195  jmp 0x000078AF20BDEDB4
000078af20be019a  sub rsp, 0x08
000078af20be019e  push rax
000078af20be019f  push rcx
000078af20be01a0  push rdx
000078af20be01a1  push rdi
000078af20be01a2  push rsi
000078af20be01a3  push r8
000078af20be01a5  push r9
000078af20be01a7  push r10
000078af20be01a9  push r11
000078af20be01ab  sub rsp, 0xF0
000078af20be01b2  vmovaps [rsp], xmm0
000078af20be01b7  vmovaps [rsp+0x10], xmm1
000078af20be01bd  vmovaps [rsp+0x20], xmm2
000078af20be01c3  vmovaps [rsp+0x30], xmm4
000078af20be01c9  vmovaps [rsp+0x40], xmm5
000078af20be01cf  vmovaps [rsp+0x50], xmm6
000078af20be01d5  vmovaps [rsp+0x60], xmm7
000078af20be01db  vmovaps [rsp+0x70], xmm8
000078af20be01e1  vmovaps [rsp+0x80], xmm9
000078af20be01ea  vmovaps [rsp+0x90], xmm10
000078af20be01f3  vmovaps [rsp+0xA0], xmm11
000078af20be01fc  vmovaps [rsp+0xB0], xmm12
000078af20be0205  vmovaps [rsp+0xC0], xmm13
000078af20be020e  vmovaps [rsp+0xD0], xmm14
000078af20be0217  vmovaps [rsp+0xE0], xmm15
000078af20be0220  sub rsp, 0x30
000078af20be0224  movaps [rsp], xmm3
000078af20be0228  movaps [rsp+0x10], xmm5
000078af20be022d  movaps [rsp+0x20], xmm4
000078af20be0232  lea rdi, [rsp]
000078af20be0236  mov esi, 0x00
000078af20be023b  mov rax, 0x65452FFB8530
000078af20be0245  call rax
000078af20be0247  movaps xmm3, [rsp]
000078af20be024b  add rsp, 0x30
000078af20be024f  vmovaps xmm0, [rsp]
000078af20be0254  vmovaps xmm1, [rsp+0x10]
000078af20be025a  vmovaps xmm2, [rsp+0x20]
000078af20be0260  vmovaps xmm4, [rsp+0x30]
000078af20be0266  vmovaps xmm5, [rsp+0x40]
000078af20be026c  vmovaps xmm6, [rsp+0x50]
000078af20be0272  vmovaps xmm7, [rsp+0x60]
000078af20be0278  vmovaps xmm8, [rsp+0x70]
000078af20be027e  vmovaps xmm9, [rsp+0x80]
000078af20be0287  vmovaps xmm10, [rsp+0x90]
000078af20be0290  vmovaps xmm11, [rsp+0xA0]
000078af20be0299  vmovaps xmm12, [rsp+0xB0]
000078af20be02a2  vmovaps xmm13, [rsp+0xC0]
000078af20be02ab  vmovaps xmm14, [rsp+0xD0]
000078af20be02b4  vmovaps xmm15, [rsp+0xE0]
000078af20be02bd  add rsp, 0xF0
000078af20be02c4  pop r11
000078af20be02c6  pop r10
000078af20be02c8  pop r9
000078af20be02ca  pop r8
000078af20be02cc  pop rsi
000078af20be02cd  pop rdi
000078af20be02ce  pop rdx
000078af20be02cf  pop rcx
000078af20be02d0  pop rax
000078af20be02d1  add rsp, 0x08
000078af20be02d5  jmp 0x000078AF20BDEE15
000078af20be02da  sub rsp, 0x08
000078af20be02de  push rax
000078af20be02df  push rcx
000078af20be02e0  push rdx
000078af20be02e1  push rdi
000078af20be02e2  push rsi
000078af20be02e3  push r8
000078af20be02e5  push r9
000078af20be02e7  push r10
000078af20be02e9  push r11
000078af20be02eb  sub rsp, 0xF0
000078af20be02f2  vmovaps [rsp], xmm0
000078af20be02f7  vmovaps [rsp+0x10], xmm1
000078af20be02fd  vmovaps [rsp+0x20], xmm2
000078af20be0303  vmovaps [rsp+0x30], xmm3
000078af20be0309  vmovaps [rsp+0x40], xmm4
000078af20be030f  vmovaps [rsp+0x50], xmm6
000078af20be0315  vmovaps [rsp+0x60], xmm7
000078af20be031b  vmovaps [rsp+0x70], xmm8
000078af20be0321  vmovaps [rsp+0x80], xmm9
000078af20be032a  vmovaps [rsp+0x90], xmm10
000078af20be0333  vmovaps [rsp+0xA0], xmm11
000078af20be033c  vmovaps [rsp+0xB0], xmm12
000078af20be0345  vmovaps [rsp+0xC0], xmm13
000078af20be034e  vmovaps [rsp+0xD0], xmm14
000078af20be0357  vmovaps [rsp+0xE0], xmm15
000078af20be0360  sub rsp, 0x30
000078af20be0364  movaps [rsp], xmm5
000078af20be0368  movaps [rsp+0x10], xmm8
000078af20be036e  movaps [rsp+0x20], xmm15
000078af20be0374  lea rdi, [rsp]
000078af20be0378  mov esi, 0x00
000078af20be037d  mov rax, 0x65452FFB8530
000078af20be0387  call rax
000078af20be0389  movaps xmm5, [rsp]
000078af20be038d  add rsp, 0x30
000078af20be0391  vmovaps xmm0, [rsp]
000078af20be0396  vmovaps xmm1, [rsp+0x10]
000078af20be039c  vmovaps xmm2, [rsp+0x20]
000078af20be03a2  vmovaps xmm3, [rsp+0x30]
000078af20be03a8  vmovaps xmm4, [rsp+0x40]
000078af20be03ae  vmovaps xmm6, [rsp+0x50]
000078af20be03b4  vmovaps xmm7, [rsp+0x60]
000078af20be03ba  vmovaps xmm8, [rsp+0x70]
000078af20be03c0  vmovaps xmm9, [rsp+0x80]
000078af20be03c9  vmovaps xmm10, [rsp+0x90]
000078af20be03d2  vmovaps xmm11, [rsp+0xA0]
000078af20be03db  vmovaps xmm12, [rsp+0xB0]
000078af20be03e4  vmovaps xmm13, [rsp+0xC0]
000078af20be03ed  vmovaps xmm14, [rsp+0xD0]
000078af20be03f6  vmovaps xmm15, [rsp+0xE0]
000078af20be03ff  add rsp, 0xF0
000078af20be0406  pop r11
000078af20be0408  pop r10
000078af20be040a  pop r9
000078af20be040c  pop r8
000078af20be040e  pop rsi
000078af20be040f  pop rdi
000078af20be0410  pop rdx
000078af20be0411  pop rcx
000078af20be0412  pop rax
000078af20be0413  add rsp, 0x08
000078af20be0417  jmp 0x000078AF20BDEE53
000078af20be041c  sub rsp, 0x08
000078af20be0420  push rax
000078af20be0421  push rcx
000078af20be0422  push rdx
000078af20be0423  push rdi
000078af20be0424  push rsi
000078af20be0425  push r8
000078af20be0427  push r9
000078af20be0429  push r10
000078af20be042b  push r11
000078af20be042d  sub rsp, 0xF0
000078af20be0434  vmovaps [rsp], xmm0
000078af20be0439  vmovaps [rsp+0x10], xmm1
000078af20be043f  vmovaps [rsp+0x20], xmm2
000078af20be0445  vmovaps [rsp+0x30], xmm3
000078af20be044b  vmovaps [rsp+0x40], xmm5
000078af20be0451  vmovaps [rsp+0x50], xmm6
000078af20be0457  vmovaps [rsp+0x60], xmm7
000078af20be045d  vmovaps [rsp+0x70], xmm8
000078af20be0463  vmovaps [rsp+0x80], xmm9
000078af20be046c  vmovaps [rsp+0x90], xmm10
000078af20be0475  vmovaps [rsp+0xA0], xmm11
000078af20be047e  vmovaps [rsp+0xB0], xmm12
000078af20be0487  vmovaps [rsp+0xC0], xmm13
000078af20be0490  vmovaps [rsp+0xD0], xmm14
000078af20be0499  vmovaps [rsp+0xE0], xmm15
000078af20be04a2  sub rsp, 0x30
000078af20be04a6  movaps [rsp], xmm4
000078af20be04aa  movaps [rsp+0x10], xmm9
000078af20be04b0  movaps [rsp+0x20], xmm8
000078af20be04b6  lea rdi, [rsp]
000078af20be04ba  mov esi, 0x00
000078af20be04bf  mov rax, 0x65452FFB8530
000078af20be04c9  call rax
000078af20be04cb  movaps xmm4, [rsp]
000078af20be04cf  add rsp, 0x30
000078af20be04d3  vmovaps xmm0, [rsp]
000078af20be04d8  vmovaps xmm1, [rsp+0x10]
000078af20be04de  vmovaps xmm2, [rsp+0x20]
000078af20be04e4  vmovaps xmm3, [rsp+0x30]
000078af20be04ea  vmovaps xmm5, [rsp+0x40]
000078af20be04f0  vmovaps xmm6, [rsp+0x50]
000078af20be04f6  vmovaps xmm7, [rsp+0x60]
000078af20be04fc  vmovaps xmm8, [rsp+0x70]
000078af20be0502  vmovaps xmm9, [rsp+0x80]
000078af20be050b  vmovaps xmm10, [rsp+0x90]
000078af20be0514  vmovaps xmm11, [rsp+0xA0]
000078af20be051d  vmovaps xmm12, [rsp+0xB0]
000078af20be0526  vmovaps xmm13, [rsp+0xC0]
000078af20be052f  vmovaps xmm14, [rsp+0xD0]
000078af20be0538  vmovaps xmm15, [rsp+0xE0]
000078af20be0541  add rsp, 0xF0
000078af20be0548  pop r11
000078af20be054a  pop r10
000078af20be054c  pop r9
000078af20be054e  pop r8
000078af20be0550  pop rsi
000078af20be0551  pop rdi
000078af20be0552  pop rdx
000078af20be0553  pop rcx
000078af20be0554  pop rax
000078af20be0555  add rsp, 0x08
000078af20be0559  jmp 0x000078AF20BDEE74
000078af20be055e  sub rsp, 0x08
000078af20be0562  push rax
000078af20be0563  push rcx
000078af20be0564  push rdx
000078af20be0565  push rdi
000078af20be0566  push rsi
000078af20be0567  push r8
000078af20be0569  push r9
000078af20be056b  push r10
000078af20be056d  push r11
000078af20be056f  sub rsp, 0xF0
000078af20be0576  vmovaps [rsp], xmm0
000078af20be057b  vmovaps [rsp+0x10], xmm1
000078af20be0581  vmovaps [rsp+0x20], xmm2
000078af20be0587  vmovaps [rsp+0x30], xmm3
000078af20be058d  vmovaps [rsp+0x40], xmm4
000078af20be0593  vmovaps [rsp+0x50], xmm5
000078af20be0599  vmovaps [rsp+0x60], xmm6
000078af20be059f  vmovaps [rsp+0x70], xmm7
000078af20be05a5  vmovaps [rsp+0x80], xmm8
000078af20be05ae  vmovaps [rsp+0x90], xmm10
000078af20be05b7  vmovaps [rsp+0xA0], xmm11
000078af20be05c0  vmovaps [rsp+0xB0], xmm12
000078af20be05c9  vmovaps [rsp+0xC0], xmm13
000078af20be05d2  vmovaps [rsp+0xD0], xmm14
000078af20be05db  vmovaps [rsp+0xE0], xmm15
000078af20be05e4  sub rsp, 0x30
000078af20be05e8  movaps [rsp], xmm9
000078af20be05ed  movaps [rsp+0x10], xmm10
000078af20be05f3  movaps [rsp+0x20], xmm8
000078af20be05f9  lea rdi, [rsp]
000078af20be05fd  mov esi, 0x00
000078af20be0602  mov rax, 0x65452FFB8530
000078af20be060c  call rax
000078af20be060e  movaps xmm9, [rsp]
000078af20be0613  add rsp, 0x30
000078af20be0617  vmovaps xmm0, [rsp]
000078af20be061c  vmovaps xmm1, [rsp+0x10]
000078af20be0622  vmovaps xmm2, [rsp+0x20]
000078af20be0628  vmovaps xmm3, [rsp+0x30]
000078af20be062e  vmovaps xmm4, [rsp+0x40]
000078af20be0634  vmovaps xmm5, [rsp+0x50]
000078af20be063a  vmovaps xmm6, [rsp+0x60]
000078af20be0640  vmovaps xmm7, [rsp+0x70]
000078af20be0646  vmovaps xmm8, [rsp+0x80]
000078af20be064f  vmovaps xmm10, [rsp+0x90]
000078af20be0658  vmovaps xmm11, [rsp+0xA0]
000078af20be0661  vmovaps xmm12, [rsp+0xB0]
000078af20be066a  vmovaps xmm13, [rsp+0xC0]
000078af20be0673  vmovaps xmm14, [rsp+0xD0]
000078af20be067c  vmovaps xmm15, [rsp+0xE0]
000078af20be0685  add rsp, 0xF0
000078af20be068c  pop r11
000078af20be068e  pop r10
000078af20be0690  pop r9
000078af20be0692  pop r8
000078af20be0694  pop rsi
000078af20be0695  pop rdi
000078af20be0696  pop rdx
000078af20be0697  pop rcx
000078af20be0698  pop rax
000078af20be0699  add rsp, 0x08
000078af20be069d  jmp 0x000078AF20BDEE8E
000078af20be06a2  call 0x000078AF20AB52F0
000078af20be06a7  jmp 0x000078AF20BDEFA8
000078af20be06ac  call 0x000078AF20AB52F0
000078af20be06b1  jmp 0x000078AF20BDEFBE
000078af20be06b6  sub rsp, 0x08
000078af20be06ba  push rax
000078af20be06bb  push rcx
000078af20be06bc  push rdx
000078af20be06bd  push rdi
000078af20be06be  push rsi
000078af20be06bf  push r8
000078af20be06c1  push r9
000078af20be06c3  push r10
000078af20be06c5  push r11
000078af20be06c7  sub rsp, 0xF0
000078af20be06ce  vmovaps [rsp], xmm0
000078af20be06d3  vmovaps [rsp+0x10], xmm2
000078af20be06d9  vmovaps [rsp+0x20], xmm3
000078af20be06df  vmovaps [rsp+0x30], xmm4
000078af20be06e5  vmovaps [rsp+0x40], xmm5
000078af20be06eb  vmovaps [rsp+0x50], xmm6
000078af20be06f1  vmovaps [rsp+0x60], xmm7
000078af20be06f7  vmovaps [rsp+0x70], xmm8
000078af20be06fd  vmovaps [rsp+0x80], xmm9
000078af20be0706  vmovaps [rsp+0x90], xmm10
000078af20be070f  vmovaps [rsp+0xA0], xmm11
000078af20be0718  vmovaps [rsp+0xB0], xmm12
000078af20be0721  vmovaps [rsp+0xC0], xmm13
000078af20be072a  vmovaps [rsp+0xD0], xmm14
000078af20be0733  vmovaps [rsp+0xE0], xmm15
000078af20be073c  sub rsp, 0x30
000078af20be0740  movaps [rsp], xmm1
000078af20be0744  movaps [rsp+0x10], xmm6
000078af20be0749  movaps [rsp+0x20], xmm15
000078af20be074f  lea rdi, [rsp]
000078af20be0753  mov esi, 0x00
000078af20be0758  mov rax, 0x65452FFB8530
000078af20be0762  call rax
000078af20be0764  movaps xmm1, [rsp]
000078af20be0768  add rsp, 0x30
000078af20be076c  vmovaps xmm0, [rsp]
000078af20be0771  vmovaps xmm2, [rsp+0x10]
000078af20be0777  vmovaps xmm3, [rsp+0x20]
000078af20be077d  vmovaps xmm4, [rsp+0x30]
000078af20be0783  vmovaps xmm5, [rsp+0x40]
000078af20be0789  vmovaps xmm6, [rsp+0x50]
000078af20be078f  vmovaps xmm7, [rsp+0x60]
000078af20be0795  vmovaps xmm8, [rsp+0x70]
000078af20be079b  vmovaps xmm9, [rsp+0x80]
000078af20be07a4  vmovaps xmm10, [rsp+0x90]
000078af20be07ad  vmovaps xmm11, [rsp+0xA0]
000078af20be07b6  vmovaps xmm12, [rsp+0xB0]
000078af20be07bf  vmovaps xmm13, [rsp+0xC0]
000078af20be07c8  vmovaps xmm14, [rsp+0xD0]
000078af20be07d1  vmovaps xmm15, [rsp+0xE0]
000078af20be07da  add rsp, 0xF0
000078af20be07e1  pop r11
000078af20be07e3  pop r10
000078af20be07e5  pop r9
000078af20be07e7  pop r8
000078af20be07e9  pop rsi
000078af20be07ea  pop rdi
000078af20be07eb  pop rdx
000078af20be07ec  pop rcx
000078af20be07ed  pop rax
000078af20be07ee  add rsp, 0x08
000078af20be07f2  jmp 0x000078AF20BDEFFB
000078af20be07f7  call 0x000078AF20AC4620
000078af20be07fc  jmp 0x000078AF20BDF008
000078af20be0801  sub rsp, 0x08
000078af20be0805  push rax
000078af20be0806  push rcx
000078af20be0807  push rdx
000078af20be0808  push rdi
000078af20be0809  push rsi
000078af20be080a  push r8
000078af20be080c  push r9
000078af20be080e  push r10
000078af20be0810  push r11
000078af20be0812  sub rsp, 0xF0
000078af20be0819  vmovaps [rsp], xmm0
000078af20be081e  vmovaps [rsp+0x10], xmm1
000078af20be0824  vmovaps [rsp+0x20], xmm2
000078af20be082a  vmovaps [rsp+0x30], xmm3
000078af20be0830  vmovaps [rsp+0x40], xmm4
000078af20be0836  vmovaps [rsp+0x50], xmm5
000078af20be083c  vmovaps [rsp+0x60], xmm6
000078af20be0842  vmovaps [rsp+0x70], xmm7
000078af20be0848  vmovaps [rsp+0x80], xmm8
000078af20be0851  vmovaps [rsp+0x90], xmm9
000078af20be085a  vmovaps [rsp+0xA0], xmm10
000078af20be0863  vmovaps [rsp+0xB0], xmm11
000078af20be086c  vmovaps [rsp+0xC0], xmm12
000078af20be0875  vmovaps [rsp+0xD0], xmm13
000078af20be087e  vmovaps [rsp+0xE0], xmm15
000078af20be0887  sub rsp, 0x30
000078af20be088b  movaps [rsp], xmm14
000078af20be0890  movaps [rsp+0x10], xmm4
000078af20be0895  movaps [rsp+0x20], xmm3
000078af20be089a  lea rdi, [rsp]
000078af20be089e  mov esi, 0x00
000078af20be08a3  mov rax, 0x65452FFB8530
000078af20be08ad  call rax
000078af20be08af  movaps xmm14, [rsp]
000078af20be08b4  add rsp, 0x30
000078af20be08b8  vmovaps xmm0, [rsp]
000078af20be08bd  vmovaps xmm1, [rsp+0x10]
000078af20be08c3  vmovaps xmm2, [rsp+0x20]
000078af20be08c9  vmovaps xmm3, [rsp+0x30]
000078af20be08cf  vmovaps xmm4, [rsp+0x40]
000078af20be08d5  vmovaps xmm5, [rsp+0x50]
000078af20be08db  vmovaps xmm6, [rsp+0x60]
000078af20be08e1  vmovaps xmm7, [rsp+0x70]
000078af20be08e7  vmovaps xmm8, [rsp+0x80]
000078af20be08f0  vmovaps xmm9, [rsp+0x90]
000078af20be08f9  vmovaps xmm10, [rsp+0xA0]
000078af20be0902  vmovaps xmm11, [rsp+0xB0]
000078af20be090b  vmovaps xmm12, [rsp+0xC0]
000078af20be0914  vmovaps xmm13, [rsp+0xD0]
000078af20be091d  vmovaps xmm15, [rsp+0xE0]
000078af20be0926  add rsp, 0xF0
000078af20be092d  pop r11
000078af20be092f  pop r10
000078af20be0931  pop r9
000078af20be0933  pop r8
000078af20be0935  pop rsi
000078af20be0936  pop rdi
000078af20be0937  pop rdx
000078af20be0938  pop rcx
000078af20be0939  pop rax
000078af20be093a  add rsp, 0x08
000078af20be093e  jmp 0x000078AF20BDF022
000078af20be0943  sub rsp, 0x08
000078af20be0947  push rax
000078af20be0948  push rcx
000078af20be0949  push rdx
000078af20be094a  push rdi
000078af20be094b  push rsi
000078af20be094c  push r8
000078af20be094e  push r9
000078af20be0950  push r10
000078af20be0952  push r11
000078af20be0954  sub rsp, 0xF0
000078af20be095b  vmovaps [rsp], xmm0
000078af20be0960  vmovaps [rsp+0x10], xmm1
000078af20be0966  vmovaps [rsp+0x20], xmm2
000078af20be096c  vmovaps [rsp+0x30], xmm3
000078af20be0972  vmovaps [rsp+0x40], xmm4
000078af20be0978  vmovaps [rsp+0x50], xmm5
000078af20be097e  vmovaps [rsp+0x60], xmm7
000078af20be0984  vmovaps [rsp+0x70], xmm8
000078af20be098a  vmovaps [rsp+0x80], xmm9
000078af20be0993  vmovaps [rsp+0x90], xmm10
000078af20be099c  vmovaps [rsp+0xA0], xmm11
000078af20be09a5  vmovaps [rsp+0xB0], xmm12
000078af20be09ae  vmovaps [rsp+0xC0], xmm13
000078af20be09b7  vmovaps [rsp+0xD0], xmm14
000078af20be09c0  vmovaps [rsp+0xE0], xmm15
000078af20be09c9  sub rsp, 0x30
000078af20be09cd  movaps [rsp], xmm6
000078af20be09d1  movaps [rsp+0x10], xmm9
000078af20be09d7  movaps [rsp+0x20], xmm7
000078af20be09dc  lea rdi, [rsp]
000078af20be09e0  mov esi, 0x00
000078af20be09e5  mov rax, 0x65452FFB8530
000078af20be09ef  call rax
000078af20be09f1  movaps xmm6, [rsp]
000078af20be09f5  add rsp, 0x30
000078af20be09f9  vmovaps xmm0, [rsp]
000078af20be09fe  vmovaps xmm1, [rsp+0x10]
000078af20be0a04  vmovaps xmm2, [rsp+0x20]
000078af20be0a0a  vmovaps xmm3, [rsp+0x30]
000078af20be0a10  vmovaps xmm4, [rsp+0x40]
000078af20be0a16  vmovaps xmm5, [rsp+0x50]
000078af20be0a1c  vmovaps xmm7, [rsp+0x60]
000078af20be0a22  vmovaps xmm8, [rsp+0x70]
000078af20be0a28  vmovaps xmm9, [rsp+0x80]
000078af20be0a31  vmovaps xmm10, [rsp+0x90]
000078af20be0a3a  vmovaps xmm11, [rsp+0xA0]
000078af20be0a43  vmovaps xmm12, [rsp+0xB0]
000078af20be0a4c  vmovaps xmm13, [rsp+0xC0]
000078af20be0a55  vmovaps xmm14, [rsp+0xD0]
000078af20be0a5e  vmovaps xmm15, [rsp+0xE0]
000078af20be0a67  add rsp, 0xF0
000078af20be0a6e  pop r11
000078af20be0a70  pop r10
000078af20be0a72  pop r9
000078af20be0a74  pop r8
000078af20be0a76  pop rsi
000078af20be0a77  pop rdi
000078af20be0a78  pop rdx
000078af20be0a79  pop rcx
000078af20be0a7a  pop rax
000078af20be0a7b  add rsp, 0x08
000078af20be0a7f  jmp 0x000078AF20BDF03A
000078af20be0a84  sub rsp, 0x08
000078af20be0a88  push rax
000078af20be0a89  push rcx
000078af20be0a8a  push rdx
000078af20be0a8b  push rdi
000078af20be0a8c  push rsi
000078af20be0a8d  push r8
000078af20be0a8f  push r9
000078af20be0a91  push r10
000078af20be0a93  push r11
000078af20be0a95  sub rsp, 0xF0
000078af20be0a9c  vmovaps [rsp], xmm0
000078af20be0aa1  vmovaps [rsp+0x10], xmm1
000078af20be0aa7  vmovaps [rsp+0x20], xmm2
000078af20be0aad  vmovaps [rsp+0x30], xmm3
000078af20be0ab3  vmovaps [rsp+0x40], xmm4
000078af20be0ab9  vmovaps [rsp+0x50], xmm5
000078af20be0abf  vmovaps [rsp+0x60], xmm6
000078af20be0ac5  vmovaps [rsp+0x70], xmm8
000078af20be0acb  vmovaps [rsp+0x80], xmm9
000078af20be0ad4  vmovaps [rsp+0x90], xmm10
000078af20be0add  vmovaps [rsp+0xA0], xmm11
000078af20be0ae6  vmovaps [rsp+0xB0], xmm12
000078af20be0aef  vmovaps [rsp+0xC0], xmm13
000078af20be0af8  vmovaps [rsp+0xD0], xmm14
000078af20be0b01  vmovaps [rsp+0xE0], xmm15
000078af20be0b0a  sub rsp, 0x30
000078af20be0b0e  movaps [rsp], xmm7
000078af20be0b12  movaps [rsp+0x10], xmm4
000078af20be0b17  movaps [rsp+0x20], xmm9
000078af20be0b1d  lea rdi, [rsp]
000078af20be0b21  mov esi, 0x00
000078af20be0b26  mov rax, 0x65452FFB8530
000078af20be0b30  call rax
000078af20be0b32  movaps xmm7, [rsp]
000078af20be0b36  add rsp, 0x30
000078af20be0b3a  vmovaps xmm0, [rsp]
000078af20be0b3f  vmovaps xmm1, [rsp+0x10]
000078af20be0b45  vmovaps xmm2, [rsp+0x20]
000078af20be0b4b  vmovaps xmm3, [rsp+0x30]
000078af20be0b51  vmovaps xmm4, [rsp+0x40]
000078af20be0b57  vmovaps xmm5, [rsp+0x50]
000078af20be0b5d  vmovaps xmm6, [rsp+0x60]
000078af20be0b63  vmovaps xmm8, [rsp+0x70]
000078af20be0b69  vmovaps xmm9, [rsp+0x80]
000078af20be0b72  vmovaps xmm10, [rsp+0x90]
000078af20be0b7b  vmovaps xmm11, [rsp+0xA0]
000078af20be0b84  vmovaps xmm12, [rsp+0xB0]
000078af20be0b8d  vmovaps xmm13, [rsp+0xC0]
000078af20be0b96  vmovaps xmm14, [rsp+0xD0]
000078af20be0b9f  vmovaps xmm15, [rsp+0xE0]
000078af20be0ba8  add rsp, 0xF0
000078af20be0baf  pop r11
000078af20be0bb1  pop r10
000078af20be0bb3  pop r9
000078af20be0bb5  pop r8
000078af20be0bb7  pop rsi
000078af20be0bb8  pop rdi
000078af20be0bb9  pop rdx
000078af20be0bba  pop rcx
000078af20be0bbb  pop rax
000078af20be0bbc  add rsp, 0x08
000078af20be0bc0  jmp 0x000078AF20BDF067
000078af20be0bc5  sub rsp, 0x08
000078af20be0bc9  push rax
000078af20be0bca  push rcx
000078af20be0bcb  push rdx
000078af20be0bcc  push rdi
000078af20be0bcd  push rsi
000078af20be0bce  push r8
000078af20be0bd0  push r9
000078af20be0bd2  push r10
000078af20be0bd4  push r11
000078af20be0bd6  sub rsp, 0xF0
000078af20be0bdd  vmovaps [rsp], xmm0
000078af20be0be2  vmovaps [rsp+0x10], xmm1
000078af20be0be8  vmovaps [rsp+0x20], xmm2
000078af20be0bee  vmovaps [rsp+0x30], xmm3
000078af20be0bf4  vmovaps [rsp+0x40], xmm5
000078af20be0bfa  vmovaps [rsp+0x50], xmm6
000078af20be0c00  vmovaps [rsp+0x60], xmm7
000078af20be0c06  vmovaps [rsp+0x70], xmm8
000078af20be0c0c  vmovaps [rsp+0x80], xmm9
000078af20be0c15  vmovaps [rsp+0x90], xmm10
000078af20be0c1e  vmovaps [rsp+0xA0], xmm11
000078af20be0c27  vmovaps [rsp+0xB0], xmm12
000078af20be0c30  vmovaps [rsp+0xC0], xmm13
000078af20be0c39  vmovaps [rsp+0xD0], xmm14
000078af20be0c42  vmovaps [rsp+0xE0], xmm15
000078af20be0c4b  sub rsp, 0x30
000078af20be0c4f  movaps [rsp], xmm4
000078af20be0c53  movaps [rsp+0x10], xmm15
000078af20be0c59  movaps [rsp+0x20], xmm9
000078af20be0c5f  lea rdi, [rsp]
000078af20be0c63  mov esi, 0x00
000078af20be0c68  mov rax, 0x65452FFB8530
000078af20be0c72  call rax
000078af20be0c74  movaps xmm4, [rsp]
000078af20be0c78  add rsp, 0x30
000078af20be0c7c  vmovaps xmm0, [rsp]
000078af20be0c81  vmovaps xmm1, [rsp+0x10]
000078af20be0c87  vmovaps xmm2, [rsp+0x20]
000078af20be0c8d  vmovaps xmm3, [rsp+0x30]
000078af20be0c93  vmovaps xmm5, [rsp+0x40]
000078af20be0c99  vmovaps xmm6, [rsp+0x50]
000078af20be0c9f  vmovaps xmm7, [rsp+0x60]
000078af20be0ca5  vmovaps xmm8, [rsp+0x70]
000078af20be0cab  vmovaps xmm9, [rsp+0x80]
000078af20be0cb4  vmovaps xmm10, [rsp+0x90]
000078af20be0cbd  vmovaps xmm11, [rsp+0xA0]
000078af20be0cc6  vmovaps xmm12, [rsp+0xB0]
000078af20be0ccf  vmovaps xmm13, [rsp+0xC0]
000078af20be0cd8  vmovaps xmm14, [rsp+0xD0]
000078af20be0ce1  vmovaps xmm15, [rsp+0xE0]
000078af20be0cea  add rsp, 0xF0
000078af20be0cf1  pop r11
000078af20be0cf3  pop r10
000078af20be0cf5  pop r9
000078af20be0cf7  pop r8
000078af20be0cf9  pop rsi
000078af20be0cfa  pop rdi
000078af20be0cfb  pop rdx
000078af20be0cfc  pop rcx
000078af20be0cfd  pop rax
000078af20be0cfe  add rsp, 0x08
000078af20be0d02  jmp 0x000078AF20BDF08C
000078af20be0d07  call 0x000078AF20AC4620
000078af20be0d0c  jmp 0x000078AF20BDF099
000078af20be0d11  sub rsp, 0x08
000078af20be0d15  push rax
000078af20be0d16  push rcx
000078af20be0d17  push rdx
000078af20be0d18  push rdi
000078af20be0d19  push rsi
000078af20be0d1a  push r8
000078af20be0d1c  push r9
000078af20be0d1e  push r10
000078af20be0d20  push r11
000078af20be0d22  sub rsp, 0xF0
000078af20be0d29  vmovaps [rsp], xmm0
000078af20be0d2e  vmovaps [rsp+0x10], xmm1
000078af20be0d34  vmovaps [rsp+0x20], xmm2
000078af20be0d3a  vmovaps [rsp+0x30], xmm4
000078af20be0d40  vmovaps [rsp+0x40], xmm5
000078af20be0d46  vmovaps [rsp+0x50], xmm6
000078af20be0d4c  vmovaps [rsp+0x60], xmm7
000078af20be0d52  vmovaps [rsp+0x70], xmm8
000078af20be0d58  vmovaps [rsp+0x80], xmm9
000078af20be0d61  vmovaps [rsp+0x90], xmm10
000078af20be0d6a  vmovaps [rsp+0xA0], xmm11
000078af20be0d73  vmovaps [rsp+0xB0], xmm12
000078af20be0d7c  vmovaps [rsp+0xC0], xmm13
000078af20be0d85  vmovaps [rsp+0xD0], xmm14
000078af20be0d8e  vmovaps [rsp+0xE0], xmm15
000078af20be0d97  sub rsp, 0x30
000078af20be0d9b  movaps [rsp], xmm3
000078af20be0d9f  movaps [rsp+0x10], xmm1
000078af20be0da4  movaps [rsp+0x20], xmm9
000078af20be0daa  lea rdi, [rsp]
000078af20be0dae  mov esi, 0x00
000078af20be0db3  mov rax, 0x65452FFB8530
000078af20be0dbd  call rax
000078af20be0dbf  movaps xmm3, [rsp]
000078af20be0dc3  add rsp, 0x30
000078af20be0dc7  vmovaps xmm0, [rsp]
000078af20be0dcc  vmovaps xmm1, [rsp+0x10]
000078af20be0dd2  vmovaps xmm2, [rsp+0x20]
000078af20be0dd8  vmovaps xmm4, [rsp+0x30]
000078af20be0dde  vmovaps xmm5, [rsp+0x40]
000078af20be0de4  vmovaps xmm6, [rsp+0x50]
000078af20be0dea  vmovaps xmm7, [rsp+0x60]
000078af20be0df0  vmovaps xmm8, [rsp+0x70]
000078af20be0df6  vmovaps xmm9, [rsp+0x80]
000078af20be0dff  vmovaps xmm10, [rsp+0x90]
000078af20be0e08  vmovaps xmm11, [rsp+0xA0]
000078af20be0e11  vmovaps xmm12, [rsp+0xB0]
000078af20be0e1a  vmovaps xmm13, [rsp+0xC0]
000078af20be0e23  vmovaps xmm14, [rsp+0xD0]
000078af20be0e2c  vmovaps xmm15, [rsp+0xE0]
000078af20be0e35  add rsp, 0xF0
000078af20be0e3c  pop r11
000078af20be0e3e  pop r10
000078af20be0e40  pop r9
000078af20be0e42  pop r8
000078af20be0e44  pop rsi
000078af20be0e45  pop rdi
000078af20be0e46  pop rdx
000078af20be0e47  pop rcx
000078af20be0e48  pop rax
000078af20be0e49  add rsp, 0x08
000078af20be0e4d  jmp 0x000078AF20BDF0D6
000078af20be0e52  sub rsp, 0x08
000078af20be0e56  push rax
000078af20be0e57  push rcx
000078af20be0e58  push rdx
000078af20be0e59  push rdi
000078af20be0e5a  push rsi
000078af20be0e5b  push r8
000078af20be0e5d  push r9
000078af20be0e5f  push r10
000078af20be0e61  push r11
000078af20be0e63  sub rsp, 0xF0
000078af20be0e6a  vmovaps [rsp], xmm0
000078af20be0e6f  vmovaps [rsp+0x10], xmm2
000078af20be0e75  vmovaps [rsp+0x20], xmm3
000078af20be0e7b  vmovaps [rsp+0x30], xmm4
000078af20be0e81  vmovaps [rsp+0x40], xmm5
000078af20be0e87  vmovaps [rsp+0x50], xmm6
000078af20be0e8d  vmovaps [rsp+0x60], xmm7
000078af20be0e93  vmovaps [rsp+0x70], xmm8
000078af20be0e99  vmovaps [rsp+0x80], xmm9
000078af20be0ea2  vmovaps [rsp+0x90], xmm10
000078af20be0eab  vmovaps [rsp+0xA0], xmm11
000078af20be0eb4  vmovaps [rsp+0xB0], xmm12
000078af20be0ebd  vmovaps [rsp+0xC0], xmm13
000078af20be0ec6  vmovaps [rsp+0xD0], xmm14
000078af20be0ecf  vmovaps [rsp+0xE0], xmm15
000078af20be0ed8  sub rsp, 0x30
000078af20be0edc  movaps [rsp], xmm1
000078af20be0ee0  movaps [rsp+0x10], xmm15
000078af20be0ee6  movaps [rsp+0x20], xmm9
000078af20be0eec  lea rdi, [rsp]
000078af20be0ef0  mov esi, 0x00
000078af20be0ef5  mov rax, 0x65452FFB8530
000078af20be0eff  call rax
000078af20be0f01  movaps xmm1, [rsp]
000078af20be0f05  add rsp, 0x30
000078af20be0f09  vmovaps xmm0, [rsp]
000078af20be0f0e  vmovaps xmm2, [rsp+0x10]
000078af20be0f14  vmovaps xmm3, [rsp+0x20]
000078af20be0f1a  vmovaps xmm4, [rsp+0x30]
000078af20be0f20  vmovaps xmm5, [rsp+0x40]
000078af20be0f26  vmovaps xmm6, [rsp+0x50]
000078af20be0f2c  vmovaps xmm7, [rsp+0x60]
000078af20be0f32  vmovaps xmm8, [rsp+0x70]
000078af20be0f38  vmovaps xmm9, [rsp+0x80]
000078af20be0f41  vmovaps xmm10, [rsp+0x90]
000078af20be0f4a  vmovaps xmm11, [rsp+0xA0]
000078af20be0f53  vmovaps xmm12, [rsp+0xB0]
000078af20be0f5c  vmovaps xmm13, [rsp+0xC0]
000078af20be0f65  vmovaps xmm14, [rsp+0xD0]
000078af20be0f6e  vmovaps xmm15, [rsp+0xE0]
000078af20be0f77  add rsp, 0xF0
000078af20be0f7e  pop r11
000078af20be0f80  pop r10
000078af20be0f82  pop r9
000078af20be0f84  pop r8
000078af20be0f86  pop rsi
000078af20be0f87  pop rdi
000078af20be0f88  pop rdx
000078af20be0f89  pop rcx
000078af20be0f8a  pop rax
000078af20be0f8b  add rsp, 0x08
000078af20be0f8f  jmp 0x000078AF20BDF15E
000078af20be0f94  call 0x000078AF20AC4620
000078af20be0f99  jmp 0x000078AF20BDF16B
000078af20be0f9e  sub rsp, 0x08
000078af20be0fa2  push rax
000078af20be0fa3  push rcx
000078af20be0fa4  push rdx
000078af20be0fa5  push rdi
000078af20be0fa6  push rsi
000078af20be0fa7  push r8
000078af20be0fa9  push r9
000078af20be0fab  push r10
000078af20be0fad  push r11
000078af20be0faf  sub rsp, 0xF0
000078af20be0fb6  vmovaps [rsp], xmm0
000078af20be0fbb  vmovaps [rsp+0x10], xmm2
000078af20be0fc1  vmovaps [rsp+0x20], xmm3
000078af20be0fc7  vmovaps [rsp+0x30], xmm4
000078af20be0fcd  vmovaps [rsp+0x40], xmm5
000078af20be0fd3  vmovaps [rsp+0x50], xmm6
000078af20be0fd9  vmovaps [rsp+0x60], xmm7
000078af20be0fdf  vmovaps [rsp+0x70], xmm8
000078af20be0fe5  vmovaps [rsp+0x80], xmm9
000078af20be0fee  vmovaps [rsp+0x90], xmm10
000078af20be0ff7  vmovaps [rsp+0xA0], xmm11
000078af20be1000  vmovaps [rsp+0xB0], xmm12
000078af20be1009  vmovaps [rsp+0xC0], xmm13
000078af20be1012  vmovaps [rsp+0xD0], xmm14
000078af20be101b  vmovaps [rsp+0xE0], xmm15
000078af20be1024  sub rsp, 0x30
000078af20be1028  movaps [rsp], xmm1
000078af20be102c  movaps [rsp+0x10], xmm5
000078af20be1031  movaps [rsp+0x20], xmm7
000078af20be1036  lea rdi, [rsp]
000078af20be103a  mov esi, 0x00
000078af20be103f  mov rax, 0x65452FFB8530
000078af20be1049  call rax
000078af20be104b  movaps xmm1, [rsp]
000078af20be104f  add rsp, 0x30
000078af20be1053  vmovaps xmm0, [rsp]
000078af20be1058  vmovaps xmm2, [rsp+0x10]
000078af20be105e  vmovaps xmm3, [rsp+0x20]
000078af20be1064  vmovaps xmm4, [rsp+0x30]
000078af20be106a  vmovaps xmm5, [rsp+0x40]
000078af20be1070  vmovaps xmm6, [rsp+0x50]
000078af20be1076  vmovaps xmm7, [rsp+0x60]
000078af20be107c  vmovaps xmm8, [rsp+0x70]
000078af20be1082  vmovaps xmm9, [rsp+0x80]
000078af20be108b  vmovaps xmm10, [rsp+0x90]
000078af20be1094  vmovaps xmm11, [rsp+0xA0]
000078af20be109d  vmovaps xmm12, [rsp+0xB0]
000078af20be10a6  vmovaps xmm13, [rsp+0xC0]
000078af20be10af  vmovaps xmm14, [rsp+0xD0]
000078af20be10b8  vmovaps xmm15, [rsp+0xE0]
000078af20be10c1  add rsp, 0xF0
000078af20be10c8  pop r11
000078af20be10ca  pop r10
000078af20be10cc  pop r9
000078af20be10ce  pop r8
000078af20be10d0  pop rsi
000078af20be10d1  pop rdi
000078af20be10d2  pop rdx
000078af20be10d3  pop rcx
000078af20be10d4  pop rax
000078af20be10d5  add rsp, 0x08
000078af20be10d9  jmp 0x000078AF20BDF210
000078af20be10de  sub rsp, 0x08
000078af20be10e2  push rax
000078af20be10e3  push rcx
000078af20be10e4  push rdx
000078af20be10e5  push rdi
000078af20be10e6  push rsi
000078af20be10e7  push r8
000078af20be10e9  push r9
000078af20be10eb  push r10
000078af20be10ed  push r11
000078af20be10ef  sub rsp, 0xF0
000078af20be10f6  vmovaps [rsp], xmm0
000078af20be10fb  vmovaps [rsp+0x10], xmm1
000078af20be1101  vmovaps [rsp+0x20], xmm2
000078af20be1107  vmovaps [rsp+0x30], xmm3
000078af20be110d  vmovaps [rsp+0x40], xmm4
000078af20be1113  vmovaps [rsp+0x50], xmm5
000078af20be1119  vmovaps [rsp+0x60], xmm6
000078af20be111f  vmovaps [rsp+0x70], xmm8
000078af20be1125  vmovaps [rsp+0x80], xmm9
000078af20be112e  vmovaps [rsp+0x90], xmm10
000078af20be1137  vmovaps [rsp+0xA0], xmm11
000078af20be1140  vmovaps [rsp+0xB0], xmm12
000078af20be1149  vmovaps [rsp+0xC0], xmm13
000078af20be1152  vmovaps [rsp+0xD0], xmm14
000078af20be115b  vmovaps [rsp+0xE0], xmm15
000078af20be1164  sub rsp, 0x30
000078af20be1168  movaps [rsp], xmm7
000078af20be116c  movaps [rsp+0x10], xmm5
000078af20be1171  movaps [rsp+0x20], xmm15
000078af20be1177  lea rdi, [rsp]
000078af20be117b  mov esi, 0x00
000078af20be1180  mov rax, 0x65452FFB8530
000078af20be118a  call rax
000078af20be118c  movaps xmm7, [rsp]
000078af20be1190  add rsp, 0x30
000078af20be1194  vmovaps xmm0, [rsp]
000078af20be1199  vmovaps xmm1, [rsp+0x10]
000078af20be119f  vmovaps xmm2, [rsp+0x20]
000078af20be11a5  vmovaps xmm3, [rsp+0x30]
000078af20be11ab  vmovaps xmm4, [rsp+0x40]
000078af20be11b1  vmovaps xmm5, [rsp+0x50]
000078af20be11b7  vmovaps xmm6, [rsp+0x60]
000078af20be11bd  vmovaps xmm8, [rsp+0x70]
000078af20be11c3  vmovaps xmm9, [rsp+0x80]
000078af20be11cc  vmovaps xmm10, [rsp+0x90]
000078af20be11d5  vmovaps xmm11, [rsp+0xA0]
000078af20be11de  vmovaps xmm12, [rsp+0xB0]
000078af20be11e7  vmovaps xmm13, [rsp+0xC0]
000078af20be11f0  vmovaps xmm14, [rsp+0xD0]
000078af20be11f9  vmovaps xmm15, [rsp+0xE0]
000078af20be1202  add rsp, 0xF0
000078af20be1209  pop r11
000078af20be120b  pop r10
000078af20be120d  pop r9
000078af20be120f  pop r8
000078af20be1211  pop rsi
000078af20be1212  pop rdi
000078af20be1213  pop rdx
000078af20be1214  pop rcx
000078af20be1215  pop rax
000078af20be1216  add rsp, 0x08
000078af20be121a  jmp 0x000078AF20BDF246
000078af20be121f  call 0x000078AF20AB52F0
000078af20be1224  jmp 0x000078AF20BDF253
000078af20be1229  sub rsp, 0x08
000078af20be122d  push rax
000078af20be122e  push rcx
000078af20be122f  push rdx
000078af20be1230  push rdi
000078af20be1231  push rsi
000078af20be1232  push r8
000078af20be1234  push r9
000078af20be1236  push r10
000078af20be1238  push r11
000078af20be123a  sub rsp, 0xF0
000078af20be1241  vmovaps [rsp], xmm0
000078af20be1246  vmovaps [rsp+0x10], xmm1
000078af20be124c  vmovaps [rsp+0x20], xmm2
000078af20be1252  vmovaps [rsp+0x30], xmm3
000078af20be1258  vmovaps [rsp+0x40], xmm4
000078af20be125e  vmovaps [rsp+0x50], xmm5
000078af20be1264  vmovaps [rsp+0x60], xmm6
000078af20be126a  vmovaps [rsp+0x70], xmm7
000078af20be1270  vmovaps [rsp+0x80], xmm8
000078af20be1279  vmovaps [rsp+0x90], xmm9
000078af20be1282  vmovaps [rsp+0xA0], xmm10
000078af20be128b  vmovaps [rsp+0xB0], xmm11
000078af20be1294  vmovaps [rsp+0xC0], xmm12
000078af20be129d  vmovaps [rsp+0xD0], xmm13
000078af20be12a6  vmovaps [rsp+0xE0], xmm14
000078af20be12af  sub rsp, 0x30
000078af20be12b3  movaps [rsp], xmm15
000078af20be12b8  movaps [rsp+0x10], xmm5
000078af20be12bd  movaps [rsp+0x20], xmm3
000078af20be12c2  lea rdi, [rsp]
000078af20be12c6  mov esi, 0x00
000078af20be12cb  mov rax, 0x65452FFB8530
000078af20be12d5  call rax
000078af20be12d7  movaps xmm15, [rsp]
000078af20be12dc  add rsp, 0x30
000078af20be12e0  vmovaps xmm0, [rsp]
000078af20be12e5  vmovaps xmm1, [rsp+0x10]
000078af20be12eb  vmovaps xmm2, [rsp+0x20]
000078af20be12f1  vmovaps xmm3, [rsp+0x30]
000078af20be12f7  vmovaps xmm4, [rsp+0x40]
000078af20be12fd  vmovaps xmm5, [rsp+0x50]
000078af20be1303  vmovaps xmm6, [rsp+0x60]
000078af20be1309  vmovaps xmm7, [rsp+0x70]
000078af20be130f  vmovaps xmm8, [rsp+0x80]
000078af20be1318  vmovaps xmm9, [rsp+0x90]
000078af20be1321  vmovaps xmm10, [rsp+0xA0]
000078af20be132a  vmovaps xmm11, [rsp+0xB0]
000078af20be1333  vmovaps xmm12, [rsp+0xC0]
000078af20be133c  vmovaps xmm13, [rsp+0xD0]
000078af20be1345  vmovaps xmm14, [rsp+0xE0]
000078af20be134e  add rsp, 0xF0
000078af20be1355  pop r11
000078af20be1357  pop r10
000078af20be1359  pop r9
000078af20be135b  pop r8
000078af20be135d  pop rsi
000078af20be135e  pop rdi
000078af20be135f  pop rdx
000078af20be1360  pop rcx
000078af20be1361  pop rax
000078af20be1362  add rsp, 0x08
000078af20be1366  jmp 0x000078AF20BDF279
000078af20be136b  sub rsp, 0x08
000078af20be136f  push rax
000078af20be1370  push rcx
000078af20be1371  push rdx
000078af20be1372  push rdi
000078af20be1373  push rsi
000078af20be1374  push r8
000078af20be1376  push r9
000078af20be1378  push r10
000078af20be137a  push r11
000078af20be137c  sub rsp, 0xF0
000078af20be1383  vmovaps [rsp], xmm0
000078af20be1388  vmovaps [rsp+0x10], xmm2
000078af20be138e  vmovaps [rsp+0x20], xmm3
000078af20be1394  vmovaps [rsp+0x30], xmm4
000078af20be139a  vmovaps [rsp+0x40], xmm5
000078af20be13a0  vmovaps [rsp+0x50], xmm6
000078af20be13a6  vmovaps [rsp+0x60], xmm7
000078af20be13ac  vmovaps [rsp+0x70], xmm8
000078af20be13b2  vmovaps [rsp+0x80], xmm9
000078af20be13bb  vmovaps [rsp+0x90], xmm10
000078af20be13c4  vmovaps [rsp+0xA0], xmm11
000078af20be13cd  vmovaps [rsp+0xB0], xmm12
000078af20be13d6  vmovaps [rsp+0xC0], xmm13
000078af20be13df  vmovaps [rsp+0xD0], xmm14
000078af20be13e8  vmovaps [rsp+0xE0], xmm15
000078af20be13f1  sub rsp, 0x30
000078af20be13f5  movaps [rsp], xmm1
000078af20be13f9  movaps [rsp+0x10], xmm5
000078af20be13fe  movaps [rsp+0x20], xmm4
000078af20be1403  lea rdi, [rsp]
000078af20be1407  mov esi, 0x00
000078af20be140c  mov rax, 0x65452FFB8530
000078af20be1416  call rax
000078af20be1418  movaps xmm1, [rsp]
000078af20be141c  add rsp, 0x30
000078af20be1420  vmovaps xmm0, [rsp]
000078af20be1425  vmovaps xmm2, [rsp+0x10]
000078af20be142b  vmovaps xmm3, [rsp+0x20]
000078af20be1431  vmovaps xmm4, [rsp+0x30]
000078af20be1437  vmovaps xmm5, [rsp+0x40]
000078af20be143d  vmovaps xmm6, [rsp+0x50]
000078af20be1443  vmovaps xmm7, [rsp+0x60]
000078af20be1449  vmovaps xmm8, [rsp+0x70]
000078af20be144f  vmovaps xmm9, [rsp+0x80]
000078af20be1458  vmovaps xmm10, [rsp+0x90]
000078af20be1461  vmovaps xmm11, [rsp+0xA0]
000078af20be146a  vmovaps xmm12, [rsp+0xB0]
000078af20be1473  vmovaps xmm13, [rsp+0xC0]
000078af20be147c  vmovaps xmm14, [rsp+0xD0]
000078af20be1485  vmovaps xmm15, [rsp+0xE0]
000078af20be148e  add rsp, 0xF0
000078af20be1495  pop r11
000078af20be1497  pop r10
000078af20be1499  pop r9
000078af20be149b  pop r8
000078af20be149d  pop rsi
000078af20be149e  pop rdi
000078af20be149f  pop rdx
000078af20be14a0  pop rcx
000078af20be14a1  pop rax
000078af20be14a2  add rsp, 0x08
000078af20be14a6  jmp 0x000078AF20BDF299
000078af20be14ab  sub rsp, 0x08
000078af20be14af  push rax
000078af20be14b0  push rcx
000078af20be14b1  push rdx
000078af20be14b2  push rdi
000078af20be14b3  push rsi
000078af20be14b4  push r8
000078af20be14b6  push r9
000078af20be14b8  push r10
000078af20be14ba  push r11
000078af20be14bc  sub rsp, 0xF0
000078af20be14c3  vmovaps [rsp], xmm0
000078af20be14c8  vmovaps [rsp+0x10], xmm1
000078af20be14ce  vmovaps [rsp+0x20], xmm2
000078af20be14d4  vmovaps [rsp+0x30], xmm3
000078af20be14da  vmovaps [rsp+0x40], xmm5
000078af20be14e0  vmovaps [rsp+0x50], xmm6
000078af20be14e6  vmovaps [rsp+0x60], xmm7
000078af20be14ec  vmovaps [rsp+0x70], xmm8
000078af20be14f2  vmovaps [rsp+0x80], xmm9
000078af20be14fb  vmovaps [rsp+0x90], xmm10
000078af20be1504  vmovaps [rsp+0xA0], xmm11
000078af20be150d  vmovaps [rsp+0xB0], xmm12
000078af20be1516  vmovaps [rsp+0xC0], xmm13
000078af20be151f  vmovaps [rsp+0xD0], xmm14
000078af20be1528  vmovaps [rsp+0xE0], xmm15
000078af20be1531  sub rsp, 0x30
000078af20be1535  movaps [rsp], xmm4
000078af20be1539  movaps [rsp+0x10], xmm3
000078af20be153e  movaps [rsp+0x20], xmm5
000078af20be1543  lea rdi, [rsp]
000078af20be1547  mov esi, 0x00
000078af20be154c  mov rax, 0x65452FFB8530
000078af20be1556  call rax
000078af20be1558  movaps xmm4, [rsp]
000078af20be155c  add rsp, 0x30
000078af20be1560  vmovaps xmm0, [rsp]
000078af20be1565  vmovaps xmm1, [rsp+0x10]
000078af20be156b  vmovaps xmm2, [rsp+0x20]
000078af20be1571  vmovaps xmm3, [rsp+0x30]
000078af20be1577  vmovaps xmm5, [rsp+0x40]
000078af20be157d  vmovaps xmm6, [rsp+0x50]
000078af20be1583  vmovaps xmm7, [rsp+0x60]
000078af20be1589  vmovaps xmm8, [rsp+0x70]
000078af20be158f  vmovaps xmm9, [rsp+0x80]
000078af20be1598  vmovaps xmm10, [rsp+0x90]
000078af20be15a1  vmovaps xmm11, [rsp+0xA0]
000078af20be15aa  vmovaps xmm12, [rsp+0xB0]
000078af20be15b3  vmovaps xmm13, [rsp+0xC0]
000078af20be15bc  vmovaps xmm14, [rsp+0xD0]
000078af20be15c5  vmovaps xmm15, [rsp+0xE0]
000078af20be15ce  add rsp, 0xF0
000078af20be15d5  pop r11
000078af20be15d7  pop r10
000078af20be15d9  pop r9
000078af20be15db  pop r8
000078af20be15dd  pop rsi
000078af20be15de  pop rdi
000078af20be15df  pop rdx
000078af20be15e0  pop rcx
000078af20be15e1  pop rax
000078af20be15e2  add rsp, 0x08
000078af20be15e6  jmp 0x000078AF20BDF2E7
000078af20be15eb  call 0x000078AF20AB52F0
000078af20be15f0  jmp 0x000078AF20BDF2F4
000078af20be15f5  sub rsp, 0x08
000078af20be15f9  push rax
000078af20be15fa  push rcx
000078af20be15fb  push rdx
000078af20be15fc  push rdi
000078af20be15fd  push rsi
000078af20be15fe  push r8
000078af20be1600  push r9
000078af20be1602  push r10
000078af20be1604  push r11
000078af20be1606  sub rsp, 0xF0
000078af20be160d  vmovaps [rsp], xmm0
000078af20be1612  vmovaps [rsp+0x10], xmm1
000078af20be1618  vmovaps [rsp+0x20], xmm2
000078af20be161e  vmovaps [rsp+0x30], xmm3
000078af20be1624  vmovaps [rsp+0x40], xmm4
000078af20be162a  vmovaps [rsp+0x50], xmm6
000078af20be1630  vmovaps [rsp+0x60], xmm7
000078af20be1636  vmovaps [rsp+0x70], xmm8
000078af20be163c  vmovaps [rsp+0x80], xmm9
000078af20be1645  vmovaps [rsp+0x90], xmm10
000078af20be164e  vmovaps [rsp+0xA0], xmm11
000078af20be1657  vmovaps [rsp+0xB0], xmm12
000078af20be1660  vmovaps [rsp+0xC0], xmm13
000078af20be1669  vmovaps [rsp+0xD0], xmm14
000078af20be1672  vmovaps [rsp+0xE0], xmm15
000078af20be167b  sub rsp, 0x30
000078af20be167f  movaps [rsp], xmm5
000078af20be1683  movaps [rsp+0x10], xmm6
000078af20be1688  movaps [rsp+0x20], xmm3
000078af20be168d  lea rdi, [rsp]
000078af20be1691  mov esi, 0x00
000078af20be1696  mov rax, 0x65452FFB8530
000078af20be16a0  call rax
000078af20be16a2  movaps xmm5, [rsp]
000078af20be16a6  add rsp, 0x30
000078af20be16aa  vmovaps xmm0, [rsp]
000078af20be16af  vmovaps xmm1, [rsp+0x10]
000078af20be16b5  vmovaps xmm2, [rsp+0x20]
000078af20be16bb  vmovaps xmm3, [rsp+0x30]
000078af20be16c1  vmovaps xmm4, [rsp+0x40]
000078af20be16c7  vmovaps xmm6, [rsp+0x50]
000078af20be16cd  vmovaps xmm7, [rsp+0x60]
000078af20be16d3  vmovaps xmm8, [rsp+0x70]
000078af20be16d9  vmovaps xmm9, [rsp+0x80]
000078af20be16e2  vmovaps xmm10, [rsp+0x90]
000078af20be16eb  vmovaps xmm11, [rsp+0xA0]
000078af20be16f4  vmovaps xmm12, [rsp+0xB0]
000078af20be16fd  vmovaps xmm13, [rsp+0xC0]
000078af20be1706  vmovaps xmm14, [rsp+0xD0]
000078af20be170f  vmovaps xmm15, [rsp+0xE0]
000078af20be1718  add rsp, 0xF0
000078af20be171f  pop r11
000078af20be1721  pop r10
000078af20be1723  pop r9
000078af20be1725  pop r8
000078af20be1727  pop rsi
000078af20be1728  pop rdi
000078af20be1729  pop rdx
000078af20be172a  pop rcx
000078af20be172b  pop rax
000078af20be172c  add rsp, 0x08
000078af20be1730  jmp 0x000078AF20BDF31A
000078af20be1735  sub rsp, 0x08
000078af20be1739  push rax
000078af20be173a  push rcx
000078af20be173b  push rdx
000078af20be173c  push rdi
000078af20be173d  push rsi
000078af20be173e  push r8
000078af20be1740  push r9
000078af20be1742  push r10
000078af20be1744  push r11
000078af20be1746  sub rsp, 0xF0
000078af20be174d  vmovaps [rsp], xmm0
000078af20be1752  vmovaps [rsp+0x10], xmm1
000078af20be1758  vmovaps [rsp+0x20], xmm2
000078af20be175e  vmovaps [rsp+0x30], xmm3
000078af20be1764  vmovaps [rsp+0x40], xmm4
000078af20be176a  vmovaps [rsp+0x50], xmm5
000078af20be1770  vmovaps [rsp+0x60], xmm7
000078af20be1776  vmovaps [rsp+0x70], xmm8
000078af20be177c  vmovaps [rsp+0x80], xmm9
000078af20be1785  vmovaps [rsp+0x90], xmm10
000078af20be178e  vmovaps [rsp+0xA0], xmm11
000078af20be1797  vmovaps [rsp+0xB0], xmm12
000078af20be17a0  vmovaps [rsp+0xC0], xmm13
000078af20be17a9  vmovaps [rsp+0xD0], xmm14
000078af20be17b2  vmovaps [rsp+0xE0], xmm15
000078af20be17bb  sub rsp, 0x30
000078af20be17bf  movaps [rsp], xmm6
000078af20be17c3  movaps [rsp+0x10], xmm9
000078af20be17c9  movaps [rsp+0x20], xmm1
000078af20be17ce  lea rdi, [rsp]
000078af20be17d2  mov esi, 0x00
000078af20be17d7  mov rax, 0x65452FFB8530
000078af20be17e1  call rax
000078af20be17e3  movaps xmm6, [rsp]
000078af20be17e7  add rsp, 0x30
000078af20be17eb  vmovaps xmm0, [rsp]
000078af20be17f0  vmovaps xmm1, [rsp+0x10]
000078af20be17f6  vmovaps xmm2, [rsp+0x20]
000078af20be17fc  vmovaps xmm3, [rsp+0x30]
000078af20be1802  vmovaps xmm4, [rsp+0x40]
000078af20be1808  vmovaps xmm5, [rsp+0x50]
000078af20be180e  vmovaps xmm7, [rsp+0x60]
000078af20be1814  vmovaps xmm8, [rsp+0x70]
000078af20be181a  vmovaps xmm9, [rsp+0x80]
000078af20be1823  vmovaps xmm10, [rsp+0x90]
000078af20be182c  vmovaps xmm11, [rsp+0xA0]
000078af20be1835  vmovaps xmm12, [rsp+0xB0]
000078af20be183e  vmovaps xmm13, [rsp+0xC0]
000078af20be1847  vmovaps xmm14, [rsp+0xD0]
000078af20be1850  vmovaps xmm15, [rsp+0xE0]
000078af20be1859  add rsp, 0xF0
000078af20be1860  pop r11
000078af20be1862  pop r10
000078af20be1864  pop r9
000078af20be1866  pop r8
000078af20be1868  pop rsi
000078af20be1869  pop rdi
000078af20be186a  pop rdx
000078af20be186b  pop rcx
000078af20be186c  pop rax
000078af20be186d  add rsp, 0x08
000078af20be1871  jmp 0x000078AF20BDF33E
000078af20be1876  sub rsp, 0x08
000078af20be187a  push rax
000078af20be187b  push rcx
000078af20be187c  push rdx
000078af20be187d  push rdi
000078af20be187e  push rsi
000078af20be187f  push r8
000078af20be1881  push r9
000078af20be1883  push r10
000078af20be1885  push r11
000078af20be1887  sub rsp, 0xF0
000078af20be188e  vmovaps [rsp], xmm0
000078af20be1893  vmovaps [rsp+0x10], xmm1
000078af20be1899  vmovaps [rsp+0x20], xmm2
000078af20be189f  vmovaps [rsp+0x30], xmm3
000078af20be18a5  vmovaps [rsp+0x40], xmm4
000078af20be18ab  vmovaps [rsp+0x50], xmm5
000078af20be18b1  vmovaps [rsp+0x60], xmm6
000078af20be18b7  vmovaps [rsp+0x70], xmm7
000078af20be18bd  vmovaps [rsp+0x80], xmm8
000078af20be18c6  vmovaps [rsp+0x90], xmm10
000078af20be18cf  vmovaps [rsp+0xA0], xmm11
000078af20be18d8  vmovaps [rsp+0xB0], xmm12
000078af20be18e1  vmovaps [rsp+0xC0], xmm13
000078af20be18ea  vmovaps [rsp+0xD0], xmm14
000078af20be18f3  vmovaps [rsp+0xE0], xmm15
000078af20be18fc  sub rsp, 0x30
000078af20be1900  movaps [rsp], xmm9
000078af20be1905  movaps [rsp+0x10], xmm3
000078af20be190a  movaps [rsp+0x20], xmm1
000078af20be190f  lea rdi, [rsp]
000078af20be1913  mov esi, 0x00
000078af20be1918  mov rax, 0x65452FFB8530
000078af20be1922  call rax
000078af20be1924  movaps xmm9, [rsp]
000078af20be1929  add rsp, 0x30
000078af20be192d  vmovaps xmm0, [rsp]
000078af20be1932  vmovaps xmm1, [rsp+0x10]
000078af20be1938  vmovaps xmm2, [rsp+0x20]
000078af20be193e  vmovaps xmm3, [rsp+0x30]
000078af20be1944  vmovaps xmm4, [rsp+0x40]
000078af20be194a  vmovaps xmm5, [rsp+0x50]
000078af20be1950  vmovaps xmm6, [rsp+0x60]
000078af20be1956  vmovaps xmm7, [rsp+0x70]
000078af20be195c  vmovaps xmm8, [rsp+0x80]
000078af20be1965  vmovaps xmm10, [rsp+0x90]
000078af20be196e  vmovaps xmm11, [rsp+0xA0]
000078af20be1977  vmovaps xmm12, [rsp+0xB0]
000078af20be1980  vmovaps xmm13, [rsp+0xC0]
000078af20be1989  vmovaps xmm14, [rsp+0xD0]
000078af20be1992  vmovaps xmm15, [rsp+0xE0]
000078af20be199b  add rsp, 0xF0
000078af20be19a2  pop r11
000078af20be19a4  pop r10
000078af20be19a6  pop r9
000078af20be19a8  pop r8
000078af20be19aa  pop rsi
000078af20be19ab  pop rdi
000078af20be19ac  pop rdx
000078af20be19ad  pop rcx
000078af20be19ae  pop rax
000078af20be19af  add rsp, 0x08
000078af20be19b3  jmp 0x000078AF20BDF38A
000078af20be19b8  call 0x000078AF20AB52F0
000078af20be19bd  jmp 0x000078AF20BDF397
000078af20be19c2  sub rsp, 0x08
000078af20be19c6  push rax
000078af20be19c7  push rcx
000078af20be19c8  push rdx
000078af20be19c9  push rdi
000078af20be19ca  push rsi
000078af20be19cb  push r8
000078af20be19cd  push r9
000078af20be19cf  push r10
000078af20be19d1  push r11
000078af20be19d3  sub rsp, 0xF0
000078af20be19da  vmovaps [rsp], xmm0
000078af20be19df  vmovaps [rsp+0x10], xmm1
000078af20be19e5  vmovaps [rsp+0x20], xmm2
000078af20be19eb  vmovaps [rsp+0x30], xmm3
000078af20be19f1  vmovaps [rsp+0x40], xmm4
000078af20be19f7  vmovaps [rsp+0x50], xmm5
000078af20be19fd  vmovaps [rsp+0x60], xmm6
000078af20be1a03  vmovaps [rsp+0x70], xmm7
000078af20be1a09  vmovaps [rsp+0x80], xmm8
000078af20be1a12  vmovaps [rsp+0x90], xmm9
000078af20be1a1b  vmovaps [rsp+0xA0], xmm10
000078af20be1a24  vmovaps [rsp+0xB0], xmm11
000078af20be1a2d  vmovaps [rsp+0xC0], xmm12
000078af20be1a36  vmovaps [rsp+0xD0], xmm13
000078af20be1a3f  vmovaps [rsp+0xE0], xmm14
000078af20be1a48  sub rsp, 0x30
000078af20be1a4c  movaps [rsp], xmm15
000078af20be1a51  movaps [rsp+0x10], xmm3
000078af20be1a56  movaps [rsp+0x20], xmm7
000078af20be1a5b  lea rdi, [rsp]
000078af20be1a5f  mov esi, 0x00
000078af20be1a64  mov rax, 0x65452FFB8530
000078af20be1a6e  call rax
000078af20be1a70  movaps xmm15, [rsp]
000078af20be1a75  add rsp, 0x30
000078af20be1a79  vmovaps xmm0, [rsp]
000078af20be1a7e  vmovaps xmm1, [rsp+0x10]
000078af20be1a84  vmovaps xmm2, [rsp+0x20]
000078af20be1a8a  vmovaps xmm3, [rsp+0x30]
000078af20be1a90  vmovaps xmm4, [rsp+0x40]
000078af20be1a96  vmovaps xmm5, [rsp+0x50]
000078af20be1a9c  vmovaps xmm6, [rsp+0x60]
000078af20be1aa2  vmovaps xmm7, [rsp+0x70]
000078af20be1aa8  vmovaps xmm8, [rsp+0x80]
000078af20be1ab1  vmovaps xmm9, [rsp+0x90]
000078af20be1aba  vmovaps xmm10, [rsp+0xA0]
000078af20be1ac3  vmovaps xmm11, [rsp+0xB0]
000078af20be1acc  vmovaps xmm12, [rsp+0xC0]
000078af20be1ad5  vmovaps xmm13, [rsp+0xD0]
000078af20be1ade  vmovaps xmm14, [rsp+0xE0]
000078af20be1ae7  add rsp, 0xF0
000078af20be1aee  pop r11
000078af20be1af0  pop r10
000078af20be1af2  pop r9
000078af20be1af4  pop r8
000078af20be1af6  pop rsi
000078af20be1af7  pop rdi
000078af20be1af8  pop rdx
000078af20be1af9  pop rcx
000078af20be1afa  pop rax
000078af20be1afb  add rsp, 0x08
000078af20be1aff  jmp 0x000078AF20BDF3C3
000078af20be1b04  sub rsp, 0x08
000078af20be1b08  push rax
000078af20be1b09  push rcx
000078af20be1b0a  push rdx
000078af20be1b0b  push rdi
000078af20be1b0c  push rsi
000078af20be1b0d  push r8
000078af20be1b0f  push r9
000078af20be1b11  push r10
000078af20be1b13  push r11
000078af20be1b15  sub rsp, 0xF0
000078af20be1b1c  vmovaps [rsp], xmm0
000078af20be1b21  vmovaps [rsp+0x10], xmm1
000078af20be1b27  vmovaps [rsp+0x20], xmm2
000078af20be1b2d  vmovaps [rsp+0x30], xmm4
000078af20be1b33  vmovaps [rsp+0x40], xmm5
000078af20be1b39  vmovaps [rsp+0x50], xmm6
000078af20be1b3f  vmovaps [rsp+0x60], xmm7
000078af20be1b45  vmovaps [rsp+0x70], xmm8
000078af20be1b4b  vmovaps [rsp+0x80], xmm9
000078af20be1b54  vmovaps [rsp+0x90], xmm10
000078af20be1b5d  vmovaps [rsp+0xA0], xmm11
000078af20be1b66  vmovaps [rsp+0xB0], xmm12
000078af20be1b6f  vmovaps [rsp+0xC0], xmm13
000078af20be1b78  vmovaps [rsp+0xD0], xmm14
000078af20be1b81  vmovaps [rsp+0xE0], xmm15
000078af20be1b8a  sub rsp, 0x30
000078af20be1b8e  movaps [rsp], xmm3
000078af20be1b92  movaps [rsp+0x10], xmm1
000078af20be1b97  movaps [rsp+0x20], xmm15
000078af20be1b9d  lea rdi, [rsp]
000078af20be1ba1  mov esi, 0x00
000078af20be1ba6  mov rax, 0x65452FFB8530
000078af20be1bb0  call rax
000078af20be1bb2  movaps xmm3, [rsp]
000078af20be1bb6  add rsp, 0x30
000078af20be1bba  vmovaps xmm0, [rsp]
000078af20be1bbf  vmovaps xmm1, [rsp+0x10]
000078af20be1bc5  vmovaps xmm2, [rsp+0x20]
000078af20be1bcb  vmovaps xmm4, [rsp+0x30]
000078af20be1bd1  vmovaps xmm5, [rsp+0x40]
000078af20be1bd7  vmovaps xmm6, [rsp+0x50]
000078af20be1bdd  vmovaps xmm7, [rsp+0x60]
000078af20be1be3  vmovaps xmm8, [rsp+0x70]
000078af20be1be9  vmovaps xmm9, [rsp+0x80]
000078af20be1bf2  vmovaps xmm10, [rsp+0x90]
000078af20be1bfb  vmovaps xmm11, [rsp+0xA0]
000078af20be1c04  vmovaps xmm12, [rsp+0xB0]
000078af20be1c0d  vmovaps xmm13, [rsp+0xC0]
000078af20be1c16  vmovaps xmm14, [rsp+0xD0]
000078af20be1c1f  vmovaps xmm15, [rsp+0xE0]
000078af20be1c28  add rsp, 0xF0
000078af20be1c2f  pop r11
000078af20be1c31  pop r10
000078af20be1c33  pop r9
000078af20be1c35  pop r8
000078af20be1c37  pop rsi
000078af20be1c38  pop rdi
000078af20be1c39  pop rdx
000078af20be1c3a  pop rcx
000078af20be1c3b  pop rax
000078af20be1c3c  add rsp, 0x08
000078af20be1c40  jmp 0x000078AF20BDF452
000078af20be1c45  call 0x000078AF20AB52F0
000078af20be1c4a  jmp 0x000078AF20BDF45C
000078af20be1c4f  sub rsp, 0x08
000078af20be1c53  push rax
000078af20be1c54  push rcx
000078af20be1c55  push rdx
000078af20be1c56  push rdi
000078af20be1c57  push rsi
000078af20be1c58  push r8
000078af20be1c5a  push r9
000078af20be1c5c  push r10
000078af20be1c5e  push r11
000078af20be1c60  sub rsp, 0xF0
000078af20be1c67  vmovaps [rsp], xmm0
000078af20be1c6c  vmovaps [rsp+0x10], xmm1
000078af20be1c72  vmovaps [rsp+0x20], xmm2
000078af20be1c78  vmovaps [rsp+0x30], xmm3
000078af20be1c7e  vmovaps [rsp+0x40], xmm4
000078af20be1c84  vmovaps [rsp+0x50], xmm5
000078af20be1c8a  vmovaps [rsp+0x60], xmm6
000078af20be1c90  vmovaps [rsp+0x70], xmm7
000078af20be1c96  vmovaps [rsp+0x80], xmm8
000078af20be1c9f  vmovaps [rsp+0x90], xmm9
000078af20be1ca8  vmovaps [rsp+0xA0], xmm10
000078af20be1cb1  vmovaps [rsp+0xB0], xmm11
000078af20be1cba  vmovaps [rsp+0xC0], xmm12
000078af20be1cc3  vmovaps [rsp+0xD0], xmm13
000078af20be1ccc  vmovaps [rsp+0xE0], xmm14
000078af20be1cd5  sub rsp, 0x30
000078af20be1cd9  movaps [rsp], xmm15
000078af20be1cde  movaps [rsp+0x10], xmm14
000078af20be1ce4  movaps [rsp+0x20], xmm4
000078af20be1ce9  lea rdi, [rsp]
000078af20be1ced  mov esi, 0x00
000078af20be1cf2  mov rax, 0x65452FFB8530
000078af20be1cfc  call rax
000078af20be1cfe  movaps xmm15, [rsp]
000078af20be1d03  add rsp, 0x30
000078af20be1d07  vmovaps xmm0, [rsp]
000078af20be1d0c  vmovaps xmm1, [rsp+0x10]
000078af20be1d12  vmovaps xmm2, [rsp+0x20]
000078af20be1d18  vmovaps xmm3, [rsp+0x30]
000078af20be1d1e  vmovaps xmm4, [rsp+0x40]
000078af20be1d24  vmovaps xmm5, [rsp+0x50]
000078af20be1d2a  vmovaps xmm6, [rsp+0x60]
000078af20be1d30  vmovaps xmm7, [rsp+0x70]
000078af20be1d36  vmovaps xmm8, [rsp+0x80]
000078af20be1d3f  vmovaps xmm9, [rsp+0x90]
000078af20be1d48  vmovaps xmm10, [rsp+0xA0]
000078af20be1d51  vmovaps xmm11, [rsp+0xB0]
000078af20be1d5a  vmovaps xmm12, [rsp+0xC0]
000078af20be1d63  vmovaps xmm13, [rsp+0xD0]
000078af20be1d6c  vmovaps xmm14, [rsp+0xE0]
000078af20be1d75  add rsp, 0xF0
000078af20be1d7c  pop r11
000078af20be1d7e  pop r10
000078af20be1d80  pop r9
000078af20be1d82  pop r8
000078af20be1d84  pop rsi
000078af20be1d85  pop rdi
000078af20be1d86  pop rdx
000078af20be1d87  pop rcx
000078af20be1d88  pop rax
000078af20be1d89  add rsp, 0x08
000078af20be1d8d  jmp 0x000078AF20BDF48A
000078af20be1d92  sub rsp, 0x08
000078af20be1d96  push rax
000078af20be1d97  push rcx
000078af20be1d98  push rdx
000078af20be1d99  push rdi
000078af20be1d9a  push rsi
000078af20be1d9b  push r8
000078af20be1d9d  push r9
000078af20be1d9f  push r10
000078af20be1da1  push r11
000078af20be1da3  sub rsp, 0xF0
000078af20be1daa  vmovaps [rsp], xmm0
000078af20be1daf  vmovaps [rsp+0x10], xmm1
000078af20be1db5  vmovaps [rsp+0x20], xmm2
000078af20be1dbb  vmovaps [rsp+0x30], xmm3
000078af20be1dc1  vmovaps [rsp+0x40], xmm4
000078af20be1dc7  vmovaps [rsp+0x50], xmm5
000078af20be1dcd  vmovaps [rsp+0x60], xmm6
000078af20be1dd3  vmovaps [rsp+0x70], xmm7
000078af20be1dd9  vmovaps [rsp+0x80], xmm8
000078af20be1de2  vmovaps [rsp+0x90], xmm9
000078af20be1deb  vmovaps [rsp+0xA0], xmm10
000078af20be1df4  vmovaps [rsp+0xB0], xmm11
000078af20be1dfd  vmovaps [rsp+0xC0], xmm12
000078af20be1e06  vmovaps [rsp+0xD0], xmm13
000078af20be1e0f  vmovaps [rsp+0xE0], xmm15
000078af20be1e18  sub rsp, 0x30
000078af20be1e1c  movaps [rsp], xmm14
000078af20be1e21  movaps [rsp+0x10], xmm2
000078af20be1e26  movaps [rsp+0x20], xmm1
000078af20be1e2b  lea rdi, [rsp]
000078af20be1e2f  mov esi, 0x00
000078af20be1e34  mov rax, 0x65452FFB8530
000078af20be1e3e  call rax
000078af20be1e40  movaps xmm14, [rsp]
000078af20be1e45  add rsp, 0x30
000078af20be1e49  vmovaps xmm0, [rsp]
000078af20be1e4e  vmovaps xmm1, [rsp+0x10]
000078af20be1e54  vmovaps xmm2, [rsp+0x20]
000078af20be1e5a  vmovaps xmm3, [rsp+0x30]
000078af20be1e60  vmovaps xmm4, [rsp+0x40]
000078af20be1e66  vmovaps xmm5, [rsp+0x50]
000078af20be1e6c  vmovaps xmm6, [rsp+0x60]
000078af20be1e72  vmovaps xmm7, [rsp+0x70]
000078af20be1e78  vmovaps xmm8, [rsp+0x80]
000078af20be1e81  vmovaps xmm9, [rsp+0x90]
000078af20be1e8a  vmovaps xmm10, [rsp+0xA0]
000078af20be1e93  vmovaps xmm11, [rsp+0xB0]
000078af20be1e9c  vmovaps xmm12, [rsp+0xC0]
000078af20be1ea5  vmovaps xmm13, [rsp+0xD0]
000078af20be1eae  vmovaps xmm15, [rsp+0xE0]
000078af20be1eb7  add rsp, 0xF0
000078af20be1ebe  pop r11
000078af20be1ec0  pop r10
000078af20be1ec2  pop r9
000078af20be1ec4  pop r8
000078af20be1ec6  pop rsi
000078af20be1ec7  pop rdi
000078af20be1ec8  pop rdx
000078af20be1ec9  pop rcx
000078af20be1eca  pop rax
000078af20be1ecb  add rsp, 0x08
000078af20be1ecf  jmp 0x000078AF20BDF4B0
000078af20be1ed4  sub rsp, 0x08
000078af20be1ed8  push rax
000078af20be1ed9  push rcx
000078af20be1eda  push rdx
000078af20be1edb  push rdi
000078af20be1edc  push rsi
000078af20be1edd  push r8
000078af20be1edf  push r9
000078af20be1ee1  push r10
000078af20be1ee3  push r11
000078af20be1ee5  sub rsp, 0xF0
000078af20be1eec  vmovaps [rsp], xmm0
000078af20be1ef1  vmovaps [rsp+0x10], xmm2
000078af20be1ef7  vmovaps [rsp+0x20], xmm3
000078af20be1efd  vmovaps [rsp+0x30], xmm4
000078af20be1f03  vmovaps [rsp+0x40], xmm5
000078af20be1f09  vmovaps [rsp+0x50], xmm6
000078af20be1f0f  vmovaps [rsp+0x60], xmm7
000078af20be1f15  vmovaps [rsp+0x70], xmm8
000078af20be1f1b  vmovaps [rsp+0x80], xmm9
000078af20be1f24  vmovaps [rsp+0x90], xmm10
000078af20be1f2d  vmovaps [rsp+0xA0], xmm11
000078af20be1f36  vmovaps [rsp+0xB0], xmm12
000078af20be1f3f  vmovaps [rsp+0xC0], xmm13
000078af20be1f48  vmovaps [rsp+0xD0], xmm14
000078af20be1f51  vmovaps [rsp+0xE0], xmm15
000078af20be1f5a  sub rsp, 0x30
000078af20be1f5e  movaps [rsp], xmm1
000078af20be1f62  movaps [rsp+0x10], xmm4
000078af20be1f67  movaps [rsp+0x20], xmm9
000078af20be1f6d  lea rdi, [rsp]
000078af20be1f71  mov esi, 0x00
000078af20be1f76  mov rax, 0x65452FFB8530
000078af20be1f80  call rax
000078af20be1f82  movaps xmm1, [rsp]
000078af20be1f86  add rsp, 0x30
000078af20be1f8a  vmovaps xmm0, [rsp]
000078af20be1f8f  vmovaps xmm2, [rsp+0x10]
000078af20be1f95  vmovaps xmm3, [rsp+0x20]
000078af20be1f9b  vmovaps xmm4, [rsp+0x30]
000078af20be1fa1  vmovaps xmm5, [rsp+0x40]
000078af20be1fa7  vmovaps xmm6, [rsp+0x50]
000078af20be1fad  vmovaps xmm7, [rsp+0x60]
000078af20be1fb3  vmovaps xmm8, [rsp+0x70]
000078af20be1fb9  vmovaps xmm9, [rsp+0x80]
000078af20be1fc2  vmovaps xmm10, [rsp+0x90]
000078af20be1fcb  vmovaps xmm11, [rsp+0xA0]
000078af20be1fd4  vmovaps xmm12, [rsp+0xB0]
000078af20be1fdd  vmovaps xmm13, [rsp+0xC0]
000078af20be1fe6  vmovaps xmm14, [rsp+0xD0]
000078af20be1fef  vmovaps xmm15, [rsp+0xE0]
000078af20be1ff8  add rsp, 0xF0
000078af20be1fff  pop r11
000078af20be2001  pop r10
000078af20be2003  pop r9
000078af20be2005  pop r8
000078af20be2007  pop rsi
000078af20be2008  pop rdi
000078af20be2009  pop rdx
000078af20be200a  pop rcx
000078af20be200b  pop rax
000078af20be200c  add rsp, 0x08
000078af20be2010  jmp 0x000078AF20BDF4CE
000078af20be2015  sub rsp, 0x08
000078af20be2019  push rax
000078af20be201a  push rcx
000078af20be201b  push rdx
000078af20be201c  push rdi
000078af20be201d  push rsi
000078af20be201e  push r8
000078af20be2020  push r9
000078af20be2022  push r10
000078af20be2024  push r11
000078af20be2026  sub rsp, 0xF0
000078af20be202d  vmovaps [rsp], xmm0
000078af20be2032  vmovaps [rsp+0x10], xmm1
000078af20be2038  vmovaps [rsp+0x20], xmm2
000078af20be203e  vmovaps [rsp+0x30], xmm3
000078af20be2044  vmovaps [rsp+0x40], xmm5
000078af20be204a  vmovaps [rsp+0x50], xmm6
000078af20be2050  vmovaps [rsp+0x60], xmm7
000078af20be2056  vmovaps [rsp+0x70], xmm8
000078af20be205c  vmovaps [rsp+0x80], xmm9
000078af20be2065  vmovaps [rsp+0x90], xmm10
000078af20be206e  vmovaps [rsp+0xA0], xmm11
000078af20be2077  vmovaps [rsp+0xB0], xmm12
000078af20be2080  vmovaps [rsp+0xC0], xmm13
000078af20be2089  vmovaps [rsp+0xD0], xmm14
000078af20be2092  vmovaps [rsp+0xE0], xmm15
000078af20be209b  sub rsp, 0x30
000078af20be209f  movaps [rsp], xmm4
000078af20be20a3  movaps [rsp+0x10], xmm2
000078af20be20a8  movaps [rsp+0x20], xmm9
000078af20be20ae  lea rdi, [rsp]
000078af20be20b2  mov esi, 0x00
000078af20be20b7  mov rax, 0x65452FFB8530
000078af20be20c1  call rax
000078af20be20c3  movaps xmm4, [rsp]
000078af20be20c7  add rsp, 0x30
000078af20be20cb  vmovaps xmm0, [rsp]
000078af20be20d0  vmovaps xmm1, [rsp+0x10]
000078af20be20d6  vmovaps xmm2, [rsp+0x20]
000078af20be20dc  vmovaps xmm3, [rsp+0x30]
000078af20be20e2  vmovaps xmm5, [rsp+0x40]
000078af20be20e8  vmovaps xmm6, [rsp+0x50]
000078af20be20ee  vmovaps xmm7, [rsp+0x60]
000078af20be20f4  vmovaps xmm8, [rsp+0x70]
000078af20be20fa  vmovaps xmm9, [rsp+0x80]
000078af20be2103  vmovaps xmm10, [rsp+0x90]
000078af20be210c  vmovaps xmm11, [rsp+0xA0]
000078af20be2115  vmovaps xmm12, [rsp+0xB0]
000078af20be211e  vmovaps xmm13, [rsp+0xC0]
000078af20be2127  vmovaps xmm14, [rsp+0xD0]
000078af20be2130  vmovaps xmm15, [rsp+0xE0]
000078af20be2139  add rsp, 0xF0
000078af20be2140  pop r11
000078af20be2142  pop r10
000078af20be2144  pop r9
000078af20be2146  pop r8
000078af20be2148  pop rsi
000078af20be2149  pop rdi
000078af20be214a  pop rdx
000078af20be214b  pop rcx
000078af20be214c  pop rax
000078af20be214d  add rsp, 0x08
000078af20be2151  jmp 0x000078AF20BDF4FE
000078af20be2156  sub rsp, 0x08
000078af20be215a  push rax
000078af20be215b  push rcx
000078af20be215c  push rdx
000078af20be215d  push rdi
000078af20be215e  push rsi
000078af20be215f  push r8
000078af20be2161  push r9
000078af20be2163  push r10
000078af20be2165  push r11
000078af20be2167  sub rsp, 0xF0
000078af20be216e  vmovaps [rsp], xmm0
000078af20be2173  vmovaps [rsp+0x10], xmm1
000078af20be2179  vmovaps [rsp+0x20], xmm2
000078af20be217f  vmovaps [rsp+0x30], xmm3
000078af20be2185  vmovaps [rsp+0x40], xmm4
000078af20be218b  vmovaps [rsp+0x50], xmm5
000078af20be2191  vmovaps [rsp+0x60], xmm6
000078af20be2197  vmovaps [rsp+0x70], xmm7
000078af20be219d  vmovaps [rsp+0x80], xmm8
000078af20be21a6  vmovaps [rsp+0x90], xmm10
000078af20be21af  vmovaps [rsp+0xA0], xmm11
000078af20be21b8  vmovaps [rsp+0xB0], xmm12
000078af20be21c1  vmovaps [rsp+0xC0], xmm13
000078af20be21ca  vmovaps [rsp+0xD0], xmm14
000078af20be21d3  vmovaps [rsp+0xE0], xmm15
000078af20be21dc  sub rsp, 0x30
000078af20be21e0  movaps [rsp], xmm9
000078af20be21e5  movaps [rsp+0x10], xmm2
000078af20be21ea  movaps [rsp+0x20], xmm1
000078af20be21ef  lea rdi, [rsp]
000078af20be21f3  mov esi, 0x00
000078af20be21f8  mov rax, 0x65452FFB8530
000078af20be2202  call rax
000078af20be2204  movaps xmm9, [rsp]
000078af20be2209  add rsp, 0x30
000078af20be220d  vmovaps xmm0, [rsp]
000078af20be2212  vmovaps xmm1, [rsp+0x10]
000078af20be2218  vmovaps xmm2, [rsp+0x20]
000078af20be221e  vmovaps xmm3, [rsp+0x30]
000078af20be2224  vmovaps xmm4, [rsp+0x40]
000078af20be222a  vmovaps xmm5, [rsp+0x50]
000078af20be2230  vmovaps xmm6, [rsp+0x60]
000078af20be2236  vmovaps xmm7, [rsp+0x70]
000078af20be223c  vmovaps xmm8, [rsp+0x80]
000078af20be2245  vmovaps xmm10, [rsp+0x90]
000078af20be224e  vmovaps xmm11, [rsp+0xA0]
000078af20be2257  vmovaps xmm12, [rsp+0xB0]
000078af20be2260  vmovaps xmm13, [rsp+0xC0]
000078af20be2269  vmovaps xmm14, [rsp+0xD0]
000078af20be2272  vmovaps xmm15, [rsp+0xE0]
000078af20be227b  add rsp, 0xF0
000078af20be2282  pop r11
000078af20be2284  pop r10
000078af20be2286  pop r9
000078af20be2288  pop r8
000078af20be228a  pop rsi
000078af20be228b  pop rdi
000078af20be228c  pop rdx
000078af20be228d  pop rcx
000078af20be228e  pop rax
000078af20be228f  add rsp, 0x08
000078af20be2293  jmp 0x000078AF20BDF534
000078af20be2298  sub rsp, 0x08
000078af20be229c  push rax
000078af20be229d  push rcx
000078af20be229e  push rdx
000078af20be229f  push rdi
000078af20be22a0  push rsi
000078af20be22a1  push r8
000078af20be22a3  push r9
000078af20be22a5  push r10
000078af20be22a7  push r11
000078af20be22a9  sub rsp, 0xF0
000078af20be22b0  vmovaps [rsp], xmm0
000078af20be22b5  vmovaps [rsp+0x10], xmm2
000078af20be22bb  vmovaps [rsp+0x20], xmm3
000078af20be22c1  vmovaps [rsp+0x30], xmm4
000078af20be22c7  vmovaps [rsp+0x40], xmm5
000078af20be22cd  vmovaps [rsp+0x50], xmm6
000078af20be22d3  vmovaps [rsp+0x60], xmm7
000078af20be22d9  vmovaps [rsp+0x70], xmm8
000078af20be22df  vmovaps [rsp+0x80], xmm9
000078af20be22e8  vmovaps [rsp+0x90], xmm10
000078af20be22f1  vmovaps [rsp+0xA0], xmm11
000078af20be22fa  vmovaps [rsp+0xB0], xmm12
000078af20be2303  vmovaps [rsp+0xC0], xmm13
000078af20be230c  vmovaps [rsp+0xD0], xmm14
000078af20be2315  vmovaps [rsp+0xE0], xmm15
000078af20be231e  sub rsp, 0x30
000078af20be2322  movaps [rsp], xmm1
000078af20be2326  movaps [rsp+0x10], xmm15
000078af20be232c  movaps [rsp+0x20], xmm6
000078af20be2331  lea rdi, [rsp]
000078af20be2335  mov esi, 0x00
000078af20be233a  mov rax, 0x65452FFB8530
000078af20be2344  call rax
000078af20be2346  movaps xmm1, [rsp]
000078af20be234a  add rsp, 0x30
000078af20be234e  vmovaps xmm0, [rsp]
000078af20be2353  vmovaps xmm2, [rsp+0x10]
000078af20be2359  vmovaps xmm3, [rsp+0x20]
000078af20be235f  vmovaps xmm4, [rsp+0x30]
000078af20be2365  vmovaps xmm5, [rsp+0x40]
000078af20be236b  vmovaps xmm6, [rsp+0x50]
000078af20be2371  vmovaps xmm7, [rsp+0x60]
000078af20be2377  vmovaps xmm8, [rsp+0x70]
000078af20be237d  vmovaps xmm9, [rsp+0x80]
000078af20be2386  vmovaps xmm10, [rsp+0x90]
000078af20be238f  vmovaps xmm11, [rsp+0xA0]
000078af20be2398  vmovaps xmm12, [rsp+0xB0]
000078af20be23a1  vmovaps xmm13, [rsp+0xC0]
000078af20be23aa  vmovaps xmm14, [rsp+0xD0]
000078af20be23b3  vmovaps xmm15, [rsp+0xE0]
000078af20be23bc  add rsp, 0xF0
000078af20be23c3  pop r11
000078af20be23c5  pop r10
000078af20be23c7  pop r9
000078af20be23c9  pop r8
000078af20be23cb  pop rsi
000078af20be23cc  pop rdi
000078af20be23cd  pop rdx
000078af20be23ce  pop rcx
000078af20be23cf  pop rax
000078af20be23d0  add rsp, 0x08
000078af20be23d4  jmp 0x000078AF20BDF555
000078af20be23d9  sub rsp, 0x08
000078af20be23dd  push rax
000078af20be23de  push rcx
000078af20be23df  push rdx
000078af20be23e0  push rdi
000078af20be23e1  push rsi
000078af20be23e2  push r8
000078af20be23e4  push r9
000078af20be23e6  push r10
000078af20be23e8  push r11
000078af20be23ea  sub rsp, 0xF0
000078af20be23f1  vmovaps [rsp], xmm0
000078af20be23f6  vmovaps [rsp+0x10], xmm1
000078af20be23fc  vmovaps [rsp+0x20], xmm2
000078af20be2402  vmovaps [rsp+0x30], xmm3
000078af20be2408  vmovaps [rsp+0x40], xmm4
000078af20be240e  vmovaps [rsp+0x50], xmm5
000078af20be2414  vmovaps [rsp+0x60], xmm6
000078af20be241a  vmovaps [rsp+0x70], xmm7
000078af20be2420  vmovaps [rsp+0x80], xmm8
000078af20be2429  vmovaps [rsp+0x90], xmm9
000078af20be2432  vmovaps [rsp+0xA0], xmm10
000078af20be243b  vmovaps [rsp+0xB0], xmm11
000078af20be2444  vmovaps [rsp+0xC0], xmm12
000078af20be244d  vmovaps [rsp+0xD0], xmm13
000078af20be2456  vmovaps [rsp+0xE0], xmm14
000078af20be245f  sub rsp, 0x30
000078af20be2463  movaps [rsp], xmm15
000078af20be2468  movaps [rsp+0x10], xmm5
000078af20be246d  movaps [rsp+0x20], xmm3
000078af20be2472  lea rdi, [rsp]
000078af20be2476  mov esi, 0x00
000078af20be247b  mov rax, 0x65452FFB8530
000078af20be2485  call rax
000078af20be2487  movaps xmm15, [rsp]
000078af20be248c  add rsp, 0x30
000078af20be2490  vmovaps xmm0, [rsp]
000078af20be2495  vmovaps xmm1, [rsp+0x10]
000078af20be249b  vmovaps xmm2, [rsp+0x20]
000078af20be24a1  vmovaps xmm3, [rsp+0x30]
000078af20be24a7  vmovaps xmm4, [rsp+0x40]
000078af20be24ad  vmovaps xmm5, [rsp+0x50]
000078af20be24b3  vmovaps xmm6, [rsp+0x60]
000078af20be24b9  vmovaps xmm7, [rsp+0x70]
000078af20be24bf  vmovaps xmm8, [rsp+0x80]
000078af20be24c8  vmovaps xmm9, [rsp+0x90]
000078af20be24d1  vmovaps xmm10, [rsp+0xA0]
000078af20be24da  vmovaps xmm11, [rsp+0xB0]
000078af20be24e3  vmovaps xmm12, [rsp+0xC0]
000078af20be24ec  vmovaps xmm13, [rsp+0xD0]
000078af20be24f5  vmovaps xmm14, [rsp+0xE0]
000078af20be24fe  add rsp, 0xF0
000078af20be2505  pop r11
000078af20be2507  pop r10
000078af20be2509  pop r9
000078af20be250b  pop r8
000078af20be250d  pop rsi
000078af20be250e  pop rdi
000078af20be250f  pop rdx
000078af20be2510  pop rcx
000078af20be2511  pop rax
000078af20be2512  add rsp, 0x08
000078af20be2516  jmp 0x000078AF20BDF56F
000078af20be251b  sub rsp, 0x08
000078af20be251f  push rax
000078af20be2520  push rcx
000078af20be2521  push rdx
000078af20be2522  push rdi
000078af20be2523  push rsi
000078af20be2524  push r8
000078af20be2526  push r9
000078af20be2528  push r10
000078af20be252a  push r11
000078af20be252c  sub rsp, 0xF0
000078af20be2533  vmovaps [rsp], xmm0
000078af20be2538  vmovaps [rsp+0x10], xmm1
000078af20be253e  vmovaps [rsp+0x20], xmm2
000078af20be2544  vmovaps [rsp+0x30], xmm3
000078af20be254a  vmovaps [rsp+0x40], xmm4
000078af20be2550  vmovaps [rsp+0x50], xmm6
000078af20be2556  vmovaps [rsp+0x60], xmm7
000078af20be255c  vmovaps [rsp+0x70], xmm8
000078af20be2562  vmovaps [rsp+0x80], xmm9
000078af20be256b  vmovaps [rsp+0x90], xmm10
000078af20be2574  vmovaps [rsp+0xA0], xmm11
000078af20be257d  vmovaps [rsp+0xB0], xmm12
000078af20be2586  vmovaps [rsp+0xC0], xmm13
000078af20be258f  vmovaps [rsp+0xD0], xmm14
000078af20be2598  vmovaps [rsp+0xE0], xmm15
000078af20be25a1  sub rsp, 0x30
000078af20be25a5  movaps [rsp], xmm5
000078af20be25a9  movaps [rsp+0x10], xmm8
000078af20be25af  movaps [rsp+0x20], xmm6
000078af20be25b4  lea rdi, [rsp]
000078af20be25b8  mov esi, 0x00
000078af20be25bd  mov rax, 0x65452FFB8530
000078af20be25c7  call rax
000078af20be25c9  movaps xmm5, [rsp]
000078af20be25cd  add rsp, 0x30
000078af20be25d1  vmovaps xmm0, [rsp]
000078af20be25d6  vmovaps xmm1, [rsp+0x10]
000078af20be25dc  vmovaps xmm2, [rsp+0x20]
000078af20be25e2  vmovaps xmm3, [rsp+0x30]
000078af20be25e8  vmovaps xmm4, [rsp+0x40]
000078af20be25ee  vmovaps xmm6, [rsp+0x50]
000078af20be25f4  vmovaps xmm7, [rsp+0x60]
000078af20be25fa  vmovaps xmm8, [rsp+0x70]
000078af20be2600  vmovaps xmm9, [rsp+0x80]
000078af20be2609  vmovaps xmm10, [rsp+0x90]
000078af20be2612  vmovaps xmm11, [rsp+0xA0]
000078af20be261b  vmovaps xmm12, [rsp+0xB0]
000078af20be2624  vmovaps xmm13, [rsp+0xC0]
000078af20be262d  vmovaps xmm14, [rsp+0xD0]
000078af20be2636  vmovaps xmm15, [rsp+0xE0]
000078af20be263f  add rsp, 0xF0
000078af20be2646  pop r11
000078af20be2648  pop r10
000078af20be264a  pop r9
000078af20be264c  pop r8
000078af20be264e  pop rsi
000078af20be264f  pop rdi
000078af20be2650  pop rdx
000078af20be2651  pop rcx
000078af20be2652  pop rax
000078af20be2653  add rsp, 0x08
000078af20be2657  jmp 0x000078AF20BDF593
000078af20be265c  sub rsp, 0x08
000078af20be2660  push rax
000078af20be2661  push rcx
000078af20be2662  push rdx
000078af20be2663  push rdi
000078af20be2664  push rsi
000078af20be2665  push r8
000078af20be2667  push r9
000078af20be2669  push r10
000078af20be266b  push r11
000078af20be266d  sub rsp, 0xF0
000078af20be2674  vmovaps [rsp], xmm0
000078af20be2679  vmovaps [rsp+0x10], xmm1
000078af20be267f  vmovaps [rsp+0x20], xmm2
000078af20be2685  vmovaps [rsp+0x30], xmm3
000078af20be268b  vmovaps [rsp+0x40], xmm4
000078af20be2691  vmovaps [rsp+0x50], xmm5
000078af20be2697  vmovaps [rsp+0x60], xmm7
000078af20be269d  vmovaps [rsp+0x70], xmm8
000078af20be26a3  vmovaps [rsp+0x80], xmm9
000078af20be26ac  vmovaps [rsp+0x90], xmm10
000078af20be26b5  vmovaps [rsp+0xA0], xmm11
000078af20be26be  vmovaps [rsp+0xB0], xmm12
000078af20be26c7  vmovaps [rsp+0xC0], xmm13
000078af20be26d0  vmovaps [rsp+0xD0], xmm14
000078af20be26d9  vmovaps [rsp+0xE0], xmm15
000078af20be26e2  sub rsp, 0x30
000078af20be26e6  movaps [rsp], xmm6
000078af20be26ea  movaps [rsp+0x10], xmm10
000078af20be26f0  movaps [rsp+0x20], xmm8
000078af20be26f6  lea rdi, [rsp]
000078af20be26fa  mov esi, 0x00
000078af20be26ff  mov rax, 0x65452FFB8530
000078af20be2709  call rax
000078af20be270b  movaps xmm6, [rsp]
000078af20be270f  add rsp, 0x30
000078af20be2713  vmovaps xmm0, [rsp]
000078af20be2718  vmovaps xmm1, [rsp+0x10]
000078af20be271e  vmovaps xmm2, [rsp+0x20]
000078af20be2724  vmovaps xmm3, [rsp+0x30]
000078af20be272a  vmovaps xmm4, [rsp+0x40]
000078af20be2730  vmovaps xmm5, [rsp+0x50]
000078af20be2736  vmovaps xmm7, [rsp+0x60]
000078af20be273c  vmovaps xmm8, [rsp+0x70]
000078af20be2742  vmovaps xmm9, [rsp+0x80]
000078af20be274b  vmovaps xmm10, [rsp+0x90]
000078af20be2754  vmovaps xmm11, [rsp+0xA0]
000078af20be275d  vmovaps xmm12, [rsp+0xB0]
000078af20be2766  vmovaps xmm13, [rsp+0xC0]
000078af20be276f  vmovaps xmm14, [rsp+0xD0]
000078af20be2778  vmovaps xmm15, [rsp+0xE0]
000078af20be2781  add rsp, 0xF0
000078af20be2788  pop r11
000078af20be278a  pop r10
000078af20be278c  pop r9
000078af20be278e  pop r8
000078af20be2790  pop rsi
000078af20be2791  pop rdi
000078af20be2792  pop rdx
000078af20be2793  pop rcx
000078af20be2794  pop rax
000078af20be2795  add rsp, 0x08
000078af20be2799  jmp 0x000078AF20BDF5B8
000078af20be279e  sub rsp, 0x08
000078af20be27a2  push rax
000078af20be27a3  push rcx
000078af20be27a4  push rdx
000078af20be27a5  push rdi
000078af20be27a6  push rsi
000078af20be27a7  push r8
000078af20be27a9  push r9
000078af20be27ab  push r10
000078af20be27ad  push r11
000078af20be27af  sub rsp, 0xF0
000078af20be27b6  vmovaps [rsp], xmm0
000078af20be27bb  vmovaps [rsp+0x10], xmm1
000078af20be27c1  vmovaps [rsp+0x20], xmm2
000078af20be27c7  vmovaps [rsp+0x30], xmm3
000078af20be27cd  vmovaps [rsp+0x40], xmm4
000078af20be27d3  vmovaps [rsp+0x50], xmm5
000078af20be27d9  vmovaps [rsp+0x60], xmm6
000078af20be27df  vmovaps [rsp+0x70], xmm7
000078af20be27e5  vmovaps [rsp+0x80], xmm8
000078af20be27ee  vmovaps [rsp+0x90], xmm9
000078af20be27f7  vmovaps [rsp+0xA0], xmm11
000078af20be2800  vmovaps [rsp+0xB0], xmm12
000078af20be2809  vmovaps [rsp+0xC0], xmm13
000078af20be2812  vmovaps [rsp+0xD0], xmm14
000078af20be281b  vmovaps [rsp+0xE0], xmm15
000078af20be2824  sub rsp, 0x30
000078af20be2828  movaps [rsp], xmm10
000078af20be282d  movaps [rsp+0x10], xmm8
000078af20be2833  movaps [rsp+0x20], xmm14
000078af20be2839  lea rdi, [rsp]
000078af20be283d  mov esi, 0x00
000078af20be2842  mov rax, 0x65452FFB8530
000078af20be284c  call rax
000078af20be284e  movaps xmm10, [rsp]
000078af20be2853  add rsp, 0x30
000078af20be2857  vmovaps xmm0, [rsp]
000078af20be285c  vmovaps xmm1, [rsp+0x10]
000078af20be2862  vmovaps xmm2, [rsp+0x20]
000078af20be2868  vmovaps xmm3, [rsp+0x30]
000078af20be286e  vmovaps xmm4, [rsp+0x40]
000078af20be2874  vmovaps xmm5, [rsp+0x50]
000078af20be287a  vmovaps xmm6, [rsp+0x60]
000078af20be2880  vmovaps xmm7, [rsp+0x70]
000078af20be2886  vmovaps xmm8, [rsp+0x80]
000078af20be288f  vmovaps xmm9, [rsp+0x90]
000078af20be2898  vmovaps xmm11, [rsp+0xA0]
000078af20be28a1  vmovaps xmm12, [rsp+0xB0]
000078af20be28aa  vmovaps xmm13, [rsp+0xC0]
000078af20be28b3  vmovaps xmm14, [rsp+0xD0]
000078af20be28bc  vmovaps xmm15, [rsp+0xE0]
000078af20be28c5  add rsp, 0xF0
000078af20be28cc  pop r11
000078af20be28ce  pop r10
000078af20be28d0  pop r9
000078af20be28d2  pop r8
000078af20be28d4  pop rsi
000078af20be28d5  pop rdi
000078af20be28d6  pop rdx
000078af20be28d7  pop rcx
000078af20be28d8  pop rax
000078af20be28d9  add rsp, 0x08
000078af20be28dd  jmp 0x000078AF20BDF5D8
000078af20be28e2  sub rsp, 0x08
000078af20be28e6  push rax
000078af20be28e7  push rcx
000078af20be28e8  push rdx
000078af20be28e9  push rdi
000078af20be28ea  push rsi
000078af20be28eb  push r8
000078af20be28ed  push r9
000078af20be28ef  push r10
000078af20be28f1  push r11
000078af20be28f3  sub rsp, 0xF0
000078af20be28fa  vmovaps [rsp], xmm0
000078af20be28ff  vmovaps [rsp+0x10], xmm1
000078af20be2905  vmovaps [rsp+0x20], xmm2
000078af20be290b  vmovaps [rsp+0x30], xmm3
000078af20be2911  vmovaps [rsp+0x40], xmm4
000078af20be2917  vmovaps [rsp+0x50], xmm5
000078af20be291d  vmovaps [rsp+0x60], xmm6
000078af20be2923  vmovaps [rsp+0x70], xmm7
000078af20be2929  vmovaps [rsp+0x80], xmm8
000078af20be2932  vmovaps [rsp+0x90], xmm9
000078af20be293b  vmovaps [rsp+0xA0], xmm10
000078af20be2944  vmovaps [rsp+0xB0], xmm11
000078af20be294d  vmovaps [rsp+0xC0], xmm12
000078af20be2956  vmovaps [rsp+0xD0], xmm13
000078af20be295f  vmovaps [rsp+0xE0], xmm15
000078af20be2968  sub rsp, 0x30
000078af20be296c  movaps [rsp], xmm14
000078af20be2971  movaps [rsp+0x10], xmm8
000078af20be2977  movaps [rsp+0x20], xmm4
000078af20be297c  lea rdi, [rsp]
000078af20be2980  mov esi, 0x00
000078af20be2985  mov rax, 0x65452FFB8530
000078af20be298f  call rax
000078af20be2991  movaps xmm14, [rsp]
000078af20be2996  add rsp, 0x30
000078af20be299a  vmovaps xmm0, [rsp]
000078af20be299f  vmovaps xmm1, [rsp+0x10]
000078af20be29a5  vmovaps xmm2, [rsp+0x20]
000078af20be29ab  vmovaps xmm3, [rsp+0x30]
000078af20be29b1  vmovaps xmm4, [rsp+0x40]
000078af20be29b7  vmovaps xmm5, [rsp+0x50]
000078af20be29bd  vmovaps xmm6, [rsp+0x60]
000078af20be29c3  vmovaps xmm7, [rsp+0x70]
000078af20be29c9  vmovaps xmm8, [rsp+0x80]
000078af20be29d2  vmovaps xmm9, [rsp+0x90]
000078af20be29db  vmovaps xmm10, [rsp+0xA0]
000078af20be29e4  vmovaps xmm11, [rsp+0xB0]
000078af20be29ed  vmovaps xmm12, [rsp+0xC0]
000078af20be29f6  vmovaps xmm13, [rsp+0xD0]
000078af20be29ff  vmovaps xmm15, [rsp+0xE0]
000078af20be2a08  add rsp, 0xF0
000078af20be2a0f  pop r11
000078af20be2a11  pop r10
000078af20be2a13  pop r9
000078af20be2a15  pop r8
000078af20be2a17  pop rsi
000078af20be2a18  pop rdi
000078af20be2a19  pop rdx
000078af20be2a1a  pop rcx
000078af20be2a1b  pop rax
000078af20be2a1c  add rsp, 0x08
000078af20be2a20  jmp 0x000078AF20BDF5F8
000078af20be2a25  sub rsp, 0x08
000078af20be2a29  push rax
000078af20be2a2a  push rcx
000078af20be2a2b  push rdx
000078af20be2a2c  push rdi
000078af20be2a2d  push rsi
000078af20be2a2e  push r8
000078af20be2a30  push r9
000078af20be2a32  push r10
000078af20be2a34  push r11
000078af20be2a36  sub rsp, 0xF0
000078af20be2a3d  vmovaps [rsp], xmm0
000078af20be2a42  vmovaps [rsp+0x10], xmm1
000078af20be2a48  vmovaps [rsp+0x20], xmm2
000078af20be2a4e  vmovaps [rsp+0x30], xmm3
000078af20be2a54  vmovaps [rsp+0x40], xmm5
000078af20be2a5a  vmovaps [rsp+0x50], xmm6
000078af20be2a60  vmovaps [rsp+0x60], xmm7
000078af20be2a66  vmovaps [rsp+0x70], xmm8
000078af20be2a6c  vmovaps [rsp+0x80], xmm9
000078af20be2a75  vmovaps [rsp+0x90], xmm10
000078af20be2a7e  vmovaps [rsp+0xA0], xmm11
000078af20be2a87  vmovaps [rsp+0xB0], xmm12
000078af20be2a90  vmovaps [rsp+0xC0], xmm13
000078af20be2a99  vmovaps [rsp+0xD0], xmm14
000078af20be2aa2  vmovaps [rsp+0xE0], xmm15
000078af20be2aab  sub rsp, 0x30
000078af20be2aaf  movaps [rsp], xmm4
000078af20be2ab3  movaps [rsp+0x10], xmm13
000078af20be2ab9  movaps [rsp+0x20], xmm8
000078af20be2abf  lea rdi, [rsp]
000078af20be2ac3  mov esi, 0x00
000078af20be2ac8  mov rax, 0x65452FFB8530
000078af20be2ad2  call rax
000078af20be2ad4  movaps xmm4, [rsp]
000078af20be2ad8  add rsp, 0x30
000078af20be2adc  vmovaps xmm0, [rsp]
000078af20be2ae1  vmovaps xmm1, [rsp+0x10]
000078af20be2ae7  vmovaps xmm2, [rsp+0x20]
000078af20be2aed  vmovaps xmm3, [rsp+0x30]
000078af20be2af3  vmovaps xmm5, [rsp+0x40]
000078af20be2af9  vmovaps xmm6, [rsp+0x50]
000078af20be2aff  vmovaps xmm7, [rsp+0x60]
000078af20be2b05  vmovaps xmm8, [rsp+0x70]
000078af20be2b0b  vmovaps xmm9, [rsp+0x80]
000078af20be2b14  vmovaps xmm10, [rsp+0x90]
000078af20be2b1d  vmovaps xmm11, [rsp+0xA0]
000078af20be2b26  vmovaps xmm12, [rsp+0xB0]
000078af20be2b2f  vmovaps xmm13, [rsp+0xC0]
000078af20be2b38  vmovaps xmm14, [rsp+0xD0]
000078af20be2b41  vmovaps xmm15, [rsp+0xE0]
000078af20be2b4a  add rsp, 0xF0
000078af20be2b51  pop r11
000078af20be2b53  pop r10
000078af20be2b55  pop r9
000078af20be2b57  pop r8
000078af20be2b59  pop rsi
000078af20be2b5a  pop rdi
000078af20be2b5b  pop rdx
000078af20be2b5c  pop rcx
000078af20be2b5d  pop rax
000078af20be2b5e  add rsp, 0x08
000078af20be2b62  jmp 0x000078AF20BDF61D
000078af20be2b67  sub rsp, 0x08
000078af20be2b6b  push rax
000078af20be2b6c  push rcx
000078af20be2b6d  push rdx
000078af20be2b6e  push rdi
000078af20be2b6f  push rsi
000078af20be2b70  push r8
000078af20be2b72  push r9
000078af20be2b74  push r10
000078af20be2b76  push r11
000078af20be2b78  sub rsp, 0xF0
000078af20be2b7f  vmovaps [rsp], xmm0
000078af20be2b84  vmovaps [rsp+0x10], xmm1
000078af20be2b8a  vmovaps [rsp+0x20], xmm2
000078af20be2b90  vmovaps [rsp+0x30], xmm3
000078af20be2b96  vmovaps [rsp+0x40], xmm4
000078af20be2b9c  vmovaps [rsp+0x50], xmm5
000078af20be2ba2  vmovaps [rsp+0x60], xmm6
000078af20be2ba8  vmovaps [rsp+0x70], xmm7
000078af20be2bae  vmovaps [rsp+0x80], xmm8
000078af20be2bb7  vmovaps [rsp+0x90], xmm9
000078af20be2bc0  vmovaps [rsp+0xA0], xmm10
000078af20be2bc9  vmovaps [rsp+0xB0], xmm11
000078af20be2bd2  vmovaps [rsp+0xC0], xmm12
000078af20be2bdb  vmovaps [rsp+0xD0], xmm14
000078af20be2be4  vmovaps [rsp+0xE0], xmm15
000078af20be2bed  sub rsp, 0x30
000078af20be2bf1  movaps [rsp], xmm13
000078af20be2bf6  movaps [rsp+0x10], xmm15
000078af20be2bfc  movaps [rsp+0x20], xmm9
000078af20be2c02  lea rdi, [rsp]
000078af20be2c06  mov esi, 0x00
000078af20be2c0b  mov rax, 0x65452FFB8530
000078af20be2c15  call rax
000078af20be2c17  movaps xmm13, [rsp]
000078af20be2c1c  add rsp, 0x30
000078af20be2c20  vmovaps xmm0, [rsp]
000078af20be2c25  vmovaps xmm1, [rsp+0x10]
000078af20be2c2b  vmovaps xmm2, [rsp+0x20]
000078af20be2c31  vmovaps xmm3, [rsp+0x30]
000078af20be2c37  vmovaps xmm4, [rsp+0x40]
000078af20be2c3d  vmovaps xmm5, [rsp+0x50]
000078af20be2c43  vmovaps xmm6, [rsp+0x60]
000078af20be2c49  vmovaps xmm7, [rsp+0x70]
000078af20be2c4f  vmovaps xmm8, [rsp+0x80]
000078af20be2c58  vmovaps xmm9, [rsp+0x90]
000078af20be2c61  vmovaps xmm10, [rsp+0xA0]
000078af20be2c6a  vmovaps xmm11, [rsp+0xB0]
000078af20be2c73  vmovaps xmm12, [rsp+0xC0]
000078af20be2c7c  vmovaps xmm14, [rsp+0xD0]
000078af20be2c85  vmovaps xmm15, [rsp+0xE0]
000078af20be2c8e  add rsp, 0xF0
000078af20be2c95  pop r11
000078af20be2c97  pop r10
000078af20be2c99  pop r9
000078af20be2c9b  pop r8
000078af20be2c9d  pop rsi
000078af20be2c9e  pop rdi
000078af20be2c9f  pop rdx
000078af20be2ca0  pop rcx
000078af20be2ca1  pop rax
000078af20be2ca2  add rsp, 0x08
000078af20be2ca6  jmp 0x000078AF20BDF638
000078af20be2cab  sub rsp, 0x08
000078af20be2caf  push rax
000078af20be2cb0  push rcx
000078af20be2cb1  push rdx
000078af20be2cb2  push rdi
000078af20be2cb3  push rsi
000078af20be2cb4  push r8
000078af20be2cb6  push r9
000078af20be2cb8  push r10
000078af20be2cba  push r11
000078af20be2cbc  sub rsp, 0xF0
000078af20be2cc3  vmovaps [rsp], xmm0
000078af20be2cc8  vmovaps [rsp+0x10], xmm1
000078af20be2cce  vmovaps [rsp+0x20], xmm2
000078af20be2cd4  vmovaps [rsp+0x30], xmm3
000078af20be2cda  vmovaps [rsp+0x40], xmm4
000078af20be2ce0  vmovaps [rsp+0x50], xmm5
000078af20be2ce6  vmovaps [rsp+0x60], xmm6
000078af20be2cec  vmovaps [rsp+0x70], xmm7
000078af20be2cf2  vmovaps [rsp+0x80], xmm8
000078af20be2cfb  vmovaps [rsp+0x90], xmm9
000078af20be2d04  vmovaps [rsp+0xA0], xmm10
000078af20be2d0d  vmovaps [rsp+0xB0], xmm11
000078af20be2d16  vmovaps [rsp+0xC0], xmm12
000078af20be2d1f  vmovaps [rsp+0xD0], xmm13
000078af20be2d28  vmovaps [rsp+0xE0], xmm14
000078af20be2d31  sub rsp, 0x30
000078af20be2d35  movaps [rsp], xmm15
000078af20be2d3a  movaps [rsp+0x10], xmm1
000078af20be2d3f  movaps [rsp+0x20], xmm5
000078af20be2d44  lea rdi, [rsp]
000078af20be2d48  mov esi, 0x00
000078af20be2d4d  mov rax, 0x65452FFB8530
000078af20be2d57  call rax
000078af20be2d59  movaps xmm15, [rsp]
000078af20be2d5e  add rsp, 0x30
000078af20be2d62  vmovaps xmm0, [rsp]
000078af20be2d67  vmovaps xmm1, [rsp+0x10]
000078af20be2d6d  vmovaps xmm2, [rsp+0x20]
000078af20be2d73  vmovaps xmm3, [rsp+0x30]
000078af20be2d79  vmovaps xmm4, [rsp+0x40]
000078af20be2d7f  vmovaps xmm5, [rsp+0x50]
000078af20be2d85  vmovaps xmm6, [rsp+0x60]
000078af20be2d8b  vmovaps xmm7, [rsp+0x70]
000078af20be2d91  vmovaps xmm8, [rsp+0x80]
000078af20be2d9a  vmovaps xmm9, [rsp+0x90]
000078af20be2da3  vmovaps xmm10, [rsp+0xA0]
000078af20be2dac  vmovaps xmm11, [rsp+0xB0]
000078af20be2db5  vmovaps xmm12, [rsp+0xC0]
000078af20be2dbe  vmovaps xmm13, [rsp+0xD0]
000078af20be2dc7  vmovaps xmm14, [rsp+0xE0]
000078af20be2dd0  add rsp, 0xF0
000078af20be2dd7  pop r11
000078af20be2dd9  pop r10
000078af20be2ddb  pop r9
000078af20be2ddd  pop r8
000078af20be2ddf  pop rsi
000078af20be2de0  pop rdi
000078af20be2de1  pop rdx
000078af20be2de2  pop rcx
000078af20be2de3  pop rax
000078af20be2de4  add rsp, 0x08
000078af20be2de8  jmp 0x000078AF20BDF653
000078af20be2ded  call 0x000078AF20AB52F0
000078af20be2df2  jmp 0x000078AF20BDF6AE
000078af20be2df7  sub rsp, 0x08
000078af20be2dfb  push rax
000078af20be2dfc  push rcx
000078af20be2dfd  push rdx
000078af20be2dfe  push rdi
000078af20be2dff  push rsi
000078af20be2e00  push r8
000078af20be2e02  push r9
000078af20be2e04  push r10
000078af20be2e06  push r11
000078af20be2e08  sub rsp, 0xF0
000078af20be2e0f  vmovaps [rsp], xmm0
000078af20be2e14  vmovaps [rsp+0x10], xmm1
000078af20be2e1a  vmovaps [rsp+0x20], xmm2
000078af20be2e20  vmovaps [rsp+0x30], xmm3
000078af20be2e26  vmovaps [rsp+0x40], xmm4
000078af20be2e2c  vmovaps [rsp+0x50], xmm5
000078af20be2e32  vmovaps [rsp+0x60], xmm6
000078af20be2e38  vmovaps [rsp+0x70], xmm7
000078af20be2e3e  vmovaps [rsp+0x80], xmm8
000078af20be2e47  vmovaps [rsp+0x90], xmm10
000078af20be2e50  vmovaps [rsp+0xA0], xmm11
000078af20be2e59  vmovaps [rsp+0xB0], xmm12
000078af20be2e62  vmovaps [rsp+0xC0], xmm13
000078af20be2e6b  vmovaps [rsp+0xD0], xmm14
000078af20be2e74  vmovaps [rsp+0xE0], xmm15
000078af20be2e7d  sub rsp, 0x30
000078af20be2e81  movaps [rsp], xmm9
000078af20be2e86  movaps [rsp+0x10], xmm8
000078af20be2e8c  movaps [rsp+0x20], xmm11
000078af20be2e92  lea rdi, [rsp]
000078af20be2e96  mov esi, 0x00
000078af20be2e9b  mov rax, 0x65452FFB8530
000078af20be2ea5  call rax
000078af20be2ea7  movaps xmm9, [rsp]
000078af20be2eac  add rsp, 0x30
000078af20be2eb0  vmovaps xmm0, [rsp]
000078af20be2eb5  vmovaps xmm1, [rsp+0x10]
000078af20be2ebb  vmovaps xmm2, [rsp+0x20]
000078af20be2ec1  vmovaps xmm3, [rsp+0x30]
000078af20be2ec7  vmovaps xmm4, [rsp+0x40]
000078af20be2ecd  vmovaps xmm5, [rsp+0x50]
000078af20be2ed3  vmovaps xmm6, [rsp+0x60]
000078af20be2ed9  vmovaps xmm7, [rsp+0x70]
000078af20be2edf  vmovaps xmm8, [rsp+0x80]
000078af20be2ee8  vmovaps xmm10, [rsp+0x90]
000078af20be2ef1  vmovaps xmm11, [rsp+0xA0]
000078af20be2efa  vmovaps xmm12, [rsp+0xB0]
000078af20be2f03  vmovaps xmm13, [rsp+0xC0]
000078af20be2f0c  vmovaps xmm14, [rsp+0xD0]
000078af20be2f15  vmovaps xmm15, [rsp+0xE0]
000078af20be2f1e  add rsp, 0xF0
000078af20be2f25  pop r11
000078af20be2f27  pop r10
000078af20be2f29  pop r9
000078af20be2f2b  pop r8
000078af20be2f2d  pop rsi
000078af20be2f2e  pop rdi
000078af20be2f2f  pop rdx
000078af20be2f30  pop rcx
000078af20be2f31  pop rax
000078af20be2f32  add rsp, 0x08
000078af20be2f36  jmp 0x000078AF20BDF6E5
000078af20be2f3b  sub rsp, 0x08
000078af20be2f3f  push rax
000078af20be2f40  push rcx
000078af20be2f41  push rdx
000078af20be2f42  push rdi
000078af20be2f43  push rsi
000078af20be2f44  push r8
000078af20be2f46  push r9
000078af20be2f48  push r10
000078af20be2f4a  push r11
000078af20be2f4c  sub rsp, 0xF0
000078af20be2f53  vmovaps [rsp], xmm0
000078af20be2f58  vmovaps [rsp+0x10], xmm1
000078af20be2f5e  vmovaps [rsp+0x20], xmm2
000078af20be2f64  vmovaps [rsp+0x30], xmm3
000078af20be2f6a  vmovaps [rsp+0x40], xmm4
000078af20be2f70  vmovaps [rsp+0x50], xmm5
000078af20be2f76  vmovaps [rsp+0x60], xmm6
000078af20be2f7c  vmovaps [rsp+0x70], xmm7
000078af20be2f82  vmovaps [rsp+0x80], xmm8
000078af20be2f8b  vmovaps [rsp+0x90], xmm9
000078af20be2f94  vmovaps [rsp+0xA0], xmm10
000078af20be2f9d  vmovaps [rsp+0xB0], xmm12
000078af20be2fa6  vmovaps [rsp+0xC0], xmm13
000078af20be2faf  vmovaps [rsp+0xD0], xmm14
000078af20be2fb8  vmovaps [rsp+0xE0], xmm15
000078af20be2fc1  sub rsp, 0x30
000078af20be2fc5  movaps [rsp], xmm11
000078af20be2fca  movaps [rsp+0x10], xmm10
000078af20be2fd0  movaps [rsp+0x20], xmm6
000078af20be2fd5  lea rdi, [rsp]
000078af20be2fd9  mov esi, 0x00
000078af20be2fde  mov rax, 0x65452FFB8530
000078af20be2fe8  call rax
000078af20be2fea  movaps xmm11, [rsp]
000078af20be2fef  add rsp, 0x30
000078af20be2ff3  vmovaps xmm0, [rsp]
000078af20be2ff8  vmovaps xmm1, [rsp+0x10]
000078af20be2ffe  vmovaps xmm2, [rsp+0x20]
000078af20be3004  vmovaps xmm3, [rsp+0x30]
000078af20be300a  vmovaps xmm4, [rsp+0x40]
000078af20be3010  vmovaps xmm5, [rsp+0x50]
000078af20be3016  vmovaps xmm6, [rsp+0x60]
000078af20be301c  vmovaps xmm7, [rsp+0x70]
000078af20be3022  vmovaps xmm8, [rsp+0x80]
000078af20be302b  vmovaps xmm9, [rsp+0x90]
000078af20be3034  vmovaps xmm10, [rsp+0xA0]
000078af20be303d  vmovaps xmm12, [rsp+0xB0]
000078af20be3046  vmovaps xmm13, [rsp+0xC0]
000078af20be304f  vmovaps xmm14, [rsp+0xD0]
000078af20be3058  vmovaps xmm15, [rsp+0xE0]
000078af20be3061  add rsp, 0xF0
000078af20be3068  pop r11
000078af20be306a  pop r10
000078af20be306c  pop r9
000078af20be306e  pop r8
000078af20be3070  pop rsi
000078af20be3071  pop rdi
000078af20be3072  pop rdx
000078af20be3073  pop rcx
000078af20be3074  pop rax
000078af20be3075  add rsp, 0x08
000078af20be3079  jmp 0x000078AF20BDF700
000078af20be307e  sub rsp, 0x08
000078af20be3082  push rax
000078af20be3083  push rcx
000078af20be3084  push rdx
000078af20be3085  push rdi
000078af20be3086  push rsi
000078af20be3087  push r8
000078af20be3089  push r9
000078af20be308b  push r10
000078af20be308d  push r11
000078af20be308f  sub rsp, 0xF0
000078af20be3096  vmovaps [rsp], xmm0
000078af20be309b  vmovaps [rsp+0x10], xmm1
000078af20be30a1  vmovaps [rsp+0x20], xmm2
000078af20be30a7  vmovaps [rsp+0x30], xmm3
000078af20be30ad  vmovaps [rsp+0x40], xmm4
000078af20be30b3  vmovaps [rsp+0x50], xmm5
000078af20be30b9  vmovaps [rsp+0x60], xmm6
000078af20be30bf  vmovaps [rsp+0x70], xmm7
000078af20be30c5  vmovaps [rsp+0x80], xmm8
000078af20be30ce  vmovaps [rsp+0x90], xmm9
000078af20be30d7  vmovaps [rsp+0xA0], xmm11
000078af20be30e0  vmovaps [rsp+0xB0], xmm12
000078af20be30e9  vmovaps [rsp+0xC0], xmm13
000078af20be30f2  vmovaps [rsp+0xD0], xmm14
000078af20be30fb  vmovaps [rsp+0xE0], xmm15
000078af20be3104  sub rsp, 0x30
000078af20be3108  movaps [rsp], xmm10
000078af20be310d  movaps [rsp+0x10], xmm14
000078af20be3113  movaps [rsp+0x20], xmm4
000078af20be3118  lea rdi, [rsp]
000078af20be311c  mov esi, 0x00
000078af20be3121  mov rax, 0x65452FFB8530
000078af20be312b  call rax
000078af20be312d  movaps xmm10, [rsp]
000078af20be3132  add rsp, 0x30
000078af20be3136  vmovaps xmm0, [rsp]
000078af20be313b  vmovaps xmm1, [rsp+0x10]
000078af20be3141  vmovaps xmm2, [rsp+0x20]
000078af20be3147  vmovaps xmm3, [rsp+0x30]
000078af20be314d  vmovaps xmm4, [rsp+0x40]
000078af20be3153  vmovaps xmm5, [rsp+0x50]
000078af20be3159  vmovaps xmm6, [rsp+0x60]
000078af20be315f  vmovaps xmm7, [rsp+0x70]
000078af20be3165  vmovaps xmm8, [rsp+0x80]
000078af20be316e  vmovaps xmm9, [rsp+0x90]
000078af20be3177  vmovaps xmm11, [rsp+0xA0]
000078af20be3180  vmovaps xmm12, [rsp+0xB0]
000078af20be3189  vmovaps xmm13, [rsp+0xC0]
000078af20be3192  vmovaps xmm14, [rsp+0xD0]
000078af20be319b  vmovaps xmm15, [rsp+0xE0]
000078af20be31a4  add rsp, 0xF0
000078af20be31ab  pop r11
000078af20be31ad  pop r10
000078af20be31af  pop r9
000078af20be31b1  pop r8
000078af20be31b3  pop rsi
000078af20be31b4  pop rdi
000078af20be31b5  pop rdx
000078af20be31b6  pop rcx
000078af20be31b7  pop rax
000078af20be31b8  add rsp, 0x08
000078af20be31bc  jmp 0x000078AF20BDF71B
000078af20be31c1  sub rsp, 0x08
000078af20be31c5  push rax
000078af20be31c6  push rcx
000078af20be31c7  push rdx
000078af20be31c8  push rdi
000078af20be31c9  push rsi
000078af20be31ca  push r8
000078af20be31cc  push r9
000078af20be31ce  push r10
000078af20be31d0  push r11
000078af20be31d2  sub rsp, 0xF0
000078af20be31d9  vmovaps [rsp], xmm0
000078af20be31de  vmovaps [rsp+0x10], xmm1
000078af20be31e4  vmovaps [rsp+0x20], xmm2
000078af20be31ea  vmovaps [rsp+0x30], xmm3
000078af20be31f0  vmovaps [rsp+0x40], xmm4
000078af20be31f6  vmovaps [rsp+0x50], xmm5
000078af20be31fc  vmovaps [rsp+0x60], xmm6
000078af20be3202  vmovaps [rsp+0x70], xmm7
000078af20be3208  vmovaps [rsp+0x80], xmm9
000078af20be3211  vmovaps [rsp+0x90], xmm10
000078af20be321a  vmovaps [rsp+0xA0], xmm11
000078af20be3223  vmovaps [rsp+0xB0], xmm12
000078af20be322c  vmovaps [rsp+0xC0], xmm13
000078af20be3235  vmovaps [rsp+0xD0], xmm14
000078af20be323e  vmovaps [rsp+0xE0], xmm15
000078af20be3247  sub rsp, 0x30
000078af20be324b  movaps [rsp], xmm8
000078af20be3250  movaps [rsp+0x10], xmm1
000078af20be3255  movaps [rsp+0x20], xmm14
000078af20be325b  lea rdi, [rsp]
000078af20be325f  mov esi, 0x00
000078af20be3264  mov rax, 0x65452FFB8530
000078af20be326e  call rax
000078af20be3270  movaps xmm8, [rsp]
000078af20be3275  add rsp, 0x30
000078af20be3279  vmovaps xmm0, [rsp]
000078af20be327e  vmovaps xmm1, [rsp+0x10]
000078af20be3284  vmovaps xmm2, [rsp+0x20]
000078af20be328a  vmovaps xmm3, [rsp+0x30]
000078af20be3290  vmovaps xmm4, [rsp+0x40]
000078af20be3296  vmovaps xmm5, [rsp+0x50]
000078af20be329c  vmovaps xmm6, [rsp+0x60]
000078af20be32a2  vmovaps xmm7, [rsp+0x70]
000078af20be32a8  vmovaps xmm9, [rsp+0x80]
000078af20be32b1  vmovaps xmm10, [rsp+0x90]
000078af20be32ba  vmovaps xmm11, [rsp+0xA0]
000078af20be32c3  vmovaps xmm12, [rsp+0xB0]
000078af20be32cc  vmovaps xmm13, [rsp+0xC0]
000078af20be32d5  vmovaps xmm14, [rsp+0xD0]
000078af20be32de  vmovaps xmm15, [rsp+0xE0]
000078af20be32e7  add rsp, 0xF0
000078af20be32ee  pop r11
000078af20be32f0  pop r10
000078af20be32f2  pop r9
000078af20be32f4  pop r8
000078af20be32f6  pop rsi
000078af20be32f7  pop rdi
000078af20be32f8  pop rdx
000078af20be32f9  pop rcx
000078af20be32fa  pop rax
000078af20be32fb  add rsp, 0x08
000078af20be32ff  jmp 0x000078AF20BDF741
000078af20be3304  sub rsp, 0x08
000078af20be3308  push rax
000078af20be3309  push rcx
000078af20be330a  push rdx
000078af20be330b  push rdi
000078af20be330c  push rsi
000078af20be330d  push r8
000078af20be330f  push r9
000078af20be3311  push r10
000078af20be3313  push r11
000078af20be3315  sub rsp, 0xF0
000078af20be331c  vmovaps [rsp], xmm0
000078af20be3321  vmovaps [rsp+0x10], xmm1
000078af20be3327  vmovaps [rsp+0x20], xmm2
000078af20be332d  vmovaps [rsp+0x30], xmm3
000078af20be3333  vmovaps [rsp+0x40], xmm4
000078af20be3339  vmovaps [rsp+0x50], xmm5
000078af20be333f  vmovaps [rsp+0x60], xmm7
000078af20be3345  vmovaps [rsp+0x70], xmm8
000078af20be334b  vmovaps [rsp+0x80], xmm9
000078af20be3354  vmovaps [rsp+0x90], xmm10
000078af20be335d  vmovaps [rsp+0xA0], xmm11
000078af20be3366  vmovaps [rsp+0xB0], xmm12
000078af20be336f  vmovaps [rsp+0xC0], xmm13
000078af20be3378  vmovaps [rsp+0xD0], xmm14
000078af20be3381  vmovaps [rsp+0xE0], xmm15
000078af20be338a  sub rsp, 0x30
000078af20be338e  movaps [rsp], xmm6
000078af20be3392  movaps [rsp+0x10], xmm1
000078af20be3397  movaps [rsp+0x20], xmm14
000078af20be339d  lea rdi, [rsp]
000078af20be33a1  mov esi, 0x00
000078af20be33a6  mov rax, 0x65452FFB8530
000078af20be33b0  call rax
000078af20be33b2  movaps xmm6, [rsp]
000078af20be33b6  add rsp, 0x30
000078af20be33ba  vmovaps xmm0, [rsp]
000078af20be33bf  vmovaps xmm1, [rsp+0x10]
000078af20be33c5  vmovaps xmm2, [rsp+0x20]
000078af20be33cb  vmovaps xmm3, [rsp+0x30]
000078af20be33d1  vmovaps xmm4, [rsp+0x40]
000078af20be33d7  vmovaps xmm5, [rsp+0x50]
000078af20be33dd  vmovaps xmm7, [rsp+0x60]
000078af20be33e3  vmovaps xmm8, [rsp+0x70]
000078af20be33e9  vmovaps xmm9, [rsp+0x80]
000078af20be33f2  vmovaps xmm10, [rsp+0x90]
000078af20be33fb  vmovaps xmm11, [rsp+0xA0]
000078af20be3404  vmovaps xmm12, [rsp+0xB0]
000078af20be340d  vmovaps xmm13, [rsp+0xC0]
000078af20be3416  vmovaps xmm14, [rsp+0xD0]
000078af20be341f  vmovaps xmm15, [rsp+0xE0]
000078af20be3428  add rsp, 0xF0
000078af20be342f  pop r11
000078af20be3431  pop r10
000078af20be3433  pop r9
000078af20be3435  pop r8
000078af20be3437  pop rsi
000078af20be3438  pop rdi
000078af20be3439  pop rdx
000078af20be343a  pop rcx
000078af20be343b  pop rax
000078af20be343c  add rsp, 0x08
000078af20be3440  jmp 0x000078AF20BDF76D
000078af20be3445  sub rsp, 0x08
000078af20be3449  push rax
000078af20be344a  push rcx
000078af20be344b  push rdx
000078af20be344c  push rdi
000078af20be344d  push rsi
000078af20be344e  push r8
000078af20be3450  push r9
000078af20be3452  push r10
000078af20be3454  push r11
000078af20be3456  sub rsp, 0xF0
000078af20be345d  vmovaps [rsp], xmm0
000078af20be3462  vmovaps [rsp+0x10], xmm1
000078af20be3468  vmovaps [rsp+0x20], xmm2
000078af20be346e  vmovaps [rsp+0x30], xmm3
000078af20be3474  vmovaps [rsp+0x40], xmm4
000078af20be347a  vmovaps [rsp+0x50], xmm5
000078af20be3480  vmovaps [rsp+0x60], xmm6
000078af20be3486  vmovaps [rsp+0x70], xmm7
000078af20be348c  vmovaps [rsp+0x80], xmm8
000078af20be3495  vmovaps [rsp+0x90], xmm9
000078af20be349e  vmovaps [rsp+0xA0], xmm10
000078af20be34a7  vmovaps [rsp+0xB0], xmm11
000078af20be34b0  vmovaps [rsp+0xC0], xmm12
000078af20be34b9  vmovaps [rsp+0xD0], xmm13
000078af20be34c2  vmovaps [rsp+0xE0], xmm15
000078af20be34cb  sub rsp, 0x30
000078af20be34cf  movaps [rsp], xmm14
000078af20be34d4  movaps [rsp+0x10], xmm12
000078af20be34da  movaps [rsp+0x20], xmm1
000078af20be34df  lea rdi, [rsp]
000078af20be34e3  mov esi, 0x00
000078af20be34e8  mov rax, 0x65452FFB8530
000078af20be34f2  call rax
000078af20be34f4  movaps xmm14, [rsp]
000078af20be34f9  add rsp, 0x30
000078af20be34fd  vmovaps xmm0, [rsp]
000078af20be3502  vmovaps xmm1, [rsp+0x10]
000078af20be3508  vmovaps xmm2, [rsp+0x20]
000078af20be350e  vmovaps xmm3, [rsp+0x30]
000078af20be3514  vmovaps xmm4, [rsp+0x40]
000078af20be351a  vmovaps xmm5, [rsp+0x50]
000078af20be3520  vmovaps xmm6, [rsp+0x60]
000078af20be3526  vmovaps xmm7, [rsp+0x70]
000078af20be352c  vmovaps xmm8, [rsp+0x80]
000078af20be3535  vmovaps xmm9, [rsp+0x90]
000078af20be353e  vmovaps xmm10, [rsp+0xA0]
000078af20be3547  vmovaps xmm11, [rsp+0xB0]
000078af20be3550  vmovaps xmm12, [rsp+0xC0]
000078af20be3559  vmovaps xmm13, [rsp+0xD0]
000078af20be3562  vmovaps xmm15, [rsp+0xE0]
000078af20be356b  add rsp, 0xF0
000078af20be3572  pop r11
000078af20be3574  pop r10
000078af20be3576  pop r9
000078af20be3578  pop r8
000078af20be357a  pop rsi
000078af20be357b  pop rdi
000078af20be357c  pop rdx
000078af20be357d  pop rcx
000078af20be357e  pop rax
000078af20be357f  add rsp, 0x08
000078af20be3583  jmp 0x000078AF20BDF793
000078af20be3588  sub rsp, 0x08
000078af20be358c  push rax
000078af20be358d  push rcx
000078af20be358e  push rdx
000078af20be358f  push rdi
000078af20be3590  push rsi
000078af20be3591  push r8
000078af20be3593  push r9
000078af20be3595  push r10
000078af20be3597  push r11
000078af20be3599  sub rsp, 0xF0
000078af20be35a0  vmovaps [rsp], xmm0
000078af20be35a5  vmovaps [rsp+0x10], xmm2
000078af20be35ab  vmovaps [rsp+0x20], xmm3
000078af20be35b1  vmovaps [rsp+0x30], xmm4
000078af20be35b7  vmovaps [rsp+0x40], xmm5
000078af20be35bd  vmovaps [rsp+0x50], xmm6
000078af20be35c3  vmovaps [rsp+0x60], xmm7
000078af20be35c9  vmovaps [rsp+0x70], xmm8
000078af20be35cf  vmovaps [rsp+0x80], xmm9
000078af20be35d8  vmovaps [rsp+0x90], xmm10
000078af20be35e1  vmovaps [rsp+0xA0], xmm11
000078af20be35ea  vmovaps [rsp+0xB0], xmm12
000078af20be35f3  vmovaps [rsp+0xC0], xmm13
000078af20be35fc  vmovaps [rsp+0xD0], xmm14
000078af20be3605  vmovaps [rsp+0xE0], xmm15
000078af20be360e  sub rsp, 0x30
000078af20be3612  movaps [rsp], xmm1
000078af20be3616  movaps [rsp+0x10], xmm13
000078af20be361c  movaps [rsp+0x20], xmm9
000078af20be3622  lea rdi, [rsp]
000078af20be3626  mov esi, 0x00
000078af20be362b  mov rax, 0x65452FFB8530
000078af20be3635  call rax
000078af20be3637  movaps xmm1, [rsp]
000078af20be363b  add rsp, 0x30
000078af20be363f  vmovaps xmm0, [rsp]
000078af20be3644  vmovaps xmm2, [rsp+0x10]
000078af20be364a  vmovaps xmm3, [rsp+0x20]
000078af20be3650  vmovaps xmm4, [rsp+0x30]
000078af20be3656  vmovaps xmm5, [rsp+0x40]
000078af20be365c  vmovaps xmm6, [rsp+0x50]
000078af20be3662  vmovaps xmm7, [rsp+0x60]
000078af20be3668  vmovaps xmm8, [rsp+0x70]
000078af20be366e  vmovaps xmm9, [rsp+0x80]
000078af20be3677  vmovaps xmm10, [rsp+0x90]
000078af20be3680  vmovaps xmm11, [rsp+0xA0]
000078af20be3689  vmovaps xmm12, [rsp+0xB0]
000078af20be3692  vmovaps xmm13, [rsp+0xC0]
000078af20be369b  vmovaps xmm14, [rsp+0xD0]
000078af20be36a4  vmovaps xmm15, [rsp+0xE0]
000078af20be36ad  add rsp, 0xF0
000078af20be36b4  pop r11
000078af20be36b6  pop r10
000078af20be36b8  pop r9
000078af20be36ba  pop r8
000078af20be36bc  pop rsi
000078af20be36bd  pop rdi
000078af20be36be  pop rdx
000078af20be36bf  pop rcx
000078af20be36c0  pop rax
000078af20be36c1  add rsp, 0x08
000078af20be36c5  jmp 0x000078AF20BDF7AD
000078af20be36ca  sub rsp, 0x08
000078af20be36ce  push rax
000078af20be36cf  push rcx
000078af20be36d0  push rdx
000078af20be36d1  push rdi
000078af20be36d2  push rsi
000078af20be36d3  push r8
000078af20be36d5  push r9
000078af20be36d7  push r10
000078af20be36d9  push r11
000078af20be36db  sub rsp, 0xF0
000078af20be36e2  vmovaps [rsp], xmm0
000078af20be36e7  vmovaps [rsp+0x10], xmm1
000078af20be36ed  vmovaps [rsp+0x20], xmm2
000078af20be36f3  vmovaps [rsp+0x30], xmm3
000078af20be36f9  vmovaps [rsp+0x40], xmm4
000078af20be36ff  vmovaps [rsp+0x50], xmm5
000078af20be3705  vmovaps [rsp+0x60], xmm6
000078af20be370b  vmovaps [rsp+0x70], xmm7
000078af20be3711  vmovaps [rsp+0x80], xmm8
000078af20be371a  vmovaps [rsp+0x90], xmm9
000078af20be3723  vmovaps [rsp+0xA0], xmm10
000078af20be372c  vmovaps [rsp+0xB0], xmm11
000078af20be3735  vmovaps [rsp+0xC0], xmm13
000078af20be373e  vmovaps [rsp+0xD0], xmm14
000078af20be3747  vmovaps [rsp+0xE0], xmm15
000078af20be3750  sub rsp, 0x30
000078af20be3754  movaps [rsp], xmm12
000078af20be3759  movaps [rsp+0x10], xmm7
000078af20be375e  movaps [rsp+0x20], xmm13
000078af20be3764  lea rdi, [rsp]
000078af20be3768  mov esi, 0x00
000078af20be376d  mov rax, 0x65452FFB8530
000078af20be3777  call rax
000078af20be3779  movaps xmm12, [rsp]
000078af20be377e  add rsp, 0x30
000078af20be3782  vmovaps xmm0, [rsp]
000078af20be3787  vmovaps xmm1, [rsp+0x10]
000078af20be378d  vmovaps xmm2, [rsp+0x20]
000078af20be3793  vmovaps xmm3, [rsp+0x30]
000078af20be3799  vmovaps xmm4, [rsp+0x40]
000078af20be379f  vmovaps xmm5, [rsp+0x50]
000078af20be37a5  vmovaps xmm6, [rsp+0x60]
000078af20be37ab  vmovaps xmm7, [rsp+0x70]
000078af20be37b1  vmovaps xmm8, [rsp+0x80]
000078af20be37ba  vmovaps xmm9, [rsp+0x90]
000078af20be37c3  vmovaps xmm10, [rsp+0xA0]
000078af20be37cc  vmovaps xmm11, [rsp+0xB0]
000078af20be37d5  vmovaps xmm13, [rsp+0xC0]
000078af20be37de  vmovaps xmm14, [rsp+0xD0]
000078af20be37e7  vmovaps xmm15, [rsp+0xE0]
000078af20be37f0  add rsp, 0xF0
000078af20be37f7  pop r11
000078af20be37f9  pop r10
000078af20be37fb  pop r9
000078af20be37fd  pop r8
000078af20be37ff  pop rsi
000078af20be3800  pop rdi
000078af20be3801  pop rdx
000078af20be3802  pop rcx
000078af20be3803  pop rax
000078af20be3804  add rsp, 0x08
000078af20be3808  jmp 0x000078AF20BDF7D4
000078af20be380d  sub rsp, 0x08
000078af20be3811  push rax
000078af20be3812  push rcx
000078af20be3813  push rdx
000078af20be3814  push rdi
000078af20be3815  push rsi
000078af20be3816  push r8
000078af20be3818  push r9
000078af20be381a  push r10
000078af20be381c  push r11
000078af20be381e  sub rsp, 0xF0
000078af20be3825  vmovaps [rsp], xmm0
000078af20be382a  vmovaps [rsp+0x10], xmm1
000078af20be3830  vmovaps [rsp+0x20], xmm2
000078af20be3836  vmovaps [rsp+0x30], xmm3
000078af20be383c  vmovaps [rsp+0x40], xmm4
000078af20be3842  vmovaps [rsp+0x50], xmm5
000078af20be3848  vmovaps [rsp+0x60], xmm6
000078af20be384e  vmovaps [rsp+0x70], xmm7
000078af20be3854  vmovaps [rsp+0x80], xmm8
000078af20be385d  vmovaps [rsp+0x90], xmm9
000078af20be3866  vmovaps [rsp+0xA0], xmm10
000078af20be386f  vmovaps [rsp+0xB0], xmm11
000078af20be3878  vmovaps [rsp+0xC0], xmm12
000078af20be3881  vmovaps [rsp+0xD0], xmm14
000078af20be388a  vmovaps [rsp+0xE0], xmm15
000078af20be3893  sub rsp, 0x30
000078af20be3897  movaps [rsp], xmm13
000078af20be389c  movaps [rsp+0x10], xmm15
000078af20be38a2  movaps [rsp+0x20], xmm8
000078af20be38a8  lea rdi, [rsp]
000078af20be38ac  mov esi, 0x00
000078af20be38b1  mov rax, 0x65452FFB8530
000078af20be38bb  call rax
000078af20be38bd  movaps xmm13, [rsp]
000078af20be38c2  add rsp, 0x30
000078af20be38c6  vmovaps xmm0, [rsp]
000078af20be38cb  vmovaps xmm1, [rsp+0x10]
000078af20be38d1  vmovaps xmm2, [rsp+0x20]
000078af20be38d7  vmovaps xmm3, [rsp+0x30]
000078af20be38dd  vmovaps xmm4, [rsp+0x40]
000078af20be38e3  vmovaps xmm5, [rsp+0x50]
000078af20be38e9  vmovaps xmm6, [rsp+0x60]
000078af20be38ef  vmovaps xmm7, [rsp+0x70]
000078af20be38f5  vmovaps xmm8, [rsp+0x80]
000078af20be38fe  vmovaps xmm9, [rsp+0x90]
000078af20be3907  vmovaps xmm10, [rsp+0xA0]
000078af20be3910  vmovaps xmm11, [rsp+0xB0]
000078af20be3919  vmovaps xmm12, [rsp+0xC0]
000078af20be3922  vmovaps xmm14, [rsp+0xD0]
000078af20be392b  vmovaps xmm15, [rsp+0xE0]
000078af20be3934  add rsp, 0xF0
000078af20be393b  pop r11
000078af20be393d  pop r10
000078af20be393f  pop r9
000078af20be3941  pop r8
000078af20be3943  pop rsi
000078af20be3944  pop rdi
000078af20be3945  pop rdx
000078af20be3946  pop rcx
000078af20be3947  pop rax
000078af20be3948  add rsp, 0x08
000078af20be394c  jmp 0x000078AF20BDF7EF
000078af20be3951  sub rsp, 0x08
000078af20be3955  push rax
000078af20be3956  push rcx
000078af20be3957  push rdx
000078af20be3958  push rdi
000078af20be3959  push rsi
000078af20be395a  push r8
000078af20be395c  push r9
000078af20be395e  push r10
000078af20be3960  push r11
000078af20be3962  sub rsp, 0xF0
000078af20be3969  vmovaps [rsp], xmm0
000078af20be396e  vmovaps [rsp+0x10], xmm1
000078af20be3974  vmovaps [rsp+0x20], xmm2
000078af20be397a  vmovaps [rsp+0x30], xmm3
000078af20be3980  vmovaps [rsp+0x40], xmm4
000078af20be3986  vmovaps [rsp+0x50], xmm5
000078af20be398c  vmovaps [rsp+0x60], xmm6
000078af20be3992  vmovaps [rsp+0x70], xmm7
000078af20be3998  vmovaps [rsp+0x80], xmm9
000078af20be39a1  vmovaps [rsp+0x90], xmm10
000078af20be39aa  vmovaps [rsp+0xA0], xmm11
000078af20be39b3  vmovaps [rsp+0xB0], xmm12
000078af20be39bc  vmovaps [rsp+0xC0], xmm13
000078af20be39c5  vmovaps [rsp+0xD0], xmm14
000078af20be39ce  vmovaps [rsp+0xE0], xmm15
000078af20be39d7  sub rsp, 0x30
000078af20be39db  movaps [rsp], xmm8
000078af20be39e0  movaps [rsp+0x10], xmm15
000078af20be39e6  movaps [rsp+0x20], xmm9
000078af20be39ec  lea rdi, [rsp]
000078af20be39f0  mov esi, 0x00
000078af20be39f5  mov rax, 0x65452FFB8530
000078af20be39ff  call rax
000078af20be3a01  movaps xmm8, [rsp]
000078af20be3a06  add rsp, 0x30
000078af20be3a0a  vmovaps xmm0, [rsp]
000078af20be3a0f  vmovaps xmm1, [rsp+0x10]
000078af20be3a15  vmovaps xmm2, [rsp+0x20]
000078af20be3a1b  vmovaps xmm3, [rsp+0x30]
000078af20be3a21  vmovaps xmm4, [rsp+0x40]
000078af20be3a27  vmovaps xmm5, [rsp+0x50]
000078af20be3a2d  vmovaps xmm6, [rsp+0x60]
000078af20be3a33  vmovaps xmm7, [rsp+0x70]
000078af20be3a39  vmovaps xmm9, [rsp+0x80]
000078af20be3a42  vmovaps xmm10, [rsp+0x90]
000078af20be3a4b  vmovaps xmm11, [rsp+0xA0]
000078af20be3a54  vmovaps xmm12, [rsp+0xB0]
000078af20be3a5d  vmovaps xmm13, [rsp+0xC0]
000078af20be3a66  vmovaps xmm14, [rsp+0xD0]
000078af20be3a6f  vmovaps xmm15, [rsp+0xE0]
000078af20be3a78  add rsp, 0xF0
000078af20be3a7f  pop r11
000078af20be3a81  pop r10
000078af20be3a83  pop r9
000078af20be3a85  pop r8
000078af20be3a87  pop rsi
000078af20be3a88  pop rdi
000078af20be3a89  pop rdx
000078af20be3a8a  pop rcx
000078af20be3a8b  pop rax
000078af20be3a8c  add rsp, 0x08
000078af20be3a90  jmp 0x000078AF20BDF81D
000078af20be3a95  sub rsp, 0x08
000078af20be3a99  push rax
000078af20be3a9a  push rcx
000078af20be3a9b  push rdx
000078af20be3a9c  push rdi
000078af20be3a9d  push rsi
000078af20be3a9e  push r8
000078af20be3aa0  push r9
000078af20be3aa2  push r10
000078af20be3aa4  push r11
000078af20be3aa6  sub rsp, 0xF0
000078af20be3aad  vmovaps [rsp], xmm0
000078af20be3ab2  vmovaps [rsp+0x10], xmm1
000078af20be3ab8  vmovaps [rsp+0x20], xmm2
000078af20be3abe  vmovaps [rsp+0x30], xmm3
000078af20be3ac4  vmovaps [rsp+0x40], xmm4
000078af20be3aca  vmovaps [rsp+0x50], xmm5
000078af20be3ad0  vmovaps [rsp+0x60], xmm6
000078af20be3ad6  vmovaps [rsp+0x70], xmm7
000078af20be3adc  vmovaps [rsp+0x80], xmm8
000078af20be3ae5  vmovaps [rsp+0x90], xmm9
000078af20be3aee  vmovaps [rsp+0xA0], xmm10
000078af20be3af7  vmovaps [rsp+0xB0], xmm11
000078af20be3b00  vmovaps [rsp+0xC0], xmm12
000078af20be3b09  vmovaps [rsp+0xD0], xmm13
000078af20be3b12  vmovaps [rsp+0xE0], xmm14
000078af20be3b1b  sub rsp, 0x30
000078af20be3b1f  movaps [rsp], xmm15
000078af20be3b24  movaps [rsp+0x10], xmm11
000078af20be3b2a  movaps [rsp+0x20], xmm6
000078af20be3b2f  lea rdi, [rsp]
000078af20be3b33  mov esi, 0x00
000078af20be3b38  mov rax, 0x65452FFB8530
000078af20be3b42  call rax
000078af20be3b44  movaps xmm15, [rsp]
000078af20be3b49  add rsp, 0x30
000078af20be3b4d  vmovaps xmm0, [rsp]
000078af20be3b52  vmovaps xmm1, [rsp+0x10]
000078af20be3b58  vmovaps xmm2, [rsp+0x20]
000078af20be3b5e  vmovaps xmm3, [rsp+0x30]
000078af20be3b64  vmovaps xmm4, [rsp+0x40]
000078af20be3b6a  vmovaps xmm5, [rsp+0x50]
000078af20be3b70  vmovaps xmm6, [rsp+0x60]
000078af20be3b76  vmovaps xmm7, [rsp+0x70]
000078af20be3b7c  vmovaps xmm8, [rsp+0x80]
000078af20be3b85  vmovaps xmm9, [rsp+0x90]
000078af20be3b8e  vmovaps xmm10, [rsp+0xA0]
000078af20be3b97  vmovaps xmm11, [rsp+0xB0]
000078af20be3ba0  vmovaps xmm12, [rsp+0xC0]
000078af20be3ba9  vmovaps xmm13, [rsp+0xD0]
000078af20be3bb2  vmovaps xmm14, [rsp+0xE0]
000078af20be3bbb  add rsp, 0xF0
000078af20be3bc2  pop r11
000078af20be3bc4  pop r10
000078af20be3bc6  pop r9
000078af20be3bc8  pop r8
000078af20be3bca  pop rsi
000078af20be3bcb  pop rdi
000078af20be3bcc  pop rdx
000078af20be3bcd  pop rcx
000078af20be3bce  pop rax
000078af20be3bcf  add rsp, 0x08
000078af20be3bd3  jmp 0x000078AF20BDF838
000078af20be3bd8  sub rsp, 0x08
000078af20be3bdc  push rax
000078af20be3bdd  push rcx
000078af20be3bde  push rdx
000078af20be3bdf  push rdi
000078af20be3be0  push rsi
000078af20be3be1  push r8
000078af20be3be3  push r9
000078af20be3be5  push r10
000078af20be3be7  push r11
000078af20be3be9  sub rsp, 0xF0
000078af20be3bf0  vmovaps [rsp], xmm0
000078af20be3bf5  vmovaps [rsp+0x10], xmm1
000078af20be3bfb  vmovaps [rsp+0x20], xmm2
000078af20be3c01  vmovaps [rsp+0x30], xmm3
000078af20be3c07  vmovaps [rsp+0x40], xmm4
000078af20be3c0d  vmovaps [rsp+0x50], xmm5
000078af20be3c13  vmovaps [rsp+0x60], xmm6
000078af20be3c19  vmovaps [rsp+0x70], xmm8
000078af20be3c1f  vmovaps [rsp+0x80], xmm9
000078af20be3c28  vmovaps [rsp+0x90], xmm10
000078af20be3c31  vmovaps [rsp+0xA0], xmm11
000078af20be3c3a  vmovaps [rsp+0xB0], xmm12
000078af20be3c43  vmovaps [rsp+0xC0], xmm13
000078af20be3c4c  vmovaps [rsp+0xD0], xmm14
000078af20be3c55  vmovaps [rsp+0xE0], xmm15
000078af20be3c5e  sub rsp, 0x30
000078af20be3c62  movaps [rsp], xmm7
000078af20be3c66  movaps [rsp+0x10], xmm11
000078af20be3c6c  movaps [rsp+0x20], xmm9
000078af20be3c72  lea rdi, [rsp]
000078af20be3c76  mov esi, 0x00
000078af20be3c7b  mov rax, 0x65452FFB8530
000078af20be3c85  call rax
000078af20be3c87  movaps xmm7, [rsp]
000078af20be3c8b  add rsp, 0x30
000078af20be3c8f  vmovaps xmm0, [rsp]
000078af20be3c94  vmovaps xmm1, [rsp+0x10]
000078af20be3c9a  vmovaps xmm2, [rsp+0x20]
000078af20be3ca0  vmovaps xmm3, [rsp+0x30]
000078af20be3ca6  vmovaps xmm4, [rsp+0x40]
000078af20be3cac  vmovaps xmm5, [rsp+0x50]
000078af20be3cb2  vmovaps xmm6, [rsp+0x60]
000078af20be3cb8  vmovaps xmm8, [rsp+0x70]
000078af20be3cbe  vmovaps xmm9, [rsp+0x80]
000078af20be3cc7  vmovaps xmm10, [rsp+0x90]
000078af20be3cd0  vmovaps xmm11, [rsp+0xA0]
000078af20be3cd9  vmovaps xmm12, [rsp+0xB0]
000078af20be3ce2  vmovaps xmm13, [rsp+0xC0]
000078af20be3ceb  vmovaps xmm14, [rsp+0xD0]
000078af20be3cf4  vmovaps xmm15, [rsp+0xE0]
000078af20be3cfd  add rsp, 0xF0
000078af20be3d04  pop r11
000078af20be3d06  pop r10
000078af20be3d08  pop r9
000078af20be3d0a  pop r8
000078af20be3d0c  pop rsi
000078af20be3d0d  pop rdi
000078af20be3d0e  pop rdx
000078af20be3d0f  pop rcx
000078af20be3d10  pop rax
000078af20be3d11  add rsp, 0x08
000078af20be3d15  jmp 0x000078AF20BDF865
000078af20be3d1a  sub rsp, 0x08
000078af20be3d1e  push rax
000078af20be3d1f  push rcx
000078af20be3d20  push rdx
000078af20be3d21  push rdi
000078af20be3d22  push rsi
000078af20be3d23  push r8
000078af20be3d25  push r9
000078af20be3d27  push r10
000078af20be3d29  push r11
000078af20be3d2b  sub rsp, 0xF0
000078af20be3d32  vmovaps [rsp], xmm0
000078af20be3d37  vmovaps [rsp+0x10], xmm1
000078af20be3d3d  vmovaps [rsp+0x20], xmm2
000078af20be3d43  vmovaps [rsp+0x30], xmm3
000078af20be3d49  vmovaps [rsp+0x40], xmm4
000078af20be3d4f  vmovaps [rsp+0x50], xmm5
000078af20be3d55  vmovaps [rsp+0x60], xmm6
000078af20be3d5b  vmovaps [rsp+0x70], xmm7
000078af20be3d61  vmovaps [rsp+0x80], xmm8
000078af20be3d6a  vmovaps [rsp+0x90], xmm9
000078af20be3d73  vmovaps [rsp+0xA0], xmm10
000078af20be3d7c  vmovaps [rsp+0xB0], xmm12
000078af20be3d85  vmovaps [rsp+0xC0], xmm13
000078af20be3d8e  vmovaps [rsp+0xD0], xmm14
000078af20be3d97  vmovaps [rsp+0xE0], xmm15
000078af20be3da0  sub rsp, 0x30
000078af20be3da4  movaps [rsp], xmm11
000078af20be3da9  movaps [rsp+0x10], xmm10
000078af20be3daf  movaps [rsp+0x20], xmm14
000078af20be3db5  lea rdi, [rsp]
000078af20be3db9  mov esi, 0x00
000078af20be3dbe  mov rax, 0x65452FFB8530
000078af20be3dc8  call rax
000078af20be3dca  movaps xmm11, [rsp]
000078af20be3dcf  add rsp, 0x30
000078af20be3dd3  vmovaps xmm0, [rsp]
000078af20be3dd8  vmovaps xmm1, [rsp+0x10]
000078af20be3dde  vmovaps xmm2, [rsp+0x20]
000078af20be3de4  vmovaps xmm3, [rsp+0x30]
000078af20be3dea  vmovaps xmm4, [rsp+0x40]
000078af20be3df0  vmovaps xmm5, [rsp+0x50]
000078af20be3df6  vmovaps xmm6, [rsp+0x60]
000078af20be3dfc  vmovaps xmm7, [rsp+0x70]
000078af20be3e02  vmovaps xmm8, [rsp+0x80]
000078af20be3e0b  vmovaps xmm9, [rsp+0x90]
000078af20be3e14  vmovaps xmm10, [rsp+0xA0]
000078af20be3e1d  vmovaps xmm12, [rsp+0xB0]
000078af20be3e26  vmovaps xmm13, [rsp+0xC0]
000078af20be3e2f  vmovaps xmm14, [rsp+0xD0]
000078af20be3e38  vmovaps xmm15, [rsp+0xE0]
000078af20be3e41  add rsp, 0xF0
000078af20be3e48  pop r11
000078af20be3e4a  pop r10
000078af20be3e4c  pop r9
000078af20be3e4e  pop r8
000078af20be3e50  pop rsi
000078af20be3e51  pop rdi
000078af20be3e52  pop rdx
000078af20be3e53  pop rcx
000078af20be3e54  pop rax
000078af20be3e55  add rsp, 0x08
000078af20be3e59  jmp 0x000078AF20BDF880
000078af20be3e5e  call 0x000078AF20AC33A0
000078af20be3e63  jmp 0x000078AF20BDF88A
000078af20be3e68  sub rsp, 0x08
000078af20be3e6c  push rax
000078af20be3e6d  push rcx
000078af20be3e6e  push rdx
000078af20be3e6f  push rdi
000078af20be3e70  push rsi
000078af20be3e71  push r8
000078af20be3e73  push r9
000078af20be3e75  push r10
000078af20be3e77  push r11
000078af20be3e79  sub rsp, 0xF0
000078af20be3e80  vmovaps [rsp], xmm0
000078af20be3e85  vmovaps [rsp+0x10], xmm1
000078af20be3e8b  vmovaps [rsp+0x20], xmm2
000078af20be3e91  vmovaps [rsp+0x30], xmm3
000078af20be3e97  vmovaps [rsp+0x40], xmm4
000078af20be3e9d  vmovaps [rsp+0x50], xmm5
000078af20be3ea3  vmovaps [rsp+0x60], xmm6
000078af20be3ea9  vmovaps [rsp+0x70], xmm7
000078af20be3eaf  vmovaps [rsp+0x80], xmm8
000078af20be3eb8  vmovaps [rsp+0x90], xmm9
000078af20be3ec1  vmovaps [rsp+0xA0], xmm11
000078af20be3eca  vmovaps [rsp+0xB0], xmm12
000078af20be3ed3  vmovaps [rsp+0xC0], xmm13
000078af20be3edc  vmovaps [rsp+0xD0], xmm14
000078af20be3ee5  vmovaps [rsp+0xE0], xmm15
000078af20be3eee  sub rsp, 0x30
000078af20be3ef2  movaps [rsp], xmm10
000078af20be3ef7  movaps [rsp+0x10], xmm1
000078af20be3efc  movaps [rsp+0x20], xmm12
000078af20be3f02  lea rdi, [rsp]
000078af20be3f06  mov esi, 0x00
000078af20be3f0b  mov rax, 0x65452FFB8530
000078af20be3f15  call rax
000078af20be3f17  movaps xmm10, [rsp]
000078af20be3f1c  add rsp, 0x30
000078af20be3f20  vmovaps xmm0, [rsp]
000078af20be3f25  vmovaps xmm1, [rsp+0x10]
000078af20be3f2b  vmovaps xmm2, [rsp+0x20]
000078af20be3f31  vmovaps xmm3, [rsp+0x30]
000078af20be3f37  vmovaps xmm4, [rsp+0x40]
000078af20be3f3d  vmovaps xmm5, [rsp+0x50]
000078af20be3f43  vmovaps xmm6, [rsp+0x60]
000078af20be3f49  vmovaps xmm7, [rsp+0x70]
000078af20be3f4f  vmovaps xmm8, [rsp+0x80]
000078af20be3f58  vmovaps xmm9, [rsp+0x90]
000078af20be3f61  vmovaps xmm11, [rsp+0xA0]
000078af20be3f6a  vmovaps xmm12, [rsp+0xB0]
000078af20be3f73  vmovaps xmm13, [rsp+0xC0]
000078af20be3f7c  vmovaps xmm14, [rsp+0xD0]
000078af20be3f85  vmovaps xmm15, [rsp+0xE0]
000078af20be3f8e  add rsp, 0xF0
000078af20be3f95  pop r11
000078af20be3f97  pop r10
000078af20be3f99  pop r9
000078af20be3f9b  pop r8
000078af20be3f9d  pop rsi
000078af20be3f9e  pop rdi
000078af20be3f9f  pop rdx
000078af20be3fa0  pop rcx
000078af20be3fa1  pop rax
000078af20be3fa2  add rsp, 0x08
000078af20be3fa6  jmp 0x000078AF20BDF8AD
000078af20be3fab  sub rsp, 0x08
000078af20be3faf  push rax
000078af20be3fb0  push rcx
000078af20be3fb1  push rdx
000078af20be3fb2  push rdi
000078af20be3fb3  push rsi
000078af20be3fb4  push r8
000078af20be3fb6  push r9
000078af20be3fb8  push r10
000078af20be3fba  push r11
000078af20be3fbc  sub rsp, 0xF0
000078af20be3fc3  vmovaps [rsp], xmm0
000078af20be3fc8  vmovaps [rsp+0x10], xmm1
000078af20be3fce  vmovaps [rsp+0x20], xmm2
000078af20be3fd4  vmovaps [rsp+0x30], xmm3
000078af20be3fda  vmovaps [rsp+0x40], xmm4
000078af20be3fe0  vmovaps [rsp+0x50], xmm5
000078af20be3fe6  vmovaps [rsp+0x60], xmm6
000078af20be3fec  vmovaps [rsp+0x70], xmm7
000078af20be3ff2  vmovaps [rsp+0x80], xmm8
000078af20be3ffb  vmovaps [rsp+0x90], xmm9
000078af20be4004  vmovaps [rsp+0xA0], xmm10
000078af20be400d  vmovaps [rsp+0xB0], xmm11
000078af20be4016  vmovaps [rsp+0xC0], xmm13
000078af20be401f  vmovaps [rsp+0xD0], xmm14
000078af20be4028  vmovaps [rsp+0xE0], xmm15
000078af20be4031  sub rsp, 0x30
000078af20be4035  movaps [rsp], xmm12
000078af20be403a  movaps [rsp+0x10], xmm14
000078af20be4040  movaps [rsp+0x20], xmm1
000078af20be4045  lea rdi, [rsp]
000078af20be4049  mov esi, 0x00
000078af20be404e  mov rax, 0x65452FFB8530
000078af20be4058  call rax
000078af20be405a  movaps xmm12, [rsp]
000078af20be405f  add rsp, 0x30
000078af20be4063  vmovaps xmm0, [rsp]
000078af20be4068  vmovaps xmm1, [rsp+0x10]
000078af20be406e  vmovaps xmm2, [rsp+0x20]
000078af20be4074  vmovaps xmm3, [rsp+0x30]
000078af20be407a  vmovaps xmm4, [rsp+0x40]
000078af20be4080  vmovaps xmm5, [rsp+0x50]
000078af20be4086  vmovaps xmm6, [rsp+0x60]
000078af20be408c  vmovaps xmm7, [rsp+0x70]
000078af20be4092  vmovaps xmm8, [rsp+0x80]
000078af20be409b  vmovaps xmm9, [rsp+0x90]
000078af20be40a4  vmovaps xmm10, [rsp+0xA0]
000078af20be40ad  vmovaps xmm11, [rsp+0xB0]
000078af20be40b6  vmovaps xmm13, [rsp+0xC0]
000078af20be40bf  vmovaps xmm14, [rsp+0xD0]
000078af20be40c8  vmovaps xmm15, [rsp+0xE0]
000078af20be40d1  add rsp, 0xF0
000078af20be40d8  pop r11
000078af20be40da  pop r10
000078af20be40dc  pop r9
000078af20be40de  pop r8
000078af20be40e0  pop rsi
000078af20be40e1  pop rdi
000078af20be40e2  pop rdx
000078af20be40e3  pop rcx
000078af20be40e4  pop rax
000078af20be40e5  add rsp, 0x08
000078af20be40e9  jmp 0x000078AF20BDF8DC
000078af20be40ee  sub rsp, 0x08
000078af20be40f2  push rax
000078af20be40f3  push rcx
000078af20be40f4  push rdx
000078af20be40f5  push rdi
000078af20be40f6  push rsi
000078af20be40f7  push r8
000078af20be40f9  push r9
000078af20be40fb  push r10
000078af20be40fd  push r11
000078af20be40ff  sub rsp, 0xF0
000078af20be4106  vmovaps [rsp], xmm0
000078af20be410b  vmovaps [rsp+0x10], xmm1
000078af20be4111  vmovaps [rsp+0x20], xmm2
000078af20be4117  vmovaps [rsp+0x30], xmm3
000078af20be411d  vmovaps [rsp+0x40], xmm4
000078af20be4123  vmovaps [rsp+0x50], xmm5
000078af20be4129  vmovaps [rsp+0x60], xmm6
000078af20be412f  vmovaps [rsp+0x70], xmm7
000078af20be4135  vmovaps [rsp+0x80], xmm8
000078af20be413e  vmovaps [rsp+0x90], xmm9
000078af20be4147  vmovaps [rsp+0xA0], xmm10
000078af20be4150  vmovaps [rsp+0xB0], xmm11
000078af20be4159  vmovaps [rsp+0xC0], xmm12
000078af20be4162  vmovaps [rsp+0xD0], xmm13
000078af20be416b  vmovaps [rsp+0xE0], xmm15
000078af20be4174  sub rsp, 0x30
000078af20be4178  movaps [rsp], xmm14
000078af20be417d  movaps [rsp+0x10], xmm9
000078af20be4183  movaps [rsp+0x20], xmm1
000078af20be4188  lea rdi, [rsp]
000078af20be418c  mov esi, 0x00
000078af20be4191  mov rax, 0x65452FFB8530
000078af20be419b  call rax
000078af20be419d  movaps xmm14, [rsp]
000078af20be41a2  add rsp, 0x30
000078af20be41a6  vmovaps xmm0, [rsp]
000078af20be41ab  vmovaps xmm1, [rsp+0x10]
000078af20be41b1  vmovaps xmm2, [rsp+0x20]
000078af20be41b7  vmovaps xmm3, [rsp+0x30]
000078af20be41bd  vmovaps xmm4, [rsp+0x40]
000078af20be41c3  vmovaps xmm5, [rsp+0x50]
000078af20be41c9  vmovaps xmm6, [rsp+0x60]
000078af20be41cf  vmovaps xmm7, [rsp+0x70]
000078af20be41d5  vmovaps xmm8, [rsp+0x80]
000078af20be41de  vmovaps xmm9, [rsp+0x90]
000078af20be41e7  vmovaps xmm10, [rsp+0xA0]
000078af20be41f0  vmovaps xmm11, [rsp+0xB0]
000078af20be41f9  vmovaps xmm12, [rsp+0xC0]
000078af20be4202  vmovaps xmm13, [rsp+0xD0]
000078af20be420b  vmovaps xmm15, [rsp+0xE0]
000078af20be4214  add rsp, 0xF0
000078af20be421b  pop r11
000078af20be421d  pop r10
000078af20be421f  pop r9
000078af20be4221  pop r8
000078af20be4223  pop rsi
000078af20be4224  pop rdi
000078af20be4225  pop rdx
000078af20be4226  pop rcx
000078af20be4227  pop rax
000078af20be4228  add rsp, 0x08
000078af20be422c  jmp 0x000078AF20BDF90B
000078af20be4231  sub rsp, 0x08
000078af20be4235  push rax
000078af20be4236  push rcx
000078af20be4237  push rdx
000078af20be4238  push rdi
000078af20be4239  push rsi
000078af20be423a  push r8
000078af20be423c  push r9
000078af20be423e  push r10
000078af20be4240  push r11
000078af20be4242  sub rsp, 0xF0
000078af20be4249  vmovaps [rsp], xmm0
000078af20be424e  vmovaps [rsp+0x10], xmm2
000078af20be4254  vmovaps [rsp+0x20], xmm3
000078af20be425a  vmovaps [rsp+0x30], xmm4
000078af20be4260  vmovaps [rsp+0x40], xmm5
000078af20be4266  vmovaps [rsp+0x50], xmm6
000078af20be426c  vmovaps [rsp+0x60], xmm7
000078af20be4272  vmovaps [rsp+0x70], xmm8
000078af20be4278  vmovaps [rsp+0x80], xmm9
000078af20be4281  vmovaps [rsp+0x90], xmm10
000078af20be428a  vmovaps [rsp+0xA0], xmm11
000078af20be4293  vmovaps [rsp+0xB0], xmm12
000078af20be429c  vmovaps [rsp+0xC0], xmm13
000078af20be42a5  vmovaps [rsp+0xD0], xmm14
000078af20be42ae  vmovaps [rsp+0xE0], xmm15
000078af20be42b7  sub rsp, 0x30
000078af20be42bb  movaps [rsp], xmm1
000078af20be42bf  movaps [rsp+0x10], xmm13
000078af20be42c5  movaps [rsp+0x20], xmm8
000078af20be42cb  lea rdi, [rsp]
000078af20be42cf  mov esi, 0x00
000078af20be42d4  mov rax, 0x65452FFB8530
000078af20be42de  call rax
000078af20be42e0  movaps xmm1, [rsp]
000078af20be42e4  add rsp, 0x30
000078af20be42e8  vmovaps xmm0, [rsp]
000078af20be42ed  vmovaps xmm2, [rsp+0x10]
000078af20be42f3  vmovaps xmm3, [rsp+0x20]
000078af20be42f9  vmovaps xmm4, [rsp+0x30]
000078af20be42ff  vmovaps xmm5, [rsp+0x40]
000078af20be4305  vmovaps xmm6, [rsp+0x50]
000078af20be430b  vmovaps xmm7, [rsp+0x60]
000078af20be4311  vmovaps xmm8, [rsp+0x70]
000078af20be4317  vmovaps xmm9, [rsp+0x80]
000078af20be4320  vmovaps xmm10, [rsp+0x90]
000078af20be4329  vmovaps xmm11, [rsp+0xA0]
000078af20be4332  vmovaps xmm12, [rsp+0xB0]
000078af20be433b  vmovaps xmm13, [rsp+0xC0]
000078af20be4344  vmovaps xmm14, [rsp+0xD0]
000078af20be434d  vmovaps xmm15, [rsp+0xE0]
000078af20be4356  add rsp, 0xF0
000078af20be435d  pop r11
000078af20be435f  pop r10
000078af20be4361  pop r9
000078af20be4363  pop r8
000078af20be4365  pop rsi
000078af20be4366  pop rdi
000078af20be4367  pop rdx
000078af20be4368  pop rcx
000078af20be4369  pop rax
000078af20be436a  add rsp, 0x08
000078af20be436e  jmp 0x000078AF20BDF92D
000078af20be4373  call 0x000078AF20A0C260
000078af20be4378  jmp 0x000078AF20BDF93B
000078af20be437d  call 0x000078AF20ABD750
000078af20be4382  jmp 0x000078AF20BDF945
000078af20be4387  sub rsp, 0x08
000078af20be438b  push rax
000078af20be438c  push rcx
000078af20be438d  push rdx
000078af20be438e  push rdi
000078af20be438f  push rsi
000078af20be4390  push r8
000078af20be4392  push r9
000078af20be4394  push r10
000078af20be4396  push r11
000078af20be4398  sub rsp, 0xF0
000078af20be439f  vmovaps [rsp], xmm0
000078af20be43a4  vmovaps [rsp+0x10], xmm1
000078af20be43aa  vmovaps [rsp+0x20], xmm2
000078af20be43b0  vmovaps [rsp+0x30], xmm3
000078af20be43b6  vmovaps [rsp+0x40], xmm4
000078af20be43bc  vmovaps [rsp+0x50], xmm5
000078af20be43c2  vmovaps [rsp+0x60], xmm6
000078af20be43c8  vmovaps [rsp+0x70], xmm7
000078af20be43ce  vmovaps [rsp+0x80], xmm9
000078af20be43d7  vmovaps [rsp+0x90], xmm10
000078af20be43e0  vmovaps [rsp+0xA0], xmm11
000078af20be43e9  vmovaps [rsp+0xB0], xmm12
000078af20be43f2  vmovaps [rsp+0xC0], xmm13
000078af20be43fb  vmovaps [rsp+0xD0], xmm14
000078af20be4404  vmovaps [rsp+0xE0], xmm15
000078af20be440d  sub rsp, 0x30
000078af20be4411  movaps [rsp], xmm8
000078af20be4416  movaps [rsp+0x10], xmm15
000078af20be441c  movaps [rsp+0x20], xmm7
000078af20be4421  lea rdi, [rsp]
000078af20be4425  mov esi, 0x00
000078af20be442a  mov rax, 0x65452FFB8530
000078af20be4434  call rax
000078af20be4436  movaps xmm8, [rsp]
000078af20be443b  add rsp, 0x30
000078af20be443f  vmovaps xmm0, [rsp]
000078af20be4444  vmovaps xmm1, [rsp+0x10]
000078af20be444a  vmovaps xmm2, [rsp+0x20]
000078af20be4450  vmovaps xmm3, [rsp+0x30]
000078af20be4456  vmovaps xmm4, [rsp+0x40]
000078af20be445c  vmovaps xmm5, [rsp+0x50]
000078af20be4462  vmovaps xmm6, [rsp+0x60]
000078af20be4468  vmovaps xmm7, [rsp+0x70]
000078af20be446e  vmovaps xmm9, [rsp+0x80]
000078af20be4477  vmovaps xmm10, [rsp+0x90]
000078af20be4480  vmovaps xmm11, [rsp+0xA0]
000078af20be4489  vmovaps xmm12, [rsp+0xB0]
000078af20be4492  vmovaps xmm13, [rsp+0xC0]
000078af20be449b  vmovaps xmm14, [rsp+0xD0]
000078af20be44a4  vmovaps xmm15, [rsp+0xE0]
000078af20be44ad  add rsp, 0xF0
000078af20be44b4  pop r11
000078af20be44b6  pop r10
000078af20be44b8  pop r9
000078af20be44ba  pop r8
000078af20be44bc  pop rsi
000078af20be44bd  pop rdi
000078af20be44be  pop rdx
000078af20be44bf  pop rcx
000078af20be44c0  pop rax
000078af20be44c1  add rsp, 0x08
000078af20be44c5  jmp 0x000078AF20BDF967
000078af20be44ca  sub rsp, 0x08
000078af20be44ce  push rax
000078af20be44cf  push rcx
000078af20be44d0  push rdx
000078af20be44d1  push rdi
000078af20be44d2  push rsi
000078af20be44d3  push r8
000078af20be44d5  push r9
000078af20be44d7  push r10
000078af20be44d9  push r11
000078af20be44db  sub rsp, 0xF0
000078af20be44e2  vmovaps [rsp], xmm0
000078af20be44e7  vmovaps [rsp+0x10], xmm1
000078af20be44ed  vmovaps [rsp+0x20], xmm2
000078af20be44f3  vmovaps [rsp+0x30], xmm3
000078af20be44f9  vmovaps [rsp+0x40], xmm4
000078af20be44ff  vmovaps [rsp+0x50], xmm5
000078af20be4505  vmovaps [rsp+0x60], xmm6
000078af20be450b  vmovaps [rsp+0x70], xmm8
000078af20be4511  vmovaps [rsp+0x80], xmm9
000078af20be451a  vmovaps [rsp+0x90], xmm10
000078af20be4523  vmovaps [rsp+0xA0], xmm11
000078af20be452c  vmovaps [rsp+0xB0], xmm12
000078af20be4535  vmovaps [rsp+0xC0], xmm13
000078af20be453e  vmovaps [rsp+0xD0], xmm14
000078af20be4547  vmovaps [rsp+0xE0], xmm15
000078af20be4550  sub rsp, 0x30
000078af20be4554  movaps [rsp], xmm7
000078af20be4558  movaps [rsp+0x10], xmm9
000078af20be455e  movaps [rsp+0x20], xmm15
000078af20be4564  lea rdi, [rsp]
000078af20be4568  mov esi, 0x00
000078af20be456d  mov rax, 0x65452FFB8530
000078af20be4577  call rax
000078af20be4579  movaps xmm7, [rsp]
000078af20be457d  add rsp, 0x30
000078af20be4581  vmovaps xmm0, [rsp]
000078af20be4586  vmovaps xmm1, [rsp+0x10]
000078af20be458c  vmovaps xmm2, [rsp+0x20]
000078af20be4592  vmovaps xmm3, [rsp+0x30]
000078af20be4598  vmovaps xmm4, [rsp+0x40]
000078af20be459e  vmovaps xmm5, [rsp+0x50]
000078af20be45a4  vmovaps xmm6, [rsp+0x60]
000078af20be45aa  vmovaps xmm8, [rsp+0x70]
000078af20be45b0  vmovaps xmm9, [rsp+0x80]
000078af20be45b9  vmovaps xmm10, [rsp+0x90]
000078af20be45c2  vmovaps xmm11, [rsp+0xA0]
000078af20be45cb  vmovaps xmm12, [rsp+0xB0]
000078af20be45d4  vmovaps xmm13, [rsp+0xC0]
000078af20be45dd  vmovaps xmm14, [rsp+0xD0]
000078af20be45e6  vmovaps xmm15, [rsp+0xE0]
000078af20be45ef  add rsp, 0xF0
000078af20be45f6  pop r11
000078af20be45f8  pop r10
000078af20be45fa  pop r9
000078af20be45fc  pop r8
000078af20be45fe  pop rsi
000078af20be45ff  pop rdi
000078af20be4600  pop rdx
000078af20be4601  pop rcx
000078af20be4602  pop rax
000078af20be4603  add rsp, 0x08
000078af20be4607  jmp 0x000078AF20BDF994
000078af20be460c  sub rsp, 0x08
000078af20be4610  push rax
000078af20be4611  push rcx
000078af20be4612  push rdx
000078af20be4613  push rdi
000078af20be4614  push rsi
000078af20be4615  push r8
000078af20be4617  push r9
000078af20be4619  push r10
000078af20be461b  push r11
000078af20be461d  sub rsp, 0xF0
000078af20be4624  vmovaps [rsp], xmm0
000078af20be4629  vmovaps [rsp+0x10], xmm1
000078af20be462f  vmovaps [rsp+0x20], xmm2
000078af20be4635  vmovaps [rsp+0x30], xmm3
000078af20be463b  vmovaps [rsp+0x40], xmm4
000078af20be4641  vmovaps [rsp+0x50], xmm5
000078af20be4647  vmovaps [rsp+0x60], xmm6
000078af20be464d  vmovaps [rsp+0x70], xmm7
000078af20be4653  vmovaps [rsp+0x80], xmm8
000078af20be465c  vmovaps [rsp+0x90], xmm10
000078af20be4665  vmovaps [rsp+0xA0], xmm11
000078af20be466e  vmovaps [rsp+0xB0], xmm12
000078af20be4677  vmovaps [rsp+0xC0], xmm13
000078af20be4680  vmovaps [rsp+0xD0], xmm14
000078af20be4689  vmovaps [rsp+0xE0], xmm15
000078af20be4692  sub rsp, 0x30
000078af20be4696  movaps [rsp], xmm9
000078af20be469b  movaps [rsp+0x10], xmm13
000078af20be46a1  movaps [rsp+0x20], xmm15
000078af20be46a7  lea rdi, [rsp]
000078af20be46ab  mov esi, 0x00
000078af20be46b0  mov rax, 0x65452FFB8530
000078af20be46ba  call rax
000078af20be46bc  movaps xmm9, [rsp]
000078af20be46c1  add rsp, 0x30
000078af20be46c5  vmovaps xmm0, [rsp]
000078af20be46ca  vmovaps xmm1, [rsp+0x10]
000078af20be46d0  vmovaps xmm2, [rsp+0x20]
000078af20be46d6  vmovaps xmm3, [rsp+0x30]
000078af20be46dc  vmovaps xmm4, [rsp+0x40]
000078af20be46e2  vmovaps xmm5, [rsp+0x50]
000078af20be46e8  vmovaps xmm6, [rsp+0x60]
000078af20be46ee  vmovaps xmm7, [rsp+0x70]
000078af20be46f4  vmovaps xmm8, [rsp+0x80]
000078af20be46fd  vmovaps xmm10, [rsp+0x90]
000078af20be4706  vmovaps xmm11, [rsp+0xA0]
000078af20be470f  vmovaps xmm12, [rsp+0xB0]
000078af20be4718  vmovaps xmm13, [rsp+0xC0]
000078af20be4721  vmovaps xmm14, [rsp+0xD0]
000078af20be472a  vmovaps xmm15, [rsp+0xE0]
000078af20be4733  add rsp, 0xF0
000078af20be473a  pop r11
000078af20be473c  pop r10
000078af20be473e  pop r9
000078af20be4740  pop r8
000078af20be4742  pop rsi
000078af20be4743  pop rdi
000078af20be4744  pop rdx
000078af20be4745  pop rcx
000078af20be4746  pop rax
000078af20be4747  add rsp, 0x08
000078af20be474b  jmp 0x000078AF20BDF9C2
000078af20be4750  sub rsp, 0x08
000078af20be4754  push rax
000078af20be4755  push rcx
000078af20be4756  push rdx
000078af20be4757  push rdi
000078af20be4758  push rsi
000078af20be4759  push r8
000078af20be475b  push r9
000078af20be475d  push r10
000078af20be475f  push r11
000078af20be4761  sub rsp, 0xF0
000078af20be4768  vmovaps [rsp], xmm0
000078af20be476d  vmovaps [rsp+0x10], xmm1
000078af20be4773  vmovaps [rsp+0x20], xmm2
000078af20be4779  vmovaps [rsp+0x30], xmm3
000078af20be477f  vmovaps [rsp+0x40], xmm4
000078af20be4785  vmovaps [rsp+0x50], xmm5
000078af20be478b  vmovaps [rsp+0x60], xmm6
000078af20be4791  vmovaps [rsp+0x70], xmm7
000078af20be4797  vmovaps [rsp+0x80], xmm8
000078af20be47a0  vmovaps [rsp+0x90], xmm9
000078af20be47a9  vmovaps [rsp+0xA0], xmm10
000078af20be47b2  vmovaps [rsp+0xB0], xmm11
000078af20be47bb  vmovaps [rsp+0xC0], xmm12
000078af20be47c4  vmovaps [rsp+0xD0], xmm13
000078af20be47cd  vmovaps [rsp+0xE0], xmm14
000078af20be47d6  sub rsp, 0x30
000078af20be47da  movaps [rsp], xmm15
000078af20be47df  movaps [rsp+0x10], xmm11
000078af20be47e5  movaps [rsp+0x20], xmm12
000078af20be47eb  lea rdi, [rsp]
000078af20be47ef  mov esi, 0x00
000078af20be47f4  mov rax, 0x65452FFB8530
000078af20be47fe  call rax
000078af20be4800  movaps xmm15, [rsp]
000078af20be4805  add rsp, 0x30
000078af20be4809  vmovaps xmm0, [rsp]
000078af20be480e  vmovaps xmm1, [rsp+0x10]
000078af20be4814  vmovaps xmm2, [rsp+0x20]
000078af20be481a  vmovaps xmm3, [rsp+0x30]
000078af20be4820  vmovaps xmm4, [rsp+0x40]
000078af20be4826  vmovaps xmm5, [rsp+0x50]
000078af20be482c  vmovaps xmm6, [rsp+0x60]
000078af20be4832  vmovaps xmm7, [rsp+0x70]
000078af20be4838  vmovaps xmm8, [rsp+0x80]
000078af20be4841  vmovaps xmm9, [rsp+0x90]
000078af20be484a  vmovaps xmm10, [rsp+0xA0]
000078af20be4853  vmovaps xmm11, [rsp+0xB0]
000078af20be485c  vmovaps xmm12, [rsp+0xC0]
000078af20be4865  vmovaps xmm13, [rsp+0xD0]
000078af20be486e  vmovaps xmm14, [rsp+0xE0]
000078af20be4877  add rsp, 0xF0
000078af20be487e  pop r11
000078af20be4880  pop r10
000078af20be4882  pop r9
000078af20be4884  pop r8
000078af20be4886  pop rsi
000078af20be4887  pop rdi
000078af20be4888  pop rdx
000078af20be4889  pop rcx
000078af20be488a  pop rax
000078af20be488b  add rsp, 0x08
000078af20be488f  jmp 0x000078AF20BDF9DD
000078af20be4894  sub rsp, 0x08
000078af20be4898  push rax
000078af20be4899  push rcx
000078af20be489a  push rdx
000078af20be489b  push rdi
000078af20be489c  push rsi
000078af20be489d  push r8
000078af20be489f  push r9
000078af20be48a1  push r10
000078af20be48a3  push r11
000078af20be48a5  sub rsp, 0xF0
000078af20be48ac  vmovaps [rsp], xmm0
000078af20be48b1  vmovaps [rsp+0x10], xmm1
000078af20be48b7  vmovaps [rsp+0x20], xmm2
000078af20be48bd  vmovaps [rsp+0x30], xmm3
000078af20be48c3  vmovaps [rsp+0x40], xmm4
000078af20be48c9  vmovaps [rsp+0x50], xmm5
000078af20be48cf  vmovaps [rsp+0x60], xmm6
000078af20be48d5  vmovaps [rsp+0x70], xmm7
000078af20be48db  vmovaps [rsp+0x80], xmm8
000078af20be48e4  vmovaps [rsp+0x90], xmm9
000078af20be48ed  vmovaps [rsp+0xA0], xmm10
000078af20be48f6  vmovaps [rsp+0xB0], xmm11
000078af20be48ff  vmovaps [rsp+0xC0], xmm12
000078af20be4908  vmovaps [rsp+0xD0], xmm14
000078af20be4911  vmovaps [rsp+0xE0], xmm15
000078af20be491a  sub rsp, 0x30
000078af20be491e  movaps [rsp], xmm13
000078af20be4923  movaps [rsp+0x10], xmm10
000078af20be4929  movaps [rsp+0x20], xmm14
000078af20be492f  lea rdi, [rsp]
000078af20be4933  mov esi, 0x00
000078af20be4938  mov rax, 0x65452FFB8530
000078af20be4942  call rax
000078af20be4944  movaps xmm13, [rsp]
000078af20be4949  add rsp, 0x30
000078af20be494d  vmovaps xmm0, [rsp]
000078af20be4952  vmovaps xmm1, [rsp+0x10]
000078af20be4958  vmovaps xmm2, [rsp+0x20]
000078af20be495e  vmovaps xmm3, [rsp+0x30]
000078af20be4964  vmovaps xmm4, [rsp+0x40]
000078af20be496a  vmovaps xmm5, [rsp+0x50]
000078af20be4970  vmovaps xmm6, [rsp+0x60]
000078af20be4976  vmovaps xmm7, [rsp+0x70]
000078af20be497c  vmovaps xmm8, [rsp+0x80]
000078af20be4985  vmovaps xmm9, [rsp+0x90]
000078af20be498e  vmovaps xmm10, [rsp+0xA0]
000078af20be4997  vmovaps xmm11, [rsp+0xB0]
000078af20be49a0  vmovaps xmm12, [rsp+0xC0]
000078af20be49a9  vmovaps xmm14, [rsp+0xD0]
000078af20be49b2  vmovaps xmm15, [rsp+0xE0]
000078af20be49bb  add rsp, 0xF0
000078af20be49c2  pop r11
000078af20be49c4  pop r10
000078af20be49c6  pop r9
000078af20be49c8  pop r8
000078af20be49ca  pop rsi
000078af20be49cb  pop rdi
000078af20be49cc  pop rdx
000078af20be49cd  pop rcx
000078af20be49ce  pop rax
000078af20be49cf  add rsp, 0x08
000078af20be49d3  jmp 0x000078AF20BDFA00
000078af20be49d8  sub rsp, 0x08
000078af20be49dc  push rax
000078af20be49dd  push rcx
000078af20be49de  push rdx
000078af20be49df  push rdi
000078af20be49e0  push rsi
000078af20be49e1  push r8
000078af20be49e3  push r9
000078af20be49e5  push r10
000078af20be49e7  push r11
000078af20be49e9  sub rsp, 0xF0
000078af20be49f0  vmovaps [rsp], xmm0
000078af20be49f5  vmovaps [rsp+0x10], xmm1
000078af20be49fb  vmovaps [rsp+0x20], xmm2
000078af20be4a01  vmovaps [rsp+0x30], xmm3
000078af20be4a07  vmovaps [rsp+0x40], xmm4
000078af20be4a0d  vmovaps [rsp+0x50], xmm5
000078af20be4a13  vmovaps [rsp+0x60], xmm6
000078af20be4a19  vmovaps [rsp+0x70], xmm7
000078af20be4a1f  vmovaps [rsp+0x80], xmm8
000078af20be4a28  vmovaps [rsp+0x90], xmm9
000078af20be4a31  vmovaps [rsp+0xA0], xmm10
000078af20be4a3a  vmovaps [rsp+0xB0], xmm11
000078af20be4a43  vmovaps [rsp+0xC0], xmm12
000078af20be4a4c  vmovaps [rsp+0xD0], xmm13
000078af20be4a55  vmovaps [rsp+0xE0], xmm15
000078af20be4a5e  sub rsp, 0x30
000078af20be4a62  movaps [rsp], xmm14
000078af20be4a67  movaps [rsp+0x10], xmm1
000078af20be4a6c  movaps [rsp+0x20], xmm7
000078af20be4a71  lea rdi, [rsp]
000078af20be4a75  mov esi, 0x00
000078af20be4a7a  mov rax, 0x65452FFB8530
000078af20be4a84  call rax
000078af20be4a86  movaps xmm14, [rsp]
000078af20be4a8b  add rsp, 0x30
000078af20be4a8f  vmovaps xmm0, [rsp]
000078af20be4a94  vmovaps xmm1, [rsp+0x10]
000078af20be4a9a  vmovaps xmm2, [rsp+0x20]
000078af20be4aa0  vmovaps xmm3, [rsp+0x30]
000078af20be4aa6  vmovaps xmm4, [rsp+0x40]
000078af20be4aac  vmovaps xmm5, [rsp+0x50]
000078af20be4ab2  vmovaps xmm6, [rsp+0x60]
000078af20be4ab8  vmovaps xmm7, [rsp+0x70]
000078af20be4abe  vmovaps xmm8, [rsp+0x80]
000078af20be4ac7  vmovaps xmm9, [rsp+0x90]
000078af20be4ad0  vmovaps xmm10, [rsp+0xA0]
000078af20be4ad9  vmovaps xmm11, [rsp+0xB0]
000078af20be4ae2  vmovaps xmm12, [rsp+0xC0]
000078af20be4aeb  vmovaps xmm13, [rsp+0xD0]
000078af20be4af4  vmovaps xmm15, [rsp+0xE0]
000078af20be4afd  add rsp, 0xF0
000078af20be4b04  pop r11
000078af20be4b06  pop r10
000078af20be4b08  pop r9
000078af20be4b0a  pop r8
000078af20be4b0c  pop rsi
000078af20be4b0d  pop rdi
000078af20be4b0e  pop rdx
000078af20be4b0f  pop rcx
000078af20be4b10  pop rax
000078af20be4b11  add rsp, 0x08
000078af20be4b15  jmp 0x000078AF20BDFA23
000078af20be4b1a  sub rsp, 0x08
000078af20be4b1e  push rax
000078af20be4b1f  push rcx
000078af20be4b20  push rdx
000078af20be4b21  push rdi
000078af20be4b22  push rsi
000078af20be4b23  push r8
000078af20be4b25  push r9
000078af20be4b27  push r10
000078af20be4b29  push r11
000078af20be4b2b  sub rsp, 0xF0
000078af20be4b32  vmovaps [rsp], xmm0
000078af20be4b37  vmovaps [rsp+0x10], xmm2
000078af20be4b3d  vmovaps [rsp+0x20], xmm3
000078af20be4b43  vmovaps [rsp+0x30], xmm4
000078af20be4b49  vmovaps [rsp+0x40], xmm5
000078af20be4b4f  vmovaps [rsp+0x50], xmm6
000078af20be4b55  vmovaps [rsp+0x60], xmm7
000078af20be4b5b  vmovaps [rsp+0x70], xmm8
000078af20be4b61  vmovaps [rsp+0x80], xmm9
000078af20be4b6a  vmovaps [rsp+0x90], xmm10
000078af20be4b73  vmovaps [rsp+0xA0], xmm11
000078af20be4b7c  vmovaps [rsp+0xB0], xmm12
000078af20be4b85  vmovaps [rsp+0xC0], xmm13
000078af20be4b8e  vmovaps [rsp+0xD0], xmm14
000078af20be4b97  vmovaps [rsp+0xE0], xmm15
000078af20be4ba0  sub rsp, 0x30
000078af20be4ba4  movaps [rsp], xmm1
000078af20be4ba8  movaps [rsp+0x10], xmm8
000078af20be4bae  movaps [rsp+0x20], xmm9
000078af20be4bb4  lea rdi, [rsp]
000078af20be4bb8  mov esi, 0x00
000078af20be4bbd  mov rax, 0x65452FFB8530
000078af20be4bc7  call rax
000078af20be4bc9  movaps xmm1, [rsp]
000078af20be4bcd  add rsp, 0x30
000078af20be4bd1  vmovaps xmm0, [rsp]
000078af20be4bd6  vmovaps xmm2, [rsp+0x10]
000078af20be4bdc  vmovaps xmm3, [rsp+0x20]
000078af20be4be2  vmovaps xmm4, [rsp+0x30]
000078af20be4be8  vmovaps xmm5, [rsp+0x40]
000078af20be4bee  vmovaps xmm6, [rsp+0x50]
000078af20be4bf4  vmovaps xmm7, [rsp+0x60]
000078af20be4bfa  vmovaps xmm8, [rsp+0x70]
000078af20be4c00  vmovaps xmm9, [rsp+0x80]
000078af20be4c09  vmovaps xmm10, [rsp+0x90]
000078af20be4c12  vmovaps xmm11, [rsp+0xA0]
000078af20be4c1b  vmovaps xmm12, [rsp+0xB0]
000078af20be4c24  vmovaps xmm13, [rsp+0xC0]
000078af20be4c2d  vmovaps xmm14, [rsp+0xD0]
000078af20be4c36  vmovaps xmm15, [rsp+0xE0]
000078af20be4c3f  add rsp, 0xF0
000078af20be4c46  pop r11
000078af20be4c48  pop r10
000078af20be4c4a  pop r9
000078af20be4c4c  pop r8
000078af20be4c4e  pop rsi
000078af20be4c4f  pop rdi
000078af20be4c50  pop rdx
000078af20be4c51  pop rcx
000078af20be4c52  pop rax
000078af20be4c53  add rsp, 0x08
000078af20be4c57  jmp 0x000078AF20BDFA45
000078af20be4c5c  call 0x000078AF20AE5940
000078af20be4c61  jmp 0x000078AF20BDFA53
000078af20be4c66  call 0x000078AF20A0C380
000078af20be4c6b  jmp 0x000078AF20BDFA5D
000078af20be4c70  call 0x000078AF20A0D600
000078af20be4c75  jmp 0x000078AF20BDFA67
000078af20be4c7a  call 0x000078AF209FF540
000078af20be4c7f  jmp 0x000078AF20BDFA71
000078af20be4c84  int3
000078af20be4c85  nop [rax+rax*1], ax
000078af20be4c8e  nop
000078af20be4c90  mov qword ptr [r15+0x40], 0x430000
000078af20be4c98  mov eax, 0x430CC0
000078af20be4c9d  mov r14, [r13+rax*1]
000078af20be4ca2  movq xmm1, r14
000078af20be4ca7  mov rax, [r15+0x50]
000078af20be4cab  movups xmm15, [r13+rax*1]
000078af20be4cb1  movaps [r15+0x120], xmm15
000078af20be4cb9  mov qword ptr [r15+0x48], 0x10
000078af20be4cc1  xor eax, eax
000078af20be4cc3  mov r14d, 0x10
000078af20be4cc9  mov r12d, 0x200
000078af20be4ccf  cmp r14, r12
000078af20be4cd2  cmc
000078af20be4cd3  lahf
000078af20be4cd4  seto al
000078af20be4cd7  mov [r15+0x108], eax
000078af20be4cde  pextrq rax, xmm15, 0x01
000078af20be4ce5  movq xmm14, rax
000078af20be4cea  movaps [r15+0x130], xmm14
000078af20be4cf2  movq rax, xmm1
000078af20be4cf7  movq r14, xmm15
000078af20be4cfc  vmovq xmm1, rax
000078af20be4d01  vmovq xmm15, r14
000078af20be4d06  movaps xmm13, xmm1
000078af20be4d0a  addsd xmm13, xmm15
000078af20be4d0f  ucomisd xmm13, xmm13
000078af20be4d14  jp 0x000078AF20BE4DD3
000078af20be4d1a  movq xmm13, xmm13
000078af20be4d1f  movq rax, xmm13
000078af20be4d24  movq r14, xmm14
000078af20be4d29  vmovq xmm1, rax
000078af20be4d2e  vmovq xmm15, r14
000078af20be4d33  movaps xmm14, xmm1
000078af20be4d37  addsd xmm14, xmm15
000078af20be4d3c  ucomisd xmm14, xmm14
000078af20be4d41  jp 0x000078AF20BE4E1B
000078af20be4d47  movq xmm14, xmm14
000078af20be4d4c  movaps [r15+0x110], xmm14
000078af20be4d54  mov eax, [r15+0x108]
000078af20be4d5b  sahf
000078af20be4d5c  jnz 0x000078AF20BE4D8E
000078af20be4d5e  cmp dword ptr [r15+0x318], 0x00
000078af20be4d66  jz 0x000078AF20BE5030
000078af20be4d6c  nop [rax+rax*1], ax
000078af20be4d75  nop [rax+rax*1], eax
000078af20be4d7d  mov eax, 0x410704
000078af20be4d82  mov [r15+0x100], rax
000078af20be4d89  jmp 0x000078AF209FE110
000078af20be4d8e  cmp dword ptr [r15+0x318], 0x00
000078af20be4d96  jz 0x000078AF20BE4E70
000078af20be4d9c  nop [rax+rax*1], ax
000078af20be4da5  nop [rax+rax*1], eax
000078af20be4dad  mov eax, 0x4106E8
000078af20be4db2  mov [r15+0x100], rax
000078af20be4db9  jmp 0x000078AF209FE110
000078af20be4dbe  int3
000078af20be4dbf  call 0x000078AF20A0DC20
000078af20be4dc4  jmp 0x000078AF20BE4CA2
000078af20be4dc9  call 0x000078AF20A0E760
000078af20be4dce  jmp 0x000078AF20BE4CB1
000078af20be4dd3  ucomisd xmm1, xmm15
000078af20be4dd8  jp 0x000078AF20BE4DE7
000078af20be4dda  movaps xmm13, [0x000078AF207FE060]
000078af20be4de2  jmp 0x000078AF20BE4D1A
000078af20be4de7  vxorps xmm0, xmm1, xmm15
000078af20be4dec  pextrw eax, xmm0, 0x03
000078af20be4df1  and eax, 0x7FF8
000078af20be4df6  cmp eax, 0x08
000078af20be4df9  jnz 0x000078AF20BE4D1A
000078af20be4dff  movq rax, xmm15
000078af20be4e04  shl rax, 0x0D
000078af20be4e08  jbe 0x000078AF20BE4D1A
000078af20be4e0e  vorps xmm13, xmm15, [0x000078AF207FE070]
000078af20be4e16  jmp 0x000078AF20BE4D1A
000078af20be4e1b  ucomisd xmm1, xmm15
000078af20be4e20  jp 0x000078AF20BE4E2F
000078af20be4e22  movaps xmm14, [0x000078AF207FE060]
000078af20be4e2a  jmp 0x000078AF20BE4D47
000078af20be4e2f  vxorps xmm0, xmm1, xmm15
000078af20be4e34  pextrw eax, xmm0, 0x03
000078af20be4e39  and eax, 0x7FF8
000078af20be4e3e  cmp eax, 0x08
000078af20be4e41  jnz 0x000078AF20BE4D47
000078af20be4e47  movq rax, xmm15
000078af20be4e4c  shl rax, 0x0D
000078af20be4e50  jbe 0x000078AF20BE4D47
000078af20be4e56  vorps xmm14, xmm15, [0x000078AF207FE070]
000078af20be4e5e  jmp 0x000078AF20BE4D47
000078af20be4e63  int3
000078af20be4e64  nop [rax+rax*1], ax
000078af20be4e6d  nop [rax], eax
000078af20be4e70  mov rax, [r15+0x48]
000078af20be4e74  mov r14, [r15+0x50]
000078af20be4e78  lea r12, [r14+rax*1]
000078af20be4e7c  movups xmm1, [r13+r12*1]
000078af20be4e82  movaps [r15+0x120], xmm1
000078af20be4e8a  lea r14, [rax+0x10]
000078af20be4e8e  mov [r15+0x48], r14
000078af20be4e92  xor eax, eax
000078af20be4e94  mov r12d, 0x200
000078af20be4e9a  cmp r14, r12
000078af20be4e9d  cmc
000078af20be4e9e  lahf
000078af20be4e9f  seto al
000078af20be4ea2  mov [r15+0x108], eax
000078af20be4ea9  pextrq rax, xmm1, 0x01
000078af20be4eb0  movq xmm15, rax
000078af20be4eb5  movaps [r15+0x130], xmm15
000078af20be4ebd  movaps xmm14, [r15+0x110]
000078af20be4ec5  movq rax, xmm14
000078af20be4eca  movq r14, xmm1
000078af20be4ecf  vmovq xmm1, rax
000078af20be4ed4  vmovq xmm14, r14
000078af20be4ed9  movaps xmm13, xmm1
000078af20be4edd  addsd xmm13, xmm14
000078af20be4ee2  ucomisd xmm13, xmm13
000078af20be4ee7  jp 0x000078AF20BE4F9C
000078af20be4eed  movq xmm13, xmm13
000078af20be4ef2  movq rax, xmm13
000078af20be4ef7  movq r14, xmm15
000078af20be4efc  vmovq xmm1, rax
000078af20be4f01  vmovq xmm15, r14
000078af20be4f06  movaps xmm14, xmm1
000078af20be4f0a  addsd xmm14, xmm15
000078af20be4f0f  ucomisd xmm14, xmm14
000078af20be4f14  jp 0x000078AF20BE4FE4
000078af20be4f1a  movq xmm14, xmm14
000078af20be4f1f  movaps [r15+0x110], xmm14
000078af20be4f27  mov eax, [r15+0x108]
000078af20be4f2e  sahf
000078af20be4f2f  jnz 0x000078AF20BE4F61
000078af20be4f31  cmp dword ptr [r15+0x318], 0x00
000078af20be4f39  jz 0x000078AF20BE5030
000078af20be4f3f  nop [rax+rax*1], ax
000078af20be4f48  nop [rax+rax*1], eax
000078af20be4f50  mov eax, 0x410704
000078af20be4f55  mov [r15+0x100], rax
000078af20be4f5c  jmp 0x000078AF209FE110
000078af20be4f61  cmp dword ptr [r15+0x318], 0x00
000078af20be4f69  jz 0x000078AF20BE4E70
000078af20be4f6f  nop [rax+rax*1], ax
000078af20be4f78  nop [rax+rax*1], eax
000078af20be4f80  mov eax, 0x4106E8
000078af20be4f85  mov [r15+0x100], rax
000078af20be4f8c  jmp 0x000078AF209FE110
000078af20be4f91  int3
000078af20be4f92  call 0x000078AF20AB52F0
000078af20be4f97  jmp 0x000078AF20BE4E82
000078af20be4f9c  ucomisd xmm1, xmm14
000078af20be4fa1  jp 0x000078AF20BE4FB0
000078af20be4fa3  movaps xmm13, [0x000078AF207FE060]
000078af20be4fab  jmp 0x000078AF20BE4EED
000078af20be4fb0  vxorps xmm0, xmm1, xmm14
000078af20be4fb5  pextrw eax, xmm0, 0x03
000078af20be4fba  and eax, 0x7FF8
000078af20be4fbf  cmp eax, 0x08
000078af20be4fc2  jnz 0x000078AF20BE4EED
000078af20be4fc8  movq rax, xmm14
000078af20be4fcd  shl rax, 0x0D
000078af20be4fd1  jbe 0x000078AF20BE4EED
000078af20be4fd7  vorps xmm13, xmm14, [0x000078AF207FE070]
000078af20be4fdf  jmp 0x000078AF20BE4EED
000078af20be4fe4  ucomisd xmm1, xmm15
000078af20be4fe9  jp 0x000078AF20BE4FF8
000078af20be4feb  movaps xmm14, [0x000078AF207FE060]
000078af20be4ff3  jmp 0x000078AF20BE4F1A
000078af20be4ff8  vxorps xmm0, xmm1, xmm15
000078af20be4ffd  pextrw eax, xmm0, 0x03
000078af20be5002  and eax, 0x7FF8
000078af20be5007  cmp eax, 0x08
000078af20be500a  jnz 0x000078AF20BE4F1A
000078af20be5010  movq rax, xmm15
000078af20be5015  shl rax, 0x0D
000078af20be5019  jbe 0x000078AF20BE4F1A
000078af20be501f  vorps xmm14, xmm15, [0x000078AF207FE070]
000078af20be5027  jmp 0x000078AF20BE4F1A
000078af20be502c  int3
000078af20be502d  nop [rax], eax
000078af20be5030  mov rax, [r15+0xF8]
000078af20be5037  lea r14, [rax+0x1D0]
000078af20be503e  mov r12, [r13+r14*1]
000078af20be5043  lea r14, [rax+0x1D8]
000078af20be504a  mov r11, [r13+r14*1]
000078af20be504f  mov [r15+0xA0], r12
000078af20be5056  mov [r15+0x98], r11
000078af20be505d  mov r14, [r15+0x40]
000078af20be5061  lea r12, [r14+0xCC0]
000078af20be5068  movaps xmm1, [r15+0x110]
000078af20be5070  movq r14, xmm1
000078af20be5075  mov [r13+r12*1], r14
000078af20be507a  lea r14, [rax+0x1C0]
000078af20be5081  mov r12, [r13+r14*1]
000078af20be5086  lea r14, [rax+0x1C8]
000078af20be508d  mov r11, [r13+r14*1]
000078af20be5092  mov [r15+0xE8], r12
000078af20be5099  mov [r15+0xF0], r11
000078af20be50a0  lea r14, [rax+0x1B0]
000078af20be50a7  mov r12, [r13+r14*1]
000078af20be50ac  lea r14, [rax+0x1B8]
000078af20be50b3  mov r10, [r13+r14*1]
000078af20be50b8  movq xmm1, r12
000078af20be50bd  movq xmm15, r10
000078af20be50c2  movq xmm1, xmm1
000078af20be50c6  movq xmm1, xmm1
000078af20be50ca  movaps [r15+0x1A0], xmm1
000078af20be50d2  movq xmm15, xmm15
000078af20be50d7  movq xmm15, xmm15
000078af20be50dc  movaps [r15+0x190], xmm15
000078af20be50e4  lea r14, [rax+0x1A0]
000078af20be50eb  mov r12, [r13+r14*1]
000078af20be50f0  lea r14, [rax+0x1A8]
000078af20be50f7  mov r10, [r13+r14*1]
000078af20be50fc  movq xmm1, r12
000078af20be5101  movq xmm15, r10
000078af20be5106  movq xmm1, xmm1
000078af20be510a  movq xmm1, xmm1
000078af20be510e  movaps [r15+0x1C0], xmm1
000078af20be5116  movq xmm15, xmm15
000078af20be511b  movq xmm15, xmm15
000078af20be5120  movaps [r15+0x1B0], xmm15
000078af20be5128  lea r14, [rax+0x190]
000078af20be512f  mov r12, [r13+r14*1]
000078af20be5134  lea r14, [rax+0x198]
000078af20be513b  mov r10, [r13+r14*1]
000078af20be5140  movq xmm1, r12
000078af20be5145  movq xmm15, r10
000078af20be514a  movq xmm1, xmm1
000078af20be514e  movq xmm1, xmm1
000078af20be5152  movaps [r15+0x1E0], xmm1
000078af20be515a  movq xmm15, xmm15
000078af20be515f  movq xmm15, xmm15
000078af20be5164  movaps [r15+0x1D0], xmm15
000078af20be516c  lea r14, [rax+0x180]
000078af20be5173  mov r12, [r13+r14*1]
000078af20be5178  lea r14, [rax+0x188]
000078af20be517f  mov r10, [r13+r14*1]
000078af20be5184  movq xmm1, r12
000078af20be5189  movq xmm15, r10
000078af20be518e  movq xmm1, xmm1
000078af20be5192  movq xmm1, xmm1
000078af20be5196  movaps [r15+0x200], xmm1
000078af20be519e  movq xmm15, xmm15
000078af20be51a3  movq xmm15, xmm15
000078af20be51a8  movaps [r15+0x1F0], xmm15
000078af20be51b0  lea r14, [rax+0x1E0]
000078af20be51b7  mov [r15+0xF8], r14
000078af20be51be  mov [r15+0x100], r11
000078af20be51c5  jmp 0x000078AF20BCE5C0
000078af20be51ca  int3
000078af20be51cb  call 0x000078AF20AE27E0
000078af20be51d0  jmp 0x000078AF20BE5043
000078af20be51d5  call 0x000078AF20AE1570
000078af20be51da  jmp 0x000078AF20BE504F
000078af20be51df  call 0x000078AF20AC3FE0
000078af20be51e4  jmp 0x000078AF20BE507A
000078af20be51e9  call 0x000078AF20AE27E0
000078af20be51ee  jmp 0x000078AF20BE5086
000078af20be51f3  call 0x000078AF20AE1570
000078af20be51f8  jmp 0x000078AF20BE5092
000078af20be51fd  call 0x000078AF20AE27E0
000078af20be5202  jmp 0x000078AF20BE50AC
000078af20be5207  call 0x000078AF20AE0300
000078af20be520c  jmp 0x000078AF20BE50B8
000078af20be5211  call 0x000078AF20AE27E0
000078af20be5216  jmp 0x000078AF20BE50F0
000078af20be521b  call 0x000078AF20AE0300
000078af20be5220  jmp 0x000078AF20BE50FC
000078af20be5225  call 0x000078AF20AE27E0
000078af20be522a  jmp 0x000078AF20BE5134
000078af20be522f  call 0x000078AF20AE0300
000078af20be5234  jmp 0x000078AF20BE5140
000078af20be5239  call 0x000078AF20AE27E0
000078af20be523e  jmp 0x000078AF20BE5178
000078af20be5243  call 0x000078AF20AE0300
000078af20be5248  jmp 0x000078AF20BE5184
000078af20be524d  int3
000078af20be524e  nop
000078af20be5250  mov qword ptr [r15+0x100], 0x04
000078af20be525b  mov esi, 0x00
000078af20be5260  mov edx, 0x09
000078af20be5265  mov rdi, 0x7FFC40B8D700
000078af20be526f  mov rax, 0x65452FE4B970
000078af20be5279  call rax
000078af20be527b  cmp dword ptr [r15+0x318], 0x00
000078af20be5283  jnz 0x000078AF209FE110
000078af20be5289  jmp 0x000078AF209FE0A0
000078af20be528e  int3
000078af20be528f  int3
