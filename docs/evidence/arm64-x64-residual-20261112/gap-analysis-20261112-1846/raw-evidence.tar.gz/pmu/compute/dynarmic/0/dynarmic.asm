0000710e9ebce69b  nop [rax+rax*1], eax
0000710e9ebce6a0  mov rax, [r15+0xF8]
0000710e9ebce6a7  lea r14, [rax-0x1E0]
0000710e9ebce6ae  mov [r15+0xF8], r14
0000710e9ebce6b5  lea rax, [r14+0x1D0]
0000710e9ebce6bc  mov r12, [r15+0xA0]
0000710e9ebce6c3  mov r11, [r15+0x98]
0000710e9ebce6ca  mov [r13+rax*1], r12
0000710e9ebce6cf  lea rax, [r14+0x1D8]
0000710e9ebce6d6  mov [r13+rax*1], r11
0000710e9ebce6db  mov eax, 0x420AA0
0000710e9ebce6e0  movups xmm1, [r13+rax*1]
0000710e9ebce6e6  mov eax, 0x420A30
0000710e9ebce6eb  movups xmm15, [r13+rax*1]
0000710e9ebce6f1  mov eax, 0x420AC0
0000710e9ebce6f6  movups xmm14, [r13+rax*1]
0000710e9ebce6fc  mov eax, 0x420A60
0000710e9ebce701  movups xmm13, [r13+rax*1]
0000710e9ebce707  mov qword ptr [r15+0x98], 0x430CD0
0000710e9ebce712  mov eax, 0x420AD0
0000710e9ebce717  movups xmm12, [r13+rax*1]
0000710e9ebce71d  mov eax, 0x430CD0
0000710e9ebce722  movups [r13+rax*1], xmm1
0000710e9ebce728  mov eax, 0x430CE0
0000710e9ebce72d  movups [r13+rax*1], xmm15
0000710e9ebce733  mov eax, 0x430CF0
0000710e9ebce738  movups [r13+rax*1], xmm14
0000710e9ebce73e  mov eax, 0x430D00
0000710e9ebce743  movups [r13+rax*1], xmm13
0000710e9ebce749  mov eax, 0x420A20
0000710e9ebce74e  movups xmm14, [r13+rax*1]
0000710e9ebce754  mov eax, 0x420A10
0000710e9ebce759  movups xmm13, [r13+rax*1]
0000710e9ebce75f  mov eax, 0x430DD0
0000710e9ebce764  movups [r13+rax*1], xmm1
0000710e9ebce76a  mov eax, 0x430DE0
0000710e9ebce76f  movups [r13+rax*1], xmm15
0000710e9ebce775  mov eax, 0x430D10
0000710e9ebce77a  movups [r13+rax*1], xmm12
0000710e9ebce780  mov eax, 0x430D20
0000710e9ebce785  movups [r13+rax*1], xmm14
0000710e9ebce78b  mov eax, 0x420A00
0000710e9ebce790  movups xmm1, [r13+rax*1]
0000710e9ebce796  mov eax, 0x420A70
0000710e9ebce79b  movups xmm15, [r13+rax*1]
0000710e9ebce7a1  mov eax, 0x430D30
0000710e9ebce7a6  movups [r13+rax*1], xmm13
0000710e9ebce7ac  mov eax, 0x430D40
0000710e9ebce7b1  movups [r13+rax*1], xmm1
0000710e9ebce7b7  mov eax, 0x420A80
0000710e9ebce7bc  movups xmm1, [r13+rax*1]
0000710e9ebce7c2  mov eax, 0x420A50
0000710e9ebce7c7  movups xmm14, [r13+rax*1]
0000710e9ebce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
0000710e9ebce7d5  mov eax, 0x430D50
0000710e9ebce7da  movups [r13+rax*1], xmm15
0000710e9ebce7e0  mov eax, 0x430D60
0000710e9ebce7e5  movups [r13+rax*1], xmm1
0000710e9ebce7eb  mov eax, 0x420AF0
0000710e9ebce7f0  movups xmm1, [r13+rax*1]
0000710e9ebce7f6  mov eax, 0x420B00
0000710e9ebce7fb  movups xmm15, [r13+rax*1]
0000710e9ebce801  movaps [r15+0x150], xmm15
0000710e9ebce809  mov qword ptr [r15+0xA0], 0x3E8
0000710e9ebce814  mov eax, 0x430D70
0000710e9ebce819  movups [r13+rax*1], xmm14
0000710e9ebce81f  mov eax, 0x430D80
0000710e9ebce824  movups [r13+rax*1], xmm1
0000710e9ebce82a  mov eax, 0x420AE0
0000710e9ebce82f  movups xmm1, [r13+rax*1]
0000710e9ebce835  mov eax, 0x420A90
0000710e9ebce83a  movups xmm14, [r13+rax*1]
0000710e9ebce840  movaps [r15+0x140], xmm14
0000710e9ebce848  lea rax, [r14+0x180]
0000710e9ebce84f  movq xmm13, qword ptr [r15+0x200]
0000710e9ebce858  movq xmm12, qword ptr [r15+0x1F0]
0000710e9ebce861  movq r12, xmm13
0000710e9ebce866  movq r11, xmm12
0000710e9ebce86b  mov [r13+rax*1], r12
0000710e9ebce870  lea rax, [r14+0x188]
0000710e9ebce877  mov [r13+rax*1], r11
0000710e9ebce87c  mov eax, 0x430D90
0000710e9ebce881  movups [r13+rax*1], xmm15
0000710e9ebce887  mov eax, 0x430DA0
0000710e9ebce88c  movups [r13+rax*1], xmm1
0000710e9ebce892  mov eax, 0x420AB0
0000710e9ebce897  movups xmm1, [r13+rax*1]
0000710e9ebce89d  mov eax, 0x420B18
0000710e9ebce8a2  mov r12, [r13+rax*1]
0000710e9ebce8a7  movq xmm15, r12
0000710e9ebce8ac  mov qword ptr [r15+0x40], 0x420B20
0000710e9ebce8b4  mov eax, 0x430DB0
0000710e9ebce8b9  movups [r13+rax*1], xmm14
0000710e9ebce8bf  mov eax, 0x430DC0
0000710e9ebce8c4  movups [r13+rax*1], xmm1
0000710e9ebce8ca  mov eax, 0x420B80
0000710e9ebce8cf  movups xmm1, [r13+rax*1]
0000710e9ebce8d5  movq rax, xmm15
0000710e9ebce8da  mov r12d, 0x430DF0
0000710e9ebce8e0  mov [r13+r12*1], rax
0000710e9ebce8e5  mov eax, 0x420B60
0000710e9ebce8ea  movups xmm15, [r13+rax*1]
0000710e9ebce8f0  mov eax, 0x420B70
0000710e9ebce8f5  movups xmm14, [r13+rax*1]
0000710e9ebce8fb  lea rax, [r14+0x160]
0000710e9ebce902  movups [r13+rax*1], xmm1
0000710e9ebce908  lea rax, [r14+0x190]
0000710e9ebce90f  movq xmm1, qword ptr [r15+0x1E0]
0000710e9ebce918  movq xmm13, qword ptr [r15+0x1D0]
0000710e9ebce921  movq r12, xmm1
0000710e9ebce926  movq r11, xmm13
0000710e9ebce92b  mov [r13+rax*1], r12
0000710e9ebce930  lea rax, [r14+0x198]
0000710e9ebce937  mov [r13+rax*1], r11
0000710e9ebce93c  lea rax, [r14+0x140]
0000710e9ebce943  movups [r13+rax*1], xmm15
0000710e9ebce949  lea rax, [r14+0x150]
0000710e9ebce950  movups [r13+rax*1], xmm14
0000710e9ebce956  mov eax, 0x420B20
0000710e9ebce95b  movups xmm1, [r13+rax*1]
0000710e9ebce961  mov eax, 0x420B30
0000710e9ebce966  movups xmm15, [r13+rax*1]
0000710e9ebce96c  movaps [r15+0x120], xmm15
0000710e9ebce974  lea rax, [r14+0x1A0]
0000710e9ebce97b  movq xmm14, qword ptr [r15+0x1C0]
0000710e9ebce984  movq xmm13, qword ptr [r15+0x1B0]
0000710e9ebce98d  movq r12, xmm14
0000710e9ebce992  movq r11, xmm13
0000710e9ebce997  mov [r13+rax*1], r12
0000710e9ebce99c  lea rax, [r14+0x1A8]
0000710e9ebce9a3  mov [r13+rax*1], r11
0000710e9ebce9a8  lea rax, [r14+0x1B0]
0000710e9ebce9af  movq xmm14, qword ptr [r15+0x1A0]
0000710e9ebce9b8  movq xmm13, qword ptr [r15+0x190]
0000710e9ebce9c1  movq r12, xmm14
0000710e9ebce9c6  movq r11, xmm13
0000710e9ebce9cb  mov [r13+rax*1], r12
0000710e9ebce9d0  lea rax, [r14+0x1B8]
0000710e9ebce9d7  mov [r13+rax*1], r11
0000710e9ebce9dc  lea rax, [r14+0x100]
0000710e9ebce9e3  movups [r13+rax*1], xmm1
0000710e9ebce9e9  lea rax, [r14+0x110]
0000710e9ebce9f0  movups [r13+rax*1], xmm15
0000710e9ebce9f6  mov eax, 0x420B40
0000710e9ebce9fb  movups xmm1, [r13+rax*1]
0000710e9ebcea01  mov eax, 0x420B50
0000710e9ebcea06  movups xmm15, [r13+rax*1]
0000710e9ebcea0c  movaps [r15+0x110], xmm1
0000710e9ebcea14  movaps [r15+0x130], xmm15
0000710e9ebcea1c  lea rax, [r14+0x1C0]
0000710e9ebcea23  mov r12, [r15+0xE8]
0000710e9ebcea2a  mov r11, [r15+0xF0]
0000710e9ebcea31  mov [r13+rax*1], r12
0000710e9ebcea36  lea rax, [r14+0x1C8]
0000710e9ebcea3d  mov [r13+rax*1], r11
0000710e9ebcea42  mov eax, 0x430DF8
0000710e9ebcea47  mov r12d, 0x421DF8D3
0000710e9ebcea4d  mov [r13+rax*1], r12d
0000710e9ebcea52  lea rax, [r14+0x120]
0000710e9ebcea59  movups [r13+rax*1], xmm1
0000710e9ebcea5f  lea rax, [r14+0x130]
0000710e9ebcea66  movups [r13+rax*1], xmm15
0000710e9ebcea6c  lea rax, [r14+0x100]
0000710e9ebcea73  mov [r15], rax
0000710e9ebcea76  mov qword ptr [r15+0x08], 0x430CD0
0000710e9ebcea7e  mov qword ptr [r15+0x10], 0x12C
0000710e9ebcea86  mov qword ptr [r15+0xF0], 0x410284
0000710e9ebcea91  mov r14d, [r15+0x320]
0000710e9ebcea98  mov eax, 0x410284
0000710e9ebcea9d  mov rcx, 0x710E9EBD07C0
0000710e9ebceaa7  mov [r15+r14*8+0x328], rax
0000710e9ebceaaf  mov [r15+r14*8+0x368], rcx
0000710e9ebceab7  add r14d, 0x01
0000710e9ebceabb  and r14d, 0x07
0000710e9ebceabf  mov [r15+0x320], r14d
0000710e9ebceac6  cmp dword ptr [r15+0x318], 0x00
0000710e9ebceace  jz 0x0000710E9EBCED70
0000710e9ebcead4  nop [rax+rax*1], ax
0000710e9ebceadd  nop [rax+rax*1], eax
0000710e9ebceae5  mov eax, 0x410728
0000710e9ebceaea  mov [r15+0x100], rax
0000710e9ebceaf1  jmp 0x0000710E9E9FE110
0000710e9ebceaf6  int3
0000710e9ebceaf7  call 0x0000710E9EA0BC20
0000710e9ebceafc  jmp 0x0000710E9EBCE6CF
0000710e9ebceb01  call 0x0000710E9EA0A9A0
0000710e9ebceb06  jmp 0x0000710E9EBCE6DB
0000710e9ebceb0b  call 0x0000710E9E9FF430
0000710e9ebceb10  jmp 0x0000710E9EBCE6E6
0000710e9ebceb15  call 0x0000710E9EA0E760
0000710e9ebceb1a  jmp 0x0000710E9EBCE6F1
0000710e9ebceb1f  call 0x0000710E9EA0D4E0
0000710e9ebceb24  jmp 0x0000710E9EBCE6FC
0000710e9ebceb29  call 0x0000710E9EA0C260
0000710e9ebceb2e  jmp 0x0000710E9EBCE707
0000710e9ebceb33  call 0x0000710E9EA0AFE0
0000710e9ebceb38  jmp 0x0000710E9EBCE71D
0000710e9ebceb3d  call 0x0000710E9E9FF540
0000710e9ebceb42  jmp 0x0000710E9EBCE728
0000710e9ebceb47  call 0x0000710E9EA0E880
0000710e9ebceb4c  jmp 0x0000710E9EBCE733
0000710e9ebceb51  call 0x0000710E9EA0D600
0000710e9ebceb56  jmp 0x0000710E9EBCE73E
0000710e9ebceb5b  call 0x0000710E9EA0C380
0000710e9ebceb60  jmp 0x0000710E9EBCE749
0000710e9ebceb65  call 0x0000710E9EA0D4E0
0000710e9ebceb6a  jmp 0x0000710E9EBCE754
0000710e9ebceb6f  call 0x0000710E9EA0C260
0000710e9ebceb74  jmp 0x0000710E9EBCE75F
0000710e9ebceb79  call 0x0000710E9E9FF540
0000710e9ebceb7e  jmp 0x0000710E9EBCE76A
0000710e9ebceb83  call 0x0000710E9EA0E880
0000710e9ebceb88  jmp 0x0000710E9EBCE775
0000710e9ebceb8d  call 0x0000710E9EA0B100
0000710e9ebceb92  jmp 0x0000710E9EBCE780
0000710e9ebceb97  call 0x0000710E9EA0D600
0000710e9ebceb9c  jmp 0x0000710E9EBCE78B
0000710e9ebceba1  call 0x0000710E9E9FF430
0000710e9ebceba6  jmp 0x0000710E9EBCE796
0000710e9ebcebab  call 0x0000710E9EA0E760
0000710e9ebcebb0  jmp 0x0000710E9EBCE7A1
0000710e9ebcebb5  call 0x0000710E9EA0C380
0000710e9ebcebba  jmp 0x0000710E9EBCE7AC
0000710e9ebcebbf  call 0x0000710E9E9FF540
0000710e9ebcebc4  jmp 0x0000710E9EBCE7B7
0000710e9ebcebc9  call 0x0000710E9E9FF430
0000710e9ebcebce  jmp 0x0000710E9EBCE7C2
0000710e9ebcebd3  call 0x0000710E9EA0D4E0
0000710e9ebcebd8  jmp 0x0000710E9EBCE7CD
0000710e9ebcebdd  call 0x0000710E9EA0E880
0000710e9ebcebe2  jmp 0x0000710E9EBCE7E0
0000710e9ebcebe7  call 0x0000710E9E9FF540
0000710e9ebcebec  jmp 0x0000710E9EBCE7EB
0000710e9ebcebf1  call 0x0000710E9E9FF430
0000710e9ebcebf6  jmp 0x0000710E9EBCE7F6
0000710e9ebcebfb  call 0x0000710E9EA0E760
0000710e9ebcec00  jmp 0x0000710E9EBCE801
0000710e9ebcec05  call 0x0000710E9EA0D600
0000710e9ebcec0a  jmp 0x0000710E9EBCE81F
0000710e9ebcec0f  call 0x0000710E9E9FF540
0000710e9ebcec14  jmp 0x0000710E9EBCE82A
0000710e9ebcec19  call 0x0000710E9E9FF430
0000710e9ebcec1e  jmp 0x0000710E9EBCE835
0000710e9ebcec23  call 0x0000710E9EA0D4E0
0000710e9ebcec28  jmp 0x0000710E9EBCE840
0000710e9ebcec2d  call 0x0000710E9EA0BC20
0000710e9ebcec32  jmp 0x0000710E9EBCE870
0000710e9ebcec37  call 0x0000710E9EA0A9A0
0000710e9ebcec3c  jmp 0x0000710E9EBCE87C
0000710e9ebcec41  call 0x0000710E9EA0E880
0000710e9ebcec46  jmp 0x0000710E9EBCE887
0000710e9ebcec4b  call 0x0000710E9E9FF540
0000710e9ebcec50  jmp 0x0000710E9EBCE892
0000710e9ebcec55  call 0x0000710E9E9FF430
0000710e9ebcec5a  jmp 0x0000710E9EBCE89D
0000710e9ebcec5f  call 0x0000710E9EA0B720
0000710e9ebcec64  jmp 0x0000710E9EBCE8A7
0000710e9ebcec69  call 0x0000710E9EA0D600
0000710e9ebcec6e  jmp 0x0000710E9EBCE8BF
0000710e9ebcec73  call 0x0000710E9E9FF540
0000710e9ebcec78  jmp 0x0000710E9EBCE8CA
0000710e9ebcec7d  call 0x0000710E9E9FF430
0000710e9ebcec82  jmp 0x0000710E9EBCE8D5
0000710e9ebcec87  call 0x0000710E9EAB4CB0
0000710e9ebcec8c  jmp 0x0000710E9EBCE8E5
0000710e9ebcec91  call 0x0000710E9EA0E760
0000710e9ebcec96  jmp 0x0000710E9EBCE8F0
0000710e9ebcec9b  call 0x0000710E9EA0D4E0
0000710e9ebceca0  jmp 0x0000710E9EBCE8FB
0000710e9ebceca5  call 0x0000710E9E9FF540
0000710e9ebcecaa  jmp 0x0000710E9EBCE908
0000710e9ebcecaf  call 0x0000710E9EA0BC20
0000710e9ebcecb4  jmp 0x0000710E9EBCE930
0000710e9ebcecb9  call 0x0000710E9EA0A9A0
0000710e9ebcecbe  jmp 0x0000710E9EBCE93C
0000710e9ebcecc3  call 0x0000710E9EA0E880
0000710e9ebcecc8  jmp 0x0000710E9EBCE949
0000710e9ebceccd  call 0x0000710E9EA0D600
0000710e9ebcecd2  jmp 0x0000710E9EBCE956
0000710e9ebcecd7  call 0x0000710E9E9FF430
0000710e9ebcecdc  jmp 0x0000710E9EBCE961
0000710e9ebcece1  call 0x0000710E9EA0E760
0000710e9ebcece6  jmp 0x0000710E9EBCE96C
0000710e9ebceceb  call 0x0000710E9EA0BC20
0000710e9ebcecf0  jmp 0x0000710E9EBCE99C
0000710e9ebcecf5  call 0x0000710E9EA0A9A0
0000710e9ebcecfa  jmp 0x0000710E9EBCE9A8
0000710e9ebcecff  call 0x0000710E9EA0BC20
0000710e9ebced04  jmp 0x0000710E9EBCE9D0
0000710e9ebced09  call 0x0000710E9EA0A9A0
0000710e9ebced0e  jmp 0x0000710E9EBCE9DC
0000710e9ebced13  call 0x0000710E9E9FF540
0000710e9ebced18  jmp 0x0000710E9EBCE9E9
0000710e9ebced1d  call 0x0000710E9EA0E880
0000710e9ebced22  jmp 0x0000710E9EBCE9F6
0000710e9ebced27  call 0x0000710E9E9FF430
0000710e9ebced2c  jmp 0x0000710E9EBCEA01
0000710e9ebced31  call 0x0000710E9EA0E760
0000710e9ebced36  jmp 0x0000710E9EBCEA0C
0000710e9ebced3b  call 0x0000710E9EA0BC20
0000710e9ebced40  jmp 0x0000710E9EBCEA36
0000710e9ebced45  call 0x0000710E9EA0A9A0
0000710e9ebced4a  jmp 0x0000710E9EBCEA42
0000710e9ebced4f  call 0x0000710E9EA0BAE0
0000710e9ebced54  jmp 0x0000710E9EBCEA52
0000710e9ebced59  call 0x0000710E9E9FF540
0000710e9ebced5e  jmp 0x0000710E9EBCEA5F
0000710e9ebced63  call 0x0000710E9EA0E880
0000710e9ebced68  jmp 0x0000710E9EBCEA6C
0000710e9ebced6d  int3
0000710e9ebced6e  nop
0000710e9ebced70  mov rax, [r15]
0000710e9ebced73  lea r14, [rax+0x20]
0000710e9ebced77  mov r12, [r13+r14*1]
0000710e9ebced7c  mov r14, [r15+0x10]
0000710e9ebced80  lea r11, [r12+r14*1]
0000710e9ebced84  mov [r15+0x40], r11
0000710e9ebced88  lea r12, [rax+0x20]
0000710e9ebced8c  mov [r13+r12*1], r11
0000710e9ebced91  test r14, r14
0000710e9ebced94  setz r14b
0000710e9ebced98  movzx r14, r14b
0000710e9ebced9c  mov [rsp+0x414], r14b
0000710e9ebceda4  cmp byte ptr [rsp+0x414], 0x00
0000710e9ebcedac  jz 0x0000710E9EBCEDDE
0000710e9ebcedae  cmp dword ptr [r15+0x318], 0x00
0000710e9ebcedb6  mov eax, 0x4109A0
0000710e9ebcedbb  mov [r15+0x100], rax
0000710e9ebcedc2  jz 0x0000710E9E9FE0A0
0000710e9ebcedc8  nop [rax+rax*1], eax
0000710e9ebcedcd  mov eax, 0x4109A0
0000710e9ebcedd2  mov [r15+0x100], rax
0000710e9ebcedd9  jmp 0x0000710E9E9FE110
0000710e9ebcedde  cmp dword ptr [r15+0x318], 0x00
0000710e9ebcede6  jz 0x0000710E9EBCEE30
0000710e9ebcedec  nop [rax+rax*1], ax
0000710e9ebcedf5  nop [rax+rax*1], eax
0000710e9ebcedfd  mov eax, 0x410738
0000710e9ebcee02  mov [r15+0x100], rax
0000710e9ebcee09  jmp 0x0000710E9E9FE110
0000710e9ebcee0e  int3
0000710e9ebcee0f  call 0x0000710E9EAE27E0
0000710e9ebcee14  jmp 0x0000710E9EBCED7C
0000710e9ebcee19  call 0x0000710E9EAC0860
0000710e9ebcee1e  jmp 0x0000710E9EBCED91
0000710e9ebcee23  int3
0000710e9ebcee24  nop [rax+rax*1], ax
0000710e9ebcee2d  nop [rax], eax
0000710e9ebcee30  mov rax, [r15+0xF8]
0000710e9ebcee37  lea r14, [rax-0x150]
0000710e9ebcee3e  mov [r15+0xF8], r14
0000710e9ebcee45  mov rax, [r15]
0000710e9ebcee48  lea r12, [rax+0x68]
0000710e9ebcee4c  mov r11, [r13+r12*1]
0000710e9ebcee51  mov [r15+0x88], r11
0000710e9ebcee58  lea r12, [rax+0x28]
0000710e9ebcee5c  mov [r15+0x40], r12
0000710e9ebcee60  mov [r15+0x48], r14
0000710e9ebcee64  mov qword ptr [r15+0x50], 0x420B90
0000710e9ebcee6c  lea rax, [r14+0x100]
0000710e9ebcee73  mov r12, [r15+0xE8]
0000710e9ebcee7a  mov r11, [r15+0xD8]
0000710e9ebcee81  mov [r13+rax*1], r12
0000710e9ebcee86  lea rax, [r14+0x108]
0000710e9ebcee8d  mov [r13+rax*1], r11
0000710e9ebcee92  lea rax, [r14+0x110]
0000710e9ebcee99  mov r12, [r15+0xD0]
0000710e9ebceea0  mov r11, [r15+0xC8]
0000710e9ebceea7  mov [r13+rax*1], r12
0000710e9ebceeac  lea rax, [r14+0x118]
0000710e9ebceeb3  mov [r13+rax*1], r11
0000710e9ebceeb8  lea rax, [r14+0x120]
0000710e9ebceebf  mov r12, [r15+0xC0]
0000710e9ebceec6  mov r11, [r15+0xB8]
0000710e9ebceecd  mov [r13+rax*1], r12
0000710e9ebceed2  lea rax, [r14+0x128]
0000710e9ebceed9  mov [r13+rax*1], r11
0000710e9ebceede  lea rax, [r14+0x130]
0000710e9ebceee5  mov r12, [r15+0xB0]
0000710e9ebceeec  mov r11, [r15+0xA8]
0000710e9ebceef3  mov [r13+rax*1], r12
0000710e9ebceef8  lea rax, [r14+0x138]
0000710e9ebceeff  mov [r13+rax*1], r11
0000710e9ebcef04  lea rax, [r14+0x140]
0000710e9ebcef0b  mov r12, [r15+0xA0]
0000710e9ebcef12  mov r11, [r15+0x98]
0000710e9ebcef19  mov [r13+rax*1], r12
0000710e9ebcef1e  lea rax, [r14+0x148]
0000710e9ebcef25  mov [r13+rax*1], r11
0000710e9ebcef2a  cmp dword ptr [r15+0x318], 0x00
0000710e9ebcef32  jz 0x0000710E9EBCEFD0
0000710e9ebcef38  nop [rax+rax*1], ax
0000710e9ebcef41  nop [rax+rax*1], eax
0000710e9ebcef49  mov eax, 0x410770
0000710e9ebcef4e  mov [r15+0x100], rax
0000710e9ebcef55  jmp 0x0000710E9E9FE110
0000710e9ebcef5a  int3
0000710e9ebcef5b  call 0x0000710E9EAC0370
0000710e9ebcef60  jmp 0x0000710E9EBCEE51
0000710e9ebcef65  call 0x0000710E9EA0BC20
0000710e9ebcef6a  jmp 0x0000710E9EBCEE86
0000710e9ebcef6f  call 0x0000710E9EA0A9A0
0000710e9ebcef74  jmp 0x0000710E9EBCEE92
0000710e9ebcef79  call 0x0000710E9EA0BC20
0000710e9ebcef7e  jmp 0x0000710E9EBCEEAC
0000710e9ebcef83  call 0x0000710E9EA0A9A0
0000710e9ebcef88  jmp 0x0000710E9EBCEEB8
0000710e9ebcef8d  call 0x0000710E9EA0BC20
0000710e9ebcef92  jmp 0x0000710E9EBCEED2
0000710e9ebcef97  call 0x0000710E9EA0A9A0
0000710e9ebcef9c  jmp 0x0000710E9EBCEEDE
0000710e9ebcefa1  call 0x0000710E9EA0BC20
0000710e9ebcefa6  jmp 0x0000710E9EBCEEF8
0000710e9ebcefab  call 0x0000710E9EA0A9A0
0000710e9ebcefb0  jmp 0x0000710E9EBCEF04
0000710e9ebcefb5  call 0x0000710E9EA0BC20
0000710e9ebcefba  jmp 0x0000710E9EBCEF1E
0000710e9ebcefbf  call 0x0000710E9EA0A9A0
0000710e9ebcefc4  jmp 0x0000710E9EBCEF2A
0000710e9ebcefc9  int3
0000710e9ebcefca  nop [rax+rax*1], ax
0000710e9ebcefd0  mov rax, [r15+0x08]
0000710e9ebcefd4  movzx r14d, byte ptr [r13+rax*1]
0000710e9ebcefda  movzx r14d, r14b
0000710e9ebcefde  mov [rsp+0x10], r14d
0000710e9ebcefe3  mov r14d, r14d
0000710e9ebcefe6  mov [r15+0x58], r14
0000710e9ebcefea  lea r14, [rax+0x01]
0000710e9ebcefee  mov [r15+0x08], r14
0000710e9ebceff2  mov rax, [r15+0x88]
0000710e9ebceff9  lea r14, [rax+0x01]
0000710e9ebceffd  mov r12, [r15]
0000710e9ebcf000  lea r11, [r12+0x68]
0000710e9ebcf005  mov [r13+r11*1], r14
0000710e9ebcf00a  lea r14, [r12+rax*1]
0000710e9ebcf00e  mov [r15+0x60], r14
0000710e9ebcf012  lea rax, [r14+0x28]
0000710e9ebcf016  mov r11d, [rsp+0x10]
0000710e9ebcf01b  movzx r14d, r11b
0000710e9ebcf01f  mov [r13+rax*1], r14b
0000710e9ebcf024  lea rax, [r12+0x68]
0000710e9ebcf029  mov r14, [r13+rax*1]
0000710e9ebcf02e  mov [r15+0x88], r14
0000710e9ebcf035  xor eax, eax
0000710e9ebcf037  mov r12d, 0x40
0000710e9ebcf03d  cmp r14, r12
0000710e9ebcf040  cmc
0000710e9ebcf041  lahf
0000710e9ebcf042  seto al
0000710e9ebcf045  mov [r15+0x108], eax
0000710e9ebcf04c  mov eax, [r15+0x108]
0000710e9ebcf053  sahf
0000710e9ebcf054  jnz 0x0000710E9EBCF086
0000710e9ebcf056  cmp dword ptr [r15+0x318], 0x00
0000710e9ebcf05e  jz 0x0000710E9EBCF170
0000710e9ebcf064  nop [rax+rax*1], ax
0000710e9ebcf06d  nop [rax+rax*1], eax
0000710e9ebcf075  mov eax, 0x410790
0000710e9ebcf07a  mov [r15+0x100], rax
0000710e9ebcf081  jmp 0x0000710E9E9FE110
0000710e9ebcf086  cmp dword ptr [r15+0x318], 0x00
0000710e9ebcf08e  jz 0x0000710E9EBCF0E0
0000710e9ebcf094  nop [rax+rax*1], ax
0000710e9ebcf09d  nop [rax+rax*1], eax
0000710e9ebcf0a5  mov eax, 0x410768
0000710e9ebcf0aa  mov [r15+0x100], rax
0000710e9ebcf0b1  jmp 0x0000710E9E9FE110
0000710e9ebcf0b6  int3
0000710e9ebcf0b7  call 0x0000710E9EA0D860
0000710e9ebcf0bc  jmp 0x0000710E9EBCEFDA
0000710e9ebcf0c1  call 0x0000710E9EAB36E0
0000710e9ebcf0c6  jmp 0x0000710E9EBCF00A
0000710e9ebcf0cb  call 0x0000710E9EA0DD60
0000710e9ebcf0d0  jmp 0x0000710E9EBCF024
0000710e9ebcf0d5  call 0x0000710E9EA0DC20
0000710e9ebcf0da  jmp 0x0000710E9EBCF02E
0000710e9ebcf0df  int3
0000710e9ebcf0e0  mov rax, [r15+0x10]
0000710e9ebcf0e4  lea r14, [rax-0x01]
0000710e9ebcf0e8  mov [r15+0x10], r14
0000710e9ebcf0ec  test r14, r14
0000710e9ebcf0ef  setz r14b
0000710e9ebcf0f3  movzx r14, r14b
0000710e9ebcf0f7  mov [rsp+0x414], r14b
0000710e9ebcf0ff  cmp byte ptr [rsp+0x414], 0x00
0000710e9ebcf107  jz 0x0000710E9EBCF139
0000710e9ebcf109  cmp dword ptr [r15+0x318], 0x00
0000710e9ebcf111  jz 0x0000710E9EBD0670
0000710e9ebcf117  nop [rax+rax*1], ax
0000710e9ebcf120  nop [rax+rax*1], eax
0000710e9ebcf128  mov eax, 0x410988
0000710e9ebcf12d  mov [r15+0x100], rax
0000710e9ebcf134  jmp 0x0000710E9E9FE110
0000710e9ebcf139  cmp dword ptr [r15+0x318], 0x00
0000710e9ebcf141  jz 0x0000710E9EBCEFD0
0000710e9ebcf147  nop [rax+rax*1], ax
0000710e9ebcf150  nop [rax+rax*1], eax
0000710e9ebcf158  mov eax, 0x410770
0000710e9ebcf15d  mov [r15+0x100], rax
0000710e9ebcf164  jmp 0x0000710E9E9FE110
0000710e9ebcf169  int3
0000710e9ebcf16a  int3
0000710e9ebcf16b  nop [rax+rax*1], eax
0000710e9ebcf170  mov rax, [r15+0x40]
0000710e9ebcf174  movzx r14d, byte ptr [r13+rax*1]
0000710e9ebcf17a  movaps xmm1, [r15+0x110]
0000710e9ebcf182  pinsrb xmm1, r14d, 0x00
0000710e9ebcf189  lea r14, [rax+0x01]
0000710e9ebcf18d  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf193  movaps xmm15, [r15+0x120]
0000710e9ebcf19b  pinsrb xmm15, r12d, 0x00
0000710e9ebcf1a2  lea r14, [rax+0x02]
0000710e9ebcf1a6  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf1ac  movaps xmm14, [r15+0x130]
0000710e9ebcf1b4  pinsrb xmm14, r12d, 0x00
0000710e9ebcf1bb  lea r14, [rax+0x03]
0000710e9ebcf1bf  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf1c5  movaps xmm13, [r15+0x140]
0000710e9ebcf1cd  pinsrb xmm13, r12d, 0x00
0000710e9ebcf1d4  lea r14, [rax+0x04]
0000710e9ebcf1d8  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf1de  pinsrb xmm1, r12d, 0x01
0000710e9ebcf1e5  lea r14, [rax+0x05]
0000710e9ebcf1e9  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf1ef  pinsrb xmm15, r12d, 0x01
0000710e9ebcf1f6  lea r14, [rax+0x06]
0000710e9ebcf1fa  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf200  pinsrb xmm14, r12d, 0x01
0000710e9ebcf207  lea r14, [rax+0x07]
0000710e9ebcf20b  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf211  pinsrb xmm13, r12d, 0x01
0000710e9ebcf218  lea r14, [rax+0x08]
0000710e9ebcf21c  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf222  pinsrb xmm1, r12d, 0x02
0000710e9ebcf229  lea r14, [rax+0x09]
0000710e9ebcf22d  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf233  pinsrb xmm15, r12d, 0x02
0000710e9ebcf23a  lea r14, [rax+0x0A]
0000710e9ebcf23e  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf244  pinsrb xmm14, r12d, 0x02
0000710e9ebcf24b  lea r14, [rax+0x0B]
0000710e9ebcf24f  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf255  pinsrb xmm13, r12d, 0x02
0000710e9ebcf25c  lea r14, [rax+0x0C]
0000710e9ebcf260  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf266  pinsrb xmm1, r12d, 0x03
0000710e9ebcf26d  lea r14, [rax+0x0D]
0000710e9ebcf271  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf277  pinsrb xmm15, r12d, 0x03
0000710e9ebcf27e  lea r14, [rax+0x0E]
0000710e9ebcf282  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf288  pinsrb xmm14, r12d, 0x03
0000710e9ebcf28f  lea r14, [rax+0x0F]
0000710e9ebcf293  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf299  pinsrb xmm13, r12d, 0x03
0000710e9ebcf2a0  lea r14, [rax+0x10]
0000710e9ebcf2a4  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf2aa  pinsrb xmm1, r12d, 0x04
0000710e9ebcf2b1  lea r14, [rax+0x11]
0000710e9ebcf2b5  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf2bb  pinsrb xmm15, r12d, 0x04
0000710e9ebcf2c2  lea r14, [rax+0x12]
0000710e9ebcf2c6  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf2cc  pinsrb xmm14, r12d, 0x04
0000710e9ebcf2d3  lea r14, [rax+0x13]
0000710e9ebcf2d7  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf2dd  pinsrb xmm13, r12d, 0x04
0000710e9ebcf2e4  lea r14, [rax+0x14]
0000710e9ebcf2e8  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf2ee  pinsrb xmm1, r12d, 0x05
0000710e9ebcf2f5  lea r14, [rax+0x15]
0000710e9ebcf2f9  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf2ff  pinsrb xmm15, r12d, 0x05
0000710e9ebcf306  lea r14, [rax+0x16]
0000710e9ebcf30a  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf310  pinsrb xmm14, r12d, 0x05
0000710e9ebcf317  lea r14, [rax+0x17]
0000710e9ebcf31b  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf321  pinsrb xmm13, r12d, 0x05
0000710e9ebcf328  lea r14, [rax+0x18]
0000710e9ebcf32c  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf332  pinsrb xmm1, r12d, 0x06
0000710e9ebcf339  lea r14, [rax+0x19]
0000710e9ebcf33d  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf343  pinsrb xmm15, r12d, 0x06
0000710e9ebcf34a  lea r14, [rax+0x1A]
0000710e9ebcf34e  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf354  pinsrb xmm14, r12d, 0x06
0000710e9ebcf35b  lea r14, [rax+0x1B]
0000710e9ebcf35f  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf365  pinsrb xmm13, r12d, 0x06
0000710e9ebcf36c  lea r14, [rax+0x1C]
0000710e9ebcf370  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf376  pinsrb xmm1, r12d, 0x07
0000710e9ebcf37d  lea r14, [rax+0x1D]
0000710e9ebcf381  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf387  pinsrb xmm15, r12d, 0x07
0000710e9ebcf38e  lea r14, [rax+0x1E]
0000710e9ebcf392  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf398  pinsrb xmm14, r12d, 0x07
0000710e9ebcf39f  lea r14, [rax+0x1F]
0000710e9ebcf3a3  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf3a9  pinsrb xmm13, r12d, 0x07
0000710e9ebcf3b0  lea r14, [rax+0x20]
0000710e9ebcf3b4  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf3ba  pinsrb xmm1, r12d, 0x08
0000710e9ebcf3c1  lea r14, [rax+0x21]
0000710e9ebcf3c5  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf3cb  pinsrb xmm15, r12d, 0x08
0000710e9ebcf3d2  lea r14, [rax+0x22]
0000710e9ebcf3d6  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf3dc  pinsrb xmm14, r12d, 0x08
0000710e9ebcf3e3  lea r14, [rax+0x23]
0000710e9ebcf3e7  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf3ed  pinsrb xmm13, r12d, 0x08
0000710e9ebcf3f4  lea r14, [rax+0x24]
0000710e9ebcf3f8  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf3fe  pinsrb xmm1, r12d, 0x09
0000710e9ebcf405  lea r14, [rax+0x25]
0000710e9ebcf409  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf40f  pinsrb xmm15, r12d, 0x09
0000710e9ebcf416  lea r14, [rax+0x26]
0000710e9ebcf41a  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf420  pinsrb xmm14, r12d, 0x09
0000710e9ebcf427  lea r14, [rax+0x27]
0000710e9ebcf42b  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf431  pinsrb xmm13, r12d, 0x09
0000710e9ebcf438  lea r14, [rax+0x28]
0000710e9ebcf43c  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf442  pinsrb xmm1, r12d, 0x0A
0000710e9ebcf449  lea r14, [rax+0x29]
0000710e9ebcf44d  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf453  pinsrb xmm15, r12d, 0x0A
0000710e9ebcf45a  lea r14, [rax+0x2A]
0000710e9ebcf45e  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf464  pinsrb xmm14, r12d, 0x0A
0000710e9ebcf46b  lea r14, [rax+0x2B]
0000710e9ebcf46f  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf475  pinsrb xmm13, r12d, 0x0A
0000710e9ebcf47c  lea r14, [rax+0x2C]
0000710e9ebcf480  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf486  pinsrb xmm1, r12d, 0x0B
0000710e9ebcf48d  lea r14, [rax+0x2D]
0000710e9ebcf491  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf497  pinsrb xmm15, r12d, 0x0B
0000710e9ebcf49e  lea r14, [rax+0x2E]
0000710e9ebcf4a2  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf4a8  pinsrb xmm14, r12d, 0x0B
0000710e9ebcf4af  lea r14, [rax+0x2F]
0000710e9ebcf4b3  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf4b9  pinsrb xmm13, r12d, 0x0B
0000710e9ebcf4c0  lea r14, [rax+0x30]
0000710e9ebcf4c4  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf4ca  pinsrb xmm1, r12d, 0x0C
0000710e9ebcf4d1  lea r14, [rax+0x31]
0000710e9ebcf4d5  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf4db  pinsrb xmm15, r12d, 0x0C
0000710e9ebcf4e2  lea r14, [rax+0x32]
0000710e9ebcf4e6  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf4ec  pinsrb xmm14, r12d, 0x0C
0000710e9ebcf4f3  lea r14, [rax+0x33]
0000710e9ebcf4f7  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf4fd  pinsrb xmm13, r12d, 0x0C
0000710e9ebcf504  lea r14, [rax+0x34]
0000710e9ebcf508  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf50e  pinsrb xmm1, r12d, 0x0D
0000710e9ebcf515  lea r14, [rax+0x35]
0000710e9ebcf519  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf51f  pinsrb xmm15, r12d, 0x0D
0000710e9ebcf526  lea r14, [rax+0x36]
0000710e9ebcf52a  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf530  pinsrb xmm14, r12d, 0x0D
0000710e9ebcf537  lea r14, [rax+0x37]
0000710e9ebcf53b  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf541  pinsrb xmm13, r12d, 0x0D
0000710e9ebcf548  lea r14, [rax+0x38]
0000710e9ebcf54c  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf552  pinsrb xmm1, r12d, 0x0E
0000710e9ebcf559  lea r14, [rax+0x39]
0000710e9ebcf55d  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf563  pinsrb xmm15, r12d, 0x0E
0000710e9ebcf56a  lea r14, [rax+0x3A]
0000710e9ebcf56e  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf574  pinsrb xmm14, r12d, 0x0E
0000710e9ebcf57b  lea r14, [rax+0x3B]
0000710e9ebcf57f  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf585  pinsrb xmm13, r12d, 0x0E
0000710e9ebcf58c  lea r14, [rax+0x3C]
0000710e9ebcf590  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf596  pinsrb xmm1, r12d, 0x0F
0000710e9ebcf59d  movaps [r15+0x110], xmm1
0000710e9ebcf5a5  lea r14, [rax+0x3D]
0000710e9ebcf5a9  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf5af  pinsrb xmm15, r12d, 0x0F
0000710e9ebcf5b6  movaps [r15+0x120], xmm15
0000710e9ebcf5be  lea r14, [rax+0x3E]
0000710e9ebcf5c2  movzx r12d, byte ptr [r13+r14*1]
0000710e9ebcf5c8  pinsrb xmm14, r12d, 0x0F
0000710e9ebcf5cf  movaps [r15+0x130], xmm14
0000710e9ebcf5d7  lea r14, [rax+0x3F]
0000710e9ebcf5db  movzx eax, byte ptr [r13+r14*1]
0000710e9ebcf5e1  pinsrb xmm13, eax, 0x0F
0000710e9ebcf5e8  movaps [r15+0x140], xmm13
0000710e9ebcf5f0  movq xmm1, qword ptr [r15+0x120]
0000710e9ebcf5f9  pmovzxbw xmm1, xmm1
0000710e9ebcf5fe  psllw xmm1, 0x00
0000710e9ebcf603  movaps [r15+0x150], xmm1
0000710e9ebcf60b  movq xmm1, qword ptr [r15+0x130]
0000710e9ebcf614  pmovzxbw xmm1, xmm1
0000710e9ebcf619  psllw xmm1, 0x00
0000710e9ebcf61e  movaps [r15+0x160], xmm1
0000710e9ebcf626  movq xmm1, qword ptr [r15+0x110]
0000710e9ebcf62f  pmovzxbw xmm1, xmm1
0000710e9ebcf634  psllw xmm1, 0x00
0000710e9ebcf639  movaps [r15+0x170], xmm1
0000710e9ebcf641  movaps xmm15, [r15+0x110]
0000710e9ebcf649  pextrq rax, xmm15, 0x01
0000710e9ebcf650  movq xmm15, rax
0000710e9ebcf655  pmovzxbw xmm15, xmm15
0000710e9ebcf65b  psllw xmm15, 0x00
0000710e9ebcf661  movaps [r15+0x180], xmm15
0000710e9ebcf669  movaps xmm14, [r15+0x120]
0000710e9ebcf671  pextrq rax, xmm14, 0x01
0000710e9ebcf678  movq xmm14, rax
0000710e9ebcf67d  pmovzxbw xmm14, xmm14
0000710e9ebcf683  psllw xmm14, 0x00
0000710e9ebcf689  movaps [r15+0x210], xmm14
0000710e9ebcf691  movaps xmm13, [r15+0x130]
0000710e9ebcf699  pextrq rax, xmm13, 0x01
0000710e9ebcf6a0  movq xmm13, rax
0000710e9ebcf6a5  pmovzxbw xmm13, xmm13
0000710e9ebcf6ab  psllw xmm13, 0x00
0000710e9ebcf6b1  movaps [r15+0x220], xmm13
0000710e9ebcf6b9  movq xmm12, qword ptr [r15+0x140]
0000710e9ebcf6c2  pmovzxbw xmm12, xmm12
0000710e9ebcf6c8  psllw xmm12, 0x00
0000710e9ebcf6ce  movaps [r15+0x250], xmm12
0000710e9ebcf6d6  movaps xmm12, [r15+0x140]
0000710e9ebcf6de  pextrq rax, xmm12, 0x01
0000710e9ebcf6e5  movq xmm12, rax
0000710e9ebcf6ea  pmovzxbw xmm12, xmm12
0000710e9ebcf6f0  psllw xmm12, 0x00
0000710e9ebcf6f6  movaps [r15+0x110], xmm12
0000710e9ebcf6fe  movq xmm11, qword ptr [r15+0x150]
0000710e9ebcf707  pmovzxwd xmm11, xmm11
0000710e9ebcf70d  pslld xmm11, 0x10
0000710e9ebcf713  movq xmm10, qword ptr [r15+0x160]
0000710e9ebcf71c  pmovzxwd xmm10, xmm10
0000710e9ebcf722  pslld xmm10, 0x08
0000710e9ebcf728  pextrq rax, xmm1, 0x01
0000710e9ebcf72f  movq xmm1, rax
0000710e9ebcf734  pmovzxwd xmm1, xmm1
0000710e9ebcf739  pslld xmm1, 0x00
0000710e9ebcf73e  movaps [r15+0x260], xmm1
0000710e9ebcf746  pextrq rax, xmm15, 0x01
0000710e9ebcf74d  movq xmm15, rax
0000710e9ebcf752  pmovzxwd xmm15, xmm15
0000710e9ebcf758  pslld xmm15, 0x00
0000710e9ebcf75e  movaps [r15+0x270], xmm15
0000710e9ebcf766  movq xmm9, qword ptr [r15+0x170]
0000710e9ebcf76f  pmovzxwd xmm9, xmm9
0000710e9ebcf775  pslld xmm9, 0x00
0000710e9ebcf77b  pextrq rax, xmm14, 0x01
0000710e9ebcf782  movq xmm14, rax
0000710e9ebcf787  pmovzxwd xmm14, xmm14
0000710e9ebcf78d  pslld xmm14, 0x10
0000710e9ebcf793  movaps [r15+0x280], xmm14
0000710e9ebcf79b  movq xmm8, qword ptr [r15+0x180]
0000710e9ebcf7a4  pmovzxwd xmm8, xmm8
0000710e9ebcf7aa  pslld xmm8, 0x00
0000710e9ebcf7b0  movq xmm7, qword ptr [r15+0x210]
0000710e9ebcf7b9  pmovzxwd xmm7, xmm7
0000710e9ebcf7be  pslld xmm7, 0x10
0000710e9ebcf7c3  movaps xmm6, [r15+0x150]
0000710e9ebcf7cb  pextrq rax, xmm6, 0x01
0000710e9ebcf7d2  movq xmm6, rax
0000710e9ebcf7d7  pmovzxwd xmm6, xmm6
0000710e9ebcf7dc  pslld xmm6, 0x10
0000710e9ebcf7e1  por xmm11, xmm10
0000710e9ebcf7e6  movaps [r15+0x230], xmm11
0000710e9ebcf7ee  pextrq rax, xmm13, 0x01
0000710e9ebcf7f5  movq xmm13, rax
0000710e9ebcf7fa  pmovzxwd xmm13, xmm13
0000710e9ebcf800  pslld xmm13, 0x08
0000710e9ebcf806  movaps [r15+0x240], xmm13
0000710e9ebcf80e  movq xmm10, qword ptr [r15+0x220]
0000710e9ebcf817  pmovzxwd xmm10, xmm10
0000710e9ebcf81d  pslld xmm10, 0x08
0000710e9ebcf823  movaps xmm5, [r15+0x160]
0000710e9ebcf82b  pextrq rax, xmm5, 0x01
0000710e9ebcf832  movq xmm5, rax
0000710e9ebcf837  pmovzxwd xmm5, xmm5
0000710e9ebcf83c  pslld xmm5, 0x08
0000710e9ebcf841  pslld xmm9, 0x18
0000710e9ebcf847  pslld xmm15, 0x18
0000710e9ebcf84d  pslld xmm8, 0x18
0000710e9ebcf853  movq xmm4, qword ptr [r15+0x250]
0000710e9ebcf85c  pmovzxwd xmm4, xmm4
0000710e9ebcf861  pslld xmm4, 0x00
0000710e9ebcf866  por xmm14, xmm13
0000710e9ebcf86b  por xmm7, xmm10
0000710e9ebcf870  movaps [r15+0x210], xmm7
0000710e9ebcf878  pslld xmm1, 0x18
0000710e9ebcf87d  movaps [r15+0x220], xmm1
0000710e9ebcf885  por xmm6, xmm5
0000710e9ebcf889  por xmm11, xmm9
0000710e9ebcf88e  movaps [r15+0x160], xmm11
0000710e9ebcf896  pextrq rax, xmm12, 0x01
0000710e9ebcf89d  movq xmm13, rax
0000710e9ebcf8a2  pmovzxwd xmm13, xmm13
0000710e9ebcf8a8  pslld xmm13, 0x00
0000710e9ebcf8ae  movaps [r15+0x170], xmm13
0000710e9ebcf8b6  movq xmm12, qword ptr [r15+0x110]
0000710e9ebcf8bf  pmovzxwd xmm12, xmm12
0000710e9ebcf8c5  pslld xmm12, 0x00
0000710e9ebcf8cb  por xmm14, xmm15
0000710e9ebcf8d0  por xmm7, xmm8
0000710e9ebcf8d5  movaps xmm15, [r15+0x250]
0000710e9ebcf8dd  pextrq rax, xmm15, 0x01
0000710e9ebcf8e4  movq xmm15, rax
0000710e9ebcf8e9  pmovzxwd xmm15, xmm15
0000710e9ebcf8ef  pslld xmm15, 0x00
0000710e9ebcf8f5  movaps [r15+0x180], xmm15
0000710e9ebcf8fd  por xmm6, xmm1
0000710e9ebcf901  movaps [r15+0x150], xmm6
0000710e9ebcf909  por xmm11, xmm4
0000710e9ebcf90e  movaps [r15+0x140], xmm11
0000710e9ebcf916  por xmm7, xmm12
0000710e9ebcf91b  movaps [r15+0x110], xmm7
0000710e9ebcf923  por xmm14, xmm13
0000710e9ebcf928  movaps [r15+0x120], xmm14
0000710e9ebcf930  por xmm6, xmm15
0000710e9ebcf935  movaps [r15+0x130], xmm6
0000710e9ebcf93d  mov rax, [r15+0xF8]
0000710e9ebcf944  lea r14, [rax+0x20]
0000710e9ebcf948  movups [r13+r14*1], xmm7
0000710e9ebcf94e  lea r14, [rax+0x30]
0000710e9ebcf952  movups [r13+r14*1], xmm14
0000710e9ebcf958  movups [r13+rax*1], xmm11
0000710e9ebcf95e  lea r14, [rax+0x10]
0000710e9ebcf962  movups [r13+r14*1], xmm6
0000710e9ebcf968  mov r14d, [r13+rax*1]
0000710e9ebcf96d  mov rax, [r15+0x48]
0000710e9ebcf971  mov [r15+0x68], rax
0000710e9ebcf975  mov qword ptr [r15+0x58], 0x04
0000710e9ebcf97d  lea r12, [rax+0x04]
0000710e9ebcf981  mov r11d, [r13+r12*1]
0000710e9ebcf986  mov [rsp+0x10], r11d
0000710e9ebcf98b  mov r11d, r11d
0000710e9ebcf98e  mov [r15+0x70], r11
0000710e9ebcf992  lea r12, [rax+0x38]
0000710e9ebcf996  mov r11d, [r13+r12*1]
0000710e9ebcf99b  lea r12, [rax+0x24]
0000710e9ebcf99f  mov r10d, [r13+r12*1]
0000710e9ebcf9a4  mov [rsp+0x20], r10d
0000710e9ebcf9a9  mov r10d, r10d
0000710e9ebcf9ac  mov [r15+0x90], r10
0000710e9ebcf9b3  mov [rsp+0x30], rax
0000710e9ebcf9b8  xor eax, eax
0000710e9ebcf9ba  mov r12d, 0x04
0000710e9ebcf9c0  mov r10d, 0xC0
0000710e9ebcf9c6  cmp r12, r10
0000710e9ebcf9c9  cmc
0000710e9ebcf9ca  lahf
0000710e9ebcf9cb  seto al
0000710e9ebcf9ce  mov [r15+0x108], eax
0000710e9ebcf9d5  mov eax, [rsp+0x10]
0000710e9ebcf9d9  mov r12d, [rsp+0x10]
0000710e9ebcf9de  shrd eax, r12d, 0x07
0000710e9ebcf9e3  mov [rsp+0x10], r11d
0000710e9ebcf9e8  mov r10d, [rsp+0x10]
0000710e9ebcf9ed  shrd r11d, r10d, 0x11
0000710e9ebcf9f2  mov r9d, [rsp+0x20]
0000710e9ebcf9f7  lea r8d, [r9d+r14d*1]
0000710e9ebcf9fc  rorx r14d, r12d, 0x12
0000710e9ebcfa02  xor eax, r14d
0000710e9ebcfa05  rorx r14d, r10d, 0x13
0000710e9ebcfa0b  xor r11d, r14d
0000710e9ebcfa0e  mov [rsp+0x10], r11d
0000710e9ebcfa13  mov r11d, r11d
0000710e9ebcfa16  mov [r15+0x88], r11
0000710e9ebcfa1d  mov [rsp+0x20], r12d
0000710e9ebcfa22  shr r12d, 0x03
0000710e9ebcfa26  xor eax, r12d
0000710e9ebcfa29  mov [rsp+0x40], eax
0000710e9ebcfa2d  mov eax, eax
0000710e9ebcfa2f  mov [r15+0x80], rax
0000710e9ebcfa36  shr r10d, 0x0A
0000710e9ebcfa3a  mov eax, [rsp+0x10]
0000710e9ebcfa3e  xor eax, r10d
0000710e9ebcfa41  mov [rsp+0x10], eax
0000710e9ebcfa45  mov eax, eax
0000710e9ebcfa47  mov [r15+0x78], rax
0000710e9ebcfa4b  mov eax, [rsp+0x40]
0000710e9ebcfa4f  lea r14d, [r8d+eax*1]
0000710e9ebcfa54  mov eax, [rsp+0x10]
0000710e9ebcfa58  lea r12d, [r14d+eax*1]
0000710e9ebcfa5d  mov rax, [rsp+0x30]
0000710e9ebcfa62  lea r14, [rax+0x40]
0000710e9ebcfa66  mov [r13+r14*1], r12d
0000710e9ebcfa6b  mov eax, [rsp+0x20]
0000710e9ebcfa6f  mov eax, eax
0000710e9ebcfa71  mov [r15+0x60], rax
0000710e9ebcfa75  mov eax, [r15+0x108]
0000710e9ebcfa7c  sahf
0000710e9ebcfa7d  jnz 0x0000710E9EBCFAAF
0000710e9ebcfa7f  cmp dword ptr [r15+0x318], 0x00
0000710e9ebcfa87  jz 0x0000710E9EBCFF70
0000710e9ebcfa8d  nop [rax+rax*1], ax
0000710e9ebcfa96  nop [rax+rax*1], eax
0000710e9ebcfa9e  mov eax, 0x41088C
0000710e9ebcfaa3  mov [r15+0x100], rax
0000710e9ebcfaaa  jmp 0x0000710E9E9FE110
0000710e9ebcfaaf  cmp dword ptr [r15+0x318], 0x00
0000710e9ebcfab7  jz 0x0000710E9EBCFDC0
0000710e9ebcfabd  nop [rax+rax*1], ax
0000710e9ebcfac6  nop [rax+rax*1], eax
0000710e9ebcface  mov eax, 0x410844
0000710e9ebcfad3  mov [r15+0x100], rax
0000710e9ebcfada  jmp 0x0000710E9E9FE110
0000710e9ebcfadf  int3
0000710e9ebcfae0  call 0x0000710E9EA0D860
0000710e9ebcfae5  jmp 0x0000710E9EBCF17A
0000710e9ebcfaea  call 0x0000710E9EAE2420
0000710e9ebcfaef  jmp 0x0000710E9EBCF193
0000710e9ebcfaf4  call 0x0000710E9EAE2420
0000710e9ebcfaf9  jmp 0x0000710E9EBCF1AC
0000710e9ebcfafe  call 0x0000710E9EAE2420
0000710e9ebcfb03  jmp 0x0000710E9EBCF1C5
0000710e9ebcfb08  call 0x0000710E9EAE2420
0000710e9ebcfb0d  jmp 0x0000710E9EBCF1DE
0000710e9ebcfb12  call 0x0000710E9EAE2420
0000710e9ebcfb17  jmp 0x0000710E9EBCF1EF
0000710e9ebcfb1c  call 0x0000710E9EAE2420
0000710e9ebcfb21  jmp 0x0000710E9EBCF200
0000710e9ebcfb26  call 0x0000710E9EAE2420
0000710e9ebcfb2b  jmp 0x0000710E9EBCF211
0000710e9ebcfb30  call 0x0000710E9EAE2420
0000710e9ebcfb35  jmp 0x0000710E9EBCF222
0000710e9ebcfb3a  call 0x0000710E9EAE2420
0000710e9ebcfb3f  jmp 0x0000710E9EBCF233
0000710e9ebcfb44  call 0x0000710E9EAE2420
0000710e9ebcfb49  jmp 0x0000710E9EBCF244
0000710e9ebcfb4e  call 0x0000710E9EAE2420
0000710e9ebcfb53  jmp 0x0000710E9EBCF255
0000710e9ebcfb58  call 0x0000710E9EAE2420
0000710e9ebcfb5d  jmp 0x0000710E9EBCF266
0000710e9ebcfb62  call 0x0000710E9EAE2420
0000710e9ebcfb67  jmp 0x0000710E9EBCF277
0000710e9ebcfb6c  call 0x0000710E9EAE2420
0000710e9ebcfb71  jmp 0x0000710E9EBCF288
0000710e9ebcfb76  call 0x0000710E9EAE2420
0000710e9ebcfb7b  jmp 0x0000710E9EBCF299
0000710e9ebcfb80  call 0x0000710E9EAE2420
0000710e9ebcfb85  jmp 0x0000710E9EBCF2AA
0000710e9ebcfb8a  call 0x0000710E9EAE2420
0000710e9ebcfb8f  jmp 0x0000710E9EBCF2BB
0000710e9ebcfb94  call 0x0000710E9EAE2420
0000710e9ebcfb99  jmp 0x0000710E9EBCF2CC
0000710e9ebcfb9e  call 0x0000710E9EAE2420
0000710e9ebcfba3  jmp 0x0000710E9EBCF2DD
0000710e9ebcfba8  call 0x0000710E9EAE2420
0000710e9ebcfbad  jmp 0x0000710E9EBCF2EE
0000710e9ebcfbb2  call 0x0000710E9EAE2420
0000710e9ebcfbb7  jmp 0x0000710E9EBCF2FF
0000710e9ebcfbbc  call 0x0000710E9EAE2420
0000710e9ebcfbc1  jmp 0x0000710E9EBCF310
0000710e9ebcfbc6  call 0x0000710E9EAE2420
0000710e9ebcfbcb  jmp 0x0000710E9EBCF321
0000710e9ebcfbd0  call 0x0000710E9EAE2420
0000710e9ebcfbd5  jmp 0x0000710E9EBCF332
0000710e9ebcfbda  call 0x0000710E9EAE2420
0000710e9ebcfbdf  jmp 0x0000710E9EBCF343
0000710e9ebcfbe4  call 0x0000710E9EAE2420
0000710e9ebcfbe9  jmp 0x0000710E9EBCF354
0000710e9ebcfbee  call 0x0000710E9EAE2420
0000710e9ebcfbf3  jmp 0x0000710E9EBCF365
0000710e9ebcfbf8  call 0x0000710E9EAE2420
0000710e9ebcfbfd  jmp 0x0000710E9EBCF376
0000710e9ebcfc02  call 0x0000710E9EAE2420
0000710e9ebcfc07  jmp 0x0000710E9EBCF387
0000710e9ebcfc0c  call 0x0000710E9EAE2420
0000710e9ebcfc11  jmp 0x0000710E9EBCF398
0000710e9ebcfc16  call 0x0000710E9EAE2420
0000710e9ebcfc1b  jmp 0x0000710E9EBCF3A9
0000710e9ebcfc20  call 0x0000710E9EAE2420
0000710e9ebcfc25  jmp 0x0000710E9EBCF3BA
0000710e9ebcfc2a  call 0x0000710E9EAE2420
0000710e9ebcfc2f  jmp 0x0000710E9EBCF3CB
0000710e9ebcfc34  call 0x0000710E9EAE2420
0000710e9ebcfc39  jmp 0x0000710E9EBCF3DC
0000710e9ebcfc3e  call 0x0000710E9EAE2420
0000710e9ebcfc43  jmp 0x0000710E9EBCF3ED
0000710e9ebcfc48  call 0x0000710E9EAE2420
0000710e9ebcfc4d  jmp 0x0000710E9EBCF3FE
0000710e9ebcfc52  call 0x0000710E9EAE2420
0000710e9ebcfc57  jmp 0x0000710E9EBCF40F
0000710e9ebcfc5c  call 0x0000710E9EAE2420
0000710e9ebcfc61  jmp 0x0000710E9EBCF420
0000710e9ebcfc66  call 0x0000710E9EAE2420
0000710e9ebcfc6b  jmp 0x0000710E9EBCF431
0000710e9ebcfc70  call 0x0000710E9EAE2420
0000710e9ebcfc75  jmp 0x0000710E9EBCF442
0000710e9ebcfc7a  call 0x0000710E9EAE2420
0000710e9ebcfc7f  jmp 0x0000710E9EBCF453
0000710e9ebcfc84  call 0x0000710E9EAE2420
0000710e9ebcfc89  jmp 0x0000710E9EBCF464
0000710e9ebcfc8e  call 0x0000710E9EAE2420
0000710e9ebcfc93  jmp 0x0000710E9EBCF475
0000710e9ebcfc98  call 0x0000710E9EAE2420
0000710e9ebcfc9d  jmp 0x0000710E9EBCF486
0000710e9ebcfca2  call 0x0000710E9EAE2420
0000710e9ebcfca7  jmp 0x0000710E9EBCF497
0000710e9ebcfcac  call 0x0000710E9EAE2420
0000710e9ebcfcb1  jmp 0x0000710E9EBCF4A8
0000710e9ebcfcb6  call 0x0000710E9EAE2420
0000710e9ebcfcbb  jmp 0x0000710E9EBCF4B9
0000710e9ebcfcc0  call 0x0000710E9EAE2420
0000710e9ebcfcc5  jmp 0x0000710E9EBCF4CA
0000710e9ebcfcca  call 0x0000710E9EAE2420
0000710e9ebcfccf  jmp 0x0000710E9EBCF4DB
0000710e9ebcfcd4  call 0x0000710E9EAE2420
0000710e9ebcfcd9  jmp 0x0000710E9EBCF4EC
0000710e9ebcfcde  call 0x0000710E9EAE2420
0000710e9ebcfce3  jmp 0x0000710E9EBCF4FD
0000710e9ebcfce8  call 0x0000710E9EAE2420
0000710e9ebcfced  jmp 0x0000710E9EBCF50E
0000710e9ebcfcf2  call 0x0000710E9EAE2420
0000710e9ebcfcf7  jmp 0x0000710E9EBCF51F
0000710e9ebcfcfc  call 0x0000710E9EAE2420
0000710e9ebcfd01  jmp 0x0000710E9EBCF530
0000710e9ebcfd06  call 0x0000710E9EAE2420
0000710e9ebcfd0b  jmp 0x0000710E9EBCF541
0000710e9ebcfd10  call 0x0000710E9EAE2420
0000710e9ebcfd15  jmp 0x0000710E9EBCF552
0000710e9ebcfd1a  call 0x0000710E9EAE2420
0000710e9ebcfd1f  jmp 0x0000710E9EBCF563
0000710e9ebcfd24  call 0x0000710E9EAE2420
0000710e9ebcfd29  jmp 0x0000710E9EBCF574
0000710e9ebcfd2e  call 0x0000710E9EAE2420
0000710e9ebcfd33  jmp 0x0000710E9EBCF585
0000710e9ebcfd38  call 0x0000710E9EAE2420
0000710e9ebcfd3d  jmp 0x0000710E9EBCF596
0000710e9ebcfd42  call 0x0000710E9EAE2420
0000710e9ebcfd47  jmp 0x0000710E9EBCF5AF
0000710e9ebcfd4c  call 0x0000710E9EAE2420
0000710e9ebcfd51  jmp 0x0000710E9EBCF5C8
0000710e9ebcfd56  call 0x0000710E9EAD5610
0000710e9ebcfd5b  jmp 0x0000710E9EBCF5E1
0000710e9ebcfd60  call 0x0000710E9EADC580
0000710e9ebcfd65  jmp 0x0000710E9EBCF94E
0000710e9ebcfd6a  call 0x0000710E9EAE46C0
0000710e9ebcfd6f  jmp 0x0000710E9EBCF958
0000710e9ebcfd74  call 0x0000710E9EA09E90
0000710e9ebcfd79  jmp 0x0000710E9EBCF95E
0000710e9ebcfd7e  call 0x0000710E9EADB310
0000710e9ebcfd83  jmp 0x0000710E9EBCF968
0000710e9ebcfd88  call 0x0000710E9EA0DAE0
0000710e9ebcfd8d  jmp 0x0000710E9EBCF96D
0000710e9ebcfd92  call 0x0000710E9EAC0230
0000710e9ebcfd97  jmp 0x0000710E9EBCF986
0000710e9ebcfd9c  call 0x0000710E9EAC0230
0000710e9ebcfda1  jmp 0x0000710E9EBCF99B
0000710e9ebcfda6  call 0x0000710E9EABEFC0
0000710e9ebcfdab  jmp 0x0000710E9EBCF9A4
0000710e9ebcfdb0  call 0x0000710E9EAE2BA0
0000710e9ebcfdb5  jmp 0x0000710E9EBCFA6B
0000710e9ebcfdba  int3
0000710e9ebcfdbb  nop [rax+rax*1], eax
0000710e9ebcfdc0  mov rax, [r15+0x48]
0000710e9ebcfdc4  mov r14, [r15+0x58]
0000710e9ebcfdc8  lea r12, [rax+r14*1]
0000710e9ebcfdcc  mov [r15+0x68], r12
0000710e9ebcfdd0  lea rax, [r14+0x04]
0000710e9ebcfdd4  mov [r15+0x58], rax
0000710e9ebcfdd8  lea r14, [r12+0x04]
0000710e9ebcfddd  mov r11d, [r13+r14*1]
0000710e9ebcfde2  mov [rsp+0x10], r11d
0000710e9ebcfde7  mov r11d, r11d
0000710e9ebcfdea  mov [r15+0x70], r11
0000710e9ebcfdee  lea r14, [r12+0x38]
0000710e9ebcfdf3  mov r11d, [r13+r14*1]
0000710e9ebcfdf8  lea r14, [r12+0x24]
0000710e9ebcfdfd  mov r10d, [r13+r14*1]
0000710e9ebcfe02  mov [rsp+0x20], r10d
0000710e9ebcfe07  mov r10d, r10d
0000710e9ebcfe0a  mov [r15+0x90], r10
0000710e9ebcfe11  mov [rsp+0x30], rax
0000710e9ebcfe16  xor eax, eax
0000710e9ebcfe18  mov r14, [rsp+0x30]
0000710e9ebcfe1d  mov r10d, 0xC0
0000710e9ebcfe23  cmp r14, r10
0000710e9ebcfe26  cmc
0000710e9ebcfe27  lahf
0000710e9ebcfe28  seto al
0000710e9ebcfe2b  mov [r15+0x108], eax
0000710e9ebcfe32  mov eax, [rsp+0x10]
0000710e9ebcfe36  mov r14d, [rsp+0x10]
0000710e9ebcfe3b  shrd eax, r14d, 0x07
0000710e9ebcfe40  mov [rsp+0x10], r11d
0000710e9ebcfe45  mov r10d, [rsp+0x10]
0000710e9ebcfe4a  shrd r11d, r10d, 0x11
0000710e9ebcfe4f  mov r9d, [r15+0x60]
0000710e9ebcfe53  mov r8d, [rsp+0x20]
0000710e9ebcfe58  lea ebp, [r8d+r9d*1]
0000710e9ebcfe5d  rorx r9d, r14d, 0x12
0000710e9ebcfe63  xor eax, r9d
0000710e9ebcfe66  rorx r9d, r10d, 0x13
0000710e9ebcfe6c  xor r11d, r9d
0000710e9ebcfe6f  mov [rsp+0x10], r11d
0000710e9ebcfe74  mov r11d, r11d
0000710e9ebcfe77  mov [r15+0x88], r11
0000710e9ebcfe7e  mov [rsp+0x20], r14d
0000710e9ebcfe83  shr r14d, 0x03
0000710e9ebcfe87  xor eax, r14d
0000710e9ebcfe8a  mov [rsp+0x30], eax
0000710e9ebcfe8e  mov eax, eax
0000710e9ebcfe90  mov [r15+0x80], rax
0000710e9ebcfe97  shr r10d, 0x0A
0000710e9ebcfe9b  mov eax, [rsp+0x10]
0000710e9ebcfe9f  xor eax, r10d
0000710e9ebcfea2  mov [rsp+0x10], eax
0000710e9ebcfea6  mov eax, eax
0000710e9ebcfea8  mov [r15+0x78], rax
0000710e9ebcfeac  mov eax, [rsp+0x30]
0000710e9ebcfeb0  lea r14d, [ebp+eax*1]
0000710e9ebcfeb6  mov eax, [rsp+0x10]
0000710e9ebcfeba  lea r11d, [r14d+eax*1]
0000710e9ebcfebf  lea rax, [r12+0x40]
0000710e9ebcfec4  mov [r13+rax*1], r11d
0000710e9ebcfec9  mov eax, [rsp+0x20]
0000710e9ebcfecd  mov eax, eax
0000710e9ebcfecf  mov [r15+0x60], rax
0000710e9ebcfed3  mov eax, [r15+0x108]
0000710e9ebcfeda  sahf
0000710e9ebcfedb  jnz 0x0000710E9EBCFF0D
0000710e9ebcfedd  cmp dword ptr [r15+0x318], 0x00
0000710e9ebcfee5  jz 0x0000710E9EBCFF70
0000710e9ebcfeeb  nop [rax+rax*1], ax
0000710e9ebcfef4  nop [rax+rax*1], eax
0000710e9ebcfefc  mov eax, 0x41088C
0000710e9ebcff01  mov [r15+0x100], rax
0000710e9ebcff08  jmp 0x0000710E9E9FE110
0000710e9ebcff0d  cmp dword ptr [r15+0x318], 0x00
0000710e9ebcff15  jz 0x0000710E9EBCFDC0
0000710e9ebcff1b  nop [rax+rax*1], ax
0000710e9ebcff24  nop [rax+rax*1], eax
0000710e9ebcff2c  mov eax, 0x410844
0000710e9ebcff31  mov [r15+0x100], rax
0000710e9ebcff38  jmp 0x0000710E9E9FE110
0000710e9ebcff3d  int3
0000710e9ebcff3e  call 0x0000710E9EAE1430
0000710e9ebcff43  jmp 0x0000710E9EBCFDE2
0000710e9ebcff48  call 0x0000710E9EAE1430
0000710e9ebcff4d  jmp 0x0000710E9EBCFDF8
0000710e9ebcff52  call 0x0000710E9EAE01C0
0000710e9ebcff57  jmp 0x0000710E9EBCFE02
0000710e9ebcff5c  call 0x0000710E9EA0A860
0000710e9ebcff61  jmp 0x0000710E9EBCFEC9
0000710e9ebcff66  int3
0000710e9ebcff67  nop [rax+rax*1], ax
0000710e9ebcff70  mov rax, [r15]
0000710e9ebcff73  mov r14d, [r13+rax*1]
0000710e9ebcff78  lea r12, [rax+0x04]
0000710e9ebcff7c  mov r11d, [r13+r12*1]
0000710e9ebcff81  mov [rsp+0x10], r14d
0000710e9ebcff86  mov r14d, r14d
0000710e9ebcff89  mov [r15+0x78], r14
0000710e9ebcff8d  mov [rsp+0x20], r11d
0000710e9ebcff92  mov r11d, r11d
0000710e9ebcff95  mov [r15+0x80], r11
0000710e9ebcff9c  lea r14, [rax+0x08]
0000710e9ebcffa0  mov r12d, [r13+r14*1]
0000710e9ebcffa5  lea r14, [rax+0x0C]
0000710e9ebcffa9  mov r11d, [r13+r14*1]
0000710e9ebcffae  mov [rsp+0x30], r12d
0000710e9ebcffb3  mov r12d, r12d
0000710e9ebcffb6  mov [r15+0x70], r12
0000710e9ebcffba  mov [rsp+0x40], r11d
0000710e9ebcffbf  mov r11d, r11d
0000710e9ebcffc2  mov [r15+0x68], r11
0000710e9ebcffc6  lea r14, [rax+0x18]
0000710e9ebcffca  mov r12d, [r13+r14*1]
0000710e9ebcffcf  lea r14, [rax+0x1C]
0000710e9ebcffd3  mov r11d, [r13+r14*1]
0000710e9ebcffd8  mov [rsp+0x50], r12d
0000710e9ebcffdd  mov r12d, r12d
0000710e9ebcffe0  mov [r15+0x58], r12
0000710e9ebcffe4  mov [rsp+0x60], r11d
0000710e9ebcffe9  mov r11d, r11d
0000710e9ebcffec  mov [r15+0x60], r11
0000710e9ebcfff0  lea r14, [rax+0x10]
0000710e9ebcfff4  mov r12d, [r13+r14*1]
0000710e9ebcfff9  lea r14, [rax+0x14]
0000710e9ebcfffd  mov eax, [r13+r14*1]
0000710e9ebd0002  mov [rsp+0x70], r12d
0000710e9ebd0007  mov r12d, r12d
0000710e9ebd000a  mov [r15+0x18], r12
0000710e9ebd000e  mov [rsp+0x80], eax
0000710e9ebd0015  mov eax, eax
0000710e9ebd0017  mov [r15+0x90], rax
0000710e9ebd001e  mov eax, [rsp+0x70]
0000710e9ebd0022  mov eax, eax
0000710e9ebd0024  mov [r15+0x30], rax
0000710e9ebd0028  mov eax, [rsp+0x50]
0000710e9ebd002c  mov eax, eax
0000710e9ebd002e  mov [r15+0xA0], rax
0000710e9ebd0035  mov eax, [rsp+0x30]
0000710e9ebd0039  mov eax, eax
0000710e9ebd003b  mov [r15+0x28], rax
0000710e9ebd003f  mov eax, [rsp+0x20]
0000710e9ebd0043  mov eax, eax
0000710e9ebd0045  mov [r15+0x98], rax
0000710e9ebd004c  mov eax, [rsp+0x10]
0000710e9ebd0050  mov eax, eax
0000710e9ebd0052  mov [r15+0x38], rax
0000710e9ebd0056  mov eax, [rsp+0x70]
0000710e9ebd005a  mov r14d, [rsp+0x70]
0000710e9ebd005f  shrd eax, r14d, 0x06
0000710e9ebd0064  mov [rsp+0x70], r14d
0000710e9ebd0069  mov r12d, [rsp+0x80]
0000710e9ebd0071  and r14d, r12d
0000710e9ebd0074  mov r11d, [rsp+0x10]
0000710e9ebd0079  mov r10d, [rsp+0x10]
0000710e9ebd007e  shrd r11d, r10d, 0x02
0000710e9ebd0083  mov [rsp+0x10], r12d
0000710e9ebd0088  mov r12d, r12d
0000710e9ebd008b  mov [r15+0x20], r12
0000710e9ebd008f  mov r12, [r15+0x50]
0000710e9ebd0093  mov r9d, [r13+r12*1]
0000710e9ebd0098  mov r12d, [rsp+0x50]
0000710e9ebd009d  mov r8d, [rsp+0x70]
0000710e9ebd00a2  andn ebp, r8d, r12d
0000710e9ebd00a7  mov edi, [rsp+0x60]
0000710e9ebd00ab  lea esi, [r14d+edi*1]
0000710e9ebd00b0  rorx r14d, r8d, 0x0B
0000710e9ebd00b6  xor eax, r14d
0000710e9ebd00b9  rorx r14d, r10d, 0x0D
0000710e9ebd00bf  xor r11d, r14d
0000710e9ebd00c2  lea edi, [esi+ebp*1]
0000710e9ebd00c6  mov r14, [r15+0x48]
0000710e9ebd00ca  mov ebp, [r13+r14*1]
0000710e9ebd00cf  mov r14d, [rsp+0x30]
0000710e9ebd00d4  mov esi, [rsp+0x20]
0000710e9ebd00d8  and r14d, esi
0000710e9ebd00db  mov [rsp+0x20], r14d
0000710e9ebd00e0  mov r14d, r14d
0000710e9ebd00e3  mov [r15+0xD8], r14
0000710e9ebd00ea  lea r14d, [edi+r9d*1]
0000710e9ebd00ef  mov r9d, [rsp+0x30]
0000710e9ebd00f4  xor r9d, esi
0000710e9ebd00f7  rorx edi, r8d, 0x19
0000710e9ebd00fd  xor eax, edi
0000710e9ebd00ff  and r9d, r10d
0000710e9ebd0102  rorx edi, r10d, 0x16
0000710e9ebd0108  xor r11d, edi
0000710e9ebd010b  mov [rsp+0x30], r11d
0000710e9ebd0110  mov r11d, r11d
0000710e9ebd0113  mov [r15+0xD0], r11
0000710e9ebd011a  lea r11d, [r14d+ebp*1]
0000710e9ebd011f  mov r10d, [rsp+0x20]
0000710e9ebd0124  xor r9d, r10d
0000710e9ebd0127  lea r14d, [r11d+eax*1]
0000710e9ebd012c  mov qword ptr [r15+0x88], 0x04
0000710e9ebd0137  mov eax, [rsp+0x30]
0000710e9ebd013b  lea r11d, [r9d+eax*1]
0000710e9ebd0140  mov eax, [rsp+0x40]
0000710e9ebd0144  lea r10d, [r14d+eax*1]
0000710e9ebd0149  mov r10d, r10d
0000710e9ebd014c  mov [r15+0xB8], r10
0000710e9ebd0153  xor eax, eax
0000710e9ebd0155  mov r10d, 0x04
0000710e9ebd015b  mov r9d, 0x100
0000710e9ebd0161  cmp r10, r9
0000710e9ebd0164  cmc
0000710e9ebd0165  lahf
0000710e9ebd0166  seto al
0000710e9ebd0169  mov [r15+0x108], eax
0000710e9ebd0170  lea eax, [r11d+r14d*1]
0000710e9ebd0175  mov eax, eax
0000710e9ebd0177  mov [r15+0xA8], rax
0000710e9ebd017e  mov r12d, r12d
0000710e9ebd0181  mov [r15+0xB0], r12
0000710e9ebd0188  mov eax, [rsp+0x10]
0000710e9ebd018c  mov eax, eax
0000710e9ebd018e  mov [r15+0xC0], rax
0000710e9ebd0195  mov r8d, r8d
0000710e9ebd0198  mov [r15+0xC8], r8
0000710e9ebd019f  mov eax, [r15+0x108]
0000710e9ebd01a6  sahf
0000710e9ebd01a7  jnz 0x0000710E9EBD01D9
0000710e9ebd01a9  cmp dword ptr [r15+0x318], 0x00
0000710e9ebd01b1  jz 0x0000710E9EBD04A0
0000710e9ebd01b7  nop [rax+rax*1], ax
0000710e9ebd01c0  nop [rax+rax*1], eax
0000710e9ebd01c8  mov eax, 0x41094C
0000710e9ebd01cd  mov [r15+0x100], rax
0000710e9ebd01d4  jmp 0x0000710E9E9FE110
0000710e9ebd01d9  cmp dword ptr [r15+0x318], 0x00
0000710e9ebd01e1  jz 0x0000710E9EBD0270
0000710e9ebd01e7  nop [rax+rax*1], ax
0000710e9ebd01f0  nop [rax+rax*1], eax
0000710e9ebd01f8  mov eax, 0x4108C0
0000710e9ebd01fd  mov [r15+0x100], rax
0000710e9ebd0204  jmp 0x0000710E9E9FE110
0000710e9ebd0209  int3
0000710e9ebd020a  call 0x0000710E9EA0DAE0
0000710e9ebd020f  jmp 0x0000710E9EBCFF78
0000710e9ebd0214  call 0x0000710E9EAC0230
0000710e9ebd0219  jmp 0x0000710E9EBCFF81
0000710e9ebd021e  call 0x0000710E9EAE26A0
0000710e9ebd0223  jmp 0x0000710E9EBCFFA5
0000710e9ebd0228  call 0x0000710E9EAE1430
0000710e9ebd022d  jmp 0x0000710E9EBCFFAE
0000710e9ebd0232  call 0x0000710E9EAE26A0
0000710e9ebd0237  jmp 0x0000710E9EBCFFCF
0000710e9ebd023c  call 0x0000710E9EAE1430
0000710e9ebd0241  jmp 0x0000710E9EBCFFD8
0000710e9ebd0246  call 0x0000710E9EAE26A0
0000710e9ebd024b  jmp 0x0000710E9EBCFFF9
0000710e9ebd0250  call 0x0000710E9EAD5890
0000710e9ebd0255  jmp 0x0000710E9EBD0002
0000710e9ebd025a  call 0x0000710E9EABDD50
0000710e9ebd025f  jmp 0x0000710E9EBD0098
0000710e9ebd0264  call 0x0000710E9EADA580
0000710e9ebd0269  jmp 0x0000710E9EBD00CF
0000710e9ebd026e  int3
0000710e9ebd026f  nop
0000710e9ebd0270  mov eax, [r15+0xB8]
0000710e9ebd0277  mov [rsp+0x10], eax
0000710e9ebd027b  mov eax, eax
0000710e9ebd027d  mov [r15+0x30], rax
0000710e9ebd0281  mov eax, [r15+0xC0]
0000710e9ebd0288  mov [rsp+0x20], eax
0000710e9ebd028c  mov eax, eax
0000710e9ebd028e  mov [r15+0xA0], rax
0000710e9ebd0295  mov eax, [r15+0x28]
0000710e9ebd0299  mov r14d, [r15+0x98]
0000710e9ebd02a0  mov [rsp+0x30], r14d
0000710e9ebd02a5  mov r14d, r14d
0000710e9ebd02a8  mov [r15+0x28], r14
0000710e9ebd02ac  mov r14d, [r15+0x38]
0000710e9ebd02b0  mov [rsp+0x40], r14d
0000710e9ebd02b5  mov r14d, r14d
0000710e9ebd02b8  mov [r15+0x98], r14
0000710e9ebd02bf  mov r14d, [r15+0xA8]
0000710e9ebd02c6  mov [rsp+0x50], r14d
0000710e9ebd02cb  mov r14d, r14d
0000710e9ebd02ce  mov [r15+0x38], r14
0000710e9ebd02d2  mov r14d, [rsp+0x10]
0000710e9ebd02d7  mov r12d, [rsp+0x10]
0000710e9ebd02dc  shrd r14d, r12d, 0x06
0000710e9ebd02e1  mov r11d, [r15+0xC8]
0000710e9ebd02e8  mov [rsp+0x10], r12d
0000710e9ebd02ed  and r12d, r11d
0000710e9ebd02f0  mov r10d, [rsp+0x50]
0000710e9ebd02f5  mov r9d, [rsp+0x50]
0000710e9ebd02fa  shrd r10d, r9d, 0x02
0000710e9ebd02ff  mov [rsp+0x50], r11d
0000710e9ebd0304  mov r11d, r11d
0000710e9ebd0307  mov [r15+0x20], r11
0000710e9ebd030b  mov r11, [r15+0x88]
0000710e9ebd0312  mov r8, [r15+0x50]
0000710e9ebd0316  lea rbp, [r8+r11*1]
0000710e9ebd031a  mov r8d, [r13+rbp*1]
0000710e9ebd031f  mov ebp, [rsp+0x20]
0000710e9ebd0323  mov edi, [rsp+0x10]
0000710e9ebd0327  andn esi, edi, ebp
0000710e9ebd032c  mov edx, [r15+0xB0]
0000710e9ebd0333  lea ecx, [r12d+edx*1]
0000710e9ebd0338  rorx r12d, edi, 0x0B
0000710e9ebd033e  xor r14d, r12d
0000710e9ebd0341  rorx r12d, r9d, 0x0D
0000710e9ebd0347  xor r10d, r12d
0000710e9ebd034a  lea r12d, [ecx+esi*1]
0000710e9ebd034f  mov rsi, [r15+0x48]
0000710e9ebd0353  lea rdx, [rsi+r11*1]
0000710e9ebd0357  mov esi, [r13+rdx*1]
0000710e9ebd035c  mov edx, [rsp+0x30]
0000710e9ebd0360  mov ecx, [rsp+0x40]
0000710e9ebd0364  and edx, ecx
0000710e9ebd0366  mov [rsp+0x10], edx
0000710e9ebd036a  mov edx, edx
0000710e9ebd036c  mov [r15+0xD8], rdx
0000710e9ebd0373  lea edx, [r12d+r8d*1]
0000710e9ebd0378  mov r12d, [rsp+0x30]
0000710e9ebd037d  xor r12d, ecx
0000710e9ebd0380  rorx r8d, edi, 0x19
0000710e9ebd0386  xor r14d, r8d
0000710e9ebd0389  and r12d, r9d
0000710e9ebd038c  rorx r8d, r9d, 0x16
0000710e9ebd0392  xor r10d, r8d
0000710e9ebd0395  mov [rsp+0x20], r10d
0000710e9ebd039a  mov r10d, r10d
0000710e9ebd039d  mov [r15+0xD0], r10
0000710e9ebd03a4  lea r10d, [edx+esi*1]
0000710e9ebd03a9  mov r9d, [rsp+0x10]
0000710e9ebd03ae  xor r12d, r9d
0000710e9ebd03b1  lea r9d, [r10d+r14d*1]
0000710e9ebd03b6  lea r14, [r11+0x04]
0000710e9ebd03ba  mov [r15+0x88], r14
0000710e9ebd03c1  mov r11d, [rsp+0x20]
0000710e9ebd03c6  lea r10d, [r12d+r11d*1]
0000710e9ebd03cb  lea r11d, [r9d+eax*1]
0000710e9ebd03d0  mov r11d, r11d
0000710e9ebd03d3  mov [r15+0xB8], r11
0000710e9ebd03da  xor eax, eax
0000710e9ebd03dc  mov r12d, 0x100
0000710e9ebd03e2  cmp r14, r12
0000710e9ebd03e5  cmc
0000710e9ebd03e6  lahf
0000710e9ebd03e7  seto al
0000710e9ebd03ea  mov [r15+0x108], eax
0000710e9ebd03f1  lea eax, [r10d+r9d*1]
0000710e9ebd03f6  mov eax, eax
0000710e9ebd03f8  mov [r15+0xA8], rax
0000710e9ebd03ff  mov ebp, ebp
0000710e9ebd0401  mov [r15+0xB0], rbp
0000710e9ebd0408  mov eax, [rsp+0x50]
0000710e9ebd040c  mov eax, eax
0000710e9ebd040e  mov [r15+0xC0], rax
0000710e9ebd0415  mov edi, edi
0000710e9ebd0417  mov [r15+0xC8], rdi
0000710e9ebd041e  mov eax, [r15+0x108]
0000710e9ebd0425  sahf
0000710e9ebd0426  jnz 0x0000710E9EBD0458
0000710e9ebd0428  cmp dword ptr [r15+0x318], 0x00
0000710e9ebd0430  jz 0x0000710E9EBD04A0
0000710e9ebd0436  nop [rax+rax*1], ax
0000710e9ebd043f  nop [rax+rax*1], eax
0000710e9ebd0447  mov eax, 0x41094C
0000710e9ebd044c  mov [r15+0x100], rax
0000710e9ebd0453  jmp 0x0000710E9E9FE110
0000710e9ebd0458  cmp dword ptr [r15+0x318], 0x00
0000710e9ebd0460  jz 0x0000710E9EBD0270
0000710e9ebd0466  nop [rax+rax*1], ax
0000710e9ebd046f  nop [rax+rax*1], eax
0000710e9ebd0477  mov eax, 0x4108C0
0000710e9ebd047c  mov [r15+0x100], rax
0000710e9ebd0483  jmp 0x0000710E9E9FE110
0000710e9ebd0488  int3
0000710e9ebd0489  call 0x0000710E9EA49010
0000710e9ebd048e  jmp 0x0000710E9EBD031F
0000710e9ebd0493  call 0x0000710E9EA25930
0000710e9ebd0498  jmp 0x0000710E9EBD035C
0000710e9ebd049d  int3
0000710e9ebd049e  nop
0000710e9ebd04a0  mov eax, [r15+0x98]
0000710e9ebd04a7  mov r14d, [r15+0x70]
0000710e9ebd04ab  lea r12d, [eax+r14d*1]
0000710e9ebd04b0  mov eax, [r15+0x28]
0000710e9ebd04b4  mov r14d, [r15+0x68]
0000710e9ebd04b8  lea r11d, [eax+r14d*1]
0000710e9ebd04bd  mov qword ptr [r15+0x88], 0x00
0000710e9ebd04c8  mov eax, [r15+0xA8]
0000710e9ebd04cf  mov r14d, [r15+0x78]
0000710e9ebd04d3  lea r10d, [eax+r14d*1]
0000710e9ebd04d8  mov [rsp+0x10], r10d
0000710e9ebd04dd  mov r10d, r10d
0000710e9ebd04e0  mov [r15+0x78], r10
0000710e9ebd04e4  mov eax, [r15+0x38]
0000710e9ebd04e8  mov r14d, [r15+0x80]
0000710e9ebd04ef  lea r10d, [eax+r14d*1]
0000710e9ebd04f4  mov [rsp+0x20], r10d
0000710e9ebd04f9  mov r10d, r10d
0000710e9ebd04fc  mov [r15+0x80], r10
0000710e9ebd0503  mov rax, [r15]
0000710e9ebd0506  lea r14, [rax+0x08]
0000710e9ebd050a  mov [r13+r14*1], r12d
0000710e9ebd050f  lea r14, [rax+0x0C]
0000710e9ebd0513  mov [r13+r14*1], r11d
0000710e9ebd0518  mov r14d, [r15+0xB8]
0000710e9ebd051f  mov r12d, [r15+0x18]
0000710e9ebd0523  lea r11d, [r14d+r12d*1]
0000710e9ebd0528  mov [rsp+0x30], r11d
0000710e9ebd052d  mov r11d, r11d
0000710e9ebd0530  mov [r15+0x68], r11
0000710e9ebd0534  mov r14d, [r15+0x30]
0000710e9ebd0538  mov r12d, [r15+0x90]
0000710e9ebd053f  lea r11d, [r14d+r12d*1]
0000710e9ebd0544  mov [rsp+0x40], r11d
0000710e9ebd0549  mov r11d, r11d
0000710e9ebd054c  mov [r15+0x70], r11
0000710e9ebd0550  mov r14d, [r15+0x20]
0000710e9ebd0554  mov r12d, [r15+0x58]
0000710e9ebd0558  lea r11d, [r14d+r12d*1]
0000710e9ebd055d  mov [rsp+0x50], r11d
0000710e9ebd0562  mov r11d, r11d
0000710e9ebd0565  mov [r15+0x58], r11
0000710e9ebd0569  mov r14d, [r15+0xA0]
0000710e9ebd0570  mov r12d, [r15+0x60]
0000710e9ebd0574  lea r11d, [r14d+r12d*1]
0000710e9ebd0579  mov [rsp+0x60], r11d
0000710e9ebd057e  mov r11d, r11d
0000710e9ebd0581  mov [r15+0x60], r11
0000710e9ebd0585  mov r14d, [rsp+0x10]
0000710e9ebd058a  mov [r13+rax*1], r14d
0000710e9ebd058f  lea r14, [rax+0x04]
0000710e9ebd0593  mov r12d, [rsp+0x20]
0000710e9ebd0598  mov [r13+r14*1], r12d
0000710e9ebd059d  lea r14, [rax+0x10]
0000710e9ebd05a1  mov r12d, [rsp+0x30]
0000710e9ebd05a6  mov [r13+r14*1], r12d
0000710e9ebd05ab  lea r14, [rax+0x14]
0000710e9ebd05af  mov r12d, [rsp+0x40]
0000710e9ebd05b4  mov [r13+r14*1], r12d
0000710e9ebd05b9  lea r14, [rax+0x18]
0000710e9ebd05bd  mov r12d, [rsp+0x50]
0000710e9ebd05c2  mov [r13+r14*1], r12d
0000710e9ebd05c7  lea r14, [rax+0x1C]
0000710e9ebd05cb  mov r12d, [rsp+0x60]
0000710e9ebd05d0  mov [r13+r14*1], r12d
0000710e9ebd05d5  lea r14, [rax+0x68]
0000710e9ebd05d9  xor eax, eax
0000710e9ebd05db  mov [r13+r14*1], rax
0000710e9ebd05e0  cmp dword ptr [r15+0x318], 0x00
0000710e9ebd05e8  jz 0x0000710E9EBCF0E0
0000710e9ebd05ee  nop [rax+rax*1], ax
0000710e9ebd05f7  nop [rax+rax*1], eax
0000710e9ebd05ff  mov eax, 0x410768
0000710e9ebd0604  mov [r15+0x100], rax
0000710e9ebd060b  jmp 0x0000710E9E9FE110
0000710e9ebd0610  int3
0000710e9ebd0611  call 0x0000710E9EAE2BA0
0000710e9ebd0616  jmp 0x0000710E9EBD050F
0000710e9ebd061b  call 0x0000710E9EAE1920
0000710e9ebd0620  jmp 0x0000710E9EBD0518
0000710e9ebd0625  call 0x0000710E9EA0DFE0
0000710e9ebd062a  jmp 0x0000710E9EBD058F
0000710e9ebd062f  call 0x0000710E9EAE2BA0
0000710e9ebd0634  jmp 0x0000710E9EBD059D
0000710e9ebd0639  call 0x0000710E9EAE2BA0
0000710e9ebd063e  jmp 0x0000710E9EBD05AB
0000710e9ebd0643  call 0x0000710E9EAE2BA0
0000710e9ebd0648  jmp 0x0000710E9EBD05B9
0000710e9ebd064d  call 0x0000710E9EAE2BA0
0000710e9ebd0652  jmp 0x0000710E9EBD05C7
0000710e9ebd0657  call 0x0000710E9EAE2BA0
0000710e9ebd065c  jmp 0x0000710E9EBD05D5
0000710e9ebd0661  call 0x0000710E9EAD5EB0
0000710e9ebd0666  jmp 0x0000710E9EBD05E0
0000710e9ebd066b  int3
0000710e9ebd066c  nop [rax], eax
0000710e9ebd0670  mov rax, [r15+0xF8]
0000710e9ebd0677  lea r14, [rax+0x140]
0000710e9ebd067e  mov r12, [r13+r14*1]
0000710e9ebd0683  lea r14, [rax+0x148]
0000710e9ebd068a  mov r11, [r13+r14*1]
0000710e9ebd068f  mov [r15+0xA0], r12
0000710e9ebd0696  mov [r15+0x98], r11
0000710e9ebd069d  lea r14, [rax+0x130]
0000710e9ebd06a4  mov r12, [r13+r14*1]
0000710e9ebd06a9  lea r14, [rax+0x138]
0000710e9ebd06b0  mov r11, [r13+r14*1]
0000710e9ebd06b5  mov [r15+0xB0], r12
0000710e9ebd06bc  mov [r15+0xA8], r11
0000710e9ebd06c3  lea r14, [rax+0x120]
0000710e9ebd06ca  mov r12, [r13+r14*1]
0000710e9ebd06cf  lea r14, [rax+0x128]
0000710e9ebd06d6  mov r11, [r13+r14*1]
0000710e9ebd06db  mov [r15+0xC0], r12
0000710e9ebd06e2  mov [r15+0xB8], r11
0000710e9ebd06e9  lea r14, [rax+0x110]
0000710e9ebd06f0  mov r12, [r13+r14*1]
0000710e9ebd06f5  lea r14, [rax+0x118]
0000710e9ebd06fc  mov r11, [r13+r14*1]
0000710e9ebd0701  mov [r15+0xD0], r12
0000710e9ebd0708  mov [r15+0xC8], r11
0000710e9ebd070f  lea r14, [rax+0x100]
0000710e9ebd0716  mov r12, [r13+r14*1]
0000710e9ebd071b  lea r14, [rax+0x108]
0000710e9ebd0722  mov r11, [r13+r14*1]
0000710e9ebd0727  mov [r15+0xE8], r12
0000710e9ebd072e  mov [r15+0xD8], r11
0000710e9ebd0735  lea r14, [rax+0x150]
0000710e9ebd073c  mov [r15+0xF8], r14
0000710e9ebd0743  mov rax, [r15+0xF0]
0000710e9ebd074a  mov [r15+0x100], rax
0000710e9ebd0751  jmp 0x0000710E9EBCE5C0
0000710e9ebd0756  int3
0000710e9ebd0757  call 0x0000710E9EAE27E0
0000710e9ebd075c  jmp 0x0000710E9EBD0683
0000710e9ebd0761  call 0x0000710E9EAE1570
0000710e9ebd0766  jmp 0x0000710E9EBD068F
0000710e9ebd076b  call 0x0000710E9EAE27E0
0000710e9ebd0770  jmp 0x0000710E9EBD06A9
0000710e9ebd0775  call 0x0000710E9EAE1570
0000710e9ebd077a  jmp 0x0000710E9EBD06B5
0000710e9ebd077f  call 0x0000710E9EAE27E0
0000710e9ebd0784  jmp 0x0000710E9EBD06CF
0000710e9ebd0789  call 0x0000710E9EAE1570
0000710e9ebd078e  jmp 0x0000710E9EBD06DB
0000710e9ebd0793  call 0x0000710E9EAE27E0
0000710e9ebd0798  jmp 0x0000710E9EBD06F5
0000710e9ebd079d  call 0x0000710E9EAE1570
0000710e9ebd07a2  jmp 0x0000710E9EBD0701
0000710e9ebd07a7  call 0x0000710E9EAE27E0
0000710e9ebd07ac  jmp 0x0000710E9EBD071B
0000710e9ebd07b1  call 0x0000710E9EAE1570
0000710e9ebd07b6  jmp 0x0000710E9EBD0727
0000710e9ebd07bb  int3
0000710e9ebd07bc  nop [rax], eax
0000710e9ebd07c0  mov eax, [r15+0xA0]
0000710e9ebd07c7  mov [rsp+0x10], eax
0000710e9ebd07cb  xor eax, eax
0000710e9ebd07cd  mov r14d, [rsp+0x10]
0000710e9ebd07d2  sub r14d, 0x01
0000710e9ebd07d6  cmc
0000710e9ebd07d7  lahf
0000710e9ebd07d8  seto al
0000710e9ebd07db  mov [r15+0x108], eax
0000710e9ebd07e2  mov r14d, r14d
0000710e9ebd07e5  mov [r15+0xA0], r14
0000710e9ebd07ec  mov eax, [r15+0x108]
0000710e9ebd07f3  sahf
0000710e9ebd07f4  jnz 0x0000710E9EBD0826
0000710e9ebd07f6  cmp dword ptr [r15+0x318], 0x00
0000710e9ebd07fe  jz 0x0000710E9EBD0900
0000710e9ebd0804  nop [rax+rax*1], ax
0000710e9ebd080d  nop [rax+rax*1], eax
0000710e9ebd0815  mov eax, 0x41028C
0000710e9ebd081a  mov [r15+0x100], rax
0000710e9ebd0821  jmp 0x0000710E9E9FE110
0000710e9ebd0826  cmp dword ptr [r15+0x318], 0x00
0000710e9ebd082e  jz 0x0000710E9EBD0860
0000710e9ebd0834  nop [rax+rax*1], ax
0000710e9ebd083d  nop [rax+rax*1], eax
0000710e9ebd0845  mov eax, 0x410274
0000710e9ebd084a  mov [r15+0x100], rax
0000710e9ebd0851  jmp 0x0000710E9E9FE110
0000710e9ebd0856  int3
0000710e9ebd0857  int3
0000710e9ebd0858  nop [rax+rax*1], eax
0000710e9ebd0860  mov rax, [r15+0xF8]
0000710e9ebd0867  lea r14, [rax+0x100]
0000710e9ebd086e  mov [r15], r14
0000710e9ebd0871  mov rax, [r15+0x98]
0000710e9ebd0878  mov [r15+0x08], rax
0000710e9ebd087c  mov qword ptr [r15+0x10], 0x12C
0000710e9ebd0884  mov qword ptr [r15+0xF0], 0x410284
0000710e9ebd088f  mov r14d, [r15+0x320]
0000710e9ebd0896  mov eax, 0x410284
0000710e9ebd089b  mov rcx, 0x710E9EBD07C0
0000710e9ebd08a5  mov [r15+r14*8+0x328], rax
0000710e9ebd08ad  mov [r15+r14*8+0x368], rcx
0000710e9ebd08b5  add r14d, 0x01
0000710e9ebd08b9  and r14d, 0x07
0000710e9ebd08bd  mov [r15+0x320], r14d
0000710e9ebd08c4  cmp dword ptr [r15+0x318], 0x00
0000710e9ebd08cc  jz 0x0000710E9EBCED70
0000710e9ebd08d2  nop [rax+rax*1], ax
0000710e9ebd08db  nop [rax+rax*1], eax
0000710e9ebd08e3  mov eax, 0x410728
0000710e9ebd08e8  mov [r15+0x100], rax
0000710e9ebd08ef  jmp 0x0000710E9E9FE110
0000710e9ebd08f4  int3
0000710e9ebd08f5  int3
0000710e9ebd08f6  nop [rax+rax*1], ax
0000710e9ebd08ff  nop
0000710e9ebd0900  mov rax, [r15+0xF8]
0000710e9ebd0907  lea r14, [rax+0x120]
0000710e9ebd090e  mov r12, [r13+r14*1]
0000710e9ebd0913  mov [r15+0x98], r12
0000710e9ebd091a  mov qword ptr [r15+0x40], 0x80
0000710e9ebd0922  lea r14, [rax+0x100]
0000710e9ebd0929  mov [r15], r14
0000710e9ebd092c  lea r14, [rax+0x17C]
0000710e9ebd0933  mov [r15+0x08], r14
0000710e9ebd0937  mov qword ptr [r15+0x10], 0x01
0000710e9ebd093f  lea r14, [rax+0x17C]
0000710e9ebd0946  mov eax, 0x80
0000710e9ebd094b  mov [r13+r14*1], al
0000710e9ebd0950  mov qword ptr [r15+0xF0], 0x4102A8
0000710e9ebd095b  mov r14d, [r15+0x320]
0000710e9ebd0962  mov eax, 0x4102A8
0000710e9ebd0967  mov rcx, 0x710E9EBD09E0
0000710e9ebd0971  mov [r15+r14*8+0x328], rax
0000710e9ebd0979  mov [r15+r14*8+0x368], rcx
0000710e9ebd0981  add r14d, 0x01
0000710e9ebd0985  and r14d, 0x07
0000710e9ebd0989  mov [r15+0x320], r14d
0000710e9ebd0990  cmp dword ptr [r15+0x318], 0x00
0000710e9ebd0998  jz 0x0000710E9EBCED70
0000710e9ebd099e  nop [rax+rax*1], ax
0000710e9ebd09a7  nop [rax+rax*1], eax
0000710e9ebd09af  mov eax, 0x410728
0000710e9ebd09b4  mov [r15+0x100], rax
0000710e9ebd09bb  jmp 0x0000710E9E9FE110
0000710e9ebd09c0  int3
0000710e9ebd09c1  call 0x0000710E9EAE27E0
0000710e9ebd09c6  jmp 0x0000710E9EBD0913
0000710e9ebd09cb  call 0x0000710E9EAD5AF0
0000710e9ebd09d0  jmp 0x0000710E9EBD0950
0000710e9ebd09d5  int3
0000710e9ebd09d6  nop [rax+rax*1], ax
0000710e9ebd09df  nop
0000710e9ebd09e0  mov rax, [r15+0xF8]
0000710e9ebd09e7  lea r14, [rax+0x168]
0000710e9ebd09ee  mov r12, [r13+r14*1]
0000710e9ebd09f3  mov [r15+0x40], r12
0000710e9ebd09f7  lea r14, [rax+0x178]
0000710e9ebd09fe  xor eax, eax
0000710e9ebd0a00  mov [r13+r14*1], al
0000710e9ebd0a05  xor eax, eax
0000710e9ebd0a07  mov r14d, 0x38
0000710e9ebd0a0d  cmp r12, r14
0000710e9ebd0a10  cmc
0000710e9ebd0a11  lahf
0000710e9ebd0a12  seto al
0000710e9ebd0a15  mov [r15+0x108], eax
0000710e9ebd0a1c  mov eax, [r15+0x108]
0000710e9ebd0a23  sahf
0000710e9ebd0a24  jz 0x0000710E9EBD0A56
0000710e9ebd0a26  cmp dword ptr [r15+0x318], 0x00
0000710e9ebd0a2e  jz 0x0000710E9EBD0AA0
0000710e9ebd0a34  nop [rax+rax*1], ax
0000710e9ebd0a3d  nop [rax+rax*1], eax
0000710e9ebd0a45  mov eax, 0x4102B8
0000710e9ebd0a4a  mov [r15+0x100], rax
0000710e9ebd0a51  jmp 0x0000710E9E9FE110
0000710e9ebd0a56  cmp dword ptr [r15+0x318], 0x00
0000710e9ebd0a5e  jz 0x0000710E9EBD0BF0
0000710e9ebd0a64  nop [rax+rax*1], ax
0000710e9ebd0a6d  nop [rax+rax*1], eax
0000710e9ebd0a75  mov eax, 0x4102D4
0000710e9ebd0a7a  mov [r15+0x100], rax
0000710e9ebd0a81  jmp 0x0000710E9E9FE110
0000710e9ebd0a86  int3
0000710e9ebd0a87  call 0x0000710E9EAE27E0
0000710e9ebd0a8c  jmp 0x0000710E9EBD09F3
0000710e9ebd0a91  call 0x0000710E9EAD5AF0
0000710e9ebd0a96  jmp 0x0000710E9EBD0A05
0000710e9ebd0a9b  int3
0000710e9ebd0a9c  nop [rax], eax
0000710e9ebd0aa0  mov rax, [r15+0xF8]
0000710e9ebd0aa7  lea r14, [rax+0x100]
0000710e9ebd0aae  mov [r15], r14
0000710e9ebd0ab1  lea r14, [rax+0x178]
0000710e9ebd0ab8  mov [r15+0x08], r14
0000710e9ebd0abc  mov qword ptr [r15+0x10], 0x01
0000710e9ebd0ac4  mov qword ptr [r15+0xF0], 0x4102C8
0000710e9ebd0acf  mov r14d, [r15+0x320]
0000710e9ebd0ad6  mov eax, 0x4102C8
0000710e9ebd0adb  mov rcx, 0x710E9EBD0B40
0000710e9ebd0ae5  mov [r15+r14*8+0x328], rax
0000710e9ebd0aed  mov [r15+r14*8+0x368], rcx
0000710e9ebd0af5  add r14d, 0x01
0000710e9ebd0af9  and r14d, 0x07
0000710e9ebd0afd  mov [r15+0x320], r14d
0000710e9ebd0b04  cmp dword ptr [r15+0x318], 0x00
0000710e9ebd0b0c  jz 0x0000710E9EBCED70
0000710e9ebd0b12  nop [rax+rax*1], ax
0000710e9ebd0b1b  nop [rax+rax*1], eax
0000710e9ebd0b23  mov eax, 0x410728
0000710e9ebd0b28  mov [r15+0x100], rax
0000710e9ebd0b2f  jmp 0x0000710E9E9FE110
0000710e9ebd0b34  int3
0000710e9ebd0b35  int3
0000710e9ebd0b36  nop [rax+rax*1], ax
0000710e9ebd0b3f  nop
0000710e9ebd0b40  mov rax, [r15+0xF8]
0000710e9ebd0b47  lea r14, [rax+0x168]
0000710e9ebd0b4e  mov rax, [r13+r14*1]
0000710e9ebd0b53  mov [r15+0x40], rax
0000710e9ebd0b57  mov [rsp+0x10], rax
0000710e9ebd0b5c  xor eax, eax
0000710e9ebd0b5e  mov r14, [rsp+0x10]
0000710e9ebd0b63  mov r12d, 0x38
0000710e9ebd0b69  cmp r14, r12
0000710e9ebd0b6c  cmc
0000710e9ebd0b6d  lahf
0000710e9ebd0b6e  seto al
0000710e9ebd0b71  mov [r15+0x108], eax
0000710e9ebd0b78  mov eax, [r15+0x108]
0000710e9ebd0b7f  sahf
0000710e9ebd0b80  jnz 0x0000710E9EBD0BB2
0000710e9ebd0b82  cmp dword ptr [r15+0x318], 0x00
0000710e9ebd0b8a  jz 0x0000710E9EBD0BF0
0000710e9ebd0b90  nop [rax+rax*1], ax
0000710e9ebd0b99  nop [rax+rax*1], eax
0000710e9ebd0ba1  mov eax, 0x4102D4
0000710e9ebd0ba6  mov [r15+0x100], rax
0000710e9ebd0bad  jmp 0x0000710E9E9FE110
0000710e9ebd0bb2  cmp dword ptr [r15+0x318], 0x00
0000710e9ebd0bba  jz 0x0000710E9EBD0AA0
0000710e9ebd0bc0  nop [rax+rax*1], ax
0000710e9ebd0bc9  nop [rax+rax*1], eax
0000710e9ebd0bd1  mov eax, 0x4102B8
0000710e9ebd0bd6  mov [r15+0x100], rax
0000710e9ebd0bdd  jmp 0x0000710E9E9FE110
0000710e9ebd0be2  int3
0000710e9ebd0be3  call 0x0000710E9EAD59C0
0000710e9ebd0be8  jmp 0x0000710E9EBD0B53
0000710e9ebd0bed  int3
0000710e9ebd0bee  nop
0000710e9ebd0bf0  mov rax, [r15+0x98]
0000710e9ebd0bf7  rorx r14, rax, 0x3D
0000710e9ebd0bfd  and r14, 0xFFFFFFFFFFFFFFF8
0000710e9ebd0c01  mov rax, [r15+0xF8]
0000710e9ebd0c08  lea r12, [rax+0x100]
0000710e9ebd0c0f  mov [r15], r12
0000710e9ebd0c12  lea r12, [rax+0x170]
0000710e9ebd0c19  mov [r15+0x08], r12
0000710e9ebd0c1d  mov qword ptr [r15+0x10], 0x08
0000710e9ebd0c25  bswap r14
0000710e9ebd0c28  mov [r15+0x40], r14
0000710e9ebd0c2c  lea r12, [rax+0x170]
0000710e9ebd0c33  mov [r13+r12*1], r14
0000710e9ebd0c38  mov qword ptr [r15+0xF0], 0x4102F0
0000710e9ebd0c43  mov r14d, [r15+0x320]
0000710e9ebd0c4a  mov eax, 0x4102F0
0000710e9ebd0c4f  mov rcx, 0x710E9EBD0CC0
0000710e9ebd0c59  mov [r15+r14*8+0x328], rax
0000710e9ebd0c61  mov [r15+r14*8+0x368], rcx
0000710e9ebd0c69  add r14d, 0x01
0000710e9ebd0c6d  and r14d, 0x07
0000710e9ebd0c71  mov [r15+0x320], r14d
0000710e9ebd0c78  cmp dword ptr [r15+0x318], 0x00
0000710e9ebd0c80  jz 0x0000710E9EBCED70
0000710e9ebd0c86  nop [rax+rax*1], ax
0000710e9ebd0c8f  nop [rax+rax*1], eax
0000710e9ebd0c97  mov eax, 0x410728
0000710e9ebd0c9c  mov [r15+0x100], rax
0000710e9ebd0ca3  jmp 0x0000710E9E9FE110
0000710e9ebd0ca8  int3
0000710e9ebd0ca9  call 0x0000710E9EAC3FE0
0000710e9ebd0cae  jmp 0x0000710E9EBD0C38
0000710e9ebd0cb3  int3
0000710e9ebd0cb4  nop [rax+rax*1], ax
0000710e9ebd0cbd  nop [rax], eax
0000710e9ebd0cc0  mov rax, [r15+0xF8]
0000710e9ebd0cc7  lea r14, [rax+0x100]
0000710e9ebd0cce  mov r12d, [r13+r14*1]
0000710e9ebd0cd3  lea r14, [rax+0x104]
0000710e9ebd0cda  mov r11d, [r13+r14*1]
0000710e9ebd0cdf  mov qword ptr [r15+0x48], 0x430C90
0000710e9ebd0ce7  lea r14, [rax+0x108]
0000710e9ebd0cee  mov r10d, [r13+r14*1]
0000710e9ebd0cf3  lea r14, [rax+0x10C]
0000710e9ebd0cfa  mov r9d, [r13+r14*1]
0000710e9ebd0cff  bswap r12d
0000710e9ebd0d02  bswap r11d
0000710e9ebd0d05  mov qword ptr [r15+0xA0], 0x00
0000710e9ebd0d10  mov r14d, 0x430C90
0000710e9ebd0d16  mov [r13+r14*1], r12d
0000710e9ebd0d1b  mov r14d, 0x430C94
0000710e9ebd0d21  mov [r13+r14*1], r11d
0000710e9ebd0d26  bswap r10d
0000710e9ebd0d29  lea r14, [rax+0x110]
0000710e9ebd0d30  mov r12d, [r13+r14*1]
0000710e9ebd0d35  bswap r9d
0000710e9ebd0d38  lea r14, [rax+0x114]
0000710e9ebd0d3f  mov r11d, [r13+r14*1]
0000710e9ebd0d44  mov qword ptr [r15+0x98], 0x430DFC
0000710e9ebd0d4f  mov r14d, 0x430C98
0000710e9ebd0d55  mov [r13+r14*1], r10d
0000710e9ebd0d5a  mov r14d, 0x430C9C
0000710e9ebd0d60  mov [r13+r14*1], r9d
0000710e9ebd0d65  bswap r12d
0000710e9ebd0d68  lea r14, [rax+0x118]
0000710e9ebd0d6f  mov r10d, [r13+r14*1]
0000710e9ebd0d74  bswap r11d
0000710e9ebd0d77  mov [rsp+0x10], r11d
0000710e9ebd0d7c  mov r11d, r11d
0000710e9ebd0d7f  mov [r15+0x58], r11
0000710e9ebd0d83  lea r14, [rax+0x11C]
0000710e9ebd0d8a  mov eax, [r13+r14*1]
0000710e9ebd0d8f  mov [rsp+0x20], eax
0000710e9ebd0d93  mov eax, eax
0000710e9ebd0d95  mov [r15+0x60], rax
0000710e9ebd0d99  mov eax, 0x430CA0
0000710e9ebd0d9e  mov [r13+rax*1], r12d
0000710e9ebd0da3  mov eax, 0x430CA4
0000710e9ebd0da8  mov r14d, [rsp+0x10]
0000710e9ebd0dad  mov [r13+rax*1], r14d
0000710e9ebd0db2  bswap r10d
0000710e9ebd0db5  mov [rsp+0x10], r10d
0000710e9ebd0dba  mov r10d, r10d
0000710e9ebd0dbd  mov [r15+0x40], r10
0000710e9ebd0dc1  mov eax, [rsp+0x20]
0000710e9ebd0dc5  bswap eax
0000710e9ebd0dc7  mov [rsp+0x20], eax
0000710e9ebd0dcb  mov eax, eax
0000710e9ebd0dcd  mov [r15+0x50], rax
0000710e9ebd0dd1  mov eax, 0x430CA8
0000710e9ebd0dd6  mov r14d, [rsp+0x10]
0000710e9ebd0ddb  mov [r13+rax*1], r14d
0000710e9ebd0de0  mov eax, 0x430CAC
0000710e9ebd0de5  mov r14d, [rsp+0x20]
0000710e9ebd0dea  mov [r13+rax*1], r14d
0000710e9ebd0def  mov eax, [r15+0xA0]
0000710e9ebd0df6  lea r14d, [eax+0x11]
0000710e9ebd0dfb  mov r14d, r14d
0000710e9ebd0dfe  mov [r15], r14
0000710e9ebd0e01  mov qword ptr [r15+0xF0], 0x41035C
0000710e9ebd0e0c  mov r14d, [r15+0x320]
0000710e9ebd0e13  mov eax, 0x41035C
0000710e9ebd0e18  mov rcx, 0x710E9EBD0F90
0000710e9ebd0e22  mov [r15+r14*8+0x328], rax
0000710e9ebd0e2a  mov [r15+r14*8+0x368], rcx
0000710e9ebd0e32  add r14d, 0x01
0000710e9ebd0e36  and r14d, 0x07
0000710e9ebd0e3a  mov [r15+0x320], r14d
0000710e9ebd0e41  cmp dword ptr [r15+0x318], 0x00
0000710e9ebd0e49  jz 0x0000710E9EBD0F20
0000710e9ebd0e4f  nop [rax+rax*1], ax
0000710e9ebd0e58  nop [rax+rax*1], eax
0000710e9ebd0e60  mov eax, 0x4109A4
0000710e9ebd0e65  mov [r15+0x100], rax
0000710e9ebd0e6c  jmp 0x0000710E9E9FE110
0000710e9ebd0e71  int3
0000710e9ebd0e72  call 0x0000710E9EAE26A0
0000710e9ebd0e77  jmp 0x0000710E9EBD0CD3
0000710e9ebd0e7c  call 0x0000710E9EAE1430
0000710e9ebd0e81  jmp 0x0000710E9EBD0CDF
0000710e9ebd0e86  call 0x0000710E9EAE01C0
0000710e9ebd0e8b  jmp 0x0000710E9EBD0CF3
0000710e9ebd0e90  call 0x0000710E9EADEF50
0000710e9ebd0e95  jmp 0x0000710E9EBD0CFF
0000710e9ebd0e9a  call 0x0000710E9EAE2BA0
0000710e9ebd0e9f  jmp 0x0000710E9EBD0D1B
0000710e9ebd0ea4  call 0x0000710E9EAE1920
0000710e9ebd0ea9  jmp 0x0000710E9EBD0D26
0000710e9ebd0eae  call 0x0000710E9EAE26A0
0000710e9ebd0eb3  jmp 0x0000710E9EBD0D35
0000710e9ebd0eb8  call 0x0000710E9EAE1430
0000710e9ebd0ebd  jmp 0x0000710E9EBD0D44
0000710e9ebd0ec2  call 0x0000710E9EAE06B0
0000710e9ebd0ec7  jmp 0x0000710E9EBD0D5A
0000710e9ebd0ecc  call 0x0000710E9EADF440
0000710e9ebd0ed1  jmp 0x0000710E9EBD0D65
0000710e9ebd0ed6  call 0x0000710E9EAE01C0
0000710e9ebd0edb  jmp 0x0000710E9EBD0D74
0000710e9ebd0ee0  call 0x0000710E9EAD5890
0000710e9ebd0ee5  jmp 0x0000710E9EBD0D8F
0000710e9ebd0eea  call 0x0000710E9EA0BAE0
0000710e9ebd0eef  jmp 0x0000710E9EBD0DA3
0000710e9ebd0ef4  call 0x0000710E9EA0DFE0
0000710e9ebd0ef9  jmp 0x0000710E9EBD0DB2
0000710e9ebd0efe  call 0x0000710E9EA0DFE0
0000710e9ebd0f03  jmp 0x0000710E9EBD0DE0
0000710e9ebd0f08  call 0x0000710E9EA0DFE0
0000710e9ebd0f0d  jmp 0x0000710E9EBD0DEF
0000710e9ebd0f12  int3
0000710e9ebd0f13  nop [rax+rax*1], ax
0000710e9ebd0f1c  nop [rax], eax
0000710e9ebd0f20  mov eax, [r15]
0000710e9ebd0f23  mov [rsp+0x10], eax
0000710e9ebd0f27  shr eax, 0x10
0000710e9ebd0f2a  mov r14d, [rsp+0x10]
0000710e9ebd0f2f  xor r14d, eax
0000710e9ebd0f32  imul r14d, r14d, 0x7FEB352D
0000710e9ebd0f39  mov eax, 0x846CA68B
0000710e9ebd0f3e  mov eax, eax
0000710e9ebd0f40  mov [r15+0x48], rax
0000710e9ebd0f44  mov [rsp+0x10], r14d
0000710e9ebd0f49  shr r14d, 0x0F
0000710e9ebd0f4d  mov eax, [rsp+0x10]
0000710e9ebd0f51  xor eax, r14d
0000710e9ebd0f54  imul eax, eax, 0x846CA68B
0000710e9ebd0f5a  mov [rsp+0x10], eax
0000710e9ebd0f5e  mov eax, eax
0000710e9ebd0f60  mov [r15+0x40], rax
0000710e9ebd0f64  mov eax, [rsp+0x10]
0000710e9ebd0f68  shr eax, 0x10
0000710e9ebd0f6b  mov r14d, [rsp+0x10]
0000710e9ebd0f70  xor r14d, eax
0000710e9ebd0f73  mov r14d, r14d
0000710e9ebd0f76  mov [r15], r14
0000710e9ebd0f79  mov rax, [r15+0xF0]
0000710e9ebd0f80  mov [r15+0x100], rax
0000710e9ebd0f87  jmp 0x0000710E9EBCE5C0
0000710e9ebd0f8c  int3
0000710e9ebd0f8d  int3
0000710e9ebd0f8e  nop
0000710e9ebd0f90  mov rax, [r15+0xA0]
0000710e9ebd0f97  mov [rsp+0x10], rax
0000710e9ebd0f9c  shl rax, 0x02
0000710e9ebd0fa0  mov r14, [r15+0x98]
0000710e9ebd0fa7  lea r12, [r14+rax*1]
0000710e9ebd0fab  mov eax, [r15]
0000710e9ebd0fae  mov [r13+r12*1], eax
0000710e9ebd0fb3  mov rax, [rsp+0x10]
0000710e9ebd0fb8  lea r14, [rax+0x01]
0000710e9ebd0fbc  mov [r15+0xA0], r14
0000710e9ebd0fc3  xor eax, eax
0000710e9ebd0fc5  mov r12d, 0x400
0000710e9ebd0fcb  cmp r14, r12
0000710e9ebd0fce  cmc
0000710e9ebd0fcf  lahf
0000710e9ebd0fd0  seto al
0000710e9ebd0fd3  mov [r15+0x108], eax
0000710e9ebd0fda  mov eax, [r15+0x108]
0000710e9ebd0fe1  sahf
0000710e9ebd0fe2  jnz 0x0000710E9EBD1014
0000710e9ebd0fe4  cmp dword ptr [r15+0x318], 0x00
0000710e9ebd0fec  jz 0x0000710E9EBD10E0
0000710e9ebd0ff2  nop [rax+rax*1], ax
0000710e9ebd0ffb  nop [rax+rax*1], eax
0000710e9ebd1003  mov eax, 0x41036C
0000710e9ebd1008  mov [r15+0x100], rax
0000710e9ebd100f  jmp 0x0000710E9E9FE110
0000710e9ebd1014  cmp dword ptr [r15+0x318], 0x00
0000710e9ebd101c  jz 0x0000710E9EBD1050
0000710e9ebd1022  nop [rax+rax*1], ax
0000710e9ebd102b  nop [rax+rax*1], eax
0000710e9ebd1033  mov eax, 0x410354
0000710e9ebd1038  mov [r15+0x100], rax
0000710e9ebd103f  jmp 0x0000710E9E9FE110
0000710e9ebd1044  int3
0000710e9ebd1045  call 0x0000710E9EAB4B70
0000710e9ebd104a  jmp 0x0000710E9EBD0FB3
0000710e9ebd104f  int3
0000710e9ebd1050  mov eax, [r15+0xA0]
0000710e9ebd1057  lea r14d, [eax+0x11]
0000710e9ebd105c  mov r14d, r14d
0000710e9ebd105f  mov [r15], r14
0000710e9ebd1062  mov qword ptr [r15+0xF0], 0x41035C
0000710e9ebd106d  mov r14d, [r15+0x320]
0000710e9ebd1074  mov eax, 0x41035C
0000710e9ebd1079  mov rcx, 0x710E9EBD0F90
0000710e9ebd1083  mov [r15+r14*8+0x328], rax
0000710e9ebd108b  mov [r15+r14*8+0x368], rcx
0000710e9ebd1093  add r14d, 0x01
0000710e9ebd1097  and r14d, 0x07
0000710e9ebd109b  mov [r15+0x320], r14d
0000710e9ebd10a2  cmp dword ptr [r15+0x318], 0x00
0000710e9ebd10aa  jz 0x0000710E9EBD0F20
0000710e9ebd10b0  nop [rax+rax*1], ax
0000710e9ebd10b9  nop [rax+rax*1], eax
0000710e9ebd10c1  mov eax, 0x4109A4
0000710e9ebd10c6  mov [r15+0x100], rax
0000710e9ebd10cd  jmp 0x0000710E9E9FE110
0000710e9ebd10d2  int3
0000710e9ebd10d3  int3
0000710e9ebd10d4  nop [rax+rax*1], ax
0000710e9ebd10dd  nop [rax], eax
0000710e9ebd10e0  mov qword ptr [r15+0x40], 0x01
0000710e9ebd10e8  cmp dword ptr [r15+0x318], 0x00
0000710e9ebd10f0  jz 0x0000710E9EBD1120
0000710e9ebd10f6  nop [rax+rax*1], ax
0000710e9ebd10ff  nop [rax+rax*1], eax
0000710e9ebd1107  mov eax, 0x410388
0000710e9ebd110c  mov [r15+0x100], rax
0000710e9ebd1113  jmp 0x0000710E9E9FE110
0000710e9ebd1118  int3
0000710e9ebd1119  int3
0000710e9ebd111a  nop [rax+rax*1], ax
0000710e9ebd1120  mov rax, [r15+0x40]
0000710e9ebd1124  mov [rsp+0x10], rax
0000710e9ebd1129  shl rax, 0x02
0000710e9ebd112d  mov r14, [r15+0x98]
0000710e9ebd1134  lea r12, [r14+rax*1]
0000710e9ebd1138  mov eax, [r13+r12*1]
0000710e9ebd113d  mov [rsp+0x20], eax
0000710e9ebd1141  mov eax, eax
0000710e9ebd1143  mov [r15+0x48], rax
0000710e9ebd1147  mov rax, [rsp+0x10]
0000710e9ebd114c  mov [r15+0x50], rax
0000710e9ebd1150  mov eax, [r15+0x50]
0000710e9ebd1154  lea r12d, [eax-0x01]
0000710e9ebd1159  mov r12d, r12d
0000710e9ebd115c  mov [r15+0x58], r12
0000710e9ebd1160  mov rax, [r15+0x58]
0000710e9ebd1164  mov r12d, eax
0000710e9ebd1167  mov r12d, r12d
0000710e9ebd116a  shl r12, 0x02
0000710e9ebd116e  lea rax, [r14+r12*1]
0000710e9ebd1172  mov r14d, [r13+rax*1]
0000710e9ebd1177  mov [rsp+0x10], r14d
0000710e9ebd117c  mov r14d, r14d
0000710e9ebd117f  mov [r15+0x60], r14
0000710e9ebd1183  xor eax, eax
0000710e9ebd1185  mov r14d, [rsp+0x10]
0000710e9ebd118a  mov r12d, [rsp+0x20]
0000710e9ebd118f  cmp r14d, r12d
0000710e9ebd1192  cmc
0000710e9ebd1193  lahf
0000710e9ebd1194  seto al
0000710e9ebd1197  mov [r15+0x108], eax
0000710e9ebd119e  mov eax, [r15+0x108]
0000710e9ebd11a5  sahf
0000710e9ebd11a6  cmc
0000710e9ebd11a7  jbe 0x0000710E9EBD11D9
0000710e9ebd11a9  cmp dword ptr [r15+0x318], 0x00
0000710e9ebd11b1  jz 0x0000710E9EBD1220
0000710e9ebd11b7  nop [rax+rax*1], ax
0000710e9ebd11c0  nop [rax+rax*1], eax
0000710e9ebd11c8  mov eax, 0x4103A0
0000710e9ebd11cd  mov [r15+0x100], rax
0000710e9ebd11d4  jmp 0x0000710E9E9FE110
0000710e9ebd11d9  cmp dword ptr [r15+0x318], 0x00
0000710e9ebd11e1  jz 0x0000710E9EBD14C0
0000710e9ebd11e7  nop [rax+rax*1], ax
0000710e9ebd11f0  nop [rax+rax*1], eax
0000710e9ebd11f8  mov eax, 0x410378
0000710e9ebd11fd  mov [r15+0x100], rax
0000710e9ebd1204  jmp 0x0000710E9E9FE110
0000710e9ebd1209  int3
0000710e9ebd120a  call 0x0000710E9EAB4690
0000710e9ebd120f  jmp 0x0000710E9EBD113D
0000710e9ebd1214  call 0x0000710E9EA0DAE0
0000710e9ebd1219  jmp 0x0000710E9EBD1177
0000710e9ebd121e  int3
0000710e9ebd121f  nop
0000710e9ebd1220  mov rax, [r15+0x50]
0000710e9ebd1224  mov [rsp+0x10], rax
0000710e9ebd1229  shl rax, 0x02
0000710e9ebd122d  mov r14, [r15+0x98]
0000710e9ebd1234  lea r12, [r14+rax*1]
0000710e9ebd1238  mov eax, [r15+0x60]
0000710e9ebd123c  mov [r13+r12*1], eax
0000710e9ebd1241  mov rax, [rsp+0x10]
0000710e9ebd1246  lea r14, [rax-0x01]
0000710e9ebd124a  mov [r15+0x50], r14
0000710e9ebd124e  mov rax, [r15+0x58]
0000710e9ebd1252  test rax, rax
0000710e9ebd1255  setz al
0000710e9ebd1258  movzx rax, al
0000710e9ebd125c  mov [rsp+0x414], al
0000710e9ebd1263  cmp byte ptr [rsp+0x414], 0x00
0000710e9ebd126b  jz 0x0000710E9EBD129D
0000710e9ebd126d  cmp dword ptr [r15+0x318], 0x00
0000710e9ebd1275  jz 0x0000710E9EBD12E0
0000710e9ebd127b  nop [rax+rax*1], ax
0000710e9ebd1284  nop [rax+rax*1], eax
0000710e9ebd128c  mov eax, 0x4103AC
0000710e9ebd1291  mov [r15+0x100], rax
0000710e9ebd1298  jmp 0x0000710E9E9FE110
0000710e9ebd129d  cmp dword ptr [r15+0x318], 0x00
0000710e9ebd12a5  jz 0x0000710E9EBD13E0
0000710e9ebd12ab  nop [rax+rax*1], ax
0000710e9ebd12b4  nop [rax+rax*1], eax
0000710e9ebd12bc  mov eax, 0x410390
0000710e9ebd12c1  mov [r15+0x100], rax
0000710e9ebd12c8  jmp 0x0000710E9E9FE110
0000710e9ebd12cd  int3
0000710e9ebd12ce  call 0x0000710E9EAB4B70
0000710e9ebd12d3  jmp 0x0000710E9EBD1241
0000710e9ebd12d8  int3
0000710e9ebd12d9  nop [rax], eax
0000710e9ebd12e0  cmp dword ptr [r15+0x318], 0x00
0000710e9ebd12e8  jz 0x0000710E9EBD1320
0000710e9ebd12ee  nop [rax+rax*1], ax
0000710e9ebd12f7  nop [rax+rax*1], eax
0000710e9ebd12ff  mov eax, 0x410374
0000710e9ebd1304  mov [r15+0x100], rax
0000710e9ebd130b  jmp 0x0000710E9E9FE110
0000710e9ebd1310  int3
0000710e9ebd1311  int3
0000710e9ebd1312  nop [rax+rax*1], ax
0000710e9ebd131b  nop [rax+rax*1], eax
0000710e9ebd1320  mov qword ptr [r15+0x50], 0x00
0000710e9ebd1328  mov rax, [r15+0x40]
0000710e9ebd132c  lea r14, [rax+0x01]
0000710e9ebd1330  mov [r15+0x40], r14
0000710e9ebd1334  mov rax, [r15+0x98]
0000710e9ebd133b  mov r12d, [r15+0x48]
0000710e9ebd133f  mov [r13+rax*1], r12d
0000710e9ebd1344  xor eax, eax
0000710e9ebd1346  mov r12d, 0x400
0000710e9ebd134c  cmp r14, r12
0000710e9ebd134f  cmc
0000710e9ebd1350  lahf
0000710e9ebd1351  seto al
0000710e9ebd1354  mov [r15+0x108], eax
0000710e9ebd135b  mov eax, [r15+0x108]
0000710e9ebd1362  sahf
0000710e9ebd1363  jz 0x0000710E9EBD1395
0000710e9ebd1365  cmp dword ptr [r15+0x318], 0x00
0000710e9ebd136d  jz 0x0000710E9EBD1120
0000710e9ebd1373  nop [rax+rax*1], ax
0000710e9ebd137c  nop [rax+rax*1], eax
0000710e9ebd1384  mov eax, 0x410388
0000710e9ebd1389  mov [r15+0x100], rax
0000710e9ebd1390  jmp 0x0000710E9E9FE110
0000710e9ebd1395  cmp dword ptr [r15+0x318], 0x00
0000710e9ebd139d  jz 0x0000710E9EBD1580
0000710e9ebd13a3  nop [rax+rax*1], ax
0000710e9ebd13ac  nop [rax+rax*1], eax
0000710e9ebd13b4  mov eax, 0x4103B0
0000710e9ebd13b9  mov [r15+0x100], rax
0000710e9ebd13c0  jmp 0x0000710E9E9FE110
0000710e9ebd13c5  int3
0000710e9ebd13c6  call 0x0000710E9EA0BAE0
0000710e9ebd13cb  jmp 0x0000710E9EBD1344
0000710e9ebd13d0  int3
0000710e9ebd13d1  nop [rax+rax*1], ax
0000710e9ebd13da  nop [rax+rax*1], ax
0000710e9ebd13e0  mov eax, [r15+0x50]
0000710e9ebd13e4  lea r14d, [eax-0x01]
0000710e9ebd13e9  mov r14d, r14d
0000710e9ebd13ec  mov [r15+0x58], r14
0000710e9ebd13f0  mov rax, [r15+0x58]
0000710e9ebd13f4  mov r14d, eax
0000710e9ebd13f7  mov r14d, r14d
0000710e9ebd13fa  shl r14, 0x02
0000710e9ebd13fe  mov rax, [r15+0x98]
0000710e9ebd1405  lea r12, [rax+r14*1]
0000710e9ebd1409  mov eax, [r13+r12*1]
0000710e9ebd140e  mov [rsp+0x10], eax
0000710e9ebd1412  mov eax, eax
0000710e9ebd1414  mov [r15+0x60], rax
0000710e9ebd1418  mov eax, [r15+0x48]
0000710e9ebd141c  mov [rsp+0x20], eax
0000710e9ebd1420  xor eax, eax
0000710e9ebd1422  mov r14d, [rsp+0x10]
0000710e9ebd1427  mov r12d, [rsp+0x20]
0000710e9ebd142c  cmp r14d, r12d
0000710e9ebd142f  cmc
0000710e9ebd1430  lahf
0000710e9ebd1431  seto al
0000710e9ebd1434  mov [r15+0x108], eax
0000710e9ebd143b  mov eax, [r15+0x108]
0000710e9ebd1442  sahf
0000710e9ebd1443  cmc
0000710e9ebd1444  jbe 0x0000710E9EBD1476
0000710e9ebd1446  cmp dword ptr [r15+0x318], 0x00
0000710e9ebd144e  jz 0x0000710E9EBD1220
0000710e9ebd1454  nop [rax+rax*1], ax
0000710e9ebd145d  nop [rax+rax*1], eax
0000710e9ebd1465  mov eax, 0x4103A0
0000710e9ebd146a  mov [r15+0x100], rax
0000710e9ebd1471  jmp 0x0000710E9E9FE110
0000710e9ebd1476  cmp dword ptr [r15+0x318], 0x00
0000710e9ebd147e  jz 0x0000710E9EBD14C0
0000710e9ebd1484  nop [rax+rax*1], ax
0000710e9ebd148d  nop [rax+rax*1], eax
0000710e9ebd1495  mov eax, 0x410378
0000710e9ebd149a  mov [r15+0x100], rax
0000710e9ebd14a1  jmp 0x0000710E9E9FE110
0000710e9ebd14a6  int3
0000710e9ebd14a7  call 0x0000710E9EAB4690
0000710e9ebd14ac  jmp 0x0000710E9EBD140E
0000710e9ebd14b1  int3
0000710e9ebd14b2  nop [rax+rax*1], ax
0000710e9ebd14bb  nop [rax+rax*1], eax
0000710e9ebd14c0  mov rax, [r15+0x40]
0000710e9ebd14c4  lea r14, [rax+0x01]
0000710e9ebd14c8  mov [r15+0x40], r14
0000710e9ebd14cc  mov rax, [r15+0x50]
0000710e9ebd14d0  mov r12d, eax
0000710e9ebd14d3  mov r12d, r12d
0000710e9ebd14d6  shl r12, 0x02
0000710e9ebd14da  mov rax, [r15+0x98]
0000710e9ebd14e1  lea r11, [rax+r12*1]
0000710e9ebd14e5  mov eax, [r15+0x48]
0000710e9ebd14e9  mov [r13+r11*1], eax
0000710e9ebd14ee  xor eax, eax
0000710e9ebd14f0  mov r12d, 0x400
0000710e9ebd14f6  cmp r14, r12
0000710e9ebd14f9  cmc
0000710e9ebd14fa  lahf
0000710e9ebd14fb  seto al
0000710e9ebd14fe  mov [r15+0x108], eax
0000710e9ebd1505  mov eax, [r15+0x108]
0000710e9ebd150c  sahf
0000710e9ebd150d  jz 0x0000710E9EBD153F
0000710e9ebd150f  cmp dword ptr [r15+0x318], 0x00
0000710e9ebd1517  jz 0x0000710E9EBD1120
0000710e9ebd151d  nop [rax+rax*1], ax
0000710e9ebd1526  nop [rax+rax*1], eax
0000710e9ebd152e  mov eax, 0x410388
0000710e9ebd1533  mov [r15+0x100], rax
0000710e9ebd153a  jmp 0x0000710E9E9FE110
0000710e9ebd153f  cmp dword ptr [r15+0x318], 0x00
0000710e9ebd1547  jz 0x0000710E9EBD1580
0000710e9ebd154d  nop [rax+rax*1], ax
0000710e9ebd1556  nop [rax+rax*1], eax
0000710e9ebd155e  mov eax, 0x4103B0
0000710e9ebd1563  mov [r15+0x100], rax
0000710e9ebd156a  jmp 0x0000710E9E9FE110
0000710e9ebd156f  int3
0000710e9ebd1570  call 0x0000710E9EAA4270
0000710e9ebd1575  jmp 0x0000710E9EBD14EE
0000710e9ebd157a  int3
0000710e9ebd157b  nop [rax+rax*1], eax
0000710e9ebd1580  mov qword ptr [r15+0x40], 0x430000
0000710e9ebd1588  mov eax, 0x430CB0
0000710e9ebd158d  mov r14, [r13+rax*1]
0000710e9ebd1592  mov rax, [r15+0x98]
0000710e9ebd1599  mov r12d, [r13+rax*1]
0000710e9ebd159e  lea r11, [rax+0x04]
0000710e9ebd15a2  mov eax, [r13+r11*1]
0000710e9ebd15a7  mov r12d, r12d
0000710e9ebd15aa  mov [r15+0x68], r12
0000710e9ebd15ae  mov eax, eax
0000710e9ebd15b0  mov [r15+0x60], rax
0000710e9ebd15b4  mov rax, [r15+0x68]
0000710e9ebd15b8  mov [r15+0x68], rax
0000710e9ebd15bc  mov qword ptr [r15+0x58], 0x02
0000710e9ebd15c4  mov [rsp+0x10], rax
0000710e9ebd15c9  xor eax, eax
0000710e9ebd15cb  mov r12d, 0x02
0000710e9ebd15d1  mov r11d, 0x400
0000710e9ebd15d7  cmp r12, r11
0000710e9ebd15da  cmc
0000710e9ebd15db  lahf
0000710e9ebd15dc  seto al
0000710e9ebd15df  mov [r15+0x108], eax
0000710e9ebd15e6  mov rax, [r15+0x60]
0000710e9ebd15ea  mov r12d, 0x02
0000710e9ebd15f0  imul rax, r12
0000710e9ebd15f4  mov [r15+0x50], rax
0000710e9ebd15f8  mov rax, [rsp+0x10]
0000710e9ebd15fd  lea r12, [rax+r14*1]
0000710e9ebd1601  mov [r15+0x48], r12
0000710e9ebd1605  mov eax, [r15+0x108]
0000710e9ebd160c  sahf
0000710e9ebd160d  jnz 0x0000710E9EBD163F
0000710e9ebd160f  cmp dword ptr [r15+0x318], 0x00
0000710e9ebd1617  jz 0x0000710E9EBD17B0
0000710e9ebd161d  nop [rax+rax*1], ax
0000710e9ebd1626  nop [rax+rax*1], eax
0000710e9ebd162e  mov eax, 0x4103E0
0000710e9ebd1633  mov [r15+0x100], rax
0000710e9ebd163a  jmp 0x0000710E9E9FE110
0000710e9ebd163f  cmp dword ptr [r15+0x318], 0x00
0000710e9ebd1647  jz 0x0000710E9EBD1690
0000710e9ebd164d  nop [rax+rax*1], ax
0000710e9ebd1656  nop [rax+rax*1], eax
0000710e9ebd165e  mov eax, 0x4103C0
0000710e9ebd1663  mov [r15+0x100], rax
0000710e9ebd166a  jmp 0x0000710E9E9FE110
0000710e9ebd166f  int3
0000710e9ebd1670  call 0x0000710E9EA0DC20
0000710e9ebd1675  jmp 0x0000710E9EBD1592
0000710e9ebd167a  call 0x0000710E9EA0B5E0
0000710e9ebd167f  jmp 0x0000710E9EBD159E
0000710e9ebd1684  call 0x0000710E9EAA3D90
0000710e9ebd1689  jmp 0x0000710E9EBD15A7
0000710e9ebd168e  int3
0000710e9ebd168f  nop
0000710e9ebd1690  mov rax, [r15+0x98]
0000710e9ebd1697  mov r14, [r15+0x58]
0000710e9ebd169b  mov [rsp+0x10], r14
0000710e9ebd16a0  shl r14, 0x02
0000710e9ebd16a4  lea r12, [rax+r14*1]
0000710e9ebd16a8  mov eax, [r13+r12*1]
0000710e9ebd16ad  lea r14, [r12+0x04]
0000710e9ebd16b2  mov r12d, [r13+r14*1]
0000710e9ebd16b7  mov eax, eax
0000710e9ebd16b9  mov [r15+0x68], rax
0000710e9ebd16bd  mov r12d, r12d
0000710e9ebd16c0  mov [r15+0x60], r12
0000710e9ebd16c4  mov rax, [r15+0x68]
0000710e9ebd16c8  mov [rsp+0x20], rax
0000710e9ebd16cd  mov r14, [rsp+0x10]
0000710e9ebd16d2  imul rax, r14
0000710e9ebd16d6  mov r12, [rsp+0x20]
0000710e9ebd16db  lea r11, [r12+rax*1]
0000710e9ebd16df  mov [r15+0x68], r11
0000710e9ebd16e3  lea rax, [r14+0x02]
0000710e9ebd16e7  mov [r15+0x58], rax
0000710e9ebd16eb  mov [rsp+0x10], rax
0000710e9ebd16f0  xor eax, eax
0000710e9ebd16f2  mov r14, [rsp+0x10]
0000710e9ebd16f7  mov r12d, 0x400
0000710e9ebd16fd  cmp r14, r12
0000710e9ebd1700  cmc
0000710e9ebd1701  lahf
0000710e9ebd1702  seto al
0000710e9ebd1705  mov [r15+0x108], eax
0000710e9ebd170c  mov rax, [r15+0x50]
0000710e9ebd1710  mov r12, [r15+0x60]
0000710e9ebd1714  imul r14, r12
0000710e9ebd1718  lea r12, [rax+r14*1]
0000710e9ebd171c  mov [r15+0x50], r12
0000710e9ebd1720  mov rax, [r15+0x48]
0000710e9ebd1724  lea r14, [r11+rax*1]
0000710e9ebd1728  mov [r15+0x48], r14
0000710e9ebd172c  mov eax, [r15+0x108]
0000710e9ebd1733  sahf
0000710e9ebd1734  jnz 0x0000710E9EBD1766
0000710e9ebd1736  cmp dword ptr [r15+0x318], 0x00
0000710e9ebd173e  jz 0x0000710E9EBD17B0
0000710e9ebd1744  nop [rax+rax*1], ax
0000710e9ebd174d  nop [rax+rax*1], eax
0000710e9ebd1755  mov eax, 0x4103E0
0000710e9ebd175a  mov [r15+0x100], rax
0000710e9ebd1761  jmp 0x0000710E9E9FE110
0000710e9ebd1766  cmp dword ptr [r15+0x318], 0x00
0000710e9ebd176e  jz 0x0000710E9EBD1690
0000710e9ebd1774  nop [rax+rax*1], ax
0000710e9ebd177d  nop [rax+rax*1], eax
0000710e9ebd1785  mov eax, 0x4103C0
0000710e9ebd178a  mov [r15+0x100], rax
0000710e9ebd1791  jmp 0x0000710E9E9FE110
0000710e9ebd1796  int3
0000710e9ebd1797  call 0x0000710E9EAB4690
0000710e9ebd179c  jmp 0x0000710E9EBD16AD
0000710e9ebd17a1  call 0x0000710E9EAE26A0
0000710e9ebd17a6  jmp 0x0000710E9EBD16B7
0000710e9ebd17ab  int3
0000710e9ebd17ac  nop [rax], eax
0000710e9ebd17b0  mov qword ptr [r15+0x98], 0x00
0000710e9ebd17bb  mov rax, [r15+0x50]
0000710e9ebd17bf  mov r14, [r15+0x48]
0000710e9ebd17c3  lea r12, [rax+r14*1]
0000710e9ebd17c7  mov [r15+0x48], r12
0000710e9ebd17cb  mov rax, [r15+0x40]
0000710e9ebd17cf  lea r14, [rax+0xCB0]
0000710e9ebd17d6  mov [r13+r14*1], r12
0000710e9ebd17db  mov qword ptr [r15], 0x01
0000710e9ebd17e2  mov qword ptr [r15+0xF0], 0x4103F8
0000710e9ebd17ed  mov r14d, [r15+0x320]
0000710e9ebd17f4  mov eax, 0x4103F8
0000710e9ebd17f9  mov rcx, 0x710E9EBD1860
0000710e9ebd1803  mov [r15+r14*8+0x328], rax
0000710e9ebd180b  mov [r15+r14*8+0x368], rcx
0000710e9ebd1813  add r14d, 0x01
0000710e9ebd1817  and r14d, 0x07
0000710e9ebd181b  mov [r15+0x320], r14d
0000710e9ebd1822  cmp dword ptr [r15+0x318], 0x00
0000710e9ebd182a  jz 0x0000710E9EBD0F20
0000710e9ebd1830  nop [rax+rax*1], ax
0000710e9ebd1839  nop [rax+rax*1], eax
0000710e9ebd1841  mov eax, 0x4109A4
0000710e9ebd1846  mov [r15+0x100], rax
0000710e9ebd184d  jmp 0x0000710E9E9FE110
0000710e9ebd1852  int3
0000710e9ebd1853  call 0x0000710E9EAE2CE0
0000710e9ebd1858  jmp 0x0000710E9EBD17DB
0000710e9ebd185d  int3
0000710e9ebd185e  nop
0000710e9ebd1860  mov eax, [r15+0x98]
0000710e9ebd1867  lea r14d, [eax+0x01]
0000710e9ebd186c  mov [rsp+0x10], r14d
0000710e9ebd1871  mov r14d, r14d
0000710e9ebd1874  mov [r15+0x98], r14
0000710e9ebd187b  xor eax, eax
0000710e9ebd187d  mov r14d, [rsp+0x10]
0000710e9ebd1882  cmp r14d, 0x10000
0000710e9ebd1889  cmc
0000710e9ebd188a  lahf
0000710e9ebd188b  seto al
0000710e9ebd188e  mov [r15+0x108], eax
0000710e9ebd1895  mov eax, [r15+0x108]
0000710e9ebd189c  sahf
0000710e9ebd189d  jnz 0x0000710E9EBD18CF
0000710e9ebd189f  cmp dword ptr [r15+0x318], 0x00
0000710e9ebd18a7  jz 0x0000710E9EBD19A0
0000710e9ebd18ad  nop [rax+rax*1], ax
0000710e9ebd18b6  nop [rax+rax*1], eax
0000710e9ebd18be  mov eax, 0x410404
0000710e9ebd18c3  mov [r15+0x100], rax
0000710e9ebd18ca  jmp 0x0000710E9E9FE110
0000710e9ebd18cf  cmp dword ptr [r15+0x318], 0x00
0000710e9ebd18d7  jz 0x0000710E9EBD1910
0000710e9ebd18dd  nop [rax+rax*1], ax
0000710e9ebd18e6  nop [rax+rax*1], eax
0000710e9ebd18ee  mov eax, 0x4103F0
0000710e9ebd18f3  mov [r15+0x100], rax
0000710e9ebd18fa  jmp 0x0000710E9E9FE110
0000710e9ebd18ff  int3
0000710e9ebd1900  int3
0000710e9ebd1901  nop [rax+rax*1], ax
0000710e9ebd190a  nop [rax+rax*1], ax
0000710e9ebd1910  mov eax, [r15]
0000710e9ebd1913  mov r14d, [r15+0x98]
0000710e9ebd191a  lea r12d, [eax+r14d*1]
0000710e9ebd191f  mov r12d, r12d
0000710e9ebd1922  mov [r15], r12
0000710e9ebd1925  mov qword ptr [r15+0xF0], 0x4103F8
0000710e9ebd1930  mov r14d, [r15+0x320]
0000710e9ebd1937  mov eax, 0x4103F8
0000710e9ebd193c  mov rcx, 0x710E9EBD1860
0000710e9ebd1946  mov [r15+r14*8+0x328], rax
0000710e9ebd194e  mov [r15+r14*8+0x368], rcx
0000710e9ebd1956  add r14d, 0x01
0000710e9ebd195a  and r14d, 0x07
0000710e9ebd195e  mov [r15+0x320], r14d
0000710e9ebd1965  cmp dword ptr [r15+0x318], 0x00
0000710e9ebd196d  jz 0x0000710E9EBD0F20
0000710e9ebd1973  nop [rax+rax*1], ax
0000710e9ebd197c  nop [rax+rax*1], eax
0000710e9ebd1984  mov eax, 0x4109A4
0000710e9ebd1989  mov [r15+0x100], rax
0000710e9ebd1990  jmp 0x0000710E9E9FE110
0000710e9ebd1995  int3
0000710e9ebd1996  int3
0000710e9ebd1997  nop [rax+rax*1], ax
0000710e9ebd19a0  vmovaps xmm1, [0x0000710E9E7FE010]
0000710e9ebd19a8  movq xmm1, xmm1
0000710e9ebd19ac  movaps [r15+0x110], xmm1
0000710e9ebd19b4  mov eax, 0x420B10
0000710e9ebd19b9  mov r14, [r13+rax*1]
0000710e9ebd19be  movq xmm1, r14
0000710e9ebd19c3  movaps [r15+0x120], xmm1
0000710e9ebd19cb  vmovaps xmm1, [0x0000710E9E7FE020]
0000710e9ebd19d3  movq xmm1, xmm1
0000710e9ebd19d7  movaps [r15+0x140], xmm1
0000710e9ebd19df  vmovaps xmm1, [0x0000710E9E7FE030]
0000710e9ebd19e7  vpbroadcastq xmm1, xmm1
0000710e9ebd19ec  movaps [r15+0x150], xmm1
0000710e9ebd19f4  mov qword ptr [r15+0x40], 0x02
0000710e9ebd19fc  vmovaps xmm15, [0x0000710E9E7FE040]
0000710e9ebd1a04  movq xmm15, xmm15
0000710e9ebd1a09  movaps [r15+0x160], xmm15
0000710e9ebd1a11  vmovaps xmm15, [0x0000710E9E7FE050]
0000710e9ebd1a19  vpbroadcastq xmm15, xmm15
0000710e9ebd1a1e  movaps [r15+0x130], xmm15
0000710e9ebd1a26  mov rax, [r15+0x40]
0000710e9ebd1a2a  vmovq xmm14, rax
0000710e9ebd1a2f  vpbroadcastq xmm14, xmm14
0000710e9ebd1a34  movaps [r15+0x170], xmm14
0000710e9ebd1a3c  mov eax, 0x420A40
0000710e9ebd1a41  movups xmm13, [r13+rax*1]
0000710e9ebd1a47  mov qword ptr [r15+0x40], 0x431E00
0000710e9ebd1a4f  mov eax, [r15]
0000710e9ebd1a52  mov r14d, 0x430CB8
0000710e9ebd1a58  mov [r13+r14*1], eax
0000710e9ebd1a5d  mov qword ptr [r15+0x50], 0x432000
0000710e9ebd1a65  vpmovqd xmm12, xmm13
0000710e9ebd1a6b  pxor xmm11, xmm11
0000710e9ebd1a70  punpcklqdq xmm12, xmm11
0000710e9ebd1a75  movaps [r15+0x210], xmm12
0000710e9ebd1a7d  movq xmm12, qword ptr [r15+0x140]
0000710e9ebd1a86  movq xmm11, qword ptr [r15+0x120]
0000710e9ebd1a8f  psubd xmm12, xmm11
0000710e9ebd1a94  movq xmm12, xmm12
0000710e9ebd1a99  paddq xmm13, xmm14
0000710e9ebd1a9e  movaps [r15+0x180], xmm13
0000710e9ebd1aa6  movq xmm14, qword ptr [r15+0x160]
0000710e9ebd1aaf  paddd xmm11, xmm14
0000710e9ebd1ab4  movq xmm11, xmm11
0000710e9ebd1ab9  movq xmm11, xmm11
0000710e9ebd1abe  movaps [r15+0x120], xmm11
0000710e9ebd1ac6  pmovzxdq xmm12, xmm12
0000710e9ebd1acc  psllq xmm12, 0x00
0000710e9ebd1ad2  movq xmm14, qword ptr [r15+0x210]
0000710e9ebd1adb  movq xmm13, qword ptr [r15+0x110]
0000710e9ebd1ae4  paddd xmm14, xmm13
0000710e9ebd1ae9  movq xmm14, xmm14
0000710e9ebd1aee  vcvtuqq2pd xmm12, xmm12
0000710e9ebd1af4  pmovzxdq xmm14, xmm14
0000710e9ebd1afa  psllq xmm14, 0x00
0000710e9ebd1b00  vcvtuqq2pd xmm14, xmm14
0000710e9ebd1b06  movaps xmm13, xmm12
0000710e9ebd1b0a  mulpd xmm13, xmm1
0000710e9ebd1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
0000710e9ebd1b15  ptest xmm11, xmm11
0000710e9ebd1b1b  jnz 0x0000710E9EBD1C0F
0000710e9ebd1b21  movaps [r15+0x220], xmm13
0000710e9ebd1b29  mov eax, 0x432000
0000710e9ebd1b2e  movups [r13+rax*1], xmm13
0000710e9ebd1b34  movaps xmm1, xmm14
0000710e9ebd1b38  mulpd xmm1, xmm15
0000710e9ebd1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
0000710e9ebd1b42  ptest xmm13, xmm13
0000710e9ebd1b48  jnz 0x0000710E9EBD1D5C
0000710e9ebd1b4e  movaps [r15+0x210], xmm1
0000710e9ebd1b56  mov eax, 0x431E00
0000710e9ebd1b5b  movups [r13+rax*1], xmm1
0000710e9ebd1b61  mov qword ptr [r15+0x48], 0x10
0000710e9ebd1b69  xor eax, eax
0000710e9ebd1b6b  mov r14d, 0x10
0000710e9ebd1b71  mov r12d, 0x200
0000710e9ebd1b77  cmp r14, r12
0000710e9ebd1b7a  cmc
0000710e9ebd1b7b  lahf
0000710e9ebd1b7c  seto al
0000710e9ebd1b7f  mov [r15+0x108], eax
0000710e9ebd1b86  mov eax, [r15+0x108]
0000710e9ebd1b8d  sahf
0000710e9ebd1b8e  jnz 0x0000710E9EBD1BC0
0000710e9ebd1b90  cmp dword ptr [r15+0x318], 0x00
0000710e9ebd1b98  jz 0x0000710E9EBD2300
0000710e9ebd1b9e  nop [rax+rax*1], ax
0000710e9ebd1ba7  nop [rax+rax*1], eax
0000710e9ebd1baf  mov eax, 0x410490
0000710e9ebd1bb4  mov [r15+0x100], rax
0000710e9ebd1bbb  jmp 0x0000710E9E9FE110
0000710e9ebd1bc0  cmp dword ptr [r15+0x318], 0x00
0000710e9ebd1bc8  jz 0x0000710E9EBD1EB0
0000710e9ebd1bce  nop [rax+rax*1], ax
0000710e9ebd1bd7  nop [rax+rax*1], eax
0000710e9ebd1bdf  mov eax, 0x410450
0000710e9ebd1be4  mov [r15+0x100], rax
0000710e9ebd1beb  jmp 0x0000710E9E9FE110
0000710e9ebd1bf0  int3
0000710e9ebd1bf1  call 0x0000710E9EA0DC20
0000710e9ebd1bf6  jmp 0x0000710E9EBD19BE
0000710e9ebd1bfb  call 0x0000710E9EA0C260
0000710e9ebd1c00  jmp 0x0000710E9EBD1A47
0000710e9ebd1c05  call 0x0000710E9EAD5D70
0000710e9ebd1c0a  jmp 0x0000710E9EBD1A5D
0000710e9ebd1c0f  sub rsp, 0x08
0000710e9ebd1c13  push rax
0000710e9ebd1c14  push rcx
0000710e9ebd1c15  push rdx
0000710e9ebd1c16  push rdi
0000710e9ebd1c17  push rsi
0000710e9ebd1c18  push r8
0000710e9ebd1c1a  push r9
0000710e9ebd1c1c  push r10
0000710e9ebd1c1e  push r11
0000710e9ebd1c20  sub rsp, 0xF0
0000710e9ebd1c27  vmovaps [rsp], xmm0
0000710e9ebd1c2c  vmovaps [rsp+0x10], xmm1
0000710e9ebd1c32  vmovaps [rsp+0x20], xmm2
0000710e9ebd1c38  vmovaps [rsp+0x30], xmm3
0000710e9ebd1c3e  vmovaps [rsp+0x40], xmm4
0000710e9ebd1c44  vmovaps [rsp+0x50], xmm5
0000710e9ebd1c4a  vmovaps [rsp+0x60], xmm6
0000710e9ebd1c50  vmovaps [rsp+0x70], xmm7
0000710e9ebd1c56  vmovaps [rsp+0x80], xmm8
0000710e9ebd1c5f  vmovaps [rsp+0x90], xmm9
0000710e9ebd1c68  vmovaps [rsp+0xA0], xmm10
0000710e9ebd1c71  vmovaps [rsp+0xB0], xmm11
0000710e9ebd1c7a  vmovaps [rsp+0xC0], xmm12
0000710e9ebd1c83  vmovaps [rsp+0xD0], xmm14
0000710e9ebd1c8c  vmovaps [rsp+0xE0], xmm15
0000710e9ebd1c95  sub rsp, 0x30
0000710e9ebd1c99  movaps [rsp], xmm13
0000710e9ebd1c9e  movaps [rsp+0x10], xmm12
0000710e9ebd1ca4  movaps [rsp+0x20], xmm1
0000710e9ebd1ca9  lea rdi, [rsp]
0000710e9ebd1cad  mov esi, 0x00
0000710e9ebd1cb2  mov rax, 0x5DADAF7CF530
0000710e9ebd1cbc  call rax
0000710e9ebd1cbe  movaps xmm13, [rsp]
0000710e9ebd1cc3  add rsp, 0x30
0000710e9ebd1cc7  vmovaps xmm0, [rsp]
0000710e9ebd1ccc  vmovaps xmm1, [rsp+0x10]
0000710e9ebd1cd2  vmovaps xmm2, [rsp+0x20]
0000710e9ebd1cd8  vmovaps xmm3, [rsp+0x30]
0000710e9ebd1cde  vmovaps xmm4, [rsp+0x40]
0000710e9ebd1ce4  vmovaps xmm5, [rsp+0x50]
0000710e9ebd1cea  vmovaps xmm6, [rsp+0x60]
0000710e9ebd1cf0  vmovaps xmm7, [rsp+0x70]
0000710e9ebd1cf6  vmovaps xmm8, [rsp+0x80]
0000710e9ebd1cff  vmovaps xmm9, [rsp+0x90]
0000710e9ebd1d08  vmovaps xmm10, [rsp+0xA0]
0000710e9ebd1d11  vmovaps xmm11, [rsp+0xB0]
0000710e9ebd1d1a  vmovaps xmm12, [rsp+0xC0]
0000710e9ebd1d23  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd1d2c  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd1d35  add rsp, 0xF0
0000710e9ebd1d3c  pop r11
0000710e9ebd1d3e  pop r10
0000710e9ebd1d40  pop r9
0000710e9ebd1d42  pop r8
0000710e9ebd1d44  pop rsi
0000710e9ebd1d45  pop rdi
0000710e9ebd1d46  pop rdx
0000710e9ebd1d47  pop rcx
0000710e9ebd1d48  pop rax
0000710e9ebd1d49  add rsp, 0x08
0000710e9ebd1d4d  jmp 0x0000710E9EBD1B21
0000710e9ebd1d52  call 0x0000710E9EA0C380
0000710e9ebd1d57  jmp 0x0000710E9EBD1B34
0000710e9ebd1d5c  sub rsp, 0x08
0000710e9ebd1d60  push rax
0000710e9ebd1d61  push rcx
0000710e9ebd1d62  push rdx
0000710e9ebd1d63  push rdi
0000710e9ebd1d64  push rsi
0000710e9ebd1d65  push r8
0000710e9ebd1d67  push r9
0000710e9ebd1d69  push r10
0000710e9ebd1d6b  push r11
0000710e9ebd1d6d  sub rsp, 0xF0
0000710e9ebd1d74  vmovaps [rsp], xmm0
0000710e9ebd1d79  vmovaps [rsp+0x10], xmm2
0000710e9ebd1d7f  vmovaps [rsp+0x20], xmm3
0000710e9ebd1d85  vmovaps [rsp+0x30], xmm4
0000710e9ebd1d8b  vmovaps [rsp+0x40], xmm5
0000710e9ebd1d91  vmovaps [rsp+0x50], xmm6
0000710e9ebd1d97  vmovaps [rsp+0x60], xmm7
0000710e9ebd1d9d  vmovaps [rsp+0x70], xmm8
0000710e9ebd1da3  vmovaps [rsp+0x80], xmm9
0000710e9ebd1dac  vmovaps [rsp+0x90], xmm10
0000710e9ebd1db5  vmovaps [rsp+0xA0], xmm11
0000710e9ebd1dbe  vmovaps [rsp+0xB0], xmm12
0000710e9ebd1dc7  vmovaps [rsp+0xC0], xmm13
0000710e9ebd1dd0  vmovaps [rsp+0xD0], xmm14
0000710e9ebd1dd9  vmovaps [rsp+0xE0], xmm15
0000710e9ebd1de2  sub rsp, 0x30
0000710e9ebd1de6  movaps [rsp], xmm1
0000710e9ebd1dea  movaps [rsp+0x10], xmm14
0000710e9ebd1df0  movaps [rsp+0x20], xmm15
0000710e9ebd1df6  lea rdi, [rsp]
0000710e9ebd1dfa  mov esi, 0x00
0000710e9ebd1dff  mov rax, 0x5DADAF7CF530
0000710e9ebd1e09  call rax
0000710e9ebd1e0b  movaps xmm1, [rsp]
0000710e9ebd1e0f  add rsp, 0x30
0000710e9ebd1e13  vmovaps xmm0, [rsp]
0000710e9ebd1e18  vmovaps xmm2, [rsp+0x10]
0000710e9ebd1e1e  vmovaps xmm3, [rsp+0x20]
0000710e9ebd1e24  vmovaps xmm4, [rsp+0x30]
0000710e9ebd1e2a  vmovaps xmm5, [rsp+0x40]
0000710e9ebd1e30  vmovaps xmm6, [rsp+0x50]
0000710e9ebd1e36  vmovaps xmm7, [rsp+0x60]
0000710e9ebd1e3c  vmovaps xmm8, [rsp+0x70]
0000710e9ebd1e42  vmovaps xmm9, [rsp+0x80]
0000710e9ebd1e4b  vmovaps xmm10, [rsp+0x90]
0000710e9ebd1e54  vmovaps xmm11, [rsp+0xA0]
0000710e9ebd1e5d  vmovaps xmm12, [rsp+0xB0]
0000710e9ebd1e66  vmovaps xmm13, [rsp+0xC0]
0000710e9ebd1e6f  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd1e78  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd1e81  add rsp, 0xF0
0000710e9ebd1e88  pop r11
0000710e9ebd1e8a  pop r10
0000710e9ebd1e8c  pop r9
0000710e9ebd1e8e  pop r8
0000710e9ebd1e90  pop rsi
0000710e9ebd1e91  pop rdi
0000710e9ebd1e92  pop rdx
0000710e9ebd1e93  pop rcx
0000710e9ebd1e94  pop rax
0000710e9ebd1e95  add rsp, 0x08
0000710e9ebd1e99  jmp 0x0000710E9EBD1B4E
0000710e9ebd1e9e  call 0x0000710E9E9FF540
0000710e9ebd1ea3  jmp 0x0000710E9EBD1B61
0000710e9ebd1ea8  int3
0000710e9ebd1ea9  nop [rax], eax
0000710e9ebd1eb0  movaps xmm1, [r15+0x180]
0000710e9ebd1eb8  vpmovqd xmm15, xmm1
0000710e9ebd1ebe  pxor xmm14, xmm14
0000710e9ebd1ec3  punpcklqdq xmm15, xmm14
0000710e9ebd1ec8  movaps [r15+0x210], xmm15
0000710e9ebd1ed0  movq xmm15, qword ptr [r15+0x140]
0000710e9ebd1ed9  movq xmm14, qword ptr [r15+0x120]
0000710e9ebd1ee2  psubd xmm15, xmm14
0000710e9ebd1ee7  movq xmm15, xmm15
0000710e9ebd1eec  movaps xmm13, [r15+0x170]
0000710e9ebd1ef4  paddq xmm1, xmm13
0000710e9ebd1ef9  movaps [r15+0x180], xmm1
0000710e9ebd1f01  movq xmm1, qword ptr [r15+0x160]
0000710e9ebd1f0a  paddd xmm14, xmm1
0000710e9ebd1f0f  movq xmm14, xmm14
0000710e9ebd1f14  movq xmm14, xmm14
0000710e9ebd1f19  movaps [r15+0x120], xmm14
0000710e9ebd1f21  pmovzxdq xmm15, xmm15
0000710e9ebd1f27  psllq xmm15, 0x00
0000710e9ebd1f2d  movq xmm1, qword ptr [r15+0x210]
0000710e9ebd1f36  movq xmm14, qword ptr [r15+0x110]
0000710e9ebd1f3f  paddd xmm1, xmm14
0000710e9ebd1f44  movq xmm1, xmm1
0000710e9ebd1f48  vcvtuqq2pd xmm15, xmm15
0000710e9ebd1f4e  pmovzxdq xmm1, xmm1
0000710e9ebd1f53  psllq xmm1, 0x00
0000710e9ebd1f58  vcvtuqq2pd xmm1, xmm1
0000710e9ebd1f5e  movaps xmm14, [r15+0x150]
0000710e9ebd1f66  movaps xmm13, xmm15
0000710e9ebd1f6a  mulpd xmm13, xmm14
0000710e9ebd1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
0000710e9ebd1f75  ptest xmm12, xmm12
0000710e9ebd1f7b  jnz 0x0000710E9EBD205E
0000710e9ebd1f81  movaps [r15+0x220], xmm13
0000710e9ebd1f89  mov rax, [r15+0x48]
0000710e9ebd1f8d  mov r14, [r15+0x50]
0000710e9ebd1f91  lea r12, [r14+rax*1]
0000710e9ebd1f95  movups [r13+r12*1], xmm13
0000710e9ebd1f9b  movaps xmm15, [r15+0x130]
0000710e9ebd1fa3  movaps xmm14, xmm1
0000710e9ebd1fa7  mulpd xmm14, xmm15
0000710e9ebd1fac  vcmppd xmm13, xmm14, xmm14, 0x03
0000710e9ebd1fb2  ptest xmm13, xmm13
0000710e9ebd1fb8  jnz 0x0000710E9EBD21AC
0000710e9ebd1fbe  movaps [r15+0x210], xmm14
0000710e9ebd1fc6  mov r14, [r15+0x40]
0000710e9ebd1fca  lea r12, [r14+rax*1]
0000710e9ebd1fce  movups [r13+r12*1], xmm14
0000710e9ebd1fd4  lea r14, [rax+0x10]
0000710e9ebd1fd8  mov [r15+0x48], r14
0000710e9ebd1fdc  xor eax, eax
0000710e9ebd1fde  mov r12d, 0x200
0000710e9ebd1fe4  cmp r14, r12
0000710e9ebd1fe7  cmc
0000710e9ebd1fe8  lahf
0000710e9ebd1fe9  seto al
0000710e9ebd1fec  mov [r15+0x108], eax
0000710e9ebd1ff3  mov eax, [r15+0x108]
0000710e9ebd1ffa  sahf
0000710e9ebd1ffb  jnz 0x0000710E9EBD202D
0000710e9ebd1ffd  cmp dword ptr [r15+0x318], 0x00
0000710e9ebd2005  jz 0x0000710E9EBD2300
0000710e9ebd200b  nop [rax+rax*1], ax
0000710e9ebd2014  nop [rax+rax*1], eax
0000710e9ebd201c  mov eax, 0x410490
0000710e9ebd2021  mov [r15+0x100], rax
0000710e9ebd2028  jmp 0x0000710E9E9FE110
0000710e9ebd202d  cmp dword ptr [r15+0x318], 0x00
0000710e9ebd2035  jz 0x0000710E9EBD1EB0
0000710e9ebd203b  nop [rax+rax*1], ax
0000710e9ebd2044  nop [rax+rax*1], eax
0000710e9ebd204c  mov eax, 0x410450
0000710e9ebd2051  mov [r15+0x100], rax
0000710e9ebd2058  jmp 0x0000710E9E9FE110
0000710e9ebd205d  int3
0000710e9ebd205e  sub rsp, 0x08
0000710e9ebd2062  push rax
0000710e9ebd2063  push rcx
0000710e9ebd2064  push rdx
0000710e9ebd2065  push rdi
0000710e9ebd2066  push rsi
0000710e9ebd2067  push r8
0000710e9ebd2069  push r9
0000710e9ebd206b  push r10
0000710e9ebd206d  push r11
0000710e9ebd206f  sub rsp, 0xF0
0000710e9ebd2076  vmovaps [rsp], xmm0
0000710e9ebd207b  vmovaps [rsp+0x10], xmm1
0000710e9ebd2081  vmovaps [rsp+0x20], xmm2
0000710e9ebd2087  vmovaps [rsp+0x30], xmm3
0000710e9ebd208d  vmovaps [rsp+0x40], xmm4
0000710e9ebd2093  vmovaps [rsp+0x50], xmm5
0000710e9ebd2099  vmovaps [rsp+0x60], xmm6
0000710e9ebd209f  vmovaps [rsp+0x70], xmm7
0000710e9ebd20a5  vmovaps [rsp+0x80], xmm8
0000710e9ebd20ae  vmovaps [rsp+0x90], xmm9
0000710e9ebd20b7  vmovaps [rsp+0xA0], xmm10
0000710e9ebd20c0  vmovaps [rsp+0xB0], xmm11
0000710e9ebd20c9  vmovaps [rsp+0xC0], xmm12
0000710e9ebd20d2  vmovaps [rsp+0xD0], xmm14
0000710e9ebd20db  vmovaps [rsp+0xE0], xmm15
0000710e9ebd20e4  sub rsp, 0x30
0000710e9ebd20e8  movaps [rsp], xmm13
0000710e9ebd20ed  movaps [rsp+0x10], xmm15
0000710e9ebd20f3  movaps [rsp+0x20], xmm14
0000710e9ebd20f9  lea rdi, [rsp]
0000710e9ebd20fd  mov esi, 0x00
0000710e9ebd2102  mov rax, 0x5DADAF7CF530
0000710e9ebd210c  call rax
0000710e9ebd210e  movaps xmm13, [rsp]
0000710e9ebd2113  add rsp, 0x30
0000710e9ebd2117  vmovaps xmm0, [rsp]
0000710e9ebd211c  vmovaps xmm1, [rsp+0x10]
0000710e9ebd2122  vmovaps xmm2, [rsp+0x20]
0000710e9ebd2128  vmovaps xmm3, [rsp+0x30]
0000710e9ebd212e  vmovaps xmm4, [rsp+0x40]
0000710e9ebd2134  vmovaps xmm5, [rsp+0x50]
0000710e9ebd213a  vmovaps xmm6, [rsp+0x60]
0000710e9ebd2140  vmovaps xmm7, [rsp+0x70]
0000710e9ebd2146  vmovaps xmm8, [rsp+0x80]
0000710e9ebd214f  vmovaps xmm9, [rsp+0x90]
0000710e9ebd2158  vmovaps xmm10, [rsp+0xA0]
0000710e9ebd2161  vmovaps xmm11, [rsp+0xB0]
0000710e9ebd216a  vmovaps xmm12, [rsp+0xC0]
0000710e9ebd2173  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd217c  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd2185  add rsp, 0xF0
0000710e9ebd218c  pop r11
0000710e9ebd218e  pop r10
0000710e9ebd2190  pop r9
0000710e9ebd2192  pop r8
0000710e9ebd2194  pop rsi
0000710e9ebd2195  pop rdi
0000710e9ebd2196  pop rdx
0000710e9ebd2197  pop rcx
0000710e9ebd2198  pop rax
0000710e9ebd2199  add rsp, 0x08
0000710e9ebd219d  jmp 0x0000710E9EBD1F81
0000710e9ebd21a2  call 0x0000710E9EAC2240
0000710e9ebd21a7  jmp 0x0000710E9EBD1F9B
0000710e9ebd21ac  sub rsp, 0x08
0000710e9ebd21b0  push rax
0000710e9ebd21b1  push rcx
0000710e9ebd21b2  push rdx
0000710e9ebd21b3  push rdi
0000710e9ebd21b4  push rsi
0000710e9ebd21b5  push r8
0000710e9ebd21b7  push r9
0000710e9ebd21b9  push r10
0000710e9ebd21bb  push r11
0000710e9ebd21bd  sub rsp, 0xF0
0000710e9ebd21c4  vmovaps [rsp], xmm0
0000710e9ebd21c9  vmovaps [rsp+0x10], xmm1
0000710e9ebd21cf  vmovaps [rsp+0x20], xmm2
0000710e9ebd21d5  vmovaps [rsp+0x30], xmm3
0000710e9ebd21db  vmovaps [rsp+0x40], xmm4
0000710e9ebd21e1  vmovaps [rsp+0x50], xmm5
0000710e9ebd21e7  vmovaps [rsp+0x60], xmm6
0000710e9ebd21ed  vmovaps [rsp+0x70], xmm7
0000710e9ebd21f3  vmovaps [rsp+0x80], xmm8
0000710e9ebd21fc  vmovaps [rsp+0x90], xmm9
0000710e9ebd2205  vmovaps [rsp+0xA0], xmm10
0000710e9ebd220e  vmovaps [rsp+0xB0], xmm11
0000710e9ebd2217  vmovaps [rsp+0xC0], xmm12
0000710e9ebd2220  vmovaps [rsp+0xD0], xmm13
0000710e9ebd2229  vmovaps [rsp+0xE0], xmm15
0000710e9ebd2232  sub rsp, 0x30
0000710e9ebd2236  movaps [rsp], xmm14
0000710e9ebd223b  movaps [rsp+0x10], xmm1
0000710e9ebd2240  movaps [rsp+0x20], xmm15
0000710e9ebd2246  lea rdi, [rsp]
0000710e9ebd224a  mov esi, 0x00
0000710e9ebd224f  mov rax, 0x5DADAF7CF530
0000710e9ebd2259  call rax
0000710e9ebd225b  movaps xmm14, [rsp]
0000710e9ebd2260  add rsp, 0x30
0000710e9ebd2264  vmovaps xmm0, [rsp]
0000710e9ebd2269  vmovaps xmm1, [rsp+0x10]
0000710e9ebd226f  vmovaps xmm2, [rsp+0x20]
0000710e9ebd2275  vmovaps xmm3, [rsp+0x30]
0000710e9ebd227b  vmovaps xmm4, [rsp+0x40]
0000710e9ebd2281  vmovaps xmm5, [rsp+0x50]
0000710e9ebd2287  vmovaps xmm6, [rsp+0x60]
0000710e9ebd228d  vmovaps xmm7, [rsp+0x70]
0000710e9ebd2293  vmovaps xmm8, [rsp+0x80]
0000710e9ebd229c  vmovaps xmm9, [rsp+0x90]
0000710e9ebd22a5  vmovaps xmm10, [rsp+0xA0]
0000710e9ebd22ae  vmovaps xmm11, [rsp+0xB0]
0000710e9ebd22b7  vmovaps xmm12, [rsp+0xC0]
0000710e9ebd22c0  vmovaps xmm13, [rsp+0xD0]
0000710e9ebd22c9  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd22d2  add rsp, 0xF0
0000710e9ebd22d9  pop r11
0000710e9ebd22db  pop r10
0000710e9ebd22dd  pop r9
0000710e9ebd22df  pop r8
0000710e9ebd22e1  pop rsi
0000710e9ebd22e2  pop rdi
0000710e9ebd22e3  pop rdx
0000710e9ebd22e4  pop rcx
0000710e9ebd22e5  pop rax
0000710e9ebd22e6  add rsp, 0x08
0000710e9ebd22ea  jmp 0x0000710E9EBD1FBE
0000710e9ebd22ef  call 0x0000710E9EAC34C0
0000710e9ebd22f4  jmp 0x0000710E9EBD1FD4
0000710e9ebd22f9  int3
0000710e9ebd22fa  nop [rax+rax*1], ax
0000710e9ebd2300  mov rax, [r15+0x50]
0000710e9ebd2304  lea r14, [rax+0x80]
0000710e9ebd230b  movups xmm1, [r13+r14*1]
0000710e9ebd2311  lea r14, [rax+0x90]
0000710e9ebd2318  movups xmm15, [r13+r14*1]
0000710e9ebd231e  vxorps xmm14, xmm14, xmm14
0000710e9ebd2323  vpbroadcastq xmm14, xmm14
0000710e9ebd2328  lea r14, [rax+0x40]
0000710e9ebd232c  movups xmm13, [r13+r14*1]
0000710e9ebd2332  lea r14, [rax+0x50]
0000710e9ebd2336  movups xmm12, [r13+r14*1]
0000710e9ebd233c  mov qword ptr [r15+0x48], 0x00
0000710e9ebd2344  movups xmm11, [r13+rax*1]
0000710e9ebd234a  lea r14, [rax+0x10]
0000710e9ebd234e  movups xmm10, [r13+r14*1]
0000710e9ebd2354  mov r14, [r15+0xF8]
0000710e9ebd235b  lea r12, [r14+0xE0]
0000710e9ebd2362  movups [r13+r12*1], xmm15
0000710e9ebd2368  lea r12, [r14+0xF0]
0000710e9ebd236f  movups [r13+r12*1], xmm1
0000710e9ebd2375  lea r12, [rax+0xC0]
0000710e9ebd237c  movups xmm1, [r13+r12*1]
0000710e9ebd2382  lea r12, [rax+0xD0]
0000710e9ebd2389  movups xmm15, [r13+r12*1]
0000710e9ebd238f  lea r12, [rax+0x140]
0000710e9ebd2396  movups xmm9, [r13+r12*1]
0000710e9ebd239c  lea r12, [rax+0x150]
0000710e9ebd23a3  movups xmm8, [r13+r12*1]
0000710e9ebd23a9  lea r12, [rax+0x180]
0000710e9ebd23b0  movups xmm7, [r13+r12*1]
0000710e9ebd23b6  lea r12, [rax+0x190]
0000710e9ebd23bd  movups xmm6, [r13+r12*1]
0000710e9ebd23c3  lea r12, [r14+0xC0]
0000710e9ebd23ca  movups [r13+r12*1], xmm15
0000710e9ebd23d0  lea r12, [r14+0xD0]
0000710e9ebd23d7  movups [r13+r12*1], xmm1
0000710e9ebd23dd  lea r12, [rax+0x100]
0000710e9ebd23e4  movups xmm1, [r13+r12*1]
0000710e9ebd23ea  lea r12, [rax+0x110]
0000710e9ebd23f1  movups xmm15, [r13+r12*1]
0000710e9ebd23f7  lea r12, [rax+0x1C0]
0000710e9ebd23fe  movups xmm5, [r13+r12*1]
0000710e9ebd2404  lea r12, [rax+0x1D0]
0000710e9ebd240b  movups xmm4, [r13+r12*1]
0000710e9ebd2411  lea r12, [rax+0x20]
0000710e9ebd2415  movups xmm3, [r13+r12*1]
0000710e9ebd241b  lea r12, [rax+0x30]
0000710e9ebd241f  movups xmm2, [r13+r12*1]
0000710e9ebd2425  movaps [r15+0x1F0], xmm2
0000710e9ebd242d  lea r12, [r14+0x20]
0000710e9ebd2431  movups [r13+r12*1], xmm1
0000710e9ebd2437  lea r12, [r14+0x30]
0000710e9ebd243b  movups [r13+r12*1], xmm12
0000710e9ebd2441  lea r12, [rax+0x60]
0000710e9ebd2445  movups xmm1, [r13+r12*1]
0000710e9ebd244b  lea r12, [rax+0x70]
0000710e9ebd244f  movups xmm12, [r13+r12*1]
0000710e9ebd2455  lea r12, [r14+0x60]
0000710e9ebd2459  movups [r13+r12*1], xmm11
0000710e9ebd245f  lea r12, [r14+0x70]
0000710e9ebd2463  movups [r13+r12*1], xmm5
0000710e9ebd2469  lea r12, [rax+0xE0]
0000710e9ebd2470  movups xmm11, [r13+r12*1]
0000710e9ebd2476  lea r12, [rax+0xF0]
0000710e9ebd247d  movups xmm5, [r13+r12*1]
0000710e9ebd2483  lea r12, [rax+0x120]
0000710e9ebd248a  vmovaps [rsp+0x10], xmm1
0000710e9ebd2490  movups xmm1, [r13+r12*1]
0000710e9ebd2496  lea r12, [rax+0x130]
0000710e9ebd249d  vmovaps [rsp+0x20], xmm1
0000710e9ebd24a3  movups xmm1, [r13+r12*1]
0000710e9ebd24a9  lea r12, [r14+0xA0]
0000710e9ebd24b0  movups [r13+r12*1], xmm12
0000710e9ebd24b6  lea r12, [r14+0xB0]
0000710e9ebd24bd  vmovaps xmm12, [rsp+0x10]
0000710e9ebd24c3  movups [r13+r12*1], xmm12
0000710e9ebd24c9  lea r12, [rax+0xA0]
0000710e9ebd24d0  movups xmm12, [r13+r12*1]
0000710e9ebd24d6  lea r12, [rax+0xB0]
0000710e9ebd24dd  vmovaps [rsp+0x10], xmm1
0000710e9ebd24e3  movups xmm1, [r13+r12*1]
0000710e9ebd24e9  lea r12, [rax+0x160]
0000710e9ebd24f0  vmovaps [rsp+0x30], xmm1
0000710e9ebd24f6  movups xmm1, [r13+r12*1]
0000710e9ebd24fc  lea r12, [rax+0x170]
0000710e9ebd2503  vmovaps [rsp+0x40], xmm1
0000710e9ebd2509  movups xmm1, [r13+r12*1]
0000710e9ebd250f  movaps [r15+0x2B0], xmm1
0000710e9ebd2517  lea r12, [rax+0x1A0]
0000710e9ebd251e  vmovaps [rsp+0x50], xmm1
0000710e9ebd2524  movups xmm1, [r13+r12*1]
0000710e9ebd252a  lea r12, [rax+0x1B0]
0000710e9ebd2531  vmovaps [rsp+0x60], xmm1
0000710e9ebd2537  movups xmm1, [r13+r12*1]
0000710e9ebd253d  vmovaps [rsp+0x70], xmm1
0000710e9ebd2543  vmovaps xmm1, [rsp+0x60]
0000710e9ebd2549  movaps [r15+0x290], xmm1
0000710e9ebd2551  vmovaps [rsp+0x60], xmm1
0000710e9ebd2557  vmovaps xmm1, [rsp+0x70]
0000710e9ebd255d  movaps [r15+0x1E0], xmm1
0000710e9ebd2565  lea r12, [r14+0x80]
0000710e9ebd256c  vmovaps [rsp+0x70], xmm1
0000710e9ebd2572  vmovaps xmm1, [rsp+0x30]
0000710e9ebd2578  movups [r13+r12*1], xmm1
0000710e9ebd257e  lea r12, [r14+0x90]
0000710e9ebd2585  movups [r13+r12*1], xmm12
0000710e9ebd258b  lea r12, [rax+0x1E0]
0000710e9ebd2592  movups xmm1, [r13+r12*1]
0000710e9ebd2598  lea r12, [rax+0x1F0]
0000710e9ebd259f  movups xmm12, [r13+r12*1]
0000710e9ebd25a5  mov qword ptr [r15+0x50], 0x432200
0000710e9ebd25ad  lea rax, [r14+0x40]
0000710e9ebd25b1  vmovaps [rsp+0x30], xmm1
0000710e9ebd25b7  vmovaps xmm1, [rsp+0x40]
0000710e9ebd25bd  movups [r13+rax*1], xmm1
0000710e9ebd25c3  lea rax, [r14+0x50]
0000710e9ebd25c7  movups [r13+rax*1], xmm10
0000710e9ebd25cd  movups [r13+r14*1], xmm12
0000710e9ebd25d3  lea rax, [r14+0x10]
0000710e9ebd25d7  vmovaps xmm1, [rsp+0x30]
0000710e9ebd25dd  movups [r13+rax*1], xmm1
0000710e9ebd25e3  mov rax, [r15+0x40]
0000710e9ebd25e7  vmovaps [rsp+0x30], xmm3
0000710e9ebd25ed  vmovaps xmm1, [rsp+0x30]
0000710e9ebd25f3  por xmm3, xmm1
0000710e9ebd25f7  vmovaps [rsp+0x30], xmm6
0000710e9ebd25fd  vmovaps xmm12, [rsp+0x30]
0000710e9ebd2603  por xmm6, xmm12
0000710e9ebd2608  lea r12, [rax+0x30]
0000710e9ebd260c  mov r11, [r13+r12*1]
0000710e9ebd2611  lea r12, [rax+0x38]
0000710e9ebd2615  mov r10, [r13+r12*1]
0000710e9ebd261a  movq xmm12, r11
0000710e9ebd261f  movq xmm10, r10
0000710e9ebd2624  movq xmm12, xmm12
0000710e9ebd2629  vmovaps [rsp+0x30], xmm12
0000710e9ebd262f  movq xmm12, xmm12
0000710e9ebd2634  movaps [r15+0x130], xmm12
0000710e9ebd263c  movq xmm10, xmm10
0000710e9ebd2641  vmovaps [rsp+0x40], xmm10
0000710e9ebd2647  movq xmm10, xmm10
0000710e9ebd264c  movaps [r15+0x280], xmm10
0000710e9ebd2654  vmovaps [rsp+0x80], xmm9
0000710e9ebd265d  vmovaps xmm12, [rsp+0x80]
0000710e9ebd2666  por xmm9, xmm12
0000710e9ebd266b  lea r12, [rax+0x20]
0000710e9ebd266f  mov r11, [r13+r12*1]
0000710e9ebd2674  lea r12, [rax+0x28]
0000710e9ebd2678  mov r10, [r13+r12*1]
0000710e9ebd267d  movq xmm12, r11
0000710e9ebd2682  movq xmm10, r10
0000710e9ebd2687  movq xmm12, xmm12
0000710e9ebd268c  vmovaps [rsp+0x80], xmm12
0000710e9ebd2695  movq xmm12, xmm12
0000710e9ebd269a  movaps [r15+0x150], xmm12
0000710e9ebd26a2  movq xmm10, xmm10
0000710e9ebd26a7  vmovaps [rsp+0x90], xmm10
0000710e9ebd26b0  movq xmm10, xmm10
0000710e9ebd26b5  movaps [r15+0x140], xmm10
0000710e9ebd26bd  lea r12, [rax+0x10]
0000710e9ebd26c1  mov r11, [r13+r12*1]
0000710e9ebd26c6  lea r12, [rax+0x18]
0000710e9ebd26ca  mov r10, [r13+r12*1]
0000710e9ebd26cf  movq xmm12, r11
0000710e9ebd26d4  movq xmm10, r10
0000710e9ebd26d9  movq xmm12, xmm12
0000710e9ebd26de  vmovaps [rsp+0xA0], xmm12
0000710e9ebd26e7  movq xmm12, xmm12
0000710e9ebd26ec  movaps [r15+0x170], xmm12
0000710e9ebd26f4  movq xmm10, xmm10
0000710e9ebd26f9  vmovaps [rsp+0xB0], xmm10
0000710e9ebd2702  movq xmm10, xmm10
0000710e9ebd2707  movaps [r15+0x160], xmm10
0000710e9ebd270f  mov r12, [r13+rax*1]
0000710e9ebd2714  vmovq xmm12, r12
0000710e9ebd2719  vpbroadcastq xmm12, xmm12
0000710e9ebd271e  lea r12, [rax+0x08]
0000710e9ebd2722  mov rax, [r13+r12*1]
0000710e9ebd2727  movq xmm10, rax
0000710e9ebd272c  movaps [r15+0x230], xmm10
0000710e9ebd2734  lea rax, [r14+0x50]
0000710e9ebd2738  movups xmm10, [r13+rax*1]
0000710e9ebd273e  lea rax, [r14+0x60]
0000710e9ebd2742  vmovaps [rsp+0xC0], xmm1
0000710e9ebd274b  movups xmm1, [r13+rax*1]
0000710e9ebd2751  lea rax, [r14+0x30]
0000710e9ebd2755  vmovaps [rsp+0xD0], xmm1
0000710e9ebd275e  movups xmm1, [r13+rax*1]
0000710e9ebd2764  mov qword ptr [r15+0x60], 0x432200
0000710e9ebd276c  mov qword ptr [r15+0x58], 0x40
0000710e9ebd2774  vmovaps [rsp+0xE0], xmm1
0000710e9ebd277d  vmovaps [rsp+0xF0], xmm15
0000710e9ebd2786  vmovaps xmm15, [rsp+0xC0]
0000710e9ebd278f  vmovaps [rsp+0xC0], xmm14
0000710e9ebd2798  movaps xmm1, xmm12
0000710e9ebd279c  mulpd xmm1, xmm15
0000710e9ebd27a1  vcmppd xmm14, xmm1, xmm1, 0x03
0000710e9ebd27a6  ptest xmm14, xmm14
0000710e9ebd27ac  jnz 0x0000710E9EBD3863
0000710e9ebd27b2  movq xmm15, qword ptr [r15+0x230]
0000710e9ebd27bb  vmovaps [rsp+0x100], xmm15
0000710e9ebd27c4  vpermilpd xmm15, xmm15, 0x00
0000710e9ebd27ca  vmovaps [rsp+0x110], xmm1
0000710e9ebd27d3  vmovaps xmm1, [rsp+0xE0]
0000710e9ebd27dc  vmovaps [rsp+0xE0], xmm13
0000710e9ebd27e5  movaps xmm14, xmm1
0000710e9ebd27e9  mulpd xmm14, xmm15
0000710e9ebd27ee  vcmppd xmm13, xmm14, xmm14, 0x03
0000710e9ebd27f4  ptest xmm13, xmm13
0000710e9ebd27fa  jnz 0x0000710E9EBD39A5
0000710e9ebd2800  vxorps xmm1, xmm1, xmm1
0000710e9ebd2804  vpbroadcastq xmm1, xmm1
0000710e9ebd2809  vmovaps xmm13, [rsp+0xD0]
0000710e9ebd2812  vmovaps [rsp+0xD0], xmm1
0000710e9ebd281b  movaps xmm15, xmm12
0000710e9ebd281f  mulpd xmm15, xmm13
0000710e9ebd2824  vcmppd xmm1, xmm15, xmm15, 0x03
0000710e9ebd282a  ptest xmm1, xmm1
0000710e9ebd282f  jnz 0x0000710E9EBD3AE8
0000710e9ebd2835  movaps xmm1, xmm12
0000710e9ebd2839  mulpd xmm1, xmm10
0000710e9ebd283e  vcmppd xmm13, xmm1, xmm1, 0x03
0000710e9ebd2843  ptest xmm13, xmm13
0000710e9ebd2849  jnz 0x0000710E9EBD3C2C
0000710e9ebd284f  movaps xmm13, xmm12
0000710e9ebd2853  mulpd xmm13, xmm2
0000710e9ebd2858  vcmppd xmm10, xmm13, xmm13, 0x03
0000710e9ebd285e  ptest xmm10, xmm10
0000710e9ebd2864  jnz 0x0000710E9EBD3D6E
0000710e9ebd286a  vmovaps [rsp+0x120], xmm7
0000710e9ebd2873  vmovaps xmm12, [rsp+0x120]
0000710e9ebd287c  por xmm7, xmm12
0000710e9ebd2881  vmovaps xmm12, [rsp+0xE0]
0000710e9ebd288a  vmovaps xmm10, [rsp+0xE0]
0000710e9ebd2893  por xmm12, xmm10
0000710e9ebd2898  vmovaps xmm2, [rsp+0x100]
0000710e9ebd28a1  vpermilpd xmm2, xmm2, 0x00
0000710e9ebd28a7  vmovaps [rsp+0xE0], xmm1
0000710e9ebd28b0  vmovaps [rsp+0x120], xmm15
0000710e9ebd28b9  movaps xmm1, xmm10
0000710e9ebd28bd  mulpd xmm1, xmm2
0000710e9ebd28c1  vcmppd xmm15, xmm1, xmm1, 0x03
0000710e9ebd28c6  ptest xmm15, xmm15
0000710e9ebd28cc  jnz 0x0000710E9EBD3EB1
0000710e9ebd28d2  xor eax, eax
0000710e9ebd28d4  mov r12d, 0x40
0000710e9ebd28da  mov r11d, 0x200
0000710e9ebd28e0  cmp r12, r11
0000710e9ebd28e3  cmc
0000710e9ebd28e4  lahf
0000710e9ebd28e5  seto al
0000710e9ebd28e8  mov [r15+0x108], eax
0000710e9ebd28ef  vmovaps xmm10, [rsp+0x110]
0000710e9ebd28f8  vmovaps xmm2, [rsp+0xD0]
0000710e9ebd2901  vmovaps [rsp+0xD0], xmm1
0000710e9ebd290a  movaps xmm15, xmm10
0000710e9ebd290e  addpd xmm15, xmm2
0000710e9ebd2913  vcmppd xmm1, xmm15, xmm15, 0x03
0000710e9ebd2919  ptest xmm1, xmm1
0000710e9ebd291e  jnz 0x0000710E9EBD3FF2
0000710e9ebd2924  vmovaps xmm10, [rsp+0x120]
0000710e9ebd292d  vmovaps [rsp+0x110], xmm15
0000710e9ebd2936  vmovaps xmm15, [rsp+0xC0]
0000710e9ebd293f  vmovaps [rsp+0xC0], xmm14
0000710e9ebd2948  movaps xmm1, xmm10
0000710e9ebd294c  addpd xmm1, xmm15
0000710e9ebd2951  vcmppd xmm14, xmm1, xmm1, 0x03
0000710e9ebd2956  ptest xmm14, xmm14
0000710e9ebd295c  jnz 0x0000710E9EBD4135
0000710e9ebd2962  vmovaps xmm10, [rsp+0xE0]
0000710e9ebd296b  vmovaps [rsp+0xE0], xmm1
0000710e9ebd2974  movaps xmm14, xmm10
0000710e9ebd2978  addpd xmm14, xmm15
0000710e9ebd297d  vcmppd xmm1, xmm14, xmm14, 0x03
0000710e9ebd2983  ptest xmm1, xmm1
0000710e9ebd2988  jnz 0x0000710E9EBD4277
0000710e9ebd298e  vmovaps xmm1, [rsp+0x10]
0000710e9ebd2994  vmovaps xmm15, [rsp+0x10]
0000710e9ebd299a  por xmm1, xmm15
0000710e9ebd299f  vmovaps xmm15, [rsp+0x20]
0000710e9ebd29a5  vmovaps xmm10, [rsp+0x20]
0000710e9ebd29ab  por xmm15, xmm10
0000710e9ebd29b0  vmovaps [rsp+0x10], xmm5
0000710e9ebd29b6  vmovaps xmm10, [rsp+0x10]
0000710e9ebd29bc  por xmm5, xmm10
0000710e9ebd29c1  vmovaps [rsp+0x10], xmm11
0000710e9ebd29c7  vmovaps xmm10, [rsp+0x10]
0000710e9ebd29cd  por xmm11, xmm10
0000710e9ebd29d2  vmovaps [rsp+0x10], xmm4
0000710e9ebd29d8  vmovaps xmm10, [rsp+0x10]
0000710e9ebd29de  por xmm4, xmm10
0000710e9ebd29e3  vmovaps [rsp+0x10], xmm8
0000710e9ebd29e9  vmovaps xmm10, [rsp+0x10]
0000710e9ebd29ef  por xmm8, xmm10
0000710e9ebd29f4  vmovaps xmm10, [rsp+0xF0]
0000710e9ebd29fd  vmovaps [rsp+0x10], xmm1
0000710e9ebd2a03  vmovaps xmm1, [rsp+0xF0]
0000710e9ebd2a0c  por xmm10, xmm1
0000710e9ebd2a11  lea rax, [r14+0xA0]
0000710e9ebd2a18  movups xmm1, [r13+rax*1]
0000710e9ebd2a1e  lea rax, [r14+0xB0]
0000710e9ebd2a25  vmovaps [rsp+0x20], xmm1
0000710e9ebd2a2b  movups xmm1, [r13+rax*1]
0000710e9ebd2a31  vmovaps [rsp+0xF0], xmm1
0000710e9ebd2a3a  vmovaps [rsp+0x120], xmm15
0000710e9ebd2a43  movaps xmm1, xmm13
0000710e9ebd2a47  addpd xmm1, xmm2
0000710e9ebd2a4b  vcmppd xmm15, xmm1, xmm1, 0x03
0000710e9ebd2a50  ptest xmm15, xmm15
0000710e9ebd2a56  jnz 0x0000710E9EBD43CF
0000710e9ebd2a5c  lea rax, [r14+0xF0]
0000710e9ebd2a63  movups xmm15, [r13+rax*1]
0000710e9ebd2a69  vmovaps xmm2, [rsp+0xE0]
0000710e9ebd2a72  vmovaps [rsp+0xE0], xmm1
0000710e9ebd2a7b  vmovaps xmm1, [rsp+0xD0]
0000710e9ebd2a84  vmovaps [rsp+0xD0], xmm15
0000710e9ebd2a8d  movaps xmm13, xmm2
0000710e9ebd2a91  addpd xmm13, xmm1
0000710e9ebd2a96  vcmppd xmm15, xmm13, xmm13, 0x03
0000710e9ebd2a9c  ptest xmm15, xmm15
0000710e9ebd2aa2  jnz 0x0000710E9EBD451A
0000710e9ebd2aa8  vmovaps xmm15, [rsp+0xC0]
0000710e9ebd2ab1  movaps xmm1, xmm14
0000710e9ebd2ab5  addpd xmm1, xmm15
0000710e9ebd2aba  vcmppd xmm2, xmm1, xmm1, 0x03
0000710e9ebd2abf  ptest xmm2, xmm2
0000710e9ebd2ac4  jnz 0x0000710E9EBD465C
0000710e9ebd2aca  vmovaps xmm15, [rsp+0x100]
0000710e9ebd2ad3  vpermilpd xmm15, xmm15, 0x00
0000710e9ebd2ad9  vmovaps xmm2, [rsp+0xF0]
0000710e9ebd2ae2  vmovaps [rsp+0xC0], xmm1
0000710e9ebd2aeb  movaps xmm14, xmm2
0000710e9ebd2aef  mulpd xmm14, xmm15
0000710e9ebd2af4  vcmppd xmm1, xmm14, xmm14, 0x03
0000710e9ebd2afa  ptest xmm1, xmm1
0000710e9ebd2aff  jnz 0x0000710E9EBD479E
0000710e9ebd2b05  vmovaps xmm1, [rsp+0xA0]
0000710e9ebd2b0e  vpermilpd xmm1, xmm1, 0x00
0000710e9ebd2b14  vmovaps xmm2, [rsp+0xD0]
0000710e9ebd2b1d  vmovaps [rsp+0xD0], xmm14
0000710e9ebd2b26  movaps xmm15, xmm2
0000710e9ebd2b2a  mulpd xmm15, xmm1
0000710e9ebd2b2f  vcmppd xmm14, xmm15, xmm15, 0x03
0000710e9ebd2b35  ptest xmm14, xmm14
0000710e9ebd2b3b  jnz 0x0000710E9EBD48E1
0000710e9ebd2b41  lea rax, [r14+0xE0]
0000710e9ebd2b48  movups xmm1, [r13+rax*1]
0000710e9ebd2b4e  vmovaps xmm14, [rsp+0x100]
0000710e9ebd2b57  vpermilpd xmm14, xmm14, 0x00
0000710e9ebd2b5d  vmovaps [rsp+0xF0], xmm1
0000710e9ebd2b66  vmovaps xmm1, [rsp+0x20]
0000710e9ebd2b6c  vmovaps [rsp+0x20], xmm15
0000710e9ebd2b72  movaps xmm2, xmm1
0000710e9ebd2b75  mulpd xmm2, xmm14
0000710e9ebd2b7a  vcmppd xmm15, xmm2, xmm2, 0x03
0000710e9ebd2b7f  ptest xmm15, xmm15
0000710e9ebd2b85  jnz 0x0000710E9EBD4A2D
0000710e9ebd2b8b  vmovaps [rsp+0x100], xmm10
0000710e9ebd2b94  vmovaps xmm1, [rsp+0x100]
0000710e9ebd2b9d  por xmm10, xmm1
0000710e9ebd2ba2  movaps [r15+0x300], xmm10
0000710e9ebd2baa  vmovaps [rsp+0x100], xmm8
0000710e9ebd2bb3  vmovaps xmm1, [rsp+0x100]
0000710e9ebd2bbc  por xmm8, xmm1
0000710e9ebd2bc1  movaps [r15+0x190], xmm8
0000710e9ebd2bc9  vmovaps xmm1, [rsp+0xA0]
0000710e9ebd2bd2  vpermilpd xmm1, xmm1, 0x00
0000710e9ebd2bd8  vmovaps xmm14, [rsp+0xF0]
0000710e9ebd2be1  vmovaps [rsp+0xF0], xmm13
0000710e9ebd2bea  movaps xmm15, xmm14
0000710e9ebd2bee  mulpd xmm15, xmm1
0000710e9ebd2bf3  vcmppd xmm13, xmm15, xmm15, 0x03
0000710e9ebd2bf9  ptest xmm13, xmm13
0000710e9ebd2bff  jnz 0x0000710E9EBD4B6E
0000710e9ebd2c05  lea rax, [r14+0x90]
0000710e9ebd2c0c  movups xmm1, [r13+rax*1]
0000710e9ebd2c12  vmovaps [rsp+0x100], xmm4
0000710e9ebd2c1b  vmovaps xmm14, [rsp+0x100]
0000710e9ebd2c24  por xmm4, xmm14
0000710e9ebd2c29  movaps [r15+0x1C0], xmm4
0000710e9ebd2c31  vmovaps [rsp+0x100], xmm11
0000710e9ebd2c3a  vmovaps xmm14, [rsp+0x100]
0000710e9ebd2c43  por xmm11, xmm14
0000710e9ebd2c48  movaps [r15+0x200], xmm11
0000710e9ebd2c50  vmovaps [rsp+0x100], xmm5
0000710e9ebd2c59  vmovaps xmm14, [rsp+0x100]
0000710e9ebd2c62  por xmm5, xmm14
0000710e9ebd2c67  movaps [r15+0x2D0], xmm5
0000710e9ebd2c6f  vmovaps xmm14, [rsp+0x120]
0000710e9ebd2c78  vmovaps xmm13, [rsp+0x120]
0000710e9ebd2c81  por xmm14, xmm13
0000710e9ebd2c86  movaps [r15+0x2E0], xmm14
0000710e9ebd2c8e  vmovaps [rsp+0x100], xmm1
0000710e9ebd2c97  vmovaps xmm1, [rsp+0x110]
0000710e9ebd2ca0  vmovaps [rsp+0x110], xmm15
0000710e9ebd2ca9  vmovaps xmm15, [rsp+0xD0]
0000710e9ebd2cb2  vmovaps [rsp+0xD0], xmm14
0000710e9ebd2cbb  movaps xmm13, xmm1
0000710e9ebd2cbf  addpd xmm13, xmm15
0000710e9ebd2cc4  vcmppd xmm14, xmm13, xmm13, 0x03
0000710e9ebd2cca  ptest xmm14, xmm14
0000710e9ebd2cd0  jnz 0x0000710E9EBD4CBB
0000710e9ebd2cd6  vmovaps xmm1, [rsp+0xA0]
0000710e9ebd2cdf  vpermilpd xmm1, xmm1, 0x00
0000710e9ebd2ce5  vmovaps xmm14, [rsp+0x100]
0000710e9ebd2cee  vmovaps [rsp+0x100], xmm13
0000710e9ebd2cf7  movaps xmm15, xmm14
0000710e9ebd2cfb  mulpd xmm15, xmm1
0000710e9ebd2d00  vcmppd xmm13, xmm15, xmm15, 0x03
0000710e9ebd2d06  ptest xmm13, xmm13
0000710e9ebd2d0c  jnz 0x0000710E9EBD4DFE
0000710e9ebd2d12  lea rax, [r14+0x80]
0000710e9ebd2d19  movups xmm1, [r13+rax*1]
0000710e9ebd2d1f  vmovaps xmm13, [rsp+0xE0]
0000710e9ebd2d28  vmovaps [rsp+0xE0], xmm1
0000710e9ebd2d31  movaps xmm14, xmm13
0000710e9ebd2d35  addpd xmm14, xmm2
0000710e9ebd2d3a  vcmppd xmm1, xmm14, xmm14, 0x03
0000710e9ebd2d40  ptest xmm1, xmm1
0000710e9ebd2d45  jnz 0x0000710E9EBD4F4B
0000710e9ebd2d4b  vmovaps xmm13, [rsp+0xF0]
0000710e9ebd2d54  vmovaps xmm2, [rsp+0x20]
0000710e9ebd2d5a  vmovaps [rsp+0x20], xmm15
0000710e9ebd2d60  movaps xmm1, xmm13
0000710e9ebd2d64  addpd xmm1, xmm2
0000710e9ebd2d68  vcmppd xmm15, xmm1, xmm1, 0x03
0000710e9ebd2d6d  ptest xmm15, xmm15
0000710e9ebd2d73  jnz 0x0000710E9EBD508E
0000710e9ebd2d79  vmovaps xmm15, [rsp+0x10]
0000710e9ebd2d7f  vmovaps xmm13, [rsp+0x10]
0000710e9ebd2d85  por xmm15, xmm13
0000710e9ebd2d8a  movaps [r15+0x2F0], xmm15
0000710e9ebd2d92  vmovaps xmm13, [rsp+0xA0]
0000710e9ebd2d9b  vpermilpd xmm13, xmm13, 0x00
0000710e9ebd2da1  vmovaps [rsp+0x10], xmm1
0000710e9ebd2da7  vmovaps xmm1, [rsp+0xE0]
0000710e9ebd2db0  vmovaps [rsp+0xA0], xmm15
0000710e9ebd2db9  movaps xmm2, xmm1
0000710e9ebd2dbc  mulpd xmm2, xmm13
0000710e9ebd2dc1  vcmppd xmm15, xmm2, xmm2, 0x03
0000710e9ebd2dc6  ptest xmm15, xmm15
0000710e9ebd2dcc  jnz 0x0000710E9EBD51CF
0000710e9ebd2dd2  lea rax, [r14+0xD0]
0000710e9ebd2dd9  movups xmm1, [r13+rax*1]
0000710e9ebd2ddf  vmovaps xmm13, [rsp+0xC0]
0000710e9ebd2de8  vmovaps [rsp+0xC0], xmm1
0000710e9ebd2df1  vmovaps xmm1, [rsp+0x110]
0000710e9ebd2dfa  vmovaps [rsp+0xE0], xmm14
0000710e9ebd2e03  movaps xmm15, xmm13
0000710e9ebd2e07  addpd xmm15, xmm1
0000710e9ebd2e0c  vcmppd xmm14, xmm15, xmm15, 0x03
0000710e9ebd2e12  ptest xmm14, xmm14
0000710e9ebd2e18  jnz 0x0000710E9EBD531A
0000710e9ebd2e1e  vmovaps xmm1, [rsp+0xB0]
0000710e9ebd2e27  vpermilpd xmm1, xmm1, 0x00
0000710e9ebd2e2d  movaps xmm14, xmm11
0000710e9ebd2e31  mulpd xmm14, xmm1
0000710e9ebd2e36  vcmppd xmm13, xmm14, xmm14, 0x03
0000710e9ebd2e3c  ptest xmm13, xmm13
0000710e9ebd2e42  jnz 0x0000710E9EBD545D
0000710e9ebd2e48  movaps [r15+0x260], xmm14
0000710e9ebd2e50  vxorps xmm1, xmm1, xmm1
0000710e9ebd2e54  vpbroadcastq xmm1, xmm1
0000710e9ebd2e59  movaps [r15+0x1B0], xmm1
0000710e9ebd2e61  vmovaps xmm1, [rsp+0xB0]
0000710e9ebd2e6a  vpermilpd xmm1, xmm1, 0x00
0000710e9ebd2e70  vmovaps xmm11, [rsp+0xC0]
0000710e9ebd2e79  vmovaps [rsp+0xC0], xmm15
0000710e9ebd2e82  movaps xmm13, xmm11
0000710e9ebd2e86  mulpd xmm13, xmm1
0000710e9ebd2e8b  vcmppd xmm15, xmm13, xmm13, 0x03
0000710e9ebd2e91  ptest xmm15, xmm15
0000710e9ebd2e97  jnz 0x0000710E9EBD55A0
0000710e9ebd2e9d  lea rax, [r14+0xC0]
0000710e9ebd2ea4  movups xmm1, [r13+rax*1]
0000710e9ebd2eaa  vmovaps xmm11, [rsp+0x100]
0000710e9ebd2eb3  vmovaps [rsp+0xF0], xmm1
0000710e9ebd2ebc  vmovaps xmm1, [rsp+0x20]
0000710e9ebd2ec2  vmovaps [rsp+0x20], xmm14
0000710e9ebd2ec8  movaps xmm15, xmm11
0000710e9ebd2ecc  addpd xmm15, xmm1
0000710e9ebd2ed1  vcmppd xmm14, xmm15, xmm15, 0x03
0000710e9ebd2ed7  ptest xmm14, xmm14
0000710e9ebd2edd  jnz 0x0000710E9EBD56ED
0000710e9ebd2ee3  vmovaps [rsp+0x100], xmm9
0000710e9ebd2eec  vmovaps xmm1, [rsp+0x100]
0000710e9ebd2ef5  por xmm9, xmm1
0000710e9ebd2efa  movaps [r15+0x270], xmm9
0000710e9ebd2f02  vmovaps [rsp+0x100], xmm6
0000710e9ebd2f0b  vmovaps xmm1, [rsp+0x100]
0000710e9ebd2f14  por xmm6, xmm1
0000710e9ebd2f18  movaps [r15+0x1A0], xmm6
0000710e9ebd2f20  vmovaps xmm14, [rsp+0xB0]
0000710e9ebd2f29  vpermilpd xmm14, xmm14, 0x00
0000710e9ebd2f2f  vmovaps xmm6, [rsp+0xF0]
0000710e9ebd2f38  vmovaps [rsp+0xF0], xmm1
0000710e9ebd2f41  movaps xmm11, xmm6
0000710e9ebd2f45  mulpd xmm11, xmm14
0000710e9ebd2f4a  vcmppd xmm1, xmm11, xmm11, 0x03
0000710e9ebd2f50  ptest xmm1, xmm1
0000710e9ebd2f55  jnz 0x0000710E9EBD5830
0000710e9ebd2f5b  lea rax, [r14+0x20]
0000710e9ebd2f5f  movups xmm1, [r13+rax*1]
0000710e9ebd2f65  movaps [r15+0x110], xmm1
0000710e9ebd2f6d  vmovaps xmm6, [rsp+0xE0]
0000710e9ebd2f76  vmovaps [rsp+0xE0], xmm1
0000710e9ebd2f7f  movaps xmm14, xmm6
0000710e9ebd2f83  addpd xmm14, xmm2
0000710e9ebd2f88  vcmppd xmm1, xmm14, xmm14, 0x03
0000710e9ebd2f8e  ptest xmm1, xmm1
0000710e9ebd2f93  jnz 0x0000710E9EBD597D
0000710e9ebd2f99  vmovaps xmm1, [rsp+0xB0]
0000710e9ebd2fa2  vpermilpd xmm1, xmm1, 0x00
0000710e9ebd2fa8  movaps xmm6, xmm5
0000710e9ebd2fab  mulpd xmm6, xmm1
0000710e9ebd2faf  vcmppd xmm2, xmm6, xmm6, 0x03
0000710e9ebd2fb4  ptest xmm2, xmm2
0000710e9ebd2fb9  jnz 0x0000710E9EBD5ABF
0000710e9ebd2fbf  vmovaps xmm5, [rsp+0x10]
0000710e9ebd2fc5  movaps xmm1, xmm5
0000710e9ebd2fc8  addpd xmm1, xmm13
0000710e9ebd2fcd  vcmppd xmm2, xmm1, xmm1, 0x03
0000710e9ebd2fd2  ptest xmm2, xmm2
0000710e9ebd2fd7  jnz 0x0000710E9EBD5BFF
0000710e9ebd2fdd  vmovaps xmm13, [rsp+0x80]
0000710e9ebd2fe6  vpermilpd xmm13, xmm13, 0x00
0000710e9ebd2fec  vmovaps xmm2, [rsp+0xE0]
0000710e9ebd2ff5  vmovaps [rsp+0x10], xmm1
0000710e9ebd2ffb  movaps xmm5, xmm2
0000710e9ebd2ffe  mulpd xmm5, xmm13
0000710e9ebd3003  vcmppd xmm1, xmm5, xmm5, 0x03
0000710e9ebd3008  ptest xmm1, xmm1
0000710e9ebd300d  jnz 0x0000710E9EBD5D40
0000710e9ebd3013  vmovaps xmm1, [rsp+0x80]
0000710e9ebd301c  vpermilpd xmm1, xmm1, 0x00
0000710e9ebd3022  movaps xmm13, xmm10
0000710e9ebd3026  mulpd xmm13, xmm1
0000710e9ebd302b  vcmppd xmm2, xmm13, xmm13, 0x03
0000710e9ebd3031  ptest xmm2, xmm2
0000710e9ebd3036  jnz 0x0000710E9EBD5E81
0000710e9ebd303c  vmovaps xmm10, [rsp+0x20]
0000710e9ebd3042  movaps xmm1, xmm15
0000710e9ebd3046  addpd xmm1, xmm10
0000710e9ebd304b  vcmppd xmm2, xmm1, xmm1, 0x03
0000710e9ebd3050  ptest xmm2, xmm2
0000710e9ebd3055  jnz 0x0000710E9EBD5FC4
0000710e9ebd305b  vmovaps xmm10, [rsp+0xC0]
0000710e9ebd3064  movaps xmm15, xmm10
0000710e9ebd3068  addpd xmm15, xmm11
0000710e9ebd306d  vcmppd xmm2, xmm15, xmm15, 0x03
0000710e9ebd3073  ptest xmm2, xmm2
0000710e9ebd3078  jnz 0x0000710E9EBD6106
0000710e9ebd307e  vmovaps xmm11, [rsp+0x80]
0000710e9ebd3087  vpermilpd xmm11, xmm11, 0x00
0000710e9ebd308d  vmovaps xmm2, [rsp+0xD0]
0000710e9ebd3096  vmovaps [rsp+0x20], xmm1
0000710e9ebd309c  movaps xmm10, xmm2
0000710e9ebd30a0  mulpd xmm10, xmm11
0000710e9ebd30a5  vcmppd xmm1, xmm10, xmm10, 0x03
0000710e9ebd30ab  ptest xmm1, xmm1
0000710e9ebd30b0  jnz 0x0000710E9EBD624A
0000710e9ebd30b6  vmovaps xmm1, [rsp+0x80]
0000710e9ebd30bf  vpermilpd xmm1, xmm1, 0x00
0000710e9ebd30c5  vmovaps xmm2, [rsp+0xA0]
0000710e9ebd30ce  vmovaps [rsp+0x80], xmm15
0000710e9ebd30d7  movaps xmm11, xmm2
0000710e9ebd30db  mulpd xmm11, xmm1
0000710e9ebd30e0  vcmppd xmm15, xmm11, xmm11, 0x03
0000710e9ebd30e6  ptest xmm15, xmm15
0000710e9ebd30ec  jnz 0x0000710E9EBD638D
0000710e9ebd30f2  movaps xmm1, xmm14
0000710e9ebd30f6  addpd xmm1, xmm6
0000710e9ebd30fa  vcmppd xmm15, xmm1, xmm1, 0x03
0000710e9ebd30ff  ptest xmm15, xmm15
0000710e9ebd3105  jnz 0x0000710E9EBD64CF
0000710e9ebd310b  vmovaps xmm14, [rsp+0x10]
0000710e9ebd3111  movaps xmm15, xmm14
0000710e9ebd3115  addpd xmm15, xmm5
0000710e9ebd311a  vcmppd xmm6, xmm15, xmm15, 0x03
0000710e9ebd3120  ptest xmm6, xmm6
0000710e9ebd3125  jnz 0x0000710E9EBD6610
0000710e9ebd312b  vmovaps xmm14, [rsp+0x90]
0000710e9ebd3134  vpermilpd xmm14, xmm14, 0x00
0000710e9ebd313a  movaps xmm6, xmm9
0000710e9ebd313e  mulpd xmm6, xmm14
0000710e9ebd3143  vcmppd xmm5, xmm6, xmm6, 0x03
0000710e9ebd3148  ptest xmm5, xmm5
0000710e9ebd314d  jnz 0x0000710E9EBD6753
0000710e9ebd3153  vmovaps xmm9, [rsp+0x80]
0000710e9ebd315c  movaps xmm14, xmm9
0000710e9ebd3160  addpd xmm14, xmm13
0000710e9ebd3165  vcmppd xmm5, xmm14, xmm14, 0x03
0000710e9ebd316b  ptest xmm5, xmm5
0000710e9ebd3170  jnz 0x0000710E9EBD6895
0000710e9ebd3176  vmovaps xmm9, [rsp+0x20]
0000710e9ebd317c  movaps xmm13, xmm9
0000710e9ebd3180  addpd xmm13, xmm10
0000710e9ebd3185  vcmppd xmm5, xmm13, xmm13, 0x03
0000710e9ebd318b  ptest xmm5, xmm5
0000710e9ebd3190  jnz 0x0000710E9EBD69D9
0000710e9ebd3196  vmovaps [rsp+0x10], xmm12
0000710e9ebd319c  vmovaps xmm10, [rsp+0x10]
0000710e9ebd31a2  por xmm12, xmm10
0000710e9ebd31a7  movaps [r15+0x250], xmm12
0000710e9ebd31af  vmovaps [rsp+0x10], xmm7
0000710e9ebd31b5  vmovaps xmm12, [rsp+0x10]
0000710e9ebd31bb  por xmm7, xmm12
0000710e9ebd31c0  movaps [r15+0x2A0], xmm7
0000710e9ebd31c8  vmovaps [rsp+0x10], xmm3
0000710e9ebd31ce  vmovaps xmm12, [rsp+0x10]
0000710e9ebd31d4  por xmm3, xmm12
0000710e9ebd31d9  movaps [r15+0x1D0], xmm3
0000710e9ebd31e1  lea rax, [r14+0x40]
0000710e9ebd31e5  movups xmm12, [r13+rax*1]
0000710e9ebd31eb  movaps [r15+0x2C0], xmm12
0000710e9ebd31f3  vmovaps xmm10, [rsp+0x90]
0000710e9ebd31fc  vpermilpd xmm10, xmm10, 0x00
0000710e9ebd3202  movaps xmm9, xmm8
0000710e9ebd3206  mulpd xmm9, xmm10
0000710e9ebd320b  vcmppd xmm5, xmm9, xmm9, 0x03
0000710e9ebd3211  ptest xmm5, xmm5
0000710e9ebd3216  jnz 0x0000710E9EBD6B27
0000710e9ebd321c  movaps xmm10, xmm1
0000710e9ebd3220  addpd xmm10, xmm11
0000710e9ebd3225  vcmppd xmm8, xmm10, xmm10, 0x03
0000710e9ebd322b  ptest xmm8, xmm8
0000710e9ebd3231  jnz 0x0000710E9EBD6C6B
0000710e9ebd3237  movaps xmm1, xmm15
0000710e9ebd323b  addpd xmm1, xmm6
0000710e9ebd323f  vcmppd xmm11, xmm1, xmm1, 0x03
0000710e9ebd3244  ptest xmm11, xmm11
0000710e9ebd324a  jnz 0x0000710E9EBD6DAE
0000710e9ebd3250  vmovaps xmm15, [rsp+0x90]
0000710e9ebd3259  vpermilpd xmm15, xmm15, 0x00
0000710e9ebd325f  movaps xmm11, xmm12
0000710e9ebd3263  mulpd xmm11, xmm15
0000710e9ebd3268  vcmppd xmm8, xmm11, xmm11, 0x03
0000710e9ebd326e  ptest xmm8, xmm8
0000710e9ebd3274  jnz 0x0000710E9EBD6EEF
0000710e9ebd327a  vmovaps xmm15, [rsp+0x90]
0000710e9ebd3283  vpermilpd xmm15, xmm15, 0x00
0000710e9ebd3289  vmovaps xmm8, [rsp+0x50]
0000710e9ebd328f  movaps xmm12, xmm8
0000710e9ebd3293  mulpd xmm12, xmm15
0000710e9ebd3298  vcmppd xmm6, xmm12, xmm12, 0x03
0000710e9ebd329e  ptest xmm6, xmm6
0000710e9ebd32a3  jnz 0x0000710E9EBD7033
0000710e9ebd32a9  vmovaps xmm15, [rsp+0x30]
0000710e9ebd32af  vpermilpd xmm15, xmm15, 0x00
0000710e9ebd32b5  movaps xmm8, xmm7
0000710e9ebd32b9  mulpd xmm8, xmm15
0000710e9ebd32be  vcmppd xmm6, xmm8, xmm8, 0x03
0000710e9ebd32c4  ptest xmm6, xmm6
0000710e9ebd32c9  jnz 0x0000710E9EBD7177
0000710e9ebd32cf  movaps xmm15, xmm14
0000710e9ebd32d3  addpd xmm15, xmm9
0000710e9ebd32d8  vcmppd xmm7, xmm15, xmm15, 0x03
0000710e9ebd32de  ptest xmm7, xmm7
0000710e9ebd32e3  jnz 0x0000710E9EBD72BA
0000710e9ebd32e9  vmovaps xmm14, [rsp+0x30]
0000710e9ebd32ef  vpermilpd xmm14, xmm14, 0x00
0000710e9ebd32f5  vmovaps xmm7, [rsp+0xF0]
0000710e9ebd32fe  movaps xmm9, xmm7
0000710e9ebd3302  mulpd xmm9, xmm14
0000710e9ebd3307  vcmppd xmm6, xmm9, xmm9, 0x03
0000710e9ebd330d  ptest xmm6, xmm6
0000710e9ebd3312  jnz 0x0000710E9EBD73FE
0000710e9ebd3318  movaps xmm14, xmm13
0000710e9ebd331c  addpd xmm14, xmm11
0000710e9ebd3321  vcmppd xmm7, xmm14, xmm14, 0x03
0000710e9ebd3327  ptest xmm7, xmm7
0000710e9ebd332c  jnz 0x0000710E9EBD7541
0000710e9ebd3332  vmovaps xmm13, [rsp+0x30]
0000710e9ebd3338  vpermilpd xmm13, xmm13, 0x00
0000710e9ebd333e  vmovaps xmm7, [rsp+0x60]
0000710e9ebd3344  movaps xmm11, xmm7
0000710e9ebd3348  mulpd xmm11, xmm13
0000710e9ebd334d  vcmppd xmm6, xmm11, xmm11, 0x03
0000710e9ebd3353  ptest xmm6, xmm6
0000710e9ebd3358  jnz 0x0000710E9EBD7685
0000710e9ebd335e  movaps xmm13, xmm10
0000710e9ebd3362  addpd xmm13, xmm12
0000710e9ebd3367  vcmppd xmm7, xmm13, xmm13, 0x03
0000710e9ebd336d  ptest xmm7, xmm7
0000710e9ebd3372  jnz 0x0000710E9EBD77C8
0000710e9ebd3378  vmovaps xmm12, [rsp+0x30]
0000710e9ebd337e  vpermilpd xmm12, xmm12, 0x00
0000710e9ebd3384  vmovaps xmm7, [rsp+0x70]
0000710e9ebd338a  movaps xmm10, xmm7
0000710e9ebd338e  mulpd xmm10, xmm12
0000710e9ebd3393  vcmppd xmm6, xmm10, xmm10, 0x03
0000710e9ebd3399  ptest xmm6, xmm6
0000710e9ebd339e  jnz 0x0000710E9EBD790C
0000710e9ebd33a4  movaps xmm12, xmm1
0000710e9ebd33a8  addpd xmm12, xmm8
0000710e9ebd33ad  vcmppd xmm7, xmm12, xmm12, 0x03
0000710e9ebd33b3  ptest xmm7, xmm7
0000710e9ebd33b8  jnz 0x0000710E9EBD7A4F
0000710e9ebd33be  lea rax, [r14+0x70]
0000710e9ebd33c2  movups xmm1, [r13+rax*1]
0000710e9ebd33c8  movaps [r15+0x240], xmm1
0000710e9ebd33d0  movaps xmm8, xmm15
0000710e9ebd33d4  addpd xmm8, xmm9
0000710e9ebd33d9  vcmppd xmm7, xmm8, xmm8, 0x03
0000710e9ebd33df  ptest xmm7, xmm7
0000710e9ebd33e4  jnz 0x0000710E9EBD7B9C
0000710e9ebd33ea  movaps [r15+0x170], xmm8
0000710e9ebd33f2  vmovaps xmm15, [rsp+0x40]
0000710e9ebd33f8  vpermilpd xmm15, xmm15, 0x00
0000710e9ebd33fe  movaps xmm9, xmm1
0000710e9ebd3402  mulpd xmm9, xmm15
0000710e9ebd3407  vcmppd xmm7, xmm9, xmm9, 0x03
0000710e9ebd340d  ptest xmm7, xmm7
0000710e9ebd3412  jnz 0x0000710E9EBD7CE0
0000710e9ebd3418  vmovaps xmm1, [rsp+0x40]
0000710e9ebd341e  vpermilpd xmm1, xmm1, 0x00
0000710e9ebd3424  movaps xmm15, xmm4
0000710e9ebd3428  mulpd xmm15, xmm1
0000710e9ebd342d  vcmppd xmm7, xmm15, xmm15, 0x03
0000710e9ebd3433  ptest xmm7, xmm7
0000710e9ebd3438  jnz 0x0000710E9EBD7E23
0000710e9ebd343e  movaps [r15+0x180], xmm15
0000710e9ebd3446  movaps xmm1, xmm14
0000710e9ebd344a  addpd xmm1, xmm11
0000710e9ebd344f  vcmppd xmm7, xmm1, xmm1, 0x03
0000710e9ebd3454  ptest xmm7, xmm7
0000710e9ebd3459  jnz 0x0000710E9EBD7F65
0000710e9ebd345f  movaps [r15+0x210], xmm1
0000710e9ebd3467  movups xmm14, [r13+r14*1]
0000710e9ebd346d  lea rax, [r14+0x10]
0000710e9ebd3471  movups xmm11, [r13+rax*1]
0000710e9ebd3477  movaps [r15+0x230], xmm11
0000710e9ebd347f  movaps xmm7, xmm13
0000710e9ebd3483  addpd xmm7, xmm10
0000710e9ebd3488  vcmppd xmm6, xmm7, xmm7, 0x03
0000710e9ebd348d  ptest xmm6, xmm6
0000710e9ebd3492  jnz 0x0000710E9EBD80BB
0000710e9ebd3498  movaps [r15+0x130], xmm7
0000710e9ebd34a0  vmovaps xmm13, [rsp+0x40]
0000710e9ebd34a6  vpermilpd xmm13, xmm13, 0x00
0000710e9ebd34ac  movaps xmm10, xmm11
0000710e9ebd34b0  mulpd xmm10, xmm13
0000710e9ebd34b5  vcmppd xmm6, xmm10, xmm10, 0x03
0000710e9ebd34bb  ptest xmm6, xmm6
0000710e9ebd34c0  jnz 0x0000710E9EBD81FD
0000710e9ebd34c6  movaps [r15+0x220], xmm10
0000710e9ebd34ce  vmovaps xmm13, [rsp+0x40]
0000710e9ebd34d4  vpermilpd xmm13, xmm13, 0x00
0000710e9ebd34da  movaps xmm11, xmm14
0000710e9ebd34de  mulpd xmm11, xmm13
0000710e9ebd34e3  vcmppd xmm6, xmm11, xmm11, 0x03
0000710e9ebd34e9  ptest xmm6, xmm6
0000710e9ebd34ee  jnz 0x0000710E9EBD8341
0000710e9ebd34f4  movaps xmm14, xmm12
0000710e9ebd34f8  addpd xmm14, xmm9
0000710e9ebd34fd  vcmppd xmm13, xmm14, xmm14, 0x03
0000710e9ebd3503  ptest xmm13, xmm13
0000710e9ebd3509  jnz 0x0000710E9EBD8485
0000710e9ebd350f  movaps [r15+0x140], xmm14
0000710e9ebd3517  movaps xmm13, xmm8
0000710e9ebd351b  addpd xmm13, xmm15
0000710e9ebd3520  vcmppd xmm12, xmm13, xmm13, 0x03
0000710e9ebd3526  ptest xmm12, xmm12
0000710e9ebd352c  jnz 0x0000710E9EBD85C9
0000710e9ebd3532  movaps [r15+0x150], xmm13
0000710e9ebd353a  movaps xmm15, xmm1
0000710e9ebd353e  addpd xmm15, xmm10
0000710e9ebd3543  vcmppd xmm12, xmm15, xmm15, 0x03
0000710e9ebd3549  ptest xmm12, xmm12
0000710e9ebd354f  jnz 0x0000710E9EBD870D
0000710e9ebd3555  movaps [r15+0x160], xmm15
0000710e9ebd355d  movaps xmm1, xmm7
0000710e9ebd3560  addpd xmm1, xmm11
0000710e9ebd3565  vcmppd xmm12, xmm1, xmm1, 0x03
0000710e9ebd356a  ptest xmm12, xmm12
0000710e9ebd3570  jnz 0x0000710E9EBD8850
0000710e9ebd3576  movaps [r15+0x120], xmm1
0000710e9ebd357e  mov eax, 0x432200
0000710e9ebd3583  movups [r13+rax*1], xmm14
0000710e9ebd3589  mov eax, 0x432210
0000710e9ebd358e  movups [r13+rax*1], xmm13
0000710e9ebd3594  mov eax, 0x432220
0000710e9ebd3599  movups [r13+rax*1], xmm15
0000710e9ebd359f  mov eax, 0x432230
0000710e9ebd35a4  movups [r13+rax*1], xmm1
0000710e9ebd35aa  mov eax, [r15+0x108]
0000710e9ebd35b1  sahf
0000710e9ebd35b2  jnz 0x0000710E9EBD35E4
0000710e9ebd35b4  cmp dword ptr [r15+0x318], 0x00
0000710e9ebd35bc  jz 0x0000710E9EBDEAE0
0000710e9ebd35c2  nop [rax+rax*1], ax
0000710e9ebd35cb  nop [rax+rax*1], eax
0000710e9ebd35d3  mov eax, 0x4106D0
0000710e9ebd35d8  mov [r15+0x100], rax
0000710e9ebd35df  jmp 0x0000710E9E9FE110
0000710e9ebd35e4  cmp dword ptr [r15+0x318], 0x00
0000710e9ebd35ec  jz 0x0000710E9EBD89C0
0000710e9ebd35f2  nop [rax+rax*1], ax
0000710e9ebd35fb  nop [rax+rax*1], eax
0000710e9ebd3603  mov eax, 0x410504
0000710e9ebd3608  mov [r15+0x100], rax
0000710e9ebd360f  jmp 0x0000710E9E9FE110
0000710e9ebd3614  int3
0000710e9ebd3615  call 0x0000710E9EAD64F0
0000710e9ebd361a  jmp 0x0000710E9EBD2311
0000710e9ebd361f  call 0x0000710E9EAE5820
0000710e9ebd3624  jmp 0x0000710E9EBD231E
0000710e9ebd3629  call 0x0000710E9EAE3320
0000710e9ebd362e  jmp 0x0000710E9EBD2332
0000710e9ebd3633  call 0x0000710E9EAE20A0
0000710e9ebd3638  jmp 0x0000710E9EBD233C
0000710e9ebd363d  call 0x0000710E9EA09D70
0000710e9ebd3642  jmp 0x0000710E9EBD234A
0000710e9ebd3647  call 0x0000710E9EADFBC0
0000710e9ebd364c  jmp 0x0000710E9EBD2354
0000710e9ebd3651  call 0x0000710E9EAC4740
0000710e9ebd3656  jmp 0x0000710E9EBD2368
0000710e9ebd365b  call 0x0000710E9EAB5400
0000710e9ebd3660  jmp 0x0000710E9EBD2375
0000710e9ebd3665  call 0x0000710E9EAB52F0
0000710e9ebd366a  jmp 0x0000710E9EBD2382
0000710e9ebd366f  call 0x0000710E9EAC4620
0000710e9ebd3674  jmp 0x0000710E9EBD238F
0000710e9ebd3679  call 0x0000710E9EABD750
0000710e9ebd367e  jmp 0x0000710E9EBD239C
0000710e9ebd3683  call 0x0000710E9EABC4E0
0000710e9ebd3688  jmp 0x0000710E9EBD23A9
0000710e9ebd368d  call 0x0000710E9EABB270
0000710e9ebd3692  jmp 0x0000710E9EBD23B6
0000710e9ebd3697  call 0x0000710E9EABA000
0000710e9ebd369c  jmp 0x0000710E9EBD23C3
0000710e9ebd36a1  call 0x0000710E9EAC4740
0000710e9ebd36a6  jmp 0x0000710E9EBD23D0
0000710e9ebd36ab  call 0x0000710E9EAB5400
0000710e9ebd36b0  jmp 0x0000710E9EBD23DD
0000710e9ebd36b5  call 0x0000710E9EAB52F0
0000710e9ebd36ba  jmp 0x0000710E9EBD23EA
0000710e9ebd36bf  call 0x0000710E9EAC4620
0000710e9ebd36c4  jmp 0x0000710E9EBD23F7
0000710e9ebd36c9  call 0x0000710E9EAB8D90
0000710e9ebd36ce  jmp 0x0000710E9EBD2404
0000710e9ebd36d3  call 0x0000710E9EAB8A20
0000710e9ebd36d8  jmp 0x0000710E9EBD2411
0000710e9ebd36dd  call 0x0000710E9EAB77B0
0000710e9ebd36e2  jmp 0x0000710E9EBD241B
0000710e9ebd36e7  call 0x0000710E9EAB6550
0000710e9ebd36ec  jmp 0x0000710E9EBD2425
0000710e9ebd36f1  call 0x0000710E9EAB5400
0000710e9ebd36f6  jmp 0x0000710E9EBD2437
0000710e9ebd36fb  call 0x0000710E9EAC0FC0
0000710e9ebd3700  jmp 0x0000710E9EBD2441
0000710e9ebd3705  call 0x0000710E9EAB52F0
0000710e9ebd370a  jmp 0x0000710E9EBD244B
0000710e9ebd370f  call 0x0000710E9EAC0EA0
0000710e9ebd3714  jmp 0x0000710E9EBD2455
0000710e9ebd3719  call 0x0000710E9EABFD50
0000710e9ebd371e  jmp 0x0000710E9EBD245F
0000710e9ebd3723  call 0x0000710E9EAB8EA0
0000710e9ebd3728  jmp 0x0000710E9EBD2469
0000710e9ebd372d  call 0x0000710E9EABFC30
0000710e9ebd3732  jmp 0x0000710E9EBD2476
0000710e9ebd3737  call 0x0000710E9EAB8D90
0000710e9ebd373c  jmp 0x0000710E9EBD2483
0000710e9ebd3741  call 0x0000710E9EAB52F0
0000710e9ebd3746  jmp 0x0000710E9EBD2496
0000710e9ebd374b  call 0x0000710E9EAB52F0
0000710e9ebd3750  jmp 0x0000710E9EBD24A9
0000710e9ebd3755  call 0x0000710E9EAC0FC0
0000710e9ebd375a  jmp 0x0000710E9EBD24B6
0000710e9ebd375f  call 0x0000710E9EAC0FC0
0000710e9ebd3764  jmp 0x0000710E9EBD24C9
0000710e9ebd3769  call 0x0000710E9EAC0EA0
0000710e9ebd376e  jmp 0x0000710E9EBD24D6
0000710e9ebd3773  call 0x0000710E9EAB52F0
0000710e9ebd3778  jmp 0x0000710E9EBD24E9
0000710e9ebd377d  call 0x0000710E9EAB52F0
0000710e9ebd3782  jmp 0x0000710E9EBD24FC
0000710e9ebd3787  call 0x0000710E9EAB52F0
0000710e9ebd378c  jmp 0x0000710E9EBD250F
0000710e9ebd3791  call 0x0000710E9EAB52F0
0000710e9ebd3796  jmp 0x0000710E9EBD252A
0000710e9ebd379b  call 0x0000710E9EAB52F0
0000710e9ebd37a0  jmp 0x0000710E9EBD253D
0000710e9ebd37a5  call 0x0000710E9EAB5400
0000710e9ebd37aa  jmp 0x0000710E9EBD257E
0000710e9ebd37af  call 0x0000710E9EAC0FC0
0000710e9ebd37b4  jmp 0x0000710E9EBD258B
0000710e9ebd37b9  call 0x0000710E9EAB52F0
0000710e9ebd37be  jmp 0x0000710E9EBD2598
0000710e9ebd37c3  call 0x0000710E9EAC0EA0
0000710e9ebd37c8  jmp 0x0000710E9EBD25A5
0000710e9ebd37cd  call 0x0000710E9E9FF540
0000710e9ebd37d2  jmp 0x0000710E9EBD25C3
0000710e9ebd37d7  call 0x0000710E9EA08C20
0000710e9ebd37dc  jmp 0x0000710E9EBD25CD
0000710e9ebd37e1  call 0x0000710E9EAE21C0
0000710e9ebd37e6  jmp 0x0000710E9EBD25D3
0000710e9ebd37eb  call 0x0000710E9E9FF540
0000710e9ebd37f0  jmp 0x0000710E9EBD25E3
0000710e9ebd37f5  call 0x0000710E9EAC0370
0000710e9ebd37fa  jmp 0x0000710E9EBD2611
0000710e9ebd37ff  call 0x0000710E9EABF100
0000710e9ebd3804  jmp 0x0000710E9EBD261A
0000710e9ebd3809  call 0x0000710E9EAC0370
0000710e9ebd380e  jmp 0x0000710E9EBD2674
0000710e9ebd3813  call 0x0000710E9EABF100
0000710e9ebd3818  jmp 0x0000710E9EBD267D
0000710e9ebd381d  call 0x0000710E9EAC0370
0000710e9ebd3822  jmp 0x0000710E9EBD26C6
0000710e9ebd3827  call 0x0000710E9EABF100
0000710e9ebd382c  jmp 0x0000710E9EBD26CF
0000710e9ebd3831  call 0x0000710E9EA0B720
0000710e9ebd3836  jmp 0x0000710E9EBD2714
0000710e9ebd383b  call 0x0000710E9EAB47C0
0000710e9ebd3840  jmp 0x0000710E9EBD2727
0000710e9ebd3845  call 0x0000710E9EA08B00
0000710e9ebd384a  jmp 0x0000710E9EBD273E
0000710e9ebd384f  call 0x0000710E9E9FF430
0000710e9ebd3854  jmp 0x0000710E9EBD2751
0000710e9ebd3859  call 0x0000710E9E9FF430
0000710e9ebd385e  jmp 0x0000710E9EBD2764
0000710e9ebd3863  sub rsp, 0x08
0000710e9ebd3867  push rax
0000710e9ebd3868  push rcx
0000710e9ebd3869  push rdx
0000710e9ebd386a  push rdi
0000710e9ebd386b  push rsi
0000710e9ebd386c  push r8
0000710e9ebd386e  push r9
0000710e9ebd3870  push r10
0000710e9ebd3872  push r11
0000710e9ebd3874  sub rsp, 0xF0
0000710e9ebd387b  vmovaps [rsp], xmm0
0000710e9ebd3880  vmovaps [rsp+0x10], xmm2
0000710e9ebd3886  vmovaps [rsp+0x20], xmm3
0000710e9ebd388c  vmovaps [rsp+0x30], xmm4
0000710e9ebd3892  vmovaps [rsp+0x40], xmm5
0000710e9ebd3898  vmovaps [rsp+0x50], xmm6
0000710e9ebd389e  vmovaps [rsp+0x60], xmm7
0000710e9ebd38a4  vmovaps [rsp+0x70], xmm8
0000710e9ebd38aa  vmovaps [rsp+0x80], xmm9
0000710e9ebd38b3  vmovaps [rsp+0x90], xmm10
0000710e9ebd38bc  vmovaps [rsp+0xA0], xmm11
0000710e9ebd38c5  vmovaps [rsp+0xB0], xmm12
0000710e9ebd38ce  vmovaps [rsp+0xC0], xmm13
0000710e9ebd38d7  vmovaps [rsp+0xD0], xmm14
0000710e9ebd38e0  vmovaps [rsp+0xE0], xmm15
0000710e9ebd38e9  sub rsp, 0x30
0000710e9ebd38ed  movaps [rsp], xmm1
0000710e9ebd38f1  movaps [rsp+0x10], xmm12
0000710e9ebd38f7  movaps [rsp+0x20], xmm15
0000710e9ebd38fd  lea rdi, [rsp]
0000710e9ebd3901  mov esi, 0x00
0000710e9ebd3906  mov rax, 0x5DADAF7CF530
0000710e9ebd3910  call rax
0000710e9ebd3912  movaps xmm1, [rsp]
0000710e9ebd3916  add rsp, 0x30
0000710e9ebd391a  vmovaps xmm0, [rsp]
0000710e9ebd391f  vmovaps xmm2, [rsp+0x10]
0000710e9ebd3925  vmovaps xmm3, [rsp+0x20]
0000710e9ebd392b  vmovaps xmm4, [rsp+0x30]
0000710e9ebd3931  vmovaps xmm5, [rsp+0x40]
0000710e9ebd3937  vmovaps xmm6, [rsp+0x50]
0000710e9ebd393d  vmovaps xmm7, [rsp+0x60]
0000710e9ebd3943  vmovaps xmm8, [rsp+0x70]
0000710e9ebd3949  vmovaps xmm9, [rsp+0x80]
0000710e9ebd3952  vmovaps xmm10, [rsp+0x90]
0000710e9ebd395b  vmovaps xmm11, [rsp+0xA0]
0000710e9ebd3964  vmovaps xmm12, [rsp+0xB0]
0000710e9ebd396d  vmovaps xmm13, [rsp+0xC0]
0000710e9ebd3976  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd397f  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd3988  add rsp, 0xF0
0000710e9ebd398f  pop r11
0000710e9ebd3991  pop r10
0000710e9ebd3993  pop r9
0000710e9ebd3995  pop r8
0000710e9ebd3997  pop rsi
0000710e9ebd3998  pop rdi
0000710e9ebd3999  pop rdx
0000710e9ebd399a  pop rcx
0000710e9ebd399b  pop rax
0000710e9ebd399c  add rsp, 0x08
0000710e9ebd39a0  jmp 0x0000710E9EBD27B2
0000710e9ebd39a5  sub rsp, 0x08
0000710e9ebd39a9  push rax
0000710e9ebd39aa  push rcx
0000710e9ebd39ab  push rdx
0000710e9ebd39ac  push rdi
0000710e9ebd39ad  push rsi
0000710e9ebd39ae  push r8
0000710e9ebd39b0  push r9
0000710e9ebd39b2  push r10
0000710e9ebd39b4  push r11
0000710e9ebd39b6  sub rsp, 0xF0
0000710e9ebd39bd  vmovaps [rsp], xmm0
0000710e9ebd39c2  vmovaps [rsp+0x10], xmm1
0000710e9ebd39c8  vmovaps [rsp+0x20], xmm2
0000710e9ebd39ce  vmovaps [rsp+0x30], xmm3
0000710e9ebd39d4  vmovaps [rsp+0x40], xmm4
0000710e9ebd39da  vmovaps [rsp+0x50], xmm5
0000710e9ebd39e0  vmovaps [rsp+0x60], xmm6
0000710e9ebd39e6  vmovaps [rsp+0x70], xmm7
0000710e9ebd39ec  vmovaps [rsp+0x80], xmm8
0000710e9ebd39f5  vmovaps [rsp+0x90], xmm9
0000710e9ebd39fe  vmovaps [rsp+0xA0], xmm10
0000710e9ebd3a07  vmovaps [rsp+0xB0], xmm11
0000710e9ebd3a10  vmovaps [rsp+0xC0], xmm12
0000710e9ebd3a19  vmovaps [rsp+0xD0], xmm13
0000710e9ebd3a22  vmovaps [rsp+0xE0], xmm15
0000710e9ebd3a2b  sub rsp, 0x30
0000710e9ebd3a2f  movaps [rsp], xmm14
0000710e9ebd3a34  movaps [rsp+0x10], xmm1
0000710e9ebd3a39  movaps [rsp+0x20], xmm15
0000710e9ebd3a3f  lea rdi, [rsp]
0000710e9ebd3a43  mov esi, 0x00
0000710e9ebd3a48  mov rax, 0x5DADAF7CF530
0000710e9ebd3a52  call rax
0000710e9ebd3a54  movaps xmm14, [rsp]
0000710e9ebd3a59  add rsp, 0x30
0000710e9ebd3a5d  vmovaps xmm0, [rsp]
0000710e9ebd3a62  vmovaps xmm1, [rsp+0x10]
0000710e9ebd3a68  vmovaps xmm2, [rsp+0x20]
0000710e9ebd3a6e  vmovaps xmm3, [rsp+0x30]
0000710e9ebd3a74  vmovaps xmm4, [rsp+0x40]
0000710e9ebd3a7a  vmovaps xmm5, [rsp+0x50]
0000710e9ebd3a80  vmovaps xmm6, [rsp+0x60]
0000710e9ebd3a86  vmovaps xmm7, [rsp+0x70]
0000710e9ebd3a8c  vmovaps xmm8, [rsp+0x80]
0000710e9ebd3a95  vmovaps xmm9, [rsp+0x90]
0000710e9ebd3a9e  vmovaps xmm10, [rsp+0xA0]
0000710e9ebd3aa7  vmovaps xmm11, [rsp+0xB0]
0000710e9ebd3ab0  vmovaps xmm12, [rsp+0xC0]
0000710e9ebd3ab9  vmovaps xmm13, [rsp+0xD0]
0000710e9ebd3ac2  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd3acb  add rsp, 0xF0
0000710e9ebd3ad2  pop r11
0000710e9ebd3ad4  pop r10
0000710e9ebd3ad6  pop r9
0000710e9ebd3ad8  pop r8
0000710e9ebd3ada  pop rsi
0000710e9ebd3adb  pop rdi
0000710e9ebd3adc  pop rdx
0000710e9ebd3add  pop rcx
0000710e9ebd3ade  pop rax
0000710e9ebd3adf  add rsp, 0x08
0000710e9ebd3ae3  jmp 0x0000710E9EBD2800
0000710e9ebd3ae8  sub rsp, 0x08
0000710e9ebd3aec  push rax
0000710e9ebd3aed  push rcx
0000710e9ebd3aee  push rdx
0000710e9ebd3aef  push rdi
0000710e9ebd3af0  push rsi
0000710e9ebd3af1  push r8
0000710e9ebd3af3  push r9
0000710e9ebd3af5  push r10
0000710e9ebd3af7  push r11
0000710e9ebd3af9  sub rsp, 0xF0
0000710e9ebd3b00  vmovaps [rsp], xmm0
0000710e9ebd3b05  vmovaps [rsp+0x10], xmm1
0000710e9ebd3b0b  vmovaps [rsp+0x20], xmm2
0000710e9ebd3b11  vmovaps [rsp+0x30], xmm3
0000710e9ebd3b17  vmovaps [rsp+0x40], xmm4
0000710e9ebd3b1d  vmovaps [rsp+0x50], xmm5
0000710e9ebd3b23  vmovaps [rsp+0x60], xmm6
0000710e9ebd3b29  vmovaps [rsp+0x70], xmm7
0000710e9ebd3b2f  vmovaps [rsp+0x80], xmm8
0000710e9ebd3b38  vmovaps [rsp+0x90], xmm9
0000710e9ebd3b41  vmovaps [rsp+0xA0], xmm10
0000710e9ebd3b4a  vmovaps [rsp+0xB0], xmm11
0000710e9ebd3b53  vmovaps [rsp+0xC0], xmm12
0000710e9ebd3b5c  vmovaps [rsp+0xD0], xmm13
0000710e9ebd3b65  vmovaps [rsp+0xE0], xmm14
0000710e9ebd3b6e  sub rsp, 0x30
0000710e9ebd3b72  movaps [rsp], xmm15
0000710e9ebd3b77  movaps [rsp+0x10], xmm12
0000710e9ebd3b7d  movaps [rsp+0x20], xmm13
0000710e9ebd3b83  lea rdi, [rsp]
0000710e9ebd3b87  mov esi, 0x00
0000710e9ebd3b8c  mov rax, 0x5DADAF7CF530
0000710e9ebd3b96  call rax
0000710e9ebd3b98  movaps xmm15, [rsp]
0000710e9ebd3b9d  add rsp, 0x30
0000710e9ebd3ba1  vmovaps xmm0, [rsp]
0000710e9ebd3ba6  vmovaps xmm1, [rsp+0x10]
0000710e9ebd3bac  vmovaps xmm2, [rsp+0x20]
0000710e9ebd3bb2  vmovaps xmm3, [rsp+0x30]
0000710e9ebd3bb8  vmovaps xmm4, [rsp+0x40]
0000710e9ebd3bbe  vmovaps xmm5, [rsp+0x50]
0000710e9ebd3bc4  vmovaps xmm6, [rsp+0x60]
0000710e9ebd3bca  vmovaps xmm7, [rsp+0x70]
0000710e9ebd3bd0  vmovaps xmm8, [rsp+0x80]
0000710e9ebd3bd9  vmovaps xmm9, [rsp+0x90]
0000710e9ebd3be2  vmovaps xmm10, [rsp+0xA0]
0000710e9ebd3beb  vmovaps xmm11, [rsp+0xB0]
0000710e9ebd3bf4  vmovaps xmm12, [rsp+0xC0]
0000710e9ebd3bfd  vmovaps xmm13, [rsp+0xD0]
0000710e9ebd3c06  vmovaps xmm14, [rsp+0xE0]
0000710e9ebd3c0f  add rsp, 0xF0
0000710e9ebd3c16  pop r11
0000710e9ebd3c18  pop r10
0000710e9ebd3c1a  pop r9
0000710e9ebd3c1c  pop r8
0000710e9ebd3c1e  pop rsi
0000710e9ebd3c1f  pop rdi
0000710e9ebd3c20  pop rdx
0000710e9ebd3c21  pop rcx
0000710e9ebd3c22  pop rax
0000710e9ebd3c23  add rsp, 0x08
0000710e9ebd3c27  jmp 0x0000710E9EBD2835
0000710e9ebd3c2c  sub rsp, 0x08
0000710e9ebd3c30  push rax
0000710e9ebd3c31  push rcx
0000710e9ebd3c32  push rdx
0000710e9ebd3c33  push rdi
0000710e9ebd3c34  push rsi
0000710e9ebd3c35  push r8
0000710e9ebd3c37  push r9
0000710e9ebd3c39  push r10
0000710e9ebd3c3b  push r11
0000710e9ebd3c3d  sub rsp, 0xF0
0000710e9ebd3c44  vmovaps [rsp], xmm0
0000710e9ebd3c49  vmovaps [rsp+0x10], xmm2
0000710e9ebd3c4f  vmovaps [rsp+0x20], xmm3
0000710e9ebd3c55  vmovaps [rsp+0x30], xmm4
0000710e9ebd3c5b  vmovaps [rsp+0x40], xmm5
0000710e9ebd3c61  vmovaps [rsp+0x50], xmm6
0000710e9ebd3c67  vmovaps [rsp+0x60], xmm7
0000710e9ebd3c6d  vmovaps [rsp+0x70], xmm8
0000710e9ebd3c73  vmovaps [rsp+0x80], xmm9
0000710e9ebd3c7c  vmovaps [rsp+0x90], xmm10
0000710e9ebd3c85  vmovaps [rsp+0xA0], xmm11
0000710e9ebd3c8e  vmovaps [rsp+0xB0], xmm12
0000710e9ebd3c97  vmovaps [rsp+0xC0], xmm13
0000710e9ebd3ca0  vmovaps [rsp+0xD0], xmm14
0000710e9ebd3ca9  vmovaps [rsp+0xE0], xmm15
0000710e9ebd3cb2  sub rsp, 0x30
0000710e9ebd3cb6  movaps [rsp], xmm1
0000710e9ebd3cba  movaps [rsp+0x10], xmm12
0000710e9ebd3cc0  movaps [rsp+0x20], xmm10
0000710e9ebd3cc6  lea rdi, [rsp]
0000710e9ebd3cca  mov esi, 0x00
0000710e9ebd3ccf  mov rax, 0x5DADAF7CF530
0000710e9ebd3cd9  call rax
0000710e9ebd3cdb  movaps xmm1, [rsp]
0000710e9ebd3cdf  add rsp, 0x30
0000710e9ebd3ce3  vmovaps xmm0, [rsp]
0000710e9ebd3ce8  vmovaps xmm2, [rsp+0x10]
0000710e9ebd3cee  vmovaps xmm3, [rsp+0x20]
0000710e9ebd3cf4  vmovaps xmm4, [rsp+0x30]
0000710e9ebd3cfa  vmovaps xmm5, [rsp+0x40]
0000710e9ebd3d00  vmovaps xmm6, [rsp+0x50]
0000710e9ebd3d06  vmovaps xmm7, [rsp+0x60]
0000710e9ebd3d0c  vmovaps xmm8, [rsp+0x70]
0000710e9ebd3d12  vmovaps xmm9, [rsp+0x80]
0000710e9ebd3d1b  vmovaps xmm10, [rsp+0x90]
0000710e9ebd3d24  vmovaps xmm11, [rsp+0xA0]
0000710e9ebd3d2d  vmovaps xmm12, [rsp+0xB0]
0000710e9ebd3d36  vmovaps xmm13, [rsp+0xC0]
0000710e9ebd3d3f  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd3d48  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd3d51  add rsp, 0xF0
0000710e9ebd3d58  pop r11
0000710e9ebd3d5a  pop r10
0000710e9ebd3d5c  pop r9
0000710e9ebd3d5e  pop r8
0000710e9ebd3d60  pop rsi
0000710e9ebd3d61  pop rdi
0000710e9ebd3d62  pop rdx
0000710e9ebd3d63  pop rcx
0000710e9ebd3d64  pop rax
0000710e9ebd3d65  add rsp, 0x08
0000710e9ebd3d69  jmp 0x0000710E9EBD284F
0000710e9ebd3d6e  sub rsp, 0x08
0000710e9ebd3d72  push rax
0000710e9ebd3d73  push rcx
0000710e9ebd3d74  push rdx
0000710e9ebd3d75  push rdi
0000710e9ebd3d76  push rsi
0000710e9ebd3d77  push r8
0000710e9ebd3d79  push r9
0000710e9ebd3d7b  push r10
0000710e9ebd3d7d  push r11
0000710e9ebd3d7f  sub rsp, 0xF0
0000710e9ebd3d86  vmovaps [rsp], xmm0
0000710e9ebd3d8b  vmovaps [rsp+0x10], xmm1
0000710e9ebd3d91  vmovaps [rsp+0x20], xmm2
0000710e9ebd3d97  vmovaps [rsp+0x30], xmm3
0000710e9ebd3d9d  vmovaps [rsp+0x40], xmm4
0000710e9ebd3da3  vmovaps [rsp+0x50], xmm5
0000710e9ebd3da9  vmovaps [rsp+0x60], xmm6
0000710e9ebd3daf  vmovaps [rsp+0x70], xmm7
0000710e9ebd3db5  vmovaps [rsp+0x80], xmm8
0000710e9ebd3dbe  vmovaps [rsp+0x90], xmm9
0000710e9ebd3dc7  vmovaps [rsp+0xA0], xmm10
0000710e9ebd3dd0  vmovaps [rsp+0xB0], xmm11
0000710e9ebd3dd9  vmovaps [rsp+0xC0], xmm12
0000710e9ebd3de2  vmovaps [rsp+0xD0], xmm14
0000710e9ebd3deb  vmovaps [rsp+0xE0], xmm15
0000710e9ebd3df4  sub rsp, 0x30
0000710e9ebd3df8  movaps [rsp], xmm13
0000710e9ebd3dfd  movaps [rsp+0x10], xmm12
0000710e9ebd3e03  movaps [rsp+0x20], xmm2
0000710e9ebd3e08  lea rdi, [rsp]
0000710e9ebd3e0c  mov esi, 0x00
0000710e9ebd3e11  mov rax, 0x5DADAF7CF530
0000710e9ebd3e1b  call rax
0000710e9ebd3e1d  movaps xmm13, [rsp]
0000710e9ebd3e22  add rsp, 0x30
0000710e9ebd3e26  vmovaps xmm0, [rsp]
0000710e9ebd3e2b  vmovaps xmm1, [rsp+0x10]
0000710e9ebd3e31  vmovaps xmm2, [rsp+0x20]
0000710e9ebd3e37  vmovaps xmm3, [rsp+0x30]
0000710e9ebd3e3d  vmovaps xmm4, [rsp+0x40]
0000710e9ebd3e43  vmovaps xmm5, [rsp+0x50]
0000710e9ebd3e49  vmovaps xmm6, [rsp+0x60]
0000710e9ebd3e4f  vmovaps xmm7, [rsp+0x70]
0000710e9ebd3e55  vmovaps xmm8, [rsp+0x80]
0000710e9ebd3e5e  vmovaps xmm9, [rsp+0x90]
0000710e9ebd3e67  vmovaps xmm10, [rsp+0xA0]
0000710e9ebd3e70  vmovaps xmm11, [rsp+0xB0]
0000710e9ebd3e79  vmovaps xmm12, [rsp+0xC0]
0000710e9ebd3e82  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd3e8b  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd3e94  add rsp, 0xF0
0000710e9ebd3e9b  pop r11
0000710e9ebd3e9d  pop r10
0000710e9ebd3e9f  pop r9
0000710e9ebd3ea1  pop r8
0000710e9ebd3ea3  pop rsi
0000710e9ebd3ea4  pop rdi
0000710e9ebd3ea5  pop rdx
0000710e9ebd3ea6  pop rcx
0000710e9ebd3ea7  pop rax
0000710e9ebd3ea8  add rsp, 0x08
0000710e9ebd3eac  jmp 0x0000710E9EBD286A
0000710e9ebd3eb1  sub rsp, 0x08
0000710e9ebd3eb5  push rax
0000710e9ebd3eb6  push rcx
0000710e9ebd3eb7  push rdx
0000710e9ebd3eb8  push rdi
0000710e9ebd3eb9  push rsi
0000710e9ebd3eba  push r8
0000710e9ebd3ebc  push r9
0000710e9ebd3ebe  push r10
0000710e9ebd3ec0  push r11
0000710e9ebd3ec2  sub rsp, 0xF0
0000710e9ebd3ec9  vmovaps [rsp], xmm0
0000710e9ebd3ece  vmovaps [rsp+0x10], xmm2
0000710e9ebd3ed4  vmovaps [rsp+0x20], xmm3
0000710e9ebd3eda  vmovaps [rsp+0x30], xmm4
0000710e9ebd3ee0  vmovaps [rsp+0x40], xmm5
0000710e9ebd3ee6  vmovaps [rsp+0x50], xmm6
0000710e9ebd3eec  vmovaps [rsp+0x60], xmm7
0000710e9ebd3ef2  vmovaps [rsp+0x70], xmm8
0000710e9ebd3ef8  vmovaps [rsp+0x80], xmm9
0000710e9ebd3f01  vmovaps [rsp+0x90], xmm10
0000710e9ebd3f0a  vmovaps [rsp+0xA0], xmm11
0000710e9ebd3f13  vmovaps [rsp+0xB0], xmm12
0000710e9ebd3f1c  vmovaps [rsp+0xC0], xmm13
0000710e9ebd3f25  vmovaps [rsp+0xD0], xmm14
0000710e9ebd3f2e  vmovaps [rsp+0xE0], xmm15
0000710e9ebd3f37  sub rsp, 0x30
0000710e9ebd3f3b  movaps [rsp], xmm1
0000710e9ebd3f3f  movaps [rsp+0x10], xmm10
0000710e9ebd3f45  movaps [rsp+0x20], xmm2
0000710e9ebd3f4a  lea rdi, [rsp]
0000710e9ebd3f4e  mov esi, 0x00
0000710e9ebd3f53  mov rax, 0x5DADAF7CF530
0000710e9ebd3f5d  call rax
0000710e9ebd3f5f  movaps xmm1, [rsp]
0000710e9ebd3f63  add rsp, 0x30
0000710e9ebd3f67  vmovaps xmm0, [rsp]
0000710e9ebd3f6c  vmovaps xmm2, [rsp+0x10]
0000710e9ebd3f72  vmovaps xmm3, [rsp+0x20]
0000710e9ebd3f78  vmovaps xmm4, [rsp+0x30]
0000710e9ebd3f7e  vmovaps xmm5, [rsp+0x40]
0000710e9ebd3f84  vmovaps xmm6, [rsp+0x50]
0000710e9ebd3f8a  vmovaps xmm7, [rsp+0x60]
0000710e9ebd3f90  vmovaps xmm8, [rsp+0x70]
0000710e9ebd3f96  vmovaps xmm9, [rsp+0x80]
0000710e9ebd3f9f  vmovaps xmm10, [rsp+0x90]
0000710e9ebd3fa8  vmovaps xmm11, [rsp+0xA0]
0000710e9ebd3fb1  vmovaps xmm12, [rsp+0xB0]
0000710e9ebd3fba  vmovaps xmm13, [rsp+0xC0]
0000710e9ebd3fc3  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd3fcc  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd3fd5  add rsp, 0xF0
0000710e9ebd3fdc  pop r11
0000710e9ebd3fde  pop r10
0000710e9ebd3fe0  pop r9
0000710e9ebd3fe2  pop r8
0000710e9ebd3fe4  pop rsi
0000710e9ebd3fe5  pop rdi
0000710e9ebd3fe6  pop rdx
0000710e9ebd3fe7  pop rcx
0000710e9ebd3fe8  pop rax
0000710e9ebd3fe9  add rsp, 0x08
0000710e9ebd3fed  jmp 0x0000710E9EBD28D2
0000710e9ebd3ff2  sub rsp, 0x08
0000710e9ebd3ff6  push rax
0000710e9ebd3ff7  push rcx
0000710e9ebd3ff8  push rdx
0000710e9ebd3ff9  push rdi
0000710e9ebd3ffa  push rsi
0000710e9ebd3ffb  push r8
0000710e9ebd3ffd  push r9
0000710e9ebd3fff  push r10
0000710e9ebd4001  push r11
0000710e9ebd4003  sub rsp, 0xF0
0000710e9ebd400a  vmovaps [rsp], xmm0
0000710e9ebd400f  vmovaps [rsp+0x10], xmm1
0000710e9ebd4015  vmovaps [rsp+0x20], xmm2
0000710e9ebd401b  vmovaps [rsp+0x30], xmm3
0000710e9ebd4021  vmovaps [rsp+0x40], xmm4
0000710e9ebd4027  vmovaps [rsp+0x50], xmm5
0000710e9ebd402d  vmovaps [rsp+0x60], xmm6
0000710e9ebd4033  vmovaps [rsp+0x70], xmm7
0000710e9ebd4039  vmovaps [rsp+0x80], xmm8
0000710e9ebd4042  vmovaps [rsp+0x90], xmm9
0000710e9ebd404b  vmovaps [rsp+0xA0], xmm10
0000710e9ebd4054  vmovaps [rsp+0xB0], xmm11
0000710e9ebd405d  vmovaps [rsp+0xC0], xmm12
0000710e9ebd4066  vmovaps [rsp+0xD0], xmm13
0000710e9ebd406f  vmovaps [rsp+0xE0], xmm14
0000710e9ebd4078  sub rsp, 0x30
0000710e9ebd407c  movaps [rsp], xmm15
0000710e9ebd4081  movaps [rsp+0x10], xmm10
0000710e9ebd4087  movaps [rsp+0x20], xmm2
0000710e9ebd408c  lea rdi, [rsp]
0000710e9ebd4090  mov esi, 0x00
0000710e9ebd4095  mov rax, 0x5DADAF7CF530
0000710e9ebd409f  call rax
0000710e9ebd40a1  movaps xmm15, [rsp]
0000710e9ebd40a6  add rsp, 0x30
0000710e9ebd40aa  vmovaps xmm0, [rsp]
0000710e9ebd40af  vmovaps xmm1, [rsp+0x10]
0000710e9ebd40b5  vmovaps xmm2, [rsp+0x20]
0000710e9ebd40bb  vmovaps xmm3, [rsp+0x30]
0000710e9ebd40c1  vmovaps xmm4, [rsp+0x40]
0000710e9ebd40c7  vmovaps xmm5, [rsp+0x50]
0000710e9ebd40cd  vmovaps xmm6, [rsp+0x60]
0000710e9ebd40d3  vmovaps xmm7, [rsp+0x70]
0000710e9ebd40d9  vmovaps xmm8, [rsp+0x80]
0000710e9ebd40e2  vmovaps xmm9, [rsp+0x90]
0000710e9ebd40eb  vmovaps xmm10, [rsp+0xA0]
0000710e9ebd40f4  vmovaps xmm11, [rsp+0xB0]
0000710e9ebd40fd  vmovaps xmm12, [rsp+0xC0]
0000710e9ebd4106  vmovaps xmm13, [rsp+0xD0]
0000710e9ebd410f  vmovaps xmm14, [rsp+0xE0]
0000710e9ebd4118  add rsp, 0xF0
0000710e9ebd411f  pop r11
0000710e9ebd4121  pop r10
0000710e9ebd4123  pop r9
0000710e9ebd4125  pop r8
0000710e9ebd4127  pop rsi
0000710e9ebd4128  pop rdi
0000710e9ebd4129  pop rdx
0000710e9ebd412a  pop rcx
0000710e9ebd412b  pop rax
0000710e9ebd412c  add rsp, 0x08
0000710e9ebd4130  jmp 0x0000710E9EBD2924
0000710e9ebd4135  sub rsp, 0x08
0000710e9ebd4139  push rax
0000710e9ebd413a  push rcx
0000710e9ebd413b  push rdx
0000710e9ebd413c  push rdi
0000710e9ebd413d  push rsi
0000710e9ebd413e  push r8
0000710e9ebd4140  push r9
0000710e9ebd4142  push r10
0000710e9ebd4144  push r11
0000710e9ebd4146  sub rsp, 0xF0
0000710e9ebd414d  vmovaps [rsp], xmm0
0000710e9ebd4152  vmovaps [rsp+0x10], xmm2
0000710e9ebd4158  vmovaps [rsp+0x20], xmm3
0000710e9ebd415e  vmovaps [rsp+0x30], xmm4
0000710e9ebd4164  vmovaps [rsp+0x40], xmm5
0000710e9ebd416a  vmovaps [rsp+0x50], xmm6
0000710e9ebd4170  vmovaps [rsp+0x60], xmm7
0000710e9ebd4176  vmovaps [rsp+0x70], xmm8
0000710e9ebd417c  vmovaps [rsp+0x80], xmm9
0000710e9ebd4185  vmovaps [rsp+0x90], xmm10
0000710e9ebd418e  vmovaps [rsp+0xA0], xmm11
0000710e9ebd4197  vmovaps [rsp+0xB0], xmm12
0000710e9ebd41a0  vmovaps [rsp+0xC0], xmm13
0000710e9ebd41a9  vmovaps [rsp+0xD0], xmm14
0000710e9ebd41b2  vmovaps [rsp+0xE0], xmm15
0000710e9ebd41bb  sub rsp, 0x30
0000710e9ebd41bf  movaps [rsp], xmm1
0000710e9ebd41c3  movaps [rsp+0x10], xmm10
0000710e9ebd41c9  movaps [rsp+0x20], xmm15
0000710e9ebd41cf  lea rdi, [rsp]
0000710e9ebd41d3  mov esi, 0x00
0000710e9ebd41d8  mov rax, 0x5DADAF7CF530
0000710e9ebd41e2  call rax
0000710e9ebd41e4  movaps xmm1, [rsp]
0000710e9ebd41e8  add rsp, 0x30
0000710e9ebd41ec  vmovaps xmm0, [rsp]
0000710e9ebd41f1  vmovaps xmm2, [rsp+0x10]
0000710e9ebd41f7  vmovaps xmm3, [rsp+0x20]
0000710e9ebd41fd  vmovaps xmm4, [rsp+0x30]
0000710e9ebd4203  vmovaps xmm5, [rsp+0x40]
0000710e9ebd4209  vmovaps xmm6, [rsp+0x50]
0000710e9ebd420f  vmovaps xmm7, [rsp+0x60]
0000710e9ebd4215  vmovaps xmm8, [rsp+0x70]
0000710e9ebd421b  vmovaps xmm9, [rsp+0x80]
0000710e9ebd4224  vmovaps xmm10, [rsp+0x90]
0000710e9ebd422d  vmovaps xmm11, [rsp+0xA0]
0000710e9ebd4236  vmovaps xmm12, [rsp+0xB0]
0000710e9ebd423f  vmovaps xmm13, [rsp+0xC0]
0000710e9ebd4248  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd4251  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd425a  add rsp, 0xF0
0000710e9ebd4261  pop r11
0000710e9ebd4263  pop r10
0000710e9ebd4265  pop r9
0000710e9ebd4267  pop r8
0000710e9ebd4269  pop rsi
0000710e9ebd426a  pop rdi
0000710e9ebd426b  pop rdx
0000710e9ebd426c  pop rcx
0000710e9ebd426d  pop rax
0000710e9ebd426e  add rsp, 0x08
0000710e9ebd4272  jmp 0x0000710E9EBD2962
0000710e9ebd4277  sub rsp, 0x08
0000710e9ebd427b  push rax
0000710e9ebd427c  push rcx
0000710e9ebd427d  push rdx
0000710e9ebd427e  push rdi
0000710e9ebd427f  push rsi
0000710e9ebd4280  push r8
0000710e9ebd4282  push r9
0000710e9ebd4284  push r10
0000710e9ebd4286  push r11
0000710e9ebd4288  sub rsp, 0xF0
0000710e9ebd428f  vmovaps [rsp], xmm0
0000710e9ebd4294  vmovaps [rsp+0x10], xmm1
0000710e9ebd429a  vmovaps [rsp+0x20], xmm2
0000710e9ebd42a0  vmovaps [rsp+0x30], xmm3
0000710e9ebd42a6  vmovaps [rsp+0x40], xmm4
0000710e9ebd42ac  vmovaps [rsp+0x50], xmm5
0000710e9ebd42b2  vmovaps [rsp+0x60], xmm6
0000710e9ebd42b8  vmovaps [rsp+0x70], xmm7
0000710e9ebd42be  vmovaps [rsp+0x80], xmm8
0000710e9ebd42c7  vmovaps [rsp+0x90], xmm9
0000710e9ebd42d0  vmovaps [rsp+0xA0], xmm10
0000710e9ebd42d9  vmovaps [rsp+0xB0], xmm11
0000710e9ebd42e2  vmovaps [rsp+0xC0], xmm12
0000710e9ebd42eb  vmovaps [rsp+0xD0], xmm13
0000710e9ebd42f4  vmovaps [rsp+0xE0], xmm15
0000710e9ebd42fd  sub rsp, 0x30
0000710e9ebd4301  movaps [rsp], xmm14
0000710e9ebd4306  movaps [rsp+0x10], xmm10
0000710e9ebd430c  movaps [rsp+0x20], xmm15
0000710e9ebd4312  lea rdi, [rsp]
0000710e9ebd4316  mov esi, 0x00
0000710e9ebd431b  mov rax, 0x5DADAF7CF530
0000710e9ebd4325  call rax
0000710e9ebd4327  movaps xmm14, [rsp]
0000710e9ebd432c  add rsp, 0x30
0000710e9ebd4330  vmovaps xmm0, [rsp]
0000710e9ebd4335  vmovaps xmm1, [rsp+0x10]
0000710e9ebd433b  vmovaps xmm2, [rsp+0x20]
0000710e9ebd4341  vmovaps xmm3, [rsp+0x30]
0000710e9ebd4347  vmovaps xmm4, [rsp+0x40]
0000710e9ebd434d  vmovaps xmm5, [rsp+0x50]
0000710e9ebd4353  vmovaps xmm6, [rsp+0x60]
0000710e9ebd4359  vmovaps xmm7, [rsp+0x70]
0000710e9ebd435f  vmovaps xmm8, [rsp+0x80]
0000710e9ebd4368  vmovaps xmm9, [rsp+0x90]
0000710e9ebd4371  vmovaps xmm10, [rsp+0xA0]
0000710e9ebd437a  vmovaps xmm11, [rsp+0xB0]
0000710e9ebd4383  vmovaps xmm12, [rsp+0xC0]
0000710e9ebd438c  vmovaps xmm13, [rsp+0xD0]
0000710e9ebd4395  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd439e  add rsp, 0xF0
0000710e9ebd43a5  pop r11
0000710e9ebd43a7  pop r10
0000710e9ebd43a9  pop r9
0000710e9ebd43ab  pop r8
0000710e9ebd43ad  pop rsi
0000710e9ebd43ae  pop rdi
0000710e9ebd43af  pop rdx
0000710e9ebd43b0  pop rcx
0000710e9ebd43b1  pop rax
0000710e9ebd43b2  add rsp, 0x08
0000710e9ebd43b6  jmp 0x0000710E9EBD298E
0000710e9ebd43bb  call 0x0000710E9E9FF430
0000710e9ebd43c0  jmp 0x0000710E9EBD2A1E
0000710e9ebd43c5  call 0x0000710E9E9FF430
0000710e9ebd43ca  jmp 0x0000710E9EBD2A31
0000710e9ebd43cf  sub rsp, 0x08
0000710e9ebd43d3  push rax
0000710e9ebd43d4  push rcx
0000710e9ebd43d5  push rdx
0000710e9ebd43d6  push rdi
0000710e9ebd43d7  push rsi
0000710e9ebd43d8  push r8
0000710e9ebd43da  push r9
0000710e9ebd43dc  push r10
0000710e9ebd43de  push r11
0000710e9ebd43e0  sub rsp, 0xF0
0000710e9ebd43e7  vmovaps [rsp], xmm0
0000710e9ebd43ec  vmovaps [rsp+0x10], xmm2
0000710e9ebd43f2  vmovaps [rsp+0x20], xmm3
0000710e9ebd43f8  vmovaps [rsp+0x30], xmm4
0000710e9ebd43fe  vmovaps [rsp+0x40], xmm5
0000710e9ebd4404  vmovaps [rsp+0x50], xmm6
0000710e9ebd440a  vmovaps [rsp+0x60], xmm7
0000710e9ebd4410  vmovaps [rsp+0x70], xmm8
0000710e9ebd4416  vmovaps [rsp+0x80], xmm9
0000710e9ebd441f  vmovaps [rsp+0x90], xmm10
0000710e9ebd4428  vmovaps [rsp+0xA0], xmm11
0000710e9ebd4431  vmovaps [rsp+0xB0], xmm12
0000710e9ebd443a  vmovaps [rsp+0xC0], xmm13
0000710e9ebd4443  vmovaps [rsp+0xD0], xmm14
0000710e9ebd444c  vmovaps [rsp+0xE0], xmm15
0000710e9ebd4455  sub rsp, 0x30
0000710e9ebd4459  movaps [rsp], xmm1
0000710e9ebd445d  movaps [rsp+0x10], xmm13
0000710e9ebd4463  movaps [rsp+0x20], xmm2
0000710e9ebd4468  lea rdi, [rsp]
0000710e9ebd446c  mov esi, 0x00
0000710e9ebd4471  mov rax, 0x5DADAF7CF530
0000710e9ebd447b  call rax
0000710e9ebd447d  movaps xmm1, [rsp]
0000710e9ebd4481  add rsp, 0x30
0000710e9ebd4485  vmovaps xmm0, [rsp]
0000710e9ebd448a  vmovaps xmm2, [rsp+0x10]
0000710e9ebd4490  vmovaps xmm3, [rsp+0x20]
0000710e9ebd4496  vmovaps xmm4, [rsp+0x30]
0000710e9ebd449c  vmovaps xmm5, [rsp+0x40]
0000710e9ebd44a2  vmovaps xmm6, [rsp+0x50]
0000710e9ebd44a8  vmovaps xmm7, [rsp+0x60]
0000710e9ebd44ae  vmovaps xmm8, [rsp+0x70]
0000710e9ebd44b4  vmovaps xmm9, [rsp+0x80]
0000710e9ebd44bd  vmovaps xmm10, [rsp+0x90]
0000710e9ebd44c6  vmovaps xmm11, [rsp+0xA0]
0000710e9ebd44cf  vmovaps xmm12, [rsp+0xB0]
0000710e9ebd44d8  vmovaps xmm13, [rsp+0xC0]
0000710e9ebd44e1  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd44ea  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd44f3  add rsp, 0xF0
0000710e9ebd44fa  pop r11
0000710e9ebd44fc  pop r10
0000710e9ebd44fe  pop r9
0000710e9ebd4500  pop r8
0000710e9ebd4502  pop rsi
0000710e9ebd4503  pop rdi
0000710e9ebd4504  pop rdx
0000710e9ebd4505  pop rcx
0000710e9ebd4506  pop rax
0000710e9ebd4507  add rsp, 0x08
0000710e9ebd450b  jmp 0x0000710E9EBD2A5C
0000710e9ebd4510  call 0x0000710E9EA0E760
0000710e9ebd4515  jmp 0x0000710E9EBD2A69
0000710e9ebd451a  sub rsp, 0x08
0000710e9ebd451e  push rax
0000710e9ebd451f  push rcx
0000710e9ebd4520  push rdx
0000710e9ebd4521  push rdi
0000710e9ebd4522  push rsi
0000710e9ebd4523  push r8
0000710e9ebd4525  push r9
0000710e9ebd4527  push r10
0000710e9ebd4529  push r11
0000710e9ebd452b  sub rsp, 0xF0
0000710e9ebd4532  vmovaps [rsp], xmm0
0000710e9ebd4537  vmovaps [rsp+0x10], xmm1
0000710e9ebd453d  vmovaps [rsp+0x20], xmm2
0000710e9ebd4543  vmovaps [rsp+0x30], xmm3
0000710e9ebd4549  vmovaps [rsp+0x40], xmm4
0000710e9ebd454f  vmovaps [rsp+0x50], xmm5
0000710e9ebd4555  vmovaps [rsp+0x60], xmm6
0000710e9ebd455b  vmovaps [rsp+0x70], xmm7
0000710e9ebd4561  vmovaps [rsp+0x80], xmm8
0000710e9ebd456a  vmovaps [rsp+0x90], xmm9
0000710e9ebd4573  vmovaps [rsp+0xA0], xmm10
0000710e9ebd457c  vmovaps [rsp+0xB0], xmm11
0000710e9ebd4585  vmovaps [rsp+0xC0], xmm12
0000710e9ebd458e  vmovaps [rsp+0xD0], xmm14
0000710e9ebd4597  vmovaps [rsp+0xE0], xmm15
0000710e9ebd45a0  sub rsp, 0x30
0000710e9ebd45a4  movaps [rsp], xmm13
0000710e9ebd45a9  movaps [rsp+0x10], xmm2
0000710e9ebd45ae  movaps [rsp+0x20], xmm1
0000710e9ebd45b3  lea rdi, [rsp]
0000710e9ebd45b7  mov esi, 0x00
0000710e9ebd45bc  mov rax, 0x5DADAF7CF530
0000710e9ebd45c6  call rax
0000710e9ebd45c8  movaps xmm13, [rsp]
0000710e9ebd45cd  add rsp, 0x30
0000710e9ebd45d1  vmovaps xmm0, [rsp]
0000710e9ebd45d6  vmovaps xmm1, [rsp+0x10]
0000710e9ebd45dc  vmovaps xmm2, [rsp+0x20]
0000710e9ebd45e2  vmovaps xmm3, [rsp+0x30]
0000710e9ebd45e8  vmovaps xmm4, [rsp+0x40]
0000710e9ebd45ee  vmovaps xmm5, [rsp+0x50]
0000710e9ebd45f4  vmovaps xmm6, [rsp+0x60]
0000710e9ebd45fa  vmovaps xmm7, [rsp+0x70]
0000710e9ebd4600  vmovaps xmm8, [rsp+0x80]
0000710e9ebd4609  vmovaps xmm9, [rsp+0x90]
0000710e9ebd4612  vmovaps xmm10, [rsp+0xA0]
0000710e9ebd461b  vmovaps xmm11, [rsp+0xB0]
0000710e9ebd4624  vmovaps xmm12, [rsp+0xC0]
0000710e9ebd462d  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd4636  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd463f  add rsp, 0xF0
0000710e9ebd4646  pop r11
0000710e9ebd4648  pop r10
0000710e9ebd464a  pop r9
0000710e9ebd464c  pop r8
0000710e9ebd464e  pop rsi
0000710e9ebd464f  pop rdi
0000710e9ebd4650  pop rdx
0000710e9ebd4651  pop rcx
0000710e9ebd4652  pop rax
0000710e9ebd4653  add rsp, 0x08
0000710e9ebd4657  jmp 0x0000710E9EBD2AA8
0000710e9ebd465c  sub rsp, 0x08
0000710e9ebd4660  push rax
0000710e9ebd4661  push rcx
0000710e9ebd4662  push rdx
0000710e9ebd4663  push rdi
0000710e9ebd4664  push rsi
0000710e9ebd4665  push r8
0000710e9ebd4667  push r9
0000710e9ebd4669  push r10
0000710e9ebd466b  push r11
0000710e9ebd466d  sub rsp, 0xF0
0000710e9ebd4674  vmovaps [rsp], xmm0
0000710e9ebd4679  vmovaps [rsp+0x10], xmm2
0000710e9ebd467f  vmovaps [rsp+0x20], xmm3
0000710e9ebd4685  vmovaps [rsp+0x30], xmm4
0000710e9ebd468b  vmovaps [rsp+0x40], xmm5
0000710e9ebd4691  vmovaps [rsp+0x50], xmm6
0000710e9ebd4697  vmovaps [rsp+0x60], xmm7
0000710e9ebd469d  vmovaps [rsp+0x70], xmm8
0000710e9ebd46a3  vmovaps [rsp+0x80], xmm9
0000710e9ebd46ac  vmovaps [rsp+0x90], xmm10
0000710e9ebd46b5  vmovaps [rsp+0xA0], xmm11
0000710e9ebd46be  vmovaps [rsp+0xB0], xmm12
0000710e9ebd46c7  vmovaps [rsp+0xC0], xmm13
0000710e9ebd46d0  vmovaps [rsp+0xD0], xmm14
0000710e9ebd46d9  vmovaps [rsp+0xE0], xmm15
0000710e9ebd46e2  sub rsp, 0x30
0000710e9ebd46e6  movaps [rsp], xmm1
0000710e9ebd46ea  movaps [rsp+0x10], xmm14
0000710e9ebd46f0  movaps [rsp+0x20], xmm15
0000710e9ebd46f6  lea rdi, [rsp]
0000710e9ebd46fa  mov esi, 0x00
0000710e9ebd46ff  mov rax, 0x5DADAF7CF530
0000710e9ebd4709  call rax
0000710e9ebd470b  movaps xmm1, [rsp]
0000710e9ebd470f  add rsp, 0x30
0000710e9ebd4713  vmovaps xmm0, [rsp]
0000710e9ebd4718  vmovaps xmm2, [rsp+0x10]
0000710e9ebd471e  vmovaps xmm3, [rsp+0x20]
0000710e9ebd4724  vmovaps xmm4, [rsp+0x30]
0000710e9ebd472a  vmovaps xmm5, [rsp+0x40]
0000710e9ebd4730  vmovaps xmm6, [rsp+0x50]
0000710e9ebd4736  vmovaps xmm7, [rsp+0x60]
0000710e9ebd473c  vmovaps xmm8, [rsp+0x70]
0000710e9ebd4742  vmovaps xmm9, [rsp+0x80]
0000710e9ebd474b  vmovaps xmm10, [rsp+0x90]
0000710e9ebd4754  vmovaps xmm11, [rsp+0xA0]
0000710e9ebd475d  vmovaps xmm12, [rsp+0xB0]
0000710e9ebd4766  vmovaps xmm13, [rsp+0xC0]
0000710e9ebd476f  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd4778  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd4781  add rsp, 0xF0
0000710e9ebd4788  pop r11
0000710e9ebd478a  pop r10
0000710e9ebd478c  pop r9
0000710e9ebd478e  pop r8
0000710e9ebd4790  pop rsi
0000710e9ebd4791  pop rdi
0000710e9ebd4792  pop rdx
0000710e9ebd4793  pop rcx
0000710e9ebd4794  pop rax
0000710e9ebd4795  add rsp, 0x08
0000710e9ebd4799  jmp 0x0000710E9EBD2ACA
0000710e9ebd479e  sub rsp, 0x08
0000710e9ebd47a2  push rax
0000710e9ebd47a3  push rcx
0000710e9ebd47a4  push rdx
0000710e9ebd47a5  push rdi
0000710e9ebd47a6  push rsi
0000710e9ebd47a7  push r8
0000710e9ebd47a9  push r9
0000710e9ebd47ab  push r10
0000710e9ebd47ad  push r11
0000710e9ebd47af  sub rsp, 0xF0
0000710e9ebd47b6  vmovaps [rsp], xmm0
0000710e9ebd47bb  vmovaps [rsp+0x10], xmm1
0000710e9ebd47c1  vmovaps [rsp+0x20], xmm2
0000710e9ebd47c7  vmovaps [rsp+0x30], xmm3
0000710e9ebd47cd  vmovaps [rsp+0x40], xmm4
0000710e9ebd47d3  vmovaps [rsp+0x50], xmm5
0000710e9ebd47d9  vmovaps [rsp+0x60], xmm6
0000710e9ebd47df  vmovaps [rsp+0x70], xmm7
0000710e9ebd47e5  vmovaps [rsp+0x80], xmm8
0000710e9ebd47ee  vmovaps [rsp+0x90], xmm9
0000710e9ebd47f7  vmovaps [rsp+0xA0], xmm10
0000710e9ebd4800  vmovaps [rsp+0xB0], xmm11
0000710e9ebd4809  vmovaps [rsp+0xC0], xmm12
0000710e9ebd4812  vmovaps [rsp+0xD0], xmm13
0000710e9ebd481b  vmovaps [rsp+0xE0], xmm15
0000710e9ebd4824  sub rsp, 0x30
0000710e9ebd4828  movaps [rsp], xmm14
0000710e9ebd482d  movaps [rsp+0x10], xmm2
0000710e9ebd4832  movaps [rsp+0x20], xmm15
0000710e9ebd4838  lea rdi, [rsp]
0000710e9ebd483c  mov esi, 0x00
0000710e9ebd4841  mov rax, 0x5DADAF7CF530
0000710e9ebd484b  call rax
0000710e9ebd484d  movaps xmm14, [rsp]
0000710e9ebd4852  add rsp, 0x30
0000710e9ebd4856  vmovaps xmm0, [rsp]
0000710e9ebd485b  vmovaps xmm1, [rsp+0x10]
0000710e9ebd4861  vmovaps xmm2, [rsp+0x20]
0000710e9ebd4867  vmovaps xmm3, [rsp+0x30]
0000710e9ebd486d  vmovaps xmm4, [rsp+0x40]
0000710e9ebd4873  vmovaps xmm5, [rsp+0x50]
0000710e9ebd4879  vmovaps xmm6, [rsp+0x60]
0000710e9ebd487f  vmovaps xmm7, [rsp+0x70]
0000710e9ebd4885  vmovaps xmm8, [rsp+0x80]
0000710e9ebd488e  vmovaps xmm9, [rsp+0x90]
0000710e9ebd4897  vmovaps xmm10, [rsp+0xA0]
0000710e9ebd48a0  vmovaps xmm11, [rsp+0xB0]
0000710e9ebd48a9  vmovaps xmm12, [rsp+0xC0]
0000710e9ebd48b2  vmovaps xmm13, [rsp+0xD0]
0000710e9ebd48bb  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd48c4  add rsp, 0xF0
0000710e9ebd48cb  pop r11
0000710e9ebd48cd  pop r10
0000710e9ebd48cf  pop r9
0000710e9ebd48d1  pop r8
0000710e9ebd48d3  pop rsi
0000710e9ebd48d4  pop rdi
0000710e9ebd48d5  pop rdx
0000710e9ebd48d6  pop rcx
0000710e9ebd48d7  pop rax
0000710e9ebd48d8  add rsp, 0x08
0000710e9ebd48dc  jmp 0x0000710E9EBD2B05
0000710e9ebd48e1  sub rsp, 0x08
0000710e9ebd48e5  push rax
0000710e9ebd48e6  push rcx
0000710e9ebd48e7  push rdx
0000710e9ebd48e8  push rdi
0000710e9ebd48e9  push rsi
0000710e9ebd48ea  push r8
0000710e9ebd48ec  push r9
0000710e9ebd48ee  push r10
0000710e9ebd48f0  push r11
0000710e9ebd48f2  sub rsp, 0xF0
0000710e9ebd48f9  vmovaps [rsp], xmm0
0000710e9ebd48fe  vmovaps [rsp+0x10], xmm1
0000710e9ebd4904  vmovaps [rsp+0x20], xmm2
0000710e9ebd490a  vmovaps [rsp+0x30], xmm3
0000710e9ebd4910  vmovaps [rsp+0x40], xmm4
0000710e9ebd4916  vmovaps [rsp+0x50], xmm5
0000710e9ebd491c  vmovaps [rsp+0x60], xmm6
0000710e9ebd4922  vmovaps [rsp+0x70], xmm7
0000710e9ebd4928  vmovaps [rsp+0x80], xmm8
0000710e9ebd4931  vmovaps [rsp+0x90], xmm9
0000710e9ebd493a  vmovaps [rsp+0xA0], xmm10
0000710e9ebd4943  vmovaps [rsp+0xB0], xmm11
0000710e9ebd494c  vmovaps [rsp+0xC0], xmm12
0000710e9ebd4955  vmovaps [rsp+0xD0], xmm13
0000710e9ebd495e  vmovaps [rsp+0xE0], xmm14
0000710e9ebd4967  sub rsp, 0x30
0000710e9ebd496b  movaps [rsp], xmm15
0000710e9ebd4970  movaps [rsp+0x10], xmm2
0000710e9ebd4975  movaps [rsp+0x20], xmm1
0000710e9ebd497a  lea rdi, [rsp]
0000710e9ebd497e  mov esi, 0x00
0000710e9ebd4983  mov rax, 0x5DADAF7CF530
0000710e9ebd498d  call rax
0000710e9ebd498f  movaps xmm15, [rsp]
0000710e9ebd4994  add rsp, 0x30
0000710e9ebd4998  vmovaps xmm0, [rsp]
0000710e9ebd499d  vmovaps xmm1, [rsp+0x10]
0000710e9ebd49a3  vmovaps xmm2, [rsp+0x20]
0000710e9ebd49a9  vmovaps xmm3, [rsp+0x30]
0000710e9ebd49af  vmovaps xmm4, [rsp+0x40]
0000710e9ebd49b5  vmovaps xmm5, [rsp+0x50]
0000710e9ebd49bb  vmovaps xmm6, [rsp+0x60]
0000710e9ebd49c1  vmovaps xmm7, [rsp+0x70]
0000710e9ebd49c7  vmovaps xmm8, [rsp+0x80]
0000710e9ebd49d0  vmovaps xmm9, [rsp+0x90]
0000710e9ebd49d9  vmovaps xmm10, [rsp+0xA0]
0000710e9ebd49e2  vmovaps xmm11, [rsp+0xB0]
0000710e9ebd49eb  vmovaps xmm12, [rsp+0xC0]
0000710e9ebd49f4  vmovaps xmm13, [rsp+0xD0]
0000710e9ebd49fd  vmovaps xmm14, [rsp+0xE0]
0000710e9ebd4a06  add rsp, 0xF0
0000710e9ebd4a0d  pop r11
0000710e9ebd4a0f  pop r10
0000710e9ebd4a11  pop r9
0000710e9ebd4a13  pop r8
0000710e9ebd4a15  pop rsi
0000710e9ebd4a16  pop rdi
0000710e9ebd4a17  pop rdx
0000710e9ebd4a18  pop rcx
0000710e9ebd4a19  pop rax
0000710e9ebd4a1a  add rsp, 0x08
0000710e9ebd4a1e  jmp 0x0000710E9EBD2B41
0000710e9ebd4a23  call 0x0000710E9E9FF430
0000710e9ebd4a28  jmp 0x0000710E9EBD2B4E
0000710e9ebd4a2d  sub rsp, 0x08
0000710e9ebd4a31  push rax
0000710e9ebd4a32  push rcx
0000710e9ebd4a33  push rdx
0000710e9ebd4a34  push rdi
0000710e9ebd4a35  push rsi
0000710e9ebd4a36  push r8
0000710e9ebd4a38  push r9
0000710e9ebd4a3a  push r10
0000710e9ebd4a3c  push r11
0000710e9ebd4a3e  sub rsp, 0xF0
0000710e9ebd4a45  vmovaps [rsp], xmm0
0000710e9ebd4a4a  vmovaps [rsp+0x10], xmm1
0000710e9ebd4a50  vmovaps [rsp+0x20], xmm3
0000710e9ebd4a56  vmovaps [rsp+0x30], xmm4
0000710e9ebd4a5c  vmovaps [rsp+0x40], xmm5
0000710e9ebd4a62  vmovaps [rsp+0x50], xmm6
0000710e9ebd4a68  vmovaps [rsp+0x60], xmm7
0000710e9ebd4a6e  vmovaps [rsp+0x70], xmm8
0000710e9ebd4a74  vmovaps [rsp+0x80], xmm9
0000710e9ebd4a7d  vmovaps [rsp+0x90], xmm10
0000710e9ebd4a86  vmovaps [rsp+0xA0], xmm11
0000710e9ebd4a8f  vmovaps [rsp+0xB0], xmm12
0000710e9ebd4a98  vmovaps [rsp+0xC0], xmm13
0000710e9ebd4aa1  vmovaps [rsp+0xD0], xmm14
0000710e9ebd4aaa  vmovaps [rsp+0xE0], xmm15
0000710e9ebd4ab3  sub rsp, 0x30
0000710e9ebd4ab7  movaps [rsp], xmm2
0000710e9ebd4abb  movaps [rsp+0x10], xmm1
0000710e9ebd4ac0  movaps [rsp+0x20], xmm14
0000710e9ebd4ac6  lea rdi, [rsp]
0000710e9ebd4aca  mov esi, 0x00
0000710e9ebd4acf  mov rax, 0x5DADAF7CF530
0000710e9ebd4ad9  call rax
0000710e9ebd4adb  movaps xmm2, [rsp]
0000710e9ebd4adf  add rsp, 0x30
0000710e9ebd4ae3  vmovaps xmm0, [rsp]
0000710e9ebd4ae8  vmovaps xmm1, [rsp+0x10]
0000710e9ebd4aee  vmovaps xmm3, [rsp+0x20]
0000710e9ebd4af4  vmovaps xmm4, [rsp+0x30]
0000710e9ebd4afa  vmovaps xmm5, [rsp+0x40]
0000710e9ebd4b00  vmovaps xmm6, [rsp+0x50]
0000710e9ebd4b06  vmovaps xmm7, [rsp+0x60]
0000710e9ebd4b0c  vmovaps xmm8, [rsp+0x70]
0000710e9ebd4b12  vmovaps xmm9, [rsp+0x80]
0000710e9ebd4b1b  vmovaps xmm10, [rsp+0x90]
0000710e9ebd4b24  vmovaps xmm11, [rsp+0xA0]
0000710e9ebd4b2d  vmovaps xmm12, [rsp+0xB0]
0000710e9ebd4b36  vmovaps xmm13, [rsp+0xC0]
0000710e9ebd4b3f  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd4b48  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd4b51  add rsp, 0xF0
0000710e9ebd4b58  pop r11
0000710e9ebd4b5a  pop r10
0000710e9ebd4b5c  pop r9
0000710e9ebd4b5e  pop r8
0000710e9ebd4b60  pop rsi
0000710e9ebd4b61  pop rdi
0000710e9ebd4b62  pop rdx
0000710e9ebd4b63  pop rcx
0000710e9ebd4b64  pop rax
0000710e9ebd4b65  add rsp, 0x08
0000710e9ebd4b69  jmp 0x0000710E9EBD2B8B
0000710e9ebd4b6e  sub rsp, 0x08
0000710e9ebd4b72  push rax
0000710e9ebd4b73  push rcx
0000710e9ebd4b74  push rdx
0000710e9ebd4b75  push rdi
0000710e9ebd4b76  push rsi
0000710e9ebd4b77  push r8
0000710e9ebd4b79  push r9
0000710e9ebd4b7b  push r10
0000710e9ebd4b7d  push r11
0000710e9ebd4b7f  sub rsp, 0xF0
0000710e9ebd4b86  vmovaps [rsp], xmm0
0000710e9ebd4b8b  vmovaps [rsp+0x10], xmm1
0000710e9ebd4b91  vmovaps [rsp+0x20], xmm2
0000710e9ebd4b97  vmovaps [rsp+0x30], xmm3
0000710e9ebd4b9d  vmovaps [rsp+0x40], xmm4
0000710e9ebd4ba3  vmovaps [rsp+0x50], xmm5
0000710e9ebd4ba9  vmovaps [rsp+0x60], xmm6
0000710e9ebd4baf  vmovaps [rsp+0x70], xmm7
0000710e9ebd4bb5  vmovaps [rsp+0x80], xmm8
0000710e9ebd4bbe  vmovaps [rsp+0x90], xmm9
0000710e9ebd4bc7  vmovaps [rsp+0xA0], xmm10
0000710e9ebd4bd0  vmovaps [rsp+0xB0], xmm11
0000710e9ebd4bd9  vmovaps [rsp+0xC0], xmm12
0000710e9ebd4be2  vmovaps [rsp+0xD0], xmm13
0000710e9ebd4beb  vmovaps [rsp+0xE0], xmm14
0000710e9ebd4bf4  sub rsp, 0x30
0000710e9ebd4bf8  movaps [rsp], xmm15
0000710e9ebd4bfd  movaps [rsp+0x10], xmm14
0000710e9ebd4c03  movaps [rsp+0x20], xmm1
0000710e9ebd4c08  lea rdi, [rsp]
0000710e9ebd4c0c  mov esi, 0x00
0000710e9ebd4c11  mov rax, 0x5DADAF7CF530
0000710e9ebd4c1b  call rax
0000710e9ebd4c1d  movaps xmm15, [rsp]
0000710e9ebd4c22  add rsp, 0x30
0000710e9ebd4c26  vmovaps xmm0, [rsp]
0000710e9ebd4c2b  vmovaps xmm1, [rsp+0x10]
0000710e9ebd4c31  vmovaps xmm2, [rsp+0x20]
0000710e9ebd4c37  vmovaps xmm3, [rsp+0x30]
0000710e9ebd4c3d  vmovaps xmm4, [rsp+0x40]
0000710e9ebd4c43  vmovaps xmm5, [rsp+0x50]
0000710e9ebd4c49  vmovaps xmm6, [rsp+0x60]
0000710e9ebd4c4f  vmovaps xmm7, [rsp+0x70]
0000710e9ebd4c55  vmovaps xmm8, [rsp+0x80]
0000710e9ebd4c5e  vmovaps xmm9, [rsp+0x90]
0000710e9ebd4c67  vmovaps xmm10, [rsp+0xA0]
0000710e9ebd4c70  vmovaps xmm11, [rsp+0xB0]
0000710e9ebd4c79  vmovaps xmm12, [rsp+0xC0]
0000710e9ebd4c82  vmovaps xmm13, [rsp+0xD0]
0000710e9ebd4c8b  vmovaps xmm14, [rsp+0xE0]
0000710e9ebd4c94  add rsp, 0xF0
0000710e9ebd4c9b  pop r11
0000710e9ebd4c9d  pop r10
0000710e9ebd4c9f  pop r9
0000710e9ebd4ca1  pop r8
0000710e9ebd4ca3  pop rsi
0000710e9ebd4ca4  pop rdi
0000710e9ebd4ca5  pop rdx
0000710e9ebd4ca6  pop rcx
0000710e9ebd4ca7  pop rax
0000710e9ebd4ca8  add rsp, 0x08
0000710e9ebd4cac  jmp 0x0000710E9EBD2C05
0000710e9ebd4cb1  call 0x0000710E9E9FF430
0000710e9ebd4cb6  jmp 0x0000710E9EBD2C12
0000710e9ebd4cbb  sub rsp, 0x08
0000710e9ebd4cbf  push rax
0000710e9ebd4cc0  push rcx
0000710e9ebd4cc1  push rdx
0000710e9ebd4cc2  push rdi
0000710e9ebd4cc3  push rsi
0000710e9ebd4cc4  push r8
0000710e9ebd4cc6  push r9
0000710e9ebd4cc8  push r10
0000710e9ebd4cca  push r11
0000710e9ebd4ccc  sub rsp, 0xF0
0000710e9ebd4cd3  vmovaps [rsp], xmm0
0000710e9ebd4cd8  vmovaps [rsp+0x10], xmm1
0000710e9ebd4cde  vmovaps [rsp+0x20], xmm2
0000710e9ebd4ce4  vmovaps [rsp+0x30], xmm3
0000710e9ebd4cea  vmovaps [rsp+0x40], xmm4
0000710e9ebd4cf0  vmovaps [rsp+0x50], xmm5
0000710e9ebd4cf6  vmovaps [rsp+0x60], xmm6
0000710e9ebd4cfc  vmovaps [rsp+0x70], xmm7
0000710e9ebd4d02  vmovaps [rsp+0x80], xmm8
0000710e9ebd4d0b  vmovaps [rsp+0x90], xmm9
0000710e9ebd4d14  vmovaps [rsp+0xA0], xmm10
0000710e9ebd4d1d  vmovaps [rsp+0xB0], xmm11
0000710e9ebd4d26  vmovaps [rsp+0xC0], xmm12
0000710e9ebd4d2f  vmovaps [rsp+0xD0], xmm14
0000710e9ebd4d38  vmovaps [rsp+0xE0], xmm15
0000710e9ebd4d41  sub rsp, 0x30
0000710e9ebd4d45  movaps [rsp], xmm13
0000710e9ebd4d4a  movaps [rsp+0x10], xmm1
0000710e9ebd4d4f  movaps [rsp+0x20], xmm15
0000710e9ebd4d55  lea rdi, [rsp]
0000710e9ebd4d59  mov esi, 0x00
0000710e9ebd4d5e  mov rax, 0x5DADAF7CF530
0000710e9ebd4d68  call rax
0000710e9ebd4d6a  movaps xmm13, [rsp]
0000710e9ebd4d6f  add rsp, 0x30
0000710e9ebd4d73  vmovaps xmm0, [rsp]
0000710e9ebd4d78  vmovaps xmm1, [rsp+0x10]
0000710e9ebd4d7e  vmovaps xmm2, [rsp+0x20]
0000710e9ebd4d84  vmovaps xmm3, [rsp+0x30]
0000710e9ebd4d8a  vmovaps xmm4, [rsp+0x40]
0000710e9ebd4d90  vmovaps xmm5, [rsp+0x50]
0000710e9ebd4d96  vmovaps xmm6, [rsp+0x60]
0000710e9ebd4d9c  vmovaps xmm7, [rsp+0x70]
0000710e9ebd4da2  vmovaps xmm8, [rsp+0x80]
0000710e9ebd4dab  vmovaps xmm9, [rsp+0x90]
0000710e9ebd4db4  vmovaps xmm10, [rsp+0xA0]
0000710e9ebd4dbd  vmovaps xmm11, [rsp+0xB0]
0000710e9ebd4dc6  vmovaps xmm12, [rsp+0xC0]
0000710e9ebd4dcf  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd4dd8  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd4de1  add rsp, 0xF0
0000710e9ebd4de8  pop r11
0000710e9ebd4dea  pop r10
0000710e9ebd4dec  pop r9
0000710e9ebd4dee  pop r8
0000710e9ebd4df0  pop rsi
0000710e9ebd4df1  pop rdi
0000710e9ebd4df2  pop rdx
0000710e9ebd4df3  pop rcx
0000710e9ebd4df4  pop rax
0000710e9ebd4df5  add rsp, 0x08
0000710e9ebd4df9  jmp 0x0000710E9EBD2CD6
0000710e9ebd4dfe  sub rsp, 0x08
0000710e9ebd4e02  push rax
0000710e9ebd4e03  push rcx
0000710e9ebd4e04  push rdx
0000710e9ebd4e05  push rdi
0000710e9ebd4e06  push rsi
0000710e9ebd4e07  push r8
0000710e9ebd4e09  push r9
0000710e9ebd4e0b  push r10
0000710e9ebd4e0d  push r11
0000710e9ebd4e0f  sub rsp, 0xF0
0000710e9ebd4e16  vmovaps [rsp], xmm0
0000710e9ebd4e1b  vmovaps [rsp+0x10], xmm1
0000710e9ebd4e21  vmovaps [rsp+0x20], xmm2
0000710e9ebd4e27  vmovaps [rsp+0x30], xmm3
0000710e9ebd4e2d  vmovaps [rsp+0x40], xmm4
0000710e9ebd4e33  vmovaps [rsp+0x50], xmm5
0000710e9ebd4e39  vmovaps [rsp+0x60], xmm6
0000710e9ebd4e3f  vmovaps [rsp+0x70], xmm7
0000710e9ebd4e45  vmovaps [rsp+0x80], xmm8
0000710e9ebd4e4e  vmovaps [rsp+0x90], xmm9
0000710e9ebd4e57  vmovaps [rsp+0xA0], xmm10
0000710e9ebd4e60  vmovaps [rsp+0xB0], xmm11
0000710e9ebd4e69  vmovaps [rsp+0xC0], xmm12
0000710e9ebd4e72  vmovaps [rsp+0xD0], xmm13
0000710e9ebd4e7b  vmovaps [rsp+0xE0], xmm14
0000710e9ebd4e84  sub rsp, 0x30
0000710e9ebd4e88  movaps [rsp], xmm15
0000710e9ebd4e8d  movaps [rsp+0x10], xmm14
0000710e9ebd4e93  movaps [rsp+0x20], xmm1
0000710e9ebd4e98  lea rdi, [rsp]
0000710e9ebd4e9c  mov esi, 0x00
0000710e9ebd4ea1  mov rax, 0x5DADAF7CF530
0000710e9ebd4eab  call rax
0000710e9ebd4ead  movaps xmm15, [rsp]
0000710e9ebd4eb2  add rsp, 0x30
0000710e9ebd4eb6  vmovaps xmm0, [rsp]
0000710e9ebd4ebb  vmovaps xmm1, [rsp+0x10]
0000710e9ebd4ec1  vmovaps xmm2, [rsp+0x20]
0000710e9ebd4ec7  vmovaps xmm3, [rsp+0x30]
0000710e9ebd4ecd  vmovaps xmm4, [rsp+0x40]
0000710e9ebd4ed3  vmovaps xmm5, [rsp+0x50]
0000710e9ebd4ed9  vmovaps xmm6, [rsp+0x60]
0000710e9ebd4edf  vmovaps xmm7, [rsp+0x70]
0000710e9ebd4ee5  vmovaps xmm8, [rsp+0x80]
0000710e9ebd4eee  vmovaps xmm9, [rsp+0x90]
0000710e9ebd4ef7  vmovaps xmm10, [rsp+0xA0]
0000710e9ebd4f00  vmovaps xmm11, [rsp+0xB0]
0000710e9ebd4f09  vmovaps xmm12, [rsp+0xC0]
0000710e9ebd4f12  vmovaps xmm13, [rsp+0xD0]
0000710e9ebd4f1b  vmovaps xmm14, [rsp+0xE0]
0000710e9ebd4f24  add rsp, 0xF0
0000710e9ebd4f2b  pop r11
0000710e9ebd4f2d  pop r10
0000710e9ebd4f2f  pop r9
0000710e9ebd4f31  pop r8
0000710e9ebd4f33  pop rsi
0000710e9ebd4f34  pop rdi
0000710e9ebd4f35  pop rdx
0000710e9ebd4f36  pop rcx
0000710e9ebd4f37  pop rax
0000710e9ebd4f38  add rsp, 0x08
0000710e9ebd4f3c  jmp 0x0000710E9EBD2D12
0000710e9ebd4f41  call 0x0000710E9E9FF430
0000710e9ebd4f46  jmp 0x0000710E9EBD2D1F
0000710e9ebd4f4b  sub rsp, 0x08
0000710e9ebd4f4f  push rax
0000710e9ebd4f50  push rcx
0000710e9ebd4f51  push rdx
0000710e9ebd4f52  push rdi
0000710e9ebd4f53  push rsi
0000710e9ebd4f54  push r8
0000710e9ebd4f56  push r9
0000710e9ebd4f58  push r10
0000710e9ebd4f5a  push r11
0000710e9ebd4f5c  sub rsp, 0xF0
0000710e9ebd4f63  vmovaps [rsp], xmm0
0000710e9ebd4f68  vmovaps [rsp+0x10], xmm1
0000710e9ebd4f6e  vmovaps [rsp+0x20], xmm2
0000710e9ebd4f74  vmovaps [rsp+0x30], xmm3
0000710e9ebd4f7a  vmovaps [rsp+0x40], xmm4
0000710e9ebd4f80  vmovaps [rsp+0x50], xmm5
0000710e9ebd4f86  vmovaps [rsp+0x60], xmm6
0000710e9ebd4f8c  vmovaps [rsp+0x70], xmm7
0000710e9ebd4f92  vmovaps [rsp+0x80], xmm8
0000710e9ebd4f9b  vmovaps [rsp+0x90], xmm9
0000710e9ebd4fa4  vmovaps [rsp+0xA0], xmm10
0000710e9ebd4fad  vmovaps [rsp+0xB0], xmm11
0000710e9ebd4fb6  vmovaps [rsp+0xC0], xmm12
0000710e9ebd4fbf  vmovaps [rsp+0xD0], xmm13
0000710e9ebd4fc8  vmovaps [rsp+0xE0], xmm15
0000710e9ebd4fd1  sub rsp, 0x30
0000710e9ebd4fd5  movaps [rsp], xmm14
0000710e9ebd4fda  movaps [rsp+0x10], xmm13
0000710e9ebd4fe0  movaps [rsp+0x20], xmm2
0000710e9ebd4fe5  lea rdi, [rsp]
0000710e9ebd4fe9  mov esi, 0x00
0000710e9ebd4fee  mov rax, 0x5DADAF7CF530
0000710e9ebd4ff8  call rax
0000710e9ebd4ffa  movaps xmm14, [rsp]
0000710e9ebd4fff  add rsp, 0x30
0000710e9ebd5003  vmovaps xmm0, [rsp]
0000710e9ebd5008  vmovaps xmm1, [rsp+0x10]
0000710e9ebd500e  vmovaps xmm2, [rsp+0x20]
0000710e9ebd5014  vmovaps xmm3, [rsp+0x30]
0000710e9ebd501a  vmovaps xmm4, [rsp+0x40]
0000710e9ebd5020  vmovaps xmm5, [rsp+0x50]
0000710e9ebd5026  vmovaps xmm6, [rsp+0x60]
0000710e9ebd502c  vmovaps xmm7, [rsp+0x70]
0000710e9ebd5032  vmovaps xmm8, [rsp+0x80]
0000710e9ebd503b  vmovaps xmm9, [rsp+0x90]
0000710e9ebd5044  vmovaps xmm10, [rsp+0xA0]
0000710e9ebd504d  vmovaps xmm11, [rsp+0xB0]
0000710e9ebd5056  vmovaps xmm12, [rsp+0xC0]
0000710e9ebd505f  vmovaps xmm13, [rsp+0xD0]
0000710e9ebd5068  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd5071  add rsp, 0xF0
0000710e9ebd5078  pop r11
0000710e9ebd507a  pop r10
0000710e9ebd507c  pop r9
0000710e9ebd507e  pop r8
0000710e9ebd5080  pop rsi
0000710e9ebd5081  pop rdi
0000710e9ebd5082  pop rdx
0000710e9ebd5083  pop rcx
0000710e9ebd5084  pop rax
0000710e9ebd5085  add rsp, 0x08
0000710e9ebd5089  jmp 0x0000710E9EBD2D4B
0000710e9ebd508e  sub rsp, 0x08
0000710e9ebd5092  push rax
0000710e9ebd5093  push rcx
0000710e9ebd5094  push rdx
0000710e9ebd5095  push rdi
0000710e9ebd5096  push rsi
0000710e9ebd5097  push r8
0000710e9ebd5099  push r9
0000710e9ebd509b  push r10
0000710e9ebd509d  push r11
0000710e9ebd509f  sub rsp, 0xF0
0000710e9ebd50a6  vmovaps [rsp], xmm0
0000710e9ebd50ab  vmovaps [rsp+0x10], xmm2
0000710e9ebd50b1  vmovaps [rsp+0x20], xmm3
0000710e9ebd50b7  vmovaps [rsp+0x30], xmm4
0000710e9ebd50bd  vmovaps [rsp+0x40], xmm5
0000710e9ebd50c3  vmovaps [rsp+0x50], xmm6
0000710e9ebd50c9  vmovaps [rsp+0x60], xmm7
0000710e9ebd50cf  vmovaps [rsp+0x70], xmm8
0000710e9ebd50d5  vmovaps [rsp+0x80], xmm9
0000710e9ebd50de  vmovaps [rsp+0x90], xmm10
0000710e9ebd50e7  vmovaps [rsp+0xA0], xmm11
0000710e9ebd50f0  vmovaps [rsp+0xB0], xmm12
0000710e9ebd50f9  vmovaps [rsp+0xC0], xmm13
0000710e9ebd5102  vmovaps [rsp+0xD0], xmm14
0000710e9ebd510b  vmovaps [rsp+0xE0], xmm15
0000710e9ebd5114  sub rsp, 0x30
0000710e9ebd5118  movaps [rsp], xmm1
0000710e9ebd511c  movaps [rsp+0x10], xmm13
0000710e9ebd5122  movaps [rsp+0x20], xmm2
0000710e9ebd5127  lea rdi, [rsp]
0000710e9ebd512b  mov esi, 0x00
0000710e9ebd5130  mov rax, 0x5DADAF7CF530
0000710e9ebd513a  call rax
0000710e9ebd513c  movaps xmm1, [rsp]
0000710e9ebd5140  add rsp, 0x30
0000710e9ebd5144  vmovaps xmm0, [rsp]
0000710e9ebd5149  vmovaps xmm2, [rsp+0x10]
0000710e9ebd514f  vmovaps xmm3, [rsp+0x20]
0000710e9ebd5155  vmovaps xmm4, [rsp+0x30]
0000710e9ebd515b  vmovaps xmm5, [rsp+0x40]
0000710e9ebd5161  vmovaps xmm6, [rsp+0x50]
0000710e9ebd5167  vmovaps xmm7, [rsp+0x60]
0000710e9ebd516d  vmovaps xmm8, [rsp+0x70]
0000710e9ebd5173  vmovaps xmm9, [rsp+0x80]
0000710e9ebd517c  vmovaps xmm10, [rsp+0x90]
0000710e9ebd5185  vmovaps xmm11, [rsp+0xA0]
0000710e9ebd518e  vmovaps xmm12, [rsp+0xB0]
0000710e9ebd5197  vmovaps xmm13, [rsp+0xC0]
0000710e9ebd51a0  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd51a9  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd51b2  add rsp, 0xF0
0000710e9ebd51b9  pop r11
0000710e9ebd51bb  pop r10
0000710e9ebd51bd  pop r9
0000710e9ebd51bf  pop r8
0000710e9ebd51c1  pop rsi
0000710e9ebd51c2  pop rdi
0000710e9ebd51c3  pop rdx
0000710e9ebd51c4  pop rcx
0000710e9ebd51c5  pop rax
0000710e9ebd51c6  add rsp, 0x08
0000710e9ebd51ca  jmp 0x0000710E9EBD2D79
0000710e9ebd51cf  sub rsp, 0x08
0000710e9ebd51d3  push rax
0000710e9ebd51d4  push rcx
0000710e9ebd51d5  push rdx
0000710e9ebd51d6  push rdi
0000710e9ebd51d7  push rsi
0000710e9ebd51d8  push r8
0000710e9ebd51da  push r9
0000710e9ebd51dc  push r10
0000710e9ebd51de  push r11
0000710e9ebd51e0  sub rsp, 0xF0
0000710e9ebd51e7  vmovaps [rsp], xmm0
0000710e9ebd51ec  vmovaps [rsp+0x10], xmm1
0000710e9ebd51f2  vmovaps [rsp+0x20], xmm3
0000710e9ebd51f8  vmovaps [rsp+0x30], xmm4
0000710e9ebd51fe  vmovaps [rsp+0x40], xmm5
0000710e9ebd5204  vmovaps [rsp+0x50], xmm6
0000710e9ebd520a  vmovaps [rsp+0x60], xmm7
0000710e9ebd5210  vmovaps [rsp+0x70], xmm8
0000710e9ebd5216  vmovaps [rsp+0x80], xmm9
0000710e9ebd521f  vmovaps [rsp+0x90], xmm10
0000710e9ebd5228  vmovaps [rsp+0xA0], xmm11
0000710e9ebd5231  vmovaps [rsp+0xB0], xmm12
0000710e9ebd523a  vmovaps [rsp+0xC0], xmm13
0000710e9ebd5243  vmovaps [rsp+0xD0], xmm14
0000710e9ebd524c  vmovaps [rsp+0xE0], xmm15
0000710e9ebd5255  sub rsp, 0x30
0000710e9ebd5259  movaps [rsp], xmm2
0000710e9ebd525d  movaps [rsp+0x10], xmm1
0000710e9ebd5262  movaps [rsp+0x20], xmm13
0000710e9ebd5268  lea rdi, [rsp]
0000710e9ebd526c  mov esi, 0x00
0000710e9ebd5271  mov rax, 0x5DADAF7CF530
0000710e9ebd527b  call rax
0000710e9ebd527d  movaps xmm2, [rsp]
0000710e9ebd5281  add rsp, 0x30
0000710e9ebd5285  vmovaps xmm0, [rsp]
0000710e9ebd528a  vmovaps xmm1, [rsp+0x10]
0000710e9ebd5290  vmovaps xmm3, [rsp+0x20]
0000710e9ebd5296  vmovaps xmm4, [rsp+0x30]
0000710e9ebd529c  vmovaps xmm5, [rsp+0x40]
0000710e9ebd52a2  vmovaps xmm6, [rsp+0x50]
0000710e9ebd52a8  vmovaps xmm7, [rsp+0x60]
0000710e9ebd52ae  vmovaps xmm8, [rsp+0x70]
0000710e9ebd52b4  vmovaps xmm9, [rsp+0x80]
0000710e9ebd52bd  vmovaps xmm10, [rsp+0x90]
0000710e9ebd52c6  vmovaps xmm11, [rsp+0xA0]
0000710e9ebd52cf  vmovaps xmm12, [rsp+0xB0]
0000710e9ebd52d8  vmovaps xmm13, [rsp+0xC0]
0000710e9ebd52e1  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd52ea  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd52f3  add rsp, 0xF0
0000710e9ebd52fa  pop r11
0000710e9ebd52fc  pop r10
0000710e9ebd52fe  pop r9
0000710e9ebd5300  pop r8
0000710e9ebd5302  pop rsi
0000710e9ebd5303  pop rdi
0000710e9ebd5304  pop rdx
0000710e9ebd5305  pop rcx
0000710e9ebd5306  pop rax
0000710e9ebd5307  add rsp, 0x08
0000710e9ebd530b  jmp 0x0000710E9EBD2DD2
0000710e9ebd5310  call 0x0000710E9E9FF430
0000710e9ebd5315  jmp 0x0000710E9EBD2DDF
0000710e9ebd531a  sub rsp, 0x08
0000710e9ebd531e  push rax
0000710e9ebd531f  push rcx
0000710e9ebd5320  push rdx
0000710e9ebd5321  push rdi
0000710e9ebd5322  push rsi
0000710e9ebd5323  push r8
0000710e9ebd5325  push r9
0000710e9ebd5327  push r10
0000710e9ebd5329  push r11
0000710e9ebd532b  sub rsp, 0xF0
0000710e9ebd5332  vmovaps [rsp], xmm0
0000710e9ebd5337  vmovaps [rsp+0x10], xmm1
0000710e9ebd533d  vmovaps [rsp+0x20], xmm2
0000710e9ebd5343  vmovaps [rsp+0x30], xmm3
0000710e9ebd5349  vmovaps [rsp+0x40], xmm4
0000710e9ebd534f  vmovaps [rsp+0x50], xmm5
0000710e9ebd5355  vmovaps [rsp+0x60], xmm6
0000710e9ebd535b  vmovaps [rsp+0x70], xmm7
0000710e9ebd5361  vmovaps [rsp+0x80], xmm8
0000710e9ebd536a  vmovaps [rsp+0x90], xmm9
0000710e9ebd5373  vmovaps [rsp+0xA0], xmm10
0000710e9ebd537c  vmovaps [rsp+0xB0], xmm11
0000710e9ebd5385  vmovaps [rsp+0xC0], xmm12
0000710e9ebd538e  vmovaps [rsp+0xD0], xmm13
0000710e9ebd5397  vmovaps [rsp+0xE0], xmm14
0000710e9ebd53a0  sub rsp, 0x30
0000710e9ebd53a4  movaps [rsp], xmm15
0000710e9ebd53a9  movaps [rsp+0x10], xmm13
0000710e9ebd53af  movaps [rsp+0x20], xmm1
0000710e9ebd53b4  lea rdi, [rsp]
0000710e9ebd53b8  mov esi, 0x00
0000710e9ebd53bd  mov rax, 0x5DADAF7CF530
0000710e9ebd53c7  call rax
0000710e9ebd53c9  movaps xmm15, [rsp]
0000710e9ebd53ce  add rsp, 0x30
0000710e9ebd53d2  vmovaps xmm0, [rsp]
0000710e9ebd53d7  vmovaps xmm1, [rsp+0x10]
0000710e9ebd53dd  vmovaps xmm2, [rsp+0x20]
0000710e9ebd53e3  vmovaps xmm3, [rsp+0x30]
0000710e9ebd53e9  vmovaps xmm4, [rsp+0x40]
0000710e9ebd53ef  vmovaps xmm5, [rsp+0x50]
0000710e9ebd53f5  vmovaps xmm6, [rsp+0x60]
0000710e9ebd53fb  vmovaps xmm7, [rsp+0x70]
0000710e9ebd5401  vmovaps xmm8, [rsp+0x80]
0000710e9ebd540a  vmovaps xmm9, [rsp+0x90]
0000710e9ebd5413  vmovaps xmm10, [rsp+0xA0]
0000710e9ebd541c  vmovaps xmm11, [rsp+0xB0]
0000710e9ebd5425  vmovaps xmm12, [rsp+0xC0]
0000710e9ebd542e  vmovaps xmm13, [rsp+0xD0]
0000710e9ebd5437  vmovaps xmm14, [rsp+0xE0]
0000710e9ebd5440  add rsp, 0xF0
0000710e9ebd5447  pop r11
0000710e9ebd5449  pop r10
0000710e9ebd544b  pop r9
0000710e9ebd544d  pop r8
0000710e9ebd544f  pop rsi
0000710e9ebd5450  pop rdi
0000710e9ebd5451  pop rdx
0000710e9ebd5452  pop rcx
0000710e9ebd5453  pop rax
0000710e9ebd5454  add rsp, 0x08
0000710e9ebd5458  jmp 0x0000710E9EBD2E1E
0000710e9ebd545d  sub rsp, 0x08
0000710e9ebd5461  push rax
0000710e9ebd5462  push rcx
0000710e9ebd5463  push rdx
0000710e9ebd5464  push rdi
0000710e9ebd5465  push rsi
0000710e9ebd5466  push r8
0000710e9ebd5468  push r9
0000710e9ebd546a  push r10
0000710e9ebd546c  push r11
0000710e9ebd546e  sub rsp, 0xF0
0000710e9ebd5475  vmovaps [rsp], xmm0
0000710e9ebd547a  vmovaps [rsp+0x10], xmm1
0000710e9ebd5480  vmovaps [rsp+0x20], xmm2
0000710e9ebd5486  vmovaps [rsp+0x30], xmm3
0000710e9ebd548c  vmovaps [rsp+0x40], xmm4
0000710e9ebd5492  vmovaps [rsp+0x50], xmm5
0000710e9ebd5498  vmovaps [rsp+0x60], xmm6
0000710e9ebd549e  vmovaps [rsp+0x70], xmm7
0000710e9ebd54a4  vmovaps [rsp+0x80], xmm8
0000710e9ebd54ad  vmovaps [rsp+0x90], xmm9
0000710e9ebd54b6  vmovaps [rsp+0xA0], xmm10
0000710e9ebd54bf  vmovaps [rsp+0xB0], xmm11
0000710e9ebd54c8  vmovaps [rsp+0xC0], xmm12
0000710e9ebd54d1  vmovaps [rsp+0xD0], xmm13
0000710e9ebd54da  vmovaps [rsp+0xE0], xmm15
0000710e9ebd54e3  sub rsp, 0x30
0000710e9ebd54e7  movaps [rsp], xmm14
0000710e9ebd54ec  movaps [rsp+0x10], xmm11
0000710e9ebd54f2  movaps [rsp+0x20], xmm1
0000710e9ebd54f7  lea rdi, [rsp]
0000710e9ebd54fb  mov esi, 0x00
0000710e9ebd5500  mov rax, 0x5DADAF7CF530
0000710e9ebd550a  call rax
0000710e9ebd550c  movaps xmm14, [rsp]
0000710e9ebd5511  add rsp, 0x30
0000710e9ebd5515  vmovaps xmm0, [rsp]
0000710e9ebd551a  vmovaps xmm1, [rsp+0x10]
0000710e9ebd5520  vmovaps xmm2, [rsp+0x20]
0000710e9ebd5526  vmovaps xmm3, [rsp+0x30]
0000710e9ebd552c  vmovaps xmm4, [rsp+0x40]
0000710e9ebd5532  vmovaps xmm5, [rsp+0x50]
0000710e9ebd5538  vmovaps xmm6, [rsp+0x60]
0000710e9ebd553e  vmovaps xmm7, [rsp+0x70]
0000710e9ebd5544  vmovaps xmm8, [rsp+0x80]
0000710e9ebd554d  vmovaps xmm9, [rsp+0x90]
0000710e9ebd5556  vmovaps xmm10, [rsp+0xA0]
0000710e9ebd555f  vmovaps xmm11, [rsp+0xB0]
0000710e9ebd5568  vmovaps xmm12, [rsp+0xC0]
0000710e9ebd5571  vmovaps xmm13, [rsp+0xD0]
0000710e9ebd557a  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd5583  add rsp, 0xF0
0000710e9ebd558a  pop r11
0000710e9ebd558c  pop r10
0000710e9ebd558e  pop r9
0000710e9ebd5590  pop r8
0000710e9ebd5592  pop rsi
0000710e9ebd5593  pop rdi
0000710e9ebd5594  pop rdx
0000710e9ebd5595  pop rcx
0000710e9ebd5596  pop rax
0000710e9ebd5597  add rsp, 0x08
0000710e9ebd559b  jmp 0x0000710E9EBD2E48
0000710e9ebd55a0  sub rsp, 0x08
0000710e9ebd55a4  push rax
0000710e9ebd55a5  push rcx
0000710e9ebd55a6  push rdx
0000710e9ebd55a7  push rdi
0000710e9ebd55a8  push rsi
0000710e9ebd55a9  push r8
0000710e9ebd55ab  push r9
0000710e9ebd55ad  push r10
0000710e9ebd55af  push r11
0000710e9ebd55b1  sub rsp, 0xF0
0000710e9ebd55b8  vmovaps [rsp], xmm0
0000710e9ebd55bd  vmovaps [rsp+0x10], xmm1
0000710e9ebd55c3  vmovaps [rsp+0x20], xmm2
0000710e9ebd55c9  vmovaps [rsp+0x30], xmm3
0000710e9ebd55cf  vmovaps [rsp+0x40], xmm4
0000710e9ebd55d5  vmovaps [rsp+0x50], xmm5
0000710e9ebd55db  vmovaps [rsp+0x60], xmm6
0000710e9ebd55e1  vmovaps [rsp+0x70], xmm7
0000710e9ebd55e7  vmovaps [rsp+0x80], xmm8
0000710e9ebd55f0  vmovaps [rsp+0x90], xmm9
0000710e9ebd55f9  vmovaps [rsp+0xA0], xmm10
0000710e9ebd5602  vmovaps [rsp+0xB0], xmm11
0000710e9ebd560b  vmovaps [rsp+0xC0], xmm12
0000710e9ebd5614  vmovaps [rsp+0xD0], xmm14
0000710e9ebd561d  vmovaps [rsp+0xE0], xmm15
0000710e9ebd5626  sub rsp, 0x30
0000710e9ebd562a  movaps [rsp], xmm13
0000710e9ebd562f  movaps [rsp+0x10], xmm11
0000710e9ebd5635  movaps [rsp+0x20], xmm1
0000710e9ebd563a  lea rdi, [rsp]
0000710e9ebd563e  mov esi, 0x00
0000710e9ebd5643  mov rax, 0x5DADAF7CF530
0000710e9ebd564d  call rax
0000710e9ebd564f  movaps xmm13, [rsp]
0000710e9ebd5654  add rsp, 0x30
0000710e9ebd5658  vmovaps xmm0, [rsp]
0000710e9ebd565d  vmovaps xmm1, [rsp+0x10]
0000710e9ebd5663  vmovaps xmm2, [rsp+0x20]
0000710e9ebd5669  vmovaps xmm3, [rsp+0x30]
0000710e9ebd566f  vmovaps xmm4, [rsp+0x40]
0000710e9ebd5675  vmovaps xmm5, [rsp+0x50]
0000710e9ebd567b  vmovaps xmm6, [rsp+0x60]
0000710e9ebd5681  vmovaps xmm7, [rsp+0x70]
0000710e9ebd5687  vmovaps xmm8, [rsp+0x80]
0000710e9ebd5690  vmovaps xmm9, [rsp+0x90]
0000710e9ebd5699  vmovaps xmm10, [rsp+0xA0]
0000710e9ebd56a2  vmovaps xmm11, [rsp+0xB0]
0000710e9ebd56ab  vmovaps xmm12, [rsp+0xC0]
0000710e9ebd56b4  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd56bd  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd56c6  add rsp, 0xF0
0000710e9ebd56cd  pop r11
0000710e9ebd56cf  pop r10
0000710e9ebd56d1  pop r9
0000710e9ebd56d3  pop r8
0000710e9ebd56d5  pop rsi
0000710e9ebd56d6  pop rdi
0000710e9ebd56d7  pop rdx
0000710e9ebd56d8  pop rcx
0000710e9ebd56d9  pop rax
0000710e9ebd56da  add rsp, 0x08
0000710e9ebd56de  jmp 0x0000710E9EBD2E9D
0000710e9ebd56e3  call 0x0000710E9E9FF430
0000710e9ebd56e8  jmp 0x0000710E9EBD2EAA
0000710e9ebd56ed  sub rsp, 0x08
0000710e9ebd56f1  push rax
0000710e9ebd56f2  push rcx
0000710e9ebd56f3  push rdx
0000710e9ebd56f4  push rdi
0000710e9ebd56f5  push rsi
0000710e9ebd56f6  push r8
0000710e9ebd56f8  push r9
0000710e9ebd56fa  push r10
0000710e9ebd56fc  push r11
0000710e9ebd56fe  sub rsp, 0xF0
0000710e9ebd5705  vmovaps [rsp], xmm0
0000710e9ebd570a  vmovaps [rsp+0x10], xmm1
0000710e9ebd5710  vmovaps [rsp+0x20], xmm2
0000710e9ebd5716  vmovaps [rsp+0x30], xmm3
0000710e9ebd571c  vmovaps [rsp+0x40], xmm4
0000710e9ebd5722  vmovaps [rsp+0x50], xmm5
0000710e9ebd5728  vmovaps [rsp+0x60], xmm6
0000710e9ebd572e  vmovaps [rsp+0x70], xmm7
0000710e9ebd5734  vmovaps [rsp+0x80], xmm8
0000710e9ebd573d  vmovaps [rsp+0x90], xmm9
0000710e9ebd5746  vmovaps [rsp+0xA0], xmm10
0000710e9ebd574f  vmovaps [rsp+0xB0], xmm11
0000710e9ebd5758  vmovaps [rsp+0xC0], xmm12
0000710e9ebd5761  vmovaps [rsp+0xD0], xmm13
0000710e9ebd576a  vmovaps [rsp+0xE0], xmm14
0000710e9ebd5773  sub rsp, 0x30
0000710e9ebd5777  movaps [rsp], xmm15
0000710e9ebd577c  movaps [rsp+0x10], xmm11
0000710e9ebd5782  movaps [rsp+0x20], xmm1
0000710e9ebd5787  lea rdi, [rsp]
0000710e9ebd578b  mov esi, 0x00
0000710e9ebd5790  mov rax, 0x5DADAF7CF530
0000710e9ebd579a  call rax
0000710e9ebd579c  movaps xmm15, [rsp]
0000710e9ebd57a1  add rsp, 0x30
0000710e9ebd57a5  vmovaps xmm0, [rsp]
0000710e9ebd57aa  vmovaps xmm1, [rsp+0x10]
0000710e9ebd57b0  vmovaps xmm2, [rsp+0x20]
0000710e9ebd57b6  vmovaps xmm3, [rsp+0x30]
0000710e9ebd57bc  vmovaps xmm4, [rsp+0x40]
0000710e9ebd57c2  vmovaps xmm5, [rsp+0x50]
0000710e9ebd57c8  vmovaps xmm6, [rsp+0x60]
0000710e9ebd57ce  vmovaps xmm7, [rsp+0x70]
0000710e9ebd57d4  vmovaps xmm8, [rsp+0x80]
0000710e9ebd57dd  vmovaps xmm9, [rsp+0x90]
0000710e9ebd57e6  vmovaps xmm10, [rsp+0xA0]
0000710e9ebd57ef  vmovaps xmm11, [rsp+0xB0]
0000710e9ebd57f8  vmovaps xmm12, [rsp+0xC0]
0000710e9ebd5801  vmovaps xmm13, [rsp+0xD0]
0000710e9ebd580a  vmovaps xmm14, [rsp+0xE0]
0000710e9ebd5813  add rsp, 0xF0
0000710e9ebd581a  pop r11
0000710e9ebd581c  pop r10
0000710e9ebd581e  pop r9
0000710e9ebd5820  pop r8
0000710e9ebd5822  pop rsi
0000710e9ebd5823  pop rdi
0000710e9ebd5824  pop rdx
0000710e9ebd5825  pop rcx
0000710e9ebd5826  pop rax
0000710e9ebd5827  add rsp, 0x08
0000710e9ebd582b  jmp 0x0000710E9EBD2EE3
0000710e9ebd5830  sub rsp, 0x08
0000710e9ebd5834  push rax
0000710e9ebd5835  push rcx
0000710e9ebd5836  push rdx
0000710e9ebd5837  push rdi
0000710e9ebd5838  push rsi
0000710e9ebd5839  push r8
0000710e9ebd583b  push r9
0000710e9ebd583d  push r10
0000710e9ebd583f  push r11
0000710e9ebd5841  sub rsp, 0xF0
0000710e9ebd5848  vmovaps [rsp], xmm0
0000710e9ebd584d  vmovaps [rsp+0x10], xmm1
0000710e9ebd5853  vmovaps [rsp+0x20], xmm2
0000710e9ebd5859  vmovaps [rsp+0x30], xmm3
0000710e9ebd585f  vmovaps [rsp+0x40], xmm4
0000710e9ebd5865  vmovaps [rsp+0x50], xmm5
0000710e9ebd586b  vmovaps [rsp+0x60], xmm6
0000710e9ebd5871  vmovaps [rsp+0x70], xmm7
0000710e9ebd5877  vmovaps [rsp+0x80], xmm8
0000710e9ebd5880  vmovaps [rsp+0x90], xmm9
0000710e9ebd5889  vmovaps [rsp+0xA0], xmm10
0000710e9ebd5892  vmovaps [rsp+0xB0], xmm12
0000710e9ebd589b  vmovaps [rsp+0xC0], xmm13
0000710e9ebd58a4  vmovaps [rsp+0xD0], xmm14
0000710e9ebd58ad  vmovaps [rsp+0xE0], xmm15
0000710e9ebd58b6  sub rsp, 0x30
0000710e9ebd58ba  movaps [rsp], xmm11
0000710e9ebd58bf  movaps [rsp+0x10], xmm6
0000710e9ebd58c4  movaps [rsp+0x20], xmm14
0000710e9ebd58ca  lea rdi, [rsp]
0000710e9ebd58ce  mov esi, 0x00
0000710e9ebd58d3  mov rax, 0x5DADAF7CF530
0000710e9ebd58dd  call rax
0000710e9ebd58df  movaps xmm11, [rsp]
0000710e9ebd58e4  add rsp, 0x30
0000710e9ebd58e8  vmovaps xmm0, [rsp]
0000710e9ebd58ed  vmovaps xmm1, [rsp+0x10]
0000710e9ebd58f3  vmovaps xmm2, [rsp+0x20]
0000710e9ebd58f9  vmovaps xmm3, [rsp+0x30]
0000710e9ebd58ff  vmovaps xmm4, [rsp+0x40]
0000710e9ebd5905  vmovaps xmm5, [rsp+0x50]
0000710e9ebd590b  vmovaps xmm6, [rsp+0x60]
0000710e9ebd5911  vmovaps xmm7, [rsp+0x70]
0000710e9ebd5917  vmovaps xmm8, [rsp+0x80]
0000710e9ebd5920  vmovaps xmm9, [rsp+0x90]
0000710e9ebd5929  vmovaps xmm10, [rsp+0xA0]
0000710e9ebd5932  vmovaps xmm12, [rsp+0xB0]
0000710e9ebd593b  vmovaps xmm13, [rsp+0xC0]
0000710e9ebd5944  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd594d  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd5956  add rsp, 0xF0
0000710e9ebd595d  pop r11
0000710e9ebd595f  pop r10
0000710e9ebd5961  pop r9
0000710e9ebd5963  pop r8
0000710e9ebd5965  pop rsi
0000710e9ebd5966  pop rdi
0000710e9ebd5967  pop rdx
0000710e9ebd5968  pop rcx
0000710e9ebd5969  pop rax
0000710e9ebd596a  add rsp, 0x08
0000710e9ebd596e  jmp 0x0000710E9EBD2F5B
0000710e9ebd5973  call 0x0000710E9E9FF430
0000710e9ebd5978  jmp 0x0000710E9EBD2F65
0000710e9ebd597d  sub rsp, 0x08
0000710e9ebd5981  push rax
0000710e9ebd5982  push rcx
0000710e9ebd5983  push rdx
0000710e9ebd5984  push rdi
0000710e9ebd5985  push rsi
0000710e9ebd5986  push r8
0000710e9ebd5988  push r9
0000710e9ebd598a  push r10
0000710e9ebd598c  push r11
0000710e9ebd598e  sub rsp, 0xF0
0000710e9ebd5995  vmovaps [rsp], xmm0
0000710e9ebd599a  vmovaps [rsp+0x10], xmm1
0000710e9ebd59a0  vmovaps [rsp+0x20], xmm2
0000710e9ebd59a6  vmovaps [rsp+0x30], xmm3
0000710e9ebd59ac  vmovaps [rsp+0x40], xmm4
0000710e9ebd59b2  vmovaps [rsp+0x50], xmm5
0000710e9ebd59b8  vmovaps [rsp+0x60], xmm6
0000710e9ebd59be  vmovaps [rsp+0x70], xmm7
0000710e9ebd59c4  vmovaps [rsp+0x80], xmm8
0000710e9ebd59cd  vmovaps [rsp+0x90], xmm9
0000710e9ebd59d6  vmovaps [rsp+0xA0], xmm10
0000710e9ebd59df  vmovaps [rsp+0xB0], xmm11
0000710e9ebd59e8  vmovaps [rsp+0xC0], xmm12
0000710e9ebd59f1  vmovaps [rsp+0xD0], xmm13
0000710e9ebd59fa  vmovaps [rsp+0xE0], xmm15
0000710e9ebd5a03  sub rsp, 0x30
0000710e9ebd5a07  movaps [rsp], xmm14
0000710e9ebd5a0c  movaps [rsp+0x10], xmm6
0000710e9ebd5a11  movaps [rsp+0x20], xmm2
0000710e9ebd5a16  lea rdi, [rsp]
0000710e9ebd5a1a  mov esi, 0x00
0000710e9ebd5a1f  mov rax, 0x5DADAF7CF530
0000710e9ebd5a29  call rax
0000710e9ebd5a2b  movaps xmm14, [rsp]
0000710e9ebd5a30  add rsp, 0x30
0000710e9ebd5a34  vmovaps xmm0, [rsp]
0000710e9ebd5a39  vmovaps xmm1, [rsp+0x10]
0000710e9ebd5a3f  vmovaps xmm2, [rsp+0x20]
0000710e9ebd5a45  vmovaps xmm3, [rsp+0x30]
0000710e9ebd5a4b  vmovaps xmm4, [rsp+0x40]
0000710e9ebd5a51  vmovaps xmm5, [rsp+0x50]
0000710e9ebd5a57  vmovaps xmm6, [rsp+0x60]
0000710e9ebd5a5d  vmovaps xmm7, [rsp+0x70]
0000710e9ebd5a63  vmovaps xmm8, [rsp+0x80]
0000710e9ebd5a6c  vmovaps xmm9, [rsp+0x90]
0000710e9ebd5a75  vmovaps xmm10, [rsp+0xA0]
0000710e9ebd5a7e  vmovaps xmm11, [rsp+0xB0]
0000710e9ebd5a87  vmovaps xmm12, [rsp+0xC0]
0000710e9ebd5a90  vmovaps xmm13, [rsp+0xD0]
0000710e9ebd5a99  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd5aa2  add rsp, 0xF0
0000710e9ebd5aa9  pop r11
0000710e9ebd5aab  pop r10
0000710e9ebd5aad  pop r9
0000710e9ebd5aaf  pop r8
0000710e9ebd5ab1  pop rsi
0000710e9ebd5ab2  pop rdi
0000710e9ebd5ab3  pop rdx
0000710e9ebd5ab4  pop rcx
0000710e9ebd5ab5  pop rax
0000710e9ebd5ab6  add rsp, 0x08
0000710e9ebd5aba  jmp 0x0000710E9EBD2F99
0000710e9ebd5abf  sub rsp, 0x08
0000710e9ebd5ac3  push rax
0000710e9ebd5ac4  push rcx
0000710e9ebd5ac5  push rdx
0000710e9ebd5ac6  push rdi
0000710e9ebd5ac7  push rsi
0000710e9ebd5ac8  push r8
0000710e9ebd5aca  push r9
0000710e9ebd5acc  push r10
0000710e9ebd5ace  push r11
0000710e9ebd5ad0  sub rsp, 0xF0
0000710e9ebd5ad7  vmovaps [rsp], xmm0
0000710e9ebd5adc  vmovaps [rsp+0x10], xmm1
0000710e9ebd5ae2  vmovaps [rsp+0x20], xmm2
0000710e9ebd5ae8  vmovaps [rsp+0x30], xmm3
0000710e9ebd5aee  vmovaps [rsp+0x40], xmm4
0000710e9ebd5af4  vmovaps [rsp+0x50], xmm5
0000710e9ebd5afa  vmovaps [rsp+0x60], xmm7
0000710e9ebd5b00  vmovaps [rsp+0x70], xmm8
0000710e9ebd5b06  vmovaps [rsp+0x80], xmm9
0000710e9ebd5b0f  vmovaps [rsp+0x90], xmm10
0000710e9ebd5b18  vmovaps [rsp+0xA0], xmm11
0000710e9ebd5b21  vmovaps [rsp+0xB0], xmm12
0000710e9ebd5b2a  vmovaps [rsp+0xC0], xmm13
0000710e9ebd5b33  vmovaps [rsp+0xD0], xmm14
0000710e9ebd5b3c  vmovaps [rsp+0xE0], xmm15
0000710e9ebd5b45  sub rsp, 0x30
0000710e9ebd5b49  movaps [rsp], xmm6
0000710e9ebd5b4d  movaps [rsp+0x10], xmm5
0000710e9ebd5b52  movaps [rsp+0x20], xmm1
0000710e9ebd5b57  lea rdi, [rsp]
0000710e9ebd5b5b  mov esi, 0x00
0000710e9ebd5b60  mov rax, 0x5DADAF7CF530
0000710e9ebd5b6a  call rax
0000710e9ebd5b6c  movaps xmm6, [rsp]
0000710e9ebd5b70  add rsp, 0x30
0000710e9ebd5b74  vmovaps xmm0, [rsp]
0000710e9ebd5b79  vmovaps xmm1, [rsp+0x10]
0000710e9ebd5b7f  vmovaps xmm2, [rsp+0x20]
0000710e9ebd5b85  vmovaps xmm3, [rsp+0x30]
0000710e9ebd5b8b  vmovaps xmm4, [rsp+0x40]
0000710e9ebd5b91  vmovaps xmm5, [rsp+0x50]
0000710e9ebd5b97  vmovaps xmm7, [rsp+0x60]
0000710e9ebd5b9d  vmovaps xmm8, [rsp+0x70]
0000710e9ebd5ba3  vmovaps xmm9, [rsp+0x80]
0000710e9ebd5bac  vmovaps xmm10, [rsp+0x90]
0000710e9ebd5bb5  vmovaps xmm11, [rsp+0xA0]
0000710e9ebd5bbe  vmovaps xmm12, [rsp+0xB0]
0000710e9ebd5bc7  vmovaps xmm13, [rsp+0xC0]
0000710e9ebd5bd0  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd5bd9  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd5be2  add rsp, 0xF0
0000710e9ebd5be9  pop r11
0000710e9ebd5beb  pop r10
0000710e9ebd5bed  pop r9
0000710e9ebd5bef  pop r8
0000710e9ebd5bf1  pop rsi
0000710e9ebd5bf2  pop rdi
0000710e9ebd5bf3  pop rdx
0000710e9ebd5bf4  pop rcx
0000710e9ebd5bf5  pop rax
0000710e9ebd5bf6  add rsp, 0x08
0000710e9ebd5bfa  jmp 0x0000710E9EBD2FBF
0000710e9ebd5bff  sub rsp, 0x08
0000710e9ebd5c03  push rax
0000710e9ebd5c04  push rcx
0000710e9ebd5c05  push rdx
0000710e9ebd5c06  push rdi
0000710e9ebd5c07  push rsi
0000710e9ebd5c08  push r8
0000710e9ebd5c0a  push r9
0000710e9ebd5c0c  push r10
0000710e9ebd5c0e  push r11
0000710e9ebd5c10  sub rsp, 0xF0
0000710e9ebd5c17  vmovaps [rsp], xmm0
0000710e9ebd5c1c  vmovaps [rsp+0x10], xmm2
0000710e9ebd5c22  vmovaps [rsp+0x20], xmm3
0000710e9ebd5c28  vmovaps [rsp+0x30], xmm4
0000710e9ebd5c2e  vmovaps [rsp+0x40], xmm5
0000710e9ebd5c34  vmovaps [rsp+0x50], xmm6
0000710e9ebd5c3a  vmovaps [rsp+0x60], xmm7
0000710e9ebd5c40  vmovaps [rsp+0x70], xmm8
0000710e9ebd5c46  vmovaps [rsp+0x80], xmm9
0000710e9ebd5c4f  vmovaps [rsp+0x90], xmm10
0000710e9ebd5c58  vmovaps [rsp+0xA0], xmm11
0000710e9ebd5c61  vmovaps [rsp+0xB0], xmm12
0000710e9ebd5c6a  vmovaps [rsp+0xC0], xmm13
0000710e9ebd5c73  vmovaps [rsp+0xD0], xmm14
0000710e9ebd5c7c  vmovaps [rsp+0xE0], xmm15
0000710e9ebd5c85  sub rsp, 0x30
0000710e9ebd5c89  movaps [rsp], xmm1
0000710e9ebd5c8d  movaps [rsp+0x10], xmm5
0000710e9ebd5c92  movaps [rsp+0x20], xmm13
0000710e9ebd5c98  lea rdi, [rsp]
0000710e9ebd5c9c  mov esi, 0x00
0000710e9ebd5ca1  mov rax, 0x5DADAF7CF530
0000710e9ebd5cab  call rax
0000710e9ebd5cad  movaps xmm1, [rsp]
0000710e9ebd5cb1  add rsp, 0x30
0000710e9ebd5cb5  vmovaps xmm0, [rsp]
0000710e9ebd5cba  vmovaps xmm2, [rsp+0x10]
0000710e9ebd5cc0  vmovaps xmm3, [rsp+0x20]
0000710e9ebd5cc6  vmovaps xmm4, [rsp+0x30]
0000710e9ebd5ccc  vmovaps xmm5, [rsp+0x40]
0000710e9ebd5cd2  vmovaps xmm6, [rsp+0x50]
0000710e9ebd5cd8  vmovaps xmm7, [rsp+0x60]
0000710e9ebd5cde  vmovaps xmm8, [rsp+0x70]
0000710e9ebd5ce4  vmovaps xmm9, [rsp+0x80]
0000710e9ebd5ced  vmovaps xmm10, [rsp+0x90]
0000710e9ebd5cf6  vmovaps xmm11, [rsp+0xA0]
0000710e9ebd5cff  vmovaps xmm12, [rsp+0xB0]
0000710e9ebd5d08  vmovaps xmm13, [rsp+0xC0]
0000710e9ebd5d11  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd5d1a  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd5d23  add rsp, 0xF0
0000710e9ebd5d2a  pop r11
0000710e9ebd5d2c  pop r10
0000710e9ebd5d2e  pop r9
0000710e9ebd5d30  pop r8
0000710e9ebd5d32  pop rsi
0000710e9ebd5d33  pop rdi
0000710e9ebd5d34  pop rdx
0000710e9ebd5d35  pop rcx
0000710e9ebd5d36  pop rax
0000710e9ebd5d37  add rsp, 0x08
0000710e9ebd5d3b  jmp 0x0000710E9EBD2FDD
0000710e9ebd5d40  sub rsp, 0x08
0000710e9ebd5d44  push rax
0000710e9ebd5d45  push rcx
0000710e9ebd5d46  push rdx
0000710e9ebd5d47  push rdi
0000710e9ebd5d48  push rsi
0000710e9ebd5d49  push r8
0000710e9ebd5d4b  push r9
0000710e9ebd5d4d  push r10
0000710e9ebd5d4f  push r11
0000710e9ebd5d51  sub rsp, 0xF0
0000710e9ebd5d58  vmovaps [rsp], xmm0
0000710e9ebd5d5d  vmovaps [rsp+0x10], xmm1
0000710e9ebd5d63  vmovaps [rsp+0x20], xmm2
0000710e9ebd5d69  vmovaps [rsp+0x30], xmm3
0000710e9ebd5d6f  vmovaps [rsp+0x40], xmm4
0000710e9ebd5d75  vmovaps [rsp+0x50], xmm6
0000710e9ebd5d7b  vmovaps [rsp+0x60], xmm7
0000710e9ebd5d81  vmovaps [rsp+0x70], xmm8
0000710e9ebd5d87  vmovaps [rsp+0x80], xmm9
0000710e9ebd5d90  vmovaps [rsp+0x90], xmm10
0000710e9ebd5d99  vmovaps [rsp+0xA0], xmm11
0000710e9ebd5da2  vmovaps [rsp+0xB0], xmm12
0000710e9ebd5dab  vmovaps [rsp+0xC0], xmm13
0000710e9ebd5db4  vmovaps [rsp+0xD0], xmm14
0000710e9ebd5dbd  vmovaps [rsp+0xE0], xmm15
0000710e9ebd5dc6  sub rsp, 0x30
0000710e9ebd5dca  movaps [rsp], xmm5
0000710e9ebd5dce  movaps [rsp+0x10], xmm2
0000710e9ebd5dd3  movaps [rsp+0x20], xmm13
0000710e9ebd5dd9  lea rdi, [rsp]
0000710e9ebd5ddd  mov esi, 0x00
0000710e9ebd5de2  mov rax, 0x5DADAF7CF530
0000710e9ebd5dec  call rax
0000710e9ebd5dee  movaps xmm5, [rsp]
0000710e9ebd5df2  add rsp, 0x30
0000710e9ebd5df6  vmovaps xmm0, [rsp]
0000710e9ebd5dfb  vmovaps xmm1, [rsp+0x10]
0000710e9ebd5e01  vmovaps xmm2, [rsp+0x20]
0000710e9ebd5e07  vmovaps xmm3, [rsp+0x30]
0000710e9ebd5e0d  vmovaps xmm4, [rsp+0x40]
0000710e9ebd5e13  vmovaps xmm6, [rsp+0x50]
0000710e9ebd5e19  vmovaps xmm7, [rsp+0x60]
0000710e9ebd5e1f  vmovaps xmm8, [rsp+0x70]
0000710e9ebd5e25  vmovaps xmm9, [rsp+0x80]
0000710e9ebd5e2e  vmovaps xmm10, [rsp+0x90]
0000710e9ebd5e37  vmovaps xmm11, [rsp+0xA0]
0000710e9ebd5e40  vmovaps xmm12, [rsp+0xB0]
0000710e9ebd5e49  vmovaps xmm13, [rsp+0xC0]
0000710e9ebd5e52  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd5e5b  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd5e64  add rsp, 0xF0
0000710e9ebd5e6b  pop r11
0000710e9ebd5e6d  pop r10
0000710e9ebd5e6f  pop r9
0000710e9ebd5e71  pop r8
0000710e9ebd5e73  pop rsi
0000710e9ebd5e74  pop rdi
0000710e9ebd5e75  pop rdx
0000710e9ebd5e76  pop rcx
0000710e9ebd5e77  pop rax
0000710e9ebd5e78  add rsp, 0x08
0000710e9ebd5e7c  jmp 0x0000710E9EBD3013
0000710e9ebd5e81  sub rsp, 0x08
0000710e9ebd5e85  push rax
0000710e9ebd5e86  push rcx
0000710e9ebd5e87  push rdx
0000710e9ebd5e88  push rdi
0000710e9ebd5e89  push rsi
0000710e9ebd5e8a  push r8
0000710e9ebd5e8c  push r9
0000710e9ebd5e8e  push r10
0000710e9ebd5e90  push r11
0000710e9ebd5e92  sub rsp, 0xF0
0000710e9ebd5e99  vmovaps [rsp], xmm0
0000710e9ebd5e9e  vmovaps [rsp+0x10], xmm1
0000710e9ebd5ea4  vmovaps [rsp+0x20], xmm2
0000710e9ebd5eaa  vmovaps [rsp+0x30], xmm3
0000710e9ebd5eb0  vmovaps [rsp+0x40], xmm4
0000710e9ebd5eb6  vmovaps [rsp+0x50], xmm5
0000710e9ebd5ebc  vmovaps [rsp+0x60], xmm6
0000710e9ebd5ec2  vmovaps [rsp+0x70], xmm7
0000710e9ebd5ec8  vmovaps [rsp+0x80], xmm8
0000710e9ebd5ed1  vmovaps [rsp+0x90], xmm9
0000710e9ebd5eda  vmovaps [rsp+0xA0], xmm10
0000710e9ebd5ee3  vmovaps [rsp+0xB0], xmm11
0000710e9ebd5eec  vmovaps [rsp+0xC0], xmm12
0000710e9ebd5ef5  vmovaps [rsp+0xD0], xmm14
0000710e9ebd5efe  vmovaps [rsp+0xE0], xmm15
0000710e9ebd5f07  sub rsp, 0x30
0000710e9ebd5f0b  movaps [rsp], xmm13
0000710e9ebd5f10  movaps [rsp+0x10], xmm10
0000710e9ebd5f16  movaps [rsp+0x20], xmm1
0000710e9ebd5f1b  lea rdi, [rsp]
0000710e9ebd5f1f  mov esi, 0x00
0000710e9ebd5f24  mov rax, 0x5DADAF7CF530
0000710e9ebd5f2e  call rax
0000710e9ebd5f30  movaps xmm13, [rsp]
0000710e9ebd5f35  add rsp, 0x30
0000710e9ebd5f39  vmovaps xmm0, [rsp]
0000710e9ebd5f3e  vmovaps xmm1, [rsp+0x10]
0000710e9ebd5f44  vmovaps xmm2, [rsp+0x20]
0000710e9ebd5f4a  vmovaps xmm3, [rsp+0x30]
0000710e9ebd5f50  vmovaps xmm4, [rsp+0x40]
0000710e9ebd5f56  vmovaps xmm5, [rsp+0x50]
0000710e9ebd5f5c  vmovaps xmm6, [rsp+0x60]
0000710e9ebd5f62  vmovaps xmm7, [rsp+0x70]
0000710e9ebd5f68  vmovaps xmm8, [rsp+0x80]
0000710e9ebd5f71  vmovaps xmm9, [rsp+0x90]
0000710e9ebd5f7a  vmovaps xmm10, [rsp+0xA0]
0000710e9ebd5f83  vmovaps xmm11, [rsp+0xB0]
0000710e9ebd5f8c  vmovaps xmm12, [rsp+0xC0]
0000710e9ebd5f95  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd5f9e  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd5fa7  add rsp, 0xF0
0000710e9ebd5fae  pop r11
0000710e9ebd5fb0  pop r10
0000710e9ebd5fb2  pop r9
0000710e9ebd5fb4  pop r8
0000710e9ebd5fb6  pop rsi
0000710e9ebd5fb7  pop rdi
0000710e9ebd5fb8  pop rdx
0000710e9ebd5fb9  pop rcx
0000710e9ebd5fba  pop rax
0000710e9ebd5fbb  add rsp, 0x08
0000710e9ebd5fbf  jmp 0x0000710E9EBD303C
0000710e9ebd5fc4  sub rsp, 0x08
0000710e9ebd5fc8  push rax
0000710e9ebd5fc9  push rcx
0000710e9ebd5fca  push rdx
0000710e9ebd5fcb  push rdi
0000710e9ebd5fcc  push rsi
0000710e9ebd5fcd  push r8
0000710e9ebd5fcf  push r9
0000710e9ebd5fd1  push r10
0000710e9ebd5fd3  push r11
0000710e9ebd5fd5  sub rsp, 0xF0
0000710e9ebd5fdc  vmovaps [rsp], xmm0
0000710e9ebd5fe1  vmovaps [rsp+0x10], xmm2
0000710e9ebd5fe7  vmovaps [rsp+0x20], xmm3
0000710e9ebd5fed  vmovaps [rsp+0x30], xmm4
0000710e9ebd5ff3  vmovaps [rsp+0x40], xmm5
0000710e9ebd5ff9  vmovaps [rsp+0x50], xmm6
0000710e9ebd5fff  vmovaps [rsp+0x60], xmm7
0000710e9ebd6005  vmovaps [rsp+0x70], xmm8
0000710e9ebd600b  vmovaps [rsp+0x80], xmm9
0000710e9ebd6014  vmovaps [rsp+0x90], xmm10
0000710e9ebd601d  vmovaps [rsp+0xA0], xmm11
0000710e9ebd6026  vmovaps [rsp+0xB0], xmm12
0000710e9ebd602f  vmovaps [rsp+0xC0], xmm13
0000710e9ebd6038  vmovaps [rsp+0xD0], xmm14
0000710e9ebd6041  vmovaps [rsp+0xE0], xmm15
0000710e9ebd604a  sub rsp, 0x30
0000710e9ebd604e  movaps [rsp], xmm1
0000710e9ebd6052  movaps [rsp+0x10], xmm15
0000710e9ebd6058  movaps [rsp+0x20], xmm10
0000710e9ebd605e  lea rdi, [rsp]
0000710e9ebd6062  mov esi, 0x00
0000710e9ebd6067  mov rax, 0x5DADAF7CF530
0000710e9ebd6071  call rax
0000710e9ebd6073  movaps xmm1, [rsp]
0000710e9ebd6077  add rsp, 0x30
0000710e9ebd607b  vmovaps xmm0, [rsp]
0000710e9ebd6080  vmovaps xmm2, [rsp+0x10]
0000710e9ebd6086  vmovaps xmm3, [rsp+0x20]
0000710e9ebd608c  vmovaps xmm4, [rsp+0x30]
0000710e9ebd6092  vmovaps xmm5, [rsp+0x40]
0000710e9ebd6098  vmovaps xmm6, [rsp+0x50]
0000710e9ebd609e  vmovaps xmm7, [rsp+0x60]
0000710e9ebd60a4  vmovaps xmm8, [rsp+0x70]
0000710e9ebd60aa  vmovaps xmm9, [rsp+0x80]
0000710e9ebd60b3  vmovaps xmm10, [rsp+0x90]
0000710e9ebd60bc  vmovaps xmm11, [rsp+0xA0]
0000710e9ebd60c5  vmovaps xmm12, [rsp+0xB0]
0000710e9ebd60ce  vmovaps xmm13, [rsp+0xC0]
0000710e9ebd60d7  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd60e0  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd60e9  add rsp, 0xF0
0000710e9ebd60f0  pop r11
0000710e9ebd60f2  pop r10
0000710e9ebd60f4  pop r9
0000710e9ebd60f6  pop r8
0000710e9ebd60f8  pop rsi
0000710e9ebd60f9  pop rdi
0000710e9ebd60fa  pop rdx
0000710e9ebd60fb  pop rcx
0000710e9ebd60fc  pop rax
0000710e9ebd60fd  add rsp, 0x08
0000710e9ebd6101  jmp 0x0000710E9EBD305B
0000710e9ebd6106  sub rsp, 0x08
0000710e9ebd610a  push rax
0000710e9ebd610b  push rcx
0000710e9ebd610c  push rdx
0000710e9ebd610d  push rdi
0000710e9ebd610e  push rsi
0000710e9ebd610f  push r8
0000710e9ebd6111  push r9
0000710e9ebd6113  push r10
0000710e9ebd6115  push r11
0000710e9ebd6117  sub rsp, 0xF0
0000710e9ebd611e  vmovaps [rsp], xmm0
0000710e9ebd6123  vmovaps [rsp+0x10], xmm1
0000710e9ebd6129  vmovaps [rsp+0x20], xmm2
0000710e9ebd612f  vmovaps [rsp+0x30], xmm3
0000710e9ebd6135  vmovaps [rsp+0x40], xmm4
0000710e9ebd613b  vmovaps [rsp+0x50], xmm5
0000710e9ebd6141  vmovaps [rsp+0x60], xmm6
0000710e9ebd6147  vmovaps [rsp+0x70], xmm7
0000710e9ebd614d  vmovaps [rsp+0x80], xmm8
0000710e9ebd6156  vmovaps [rsp+0x90], xmm9
0000710e9ebd615f  vmovaps [rsp+0xA0], xmm10
0000710e9ebd6168  vmovaps [rsp+0xB0], xmm11
0000710e9ebd6171  vmovaps [rsp+0xC0], xmm12
0000710e9ebd617a  vmovaps [rsp+0xD0], xmm13
0000710e9ebd6183  vmovaps [rsp+0xE0], xmm14
0000710e9ebd618c  sub rsp, 0x30
0000710e9ebd6190  movaps [rsp], xmm15
0000710e9ebd6195  movaps [rsp+0x10], xmm10
0000710e9ebd619b  movaps [rsp+0x20], xmm11
0000710e9ebd61a1  lea rdi, [rsp]
0000710e9ebd61a5  mov esi, 0x00
0000710e9ebd61aa  mov rax, 0x5DADAF7CF530
0000710e9ebd61b4  call rax
0000710e9ebd61b6  movaps xmm15, [rsp]
0000710e9ebd61bb  add rsp, 0x30
0000710e9ebd61bf  vmovaps xmm0, [rsp]
0000710e9ebd61c4  vmovaps xmm1, [rsp+0x10]
0000710e9ebd61ca  vmovaps xmm2, [rsp+0x20]
0000710e9ebd61d0  vmovaps xmm3, [rsp+0x30]
0000710e9ebd61d6  vmovaps xmm4, [rsp+0x40]
0000710e9ebd61dc  vmovaps xmm5, [rsp+0x50]
0000710e9ebd61e2  vmovaps xmm6, [rsp+0x60]
0000710e9ebd61e8  vmovaps xmm7, [rsp+0x70]
0000710e9ebd61ee  vmovaps xmm8, [rsp+0x80]
0000710e9ebd61f7  vmovaps xmm9, [rsp+0x90]
0000710e9ebd6200  vmovaps xmm10, [rsp+0xA0]
0000710e9ebd6209  vmovaps xmm11, [rsp+0xB0]
0000710e9ebd6212  vmovaps xmm12, [rsp+0xC0]
0000710e9ebd621b  vmovaps xmm13, [rsp+0xD0]
0000710e9ebd6224  vmovaps xmm14, [rsp+0xE0]
0000710e9ebd622d  add rsp, 0xF0
0000710e9ebd6234  pop r11
0000710e9ebd6236  pop r10
0000710e9ebd6238  pop r9
0000710e9ebd623a  pop r8
0000710e9ebd623c  pop rsi
0000710e9ebd623d  pop rdi
0000710e9ebd623e  pop rdx
0000710e9ebd623f  pop rcx
0000710e9ebd6240  pop rax
0000710e9ebd6241  add rsp, 0x08
0000710e9ebd6245  jmp 0x0000710E9EBD307E
0000710e9ebd624a  sub rsp, 0x08
0000710e9ebd624e  push rax
0000710e9ebd624f  push rcx
0000710e9ebd6250  push rdx
0000710e9ebd6251  push rdi
0000710e9ebd6252  push rsi
0000710e9ebd6253  push r8
0000710e9ebd6255  push r9
0000710e9ebd6257  push r10
0000710e9ebd6259  push r11
0000710e9ebd625b  sub rsp, 0xF0
0000710e9ebd6262  vmovaps [rsp], xmm0
0000710e9ebd6267  vmovaps [rsp+0x10], xmm1
0000710e9ebd626d  vmovaps [rsp+0x20], xmm2
0000710e9ebd6273  vmovaps [rsp+0x30], xmm3
0000710e9ebd6279  vmovaps [rsp+0x40], xmm4
0000710e9ebd627f  vmovaps [rsp+0x50], xmm5
0000710e9ebd6285  vmovaps [rsp+0x60], xmm6
0000710e9ebd628b  vmovaps [rsp+0x70], xmm7
0000710e9ebd6291  vmovaps [rsp+0x80], xmm8
0000710e9ebd629a  vmovaps [rsp+0x90], xmm9
0000710e9ebd62a3  vmovaps [rsp+0xA0], xmm11
0000710e9ebd62ac  vmovaps [rsp+0xB0], xmm12
0000710e9ebd62b5  vmovaps [rsp+0xC0], xmm13
0000710e9ebd62be  vmovaps [rsp+0xD0], xmm14
0000710e9ebd62c7  vmovaps [rsp+0xE0], xmm15
0000710e9ebd62d0  sub rsp, 0x30
0000710e9ebd62d4  movaps [rsp], xmm10
0000710e9ebd62d9  movaps [rsp+0x10], xmm2
0000710e9ebd62de  movaps [rsp+0x20], xmm11
0000710e9ebd62e4  lea rdi, [rsp]
0000710e9ebd62e8  mov esi, 0x00
0000710e9ebd62ed  mov rax, 0x5DADAF7CF530
0000710e9ebd62f7  call rax
0000710e9ebd62f9  movaps xmm10, [rsp]
0000710e9ebd62fe  add rsp, 0x30
0000710e9ebd6302  vmovaps xmm0, [rsp]
0000710e9ebd6307  vmovaps xmm1, [rsp+0x10]
0000710e9ebd630d  vmovaps xmm2, [rsp+0x20]
0000710e9ebd6313  vmovaps xmm3, [rsp+0x30]
0000710e9ebd6319  vmovaps xmm4, [rsp+0x40]
0000710e9ebd631f  vmovaps xmm5, [rsp+0x50]
0000710e9ebd6325  vmovaps xmm6, [rsp+0x60]
0000710e9ebd632b  vmovaps xmm7, [rsp+0x70]
0000710e9ebd6331  vmovaps xmm8, [rsp+0x80]
0000710e9ebd633a  vmovaps xmm9, [rsp+0x90]
0000710e9ebd6343  vmovaps xmm11, [rsp+0xA0]
0000710e9ebd634c  vmovaps xmm12, [rsp+0xB0]
0000710e9ebd6355  vmovaps xmm13, [rsp+0xC0]
0000710e9ebd635e  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd6367  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd6370  add rsp, 0xF0
0000710e9ebd6377  pop r11
0000710e9ebd6379  pop r10
0000710e9ebd637b  pop r9
0000710e9ebd637d  pop r8
0000710e9ebd637f  pop rsi
0000710e9ebd6380  pop rdi
0000710e9ebd6381  pop rdx
0000710e9ebd6382  pop rcx
0000710e9ebd6383  pop rax
0000710e9ebd6384  add rsp, 0x08
0000710e9ebd6388  jmp 0x0000710E9EBD30B6
0000710e9ebd638d  sub rsp, 0x08
0000710e9ebd6391  push rax
0000710e9ebd6392  push rcx
0000710e9ebd6393  push rdx
0000710e9ebd6394  push rdi
0000710e9ebd6395  push rsi
0000710e9ebd6396  push r8
0000710e9ebd6398  push r9
0000710e9ebd639a  push r10
0000710e9ebd639c  push r11
0000710e9ebd639e  sub rsp, 0xF0
0000710e9ebd63a5  vmovaps [rsp], xmm0
0000710e9ebd63aa  vmovaps [rsp+0x10], xmm1
0000710e9ebd63b0  vmovaps [rsp+0x20], xmm2
0000710e9ebd63b6  vmovaps [rsp+0x30], xmm3
0000710e9ebd63bc  vmovaps [rsp+0x40], xmm4
0000710e9ebd63c2  vmovaps [rsp+0x50], xmm5
0000710e9ebd63c8  vmovaps [rsp+0x60], xmm6
0000710e9ebd63ce  vmovaps [rsp+0x70], xmm7
0000710e9ebd63d4  vmovaps [rsp+0x80], xmm8
0000710e9ebd63dd  vmovaps [rsp+0x90], xmm9
0000710e9ebd63e6  vmovaps [rsp+0xA0], xmm10
0000710e9ebd63ef  vmovaps [rsp+0xB0], xmm12
0000710e9ebd63f8  vmovaps [rsp+0xC0], xmm13
0000710e9ebd6401  vmovaps [rsp+0xD0], xmm14
0000710e9ebd640a  vmovaps [rsp+0xE0], xmm15
0000710e9ebd6413  sub rsp, 0x30
0000710e9ebd6417  movaps [rsp], xmm11
0000710e9ebd641c  movaps [rsp+0x10], xmm2
0000710e9ebd6421  movaps [rsp+0x20], xmm1
0000710e9ebd6426  lea rdi, [rsp]
0000710e9ebd642a  mov esi, 0x00
0000710e9ebd642f  mov rax, 0x5DADAF7CF530
0000710e9ebd6439  call rax
0000710e9ebd643b  movaps xmm11, [rsp]
0000710e9ebd6440  add rsp, 0x30
0000710e9ebd6444  vmovaps xmm0, [rsp]
0000710e9ebd6449  vmovaps xmm1, [rsp+0x10]
0000710e9ebd644f  vmovaps xmm2, [rsp+0x20]
0000710e9ebd6455  vmovaps xmm3, [rsp+0x30]
0000710e9ebd645b  vmovaps xmm4, [rsp+0x40]
0000710e9ebd6461  vmovaps xmm5, [rsp+0x50]
0000710e9ebd6467  vmovaps xmm6, [rsp+0x60]
0000710e9ebd646d  vmovaps xmm7, [rsp+0x70]
0000710e9ebd6473  vmovaps xmm8, [rsp+0x80]
0000710e9ebd647c  vmovaps xmm9, [rsp+0x90]
0000710e9ebd6485  vmovaps xmm10, [rsp+0xA0]
0000710e9ebd648e  vmovaps xmm12, [rsp+0xB0]
0000710e9ebd6497  vmovaps xmm13, [rsp+0xC0]
0000710e9ebd64a0  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd64a9  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd64b2  add rsp, 0xF0
0000710e9ebd64b9  pop r11
0000710e9ebd64bb  pop r10
0000710e9ebd64bd  pop r9
0000710e9ebd64bf  pop r8
0000710e9ebd64c1  pop rsi
0000710e9ebd64c2  pop rdi
0000710e9ebd64c3  pop rdx
0000710e9ebd64c4  pop rcx
0000710e9ebd64c5  pop rax
0000710e9ebd64c6  add rsp, 0x08
0000710e9ebd64ca  jmp 0x0000710E9EBD30F2
0000710e9ebd64cf  sub rsp, 0x08
0000710e9ebd64d3  push rax
0000710e9ebd64d4  push rcx
0000710e9ebd64d5  push rdx
0000710e9ebd64d6  push rdi
0000710e9ebd64d7  push rsi
0000710e9ebd64d8  push r8
0000710e9ebd64da  push r9
0000710e9ebd64dc  push r10
0000710e9ebd64de  push r11
0000710e9ebd64e0  sub rsp, 0xF0
0000710e9ebd64e7  vmovaps [rsp], xmm0
0000710e9ebd64ec  vmovaps [rsp+0x10], xmm2
0000710e9ebd64f2  vmovaps [rsp+0x20], xmm3
0000710e9ebd64f8  vmovaps [rsp+0x30], xmm4
0000710e9ebd64fe  vmovaps [rsp+0x40], xmm5
0000710e9ebd6504  vmovaps [rsp+0x50], xmm6
0000710e9ebd650a  vmovaps [rsp+0x60], xmm7
0000710e9ebd6510  vmovaps [rsp+0x70], xmm8
0000710e9ebd6516  vmovaps [rsp+0x80], xmm9
0000710e9ebd651f  vmovaps [rsp+0x90], xmm10
0000710e9ebd6528  vmovaps [rsp+0xA0], xmm11
0000710e9ebd6531  vmovaps [rsp+0xB0], xmm12
0000710e9ebd653a  vmovaps [rsp+0xC0], xmm13
0000710e9ebd6543  vmovaps [rsp+0xD0], xmm14
0000710e9ebd654c  vmovaps [rsp+0xE0], xmm15
0000710e9ebd6555  sub rsp, 0x30
0000710e9ebd6559  movaps [rsp], xmm1
0000710e9ebd655d  movaps [rsp+0x10], xmm14
0000710e9ebd6563  movaps [rsp+0x20], xmm6
0000710e9ebd6568  lea rdi, [rsp]
0000710e9ebd656c  mov esi, 0x00
0000710e9ebd6571  mov rax, 0x5DADAF7CF530
0000710e9ebd657b  call rax
0000710e9ebd657d  movaps xmm1, [rsp]
0000710e9ebd6581  add rsp, 0x30
0000710e9ebd6585  vmovaps xmm0, [rsp]
0000710e9ebd658a  vmovaps xmm2, [rsp+0x10]
0000710e9ebd6590  vmovaps xmm3, [rsp+0x20]
0000710e9ebd6596  vmovaps xmm4, [rsp+0x30]
0000710e9ebd659c  vmovaps xmm5, [rsp+0x40]
0000710e9ebd65a2  vmovaps xmm6, [rsp+0x50]
0000710e9ebd65a8  vmovaps xmm7, [rsp+0x60]
0000710e9ebd65ae  vmovaps xmm8, [rsp+0x70]
0000710e9ebd65b4  vmovaps xmm9, [rsp+0x80]
0000710e9ebd65bd  vmovaps xmm10, [rsp+0x90]
0000710e9ebd65c6  vmovaps xmm11, [rsp+0xA0]
0000710e9ebd65cf  vmovaps xmm12, [rsp+0xB0]
0000710e9ebd65d8  vmovaps xmm13, [rsp+0xC0]
0000710e9ebd65e1  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd65ea  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd65f3  add rsp, 0xF0
0000710e9ebd65fa  pop r11
0000710e9ebd65fc  pop r10
0000710e9ebd65fe  pop r9
0000710e9ebd6600  pop r8
0000710e9ebd6602  pop rsi
0000710e9ebd6603  pop rdi
0000710e9ebd6604  pop rdx
0000710e9ebd6605  pop rcx
0000710e9ebd6606  pop rax
0000710e9ebd6607  add rsp, 0x08
0000710e9ebd660b  jmp 0x0000710E9EBD310B
0000710e9ebd6610  sub rsp, 0x08
0000710e9ebd6614  push rax
0000710e9ebd6615  push rcx
0000710e9ebd6616  push rdx
0000710e9ebd6617  push rdi
0000710e9ebd6618  push rsi
0000710e9ebd6619  push r8
0000710e9ebd661b  push r9
0000710e9ebd661d  push r10
0000710e9ebd661f  push r11
0000710e9ebd6621  sub rsp, 0xF0
0000710e9ebd6628  vmovaps [rsp], xmm0
0000710e9ebd662d  vmovaps [rsp+0x10], xmm1
0000710e9ebd6633  vmovaps [rsp+0x20], xmm2
0000710e9ebd6639  vmovaps [rsp+0x30], xmm3
0000710e9ebd663f  vmovaps [rsp+0x40], xmm4
0000710e9ebd6645  vmovaps [rsp+0x50], xmm5
0000710e9ebd664b  vmovaps [rsp+0x60], xmm6
0000710e9ebd6651  vmovaps [rsp+0x70], xmm7
0000710e9ebd6657  vmovaps [rsp+0x80], xmm8
0000710e9ebd6660  vmovaps [rsp+0x90], xmm9
0000710e9ebd6669  vmovaps [rsp+0xA0], xmm10
0000710e9ebd6672  vmovaps [rsp+0xB0], xmm11
0000710e9ebd667b  vmovaps [rsp+0xC0], xmm12
0000710e9ebd6684  vmovaps [rsp+0xD0], xmm13
0000710e9ebd668d  vmovaps [rsp+0xE0], xmm14
0000710e9ebd6696  sub rsp, 0x30
0000710e9ebd669a  movaps [rsp], xmm15
0000710e9ebd669f  movaps [rsp+0x10], xmm14
0000710e9ebd66a5  movaps [rsp+0x20], xmm5
0000710e9ebd66aa  lea rdi, [rsp]
0000710e9ebd66ae  mov esi, 0x00
0000710e9ebd66b3  mov rax, 0x5DADAF7CF530
0000710e9ebd66bd  call rax
0000710e9ebd66bf  movaps xmm15, [rsp]
0000710e9ebd66c4  add rsp, 0x30
0000710e9ebd66c8  vmovaps xmm0, [rsp]
0000710e9ebd66cd  vmovaps xmm1, [rsp+0x10]
0000710e9ebd66d3  vmovaps xmm2, [rsp+0x20]
0000710e9ebd66d9  vmovaps xmm3, [rsp+0x30]
0000710e9ebd66df  vmovaps xmm4, [rsp+0x40]
0000710e9ebd66e5  vmovaps xmm5, [rsp+0x50]
0000710e9ebd66eb  vmovaps xmm6, [rsp+0x60]
0000710e9ebd66f1  vmovaps xmm7, [rsp+0x70]
0000710e9ebd66f7  vmovaps xmm8, [rsp+0x80]
0000710e9ebd6700  vmovaps xmm9, [rsp+0x90]
0000710e9ebd6709  vmovaps xmm10, [rsp+0xA0]
0000710e9ebd6712  vmovaps xmm11, [rsp+0xB0]
0000710e9ebd671b  vmovaps xmm12, [rsp+0xC0]
0000710e9ebd6724  vmovaps xmm13, [rsp+0xD0]
0000710e9ebd672d  vmovaps xmm14, [rsp+0xE0]
0000710e9ebd6736  add rsp, 0xF0
0000710e9ebd673d  pop r11
0000710e9ebd673f  pop r10
0000710e9ebd6741  pop r9
0000710e9ebd6743  pop r8
0000710e9ebd6745  pop rsi
0000710e9ebd6746  pop rdi
0000710e9ebd6747  pop rdx
0000710e9ebd6748  pop rcx
0000710e9ebd6749  pop rax
0000710e9ebd674a  add rsp, 0x08
0000710e9ebd674e  jmp 0x0000710E9EBD312B
0000710e9ebd6753  sub rsp, 0x08
0000710e9ebd6757  push rax
0000710e9ebd6758  push rcx
0000710e9ebd6759  push rdx
0000710e9ebd675a  push rdi
0000710e9ebd675b  push rsi
0000710e9ebd675c  push r8
0000710e9ebd675e  push r9
0000710e9ebd6760  push r10
0000710e9ebd6762  push r11
0000710e9ebd6764  sub rsp, 0xF0
0000710e9ebd676b  vmovaps [rsp], xmm0
0000710e9ebd6770  vmovaps [rsp+0x10], xmm1
0000710e9ebd6776  vmovaps [rsp+0x20], xmm2
0000710e9ebd677c  vmovaps [rsp+0x30], xmm3
0000710e9ebd6782  vmovaps [rsp+0x40], xmm4
0000710e9ebd6788  vmovaps [rsp+0x50], xmm5
0000710e9ebd678e  vmovaps [rsp+0x60], xmm7
0000710e9ebd6794  vmovaps [rsp+0x70], xmm8
0000710e9ebd679a  vmovaps [rsp+0x80], xmm9
0000710e9ebd67a3  vmovaps [rsp+0x90], xmm10
0000710e9ebd67ac  vmovaps [rsp+0xA0], xmm11
0000710e9ebd67b5  vmovaps [rsp+0xB0], xmm12
0000710e9ebd67be  vmovaps [rsp+0xC0], xmm13
0000710e9ebd67c7  vmovaps [rsp+0xD0], xmm14
0000710e9ebd67d0  vmovaps [rsp+0xE0], xmm15
0000710e9ebd67d9  sub rsp, 0x30
0000710e9ebd67dd  movaps [rsp], xmm6
0000710e9ebd67e1  movaps [rsp+0x10], xmm9
0000710e9ebd67e7  movaps [rsp+0x20], xmm14
0000710e9ebd67ed  lea rdi, [rsp]
0000710e9ebd67f1  mov esi, 0x00
0000710e9ebd67f6  mov rax, 0x5DADAF7CF530
0000710e9ebd6800  call rax
0000710e9ebd6802  movaps xmm6, [rsp]
0000710e9ebd6806  add rsp, 0x30
0000710e9ebd680a  vmovaps xmm0, [rsp]
0000710e9ebd680f  vmovaps xmm1, [rsp+0x10]
0000710e9ebd6815  vmovaps xmm2, [rsp+0x20]
0000710e9ebd681b  vmovaps xmm3, [rsp+0x30]
0000710e9ebd6821  vmovaps xmm4, [rsp+0x40]
0000710e9ebd6827  vmovaps xmm5, [rsp+0x50]
0000710e9ebd682d  vmovaps xmm7, [rsp+0x60]
0000710e9ebd6833  vmovaps xmm8, [rsp+0x70]
0000710e9ebd6839  vmovaps xmm9, [rsp+0x80]
0000710e9ebd6842  vmovaps xmm10, [rsp+0x90]
0000710e9ebd684b  vmovaps xmm11, [rsp+0xA0]
0000710e9ebd6854  vmovaps xmm12, [rsp+0xB0]
0000710e9ebd685d  vmovaps xmm13, [rsp+0xC0]
0000710e9ebd6866  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd686f  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd6878  add rsp, 0xF0
0000710e9ebd687f  pop r11
0000710e9ebd6881  pop r10
0000710e9ebd6883  pop r9
0000710e9ebd6885  pop r8
0000710e9ebd6887  pop rsi
0000710e9ebd6888  pop rdi
0000710e9ebd6889  pop rdx
0000710e9ebd688a  pop rcx
0000710e9ebd688b  pop rax
0000710e9ebd688c  add rsp, 0x08
0000710e9ebd6890  jmp 0x0000710E9EBD3153
0000710e9ebd6895  sub rsp, 0x08
0000710e9ebd6899  push rax
0000710e9ebd689a  push rcx
0000710e9ebd689b  push rdx
0000710e9ebd689c  push rdi
0000710e9ebd689d  push rsi
0000710e9ebd689e  push r8
0000710e9ebd68a0  push r9
0000710e9ebd68a2  push r10
0000710e9ebd68a4  push r11
0000710e9ebd68a6  sub rsp, 0xF0
0000710e9ebd68ad  vmovaps [rsp], xmm0
0000710e9ebd68b2  vmovaps [rsp+0x10], xmm1
0000710e9ebd68b8  vmovaps [rsp+0x20], xmm2
0000710e9ebd68be  vmovaps [rsp+0x30], xmm3
0000710e9ebd68c4  vmovaps [rsp+0x40], xmm4
0000710e9ebd68ca  vmovaps [rsp+0x50], xmm5
0000710e9ebd68d0  vmovaps [rsp+0x60], xmm6
0000710e9ebd68d6  vmovaps [rsp+0x70], xmm7
0000710e9ebd68dc  vmovaps [rsp+0x80], xmm8
0000710e9ebd68e5  vmovaps [rsp+0x90], xmm9
0000710e9ebd68ee  vmovaps [rsp+0xA0], xmm10
0000710e9ebd68f7  vmovaps [rsp+0xB0], xmm11
0000710e9ebd6900  vmovaps [rsp+0xC0], xmm12
0000710e9ebd6909  vmovaps [rsp+0xD0], xmm13
0000710e9ebd6912  vmovaps [rsp+0xE0], xmm15
0000710e9ebd691b  sub rsp, 0x30
0000710e9ebd691f  movaps [rsp], xmm14
0000710e9ebd6924  movaps [rsp+0x10], xmm9
0000710e9ebd692a  movaps [rsp+0x20], xmm13
0000710e9ebd6930  lea rdi, [rsp]
0000710e9ebd6934  mov esi, 0x00
0000710e9ebd6939  mov rax, 0x5DADAF7CF530
0000710e9ebd6943  call rax
0000710e9ebd6945  movaps xmm14, [rsp]
0000710e9ebd694a  add rsp, 0x30
0000710e9ebd694e  vmovaps xmm0, [rsp]
0000710e9ebd6953  vmovaps xmm1, [rsp+0x10]
0000710e9ebd6959  vmovaps xmm2, [rsp+0x20]
0000710e9ebd695f  vmovaps xmm3, [rsp+0x30]
0000710e9ebd6965  vmovaps xmm4, [rsp+0x40]
0000710e9ebd696b  vmovaps xmm5, [rsp+0x50]
0000710e9ebd6971  vmovaps xmm6, [rsp+0x60]
0000710e9ebd6977  vmovaps xmm7, [rsp+0x70]
0000710e9ebd697d  vmovaps xmm8, [rsp+0x80]
0000710e9ebd6986  vmovaps xmm9, [rsp+0x90]
0000710e9ebd698f  vmovaps xmm10, [rsp+0xA0]
0000710e9ebd6998  vmovaps xmm11, [rsp+0xB0]
0000710e9ebd69a1  vmovaps xmm12, [rsp+0xC0]
0000710e9ebd69aa  vmovaps xmm13, [rsp+0xD0]
0000710e9ebd69b3  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd69bc  add rsp, 0xF0
0000710e9ebd69c3  pop r11
0000710e9ebd69c5  pop r10
0000710e9ebd69c7  pop r9
0000710e9ebd69c9  pop r8
0000710e9ebd69cb  pop rsi
0000710e9ebd69cc  pop rdi
0000710e9ebd69cd  pop rdx
0000710e9ebd69ce  pop rcx
0000710e9ebd69cf  pop rax
0000710e9ebd69d0  add rsp, 0x08
0000710e9ebd69d4  jmp 0x0000710E9EBD3176
0000710e9ebd69d9  sub rsp, 0x08
0000710e9ebd69dd  push rax
0000710e9ebd69de  push rcx
0000710e9ebd69df  push rdx
0000710e9ebd69e0  push rdi
0000710e9ebd69e1  push rsi
0000710e9ebd69e2  push r8
0000710e9ebd69e4  push r9
0000710e9ebd69e6  push r10
0000710e9ebd69e8  push r11
0000710e9ebd69ea  sub rsp, 0xF0
0000710e9ebd69f1  vmovaps [rsp], xmm0
0000710e9ebd69f6  vmovaps [rsp+0x10], xmm1
0000710e9ebd69fc  vmovaps [rsp+0x20], xmm2
0000710e9ebd6a02  vmovaps [rsp+0x30], xmm3
0000710e9ebd6a08  vmovaps [rsp+0x40], xmm4
0000710e9ebd6a0e  vmovaps [rsp+0x50], xmm5
0000710e9ebd6a14  vmovaps [rsp+0x60], xmm6
0000710e9ebd6a1a  vmovaps [rsp+0x70], xmm7
0000710e9ebd6a20  vmovaps [rsp+0x80], xmm8
0000710e9ebd6a29  vmovaps [rsp+0x90], xmm9
0000710e9ebd6a32  vmovaps [rsp+0xA0], xmm10
0000710e9ebd6a3b  vmovaps [rsp+0xB0], xmm11
0000710e9ebd6a44  vmovaps [rsp+0xC0], xmm12
0000710e9ebd6a4d  vmovaps [rsp+0xD0], xmm14
0000710e9ebd6a56  vmovaps [rsp+0xE0], xmm15
0000710e9ebd6a5f  sub rsp, 0x30
0000710e9ebd6a63  movaps [rsp], xmm13
0000710e9ebd6a68  movaps [rsp+0x10], xmm9
0000710e9ebd6a6e  movaps [rsp+0x20], xmm10
0000710e9ebd6a74  lea rdi, [rsp]
0000710e9ebd6a78  mov esi, 0x00
0000710e9ebd6a7d  mov rax, 0x5DADAF7CF530
0000710e9ebd6a87  call rax
0000710e9ebd6a89  movaps xmm13, [rsp]
0000710e9ebd6a8e  add rsp, 0x30
0000710e9ebd6a92  vmovaps xmm0, [rsp]
0000710e9ebd6a97  vmovaps xmm1, [rsp+0x10]
0000710e9ebd6a9d  vmovaps xmm2, [rsp+0x20]
0000710e9ebd6aa3  vmovaps xmm3, [rsp+0x30]
0000710e9ebd6aa9  vmovaps xmm4, [rsp+0x40]
0000710e9ebd6aaf  vmovaps xmm5, [rsp+0x50]
0000710e9ebd6ab5  vmovaps xmm6, [rsp+0x60]
0000710e9ebd6abb  vmovaps xmm7, [rsp+0x70]
0000710e9ebd6ac1  vmovaps xmm8, [rsp+0x80]
0000710e9ebd6aca  vmovaps xmm9, [rsp+0x90]
0000710e9ebd6ad3  vmovaps xmm10, [rsp+0xA0]
0000710e9ebd6adc  vmovaps xmm11, [rsp+0xB0]
0000710e9ebd6ae5  vmovaps xmm12, [rsp+0xC0]
0000710e9ebd6aee  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd6af7  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd6b00  add rsp, 0xF0
0000710e9ebd6b07  pop r11
0000710e9ebd6b09  pop r10
0000710e9ebd6b0b  pop r9
0000710e9ebd6b0d  pop r8
0000710e9ebd6b0f  pop rsi
0000710e9ebd6b10  pop rdi
0000710e9ebd6b11  pop rdx
0000710e9ebd6b12  pop rcx
0000710e9ebd6b13  pop rax
0000710e9ebd6b14  add rsp, 0x08
0000710e9ebd6b18  jmp 0x0000710E9EBD3196
0000710e9ebd6b1d  call 0x0000710E9EA0AFE0
0000710e9ebd6b22  jmp 0x0000710E9EBD31EB
0000710e9ebd6b27  sub rsp, 0x08
0000710e9ebd6b2b  push rax
0000710e9ebd6b2c  push rcx
0000710e9ebd6b2d  push rdx
0000710e9ebd6b2e  push rdi
0000710e9ebd6b2f  push rsi
0000710e9ebd6b30  push r8
0000710e9ebd6b32  push r9
0000710e9ebd6b34  push r10
0000710e9ebd6b36  push r11
0000710e9ebd6b38  sub rsp, 0xF0
0000710e9ebd6b3f  vmovaps [rsp], xmm0
0000710e9ebd6b44  vmovaps [rsp+0x10], xmm1
0000710e9ebd6b4a  vmovaps [rsp+0x20], xmm2
0000710e9ebd6b50  vmovaps [rsp+0x30], xmm3
0000710e9ebd6b56  vmovaps [rsp+0x40], xmm4
0000710e9ebd6b5c  vmovaps [rsp+0x50], xmm5
0000710e9ebd6b62  vmovaps [rsp+0x60], xmm6
0000710e9ebd6b68  vmovaps [rsp+0x70], xmm7
0000710e9ebd6b6e  vmovaps [rsp+0x80], xmm8
0000710e9ebd6b77  vmovaps [rsp+0x90], xmm10
0000710e9ebd6b80  vmovaps [rsp+0xA0], xmm11
0000710e9ebd6b89  vmovaps [rsp+0xB0], xmm12
0000710e9ebd6b92  vmovaps [rsp+0xC0], xmm13
0000710e9ebd6b9b  vmovaps [rsp+0xD0], xmm14
0000710e9ebd6ba4  vmovaps [rsp+0xE0], xmm15
0000710e9ebd6bad  sub rsp, 0x30
0000710e9ebd6bb1  movaps [rsp], xmm9
0000710e9ebd6bb6  movaps [rsp+0x10], xmm8
0000710e9ebd6bbc  movaps [rsp+0x20], xmm10
0000710e9ebd6bc2  lea rdi, [rsp]
0000710e9ebd6bc6  mov esi, 0x00
0000710e9ebd6bcb  mov rax, 0x5DADAF7CF530
0000710e9ebd6bd5  call rax
0000710e9ebd6bd7  movaps xmm9, [rsp]
0000710e9ebd6bdc  add rsp, 0x30
0000710e9ebd6be0  vmovaps xmm0, [rsp]
0000710e9ebd6be5  vmovaps xmm1, [rsp+0x10]
0000710e9ebd6beb  vmovaps xmm2, [rsp+0x20]
0000710e9ebd6bf1  vmovaps xmm3, [rsp+0x30]
0000710e9ebd6bf7  vmovaps xmm4, [rsp+0x40]
0000710e9ebd6bfd  vmovaps xmm5, [rsp+0x50]
0000710e9ebd6c03  vmovaps xmm6, [rsp+0x60]
0000710e9ebd6c09  vmovaps xmm7, [rsp+0x70]
0000710e9ebd6c0f  vmovaps xmm8, [rsp+0x80]
0000710e9ebd6c18  vmovaps xmm10, [rsp+0x90]
0000710e9ebd6c21  vmovaps xmm11, [rsp+0xA0]
0000710e9ebd6c2a  vmovaps xmm12, [rsp+0xB0]
0000710e9ebd6c33  vmovaps xmm13, [rsp+0xC0]
0000710e9ebd6c3c  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd6c45  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd6c4e  add rsp, 0xF0
0000710e9ebd6c55  pop r11
0000710e9ebd6c57  pop r10
0000710e9ebd6c59  pop r9
0000710e9ebd6c5b  pop r8
0000710e9ebd6c5d  pop rsi
0000710e9ebd6c5e  pop rdi
0000710e9ebd6c5f  pop rdx
0000710e9ebd6c60  pop rcx
0000710e9ebd6c61  pop rax
0000710e9ebd6c62  add rsp, 0x08
0000710e9ebd6c66  jmp 0x0000710E9EBD321C
0000710e9ebd6c6b  sub rsp, 0x08
0000710e9ebd6c6f  push rax
0000710e9ebd6c70  push rcx
0000710e9ebd6c71  push rdx
0000710e9ebd6c72  push rdi
0000710e9ebd6c73  push rsi
0000710e9ebd6c74  push r8
0000710e9ebd6c76  push r9
0000710e9ebd6c78  push r10
0000710e9ebd6c7a  push r11
0000710e9ebd6c7c  sub rsp, 0xF0
0000710e9ebd6c83  vmovaps [rsp], xmm0
0000710e9ebd6c88  vmovaps [rsp+0x10], xmm1
0000710e9ebd6c8e  vmovaps [rsp+0x20], xmm2
0000710e9ebd6c94  vmovaps [rsp+0x30], xmm3
0000710e9ebd6c9a  vmovaps [rsp+0x40], xmm4
0000710e9ebd6ca0  vmovaps [rsp+0x50], xmm5
0000710e9ebd6ca6  vmovaps [rsp+0x60], xmm6
0000710e9ebd6cac  vmovaps [rsp+0x70], xmm7
0000710e9ebd6cb2  vmovaps [rsp+0x80], xmm8
0000710e9ebd6cbb  vmovaps [rsp+0x90], xmm9
0000710e9ebd6cc4  vmovaps [rsp+0xA0], xmm11
0000710e9ebd6ccd  vmovaps [rsp+0xB0], xmm12
0000710e9ebd6cd6  vmovaps [rsp+0xC0], xmm13
0000710e9ebd6cdf  vmovaps [rsp+0xD0], xmm14
0000710e9ebd6ce8  vmovaps [rsp+0xE0], xmm15
0000710e9ebd6cf1  sub rsp, 0x30
0000710e9ebd6cf5  movaps [rsp], xmm10
0000710e9ebd6cfa  movaps [rsp+0x10], xmm1
0000710e9ebd6cff  movaps [rsp+0x20], xmm11
0000710e9ebd6d05  lea rdi, [rsp]
0000710e9ebd6d09  mov esi, 0x00
0000710e9ebd6d0e  mov rax, 0x5DADAF7CF530
0000710e9ebd6d18  call rax
0000710e9ebd6d1a  movaps xmm10, [rsp]
0000710e9ebd6d1f  add rsp, 0x30
0000710e9ebd6d23  vmovaps xmm0, [rsp]
0000710e9ebd6d28  vmovaps xmm1, [rsp+0x10]
0000710e9ebd6d2e  vmovaps xmm2, [rsp+0x20]
0000710e9ebd6d34  vmovaps xmm3, [rsp+0x30]
0000710e9ebd6d3a  vmovaps xmm4, [rsp+0x40]
0000710e9ebd6d40  vmovaps xmm5, [rsp+0x50]
0000710e9ebd6d46  vmovaps xmm6, [rsp+0x60]
0000710e9ebd6d4c  vmovaps xmm7, [rsp+0x70]
0000710e9ebd6d52  vmovaps xmm8, [rsp+0x80]
0000710e9ebd6d5b  vmovaps xmm9, [rsp+0x90]
0000710e9ebd6d64  vmovaps xmm11, [rsp+0xA0]
0000710e9ebd6d6d  vmovaps xmm12, [rsp+0xB0]
0000710e9ebd6d76  vmovaps xmm13, [rsp+0xC0]
0000710e9ebd6d7f  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd6d88  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd6d91  add rsp, 0xF0
0000710e9ebd6d98  pop r11
0000710e9ebd6d9a  pop r10
0000710e9ebd6d9c  pop r9
0000710e9ebd6d9e  pop r8
0000710e9ebd6da0  pop rsi
0000710e9ebd6da1  pop rdi
0000710e9ebd6da2  pop rdx
0000710e9ebd6da3  pop rcx
0000710e9ebd6da4  pop rax
0000710e9ebd6da5  add rsp, 0x08
0000710e9ebd6da9  jmp 0x0000710E9EBD3237
0000710e9ebd6dae  sub rsp, 0x08
0000710e9ebd6db2  push rax
0000710e9ebd6db3  push rcx
0000710e9ebd6db4  push rdx
0000710e9ebd6db5  push rdi
0000710e9ebd6db6  push rsi
0000710e9ebd6db7  push r8
0000710e9ebd6db9  push r9
0000710e9ebd6dbb  push r10
0000710e9ebd6dbd  push r11
0000710e9ebd6dbf  sub rsp, 0xF0
0000710e9ebd6dc6  vmovaps [rsp], xmm0
0000710e9ebd6dcb  vmovaps [rsp+0x10], xmm2
0000710e9ebd6dd1  vmovaps [rsp+0x20], xmm3
0000710e9ebd6dd7  vmovaps [rsp+0x30], xmm4
0000710e9ebd6ddd  vmovaps [rsp+0x40], xmm5
0000710e9ebd6de3  vmovaps [rsp+0x50], xmm6
0000710e9ebd6de9  vmovaps [rsp+0x60], xmm7
0000710e9ebd6def  vmovaps [rsp+0x70], xmm8
0000710e9ebd6df5  vmovaps [rsp+0x80], xmm9
0000710e9ebd6dfe  vmovaps [rsp+0x90], xmm10
0000710e9ebd6e07  vmovaps [rsp+0xA0], xmm11
0000710e9ebd6e10  vmovaps [rsp+0xB0], xmm12
0000710e9ebd6e19  vmovaps [rsp+0xC0], xmm13
0000710e9ebd6e22  vmovaps [rsp+0xD0], xmm14
0000710e9ebd6e2b  vmovaps [rsp+0xE0], xmm15
0000710e9ebd6e34  sub rsp, 0x30
0000710e9ebd6e38  movaps [rsp], xmm1
0000710e9ebd6e3c  movaps [rsp+0x10], xmm15
0000710e9ebd6e42  movaps [rsp+0x20], xmm6
0000710e9ebd6e47  lea rdi, [rsp]
0000710e9ebd6e4b  mov esi, 0x00
0000710e9ebd6e50  mov rax, 0x5DADAF7CF530
0000710e9ebd6e5a  call rax
0000710e9ebd6e5c  movaps xmm1, [rsp]
0000710e9ebd6e60  add rsp, 0x30
0000710e9ebd6e64  vmovaps xmm0, [rsp]
0000710e9ebd6e69  vmovaps xmm2, [rsp+0x10]
0000710e9ebd6e6f  vmovaps xmm3, [rsp+0x20]
0000710e9ebd6e75  vmovaps xmm4, [rsp+0x30]
0000710e9ebd6e7b  vmovaps xmm5, [rsp+0x40]
0000710e9ebd6e81  vmovaps xmm6, [rsp+0x50]
0000710e9ebd6e87  vmovaps xmm7, [rsp+0x60]
0000710e9ebd6e8d  vmovaps xmm8, [rsp+0x70]
0000710e9ebd6e93  vmovaps xmm9, [rsp+0x80]
0000710e9ebd6e9c  vmovaps xmm10, [rsp+0x90]
0000710e9ebd6ea5  vmovaps xmm11, [rsp+0xA0]
0000710e9ebd6eae  vmovaps xmm12, [rsp+0xB0]
0000710e9ebd6eb7  vmovaps xmm13, [rsp+0xC0]
0000710e9ebd6ec0  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd6ec9  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd6ed2  add rsp, 0xF0
0000710e9ebd6ed9  pop r11
0000710e9ebd6edb  pop r10
0000710e9ebd6edd  pop r9
0000710e9ebd6edf  pop r8
0000710e9ebd6ee1  pop rsi
0000710e9ebd6ee2  pop rdi
0000710e9ebd6ee3  pop rdx
0000710e9ebd6ee4  pop rcx
0000710e9ebd6ee5  pop rax
0000710e9ebd6ee6  add rsp, 0x08
0000710e9ebd6eea  jmp 0x0000710E9EBD3250
0000710e9ebd6eef  sub rsp, 0x08
0000710e9ebd6ef3  push rax
0000710e9ebd6ef4  push rcx
0000710e9ebd6ef5  push rdx
0000710e9ebd6ef6  push rdi
0000710e9ebd6ef7  push rsi
0000710e9ebd6ef8  push r8
0000710e9ebd6efa  push r9
0000710e9ebd6efc  push r10
0000710e9ebd6efe  push r11
0000710e9ebd6f00  sub rsp, 0xF0
0000710e9ebd6f07  vmovaps [rsp], xmm0
0000710e9ebd6f0c  vmovaps [rsp+0x10], xmm1
0000710e9ebd6f12  vmovaps [rsp+0x20], xmm2
0000710e9ebd6f18  vmovaps [rsp+0x30], xmm3
0000710e9ebd6f1e  vmovaps [rsp+0x40], xmm4
0000710e9ebd6f24  vmovaps [rsp+0x50], xmm5
0000710e9ebd6f2a  vmovaps [rsp+0x60], xmm6
0000710e9ebd6f30  vmovaps [rsp+0x70], xmm7
0000710e9ebd6f36  vmovaps [rsp+0x80], xmm8
0000710e9ebd6f3f  vmovaps [rsp+0x90], xmm9
0000710e9ebd6f48  vmovaps [rsp+0xA0], xmm10
0000710e9ebd6f51  vmovaps [rsp+0xB0], xmm12
0000710e9ebd6f5a  vmovaps [rsp+0xC0], xmm13
0000710e9ebd6f63  vmovaps [rsp+0xD0], xmm14
0000710e9ebd6f6c  vmovaps [rsp+0xE0], xmm15
0000710e9ebd6f75  sub rsp, 0x30
0000710e9ebd6f79  movaps [rsp], xmm11
0000710e9ebd6f7e  movaps [rsp+0x10], xmm12
0000710e9ebd6f84  movaps [rsp+0x20], xmm15
0000710e9ebd6f8a  lea rdi, [rsp]
0000710e9ebd6f8e  mov esi, 0x00
0000710e9ebd6f93  mov rax, 0x5DADAF7CF530
0000710e9ebd6f9d  call rax
0000710e9ebd6f9f  movaps xmm11, [rsp]
0000710e9ebd6fa4  add rsp, 0x30
0000710e9ebd6fa8  vmovaps xmm0, [rsp]
0000710e9ebd6fad  vmovaps xmm1, [rsp+0x10]
0000710e9ebd6fb3  vmovaps xmm2, [rsp+0x20]
0000710e9ebd6fb9  vmovaps xmm3, [rsp+0x30]
0000710e9ebd6fbf  vmovaps xmm4, [rsp+0x40]
0000710e9ebd6fc5  vmovaps xmm5, [rsp+0x50]
0000710e9ebd6fcb  vmovaps xmm6, [rsp+0x60]
0000710e9ebd6fd1  vmovaps xmm7, [rsp+0x70]
0000710e9ebd6fd7  vmovaps xmm8, [rsp+0x80]
0000710e9ebd6fe0  vmovaps xmm9, [rsp+0x90]
0000710e9ebd6fe9  vmovaps xmm10, [rsp+0xA0]
0000710e9ebd6ff2  vmovaps xmm12, [rsp+0xB0]
0000710e9ebd6ffb  vmovaps xmm13, [rsp+0xC0]
0000710e9ebd7004  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd700d  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd7016  add rsp, 0xF0
0000710e9ebd701d  pop r11
0000710e9ebd701f  pop r10
0000710e9ebd7021  pop r9
0000710e9ebd7023  pop r8
0000710e9ebd7025  pop rsi
0000710e9ebd7026  pop rdi
0000710e9ebd7027  pop rdx
0000710e9ebd7028  pop rcx
0000710e9ebd7029  pop rax
0000710e9ebd702a  add rsp, 0x08
0000710e9ebd702e  jmp 0x0000710E9EBD327A
0000710e9ebd7033  sub rsp, 0x08
0000710e9ebd7037  push rax
0000710e9ebd7038  push rcx
0000710e9ebd7039  push rdx
0000710e9ebd703a  push rdi
0000710e9ebd703b  push rsi
0000710e9ebd703c  push r8
0000710e9ebd703e  push r9
0000710e9ebd7040  push r10
0000710e9ebd7042  push r11
0000710e9ebd7044  sub rsp, 0xF0
0000710e9ebd704b  vmovaps [rsp], xmm0
0000710e9ebd7050  vmovaps [rsp+0x10], xmm1
0000710e9ebd7056  vmovaps [rsp+0x20], xmm2
0000710e9ebd705c  vmovaps [rsp+0x30], xmm3
0000710e9ebd7062  vmovaps [rsp+0x40], xmm4
0000710e9ebd7068  vmovaps [rsp+0x50], xmm5
0000710e9ebd706e  vmovaps [rsp+0x60], xmm6
0000710e9ebd7074  vmovaps [rsp+0x70], xmm7
0000710e9ebd707a  vmovaps [rsp+0x80], xmm8
0000710e9ebd7083  vmovaps [rsp+0x90], xmm9
0000710e9ebd708c  vmovaps [rsp+0xA0], xmm10
0000710e9ebd7095  vmovaps [rsp+0xB0], xmm11
0000710e9ebd709e  vmovaps [rsp+0xC0], xmm13
0000710e9ebd70a7  vmovaps [rsp+0xD0], xmm14
0000710e9ebd70b0  vmovaps [rsp+0xE0], xmm15
0000710e9ebd70b9  sub rsp, 0x30
0000710e9ebd70bd  movaps [rsp], xmm12
0000710e9ebd70c2  movaps [rsp+0x10], xmm8
0000710e9ebd70c8  movaps [rsp+0x20], xmm15
0000710e9ebd70ce  lea rdi, [rsp]
0000710e9ebd70d2  mov esi, 0x00
0000710e9ebd70d7  mov rax, 0x5DADAF7CF530
0000710e9ebd70e1  call rax
0000710e9ebd70e3  movaps xmm12, [rsp]
0000710e9ebd70e8  add rsp, 0x30
0000710e9ebd70ec  vmovaps xmm0, [rsp]
0000710e9ebd70f1  vmovaps xmm1, [rsp+0x10]
0000710e9ebd70f7  vmovaps xmm2, [rsp+0x20]
0000710e9ebd70fd  vmovaps xmm3, [rsp+0x30]
0000710e9ebd7103  vmovaps xmm4, [rsp+0x40]
0000710e9ebd7109  vmovaps xmm5, [rsp+0x50]
0000710e9ebd710f  vmovaps xmm6, [rsp+0x60]
0000710e9ebd7115  vmovaps xmm7, [rsp+0x70]
0000710e9ebd711b  vmovaps xmm8, [rsp+0x80]
0000710e9ebd7124  vmovaps xmm9, [rsp+0x90]
0000710e9ebd712d  vmovaps xmm10, [rsp+0xA0]
0000710e9ebd7136  vmovaps xmm11, [rsp+0xB0]
0000710e9ebd713f  vmovaps xmm13, [rsp+0xC0]
0000710e9ebd7148  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd7151  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd715a  add rsp, 0xF0
0000710e9ebd7161  pop r11
0000710e9ebd7163  pop r10
0000710e9ebd7165  pop r9
0000710e9ebd7167  pop r8
0000710e9ebd7169  pop rsi
0000710e9ebd716a  pop rdi
0000710e9ebd716b  pop rdx
0000710e9ebd716c  pop rcx
0000710e9ebd716d  pop rax
0000710e9ebd716e  add rsp, 0x08
0000710e9ebd7172  jmp 0x0000710E9EBD32A9
0000710e9ebd7177  sub rsp, 0x08
0000710e9ebd717b  push rax
0000710e9ebd717c  push rcx
0000710e9ebd717d  push rdx
0000710e9ebd717e  push rdi
0000710e9ebd717f  push rsi
0000710e9ebd7180  push r8
0000710e9ebd7182  push r9
0000710e9ebd7184  push r10
0000710e9ebd7186  push r11
0000710e9ebd7188  sub rsp, 0xF0
0000710e9ebd718f  vmovaps [rsp], xmm0
0000710e9ebd7194  vmovaps [rsp+0x10], xmm1
0000710e9ebd719a  vmovaps [rsp+0x20], xmm2
0000710e9ebd71a0  vmovaps [rsp+0x30], xmm3
0000710e9ebd71a6  vmovaps [rsp+0x40], xmm4
0000710e9ebd71ac  vmovaps [rsp+0x50], xmm5
0000710e9ebd71b2  vmovaps [rsp+0x60], xmm6
0000710e9ebd71b8  vmovaps [rsp+0x70], xmm7
0000710e9ebd71be  vmovaps [rsp+0x80], xmm9
0000710e9ebd71c7  vmovaps [rsp+0x90], xmm10
0000710e9ebd71d0  vmovaps [rsp+0xA0], xmm11
0000710e9ebd71d9  vmovaps [rsp+0xB0], xmm12
0000710e9ebd71e2  vmovaps [rsp+0xC0], xmm13
0000710e9ebd71eb  vmovaps [rsp+0xD0], xmm14
0000710e9ebd71f4  vmovaps [rsp+0xE0], xmm15
0000710e9ebd71fd  sub rsp, 0x30
0000710e9ebd7201  movaps [rsp], xmm8
0000710e9ebd7206  movaps [rsp+0x10], xmm7
0000710e9ebd720b  movaps [rsp+0x20], xmm15
0000710e9ebd7211  lea rdi, [rsp]
0000710e9ebd7215  mov esi, 0x00
0000710e9ebd721a  mov rax, 0x5DADAF7CF530
0000710e9ebd7224  call rax
0000710e9ebd7226  movaps xmm8, [rsp]
0000710e9ebd722b  add rsp, 0x30
0000710e9ebd722f  vmovaps xmm0, [rsp]
0000710e9ebd7234  vmovaps xmm1, [rsp+0x10]
0000710e9ebd723a  vmovaps xmm2, [rsp+0x20]
0000710e9ebd7240  vmovaps xmm3, [rsp+0x30]
0000710e9ebd7246  vmovaps xmm4, [rsp+0x40]
0000710e9ebd724c  vmovaps xmm5, [rsp+0x50]
0000710e9ebd7252  vmovaps xmm6, [rsp+0x60]
0000710e9ebd7258  vmovaps xmm7, [rsp+0x70]
0000710e9ebd725e  vmovaps xmm9, [rsp+0x80]
0000710e9ebd7267  vmovaps xmm10, [rsp+0x90]
0000710e9ebd7270  vmovaps xmm11, [rsp+0xA0]
0000710e9ebd7279  vmovaps xmm12, [rsp+0xB0]
0000710e9ebd7282  vmovaps xmm13, [rsp+0xC0]
0000710e9ebd728b  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd7294  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd729d  add rsp, 0xF0
0000710e9ebd72a4  pop r11
0000710e9ebd72a6  pop r10
0000710e9ebd72a8  pop r9
0000710e9ebd72aa  pop r8
0000710e9ebd72ac  pop rsi
0000710e9ebd72ad  pop rdi
0000710e9ebd72ae  pop rdx
0000710e9ebd72af  pop rcx
0000710e9ebd72b0  pop rax
0000710e9ebd72b1  add rsp, 0x08
0000710e9ebd72b5  jmp 0x0000710E9EBD32CF
0000710e9ebd72ba  sub rsp, 0x08
0000710e9ebd72be  push rax
0000710e9ebd72bf  push rcx
0000710e9ebd72c0  push rdx
0000710e9ebd72c1  push rdi
0000710e9ebd72c2  push rsi
0000710e9ebd72c3  push r8
0000710e9ebd72c5  push r9
0000710e9ebd72c7  push r10
0000710e9ebd72c9  push r11
0000710e9ebd72cb  sub rsp, 0xF0
0000710e9ebd72d2  vmovaps [rsp], xmm0
0000710e9ebd72d7  vmovaps [rsp+0x10], xmm1
0000710e9ebd72dd  vmovaps [rsp+0x20], xmm2
0000710e9ebd72e3  vmovaps [rsp+0x30], xmm3
0000710e9ebd72e9  vmovaps [rsp+0x40], xmm4
0000710e9ebd72ef  vmovaps [rsp+0x50], xmm5
0000710e9ebd72f5  vmovaps [rsp+0x60], xmm6
0000710e9ebd72fb  vmovaps [rsp+0x70], xmm7
0000710e9ebd7301  vmovaps [rsp+0x80], xmm8
0000710e9ebd730a  vmovaps [rsp+0x90], xmm9
0000710e9ebd7313  vmovaps [rsp+0xA0], xmm10
0000710e9ebd731c  vmovaps [rsp+0xB0], xmm11
0000710e9ebd7325  vmovaps [rsp+0xC0], xmm12
0000710e9ebd732e  vmovaps [rsp+0xD0], xmm13
0000710e9ebd7337  vmovaps [rsp+0xE0], xmm14
0000710e9ebd7340  sub rsp, 0x30
0000710e9ebd7344  movaps [rsp], xmm15
0000710e9ebd7349  movaps [rsp+0x10], xmm14
0000710e9ebd734f  movaps [rsp+0x20], xmm9
0000710e9ebd7355  lea rdi, [rsp]
0000710e9ebd7359  mov esi, 0x00
0000710e9ebd735e  mov rax, 0x5DADAF7CF530
0000710e9ebd7368  call rax
0000710e9ebd736a  movaps xmm15, [rsp]
0000710e9ebd736f  add rsp, 0x30
0000710e9ebd7373  vmovaps xmm0, [rsp]
0000710e9ebd7378  vmovaps xmm1, [rsp+0x10]
0000710e9ebd737e  vmovaps xmm2, [rsp+0x20]
0000710e9ebd7384  vmovaps xmm3, [rsp+0x30]
0000710e9ebd738a  vmovaps xmm4, [rsp+0x40]
0000710e9ebd7390  vmovaps xmm5, [rsp+0x50]
0000710e9ebd7396  vmovaps xmm6, [rsp+0x60]
0000710e9ebd739c  vmovaps xmm7, [rsp+0x70]
0000710e9ebd73a2  vmovaps xmm8, [rsp+0x80]
0000710e9ebd73ab  vmovaps xmm9, [rsp+0x90]
0000710e9ebd73b4  vmovaps xmm10, [rsp+0xA0]
0000710e9ebd73bd  vmovaps xmm11, [rsp+0xB0]
0000710e9ebd73c6  vmovaps xmm12, [rsp+0xC0]
0000710e9ebd73cf  vmovaps xmm13, [rsp+0xD0]
0000710e9ebd73d8  vmovaps xmm14, [rsp+0xE0]
0000710e9ebd73e1  add rsp, 0xF0
0000710e9ebd73e8  pop r11
0000710e9ebd73ea  pop r10
0000710e9ebd73ec  pop r9
0000710e9ebd73ee  pop r8
0000710e9ebd73f0  pop rsi
0000710e9ebd73f1  pop rdi
0000710e9ebd73f2  pop rdx
0000710e9ebd73f3  pop rcx
0000710e9ebd73f4  pop rax
0000710e9ebd73f5  add rsp, 0x08
0000710e9ebd73f9  jmp 0x0000710E9EBD32E9
0000710e9ebd73fe  sub rsp, 0x08
0000710e9ebd7402  push rax
0000710e9ebd7403  push rcx
0000710e9ebd7404  push rdx
0000710e9ebd7405  push rdi
0000710e9ebd7406  push rsi
0000710e9ebd7407  push r8
0000710e9ebd7409  push r9
0000710e9ebd740b  push r10
0000710e9ebd740d  push r11
0000710e9ebd740f  sub rsp, 0xF0
0000710e9ebd7416  vmovaps [rsp], xmm0
0000710e9ebd741b  vmovaps [rsp+0x10], xmm1
0000710e9ebd7421  vmovaps [rsp+0x20], xmm2
0000710e9ebd7427  vmovaps [rsp+0x30], xmm3
0000710e9ebd742d  vmovaps [rsp+0x40], xmm4
0000710e9ebd7433  vmovaps [rsp+0x50], xmm5
0000710e9ebd7439  vmovaps [rsp+0x60], xmm6
0000710e9ebd743f  vmovaps [rsp+0x70], xmm7
0000710e9ebd7445  vmovaps [rsp+0x80], xmm8
0000710e9ebd744e  vmovaps [rsp+0x90], xmm10
0000710e9ebd7457  vmovaps [rsp+0xA0], xmm11
0000710e9ebd7460  vmovaps [rsp+0xB0], xmm12
0000710e9ebd7469  vmovaps [rsp+0xC0], xmm13
0000710e9ebd7472  vmovaps [rsp+0xD0], xmm14
0000710e9ebd747b  vmovaps [rsp+0xE0], xmm15
0000710e9ebd7484  sub rsp, 0x30
0000710e9ebd7488  movaps [rsp], xmm9
0000710e9ebd748d  movaps [rsp+0x10], xmm7
0000710e9ebd7492  movaps [rsp+0x20], xmm14
0000710e9ebd7498  lea rdi, [rsp]
0000710e9ebd749c  mov esi, 0x00
0000710e9ebd74a1  mov rax, 0x5DADAF7CF530
0000710e9ebd74ab  call rax
0000710e9ebd74ad  movaps xmm9, [rsp]
0000710e9ebd74b2  add rsp, 0x30
0000710e9ebd74b6  vmovaps xmm0, [rsp]
0000710e9ebd74bb  vmovaps xmm1, [rsp+0x10]
0000710e9ebd74c1  vmovaps xmm2, [rsp+0x20]
0000710e9ebd74c7  vmovaps xmm3, [rsp+0x30]
0000710e9ebd74cd  vmovaps xmm4, [rsp+0x40]
0000710e9ebd74d3  vmovaps xmm5, [rsp+0x50]
0000710e9ebd74d9  vmovaps xmm6, [rsp+0x60]
0000710e9ebd74df  vmovaps xmm7, [rsp+0x70]
0000710e9ebd74e5  vmovaps xmm8, [rsp+0x80]
0000710e9ebd74ee  vmovaps xmm10, [rsp+0x90]
0000710e9ebd74f7  vmovaps xmm11, [rsp+0xA0]
0000710e9ebd7500  vmovaps xmm12, [rsp+0xB0]
0000710e9ebd7509  vmovaps xmm13, [rsp+0xC0]
0000710e9ebd7512  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd751b  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd7524  add rsp, 0xF0
0000710e9ebd752b  pop r11
0000710e9ebd752d  pop r10
0000710e9ebd752f  pop r9
0000710e9ebd7531  pop r8
0000710e9ebd7533  pop rsi
0000710e9ebd7534  pop rdi
0000710e9ebd7535  pop rdx
0000710e9ebd7536  pop rcx
0000710e9ebd7537  pop rax
0000710e9ebd7538  add rsp, 0x08
0000710e9ebd753c  jmp 0x0000710E9EBD3318
0000710e9ebd7541  sub rsp, 0x08
0000710e9ebd7545  push rax
0000710e9ebd7546  push rcx
0000710e9ebd7547  push rdx
0000710e9ebd7548  push rdi
0000710e9ebd7549  push rsi
0000710e9ebd754a  push r8
0000710e9ebd754c  push r9
0000710e9ebd754e  push r10
0000710e9ebd7550  push r11
0000710e9ebd7552  sub rsp, 0xF0
0000710e9ebd7559  vmovaps [rsp], xmm0
0000710e9ebd755e  vmovaps [rsp+0x10], xmm1
0000710e9ebd7564  vmovaps [rsp+0x20], xmm2
0000710e9ebd756a  vmovaps [rsp+0x30], xmm3
0000710e9ebd7570  vmovaps [rsp+0x40], xmm4
0000710e9ebd7576  vmovaps [rsp+0x50], xmm5
0000710e9ebd757c  vmovaps [rsp+0x60], xmm6
0000710e9ebd7582  vmovaps [rsp+0x70], xmm7
0000710e9ebd7588  vmovaps [rsp+0x80], xmm8
0000710e9ebd7591  vmovaps [rsp+0x90], xmm9
0000710e9ebd759a  vmovaps [rsp+0xA0], xmm10
0000710e9ebd75a3  vmovaps [rsp+0xB0], xmm11
0000710e9ebd75ac  vmovaps [rsp+0xC0], xmm12
0000710e9ebd75b5  vmovaps [rsp+0xD0], xmm13
0000710e9ebd75be  vmovaps [rsp+0xE0], xmm15
0000710e9ebd75c7  sub rsp, 0x30
0000710e9ebd75cb  movaps [rsp], xmm14
0000710e9ebd75d0  movaps [rsp+0x10], xmm13
0000710e9ebd75d6  movaps [rsp+0x20], xmm11
0000710e9ebd75dc  lea rdi, [rsp]
0000710e9ebd75e0  mov esi, 0x00
0000710e9ebd75e5  mov rax, 0x5DADAF7CF530
0000710e9ebd75ef  call rax
0000710e9ebd75f1  movaps xmm14, [rsp]
0000710e9ebd75f6  add rsp, 0x30
0000710e9ebd75fa  vmovaps xmm0, [rsp]
0000710e9ebd75ff  vmovaps xmm1, [rsp+0x10]
0000710e9ebd7605  vmovaps xmm2, [rsp+0x20]
0000710e9ebd760b  vmovaps xmm3, [rsp+0x30]
0000710e9ebd7611  vmovaps xmm4, [rsp+0x40]
0000710e9ebd7617  vmovaps xmm5, [rsp+0x50]
0000710e9ebd761d  vmovaps xmm6, [rsp+0x60]
0000710e9ebd7623  vmovaps xmm7, [rsp+0x70]
0000710e9ebd7629  vmovaps xmm8, [rsp+0x80]
0000710e9ebd7632  vmovaps xmm9, [rsp+0x90]
0000710e9ebd763b  vmovaps xmm10, [rsp+0xA0]
0000710e9ebd7644  vmovaps xmm11, [rsp+0xB0]
0000710e9ebd764d  vmovaps xmm12, [rsp+0xC0]
0000710e9ebd7656  vmovaps xmm13, [rsp+0xD0]
0000710e9ebd765f  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd7668  add rsp, 0xF0
0000710e9ebd766f  pop r11
0000710e9ebd7671  pop r10
0000710e9ebd7673  pop r9
0000710e9ebd7675  pop r8
0000710e9ebd7677  pop rsi
0000710e9ebd7678  pop rdi
0000710e9ebd7679  pop rdx
0000710e9ebd767a  pop rcx
0000710e9ebd767b  pop rax
0000710e9ebd767c  add rsp, 0x08
0000710e9ebd7680  jmp 0x0000710E9EBD3332
0000710e9ebd7685  sub rsp, 0x08
0000710e9ebd7689  push rax
0000710e9ebd768a  push rcx
0000710e9ebd768b  push rdx
0000710e9ebd768c  push rdi
0000710e9ebd768d  push rsi
0000710e9ebd768e  push r8
0000710e9ebd7690  push r9
0000710e9ebd7692  push r10
0000710e9ebd7694  push r11
0000710e9ebd7696  sub rsp, 0xF0
0000710e9ebd769d  vmovaps [rsp], xmm0
0000710e9ebd76a2  vmovaps [rsp+0x10], xmm1
0000710e9ebd76a8  vmovaps [rsp+0x20], xmm2
0000710e9ebd76ae  vmovaps [rsp+0x30], xmm3
0000710e9ebd76b4  vmovaps [rsp+0x40], xmm4
0000710e9ebd76ba  vmovaps [rsp+0x50], xmm5
0000710e9ebd76c0  vmovaps [rsp+0x60], xmm6
0000710e9ebd76c6  vmovaps [rsp+0x70], xmm7
0000710e9ebd76cc  vmovaps [rsp+0x80], xmm8
0000710e9ebd76d5  vmovaps [rsp+0x90], xmm9
0000710e9ebd76de  vmovaps [rsp+0xA0], xmm10
0000710e9ebd76e7  vmovaps [rsp+0xB0], xmm12
0000710e9ebd76f0  vmovaps [rsp+0xC0], xmm13
0000710e9ebd76f9  vmovaps [rsp+0xD0], xmm14
0000710e9ebd7702  vmovaps [rsp+0xE0], xmm15
0000710e9ebd770b  sub rsp, 0x30
0000710e9ebd770f  movaps [rsp], xmm11
0000710e9ebd7714  movaps [rsp+0x10], xmm7
0000710e9ebd7719  movaps [rsp+0x20], xmm13
0000710e9ebd771f  lea rdi, [rsp]
0000710e9ebd7723  mov esi, 0x00
0000710e9ebd7728  mov rax, 0x5DADAF7CF530
0000710e9ebd7732  call rax
0000710e9ebd7734  movaps xmm11, [rsp]
0000710e9ebd7739  add rsp, 0x30
0000710e9ebd773d  vmovaps xmm0, [rsp]
0000710e9ebd7742  vmovaps xmm1, [rsp+0x10]
0000710e9ebd7748  vmovaps xmm2, [rsp+0x20]
0000710e9ebd774e  vmovaps xmm3, [rsp+0x30]
0000710e9ebd7754  vmovaps xmm4, [rsp+0x40]
0000710e9ebd775a  vmovaps xmm5, [rsp+0x50]
0000710e9ebd7760  vmovaps xmm6, [rsp+0x60]
0000710e9ebd7766  vmovaps xmm7, [rsp+0x70]
0000710e9ebd776c  vmovaps xmm8, [rsp+0x80]
0000710e9ebd7775  vmovaps xmm9, [rsp+0x90]
0000710e9ebd777e  vmovaps xmm10, [rsp+0xA0]
0000710e9ebd7787  vmovaps xmm12, [rsp+0xB0]
0000710e9ebd7790  vmovaps xmm13, [rsp+0xC0]
0000710e9ebd7799  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd77a2  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd77ab  add rsp, 0xF0
0000710e9ebd77b2  pop r11
0000710e9ebd77b4  pop r10
0000710e9ebd77b6  pop r9
0000710e9ebd77b8  pop r8
0000710e9ebd77ba  pop rsi
0000710e9ebd77bb  pop rdi
0000710e9ebd77bc  pop rdx
0000710e9ebd77bd  pop rcx
0000710e9ebd77be  pop rax
0000710e9ebd77bf  add rsp, 0x08
0000710e9ebd77c3  jmp 0x0000710E9EBD335E
0000710e9ebd77c8  sub rsp, 0x08
0000710e9ebd77cc  push rax
0000710e9ebd77cd  push rcx
0000710e9ebd77ce  push rdx
0000710e9ebd77cf  push rdi
0000710e9ebd77d0  push rsi
0000710e9ebd77d1  push r8
0000710e9ebd77d3  push r9
0000710e9ebd77d5  push r10
0000710e9ebd77d7  push r11
0000710e9ebd77d9  sub rsp, 0xF0
0000710e9ebd77e0  vmovaps [rsp], xmm0
0000710e9ebd77e5  vmovaps [rsp+0x10], xmm1
0000710e9ebd77eb  vmovaps [rsp+0x20], xmm2
0000710e9ebd77f1  vmovaps [rsp+0x30], xmm3
0000710e9ebd77f7  vmovaps [rsp+0x40], xmm4
0000710e9ebd77fd  vmovaps [rsp+0x50], xmm5
0000710e9ebd7803  vmovaps [rsp+0x60], xmm6
0000710e9ebd7809  vmovaps [rsp+0x70], xmm7
0000710e9ebd780f  vmovaps [rsp+0x80], xmm8
0000710e9ebd7818  vmovaps [rsp+0x90], xmm9
0000710e9ebd7821  vmovaps [rsp+0xA0], xmm10
0000710e9ebd782a  vmovaps [rsp+0xB0], xmm11
0000710e9ebd7833  vmovaps [rsp+0xC0], xmm12
0000710e9ebd783c  vmovaps [rsp+0xD0], xmm14
0000710e9ebd7845  vmovaps [rsp+0xE0], xmm15
0000710e9ebd784e  sub rsp, 0x30
0000710e9ebd7852  movaps [rsp], xmm13
0000710e9ebd7857  movaps [rsp+0x10], xmm10
0000710e9ebd785d  movaps [rsp+0x20], xmm12
0000710e9ebd7863  lea rdi, [rsp]
0000710e9ebd7867  mov esi, 0x00
0000710e9ebd786c  mov rax, 0x5DADAF7CF530
0000710e9ebd7876  call rax
0000710e9ebd7878  movaps xmm13, [rsp]
0000710e9ebd787d  add rsp, 0x30
0000710e9ebd7881  vmovaps xmm0, [rsp]
0000710e9ebd7886  vmovaps xmm1, [rsp+0x10]
0000710e9ebd788c  vmovaps xmm2, [rsp+0x20]
0000710e9ebd7892  vmovaps xmm3, [rsp+0x30]
0000710e9ebd7898  vmovaps xmm4, [rsp+0x40]
0000710e9ebd789e  vmovaps xmm5, [rsp+0x50]
0000710e9ebd78a4  vmovaps xmm6, [rsp+0x60]
0000710e9ebd78aa  vmovaps xmm7, [rsp+0x70]
0000710e9ebd78b0  vmovaps xmm8, [rsp+0x80]
0000710e9ebd78b9  vmovaps xmm9, [rsp+0x90]
0000710e9ebd78c2  vmovaps xmm10, [rsp+0xA0]
0000710e9ebd78cb  vmovaps xmm11, [rsp+0xB0]
0000710e9ebd78d4  vmovaps xmm12, [rsp+0xC0]
0000710e9ebd78dd  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd78e6  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd78ef  add rsp, 0xF0
0000710e9ebd78f6  pop r11
0000710e9ebd78f8  pop r10
0000710e9ebd78fa  pop r9
0000710e9ebd78fc  pop r8
0000710e9ebd78fe  pop rsi
0000710e9ebd78ff  pop rdi
0000710e9ebd7900  pop rdx
0000710e9ebd7901  pop rcx
0000710e9ebd7902  pop rax
0000710e9ebd7903  add rsp, 0x08
0000710e9ebd7907  jmp 0x0000710E9EBD3378
0000710e9ebd790c  sub rsp, 0x08
0000710e9ebd7910  push rax
0000710e9ebd7911  push rcx
0000710e9ebd7912  push rdx
0000710e9ebd7913  push rdi
0000710e9ebd7914  push rsi
0000710e9ebd7915  push r8
0000710e9ebd7917  push r9
0000710e9ebd7919  push r10
0000710e9ebd791b  push r11
0000710e9ebd791d  sub rsp, 0xF0
0000710e9ebd7924  vmovaps [rsp], xmm0
0000710e9ebd7929  vmovaps [rsp+0x10], xmm1
0000710e9ebd792f  vmovaps [rsp+0x20], xmm2
0000710e9ebd7935  vmovaps [rsp+0x30], xmm3
0000710e9ebd793b  vmovaps [rsp+0x40], xmm4
0000710e9ebd7941  vmovaps [rsp+0x50], xmm5
0000710e9ebd7947  vmovaps [rsp+0x60], xmm6
0000710e9ebd794d  vmovaps [rsp+0x70], xmm7
0000710e9ebd7953  vmovaps [rsp+0x80], xmm8
0000710e9ebd795c  vmovaps [rsp+0x90], xmm9
0000710e9ebd7965  vmovaps [rsp+0xA0], xmm11
0000710e9ebd796e  vmovaps [rsp+0xB0], xmm12
0000710e9ebd7977  vmovaps [rsp+0xC0], xmm13
0000710e9ebd7980  vmovaps [rsp+0xD0], xmm14
0000710e9ebd7989  vmovaps [rsp+0xE0], xmm15
0000710e9ebd7992  sub rsp, 0x30
0000710e9ebd7996  movaps [rsp], xmm10
0000710e9ebd799b  movaps [rsp+0x10], xmm7
0000710e9ebd79a0  movaps [rsp+0x20], xmm12
0000710e9ebd79a6  lea rdi, [rsp]
0000710e9ebd79aa  mov esi, 0x00
0000710e9ebd79af  mov rax, 0x5DADAF7CF530
0000710e9ebd79b9  call rax
0000710e9ebd79bb  movaps xmm10, [rsp]
0000710e9ebd79c0  add rsp, 0x30
0000710e9ebd79c4  vmovaps xmm0, [rsp]
0000710e9ebd79c9  vmovaps xmm1, [rsp+0x10]
0000710e9ebd79cf  vmovaps xmm2, [rsp+0x20]
0000710e9ebd79d5  vmovaps xmm3, [rsp+0x30]
0000710e9ebd79db  vmovaps xmm4, [rsp+0x40]
0000710e9ebd79e1  vmovaps xmm5, [rsp+0x50]
0000710e9ebd79e7  vmovaps xmm6, [rsp+0x60]
0000710e9ebd79ed  vmovaps xmm7, [rsp+0x70]
0000710e9ebd79f3  vmovaps xmm8, [rsp+0x80]
0000710e9ebd79fc  vmovaps xmm9, [rsp+0x90]
0000710e9ebd7a05  vmovaps xmm11, [rsp+0xA0]
0000710e9ebd7a0e  vmovaps xmm12, [rsp+0xB0]
0000710e9ebd7a17  vmovaps xmm13, [rsp+0xC0]
0000710e9ebd7a20  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd7a29  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd7a32  add rsp, 0xF0
0000710e9ebd7a39  pop r11
0000710e9ebd7a3b  pop r10
0000710e9ebd7a3d  pop r9
0000710e9ebd7a3f  pop r8
0000710e9ebd7a41  pop rsi
0000710e9ebd7a42  pop rdi
0000710e9ebd7a43  pop rdx
0000710e9ebd7a44  pop rcx
0000710e9ebd7a45  pop rax
0000710e9ebd7a46  add rsp, 0x08
0000710e9ebd7a4a  jmp 0x0000710E9EBD33A4
0000710e9ebd7a4f  sub rsp, 0x08
0000710e9ebd7a53  push rax
0000710e9ebd7a54  push rcx
0000710e9ebd7a55  push rdx
0000710e9ebd7a56  push rdi
0000710e9ebd7a57  push rsi
0000710e9ebd7a58  push r8
0000710e9ebd7a5a  push r9
0000710e9ebd7a5c  push r10
0000710e9ebd7a5e  push r11
0000710e9ebd7a60  sub rsp, 0xF0
0000710e9ebd7a67  vmovaps [rsp], xmm0
0000710e9ebd7a6c  vmovaps [rsp+0x10], xmm1
0000710e9ebd7a72  vmovaps [rsp+0x20], xmm2
0000710e9ebd7a78  vmovaps [rsp+0x30], xmm3
0000710e9ebd7a7e  vmovaps [rsp+0x40], xmm4
0000710e9ebd7a84  vmovaps [rsp+0x50], xmm5
0000710e9ebd7a8a  vmovaps [rsp+0x60], xmm6
0000710e9ebd7a90  vmovaps [rsp+0x70], xmm7
0000710e9ebd7a96  vmovaps [rsp+0x80], xmm8
0000710e9ebd7a9f  vmovaps [rsp+0x90], xmm9
0000710e9ebd7aa8  vmovaps [rsp+0xA0], xmm10
0000710e9ebd7ab1  vmovaps [rsp+0xB0], xmm11
0000710e9ebd7aba  vmovaps [rsp+0xC0], xmm13
0000710e9ebd7ac3  vmovaps [rsp+0xD0], xmm14
0000710e9ebd7acc  vmovaps [rsp+0xE0], xmm15
0000710e9ebd7ad5  sub rsp, 0x30
0000710e9ebd7ad9  movaps [rsp], xmm12
0000710e9ebd7ade  movaps [rsp+0x10], xmm1
0000710e9ebd7ae3  movaps [rsp+0x20], xmm8
0000710e9ebd7ae9  lea rdi, [rsp]
0000710e9ebd7aed  mov esi, 0x00
0000710e9ebd7af2  mov rax, 0x5DADAF7CF530
0000710e9ebd7afc  call rax
0000710e9ebd7afe  movaps xmm12, [rsp]
0000710e9ebd7b03  add rsp, 0x30
0000710e9ebd7b07  vmovaps xmm0, [rsp]
0000710e9ebd7b0c  vmovaps xmm1, [rsp+0x10]
0000710e9ebd7b12  vmovaps xmm2, [rsp+0x20]
0000710e9ebd7b18  vmovaps xmm3, [rsp+0x30]
0000710e9ebd7b1e  vmovaps xmm4, [rsp+0x40]
0000710e9ebd7b24  vmovaps xmm5, [rsp+0x50]
0000710e9ebd7b2a  vmovaps xmm6, [rsp+0x60]
0000710e9ebd7b30  vmovaps xmm7, [rsp+0x70]
0000710e9ebd7b36  vmovaps xmm8, [rsp+0x80]
0000710e9ebd7b3f  vmovaps xmm9, [rsp+0x90]
0000710e9ebd7b48  vmovaps xmm10, [rsp+0xA0]
0000710e9ebd7b51  vmovaps xmm11, [rsp+0xB0]
0000710e9ebd7b5a  vmovaps xmm13, [rsp+0xC0]
0000710e9ebd7b63  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd7b6c  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd7b75  add rsp, 0xF0
0000710e9ebd7b7c  pop r11
0000710e9ebd7b7e  pop r10
0000710e9ebd7b80  pop r9
0000710e9ebd7b82  pop r8
0000710e9ebd7b84  pop rsi
0000710e9ebd7b85  pop rdi
0000710e9ebd7b86  pop rdx
0000710e9ebd7b87  pop rcx
0000710e9ebd7b88  pop rax
0000710e9ebd7b89  add rsp, 0x08
0000710e9ebd7b8d  jmp 0x0000710E9EBD33BE
0000710e9ebd7b92  call 0x0000710E9E9FF430
0000710e9ebd7b97  jmp 0x0000710E9EBD33C8
0000710e9ebd7b9c  sub rsp, 0x08
0000710e9ebd7ba0  push rax
0000710e9ebd7ba1  push rcx
0000710e9ebd7ba2  push rdx
0000710e9ebd7ba3  push rdi
0000710e9ebd7ba4  push rsi
0000710e9ebd7ba5  push r8
0000710e9ebd7ba7  push r9
0000710e9ebd7ba9  push r10
0000710e9ebd7bab  push r11
0000710e9ebd7bad  sub rsp, 0xF0
0000710e9ebd7bb4  vmovaps [rsp], xmm0
0000710e9ebd7bb9  vmovaps [rsp+0x10], xmm1
0000710e9ebd7bbf  vmovaps [rsp+0x20], xmm2
0000710e9ebd7bc5  vmovaps [rsp+0x30], xmm3
0000710e9ebd7bcb  vmovaps [rsp+0x40], xmm4
0000710e9ebd7bd1  vmovaps [rsp+0x50], xmm5
0000710e9ebd7bd7  vmovaps [rsp+0x60], xmm6
0000710e9ebd7bdd  vmovaps [rsp+0x70], xmm7
0000710e9ebd7be3  vmovaps [rsp+0x80], xmm9
0000710e9ebd7bec  vmovaps [rsp+0x90], xmm10
0000710e9ebd7bf5  vmovaps [rsp+0xA0], xmm11
0000710e9ebd7bfe  vmovaps [rsp+0xB0], xmm12
0000710e9ebd7c07  vmovaps [rsp+0xC0], xmm13
0000710e9ebd7c10  vmovaps [rsp+0xD0], xmm14
0000710e9ebd7c19  vmovaps [rsp+0xE0], xmm15
0000710e9ebd7c22  sub rsp, 0x30
0000710e9ebd7c26  movaps [rsp], xmm8
0000710e9ebd7c2b  movaps [rsp+0x10], xmm15
0000710e9ebd7c31  movaps [rsp+0x20], xmm9
0000710e9ebd7c37  lea rdi, [rsp]
0000710e9ebd7c3b  mov esi, 0x00
0000710e9ebd7c40  mov rax, 0x5DADAF7CF530
0000710e9ebd7c4a  call rax
0000710e9ebd7c4c  movaps xmm8, [rsp]
0000710e9ebd7c51  add rsp, 0x30
0000710e9ebd7c55  vmovaps xmm0, [rsp]
0000710e9ebd7c5a  vmovaps xmm1, [rsp+0x10]
0000710e9ebd7c60  vmovaps xmm2, [rsp+0x20]
0000710e9ebd7c66  vmovaps xmm3, [rsp+0x30]
0000710e9ebd7c6c  vmovaps xmm4, [rsp+0x40]
0000710e9ebd7c72  vmovaps xmm5, [rsp+0x50]
0000710e9ebd7c78  vmovaps xmm6, [rsp+0x60]
0000710e9ebd7c7e  vmovaps xmm7, [rsp+0x70]
0000710e9ebd7c84  vmovaps xmm9, [rsp+0x80]
0000710e9ebd7c8d  vmovaps xmm10, [rsp+0x90]
0000710e9ebd7c96  vmovaps xmm11, [rsp+0xA0]
0000710e9ebd7c9f  vmovaps xmm12, [rsp+0xB0]
0000710e9ebd7ca8  vmovaps xmm13, [rsp+0xC0]
0000710e9ebd7cb1  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd7cba  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd7cc3  add rsp, 0xF0
0000710e9ebd7cca  pop r11
0000710e9ebd7ccc  pop r10
0000710e9ebd7cce  pop r9
0000710e9ebd7cd0  pop r8
0000710e9ebd7cd2  pop rsi
0000710e9ebd7cd3  pop rdi
0000710e9ebd7cd4  pop rdx
0000710e9ebd7cd5  pop rcx
0000710e9ebd7cd6  pop rax
0000710e9ebd7cd7  add rsp, 0x08
0000710e9ebd7cdb  jmp 0x0000710E9EBD33EA
0000710e9ebd7ce0  sub rsp, 0x08
0000710e9ebd7ce4  push rax
0000710e9ebd7ce5  push rcx
0000710e9ebd7ce6  push rdx
0000710e9ebd7ce7  push rdi
0000710e9ebd7ce8  push rsi
0000710e9ebd7ce9  push r8
0000710e9ebd7ceb  push r9
0000710e9ebd7ced  push r10
0000710e9ebd7cef  push r11
0000710e9ebd7cf1  sub rsp, 0xF0
0000710e9ebd7cf8  vmovaps [rsp], xmm0
0000710e9ebd7cfd  vmovaps [rsp+0x10], xmm1
0000710e9ebd7d03  vmovaps [rsp+0x20], xmm2
0000710e9ebd7d09  vmovaps [rsp+0x30], xmm3
0000710e9ebd7d0f  vmovaps [rsp+0x40], xmm4
0000710e9ebd7d15  vmovaps [rsp+0x50], xmm5
0000710e9ebd7d1b  vmovaps [rsp+0x60], xmm6
0000710e9ebd7d21  vmovaps [rsp+0x70], xmm7
0000710e9ebd7d27  vmovaps [rsp+0x80], xmm8
0000710e9ebd7d30  vmovaps [rsp+0x90], xmm10
0000710e9ebd7d39  vmovaps [rsp+0xA0], xmm11
0000710e9ebd7d42  vmovaps [rsp+0xB0], xmm12
0000710e9ebd7d4b  vmovaps [rsp+0xC0], xmm13
0000710e9ebd7d54  vmovaps [rsp+0xD0], xmm14
0000710e9ebd7d5d  vmovaps [rsp+0xE0], xmm15
0000710e9ebd7d66  sub rsp, 0x30
0000710e9ebd7d6a  movaps [rsp], xmm9
0000710e9ebd7d6f  movaps [rsp+0x10], xmm1
0000710e9ebd7d74  movaps [rsp+0x20], xmm15
0000710e9ebd7d7a  lea rdi, [rsp]
0000710e9ebd7d7e  mov esi, 0x00
0000710e9ebd7d83  mov rax, 0x5DADAF7CF530
0000710e9ebd7d8d  call rax
0000710e9ebd7d8f  movaps xmm9, [rsp]
0000710e9ebd7d94  add rsp, 0x30
0000710e9ebd7d98  vmovaps xmm0, [rsp]
0000710e9ebd7d9d  vmovaps xmm1, [rsp+0x10]
0000710e9ebd7da3  vmovaps xmm2, [rsp+0x20]
0000710e9ebd7da9  vmovaps xmm3, [rsp+0x30]
0000710e9ebd7daf  vmovaps xmm4, [rsp+0x40]
0000710e9ebd7db5  vmovaps xmm5, [rsp+0x50]
0000710e9ebd7dbb  vmovaps xmm6, [rsp+0x60]
0000710e9ebd7dc1  vmovaps xmm7, [rsp+0x70]
0000710e9ebd7dc7  vmovaps xmm8, [rsp+0x80]
0000710e9ebd7dd0  vmovaps xmm10, [rsp+0x90]
0000710e9ebd7dd9  vmovaps xmm11, [rsp+0xA0]
0000710e9ebd7de2  vmovaps xmm12, [rsp+0xB0]
0000710e9ebd7deb  vmovaps xmm13, [rsp+0xC0]
0000710e9ebd7df4  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd7dfd  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd7e06  add rsp, 0xF0
0000710e9ebd7e0d  pop r11
0000710e9ebd7e0f  pop r10
0000710e9ebd7e11  pop r9
0000710e9ebd7e13  pop r8
0000710e9ebd7e15  pop rsi
0000710e9ebd7e16  pop rdi
0000710e9ebd7e17  pop rdx
0000710e9ebd7e18  pop rcx
0000710e9ebd7e19  pop rax
0000710e9ebd7e1a  add rsp, 0x08
0000710e9ebd7e1e  jmp 0x0000710E9EBD3418
0000710e9ebd7e23  sub rsp, 0x08
0000710e9ebd7e27  push rax
0000710e9ebd7e28  push rcx
0000710e9ebd7e29  push rdx
0000710e9ebd7e2a  push rdi
0000710e9ebd7e2b  push rsi
0000710e9ebd7e2c  push r8
0000710e9ebd7e2e  push r9
0000710e9ebd7e30  push r10
0000710e9ebd7e32  push r11
0000710e9ebd7e34  sub rsp, 0xF0
0000710e9ebd7e3b  vmovaps [rsp], xmm0
0000710e9ebd7e40  vmovaps [rsp+0x10], xmm1
0000710e9ebd7e46  vmovaps [rsp+0x20], xmm2
0000710e9ebd7e4c  vmovaps [rsp+0x30], xmm3
0000710e9ebd7e52  vmovaps [rsp+0x40], xmm4
0000710e9ebd7e58  vmovaps [rsp+0x50], xmm5
0000710e9ebd7e5e  vmovaps [rsp+0x60], xmm6
0000710e9ebd7e64  vmovaps [rsp+0x70], xmm7
0000710e9ebd7e6a  vmovaps [rsp+0x80], xmm8
0000710e9ebd7e73  vmovaps [rsp+0x90], xmm9
0000710e9ebd7e7c  vmovaps [rsp+0xA0], xmm10
0000710e9ebd7e85  vmovaps [rsp+0xB0], xmm11
0000710e9ebd7e8e  vmovaps [rsp+0xC0], xmm12
0000710e9ebd7e97  vmovaps [rsp+0xD0], xmm13
0000710e9ebd7ea0  vmovaps [rsp+0xE0], xmm14
0000710e9ebd7ea9  sub rsp, 0x30
0000710e9ebd7ead  movaps [rsp], xmm15
0000710e9ebd7eb2  movaps [rsp+0x10], xmm4
0000710e9ebd7eb7  movaps [rsp+0x20], xmm1
0000710e9ebd7ebc  lea rdi, [rsp]
0000710e9ebd7ec0  mov esi, 0x00
0000710e9ebd7ec5  mov rax, 0x5DADAF7CF530
0000710e9ebd7ecf  call rax
0000710e9ebd7ed1  movaps xmm15, [rsp]
0000710e9ebd7ed6  add rsp, 0x30
0000710e9ebd7eda  vmovaps xmm0, [rsp]
0000710e9ebd7edf  vmovaps xmm1, [rsp+0x10]
0000710e9ebd7ee5  vmovaps xmm2, [rsp+0x20]
0000710e9ebd7eeb  vmovaps xmm3, [rsp+0x30]
0000710e9ebd7ef1  vmovaps xmm4, [rsp+0x40]
0000710e9ebd7ef7  vmovaps xmm5, [rsp+0x50]
0000710e9ebd7efd  vmovaps xmm6, [rsp+0x60]
0000710e9ebd7f03  vmovaps xmm7, [rsp+0x70]
0000710e9ebd7f09  vmovaps xmm8, [rsp+0x80]
0000710e9ebd7f12  vmovaps xmm9, [rsp+0x90]
0000710e9ebd7f1b  vmovaps xmm10, [rsp+0xA0]
0000710e9ebd7f24  vmovaps xmm11, [rsp+0xB0]
0000710e9ebd7f2d  vmovaps xmm12, [rsp+0xC0]
0000710e9ebd7f36  vmovaps xmm13, [rsp+0xD0]
0000710e9ebd7f3f  vmovaps xmm14, [rsp+0xE0]
0000710e9ebd7f48  add rsp, 0xF0
0000710e9ebd7f4f  pop r11
0000710e9ebd7f51  pop r10
0000710e9ebd7f53  pop r9
0000710e9ebd7f55  pop r8
0000710e9ebd7f57  pop rsi
0000710e9ebd7f58  pop rdi
0000710e9ebd7f59  pop rdx
0000710e9ebd7f5a  pop rcx
0000710e9ebd7f5b  pop rax
0000710e9ebd7f5c  add rsp, 0x08
0000710e9ebd7f60  jmp 0x0000710E9EBD343E
0000710e9ebd7f65  sub rsp, 0x08
0000710e9ebd7f69  push rax
0000710e9ebd7f6a  push rcx
0000710e9ebd7f6b  push rdx
0000710e9ebd7f6c  push rdi
0000710e9ebd7f6d  push rsi
0000710e9ebd7f6e  push r8
0000710e9ebd7f70  push r9
0000710e9ebd7f72  push r10
0000710e9ebd7f74  push r11
0000710e9ebd7f76  sub rsp, 0xF0
0000710e9ebd7f7d  vmovaps [rsp], xmm0
0000710e9ebd7f82  vmovaps [rsp+0x10], xmm2
0000710e9ebd7f88  vmovaps [rsp+0x20], xmm3
0000710e9ebd7f8e  vmovaps [rsp+0x30], xmm4
0000710e9ebd7f94  vmovaps [rsp+0x40], xmm5
0000710e9ebd7f9a  vmovaps [rsp+0x50], xmm6
0000710e9ebd7fa0  vmovaps [rsp+0x60], xmm7
0000710e9ebd7fa6  vmovaps [rsp+0x70], xmm8
0000710e9ebd7fac  vmovaps [rsp+0x80], xmm9
0000710e9ebd7fb5  vmovaps [rsp+0x90], xmm10
0000710e9ebd7fbe  vmovaps [rsp+0xA0], xmm11
0000710e9ebd7fc7  vmovaps [rsp+0xB0], xmm12
0000710e9ebd7fd0  vmovaps [rsp+0xC0], xmm13
0000710e9ebd7fd9  vmovaps [rsp+0xD0], xmm14
0000710e9ebd7fe2  vmovaps [rsp+0xE0], xmm15
0000710e9ebd7feb  sub rsp, 0x30
0000710e9ebd7fef  movaps [rsp], xmm1
0000710e9ebd7ff3  movaps [rsp+0x10], xmm14
0000710e9ebd7ff9  movaps [rsp+0x20], xmm11
0000710e9ebd7fff  lea rdi, [rsp]
0000710e9ebd8003  mov esi, 0x00
0000710e9ebd8008  mov rax, 0x5DADAF7CF530
0000710e9ebd8012  call rax
0000710e9ebd8014  movaps xmm1, [rsp]
0000710e9ebd8018  add rsp, 0x30
0000710e9ebd801c  vmovaps xmm0, [rsp]
0000710e9ebd8021  vmovaps xmm2, [rsp+0x10]
0000710e9ebd8027  vmovaps xmm3, [rsp+0x20]
0000710e9ebd802d  vmovaps xmm4, [rsp+0x30]
0000710e9ebd8033  vmovaps xmm5, [rsp+0x40]
0000710e9ebd8039  vmovaps xmm6, [rsp+0x50]
0000710e9ebd803f  vmovaps xmm7, [rsp+0x60]
0000710e9ebd8045  vmovaps xmm8, [rsp+0x70]
0000710e9ebd804b  vmovaps xmm9, [rsp+0x80]
0000710e9ebd8054  vmovaps xmm10, [rsp+0x90]
0000710e9ebd805d  vmovaps xmm11, [rsp+0xA0]
0000710e9ebd8066  vmovaps xmm12, [rsp+0xB0]
0000710e9ebd806f  vmovaps xmm13, [rsp+0xC0]
0000710e9ebd8078  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd8081  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd808a  add rsp, 0xF0
0000710e9ebd8091  pop r11
0000710e9ebd8093  pop r10
0000710e9ebd8095  pop r9
0000710e9ebd8097  pop r8
0000710e9ebd8099  pop rsi
0000710e9ebd809a  pop rdi
0000710e9ebd809b  pop rdx
0000710e9ebd809c  pop rcx
0000710e9ebd809d  pop rax
0000710e9ebd809e  add rsp, 0x08
0000710e9ebd80a2  jmp 0x0000710E9EBD345F
0000710e9ebd80a7  call 0x0000710E9EAE45A0
0000710e9ebd80ac  jmp 0x0000710E9EBD346D
0000710e9ebd80b1  call 0x0000710E9EA09D70
0000710e9ebd80b6  jmp 0x0000710E9EBD3477
0000710e9ebd80bb  sub rsp, 0x08
0000710e9ebd80bf  push rax
0000710e9ebd80c0  push rcx
0000710e9ebd80c1  push rdx
0000710e9ebd80c2  push rdi
0000710e9ebd80c3  push rsi
0000710e9ebd80c4  push r8
0000710e9ebd80c6  push r9
0000710e9ebd80c8  push r10
0000710e9ebd80ca  push r11
0000710e9ebd80cc  sub rsp, 0xF0
0000710e9ebd80d3  vmovaps [rsp], xmm0
0000710e9ebd80d8  vmovaps [rsp+0x10], xmm1
0000710e9ebd80de  vmovaps [rsp+0x20], xmm2
0000710e9ebd80e4  vmovaps [rsp+0x30], xmm3
0000710e9ebd80ea  vmovaps [rsp+0x40], xmm4
0000710e9ebd80f0  vmovaps [rsp+0x50], xmm5
0000710e9ebd80f6  vmovaps [rsp+0x60], xmm6
0000710e9ebd80fc  vmovaps [rsp+0x70], xmm8
0000710e9ebd8102  vmovaps [rsp+0x80], xmm9
0000710e9ebd810b  vmovaps [rsp+0x90], xmm10
0000710e9ebd8114  vmovaps [rsp+0xA0], xmm11
0000710e9ebd811d  vmovaps [rsp+0xB0], xmm12
0000710e9ebd8126  vmovaps [rsp+0xC0], xmm13
0000710e9ebd812f  vmovaps [rsp+0xD0], xmm14
0000710e9ebd8138  vmovaps [rsp+0xE0], xmm15
0000710e9ebd8141  sub rsp, 0x30
0000710e9ebd8145  movaps [rsp], xmm7
0000710e9ebd8149  movaps [rsp+0x10], xmm13
0000710e9ebd814f  movaps [rsp+0x20], xmm10
0000710e9ebd8155  lea rdi, [rsp]
0000710e9ebd8159  mov esi, 0x00
0000710e9ebd815e  mov rax, 0x5DADAF7CF530
0000710e9ebd8168  call rax
0000710e9ebd816a  movaps xmm7, [rsp]
0000710e9ebd816e  add rsp, 0x30
0000710e9ebd8172  vmovaps xmm0, [rsp]
0000710e9ebd8177  vmovaps xmm1, [rsp+0x10]
0000710e9ebd817d  vmovaps xmm2, [rsp+0x20]
0000710e9ebd8183  vmovaps xmm3, [rsp+0x30]
0000710e9ebd8189  vmovaps xmm4, [rsp+0x40]
0000710e9ebd818f  vmovaps xmm5, [rsp+0x50]
0000710e9ebd8195  vmovaps xmm6, [rsp+0x60]
0000710e9ebd819b  vmovaps xmm8, [rsp+0x70]
0000710e9ebd81a1  vmovaps xmm9, [rsp+0x80]
0000710e9ebd81aa  vmovaps xmm10, [rsp+0x90]
0000710e9ebd81b3  vmovaps xmm11, [rsp+0xA0]
0000710e9ebd81bc  vmovaps xmm12, [rsp+0xB0]
0000710e9ebd81c5  vmovaps xmm13, [rsp+0xC0]
0000710e9ebd81ce  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd81d7  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd81e0  add rsp, 0xF0
0000710e9ebd81e7  pop r11
0000710e9ebd81e9  pop r10
0000710e9ebd81eb  pop r9
0000710e9ebd81ed  pop r8
0000710e9ebd81ef  pop rsi
0000710e9ebd81f0  pop rdi
0000710e9ebd81f1  pop rdx
0000710e9ebd81f2  pop rcx
0000710e9ebd81f3  pop rax
0000710e9ebd81f4  add rsp, 0x08
0000710e9ebd81f8  jmp 0x0000710E9EBD3498
0000710e9ebd81fd  sub rsp, 0x08
0000710e9ebd8201  push rax
0000710e9ebd8202  push rcx
0000710e9ebd8203  push rdx
0000710e9ebd8204  push rdi
0000710e9ebd8205  push rsi
0000710e9ebd8206  push r8
0000710e9ebd8208  push r9
0000710e9ebd820a  push r10
0000710e9ebd820c  push r11
0000710e9ebd820e  sub rsp, 0xF0
0000710e9ebd8215  vmovaps [rsp], xmm0
0000710e9ebd821a  vmovaps [rsp+0x10], xmm1
0000710e9ebd8220  vmovaps [rsp+0x20], xmm2
0000710e9ebd8226  vmovaps [rsp+0x30], xmm3
0000710e9ebd822c  vmovaps [rsp+0x40], xmm4
0000710e9ebd8232  vmovaps [rsp+0x50], xmm5
0000710e9ebd8238  vmovaps [rsp+0x60], xmm6
0000710e9ebd823e  vmovaps [rsp+0x70], xmm7
0000710e9ebd8244  vmovaps [rsp+0x80], xmm8
0000710e9ebd824d  vmovaps [rsp+0x90], xmm9
0000710e9ebd8256  vmovaps [rsp+0xA0], xmm11
0000710e9ebd825f  vmovaps [rsp+0xB0], xmm12
0000710e9ebd8268  vmovaps [rsp+0xC0], xmm13
0000710e9ebd8271  vmovaps [rsp+0xD0], xmm14
0000710e9ebd827a  vmovaps [rsp+0xE0], xmm15
0000710e9ebd8283  sub rsp, 0x30
0000710e9ebd8287  movaps [rsp], xmm10
0000710e9ebd828c  movaps [rsp+0x10], xmm11
0000710e9ebd8292  movaps [rsp+0x20], xmm13
0000710e9ebd8298  lea rdi, [rsp]
0000710e9ebd829c  mov esi, 0x00
0000710e9ebd82a1  mov rax, 0x5DADAF7CF530
0000710e9ebd82ab  call rax
0000710e9ebd82ad  movaps xmm10, [rsp]
0000710e9ebd82b2  add rsp, 0x30
0000710e9ebd82b6  vmovaps xmm0, [rsp]
0000710e9ebd82bb  vmovaps xmm1, [rsp+0x10]
0000710e9ebd82c1  vmovaps xmm2, [rsp+0x20]
0000710e9ebd82c7  vmovaps xmm3, [rsp+0x30]
0000710e9ebd82cd  vmovaps xmm4, [rsp+0x40]
0000710e9ebd82d3  vmovaps xmm5, [rsp+0x50]
0000710e9ebd82d9  vmovaps xmm6, [rsp+0x60]
0000710e9ebd82df  vmovaps xmm7, [rsp+0x70]
0000710e9ebd82e5  vmovaps xmm8, [rsp+0x80]
0000710e9ebd82ee  vmovaps xmm9, [rsp+0x90]
0000710e9ebd82f7  vmovaps xmm11, [rsp+0xA0]
0000710e9ebd8300  vmovaps xmm12, [rsp+0xB0]
0000710e9ebd8309  vmovaps xmm13, [rsp+0xC0]
0000710e9ebd8312  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd831b  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd8324  add rsp, 0xF0
0000710e9ebd832b  pop r11
0000710e9ebd832d  pop r10
0000710e9ebd832f  pop r9
0000710e9ebd8331  pop r8
0000710e9ebd8333  pop rsi
0000710e9ebd8334  pop rdi
0000710e9ebd8335  pop rdx
0000710e9ebd8336  pop rcx
0000710e9ebd8337  pop rax
0000710e9ebd8338  add rsp, 0x08
0000710e9ebd833c  jmp 0x0000710E9EBD34C6
0000710e9ebd8341  sub rsp, 0x08
0000710e9ebd8345  push rax
0000710e9ebd8346  push rcx
0000710e9ebd8347  push rdx
0000710e9ebd8348  push rdi
0000710e9ebd8349  push rsi
0000710e9ebd834a  push r8
0000710e9ebd834c  push r9
0000710e9ebd834e  push r10
0000710e9ebd8350  push r11
0000710e9ebd8352  sub rsp, 0xF0
0000710e9ebd8359  vmovaps [rsp], xmm0
0000710e9ebd835e  vmovaps [rsp+0x10], xmm1
0000710e9ebd8364  vmovaps [rsp+0x20], xmm2
0000710e9ebd836a  vmovaps [rsp+0x30], xmm3
0000710e9ebd8370  vmovaps [rsp+0x40], xmm4
0000710e9ebd8376  vmovaps [rsp+0x50], xmm5
0000710e9ebd837c  vmovaps [rsp+0x60], xmm6
0000710e9ebd8382  vmovaps [rsp+0x70], xmm7
0000710e9ebd8388  vmovaps [rsp+0x80], xmm8
0000710e9ebd8391  vmovaps [rsp+0x90], xmm9
0000710e9ebd839a  vmovaps [rsp+0xA0], xmm10
0000710e9ebd83a3  vmovaps [rsp+0xB0], xmm12
0000710e9ebd83ac  vmovaps [rsp+0xC0], xmm13
0000710e9ebd83b5  vmovaps [rsp+0xD0], xmm14
0000710e9ebd83be  vmovaps [rsp+0xE0], xmm15
0000710e9ebd83c7  sub rsp, 0x30
0000710e9ebd83cb  movaps [rsp], xmm11
0000710e9ebd83d0  movaps [rsp+0x10], xmm14
0000710e9ebd83d6  movaps [rsp+0x20], xmm13
0000710e9ebd83dc  lea rdi, [rsp]
0000710e9ebd83e0  mov esi, 0x00
0000710e9ebd83e5  mov rax, 0x5DADAF7CF530
0000710e9ebd83ef  call rax
0000710e9ebd83f1  movaps xmm11, [rsp]
0000710e9ebd83f6  add rsp, 0x30
0000710e9ebd83fa  vmovaps xmm0, [rsp]
0000710e9ebd83ff  vmovaps xmm1, [rsp+0x10]
0000710e9ebd8405  vmovaps xmm2, [rsp+0x20]
0000710e9ebd840b  vmovaps xmm3, [rsp+0x30]
0000710e9ebd8411  vmovaps xmm4, [rsp+0x40]
0000710e9ebd8417  vmovaps xmm5, [rsp+0x50]
0000710e9ebd841d  vmovaps xmm6, [rsp+0x60]
0000710e9ebd8423  vmovaps xmm7, [rsp+0x70]
0000710e9ebd8429  vmovaps xmm8, [rsp+0x80]
0000710e9ebd8432  vmovaps xmm9, [rsp+0x90]
0000710e9ebd843b  vmovaps xmm10, [rsp+0xA0]
0000710e9ebd8444  vmovaps xmm12, [rsp+0xB0]
0000710e9ebd844d  vmovaps xmm13, [rsp+0xC0]
0000710e9ebd8456  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd845f  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd8468  add rsp, 0xF0
0000710e9ebd846f  pop r11
0000710e9ebd8471  pop r10
0000710e9ebd8473  pop r9
0000710e9ebd8475  pop r8
0000710e9ebd8477  pop rsi
0000710e9ebd8478  pop rdi
0000710e9ebd8479  pop rdx
0000710e9ebd847a  pop rcx
0000710e9ebd847b  pop rax
0000710e9ebd847c  add rsp, 0x08
0000710e9ebd8480  jmp 0x0000710E9EBD34F4
0000710e9ebd8485  sub rsp, 0x08
0000710e9ebd8489  push rax
0000710e9ebd848a  push rcx
0000710e9ebd848b  push rdx
0000710e9ebd848c  push rdi
0000710e9ebd848d  push rsi
0000710e9ebd848e  push r8
0000710e9ebd8490  push r9
0000710e9ebd8492  push r10
0000710e9ebd8494  push r11
0000710e9ebd8496  sub rsp, 0xF0
0000710e9ebd849d  vmovaps [rsp], xmm0
0000710e9ebd84a2  vmovaps [rsp+0x10], xmm1
0000710e9ebd84a8  vmovaps [rsp+0x20], xmm2
0000710e9ebd84ae  vmovaps [rsp+0x30], xmm3
0000710e9ebd84b4  vmovaps [rsp+0x40], xmm4
0000710e9ebd84ba  vmovaps [rsp+0x50], xmm5
0000710e9ebd84c0  vmovaps [rsp+0x60], xmm6
0000710e9ebd84c6  vmovaps [rsp+0x70], xmm7
0000710e9ebd84cc  vmovaps [rsp+0x80], xmm8
0000710e9ebd84d5  vmovaps [rsp+0x90], xmm9
0000710e9ebd84de  vmovaps [rsp+0xA0], xmm10
0000710e9ebd84e7  vmovaps [rsp+0xB0], xmm11
0000710e9ebd84f0  vmovaps [rsp+0xC0], xmm12
0000710e9ebd84f9  vmovaps [rsp+0xD0], xmm13
0000710e9ebd8502  vmovaps [rsp+0xE0], xmm15
0000710e9ebd850b  sub rsp, 0x30
0000710e9ebd850f  movaps [rsp], xmm14
0000710e9ebd8514  movaps [rsp+0x10], xmm12
0000710e9ebd851a  movaps [rsp+0x20], xmm9
0000710e9ebd8520  lea rdi, [rsp]
0000710e9ebd8524  mov esi, 0x00
0000710e9ebd8529  mov rax, 0x5DADAF7CF530
0000710e9ebd8533  call rax
0000710e9ebd8535  movaps xmm14, [rsp]
0000710e9ebd853a  add rsp, 0x30
0000710e9ebd853e  vmovaps xmm0, [rsp]
0000710e9ebd8543  vmovaps xmm1, [rsp+0x10]
0000710e9ebd8549  vmovaps xmm2, [rsp+0x20]
0000710e9ebd854f  vmovaps xmm3, [rsp+0x30]
0000710e9ebd8555  vmovaps xmm4, [rsp+0x40]
0000710e9ebd855b  vmovaps xmm5, [rsp+0x50]
0000710e9ebd8561  vmovaps xmm6, [rsp+0x60]
0000710e9ebd8567  vmovaps xmm7, [rsp+0x70]
0000710e9ebd856d  vmovaps xmm8, [rsp+0x80]
0000710e9ebd8576  vmovaps xmm9, [rsp+0x90]
0000710e9ebd857f  vmovaps xmm10, [rsp+0xA0]
0000710e9ebd8588  vmovaps xmm11, [rsp+0xB0]
0000710e9ebd8591  vmovaps xmm12, [rsp+0xC0]
0000710e9ebd859a  vmovaps xmm13, [rsp+0xD0]
0000710e9ebd85a3  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd85ac  add rsp, 0xF0
0000710e9ebd85b3  pop r11
0000710e9ebd85b5  pop r10
0000710e9ebd85b7  pop r9
0000710e9ebd85b9  pop r8
0000710e9ebd85bb  pop rsi
0000710e9ebd85bc  pop rdi
0000710e9ebd85bd  pop rdx
0000710e9ebd85be  pop rcx
0000710e9ebd85bf  pop rax
0000710e9ebd85c0  add rsp, 0x08
0000710e9ebd85c4  jmp 0x0000710E9EBD350F
0000710e9ebd85c9  sub rsp, 0x08
0000710e9ebd85cd  push rax
0000710e9ebd85ce  push rcx
0000710e9ebd85cf  push rdx
0000710e9ebd85d0  push rdi
0000710e9ebd85d1  push rsi
0000710e9ebd85d2  push r8
0000710e9ebd85d4  push r9
0000710e9ebd85d6  push r10
0000710e9ebd85d8  push r11
0000710e9ebd85da  sub rsp, 0xF0
0000710e9ebd85e1  vmovaps [rsp], xmm0
0000710e9ebd85e6  vmovaps [rsp+0x10], xmm1
0000710e9ebd85ec  vmovaps [rsp+0x20], xmm2
0000710e9ebd85f2  vmovaps [rsp+0x30], xmm3
0000710e9ebd85f8  vmovaps [rsp+0x40], xmm4
0000710e9ebd85fe  vmovaps [rsp+0x50], xmm5
0000710e9ebd8604  vmovaps [rsp+0x60], xmm6
0000710e9ebd860a  vmovaps [rsp+0x70], xmm7
0000710e9ebd8610  vmovaps [rsp+0x80], xmm8
0000710e9ebd8619  vmovaps [rsp+0x90], xmm9
0000710e9ebd8622  vmovaps [rsp+0xA0], xmm10
0000710e9ebd862b  vmovaps [rsp+0xB0], xmm11
0000710e9ebd8634  vmovaps [rsp+0xC0], xmm12
0000710e9ebd863d  vmovaps [rsp+0xD0], xmm14
0000710e9ebd8646  vmovaps [rsp+0xE0], xmm15
0000710e9ebd864f  sub rsp, 0x30
0000710e9ebd8653  movaps [rsp], xmm13
0000710e9ebd8658  movaps [rsp+0x10], xmm8
0000710e9ebd865e  movaps [rsp+0x20], xmm15
0000710e9ebd8664  lea rdi, [rsp]
0000710e9ebd8668  mov esi, 0x00
0000710e9ebd866d  mov rax, 0x5DADAF7CF530
0000710e9ebd8677  call rax
0000710e9ebd8679  movaps xmm13, [rsp]
0000710e9ebd867e  add rsp, 0x30
0000710e9ebd8682  vmovaps xmm0, [rsp]
0000710e9ebd8687  vmovaps xmm1, [rsp+0x10]
0000710e9ebd868d  vmovaps xmm2, [rsp+0x20]
0000710e9ebd8693  vmovaps xmm3, [rsp+0x30]
0000710e9ebd8699  vmovaps xmm4, [rsp+0x40]
0000710e9ebd869f  vmovaps xmm5, [rsp+0x50]
0000710e9ebd86a5  vmovaps xmm6, [rsp+0x60]
0000710e9ebd86ab  vmovaps xmm7, [rsp+0x70]
0000710e9ebd86b1  vmovaps xmm8, [rsp+0x80]
0000710e9ebd86ba  vmovaps xmm9, [rsp+0x90]
0000710e9ebd86c3  vmovaps xmm10, [rsp+0xA0]
0000710e9ebd86cc  vmovaps xmm11, [rsp+0xB0]
0000710e9ebd86d5  vmovaps xmm12, [rsp+0xC0]
0000710e9ebd86de  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd86e7  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd86f0  add rsp, 0xF0
0000710e9ebd86f7  pop r11
0000710e9ebd86f9  pop r10
0000710e9ebd86fb  pop r9
0000710e9ebd86fd  pop r8
0000710e9ebd86ff  pop rsi
0000710e9ebd8700  pop rdi
0000710e9ebd8701  pop rdx
0000710e9ebd8702  pop rcx
0000710e9ebd8703  pop rax
0000710e9ebd8704  add rsp, 0x08
0000710e9ebd8708  jmp 0x0000710E9EBD3532
0000710e9ebd870d  sub rsp, 0x08
0000710e9ebd8711  push rax
0000710e9ebd8712  push rcx
0000710e9ebd8713  push rdx
0000710e9ebd8714  push rdi
0000710e9ebd8715  push rsi
0000710e9ebd8716  push r8
0000710e9ebd8718  push r9
0000710e9ebd871a  push r10
0000710e9ebd871c  push r11
0000710e9ebd871e  sub rsp, 0xF0
0000710e9ebd8725  vmovaps [rsp], xmm0
0000710e9ebd872a  vmovaps [rsp+0x10], xmm1
0000710e9ebd8730  vmovaps [rsp+0x20], xmm2
0000710e9ebd8736  vmovaps [rsp+0x30], xmm3
0000710e9ebd873c  vmovaps [rsp+0x40], xmm4
0000710e9ebd8742  vmovaps [rsp+0x50], xmm5
0000710e9ebd8748  vmovaps [rsp+0x60], xmm6
0000710e9ebd874e  vmovaps [rsp+0x70], xmm7
0000710e9ebd8754  vmovaps [rsp+0x80], xmm8
0000710e9ebd875d  vmovaps [rsp+0x90], xmm9
0000710e9ebd8766  vmovaps [rsp+0xA0], xmm10
0000710e9ebd876f  vmovaps [rsp+0xB0], xmm11
0000710e9ebd8778  vmovaps [rsp+0xC0], xmm12
0000710e9ebd8781  vmovaps [rsp+0xD0], xmm13
0000710e9ebd878a  vmovaps [rsp+0xE0], xmm14
0000710e9ebd8793  sub rsp, 0x30
0000710e9ebd8797  movaps [rsp], xmm15
0000710e9ebd879c  movaps [rsp+0x10], xmm1
0000710e9ebd87a1  movaps [rsp+0x20], xmm10
0000710e9ebd87a7  lea rdi, [rsp]
0000710e9ebd87ab  mov esi, 0x00
0000710e9ebd87b0  mov rax, 0x5DADAF7CF530
0000710e9ebd87ba  call rax
0000710e9ebd87bc  movaps xmm15, [rsp]
0000710e9ebd87c1  add rsp, 0x30
0000710e9ebd87c5  vmovaps xmm0, [rsp]
0000710e9ebd87ca  vmovaps xmm1, [rsp+0x10]
0000710e9ebd87d0  vmovaps xmm2, [rsp+0x20]
0000710e9ebd87d6  vmovaps xmm3, [rsp+0x30]
0000710e9ebd87dc  vmovaps xmm4, [rsp+0x40]
0000710e9ebd87e2  vmovaps xmm5, [rsp+0x50]
0000710e9ebd87e8  vmovaps xmm6, [rsp+0x60]
0000710e9ebd87ee  vmovaps xmm7, [rsp+0x70]
0000710e9ebd87f4  vmovaps xmm8, [rsp+0x80]
0000710e9ebd87fd  vmovaps xmm9, [rsp+0x90]
0000710e9ebd8806  vmovaps xmm10, [rsp+0xA0]
0000710e9ebd880f  vmovaps xmm11, [rsp+0xB0]
0000710e9ebd8818  vmovaps xmm12, [rsp+0xC0]
0000710e9ebd8821  vmovaps xmm13, [rsp+0xD0]
0000710e9ebd882a  vmovaps xmm14, [rsp+0xE0]
0000710e9ebd8833  add rsp, 0xF0
0000710e9ebd883a  pop r11
0000710e9ebd883c  pop r10
0000710e9ebd883e  pop r9
0000710e9ebd8840  pop r8
0000710e9ebd8842  pop rsi
0000710e9ebd8843  pop rdi
0000710e9ebd8844  pop rdx
0000710e9ebd8845  pop rcx
0000710e9ebd8846  pop rax
0000710e9ebd8847  add rsp, 0x08
0000710e9ebd884b  jmp 0x0000710E9EBD3555
0000710e9ebd8850  sub rsp, 0x08
0000710e9ebd8854  push rax
0000710e9ebd8855  push rcx
0000710e9ebd8856  push rdx
0000710e9ebd8857  push rdi
0000710e9ebd8858  push rsi
0000710e9ebd8859  push r8
0000710e9ebd885b  push r9
0000710e9ebd885d  push r10
0000710e9ebd885f  push r11
0000710e9ebd8861  sub rsp, 0xF0
0000710e9ebd8868  vmovaps [rsp], xmm0
0000710e9ebd886d  vmovaps [rsp+0x10], xmm2
0000710e9ebd8873  vmovaps [rsp+0x20], xmm3
0000710e9ebd8879  vmovaps [rsp+0x30], xmm4
0000710e9ebd887f  vmovaps [rsp+0x40], xmm5
0000710e9ebd8885  vmovaps [rsp+0x50], xmm6
0000710e9ebd888b  vmovaps [rsp+0x60], xmm7
0000710e9ebd8891  vmovaps [rsp+0x70], xmm8
0000710e9ebd8897  vmovaps [rsp+0x80], xmm9
0000710e9ebd88a0  vmovaps [rsp+0x90], xmm10
0000710e9ebd88a9  vmovaps [rsp+0xA0], xmm11
0000710e9ebd88b2  vmovaps [rsp+0xB0], xmm12
0000710e9ebd88bb  vmovaps [rsp+0xC0], xmm13
0000710e9ebd88c4  vmovaps [rsp+0xD0], xmm14
0000710e9ebd88cd  vmovaps [rsp+0xE0], xmm15
0000710e9ebd88d6  sub rsp, 0x30
0000710e9ebd88da  movaps [rsp], xmm1
0000710e9ebd88de  movaps [rsp+0x10], xmm7
0000710e9ebd88e3  movaps [rsp+0x20], xmm11
0000710e9ebd88e9  lea rdi, [rsp]
0000710e9ebd88ed  mov esi, 0x00
0000710e9ebd88f2  mov rax, 0x5DADAF7CF530
0000710e9ebd88fc  call rax
0000710e9ebd88fe  movaps xmm1, [rsp]
0000710e9ebd8902  add rsp, 0x30
0000710e9ebd8906  vmovaps xmm0, [rsp]
0000710e9ebd890b  vmovaps xmm2, [rsp+0x10]
0000710e9ebd8911  vmovaps xmm3, [rsp+0x20]
0000710e9ebd8917  vmovaps xmm4, [rsp+0x30]
0000710e9ebd891d  vmovaps xmm5, [rsp+0x40]
0000710e9ebd8923  vmovaps xmm6, [rsp+0x50]
0000710e9ebd8929  vmovaps xmm7, [rsp+0x60]
0000710e9ebd892f  vmovaps xmm8, [rsp+0x70]
0000710e9ebd8935  vmovaps xmm9, [rsp+0x80]
0000710e9ebd893e  vmovaps xmm10, [rsp+0x90]
0000710e9ebd8947  vmovaps xmm11, [rsp+0xA0]
0000710e9ebd8950  vmovaps xmm12, [rsp+0xB0]
0000710e9ebd8959  vmovaps xmm13, [rsp+0xC0]
0000710e9ebd8962  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd896b  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd8974  add rsp, 0xF0
0000710e9ebd897b  pop r11
0000710e9ebd897d  pop r10
0000710e9ebd897f  pop r9
0000710e9ebd8981  pop r8
0000710e9ebd8983  pop rsi
0000710e9ebd8984  pop rdi
0000710e9ebd8985  pop rdx
0000710e9ebd8986  pop rcx
0000710e9ebd8987  pop rax
0000710e9ebd8988  add rsp, 0x08
0000710e9ebd898c  jmp 0x0000710E9EBD3576
0000710e9ebd8991  call 0x0000710E9EA0D600
0000710e9ebd8996  jmp 0x0000710E9EBD3589
0000710e9ebd899b  call 0x0000710E9EA0C380
0000710e9ebd89a0  jmp 0x0000710E9EBD3594
0000710e9ebd89a5  call 0x0000710E9EA0E880
0000710e9ebd89aa  jmp 0x0000710E9EBD359F
0000710e9ebd89af  call 0x0000710E9E9FF540
0000710e9ebd89b4  jmp 0x0000710E9EBD35AA
0000710e9ebd89b9  int3
0000710e9ebd89ba  nop [rax+rax*1], ax
0000710e9ebd89c0  mov rax, [r15+0x40]
0000710e9ebd89c4  mov r14, [r15+0x58]
0000710e9ebd89c8  lea r12, [rax+r14*1]
0000710e9ebd89cc  movaps xmm1, [r15+0x1D0]
0000710e9ebd89d4  vmovaps [rsp+0x10], xmm1
0000710e9ebd89da  vmovaps xmm15, [rsp+0x10]
0000710e9ebd89e0  por xmm1, xmm15
0000710e9ebd89e5  movaps xmm14, [r15+0x1A0]
0000710e9ebd89ed  vmovaps [rsp+0x10], xmm14
0000710e9ebd89f3  vmovaps xmm13, [rsp+0x10]
0000710e9ebd89f9  por xmm14, xmm13
0000710e9ebd89fe  lea rax, [r12+0x30]
0000710e9ebd8a03  mov r11, [r13+rax*1]
0000710e9ebd8a08  lea rax, [r12+0x38]
0000710e9ebd8a0d  mov r10, [r13+rax*1]
0000710e9ebd8a12  movq xmm13, r11
0000710e9ebd8a17  movq xmm12, r10
0000710e9ebd8a1c  movq xmm13, xmm13
0000710e9ebd8a21  vmovaps [rsp+0x10], xmm13
0000710e9ebd8a27  movq xmm13, xmm13
0000710e9ebd8a2c  movaps [r15+0x130], xmm13
0000710e9ebd8a34  movq xmm12, xmm12
0000710e9ebd8a39  vmovaps [rsp+0x20], xmm12
0000710e9ebd8a3f  movq xmm12, xmm12
0000710e9ebd8a44  movaps [r15+0x280], xmm12
0000710e9ebd8a4c  movaps xmm13, [r15+0x270]
0000710e9ebd8a54  vmovaps [rsp+0x30], xmm13
0000710e9ebd8a5a  vmovaps xmm12, [rsp+0x30]
0000710e9ebd8a60  por xmm13, xmm12
0000710e9ebd8a65  lea rax, [r12+0x20]
0000710e9ebd8a6a  mov r11, [r13+rax*1]
0000710e9ebd8a6f  lea rax, [r12+0x28]
0000710e9ebd8a74  mov r10, [r13+rax*1]
0000710e9ebd8a79  movq xmm12, r11
0000710e9ebd8a7e  movq xmm11, r10
0000710e9ebd8a83  movq xmm12, xmm12
0000710e9ebd8a88  vmovaps [rsp+0x30], xmm12
0000710e9ebd8a8e  movq xmm12, xmm12
0000710e9ebd8a93  movaps [r15+0x150], xmm12
0000710e9ebd8a9b  movq xmm11, xmm11
0000710e9ebd8aa0  vmovaps [rsp+0x40], xmm11
0000710e9ebd8aa6  movq xmm11, xmm11
0000710e9ebd8aab  movaps [r15+0x140], xmm11
0000710e9ebd8ab3  lea rax, [r12+0x10]
0000710e9ebd8ab8  mov r11, [r13+rax*1]
0000710e9ebd8abd  lea rax, [r12+0x18]
0000710e9ebd8ac2  mov r10, [r13+rax*1]
0000710e9ebd8ac7  movq xmm12, r11
0000710e9ebd8acc  movq xmm11, r10
0000710e9ebd8ad1  movq xmm12, xmm12
0000710e9ebd8ad6  vmovaps [rsp+0x50], xmm12
0000710e9ebd8adc  movq xmm12, xmm12
0000710e9ebd8ae1  movaps [r15+0x170], xmm12
0000710e9ebd8ae9  movq xmm11, xmm11
0000710e9ebd8aee  vmovaps [rsp+0x60], xmm11
0000710e9ebd8af4  movq xmm11, xmm11
0000710e9ebd8af9  movaps [r15+0x160], xmm11
0000710e9ebd8b01  mov rax, [r13+r12*1]
0000710e9ebd8b06  vmovq xmm12, rax
0000710e9ebd8b0b  vpbroadcastq xmm12, xmm12
0000710e9ebd8b10  lea rax, [r12+0x08]
0000710e9ebd8b15  mov r12, [r13+rax*1]
0000710e9ebd8b1a  movq xmm11, r12
0000710e9ebd8b1f  movaps [r15+0x230], xmm11
0000710e9ebd8b27  mov rax, [r15+0xF8]
0000710e9ebd8b2e  lea r12, [rax+0x50]
0000710e9ebd8b32  movups xmm11, [r13+r12*1]
0000710e9ebd8b38  lea r12, [rax+0x60]
0000710e9ebd8b3c  movups xmm10, [r13+r12*1]
0000710e9ebd8b42  lea r12, [rax+0x30]
0000710e9ebd8b46  movups xmm9, [r13+r12*1]
0000710e9ebd8b4c  mov r12, [r15+0x50]
0000710e9ebd8b50  lea r11, [r12+r14*1]
0000710e9ebd8b54  mov [r15+0x60], r11
0000710e9ebd8b58  lea r12, [r14+0x40]
0000710e9ebd8b5c  mov [r15+0x58], r12
0000710e9ebd8b60  movaps xmm8, xmm12
0000710e9ebd8b64  mulpd xmm8, xmm15
0000710e9ebd8b69  vcmppd xmm7, xmm8, xmm8, 0x03
0000710e9ebd8b6f  ptest xmm7, xmm7
0000710e9ebd8b74  jnz 0x0000710E9EBD9997
0000710e9ebd8b7a  movq xmm15, qword ptr [r15+0x230]
0000710e9ebd8b83  vmovaps [rsp+0x70], xmm15
0000710e9ebd8b89  vpermilpd xmm15, xmm15, 0x00
0000710e9ebd8b8f  movaps xmm7, xmm9
0000710e9ebd8b93  mulpd xmm7, xmm15
0000710e9ebd8b98  vcmppd xmm6, xmm7, xmm7, 0x03
0000710e9ebd8b9d  ptest xmm6, xmm6
0000710e9ebd8ba2  jnz 0x0000710E9EBD9ADB
0000710e9ebd8ba8  vxorps xmm15, xmm15, xmm15
0000710e9ebd8bad  vpbroadcastq xmm15, xmm15
0000710e9ebd8bb2  movaps xmm9, xmm12
0000710e9ebd8bb6  mulpd xmm9, xmm10
0000710e9ebd8bbb  vcmppd xmm6, xmm9, xmm9, 0x03
0000710e9ebd8bc1  ptest xmm6, xmm6
0000710e9ebd8bc6  jnz 0x0000710E9EBD9C1D
0000710e9ebd8bcc  movaps xmm10, xmm12
0000710e9ebd8bd0  mulpd xmm10, xmm11
0000710e9ebd8bd5  vcmppd xmm6, xmm10, xmm10, 0x03
0000710e9ebd8bdb  ptest xmm6, xmm6
0000710e9ebd8be0  jnz 0x0000710E9EBD9D61
0000710e9ebd8be6  movaps xmm11, [r15+0x1F0]
0000710e9ebd8bee  movaps xmm6, xmm12
0000710e9ebd8bf2  mulpd xmm6, xmm11
0000710e9ebd8bf7  vcmppd xmm5, xmm6, xmm6, 0x03
0000710e9ebd8bfc  ptest xmm5, xmm5
0000710e9ebd8c01  jnz 0x0000710E9EBD9EA5
0000710e9ebd8c07  movaps xmm12, [r15+0x2A0]
0000710e9ebd8c0f  vmovaps [rsp+0x80], xmm12
0000710e9ebd8c18  vmovaps xmm11, [rsp+0x80]
0000710e9ebd8c21  por xmm12, xmm11
0000710e9ebd8c26  movaps xmm11, [r15+0x250]
0000710e9ebd8c2e  vmovaps [rsp+0x80], xmm11
0000710e9ebd8c37  vmovaps xmm5, [rsp+0x80]
0000710e9ebd8c40  por xmm11, xmm5
0000710e9ebd8c45  vmovaps xmm4, [rsp+0x70]
0000710e9ebd8c4b  vpermilpd xmm4, xmm4, 0x00
0000710e9ebd8c51  movaps xmm3, xmm5
0000710e9ebd8c54  mulpd xmm3, xmm4
0000710e9ebd8c58  vcmppd xmm2, xmm3, xmm3, 0x03
0000710e9ebd8c5d  ptest xmm2, xmm2
0000710e9ebd8c62  jnz 0x0000710E9EBD9FE7
0000710e9ebd8c68  mov [rsp+0x80], rax
0000710e9ebd8c70  xor eax, eax
0000710e9ebd8c72  mov r14d, 0x200
0000710e9ebd8c78  cmp r12, r14
0000710e9ebd8c7b  cmc
0000710e9ebd8c7c  lahf
0000710e9ebd8c7d  seto al
0000710e9ebd8c80  mov [r15+0x108], eax
0000710e9ebd8c87  movaps xmm5, xmm8
0000710e9ebd8c8b  addpd xmm5, xmm15
0000710e9ebd8c90  vcmppd xmm4, xmm5, xmm5, 0x03
0000710e9ebd8c95  ptest xmm4, xmm4
0000710e9ebd8c9a  jnz 0x0000710E9EBDA127
0000710e9ebd8ca0  movaps xmm8, [r15+0x1B0]
0000710e9ebd8ca8  movaps xmm4, xmm9
0000710e9ebd8cac  addpd xmm4, xmm8
0000710e9ebd8cb1  vcmppd xmm2, xmm4, xmm4, 0x03
0000710e9ebd8cb6  ptest xmm2, xmm2
0000710e9ebd8cbb  jnz 0x0000710E9EBDA269
0000710e9ebd8cc1  movaps xmm9, xmm10
0000710e9ebd8cc5  addpd xmm9, xmm8
0000710e9ebd8cca  vcmppd xmm2, xmm9, xmm9, 0x03
0000710e9ebd8cd0  ptest xmm2, xmm2
0000710e9ebd8cd5  jnz 0x0000710E9EBDA3AB
0000710e9ebd8cdb  movaps xmm10, [r15+0x2F0]
0000710e9ebd8ce3  vmovaps [rsp+0x90], xmm10
0000710e9ebd8cec  vmovaps xmm8, [rsp+0x90]
0000710e9ebd8cf5  por xmm10, xmm8
0000710e9ebd8cfa  movaps xmm8, [r15+0x2E0]
0000710e9ebd8d02  vmovaps [rsp+0x90], xmm8
0000710e9ebd8d0b  vmovaps xmm2, [rsp+0x90]
0000710e9ebd8d14  por xmm8, xmm2
0000710e9ebd8d19  movaps xmm2, [r15+0x2D0]
0000710e9ebd8d21  vmovaps [rsp+0x90], xmm2
0000710e9ebd8d2a  vmovaps [rsp+0xA0], xmm1
0000710e9ebd8d33  vmovaps xmm1, [rsp+0x90]
0000710e9ebd8d3c  por xmm2, xmm1
0000710e9ebd8d40  movaps xmm1, [r15+0x200]
0000710e9ebd8d48  vmovaps [rsp+0x90], xmm1
0000710e9ebd8d51  vmovaps [rsp+0xB0], xmm15
0000710e9ebd8d5a  vmovaps xmm15, [rsp+0x90]
0000710e9ebd8d63  por xmm1, xmm15
0000710e9ebd8d68  movaps xmm15, [r15+0x1C0]
0000710e9ebd8d70  vmovaps [rsp+0x90], xmm15
0000710e9ebd8d79  vmovaps [rsp+0xC0], xmm1
0000710e9ebd8d82  vmovaps xmm1, [rsp+0x90]
0000710e9ebd8d8b  por xmm15, xmm1
0000710e9ebd8d90  movaps xmm1, [r15+0x190]
0000710e9ebd8d98  vmovaps [rsp+0x90], xmm1
0000710e9ebd8da1  vmovaps [rsp+0xD0], xmm15
0000710e9ebd8daa  vmovaps xmm15, [rsp+0x90]
0000710e9ebd8db3  por xmm1, xmm15
0000710e9ebd8db8  movaps xmm15, [r15+0x300]
0000710e9ebd8dc0  vmovaps [rsp+0x90], xmm15
0000710e9ebd8dc9  vmovaps [rsp+0xE0], xmm1
0000710e9ebd8dd2  vmovaps xmm1, [rsp+0x90]
0000710e9ebd8ddb  por xmm15, xmm1
0000710e9ebd8de0  mov rax, [rsp+0x80]
0000710e9ebd8de8  lea r14, [rax+0xA0]
0000710e9ebd8def  movups xmm1, [r13+r14*1]
0000710e9ebd8df5  lea r14, [rax+0xB0]
0000710e9ebd8dfc  vmovaps [rsp+0x80], xmm1
0000710e9ebd8e05  movups xmm1, [r13+r14*1]
0000710e9ebd8e0b  vmovaps [rsp+0x90], xmm1
0000710e9ebd8e14  vmovaps [rsp+0xF0], xmm15
0000710e9ebd8e1d  vmovaps xmm15, [rsp+0xB0]
0000710e9ebd8e26  vmovaps [rsp+0xB0], xmm14
0000710e9ebd8e2f  movaps xmm1, xmm6
0000710e9ebd8e32  addpd xmm1, xmm15
0000710e9ebd8e37  vcmppd xmm14, xmm1, xmm1, 0x03
0000710e9ebd8e3c  ptest xmm14, xmm14
0000710e9ebd8e42  jnz 0x0000710E9EBDA503
0000710e9ebd8e48  lea r14, [rax+0xF0]
0000710e9ebd8e4f  movups xmm15, [r13+r14*1]
0000710e9ebd8e55  movaps xmm14, xmm4
0000710e9ebd8e59  addpd xmm14, xmm3
0000710e9ebd8e5e  vcmppd xmm6, xmm14, xmm14, 0x03
0000710e9ebd8e64  ptest xmm6, xmm6
0000710e9ebd8e69  jnz 0x0000710E9EBDA64E
0000710e9ebd8e6f  movaps xmm6, xmm9
0000710e9ebd8e73  addpd xmm6, xmm7
0000710e9ebd8e77  vcmppd xmm4, xmm6, xmm6, 0x03
0000710e9ebd8e7c  ptest xmm4, xmm4
0000710e9ebd8e81  jnz 0x0000710E9EBDA790
0000710e9ebd8e87  vmovaps xmm9, [rsp+0x70]
0000710e9ebd8e8d  vpermilpd xmm9, xmm9, 0x00
0000710e9ebd8e93  vmovaps xmm4, [rsp+0x90]
0000710e9ebd8e9c  movaps xmm7, xmm4
0000710e9ebd8e9f  mulpd xmm7, xmm9
0000710e9ebd8ea4  vcmppd xmm3, xmm7, xmm7, 0x03
0000710e9ebd8ea9  ptest xmm3, xmm3
0000710e9ebd8eae  jnz 0x0000710E9EBDA8D1
0000710e9ebd8eb4  vmovaps xmm9, [rsp+0x50]
0000710e9ebd8eba  vpermilpd xmm9, xmm9, 0x00
0000710e9ebd8ec0  movaps xmm4, xmm15
0000710e9ebd8ec4  mulpd xmm4, xmm9
0000710e9ebd8ec9  vcmppd xmm3, xmm4, xmm4, 0x03
0000710e9ebd8ece  ptest xmm3, xmm3
0000710e9ebd8ed3  jnz 0x0000710E9EBDAA12
0000710e9ebd8ed9  lea r14, [rax+0xE0]
0000710e9ebd8ee0  movups xmm15, [r13+r14*1]
0000710e9ebd8ee6  vmovaps xmm9, [rsp+0x70]
0000710e9ebd8eec  vpermilpd xmm9, xmm9, 0x00
0000710e9ebd8ef2  vmovaps [rsp+0x70], xmm1
0000710e9ebd8ef8  vmovaps xmm1, [rsp+0x80]
0000710e9ebd8f01  vmovaps [rsp+0x80], xmm15
0000710e9ebd8f0a  movaps xmm3, xmm1
0000710e9ebd8f0d  mulpd xmm3, xmm9
0000710e9ebd8f12  vcmppd xmm15, xmm3, xmm3, 0x03
0000710e9ebd8f17  ptest xmm15, xmm15
0000710e9ebd8f1d  jnz 0x0000710E9EBDAB5E
0000710e9ebd8f23  vmovaps xmm1, [rsp+0xF0]
0000710e9ebd8f2c  vmovaps xmm15, [rsp+0xF0]
0000710e9ebd8f35  por xmm1, xmm15
0000710e9ebd8f3a  movaps [r15+0x300], xmm1
0000710e9ebd8f42  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd8f4b  vmovaps xmm9, [rsp+0xE0]
0000710e9ebd8f54  por xmm15, xmm9
0000710e9ebd8f59  movaps [r15+0x190], xmm15
0000710e9ebd8f61  vmovaps xmm9, [rsp+0x50]
0000710e9ebd8f67  vpermilpd xmm9, xmm9, 0x00
0000710e9ebd8f6d  vmovaps [rsp+0x90], xmm1
0000710e9ebd8f76  vmovaps [rsp+0xE0], xmm15
0000710e9ebd8f7f  vmovaps xmm15, [rsp+0x80]
0000710e9ebd8f88  vmovaps [rsp+0x80], xmm14
0000710e9ebd8f91  movaps xmm1, xmm15
0000710e9ebd8f95  mulpd xmm1, xmm9
0000710e9ebd8f9a  vcmppd xmm14, xmm1, xmm1, 0x03
0000710e9ebd8f9f  ptest xmm14, xmm14
0000710e9ebd8fa5  jnz 0x0000710E9EBDAC9F
0000710e9ebd8fab  lea r14, [rax+0x90]
0000710e9ebd8fb2  movups xmm15, [r13+r14*1]
0000710e9ebd8fb8  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd8fc1  vmovaps xmm9, [rsp+0xD0]
0000710e9ebd8fca  por xmm14, xmm9
0000710e9ebd8fcf  movaps [r15+0x1C0], xmm14
0000710e9ebd8fd7  vmovaps xmm9, [rsp+0xC0]
0000710e9ebd8fe0  vmovaps [rsp+0xD0], xmm1
0000710e9ebd8fe9  vmovaps xmm1, [rsp+0xC0]
0000710e9ebd8ff2  por xmm9, xmm1
0000710e9ebd8ff7  movaps [r15+0x200], xmm9
0000710e9ebd8fff  vmovaps [rsp+0xC0], xmm2
0000710e9ebd9008  vmovaps xmm1, [rsp+0xC0]
0000710e9ebd9011  por xmm2, xmm1
0000710e9ebd9015  movaps [r15+0x2D0], xmm2
0000710e9ebd901d  vmovaps [rsp+0xC0], xmm8
0000710e9ebd9026  vmovaps xmm1, [rsp+0xC0]
0000710e9ebd902f  por xmm8, xmm1
0000710e9ebd9034  movaps [r15+0x2E0], xmm8
0000710e9ebd903c  vmovaps [rsp+0xC0], xmm15
0000710e9ebd9045  movaps xmm1, xmm5
0000710e9ebd9048  addpd xmm1, xmm7
0000710e9ebd904c  vcmppd xmm15, xmm1, xmm1, 0x03
0000710e9ebd9051  ptest xmm15, xmm15
0000710e9ebd9057  jnz 0x0000710E9EBDADEB
0000710e9ebd905d  vmovaps xmm15, [rsp+0x50]
0000710e9ebd9063  vpermilpd xmm15, xmm15, 0x00
0000710e9ebd9069  vmovaps xmm5, [rsp+0xC0]
0000710e9ebd9072  vmovaps [rsp+0xC0], xmm1
0000710e9ebd907b  movaps xmm7, xmm5
0000710e9ebd907e  mulpd xmm7, xmm15
0000710e9ebd9083  vcmppd xmm1, xmm7, xmm7, 0x03
0000710e9ebd9088  ptest xmm1, xmm1
0000710e9ebd908d  jnz 0x0000710E9EBDAF2B
0000710e9ebd9093  lea r14, [rax+0x80]
0000710e9ebd909a  movups xmm1, [r13+r14*1]
0000710e9ebd90a0  vmovaps xmm5, [rsp+0x70]
0000710e9ebd90a6  vmovaps [rsp+0x70], xmm1
0000710e9ebd90ac  movaps xmm15, xmm5
0000710e9ebd90b0  addpd xmm15, xmm3
0000710e9ebd90b5  vcmppd xmm1, xmm15, xmm15, 0x03
0000710e9ebd90bb  ptest xmm1, xmm1
0000710e9ebd90c0  jnz 0x0000710E9EBDB076
0000710e9ebd90c6  vmovaps xmm5, [rsp+0x80]
0000710e9ebd90cf  movaps xmm1, xmm5
0000710e9ebd90d2  addpd xmm1, xmm4
0000710e9ebd90d6  vcmppd xmm3, xmm1, xmm1, 0x03
0000710e9ebd90db  ptest xmm3, xmm3
0000710e9ebd90e0  jnz 0x0000710E9EBDB1B8
0000710e9ebd90e6  vmovaps [rsp+0x80], xmm10
0000710e9ebd90ef  vmovaps xmm5, [rsp+0x80]
0000710e9ebd90f8  por xmm10, xmm5
0000710e9ebd90fd  movaps [r15+0x2F0], xmm10
0000710e9ebd9105  vmovaps xmm5, [rsp+0x50]
0000710e9ebd910b  vpermilpd xmm5, xmm5, 0x00
0000710e9ebd9111  vmovaps xmm3, [rsp+0x70]
0000710e9ebd9117  vmovaps [rsp+0x50], xmm1
0000710e9ebd911d  movaps xmm4, xmm3
0000710e9ebd9120  mulpd xmm4, xmm5
0000710e9ebd9124  vcmppd xmm1, xmm4, xmm4, 0x03
0000710e9ebd9129  ptest xmm1, xmm1
0000710e9ebd912e  jnz 0x0000710E9EBDB2F8
0000710e9ebd9134  lea r14, [rax+0xD0]
0000710e9ebd913b  movups xmm1, [r13+r14*1]
0000710e9ebd9141  vmovaps xmm3, [rsp+0xD0]
0000710e9ebd914a  vmovaps [rsp+0x70], xmm1
0000710e9ebd9150  movaps xmm5, xmm6
0000710e9ebd9153  addpd xmm5, xmm3
0000710e9ebd9157  vcmppd xmm1, xmm5, xmm5, 0x03
0000710e9ebd915c  ptest xmm1, xmm1
0000710e9ebd9161  jnz 0x0000710E9EBDB442
0000710e9ebd9167  vmovaps xmm1, [rsp+0x60]
0000710e9ebd916d  vpermilpd xmm1, xmm1, 0x00
0000710e9ebd9173  movaps xmm6, xmm9
0000710e9ebd9177  mulpd xmm6, xmm1
0000710e9ebd917b  vcmppd xmm3, xmm6, xmm6, 0x03
0000710e9ebd9180  ptest xmm3, xmm3
0000710e9ebd9185  jnz 0x0000710E9EBDB582
0000710e9ebd918b  movaps [r15+0x260], xmm6
0000710e9ebd9193  vxorps xmm1, xmm1, xmm1
0000710e9ebd9197  vpbroadcastq xmm1, xmm1
0000710e9ebd919c  movaps [r15+0x1B0], xmm1
0000710e9ebd91a4  vmovaps xmm1, [rsp+0x60]
0000710e9ebd91aa  vpermilpd xmm1, xmm1, 0x00
0000710e9ebd91b0  vmovaps xmm3, [rsp+0x70]
0000710e9ebd91b6  vmovaps [rsp+0x70], xmm15
0000710e9ebd91bc  movaps xmm9, xmm3
0000710e9ebd91c0  mulpd xmm9, xmm1
0000710e9ebd91c5  vcmppd xmm15, xmm9, xmm9, 0x03
0000710e9ebd91cb  ptest xmm15, xmm15
0000710e9ebd91d1  jnz 0x0000710E9EBDB6C3
0000710e9ebd91d7  lea r14, [rax+0xC0]
0000710e9ebd91de  movups xmm1, [r13+r14*1]
0000710e9ebd91e4  vmovaps xmm3, [rsp+0xC0]
0000710e9ebd91ed  vmovaps [rsp+0x80], xmm1
0000710e9ebd91f6  movaps xmm15, xmm3
0000710e9ebd91fa  addpd xmm15, xmm7
0000710e9ebd91ff  vcmppd xmm1, xmm15, xmm15, 0x03
0000710e9ebd9205  ptest xmm1, xmm1
0000710e9ebd920a  jnz 0x0000710E9EBDB80F
0000710e9ebd9210  vmovaps [rsp+0xC0], xmm13
0000710e9ebd9219  vmovaps xmm1, [rsp+0xC0]
0000710e9ebd9222  por xmm13, xmm1
0000710e9ebd9227  movaps [r15+0x270], xmm13
0000710e9ebd922f  vmovaps xmm1, [rsp+0xB0]
0000710e9ebd9238  vmovaps xmm7, [rsp+0xB0]
0000710e9ebd9241  por xmm1, xmm7
0000710e9ebd9245  movaps [r15+0x1A0], xmm1
0000710e9ebd924d  vmovaps xmm1, [rsp+0x60]
0000710e9ebd9253  vpermilpd xmm1, xmm1, 0x00
0000710e9ebd9259  vmovaps [rsp+0xB0], xmm1
0000710e9ebd9262  vmovaps xmm1, [rsp+0x80]
0000710e9ebd926b  vmovaps [rsp+0x80], xmm15
0000710e9ebd9274  vmovaps xmm15, [rsp+0xB0]
0000710e9ebd927d  vmovaps [rsp+0xB0], xmm14
0000710e9ebd9286  movaps xmm3, xmm1
0000710e9ebd9289  mulpd xmm3, xmm15
0000710e9ebd928e  vcmppd xmm14, xmm3, xmm3, 0x03
0000710e9ebd9293  ptest xmm14, xmm14
0000710e9ebd9299  jnz 0x0000710E9EBDB951
0000710e9ebd929f  lea r14, [rax+0x20]
0000710e9ebd92a3  movups xmm1, [r13+r14*1]
0000710e9ebd92a9  movaps [r15+0x110], xmm1
0000710e9ebd92b1  vmovaps xmm14, [rsp+0x70]
0000710e9ebd92b7  vmovaps [rsp+0x70], xmm1
0000710e9ebd92bd  movaps xmm15, xmm14
0000710e9ebd92c1  addpd xmm15, xmm4
0000710e9ebd92c6  vcmppd xmm1, xmm15, xmm15, 0x03
0000710e9ebd92cc  ptest xmm1, xmm1
0000710e9ebd92d1  jnz 0x0000710E9EBDBA9C
0000710e9ebd92d7  vmovaps xmm1, [rsp+0x60]
0000710e9ebd92dd  vpermilpd xmm1, xmm1, 0x00
0000710e9ebd92e3  movaps xmm14, xmm2
0000710e9ebd92e7  mulpd xmm14, xmm1
0000710e9ebd92ec  vcmppd xmm4, xmm14, xmm14, 0x03
0000710e9ebd92f2  ptest xmm4, xmm4
0000710e9ebd92f7  jnz 0x0000710E9EBDBBDF
0000710e9ebd92fd  vmovaps xmm4, [rsp+0x50]
0000710e9ebd9303  movaps xmm1, xmm4
0000710e9ebd9306  addpd xmm1, xmm9
0000710e9ebd930b  vcmppd xmm2, xmm1, xmm1, 0x03
0000710e9ebd9310  ptest xmm2, xmm2
0000710e9ebd9315  jnz 0x0000710E9EBDBD21
0000710e9ebd931b  vmovaps xmm9, [rsp+0x30]
0000710e9ebd9321  vpermilpd xmm9, xmm9, 0x00
0000710e9ebd9327  vmovaps xmm2, [rsp+0x70]
0000710e9ebd932d  vmovaps [rsp+0x50], xmm1
0000710e9ebd9333  movaps xmm4, xmm2
0000710e9ebd9336  mulpd xmm4, xmm9
0000710e9ebd933b  vcmppd xmm1, xmm4, xmm4, 0x03
0000710e9ebd9340  ptest xmm1, xmm1
0000710e9ebd9345  jnz 0x0000710E9EBDBE62
0000710e9ebd934b  vmovaps xmm1, [rsp+0x30]
0000710e9ebd9351  vpermilpd xmm1, xmm1, 0x00
0000710e9ebd9357  vmovaps xmm2, [rsp+0x90]
0000710e9ebd9360  vmovaps [rsp+0x60], xmm15
0000710e9ebd9366  movaps xmm9, xmm2
0000710e9ebd936a  mulpd xmm9, xmm1
0000710e9ebd936f  vcmppd xmm15, xmm9, xmm9, 0x03
0000710e9ebd9375  ptest xmm15, xmm15
0000710e9ebd937b  jnz 0x0000710E9EBDBFA3
0000710e9ebd9381  vmovaps xmm15, [rsp+0x80]
0000710e9ebd938a  movaps xmm1, xmm15
0000710e9ebd938e  addpd xmm1, xmm6
0000710e9ebd9392  vcmppd xmm2, xmm1, xmm1, 0x03
0000710e9ebd9397  ptest xmm2, xmm2
0000710e9ebd939c  jnz 0x0000710E9EBDC0E5
0000710e9ebd93a2  movaps xmm15, xmm5
0000710e9ebd93a6  addpd xmm15, xmm3
0000710e9ebd93ab  vcmppd xmm6, xmm15, xmm15, 0x03
0000710e9ebd93b1  ptest xmm6, xmm6
0000710e9ebd93b6  jnz 0x0000710E9EBDC226
0000710e9ebd93bc  vmovaps xmm6, [rsp+0x30]
0000710e9ebd93c2  vpermilpd xmm6, xmm6, 0x00
0000710e9ebd93c8  movaps xmm5, xmm8
0000710e9ebd93cc  mulpd xmm5, xmm6
0000710e9ebd93d0  vcmppd xmm3, xmm5, xmm5, 0x03
0000710e9ebd93d5  ptest xmm3, xmm3
0000710e9ebd93da  jnz 0x0000710E9EBDC368
0000710e9ebd93e0  vmovaps xmm8, [rsp+0x30]
0000710e9ebd93e6  vpermilpd xmm8, xmm8, 0x00
0000710e9ebd93ec  movaps xmm6, xmm10
0000710e9ebd93f0  mulpd xmm6, xmm8
0000710e9ebd93f5  vcmppd xmm3, xmm6, xmm6, 0x03
0000710e9ebd93fa  ptest xmm3, xmm3
0000710e9ebd93ff  jnz 0x0000710E9EBDC4A9
0000710e9ebd9405  vmovaps xmm8, [rsp+0x60]
0000710e9ebd940b  movaps xmm10, xmm8
0000710e9ebd940f  addpd xmm10, xmm14
0000710e9ebd9414  vcmppd xmm3, xmm10, xmm10, 0x03
0000710e9ebd941a  ptest xmm3, xmm3
0000710e9ebd941f  jnz 0x0000710E9EBDC5EB
0000710e9ebd9425  vmovaps xmm8, [rsp+0x50]
0000710e9ebd942b  movaps xmm14, xmm8
0000710e9ebd942f  addpd xmm14, xmm4
0000710e9ebd9434  vcmppd xmm3, xmm14, xmm14, 0x03
0000710e9ebd943a  ptest xmm3, xmm3
0000710e9ebd943f  jnz 0x0000710E9EBDC72F
0000710e9ebd9445  vmovaps xmm8, [rsp+0x40]
0000710e9ebd944b  vpermilpd xmm8, xmm8, 0x00
0000710e9ebd9451  movaps xmm4, xmm13
0000710e9ebd9455  mulpd xmm4, xmm8
0000710e9ebd945a  vcmppd xmm3, xmm4, xmm4, 0x03
0000710e9ebd945f  ptest xmm3, xmm3
0000710e9ebd9464  jnz 0x0000710E9EBDC872
0000710e9ebd946a  movaps xmm13, xmm15
0000710e9ebd946e  addpd xmm13, xmm9
0000710e9ebd9473  vcmppd xmm8, xmm13, xmm13, 0x03
0000710e9ebd9479  ptest xmm8, xmm8
0000710e9ebd947f  jnz 0x0000710E9EBDC9B4
0000710e9ebd9485  movaps xmm15, xmm1
0000710e9ebd9489  addpd xmm15, xmm5
0000710e9ebd948e  vcmppd xmm9, xmm15, xmm15, 0x03
0000710e9ebd9494  ptest xmm9, xmm9
0000710e9ebd949a  jnz 0x0000710E9EBDCAF8
0000710e9ebd94a0  vmovaps [rsp+0x30], xmm11
0000710e9ebd94a6  vmovaps xmm1, [rsp+0x30]
0000710e9ebd94ac  por xmm11, xmm1
0000710e9ebd94b1  movaps [r15+0x250], xmm11
0000710e9ebd94b9  vmovaps [rsp+0x30], xmm12
0000710e9ebd94bf  vmovaps xmm1, [rsp+0x30]
0000710e9ebd94c5  por xmm12, xmm1
0000710e9ebd94ca  movaps [r15+0x2A0], xmm12
0000710e9ebd94d2  vmovaps xmm1, [rsp+0xA0]
0000710e9ebd94db  vmovaps xmm11, [rsp+0xA0]
0000710e9ebd94e4  por xmm1, xmm11
0000710e9ebd94e9  movaps [r15+0x1D0], xmm1
0000710e9ebd94f1  lea r14, [rax+0x40]
0000710e9ebd94f5  movups xmm1, [r13+r14*1]
0000710e9ebd94fb  movaps [r15+0x2C0], xmm1
0000710e9ebd9503  vmovaps xmm11, [rsp+0x40]
0000710e9ebd9509  vpermilpd xmm11, xmm11, 0x00
0000710e9ebd950f  vmovaps xmm8, [rsp+0xE0]
0000710e9ebd9518  movaps xmm9, xmm8
0000710e9ebd951c  mulpd xmm9, xmm11
0000710e9ebd9521  vcmppd xmm5, xmm9, xmm9, 0x03
0000710e9ebd9527  ptest xmm5, xmm5
0000710e9ebd952c  jnz 0x0000710E9EBDCC44
0000710e9ebd9532  movaps xmm11, xmm10
0000710e9ebd9536  addpd xmm11, xmm6
0000710e9ebd953b  vcmppd xmm8, xmm11, xmm11, 0x03
0000710e9ebd9541  ptest xmm8, xmm8
0000710e9ebd9547  jnz 0x0000710E9EBDCD88
0000710e9ebd954d  movaps xmm10, xmm14
0000710e9ebd9551  addpd xmm10, xmm4
0000710e9ebd9556  vcmppd xmm8, xmm10, xmm10, 0x03
0000710e9ebd955c  ptest xmm8, xmm8
0000710e9ebd9562  jnz 0x0000710E9EBDCECB
0000710e9ebd9568  vmovaps xmm14, [rsp+0x40]
0000710e9ebd956e  vpermilpd xmm14, xmm14, 0x00
0000710e9ebd9574  movaps xmm8, xmm1
0000710e9ebd9578  mulpd xmm8, xmm14
0000710e9ebd957d  vcmppd xmm6, xmm8, xmm8, 0x03
0000710e9ebd9583  ptest xmm6, xmm6
0000710e9ebd9588  jnz 0x0000710E9EBDD00E
0000710e9ebd958e  movaps xmm1, [r15+0x2B0]
0000710e9ebd9596  vmovaps xmm14, [rsp+0x40]
0000710e9ebd959c  vpermilpd xmm14, xmm14, 0x00
0000710e9ebd95a2  movaps xmm6, xmm1
0000710e9ebd95a5  mulpd xmm6, xmm14
0000710e9ebd95aa  vcmppd xmm5, xmm6, xmm6, 0x03
0000710e9ebd95af  ptest xmm5, xmm5
0000710e9ebd95b4  jnz 0x0000710E9EBDD151
0000710e9ebd95ba  vmovaps xmm1, [rsp+0x10]
0000710e9ebd95c0  vpermilpd xmm1, xmm1, 0x00
0000710e9ebd95c6  movaps xmm14, xmm12
0000710e9ebd95ca  mulpd xmm14, xmm1
0000710e9ebd95cf  vcmppd xmm5, xmm14, xmm14, 0x03
0000710e9ebd95d5  ptest xmm5, xmm5
0000710e9ebd95da  jnz 0x0000710E9EBDD292
0000710e9ebd95e0  movaps xmm1, xmm13
0000710e9ebd95e4  addpd xmm1, xmm9
0000710e9ebd95e9  vcmppd xmm12, xmm1, xmm1, 0x03
0000710e9ebd95ee  ptest xmm12, xmm12
0000710e9ebd95f4  jnz 0x0000710E9EBDD3D5
0000710e9ebd95fa  vmovaps xmm13, [rsp+0x10]
0000710e9ebd9600  vpermilpd xmm13, xmm13, 0x00
0000710e9ebd9606  movaps xmm12, xmm7
0000710e9ebd960a  mulpd xmm12, xmm13
0000710e9ebd960f  vcmppd xmm9, xmm12, xmm12, 0x03
0000710e9ebd9615  ptest xmm9, xmm9
0000710e9ebd961b  jnz 0x0000710E9EBDD517
0000710e9ebd9621  movaps xmm13, xmm15
0000710e9ebd9625  addpd xmm13, xmm8
0000710e9ebd962a  vcmppd xmm9, xmm13, xmm13, 0x03
0000710e9ebd9630  ptest xmm9, xmm9
0000710e9ebd9636  jnz 0x0000710E9EBDD65A
0000710e9ebd963c  movaps xmm15, [r15+0x290]
0000710e9ebd9644  vmovaps xmm9, [rsp+0x10]
0000710e9ebd964a  vpermilpd xmm9, xmm9, 0x00
0000710e9ebd9650  movaps xmm8, xmm15
0000710e9ebd9654  mulpd xmm8, xmm9
0000710e9ebd9659  vcmppd xmm7, xmm8, xmm8, 0x03
0000710e9ebd965f  ptest xmm7, xmm7
0000710e9ebd9664  jnz 0x0000710E9EBDD79E
0000710e9ebd966a  movaps xmm15, xmm11
0000710e9ebd966e  addpd xmm15, xmm6
0000710e9ebd9673  vcmppd xmm9, xmm15, xmm15, 0x03
0000710e9ebd9679  ptest xmm9, xmm9
0000710e9ebd967f  jnz 0x0000710E9EBDD8E2
0000710e9ebd9685  movaps xmm11, [r15+0x1E0]
0000710e9ebd968d  vmovaps xmm9, [rsp+0x10]
0000710e9ebd9693  vpermilpd xmm9, xmm9, 0x00
0000710e9ebd9699  movaps xmm7, xmm11
0000710e9ebd969d  mulpd xmm7, xmm9
0000710e9ebd96a2  vcmppd xmm6, xmm7, xmm7, 0x03
0000710e9ebd96a7  ptest xmm6, xmm6
0000710e9ebd96ac  jnz 0x0000710E9EBDDA25
0000710e9ebd96b2  movaps xmm11, xmm10
0000710e9ebd96b6  addpd xmm11, xmm14
0000710e9ebd96bb  vcmppd xmm9, xmm11, xmm11, 0x03
0000710e9ebd96c1  ptest xmm9, xmm9
0000710e9ebd96c7  jnz 0x0000710E9EBDDB67
0000710e9ebd96cd  lea r14, [rax+0x70]
0000710e9ebd96d1  movups xmm14, [r13+r14*1]
0000710e9ebd96d7  movaps [r15+0x240], xmm14
0000710e9ebd96df  movaps xmm10, xmm1
0000710e9ebd96e3  addpd xmm10, xmm12
0000710e9ebd96e8  vcmppd xmm9, xmm10, xmm10, 0x03
0000710e9ebd96ee  ptest xmm9, xmm9
0000710e9ebd96f4  jnz 0x0000710E9EBDDCB5
0000710e9ebd96fa  movaps [r15+0x170], xmm10
0000710e9ebd9702  vmovaps xmm1, [rsp+0x20]
0000710e9ebd9708  vpermilpd xmm1, xmm1, 0x00
0000710e9ebd970e  movaps xmm12, xmm14
0000710e9ebd9712  mulpd xmm12, xmm1
0000710e9ebd9717  vcmppd xmm9, xmm12, xmm12, 0x03
0000710e9ebd971d  ptest xmm9, xmm9
0000710e9ebd9723  jnz 0x0000710E9EBDDDF8
0000710e9ebd9729  vmovaps xmm1, [rsp+0x20]
0000710e9ebd972f  vpermilpd xmm1, xmm1, 0x00
0000710e9ebd9735  vmovaps xmm9, [rsp+0xB0]
0000710e9ebd973e  movaps xmm14, xmm9
0000710e9ebd9742  mulpd xmm14, xmm1
0000710e9ebd9747  vcmppd xmm6, xmm14, xmm14, 0x03
0000710e9ebd974d  ptest xmm6, xmm6
0000710e9ebd9752  jnz 0x0000710E9EBDDF3B
0000710e9ebd9758  movaps [r15+0x180], xmm14
0000710e9ebd9760  movaps xmm1, xmm13
0000710e9ebd9764  addpd xmm1, xmm8
0000710e9ebd9769  vcmppd xmm9, xmm1, xmm1, 0x03
0000710e9ebd976e  ptest xmm9, xmm9
0000710e9ebd9774  jnz 0x0000710E9EBDE07E
0000710e9ebd977a  movaps [r15+0x210], xmm1
0000710e9ebd9782  movups xmm13, [r13+rax*1]
0000710e9ebd9788  lea r14, [rax+0x10]
0000710e9ebd978c  movups xmm9, [r13+r14*1]
0000710e9ebd9792  movaps [r15+0x230], xmm9
0000710e9ebd979a  movaps xmm8, xmm15
0000710e9ebd979e  addpd xmm8, xmm7
0000710e9ebd97a3  vcmppd xmm6, xmm8, xmm8, 0x03
0000710e9ebd97a9  ptest xmm6, xmm6
0000710e9ebd97ae  jnz 0x0000710E9EBDE1D4
0000710e9ebd97b4  movaps [r15+0x130], xmm8
0000710e9ebd97bc  vmovaps xmm15, [rsp+0x20]
0000710e9ebd97c2  vpermilpd xmm15, xmm15, 0x00
0000710e9ebd97c8  movaps xmm7, xmm9
0000710e9ebd97cc  mulpd xmm7, xmm15
0000710e9ebd97d1  vcmppd xmm6, xmm7, xmm7, 0x03
0000710e9ebd97d6  ptest xmm6, xmm6
0000710e9ebd97db  jnz 0x0000710E9EBDE317
0000710e9ebd97e1  movaps [r15+0x220], xmm7
0000710e9ebd97e9  vmovaps xmm15, [rsp+0x20]
0000710e9ebd97ef  vpermilpd xmm15, xmm15, 0x00
0000710e9ebd97f5  movaps xmm9, xmm13
0000710e9ebd97f9  mulpd xmm9, xmm15
0000710e9ebd97fe  vcmppd xmm6, xmm9, xmm9, 0x03
0000710e9ebd9804  ptest xmm6, xmm6
0000710e9ebd9809  jnz 0x0000710E9EBDE459
0000710e9ebd980f  movaps xmm15, xmm11
0000710e9ebd9813  addpd xmm15, xmm12
0000710e9ebd9818  vcmppd xmm13, xmm15, xmm15, 0x03
0000710e9ebd981e  ptest xmm13, xmm13
0000710e9ebd9824  jnz 0x0000710E9EBDE59D
0000710e9ebd982a  movaps [r15+0x140], xmm15
0000710e9ebd9832  movaps xmm13, xmm10
0000710e9ebd9836  addpd xmm13, xmm14
0000710e9ebd983b  vcmppd xmm12, xmm13, xmm13, 0x03
0000710e9ebd9841  ptest xmm12, xmm12
0000710e9ebd9847  jnz 0x0000710E9EBDE6E1
0000710e9ebd984d  movaps [r15+0x150], xmm13
0000710e9ebd9855  movaps xmm14, xmm1
0000710e9ebd9859  addpd xmm14, xmm7
0000710e9ebd985e  vcmppd xmm12, xmm14, xmm14, 0x03
0000710e9ebd9864  ptest xmm12, xmm12
0000710e9ebd986a  jnz 0x0000710E9EBDE825
0000710e9ebd9870  movaps [r15+0x160], xmm14
0000710e9ebd9878  movaps xmm1, xmm8
0000710e9ebd987c  addpd xmm1, xmm9
0000710e9ebd9881  vcmppd xmm12, xmm1, xmm1, 0x03
0000710e9ebd9886  ptest xmm12, xmm12
0000710e9ebd988c  jnz 0x0000710E9EBDE967
0000710e9ebd9892  movaps [r15+0x120], xmm1
0000710e9ebd989a  movups [r13+r11*1], xmm15
0000710e9ebd98a0  lea rax, [r11+0x10]
0000710e9ebd98a4  movups [r13+rax*1], xmm13
0000710e9ebd98aa  lea rax, [r11+0x20]
0000710e9ebd98ae  movups [r13+rax*1], xmm14
0000710e9ebd98b4  lea rax, [r11+0x30]
0000710e9ebd98b8  movups [r13+rax*1], xmm1
0000710e9ebd98be  mov eax, [r15+0x108]
0000710e9ebd98c5  sahf
0000710e9ebd98c6  jnz 0x0000710E9EBD98F8
0000710e9ebd98c8  cmp dword ptr [r15+0x318], 0x00
0000710e9ebd98d0  jz 0x0000710E9EBDEAE0
0000710e9ebd98d6  nop [rax+rax*1], ax
0000710e9ebd98df  nop [rax+rax*1], eax
0000710e9ebd98e7  mov eax, 0x4106D0
0000710e9ebd98ec  mov [r15+0x100], rax
0000710e9ebd98f3  jmp 0x0000710E9E9FE110
0000710e9ebd98f8  cmp dword ptr [r15+0x318], 0x00
0000710e9ebd9900  jz 0x0000710E9EBD89C0
0000710e9ebd9906  nop [rax+rax*1], ax
0000710e9ebd990f  nop [rax+rax*1], eax
0000710e9ebd9917  mov eax, 0x410504
0000710e9ebd991c  mov [r15+0x100], rax
0000710e9ebd9923  jmp 0x0000710E9E9FE110
0000710e9ebd9928  int3
0000710e9ebd9929  call 0x0000710E9EA0A4B0
0000710e9ebd992e  jmp 0x0000710E9EBD8A08
0000710e9ebd9933  call 0x0000710E9EA09240
0000710e9ebd9938  jmp 0x0000710E9EBD8A12
0000710e9ebd993d  call 0x0000710E9EA0A4B0
0000710e9ebd9942  jmp 0x0000710E9EBD8A6F
0000710e9ebd9947  call 0x0000710E9EA09240
0000710e9ebd994c  jmp 0x0000710E9EBD8A79
0000710e9ebd9951  call 0x0000710E9EA0A4B0
0000710e9ebd9956  jmp 0x0000710E9EBD8ABD
0000710e9ebd995b  call 0x0000710E9EA09240
0000710e9ebd9960  jmp 0x0000710E9EBD8AC7
0000710e9ebd9965  call 0x0000710E9EAB47C0
0000710e9ebd996a  jmp 0x0000710E9EBD8B06
0000710e9ebd996f  call 0x0000710E9EA0B720
0000710e9ebd9974  jmp 0x0000710E9EBD8B1A
0000710e9ebd9979  call 0x0000710E9EABFC30
0000710e9ebd997e  jmp 0x0000710E9EBD8B38
0000710e9ebd9983  call 0x0000710E9EABE9C0
0000710e9ebd9988  jmp 0x0000710E9EBD8B42
0000710e9ebd998d  call 0x0000710E9EABD750
0000710e9ebd9992  jmp 0x0000710E9EBD8B4C
0000710e9ebd9997  sub rsp, 0x08
0000710e9ebd999b  push rax
0000710e9ebd999c  push rcx
0000710e9ebd999d  push rdx
0000710e9ebd999e  push rdi
0000710e9ebd999f  push rsi
0000710e9ebd99a0  push r8
0000710e9ebd99a2  push r9
0000710e9ebd99a4  push r10
0000710e9ebd99a6  push r11
0000710e9ebd99a8  sub rsp, 0xF0
0000710e9ebd99af  vmovaps [rsp], xmm0
0000710e9ebd99b4  vmovaps [rsp+0x10], xmm1
0000710e9ebd99ba  vmovaps [rsp+0x20], xmm2
0000710e9ebd99c0  vmovaps [rsp+0x30], xmm3
0000710e9ebd99c6  vmovaps [rsp+0x40], xmm4
0000710e9ebd99cc  vmovaps [rsp+0x50], xmm5
0000710e9ebd99d2  vmovaps [rsp+0x60], xmm6
0000710e9ebd99d8  vmovaps [rsp+0x70], xmm7
0000710e9ebd99de  vmovaps [rsp+0x80], xmm9
0000710e9ebd99e7  vmovaps [rsp+0x90], xmm10
0000710e9ebd99f0  vmovaps [rsp+0xA0], xmm11
0000710e9ebd99f9  vmovaps [rsp+0xB0], xmm12
0000710e9ebd9a02  vmovaps [rsp+0xC0], xmm13
0000710e9ebd9a0b  vmovaps [rsp+0xD0], xmm14
0000710e9ebd9a14  vmovaps [rsp+0xE0], xmm15
0000710e9ebd9a1d  sub rsp, 0x30
0000710e9ebd9a21  movaps [rsp], xmm8
0000710e9ebd9a26  movaps [rsp+0x10], xmm12
0000710e9ebd9a2c  movaps [rsp+0x20], xmm15
0000710e9ebd9a32  lea rdi, [rsp]
0000710e9ebd9a36  mov esi, 0x00
0000710e9ebd9a3b  mov rax, 0x5DADAF7CF530
0000710e9ebd9a45  call rax
0000710e9ebd9a47  movaps xmm8, [rsp]
0000710e9ebd9a4c  add rsp, 0x30
0000710e9ebd9a50  vmovaps xmm0, [rsp]
0000710e9ebd9a55  vmovaps xmm1, [rsp+0x10]
0000710e9ebd9a5b  vmovaps xmm2, [rsp+0x20]
0000710e9ebd9a61  vmovaps xmm3, [rsp+0x30]
0000710e9ebd9a67  vmovaps xmm4, [rsp+0x40]
0000710e9ebd9a6d  vmovaps xmm5, [rsp+0x50]
0000710e9ebd9a73  vmovaps xmm6, [rsp+0x60]
0000710e9ebd9a79  vmovaps xmm7, [rsp+0x70]
0000710e9ebd9a7f  vmovaps xmm9, [rsp+0x80]
0000710e9ebd9a88  vmovaps xmm10, [rsp+0x90]
0000710e9ebd9a91  vmovaps xmm11, [rsp+0xA0]
0000710e9ebd9a9a  vmovaps xmm12, [rsp+0xB0]
0000710e9ebd9aa3  vmovaps xmm13, [rsp+0xC0]
0000710e9ebd9aac  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd9ab5  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd9abe  add rsp, 0xF0
0000710e9ebd9ac5  pop r11
0000710e9ebd9ac7  pop r10
0000710e9ebd9ac9  pop r9
0000710e9ebd9acb  pop r8
0000710e9ebd9acd  pop rsi
0000710e9ebd9ace  pop rdi
0000710e9ebd9acf  pop rdx
0000710e9ebd9ad0  pop rcx
0000710e9ebd9ad1  pop rax
0000710e9ebd9ad2  add rsp, 0x08
0000710e9ebd9ad6  jmp 0x0000710E9EBD8B7A
0000710e9ebd9adb  sub rsp, 0x08
0000710e9ebd9adf  push rax
0000710e9ebd9ae0  push rcx
0000710e9ebd9ae1  push rdx
0000710e9ebd9ae2  push rdi
0000710e9ebd9ae3  push rsi
0000710e9ebd9ae4  push r8
0000710e9ebd9ae6  push r9
0000710e9ebd9ae8  push r10
0000710e9ebd9aea  push r11
0000710e9ebd9aec  sub rsp, 0xF0
0000710e9ebd9af3  vmovaps [rsp], xmm0
0000710e9ebd9af8  vmovaps [rsp+0x10], xmm1
0000710e9ebd9afe  vmovaps [rsp+0x20], xmm2
0000710e9ebd9b04  vmovaps [rsp+0x30], xmm3
0000710e9ebd9b0a  vmovaps [rsp+0x40], xmm4
0000710e9ebd9b10  vmovaps [rsp+0x50], xmm5
0000710e9ebd9b16  vmovaps [rsp+0x60], xmm6
0000710e9ebd9b1c  vmovaps [rsp+0x70], xmm8
0000710e9ebd9b22  vmovaps [rsp+0x80], xmm9
0000710e9ebd9b2b  vmovaps [rsp+0x90], xmm10
0000710e9ebd9b34  vmovaps [rsp+0xA0], xmm11
0000710e9ebd9b3d  vmovaps [rsp+0xB0], xmm12
0000710e9ebd9b46  vmovaps [rsp+0xC0], xmm13
0000710e9ebd9b4f  vmovaps [rsp+0xD0], xmm14
0000710e9ebd9b58  vmovaps [rsp+0xE0], xmm15
0000710e9ebd9b61  sub rsp, 0x30
0000710e9ebd9b65  movaps [rsp], xmm7
0000710e9ebd9b69  movaps [rsp+0x10], xmm9
0000710e9ebd9b6f  movaps [rsp+0x20], xmm15
0000710e9ebd9b75  lea rdi, [rsp]
0000710e9ebd9b79  mov esi, 0x00
0000710e9ebd9b7e  mov rax, 0x5DADAF7CF530
0000710e9ebd9b88  call rax
0000710e9ebd9b8a  movaps xmm7, [rsp]
0000710e9ebd9b8e  add rsp, 0x30
0000710e9ebd9b92  vmovaps xmm0, [rsp]
0000710e9ebd9b97  vmovaps xmm1, [rsp+0x10]
0000710e9ebd9b9d  vmovaps xmm2, [rsp+0x20]
0000710e9ebd9ba3  vmovaps xmm3, [rsp+0x30]
0000710e9ebd9ba9  vmovaps xmm4, [rsp+0x40]
0000710e9ebd9baf  vmovaps xmm5, [rsp+0x50]
0000710e9ebd9bb5  vmovaps xmm6, [rsp+0x60]
0000710e9ebd9bbb  vmovaps xmm8, [rsp+0x70]
0000710e9ebd9bc1  vmovaps xmm9, [rsp+0x80]
0000710e9ebd9bca  vmovaps xmm10, [rsp+0x90]
0000710e9ebd9bd3  vmovaps xmm11, [rsp+0xA0]
0000710e9ebd9bdc  vmovaps xmm12, [rsp+0xB0]
0000710e9ebd9be5  vmovaps xmm13, [rsp+0xC0]
0000710e9ebd9bee  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd9bf7  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd9c00  add rsp, 0xF0
0000710e9ebd9c07  pop r11
0000710e9ebd9c09  pop r10
0000710e9ebd9c0b  pop r9
0000710e9ebd9c0d  pop r8
0000710e9ebd9c0f  pop rsi
0000710e9ebd9c10  pop rdi
0000710e9ebd9c11  pop rdx
0000710e9ebd9c12  pop rcx
0000710e9ebd9c13  pop rax
0000710e9ebd9c14  add rsp, 0x08
0000710e9ebd9c18  jmp 0x0000710E9EBD8BA8
0000710e9ebd9c1d  sub rsp, 0x08
0000710e9ebd9c21  push rax
0000710e9ebd9c22  push rcx
0000710e9ebd9c23  push rdx
0000710e9ebd9c24  push rdi
0000710e9ebd9c25  push rsi
0000710e9ebd9c26  push r8
0000710e9ebd9c28  push r9
0000710e9ebd9c2a  push r10
0000710e9ebd9c2c  push r11
0000710e9ebd9c2e  sub rsp, 0xF0
0000710e9ebd9c35  vmovaps [rsp], xmm0
0000710e9ebd9c3a  vmovaps [rsp+0x10], xmm1
0000710e9ebd9c40  vmovaps [rsp+0x20], xmm2
0000710e9ebd9c46  vmovaps [rsp+0x30], xmm3
0000710e9ebd9c4c  vmovaps [rsp+0x40], xmm4
0000710e9ebd9c52  vmovaps [rsp+0x50], xmm5
0000710e9ebd9c58  vmovaps [rsp+0x60], xmm6
0000710e9ebd9c5e  vmovaps [rsp+0x70], xmm7
0000710e9ebd9c64  vmovaps [rsp+0x80], xmm8
0000710e9ebd9c6d  vmovaps [rsp+0x90], xmm10
0000710e9ebd9c76  vmovaps [rsp+0xA0], xmm11
0000710e9ebd9c7f  vmovaps [rsp+0xB0], xmm12
0000710e9ebd9c88  vmovaps [rsp+0xC0], xmm13
0000710e9ebd9c91  vmovaps [rsp+0xD0], xmm14
0000710e9ebd9c9a  vmovaps [rsp+0xE0], xmm15
0000710e9ebd9ca3  sub rsp, 0x30
0000710e9ebd9ca7  movaps [rsp], xmm9
0000710e9ebd9cac  movaps [rsp+0x10], xmm12
0000710e9ebd9cb2  movaps [rsp+0x20], xmm10
0000710e9ebd9cb8  lea rdi, [rsp]
0000710e9ebd9cbc  mov esi, 0x00
0000710e9ebd9cc1  mov rax, 0x5DADAF7CF530
0000710e9ebd9ccb  call rax
0000710e9ebd9ccd  movaps xmm9, [rsp]
0000710e9ebd9cd2  add rsp, 0x30
0000710e9ebd9cd6  vmovaps xmm0, [rsp]
0000710e9ebd9cdb  vmovaps xmm1, [rsp+0x10]
0000710e9ebd9ce1  vmovaps xmm2, [rsp+0x20]
0000710e9ebd9ce7  vmovaps xmm3, [rsp+0x30]
0000710e9ebd9ced  vmovaps xmm4, [rsp+0x40]
0000710e9ebd9cf3  vmovaps xmm5, [rsp+0x50]
0000710e9ebd9cf9  vmovaps xmm6, [rsp+0x60]
0000710e9ebd9cff  vmovaps xmm7, [rsp+0x70]
0000710e9ebd9d05  vmovaps xmm8, [rsp+0x80]
0000710e9ebd9d0e  vmovaps xmm10, [rsp+0x90]
0000710e9ebd9d17  vmovaps xmm11, [rsp+0xA0]
0000710e9ebd9d20  vmovaps xmm12, [rsp+0xB0]
0000710e9ebd9d29  vmovaps xmm13, [rsp+0xC0]
0000710e9ebd9d32  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd9d3b  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd9d44  add rsp, 0xF0
0000710e9ebd9d4b  pop r11
0000710e9ebd9d4d  pop r10
0000710e9ebd9d4f  pop r9
0000710e9ebd9d51  pop r8
0000710e9ebd9d53  pop rsi
0000710e9ebd9d54  pop rdi
0000710e9ebd9d55  pop rdx
0000710e9ebd9d56  pop rcx
0000710e9ebd9d57  pop rax
0000710e9ebd9d58  add rsp, 0x08
0000710e9ebd9d5c  jmp 0x0000710E9EBD8BCC
0000710e9ebd9d61  sub rsp, 0x08
0000710e9ebd9d65  push rax
0000710e9ebd9d66  push rcx
0000710e9ebd9d67  push rdx
0000710e9ebd9d68  push rdi
0000710e9ebd9d69  push rsi
0000710e9ebd9d6a  push r8
0000710e9ebd9d6c  push r9
0000710e9ebd9d6e  push r10
0000710e9ebd9d70  push r11
0000710e9ebd9d72  sub rsp, 0xF0
0000710e9ebd9d79  vmovaps [rsp], xmm0
0000710e9ebd9d7e  vmovaps [rsp+0x10], xmm1
0000710e9ebd9d84  vmovaps [rsp+0x20], xmm2
0000710e9ebd9d8a  vmovaps [rsp+0x30], xmm3
0000710e9ebd9d90  vmovaps [rsp+0x40], xmm4
0000710e9ebd9d96  vmovaps [rsp+0x50], xmm5
0000710e9ebd9d9c  vmovaps [rsp+0x60], xmm6
0000710e9ebd9da2  vmovaps [rsp+0x70], xmm7
0000710e9ebd9da8  vmovaps [rsp+0x80], xmm8
0000710e9ebd9db1  vmovaps [rsp+0x90], xmm9
0000710e9ebd9dba  vmovaps [rsp+0xA0], xmm11
0000710e9ebd9dc3  vmovaps [rsp+0xB0], xmm12
0000710e9ebd9dcc  vmovaps [rsp+0xC0], xmm13
0000710e9ebd9dd5  vmovaps [rsp+0xD0], xmm14
0000710e9ebd9dde  vmovaps [rsp+0xE0], xmm15
0000710e9ebd9de7  sub rsp, 0x30
0000710e9ebd9deb  movaps [rsp], xmm10
0000710e9ebd9df0  movaps [rsp+0x10], xmm12
0000710e9ebd9df6  movaps [rsp+0x20], xmm11
0000710e9ebd9dfc  lea rdi, [rsp]
0000710e9ebd9e00  mov esi, 0x00
0000710e9ebd9e05  mov rax, 0x5DADAF7CF530
0000710e9ebd9e0f  call rax
0000710e9ebd9e11  movaps xmm10, [rsp]
0000710e9ebd9e16  add rsp, 0x30
0000710e9ebd9e1a  vmovaps xmm0, [rsp]
0000710e9ebd9e1f  vmovaps xmm1, [rsp+0x10]
0000710e9ebd9e25  vmovaps xmm2, [rsp+0x20]
0000710e9ebd9e2b  vmovaps xmm3, [rsp+0x30]
0000710e9ebd9e31  vmovaps xmm4, [rsp+0x40]
0000710e9ebd9e37  vmovaps xmm5, [rsp+0x50]
0000710e9ebd9e3d  vmovaps xmm6, [rsp+0x60]
0000710e9ebd9e43  vmovaps xmm7, [rsp+0x70]
0000710e9ebd9e49  vmovaps xmm8, [rsp+0x80]
0000710e9ebd9e52  vmovaps xmm9, [rsp+0x90]
0000710e9ebd9e5b  vmovaps xmm11, [rsp+0xA0]
0000710e9ebd9e64  vmovaps xmm12, [rsp+0xB0]
0000710e9ebd9e6d  vmovaps xmm13, [rsp+0xC0]
0000710e9ebd9e76  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd9e7f  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd9e88  add rsp, 0xF0
0000710e9ebd9e8f  pop r11
0000710e9ebd9e91  pop r10
0000710e9ebd9e93  pop r9
0000710e9ebd9e95  pop r8
0000710e9ebd9e97  pop rsi
0000710e9ebd9e98  pop rdi
0000710e9ebd9e99  pop rdx
0000710e9ebd9e9a  pop rcx
0000710e9ebd9e9b  pop rax
0000710e9ebd9e9c  add rsp, 0x08
0000710e9ebd9ea0  jmp 0x0000710E9EBD8BE6
0000710e9ebd9ea5  sub rsp, 0x08
0000710e9ebd9ea9  push rax
0000710e9ebd9eaa  push rcx
0000710e9ebd9eab  push rdx
0000710e9ebd9eac  push rdi
0000710e9ebd9ead  push rsi
0000710e9ebd9eae  push r8
0000710e9ebd9eb0  push r9
0000710e9ebd9eb2  push r10
0000710e9ebd9eb4  push r11
0000710e9ebd9eb6  sub rsp, 0xF0
0000710e9ebd9ebd  vmovaps [rsp], xmm0
0000710e9ebd9ec2  vmovaps [rsp+0x10], xmm1
0000710e9ebd9ec8  vmovaps [rsp+0x20], xmm2
0000710e9ebd9ece  vmovaps [rsp+0x30], xmm3
0000710e9ebd9ed4  vmovaps [rsp+0x40], xmm4
0000710e9ebd9eda  vmovaps [rsp+0x50], xmm5
0000710e9ebd9ee0  vmovaps [rsp+0x60], xmm7
0000710e9ebd9ee6  vmovaps [rsp+0x70], xmm8
0000710e9ebd9eec  vmovaps [rsp+0x80], xmm9
0000710e9ebd9ef5  vmovaps [rsp+0x90], xmm10
0000710e9ebd9efe  vmovaps [rsp+0xA0], xmm11
0000710e9ebd9f07  vmovaps [rsp+0xB0], xmm12
0000710e9ebd9f10  vmovaps [rsp+0xC0], xmm13
0000710e9ebd9f19  vmovaps [rsp+0xD0], xmm14
0000710e9ebd9f22  vmovaps [rsp+0xE0], xmm15
0000710e9ebd9f2b  sub rsp, 0x30
0000710e9ebd9f2f  movaps [rsp], xmm6
0000710e9ebd9f33  movaps [rsp+0x10], xmm12
0000710e9ebd9f39  movaps [rsp+0x20], xmm11
0000710e9ebd9f3f  lea rdi, [rsp]
0000710e9ebd9f43  mov esi, 0x00
0000710e9ebd9f48  mov rax, 0x5DADAF7CF530
0000710e9ebd9f52  call rax
0000710e9ebd9f54  movaps xmm6, [rsp]
0000710e9ebd9f58  add rsp, 0x30
0000710e9ebd9f5c  vmovaps xmm0, [rsp]
0000710e9ebd9f61  vmovaps xmm1, [rsp+0x10]
0000710e9ebd9f67  vmovaps xmm2, [rsp+0x20]
0000710e9ebd9f6d  vmovaps xmm3, [rsp+0x30]
0000710e9ebd9f73  vmovaps xmm4, [rsp+0x40]
0000710e9ebd9f79  vmovaps xmm5, [rsp+0x50]
0000710e9ebd9f7f  vmovaps xmm7, [rsp+0x60]
0000710e9ebd9f85  vmovaps xmm8, [rsp+0x70]
0000710e9ebd9f8b  vmovaps xmm9, [rsp+0x80]
0000710e9ebd9f94  vmovaps xmm10, [rsp+0x90]
0000710e9ebd9f9d  vmovaps xmm11, [rsp+0xA0]
0000710e9ebd9fa6  vmovaps xmm12, [rsp+0xB0]
0000710e9ebd9faf  vmovaps xmm13, [rsp+0xC0]
0000710e9ebd9fb8  vmovaps xmm14, [rsp+0xD0]
0000710e9ebd9fc1  vmovaps xmm15, [rsp+0xE0]
0000710e9ebd9fca  add rsp, 0xF0
0000710e9ebd9fd1  pop r11
0000710e9ebd9fd3  pop r10
0000710e9ebd9fd5  pop r9
0000710e9ebd9fd7  pop r8
0000710e9ebd9fd9  pop rsi
0000710e9ebd9fda  pop rdi
0000710e9ebd9fdb  pop rdx
0000710e9ebd9fdc  pop rcx
0000710e9ebd9fdd  pop rax
0000710e9ebd9fde  add rsp, 0x08
0000710e9ebd9fe2  jmp 0x0000710E9EBD8C07
0000710e9ebd9fe7  sub rsp, 0x08
0000710e9ebd9feb  push rax
0000710e9ebd9fec  push rcx
0000710e9ebd9fed  push rdx
0000710e9ebd9fee  push rdi
0000710e9ebd9fef  push rsi
0000710e9ebd9ff0  push r8
0000710e9ebd9ff2  push r9
0000710e9ebd9ff4  push r10
0000710e9ebd9ff6  push r11
0000710e9ebd9ff8  sub rsp, 0xF0
0000710e9ebd9fff  vmovaps [rsp], xmm0
0000710e9ebda004  vmovaps [rsp+0x10], xmm1
0000710e9ebda00a  vmovaps [rsp+0x20], xmm2
0000710e9ebda010  vmovaps [rsp+0x30], xmm4
0000710e9ebda016  vmovaps [rsp+0x40], xmm5
0000710e9ebda01c  vmovaps [rsp+0x50], xmm6
0000710e9ebda022  vmovaps [rsp+0x60], xmm7
0000710e9ebda028  vmovaps [rsp+0x70], xmm8
0000710e9ebda02e  vmovaps [rsp+0x80], xmm9
0000710e9ebda037  vmovaps [rsp+0x90], xmm10
0000710e9ebda040  vmovaps [rsp+0xA0], xmm11
0000710e9ebda049  vmovaps [rsp+0xB0], xmm12
0000710e9ebda052  vmovaps [rsp+0xC0], xmm13
0000710e9ebda05b  vmovaps [rsp+0xD0], xmm14
0000710e9ebda064  vmovaps [rsp+0xE0], xmm15
0000710e9ebda06d  sub rsp, 0x30
0000710e9ebda071  movaps [rsp], xmm3
0000710e9ebda075  movaps [rsp+0x10], xmm5
0000710e9ebda07a  movaps [rsp+0x20], xmm4
0000710e9ebda07f  lea rdi, [rsp]
0000710e9ebda083  mov esi, 0x00
0000710e9ebda088  mov rax, 0x5DADAF7CF530
0000710e9ebda092  call rax
0000710e9ebda094  movaps xmm3, [rsp]
0000710e9ebda098  add rsp, 0x30
0000710e9ebda09c  vmovaps xmm0, [rsp]
0000710e9ebda0a1  vmovaps xmm1, [rsp+0x10]
0000710e9ebda0a7  vmovaps xmm2, [rsp+0x20]
0000710e9ebda0ad  vmovaps xmm4, [rsp+0x30]
0000710e9ebda0b3  vmovaps xmm5, [rsp+0x40]
0000710e9ebda0b9  vmovaps xmm6, [rsp+0x50]
0000710e9ebda0bf  vmovaps xmm7, [rsp+0x60]
0000710e9ebda0c5  vmovaps xmm8, [rsp+0x70]
0000710e9ebda0cb  vmovaps xmm9, [rsp+0x80]
0000710e9ebda0d4  vmovaps xmm10, [rsp+0x90]
0000710e9ebda0dd  vmovaps xmm11, [rsp+0xA0]
0000710e9ebda0e6  vmovaps xmm12, [rsp+0xB0]
0000710e9ebda0ef  vmovaps xmm13, [rsp+0xC0]
0000710e9ebda0f8  vmovaps xmm14, [rsp+0xD0]
0000710e9ebda101  vmovaps xmm15, [rsp+0xE0]
0000710e9ebda10a  add rsp, 0xF0
0000710e9ebda111  pop r11
0000710e9ebda113  pop r10
0000710e9ebda115  pop r9
0000710e9ebda117  pop r8
0000710e9ebda119  pop rsi
0000710e9ebda11a  pop rdi
0000710e9ebda11b  pop rdx
0000710e9ebda11c  pop rcx
0000710e9ebda11d  pop rax
0000710e9ebda11e  add rsp, 0x08
0000710e9ebda122  jmp 0x0000710E9EBD8C68
0000710e9ebda127  sub rsp, 0x08
0000710e9ebda12b  push rax
0000710e9ebda12c  push rcx
0000710e9ebda12d  push rdx
0000710e9ebda12e  push rdi
0000710e9ebda12f  push rsi
0000710e9ebda130  push r8
0000710e9ebda132  push r9
0000710e9ebda134  push r10
0000710e9ebda136  push r11
0000710e9ebda138  sub rsp, 0xF0
0000710e9ebda13f  vmovaps [rsp], xmm0
0000710e9ebda144  vmovaps [rsp+0x10], xmm1
0000710e9ebda14a  vmovaps [rsp+0x20], xmm2
0000710e9ebda150  vmovaps [rsp+0x30], xmm3
0000710e9ebda156  vmovaps [rsp+0x40], xmm4
0000710e9ebda15c  vmovaps [rsp+0x50], xmm6
0000710e9ebda162  vmovaps [rsp+0x60], xmm7
0000710e9ebda168  vmovaps [rsp+0x70], xmm8
0000710e9ebda16e  vmovaps [rsp+0x80], xmm9
0000710e9ebda177  vmovaps [rsp+0x90], xmm10
0000710e9ebda180  vmovaps [rsp+0xA0], xmm11
0000710e9ebda189  vmovaps [rsp+0xB0], xmm12
0000710e9ebda192  vmovaps [rsp+0xC0], xmm13
0000710e9ebda19b  vmovaps [rsp+0xD0], xmm14
0000710e9ebda1a4  vmovaps [rsp+0xE0], xmm15
0000710e9ebda1ad  sub rsp, 0x30
0000710e9ebda1b1  movaps [rsp], xmm5
0000710e9ebda1b5  movaps [rsp+0x10], xmm8
0000710e9ebda1bb  movaps [rsp+0x20], xmm15
0000710e9ebda1c1  lea rdi, [rsp]
0000710e9ebda1c5  mov esi, 0x00
0000710e9ebda1ca  mov rax, 0x5DADAF7CF530
0000710e9ebda1d4  call rax
0000710e9ebda1d6  movaps xmm5, [rsp]
0000710e9ebda1da  add rsp, 0x30
0000710e9ebda1de  vmovaps xmm0, [rsp]
0000710e9ebda1e3  vmovaps xmm1, [rsp+0x10]
0000710e9ebda1e9  vmovaps xmm2, [rsp+0x20]
0000710e9ebda1ef  vmovaps xmm3, [rsp+0x30]
0000710e9ebda1f5  vmovaps xmm4, [rsp+0x40]
0000710e9ebda1fb  vmovaps xmm6, [rsp+0x50]
0000710e9ebda201  vmovaps xmm7, [rsp+0x60]
0000710e9ebda207  vmovaps xmm8, [rsp+0x70]
0000710e9ebda20d  vmovaps xmm9, [rsp+0x80]
0000710e9ebda216  vmovaps xmm10, [rsp+0x90]
0000710e9ebda21f  vmovaps xmm11, [rsp+0xA0]
0000710e9ebda228  vmovaps xmm12, [rsp+0xB0]
0000710e9ebda231  vmovaps xmm13, [rsp+0xC0]
0000710e9ebda23a  vmovaps xmm14, [rsp+0xD0]
0000710e9ebda243  vmovaps xmm15, [rsp+0xE0]
0000710e9ebda24c  add rsp, 0xF0
0000710e9ebda253  pop r11
0000710e9ebda255  pop r10
0000710e9ebda257  pop r9
0000710e9ebda259  pop r8
0000710e9ebda25b  pop rsi
0000710e9ebda25c  pop rdi
0000710e9ebda25d  pop rdx
0000710e9ebda25e  pop rcx
0000710e9ebda25f  pop rax
0000710e9ebda260  add rsp, 0x08
0000710e9ebda264  jmp 0x0000710E9EBD8CA0
0000710e9ebda269  sub rsp, 0x08
0000710e9ebda26d  push rax
0000710e9ebda26e  push rcx
0000710e9ebda26f  push rdx
0000710e9ebda270  push rdi
0000710e9ebda271  push rsi
0000710e9ebda272  push r8
0000710e9ebda274  push r9
0000710e9ebda276  push r10
0000710e9ebda278  push r11
0000710e9ebda27a  sub rsp, 0xF0
0000710e9ebda281  vmovaps [rsp], xmm0
0000710e9ebda286  vmovaps [rsp+0x10], xmm1
0000710e9ebda28c  vmovaps [rsp+0x20], xmm2
0000710e9ebda292  vmovaps [rsp+0x30], xmm3
0000710e9ebda298  vmovaps [rsp+0x40], xmm5
0000710e9ebda29e  vmovaps [rsp+0x50], xmm6
0000710e9ebda2a4  vmovaps [rsp+0x60], xmm7
0000710e9ebda2aa  vmovaps [rsp+0x70], xmm8
0000710e9ebda2b0  vmovaps [rsp+0x80], xmm9
0000710e9ebda2b9  vmovaps [rsp+0x90], xmm10
0000710e9ebda2c2  vmovaps [rsp+0xA0], xmm11
0000710e9ebda2cb  vmovaps [rsp+0xB0], xmm12
0000710e9ebda2d4  vmovaps [rsp+0xC0], xmm13
0000710e9ebda2dd  vmovaps [rsp+0xD0], xmm14
0000710e9ebda2e6  vmovaps [rsp+0xE0], xmm15
0000710e9ebda2ef  sub rsp, 0x30
0000710e9ebda2f3  movaps [rsp], xmm4
0000710e9ebda2f7  movaps [rsp+0x10], xmm9
0000710e9ebda2fd  movaps [rsp+0x20], xmm8
0000710e9ebda303  lea rdi, [rsp]
0000710e9ebda307  mov esi, 0x00
0000710e9ebda30c  mov rax, 0x5DADAF7CF530
0000710e9ebda316  call rax
0000710e9ebda318  movaps xmm4, [rsp]
0000710e9ebda31c  add rsp, 0x30
0000710e9ebda320  vmovaps xmm0, [rsp]
0000710e9ebda325  vmovaps xmm1, [rsp+0x10]
0000710e9ebda32b  vmovaps xmm2, [rsp+0x20]
0000710e9ebda331  vmovaps xmm3, [rsp+0x30]
0000710e9ebda337  vmovaps xmm5, [rsp+0x40]
0000710e9ebda33d  vmovaps xmm6, [rsp+0x50]
0000710e9ebda343  vmovaps xmm7, [rsp+0x60]
0000710e9ebda349  vmovaps xmm8, [rsp+0x70]
0000710e9ebda34f  vmovaps xmm9, [rsp+0x80]
0000710e9ebda358  vmovaps xmm10, [rsp+0x90]
0000710e9ebda361  vmovaps xmm11, [rsp+0xA0]
0000710e9ebda36a  vmovaps xmm12, [rsp+0xB0]
0000710e9ebda373  vmovaps xmm13, [rsp+0xC0]
0000710e9ebda37c  vmovaps xmm14, [rsp+0xD0]
0000710e9ebda385  vmovaps xmm15, [rsp+0xE0]
0000710e9ebda38e  add rsp, 0xF0
0000710e9ebda395  pop r11
0000710e9ebda397  pop r10
0000710e9ebda399  pop r9
0000710e9ebda39b  pop r8
0000710e9ebda39d  pop rsi
0000710e9ebda39e  pop rdi
0000710e9ebda39f  pop rdx
0000710e9ebda3a0  pop rcx
0000710e9ebda3a1  pop rax
0000710e9ebda3a2  add rsp, 0x08
0000710e9ebda3a6  jmp 0x0000710E9EBD8CC1
0000710e9ebda3ab  sub rsp, 0x08
0000710e9ebda3af  push rax
0000710e9ebda3b0  push rcx
0000710e9ebda3b1  push rdx
0000710e9ebda3b2  push rdi
0000710e9ebda3b3  push rsi
0000710e9ebda3b4  push r8
0000710e9ebda3b6  push r9
0000710e9ebda3b8  push r10
0000710e9ebda3ba  push r11
0000710e9ebda3bc  sub rsp, 0xF0
0000710e9ebda3c3  vmovaps [rsp], xmm0
0000710e9ebda3c8  vmovaps [rsp+0x10], xmm1
0000710e9ebda3ce  vmovaps [rsp+0x20], xmm2
0000710e9ebda3d4  vmovaps [rsp+0x30], xmm3
0000710e9ebda3da  vmovaps [rsp+0x40], xmm4
0000710e9ebda3e0  vmovaps [rsp+0x50], xmm5
0000710e9ebda3e6  vmovaps [rsp+0x60], xmm6
0000710e9ebda3ec  vmovaps [rsp+0x70], xmm7
0000710e9ebda3f2  vmovaps [rsp+0x80], xmm8
0000710e9ebda3fb  vmovaps [rsp+0x90], xmm10
0000710e9ebda404  vmovaps [rsp+0xA0], xmm11
0000710e9ebda40d  vmovaps [rsp+0xB0], xmm12
0000710e9ebda416  vmovaps [rsp+0xC0], xmm13
0000710e9ebda41f  vmovaps [rsp+0xD0], xmm14
0000710e9ebda428  vmovaps [rsp+0xE0], xmm15
0000710e9ebda431  sub rsp, 0x30
0000710e9ebda435  movaps [rsp], xmm9
0000710e9ebda43a  movaps [rsp+0x10], xmm10
0000710e9ebda440  movaps [rsp+0x20], xmm8
0000710e9ebda446  lea rdi, [rsp]
0000710e9ebda44a  mov esi, 0x00
0000710e9ebda44f  mov rax, 0x5DADAF7CF530
0000710e9ebda459  call rax
0000710e9ebda45b  movaps xmm9, [rsp]
0000710e9ebda460  add rsp, 0x30
0000710e9ebda464  vmovaps xmm0, [rsp]
0000710e9ebda469  vmovaps xmm1, [rsp+0x10]
0000710e9ebda46f  vmovaps xmm2, [rsp+0x20]
0000710e9ebda475  vmovaps xmm3, [rsp+0x30]
0000710e9ebda47b  vmovaps xmm4, [rsp+0x40]
0000710e9ebda481  vmovaps xmm5, [rsp+0x50]
0000710e9ebda487  vmovaps xmm6, [rsp+0x60]
0000710e9ebda48d  vmovaps xmm7, [rsp+0x70]
0000710e9ebda493  vmovaps xmm8, [rsp+0x80]
0000710e9ebda49c  vmovaps xmm10, [rsp+0x90]
0000710e9ebda4a5  vmovaps xmm11, [rsp+0xA0]
0000710e9ebda4ae  vmovaps xmm12, [rsp+0xB0]
0000710e9ebda4b7  vmovaps xmm13, [rsp+0xC0]
0000710e9ebda4c0  vmovaps xmm14, [rsp+0xD0]
0000710e9ebda4c9  vmovaps xmm15, [rsp+0xE0]
0000710e9ebda4d2  add rsp, 0xF0
0000710e9ebda4d9  pop r11
0000710e9ebda4db  pop r10
0000710e9ebda4dd  pop r9
0000710e9ebda4df  pop r8
0000710e9ebda4e1  pop rsi
0000710e9ebda4e2  pop rdi
0000710e9ebda4e3  pop rdx
0000710e9ebda4e4  pop rcx
0000710e9ebda4e5  pop rax
0000710e9ebda4e6  add rsp, 0x08
0000710e9ebda4ea  jmp 0x0000710E9EBD8CDB
0000710e9ebda4ef  call 0x0000710E9EAD64F0
0000710e9ebda4f4  jmp 0x0000710E9EBD8DF5
0000710e9ebda4f9  call 0x0000710E9EAD64F0
0000710e9ebda4fe  jmp 0x0000710E9EBD8E0B
0000710e9ebda503  sub rsp, 0x08
0000710e9ebda507  push rax
0000710e9ebda508  push rcx
0000710e9ebda509  push rdx
0000710e9ebda50a  push rdi
0000710e9ebda50b  push rsi
0000710e9ebda50c  push r8
0000710e9ebda50e  push r9
0000710e9ebda510  push r10
0000710e9ebda512  push r11
0000710e9ebda514  sub rsp, 0xF0
0000710e9ebda51b  vmovaps [rsp], xmm0
0000710e9ebda520  vmovaps [rsp+0x10], xmm2
0000710e9ebda526  vmovaps [rsp+0x20], xmm3
0000710e9ebda52c  vmovaps [rsp+0x30], xmm4
0000710e9ebda532  vmovaps [rsp+0x40], xmm5
0000710e9ebda538  vmovaps [rsp+0x50], xmm6
0000710e9ebda53e  vmovaps [rsp+0x60], xmm7
0000710e9ebda544  vmovaps [rsp+0x70], xmm8
0000710e9ebda54a  vmovaps [rsp+0x80], xmm9
0000710e9ebda553  vmovaps [rsp+0x90], xmm10
0000710e9ebda55c  vmovaps [rsp+0xA0], xmm11
0000710e9ebda565  vmovaps [rsp+0xB0], xmm12
0000710e9ebda56e  vmovaps [rsp+0xC0], xmm13
0000710e9ebda577  vmovaps [rsp+0xD0], xmm14
0000710e9ebda580  vmovaps [rsp+0xE0], xmm15
0000710e9ebda589  sub rsp, 0x30
0000710e9ebda58d  movaps [rsp], xmm1
0000710e9ebda591  movaps [rsp+0x10], xmm6
0000710e9ebda596  movaps [rsp+0x20], xmm15
0000710e9ebda59c  lea rdi, [rsp]
0000710e9ebda5a0  mov esi, 0x00
0000710e9ebda5a5  mov rax, 0x5DADAF7CF530
0000710e9ebda5af  call rax
0000710e9ebda5b1  movaps xmm1, [rsp]
0000710e9ebda5b5  add rsp, 0x30
0000710e9ebda5b9  vmovaps xmm0, [rsp]
0000710e9ebda5be  vmovaps xmm2, [rsp+0x10]
0000710e9ebda5c4  vmovaps xmm3, [rsp+0x20]
0000710e9ebda5ca  vmovaps xmm4, [rsp+0x30]
0000710e9ebda5d0  vmovaps xmm5, [rsp+0x40]
0000710e9ebda5d6  vmovaps xmm6, [rsp+0x50]
0000710e9ebda5dc  vmovaps xmm7, [rsp+0x60]
0000710e9ebda5e2  vmovaps xmm8, [rsp+0x70]
0000710e9ebda5e8  vmovaps xmm9, [rsp+0x80]
0000710e9ebda5f1  vmovaps xmm10, [rsp+0x90]
0000710e9ebda5fa  vmovaps xmm11, [rsp+0xA0]
0000710e9ebda603  vmovaps xmm12, [rsp+0xB0]
0000710e9ebda60c  vmovaps xmm13, [rsp+0xC0]
0000710e9ebda615  vmovaps xmm14, [rsp+0xD0]
0000710e9ebda61e  vmovaps xmm15, [rsp+0xE0]
0000710e9ebda627  add rsp, 0xF0
0000710e9ebda62e  pop r11
0000710e9ebda630  pop r10
0000710e9ebda632  pop r9
0000710e9ebda634  pop r8
0000710e9ebda636  pop rsi
0000710e9ebda637  pop rdi
0000710e9ebda638  pop rdx
0000710e9ebda639  pop rcx
0000710e9ebda63a  pop rax
0000710e9ebda63b  add rsp, 0x08
0000710e9ebda63f  jmp 0x0000710E9EBD8E48
0000710e9ebda644  call 0x0000710E9EAE5820
0000710e9ebda649  jmp 0x0000710E9EBD8E55
0000710e9ebda64e  sub rsp, 0x08
0000710e9ebda652  push rax
0000710e9ebda653  push rcx
0000710e9ebda654  push rdx
0000710e9ebda655  push rdi
0000710e9ebda656  push rsi
0000710e9ebda657  push r8
0000710e9ebda659  push r9
0000710e9ebda65b  push r10
0000710e9ebda65d  push r11
0000710e9ebda65f  sub rsp, 0xF0
0000710e9ebda666  vmovaps [rsp], xmm0
0000710e9ebda66b  vmovaps [rsp+0x10], xmm1
0000710e9ebda671  vmovaps [rsp+0x20], xmm2
0000710e9ebda677  vmovaps [rsp+0x30], xmm3
0000710e9ebda67d  vmovaps [rsp+0x40], xmm4
0000710e9ebda683  vmovaps [rsp+0x50], xmm5
0000710e9ebda689  vmovaps [rsp+0x60], xmm6
0000710e9ebda68f  vmovaps [rsp+0x70], xmm7
0000710e9ebda695  vmovaps [rsp+0x80], xmm8
0000710e9ebda69e  vmovaps [rsp+0x90], xmm9
0000710e9ebda6a7  vmovaps [rsp+0xA0], xmm10
0000710e9ebda6b0  vmovaps [rsp+0xB0], xmm11
0000710e9ebda6b9  vmovaps [rsp+0xC0], xmm12
0000710e9ebda6c2  vmovaps [rsp+0xD0], xmm13
0000710e9ebda6cb  vmovaps [rsp+0xE0], xmm15
0000710e9ebda6d4  sub rsp, 0x30
0000710e9ebda6d8  movaps [rsp], xmm14
0000710e9ebda6dd  movaps [rsp+0x10], xmm4
0000710e9ebda6e2  movaps [rsp+0x20], xmm3
0000710e9ebda6e7  lea rdi, [rsp]
0000710e9ebda6eb  mov esi, 0x00
0000710e9ebda6f0  mov rax, 0x5DADAF7CF530
0000710e9ebda6fa  call rax
0000710e9ebda6fc  movaps xmm14, [rsp]
0000710e9ebda701  add rsp, 0x30
0000710e9ebda705  vmovaps xmm0, [rsp]
0000710e9ebda70a  vmovaps xmm1, [rsp+0x10]
0000710e9ebda710  vmovaps xmm2, [rsp+0x20]
0000710e9ebda716  vmovaps xmm3, [rsp+0x30]
0000710e9ebda71c  vmovaps xmm4, [rsp+0x40]
0000710e9ebda722  vmovaps xmm5, [rsp+0x50]
0000710e9ebda728  vmovaps xmm6, [rsp+0x60]
0000710e9ebda72e  vmovaps xmm7, [rsp+0x70]
0000710e9ebda734  vmovaps xmm8, [rsp+0x80]
0000710e9ebda73d  vmovaps xmm9, [rsp+0x90]
0000710e9ebda746  vmovaps xmm10, [rsp+0xA0]
0000710e9ebda74f  vmovaps xmm11, [rsp+0xB0]
0000710e9ebda758  vmovaps xmm12, [rsp+0xC0]
0000710e9ebda761  vmovaps xmm13, [rsp+0xD0]
0000710e9ebda76a  vmovaps xmm15, [rsp+0xE0]
0000710e9ebda773  add rsp, 0xF0
0000710e9ebda77a  pop r11
0000710e9ebda77c  pop r10
0000710e9ebda77e  pop r9
0000710e9ebda780  pop r8
0000710e9ebda782  pop rsi
0000710e9ebda783  pop rdi
0000710e9ebda784  pop rdx
0000710e9ebda785  pop rcx
0000710e9ebda786  pop rax
0000710e9ebda787  add rsp, 0x08
0000710e9ebda78b  jmp 0x0000710E9EBD8E6F
0000710e9ebda790  sub rsp, 0x08
0000710e9ebda794  push rax
0000710e9ebda795  push rcx
0000710e9ebda796  push rdx
0000710e9ebda797  push rdi
0000710e9ebda798  push rsi
0000710e9ebda799  push r8
0000710e9ebda79b  push r9
0000710e9ebda79d  push r10
0000710e9ebda79f  push r11
0000710e9ebda7a1  sub rsp, 0xF0
0000710e9ebda7a8  vmovaps [rsp], xmm0
0000710e9ebda7ad  vmovaps [rsp+0x10], xmm1
0000710e9ebda7b3  vmovaps [rsp+0x20], xmm2
0000710e9ebda7b9  vmovaps [rsp+0x30], xmm3
0000710e9ebda7bf  vmovaps [rsp+0x40], xmm4
0000710e9ebda7c5  vmovaps [rsp+0x50], xmm5
0000710e9ebda7cb  vmovaps [rsp+0x60], xmm7
0000710e9ebda7d1  vmovaps [rsp+0x70], xmm8
0000710e9ebda7d7  vmovaps [rsp+0x80], xmm9
0000710e9ebda7e0  vmovaps [rsp+0x90], xmm10
0000710e9ebda7e9  vmovaps [rsp+0xA0], xmm11
0000710e9ebda7f2  vmovaps [rsp+0xB0], xmm12
0000710e9ebda7fb  vmovaps [rsp+0xC0], xmm13
0000710e9ebda804  vmovaps [rsp+0xD0], xmm14
0000710e9ebda80d  vmovaps [rsp+0xE0], xmm15
0000710e9ebda816  sub rsp, 0x30
0000710e9ebda81a  movaps [rsp], xmm6
0000710e9ebda81e  movaps [rsp+0x10], xmm9
0000710e9ebda824  movaps [rsp+0x20], xmm7
0000710e9ebda829  lea rdi, [rsp]
0000710e9ebda82d  mov esi, 0x00
0000710e9ebda832  mov rax, 0x5DADAF7CF530
0000710e9ebda83c  call rax
0000710e9ebda83e  movaps xmm6, [rsp]
0000710e9ebda842  add rsp, 0x30
0000710e9ebda846  vmovaps xmm0, [rsp]
0000710e9ebda84b  vmovaps xmm1, [rsp+0x10]
0000710e9ebda851  vmovaps xmm2, [rsp+0x20]
0000710e9ebda857  vmovaps xmm3, [rsp+0x30]
0000710e9ebda85d  vmovaps xmm4, [rsp+0x40]
0000710e9ebda863  vmovaps xmm5, [rsp+0x50]
0000710e9ebda869  vmovaps xmm7, [rsp+0x60]
0000710e9ebda86f  vmovaps xmm8, [rsp+0x70]
0000710e9ebda875  vmovaps xmm9, [rsp+0x80]
0000710e9ebda87e  vmovaps xmm10, [rsp+0x90]
0000710e9ebda887  vmovaps xmm11, [rsp+0xA0]
0000710e9ebda890  vmovaps xmm12, [rsp+0xB0]
0000710e9ebda899  vmovaps xmm13, [rsp+0xC0]
0000710e9ebda8a2  vmovaps xmm14, [rsp+0xD0]
0000710e9ebda8ab  vmovaps xmm15, [rsp+0xE0]
0000710e9ebda8b4  add rsp, 0xF0
0000710e9ebda8bb  pop r11
0000710e9ebda8bd  pop r10
0000710e9ebda8bf  pop r9
0000710e9ebda8c1  pop r8
0000710e9ebda8c3  pop rsi
0000710e9ebda8c4  pop rdi
0000710e9ebda8c5  pop rdx
0000710e9ebda8c6  pop rcx
0000710e9ebda8c7  pop rax
0000710e9ebda8c8  add rsp, 0x08
0000710e9ebda8cc  jmp 0x0000710E9EBD8E87
0000710e9ebda8d1  sub rsp, 0x08
0000710e9ebda8d5  push rax
0000710e9ebda8d6  push rcx
0000710e9ebda8d7  push rdx
0000710e9ebda8d8  push rdi
0000710e9ebda8d9  push rsi
0000710e9ebda8da  push r8
0000710e9ebda8dc  push r9
0000710e9ebda8de  push r10
0000710e9ebda8e0  push r11
0000710e9ebda8e2  sub rsp, 0xF0
0000710e9ebda8e9  vmovaps [rsp], xmm0
0000710e9ebda8ee  vmovaps [rsp+0x10], xmm1
0000710e9ebda8f4  vmovaps [rsp+0x20], xmm2
0000710e9ebda8fa  vmovaps [rsp+0x30], xmm3
0000710e9ebda900  vmovaps [rsp+0x40], xmm4
0000710e9ebda906  vmovaps [rsp+0x50], xmm5
0000710e9ebda90c  vmovaps [rsp+0x60], xmm6
0000710e9ebda912  vmovaps [rsp+0x70], xmm8
0000710e9ebda918  vmovaps [rsp+0x80], xmm9
0000710e9ebda921  vmovaps [rsp+0x90], xmm10
0000710e9ebda92a  vmovaps [rsp+0xA0], xmm11
0000710e9ebda933  vmovaps [rsp+0xB0], xmm12
0000710e9ebda93c  vmovaps [rsp+0xC0], xmm13
0000710e9ebda945  vmovaps [rsp+0xD0], xmm14
0000710e9ebda94e  vmovaps [rsp+0xE0], xmm15
0000710e9ebda957  sub rsp, 0x30
0000710e9ebda95b  movaps [rsp], xmm7
0000710e9ebda95f  movaps [rsp+0x10], xmm4
0000710e9ebda964  movaps [rsp+0x20], xmm9
0000710e9ebda96a  lea rdi, [rsp]
0000710e9ebda96e  mov esi, 0x00
0000710e9ebda973  mov rax, 0x5DADAF7CF530
0000710e9ebda97d  call rax
0000710e9ebda97f  movaps xmm7, [rsp]
0000710e9ebda983  add rsp, 0x30
0000710e9ebda987  vmovaps xmm0, [rsp]
0000710e9ebda98c  vmovaps xmm1, [rsp+0x10]
0000710e9ebda992  vmovaps xmm2, [rsp+0x20]
0000710e9ebda998  vmovaps xmm3, [rsp+0x30]
0000710e9ebda99e  vmovaps xmm4, [rsp+0x40]
0000710e9ebda9a4  vmovaps xmm5, [rsp+0x50]
0000710e9ebda9aa  vmovaps xmm6, [rsp+0x60]
0000710e9ebda9b0  vmovaps xmm8, [rsp+0x70]
0000710e9ebda9b6  vmovaps xmm9, [rsp+0x80]
0000710e9ebda9bf  vmovaps xmm10, [rsp+0x90]
0000710e9ebda9c8  vmovaps xmm11, [rsp+0xA0]
0000710e9ebda9d1  vmovaps xmm12, [rsp+0xB0]
0000710e9ebda9da  vmovaps xmm13, [rsp+0xC0]
0000710e9ebda9e3  vmovaps xmm14, [rsp+0xD0]
0000710e9ebda9ec  vmovaps xmm15, [rsp+0xE0]
0000710e9ebda9f5  add rsp, 0xF0
0000710e9ebda9fc  pop r11
0000710e9ebda9fe  pop r10
0000710e9ebdaa00  pop r9
0000710e9ebdaa02  pop r8
0000710e9ebdaa04  pop rsi
0000710e9ebdaa05  pop rdi
0000710e9ebdaa06  pop rdx
0000710e9ebdaa07  pop rcx
0000710e9ebdaa08  pop rax
0000710e9ebdaa09  add rsp, 0x08
0000710e9ebdaa0d  jmp 0x0000710E9EBD8EB4
0000710e9ebdaa12  sub rsp, 0x08
0000710e9ebdaa16  push rax
0000710e9ebdaa17  push rcx
0000710e9ebdaa18  push rdx
0000710e9ebdaa19  push rdi
0000710e9ebdaa1a  push rsi
0000710e9ebdaa1b  push r8
0000710e9ebdaa1d  push r9
0000710e9ebdaa1f  push r10
0000710e9ebdaa21  push r11
0000710e9ebdaa23  sub rsp, 0xF0
0000710e9ebdaa2a  vmovaps [rsp], xmm0
0000710e9ebdaa2f  vmovaps [rsp+0x10], xmm1
0000710e9ebdaa35  vmovaps [rsp+0x20], xmm2
0000710e9ebdaa3b  vmovaps [rsp+0x30], xmm3
0000710e9ebdaa41  vmovaps [rsp+0x40], xmm5
0000710e9ebdaa47  vmovaps [rsp+0x50], xmm6
0000710e9ebdaa4d  vmovaps [rsp+0x60], xmm7
0000710e9ebdaa53  vmovaps [rsp+0x70], xmm8
0000710e9ebdaa59  vmovaps [rsp+0x80], xmm9
0000710e9ebdaa62  vmovaps [rsp+0x90], xmm10
0000710e9ebdaa6b  vmovaps [rsp+0xA0], xmm11
0000710e9ebdaa74  vmovaps [rsp+0xB0], xmm12
0000710e9ebdaa7d  vmovaps [rsp+0xC0], xmm13
0000710e9ebdaa86  vmovaps [rsp+0xD0], xmm14
0000710e9ebdaa8f  vmovaps [rsp+0xE0], xmm15
0000710e9ebdaa98  sub rsp, 0x30
0000710e9ebdaa9c  movaps [rsp], xmm4
0000710e9ebdaaa0  movaps [rsp+0x10], xmm15
0000710e9ebdaaa6  movaps [rsp+0x20], xmm9
0000710e9ebdaaac  lea rdi, [rsp]
0000710e9ebdaab0  mov esi, 0x00
0000710e9ebdaab5  mov rax, 0x5DADAF7CF530
0000710e9ebdaabf  call rax
0000710e9ebdaac1  movaps xmm4, [rsp]
0000710e9ebdaac5  add rsp, 0x30
0000710e9ebdaac9  vmovaps xmm0, [rsp]
0000710e9ebdaace  vmovaps xmm1, [rsp+0x10]
0000710e9ebdaad4  vmovaps xmm2, [rsp+0x20]
0000710e9ebdaada  vmovaps xmm3, [rsp+0x30]
0000710e9ebdaae0  vmovaps xmm5, [rsp+0x40]
0000710e9ebdaae6  vmovaps xmm6, [rsp+0x50]
0000710e9ebdaaec  vmovaps xmm7, [rsp+0x60]
0000710e9ebdaaf2  vmovaps xmm8, [rsp+0x70]
0000710e9ebdaaf8  vmovaps xmm9, [rsp+0x80]
0000710e9ebdab01  vmovaps xmm10, [rsp+0x90]
0000710e9ebdab0a  vmovaps xmm11, [rsp+0xA0]
0000710e9ebdab13  vmovaps xmm12, [rsp+0xB0]
0000710e9ebdab1c  vmovaps xmm13, [rsp+0xC0]
0000710e9ebdab25  vmovaps xmm14, [rsp+0xD0]
0000710e9ebdab2e  vmovaps xmm15, [rsp+0xE0]
0000710e9ebdab37  add rsp, 0xF0
0000710e9ebdab3e  pop r11
0000710e9ebdab40  pop r10
0000710e9ebdab42  pop r9
0000710e9ebdab44  pop r8
0000710e9ebdab46  pop rsi
0000710e9ebdab47  pop rdi
0000710e9ebdab48  pop rdx
0000710e9ebdab49  pop rcx
0000710e9ebdab4a  pop rax
0000710e9ebdab4b  add rsp, 0x08
0000710e9ebdab4f  jmp 0x0000710E9EBD8ED9
0000710e9ebdab54  call 0x0000710E9EAE5820
0000710e9ebdab59  jmp 0x0000710E9EBD8EE6
0000710e9ebdab5e  sub rsp, 0x08
0000710e9ebdab62  push rax
0000710e9ebdab63  push rcx
0000710e9ebdab64  push rdx
0000710e9ebdab65  push rdi
0000710e9ebdab66  push rsi
0000710e9ebdab67  push r8
0000710e9ebdab69  push r9
0000710e9ebdab6b  push r10
0000710e9ebdab6d  push r11
0000710e9ebdab6f  sub rsp, 0xF0
0000710e9ebdab76  vmovaps [rsp], xmm0
0000710e9ebdab7b  vmovaps [rsp+0x10], xmm1
0000710e9ebdab81  vmovaps [rsp+0x20], xmm2
0000710e9ebdab87  vmovaps [rsp+0x30], xmm4
0000710e9ebdab8d  vmovaps [rsp+0x40], xmm5
0000710e9ebdab93  vmovaps [rsp+0x50], xmm6
0000710e9ebdab99  vmovaps [rsp+0x60], xmm7
0000710e9ebdab9f  vmovaps [rsp+0x70], xmm8
0000710e9ebdaba5  vmovaps [rsp+0x80], xmm9
0000710e9ebdabae  vmovaps [rsp+0x90], xmm10
0000710e9ebdabb7  vmovaps [rsp+0xA0], xmm11
0000710e9ebdabc0  vmovaps [rsp+0xB0], xmm12
0000710e9ebdabc9  vmovaps [rsp+0xC0], xmm13
0000710e9ebdabd2  vmovaps [rsp+0xD0], xmm14
0000710e9ebdabdb  vmovaps [rsp+0xE0], xmm15
0000710e9ebdabe4  sub rsp, 0x30
0000710e9ebdabe8  movaps [rsp], xmm3
0000710e9ebdabec  movaps [rsp+0x10], xmm1
0000710e9ebdabf1  movaps [rsp+0x20], xmm9
0000710e9ebdabf7  lea rdi, [rsp]
0000710e9ebdabfb  mov esi, 0x00
0000710e9ebdac00  mov rax, 0x5DADAF7CF530
0000710e9ebdac0a  call rax
0000710e9ebdac0c  movaps xmm3, [rsp]
0000710e9ebdac10  add rsp, 0x30
0000710e9ebdac14  vmovaps xmm0, [rsp]
0000710e9ebdac19  vmovaps xmm1, [rsp+0x10]
0000710e9ebdac1f  vmovaps xmm2, [rsp+0x20]
0000710e9ebdac25  vmovaps xmm4, [rsp+0x30]
0000710e9ebdac2b  vmovaps xmm5, [rsp+0x40]
0000710e9ebdac31  vmovaps xmm6, [rsp+0x50]
0000710e9ebdac37  vmovaps xmm7, [rsp+0x60]
0000710e9ebdac3d  vmovaps xmm8, [rsp+0x70]
0000710e9ebdac43  vmovaps xmm9, [rsp+0x80]
0000710e9ebdac4c  vmovaps xmm10, [rsp+0x90]
0000710e9ebdac55  vmovaps xmm11, [rsp+0xA0]
0000710e9ebdac5e  vmovaps xmm12, [rsp+0xB0]
0000710e9ebdac67  vmovaps xmm13, [rsp+0xC0]
0000710e9ebdac70  vmovaps xmm14, [rsp+0xD0]
0000710e9ebdac79  vmovaps xmm15, [rsp+0xE0]
0000710e9ebdac82  add rsp, 0xF0
0000710e9ebdac89  pop r11
0000710e9ebdac8b  pop r10
0000710e9ebdac8d  pop r9
0000710e9ebdac8f  pop r8
0000710e9ebdac91  pop rsi
0000710e9ebdac92  pop rdi
0000710e9ebdac93  pop rdx
0000710e9ebdac94  pop rcx
0000710e9ebdac95  pop rax
0000710e9ebdac96  add rsp, 0x08
0000710e9ebdac9a  jmp 0x0000710E9EBD8F23
0000710e9ebdac9f  sub rsp, 0x08
0000710e9ebdaca3  push rax
0000710e9ebdaca4  push rcx
0000710e9ebdaca5  push rdx
0000710e9ebdaca6  push rdi
0000710e9ebdaca7  push rsi
0000710e9ebdaca8  push r8
0000710e9ebdacaa  push r9
0000710e9ebdacac  push r10
0000710e9ebdacae  push r11
0000710e9ebdacb0  sub rsp, 0xF0
0000710e9ebdacb7  vmovaps [rsp], xmm0
0000710e9ebdacbc  vmovaps [rsp+0x10], xmm2
0000710e9ebdacc2  vmovaps [rsp+0x20], xmm3
0000710e9ebdacc8  vmovaps [rsp+0x30], xmm4
0000710e9ebdacce  vmovaps [rsp+0x40], xmm5
0000710e9ebdacd4  vmovaps [rsp+0x50], xmm6
0000710e9ebdacda  vmovaps [rsp+0x60], xmm7
0000710e9ebdace0  vmovaps [rsp+0x70], xmm8
0000710e9ebdace6  vmovaps [rsp+0x80], xmm9
0000710e9ebdacef  vmovaps [rsp+0x90], xmm10
0000710e9ebdacf8  vmovaps [rsp+0xA0], xmm11
0000710e9ebdad01  vmovaps [rsp+0xB0], xmm12
0000710e9ebdad0a  vmovaps [rsp+0xC0], xmm13
0000710e9ebdad13  vmovaps [rsp+0xD0], xmm14
0000710e9ebdad1c  vmovaps [rsp+0xE0], xmm15
0000710e9ebdad25  sub rsp, 0x30
0000710e9ebdad29  movaps [rsp], xmm1
0000710e9ebdad2d  movaps [rsp+0x10], xmm15
0000710e9ebdad33  movaps [rsp+0x20], xmm9
0000710e9ebdad39  lea rdi, [rsp]
0000710e9ebdad3d  mov esi, 0x00
0000710e9ebdad42  mov rax, 0x5DADAF7CF530
0000710e9ebdad4c  call rax
0000710e9ebdad4e  movaps xmm1, [rsp]
0000710e9ebdad52  add rsp, 0x30
0000710e9ebdad56  vmovaps xmm0, [rsp]
0000710e9ebdad5b  vmovaps xmm2, [rsp+0x10]
0000710e9ebdad61  vmovaps xmm3, [rsp+0x20]
0000710e9ebdad67  vmovaps xmm4, [rsp+0x30]
0000710e9ebdad6d  vmovaps xmm5, [rsp+0x40]
0000710e9ebdad73  vmovaps xmm6, [rsp+0x50]
0000710e9ebdad79  vmovaps xmm7, [rsp+0x60]
0000710e9ebdad7f  vmovaps xmm8, [rsp+0x70]
0000710e9ebdad85  vmovaps xmm9, [rsp+0x80]
0000710e9ebdad8e  vmovaps xmm10, [rsp+0x90]
0000710e9ebdad97  vmovaps xmm11, [rsp+0xA0]
0000710e9ebdada0  vmovaps xmm12, [rsp+0xB0]
0000710e9ebdada9  vmovaps xmm13, [rsp+0xC0]
0000710e9ebdadb2  vmovaps xmm14, [rsp+0xD0]
0000710e9ebdadbb  vmovaps xmm15, [rsp+0xE0]
0000710e9ebdadc4  add rsp, 0xF0
0000710e9ebdadcb  pop r11
0000710e9ebdadcd  pop r10
0000710e9ebdadcf  pop r9
0000710e9ebdadd1  pop r8
0000710e9ebdadd3  pop rsi
0000710e9ebdadd4  pop rdi
0000710e9ebdadd5  pop rdx
0000710e9ebdadd6  pop rcx
0000710e9ebdadd7  pop rax
0000710e9ebdadd8  add rsp, 0x08
0000710e9ebdaddc  jmp 0x0000710E9EBD8FAB
0000710e9ebdade1  call 0x0000710E9EAE5820
0000710e9ebdade6  jmp 0x0000710E9EBD8FB8
0000710e9ebdadeb  sub rsp, 0x08
0000710e9ebdadef  push rax
0000710e9ebdadf0  push rcx
0000710e9ebdadf1  push rdx
0000710e9ebdadf2  push rdi
0000710e9ebdadf3  push rsi
0000710e9ebdadf4  push r8
0000710e9ebdadf6  push r9
0000710e9ebdadf8  push r10
0000710e9ebdadfa  push r11
0000710e9ebdadfc  sub rsp, 0xF0
0000710e9ebdae03  vmovaps [rsp], xmm0
0000710e9ebdae08  vmovaps [rsp+0x10], xmm2
0000710e9ebdae0e  vmovaps [rsp+0x20], xmm3
0000710e9ebdae14  vmovaps [rsp+0x30], xmm4
0000710e9ebdae1a  vmovaps [rsp+0x40], xmm5
0000710e9ebdae20  vmovaps [rsp+0x50], xmm6
0000710e9ebdae26  vmovaps [rsp+0x60], xmm7
0000710e9ebdae2c  vmovaps [rsp+0x70], xmm8
0000710e9ebdae32  vmovaps [rsp+0x80], xmm9
0000710e9ebdae3b  vmovaps [rsp+0x90], xmm10
0000710e9ebdae44  vmovaps [rsp+0xA0], xmm11
0000710e9ebdae4d  vmovaps [rsp+0xB0], xmm12
0000710e9ebdae56  vmovaps [rsp+0xC0], xmm13
0000710e9ebdae5f  vmovaps [rsp+0xD0], xmm14
0000710e9ebdae68  vmovaps [rsp+0xE0], xmm15
0000710e9ebdae71  sub rsp, 0x30
0000710e9ebdae75  movaps [rsp], xmm1
0000710e9ebdae79  movaps [rsp+0x10], xmm5
0000710e9ebdae7e  movaps [rsp+0x20], xmm7
0000710e9ebdae83  lea rdi, [rsp]
0000710e9ebdae87  mov esi, 0x00
0000710e9ebdae8c  mov rax, 0x5DADAF7CF530
0000710e9ebdae96  call rax
0000710e9ebdae98  movaps xmm1, [rsp]
0000710e9ebdae9c  add rsp, 0x30
0000710e9ebdaea0  vmovaps xmm0, [rsp]
0000710e9ebdaea5  vmovaps xmm2, [rsp+0x10]
0000710e9ebdaeab  vmovaps xmm3, [rsp+0x20]
0000710e9ebdaeb1  vmovaps xmm4, [rsp+0x30]
0000710e9ebdaeb7  vmovaps xmm5, [rsp+0x40]
0000710e9ebdaebd  vmovaps xmm6, [rsp+0x50]
0000710e9ebdaec3  vmovaps xmm7, [rsp+0x60]
0000710e9ebdaec9  vmovaps xmm8, [rsp+0x70]
0000710e9ebdaecf  vmovaps xmm9, [rsp+0x80]
0000710e9ebdaed8  vmovaps xmm10, [rsp+0x90]
0000710e9ebdaee1  vmovaps xmm11, [rsp+0xA0]
0000710e9ebdaeea  vmovaps xmm12, [rsp+0xB0]
0000710e9ebdaef3  vmovaps xmm13, [rsp+0xC0]
0000710e9ebdaefc  vmovaps xmm14, [rsp+0xD0]
0000710e9ebdaf05  vmovaps xmm15, [rsp+0xE0]
0000710e9ebdaf0e  add rsp, 0xF0
0000710e9ebdaf15  pop r11
0000710e9ebdaf17  pop r10
0000710e9ebdaf19  pop r9
0000710e9ebdaf1b  pop r8
0000710e9ebdaf1d  pop rsi
0000710e9ebdaf1e  pop rdi
0000710e9ebdaf1f  pop rdx
0000710e9ebdaf20  pop rcx
0000710e9ebdaf21  pop rax
0000710e9ebdaf22  add rsp, 0x08
0000710e9ebdaf26  jmp 0x0000710E9EBD905D
0000710e9ebdaf2b  sub rsp, 0x08
0000710e9ebdaf2f  push rax
0000710e9ebdaf30  push rcx
0000710e9ebdaf31  push rdx
0000710e9ebdaf32  push rdi
0000710e9ebdaf33  push rsi
0000710e9ebdaf34  push r8
0000710e9ebdaf36  push r9
0000710e9ebdaf38  push r10
0000710e9ebdaf3a  push r11
0000710e9ebdaf3c  sub rsp, 0xF0
0000710e9ebdaf43  vmovaps [rsp], xmm0
0000710e9ebdaf48  vmovaps [rsp+0x10], xmm1
0000710e9ebdaf4e  vmovaps [rsp+0x20], xmm2
0000710e9ebdaf54  vmovaps [rsp+0x30], xmm3
0000710e9ebdaf5a  vmovaps [rsp+0x40], xmm4
0000710e9ebdaf60  vmovaps [rsp+0x50], xmm5
0000710e9ebdaf66  vmovaps [rsp+0x60], xmm6
0000710e9ebdaf6c  vmovaps [rsp+0x70], xmm8
0000710e9ebdaf72  vmovaps [rsp+0x80], xmm9
0000710e9ebdaf7b  vmovaps [rsp+0x90], xmm10
0000710e9ebdaf84  vmovaps [rsp+0xA0], xmm11
0000710e9ebdaf8d  vmovaps [rsp+0xB0], xmm12
0000710e9ebdaf96  vmovaps [rsp+0xC0], xmm13
0000710e9ebdaf9f  vmovaps [rsp+0xD0], xmm14
0000710e9ebdafa8  vmovaps [rsp+0xE0], xmm15
0000710e9ebdafb1  sub rsp, 0x30
0000710e9ebdafb5  movaps [rsp], xmm7
0000710e9ebdafb9  movaps [rsp+0x10], xmm5
0000710e9ebdafbe  movaps [rsp+0x20], xmm15
0000710e9ebdafc4  lea rdi, [rsp]
0000710e9ebdafc8  mov esi, 0x00
0000710e9ebdafcd  mov rax, 0x5DADAF7CF530
0000710e9ebdafd7  call rax
0000710e9ebdafd9  movaps xmm7, [rsp]
0000710e9ebdafdd  add rsp, 0x30
0000710e9ebdafe1  vmovaps xmm0, [rsp]
0000710e9ebdafe6  vmovaps xmm1, [rsp+0x10]
0000710e9ebdafec  vmovaps xmm2, [rsp+0x20]
0000710e9ebdaff2  vmovaps xmm3, [rsp+0x30]
0000710e9ebdaff8  vmovaps xmm4, [rsp+0x40]
0000710e9ebdaffe  vmovaps xmm5, [rsp+0x50]
0000710e9ebdb004  vmovaps xmm6, [rsp+0x60]
0000710e9ebdb00a  vmovaps xmm8, [rsp+0x70]
0000710e9ebdb010  vmovaps xmm9, [rsp+0x80]
0000710e9ebdb019  vmovaps xmm10, [rsp+0x90]
0000710e9ebdb022  vmovaps xmm11, [rsp+0xA0]
0000710e9ebdb02b  vmovaps xmm12, [rsp+0xB0]
0000710e9ebdb034  vmovaps xmm13, [rsp+0xC0]
0000710e9ebdb03d  vmovaps xmm14, [rsp+0xD0]
0000710e9ebdb046  vmovaps xmm15, [rsp+0xE0]
0000710e9ebdb04f  add rsp, 0xF0
0000710e9ebdb056  pop r11
0000710e9ebdb058  pop r10
0000710e9ebdb05a  pop r9
0000710e9ebdb05c  pop r8
0000710e9ebdb05e  pop rsi
0000710e9ebdb05f  pop rdi
0000710e9ebdb060  pop rdx
0000710e9ebdb061  pop rcx
0000710e9ebdb062  pop rax
0000710e9ebdb063  add rsp, 0x08
0000710e9ebdb067  jmp 0x0000710E9EBD9093
0000710e9ebdb06c  call 0x0000710E9EAD64F0
0000710e9ebdb071  jmp 0x0000710E9EBD90A0
0000710e9ebdb076  sub rsp, 0x08
0000710e9ebdb07a  push rax
0000710e9ebdb07b  push rcx
0000710e9ebdb07c  push rdx
0000710e9ebdb07d  push rdi
0000710e9ebdb07e  push rsi
0000710e9ebdb07f  push r8
0000710e9ebdb081  push r9
0000710e9ebdb083  push r10
0000710e9ebdb085  push r11
0000710e9ebdb087  sub rsp, 0xF0
0000710e9ebdb08e  vmovaps [rsp], xmm0
0000710e9ebdb093  vmovaps [rsp+0x10], xmm1
0000710e9ebdb099  vmovaps [rsp+0x20], xmm2
0000710e9ebdb09f  vmovaps [rsp+0x30], xmm3
0000710e9ebdb0a5  vmovaps [rsp+0x40], xmm4
0000710e9ebdb0ab  vmovaps [rsp+0x50], xmm5
0000710e9ebdb0b1  vmovaps [rsp+0x60], xmm6
0000710e9ebdb0b7  vmovaps [rsp+0x70], xmm7
0000710e9ebdb0bd  vmovaps [rsp+0x80], xmm8
0000710e9ebdb0c6  vmovaps [rsp+0x90], xmm9
0000710e9ebdb0cf  vmovaps [rsp+0xA0], xmm10
0000710e9ebdb0d8  vmovaps [rsp+0xB0], xmm11
0000710e9ebdb0e1  vmovaps [rsp+0xC0], xmm12
0000710e9ebdb0ea  vmovaps [rsp+0xD0], xmm13
0000710e9ebdb0f3  vmovaps [rsp+0xE0], xmm14
0000710e9ebdb0fc  sub rsp, 0x30
0000710e9ebdb100  movaps [rsp], xmm15
0000710e9ebdb105  movaps [rsp+0x10], xmm5
0000710e9ebdb10a  movaps [rsp+0x20], xmm3
0000710e9ebdb10f  lea rdi, [rsp]
0000710e9ebdb113  mov esi, 0x00
0000710e9ebdb118  mov rax, 0x5DADAF7CF530
0000710e9ebdb122  call rax
0000710e9ebdb124  movaps xmm15, [rsp]
0000710e9ebdb129  add rsp, 0x30
0000710e9ebdb12d  vmovaps xmm0, [rsp]
0000710e9ebdb132  vmovaps xmm1, [rsp+0x10]
0000710e9ebdb138  vmovaps xmm2, [rsp+0x20]
0000710e9ebdb13e  vmovaps xmm3, [rsp+0x30]
0000710e9ebdb144  vmovaps xmm4, [rsp+0x40]
0000710e9ebdb14a  vmovaps xmm5, [rsp+0x50]
0000710e9ebdb150  vmovaps xmm6, [rsp+0x60]
0000710e9ebdb156  vmovaps xmm7, [rsp+0x70]
0000710e9ebdb15c  vmovaps xmm8, [rsp+0x80]
0000710e9ebdb165  vmovaps xmm9, [rsp+0x90]
0000710e9ebdb16e  vmovaps xmm10, [rsp+0xA0]
0000710e9ebdb177  vmovaps xmm11, [rsp+0xB0]
0000710e9ebdb180  vmovaps xmm12, [rsp+0xC0]
0000710e9ebdb189  vmovaps xmm13, [rsp+0xD0]
0000710e9ebdb192  vmovaps xmm14, [rsp+0xE0]
0000710e9ebdb19b  add rsp, 0xF0
0000710e9ebdb1a2  pop r11
0000710e9ebdb1a4  pop r10
0000710e9ebdb1a6  pop r9
0000710e9ebdb1a8  pop r8
0000710e9ebdb1aa  pop rsi
0000710e9ebdb1ab  pop rdi
0000710e9ebdb1ac  pop rdx
0000710e9ebdb1ad  pop rcx
0000710e9ebdb1ae  pop rax
0000710e9ebdb1af  add rsp, 0x08
0000710e9ebdb1b3  jmp 0x0000710E9EBD90C6
0000710e9ebdb1b8  sub rsp, 0x08
0000710e9ebdb1bc  push rax
0000710e9ebdb1bd  push rcx
0000710e9ebdb1be  push rdx
0000710e9ebdb1bf  push rdi
0000710e9ebdb1c0  push rsi
0000710e9ebdb1c1  push r8
0000710e9ebdb1c3  push r9
0000710e9ebdb1c5  push r10
0000710e9ebdb1c7  push r11
0000710e9ebdb1c9  sub rsp, 0xF0
0000710e9ebdb1d0  vmovaps [rsp], xmm0
0000710e9ebdb1d5  vmovaps [rsp+0x10], xmm2
0000710e9ebdb1db  vmovaps [rsp+0x20], xmm3
0000710e9ebdb1e1  vmovaps [rsp+0x30], xmm4
0000710e9ebdb1e7  vmovaps [rsp+0x40], xmm5
0000710e9ebdb1ed  vmovaps [rsp+0x50], xmm6
0000710e9ebdb1f3  vmovaps [rsp+0x60], xmm7
0000710e9ebdb1f9  vmovaps [rsp+0x70], xmm8
0000710e9ebdb1ff  vmovaps [rsp+0x80], xmm9
0000710e9ebdb208  vmovaps [rsp+0x90], xmm10
0000710e9ebdb211  vmovaps [rsp+0xA0], xmm11
0000710e9ebdb21a  vmovaps [rsp+0xB0], xmm12
0000710e9ebdb223  vmovaps [rsp+0xC0], xmm13
0000710e9ebdb22c  vmovaps [rsp+0xD0], xmm14
0000710e9ebdb235  vmovaps [rsp+0xE0], xmm15
0000710e9ebdb23e  sub rsp, 0x30
0000710e9ebdb242  movaps [rsp], xmm1
0000710e9ebdb246  movaps [rsp+0x10], xmm5
0000710e9ebdb24b  movaps [rsp+0x20], xmm4
0000710e9ebdb250  lea rdi, [rsp]
0000710e9ebdb254  mov esi, 0x00
0000710e9ebdb259  mov rax, 0x5DADAF7CF530
0000710e9ebdb263  call rax
0000710e9ebdb265  movaps xmm1, [rsp]
0000710e9ebdb269  add rsp, 0x30
0000710e9ebdb26d  vmovaps xmm0, [rsp]
0000710e9ebdb272  vmovaps xmm2, [rsp+0x10]
0000710e9ebdb278  vmovaps xmm3, [rsp+0x20]
0000710e9ebdb27e  vmovaps xmm4, [rsp+0x30]
0000710e9ebdb284  vmovaps xmm5, [rsp+0x40]
0000710e9ebdb28a  vmovaps xmm6, [rsp+0x50]
0000710e9ebdb290  vmovaps xmm7, [rsp+0x60]
0000710e9ebdb296  vmovaps xmm8, [rsp+0x70]
0000710e9ebdb29c  vmovaps xmm9, [rsp+0x80]
0000710e9ebdb2a5  vmovaps xmm10, [rsp+0x90]
0000710e9ebdb2ae  vmovaps xmm11, [rsp+0xA0]
0000710e9ebdb2b7  vmovaps xmm12, [rsp+0xB0]
0000710e9ebdb2c0  vmovaps xmm13, [rsp+0xC0]
0000710e9ebdb2c9  vmovaps xmm14, [rsp+0xD0]
0000710e9ebdb2d2  vmovaps xmm15, [rsp+0xE0]
0000710e9ebdb2db  add rsp, 0xF0
0000710e9ebdb2e2  pop r11
0000710e9ebdb2e4  pop r10
0000710e9ebdb2e6  pop r9
0000710e9ebdb2e8  pop r8
0000710e9ebdb2ea  pop rsi
0000710e9ebdb2eb  pop rdi
0000710e9ebdb2ec  pop rdx
0000710e9ebdb2ed  pop rcx
0000710e9ebdb2ee  pop rax
0000710e9ebdb2ef  add rsp, 0x08
0000710e9ebdb2f3  jmp 0x0000710E9EBD90E6
0000710e9ebdb2f8  sub rsp, 0x08
0000710e9ebdb2fc  push rax
0000710e9ebdb2fd  push rcx
0000710e9ebdb2fe  push rdx
0000710e9ebdb2ff  push rdi
0000710e9ebdb300  push rsi
0000710e9ebdb301  push r8
0000710e9ebdb303  push r9
0000710e9ebdb305  push r10
0000710e9ebdb307  push r11
0000710e9ebdb309  sub rsp, 0xF0
0000710e9ebdb310  vmovaps [rsp], xmm0
0000710e9ebdb315  vmovaps [rsp+0x10], xmm1
0000710e9ebdb31b  vmovaps [rsp+0x20], xmm2
0000710e9ebdb321  vmovaps [rsp+0x30], xmm3
0000710e9ebdb327  vmovaps [rsp+0x40], xmm5
0000710e9ebdb32d  vmovaps [rsp+0x50], xmm6
0000710e9ebdb333  vmovaps [rsp+0x60], xmm7
0000710e9ebdb339  vmovaps [rsp+0x70], xmm8
0000710e9ebdb33f  vmovaps [rsp+0x80], xmm9
0000710e9ebdb348  vmovaps [rsp+0x90], xmm10
0000710e9ebdb351  vmovaps [rsp+0xA0], xmm11
0000710e9ebdb35a  vmovaps [rsp+0xB0], xmm12
0000710e9ebdb363  vmovaps [rsp+0xC0], xmm13
0000710e9ebdb36c  vmovaps [rsp+0xD0], xmm14
0000710e9ebdb375  vmovaps [rsp+0xE0], xmm15
0000710e9ebdb37e  sub rsp, 0x30
0000710e9ebdb382  movaps [rsp], xmm4
0000710e9ebdb386  movaps [rsp+0x10], xmm3
0000710e9ebdb38b  movaps [rsp+0x20], xmm5
0000710e9ebdb390  lea rdi, [rsp]
0000710e9ebdb394  mov esi, 0x00
0000710e9ebdb399  mov rax, 0x5DADAF7CF530
0000710e9ebdb3a3  call rax
0000710e9ebdb3a5  movaps xmm4, [rsp]
0000710e9ebdb3a9  add rsp, 0x30
0000710e9ebdb3ad  vmovaps xmm0, [rsp]
0000710e9ebdb3b2  vmovaps xmm1, [rsp+0x10]
0000710e9ebdb3b8  vmovaps xmm2, [rsp+0x20]
0000710e9ebdb3be  vmovaps xmm3, [rsp+0x30]
0000710e9ebdb3c4  vmovaps xmm5, [rsp+0x40]
0000710e9ebdb3ca  vmovaps xmm6, [rsp+0x50]
0000710e9ebdb3d0  vmovaps xmm7, [rsp+0x60]
0000710e9ebdb3d6  vmovaps xmm8, [rsp+0x70]
0000710e9ebdb3dc  vmovaps xmm9, [rsp+0x80]
0000710e9ebdb3e5  vmovaps xmm10, [rsp+0x90]
0000710e9ebdb3ee  vmovaps xmm11, [rsp+0xA0]
0000710e9ebdb3f7  vmovaps xmm12, [rsp+0xB0]
0000710e9ebdb400  vmovaps xmm13, [rsp+0xC0]
0000710e9ebdb409  vmovaps xmm14, [rsp+0xD0]
0000710e9ebdb412  vmovaps xmm15, [rsp+0xE0]
0000710e9ebdb41b  add rsp, 0xF0
0000710e9ebdb422  pop r11
0000710e9ebdb424  pop r10
0000710e9ebdb426  pop r9
0000710e9ebdb428  pop r8
0000710e9ebdb42a  pop rsi
0000710e9ebdb42b  pop rdi
0000710e9ebdb42c  pop rdx
0000710e9ebdb42d  pop rcx
0000710e9ebdb42e  pop rax
0000710e9ebdb42f  add rsp, 0x08
0000710e9ebdb433  jmp 0x0000710E9EBD9134
0000710e9ebdb438  call 0x0000710E9EAD64F0
0000710e9ebdb43d  jmp 0x0000710E9EBD9141
0000710e9ebdb442  sub rsp, 0x08
0000710e9ebdb446  push rax
0000710e9ebdb447  push rcx
0000710e9ebdb448  push rdx
0000710e9ebdb449  push rdi
0000710e9ebdb44a  push rsi
0000710e9ebdb44b  push r8
0000710e9ebdb44d  push r9
0000710e9ebdb44f  push r10
0000710e9ebdb451  push r11
0000710e9ebdb453  sub rsp, 0xF0
0000710e9ebdb45a  vmovaps [rsp], xmm0
0000710e9ebdb45f  vmovaps [rsp+0x10], xmm1
0000710e9ebdb465  vmovaps [rsp+0x20], xmm2
0000710e9ebdb46b  vmovaps [rsp+0x30], xmm3
0000710e9ebdb471  vmovaps [rsp+0x40], xmm4
0000710e9ebdb477  vmovaps [rsp+0x50], xmm6
0000710e9ebdb47d  vmovaps [rsp+0x60], xmm7
0000710e9ebdb483  vmovaps [rsp+0x70], xmm8
0000710e9ebdb489  vmovaps [rsp+0x80], xmm9
0000710e9ebdb492  vmovaps [rsp+0x90], xmm10
0000710e9ebdb49b  vmovaps [rsp+0xA0], xmm11
0000710e9ebdb4a4  vmovaps [rsp+0xB0], xmm12
0000710e9ebdb4ad  vmovaps [rsp+0xC0], xmm13
0000710e9ebdb4b6  vmovaps [rsp+0xD0], xmm14
0000710e9ebdb4bf  vmovaps [rsp+0xE0], xmm15
0000710e9ebdb4c8  sub rsp, 0x30
0000710e9ebdb4cc  movaps [rsp], xmm5
0000710e9ebdb4d0  movaps [rsp+0x10], xmm6
0000710e9ebdb4d5  movaps [rsp+0x20], xmm3
0000710e9ebdb4da  lea rdi, [rsp]
0000710e9ebdb4de  mov esi, 0x00
0000710e9ebdb4e3  mov rax, 0x5DADAF7CF530
0000710e9ebdb4ed  call rax
0000710e9ebdb4ef  movaps xmm5, [rsp]
0000710e9ebdb4f3  add rsp, 0x30
0000710e9ebdb4f7  vmovaps xmm0, [rsp]
0000710e9ebdb4fc  vmovaps xmm1, [rsp+0x10]
0000710e9ebdb502  vmovaps xmm2, [rsp+0x20]
0000710e9ebdb508  vmovaps xmm3, [rsp+0x30]
0000710e9ebdb50e  vmovaps xmm4, [rsp+0x40]
0000710e9ebdb514  vmovaps xmm6, [rsp+0x50]
0000710e9ebdb51a  vmovaps xmm7, [rsp+0x60]
0000710e9ebdb520  vmovaps xmm8, [rsp+0x70]
0000710e9ebdb526  vmovaps xmm9, [rsp+0x80]
0000710e9ebdb52f  vmovaps xmm10, [rsp+0x90]
0000710e9ebdb538  vmovaps xmm11, [rsp+0xA0]
0000710e9ebdb541  vmovaps xmm12, [rsp+0xB0]
0000710e9ebdb54a  vmovaps xmm13, [rsp+0xC0]
0000710e9ebdb553  vmovaps xmm14, [rsp+0xD0]
0000710e9ebdb55c  vmovaps xmm15, [rsp+0xE0]
0000710e9ebdb565  add rsp, 0xF0
0000710e9ebdb56c  pop r11
0000710e9ebdb56e  pop r10
0000710e9ebdb570  pop r9
0000710e9ebdb572  pop r8
0000710e9ebdb574  pop rsi
0000710e9ebdb575  pop rdi
0000710e9ebdb576  pop rdx
0000710e9ebdb577  pop rcx
0000710e9ebdb578  pop rax
0000710e9ebdb579  add rsp, 0x08
0000710e9ebdb57d  jmp 0x0000710E9EBD9167
0000710e9ebdb582  sub rsp, 0x08
0000710e9ebdb586  push rax
0000710e9ebdb587  push rcx
0000710e9ebdb588  push rdx
0000710e9ebdb589  push rdi
0000710e9ebdb58a  push rsi
0000710e9ebdb58b  push r8
0000710e9ebdb58d  push r9
0000710e9ebdb58f  push r10
0000710e9ebdb591  push r11
0000710e9ebdb593  sub rsp, 0xF0
0000710e9ebdb59a  vmovaps [rsp], xmm0
0000710e9ebdb59f  vmovaps [rsp+0x10], xmm1
0000710e9ebdb5a5  vmovaps [rsp+0x20], xmm2
0000710e9ebdb5ab  vmovaps [rsp+0x30], xmm3
0000710e9ebdb5b1  vmovaps [rsp+0x40], xmm4
0000710e9ebdb5b7  vmovaps [rsp+0x50], xmm5
0000710e9ebdb5bd  vmovaps [rsp+0x60], xmm7
0000710e9ebdb5c3  vmovaps [rsp+0x70], xmm8
0000710e9ebdb5c9  vmovaps [rsp+0x80], xmm9
0000710e9ebdb5d2  vmovaps [rsp+0x90], xmm10
0000710e9ebdb5db  vmovaps [rsp+0xA0], xmm11
0000710e9ebdb5e4  vmovaps [rsp+0xB0], xmm12
0000710e9ebdb5ed  vmovaps [rsp+0xC0], xmm13
0000710e9ebdb5f6  vmovaps [rsp+0xD0], xmm14
0000710e9ebdb5ff  vmovaps [rsp+0xE0], xmm15
0000710e9ebdb608  sub rsp, 0x30
0000710e9ebdb60c  movaps [rsp], xmm6
0000710e9ebdb610  movaps [rsp+0x10], xmm9
0000710e9ebdb616  movaps [rsp+0x20], xmm1
0000710e9ebdb61b  lea rdi, [rsp]
0000710e9ebdb61f  mov esi, 0x00
0000710e9ebdb624  mov rax, 0x5DADAF7CF530
0000710e9ebdb62e  call rax
0000710e9ebdb630  movaps xmm6, [rsp]
0000710e9ebdb634  add rsp, 0x30
0000710e9ebdb638  vmovaps xmm0, [rsp]
0000710e9ebdb63d  vmovaps xmm1, [rsp+0x10]
0000710e9ebdb643  vmovaps xmm2, [rsp+0x20]
0000710e9ebdb649  vmovaps xmm3, [rsp+0x30]
0000710e9ebdb64f  vmovaps xmm4, [rsp+0x40]
0000710e9ebdb655  vmovaps xmm5, [rsp+0x50]
0000710e9ebdb65b  vmovaps xmm7, [rsp+0x60]
0000710e9ebdb661  vmovaps xmm8, [rsp+0x70]
0000710e9ebdb667  vmovaps xmm9, [rsp+0x80]
0000710e9ebdb670  vmovaps xmm10, [rsp+0x90]
0000710e9ebdb679  vmovaps xmm11, [rsp+0xA0]
0000710e9ebdb682  vmovaps xmm12, [rsp+0xB0]
0000710e9ebdb68b  vmovaps xmm13, [rsp+0xC0]
0000710e9ebdb694  vmovaps xmm14, [rsp+0xD0]
0000710e9ebdb69d  vmovaps xmm15, [rsp+0xE0]
0000710e9ebdb6a6  add rsp, 0xF0
0000710e9ebdb6ad  pop r11
0000710e9ebdb6af  pop r10
0000710e9ebdb6b1  pop r9
0000710e9ebdb6b3  pop r8
0000710e9ebdb6b5  pop rsi
0000710e9ebdb6b6  pop rdi
0000710e9ebdb6b7  pop rdx
0000710e9ebdb6b8  pop rcx
0000710e9ebdb6b9  pop rax
0000710e9ebdb6ba  add rsp, 0x08
0000710e9ebdb6be  jmp 0x0000710E9EBD918B
0000710e9ebdb6c3  sub rsp, 0x08
0000710e9ebdb6c7  push rax
0000710e9ebdb6c8  push rcx
0000710e9ebdb6c9  push rdx
0000710e9ebdb6ca  push rdi
0000710e9ebdb6cb  push rsi
0000710e9ebdb6cc  push r8
0000710e9ebdb6ce  push r9
0000710e9ebdb6d0  push r10
0000710e9ebdb6d2  push r11
0000710e9ebdb6d4  sub rsp, 0xF0
0000710e9ebdb6db  vmovaps [rsp], xmm0
0000710e9ebdb6e0  vmovaps [rsp+0x10], xmm1
0000710e9ebdb6e6  vmovaps [rsp+0x20], xmm2
0000710e9ebdb6ec  vmovaps [rsp+0x30], xmm3
0000710e9ebdb6f2  vmovaps [rsp+0x40], xmm4
0000710e9ebdb6f8  vmovaps [rsp+0x50], xmm5
0000710e9ebdb6fe  vmovaps [rsp+0x60], xmm6
0000710e9ebdb704  vmovaps [rsp+0x70], xmm7
0000710e9ebdb70a  vmovaps [rsp+0x80], xmm8
0000710e9ebdb713  vmovaps [rsp+0x90], xmm10
0000710e9ebdb71c  vmovaps [rsp+0xA0], xmm11
0000710e9ebdb725  vmovaps [rsp+0xB0], xmm12
0000710e9ebdb72e  vmovaps [rsp+0xC0], xmm13
0000710e9ebdb737  vmovaps [rsp+0xD0], xmm14
0000710e9ebdb740  vmovaps [rsp+0xE0], xmm15
0000710e9ebdb749  sub rsp, 0x30
0000710e9ebdb74d  movaps [rsp], xmm9
0000710e9ebdb752  movaps [rsp+0x10], xmm3
0000710e9ebdb757  movaps [rsp+0x20], xmm1
0000710e9ebdb75c  lea rdi, [rsp]
0000710e9ebdb760  mov esi, 0x00
0000710e9ebdb765  mov rax, 0x5DADAF7CF530
0000710e9ebdb76f  call rax
0000710e9ebdb771  movaps xmm9, [rsp]
0000710e9ebdb776  add rsp, 0x30
0000710e9ebdb77a  vmovaps xmm0, [rsp]
0000710e9ebdb77f  vmovaps xmm1, [rsp+0x10]
0000710e9ebdb785  vmovaps xmm2, [rsp+0x20]
0000710e9ebdb78b  vmovaps xmm3, [rsp+0x30]
0000710e9ebdb791  vmovaps xmm4, [rsp+0x40]
0000710e9ebdb797  vmovaps xmm5, [rsp+0x50]
0000710e9ebdb79d  vmovaps xmm6, [rsp+0x60]
0000710e9ebdb7a3  vmovaps xmm7, [rsp+0x70]
0000710e9ebdb7a9  vmovaps xmm8, [rsp+0x80]
0000710e9ebdb7b2  vmovaps xmm10, [rsp+0x90]
0000710e9ebdb7bb  vmovaps xmm11, [rsp+0xA0]
0000710e9ebdb7c4  vmovaps xmm12, [rsp+0xB0]
0000710e9ebdb7cd  vmovaps xmm13, [rsp+0xC0]
0000710e9ebdb7d6  vmovaps xmm14, [rsp+0xD0]
0000710e9ebdb7df  vmovaps xmm15, [rsp+0xE0]
0000710e9ebdb7e8  add rsp, 0xF0
0000710e9ebdb7ef  pop r11
0000710e9ebdb7f1  pop r10
0000710e9ebdb7f3  pop r9
0000710e9ebdb7f5  pop r8
0000710e9ebdb7f7  pop rsi
0000710e9ebdb7f8  pop rdi
0000710e9ebdb7f9  pop rdx
0000710e9ebdb7fa  pop rcx
0000710e9ebdb7fb  pop rax
0000710e9ebdb7fc  add rsp, 0x08
0000710e9ebdb800  jmp 0x0000710E9EBD91D7
0000710e9ebdb805  call 0x0000710E9EAD64F0
0000710e9ebdb80a  jmp 0x0000710E9EBD91E4
0000710e9ebdb80f  sub rsp, 0x08
0000710e9ebdb813  push rax
0000710e9ebdb814  push rcx
0000710e9ebdb815  push rdx
0000710e9ebdb816  push rdi
0000710e9ebdb817  push rsi
0000710e9ebdb818  push r8
0000710e9ebdb81a  push r9
0000710e9ebdb81c  push r10
0000710e9ebdb81e  push r11
0000710e9ebdb820  sub rsp, 0xF0
0000710e9ebdb827  vmovaps [rsp], xmm0
0000710e9ebdb82c  vmovaps [rsp+0x10], xmm1
0000710e9ebdb832  vmovaps [rsp+0x20], xmm2
0000710e9ebdb838  vmovaps [rsp+0x30], xmm3
0000710e9ebdb83e  vmovaps [rsp+0x40], xmm4
0000710e9ebdb844  vmovaps [rsp+0x50], xmm5
0000710e9ebdb84a  vmovaps [rsp+0x60], xmm6
0000710e9ebdb850  vmovaps [rsp+0x70], xmm7
0000710e9ebdb856  vmovaps [rsp+0x80], xmm8
0000710e9ebdb85f  vmovaps [rsp+0x90], xmm9
0000710e9ebdb868  vmovaps [rsp+0xA0], xmm10
0000710e9ebdb871  vmovaps [rsp+0xB0], xmm11
0000710e9ebdb87a  vmovaps [rsp+0xC0], xmm12
0000710e9ebdb883  vmovaps [rsp+0xD0], xmm13
0000710e9ebdb88c  vmovaps [rsp+0xE0], xmm14
0000710e9ebdb895  sub rsp, 0x30
0000710e9ebdb899  movaps [rsp], xmm15
0000710e9ebdb89e  movaps [rsp+0x10], xmm3
0000710e9ebdb8a3  movaps [rsp+0x20], xmm7
0000710e9ebdb8a8  lea rdi, [rsp]
0000710e9ebdb8ac  mov esi, 0x00
0000710e9ebdb8b1  mov rax, 0x5DADAF7CF530
0000710e9ebdb8bb  call rax
0000710e9ebdb8bd  movaps xmm15, [rsp]
0000710e9ebdb8c2  add rsp, 0x30
0000710e9ebdb8c6  vmovaps xmm0, [rsp]
0000710e9ebdb8cb  vmovaps xmm1, [rsp+0x10]
0000710e9ebdb8d1  vmovaps xmm2, [rsp+0x20]
0000710e9ebdb8d7  vmovaps xmm3, [rsp+0x30]
0000710e9ebdb8dd  vmovaps xmm4, [rsp+0x40]
0000710e9ebdb8e3  vmovaps xmm5, [rsp+0x50]
0000710e9ebdb8e9  vmovaps xmm6, [rsp+0x60]
0000710e9ebdb8ef  vmovaps xmm7, [rsp+0x70]
0000710e9ebdb8f5  vmovaps xmm8, [rsp+0x80]
0000710e9ebdb8fe  vmovaps xmm9, [rsp+0x90]
0000710e9ebdb907  vmovaps xmm10, [rsp+0xA0]
0000710e9ebdb910  vmovaps xmm11, [rsp+0xB0]
0000710e9ebdb919  vmovaps xmm12, [rsp+0xC0]
0000710e9ebdb922  vmovaps xmm13, [rsp+0xD0]
0000710e9ebdb92b  vmovaps xmm14, [rsp+0xE0]
0000710e9ebdb934  add rsp, 0xF0
0000710e9ebdb93b  pop r11
0000710e9ebdb93d  pop r10
0000710e9ebdb93f  pop r9
0000710e9ebdb941  pop r8
0000710e9ebdb943  pop rsi
0000710e9ebdb944  pop rdi
0000710e9ebdb945  pop rdx
0000710e9ebdb946  pop rcx
0000710e9ebdb947  pop rax
0000710e9ebdb948  add rsp, 0x08
0000710e9ebdb94c  jmp 0x0000710E9EBD9210
0000710e9ebdb951  sub rsp, 0x08
0000710e9ebdb955  push rax
0000710e9ebdb956  push rcx
0000710e9ebdb957  push rdx
0000710e9ebdb958  push rdi
0000710e9ebdb959  push rsi
0000710e9ebdb95a  push r8
0000710e9ebdb95c  push r9
0000710e9ebdb95e  push r10
0000710e9ebdb960  push r11
0000710e9ebdb962  sub rsp, 0xF0
0000710e9ebdb969  vmovaps [rsp], xmm0
0000710e9ebdb96e  vmovaps [rsp+0x10], xmm1
0000710e9ebdb974  vmovaps [rsp+0x20], xmm2
0000710e9ebdb97a  vmovaps [rsp+0x30], xmm4
0000710e9ebdb980  vmovaps [rsp+0x40], xmm5
0000710e9ebdb986  vmovaps [rsp+0x50], xmm6
0000710e9ebdb98c  vmovaps [rsp+0x60], xmm7
0000710e9ebdb992  vmovaps [rsp+0x70], xmm8
0000710e9ebdb998  vmovaps [rsp+0x80], xmm9
0000710e9ebdb9a1  vmovaps [rsp+0x90], xmm10
0000710e9ebdb9aa  vmovaps [rsp+0xA0], xmm11
0000710e9ebdb9b3  vmovaps [rsp+0xB0], xmm12
0000710e9ebdb9bc  vmovaps [rsp+0xC0], xmm13
0000710e9ebdb9c5  vmovaps [rsp+0xD0], xmm14
0000710e9ebdb9ce  vmovaps [rsp+0xE0], xmm15
0000710e9ebdb9d7  sub rsp, 0x30
0000710e9ebdb9db  movaps [rsp], xmm3
0000710e9ebdb9df  movaps [rsp+0x10], xmm1
0000710e9ebdb9e4  movaps [rsp+0x20], xmm15
0000710e9ebdb9ea  lea rdi, [rsp]
0000710e9ebdb9ee  mov esi, 0x00
0000710e9ebdb9f3  mov rax, 0x5DADAF7CF530
0000710e9ebdb9fd  call rax
0000710e9ebdb9ff  movaps xmm3, [rsp]
0000710e9ebdba03  add rsp, 0x30
0000710e9ebdba07  vmovaps xmm0, [rsp]
0000710e9ebdba0c  vmovaps xmm1, [rsp+0x10]
0000710e9ebdba12  vmovaps xmm2, [rsp+0x20]
0000710e9ebdba18  vmovaps xmm4, [rsp+0x30]
0000710e9ebdba1e  vmovaps xmm5, [rsp+0x40]
0000710e9ebdba24  vmovaps xmm6, [rsp+0x50]
0000710e9ebdba2a  vmovaps xmm7, [rsp+0x60]
0000710e9ebdba30  vmovaps xmm8, [rsp+0x70]
0000710e9ebdba36  vmovaps xmm9, [rsp+0x80]
0000710e9ebdba3f  vmovaps xmm10, [rsp+0x90]
0000710e9ebdba48  vmovaps xmm11, [rsp+0xA0]
0000710e9ebdba51  vmovaps xmm12, [rsp+0xB0]
0000710e9ebdba5a  vmovaps xmm13, [rsp+0xC0]
0000710e9ebdba63  vmovaps xmm14, [rsp+0xD0]
0000710e9ebdba6c  vmovaps xmm15, [rsp+0xE0]
0000710e9ebdba75  add rsp, 0xF0
0000710e9ebdba7c  pop r11
0000710e9ebdba7e  pop r10
0000710e9ebdba80  pop r9
0000710e9ebdba82  pop r8
0000710e9ebdba84  pop rsi
0000710e9ebdba85  pop rdi
0000710e9ebdba86  pop rdx
0000710e9ebdba87  pop rcx
0000710e9ebdba88  pop rax
0000710e9ebdba89  add rsp, 0x08
0000710e9ebdba8d  jmp 0x0000710E9EBD929F
0000710e9ebdba92  call 0x0000710E9EAD64F0
0000710e9ebdba97  jmp 0x0000710E9EBD92A9
0000710e9ebdba9c  sub rsp, 0x08
0000710e9ebdbaa0  push rax
0000710e9ebdbaa1  push rcx
0000710e9ebdbaa2  push rdx
0000710e9ebdbaa3  push rdi
0000710e9ebdbaa4  push rsi
0000710e9ebdbaa5  push r8
0000710e9ebdbaa7  push r9
0000710e9ebdbaa9  push r10
0000710e9ebdbaab  push r11
0000710e9ebdbaad  sub rsp, 0xF0
0000710e9ebdbab4  vmovaps [rsp], xmm0
0000710e9ebdbab9  vmovaps [rsp+0x10], xmm1
0000710e9ebdbabf  vmovaps [rsp+0x20], xmm2
0000710e9ebdbac5  vmovaps [rsp+0x30], xmm3
0000710e9ebdbacb  vmovaps [rsp+0x40], xmm4
0000710e9ebdbad1  vmovaps [rsp+0x50], xmm5
0000710e9ebdbad7  vmovaps [rsp+0x60], xmm6
0000710e9ebdbadd  vmovaps [rsp+0x70], xmm7
0000710e9ebdbae3  vmovaps [rsp+0x80], xmm8
0000710e9ebdbaec  vmovaps [rsp+0x90], xmm9
0000710e9ebdbaf5  vmovaps [rsp+0xA0], xmm10
0000710e9ebdbafe  vmovaps [rsp+0xB0], xmm11
0000710e9ebdbb07  vmovaps [rsp+0xC0], xmm12
0000710e9ebdbb10  vmovaps [rsp+0xD0], xmm13
0000710e9ebdbb19  vmovaps [rsp+0xE0], xmm14
0000710e9ebdbb22  sub rsp, 0x30
0000710e9ebdbb26  movaps [rsp], xmm15
0000710e9ebdbb2b  movaps [rsp+0x10], xmm14
0000710e9ebdbb31  movaps [rsp+0x20], xmm4
0000710e9ebdbb36  lea rdi, [rsp]
0000710e9ebdbb3a  mov esi, 0x00
0000710e9ebdbb3f  mov rax, 0x5DADAF7CF530
0000710e9ebdbb49  call rax
0000710e9ebdbb4b  movaps xmm15, [rsp]
0000710e9ebdbb50  add rsp, 0x30
0000710e9ebdbb54  vmovaps xmm0, [rsp]
0000710e9ebdbb59  vmovaps xmm1, [rsp+0x10]
0000710e9ebdbb5f  vmovaps xmm2, [rsp+0x20]
0000710e9ebdbb65  vmovaps xmm3, [rsp+0x30]
0000710e9ebdbb6b  vmovaps xmm4, [rsp+0x40]
0000710e9ebdbb71  vmovaps xmm5, [rsp+0x50]
0000710e9ebdbb77  vmovaps xmm6, [rsp+0x60]
0000710e9ebdbb7d  vmovaps xmm7, [rsp+0x70]
0000710e9ebdbb83  vmovaps xmm8, [rsp+0x80]
0000710e9ebdbb8c  vmovaps xmm9, [rsp+0x90]
0000710e9ebdbb95  vmovaps xmm10, [rsp+0xA0]
0000710e9ebdbb9e  vmovaps xmm11, [rsp+0xB0]
0000710e9ebdbba7  vmovaps xmm12, [rsp+0xC0]
0000710e9ebdbbb0  vmovaps xmm13, [rsp+0xD0]
0000710e9ebdbbb9  vmovaps xmm14, [rsp+0xE0]
0000710e9ebdbbc2  add rsp, 0xF0
0000710e9ebdbbc9  pop r11
0000710e9ebdbbcb  pop r10
0000710e9ebdbbcd  pop r9
0000710e9ebdbbcf  pop r8
0000710e9ebdbbd1  pop rsi
0000710e9ebdbbd2  pop rdi
0000710e9ebdbbd3  pop rdx
0000710e9ebdbbd4  pop rcx
0000710e9ebdbbd5  pop rax
0000710e9ebdbbd6  add rsp, 0x08
0000710e9ebdbbda  jmp 0x0000710E9EBD92D7
0000710e9ebdbbdf  sub rsp, 0x08
0000710e9ebdbbe3  push rax
0000710e9ebdbbe4  push rcx
0000710e9ebdbbe5  push rdx
0000710e9ebdbbe6  push rdi
0000710e9ebdbbe7  push rsi
0000710e9ebdbbe8  push r8
0000710e9ebdbbea  push r9
0000710e9ebdbbec  push r10
0000710e9ebdbbee  push r11
0000710e9ebdbbf0  sub rsp, 0xF0
0000710e9ebdbbf7  vmovaps [rsp], xmm0
0000710e9ebdbbfc  vmovaps [rsp+0x10], xmm1
0000710e9ebdbc02  vmovaps [rsp+0x20], xmm2
0000710e9ebdbc08  vmovaps [rsp+0x30], xmm3
0000710e9ebdbc0e  vmovaps [rsp+0x40], xmm4
0000710e9ebdbc14  vmovaps [rsp+0x50], xmm5
0000710e9ebdbc1a  vmovaps [rsp+0x60], xmm6
0000710e9ebdbc20  vmovaps [rsp+0x70], xmm7
0000710e9ebdbc26  vmovaps [rsp+0x80], xmm8
0000710e9ebdbc2f  vmovaps [rsp+0x90], xmm9
0000710e9ebdbc38  vmovaps [rsp+0xA0], xmm10
0000710e9ebdbc41  vmovaps [rsp+0xB0], xmm11
0000710e9ebdbc4a  vmovaps [rsp+0xC0], xmm12
0000710e9ebdbc53  vmovaps [rsp+0xD0], xmm13
0000710e9ebdbc5c  vmovaps [rsp+0xE0], xmm15
0000710e9ebdbc65  sub rsp, 0x30
0000710e9ebdbc69  movaps [rsp], xmm14
0000710e9ebdbc6e  movaps [rsp+0x10], xmm2
0000710e9ebdbc73  movaps [rsp+0x20], xmm1
0000710e9ebdbc78  lea rdi, [rsp]
0000710e9ebdbc7c  mov esi, 0x00
0000710e9ebdbc81  mov rax, 0x5DADAF7CF530
0000710e9ebdbc8b  call rax
0000710e9ebdbc8d  movaps xmm14, [rsp]
0000710e9ebdbc92  add rsp, 0x30
0000710e9ebdbc96  vmovaps xmm0, [rsp]
0000710e9ebdbc9b  vmovaps xmm1, [rsp+0x10]
0000710e9ebdbca1  vmovaps xmm2, [rsp+0x20]
0000710e9ebdbca7  vmovaps xmm3, [rsp+0x30]
0000710e9ebdbcad  vmovaps xmm4, [rsp+0x40]
0000710e9ebdbcb3  vmovaps xmm5, [rsp+0x50]
0000710e9ebdbcb9  vmovaps xmm6, [rsp+0x60]
0000710e9ebdbcbf  vmovaps xmm7, [rsp+0x70]
0000710e9ebdbcc5  vmovaps xmm8, [rsp+0x80]
0000710e9ebdbcce  vmovaps xmm9, [rsp+0x90]
0000710e9ebdbcd7  vmovaps xmm10, [rsp+0xA0]
0000710e9ebdbce0  vmovaps xmm11, [rsp+0xB0]
0000710e9ebdbce9  vmovaps xmm12, [rsp+0xC0]
0000710e9ebdbcf2  vmovaps xmm13, [rsp+0xD0]
0000710e9ebdbcfb  vmovaps xmm15, [rsp+0xE0]
0000710e9ebdbd04  add rsp, 0xF0
0000710e9ebdbd0b  pop r11
0000710e9ebdbd0d  pop r10
0000710e9ebdbd0f  pop r9
0000710e9ebdbd11  pop r8
0000710e9ebdbd13  pop rsi
0000710e9ebdbd14  pop rdi
0000710e9ebdbd15  pop rdx
0000710e9ebdbd16  pop rcx
0000710e9ebdbd17  pop rax
0000710e9ebdbd18  add rsp, 0x08
0000710e9ebdbd1c  jmp 0x0000710E9EBD92FD
0000710e9ebdbd21  sub rsp, 0x08
0000710e9ebdbd25  push rax
0000710e9ebdbd26  push rcx
0000710e9ebdbd27  push rdx
0000710e9ebdbd28  push rdi
0000710e9ebdbd29  push rsi
0000710e9ebdbd2a  push r8
0000710e9ebdbd2c  push r9
0000710e9ebdbd2e  push r10
0000710e9ebdbd30  push r11
0000710e9ebdbd32  sub rsp, 0xF0
0000710e9ebdbd39  vmovaps [rsp], xmm0
0000710e9ebdbd3e  vmovaps [rsp+0x10], xmm2
0000710e9ebdbd44  vmovaps [rsp+0x20], xmm3
0000710e9ebdbd4a  vmovaps [rsp+0x30], xmm4
0000710e9ebdbd50  vmovaps [rsp+0x40], xmm5
0000710e9ebdbd56  vmovaps [rsp+0x50], xmm6
0000710e9ebdbd5c  vmovaps [rsp+0x60], xmm7
0000710e9ebdbd62  vmovaps [rsp+0x70], xmm8
0000710e9ebdbd68  vmovaps [rsp+0x80], xmm9
0000710e9ebdbd71  vmovaps [rsp+0x90], xmm10
0000710e9ebdbd7a  vmovaps [rsp+0xA0], xmm11
0000710e9ebdbd83  vmovaps [rsp+0xB0], xmm12
0000710e9ebdbd8c  vmovaps [rsp+0xC0], xmm13
0000710e9ebdbd95  vmovaps [rsp+0xD0], xmm14
0000710e9ebdbd9e  vmovaps [rsp+0xE0], xmm15
0000710e9ebdbda7  sub rsp, 0x30
0000710e9ebdbdab  movaps [rsp], xmm1
0000710e9ebdbdaf  movaps [rsp+0x10], xmm4
0000710e9ebdbdb4  movaps [rsp+0x20], xmm9
0000710e9ebdbdba  lea rdi, [rsp]
0000710e9ebdbdbe  mov esi, 0x00
0000710e9ebdbdc3  mov rax, 0x5DADAF7CF530
0000710e9ebdbdcd  call rax
0000710e9ebdbdcf  movaps xmm1, [rsp]
0000710e9ebdbdd3  add rsp, 0x30
0000710e9ebdbdd7  vmovaps xmm0, [rsp]
0000710e9ebdbddc  vmovaps xmm2, [rsp+0x10]
0000710e9ebdbde2  vmovaps xmm3, [rsp+0x20]
0000710e9ebdbde8  vmovaps xmm4, [rsp+0x30]
0000710e9ebdbdee  vmovaps xmm5, [rsp+0x40]
0000710e9ebdbdf4  vmovaps xmm6, [rsp+0x50]
0000710e9ebdbdfa  vmovaps xmm7, [rsp+0x60]
0000710e9ebdbe00  vmovaps xmm8, [rsp+0x70]
0000710e9ebdbe06  vmovaps xmm9, [rsp+0x80]
0000710e9ebdbe0f  vmovaps xmm10, [rsp+0x90]
0000710e9ebdbe18  vmovaps xmm11, [rsp+0xA0]
0000710e9ebdbe21  vmovaps xmm12, [rsp+0xB0]
0000710e9ebdbe2a  vmovaps xmm13, [rsp+0xC0]
0000710e9ebdbe33  vmovaps xmm14, [rsp+0xD0]
0000710e9ebdbe3c  vmovaps xmm15, [rsp+0xE0]
0000710e9ebdbe45  add rsp, 0xF0
0000710e9ebdbe4c  pop r11
0000710e9ebdbe4e  pop r10
0000710e9ebdbe50  pop r9
0000710e9ebdbe52  pop r8
0000710e9ebdbe54  pop rsi
0000710e9ebdbe55  pop rdi
0000710e9ebdbe56  pop rdx
0000710e9ebdbe57  pop rcx
0000710e9ebdbe58  pop rax
0000710e9ebdbe59  add rsp, 0x08
0000710e9ebdbe5d  jmp 0x0000710E9EBD931B
0000710e9ebdbe62  sub rsp, 0x08
0000710e9ebdbe66  push rax
0000710e9ebdbe67  push rcx
0000710e9ebdbe68  push rdx
0000710e9ebdbe69  push rdi
0000710e9ebdbe6a  push rsi
0000710e9ebdbe6b  push r8
0000710e9ebdbe6d  push r9
0000710e9ebdbe6f  push r10
0000710e9ebdbe71  push r11
0000710e9ebdbe73  sub rsp, 0xF0
0000710e9ebdbe7a  vmovaps [rsp], xmm0
0000710e9ebdbe7f  vmovaps [rsp+0x10], xmm1
0000710e9ebdbe85  vmovaps [rsp+0x20], xmm2
0000710e9ebdbe8b  vmovaps [rsp+0x30], xmm3
0000710e9ebdbe91  vmovaps [rsp+0x40], xmm5
0000710e9ebdbe97  vmovaps [rsp+0x50], xmm6
0000710e9ebdbe9d  vmovaps [rsp+0x60], xmm7
0000710e9ebdbea3  vmovaps [rsp+0x70], xmm8
0000710e9ebdbea9  vmovaps [rsp+0x80], xmm9
0000710e9ebdbeb2  vmovaps [rsp+0x90], xmm10
0000710e9ebdbebb  vmovaps [rsp+0xA0], xmm11
0000710e9ebdbec4  vmovaps [rsp+0xB0], xmm12
0000710e9ebdbecd  vmovaps [rsp+0xC0], xmm13
0000710e9ebdbed6  vmovaps [rsp+0xD0], xmm14
0000710e9ebdbedf  vmovaps [rsp+0xE0], xmm15
0000710e9ebdbee8  sub rsp, 0x30
0000710e9ebdbeec  movaps [rsp], xmm4
0000710e9ebdbef0  movaps [rsp+0x10], xmm2
0000710e9ebdbef5  movaps [rsp+0x20], xmm9
0000710e9ebdbefb  lea rdi, [rsp]
0000710e9ebdbeff  mov esi, 0x00
0000710e9ebdbf04  mov rax, 0x5DADAF7CF530
0000710e9ebdbf0e  call rax
0000710e9ebdbf10  movaps xmm4, [rsp]
0000710e9ebdbf14  add rsp, 0x30
0000710e9ebdbf18  vmovaps xmm0, [rsp]
0000710e9ebdbf1d  vmovaps xmm1, [rsp+0x10]
0000710e9ebdbf23  vmovaps xmm2, [rsp+0x20]
0000710e9ebdbf29  vmovaps xmm3, [rsp+0x30]
0000710e9ebdbf2f  vmovaps xmm5, [rsp+0x40]
0000710e9ebdbf35  vmovaps xmm6, [rsp+0x50]
0000710e9ebdbf3b  vmovaps xmm7, [rsp+0x60]
0000710e9ebdbf41  vmovaps xmm8, [rsp+0x70]
0000710e9ebdbf47  vmovaps xmm9, [rsp+0x80]
0000710e9ebdbf50  vmovaps xmm10, [rsp+0x90]
0000710e9ebdbf59  vmovaps xmm11, [rsp+0xA0]
0000710e9ebdbf62  vmovaps xmm12, [rsp+0xB0]
0000710e9ebdbf6b  vmovaps xmm13, [rsp+0xC0]
0000710e9ebdbf74  vmovaps xmm14, [rsp+0xD0]
0000710e9ebdbf7d  vmovaps xmm15, [rsp+0xE0]
0000710e9ebdbf86  add rsp, 0xF0
0000710e9ebdbf8d  pop r11
0000710e9ebdbf8f  pop r10
0000710e9ebdbf91  pop r9
0000710e9ebdbf93  pop r8
0000710e9ebdbf95  pop rsi
0000710e9ebdbf96  pop rdi
0000710e9ebdbf97  pop rdx
0000710e9ebdbf98  pop rcx
0000710e9ebdbf99  pop rax
0000710e9ebdbf9a  add rsp, 0x08
0000710e9ebdbf9e  jmp 0x0000710E9EBD934B
0000710e9ebdbfa3  sub rsp, 0x08
0000710e9ebdbfa7  push rax
0000710e9ebdbfa8  push rcx
0000710e9ebdbfa9  push rdx
0000710e9ebdbfaa  push rdi
0000710e9ebdbfab  push rsi
0000710e9ebdbfac  push r8
0000710e9ebdbfae  push r9
0000710e9ebdbfb0  push r10
0000710e9ebdbfb2  push r11
0000710e9ebdbfb4  sub rsp, 0xF0
0000710e9ebdbfbb  vmovaps [rsp], xmm0
0000710e9ebdbfc0  vmovaps [rsp+0x10], xmm1
0000710e9ebdbfc6  vmovaps [rsp+0x20], xmm2
0000710e9ebdbfcc  vmovaps [rsp+0x30], xmm3
0000710e9ebdbfd2  vmovaps [rsp+0x40], xmm4
0000710e9ebdbfd8  vmovaps [rsp+0x50], xmm5
0000710e9ebdbfde  vmovaps [rsp+0x60], xmm6
0000710e9ebdbfe4  vmovaps [rsp+0x70], xmm7
0000710e9ebdbfea  vmovaps [rsp+0x80], xmm8
0000710e9ebdbff3  vmovaps [rsp+0x90], xmm10
0000710e9ebdbffc  vmovaps [rsp+0xA0], xmm11
0000710e9ebdc005  vmovaps [rsp+0xB0], xmm12
0000710e9ebdc00e  vmovaps [rsp+0xC0], xmm13
0000710e9ebdc017  vmovaps [rsp+0xD0], xmm14
0000710e9ebdc020  vmovaps [rsp+0xE0], xmm15
0000710e9ebdc029  sub rsp, 0x30
0000710e9ebdc02d  movaps [rsp], xmm9
0000710e9ebdc032  movaps [rsp+0x10], xmm2
0000710e9ebdc037  movaps [rsp+0x20], xmm1
0000710e9ebdc03c  lea rdi, [rsp]
0000710e9ebdc040  mov esi, 0x00
0000710e9ebdc045  mov rax, 0x5DADAF7CF530
0000710e9ebdc04f  call rax
0000710e9ebdc051  movaps xmm9, [rsp]
0000710e9ebdc056  add rsp, 0x30
0000710e9ebdc05a  vmovaps xmm0, [rsp]
0000710e9ebdc05f  vmovaps xmm1, [rsp+0x10]
0000710e9ebdc065  vmovaps xmm2, [rsp+0x20]
0000710e9ebdc06b  vmovaps xmm3, [rsp+0x30]
0000710e9ebdc071  vmovaps xmm4, [rsp+0x40]
0000710e9ebdc077  vmovaps xmm5, [rsp+0x50]
0000710e9ebdc07d  vmovaps xmm6, [rsp+0x60]
0000710e9ebdc083  vmovaps xmm7, [rsp+0x70]
0000710e9ebdc089  vmovaps xmm8, [rsp+0x80]
0000710e9ebdc092  vmovaps xmm10, [rsp+0x90]
0000710e9ebdc09b  vmovaps xmm11, [rsp+0xA0]
0000710e9ebdc0a4  vmovaps xmm12, [rsp+0xB0]
0000710e9ebdc0ad  vmovaps xmm13, [rsp+0xC0]
0000710e9ebdc0b6  vmovaps xmm14, [rsp+0xD0]
0000710e9ebdc0bf  vmovaps xmm15, [rsp+0xE0]
0000710e9ebdc0c8  add rsp, 0xF0
0000710e9ebdc0cf  pop r11
0000710e9ebdc0d1  pop r10
0000710e9ebdc0d3  pop r9
0000710e9ebdc0d5  pop r8
0000710e9ebdc0d7  pop rsi
0000710e9ebdc0d8  pop rdi
0000710e9ebdc0d9  pop rdx
0000710e9ebdc0da  pop rcx
0000710e9ebdc0db  pop rax
0000710e9ebdc0dc  add rsp, 0x08
0000710e9ebdc0e0  jmp 0x0000710E9EBD9381
0000710e9ebdc0e5  sub rsp, 0x08
0000710e9ebdc0e9  push rax
0000710e9ebdc0ea  push rcx
0000710e9ebdc0eb  push rdx
0000710e9ebdc0ec  push rdi
0000710e9ebdc0ed  push rsi
0000710e9ebdc0ee  push r8
0000710e9ebdc0f0  push r9
0000710e9ebdc0f2  push r10
0000710e9ebdc0f4  push r11
0000710e9ebdc0f6  sub rsp, 0xF0
0000710e9ebdc0fd  vmovaps [rsp], xmm0
0000710e9ebdc102  vmovaps [rsp+0x10], xmm2
0000710e9ebdc108  vmovaps [rsp+0x20], xmm3
0000710e9ebdc10e  vmovaps [rsp+0x30], xmm4
0000710e9ebdc114  vmovaps [rsp+0x40], xmm5
0000710e9ebdc11a  vmovaps [rsp+0x50], xmm6
0000710e9ebdc120  vmovaps [rsp+0x60], xmm7
0000710e9ebdc126  vmovaps [rsp+0x70], xmm8
0000710e9ebdc12c  vmovaps [rsp+0x80], xmm9
0000710e9ebdc135  vmovaps [rsp+0x90], xmm10
0000710e9ebdc13e  vmovaps [rsp+0xA0], xmm11
0000710e9ebdc147  vmovaps [rsp+0xB0], xmm12
0000710e9ebdc150  vmovaps [rsp+0xC0], xmm13
0000710e9ebdc159  vmovaps [rsp+0xD0], xmm14
0000710e9ebdc162  vmovaps [rsp+0xE0], xmm15
0000710e9ebdc16b  sub rsp, 0x30
0000710e9ebdc16f  movaps [rsp], xmm1
0000710e9ebdc173  movaps [rsp+0x10], xmm15
0000710e9ebdc179  movaps [rsp+0x20], xmm6
0000710e9ebdc17e  lea rdi, [rsp]
0000710e9ebdc182  mov esi, 0x00
0000710e9ebdc187  mov rax, 0x5DADAF7CF530
0000710e9ebdc191  call rax
0000710e9ebdc193  movaps xmm1, [rsp]
0000710e9ebdc197  add rsp, 0x30
0000710e9ebdc19b  vmovaps xmm0, [rsp]
0000710e9ebdc1a0  vmovaps xmm2, [rsp+0x10]
0000710e9ebdc1a6  vmovaps xmm3, [rsp+0x20]
0000710e9ebdc1ac  vmovaps xmm4, [rsp+0x30]
0000710e9ebdc1b2  vmovaps xmm5, [rsp+0x40]
0000710e9ebdc1b8  vmovaps xmm6, [rsp+0x50]
0000710e9ebdc1be  vmovaps xmm7, [rsp+0x60]
0000710e9ebdc1c4  vmovaps xmm8, [rsp+0x70]
0000710e9ebdc1ca  vmovaps xmm9, [rsp+0x80]
0000710e9ebdc1d3  vmovaps xmm10, [rsp+0x90]
0000710e9ebdc1dc  vmovaps xmm11, [rsp+0xA0]
0000710e9ebdc1e5  vmovaps xmm12, [rsp+0xB0]
0000710e9ebdc1ee  vmovaps xmm13, [rsp+0xC0]
0000710e9ebdc1f7  vmovaps xmm14, [rsp+0xD0]
0000710e9ebdc200  vmovaps xmm15, [rsp+0xE0]
0000710e9ebdc209  add rsp, 0xF0
0000710e9ebdc210  pop r11
0000710e9ebdc212  pop r10
0000710e9ebdc214  pop r9
0000710e9ebdc216  pop r8
0000710e9ebdc218  pop rsi
0000710e9ebdc219  pop rdi
0000710e9ebdc21a  pop rdx
0000710e9ebdc21b  pop rcx
0000710e9ebdc21c  pop rax
0000710e9ebdc21d  add rsp, 0x08
0000710e9ebdc221  jmp 0x0000710E9EBD93A2
0000710e9ebdc226  sub rsp, 0x08
0000710e9ebdc22a  push rax
0000710e9ebdc22b  push rcx
0000710e9ebdc22c  push rdx
0000710e9ebdc22d  push rdi
0000710e9ebdc22e  push rsi
0000710e9ebdc22f  push r8
0000710e9ebdc231  push r9
0000710e9ebdc233  push r10
0000710e9ebdc235  push r11
0000710e9ebdc237  sub rsp, 0xF0
0000710e9ebdc23e  vmovaps [rsp], xmm0
0000710e9ebdc243  vmovaps [rsp+0x10], xmm1
0000710e9ebdc249  vmovaps [rsp+0x20], xmm2
0000710e9ebdc24f  vmovaps [rsp+0x30], xmm3
0000710e9ebdc255  vmovaps [rsp+0x40], xmm4
0000710e9ebdc25b  vmovaps [rsp+0x50], xmm5
0000710e9ebdc261  vmovaps [rsp+0x60], xmm6
0000710e9ebdc267  vmovaps [rsp+0x70], xmm7
0000710e9ebdc26d  vmovaps [rsp+0x80], xmm8
0000710e9ebdc276  vmovaps [rsp+0x90], xmm9
0000710e9ebdc27f  vmovaps [rsp+0xA0], xmm10
0000710e9ebdc288  vmovaps [rsp+0xB0], xmm11
0000710e9ebdc291  vmovaps [rsp+0xC0], xmm12
0000710e9ebdc29a  vmovaps [rsp+0xD0], xmm13
0000710e9ebdc2a3  vmovaps [rsp+0xE0], xmm14
0000710e9ebdc2ac  sub rsp, 0x30
0000710e9ebdc2b0  movaps [rsp], xmm15
0000710e9ebdc2b5  movaps [rsp+0x10], xmm5
0000710e9ebdc2ba  movaps [rsp+0x20], xmm3
0000710e9ebdc2bf  lea rdi, [rsp]
0000710e9ebdc2c3  mov esi, 0x00
0000710e9ebdc2c8  mov rax, 0x5DADAF7CF530
0000710e9ebdc2d2  call rax
0000710e9ebdc2d4  movaps xmm15, [rsp]
0000710e9ebdc2d9  add rsp, 0x30
0000710e9ebdc2dd  vmovaps xmm0, [rsp]
0000710e9ebdc2e2  vmovaps xmm1, [rsp+0x10]
0000710e9ebdc2e8  vmovaps xmm2, [rsp+0x20]
0000710e9ebdc2ee  vmovaps xmm3, [rsp+0x30]
0000710e9ebdc2f4  vmovaps xmm4, [rsp+0x40]
0000710e9ebdc2fa  vmovaps xmm5, [rsp+0x50]
0000710e9ebdc300  vmovaps xmm6, [rsp+0x60]
0000710e9ebdc306  vmovaps xmm7, [rsp+0x70]
0000710e9ebdc30c  vmovaps xmm8, [rsp+0x80]
0000710e9ebdc315  vmovaps xmm9, [rsp+0x90]
0000710e9ebdc31e  vmovaps xmm10, [rsp+0xA0]
0000710e9ebdc327  vmovaps xmm11, [rsp+0xB0]
0000710e9ebdc330  vmovaps xmm12, [rsp+0xC0]
0000710e9ebdc339  vmovaps xmm13, [rsp+0xD0]
0000710e9ebdc342  vmovaps xmm14, [rsp+0xE0]
0000710e9ebdc34b  add rsp, 0xF0
0000710e9ebdc352  pop r11
0000710e9ebdc354  pop r10
0000710e9ebdc356  pop r9
0000710e9ebdc358  pop r8
0000710e9ebdc35a  pop rsi
0000710e9ebdc35b  pop rdi
0000710e9ebdc35c  pop rdx
0000710e9ebdc35d  pop rcx
0000710e9ebdc35e  pop rax
0000710e9ebdc35f  add rsp, 0x08
0000710e9ebdc363  jmp 0x0000710E9EBD93BC
0000710e9ebdc368  sub rsp, 0x08
0000710e9ebdc36c  push rax
0000710e9ebdc36d  push rcx
0000710e9ebdc36e  push rdx
0000710e9ebdc36f  push rdi
0000710e9ebdc370  push rsi
0000710e9ebdc371  push r8
0000710e9ebdc373  push r9
0000710e9ebdc375  push r10
0000710e9ebdc377  push r11
0000710e9ebdc379  sub rsp, 0xF0
0000710e9ebdc380  vmovaps [rsp], xmm0
0000710e9ebdc385  vmovaps [rsp+0x10], xmm1
0000710e9ebdc38b  vmovaps [rsp+0x20], xmm2
0000710e9ebdc391  vmovaps [rsp+0x30], xmm3
0000710e9ebdc397  vmovaps [rsp+0x40], xmm4
0000710e9ebdc39d  vmovaps [rsp+0x50], xmm6
0000710e9ebdc3a3  vmovaps [rsp+0x60], xmm7
0000710e9ebdc3a9  vmovaps [rsp+0x70], xmm8
0000710e9ebdc3af  vmovaps [rsp+0x80], xmm9
0000710e9ebdc3b8  vmovaps [rsp+0x90], xmm10
0000710e9ebdc3c1  vmovaps [rsp+0xA0], xmm11
0000710e9ebdc3ca  vmovaps [rsp+0xB0], xmm12
0000710e9ebdc3d3  vmovaps [rsp+0xC0], xmm13
0000710e9ebdc3dc  vmovaps [rsp+0xD0], xmm14
0000710e9ebdc3e5  vmovaps [rsp+0xE0], xmm15
0000710e9ebdc3ee  sub rsp, 0x30
0000710e9ebdc3f2  movaps [rsp], xmm5
0000710e9ebdc3f6  movaps [rsp+0x10], xmm8
0000710e9ebdc3fc  movaps [rsp+0x20], xmm6
0000710e9ebdc401  lea rdi, [rsp]
0000710e9ebdc405  mov esi, 0x00
0000710e9ebdc40a  mov rax, 0x5DADAF7CF530
0000710e9ebdc414  call rax
0000710e9ebdc416  movaps xmm5, [rsp]
0000710e9ebdc41a  add rsp, 0x30
0000710e9ebdc41e  vmovaps xmm0, [rsp]
0000710e9ebdc423  vmovaps xmm1, [rsp+0x10]
0000710e9ebdc429  vmovaps xmm2, [rsp+0x20]
0000710e9ebdc42f  vmovaps xmm3, [rsp+0x30]
0000710e9ebdc435  vmovaps xmm4, [rsp+0x40]
0000710e9ebdc43b  vmovaps xmm6, [rsp+0x50]
0000710e9ebdc441  vmovaps xmm7, [rsp+0x60]
0000710e9ebdc447  vmovaps xmm8, [rsp+0x70]
0000710e9ebdc44d  vmovaps xmm9, [rsp+0x80]
0000710e9ebdc456  vmovaps xmm10, [rsp+0x90]
0000710e9ebdc45f  vmovaps xmm11, [rsp+0xA0]
0000710e9ebdc468  vmovaps xmm12, [rsp+0xB0]
0000710e9ebdc471  vmovaps xmm13, [rsp+0xC0]
0000710e9ebdc47a  vmovaps xmm14, [rsp+0xD0]
0000710e9ebdc483  vmovaps xmm15, [rsp+0xE0]
0000710e9ebdc48c  add rsp, 0xF0
0000710e9ebdc493  pop r11
0000710e9ebdc495  pop r10
0000710e9ebdc497  pop r9
0000710e9ebdc499  pop r8
0000710e9ebdc49b  pop rsi
0000710e9ebdc49c  pop rdi
0000710e9ebdc49d  pop rdx
0000710e9ebdc49e  pop rcx
0000710e9ebdc49f  pop rax
0000710e9ebdc4a0  add rsp, 0x08
0000710e9ebdc4a4  jmp 0x0000710E9EBD93E0
0000710e9ebdc4a9  sub rsp, 0x08
0000710e9ebdc4ad  push rax
0000710e9ebdc4ae  push rcx
0000710e9ebdc4af  push rdx
0000710e9ebdc4b0  push rdi
0000710e9ebdc4b1  push rsi
0000710e9ebdc4b2  push r8
0000710e9ebdc4b4  push r9
0000710e9ebdc4b6  push r10
0000710e9ebdc4b8  push r11
0000710e9ebdc4ba  sub rsp, 0xF0
0000710e9ebdc4c1  vmovaps [rsp], xmm0
0000710e9ebdc4c6  vmovaps [rsp+0x10], xmm1
0000710e9ebdc4cc  vmovaps [rsp+0x20], xmm2
0000710e9ebdc4d2  vmovaps [rsp+0x30], xmm3
0000710e9ebdc4d8  vmovaps [rsp+0x40], xmm4
0000710e9ebdc4de  vmovaps [rsp+0x50], xmm5
0000710e9ebdc4e4  vmovaps [rsp+0x60], xmm7
0000710e9ebdc4ea  vmovaps [rsp+0x70], xmm8
0000710e9ebdc4f0  vmovaps [rsp+0x80], xmm9
0000710e9ebdc4f9  vmovaps [rsp+0x90], xmm10
0000710e9ebdc502  vmovaps [rsp+0xA0], xmm11
0000710e9ebdc50b  vmovaps [rsp+0xB0], xmm12
0000710e9ebdc514  vmovaps [rsp+0xC0], xmm13
0000710e9ebdc51d  vmovaps [rsp+0xD0], xmm14
0000710e9ebdc526  vmovaps [rsp+0xE0], xmm15
0000710e9ebdc52f  sub rsp, 0x30
0000710e9ebdc533  movaps [rsp], xmm6
0000710e9ebdc537  movaps [rsp+0x10], xmm10
0000710e9ebdc53d  movaps [rsp+0x20], xmm8
0000710e9ebdc543  lea rdi, [rsp]
0000710e9ebdc547  mov esi, 0x00
0000710e9ebdc54c  mov rax, 0x5DADAF7CF530
0000710e9ebdc556  call rax
0000710e9ebdc558  movaps xmm6, [rsp]
0000710e9ebdc55c  add rsp, 0x30
0000710e9ebdc560  vmovaps xmm0, [rsp]
0000710e9ebdc565  vmovaps xmm1, [rsp+0x10]
0000710e9ebdc56b  vmovaps xmm2, [rsp+0x20]
0000710e9ebdc571  vmovaps xmm3, [rsp+0x30]
0000710e9ebdc577  vmovaps xmm4, [rsp+0x40]
0000710e9ebdc57d  vmovaps xmm5, [rsp+0x50]
0000710e9ebdc583  vmovaps xmm7, [rsp+0x60]
0000710e9ebdc589  vmovaps xmm8, [rsp+0x70]
0000710e9ebdc58f  vmovaps xmm9, [rsp+0x80]
0000710e9ebdc598  vmovaps xmm10, [rsp+0x90]
0000710e9ebdc5a1  vmovaps xmm11, [rsp+0xA0]
0000710e9ebdc5aa  vmovaps xmm12, [rsp+0xB0]
0000710e9ebdc5b3  vmovaps xmm13, [rsp+0xC0]
0000710e9ebdc5bc  vmovaps xmm14, [rsp+0xD0]
0000710e9ebdc5c5  vmovaps xmm15, [rsp+0xE0]
0000710e9ebdc5ce  add rsp, 0xF0
0000710e9ebdc5d5  pop r11
0000710e9ebdc5d7  pop r10
0000710e9ebdc5d9  pop r9
0000710e9ebdc5db  pop r8
0000710e9ebdc5dd  pop rsi
0000710e9ebdc5de  pop rdi
0000710e9ebdc5df  pop rdx
0000710e9ebdc5e0  pop rcx
0000710e9ebdc5e1  pop rax
0000710e9ebdc5e2  add rsp, 0x08
0000710e9ebdc5e6  jmp 0x0000710E9EBD9405
0000710e9ebdc5eb  sub rsp, 0x08
0000710e9ebdc5ef  push rax
0000710e9ebdc5f0  push rcx
0000710e9ebdc5f1  push rdx
0000710e9ebdc5f2  push rdi
0000710e9ebdc5f3  push rsi
0000710e9ebdc5f4  push r8
0000710e9ebdc5f6  push r9
0000710e9ebdc5f8  push r10
0000710e9ebdc5fa  push r11
0000710e9ebdc5fc  sub rsp, 0xF0
0000710e9ebdc603  vmovaps [rsp], xmm0
0000710e9ebdc608  vmovaps [rsp+0x10], xmm1
0000710e9ebdc60e  vmovaps [rsp+0x20], xmm2
0000710e9ebdc614  vmovaps [rsp+0x30], xmm3
0000710e9ebdc61a  vmovaps [rsp+0x40], xmm4
0000710e9ebdc620  vmovaps [rsp+0x50], xmm5
0000710e9ebdc626  vmovaps [rsp+0x60], xmm6
0000710e9ebdc62c  vmovaps [rsp+0x70], xmm7
0000710e9ebdc632  vmovaps [rsp+0x80], xmm8
0000710e9ebdc63b  vmovaps [rsp+0x90], xmm9
0000710e9ebdc644  vmovaps [rsp+0xA0], xmm11
0000710e9ebdc64d  vmovaps [rsp+0xB0], xmm12
0000710e9ebdc656  vmovaps [rsp+0xC0], xmm13
0000710e9ebdc65f  vmovaps [rsp+0xD0], xmm14
0000710e9ebdc668  vmovaps [rsp+0xE0], xmm15
0000710e9ebdc671  sub rsp, 0x30
0000710e9ebdc675  movaps [rsp], xmm10
0000710e9ebdc67a  movaps [rsp+0x10], xmm8
0000710e9ebdc680  movaps [rsp+0x20], xmm14
0000710e9ebdc686  lea rdi, [rsp]
0000710e9ebdc68a  mov esi, 0x00
0000710e9ebdc68f  mov rax, 0x5DADAF7CF530
0000710e9ebdc699  call rax
0000710e9ebdc69b  movaps xmm10, [rsp]
0000710e9ebdc6a0  add rsp, 0x30
0000710e9ebdc6a4  vmovaps xmm0, [rsp]
0000710e9ebdc6a9  vmovaps xmm1, [rsp+0x10]
0000710e9ebdc6af  vmovaps xmm2, [rsp+0x20]
0000710e9ebdc6b5  vmovaps xmm3, [rsp+0x30]
0000710e9ebdc6bb  vmovaps xmm4, [rsp+0x40]
0000710e9ebdc6c1  vmovaps xmm5, [rsp+0x50]
0000710e9ebdc6c7  vmovaps xmm6, [rsp+0x60]
0000710e9ebdc6cd  vmovaps xmm7, [rsp+0x70]
0000710e9ebdc6d3  vmovaps xmm8, [rsp+0x80]
0000710e9ebdc6dc  vmovaps xmm9, [rsp+0x90]
0000710e9ebdc6e5  vmovaps xmm11, [rsp+0xA0]
0000710e9ebdc6ee  vmovaps xmm12, [rsp+0xB0]
0000710e9ebdc6f7  vmovaps xmm13, [rsp+0xC0]
0000710e9ebdc700  vmovaps xmm14, [rsp+0xD0]
0000710e9ebdc709  vmovaps xmm15, [rsp+0xE0]
0000710e9ebdc712  add rsp, 0xF0
0000710e9ebdc719  pop r11
0000710e9ebdc71b  pop r10
0000710e9ebdc71d  pop r9
0000710e9ebdc71f  pop r8
0000710e9ebdc721  pop rsi
0000710e9ebdc722  pop rdi
0000710e9ebdc723  pop rdx
0000710e9ebdc724  pop rcx
0000710e9ebdc725  pop rax
0000710e9ebdc726  add rsp, 0x08
0000710e9ebdc72a  jmp 0x0000710E9EBD9425
0000710e9ebdc72f  sub rsp, 0x08
0000710e9ebdc733  push rax
0000710e9ebdc734  push rcx
0000710e9ebdc735  push rdx
0000710e9ebdc736  push rdi
0000710e9ebdc737  push rsi
0000710e9ebdc738  push r8
0000710e9ebdc73a  push r9
0000710e9ebdc73c  push r10
0000710e9ebdc73e  push r11
0000710e9ebdc740  sub rsp, 0xF0
0000710e9ebdc747  vmovaps [rsp], xmm0
0000710e9ebdc74c  vmovaps [rsp+0x10], xmm1
0000710e9ebdc752  vmovaps [rsp+0x20], xmm2
0000710e9ebdc758  vmovaps [rsp+0x30], xmm3
0000710e9ebdc75e  vmovaps [rsp+0x40], xmm4
0000710e9ebdc764  vmovaps [rsp+0x50], xmm5
0000710e9ebdc76a  vmovaps [rsp+0x60], xmm6
0000710e9ebdc770  vmovaps [rsp+0x70], xmm7
0000710e9ebdc776  vmovaps [rsp+0x80], xmm8
0000710e9ebdc77f  vmovaps [rsp+0x90], xmm9
0000710e9ebdc788  vmovaps [rsp+0xA0], xmm10
0000710e9ebdc791  vmovaps [rsp+0xB0], xmm11
0000710e9ebdc79a  vmovaps [rsp+0xC0], xmm12
0000710e9ebdc7a3  vmovaps [rsp+0xD0], xmm13
0000710e9ebdc7ac  vmovaps [rsp+0xE0], xmm15
0000710e9ebdc7b5  sub rsp, 0x30
0000710e9ebdc7b9  movaps [rsp], xmm14
0000710e9ebdc7be  movaps [rsp+0x10], xmm8
0000710e9ebdc7c4  movaps [rsp+0x20], xmm4
0000710e9ebdc7c9  lea rdi, [rsp]
0000710e9ebdc7cd  mov esi, 0x00
0000710e9ebdc7d2  mov rax, 0x5DADAF7CF530
0000710e9ebdc7dc  call rax
0000710e9ebdc7de  movaps xmm14, [rsp]
0000710e9ebdc7e3  add rsp, 0x30
0000710e9ebdc7e7  vmovaps xmm0, [rsp]
0000710e9ebdc7ec  vmovaps xmm1, [rsp+0x10]
0000710e9ebdc7f2  vmovaps xmm2, [rsp+0x20]
0000710e9ebdc7f8  vmovaps xmm3, [rsp+0x30]
0000710e9ebdc7fe  vmovaps xmm4, [rsp+0x40]
0000710e9ebdc804  vmovaps xmm5, [rsp+0x50]
0000710e9ebdc80a  vmovaps xmm6, [rsp+0x60]
0000710e9ebdc810  vmovaps xmm7, [rsp+0x70]
0000710e9ebdc816  vmovaps xmm8, [rsp+0x80]
0000710e9ebdc81f  vmovaps xmm9, [rsp+0x90]
0000710e9ebdc828  vmovaps xmm10, [rsp+0xA0]
0000710e9ebdc831  vmovaps xmm11, [rsp+0xB0]
0000710e9ebdc83a  vmovaps xmm12, [rsp+0xC0]
0000710e9ebdc843  vmovaps xmm13, [rsp+0xD0]
0000710e9ebdc84c  vmovaps xmm15, [rsp+0xE0]
0000710e9ebdc855  add rsp, 0xF0
0000710e9ebdc85c  pop r11
0000710e9ebdc85e  pop r10
0000710e9ebdc860  pop r9
0000710e9ebdc862  pop r8
0000710e9ebdc864  pop rsi
0000710e9ebdc865  pop rdi
0000710e9ebdc866  pop rdx
0000710e9ebdc867  pop rcx
0000710e9ebdc868  pop rax
0000710e9ebdc869  add rsp, 0x08
0000710e9ebdc86d  jmp 0x0000710E9EBD9445
0000710e9ebdc872  sub rsp, 0x08
0000710e9ebdc876  push rax
0000710e9ebdc877  push rcx
0000710e9ebdc878  push rdx
0000710e9ebdc879  push rdi
0000710e9ebdc87a  push rsi
0000710e9ebdc87b  push r8
0000710e9ebdc87d  push r9
0000710e9ebdc87f  push r10
0000710e9ebdc881  push r11
0000710e9ebdc883  sub rsp, 0xF0
0000710e9ebdc88a  vmovaps [rsp], xmm0
0000710e9ebdc88f  vmovaps [rsp+0x10], xmm1
0000710e9ebdc895  vmovaps [rsp+0x20], xmm2
0000710e9ebdc89b  vmovaps [rsp+0x30], xmm3
0000710e9ebdc8a1  vmovaps [rsp+0x40], xmm5
0000710e9ebdc8a7  vmovaps [rsp+0x50], xmm6
0000710e9ebdc8ad  vmovaps [rsp+0x60], xmm7
0000710e9ebdc8b3  vmovaps [rsp+0x70], xmm8
0000710e9ebdc8b9  vmovaps [rsp+0x80], xmm9
0000710e9ebdc8c2  vmovaps [rsp+0x90], xmm10
0000710e9ebdc8cb  vmovaps [rsp+0xA0], xmm11
0000710e9ebdc8d4  vmovaps [rsp+0xB0], xmm12
0000710e9ebdc8dd  vmovaps [rsp+0xC0], xmm13
0000710e9ebdc8e6  vmovaps [rsp+0xD0], xmm14
0000710e9ebdc8ef  vmovaps [rsp+0xE0], xmm15
0000710e9ebdc8f8  sub rsp, 0x30
0000710e9ebdc8fc  movaps [rsp], xmm4
0000710e9ebdc900  movaps [rsp+0x10], xmm13
0000710e9ebdc906  movaps [rsp+0x20], xmm8
0000710e9ebdc90c  lea rdi, [rsp]
0000710e9ebdc910  mov esi, 0x00
0000710e9ebdc915  mov rax, 0x5DADAF7CF530
0000710e9ebdc91f  call rax
0000710e9ebdc921  movaps xmm4, [rsp]
0000710e9ebdc925  add rsp, 0x30
0000710e9ebdc929  vmovaps xmm0, [rsp]
0000710e9ebdc92e  vmovaps xmm1, [rsp+0x10]
0000710e9ebdc934  vmovaps xmm2, [rsp+0x20]
0000710e9ebdc93a  vmovaps xmm3, [rsp+0x30]
0000710e9ebdc940  vmovaps xmm5, [rsp+0x40]
0000710e9ebdc946  vmovaps xmm6, [rsp+0x50]
0000710e9ebdc94c  vmovaps xmm7, [rsp+0x60]
0000710e9ebdc952  vmovaps xmm8, [rsp+0x70]
0000710e9ebdc958  vmovaps xmm9, [rsp+0x80]
0000710e9ebdc961  vmovaps xmm10, [rsp+0x90]
0000710e9ebdc96a  vmovaps xmm11, [rsp+0xA0]
0000710e9ebdc973  vmovaps xmm12, [rsp+0xB0]
0000710e9ebdc97c  vmovaps xmm13, [rsp+0xC0]
0000710e9ebdc985  vmovaps xmm14, [rsp+0xD0]
0000710e9ebdc98e  vmovaps xmm15, [rsp+0xE0]
0000710e9ebdc997  add rsp, 0xF0
0000710e9ebdc99e  pop r11
0000710e9ebdc9a0  pop r10
0000710e9ebdc9a2  pop r9
0000710e9ebdc9a4  pop r8
0000710e9ebdc9a6  pop rsi
0000710e9ebdc9a7  pop rdi
0000710e9ebdc9a8  pop rdx
0000710e9ebdc9a9  pop rcx
0000710e9ebdc9aa  pop rax
0000710e9ebdc9ab  add rsp, 0x08
0000710e9ebdc9af  jmp 0x0000710E9EBD946A
0000710e9ebdc9b4  sub rsp, 0x08
0000710e9ebdc9b8  push rax
0000710e9ebdc9b9  push rcx
0000710e9ebdc9ba  push rdx
0000710e9ebdc9bb  push rdi
0000710e9ebdc9bc  push rsi
0000710e9ebdc9bd  push r8
0000710e9ebdc9bf  push r9
0000710e9ebdc9c1  push r10
0000710e9ebdc9c3  push r11
0000710e9ebdc9c5  sub rsp, 0xF0
0000710e9ebdc9cc  vmovaps [rsp], xmm0
0000710e9ebdc9d1  vmovaps [rsp+0x10], xmm1
0000710e9ebdc9d7  vmovaps [rsp+0x20], xmm2
0000710e9ebdc9dd  vmovaps [rsp+0x30], xmm3
0000710e9ebdc9e3  vmovaps [rsp+0x40], xmm4
0000710e9ebdc9e9  vmovaps [rsp+0x50], xmm5
0000710e9ebdc9ef  vmovaps [rsp+0x60], xmm6
0000710e9ebdc9f5  vmovaps [rsp+0x70], xmm7
0000710e9ebdc9fb  vmovaps [rsp+0x80], xmm8
0000710e9ebdca04  vmovaps [rsp+0x90], xmm9
0000710e9ebdca0d  vmovaps [rsp+0xA0], xmm10
0000710e9ebdca16  vmovaps [rsp+0xB0], xmm11
0000710e9ebdca1f  vmovaps [rsp+0xC0], xmm12
0000710e9ebdca28  vmovaps [rsp+0xD0], xmm14
0000710e9ebdca31  vmovaps [rsp+0xE0], xmm15
0000710e9ebdca3a  sub rsp, 0x30
0000710e9ebdca3e  movaps [rsp], xmm13
0000710e9ebdca43  movaps [rsp+0x10], xmm15
0000710e9ebdca49  movaps [rsp+0x20], xmm9
0000710e9ebdca4f  lea rdi, [rsp]
0000710e9ebdca53  mov esi, 0x00
0000710e9ebdca58  mov rax, 0x5DADAF7CF530
0000710e9ebdca62  call rax
0000710e9ebdca64  movaps xmm13, [rsp]
0000710e9ebdca69  add rsp, 0x30
0000710e9ebdca6d  vmovaps xmm0, [rsp]
0000710e9ebdca72  vmovaps xmm1, [rsp+0x10]
0000710e9ebdca78  vmovaps xmm2, [rsp+0x20]
0000710e9ebdca7e  vmovaps xmm3, [rsp+0x30]
0000710e9ebdca84  vmovaps xmm4, [rsp+0x40]
0000710e9ebdca8a  vmovaps xmm5, [rsp+0x50]
0000710e9ebdca90  vmovaps xmm6, [rsp+0x60]
0000710e9ebdca96  vmovaps xmm7, [rsp+0x70]
0000710e9ebdca9c  vmovaps xmm8, [rsp+0x80]
0000710e9ebdcaa5  vmovaps xmm9, [rsp+0x90]
0000710e9ebdcaae  vmovaps xmm10, [rsp+0xA0]
0000710e9ebdcab7  vmovaps xmm11, [rsp+0xB0]
0000710e9ebdcac0  vmovaps xmm12, [rsp+0xC0]
0000710e9ebdcac9  vmovaps xmm14, [rsp+0xD0]
0000710e9ebdcad2  vmovaps xmm15, [rsp+0xE0]
0000710e9ebdcadb  add rsp, 0xF0
0000710e9ebdcae2  pop r11
0000710e9ebdcae4  pop r10
0000710e9ebdcae6  pop r9
0000710e9ebdcae8  pop r8
0000710e9ebdcaea  pop rsi
0000710e9ebdcaeb  pop rdi
0000710e9ebdcaec  pop rdx
0000710e9ebdcaed  pop rcx
0000710e9ebdcaee  pop rax
0000710e9ebdcaef  add rsp, 0x08
0000710e9ebdcaf3  jmp 0x0000710E9EBD9485
0000710e9ebdcaf8  sub rsp, 0x08
0000710e9ebdcafc  push rax
0000710e9ebdcafd  push rcx
0000710e9ebdcafe  push rdx
0000710e9ebdcaff  push rdi
0000710e9ebdcb00  push rsi
0000710e9ebdcb01  push r8
0000710e9ebdcb03  push r9
0000710e9ebdcb05  push r10
0000710e9ebdcb07  push r11
0000710e9ebdcb09  sub rsp, 0xF0
0000710e9ebdcb10  vmovaps [rsp], xmm0
0000710e9ebdcb15  vmovaps [rsp+0x10], xmm1
0000710e9ebdcb1b  vmovaps [rsp+0x20], xmm2
0000710e9ebdcb21  vmovaps [rsp+0x30], xmm3
0000710e9ebdcb27  vmovaps [rsp+0x40], xmm4
0000710e9ebdcb2d  vmovaps [rsp+0x50], xmm5
0000710e9ebdcb33  vmovaps [rsp+0x60], xmm6
0000710e9ebdcb39  vmovaps [rsp+0x70], xmm7
0000710e9ebdcb3f  vmovaps [rsp+0x80], xmm8
0000710e9ebdcb48  vmovaps [rsp+0x90], xmm9
0000710e9ebdcb51  vmovaps [rsp+0xA0], xmm10
0000710e9ebdcb5a  vmovaps [rsp+0xB0], xmm11
0000710e9ebdcb63  vmovaps [rsp+0xC0], xmm12
0000710e9ebdcb6c  vmovaps [rsp+0xD0], xmm13
0000710e9ebdcb75  vmovaps [rsp+0xE0], xmm14
0000710e9ebdcb7e  sub rsp, 0x30
0000710e9ebdcb82  movaps [rsp], xmm15
0000710e9ebdcb87  movaps [rsp+0x10], xmm1
0000710e9ebdcb8c  movaps [rsp+0x20], xmm5
0000710e9ebdcb91  lea rdi, [rsp]
0000710e9ebdcb95  mov esi, 0x00
0000710e9ebdcb9a  mov rax, 0x5DADAF7CF530
0000710e9ebdcba4  call rax
0000710e9ebdcba6  movaps xmm15, [rsp]
0000710e9ebdcbab  add rsp, 0x30
0000710e9ebdcbaf  vmovaps xmm0, [rsp]
0000710e9ebdcbb4  vmovaps xmm1, [rsp+0x10]
0000710e9ebdcbba  vmovaps xmm2, [rsp+0x20]
0000710e9ebdcbc0  vmovaps xmm3, [rsp+0x30]
0000710e9ebdcbc6  vmovaps xmm4, [rsp+0x40]
0000710e9ebdcbcc  vmovaps xmm5, [rsp+0x50]
0000710e9ebdcbd2  vmovaps xmm6, [rsp+0x60]
0000710e9ebdcbd8  vmovaps xmm7, [rsp+0x70]
0000710e9ebdcbde  vmovaps xmm8, [rsp+0x80]
0000710e9ebdcbe7  vmovaps xmm9, [rsp+0x90]
0000710e9ebdcbf0  vmovaps xmm10, [rsp+0xA0]
0000710e9ebdcbf9  vmovaps xmm11, [rsp+0xB0]
0000710e9ebdcc02  vmovaps xmm12, [rsp+0xC0]
0000710e9ebdcc0b  vmovaps xmm13, [rsp+0xD0]
0000710e9ebdcc14  vmovaps xmm14, [rsp+0xE0]
0000710e9ebdcc1d  add rsp, 0xF0
0000710e9ebdcc24  pop r11
0000710e9ebdcc26  pop r10
0000710e9ebdcc28  pop r9
0000710e9ebdcc2a  pop r8
0000710e9ebdcc2c  pop rsi
0000710e9ebdcc2d  pop rdi
0000710e9ebdcc2e  pop rdx
0000710e9ebdcc2f  pop rcx
0000710e9ebdcc30  pop rax
0000710e9ebdcc31  add rsp, 0x08
0000710e9ebdcc35  jmp 0x0000710E9EBD94A0
0000710e9ebdcc3a  call 0x0000710E9EAD64F0
0000710e9ebdcc3f  jmp 0x0000710E9EBD94FB
0000710e9ebdcc44  sub rsp, 0x08
0000710e9ebdcc48  push rax
0000710e9ebdcc49  push rcx
0000710e9ebdcc4a  push rdx
0000710e9ebdcc4b  push rdi
0000710e9ebdcc4c  push rsi
0000710e9ebdcc4d  push r8
0000710e9ebdcc4f  push r9
0000710e9ebdcc51  push r10
0000710e9ebdcc53  push r11
0000710e9ebdcc55  sub rsp, 0xF0
0000710e9ebdcc5c  vmovaps [rsp], xmm0
0000710e9ebdcc61  vmovaps [rsp+0x10], xmm1
0000710e9ebdcc67  vmovaps [rsp+0x20], xmm2
0000710e9ebdcc6d  vmovaps [rsp+0x30], xmm3
0000710e9ebdcc73  vmovaps [rsp+0x40], xmm4
0000710e9ebdcc79  vmovaps [rsp+0x50], xmm5
0000710e9ebdcc7f  vmovaps [rsp+0x60], xmm6
0000710e9ebdcc85  vmovaps [rsp+0x70], xmm7
0000710e9ebdcc8b  vmovaps [rsp+0x80], xmm8
0000710e9ebdcc94  vmovaps [rsp+0x90], xmm10
0000710e9ebdcc9d  vmovaps [rsp+0xA0], xmm11
0000710e9ebdcca6  vmovaps [rsp+0xB0], xmm12
0000710e9ebdccaf  vmovaps [rsp+0xC0], xmm13
0000710e9ebdccb8  vmovaps [rsp+0xD0], xmm14
0000710e9ebdccc1  vmovaps [rsp+0xE0], xmm15
0000710e9ebdccca  sub rsp, 0x30
0000710e9ebdccce  movaps [rsp], xmm9
0000710e9ebdccd3  movaps [rsp+0x10], xmm8
0000710e9ebdccd9  movaps [rsp+0x20], xmm11
0000710e9ebdccdf  lea rdi, [rsp]
0000710e9ebdcce3  mov esi, 0x00
0000710e9ebdcce8  mov rax, 0x5DADAF7CF530
0000710e9ebdccf2  call rax
0000710e9ebdccf4  movaps xmm9, [rsp]
0000710e9ebdccf9  add rsp, 0x30
0000710e9ebdccfd  vmovaps xmm0, [rsp]
0000710e9ebdcd02  vmovaps xmm1, [rsp+0x10]
0000710e9ebdcd08  vmovaps xmm2, [rsp+0x20]
0000710e9ebdcd0e  vmovaps xmm3, [rsp+0x30]
0000710e9ebdcd14  vmovaps xmm4, [rsp+0x40]
0000710e9ebdcd1a  vmovaps xmm5, [rsp+0x50]
0000710e9ebdcd20  vmovaps xmm6, [rsp+0x60]
0000710e9ebdcd26  vmovaps xmm7, [rsp+0x70]
0000710e9ebdcd2c  vmovaps xmm8, [rsp+0x80]
0000710e9ebdcd35  vmovaps xmm10, [rsp+0x90]
0000710e9ebdcd3e  vmovaps xmm11, [rsp+0xA0]
0000710e9ebdcd47  vmovaps xmm12, [rsp+0xB0]
0000710e9ebdcd50  vmovaps xmm13, [rsp+0xC0]
0000710e9ebdcd59  vmovaps xmm14, [rsp+0xD0]
0000710e9ebdcd62  vmovaps xmm15, [rsp+0xE0]
0000710e9ebdcd6b  add rsp, 0xF0
0000710e9ebdcd72  pop r11
0000710e9ebdcd74  pop r10
0000710e9ebdcd76  pop r9
0000710e9ebdcd78  pop r8
0000710e9ebdcd7a  pop rsi
0000710e9ebdcd7b  pop rdi
0000710e9ebdcd7c  pop rdx
0000710e9ebdcd7d  pop rcx
0000710e9ebdcd7e  pop rax
0000710e9ebdcd7f  add rsp, 0x08
0000710e9ebdcd83  jmp 0x0000710E9EBD9532
0000710e9ebdcd88  sub rsp, 0x08
0000710e9ebdcd8c  push rax
0000710e9ebdcd8d  push rcx
0000710e9ebdcd8e  push rdx
0000710e9ebdcd8f  push rdi
0000710e9ebdcd90  push rsi
0000710e9ebdcd91  push r8
0000710e9ebdcd93  push r9
0000710e9ebdcd95  push r10
0000710e9ebdcd97  push r11
0000710e9ebdcd99  sub rsp, 0xF0
0000710e9ebdcda0  vmovaps [rsp], xmm0
0000710e9ebdcda5  vmovaps [rsp+0x10], xmm1
0000710e9ebdcdab  vmovaps [rsp+0x20], xmm2
0000710e9ebdcdb1  vmovaps [rsp+0x30], xmm3
0000710e9ebdcdb7  vmovaps [rsp+0x40], xmm4
0000710e9ebdcdbd  vmovaps [rsp+0x50], xmm5
0000710e9ebdcdc3  vmovaps [rsp+0x60], xmm6
0000710e9ebdcdc9  vmovaps [rsp+0x70], xmm7
0000710e9ebdcdcf  vmovaps [rsp+0x80], xmm8
0000710e9ebdcdd8  vmovaps [rsp+0x90], xmm9
0000710e9ebdcde1  vmovaps [rsp+0xA0], xmm10
0000710e9ebdcdea  vmovaps [rsp+0xB0], xmm12
0000710e9ebdcdf3  vmovaps [rsp+0xC0], xmm13
0000710e9ebdcdfc  vmovaps [rsp+0xD0], xmm14
0000710e9ebdce05  vmovaps [rsp+0xE0], xmm15
0000710e9ebdce0e  sub rsp, 0x30
0000710e9ebdce12  movaps [rsp], xmm11
0000710e9ebdce17  movaps [rsp+0x10], xmm10
0000710e9ebdce1d  movaps [rsp+0x20], xmm6
0000710e9ebdce22  lea rdi, [rsp]
0000710e9ebdce26  mov esi, 0x00
0000710e9ebdce2b  mov rax, 0x5DADAF7CF530
0000710e9ebdce35  call rax
0000710e9ebdce37  movaps xmm11, [rsp]
0000710e9ebdce3c  add rsp, 0x30
0000710e9ebdce40  vmovaps xmm0, [rsp]
0000710e9ebdce45  vmovaps xmm1, [rsp+0x10]
0000710e9ebdce4b  vmovaps xmm2, [rsp+0x20]
0000710e9ebdce51  vmovaps xmm3, [rsp+0x30]
0000710e9ebdce57  vmovaps xmm4, [rsp+0x40]
0000710e9ebdce5d  vmovaps xmm5, [rsp+0x50]
0000710e9ebdce63  vmovaps xmm6, [rsp+0x60]
0000710e9ebdce69  vmovaps xmm7, [rsp+0x70]
0000710e9ebdce6f  vmovaps xmm8, [rsp+0x80]
0000710e9ebdce78  vmovaps xmm9, [rsp+0x90]
0000710e9ebdce81  vmovaps xmm10, [rsp+0xA0]
0000710e9ebdce8a  vmovaps xmm12, [rsp+0xB0]
0000710e9ebdce93  vmovaps xmm13, [rsp+0xC0]
0000710e9ebdce9c  vmovaps xmm14, [rsp+0xD0]
0000710e9ebdcea5  vmovaps xmm15, [rsp+0xE0]
0000710e9ebdceae  add rsp, 0xF0
0000710e9ebdceb5  pop r11
0000710e9ebdceb7  pop r10
0000710e9ebdceb9  pop r9
0000710e9ebdcebb  pop r8
0000710e9ebdcebd  pop rsi
0000710e9ebdcebe  pop rdi
0000710e9ebdcebf  pop rdx
0000710e9ebdcec0  pop rcx
0000710e9ebdcec1  pop rax
0000710e9ebdcec2  add rsp, 0x08
0000710e9ebdcec6  jmp 0x0000710E9EBD954D
0000710e9ebdcecb  sub rsp, 0x08
0000710e9ebdcecf  push rax
0000710e9ebdced0  push rcx
0000710e9ebdced1  push rdx
0000710e9ebdced2  push rdi
0000710e9ebdced3  push rsi
0000710e9ebdced4  push r8
0000710e9ebdced6  push r9
0000710e9ebdced8  push r10
0000710e9ebdceda  push r11
0000710e9ebdcedc  sub rsp, 0xF0
0000710e9ebdcee3  vmovaps [rsp], xmm0
0000710e9ebdcee8  vmovaps [rsp+0x10], xmm1
0000710e9ebdceee  vmovaps [rsp+0x20], xmm2
0000710e9ebdcef4  vmovaps [rsp+0x30], xmm3
0000710e9ebdcefa  vmovaps [rsp+0x40], xmm4
0000710e9ebdcf00  vmovaps [rsp+0x50], xmm5
0000710e9ebdcf06  vmovaps [rsp+0x60], xmm6
0000710e9ebdcf0c  vmovaps [rsp+0x70], xmm7
0000710e9ebdcf12  vmovaps [rsp+0x80], xmm8
0000710e9ebdcf1b  vmovaps [rsp+0x90], xmm9
0000710e9ebdcf24  vmovaps [rsp+0xA0], xmm11
0000710e9ebdcf2d  vmovaps [rsp+0xB0], xmm12
0000710e9ebdcf36  vmovaps [rsp+0xC0], xmm13
0000710e9ebdcf3f  vmovaps [rsp+0xD0], xmm14
0000710e9ebdcf48  vmovaps [rsp+0xE0], xmm15
0000710e9ebdcf51  sub rsp, 0x30
0000710e9ebdcf55  movaps [rsp], xmm10
0000710e9ebdcf5a  movaps [rsp+0x10], xmm14
0000710e9ebdcf60  movaps [rsp+0x20], xmm4
0000710e9ebdcf65  lea rdi, [rsp]
0000710e9ebdcf69  mov esi, 0x00
0000710e9ebdcf6e  mov rax, 0x5DADAF7CF530
0000710e9ebdcf78  call rax
0000710e9ebdcf7a  movaps xmm10, [rsp]
0000710e9ebdcf7f  add rsp, 0x30
0000710e9ebdcf83  vmovaps xmm0, [rsp]
0000710e9ebdcf88  vmovaps xmm1, [rsp+0x10]
0000710e9ebdcf8e  vmovaps xmm2, [rsp+0x20]
0000710e9ebdcf94  vmovaps xmm3, [rsp+0x30]
0000710e9ebdcf9a  vmovaps xmm4, [rsp+0x40]
0000710e9ebdcfa0  vmovaps xmm5, [rsp+0x50]
0000710e9ebdcfa6  vmovaps xmm6, [rsp+0x60]
0000710e9ebdcfac  vmovaps xmm7, [rsp+0x70]
0000710e9ebdcfb2  vmovaps xmm8, [rsp+0x80]
0000710e9ebdcfbb  vmovaps xmm9, [rsp+0x90]
0000710e9ebdcfc4  vmovaps xmm11, [rsp+0xA0]
0000710e9ebdcfcd  vmovaps xmm12, [rsp+0xB0]
0000710e9ebdcfd6  vmovaps xmm13, [rsp+0xC0]
0000710e9ebdcfdf  vmovaps xmm14, [rsp+0xD0]
0000710e9ebdcfe8  vmovaps xmm15, [rsp+0xE0]
0000710e9ebdcff1  add rsp, 0xF0
0000710e9ebdcff8  pop r11
0000710e9ebdcffa  pop r10
0000710e9ebdcffc  pop r9
0000710e9ebdcffe  pop r8
0000710e9ebdd000  pop rsi
0000710e9ebdd001  pop rdi
0000710e9ebdd002  pop rdx
0000710e9ebdd003  pop rcx
0000710e9ebdd004  pop rax
0000710e9ebdd005  add rsp, 0x08
0000710e9ebdd009  jmp 0x0000710E9EBD9568
0000710e9ebdd00e  sub rsp, 0x08
0000710e9ebdd012  push rax
0000710e9ebdd013  push rcx
0000710e9ebdd014  push rdx
0000710e9ebdd015  push rdi
0000710e9ebdd016  push rsi
0000710e9ebdd017  push r8
0000710e9ebdd019  push r9
0000710e9ebdd01b  push r10
0000710e9ebdd01d  push r11
0000710e9ebdd01f  sub rsp, 0xF0
0000710e9ebdd026  vmovaps [rsp], xmm0
0000710e9ebdd02b  vmovaps [rsp+0x10], xmm1
0000710e9ebdd031  vmovaps [rsp+0x20], xmm2
0000710e9ebdd037  vmovaps [rsp+0x30], xmm3
0000710e9ebdd03d  vmovaps [rsp+0x40], xmm4
0000710e9ebdd043  vmovaps [rsp+0x50], xmm5
0000710e9ebdd049  vmovaps [rsp+0x60], xmm6
0000710e9ebdd04f  vmovaps [rsp+0x70], xmm7
0000710e9ebdd055  vmovaps [rsp+0x80], xmm9
0000710e9ebdd05e  vmovaps [rsp+0x90], xmm10
0000710e9ebdd067  vmovaps [rsp+0xA0], xmm11
0000710e9ebdd070  vmovaps [rsp+0xB0], xmm12
0000710e9ebdd079  vmovaps [rsp+0xC0], xmm13
0000710e9ebdd082  vmovaps [rsp+0xD0], xmm14
0000710e9ebdd08b  vmovaps [rsp+0xE0], xmm15
0000710e9ebdd094  sub rsp, 0x30
0000710e9ebdd098  movaps [rsp], xmm8
0000710e9ebdd09d  movaps [rsp+0x10], xmm1
0000710e9ebdd0a2  movaps [rsp+0x20], xmm14
0000710e9ebdd0a8  lea rdi, [rsp]
0000710e9ebdd0ac  mov esi, 0x00
0000710e9ebdd0b1  mov rax, 0x5DADAF7CF530
0000710e9ebdd0bb  call rax
0000710e9ebdd0bd  movaps xmm8, [rsp]
0000710e9ebdd0c2  add rsp, 0x30
0000710e9ebdd0c6  vmovaps xmm0, [rsp]
0000710e9ebdd0cb  vmovaps xmm1, [rsp+0x10]
0000710e9ebdd0d1  vmovaps xmm2, [rsp+0x20]
0000710e9ebdd0d7  vmovaps xmm3, [rsp+0x30]
0000710e9ebdd0dd  vmovaps xmm4, [rsp+0x40]
0000710e9ebdd0e3  vmovaps xmm5, [rsp+0x50]
0000710e9ebdd0e9  vmovaps xmm6, [rsp+0x60]
0000710e9ebdd0ef  vmovaps xmm7, [rsp+0x70]
0000710e9ebdd0f5  vmovaps xmm9, [rsp+0x80]
0000710e9ebdd0fe  vmovaps xmm10, [rsp+0x90]
0000710e9ebdd107  vmovaps xmm11, [rsp+0xA0]
0000710e9ebdd110  vmovaps xmm12, [rsp+0xB0]
0000710e9ebdd119  vmovaps xmm13, [rsp+0xC0]
0000710e9ebdd122  vmovaps xmm14, [rsp+0xD0]
0000710e9ebdd12b  vmovaps xmm15, [rsp+0xE0]
0000710e9ebdd134  add rsp, 0xF0
0000710e9ebdd13b  pop r11
0000710e9ebdd13d  pop r10
0000710e9ebdd13f  pop r9
0000710e9ebdd141  pop r8
0000710e9ebdd143  pop rsi
0000710e9ebdd144  pop rdi
0000710e9ebdd145  pop rdx
0000710e9ebdd146  pop rcx
0000710e9ebdd147  pop rax
0000710e9ebdd148  add rsp, 0x08
0000710e9ebdd14c  jmp 0x0000710E9EBD958E
0000710e9ebdd151  sub rsp, 0x08
0000710e9ebdd155  push rax
0000710e9ebdd156  push rcx
0000710e9ebdd157  push rdx
0000710e9ebdd158  push rdi
0000710e9ebdd159  push rsi
0000710e9ebdd15a  push r8
0000710e9ebdd15c  push r9
0000710e9ebdd15e  push r10
0000710e9ebdd160  push r11
0000710e9ebdd162  sub rsp, 0xF0
0000710e9ebdd169  vmovaps [rsp], xmm0
0000710e9ebdd16e  vmovaps [rsp+0x10], xmm1
0000710e9ebdd174  vmovaps [rsp+0x20], xmm2
0000710e9ebdd17a  vmovaps [rsp+0x30], xmm3
0000710e9ebdd180  vmovaps [rsp+0x40], xmm4
0000710e9ebdd186  vmovaps [rsp+0x50], xmm5
0000710e9ebdd18c  vmovaps [rsp+0x60], xmm7
0000710e9ebdd192  vmovaps [rsp+0x70], xmm8
0000710e9ebdd198  vmovaps [rsp+0x80], xmm9
0000710e9ebdd1a1  vmovaps [rsp+0x90], xmm10
0000710e9ebdd1aa  vmovaps [rsp+0xA0], xmm11
0000710e9ebdd1b3  vmovaps [rsp+0xB0], xmm12
0000710e9ebdd1bc  vmovaps [rsp+0xC0], xmm13
0000710e9ebdd1c5  vmovaps [rsp+0xD0], xmm14
0000710e9ebdd1ce  vmovaps [rsp+0xE0], xmm15
0000710e9ebdd1d7  sub rsp, 0x30
0000710e9ebdd1db  movaps [rsp], xmm6
0000710e9ebdd1df  movaps [rsp+0x10], xmm1
0000710e9ebdd1e4  movaps [rsp+0x20], xmm14
0000710e9ebdd1ea  lea rdi, [rsp]
0000710e9ebdd1ee  mov esi, 0x00
0000710e9ebdd1f3  mov rax, 0x5DADAF7CF530
0000710e9ebdd1fd  call rax
0000710e9ebdd1ff  movaps xmm6, [rsp]
0000710e9ebdd203  add rsp, 0x30
0000710e9ebdd207  vmovaps xmm0, [rsp]
0000710e9ebdd20c  vmovaps xmm1, [rsp+0x10]
0000710e9ebdd212  vmovaps xmm2, [rsp+0x20]
0000710e9ebdd218  vmovaps xmm3, [rsp+0x30]
0000710e9ebdd21e  vmovaps xmm4, [rsp+0x40]
0000710e9ebdd224  vmovaps xmm5, [rsp+0x50]
0000710e9ebdd22a  vmovaps xmm7, [rsp+0x60]
0000710e9ebdd230  vmovaps xmm8, [rsp+0x70]
0000710e9ebdd236  vmovaps xmm9, [rsp+0x80]
0000710e9ebdd23f  vmovaps xmm10, [rsp+0x90]
0000710e9ebdd248  vmovaps xmm11, [rsp+0xA0]
0000710e9ebdd251  vmovaps xmm12, [rsp+0xB0]
0000710e9ebdd25a  vmovaps xmm13, [rsp+0xC0]
0000710e9ebdd263  vmovaps xmm14, [rsp+0xD0]
0000710e9ebdd26c  vmovaps xmm15, [rsp+0xE0]
0000710e9ebdd275  add rsp, 0xF0
0000710e9ebdd27c  pop r11
0000710e9ebdd27e  pop r10
0000710e9ebdd280  pop r9
0000710e9ebdd282  pop r8
0000710e9ebdd284  pop rsi
0000710e9ebdd285  pop rdi
0000710e9ebdd286  pop rdx
0000710e9ebdd287  pop rcx
0000710e9ebdd288  pop rax
0000710e9ebdd289  add rsp, 0x08
0000710e9ebdd28d  jmp 0x0000710E9EBD95BA
0000710e9ebdd292  sub rsp, 0x08
0000710e9ebdd296  push rax
0000710e9ebdd297  push rcx
0000710e9ebdd298  push rdx
0000710e9ebdd299  push rdi
0000710e9ebdd29a  push rsi
0000710e9ebdd29b  push r8
0000710e9ebdd29d  push r9
0000710e9ebdd29f  push r10
0000710e9ebdd2a1  push r11
0000710e9ebdd2a3  sub rsp, 0xF0
0000710e9ebdd2aa  vmovaps [rsp], xmm0
0000710e9ebdd2af  vmovaps [rsp+0x10], xmm1
0000710e9ebdd2b5  vmovaps [rsp+0x20], xmm2
0000710e9ebdd2bb  vmovaps [rsp+0x30], xmm3
0000710e9ebdd2c1  vmovaps [rsp+0x40], xmm4
0000710e9ebdd2c7  vmovaps [rsp+0x50], xmm5
0000710e9ebdd2cd  vmovaps [rsp+0x60], xmm6
0000710e9ebdd2d3  vmovaps [rsp+0x70], xmm7
0000710e9ebdd2d9  vmovaps [rsp+0x80], xmm8
0000710e9ebdd2e2  vmovaps [rsp+0x90], xmm9
0000710e9ebdd2eb  vmovaps [rsp+0xA0], xmm10
0000710e9ebdd2f4  vmovaps [rsp+0xB0], xmm11
0000710e9ebdd2fd  vmovaps [rsp+0xC0], xmm12
0000710e9ebdd306  vmovaps [rsp+0xD0], xmm13
0000710e9ebdd30f  vmovaps [rsp+0xE0], xmm15
0000710e9ebdd318  sub rsp, 0x30
0000710e9ebdd31c  movaps [rsp], xmm14
0000710e9ebdd321  movaps [rsp+0x10], xmm12
0000710e9ebdd327  movaps [rsp+0x20], xmm1
0000710e9ebdd32c  lea rdi, [rsp]
0000710e9ebdd330  mov esi, 0x00
0000710e9ebdd335  mov rax, 0x5DADAF7CF530
0000710e9ebdd33f  call rax
0000710e9ebdd341  movaps xmm14, [rsp]
0000710e9ebdd346  add rsp, 0x30
0000710e9ebdd34a  vmovaps xmm0, [rsp]
0000710e9ebdd34f  vmovaps xmm1, [rsp+0x10]
0000710e9ebdd355  vmovaps xmm2, [rsp+0x20]
0000710e9ebdd35b  vmovaps xmm3, [rsp+0x30]
0000710e9ebdd361  vmovaps xmm4, [rsp+0x40]
0000710e9ebdd367  vmovaps xmm5, [rsp+0x50]
0000710e9ebdd36d  vmovaps xmm6, [rsp+0x60]
0000710e9ebdd373  vmovaps xmm7, [rsp+0x70]
0000710e9ebdd379  vmovaps xmm8, [rsp+0x80]
0000710e9ebdd382  vmovaps xmm9, [rsp+0x90]
0000710e9ebdd38b  vmovaps xmm10, [rsp+0xA0]
0000710e9ebdd394  vmovaps xmm11, [rsp+0xB0]
0000710e9ebdd39d  vmovaps xmm12, [rsp+0xC0]
0000710e9ebdd3a6  vmovaps xmm13, [rsp+0xD0]
0000710e9ebdd3af  vmovaps xmm15, [rsp+0xE0]
0000710e9ebdd3b8  add rsp, 0xF0
0000710e9ebdd3bf  pop r11
0000710e9ebdd3c1  pop r10
0000710e9ebdd3c3  pop r9
0000710e9ebdd3c5  pop r8
0000710e9ebdd3c7  pop rsi
0000710e9ebdd3c8  pop rdi
0000710e9ebdd3c9  pop rdx
0000710e9ebdd3ca  pop rcx
0000710e9ebdd3cb  pop rax
0000710e9ebdd3cc  add rsp, 0x08
0000710e9ebdd3d0  jmp 0x0000710E9EBD95E0
0000710e9ebdd3d5  sub rsp, 0x08
0000710e9ebdd3d9  push rax
0000710e9ebdd3da  push rcx
0000710e9ebdd3db  push rdx
0000710e9ebdd3dc  push rdi
0000710e9ebdd3dd  push rsi
0000710e9ebdd3de  push r8
0000710e9ebdd3e0  push r9
0000710e9ebdd3e2  push r10
0000710e9ebdd3e4  push r11
0000710e9ebdd3e6  sub rsp, 0xF0
0000710e9ebdd3ed  vmovaps [rsp], xmm0
0000710e9ebdd3f2  vmovaps [rsp+0x10], xmm2
0000710e9ebdd3f8  vmovaps [rsp+0x20], xmm3
0000710e9ebdd3fe  vmovaps [rsp+0x30], xmm4
0000710e9ebdd404  vmovaps [rsp+0x40], xmm5
0000710e9ebdd40a  vmovaps [rsp+0x50], xmm6
0000710e9ebdd410  vmovaps [rsp+0x60], xmm7
0000710e9ebdd416  vmovaps [rsp+0x70], xmm8
0000710e9ebdd41c  vmovaps [rsp+0x80], xmm9
0000710e9ebdd425  vmovaps [rsp+0x90], xmm10
0000710e9ebdd42e  vmovaps [rsp+0xA0], xmm11
0000710e9ebdd437  vmovaps [rsp+0xB0], xmm12
0000710e9ebdd440  vmovaps [rsp+0xC0], xmm13
0000710e9ebdd449  vmovaps [rsp+0xD0], xmm14
0000710e9ebdd452  vmovaps [rsp+0xE0], xmm15
0000710e9ebdd45b  sub rsp, 0x30
0000710e9ebdd45f  movaps [rsp], xmm1
0000710e9ebdd463  movaps [rsp+0x10], xmm13
0000710e9ebdd469  movaps [rsp+0x20], xmm9
0000710e9ebdd46f  lea rdi, [rsp]
0000710e9ebdd473  mov esi, 0x00
0000710e9ebdd478  mov rax, 0x5DADAF7CF530
0000710e9ebdd482  call rax
0000710e9ebdd484  movaps xmm1, [rsp]
0000710e9ebdd488  add rsp, 0x30
0000710e9ebdd48c  vmovaps xmm0, [rsp]
0000710e9ebdd491  vmovaps xmm2, [rsp+0x10]
0000710e9ebdd497  vmovaps xmm3, [rsp+0x20]
0000710e9ebdd49d  vmovaps xmm4, [rsp+0x30]
0000710e9ebdd4a3  vmovaps xmm5, [rsp+0x40]
0000710e9ebdd4a9  vmovaps xmm6, [rsp+0x50]
0000710e9ebdd4af  vmovaps xmm7, [rsp+0x60]
0000710e9ebdd4b5  vmovaps xmm8, [rsp+0x70]
0000710e9ebdd4bb  vmovaps xmm9, [rsp+0x80]
0000710e9ebdd4c4  vmovaps xmm10, [rsp+0x90]
0000710e9ebdd4cd  vmovaps xmm11, [rsp+0xA0]
0000710e9ebdd4d6  vmovaps xmm12, [rsp+0xB0]
0000710e9ebdd4df  vmovaps xmm13, [rsp+0xC0]
0000710e9ebdd4e8  vmovaps xmm14, [rsp+0xD0]
0000710e9ebdd4f1  vmovaps xmm15, [rsp+0xE0]
0000710e9ebdd4fa  add rsp, 0xF0
0000710e9ebdd501  pop r11
0000710e9ebdd503  pop r10
0000710e9ebdd505  pop r9
0000710e9ebdd507  pop r8
0000710e9ebdd509  pop rsi
0000710e9ebdd50a  pop rdi
0000710e9ebdd50b  pop rdx
0000710e9ebdd50c  pop rcx
0000710e9ebdd50d  pop rax
0000710e9ebdd50e  add rsp, 0x08
0000710e9ebdd512  jmp 0x0000710E9EBD95FA
0000710e9ebdd517  sub rsp, 0x08
0000710e9ebdd51b  push rax
0000710e9ebdd51c  push rcx
0000710e9ebdd51d  push rdx
0000710e9ebdd51e  push rdi
0000710e9ebdd51f  push rsi
0000710e9ebdd520  push r8
0000710e9ebdd522  push r9
0000710e9ebdd524  push r10
0000710e9ebdd526  push r11
0000710e9ebdd528  sub rsp, 0xF0
0000710e9ebdd52f  vmovaps [rsp], xmm0
0000710e9ebdd534  vmovaps [rsp+0x10], xmm1
0000710e9ebdd53a  vmovaps [rsp+0x20], xmm2
0000710e9ebdd540  vmovaps [rsp+0x30], xmm3
0000710e9ebdd546  vmovaps [rsp+0x40], xmm4
0000710e9ebdd54c  vmovaps [rsp+0x50], xmm5
0000710e9ebdd552  vmovaps [rsp+0x60], xmm6
0000710e9ebdd558  vmovaps [rsp+0x70], xmm7
0000710e9ebdd55e  vmovaps [rsp+0x80], xmm8
0000710e9ebdd567  vmovaps [rsp+0x90], xmm9
0000710e9ebdd570  vmovaps [rsp+0xA0], xmm10
0000710e9ebdd579  vmovaps [rsp+0xB0], xmm11
0000710e9ebdd582  vmovaps [rsp+0xC0], xmm13
0000710e9ebdd58b  vmovaps [rsp+0xD0], xmm14
0000710e9ebdd594  vmovaps [rsp+0xE0], xmm15
0000710e9ebdd59d  sub rsp, 0x30
0000710e9ebdd5a1  movaps [rsp], xmm12
0000710e9ebdd5a6  movaps [rsp+0x10], xmm7
0000710e9ebdd5ab  movaps [rsp+0x20], xmm13
0000710e9ebdd5b1  lea rdi, [rsp]
0000710e9ebdd5b5  mov esi, 0x00
0000710e9ebdd5ba  mov rax, 0x5DADAF7CF530
0000710e9ebdd5c4  call rax
0000710e9ebdd5c6  movaps xmm12, [rsp]
0000710e9ebdd5cb  add rsp, 0x30
0000710e9ebdd5cf  vmovaps xmm0, [rsp]
0000710e9ebdd5d4  vmovaps xmm1, [rsp+0x10]
0000710e9ebdd5da  vmovaps xmm2, [rsp+0x20]
0000710e9ebdd5e0  vmovaps xmm3, [rsp+0x30]
0000710e9ebdd5e6  vmovaps xmm4, [rsp+0x40]
0000710e9ebdd5ec  vmovaps xmm5, [rsp+0x50]
0000710e9ebdd5f2  vmovaps xmm6, [rsp+0x60]
0000710e9ebdd5f8  vmovaps xmm7, [rsp+0x70]
0000710e9ebdd5fe  vmovaps xmm8, [rsp+0x80]
0000710e9ebdd607  vmovaps xmm9, [rsp+0x90]
0000710e9ebdd610  vmovaps xmm10, [rsp+0xA0]
0000710e9ebdd619  vmovaps xmm11, [rsp+0xB0]
0000710e9ebdd622  vmovaps xmm13, [rsp+0xC0]
0000710e9ebdd62b  vmovaps xmm14, [rsp+0xD0]
0000710e9ebdd634  vmovaps xmm15, [rsp+0xE0]
0000710e9ebdd63d  add rsp, 0xF0
0000710e9ebdd644  pop r11
0000710e9ebdd646  pop r10
0000710e9ebdd648  pop r9
0000710e9ebdd64a  pop r8
0000710e9ebdd64c  pop rsi
0000710e9ebdd64d  pop rdi
0000710e9ebdd64e  pop rdx
0000710e9ebdd64f  pop rcx
0000710e9ebdd650  pop rax
0000710e9ebdd651  add rsp, 0x08
0000710e9ebdd655  jmp 0x0000710E9EBD9621
0000710e9ebdd65a  sub rsp, 0x08
0000710e9ebdd65e  push rax
0000710e9ebdd65f  push rcx
0000710e9ebdd660  push rdx
0000710e9ebdd661  push rdi
0000710e9ebdd662  push rsi
0000710e9ebdd663  push r8
0000710e9ebdd665  push r9
0000710e9ebdd667  push r10
0000710e9ebdd669  push r11
0000710e9ebdd66b  sub rsp, 0xF0
0000710e9ebdd672  vmovaps [rsp], xmm0
0000710e9ebdd677  vmovaps [rsp+0x10], xmm1
0000710e9ebdd67d  vmovaps [rsp+0x20], xmm2
0000710e9ebdd683  vmovaps [rsp+0x30], xmm3
0000710e9ebdd689  vmovaps [rsp+0x40], xmm4
0000710e9ebdd68f  vmovaps [rsp+0x50], xmm5
0000710e9ebdd695  vmovaps [rsp+0x60], xmm6
0000710e9ebdd69b  vmovaps [rsp+0x70], xmm7
0000710e9ebdd6a1  vmovaps [rsp+0x80], xmm8
0000710e9ebdd6aa  vmovaps [rsp+0x90], xmm9
0000710e9ebdd6b3  vmovaps [rsp+0xA0], xmm10
0000710e9ebdd6bc  vmovaps [rsp+0xB0], xmm11
0000710e9ebdd6c5  vmovaps [rsp+0xC0], xmm12
0000710e9ebdd6ce  vmovaps [rsp+0xD0], xmm14
0000710e9ebdd6d7  vmovaps [rsp+0xE0], xmm15
0000710e9ebdd6e0  sub rsp, 0x30
0000710e9ebdd6e4  movaps [rsp], xmm13
0000710e9ebdd6e9  movaps [rsp+0x10], xmm15
0000710e9ebdd6ef  movaps [rsp+0x20], xmm8
0000710e9ebdd6f5  lea rdi, [rsp]
0000710e9ebdd6f9  mov esi, 0x00
0000710e9ebdd6fe  mov rax, 0x5DADAF7CF530
0000710e9ebdd708  call rax
0000710e9ebdd70a  movaps xmm13, [rsp]
0000710e9ebdd70f  add rsp, 0x30
0000710e9ebdd713  vmovaps xmm0, [rsp]
0000710e9ebdd718  vmovaps xmm1, [rsp+0x10]
0000710e9ebdd71e  vmovaps xmm2, [rsp+0x20]
0000710e9ebdd724  vmovaps xmm3, [rsp+0x30]
0000710e9ebdd72a  vmovaps xmm4, [rsp+0x40]
0000710e9ebdd730  vmovaps xmm5, [rsp+0x50]
0000710e9ebdd736  vmovaps xmm6, [rsp+0x60]
0000710e9ebdd73c  vmovaps xmm7, [rsp+0x70]
0000710e9ebdd742  vmovaps xmm8, [rsp+0x80]
0000710e9ebdd74b  vmovaps xmm9, [rsp+0x90]
0000710e9ebdd754  vmovaps xmm10, [rsp+0xA0]
0000710e9ebdd75d  vmovaps xmm11, [rsp+0xB0]
0000710e9ebdd766  vmovaps xmm12, [rsp+0xC0]
0000710e9ebdd76f  vmovaps xmm14, [rsp+0xD0]
0000710e9ebdd778  vmovaps xmm15, [rsp+0xE0]
0000710e9ebdd781  add rsp, 0xF0
0000710e9ebdd788  pop r11
0000710e9ebdd78a  pop r10
0000710e9ebdd78c  pop r9
0000710e9ebdd78e  pop r8
0000710e9ebdd790  pop rsi
0000710e9ebdd791  pop rdi
0000710e9ebdd792  pop rdx
0000710e9ebdd793  pop rcx
0000710e9ebdd794  pop rax
0000710e9ebdd795  add rsp, 0x08
0000710e9ebdd799  jmp 0x0000710E9EBD963C
0000710e9ebdd79e  sub rsp, 0x08
0000710e9ebdd7a2  push rax
0000710e9ebdd7a3  push rcx
0000710e9ebdd7a4  push rdx
0000710e9ebdd7a5  push rdi
0000710e9ebdd7a6  push rsi
0000710e9ebdd7a7  push r8
0000710e9ebdd7a9  push r9
0000710e9ebdd7ab  push r10
0000710e9ebdd7ad  push r11
0000710e9ebdd7af  sub rsp, 0xF0
0000710e9ebdd7b6  vmovaps [rsp], xmm0
0000710e9ebdd7bb  vmovaps [rsp+0x10], xmm1
0000710e9ebdd7c1  vmovaps [rsp+0x20], xmm2
0000710e9ebdd7c7  vmovaps [rsp+0x30], xmm3
0000710e9ebdd7cd  vmovaps [rsp+0x40], xmm4
0000710e9ebdd7d3  vmovaps [rsp+0x50], xmm5
0000710e9ebdd7d9  vmovaps [rsp+0x60], xmm6
0000710e9ebdd7df  vmovaps [rsp+0x70], xmm7
0000710e9ebdd7e5  vmovaps [rsp+0x80], xmm9
0000710e9ebdd7ee  vmovaps [rsp+0x90], xmm10
0000710e9ebdd7f7  vmovaps [rsp+0xA0], xmm11
0000710e9ebdd800  vmovaps [rsp+0xB0], xmm12
0000710e9ebdd809  vmovaps [rsp+0xC0], xmm13
0000710e9ebdd812  vmovaps [rsp+0xD0], xmm14
0000710e9ebdd81b  vmovaps [rsp+0xE0], xmm15
0000710e9ebdd824  sub rsp, 0x30
0000710e9ebdd828  movaps [rsp], xmm8
0000710e9ebdd82d  movaps [rsp+0x10], xmm15
0000710e9ebdd833  movaps [rsp+0x20], xmm9
0000710e9ebdd839  lea rdi, [rsp]
0000710e9ebdd83d  mov esi, 0x00
0000710e9ebdd842  mov rax, 0x5DADAF7CF530
0000710e9ebdd84c  call rax
0000710e9ebdd84e  movaps xmm8, [rsp]
0000710e9ebdd853  add rsp, 0x30
0000710e9ebdd857  vmovaps xmm0, [rsp]
0000710e9ebdd85c  vmovaps xmm1, [rsp+0x10]
0000710e9ebdd862  vmovaps xmm2, [rsp+0x20]
0000710e9ebdd868  vmovaps xmm3, [rsp+0x30]
0000710e9ebdd86e  vmovaps xmm4, [rsp+0x40]
0000710e9ebdd874  vmovaps xmm5, [rsp+0x50]
0000710e9ebdd87a  vmovaps xmm6, [rsp+0x60]
0000710e9ebdd880  vmovaps xmm7, [rsp+0x70]
0000710e9ebdd886  vmovaps xmm9, [rsp+0x80]
0000710e9ebdd88f  vmovaps xmm10, [rsp+0x90]
0000710e9ebdd898  vmovaps xmm11, [rsp+0xA0]
0000710e9ebdd8a1  vmovaps xmm12, [rsp+0xB0]
0000710e9ebdd8aa  vmovaps xmm13, [rsp+0xC0]
0000710e9ebdd8b3  vmovaps xmm14, [rsp+0xD0]
0000710e9ebdd8bc  vmovaps xmm15, [rsp+0xE0]
0000710e9ebdd8c5  add rsp, 0xF0
0000710e9ebdd8cc  pop r11
0000710e9ebdd8ce  pop r10
0000710e9ebdd8d0  pop r9
0000710e9ebdd8d2  pop r8
0000710e9ebdd8d4  pop rsi
0000710e9ebdd8d5  pop rdi
0000710e9ebdd8d6  pop rdx
0000710e9ebdd8d7  pop rcx
0000710e9ebdd8d8  pop rax
0000710e9ebdd8d9  add rsp, 0x08
0000710e9ebdd8dd  jmp 0x0000710E9EBD966A
0000710e9ebdd8e2  sub rsp, 0x08
0000710e9ebdd8e6  push rax
0000710e9ebdd8e7  push rcx
0000710e9ebdd8e8  push rdx
0000710e9ebdd8e9  push rdi
0000710e9ebdd8ea  push rsi
0000710e9ebdd8eb  push r8
0000710e9ebdd8ed  push r9
0000710e9ebdd8ef  push r10
0000710e9ebdd8f1  push r11
0000710e9ebdd8f3  sub rsp, 0xF0
0000710e9ebdd8fa  vmovaps [rsp], xmm0
0000710e9ebdd8ff  vmovaps [rsp+0x10], xmm1
0000710e9ebdd905  vmovaps [rsp+0x20], xmm2
0000710e9ebdd90b  vmovaps [rsp+0x30], xmm3
0000710e9ebdd911  vmovaps [rsp+0x40], xmm4
0000710e9ebdd917  vmovaps [rsp+0x50], xmm5
0000710e9ebdd91d  vmovaps [rsp+0x60], xmm6
0000710e9ebdd923  vmovaps [rsp+0x70], xmm7
0000710e9ebdd929  vmovaps [rsp+0x80], xmm8
0000710e9ebdd932  vmovaps [rsp+0x90], xmm9
0000710e9ebdd93b  vmovaps [rsp+0xA0], xmm10
0000710e9ebdd944  vmovaps [rsp+0xB0], xmm11
0000710e9ebdd94d  vmovaps [rsp+0xC0], xmm12
0000710e9ebdd956  vmovaps [rsp+0xD0], xmm13
0000710e9ebdd95f  vmovaps [rsp+0xE0], xmm14
0000710e9ebdd968  sub rsp, 0x30
0000710e9ebdd96c  movaps [rsp], xmm15
0000710e9ebdd971  movaps [rsp+0x10], xmm11
0000710e9ebdd977  movaps [rsp+0x20], xmm6
0000710e9ebdd97c  lea rdi, [rsp]
0000710e9ebdd980  mov esi, 0x00
0000710e9ebdd985  mov rax, 0x5DADAF7CF530
0000710e9ebdd98f  call rax
0000710e9ebdd991  movaps xmm15, [rsp]
0000710e9ebdd996  add rsp, 0x30
0000710e9ebdd99a  vmovaps xmm0, [rsp]
0000710e9ebdd99f  vmovaps xmm1, [rsp+0x10]
0000710e9ebdd9a5  vmovaps xmm2, [rsp+0x20]
0000710e9ebdd9ab  vmovaps xmm3, [rsp+0x30]
0000710e9ebdd9b1  vmovaps xmm4, [rsp+0x40]
0000710e9ebdd9b7  vmovaps xmm5, [rsp+0x50]
0000710e9ebdd9bd  vmovaps xmm6, [rsp+0x60]
0000710e9ebdd9c3  vmovaps xmm7, [rsp+0x70]
0000710e9ebdd9c9  vmovaps xmm8, [rsp+0x80]
0000710e9ebdd9d2  vmovaps xmm9, [rsp+0x90]
0000710e9ebdd9db  vmovaps xmm10, [rsp+0xA0]
0000710e9ebdd9e4  vmovaps xmm11, [rsp+0xB0]
0000710e9ebdd9ed  vmovaps xmm12, [rsp+0xC0]
0000710e9ebdd9f6  vmovaps xmm13, [rsp+0xD0]
0000710e9ebdd9ff  vmovaps xmm14, [rsp+0xE0]
0000710e9ebdda08  add rsp, 0xF0
0000710e9ebdda0f  pop r11
0000710e9ebdda11  pop r10
0000710e9ebdda13  pop r9
0000710e9ebdda15  pop r8
0000710e9ebdda17  pop rsi
0000710e9ebdda18  pop rdi
0000710e9ebdda19  pop rdx
0000710e9ebdda1a  pop rcx
0000710e9ebdda1b  pop rax
0000710e9ebdda1c  add rsp, 0x08
0000710e9ebdda20  jmp 0x0000710E9EBD9685
0000710e9ebdda25  sub rsp, 0x08
0000710e9ebdda29  push rax
0000710e9ebdda2a  push rcx
0000710e9ebdda2b  push rdx
0000710e9ebdda2c  push rdi
0000710e9ebdda2d  push rsi
0000710e9ebdda2e  push r8
0000710e9ebdda30  push r9
0000710e9ebdda32  push r10
0000710e9ebdda34  push r11
0000710e9ebdda36  sub rsp, 0xF0
0000710e9ebdda3d  vmovaps [rsp], xmm0
0000710e9ebdda42  vmovaps [rsp+0x10], xmm1
0000710e9ebdda48  vmovaps [rsp+0x20], xmm2
0000710e9ebdda4e  vmovaps [rsp+0x30], xmm3
0000710e9ebdda54  vmovaps [rsp+0x40], xmm4
0000710e9ebdda5a  vmovaps [rsp+0x50], xmm5
0000710e9ebdda60  vmovaps [rsp+0x60], xmm6
0000710e9ebdda66  vmovaps [rsp+0x70], xmm8
0000710e9ebdda6c  vmovaps [rsp+0x80], xmm9
0000710e9ebdda75  vmovaps [rsp+0x90], xmm10
0000710e9ebdda7e  vmovaps [rsp+0xA0], xmm11
0000710e9ebdda87  vmovaps [rsp+0xB0], xmm12
0000710e9ebdda90  vmovaps [rsp+0xC0], xmm13
0000710e9ebdda99  vmovaps [rsp+0xD0], xmm14
0000710e9ebddaa2  vmovaps [rsp+0xE0], xmm15
0000710e9ebddaab  sub rsp, 0x30
0000710e9ebddaaf  movaps [rsp], xmm7
0000710e9ebddab3  movaps [rsp+0x10], xmm11
0000710e9ebddab9  movaps [rsp+0x20], xmm9
0000710e9ebddabf  lea rdi, [rsp]
0000710e9ebddac3  mov esi, 0x00
0000710e9ebddac8  mov rax, 0x5DADAF7CF530
0000710e9ebddad2  call rax
0000710e9ebddad4  movaps xmm7, [rsp]
0000710e9ebddad8  add rsp, 0x30
0000710e9ebddadc  vmovaps xmm0, [rsp]
0000710e9ebddae1  vmovaps xmm1, [rsp+0x10]
0000710e9ebddae7  vmovaps xmm2, [rsp+0x20]
0000710e9ebddaed  vmovaps xmm3, [rsp+0x30]
0000710e9ebddaf3  vmovaps xmm4, [rsp+0x40]
0000710e9ebddaf9  vmovaps xmm5, [rsp+0x50]
0000710e9ebddaff  vmovaps xmm6, [rsp+0x60]
0000710e9ebddb05  vmovaps xmm8, [rsp+0x70]
0000710e9ebddb0b  vmovaps xmm9, [rsp+0x80]
0000710e9ebddb14  vmovaps xmm10, [rsp+0x90]
0000710e9ebddb1d  vmovaps xmm11, [rsp+0xA0]
0000710e9ebddb26  vmovaps xmm12, [rsp+0xB0]
0000710e9ebddb2f  vmovaps xmm13, [rsp+0xC0]
0000710e9ebddb38  vmovaps xmm14, [rsp+0xD0]
0000710e9ebddb41  vmovaps xmm15, [rsp+0xE0]
0000710e9ebddb4a  add rsp, 0xF0
0000710e9ebddb51  pop r11
0000710e9ebddb53  pop r10
0000710e9ebddb55  pop r9
0000710e9ebddb57  pop r8
0000710e9ebddb59  pop rsi
0000710e9ebddb5a  pop rdi
0000710e9ebddb5b  pop rdx
0000710e9ebddb5c  pop rcx
0000710e9ebddb5d  pop rax
0000710e9ebddb5e  add rsp, 0x08
0000710e9ebddb62  jmp 0x0000710E9EBD96B2
0000710e9ebddb67  sub rsp, 0x08
0000710e9ebddb6b  push rax
0000710e9ebddb6c  push rcx
0000710e9ebddb6d  push rdx
0000710e9ebddb6e  push rdi
0000710e9ebddb6f  push rsi
0000710e9ebddb70  push r8
0000710e9ebddb72  push r9
0000710e9ebddb74  push r10
0000710e9ebddb76  push r11
0000710e9ebddb78  sub rsp, 0xF0
0000710e9ebddb7f  vmovaps [rsp], xmm0
0000710e9ebddb84  vmovaps [rsp+0x10], xmm1
0000710e9ebddb8a  vmovaps [rsp+0x20], xmm2
0000710e9ebddb90  vmovaps [rsp+0x30], xmm3
0000710e9ebddb96  vmovaps [rsp+0x40], xmm4
0000710e9ebddb9c  vmovaps [rsp+0x50], xmm5
0000710e9ebddba2  vmovaps [rsp+0x60], xmm6
0000710e9ebddba8  vmovaps [rsp+0x70], xmm7
0000710e9ebddbae  vmovaps [rsp+0x80], xmm8
0000710e9ebddbb7  vmovaps [rsp+0x90], xmm9
0000710e9ebddbc0  vmovaps [rsp+0xA0], xmm10
0000710e9ebddbc9  vmovaps [rsp+0xB0], xmm12
0000710e9ebddbd2  vmovaps [rsp+0xC0], xmm13
0000710e9ebddbdb  vmovaps [rsp+0xD0], xmm14
0000710e9ebddbe4  vmovaps [rsp+0xE0], xmm15
0000710e9ebddbed  sub rsp, 0x30
0000710e9ebddbf1  movaps [rsp], xmm11
0000710e9ebddbf6  movaps [rsp+0x10], xmm10
0000710e9ebddbfc  movaps [rsp+0x20], xmm14
0000710e9ebddc02  lea rdi, [rsp]
0000710e9ebddc06  mov esi, 0x00
0000710e9ebddc0b  mov rax, 0x5DADAF7CF530
0000710e9ebddc15  call rax
0000710e9ebddc17  movaps xmm11, [rsp]
0000710e9ebddc1c  add rsp, 0x30
0000710e9ebddc20  vmovaps xmm0, [rsp]
0000710e9ebddc25  vmovaps xmm1, [rsp+0x10]
0000710e9ebddc2b  vmovaps xmm2, [rsp+0x20]
0000710e9ebddc31  vmovaps xmm3, [rsp+0x30]
0000710e9ebddc37  vmovaps xmm4, [rsp+0x40]
0000710e9ebddc3d  vmovaps xmm5, [rsp+0x50]
0000710e9ebddc43  vmovaps xmm6, [rsp+0x60]
0000710e9ebddc49  vmovaps xmm7, [rsp+0x70]
0000710e9ebddc4f  vmovaps xmm8, [rsp+0x80]
0000710e9ebddc58  vmovaps xmm9, [rsp+0x90]
0000710e9ebddc61  vmovaps xmm10, [rsp+0xA0]
0000710e9ebddc6a  vmovaps xmm12, [rsp+0xB0]
0000710e9ebddc73  vmovaps xmm13, [rsp+0xC0]
0000710e9ebddc7c  vmovaps xmm14, [rsp+0xD0]
0000710e9ebddc85  vmovaps xmm15, [rsp+0xE0]
0000710e9ebddc8e  add rsp, 0xF0
0000710e9ebddc95  pop r11
0000710e9ebddc97  pop r10
0000710e9ebddc99  pop r9
0000710e9ebddc9b  pop r8
0000710e9ebddc9d  pop rsi
0000710e9ebddc9e  pop rdi
0000710e9ebddc9f  pop rdx
0000710e9ebddca0  pop rcx
0000710e9ebddca1  pop rax
0000710e9ebddca2  add rsp, 0x08
0000710e9ebddca6  jmp 0x0000710E9EBD96CD
0000710e9ebddcab  call 0x0000710E9EAE45A0
0000710e9ebddcb0  jmp 0x0000710E9EBD96D7
0000710e9ebddcb5  sub rsp, 0x08
0000710e9ebddcb9  push rax
0000710e9ebddcba  push rcx
0000710e9ebddcbb  push rdx
0000710e9ebddcbc  push rdi
0000710e9ebddcbd  push rsi
0000710e9ebddcbe  push r8
0000710e9ebddcc0  push r9
0000710e9ebddcc2  push r10
0000710e9ebddcc4  push r11
0000710e9ebddcc6  sub rsp, 0xF0
0000710e9ebddccd  vmovaps [rsp], xmm0
0000710e9ebddcd2  vmovaps [rsp+0x10], xmm1
0000710e9ebddcd8  vmovaps [rsp+0x20], xmm2
0000710e9ebddcde  vmovaps [rsp+0x30], xmm3
0000710e9ebddce4  vmovaps [rsp+0x40], xmm4
0000710e9ebddcea  vmovaps [rsp+0x50], xmm5
0000710e9ebddcf0  vmovaps [rsp+0x60], xmm6
0000710e9ebddcf6  vmovaps [rsp+0x70], xmm7
0000710e9ebddcfc  vmovaps [rsp+0x80], xmm8
0000710e9ebddd05  vmovaps [rsp+0x90], xmm9
0000710e9ebddd0e  vmovaps [rsp+0xA0], xmm11
0000710e9ebddd17  vmovaps [rsp+0xB0], xmm12
0000710e9ebddd20  vmovaps [rsp+0xC0], xmm13
0000710e9ebddd29  vmovaps [rsp+0xD0], xmm14
0000710e9ebddd32  vmovaps [rsp+0xE0], xmm15
0000710e9ebddd3b  sub rsp, 0x30
0000710e9ebddd3f  movaps [rsp], xmm10
0000710e9ebddd44  movaps [rsp+0x10], xmm1
0000710e9ebddd49  movaps [rsp+0x20], xmm12
0000710e9ebddd4f  lea rdi, [rsp]
0000710e9ebddd53  mov esi, 0x00
0000710e9ebddd58  mov rax, 0x5DADAF7CF530
0000710e9ebddd62  call rax
0000710e9ebddd64  movaps xmm10, [rsp]
0000710e9ebddd69  add rsp, 0x30
0000710e9ebddd6d  vmovaps xmm0, [rsp]
0000710e9ebddd72  vmovaps xmm1, [rsp+0x10]
0000710e9ebddd78  vmovaps xmm2, [rsp+0x20]
0000710e9ebddd7e  vmovaps xmm3, [rsp+0x30]
0000710e9ebddd84  vmovaps xmm4, [rsp+0x40]
0000710e9ebddd8a  vmovaps xmm5, [rsp+0x50]
0000710e9ebddd90  vmovaps xmm6, [rsp+0x60]
0000710e9ebddd96  vmovaps xmm7, [rsp+0x70]
0000710e9ebddd9c  vmovaps xmm8, [rsp+0x80]
0000710e9ebddda5  vmovaps xmm9, [rsp+0x90]
0000710e9ebdddae  vmovaps xmm11, [rsp+0xA0]
0000710e9ebdddb7  vmovaps xmm12, [rsp+0xB0]
0000710e9ebdddc0  vmovaps xmm13, [rsp+0xC0]
0000710e9ebdddc9  vmovaps xmm14, [rsp+0xD0]
0000710e9ebdddd2  vmovaps xmm15, [rsp+0xE0]
0000710e9ebddddb  add rsp, 0xF0
0000710e9ebddde2  pop r11
0000710e9ebddde4  pop r10
0000710e9ebddde6  pop r9
0000710e9ebddde8  pop r8
0000710e9ebdddea  pop rsi
0000710e9ebdddeb  pop rdi
0000710e9ebdddec  pop rdx
0000710e9ebddded  pop rcx
0000710e9ebdddee  pop rax
0000710e9ebdddef  add rsp, 0x08
0000710e9ebdddf3  jmp 0x0000710E9EBD96FA
0000710e9ebdddf8  sub rsp, 0x08
0000710e9ebdddfc  push rax
0000710e9ebdddfd  push rcx
0000710e9ebdddfe  push rdx
0000710e9ebdddff  push rdi
0000710e9ebdde00  push rsi
0000710e9ebdde01  push r8
0000710e9ebdde03  push r9
0000710e9ebdde05  push r10
0000710e9ebdde07  push r11
0000710e9ebdde09  sub rsp, 0xF0
0000710e9ebdde10  vmovaps [rsp], xmm0
0000710e9ebdde15  vmovaps [rsp+0x10], xmm1
0000710e9ebdde1b  vmovaps [rsp+0x20], xmm2
0000710e9ebdde21  vmovaps [rsp+0x30], xmm3
0000710e9ebdde27  vmovaps [rsp+0x40], xmm4
0000710e9ebdde2d  vmovaps [rsp+0x50], xmm5
0000710e9ebdde33  vmovaps [rsp+0x60], xmm6
0000710e9ebdde39  vmovaps [rsp+0x70], xmm7
0000710e9ebdde3f  vmovaps [rsp+0x80], xmm8
0000710e9ebdde48  vmovaps [rsp+0x90], xmm9
0000710e9ebdde51  vmovaps [rsp+0xA0], xmm10
0000710e9ebdde5a  vmovaps [rsp+0xB0], xmm11
0000710e9ebdde63  vmovaps [rsp+0xC0], xmm13
0000710e9ebdde6c  vmovaps [rsp+0xD0], xmm14
0000710e9ebdde75  vmovaps [rsp+0xE0], xmm15
0000710e9ebdde7e  sub rsp, 0x30
0000710e9ebdde82  movaps [rsp], xmm12
0000710e9ebdde87  movaps [rsp+0x10], xmm14
0000710e9ebdde8d  movaps [rsp+0x20], xmm1
0000710e9ebdde92  lea rdi, [rsp]
0000710e9ebdde96  mov esi, 0x00
0000710e9ebdde9b  mov rax, 0x5DADAF7CF530
0000710e9ebddea5  call rax
0000710e9ebddea7  movaps xmm12, [rsp]
0000710e9ebddeac  add rsp, 0x30
0000710e9ebddeb0  vmovaps xmm0, [rsp]
0000710e9ebddeb5  vmovaps xmm1, [rsp+0x10]
0000710e9ebddebb  vmovaps xmm2, [rsp+0x20]
0000710e9ebddec1  vmovaps xmm3, [rsp+0x30]
0000710e9ebddec7  vmovaps xmm4, [rsp+0x40]
0000710e9ebddecd  vmovaps xmm5, [rsp+0x50]
0000710e9ebdded3  vmovaps xmm6, [rsp+0x60]
0000710e9ebdded9  vmovaps xmm7, [rsp+0x70]
0000710e9ebddedf  vmovaps xmm8, [rsp+0x80]
0000710e9ebddee8  vmovaps xmm9, [rsp+0x90]
0000710e9ebddef1  vmovaps xmm10, [rsp+0xA0]
0000710e9ebddefa  vmovaps xmm11, [rsp+0xB0]
0000710e9ebddf03  vmovaps xmm13, [rsp+0xC0]
0000710e9ebddf0c  vmovaps xmm14, [rsp+0xD0]
0000710e9ebddf15  vmovaps xmm15, [rsp+0xE0]
0000710e9ebddf1e  add rsp, 0xF0
0000710e9ebddf25  pop r11
0000710e9ebddf27  pop r10
0000710e9ebddf29  pop r9
0000710e9ebddf2b  pop r8
0000710e9ebddf2d  pop rsi
0000710e9ebddf2e  pop rdi
0000710e9ebddf2f  pop rdx
0000710e9ebddf30  pop rcx
0000710e9ebddf31  pop rax
0000710e9ebddf32  add rsp, 0x08
0000710e9ebddf36  jmp 0x0000710E9EBD9729
0000710e9ebddf3b  sub rsp, 0x08
0000710e9ebddf3f  push rax
0000710e9ebddf40  push rcx
0000710e9ebddf41  push rdx
0000710e9ebddf42  push rdi
0000710e9ebddf43  push rsi
0000710e9ebddf44  push r8
0000710e9ebddf46  push r9
0000710e9ebddf48  push r10
0000710e9ebddf4a  push r11
0000710e9ebddf4c  sub rsp, 0xF0
0000710e9ebddf53  vmovaps [rsp], xmm0
0000710e9ebddf58  vmovaps [rsp+0x10], xmm1
0000710e9ebddf5e  vmovaps [rsp+0x20], xmm2
0000710e9ebddf64  vmovaps [rsp+0x30], xmm3
0000710e9ebddf6a  vmovaps [rsp+0x40], xmm4
0000710e9ebddf70  vmovaps [rsp+0x50], xmm5
0000710e9ebddf76  vmovaps [rsp+0x60], xmm6
0000710e9ebddf7c  vmovaps [rsp+0x70], xmm7
0000710e9ebddf82  vmovaps [rsp+0x80], xmm8
0000710e9ebddf8b  vmovaps [rsp+0x90], xmm9
0000710e9ebddf94  vmovaps [rsp+0xA0], xmm10
0000710e9ebddf9d  vmovaps [rsp+0xB0], xmm11
0000710e9ebddfa6  vmovaps [rsp+0xC0], xmm12
0000710e9ebddfaf  vmovaps [rsp+0xD0], xmm13
0000710e9ebddfb8  vmovaps [rsp+0xE0], xmm15
0000710e9ebddfc1  sub rsp, 0x30
0000710e9ebddfc5  movaps [rsp], xmm14
0000710e9ebddfca  movaps [rsp+0x10], xmm9
0000710e9ebddfd0  movaps [rsp+0x20], xmm1
0000710e9ebddfd5  lea rdi, [rsp]
0000710e9ebddfd9  mov esi, 0x00
0000710e9ebddfde  mov rax, 0x5DADAF7CF530
0000710e9ebddfe8  call rax
0000710e9ebddfea  movaps xmm14, [rsp]
0000710e9ebddfef  add rsp, 0x30
0000710e9ebddff3  vmovaps xmm0, [rsp]
0000710e9ebddff8  vmovaps xmm1, [rsp+0x10]
0000710e9ebddffe  vmovaps xmm2, [rsp+0x20]
0000710e9ebde004  vmovaps xmm3, [rsp+0x30]
0000710e9ebde00a  vmovaps xmm4, [rsp+0x40]
0000710e9ebde010  vmovaps xmm5, [rsp+0x50]
0000710e9ebde016  vmovaps xmm6, [rsp+0x60]
0000710e9ebde01c  vmovaps xmm7, [rsp+0x70]
0000710e9ebde022  vmovaps xmm8, [rsp+0x80]
0000710e9ebde02b  vmovaps xmm9, [rsp+0x90]
0000710e9ebde034  vmovaps xmm10, [rsp+0xA0]
0000710e9ebde03d  vmovaps xmm11, [rsp+0xB0]
0000710e9ebde046  vmovaps xmm12, [rsp+0xC0]
0000710e9ebde04f  vmovaps xmm13, [rsp+0xD0]
0000710e9ebde058  vmovaps xmm15, [rsp+0xE0]
0000710e9ebde061  add rsp, 0xF0
0000710e9ebde068  pop r11
0000710e9ebde06a  pop r10
0000710e9ebde06c  pop r9
0000710e9ebde06e  pop r8
0000710e9ebde070  pop rsi
0000710e9ebde071  pop rdi
0000710e9ebde072  pop rdx
0000710e9ebde073  pop rcx
0000710e9ebde074  pop rax
0000710e9ebde075  add rsp, 0x08
0000710e9ebde079  jmp 0x0000710E9EBD9758
0000710e9ebde07e  sub rsp, 0x08
0000710e9ebde082  push rax
0000710e9ebde083  push rcx
0000710e9ebde084  push rdx
0000710e9ebde085  push rdi
0000710e9ebde086  push rsi
0000710e9ebde087  push r8
0000710e9ebde089  push r9
0000710e9ebde08b  push r10
0000710e9ebde08d  push r11
0000710e9ebde08f  sub rsp, 0xF0
0000710e9ebde096  vmovaps [rsp], xmm0
0000710e9ebde09b  vmovaps [rsp+0x10], xmm2
0000710e9ebde0a1  vmovaps [rsp+0x20], xmm3
0000710e9ebde0a7  vmovaps [rsp+0x30], xmm4
0000710e9ebde0ad  vmovaps [rsp+0x40], xmm5
0000710e9ebde0b3  vmovaps [rsp+0x50], xmm6
0000710e9ebde0b9  vmovaps [rsp+0x60], xmm7
0000710e9ebde0bf  vmovaps [rsp+0x70], xmm8
0000710e9ebde0c5  vmovaps [rsp+0x80], xmm9
0000710e9ebde0ce  vmovaps [rsp+0x90], xmm10
0000710e9ebde0d7  vmovaps [rsp+0xA0], xmm11
0000710e9ebde0e0  vmovaps [rsp+0xB0], xmm12
0000710e9ebde0e9  vmovaps [rsp+0xC0], xmm13
0000710e9ebde0f2  vmovaps [rsp+0xD0], xmm14
0000710e9ebde0fb  vmovaps [rsp+0xE0], xmm15
0000710e9ebde104  sub rsp, 0x30
0000710e9ebde108  movaps [rsp], xmm1
0000710e9ebde10c  movaps [rsp+0x10], xmm13
0000710e9ebde112  movaps [rsp+0x20], xmm8
0000710e9ebde118  lea rdi, [rsp]
0000710e9ebde11c  mov esi, 0x00
0000710e9ebde121  mov rax, 0x5DADAF7CF530
0000710e9ebde12b  call rax
0000710e9ebde12d  movaps xmm1, [rsp]
0000710e9ebde131  add rsp, 0x30
0000710e9ebde135  vmovaps xmm0, [rsp]
0000710e9ebde13a  vmovaps xmm2, [rsp+0x10]
0000710e9ebde140  vmovaps xmm3, [rsp+0x20]
0000710e9ebde146  vmovaps xmm4, [rsp+0x30]
0000710e9ebde14c  vmovaps xmm5, [rsp+0x40]
0000710e9ebde152  vmovaps xmm6, [rsp+0x50]
0000710e9ebde158  vmovaps xmm7, [rsp+0x60]
0000710e9ebde15e  vmovaps xmm8, [rsp+0x70]
0000710e9ebde164  vmovaps xmm9, [rsp+0x80]
0000710e9ebde16d  vmovaps xmm10, [rsp+0x90]
0000710e9ebde176  vmovaps xmm11, [rsp+0xA0]
0000710e9ebde17f  vmovaps xmm12, [rsp+0xB0]
0000710e9ebde188  vmovaps xmm13, [rsp+0xC0]
0000710e9ebde191  vmovaps xmm14, [rsp+0xD0]
0000710e9ebde19a  vmovaps xmm15, [rsp+0xE0]
0000710e9ebde1a3  add rsp, 0xF0
0000710e9ebde1aa  pop r11
0000710e9ebde1ac  pop r10
0000710e9ebde1ae  pop r9
0000710e9ebde1b0  pop r8
0000710e9ebde1b2  pop rsi
0000710e9ebde1b3  pop rdi
0000710e9ebde1b4  pop rdx
0000710e9ebde1b5  pop rcx
0000710e9ebde1b6  pop rax
0000710e9ebde1b7  add rsp, 0x08
0000710e9ebde1bb  jmp 0x0000710E9EBD977A
0000710e9ebde1c0  call 0x0000710E9EA0C260
0000710e9ebde1c5  jmp 0x0000710E9EBD9788
0000710e9ebde1ca  call 0x0000710E9EADE950
0000710e9ebde1cf  jmp 0x0000710E9EBD9792
0000710e9ebde1d4  sub rsp, 0x08
0000710e9ebde1d8  push rax
0000710e9ebde1d9  push rcx
0000710e9ebde1da  push rdx
0000710e9ebde1db  push rdi
0000710e9ebde1dc  push rsi
0000710e9ebde1dd  push r8
0000710e9ebde1df  push r9
0000710e9ebde1e1  push r10
0000710e9ebde1e3  push r11
0000710e9ebde1e5  sub rsp, 0xF0
0000710e9ebde1ec  vmovaps [rsp], xmm0
0000710e9ebde1f1  vmovaps [rsp+0x10], xmm1
0000710e9ebde1f7  vmovaps [rsp+0x20], xmm2
0000710e9ebde1fd  vmovaps [rsp+0x30], xmm3
0000710e9ebde203  vmovaps [rsp+0x40], xmm4
0000710e9ebde209  vmovaps [rsp+0x50], xmm5
0000710e9ebde20f  vmovaps [rsp+0x60], xmm6
0000710e9ebde215  vmovaps [rsp+0x70], xmm7
0000710e9ebde21b  vmovaps [rsp+0x80], xmm9
0000710e9ebde224  vmovaps [rsp+0x90], xmm10
0000710e9ebde22d  vmovaps [rsp+0xA0], xmm11
0000710e9ebde236  vmovaps [rsp+0xB0], xmm12
0000710e9ebde23f  vmovaps [rsp+0xC0], xmm13
0000710e9ebde248  vmovaps [rsp+0xD0], xmm14
0000710e9ebde251  vmovaps [rsp+0xE0], xmm15
0000710e9ebde25a  sub rsp, 0x30
0000710e9ebde25e  movaps [rsp], xmm8
0000710e9ebde263  movaps [rsp+0x10], xmm15
0000710e9ebde269  movaps [rsp+0x20], xmm7
0000710e9ebde26e  lea rdi, [rsp]
0000710e9ebde272  mov esi, 0x00
0000710e9ebde277  mov rax, 0x5DADAF7CF530
0000710e9ebde281  call rax
0000710e9ebde283  movaps xmm8, [rsp]
0000710e9ebde288  add rsp, 0x30
0000710e9ebde28c  vmovaps xmm0, [rsp]
0000710e9ebde291  vmovaps xmm1, [rsp+0x10]
0000710e9ebde297  vmovaps xmm2, [rsp+0x20]
0000710e9ebde29d  vmovaps xmm3, [rsp+0x30]
0000710e9ebde2a3  vmovaps xmm4, [rsp+0x40]
0000710e9ebde2a9  vmovaps xmm5, [rsp+0x50]
0000710e9ebde2af  vmovaps xmm6, [rsp+0x60]
0000710e9ebde2b5  vmovaps xmm7, [rsp+0x70]
0000710e9ebde2bb  vmovaps xmm9, [rsp+0x80]
0000710e9ebde2c4  vmovaps xmm10, [rsp+0x90]
0000710e9ebde2cd  vmovaps xmm11, [rsp+0xA0]
0000710e9ebde2d6  vmovaps xmm12, [rsp+0xB0]
0000710e9ebde2df  vmovaps xmm13, [rsp+0xC0]
0000710e9ebde2e8  vmovaps xmm14, [rsp+0xD0]
0000710e9ebde2f1  vmovaps xmm15, [rsp+0xE0]
0000710e9ebde2fa  add rsp, 0xF0
0000710e9ebde301  pop r11
0000710e9ebde303  pop r10
0000710e9ebde305  pop r9
0000710e9ebde307  pop r8
0000710e9ebde309  pop rsi
0000710e9ebde30a  pop rdi
0000710e9ebde30b  pop rdx
0000710e9ebde30c  pop rcx
0000710e9ebde30d  pop rax
0000710e9ebde30e  add rsp, 0x08
0000710e9ebde312  jmp 0x0000710E9EBD97B4
0000710e9ebde317  sub rsp, 0x08
0000710e9ebde31b  push rax
0000710e9ebde31c  push rcx
0000710e9ebde31d  push rdx
0000710e9ebde31e  push rdi
0000710e9ebde31f  push rsi
0000710e9ebde320  push r8
0000710e9ebde322  push r9
0000710e9ebde324  push r10
0000710e9ebde326  push r11
0000710e9ebde328  sub rsp, 0xF0
0000710e9ebde32f  vmovaps [rsp], xmm0
0000710e9ebde334  vmovaps [rsp+0x10], xmm1
0000710e9ebde33a  vmovaps [rsp+0x20], xmm2
0000710e9ebde340  vmovaps [rsp+0x30], xmm3
0000710e9ebde346  vmovaps [rsp+0x40], xmm4
0000710e9ebde34c  vmovaps [rsp+0x50], xmm5
0000710e9ebde352  vmovaps [rsp+0x60], xmm6
0000710e9ebde358  vmovaps [rsp+0x70], xmm8
0000710e9ebde35e  vmovaps [rsp+0x80], xmm9
0000710e9ebde367  vmovaps [rsp+0x90], xmm10
0000710e9ebde370  vmovaps [rsp+0xA0], xmm11
0000710e9ebde379  vmovaps [rsp+0xB0], xmm12
0000710e9ebde382  vmovaps [rsp+0xC0], xmm13
0000710e9ebde38b  vmovaps [rsp+0xD0], xmm14
0000710e9ebde394  vmovaps [rsp+0xE0], xmm15
0000710e9ebde39d  sub rsp, 0x30
0000710e9ebde3a1  movaps [rsp], xmm7
0000710e9ebde3a5  movaps [rsp+0x10], xmm9
0000710e9ebde3ab  movaps [rsp+0x20], xmm15
0000710e9ebde3b1  lea rdi, [rsp]
0000710e9ebde3b5  mov esi, 0x00
0000710e9ebde3ba  mov rax, 0x5DADAF7CF530
0000710e9ebde3c4  call rax
0000710e9ebde3c6  movaps xmm7, [rsp]
0000710e9ebde3ca  add rsp, 0x30
0000710e9ebde3ce  vmovaps xmm0, [rsp]
0000710e9ebde3d3  vmovaps xmm1, [rsp+0x10]
0000710e9ebde3d9  vmovaps xmm2, [rsp+0x20]
0000710e9ebde3df  vmovaps xmm3, [rsp+0x30]
0000710e9ebde3e5  vmovaps xmm4, [rsp+0x40]
0000710e9ebde3eb  vmovaps xmm5, [rsp+0x50]
0000710e9ebde3f1  vmovaps xmm6, [rsp+0x60]
0000710e9ebde3f7  vmovaps xmm8, [rsp+0x70]
0000710e9ebde3fd  vmovaps xmm9, [rsp+0x80]
0000710e9ebde406  vmovaps xmm10, [rsp+0x90]
0000710e9ebde40f  vmovaps xmm11, [rsp+0xA0]
0000710e9ebde418  vmovaps xmm12, [rsp+0xB0]
0000710e9ebde421  vmovaps xmm13, [rsp+0xC0]
0000710e9ebde42a  vmovaps xmm14, [rsp+0xD0]
0000710e9ebde433  vmovaps xmm15, [rsp+0xE0]
0000710e9ebde43c  add rsp, 0xF0
0000710e9ebde443  pop r11
0000710e9ebde445  pop r10
0000710e9ebde447  pop r9
0000710e9ebde449  pop r8
0000710e9ebde44b  pop rsi
0000710e9ebde44c  pop rdi
0000710e9ebde44d  pop rdx
0000710e9ebde44e  pop rcx
0000710e9ebde44f  pop rax
0000710e9ebde450  add rsp, 0x08
0000710e9ebde454  jmp 0x0000710E9EBD97E1
0000710e9ebde459  sub rsp, 0x08
0000710e9ebde45d  push rax
0000710e9ebde45e  push rcx
0000710e9ebde45f  push rdx
0000710e9ebde460  push rdi
0000710e9ebde461  push rsi
0000710e9ebde462  push r8
0000710e9ebde464  push r9
0000710e9ebde466  push r10
0000710e9ebde468  push r11
0000710e9ebde46a  sub rsp, 0xF0
0000710e9ebde471  vmovaps [rsp], xmm0
0000710e9ebde476  vmovaps [rsp+0x10], xmm1
0000710e9ebde47c  vmovaps [rsp+0x20], xmm2
0000710e9ebde482  vmovaps [rsp+0x30], xmm3
0000710e9ebde488  vmovaps [rsp+0x40], xmm4
0000710e9ebde48e  vmovaps [rsp+0x50], xmm5
0000710e9ebde494  vmovaps [rsp+0x60], xmm6
0000710e9ebde49a  vmovaps [rsp+0x70], xmm7
0000710e9ebde4a0  vmovaps [rsp+0x80], xmm8
0000710e9ebde4a9  vmovaps [rsp+0x90], xmm10
0000710e9ebde4b2  vmovaps [rsp+0xA0], xmm11
0000710e9ebde4bb  vmovaps [rsp+0xB0], xmm12
0000710e9ebde4c4  vmovaps [rsp+0xC0], xmm13
0000710e9ebde4cd  vmovaps [rsp+0xD0], xmm14
0000710e9ebde4d6  vmovaps [rsp+0xE0], xmm15
0000710e9ebde4df  sub rsp, 0x30
0000710e9ebde4e3  movaps [rsp], xmm9
0000710e9ebde4e8  movaps [rsp+0x10], xmm13
0000710e9ebde4ee  movaps [rsp+0x20], xmm15
0000710e9ebde4f4  lea rdi, [rsp]
0000710e9ebde4f8  mov esi, 0x00
0000710e9ebde4fd  mov rax, 0x5DADAF7CF530
0000710e9ebde507  call rax
0000710e9ebde509  movaps xmm9, [rsp]
0000710e9ebde50e  add rsp, 0x30
0000710e9ebde512  vmovaps xmm0, [rsp]
0000710e9ebde517  vmovaps xmm1, [rsp+0x10]
0000710e9ebde51d  vmovaps xmm2, [rsp+0x20]
0000710e9ebde523  vmovaps xmm3, [rsp+0x30]
0000710e9ebde529  vmovaps xmm4, [rsp+0x40]
0000710e9ebde52f  vmovaps xmm5, [rsp+0x50]
0000710e9ebde535  vmovaps xmm6, [rsp+0x60]
0000710e9ebde53b  vmovaps xmm7, [rsp+0x70]
0000710e9ebde541  vmovaps xmm8, [rsp+0x80]
0000710e9ebde54a  vmovaps xmm10, [rsp+0x90]
0000710e9ebde553  vmovaps xmm11, [rsp+0xA0]
0000710e9ebde55c  vmovaps xmm12, [rsp+0xB0]
0000710e9ebde565  vmovaps xmm13, [rsp+0xC0]
0000710e9ebde56e  vmovaps xmm14, [rsp+0xD0]
0000710e9ebde577  vmovaps xmm15, [rsp+0xE0]
0000710e9ebde580  add rsp, 0xF0
0000710e9ebde587  pop r11
0000710e9ebde589  pop r10
0000710e9ebde58b  pop r9
0000710e9ebde58d  pop r8
0000710e9ebde58f  pop rsi
0000710e9ebde590  pop rdi
0000710e9ebde591  pop rdx
0000710e9ebde592  pop rcx
0000710e9ebde593  pop rax
0000710e9ebde594  add rsp, 0x08
0000710e9ebde598  jmp 0x0000710E9EBD980F
0000710e9ebde59d  sub rsp, 0x08
0000710e9ebde5a1  push rax
0000710e9ebde5a2  push rcx
0000710e9ebde5a3  push rdx
0000710e9ebde5a4  push rdi
0000710e9ebde5a5  push rsi
0000710e9ebde5a6  push r8
0000710e9ebde5a8  push r9
0000710e9ebde5aa  push r10
0000710e9ebde5ac  push r11
0000710e9ebde5ae  sub rsp, 0xF0
0000710e9ebde5b5  vmovaps [rsp], xmm0
0000710e9ebde5ba  vmovaps [rsp+0x10], xmm1
0000710e9ebde5c0  vmovaps [rsp+0x20], xmm2
0000710e9ebde5c6  vmovaps [rsp+0x30], xmm3
0000710e9ebde5cc  vmovaps [rsp+0x40], xmm4
0000710e9ebde5d2  vmovaps [rsp+0x50], xmm5
0000710e9ebde5d8  vmovaps [rsp+0x60], xmm6
0000710e9ebde5de  vmovaps [rsp+0x70], xmm7
0000710e9ebde5e4  vmovaps [rsp+0x80], xmm8
0000710e9ebde5ed  vmovaps [rsp+0x90], xmm9
0000710e9ebde5f6  vmovaps [rsp+0xA0], xmm10
0000710e9ebde5ff  vmovaps [rsp+0xB0], xmm11
0000710e9ebde608  vmovaps [rsp+0xC0], xmm12
0000710e9ebde611  vmovaps [rsp+0xD0], xmm13
0000710e9ebde61a  vmovaps [rsp+0xE0], xmm14
0000710e9ebde623  sub rsp, 0x30
0000710e9ebde627  movaps [rsp], xmm15
0000710e9ebde62c  movaps [rsp+0x10], xmm11
0000710e9ebde632  movaps [rsp+0x20], xmm12
0000710e9ebde638  lea rdi, [rsp]
0000710e9ebde63c  mov esi, 0x00
0000710e9ebde641  mov rax, 0x5DADAF7CF530
0000710e9ebde64b  call rax
0000710e9ebde64d  movaps xmm15, [rsp]
0000710e9ebde652  add rsp, 0x30
0000710e9ebde656  vmovaps xmm0, [rsp]
0000710e9ebde65b  vmovaps xmm1, [rsp+0x10]
0000710e9ebde661  vmovaps xmm2, [rsp+0x20]
0000710e9ebde667  vmovaps xmm3, [rsp+0x30]
0000710e9ebde66d  vmovaps xmm4, [rsp+0x40]
0000710e9ebde673  vmovaps xmm5, [rsp+0x50]
0000710e9ebde679  vmovaps xmm6, [rsp+0x60]
0000710e9ebde67f  vmovaps xmm7, [rsp+0x70]
0000710e9ebde685  vmovaps xmm8, [rsp+0x80]
0000710e9ebde68e  vmovaps xmm9, [rsp+0x90]
0000710e9ebde697  vmovaps xmm10, [rsp+0xA0]
0000710e9ebde6a0  vmovaps xmm11, [rsp+0xB0]
0000710e9ebde6a9  vmovaps xmm12, [rsp+0xC0]
0000710e9ebde6b2  vmovaps xmm13, [rsp+0xD0]
0000710e9ebde6bb  vmovaps xmm14, [rsp+0xE0]
0000710e9ebde6c4  add rsp, 0xF0
0000710e9ebde6cb  pop r11
0000710e9ebde6cd  pop r10
0000710e9ebde6cf  pop r9
0000710e9ebde6d1  pop r8
0000710e9ebde6d3  pop rsi
0000710e9ebde6d4  pop rdi
0000710e9ebde6d5  pop rdx
0000710e9ebde6d6  pop rcx
0000710e9ebde6d7  pop rax
0000710e9ebde6d8  add rsp, 0x08
0000710e9ebde6dc  jmp 0x0000710E9EBD982A
0000710e9ebde6e1  sub rsp, 0x08
0000710e9ebde6e5  push rax
0000710e9ebde6e6  push rcx
0000710e9ebde6e7  push rdx
0000710e9ebde6e8  push rdi
0000710e9ebde6e9  push rsi
0000710e9ebde6ea  push r8
0000710e9ebde6ec  push r9
0000710e9ebde6ee  push r10
0000710e9ebde6f0  push r11
0000710e9ebde6f2  sub rsp, 0xF0
0000710e9ebde6f9  vmovaps [rsp], xmm0
0000710e9ebde6fe  vmovaps [rsp+0x10], xmm1
0000710e9ebde704  vmovaps [rsp+0x20], xmm2
0000710e9ebde70a  vmovaps [rsp+0x30], xmm3
0000710e9ebde710  vmovaps [rsp+0x40], xmm4
0000710e9ebde716  vmovaps [rsp+0x50], xmm5
0000710e9ebde71c  vmovaps [rsp+0x60], xmm6
0000710e9ebde722  vmovaps [rsp+0x70], xmm7
0000710e9ebde728  vmovaps [rsp+0x80], xmm8
0000710e9ebde731  vmovaps [rsp+0x90], xmm9
0000710e9ebde73a  vmovaps [rsp+0xA0], xmm10
0000710e9ebde743  vmovaps [rsp+0xB0], xmm11
0000710e9ebde74c  vmovaps [rsp+0xC0], xmm12
0000710e9ebde755  vmovaps [rsp+0xD0], xmm14
0000710e9ebde75e  vmovaps [rsp+0xE0], xmm15
0000710e9ebde767  sub rsp, 0x30
0000710e9ebde76b  movaps [rsp], xmm13
0000710e9ebde770  movaps [rsp+0x10], xmm10
0000710e9ebde776  movaps [rsp+0x20], xmm14
0000710e9ebde77c  lea rdi, [rsp]
0000710e9ebde780  mov esi, 0x00
0000710e9ebde785  mov rax, 0x5DADAF7CF530
0000710e9ebde78f  call rax
0000710e9ebde791  movaps xmm13, [rsp]
0000710e9ebde796  add rsp, 0x30
0000710e9ebde79a  vmovaps xmm0, [rsp]
0000710e9ebde79f  vmovaps xmm1, [rsp+0x10]
0000710e9ebde7a5  vmovaps xmm2, [rsp+0x20]
0000710e9ebde7ab  vmovaps xmm3, [rsp+0x30]
0000710e9ebde7b1  vmovaps xmm4, [rsp+0x40]
0000710e9ebde7b7  vmovaps xmm5, [rsp+0x50]
0000710e9ebde7bd  vmovaps xmm6, [rsp+0x60]
0000710e9ebde7c3  vmovaps xmm7, [rsp+0x70]
0000710e9ebde7c9  vmovaps xmm8, [rsp+0x80]
0000710e9ebde7d2  vmovaps xmm9, [rsp+0x90]
0000710e9ebde7db  vmovaps xmm10, [rsp+0xA0]
0000710e9ebde7e4  vmovaps xmm11, [rsp+0xB0]
0000710e9ebde7ed  vmovaps xmm12, [rsp+0xC0]
0000710e9ebde7f6  vmovaps xmm14, [rsp+0xD0]
0000710e9ebde7ff  vmovaps xmm15, [rsp+0xE0]
0000710e9ebde808  add rsp, 0xF0
0000710e9ebde80f  pop r11
0000710e9ebde811  pop r10
0000710e9ebde813  pop r9
0000710e9ebde815  pop r8
0000710e9ebde817  pop rsi
0000710e9ebde818  pop rdi
0000710e9ebde819  pop rdx
0000710e9ebde81a  pop rcx
0000710e9ebde81b  pop rax
0000710e9ebde81c  add rsp, 0x08
0000710e9ebde820  jmp 0x0000710E9EBD984D
0000710e9ebde825  sub rsp, 0x08
0000710e9ebde829  push rax
0000710e9ebde82a  push rcx
0000710e9ebde82b  push rdx
0000710e9ebde82c  push rdi
0000710e9ebde82d  push rsi
0000710e9ebde82e  push r8
0000710e9ebde830  push r9
0000710e9ebde832  push r10
0000710e9ebde834  push r11
0000710e9ebde836  sub rsp, 0xF0
0000710e9ebde83d  vmovaps [rsp], xmm0
0000710e9ebde842  vmovaps [rsp+0x10], xmm1
0000710e9ebde848  vmovaps [rsp+0x20], xmm2
0000710e9ebde84e  vmovaps [rsp+0x30], xmm3
0000710e9ebde854  vmovaps [rsp+0x40], xmm4
0000710e9ebde85a  vmovaps [rsp+0x50], xmm5
0000710e9ebde860  vmovaps [rsp+0x60], xmm6
0000710e9ebde866  vmovaps [rsp+0x70], xmm7
0000710e9ebde86c  vmovaps [rsp+0x80], xmm8
0000710e9ebde875  vmovaps [rsp+0x90], xmm9
0000710e9ebde87e  vmovaps [rsp+0xA0], xmm10
0000710e9ebde887  vmovaps [rsp+0xB0], xmm11
0000710e9ebde890  vmovaps [rsp+0xC0], xmm12
0000710e9ebde899  vmovaps [rsp+0xD0], xmm13
0000710e9ebde8a2  vmovaps [rsp+0xE0], xmm15
0000710e9ebde8ab  sub rsp, 0x30
0000710e9ebde8af  movaps [rsp], xmm14
0000710e9ebde8b4  movaps [rsp+0x10], xmm1
0000710e9ebde8b9  movaps [rsp+0x20], xmm7
0000710e9ebde8be  lea rdi, [rsp]
0000710e9ebde8c2  mov esi, 0x00
0000710e9ebde8c7  mov rax, 0x5DADAF7CF530
0000710e9ebde8d1  call rax
0000710e9ebde8d3  movaps xmm14, [rsp]
0000710e9ebde8d8  add rsp, 0x30
0000710e9ebde8dc  vmovaps xmm0, [rsp]
0000710e9ebde8e1  vmovaps xmm1, [rsp+0x10]
0000710e9ebde8e7  vmovaps xmm2, [rsp+0x20]
0000710e9ebde8ed  vmovaps xmm3, [rsp+0x30]
0000710e9ebde8f3  vmovaps xmm4, [rsp+0x40]
0000710e9ebde8f9  vmovaps xmm5, [rsp+0x50]
0000710e9ebde8ff  vmovaps xmm6, [rsp+0x60]
0000710e9ebde905  vmovaps xmm7, [rsp+0x70]
0000710e9ebde90b  vmovaps xmm8, [rsp+0x80]
0000710e9ebde914  vmovaps xmm9, [rsp+0x90]
0000710e9ebde91d  vmovaps xmm10, [rsp+0xA0]
0000710e9ebde926  vmovaps xmm11, [rsp+0xB0]
0000710e9ebde92f  vmovaps xmm12, [rsp+0xC0]
0000710e9ebde938  vmovaps xmm13, [rsp+0xD0]
0000710e9ebde941  vmovaps xmm15, [rsp+0xE0]
0000710e9ebde94a  add rsp, 0xF0
0000710e9ebde951  pop r11
0000710e9ebde953  pop r10
0000710e9ebde955  pop r9
0000710e9ebde957  pop r8
0000710e9ebde959  pop rsi
0000710e9ebde95a  pop rdi
0000710e9ebde95b  pop rdx
0000710e9ebde95c  pop rcx
0000710e9ebde95d  pop rax
0000710e9ebde95e  add rsp, 0x08
0000710e9ebde962  jmp 0x0000710E9EBD9870
0000710e9ebde967  sub rsp, 0x08
0000710e9ebde96b  push rax
0000710e9ebde96c  push rcx
0000710e9ebde96d  push rdx
0000710e9ebde96e  push rdi
0000710e9ebde96f  push rsi
0000710e9ebde970  push r8
0000710e9ebde972  push r9
0000710e9ebde974  push r10
0000710e9ebde976  push r11
0000710e9ebde978  sub rsp, 0xF0
0000710e9ebde97f  vmovaps [rsp], xmm0
0000710e9ebde984  vmovaps [rsp+0x10], xmm2
0000710e9ebde98a  vmovaps [rsp+0x20], xmm3
0000710e9ebde990  vmovaps [rsp+0x30], xmm4
0000710e9ebde996  vmovaps [rsp+0x40], xmm5
0000710e9ebde99c  vmovaps [rsp+0x50], xmm6
0000710e9ebde9a2  vmovaps [rsp+0x60], xmm7
0000710e9ebde9a8  vmovaps [rsp+0x70], xmm8
0000710e9ebde9ae  vmovaps [rsp+0x80], xmm9
0000710e9ebde9b7  vmovaps [rsp+0x90], xmm10
0000710e9ebde9c0  vmovaps [rsp+0xA0], xmm11
0000710e9ebde9c9  vmovaps [rsp+0xB0], xmm12
0000710e9ebde9d2  vmovaps [rsp+0xC0], xmm13
0000710e9ebde9db  vmovaps [rsp+0xD0], xmm14
0000710e9ebde9e4  vmovaps [rsp+0xE0], xmm15
0000710e9ebde9ed  sub rsp, 0x30
0000710e9ebde9f1  movaps [rsp], xmm1
0000710e9ebde9f5  movaps [rsp+0x10], xmm8
0000710e9ebde9fb  movaps [rsp+0x20], xmm9
0000710e9ebdea01  lea rdi, [rsp]
0000710e9ebdea05  mov esi, 0x00
0000710e9ebdea0a  mov rax, 0x5DADAF7CF530
0000710e9ebdea14  call rax
0000710e9ebdea16  movaps xmm1, [rsp]
0000710e9ebdea1a  add rsp, 0x30
0000710e9ebdea1e  vmovaps xmm0, [rsp]
0000710e9ebdea23  vmovaps xmm2, [rsp+0x10]
0000710e9ebdea29  vmovaps xmm3, [rsp+0x20]
0000710e9ebdea2f  vmovaps xmm4, [rsp+0x30]
0000710e9ebdea35  vmovaps xmm5, [rsp+0x40]
0000710e9ebdea3b  vmovaps xmm6, [rsp+0x50]
0000710e9ebdea41  vmovaps xmm7, [rsp+0x60]
0000710e9ebdea47  vmovaps xmm8, [rsp+0x70]
0000710e9ebdea4d  vmovaps xmm9, [rsp+0x80]
0000710e9ebdea56  vmovaps xmm10, [rsp+0x90]
0000710e9ebdea5f  vmovaps xmm11, [rsp+0xA0]
0000710e9ebdea68  vmovaps xmm12, [rsp+0xB0]
0000710e9ebdea71  vmovaps xmm13, [rsp+0xC0]
0000710e9ebdea7a  vmovaps xmm14, [rsp+0xD0]
0000710e9ebdea83  vmovaps xmm15, [rsp+0xE0]
0000710e9ebdea8c  add rsp, 0xF0
0000710e9ebdea93  pop r11
0000710e9ebdea95  pop r10
0000710e9ebdea97  pop r9
0000710e9ebdea99  pop r8
0000710e9ebdea9b  pop rsi
0000710e9ebdea9c  pop rdi
0000710e9ebdea9d  pop rdx
0000710e9ebdea9e  pop rcx
0000710e9ebdea9f  pop rax
0000710e9ebdeaa0  add rsp, 0x08
0000710e9ebdeaa4  jmp 0x0000710E9EBD9892
0000710e9ebdeaa9  call 0x0000710E9EAB3E40
0000710e9ebdeaae  jmp 0x0000710E9EBD98A0
0000710e9ebdeab3  call 0x0000710E9EA0C380
0000710e9ebdeab8  jmp 0x0000710E9EBD98AA
0000710e9ebdeabd  call 0x0000710E9EA0D600
0000710e9ebdeac2  jmp 0x0000710E9EBD98B4
0000710e9ebdeac7  call 0x0000710E9E9FF540
0000710e9ebdeacc  jmp 0x0000710E9EBD98BE
0000710e9ebdead1  int3
0000710e9ebdead2  nop [rax+rax*1], ax
0000710e9ebdeadb  nop [rax+rax*1], eax
0000710e9ebdeae0  mov eax, [r15+0x48]
0000710e9ebdeae4  lea r14d, [eax+0x01]
0000710e9ebdeae9  mov [rsp+0x10], r14d
0000710e9ebdeaee  mov r14d, r14d
0000710e9ebdeaf1  mov [r15+0x48], r14
0000710e9ebdeaf5  xor eax, eax
0000710e9ebdeaf7  mov r14d, [rsp+0x10]
0000710e9ebdeafc  cmp r14d, 0x1F4
0000710e9ebdeb03  cmc
0000710e9ebdeb04  lahf
0000710e9ebdeb05  seto al
0000710e9ebdeb08  mov [r15+0x108], eax
0000710e9ebdeb0f  mov eax, [r15+0x108]
0000710e9ebdeb16  sahf
0000710e9ebdeb17  jnz 0x0000710E9EBDEB49
0000710e9ebdeb19  cmp dword ptr [r15+0x318], 0x00
0000710e9ebdeb21  jz 0x0000710E9EBE4C90
0000710e9ebdeb27  nop [rax+rax*1], ax
0000710e9ebdeb30  nop [rax+rax*1], eax
0000710e9ebdeb38  mov eax, 0x4106DC
0000710e9ebdeb3d  mov [r15+0x100], rax
0000710e9ebdeb44  jmp 0x0000710E9E9FE110
0000710e9ebdeb49  cmp dword ptr [r15+0x318], 0x00
0000710e9ebdeb51  jz 0x0000710E9EBDEB80
0000710e9ebdeb57  nop [rax+rax*1], ax
0000710e9ebdeb60  nop [rax+rax*1], eax
0000710e9ebdeb68  mov eax, 0x410500
0000710e9ebdeb6d  mov [r15+0x100], rax
0000710e9ebdeb74  jmp 0x0000710E9E9FE110
0000710e9ebdeb79  int3
0000710e9ebdeb7a  int3
0000710e9ebdeb7b  nop [rax+rax*1], eax
0000710e9ebdeb80  mov rax, [r15+0x40]
0000710e9ebdeb84  movaps xmm1, [r15+0x1D0]
0000710e9ebdeb8c  vmovaps [rsp+0x10], xmm1
0000710e9ebdeb92  vmovaps xmm15, [rsp+0x10]
0000710e9ebdeb98  por xmm1, xmm15
0000710e9ebdeb9d  movaps xmm14, [r15+0x1A0]
0000710e9ebdeba5  vmovaps [rsp+0x10], xmm14
0000710e9ebdebab  vmovaps xmm13, [rsp+0x10]
0000710e9ebdebb1  por xmm14, xmm13
0000710e9ebdebb6  lea r14, [rax+0x30]
0000710e9ebdebba  mov r12, [r13+r14*1]
0000710e9ebdebbf  lea r14, [rax+0x38]
0000710e9ebdebc3  mov r11, [r13+r14*1]
0000710e9ebdebc8  movq xmm13, r12
0000710e9ebdebcd  movq xmm12, r11
0000710e9ebdebd2  movq xmm13, xmm13
0000710e9ebdebd7  vmovaps [rsp+0x10], xmm13
0000710e9ebdebdd  movq xmm13, xmm13
0000710e9ebdebe2  movaps [r15+0x130], xmm13
0000710e9ebdebea  movq xmm12, xmm12
0000710e9ebdebef  vmovaps [rsp+0x20], xmm12
0000710e9ebdebf5  movq xmm12, xmm12
0000710e9ebdebfa  movaps [r15+0x280], xmm12
0000710e9ebdec02  movaps xmm13, [r15+0x270]
0000710e9ebdec0a  vmovaps [rsp+0x30], xmm13
0000710e9ebdec10  vmovaps xmm12, [rsp+0x30]
0000710e9ebdec16  por xmm13, xmm12
0000710e9ebdec1b  lea r14, [rax+0x20]
0000710e9ebdec1f  mov r12, [r13+r14*1]
0000710e9ebdec24  lea r14, [rax+0x28]
0000710e9ebdec28  mov r11, [r13+r14*1]
0000710e9ebdec2d  movq xmm12, r12
0000710e9ebdec32  movq xmm11, r11
0000710e9ebdec37  movq xmm12, xmm12
0000710e9ebdec3c  vmovaps [rsp+0x30], xmm12
0000710e9ebdec42  movq xmm12, xmm12
0000710e9ebdec47  movaps [r15+0x150], xmm12
0000710e9ebdec4f  movq xmm11, xmm11
0000710e9ebdec54  vmovaps [rsp+0x40], xmm11
0000710e9ebdec5a  movq xmm11, xmm11
0000710e9ebdec5f  movaps [r15+0x140], xmm11
0000710e9ebdec67  lea r14, [rax+0x10]
0000710e9ebdec6b  mov r12, [r13+r14*1]
0000710e9ebdec70  lea r14, [rax+0x18]
0000710e9ebdec74  mov r11, [r13+r14*1]
0000710e9ebdec79  movq xmm12, r12
0000710e9ebdec7e  movq xmm11, r11
0000710e9ebdec83  movq xmm12, xmm12
0000710e9ebdec88  vmovaps [rsp+0x50], xmm12
0000710e9ebdec8e  movq xmm12, xmm12
0000710e9ebdec93  movaps [r15+0x170], xmm12
0000710e9ebdec9b  movq xmm11, xmm11
0000710e9ebdeca0  vmovaps [rsp+0x60], xmm11
0000710e9ebdeca6  movq xmm11, xmm11
0000710e9ebdecab  movaps [r15+0x160], xmm11
0000710e9ebdecb3  mov r14, [r13+rax*1]
0000710e9ebdecb8  vmovq xmm12, r14
0000710e9ebdecbd  vpbroadcastq xmm12, xmm12
0000710e9ebdecc2  lea r14, [rax+0x08]
0000710e9ebdecc6  mov rax, [r13+r14*1]
0000710e9ebdeccb  movq xmm11, rax
0000710e9ebdecd0  movaps [r15+0x230], xmm11
0000710e9ebdecd8  mov rax, [r15+0xF8]
0000710e9ebdecdf  lea r14, [rax+0x50]
0000710e9ebdece3  movups xmm11, [r13+r14*1]
0000710e9ebdece9  lea r14, [rax+0x60]
0000710e9ebdeced  movups xmm10, [r13+r14*1]
0000710e9ebdecf3  lea r14, [rax+0x30]
0000710e9ebdecf7  movups xmm9, [r13+r14*1]
0000710e9ebdecfd  mov r14, [r15+0x50]
0000710e9ebded01  mov [r15+0x60], r14
0000710e9ebded05  mov qword ptr [r15+0x58], 0x40
0000710e9ebded0d  movaps xmm8, xmm12
0000710e9ebded11  mulpd xmm8, xmm15
0000710e9ebded16  vcmppd xmm7, xmm8, xmm8, 0x03
0000710e9ebded1c  ptest xmm7, xmm7
0000710e9ebded21  jnz 0x0000710E9EBDFB4A
0000710e9ebded27  movq xmm15, qword ptr [r15+0x230]
0000710e9ebded30  vmovaps [rsp+0x70], xmm15
0000710e9ebded36  vpermilpd xmm15, xmm15, 0x00
0000710e9ebded3c  movaps xmm7, xmm9
0000710e9ebded40  mulpd xmm7, xmm15
0000710e9ebded45  vcmppd xmm6, xmm7, xmm7, 0x03
0000710e9ebded4a  ptest xmm6, xmm6
0000710e9ebded4f  jnz 0x0000710E9EBDFC8E
0000710e9ebded55  vxorps xmm15, xmm15, xmm15
0000710e9ebded5a  vpbroadcastq xmm15, xmm15
0000710e9ebded5f  movaps xmm9, xmm12
0000710e9ebded63  mulpd xmm9, xmm10
0000710e9ebded68  vcmppd xmm6, xmm9, xmm9, 0x03
0000710e9ebded6e  ptest xmm6, xmm6
0000710e9ebded73  jnz 0x0000710E9EBDFDD0
0000710e9ebded79  movaps xmm10, xmm12
0000710e9ebded7d  mulpd xmm10, xmm11
0000710e9ebded82  vcmppd xmm6, xmm10, xmm10, 0x03
0000710e9ebded88  ptest xmm6, xmm6
0000710e9ebded8d  jnz 0x0000710E9EBDFF14
0000710e9ebded93  movaps xmm11, [r15+0x1F0]
0000710e9ebded9b  movaps xmm6, xmm12
0000710e9ebded9f  mulpd xmm6, xmm11
0000710e9ebdeda4  vcmppd xmm5, xmm6, xmm6, 0x03
0000710e9ebdeda9  ptest xmm5, xmm5
0000710e9ebdedae  jnz 0x0000710E9EBE0058
0000710e9ebdedb4  movaps xmm12, [r15+0x2A0]
0000710e9ebdedbc  vmovaps [rsp+0x80], xmm12
0000710e9ebdedc5  vmovaps xmm11, [rsp+0x80]
0000710e9ebdedce  por xmm12, xmm11
0000710e9ebdedd3  movaps xmm11, [r15+0x250]
0000710e9ebdeddb  vmovaps [rsp+0x80], xmm11
0000710e9ebdede4  vmovaps xmm5, [rsp+0x80]
0000710e9ebdeded  por xmm11, xmm5
0000710e9ebdedf2  vmovaps xmm4, [rsp+0x70]
0000710e9ebdedf8  vpermilpd xmm4, xmm4, 0x00
0000710e9ebdedfe  movaps xmm3, xmm5
0000710e9ebdee01  mulpd xmm3, xmm4
0000710e9ebdee05  vcmppd xmm2, xmm3, xmm3, 0x03
0000710e9ebdee0a  ptest xmm2, xmm2
0000710e9ebdee0f  jnz 0x0000710E9EBE019A
0000710e9ebdee15  mov [rsp+0x80], rax
0000710e9ebdee1d  xor eax, eax
0000710e9ebdee1f  mov r12d, 0x40
0000710e9ebdee25  mov r11d, 0x200
0000710e9ebdee2b  cmp r12, r11
0000710e9ebdee2e  cmc
0000710e9ebdee2f  lahf
0000710e9ebdee30  seto al
0000710e9ebdee33  mov [r15+0x108], eax
0000710e9ebdee3a  movaps xmm5, xmm8
0000710e9ebdee3e  addpd xmm5, xmm15
0000710e9ebdee43  vcmppd xmm4, xmm5, xmm5, 0x03
0000710e9ebdee48  ptest xmm4, xmm4
0000710e9ebdee4d  jnz 0x0000710E9EBE02DA
0000710e9ebdee53  movaps xmm8, [r15+0x1B0]
0000710e9ebdee5b  movaps xmm4, xmm9
0000710e9ebdee5f  addpd xmm4, xmm8
0000710e9ebdee64  vcmppd xmm2, xmm4, xmm4, 0x03
0000710e9ebdee69  ptest xmm2, xmm2
0000710e9ebdee6e  jnz 0x0000710E9EBE041C
0000710e9ebdee74  movaps xmm9, xmm10
0000710e9ebdee78  addpd xmm9, xmm8
0000710e9ebdee7d  vcmppd xmm2, xmm9, xmm9, 0x03
0000710e9ebdee83  ptest xmm2, xmm2
0000710e9ebdee88  jnz 0x0000710E9EBE055E
0000710e9ebdee8e  movaps xmm10, [r15+0x2F0]
0000710e9ebdee96  vmovaps [rsp+0x90], xmm10
0000710e9ebdee9f  vmovaps xmm8, [rsp+0x90]
0000710e9ebdeea8  por xmm10, xmm8
0000710e9ebdeead  movaps xmm8, [r15+0x2E0]
0000710e9ebdeeb5  vmovaps [rsp+0x90], xmm8
0000710e9ebdeebe  vmovaps xmm2, [rsp+0x90]
0000710e9ebdeec7  por xmm8, xmm2
0000710e9ebdeecc  movaps xmm2, [r15+0x2D0]
0000710e9ebdeed4  vmovaps [rsp+0x90], xmm2
0000710e9ebdeedd  vmovaps [rsp+0xA0], xmm1
0000710e9ebdeee6  vmovaps xmm1, [rsp+0x90]
0000710e9ebdeeef  por xmm2, xmm1
0000710e9ebdeef3  movaps xmm1, [r15+0x200]
0000710e9ebdeefb  vmovaps [rsp+0x90], xmm1
0000710e9ebdef04  vmovaps [rsp+0xB0], xmm15
0000710e9ebdef0d  vmovaps xmm15, [rsp+0x90]
0000710e9ebdef16  por xmm1, xmm15
0000710e9ebdef1b  movaps xmm15, [r15+0x1C0]
0000710e9ebdef23  vmovaps [rsp+0x90], xmm15
0000710e9ebdef2c  vmovaps [rsp+0xC0], xmm1
0000710e9ebdef35  vmovaps xmm1, [rsp+0x90]
0000710e9ebdef3e  por xmm15, xmm1
0000710e9ebdef43  movaps xmm1, [r15+0x190]
0000710e9ebdef4b  vmovaps [rsp+0x90], xmm1
0000710e9ebdef54  vmovaps [rsp+0xD0], xmm15
0000710e9ebdef5d  vmovaps xmm15, [rsp+0x90]
0000710e9ebdef66  por xmm1, xmm15
0000710e9ebdef6b  movaps xmm15, [r15+0x300]
0000710e9ebdef73  vmovaps [rsp+0x90], xmm15
0000710e9ebdef7c  vmovaps [rsp+0xE0], xmm1
0000710e9ebdef85  vmovaps xmm1, [rsp+0x90]
0000710e9ebdef8e  por xmm15, xmm1
0000710e9ebdef93  mov rax, [rsp+0x80]
0000710e9ebdef9b  lea r12, [rax+0xA0]
0000710e9ebdefa2  movups xmm1, [r13+r12*1]
0000710e9ebdefa8  lea r12, [rax+0xB0]
0000710e9ebdefaf  vmovaps [rsp+0x80], xmm1
0000710e9ebdefb8  movups xmm1, [r13+r12*1]
0000710e9ebdefbe  vmovaps [rsp+0x90], xmm1
0000710e9ebdefc7  vmovaps [rsp+0xF0], xmm15
0000710e9ebdefd0  vmovaps xmm15, [rsp+0xB0]
0000710e9ebdefd9  vmovaps [rsp+0xB0], xmm14
0000710e9ebdefe2  movaps xmm1, xmm6
0000710e9ebdefe5  addpd xmm1, xmm15
0000710e9ebdefea  vcmppd xmm14, xmm1, xmm1, 0x03
0000710e9ebdefef  ptest xmm14, xmm14
0000710e9ebdeff5  jnz 0x0000710E9EBE06B6
0000710e9ebdeffb  lea r12, [rax+0xF0]
0000710e9ebdf002  movups xmm15, [r13+r12*1]
0000710e9ebdf008  movaps xmm14, xmm4
0000710e9ebdf00c  addpd xmm14, xmm3
0000710e9ebdf011  vcmppd xmm6, xmm14, xmm14, 0x03
0000710e9ebdf017  ptest xmm6, xmm6
0000710e9ebdf01c  jnz 0x0000710E9EBE0801
0000710e9ebdf022  movaps xmm6, xmm9
0000710e9ebdf026  addpd xmm6, xmm7
0000710e9ebdf02a  vcmppd xmm4, xmm6, xmm6, 0x03
0000710e9ebdf02f  ptest xmm4, xmm4
0000710e9ebdf034  jnz 0x0000710E9EBE0943
0000710e9ebdf03a  vmovaps xmm9, [rsp+0x70]
0000710e9ebdf040  vpermilpd xmm9, xmm9, 0x00
0000710e9ebdf046  vmovaps xmm4, [rsp+0x90]
0000710e9ebdf04f  movaps xmm7, xmm4
0000710e9ebdf052  mulpd xmm7, xmm9
0000710e9ebdf057  vcmppd xmm3, xmm7, xmm7, 0x03
0000710e9ebdf05c  ptest xmm3, xmm3
0000710e9ebdf061  jnz 0x0000710E9EBE0A84
0000710e9ebdf067  vmovaps xmm9, [rsp+0x50]
0000710e9ebdf06d  vpermilpd xmm9, xmm9, 0x00
0000710e9ebdf073  movaps xmm4, xmm15
0000710e9ebdf077  mulpd xmm4, xmm9
0000710e9ebdf07c  vcmppd xmm3, xmm4, xmm4, 0x03
0000710e9ebdf081  ptest xmm3, xmm3
0000710e9ebdf086  jnz 0x0000710E9EBE0BC5
0000710e9ebdf08c  lea r12, [rax+0xE0]
0000710e9ebdf093  movups xmm15, [r13+r12*1]
0000710e9ebdf099  vmovaps xmm9, [rsp+0x70]
0000710e9ebdf09f  vpermilpd xmm9, xmm9, 0x00
0000710e9ebdf0a5  vmovaps [rsp+0x70], xmm1
0000710e9ebdf0ab  vmovaps xmm1, [rsp+0x80]
0000710e9ebdf0b4  vmovaps [rsp+0x80], xmm15
0000710e9ebdf0bd  movaps xmm3, xmm1
0000710e9ebdf0c0  mulpd xmm3, xmm9
0000710e9ebdf0c5  vcmppd xmm15, xmm3, xmm3, 0x03
0000710e9ebdf0ca  ptest xmm15, xmm15
0000710e9ebdf0d0  jnz 0x0000710E9EBE0D11
0000710e9ebdf0d6  vmovaps xmm1, [rsp+0xF0]
0000710e9ebdf0df  vmovaps xmm15, [rsp+0xF0]
0000710e9ebdf0e8  por xmm1, xmm15
0000710e9ebdf0ed  movaps [r15+0x300], xmm1
0000710e9ebdf0f5  vmovaps xmm15, [rsp+0xE0]
0000710e9ebdf0fe  vmovaps xmm9, [rsp+0xE0]
0000710e9ebdf107  por xmm15, xmm9
0000710e9ebdf10c  movaps [r15+0x190], xmm15
0000710e9ebdf114  vmovaps xmm9, [rsp+0x50]
0000710e9ebdf11a  vpermilpd xmm9, xmm9, 0x00
0000710e9ebdf120  vmovaps [rsp+0x90], xmm1
0000710e9ebdf129  vmovaps [rsp+0xE0], xmm15
0000710e9ebdf132  vmovaps xmm15, [rsp+0x80]
0000710e9ebdf13b  vmovaps [rsp+0x80], xmm14
0000710e9ebdf144  movaps xmm1, xmm15
0000710e9ebdf148  mulpd xmm1, xmm9
0000710e9ebdf14d  vcmppd xmm14, xmm1, xmm1, 0x03
0000710e9ebdf152  ptest xmm14, xmm14
0000710e9ebdf158  jnz 0x0000710E9EBE0E52
0000710e9ebdf15e  lea r12, [rax+0x90]
0000710e9ebdf165  movups xmm15, [r13+r12*1]
0000710e9ebdf16b  vmovaps xmm14, [rsp+0xD0]
0000710e9ebdf174  vmovaps xmm9, [rsp+0xD0]
0000710e9ebdf17d  por xmm14, xmm9
0000710e9ebdf182  movaps [r15+0x1C0], xmm14
0000710e9ebdf18a  vmovaps xmm9, [rsp+0xC0]
0000710e9ebdf193  vmovaps [rsp+0xD0], xmm1
0000710e9ebdf19c  vmovaps xmm1, [rsp+0xC0]
0000710e9ebdf1a5  por xmm9, xmm1
0000710e9ebdf1aa  movaps [r15+0x200], xmm9
0000710e9ebdf1b2  vmovaps [rsp+0xC0], xmm2
0000710e9ebdf1bb  vmovaps xmm1, [rsp+0xC0]
0000710e9ebdf1c4  por xmm2, xmm1
0000710e9ebdf1c8  movaps [r15+0x2D0], xmm2
0000710e9ebdf1d0  vmovaps [rsp+0xC0], xmm8
0000710e9ebdf1d9  vmovaps xmm1, [rsp+0xC0]
0000710e9ebdf1e2  por xmm8, xmm1
0000710e9ebdf1e7  movaps [r15+0x2E0], xmm8
0000710e9ebdf1ef  vmovaps [rsp+0xC0], xmm15
0000710e9ebdf1f8  movaps xmm1, xmm5
0000710e9ebdf1fb  addpd xmm1, xmm7
0000710e9ebdf1ff  vcmppd xmm15, xmm1, xmm1, 0x03
0000710e9ebdf204  ptest xmm15, xmm15
0000710e9ebdf20a  jnz 0x0000710E9EBE0F9E
0000710e9ebdf210  vmovaps xmm15, [rsp+0x50]
0000710e9ebdf216  vpermilpd xmm15, xmm15, 0x00
0000710e9ebdf21c  vmovaps xmm5, [rsp+0xC0]
0000710e9ebdf225  vmovaps [rsp+0xC0], xmm1
0000710e9ebdf22e  movaps xmm7, xmm5
0000710e9ebdf231  mulpd xmm7, xmm15
0000710e9ebdf236  vcmppd xmm1, xmm7, xmm7, 0x03
0000710e9ebdf23b  ptest xmm1, xmm1
0000710e9ebdf240  jnz 0x0000710E9EBE10DE
0000710e9ebdf246  lea r12, [rax+0x80]
0000710e9ebdf24d  movups xmm1, [r13+r12*1]
0000710e9ebdf253  vmovaps xmm5, [rsp+0x70]
0000710e9ebdf259  vmovaps [rsp+0x70], xmm1
0000710e9ebdf25f  movaps xmm15, xmm5
0000710e9ebdf263  addpd xmm15, xmm3
0000710e9ebdf268  vcmppd xmm1, xmm15, xmm15, 0x03
0000710e9ebdf26e  ptest xmm1, xmm1
0000710e9ebdf273  jnz 0x0000710E9EBE1229
0000710e9ebdf279  vmovaps xmm5, [rsp+0x80]
0000710e9ebdf282  movaps xmm1, xmm5
0000710e9ebdf285  addpd xmm1, xmm4
0000710e9ebdf289  vcmppd xmm3, xmm1, xmm1, 0x03
0000710e9ebdf28e  ptest xmm3, xmm3
0000710e9ebdf293  jnz 0x0000710E9EBE136B
0000710e9ebdf299  vmovaps [rsp+0x80], xmm10
0000710e9ebdf2a2  vmovaps xmm5, [rsp+0x80]
0000710e9ebdf2ab  por xmm10, xmm5
0000710e9ebdf2b0  movaps [r15+0x2F0], xmm10
0000710e9ebdf2b8  vmovaps xmm5, [rsp+0x50]
0000710e9ebdf2be  vpermilpd xmm5, xmm5, 0x00
0000710e9ebdf2c4  vmovaps xmm3, [rsp+0x70]
0000710e9ebdf2ca  vmovaps [rsp+0x50], xmm1
0000710e9ebdf2d0  movaps xmm4, xmm3
0000710e9ebdf2d3  mulpd xmm4, xmm5
0000710e9ebdf2d7  vcmppd xmm1, xmm4, xmm4, 0x03
0000710e9ebdf2dc  ptest xmm1, xmm1
0000710e9ebdf2e1  jnz 0x0000710E9EBE14AB
0000710e9ebdf2e7  lea r12, [rax+0xD0]
0000710e9ebdf2ee  movups xmm1, [r13+r12*1]
0000710e9ebdf2f4  vmovaps xmm3, [rsp+0xD0]
0000710e9ebdf2fd  vmovaps [rsp+0x70], xmm1
0000710e9ebdf303  movaps xmm5, xmm6
0000710e9ebdf306  addpd xmm5, xmm3
0000710e9ebdf30a  vcmppd xmm1, xmm5, xmm5, 0x03
0000710e9ebdf30f  ptest xmm1, xmm1
0000710e9ebdf314  jnz 0x0000710E9EBE15F5
0000710e9ebdf31a  vmovaps xmm1, [rsp+0x60]
0000710e9ebdf320  vpermilpd xmm1, xmm1, 0x00
0000710e9ebdf326  movaps xmm6, xmm9
0000710e9ebdf32a  mulpd xmm6, xmm1
0000710e9ebdf32e  vcmppd xmm3, xmm6, xmm6, 0x03
0000710e9ebdf333  ptest xmm3, xmm3
0000710e9ebdf338  jnz 0x0000710E9EBE1735
0000710e9ebdf33e  movaps [r15+0x260], xmm6
0000710e9ebdf346  vxorps xmm1, xmm1, xmm1
0000710e9ebdf34a  vpbroadcastq xmm1, xmm1
0000710e9ebdf34f  movaps [r15+0x1B0], xmm1
0000710e9ebdf357  vmovaps xmm1, [rsp+0x60]
0000710e9ebdf35d  vpermilpd xmm1, xmm1, 0x00
0000710e9ebdf363  vmovaps xmm3, [rsp+0x70]
0000710e9ebdf369  vmovaps [rsp+0x70], xmm15
0000710e9ebdf36f  movaps xmm9, xmm3
0000710e9ebdf373  mulpd xmm9, xmm1
0000710e9ebdf378  vcmppd xmm15, xmm9, xmm9, 0x03
0000710e9ebdf37e  ptest xmm15, xmm15
0000710e9ebdf384  jnz 0x0000710E9EBE1876
0000710e9ebdf38a  lea r12, [rax+0xC0]
0000710e9ebdf391  movups xmm1, [r13+r12*1]
0000710e9ebdf397  vmovaps xmm3, [rsp+0xC0]
0000710e9ebdf3a0  vmovaps [rsp+0x80], xmm1
0000710e9ebdf3a9  movaps xmm15, xmm3
0000710e9ebdf3ad  addpd xmm15, xmm7
0000710e9ebdf3b2  vcmppd xmm1, xmm15, xmm15, 0x03
0000710e9ebdf3b8  ptest xmm1, xmm1
0000710e9ebdf3bd  jnz 0x0000710E9EBE19C2
0000710e9ebdf3c3  vmovaps [rsp+0xC0], xmm13
0000710e9ebdf3cc  vmovaps xmm1, [rsp+0xC0]
0000710e9ebdf3d5  por xmm13, xmm1
0000710e9ebdf3da  movaps [r15+0x270], xmm13
0000710e9ebdf3e2  vmovaps xmm1, [rsp+0xB0]
0000710e9ebdf3eb  vmovaps xmm7, [rsp+0xB0]
0000710e9ebdf3f4  por xmm1, xmm7
0000710e9ebdf3f8  movaps [r15+0x1A0], xmm1
0000710e9ebdf400  vmovaps xmm1, [rsp+0x60]
0000710e9ebdf406  vpermilpd xmm1, xmm1, 0x00
0000710e9ebdf40c  vmovaps [rsp+0xB0], xmm1
0000710e9ebdf415  vmovaps xmm1, [rsp+0x80]
0000710e9ebdf41e  vmovaps [rsp+0x80], xmm15
0000710e9ebdf427  vmovaps xmm15, [rsp+0xB0]
0000710e9ebdf430  vmovaps [rsp+0xB0], xmm14
0000710e9ebdf439  movaps xmm3, xmm1
0000710e9ebdf43c  mulpd xmm3, xmm15
0000710e9ebdf441  vcmppd xmm14, xmm3, xmm3, 0x03
0000710e9ebdf446  ptest xmm14, xmm14
0000710e9ebdf44c  jnz 0x0000710E9EBE1B04
0000710e9ebdf452  lea r12, [rax+0x20]
0000710e9ebdf456  movups xmm1, [r13+r12*1]
0000710e9ebdf45c  movaps [r15+0x110], xmm1
0000710e9ebdf464  vmovaps xmm14, [rsp+0x70]
0000710e9ebdf46a  vmovaps [rsp+0x70], xmm1
0000710e9ebdf470  movaps xmm15, xmm14
0000710e9ebdf474  addpd xmm15, xmm4
0000710e9ebdf479  vcmppd xmm1, xmm15, xmm15, 0x03
0000710e9ebdf47f  ptest xmm1, xmm1
0000710e9ebdf484  jnz 0x0000710E9EBE1C4F
0000710e9ebdf48a  vmovaps xmm1, [rsp+0x60]
0000710e9ebdf490  vpermilpd xmm1, xmm1, 0x00
0000710e9ebdf496  movaps xmm14, xmm2
0000710e9ebdf49a  mulpd xmm14, xmm1
0000710e9ebdf49f  vcmppd xmm4, xmm14, xmm14, 0x03
0000710e9ebdf4a5  ptest xmm4, xmm4
0000710e9ebdf4aa  jnz 0x0000710E9EBE1D92
0000710e9ebdf4b0  vmovaps xmm4, [rsp+0x50]
0000710e9ebdf4b6  movaps xmm1, xmm4
0000710e9ebdf4b9  addpd xmm1, xmm9
0000710e9ebdf4be  vcmppd xmm2, xmm1, xmm1, 0x03
0000710e9ebdf4c3  ptest xmm2, xmm2
0000710e9ebdf4c8  jnz 0x0000710E9EBE1ED4
0000710e9ebdf4ce  vmovaps xmm9, [rsp+0x30]
0000710e9ebdf4d4  vpermilpd xmm9, xmm9, 0x00
0000710e9ebdf4da  vmovaps xmm2, [rsp+0x70]
0000710e9ebdf4e0  vmovaps [rsp+0x50], xmm1
0000710e9ebdf4e6  movaps xmm4, xmm2
0000710e9ebdf4e9  mulpd xmm4, xmm9
0000710e9ebdf4ee  vcmppd xmm1, xmm4, xmm4, 0x03
0000710e9ebdf4f3  ptest xmm1, xmm1
0000710e9ebdf4f8  jnz 0x0000710E9EBE2015
0000710e9ebdf4fe  vmovaps xmm1, [rsp+0x30]
0000710e9ebdf504  vpermilpd xmm1, xmm1, 0x00
0000710e9ebdf50a  vmovaps xmm2, [rsp+0x90]
0000710e9ebdf513  vmovaps [rsp+0x60], xmm15
0000710e9ebdf519  movaps xmm9, xmm2
0000710e9ebdf51d  mulpd xmm9, xmm1
0000710e9ebdf522  vcmppd xmm15, xmm9, xmm9, 0x03
0000710e9ebdf528  ptest xmm15, xmm15
0000710e9ebdf52e  jnz 0x0000710E9EBE2156
0000710e9ebdf534  vmovaps xmm15, [rsp+0x80]
0000710e9ebdf53d  movaps xmm1, xmm15
0000710e9ebdf541  addpd xmm1, xmm6
0000710e9ebdf545  vcmppd xmm2, xmm1, xmm1, 0x03
0000710e9ebdf54a  ptest xmm2, xmm2
0000710e9ebdf54f  jnz 0x0000710E9EBE2298
0000710e9ebdf555  movaps xmm15, xmm5
0000710e9ebdf559  addpd xmm15, xmm3
0000710e9ebdf55e  vcmppd xmm6, xmm15, xmm15, 0x03
0000710e9ebdf564  ptest xmm6, xmm6
0000710e9ebdf569  jnz 0x0000710E9EBE23D9
0000710e9ebdf56f  vmovaps xmm6, [rsp+0x30]
0000710e9ebdf575  vpermilpd xmm6, xmm6, 0x00
0000710e9ebdf57b  movaps xmm5, xmm8
0000710e9ebdf57f  mulpd xmm5, xmm6
0000710e9ebdf583  vcmppd xmm3, xmm5, xmm5, 0x03
0000710e9ebdf588  ptest xmm3, xmm3
0000710e9ebdf58d  jnz 0x0000710E9EBE251B
0000710e9ebdf593  vmovaps xmm8, [rsp+0x30]
0000710e9ebdf599  vpermilpd xmm8, xmm8, 0x00
0000710e9ebdf59f  movaps xmm6, xmm10
0000710e9ebdf5a3  mulpd xmm6, xmm8
0000710e9ebdf5a8  vcmppd xmm3, xmm6, xmm6, 0x03
0000710e9ebdf5ad  ptest xmm3, xmm3
0000710e9ebdf5b2  jnz 0x0000710E9EBE265C
0000710e9ebdf5b8  vmovaps xmm8, [rsp+0x60]
0000710e9ebdf5be  movaps xmm10, xmm8
0000710e9ebdf5c2  addpd xmm10, xmm14
0000710e9ebdf5c7  vcmppd xmm3, xmm10, xmm10, 0x03
0000710e9ebdf5cd  ptest xmm3, xmm3
0000710e9ebdf5d2  jnz 0x0000710E9EBE279E
0000710e9ebdf5d8  vmovaps xmm8, [rsp+0x50]
0000710e9ebdf5de  movaps xmm14, xmm8
0000710e9ebdf5e2  addpd xmm14, xmm4
0000710e9ebdf5e7  vcmppd xmm3, xmm14, xmm14, 0x03
0000710e9ebdf5ed  ptest xmm3, xmm3
0000710e9ebdf5f2  jnz 0x0000710E9EBE28E2
0000710e9ebdf5f8  vmovaps xmm8, [rsp+0x40]
0000710e9ebdf5fe  vpermilpd xmm8, xmm8, 0x00
0000710e9ebdf604  movaps xmm4, xmm13
0000710e9ebdf608  mulpd xmm4, xmm8
0000710e9ebdf60d  vcmppd xmm3, xmm4, xmm4, 0x03
0000710e9ebdf612  ptest xmm3, xmm3
0000710e9ebdf617  jnz 0x0000710E9EBE2A25
0000710e9ebdf61d  movaps xmm13, xmm15
0000710e9ebdf621  addpd xmm13, xmm9
0000710e9ebdf626  vcmppd xmm8, xmm13, xmm13, 0x03
0000710e9ebdf62c  ptest xmm8, xmm8
0000710e9ebdf632  jnz 0x0000710E9EBE2B67
0000710e9ebdf638  movaps xmm15, xmm1
0000710e9ebdf63c  addpd xmm15, xmm5
0000710e9ebdf641  vcmppd xmm9, xmm15, xmm15, 0x03
0000710e9ebdf647  ptest xmm9, xmm9
0000710e9ebdf64d  jnz 0x0000710E9EBE2CAB
0000710e9ebdf653  vmovaps [rsp+0x30], xmm11
0000710e9ebdf659  vmovaps xmm1, [rsp+0x30]
0000710e9ebdf65f  por xmm11, xmm1
0000710e9ebdf664  movaps [r15+0x250], xmm11
0000710e9ebdf66c  vmovaps [rsp+0x30], xmm12
0000710e9ebdf672  vmovaps xmm1, [rsp+0x30]
0000710e9ebdf678  por xmm12, xmm1
0000710e9ebdf67d  movaps [r15+0x2A0], xmm12
0000710e9ebdf685  vmovaps xmm1, [rsp+0xA0]
0000710e9ebdf68e  vmovaps xmm11, [rsp+0xA0]
0000710e9ebdf697  por xmm1, xmm11
0000710e9ebdf69c  movaps [r15+0x1D0], xmm1
0000710e9ebdf6a4  lea r12, [rax+0x40]
0000710e9ebdf6a8  movups xmm1, [r13+r12*1]
0000710e9ebdf6ae  movaps [r15+0x2C0], xmm1
0000710e9ebdf6b6  vmovaps xmm11, [rsp+0x40]
0000710e9ebdf6bc  vpermilpd xmm11, xmm11, 0x00
0000710e9ebdf6c2  vmovaps xmm8, [rsp+0xE0]
0000710e9ebdf6cb  movaps xmm9, xmm8
0000710e9ebdf6cf  mulpd xmm9, xmm11
0000710e9ebdf6d4  vcmppd xmm5, xmm9, xmm9, 0x03
0000710e9ebdf6da  ptest xmm5, xmm5
0000710e9ebdf6df  jnz 0x0000710E9EBE2DF7
0000710e9ebdf6e5  movaps xmm11, xmm10
0000710e9ebdf6e9  addpd xmm11, xmm6
0000710e9ebdf6ee  vcmppd xmm8, xmm11, xmm11, 0x03
0000710e9ebdf6f4  ptest xmm8, xmm8
0000710e9ebdf6fa  jnz 0x0000710E9EBE2F3B
0000710e9ebdf700  movaps xmm10, xmm14
0000710e9ebdf704  addpd xmm10, xmm4
0000710e9ebdf709  vcmppd xmm8, xmm10, xmm10, 0x03
0000710e9ebdf70f  ptest xmm8, xmm8
0000710e9ebdf715  jnz 0x0000710E9EBE307E
0000710e9ebdf71b  vmovaps xmm14, [rsp+0x40]
0000710e9ebdf721  vpermilpd xmm14, xmm14, 0x00
0000710e9ebdf727  movaps xmm8, xmm1
0000710e9ebdf72b  mulpd xmm8, xmm14
0000710e9ebdf730  vcmppd xmm6, xmm8, xmm8, 0x03
0000710e9ebdf736  ptest xmm6, xmm6
0000710e9ebdf73b  jnz 0x0000710E9EBE31C1
0000710e9ebdf741  movaps xmm1, [r15+0x2B0]
0000710e9ebdf749  vmovaps xmm14, [rsp+0x40]
0000710e9ebdf74f  vpermilpd xmm14, xmm14, 0x00
0000710e9ebdf755  movaps xmm6, xmm1
0000710e9ebdf758  mulpd xmm6, xmm14
0000710e9ebdf75d  vcmppd xmm5, xmm6, xmm6, 0x03
0000710e9ebdf762  ptest xmm5, xmm5
0000710e9ebdf767  jnz 0x0000710E9EBE3304
0000710e9ebdf76d  vmovaps xmm1, [rsp+0x10]
0000710e9ebdf773  vpermilpd xmm1, xmm1, 0x00
0000710e9ebdf779  movaps xmm14, xmm12
0000710e9ebdf77d  mulpd xmm14, xmm1
0000710e9ebdf782  vcmppd xmm5, xmm14, xmm14, 0x03
0000710e9ebdf788  ptest xmm5, xmm5
0000710e9ebdf78d  jnz 0x0000710E9EBE3445
0000710e9ebdf793  movaps xmm1, xmm13
0000710e9ebdf797  addpd xmm1, xmm9
0000710e9ebdf79c  vcmppd xmm12, xmm1, xmm1, 0x03
0000710e9ebdf7a1  ptest xmm12, xmm12
0000710e9ebdf7a7  jnz 0x0000710E9EBE3588
0000710e9ebdf7ad  vmovaps xmm13, [rsp+0x10]
0000710e9ebdf7b3  vpermilpd xmm13, xmm13, 0x00
0000710e9ebdf7b9  movaps xmm12, xmm7
0000710e9ebdf7bd  mulpd xmm12, xmm13
0000710e9ebdf7c2  vcmppd xmm9, xmm12, xmm12, 0x03
0000710e9ebdf7c8  ptest xmm9, xmm9
0000710e9ebdf7ce  jnz 0x0000710E9EBE36CA
0000710e9ebdf7d4  movaps xmm13, xmm15
0000710e9ebdf7d8  addpd xmm13, xmm8
0000710e9ebdf7dd  vcmppd xmm9, xmm13, xmm13, 0x03
0000710e9ebdf7e3  ptest xmm9, xmm9
0000710e9ebdf7e9  jnz 0x0000710E9EBE380D
0000710e9ebdf7ef  movaps xmm15, [r15+0x290]
0000710e9ebdf7f7  vmovaps xmm9, [rsp+0x10]
0000710e9ebdf7fd  vpermilpd xmm9, xmm9, 0x00
0000710e9ebdf803  movaps xmm8, xmm15
0000710e9ebdf807  mulpd xmm8, xmm9
0000710e9ebdf80c  vcmppd xmm7, xmm8, xmm8, 0x03
0000710e9ebdf812  ptest xmm7, xmm7
0000710e9ebdf817  jnz 0x0000710E9EBE3951
0000710e9ebdf81d  movaps xmm15, xmm11
0000710e9ebdf821  addpd xmm15, xmm6
0000710e9ebdf826  vcmppd xmm9, xmm15, xmm15, 0x03
0000710e9ebdf82c  ptest xmm9, xmm9
0000710e9ebdf832  jnz 0x0000710E9EBE3A95
0000710e9ebdf838  movaps xmm11, [r15+0x1E0]
0000710e9ebdf840  vmovaps xmm9, [rsp+0x10]
0000710e9ebdf846  vpermilpd xmm9, xmm9, 0x00
0000710e9ebdf84c  movaps xmm7, xmm11
0000710e9ebdf850  mulpd xmm7, xmm9
0000710e9ebdf855  vcmppd xmm6, xmm7, xmm7, 0x03
0000710e9ebdf85a  ptest xmm6, xmm6
0000710e9ebdf85f  jnz 0x0000710E9EBE3BD8
0000710e9ebdf865  movaps xmm11, xmm10
0000710e9ebdf869  addpd xmm11, xmm14
0000710e9ebdf86e  vcmppd xmm9, xmm11, xmm11, 0x03
0000710e9ebdf874  ptest xmm9, xmm9
0000710e9ebdf87a  jnz 0x0000710E9EBE3D1A
0000710e9ebdf880  lea r12, [rax+0x70]
0000710e9ebdf884  movups xmm14, [r13+r12*1]
0000710e9ebdf88a  movaps [r15+0x240], xmm14
0000710e9ebdf892  movaps xmm10, xmm1
0000710e9ebdf896  addpd xmm10, xmm12
0000710e9ebdf89b  vcmppd xmm9, xmm10, xmm10, 0x03
0000710e9ebdf8a1  ptest xmm9, xmm9
0000710e9ebdf8a7  jnz 0x0000710E9EBE3E68
0000710e9ebdf8ad  movaps [r15+0x170], xmm10
0000710e9ebdf8b5  vmovaps xmm1, [rsp+0x20]
0000710e9ebdf8bb  vpermilpd xmm1, xmm1, 0x00
0000710e9ebdf8c1  movaps xmm12, xmm14
0000710e9ebdf8c5  mulpd xmm12, xmm1
0000710e9ebdf8ca  vcmppd xmm9, xmm12, xmm12, 0x03
0000710e9ebdf8d0  ptest xmm9, xmm9
0000710e9ebdf8d6  jnz 0x0000710E9EBE3FAB
0000710e9ebdf8dc  vmovaps xmm1, [rsp+0x20]
0000710e9ebdf8e2  vpermilpd xmm1, xmm1, 0x00
0000710e9ebdf8e8  vmovaps xmm9, [rsp+0xB0]
0000710e9ebdf8f1  movaps xmm14, xmm9
0000710e9ebdf8f5  mulpd xmm14, xmm1
0000710e9ebdf8fa  vcmppd xmm6, xmm14, xmm14, 0x03
0000710e9ebdf900  ptest xmm6, xmm6
0000710e9ebdf905  jnz 0x0000710E9EBE40EE
0000710e9ebdf90b  movaps [r15+0x180], xmm14
0000710e9ebdf913  movaps xmm1, xmm13
0000710e9ebdf917  addpd xmm1, xmm8
0000710e9ebdf91c  vcmppd xmm9, xmm1, xmm1, 0x03
0000710e9ebdf921  ptest xmm9, xmm9
0000710e9ebdf927  jnz 0x0000710E9EBE4231
0000710e9ebdf92d  movaps [r15+0x210], xmm1
0000710e9ebdf935  movups xmm13, [r13+rax*1]
0000710e9ebdf93b  lea r12, [rax+0x10]
0000710e9ebdf93f  movups xmm9, [r13+r12*1]
0000710e9ebdf945  movaps [r15+0x230], xmm9
0000710e9ebdf94d  movaps xmm8, xmm15
0000710e9ebdf951  addpd xmm8, xmm7
0000710e9ebdf956  vcmppd xmm6, xmm8, xmm8, 0x03
0000710e9ebdf95c  ptest xmm6, xmm6
0000710e9ebdf961  jnz 0x0000710E9EBE4387
0000710e9ebdf967  movaps [r15+0x130], xmm8
0000710e9ebdf96f  vmovaps xmm15, [rsp+0x20]
0000710e9ebdf975  vpermilpd xmm15, xmm15, 0x00
0000710e9ebdf97b  movaps xmm7, xmm9
0000710e9ebdf97f  mulpd xmm7, xmm15
0000710e9ebdf984  vcmppd xmm6, xmm7, xmm7, 0x03
0000710e9ebdf989  ptest xmm6, xmm6
0000710e9ebdf98e  jnz 0x0000710E9EBE44CA
0000710e9ebdf994  movaps [r15+0x220], xmm7
0000710e9ebdf99c  vmovaps xmm15, [rsp+0x20]
0000710e9ebdf9a2  vpermilpd xmm15, xmm15, 0x00
0000710e9ebdf9a8  movaps xmm9, xmm13
0000710e9ebdf9ac  mulpd xmm9, xmm15
0000710e9ebdf9b1  vcmppd xmm6, xmm9, xmm9, 0x03
0000710e9ebdf9b7  ptest xmm6, xmm6
0000710e9ebdf9bc  jnz 0x0000710E9EBE460C
0000710e9ebdf9c2  movaps xmm15, xmm11
0000710e9ebdf9c6  addpd xmm15, xmm12
0000710e9ebdf9cb  vcmppd xmm13, xmm15, xmm15, 0x03
0000710e9ebdf9d1  ptest xmm13, xmm13
0000710e9ebdf9d7  jnz 0x0000710E9EBE4750
0000710e9ebdf9dd  movaps [r15+0x140], xmm15
0000710e9ebdf9e5  movaps xmm13, xmm10
0000710e9ebdf9e9  addpd xmm13, xmm14
0000710e9ebdf9ee  vcmppd xmm12, xmm13, xmm13, 0x03
0000710e9ebdf9f4  ptest xmm12, xmm12
0000710e9ebdf9fa  jnz 0x0000710E9EBE4894
0000710e9ebdfa00  movaps [r15+0x150], xmm13
0000710e9ebdfa08  movaps xmm14, xmm1
0000710e9ebdfa0c  addpd xmm14, xmm7
0000710e9ebdfa11  vcmppd xmm12, xmm14, xmm14, 0x03
0000710e9ebdfa17  ptest xmm12, xmm12
0000710e9ebdfa1d  jnz 0x0000710E9EBE49D8
0000710e9ebdfa23  movaps [r15+0x160], xmm14
0000710e9ebdfa2b  movaps xmm1, xmm8
0000710e9ebdfa2f  addpd xmm1, xmm9
0000710e9ebdfa34  vcmppd xmm12, xmm1, xmm1, 0x03
0000710e9ebdfa39  ptest xmm12, xmm12
0000710e9ebdfa3f  jnz 0x0000710E9EBE4B1A
0000710e9ebdfa45  movaps [r15+0x120], xmm1
0000710e9ebdfa4d  movups [r13+r14*1], xmm15
0000710e9ebdfa53  lea rax, [r14+0x10]
0000710e9ebdfa57  movups [r13+rax*1], xmm13
0000710e9ebdfa5d  lea rax, [r14+0x20]
0000710e9ebdfa61  movups [r13+rax*1], xmm14
0000710e9ebdfa67  lea rax, [r14+0x30]
0000710e9ebdfa6b  movups [r13+rax*1], xmm1
0000710e9ebdfa71  mov eax, [r15+0x108]
0000710e9ebdfa78  sahf
0000710e9ebdfa79  jnz 0x0000710E9EBDFAAB
0000710e9ebdfa7b  cmp dword ptr [r15+0x318], 0x00
0000710e9ebdfa83  jz 0x0000710E9EBDEAE0
0000710e9ebdfa89  nop [rax+rax*1], ax
0000710e9ebdfa92  nop [rax+rax*1], eax
0000710e9ebdfa9a  mov eax, 0x4106D0
0000710e9ebdfa9f  mov [r15+0x100], rax
0000710e9ebdfaa6  jmp 0x0000710E9E9FE110
0000710e9ebdfaab  cmp dword ptr [r15+0x318], 0x00
0000710e9ebdfab3  jz 0x0000710E9EBD89C0
0000710e9ebdfab9  nop [rax+rax*1], ax
0000710e9ebdfac2  nop [rax+rax*1], eax
0000710e9ebdfaca  mov eax, 0x410504
0000710e9ebdfacf  mov [r15+0x100], rax
0000710e9ebdfad6  jmp 0x0000710E9E9FE110
0000710e9ebdfadb  int3
0000710e9ebdfadc  call 0x0000710E9EAE27E0
0000710e9ebdfae1  jmp 0x0000710E9EBDEBBF
0000710e9ebdfae6  call 0x0000710E9EAE1570
0000710e9ebdfaeb  jmp 0x0000710E9EBDEBC8
0000710e9ebdfaf0  call 0x0000710E9EAE27E0
0000710e9ebdfaf5  jmp 0x0000710E9EBDEC24
0000710e9ebdfafa  call 0x0000710E9EAE1570
0000710e9ebdfaff  jmp 0x0000710E9EBDEC2D
0000710e9ebdfb04  call 0x0000710E9EAE27E0
0000710e9ebdfb09  jmp 0x0000710E9EBDEC70
0000710e9ebdfb0e  call 0x0000710E9EAE1570
0000710e9ebdfb13  jmp 0x0000710E9EBDEC79
0000710e9ebdfb18  call 0x0000710E9EA0DC20
0000710e9ebdfb1d  jmp 0x0000710E9EBDECB8
0000710e9ebdfb22  call 0x0000710E9EAD59C0
0000710e9ebdfb27  jmp 0x0000710E9EBDECCB
0000710e9ebdfb2c  call 0x0000710E9EAE0E30
0000710e9ebdfb31  jmp 0x0000710E9EBDECE9
0000710e9ebdfb36  call 0x0000710E9EADFBC0
0000710e9ebdfb3b  jmp 0x0000710E9EBDECF3
0000710e9ebdfb40  call 0x0000710E9EADE950
0000710e9ebdfb45  jmp 0x0000710E9EBDECFD
0000710e9ebdfb4a  sub rsp, 0x08
0000710e9ebdfb4e  push rax
0000710e9ebdfb4f  push rcx
0000710e9ebdfb50  push rdx
0000710e9ebdfb51  push rdi
0000710e9ebdfb52  push rsi
0000710e9ebdfb53  push r8
0000710e9ebdfb55  push r9
0000710e9ebdfb57  push r10
0000710e9ebdfb59  push r11
0000710e9ebdfb5b  sub rsp, 0xF0
0000710e9ebdfb62  vmovaps [rsp], xmm0
0000710e9ebdfb67  vmovaps [rsp+0x10], xmm1
0000710e9ebdfb6d  vmovaps [rsp+0x20], xmm2
0000710e9ebdfb73  vmovaps [rsp+0x30], xmm3
0000710e9ebdfb79  vmovaps [rsp+0x40], xmm4
0000710e9ebdfb7f  vmovaps [rsp+0x50], xmm5
0000710e9ebdfb85  vmovaps [rsp+0x60], xmm6
0000710e9ebdfb8b  vmovaps [rsp+0x70], xmm7
0000710e9ebdfb91  vmovaps [rsp+0x80], xmm9
0000710e9ebdfb9a  vmovaps [rsp+0x90], xmm10
0000710e9ebdfba3  vmovaps [rsp+0xA0], xmm11
0000710e9ebdfbac  vmovaps [rsp+0xB0], xmm12
0000710e9ebdfbb5  vmovaps [rsp+0xC0], xmm13
0000710e9ebdfbbe  vmovaps [rsp+0xD0], xmm14
0000710e9ebdfbc7  vmovaps [rsp+0xE0], xmm15
0000710e9ebdfbd0  sub rsp, 0x30
0000710e9ebdfbd4  movaps [rsp], xmm8
0000710e9ebdfbd9  movaps [rsp+0x10], xmm12
0000710e9ebdfbdf  movaps [rsp+0x20], xmm15
0000710e9ebdfbe5  lea rdi, [rsp]
0000710e9ebdfbe9  mov esi, 0x00
0000710e9ebdfbee  mov rax, 0x5DADAF7CF530
0000710e9ebdfbf8  call rax
0000710e9ebdfbfa  movaps xmm8, [rsp]
0000710e9ebdfbff  add rsp, 0x30
0000710e9ebdfc03  vmovaps xmm0, [rsp]
0000710e9ebdfc08  vmovaps xmm1, [rsp+0x10]
0000710e9ebdfc0e  vmovaps xmm2, [rsp+0x20]
0000710e9ebdfc14  vmovaps xmm3, [rsp+0x30]
0000710e9ebdfc1a  vmovaps xmm4, [rsp+0x40]
0000710e9ebdfc20  vmovaps xmm5, [rsp+0x50]
0000710e9ebdfc26  vmovaps xmm6, [rsp+0x60]
0000710e9ebdfc2c  vmovaps xmm7, [rsp+0x70]
0000710e9ebdfc32  vmovaps xmm9, [rsp+0x80]
0000710e9ebdfc3b  vmovaps xmm10, [rsp+0x90]
0000710e9ebdfc44  vmovaps xmm11, [rsp+0xA0]
0000710e9ebdfc4d  vmovaps xmm12, [rsp+0xB0]
0000710e9ebdfc56  vmovaps xmm13, [rsp+0xC0]
0000710e9ebdfc5f  vmovaps xmm14, [rsp+0xD0]
0000710e9ebdfc68  vmovaps xmm15, [rsp+0xE0]
0000710e9ebdfc71  add rsp, 0xF0
0000710e9ebdfc78  pop r11
0000710e9ebdfc7a  pop r10
0000710e9ebdfc7c  pop r9
0000710e9ebdfc7e  pop r8
0000710e9ebdfc80  pop rsi
0000710e9ebdfc81  pop rdi
0000710e9ebdfc82  pop rdx
0000710e9ebdfc83  pop rcx
0000710e9ebdfc84  pop rax
0000710e9ebdfc85  add rsp, 0x08
0000710e9ebdfc89  jmp 0x0000710E9EBDED27
0000710e9ebdfc8e  sub rsp, 0x08
0000710e9ebdfc92  push rax
0000710e9ebdfc93  push rcx
0000710e9ebdfc94  push rdx
0000710e9ebdfc95  push rdi
0000710e9ebdfc96  push rsi
0000710e9ebdfc97  push r8
0000710e9ebdfc99  push r9
0000710e9ebdfc9b  push r10
0000710e9ebdfc9d  push r11
0000710e9ebdfc9f  sub rsp, 0xF0
0000710e9ebdfca6  vmovaps [rsp], xmm0
0000710e9ebdfcab  vmovaps [rsp+0x10], xmm1
0000710e9ebdfcb1  vmovaps [rsp+0x20], xmm2
0000710e9ebdfcb7  vmovaps [rsp+0x30], xmm3
0000710e9ebdfcbd  vmovaps [rsp+0x40], xmm4
0000710e9ebdfcc3  vmovaps [rsp+0x50], xmm5
0000710e9ebdfcc9  vmovaps [rsp+0x60], xmm6
0000710e9ebdfccf  vmovaps [rsp+0x70], xmm8
0000710e9ebdfcd5  vmovaps [rsp+0x80], xmm9
0000710e9ebdfcde  vmovaps [rsp+0x90], xmm10
0000710e9ebdfce7  vmovaps [rsp+0xA0], xmm11
0000710e9ebdfcf0  vmovaps [rsp+0xB0], xmm12
0000710e9ebdfcf9  vmovaps [rsp+0xC0], xmm13
0000710e9ebdfd02  vmovaps [rsp+0xD0], xmm14
0000710e9ebdfd0b  vmovaps [rsp+0xE0], xmm15
0000710e9ebdfd14  sub rsp, 0x30
0000710e9ebdfd18  movaps [rsp], xmm7
0000710e9ebdfd1c  movaps [rsp+0x10], xmm9
0000710e9ebdfd22  movaps [rsp+0x20], xmm15
0000710e9ebdfd28  lea rdi, [rsp]
0000710e9ebdfd2c  mov esi, 0x00
0000710e9ebdfd31  mov rax, 0x5DADAF7CF530
0000710e9ebdfd3b  call rax
0000710e9ebdfd3d  movaps xmm7, [rsp]
0000710e9ebdfd41  add rsp, 0x30
0000710e9ebdfd45  vmovaps xmm0, [rsp]
0000710e9ebdfd4a  vmovaps xmm1, [rsp+0x10]
0000710e9ebdfd50  vmovaps xmm2, [rsp+0x20]
0000710e9ebdfd56  vmovaps xmm3, [rsp+0x30]
0000710e9ebdfd5c  vmovaps xmm4, [rsp+0x40]
0000710e9ebdfd62  vmovaps xmm5, [rsp+0x50]
0000710e9ebdfd68  vmovaps xmm6, [rsp+0x60]
0000710e9ebdfd6e  vmovaps xmm8, [rsp+0x70]
0000710e9ebdfd74  vmovaps xmm9, [rsp+0x80]
0000710e9ebdfd7d  vmovaps xmm10, [rsp+0x90]
0000710e9ebdfd86  vmovaps xmm11, [rsp+0xA0]
0000710e9ebdfd8f  vmovaps xmm12, [rsp+0xB0]
0000710e9ebdfd98  vmovaps xmm13, [rsp+0xC0]
0000710e9ebdfda1  vmovaps xmm14, [rsp+0xD0]
0000710e9ebdfdaa  vmovaps xmm15, [rsp+0xE0]
0000710e9ebdfdb3  add rsp, 0xF0
0000710e9ebdfdba  pop r11
0000710e9ebdfdbc  pop r10
0000710e9ebdfdbe  pop r9
0000710e9ebdfdc0  pop r8
0000710e9ebdfdc2  pop rsi
0000710e9ebdfdc3  pop rdi
0000710e9ebdfdc4  pop rdx
0000710e9ebdfdc5  pop rcx
0000710e9ebdfdc6  pop rax
0000710e9ebdfdc7  add rsp, 0x08
0000710e9ebdfdcb  jmp 0x0000710E9EBDED55
0000710e9ebdfdd0  sub rsp, 0x08
0000710e9ebdfdd4  push rax
0000710e9ebdfdd5  push rcx
0000710e9ebdfdd6  push rdx
0000710e9ebdfdd7  push rdi
0000710e9ebdfdd8  push rsi
0000710e9ebdfdd9  push r8
0000710e9ebdfddb  push r9
0000710e9ebdfddd  push r10
0000710e9ebdfddf  push r11
0000710e9ebdfde1  sub rsp, 0xF0
0000710e9ebdfde8  vmovaps [rsp], xmm0
0000710e9ebdfded  vmovaps [rsp+0x10], xmm1
0000710e9ebdfdf3  vmovaps [rsp+0x20], xmm2
0000710e9ebdfdf9  vmovaps [rsp+0x30], xmm3
0000710e9ebdfdff  vmovaps [rsp+0x40], xmm4
0000710e9ebdfe05  vmovaps [rsp+0x50], xmm5
0000710e9ebdfe0b  vmovaps [rsp+0x60], xmm6
0000710e9ebdfe11  vmovaps [rsp+0x70], xmm7
0000710e9ebdfe17  vmovaps [rsp+0x80], xmm8
0000710e9ebdfe20  vmovaps [rsp+0x90], xmm10
0000710e9ebdfe29  vmovaps [rsp+0xA0], xmm11
0000710e9ebdfe32  vmovaps [rsp+0xB0], xmm12
0000710e9ebdfe3b  vmovaps [rsp+0xC0], xmm13
0000710e9ebdfe44  vmovaps [rsp+0xD0], xmm14
0000710e9ebdfe4d  vmovaps [rsp+0xE0], xmm15
0000710e9ebdfe56  sub rsp, 0x30
0000710e9ebdfe5a  movaps [rsp], xmm9
0000710e9ebdfe5f  movaps [rsp+0x10], xmm12
0000710e9ebdfe65  movaps [rsp+0x20], xmm10
0000710e9ebdfe6b  lea rdi, [rsp]
0000710e9ebdfe6f  mov esi, 0x00
0000710e9ebdfe74  mov rax, 0x5DADAF7CF530
0000710e9ebdfe7e  call rax
0000710e9ebdfe80  movaps xmm9, [rsp]
0000710e9ebdfe85  add rsp, 0x30
0000710e9ebdfe89  vmovaps xmm0, [rsp]
0000710e9ebdfe8e  vmovaps xmm1, [rsp+0x10]
0000710e9ebdfe94  vmovaps xmm2, [rsp+0x20]
0000710e9ebdfe9a  vmovaps xmm3, [rsp+0x30]
0000710e9ebdfea0  vmovaps xmm4, [rsp+0x40]
0000710e9ebdfea6  vmovaps xmm5, [rsp+0x50]
0000710e9ebdfeac  vmovaps xmm6, [rsp+0x60]
0000710e9ebdfeb2  vmovaps xmm7, [rsp+0x70]
0000710e9ebdfeb8  vmovaps xmm8, [rsp+0x80]
0000710e9ebdfec1  vmovaps xmm10, [rsp+0x90]
0000710e9ebdfeca  vmovaps xmm11, [rsp+0xA0]
0000710e9ebdfed3  vmovaps xmm12, [rsp+0xB0]
0000710e9ebdfedc  vmovaps xmm13, [rsp+0xC0]
0000710e9ebdfee5  vmovaps xmm14, [rsp+0xD0]
0000710e9ebdfeee  vmovaps xmm15, [rsp+0xE0]
0000710e9ebdfef7  add rsp, 0xF0
0000710e9ebdfefe  pop r11
0000710e9ebdff00  pop r10
0000710e9ebdff02  pop r9
0000710e9ebdff04  pop r8
0000710e9ebdff06  pop rsi
0000710e9ebdff07  pop rdi
0000710e9ebdff08  pop rdx
0000710e9ebdff09  pop rcx
0000710e9ebdff0a  pop rax
0000710e9ebdff0b  add rsp, 0x08
0000710e9ebdff0f  jmp 0x0000710E9EBDED79
0000710e9ebdff14  sub rsp, 0x08
0000710e9ebdff18  push rax
0000710e9ebdff19  push rcx
0000710e9ebdff1a  push rdx
0000710e9ebdff1b  push rdi
0000710e9ebdff1c  push rsi
0000710e9ebdff1d  push r8
0000710e9ebdff1f  push r9
0000710e9ebdff21  push r10
0000710e9ebdff23  push r11
0000710e9ebdff25  sub rsp, 0xF0
0000710e9ebdff2c  vmovaps [rsp], xmm0
0000710e9ebdff31  vmovaps [rsp+0x10], xmm1
0000710e9ebdff37  vmovaps [rsp+0x20], xmm2
0000710e9ebdff3d  vmovaps [rsp+0x30], xmm3
0000710e9ebdff43  vmovaps [rsp+0x40], xmm4
0000710e9ebdff49  vmovaps [rsp+0x50], xmm5
0000710e9ebdff4f  vmovaps [rsp+0x60], xmm6
0000710e9ebdff55  vmovaps [rsp+0x70], xmm7
0000710e9ebdff5b  vmovaps [rsp+0x80], xmm8
0000710e9ebdff64  vmovaps [rsp+0x90], xmm9
0000710e9ebdff6d  vmovaps [rsp+0xA0], xmm11
0000710e9ebdff76  vmovaps [rsp+0xB0], xmm12
0000710e9ebdff7f  vmovaps [rsp+0xC0], xmm13
0000710e9ebdff88  vmovaps [rsp+0xD0], xmm14
0000710e9ebdff91  vmovaps [rsp+0xE0], xmm15
0000710e9ebdff9a  sub rsp, 0x30
0000710e9ebdff9e  movaps [rsp], xmm10
0000710e9ebdffa3  movaps [rsp+0x10], xmm12
0000710e9ebdffa9  movaps [rsp+0x20], xmm11
0000710e9ebdffaf  lea rdi, [rsp]
0000710e9ebdffb3  mov esi, 0x00
0000710e9ebdffb8  mov rax, 0x5DADAF7CF530
0000710e9ebdffc2  call rax
0000710e9ebdffc4  movaps xmm10, [rsp]
0000710e9ebdffc9  add rsp, 0x30
0000710e9ebdffcd  vmovaps xmm0, [rsp]
0000710e9ebdffd2  vmovaps xmm1, [rsp+0x10]
0000710e9ebdffd8  vmovaps xmm2, [rsp+0x20]
0000710e9ebdffde  vmovaps xmm3, [rsp+0x30]
0000710e9ebdffe4  vmovaps xmm4, [rsp+0x40]
0000710e9ebdffea  vmovaps xmm5, [rsp+0x50]
0000710e9ebdfff0  vmovaps xmm6, [rsp+0x60]
0000710e9ebdfff6  vmovaps xmm7, [rsp+0x70]
0000710e9ebdfffc  vmovaps xmm8, [rsp+0x80]
0000710e9ebe0005  vmovaps xmm9, [rsp+0x90]
0000710e9ebe000e  vmovaps xmm11, [rsp+0xA0]
0000710e9ebe0017  vmovaps xmm12, [rsp+0xB0]
0000710e9ebe0020  vmovaps xmm13, [rsp+0xC0]
0000710e9ebe0029  vmovaps xmm14, [rsp+0xD0]
0000710e9ebe0032  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe003b  add rsp, 0xF0
0000710e9ebe0042  pop r11
0000710e9ebe0044  pop r10
0000710e9ebe0046  pop r9
0000710e9ebe0048  pop r8
0000710e9ebe004a  pop rsi
0000710e9ebe004b  pop rdi
0000710e9ebe004c  pop rdx
0000710e9ebe004d  pop rcx
0000710e9ebe004e  pop rax
0000710e9ebe004f  add rsp, 0x08
0000710e9ebe0053  jmp 0x0000710E9EBDED93
0000710e9ebe0058  sub rsp, 0x08
0000710e9ebe005c  push rax
0000710e9ebe005d  push rcx
0000710e9ebe005e  push rdx
0000710e9ebe005f  push rdi
0000710e9ebe0060  push rsi
0000710e9ebe0061  push r8
0000710e9ebe0063  push r9
0000710e9ebe0065  push r10
0000710e9ebe0067  push r11
0000710e9ebe0069  sub rsp, 0xF0
0000710e9ebe0070  vmovaps [rsp], xmm0
0000710e9ebe0075  vmovaps [rsp+0x10], xmm1
0000710e9ebe007b  vmovaps [rsp+0x20], xmm2
0000710e9ebe0081  vmovaps [rsp+0x30], xmm3
0000710e9ebe0087  vmovaps [rsp+0x40], xmm4
0000710e9ebe008d  vmovaps [rsp+0x50], xmm5
0000710e9ebe0093  vmovaps [rsp+0x60], xmm7
0000710e9ebe0099  vmovaps [rsp+0x70], xmm8
0000710e9ebe009f  vmovaps [rsp+0x80], xmm9
0000710e9ebe00a8  vmovaps [rsp+0x90], xmm10
0000710e9ebe00b1  vmovaps [rsp+0xA0], xmm11
0000710e9ebe00ba  vmovaps [rsp+0xB0], xmm12
0000710e9ebe00c3  vmovaps [rsp+0xC0], xmm13
0000710e9ebe00cc  vmovaps [rsp+0xD0], xmm14
0000710e9ebe00d5  vmovaps [rsp+0xE0], xmm15
0000710e9ebe00de  sub rsp, 0x30
0000710e9ebe00e2  movaps [rsp], xmm6
0000710e9ebe00e6  movaps [rsp+0x10], xmm12
0000710e9ebe00ec  movaps [rsp+0x20], xmm11
0000710e9ebe00f2  lea rdi, [rsp]
0000710e9ebe00f6  mov esi, 0x00
0000710e9ebe00fb  mov rax, 0x5DADAF7CF530
0000710e9ebe0105  call rax
0000710e9ebe0107  movaps xmm6, [rsp]
0000710e9ebe010b  add rsp, 0x30
0000710e9ebe010f  vmovaps xmm0, [rsp]
0000710e9ebe0114  vmovaps xmm1, [rsp+0x10]
0000710e9ebe011a  vmovaps xmm2, [rsp+0x20]
0000710e9ebe0120  vmovaps xmm3, [rsp+0x30]
0000710e9ebe0126  vmovaps xmm4, [rsp+0x40]
0000710e9ebe012c  vmovaps xmm5, [rsp+0x50]
0000710e9ebe0132  vmovaps xmm7, [rsp+0x60]
0000710e9ebe0138  vmovaps xmm8, [rsp+0x70]
0000710e9ebe013e  vmovaps xmm9, [rsp+0x80]
0000710e9ebe0147  vmovaps xmm10, [rsp+0x90]
0000710e9ebe0150  vmovaps xmm11, [rsp+0xA0]
0000710e9ebe0159  vmovaps xmm12, [rsp+0xB0]
0000710e9ebe0162  vmovaps xmm13, [rsp+0xC0]
0000710e9ebe016b  vmovaps xmm14, [rsp+0xD0]
0000710e9ebe0174  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe017d  add rsp, 0xF0
0000710e9ebe0184  pop r11
0000710e9ebe0186  pop r10
0000710e9ebe0188  pop r9
0000710e9ebe018a  pop r8
0000710e9ebe018c  pop rsi
0000710e9ebe018d  pop rdi
0000710e9ebe018e  pop rdx
0000710e9ebe018f  pop rcx
0000710e9ebe0190  pop rax
0000710e9ebe0191  add rsp, 0x08
0000710e9ebe0195  jmp 0x0000710E9EBDEDB4
0000710e9ebe019a  sub rsp, 0x08
0000710e9ebe019e  push rax
0000710e9ebe019f  push rcx
0000710e9ebe01a0  push rdx
0000710e9ebe01a1  push rdi
0000710e9ebe01a2  push rsi
0000710e9ebe01a3  push r8
0000710e9ebe01a5  push r9
0000710e9ebe01a7  push r10
0000710e9ebe01a9  push r11
0000710e9ebe01ab  sub rsp, 0xF0
0000710e9ebe01b2  vmovaps [rsp], xmm0
0000710e9ebe01b7  vmovaps [rsp+0x10], xmm1
0000710e9ebe01bd  vmovaps [rsp+0x20], xmm2
0000710e9ebe01c3  vmovaps [rsp+0x30], xmm4
0000710e9ebe01c9  vmovaps [rsp+0x40], xmm5
0000710e9ebe01cf  vmovaps [rsp+0x50], xmm6
0000710e9ebe01d5  vmovaps [rsp+0x60], xmm7
0000710e9ebe01db  vmovaps [rsp+0x70], xmm8
0000710e9ebe01e1  vmovaps [rsp+0x80], xmm9
0000710e9ebe01ea  vmovaps [rsp+0x90], xmm10
0000710e9ebe01f3  vmovaps [rsp+0xA0], xmm11
0000710e9ebe01fc  vmovaps [rsp+0xB0], xmm12
0000710e9ebe0205  vmovaps [rsp+0xC0], xmm13
0000710e9ebe020e  vmovaps [rsp+0xD0], xmm14
0000710e9ebe0217  vmovaps [rsp+0xE0], xmm15
0000710e9ebe0220  sub rsp, 0x30
0000710e9ebe0224  movaps [rsp], xmm3
0000710e9ebe0228  movaps [rsp+0x10], xmm5
0000710e9ebe022d  movaps [rsp+0x20], xmm4
0000710e9ebe0232  lea rdi, [rsp]
0000710e9ebe0236  mov esi, 0x00
0000710e9ebe023b  mov rax, 0x5DADAF7CF530
0000710e9ebe0245  call rax
0000710e9ebe0247  movaps xmm3, [rsp]
0000710e9ebe024b  add rsp, 0x30
0000710e9ebe024f  vmovaps xmm0, [rsp]
0000710e9ebe0254  vmovaps xmm1, [rsp+0x10]
0000710e9ebe025a  vmovaps xmm2, [rsp+0x20]
0000710e9ebe0260  vmovaps xmm4, [rsp+0x30]
0000710e9ebe0266  vmovaps xmm5, [rsp+0x40]
0000710e9ebe026c  vmovaps xmm6, [rsp+0x50]
0000710e9ebe0272  vmovaps xmm7, [rsp+0x60]
0000710e9ebe0278  vmovaps xmm8, [rsp+0x70]
0000710e9ebe027e  vmovaps xmm9, [rsp+0x80]
0000710e9ebe0287  vmovaps xmm10, [rsp+0x90]
0000710e9ebe0290  vmovaps xmm11, [rsp+0xA0]
0000710e9ebe0299  vmovaps xmm12, [rsp+0xB0]
0000710e9ebe02a2  vmovaps xmm13, [rsp+0xC0]
0000710e9ebe02ab  vmovaps xmm14, [rsp+0xD0]
0000710e9ebe02b4  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe02bd  add rsp, 0xF0
0000710e9ebe02c4  pop r11
0000710e9ebe02c6  pop r10
0000710e9ebe02c8  pop r9
0000710e9ebe02ca  pop r8
0000710e9ebe02cc  pop rsi
0000710e9ebe02cd  pop rdi
0000710e9ebe02ce  pop rdx
0000710e9ebe02cf  pop rcx
0000710e9ebe02d0  pop rax
0000710e9ebe02d1  add rsp, 0x08
0000710e9ebe02d5  jmp 0x0000710E9EBDEE15
0000710e9ebe02da  sub rsp, 0x08
0000710e9ebe02de  push rax
0000710e9ebe02df  push rcx
0000710e9ebe02e0  push rdx
0000710e9ebe02e1  push rdi
0000710e9ebe02e2  push rsi
0000710e9ebe02e3  push r8
0000710e9ebe02e5  push r9
0000710e9ebe02e7  push r10
0000710e9ebe02e9  push r11
0000710e9ebe02eb  sub rsp, 0xF0
0000710e9ebe02f2  vmovaps [rsp], xmm0
0000710e9ebe02f7  vmovaps [rsp+0x10], xmm1
0000710e9ebe02fd  vmovaps [rsp+0x20], xmm2
0000710e9ebe0303  vmovaps [rsp+0x30], xmm3
0000710e9ebe0309  vmovaps [rsp+0x40], xmm4
0000710e9ebe030f  vmovaps [rsp+0x50], xmm6
0000710e9ebe0315  vmovaps [rsp+0x60], xmm7
0000710e9ebe031b  vmovaps [rsp+0x70], xmm8
0000710e9ebe0321  vmovaps [rsp+0x80], xmm9
0000710e9ebe032a  vmovaps [rsp+0x90], xmm10
0000710e9ebe0333  vmovaps [rsp+0xA0], xmm11
0000710e9ebe033c  vmovaps [rsp+0xB0], xmm12
0000710e9ebe0345  vmovaps [rsp+0xC0], xmm13
0000710e9ebe034e  vmovaps [rsp+0xD0], xmm14
0000710e9ebe0357  vmovaps [rsp+0xE0], xmm15
0000710e9ebe0360  sub rsp, 0x30
0000710e9ebe0364  movaps [rsp], xmm5
0000710e9ebe0368  movaps [rsp+0x10], xmm8
0000710e9ebe036e  movaps [rsp+0x20], xmm15
0000710e9ebe0374  lea rdi, [rsp]
0000710e9ebe0378  mov esi, 0x00
0000710e9ebe037d  mov rax, 0x5DADAF7CF530
0000710e9ebe0387  call rax
0000710e9ebe0389  movaps xmm5, [rsp]
0000710e9ebe038d  add rsp, 0x30
0000710e9ebe0391  vmovaps xmm0, [rsp]
0000710e9ebe0396  vmovaps xmm1, [rsp+0x10]
0000710e9ebe039c  vmovaps xmm2, [rsp+0x20]
0000710e9ebe03a2  vmovaps xmm3, [rsp+0x30]
0000710e9ebe03a8  vmovaps xmm4, [rsp+0x40]
0000710e9ebe03ae  vmovaps xmm6, [rsp+0x50]
0000710e9ebe03b4  vmovaps xmm7, [rsp+0x60]
0000710e9ebe03ba  vmovaps xmm8, [rsp+0x70]
0000710e9ebe03c0  vmovaps xmm9, [rsp+0x80]
0000710e9ebe03c9  vmovaps xmm10, [rsp+0x90]
0000710e9ebe03d2  vmovaps xmm11, [rsp+0xA0]
0000710e9ebe03db  vmovaps xmm12, [rsp+0xB0]
0000710e9ebe03e4  vmovaps xmm13, [rsp+0xC0]
0000710e9ebe03ed  vmovaps xmm14, [rsp+0xD0]
0000710e9ebe03f6  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe03ff  add rsp, 0xF0
0000710e9ebe0406  pop r11
0000710e9ebe0408  pop r10
0000710e9ebe040a  pop r9
0000710e9ebe040c  pop r8
0000710e9ebe040e  pop rsi
0000710e9ebe040f  pop rdi
0000710e9ebe0410  pop rdx
0000710e9ebe0411  pop rcx
0000710e9ebe0412  pop rax
0000710e9ebe0413  add rsp, 0x08
0000710e9ebe0417  jmp 0x0000710E9EBDEE53
0000710e9ebe041c  sub rsp, 0x08
0000710e9ebe0420  push rax
0000710e9ebe0421  push rcx
0000710e9ebe0422  push rdx
0000710e9ebe0423  push rdi
0000710e9ebe0424  push rsi
0000710e9ebe0425  push r8
0000710e9ebe0427  push r9
0000710e9ebe0429  push r10
0000710e9ebe042b  push r11
0000710e9ebe042d  sub rsp, 0xF0
0000710e9ebe0434  vmovaps [rsp], xmm0
0000710e9ebe0439  vmovaps [rsp+0x10], xmm1
0000710e9ebe043f  vmovaps [rsp+0x20], xmm2
0000710e9ebe0445  vmovaps [rsp+0x30], xmm3
0000710e9ebe044b  vmovaps [rsp+0x40], xmm5
0000710e9ebe0451  vmovaps [rsp+0x50], xmm6
0000710e9ebe0457  vmovaps [rsp+0x60], xmm7
0000710e9ebe045d  vmovaps [rsp+0x70], xmm8
0000710e9ebe0463  vmovaps [rsp+0x80], xmm9
0000710e9ebe046c  vmovaps [rsp+0x90], xmm10
0000710e9ebe0475  vmovaps [rsp+0xA0], xmm11
0000710e9ebe047e  vmovaps [rsp+0xB0], xmm12
0000710e9ebe0487  vmovaps [rsp+0xC0], xmm13
0000710e9ebe0490  vmovaps [rsp+0xD0], xmm14
0000710e9ebe0499  vmovaps [rsp+0xE0], xmm15
0000710e9ebe04a2  sub rsp, 0x30
0000710e9ebe04a6  movaps [rsp], xmm4
0000710e9ebe04aa  movaps [rsp+0x10], xmm9
0000710e9ebe04b0  movaps [rsp+0x20], xmm8
0000710e9ebe04b6  lea rdi, [rsp]
0000710e9ebe04ba  mov esi, 0x00
0000710e9ebe04bf  mov rax, 0x5DADAF7CF530
0000710e9ebe04c9  call rax
0000710e9ebe04cb  movaps xmm4, [rsp]
0000710e9ebe04cf  add rsp, 0x30
0000710e9ebe04d3  vmovaps xmm0, [rsp]
0000710e9ebe04d8  vmovaps xmm1, [rsp+0x10]
0000710e9ebe04de  vmovaps xmm2, [rsp+0x20]
0000710e9ebe04e4  vmovaps xmm3, [rsp+0x30]
0000710e9ebe04ea  vmovaps xmm5, [rsp+0x40]
0000710e9ebe04f0  vmovaps xmm6, [rsp+0x50]
0000710e9ebe04f6  vmovaps xmm7, [rsp+0x60]
0000710e9ebe04fc  vmovaps xmm8, [rsp+0x70]
0000710e9ebe0502  vmovaps xmm9, [rsp+0x80]
0000710e9ebe050b  vmovaps xmm10, [rsp+0x90]
0000710e9ebe0514  vmovaps xmm11, [rsp+0xA0]
0000710e9ebe051d  vmovaps xmm12, [rsp+0xB0]
0000710e9ebe0526  vmovaps xmm13, [rsp+0xC0]
0000710e9ebe052f  vmovaps xmm14, [rsp+0xD0]
0000710e9ebe0538  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe0541  add rsp, 0xF0
0000710e9ebe0548  pop r11
0000710e9ebe054a  pop r10
0000710e9ebe054c  pop r9
0000710e9ebe054e  pop r8
0000710e9ebe0550  pop rsi
0000710e9ebe0551  pop rdi
0000710e9ebe0552  pop rdx
0000710e9ebe0553  pop rcx
0000710e9ebe0554  pop rax
0000710e9ebe0555  add rsp, 0x08
0000710e9ebe0559  jmp 0x0000710E9EBDEE74
0000710e9ebe055e  sub rsp, 0x08
0000710e9ebe0562  push rax
0000710e9ebe0563  push rcx
0000710e9ebe0564  push rdx
0000710e9ebe0565  push rdi
0000710e9ebe0566  push rsi
0000710e9ebe0567  push r8
0000710e9ebe0569  push r9
0000710e9ebe056b  push r10
0000710e9ebe056d  push r11
0000710e9ebe056f  sub rsp, 0xF0
0000710e9ebe0576  vmovaps [rsp], xmm0
0000710e9ebe057b  vmovaps [rsp+0x10], xmm1
0000710e9ebe0581  vmovaps [rsp+0x20], xmm2
0000710e9ebe0587  vmovaps [rsp+0x30], xmm3
0000710e9ebe058d  vmovaps [rsp+0x40], xmm4
0000710e9ebe0593  vmovaps [rsp+0x50], xmm5
0000710e9ebe0599  vmovaps [rsp+0x60], xmm6
0000710e9ebe059f  vmovaps [rsp+0x70], xmm7
0000710e9ebe05a5  vmovaps [rsp+0x80], xmm8
0000710e9ebe05ae  vmovaps [rsp+0x90], xmm10
0000710e9ebe05b7  vmovaps [rsp+0xA0], xmm11
0000710e9ebe05c0  vmovaps [rsp+0xB0], xmm12
0000710e9ebe05c9  vmovaps [rsp+0xC0], xmm13
0000710e9ebe05d2  vmovaps [rsp+0xD0], xmm14
0000710e9ebe05db  vmovaps [rsp+0xE0], xmm15
0000710e9ebe05e4  sub rsp, 0x30
0000710e9ebe05e8  movaps [rsp], xmm9
0000710e9ebe05ed  movaps [rsp+0x10], xmm10
0000710e9ebe05f3  movaps [rsp+0x20], xmm8
0000710e9ebe05f9  lea rdi, [rsp]
0000710e9ebe05fd  mov esi, 0x00
0000710e9ebe0602  mov rax, 0x5DADAF7CF530
0000710e9ebe060c  call rax
0000710e9ebe060e  movaps xmm9, [rsp]
0000710e9ebe0613  add rsp, 0x30
0000710e9ebe0617  vmovaps xmm0, [rsp]
0000710e9ebe061c  vmovaps xmm1, [rsp+0x10]
0000710e9ebe0622  vmovaps xmm2, [rsp+0x20]
0000710e9ebe0628  vmovaps xmm3, [rsp+0x30]
0000710e9ebe062e  vmovaps xmm4, [rsp+0x40]
0000710e9ebe0634  vmovaps xmm5, [rsp+0x50]
0000710e9ebe063a  vmovaps xmm6, [rsp+0x60]
0000710e9ebe0640  vmovaps xmm7, [rsp+0x70]
0000710e9ebe0646  vmovaps xmm8, [rsp+0x80]
0000710e9ebe064f  vmovaps xmm10, [rsp+0x90]
0000710e9ebe0658  vmovaps xmm11, [rsp+0xA0]
0000710e9ebe0661  vmovaps xmm12, [rsp+0xB0]
0000710e9ebe066a  vmovaps xmm13, [rsp+0xC0]
0000710e9ebe0673  vmovaps xmm14, [rsp+0xD0]
0000710e9ebe067c  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe0685  add rsp, 0xF0
0000710e9ebe068c  pop r11
0000710e9ebe068e  pop r10
0000710e9ebe0690  pop r9
0000710e9ebe0692  pop r8
0000710e9ebe0694  pop rsi
0000710e9ebe0695  pop rdi
0000710e9ebe0696  pop rdx
0000710e9ebe0697  pop rcx
0000710e9ebe0698  pop rax
0000710e9ebe0699  add rsp, 0x08
0000710e9ebe069d  jmp 0x0000710E9EBDEE8E
0000710e9ebe06a2  call 0x0000710E9EAB52F0
0000710e9ebe06a7  jmp 0x0000710E9EBDEFA8
0000710e9ebe06ac  call 0x0000710E9EAB52F0
0000710e9ebe06b1  jmp 0x0000710E9EBDEFBE
0000710e9ebe06b6  sub rsp, 0x08
0000710e9ebe06ba  push rax
0000710e9ebe06bb  push rcx
0000710e9ebe06bc  push rdx
0000710e9ebe06bd  push rdi
0000710e9ebe06be  push rsi
0000710e9ebe06bf  push r8
0000710e9ebe06c1  push r9
0000710e9ebe06c3  push r10
0000710e9ebe06c5  push r11
0000710e9ebe06c7  sub rsp, 0xF0
0000710e9ebe06ce  vmovaps [rsp], xmm0
0000710e9ebe06d3  vmovaps [rsp+0x10], xmm2
0000710e9ebe06d9  vmovaps [rsp+0x20], xmm3
0000710e9ebe06df  vmovaps [rsp+0x30], xmm4
0000710e9ebe06e5  vmovaps [rsp+0x40], xmm5
0000710e9ebe06eb  vmovaps [rsp+0x50], xmm6
0000710e9ebe06f1  vmovaps [rsp+0x60], xmm7
0000710e9ebe06f7  vmovaps [rsp+0x70], xmm8
0000710e9ebe06fd  vmovaps [rsp+0x80], xmm9
0000710e9ebe0706  vmovaps [rsp+0x90], xmm10
0000710e9ebe070f  vmovaps [rsp+0xA0], xmm11
0000710e9ebe0718  vmovaps [rsp+0xB0], xmm12
0000710e9ebe0721  vmovaps [rsp+0xC0], xmm13
0000710e9ebe072a  vmovaps [rsp+0xD0], xmm14
0000710e9ebe0733  vmovaps [rsp+0xE0], xmm15
0000710e9ebe073c  sub rsp, 0x30
0000710e9ebe0740  movaps [rsp], xmm1
0000710e9ebe0744  movaps [rsp+0x10], xmm6
0000710e9ebe0749  movaps [rsp+0x20], xmm15
0000710e9ebe074f  lea rdi, [rsp]
0000710e9ebe0753  mov esi, 0x00
0000710e9ebe0758  mov rax, 0x5DADAF7CF530
0000710e9ebe0762  call rax
0000710e9ebe0764  movaps xmm1, [rsp]
0000710e9ebe0768  add rsp, 0x30
0000710e9ebe076c  vmovaps xmm0, [rsp]
0000710e9ebe0771  vmovaps xmm2, [rsp+0x10]
0000710e9ebe0777  vmovaps xmm3, [rsp+0x20]
0000710e9ebe077d  vmovaps xmm4, [rsp+0x30]
0000710e9ebe0783  vmovaps xmm5, [rsp+0x40]
0000710e9ebe0789  vmovaps xmm6, [rsp+0x50]
0000710e9ebe078f  vmovaps xmm7, [rsp+0x60]
0000710e9ebe0795  vmovaps xmm8, [rsp+0x70]
0000710e9ebe079b  vmovaps xmm9, [rsp+0x80]
0000710e9ebe07a4  vmovaps xmm10, [rsp+0x90]
0000710e9ebe07ad  vmovaps xmm11, [rsp+0xA0]
0000710e9ebe07b6  vmovaps xmm12, [rsp+0xB0]
0000710e9ebe07bf  vmovaps xmm13, [rsp+0xC0]
0000710e9ebe07c8  vmovaps xmm14, [rsp+0xD0]
0000710e9ebe07d1  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe07da  add rsp, 0xF0
0000710e9ebe07e1  pop r11
0000710e9ebe07e3  pop r10
0000710e9ebe07e5  pop r9
0000710e9ebe07e7  pop r8
0000710e9ebe07e9  pop rsi
0000710e9ebe07ea  pop rdi
0000710e9ebe07eb  pop rdx
0000710e9ebe07ec  pop rcx
0000710e9ebe07ed  pop rax
0000710e9ebe07ee  add rsp, 0x08
0000710e9ebe07f2  jmp 0x0000710E9EBDEFFB
0000710e9ebe07f7  call 0x0000710E9EAC4620
0000710e9ebe07fc  jmp 0x0000710E9EBDF008
0000710e9ebe0801  sub rsp, 0x08
0000710e9ebe0805  push rax
0000710e9ebe0806  push rcx
0000710e9ebe0807  push rdx
0000710e9ebe0808  push rdi
0000710e9ebe0809  push rsi
0000710e9ebe080a  push r8
0000710e9ebe080c  push r9
0000710e9ebe080e  push r10
0000710e9ebe0810  push r11
0000710e9ebe0812  sub rsp, 0xF0
0000710e9ebe0819  vmovaps [rsp], xmm0
0000710e9ebe081e  vmovaps [rsp+0x10], xmm1
0000710e9ebe0824  vmovaps [rsp+0x20], xmm2
0000710e9ebe082a  vmovaps [rsp+0x30], xmm3
0000710e9ebe0830  vmovaps [rsp+0x40], xmm4
0000710e9ebe0836  vmovaps [rsp+0x50], xmm5
0000710e9ebe083c  vmovaps [rsp+0x60], xmm6
0000710e9ebe0842  vmovaps [rsp+0x70], xmm7
0000710e9ebe0848  vmovaps [rsp+0x80], xmm8
0000710e9ebe0851  vmovaps [rsp+0x90], xmm9
0000710e9ebe085a  vmovaps [rsp+0xA0], xmm10
0000710e9ebe0863  vmovaps [rsp+0xB0], xmm11
0000710e9ebe086c  vmovaps [rsp+0xC0], xmm12
0000710e9ebe0875  vmovaps [rsp+0xD0], xmm13
0000710e9ebe087e  vmovaps [rsp+0xE0], xmm15
0000710e9ebe0887  sub rsp, 0x30
0000710e9ebe088b  movaps [rsp], xmm14
0000710e9ebe0890  movaps [rsp+0x10], xmm4
0000710e9ebe0895  movaps [rsp+0x20], xmm3
0000710e9ebe089a  lea rdi, [rsp]
0000710e9ebe089e  mov esi, 0x00
0000710e9ebe08a3  mov rax, 0x5DADAF7CF530
0000710e9ebe08ad  call rax
0000710e9ebe08af  movaps xmm14, [rsp]
0000710e9ebe08b4  add rsp, 0x30
0000710e9ebe08b8  vmovaps xmm0, [rsp]
0000710e9ebe08bd  vmovaps xmm1, [rsp+0x10]
0000710e9ebe08c3  vmovaps xmm2, [rsp+0x20]
0000710e9ebe08c9  vmovaps xmm3, [rsp+0x30]
0000710e9ebe08cf  vmovaps xmm4, [rsp+0x40]
0000710e9ebe08d5  vmovaps xmm5, [rsp+0x50]
0000710e9ebe08db  vmovaps xmm6, [rsp+0x60]
0000710e9ebe08e1  vmovaps xmm7, [rsp+0x70]
0000710e9ebe08e7  vmovaps xmm8, [rsp+0x80]
0000710e9ebe08f0  vmovaps xmm9, [rsp+0x90]
0000710e9ebe08f9  vmovaps xmm10, [rsp+0xA0]
0000710e9ebe0902  vmovaps xmm11, [rsp+0xB0]
0000710e9ebe090b  vmovaps xmm12, [rsp+0xC0]
0000710e9ebe0914  vmovaps xmm13, [rsp+0xD0]
0000710e9ebe091d  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe0926  add rsp, 0xF0
0000710e9ebe092d  pop r11
0000710e9ebe092f  pop r10
0000710e9ebe0931  pop r9
0000710e9ebe0933  pop r8
0000710e9ebe0935  pop rsi
0000710e9ebe0936  pop rdi
0000710e9ebe0937  pop rdx
0000710e9ebe0938  pop rcx
0000710e9ebe0939  pop rax
0000710e9ebe093a  add rsp, 0x08
0000710e9ebe093e  jmp 0x0000710E9EBDF022
0000710e9ebe0943  sub rsp, 0x08
0000710e9ebe0947  push rax
0000710e9ebe0948  push rcx
0000710e9ebe0949  push rdx
0000710e9ebe094a  push rdi
0000710e9ebe094b  push rsi
0000710e9ebe094c  push r8
0000710e9ebe094e  push r9
0000710e9ebe0950  push r10
0000710e9ebe0952  push r11
0000710e9ebe0954  sub rsp, 0xF0
0000710e9ebe095b  vmovaps [rsp], xmm0
0000710e9ebe0960  vmovaps [rsp+0x10], xmm1
0000710e9ebe0966  vmovaps [rsp+0x20], xmm2
0000710e9ebe096c  vmovaps [rsp+0x30], xmm3
0000710e9ebe0972  vmovaps [rsp+0x40], xmm4
0000710e9ebe0978  vmovaps [rsp+0x50], xmm5
0000710e9ebe097e  vmovaps [rsp+0x60], xmm7
0000710e9ebe0984  vmovaps [rsp+0x70], xmm8
0000710e9ebe098a  vmovaps [rsp+0x80], xmm9
0000710e9ebe0993  vmovaps [rsp+0x90], xmm10
0000710e9ebe099c  vmovaps [rsp+0xA0], xmm11
0000710e9ebe09a5  vmovaps [rsp+0xB0], xmm12
0000710e9ebe09ae  vmovaps [rsp+0xC0], xmm13
0000710e9ebe09b7  vmovaps [rsp+0xD0], xmm14
0000710e9ebe09c0  vmovaps [rsp+0xE0], xmm15
0000710e9ebe09c9  sub rsp, 0x30
0000710e9ebe09cd  movaps [rsp], xmm6
0000710e9ebe09d1  movaps [rsp+0x10], xmm9
0000710e9ebe09d7  movaps [rsp+0x20], xmm7
0000710e9ebe09dc  lea rdi, [rsp]
0000710e9ebe09e0  mov esi, 0x00
0000710e9ebe09e5  mov rax, 0x5DADAF7CF530
0000710e9ebe09ef  call rax
0000710e9ebe09f1  movaps xmm6, [rsp]
0000710e9ebe09f5  add rsp, 0x30
0000710e9ebe09f9  vmovaps xmm0, [rsp]
0000710e9ebe09fe  vmovaps xmm1, [rsp+0x10]
0000710e9ebe0a04  vmovaps xmm2, [rsp+0x20]
0000710e9ebe0a0a  vmovaps xmm3, [rsp+0x30]
0000710e9ebe0a10  vmovaps xmm4, [rsp+0x40]
0000710e9ebe0a16  vmovaps xmm5, [rsp+0x50]
0000710e9ebe0a1c  vmovaps xmm7, [rsp+0x60]
0000710e9ebe0a22  vmovaps xmm8, [rsp+0x70]
0000710e9ebe0a28  vmovaps xmm9, [rsp+0x80]
0000710e9ebe0a31  vmovaps xmm10, [rsp+0x90]
0000710e9ebe0a3a  vmovaps xmm11, [rsp+0xA0]
0000710e9ebe0a43  vmovaps xmm12, [rsp+0xB0]
0000710e9ebe0a4c  vmovaps xmm13, [rsp+0xC0]
0000710e9ebe0a55  vmovaps xmm14, [rsp+0xD0]
0000710e9ebe0a5e  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe0a67  add rsp, 0xF0
0000710e9ebe0a6e  pop r11
0000710e9ebe0a70  pop r10
0000710e9ebe0a72  pop r9
0000710e9ebe0a74  pop r8
0000710e9ebe0a76  pop rsi
0000710e9ebe0a77  pop rdi
0000710e9ebe0a78  pop rdx
0000710e9ebe0a79  pop rcx
0000710e9ebe0a7a  pop rax
0000710e9ebe0a7b  add rsp, 0x08
0000710e9ebe0a7f  jmp 0x0000710E9EBDF03A
0000710e9ebe0a84  sub rsp, 0x08
0000710e9ebe0a88  push rax
0000710e9ebe0a89  push rcx
0000710e9ebe0a8a  push rdx
0000710e9ebe0a8b  push rdi
0000710e9ebe0a8c  push rsi
0000710e9ebe0a8d  push r8
0000710e9ebe0a8f  push r9
0000710e9ebe0a91  push r10
0000710e9ebe0a93  push r11
0000710e9ebe0a95  sub rsp, 0xF0
0000710e9ebe0a9c  vmovaps [rsp], xmm0
0000710e9ebe0aa1  vmovaps [rsp+0x10], xmm1
0000710e9ebe0aa7  vmovaps [rsp+0x20], xmm2
0000710e9ebe0aad  vmovaps [rsp+0x30], xmm3
0000710e9ebe0ab3  vmovaps [rsp+0x40], xmm4
0000710e9ebe0ab9  vmovaps [rsp+0x50], xmm5
0000710e9ebe0abf  vmovaps [rsp+0x60], xmm6
0000710e9ebe0ac5  vmovaps [rsp+0x70], xmm8
0000710e9ebe0acb  vmovaps [rsp+0x80], xmm9
0000710e9ebe0ad4  vmovaps [rsp+0x90], xmm10
0000710e9ebe0add  vmovaps [rsp+0xA0], xmm11
0000710e9ebe0ae6  vmovaps [rsp+0xB0], xmm12
0000710e9ebe0aef  vmovaps [rsp+0xC0], xmm13
0000710e9ebe0af8  vmovaps [rsp+0xD0], xmm14
0000710e9ebe0b01  vmovaps [rsp+0xE0], xmm15
0000710e9ebe0b0a  sub rsp, 0x30
0000710e9ebe0b0e  movaps [rsp], xmm7
0000710e9ebe0b12  movaps [rsp+0x10], xmm4
0000710e9ebe0b17  movaps [rsp+0x20], xmm9
0000710e9ebe0b1d  lea rdi, [rsp]
0000710e9ebe0b21  mov esi, 0x00
0000710e9ebe0b26  mov rax, 0x5DADAF7CF530
0000710e9ebe0b30  call rax
0000710e9ebe0b32  movaps xmm7, [rsp]
0000710e9ebe0b36  add rsp, 0x30
0000710e9ebe0b3a  vmovaps xmm0, [rsp]
0000710e9ebe0b3f  vmovaps xmm1, [rsp+0x10]
0000710e9ebe0b45  vmovaps xmm2, [rsp+0x20]
0000710e9ebe0b4b  vmovaps xmm3, [rsp+0x30]
0000710e9ebe0b51  vmovaps xmm4, [rsp+0x40]
0000710e9ebe0b57  vmovaps xmm5, [rsp+0x50]
0000710e9ebe0b5d  vmovaps xmm6, [rsp+0x60]
0000710e9ebe0b63  vmovaps xmm8, [rsp+0x70]
0000710e9ebe0b69  vmovaps xmm9, [rsp+0x80]
0000710e9ebe0b72  vmovaps xmm10, [rsp+0x90]
0000710e9ebe0b7b  vmovaps xmm11, [rsp+0xA0]
0000710e9ebe0b84  vmovaps xmm12, [rsp+0xB0]
0000710e9ebe0b8d  vmovaps xmm13, [rsp+0xC0]
0000710e9ebe0b96  vmovaps xmm14, [rsp+0xD0]
0000710e9ebe0b9f  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe0ba8  add rsp, 0xF0
0000710e9ebe0baf  pop r11
0000710e9ebe0bb1  pop r10
0000710e9ebe0bb3  pop r9
0000710e9ebe0bb5  pop r8
0000710e9ebe0bb7  pop rsi
0000710e9ebe0bb8  pop rdi
0000710e9ebe0bb9  pop rdx
0000710e9ebe0bba  pop rcx
0000710e9ebe0bbb  pop rax
0000710e9ebe0bbc  add rsp, 0x08
0000710e9ebe0bc0  jmp 0x0000710E9EBDF067
0000710e9ebe0bc5  sub rsp, 0x08
0000710e9ebe0bc9  push rax
0000710e9ebe0bca  push rcx
0000710e9ebe0bcb  push rdx
0000710e9ebe0bcc  push rdi
0000710e9ebe0bcd  push rsi
0000710e9ebe0bce  push r8
0000710e9ebe0bd0  push r9
0000710e9ebe0bd2  push r10
0000710e9ebe0bd4  push r11
0000710e9ebe0bd6  sub rsp, 0xF0
0000710e9ebe0bdd  vmovaps [rsp], xmm0
0000710e9ebe0be2  vmovaps [rsp+0x10], xmm1
0000710e9ebe0be8  vmovaps [rsp+0x20], xmm2
0000710e9ebe0bee  vmovaps [rsp+0x30], xmm3
0000710e9ebe0bf4  vmovaps [rsp+0x40], xmm5
0000710e9ebe0bfa  vmovaps [rsp+0x50], xmm6
0000710e9ebe0c00  vmovaps [rsp+0x60], xmm7
0000710e9ebe0c06  vmovaps [rsp+0x70], xmm8
0000710e9ebe0c0c  vmovaps [rsp+0x80], xmm9
0000710e9ebe0c15  vmovaps [rsp+0x90], xmm10
0000710e9ebe0c1e  vmovaps [rsp+0xA0], xmm11
0000710e9ebe0c27  vmovaps [rsp+0xB0], xmm12
0000710e9ebe0c30  vmovaps [rsp+0xC0], xmm13
0000710e9ebe0c39  vmovaps [rsp+0xD0], xmm14
0000710e9ebe0c42  vmovaps [rsp+0xE0], xmm15
0000710e9ebe0c4b  sub rsp, 0x30
0000710e9ebe0c4f  movaps [rsp], xmm4
0000710e9ebe0c53  movaps [rsp+0x10], xmm15
0000710e9ebe0c59  movaps [rsp+0x20], xmm9
0000710e9ebe0c5f  lea rdi, [rsp]
0000710e9ebe0c63  mov esi, 0x00
0000710e9ebe0c68  mov rax, 0x5DADAF7CF530
0000710e9ebe0c72  call rax
0000710e9ebe0c74  movaps xmm4, [rsp]
0000710e9ebe0c78  add rsp, 0x30
0000710e9ebe0c7c  vmovaps xmm0, [rsp]
0000710e9ebe0c81  vmovaps xmm1, [rsp+0x10]
0000710e9ebe0c87  vmovaps xmm2, [rsp+0x20]
0000710e9ebe0c8d  vmovaps xmm3, [rsp+0x30]
0000710e9ebe0c93  vmovaps xmm5, [rsp+0x40]
0000710e9ebe0c99  vmovaps xmm6, [rsp+0x50]
0000710e9ebe0c9f  vmovaps xmm7, [rsp+0x60]
0000710e9ebe0ca5  vmovaps xmm8, [rsp+0x70]
0000710e9ebe0cab  vmovaps xmm9, [rsp+0x80]
0000710e9ebe0cb4  vmovaps xmm10, [rsp+0x90]
0000710e9ebe0cbd  vmovaps xmm11, [rsp+0xA0]
0000710e9ebe0cc6  vmovaps xmm12, [rsp+0xB0]
0000710e9ebe0ccf  vmovaps xmm13, [rsp+0xC0]
0000710e9ebe0cd8  vmovaps xmm14, [rsp+0xD0]
0000710e9ebe0ce1  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe0cea  add rsp, 0xF0
0000710e9ebe0cf1  pop r11
0000710e9ebe0cf3  pop r10
0000710e9ebe0cf5  pop r9
0000710e9ebe0cf7  pop r8
0000710e9ebe0cf9  pop rsi
0000710e9ebe0cfa  pop rdi
0000710e9ebe0cfb  pop rdx
0000710e9ebe0cfc  pop rcx
0000710e9ebe0cfd  pop rax
0000710e9ebe0cfe  add rsp, 0x08
0000710e9ebe0d02  jmp 0x0000710E9EBDF08C
0000710e9ebe0d07  call 0x0000710E9EAC4620
0000710e9ebe0d0c  jmp 0x0000710E9EBDF099
0000710e9ebe0d11  sub rsp, 0x08
0000710e9ebe0d15  push rax
0000710e9ebe0d16  push rcx
0000710e9ebe0d17  push rdx
0000710e9ebe0d18  push rdi
0000710e9ebe0d19  push rsi
0000710e9ebe0d1a  push r8
0000710e9ebe0d1c  push r9
0000710e9ebe0d1e  push r10
0000710e9ebe0d20  push r11
0000710e9ebe0d22  sub rsp, 0xF0
0000710e9ebe0d29  vmovaps [rsp], xmm0
0000710e9ebe0d2e  vmovaps [rsp+0x10], xmm1
0000710e9ebe0d34  vmovaps [rsp+0x20], xmm2
0000710e9ebe0d3a  vmovaps [rsp+0x30], xmm4
0000710e9ebe0d40  vmovaps [rsp+0x40], xmm5
0000710e9ebe0d46  vmovaps [rsp+0x50], xmm6
0000710e9ebe0d4c  vmovaps [rsp+0x60], xmm7
0000710e9ebe0d52  vmovaps [rsp+0x70], xmm8
0000710e9ebe0d58  vmovaps [rsp+0x80], xmm9
0000710e9ebe0d61  vmovaps [rsp+0x90], xmm10
0000710e9ebe0d6a  vmovaps [rsp+0xA0], xmm11
0000710e9ebe0d73  vmovaps [rsp+0xB0], xmm12
0000710e9ebe0d7c  vmovaps [rsp+0xC0], xmm13
0000710e9ebe0d85  vmovaps [rsp+0xD0], xmm14
0000710e9ebe0d8e  vmovaps [rsp+0xE0], xmm15
0000710e9ebe0d97  sub rsp, 0x30
0000710e9ebe0d9b  movaps [rsp], xmm3
0000710e9ebe0d9f  movaps [rsp+0x10], xmm1
0000710e9ebe0da4  movaps [rsp+0x20], xmm9
0000710e9ebe0daa  lea rdi, [rsp]
0000710e9ebe0dae  mov esi, 0x00
0000710e9ebe0db3  mov rax, 0x5DADAF7CF530
0000710e9ebe0dbd  call rax
0000710e9ebe0dbf  movaps xmm3, [rsp]
0000710e9ebe0dc3  add rsp, 0x30
0000710e9ebe0dc7  vmovaps xmm0, [rsp]
0000710e9ebe0dcc  vmovaps xmm1, [rsp+0x10]
0000710e9ebe0dd2  vmovaps xmm2, [rsp+0x20]
0000710e9ebe0dd8  vmovaps xmm4, [rsp+0x30]
0000710e9ebe0dde  vmovaps xmm5, [rsp+0x40]
0000710e9ebe0de4  vmovaps xmm6, [rsp+0x50]
0000710e9ebe0dea  vmovaps xmm7, [rsp+0x60]
0000710e9ebe0df0  vmovaps xmm8, [rsp+0x70]
0000710e9ebe0df6  vmovaps xmm9, [rsp+0x80]
0000710e9ebe0dff  vmovaps xmm10, [rsp+0x90]
0000710e9ebe0e08  vmovaps xmm11, [rsp+0xA0]
0000710e9ebe0e11  vmovaps xmm12, [rsp+0xB0]
0000710e9ebe0e1a  vmovaps xmm13, [rsp+0xC0]
0000710e9ebe0e23  vmovaps xmm14, [rsp+0xD0]
0000710e9ebe0e2c  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe0e35  add rsp, 0xF0
0000710e9ebe0e3c  pop r11
0000710e9ebe0e3e  pop r10
0000710e9ebe0e40  pop r9
0000710e9ebe0e42  pop r8
0000710e9ebe0e44  pop rsi
0000710e9ebe0e45  pop rdi
0000710e9ebe0e46  pop rdx
0000710e9ebe0e47  pop rcx
0000710e9ebe0e48  pop rax
0000710e9ebe0e49  add rsp, 0x08
0000710e9ebe0e4d  jmp 0x0000710E9EBDF0D6
0000710e9ebe0e52  sub rsp, 0x08
0000710e9ebe0e56  push rax
0000710e9ebe0e57  push rcx
0000710e9ebe0e58  push rdx
0000710e9ebe0e59  push rdi
0000710e9ebe0e5a  push rsi
0000710e9ebe0e5b  push r8
0000710e9ebe0e5d  push r9
0000710e9ebe0e5f  push r10
0000710e9ebe0e61  push r11
0000710e9ebe0e63  sub rsp, 0xF0
0000710e9ebe0e6a  vmovaps [rsp], xmm0
0000710e9ebe0e6f  vmovaps [rsp+0x10], xmm2
0000710e9ebe0e75  vmovaps [rsp+0x20], xmm3
0000710e9ebe0e7b  vmovaps [rsp+0x30], xmm4
0000710e9ebe0e81  vmovaps [rsp+0x40], xmm5
0000710e9ebe0e87  vmovaps [rsp+0x50], xmm6
0000710e9ebe0e8d  vmovaps [rsp+0x60], xmm7
0000710e9ebe0e93  vmovaps [rsp+0x70], xmm8
0000710e9ebe0e99  vmovaps [rsp+0x80], xmm9
0000710e9ebe0ea2  vmovaps [rsp+0x90], xmm10
0000710e9ebe0eab  vmovaps [rsp+0xA0], xmm11
0000710e9ebe0eb4  vmovaps [rsp+0xB0], xmm12
0000710e9ebe0ebd  vmovaps [rsp+0xC0], xmm13
0000710e9ebe0ec6  vmovaps [rsp+0xD0], xmm14
0000710e9ebe0ecf  vmovaps [rsp+0xE0], xmm15
0000710e9ebe0ed8  sub rsp, 0x30
0000710e9ebe0edc  movaps [rsp], xmm1
0000710e9ebe0ee0  movaps [rsp+0x10], xmm15
0000710e9ebe0ee6  movaps [rsp+0x20], xmm9
0000710e9ebe0eec  lea rdi, [rsp]
0000710e9ebe0ef0  mov esi, 0x00
0000710e9ebe0ef5  mov rax, 0x5DADAF7CF530
0000710e9ebe0eff  call rax
0000710e9ebe0f01  movaps xmm1, [rsp]
0000710e9ebe0f05  add rsp, 0x30
0000710e9ebe0f09  vmovaps xmm0, [rsp]
0000710e9ebe0f0e  vmovaps xmm2, [rsp+0x10]
0000710e9ebe0f14  vmovaps xmm3, [rsp+0x20]
0000710e9ebe0f1a  vmovaps xmm4, [rsp+0x30]
0000710e9ebe0f20  vmovaps xmm5, [rsp+0x40]
0000710e9ebe0f26  vmovaps xmm6, [rsp+0x50]
0000710e9ebe0f2c  vmovaps xmm7, [rsp+0x60]
0000710e9ebe0f32  vmovaps xmm8, [rsp+0x70]
0000710e9ebe0f38  vmovaps xmm9, [rsp+0x80]
0000710e9ebe0f41  vmovaps xmm10, [rsp+0x90]
0000710e9ebe0f4a  vmovaps xmm11, [rsp+0xA0]
0000710e9ebe0f53  vmovaps xmm12, [rsp+0xB0]
0000710e9ebe0f5c  vmovaps xmm13, [rsp+0xC0]
0000710e9ebe0f65  vmovaps xmm14, [rsp+0xD0]
0000710e9ebe0f6e  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe0f77  add rsp, 0xF0
0000710e9ebe0f7e  pop r11
0000710e9ebe0f80  pop r10
0000710e9ebe0f82  pop r9
0000710e9ebe0f84  pop r8
0000710e9ebe0f86  pop rsi
0000710e9ebe0f87  pop rdi
0000710e9ebe0f88  pop rdx
0000710e9ebe0f89  pop rcx
0000710e9ebe0f8a  pop rax
0000710e9ebe0f8b  add rsp, 0x08
0000710e9ebe0f8f  jmp 0x0000710E9EBDF15E
0000710e9ebe0f94  call 0x0000710E9EAC4620
0000710e9ebe0f99  jmp 0x0000710E9EBDF16B
0000710e9ebe0f9e  sub rsp, 0x08
0000710e9ebe0fa2  push rax
0000710e9ebe0fa3  push rcx
0000710e9ebe0fa4  push rdx
0000710e9ebe0fa5  push rdi
0000710e9ebe0fa6  push rsi
0000710e9ebe0fa7  push r8
0000710e9ebe0fa9  push r9
0000710e9ebe0fab  push r10
0000710e9ebe0fad  push r11
0000710e9ebe0faf  sub rsp, 0xF0
0000710e9ebe0fb6  vmovaps [rsp], xmm0
0000710e9ebe0fbb  vmovaps [rsp+0x10], xmm2
0000710e9ebe0fc1  vmovaps [rsp+0x20], xmm3
0000710e9ebe0fc7  vmovaps [rsp+0x30], xmm4
0000710e9ebe0fcd  vmovaps [rsp+0x40], xmm5
0000710e9ebe0fd3  vmovaps [rsp+0x50], xmm6
0000710e9ebe0fd9  vmovaps [rsp+0x60], xmm7
0000710e9ebe0fdf  vmovaps [rsp+0x70], xmm8
0000710e9ebe0fe5  vmovaps [rsp+0x80], xmm9
0000710e9ebe0fee  vmovaps [rsp+0x90], xmm10
0000710e9ebe0ff7  vmovaps [rsp+0xA0], xmm11
0000710e9ebe1000  vmovaps [rsp+0xB0], xmm12
0000710e9ebe1009  vmovaps [rsp+0xC0], xmm13
0000710e9ebe1012  vmovaps [rsp+0xD0], xmm14
0000710e9ebe101b  vmovaps [rsp+0xE0], xmm15
0000710e9ebe1024  sub rsp, 0x30
0000710e9ebe1028  movaps [rsp], xmm1
0000710e9ebe102c  movaps [rsp+0x10], xmm5
0000710e9ebe1031  movaps [rsp+0x20], xmm7
0000710e9ebe1036  lea rdi, [rsp]
0000710e9ebe103a  mov esi, 0x00
0000710e9ebe103f  mov rax, 0x5DADAF7CF530
0000710e9ebe1049  call rax
0000710e9ebe104b  movaps xmm1, [rsp]
0000710e9ebe104f  add rsp, 0x30
0000710e9ebe1053  vmovaps xmm0, [rsp]
0000710e9ebe1058  vmovaps xmm2, [rsp+0x10]
0000710e9ebe105e  vmovaps xmm3, [rsp+0x20]
0000710e9ebe1064  vmovaps xmm4, [rsp+0x30]
0000710e9ebe106a  vmovaps xmm5, [rsp+0x40]
0000710e9ebe1070  vmovaps xmm6, [rsp+0x50]
0000710e9ebe1076  vmovaps xmm7, [rsp+0x60]
0000710e9ebe107c  vmovaps xmm8, [rsp+0x70]
0000710e9ebe1082  vmovaps xmm9, [rsp+0x80]
0000710e9ebe108b  vmovaps xmm10, [rsp+0x90]
0000710e9ebe1094  vmovaps xmm11, [rsp+0xA0]
0000710e9ebe109d  vmovaps xmm12, [rsp+0xB0]
0000710e9ebe10a6  vmovaps xmm13, [rsp+0xC0]
0000710e9ebe10af  vmovaps xmm14, [rsp+0xD0]
0000710e9ebe10b8  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe10c1  add rsp, 0xF0
0000710e9ebe10c8  pop r11
0000710e9ebe10ca  pop r10
0000710e9ebe10cc  pop r9
0000710e9ebe10ce  pop r8
0000710e9ebe10d0  pop rsi
0000710e9ebe10d1  pop rdi
0000710e9ebe10d2  pop rdx
0000710e9ebe10d3  pop rcx
0000710e9ebe10d4  pop rax
0000710e9ebe10d5  add rsp, 0x08
0000710e9ebe10d9  jmp 0x0000710E9EBDF210
0000710e9ebe10de  sub rsp, 0x08
0000710e9ebe10e2  push rax
0000710e9ebe10e3  push rcx
0000710e9ebe10e4  push rdx
0000710e9ebe10e5  push rdi
0000710e9ebe10e6  push rsi
0000710e9ebe10e7  push r8
0000710e9ebe10e9  push r9
0000710e9ebe10eb  push r10
0000710e9ebe10ed  push r11
0000710e9ebe10ef  sub rsp, 0xF0
0000710e9ebe10f6  vmovaps [rsp], xmm0
0000710e9ebe10fb  vmovaps [rsp+0x10], xmm1
0000710e9ebe1101  vmovaps [rsp+0x20], xmm2
0000710e9ebe1107  vmovaps [rsp+0x30], xmm3
0000710e9ebe110d  vmovaps [rsp+0x40], xmm4
0000710e9ebe1113  vmovaps [rsp+0x50], xmm5
0000710e9ebe1119  vmovaps [rsp+0x60], xmm6
0000710e9ebe111f  vmovaps [rsp+0x70], xmm8
0000710e9ebe1125  vmovaps [rsp+0x80], xmm9
0000710e9ebe112e  vmovaps [rsp+0x90], xmm10
0000710e9ebe1137  vmovaps [rsp+0xA0], xmm11
0000710e9ebe1140  vmovaps [rsp+0xB0], xmm12
0000710e9ebe1149  vmovaps [rsp+0xC0], xmm13
0000710e9ebe1152  vmovaps [rsp+0xD0], xmm14
0000710e9ebe115b  vmovaps [rsp+0xE0], xmm15
0000710e9ebe1164  sub rsp, 0x30
0000710e9ebe1168  movaps [rsp], xmm7
0000710e9ebe116c  movaps [rsp+0x10], xmm5
0000710e9ebe1171  movaps [rsp+0x20], xmm15
0000710e9ebe1177  lea rdi, [rsp]
0000710e9ebe117b  mov esi, 0x00
0000710e9ebe1180  mov rax, 0x5DADAF7CF530
0000710e9ebe118a  call rax
0000710e9ebe118c  movaps xmm7, [rsp]
0000710e9ebe1190  add rsp, 0x30
0000710e9ebe1194  vmovaps xmm0, [rsp]
0000710e9ebe1199  vmovaps xmm1, [rsp+0x10]
0000710e9ebe119f  vmovaps xmm2, [rsp+0x20]
0000710e9ebe11a5  vmovaps xmm3, [rsp+0x30]
0000710e9ebe11ab  vmovaps xmm4, [rsp+0x40]
0000710e9ebe11b1  vmovaps xmm5, [rsp+0x50]
0000710e9ebe11b7  vmovaps xmm6, [rsp+0x60]
0000710e9ebe11bd  vmovaps xmm8, [rsp+0x70]
0000710e9ebe11c3  vmovaps xmm9, [rsp+0x80]
0000710e9ebe11cc  vmovaps xmm10, [rsp+0x90]
0000710e9ebe11d5  vmovaps xmm11, [rsp+0xA0]
0000710e9ebe11de  vmovaps xmm12, [rsp+0xB0]
0000710e9ebe11e7  vmovaps xmm13, [rsp+0xC0]
0000710e9ebe11f0  vmovaps xmm14, [rsp+0xD0]
0000710e9ebe11f9  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe1202  add rsp, 0xF0
0000710e9ebe1209  pop r11
0000710e9ebe120b  pop r10
0000710e9ebe120d  pop r9
0000710e9ebe120f  pop r8
0000710e9ebe1211  pop rsi
0000710e9ebe1212  pop rdi
0000710e9ebe1213  pop rdx
0000710e9ebe1214  pop rcx
0000710e9ebe1215  pop rax
0000710e9ebe1216  add rsp, 0x08
0000710e9ebe121a  jmp 0x0000710E9EBDF246
0000710e9ebe121f  call 0x0000710E9EAB52F0
0000710e9ebe1224  jmp 0x0000710E9EBDF253
0000710e9ebe1229  sub rsp, 0x08
0000710e9ebe122d  push rax
0000710e9ebe122e  push rcx
0000710e9ebe122f  push rdx
0000710e9ebe1230  push rdi
0000710e9ebe1231  push rsi
0000710e9ebe1232  push r8
0000710e9ebe1234  push r9
0000710e9ebe1236  push r10
0000710e9ebe1238  push r11
0000710e9ebe123a  sub rsp, 0xF0
0000710e9ebe1241  vmovaps [rsp], xmm0
0000710e9ebe1246  vmovaps [rsp+0x10], xmm1
0000710e9ebe124c  vmovaps [rsp+0x20], xmm2
0000710e9ebe1252  vmovaps [rsp+0x30], xmm3
0000710e9ebe1258  vmovaps [rsp+0x40], xmm4
0000710e9ebe125e  vmovaps [rsp+0x50], xmm5
0000710e9ebe1264  vmovaps [rsp+0x60], xmm6
0000710e9ebe126a  vmovaps [rsp+0x70], xmm7
0000710e9ebe1270  vmovaps [rsp+0x80], xmm8
0000710e9ebe1279  vmovaps [rsp+0x90], xmm9
0000710e9ebe1282  vmovaps [rsp+0xA0], xmm10
0000710e9ebe128b  vmovaps [rsp+0xB0], xmm11
0000710e9ebe1294  vmovaps [rsp+0xC0], xmm12
0000710e9ebe129d  vmovaps [rsp+0xD0], xmm13
0000710e9ebe12a6  vmovaps [rsp+0xE0], xmm14
0000710e9ebe12af  sub rsp, 0x30
0000710e9ebe12b3  movaps [rsp], xmm15
0000710e9ebe12b8  movaps [rsp+0x10], xmm5
0000710e9ebe12bd  movaps [rsp+0x20], xmm3
0000710e9ebe12c2  lea rdi, [rsp]
0000710e9ebe12c6  mov esi, 0x00
0000710e9ebe12cb  mov rax, 0x5DADAF7CF530
0000710e9ebe12d5  call rax
0000710e9ebe12d7  movaps xmm15, [rsp]
0000710e9ebe12dc  add rsp, 0x30
0000710e9ebe12e0  vmovaps xmm0, [rsp]
0000710e9ebe12e5  vmovaps xmm1, [rsp+0x10]
0000710e9ebe12eb  vmovaps xmm2, [rsp+0x20]
0000710e9ebe12f1  vmovaps xmm3, [rsp+0x30]
0000710e9ebe12f7  vmovaps xmm4, [rsp+0x40]
0000710e9ebe12fd  vmovaps xmm5, [rsp+0x50]
0000710e9ebe1303  vmovaps xmm6, [rsp+0x60]
0000710e9ebe1309  vmovaps xmm7, [rsp+0x70]
0000710e9ebe130f  vmovaps xmm8, [rsp+0x80]
0000710e9ebe1318  vmovaps xmm9, [rsp+0x90]
0000710e9ebe1321  vmovaps xmm10, [rsp+0xA0]
0000710e9ebe132a  vmovaps xmm11, [rsp+0xB0]
0000710e9ebe1333  vmovaps xmm12, [rsp+0xC0]
0000710e9ebe133c  vmovaps xmm13, [rsp+0xD0]
0000710e9ebe1345  vmovaps xmm14, [rsp+0xE0]
0000710e9ebe134e  add rsp, 0xF0
0000710e9ebe1355  pop r11
0000710e9ebe1357  pop r10
0000710e9ebe1359  pop r9
0000710e9ebe135b  pop r8
0000710e9ebe135d  pop rsi
0000710e9ebe135e  pop rdi
0000710e9ebe135f  pop rdx
0000710e9ebe1360  pop rcx
0000710e9ebe1361  pop rax
0000710e9ebe1362  add rsp, 0x08
0000710e9ebe1366  jmp 0x0000710E9EBDF279
0000710e9ebe136b  sub rsp, 0x08
0000710e9ebe136f  push rax
0000710e9ebe1370  push rcx
0000710e9ebe1371  push rdx
0000710e9ebe1372  push rdi
0000710e9ebe1373  push rsi
0000710e9ebe1374  push r8
0000710e9ebe1376  push r9
0000710e9ebe1378  push r10
0000710e9ebe137a  push r11
0000710e9ebe137c  sub rsp, 0xF0
0000710e9ebe1383  vmovaps [rsp], xmm0
0000710e9ebe1388  vmovaps [rsp+0x10], xmm2
0000710e9ebe138e  vmovaps [rsp+0x20], xmm3
0000710e9ebe1394  vmovaps [rsp+0x30], xmm4
0000710e9ebe139a  vmovaps [rsp+0x40], xmm5
0000710e9ebe13a0  vmovaps [rsp+0x50], xmm6
0000710e9ebe13a6  vmovaps [rsp+0x60], xmm7
0000710e9ebe13ac  vmovaps [rsp+0x70], xmm8
0000710e9ebe13b2  vmovaps [rsp+0x80], xmm9
0000710e9ebe13bb  vmovaps [rsp+0x90], xmm10
0000710e9ebe13c4  vmovaps [rsp+0xA0], xmm11
0000710e9ebe13cd  vmovaps [rsp+0xB0], xmm12
0000710e9ebe13d6  vmovaps [rsp+0xC0], xmm13
0000710e9ebe13df  vmovaps [rsp+0xD0], xmm14
0000710e9ebe13e8  vmovaps [rsp+0xE0], xmm15
0000710e9ebe13f1  sub rsp, 0x30
0000710e9ebe13f5  movaps [rsp], xmm1
0000710e9ebe13f9  movaps [rsp+0x10], xmm5
0000710e9ebe13fe  movaps [rsp+0x20], xmm4
0000710e9ebe1403  lea rdi, [rsp]
0000710e9ebe1407  mov esi, 0x00
0000710e9ebe140c  mov rax, 0x5DADAF7CF530
0000710e9ebe1416  call rax
0000710e9ebe1418  movaps xmm1, [rsp]
0000710e9ebe141c  add rsp, 0x30
0000710e9ebe1420  vmovaps xmm0, [rsp]
0000710e9ebe1425  vmovaps xmm2, [rsp+0x10]
0000710e9ebe142b  vmovaps xmm3, [rsp+0x20]
0000710e9ebe1431  vmovaps xmm4, [rsp+0x30]
0000710e9ebe1437  vmovaps xmm5, [rsp+0x40]
0000710e9ebe143d  vmovaps xmm6, [rsp+0x50]
0000710e9ebe1443  vmovaps xmm7, [rsp+0x60]
0000710e9ebe1449  vmovaps xmm8, [rsp+0x70]
0000710e9ebe144f  vmovaps xmm9, [rsp+0x80]
0000710e9ebe1458  vmovaps xmm10, [rsp+0x90]
0000710e9ebe1461  vmovaps xmm11, [rsp+0xA0]
0000710e9ebe146a  vmovaps xmm12, [rsp+0xB0]
0000710e9ebe1473  vmovaps xmm13, [rsp+0xC0]
0000710e9ebe147c  vmovaps xmm14, [rsp+0xD0]
0000710e9ebe1485  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe148e  add rsp, 0xF0
0000710e9ebe1495  pop r11
0000710e9ebe1497  pop r10
0000710e9ebe1499  pop r9
0000710e9ebe149b  pop r8
0000710e9ebe149d  pop rsi
0000710e9ebe149e  pop rdi
0000710e9ebe149f  pop rdx
0000710e9ebe14a0  pop rcx
0000710e9ebe14a1  pop rax
0000710e9ebe14a2  add rsp, 0x08
0000710e9ebe14a6  jmp 0x0000710E9EBDF299
0000710e9ebe14ab  sub rsp, 0x08
0000710e9ebe14af  push rax
0000710e9ebe14b0  push rcx
0000710e9ebe14b1  push rdx
0000710e9ebe14b2  push rdi
0000710e9ebe14b3  push rsi
0000710e9ebe14b4  push r8
0000710e9ebe14b6  push r9
0000710e9ebe14b8  push r10
0000710e9ebe14ba  push r11
0000710e9ebe14bc  sub rsp, 0xF0
0000710e9ebe14c3  vmovaps [rsp], xmm0
0000710e9ebe14c8  vmovaps [rsp+0x10], xmm1
0000710e9ebe14ce  vmovaps [rsp+0x20], xmm2
0000710e9ebe14d4  vmovaps [rsp+0x30], xmm3
0000710e9ebe14da  vmovaps [rsp+0x40], xmm5
0000710e9ebe14e0  vmovaps [rsp+0x50], xmm6
0000710e9ebe14e6  vmovaps [rsp+0x60], xmm7
0000710e9ebe14ec  vmovaps [rsp+0x70], xmm8
0000710e9ebe14f2  vmovaps [rsp+0x80], xmm9
0000710e9ebe14fb  vmovaps [rsp+0x90], xmm10
0000710e9ebe1504  vmovaps [rsp+0xA0], xmm11
0000710e9ebe150d  vmovaps [rsp+0xB0], xmm12
0000710e9ebe1516  vmovaps [rsp+0xC0], xmm13
0000710e9ebe151f  vmovaps [rsp+0xD0], xmm14
0000710e9ebe1528  vmovaps [rsp+0xE0], xmm15
0000710e9ebe1531  sub rsp, 0x30
0000710e9ebe1535  movaps [rsp], xmm4
0000710e9ebe1539  movaps [rsp+0x10], xmm3
0000710e9ebe153e  movaps [rsp+0x20], xmm5
0000710e9ebe1543  lea rdi, [rsp]
0000710e9ebe1547  mov esi, 0x00
0000710e9ebe154c  mov rax, 0x5DADAF7CF530
0000710e9ebe1556  call rax
0000710e9ebe1558  movaps xmm4, [rsp]
0000710e9ebe155c  add rsp, 0x30
0000710e9ebe1560  vmovaps xmm0, [rsp]
0000710e9ebe1565  vmovaps xmm1, [rsp+0x10]
0000710e9ebe156b  vmovaps xmm2, [rsp+0x20]
0000710e9ebe1571  vmovaps xmm3, [rsp+0x30]
0000710e9ebe1577  vmovaps xmm5, [rsp+0x40]
0000710e9ebe157d  vmovaps xmm6, [rsp+0x50]
0000710e9ebe1583  vmovaps xmm7, [rsp+0x60]
0000710e9ebe1589  vmovaps xmm8, [rsp+0x70]
0000710e9ebe158f  vmovaps xmm9, [rsp+0x80]
0000710e9ebe1598  vmovaps xmm10, [rsp+0x90]
0000710e9ebe15a1  vmovaps xmm11, [rsp+0xA0]
0000710e9ebe15aa  vmovaps xmm12, [rsp+0xB0]
0000710e9ebe15b3  vmovaps xmm13, [rsp+0xC0]
0000710e9ebe15bc  vmovaps xmm14, [rsp+0xD0]
0000710e9ebe15c5  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe15ce  add rsp, 0xF0
0000710e9ebe15d5  pop r11
0000710e9ebe15d7  pop r10
0000710e9ebe15d9  pop r9
0000710e9ebe15db  pop r8
0000710e9ebe15dd  pop rsi
0000710e9ebe15de  pop rdi
0000710e9ebe15df  pop rdx
0000710e9ebe15e0  pop rcx
0000710e9ebe15e1  pop rax
0000710e9ebe15e2  add rsp, 0x08
0000710e9ebe15e6  jmp 0x0000710E9EBDF2E7
0000710e9ebe15eb  call 0x0000710E9EAB52F0
0000710e9ebe15f0  jmp 0x0000710E9EBDF2F4
0000710e9ebe15f5  sub rsp, 0x08
0000710e9ebe15f9  push rax
0000710e9ebe15fa  push rcx
0000710e9ebe15fb  push rdx
0000710e9ebe15fc  push rdi
0000710e9ebe15fd  push rsi
0000710e9ebe15fe  push r8
0000710e9ebe1600  push r9
0000710e9ebe1602  push r10
0000710e9ebe1604  push r11
0000710e9ebe1606  sub rsp, 0xF0
0000710e9ebe160d  vmovaps [rsp], xmm0
0000710e9ebe1612  vmovaps [rsp+0x10], xmm1
0000710e9ebe1618  vmovaps [rsp+0x20], xmm2
0000710e9ebe161e  vmovaps [rsp+0x30], xmm3
0000710e9ebe1624  vmovaps [rsp+0x40], xmm4
0000710e9ebe162a  vmovaps [rsp+0x50], xmm6
0000710e9ebe1630  vmovaps [rsp+0x60], xmm7
0000710e9ebe1636  vmovaps [rsp+0x70], xmm8
0000710e9ebe163c  vmovaps [rsp+0x80], xmm9
0000710e9ebe1645  vmovaps [rsp+0x90], xmm10
0000710e9ebe164e  vmovaps [rsp+0xA0], xmm11
0000710e9ebe1657  vmovaps [rsp+0xB0], xmm12
0000710e9ebe1660  vmovaps [rsp+0xC0], xmm13
0000710e9ebe1669  vmovaps [rsp+0xD0], xmm14
0000710e9ebe1672  vmovaps [rsp+0xE0], xmm15
0000710e9ebe167b  sub rsp, 0x30
0000710e9ebe167f  movaps [rsp], xmm5
0000710e9ebe1683  movaps [rsp+0x10], xmm6
0000710e9ebe1688  movaps [rsp+0x20], xmm3
0000710e9ebe168d  lea rdi, [rsp]
0000710e9ebe1691  mov esi, 0x00
0000710e9ebe1696  mov rax, 0x5DADAF7CF530
0000710e9ebe16a0  call rax
0000710e9ebe16a2  movaps xmm5, [rsp]
0000710e9ebe16a6  add rsp, 0x30
0000710e9ebe16aa  vmovaps xmm0, [rsp]
0000710e9ebe16af  vmovaps xmm1, [rsp+0x10]
0000710e9ebe16b5  vmovaps xmm2, [rsp+0x20]
0000710e9ebe16bb  vmovaps xmm3, [rsp+0x30]
0000710e9ebe16c1  vmovaps xmm4, [rsp+0x40]
0000710e9ebe16c7  vmovaps xmm6, [rsp+0x50]
0000710e9ebe16cd  vmovaps xmm7, [rsp+0x60]
0000710e9ebe16d3  vmovaps xmm8, [rsp+0x70]
0000710e9ebe16d9  vmovaps xmm9, [rsp+0x80]
0000710e9ebe16e2  vmovaps xmm10, [rsp+0x90]
0000710e9ebe16eb  vmovaps xmm11, [rsp+0xA0]
0000710e9ebe16f4  vmovaps xmm12, [rsp+0xB0]
0000710e9ebe16fd  vmovaps xmm13, [rsp+0xC0]
0000710e9ebe1706  vmovaps xmm14, [rsp+0xD0]
0000710e9ebe170f  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe1718  add rsp, 0xF0
0000710e9ebe171f  pop r11
0000710e9ebe1721  pop r10
0000710e9ebe1723  pop r9
0000710e9ebe1725  pop r8
0000710e9ebe1727  pop rsi
0000710e9ebe1728  pop rdi
0000710e9ebe1729  pop rdx
0000710e9ebe172a  pop rcx
0000710e9ebe172b  pop rax
0000710e9ebe172c  add rsp, 0x08
0000710e9ebe1730  jmp 0x0000710E9EBDF31A
0000710e9ebe1735  sub rsp, 0x08
0000710e9ebe1739  push rax
0000710e9ebe173a  push rcx
0000710e9ebe173b  push rdx
0000710e9ebe173c  push rdi
0000710e9ebe173d  push rsi
0000710e9ebe173e  push r8
0000710e9ebe1740  push r9
0000710e9ebe1742  push r10
0000710e9ebe1744  push r11
0000710e9ebe1746  sub rsp, 0xF0
0000710e9ebe174d  vmovaps [rsp], xmm0
0000710e9ebe1752  vmovaps [rsp+0x10], xmm1
0000710e9ebe1758  vmovaps [rsp+0x20], xmm2
0000710e9ebe175e  vmovaps [rsp+0x30], xmm3
0000710e9ebe1764  vmovaps [rsp+0x40], xmm4
0000710e9ebe176a  vmovaps [rsp+0x50], xmm5
0000710e9ebe1770  vmovaps [rsp+0x60], xmm7
0000710e9ebe1776  vmovaps [rsp+0x70], xmm8
0000710e9ebe177c  vmovaps [rsp+0x80], xmm9
0000710e9ebe1785  vmovaps [rsp+0x90], xmm10
0000710e9ebe178e  vmovaps [rsp+0xA0], xmm11
0000710e9ebe1797  vmovaps [rsp+0xB0], xmm12
0000710e9ebe17a0  vmovaps [rsp+0xC0], xmm13
0000710e9ebe17a9  vmovaps [rsp+0xD0], xmm14
0000710e9ebe17b2  vmovaps [rsp+0xE0], xmm15
0000710e9ebe17bb  sub rsp, 0x30
0000710e9ebe17bf  movaps [rsp], xmm6
0000710e9ebe17c3  movaps [rsp+0x10], xmm9
0000710e9ebe17c9  movaps [rsp+0x20], xmm1
0000710e9ebe17ce  lea rdi, [rsp]
0000710e9ebe17d2  mov esi, 0x00
0000710e9ebe17d7  mov rax, 0x5DADAF7CF530
0000710e9ebe17e1  call rax
0000710e9ebe17e3  movaps xmm6, [rsp]
0000710e9ebe17e7  add rsp, 0x30
0000710e9ebe17eb  vmovaps xmm0, [rsp]
0000710e9ebe17f0  vmovaps xmm1, [rsp+0x10]
0000710e9ebe17f6  vmovaps xmm2, [rsp+0x20]
0000710e9ebe17fc  vmovaps xmm3, [rsp+0x30]
0000710e9ebe1802  vmovaps xmm4, [rsp+0x40]
0000710e9ebe1808  vmovaps xmm5, [rsp+0x50]
0000710e9ebe180e  vmovaps xmm7, [rsp+0x60]
0000710e9ebe1814  vmovaps xmm8, [rsp+0x70]
0000710e9ebe181a  vmovaps xmm9, [rsp+0x80]
0000710e9ebe1823  vmovaps xmm10, [rsp+0x90]
0000710e9ebe182c  vmovaps xmm11, [rsp+0xA0]
0000710e9ebe1835  vmovaps xmm12, [rsp+0xB0]
0000710e9ebe183e  vmovaps xmm13, [rsp+0xC0]
0000710e9ebe1847  vmovaps xmm14, [rsp+0xD0]
0000710e9ebe1850  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe1859  add rsp, 0xF0
0000710e9ebe1860  pop r11
0000710e9ebe1862  pop r10
0000710e9ebe1864  pop r9
0000710e9ebe1866  pop r8
0000710e9ebe1868  pop rsi
0000710e9ebe1869  pop rdi
0000710e9ebe186a  pop rdx
0000710e9ebe186b  pop rcx
0000710e9ebe186c  pop rax
0000710e9ebe186d  add rsp, 0x08
0000710e9ebe1871  jmp 0x0000710E9EBDF33E
0000710e9ebe1876  sub rsp, 0x08
0000710e9ebe187a  push rax
0000710e9ebe187b  push rcx
0000710e9ebe187c  push rdx
0000710e9ebe187d  push rdi
0000710e9ebe187e  push rsi
0000710e9ebe187f  push r8
0000710e9ebe1881  push r9
0000710e9ebe1883  push r10
0000710e9ebe1885  push r11
0000710e9ebe1887  sub rsp, 0xF0
0000710e9ebe188e  vmovaps [rsp], xmm0
0000710e9ebe1893  vmovaps [rsp+0x10], xmm1
0000710e9ebe1899  vmovaps [rsp+0x20], xmm2
0000710e9ebe189f  vmovaps [rsp+0x30], xmm3
0000710e9ebe18a5  vmovaps [rsp+0x40], xmm4
0000710e9ebe18ab  vmovaps [rsp+0x50], xmm5
0000710e9ebe18b1  vmovaps [rsp+0x60], xmm6
0000710e9ebe18b7  vmovaps [rsp+0x70], xmm7
0000710e9ebe18bd  vmovaps [rsp+0x80], xmm8
0000710e9ebe18c6  vmovaps [rsp+0x90], xmm10
0000710e9ebe18cf  vmovaps [rsp+0xA0], xmm11
0000710e9ebe18d8  vmovaps [rsp+0xB0], xmm12
0000710e9ebe18e1  vmovaps [rsp+0xC0], xmm13
0000710e9ebe18ea  vmovaps [rsp+0xD0], xmm14
0000710e9ebe18f3  vmovaps [rsp+0xE0], xmm15
0000710e9ebe18fc  sub rsp, 0x30
0000710e9ebe1900  movaps [rsp], xmm9
0000710e9ebe1905  movaps [rsp+0x10], xmm3
0000710e9ebe190a  movaps [rsp+0x20], xmm1
0000710e9ebe190f  lea rdi, [rsp]
0000710e9ebe1913  mov esi, 0x00
0000710e9ebe1918  mov rax, 0x5DADAF7CF530
0000710e9ebe1922  call rax
0000710e9ebe1924  movaps xmm9, [rsp]
0000710e9ebe1929  add rsp, 0x30
0000710e9ebe192d  vmovaps xmm0, [rsp]
0000710e9ebe1932  vmovaps xmm1, [rsp+0x10]
0000710e9ebe1938  vmovaps xmm2, [rsp+0x20]
0000710e9ebe193e  vmovaps xmm3, [rsp+0x30]
0000710e9ebe1944  vmovaps xmm4, [rsp+0x40]
0000710e9ebe194a  vmovaps xmm5, [rsp+0x50]
0000710e9ebe1950  vmovaps xmm6, [rsp+0x60]
0000710e9ebe1956  vmovaps xmm7, [rsp+0x70]
0000710e9ebe195c  vmovaps xmm8, [rsp+0x80]
0000710e9ebe1965  vmovaps xmm10, [rsp+0x90]
0000710e9ebe196e  vmovaps xmm11, [rsp+0xA0]
0000710e9ebe1977  vmovaps xmm12, [rsp+0xB0]
0000710e9ebe1980  vmovaps xmm13, [rsp+0xC0]
0000710e9ebe1989  vmovaps xmm14, [rsp+0xD0]
0000710e9ebe1992  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe199b  add rsp, 0xF0
0000710e9ebe19a2  pop r11
0000710e9ebe19a4  pop r10
0000710e9ebe19a6  pop r9
0000710e9ebe19a8  pop r8
0000710e9ebe19aa  pop rsi
0000710e9ebe19ab  pop rdi
0000710e9ebe19ac  pop rdx
0000710e9ebe19ad  pop rcx
0000710e9ebe19ae  pop rax
0000710e9ebe19af  add rsp, 0x08
0000710e9ebe19b3  jmp 0x0000710E9EBDF38A
0000710e9ebe19b8  call 0x0000710E9EAB52F0
0000710e9ebe19bd  jmp 0x0000710E9EBDF397
0000710e9ebe19c2  sub rsp, 0x08
0000710e9ebe19c6  push rax
0000710e9ebe19c7  push rcx
0000710e9ebe19c8  push rdx
0000710e9ebe19c9  push rdi
0000710e9ebe19ca  push rsi
0000710e9ebe19cb  push r8
0000710e9ebe19cd  push r9
0000710e9ebe19cf  push r10
0000710e9ebe19d1  push r11
0000710e9ebe19d3  sub rsp, 0xF0
0000710e9ebe19da  vmovaps [rsp], xmm0
0000710e9ebe19df  vmovaps [rsp+0x10], xmm1
0000710e9ebe19e5  vmovaps [rsp+0x20], xmm2
0000710e9ebe19eb  vmovaps [rsp+0x30], xmm3
0000710e9ebe19f1  vmovaps [rsp+0x40], xmm4
0000710e9ebe19f7  vmovaps [rsp+0x50], xmm5
0000710e9ebe19fd  vmovaps [rsp+0x60], xmm6
0000710e9ebe1a03  vmovaps [rsp+0x70], xmm7
0000710e9ebe1a09  vmovaps [rsp+0x80], xmm8
0000710e9ebe1a12  vmovaps [rsp+0x90], xmm9
0000710e9ebe1a1b  vmovaps [rsp+0xA0], xmm10
0000710e9ebe1a24  vmovaps [rsp+0xB0], xmm11
0000710e9ebe1a2d  vmovaps [rsp+0xC0], xmm12
0000710e9ebe1a36  vmovaps [rsp+0xD0], xmm13
0000710e9ebe1a3f  vmovaps [rsp+0xE0], xmm14
0000710e9ebe1a48  sub rsp, 0x30
0000710e9ebe1a4c  movaps [rsp], xmm15
0000710e9ebe1a51  movaps [rsp+0x10], xmm3
0000710e9ebe1a56  movaps [rsp+0x20], xmm7
0000710e9ebe1a5b  lea rdi, [rsp]
0000710e9ebe1a5f  mov esi, 0x00
0000710e9ebe1a64  mov rax, 0x5DADAF7CF530
0000710e9ebe1a6e  call rax
0000710e9ebe1a70  movaps xmm15, [rsp]
0000710e9ebe1a75  add rsp, 0x30
0000710e9ebe1a79  vmovaps xmm0, [rsp]
0000710e9ebe1a7e  vmovaps xmm1, [rsp+0x10]
0000710e9ebe1a84  vmovaps xmm2, [rsp+0x20]
0000710e9ebe1a8a  vmovaps xmm3, [rsp+0x30]
0000710e9ebe1a90  vmovaps xmm4, [rsp+0x40]
0000710e9ebe1a96  vmovaps xmm5, [rsp+0x50]
0000710e9ebe1a9c  vmovaps xmm6, [rsp+0x60]
0000710e9ebe1aa2  vmovaps xmm7, [rsp+0x70]
0000710e9ebe1aa8  vmovaps xmm8, [rsp+0x80]
0000710e9ebe1ab1  vmovaps xmm9, [rsp+0x90]
0000710e9ebe1aba  vmovaps xmm10, [rsp+0xA0]
0000710e9ebe1ac3  vmovaps xmm11, [rsp+0xB0]
0000710e9ebe1acc  vmovaps xmm12, [rsp+0xC0]
0000710e9ebe1ad5  vmovaps xmm13, [rsp+0xD0]
0000710e9ebe1ade  vmovaps xmm14, [rsp+0xE0]
0000710e9ebe1ae7  add rsp, 0xF0
0000710e9ebe1aee  pop r11
0000710e9ebe1af0  pop r10
0000710e9ebe1af2  pop r9
0000710e9ebe1af4  pop r8
0000710e9ebe1af6  pop rsi
0000710e9ebe1af7  pop rdi
0000710e9ebe1af8  pop rdx
0000710e9ebe1af9  pop rcx
0000710e9ebe1afa  pop rax
0000710e9ebe1afb  add rsp, 0x08
0000710e9ebe1aff  jmp 0x0000710E9EBDF3C3
0000710e9ebe1b04  sub rsp, 0x08
0000710e9ebe1b08  push rax
0000710e9ebe1b09  push rcx
0000710e9ebe1b0a  push rdx
0000710e9ebe1b0b  push rdi
0000710e9ebe1b0c  push rsi
0000710e9ebe1b0d  push r8
0000710e9ebe1b0f  push r9
0000710e9ebe1b11  push r10
0000710e9ebe1b13  push r11
0000710e9ebe1b15  sub rsp, 0xF0
0000710e9ebe1b1c  vmovaps [rsp], xmm0
0000710e9ebe1b21  vmovaps [rsp+0x10], xmm1
0000710e9ebe1b27  vmovaps [rsp+0x20], xmm2
0000710e9ebe1b2d  vmovaps [rsp+0x30], xmm4
0000710e9ebe1b33  vmovaps [rsp+0x40], xmm5
0000710e9ebe1b39  vmovaps [rsp+0x50], xmm6
0000710e9ebe1b3f  vmovaps [rsp+0x60], xmm7
0000710e9ebe1b45  vmovaps [rsp+0x70], xmm8
0000710e9ebe1b4b  vmovaps [rsp+0x80], xmm9
0000710e9ebe1b54  vmovaps [rsp+0x90], xmm10
0000710e9ebe1b5d  vmovaps [rsp+0xA0], xmm11
0000710e9ebe1b66  vmovaps [rsp+0xB0], xmm12
0000710e9ebe1b6f  vmovaps [rsp+0xC0], xmm13
0000710e9ebe1b78  vmovaps [rsp+0xD0], xmm14
0000710e9ebe1b81  vmovaps [rsp+0xE0], xmm15
0000710e9ebe1b8a  sub rsp, 0x30
0000710e9ebe1b8e  movaps [rsp], xmm3
0000710e9ebe1b92  movaps [rsp+0x10], xmm1
0000710e9ebe1b97  movaps [rsp+0x20], xmm15
0000710e9ebe1b9d  lea rdi, [rsp]
0000710e9ebe1ba1  mov esi, 0x00
0000710e9ebe1ba6  mov rax, 0x5DADAF7CF530
0000710e9ebe1bb0  call rax
0000710e9ebe1bb2  movaps xmm3, [rsp]
0000710e9ebe1bb6  add rsp, 0x30
0000710e9ebe1bba  vmovaps xmm0, [rsp]
0000710e9ebe1bbf  vmovaps xmm1, [rsp+0x10]
0000710e9ebe1bc5  vmovaps xmm2, [rsp+0x20]
0000710e9ebe1bcb  vmovaps xmm4, [rsp+0x30]
0000710e9ebe1bd1  vmovaps xmm5, [rsp+0x40]
0000710e9ebe1bd7  vmovaps xmm6, [rsp+0x50]
0000710e9ebe1bdd  vmovaps xmm7, [rsp+0x60]
0000710e9ebe1be3  vmovaps xmm8, [rsp+0x70]
0000710e9ebe1be9  vmovaps xmm9, [rsp+0x80]
0000710e9ebe1bf2  vmovaps xmm10, [rsp+0x90]
0000710e9ebe1bfb  vmovaps xmm11, [rsp+0xA0]
0000710e9ebe1c04  vmovaps xmm12, [rsp+0xB0]
0000710e9ebe1c0d  vmovaps xmm13, [rsp+0xC0]
0000710e9ebe1c16  vmovaps xmm14, [rsp+0xD0]
0000710e9ebe1c1f  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe1c28  add rsp, 0xF0
0000710e9ebe1c2f  pop r11
0000710e9ebe1c31  pop r10
0000710e9ebe1c33  pop r9
0000710e9ebe1c35  pop r8
0000710e9ebe1c37  pop rsi
0000710e9ebe1c38  pop rdi
0000710e9ebe1c39  pop rdx
0000710e9ebe1c3a  pop rcx
0000710e9ebe1c3b  pop rax
0000710e9ebe1c3c  add rsp, 0x08
0000710e9ebe1c40  jmp 0x0000710E9EBDF452
0000710e9ebe1c45  call 0x0000710E9EAB52F0
0000710e9ebe1c4a  jmp 0x0000710E9EBDF45C
0000710e9ebe1c4f  sub rsp, 0x08
0000710e9ebe1c53  push rax
0000710e9ebe1c54  push rcx
0000710e9ebe1c55  push rdx
0000710e9ebe1c56  push rdi
0000710e9ebe1c57  push rsi
0000710e9ebe1c58  push r8
0000710e9ebe1c5a  push r9
0000710e9ebe1c5c  push r10
0000710e9ebe1c5e  push r11
0000710e9ebe1c60  sub rsp, 0xF0
0000710e9ebe1c67  vmovaps [rsp], xmm0
0000710e9ebe1c6c  vmovaps [rsp+0x10], xmm1
0000710e9ebe1c72  vmovaps [rsp+0x20], xmm2
0000710e9ebe1c78  vmovaps [rsp+0x30], xmm3
0000710e9ebe1c7e  vmovaps [rsp+0x40], xmm4
0000710e9ebe1c84  vmovaps [rsp+0x50], xmm5
0000710e9ebe1c8a  vmovaps [rsp+0x60], xmm6
0000710e9ebe1c90  vmovaps [rsp+0x70], xmm7
0000710e9ebe1c96  vmovaps [rsp+0x80], xmm8
0000710e9ebe1c9f  vmovaps [rsp+0x90], xmm9
0000710e9ebe1ca8  vmovaps [rsp+0xA0], xmm10
0000710e9ebe1cb1  vmovaps [rsp+0xB0], xmm11
0000710e9ebe1cba  vmovaps [rsp+0xC0], xmm12
0000710e9ebe1cc3  vmovaps [rsp+0xD0], xmm13
0000710e9ebe1ccc  vmovaps [rsp+0xE0], xmm14
0000710e9ebe1cd5  sub rsp, 0x30
0000710e9ebe1cd9  movaps [rsp], xmm15
0000710e9ebe1cde  movaps [rsp+0x10], xmm14
0000710e9ebe1ce4  movaps [rsp+0x20], xmm4
0000710e9ebe1ce9  lea rdi, [rsp]
0000710e9ebe1ced  mov esi, 0x00
0000710e9ebe1cf2  mov rax, 0x5DADAF7CF530
0000710e9ebe1cfc  call rax
0000710e9ebe1cfe  movaps xmm15, [rsp]
0000710e9ebe1d03  add rsp, 0x30
0000710e9ebe1d07  vmovaps xmm0, [rsp]
0000710e9ebe1d0c  vmovaps xmm1, [rsp+0x10]
0000710e9ebe1d12  vmovaps xmm2, [rsp+0x20]
0000710e9ebe1d18  vmovaps xmm3, [rsp+0x30]
0000710e9ebe1d1e  vmovaps xmm4, [rsp+0x40]
0000710e9ebe1d24  vmovaps xmm5, [rsp+0x50]
0000710e9ebe1d2a  vmovaps xmm6, [rsp+0x60]
0000710e9ebe1d30  vmovaps xmm7, [rsp+0x70]
0000710e9ebe1d36  vmovaps xmm8, [rsp+0x80]
0000710e9ebe1d3f  vmovaps xmm9, [rsp+0x90]
0000710e9ebe1d48  vmovaps xmm10, [rsp+0xA0]
0000710e9ebe1d51  vmovaps xmm11, [rsp+0xB0]
0000710e9ebe1d5a  vmovaps xmm12, [rsp+0xC0]
0000710e9ebe1d63  vmovaps xmm13, [rsp+0xD0]
0000710e9ebe1d6c  vmovaps xmm14, [rsp+0xE0]
0000710e9ebe1d75  add rsp, 0xF0
0000710e9ebe1d7c  pop r11
0000710e9ebe1d7e  pop r10
0000710e9ebe1d80  pop r9
0000710e9ebe1d82  pop r8
0000710e9ebe1d84  pop rsi
0000710e9ebe1d85  pop rdi
0000710e9ebe1d86  pop rdx
0000710e9ebe1d87  pop rcx
0000710e9ebe1d88  pop rax
0000710e9ebe1d89  add rsp, 0x08
0000710e9ebe1d8d  jmp 0x0000710E9EBDF48A
0000710e9ebe1d92  sub rsp, 0x08
0000710e9ebe1d96  push rax
0000710e9ebe1d97  push rcx
0000710e9ebe1d98  push rdx
0000710e9ebe1d99  push rdi
0000710e9ebe1d9a  push rsi
0000710e9ebe1d9b  push r8
0000710e9ebe1d9d  push r9
0000710e9ebe1d9f  push r10
0000710e9ebe1da1  push r11
0000710e9ebe1da3  sub rsp, 0xF0
0000710e9ebe1daa  vmovaps [rsp], xmm0
0000710e9ebe1daf  vmovaps [rsp+0x10], xmm1
0000710e9ebe1db5  vmovaps [rsp+0x20], xmm2
0000710e9ebe1dbb  vmovaps [rsp+0x30], xmm3
0000710e9ebe1dc1  vmovaps [rsp+0x40], xmm4
0000710e9ebe1dc7  vmovaps [rsp+0x50], xmm5
0000710e9ebe1dcd  vmovaps [rsp+0x60], xmm6
0000710e9ebe1dd3  vmovaps [rsp+0x70], xmm7
0000710e9ebe1dd9  vmovaps [rsp+0x80], xmm8
0000710e9ebe1de2  vmovaps [rsp+0x90], xmm9
0000710e9ebe1deb  vmovaps [rsp+0xA0], xmm10
0000710e9ebe1df4  vmovaps [rsp+0xB0], xmm11
0000710e9ebe1dfd  vmovaps [rsp+0xC0], xmm12
0000710e9ebe1e06  vmovaps [rsp+0xD0], xmm13
0000710e9ebe1e0f  vmovaps [rsp+0xE0], xmm15
0000710e9ebe1e18  sub rsp, 0x30
0000710e9ebe1e1c  movaps [rsp], xmm14
0000710e9ebe1e21  movaps [rsp+0x10], xmm2
0000710e9ebe1e26  movaps [rsp+0x20], xmm1
0000710e9ebe1e2b  lea rdi, [rsp]
0000710e9ebe1e2f  mov esi, 0x00
0000710e9ebe1e34  mov rax, 0x5DADAF7CF530
0000710e9ebe1e3e  call rax
0000710e9ebe1e40  movaps xmm14, [rsp]
0000710e9ebe1e45  add rsp, 0x30
0000710e9ebe1e49  vmovaps xmm0, [rsp]
0000710e9ebe1e4e  vmovaps xmm1, [rsp+0x10]
0000710e9ebe1e54  vmovaps xmm2, [rsp+0x20]
0000710e9ebe1e5a  vmovaps xmm3, [rsp+0x30]
0000710e9ebe1e60  vmovaps xmm4, [rsp+0x40]
0000710e9ebe1e66  vmovaps xmm5, [rsp+0x50]
0000710e9ebe1e6c  vmovaps xmm6, [rsp+0x60]
0000710e9ebe1e72  vmovaps xmm7, [rsp+0x70]
0000710e9ebe1e78  vmovaps xmm8, [rsp+0x80]
0000710e9ebe1e81  vmovaps xmm9, [rsp+0x90]
0000710e9ebe1e8a  vmovaps xmm10, [rsp+0xA0]
0000710e9ebe1e93  vmovaps xmm11, [rsp+0xB0]
0000710e9ebe1e9c  vmovaps xmm12, [rsp+0xC0]
0000710e9ebe1ea5  vmovaps xmm13, [rsp+0xD0]
0000710e9ebe1eae  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe1eb7  add rsp, 0xF0
0000710e9ebe1ebe  pop r11
0000710e9ebe1ec0  pop r10
0000710e9ebe1ec2  pop r9
0000710e9ebe1ec4  pop r8
0000710e9ebe1ec6  pop rsi
0000710e9ebe1ec7  pop rdi
0000710e9ebe1ec8  pop rdx
0000710e9ebe1ec9  pop rcx
0000710e9ebe1eca  pop rax
0000710e9ebe1ecb  add rsp, 0x08
0000710e9ebe1ecf  jmp 0x0000710E9EBDF4B0
0000710e9ebe1ed4  sub rsp, 0x08
0000710e9ebe1ed8  push rax
0000710e9ebe1ed9  push rcx
0000710e9ebe1eda  push rdx
0000710e9ebe1edb  push rdi
0000710e9ebe1edc  push rsi
0000710e9ebe1edd  push r8
0000710e9ebe1edf  push r9
0000710e9ebe1ee1  push r10
0000710e9ebe1ee3  push r11
0000710e9ebe1ee5  sub rsp, 0xF0
0000710e9ebe1eec  vmovaps [rsp], xmm0
0000710e9ebe1ef1  vmovaps [rsp+0x10], xmm2
0000710e9ebe1ef7  vmovaps [rsp+0x20], xmm3
0000710e9ebe1efd  vmovaps [rsp+0x30], xmm4
0000710e9ebe1f03  vmovaps [rsp+0x40], xmm5
0000710e9ebe1f09  vmovaps [rsp+0x50], xmm6
0000710e9ebe1f0f  vmovaps [rsp+0x60], xmm7
0000710e9ebe1f15  vmovaps [rsp+0x70], xmm8
0000710e9ebe1f1b  vmovaps [rsp+0x80], xmm9
0000710e9ebe1f24  vmovaps [rsp+0x90], xmm10
0000710e9ebe1f2d  vmovaps [rsp+0xA0], xmm11
0000710e9ebe1f36  vmovaps [rsp+0xB0], xmm12
0000710e9ebe1f3f  vmovaps [rsp+0xC0], xmm13
0000710e9ebe1f48  vmovaps [rsp+0xD0], xmm14
0000710e9ebe1f51  vmovaps [rsp+0xE0], xmm15
0000710e9ebe1f5a  sub rsp, 0x30
0000710e9ebe1f5e  movaps [rsp], xmm1
0000710e9ebe1f62  movaps [rsp+0x10], xmm4
0000710e9ebe1f67  movaps [rsp+0x20], xmm9
0000710e9ebe1f6d  lea rdi, [rsp]
0000710e9ebe1f71  mov esi, 0x00
0000710e9ebe1f76  mov rax, 0x5DADAF7CF530
0000710e9ebe1f80  call rax
0000710e9ebe1f82  movaps xmm1, [rsp]
0000710e9ebe1f86  add rsp, 0x30
0000710e9ebe1f8a  vmovaps xmm0, [rsp]
0000710e9ebe1f8f  vmovaps xmm2, [rsp+0x10]
0000710e9ebe1f95  vmovaps xmm3, [rsp+0x20]
0000710e9ebe1f9b  vmovaps xmm4, [rsp+0x30]
0000710e9ebe1fa1  vmovaps xmm5, [rsp+0x40]
0000710e9ebe1fa7  vmovaps xmm6, [rsp+0x50]
0000710e9ebe1fad  vmovaps xmm7, [rsp+0x60]
0000710e9ebe1fb3  vmovaps xmm8, [rsp+0x70]
0000710e9ebe1fb9  vmovaps xmm9, [rsp+0x80]
0000710e9ebe1fc2  vmovaps xmm10, [rsp+0x90]
0000710e9ebe1fcb  vmovaps xmm11, [rsp+0xA0]
0000710e9ebe1fd4  vmovaps xmm12, [rsp+0xB0]
0000710e9ebe1fdd  vmovaps xmm13, [rsp+0xC0]
0000710e9ebe1fe6  vmovaps xmm14, [rsp+0xD0]
0000710e9ebe1fef  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe1ff8  add rsp, 0xF0
0000710e9ebe1fff  pop r11
0000710e9ebe2001  pop r10
0000710e9ebe2003  pop r9
0000710e9ebe2005  pop r8
0000710e9ebe2007  pop rsi
0000710e9ebe2008  pop rdi
0000710e9ebe2009  pop rdx
0000710e9ebe200a  pop rcx
0000710e9ebe200b  pop rax
0000710e9ebe200c  add rsp, 0x08
0000710e9ebe2010  jmp 0x0000710E9EBDF4CE
0000710e9ebe2015  sub rsp, 0x08
0000710e9ebe2019  push rax
0000710e9ebe201a  push rcx
0000710e9ebe201b  push rdx
0000710e9ebe201c  push rdi
0000710e9ebe201d  push rsi
0000710e9ebe201e  push r8
0000710e9ebe2020  push r9
0000710e9ebe2022  push r10
0000710e9ebe2024  push r11
0000710e9ebe2026  sub rsp, 0xF0
0000710e9ebe202d  vmovaps [rsp], xmm0
0000710e9ebe2032  vmovaps [rsp+0x10], xmm1
0000710e9ebe2038  vmovaps [rsp+0x20], xmm2
0000710e9ebe203e  vmovaps [rsp+0x30], xmm3
0000710e9ebe2044  vmovaps [rsp+0x40], xmm5
0000710e9ebe204a  vmovaps [rsp+0x50], xmm6
0000710e9ebe2050  vmovaps [rsp+0x60], xmm7
0000710e9ebe2056  vmovaps [rsp+0x70], xmm8
0000710e9ebe205c  vmovaps [rsp+0x80], xmm9
0000710e9ebe2065  vmovaps [rsp+0x90], xmm10
0000710e9ebe206e  vmovaps [rsp+0xA0], xmm11
0000710e9ebe2077  vmovaps [rsp+0xB0], xmm12
0000710e9ebe2080  vmovaps [rsp+0xC0], xmm13
0000710e9ebe2089  vmovaps [rsp+0xD0], xmm14
0000710e9ebe2092  vmovaps [rsp+0xE0], xmm15
0000710e9ebe209b  sub rsp, 0x30
0000710e9ebe209f  movaps [rsp], xmm4
0000710e9ebe20a3  movaps [rsp+0x10], xmm2
0000710e9ebe20a8  movaps [rsp+0x20], xmm9
0000710e9ebe20ae  lea rdi, [rsp]
0000710e9ebe20b2  mov esi, 0x00
0000710e9ebe20b7  mov rax, 0x5DADAF7CF530
0000710e9ebe20c1  call rax
0000710e9ebe20c3  movaps xmm4, [rsp]
0000710e9ebe20c7  add rsp, 0x30
0000710e9ebe20cb  vmovaps xmm0, [rsp]
0000710e9ebe20d0  vmovaps xmm1, [rsp+0x10]
0000710e9ebe20d6  vmovaps xmm2, [rsp+0x20]
0000710e9ebe20dc  vmovaps xmm3, [rsp+0x30]
0000710e9ebe20e2  vmovaps xmm5, [rsp+0x40]
0000710e9ebe20e8  vmovaps xmm6, [rsp+0x50]
0000710e9ebe20ee  vmovaps xmm7, [rsp+0x60]
0000710e9ebe20f4  vmovaps xmm8, [rsp+0x70]
0000710e9ebe20fa  vmovaps xmm9, [rsp+0x80]
0000710e9ebe2103  vmovaps xmm10, [rsp+0x90]
0000710e9ebe210c  vmovaps xmm11, [rsp+0xA0]
0000710e9ebe2115  vmovaps xmm12, [rsp+0xB0]
0000710e9ebe211e  vmovaps xmm13, [rsp+0xC0]
0000710e9ebe2127  vmovaps xmm14, [rsp+0xD0]
0000710e9ebe2130  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe2139  add rsp, 0xF0
0000710e9ebe2140  pop r11
0000710e9ebe2142  pop r10
0000710e9ebe2144  pop r9
0000710e9ebe2146  pop r8
0000710e9ebe2148  pop rsi
0000710e9ebe2149  pop rdi
0000710e9ebe214a  pop rdx
0000710e9ebe214b  pop rcx
0000710e9ebe214c  pop rax
0000710e9ebe214d  add rsp, 0x08
0000710e9ebe2151  jmp 0x0000710E9EBDF4FE
0000710e9ebe2156  sub rsp, 0x08
0000710e9ebe215a  push rax
0000710e9ebe215b  push rcx
0000710e9ebe215c  push rdx
0000710e9ebe215d  push rdi
0000710e9ebe215e  push rsi
0000710e9ebe215f  push r8
0000710e9ebe2161  push r9
0000710e9ebe2163  push r10
0000710e9ebe2165  push r11
0000710e9ebe2167  sub rsp, 0xF0
0000710e9ebe216e  vmovaps [rsp], xmm0
0000710e9ebe2173  vmovaps [rsp+0x10], xmm1
0000710e9ebe2179  vmovaps [rsp+0x20], xmm2
0000710e9ebe217f  vmovaps [rsp+0x30], xmm3
0000710e9ebe2185  vmovaps [rsp+0x40], xmm4
0000710e9ebe218b  vmovaps [rsp+0x50], xmm5
0000710e9ebe2191  vmovaps [rsp+0x60], xmm6
0000710e9ebe2197  vmovaps [rsp+0x70], xmm7
0000710e9ebe219d  vmovaps [rsp+0x80], xmm8
0000710e9ebe21a6  vmovaps [rsp+0x90], xmm10
0000710e9ebe21af  vmovaps [rsp+0xA0], xmm11
0000710e9ebe21b8  vmovaps [rsp+0xB0], xmm12
0000710e9ebe21c1  vmovaps [rsp+0xC0], xmm13
0000710e9ebe21ca  vmovaps [rsp+0xD0], xmm14
0000710e9ebe21d3  vmovaps [rsp+0xE0], xmm15
0000710e9ebe21dc  sub rsp, 0x30
0000710e9ebe21e0  movaps [rsp], xmm9
0000710e9ebe21e5  movaps [rsp+0x10], xmm2
0000710e9ebe21ea  movaps [rsp+0x20], xmm1
0000710e9ebe21ef  lea rdi, [rsp]
0000710e9ebe21f3  mov esi, 0x00
0000710e9ebe21f8  mov rax, 0x5DADAF7CF530
0000710e9ebe2202  call rax
0000710e9ebe2204  movaps xmm9, [rsp]
0000710e9ebe2209  add rsp, 0x30
0000710e9ebe220d  vmovaps xmm0, [rsp]
0000710e9ebe2212  vmovaps xmm1, [rsp+0x10]
0000710e9ebe2218  vmovaps xmm2, [rsp+0x20]
0000710e9ebe221e  vmovaps xmm3, [rsp+0x30]
0000710e9ebe2224  vmovaps xmm4, [rsp+0x40]
0000710e9ebe222a  vmovaps xmm5, [rsp+0x50]
0000710e9ebe2230  vmovaps xmm6, [rsp+0x60]
0000710e9ebe2236  vmovaps xmm7, [rsp+0x70]
0000710e9ebe223c  vmovaps xmm8, [rsp+0x80]
0000710e9ebe2245  vmovaps xmm10, [rsp+0x90]
0000710e9ebe224e  vmovaps xmm11, [rsp+0xA0]
0000710e9ebe2257  vmovaps xmm12, [rsp+0xB0]
0000710e9ebe2260  vmovaps xmm13, [rsp+0xC0]
0000710e9ebe2269  vmovaps xmm14, [rsp+0xD0]
0000710e9ebe2272  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe227b  add rsp, 0xF0
0000710e9ebe2282  pop r11
0000710e9ebe2284  pop r10
0000710e9ebe2286  pop r9
0000710e9ebe2288  pop r8
0000710e9ebe228a  pop rsi
0000710e9ebe228b  pop rdi
0000710e9ebe228c  pop rdx
0000710e9ebe228d  pop rcx
0000710e9ebe228e  pop rax
0000710e9ebe228f  add rsp, 0x08
0000710e9ebe2293  jmp 0x0000710E9EBDF534
0000710e9ebe2298  sub rsp, 0x08
0000710e9ebe229c  push rax
0000710e9ebe229d  push rcx
0000710e9ebe229e  push rdx
0000710e9ebe229f  push rdi
0000710e9ebe22a0  push rsi
0000710e9ebe22a1  push r8
0000710e9ebe22a3  push r9
0000710e9ebe22a5  push r10
0000710e9ebe22a7  push r11
0000710e9ebe22a9  sub rsp, 0xF0
0000710e9ebe22b0  vmovaps [rsp], xmm0
0000710e9ebe22b5  vmovaps [rsp+0x10], xmm2
0000710e9ebe22bb  vmovaps [rsp+0x20], xmm3
0000710e9ebe22c1  vmovaps [rsp+0x30], xmm4
0000710e9ebe22c7  vmovaps [rsp+0x40], xmm5
0000710e9ebe22cd  vmovaps [rsp+0x50], xmm6
0000710e9ebe22d3  vmovaps [rsp+0x60], xmm7
0000710e9ebe22d9  vmovaps [rsp+0x70], xmm8
0000710e9ebe22df  vmovaps [rsp+0x80], xmm9
0000710e9ebe22e8  vmovaps [rsp+0x90], xmm10
0000710e9ebe22f1  vmovaps [rsp+0xA0], xmm11
0000710e9ebe22fa  vmovaps [rsp+0xB0], xmm12
0000710e9ebe2303  vmovaps [rsp+0xC0], xmm13
0000710e9ebe230c  vmovaps [rsp+0xD0], xmm14
0000710e9ebe2315  vmovaps [rsp+0xE0], xmm15
0000710e9ebe231e  sub rsp, 0x30
0000710e9ebe2322  movaps [rsp], xmm1
0000710e9ebe2326  movaps [rsp+0x10], xmm15
0000710e9ebe232c  movaps [rsp+0x20], xmm6
0000710e9ebe2331  lea rdi, [rsp]
0000710e9ebe2335  mov esi, 0x00
0000710e9ebe233a  mov rax, 0x5DADAF7CF530
0000710e9ebe2344  call rax
0000710e9ebe2346  movaps xmm1, [rsp]
0000710e9ebe234a  add rsp, 0x30
0000710e9ebe234e  vmovaps xmm0, [rsp]
0000710e9ebe2353  vmovaps xmm2, [rsp+0x10]
0000710e9ebe2359  vmovaps xmm3, [rsp+0x20]
0000710e9ebe235f  vmovaps xmm4, [rsp+0x30]
0000710e9ebe2365  vmovaps xmm5, [rsp+0x40]
0000710e9ebe236b  vmovaps xmm6, [rsp+0x50]
0000710e9ebe2371  vmovaps xmm7, [rsp+0x60]
0000710e9ebe2377  vmovaps xmm8, [rsp+0x70]
0000710e9ebe237d  vmovaps xmm9, [rsp+0x80]
0000710e9ebe2386  vmovaps xmm10, [rsp+0x90]
0000710e9ebe238f  vmovaps xmm11, [rsp+0xA0]
0000710e9ebe2398  vmovaps xmm12, [rsp+0xB0]
0000710e9ebe23a1  vmovaps xmm13, [rsp+0xC0]
0000710e9ebe23aa  vmovaps xmm14, [rsp+0xD0]
0000710e9ebe23b3  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe23bc  add rsp, 0xF0
0000710e9ebe23c3  pop r11
0000710e9ebe23c5  pop r10
0000710e9ebe23c7  pop r9
0000710e9ebe23c9  pop r8
0000710e9ebe23cb  pop rsi
0000710e9ebe23cc  pop rdi
0000710e9ebe23cd  pop rdx
0000710e9ebe23ce  pop rcx
0000710e9ebe23cf  pop rax
0000710e9ebe23d0  add rsp, 0x08
0000710e9ebe23d4  jmp 0x0000710E9EBDF555
0000710e9ebe23d9  sub rsp, 0x08
0000710e9ebe23dd  push rax
0000710e9ebe23de  push rcx
0000710e9ebe23df  push rdx
0000710e9ebe23e0  push rdi
0000710e9ebe23e1  push rsi
0000710e9ebe23e2  push r8
0000710e9ebe23e4  push r9
0000710e9ebe23e6  push r10
0000710e9ebe23e8  push r11
0000710e9ebe23ea  sub rsp, 0xF0
0000710e9ebe23f1  vmovaps [rsp], xmm0
0000710e9ebe23f6  vmovaps [rsp+0x10], xmm1
0000710e9ebe23fc  vmovaps [rsp+0x20], xmm2
0000710e9ebe2402  vmovaps [rsp+0x30], xmm3
0000710e9ebe2408  vmovaps [rsp+0x40], xmm4
0000710e9ebe240e  vmovaps [rsp+0x50], xmm5
0000710e9ebe2414  vmovaps [rsp+0x60], xmm6
0000710e9ebe241a  vmovaps [rsp+0x70], xmm7
0000710e9ebe2420  vmovaps [rsp+0x80], xmm8
0000710e9ebe2429  vmovaps [rsp+0x90], xmm9
0000710e9ebe2432  vmovaps [rsp+0xA0], xmm10
0000710e9ebe243b  vmovaps [rsp+0xB0], xmm11
0000710e9ebe2444  vmovaps [rsp+0xC0], xmm12
0000710e9ebe244d  vmovaps [rsp+0xD0], xmm13
0000710e9ebe2456  vmovaps [rsp+0xE0], xmm14
0000710e9ebe245f  sub rsp, 0x30
0000710e9ebe2463  movaps [rsp], xmm15
0000710e9ebe2468  movaps [rsp+0x10], xmm5
0000710e9ebe246d  movaps [rsp+0x20], xmm3
0000710e9ebe2472  lea rdi, [rsp]
0000710e9ebe2476  mov esi, 0x00
0000710e9ebe247b  mov rax, 0x5DADAF7CF530
0000710e9ebe2485  call rax
0000710e9ebe2487  movaps xmm15, [rsp]
0000710e9ebe248c  add rsp, 0x30
0000710e9ebe2490  vmovaps xmm0, [rsp]
0000710e9ebe2495  vmovaps xmm1, [rsp+0x10]
0000710e9ebe249b  vmovaps xmm2, [rsp+0x20]
0000710e9ebe24a1  vmovaps xmm3, [rsp+0x30]
0000710e9ebe24a7  vmovaps xmm4, [rsp+0x40]
0000710e9ebe24ad  vmovaps xmm5, [rsp+0x50]
0000710e9ebe24b3  vmovaps xmm6, [rsp+0x60]
0000710e9ebe24b9  vmovaps xmm7, [rsp+0x70]
0000710e9ebe24bf  vmovaps xmm8, [rsp+0x80]
0000710e9ebe24c8  vmovaps xmm9, [rsp+0x90]
0000710e9ebe24d1  vmovaps xmm10, [rsp+0xA0]
0000710e9ebe24da  vmovaps xmm11, [rsp+0xB0]
0000710e9ebe24e3  vmovaps xmm12, [rsp+0xC0]
0000710e9ebe24ec  vmovaps xmm13, [rsp+0xD0]
0000710e9ebe24f5  vmovaps xmm14, [rsp+0xE0]
0000710e9ebe24fe  add rsp, 0xF0
0000710e9ebe2505  pop r11
0000710e9ebe2507  pop r10
0000710e9ebe2509  pop r9
0000710e9ebe250b  pop r8
0000710e9ebe250d  pop rsi
0000710e9ebe250e  pop rdi
0000710e9ebe250f  pop rdx
0000710e9ebe2510  pop rcx
0000710e9ebe2511  pop rax
0000710e9ebe2512  add rsp, 0x08
0000710e9ebe2516  jmp 0x0000710E9EBDF56F
0000710e9ebe251b  sub rsp, 0x08
0000710e9ebe251f  push rax
0000710e9ebe2520  push rcx
0000710e9ebe2521  push rdx
0000710e9ebe2522  push rdi
0000710e9ebe2523  push rsi
0000710e9ebe2524  push r8
0000710e9ebe2526  push r9
0000710e9ebe2528  push r10
0000710e9ebe252a  push r11
0000710e9ebe252c  sub rsp, 0xF0
0000710e9ebe2533  vmovaps [rsp], xmm0
0000710e9ebe2538  vmovaps [rsp+0x10], xmm1
0000710e9ebe253e  vmovaps [rsp+0x20], xmm2
0000710e9ebe2544  vmovaps [rsp+0x30], xmm3
0000710e9ebe254a  vmovaps [rsp+0x40], xmm4
0000710e9ebe2550  vmovaps [rsp+0x50], xmm6
0000710e9ebe2556  vmovaps [rsp+0x60], xmm7
0000710e9ebe255c  vmovaps [rsp+0x70], xmm8
0000710e9ebe2562  vmovaps [rsp+0x80], xmm9
0000710e9ebe256b  vmovaps [rsp+0x90], xmm10
0000710e9ebe2574  vmovaps [rsp+0xA0], xmm11
0000710e9ebe257d  vmovaps [rsp+0xB0], xmm12
0000710e9ebe2586  vmovaps [rsp+0xC0], xmm13
0000710e9ebe258f  vmovaps [rsp+0xD0], xmm14
0000710e9ebe2598  vmovaps [rsp+0xE0], xmm15
0000710e9ebe25a1  sub rsp, 0x30
0000710e9ebe25a5  movaps [rsp], xmm5
0000710e9ebe25a9  movaps [rsp+0x10], xmm8
0000710e9ebe25af  movaps [rsp+0x20], xmm6
0000710e9ebe25b4  lea rdi, [rsp]
0000710e9ebe25b8  mov esi, 0x00
0000710e9ebe25bd  mov rax, 0x5DADAF7CF530
0000710e9ebe25c7  call rax
0000710e9ebe25c9  movaps xmm5, [rsp]
0000710e9ebe25cd  add rsp, 0x30
0000710e9ebe25d1  vmovaps xmm0, [rsp]
0000710e9ebe25d6  vmovaps xmm1, [rsp+0x10]
0000710e9ebe25dc  vmovaps xmm2, [rsp+0x20]
0000710e9ebe25e2  vmovaps xmm3, [rsp+0x30]
0000710e9ebe25e8  vmovaps xmm4, [rsp+0x40]
0000710e9ebe25ee  vmovaps xmm6, [rsp+0x50]
0000710e9ebe25f4  vmovaps xmm7, [rsp+0x60]
0000710e9ebe25fa  vmovaps xmm8, [rsp+0x70]
0000710e9ebe2600  vmovaps xmm9, [rsp+0x80]
0000710e9ebe2609  vmovaps xmm10, [rsp+0x90]
0000710e9ebe2612  vmovaps xmm11, [rsp+0xA0]
0000710e9ebe261b  vmovaps xmm12, [rsp+0xB0]
0000710e9ebe2624  vmovaps xmm13, [rsp+0xC0]
0000710e9ebe262d  vmovaps xmm14, [rsp+0xD0]
0000710e9ebe2636  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe263f  add rsp, 0xF0
0000710e9ebe2646  pop r11
0000710e9ebe2648  pop r10
0000710e9ebe264a  pop r9
0000710e9ebe264c  pop r8
0000710e9ebe264e  pop rsi
0000710e9ebe264f  pop rdi
0000710e9ebe2650  pop rdx
0000710e9ebe2651  pop rcx
0000710e9ebe2652  pop rax
0000710e9ebe2653  add rsp, 0x08
0000710e9ebe2657  jmp 0x0000710E9EBDF593
0000710e9ebe265c  sub rsp, 0x08
0000710e9ebe2660  push rax
0000710e9ebe2661  push rcx
0000710e9ebe2662  push rdx
0000710e9ebe2663  push rdi
0000710e9ebe2664  push rsi
0000710e9ebe2665  push r8
0000710e9ebe2667  push r9
0000710e9ebe2669  push r10
0000710e9ebe266b  push r11
0000710e9ebe266d  sub rsp, 0xF0
0000710e9ebe2674  vmovaps [rsp], xmm0
0000710e9ebe2679  vmovaps [rsp+0x10], xmm1
0000710e9ebe267f  vmovaps [rsp+0x20], xmm2
0000710e9ebe2685  vmovaps [rsp+0x30], xmm3
0000710e9ebe268b  vmovaps [rsp+0x40], xmm4
0000710e9ebe2691  vmovaps [rsp+0x50], xmm5
0000710e9ebe2697  vmovaps [rsp+0x60], xmm7
0000710e9ebe269d  vmovaps [rsp+0x70], xmm8
0000710e9ebe26a3  vmovaps [rsp+0x80], xmm9
0000710e9ebe26ac  vmovaps [rsp+0x90], xmm10
0000710e9ebe26b5  vmovaps [rsp+0xA0], xmm11
0000710e9ebe26be  vmovaps [rsp+0xB0], xmm12
0000710e9ebe26c7  vmovaps [rsp+0xC0], xmm13
0000710e9ebe26d0  vmovaps [rsp+0xD0], xmm14
0000710e9ebe26d9  vmovaps [rsp+0xE0], xmm15
0000710e9ebe26e2  sub rsp, 0x30
0000710e9ebe26e6  movaps [rsp], xmm6
0000710e9ebe26ea  movaps [rsp+0x10], xmm10
0000710e9ebe26f0  movaps [rsp+0x20], xmm8
0000710e9ebe26f6  lea rdi, [rsp]
0000710e9ebe26fa  mov esi, 0x00
0000710e9ebe26ff  mov rax, 0x5DADAF7CF530
0000710e9ebe2709  call rax
0000710e9ebe270b  movaps xmm6, [rsp]
0000710e9ebe270f  add rsp, 0x30
0000710e9ebe2713  vmovaps xmm0, [rsp]
0000710e9ebe2718  vmovaps xmm1, [rsp+0x10]
0000710e9ebe271e  vmovaps xmm2, [rsp+0x20]
0000710e9ebe2724  vmovaps xmm3, [rsp+0x30]
0000710e9ebe272a  vmovaps xmm4, [rsp+0x40]
0000710e9ebe2730  vmovaps xmm5, [rsp+0x50]
0000710e9ebe2736  vmovaps xmm7, [rsp+0x60]
0000710e9ebe273c  vmovaps xmm8, [rsp+0x70]
0000710e9ebe2742  vmovaps xmm9, [rsp+0x80]
0000710e9ebe274b  vmovaps xmm10, [rsp+0x90]
0000710e9ebe2754  vmovaps xmm11, [rsp+0xA0]
0000710e9ebe275d  vmovaps xmm12, [rsp+0xB0]
0000710e9ebe2766  vmovaps xmm13, [rsp+0xC0]
0000710e9ebe276f  vmovaps xmm14, [rsp+0xD0]
0000710e9ebe2778  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe2781  add rsp, 0xF0
0000710e9ebe2788  pop r11
0000710e9ebe278a  pop r10
0000710e9ebe278c  pop r9
0000710e9ebe278e  pop r8
0000710e9ebe2790  pop rsi
0000710e9ebe2791  pop rdi
0000710e9ebe2792  pop rdx
0000710e9ebe2793  pop rcx
0000710e9ebe2794  pop rax
0000710e9ebe2795  add rsp, 0x08
0000710e9ebe2799  jmp 0x0000710E9EBDF5B8
0000710e9ebe279e  sub rsp, 0x08
0000710e9ebe27a2  push rax
0000710e9ebe27a3  push rcx
0000710e9ebe27a4  push rdx
0000710e9ebe27a5  push rdi
0000710e9ebe27a6  push rsi
0000710e9ebe27a7  push r8
0000710e9ebe27a9  push r9
0000710e9ebe27ab  push r10
0000710e9ebe27ad  push r11
0000710e9ebe27af  sub rsp, 0xF0
0000710e9ebe27b6  vmovaps [rsp], xmm0
0000710e9ebe27bb  vmovaps [rsp+0x10], xmm1
0000710e9ebe27c1  vmovaps [rsp+0x20], xmm2
0000710e9ebe27c7  vmovaps [rsp+0x30], xmm3
0000710e9ebe27cd  vmovaps [rsp+0x40], xmm4
0000710e9ebe27d3  vmovaps [rsp+0x50], xmm5
0000710e9ebe27d9  vmovaps [rsp+0x60], xmm6
0000710e9ebe27df  vmovaps [rsp+0x70], xmm7
0000710e9ebe27e5  vmovaps [rsp+0x80], xmm8
0000710e9ebe27ee  vmovaps [rsp+0x90], xmm9
0000710e9ebe27f7  vmovaps [rsp+0xA0], xmm11
0000710e9ebe2800  vmovaps [rsp+0xB0], xmm12
0000710e9ebe2809  vmovaps [rsp+0xC0], xmm13
0000710e9ebe2812  vmovaps [rsp+0xD0], xmm14
0000710e9ebe281b  vmovaps [rsp+0xE0], xmm15
0000710e9ebe2824  sub rsp, 0x30
0000710e9ebe2828  movaps [rsp], xmm10
0000710e9ebe282d  movaps [rsp+0x10], xmm8
0000710e9ebe2833  movaps [rsp+0x20], xmm14
0000710e9ebe2839  lea rdi, [rsp]
0000710e9ebe283d  mov esi, 0x00
0000710e9ebe2842  mov rax, 0x5DADAF7CF530
0000710e9ebe284c  call rax
0000710e9ebe284e  movaps xmm10, [rsp]
0000710e9ebe2853  add rsp, 0x30
0000710e9ebe2857  vmovaps xmm0, [rsp]
0000710e9ebe285c  vmovaps xmm1, [rsp+0x10]
0000710e9ebe2862  vmovaps xmm2, [rsp+0x20]
0000710e9ebe2868  vmovaps xmm3, [rsp+0x30]
0000710e9ebe286e  vmovaps xmm4, [rsp+0x40]
0000710e9ebe2874  vmovaps xmm5, [rsp+0x50]
0000710e9ebe287a  vmovaps xmm6, [rsp+0x60]
0000710e9ebe2880  vmovaps xmm7, [rsp+0x70]
0000710e9ebe2886  vmovaps xmm8, [rsp+0x80]
0000710e9ebe288f  vmovaps xmm9, [rsp+0x90]
0000710e9ebe2898  vmovaps xmm11, [rsp+0xA0]
0000710e9ebe28a1  vmovaps xmm12, [rsp+0xB0]
0000710e9ebe28aa  vmovaps xmm13, [rsp+0xC0]
0000710e9ebe28b3  vmovaps xmm14, [rsp+0xD0]
0000710e9ebe28bc  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe28c5  add rsp, 0xF0
0000710e9ebe28cc  pop r11
0000710e9ebe28ce  pop r10
0000710e9ebe28d0  pop r9
0000710e9ebe28d2  pop r8
0000710e9ebe28d4  pop rsi
0000710e9ebe28d5  pop rdi
0000710e9ebe28d6  pop rdx
0000710e9ebe28d7  pop rcx
0000710e9ebe28d8  pop rax
0000710e9ebe28d9  add rsp, 0x08
0000710e9ebe28dd  jmp 0x0000710E9EBDF5D8
0000710e9ebe28e2  sub rsp, 0x08
0000710e9ebe28e6  push rax
0000710e9ebe28e7  push rcx
0000710e9ebe28e8  push rdx
0000710e9ebe28e9  push rdi
0000710e9ebe28ea  push rsi
0000710e9ebe28eb  push r8
0000710e9ebe28ed  push r9
0000710e9ebe28ef  push r10
0000710e9ebe28f1  push r11
0000710e9ebe28f3  sub rsp, 0xF0
0000710e9ebe28fa  vmovaps [rsp], xmm0
0000710e9ebe28ff  vmovaps [rsp+0x10], xmm1
0000710e9ebe2905  vmovaps [rsp+0x20], xmm2
0000710e9ebe290b  vmovaps [rsp+0x30], xmm3
0000710e9ebe2911  vmovaps [rsp+0x40], xmm4
0000710e9ebe2917  vmovaps [rsp+0x50], xmm5
0000710e9ebe291d  vmovaps [rsp+0x60], xmm6
0000710e9ebe2923  vmovaps [rsp+0x70], xmm7
0000710e9ebe2929  vmovaps [rsp+0x80], xmm8
0000710e9ebe2932  vmovaps [rsp+0x90], xmm9
0000710e9ebe293b  vmovaps [rsp+0xA0], xmm10
0000710e9ebe2944  vmovaps [rsp+0xB0], xmm11
0000710e9ebe294d  vmovaps [rsp+0xC0], xmm12
0000710e9ebe2956  vmovaps [rsp+0xD0], xmm13
0000710e9ebe295f  vmovaps [rsp+0xE0], xmm15
0000710e9ebe2968  sub rsp, 0x30
0000710e9ebe296c  movaps [rsp], xmm14
0000710e9ebe2971  movaps [rsp+0x10], xmm8
0000710e9ebe2977  movaps [rsp+0x20], xmm4
0000710e9ebe297c  lea rdi, [rsp]
0000710e9ebe2980  mov esi, 0x00
0000710e9ebe2985  mov rax, 0x5DADAF7CF530
0000710e9ebe298f  call rax
0000710e9ebe2991  movaps xmm14, [rsp]
0000710e9ebe2996  add rsp, 0x30
0000710e9ebe299a  vmovaps xmm0, [rsp]
0000710e9ebe299f  vmovaps xmm1, [rsp+0x10]
0000710e9ebe29a5  vmovaps xmm2, [rsp+0x20]
0000710e9ebe29ab  vmovaps xmm3, [rsp+0x30]
0000710e9ebe29b1  vmovaps xmm4, [rsp+0x40]
0000710e9ebe29b7  vmovaps xmm5, [rsp+0x50]
0000710e9ebe29bd  vmovaps xmm6, [rsp+0x60]
0000710e9ebe29c3  vmovaps xmm7, [rsp+0x70]
0000710e9ebe29c9  vmovaps xmm8, [rsp+0x80]
0000710e9ebe29d2  vmovaps xmm9, [rsp+0x90]
0000710e9ebe29db  vmovaps xmm10, [rsp+0xA0]
0000710e9ebe29e4  vmovaps xmm11, [rsp+0xB0]
0000710e9ebe29ed  vmovaps xmm12, [rsp+0xC0]
0000710e9ebe29f6  vmovaps xmm13, [rsp+0xD0]
0000710e9ebe29ff  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe2a08  add rsp, 0xF0
0000710e9ebe2a0f  pop r11
0000710e9ebe2a11  pop r10
0000710e9ebe2a13  pop r9
0000710e9ebe2a15  pop r8
0000710e9ebe2a17  pop rsi
0000710e9ebe2a18  pop rdi
0000710e9ebe2a19  pop rdx
0000710e9ebe2a1a  pop rcx
0000710e9ebe2a1b  pop rax
0000710e9ebe2a1c  add rsp, 0x08
0000710e9ebe2a20  jmp 0x0000710E9EBDF5F8
0000710e9ebe2a25  sub rsp, 0x08
0000710e9ebe2a29  push rax
0000710e9ebe2a2a  push rcx
0000710e9ebe2a2b  push rdx
0000710e9ebe2a2c  push rdi
0000710e9ebe2a2d  push rsi
0000710e9ebe2a2e  push r8
0000710e9ebe2a30  push r9
0000710e9ebe2a32  push r10
0000710e9ebe2a34  push r11
0000710e9ebe2a36  sub rsp, 0xF0
0000710e9ebe2a3d  vmovaps [rsp], xmm0
0000710e9ebe2a42  vmovaps [rsp+0x10], xmm1
0000710e9ebe2a48  vmovaps [rsp+0x20], xmm2
0000710e9ebe2a4e  vmovaps [rsp+0x30], xmm3
0000710e9ebe2a54  vmovaps [rsp+0x40], xmm5
0000710e9ebe2a5a  vmovaps [rsp+0x50], xmm6
0000710e9ebe2a60  vmovaps [rsp+0x60], xmm7
0000710e9ebe2a66  vmovaps [rsp+0x70], xmm8
0000710e9ebe2a6c  vmovaps [rsp+0x80], xmm9
0000710e9ebe2a75  vmovaps [rsp+0x90], xmm10
0000710e9ebe2a7e  vmovaps [rsp+0xA0], xmm11
0000710e9ebe2a87  vmovaps [rsp+0xB0], xmm12
0000710e9ebe2a90  vmovaps [rsp+0xC0], xmm13
0000710e9ebe2a99  vmovaps [rsp+0xD0], xmm14
0000710e9ebe2aa2  vmovaps [rsp+0xE0], xmm15
0000710e9ebe2aab  sub rsp, 0x30
0000710e9ebe2aaf  movaps [rsp], xmm4
0000710e9ebe2ab3  movaps [rsp+0x10], xmm13
0000710e9ebe2ab9  movaps [rsp+0x20], xmm8
0000710e9ebe2abf  lea rdi, [rsp]
0000710e9ebe2ac3  mov esi, 0x00
0000710e9ebe2ac8  mov rax, 0x5DADAF7CF530
0000710e9ebe2ad2  call rax
0000710e9ebe2ad4  movaps xmm4, [rsp]
0000710e9ebe2ad8  add rsp, 0x30
0000710e9ebe2adc  vmovaps xmm0, [rsp]
0000710e9ebe2ae1  vmovaps xmm1, [rsp+0x10]
0000710e9ebe2ae7  vmovaps xmm2, [rsp+0x20]
0000710e9ebe2aed  vmovaps xmm3, [rsp+0x30]
0000710e9ebe2af3  vmovaps xmm5, [rsp+0x40]
0000710e9ebe2af9  vmovaps xmm6, [rsp+0x50]
0000710e9ebe2aff  vmovaps xmm7, [rsp+0x60]
0000710e9ebe2b05  vmovaps xmm8, [rsp+0x70]
0000710e9ebe2b0b  vmovaps xmm9, [rsp+0x80]
0000710e9ebe2b14  vmovaps xmm10, [rsp+0x90]
0000710e9ebe2b1d  vmovaps xmm11, [rsp+0xA0]
0000710e9ebe2b26  vmovaps xmm12, [rsp+0xB0]
0000710e9ebe2b2f  vmovaps xmm13, [rsp+0xC0]
0000710e9ebe2b38  vmovaps xmm14, [rsp+0xD0]
0000710e9ebe2b41  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe2b4a  add rsp, 0xF0
0000710e9ebe2b51  pop r11
0000710e9ebe2b53  pop r10
0000710e9ebe2b55  pop r9
0000710e9ebe2b57  pop r8
0000710e9ebe2b59  pop rsi
0000710e9ebe2b5a  pop rdi
0000710e9ebe2b5b  pop rdx
0000710e9ebe2b5c  pop rcx
0000710e9ebe2b5d  pop rax
0000710e9ebe2b5e  add rsp, 0x08
0000710e9ebe2b62  jmp 0x0000710E9EBDF61D
0000710e9ebe2b67  sub rsp, 0x08
0000710e9ebe2b6b  push rax
0000710e9ebe2b6c  push rcx
0000710e9ebe2b6d  push rdx
0000710e9ebe2b6e  push rdi
0000710e9ebe2b6f  push rsi
0000710e9ebe2b70  push r8
0000710e9ebe2b72  push r9
0000710e9ebe2b74  push r10
0000710e9ebe2b76  push r11
0000710e9ebe2b78  sub rsp, 0xF0
0000710e9ebe2b7f  vmovaps [rsp], xmm0
0000710e9ebe2b84  vmovaps [rsp+0x10], xmm1
0000710e9ebe2b8a  vmovaps [rsp+0x20], xmm2
0000710e9ebe2b90  vmovaps [rsp+0x30], xmm3
0000710e9ebe2b96  vmovaps [rsp+0x40], xmm4
0000710e9ebe2b9c  vmovaps [rsp+0x50], xmm5
0000710e9ebe2ba2  vmovaps [rsp+0x60], xmm6
0000710e9ebe2ba8  vmovaps [rsp+0x70], xmm7
0000710e9ebe2bae  vmovaps [rsp+0x80], xmm8
0000710e9ebe2bb7  vmovaps [rsp+0x90], xmm9
0000710e9ebe2bc0  vmovaps [rsp+0xA0], xmm10
0000710e9ebe2bc9  vmovaps [rsp+0xB0], xmm11
0000710e9ebe2bd2  vmovaps [rsp+0xC0], xmm12
0000710e9ebe2bdb  vmovaps [rsp+0xD0], xmm14
0000710e9ebe2be4  vmovaps [rsp+0xE0], xmm15
0000710e9ebe2bed  sub rsp, 0x30
0000710e9ebe2bf1  movaps [rsp], xmm13
0000710e9ebe2bf6  movaps [rsp+0x10], xmm15
0000710e9ebe2bfc  movaps [rsp+0x20], xmm9
0000710e9ebe2c02  lea rdi, [rsp]
0000710e9ebe2c06  mov esi, 0x00
0000710e9ebe2c0b  mov rax, 0x5DADAF7CF530
0000710e9ebe2c15  call rax
0000710e9ebe2c17  movaps xmm13, [rsp]
0000710e9ebe2c1c  add rsp, 0x30
0000710e9ebe2c20  vmovaps xmm0, [rsp]
0000710e9ebe2c25  vmovaps xmm1, [rsp+0x10]
0000710e9ebe2c2b  vmovaps xmm2, [rsp+0x20]
0000710e9ebe2c31  vmovaps xmm3, [rsp+0x30]
0000710e9ebe2c37  vmovaps xmm4, [rsp+0x40]
0000710e9ebe2c3d  vmovaps xmm5, [rsp+0x50]
0000710e9ebe2c43  vmovaps xmm6, [rsp+0x60]
0000710e9ebe2c49  vmovaps xmm7, [rsp+0x70]
0000710e9ebe2c4f  vmovaps xmm8, [rsp+0x80]
0000710e9ebe2c58  vmovaps xmm9, [rsp+0x90]
0000710e9ebe2c61  vmovaps xmm10, [rsp+0xA0]
0000710e9ebe2c6a  vmovaps xmm11, [rsp+0xB0]
0000710e9ebe2c73  vmovaps xmm12, [rsp+0xC0]
0000710e9ebe2c7c  vmovaps xmm14, [rsp+0xD0]
0000710e9ebe2c85  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe2c8e  add rsp, 0xF0
0000710e9ebe2c95  pop r11
0000710e9ebe2c97  pop r10
0000710e9ebe2c99  pop r9
0000710e9ebe2c9b  pop r8
0000710e9ebe2c9d  pop rsi
0000710e9ebe2c9e  pop rdi
0000710e9ebe2c9f  pop rdx
0000710e9ebe2ca0  pop rcx
0000710e9ebe2ca1  pop rax
0000710e9ebe2ca2  add rsp, 0x08
0000710e9ebe2ca6  jmp 0x0000710E9EBDF638
0000710e9ebe2cab  sub rsp, 0x08
0000710e9ebe2caf  push rax
0000710e9ebe2cb0  push rcx
0000710e9ebe2cb1  push rdx
0000710e9ebe2cb2  push rdi
0000710e9ebe2cb3  push rsi
0000710e9ebe2cb4  push r8
0000710e9ebe2cb6  push r9
0000710e9ebe2cb8  push r10
0000710e9ebe2cba  push r11
0000710e9ebe2cbc  sub rsp, 0xF0
0000710e9ebe2cc3  vmovaps [rsp], xmm0
0000710e9ebe2cc8  vmovaps [rsp+0x10], xmm1
0000710e9ebe2cce  vmovaps [rsp+0x20], xmm2
0000710e9ebe2cd4  vmovaps [rsp+0x30], xmm3
0000710e9ebe2cda  vmovaps [rsp+0x40], xmm4
0000710e9ebe2ce0  vmovaps [rsp+0x50], xmm5
0000710e9ebe2ce6  vmovaps [rsp+0x60], xmm6
0000710e9ebe2cec  vmovaps [rsp+0x70], xmm7
0000710e9ebe2cf2  vmovaps [rsp+0x80], xmm8
0000710e9ebe2cfb  vmovaps [rsp+0x90], xmm9
0000710e9ebe2d04  vmovaps [rsp+0xA0], xmm10
0000710e9ebe2d0d  vmovaps [rsp+0xB0], xmm11
0000710e9ebe2d16  vmovaps [rsp+0xC0], xmm12
0000710e9ebe2d1f  vmovaps [rsp+0xD0], xmm13
0000710e9ebe2d28  vmovaps [rsp+0xE0], xmm14
0000710e9ebe2d31  sub rsp, 0x30
0000710e9ebe2d35  movaps [rsp], xmm15
0000710e9ebe2d3a  movaps [rsp+0x10], xmm1
0000710e9ebe2d3f  movaps [rsp+0x20], xmm5
0000710e9ebe2d44  lea rdi, [rsp]
0000710e9ebe2d48  mov esi, 0x00
0000710e9ebe2d4d  mov rax, 0x5DADAF7CF530
0000710e9ebe2d57  call rax
0000710e9ebe2d59  movaps xmm15, [rsp]
0000710e9ebe2d5e  add rsp, 0x30
0000710e9ebe2d62  vmovaps xmm0, [rsp]
0000710e9ebe2d67  vmovaps xmm1, [rsp+0x10]
0000710e9ebe2d6d  vmovaps xmm2, [rsp+0x20]
0000710e9ebe2d73  vmovaps xmm3, [rsp+0x30]
0000710e9ebe2d79  vmovaps xmm4, [rsp+0x40]
0000710e9ebe2d7f  vmovaps xmm5, [rsp+0x50]
0000710e9ebe2d85  vmovaps xmm6, [rsp+0x60]
0000710e9ebe2d8b  vmovaps xmm7, [rsp+0x70]
0000710e9ebe2d91  vmovaps xmm8, [rsp+0x80]
0000710e9ebe2d9a  vmovaps xmm9, [rsp+0x90]
0000710e9ebe2da3  vmovaps xmm10, [rsp+0xA0]
0000710e9ebe2dac  vmovaps xmm11, [rsp+0xB0]
0000710e9ebe2db5  vmovaps xmm12, [rsp+0xC0]
0000710e9ebe2dbe  vmovaps xmm13, [rsp+0xD0]
0000710e9ebe2dc7  vmovaps xmm14, [rsp+0xE0]
0000710e9ebe2dd0  add rsp, 0xF0
0000710e9ebe2dd7  pop r11
0000710e9ebe2dd9  pop r10
0000710e9ebe2ddb  pop r9
0000710e9ebe2ddd  pop r8
0000710e9ebe2ddf  pop rsi
0000710e9ebe2de0  pop rdi
0000710e9ebe2de1  pop rdx
0000710e9ebe2de2  pop rcx
0000710e9ebe2de3  pop rax
0000710e9ebe2de4  add rsp, 0x08
0000710e9ebe2de8  jmp 0x0000710E9EBDF653
0000710e9ebe2ded  call 0x0000710E9EAB52F0
0000710e9ebe2df2  jmp 0x0000710E9EBDF6AE
0000710e9ebe2df7  sub rsp, 0x08
0000710e9ebe2dfb  push rax
0000710e9ebe2dfc  push rcx
0000710e9ebe2dfd  push rdx
0000710e9ebe2dfe  push rdi
0000710e9ebe2dff  push rsi
0000710e9ebe2e00  push r8
0000710e9ebe2e02  push r9
0000710e9ebe2e04  push r10
0000710e9ebe2e06  push r11
0000710e9ebe2e08  sub rsp, 0xF0
0000710e9ebe2e0f  vmovaps [rsp], xmm0
0000710e9ebe2e14  vmovaps [rsp+0x10], xmm1
0000710e9ebe2e1a  vmovaps [rsp+0x20], xmm2
0000710e9ebe2e20  vmovaps [rsp+0x30], xmm3
0000710e9ebe2e26  vmovaps [rsp+0x40], xmm4
0000710e9ebe2e2c  vmovaps [rsp+0x50], xmm5
0000710e9ebe2e32  vmovaps [rsp+0x60], xmm6
0000710e9ebe2e38  vmovaps [rsp+0x70], xmm7
0000710e9ebe2e3e  vmovaps [rsp+0x80], xmm8
0000710e9ebe2e47  vmovaps [rsp+0x90], xmm10
0000710e9ebe2e50  vmovaps [rsp+0xA0], xmm11
0000710e9ebe2e59  vmovaps [rsp+0xB0], xmm12
0000710e9ebe2e62  vmovaps [rsp+0xC0], xmm13
0000710e9ebe2e6b  vmovaps [rsp+0xD0], xmm14
0000710e9ebe2e74  vmovaps [rsp+0xE0], xmm15
0000710e9ebe2e7d  sub rsp, 0x30
0000710e9ebe2e81  movaps [rsp], xmm9
0000710e9ebe2e86  movaps [rsp+0x10], xmm8
0000710e9ebe2e8c  movaps [rsp+0x20], xmm11
0000710e9ebe2e92  lea rdi, [rsp]
0000710e9ebe2e96  mov esi, 0x00
0000710e9ebe2e9b  mov rax, 0x5DADAF7CF530
0000710e9ebe2ea5  call rax
0000710e9ebe2ea7  movaps xmm9, [rsp]
0000710e9ebe2eac  add rsp, 0x30
0000710e9ebe2eb0  vmovaps xmm0, [rsp]
0000710e9ebe2eb5  vmovaps xmm1, [rsp+0x10]
0000710e9ebe2ebb  vmovaps xmm2, [rsp+0x20]
0000710e9ebe2ec1  vmovaps xmm3, [rsp+0x30]
0000710e9ebe2ec7  vmovaps xmm4, [rsp+0x40]
0000710e9ebe2ecd  vmovaps xmm5, [rsp+0x50]
0000710e9ebe2ed3  vmovaps xmm6, [rsp+0x60]
0000710e9ebe2ed9  vmovaps xmm7, [rsp+0x70]
0000710e9ebe2edf  vmovaps xmm8, [rsp+0x80]
0000710e9ebe2ee8  vmovaps xmm10, [rsp+0x90]
0000710e9ebe2ef1  vmovaps xmm11, [rsp+0xA0]
0000710e9ebe2efa  vmovaps xmm12, [rsp+0xB0]
0000710e9ebe2f03  vmovaps xmm13, [rsp+0xC0]
0000710e9ebe2f0c  vmovaps xmm14, [rsp+0xD0]
0000710e9ebe2f15  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe2f1e  add rsp, 0xF0
0000710e9ebe2f25  pop r11
0000710e9ebe2f27  pop r10
0000710e9ebe2f29  pop r9
0000710e9ebe2f2b  pop r8
0000710e9ebe2f2d  pop rsi
0000710e9ebe2f2e  pop rdi
0000710e9ebe2f2f  pop rdx
0000710e9ebe2f30  pop rcx
0000710e9ebe2f31  pop rax
0000710e9ebe2f32  add rsp, 0x08
0000710e9ebe2f36  jmp 0x0000710E9EBDF6E5
0000710e9ebe2f3b  sub rsp, 0x08
0000710e9ebe2f3f  push rax
0000710e9ebe2f40  push rcx
0000710e9ebe2f41  push rdx
0000710e9ebe2f42  push rdi
0000710e9ebe2f43  push rsi
0000710e9ebe2f44  push r8
0000710e9ebe2f46  push r9
0000710e9ebe2f48  push r10
0000710e9ebe2f4a  push r11
0000710e9ebe2f4c  sub rsp, 0xF0
0000710e9ebe2f53  vmovaps [rsp], xmm0
0000710e9ebe2f58  vmovaps [rsp+0x10], xmm1
0000710e9ebe2f5e  vmovaps [rsp+0x20], xmm2
0000710e9ebe2f64  vmovaps [rsp+0x30], xmm3
0000710e9ebe2f6a  vmovaps [rsp+0x40], xmm4
0000710e9ebe2f70  vmovaps [rsp+0x50], xmm5
0000710e9ebe2f76  vmovaps [rsp+0x60], xmm6
0000710e9ebe2f7c  vmovaps [rsp+0x70], xmm7
0000710e9ebe2f82  vmovaps [rsp+0x80], xmm8
0000710e9ebe2f8b  vmovaps [rsp+0x90], xmm9
0000710e9ebe2f94  vmovaps [rsp+0xA0], xmm10
0000710e9ebe2f9d  vmovaps [rsp+0xB0], xmm12
0000710e9ebe2fa6  vmovaps [rsp+0xC0], xmm13
0000710e9ebe2faf  vmovaps [rsp+0xD0], xmm14
0000710e9ebe2fb8  vmovaps [rsp+0xE0], xmm15
0000710e9ebe2fc1  sub rsp, 0x30
0000710e9ebe2fc5  movaps [rsp], xmm11
0000710e9ebe2fca  movaps [rsp+0x10], xmm10
0000710e9ebe2fd0  movaps [rsp+0x20], xmm6
0000710e9ebe2fd5  lea rdi, [rsp]
0000710e9ebe2fd9  mov esi, 0x00
0000710e9ebe2fde  mov rax, 0x5DADAF7CF530
0000710e9ebe2fe8  call rax
0000710e9ebe2fea  movaps xmm11, [rsp]
0000710e9ebe2fef  add rsp, 0x30
0000710e9ebe2ff3  vmovaps xmm0, [rsp]
0000710e9ebe2ff8  vmovaps xmm1, [rsp+0x10]
0000710e9ebe2ffe  vmovaps xmm2, [rsp+0x20]
0000710e9ebe3004  vmovaps xmm3, [rsp+0x30]
0000710e9ebe300a  vmovaps xmm4, [rsp+0x40]
0000710e9ebe3010  vmovaps xmm5, [rsp+0x50]
0000710e9ebe3016  vmovaps xmm6, [rsp+0x60]
0000710e9ebe301c  vmovaps xmm7, [rsp+0x70]
0000710e9ebe3022  vmovaps xmm8, [rsp+0x80]
0000710e9ebe302b  vmovaps xmm9, [rsp+0x90]
0000710e9ebe3034  vmovaps xmm10, [rsp+0xA0]
0000710e9ebe303d  vmovaps xmm12, [rsp+0xB0]
0000710e9ebe3046  vmovaps xmm13, [rsp+0xC0]
0000710e9ebe304f  vmovaps xmm14, [rsp+0xD0]
0000710e9ebe3058  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe3061  add rsp, 0xF0
0000710e9ebe3068  pop r11
0000710e9ebe306a  pop r10
0000710e9ebe306c  pop r9
0000710e9ebe306e  pop r8
0000710e9ebe3070  pop rsi
0000710e9ebe3071  pop rdi
0000710e9ebe3072  pop rdx
0000710e9ebe3073  pop rcx
0000710e9ebe3074  pop rax
0000710e9ebe3075  add rsp, 0x08
0000710e9ebe3079  jmp 0x0000710E9EBDF700
0000710e9ebe307e  sub rsp, 0x08
0000710e9ebe3082  push rax
0000710e9ebe3083  push rcx
0000710e9ebe3084  push rdx
0000710e9ebe3085  push rdi
0000710e9ebe3086  push rsi
0000710e9ebe3087  push r8
0000710e9ebe3089  push r9
0000710e9ebe308b  push r10
0000710e9ebe308d  push r11
0000710e9ebe308f  sub rsp, 0xF0
0000710e9ebe3096  vmovaps [rsp], xmm0
0000710e9ebe309b  vmovaps [rsp+0x10], xmm1
0000710e9ebe30a1  vmovaps [rsp+0x20], xmm2
0000710e9ebe30a7  vmovaps [rsp+0x30], xmm3
0000710e9ebe30ad  vmovaps [rsp+0x40], xmm4
0000710e9ebe30b3  vmovaps [rsp+0x50], xmm5
0000710e9ebe30b9  vmovaps [rsp+0x60], xmm6
0000710e9ebe30bf  vmovaps [rsp+0x70], xmm7
0000710e9ebe30c5  vmovaps [rsp+0x80], xmm8
0000710e9ebe30ce  vmovaps [rsp+0x90], xmm9
0000710e9ebe30d7  vmovaps [rsp+0xA0], xmm11
0000710e9ebe30e0  vmovaps [rsp+0xB0], xmm12
0000710e9ebe30e9  vmovaps [rsp+0xC0], xmm13
0000710e9ebe30f2  vmovaps [rsp+0xD0], xmm14
0000710e9ebe30fb  vmovaps [rsp+0xE0], xmm15
0000710e9ebe3104  sub rsp, 0x30
0000710e9ebe3108  movaps [rsp], xmm10
0000710e9ebe310d  movaps [rsp+0x10], xmm14
0000710e9ebe3113  movaps [rsp+0x20], xmm4
0000710e9ebe3118  lea rdi, [rsp]
0000710e9ebe311c  mov esi, 0x00
0000710e9ebe3121  mov rax, 0x5DADAF7CF530
0000710e9ebe312b  call rax
0000710e9ebe312d  movaps xmm10, [rsp]
0000710e9ebe3132  add rsp, 0x30
0000710e9ebe3136  vmovaps xmm0, [rsp]
0000710e9ebe313b  vmovaps xmm1, [rsp+0x10]
0000710e9ebe3141  vmovaps xmm2, [rsp+0x20]
0000710e9ebe3147  vmovaps xmm3, [rsp+0x30]
0000710e9ebe314d  vmovaps xmm4, [rsp+0x40]
0000710e9ebe3153  vmovaps xmm5, [rsp+0x50]
0000710e9ebe3159  vmovaps xmm6, [rsp+0x60]
0000710e9ebe315f  vmovaps xmm7, [rsp+0x70]
0000710e9ebe3165  vmovaps xmm8, [rsp+0x80]
0000710e9ebe316e  vmovaps xmm9, [rsp+0x90]
0000710e9ebe3177  vmovaps xmm11, [rsp+0xA0]
0000710e9ebe3180  vmovaps xmm12, [rsp+0xB0]
0000710e9ebe3189  vmovaps xmm13, [rsp+0xC0]
0000710e9ebe3192  vmovaps xmm14, [rsp+0xD0]
0000710e9ebe319b  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe31a4  add rsp, 0xF0
0000710e9ebe31ab  pop r11
0000710e9ebe31ad  pop r10
0000710e9ebe31af  pop r9
0000710e9ebe31b1  pop r8
0000710e9ebe31b3  pop rsi
0000710e9ebe31b4  pop rdi
0000710e9ebe31b5  pop rdx
0000710e9ebe31b6  pop rcx
0000710e9ebe31b7  pop rax
0000710e9ebe31b8  add rsp, 0x08
0000710e9ebe31bc  jmp 0x0000710E9EBDF71B
0000710e9ebe31c1  sub rsp, 0x08
0000710e9ebe31c5  push rax
0000710e9ebe31c6  push rcx
0000710e9ebe31c7  push rdx
0000710e9ebe31c8  push rdi
0000710e9ebe31c9  push rsi
0000710e9ebe31ca  push r8
0000710e9ebe31cc  push r9
0000710e9ebe31ce  push r10
0000710e9ebe31d0  push r11
0000710e9ebe31d2  sub rsp, 0xF0
0000710e9ebe31d9  vmovaps [rsp], xmm0
0000710e9ebe31de  vmovaps [rsp+0x10], xmm1
0000710e9ebe31e4  vmovaps [rsp+0x20], xmm2
0000710e9ebe31ea  vmovaps [rsp+0x30], xmm3
0000710e9ebe31f0  vmovaps [rsp+0x40], xmm4
0000710e9ebe31f6  vmovaps [rsp+0x50], xmm5
0000710e9ebe31fc  vmovaps [rsp+0x60], xmm6
0000710e9ebe3202  vmovaps [rsp+0x70], xmm7
0000710e9ebe3208  vmovaps [rsp+0x80], xmm9
0000710e9ebe3211  vmovaps [rsp+0x90], xmm10
0000710e9ebe321a  vmovaps [rsp+0xA0], xmm11
0000710e9ebe3223  vmovaps [rsp+0xB0], xmm12
0000710e9ebe322c  vmovaps [rsp+0xC0], xmm13
0000710e9ebe3235  vmovaps [rsp+0xD0], xmm14
0000710e9ebe323e  vmovaps [rsp+0xE0], xmm15
0000710e9ebe3247  sub rsp, 0x30
0000710e9ebe324b  movaps [rsp], xmm8
0000710e9ebe3250  movaps [rsp+0x10], xmm1
0000710e9ebe3255  movaps [rsp+0x20], xmm14
0000710e9ebe325b  lea rdi, [rsp]
0000710e9ebe325f  mov esi, 0x00
0000710e9ebe3264  mov rax, 0x5DADAF7CF530
0000710e9ebe326e  call rax
0000710e9ebe3270  movaps xmm8, [rsp]
0000710e9ebe3275  add rsp, 0x30
0000710e9ebe3279  vmovaps xmm0, [rsp]
0000710e9ebe327e  vmovaps xmm1, [rsp+0x10]
0000710e9ebe3284  vmovaps xmm2, [rsp+0x20]
0000710e9ebe328a  vmovaps xmm3, [rsp+0x30]
0000710e9ebe3290  vmovaps xmm4, [rsp+0x40]
0000710e9ebe3296  vmovaps xmm5, [rsp+0x50]
0000710e9ebe329c  vmovaps xmm6, [rsp+0x60]
0000710e9ebe32a2  vmovaps xmm7, [rsp+0x70]
0000710e9ebe32a8  vmovaps xmm9, [rsp+0x80]
0000710e9ebe32b1  vmovaps xmm10, [rsp+0x90]
0000710e9ebe32ba  vmovaps xmm11, [rsp+0xA0]
0000710e9ebe32c3  vmovaps xmm12, [rsp+0xB0]
0000710e9ebe32cc  vmovaps xmm13, [rsp+0xC0]
0000710e9ebe32d5  vmovaps xmm14, [rsp+0xD0]
0000710e9ebe32de  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe32e7  add rsp, 0xF0
0000710e9ebe32ee  pop r11
0000710e9ebe32f0  pop r10
0000710e9ebe32f2  pop r9
0000710e9ebe32f4  pop r8
0000710e9ebe32f6  pop rsi
0000710e9ebe32f7  pop rdi
0000710e9ebe32f8  pop rdx
0000710e9ebe32f9  pop rcx
0000710e9ebe32fa  pop rax
0000710e9ebe32fb  add rsp, 0x08
0000710e9ebe32ff  jmp 0x0000710E9EBDF741
0000710e9ebe3304  sub rsp, 0x08
0000710e9ebe3308  push rax
0000710e9ebe3309  push rcx
0000710e9ebe330a  push rdx
0000710e9ebe330b  push rdi
0000710e9ebe330c  push rsi
0000710e9ebe330d  push r8
0000710e9ebe330f  push r9
0000710e9ebe3311  push r10
0000710e9ebe3313  push r11
0000710e9ebe3315  sub rsp, 0xF0
0000710e9ebe331c  vmovaps [rsp], xmm0
0000710e9ebe3321  vmovaps [rsp+0x10], xmm1
0000710e9ebe3327  vmovaps [rsp+0x20], xmm2
0000710e9ebe332d  vmovaps [rsp+0x30], xmm3
0000710e9ebe3333  vmovaps [rsp+0x40], xmm4
0000710e9ebe3339  vmovaps [rsp+0x50], xmm5
0000710e9ebe333f  vmovaps [rsp+0x60], xmm7
0000710e9ebe3345  vmovaps [rsp+0x70], xmm8
0000710e9ebe334b  vmovaps [rsp+0x80], xmm9
0000710e9ebe3354  vmovaps [rsp+0x90], xmm10
0000710e9ebe335d  vmovaps [rsp+0xA0], xmm11
0000710e9ebe3366  vmovaps [rsp+0xB0], xmm12
0000710e9ebe336f  vmovaps [rsp+0xC0], xmm13
0000710e9ebe3378  vmovaps [rsp+0xD0], xmm14
0000710e9ebe3381  vmovaps [rsp+0xE0], xmm15
0000710e9ebe338a  sub rsp, 0x30
0000710e9ebe338e  movaps [rsp], xmm6
0000710e9ebe3392  movaps [rsp+0x10], xmm1
0000710e9ebe3397  movaps [rsp+0x20], xmm14
0000710e9ebe339d  lea rdi, [rsp]
0000710e9ebe33a1  mov esi, 0x00
0000710e9ebe33a6  mov rax, 0x5DADAF7CF530
0000710e9ebe33b0  call rax
0000710e9ebe33b2  movaps xmm6, [rsp]
0000710e9ebe33b6  add rsp, 0x30
0000710e9ebe33ba  vmovaps xmm0, [rsp]
0000710e9ebe33bf  vmovaps xmm1, [rsp+0x10]
0000710e9ebe33c5  vmovaps xmm2, [rsp+0x20]
0000710e9ebe33cb  vmovaps xmm3, [rsp+0x30]
0000710e9ebe33d1  vmovaps xmm4, [rsp+0x40]
0000710e9ebe33d7  vmovaps xmm5, [rsp+0x50]
0000710e9ebe33dd  vmovaps xmm7, [rsp+0x60]
0000710e9ebe33e3  vmovaps xmm8, [rsp+0x70]
0000710e9ebe33e9  vmovaps xmm9, [rsp+0x80]
0000710e9ebe33f2  vmovaps xmm10, [rsp+0x90]
0000710e9ebe33fb  vmovaps xmm11, [rsp+0xA0]
0000710e9ebe3404  vmovaps xmm12, [rsp+0xB0]
0000710e9ebe340d  vmovaps xmm13, [rsp+0xC0]
0000710e9ebe3416  vmovaps xmm14, [rsp+0xD0]
0000710e9ebe341f  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe3428  add rsp, 0xF0
0000710e9ebe342f  pop r11
0000710e9ebe3431  pop r10
0000710e9ebe3433  pop r9
0000710e9ebe3435  pop r8
0000710e9ebe3437  pop rsi
0000710e9ebe3438  pop rdi
0000710e9ebe3439  pop rdx
0000710e9ebe343a  pop rcx
0000710e9ebe343b  pop rax
0000710e9ebe343c  add rsp, 0x08
0000710e9ebe3440  jmp 0x0000710E9EBDF76D
0000710e9ebe3445  sub rsp, 0x08
0000710e9ebe3449  push rax
0000710e9ebe344a  push rcx
0000710e9ebe344b  push rdx
0000710e9ebe344c  push rdi
0000710e9ebe344d  push rsi
0000710e9ebe344e  push r8
0000710e9ebe3450  push r9
0000710e9ebe3452  push r10
0000710e9ebe3454  push r11
0000710e9ebe3456  sub rsp, 0xF0
0000710e9ebe345d  vmovaps [rsp], xmm0
0000710e9ebe3462  vmovaps [rsp+0x10], xmm1
0000710e9ebe3468  vmovaps [rsp+0x20], xmm2
0000710e9ebe346e  vmovaps [rsp+0x30], xmm3
0000710e9ebe3474  vmovaps [rsp+0x40], xmm4
0000710e9ebe347a  vmovaps [rsp+0x50], xmm5
0000710e9ebe3480  vmovaps [rsp+0x60], xmm6
0000710e9ebe3486  vmovaps [rsp+0x70], xmm7
0000710e9ebe348c  vmovaps [rsp+0x80], xmm8
0000710e9ebe3495  vmovaps [rsp+0x90], xmm9
0000710e9ebe349e  vmovaps [rsp+0xA0], xmm10
0000710e9ebe34a7  vmovaps [rsp+0xB0], xmm11
0000710e9ebe34b0  vmovaps [rsp+0xC0], xmm12
0000710e9ebe34b9  vmovaps [rsp+0xD0], xmm13
0000710e9ebe34c2  vmovaps [rsp+0xE0], xmm15
0000710e9ebe34cb  sub rsp, 0x30
0000710e9ebe34cf  movaps [rsp], xmm14
0000710e9ebe34d4  movaps [rsp+0x10], xmm12
0000710e9ebe34da  movaps [rsp+0x20], xmm1
0000710e9ebe34df  lea rdi, [rsp]
0000710e9ebe34e3  mov esi, 0x00
0000710e9ebe34e8  mov rax, 0x5DADAF7CF530
0000710e9ebe34f2  call rax
0000710e9ebe34f4  movaps xmm14, [rsp]
0000710e9ebe34f9  add rsp, 0x30
0000710e9ebe34fd  vmovaps xmm0, [rsp]
0000710e9ebe3502  vmovaps xmm1, [rsp+0x10]
0000710e9ebe3508  vmovaps xmm2, [rsp+0x20]
0000710e9ebe350e  vmovaps xmm3, [rsp+0x30]
0000710e9ebe3514  vmovaps xmm4, [rsp+0x40]
0000710e9ebe351a  vmovaps xmm5, [rsp+0x50]
0000710e9ebe3520  vmovaps xmm6, [rsp+0x60]
0000710e9ebe3526  vmovaps xmm7, [rsp+0x70]
0000710e9ebe352c  vmovaps xmm8, [rsp+0x80]
0000710e9ebe3535  vmovaps xmm9, [rsp+0x90]
0000710e9ebe353e  vmovaps xmm10, [rsp+0xA0]
0000710e9ebe3547  vmovaps xmm11, [rsp+0xB0]
0000710e9ebe3550  vmovaps xmm12, [rsp+0xC0]
0000710e9ebe3559  vmovaps xmm13, [rsp+0xD0]
0000710e9ebe3562  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe356b  add rsp, 0xF0
0000710e9ebe3572  pop r11
0000710e9ebe3574  pop r10
0000710e9ebe3576  pop r9
0000710e9ebe3578  pop r8
0000710e9ebe357a  pop rsi
0000710e9ebe357b  pop rdi
0000710e9ebe357c  pop rdx
0000710e9ebe357d  pop rcx
0000710e9ebe357e  pop rax
0000710e9ebe357f  add rsp, 0x08
0000710e9ebe3583  jmp 0x0000710E9EBDF793
0000710e9ebe3588  sub rsp, 0x08
0000710e9ebe358c  push rax
0000710e9ebe358d  push rcx
0000710e9ebe358e  push rdx
0000710e9ebe358f  push rdi
0000710e9ebe3590  push rsi
0000710e9ebe3591  push r8
0000710e9ebe3593  push r9
0000710e9ebe3595  push r10
0000710e9ebe3597  push r11
0000710e9ebe3599  sub rsp, 0xF0
0000710e9ebe35a0  vmovaps [rsp], xmm0
0000710e9ebe35a5  vmovaps [rsp+0x10], xmm2
0000710e9ebe35ab  vmovaps [rsp+0x20], xmm3
0000710e9ebe35b1  vmovaps [rsp+0x30], xmm4
0000710e9ebe35b7  vmovaps [rsp+0x40], xmm5
0000710e9ebe35bd  vmovaps [rsp+0x50], xmm6
0000710e9ebe35c3  vmovaps [rsp+0x60], xmm7
0000710e9ebe35c9  vmovaps [rsp+0x70], xmm8
0000710e9ebe35cf  vmovaps [rsp+0x80], xmm9
0000710e9ebe35d8  vmovaps [rsp+0x90], xmm10
0000710e9ebe35e1  vmovaps [rsp+0xA0], xmm11
0000710e9ebe35ea  vmovaps [rsp+0xB0], xmm12
0000710e9ebe35f3  vmovaps [rsp+0xC0], xmm13
0000710e9ebe35fc  vmovaps [rsp+0xD0], xmm14
0000710e9ebe3605  vmovaps [rsp+0xE0], xmm15
0000710e9ebe360e  sub rsp, 0x30
0000710e9ebe3612  movaps [rsp], xmm1
0000710e9ebe3616  movaps [rsp+0x10], xmm13
0000710e9ebe361c  movaps [rsp+0x20], xmm9
0000710e9ebe3622  lea rdi, [rsp]
0000710e9ebe3626  mov esi, 0x00
0000710e9ebe362b  mov rax, 0x5DADAF7CF530
0000710e9ebe3635  call rax
0000710e9ebe3637  movaps xmm1, [rsp]
0000710e9ebe363b  add rsp, 0x30
0000710e9ebe363f  vmovaps xmm0, [rsp]
0000710e9ebe3644  vmovaps xmm2, [rsp+0x10]
0000710e9ebe364a  vmovaps xmm3, [rsp+0x20]
0000710e9ebe3650  vmovaps xmm4, [rsp+0x30]
0000710e9ebe3656  vmovaps xmm5, [rsp+0x40]
0000710e9ebe365c  vmovaps xmm6, [rsp+0x50]
0000710e9ebe3662  vmovaps xmm7, [rsp+0x60]
0000710e9ebe3668  vmovaps xmm8, [rsp+0x70]
0000710e9ebe366e  vmovaps xmm9, [rsp+0x80]
0000710e9ebe3677  vmovaps xmm10, [rsp+0x90]
0000710e9ebe3680  vmovaps xmm11, [rsp+0xA0]
0000710e9ebe3689  vmovaps xmm12, [rsp+0xB0]
0000710e9ebe3692  vmovaps xmm13, [rsp+0xC0]
0000710e9ebe369b  vmovaps xmm14, [rsp+0xD0]
0000710e9ebe36a4  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe36ad  add rsp, 0xF0
0000710e9ebe36b4  pop r11
0000710e9ebe36b6  pop r10
0000710e9ebe36b8  pop r9
0000710e9ebe36ba  pop r8
0000710e9ebe36bc  pop rsi
0000710e9ebe36bd  pop rdi
0000710e9ebe36be  pop rdx
0000710e9ebe36bf  pop rcx
0000710e9ebe36c0  pop rax
0000710e9ebe36c1  add rsp, 0x08
0000710e9ebe36c5  jmp 0x0000710E9EBDF7AD
0000710e9ebe36ca  sub rsp, 0x08
0000710e9ebe36ce  push rax
0000710e9ebe36cf  push rcx
0000710e9ebe36d0  push rdx
0000710e9ebe36d1  push rdi
0000710e9ebe36d2  push rsi
0000710e9ebe36d3  push r8
0000710e9ebe36d5  push r9
0000710e9ebe36d7  push r10
0000710e9ebe36d9  push r11
0000710e9ebe36db  sub rsp, 0xF0
0000710e9ebe36e2  vmovaps [rsp], xmm0
0000710e9ebe36e7  vmovaps [rsp+0x10], xmm1
0000710e9ebe36ed  vmovaps [rsp+0x20], xmm2
0000710e9ebe36f3  vmovaps [rsp+0x30], xmm3
0000710e9ebe36f9  vmovaps [rsp+0x40], xmm4
0000710e9ebe36ff  vmovaps [rsp+0x50], xmm5
0000710e9ebe3705  vmovaps [rsp+0x60], xmm6
0000710e9ebe370b  vmovaps [rsp+0x70], xmm7
0000710e9ebe3711  vmovaps [rsp+0x80], xmm8
0000710e9ebe371a  vmovaps [rsp+0x90], xmm9
0000710e9ebe3723  vmovaps [rsp+0xA0], xmm10
0000710e9ebe372c  vmovaps [rsp+0xB0], xmm11
0000710e9ebe3735  vmovaps [rsp+0xC0], xmm13
0000710e9ebe373e  vmovaps [rsp+0xD0], xmm14
0000710e9ebe3747  vmovaps [rsp+0xE0], xmm15
0000710e9ebe3750  sub rsp, 0x30
0000710e9ebe3754  movaps [rsp], xmm12
0000710e9ebe3759  movaps [rsp+0x10], xmm7
0000710e9ebe375e  movaps [rsp+0x20], xmm13
0000710e9ebe3764  lea rdi, [rsp]
0000710e9ebe3768  mov esi, 0x00
0000710e9ebe376d  mov rax, 0x5DADAF7CF530
0000710e9ebe3777  call rax
0000710e9ebe3779  movaps xmm12, [rsp]
0000710e9ebe377e  add rsp, 0x30
0000710e9ebe3782  vmovaps xmm0, [rsp]
0000710e9ebe3787  vmovaps xmm1, [rsp+0x10]
0000710e9ebe378d  vmovaps xmm2, [rsp+0x20]
0000710e9ebe3793  vmovaps xmm3, [rsp+0x30]
0000710e9ebe3799  vmovaps xmm4, [rsp+0x40]
0000710e9ebe379f  vmovaps xmm5, [rsp+0x50]
0000710e9ebe37a5  vmovaps xmm6, [rsp+0x60]
0000710e9ebe37ab  vmovaps xmm7, [rsp+0x70]
0000710e9ebe37b1  vmovaps xmm8, [rsp+0x80]
0000710e9ebe37ba  vmovaps xmm9, [rsp+0x90]
0000710e9ebe37c3  vmovaps xmm10, [rsp+0xA0]
0000710e9ebe37cc  vmovaps xmm11, [rsp+0xB0]
0000710e9ebe37d5  vmovaps xmm13, [rsp+0xC0]
0000710e9ebe37de  vmovaps xmm14, [rsp+0xD0]
0000710e9ebe37e7  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe37f0  add rsp, 0xF0
0000710e9ebe37f7  pop r11
0000710e9ebe37f9  pop r10
0000710e9ebe37fb  pop r9
0000710e9ebe37fd  pop r8
0000710e9ebe37ff  pop rsi
0000710e9ebe3800  pop rdi
0000710e9ebe3801  pop rdx
0000710e9ebe3802  pop rcx
0000710e9ebe3803  pop rax
0000710e9ebe3804  add rsp, 0x08
0000710e9ebe3808  jmp 0x0000710E9EBDF7D4
0000710e9ebe380d  sub rsp, 0x08
0000710e9ebe3811  push rax
0000710e9ebe3812  push rcx
0000710e9ebe3813  push rdx
0000710e9ebe3814  push rdi
0000710e9ebe3815  push rsi
0000710e9ebe3816  push r8
0000710e9ebe3818  push r9
0000710e9ebe381a  push r10
0000710e9ebe381c  push r11
0000710e9ebe381e  sub rsp, 0xF0
0000710e9ebe3825  vmovaps [rsp], xmm0
0000710e9ebe382a  vmovaps [rsp+0x10], xmm1
0000710e9ebe3830  vmovaps [rsp+0x20], xmm2
0000710e9ebe3836  vmovaps [rsp+0x30], xmm3
0000710e9ebe383c  vmovaps [rsp+0x40], xmm4
0000710e9ebe3842  vmovaps [rsp+0x50], xmm5
0000710e9ebe3848  vmovaps [rsp+0x60], xmm6
0000710e9ebe384e  vmovaps [rsp+0x70], xmm7
0000710e9ebe3854  vmovaps [rsp+0x80], xmm8
0000710e9ebe385d  vmovaps [rsp+0x90], xmm9
0000710e9ebe3866  vmovaps [rsp+0xA0], xmm10
0000710e9ebe386f  vmovaps [rsp+0xB0], xmm11
0000710e9ebe3878  vmovaps [rsp+0xC0], xmm12
0000710e9ebe3881  vmovaps [rsp+0xD0], xmm14
0000710e9ebe388a  vmovaps [rsp+0xE0], xmm15
0000710e9ebe3893  sub rsp, 0x30
0000710e9ebe3897  movaps [rsp], xmm13
0000710e9ebe389c  movaps [rsp+0x10], xmm15
0000710e9ebe38a2  movaps [rsp+0x20], xmm8
0000710e9ebe38a8  lea rdi, [rsp]
0000710e9ebe38ac  mov esi, 0x00
0000710e9ebe38b1  mov rax, 0x5DADAF7CF530
0000710e9ebe38bb  call rax
0000710e9ebe38bd  movaps xmm13, [rsp]
0000710e9ebe38c2  add rsp, 0x30
0000710e9ebe38c6  vmovaps xmm0, [rsp]
0000710e9ebe38cb  vmovaps xmm1, [rsp+0x10]
0000710e9ebe38d1  vmovaps xmm2, [rsp+0x20]
0000710e9ebe38d7  vmovaps xmm3, [rsp+0x30]
0000710e9ebe38dd  vmovaps xmm4, [rsp+0x40]
0000710e9ebe38e3  vmovaps xmm5, [rsp+0x50]
0000710e9ebe38e9  vmovaps xmm6, [rsp+0x60]
0000710e9ebe38ef  vmovaps xmm7, [rsp+0x70]
0000710e9ebe38f5  vmovaps xmm8, [rsp+0x80]
0000710e9ebe38fe  vmovaps xmm9, [rsp+0x90]
0000710e9ebe3907  vmovaps xmm10, [rsp+0xA0]
0000710e9ebe3910  vmovaps xmm11, [rsp+0xB0]
0000710e9ebe3919  vmovaps xmm12, [rsp+0xC0]
0000710e9ebe3922  vmovaps xmm14, [rsp+0xD0]
0000710e9ebe392b  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe3934  add rsp, 0xF0
0000710e9ebe393b  pop r11
0000710e9ebe393d  pop r10
0000710e9ebe393f  pop r9
0000710e9ebe3941  pop r8
0000710e9ebe3943  pop rsi
0000710e9ebe3944  pop rdi
0000710e9ebe3945  pop rdx
0000710e9ebe3946  pop rcx
0000710e9ebe3947  pop rax
0000710e9ebe3948  add rsp, 0x08
0000710e9ebe394c  jmp 0x0000710E9EBDF7EF
0000710e9ebe3951  sub rsp, 0x08
0000710e9ebe3955  push rax
0000710e9ebe3956  push rcx
0000710e9ebe3957  push rdx
0000710e9ebe3958  push rdi
0000710e9ebe3959  push rsi
0000710e9ebe395a  push r8
0000710e9ebe395c  push r9
0000710e9ebe395e  push r10
0000710e9ebe3960  push r11
0000710e9ebe3962  sub rsp, 0xF0
0000710e9ebe3969  vmovaps [rsp], xmm0
0000710e9ebe396e  vmovaps [rsp+0x10], xmm1
0000710e9ebe3974  vmovaps [rsp+0x20], xmm2
0000710e9ebe397a  vmovaps [rsp+0x30], xmm3
0000710e9ebe3980  vmovaps [rsp+0x40], xmm4
0000710e9ebe3986  vmovaps [rsp+0x50], xmm5
0000710e9ebe398c  vmovaps [rsp+0x60], xmm6
0000710e9ebe3992  vmovaps [rsp+0x70], xmm7
0000710e9ebe3998  vmovaps [rsp+0x80], xmm9
0000710e9ebe39a1  vmovaps [rsp+0x90], xmm10
0000710e9ebe39aa  vmovaps [rsp+0xA0], xmm11
0000710e9ebe39b3  vmovaps [rsp+0xB0], xmm12
0000710e9ebe39bc  vmovaps [rsp+0xC0], xmm13
0000710e9ebe39c5  vmovaps [rsp+0xD0], xmm14
0000710e9ebe39ce  vmovaps [rsp+0xE0], xmm15
0000710e9ebe39d7  sub rsp, 0x30
0000710e9ebe39db  movaps [rsp], xmm8
0000710e9ebe39e0  movaps [rsp+0x10], xmm15
0000710e9ebe39e6  movaps [rsp+0x20], xmm9
0000710e9ebe39ec  lea rdi, [rsp]
0000710e9ebe39f0  mov esi, 0x00
0000710e9ebe39f5  mov rax, 0x5DADAF7CF530
0000710e9ebe39ff  call rax
0000710e9ebe3a01  movaps xmm8, [rsp]
0000710e9ebe3a06  add rsp, 0x30
0000710e9ebe3a0a  vmovaps xmm0, [rsp]
0000710e9ebe3a0f  vmovaps xmm1, [rsp+0x10]
0000710e9ebe3a15  vmovaps xmm2, [rsp+0x20]
0000710e9ebe3a1b  vmovaps xmm3, [rsp+0x30]
0000710e9ebe3a21  vmovaps xmm4, [rsp+0x40]
0000710e9ebe3a27  vmovaps xmm5, [rsp+0x50]
0000710e9ebe3a2d  vmovaps xmm6, [rsp+0x60]
0000710e9ebe3a33  vmovaps xmm7, [rsp+0x70]
0000710e9ebe3a39  vmovaps xmm9, [rsp+0x80]
0000710e9ebe3a42  vmovaps xmm10, [rsp+0x90]
0000710e9ebe3a4b  vmovaps xmm11, [rsp+0xA0]
0000710e9ebe3a54  vmovaps xmm12, [rsp+0xB0]
0000710e9ebe3a5d  vmovaps xmm13, [rsp+0xC0]
0000710e9ebe3a66  vmovaps xmm14, [rsp+0xD0]
0000710e9ebe3a6f  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe3a78  add rsp, 0xF0
0000710e9ebe3a7f  pop r11
0000710e9ebe3a81  pop r10
0000710e9ebe3a83  pop r9
0000710e9ebe3a85  pop r8
0000710e9ebe3a87  pop rsi
0000710e9ebe3a88  pop rdi
0000710e9ebe3a89  pop rdx
0000710e9ebe3a8a  pop rcx
0000710e9ebe3a8b  pop rax
0000710e9ebe3a8c  add rsp, 0x08
0000710e9ebe3a90  jmp 0x0000710E9EBDF81D
0000710e9ebe3a95  sub rsp, 0x08
0000710e9ebe3a99  push rax
0000710e9ebe3a9a  push rcx
0000710e9ebe3a9b  push rdx
0000710e9ebe3a9c  push rdi
0000710e9ebe3a9d  push rsi
0000710e9ebe3a9e  push r8
0000710e9ebe3aa0  push r9
0000710e9ebe3aa2  push r10
0000710e9ebe3aa4  push r11
0000710e9ebe3aa6  sub rsp, 0xF0
0000710e9ebe3aad  vmovaps [rsp], xmm0
0000710e9ebe3ab2  vmovaps [rsp+0x10], xmm1
0000710e9ebe3ab8  vmovaps [rsp+0x20], xmm2
0000710e9ebe3abe  vmovaps [rsp+0x30], xmm3
0000710e9ebe3ac4  vmovaps [rsp+0x40], xmm4
0000710e9ebe3aca  vmovaps [rsp+0x50], xmm5
0000710e9ebe3ad0  vmovaps [rsp+0x60], xmm6
0000710e9ebe3ad6  vmovaps [rsp+0x70], xmm7
0000710e9ebe3adc  vmovaps [rsp+0x80], xmm8
0000710e9ebe3ae5  vmovaps [rsp+0x90], xmm9
0000710e9ebe3aee  vmovaps [rsp+0xA0], xmm10
0000710e9ebe3af7  vmovaps [rsp+0xB0], xmm11
0000710e9ebe3b00  vmovaps [rsp+0xC0], xmm12
0000710e9ebe3b09  vmovaps [rsp+0xD0], xmm13
0000710e9ebe3b12  vmovaps [rsp+0xE0], xmm14
0000710e9ebe3b1b  sub rsp, 0x30
0000710e9ebe3b1f  movaps [rsp], xmm15
0000710e9ebe3b24  movaps [rsp+0x10], xmm11
0000710e9ebe3b2a  movaps [rsp+0x20], xmm6
0000710e9ebe3b2f  lea rdi, [rsp]
0000710e9ebe3b33  mov esi, 0x00
0000710e9ebe3b38  mov rax, 0x5DADAF7CF530
0000710e9ebe3b42  call rax
0000710e9ebe3b44  movaps xmm15, [rsp]
0000710e9ebe3b49  add rsp, 0x30
0000710e9ebe3b4d  vmovaps xmm0, [rsp]
0000710e9ebe3b52  vmovaps xmm1, [rsp+0x10]
0000710e9ebe3b58  vmovaps xmm2, [rsp+0x20]
0000710e9ebe3b5e  vmovaps xmm3, [rsp+0x30]
0000710e9ebe3b64  vmovaps xmm4, [rsp+0x40]
0000710e9ebe3b6a  vmovaps xmm5, [rsp+0x50]
0000710e9ebe3b70  vmovaps xmm6, [rsp+0x60]
0000710e9ebe3b76  vmovaps xmm7, [rsp+0x70]
0000710e9ebe3b7c  vmovaps xmm8, [rsp+0x80]
0000710e9ebe3b85  vmovaps xmm9, [rsp+0x90]
0000710e9ebe3b8e  vmovaps xmm10, [rsp+0xA0]
0000710e9ebe3b97  vmovaps xmm11, [rsp+0xB0]
0000710e9ebe3ba0  vmovaps xmm12, [rsp+0xC0]
0000710e9ebe3ba9  vmovaps xmm13, [rsp+0xD0]
0000710e9ebe3bb2  vmovaps xmm14, [rsp+0xE0]
0000710e9ebe3bbb  add rsp, 0xF0
0000710e9ebe3bc2  pop r11
0000710e9ebe3bc4  pop r10
0000710e9ebe3bc6  pop r9
0000710e9ebe3bc8  pop r8
0000710e9ebe3bca  pop rsi
0000710e9ebe3bcb  pop rdi
0000710e9ebe3bcc  pop rdx
0000710e9ebe3bcd  pop rcx
0000710e9ebe3bce  pop rax
0000710e9ebe3bcf  add rsp, 0x08
0000710e9ebe3bd3  jmp 0x0000710E9EBDF838
0000710e9ebe3bd8  sub rsp, 0x08
0000710e9ebe3bdc  push rax
0000710e9ebe3bdd  push rcx
0000710e9ebe3bde  push rdx
0000710e9ebe3bdf  push rdi
0000710e9ebe3be0  push rsi
0000710e9ebe3be1  push r8
0000710e9ebe3be3  push r9
0000710e9ebe3be5  push r10
0000710e9ebe3be7  push r11
0000710e9ebe3be9  sub rsp, 0xF0
0000710e9ebe3bf0  vmovaps [rsp], xmm0
0000710e9ebe3bf5  vmovaps [rsp+0x10], xmm1
0000710e9ebe3bfb  vmovaps [rsp+0x20], xmm2
0000710e9ebe3c01  vmovaps [rsp+0x30], xmm3
0000710e9ebe3c07  vmovaps [rsp+0x40], xmm4
0000710e9ebe3c0d  vmovaps [rsp+0x50], xmm5
0000710e9ebe3c13  vmovaps [rsp+0x60], xmm6
0000710e9ebe3c19  vmovaps [rsp+0x70], xmm8
0000710e9ebe3c1f  vmovaps [rsp+0x80], xmm9
0000710e9ebe3c28  vmovaps [rsp+0x90], xmm10
0000710e9ebe3c31  vmovaps [rsp+0xA0], xmm11
0000710e9ebe3c3a  vmovaps [rsp+0xB0], xmm12
0000710e9ebe3c43  vmovaps [rsp+0xC0], xmm13
0000710e9ebe3c4c  vmovaps [rsp+0xD0], xmm14
0000710e9ebe3c55  vmovaps [rsp+0xE0], xmm15
0000710e9ebe3c5e  sub rsp, 0x30
0000710e9ebe3c62  movaps [rsp], xmm7
0000710e9ebe3c66  movaps [rsp+0x10], xmm11
0000710e9ebe3c6c  movaps [rsp+0x20], xmm9
0000710e9ebe3c72  lea rdi, [rsp]
0000710e9ebe3c76  mov esi, 0x00
0000710e9ebe3c7b  mov rax, 0x5DADAF7CF530
0000710e9ebe3c85  call rax
0000710e9ebe3c87  movaps xmm7, [rsp]
0000710e9ebe3c8b  add rsp, 0x30
0000710e9ebe3c8f  vmovaps xmm0, [rsp]
0000710e9ebe3c94  vmovaps xmm1, [rsp+0x10]
0000710e9ebe3c9a  vmovaps xmm2, [rsp+0x20]
0000710e9ebe3ca0  vmovaps xmm3, [rsp+0x30]
0000710e9ebe3ca6  vmovaps xmm4, [rsp+0x40]
0000710e9ebe3cac  vmovaps xmm5, [rsp+0x50]
0000710e9ebe3cb2  vmovaps xmm6, [rsp+0x60]
0000710e9ebe3cb8  vmovaps xmm8, [rsp+0x70]
0000710e9ebe3cbe  vmovaps xmm9, [rsp+0x80]
0000710e9ebe3cc7  vmovaps xmm10, [rsp+0x90]
0000710e9ebe3cd0  vmovaps xmm11, [rsp+0xA0]
0000710e9ebe3cd9  vmovaps xmm12, [rsp+0xB0]
0000710e9ebe3ce2  vmovaps xmm13, [rsp+0xC0]
0000710e9ebe3ceb  vmovaps xmm14, [rsp+0xD0]
0000710e9ebe3cf4  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe3cfd  add rsp, 0xF0
0000710e9ebe3d04  pop r11
0000710e9ebe3d06  pop r10
0000710e9ebe3d08  pop r9
0000710e9ebe3d0a  pop r8
0000710e9ebe3d0c  pop rsi
0000710e9ebe3d0d  pop rdi
0000710e9ebe3d0e  pop rdx
0000710e9ebe3d0f  pop rcx
0000710e9ebe3d10  pop rax
0000710e9ebe3d11  add rsp, 0x08
0000710e9ebe3d15  jmp 0x0000710E9EBDF865
0000710e9ebe3d1a  sub rsp, 0x08
0000710e9ebe3d1e  push rax
0000710e9ebe3d1f  push rcx
0000710e9ebe3d20  push rdx
0000710e9ebe3d21  push rdi
0000710e9ebe3d22  push rsi
0000710e9ebe3d23  push r8
0000710e9ebe3d25  push r9
0000710e9ebe3d27  push r10
0000710e9ebe3d29  push r11
0000710e9ebe3d2b  sub rsp, 0xF0
0000710e9ebe3d32  vmovaps [rsp], xmm0
0000710e9ebe3d37  vmovaps [rsp+0x10], xmm1
0000710e9ebe3d3d  vmovaps [rsp+0x20], xmm2
0000710e9ebe3d43  vmovaps [rsp+0x30], xmm3
0000710e9ebe3d49  vmovaps [rsp+0x40], xmm4
0000710e9ebe3d4f  vmovaps [rsp+0x50], xmm5
0000710e9ebe3d55  vmovaps [rsp+0x60], xmm6
0000710e9ebe3d5b  vmovaps [rsp+0x70], xmm7
0000710e9ebe3d61  vmovaps [rsp+0x80], xmm8
0000710e9ebe3d6a  vmovaps [rsp+0x90], xmm9
0000710e9ebe3d73  vmovaps [rsp+0xA0], xmm10
0000710e9ebe3d7c  vmovaps [rsp+0xB0], xmm12
0000710e9ebe3d85  vmovaps [rsp+0xC0], xmm13
0000710e9ebe3d8e  vmovaps [rsp+0xD0], xmm14
0000710e9ebe3d97  vmovaps [rsp+0xE0], xmm15
0000710e9ebe3da0  sub rsp, 0x30
0000710e9ebe3da4  movaps [rsp], xmm11
0000710e9ebe3da9  movaps [rsp+0x10], xmm10
0000710e9ebe3daf  movaps [rsp+0x20], xmm14
0000710e9ebe3db5  lea rdi, [rsp]
0000710e9ebe3db9  mov esi, 0x00
0000710e9ebe3dbe  mov rax, 0x5DADAF7CF530
0000710e9ebe3dc8  call rax
0000710e9ebe3dca  movaps xmm11, [rsp]
0000710e9ebe3dcf  add rsp, 0x30
0000710e9ebe3dd3  vmovaps xmm0, [rsp]
0000710e9ebe3dd8  vmovaps xmm1, [rsp+0x10]
0000710e9ebe3dde  vmovaps xmm2, [rsp+0x20]
0000710e9ebe3de4  vmovaps xmm3, [rsp+0x30]
0000710e9ebe3dea  vmovaps xmm4, [rsp+0x40]
0000710e9ebe3df0  vmovaps xmm5, [rsp+0x50]
0000710e9ebe3df6  vmovaps xmm6, [rsp+0x60]
0000710e9ebe3dfc  vmovaps xmm7, [rsp+0x70]
0000710e9ebe3e02  vmovaps xmm8, [rsp+0x80]
0000710e9ebe3e0b  vmovaps xmm9, [rsp+0x90]
0000710e9ebe3e14  vmovaps xmm10, [rsp+0xA0]
0000710e9ebe3e1d  vmovaps xmm12, [rsp+0xB0]
0000710e9ebe3e26  vmovaps xmm13, [rsp+0xC0]
0000710e9ebe3e2f  vmovaps xmm14, [rsp+0xD0]
0000710e9ebe3e38  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe3e41  add rsp, 0xF0
0000710e9ebe3e48  pop r11
0000710e9ebe3e4a  pop r10
0000710e9ebe3e4c  pop r9
0000710e9ebe3e4e  pop r8
0000710e9ebe3e50  pop rsi
0000710e9ebe3e51  pop rdi
0000710e9ebe3e52  pop rdx
0000710e9ebe3e53  pop rcx
0000710e9ebe3e54  pop rax
0000710e9ebe3e55  add rsp, 0x08
0000710e9ebe3e59  jmp 0x0000710E9EBDF880
0000710e9ebe3e5e  call 0x0000710E9EAC33A0
0000710e9ebe3e63  jmp 0x0000710E9EBDF88A
0000710e9ebe3e68  sub rsp, 0x08
0000710e9ebe3e6c  push rax
0000710e9ebe3e6d  push rcx
0000710e9ebe3e6e  push rdx
0000710e9ebe3e6f  push rdi
0000710e9ebe3e70  push rsi
0000710e9ebe3e71  push r8
0000710e9ebe3e73  push r9
0000710e9ebe3e75  push r10
0000710e9ebe3e77  push r11
0000710e9ebe3e79  sub rsp, 0xF0
0000710e9ebe3e80  vmovaps [rsp], xmm0
0000710e9ebe3e85  vmovaps [rsp+0x10], xmm1
0000710e9ebe3e8b  vmovaps [rsp+0x20], xmm2
0000710e9ebe3e91  vmovaps [rsp+0x30], xmm3
0000710e9ebe3e97  vmovaps [rsp+0x40], xmm4
0000710e9ebe3e9d  vmovaps [rsp+0x50], xmm5
0000710e9ebe3ea3  vmovaps [rsp+0x60], xmm6
0000710e9ebe3ea9  vmovaps [rsp+0x70], xmm7
0000710e9ebe3eaf  vmovaps [rsp+0x80], xmm8
0000710e9ebe3eb8  vmovaps [rsp+0x90], xmm9
0000710e9ebe3ec1  vmovaps [rsp+0xA0], xmm11
0000710e9ebe3eca  vmovaps [rsp+0xB0], xmm12
0000710e9ebe3ed3  vmovaps [rsp+0xC0], xmm13
0000710e9ebe3edc  vmovaps [rsp+0xD0], xmm14
0000710e9ebe3ee5  vmovaps [rsp+0xE0], xmm15
0000710e9ebe3eee  sub rsp, 0x30
0000710e9ebe3ef2  movaps [rsp], xmm10
0000710e9ebe3ef7  movaps [rsp+0x10], xmm1
0000710e9ebe3efc  movaps [rsp+0x20], xmm12
0000710e9ebe3f02  lea rdi, [rsp]
0000710e9ebe3f06  mov esi, 0x00
0000710e9ebe3f0b  mov rax, 0x5DADAF7CF530
0000710e9ebe3f15  call rax
0000710e9ebe3f17  movaps xmm10, [rsp]
0000710e9ebe3f1c  add rsp, 0x30
0000710e9ebe3f20  vmovaps xmm0, [rsp]
0000710e9ebe3f25  vmovaps xmm1, [rsp+0x10]
0000710e9ebe3f2b  vmovaps xmm2, [rsp+0x20]
0000710e9ebe3f31  vmovaps xmm3, [rsp+0x30]
0000710e9ebe3f37  vmovaps xmm4, [rsp+0x40]
0000710e9ebe3f3d  vmovaps xmm5, [rsp+0x50]
0000710e9ebe3f43  vmovaps xmm6, [rsp+0x60]
0000710e9ebe3f49  vmovaps xmm7, [rsp+0x70]
0000710e9ebe3f4f  vmovaps xmm8, [rsp+0x80]
0000710e9ebe3f58  vmovaps xmm9, [rsp+0x90]
0000710e9ebe3f61  vmovaps xmm11, [rsp+0xA0]
0000710e9ebe3f6a  vmovaps xmm12, [rsp+0xB0]
0000710e9ebe3f73  vmovaps xmm13, [rsp+0xC0]
0000710e9ebe3f7c  vmovaps xmm14, [rsp+0xD0]
0000710e9ebe3f85  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe3f8e  add rsp, 0xF0
0000710e9ebe3f95  pop r11
0000710e9ebe3f97  pop r10
0000710e9ebe3f99  pop r9
0000710e9ebe3f9b  pop r8
0000710e9ebe3f9d  pop rsi
0000710e9ebe3f9e  pop rdi
0000710e9ebe3f9f  pop rdx
0000710e9ebe3fa0  pop rcx
0000710e9ebe3fa1  pop rax
0000710e9ebe3fa2  add rsp, 0x08
0000710e9ebe3fa6  jmp 0x0000710E9EBDF8AD
0000710e9ebe3fab  sub rsp, 0x08
0000710e9ebe3faf  push rax
0000710e9ebe3fb0  push rcx
0000710e9ebe3fb1  push rdx
0000710e9ebe3fb2  push rdi
0000710e9ebe3fb3  push rsi
0000710e9ebe3fb4  push r8
0000710e9ebe3fb6  push r9
0000710e9ebe3fb8  push r10
0000710e9ebe3fba  push r11
0000710e9ebe3fbc  sub rsp, 0xF0
0000710e9ebe3fc3  vmovaps [rsp], xmm0
0000710e9ebe3fc8  vmovaps [rsp+0x10], xmm1
0000710e9ebe3fce  vmovaps [rsp+0x20], xmm2
0000710e9ebe3fd4  vmovaps [rsp+0x30], xmm3
0000710e9ebe3fda  vmovaps [rsp+0x40], xmm4
0000710e9ebe3fe0  vmovaps [rsp+0x50], xmm5
0000710e9ebe3fe6  vmovaps [rsp+0x60], xmm6
0000710e9ebe3fec  vmovaps [rsp+0x70], xmm7
0000710e9ebe3ff2  vmovaps [rsp+0x80], xmm8
0000710e9ebe3ffb  vmovaps [rsp+0x90], xmm9
0000710e9ebe4004  vmovaps [rsp+0xA0], xmm10
0000710e9ebe400d  vmovaps [rsp+0xB0], xmm11
0000710e9ebe4016  vmovaps [rsp+0xC0], xmm13
0000710e9ebe401f  vmovaps [rsp+0xD0], xmm14
0000710e9ebe4028  vmovaps [rsp+0xE0], xmm15
0000710e9ebe4031  sub rsp, 0x30
0000710e9ebe4035  movaps [rsp], xmm12
0000710e9ebe403a  movaps [rsp+0x10], xmm14
0000710e9ebe4040  movaps [rsp+0x20], xmm1
0000710e9ebe4045  lea rdi, [rsp]
0000710e9ebe4049  mov esi, 0x00
0000710e9ebe404e  mov rax, 0x5DADAF7CF530
0000710e9ebe4058  call rax
0000710e9ebe405a  movaps xmm12, [rsp]
0000710e9ebe405f  add rsp, 0x30
0000710e9ebe4063  vmovaps xmm0, [rsp]
0000710e9ebe4068  vmovaps xmm1, [rsp+0x10]
0000710e9ebe406e  vmovaps xmm2, [rsp+0x20]
0000710e9ebe4074  vmovaps xmm3, [rsp+0x30]
0000710e9ebe407a  vmovaps xmm4, [rsp+0x40]
0000710e9ebe4080  vmovaps xmm5, [rsp+0x50]
0000710e9ebe4086  vmovaps xmm6, [rsp+0x60]
0000710e9ebe408c  vmovaps xmm7, [rsp+0x70]
0000710e9ebe4092  vmovaps xmm8, [rsp+0x80]
0000710e9ebe409b  vmovaps xmm9, [rsp+0x90]
0000710e9ebe40a4  vmovaps xmm10, [rsp+0xA0]
0000710e9ebe40ad  vmovaps xmm11, [rsp+0xB0]
0000710e9ebe40b6  vmovaps xmm13, [rsp+0xC0]
0000710e9ebe40bf  vmovaps xmm14, [rsp+0xD0]
0000710e9ebe40c8  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe40d1  add rsp, 0xF0
0000710e9ebe40d8  pop r11
0000710e9ebe40da  pop r10
0000710e9ebe40dc  pop r9
0000710e9ebe40de  pop r8
0000710e9ebe40e0  pop rsi
0000710e9ebe40e1  pop rdi
0000710e9ebe40e2  pop rdx
0000710e9ebe40e3  pop rcx
0000710e9ebe40e4  pop rax
0000710e9ebe40e5  add rsp, 0x08
0000710e9ebe40e9  jmp 0x0000710E9EBDF8DC
0000710e9ebe40ee  sub rsp, 0x08
0000710e9ebe40f2  push rax
0000710e9ebe40f3  push rcx
0000710e9ebe40f4  push rdx
0000710e9ebe40f5  push rdi
0000710e9ebe40f6  push rsi
0000710e9ebe40f7  push r8
0000710e9ebe40f9  push r9
0000710e9ebe40fb  push r10
0000710e9ebe40fd  push r11
0000710e9ebe40ff  sub rsp, 0xF0
0000710e9ebe4106  vmovaps [rsp], xmm0
0000710e9ebe410b  vmovaps [rsp+0x10], xmm1
0000710e9ebe4111  vmovaps [rsp+0x20], xmm2
0000710e9ebe4117  vmovaps [rsp+0x30], xmm3
0000710e9ebe411d  vmovaps [rsp+0x40], xmm4
0000710e9ebe4123  vmovaps [rsp+0x50], xmm5
0000710e9ebe4129  vmovaps [rsp+0x60], xmm6
0000710e9ebe412f  vmovaps [rsp+0x70], xmm7
0000710e9ebe4135  vmovaps [rsp+0x80], xmm8
0000710e9ebe413e  vmovaps [rsp+0x90], xmm9
0000710e9ebe4147  vmovaps [rsp+0xA0], xmm10
0000710e9ebe4150  vmovaps [rsp+0xB0], xmm11
0000710e9ebe4159  vmovaps [rsp+0xC0], xmm12
0000710e9ebe4162  vmovaps [rsp+0xD0], xmm13
0000710e9ebe416b  vmovaps [rsp+0xE0], xmm15
0000710e9ebe4174  sub rsp, 0x30
0000710e9ebe4178  movaps [rsp], xmm14
0000710e9ebe417d  movaps [rsp+0x10], xmm9
0000710e9ebe4183  movaps [rsp+0x20], xmm1
0000710e9ebe4188  lea rdi, [rsp]
0000710e9ebe418c  mov esi, 0x00
0000710e9ebe4191  mov rax, 0x5DADAF7CF530
0000710e9ebe419b  call rax
0000710e9ebe419d  movaps xmm14, [rsp]
0000710e9ebe41a2  add rsp, 0x30
0000710e9ebe41a6  vmovaps xmm0, [rsp]
0000710e9ebe41ab  vmovaps xmm1, [rsp+0x10]
0000710e9ebe41b1  vmovaps xmm2, [rsp+0x20]
0000710e9ebe41b7  vmovaps xmm3, [rsp+0x30]
0000710e9ebe41bd  vmovaps xmm4, [rsp+0x40]
0000710e9ebe41c3  vmovaps xmm5, [rsp+0x50]
0000710e9ebe41c9  vmovaps xmm6, [rsp+0x60]
0000710e9ebe41cf  vmovaps xmm7, [rsp+0x70]
0000710e9ebe41d5  vmovaps xmm8, [rsp+0x80]
0000710e9ebe41de  vmovaps xmm9, [rsp+0x90]
0000710e9ebe41e7  vmovaps xmm10, [rsp+0xA0]
0000710e9ebe41f0  vmovaps xmm11, [rsp+0xB0]
0000710e9ebe41f9  vmovaps xmm12, [rsp+0xC0]
0000710e9ebe4202  vmovaps xmm13, [rsp+0xD0]
0000710e9ebe420b  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe4214  add rsp, 0xF0
0000710e9ebe421b  pop r11
0000710e9ebe421d  pop r10
0000710e9ebe421f  pop r9
0000710e9ebe4221  pop r8
0000710e9ebe4223  pop rsi
0000710e9ebe4224  pop rdi
0000710e9ebe4225  pop rdx
0000710e9ebe4226  pop rcx
0000710e9ebe4227  pop rax
0000710e9ebe4228  add rsp, 0x08
0000710e9ebe422c  jmp 0x0000710E9EBDF90B
0000710e9ebe4231  sub rsp, 0x08
0000710e9ebe4235  push rax
0000710e9ebe4236  push rcx
0000710e9ebe4237  push rdx
0000710e9ebe4238  push rdi
0000710e9ebe4239  push rsi
0000710e9ebe423a  push r8
0000710e9ebe423c  push r9
0000710e9ebe423e  push r10
0000710e9ebe4240  push r11
0000710e9ebe4242  sub rsp, 0xF0
0000710e9ebe4249  vmovaps [rsp], xmm0
0000710e9ebe424e  vmovaps [rsp+0x10], xmm2
0000710e9ebe4254  vmovaps [rsp+0x20], xmm3
0000710e9ebe425a  vmovaps [rsp+0x30], xmm4
0000710e9ebe4260  vmovaps [rsp+0x40], xmm5
0000710e9ebe4266  vmovaps [rsp+0x50], xmm6
0000710e9ebe426c  vmovaps [rsp+0x60], xmm7
0000710e9ebe4272  vmovaps [rsp+0x70], xmm8
0000710e9ebe4278  vmovaps [rsp+0x80], xmm9
0000710e9ebe4281  vmovaps [rsp+0x90], xmm10
0000710e9ebe428a  vmovaps [rsp+0xA0], xmm11
0000710e9ebe4293  vmovaps [rsp+0xB0], xmm12
0000710e9ebe429c  vmovaps [rsp+0xC0], xmm13
0000710e9ebe42a5  vmovaps [rsp+0xD0], xmm14
0000710e9ebe42ae  vmovaps [rsp+0xE0], xmm15
0000710e9ebe42b7  sub rsp, 0x30
0000710e9ebe42bb  movaps [rsp], xmm1
0000710e9ebe42bf  movaps [rsp+0x10], xmm13
0000710e9ebe42c5  movaps [rsp+0x20], xmm8
0000710e9ebe42cb  lea rdi, [rsp]
0000710e9ebe42cf  mov esi, 0x00
0000710e9ebe42d4  mov rax, 0x5DADAF7CF530
0000710e9ebe42de  call rax
0000710e9ebe42e0  movaps xmm1, [rsp]
0000710e9ebe42e4  add rsp, 0x30
0000710e9ebe42e8  vmovaps xmm0, [rsp]
0000710e9ebe42ed  vmovaps xmm2, [rsp+0x10]
0000710e9ebe42f3  vmovaps xmm3, [rsp+0x20]
0000710e9ebe42f9  vmovaps xmm4, [rsp+0x30]
0000710e9ebe42ff  vmovaps xmm5, [rsp+0x40]
0000710e9ebe4305  vmovaps xmm6, [rsp+0x50]
0000710e9ebe430b  vmovaps xmm7, [rsp+0x60]
0000710e9ebe4311  vmovaps xmm8, [rsp+0x70]
0000710e9ebe4317  vmovaps xmm9, [rsp+0x80]
0000710e9ebe4320  vmovaps xmm10, [rsp+0x90]
0000710e9ebe4329  vmovaps xmm11, [rsp+0xA0]
0000710e9ebe4332  vmovaps xmm12, [rsp+0xB0]
0000710e9ebe433b  vmovaps xmm13, [rsp+0xC0]
0000710e9ebe4344  vmovaps xmm14, [rsp+0xD0]
0000710e9ebe434d  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe4356  add rsp, 0xF0
0000710e9ebe435d  pop r11
0000710e9ebe435f  pop r10
0000710e9ebe4361  pop r9
0000710e9ebe4363  pop r8
0000710e9ebe4365  pop rsi
0000710e9ebe4366  pop rdi
0000710e9ebe4367  pop rdx
0000710e9ebe4368  pop rcx
0000710e9ebe4369  pop rax
0000710e9ebe436a  add rsp, 0x08
0000710e9ebe436e  jmp 0x0000710E9EBDF92D
0000710e9ebe4373  call 0x0000710E9EA0C260
0000710e9ebe4378  jmp 0x0000710E9EBDF93B
0000710e9ebe437d  call 0x0000710E9EABD750
0000710e9ebe4382  jmp 0x0000710E9EBDF945
0000710e9ebe4387  sub rsp, 0x08
0000710e9ebe438b  push rax
0000710e9ebe438c  push rcx
0000710e9ebe438d  push rdx
0000710e9ebe438e  push rdi
0000710e9ebe438f  push rsi
0000710e9ebe4390  push r8
0000710e9ebe4392  push r9
0000710e9ebe4394  push r10
0000710e9ebe4396  push r11
0000710e9ebe4398  sub rsp, 0xF0
0000710e9ebe439f  vmovaps [rsp], xmm0
0000710e9ebe43a4  vmovaps [rsp+0x10], xmm1
0000710e9ebe43aa  vmovaps [rsp+0x20], xmm2
0000710e9ebe43b0  vmovaps [rsp+0x30], xmm3
0000710e9ebe43b6  vmovaps [rsp+0x40], xmm4
0000710e9ebe43bc  vmovaps [rsp+0x50], xmm5
0000710e9ebe43c2  vmovaps [rsp+0x60], xmm6
0000710e9ebe43c8  vmovaps [rsp+0x70], xmm7
0000710e9ebe43ce  vmovaps [rsp+0x80], xmm9
0000710e9ebe43d7  vmovaps [rsp+0x90], xmm10
0000710e9ebe43e0  vmovaps [rsp+0xA0], xmm11
0000710e9ebe43e9  vmovaps [rsp+0xB0], xmm12
0000710e9ebe43f2  vmovaps [rsp+0xC0], xmm13
0000710e9ebe43fb  vmovaps [rsp+0xD0], xmm14
0000710e9ebe4404  vmovaps [rsp+0xE0], xmm15
0000710e9ebe440d  sub rsp, 0x30
0000710e9ebe4411  movaps [rsp], xmm8
0000710e9ebe4416  movaps [rsp+0x10], xmm15
0000710e9ebe441c  movaps [rsp+0x20], xmm7
0000710e9ebe4421  lea rdi, [rsp]
0000710e9ebe4425  mov esi, 0x00
0000710e9ebe442a  mov rax, 0x5DADAF7CF530
0000710e9ebe4434  call rax
0000710e9ebe4436  movaps xmm8, [rsp]
0000710e9ebe443b  add rsp, 0x30
0000710e9ebe443f  vmovaps xmm0, [rsp]
0000710e9ebe4444  vmovaps xmm1, [rsp+0x10]
0000710e9ebe444a  vmovaps xmm2, [rsp+0x20]
0000710e9ebe4450  vmovaps xmm3, [rsp+0x30]
0000710e9ebe4456  vmovaps xmm4, [rsp+0x40]
0000710e9ebe445c  vmovaps xmm5, [rsp+0x50]
0000710e9ebe4462  vmovaps xmm6, [rsp+0x60]
0000710e9ebe4468  vmovaps xmm7, [rsp+0x70]
0000710e9ebe446e  vmovaps xmm9, [rsp+0x80]
0000710e9ebe4477  vmovaps xmm10, [rsp+0x90]
0000710e9ebe4480  vmovaps xmm11, [rsp+0xA0]
0000710e9ebe4489  vmovaps xmm12, [rsp+0xB0]
0000710e9ebe4492  vmovaps xmm13, [rsp+0xC0]
0000710e9ebe449b  vmovaps xmm14, [rsp+0xD0]
0000710e9ebe44a4  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe44ad  add rsp, 0xF0
0000710e9ebe44b4  pop r11
0000710e9ebe44b6  pop r10
0000710e9ebe44b8  pop r9
0000710e9ebe44ba  pop r8
0000710e9ebe44bc  pop rsi
0000710e9ebe44bd  pop rdi
0000710e9ebe44be  pop rdx
0000710e9ebe44bf  pop rcx
0000710e9ebe44c0  pop rax
0000710e9ebe44c1  add rsp, 0x08
0000710e9ebe44c5  jmp 0x0000710E9EBDF967
0000710e9ebe44ca  sub rsp, 0x08
0000710e9ebe44ce  push rax
0000710e9ebe44cf  push rcx
0000710e9ebe44d0  push rdx
0000710e9ebe44d1  push rdi
0000710e9ebe44d2  push rsi
0000710e9ebe44d3  push r8
0000710e9ebe44d5  push r9
0000710e9ebe44d7  push r10
0000710e9ebe44d9  push r11
0000710e9ebe44db  sub rsp, 0xF0
0000710e9ebe44e2  vmovaps [rsp], xmm0
0000710e9ebe44e7  vmovaps [rsp+0x10], xmm1
0000710e9ebe44ed  vmovaps [rsp+0x20], xmm2
0000710e9ebe44f3  vmovaps [rsp+0x30], xmm3
0000710e9ebe44f9  vmovaps [rsp+0x40], xmm4
0000710e9ebe44ff  vmovaps [rsp+0x50], xmm5
0000710e9ebe4505  vmovaps [rsp+0x60], xmm6
0000710e9ebe450b  vmovaps [rsp+0x70], xmm8
0000710e9ebe4511  vmovaps [rsp+0x80], xmm9
0000710e9ebe451a  vmovaps [rsp+0x90], xmm10
0000710e9ebe4523  vmovaps [rsp+0xA0], xmm11
0000710e9ebe452c  vmovaps [rsp+0xB0], xmm12
0000710e9ebe4535  vmovaps [rsp+0xC0], xmm13
0000710e9ebe453e  vmovaps [rsp+0xD0], xmm14
0000710e9ebe4547  vmovaps [rsp+0xE0], xmm15
0000710e9ebe4550  sub rsp, 0x30
0000710e9ebe4554  movaps [rsp], xmm7
0000710e9ebe4558  movaps [rsp+0x10], xmm9
0000710e9ebe455e  movaps [rsp+0x20], xmm15
0000710e9ebe4564  lea rdi, [rsp]
0000710e9ebe4568  mov esi, 0x00
0000710e9ebe456d  mov rax, 0x5DADAF7CF530
0000710e9ebe4577  call rax
0000710e9ebe4579  movaps xmm7, [rsp]
0000710e9ebe457d  add rsp, 0x30
0000710e9ebe4581  vmovaps xmm0, [rsp]
0000710e9ebe4586  vmovaps xmm1, [rsp+0x10]
0000710e9ebe458c  vmovaps xmm2, [rsp+0x20]
0000710e9ebe4592  vmovaps xmm3, [rsp+0x30]
0000710e9ebe4598  vmovaps xmm4, [rsp+0x40]
0000710e9ebe459e  vmovaps xmm5, [rsp+0x50]
0000710e9ebe45a4  vmovaps xmm6, [rsp+0x60]
0000710e9ebe45aa  vmovaps xmm8, [rsp+0x70]
0000710e9ebe45b0  vmovaps xmm9, [rsp+0x80]
0000710e9ebe45b9  vmovaps xmm10, [rsp+0x90]
0000710e9ebe45c2  vmovaps xmm11, [rsp+0xA0]
0000710e9ebe45cb  vmovaps xmm12, [rsp+0xB0]
0000710e9ebe45d4  vmovaps xmm13, [rsp+0xC0]
0000710e9ebe45dd  vmovaps xmm14, [rsp+0xD0]
0000710e9ebe45e6  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe45ef  add rsp, 0xF0
0000710e9ebe45f6  pop r11
0000710e9ebe45f8  pop r10
0000710e9ebe45fa  pop r9
0000710e9ebe45fc  pop r8
0000710e9ebe45fe  pop rsi
0000710e9ebe45ff  pop rdi
0000710e9ebe4600  pop rdx
0000710e9ebe4601  pop rcx
0000710e9ebe4602  pop rax
0000710e9ebe4603  add rsp, 0x08
0000710e9ebe4607  jmp 0x0000710E9EBDF994
0000710e9ebe460c  sub rsp, 0x08
0000710e9ebe4610  push rax
0000710e9ebe4611  push rcx
0000710e9ebe4612  push rdx
0000710e9ebe4613  push rdi
0000710e9ebe4614  push rsi
0000710e9ebe4615  push r8
0000710e9ebe4617  push r9
0000710e9ebe4619  push r10
0000710e9ebe461b  push r11
0000710e9ebe461d  sub rsp, 0xF0
0000710e9ebe4624  vmovaps [rsp], xmm0
0000710e9ebe4629  vmovaps [rsp+0x10], xmm1
0000710e9ebe462f  vmovaps [rsp+0x20], xmm2
0000710e9ebe4635  vmovaps [rsp+0x30], xmm3
0000710e9ebe463b  vmovaps [rsp+0x40], xmm4
0000710e9ebe4641  vmovaps [rsp+0x50], xmm5
0000710e9ebe4647  vmovaps [rsp+0x60], xmm6
0000710e9ebe464d  vmovaps [rsp+0x70], xmm7
0000710e9ebe4653  vmovaps [rsp+0x80], xmm8
0000710e9ebe465c  vmovaps [rsp+0x90], xmm10
0000710e9ebe4665  vmovaps [rsp+0xA0], xmm11
0000710e9ebe466e  vmovaps [rsp+0xB0], xmm12
0000710e9ebe4677  vmovaps [rsp+0xC0], xmm13
0000710e9ebe4680  vmovaps [rsp+0xD0], xmm14
0000710e9ebe4689  vmovaps [rsp+0xE0], xmm15
0000710e9ebe4692  sub rsp, 0x30
0000710e9ebe4696  movaps [rsp], xmm9
0000710e9ebe469b  movaps [rsp+0x10], xmm13
0000710e9ebe46a1  movaps [rsp+0x20], xmm15
0000710e9ebe46a7  lea rdi, [rsp]
0000710e9ebe46ab  mov esi, 0x00
0000710e9ebe46b0  mov rax, 0x5DADAF7CF530
0000710e9ebe46ba  call rax
0000710e9ebe46bc  movaps xmm9, [rsp]
0000710e9ebe46c1  add rsp, 0x30
0000710e9ebe46c5  vmovaps xmm0, [rsp]
0000710e9ebe46ca  vmovaps xmm1, [rsp+0x10]
0000710e9ebe46d0  vmovaps xmm2, [rsp+0x20]
0000710e9ebe46d6  vmovaps xmm3, [rsp+0x30]
0000710e9ebe46dc  vmovaps xmm4, [rsp+0x40]
0000710e9ebe46e2  vmovaps xmm5, [rsp+0x50]
0000710e9ebe46e8  vmovaps xmm6, [rsp+0x60]
0000710e9ebe46ee  vmovaps xmm7, [rsp+0x70]
0000710e9ebe46f4  vmovaps xmm8, [rsp+0x80]
0000710e9ebe46fd  vmovaps xmm10, [rsp+0x90]
0000710e9ebe4706  vmovaps xmm11, [rsp+0xA0]
0000710e9ebe470f  vmovaps xmm12, [rsp+0xB0]
0000710e9ebe4718  vmovaps xmm13, [rsp+0xC0]
0000710e9ebe4721  vmovaps xmm14, [rsp+0xD0]
0000710e9ebe472a  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe4733  add rsp, 0xF0
0000710e9ebe473a  pop r11
0000710e9ebe473c  pop r10
0000710e9ebe473e  pop r9
0000710e9ebe4740  pop r8
0000710e9ebe4742  pop rsi
0000710e9ebe4743  pop rdi
0000710e9ebe4744  pop rdx
0000710e9ebe4745  pop rcx
0000710e9ebe4746  pop rax
0000710e9ebe4747  add rsp, 0x08
0000710e9ebe474b  jmp 0x0000710E9EBDF9C2
0000710e9ebe4750  sub rsp, 0x08
0000710e9ebe4754  push rax
0000710e9ebe4755  push rcx
0000710e9ebe4756  push rdx
0000710e9ebe4757  push rdi
0000710e9ebe4758  push rsi
0000710e9ebe4759  push r8
0000710e9ebe475b  push r9
0000710e9ebe475d  push r10
0000710e9ebe475f  push r11
0000710e9ebe4761  sub rsp, 0xF0
0000710e9ebe4768  vmovaps [rsp], xmm0
0000710e9ebe476d  vmovaps [rsp+0x10], xmm1
0000710e9ebe4773  vmovaps [rsp+0x20], xmm2
0000710e9ebe4779  vmovaps [rsp+0x30], xmm3
0000710e9ebe477f  vmovaps [rsp+0x40], xmm4
0000710e9ebe4785  vmovaps [rsp+0x50], xmm5
0000710e9ebe478b  vmovaps [rsp+0x60], xmm6
0000710e9ebe4791  vmovaps [rsp+0x70], xmm7
0000710e9ebe4797  vmovaps [rsp+0x80], xmm8
0000710e9ebe47a0  vmovaps [rsp+0x90], xmm9
0000710e9ebe47a9  vmovaps [rsp+0xA0], xmm10
0000710e9ebe47b2  vmovaps [rsp+0xB0], xmm11
0000710e9ebe47bb  vmovaps [rsp+0xC0], xmm12
0000710e9ebe47c4  vmovaps [rsp+0xD0], xmm13
0000710e9ebe47cd  vmovaps [rsp+0xE0], xmm14
0000710e9ebe47d6  sub rsp, 0x30
0000710e9ebe47da  movaps [rsp], xmm15
0000710e9ebe47df  movaps [rsp+0x10], xmm11
0000710e9ebe47e5  movaps [rsp+0x20], xmm12
0000710e9ebe47eb  lea rdi, [rsp]
0000710e9ebe47ef  mov esi, 0x00
0000710e9ebe47f4  mov rax, 0x5DADAF7CF530
0000710e9ebe47fe  call rax
0000710e9ebe4800  movaps xmm15, [rsp]
0000710e9ebe4805  add rsp, 0x30
0000710e9ebe4809  vmovaps xmm0, [rsp]
0000710e9ebe480e  vmovaps xmm1, [rsp+0x10]
0000710e9ebe4814  vmovaps xmm2, [rsp+0x20]
0000710e9ebe481a  vmovaps xmm3, [rsp+0x30]
0000710e9ebe4820  vmovaps xmm4, [rsp+0x40]
0000710e9ebe4826  vmovaps xmm5, [rsp+0x50]
0000710e9ebe482c  vmovaps xmm6, [rsp+0x60]
0000710e9ebe4832  vmovaps xmm7, [rsp+0x70]
0000710e9ebe4838  vmovaps xmm8, [rsp+0x80]
0000710e9ebe4841  vmovaps xmm9, [rsp+0x90]
0000710e9ebe484a  vmovaps xmm10, [rsp+0xA0]
0000710e9ebe4853  vmovaps xmm11, [rsp+0xB0]
0000710e9ebe485c  vmovaps xmm12, [rsp+0xC0]
0000710e9ebe4865  vmovaps xmm13, [rsp+0xD0]
0000710e9ebe486e  vmovaps xmm14, [rsp+0xE0]
0000710e9ebe4877  add rsp, 0xF0
0000710e9ebe487e  pop r11
0000710e9ebe4880  pop r10
0000710e9ebe4882  pop r9
0000710e9ebe4884  pop r8
0000710e9ebe4886  pop rsi
0000710e9ebe4887  pop rdi
0000710e9ebe4888  pop rdx
0000710e9ebe4889  pop rcx
0000710e9ebe488a  pop rax
0000710e9ebe488b  add rsp, 0x08
0000710e9ebe488f  jmp 0x0000710E9EBDF9DD
0000710e9ebe4894  sub rsp, 0x08
0000710e9ebe4898  push rax
0000710e9ebe4899  push rcx
0000710e9ebe489a  push rdx
0000710e9ebe489b  push rdi
0000710e9ebe489c  push rsi
0000710e9ebe489d  push r8
0000710e9ebe489f  push r9
0000710e9ebe48a1  push r10
0000710e9ebe48a3  push r11
0000710e9ebe48a5  sub rsp, 0xF0
0000710e9ebe48ac  vmovaps [rsp], xmm0
0000710e9ebe48b1  vmovaps [rsp+0x10], xmm1
0000710e9ebe48b7  vmovaps [rsp+0x20], xmm2
0000710e9ebe48bd  vmovaps [rsp+0x30], xmm3
0000710e9ebe48c3  vmovaps [rsp+0x40], xmm4
0000710e9ebe48c9  vmovaps [rsp+0x50], xmm5
0000710e9ebe48cf  vmovaps [rsp+0x60], xmm6
0000710e9ebe48d5  vmovaps [rsp+0x70], xmm7
0000710e9ebe48db  vmovaps [rsp+0x80], xmm8
0000710e9ebe48e4  vmovaps [rsp+0x90], xmm9
0000710e9ebe48ed  vmovaps [rsp+0xA0], xmm10
0000710e9ebe48f6  vmovaps [rsp+0xB0], xmm11
0000710e9ebe48ff  vmovaps [rsp+0xC0], xmm12
0000710e9ebe4908  vmovaps [rsp+0xD0], xmm14
0000710e9ebe4911  vmovaps [rsp+0xE0], xmm15
0000710e9ebe491a  sub rsp, 0x30
0000710e9ebe491e  movaps [rsp], xmm13
0000710e9ebe4923  movaps [rsp+0x10], xmm10
0000710e9ebe4929  movaps [rsp+0x20], xmm14
0000710e9ebe492f  lea rdi, [rsp]
0000710e9ebe4933  mov esi, 0x00
0000710e9ebe4938  mov rax, 0x5DADAF7CF530
0000710e9ebe4942  call rax
0000710e9ebe4944  movaps xmm13, [rsp]
0000710e9ebe4949  add rsp, 0x30
0000710e9ebe494d  vmovaps xmm0, [rsp]
0000710e9ebe4952  vmovaps xmm1, [rsp+0x10]
0000710e9ebe4958  vmovaps xmm2, [rsp+0x20]
0000710e9ebe495e  vmovaps xmm3, [rsp+0x30]
0000710e9ebe4964  vmovaps xmm4, [rsp+0x40]
0000710e9ebe496a  vmovaps xmm5, [rsp+0x50]
0000710e9ebe4970  vmovaps xmm6, [rsp+0x60]
0000710e9ebe4976  vmovaps xmm7, [rsp+0x70]
0000710e9ebe497c  vmovaps xmm8, [rsp+0x80]
0000710e9ebe4985  vmovaps xmm9, [rsp+0x90]
0000710e9ebe498e  vmovaps xmm10, [rsp+0xA0]
0000710e9ebe4997  vmovaps xmm11, [rsp+0xB0]
0000710e9ebe49a0  vmovaps xmm12, [rsp+0xC0]
0000710e9ebe49a9  vmovaps xmm14, [rsp+0xD0]
0000710e9ebe49b2  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe49bb  add rsp, 0xF0
0000710e9ebe49c2  pop r11
0000710e9ebe49c4  pop r10
0000710e9ebe49c6  pop r9
0000710e9ebe49c8  pop r8
0000710e9ebe49ca  pop rsi
0000710e9ebe49cb  pop rdi
0000710e9ebe49cc  pop rdx
0000710e9ebe49cd  pop rcx
0000710e9ebe49ce  pop rax
0000710e9ebe49cf  add rsp, 0x08
0000710e9ebe49d3  jmp 0x0000710E9EBDFA00
0000710e9ebe49d8  sub rsp, 0x08
0000710e9ebe49dc  push rax
0000710e9ebe49dd  push rcx
0000710e9ebe49de  push rdx
0000710e9ebe49df  push rdi
0000710e9ebe49e0  push rsi
0000710e9ebe49e1  push r8
0000710e9ebe49e3  push r9
0000710e9ebe49e5  push r10
0000710e9ebe49e7  push r11
0000710e9ebe49e9  sub rsp, 0xF0
0000710e9ebe49f0  vmovaps [rsp], xmm0
0000710e9ebe49f5  vmovaps [rsp+0x10], xmm1
0000710e9ebe49fb  vmovaps [rsp+0x20], xmm2
0000710e9ebe4a01  vmovaps [rsp+0x30], xmm3
0000710e9ebe4a07  vmovaps [rsp+0x40], xmm4
0000710e9ebe4a0d  vmovaps [rsp+0x50], xmm5
0000710e9ebe4a13  vmovaps [rsp+0x60], xmm6
0000710e9ebe4a19  vmovaps [rsp+0x70], xmm7
0000710e9ebe4a1f  vmovaps [rsp+0x80], xmm8
0000710e9ebe4a28  vmovaps [rsp+0x90], xmm9
0000710e9ebe4a31  vmovaps [rsp+0xA0], xmm10
0000710e9ebe4a3a  vmovaps [rsp+0xB0], xmm11
0000710e9ebe4a43  vmovaps [rsp+0xC0], xmm12
0000710e9ebe4a4c  vmovaps [rsp+0xD0], xmm13
0000710e9ebe4a55  vmovaps [rsp+0xE0], xmm15
0000710e9ebe4a5e  sub rsp, 0x30
0000710e9ebe4a62  movaps [rsp], xmm14
0000710e9ebe4a67  movaps [rsp+0x10], xmm1
0000710e9ebe4a6c  movaps [rsp+0x20], xmm7
0000710e9ebe4a71  lea rdi, [rsp]
0000710e9ebe4a75  mov esi, 0x00
0000710e9ebe4a7a  mov rax, 0x5DADAF7CF530
0000710e9ebe4a84  call rax
0000710e9ebe4a86  movaps xmm14, [rsp]
0000710e9ebe4a8b  add rsp, 0x30
0000710e9ebe4a8f  vmovaps xmm0, [rsp]
0000710e9ebe4a94  vmovaps xmm1, [rsp+0x10]
0000710e9ebe4a9a  vmovaps xmm2, [rsp+0x20]
0000710e9ebe4aa0  vmovaps xmm3, [rsp+0x30]
0000710e9ebe4aa6  vmovaps xmm4, [rsp+0x40]
0000710e9ebe4aac  vmovaps xmm5, [rsp+0x50]
0000710e9ebe4ab2  vmovaps xmm6, [rsp+0x60]
0000710e9ebe4ab8  vmovaps xmm7, [rsp+0x70]
0000710e9ebe4abe  vmovaps xmm8, [rsp+0x80]
0000710e9ebe4ac7  vmovaps xmm9, [rsp+0x90]
0000710e9ebe4ad0  vmovaps xmm10, [rsp+0xA0]
0000710e9ebe4ad9  vmovaps xmm11, [rsp+0xB0]
0000710e9ebe4ae2  vmovaps xmm12, [rsp+0xC0]
0000710e9ebe4aeb  vmovaps xmm13, [rsp+0xD0]
0000710e9ebe4af4  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe4afd  add rsp, 0xF0
0000710e9ebe4b04  pop r11
0000710e9ebe4b06  pop r10
0000710e9ebe4b08  pop r9
0000710e9ebe4b0a  pop r8
0000710e9ebe4b0c  pop rsi
0000710e9ebe4b0d  pop rdi
0000710e9ebe4b0e  pop rdx
0000710e9ebe4b0f  pop rcx
0000710e9ebe4b10  pop rax
0000710e9ebe4b11  add rsp, 0x08
0000710e9ebe4b15  jmp 0x0000710E9EBDFA23
0000710e9ebe4b1a  sub rsp, 0x08
0000710e9ebe4b1e  push rax
0000710e9ebe4b1f  push rcx
0000710e9ebe4b20  push rdx
0000710e9ebe4b21  push rdi
0000710e9ebe4b22  push rsi
0000710e9ebe4b23  push r8
0000710e9ebe4b25  push r9
0000710e9ebe4b27  push r10
0000710e9ebe4b29  push r11
0000710e9ebe4b2b  sub rsp, 0xF0
0000710e9ebe4b32  vmovaps [rsp], xmm0
0000710e9ebe4b37  vmovaps [rsp+0x10], xmm2
0000710e9ebe4b3d  vmovaps [rsp+0x20], xmm3
0000710e9ebe4b43  vmovaps [rsp+0x30], xmm4
0000710e9ebe4b49  vmovaps [rsp+0x40], xmm5
0000710e9ebe4b4f  vmovaps [rsp+0x50], xmm6
0000710e9ebe4b55  vmovaps [rsp+0x60], xmm7
0000710e9ebe4b5b  vmovaps [rsp+0x70], xmm8
0000710e9ebe4b61  vmovaps [rsp+0x80], xmm9
0000710e9ebe4b6a  vmovaps [rsp+0x90], xmm10
0000710e9ebe4b73  vmovaps [rsp+0xA0], xmm11
0000710e9ebe4b7c  vmovaps [rsp+0xB0], xmm12
0000710e9ebe4b85  vmovaps [rsp+0xC0], xmm13
0000710e9ebe4b8e  vmovaps [rsp+0xD0], xmm14
0000710e9ebe4b97  vmovaps [rsp+0xE0], xmm15
0000710e9ebe4ba0  sub rsp, 0x30
0000710e9ebe4ba4  movaps [rsp], xmm1
0000710e9ebe4ba8  movaps [rsp+0x10], xmm8
0000710e9ebe4bae  movaps [rsp+0x20], xmm9
0000710e9ebe4bb4  lea rdi, [rsp]
0000710e9ebe4bb8  mov esi, 0x00
0000710e9ebe4bbd  mov rax, 0x5DADAF7CF530
0000710e9ebe4bc7  call rax
0000710e9ebe4bc9  movaps xmm1, [rsp]
0000710e9ebe4bcd  add rsp, 0x30
0000710e9ebe4bd1  vmovaps xmm0, [rsp]
0000710e9ebe4bd6  vmovaps xmm2, [rsp+0x10]
0000710e9ebe4bdc  vmovaps xmm3, [rsp+0x20]
0000710e9ebe4be2  vmovaps xmm4, [rsp+0x30]
0000710e9ebe4be8  vmovaps xmm5, [rsp+0x40]
0000710e9ebe4bee  vmovaps xmm6, [rsp+0x50]
0000710e9ebe4bf4  vmovaps xmm7, [rsp+0x60]
0000710e9ebe4bfa  vmovaps xmm8, [rsp+0x70]
0000710e9ebe4c00  vmovaps xmm9, [rsp+0x80]
0000710e9ebe4c09  vmovaps xmm10, [rsp+0x90]
0000710e9ebe4c12  vmovaps xmm11, [rsp+0xA0]
0000710e9ebe4c1b  vmovaps xmm12, [rsp+0xB0]
0000710e9ebe4c24  vmovaps xmm13, [rsp+0xC0]
0000710e9ebe4c2d  vmovaps xmm14, [rsp+0xD0]
0000710e9ebe4c36  vmovaps xmm15, [rsp+0xE0]
0000710e9ebe4c3f  add rsp, 0xF0
0000710e9ebe4c46  pop r11
0000710e9ebe4c48  pop r10
0000710e9ebe4c4a  pop r9
0000710e9ebe4c4c  pop r8
0000710e9ebe4c4e  pop rsi
0000710e9ebe4c4f  pop rdi
0000710e9ebe4c50  pop rdx
0000710e9ebe4c51  pop rcx
0000710e9ebe4c52  pop rax
0000710e9ebe4c53  add rsp, 0x08
0000710e9ebe4c57  jmp 0x0000710E9EBDFA45
0000710e9ebe4c5c  call 0x0000710E9EAE5940
0000710e9ebe4c61  jmp 0x0000710E9EBDFA53
0000710e9ebe4c66  call 0x0000710E9EA0C380
0000710e9ebe4c6b  jmp 0x0000710E9EBDFA5D
0000710e9ebe4c70  call 0x0000710E9EA0D600
0000710e9ebe4c75  jmp 0x0000710E9EBDFA67
0000710e9ebe4c7a  call 0x0000710E9E9FF540
0000710e9ebe4c7f  jmp 0x0000710E9EBDFA71
0000710e9ebe4c84  int3
0000710e9ebe4c85  nop [rax+rax*1], ax
0000710e9ebe4c8e  nop
0000710e9ebe4c90  mov qword ptr [r15+0x40], 0x430000
0000710e9ebe4c98  mov eax, 0x430CC0
0000710e9ebe4c9d  mov r14, [r13+rax*1]
0000710e9ebe4ca2  movq xmm1, r14
0000710e9ebe4ca7  mov rax, [r15+0x50]
0000710e9ebe4cab  movups xmm15, [r13+rax*1]
0000710e9ebe4cb1  movaps [r15+0x120], xmm15
0000710e9ebe4cb9  mov qword ptr [r15+0x48], 0x10
0000710e9ebe4cc1  xor eax, eax
0000710e9ebe4cc3  mov r14d, 0x10
0000710e9ebe4cc9  mov r12d, 0x200
0000710e9ebe4ccf  cmp r14, r12
0000710e9ebe4cd2  cmc
0000710e9ebe4cd3  lahf
0000710e9ebe4cd4  seto al
0000710e9ebe4cd7  mov [r15+0x108], eax
0000710e9ebe4cde  pextrq rax, xmm15, 0x01
0000710e9ebe4ce5  movq xmm14, rax
0000710e9ebe4cea  movaps [r15+0x130], xmm14
0000710e9ebe4cf2  movq rax, xmm1
0000710e9ebe4cf7  movq r14, xmm15
0000710e9ebe4cfc  vmovq xmm1, rax
0000710e9ebe4d01  vmovq xmm15, r14
0000710e9ebe4d06  movaps xmm13, xmm1
0000710e9ebe4d0a  addsd xmm13, xmm15
0000710e9ebe4d0f  ucomisd xmm13, xmm13
0000710e9ebe4d14  jp 0x0000710E9EBE4DD3
0000710e9ebe4d1a  movq xmm13, xmm13
0000710e9ebe4d1f  movq rax, xmm13
0000710e9ebe4d24  movq r14, xmm14
0000710e9ebe4d29  vmovq xmm1, rax
0000710e9ebe4d2e  vmovq xmm15, r14
0000710e9ebe4d33  movaps xmm14, xmm1
0000710e9ebe4d37  addsd xmm14, xmm15
0000710e9ebe4d3c  ucomisd xmm14, xmm14
0000710e9ebe4d41  jp 0x0000710E9EBE4E1B
0000710e9ebe4d47  movq xmm14, xmm14
0000710e9ebe4d4c  movaps [r15+0x110], xmm14
0000710e9ebe4d54  mov eax, [r15+0x108]
0000710e9ebe4d5b  sahf
0000710e9ebe4d5c  jnz 0x0000710E9EBE4D8E
0000710e9ebe4d5e  cmp dword ptr [r15+0x318], 0x00
0000710e9ebe4d66  jz 0x0000710E9EBE5030
0000710e9ebe4d6c  nop [rax+rax*1], ax
0000710e9ebe4d75  nop [rax+rax*1], eax
0000710e9ebe4d7d  mov eax, 0x410704
0000710e9ebe4d82  mov [r15+0x100], rax
0000710e9ebe4d89  jmp 0x0000710E9E9FE110
0000710e9ebe4d8e  cmp dword ptr [r15+0x318], 0x00
0000710e9ebe4d96  jz 0x0000710E9EBE4E70
0000710e9ebe4d9c  nop [rax+rax*1], ax
0000710e9ebe4da5  nop [rax+rax*1], eax
0000710e9ebe4dad  mov eax, 0x4106E8
0000710e9ebe4db2  mov [r15+0x100], rax
0000710e9ebe4db9  jmp 0x0000710E9E9FE110
0000710e9ebe4dbe  int3
0000710e9ebe4dbf  call 0x0000710E9EA0DC20
0000710e9ebe4dc4  jmp 0x0000710E9EBE4CA2
0000710e9ebe4dc9  call 0x0000710E9EA0E760
0000710e9ebe4dce  jmp 0x0000710E9EBE4CB1
0000710e9ebe4dd3  ucomisd xmm1, xmm15
0000710e9ebe4dd8  jp 0x0000710E9EBE4DE7
0000710e9ebe4dda  movaps xmm13, [0x0000710E9E7FE060]
0000710e9ebe4de2  jmp 0x0000710E9EBE4D1A
0000710e9ebe4de7  vxorps xmm0, xmm1, xmm15
0000710e9ebe4dec  pextrw eax, xmm0, 0x03
0000710e9ebe4df1  and eax, 0x7FF8
0000710e9ebe4df6  cmp eax, 0x08
0000710e9ebe4df9  jnz 0x0000710E9EBE4D1A
0000710e9ebe4dff  movq rax, xmm15
0000710e9ebe4e04  shl rax, 0x0D
0000710e9ebe4e08  jbe 0x0000710E9EBE4D1A
0000710e9ebe4e0e  vorps xmm13, xmm15, [0x0000710E9E7FE070]
0000710e9ebe4e16  jmp 0x0000710E9EBE4D1A
0000710e9ebe4e1b  ucomisd xmm1, xmm15
0000710e9ebe4e20  jp 0x0000710E9EBE4E2F
0000710e9ebe4e22  movaps xmm14, [0x0000710E9E7FE060]
0000710e9ebe4e2a  jmp 0x0000710E9EBE4D47
0000710e9ebe4e2f  vxorps xmm0, xmm1, xmm15
0000710e9ebe4e34  pextrw eax, xmm0, 0x03
0000710e9ebe4e39  and eax, 0x7FF8
0000710e9ebe4e3e  cmp eax, 0x08
0000710e9ebe4e41  jnz 0x0000710E9EBE4D47
0000710e9ebe4e47  movq rax, xmm15
0000710e9ebe4e4c  shl rax, 0x0D
0000710e9ebe4e50  jbe 0x0000710E9EBE4D47
0000710e9ebe4e56  vorps xmm14, xmm15, [0x0000710E9E7FE070]
0000710e9ebe4e5e  jmp 0x0000710E9EBE4D47
0000710e9ebe4e63  int3
0000710e9ebe4e64  nop [rax+rax*1], ax
0000710e9ebe4e6d  nop [rax], eax
0000710e9ebe4e70  mov rax, [r15+0x48]
0000710e9ebe4e74  mov r14, [r15+0x50]
0000710e9ebe4e78  lea r12, [r14+rax*1]
0000710e9ebe4e7c  movups xmm1, [r13+r12*1]
0000710e9ebe4e82  movaps [r15+0x120], xmm1
0000710e9ebe4e8a  lea r14, [rax+0x10]
0000710e9ebe4e8e  mov [r15+0x48], r14
0000710e9ebe4e92  xor eax, eax
0000710e9ebe4e94  mov r12d, 0x200
0000710e9ebe4e9a  cmp r14, r12
0000710e9ebe4e9d  cmc
0000710e9ebe4e9e  lahf
0000710e9ebe4e9f  seto al
0000710e9ebe4ea2  mov [r15+0x108], eax
0000710e9ebe4ea9  pextrq rax, xmm1, 0x01
0000710e9ebe4eb0  movq xmm15, rax
0000710e9ebe4eb5  movaps [r15+0x130], xmm15
0000710e9ebe4ebd  movaps xmm14, [r15+0x110]
0000710e9ebe4ec5  movq rax, xmm14
0000710e9ebe4eca  movq r14, xmm1
0000710e9ebe4ecf  vmovq xmm1, rax
0000710e9ebe4ed4  vmovq xmm14, r14
0000710e9ebe4ed9  movaps xmm13, xmm1
0000710e9ebe4edd  addsd xmm13, xmm14
0000710e9ebe4ee2  ucomisd xmm13, xmm13
0000710e9ebe4ee7  jp 0x0000710E9EBE4F9C
0000710e9ebe4eed  movq xmm13, xmm13
0000710e9ebe4ef2  movq rax, xmm13
0000710e9ebe4ef7  movq r14, xmm15
0000710e9ebe4efc  vmovq xmm1, rax
0000710e9ebe4f01  vmovq xmm15, r14
0000710e9ebe4f06  movaps xmm14, xmm1
0000710e9ebe4f0a  addsd xmm14, xmm15
0000710e9ebe4f0f  ucomisd xmm14, xmm14
0000710e9ebe4f14  jp 0x0000710E9EBE4FE4
0000710e9ebe4f1a  movq xmm14, xmm14
0000710e9ebe4f1f  movaps [r15+0x110], xmm14
0000710e9ebe4f27  mov eax, [r15+0x108]
0000710e9ebe4f2e  sahf
0000710e9ebe4f2f  jnz 0x0000710E9EBE4F61
0000710e9ebe4f31  cmp dword ptr [r15+0x318], 0x00
0000710e9ebe4f39  jz 0x0000710E9EBE5030
0000710e9ebe4f3f  nop [rax+rax*1], ax
0000710e9ebe4f48  nop [rax+rax*1], eax
0000710e9ebe4f50  mov eax, 0x410704
0000710e9ebe4f55  mov [r15+0x100], rax
0000710e9ebe4f5c  jmp 0x0000710E9E9FE110
0000710e9ebe4f61  cmp dword ptr [r15+0x318], 0x00
0000710e9ebe4f69  jz 0x0000710E9EBE4E70
0000710e9ebe4f6f  nop [rax+rax*1], ax
0000710e9ebe4f78  nop [rax+rax*1], eax
0000710e9ebe4f80  mov eax, 0x4106E8
0000710e9ebe4f85  mov [r15+0x100], rax
0000710e9ebe4f8c  jmp 0x0000710E9E9FE110
0000710e9ebe4f91  int3
0000710e9ebe4f92  call 0x0000710E9EAB52F0
0000710e9ebe4f97  jmp 0x0000710E9EBE4E82
0000710e9ebe4f9c  ucomisd xmm1, xmm14
0000710e9ebe4fa1  jp 0x0000710E9EBE4FB0
0000710e9ebe4fa3  movaps xmm13, [0x0000710E9E7FE060]
0000710e9ebe4fab  jmp 0x0000710E9EBE4EED
0000710e9ebe4fb0  vxorps xmm0, xmm1, xmm14
0000710e9ebe4fb5  pextrw eax, xmm0, 0x03
0000710e9ebe4fba  and eax, 0x7FF8
0000710e9ebe4fbf  cmp eax, 0x08
0000710e9ebe4fc2  jnz 0x0000710E9EBE4EED
0000710e9ebe4fc8  movq rax, xmm14
0000710e9ebe4fcd  shl rax, 0x0D
0000710e9ebe4fd1  jbe 0x0000710E9EBE4EED
0000710e9ebe4fd7  vorps xmm13, xmm14, [0x0000710E9E7FE070]
0000710e9ebe4fdf  jmp 0x0000710E9EBE4EED
0000710e9ebe4fe4  ucomisd xmm1, xmm15
0000710e9ebe4fe9  jp 0x0000710E9EBE4FF8
0000710e9ebe4feb  movaps xmm14, [0x0000710E9E7FE060]
0000710e9ebe4ff3  jmp 0x0000710E9EBE4F1A
0000710e9ebe4ff8  vxorps xmm0, xmm1, xmm15
0000710e9ebe4ffd  pextrw eax, xmm0, 0x03
0000710e9ebe5002  and eax, 0x7FF8
0000710e9ebe5007  cmp eax, 0x08
0000710e9ebe500a  jnz 0x0000710E9EBE4F1A
0000710e9ebe5010  movq rax, xmm15
0000710e9ebe5015  shl rax, 0x0D
0000710e9ebe5019  jbe 0x0000710E9EBE4F1A
0000710e9ebe501f  vorps xmm14, xmm15, [0x0000710E9E7FE070]
0000710e9ebe5027  jmp 0x0000710E9EBE4F1A
0000710e9ebe502c  int3
0000710e9ebe502d  nop [rax], eax
0000710e9ebe5030  mov rax, [r15+0xF8]
0000710e9ebe5037  lea r14, [rax+0x1D0]
0000710e9ebe503e  mov r12, [r13+r14*1]
0000710e9ebe5043  lea r14, [rax+0x1D8]
0000710e9ebe504a  mov r11, [r13+r14*1]
0000710e9ebe504f  mov [r15+0xA0], r12
0000710e9ebe5056  mov [r15+0x98], r11
0000710e9ebe505d  mov r14, [r15+0x40]
0000710e9ebe5061  lea r12, [r14+0xCC0]
0000710e9ebe5068  movaps xmm1, [r15+0x110]
0000710e9ebe5070  movq r14, xmm1
0000710e9ebe5075  mov [r13+r12*1], r14
0000710e9ebe507a  lea r14, [rax+0x1C0]
0000710e9ebe5081  mov r12, [r13+r14*1]
0000710e9ebe5086  lea r14, [rax+0x1C8]
0000710e9ebe508d  mov r11, [r13+r14*1]
0000710e9ebe5092  mov [r15+0xE8], r12
0000710e9ebe5099  mov [r15+0xF0], r11
0000710e9ebe50a0  lea r14, [rax+0x1B0]
0000710e9ebe50a7  mov r12, [r13+r14*1]
0000710e9ebe50ac  lea r14, [rax+0x1B8]
0000710e9ebe50b3  mov r10, [r13+r14*1]
0000710e9ebe50b8  movq xmm1, r12
0000710e9ebe50bd  movq xmm15, r10
0000710e9ebe50c2  movq xmm1, xmm1
0000710e9ebe50c6  movq xmm1, xmm1
0000710e9ebe50ca  movaps [r15+0x1A0], xmm1
0000710e9ebe50d2  movq xmm15, xmm15
0000710e9ebe50d7  movq xmm15, xmm15
0000710e9ebe50dc  movaps [r15+0x190], xmm15
0000710e9ebe50e4  lea r14, [rax+0x1A0]
0000710e9ebe50eb  mov r12, [r13+r14*1]
0000710e9ebe50f0  lea r14, [rax+0x1A8]
0000710e9ebe50f7  mov r10, [r13+r14*1]
0000710e9ebe50fc  movq xmm1, r12
0000710e9ebe5101  movq xmm15, r10
0000710e9ebe5106  movq xmm1, xmm1
0000710e9ebe510a  movq xmm1, xmm1
0000710e9ebe510e  movaps [r15+0x1C0], xmm1
0000710e9ebe5116  movq xmm15, xmm15
0000710e9ebe511b  movq xmm15, xmm15
0000710e9ebe5120  movaps [r15+0x1B0], xmm15
0000710e9ebe5128  lea r14, [rax+0x190]
0000710e9ebe512f  mov r12, [r13+r14*1]
0000710e9ebe5134  lea r14, [rax+0x198]
0000710e9ebe513b  mov r10, [r13+r14*1]
0000710e9ebe5140  movq xmm1, r12
0000710e9ebe5145  movq xmm15, r10
0000710e9ebe514a  movq xmm1, xmm1
0000710e9ebe514e  movq xmm1, xmm1
0000710e9ebe5152  movaps [r15+0x1E0], xmm1
0000710e9ebe515a  movq xmm15, xmm15
0000710e9ebe515f  movq xmm15, xmm15
0000710e9ebe5164  movaps [r15+0x1D0], xmm15
0000710e9ebe516c  lea r14, [rax+0x180]
0000710e9ebe5173  mov r12, [r13+r14*1]
0000710e9ebe5178  lea r14, [rax+0x188]
0000710e9ebe517f  mov r10, [r13+r14*1]
0000710e9ebe5184  movq xmm1, r12
0000710e9ebe5189  movq xmm15, r10
0000710e9ebe518e  movq xmm1, xmm1
0000710e9ebe5192  movq xmm1, xmm1
0000710e9ebe5196  movaps [r15+0x200], xmm1
0000710e9ebe519e  movq xmm15, xmm15
0000710e9ebe51a3  movq xmm15, xmm15
0000710e9ebe51a8  movaps [r15+0x1F0], xmm15
0000710e9ebe51b0  lea r14, [rax+0x1E0]
0000710e9ebe51b7  mov [r15+0xF8], r14
0000710e9ebe51be  mov [r15+0x100], r11
0000710e9ebe51c5  jmp 0x0000710E9EBCE5C0
0000710e9ebe51ca  int3
0000710e9ebe51cb  call 0x0000710E9EAE27E0
0000710e9ebe51d0  jmp 0x0000710E9EBE5043
0000710e9ebe51d5  call 0x0000710E9EAE1570
0000710e9ebe51da  jmp 0x0000710E9EBE504F
0000710e9ebe51df  call 0x0000710E9EAC3FE0
0000710e9ebe51e4  jmp 0x0000710E9EBE507A
0000710e9ebe51e9  call 0x0000710E9EAE27E0
0000710e9ebe51ee  jmp 0x0000710E9EBE5086
0000710e9ebe51f3  call 0x0000710E9EAE1570
0000710e9ebe51f8  jmp 0x0000710E9EBE5092
0000710e9ebe51fd  call 0x0000710E9EAE27E0
0000710e9ebe5202  jmp 0x0000710E9EBE50AC
0000710e9ebe5207  call 0x0000710E9EAE0300
0000710e9ebe520c  jmp 0x0000710E9EBE50B8
0000710e9ebe5211  call 0x0000710E9EAE27E0
0000710e9ebe5216  jmp 0x0000710E9EBE50F0
0000710e9ebe521b  call 0x0000710E9EAE0300
0000710e9ebe5220  jmp 0x0000710E9EBE50FC
0000710e9ebe5225  call 0x0000710E9EAE27E0
0000710e9ebe522a  jmp 0x0000710E9EBE5134
0000710e9ebe522f  call 0x0000710E9EAE0300
0000710e9ebe5234  jmp 0x0000710E9EBE5140
0000710e9ebe5239  call 0x0000710E9EAE27E0
0000710e9ebe523e  jmp 0x0000710E9EBE5178
0000710e9ebe5243  call 0x0000710E9EAE0300
0000710e9ebe5248  jmp 0x0000710E9EBE5184
0000710e9ebe524d  int3
0000710e9ebe524e  nop
0000710e9ebe5250  mov qword ptr [r15+0x100], 0x04
0000710e9ebe525b  mov esi, 0x00
0000710e9ebe5260  mov edx, 0x09
0000710e9ebe5265  mov rdi, 0x7FFF51900830
0000710e9ebe526f  mov rax, 0x5DADAF662970
0000710e9ebe5279  call rax
0000710e9ebe527b  cmp dword ptr [r15+0x318], 0x00
0000710e9ebe5283  jnz 0x0000710E9E9FE110
0000710e9ebe5289  jmp 0x0000710E9E9FE0A0
0000710e9ebe528e  int3
0000710e9ebe528f  int3
