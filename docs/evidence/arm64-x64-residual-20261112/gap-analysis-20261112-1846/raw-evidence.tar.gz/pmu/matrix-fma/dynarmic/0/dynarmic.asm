00007accb5bce69b  nop [rax+rax*1], eax
00007accb5bce6a0  vmovaps xmm1, [0x00007ACCB57FE010]
00007accb5bce6a8  movq xmm1, xmm1
00007accb5bce6ac  movaps [r15+0x110], xmm1
00007accb5bce6b4  vmovaps xmm1, [0x00007ACCB57FE020]
00007accb5bce6bc  movq xmm1, xmm1
00007accb5bce6c0  movaps [r15+0x120], xmm1
00007accb5bce6c8  mov eax, 0x420470
00007accb5bce6cd  mov r14, [r13+rax*1]
00007accb5bce6d2  movq xmm1, r14
00007accb5bce6d7  movaps [r15+0x130], xmm1
00007accb5bce6df  vmovaps xmm1, [0x00007ACCB57FE030]
00007accb5bce6e7  vpbroadcastq xmm1, xmm1
00007accb5bce6ec  movaps [r15+0x140], xmm1
00007accb5bce6f4  mov qword ptr [r15+0x40], 0x02
00007accb5bce6fc  vmovaps xmm15, [0x00007ACCB57FE040]
00007accb5bce704  movq xmm15, xmm15
00007accb5bce709  movaps [r15+0x150], xmm15
00007accb5bce711  mov qword ptr [r15+0x58], 0x420000
00007accb5bce719  vmovaps xmm15, [0x00007ACCB57FE050]
00007accb5bce721  vpbroadcastq xmm15, xmm15
00007accb5bce726  movaps [r15+0x160], xmm15
00007accb5bce72e  mov rax, [r15+0x40]
00007accb5bce732  vmovq xmm14, rax
00007accb5bce737  vpbroadcastq xmm14, xmm14
00007accb5bce73c  movaps [r15+0x170], xmm14
00007accb5bce744  mov eax, 0x420480
00007accb5bce749  movups xmm13, [r13+rax*1]
00007accb5bce74f  mov qword ptr [r15+0x40], 0x4304C8
00007accb5bce757  mov qword ptr [r15+0x50], 0x4306D0
00007accb5bce75f  vpmovqd xmm12, xmm13
00007accb5bce765  pxor xmm11, xmm11
00007accb5bce76a  punpcklqdq xmm12, xmm11
00007accb5bce76f  movaps [r15+0x210], xmm12
00007accb5bce777  movq xmm12, qword ptr [r15+0x120]
00007accb5bce780  movq xmm11, qword ptr [r15+0x130]
00007accb5bce789  psubd xmm12, xmm11
00007accb5bce78e  movq xmm12, xmm12
00007accb5bce793  paddq xmm13, xmm14
00007accb5bce798  movaps [r15+0x180], xmm13
00007accb5bce7a0  movq xmm14, qword ptr [r15+0x150]
00007accb5bce7a9  paddd xmm11, xmm14
00007accb5bce7ae  movq xmm11, xmm11
00007accb5bce7b3  movq xmm11, xmm11
00007accb5bce7b8  movaps [r15+0x130], xmm11
00007accb5bce7c0  pmovzxdq xmm12, xmm12
00007accb5bce7c6  psllq xmm12, 0x00
00007accb5bce7cc  movq xmm14, qword ptr [r15+0x210]
00007accb5bce7d5  movq xmm13, qword ptr [r15+0x110]
00007accb5bce7de  paddd xmm14, xmm13
00007accb5bce7e3  movq xmm14, xmm14
00007accb5bce7e8  vcvtuqq2pd xmm12, xmm12
00007accb5bce7ee  pmovzxdq xmm14, xmm14
00007accb5bce7f4  psllq xmm14, 0x00
00007accb5bce7fa  vcvtuqq2pd xmm14, xmm14
00007accb5bce800  movaps xmm13, xmm12
00007accb5bce804  mulpd xmm13, xmm1
00007accb5bce809  vcmppd xmm11, xmm13, xmm13, 0x03
00007accb5bce80f  ptest xmm11, xmm11
00007accb5bce815  jnz 0x00007ACCB5BCE8FF
00007accb5bce81b  movaps [r15+0x220], xmm13
00007accb5bce823  mov eax, 0x4306D0
00007accb5bce828  movups [r13+rax*1], xmm13
00007accb5bce82e  movaps xmm1, xmm14
00007accb5bce832  mulpd xmm1, xmm15
00007accb5bce837  vcmppd xmm13, xmm1, xmm1, 0x03
00007accb5bce83c  ptest xmm13, xmm13
00007accb5bce842  jnz 0x00007ACCB5BCEA4C
00007accb5bce848  movaps [r15+0x210], xmm1
00007accb5bce850  mov eax, 0x4304C8
00007accb5bce855  movups [r13+rax*1], xmm1
00007accb5bce85b  mov qword ptr [r15+0x48], 0x10
00007accb5bce863  xor eax, eax
00007accb5bce865  mov r14d, 0x10
00007accb5bce86b  mov r12d, 0x200
00007accb5bce871  cmp r14, r12
00007accb5bce874  cmc
00007accb5bce875  lahf
00007accb5bce876  seto al
00007accb5bce879  mov [r15+0x108], eax
00007accb5bce880  mov eax, [r15+0x108]
00007accb5bce887  sahf
00007accb5bce888  jnz 0x00007ACCB5BCE8BA
00007accb5bce88a  cmp dword ptr [r15+0x318], 0x00
00007accb5bce892  jz 0x00007ACCB5BCEFF0
00007accb5bce898  nop [rax+rax*1], ax
00007accb5bce8a1  nop [rax+rax*1], eax
00007accb5bce8a9  mov eax, 0x4101EC
00007accb5bce8ae  mov [r15+0x100], rax
00007accb5bce8b5  jmp 0x00007ACCB59FE110
00007accb5bce8ba  cmp dword ptr [r15+0x318], 0x00
00007accb5bce8c2  jz 0x00007ACCB5BCEBA0
00007accb5bce8c8  nop [rax+rax*1], ax
00007accb5bce8d1  nop [rax+rax*1], eax
00007accb5bce8d9  mov eax, 0x4101AC
00007accb5bce8de  mov [r15+0x100], rax
00007accb5bce8e5  jmp 0x00007ACCB59FE110
00007accb5bce8ea  int3
00007accb5bce8eb  call 0x00007ACCB5A0DC20
00007accb5bce8f0  jmp 0x00007ACCB5BCE6D2
00007accb5bce8f5  call 0x00007ACCB5A0C260
00007accb5bce8fa  jmp 0x00007ACCB5BCE74F
00007accb5bce8ff  sub rsp, 0x08
00007accb5bce903  push rax
00007accb5bce904  push rcx
00007accb5bce905  push rdx
00007accb5bce906  push rdi
00007accb5bce907  push rsi
00007accb5bce908  push r8
00007accb5bce90a  push r9
00007accb5bce90c  push r10
00007accb5bce90e  push r11
00007accb5bce910  sub rsp, 0xF0
00007accb5bce917  vmovaps [rsp], xmm0
00007accb5bce91c  vmovaps [rsp+0x10], xmm1
00007accb5bce922  vmovaps [rsp+0x20], xmm2
00007accb5bce928  vmovaps [rsp+0x30], xmm3
00007accb5bce92e  vmovaps [rsp+0x40], xmm4
00007accb5bce934  vmovaps [rsp+0x50], xmm5
00007accb5bce93a  vmovaps [rsp+0x60], xmm6
00007accb5bce940  vmovaps [rsp+0x70], xmm7
00007accb5bce946  vmovaps [rsp+0x80], xmm8
00007accb5bce94f  vmovaps [rsp+0x90], xmm9
00007accb5bce958  vmovaps [rsp+0xA0], xmm10
00007accb5bce961  vmovaps [rsp+0xB0], xmm11
00007accb5bce96a  vmovaps [rsp+0xC0], xmm12
00007accb5bce973  vmovaps [rsp+0xD0], xmm14
00007accb5bce97c  vmovaps [rsp+0xE0], xmm15
00007accb5bce985  sub rsp, 0x30
00007accb5bce989  movaps [rsp], xmm13
00007accb5bce98e  movaps [rsp+0x10], xmm12
00007accb5bce994  movaps [rsp+0x20], xmm1
00007accb5bce999  lea rdi, [rsp]
00007accb5bce99d  mov esi, 0x00
00007accb5bce9a2  mov rax, 0x59156B40D530
00007accb5bce9ac  call rax
00007accb5bce9ae  movaps xmm13, [rsp]
00007accb5bce9b3  add rsp, 0x30
00007accb5bce9b7  vmovaps xmm0, [rsp]
00007accb5bce9bc  vmovaps xmm1, [rsp+0x10]
00007accb5bce9c2  vmovaps xmm2, [rsp+0x20]
00007accb5bce9c8  vmovaps xmm3, [rsp+0x30]
00007accb5bce9ce  vmovaps xmm4, [rsp+0x40]
00007accb5bce9d4  vmovaps xmm5, [rsp+0x50]
00007accb5bce9da  vmovaps xmm6, [rsp+0x60]
00007accb5bce9e0  vmovaps xmm7, [rsp+0x70]
00007accb5bce9e6  vmovaps xmm8, [rsp+0x80]
00007accb5bce9ef  vmovaps xmm9, [rsp+0x90]
00007accb5bce9f8  vmovaps xmm10, [rsp+0xA0]
00007accb5bcea01  vmovaps xmm11, [rsp+0xB0]
00007accb5bcea0a  vmovaps xmm12, [rsp+0xC0]
00007accb5bcea13  vmovaps xmm14, [rsp+0xD0]
00007accb5bcea1c  vmovaps xmm15, [rsp+0xE0]
00007accb5bcea25  add rsp, 0xF0
00007accb5bcea2c  pop r11
00007accb5bcea2e  pop r10
00007accb5bcea30  pop r9
00007accb5bcea32  pop r8
00007accb5bcea34  pop rsi
00007accb5bcea35  pop rdi
00007accb5bcea36  pop rdx
00007accb5bcea37  pop rcx
00007accb5bcea38  pop rax
00007accb5bcea39  add rsp, 0x08
00007accb5bcea3d  jmp 0x00007ACCB5BCE81B
00007accb5bcea42  call 0x00007ACCB5A0C380
00007accb5bcea47  jmp 0x00007ACCB5BCE82E
00007accb5bcea4c  sub rsp, 0x08
00007accb5bcea50  push rax
00007accb5bcea51  push rcx
00007accb5bcea52  push rdx
00007accb5bcea53  push rdi
00007accb5bcea54  push rsi
00007accb5bcea55  push r8
00007accb5bcea57  push r9
00007accb5bcea59  push r10
00007accb5bcea5b  push r11
00007accb5bcea5d  sub rsp, 0xF0
00007accb5bcea64  vmovaps [rsp], xmm0
00007accb5bcea69  vmovaps [rsp+0x10], xmm2
00007accb5bcea6f  vmovaps [rsp+0x20], xmm3
00007accb5bcea75  vmovaps [rsp+0x30], xmm4
00007accb5bcea7b  vmovaps [rsp+0x40], xmm5
00007accb5bcea81  vmovaps [rsp+0x50], xmm6
00007accb5bcea87  vmovaps [rsp+0x60], xmm7
00007accb5bcea8d  vmovaps [rsp+0x70], xmm8
00007accb5bcea93  vmovaps [rsp+0x80], xmm9
00007accb5bcea9c  vmovaps [rsp+0x90], xmm10
00007accb5bceaa5  vmovaps [rsp+0xA0], xmm11
00007accb5bceaae  vmovaps [rsp+0xB0], xmm12
00007accb5bceab7  vmovaps [rsp+0xC0], xmm13
00007accb5bceac0  vmovaps [rsp+0xD0], xmm14
00007accb5bceac9  vmovaps [rsp+0xE0], xmm15
00007accb5bcead2  sub rsp, 0x30
00007accb5bcead6  movaps [rsp], xmm1
00007accb5bceada  movaps [rsp+0x10], xmm14
00007accb5bceae0  movaps [rsp+0x20], xmm15
00007accb5bceae6  lea rdi, [rsp]
00007accb5bceaea  mov esi, 0x00
00007accb5bceaef  mov rax, 0x59156B40D530
00007accb5bceaf9  call rax
00007accb5bceafb  movaps xmm1, [rsp]
00007accb5bceaff  add rsp, 0x30
00007accb5bceb03  vmovaps xmm0, [rsp]
00007accb5bceb08  vmovaps xmm2, [rsp+0x10]
00007accb5bceb0e  vmovaps xmm3, [rsp+0x20]
00007accb5bceb14  vmovaps xmm4, [rsp+0x30]
00007accb5bceb1a  vmovaps xmm5, [rsp+0x40]
00007accb5bceb20  vmovaps xmm6, [rsp+0x50]
00007accb5bceb26  vmovaps xmm7, [rsp+0x60]
00007accb5bceb2c  vmovaps xmm8, [rsp+0x70]
00007accb5bceb32  vmovaps xmm9, [rsp+0x80]
00007accb5bceb3b  vmovaps xmm10, [rsp+0x90]
00007accb5bceb44  vmovaps xmm11, [rsp+0xA0]
00007accb5bceb4d  vmovaps xmm12, [rsp+0xB0]
00007accb5bceb56  vmovaps xmm13, [rsp+0xC0]
00007accb5bceb5f  vmovaps xmm14, [rsp+0xD0]
00007accb5bceb68  vmovaps xmm15, [rsp+0xE0]
00007accb5bceb71  add rsp, 0xF0
00007accb5bceb78  pop r11
00007accb5bceb7a  pop r10
00007accb5bceb7c  pop r9
00007accb5bceb7e  pop r8
00007accb5bceb80  pop rsi
00007accb5bceb81  pop rdi
00007accb5bceb82  pop rdx
00007accb5bceb83  pop rcx
00007accb5bceb84  pop rax
00007accb5bceb85  add rsp, 0x08
00007accb5bceb89  jmp 0x00007ACCB5BCE848
00007accb5bceb8e  call 0x00007ACCB59FF540
00007accb5bceb93  jmp 0x00007ACCB5BCE85B
00007accb5bceb98  int3
00007accb5bceb99  nop [rax], eax
00007accb5bceba0  movaps xmm1, [r15+0x180]
00007accb5bceba8  vpmovqd xmm15, xmm1
00007accb5bcebae  pxor xmm14, xmm14
00007accb5bcebb3  punpcklqdq xmm15, xmm14
00007accb5bcebb8  movaps [r15+0x210], xmm15
00007accb5bcebc0  movq xmm15, qword ptr [r15+0x120]
00007accb5bcebc9  movq xmm14, qword ptr [r15+0x130]
00007accb5bcebd2  psubd xmm15, xmm14
00007accb5bcebd7  movq xmm15, xmm15
00007accb5bcebdc  movaps xmm13, [r15+0x170]
00007accb5bcebe4  paddq xmm1, xmm13
00007accb5bcebe9  movaps [r15+0x180], xmm1
00007accb5bcebf1  movq xmm1, qword ptr [r15+0x150]
00007accb5bcebfa  paddd xmm14, xmm1
00007accb5bcebff  movq xmm14, xmm14
00007accb5bcec04  movq xmm14, xmm14
00007accb5bcec09  movaps [r15+0x130], xmm14
00007accb5bcec11  pmovzxdq xmm15, xmm15
00007accb5bcec17  psllq xmm15, 0x00
00007accb5bcec1d  movq xmm1, qword ptr [r15+0x210]
00007accb5bcec26  movq xmm14, qword ptr [r15+0x110]
00007accb5bcec2f  paddd xmm1, xmm14
00007accb5bcec34  movq xmm1, xmm1
00007accb5bcec38  vcvtuqq2pd xmm15, xmm15
00007accb5bcec3e  pmovzxdq xmm1, xmm1
00007accb5bcec43  psllq xmm1, 0x00
00007accb5bcec48  vcvtuqq2pd xmm1, xmm1
00007accb5bcec4e  movaps xmm14, [r15+0x140]
00007accb5bcec56  movaps xmm13, xmm15
00007accb5bcec5a  mulpd xmm13, xmm14
00007accb5bcec5f  vcmppd xmm12, xmm13, xmm13, 0x03
00007accb5bcec65  ptest xmm12, xmm12
00007accb5bcec6b  jnz 0x00007ACCB5BCED4E
00007accb5bcec71  movaps [r15+0x220], xmm13
00007accb5bcec79  mov rax, [r15+0x48]
00007accb5bcec7d  mov r14, [r15+0x50]
00007accb5bcec81  lea r12, [r14+rax*1]
00007accb5bcec85  movups [r13+r12*1], xmm13
00007accb5bcec8b  movaps xmm15, [r15+0x160]
00007accb5bcec93  movaps xmm14, xmm1
00007accb5bcec97  mulpd xmm14, xmm15
00007accb5bcec9c  vcmppd xmm13, xmm14, xmm14, 0x03
00007accb5bceca2  ptest xmm13, xmm13
00007accb5bceca8  jnz 0x00007ACCB5BCEE9C
00007accb5bcecae  movaps [r15+0x210], xmm14
00007accb5bcecb6  mov r14, [r15+0x40]
00007accb5bcecba  lea r12, [r14+rax*1]
00007accb5bcecbe  movups [r13+r12*1], xmm14
00007accb5bcecc4  lea r14, [rax+0x10]
00007accb5bcecc8  mov [r15+0x48], r14
00007accb5bceccc  xor eax, eax
00007accb5bcecce  mov r12d, 0x200
00007accb5bcecd4  cmp r14, r12
00007accb5bcecd7  cmc
00007accb5bcecd8  lahf
00007accb5bcecd9  seto al
00007accb5bcecdc  mov [r15+0x108], eax
00007accb5bcece3  mov eax, [r15+0x108]
00007accb5bcecea  sahf
00007accb5bceceb  jnz 0x00007ACCB5BCED1D
00007accb5bceced  cmp dword ptr [r15+0x318], 0x00
00007accb5bcecf5  jz 0x00007ACCB5BCEFF0
00007accb5bcecfb  nop [rax+rax*1], ax
00007accb5bced04  nop [rax+rax*1], eax
00007accb5bced0c  mov eax, 0x4101EC
00007accb5bced11  mov [r15+0x100], rax
00007accb5bced18  jmp 0x00007ACCB59FE110
00007accb5bced1d  cmp dword ptr [r15+0x318], 0x00
00007accb5bced25  jz 0x00007ACCB5BCEBA0
00007accb5bced2b  nop [rax+rax*1], ax
00007accb5bced34  nop [rax+rax*1], eax
00007accb5bced3c  mov eax, 0x4101AC
00007accb5bced41  mov [r15+0x100], rax
00007accb5bced48  jmp 0x00007ACCB59FE110
00007accb5bced4d  int3
00007accb5bced4e  sub rsp, 0x08
00007accb5bced52  push rax
00007accb5bced53  push rcx
00007accb5bced54  push rdx
00007accb5bced55  push rdi
00007accb5bced56  push rsi
00007accb5bced57  push r8
00007accb5bced59  push r9
00007accb5bced5b  push r10
00007accb5bced5d  push r11
00007accb5bced5f  sub rsp, 0xF0
00007accb5bced66  vmovaps [rsp], xmm0
00007accb5bced6b  vmovaps [rsp+0x10], xmm1
00007accb5bced71  vmovaps [rsp+0x20], xmm2
00007accb5bced77  vmovaps [rsp+0x30], xmm3
00007accb5bced7d  vmovaps [rsp+0x40], xmm4
00007accb5bced83  vmovaps [rsp+0x50], xmm5
00007accb5bced89  vmovaps [rsp+0x60], xmm6
00007accb5bced8f  vmovaps [rsp+0x70], xmm7
00007accb5bced95  vmovaps [rsp+0x80], xmm8
00007accb5bced9e  vmovaps [rsp+0x90], xmm9
00007accb5bceda7  vmovaps [rsp+0xA0], xmm10
00007accb5bcedb0  vmovaps [rsp+0xB0], xmm11
00007accb5bcedb9  vmovaps [rsp+0xC0], xmm12
00007accb5bcedc2  vmovaps [rsp+0xD0], xmm14
00007accb5bcedcb  vmovaps [rsp+0xE0], xmm15
00007accb5bcedd4  sub rsp, 0x30
00007accb5bcedd8  movaps [rsp], xmm13
00007accb5bceddd  movaps [rsp+0x10], xmm15
00007accb5bcede3  movaps [rsp+0x20], xmm14
00007accb5bcede9  lea rdi, [rsp]
00007accb5bceded  mov esi, 0x00
00007accb5bcedf2  mov rax, 0x59156B40D530
00007accb5bcedfc  call rax
00007accb5bcedfe  movaps xmm13, [rsp]
00007accb5bcee03  add rsp, 0x30
00007accb5bcee07  vmovaps xmm0, [rsp]
00007accb5bcee0c  vmovaps xmm1, [rsp+0x10]
00007accb5bcee12  vmovaps xmm2, [rsp+0x20]
00007accb5bcee18  vmovaps xmm3, [rsp+0x30]
00007accb5bcee1e  vmovaps xmm4, [rsp+0x40]
00007accb5bcee24  vmovaps xmm5, [rsp+0x50]
00007accb5bcee2a  vmovaps xmm6, [rsp+0x60]
00007accb5bcee30  vmovaps xmm7, [rsp+0x70]
00007accb5bcee36  vmovaps xmm8, [rsp+0x80]
00007accb5bcee3f  vmovaps xmm9, [rsp+0x90]
00007accb5bcee48  vmovaps xmm10, [rsp+0xA0]
00007accb5bcee51  vmovaps xmm11, [rsp+0xB0]
00007accb5bcee5a  vmovaps xmm12, [rsp+0xC0]
00007accb5bcee63  vmovaps xmm14, [rsp+0xD0]
00007accb5bcee6c  vmovaps xmm15, [rsp+0xE0]
00007accb5bcee75  add rsp, 0xF0
00007accb5bcee7c  pop r11
00007accb5bcee7e  pop r10
00007accb5bcee80  pop r9
00007accb5bcee82  pop r8
00007accb5bcee84  pop rsi
00007accb5bcee85  pop rdi
00007accb5bcee86  pop rdx
00007accb5bcee87  pop rcx
00007accb5bcee88  pop rax
00007accb5bcee89  add rsp, 0x08
00007accb5bcee8d  jmp 0x00007ACCB5BCEC71
00007accb5bcee92  call 0x00007ACCB5AC2240
00007accb5bcee97  jmp 0x00007ACCB5BCEC8B
00007accb5bcee9c  sub rsp, 0x08
00007accb5bceea0  push rax
00007accb5bceea1  push rcx
00007accb5bceea2  push rdx
00007accb5bceea3  push rdi
00007accb5bceea4  push rsi
00007accb5bceea5  push r8
00007accb5bceea7  push r9
00007accb5bceea9  push r10
00007accb5bceeab  push r11
00007accb5bceead  sub rsp, 0xF0
00007accb5bceeb4  vmovaps [rsp], xmm0
00007accb5bceeb9  vmovaps [rsp+0x10], xmm1
00007accb5bceebf  vmovaps [rsp+0x20], xmm2
00007accb5bceec5  vmovaps [rsp+0x30], xmm3
00007accb5bceecb  vmovaps [rsp+0x40], xmm4
00007accb5bceed1  vmovaps [rsp+0x50], xmm5
00007accb5bceed7  vmovaps [rsp+0x60], xmm6
00007accb5bceedd  vmovaps [rsp+0x70], xmm7
00007accb5bceee3  vmovaps [rsp+0x80], xmm8
00007accb5bceeec  vmovaps [rsp+0x90], xmm9
00007accb5bceef5  vmovaps [rsp+0xA0], xmm10
00007accb5bceefe  vmovaps [rsp+0xB0], xmm11
00007accb5bcef07  vmovaps [rsp+0xC0], xmm12
00007accb5bcef10  vmovaps [rsp+0xD0], xmm13
00007accb5bcef19  vmovaps [rsp+0xE0], xmm15
00007accb5bcef22  sub rsp, 0x30
00007accb5bcef26  movaps [rsp], xmm14
00007accb5bcef2b  movaps [rsp+0x10], xmm1
00007accb5bcef30  movaps [rsp+0x20], xmm15
00007accb5bcef36  lea rdi, [rsp]
00007accb5bcef3a  mov esi, 0x00
00007accb5bcef3f  mov rax, 0x59156B40D530
00007accb5bcef49  call rax
00007accb5bcef4b  movaps xmm14, [rsp]
00007accb5bcef50  add rsp, 0x30
00007accb5bcef54  vmovaps xmm0, [rsp]
00007accb5bcef59  vmovaps xmm1, [rsp+0x10]
00007accb5bcef5f  vmovaps xmm2, [rsp+0x20]
00007accb5bcef65  vmovaps xmm3, [rsp+0x30]
00007accb5bcef6b  vmovaps xmm4, [rsp+0x40]
00007accb5bcef71  vmovaps xmm5, [rsp+0x50]
00007accb5bcef77  vmovaps xmm6, [rsp+0x60]
00007accb5bcef7d  vmovaps xmm7, [rsp+0x70]
00007accb5bcef83  vmovaps xmm8, [rsp+0x80]
00007accb5bcef8c  vmovaps xmm9, [rsp+0x90]
00007accb5bcef95  vmovaps xmm10, [rsp+0xA0]
00007accb5bcef9e  vmovaps xmm11, [rsp+0xB0]
00007accb5bcefa7  vmovaps xmm12, [rsp+0xC0]
00007accb5bcefb0  vmovaps xmm13, [rsp+0xD0]
00007accb5bcefb9  vmovaps xmm15, [rsp+0xE0]
00007accb5bcefc2  add rsp, 0xF0
00007accb5bcefc9  pop r11
00007accb5bcefcb  pop r10
00007accb5bcefcd  pop r9
00007accb5bcefcf  pop r8
00007accb5bcefd1  pop rsi
00007accb5bcefd2  pop rdi
00007accb5bcefd3  pop rdx
00007accb5bcefd4  pop rcx
00007accb5bcefd5  pop rax
00007accb5bcefd6  add rsp, 0x08
00007accb5bcefda  jmp 0x00007ACCB5BCECAE
00007accb5bcefdf  call 0x00007ACCB5AC34C0
00007accb5bcefe4  jmp 0x00007ACCB5BCECC4
00007accb5bcefe9  int3
00007accb5bcefea  nop [rax+rax*1], ax
00007accb5bceff0  mov rax, [r15+0xF8]
00007accb5bceff7  lea r14, [rax-0x120]
00007accb5bceffe  mov [r15+0xF8], r14
00007accb5bcf005  mov rax, [r15+0x50]
00007accb5bcf009  movups xmm1, [r13+rax*1]
00007accb5bcf00f  lea r12, [rax+0x10]
00007accb5bcf013  movups xmm15, [r13+r12*1]
00007accb5bcf019  mov qword ptr [r15+0x48], 0x00
00007accb5bcf021  lea r12, [r14+0xD0]
00007accb5bcf028  movq xmm14, qword ptr [r15+0x200]
00007accb5bcf031  movq xmm13, qword ptr [r15+0x1F0]
00007accb5bcf03a  movq r11, xmm14
00007accb5bcf03f  movq r10, xmm13
00007accb5bcf044  mov [r13+r12*1], r11
00007accb5bcf049  lea r12, [r14+0xD8]
00007accb5bcf050  mov [r13+r12*1], r10
00007accb5bcf055  lea r12, [rax+0x80]
00007accb5bcf05c  movups xmm14, [r13+r12*1]
00007accb5bcf062  lea r12, [rax+0x90]
00007accb5bcf069  movups xmm13, [r13+r12*1]
00007accb5bcf06f  lea r12, [r14+0xE0]
00007accb5bcf076  movq xmm12, qword ptr [r15+0x1E0]
00007accb5bcf07f  movq xmm11, qword ptr [r15+0x1D0]
00007accb5bcf088  movq r11, xmm12
00007accb5bcf08d  movq r10, xmm11
00007accb5bcf092  mov [r13+r12*1], r11
00007accb5bcf097  lea r12, [r14+0xE8]
00007accb5bcf09e  mov [r13+r12*1], r10
00007accb5bcf0a3  lea r12, [rax+0xC0]
00007accb5bcf0aa  movups xmm12, [r13+r12*1]
00007accb5bcf0b0  lea r12, [rax+0xD0]
00007accb5bcf0b7  movups xmm11, [r13+r12*1]
00007accb5bcf0bd  movups [r13+r14*1], xmm1
00007accb5bcf0c3  lea r12, [rax+0x20]
00007accb5bcf0c7  movups xmm1, [r13+r12*1]
00007accb5bcf0cd  lea r12, [rax+0x30]
00007accb5bcf0d1  movups xmm10, [r13+r12*1]
00007accb5bcf0d7  lea r12, [r14+0xF0]
00007accb5bcf0de  movq xmm9, qword ptr [r15+0x1C0]
00007accb5bcf0e7  movq xmm8, qword ptr [r15+0x1B0]
00007accb5bcf0f0  movq r11, xmm9
00007accb5bcf0f5  movq r10, xmm8
00007accb5bcf0fa  mov [r13+r12*1], r11
00007accb5bcf0ff  lea r12, [r14+0xF8]
00007accb5bcf106  mov [r13+r12*1], r10
00007accb5bcf10b  lea r12, [rax+0x40]
00007accb5bcf10f  movups xmm9, [r13+r12*1]
00007accb5bcf115  lea r12, [rax+0x50]
00007accb5bcf119  movups xmm8, [r13+r12*1]
00007accb5bcf11f  lea r12, [r14+0x100]
00007accb5bcf126  movq xmm7, qword ptr [r15+0x1A0]
00007accb5bcf12f  movq xmm6, qword ptr [r15+0x190]
00007accb5bcf138  movq r11, xmm7
00007accb5bcf13d  movq r10, xmm6
00007accb5bcf142  mov [r13+r12*1], r11
00007accb5bcf147  lea r12, [r14+0x108]
00007accb5bcf14e  mov [r13+r12*1], r10
00007accb5bcf153  lea r12, [rax+0x100]
00007accb5bcf15a  movups xmm7, [r13+r12*1]
00007accb5bcf160  lea r12, [rax+0x110]
00007accb5bcf167  movups xmm6, [r13+r12*1]
00007accb5bcf16d  lea r12, [r14+0xB0]
00007accb5bcf174  movups [r13+r12*1], xmm10
00007accb5bcf17a  lea r12, [r14+0xC0]
00007accb5bcf181  movups [r13+r12*1], xmm1
00007accb5bcf187  lea r12, [rax+0x140]
00007accb5bcf18e  movups xmm1, [r13+r12*1]
00007accb5bcf194  lea r12, [rax+0x150]
00007accb5bcf19b  movups xmm10, [r13+r12*1]
00007accb5bcf1a1  lea r12, [r14+0x110]
00007accb5bcf1a8  mov r11, [r15+0xE8]
00007accb5bcf1af  mov [r13+r12*1], r11
00007accb5bcf1b4  lea r12, [rax+0x180]
00007accb5bcf1bb  movups xmm5, [r13+r12*1]
00007accb5bcf1c1  lea r12, [rax+0x190]
00007accb5bcf1c8  movups xmm4, [r13+r12*1]
00007accb5bcf1ce  lea r12, [rax+0x1C0]
00007accb5bcf1d5  movups xmm3, [r13+r12*1]
00007accb5bcf1db  lea r12, [rax+0x1D0]
00007accb5bcf1e2  movups xmm2, [r13+r12*1]
00007accb5bcf1e8  lea r12, [rax+0x60]
00007accb5bcf1ec  vmovaps [rsp+0x10], xmm1
00007accb5bcf1f2  movups xmm1, [r13+r12*1]
00007accb5bcf1f8  lea r12, [rax+0x70]
00007accb5bcf1fc  vmovaps [rsp+0x20], xmm1
00007accb5bcf202  movups xmm1, [r13+r12*1]
00007accb5bcf208  lea r12, [r14+0x70]
00007accb5bcf20c  movups [r13+r12*1], xmm4
00007accb5bcf212  lea r12, [r14+0x80]
00007accb5bcf219  movups [r13+r12*1], xmm5
00007accb5bcf21f  lea r12, [rax+0xA0]
00007accb5bcf226  movups xmm5, [r13+r12*1]
00007accb5bcf22c  lea r12, [rax+0xB0]
00007accb5bcf233  movups xmm4, [r13+r12*1]
00007accb5bcf239  lea r12, [r14+0x90]
00007accb5bcf240  movups [r13+r12*1], xmm2
00007accb5bcf246  lea r12, [r14+0xA0]
00007accb5bcf24d  movups [r13+r12*1], xmm3
00007accb5bcf253  lea r12, [rax+0xE0]
00007accb5bcf25a  movups xmm3, [r13+r12*1]
00007accb5bcf260  lea r12, [rax+0xF0]
00007accb5bcf267  movups xmm2, [r13+r12*1]
00007accb5bcf26d  lea r12, [rax+0x120]
00007accb5bcf274  vmovaps [rsp+0x30], xmm1
00007accb5bcf27a  movups xmm1, [r13+r12*1]
00007accb5bcf280  lea r12, [rax+0x130]
00007accb5bcf287  vmovaps [rsp+0x40], xmm1
00007accb5bcf28d  movups xmm1, [r13+r12*1]
00007accb5bcf293  lea r12, [rax+0x160]
00007accb5bcf29a  vmovaps [rsp+0x50], xmm1
00007accb5bcf2a0  movups xmm1, [r13+r12*1]
00007accb5bcf2a6  lea r12, [rax+0x170]
00007accb5bcf2ad  vmovaps [rsp+0x60], xmm1
00007accb5bcf2b3  movups xmm1, [r13+r12*1]
00007accb5bcf2b9  lea r12, [rax+0x1A0]
00007accb5bcf2c0  vmovaps [rsp+0x70], xmm1
00007accb5bcf2c6  movups xmm1, [r13+r12*1]
00007accb5bcf2cc  lea r12, [rax+0x1B0]
00007accb5bcf2d3  vmovaps [rsp+0x80], xmm1
00007accb5bcf2dc  movups xmm1, [r13+r12*1]
00007accb5bcf2e2  lea r12, [rax+0x1E0]
00007accb5bcf2e9  vmovaps [rsp+0x90], xmm1
00007accb5bcf2f2  movups xmm1, [r13+r12*1]
00007accb5bcf2f8  lea r12, [rax+0x1F0]
00007accb5bcf2ff  vmovaps [rsp+0xA0], xmm1
00007accb5bcf308  movups xmm1, [r13+r12*1]
00007accb5bcf30e  mov qword ptr [r15+0x50], 0x4308D0
00007accb5bcf316  lea rax, [r14+0x50]
00007accb5bcf31a  vmovaps [rsp+0xB0], xmm1
00007accb5bcf323  vmovaps xmm1, [rsp+0x60]
00007accb5bcf329  movups [r13+rax*1], xmm1
00007accb5bcf32f  lea rax, [r14+0x60]
00007accb5bcf333  vmovaps xmm1, [rsp+0x10]
00007accb5bcf339  movups [r13+rax*1], xmm1
00007accb5bcf33f  lea rax, [r14+0x40]
00007accb5bcf343  vmovaps xmm1, [rsp+0x70]
00007accb5bcf349  movups [r13+rax*1], xmm1
00007accb5bcf34f  lea rax, [r14+0x20]
00007accb5bcf353  vmovaps xmm1, [rsp+0xA0]
00007accb5bcf35c  movups [r13+rax*1], xmm1
00007accb5bcf362  lea rax, [r14+0x30]
00007accb5bcf366  vmovaps xmm1, [rsp+0x90]
00007accb5bcf36f  movups [r13+rax*1], xmm1
00007accb5bcf375  lea rax, [r14+0x10]
00007accb5bcf379  vmovaps xmm1, [rsp+0xB0]
00007accb5bcf382  movups [r13+rax*1], xmm1
00007accb5bcf388  mov rax, [r15+0x40]
00007accb5bcf38c  vxorps xmm1, xmm1, xmm1
00007accb5bcf390  vpbroadcastq xmm1, xmm1
00007accb5bcf395  vmovaps [rsp+0x10], xmm1
00007accb5bcf39b  vxorps xmm1, xmm1, xmm1
00007accb5bcf39f  vpbroadcastq xmm1, xmm1
00007accb5bcf3a4  lea r12, [rax+0x30]
00007accb5bcf3a8  mov r11, [r13+r12*1]
00007accb5bcf3ad  lea r12, [rax+0x38]
00007accb5bcf3b1  mov r10, [r13+r12*1]
00007accb5bcf3b6  vmovaps [rsp+0x60], xmm1
00007accb5bcf3bc  movq xmm1, r11
00007accb5bcf3c1  vmovaps [rsp+0x70], xmm1
00007accb5bcf3c7  movq xmm1, r10
00007accb5bcf3cc  vmovaps [rsp+0x90], xmm1
00007accb5bcf3d5  vmovaps xmm1, [rsp+0x70]
00007accb5bcf3db  movq xmm1, xmm1
00007accb5bcf3df  vmovaps [rsp+0x70], xmm1
00007accb5bcf3e5  vmovaps xmm1, [rsp+0x90]
00007accb5bcf3ee  movq xmm1, xmm1
00007accb5bcf3f2  vmovaps [rsp+0x90], xmm1
00007accb5bcf3fb  movq xmm1, xmm1
00007accb5bcf3ff  movaps [r15+0x270], xmm1
00007accb5bcf407  vmovaps [rsp+0xA0], xmm7
00007accb5bcf410  vmovaps xmm1, [rsp+0xA0]
00007accb5bcf419  por xmm7, xmm1
00007accb5bcf41d  lea r12, [rax+0x20]
00007accb5bcf421  mov r11, [r13+r12*1]
00007accb5bcf426  lea r12, [rax+0x28]
00007accb5bcf42a  mov r10, [r13+r12*1]
00007accb5bcf42f  movq xmm1, r11
00007accb5bcf434  vmovaps [rsp+0xA0], xmm1
00007accb5bcf43d  movq xmm1, r10
00007accb5bcf442  vmovaps [rsp+0xB0], xmm1
00007accb5bcf44b  vmovaps xmm1, [rsp+0xA0]
00007accb5bcf454  movq xmm1, xmm1
00007accb5bcf458  vmovaps [rsp+0xA0], xmm1
00007accb5bcf461  vmovaps xmm1, [rsp+0xB0]
00007accb5bcf46a  movq xmm1, xmm1
00007accb5bcf46e  vmovaps [rsp+0xB0], xmm2
00007accb5bcf477  vmovaps [rsp+0xC0], xmm1
00007accb5bcf480  vmovaps xmm1, [rsp+0xB0]
00007accb5bcf489  por xmm2, xmm1
00007accb5bcf48d  vmovaps xmm1, [rsp+0x40]
00007accb5bcf493  vmovaps [rsp+0xB0], xmm15
00007accb5bcf49c  vmovaps xmm15, [rsp+0x40]
00007accb5bcf4a2  por xmm1, xmm15
00007accb5bcf4a7  vmovaps [rsp+0x40], xmm3
00007accb5bcf4ad  vmovaps xmm15, [rsp+0x40]
00007accb5bcf4b3  por xmm3, xmm15
00007accb5bcf4b8  vmovaps [rsp+0x40], xmm10
00007accb5bcf4be  vmovaps xmm15, [rsp+0x40]
00007accb5bcf4c4  por xmm10, xmm15
00007accb5bcf4c9  vmovaps [rsp+0x40], xmm12
00007accb5bcf4cf  vmovaps xmm15, [rsp+0x40]
00007accb5bcf4d5  por xmm12, xmm15
00007accb5bcf4da  lea r12, [rax+0x10]
00007accb5bcf4de  mov r11, [r13+r12*1]
00007accb5bcf4e3  lea r12, [rax+0x18]
00007accb5bcf4e7  mov r10, [r13+r12*1]
00007accb5bcf4ec  movq xmm15, r11
00007accb5bcf4f1  vmovaps [rsp+0x40], xmm1
00007accb5bcf4f7  movq xmm1, r10
00007accb5bcf4fc  movq xmm15, xmm15
00007accb5bcf501  movq xmm1, xmm1
00007accb5bcf505  vmovaps [rsp+0xD0], xmm1
00007accb5bcf50e  vmovaps xmm1, [rsp+0x80]
00007accb5bcf517  vmovaps [rsp+0xE0], xmm15
00007accb5bcf520  vmovaps xmm15, [rsp+0x80]
00007accb5bcf529  por xmm1, xmm15
00007accb5bcf52e  vmovaps xmm15, [rsp+0x30]
00007accb5bcf534  vmovaps [rsp+0x80], xmm1
00007accb5bcf53d  vmovaps xmm1, [rsp+0x30]
00007accb5bcf543  por xmm15, xmm1
00007accb5bcf548  vmovaps xmm1, [rsp+0x20]
00007accb5bcf54e  vmovaps [rsp+0x30], xmm15
00007accb5bcf554  vmovaps xmm15, [rsp+0x20]
00007accb5bcf55a  por xmm1, xmm15
00007accb5bcf55f  vmovaps [rsp+0x20], xmm6
00007accb5bcf565  vmovaps xmm15, [rsp+0x20]
00007accb5bcf56b  por xmm6, xmm15
00007accb5bcf570  vmovaps [rsp+0x20], xmm13
00007accb5bcf576  vmovaps xmm15, [rsp+0x20]
00007accb5bcf57c  por xmm13, xmm15
00007accb5bcf581  vmovaps [rsp+0x20], xmm8
00007accb5bcf587  vmovaps xmm15, [rsp+0x20]
00007accb5bcf58d  por xmm8, xmm15
00007accb5bcf592  vmovaps [rsp+0x20], xmm9
00007accb5bcf598  vmovaps xmm15, [rsp+0x20]
00007accb5bcf59e  por xmm9, xmm15
00007accb5bcf5a3  mov r12, [r13+rax*1]
00007accb5bcf5a8  vmovq xmm15, r12
00007accb5bcf5ad  vpbroadcastq xmm15, xmm15
00007accb5bcf5b2  vmovaps [rsp+0x20], xmm1
00007accb5bcf5b8  vxorps xmm1, xmm1, xmm1
00007accb5bcf5bc  vpbroadcastq xmm1, xmm1
00007accb5bcf5c1  vmovaps [rsp+0xF0], xmm1
00007accb5bcf5ca  movups xmm1, [r13+r14*1]
00007accb5bcf5d0  vmovaps [rsp+0x100], xmm1
00007accb5bcf5d9  vxorps xmm1, xmm1, xmm1
00007accb5bcf5dd  vpbroadcastq xmm1, xmm1
00007accb5bcf5e2  lea r12, [rax+0x08]
00007accb5bcf5e6  mov rax, [r13+r12*1]
00007accb5bcf5eb  vmovaps [rsp+0x110], xmm1
00007accb5bcf5f4  movq xmm1, rax
00007accb5bcf5f9  movaps [r15+0x240], xmm1
00007accb5bcf601  mov qword ptr [r15+0x60], 0x4308D0
00007accb5bcf609  mov qword ptr [r15+0x58], 0x40
00007accb5bcf611  vmovaps xmm1, [rsp+0x10]
00007accb5bcf617  vmovaps [rsp+0x10], xmm15
00007accb5bcf61d  vmovaps xmm15, [rsp+0x100]
00007accb5bcf626  vmovaps [rsp+0x100], xmm14
00007accb5bcf62f  vmovaps xmm14, [rsp+0x10]
00007accb5bcf635  vmovaps [rsp+0x10], xmm13
00007accb5bcf63b  vmovaps [rsp+0x120], xmm12
00007accb5bcf644  movaps xmm13, xmm1
00007accb5bcf648  vfmadd231pd xmm13, xmm15, xmm14
00007accb5bcf64d  vcmppd xmm12, xmm13, xmm13, 0x03
00007accb5bcf653  vptest xmm12, xmm12
00007accb5bcf658  jnz 0x00007ACCB5BD0283
00007accb5bcf65e  vmovaps xmm1, [rsp+0x60]
00007accb5bcf664  vmovaps xmm15, [rsp+0xB0]
00007accb5bcf66d  vmovaps [rsp+0x60], xmm13
00007accb5bcf673  movaps xmm12, xmm1
00007accb5bcf677  vfmadd231pd xmm12, xmm15, xmm14
00007accb5bcf67c  vcmppd xmm13, xmm12, xmm12, 0x03
00007accb5bcf682  vptest xmm13, xmm13
00007accb5bcf687  jnz 0x00007ACCB5BD03DC
00007accb5bcf68d  vmovaps xmm1, [rsp+0x50]
00007accb5bcf693  vmovaps xmm13, [rsp+0x50]
00007accb5bcf699  por xmm1, xmm13
00007accb5bcf69e  vmovaps [rsp+0x50], xmm4
00007accb5bcf6a4  vmovaps xmm13, [rsp+0x50]
00007accb5bcf6aa  por xmm4, xmm13
00007accb5bcf6af  vmovaps [rsp+0x50], xmm5
00007accb5bcf6b5  vmovaps xmm13, [rsp+0x50]
00007accb5bcf6bb  por xmm5, xmm13
00007accb5bcf6c0  vmovaps [rsp+0x50], xmm11
00007accb5bcf6c6  vmovaps xmm13, [rsp+0x50]
00007accb5bcf6cc  por xmm11, xmm13
00007accb5bcf6d1  vmovaps xmm13, [rsp+0x100]
00007accb5bcf6da  vmovaps [rsp+0x50], xmm1
00007accb5bcf6e0  vmovaps xmm1, [rsp+0x100]
00007accb5bcf6e9  por xmm13, xmm1
00007accb5bcf6ee  vmovaps [rsp+0xB0], xmm15
00007accb5bcf6f7  vmovaps xmm1, [rsp+0xB0]
00007accb5bcf700  por xmm15, xmm1
00007accb5bcf705  lea rax, [r14+0xC0]
00007accb5bcf70c  movups xmm1, [r13+rax*1]
00007accb5bcf712  xor eax, eax
00007accb5bcf714  mov r12d, 0x40
00007accb5bcf71a  mov r11d, 0x200
00007accb5bcf720  cmp r12, r11
00007accb5bcf723  cmc
00007accb5bcf724  lahf
00007accb5bcf725  seto al
00007accb5bcf728  mov [r15+0x108], eax
00007accb5bcf72f  vmovaps [rsp+0xB0], xmm1
00007accb5bcf738  vmovaps xmm1, [rsp+0xF0]
00007accb5bcf741  vmovaps [rsp+0xF0], xmm15
00007accb5bcf74a  vmovaps xmm15, [rsp+0xB0]
00007accb5bcf753  vmovaps [rsp+0xB0], xmm13
00007accb5bcf75c  vmovaps [rsp+0x100], xmm12
00007accb5bcf765  movaps xmm13, xmm1
00007accb5bcf769  vfmadd231pd xmm13, xmm15, xmm14
00007accb5bcf76e  vcmppd xmm12, xmm13, xmm13, 0x03
00007accb5bcf774  vptest xmm12, xmm12
00007accb5bcf779  jnz 0x00007ACCB5BD053F
00007accb5bcf77f  lea rax, [r14+0xB0]
00007accb5bcf786  movups xmm1, [r13+rax*1]
00007accb5bcf78c  vmovaps xmm15, [rsp+0x110]
00007accb5bcf795  vmovaps [rsp+0x110], xmm13
00007accb5bcf79e  movaps xmm12, xmm15
00007accb5bcf7a2  vfmadd231pd xmm12, xmm1, xmm14
00007accb5bcf7a7  vcmppd xmm13, xmm12, xmm12, 0x03
00007accb5bcf7ad  vptest xmm13, xmm13
00007accb5bcf7b2  jnz 0x00007ACCB5BD06A2
00007accb5bcf7b8  vmovaps [rsp+0x130], xmm9
00007accb5bcf7c1  vmovaps xmm1, [rsp+0x130]
00007accb5bcf7ca  por xmm9, xmm1
00007accb5bcf7cf  movaps [r15+0x210], xmm9
00007accb5bcf7d7  vmovaps [rsp+0x130], xmm8
00007accb5bcf7e0  vmovaps xmm1, [rsp+0x130]
00007accb5bcf7e9  por xmm8, xmm1
00007accb5bcf7ee  movaps [r15+0x1C0], xmm8
00007accb5bcf7f6  vmovaps xmm1, [rsp+0x10]
00007accb5bcf7fc  vmovaps xmm15, [rsp+0x10]
00007accb5bcf802  por xmm1, xmm15
00007accb5bcf807  movaps [r15+0x280], xmm1
00007accb5bcf80f  vmovaps [rsp+0x10], xmm6
00007accb5bcf815  vmovaps xmm14, [rsp+0x10]
00007accb5bcf81b  por xmm6, xmm14
00007accb5bcf820  movaps [r15+0x2A0], xmm6
00007accb5bcf828  vmovaps xmm15, [rsp+0x20]
00007accb5bcf82e  vmovaps xmm14, [rsp+0x20]
00007accb5bcf834  por xmm15, xmm14
00007accb5bcf839  movaps [r15+0x2E0], xmm15
00007accb5bcf841  vmovaps xmm14, [rsp+0x30]
00007accb5bcf847  vmovaps xmm13, [rsp+0x30]
00007accb5bcf84d  por xmm14, xmm13
00007accb5bcf852  movaps [r15+0x1F0], xmm14
00007accb5bcf85a  vmovaps xmm13, [rsp+0xF0]
00007accb5bcf863  vmovaps [rsp+0x10], xmm1
00007accb5bcf869  vmovaps xmm1, [rsp+0xF0]
00007accb5bcf872  por xmm13, xmm1
00007accb5bcf877  movaps [r15+0x250], xmm13
00007accb5bcf87f  vmovaps xmm1, [rsp+0xB0]
00007accb5bcf888  vmovaps xmm13, [rsp+0xB0]
00007accb5bcf891  por xmm1, xmm13
00007accb5bcf896  movaps [r15+0x260], xmm1
00007accb5bcf89e  vmovaps [rsp+0x20], xmm11
00007accb5bcf8a4  vmovaps xmm13, [rsp+0x20]
00007accb5bcf8aa  por xmm11, xmm13
00007accb5bcf8af  movaps [r15+0x290], xmm11
00007accb5bcf8b7  vmovaps [rsp+0x20], xmm5
00007accb5bcf8bd  vmovaps xmm13, [rsp+0x20]
00007accb5bcf8c3  por xmm5, xmm13
00007accb5bcf8c8  movaps [r15+0x2C0], xmm5
00007accb5bcf8d0  movq xmm13, qword ptr [r15+0x240]
00007accb5bcf8d9  vmovaps [rsp+0x20], xmm13
00007accb5bcf8df  vpermilpd xmm13, xmm13, 0x00
00007accb5bcf8e5  vmovaps [rsp+0x30], xmm1
00007accb5bcf8eb  vmovaps xmm1, [rsp+0x60]
00007accb5bcf8f1  vmovaps [rsp+0x60], xmm15
00007accb5bcf8f7  vmovaps [rsp+0xB0], xmm14
00007accb5bcf900  movaps xmm15, xmm1
00007accb5bcf904  vfmadd231pd xmm15, xmm9, xmm13
00007accb5bcf909  vcmppd xmm14, xmm15, xmm15, 0x03
00007accb5bcf90f  vptest xmm14, xmm14
00007accb5bcf914  jnz 0x00007ACCB5BD07FB
00007accb5bcf91a  vmovaps xmm1, [rsp+0x20]
00007accb5bcf920  vpermilpd xmm1, xmm1, 0x00
00007accb5bcf926  vmovaps xmm14, [rsp+0x110]
00007accb5bcf92f  vmovaps xmm13, [rsp+0x60]
00007accb5bcf935  vmovaps [rsp+0x60], xmm15
00007accb5bcf93b  movaps xmm9, xmm14
00007accb5bcf93f  vfmadd231pd xmm9, xmm13, xmm1
00007accb5bcf944  vcmppd xmm15, xmm9, xmm9, 0x03
00007accb5bcf94a  vptest xmm15, xmm15
00007accb5bcf94f  jnz 0x00007ACCB5BD0954
00007accb5bcf955  vmovaps xmm1, [rsp+0x20]
00007accb5bcf95b  vpermilpd xmm1, xmm1, 0x00
00007accb5bcf961  vmovaps xmm15, [rsp+0x100]
00007accb5bcf96a  movaps xmm14, xmm15
00007accb5bcf96e  vfmadd231pd xmm14, xmm8, xmm1
00007accb5bcf973  vcmppd xmm13, xmm14, xmm14, 0x03
00007accb5bcf979  vptest xmm13, xmm13
00007accb5bcf97e  jnz 0x00007ACCB5BD0AAD
00007accb5bcf984  vmovaps [rsp+0xF0], xmm4
00007accb5bcf98d  vmovaps xmm1, [rsp+0xF0]
00007accb5bcf996  por xmm4, xmm1
00007accb5bcf99a  movaps [r15+0x1D0], xmm4
00007accb5bcf9a2  vmovaps xmm1, [rsp+0x20]
00007accb5bcf9a8  vpermilpd xmm1, xmm1, 0x00
00007accb5bcf9ae  vmovaps xmm13, [rsp+0xB0]
00007accb5bcf9b7  movaps xmm15, xmm12
00007accb5bcf9bb  vfmadd231pd xmm15, xmm13, xmm1
00007accb5bcf9c0  vcmppd xmm8, xmm15, xmm15, 0x03
00007accb5bcf9c6  vptest xmm8, xmm8
00007accb5bcf9cb  jnz 0x00007ACCB5BD0C06
00007accb5bcf9d1  vmovaps xmm1, [rsp+0x80]
00007accb5bcf9da  vmovaps xmm13, [rsp+0x80]
00007accb5bcf9e3  por xmm1, xmm13
00007accb5bcf9e8  movaps [r15+0x200], xmm1
00007accb5bcf9f0  vmovaps xmm13, [rsp+0x50]
00007accb5bcf9f6  vmovaps xmm12, [rsp+0x50]
00007accb5bcf9fc  por xmm13, xmm12
00007accb5bcfa01  movaps [r15+0x1E0], xmm13
00007accb5bcfa09  vmovaps [rsp+0x20], xmm10
00007accb5bcfa0f  vmovaps xmm13, [rsp+0x20]
00007accb5bcfa15  por xmm10, xmm13
00007accb5bcfa1a  movaps [r15+0x2B0], xmm10
00007accb5bcfa22  vmovaps [rsp+0x20], xmm3
00007accb5bcfa28  vmovaps xmm13, [rsp+0x20]
00007accb5bcfa2e  por xmm3, xmm13
00007accb5bcfa33  movaps [r15+0x300], xmm3
00007accb5bcfa3b  vmovaps xmm8, [rsp+0xE0]
00007accb5bcfa44  vpermilpd xmm8, xmm8, 0x00
00007accb5bcfa4a  vmovaps xmm3, [rsp+0x60]
00007accb5bcfa50  vmovaps [rsp+0x20], xmm1
00007accb5bcfa56  vmovaps xmm1, [rsp+0x30]
00007accb5bcfa5c  vmovaps [rsp+0x30], xmm15
00007accb5bcfa62  vmovaps [rsp+0x50], xmm14
00007accb5bcfa68  movaps xmm15, xmm3
00007accb5bcfa6c  vfmadd231pd xmm15, xmm1, xmm8
00007accb5bcfa71  vcmppd xmm14, xmm15, xmm15, 0x03
00007accb5bcfa77  vptest xmm14, xmm14
00007accb5bcfa7c  jnz 0x00007ACCB5BD0D5F
00007accb5bcfa82  vmovaps xmm1, [rsp+0xE0]
00007accb5bcfa8b  vpermilpd xmm1, xmm1, 0x00
00007accb5bcfa91  movaps xmm8, xmm9
00007accb5bcfa95  vfmadd231pd xmm8, xmm5, xmm1
00007accb5bcfa9a  vcmppd xmm14, xmm8, xmm8, 0x03
00007accb5bcfaa0  vptest xmm14, xmm14
00007accb5bcfaa5  jnz 0x00007ACCB5BD0EB7
00007accb5bcfaab  vmovaps xmm1, [rsp+0xE0]
00007accb5bcfab4  vpermilpd xmm1, xmm1, 0x00
00007accb5bcfaba  vmovaps xmm14, [rsp+0x50]
00007accb5bcfac0  vmovaps xmm9, [rsp+0x10]
00007accb5bcfac6  movaps xmm5, xmm14
00007accb5bcfaca  vfmadd231pd xmm5, xmm9, xmm1
00007accb5bcfacf  vcmppd xmm3, xmm5, xmm5, 0x03
00007accb5bcfad4  vptest xmm3, xmm3
00007accb5bcfad9  jnz 0x00007ACCB5BD100F
00007accb5bcfadf  vmovaps xmm1, [rsp+0xE0]
00007accb5bcfae8  vpermilpd xmm1, xmm1, 0x00
00007accb5bcfaee  vmovaps xmm14, [rsp+0x30]
00007accb5bcfaf4  movaps xmm9, xmm14
00007accb5bcfaf8  vfmadd231pd xmm9, xmm4, xmm1
00007accb5bcfafd  vcmppd xmm3, xmm9, xmm9, 0x03
00007accb5bcfb03  vptest xmm3, xmm3
00007accb5bcfb08  jnz 0x00007ACCB5BD1166
00007accb5bcfb0e  vmovaps xmm1, [rsp+0x120]
00007accb5bcfb17  vmovaps xmm14, [rsp+0x120]
00007accb5bcfb20  por xmm1, xmm14
00007accb5bcfb25  movaps [r15+0x180], xmm1
00007accb5bcfb2d  vmovaps xmm14, [rsp+0x40]
00007accb5bcfb33  vmovaps xmm4, [rsp+0x40]
00007accb5bcfb39  por xmm14, xmm4
00007accb5bcfb3e  movaps [r15+0x2D0], xmm14
00007accb5bcfb46  vmovaps [rsp+0x10], xmm2
00007accb5bcfb4c  vmovaps xmm4, [rsp+0x10]
00007accb5bcfb52  por xmm2, xmm4
00007accb5bcfb56  movaps [r15+0x2F0], xmm2
00007accb5bcfb5e  vmovaps xmm3, [rsp+0xD0]
00007accb5bcfb67  vpermilpd xmm3, xmm3, 0x00
00007accb5bcfb6d  vmovaps [rsp+0x10], xmm1
00007accb5bcfb73  movaps xmm2, xmm8
00007accb5bcfb77  vfmadd231pd xmm2, xmm13, xmm3
00007accb5bcfb7c  vcmppd xmm1, xmm2, xmm2, 0x03
00007accb5bcfb81  vptest xmm1, xmm1
00007accb5bcfb86  jnz 0x00007ACCB5BD12BE
00007accb5bcfb8c  vmovaps xmm1, [rsp+0xD0]
00007accb5bcfb95  vpermilpd xmm1, xmm1, 0x00
00007accb5bcfb9b  vmovaps xmm13, [rsp+0x10]
00007accb5bcfba1  movaps xmm8, xmm15
00007accb5bcfba5  vfmadd231pd xmm8, xmm13, xmm1
00007accb5bcfbaa  vcmppd xmm3, xmm8, xmm8, 0x03
00007accb5bcfbb0  vptest xmm3, xmm3
00007accb5bcfbb5  jnz 0x00007ACCB5BD1415
00007accb5bcfbbb  lea rax, [r14+0x80]
00007accb5bcfbc2  movups xmm1, [r13+rax*1]
00007accb5bcfbc8  movaps [r15+0x190], xmm1
00007accb5bcfbd0  vmovaps xmm15, [rsp+0xD0]
00007accb5bcfbd9  vpermilpd xmm15, xmm15, 0x00
00007accb5bcfbdf  movaps xmm13, xmm5
00007accb5bcfbe3  vfmadd231pd xmm13, xmm11, xmm15
00007accb5bcfbe8  vcmppd xmm3, xmm13, xmm13, 0x03
00007accb5bcfbee  vptest xmm3, xmm3
00007accb5bcfbf3  jnz 0x00007ACCB5BD1578
00007accb5bcfbf9  vmovaps xmm15, [rsp+0xD0]
00007accb5bcfc02  vpermilpd xmm15, xmm15, 0x00
00007accb5bcfc08  movaps xmm11, xmm9
00007accb5bcfc0c  vfmadd231pd xmm11, xmm4, xmm15
00007accb5bcfc11  vcmppd xmm5, xmm11, xmm11, 0x03
00007accb5bcfc17  vptest xmm5, xmm5
00007accb5bcfc1c  jnz 0x00007ACCB5BD16D1
00007accb5bcfc22  vmovaps [rsp+0x10], xmm7
00007accb5bcfc28  vmovaps xmm9, [rsp+0x10]
00007accb5bcfc2e  por xmm7, xmm9
00007accb5bcfc33  movaps [r15+0x160], xmm7
00007accb5bcfc3b  lea rax, [r14+0x40]
00007accb5bcfc3f  movups xmm15, [r13+rax*1]
00007accb5bcfc45  lea rax, [r14+0x50]
00007accb5bcfc49  movups xmm9, [r13+rax*1]
00007accb5bcfc4f  movaps [r15+0x1B0], xmm15
00007accb5bcfc57  movaps [r15+0x1A0], xmm9
00007accb5bcfc5f  vmovaps xmm5, [rsp+0xA0]
00007accb5bcfc68  vpermilpd xmm5, xmm5, 0x00
00007accb5bcfc6e  movaps xmm4, xmm2
00007accb5bcfc71  vfmadd231pd xmm4, xmm14, xmm5
00007accb5bcfc76  vcmppd xmm3, xmm4, xmm4, 0x03
00007accb5bcfc7b  vptest xmm3, xmm3
00007accb5bcfc80  jnz 0x00007ACCB5BD183E
00007accb5bcfc86  vmovaps xmm14, [rsp+0xA0]
00007accb5bcfc8f  vpermilpd xmm14, xmm14, 0x00
00007accb5bcfc95  movaps xmm5, xmm8
00007accb5bcfc99  vfmadd231pd xmm5, xmm7, xmm14
00007accb5bcfc9e  vcmppd xmm3, xmm5, xmm5, 0x03
00007accb5bcfca3  vptest xmm3, xmm3
00007accb5bcfca8  jnz 0x00007ACCB5BD1994
00007accb5bcfcae  vmovaps xmm14, [rsp+0xA0]
00007accb5bcfcb7  vpermilpd xmm14, xmm14, 0x00
00007accb5bcfcbd  movaps xmm8, xmm13
00007accb5bcfcc1  vfmadd231pd xmm8, xmm6, xmm14
00007accb5bcfcc6  vcmppd xmm7, xmm8, xmm8, 0x03
00007accb5bcfccc  vptest xmm7, xmm7
00007accb5bcfcd1  jnz 0x00007ACCB5BD1AEB
00007accb5bcfcd7  vmovaps xmm14, [rsp+0xA0]
00007accb5bcfce0  vpermilpd xmm14, xmm14, 0x00
00007accb5bcfce6  movaps xmm13, xmm11
00007accb5bcfcea  vfmadd231pd xmm13, xmm12, xmm14
00007accb5bcfcef  vcmppd xmm7, xmm13, xmm13, 0x03
00007accb5bcfcf5  vptest xmm7, xmm7
00007accb5bcfcfa  jnz 0x00007ACCB5BD1C44
00007accb5bcfd00  lea rax, [r14+0x60]
00007accb5bcfd04  movups xmm14, [r13+rax*1]
00007accb5bcfd0a  lea rax, [r14+0x70]
00007accb5bcfd0e  movups xmm12, [r13+rax*1]
00007accb5bcfd14  movaps [r15+0x150], xmm14
00007accb5bcfd1c  movaps [r15+0x120], xmm12
00007accb5bcfd24  vmovaps xmm11, [rsp+0xC0]
00007accb5bcfd2d  vpermilpd xmm11, xmm11, 0x00
00007accb5bcfd33  movaps xmm7, xmm4
00007accb5bcfd36  vfmadd231pd xmm7, xmm9, xmm11
00007accb5bcfd3b  vcmppd xmm6, xmm7, xmm7, 0x03
00007accb5bcfd40  vptest xmm6, xmm6
00007accb5bcfd45  jnz 0x00007ACCB5BD1DB2
00007accb5bcfd4b  vmovaps xmm11, [rsp+0xC0]
00007accb5bcfd54  vpermilpd xmm11, xmm11, 0x00
00007accb5bcfd5a  movaps xmm9, xmm5
00007accb5bcfd5e  vfmadd231pd xmm9, xmm14, xmm11
00007accb5bcfd63  vcmppd xmm6, xmm9, xmm9, 0x03
00007accb5bcfd69  vptest xmm6, xmm6
00007accb5bcfd6e  jnz 0x00007ACCB5BD1F09
00007accb5bcfd74  vmovaps xmm14, [rsp+0xC0]
00007accb5bcfd7d  vpermilpd xmm14, xmm14, 0x00
00007accb5bcfd83  movaps xmm11, xmm8
00007accb5bcfd87  vfmadd231pd xmm11, xmm10, xmm14
00007accb5bcfd8c  vcmppd xmm6, xmm11, xmm11, 0x03
00007accb5bcfd92  vptest xmm6, xmm6
00007accb5bcfd97  jnz 0x00007ACCB5BD2062
00007accb5bcfd9d  vmovaps xmm14, [rsp+0xC0]
00007accb5bcfda6  vpermilpd xmm14, xmm14, 0x00
00007accb5bcfdac  movaps xmm10, xmm13
00007accb5bcfdb0  vfmadd231pd xmm10, xmm15, xmm14
00007accb5bcfdb5  vcmppd xmm8, xmm10, xmm10, 0x03
00007accb5bcfdbb  vptest xmm8, xmm8
00007accb5bcfdc0  jnz 0x00007ACCB5BD21BC
00007accb5bcfdc6  lea rax, [r14+0x20]
00007accb5bcfdca  movups xmm15, [r13+rax*1]
00007accb5bcfdd0  lea rax, [r14+0x30]
00007accb5bcfdd4  movups xmm14, [r13+rax*1]
00007accb5bcfdda  vmovaps xmm13, [rsp+0x70]
00007accb5bcfde0  vpermilpd xmm13, xmm13, 0x00
00007accb5bcfde6  vmovaps xmm8, [rsp+0x20]
00007accb5bcfdec  movaps xmm6, xmm7
00007accb5bcfdef  vfmadd231pd xmm6, xmm8, xmm13
00007accb5bcfdf4  vcmppd xmm5, xmm6, xmm6, 0x03
00007accb5bcfdf9  vptest xmm5, xmm5
00007accb5bcfdfe  jnz 0x00007ACCB5BD232A
00007accb5bcfe04  vmovaps xmm13, [rsp+0x70]
00007accb5bcfe0a  vpermilpd xmm13, xmm13, 0x00
00007accb5bcfe10  movaps xmm8, xmm9
00007accb5bcfe14  vfmadd231pd xmm8, xmm1, xmm13
00007accb5bcfe19  vcmppd xmm7, xmm8, xmm8, 0x03
00007accb5bcfe1f  vptest xmm7, xmm7
00007accb5bcfe24  jnz 0x00007ACCB5BD2481
00007accb5bcfe2a  vmovaps xmm1, [rsp+0x70]
00007accb5bcfe30  vpermilpd xmm1, xmm1, 0x00
00007accb5bcfe36  movaps xmm13, xmm11
00007accb5bcfe3a  vfmadd231pd xmm13, xmm12, xmm1
00007accb5bcfe3f  vcmppd xmm9, xmm13, xmm13, 0x03
00007accb5bcfe45  vptest xmm9, xmm9
00007accb5bcfe4a  jnz 0x00007ACCB5BD25DA
00007accb5bcfe50  vmovaps xmm1, [rsp+0x70]
00007accb5bcfe56  vpermilpd xmm1, xmm1, 0x00
00007accb5bcfe5c  movaps xmm12, xmm10
00007accb5bcfe60  vfmadd231pd xmm12, xmm14, xmm1
00007accb5bcfe65  vcmppd xmm11, xmm12, xmm12, 0x03
00007accb5bcfe6b  vptest xmm11, xmm11
00007accb5bcfe70  jnz 0x00007ACCB5BD2733
00007accb5bcfe76  lea rax, [r14+0x90]
00007accb5bcfe7d  movups xmm1, [r13+rax*1]
00007accb5bcfe83  lea rax, [r14+0xA0]
00007accb5bcfe8a  movups xmm14, [r13+rax*1]
00007accb5bcfe90  movaps [r15+0x140], xmm1
00007accb5bcfe98  movaps [r15+0x130], xmm14
00007accb5bcfea0  vmovaps xmm11, [rsp+0x90]
00007accb5bcfea9  vpermilpd xmm11, xmm11, 0x00
00007accb5bcfeaf  movaps xmm10, xmm6
00007accb5bcfeb3  vfmadd231pd xmm10, xmm15, xmm11
00007accb5bcfeb8  vcmppd xmm9, xmm10, xmm10, 0x03
00007accb5bcfebe  vptest xmm9, xmm9
00007accb5bcfec3  jnz 0x00007ACCB5BD28A0
00007accb5bcfec9  movaps [r15+0x220], xmm10
00007accb5bcfed1  lea rax, [r14+0x10]
00007accb5bcfed5  movups xmm15, [r13+rax*1]
00007accb5bcfedb  movaps [r15+0x240], xmm15
00007accb5bcfee3  vmovaps xmm11, [rsp+0x90]
00007accb5bcfeec  vpermilpd xmm11, xmm11, 0x00
00007accb5bcfef2  movaps xmm9, xmm8
00007accb5bcfef6  vfmadd231pd xmm9, xmm14, xmm11
00007accb5bcfefb  vcmppd xmm7, xmm9, xmm9, 0x03
00007accb5bcff01  vptest xmm7, xmm7
00007accb5bcff06  jnz 0x00007ACCB5BD2A03
00007accb5bcff0c  movaps [r15+0x110], xmm9
00007accb5bcff14  vmovaps xmm14, [rsp+0x90]
00007accb5bcff1d  vpermilpd xmm14, xmm14, 0x00
00007accb5bcff23  movaps xmm11, xmm13
00007accb5bcff27  vfmadd231pd xmm11, xmm1, xmm14
00007accb5bcff2c  vcmppd xmm8, xmm11, xmm11, 0x03
00007accb5bcff32  vptest xmm8, xmm8
00007accb5bcff37  jnz 0x00007ACCB5BD2B5D
00007accb5bcff3d  movaps [r15+0x170], xmm11
00007accb5bcff45  vmovaps xmm1, [rsp+0x90]
00007accb5bcff4e  vpermilpd xmm1, xmm1, 0x00
00007accb5bcff54  movaps xmm14, xmm12
00007accb5bcff58  vfmadd231pd xmm14, xmm15, xmm1
00007accb5bcff5d  vcmppd xmm13, xmm14, xmm14, 0x03
00007accb5bcff63  vptest xmm13, xmm13
00007accb5bcff68  jnz 0x00007ACCB5BD2CB6
00007accb5bcff6e  movaps [r15+0x230], xmm14
00007accb5bcff76  mov eax, 0x4308D0
00007accb5bcff7b  movups [r13+rax*1], xmm9
00007accb5bcff81  mov eax, 0x4308E0
00007accb5bcff86  movups [r13+rax*1], xmm11
00007accb5bcff8c  mov eax, 0x4308F0
00007accb5bcff91  movups [r13+rax*1], xmm10
00007accb5bcff97  mov eax, 0x430900
00007accb5bcff9c  movups [r13+rax*1], xmm14
00007accb5bcffa2  mov eax, [r15+0x108]
00007accb5bcffa9  sahf
00007accb5bcffaa  jnz 0x00007ACCB5BCFFDC
00007accb5bcffac  cmp dword ptr [r15+0x318], 0x00
00007accb5bcffb4  jz 0x00007ACCB5BD67A0
00007accb5bcffba  nop [rax+rax*1], ax
00007accb5bcffc3  nop [rax+rax*1], eax
00007accb5bcffcb  mov eax, 0x4103F0
00007accb5bcffd0  mov [r15+0x100], rax
00007accb5bcffd7  jmp 0x00007ACCB59FE110
00007accb5bcffdc  cmp dword ptr [r15+0x318], 0x00
00007accb5bcffe4  jz 0x00007ACCB5BD2E40
00007accb5bcffea  nop [rax+rax*1], ax
00007accb5bcfff3  nop [rax+rax*1], eax
00007accb5bcfffb  mov eax, 0x410274
00007accb5bd0000  mov [r15+0x100], rax
00007accb5bd0007  jmp 0x00007ACCB59FE110
00007accb5bd000c  int3
00007accb5bd000d  call 0x00007ACCB59FF430
00007accb5bd0012  jmp 0x00007ACCB5BCF00F
00007accb5bd0017  call 0x00007ACCB5AC4620
00007accb5bd001c  jmp 0x00007ACCB5BCF019
00007accb5bd0021  call 0x00007ACCB5AC0860
00007accb5bd0026  jmp 0x00007ACCB5BCF049
00007accb5bd002b  call 0x00007ACCB5ABF5F0
00007accb5bd0030  jmp 0x00007ACCB5BCF055
00007accb5bd0035  call 0x00007ACCB5AC33A0
00007accb5bd003a  jmp 0x00007ACCB5BCF062
00007accb5bd003f  call 0x00007ACCB5AC2120
00007accb5bd0044  jmp 0x00007ACCB5BCF06F
00007accb5bd0049  call 0x00007ACCB5AC0860
00007accb5bd004e  jmp 0x00007ACCB5BCF097
00007accb5bd0053  call 0x00007ACCB5ABF5F0
00007accb5bd0058  jmp 0x00007ACCB5BCF0A3
00007accb5bd005d  call 0x00007ACCB5AC0EA0
00007accb5bd0062  jmp 0x00007ACCB5BCF0B0
00007accb5bd0067  call 0x00007ACCB5ABFC30
00007accb5bd006c  jmp 0x00007ACCB5BCF0BD
00007accb5bd0071  call 0x00007ACCB5AD6600
00007accb5bd0076  jmp 0x00007ACCB5BCF0C3
00007accb5bd007b  call 0x00007ACCB5AB52F0
00007accb5bd0080  jmp 0x00007ACCB5BCF0CD
00007accb5bd0085  call 0x00007ACCB5ABE9C0
00007accb5bd008a  jmp 0x00007ACCB5BCF0D7
00007accb5bd008f  call 0x00007ACCB5AC0860
00007accb5bd0094  jmp 0x00007ACCB5BCF0FF
00007accb5bd0099  call 0x00007ACCB5ABF5F0
00007accb5bd009e  jmp 0x00007ACCB5BCF10B
00007accb5bd00a3  call 0x00007ACCB5ABD750
00007accb5bd00a8  jmp 0x00007ACCB5BCF115
00007accb5bd00ad  call 0x00007ACCB5ABC4E0
00007accb5bd00b2  jmp 0x00007ACCB5BCF11F
00007accb5bd00b7  call 0x00007ACCB5AC0860
00007accb5bd00bc  jmp 0x00007ACCB5BCF147
00007accb5bd00c1  call 0x00007ACCB5ABF5F0
00007accb5bd00c6  jmp 0x00007ACCB5BCF153
00007accb5bd00cb  call 0x00007ACCB5ABB270
00007accb5bd00d0  jmp 0x00007ACCB5BCF160
00007accb5bd00d5  call 0x00007ACCB5ABA000
00007accb5bd00da  jmp 0x00007ACCB5BCF16D
00007accb5bd00df  call 0x00007ACCB5ABEAE0
00007accb5bd00e4  jmp 0x00007ACCB5BCF17A
00007accb5bd00e9  call 0x00007ACCB5AB5400
00007accb5bd00ee  jmp 0x00007ACCB5BCF187
00007accb5bd00f3  call 0x00007ACCB5AB52F0
00007accb5bd00f8  jmp 0x00007ACCB5BCF194
00007accb5bd00fd  call 0x00007ACCB5ABE9C0
00007accb5bd0102  jmp 0x00007ACCB5BCF1A1
00007accb5bd0107  call 0x00007ACCB5AC0860
00007accb5bd010c  jmp 0x00007ACCB5BCF1B4
00007accb5bd0111  call 0x00007ACCB5AB8D90
00007accb5bd0116  jmp 0x00007ACCB5BCF1C1
00007accb5bd011b  call 0x00007ACCB5AB8A20
00007accb5bd0120  jmp 0x00007ACCB5BCF1CE
00007accb5bd0125  call 0x00007ACCB5AB77B0
00007accb5bd012a  jmp 0x00007ACCB5BCF1DB
00007accb5bd012f  call 0x00007ACCB5AB6550
00007accb5bd0134  jmp 0x00007ACCB5BCF1E8
00007accb5bd0139  call 0x00007ACCB5AB52F0
00007accb5bd013e  jmp 0x00007ACCB5BCF1F8
00007accb5bd0143  call 0x00007ACCB5AB52F0
00007accb5bd0148  jmp 0x00007ACCB5BCF208
00007accb5bd014d  call 0x00007ACCB5AB8B30
00007accb5bd0152  jmp 0x00007ACCB5BCF212
00007accb5bd0157  call 0x00007ACCB5AB8EA0
00007accb5bd015c  jmp 0x00007ACCB5BCF21F
00007accb5bd0161  call 0x00007ACCB5AB8D90
00007accb5bd0166  jmp 0x00007ACCB5BCF22C
00007accb5bd016b  call 0x00007ACCB5AB8A20
00007accb5bd0170  jmp 0x00007ACCB5BCF239
00007accb5bd0175  call 0x00007ACCB5AB6660
00007accb5bd017a  jmp 0x00007ACCB5BCF246
00007accb5bd017f  call 0x00007ACCB5AB78C0
00007accb5bd0184  jmp 0x00007ACCB5BCF253
00007accb5bd0189  call 0x00007ACCB5AB77B0
00007accb5bd018e  jmp 0x00007ACCB5BCF260
00007accb5bd0193  call 0x00007ACCB5AB6550
00007accb5bd0198  jmp 0x00007ACCB5BCF26D
00007accb5bd019d  call 0x00007ACCB5AB52F0
00007accb5bd01a2  jmp 0x00007ACCB5BCF280
00007accb5bd01a7  call 0x00007ACCB5AB52F0
00007accb5bd01ac  jmp 0x00007ACCB5BCF293
00007accb5bd01b1  call 0x00007ACCB5AB52F0
00007accb5bd01b6  jmp 0x00007ACCB5BCF2A6
00007accb5bd01bb  call 0x00007ACCB5AB52F0
00007accb5bd01c0  jmp 0x00007ACCB5BCF2B9
00007accb5bd01c5  call 0x00007ACCB5AB52F0
00007accb5bd01ca  jmp 0x00007ACCB5BCF2CC
00007accb5bd01cf  call 0x00007ACCB5AB52F0
00007accb5bd01d4  jmp 0x00007ACCB5BCF2E2
00007accb5bd01d9  call 0x00007ACCB5AB52F0
00007accb5bd01de  jmp 0x00007ACCB5BCF2F8
00007accb5bd01e3  call 0x00007ACCB5AB52F0
00007accb5bd01e8  jmp 0x00007ACCB5BCF30E
00007accb5bd01ed  call 0x00007ACCB59FF540
00007accb5bd01f2  jmp 0x00007ACCB5BCF32F
00007accb5bd01f7  call 0x00007ACCB59FF540
00007accb5bd01fc  jmp 0x00007ACCB5BCF33F
00007accb5bd0201  call 0x00007ACCB59FF540
00007accb5bd0206  jmp 0x00007ACCB5BCF34F
00007accb5bd020b  call 0x00007ACCB59FF540
00007accb5bd0210  jmp 0x00007ACCB5BCF362
00007accb5bd0215  call 0x00007ACCB59FF540
00007accb5bd021a  jmp 0x00007ACCB5BCF375
00007accb5bd021f  call 0x00007ACCB59FF540
00007accb5bd0224  jmp 0x00007ACCB5BCF388
00007accb5bd0229  call 0x00007ACCB5AC0370
00007accb5bd022e  jmp 0x00007ACCB5BCF3AD
00007accb5bd0233  call 0x00007ACCB5ABF100
00007accb5bd0238  jmp 0x00007ACCB5BCF3B6
00007accb5bd023d  call 0x00007ACCB5AC0370
00007accb5bd0242  jmp 0x00007ACCB5BCF426
00007accb5bd0247  call 0x00007ACCB5ABF100
00007accb5bd024c  jmp 0x00007ACCB5BCF42F
00007accb5bd0251  call 0x00007ACCB5AC0370
00007accb5bd0256  jmp 0x00007ACCB5BCF4E3
00007accb5bd025b  call 0x00007ACCB5ABF100
00007accb5bd0260  jmp 0x00007ACCB5BCF4EC
00007accb5bd0265  call 0x00007ACCB5A0B720
00007accb5bd026a  jmp 0x00007ACCB5BCF5A8
00007accb5bd026f  call 0x00007ACCB5AD64F0
00007accb5bd0274  jmp 0x00007ACCB5BCF5D0
00007accb5bd0279  call 0x00007ACCB5AB47C0
00007accb5bd027e  jmp 0x00007ACCB5BCF5EB
00007accb5bd0283  sub rsp, 0x08
00007accb5bd0287  push rax
00007accb5bd0288  push rcx
00007accb5bd0289  push rdx
00007accb5bd028a  push rdi
00007accb5bd028b  push rsi
00007accb5bd028c  push r8
00007accb5bd028e  push r9
00007accb5bd0290  push r10
00007accb5bd0292  push r11
00007accb5bd0294  sub rsp, 0xF0
00007accb5bd029b  vmovaps [rsp], xmm0
00007accb5bd02a0  vmovaps [rsp+0x10], xmm1
00007accb5bd02a6  vmovaps [rsp+0x20], xmm2
00007accb5bd02ac  vmovaps [rsp+0x30], xmm3
00007accb5bd02b2  vmovaps [rsp+0x40], xmm4
00007accb5bd02b8  vmovaps [rsp+0x50], xmm5
00007accb5bd02be  vmovaps [rsp+0x60], xmm6
00007accb5bd02c4  vmovaps [rsp+0x70], xmm7
00007accb5bd02ca  vmovaps [rsp+0x80], xmm8
00007accb5bd02d3  vmovaps [rsp+0x90], xmm9
00007accb5bd02dc  vmovaps [rsp+0xA0], xmm10
00007accb5bd02e5  vmovaps [rsp+0xB0], xmm11
00007accb5bd02ee  vmovaps [rsp+0xC0], xmm12
00007accb5bd02f7  vmovaps [rsp+0xD0], xmm14
00007accb5bd0300  vmovaps [rsp+0xE0], xmm15
00007accb5bd0309  sub rsp, 0x40
00007accb5bd030d  lea rdi, [rsp]
00007accb5bd0311  lea rsi, [rsp+0x10]
00007accb5bd0316  lea rdx, [rsp+0x20]
00007accb5bd031b  lea rcx, [rsp+0x30]
00007accb5bd0320  mov r8d, 0x00
00007accb5bd0326  lea r9, [r15+0x3A8]
00007accb5bd032d  movaps [rdi], xmm13
00007accb5bd0331  movaps [rsi], xmm1
00007accb5bd0334  movaps [rdx], xmm15
00007accb5bd0338  movaps [rcx], xmm14
00007accb5bd033c  mov rax, 0x59156B40DA50
00007accb5bd0346  call rax
00007accb5bd0348  movaps xmm13, [rsp]
00007accb5bd034d  add rsp, 0x40
00007accb5bd0351  vmovaps xmm0, [rsp]
00007accb5bd0356  vmovaps xmm1, [rsp+0x10]
00007accb5bd035c  vmovaps xmm2, [rsp+0x20]
00007accb5bd0362  vmovaps xmm3, [rsp+0x30]
00007accb5bd0368  vmovaps xmm4, [rsp+0x40]
00007accb5bd036e  vmovaps xmm5, [rsp+0x50]
00007accb5bd0374  vmovaps xmm6, [rsp+0x60]
00007accb5bd037a  vmovaps xmm7, [rsp+0x70]
00007accb5bd0380  vmovaps xmm8, [rsp+0x80]
00007accb5bd0389  vmovaps xmm9, [rsp+0x90]
00007accb5bd0392  vmovaps xmm10, [rsp+0xA0]
00007accb5bd039b  vmovaps xmm11, [rsp+0xB0]
00007accb5bd03a4  vmovaps xmm12, [rsp+0xC0]
00007accb5bd03ad  vmovaps xmm14, [rsp+0xD0]
00007accb5bd03b6  vmovaps xmm15, [rsp+0xE0]
00007accb5bd03bf  add rsp, 0xF0
00007accb5bd03c6  pop r11
00007accb5bd03c8  pop r10
00007accb5bd03ca  pop r9
00007accb5bd03cc  pop r8
00007accb5bd03ce  pop rsi
00007accb5bd03cf  pop rdi
00007accb5bd03d0  pop rdx
00007accb5bd03d1  pop rcx
00007accb5bd03d2  pop rax
00007accb5bd03d3  add rsp, 0x08
00007accb5bd03d7  jmp 0x00007ACCB5BCF65E
00007accb5bd03dc  sub rsp, 0x08
00007accb5bd03e0  push rax
00007accb5bd03e1  push rcx
00007accb5bd03e2  push rdx
00007accb5bd03e3  push rdi
00007accb5bd03e4  push rsi
00007accb5bd03e5  push r8
00007accb5bd03e7  push r9
00007accb5bd03e9  push r10
00007accb5bd03eb  push r11
00007accb5bd03ed  sub rsp, 0xF0
00007accb5bd03f4  vmovaps [rsp], xmm0
00007accb5bd03f9  vmovaps [rsp+0x10], xmm1
00007accb5bd03ff  vmovaps [rsp+0x20], xmm2
00007accb5bd0405  vmovaps [rsp+0x30], xmm3
00007accb5bd040b  vmovaps [rsp+0x40], xmm4
00007accb5bd0411  vmovaps [rsp+0x50], xmm5
00007accb5bd0417  vmovaps [rsp+0x60], xmm6
00007accb5bd041d  vmovaps [rsp+0x70], xmm7
00007accb5bd0423  vmovaps [rsp+0x80], xmm8
00007accb5bd042c  vmovaps [rsp+0x90], xmm9
00007accb5bd0435  vmovaps [rsp+0xA0], xmm10
00007accb5bd043e  vmovaps [rsp+0xB0], xmm11
00007accb5bd0447  vmovaps [rsp+0xC0], xmm13
00007accb5bd0450  vmovaps [rsp+0xD0], xmm14
00007accb5bd0459  vmovaps [rsp+0xE0], xmm15
00007accb5bd0462  sub rsp, 0x40
00007accb5bd0466  lea rdi, [rsp]
00007accb5bd046a  lea rsi, [rsp+0x10]
00007accb5bd046f  lea rdx, [rsp+0x20]
00007accb5bd0474  lea rcx, [rsp+0x30]
00007accb5bd0479  mov r8d, 0x00
00007accb5bd047f  lea r9, [r15+0x3A8]
00007accb5bd0486  movaps [rdi], xmm12
00007accb5bd048a  movaps [rsi], xmm1
00007accb5bd048d  movaps [rdx], xmm15
00007accb5bd0491  movaps [rcx], xmm14
00007accb5bd0495  mov rax, 0x59156B40DA50
00007accb5bd049f  call rax
00007accb5bd04a1  movaps xmm12, [rsp]
00007accb5bd04a6  add rsp, 0x40
00007accb5bd04aa  vmovaps xmm0, [rsp]
00007accb5bd04af  vmovaps xmm1, [rsp+0x10]
00007accb5bd04b5  vmovaps xmm2, [rsp+0x20]
00007accb5bd04bb  vmovaps xmm3, [rsp+0x30]
00007accb5bd04c1  vmovaps xmm4, [rsp+0x40]
00007accb5bd04c7  vmovaps xmm5, [rsp+0x50]
00007accb5bd04cd  vmovaps xmm6, [rsp+0x60]
00007accb5bd04d3  vmovaps xmm7, [rsp+0x70]
00007accb5bd04d9  vmovaps xmm8, [rsp+0x80]
00007accb5bd04e2  vmovaps xmm9, [rsp+0x90]
00007accb5bd04eb  vmovaps xmm10, [rsp+0xA0]
00007accb5bd04f4  vmovaps xmm11, [rsp+0xB0]
00007accb5bd04fd  vmovaps xmm13, [rsp+0xC0]
00007accb5bd0506  vmovaps xmm14, [rsp+0xD0]
00007accb5bd050f  vmovaps xmm15, [rsp+0xE0]
00007accb5bd0518  add rsp, 0xF0
00007accb5bd051f  pop r11
00007accb5bd0521  pop r10
00007accb5bd0523  pop r9
00007accb5bd0525  pop r8
00007accb5bd0527  pop rsi
00007accb5bd0528  pop rdi
00007accb5bd0529  pop rdx
00007accb5bd052a  pop rcx
00007accb5bd052b  pop rax
00007accb5bd052c  add rsp, 0x08
00007accb5bd0530  jmp 0x00007ACCB5BCF68D
00007accb5bd0535  call 0x00007ACCB59FF430
00007accb5bd053a  jmp 0x00007ACCB5BCF712
00007accb5bd053f  sub rsp, 0x08
00007accb5bd0543  push rax
00007accb5bd0544  push rcx
00007accb5bd0545  push rdx
00007accb5bd0546  push rdi
00007accb5bd0547  push rsi
00007accb5bd0548  push r8
00007accb5bd054a  push r9
00007accb5bd054c  push r10
00007accb5bd054e  push r11
00007accb5bd0550  sub rsp, 0xF0
00007accb5bd0557  vmovaps [rsp], xmm0
00007accb5bd055c  vmovaps [rsp+0x10], xmm1
00007accb5bd0562  vmovaps [rsp+0x20], xmm2
00007accb5bd0568  vmovaps [rsp+0x30], xmm3
00007accb5bd056e  vmovaps [rsp+0x40], xmm4
00007accb5bd0574  vmovaps [rsp+0x50], xmm5
00007accb5bd057a  vmovaps [rsp+0x60], xmm6
00007accb5bd0580  vmovaps [rsp+0x70], xmm7
00007accb5bd0586  vmovaps [rsp+0x80], xmm8
00007accb5bd058f  vmovaps [rsp+0x90], xmm9
00007accb5bd0598  vmovaps [rsp+0xA0], xmm10
00007accb5bd05a1  vmovaps [rsp+0xB0], xmm11
00007accb5bd05aa  vmovaps [rsp+0xC0], xmm12
00007accb5bd05b3  vmovaps [rsp+0xD0], xmm14
00007accb5bd05bc  vmovaps [rsp+0xE0], xmm15
00007accb5bd05c5  sub rsp, 0x40
00007accb5bd05c9  lea rdi, [rsp]
00007accb5bd05cd  lea rsi, [rsp+0x10]
00007accb5bd05d2  lea rdx, [rsp+0x20]
00007accb5bd05d7  lea rcx, [rsp+0x30]
00007accb5bd05dc  mov r8d, 0x00
00007accb5bd05e2  lea r9, [r15+0x3A8]
00007accb5bd05e9  movaps [rdi], xmm13
00007accb5bd05ed  movaps [rsi], xmm1
00007accb5bd05f0  movaps [rdx], xmm15
00007accb5bd05f4  movaps [rcx], xmm14
00007accb5bd05f8  mov rax, 0x59156B40DA50
00007accb5bd0602  call rax
00007accb5bd0604  movaps xmm13, [rsp]
00007accb5bd0609  add rsp, 0x40
00007accb5bd060d  vmovaps xmm0, [rsp]
00007accb5bd0612  vmovaps xmm1, [rsp+0x10]
00007accb5bd0618  vmovaps xmm2, [rsp+0x20]
00007accb5bd061e  vmovaps xmm3, [rsp+0x30]
00007accb5bd0624  vmovaps xmm4, [rsp+0x40]
00007accb5bd062a  vmovaps xmm5, [rsp+0x50]
00007accb5bd0630  vmovaps xmm6, [rsp+0x60]
00007accb5bd0636  vmovaps xmm7, [rsp+0x70]
00007accb5bd063c  vmovaps xmm8, [rsp+0x80]
00007accb5bd0645  vmovaps xmm9, [rsp+0x90]
00007accb5bd064e  vmovaps xmm10, [rsp+0xA0]
00007accb5bd0657  vmovaps xmm11, [rsp+0xB0]
00007accb5bd0660  vmovaps xmm12, [rsp+0xC0]
00007accb5bd0669  vmovaps xmm14, [rsp+0xD0]
00007accb5bd0672  vmovaps xmm15, [rsp+0xE0]
00007accb5bd067b  add rsp, 0xF0
00007accb5bd0682  pop r11
00007accb5bd0684  pop r10
00007accb5bd0686  pop r9
00007accb5bd0688  pop r8
00007accb5bd068a  pop rsi
00007accb5bd068b  pop rdi
00007accb5bd068c  pop rdx
00007accb5bd068d  pop rcx
00007accb5bd068e  pop rax
00007accb5bd068f  add rsp, 0x08
00007accb5bd0693  jmp 0x00007ACCB5BCF77F
00007accb5bd0698  call 0x00007ACCB59FF430
00007accb5bd069d  jmp 0x00007ACCB5BCF78C
00007accb5bd06a2  sub rsp, 0x08
00007accb5bd06a6  push rax
00007accb5bd06a7  push rcx
00007accb5bd06a8  push rdx
00007accb5bd06a9  push rdi
00007accb5bd06aa  push rsi
00007accb5bd06ab  push r8
00007accb5bd06ad  push r9
00007accb5bd06af  push r10
00007accb5bd06b1  push r11
00007accb5bd06b3  sub rsp, 0xF0
00007accb5bd06ba  vmovaps [rsp], xmm0
00007accb5bd06bf  vmovaps [rsp+0x10], xmm1
00007accb5bd06c5  vmovaps [rsp+0x20], xmm2
00007accb5bd06cb  vmovaps [rsp+0x30], xmm3
00007accb5bd06d1  vmovaps [rsp+0x40], xmm4
00007accb5bd06d7  vmovaps [rsp+0x50], xmm5
00007accb5bd06dd  vmovaps [rsp+0x60], xmm6
00007accb5bd06e3  vmovaps [rsp+0x70], xmm7
00007accb5bd06e9  vmovaps [rsp+0x80], xmm8
00007accb5bd06f2  vmovaps [rsp+0x90], xmm9
00007accb5bd06fb  vmovaps [rsp+0xA0], xmm10
00007accb5bd0704  vmovaps [rsp+0xB0], xmm11
00007accb5bd070d  vmovaps [rsp+0xC0], xmm13
00007accb5bd0716  vmovaps [rsp+0xD0], xmm14
00007accb5bd071f  vmovaps [rsp+0xE0], xmm15
00007accb5bd0728  sub rsp, 0x40
00007accb5bd072c  lea rdi, [rsp]
00007accb5bd0730  lea rsi, [rsp+0x10]
00007accb5bd0735  lea rdx, [rsp+0x20]
00007accb5bd073a  lea rcx, [rsp+0x30]
00007accb5bd073f  mov r8d, 0x00
00007accb5bd0745  lea r9, [r15+0x3A8]
00007accb5bd074c  movaps [rdi], xmm12
00007accb5bd0750  movaps [rsi], xmm15
00007accb5bd0754  movaps [rdx], xmm1
00007accb5bd0757  movaps [rcx], xmm14
00007accb5bd075b  mov rax, 0x59156B40DA50
00007accb5bd0765  call rax
00007accb5bd0767  movaps xmm12, [rsp]
00007accb5bd076c  add rsp, 0x40
00007accb5bd0770  vmovaps xmm0, [rsp]
00007accb5bd0775  vmovaps xmm1, [rsp+0x10]
00007accb5bd077b  vmovaps xmm2, [rsp+0x20]
00007accb5bd0781  vmovaps xmm3, [rsp+0x30]
00007accb5bd0787  vmovaps xmm4, [rsp+0x40]
00007accb5bd078d  vmovaps xmm5, [rsp+0x50]
00007accb5bd0793  vmovaps xmm6, [rsp+0x60]
00007accb5bd0799  vmovaps xmm7, [rsp+0x70]
00007accb5bd079f  vmovaps xmm8, [rsp+0x80]
00007accb5bd07a8  vmovaps xmm9, [rsp+0x90]
00007accb5bd07b1  vmovaps xmm10, [rsp+0xA0]
00007accb5bd07ba  vmovaps xmm11, [rsp+0xB0]
00007accb5bd07c3  vmovaps xmm13, [rsp+0xC0]
00007accb5bd07cc  vmovaps xmm14, [rsp+0xD0]
00007accb5bd07d5  vmovaps xmm15, [rsp+0xE0]
00007accb5bd07de  add rsp, 0xF0
00007accb5bd07e5  pop r11
00007accb5bd07e7  pop r10
00007accb5bd07e9  pop r9
00007accb5bd07eb  pop r8
00007accb5bd07ed  pop rsi
00007accb5bd07ee  pop rdi
00007accb5bd07ef  pop rdx
00007accb5bd07f0  pop rcx
00007accb5bd07f1  pop rax
00007accb5bd07f2  add rsp, 0x08
00007accb5bd07f6  jmp 0x00007ACCB5BCF7B8
00007accb5bd07fb  sub rsp, 0x08
00007accb5bd07ff  push rax
00007accb5bd0800  push rcx
00007accb5bd0801  push rdx
00007accb5bd0802  push rdi
00007accb5bd0803  push rsi
00007accb5bd0804  push r8
00007accb5bd0806  push r9
00007accb5bd0808  push r10
00007accb5bd080a  push r11
00007accb5bd080c  sub rsp, 0xF0
00007accb5bd0813  vmovaps [rsp], xmm0
00007accb5bd0818  vmovaps [rsp+0x10], xmm1
00007accb5bd081e  vmovaps [rsp+0x20], xmm2
00007accb5bd0824  vmovaps [rsp+0x30], xmm3
00007accb5bd082a  vmovaps [rsp+0x40], xmm4
00007accb5bd0830  vmovaps [rsp+0x50], xmm5
00007accb5bd0836  vmovaps [rsp+0x60], xmm6
00007accb5bd083c  vmovaps [rsp+0x70], xmm7
00007accb5bd0842  vmovaps [rsp+0x80], xmm8
00007accb5bd084b  vmovaps [rsp+0x90], xmm9
00007accb5bd0854  vmovaps [rsp+0xA0], xmm10
00007accb5bd085d  vmovaps [rsp+0xB0], xmm11
00007accb5bd0866  vmovaps [rsp+0xC0], xmm12
00007accb5bd086f  vmovaps [rsp+0xD0], xmm13
00007accb5bd0878  vmovaps [rsp+0xE0], xmm14
00007accb5bd0881  sub rsp, 0x40
00007accb5bd0885  lea rdi, [rsp]
00007accb5bd0889  lea rsi, [rsp+0x10]
00007accb5bd088e  lea rdx, [rsp+0x20]
00007accb5bd0893  lea rcx, [rsp+0x30]
00007accb5bd0898  mov r8d, 0x00
00007accb5bd089e  lea r9, [r15+0x3A8]
00007accb5bd08a5  movaps [rdi], xmm15
00007accb5bd08a9  movaps [rsi], xmm1
00007accb5bd08ac  movaps [rdx], xmm9
00007accb5bd08b0  movaps [rcx], xmm13
00007accb5bd08b4  mov rax, 0x59156B40DA50
00007accb5bd08be  call rax
00007accb5bd08c0  movaps xmm15, [rsp]
00007accb5bd08c5  add rsp, 0x40
00007accb5bd08c9  vmovaps xmm0, [rsp]
00007accb5bd08ce  vmovaps xmm1, [rsp+0x10]
00007accb5bd08d4  vmovaps xmm2, [rsp+0x20]
00007accb5bd08da  vmovaps xmm3, [rsp+0x30]
00007accb5bd08e0  vmovaps xmm4, [rsp+0x40]
00007accb5bd08e6  vmovaps xmm5, [rsp+0x50]
00007accb5bd08ec  vmovaps xmm6, [rsp+0x60]
00007accb5bd08f2  vmovaps xmm7, [rsp+0x70]
00007accb5bd08f8  vmovaps xmm8, [rsp+0x80]
00007accb5bd0901  vmovaps xmm9, [rsp+0x90]
00007accb5bd090a  vmovaps xmm10, [rsp+0xA0]
00007accb5bd0913  vmovaps xmm11, [rsp+0xB0]
00007accb5bd091c  vmovaps xmm12, [rsp+0xC0]
00007accb5bd0925  vmovaps xmm13, [rsp+0xD0]
00007accb5bd092e  vmovaps xmm14, [rsp+0xE0]
00007accb5bd0937  add rsp, 0xF0
00007accb5bd093e  pop r11
00007accb5bd0940  pop r10
00007accb5bd0942  pop r9
00007accb5bd0944  pop r8
00007accb5bd0946  pop rsi
00007accb5bd0947  pop rdi
00007accb5bd0948  pop rdx
00007accb5bd0949  pop rcx
00007accb5bd094a  pop rax
00007accb5bd094b  add rsp, 0x08
00007accb5bd094f  jmp 0x00007ACCB5BCF91A
00007accb5bd0954  sub rsp, 0x08
00007accb5bd0958  push rax
00007accb5bd0959  push rcx
00007accb5bd095a  push rdx
00007accb5bd095b  push rdi
00007accb5bd095c  push rsi
00007accb5bd095d  push r8
00007accb5bd095f  push r9
00007accb5bd0961  push r10
00007accb5bd0963  push r11
00007accb5bd0965  sub rsp, 0xF0
00007accb5bd096c  vmovaps [rsp], xmm0
00007accb5bd0971  vmovaps [rsp+0x10], xmm1
00007accb5bd0977  vmovaps [rsp+0x20], xmm2
00007accb5bd097d  vmovaps [rsp+0x30], xmm3
00007accb5bd0983  vmovaps [rsp+0x40], xmm4
00007accb5bd0989  vmovaps [rsp+0x50], xmm5
00007accb5bd098f  vmovaps [rsp+0x60], xmm6
00007accb5bd0995  vmovaps [rsp+0x70], xmm7
00007accb5bd099b  vmovaps [rsp+0x80], xmm8
00007accb5bd09a4  vmovaps [rsp+0x90], xmm10
00007accb5bd09ad  vmovaps [rsp+0xA0], xmm11
00007accb5bd09b6  vmovaps [rsp+0xB0], xmm12
00007accb5bd09bf  vmovaps [rsp+0xC0], xmm13
00007accb5bd09c8  vmovaps [rsp+0xD0], xmm14
00007accb5bd09d1  vmovaps [rsp+0xE0], xmm15
00007accb5bd09da  sub rsp, 0x40
00007accb5bd09de  lea rdi, [rsp]
00007accb5bd09e2  lea rsi, [rsp+0x10]
00007accb5bd09e7  lea rdx, [rsp+0x20]
00007accb5bd09ec  lea rcx, [rsp+0x30]
00007accb5bd09f1  mov r8d, 0x00
00007accb5bd09f7  lea r9, [r15+0x3A8]
00007accb5bd09fe  movaps [rdi], xmm9
00007accb5bd0a02  movaps [rsi], xmm14
00007accb5bd0a06  movaps [rdx], xmm13
00007accb5bd0a0a  movaps [rcx], xmm1
00007accb5bd0a0d  mov rax, 0x59156B40DA50
00007accb5bd0a17  call rax
00007accb5bd0a19  movaps xmm9, [rsp]
00007accb5bd0a1e  add rsp, 0x40
00007accb5bd0a22  vmovaps xmm0, [rsp]
00007accb5bd0a27  vmovaps xmm1, [rsp+0x10]
00007accb5bd0a2d  vmovaps xmm2, [rsp+0x20]
00007accb5bd0a33  vmovaps xmm3, [rsp+0x30]
00007accb5bd0a39  vmovaps xmm4, [rsp+0x40]
00007accb5bd0a3f  vmovaps xmm5, [rsp+0x50]
00007accb5bd0a45  vmovaps xmm6, [rsp+0x60]
00007accb5bd0a4b  vmovaps xmm7, [rsp+0x70]
00007accb5bd0a51  vmovaps xmm8, [rsp+0x80]
00007accb5bd0a5a  vmovaps xmm10, [rsp+0x90]
00007accb5bd0a63  vmovaps xmm11, [rsp+0xA0]
00007accb5bd0a6c  vmovaps xmm12, [rsp+0xB0]
00007accb5bd0a75  vmovaps xmm13, [rsp+0xC0]
00007accb5bd0a7e  vmovaps xmm14, [rsp+0xD0]
00007accb5bd0a87  vmovaps xmm15, [rsp+0xE0]
00007accb5bd0a90  add rsp, 0xF0
00007accb5bd0a97  pop r11
00007accb5bd0a99  pop r10
00007accb5bd0a9b  pop r9
00007accb5bd0a9d  pop r8
00007accb5bd0a9f  pop rsi
00007accb5bd0aa0  pop rdi
00007accb5bd0aa1  pop rdx
00007accb5bd0aa2  pop rcx
00007accb5bd0aa3  pop rax
00007accb5bd0aa4  add rsp, 0x08
00007accb5bd0aa8  jmp 0x00007ACCB5BCF955
00007accb5bd0aad  sub rsp, 0x08
00007accb5bd0ab1  push rax
00007accb5bd0ab2  push rcx
00007accb5bd0ab3  push rdx
00007accb5bd0ab4  push rdi
00007accb5bd0ab5  push rsi
00007accb5bd0ab6  push r8
00007accb5bd0ab8  push r9
00007accb5bd0aba  push r10
00007accb5bd0abc  push r11
00007accb5bd0abe  sub rsp, 0xF0
00007accb5bd0ac5  vmovaps [rsp], xmm0
00007accb5bd0aca  vmovaps [rsp+0x10], xmm1
00007accb5bd0ad0  vmovaps [rsp+0x20], xmm2
00007accb5bd0ad6  vmovaps [rsp+0x30], xmm3
00007accb5bd0adc  vmovaps [rsp+0x40], xmm4
00007accb5bd0ae2  vmovaps [rsp+0x50], xmm5
00007accb5bd0ae8  vmovaps [rsp+0x60], xmm6
00007accb5bd0aee  vmovaps [rsp+0x70], xmm7
00007accb5bd0af4  vmovaps [rsp+0x80], xmm8
00007accb5bd0afd  vmovaps [rsp+0x90], xmm9
00007accb5bd0b06  vmovaps [rsp+0xA0], xmm10
00007accb5bd0b0f  vmovaps [rsp+0xB0], xmm11
00007accb5bd0b18  vmovaps [rsp+0xC0], xmm12
00007accb5bd0b21  vmovaps [rsp+0xD0], xmm13
00007accb5bd0b2a  vmovaps [rsp+0xE0], xmm15
00007accb5bd0b33  sub rsp, 0x40
00007accb5bd0b37  lea rdi, [rsp]
00007accb5bd0b3b  lea rsi, [rsp+0x10]
00007accb5bd0b40  lea rdx, [rsp+0x20]
00007accb5bd0b45  lea rcx, [rsp+0x30]
00007accb5bd0b4a  mov r8d, 0x00
00007accb5bd0b50  lea r9, [r15+0x3A8]
00007accb5bd0b57  movaps [rdi], xmm14
00007accb5bd0b5b  movaps [rsi], xmm15
00007accb5bd0b5f  movaps [rdx], xmm8
00007accb5bd0b63  movaps [rcx], xmm1
00007accb5bd0b66  mov rax, 0x59156B40DA50
00007accb5bd0b70  call rax
00007accb5bd0b72  movaps xmm14, [rsp]
00007accb5bd0b77  add rsp, 0x40
00007accb5bd0b7b  vmovaps xmm0, [rsp]
00007accb5bd0b80  vmovaps xmm1, [rsp+0x10]
00007accb5bd0b86  vmovaps xmm2, [rsp+0x20]
00007accb5bd0b8c  vmovaps xmm3, [rsp+0x30]
00007accb5bd0b92  vmovaps xmm4, [rsp+0x40]
00007accb5bd0b98  vmovaps xmm5, [rsp+0x50]
00007accb5bd0b9e  vmovaps xmm6, [rsp+0x60]
00007accb5bd0ba4  vmovaps xmm7, [rsp+0x70]
00007accb5bd0baa  vmovaps xmm8, [rsp+0x80]
00007accb5bd0bb3  vmovaps xmm9, [rsp+0x90]
00007accb5bd0bbc  vmovaps xmm10, [rsp+0xA0]
00007accb5bd0bc5  vmovaps xmm11, [rsp+0xB0]
00007accb5bd0bce  vmovaps xmm12, [rsp+0xC0]
00007accb5bd0bd7  vmovaps xmm13, [rsp+0xD0]
00007accb5bd0be0  vmovaps xmm15, [rsp+0xE0]
00007accb5bd0be9  add rsp, 0xF0
00007accb5bd0bf0  pop r11
00007accb5bd0bf2  pop r10
00007accb5bd0bf4  pop r9
00007accb5bd0bf6  pop r8
00007accb5bd0bf8  pop rsi
00007accb5bd0bf9  pop rdi
00007accb5bd0bfa  pop rdx
00007accb5bd0bfb  pop rcx
00007accb5bd0bfc  pop rax
00007accb5bd0bfd  add rsp, 0x08
00007accb5bd0c01  jmp 0x00007ACCB5BCF984
00007accb5bd0c06  sub rsp, 0x08
00007accb5bd0c0a  push rax
00007accb5bd0c0b  push rcx
00007accb5bd0c0c  push rdx
00007accb5bd0c0d  push rdi
00007accb5bd0c0e  push rsi
00007accb5bd0c0f  push r8
00007accb5bd0c11  push r9
00007accb5bd0c13  push r10
00007accb5bd0c15  push r11
00007accb5bd0c17  sub rsp, 0xF0
00007accb5bd0c1e  vmovaps [rsp], xmm0
00007accb5bd0c23  vmovaps [rsp+0x10], xmm1
00007accb5bd0c29  vmovaps [rsp+0x20], xmm2
00007accb5bd0c2f  vmovaps [rsp+0x30], xmm3
00007accb5bd0c35  vmovaps [rsp+0x40], xmm4
00007accb5bd0c3b  vmovaps [rsp+0x50], xmm5
00007accb5bd0c41  vmovaps [rsp+0x60], xmm6
00007accb5bd0c47  vmovaps [rsp+0x70], xmm7
00007accb5bd0c4d  vmovaps [rsp+0x80], xmm8
00007accb5bd0c56  vmovaps [rsp+0x90], xmm9
00007accb5bd0c5f  vmovaps [rsp+0xA0], xmm10
00007accb5bd0c68  vmovaps [rsp+0xB0], xmm11
00007accb5bd0c71  vmovaps [rsp+0xC0], xmm12
00007accb5bd0c7a  vmovaps [rsp+0xD0], xmm13
00007accb5bd0c83  vmovaps [rsp+0xE0], xmm14
00007accb5bd0c8c  sub rsp, 0x40
00007accb5bd0c90  lea rdi, [rsp]
00007accb5bd0c94  lea rsi, [rsp+0x10]
00007accb5bd0c99  lea rdx, [rsp+0x20]
00007accb5bd0c9e  lea rcx, [rsp+0x30]
00007accb5bd0ca3  mov r8d, 0x00
00007accb5bd0ca9  lea r9, [r15+0x3A8]
00007accb5bd0cb0  movaps [rdi], xmm15
00007accb5bd0cb4  movaps [rsi], xmm12
00007accb5bd0cb8  movaps [rdx], xmm13
00007accb5bd0cbc  movaps [rcx], xmm1
00007accb5bd0cbf  mov rax, 0x59156B40DA50
00007accb5bd0cc9  call rax
00007accb5bd0ccb  movaps xmm15, [rsp]
00007accb5bd0cd0  add rsp, 0x40
00007accb5bd0cd4  vmovaps xmm0, [rsp]
00007accb5bd0cd9  vmovaps xmm1, [rsp+0x10]
00007accb5bd0cdf  vmovaps xmm2, [rsp+0x20]
00007accb5bd0ce5  vmovaps xmm3, [rsp+0x30]
00007accb5bd0ceb  vmovaps xmm4, [rsp+0x40]
00007accb5bd0cf1  vmovaps xmm5, [rsp+0x50]
00007accb5bd0cf7  vmovaps xmm6, [rsp+0x60]
00007accb5bd0cfd  vmovaps xmm7, [rsp+0x70]
00007accb5bd0d03  vmovaps xmm8, [rsp+0x80]
00007accb5bd0d0c  vmovaps xmm9, [rsp+0x90]
00007accb5bd0d15  vmovaps xmm10, [rsp+0xA0]
00007accb5bd0d1e  vmovaps xmm11, [rsp+0xB0]
00007accb5bd0d27  vmovaps xmm12, [rsp+0xC0]
00007accb5bd0d30  vmovaps xmm13, [rsp+0xD0]
00007accb5bd0d39  vmovaps xmm14, [rsp+0xE0]
00007accb5bd0d42  add rsp, 0xF0
00007accb5bd0d49  pop r11
00007accb5bd0d4b  pop r10
00007accb5bd0d4d  pop r9
00007accb5bd0d4f  pop r8
00007accb5bd0d51  pop rsi
00007accb5bd0d52  pop rdi
00007accb5bd0d53  pop rdx
00007accb5bd0d54  pop rcx
00007accb5bd0d55  pop rax
00007accb5bd0d56  add rsp, 0x08
00007accb5bd0d5a  jmp 0x00007ACCB5BCF9D1
00007accb5bd0d5f  sub rsp, 0x08
00007accb5bd0d63  push rax
00007accb5bd0d64  push rcx
00007accb5bd0d65  push rdx
00007accb5bd0d66  push rdi
00007accb5bd0d67  push rsi
00007accb5bd0d68  push r8
00007accb5bd0d6a  push r9
00007accb5bd0d6c  push r10
00007accb5bd0d6e  push r11
00007accb5bd0d70  sub rsp, 0xF0
00007accb5bd0d77  vmovaps [rsp], xmm0
00007accb5bd0d7c  vmovaps [rsp+0x10], xmm1
00007accb5bd0d82  vmovaps [rsp+0x20], xmm2
00007accb5bd0d88  vmovaps [rsp+0x30], xmm3
00007accb5bd0d8e  vmovaps [rsp+0x40], xmm4
00007accb5bd0d94  vmovaps [rsp+0x50], xmm5
00007accb5bd0d9a  vmovaps [rsp+0x60], xmm6
00007accb5bd0da0  vmovaps [rsp+0x70], xmm7
00007accb5bd0da6  vmovaps [rsp+0x80], xmm8
00007accb5bd0daf  vmovaps [rsp+0x90], xmm9
00007accb5bd0db8  vmovaps [rsp+0xA0], xmm10
00007accb5bd0dc1  vmovaps [rsp+0xB0], xmm11
00007accb5bd0dca  vmovaps [rsp+0xC0], xmm12
00007accb5bd0dd3  vmovaps [rsp+0xD0], xmm13
00007accb5bd0ddc  vmovaps [rsp+0xE0], xmm14
00007accb5bd0de5  sub rsp, 0x40
00007accb5bd0de9  lea rdi, [rsp]
00007accb5bd0ded  lea rsi, [rsp+0x10]
00007accb5bd0df2  lea rdx, [rsp+0x20]
00007accb5bd0df7  lea rcx, [rsp+0x30]
00007accb5bd0dfc  mov r8d, 0x00
00007accb5bd0e02  lea r9, [r15+0x3A8]
00007accb5bd0e09  movaps [rdi], xmm15
00007accb5bd0e0d  movaps [rsi], xmm3
00007accb5bd0e10  movaps [rdx], xmm1
00007accb5bd0e13  movaps [rcx], xmm8
00007accb5bd0e17  mov rax, 0x59156B40DA50
00007accb5bd0e21  call rax
00007accb5bd0e23  movaps xmm15, [rsp]
00007accb5bd0e28  add rsp, 0x40
00007accb5bd0e2c  vmovaps xmm0, [rsp]
00007accb5bd0e31  vmovaps xmm1, [rsp+0x10]
00007accb5bd0e37  vmovaps xmm2, [rsp+0x20]
00007accb5bd0e3d  vmovaps xmm3, [rsp+0x30]
00007accb5bd0e43  vmovaps xmm4, [rsp+0x40]
00007accb5bd0e49  vmovaps xmm5, [rsp+0x50]
00007accb5bd0e4f  vmovaps xmm6, [rsp+0x60]
00007accb5bd0e55  vmovaps xmm7, [rsp+0x70]
00007accb5bd0e5b  vmovaps xmm8, [rsp+0x80]
00007accb5bd0e64  vmovaps xmm9, [rsp+0x90]
00007accb5bd0e6d  vmovaps xmm10, [rsp+0xA0]
00007accb5bd0e76  vmovaps xmm11, [rsp+0xB0]
00007accb5bd0e7f  vmovaps xmm12, [rsp+0xC0]
00007accb5bd0e88  vmovaps xmm13, [rsp+0xD0]
00007accb5bd0e91  vmovaps xmm14, [rsp+0xE0]
00007accb5bd0e9a  add rsp, 0xF0
00007accb5bd0ea1  pop r11
00007accb5bd0ea3  pop r10
00007accb5bd0ea5  pop r9
00007accb5bd0ea7  pop r8
00007accb5bd0ea9  pop rsi
00007accb5bd0eaa  pop rdi
00007accb5bd0eab  pop rdx
00007accb5bd0eac  pop rcx
00007accb5bd0ead  pop rax
00007accb5bd0eae  add rsp, 0x08
00007accb5bd0eb2  jmp 0x00007ACCB5BCFA82
00007accb5bd0eb7  sub rsp, 0x08
00007accb5bd0ebb  push rax
00007accb5bd0ebc  push rcx
00007accb5bd0ebd  push rdx
00007accb5bd0ebe  push rdi
00007accb5bd0ebf  push rsi
00007accb5bd0ec0  push r8
00007accb5bd0ec2  push r9
00007accb5bd0ec4  push r10
00007accb5bd0ec6  push r11
00007accb5bd0ec8  sub rsp, 0xF0
00007accb5bd0ecf  vmovaps [rsp], xmm0
00007accb5bd0ed4  vmovaps [rsp+0x10], xmm1
00007accb5bd0eda  vmovaps [rsp+0x20], xmm2
00007accb5bd0ee0  vmovaps [rsp+0x30], xmm3
00007accb5bd0ee6  vmovaps [rsp+0x40], xmm4
00007accb5bd0eec  vmovaps [rsp+0x50], xmm5
00007accb5bd0ef2  vmovaps [rsp+0x60], xmm6
00007accb5bd0ef8  vmovaps [rsp+0x70], xmm7
00007accb5bd0efe  vmovaps [rsp+0x80], xmm9
00007accb5bd0f07  vmovaps [rsp+0x90], xmm10
00007accb5bd0f10  vmovaps [rsp+0xA0], xmm11
00007accb5bd0f19  vmovaps [rsp+0xB0], xmm12
00007accb5bd0f22  vmovaps [rsp+0xC0], xmm13
00007accb5bd0f2b  vmovaps [rsp+0xD0], xmm14
00007accb5bd0f34  vmovaps [rsp+0xE0], xmm15
00007accb5bd0f3d  sub rsp, 0x40
00007accb5bd0f41  lea rdi, [rsp]
00007accb5bd0f45  lea rsi, [rsp+0x10]
00007accb5bd0f4a  lea rdx, [rsp+0x20]
00007accb5bd0f4f  lea rcx, [rsp+0x30]
00007accb5bd0f54  mov r8d, 0x00
00007accb5bd0f5a  lea r9, [r15+0x3A8]
00007accb5bd0f61  movaps [rdi], xmm8
00007accb5bd0f65  movaps [rsi], xmm9
00007accb5bd0f69  movaps [rdx], xmm5
00007accb5bd0f6c  movaps [rcx], xmm1
00007accb5bd0f6f  mov rax, 0x59156B40DA50
00007accb5bd0f79  call rax
00007accb5bd0f7b  movaps xmm8, [rsp]
00007accb5bd0f80  add rsp, 0x40
00007accb5bd0f84  vmovaps xmm0, [rsp]
00007accb5bd0f89  vmovaps xmm1, [rsp+0x10]
00007accb5bd0f8f  vmovaps xmm2, [rsp+0x20]
00007accb5bd0f95  vmovaps xmm3, [rsp+0x30]
00007accb5bd0f9b  vmovaps xmm4, [rsp+0x40]
00007accb5bd0fa1  vmovaps xmm5, [rsp+0x50]
00007accb5bd0fa7  vmovaps xmm6, [rsp+0x60]
00007accb5bd0fad  vmovaps xmm7, [rsp+0x70]
00007accb5bd0fb3  vmovaps xmm9, [rsp+0x80]
00007accb5bd0fbc  vmovaps xmm10, [rsp+0x90]
00007accb5bd0fc5  vmovaps xmm11, [rsp+0xA0]
00007accb5bd0fce  vmovaps xmm12, [rsp+0xB0]
00007accb5bd0fd7  vmovaps xmm13, [rsp+0xC0]
00007accb5bd0fe0  vmovaps xmm14, [rsp+0xD0]
00007accb5bd0fe9  vmovaps xmm15, [rsp+0xE0]
00007accb5bd0ff2  add rsp, 0xF0
00007accb5bd0ff9  pop r11
00007accb5bd0ffb  pop r10
00007accb5bd0ffd  pop r9
00007accb5bd0fff  pop r8
00007accb5bd1001  pop rsi
00007accb5bd1002  pop rdi
00007accb5bd1003  pop rdx
00007accb5bd1004  pop rcx
00007accb5bd1005  pop rax
00007accb5bd1006  add rsp, 0x08
00007accb5bd100a  jmp 0x00007ACCB5BCFAAB
00007accb5bd100f  sub rsp, 0x08
00007accb5bd1013  push rax
00007accb5bd1014  push rcx
00007accb5bd1015  push rdx
00007accb5bd1016  push rdi
00007accb5bd1017  push rsi
00007accb5bd1018  push r8
00007accb5bd101a  push r9
00007accb5bd101c  push r10
00007accb5bd101e  push r11
00007accb5bd1020  sub rsp, 0xF0
00007accb5bd1027  vmovaps [rsp], xmm0
00007accb5bd102c  vmovaps [rsp+0x10], xmm1
00007accb5bd1032  vmovaps [rsp+0x20], xmm2
00007accb5bd1038  vmovaps [rsp+0x30], xmm3
00007accb5bd103e  vmovaps [rsp+0x40], xmm4
00007accb5bd1044  vmovaps [rsp+0x50], xmm6
00007accb5bd104a  vmovaps [rsp+0x60], xmm7
00007accb5bd1050  vmovaps [rsp+0x70], xmm8
00007accb5bd1056  vmovaps [rsp+0x80], xmm9
00007accb5bd105f  vmovaps [rsp+0x90], xmm10
00007accb5bd1068  vmovaps [rsp+0xA0], xmm11
00007accb5bd1071  vmovaps [rsp+0xB0], xmm12
00007accb5bd107a  vmovaps [rsp+0xC0], xmm13
00007accb5bd1083  vmovaps [rsp+0xD0], xmm14
00007accb5bd108c  vmovaps [rsp+0xE0], xmm15
00007accb5bd1095  sub rsp, 0x40
00007accb5bd1099  lea rdi, [rsp]
00007accb5bd109d  lea rsi, [rsp+0x10]
00007accb5bd10a2  lea rdx, [rsp+0x20]
00007accb5bd10a7  lea rcx, [rsp+0x30]
00007accb5bd10ac  mov r8d, 0x00
00007accb5bd10b2  lea r9, [r15+0x3A8]
00007accb5bd10b9  movaps [rdi], xmm5
00007accb5bd10bc  movaps [rsi], xmm14
00007accb5bd10c0  movaps [rdx], xmm9
00007accb5bd10c4  movaps [rcx], xmm1
00007accb5bd10c7  mov rax, 0x59156B40DA50
00007accb5bd10d1  call rax
00007accb5bd10d3  movaps xmm5, [rsp]
00007accb5bd10d7  add rsp, 0x40
00007accb5bd10db  vmovaps xmm0, [rsp]
00007accb5bd10e0  vmovaps xmm1, [rsp+0x10]
00007accb5bd10e6  vmovaps xmm2, [rsp+0x20]
00007accb5bd10ec  vmovaps xmm3, [rsp+0x30]
00007accb5bd10f2  vmovaps xmm4, [rsp+0x40]
00007accb5bd10f8  vmovaps xmm6, [rsp+0x50]
00007accb5bd10fe  vmovaps xmm7, [rsp+0x60]
00007accb5bd1104  vmovaps xmm8, [rsp+0x70]
00007accb5bd110a  vmovaps xmm9, [rsp+0x80]
00007accb5bd1113  vmovaps xmm10, [rsp+0x90]
00007accb5bd111c  vmovaps xmm11, [rsp+0xA0]
00007accb5bd1125  vmovaps xmm12, [rsp+0xB0]
00007accb5bd112e  vmovaps xmm13, [rsp+0xC0]
00007accb5bd1137  vmovaps xmm14, [rsp+0xD0]
00007accb5bd1140  vmovaps xmm15, [rsp+0xE0]
00007accb5bd1149  add rsp, 0xF0
00007accb5bd1150  pop r11
00007accb5bd1152  pop r10
00007accb5bd1154  pop r9
00007accb5bd1156  pop r8
00007accb5bd1158  pop rsi
00007accb5bd1159  pop rdi
00007accb5bd115a  pop rdx
00007accb5bd115b  pop rcx
00007accb5bd115c  pop rax
00007accb5bd115d  add rsp, 0x08
00007accb5bd1161  jmp 0x00007ACCB5BCFADF
00007accb5bd1166  sub rsp, 0x08
00007accb5bd116a  push rax
00007accb5bd116b  push rcx
00007accb5bd116c  push rdx
00007accb5bd116d  push rdi
00007accb5bd116e  push rsi
00007accb5bd116f  push r8
00007accb5bd1171  push r9
00007accb5bd1173  push r10
00007accb5bd1175  push r11
00007accb5bd1177  sub rsp, 0xF0
00007accb5bd117e  vmovaps [rsp], xmm0
00007accb5bd1183  vmovaps [rsp+0x10], xmm1
00007accb5bd1189  vmovaps [rsp+0x20], xmm2
00007accb5bd118f  vmovaps [rsp+0x30], xmm3
00007accb5bd1195  vmovaps [rsp+0x40], xmm4
00007accb5bd119b  vmovaps [rsp+0x50], xmm5
00007accb5bd11a1  vmovaps [rsp+0x60], xmm6
00007accb5bd11a7  vmovaps [rsp+0x70], xmm7
00007accb5bd11ad  vmovaps [rsp+0x80], xmm8
00007accb5bd11b6  vmovaps [rsp+0x90], xmm10
00007accb5bd11bf  vmovaps [rsp+0xA0], xmm11
00007accb5bd11c8  vmovaps [rsp+0xB0], xmm12
00007accb5bd11d1  vmovaps [rsp+0xC0], xmm13
00007accb5bd11da  vmovaps [rsp+0xD0], xmm14
00007accb5bd11e3  vmovaps [rsp+0xE0], xmm15
00007accb5bd11ec  sub rsp, 0x40
00007accb5bd11f0  lea rdi, [rsp]
00007accb5bd11f4  lea rsi, [rsp+0x10]
00007accb5bd11f9  lea rdx, [rsp+0x20]
00007accb5bd11fe  lea rcx, [rsp+0x30]
00007accb5bd1203  mov r8d, 0x00
00007accb5bd1209  lea r9, [r15+0x3A8]
00007accb5bd1210  movaps [rdi], xmm9
00007accb5bd1214  movaps [rsi], xmm14
00007accb5bd1218  movaps [rdx], xmm4
00007accb5bd121b  movaps [rcx], xmm1
00007accb5bd121e  mov rax, 0x59156B40DA50
00007accb5bd1228  call rax
00007accb5bd122a  movaps xmm9, [rsp]
00007accb5bd122f  add rsp, 0x40
00007accb5bd1233  vmovaps xmm0, [rsp]
00007accb5bd1238  vmovaps xmm1, [rsp+0x10]
00007accb5bd123e  vmovaps xmm2, [rsp+0x20]
00007accb5bd1244  vmovaps xmm3, [rsp+0x30]
00007accb5bd124a  vmovaps xmm4, [rsp+0x40]
00007accb5bd1250  vmovaps xmm5, [rsp+0x50]
00007accb5bd1256  vmovaps xmm6, [rsp+0x60]
00007accb5bd125c  vmovaps xmm7, [rsp+0x70]
00007accb5bd1262  vmovaps xmm8, [rsp+0x80]
00007accb5bd126b  vmovaps xmm10, [rsp+0x90]
00007accb5bd1274  vmovaps xmm11, [rsp+0xA0]
00007accb5bd127d  vmovaps xmm12, [rsp+0xB0]
00007accb5bd1286  vmovaps xmm13, [rsp+0xC0]
00007accb5bd128f  vmovaps xmm14, [rsp+0xD0]
00007accb5bd1298  vmovaps xmm15, [rsp+0xE0]
00007accb5bd12a1  add rsp, 0xF0
00007accb5bd12a8  pop r11
00007accb5bd12aa  pop r10
00007accb5bd12ac  pop r9
00007accb5bd12ae  pop r8
00007accb5bd12b0  pop rsi
00007accb5bd12b1  pop rdi
00007accb5bd12b2  pop rdx
00007accb5bd12b3  pop rcx
00007accb5bd12b4  pop rax
00007accb5bd12b5  add rsp, 0x08
00007accb5bd12b9  jmp 0x00007ACCB5BCFB0E
00007accb5bd12be  sub rsp, 0x08
00007accb5bd12c2  push rax
00007accb5bd12c3  push rcx
00007accb5bd12c4  push rdx
00007accb5bd12c5  push rdi
00007accb5bd12c6  push rsi
00007accb5bd12c7  push r8
00007accb5bd12c9  push r9
00007accb5bd12cb  push r10
00007accb5bd12cd  push r11
00007accb5bd12cf  sub rsp, 0xF0
00007accb5bd12d6  vmovaps [rsp], xmm0
00007accb5bd12db  vmovaps [rsp+0x10], xmm1
00007accb5bd12e1  vmovaps [rsp+0x20], xmm3
00007accb5bd12e7  vmovaps [rsp+0x30], xmm4
00007accb5bd12ed  vmovaps [rsp+0x40], xmm5
00007accb5bd12f3  vmovaps [rsp+0x50], xmm6
00007accb5bd12f9  vmovaps [rsp+0x60], xmm7
00007accb5bd12ff  vmovaps [rsp+0x70], xmm8
00007accb5bd1305  vmovaps [rsp+0x80], xmm9
00007accb5bd130e  vmovaps [rsp+0x90], xmm10
00007accb5bd1317  vmovaps [rsp+0xA0], xmm11
00007accb5bd1320  vmovaps [rsp+0xB0], xmm12
00007accb5bd1329  vmovaps [rsp+0xC0], xmm13
00007accb5bd1332  vmovaps [rsp+0xD0], xmm14
00007accb5bd133b  vmovaps [rsp+0xE0], xmm15
00007accb5bd1344  sub rsp, 0x40
00007accb5bd1348  lea rdi, [rsp]
00007accb5bd134c  lea rsi, [rsp+0x10]
00007accb5bd1351  lea rdx, [rsp+0x20]
00007accb5bd1356  lea rcx, [rsp+0x30]
00007accb5bd135b  mov r8d, 0x00
00007accb5bd1361  lea r9, [r15+0x3A8]
00007accb5bd1368  movaps [rdi], xmm2
00007accb5bd136b  movaps [rsi], xmm8
00007accb5bd136f  movaps [rdx], xmm13
00007accb5bd1373  movaps [rcx], xmm3
00007accb5bd1376  mov rax, 0x59156B40DA50
00007accb5bd1380  call rax
00007accb5bd1382  movaps xmm2, [rsp]
00007accb5bd1386  add rsp, 0x40
00007accb5bd138a  vmovaps xmm0, [rsp]
00007accb5bd138f  vmovaps xmm1, [rsp+0x10]
00007accb5bd1395  vmovaps xmm3, [rsp+0x20]
00007accb5bd139b  vmovaps xmm4, [rsp+0x30]
00007accb5bd13a1  vmovaps xmm5, [rsp+0x40]
00007accb5bd13a7  vmovaps xmm6, [rsp+0x50]
00007accb5bd13ad  vmovaps xmm7, [rsp+0x60]
00007accb5bd13b3  vmovaps xmm8, [rsp+0x70]
00007accb5bd13b9  vmovaps xmm9, [rsp+0x80]
00007accb5bd13c2  vmovaps xmm10, [rsp+0x90]
00007accb5bd13cb  vmovaps xmm11, [rsp+0xA0]
00007accb5bd13d4  vmovaps xmm12, [rsp+0xB0]
00007accb5bd13dd  vmovaps xmm13, [rsp+0xC0]
00007accb5bd13e6  vmovaps xmm14, [rsp+0xD0]
00007accb5bd13ef  vmovaps xmm15, [rsp+0xE0]
00007accb5bd13f8  add rsp, 0xF0
00007accb5bd13ff  pop r11
00007accb5bd1401  pop r10
00007accb5bd1403  pop r9
00007accb5bd1405  pop r8
00007accb5bd1407  pop rsi
00007accb5bd1408  pop rdi
00007accb5bd1409  pop rdx
00007accb5bd140a  pop rcx
00007accb5bd140b  pop rax
00007accb5bd140c  add rsp, 0x08
00007accb5bd1410  jmp 0x00007ACCB5BCFB8C
00007accb5bd1415  sub rsp, 0x08
00007accb5bd1419  push rax
00007accb5bd141a  push rcx
00007accb5bd141b  push rdx
00007accb5bd141c  push rdi
00007accb5bd141d  push rsi
00007accb5bd141e  push r8
00007accb5bd1420  push r9
00007accb5bd1422  push r10
00007accb5bd1424  push r11
00007accb5bd1426  sub rsp, 0xF0
00007accb5bd142d  vmovaps [rsp], xmm0
00007accb5bd1432  vmovaps [rsp+0x10], xmm1
00007accb5bd1438  vmovaps [rsp+0x20], xmm2
00007accb5bd143e  vmovaps [rsp+0x30], xmm3
00007accb5bd1444  vmovaps [rsp+0x40], xmm4
00007accb5bd144a  vmovaps [rsp+0x50], xmm5
00007accb5bd1450  vmovaps [rsp+0x60], xmm6
00007accb5bd1456  vmovaps [rsp+0x70], xmm7
00007accb5bd145c  vmovaps [rsp+0x80], xmm9
00007accb5bd1465  vmovaps [rsp+0x90], xmm10
00007accb5bd146e  vmovaps [rsp+0xA0], xmm11
00007accb5bd1477  vmovaps [rsp+0xB0], xmm12
00007accb5bd1480  vmovaps [rsp+0xC0], xmm13
00007accb5bd1489  vmovaps [rsp+0xD0], xmm14
00007accb5bd1492  vmovaps [rsp+0xE0], xmm15
00007accb5bd149b  sub rsp, 0x40
00007accb5bd149f  lea rdi, [rsp]
00007accb5bd14a3  lea rsi, [rsp+0x10]
00007accb5bd14a8  lea rdx, [rsp+0x20]
00007accb5bd14ad  lea rcx, [rsp+0x30]
00007accb5bd14b2  mov r8d, 0x00
00007accb5bd14b8  lea r9, [r15+0x3A8]
00007accb5bd14bf  movaps [rdi], xmm8
00007accb5bd14c3  movaps [rsi], xmm15
00007accb5bd14c7  movaps [rdx], xmm13
00007accb5bd14cb  movaps [rcx], xmm1
00007accb5bd14ce  mov rax, 0x59156B40DA50
00007accb5bd14d8  call rax
00007accb5bd14da  movaps xmm8, [rsp]
00007accb5bd14df  add rsp, 0x40
00007accb5bd14e3  vmovaps xmm0, [rsp]
00007accb5bd14e8  vmovaps xmm1, [rsp+0x10]
00007accb5bd14ee  vmovaps xmm2, [rsp+0x20]
00007accb5bd14f4  vmovaps xmm3, [rsp+0x30]
00007accb5bd14fa  vmovaps xmm4, [rsp+0x40]
00007accb5bd1500  vmovaps xmm5, [rsp+0x50]
00007accb5bd1506  vmovaps xmm6, [rsp+0x60]
00007accb5bd150c  vmovaps xmm7, [rsp+0x70]
00007accb5bd1512  vmovaps xmm9, [rsp+0x80]
00007accb5bd151b  vmovaps xmm10, [rsp+0x90]
00007accb5bd1524  vmovaps xmm11, [rsp+0xA0]
00007accb5bd152d  vmovaps xmm12, [rsp+0xB0]
00007accb5bd1536  vmovaps xmm13, [rsp+0xC0]
00007accb5bd153f  vmovaps xmm14, [rsp+0xD0]
00007accb5bd1548  vmovaps xmm15, [rsp+0xE0]
00007accb5bd1551  add rsp, 0xF0
00007accb5bd1558  pop r11
00007accb5bd155a  pop r10
00007accb5bd155c  pop r9
00007accb5bd155e  pop r8
00007accb5bd1560  pop rsi
00007accb5bd1561  pop rdi
00007accb5bd1562  pop rdx
00007accb5bd1563  pop rcx
00007accb5bd1564  pop rax
00007accb5bd1565  add rsp, 0x08
00007accb5bd1569  jmp 0x00007ACCB5BCFBBB
00007accb5bd156e  call 0x00007ACCB59FF430
00007accb5bd1573  jmp 0x00007ACCB5BCFBC8
00007accb5bd1578  sub rsp, 0x08
00007accb5bd157c  push rax
00007accb5bd157d  push rcx
00007accb5bd157e  push rdx
00007accb5bd157f  push rdi
00007accb5bd1580  push rsi
00007accb5bd1581  push r8
00007accb5bd1583  push r9
00007accb5bd1585  push r10
00007accb5bd1587  push r11
00007accb5bd1589  sub rsp, 0xF0
00007accb5bd1590  vmovaps [rsp], xmm0
00007accb5bd1595  vmovaps [rsp+0x10], xmm1
00007accb5bd159b  vmovaps [rsp+0x20], xmm2
00007accb5bd15a1  vmovaps [rsp+0x30], xmm3
00007accb5bd15a7  vmovaps [rsp+0x40], xmm4
00007accb5bd15ad  vmovaps [rsp+0x50], xmm5
00007accb5bd15b3  vmovaps [rsp+0x60], xmm6
00007accb5bd15b9  vmovaps [rsp+0x70], xmm7
00007accb5bd15bf  vmovaps [rsp+0x80], xmm8
00007accb5bd15c8  vmovaps [rsp+0x90], xmm9
00007accb5bd15d1  vmovaps [rsp+0xA0], xmm10
00007accb5bd15da  vmovaps [rsp+0xB0], xmm11
00007accb5bd15e3  vmovaps [rsp+0xC0], xmm12
00007accb5bd15ec  vmovaps [rsp+0xD0], xmm14
00007accb5bd15f5  vmovaps [rsp+0xE0], xmm15
00007accb5bd15fe  sub rsp, 0x40
00007accb5bd1602  lea rdi, [rsp]
00007accb5bd1606  lea rsi, [rsp+0x10]
00007accb5bd160b  lea rdx, [rsp+0x20]
00007accb5bd1610  lea rcx, [rsp+0x30]
00007accb5bd1615  mov r8d, 0x00
00007accb5bd161b  lea r9, [r15+0x3A8]
00007accb5bd1622  movaps [rdi], xmm13
00007accb5bd1626  movaps [rsi], xmm5
00007accb5bd1629  movaps [rdx], xmm11
00007accb5bd162d  movaps [rcx], xmm15
00007accb5bd1631  mov rax, 0x59156B40DA50
00007accb5bd163b  call rax
00007accb5bd163d  movaps xmm13, [rsp]
00007accb5bd1642  add rsp, 0x40
00007accb5bd1646  vmovaps xmm0, [rsp]
00007accb5bd164b  vmovaps xmm1, [rsp+0x10]
00007accb5bd1651  vmovaps xmm2, [rsp+0x20]
00007accb5bd1657  vmovaps xmm3, [rsp+0x30]
00007accb5bd165d  vmovaps xmm4, [rsp+0x40]
00007accb5bd1663  vmovaps xmm5, [rsp+0x50]
00007accb5bd1669  vmovaps xmm6, [rsp+0x60]
00007accb5bd166f  vmovaps xmm7, [rsp+0x70]
00007accb5bd1675  vmovaps xmm8, [rsp+0x80]
00007accb5bd167e  vmovaps xmm9, [rsp+0x90]
00007accb5bd1687  vmovaps xmm10, [rsp+0xA0]
00007accb5bd1690  vmovaps xmm11, [rsp+0xB0]
00007accb5bd1699  vmovaps xmm12, [rsp+0xC0]
00007accb5bd16a2  vmovaps xmm14, [rsp+0xD0]
00007accb5bd16ab  vmovaps xmm15, [rsp+0xE0]
00007accb5bd16b4  add rsp, 0xF0
00007accb5bd16bb  pop r11
00007accb5bd16bd  pop r10
00007accb5bd16bf  pop r9
00007accb5bd16c1  pop r8
00007accb5bd16c3  pop rsi
00007accb5bd16c4  pop rdi
00007accb5bd16c5  pop rdx
00007accb5bd16c6  pop rcx
00007accb5bd16c7  pop rax
00007accb5bd16c8  add rsp, 0x08
00007accb5bd16cc  jmp 0x00007ACCB5BCFBF9
00007accb5bd16d1  sub rsp, 0x08
00007accb5bd16d5  push rax
00007accb5bd16d6  push rcx
00007accb5bd16d7  push rdx
00007accb5bd16d8  push rdi
00007accb5bd16d9  push rsi
00007accb5bd16da  push r8
00007accb5bd16dc  push r9
00007accb5bd16de  push r10
00007accb5bd16e0  push r11
00007accb5bd16e2  sub rsp, 0xF0
00007accb5bd16e9  vmovaps [rsp], xmm0
00007accb5bd16ee  vmovaps [rsp+0x10], xmm1
00007accb5bd16f4  vmovaps [rsp+0x20], xmm2
00007accb5bd16fa  vmovaps [rsp+0x30], xmm3
00007accb5bd1700  vmovaps [rsp+0x40], xmm4
00007accb5bd1706  vmovaps [rsp+0x50], xmm5
00007accb5bd170c  vmovaps [rsp+0x60], xmm6
00007accb5bd1712  vmovaps [rsp+0x70], xmm7
00007accb5bd1718  vmovaps [rsp+0x80], xmm8
00007accb5bd1721  vmovaps [rsp+0x90], xmm9
00007accb5bd172a  vmovaps [rsp+0xA0], xmm10
00007accb5bd1733  vmovaps [rsp+0xB0], xmm12
00007accb5bd173c  vmovaps [rsp+0xC0], xmm13
00007accb5bd1745  vmovaps [rsp+0xD0], xmm14
00007accb5bd174e  vmovaps [rsp+0xE0], xmm15
00007accb5bd1757  sub rsp, 0x40
00007accb5bd175b  lea rdi, [rsp]
00007accb5bd175f  lea rsi, [rsp+0x10]
00007accb5bd1764  lea rdx, [rsp+0x20]
00007accb5bd1769  lea rcx, [rsp+0x30]
00007accb5bd176e  mov r8d, 0x00
00007accb5bd1774  lea r9, [r15+0x3A8]
00007accb5bd177b  movaps [rdi], xmm11
00007accb5bd177f  movaps [rsi], xmm9
00007accb5bd1783  movaps [rdx], xmm4
00007accb5bd1786  movaps [rcx], xmm15
00007accb5bd178a  mov rax, 0x59156B40DA50
00007accb5bd1794  call rax
00007accb5bd1796  movaps xmm11, [rsp]
00007accb5bd179b  add rsp, 0x40
00007accb5bd179f  vmovaps xmm0, [rsp]
00007accb5bd17a4  vmovaps xmm1, [rsp+0x10]
00007accb5bd17aa  vmovaps xmm2, [rsp+0x20]
00007accb5bd17b0  vmovaps xmm3, [rsp+0x30]
00007accb5bd17b6  vmovaps xmm4, [rsp+0x40]
00007accb5bd17bc  vmovaps xmm5, [rsp+0x50]
00007accb5bd17c2  vmovaps xmm6, [rsp+0x60]
00007accb5bd17c8  vmovaps xmm7, [rsp+0x70]
00007accb5bd17ce  vmovaps xmm8, [rsp+0x80]
00007accb5bd17d7  vmovaps xmm9, [rsp+0x90]
00007accb5bd17e0  vmovaps xmm10, [rsp+0xA0]
00007accb5bd17e9  vmovaps xmm12, [rsp+0xB0]
00007accb5bd17f2  vmovaps xmm13, [rsp+0xC0]
00007accb5bd17fb  vmovaps xmm14, [rsp+0xD0]
00007accb5bd1804  vmovaps xmm15, [rsp+0xE0]
00007accb5bd180d  add rsp, 0xF0
00007accb5bd1814  pop r11
00007accb5bd1816  pop r10
00007accb5bd1818  pop r9
00007accb5bd181a  pop r8
00007accb5bd181c  pop rsi
00007accb5bd181d  pop rdi
00007accb5bd181e  pop rdx
00007accb5bd181f  pop rcx
00007accb5bd1820  pop rax
00007accb5bd1821  add rsp, 0x08
00007accb5bd1825  jmp 0x00007ACCB5BCFC22
00007accb5bd182a  call 0x00007ACCB5A0E760
00007accb5bd182f  jmp 0x00007ACCB5BCFC45
00007accb5bd1834  call 0x00007ACCB5A07890
00007accb5bd1839  jmp 0x00007ACCB5BCFC4F
00007accb5bd183e  sub rsp, 0x08
00007accb5bd1842  push rax
00007accb5bd1843  push rcx
00007accb5bd1844  push rdx
00007accb5bd1845  push rdi
00007accb5bd1846  push rsi
00007accb5bd1847  push r8
00007accb5bd1849  push r9
00007accb5bd184b  push r10
00007accb5bd184d  push r11
00007accb5bd184f  sub rsp, 0xF0
00007accb5bd1856  vmovaps [rsp], xmm0
00007accb5bd185b  vmovaps [rsp+0x10], xmm1
00007accb5bd1861  vmovaps [rsp+0x20], xmm2
00007accb5bd1867  vmovaps [rsp+0x30], xmm3
00007accb5bd186d  vmovaps [rsp+0x40], xmm5
00007accb5bd1873  vmovaps [rsp+0x50], xmm6
00007accb5bd1879  vmovaps [rsp+0x60], xmm7
00007accb5bd187f  vmovaps [rsp+0x70], xmm8
00007accb5bd1885  vmovaps [rsp+0x80], xmm9
00007accb5bd188e  vmovaps [rsp+0x90], xmm10
00007accb5bd1897  vmovaps [rsp+0xA0], xmm11
00007accb5bd18a0  vmovaps [rsp+0xB0], xmm12
00007accb5bd18a9  vmovaps [rsp+0xC0], xmm13
00007accb5bd18b2  vmovaps [rsp+0xD0], xmm14
00007accb5bd18bb  vmovaps [rsp+0xE0], xmm15
00007accb5bd18c4  sub rsp, 0x40
00007accb5bd18c8  lea rdi, [rsp]
00007accb5bd18cc  lea rsi, [rsp+0x10]
00007accb5bd18d1  lea rdx, [rsp+0x20]
00007accb5bd18d6  lea rcx, [rsp+0x30]
00007accb5bd18db  mov r8d, 0x00
00007accb5bd18e1  lea r9, [r15+0x3A8]
00007accb5bd18e8  movaps [rdi], xmm4
00007accb5bd18eb  movaps [rsi], xmm2
00007accb5bd18ee  movaps [rdx], xmm14
00007accb5bd18f2  movaps [rcx], xmm5
00007accb5bd18f5  mov rax, 0x59156B40DA50
00007accb5bd18ff  call rax
00007accb5bd1901  movaps xmm4, [rsp]
00007accb5bd1905  add rsp, 0x40
00007accb5bd1909  vmovaps xmm0, [rsp]
00007accb5bd190e  vmovaps xmm1, [rsp+0x10]
00007accb5bd1914  vmovaps xmm2, [rsp+0x20]
00007accb5bd191a  vmovaps xmm3, [rsp+0x30]
00007accb5bd1920  vmovaps xmm5, [rsp+0x40]
00007accb5bd1926  vmovaps xmm6, [rsp+0x50]
00007accb5bd192c  vmovaps xmm7, [rsp+0x60]
00007accb5bd1932  vmovaps xmm8, [rsp+0x70]
00007accb5bd1938  vmovaps xmm9, [rsp+0x80]
00007accb5bd1941  vmovaps xmm10, [rsp+0x90]
00007accb5bd194a  vmovaps xmm11, [rsp+0xA0]
00007accb5bd1953  vmovaps xmm12, [rsp+0xB0]
00007accb5bd195c  vmovaps xmm13, [rsp+0xC0]
00007accb5bd1965  vmovaps xmm14, [rsp+0xD0]
00007accb5bd196e  vmovaps xmm15, [rsp+0xE0]
00007accb5bd1977  add rsp, 0xF0
00007accb5bd197e  pop r11
00007accb5bd1980  pop r10
00007accb5bd1982  pop r9
00007accb5bd1984  pop r8
00007accb5bd1986  pop rsi
00007accb5bd1987  pop rdi
00007accb5bd1988  pop rdx
00007accb5bd1989  pop rcx
00007accb5bd198a  pop rax
00007accb5bd198b  add rsp, 0x08
00007accb5bd198f  jmp 0x00007ACCB5BCFC86
00007accb5bd1994  sub rsp, 0x08
00007accb5bd1998  push rax
00007accb5bd1999  push rcx
00007accb5bd199a  push rdx
00007accb5bd199b  push rdi
00007accb5bd199c  push rsi
00007accb5bd199d  push r8
00007accb5bd199f  push r9
00007accb5bd19a1  push r10
00007accb5bd19a3  push r11
00007accb5bd19a5  sub rsp, 0xF0
00007accb5bd19ac  vmovaps [rsp], xmm0
00007accb5bd19b1  vmovaps [rsp+0x10], xmm1
00007accb5bd19b7  vmovaps [rsp+0x20], xmm2
00007accb5bd19bd  vmovaps [rsp+0x30], xmm3
00007accb5bd19c3  vmovaps [rsp+0x40], xmm4
00007accb5bd19c9  vmovaps [rsp+0x50], xmm6
00007accb5bd19cf  vmovaps [rsp+0x60], xmm7
00007accb5bd19d5  vmovaps [rsp+0x70], xmm8
00007accb5bd19db  vmovaps [rsp+0x80], xmm9
00007accb5bd19e4  vmovaps [rsp+0x90], xmm10
00007accb5bd19ed  vmovaps [rsp+0xA0], xmm11
00007accb5bd19f6  vmovaps [rsp+0xB0], xmm12
00007accb5bd19ff  vmovaps [rsp+0xC0], xmm13
00007accb5bd1a08  vmovaps [rsp+0xD0], xmm14
00007accb5bd1a11  vmovaps [rsp+0xE0], xmm15
00007accb5bd1a1a  sub rsp, 0x40
00007accb5bd1a1e  lea rdi, [rsp]
00007accb5bd1a22  lea rsi, [rsp+0x10]
00007accb5bd1a27  lea rdx, [rsp+0x20]
00007accb5bd1a2c  lea rcx, [rsp+0x30]
00007accb5bd1a31  mov r8d, 0x00
00007accb5bd1a37  lea r9, [r15+0x3A8]
00007accb5bd1a3e  movaps [rdi], xmm5
00007accb5bd1a41  movaps [rsi], xmm8
00007accb5bd1a45  movaps [rdx], xmm7
00007accb5bd1a48  movaps [rcx], xmm14
00007accb5bd1a4c  mov rax, 0x59156B40DA50
00007accb5bd1a56  call rax
00007accb5bd1a58  movaps xmm5, [rsp]
00007accb5bd1a5c  add rsp, 0x40
00007accb5bd1a60  vmovaps xmm0, [rsp]
00007accb5bd1a65  vmovaps xmm1, [rsp+0x10]
00007accb5bd1a6b  vmovaps xmm2, [rsp+0x20]
00007accb5bd1a71  vmovaps xmm3, [rsp+0x30]
00007accb5bd1a77  vmovaps xmm4, [rsp+0x40]
00007accb5bd1a7d  vmovaps xmm6, [rsp+0x50]
00007accb5bd1a83  vmovaps xmm7, [rsp+0x60]
00007accb5bd1a89  vmovaps xmm8, [rsp+0x70]
00007accb5bd1a8f  vmovaps xmm9, [rsp+0x80]
00007accb5bd1a98  vmovaps xmm10, [rsp+0x90]
00007accb5bd1aa1  vmovaps xmm11, [rsp+0xA0]
00007accb5bd1aaa  vmovaps xmm12, [rsp+0xB0]
00007accb5bd1ab3  vmovaps xmm13, [rsp+0xC0]
00007accb5bd1abc  vmovaps xmm14, [rsp+0xD0]
00007accb5bd1ac5  vmovaps xmm15, [rsp+0xE0]
00007accb5bd1ace  add rsp, 0xF0
00007accb5bd1ad5  pop r11
00007accb5bd1ad7  pop r10
00007accb5bd1ad9  pop r9
00007accb5bd1adb  pop r8
00007accb5bd1add  pop rsi
00007accb5bd1ade  pop rdi
00007accb5bd1adf  pop rdx
00007accb5bd1ae0  pop rcx
00007accb5bd1ae1  pop rax
00007accb5bd1ae2  add rsp, 0x08
00007accb5bd1ae6  jmp 0x00007ACCB5BCFCAE
00007accb5bd1aeb  sub rsp, 0x08
00007accb5bd1aef  push rax
00007accb5bd1af0  push rcx
00007accb5bd1af1  push rdx
00007accb5bd1af2  push rdi
00007accb5bd1af3  push rsi
00007accb5bd1af4  push r8
00007accb5bd1af6  push r9
00007accb5bd1af8  push r10
00007accb5bd1afa  push r11
00007accb5bd1afc  sub rsp, 0xF0
00007accb5bd1b03  vmovaps [rsp], xmm0
00007accb5bd1b08  vmovaps [rsp+0x10], xmm1
00007accb5bd1b0e  vmovaps [rsp+0x20], xmm2
00007accb5bd1b14  vmovaps [rsp+0x30], xmm3
00007accb5bd1b1a  vmovaps [rsp+0x40], xmm4
00007accb5bd1b20  vmovaps [rsp+0x50], xmm5
00007accb5bd1b26  vmovaps [rsp+0x60], xmm6
00007accb5bd1b2c  vmovaps [rsp+0x70], xmm7
00007accb5bd1b32  vmovaps [rsp+0x80], xmm9
00007accb5bd1b3b  vmovaps [rsp+0x90], xmm10
00007accb5bd1b44  vmovaps [rsp+0xA0], xmm11
00007accb5bd1b4d  vmovaps [rsp+0xB0], xmm12
00007accb5bd1b56  vmovaps [rsp+0xC0], xmm13
00007accb5bd1b5f  vmovaps [rsp+0xD0], xmm14
00007accb5bd1b68  vmovaps [rsp+0xE0], xmm15
00007accb5bd1b71  sub rsp, 0x40
00007accb5bd1b75  lea rdi, [rsp]
00007accb5bd1b79  lea rsi, [rsp+0x10]
00007accb5bd1b7e  lea rdx, [rsp+0x20]
00007accb5bd1b83  lea rcx, [rsp+0x30]
00007accb5bd1b88  mov r8d, 0x00
00007accb5bd1b8e  lea r9, [r15+0x3A8]
00007accb5bd1b95  movaps [rdi], xmm8
00007accb5bd1b99  movaps [rsi], xmm13
00007accb5bd1b9d  movaps [rdx], xmm6
00007accb5bd1ba0  movaps [rcx], xmm14
00007accb5bd1ba4  mov rax, 0x59156B40DA50
00007accb5bd1bae  call rax
00007accb5bd1bb0  movaps xmm8, [rsp]
00007accb5bd1bb5  add rsp, 0x40
00007accb5bd1bb9  vmovaps xmm0, [rsp]
00007accb5bd1bbe  vmovaps xmm1, [rsp+0x10]
00007accb5bd1bc4  vmovaps xmm2, [rsp+0x20]
00007accb5bd1bca  vmovaps xmm3, [rsp+0x30]
00007accb5bd1bd0  vmovaps xmm4, [rsp+0x40]
00007accb5bd1bd6  vmovaps xmm5, [rsp+0x50]
00007accb5bd1bdc  vmovaps xmm6, [rsp+0x60]
00007accb5bd1be2  vmovaps xmm7, [rsp+0x70]
00007accb5bd1be8  vmovaps xmm9, [rsp+0x80]
00007accb5bd1bf1  vmovaps xmm10, [rsp+0x90]
00007accb5bd1bfa  vmovaps xmm11, [rsp+0xA0]
00007accb5bd1c03  vmovaps xmm12, [rsp+0xB0]
00007accb5bd1c0c  vmovaps xmm13, [rsp+0xC0]
00007accb5bd1c15  vmovaps xmm14, [rsp+0xD0]
00007accb5bd1c1e  vmovaps xmm15, [rsp+0xE0]
00007accb5bd1c27  add rsp, 0xF0
00007accb5bd1c2e  pop r11
00007accb5bd1c30  pop r10
00007accb5bd1c32  pop r9
00007accb5bd1c34  pop r8
00007accb5bd1c36  pop rsi
00007accb5bd1c37  pop rdi
00007accb5bd1c38  pop rdx
00007accb5bd1c39  pop rcx
00007accb5bd1c3a  pop rax
00007accb5bd1c3b  add rsp, 0x08
00007accb5bd1c3f  jmp 0x00007ACCB5BCFCD7
00007accb5bd1c44  sub rsp, 0x08
00007accb5bd1c48  push rax
00007accb5bd1c49  push rcx
00007accb5bd1c4a  push rdx
00007accb5bd1c4b  push rdi
00007accb5bd1c4c  push rsi
00007accb5bd1c4d  push r8
00007accb5bd1c4f  push r9
00007accb5bd1c51  push r10
00007accb5bd1c53  push r11
00007accb5bd1c55  sub rsp, 0xF0
00007accb5bd1c5c  vmovaps [rsp], xmm0
00007accb5bd1c61  vmovaps [rsp+0x10], xmm1
00007accb5bd1c67  vmovaps [rsp+0x20], xmm2
00007accb5bd1c6d  vmovaps [rsp+0x30], xmm3
00007accb5bd1c73  vmovaps [rsp+0x40], xmm4
00007accb5bd1c79  vmovaps [rsp+0x50], xmm5
00007accb5bd1c7f  vmovaps [rsp+0x60], xmm6
00007accb5bd1c85  vmovaps [rsp+0x70], xmm7
00007accb5bd1c8b  vmovaps [rsp+0x80], xmm8
00007accb5bd1c94  vmovaps [rsp+0x90], xmm9
00007accb5bd1c9d  vmovaps [rsp+0xA0], xmm10
00007accb5bd1ca6  vmovaps [rsp+0xB0], xmm11
00007accb5bd1caf  vmovaps [rsp+0xC0], xmm12
00007accb5bd1cb8  vmovaps [rsp+0xD0], xmm14
00007accb5bd1cc1  vmovaps [rsp+0xE0], xmm15
00007accb5bd1cca  sub rsp, 0x40
00007accb5bd1cce  lea rdi, [rsp]
00007accb5bd1cd2  lea rsi, [rsp+0x10]
00007accb5bd1cd7  lea rdx, [rsp+0x20]
00007accb5bd1cdc  lea rcx, [rsp+0x30]
00007accb5bd1ce1  mov r8d, 0x00
00007accb5bd1ce7  lea r9, [r15+0x3A8]
00007accb5bd1cee  movaps [rdi], xmm13
00007accb5bd1cf2  movaps [rsi], xmm11
00007accb5bd1cf6  movaps [rdx], xmm12
00007accb5bd1cfa  movaps [rcx], xmm14
00007accb5bd1cfe  mov rax, 0x59156B40DA50
00007accb5bd1d08  call rax
00007accb5bd1d0a  movaps xmm13, [rsp]
00007accb5bd1d0f  add rsp, 0x40
00007accb5bd1d13  vmovaps xmm0, [rsp]
00007accb5bd1d18  vmovaps xmm1, [rsp+0x10]
00007accb5bd1d1e  vmovaps xmm2, [rsp+0x20]
00007accb5bd1d24  vmovaps xmm3, [rsp+0x30]
00007accb5bd1d2a  vmovaps xmm4, [rsp+0x40]
00007accb5bd1d30  vmovaps xmm5, [rsp+0x50]
00007accb5bd1d36  vmovaps xmm6, [rsp+0x60]
00007accb5bd1d3c  vmovaps xmm7, [rsp+0x70]
00007accb5bd1d42  vmovaps xmm8, [rsp+0x80]
00007accb5bd1d4b  vmovaps xmm9, [rsp+0x90]
00007accb5bd1d54  vmovaps xmm10, [rsp+0xA0]
00007accb5bd1d5d  vmovaps xmm11, [rsp+0xB0]
00007accb5bd1d66  vmovaps xmm12, [rsp+0xC0]
00007accb5bd1d6f  vmovaps xmm14, [rsp+0xD0]
00007accb5bd1d78  vmovaps xmm15, [rsp+0xE0]
00007accb5bd1d81  add rsp, 0xF0
00007accb5bd1d88  pop r11
00007accb5bd1d8a  pop r10
00007accb5bd1d8c  pop r9
00007accb5bd1d8e  pop r8
00007accb5bd1d90  pop rsi
00007accb5bd1d91  pop rdi
00007accb5bd1d92  pop rdx
00007accb5bd1d93  pop rcx
00007accb5bd1d94  pop rax
00007accb5bd1d95  add rsp, 0x08
00007accb5bd1d99  jmp 0x00007ACCB5BCFD00
00007accb5bd1d9e  call 0x00007ACCB5A0D4E0
00007accb5bd1da3  jmp 0x00007ACCB5BCFD0A
00007accb5bd1da8  call 0x00007ACCB5A0AFE0
00007accb5bd1dad  jmp 0x00007ACCB5BCFD14
00007accb5bd1db2  sub rsp, 0x08
00007accb5bd1db6  push rax
00007accb5bd1db7  push rcx
00007accb5bd1db8  push rdx
00007accb5bd1db9  push rdi
00007accb5bd1dba  push rsi
00007accb5bd1dbb  push r8
00007accb5bd1dbd  push r9
00007accb5bd1dbf  push r10
00007accb5bd1dc1  push r11
00007accb5bd1dc3  sub rsp, 0xF0
00007accb5bd1dca  vmovaps [rsp], xmm0
00007accb5bd1dcf  vmovaps [rsp+0x10], xmm1
00007accb5bd1dd5  vmovaps [rsp+0x20], xmm2
00007accb5bd1ddb  vmovaps [rsp+0x30], xmm3
00007accb5bd1de1  vmovaps [rsp+0x40], xmm4
00007accb5bd1de7  vmovaps [rsp+0x50], xmm5
00007accb5bd1ded  vmovaps [rsp+0x60], xmm6
00007accb5bd1df3  vmovaps [rsp+0x70], xmm8
00007accb5bd1df9  vmovaps [rsp+0x80], xmm9
00007accb5bd1e02  vmovaps [rsp+0x90], xmm10
00007accb5bd1e0b  vmovaps [rsp+0xA0], xmm11
00007accb5bd1e14  vmovaps [rsp+0xB0], xmm12
00007accb5bd1e1d  vmovaps [rsp+0xC0], xmm13
00007accb5bd1e26  vmovaps [rsp+0xD0], xmm14
00007accb5bd1e2f  vmovaps [rsp+0xE0], xmm15
00007accb5bd1e38  sub rsp, 0x40
00007accb5bd1e3c  lea rdi, [rsp]
00007accb5bd1e40  lea rsi, [rsp+0x10]
00007accb5bd1e45  lea rdx, [rsp+0x20]
00007accb5bd1e4a  lea rcx, [rsp+0x30]
00007accb5bd1e4f  mov r8d, 0x00
00007accb5bd1e55  lea r9, [r15+0x3A8]
00007accb5bd1e5c  movaps [rdi], xmm7
00007accb5bd1e5f  movaps [rsi], xmm4
00007accb5bd1e62  movaps [rdx], xmm9
00007accb5bd1e66  movaps [rcx], xmm11
00007accb5bd1e6a  mov rax, 0x59156B40DA50
00007accb5bd1e74  call rax
00007accb5bd1e76  movaps xmm7, [rsp]
00007accb5bd1e7a  add rsp, 0x40
00007accb5bd1e7e  vmovaps xmm0, [rsp]
00007accb5bd1e83  vmovaps xmm1, [rsp+0x10]
00007accb5bd1e89  vmovaps xmm2, [rsp+0x20]
00007accb5bd1e8f  vmovaps xmm3, [rsp+0x30]
00007accb5bd1e95  vmovaps xmm4, [rsp+0x40]
00007accb5bd1e9b  vmovaps xmm5, [rsp+0x50]
00007accb5bd1ea1  vmovaps xmm6, [rsp+0x60]
00007accb5bd1ea7  vmovaps xmm8, [rsp+0x70]
00007accb5bd1ead  vmovaps xmm9, [rsp+0x80]
00007accb5bd1eb6  vmovaps xmm10, [rsp+0x90]
00007accb5bd1ebf  vmovaps xmm11, [rsp+0xA0]
00007accb5bd1ec8  vmovaps xmm12, [rsp+0xB0]
00007accb5bd1ed1  vmovaps xmm13, [rsp+0xC0]
00007accb5bd1eda  vmovaps xmm14, [rsp+0xD0]
00007accb5bd1ee3  vmovaps xmm15, [rsp+0xE0]
00007accb5bd1eec  add rsp, 0xF0
00007accb5bd1ef3  pop r11
00007accb5bd1ef5  pop r10
00007accb5bd1ef7  pop r9
00007accb5bd1ef9  pop r8
00007accb5bd1efb  pop rsi
00007accb5bd1efc  pop rdi
00007accb5bd1efd  pop rdx
00007accb5bd1efe  pop rcx
00007accb5bd1eff  pop rax
00007accb5bd1f00  add rsp, 0x08
00007accb5bd1f04  jmp 0x00007ACCB5BCFD4B
00007accb5bd1f09  sub rsp, 0x08
00007accb5bd1f0d  push rax
00007accb5bd1f0e  push rcx
00007accb5bd1f0f  push rdx
00007accb5bd1f10  push rdi
00007accb5bd1f11  push rsi
00007accb5bd1f12  push r8
00007accb5bd1f14  push r9
00007accb5bd1f16  push r10
00007accb5bd1f18  push r11
00007accb5bd1f1a  sub rsp, 0xF0
00007accb5bd1f21  vmovaps [rsp], xmm0
00007accb5bd1f26  vmovaps [rsp+0x10], xmm1
00007accb5bd1f2c  vmovaps [rsp+0x20], xmm2
00007accb5bd1f32  vmovaps [rsp+0x30], xmm3
00007accb5bd1f38  vmovaps [rsp+0x40], xmm4
00007accb5bd1f3e  vmovaps [rsp+0x50], xmm5
00007accb5bd1f44  vmovaps [rsp+0x60], xmm6
00007accb5bd1f4a  vmovaps [rsp+0x70], xmm7
00007accb5bd1f50  vmovaps [rsp+0x80], xmm8
00007accb5bd1f59  vmovaps [rsp+0x90], xmm10
00007accb5bd1f62  vmovaps [rsp+0xA0], xmm11
00007accb5bd1f6b  vmovaps [rsp+0xB0], xmm12
00007accb5bd1f74  vmovaps [rsp+0xC0], xmm13
00007accb5bd1f7d  vmovaps [rsp+0xD0], xmm14
00007accb5bd1f86  vmovaps [rsp+0xE0], xmm15
00007accb5bd1f8f  sub rsp, 0x40
00007accb5bd1f93  lea rdi, [rsp]
00007accb5bd1f97  lea rsi, [rsp+0x10]
00007accb5bd1f9c  lea rdx, [rsp+0x20]
00007accb5bd1fa1  lea rcx, [rsp+0x30]
00007accb5bd1fa6  mov r8d, 0x00
00007accb5bd1fac  lea r9, [r15+0x3A8]
00007accb5bd1fb3  movaps [rdi], xmm9
00007accb5bd1fb7  movaps [rsi], xmm5
00007accb5bd1fba  movaps [rdx], xmm14
00007accb5bd1fbe  movaps [rcx], xmm11
00007accb5bd1fc2  mov rax, 0x59156B40DA50
00007accb5bd1fcc  call rax
00007accb5bd1fce  movaps xmm9, [rsp]
00007accb5bd1fd3  add rsp, 0x40
00007accb5bd1fd7  vmovaps xmm0, [rsp]
00007accb5bd1fdc  vmovaps xmm1, [rsp+0x10]
00007accb5bd1fe2  vmovaps xmm2, [rsp+0x20]
00007accb5bd1fe8  vmovaps xmm3, [rsp+0x30]
00007accb5bd1fee  vmovaps xmm4, [rsp+0x40]
00007accb5bd1ff4  vmovaps xmm5, [rsp+0x50]
00007accb5bd1ffa  vmovaps xmm6, [rsp+0x60]
00007accb5bd2000  vmovaps xmm7, [rsp+0x70]
00007accb5bd2006  vmovaps xmm8, [rsp+0x80]
00007accb5bd200f  vmovaps xmm10, [rsp+0x90]
00007accb5bd2018  vmovaps xmm11, [rsp+0xA0]
00007accb5bd2021  vmovaps xmm12, [rsp+0xB0]
00007accb5bd202a  vmovaps xmm13, [rsp+0xC0]
00007accb5bd2033  vmovaps xmm14, [rsp+0xD0]
00007accb5bd203c  vmovaps xmm15, [rsp+0xE0]
00007accb5bd2045  add rsp, 0xF0
00007accb5bd204c  pop r11
00007accb5bd204e  pop r10
00007accb5bd2050  pop r9
00007accb5bd2052  pop r8
00007accb5bd2054  pop rsi
00007accb5bd2055  pop rdi
00007accb5bd2056  pop rdx
00007accb5bd2057  pop rcx
00007accb5bd2058  pop rax
00007accb5bd2059  add rsp, 0x08
00007accb5bd205d  jmp 0x00007ACCB5BCFD74
00007accb5bd2062  sub rsp, 0x08
00007accb5bd2066  push rax
00007accb5bd2067  push rcx
00007accb5bd2068  push rdx
00007accb5bd2069  push rdi
00007accb5bd206a  push rsi
00007accb5bd206b  push r8
00007accb5bd206d  push r9
00007accb5bd206f  push r10
00007accb5bd2071  push r11
00007accb5bd2073  sub rsp, 0xF0
00007accb5bd207a  vmovaps [rsp], xmm0
00007accb5bd207f  vmovaps [rsp+0x10], xmm1
00007accb5bd2085  vmovaps [rsp+0x20], xmm2
00007accb5bd208b  vmovaps [rsp+0x30], xmm3
00007accb5bd2091  vmovaps [rsp+0x40], xmm4
00007accb5bd2097  vmovaps [rsp+0x50], xmm5
00007accb5bd209d  vmovaps [rsp+0x60], xmm6
00007accb5bd20a3  vmovaps [rsp+0x70], xmm7
00007accb5bd20a9  vmovaps [rsp+0x80], xmm8
00007accb5bd20b2  vmovaps [rsp+0x90], xmm9
00007accb5bd20bb  vmovaps [rsp+0xA0], xmm10
00007accb5bd20c4  vmovaps [rsp+0xB0], xmm12
00007accb5bd20cd  vmovaps [rsp+0xC0], xmm13
00007accb5bd20d6  vmovaps [rsp+0xD0], xmm14
00007accb5bd20df  vmovaps [rsp+0xE0], xmm15
00007accb5bd20e8  sub rsp, 0x40
00007accb5bd20ec  lea rdi, [rsp]
00007accb5bd20f0  lea rsi, [rsp+0x10]
00007accb5bd20f5  lea rdx, [rsp+0x20]
00007accb5bd20fa  lea rcx, [rsp+0x30]
00007accb5bd20ff  mov r8d, 0x00
00007accb5bd2105  lea r9, [r15+0x3A8]
00007accb5bd210c  movaps [rdi], xmm11
00007accb5bd2110  movaps [rsi], xmm8
00007accb5bd2114  movaps [rdx], xmm10
00007accb5bd2118  movaps [rcx], xmm14
00007accb5bd211c  mov rax, 0x59156B40DA50
00007accb5bd2126  call rax
00007accb5bd2128  movaps xmm11, [rsp]
00007accb5bd212d  add rsp, 0x40
00007accb5bd2131  vmovaps xmm0, [rsp]
00007accb5bd2136  vmovaps xmm1, [rsp+0x10]
00007accb5bd213c  vmovaps xmm2, [rsp+0x20]
00007accb5bd2142  vmovaps xmm3, [rsp+0x30]
00007accb5bd2148  vmovaps xmm4, [rsp+0x40]
00007accb5bd214e  vmovaps xmm5, [rsp+0x50]
00007accb5bd2154  vmovaps xmm6, [rsp+0x60]
00007accb5bd215a  vmovaps xmm7, [rsp+0x70]
00007accb5bd2160  vmovaps xmm8, [rsp+0x80]
00007accb5bd2169  vmovaps xmm9, [rsp+0x90]
00007accb5bd2172  vmovaps xmm10, [rsp+0xA0]
00007accb5bd217b  vmovaps xmm12, [rsp+0xB0]
00007accb5bd2184  vmovaps xmm13, [rsp+0xC0]
00007accb5bd218d  vmovaps xmm14, [rsp+0xD0]
00007accb5bd2196  vmovaps xmm15, [rsp+0xE0]
00007accb5bd219f  add rsp, 0xF0
00007accb5bd21a6  pop r11
00007accb5bd21a8  pop r10
00007accb5bd21aa  pop r9
00007accb5bd21ac  pop r8
00007accb5bd21ae  pop rsi
00007accb5bd21af  pop rdi
00007accb5bd21b0  pop rdx
00007accb5bd21b1  pop rcx
00007accb5bd21b2  pop rax
00007accb5bd21b3  add rsp, 0x08
00007accb5bd21b7  jmp 0x00007ACCB5BCFD9D
00007accb5bd21bc  sub rsp, 0x08
00007accb5bd21c0  push rax
00007accb5bd21c1  push rcx
00007accb5bd21c2  push rdx
00007accb5bd21c3  push rdi
00007accb5bd21c4  push rsi
00007accb5bd21c5  push r8
00007accb5bd21c7  push r9
00007accb5bd21c9  push r10
00007accb5bd21cb  push r11
00007accb5bd21cd  sub rsp, 0xF0
00007accb5bd21d4  vmovaps [rsp], xmm0
00007accb5bd21d9  vmovaps [rsp+0x10], xmm1
00007accb5bd21df  vmovaps [rsp+0x20], xmm2
00007accb5bd21e5  vmovaps [rsp+0x30], xmm3
00007accb5bd21eb  vmovaps [rsp+0x40], xmm4
00007accb5bd21f1  vmovaps [rsp+0x50], xmm5
00007accb5bd21f7  vmovaps [rsp+0x60], xmm6
00007accb5bd21fd  vmovaps [rsp+0x70], xmm7
00007accb5bd2203  vmovaps [rsp+0x80], xmm8
00007accb5bd220c  vmovaps [rsp+0x90], xmm9
00007accb5bd2215  vmovaps [rsp+0xA0], xmm11
00007accb5bd221e  vmovaps [rsp+0xB0], xmm12
00007accb5bd2227  vmovaps [rsp+0xC0], xmm13
00007accb5bd2230  vmovaps [rsp+0xD0], xmm14
00007accb5bd2239  vmovaps [rsp+0xE0], xmm15
00007accb5bd2242  sub rsp, 0x40
00007accb5bd2246  lea rdi, [rsp]
00007accb5bd224a  lea rsi, [rsp+0x10]
00007accb5bd224f  lea rdx, [rsp+0x20]
00007accb5bd2254  lea rcx, [rsp+0x30]
00007accb5bd2259  mov r8d, 0x00
00007accb5bd225f  lea r9, [r15+0x3A8]
00007accb5bd2266  movaps [rdi], xmm10
00007accb5bd226a  movaps [rsi], xmm13
00007accb5bd226e  movaps [rdx], xmm15
00007accb5bd2272  movaps [rcx], xmm14
00007accb5bd2276  mov rax, 0x59156B40DA50
00007accb5bd2280  call rax
00007accb5bd2282  movaps xmm10, [rsp]
00007accb5bd2287  add rsp, 0x40
00007accb5bd228b  vmovaps xmm0, [rsp]
00007accb5bd2290  vmovaps xmm1, [rsp+0x10]
00007accb5bd2296  vmovaps xmm2, [rsp+0x20]
00007accb5bd229c  vmovaps xmm3, [rsp+0x30]
00007accb5bd22a2  vmovaps xmm4, [rsp+0x40]
00007accb5bd22a8  vmovaps xmm5, [rsp+0x50]
00007accb5bd22ae  vmovaps xmm6, [rsp+0x60]
00007accb5bd22b4  vmovaps xmm7, [rsp+0x70]
00007accb5bd22ba  vmovaps xmm8, [rsp+0x80]
00007accb5bd22c3  vmovaps xmm9, [rsp+0x90]
00007accb5bd22cc  vmovaps xmm11, [rsp+0xA0]
00007accb5bd22d5  vmovaps xmm12, [rsp+0xB0]
00007accb5bd22de  vmovaps xmm13, [rsp+0xC0]
00007accb5bd22e7  vmovaps xmm14, [rsp+0xD0]
00007accb5bd22f0  vmovaps xmm15, [rsp+0xE0]
00007accb5bd22f9  add rsp, 0xF0
00007accb5bd2300  pop r11
00007accb5bd2302  pop r10
00007accb5bd2304  pop r9
00007accb5bd2306  pop r8
00007accb5bd2308  pop rsi
00007accb5bd2309  pop rdi
00007accb5bd230a  pop rdx
00007accb5bd230b  pop rcx
00007accb5bd230c  pop rax
00007accb5bd230d  add rsp, 0x08
00007accb5bd2311  jmp 0x00007ACCB5BCFDC6
00007accb5bd2316  call 0x00007ACCB5A0E760
00007accb5bd231b  jmp 0x00007ACCB5BCFDD0
00007accb5bd2320  call 0x00007ACCB5A0D4E0
00007accb5bd2325  jmp 0x00007ACCB5BCFDDA
00007accb5bd232a  sub rsp, 0x08
00007accb5bd232e  push rax
00007accb5bd232f  push rcx
00007accb5bd2330  push rdx
00007accb5bd2331  push rdi
00007accb5bd2332  push rsi
00007accb5bd2333  push r8
00007accb5bd2335  push r9
00007accb5bd2337  push r10
00007accb5bd2339  push r11
00007accb5bd233b  sub rsp, 0xF0
00007accb5bd2342  vmovaps [rsp], xmm0
00007accb5bd2347  vmovaps [rsp+0x10], xmm1
00007accb5bd234d  vmovaps [rsp+0x20], xmm2
00007accb5bd2353  vmovaps [rsp+0x30], xmm3
00007accb5bd2359  vmovaps [rsp+0x40], xmm4
00007accb5bd235f  vmovaps [rsp+0x50], xmm5
00007accb5bd2365  vmovaps [rsp+0x60], xmm7
00007accb5bd236b  vmovaps [rsp+0x70], xmm8
00007accb5bd2371  vmovaps [rsp+0x80], xmm9
00007accb5bd237a  vmovaps [rsp+0x90], xmm10
00007accb5bd2383  vmovaps [rsp+0xA0], xmm11
00007accb5bd238c  vmovaps [rsp+0xB0], xmm12
00007accb5bd2395  vmovaps [rsp+0xC0], xmm13
00007accb5bd239e  vmovaps [rsp+0xD0], xmm14
00007accb5bd23a7  vmovaps [rsp+0xE0], xmm15
00007accb5bd23b0  sub rsp, 0x40
00007accb5bd23b4  lea rdi, [rsp]
00007accb5bd23b8  lea rsi, [rsp+0x10]
00007accb5bd23bd  lea rdx, [rsp+0x20]
00007accb5bd23c2  lea rcx, [rsp+0x30]
00007accb5bd23c7  mov r8d, 0x00
00007accb5bd23cd  lea r9, [r15+0x3A8]
00007accb5bd23d4  movaps [rdi], xmm6
00007accb5bd23d7  movaps [rsi], xmm7
00007accb5bd23da  movaps [rdx], xmm8
00007accb5bd23de  movaps [rcx], xmm13
00007accb5bd23e2  mov rax, 0x59156B40DA50
00007accb5bd23ec  call rax
00007accb5bd23ee  movaps xmm6, [rsp]
00007accb5bd23f2  add rsp, 0x40
00007accb5bd23f6  vmovaps xmm0, [rsp]
00007accb5bd23fb  vmovaps xmm1, [rsp+0x10]
00007accb5bd2401  vmovaps xmm2, [rsp+0x20]
00007accb5bd2407  vmovaps xmm3, [rsp+0x30]
00007accb5bd240d  vmovaps xmm4, [rsp+0x40]
00007accb5bd2413  vmovaps xmm5, [rsp+0x50]
00007accb5bd2419  vmovaps xmm7, [rsp+0x60]
00007accb5bd241f  vmovaps xmm8, [rsp+0x70]
00007accb5bd2425  vmovaps xmm9, [rsp+0x80]
00007accb5bd242e  vmovaps xmm10, [rsp+0x90]
00007accb5bd2437  vmovaps xmm11, [rsp+0xA0]
00007accb5bd2440  vmovaps xmm12, [rsp+0xB0]
00007accb5bd2449  vmovaps xmm13, [rsp+0xC0]
00007accb5bd2452  vmovaps xmm14, [rsp+0xD0]
00007accb5bd245b  vmovaps xmm15, [rsp+0xE0]
00007accb5bd2464  add rsp, 0xF0
00007accb5bd246b  pop r11
00007accb5bd246d  pop r10
00007accb5bd246f  pop r9
00007accb5bd2471  pop r8
00007accb5bd2473  pop rsi
00007accb5bd2474  pop rdi
00007accb5bd2475  pop rdx
00007accb5bd2476  pop rcx
00007accb5bd2477  pop rax
00007accb5bd2478  add rsp, 0x08
00007accb5bd247c  jmp 0x00007ACCB5BCFE04
00007accb5bd2481  sub rsp, 0x08
00007accb5bd2485  push rax
00007accb5bd2486  push rcx
00007accb5bd2487  push rdx
00007accb5bd2488  push rdi
00007accb5bd2489  push rsi
00007accb5bd248a  push r8
00007accb5bd248c  push r9
00007accb5bd248e  push r10
00007accb5bd2490  push r11
00007accb5bd2492  sub rsp, 0xF0
00007accb5bd2499  vmovaps [rsp], xmm0
00007accb5bd249e  vmovaps [rsp+0x10], xmm1
00007accb5bd24a4  vmovaps [rsp+0x20], xmm2
00007accb5bd24aa  vmovaps [rsp+0x30], xmm3
00007accb5bd24b0  vmovaps [rsp+0x40], xmm4
00007accb5bd24b6  vmovaps [rsp+0x50], xmm5
00007accb5bd24bc  vmovaps [rsp+0x60], xmm6
00007accb5bd24c2  vmovaps [rsp+0x70], xmm7
00007accb5bd24c8  vmovaps [rsp+0x80], xmm9
00007accb5bd24d1  vmovaps [rsp+0x90], xmm10
00007accb5bd24da  vmovaps [rsp+0xA0], xmm11
00007accb5bd24e3  vmovaps [rsp+0xB0], xmm12
00007accb5bd24ec  vmovaps [rsp+0xC0], xmm13
00007accb5bd24f5  vmovaps [rsp+0xD0], xmm14
00007accb5bd24fe  vmovaps [rsp+0xE0], xmm15
00007accb5bd2507  sub rsp, 0x40
00007accb5bd250b  lea rdi, [rsp]
00007accb5bd250f  lea rsi, [rsp+0x10]
00007accb5bd2514  lea rdx, [rsp+0x20]
00007accb5bd2519  lea rcx, [rsp+0x30]
00007accb5bd251e  mov r8d, 0x00
00007accb5bd2524  lea r9, [r15+0x3A8]
00007accb5bd252b  movaps [rdi], xmm8
00007accb5bd252f  movaps [rsi], xmm9
00007accb5bd2533  movaps [rdx], xmm1
00007accb5bd2536  movaps [rcx], xmm13
00007accb5bd253a  mov rax, 0x59156B40DA50
00007accb5bd2544  call rax
00007accb5bd2546  movaps xmm8, [rsp]
00007accb5bd254b  add rsp, 0x40
00007accb5bd254f  vmovaps xmm0, [rsp]
00007accb5bd2554  vmovaps xmm1, [rsp+0x10]
00007accb5bd255a  vmovaps xmm2, [rsp+0x20]
00007accb5bd2560  vmovaps xmm3, [rsp+0x30]
00007accb5bd2566  vmovaps xmm4, [rsp+0x40]
00007accb5bd256c  vmovaps xmm5, [rsp+0x50]
00007accb5bd2572  vmovaps xmm6, [rsp+0x60]
00007accb5bd2578  vmovaps xmm7, [rsp+0x70]
00007accb5bd257e  vmovaps xmm9, [rsp+0x80]
00007accb5bd2587  vmovaps xmm10, [rsp+0x90]
00007accb5bd2590  vmovaps xmm11, [rsp+0xA0]
00007accb5bd2599  vmovaps xmm12, [rsp+0xB0]
00007accb5bd25a2  vmovaps xmm13, [rsp+0xC0]
00007accb5bd25ab  vmovaps xmm14, [rsp+0xD0]
00007accb5bd25b4  vmovaps xmm15, [rsp+0xE0]
00007accb5bd25bd  add rsp, 0xF0
00007accb5bd25c4  pop r11
00007accb5bd25c6  pop r10
00007accb5bd25c8  pop r9
00007accb5bd25ca  pop r8
00007accb5bd25cc  pop rsi
00007accb5bd25cd  pop rdi
00007accb5bd25ce  pop rdx
00007accb5bd25cf  pop rcx
00007accb5bd25d0  pop rax
00007accb5bd25d1  add rsp, 0x08
00007accb5bd25d5  jmp 0x00007ACCB5BCFE2A
00007accb5bd25da  sub rsp, 0x08
00007accb5bd25de  push rax
00007accb5bd25df  push rcx
00007accb5bd25e0  push rdx
00007accb5bd25e1  push rdi
00007accb5bd25e2  push rsi
00007accb5bd25e3  push r8
00007accb5bd25e5  push r9
00007accb5bd25e7  push r10
00007accb5bd25e9  push r11
00007accb5bd25eb  sub rsp, 0xF0
00007accb5bd25f2  vmovaps [rsp], xmm0
00007accb5bd25f7  vmovaps [rsp+0x10], xmm1
00007accb5bd25fd  vmovaps [rsp+0x20], xmm2
00007accb5bd2603  vmovaps [rsp+0x30], xmm3
00007accb5bd2609  vmovaps [rsp+0x40], xmm4
00007accb5bd260f  vmovaps [rsp+0x50], xmm5
00007accb5bd2615  vmovaps [rsp+0x60], xmm6
00007accb5bd261b  vmovaps [rsp+0x70], xmm7
00007accb5bd2621  vmovaps [rsp+0x80], xmm8
00007accb5bd262a  vmovaps [rsp+0x90], xmm9
00007accb5bd2633  vmovaps [rsp+0xA0], xmm10
00007accb5bd263c  vmovaps [rsp+0xB0], xmm11
00007accb5bd2645  vmovaps [rsp+0xC0], xmm12
00007accb5bd264e  vmovaps [rsp+0xD0], xmm14
00007accb5bd2657  vmovaps [rsp+0xE0], xmm15
00007accb5bd2660  sub rsp, 0x40
00007accb5bd2664  lea rdi, [rsp]
00007accb5bd2668  lea rsi, [rsp+0x10]
00007accb5bd266d  lea rdx, [rsp+0x20]
00007accb5bd2672  lea rcx, [rsp+0x30]
00007accb5bd2677  mov r8d, 0x00
00007accb5bd267d  lea r9, [r15+0x3A8]
00007accb5bd2684  movaps [rdi], xmm13
00007accb5bd2688  movaps [rsi], xmm11
00007accb5bd268c  movaps [rdx], xmm12
00007accb5bd2690  movaps [rcx], xmm1
00007accb5bd2693  mov rax, 0x59156B40DA50
00007accb5bd269d  call rax
00007accb5bd269f  movaps xmm13, [rsp]
00007accb5bd26a4  add rsp, 0x40
00007accb5bd26a8  vmovaps xmm0, [rsp]
00007accb5bd26ad  vmovaps xmm1, [rsp+0x10]
00007accb5bd26b3  vmovaps xmm2, [rsp+0x20]
00007accb5bd26b9  vmovaps xmm3, [rsp+0x30]
00007accb5bd26bf  vmovaps xmm4, [rsp+0x40]
00007accb5bd26c5  vmovaps xmm5, [rsp+0x50]
00007accb5bd26cb  vmovaps xmm6, [rsp+0x60]
00007accb5bd26d1  vmovaps xmm7, [rsp+0x70]
00007accb5bd26d7  vmovaps xmm8, [rsp+0x80]
00007accb5bd26e0  vmovaps xmm9, [rsp+0x90]
00007accb5bd26e9  vmovaps xmm10, [rsp+0xA0]
00007accb5bd26f2  vmovaps xmm11, [rsp+0xB0]
00007accb5bd26fb  vmovaps xmm12, [rsp+0xC0]
00007accb5bd2704  vmovaps xmm14, [rsp+0xD0]
00007accb5bd270d  vmovaps xmm15, [rsp+0xE0]
00007accb5bd2716  add rsp, 0xF0
00007accb5bd271d  pop r11
00007accb5bd271f  pop r10
00007accb5bd2721  pop r9
00007accb5bd2723  pop r8
00007accb5bd2725  pop rsi
00007accb5bd2726  pop rdi
00007accb5bd2727  pop rdx
00007accb5bd2728  pop rcx
00007accb5bd2729  pop rax
00007accb5bd272a  add rsp, 0x08
00007accb5bd272e  jmp 0x00007ACCB5BCFE50
00007accb5bd2733  sub rsp, 0x08
00007accb5bd2737  push rax
00007accb5bd2738  push rcx
00007accb5bd2739  push rdx
00007accb5bd273a  push rdi
00007accb5bd273b  push rsi
00007accb5bd273c  push r8
00007accb5bd273e  push r9
00007accb5bd2740  push r10
00007accb5bd2742  push r11
00007accb5bd2744  sub rsp, 0xF0
00007accb5bd274b  vmovaps [rsp], xmm0
00007accb5bd2750  vmovaps [rsp+0x10], xmm1
00007accb5bd2756  vmovaps [rsp+0x20], xmm2
00007accb5bd275c  vmovaps [rsp+0x30], xmm3
00007accb5bd2762  vmovaps [rsp+0x40], xmm4
00007accb5bd2768  vmovaps [rsp+0x50], xmm5
00007accb5bd276e  vmovaps [rsp+0x60], xmm6
00007accb5bd2774  vmovaps [rsp+0x70], xmm7
00007accb5bd277a  vmovaps [rsp+0x80], xmm8
00007accb5bd2783  vmovaps [rsp+0x90], xmm9
00007accb5bd278c  vmovaps [rsp+0xA0], xmm10
00007accb5bd2795  vmovaps [rsp+0xB0], xmm11
00007accb5bd279e  vmovaps [rsp+0xC0], xmm13
00007accb5bd27a7  vmovaps [rsp+0xD0], xmm14
00007accb5bd27b0  vmovaps [rsp+0xE0], xmm15
00007accb5bd27b9  sub rsp, 0x40
00007accb5bd27bd  lea rdi, [rsp]
00007accb5bd27c1  lea rsi, [rsp+0x10]
00007accb5bd27c6  lea rdx, [rsp+0x20]
00007accb5bd27cb  lea rcx, [rsp+0x30]
00007accb5bd27d0  mov r8d, 0x00
00007accb5bd27d6  lea r9, [r15+0x3A8]
00007accb5bd27dd  movaps [rdi], xmm12
00007accb5bd27e1  movaps [rsi], xmm10
00007accb5bd27e5  movaps [rdx], xmm14
00007accb5bd27e9  movaps [rcx], xmm1
00007accb5bd27ec  mov rax, 0x59156B40DA50
00007accb5bd27f6  call rax
00007accb5bd27f8  movaps xmm12, [rsp]
00007accb5bd27fd  add rsp, 0x40
00007accb5bd2801  vmovaps xmm0, [rsp]
00007accb5bd2806  vmovaps xmm1, [rsp+0x10]
00007accb5bd280c  vmovaps xmm2, [rsp+0x20]
00007accb5bd2812  vmovaps xmm3, [rsp+0x30]
00007accb5bd2818  vmovaps xmm4, [rsp+0x40]
00007accb5bd281e  vmovaps xmm5, [rsp+0x50]
00007accb5bd2824  vmovaps xmm6, [rsp+0x60]
00007accb5bd282a  vmovaps xmm7, [rsp+0x70]
00007accb5bd2830  vmovaps xmm8, [rsp+0x80]
00007accb5bd2839  vmovaps xmm9, [rsp+0x90]
00007accb5bd2842  vmovaps xmm10, [rsp+0xA0]
00007accb5bd284b  vmovaps xmm11, [rsp+0xB0]
00007accb5bd2854  vmovaps xmm13, [rsp+0xC0]
00007accb5bd285d  vmovaps xmm14, [rsp+0xD0]
00007accb5bd2866  vmovaps xmm15, [rsp+0xE0]
00007accb5bd286f  add rsp, 0xF0
00007accb5bd2876  pop r11
00007accb5bd2878  pop r10
00007accb5bd287a  pop r9
00007accb5bd287c  pop r8
00007accb5bd287e  pop rsi
00007accb5bd287f  pop rdi
00007accb5bd2880  pop rdx
00007accb5bd2881  pop rcx
00007accb5bd2882  pop rax
00007accb5bd2883  add rsp, 0x08
00007accb5bd2887  jmp 0x00007ACCB5BCFE76
00007accb5bd288c  call 0x00007ACCB59FF430
00007accb5bd2891  jmp 0x00007ACCB5BCFE83
00007accb5bd2896  call 0x00007ACCB5A0D4E0
00007accb5bd289b  jmp 0x00007ACCB5BCFE90
00007accb5bd28a0  sub rsp, 0x08
00007accb5bd28a4  push rax
00007accb5bd28a5  push rcx
00007accb5bd28a6  push rdx
00007accb5bd28a7  push rdi
00007accb5bd28a8  push rsi
00007accb5bd28a9  push r8
00007accb5bd28ab  push r9
00007accb5bd28ad  push r10
00007accb5bd28af  push r11
00007accb5bd28b1  sub rsp, 0xF0
00007accb5bd28b8  vmovaps [rsp], xmm0
00007accb5bd28bd  vmovaps [rsp+0x10], xmm1
00007accb5bd28c3  vmovaps [rsp+0x20], xmm2
00007accb5bd28c9  vmovaps [rsp+0x30], xmm3
00007accb5bd28cf  vmovaps [rsp+0x40], xmm4
00007accb5bd28d5  vmovaps [rsp+0x50], xmm5
00007accb5bd28db  vmovaps [rsp+0x60], xmm6
00007accb5bd28e1  vmovaps [rsp+0x70], xmm7
00007accb5bd28e7  vmovaps [rsp+0x80], xmm8
00007accb5bd28f0  vmovaps [rsp+0x90], xmm9
00007accb5bd28f9  vmovaps [rsp+0xA0], xmm11
00007accb5bd2902  vmovaps [rsp+0xB0], xmm12
00007accb5bd290b  vmovaps [rsp+0xC0], xmm13
00007accb5bd2914  vmovaps [rsp+0xD0], xmm14
00007accb5bd291d  vmovaps [rsp+0xE0], xmm15
00007accb5bd2926  sub rsp, 0x40
00007accb5bd292a  lea rdi, [rsp]
00007accb5bd292e  lea rsi, [rsp+0x10]
00007accb5bd2933  lea rdx, [rsp+0x20]
00007accb5bd2938  lea rcx, [rsp+0x30]
00007accb5bd293d  mov r8d, 0x00
00007accb5bd2943  lea r9, [r15+0x3A8]
00007accb5bd294a  movaps [rdi], xmm10
00007accb5bd294e  movaps [rsi], xmm6
00007accb5bd2951  movaps [rdx], xmm15
00007accb5bd2955  movaps [rcx], xmm11
00007accb5bd2959  mov rax, 0x59156B40DA50
00007accb5bd2963  call rax
00007accb5bd2965  movaps xmm10, [rsp]
00007accb5bd296a  add rsp, 0x40
00007accb5bd296e  vmovaps xmm0, [rsp]
00007accb5bd2973  vmovaps xmm1, [rsp+0x10]
00007accb5bd2979  vmovaps xmm2, [rsp+0x20]
00007accb5bd297f  vmovaps xmm3, [rsp+0x30]
00007accb5bd2985  vmovaps xmm4, [rsp+0x40]
00007accb5bd298b  vmovaps xmm5, [rsp+0x50]
00007accb5bd2991  vmovaps xmm6, [rsp+0x60]
00007accb5bd2997  vmovaps xmm7, [rsp+0x70]
00007accb5bd299d  vmovaps xmm8, [rsp+0x80]
00007accb5bd29a6  vmovaps xmm9, [rsp+0x90]
00007accb5bd29af  vmovaps xmm11, [rsp+0xA0]
00007accb5bd29b8  vmovaps xmm12, [rsp+0xB0]
00007accb5bd29c1  vmovaps xmm13, [rsp+0xC0]
00007accb5bd29ca  vmovaps xmm14, [rsp+0xD0]
00007accb5bd29d3  vmovaps xmm15, [rsp+0xE0]
00007accb5bd29dc  add rsp, 0xF0
00007accb5bd29e3  pop r11
00007accb5bd29e5  pop r10
00007accb5bd29e7  pop r9
00007accb5bd29e9  pop r8
00007accb5bd29eb  pop rsi
00007accb5bd29ec  pop rdi
00007accb5bd29ed  pop rdx
00007accb5bd29ee  pop rcx
00007accb5bd29ef  pop rax
00007accb5bd29f0  add rsp, 0x08
00007accb5bd29f4  jmp 0x00007ACCB5BCFEC9
00007accb5bd29f9  call 0x00007ACCB5A0E760
00007accb5bd29fe  jmp 0x00007ACCB5BCFEDB
00007accb5bd2a03  sub rsp, 0x08
00007accb5bd2a07  push rax
00007accb5bd2a08  push rcx
00007accb5bd2a09  push rdx
00007accb5bd2a0a  push rdi
00007accb5bd2a0b  push rsi
00007accb5bd2a0c  push r8
00007accb5bd2a0e  push r9
00007accb5bd2a10  push r10
00007accb5bd2a12  push r11
00007accb5bd2a14  sub rsp, 0xF0
00007accb5bd2a1b  vmovaps [rsp], xmm0
00007accb5bd2a20  vmovaps [rsp+0x10], xmm1
00007accb5bd2a26  vmovaps [rsp+0x20], xmm2
00007accb5bd2a2c  vmovaps [rsp+0x30], xmm3
00007accb5bd2a32  vmovaps [rsp+0x40], xmm4
00007accb5bd2a38  vmovaps [rsp+0x50], xmm5
00007accb5bd2a3e  vmovaps [rsp+0x60], xmm6
00007accb5bd2a44  vmovaps [rsp+0x70], xmm7
00007accb5bd2a4a  vmovaps [rsp+0x80], xmm8
00007accb5bd2a53  vmovaps [rsp+0x90], xmm10
00007accb5bd2a5c  vmovaps [rsp+0xA0], xmm11
00007accb5bd2a65  vmovaps [rsp+0xB0], xmm12
00007accb5bd2a6e  vmovaps [rsp+0xC0], xmm13
00007accb5bd2a77  vmovaps [rsp+0xD0], xmm14
00007accb5bd2a80  vmovaps [rsp+0xE0], xmm15
00007accb5bd2a89  sub rsp, 0x40
00007accb5bd2a8d  lea rdi, [rsp]
00007accb5bd2a91  lea rsi, [rsp+0x10]
00007accb5bd2a96  lea rdx, [rsp+0x20]
00007accb5bd2a9b  lea rcx, [rsp+0x30]
00007accb5bd2aa0  mov r8d, 0x00
00007accb5bd2aa6  lea r9, [r15+0x3A8]
00007accb5bd2aad  movaps [rdi], xmm9
00007accb5bd2ab1  movaps [rsi], xmm8
00007accb5bd2ab5  movaps [rdx], xmm14
00007accb5bd2ab9  movaps [rcx], xmm11
00007accb5bd2abd  mov rax, 0x59156B40DA50
00007accb5bd2ac7  call rax
00007accb5bd2ac9  movaps xmm9, [rsp]
00007accb5bd2ace  add rsp, 0x40
00007accb5bd2ad2  vmovaps xmm0, [rsp]
00007accb5bd2ad7  vmovaps xmm1, [rsp+0x10]
00007accb5bd2add  vmovaps xmm2, [rsp+0x20]
00007accb5bd2ae3  vmovaps xmm3, [rsp+0x30]
00007accb5bd2ae9  vmovaps xmm4, [rsp+0x40]
00007accb5bd2aef  vmovaps xmm5, [rsp+0x50]
00007accb5bd2af5  vmovaps xmm6, [rsp+0x60]
00007accb5bd2afb  vmovaps xmm7, [rsp+0x70]
00007accb5bd2b01  vmovaps xmm8, [rsp+0x80]
00007accb5bd2b0a  vmovaps xmm10, [rsp+0x90]
00007accb5bd2b13  vmovaps xmm11, [rsp+0xA0]
00007accb5bd2b1c  vmovaps xmm12, [rsp+0xB0]
00007accb5bd2b25  vmovaps xmm13, [rsp+0xC0]
00007accb5bd2b2e  vmovaps xmm14, [rsp+0xD0]
00007accb5bd2b37  vmovaps xmm15, [rsp+0xE0]
00007accb5bd2b40  add rsp, 0xF0
00007accb5bd2b47  pop r11
00007accb5bd2b49  pop r10
00007accb5bd2b4b  pop r9
00007accb5bd2b4d  pop r8
00007accb5bd2b4f  pop rsi
00007accb5bd2b50  pop rdi
00007accb5bd2b51  pop rdx
00007accb5bd2b52  pop rcx
00007accb5bd2b53  pop rax
00007accb5bd2b54  add rsp, 0x08
00007accb5bd2b58  jmp 0x00007ACCB5BCFF0C
00007accb5bd2b5d  sub rsp, 0x08
00007accb5bd2b61  push rax
00007accb5bd2b62  push rcx
00007accb5bd2b63  push rdx
00007accb5bd2b64  push rdi
00007accb5bd2b65  push rsi
00007accb5bd2b66  push r8
00007accb5bd2b68  push r9
00007accb5bd2b6a  push r10
00007accb5bd2b6c  push r11
00007accb5bd2b6e  sub rsp, 0xF0
00007accb5bd2b75  vmovaps [rsp], xmm0
00007accb5bd2b7a  vmovaps [rsp+0x10], xmm1
00007accb5bd2b80  vmovaps [rsp+0x20], xmm2
00007accb5bd2b86  vmovaps [rsp+0x30], xmm3
00007accb5bd2b8c  vmovaps [rsp+0x40], xmm4
00007accb5bd2b92  vmovaps [rsp+0x50], xmm5
00007accb5bd2b98  vmovaps [rsp+0x60], xmm6
00007accb5bd2b9e  vmovaps [rsp+0x70], xmm7
00007accb5bd2ba4  vmovaps [rsp+0x80], xmm8
00007accb5bd2bad  vmovaps [rsp+0x90], xmm9
00007accb5bd2bb6  vmovaps [rsp+0xA0], xmm10
00007accb5bd2bbf  vmovaps [rsp+0xB0], xmm12
00007accb5bd2bc8  vmovaps [rsp+0xC0], xmm13
00007accb5bd2bd1  vmovaps [rsp+0xD0], xmm14
00007accb5bd2bda  vmovaps [rsp+0xE0], xmm15
00007accb5bd2be3  sub rsp, 0x40
00007accb5bd2be7  lea rdi, [rsp]
00007accb5bd2beb  lea rsi, [rsp+0x10]
00007accb5bd2bf0  lea rdx, [rsp+0x20]
00007accb5bd2bf5  lea rcx, [rsp+0x30]
00007accb5bd2bfa  mov r8d, 0x00
00007accb5bd2c00  lea r9, [r15+0x3A8]
00007accb5bd2c07  movaps [rdi], xmm11
00007accb5bd2c0b  movaps [rsi], xmm13
00007accb5bd2c0f  movaps [rdx], xmm1
00007accb5bd2c12  movaps [rcx], xmm14
00007accb5bd2c16  mov rax, 0x59156B40DA50
00007accb5bd2c20  call rax
00007accb5bd2c22  movaps xmm11, [rsp]
00007accb5bd2c27  add rsp, 0x40
00007accb5bd2c2b  vmovaps xmm0, [rsp]
00007accb5bd2c30  vmovaps xmm1, [rsp+0x10]
00007accb5bd2c36  vmovaps xmm2, [rsp+0x20]
00007accb5bd2c3c  vmovaps xmm3, [rsp+0x30]
00007accb5bd2c42  vmovaps xmm4, [rsp+0x40]
00007accb5bd2c48  vmovaps xmm5, [rsp+0x50]
00007accb5bd2c4e  vmovaps xmm6, [rsp+0x60]
00007accb5bd2c54  vmovaps xmm7, [rsp+0x70]
00007accb5bd2c5a  vmovaps xmm8, [rsp+0x80]
00007accb5bd2c63  vmovaps xmm9, [rsp+0x90]
00007accb5bd2c6c  vmovaps xmm10, [rsp+0xA0]
00007accb5bd2c75  vmovaps xmm12, [rsp+0xB0]
00007accb5bd2c7e  vmovaps xmm13, [rsp+0xC0]
00007accb5bd2c87  vmovaps xmm14, [rsp+0xD0]
00007accb5bd2c90  vmovaps xmm15, [rsp+0xE0]
00007accb5bd2c99  add rsp, 0xF0
00007accb5bd2ca0  pop r11
00007accb5bd2ca2  pop r10
00007accb5bd2ca4  pop r9
00007accb5bd2ca6  pop r8
00007accb5bd2ca8  pop rsi
00007accb5bd2ca9  pop rdi
00007accb5bd2caa  pop rdx
00007accb5bd2cab  pop rcx
00007accb5bd2cac  pop rax
00007accb5bd2cad  add rsp, 0x08
00007accb5bd2cb1  jmp 0x00007ACCB5BCFF3D
00007accb5bd2cb6  sub rsp, 0x08
00007accb5bd2cba  push rax
00007accb5bd2cbb  push rcx
00007accb5bd2cbc  push rdx
00007accb5bd2cbd  push rdi
00007accb5bd2cbe  push rsi
00007accb5bd2cbf  push r8
00007accb5bd2cc1  push r9
00007accb5bd2cc3  push r10
00007accb5bd2cc5  push r11
00007accb5bd2cc7  sub rsp, 0xF0
00007accb5bd2cce  vmovaps [rsp], xmm0
00007accb5bd2cd3  vmovaps [rsp+0x10], xmm1
00007accb5bd2cd9  vmovaps [rsp+0x20], xmm2
00007accb5bd2cdf  vmovaps [rsp+0x30], xmm3
00007accb5bd2ce5  vmovaps [rsp+0x40], xmm4
00007accb5bd2ceb  vmovaps [rsp+0x50], xmm5
00007accb5bd2cf1  vmovaps [rsp+0x60], xmm6
00007accb5bd2cf7  vmovaps [rsp+0x70], xmm7
00007accb5bd2cfd  vmovaps [rsp+0x80], xmm8
00007accb5bd2d06  vmovaps [rsp+0x90], xmm9
00007accb5bd2d0f  vmovaps [rsp+0xA0], xmm10
00007accb5bd2d18  vmovaps [rsp+0xB0], xmm11
00007accb5bd2d21  vmovaps [rsp+0xC0], xmm12
00007accb5bd2d2a  vmovaps [rsp+0xD0], xmm13
00007accb5bd2d33  vmovaps [rsp+0xE0], xmm15
00007accb5bd2d3c  sub rsp, 0x40
00007accb5bd2d40  lea rdi, [rsp]
00007accb5bd2d44  lea rsi, [rsp+0x10]
00007accb5bd2d49  lea rdx, [rsp+0x20]
00007accb5bd2d4e  lea rcx, [rsp+0x30]
00007accb5bd2d53  mov r8d, 0x00
00007accb5bd2d59  lea r9, [r15+0x3A8]
00007accb5bd2d60  movaps [rdi], xmm14
00007accb5bd2d64  movaps [rsi], xmm12
00007accb5bd2d68  movaps [rdx], xmm15
00007accb5bd2d6c  movaps [rcx], xmm1
00007accb5bd2d6f  mov rax, 0x59156B40DA50
00007accb5bd2d79  call rax
00007accb5bd2d7b  movaps xmm14, [rsp]
00007accb5bd2d80  add rsp, 0x40
00007accb5bd2d84  vmovaps xmm0, [rsp]
00007accb5bd2d89  vmovaps xmm1, [rsp+0x10]
00007accb5bd2d8f  vmovaps xmm2, [rsp+0x20]
00007accb5bd2d95  vmovaps xmm3, [rsp+0x30]
00007accb5bd2d9b  vmovaps xmm4, [rsp+0x40]
00007accb5bd2da1  vmovaps xmm5, [rsp+0x50]
00007accb5bd2da7  vmovaps xmm6, [rsp+0x60]
00007accb5bd2dad  vmovaps xmm7, [rsp+0x70]
00007accb5bd2db3  vmovaps xmm8, [rsp+0x80]
00007accb5bd2dbc  vmovaps xmm9, [rsp+0x90]
00007accb5bd2dc5  vmovaps xmm10, [rsp+0xA0]
00007accb5bd2dce  vmovaps xmm11, [rsp+0xB0]
00007accb5bd2dd7  vmovaps xmm12, [rsp+0xC0]
00007accb5bd2de0  vmovaps xmm13, [rsp+0xD0]
00007accb5bd2de9  vmovaps xmm15, [rsp+0xE0]
00007accb5bd2df2  add rsp, 0xF0
00007accb5bd2df9  pop r11
00007accb5bd2dfb  pop r10
00007accb5bd2dfd  pop r9
00007accb5bd2dff  pop r8
00007accb5bd2e01  pop rsi
00007accb5bd2e02  pop rdi
00007accb5bd2e03  pop rdx
00007accb5bd2e04  pop rcx
00007accb5bd2e05  pop rax
00007accb5bd2e06  add rsp, 0x08
00007accb5bd2e0a  jmp 0x00007ACCB5BCFF6E
00007accb5bd2e0f  call 0x00007ACCB5A079B0
00007accb5bd2e14  jmp 0x00007ACCB5BCFF81
00007accb5bd2e19  call 0x00007ACCB5A09E90
00007accb5bd2e1e  jmp 0x00007ACCB5BCFF8C
00007accb5bd2e23  call 0x00007ACCB5A08C20
00007accb5bd2e28  jmp 0x00007ACCB5BCFF97
00007accb5bd2e2d  call 0x00007ACCB5A0D600
00007accb5bd2e32  jmp 0x00007ACCB5BCFFA2
00007accb5bd2e37  int3
00007accb5bd2e38  nop [rax+rax*1], eax
00007accb5bd2e40  mov rax, [r15+0x40]
00007accb5bd2e44  mov r14, [r15+0x58]
00007accb5bd2e48  lea r12, [rax+r14*1]
00007accb5bd2e4c  vxorps xmm1, xmm1, xmm1
00007accb5bd2e50  vpbroadcastq xmm1, xmm1
00007accb5bd2e55  vxorps xmm15, xmm15, xmm15
00007accb5bd2e5a  vpbroadcastq xmm15, xmm15
00007accb5bd2e5f  lea rax, [r12+0x30]
00007accb5bd2e64  mov r11, [r13+rax*1]
00007accb5bd2e69  lea rax, [r12+0x38]
00007accb5bd2e6e  mov r10, [r13+rax*1]
00007accb5bd2e73  movq xmm14, r11
00007accb5bd2e78  movq xmm13, r10
00007accb5bd2e7d  movq xmm14, xmm14
00007accb5bd2e82  movq xmm13, xmm13
00007accb5bd2e87  vmovaps [rsp+0x10], xmm13
00007accb5bd2e8d  movq xmm13, xmm13
00007accb5bd2e92  movaps [r15+0x270], xmm13
00007accb5bd2e9a  movaps xmm13, [r15+0x160]
00007accb5bd2ea2  vmovaps [rsp+0x20], xmm13
00007accb5bd2ea8  vmovaps xmm12, [rsp+0x20]
00007accb5bd2eae  por xmm13, xmm12
00007accb5bd2eb3  lea rax, [r12+0x20]
00007accb5bd2eb8  mov r11, [r13+rax*1]
00007accb5bd2ebd  lea rax, [r12+0x28]
00007accb5bd2ec2  mov r10, [r13+rax*1]
00007accb5bd2ec7  movq xmm12, r11
00007accb5bd2ecc  movq xmm11, r10
00007accb5bd2ed1  movq xmm12, xmm12
00007accb5bd2ed6  movq xmm11, xmm11
00007accb5bd2edb  movaps xmm10, [r15+0x2F0]
00007accb5bd2ee3  vmovaps [rsp+0x20], xmm10
00007accb5bd2ee9  vmovaps xmm9, [rsp+0x20]
00007accb5bd2eef  por xmm10, xmm9
00007accb5bd2ef4  movaps xmm9, [r15+0x2D0]
00007accb5bd2efc  vmovaps [rsp+0x20], xmm9
00007accb5bd2f02  vmovaps xmm8, [rsp+0x20]
00007accb5bd2f08  por xmm9, xmm8
00007accb5bd2f0d  movaps xmm8, [r15+0x300]
00007accb5bd2f15  vmovaps [rsp+0x20], xmm8
00007accb5bd2f1b  vmovaps xmm7, [rsp+0x20]
00007accb5bd2f21  por xmm8, xmm7
00007accb5bd2f26  movaps xmm7, [r15+0x2B0]
00007accb5bd2f2e  vmovaps [rsp+0x20], xmm7
00007accb5bd2f34  vmovaps xmm6, [rsp+0x20]
00007accb5bd2f3a  por xmm7, xmm6
00007accb5bd2f3e  movaps xmm6, [r15+0x180]
00007accb5bd2f46  vmovaps [rsp+0x20], xmm6
00007accb5bd2f4c  vmovaps xmm5, [rsp+0x20]
00007accb5bd2f52  por xmm6, xmm5
00007accb5bd2f56  lea rax, [r12+0x10]
00007accb5bd2f5b  mov r11, [r13+rax*1]
00007accb5bd2f60  lea rax, [r12+0x18]
00007accb5bd2f65  mov r10, [r13+rax*1]
00007accb5bd2f6a  movq xmm5, r11
00007accb5bd2f6f  movq xmm4, r10
00007accb5bd2f74  movq xmm5, xmm5
00007accb5bd2f78  movq xmm4, xmm4
00007accb5bd2f7c  movaps xmm3, [r15+0x200]
00007accb5bd2f84  vmovaps [rsp+0x20], xmm3
00007accb5bd2f8a  vmovaps xmm2, [rsp+0x20]
00007accb5bd2f90  por xmm3, xmm2
00007accb5bd2f94  movaps xmm2, [r15+0x1F0]
00007accb5bd2f9c  vmovaps [rsp+0x20], xmm2
00007accb5bd2fa2  vmovaps [rsp+0x30], xmm1
00007accb5bd2fa8  vmovaps xmm1, [rsp+0x20]
00007accb5bd2fae  por xmm2, xmm1
00007accb5bd2fb2  movaps xmm1, [r15+0x2E0]
00007accb5bd2fba  vmovaps [rsp+0x20], xmm1
00007accb5bd2fc0  vmovaps [rsp+0x40], xmm15
00007accb5bd2fc6  vmovaps xmm15, [rsp+0x20]
00007accb5bd2fcc  por xmm1, xmm15
00007accb5bd2fd1  movaps xmm15, [r15+0x2A0]
00007accb5bd2fd9  vmovaps [rsp+0x20], xmm15
00007accb5bd2fdf  vmovaps [rsp+0x50], xmm1
00007accb5bd2fe5  vmovaps xmm1, [rsp+0x20]
00007accb5bd2feb  por xmm15, xmm1
00007accb5bd2ff0  movaps xmm1, [r15+0x280]
00007accb5bd2ff8  vmovaps [rsp+0x20], xmm1
00007accb5bd2ffe  vmovaps [rsp+0x60], xmm15
00007accb5bd3004  vmovaps xmm15, [rsp+0x20]
00007accb5bd300a  por xmm1, xmm15
00007accb5bd300f  movaps xmm15, [r15+0x1C0]
00007accb5bd3017  vmovaps [rsp+0x20], xmm15
00007accb5bd301d  vmovaps [rsp+0x70], xmm1
00007accb5bd3023  vmovaps xmm1, [rsp+0x20]
00007accb5bd3029  por xmm15, xmm1
00007accb5bd302e  movaps xmm1, [r15+0x210]
00007accb5bd3036  vmovaps [rsp+0x20], xmm1
00007accb5bd303c  vmovaps [rsp+0x80], xmm15
00007accb5bd3045  vmovaps xmm15, [rsp+0x20]
00007accb5bd304b  por xmm1, xmm15
00007accb5bd3050  mov rax, [r13+r12*1]
00007accb5bd3055  vmovq xmm15, rax
00007accb5bd305a  vpbroadcastq xmm15, xmm15
00007accb5bd305f  vmovaps [rsp+0x20], xmm1
00007accb5bd3065  vxorps xmm1, xmm1, xmm1
00007accb5bd3069  vpbroadcastq xmm1, xmm1
00007accb5bd306e  mov rax, [r15+0xF8]
00007accb5bd3075  vmovaps [rsp+0x90], xmm1
00007accb5bd307e  movups xmm1, [r13+rax*1]
00007accb5bd3084  vmovaps [rsp+0xA0], xmm1
00007accb5bd308d  vxorps xmm1, xmm1, xmm1
00007accb5bd3091  vpbroadcastq xmm1, xmm1
00007accb5bd3096  lea r11, [r12+0x08]
00007accb5bd309b  mov r12, [r13+r11*1]
00007accb5bd30a0  vmovaps [rsp+0xB0], xmm1
00007accb5bd30a9  movq xmm1, r12
00007accb5bd30ae  movaps [r15+0x240], xmm1
00007accb5bd30b6  mov r12, [r15+0x50]
00007accb5bd30ba  lea r11, [r12+r14*1]
00007accb5bd30be  mov [r15+0x60], r11
00007accb5bd30c2  lea r12, [r14+0x40]
00007accb5bd30c6  mov [r15+0x58], r12
00007accb5bd30ca  vmovaps xmm1, [rsp+0x30]
00007accb5bd30d0  vmovaps [rsp+0x30], xmm15
00007accb5bd30d6  vmovaps xmm15, [rsp+0xA0]
00007accb5bd30df  vmovaps [rsp+0xA0], xmm14
00007accb5bd30e8  vmovaps xmm14, [rsp+0x30]
00007accb5bd30ee  vmovaps [rsp+0x30], xmm13
00007accb5bd30f4  vmovaps [rsp+0xC0], xmm12
00007accb5bd30fd  movaps xmm13, xmm1
00007accb5bd3101  vfmadd231pd xmm13, xmm15, xmm14
00007accb5bd3106  vcmppd xmm12, xmm13, xmm13, 0x03
00007accb5bd310c  vptest xmm12, xmm12
00007accb5bd3111  jnz 0x00007ACCB5BD3BEA
00007accb5bd3117  movaps xmm1, [r15+0x250]
00007accb5bd311f  vmovaps xmm15, [rsp+0x40]
00007accb5bd3125  vmovaps [rsp+0x40], xmm13
00007accb5bd312b  movaps xmm12, xmm15
00007accb5bd312f  vfmadd231pd xmm12, xmm1, xmm14
00007accb5bd3134  vcmppd xmm13, xmm12, xmm12, 0x03
00007accb5bd313a  vptest xmm13, xmm13
00007accb5bd313f  jnz 0x00007ACCB5BD3D43
00007accb5bd3145  movaps xmm15, [r15+0x1E0]
00007accb5bd314d  vmovaps [rsp+0xD0], xmm15
00007accb5bd3156  vmovaps xmm13, [rsp+0xD0]
00007accb5bd315f  por xmm15, xmm13
00007accb5bd3164  movaps xmm13, [r15+0x1D0]
00007accb5bd316c  vmovaps [rsp+0xD0], xmm13
00007accb5bd3175  vmovaps [rsp+0xE0], xmm1
00007accb5bd317e  vmovaps xmm1, [rsp+0xD0]
00007accb5bd3187  por xmm13, xmm1
00007accb5bd318c  movaps xmm1, [r15+0x2C0]
00007accb5bd3194  vmovaps [rsp+0xD0], xmm1
00007accb5bd319d  vmovaps [rsp+0xF0], xmm15
00007accb5bd31a6  vmovaps xmm15, [rsp+0xD0]
00007accb5bd31af  por xmm1, xmm15
00007accb5bd31b4  movaps xmm15, [r15+0x290]
00007accb5bd31bc  vmovaps [rsp+0xD0], xmm15
00007accb5bd31c5  vmovaps [rsp+0x100], xmm1
00007accb5bd31ce  vmovaps xmm1, [rsp+0xD0]
00007accb5bd31d7  por xmm15, xmm1
00007accb5bd31dc  movaps xmm1, [r15+0x260]
00007accb5bd31e4  vmovaps [rsp+0xD0], xmm1
00007accb5bd31ed  vmovaps [rsp+0x110], xmm15
00007accb5bd31f6  vmovaps xmm15, [rsp+0xD0]
00007accb5bd31ff  por xmm1, xmm15
00007accb5bd3204  vmovaps xmm15, [rsp+0xE0]
00007accb5bd320d  vmovaps [rsp+0xD0], xmm1
00007accb5bd3216  vmovaps xmm1, [rsp+0xE0]
00007accb5bd321f  por xmm15, xmm1
00007accb5bd3224  lea r14, [rax+0xC0]
00007accb5bd322b  movups xmm1, [r13+r14*1]
00007accb5bd3231  mov [rsp+0xE0], rax
00007accb5bd3239  xor eax, eax
00007accb5bd323b  mov r14d, 0x200
00007accb5bd3241  cmp r12, r14
00007accb5bd3244  cmc
00007accb5bd3245  lahf
00007accb5bd3246  seto al
00007accb5bd3249  mov [r15+0x108], eax
00007accb5bd3250  vmovaps [rsp+0x120], xmm1
00007accb5bd3259  vmovaps xmm1, [rsp+0x90]
00007accb5bd3262  vmovaps [rsp+0x90], xmm15
00007accb5bd326b  vmovaps xmm15, [rsp+0x120]
00007accb5bd3274  vmovaps [rsp+0x120], xmm13
00007accb5bd327d  vmovaps [rsp+0x130], xmm12
00007accb5bd3286  movaps xmm13, xmm1
00007accb5bd328a  vfmadd231pd xmm13, xmm15, xmm14
00007accb5bd328f  vcmppd xmm12, xmm13, xmm13, 0x03
00007accb5bd3295  vptest xmm12, xmm12
00007accb5bd329a  jnz 0x00007ACCB5BD3EA6
00007accb5bd32a0  mov rax, [rsp+0xE0]
00007accb5bd32a8  lea r14, [rax+0xB0]
00007accb5bd32af  movups xmm1, [r13+r14*1]
00007accb5bd32b5  vmovaps xmm15, [rsp+0xB0]
00007accb5bd32be  vmovaps [rsp+0xB0], xmm13
00007accb5bd32c7  movaps xmm12, xmm15
00007accb5bd32cb  vfmadd231pd xmm12, xmm1, xmm14
00007accb5bd32d0  vcmppd xmm13, xmm12, xmm12, 0x03
00007accb5bd32d6  vptest xmm13, xmm13
00007accb5bd32db  jnz 0x00007ACCB5BD4009
00007accb5bd32e1  vmovaps xmm1, [rsp+0x20]
00007accb5bd32e7  vmovaps xmm15, [rsp+0x20]
00007accb5bd32ed  por xmm1, xmm15
00007accb5bd32f2  movaps [r15+0x210], xmm1
00007accb5bd32fa  vmovaps xmm15, [rsp+0x80]
00007accb5bd3303  vmovaps xmm14, [rsp+0x80]
00007accb5bd330c  por xmm15, xmm14
00007accb5bd3311  movaps [r15+0x1C0], xmm15
00007accb5bd3319  vmovaps xmm14, [rsp+0x70]
00007accb5bd331f  vmovaps xmm13, [rsp+0x70]
00007accb5bd3325  por xmm14, xmm13
00007accb5bd332a  movaps [r15+0x280], xmm14
00007accb5bd3332  vmovaps xmm13, [rsp+0x60]
00007accb5bd3338  vmovaps [rsp+0x20], xmm1
00007accb5bd333e  vmovaps xmm1, [rsp+0x60]
00007accb5bd3344  por xmm13, xmm1
00007accb5bd3349  movaps [r15+0x2A0], xmm13
00007accb5bd3351  vmovaps xmm1, [rsp+0x50]
00007accb5bd3357  vmovaps [rsp+0x60], xmm15
00007accb5bd335d  vmovaps xmm15, [rsp+0x50]
00007accb5bd3363  por xmm1, xmm15
00007accb5bd3368  movaps [r15+0x2E0], xmm1
00007accb5bd3370  vmovaps [rsp+0x50], xmm2
00007accb5bd3376  vmovaps xmm15, [rsp+0x50]
00007accb5bd337c  por xmm2, xmm15
00007accb5bd3381  movaps [r15+0x1F0], xmm2
00007accb5bd3389  vmovaps xmm15, [rsp+0x90]
00007accb5bd3392  vmovaps [rsp+0x50], xmm1
00007accb5bd3398  vmovaps xmm1, [rsp+0x90]
00007accb5bd33a1  por xmm15, xmm1
00007accb5bd33a6  movaps [r15+0x250], xmm15
00007accb5bd33ae  vmovaps xmm1, [rsp+0xD0]
00007accb5bd33b7  vmovaps xmm15, [rsp+0xD0]
00007accb5bd33c0  por xmm1, xmm15
00007accb5bd33c5  movaps [r15+0x260], xmm1
00007accb5bd33cd  vmovaps xmm15, [rsp+0x110]
00007accb5bd33d6  vmovaps [rsp+0x70], xmm1
00007accb5bd33dc  vmovaps xmm1, [rsp+0x110]
00007accb5bd33e5  por xmm15, xmm1
00007accb5bd33ea  movaps [r15+0x290], xmm15
00007accb5bd33f2  vmovaps xmm1, [rsp+0x100]
00007accb5bd33fb  vmovaps [rsp+0x80], xmm15
00007accb5bd3404  vmovaps xmm15, [rsp+0x100]
00007accb5bd340d  por xmm1, xmm15
00007accb5bd3412  movaps [r15+0x2C0], xmm1
00007accb5bd341a  movq xmm15, qword ptr [r15+0x240]
00007accb5bd3423  vmovaps [rsp+0x90], xmm15
00007accb5bd342c  vpermilpd xmm15, xmm15, 0x00
00007accb5bd3432  vmovaps [rsp+0xD0], xmm1
00007accb5bd343b  vmovaps xmm1, [rsp+0x40]
00007accb5bd3441  vmovaps [rsp+0x40], xmm15
00007accb5bd3447  vmovaps xmm15, [rsp+0x20]
00007accb5bd344d  vmovaps [rsp+0x20], xmm14
00007accb5bd3453  vmovaps xmm14, [rsp+0x40]
00007accb5bd3459  vmovaps [rsp+0x40], xmm13
00007accb5bd345f  vmovaps [rsp+0xE0], xmm12
00007accb5bd3468  movaps xmm13, xmm1
00007accb5bd346c  vfmadd231pd xmm13, xmm15, xmm14
00007accb5bd3471  vcmppd xmm12, xmm13, xmm13, 0x03
00007accb5bd3477  vptest xmm12, xmm12
00007accb5bd347c  jnz 0x00007ACCB5BD4162
00007accb5bd3482  vmovaps xmm1, [rsp+0x90]
00007accb5bd348b  vpermilpd xmm1, xmm1, 0x00
00007accb5bd3491  vmovaps xmm15, [rsp+0xB0]
00007accb5bd349a  vmovaps xmm14, [rsp+0x50]
00007accb5bd34a0  vmovaps [rsp+0x50], xmm13
00007accb5bd34a6  movaps xmm12, xmm15
00007accb5bd34aa  vfmadd231pd xmm12, xmm14, xmm1
00007accb5bd34af  vcmppd xmm13, xmm12, xmm12, 0x03
00007accb5bd34b5  vptest xmm13, xmm13
00007accb5bd34ba  jnz 0x00007ACCB5BD42BB
00007accb5bd34c0  vmovaps xmm1, [rsp+0x90]
00007accb5bd34c9  vpermilpd xmm1, xmm1, 0x00
00007accb5bd34cf  vmovaps xmm15, [rsp+0x130]
00007accb5bd34d8  vmovaps xmm14, [rsp+0x60]
00007accb5bd34de  vmovaps [rsp+0x60], xmm12
00007accb5bd34e4  movaps xmm13, xmm15
00007accb5bd34e8  vfmadd231pd xmm13, xmm14, xmm1
00007accb5bd34ed  vcmppd xmm12, xmm13, xmm13, 0x03
00007accb5bd34f3  vptest xmm12, xmm12
00007accb5bd34f8  jnz 0x00007ACCB5BD4414
00007accb5bd34fe  vmovaps xmm1, [rsp+0x120]
00007accb5bd3507  vmovaps xmm15, [rsp+0x120]
00007accb5bd3510  por xmm1, xmm15
00007accb5bd3515  movaps [r15+0x1D0], xmm1
00007accb5bd351d  vmovaps xmm15, [rsp+0x90]
00007accb5bd3526  vpermilpd xmm15, xmm15, 0x00
00007accb5bd352c  vmovaps xmm14, [rsp+0xE0]
00007accb5bd3535  vmovaps [rsp+0x90], xmm1
00007accb5bd353e  movaps xmm12, xmm14
00007accb5bd3542  vfmadd231pd xmm12, xmm2, xmm15
00007accb5bd3547  vcmppd xmm1, xmm12, xmm12, 0x03
00007accb5bd354d  vptest xmm1, xmm1
00007accb5bd3552  jnz 0x00007ACCB5BD456D
00007accb5bd3558  vmovaps [rsp+0xB0], xmm3
00007accb5bd3561  vmovaps xmm1, [rsp+0xB0]
00007accb5bd356a  por xmm3, xmm1
00007accb5bd356e  movaps [r15+0x200], xmm3
00007accb5bd3576  vmovaps xmm1, [rsp+0xF0]
00007accb5bd357f  vmovaps xmm15, [rsp+0xF0]
00007accb5bd3588  por xmm1, xmm15
00007accb5bd358d  movaps [r15+0x1E0], xmm1
00007accb5bd3595  vmovaps [rsp+0xB0], xmm7
00007accb5bd359e  vmovaps xmm1, [rsp+0xB0]
00007accb5bd35a7  por xmm7, xmm1
00007accb5bd35ab  movaps [r15+0x2B0], xmm7
00007accb5bd35b3  vmovaps [rsp+0xB0], xmm8
00007accb5bd35bc  vmovaps xmm1, [rsp+0xB0]
00007accb5bd35c5  por xmm8, xmm1
00007accb5bd35ca  movaps [r15+0x300], xmm8
00007accb5bd35d2  vmovaps [rsp+0xB0], xmm5
00007accb5bd35db  vpermilpd xmm5, xmm5, 0x00
00007accb5bd35e1  vmovaps xmm14, [rsp+0x50]
00007accb5bd35e7  vmovaps xmm8, [rsp+0x70]
00007accb5bd35ed  vmovaps [rsp+0x50], xmm1
00007accb5bd35f3  movaps xmm2, xmm14
00007accb5bd35f7  vfmadd231pd xmm2, xmm8, xmm5
00007accb5bd35fc  vcmppd xmm1, xmm2, xmm2, 0x03
00007accb5bd3601  vptest xmm1, xmm1
00007accb5bd3606  jnz 0x00007ACCB5BD46C6
00007accb5bd360c  vmovaps xmm1, [rsp+0xB0]
00007accb5bd3615  vpermilpd xmm1, xmm1, 0x00
00007accb5bd361b  vmovaps xmm14, [rsp+0x60]
00007accb5bd3621  vmovaps xmm8, [rsp+0xD0]
00007accb5bd362a  vmovaps [rsp+0x60], xmm15
00007accb5bd3630  movaps xmm5, xmm14
00007accb5bd3634  vfmadd231pd xmm5, xmm8, xmm1
00007accb5bd3639  vcmppd xmm15, xmm5, xmm5, 0x03
00007accb5bd363e  vptest xmm15, xmm15
00007accb5bd3643  jnz 0x00007ACCB5BD481D
00007accb5bd3649  vmovaps xmm1, [rsp+0xB0]
00007accb5bd3652  vpermilpd xmm1, xmm1, 0x00
00007accb5bd3658  vmovaps xmm14, [rsp+0x20]
00007accb5bd365e  movaps xmm15, xmm13
00007accb5bd3662  vfmadd231pd xmm15, xmm14, xmm1
00007accb5bd3667  vcmppd xmm8, xmm15, xmm15, 0x03
00007accb5bd366d  vptest xmm8, xmm8
00007accb5bd3672  jnz 0x00007ACCB5BD4974
00007accb5bd3678  vmovaps xmm1, [rsp+0xB0]
00007accb5bd3681  vpermilpd xmm1, xmm1, 0x00
00007accb5bd3687  vmovaps xmm14, [rsp+0x90]
00007accb5bd3690  movaps xmm13, xmm12
00007accb5bd3694  vfmadd231pd xmm13, xmm14, xmm1
00007accb5bd3699  vcmppd xmm8, xmm13, xmm13, 0x03
00007accb5bd369f  vptest xmm8, xmm8
00007accb5bd36a4  jnz 0x00007ACCB5BD4ACD
00007accb5bd36aa  vmovaps [rsp+0x20], xmm6
00007accb5bd36b0  vmovaps xmm1, [rsp+0x20]
00007accb5bd36b6  por xmm6, xmm1
00007accb5bd36ba  movaps [r15+0x180], xmm6
00007accb5bd36c2  vmovaps [rsp+0x20], xmm9
00007accb5bd36c8  vmovaps xmm1, [rsp+0x20]
00007accb5bd36ce  por xmm9, xmm1
00007accb5bd36d3  movaps [r15+0x2D0], xmm9
00007accb5bd36db  vmovaps [rsp+0x20], xmm10
00007accb5bd36e1  vmovaps xmm1, [rsp+0x20]
00007accb5bd36e7  por xmm10, xmm1
00007accb5bd36ec  movaps [r15+0x2F0], xmm10
00007accb5bd36f4  vmovaps [rsp+0x20], xmm4
00007accb5bd36fa  vpermilpd xmm4, xmm4, 0x00
00007accb5bd3700  vmovaps xmm14, [rsp+0x50]
00007accb5bd3706  movaps xmm12, xmm5
00007accb5bd370a  vfmadd231pd xmm12, xmm14, xmm4
00007accb5bd370f  vcmppd xmm10, xmm12, xmm12, 0x03
00007accb5bd3715  vptest xmm10, xmm10
00007accb5bd371a  jnz 0x00007ACCB5BD4C26
00007accb5bd3720  vmovaps xmm14, [rsp+0x20]
00007accb5bd3726  vpermilpd xmm14, xmm14, 0x00
00007accb5bd372c  movaps xmm10, xmm2
00007accb5bd3730  vfmadd231pd xmm10, xmm6, xmm14
00007accb5bd3735  vcmppd xmm8, xmm10, xmm10, 0x03
00007accb5bd373b  vptest xmm8, xmm8
00007accb5bd3740  jnz 0x00007ACCB5BD4D7E
00007accb5bd3746  lea r14, [rax+0x80]
00007accb5bd374d  movups xmm14, [r13+r14*1]
00007accb5bd3753  movaps [r15+0x190], xmm14
00007accb5bd375b  vmovaps xmm8, [rsp+0x20]
00007accb5bd3761  vpermilpd xmm8, xmm8, 0x00
00007accb5bd3767  vmovaps xmm6, [rsp+0x80]
00007accb5bd3770  movaps xmm5, xmm15
00007accb5bd3774  vfmadd231pd xmm5, xmm6, xmm8
00007accb5bd3779  vcmppd xmm4, xmm5, xmm5, 0x03
00007accb5bd377e  vptest xmm4, xmm4
00007accb5bd3783  jnz 0x00007ACCB5BD4EE0
00007accb5bd3789  vmovaps xmm15, [rsp+0x20]
00007accb5bd378f  vpermilpd xmm15, xmm15, 0x00
00007accb5bd3795  movaps xmm8, xmm13
00007accb5bd3799  vfmadd231pd xmm8, xmm1, xmm15
00007accb5bd379e  vcmppd xmm6, xmm8, xmm8, 0x03
00007accb5bd37a4  vptest xmm6, xmm6
00007accb5bd37a9  jnz 0x00007ACCB5BD5037
00007accb5bd37af  vmovaps xmm1, [rsp+0x30]
00007accb5bd37b5  vmovaps xmm15, [rsp+0x30]
00007accb5bd37bb  por xmm1, xmm15
00007accb5bd37c0  movaps [r15+0x160], xmm1
00007accb5bd37c8  lea r14, [rax+0x40]
00007accb5bd37cc  movups xmm15, [r13+r14*1]
00007accb5bd37d2  lea r14, [rax+0x50]
00007accb5bd37d6  movups xmm13, [r13+r14*1]
00007accb5bd37dc  movaps [r15+0x1B0], xmm15
00007accb5bd37e4  movaps [r15+0x1A0], xmm13
00007accb5bd37ec  vmovaps xmm6, [rsp+0xC0]
00007accb5bd37f5  vpermilpd xmm6, xmm6, 0x00
00007accb5bd37fb  movaps xmm4, xmm12
00007accb5bd37ff  vfmadd231pd xmm4, xmm9, xmm6
00007accb5bd3804  vcmppd xmm2, xmm4, xmm4, 0x03
00007accb5bd3809  vptest xmm2, xmm2
00007accb5bd380e  jnz 0x00007ACCB5BD51A4
00007accb5bd3814  vmovaps xmm12, [rsp+0xC0]
00007accb5bd381d  vpermilpd xmm12, xmm12, 0x00
00007accb5bd3823  movaps xmm9, xmm10
00007accb5bd3827  vfmadd231pd xmm9, xmm1, xmm12
00007accb5bd382c  vcmppd xmm6, xmm9, xmm9, 0x03
00007accb5bd3832  vptest xmm6, xmm6
00007accb5bd3837  jnz 0x00007ACCB5BD52FB
00007accb5bd383d  vmovaps xmm1, [rsp+0xC0]
00007accb5bd3846  vpermilpd xmm1, xmm1, 0x00
00007accb5bd384c  vmovaps xmm12, [rsp+0x40]
00007accb5bd3852  movaps xmm10, xmm5
00007accb5bd3856  vfmadd231pd xmm10, xmm12, xmm1
00007accb5bd385b  vcmppd xmm6, xmm10, xmm10, 0x03
00007accb5bd3861  vptest xmm6, xmm6
00007accb5bd3866  jnz 0x00007ACCB5BD5454
00007accb5bd386c  vmovaps xmm1, [rsp+0xC0]
00007accb5bd3875  vpermilpd xmm1, xmm1, 0x00
00007accb5bd387b  vmovaps xmm12, [rsp+0x60]
00007accb5bd3881  movaps xmm6, xmm8
00007accb5bd3885  vfmadd231pd xmm6, xmm12, xmm1
00007accb5bd388a  vcmppd xmm5, xmm6, xmm6, 0x03
00007accb5bd388f  vptest xmm5, xmm5
00007accb5bd3894  jnz 0x00007ACCB5BD55AC
00007accb5bd389a  lea r14, [rax+0x60]
00007accb5bd389e  movups xmm1, [r13+r14*1]
00007accb5bd38a4  lea r14, [rax+0x70]
00007accb5bd38a8  movups xmm12, [r13+r14*1]
00007accb5bd38ae  movaps [r15+0x150], xmm1
00007accb5bd38b6  movaps [r15+0x120], xmm12
00007accb5bd38be  vmovaps [rsp+0x20], xmm11
00007accb5bd38c4  vpermilpd xmm11, xmm11, 0x00
00007accb5bd38ca  movaps xmm8, xmm4
00007accb5bd38ce  vfmadd231pd xmm8, xmm13, xmm11
00007accb5bd38d3  vcmppd xmm5, xmm8, xmm8, 0x03
00007accb5bd38d9  vptest xmm5, xmm5
00007accb5bd38de  jnz 0x00007ACCB5BD5717
00007accb5bd38e4  vmovaps xmm13, [rsp+0x20]
00007accb5bd38ea  vpermilpd xmm13, xmm13, 0x00
00007accb5bd38f0  movaps xmm11, xmm9
00007accb5bd38f4  vfmadd231pd xmm11, xmm1, xmm13
00007accb5bd38f9  vcmppd xmm5, xmm11, xmm11, 0x03
00007accb5bd38ff  vptest xmm5, xmm5
00007accb5bd3904  jnz 0x00007ACCB5BD5870
00007accb5bd390a  vmovaps xmm1, [rsp+0x20]
00007accb5bd3910  vpermilpd xmm1, xmm1, 0x00
00007accb5bd3916  movaps xmm13, xmm10
00007accb5bd391a  vfmadd231pd xmm13, xmm7, xmm1
00007accb5bd391f  vcmppd xmm9, xmm13, xmm13, 0x03
00007accb5bd3925  vptest xmm9, xmm9
00007accb5bd392a  jnz 0x00007ACCB5BD59C9
00007accb5bd3930  vmovaps xmm1, [rsp+0x20]
00007accb5bd3936  vpermilpd xmm1, xmm1, 0x00
00007accb5bd393c  movaps xmm10, xmm6
00007accb5bd3940  vfmadd231pd xmm10, xmm15, xmm1
00007accb5bd3945  vcmppd xmm9, xmm10, xmm10, 0x03
00007accb5bd394b  vptest xmm9, xmm9
00007accb5bd3950  jnz 0x00007ACCB5BD5B21
00007accb5bd3956  lea r14, [rax+0x20]
00007accb5bd395a  movups xmm1, [r13+r14*1]
00007accb5bd3960  lea r14, [rax+0x30]
00007accb5bd3964  movups xmm15, [r13+r14*1]
00007accb5bd396a  vmovaps xmm9, [rsp+0xA0]
00007accb5bd3973  vpermilpd xmm9, xmm9, 0x00
00007accb5bd3979  movaps xmm7, xmm8
00007accb5bd397d  vfmadd231pd xmm7, xmm3, xmm9
00007accb5bd3982  vcmppd xmm6, xmm7, xmm7, 0x03
00007accb5bd3987  vptest xmm6, xmm6
00007accb5bd398c  jnz 0x00007ACCB5BD5C8D
00007accb5bd3992  vmovaps xmm9, [rsp+0xA0]
00007accb5bd399b  vpermilpd xmm9, xmm9, 0x00
00007accb5bd39a1  movaps xmm8, xmm11
00007accb5bd39a5  vfmadd231pd xmm8, xmm14, xmm9
00007accb5bd39aa  vcmppd xmm6, xmm8, xmm8, 0x03
00007accb5bd39b0  vptest xmm6, xmm6
00007accb5bd39b5  jnz 0x00007ACCB5BD5DE4
00007accb5bd39bb  vmovaps xmm14, [rsp+0xA0]
00007accb5bd39c4  vpermilpd xmm14, xmm14, 0x00
00007accb5bd39ca  movaps xmm11, xmm13
00007accb5bd39ce  vfmadd231pd xmm11, xmm12, xmm14
00007accb5bd39d3  vcmppd xmm9, xmm11, xmm11, 0x03
00007accb5bd39d9  vptest xmm9, xmm9
00007accb5bd39de  jnz 0x00007ACCB5BD5F3E
00007accb5bd39e4  vmovaps xmm14, [rsp+0xA0]
00007accb5bd39ed  vpermilpd xmm14, xmm14, 0x00
00007accb5bd39f3  movaps xmm12, xmm10
00007accb5bd39f7  vfmadd231pd xmm12, xmm15, xmm14
00007accb5bd39fc  vcmppd xmm13, xmm12, xmm12, 0x03
00007accb5bd3a02  vptest xmm13, xmm13
00007accb5bd3a07  jnz 0x00007ACCB5BD6098
00007accb5bd3a0d  lea r14, [rax+0x90]
00007accb5bd3a14  movups xmm15, [r13+r14*1]
00007accb5bd3a1a  lea r14, [rax+0xA0]
00007accb5bd3a21  movups xmm14, [r13+r14*1]
00007accb5bd3a27  movaps [r15+0x140], xmm15
00007accb5bd3a2f  movaps [r15+0x130], xmm14
00007accb5bd3a37  vmovaps xmm13, [rsp+0x10]
00007accb5bd3a3d  vpermilpd xmm13, xmm13, 0x00
00007accb5bd3a43  movaps xmm10, xmm7
00007accb5bd3a47  vfmadd231pd xmm10, xmm1, xmm13
00007accb5bd3a4c  vcmppd xmm9, xmm10, xmm10, 0x03
00007accb5bd3a52  vptest xmm9, xmm9
00007accb5bd3a57  jnz 0x00007ACCB5BD6206
00007accb5bd3a5d  movaps [r15+0x220], xmm10
00007accb5bd3a65  lea r14, [rax+0x10]
00007accb5bd3a69  movups xmm1, [r13+r14*1]
00007accb5bd3a6f  movaps [r15+0x240], xmm1
00007accb5bd3a77  vmovaps xmm13, [rsp+0x10]
00007accb5bd3a7d  vpermilpd xmm13, xmm13, 0x00
00007accb5bd3a83  movaps xmm9, xmm8
00007accb5bd3a87  vfmadd231pd xmm9, xmm14, xmm13
00007accb5bd3a8c  vcmppd xmm7, xmm9, xmm9, 0x03
00007accb5bd3a92  vptest xmm7, xmm7
00007accb5bd3a97  jnz 0x00007ACCB5BD6368
00007accb5bd3a9d  movaps [r15+0x110], xmm9
00007accb5bd3aa5  vmovaps xmm14, [rsp+0x10]
00007accb5bd3aab  vpermilpd xmm14, xmm14, 0x00
00007accb5bd3ab1  movaps xmm13, xmm11
00007accb5bd3ab5  vfmadd231pd xmm13, xmm15, xmm14
00007accb5bd3aba  vcmppd xmm8, xmm13, xmm13, 0x03
00007accb5bd3ac0  vptest xmm8, xmm8
00007accb5bd3ac5  jnz 0x00007ACCB5BD64C2
00007accb5bd3acb  movaps [r15+0x170], xmm13
00007accb5bd3ad3  vmovaps xmm15, [rsp+0x10]
00007accb5bd3ad9  vpermilpd xmm15, xmm15, 0x00
00007accb5bd3adf  movaps xmm14, xmm12
00007accb5bd3ae3  vfmadd231pd xmm14, xmm1, xmm15
00007accb5bd3ae8  vcmppd xmm11, xmm14, xmm14, 0x03
00007accb5bd3aee  vptest xmm11, xmm11
00007accb5bd3af3  jnz 0x00007ACCB5BD661C
00007accb5bd3af9  movaps [r15+0x230], xmm14
00007accb5bd3b01  movups [r13+r11*1], xmm9
00007accb5bd3b07  lea rax, [r11+0x10]
00007accb5bd3b0b  movups [r13+rax*1], xmm13
00007accb5bd3b11  lea rax, [r11+0x20]
00007accb5bd3b15  movups [r13+rax*1], xmm10
00007accb5bd3b1b  lea rax, [r11+0x30]
00007accb5bd3b1f  movups [r13+rax*1], xmm14
00007accb5bd3b25  mov eax, [r15+0x108]
00007accb5bd3b2c  sahf
00007accb5bd3b2d  jnz 0x00007ACCB5BD3B5F
00007accb5bd3b2f  cmp dword ptr [r15+0x318], 0x00
00007accb5bd3b37  jz 0x00007ACCB5BD67A0
00007accb5bd3b3d  nop [rax+rax*1], ax
00007accb5bd3b46  nop [rax+rax*1], eax
00007accb5bd3b4e  mov eax, 0x4103F0
00007accb5bd3b53  mov [r15+0x100], rax
00007accb5bd3b5a  jmp 0x00007ACCB59FE110
00007accb5bd3b5f  cmp dword ptr [r15+0x318], 0x00
00007accb5bd3b67  jz 0x00007ACCB5BD2E40
00007accb5bd3b6d  nop [rax+rax*1], ax
00007accb5bd3b76  nop [rax+rax*1], eax
00007accb5bd3b7e  mov eax, 0x410274
00007accb5bd3b83  mov [r15+0x100], rax
00007accb5bd3b8a  jmp 0x00007ACCB59FE110
00007accb5bd3b8f  int3
00007accb5bd3b90  call 0x00007ACCB5A0A4B0
00007accb5bd3b95  jmp 0x00007ACCB5BD2E69
00007accb5bd3b9a  call 0x00007ACCB5A09240
00007accb5bd3b9f  jmp 0x00007ACCB5BD2E73
00007accb5bd3ba4  call 0x00007ACCB5A0A4B0
00007accb5bd3ba9  jmp 0x00007ACCB5BD2EBD
00007accb5bd3bae  call 0x00007ACCB5A09240
00007accb5bd3bb3  jmp 0x00007ACCB5BD2EC7
00007accb5bd3bb8  call 0x00007ACCB5A0A4B0
00007accb5bd3bbd  jmp 0x00007ACCB5BD2F60
00007accb5bd3bc2  call 0x00007ACCB5A09240
00007accb5bd3bc7  jmp 0x00007ACCB5BD2F6A
00007accb5bd3bcc  call 0x00007ACCB5AB47C0
00007accb5bd3bd1  jmp 0x00007ACCB5BD3055
00007accb5bd3bd6  call 0x00007ACCB59FF430
00007accb5bd3bdb  jmp 0x00007ACCB5BD3084
00007accb5bd3be0  call 0x00007ACCB5AB0CE0
00007accb5bd3be5  jmp 0x00007ACCB5BD30A0
00007accb5bd3bea  sub rsp, 0x08
00007accb5bd3bee  push rax
00007accb5bd3bef  push rcx
00007accb5bd3bf0  push rdx
00007accb5bd3bf1  push rdi
00007accb5bd3bf2  push rsi
00007accb5bd3bf3  push r8
00007accb5bd3bf5  push r9
00007accb5bd3bf7  push r10
00007accb5bd3bf9  push r11
00007accb5bd3bfb  sub rsp, 0xF0
00007accb5bd3c02  vmovaps [rsp], xmm0
00007accb5bd3c07  vmovaps [rsp+0x10], xmm1
00007accb5bd3c0d  vmovaps [rsp+0x20], xmm2
00007accb5bd3c13  vmovaps [rsp+0x30], xmm3
00007accb5bd3c19  vmovaps [rsp+0x40], xmm4
00007accb5bd3c1f  vmovaps [rsp+0x50], xmm5
00007accb5bd3c25  vmovaps [rsp+0x60], xmm6
00007accb5bd3c2b  vmovaps [rsp+0x70], xmm7
00007accb5bd3c31  vmovaps [rsp+0x80], xmm8
00007accb5bd3c3a  vmovaps [rsp+0x90], xmm9
00007accb5bd3c43  vmovaps [rsp+0xA0], xmm10
00007accb5bd3c4c  vmovaps [rsp+0xB0], xmm11
00007accb5bd3c55  vmovaps [rsp+0xC0], xmm12
00007accb5bd3c5e  vmovaps [rsp+0xD0], xmm14
00007accb5bd3c67  vmovaps [rsp+0xE0], xmm15
00007accb5bd3c70  sub rsp, 0x40
00007accb5bd3c74  lea rdi, [rsp]
00007accb5bd3c78  lea rsi, [rsp+0x10]
00007accb5bd3c7d  lea rdx, [rsp+0x20]
00007accb5bd3c82  lea rcx, [rsp+0x30]
00007accb5bd3c87  mov r8d, 0x00
00007accb5bd3c8d  lea r9, [r15+0x3A8]
00007accb5bd3c94  movaps [rdi], xmm13
00007accb5bd3c98  movaps [rsi], xmm1
00007accb5bd3c9b  movaps [rdx], xmm15
00007accb5bd3c9f  movaps [rcx], xmm14
00007accb5bd3ca3  mov rax, 0x59156B40DA50
00007accb5bd3cad  call rax
00007accb5bd3caf  movaps xmm13, [rsp]
00007accb5bd3cb4  add rsp, 0x40
00007accb5bd3cb8  vmovaps xmm0, [rsp]
00007accb5bd3cbd  vmovaps xmm1, [rsp+0x10]
00007accb5bd3cc3  vmovaps xmm2, [rsp+0x20]
00007accb5bd3cc9  vmovaps xmm3, [rsp+0x30]
00007accb5bd3ccf  vmovaps xmm4, [rsp+0x40]
00007accb5bd3cd5  vmovaps xmm5, [rsp+0x50]
00007accb5bd3cdb  vmovaps xmm6, [rsp+0x60]
00007accb5bd3ce1  vmovaps xmm7, [rsp+0x70]
00007accb5bd3ce7  vmovaps xmm8, [rsp+0x80]
00007accb5bd3cf0  vmovaps xmm9, [rsp+0x90]
00007accb5bd3cf9  vmovaps xmm10, [rsp+0xA0]
00007accb5bd3d02  vmovaps xmm11, [rsp+0xB0]
00007accb5bd3d0b  vmovaps xmm12, [rsp+0xC0]
00007accb5bd3d14  vmovaps xmm14, [rsp+0xD0]
00007accb5bd3d1d  vmovaps xmm15, [rsp+0xE0]
00007accb5bd3d26  add rsp, 0xF0
00007accb5bd3d2d  pop r11
00007accb5bd3d2f  pop r10
00007accb5bd3d31  pop r9
00007accb5bd3d33  pop r8
00007accb5bd3d35  pop rsi
00007accb5bd3d36  pop rdi
00007accb5bd3d37  pop rdx
00007accb5bd3d38  pop rcx
00007accb5bd3d39  pop rax
00007accb5bd3d3a  add rsp, 0x08
00007accb5bd3d3e  jmp 0x00007ACCB5BD3117
00007accb5bd3d43  sub rsp, 0x08
00007accb5bd3d47  push rax
00007accb5bd3d48  push rcx
00007accb5bd3d49  push rdx
00007accb5bd3d4a  push rdi
00007accb5bd3d4b  push rsi
00007accb5bd3d4c  push r8
00007accb5bd3d4e  push r9
00007accb5bd3d50  push r10
00007accb5bd3d52  push r11
00007accb5bd3d54  sub rsp, 0xF0
00007accb5bd3d5b  vmovaps [rsp], xmm0
00007accb5bd3d60  vmovaps [rsp+0x10], xmm1
00007accb5bd3d66  vmovaps [rsp+0x20], xmm2
00007accb5bd3d6c  vmovaps [rsp+0x30], xmm3
00007accb5bd3d72  vmovaps [rsp+0x40], xmm4
00007accb5bd3d78  vmovaps [rsp+0x50], xmm5
00007accb5bd3d7e  vmovaps [rsp+0x60], xmm6
00007accb5bd3d84  vmovaps [rsp+0x70], xmm7
00007accb5bd3d8a  vmovaps [rsp+0x80], xmm8
00007accb5bd3d93  vmovaps [rsp+0x90], xmm9
00007accb5bd3d9c  vmovaps [rsp+0xA0], xmm10
00007accb5bd3da5  vmovaps [rsp+0xB0], xmm11
00007accb5bd3dae  vmovaps [rsp+0xC0], xmm13
00007accb5bd3db7  vmovaps [rsp+0xD0], xmm14
00007accb5bd3dc0  vmovaps [rsp+0xE0], xmm15
00007accb5bd3dc9  sub rsp, 0x40
00007accb5bd3dcd  lea rdi, [rsp]
00007accb5bd3dd1  lea rsi, [rsp+0x10]
00007accb5bd3dd6  lea rdx, [rsp+0x20]
00007accb5bd3ddb  lea rcx, [rsp+0x30]
00007accb5bd3de0  mov r8d, 0x00
00007accb5bd3de6  lea r9, [r15+0x3A8]
00007accb5bd3ded  movaps [rdi], xmm12
00007accb5bd3df1  movaps [rsi], xmm15
00007accb5bd3df5  movaps [rdx], xmm1
00007accb5bd3df8  movaps [rcx], xmm14
00007accb5bd3dfc  mov rax, 0x59156B40DA50
00007accb5bd3e06  call rax
00007accb5bd3e08  movaps xmm12, [rsp]
00007accb5bd3e0d  add rsp, 0x40
00007accb5bd3e11  vmovaps xmm0, [rsp]
00007accb5bd3e16  vmovaps xmm1, [rsp+0x10]
00007accb5bd3e1c  vmovaps xmm2, [rsp+0x20]
00007accb5bd3e22  vmovaps xmm3, [rsp+0x30]
00007accb5bd3e28  vmovaps xmm4, [rsp+0x40]
00007accb5bd3e2e  vmovaps xmm5, [rsp+0x50]
00007accb5bd3e34  vmovaps xmm6, [rsp+0x60]
00007accb5bd3e3a  vmovaps xmm7, [rsp+0x70]
00007accb5bd3e40  vmovaps xmm8, [rsp+0x80]
00007accb5bd3e49  vmovaps xmm9, [rsp+0x90]
00007accb5bd3e52  vmovaps xmm10, [rsp+0xA0]
00007accb5bd3e5b  vmovaps xmm11, [rsp+0xB0]
00007accb5bd3e64  vmovaps xmm13, [rsp+0xC0]
00007accb5bd3e6d  vmovaps xmm14, [rsp+0xD0]
00007accb5bd3e76  vmovaps xmm15, [rsp+0xE0]
00007accb5bd3e7f  add rsp, 0xF0
00007accb5bd3e86  pop r11
00007accb5bd3e88  pop r10
00007accb5bd3e8a  pop r9
00007accb5bd3e8c  pop r8
00007accb5bd3e8e  pop rsi
00007accb5bd3e8f  pop rdi
00007accb5bd3e90  pop rdx
00007accb5bd3e91  pop rcx
00007accb5bd3e92  pop rax
00007accb5bd3e93  add rsp, 0x08
00007accb5bd3e97  jmp 0x00007ACCB5BD3145
00007accb5bd3e9c  call 0x00007ACCB5AD64F0
00007accb5bd3ea1  jmp 0x00007ACCB5BD3231
00007accb5bd3ea6  sub rsp, 0x08
00007accb5bd3eaa  push rax
00007accb5bd3eab  push rcx
00007accb5bd3eac  push rdx
00007accb5bd3ead  push rdi
00007accb5bd3eae  push rsi
00007accb5bd3eaf  push r8
00007accb5bd3eb1  push r9
00007accb5bd3eb3  push r10
00007accb5bd3eb5  push r11
00007accb5bd3eb7  sub rsp, 0xF0
00007accb5bd3ebe  vmovaps [rsp], xmm0
00007accb5bd3ec3  vmovaps [rsp+0x10], xmm1
00007accb5bd3ec9  vmovaps [rsp+0x20], xmm2
00007accb5bd3ecf  vmovaps [rsp+0x30], xmm3
00007accb5bd3ed5  vmovaps [rsp+0x40], xmm4
00007accb5bd3edb  vmovaps [rsp+0x50], xmm5
00007accb5bd3ee1  vmovaps [rsp+0x60], xmm6
00007accb5bd3ee7  vmovaps [rsp+0x70], xmm7
00007accb5bd3eed  vmovaps [rsp+0x80], xmm8
00007accb5bd3ef6  vmovaps [rsp+0x90], xmm9
00007accb5bd3eff  vmovaps [rsp+0xA0], xmm10
00007accb5bd3f08  vmovaps [rsp+0xB0], xmm11
00007accb5bd3f11  vmovaps [rsp+0xC0], xmm12
00007accb5bd3f1a  vmovaps [rsp+0xD0], xmm14
00007accb5bd3f23  vmovaps [rsp+0xE0], xmm15
00007accb5bd3f2c  sub rsp, 0x40
00007accb5bd3f30  lea rdi, [rsp]
00007accb5bd3f34  lea rsi, [rsp+0x10]
00007accb5bd3f39  lea rdx, [rsp+0x20]
00007accb5bd3f3e  lea rcx, [rsp+0x30]
00007accb5bd3f43  mov r8d, 0x00
00007accb5bd3f49  lea r9, [r15+0x3A8]
00007accb5bd3f50  movaps [rdi], xmm13
00007accb5bd3f54  movaps [rsi], xmm1
00007accb5bd3f57  movaps [rdx], xmm15
00007accb5bd3f5b  movaps [rcx], xmm14
00007accb5bd3f5f  mov rax, 0x59156B40DA50
00007accb5bd3f69  call rax
00007accb5bd3f6b  movaps xmm13, [rsp]
00007accb5bd3f70  add rsp, 0x40
00007accb5bd3f74  vmovaps xmm0, [rsp]
00007accb5bd3f79  vmovaps xmm1, [rsp+0x10]
00007accb5bd3f7f  vmovaps xmm2, [rsp+0x20]
00007accb5bd3f85  vmovaps xmm3, [rsp+0x30]
00007accb5bd3f8b  vmovaps xmm4, [rsp+0x40]
00007accb5bd3f91  vmovaps xmm5, [rsp+0x50]
00007accb5bd3f97  vmovaps xmm6, [rsp+0x60]
00007accb5bd3f9d  vmovaps xmm7, [rsp+0x70]
00007accb5bd3fa3  vmovaps xmm8, [rsp+0x80]
00007accb5bd3fac  vmovaps xmm9, [rsp+0x90]
00007accb5bd3fb5  vmovaps xmm10, [rsp+0xA0]
00007accb5bd3fbe  vmovaps xmm11, [rsp+0xB0]
00007accb5bd3fc7  vmovaps xmm12, [rsp+0xC0]
00007accb5bd3fd0  vmovaps xmm14, [rsp+0xD0]
00007accb5bd3fd9  vmovaps xmm15, [rsp+0xE0]
00007accb5bd3fe2  add rsp, 0xF0
00007accb5bd3fe9  pop r11
00007accb5bd3feb  pop r10
00007accb5bd3fed  pop r9
00007accb5bd3fef  pop r8
00007accb5bd3ff1  pop rsi
00007accb5bd3ff2  pop rdi
00007accb5bd3ff3  pop rdx
00007accb5bd3ff4  pop rcx
00007accb5bd3ff5  pop rax
00007accb5bd3ff6  add rsp, 0x08
00007accb5bd3ffa  jmp 0x00007ACCB5BD32A0
00007accb5bd3fff  call 0x00007ACCB5AD64F0
00007accb5bd4004  jmp 0x00007ACCB5BD32B5
00007accb5bd4009  sub rsp, 0x08
00007accb5bd400d  push rax
00007accb5bd400e  push rcx
00007accb5bd400f  push rdx
00007accb5bd4010  push rdi
00007accb5bd4011  push rsi
00007accb5bd4012  push r8
00007accb5bd4014  push r9
00007accb5bd4016  push r10
00007accb5bd4018  push r11
00007accb5bd401a  sub rsp, 0xF0
00007accb5bd4021  vmovaps [rsp], xmm0
00007accb5bd4026  vmovaps [rsp+0x10], xmm1
00007accb5bd402c  vmovaps [rsp+0x20], xmm2
00007accb5bd4032  vmovaps [rsp+0x30], xmm3
00007accb5bd4038  vmovaps [rsp+0x40], xmm4
00007accb5bd403e  vmovaps [rsp+0x50], xmm5
00007accb5bd4044  vmovaps [rsp+0x60], xmm6
00007accb5bd404a  vmovaps [rsp+0x70], xmm7
00007accb5bd4050  vmovaps [rsp+0x80], xmm8
00007accb5bd4059  vmovaps [rsp+0x90], xmm9
00007accb5bd4062  vmovaps [rsp+0xA0], xmm10
00007accb5bd406b  vmovaps [rsp+0xB0], xmm11
00007accb5bd4074  vmovaps [rsp+0xC0], xmm13
00007accb5bd407d  vmovaps [rsp+0xD0], xmm14
00007accb5bd4086  vmovaps [rsp+0xE0], xmm15
00007accb5bd408f  sub rsp, 0x40
00007accb5bd4093  lea rdi, [rsp]
00007accb5bd4097  lea rsi, [rsp+0x10]
00007accb5bd409c  lea rdx, [rsp+0x20]
00007accb5bd40a1  lea rcx, [rsp+0x30]
00007accb5bd40a6  mov r8d, 0x00
00007accb5bd40ac  lea r9, [r15+0x3A8]
00007accb5bd40b3  movaps [rdi], xmm12
00007accb5bd40b7  movaps [rsi], xmm15
00007accb5bd40bb  movaps [rdx], xmm1
00007accb5bd40be  movaps [rcx], xmm14
00007accb5bd40c2  mov rax, 0x59156B40DA50
00007accb5bd40cc  call rax
00007accb5bd40ce  movaps xmm12, [rsp]
00007accb5bd40d3  add rsp, 0x40
00007accb5bd40d7  vmovaps xmm0, [rsp]
00007accb5bd40dc  vmovaps xmm1, [rsp+0x10]
00007accb5bd40e2  vmovaps xmm2, [rsp+0x20]
00007accb5bd40e8  vmovaps xmm3, [rsp+0x30]
00007accb5bd40ee  vmovaps xmm4, [rsp+0x40]
00007accb5bd40f4  vmovaps xmm5, [rsp+0x50]
00007accb5bd40fa  vmovaps xmm6, [rsp+0x60]
00007accb5bd4100  vmovaps xmm7, [rsp+0x70]
00007accb5bd4106  vmovaps xmm8, [rsp+0x80]
00007accb5bd410f  vmovaps xmm9, [rsp+0x90]
00007accb5bd4118  vmovaps xmm10, [rsp+0xA0]
00007accb5bd4121  vmovaps xmm11, [rsp+0xB0]
00007accb5bd412a  vmovaps xmm13, [rsp+0xC0]
00007accb5bd4133  vmovaps xmm14, [rsp+0xD0]
00007accb5bd413c  vmovaps xmm15, [rsp+0xE0]
00007accb5bd4145  add rsp, 0xF0
00007accb5bd414c  pop r11
00007accb5bd414e  pop r10
00007accb5bd4150  pop r9
00007accb5bd4152  pop r8
00007accb5bd4154  pop rsi
00007accb5bd4155  pop rdi
00007accb5bd4156  pop rdx
00007accb5bd4157  pop rcx
00007accb5bd4158  pop rax
00007accb5bd4159  add rsp, 0x08
00007accb5bd415d  jmp 0x00007ACCB5BD32E1
00007accb5bd4162  sub rsp, 0x08
00007accb5bd4166  push rax
00007accb5bd4167  push rcx
00007accb5bd4168  push rdx
00007accb5bd4169  push rdi
00007accb5bd416a  push rsi
00007accb5bd416b  push r8
00007accb5bd416d  push r9
00007accb5bd416f  push r10
00007accb5bd4171  push r11
00007accb5bd4173  sub rsp, 0xF0
00007accb5bd417a  vmovaps [rsp], xmm0
00007accb5bd417f  vmovaps [rsp+0x10], xmm1
00007accb5bd4185  vmovaps [rsp+0x20], xmm2
00007accb5bd418b  vmovaps [rsp+0x30], xmm3
00007accb5bd4191  vmovaps [rsp+0x40], xmm4
00007accb5bd4197  vmovaps [rsp+0x50], xmm5
00007accb5bd419d  vmovaps [rsp+0x60], xmm6
00007accb5bd41a3  vmovaps [rsp+0x70], xmm7
00007accb5bd41a9  vmovaps [rsp+0x80], xmm8
00007accb5bd41b2  vmovaps [rsp+0x90], xmm9
00007accb5bd41bb  vmovaps [rsp+0xA0], xmm10
00007accb5bd41c4  vmovaps [rsp+0xB0], xmm11
00007accb5bd41cd  vmovaps [rsp+0xC0], xmm12
00007accb5bd41d6  vmovaps [rsp+0xD0], xmm14
00007accb5bd41df  vmovaps [rsp+0xE0], xmm15
00007accb5bd41e8  sub rsp, 0x40
00007accb5bd41ec  lea rdi, [rsp]
00007accb5bd41f0  lea rsi, [rsp+0x10]
00007accb5bd41f5  lea rdx, [rsp+0x20]
00007accb5bd41fa  lea rcx, [rsp+0x30]
00007accb5bd41ff  mov r8d, 0x00
00007accb5bd4205  lea r9, [r15+0x3A8]
00007accb5bd420c  movaps [rdi], xmm13
00007accb5bd4210  movaps [rsi], xmm1
00007accb5bd4213  movaps [rdx], xmm15
00007accb5bd4217  movaps [rcx], xmm14
00007accb5bd421b  mov rax, 0x59156B40DA50
00007accb5bd4225  call rax
00007accb5bd4227  movaps xmm13, [rsp]
00007accb5bd422c  add rsp, 0x40
00007accb5bd4230  vmovaps xmm0, [rsp]
00007accb5bd4235  vmovaps xmm1, [rsp+0x10]
00007accb5bd423b  vmovaps xmm2, [rsp+0x20]
00007accb5bd4241  vmovaps xmm3, [rsp+0x30]
00007accb5bd4247  vmovaps xmm4, [rsp+0x40]
00007accb5bd424d  vmovaps xmm5, [rsp+0x50]
00007accb5bd4253  vmovaps xmm6, [rsp+0x60]
00007accb5bd4259  vmovaps xmm7, [rsp+0x70]
00007accb5bd425f  vmovaps xmm8, [rsp+0x80]
00007accb5bd4268  vmovaps xmm9, [rsp+0x90]
00007accb5bd4271  vmovaps xmm10, [rsp+0xA0]
00007accb5bd427a  vmovaps xmm11, [rsp+0xB0]
00007accb5bd4283  vmovaps xmm12, [rsp+0xC0]
00007accb5bd428c  vmovaps xmm14, [rsp+0xD0]
00007accb5bd4295  vmovaps xmm15, [rsp+0xE0]
00007accb5bd429e  add rsp, 0xF0
00007accb5bd42a5  pop r11
00007accb5bd42a7  pop r10
00007accb5bd42a9  pop r9
00007accb5bd42ab  pop r8
00007accb5bd42ad  pop rsi
00007accb5bd42ae  pop rdi
00007accb5bd42af  pop rdx
00007accb5bd42b0  pop rcx
00007accb5bd42b1  pop rax
00007accb5bd42b2  add rsp, 0x08
00007accb5bd42b6  jmp 0x00007ACCB5BD3482
00007accb5bd42bb  sub rsp, 0x08
00007accb5bd42bf  push rax
00007accb5bd42c0  push rcx
00007accb5bd42c1  push rdx
00007accb5bd42c2  push rdi
00007accb5bd42c3  push rsi
00007accb5bd42c4  push r8
00007accb5bd42c6  push r9
00007accb5bd42c8  push r10
00007accb5bd42ca  push r11
00007accb5bd42cc  sub rsp, 0xF0
00007accb5bd42d3  vmovaps [rsp], xmm0
00007accb5bd42d8  vmovaps [rsp+0x10], xmm1
00007accb5bd42de  vmovaps [rsp+0x20], xmm2
00007accb5bd42e4  vmovaps [rsp+0x30], xmm3
00007accb5bd42ea  vmovaps [rsp+0x40], xmm4
00007accb5bd42f0  vmovaps [rsp+0x50], xmm5
00007accb5bd42f6  vmovaps [rsp+0x60], xmm6
00007accb5bd42fc  vmovaps [rsp+0x70], xmm7
00007accb5bd4302  vmovaps [rsp+0x80], xmm8
00007accb5bd430b  vmovaps [rsp+0x90], xmm9
00007accb5bd4314  vmovaps [rsp+0xA0], xmm10
00007accb5bd431d  vmovaps [rsp+0xB0], xmm11
00007accb5bd4326  vmovaps [rsp+0xC0], xmm13
00007accb5bd432f  vmovaps [rsp+0xD0], xmm14
00007accb5bd4338  vmovaps [rsp+0xE0], xmm15
00007accb5bd4341  sub rsp, 0x40
00007accb5bd4345  lea rdi, [rsp]
00007accb5bd4349  lea rsi, [rsp+0x10]
00007accb5bd434e  lea rdx, [rsp+0x20]
00007accb5bd4353  lea rcx, [rsp+0x30]
00007accb5bd4358  mov r8d, 0x00
00007accb5bd435e  lea r9, [r15+0x3A8]
00007accb5bd4365  movaps [rdi], xmm12
00007accb5bd4369  movaps [rsi], xmm15
00007accb5bd436d  movaps [rdx], xmm14
00007accb5bd4371  movaps [rcx], xmm1
00007accb5bd4374  mov rax, 0x59156B40DA50
00007accb5bd437e  call rax
00007accb5bd4380  movaps xmm12, [rsp]
00007accb5bd4385  add rsp, 0x40
00007accb5bd4389  vmovaps xmm0, [rsp]
00007accb5bd438e  vmovaps xmm1, [rsp+0x10]
00007accb5bd4394  vmovaps xmm2, [rsp+0x20]
00007accb5bd439a  vmovaps xmm3, [rsp+0x30]
00007accb5bd43a0  vmovaps xmm4, [rsp+0x40]
00007accb5bd43a6  vmovaps xmm5, [rsp+0x50]
00007accb5bd43ac  vmovaps xmm6, [rsp+0x60]
00007accb5bd43b2  vmovaps xmm7, [rsp+0x70]
00007accb5bd43b8  vmovaps xmm8, [rsp+0x80]
00007accb5bd43c1  vmovaps xmm9, [rsp+0x90]
00007accb5bd43ca  vmovaps xmm10, [rsp+0xA0]
00007accb5bd43d3  vmovaps xmm11, [rsp+0xB0]
00007accb5bd43dc  vmovaps xmm13, [rsp+0xC0]
00007accb5bd43e5  vmovaps xmm14, [rsp+0xD0]
00007accb5bd43ee  vmovaps xmm15, [rsp+0xE0]
00007accb5bd43f7  add rsp, 0xF0
00007accb5bd43fe  pop r11
00007accb5bd4400  pop r10
00007accb5bd4402  pop r9
00007accb5bd4404  pop r8
00007accb5bd4406  pop rsi
00007accb5bd4407  pop rdi
00007accb5bd4408  pop rdx
00007accb5bd4409  pop rcx
00007accb5bd440a  pop rax
00007accb5bd440b  add rsp, 0x08
00007accb5bd440f  jmp 0x00007ACCB5BD34C0
00007accb5bd4414  sub rsp, 0x08
00007accb5bd4418  push rax
00007accb5bd4419  push rcx
00007accb5bd441a  push rdx
00007accb5bd441b  push rdi
00007accb5bd441c  push rsi
00007accb5bd441d  push r8
00007accb5bd441f  push r9
00007accb5bd4421  push r10
00007accb5bd4423  push r11
00007accb5bd4425  sub rsp, 0xF0
00007accb5bd442c  vmovaps [rsp], xmm0
00007accb5bd4431  vmovaps [rsp+0x10], xmm1
00007accb5bd4437  vmovaps [rsp+0x20], xmm2
00007accb5bd443d  vmovaps [rsp+0x30], xmm3
00007accb5bd4443  vmovaps [rsp+0x40], xmm4
00007accb5bd4449  vmovaps [rsp+0x50], xmm5
00007accb5bd444f  vmovaps [rsp+0x60], xmm6
00007accb5bd4455  vmovaps [rsp+0x70], xmm7
00007accb5bd445b  vmovaps [rsp+0x80], xmm8
00007accb5bd4464  vmovaps [rsp+0x90], xmm9
00007accb5bd446d  vmovaps [rsp+0xA0], xmm10
00007accb5bd4476  vmovaps [rsp+0xB0], xmm11
00007accb5bd447f  vmovaps [rsp+0xC0], xmm12
00007accb5bd4488  vmovaps [rsp+0xD0], xmm14
00007accb5bd4491  vmovaps [rsp+0xE0], xmm15
00007accb5bd449a  sub rsp, 0x40
00007accb5bd449e  lea rdi, [rsp]
00007accb5bd44a2  lea rsi, [rsp+0x10]
00007accb5bd44a7  lea rdx, [rsp+0x20]
00007accb5bd44ac  lea rcx, [rsp+0x30]
00007accb5bd44b1  mov r8d, 0x00
00007accb5bd44b7  lea r9, [r15+0x3A8]
00007accb5bd44be  movaps [rdi], xmm13
00007accb5bd44c2  movaps [rsi], xmm15
00007accb5bd44c6  movaps [rdx], xmm14
00007accb5bd44ca  movaps [rcx], xmm1
00007accb5bd44cd  mov rax, 0x59156B40DA50
00007accb5bd44d7  call rax
00007accb5bd44d9  movaps xmm13, [rsp]
00007accb5bd44de  add rsp, 0x40
00007accb5bd44e2  vmovaps xmm0, [rsp]
00007accb5bd44e7  vmovaps xmm1, [rsp+0x10]
00007accb5bd44ed  vmovaps xmm2, [rsp+0x20]
00007accb5bd44f3  vmovaps xmm3, [rsp+0x30]
00007accb5bd44f9  vmovaps xmm4, [rsp+0x40]
00007accb5bd44ff  vmovaps xmm5, [rsp+0x50]
00007accb5bd4505  vmovaps xmm6, [rsp+0x60]
00007accb5bd450b  vmovaps xmm7, [rsp+0x70]
00007accb5bd4511  vmovaps xmm8, [rsp+0x80]
00007accb5bd451a  vmovaps xmm9, [rsp+0x90]
00007accb5bd4523  vmovaps xmm10, [rsp+0xA0]
00007accb5bd452c  vmovaps xmm11, [rsp+0xB0]
00007accb5bd4535  vmovaps xmm12, [rsp+0xC0]
00007accb5bd453e  vmovaps xmm14, [rsp+0xD0]
00007accb5bd4547  vmovaps xmm15, [rsp+0xE0]
00007accb5bd4550  add rsp, 0xF0
00007accb5bd4557  pop r11
00007accb5bd4559  pop r10
00007accb5bd455b  pop r9
00007accb5bd455d  pop r8
00007accb5bd455f  pop rsi
00007accb5bd4560  pop rdi
00007accb5bd4561  pop rdx
00007accb5bd4562  pop rcx
00007accb5bd4563  pop rax
00007accb5bd4564  add rsp, 0x08
00007accb5bd4568  jmp 0x00007ACCB5BD34FE
00007accb5bd456d  sub rsp, 0x08
00007accb5bd4571  push rax
00007accb5bd4572  push rcx
00007accb5bd4573  push rdx
00007accb5bd4574  push rdi
00007accb5bd4575  push rsi
00007accb5bd4576  push r8
00007accb5bd4578  push r9
00007accb5bd457a  push r10
00007accb5bd457c  push r11
00007accb5bd457e  sub rsp, 0xF0
00007accb5bd4585  vmovaps [rsp], xmm0
00007accb5bd458a  vmovaps [rsp+0x10], xmm1
00007accb5bd4590  vmovaps [rsp+0x20], xmm2
00007accb5bd4596  vmovaps [rsp+0x30], xmm3
00007accb5bd459c  vmovaps [rsp+0x40], xmm4
00007accb5bd45a2  vmovaps [rsp+0x50], xmm5
00007accb5bd45a8  vmovaps [rsp+0x60], xmm6
00007accb5bd45ae  vmovaps [rsp+0x70], xmm7
00007accb5bd45b4  vmovaps [rsp+0x80], xmm8
00007accb5bd45bd  vmovaps [rsp+0x90], xmm9
00007accb5bd45c6  vmovaps [rsp+0xA0], xmm10
00007accb5bd45cf  vmovaps [rsp+0xB0], xmm11
00007accb5bd45d8  vmovaps [rsp+0xC0], xmm13
00007accb5bd45e1  vmovaps [rsp+0xD0], xmm14
00007accb5bd45ea  vmovaps [rsp+0xE0], xmm15
00007accb5bd45f3  sub rsp, 0x40
00007accb5bd45f7  lea rdi, [rsp]
00007accb5bd45fb  lea rsi, [rsp+0x10]
00007accb5bd4600  lea rdx, [rsp+0x20]
00007accb5bd4605  lea rcx, [rsp+0x30]
00007accb5bd460a  mov r8d, 0x00
00007accb5bd4610  lea r9, [r15+0x3A8]
00007accb5bd4617  movaps [rdi], xmm12
00007accb5bd461b  movaps [rsi], xmm14
00007accb5bd461f  movaps [rdx], xmm2
00007accb5bd4622  movaps [rcx], xmm15
00007accb5bd4626  mov rax, 0x59156B40DA50
00007accb5bd4630  call rax
00007accb5bd4632  movaps xmm12, [rsp]
00007accb5bd4637  add rsp, 0x40
00007accb5bd463b  vmovaps xmm0, [rsp]
00007accb5bd4640  vmovaps xmm1, [rsp+0x10]
00007accb5bd4646  vmovaps xmm2, [rsp+0x20]
00007accb5bd464c  vmovaps xmm3, [rsp+0x30]
00007accb5bd4652  vmovaps xmm4, [rsp+0x40]
00007accb5bd4658  vmovaps xmm5, [rsp+0x50]
00007accb5bd465e  vmovaps xmm6, [rsp+0x60]
00007accb5bd4664  vmovaps xmm7, [rsp+0x70]
00007accb5bd466a  vmovaps xmm8, [rsp+0x80]
00007accb5bd4673  vmovaps xmm9, [rsp+0x90]
00007accb5bd467c  vmovaps xmm10, [rsp+0xA0]
00007accb5bd4685  vmovaps xmm11, [rsp+0xB0]
00007accb5bd468e  vmovaps xmm13, [rsp+0xC0]
00007accb5bd4697  vmovaps xmm14, [rsp+0xD0]
00007accb5bd46a0  vmovaps xmm15, [rsp+0xE0]
00007accb5bd46a9  add rsp, 0xF0
00007accb5bd46b0  pop r11
00007accb5bd46b2  pop r10
00007accb5bd46b4  pop r9
00007accb5bd46b6  pop r8
00007accb5bd46b8  pop rsi
00007accb5bd46b9  pop rdi
00007accb5bd46ba  pop rdx
00007accb5bd46bb  pop rcx
00007accb5bd46bc  pop rax
00007accb5bd46bd  add rsp, 0x08
00007accb5bd46c1  jmp 0x00007ACCB5BD3558
00007accb5bd46c6  sub rsp, 0x08
00007accb5bd46ca  push rax
00007accb5bd46cb  push rcx
00007accb5bd46cc  push rdx
00007accb5bd46cd  push rdi
00007accb5bd46ce  push rsi
00007accb5bd46cf  push r8
00007accb5bd46d1  push r9
00007accb5bd46d3  push r10
00007accb5bd46d5  push r11
00007accb5bd46d7  sub rsp, 0xF0
00007accb5bd46de  vmovaps [rsp], xmm0
00007accb5bd46e3  vmovaps [rsp+0x10], xmm1
00007accb5bd46e9  vmovaps [rsp+0x20], xmm3
00007accb5bd46ef  vmovaps [rsp+0x30], xmm4
00007accb5bd46f5  vmovaps [rsp+0x40], xmm5
00007accb5bd46fb  vmovaps [rsp+0x50], xmm6
00007accb5bd4701  vmovaps [rsp+0x60], xmm7
00007accb5bd4707  vmovaps [rsp+0x70], xmm8
00007accb5bd470d  vmovaps [rsp+0x80], xmm9
00007accb5bd4716  vmovaps [rsp+0x90], xmm10
00007accb5bd471f  vmovaps [rsp+0xA0], xmm11
00007accb5bd4728  vmovaps [rsp+0xB0], xmm12
00007accb5bd4731  vmovaps [rsp+0xC0], xmm13
00007accb5bd473a  vmovaps [rsp+0xD0], xmm14
00007accb5bd4743  vmovaps [rsp+0xE0], xmm15
00007accb5bd474c  sub rsp, 0x40
00007accb5bd4750  lea rdi, [rsp]
00007accb5bd4754  lea rsi, [rsp+0x10]
00007accb5bd4759  lea rdx, [rsp+0x20]
00007accb5bd475e  lea rcx, [rsp+0x30]
00007accb5bd4763  mov r8d, 0x00
00007accb5bd4769  lea r9, [r15+0x3A8]
00007accb5bd4770  movaps [rdi], xmm2
00007accb5bd4773  movaps [rsi], xmm14
00007accb5bd4777  movaps [rdx], xmm8
00007accb5bd477b  movaps [rcx], xmm5
00007accb5bd477e  mov rax, 0x59156B40DA50
00007accb5bd4788  call rax
00007accb5bd478a  movaps xmm2, [rsp]
00007accb5bd478e  add rsp, 0x40
00007accb5bd4792  vmovaps xmm0, [rsp]
00007accb5bd4797  vmovaps xmm1, [rsp+0x10]
00007accb5bd479d  vmovaps xmm3, [rsp+0x20]
00007accb5bd47a3  vmovaps xmm4, [rsp+0x30]
00007accb5bd47a9  vmovaps xmm5, [rsp+0x40]
00007accb5bd47af  vmovaps xmm6, [rsp+0x50]
00007accb5bd47b5  vmovaps xmm7, [rsp+0x60]
00007accb5bd47bb  vmovaps xmm8, [rsp+0x70]
00007accb5bd47c1  vmovaps xmm9, [rsp+0x80]
00007accb5bd47ca  vmovaps xmm10, [rsp+0x90]
00007accb5bd47d3  vmovaps xmm11, [rsp+0xA0]
00007accb5bd47dc  vmovaps xmm12, [rsp+0xB0]
00007accb5bd47e5  vmovaps xmm13, [rsp+0xC0]
00007accb5bd47ee  vmovaps xmm14, [rsp+0xD0]
00007accb5bd47f7  vmovaps xmm15, [rsp+0xE0]
00007accb5bd4800  add rsp, 0xF0
00007accb5bd4807  pop r11
00007accb5bd4809  pop r10
00007accb5bd480b  pop r9
00007accb5bd480d  pop r8
00007accb5bd480f  pop rsi
00007accb5bd4810  pop rdi
00007accb5bd4811  pop rdx
00007accb5bd4812  pop rcx
00007accb5bd4813  pop rax
00007accb5bd4814  add rsp, 0x08
00007accb5bd4818  jmp 0x00007ACCB5BD360C
00007accb5bd481d  sub rsp, 0x08
00007accb5bd4821  push rax
00007accb5bd4822  push rcx
00007accb5bd4823  push rdx
00007accb5bd4824  push rdi
00007accb5bd4825  push rsi
00007accb5bd4826  push r8
00007accb5bd4828  push r9
00007accb5bd482a  push r10
00007accb5bd482c  push r11
00007accb5bd482e  sub rsp, 0xF0
00007accb5bd4835  vmovaps [rsp], xmm0
00007accb5bd483a  vmovaps [rsp+0x10], xmm1
00007accb5bd4840  vmovaps [rsp+0x20], xmm2
00007accb5bd4846  vmovaps [rsp+0x30], xmm3
00007accb5bd484c  vmovaps [rsp+0x40], xmm4
00007accb5bd4852  vmovaps [rsp+0x50], xmm6
00007accb5bd4858  vmovaps [rsp+0x60], xmm7
00007accb5bd485e  vmovaps [rsp+0x70], xmm8
00007accb5bd4864  vmovaps [rsp+0x80], xmm9
00007accb5bd486d  vmovaps [rsp+0x90], xmm10
00007accb5bd4876  vmovaps [rsp+0xA0], xmm11
00007accb5bd487f  vmovaps [rsp+0xB0], xmm12
00007accb5bd4888  vmovaps [rsp+0xC0], xmm13
00007accb5bd4891  vmovaps [rsp+0xD0], xmm14
00007accb5bd489a  vmovaps [rsp+0xE0], xmm15
00007accb5bd48a3  sub rsp, 0x40
00007accb5bd48a7  lea rdi, [rsp]
00007accb5bd48ab  lea rsi, [rsp+0x10]
00007accb5bd48b0  lea rdx, [rsp+0x20]
00007accb5bd48b5  lea rcx, [rsp+0x30]
00007accb5bd48ba  mov r8d, 0x00
00007accb5bd48c0  lea r9, [r15+0x3A8]
00007accb5bd48c7  movaps [rdi], xmm5
00007accb5bd48ca  movaps [rsi], xmm14
00007accb5bd48ce  movaps [rdx], xmm8
00007accb5bd48d2  movaps [rcx], xmm1
00007accb5bd48d5  mov rax, 0x59156B40DA50
00007accb5bd48df  call rax
00007accb5bd48e1  movaps xmm5, [rsp]
00007accb5bd48e5  add rsp, 0x40
00007accb5bd48e9  vmovaps xmm0, [rsp]
00007accb5bd48ee  vmovaps xmm1, [rsp+0x10]
00007accb5bd48f4  vmovaps xmm2, [rsp+0x20]
00007accb5bd48fa  vmovaps xmm3, [rsp+0x30]
00007accb5bd4900  vmovaps xmm4, [rsp+0x40]
00007accb5bd4906  vmovaps xmm6, [rsp+0x50]
00007accb5bd490c  vmovaps xmm7, [rsp+0x60]
00007accb5bd4912  vmovaps xmm8, [rsp+0x70]
00007accb5bd4918  vmovaps xmm9, [rsp+0x80]
00007accb5bd4921  vmovaps xmm10, [rsp+0x90]
00007accb5bd492a  vmovaps xmm11, [rsp+0xA0]
00007accb5bd4933  vmovaps xmm12, [rsp+0xB0]
00007accb5bd493c  vmovaps xmm13, [rsp+0xC0]
00007accb5bd4945  vmovaps xmm14, [rsp+0xD0]
00007accb5bd494e  vmovaps xmm15, [rsp+0xE0]
00007accb5bd4957  add rsp, 0xF0
00007accb5bd495e  pop r11
00007accb5bd4960  pop r10
00007accb5bd4962  pop r9
00007accb5bd4964  pop r8
00007accb5bd4966  pop rsi
00007accb5bd4967  pop rdi
00007accb5bd4968  pop rdx
00007accb5bd4969  pop rcx
00007accb5bd496a  pop rax
00007accb5bd496b  add rsp, 0x08
00007accb5bd496f  jmp 0x00007ACCB5BD3649
00007accb5bd4974  sub rsp, 0x08
00007accb5bd4978  push rax
00007accb5bd4979  push rcx
00007accb5bd497a  push rdx
00007accb5bd497b  push rdi
00007accb5bd497c  push rsi
00007accb5bd497d  push r8
00007accb5bd497f  push r9
00007accb5bd4981  push r10
00007accb5bd4983  push r11
00007accb5bd4985  sub rsp, 0xF0
00007accb5bd498c  vmovaps [rsp], xmm0
00007accb5bd4991  vmovaps [rsp+0x10], xmm1
00007accb5bd4997  vmovaps [rsp+0x20], xmm2
00007accb5bd499d  vmovaps [rsp+0x30], xmm3
00007accb5bd49a3  vmovaps [rsp+0x40], xmm4
00007accb5bd49a9  vmovaps [rsp+0x50], xmm5
00007accb5bd49af  vmovaps [rsp+0x60], xmm6
00007accb5bd49b5  vmovaps [rsp+0x70], xmm7
00007accb5bd49bb  vmovaps [rsp+0x80], xmm8
00007accb5bd49c4  vmovaps [rsp+0x90], xmm9
00007accb5bd49cd  vmovaps [rsp+0xA0], xmm10
00007accb5bd49d6  vmovaps [rsp+0xB0], xmm11
00007accb5bd49df  vmovaps [rsp+0xC0], xmm12
00007accb5bd49e8  vmovaps [rsp+0xD0], xmm13
00007accb5bd49f1  vmovaps [rsp+0xE0], xmm14
00007accb5bd49fa  sub rsp, 0x40
00007accb5bd49fe  lea rdi, [rsp]
00007accb5bd4a02  lea rsi, [rsp+0x10]
00007accb5bd4a07  lea rdx, [rsp+0x20]
00007accb5bd4a0c  lea rcx, [rsp+0x30]
00007accb5bd4a11  mov r8d, 0x00
00007accb5bd4a17  lea r9, [r15+0x3A8]
00007accb5bd4a1e  movaps [rdi], xmm15
00007accb5bd4a22  movaps [rsi], xmm13
00007accb5bd4a26  movaps [rdx], xmm14
00007accb5bd4a2a  movaps [rcx], xmm1
00007accb5bd4a2d  mov rax, 0x59156B40DA50
00007accb5bd4a37  call rax
00007accb5bd4a39  movaps xmm15, [rsp]
00007accb5bd4a3e  add rsp, 0x40
00007accb5bd4a42  vmovaps xmm0, [rsp]
00007accb5bd4a47  vmovaps xmm1, [rsp+0x10]
00007accb5bd4a4d  vmovaps xmm2, [rsp+0x20]
00007accb5bd4a53  vmovaps xmm3, [rsp+0x30]
00007accb5bd4a59  vmovaps xmm4, [rsp+0x40]
00007accb5bd4a5f  vmovaps xmm5, [rsp+0x50]
00007accb5bd4a65  vmovaps xmm6, [rsp+0x60]
00007accb5bd4a6b  vmovaps xmm7, [rsp+0x70]
00007accb5bd4a71  vmovaps xmm8, [rsp+0x80]
00007accb5bd4a7a  vmovaps xmm9, [rsp+0x90]
00007accb5bd4a83  vmovaps xmm10, [rsp+0xA0]
00007accb5bd4a8c  vmovaps xmm11, [rsp+0xB0]
00007accb5bd4a95  vmovaps xmm12, [rsp+0xC0]
00007accb5bd4a9e  vmovaps xmm13, [rsp+0xD0]
00007accb5bd4aa7  vmovaps xmm14, [rsp+0xE0]
00007accb5bd4ab0  add rsp, 0xF0
00007accb5bd4ab7  pop r11
00007accb5bd4ab9  pop r10
00007accb5bd4abb  pop r9
00007accb5bd4abd  pop r8
00007accb5bd4abf  pop rsi
00007accb5bd4ac0  pop rdi
00007accb5bd4ac1  pop rdx
00007accb5bd4ac2  pop rcx
00007accb5bd4ac3  pop rax
00007accb5bd4ac4  add rsp, 0x08
00007accb5bd4ac8  jmp 0x00007ACCB5BD3678
00007accb5bd4acd  sub rsp, 0x08
00007accb5bd4ad1  push rax
00007accb5bd4ad2  push rcx
00007accb5bd4ad3  push rdx
00007accb5bd4ad4  push rdi
00007accb5bd4ad5  push rsi
00007accb5bd4ad6  push r8
00007accb5bd4ad8  push r9
00007accb5bd4ada  push r10
00007accb5bd4adc  push r11
00007accb5bd4ade  sub rsp, 0xF0
00007accb5bd4ae5  vmovaps [rsp], xmm0
00007accb5bd4aea  vmovaps [rsp+0x10], xmm1
00007accb5bd4af0  vmovaps [rsp+0x20], xmm2
00007accb5bd4af6  vmovaps [rsp+0x30], xmm3
00007accb5bd4afc  vmovaps [rsp+0x40], xmm4
00007accb5bd4b02  vmovaps [rsp+0x50], xmm5
00007accb5bd4b08  vmovaps [rsp+0x60], xmm6
00007accb5bd4b0e  vmovaps [rsp+0x70], xmm7
00007accb5bd4b14  vmovaps [rsp+0x80], xmm8
00007accb5bd4b1d  vmovaps [rsp+0x90], xmm9
00007accb5bd4b26  vmovaps [rsp+0xA0], xmm10
00007accb5bd4b2f  vmovaps [rsp+0xB0], xmm11
00007accb5bd4b38  vmovaps [rsp+0xC0], xmm12
00007accb5bd4b41  vmovaps [rsp+0xD0], xmm14
00007accb5bd4b4a  vmovaps [rsp+0xE0], xmm15
00007accb5bd4b53  sub rsp, 0x40
00007accb5bd4b57  lea rdi, [rsp]
00007accb5bd4b5b  lea rsi, [rsp+0x10]
00007accb5bd4b60  lea rdx, [rsp+0x20]
00007accb5bd4b65  lea rcx, [rsp+0x30]
00007accb5bd4b6a  mov r8d, 0x00
00007accb5bd4b70  lea r9, [r15+0x3A8]
00007accb5bd4b77  movaps [rdi], xmm13
00007accb5bd4b7b  movaps [rsi], xmm12
00007accb5bd4b7f  movaps [rdx], xmm14
00007accb5bd4b83  movaps [rcx], xmm1
00007accb5bd4b86  mov rax, 0x59156B40DA50
00007accb5bd4b90  call rax
00007accb5bd4b92  movaps xmm13, [rsp]
00007accb5bd4b97  add rsp, 0x40
00007accb5bd4b9b  vmovaps xmm0, [rsp]
00007accb5bd4ba0  vmovaps xmm1, [rsp+0x10]
00007accb5bd4ba6  vmovaps xmm2, [rsp+0x20]
00007accb5bd4bac  vmovaps xmm3, [rsp+0x30]
00007accb5bd4bb2  vmovaps xmm4, [rsp+0x40]
00007accb5bd4bb8  vmovaps xmm5, [rsp+0x50]
00007accb5bd4bbe  vmovaps xmm6, [rsp+0x60]
00007accb5bd4bc4  vmovaps xmm7, [rsp+0x70]
00007accb5bd4bca  vmovaps xmm8, [rsp+0x80]
00007accb5bd4bd3  vmovaps xmm9, [rsp+0x90]
00007accb5bd4bdc  vmovaps xmm10, [rsp+0xA0]
00007accb5bd4be5  vmovaps xmm11, [rsp+0xB0]
00007accb5bd4bee  vmovaps xmm12, [rsp+0xC0]
00007accb5bd4bf7  vmovaps xmm14, [rsp+0xD0]
00007accb5bd4c00  vmovaps xmm15, [rsp+0xE0]
00007accb5bd4c09  add rsp, 0xF0
00007accb5bd4c10  pop r11
00007accb5bd4c12  pop r10
00007accb5bd4c14  pop r9
00007accb5bd4c16  pop r8
00007accb5bd4c18  pop rsi
00007accb5bd4c19  pop rdi
00007accb5bd4c1a  pop rdx
00007accb5bd4c1b  pop rcx
00007accb5bd4c1c  pop rax
00007accb5bd4c1d  add rsp, 0x08
00007accb5bd4c21  jmp 0x00007ACCB5BD36AA
00007accb5bd4c26  sub rsp, 0x08
00007accb5bd4c2a  push rax
00007accb5bd4c2b  push rcx
00007accb5bd4c2c  push rdx
00007accb5bd4c2d  push rdi
00007accb5bd4c2e  push rsi
00007accb5bd4c2f  push r8
00007accb5bd4c31  push r9
00007accb5bd4c33  push r10
00007accb5bd4c35  push r11
00007accb5bd4c37  sub rsp, 0xF0
00007accb5bd4c3e  vmovaps [rsp], xmm0
00007accb5bd4c43  vmovaps [rsp+0x10], xmm1
00007accb5bd4c49  vmovaps [rsp+0x20], xmm2
00007accb5bd4c4f  vmovaps [rsp+0x30], xmm3
00007accb5bd4c55  vmovaps [rsp+0x40], xmm4
00007accb5bd4c5b  vmovaps [rsp+0x50], xmm5
00007accb5bd4c61  vmovaps [rsp+0x60], xmm6
00007accb5bd4c67  vmovaps [rsp+0x70], xmm7
00007accb5bd4c6d  vmovaps [rsp+0x80], xmm8
00007accb5bd4c76  vmovaps [rsp+0x90], xmm9
00007accb5bd4c7f  vmovaps [rsp+0xA0], xmm10
00007accb5bd4c88  vmovaps [rsp+0xB0], xmm11
00007accb5bd4c91  vmovaps [rsp+0xC0], xmm13
00007accb5bd4c9a  vmovaps [rsp+0xD0], xmm14
00007accb5bd4ca3  vmovaps [rsp+0xE0], xmm15
00007accb5bd4cac  sub rsp, 0x40
00007accb5bd4cb0  lea rdi, [rsp]
00007accb5bd4cb4  lea rsi, [rsp+0x10]
00007accb5bd4cb9  lea rdx, [rsp+0x20]
00007accb5bd4cbe  lea rcx, [rsp+0x30]
00007accb5bd4cc3  mov r8d, 0x00
00007accb5bd4cc9  lea r9, [r15+0x3A8]
00007accb5bd4cd0  movaps [rdi], xmm12
00007accb5bd4cd4  movaps [rsi], xmm5
00007accb5bd4cd7  movaps [rdx], xmm14
00007accb5bd4cdb  movaps [rcx], xmm4
00007accb5bd4cde  mov rax, 0x59156B40DA50
00007accb5bd4ce8  call rax
00007accb5bd4cea  movaps xmm12, [rsp]
00007accb5bd4cef  add rsp, 0x40
00007accb5bd4cf3  vmovaps xmm0, [rsp]
00007accb5bd4cf8  vmovaps xmm1, [rsp+0x10]
00007accb5bd4cfe  vmovaps xmm2, [rsp+0x20]
00007accb5bd4d04  vmovaps xmm3, [rsp+0x30]
00007accb5bd4d0a  vmovaps xmm4, [rsp+0x40]
00007accb5bd4d10  vmovaps xmm5, [rsp+0x50]
00007accb5bd4d16  vmovaps xmm6, [rsp+0x60]
00007accb5bd4d1c  vmovaps xmm7, [rsp+0x70]
00007accb5bd4d22  vmovaps xmm8, [rsp+0x80]
00007accb5bd4d2b  vmovaps xmm9, [rsp+0x90]
00007accb5bd4d34  vmovaps xmm10, [rsp+0xA0]
00007accb5bd4d3d  vmovaps xmm11, [rsp+0xB0]
00007accb5bd4d46  vmovaps xmm13, [rsp+0xC0]
00007accb5bd4d4f  vmovaps xmm14, [rsp+0xD0]
00007accb5bd4d58  vmovaps xmm15, [rsp+0xE0]
00007accb5bd4d61  add rsp, 0xF0
00007accb5bd4d68  pop r11
00007accb5bd4d6a  pop r10
00007accb5bd4d6c  pop r9
00007accb5bd4d6e  pop r8
00007accb5bd4d70  pop rsi
00007accb5bd4d71  pop rdi
00007accb5bd4d72  pop rdx
00007accb5bd4d73  pop rcx
00007accb5bd4d74  pop rax
00007accb5bd4d75  add rsp, 0x08
00007accb5bd4d79  jmp 0x00007ACCB5BD3720
00007accb5bd4d7e  sub rsp, 0x08
00007accb5bd4d82  push rax
00007accb5bd4d83  push rcx
00007accb5bd4d84  push rdx
00007accb5bd4d85  push rdi
00007accb5bd4d86  push rsi
00007accb5bd4d87  push r8
00007accb5bd4d89  push r9
00007accb5bd4d8b  push r10
00007accb5bd4d8d  push r11
00007accb5bd4d8f  sub rsp, 0xF0
00007accb5bd4d96  vmovaps [rsp], xmm0
00007accb5bd4d9b  vmovaps [rsp+0x10], xmm1
00007accb5bd4da1  vmovaps [rsp+0x20], xmm2
00007accb5bd4da7  vmovaps [rsp+0x30], xmm3
00007accb5bd4dad  vmovaps [rsp+0x40], xmm4
00007accb5bd4db3  vmovaps [rsp+0x50], xmm5
00007accb5bd4db9  vmovaps [rsp+0x60], xmm6
00007accb5bd4dbf  vmovaps [rsp+0x70], xmm7
00007accb5bd4dc5  vmovaps [rsp+0x80], xmm8
00007accb5bd4dce  vmovaps [rsp+0x90], xmm9
00007accb5bd4dd7  vmovaps [rsp+0xA0], xmm11
00007accb5bd4de0  vmovaps [rsp+0xB0], xmm12
00007accb5bd4de9  vmovaps [rsp+0xC0], xmm13
00007accb5bd4df2  vmovaps [rsp+0xD0], xmm14
00007accb5bd4dfb  vmovaps [rsp+0xE0], xmm15
00007accb5bd4e04  sub rsp, 0x40
00007accb5bd4e08  lea rdi, [rsp]
00007accb5bd4e0c  lea rsi, [rsp+0x10]
00007accb5bd4e11  lea rdx, [rsp+0x20]
00007accb5bd4e16  lea rcx, [rsp+0x30]
00007accb5bd4e1b  mov r8d, 0x00
00007accb5bd4e21  lea r9, [r15+0x3A8]
00007accb5bd4e28  movaps [rdi], xmm10
00007accb5bd4e2c  movaps [rsi], xmm2
00007accb5bd4e2f  movaps [rdx], xmm6
00007accb5bd4e32  movaps [rcx], xmm14
00007accb5bd4e36  mov rax, 0x59156B40DA50
00007accb5bd4e40  call rax
00007accb5bd4e42  movaps xmm10, [rsp]
00007accb5bd4e47  add rsp, 0x40
00007accb5bd4e4b  vmovaps xmm0, [rsp]
00007accb5bd4e50  vmovaps xmm1, [rsp+0x10]
00007accb5bd4e56  vmovaps xmm2, [rsp+0x20]
00007accb5bd4e5c  vmovaps xmm3, [rsp+0x30]
00007accb5bd4e62  vmovaps xmm4, [rsp+0x40]
00007accb5bd4e68  vmovaps xmm5, [rsp+0x50]
00007accb5bd4e6e  vmovaps xmm6, [rsp+0x60]
00007accb5bd4e74  vmovaps xmm7, [rsp+0x70]
00007accb5bd4e7a  vmovaps xmm8, [rsp+0x80]
00007accb5bd4e83  vmovaps xmm9, [rsp+0x90]
00007accb5bd4e8c  vmovaps xmm11, [rsp+0xA0]
00007accb5bd4e95  vmovaps xmm12, [rsp+0xB0]
00007accb5bd4e9e  vmovaps xmm13, [rsp+0xC0]
00007accb5bd4ea7  vmovaps xmm14, [rsp+0xD0]
00007accb5bd4eb0  vmovaps xmm15, [rsp+0xE0]
00007accb5bd4eb9  add rsp, 0xF0
00007accb5bd4ec0  pop r11
00007accb5bd4ec2  pop r10
00007accb5bd4ec4  pop r9
00007accb5bd4ec6  pop r8
00007accb5bd4ec8  pop rsi
00007accb5bd4ec9  pop rdi
00007accb5bd4eca  pop rdx
00007accb5bd4ecb  pop rcx
00007accb5bd4ecc  pop rax
00007accb5bd4ecd  add rsp, 0x08
00007accb5bd4ed1  jmp 0x00007ACCB5BD3746
00007accb5bd4ed6  call 0x00007ACCB5AE45A0
00007accb5bd4edb  jmp 0x00007ACCB5BD3753
00007accb5bd4ee0  sub rsp, 0x08
00007accb5bd4ee4  push rax
00007accb5bd4ee5  push rcx
00007accb5bd4ee6  push rdx
00007accb5bd4ee7  push rdi
00007accb5bd4ee8  push rsi
00007accb5bd4ee9  push r8
00007accb5bd4eeb  push r9
00007accb5bd4eed  push r10
00007accb5bd4eef  push r11
00007accb5bd4ef1  sub rsp, 0xF0
00007accb5bd4ef8  vmovaps [rsp], xmm0
00007accb5bd4efd  vmovaps [rsp+0x10], xmm1
00007accb5bd4f03  vmovaps [rsp+0x20], xmm2
00007accb5bd4f09  vmovaps [rsp+0x30], xmm3
00007accb5bd4f0f  vmovaps [rsp+0x40], xmm4
00007accb5bd4f15  vmovaps [rsp+0x50], xmm6
00007accb5bd4f1b  vmovaps [rsp+0x60], xmm7
00007accb5bd4f21  vmovaps [rsp+0x70], xmm8
00007accb5bd4f27  vmovaps [rsp+0x80], xmm9
00007accb5bd4f30  vmovaps [rsp+0x90], xmm10
00007accb5bd4f39  vmovaps [rsp+0xA0], xmm11
00007accb5bd4f42  vmovaps [rsp+0xB0], xmm12
00007accb5bd4f4b  vmovaps [rsp+0xC0], xmm13
00007accb5bd4f54  vmovaps [rsp+0xD0], xmm14
00007accb5bd4f5d  vmovaps [rsp+0xE0], xmm15
00007accb5bd4f66  sub rsp, 0x40
00007accb5bd4f6a  lea rdi, [rsp]
00007accb5bd4f6e  lea rsi, [rsp+0x10]
00007accb5bd4f73  lea rdx, [rsp+0x20]
00007accb5bd4f78  lea rcx, [rsp+0x30]
00007accb5bd4f7d  mov r8d, 0x00
00007accb5bd4f83  lea r9, [r15+0x3A8]
00007accb5bd4f8a  movaps [rdi], xmm5
00007accb5bd4f8d  movaps [rsi], xmm15
00007accb5bd4f91  movaps [rdx], xmm6
00007accb5bd4f94  movaps [rcx], xmm8
00007accb5bd4f98  mov rax, 0x59156B40DA50
00007accb5bd4fa2  call rax
00007accb5bd4fa4  movaps xmm5, [rsp]
00007accb5bd4fa8  add rsp, 0x40
00007accb5bd4fac  vmovaps xmm0, [rsp]
00007accb5bd4fb1  vmovaps xmm1, [rsp+0x10]
00007accb5bd4fb7  vmovaps xmm2, [rsp+0x20]
00007accb5bd4fbd  vmovaps xmm3, [rsp+0x30]
00007accb5bd4fc3  vmovaps xmm4, [rsp+0x40]
00007accb5bd4fc9  vmovaps xmm6, [rsp+0x50]
00007accb5bd4fcf  vmovaps xmm7, [rsp+0x60]
00007accb5bd4fd5  vmovaps xmm8, [rsp+0x70]
00007accb5bd4fdb  vmovaps xmm9, [rsp+0x80]
00007accb5bd4fe4  vmovaps xmm10, [rsp+0x90]
00007accb5bd4fed  vmovaps xmm11, [rsp+0xA0]
00007accb5bd4ff6  vmovaps xmm12, [rsp+0xB0]
00007accb5bd4fff  vmovaps xmm13, [rsp+0xC0]
00007accb5bd5008  vmovaps xmm14, [rsp+0xD0]
00007accb5bd5011  vmovaps xmm15, [rsp+0xE0]
00007accb5bd501a  add rsp, 0xF0
00007accb5bd5021  pop r11
00007accb5bd5023  pop r10
00007accb5bd5025  pop r9
00007accb5bd5027  pop r8
00007accb5bd5029  pop rsi
00007accb5bd502a  pop rdi
00007accb5bd502b  pop rdx
00007accb5bd502c  pop rcx
00007accb5bd502d  pop rax
00007accb5bd502e  add rsp, 0x08
00007accb5bd5032  jmp 0x00007ACCB5BD3789
00007accb5bd5037  sub rsp, 0x08
00007accb5bd503b  push rax
00007accb5bd503c  push rcx
00007accb5bd503d  push rdx
00007accb5bd503e  push rdi
00007accb5bd503f  push rsi
00007accb5bd5040  push r8
00007accb5bd5042  push r9
00007accb5bd5044  push r10
00007accb5bd5046  push r11
00007accb5bd5048  sub rsp, 0xF0
00007accb5bd504f  vmovaps [rsp], xmm0
00007accb5bd5054  vmovaps [rsp+0x10], xmm1
00007accb5bd505a  vmovaps [rsp+0x20], xmm2
00007accb5bd5060  vmovaps [rsp+0x30], xmm3
00007accb5bd5066  vmovaps [rsp+0x40], xmm4
00007accb5bd506c  vmovaps [rsp+0x50], xmm5
00007accb5bd5072  vmovaps [rsp+0x60], xmm6
00007accb5bd5078  vmovaps [rsp+0x70], xmm7
00007accb5bd507e  vmovaps [rsp+0x80], xmm9
00007accb5bd5087  vmovaps [rsp+0x90], xmm10
00007accb5bd5090  vmovaps [rsp+0xA0], xmm11
00007accb5bd5099  vmovaps [rsp+0xB0], xmm12
00007accb5bd50a2  vmovaps [rsp+0xC0], xmm13
00007accb5bd50ab  vmovaps [rsp+0xD0], xmm14
00007accb5bd50b4  vmovaps [rsp+0xE0], xmm15
00007accb5bd50bd  sub rsp, 0x40
00007accb5bd50c1  lea rdi, [rsp]
00007accb5bd50c5  lea rsi, [rsp+0x10]
00007accb5bd50ca  lea rdx, [rsp+0x20]
00007accb5bd50cf  lea rcx, [rsp+0x30]
00007accb5bd50d4  mov r8d, 0x00
00007accb5bd50da  lea r9, [r15+0x3A8]
00007accb5bd50e1  movaps [rdi], xmm8
00007accb5bd50e5  movaps [rsi], xmm13
00007accb5bd50e9  movaps [rdx], xmm1
00007accb5bd50ec  movaps [rcx], xmm15
00007accb5bd50f0  mov rax, 0x59156B40DA50
00007accb5bd50fa  call rax
00007accb5bd50fc  movaps xmm8, [rsp]
00007accb5bd5101  add rsp, 0x40
00007accb5bd5105  vmovaps xmm0, [rsp]
00007accb5bd510a  vmovaps xmm1, [rsp+0x10]
00007accb5bd5110  vmovaps xmm2, [rsp+0x20]
00007accb5bd5116  vmovaps xmm3, [rsp+0x30]
00007accb5bd511c  vmovaps xmm4, [rsp+0x40]
00007accb5bd5122  vmovaps xmm5, [rsp+0x50]
00007accb5bd5128  vmovaps xmm6, [rsp+0x60]
00007accb5bd512e  vmovaps xmm7, [rsp+0x70]
00007accb5bd5134  vmovaps xmm9, [rsp+0x80]
00007accb5bd513d  vmovaps xmm10, [rsp+0x90]
00007accb5bd5146  vmovaps xmm11, [rsp+0xA0]
00007accb5bd514f  vmovaps xmm12, [rsp+0xB0]
00007accb5bd5158  vmovaps xmm13, [rsp+0xC0]
00007accb5bd5161  vmovaps xmm14, [rsp+0xD0]
00007accb5bd516a  vmovaps xmm15, [rsp+0xE0]
00007accb5bd5173  add rsp, 0xF0
00007accb5bd517a  pop r11
00007accb5bd517c  pop r10
00007accb5bd517e  pop r9
00007accb5bd5180  pop r8
00007accb5bd5182  pop rsi
00007accb5bd5183  pop rdi
00007accb5bd5184  pop rdx
00007accb5bd5185  pop rcx
00007accb5bd5186  pop rax
00007accb5bd5187  add rsp, 0x08
00007accb5bd518b  jmp 0x00007ACCB5BD37AF
00007accb5bd5190  call 0x00007ACCB5AE5820
00007accb5bd5195  jmp 0x00007ACCB5BD37D2
00007accb5bd519a  call 0x00007ACCB5AE3320
00007accb5bd519f  jmp 0x00007ACCB5BD37DC
00007accb5bd51a4  sub rsp, 0x08
00007accb5bd51a8  push rax
00007accb5bd51a9  push rcx
00007accb5bd51aa  push rdx
00007accb5bd51ab  push rdi
00007accb5bd51ac  push rsi
00007accb5bd51ad  push r8
00007accb5bd51af  push r9
00007accb5bd51b1  push r10
00007accb5bd51b3  push r11
00007accb5bd51b5  sub rsp, 0xF0
00007accb5bd51bc  vmovaps [rsp], xmm0
00007accb5bd51c1  vmovaps [rsp+0x10], xmm1
00007accb5bd51c7  vmovaps [rsp+0x20], xmm2
00007accb5bd51cd  vmovaps [rsp+0x30], xmm3
00007accb5bd51d3  vmovaps [rsp+0x40], xmm5
00007accb5bd51d9  vmovaps [rsp+0x50], xmm6
00007accb5bd51df  vmovaps [rsp+0x60], xmm7
00007accb5bd51e5  vmovaps [rsp+0x70], xmm8
00007accb5bd51eb  vmovaps [rsp+0x80], xmm9
00007accb5bd51f4  vmovaps [rsp+0x90], xmm10
00007accb5bd51fd  vmovaps [rsp+0xA0], xmm11
00007accb5bd5206  vmovaps [rsp+0xB0], xmm12
00007accb5bd520f  vmovaps [rsp+0xC0], xmm13
00007accb5bd5218  vmovaps [rsp+0xD0], xmm14
00007accb5bd5221  vmovaps [rsp+0xE0], xmm15
00007accb5bd522a  sub rsp, 0x40
00007accb5bd522e  lea rdi, [rsp]
00007accb5bd5232  lea rsi, [rsp+0x10]
00007accb5bd5237  lea rdx, [rsp+0x20]
00007accb5bd523c  lea rcx, [rsp+0x30]
00007accb5bd5241  mov r8d, 0x00
00007accb5bd5247  lea r9, [r15+0x3A8]
00007accb5bd524e  movaps [rdi], xmm4
00007accb5bd5251  movaps [rsi], xmm12
00007accb5bd5255  movaps [rdx], xmm9
00007accb5bd5259  movaps [rcx], xmm6
00007accb5bd525c  mov rax, 0x59156B40DA50
00007accb5bd5266  call rax
00007accb5bd5268  movaps xmm4, [rsp]
00007accb5bd526c  add rsp, 0x40
00007accb5bd5270  vmovaps xmm0, [rsp]
00007accb5bd5275  vmovaps xmm1, [rsp+0x10]
00007accb5bd527b  vmovaps xmm2, [rsp+0x20]
00007accb5bd5281  vmovaps xmm3, [rsp+0x30]
00007accb5bd5287  vmovaps xmm5, [rsp+0x40]
00007accb5bd528d  vmovaps xmm6, [rsp+0x50]
00007accb5bd5293  vmovaps xmm7, [rsp+0x60]
00007accb5bd5299  vmovaps xmm8, [rsp+0x70]
00007accb5bd529f  vmovaps xmm9, [rsp+0x80]
00007accb5bd52a8  vmovaps xmm10, [rsp+0x90]
00007accb5bd52b1  vmovaps xmm11, [rsp+0xA0]
00007accb5bd52ba  vmovaps xmm12, [rsp+0xB0]
00007accb5bd52c3  vmovaps xmm13, [rsp+0xC0]
00007accb5bd52cc  vmovaps xmm14, [rsp+0xD0]
00007accb5bd52d5  vmovaps xmm15, [rsp+0xE0]
00007accb5bd52de  add rsp, 0xF0
00007accb5bd52e5  pop r11
00007accb5bd52e7  pop r10
00007accb5bd52e9  pop r9
00007accb5bd52eb  pop r8
00007accb5bd52ed  pop rsi
00007accb5bd52ee  pop rdi
00007accb5bd52ef  pop rdx
00007accb5bd52f0  pop rcx
00007accb5bd52f1  pop rax
00007accb5bd52f2  add rsp, 0x08
00007accb5bd52f6  jmp 0x00007ACCB5BD3814
00007accb5bd52fb  sub rsp, 0x08
00007accb5bd52ff  push rax
00007accb5bd5300  push rcx
00007accb5bd5301  push rdx
00007accb5bd5302  push rdi
00007accb5bd5303  push rsi
00007accb5bd5304  push r8
00007accb5bd5306  push r9
00007accb5bd5308  push r10
00007accb5bd530a  push r11
00007accb5bd530c  sub rsp, 0xF0
00007accb5bd5313  vmovaps [rsp], xmm0
00007accb5bd5318  vmovaps [rsp+0x10], xmm1
00007accb5bd531e  vmovaps [rsp+0x20], xmm2
00007accb5bd5324  vmovaps [rsp+0x30], xmm3
00007accb5bd532a  vmovaps [rsp+0x40], xmm4
00007accb5bd5330  vmovaps [rsp+0x50], xmm5
00007accb5bd5336  vmovaps [rsp+0x60], xmm6
00007accb5bd533c  vmovaps [rsp+0x70], xmm7
00007accb5bd5342  vmovaps [rsp+0x80], xmm8
00007accb5bd534b  vmovaps [rsp+0x90], xmm10
00007accb5bd5354  vmovaps [rsp+0xA0], xmm11
00007accb5bd535d  vmovaps [rsp+0xB0], xmm12
00007accb5bd5366  vmovaps [rsp+0xC0], xmm13
00007accb5bd536f  vmovaps [rsp+0xD0], xmm14
00007accb5bd5378  vmovaps [rsp+0xE0], xmm15
00007accb5bd5381  sub rsp, 0x40
00007accb5bd5385  lea rdi, [rsp]
00007accb5bd5389  lea rsi, [rsp+0x10]
00007accb5bd538e  lea rdx, [rsp+0x20]
00007accb5bd5393  lea rcx, [rsp+0x30]
00007accb5bd5398  mov r8d, 0x00
00007accb5bd539e  lea r9, [r15+0x3A8]
00007accb5bd53a5  movaps [rdi], xmm9
00007accb5bd53a9  movaps [rsi], xmm10
00007accb5bd53ad  movaps [rdx], xmm1
00007accb5bd53b0  movaps [rcx], xmm12
00007accb5bd53b4  mov rax, 0x59156B40DA50
00007accb5bd53be  call rax
00007accb5bd53c0  movaps xmm9, [rsp]
00007accb5bd53c5  add rsp, 0x40
00007accb5bd53c9  vmovaps xmm0, [rsp]
00007accb5bd53ce  vmovaps xmm1, [rsp+0x10]
00007accb5bd53d4  vmovaps xmm2, [rsp+0x20]
00007accb5bd53da  vmovaps xmm3, [rsp+0x30]
00007accb5bd53e0  vmovaps xmm4, [rsp+0x40]
00007accb5bd53e6  vmovaps xmm5, [rsp+0x50]
00007accb5bd53ec  vmovaps xmm6, [rsp+0x60]
00007accb5bd53f2  vmovaps xmm7, [rsp+0x70]
00007accb5bd53f8  vmovaps xmm8, [rsp+0x80]
00007accb5bd5401  vmovaps xmm10, [rsp+0x90]
00007accb5bd540a  vmovaps xmm11, [rsp+0xA0]
00007accb5bd5413  vmovaps xmm12, [rsp+0xB0]
00007accb5bd541c  vmovaps xmm13, [rsp+0xC0]
00007accb5bd5425  vmovaps xmm14, [rsp+0xD0]
00007accb5bd542e  vmovaps xmm15, [rsp+0xE0]
00007accb5bd5437  add rsp, 0xF0
00007accb5bd543e  pop r11
00007accb5bd5440  pop r10
00007accb5bd5442  pop r9
00007accb5bd5444  pop r8
00007accb5bd5446  pop rsi
00007accb5bd5447  pop rdi
00007accb5bd5448  pop rdx
00007accb5bd5449  pop rcx
00007accb5bd544a  pop rax
00007accb5bd544b  add rsp, 0x08
00007accb5bd544f  jmp 0x00007ACCB5BD383D
00007accb5bd5454  sub rsp, 0x08
00007accb5bd5458  push rax
00007accb5bd5459  push rcx
00007accb5bd545a  push rdx
00007accb5bd545b  push rdi
00007accb5bd545c  push rsi
00007accb5bd545d  push r8
00007accb5bd545f  push r9
00007accb5bd5461  push r10
00007accb5bd5463  push r11
00007accb5bd5465  sub rsp, 0xF0
00007accb5bd546c  vmovaps [rsp], xmm0
00007accb5bd5471  vmovaps [rsp+0x10], xmm1
00007accb5bd5477  vmovaps [rsp+0x20], xmm2
00007accb5bd547d  vmovaps [rsp+0x30], xmm3
00007accb5bd5483  vmovaps [rsp+0x40], xmm4
00007accb5bd5489  vmovaps [rsp+0x50], xmm5
00007accb5bd548f  vmovaps [rsp+0x60], xmm6
00007accb5bd5495  vmovaps [rsp+0x70], xmm7
00007accb5bd549b  vmovaps [rsp+0x80], xmm8
00007accb5bd54a4  vmovaps [rsp+0x90], xmm9
00007accb5bd54ad  vmovaps [rsp+0xA0], xmm11
00007accb5bd54b6  vmovaps [rsp+0xB0], xmm12
00007accb5bd54bf  vmovaps [rsp+0xC0], xmm13
00007accb5bd54c8  vmovaps [rsp+0xD0], xmm14
00007accb5bd54d1  vmovaps [rsp+0xE0], xmm15
00007accb5bd54da  sub rsp, 0x40
00007accb5bd54de  lea rdi, [rsp]
00007accb5bd54e2  lea rsi, [rsp+0x10]
00007accb5bd54e7  lea rdx, [rsp+0x20]
00007accb5bd54ec  lea rcx, [rsp+0x30]
00007accb5bd54f1  mov r8d, 0x00
00007accb5bd54f7  lea r9, [r15+0x3A8]
00007accb5bd54fe  movaps [rdi], xmm10
00007accb5bd5502  movaps [rsi], xmm5
00007accb5bd5505  movaps [rdx], xmm12
00007accb5bd5509  movaps [rcx], xmm1
00007accb5bd550c  mov rax, 0x59156B40DA50
00007accb5bd5516  call rax
00007accb5bd5518  movaps xmm10, [rsp]
00007accb5bd551d  add rsp, 0x40
00007accb5bd5521  vmovaps xmm0, [rsp]
00007accb5bd5526  vmovaps xmm1, [rsp+0x10]
00007accb5bd552c  vmovaps xmm2, [rsp+0x20]
00007accb5bd5532  vmovaps xmm3, [rsp+0x30]
00007accb5bd5538  vmovaps xmm4, [rsp+0x40]
00007accb5bd553e  vmovaps xmm5, [rsp+0x50]
00007accb5bd5544  vmovaps xmm6, [rsp+0x60]
00007accb5bd554a  vmovaps xmm7, [rsp+0x70]
00007accb5bd5550  vmovaps xmm8, [rsp+0x80]
00007accb5bd5559  vmovaps xmm9, [rsp+0x90]
00007accb5bd5562  vmovaps xmm11, [rsp+0xA0]
00007accb5bd556b  vmovaps xmm12, [rsp+0xB0]
00007accb5bd5574  vmovaps xmm13, [rsp+0xC0]
00007accb5bd557d  vmovaps xmm14, [rsp+0xD0]
00007accb5bd5586  vmovaps xmm15, [rsp+0xE0]
00007accb5bd558f  add rsp, 0xF0
00007accb5bd5596  pop r11
00007accb5bd5598  pop r10
00007accb5bd559a  pop r9
00007accb5bd559c  pop r8
00007accb5bd559e  pop rsi
00007accb5bd559f  pop rdi
00007accb5bd55a0  pop rdx
00007accb5bd55a1  pop rcx
00007accb5bd55a2  pop rax
00007accb5bd55a3  add rsp, 0x08
00007accb5bd55a7  jmp 0x00007ACCB5BD386C
00007accb5bd55ac  sub rsp, 0x08
00007accb5bd55b0  push rax
00007accb5bd55b1  push rcx
00007accb5bd55b2  push rdx
00007accb5bd55b3  push rdi
00007accb5bd55b4  push rsi
00007accb5bd55b5  push r8
00007accb5bd55b7  push r9
00007accb5bd55b9  push r10
00007accb5bd55bb  push r11
00007accb5bd55bd  sub rsp, 0xF0
00007accb5bd55c4  vmovaps [rsp], xmm0
00007accb5bd55c9  vmovaps [rsp+0x10], xmm1
00007accb5bd55cf  vmovaps [rsp+0x20], xmm2
00007accb5bd55d5  vmovaps [rsp+0x30], xmm3
00007accb5bd55db  vmovaps [rsp+0x40], xmm4
00007accb5bd55e1  vmovaps [rsp+0x50], xmm5
00007accb5bd55e7  vmovaps [rsp+0x60], xmm7
00007accb5bd55ed  vmovaps [rsp+0x70], xmm8
00007accb5bd55f3  vmovaps [rsp+0x80], xmm9
00007accb5bd55fc  vmovaps [rsp+0x90], xmm10
00007accb5bd5605  vmovaps [rsp+0xA0], xmm11
00007accb5bd560e  vmovaps [rsp+0xB0], xmm12
00007accb5bd5617  vmovaps [rsp+0xC0], xmm13
00007accb5bd5620  vmovaps [rsp+0xD0], xmm14
00007accb5bd5629  vmovaps [rsp+0xE0], xmm15
00007accb5bd5632  sub rsp, 0x40
00007accb5bd5636  lea rdi, [rsp]
00007accb5bd563a  lea rsi, [rsp+0x10]
00007accb5bd563f  lea rdx, [rsp+0x20]
00007accb5bd5644  lea rcx, [rsp+0x30]
00007accb5bd5649  mov r8d, 0x00
00007accb5bd564f  lea r9, [r15+0x3A8]
00007accb5bd5656  movaps [rdi], xmm6
00007accb5bd5659  movaps [rsi], xmm8
00007accb5bd565d  movaps [rdx], xmm12
00007accb5bd5661  movaps [rcx], xmm1
00007accb5bd5664  mov rax, 0x59156B40DA50
00007accb5bd566e  call rax
00007accb5bd5670  movaps xmm6, [rsp]
00007accb5bd5674  add rsp, 0x40
00007accb5bd5678  vmovaps xmm0, [rsp]
00007accb5bd567d  vmovaps xmm1, [rsp+0x10]
00007accb5bd5683  vmovaps xmm2, [rsp+0x20]
00007accb5bd5689  vmovaps xmm3, [rsp+0x30]
00007accb5bd568f  vmovaps xmm4, [rsp+0x40]
00007accb5bd5695  vmovaps xmm5, [rsp+0x50]
00007accb5bd569b  vmovaps xmm7, [rsp+0x60]
00007accb5bd56a1  vmovaps xmm8, [rsp+0x70]
00007accb5bd56a7  vmovaps xmm9, [rsp+0x80]
00007accb5bd56b0  vmovaps xmm10, [rsp+0x90]
00007accb5bd56b9  vmovaps xmm11, [rsp+0xA0]
00007accb5bd56c2  vmovaps xmm12, [rsp+0xB0]
00007accb5bd56cb  vmovaps xmm13, [rsp+0xC0]
00007accb5bd56d4  vmovaps xmm14, [rsp+0xD0]
00007accb5bd56dd  vmovaps xmm15, [rsp+0xE0]
00007accb5bd56e6  add rsp, 0xF0
00007accb5bd56ed  pop r11
00007accb5bd56ef  pop r10
00007accb5bd56f1  pop r9
00007accb5bd56f3  pop r8
00007accb5bd56f5  pop rsi
00007accb5bd56f6  pop rdi
00007accb5bd56f7  pop rdx
00007accb5bd56f8  pop rcx
00007accb5bd56f9  pop rax
00007accb5bd56fa  add rsp, 0x08
00007accb5bd56fe  jmp 0x00007ACCB5BD389A
00007accb5bd5703  call 0x00007ACCB5AD64F0
00007accb5bd5708  jmp 0x00007ACCB5BD38A4
00007accb5bd570d  call 0x00007ACCB5AE20A0
00007accb5bd5712  jmp 0x00007ACCB5BD38AE
00007accb5bd5717  sub rsp, 0x08
00007accb5bd571b  push rax
00007accb5bd571c  push rcx
00007accb5bd571d  push rdx
00007accb5bd571e  push rdi
00007accb5bd571f  push rsi
00007accb5bd5720  push r8
00007accb5bd5722  push r9
00007accb5bd5724  push r10
00007accb5bd5726  push r11
00007accb5bd5728  sub rsp, 0xF0
00007accb5bd572f  vmovaps [rsp], xmm0
00007accb5bd5734  vmovaps [rsp+0x10], xmm1
00007accb5bd573a  vmovaps [rsp+0x20], xmm2
00007accb5bd5740  vmovaps [rsp+0x30], xmm3
00007accb5bd5746  vmovaps [rsp+0x40], xmm4
00007accb5bd574c  vmovaps [rsp+0x50], xmm5
00007accb5bd5752  vmovaps [rsp+0x60], xmm6
00007accb5bd5758  vmovaps [rsp+0x70], xmm7
00007accb5bd575e  vmovaps [rsp+0x80], xmm9
00007accb5bd5767  vmovaps [rsp+0x90], xmm10
00007accb5bd5770  vmovaps [rsp+0xA0], xmm11
00007accb5bd5779  vmovaps [rsp+0xB0], xmm12
00007accb5bd5782  vmovaps [rsp+0xC0], xmm13
00007accb5bd578b  vmovaps [rsp+0xD0], xmm14
00007accb5bd5794  vmovaps [rsp+0xE0], xmm15
00007accb5bd579d  sub rsp, 0x40
00007accb5bd57a1  lea rdi, [rsp]
00007accb5bd57a5  lea rsi, [rsp+0x10]
00007accb5bd57aa  lea rdx, [rsp+0x20]
00007accb5bd57af  lea rcx, [rsp+0x30]
00007accb5bd57b4  mov r8d, 0x00
00007accb5bd57ba  lea r9, [r15+0x3A8]
00007accb5bd57c1  movaps [rdi], xmm8
00007accb5bd57c5  movaps [rsi], xmm4
00007accb5bd57c8  movaps [rdx], xmm13
00007accb5bd57cc  movaps [rcx], xmm11
00007accb5bd57d0  mov rax, 0x59156B40DA50
00007accb5bd57da  call rax
00007accb5bd57dc  movaps xmm8, [rsp]
00007accb5bd57e1  add rsp, 0x40
00007accb5bd57e5  vmovaps xmm0, [rsp]
00007accb5bd57ea  vmovaps xmm1, [rsp+0x10]
00007accb5bd57f0  vmovaps xmm2, [rsp+0x20]
00007accb5bd57f6  vmovaps xmm3, [rsp+0x30]
00007accb5bd57fc  vmovaps xmm4, [rsp+0x40]
00007accb5bd5802  vmovaps xmm5, [rsp+0x50]
00007accb5bd5808  vmovaps xmm6, [rsp+0x60]
00007accb5bd580e  vmovaps xmm7, [rsp+0x70]
00007accb5bd5814  vmovaps xmm9, [rsp+0x80]
00007accb5bd581d  vmovaps xmm10, [rsp+0x90]
00007accb5bd5826  vmovaps xmm11, [rsp+0xA0]
00007accb5bd582f  vmovaps xmm12, [rsp+0xB0]
00007accb5bd5838  vmovaps xmm13, [rsp+0xC0]
00007accb5bd5841  vmovaps xmm14, [rsp+0xD0]
00007accb5bd584a  vmovaps xmm15, [rsp+0xE0]
00007accb5bd5853  add rsp, 0xF0
00007accb5bd585a  pop r11
00007accb5bd585c  pop r10
00007accb5bd585e  pop r9
00007accb5bd5860  pop r8
00007accb5bd5862  pop rsi
00007accb5bd5863  pop rdi
00007accb5bd5864  pop rdx
00007accb5bd5865  pop rcx
00007accb5bd5866  pop rax
00007accb5bd5867  add rsp, 0x08
00007accb5bd586b  jmp 0x00007ACCB5BD38E4
00007accb5bd5870  sub rsp, 0x08
00007accb5bd5874  push rax
00007accb5bd5875  push rcx
00007accb5bd5876  push rdx
00007accb5bd5877  push rdi
00007accb5bd5878  push rsi
00007accb5bd5879  push r8
00007accb5bd587b  push r9
00007accb5bd587d  push r10
00007accb5bd587f  push r11
00007accb5bd5881  sub rsp, 0xF0
00007accb5bd5888  vmovaps [rsp], xmm0
00007accb5bd588d  vmovaps [rsp+0x10], xmm1
00007accb5bd5893  vmovaps [rsp+0x20], xmm2
00007accb5bd5899  vmovaps [rsp+0x30], xmm3
00007accb5bd589f  vmovaps [rsp+0x40], xmm4
00007accb5bd58a5  vmovaps [rsp+0x50], xmm5
00007accb5bd58ab  vmovaps [rsp+0x60], xmm6
00007accb5bd58b1  vmovaps [rsp+0x70], xmm7
00007accb5bd58b7  vmovaps [rsp+0x80], xmm8
00007accb5bd58c0  vmovaps [rsp+0x90], xmm9
00007accb5bd58c9  vmovaps [rsp+0xA0], xmm10
00007accb5bd58d2  vmovaps [rsp+0xB0], xmm12
00007accb5bd58db  vmovaps [rsp+0xC0], xmm13
00007accb5bd58e4  vmovaps [rsp+0xD0], xmm14
00007accb5bd58ed  vmovaps [rsp+0xE0], xmm15
00007accb5bd58f6  sub rsp, 0x40
00007accb5bd58fa  lea rdi, [rsp]
00007accb5bd58fe  lea rsi, [rsp+0x10]
00007accb5bd5903  lea rdx, [rsp+0x20]
00007accb5bd5908  lea rcx, [rsp+0x30]
00007accb5bd590d  mov r8d, 0x00
00007accb5bd5913  lea r9, [r15+0x3A8]
00007accb5bd591a  movaps [rdi], xmm11
00007accb5bd591e  movaps [rsi], xmm9
00007accb5bd5922  movaps [rdx], xmm1
00007accb5bd5925  movaps [rcx], xmm13
00007accb5bd5929  mov rax, 0x59156B40DA50
00007accb5bd5933  call rax
00007accb5bd5935  movaps xmm11, [rsp]
00007accb5bd593a  add rsp, 0x40
00007accb5bd593e  vmovaps xmm0, [rsp]
00007accb5bd5943  vmovaps xmm1, [rsp+0x10]
00007accb5bd5949  vmovaps xmm2, [rsp+0x20]
00007accb5bd594f  vmovaps xmm3, [rsp+0x30]
00007accb5bd5955  vmovaps xmm4, [rsp+0x40]
00007accb5bd595b  vmovaps xmm5, [rsp+0x50]
00007accb5bd5961  vmovaps xmm6, [rsp+0x60]
00007accb5bd5967  vmovaps xmm7, [rsp+0x70]
00007accb5bd596d  vmovaps xmm8, [rsp+0x80]
00007accb5bd5976  vmovaps xmm9, [rsp+0x90]
00007accb5bd597f  vmovaps xmm10, [rsp+0xA0]
00007accb5bd5988  vmovaps xmm12, [rsp+0xB0]
00007accb5bd5991  vmovaps xmm13, [rsp+0xC0]
00007accb5bd599a  vmovaps xmm14, [rsp+0xD0]
00007accb5bd59a3  vmovaps xmm15, [rsp+0xE0]
00007accb5bd59ac  add rsp, 0xF0
00007accb5bd59b3  pop r11
00007accb5bd59b5  pop r10
00007accb5bd59b7  pop r9
00007accb5bd59b9  pop r8
00007accb5bd59bb  pop rsi
00007accb5bd59bc  pop rdi
00007accb5bd59bd  pop rdx
00007accb5bd59be  pop rcx
00007accb5bd59bf  pop rax
00007accb5bd59c0  add rsp, 0x08
00007accb5bd59c4  jmp 0x00007ACCB5BD390A
00007accb5bd59c9  sub rsp, 0x08
00007accb5bd59cd  push rax
00007accb5bd59ce  push rcx
00007accb5bd59cf  push rdx
00007accb5bd59d0  push rdi
00007accb5bd59d1  push rsi
00007accb5bd59d2  push r8
00007accb5bd59d4  push r9
00007accb5bd59d6  push r10
00007accb5bd59d8  push r11
00007accb5bd59da  sub rsp, 0xF0
00007accb5bd59e1  vmovaps [rsp], xmm0
00007accb5bd59e6  vmovaps [rsp+0x10], xmm1
00007accb5bd59ec  vmovaps [rsp+0x20], xmm2
00007accb5bd59f2  vmovaps [rsp+0x30], xmm3
00007accb5bd59f8  vmovaps [rsp+0x40], xmm4
00007accb5bd59fe  vmovaps [rsp+0x50], xmm5
00007accb5bd5a04  vmovaps [rsp+0x60], xmm6
00007accb5bd5a0a  vmovaps [rsp+0x70], xmm7
00007accb5bd5a10  vmovaps [rsp+0x80], xmm8
00007accb5bd5a19  vmovaps [rsp+0x90], xmm9
00007accb5bd5a22  vmovaps [rsp+0xA0], xmm10
00007accb5bd5a2b  vmovaps [rsp+0xB0], xmm11
00007accb5bd5a34  vmovaps [rsp+0xC0], xmm12
00007accb5bd5a3d  vmovaps [rsp+0xD0], xmm14
00007accb5bd5a46  vmovaps [rsp+0xE0], xmm15
00007accb5bd5a4f  sub rsp, 0x40
00007accb5bd5a53  lea rdi, [rsp]
00007accb5bd5a57  lea rsi, [rsp+0x10]
00007accb5bd5a5c  lea rdx, [rsp+0x20]
00007accb5bd5a61  lea rcx, [rsp+0x30]
00007accb5bd5a66  mov r8d, 0x00
00007accb5bd5a6c  lea r9, [r15+0x3A8]
00007accb5bd5a73  movaps [rdi], xmm13
00007accb5bd5a77  movaps [rsi], xmm10
00007accb5bd5a7b  movaps [rdx], xmm7
00007accb5bd5a7e  movaps [rcx], xmm1
00007accb5bd5a81  mov rax, 0x59156B40DA50
00007accb5bd5a8b  call rax
00007accb5bd5a8d  movaps xmm13, [rsp]
00007accb5bd5a92  add rsp, 0x40
00007accb5bd5a96  vmovaps xmm0, [rsp]
00007accb5bd5a9b  vmovaps xmm1, [rsp+0x10]
00007accb5bd5aa1  vmovaps xmm2, [rsp+0x20]
00007accb5bd5aa7  vmovaps xmm3, [rsp+0x30]
00007accb5bd5aad  vmovaps xmm4, [rsp+0x40]
00007accb5bd5ab3  vmovaps xmm5, [rsp+0x50]
00007accb5bd5ab9  vmovaps xmm6, [rsp+0x60]
00007accb5bd5abf  vmovaps xmm7, [rsp+0x70]
00007accb5bd5ac5  vmovaps xmm8, [rsp+0x80]
00007accb5bd5ace  vmovaps xmm9, [rsp+0x90]
00007accb5bd5ad7  vmovaps xmm10, [rsp+0xA0]
00007accb5bd5ae0  vmovaps xmm11, [rsp+0xB0]
00007accb5bd5ae9  vmovaps xmm12, [rsp+0xC0]
00007accb5bd5af2  vmovaps xmm14, [rsp+0xD0]
00007accb5bd5afb  vmovaps xmm15, [rsp+0xE0]
00007accb5bd5b04  add rsp, 0xF0
00007accb5bd5b0b  pop r11
00007accb5bd5b0d  pop r10
00007accb5bd5b0f  pop r9
00007accb5bd5b11  pop r8
00007accb5bd5b13  pop rsi
00007accb5bd5b14  pop rdi
00007accb5bd5b15  pop rdx
00007accb5bd5b16  pop rcx
00007accb5bd5b17  pop rax
00007accb5bd5b18  add rsp, 0x08
00007accb5bd5b1c  jmp 0x00007ACCB5BD3930
00007accb5bd5b21  sub rsp, 0x08
00007accb5bd5b25  push rax
00007accb5bd5b26  push rcx
00007accb5bd5b27  push rdx
00007accb5bd5b28  push rdi
00007accb5bd5b29  push rsi
00007accb5bd5b2a  push r8
00007accb5bd5b2c  push r9
00007accb5bd5b2e  push r10
00007accb5bd5b30  push r11
00007accb5bd5b32  sub rsp, 0xF0
00007accb5bd5b39  vmovaps [rsp], xmm0
00007accb5bd5b3e  vmovaps [rsp+0x10], xmm1
00007accb5bd5b44  vmovaps [rsp+0x20], xmm2
00007accb5bd5b4a  vmovaps [rsp+0x30], xmm3
00007accb5bd5b50  vmovaps [rsp+0x40], xmm4
00007accb5bd5b56  vmovaps [rsp+0x50], xmm5
00007accb5bd5b5c  vmovaps [rsp+0x60], xmm6
00007accb5bd5b62  vmovaps [rsp+0x70], xmm7
00007accb5bd5b68  vmovaps [rsp+0x80], xmm8
00007accb5bd5b71  vmovaps [rsp+0x90], xmm9
00007accb5bd5b7a  vmovaps [rsp+0xA0], xmm11
00007accb5bd5b83  vmovaps [rsp+0xB0], xmm12
00007accb5bd5b8c  vmovaps [rsp+0xC0], xmm13
00007accb5bd5b95  vmovaps [rsp+0xD0], xmm14
00007accb5bd5b9e  vmovaps [rsp+0xE0], xmm15
00007accb5bd5ba7  sub rsp, 0x40
00007accb5bd5bab  lea rdi, [rsp]
00007accb5bd5baf  lea rsi, [rsp+0x10]
00007accb5bd5bb4  lea rdx, [rsp+0x20]
00007accb5bd5bb9  lea rcx, [rsp+0x30]
00007accb5bd5bbe  mov r8d, 0x00
00007accb5bd5bc4  lea r9, [r15+0x3A8]
00007accb5bd5bcb  movaps [rdi], xmm10
00007accb5bd5bcf  movaps [rsi], xmm6
00007accb5bd5bd2  movaps [rdx], xmm15
00007accb5bd5bd6  movaps [rcx], xmm1
00007accb5bd5bd9  mov rax, 0x59156B40DA50
00007accb5bd5be3  call rax
00007accb5bd5be5  movaps xmm10, [rsp]
00007accb5bd5bea  add rsp, 0x40
00007accb5bd5bee  vmovaps xmm0, [rsp]
00007accb5bd5bf3  vmovaps xmm1, [rsp+0x10]
00007accb5bd5bf9  vmovaps xmm2, [rsp+0x20]
00007accb5bd5bff  vmovaps xmm3, [rsp+0x30]
00007accb5bd5c05  vmovaps xmm4, [rsp+0x40]
00007accb5bd5c0b  vmovaps xmm5, [rsp+0x50]
00007accb5bd5c11  vmovaps xmm6, [rsp+0x60]
00007accb5bd5c17  vmovaps xmm7, [rsp+0x70]
00007accb5bd5c1d  vmovaps xmm8, [rsp+0x80]
00007accb5bd5c26  vmovaps xmm9, [rsp+0x90]
00007accb5bd5c2f  vmovaps xmm11, [rsp+0xA0]
00007accb5bd5c38  vmovaps xmm12, [rsp+0xB0]
00007accb5bd5c41  vmovaps xmm13, [rsp+0xC0]
00007accb5bd5c4a  vmovaps xmm14, [rsp+0xD0]
00007accb5bd5c53  vmovaps xmm15, [rsp+0xE0]
00007accb5bd5c5c  add rsp, 0xF0
00007accb5bd5c63  pop r11
00007accb5bd5c65  pop r10
00007accb5bd5c67  pop r9
00007accb5bd5c69  pop r8
00007accb5bd5c6b  pop rsi
00007accb5bd5c6c  pop rdi
00007accb5bd5c6d  pop rdx
00007accb5bd5c6e  pop rcx
00007accb5bd5c6f  pop rax
00007accb5bd5c70  add rsp, 0x08
00007accb5bd5c74  jmp 0x00007ACCB5BD3956
00007accb5bd5c79  call 0x00007ACCB5AD64F0
00007accb5bd5c7e  jmp 0x00007ACCB5BD3960
00007accb5bd5c83  call 0x00007ACCB5AE5820
00007accb5bd5c88  jmp 0x00007ACCB5BD396A
00007accb5bd5c8d  sub rsp, 0x08
00007accb5bd5c91  push rax
00007accb5bd5c92  push rcx
00007accb5bd5c93  push rdx
00007accb5bd5c94  push rdi
00007accb5bd5c95  push rsi
00007accb5bd5c96  push r8
00007accb5bd5c98  push r9
00007accb5bd5c9a  push r10
00007accb5bd5c9c  push r11
00007accb5bd5c9e  sub rsp, 0xF0
00007accb5bd5ca5  vmovaps [rsp], xmm0
00007accb5bd5caa  vmovaps [rsp+0x10], xmm1
00007accb5bd5cb0  vmovaps [rsp+0x20], xmm2
00007accb5bd5cb6  vmovaps [rsp+0x30], xmm3
00007accb5bd5cbc  vmovaps [rsp+0x40], xmm4
00007accb5bd5cc2  vmovaps [rsp+0x50], xmm5
00007accb5bd5cc8  vmovaps [rsp+0x60], xmm6
00007accb5bd5cce  vmovaps [rsp+0x70], xmm8
00007accb5bd5cd4  vmovaps [rsp+0x80], xmm9
00007accb5bd5cdd  vmovaps [rsp+0x90], xmm10
00007accb5bd5ce6  vmovaps [rsp+0xA0], xmm11
00007accb5bd5cef  vmovaps [rsp+0xB0], xmm12
00007accb5bd5cf8  vmovaps [rsp+0xC0], xmm13
00007accb5bd5d01  vmovaps [rsp+0xD0], xmm14
00007accb5bd5d0a  vmovaps [rsp+0xE0], xmm15
00007accb5bd5d13  sub rsp, 0x40
00007accb5bd5d17  lea rdi, [rsp]
00007accb5bd5d1b  lea rsi, [rsp+0x10]
00007accb5bd5d20  lea rdx, [rsp+0x20]
00007accb5bd5d25  lea rcx, [rsp+0x30]
00007accb5bd5d2a  mov r8d, 0x00
00007accb5bd5d30  lea r9, [r15+0x3A8]
00007accb5bd5d37  movaps [rdi], xmm7
00007accb5bd5d3a  movaps [rsi], xmm8
00007accb5bd5d3e  movaps [rdx], xmm3
00007accb5bd5d41  movaps [rcx], xmm9
00007accb5bd5d45  mov rax, 0x59156B40DA50
00007accb5bd5d4f  call rax
00007accb5bd5d51  movaps xmm7, [rsp]
00007accb5bd5d55  add rsp, 0x40
00007accb5bd5d59  vmovaps xmm0, [rsp]
00007accb5bd5d5e  vmovaps xmm1, [rsp+0x10]
00007accb5bd5d64  vmovaps xmm2, [rsp+0x20]
00007accb5bd5d6a  vmovaps xmm3, [rsp+0x30]
00007accb5bd5d70  vmovaps xmm4, [rsp+0x40]
00007accb5bd5d76  vmovaps xmm5, [rsp+0x50]
00007accb5bd5d7c  vmovaps xmm6, [rsp+0x60]
00007accb5bd5d82  vmovaps xmm8, [rsp+0x70]
00007accb5bd5d88  vmovaps xmm9, [rsp+0x80]
00007accb5bd5d91  vmovaps xmm10, [rsp+0x90]
00007accb5bd5d9a  vmovaps xmm11, [rsp+0xA0]
00007accb5bd5da3  vmovaps xmm12, [rsp+0xB0]
00007accb5bd5dac  vmovaps xmm13, [rsp+0xC0]
00007accb5bd5db5  vmovaps xmm14, [rsp+0xD0]
00007accb5bd5dbe  vmovaps xmm15, [rsp+0xE0]
00007accb5bd5dc7  add rsp, 0xF0
00007accb5bd5dce  pop r11
00007accb5bd5dd0  pop r10
00007accb5bd5dd2  pop r9
00007accb5bd5dd4  pop r8
00007accb5bd5dd6  pop rsi
00007accb5bd5dd7  pop rdi
00007accb5bd5dd8  pop rdx
00007accb5bd5dd9  pop rcx
00007accb5bd5dda  pop rax
00007accb5bd5ddb  add rsp, 0x08
00007accb5bd5ddf  jmp 0x00007ACCB5BD3992
00007accb5bd5de4  sub rsp, 0x08
00007accb5bd5de8  push rax
00007accb5bd5de9  push rcx
00007accb5bd5dea  push rdx
00007accb5bd5deb  push rdi
00007accb5bd5dec  push rsi
00007accb5bd5ded  push r8
00007accb5bd5def  push r9
00007accb5bd5df1  push r10
00007accb5bd5df3  push r11
00007accb5bd5df5  sub rsp, 0xF0
00007accb5bd5dfc  vmovaps [rsp], xmm0
00007accb5bd5e01  vmovaps [rsp+0x10], xmm1
00007accb5bd5e07  vmovaps [rsp+0x20], xmm2
00007accb5bd5e0d  vmovaps [rsp+0x30], xmm3
00007accb5bd5e13  vmovaps [rsp+0x40], xmm4
00007accb5bd5e19  vmovaps [rsp+0x50], xmm5
00007accb5bd5e1f  vmovaps [rsp+0x60], xmm6
00007accb5bd5e25  vmovaps [rsp+0x70], xmm7
00007accb5bd5e2b  vmovaps [rsp+0x80], xmm9
00007accb5bd5e34  vmovaps [rsp+0x90], xmm10
00007accb5bd5e3d  vmovaps [rsp+0xA0], xmm11
00007accb5bd5e46  vmovaps [rsp+0xB0], xmm12
00007accb5bd5e4f  vmovaps [rsp+0xC0], xmm13
00007accb5bd5e58  vmovaps [rsp+0xD0], xmm14
00007accb5bd5e61  vmovaps [rsp+0xE0], xmm15
00007accb5bd5e6a  sub rsp, 0x40
00007accb5bd5e6e  lea rdi, [rsp]
00007accb5bd5e72  lea rsi, [rsp+0x10]
00007accb5bd5e77  lea rdx, [rsp+0x20]
00007accb5bd5e7c  lea rcx, [rsp+0x30]
00007accb5bd5e81  mov r8d, 0x00
00007accb5bd5e87  lea r9, [r15+0x3A8]
00007accb5bd5e8e  movaps [rdi], xmm8
00007accb5bd5e92  movaps [rsi], xmm11
00007accb5bd5e96  movaps [rdx], xmm14
00007accb5bd5e9a  movaps [rcx], xmm9
00007accb5bd5e9e  mov rax, 0x59156B40DA50
00007accb5bd5ea8  call rax
00007accb5bd5eaa  movaps xmm8, [rsp]
00007accb5bd5eaf  add rsp, 0x40
00007accb5bd5eb3  vmovaps xmm0, [rsp]
00007accb5bd5eb8  vmovaps xmm1, [rsp+0x10]
00007accb5bd5ebe  vmovaps xmm2, [rsp+0x20]
00007accb5bd5ec4  vmovaps xmm3, [rsp+0x30]
00007accb5bd5eca  vmovaps xmm4, [rsp+0x40]
00007accb5bd5ed0  vmovaps xmm5, [rsp+0x50]
00007accb5bd5ed6  vmovaps xmm6, [rsp+0x60]
00007accb5bd5edc  vmovaps xmm7, [rsp+0x70]
00007accb5bd5ee2  vmovaps xmm9, [rsp+0x80]
00007accb5bd5eeb  vmovaps xmm10, [rsp+0x90]
00007accb5bd5ef4  vmovaps xmm11, [rsp+0xA0]
00007accb5bd5efd  vmovaps xmm12, [rsp+0xB0]
00007accb5bd5f06  vmovaps xmm13, [rsp+0xC0]
00007accb5bd5f0f  vmovaps xmm14, [rsp+0xD0]
00007accb5bd5f18  vmovaps xmm15, [rsp+0xE0]
00007accb5bd5f21  add rsp, 0xF0
00007accb5bd5f28  pop r11
00007accb5bd5f2a  pop r10
00007accb5bd5f2c  pop r9
00007accb5bd5f2e  pop r8
00007accb5bd5f30  pop rsi
00007accb5bd5f31  pop rdi
00007accb5bd5f32  pop rdx
00007accb5bd5f33  pop rcx
00007accb5bd5f34  pop rax
00007accb5bd5f35  add rsp, 0x08
00007accb5bd5f39  jmp 0x00007ACCB5BD39BB
00007accb5bd5f3e  sub rsp, 0x08
00007accb5bd5f42  push rax
00007accb5bd5f43  push rcx
00007accb5bd5f44  push rdx
00007accb5bd5f45  push rdi
00007accb5bd5f46  push rsi
00007accb5bd5f47  push r8
00007accb5bd5f49  push r9
00007accb5bd5f4b  push r10
00007accb5bd5f4d  push r11
00007accb5bd5f4f  sub rsp, 0xF0
00007accb5bd5f56  vmovaps [rsp], xmm0
00007accb5bd5f5b  vmovaps [rsp+0x10], xmm1
00007accb5bd5f61  vmovaps [rsp+0x20], xmm2
00007accb5bd5f67  vmovaps [rsp+0x30], xmm3
00007accb5bd5f6d  vmovaps [rsp+0x40], xmm4
00007accb5bd5f73  vmovaps [rsp+0x50], xmm5
00007accb5bd5f79  vmovaps [rsp+0x60], xmm6
00007accb5bd5f7f  vmovaps [rsp+0x70], xmm7
00007accb5bd5f85  vmovaps [rsp+0x80], xmm8
00007accb5bd5f8e  vmovaps [rsp+0x90], xmm9
00007accb5bd5f97  vmovaps [rsp+0xA0], xmm10
00007accb5bd5fa0  vmovaps [rsp+0xB0], xmm12
00007accb5bd5fa9  vmovaps [rsp+0xC0], xmm13
00007accb5bd5fb2  vmovaps [rsp+0xD0], xmm14
00007accb5bd5fbb  vmovaps [rsp+0xE0], xmm15
00007accb5bd5fc4  sub rsp, 0x40
00007accb5bd5fc8  lea rdi, [rsp]
00007accb5bd5fcc  lea rsi, [rsp+0x10]
00007accb5bd5fd1  lea rdx, [rsp+0x20]
00007accb5bd5fd6  lea rcx, [rsp+0x30]
00007accb5bd5fdb  mov r8d, 0x00
00007accb5bd5fe1  lea r9, [r15+0x3A8]
00007accb5bd5fe8  movaps [rdi], xmm11
00007accb5bd5fec  movaps [rsi], xmm13
00007accb5bd5ff0  movaps [rdx], xmm12
00007accb5bd5ff4  movaps [rcx], xmm14
00007accb5bd5ff8  mov rax, 0x59156B40DA50
00007accb5bd6002  call rax
00007accb5bd6004  movaps xmm11, [rsp]
00007accb5bd6009  add rsp, 0x40
00007accb5bd600d  vmovaps xmm0, [rsp]
00007accb5bd6012  vmovaps xmm1, [rsp+0x10]
00007accb5bd6018  vmovaps xmm2, [rsp+0x20]
00007accb5bd601e  vmovaps xmm3, [rsp+0x30]
00007accb5bd6024  vmovaps xmm4, [rsp+0x40]
00007accb5bd602a  vmovaps xmm5, [rsp+0x50]
00007accb5bd6030  vmovaps xmm6, [rsp+0x60]
00007accb5bd6036  vmovaps xmm7, [rsp+0x70]
00007accb5bd603c  vmovaps xmm8, [rsp+0x80]
00007accb5bd6045  vmovaps xmm9, [rsp+0x90]
00007accb5bd604e  vmovaps xmm10, [rsp+0xA0]
00007accb5bd6057  vmovaps xmm12, [rsp+0xB0]
00007accb5bd6060  vmovaps xmm13, [rsp+0xC0]
00007accb5bd6069  vmovaps xmm14, [rsp+0xD0]
00007accb5bd6072  vmovaps xmm15, [rsp+0xE0]
00007accb5bd607b  add rsp, 0xF0
00007accb5bd6082  pop r11
00007accb5bd6084  pop r10
00007accb5bd6086  pop r9
00007accb5bd6088  pop r8
00007accb5bd608a  pop rsi
00007accb5bd608b  pop rdi
00007accb5bd608c  pop rdx
00007accb5bd608d  pop rcx
00007accb5bd608e  pop rax
00007accb5bd608f  add rsp, 0x08
00007accb5bd6093  jmp 0x00007ACCB5BD39E4
00007accb5bd6098  sub rsp, 0x08
00007accb5bd609c  push rax
00007accb5bd609d  push rcx
00007accb5bd609e  push rdx
00007accb5bd609f  push rdi
00007accb5bd60a0  push rsi
00007accb5bd60a1  push r8
00007accb5bd60a3  push r9
00007accb5bd60a5  push r10
00007accb5bd60a7  push r11
00007accb5bd60a9  sub rsp, 0xF0
00007accb5bd60b0  vmovaps [rsp], xmm0
00007accb5bd60b5  vmovaps [rsp+0x10], xmm1
00007accb5bd60bb  vmovaps [rsp+0x20], xmm2
00007accb5bd60c1  vmovaps [rsp+0x30], xmm3
00007accb5bd60c7  vmovaps [rsp+0x40], xmm4
00007accb5bd60cd  vmovaps [rsp+0x50], xmm5
00007accb5bd60d3  vmovaps [rsp+0x60], xmm6
00007accb5bd60d9  vmovaps [rsp+0x70], xmm7
00007accb5bd60df  vmovaps [rsp+0x80], xmm8
00007accb5bd60e8  vmovaps [rsp+0x90], xmm9
00007accb5bd60f1  vmovaps [rsp+0xA0], xmm10
00007accb5bd60fa  vmovaps [rsp+0xB0], xmm11
00007accb5bd6103  vmovaps [rsp+0xC0], xmm13
00007accb5bd610c  vmovaps [rsp+0xD0], xmm14
00007accb5bd6115  vmovaps [rsp+0xE0], xmm15
00007accb5bd611e  sub rsp, 0x40
00007accb5bd6122  lea rdi, [rsp]
00007accb5bd6126  lea rsi, [rsp+0x10]
00007accb5bd612b  lea rdx, [rsp+0x20]
00007accb5bd6130  lea rcx, [rsp+0x30]
00007accb5bd6135  mov r8d, 0x00
00007accb5bd613b  lea r9, [r15+0x3A8]
00007accb5bd6142  movaps [rdi], xmm12
00007accb5bd6146  movaps [rsi], xmm10
00007accb5bd614a  movaps [rdx], xmm15
00007accb5bd614e  movaps [rcx], xmm14
00007accb5bd6152  mov rax, 0x59156B40DA50
00007accb5bd615c  call rax
00007accb5bd615e  movaps xmm12, [rsp]
00007accb5bd6163  add rsp, 0x40
00007accb5bd6167  vmovaps xmm0, [rsp]
00007accb5bd616c  vmovaps xmm1, [rsp+0x10]
00007accb5bd6172  vmovaps xmm2, [rsp+0x20]
00007accb5bd6178  vmovaps xmm3, [rsp+0x30]
00007accb5bd617e  vmovaps xmm4, [rsp+0x40]
00007accb5bd6184  vmovaps xmm5, [rsp+0x50]
00007accb5bd618a  vmovaps xmm6, [rsp+0x60]
00007accb5bd6190  vmovaps xmm7, [rsp+0x70]
00007accb5bd6196  vmovaps xmm8, [rsp+0x80]
00007accb5bd619f  vmovaps xmm9, [rsp+0x90]
00007accb5bd61a8  vmovaps xmm10, [rsp+0xA0]
00007accb5bd61b1  vmovaps xmm11, [rsp+0xB0]
00007accb5bd61ba  vmovaps xmm13, [rsp+0xC0]
00007accb5bd61c3  vmovaps xmm14, [rsp+0xD0]
00007accb5bd61cc  vmovaps xmm15, [rsp+0xE0]
00007accb5bd61d5  add rsp, 0xF0
00007accb5bd61dc  pop r11
00007accb5bd61de  pop r10
00007accb5bd61e0  pop r9
00007accb5bd61e2  pop r8
00007accb5bd61e4  pop rsi
00007accb5bd61e5  pop rdi
00007accb5bd61e6  pop rdx
00007accb5bd61e7  pop rcx
00007accb5bd61e8  pop rax
00007accb5bd61e9  add rsp, 0x08
00007accb5bd61ed  jmp 0x00007ACCB5BD3A0D
00007accb5bd61f2  call 0x00007ACCB5AE5820
00007accb5bd61f7  jmp 0x00007ACCB5BD3A1A
00007accb5bd61fc  call 0x00007ACCB5AE45A0
00007accb5bd6201  jmp 0x00007ACCB5BD3A27
00007accb5bd6206  sub rsp, 0x08
00007accb5bd620a  push rax
00007accb5bd620b  push rcx
00007accb5bd620c  push rdx
00007accb5bd620d  push rdi
00007accb5bd620e  push rsi
00007accb5bd620f  push r8
00007accb5bd6211  push r9
00007accb5bd6213  push r10
00007accb5bd6215  push r11
00007accb5bd6217  sub rsp, 0xF0
00007accb5bd621e  vmovaps [rsp], xmm0
00007accb5bd6223  vmovaps [rsp+0x10], xmm1
00007accb5bd6229  vmovaps [rsp+0x20], xmm2
00007accb5bd622f  vmovaps [rsp+0x30], xmm3
00007accb5bd6235  vmovaps [rsp+0x40], xmm4
00007accb5bd623b  vmovaps [rsp+0x50], xmm5
00007accb5bd6241  vmovaps [rsp+0x60], xmm6
00007accb5bd6247  vmovaps [rsp+0x70], xmm7
00007accb5bd624d  vmovaps [rsp+0x80], xmm8
00007accb5bd6256  vmovaps [rsp+0x90], xmm9
00007accb5bd625f  vmovaps [rsp+0xA0], xmm11
00007accb5bd6268  vmovaps [rsp+0xB0], xmm12
00007accb5bd6271  vmovaps [rsp+0xC0], xmm13
00007accb5bd627a  vmovaps [rsp+0xD0], xmm14
00007accb5bd6283  vmovaps [rsp+0xE0], xmm15
00007accb5bd628c  sub rsp, 0x40
00007accb5bd6290  lea rdi, [rsp]
00007accb5bd6294  lea rsi, [rsp+0x10]
00007accb5bd6299  lea rdx, [rsp+0x20]
00007accb5bd629e  lea rcx, [rsp+0x30]
00007accb5bd62a3  mov r8d, 0x00
00007accb5bd62a9  lea r9, [r15+0x3A8]
00007accb5bd62b0  movaps [rdi], xmm10
00007accb5bd62b4  movaps [rsi], xmm7
00007accb5bd62b7  movaps [rdx], xmm1
00007accb5bd62ba  movaps [rcx], xmm13
00007accb5bd62be  mov rax, 0x59156B40DA50
00007accb5bd62c8  call rax
00007accb5bd62ca  movaps xmm10, [rsp]
00007accb5bd62cf  add rsp, 0x40
00007accb5bd62d3  vmovaps xmm0, [rsp]
00007accb5bd62d8  vmovaps xmm1, [rsp+0x10]
00007accb5bd62de  vmovaps xmm2, [rsp+0x20]
00007accb5bd62e4  vmovaps xmm3, [rsp+0x30]
00007accb5bd62ea  vmovaps xmm4, [rsp+0x40]
00007accb5bd62f0  vmovaps xmm5, [rsp+0x50]
00007accb5bd62f6  vmovaps xmm6, [rsp+0x60]
00007accb5bd62fc  vmovaps xmm7, [rsp+0x70]
00007accb5bd6302  vmovaps xmm8, [rsp+0x80]
00007accb5bd630b  vmovaps xmm9, [rsp+0x90]
00007accb5bd6314  vmovaps xmm11, [rsp+0xA0]
00007accb5bd631d  vmovaps xmm12, [rsp+0xB0]
00007accb5bd6326  vmovaps xmm13, [rsp+0xC0]
00007accb5bd632f  vmovaps xmm14, [rsp+0xD0]
00007accb5bd6338  vmovaps xmm15, [rsp+0xE0]
00007accb5bd6341  add rsp, 0xF0
00007accb5bd6348  pop r11
00007accb5bd634a  pop r10
00007accb5bd634c  pop r9
00007accb5bd634e  pop r8
00007accb5bd6350  pop rsi
00007accb5bd6351  pop rdi
00007accb5bd6352  pop rdx
00007accb5bd6353  pop rcx
00007accb5bd6354  pop rax
00007accb5bd6355  add rsp, 0x08
00007accb5bd6359  jmp 0x00007ACCB5BD3A5D
00007accb5bd635e  call 0x00007ACCB5AD64F0
00007accb5bd6363  jmp 0x00007ACCB5BD3A6F
00007accb5bd6368  sub rsp, 0x08
00007accb5bd636c  push rax
00007accb5bd636d  push rcx
00007accb5bd636e  push rdx
00007accb5bd636f  push rdi
00007accb5bd6370  push rsi
00007accb5bd6371  push r8
00007accb5bd6373  push r9
00007accb5bd6375  push r10
00007accb5bd6377  push r11
00007accb5bd6379  sub rsp, 0xF0
00007accb5bd6380  vmovaps [rsp], xmm0
00007accb5bd6385  vmovaps [rsp+0x10], xmm1
00007accb5bd638b  vmovaps [rsp+0x20], xmm2
00007accb5bd6391  vmovaps [rsp+0x30], xmm3
00007accb5bd6397  vmovaps [rsp+0x40], xmm4
00007accb5bd639d  vmovaps [rsp+0x50], xmm5
00007accb5bd63a3  vmovaps [rsp+0x60], xmm6
00007accb5bd63a9  vmovaps [rsp+0x70], xmm7
00007accb5bd63af  vmovaps [rsp+0x80], xmm8
00007accb5bd63b8  vmovaps [rsp+0x90], xmm10
00007accb5bd63c1  vmovaps [rsp+0xA0], xmm11
00007accb5bd63ca  vmovaps [rsp+0xB0], xmm12
00007accb5bd63d3  vmovaps [rsp+0xC0], xmm13
00007accb5bd63dc  vmovaps [rsp+0xD0], xmm14
00007accb5bd63e5  vmovaps [rsp+0xE0], xmm15
00007accb5bd63ee  sub rsp, 0x40
00007accb5bd63f2  lea rdi, [rsp]
00007accb5bd63f6  lea rsi, [rsp+0x10]
00007accb5bd63fb  lea rdx, [rsp+0x20]
00007accb5bd6400  lea rcx, [rsp+0x30]
00007accb5bd6405  mov r8d, 0x00
00007accb5bd640b  lea r9, [r15+0x3A8]
00007accb5bd6412  movaps [rdi], xmm9
00007accb5bd6416  movaps [rsi], xmm8
00007accb5bd641a  movaps [rdx], xmm14
00007accb5bd641e  movaps [rcx], xmm13
00007accb5bd6422  mov rax, 0x59156B40DA50
00007accb5bd642c  call rax
00007accb5bd642e  movaps xmm9, [rsp]
00007accb5bd6433  add rsp, 0x40
00007accb5bd6437  vmovaps xmm0, [rsp]
00007accb5bd643c  vmovaps xmm1, [rsp+0x10]
00007accb5bd6442  vmovaps xmm2, [rsp+0x20]
00007accb5bd6448  vmovaps xmm3, [rsp+0x30]
00007accb5bd644e  vmovaps xmm4, [rsp+0x40]
00007accb5bd6454  vmovaps xmm5, [rsp+0x50]
00007accb5bd645a  vmovaps xmm6, [rsp+0x60]
00007accb5bd6460  vmovaps xmm7, [rsp+0x70]
00007accb5bd6466  vmovaps xmm8, [rsp+0x80]
00007accb5bd646f  vmovaps xmm10, [rsp+0x90]
00007accb5bd6478  vmovaps xmm11, [rsp+0xA0]
00007accb5bd6481  vmovaps xmm12, [rsp+0xB0]
00007accb5bd648a  vmovaps xmm13, [rsp+0xC0]
00007accb5bd6493  vmovaps xmm14, [rsp+0xD0]
00007accb5bd649c  vmovaps xmm15, [rsp+0xE0]
00007accb5bd64a5  add rsp, 0xF0
00007accb5bd64ac  pop r11
00007accb5bd64ae  pop r10
00007accb5bd64b0  pop r9
00007accb5bd64b2  pop r8
00007accb5bd64b4  pop rsi
00007accb5bd64b5  pop rdi
00007accb5bd64b6  pop rdx
00007accb5bd64b7  pop rcx
00007accb5bd64b8  pop rax
00007accb5bd64b9  add rsp, 0x08
00007accb5bd64bd  jmp 0x00007ACCB5BD3A9D
00007accb5bd64c2  sub rsp, 0x08
00007accb5bd64c6  push rax
00007accb5bd64c7  push rcx
00007accb5bd64c8  push rdx
00007accb5bd64c9  push rdi
00007accb5bd64ca  push rsi
00007accb5bd64cb  push r8
00007accb5bd64cd  push r9
00007accb5bd64cf  push r10
00007accb5bd64d1  push r11
00007accb5bd64d3  sub rsp, 0xF0
00007accb5bd64da  vmovaps [rsp], xmm0
00007accb5bd64df  vmovaps [rsp+0x10], xmm1
00007accb5bd64e5  vmovaps [rsp+0x20], xmm2
00007accb5bd64eb  vmovaps [rsp+0x30], xmm3
00007accb5bd64f1  vmovaps [rsp+0x40], xmm4
00007accb5bd64f7  vmovaps [rsp+0x50], xmm5
00007accb5bd64fd  vmovaps [rsp+0x60], xmm6
00007accb5bd6503  vmovaps [rsp+0x70], xmm7
00007accb5bd6509  vmovaps [rsp+0x80], xmm8
00007accb5bd6512  vmovaps [rsp+0x90], xmm9
00007accb5bd651b  vmovaps [rsp+0xA0], xmm10
00007accb5bd6524  vmovaps [rsp+0xB0], xmm11
00007accb5bd652d  vmovaps [rsp+0xC0], xmm12
00007accb5bd6536  vmovaps [rsp+0xD0], xmm14
00007accb5bd653f  vmovaps [rsp+0xE0], xmm15
00007accb5bd6548  sub rsp, 0x40
00007accb5bd654c  lea rdi, [rsp]
00007accb5bd6550  lea rsi, [rsp+0x10]
00007accb5bd6555  lea rdx, [rsp+0x20]
00007accb5bd655a  lea rcx, [rsp+0x30]
00007accb5bd655f  mov r8d, 0x00
00007accb5bd6565  lea r9, [r15+0x3A8]
00007accb5bd656c  movaps [rdi], xmm13
00007accb5bd6570  movaps [rsi], xmm11
00007accb5bd6574  movaps [rdx], xmm15
00007accb5bd6578  movaps [rcx], xmm14
00007accb5bd657c  mov rax, 0x59156B40DA50
00007accb5bd6586  call rax
00007accb5bd6588  movaps xmm13, [rsp]
00007accb5bd658d  add rsp, 0x40
00007accb5bd6591  vmovaps xmm0, [rsp]
00007accb5bd6596  vmovaps xmm1, [rsp+0x10]
00007accb5bd659c  vmovaps xmm2, [rsp+0x20]
00007accb5bd65a2  vmovaps xmm3, [rsp+0x30]
00007accb5bd65a8  vmovaps xmm4, [rsp+0x40]
00007accb5bd65ae  vmovaps xmm5, [rsp+0x50]
00007accb5bd65b4  vmovaps xmm6, [rsp+0x60]
00007accb5bd65ba  vmovaps xmm7, [rsp+0x70]
00007accb5bd65c0  vmovaps xmm8, [rsp+0x80]
00007accb5bd65c9  vmovaps xmm9, [rsp+0x90]
00007accb5bd65d2  vmovaps xmm10, [rsp+0xA0]
00007accb5bd65db  vmovaps xmm11, [rsp+0xB0]
00007accb5bd65e4  vmovaps xmm12, [rsp+0xC0]
00007accb5bd65ed  vmovaps xmm14, [rsp+0xD0]
00007accb5bd65f6  vmovaps xmm15, [rsp+0xE0]
00007accb5bd65ff  add rsp, 0xF0
00007accb5bd6606  pop r11
00007accb5bd6608  pop r10
00007accb5bd660a  pop r9
00007accb5bd660c  pop r8
00007accb5bd660e  pop rsi
00007accb5bd660f  pop rdi
00007accb5bd6610  pop rdx
00007accb5bd6611  pop rcx
00007accb5bd6612  pop rax
00007accb5bd6613  add rsp, 0x08
00007accb5bd6617  jmp 0x00007ACCB5BD3ACB
00007accb5bd661c  sub rsp, 0x08
00007accb5bd6620  push rax
00007accb5bd6621  push rcx
00007accb5bd6622  push rdx
00007accb5bd6623  push rdi
00007accb5bd6624  push rsi
00007accb5bd6625  push r8
00007accb5bd6627  push r9
00007accb5bd6629  push r10
00007accb5bd662b  push r11
00007accb5bd662d  sub rsp, 0xF0
00007accb5bd6634  vmovaps [rsp], xmm0
00007accb5bd6639  vmovaps [rsp+0x10], xmm1
00007accb5bd663f  vmovaps [rsp+0x20], xmm2
00007accb5bd6645  vmovaps [rsp+0x30], xmm3
00007accb5bd664b  vmovaps [rsp+0x40], xmm4
00007accb5bd6651  vmovaps [rsp+0x50], xmm5
00007accb5bd6657  vmovaps [rsp+0x60], xmm6
00007accb5bd665d  vmovaps [rsp+0x70], xmm7
00007accb5bd6663  vmovaps [rsp+0x80], xmm8
00007accb5bd666c  vmovaps [rsp+0x90], xmm9
00007accb5bd6675  vmovaps [rsp+0xA0], xmm10
00007accb5bd667e  vmovaps [rsp+0xB0], xmm11
00007accb5bd6687  vmovaps [rsp+0xC0], xmm12
00007accb5bd6690  vmovaps [rsp+0xD0], xmm13
00007accb5bd6699  vmovaps [rsp+0xE0], xmm15
00007accb5bd66a2  sub rsp, 0x40
00007accb5bd66a6  lea rdi, [rsp]
00007accb5bd66aa  lea rsi, [rsp+0x10]
00007accb5bd66af  lea rdx, [rsp+0x20]
00007accb5bd66b4  lea rcx, [rsp+0x30]
00007accb5bd66b9  mov r8d, 0x00
00007accb5bd66bf  lea r9, [r15+0x3A8]
00007accb5bd66c6  movaps [rdi], xmm14
00007accb5bd66ca  movaps [rsi], xmm12
00007accb5bd66ce  movaps [rdx], xmm1
00007accb5bd66d1  movaps [rcx], xmm15
00007accb5bd66d5  mov rax, 0x59156B40DA50
00007accb5bd66df  call rax
00007accb5bd66e1  movaps xmm14, [rsp]
00007accb5bd66e6  add rsp, 0x40
00007accb5bd66ea  vmovaps xmm0, [rsp]
00007accb5bd66ef  vmovaps xmm1, [rsp+0x10]
00007accb5bd66f5  vmovaps xmm2, [rsp+0x20]
00007accb5bd66fb  vmovaps xmm3, [rsp+0x30]
00007accb5bd6701  vmovaps xmm4, [rsp+0x40]
00007accb5bd6707  vmovaps xmm5, [rsp+0x50]
00007accb5bd670d  vmovaps xmm6, [rsp+0x60]
00007accb5bd6713  vmovaps xmm7, [rsp+0x70]
00007accb5bd6719  vmovaps xmm8, [rsp+0x80]
00007accb5bd6722  vmovaps xmm9, [rsp+0x90]
00007accb5bd672b  vmovaps xmm10, [rsp+0xA0]
00007accb5bd6734  vmovaps xmm11, [rsp+0xB0]
00007accb5bd673d  vmovaps xmm12, [rsp+0xC0]
00007accb5bd6746  vmovaps xmm13, [rsp+0xD0]
00007accb5bd674f  vmovaps xmm15, [rsp+0xE0]
00007accb5bd6758  add rsp, 0xF0
00007accb5bd675f  pop r11
00007accb5bd6761  pop r10
00007accb5bd6763  pop r9
00007accb5bd6765  pop r8
00007accb5bd6767  pop rsi
00007accb5bd6768  pop rdi
00007accb5bd6769  pop rdx
00007accb5bd676a  pop rcx
00007accb5bd676b  pop rax
00007accb5bd676c  add rsp, 0x08
00007accb5bd6770  jmp 0x00007ACCB5BD3AF9
00007accb5bd6775  call 0x00007ACCB5AACF70
00007accb5bd677a  jmp 0x00007ACCB5BD3B07
00007accb5bd677f  call 0x00007ACCB5A0C380
00007accb5bd6784  jmp 0x00007ACCB5BD3B11
00007accb5bd6789  call 0x00007ACCB5A08C20
00007accb5bd678e  jmp 0x00007ACCB5BD3B1B
00007accb5bd6793  call 0x00007ACCB5A0D600
00007accb5bd6798  jmp 0x00007ACCB5BD3B25
00007accb5bd679d  int3
00007accb5bd679e  nop
00007accb5bd67a0  mov eax, [r15+0x48]
00007accb5bd67a4  lea r14d, [eax+0x01]
00007accb5bd67a9  mov [rsp+0x10], r14d
00007accb5bd67ae  mov r14d, r14d
00007accb5bd67b1  mov [r15+0x48], r14
00007accb5bd67b5  xor eax, eax
00007accb5bd67b7  mov r14d, [rsp+0x10]
00007accb5bd67bc  cmp r14d, 0x1F4
00007accb5bd67c3  cmc
00007accb5bd67c4  lahf
00007accb5bd67c5  seto al
00007accb5bd67c8  mov [r15+0x108], eax
00007accb5bd67cf  mov eax, [r15+0x108]
00007accb5bd67d6  sahf
00007accb5bd67d7  jnz 0x00007ACCB5BD6809
00007accb5bd67d9  cmp dword ptr [r15+0x318], 0x00
00007accb5bd67e1  jz 0x00007ACCB5BDA1A0
00007accb5bd67e7  nop [rax+rax*1], ax
00007accb5bd67f0  nop [rax+rax*1], eax
00007accb5bd67f8  mov eax, 0x4103FC
00007accb5bd67fd  mov [r15+0x100], rax
00007accb5bd6804  jmp 0x00007ACCB59FE110
00007accb5bd6809  cmp dword ptr [r15+0x318], 0x00
00007accb5bd6811  jz 0x00007ACCB5BD6840
00007accb5bd6817  nop [rax+rax*1], ax
00007accb5bd6820  nop [rax+rax*1], eax
00007accb5bd6828  mov eax, 0x410270
00007accb5bd682d  mov [r15+0x100], rax
00007accb5bd6834  jmp 0x00007ACCB59FE110
00007accb5bd6839  int3
00007accb5bd683a  int3
00007accb5bd683b  nop [rax+rax*1], eax
00007accb5bd6840  mov rax, [r15+0x40]
00007accb5bd6844  vxorps xmm1, xmm1, xmm1
00007accb5bd6848  vpbroadcastq xmm1, xmm1
00007accb5bd684d  vxorps xmm15, xmm15, xmm15
00007accb5bd6852  vpbroadcastq xmm15, xmm15
00007accb5bd6857  lea r14, [rax+0x30]
00007accb5bd685b  mov r12, [r13+r14*1]
00007accb5bd6860  lea r14, [rax+0x38]
00007accb5bd6864  mov r11, [r13+r14*1]
00007accb5bd6869  movq xmm14, r12
00007accb5bd686e  movq xmm13, r11
00007accb5bd6873  movq xmm14, xmm14
00007accb5bd6878  movq xmm13, xmm13
00007accb5bd687d  vmovaps [rsp+0x10], xmm13
00007accb5bd6883  movq xmm13, xmm13
00007accb5bd6888  movaps [r15+0x270], xmm13
00007accb5bd6890  movaps xmm13, [r15+0x160]
00007accb5bd6898  vmovaps [rsp+0x20], xmm13
00007accb5bd689e  vmovaps xmm12, [rsp+0x20]
00007accb5bd68a4  por xmm13, xmm12
00007accb5bd68a9  lea r14, [rax+0x20]
00007accb5bd68ad  mov r12, [r13+r14*1]
00007accb5bd68b2  lea r14, [rax+0x28]
00007accb5bd68b6  mov r11, [r13+r14*1]
00007accb5bd68bb  movq xmm12, r12
00007accb5bd68c0  movq xmm11, r11
00007accb5bd68c5  movq xmm12, xmm12
00007accb5bd68ca  movq xmm11, xmm11
00007accb5bd68cf  movaps xmm10, [r15+0x2F0]
00007accb5bd68d7  vmovaps [rsp+0x20], xmm10
00007accb5bd68dd  vmovaps xmm9, [rsp+0x20]
00007accb5bd68e3  por xmm10, xmm9
00007accb5bd68e8  movaps xmm9, [r15+0x2D0]
00007accb5bd68f0  vmovaps [rsp+0x20], xmm9
00007accb5bd68f6  vmovaps xmm8, [rsp+0x20]
00007accb5bd68fc  por xmm9, xmm8
00007accb5bd6901  movaps xmm8, [r15+0x300]
00007accb5bd6909  vmovaps [rsp+0x20], xmm8
00007accb5bd690f  vmovaps xmm7, [rsp+0x20]
00007accb5bd6915  por xmm8, xmm7
00007accb5bd691a  movaps xmm7, [r15+0x2B0]
00007accb5bd6922  vmovaps [rsp+0x20], xmm7
00007accb5bd6928  vmovaps xmm6, [rsp+0x20]
00007accb5bd692e  por xmm7, xmm6
00007accb5bd6932  movaps xmm6, [r15+0x180]
00007accb5bd693a  vmovaps [rsp+0x20], xmm6
00007accb5bd6940  vmovaps xmm5, [rsp+0x20]
00007accb5bd6946  por xmm6, xmm5
00007accb5bd694a  lea r14, [rax+0x10]
00007accb5bd694e  mov r12, [r13+r14*1]
00007accb5bd6953  lea r14, [rax+0x18]
00007accb5bd6957  mov r11, [r13+r14*1]
00007accb5bd695c  movq xmm5, r12
00007accb5bd6961  movq xmm4, r11
00007accb5bd6966  movq xmm5, xmm5
00007accb5bd696a  movq xmm4, xmm4
00007accb5bd696e  movaps xmm3, [r15+0x200]
00007accb5bd6976  vmovaps [rsp+0x20], xmm3
00007accb5bd697c  vmovaps xmm2, [rsp+0x20]
00007accb5bd6982  por xmm3, xmm2
00007accb5bd6986  movaps xmm2, [r15+0x1F0]
00007accb5bd698e  vmovaps [rsp+0x20], xmm2
00007accb5bd6994  vmovaps [rsp+0x30], xmm1
00007accb5bd699a  vmovaps xmm1, [rsp+0x20]
00007accb5bd69a0  por xmm2, xmm1
00007accb5bd69a4  movaps xmm1, [r15+0x2E0]
00007accb5bd69ac  vmovaps [rsp+0x20], xmm1
00007accb5bd69b2  vmovaps [rsp+0x40], xmm15
00007accb5bd69b8  vmovaps xmm15, [rsp+0x20]
00007accb5bd69be  por xmm1, xmm15
00007accb5bd69c3  movaps xmm15, [r15+0x2A0]
00007accb5bd69cb  vmovaps [rsp+0x20], xmm15
00007accb5bd69d1  vmovaps [rsp+0x50], xmm1
00007accb5bd69d7  vmovaps xmm1, [rsp+0x20]
00007accb5bd69dd  por xmm15, xmm1
00007accb5bd69e2  movaps xmm1, [r15+0x280]
00007accb5bd69ea  vmovaps [rsp+0x20], xmm1
00007accb5bd69f0  vmovaps [rsp+0x60], xmm15
00007accb5bd69f6  vmovaps xmm15, [rsp+0x20]
00007accb5bd69fc  por xmm1, xmm15
00007accb5bd6a01  movaps xmm15, [r15+0x1C0]
00007accb5bd6a09  vmovaps [rsp+0x20], xmm15
00007accb5bd6a0f  vmovaps [rsp+0x70], xmm1
00007accb5bd6a15  vmovaps xmm1, [rsp+0x20]
00007accb5bd6a1b  por xmm15, xmm1
00007accb5bd6a20  movaps xmm1, [r15+0x210]
00007accb5bd6a28  vmovaps [rsp+0x20], xmm1
00007accb5bd6a2e  vmovaps [rsp+0x80], xmm15
00007accb5bd6a37  vmovaps xmm15, [rsp+0x20]
00007accb5bd6a3d  por xmm1, xmm15
00007accb5bd6a42  mov r14, [r13+rax*1]
00007accb5bd6a47  vmovq xmm15, r14
00007accb5bd6a4c  vpbroadcastq xmm15, xmm15
00007accb5bd6a51  vmovaps [rsp+0x20], xmm1
00007accb5bd6a57  vxorps xmm1, xmm1, xmm1
00007accb5bd6a5b  vpbroadcastq xmm1, xmm1
00007accb5bd6a60  mov r14, [r15+0xF8]
00007accb5bd6a67  vmovaps [rsp+0x90], xmm1
00007accb5bd6a70  movups xmm1, [r13+r14*1]
00007accb5bd6a76  vmovaps [rsp+0xA0], xmm1
00007accb5bd6a7f  vxorps xmm1, xmm1, xmm1
00007accb5bd6a83  vpbroadcastq xmm1, xmm1
00007accb5bd6a88  lea r12, [rax+0x08]
00007accb5bd6a8c  mov rax, [r13+r12*1]
00007accb5bd6a91  vmovaps [rsp+0xB0], xmm1
00007accb5bd6a9a  movq xmm1, rax
00007accb5bd6a9f  movaps [r15+0x240], xmm1
00007accb5bd6aa7  mov rax, [r15+0x50]
00007accb5bd6aab  mov [r15+0x60], rax
00007accb5bd6aaf  mov qword ptr [r15+0x58], 0x40
00007accb5bd6ab7  vmovaps xmm1, [rsp+0x30]
00007accb5bd6abd  vmovaps [rsp+0x30], xmm15
00007accb5bd6ac3  vmovaps xmm15, [rsp+0xA0]
00007accb5bd6acc  vmovaps [rsp+0xA0], xmm14
00007accb5bd6ad5  vmovaps xmm14, [rsp+0x30]
00007accb5bd6adb  vmovaps [rsp+0x30], xmm13
00007accb5bd6ae1  vmovaps [rsp+0xC0], xmm12
00007accb5bd6aea  movaps xmm13, xmm1
00007accb5bd6aee  vfmadd231pd xmm13, xmm15, xmm14
00007accb5bd6af3  vcmppd xmm12, xmm13, xmm13, 0x03
00007accb5bd6af9  vptest xmm12, xmm12
00007accb5bd6afe  jnz 0x00007ACCB5BD75DD
00007accb5bd6b04  movaps xmm1, [r15+0x250]
00007accb5bd6b0c  vmovaps xmm15, [rsp+0x40]
00007accb5bd6b12  vmovaps [rsp+0x40], xmm13
00007accb5bd6b18  movaps xmm12, xmm15
00007accb5bd6b1c  vfmadd231pd xmm12, xmm1, xmm14
00007accb5bd6b21  vcmppd xmm13, xmm12, xmm12, 0x03
00007accb5bd6b27  vptest xmm13, xmm13
00007accb5bd6b2c  jnz 0x00007ACCB5BD7736
00007accb5bd6b32  movaps xmm15, [r15+0x1E0]
00007accb5bd6b3a  vmovaps [rsp+0xD0], xmm15
00007accb5bd6b43  vmovaps xmm13, [rsp+0xD0]
00007accb5bd6b4c  por xmm15, xmm13
00007accb5bd6b51  movaps xmm13, [r15+0x1D0]
00007accb5bd6b59  vmovaps [rsp+0xD0], xmm13
00007accb5bd6b62  vmovaps [rsp+0xE0], xmm1
00007accb5bd6b6b  vmovaps xmm1, [rsp+0xD0]
00007accb5bd6b74  por xmm13, xmm1
00007accb5bd6b79  movaps xmm1, [r15+0x2C0]
00007accb5bd6b81  vmovaps [rsp+0xD0], xmm1
00007accb5bd6b8a  vmovaps [rsp+0xF0], xmm15
00007accb5bd6b93  vmovaps xmm15, [rsp+0xD0]
00007accb5bd6b9c  por xmm1, xmm15
00007accb5bd6ba1  movaps xmm15, [r15+0x290]
00007accb5bd6ba9  vmovaps [rsp+0xD0], xmm15
00007accb5bd6bb2  vmovaps [rsp+0x100], xmm1
00007accb5bd6bbb  vmovaps xmm1, [rsp+0xD0]
00007accb5bd6bc4  por xmm15, xmm1
00007accb5bd6bc9  movaps xmm1, [r15+0x260]
00007accb5bd6bd1  vmovaps [rsp+0xD0], xmm1
00007accb5bd6bda  vmovaps [rsp+0x110], xmm15
00007accb5bd6be3  vmovaps xmm15, [rsp+0xD0]
00007accb5bd6bec  por xmm1, xmm15
00007accb5bd6bf1  vmovaps xmm15, [rsp+0xE0]
00007accb5bd6bfa  vmovaps [rsp+0xD0], xmm1
00007accb5bd6c03  vmovaps xmm1, [rsp+0xE0]
00007accb5bd6c0c  por xmm15, xmm1
00007accb5bd6c11  lea r12, [r14+0xC0]
00007accb5bd6c18  movups xmm1, [r13+r12*1]
00007accb5bd6c1e  mov [rsp+0xE0], rax
00007accb5bd6c26  xor eax, eax
00007accb5bd6c28  mov r12d, 0x40
00007accb5bd6c2e  mov r11d, 0x200
00007accb5bd6c34  cmp r12, r11
00007accb5bd6c37  cmc
00007accb5bd6c38  lahf
00007accb5bd6c39  seto al
00007accb5bd6c3c  mov [r15+0x108], eax
00007accb5bd6c43  vmovaps [rsp+0x120], xmm1
00007accb5bd6c4c  vmovaps xmm1, [rsp+0x90]
00007accb5bd6c55  vmovaps [rsp+0x90], xmm15
00007accb5bd6c5e  vmovaps xmm15, [rsp+0x120]
00007accb5bd6c67  vmovaps [rsp+0x120], xmm13
00007accb5bd6c70  vmovaps [rsp+0x130], xmm12
00007accb5bd6c79  movaps xmm13, xmm1
00007accb5bd6c7d  vfmadd231pd xmm13, xmm15, xmm14
00007accb5bd6c82  vcmppd xmm12, xmm13, xmm13, 0x03
00007accb5bd6c88  vptest xmm12, xmm12
00007accb5bd6c8d  jnz 0x00007ACCB5BD7899
00007accb5bd6c93  lea rax, [r14+0xB0]
00007accb5bd6c9a  movups xmm1, [r13+rax*1]
00007accb5bd6ca0  vmovaps xmm15, [rsp+0xB0]
00007accb5bd6ca9  vmovaps [rsp+0xB0], xmm13
00007accb5bd6cb2  movaps xmm12, xmm15
00007accb5bd6cb6  vfmadd231pd xmm12, xmm1, xmm14
00007accb5bd6cbb  vcmppd xmm13, xmm12, xmm12, 0x03
00007accb5bd6cc1  vptest xmm13, xmm13
00007accb5bd6cc6  jnz 0x00007ACCB5BD79FC
00007accb5bd6ccc  vmovaps xmm1, [rsp+0x20]
00007accb5bd6cd2  vmovaps xmm15, [rsp+0x20]
00007accb5bd6cd8  por xmm1, xmm15
00007accb5bd6cdd  movaps [r15+0x210], xmm1
00007accb5bd6ce5  vmovaps xmm15, [rsp+0x80]
00007accb5bd6cee  vmovaps xmm14, [rsp+0x80]
00007accb5bd6cf7  por xmm15, xmm14
00007accb5bd6cfc  movaps [r15+0x1C0], xmm15
00007accb5bd6d04  vmovaps xmm14, [rsp+0x70]
00007accb5bd6d0a  vmovaps xmm13, [rsp+0x70]
00007accb5bd6d10  por xmm14, xmm13
00007accb5bd6d15  movaps [r15+0x280], xmm14
00007accb5bd6d1d  vmovaps xmm13, [rsp+0x60]
00007accb5bd6d23  vmovaps [rsp+0x20], xmm1
00007accb5bd6d29  vmovaps xmm1, [rsp+0x60]
00007accb5bd6d2f  por xmm13, xmm1
00007accb5bd6d34  movaps [r15+0x2A0], xmm13
00007accb5bd6d3c  vmovaps xmm1, [rsp+0x50]
00007accb5bd6d42  vmovaps [rsp+0x60], xmm15
00007accb5bd6d48  vmovaps xmm15, [rsp+0x50]
00007accb5bd6d4e  por xmm1, xmm15
00007accb5bd6d53  movaps [r15+0x2E0], xmm1
00007accb5bd6d5b  vmovaps [rsp+0x50], xmm2
00007accb5bd6d61  vmovaps xmm15, [rsp+0x50]
00007accb5bd6d67  por xmm2, xmm15
00007accb5bd6d6c  movaps [r15+0x1F0], xmm2
00007accb5bd6d74  vmovaps xmm15, [rsp+0x90]
00007accb5bd6d7d  vmovaps [rsp+0x50], xmm1
00007accb5bd6d83  vmovaps xmm1, [rsp+0x90]
00007accb5bd6d8c  por xmm15, xmm1
00007accb5bd6d91  movaps [r15+0x250], xmm15
00007accb5bd6d99  vmovaps xmm1, [rsp+0xD0]
00007accb5bd6da2  vmovaps xmm15, [rsp+0xD0]
00007accb5bd6dab  por xmm1, xmm15
00007accb5bd6db0  movaps [r15+0x260], xmm1
00007accb5bd6db8  vmovaps xmm15, [rsp+0x110]
00007accb5bd6dc1  vmovaps [rsp+0x70], xmm1
00007accb5bd6dc7  vmovaps xmm1, [rsp+0x110]
00007accb5bd6dd0  por xmm15, xmm1
00007accb5bd6dd5  movaps [r15+0x290], xmm15
00007accb5bd6ddd  vmovaps xmm1, [rsp+0x100]
00007accb5bd6de6  vmovaps [rsp+0x80], xmm15
00007accb5bd6def  vmovaps xmm15, [rsp+0x100]
00007accb5bd6df8  por xmm1, xmm15
00007accb5bd6dfd  movaps [r15+0x2C0], xmm1
00007accb5bd6e05  movq xmm15, qword ptr [r15+0x240]
00007accb5bd6e0e  vmovaps [rsp+0x90], xmm15
00007accb5bd6e17  vpermilpd xmm15, xmm15, 0x00
00007accb5bd6e1d  vmovaps [rsp+0xD0], xmm1
00007accb5bd6e26  vmovaps xmm1, [rsp+0x40]
00007accb5bd6e2c  vmovaps [rsp+0x40], xmm15
00007accb5bd6e32  vmovaps xmm15, [rsp+0x20]
00007accb5bd6e38  vmovaps [rsp+0x20], xmm14
00007accb5bd6e3e  vmovaps xmm14, [rsp+0x40]
00007accb5bd6e44  vmovaps [rsp+0x40], xmm13
00007accb5bd6e4a  vmovaps [rsp+0x100], xmm12
00007accb5bd6e53  movaps xmm13, xmm1
00007accb5bd6e57  vfmadd231pd xmm13, xmm15, xmm14
00007accb5bd6e5c  vcmppd xmm12, xmm13, xmm13, 0x03
00007accb5bd6e62  vptest xmm12, xmm12
00007accb5bd6e67  jnz 0x00007ACCB5BD7B55
00007accb5bd6e6d  vmovaps xmm1, [rsp+0x90]
00007accb5bd6e76  vpermilpd xmm1, xmm1, 0x00
00007accb5bd6e7c  vmovaps xmm15, [rsp+0xB0]
00007accb5bd6e85  vmovaps xmm14, [rsp+0x50]
00007accb5bd6e8b  vmovaps [rsp+0x50], xmm13
00007accb5bd6e91  movaps xmm12, xmm15
00007accb5bd6e95  vfmadd231pd xmm12, xmm14, xmm1
00007accb5bd6e9a  vcmppd xmm13, xmm12, xmm12, 0x03
00007accb5bd6ea0  vptest xmm13, xmm13
00007accb5bd6ea5  jnz 0x00007ACCB5BD7CAE
00007accb5bd6eab  vmovaps xmm1, [rsp+0x90]
00007accb5bd6eb4  vpermilpd xmm1, xmm1, 0x00
00007accb5bd6eba  vmovaps xmm15, [rsp+0x130]
00007accb5bd6ec3  vmovaps xmm14, [rsp+0x60]
00007accb5bd6ec9  vmovaps [rsp+0x60], xmm12
00007accb5bd6ecf  movaps xmm13, xmm15
00007accb5bd6ed3  vfmadd231pd xmm13, xmm14, xmm1
00007accb5bd6ed8  vcmppd xmm12, xmm13, xmm13, 0x03
00007accb5bd6ede  vptest xmm12, xmm12
00007accb5bd6ee3  jnz 0x00007ACCB5BD7E07
00007accb5bd6ee9  vmovaps xmm1, [rsp+0x120]
00007accb5bd6ef2  vmovaps xmm15, [rsp+0x120]
00007accb5bd6efb  por xmm1, xmm15
00007accb5bd6f00  movaps [r15+0x1D0], xmm1
00007accb5bd6f08  vmovaps xmm15, [rsp+0x90]
00007accb5bd6f11  vpermilpd xmm15, xmm15, 0x00
00007accb5bd6f17  vmovaps xmm14, [rsp+0x100]
00007accb5bd6f20  vmovaps [rsp+0x90], xmm1
00007accb5bd6f29  movaps xmm12, xmm14
00007accb5bd6f2d  vfmadd231pd xmm12, xmm2, xmm15
00007accb5bd6f32  vcmppd xmm1, xmm12, xmm12, 0x03
00007accb5bd6f38  vptest xmm1, xmm1
00007accb5bd6f3d  jnz 0x00007ACCB5BD7F60
00007accb5bd6f43  vmovaps [rsp+0xB0], xmm3
00007accb5bd6f4c  vmovaps xmm1, [rsp+0xB0]
00007accb5bd6f55  por xmm3, xmm1
00007accb5bd6f59  movaps [r15+0x200], xmm3
00007accb5bd6f61  vmovaps xmm1, [rsp+0xF0]
00007accb5bd6f6a  vmovaps xmm15, [rsp+0xF0]
00007accb5bd6f73  por xmm1, xmm15
00007accb5bd6f78  movaps [r15+0x1E0], xmm1
00007accb5bd6f80  vmovaps [rsp+0xB0], xmm7
00007accb5bd6f89  vmovaps xmm1, [rsp+0xB0]
00007accb5bd6f92  por xmm7, xmm1
00007accb5bd6f96  movaps [r15+0x2B0], xmm7
00007accb5bd6f9e  vmovaps [rsp+0xB0], xmm8
00007accb5bd6fa7  vmovaps xmm1, [rsp+0xB0]
00007accb5bd6fb0  por xmm8, xmm1
00007accb5bd6fb5  movaps [r15+0x300], xmm8
00007accb5bd6fbd  vmovaps [rsp+0xB0], xmm5
00007accb5bd6fc6  vpermilpd xmm5, xmm5, 0x00
00007accb5bd6fcc  vmovaps xmm14, [rsp+0x50]
00007accb5bd6fd2  vmovaps xmm8, [rsp+0x70]
00007accb5bd6fd8  vmovaps [rsp+0x50], xmm1
00007accb5bd6fde  movaps xmm2, xmm14
00007accb5bd6fe2  vfmadd231pd xmm2, xmm8, xmm5
00007accb5bd6fe7  vcmppd xmm1, xmm2, xmm2, 0x03
00007accb5bd6fec  vptest xmm1, xmm1
00007accb5bd6ff1  jnz 0x00007ACCB5BD80B9
00007accb5bd6ff7  vmovaps xmm1, [rsp+0xB0]
00007accb5bd7000  vpermilpd xmm1, xmm1, 0x00
00007accb5bd7006  vmovaps xmm14, [rsp+0x60]
00007accb5bd700c  vmovaps xmm8, [rsp+0xD0]
00007accb5bd7015  vmovaps [rsp+0x60], xmm15
00007accb5bd701b  movaps xmm5, xmm14
00007accb5bd701f  vfmadd231pd xmm5, xmm8, xmm1
00007accb5bd7024  vcmppd xmm15, xmm5, xmm5, 0x03
00007accb5bd7029  vptest xmm15, xmm15
00007accb5bd702e  jnz 0x00007ACCB5BD8210
00007accb5bd7034  vmovaps xmm1, [rsp+0xB0]
00007accb5bd703d  vpermilpd xmm1, xmm1, 0x00
00007accb5bd7043  vmovaps xmm14, [rsp+0x20]
00007accb5bd7049  movaps xmm15, xmm13
00007accb5bd704d  vfmadd231pd xmm15, xmm14, xmm1
00007accb5bd7052  vcmppd xmm8, xmm15, xmm15, 0x03
00007accb5bd7058  vptest xmm8, xmm8
00007accb5bd705d  jnz 0x00007ACCB5BD8367
00007accb5bd7063  vmovaps xmm1, [rsp+0xB0]
00007accb5bd706c  vpermilpd xmm1, xmm1, 0x00
00007accb5bd7072  vmovaps xmm14, [rsp+0x90]
00007accb5bd707b  movaps xmm13, xmm12
00007accb5bd707f  vfmadd231pd xmm13, xmm14, xmm1
00007accb5bd7084  vcmppd xmm8, xmm13, xmm13, 0x03
00007accb5bd708a  vptest xmm8, xmm8
00007accb5bd708f  jnz 0x00007ACCB5BD84C0
00007accb5bd7095  vmovaps [rsp+0x20], xmm6
00007accb5bd709b  vmovaps xmm1, [rsp+0x20]
00007accb5bd70a1  por xmm6, xmm1
00007accb5bd70a5  movaps [r15+0x180], xmm6
00007accb5bd70ad  vmovaps [rsp+0x20], xmm9
00007accb5bd70b3  vmovaps xmm1, [rsp+0x20]
00007accb5bd70b9  por xmm9, xmm1
00007accb5bd70be  movaps [r15+0x2D0], xmm9
00007accb5bd70c6  vmovaps [rsp+0x20], xmm10
00007accb5bd70cc  vmovaps xmm1, [rsp+0x20]
00007accb5bd70d2  por xmm10, xmm1
00007accb5bd70d7  movaps [r15+0x2F0], xmm10
00007accb5bd70df  vmovaps [rsp+0x20], xmm4
00007accb5bd70e5  vpermilpd xmm4, xmm4, 0x00
00007accb5bd70eb  vmovaps xmm14, [rsp+0x50]
00007accb5bd70f1  movaps xmm12, xmm5
00007accb5bd70f5  vfmadd231pd xmm12, xmm14, xmm4
00007accb5bd70fa  vcmppd xmm10, xmm12, xmm12, 0x03
00007accb5bd7100  vptest xmm10, xmm10
00007accb5bd7105  jnz 0x00007ACCB5BD8619
00007accb5bd710b  vmovaps xmm14, [rsp+0x20]
00007accb5bd7111  vpermilpd xmm14, xmm14, 0x00
00007accb5bd7117  movaps xmm10, xmm2
00007accb5bd711b  vfmadd231pd xmm10, xmm6, xmm14
00007accb5bd7120  vcmppd xmm8, xmm10, xmm10, 0x03
00007accb5bd7126  vptest xmm8, xmm8
00007accb5bd712b  jnz 0x00007ACCB5BD8771
00007accb5bd7131  lea rax, [r14+0x80]
00007accb5bd7138  movups xmm14, [r13+rax*1]
00007accb5bd713e  movaps [r15+0x190], xmm14
00007accb5bd7146  vmovaps xmm8, [rsp+0x20]
00007accb5bd714c  vpermilpd xmm8, xmm8, 0x00
00007accb5bd7152  vmovaps xmm6, [rsp+0x80]
00007accb5bd715b  movaps xmm5, xmm15
00007accb5bd715f  vfmadd231pd xmm5, xmm6, xmm8
00007accb5bd7164  vcmppd xmm4, xmm5, xmm5, 0x03
00007accb5bd7169  vptest xmm4, xmm4
00007accb5bd716e  jnz 0x00007ACCB5BD88D3
00007accb5bd7174  vmovaps xmm15, [rsp+0x20]
00007accb5bd717a  vpermilpd xmm15, xmm15, 0x00
00007accb5bd7180  movaps xmm8, xmm13
00007accb5bd7184  vfmadd231pd xmm8, xmm1, xmm15
00007accb5bd7189  vcmppd xmm6, xmm8, xmm8, 0x03
00007accb5bd718f  vptest xmm6, xmm6
00007accb5bd7194  jnz 0x00007ACCB5BD8A2A
00007accb5bd719a  vmovaps xmm1, [rsp+0x30]
00007accb5bd71a0  vmovaps xmm15, [rsp+0x30]
00007accb5bd71a6  por xmm1, xmm15
00007accb5bd71ab  movaps [r15+0x160], xmm1
00007accb5bd71b3  lea rax, [r14+0x40]
00007accb5bd71b7  movups xmm15, [r13+rax*1]
00007accb5bd71bd  lea rax, [r14+0x50]
00007accb5bd71c1  movups xmm13, [r13+rax*1]
00007accb5bd71c7  movaps [r15+0x1B0], xmm15
00007accb5bd71cf  movaps [r15+0x1A0], xmm13
00007accb5bd71d7  vmovaps xmm6, [rsp+0xC0]
00007accb5bd71e0  vpermilpd xmm6, xmm6, 0x00
00007accb5bd71e6  movaps xmm4, xmm12
00007accb5bd71ea  vfmadd231pd xmm4, xmm9, xmm6
00007accb5bd71ef  vcmppd xmm2, xmm4, xmm4, 0x03
00007accb5bd71f4  vptest xmm2, xmm2
00007accb5bd71f9  jnz 0x00007ACCB5BD8B97
00007accb5bd71ff  vmovaps xmm12, [rsp+0xC0]
00007accb5bd7208  vpermilpd xmm12, xmm12, 0x00
00007accb5bd720e  movaps xmm9, xmm10
00007accb5bd7212  vfmadd231pd xmm9, xmm1, xmm12
00007accb5bd7217  vcmppd xmm6, xmm9, xmm9, 0x03
00007accb5bd721d  vptest xmm6, xmm6
00007accb5bd7222  jnz 0x00007ACCB5BD8CEE
00007accb5bd7228  vmovaps xmm1, [rsp+0xC0]
00007accb5bd7231  vpermilpd xmm1, xmm1, 0x00
00007accb5bd7237  vmovaps xmm12, [rsp+0x40]
00007accb5bd723d  movaps xmm10, xmm5
00007accb5bd7241  vfmadd231pd xmm10, xmm12, xmm1
00007accb5bd7246  vcmppd xmm6, xmm10, xmm10, 0x03
00007accb5bd724c  vptest xmm6, xmm6
00007accb5bd7251  jnz 0x00007ACCB5BD8E47
00007accb5bd7257  vmovaps xmm1, [rsp+0xC0]
00007accb5bd7260  vpermilpd xmm1, xmm1, 0x00
00007accb5bd7266  vmovaps xmm12, [rsp+0x60]
00007accb5bd726c  movaps xmm6, xmm8
00007accb5bd7270  vfmadd231pd xmm6, xmm12, xmm1
00007accb5bd7275  vcmppd xmm5, xmm6, xmm6, 0x03
00007accb5bd727a  vptest xmm5, xmm5
00007accb5bd727f  jnz 0x00007ACCB5BD8F9F
00007accb5bd7285  lea rax, [r14+0x60]
00007accb5bd7289  movups xmm1, [r13+rax*1]
00007accb5bd728f  lea rax, [r14+0x70]
00007accb5bd7293  movups xmm12, [r13+rax*1]
00007accb5bd7299  movaps [r15+0x150], xmm1
00007accb5bd72a1  movaps [r15+0x120], xmm12
00007accb5bd72a9  vmovaps [rsp+0x20], xmm11
00007accb5bd72af  vpermilpd xmm11, xmm11, 0x00
00007accb5bd72b5  movaps xmm8, xmm4
00007accb5bd72b9  vfmadd231pd xmm8, xmm13, xmm11
00007accb5bd72be  vcmppd xmm5, xmm8, xmm8, 0x03
00007accb5bd72c4  vptest xmm5, xmm5
00007accb5bd72c9  jnz 0x00007ACCB5BD910A
00007accb5bd72cf  vmovaps xmm13, [rsp+0x20]
00007accb5bd72d5  vpermilpd xmm13, xmm13, 0x00
00007accb5bd72db  movaps xmm11, xmm9
00007accb5bd72df  vfmadd231pd xmm11, xmm1, xmm13
00007accb5bd72e4  vcmppd xmm5, xmm11, xmm11, 0x03
00007accb5bd72ea  vptest xmm5, xmm5
00007accb5bd72ef  jnz 0x00007ACCB5BD9263
00007accb5bd72f5  vmovaps xmm1, [rsp+0x20]
00007accb5bd72fb  vpermilpd xmm1, xmm1, 0x00
00007accb5bd7301  movaps xmm13, xmm10
00007accb5bd7305  vfmadd231pd xmm13, xmm7, xmm1
00007accb5bd730a  vcmppd xmm9, xmm13, xmm13, 0x03
00007accb5bd7310  vptest xmm9, xmm9
00007accb5bd7315  jnz 0x00007ACCB5BD93BC
00007accb5bd731b  vmovaps xmm1, [rsp+0x20]
00007accb5bd7321  vpermilpd xmm1, xmm1, 0x00
00007accb5bd7327  movaps xmm10, xmm6
00007accb5bd732b  vfmadd231pd xmm10, xmm15, xmm1
00007accb5bd7330  vcmppd xmm9, xmm10, xmm10, 0x03
00007accb5bd7336  vptest xmm9, xmm9
00007accb5bd733b  jnz 0x00007ACCB5BD9514
00007accb5bd7341  lea rax, [r14+0x20]
00007accb5bd7345  movups xmm1, [r13+rax*1]
00007accb5bd734b  lea rax, [r14+0x30]
00007accb5bd734f  movups xmm15, [r13+rax*1]
00007accb5bd7355  vmovaps xmm9, [rsp+0xA0]
00007accb5bd735e  vpermilpd xmm9, xmm9, 0x00
00007accb5bd7364  movaps xmm7, xmm8
00007accb5bd7368  vfmadd231pd xmm7, xmm3, xmm9
00007accb5bd736d  vcmppd xmm6, xmm7, xmm7, 0x03
00007accb5bd7372  vptest xmm6, xmm6
00007accb5bd7377  jnz 0x00007ACCB5BD9680
00007accb5bd737d  vmovaps xmm9, [rsp+0xA0]
00007accb5bd7386  vpermilpd xmm9, xmm9, 0x00
00007accb5bd738c  movaps xmm8, xmm11
00007accb5bd7390  vfmadd231pd xmm8, xmm14, xmm9
00007accb5bd7395  vcmppd xmm6, xmm8, xmm8, 0x03
00007accb5bd739b  vptest xmm6, xmm6
00007accb5bd73a0  jnz 0x00007ACCB5BD97D7
00007accb5bd73a6  vmovaps xmm14, [rsp+0xA0]
00007accb5bd73af  vpermilpd xmm14, xmm14, 0x00
00007accb5bd73b5  movaps xmm11, xmm13
00007accb5bd73b9  vfmadd231pd xmm11, xmm12, xmm14
00007accb5bd73be  vcmppd xmm9, xmm11, xmm11, 0x03
00007accb5bd73c4  vptest xmm9, xmm9
00007accb5bd73c9  jnz 0x00007ACCB5BD9931
00007accb5bd73cf  vmovaps xmm14, [rsp+0xA0]
00007accb5bd73d8  vpermilpd xmm14, xmm14, 0x00
00007accb5bd73de  movaps xmm12, xmm10
00007accb5bd73e2  vfmadd231pd xmm12, xmm15, xmm14
00007accb5bd73e7  vcmppd xmm13, xmm12, xmm12, 0x03
00007accb5bd73ed  vptest xmm13, xmm13
00007accb5bd73f2  jnz 0x00007ACCB5BD9A8B
00007accb5bd73f8  lea rax, [r14+0x90]
00007accb5bd73ff  movups xmm15, [r13+rax*1]
00007accb5bd7405  lea rax, [r14+0xA0]
00007accb5bd740c  movups xmm14, [r13+rax*1]
00007accb5bd7412  movaps [r15+0x140], xmm15
00007accb5bd741a  movaps [r15+0x130], xmm14
00007accb5bd7422  vmovaps xmm13, [rsp+0x10]
00007accb5bd7428  vpermilpd xmm13, xmm13, 0x00
00007accb5bd742e  movaps xmm10, xmm7
00007accb5bd7432  vfmadd231pd xmm10, xmm1, xmm13
00007accb5bd7437  vcmppd xmm9, xmm10, xmm10, 0x03
00007accb5bd743d  vptest xmm9, xmm9
00007accb5bd7442  jnz 0x00007ACCB5BD9BF9
00007accb5bd7448  movaps [r15+0x220], xmm10
00007accb5bd7450  lea rax, [r14+0x10]
00007accb5bd7454  movups xmm1, [r13+rax*1]
00007accb5bd745a  movaps [r15+0x240], xmm1
00007accb5bd7462  vmovaps xmm13, [rsp+0x10]
00007accb5bd7468  vpermilpd xmm13, xmm13, 0x00
00007accb5bd746e  movaps xmm9, xmm8
00007accb5bd7472  vfmadd231pd xmm9, xmm14, xmm13
00007accb5bd7477  vcmppd xmm7, xmm9, xmm9, 0x03
00007accb5bd747d  vptest xmm7, xmm7
00007accb5bd7482  jnz 0x00007ACCB5BD9D5B
00007accb5bd7488  movaps [r15+0x110], xmm9
00007accb5bd7490  vmovaps xmm14, [rsp+0x10]
00007accb5bd7496  vpermilpd xmm14, xmm14, 0x00
00007accb5bd749c  movaps xmm13, xmm11
00007accb5bd74a0  vfmadd231pd xmm13, xmm15, xmm14
00007accb5bd74a5  vcmppd xmm8, xmm13, xmm13, 0x03
00007accb5bd74ab  vptest xmm8, xmm8
00007accb5bd74b0  jnz 0x00007ACCB5BD9EB5
00007accb5bd74b6  movaps [r15+0x170], xmm13
00007accb5bd74be  vmovaps xmm15, [rsp+0x10]
00007accb5bd74c4  vpermilpd xmm15, xmm15, 0x00
00007accb5bd74ca  movaps xmm14, xmm12
00007accb5bd74ce  vfmadd231pd xmm14, xmm1, xmm15
00007accb5bd74d3  vcmppd xmm11, xmm14, xmm14, 0x03
00007accb5bd74d9  vptest xmm11, xmm11
00007accb5bd74de  jnz 0x00007ACCB5BDA00F
00007accb5bd74e4  movaps [r15+0x230], xmm14
00007accb5bd74ec  mov rax, [rsp+0xE0]
00007accb5bd74f4  movups [r13+rax*1], xmm9
00007accb5bd74fa  lea r14, [rax+0x10]
00007accb5bd74fe  movups [r13+r14*1], xmm13
00007accb5bd7504  lea r14, [rax+0x20]
00007accb5bd7508  movups [r13+r14*1], xmm10
00007accb5bd750e  lea r14, [rax+0x30]
00007accb5bd7512  movups [r13+r14*1], xmm14
00007accb5bd7518  mov eax, [r15+0x108]
00007accb5bd751f  sahf
00007accb5bd7520  jnz 0x00007ACCB5BD7552
00007accb5bd7522  cmp dword ptr [r15+0x318], 0x00
00007accb5bd752a  jz 0x00007ACCB5BD67A0
00007accb5bd7530  nop [rax+rax*1], ax
00007accb5bd7539  nop [rax+rax*1], eax
00007accb5bd7541  mov eax, 0x4103F0
00007accb5bd7546  mov [r15+0x100], rax
00007accb5bd754d  jmp 0x00007ACCB59FE110
00007accb5bd7552  cmp dword ptr [r15+0x318], 0x00
00007accb5bd755a  jz 0x00007ACCB5BD2E40
00007accb5bd7560  nop [rax+rax*1], ax
00007accb5bd7569  nop [rax+rax*1], eax
00007accb5bd7571  mov eax, 0x410274
00007accb5bd7576  mov [r15+0x100], rax
00007accb5bd757d  jmp 0x00007ACCB59FE110
00007accb5bd7582  int3
00007accb5bd7583  call 0x00007ACCB5AE27E0
00007accb5bd7588  jmp 0x00007ACCB5BD6860
00007accb5bd758d  call 0x00007ACCB5AE1570
00007accb5bd7592  jmp 0x00007ACCB5BD6869
00007accb5bd7597  call 0x00007ACCB5AE27E0
00007accb5bd759c  jmp 0x00007ACCB5BD68B2
00007accb5bd75a1  call 0x00007ACCB5AE1570
00007accb5bd75a6  jmp 0x00007ACCB5BD68BB
00007accb5bd75ab  call 0x00007ACCB5AE27E0
00007accb5bd75b0  jmp 0x00007ACCB5BD6953
00007accb5bd75b5  call 0x00007ACCB5AE1570
00007accb5bd75ba  jmp 0x00007ACCB5BD695C
00007accb5bd75bf  call 0x00007ACCB5A0DC20
00007accb5bd75c4  jmp 0x00007ACCB5BD6A47
00007accb5bd75c9  call 0x00007ACCB5AD64F0
00007accb5bd75ce  jmp 0x00007ACCB5BD6A76
00007accb5bd75d3  call 0x00007ACCB5AB47C0
00007accb5bd75d8  jmp 0x00007ACCB5BD6A91
00007accb5bd75dd  sub rsp, 0x08
00007accb5bd75e1  push rax
00007accb5bd75e2  push rcx
00007accb5bd75e3  push rdx
00007accb5bd75e4  push rdi
00007accb5bd75e5  push rsi
00007accb5bd75e6  push r8
00007accb5bd75e8  push r9
00007accb5bd75ea  push r10
00007accb5bd75ec  push r11
00007accb5bd75ee  sub rsp, 0xF0
00007accb5bd75f5  vmovaps [rsp], xmm0
00007accb5bd75fa  vmovaps [rsp+0x10], xmm1
00007accb5bd7600  vmovaps [rsp+0x20], xmm2
00007accb5bd7606  vmovaps [rsp+0x30], xmm3
00007accb5bd760c  vmovaps [rsp+0x40], xmm4
00007accb5bd7612  vmovaps [rsp+0x50], xmm5
00007accb5bd7618  vmovaps [rsp+0x60], xmm6
00007accb5bd761e  vmovaps [rsp+0x70], xmm7
00007accb5bd7624  vmovaps [rsp+0x80], xmm8
00007accb5bd762d  vmovaps [rsp+0x90], xmm9
00007accb5bd7636  vmovaps [rsp+0xA0], xmm10
00007accb5bd763f  vmovaps [rsp+0xB0], xmm11
00007accb5bd7648  vmovaps [rsp+0xC0], xmm12
00007accb5bd7651  vmovaps [rsp+0xD0], xmm14
00007accb5bd765a  vmovaps [rsp+0xE0], xmm15
00007accb5bd7663  sub rsp, 0x40
00007accb5bd7667  lea rdi, [rsp]
00007accb5bd766b  lea rsi, [rsp+0x10]
00007accb5bd7670  lea rdx, [rsp+0x20]
00007accb5bd7675  lea rcx, [rsp+0x30]
00007accb5bd767a  mov r8d, 0x00
00007accb5bd7680  lea r9, [r15+0x3A8]
00007accb5bd7687  movaps [rdi], xmm13
00007accb5bd768b  movaps [rsi], xmm1
00007accb5bd768e  movaps [rdx], xmm15
00007accb5bd7692  movaps [rcx], xmm14
00007accb5bd7696  mov rax, 0x59156B40DA50
00007accb5bd76a0  call rax
00007accb5bd76a2  movaps xmm13, [rsp]
00007accb5bd76a7  add rsp, 0x40
00007accb5bd76ab  vmovaps xmm0, [rsp]
00007accb5bd76b0  vmovaps xmm1, [rsp+0x10]
00007accb5bd76b6  vmovaps xmm2, [rsp+0x20]
00007accb5bd76bc  vmovaps xmm3, [rsp+0x30]
00007accb5bd76c2  vmovaps xmm4, [rsp+0x40]
00007accb5bd76c8  vmovaps xmm5, [rsp+0x50]
00007accb5bd76ce  vmovaps xmm6, [rsp+0x60]
00007accb5bd76d4  vmovaps xmm7, [rsp+0x70]
00007accb5bd76da  vmovaps xmm8, [rsp+0x80]
00007accb5bd76e3  vmovaps xmm9, [rsp+0x90]
00007accb5bd76ec  vmovaps xmm10, [rsp+0xA0]
00007accb5bd76f5  vmovaps xmm11, [rsp+0xB0]
00007accb5bd76fe  vmovaps xmm12, [rsp+0xC0]
00007accb5bd7707  vmovaps xmm14, [rsp+0xD0]
00007accb5bd7710  vmovaps xmm15, [rsp+0xE0]
00007accb5bd7719  add rsp, 0xF0
00007accb5bd7720  pop r11
00007accb5bd7722  pop r10
00007accb5bd7724  pop r9
00007accb5bd7726  pop r8
00007accb5bd7728  pop rsi
00007accb5bd7729  pop rdi
00007accb5bd772a  pop rdx
00007accb5bd772b  pop rcx
00007accb5bd772c  pop rax
00007accb5bd772d  add rsp, 0x08
00007accb5bd7731  jmp 0x00007ACCB5BD6B04
00007accb5bd7736  sub rsp, 0x08
00007accb5bd773a  push rax
00007accb5bd773b  push rcx
00007accb5bd773c  push rdx
00007accb5bd773d  push rdi
00007accb5bd773e  push rsi
00007accb5bd773f  push r8
00007accb5bd7741  push r9
00007accb5bd7743  push r10
00007accb5bd7745  push r11
00007accb5bd7747  sub rsp, 0xF0
00007accb5bd774e  vmovaps [rsp], xmm0
00007accb5bd7753  vmovaps [rsp+0x10], xmm1
00007accb5bd7759  vmovaps [rsp+0x20], xmm2
00007accb5bd775f  vmovaps [rsp+0x30], xmm3
00007accb5bd7765  vmovaps [rsp+0x40], xmm4
00007accb5bd776b  vmovaps [rsp+0x50], xmm5
00007accb5bd7771  vmovaps [rsp+0x60], xmm6
00007accb5bd7777  vmovaps [rsp+0x70], xmm7
00007accb5bd777d  vmovaps [rsp+0x80], xmm8
00007accb5bd7786  vmovaps [rsp+0x90], xmm9
00007accb5bd778f  vmovaps [rsp+0xA0], xmm10
00007accb5bd7798  vmovaps [rsp+0xB0], xmm11
00007accb5bd77a1  vmovaps [rsp+0xC0], xmm13
00007accb5bd77aa  vmovaps [rsp+0xD0], xmm14
00007accb5bd77b3  vmovaps [rsp+0xE0], xmm15
00007accb5bd77bc  sub rsp, 0x40
00007accb5bd77c0  lea rdi, [rsp]
00007accb5bd77c4  lea rsi, [rsp+0x10]
00007accb5bd77c9  lea rdx, [rsp+0x20]
00007accb5bd77ce  lea rcx, [rsp+0x30]
00007accb5bd77d3  mov r8d, 0x00
00007accb5bd77d9  lea r9, [r15+0x3A8]
00007accb5bd77e0  movaps [rdi], xmm12
00007accb5bd77e4  movaps [rsi], xmm15
00007accb5bd77e8  movaps [rdx], xmm1
00007accb5bd77eb  movaps [rcx], xmm14
00007accb5bd77ef  mov rax, 0x59156B40DA50
00007accb5bd77f9  call rax
00007accb5bd77fb  movaps xmm12, [rsp]
00007accb5bd7800  add rsp, 0x40
00007accb5bd7804  vmovaps xmm0, [rsp]
00007accb5bd7809  vmovaps xmm1, [rsp+0x10]
00007accb5bd780f  vmovaps xmm2, [rsp+0x20]
00007accb5bd7815  vmovaps xmm3, [rsp+0x30]
00007accb5bd781b  vmovaps xmm4, [rsp+0x40]
00007accb5bd7821  vmovaps xmm5, [rsp+0x50]
00007accb5bd7827  vmovaps xmm6, [rsp+0x60]
00007accb5bd782d  vmovaps xmm7, [rsp+0x70]
00007accb5bd7833  vmovaps xmm8, [rsp+0x80]
00007accb5bd783c  vmovaps xmm9, [rsp+0x90]
00007accb5bd7845  vmovaps xmm10, [rsp+0xA0]
00007accb5bd784e  vmovaps xmm11, [rsp+0xB0]
00007accb5bd7857  vmovaps xmm13, [rsp+0xC0]
00007accb5bd7860  vmovaps xmm14, [rsp+0xD0]
00007accb5bd7869  vmovaps xmm15, [rsp+0xE0]
00007accb5bd7872  add rsp, 0xF0
00007accb5bd7879  pop r11
00007accb5bd787b  pop r10
00007accb5bd787d  pop r9
00007accb5bd787f  pop r8
00007accb5bd7881  pop rsi
00007accb5bd7882  pop rdi
00007accb5bd7883  pop rdx
00007accb5bd7884  pop rcx
00007accb5bd7885  pop rax
00007accb5bd7886  add rsp, 0x08
00007accb5bd788a  jmp 0x00007ACCB5BD6B32
00007accb5bd788f  call 0x00007ACCB5AB52F0
00007accb5bd7894  jmp 0x00007ACCB5BD6C1E
00007accb5bd7899  sub rsp, 0x08
00007accb5bd789d  push rax
00007accb5bd789e  push rcx
00007accb5bd789f  push rdx
00007accb5bd78a0  push rdi
00007accb5bd78a1  push rsi
00007accb5bd78a2  push r8
00007accb5bd78a4  push r9
00007accb5bd78a6  push r10
00007accb5bd78a8  push r11
00007accb5bd78aa  sub rsp, 0xF0
00007accb5bd78b1  vmovaps [rsp], xmm0
00007accb5bd78b6  vmovaps [rsp+0x10], xmm1
00007accb5bd78bc  vmovaps [rsp+0x20], xmm2
00007accb5bd78c2  vmovaps [rsp+0x30], xmm3
00007accb5bd78c8  vmovaps [rsp+0x40], xmm4
00007accb5bd78ce  vmovaps [rsp+0x50], xmm5
00007accb5bd78d4  vmovaps [rsp+0x60], xmm6
00007accb5bd78da  vmovaps [rsp+0x70], xmm7
00007accb5bd78e0  vmovaps [rsp+0x80], xmm8
00007accb5bd78e9  vmovaps [rsp+0x90], xmm9
00007accb5bd78f2  vmovaps [rsp+0xA0], xmm10
00007accb5bd78fb  vmovaps [rsp+0xB0], xmm11
00007accb5bd7904  vmovaps [rsp+0xC0], xmm12
00007accb5bd790d  vmovaps [rsp+0xD0], xmm14
00007accb5bd7916  vmovaps [rsp+0xE0], xmm15
00007accb5bd791f  sub rsp, 0x40
00007accb5bd7923  lea rdi, [rsp]
00007accb5bd7927  lea rsi, [rsp+0x10]
00007accb5bd792c  lea rdx, [rsp+0x20]
00007accb5bd7931  lea rcx, [rsp+0x30]
00007accb5bd7936  mov r8d, 0x00
00007accb5bd793c  lea r9, [r15+0x3A8]
00007accb5bd7943  movaps [rdi], xmm13
00007accb5bd7947  movaps [rsi], xmm1
00007accb5bd794a  movaps [rdx], xmm15
00007accb5bd794e  movaps [rcx], xmm14
00007accb5bd7952  mov rax, 0x59156B40DA50
00007accb5bd795c  call rax
00007accb5bd795e  movaps xmm13, [rsp]
00007accb5bd7963  add rsp, 0x40
00007accb5bd7967  vmovaps xmm0, [rsp]
00007accb5bd796c  vmovaps xmm1, [rsp+0x10]
00007accb5bd7972  vmovaps xmm2, [rsp+0x20]
00007accb5bd7978  vmovaps xmm3, [rsp+0x30]
00007accb5bd797e  vmovaps xmm4, [rsp+0x40]
00007accb5bd7984  vmovaps xmm5, [rsp+0x50]
00007accb5bd798a  vmovaps xmm6, [rsp+0x60]
00007accb5bd7990  vmovaps xmm7, [rsp+0x70]
00007accb5bd7996  vmovaps xmm8, [rsp+0x80]
00007accb5bd799f  vmovaps xmm9, [rsp+0x90]
00007accb5bd79a8  vmovaps xmm10, [rsp+0xA0]
00007accb5bd79b1  vmovaps xmm11, [rsp+0xB0]
00007accb5bd79ba  vmovaps xmm12, [rsp+0xC0]
00007accb5bd79c3  vmovaps xmm14, [rsp+0xD0]
00007accb5bd79cc  vmovaps xmm15, [rsp+0xE0]
00007accb5bd79d5  add rsp, 0xF0
00007accb5bd79dc  pop r11
00007accb5bd79de  pop r10
00007accb5bd79e0  pop r9
00007accb5bd79e2  pop r8
00007accb5bd79e4  pop rsi
00007accb5bd79e5  pop rdi
00007accb5bd79e6  pop rdx
00007accb5bd79e7  pop rcx
00007accb5bd79e8  pop rax
00007accb5bd79e9  add rsp, 0x08
00007accb5bd79ed  jmp 0x00007ACCB5BD6C93
00007accb5bd79f2  call 0x00007ACCB59FF430
00007accb5bd79f7  jmp 0x00007ACCB5BD6CA0
00007accb5bd79fc  sub rsp, 0x08
00007accb5bd7a00  push rax
00007accb5bd7a01  push rcx
00007accb5bd7a02  push rdx
00007accb5bd7a03  push rdi
00007accb5bd7a04  push rsi
00007accb5bd7a05  push r8
00007accb5bd7a07  push r9
00007accb5bd7a09  push r10
00007accb5bd7a0b  push r11
00007accb5bd7a0d  sub rsp, 0xF0
00007accb5bd7a14  vmovaps [rsp], xmm0
00007accb5bd7a19  vmovaps [rsp+0x10], xmm1
00007accb5bd7a1f  vmovaps [rsp+0x20], xmm2
00007accb5bd7a25  vmovaps [rsp+0x30], xmm3
00007accb5bd7a2b  vmovaps [rsp+0x40], xmm4
00007accb5bd7a31  vmovaps [rsp+0x50], xmm5
00007accb5bd7a37  vmovaps [rsp+0x60], xmm6
00007accb5bd7a3d  vmovaps [rsp+0x70], xmm7
00007accb5bd7a43  vmovaps [rsp+0x80], xmm8
00007accb5bd7a4c  vmovaps [rsp+0x90], xmm9
00007accb5bd7a55  vmovaps [rsp+0xA0], xmm10
00007accb5bd7a5e  vmovaps [rsp+0xB0], xmm11
00007accb5bd7a67  vmovaps [rsp+0xC0], xmm13
00007accb5bd7a70  vmovaps [rsp+0xD0], xmm14
00007accb5bd7a79  vmovaps [rsp+0xE0], xmm15
00007accb5bd7a82  sub rsp, 0x40
00007accb5bd7a86  lea rdi, [rsp]
00007accb5bd7a8a  lea rsi, [rsp+0x10]
00007accb5bd7a8f  lea rdx, [rsp+0x20]
00007accb5bd7a94  lea rcx, [rsp+0x30]
00007accb5bd7a99  mov r8d, 0x00
00007accb5bd7a9f  lea r9, [r15+0x3A8]
00007accb5bd7aa6  movaps [rdi], xmm12
00007accb5bd7aaa  movaps [rsi], xmm15
00007accb5bd7aae  movaps [rdx], xmm1
00007accb5bd7ab1  movaps [rcx], xmm14
00007accb5bd7ab5  mov rax, 0x59156B40DA50
00007accb5bd7abf  call rax
00007accb5bd7ac1  movaps xmm12, [rsp]
00007accb5bd7ac6  add rsp, 0x40
00007accb5bd7aca  vmovaps xmm0, [rsp]
00007accb5bd7acf  vmovaps xmm1, [rsp+0x10]
00007accb5bd7ad5  vmovaps xmm2, [rsp+0x20]
00007accb5bd7adb  vmovaps xmm3, [rsp+0x30]
00007accb5bd7ae1  vmovaps xmm4, [rsp+0x40]
00007accb5bd7ae7  vmovaps xmm5, [rsp+0x50]
00007accb5bd7aed  vmovaps xmm6, [rsp+0x60]
00007accb5bd7af3  vmovaps xmm7, [rsp+0x70]
00007accb5bd7af9  vmovaps xmm8, [rsp+0x80]
00007accb5bd7b02  vmovaps xmm9, [rsp+0x90]
00007accb5bd7b0b  vmovaps xmm10, [rsp+0xA0]
00007accb5bd7b14  vmovaps xmm11, [rsp+0xB0]
00007accb5bd7b1d  vmovaps xmm13, [rsp+0xC0]
00007accb5bd7b26  vmovaps xmm14, [rsp+0xD0]
00007accb5bd7b2f  vmovaps xmm15, [rsp+0xE0]
00007accb5bd7b38  add rsp, 0xF0
00007accb5bd7b3f  pop r11
00007accb5bd7b41  pop r10
00007accb5bd7b43  pop r9
00007accb5bd7b45  pop r8
00007accb5bd7b47  pop rsi
00007accb5bd7b48  pop rdi
00007accb5bd7b49  pop rdx
00007accb5bd7b4a  pop rcx
00007accb5bd7b4b  pop rax
00007accb5bd7b4c  add rsp, 0x08
00007accb5bd7b50  jmp 0x00007ACCB5BD6CCC
00007accb5bd7b55  sub rsp, 0x08
00007accb5bd7b59  push rax
00007accb5bd7b5a  push rcx
00007accb5bd7b5b  push rdx
00007accb5bd7b5c  push rdi
00007accb5bd7b5d  push rsi
00007accb5bd7b5e  push r8
00007accb5bd7b60  push r9
00007accb5bd7b62  push r10
00007accb5bd7b64  push r11
00007accb5bd7b66  sub rsp, 0xF0
00007accb5bd7b6d  vmovaps [rsp], xmm0
00007accb5bd7b72  vmovaps [rsp+0x10], xmm1
00007accb5bd7b78  vmovaps [rsp+0x20], xmm2
00007accb5bd7b7e  vmovaps [rsp+0x30], xmm3
00007accb5bd7b84  vmovaps [rsp+0x40], xmm4
00007accb5bd7b8a  vmovaps [rsp+0x50], xmm5
00007accb5bd7b90  vmovaps [rsp+0x60], xmm6
00007accb5bd7b96  vmovaps [rsp+0x70], xmm7
00007accb5bd7b9c  vmovaps [rsp+0x80], xmm8
00007accb5bd7ba5  vmovaps [rsp+0x90], xmm9
00007accb5bd7bae  vmovaps [rsp+0xA0], xmm10
00007accb5bd7bb7  vmovaps [rsp+0xB0], xmm11
00007accb5bd7bc0  vmovaps [rsp+0xC0], xmm12
00007accb5bd7bc9  vmovaps [rsp+0xD0], xmm14
00007accb5bd7bd2  vmovaps [rsp+0xE0], xmm15
00007accb5bd7bdb  sub rsp, 0x40
00007accb5bd7bdf  lea rdi, [rsp]
00007accb5bd7be3  lea rsi, [rsp+0x10]
00007accb5bd7be8  lea rdx, [rsp+0x20]
00007accb5bd7bed  lea rcx, [rsp+0x30]
00007accb5bd7bf2  mov r8d, 0x00
00007accb5bd7bf8  lea r9, [r15+0x3A8]
00007accb5bd7bff  movaps [rdi], xmm13
00007accb5bd7c03  movaps [rsi], xmm1
00007accb5bd7c06  movaps [rdx], xmm15
00007accb5bd7c0a  movaps [rcx], xmm14
00007accb5bd7c0e  mov rax, 0x59156B40DA50
00007accb5bd7c18  call rax
00007accb5bd7c1a  movaps xmm13, [rsp]
00007accb5bd7c1f  add rsp, 0x40
00007accb5bd7c23  vmovaps xmm0, [rsp]
00007accb5bd7c28  vmovaps xmm1, [rsp+0x10]
00007accb5bd7c2e  vmovaps xmm2, [rsp+0x20]
00007accb5bd7c34  vmovaps xmm3, [rsp+0x30]
00007accb5bd7c3a  vmovaps xmm4, [rsp+0x40]
00007accb5bd7c40  vmovaps xmm5, [rsp+0x50]
00007accb5bd7c46  vmovaps xmm6, [rsp+0x60]
00007accb5bd7c4c  vmovaps xmm7, [rsp+0x70]
00007accb5bd7c52  vmovaps xmm8, [rsp+0x80]
00007accb5bd7c5b  vmovaps xmm9, [rsp+0x90]
00007accb5bd7c64  vmovaps xmm10, [rsp+0xA0]
00007accb5bd7c6d  vmovaps xmm11, [rsp+0xB0]
00007accb5bd7c76  vmovaps xmm12, [rsp+0xC0]
00007accb5bd7c7f  vmovaps xmm14, [rsp+0xD0]
00007accb5bd7c88  vmovaps xmm15, [rsp+0xE0]
00007accb5bd7c91  add rsp, 0xF0
00007accb5bd7c98  pop r11
00007accb5bd7c9a  pop r10
00007accb5bd7c9c  pop r9
00007accb5bd7c9e  pop r8
00007accb5bd7ca0  pop rsi
00007accb5bd7ca1  pop rdi
00007accb5bd7ca2  pop rdx
00007accb5bd7ca3  pop rcx
00007accb5bd7ca4  pop rax
00007accb5bd7ca5  add rsp, 0x08
00007accb5bd7ca9  jmp 0x00007ACCB5BD6E6D
00007accb5bd7cae  sub rsp, 0x08
00007accb5bd7cb2  push rax
00007accb5bd7cb3  push rcx
00007accb5bd7cb4  push rdx
00007accb5bd7cb5  push rdi
00007accb5bd7cb6  push rsi
00007accb5bd7cb7  push r8
00007accb5bd7cb9  push r9
00007accb5bd7cbb  push r10
00007accb5bd7cbd  push r11
00007accb5bd7cbf  sub rsp, 0xF0
00007accb5bd7cc6  vmovaps [rsp], xmm0
00007accb5bd7ccb  vmovaps [rsp+0x10], xmm1
00007accb5bd7cd1  vmovaps [rsp+0x20], xmm2
00007accb5bd7cd7  vmovaps [rsp+0x30], xmm3
00007accb5bd7cdd  vmovaps [rsp+0x40], xmm4
00007accb5bd7ce3  vmovaps [rsp+0x50], xmm5
00007accb5bd7ce9  vmovaps [rsp+0x60], xmm6
00007accb5bd7cef  vmovaps [rsp+0x70], xmm7
00007accb5bd7cf5  vmovaps [rsp+0x80], xmm8
00007accb5bd7cfe  vmovaps [rsp+0x90], xmm9
00007accb5bd7d07  vmovaps [rsp+0xA0], xmm10
00007accb5bd7d10  vmovaps [rsp+0xB0], xmm11
00007accb5bd7d19  vmovaps [rsp+0xC0], xmm13
00007accb5bd7d22  vmovaps [rsp+0xD0], xmm14
00007accb5bd7d2b  vmovaps [rsp+0xE0], xmm15
00007accb5bd7d34  sub rsp, 0x40
00007accb5bd7d38  lea rdi, [rsp]
00007accb5bd7d3c  lea rsi, [rsp+0x10]
00007accb5bd7d41  lea rdx, [rsp+0x20]
00007accb5bd7d46  lea rcx, [rsp+0x30]
00007accb5bd7d4b  mov r8d, 0x00
00007accb5bd7d51  lea r9, [r15+0x3A8]
00007accb5bd7d58  movaps [rdi], xmm12
00007accb5bd7d5c  movaps [rsi], xmm15
00007accb5bd7d60  movaps [rdx], xmm14
00007accb5bd7d64  movaps [rcx], xmm1
00007accb5bd7d67  mov rax, 0x59156B40DA50
00007accb5bd7d71  call rax
00007accb5bd7d73  movaps xmm12, [rsp]
00007accb5bd7d78  add rsp, 0x40
00007accb5bd7d7c  vmovaps xmm0, [rsp]
00007accb5bd7d81  vmovaps xmm1, [rsp+0x10]
00007accb5bd7d87  vmovaps xmm2, [rsp+0x20]
00007accb5bd7d8d  vmovaps xmm3, [rsp+0x30]
00007accb5bd7d93  vmovaps xmm4, [rsp+0x40]
00007accb5bd7d99  vmovaps xmm5, [rsp+0x50]
00007accb5bd7d9f  vmovaps xmm6, [rsp+0x60]
00007accb5bd7da5  vmovaps xmm7, [rsp+0x70]
00007accb5bd7dab  vmovaps xmm8, [rsp+0x80]
00007accb5bd7db4  vmovaps xmm9, [rsp+0x90]
00007accb5bd7dbd  vmovaps xmm10, [rsp+0xA0]
00007accb5bd7dc6  vmovaps xmm11, [rsp+0xB0]
00007accb5bd7dcf  vmovaps xmm13, [rsp+0xC0]
00007accb5bd7dd8  vmovaps xmm14, [rsp+0xD0]
00007accb5bd7de1  vmovaps xmm15, [rsp+0xE0]
00007accb5bd7dea  add rsp, 0xF0
00007accb5bd7df1  pop r11
00007accb5bd7df3  pop r10
00007accb5bd7df5  pop r9
00007accb5bd7df7  pop r8
00007accb5bd7df9  pop rsi
00007accb5bd7dfa  pop rdi
00007accb5bd7dfb  pop rdx
00007accb5bd7dfc  pop rcx
00007accb5bd7dfd  pop rax
00007accb5bd7dfe  add rsp, 0x08
00007accb5bd7e02  jmp 0x00007ACCB5BD6EAB
00007accb5bd7e07  sub rsp, 0x08
00007accb5bd7e0b  push rax
00007accb5bd7e0c  push rcx
00007accb5bd7e0d  push rdx
00007accb5bd7e0e  push rdi
00007accb5bd7e0f  push rsi
00007accb5bd7e10  push r8
00007accb5bd7e12  push r9
00007accb5bd7e14  push r10
00007accb5bd7e16  push r11
00007accb5bd7e18  sub rsp, 0xF0
00007accb5bd7e1f  vmovaps [rsp], xmm0
00007accb5bd7e24  vmovaps [rsp+0x10], xmm1
00007accb5bd7e2a  vmovaps [rsp+0x20], xmm2
00007accb5bd7e30  vmovaps [rsp+0x30], xmm3
00007accb5bd7e36  vmovaps [rsp+0x40], xmm4
00007accb5bd7e3c  vmovaps [rsp+0x50], xmm5
00007accb5bd7e42  vmovaps [rsp+0x60], xmm6
00007accb5bd7e48  vmovaps [rsp+0x70], xmm7
00007accb5bd7e4e  vmovaps [rsp+0x80], xmm8
00007accb5bd7e57  vmovaps [rsp+0x90], xmm9
00007accb5bd7e60  vmovaps [rsp+0xA0], xmm10
00007accb5bd7e69  vmovaps [rsp+0xB0], xmm11
00007accb5bd7e72  vmovaps [rsp+0xC0], xmm12
00007accb5bd7e7b  vmovaps [rsp+0xD0], xmm14
00007accb5bd7e84  vmovaps [rsp+0xE0], xmm15
00007accb5bd7e8d  sub rsp, 0x40
00007accb5bd7e91  lea rdi, [rsp]
00007accb5bd7e95  lea rsi, [rsp+0x10]
00007accb5bd7e9a  lea rdx, [rsp+0x20]
00007accb5bd7e9f  lea rcx, [rsp+0x30]
00007accb5bd7ea4  mov r8d, 0x00
00007accb5bd7eaa  lea r9, [r15+0x3A8]
00007accb5bd7eb1  movaps [rdi], xmm13
00007accb5bd7eb5  movaps [rsi], xmm15
00007accb5bd7eb9  movaps [rdx], xmm14
00007accb5bd7ebd  movaps [rcx], xmm1
00007accb5bd7ec0  mov rax, 0x59156B40DA50
00007accb5bd7eca  call rax
00007accb5bd7ecc  movaps xmm13, [rsp]
00007accb5bd7ed1  add rsp, 0x40
00007accb5bd7ed5  vmovaps xmm0, [rsp]
00007accb5bd7eda  vmovaps xmm1, [rsp+0x10]
00007accb5bd7ee0  vmovaps xmm2, [rsp+0x20]
00007accb5bd7ee6  vmovaps xmm3, [rsp+0x30]
00007accb5bd7eec  vmovaps xmm4, [rsp+0x40]
00007accb5bd7ef2  vmovaps xmm5, [rsp+0x50]
00007accb5bd7ef8  vmovaps xmm6, [rsp+0x60]
00007accb5bd7efe  vmovaps xmm7, [rsp+0x70]
00007accb5bd7f04  vmovaps xmm8, [rsp+0x80]
00007accb5bd7f0d  vmovaps xmm9, [rsp+0x90]
00007accb5bd7f16  vmovaps xmm10, [rsp+0xA0]
00007accb5bd7f1f  vmovaps xmm11, [rsp+0xB0]
00007accb5bd7f28  vmovaps xmm12, [rsp+0xC0]
00007accb5bd7f31  vmovaps xmm14, [rsp+0xD0]
00007accb5bd7f3a  vmovaps xmm15, [rsp+0xE0]
00007accb5bd7f43  add rsp, 0xF0
00007accb5bd7f4a  pop r11
00007accb5bd7f4c  pop r10
00007accb5bd7f4e  pop r9
00007accb5bd7f50  pop r8
00007accb5bd7f52  pop rsi
00007accb5bd7f53  pop rdi
00007accb5bd7f54  pop rdx
00007accb5bd7f55  pop rcx
00007accb5bd7f56  pop rax
00007accb5bd7f57  add rsp, 0x08
00007accb5bd7f5b  jmp 0x00007ACCB5BD6EE9
00007accb5bd7f60  sub rsp, 0x08
00007accb5bd7f64  push rax
00007accb5bd7f65  push rcx
00007accb5bd7f66  push rdx
00007accb5bd7f67  push rdi
00007accb5bd7f68  push rsi
00007accb5bd7f69  push r8
00007accb5bd7f6b  push r9
00007accb5bd7f6d  push r10
00007accb5bd7f6f  push r11
00007accb5bd7f71  sub rsp, 0xF0
00007accb5bd7f78  vmovaps [rsp], xmm0
00007accb5bd7f7d  vmovaps [rsp+0x10], xmm1
00007accb5bd7f83  vmovaps [rsp+0x20], xmm2
00007accb5bd7f89  vmovaps [rsp+0x30], xmm3
00007accb5bd7f8f  vmovaps [rsp+0x40], xmm4
00007accb5bd7f95  vmovaps [rsp+0x50], xmm5
00007accb5bd7f9b  vmovaps [rsp+0x60], xmm6
00007accb5bd7fa1  vmovaps [rsp+0x70], xmm7
00007accb5bd7fa7  vmovaps [rsp+0x80], xmm8
00007accb5bd7fb0  vmovaps [rsp+0x90], xmm9
00007accb5bd7fb9  vmovaps [rsp+0xA0], xmm10
00007accb5bd7fc2  vmovaps [rsp+0xB0], xmm11
00007accb5bd7fcb  vmovaps [rsp+0xC0], xmm13
00007accb5bd7fd4  vmovaps [rsp+0xD0], xmm14
00007accb5bd7fdd  vmovaps [rsp+0xE0], xmm15
00007accb5bd7fe6  sub rsp, 0x40
00007accb5bd7fea  lea rdi, [rsp]
00007accb5bd7fee  lea rsi, [rsp+0x10]
00007accb5bd7ff3  lea rdx, [rsp+0x20]
00007accb5bd7ff8  lea rcx, [rsp+0x30]
00007accb5bd7ffd  mov r8d, 0x00
00007accb5bd8003  lea r9, [r15+0x3A8]
00007accb5bd800a  movaps [rdi], xmm12
00007accb5bd800e  movaps [rsi], xmm14
00007accb5bd8012  movaps [rdx], xmm2
00007accb5bd8015  movaps [rcx], xmm15
00007accb5bd8019  mov rax, 0x59156B40DA50
00007accb5bd8023  call rax
00007accb5bd8025  movaps xmm12, [rsp]
00007accb5bd802a  add rsp, 0x40
00007accb5bd802e  vmovaps xmm0, [rsp]
00007accb5bd8033  vmovaps xmm1, [rsp+0x10]
00007accb5bd8039  vmovaps xmm2, [rsp+0x20]
00007accb5bd803f  vmovaps xmm3, [rsp+0x30]
00007accb5bd8045  vmovaps xmm4, [rsp+0x40]
00007accb5bd804b  vmovaps xmm5, [rsp+0x50]
00007accb5bd8051  vmovaps xmm6, [rsp+0x60]
00007accb5bd8057  vmovaps xmm7, [rsp+0x70]
00007accb5bd805d  vmovaps xmm8, [rsp+0x80]
00007accb5bd8066  vmovaps xmm9, [rsp+0x90]
00007accb5bd806f  vmovaps xmm10, [rsp+0xA0]
00007accb5bd8078  vmovaps xmm11, [rsp+0xB0]
00007accb5bd8081  vmovaps xmm13, [rsp+0xC0]
00007accb5bd808a  vmovaps xmm14, [rsp+0xD0]
00007accb5bd8093  vmovaps xmm15, [rsp+0xE0]
00007accb5bd809c  add rsp, 0xF0
00007accb5bd80a3  pop r11
00007accb5bd80a5  pop r10
00007accb5bd80a7  pop r9
00007accb5bd80a9  pop r8
00007accb5bd80ab  pop rsi
00007accb5bd80ac  pop rdi
00007accb5bd80ad  pop rdx
00007accb5bd80ae  pop rcx
00007accb5bd80af  pop rax
00007accb5bd80b0  add rsp, 0x08
00007accb5bd80b4  jmp 0x00007ACCB5BD6F43
00007accb5bd80b9  sub rsp, 0x08
00007accb5bd80bd  push rax
00007accb5bd80be  push rcx
00007accb5bd80bf  push rdx
00007accb5bd80c0  push rdi
00007accb5bd80c1  push rsi
00007accb5bd80c2  push r8
00007accb5bd80c4  push r9
00007accb5bd80c6  push r10
00007accb5bd80c8  push r11
00007accb5bd80ca  sub rsp, 0xF0
00007accb5bd80d1  vmovaps [rsp], xmm0
00007accb5bd80d6  vmovaps [rsp+0x10], xmm1
00007accb5bd80dc  vmovaps [rsp+0x20], xmm3
00007accb5bd80e2  vmovaps [rsp+0x30], xmm4
00007accb5bd80e8  vmovaps [rsp+0x40], xmm5
00007accb5bd80ee  vmovaps [rsp+0x50], xmm6
00007accb5bd80f4  vmovaps [rsp+0x60], xmm7
00007accb5bd80fa  vmovaps [rsp+0x70], xmm8
00007accb5bd8100  vmovaps [rsp+0x80], xmm9
00007accb5bd8109  vmovaps [rsp+0x90], xmm10
00007accb5bd8112  vmovaps [rsp+0xA0], xmm11
00007accb5bd811b  vmovaps [rsp+0xB0], xmm12
00007accb5bd8124  vmovaps [rsp+0xC0], xmm13
00007accb5bd812d  vmovaps [rsp+0xD0], xmm14
00007accb5bd8136  vmovaps [rsp+0xE0], xmm15
00007accb5bd813f  sub rsp, 0x40
00007accb5bd8143  lea rdi, [rsp]
00007accb5bd8147  lea rsi, [rsp+0x10]
00007accb5bd814c  lea rdx, [rsp+0x20]
00007accb5bd8151  lea rcx, [rsp+0x30]
00007accb5bd8156  mov r8d, 0x00
00007accb5bd815c  lea r9, [r15+0x3A8]
00007accb5bd8163  movaps [rdi], xmm2
00007accb5bd8166  movaps [rsi], xmm14
00007accb5bd816a  movaps [rdx], xmm8
00007accb5bd816e  movaps [rcx], xmm5
00007accb5bd8171  mov rax, 0x59156B40DA50
00007accb5bd817b  call rax
00007accb5bd817d  movaps xmm2, [rsp]
00007accb5bd8181  add rsp, 0x40
00007accb5bd8185  vmovaps xmm0, [rsp]
00007accb5bd818a  vmovaps xmm1, [rsp+0x10]
00007accb5bd8190  vmovaps xmm3, [rsp+0x20]
00007accb5bd8196  vmovaps xmm4, [rsp+0x30]
00007accb5bd819c  vmovaps xmm5, [rsp+0x40]
00007accb5bd81a2  vmovaps xmm6, [rsp+0x50]
00007accb5bd81a8  vmovaps xmm7, [rsp+0x60]
00007accb5bd81ae  vmovaps xmm8, [rsp+0x70]
00007accb5bd81b4  vmovaps xmm9, [rsp+0x80]
00007accb5bd81bd  vmovaps xmm10, [rsp+0x90]
00007accb5bd81c6  vmovaps xmm11, [rsp+0xA0]
00007accb5bd81cf  vmovaps xmm12, [rsp+0xB0]
00007accb5bd81d8  vmovaps xmm13, [rsp+0xC0]
00007accb5bd81e1  vmovaps xmm14, [rsp+0xD0]
00007accb5bd81ea  vmovaps xmm15, [rsp+0xE0]
00007accb5bd81f3  add rsp, 0xF0
00007accb5bd81fa  pop r11
00007accb5bd81fc  pop r10
00007accb5bd81fe  pop r9
00007accb5bd8200  pop r8
00007accb5bd8202  pop rsi
00007accb5bd8203  pop rdi
00007accb5bd8204  pop rdx
00007accb5bd8205  pop rcx
00007accb5bd8206  pop rax
00007accb5bd8207  add rsp, 0x08
00007accb5bd820b  jmp 0x00007ACCB5BD6FF7
00007accb5bd8210  sub rsp, 0x08
00007accb5bd8214  push rax
00007accb5bd8215  push rcx
00007accb5bd8216  push rdx
00007accb5bd8217  push rdi
00007accb5bd8218  push rsi
00007accb5bd8219  push r8
00007accb5bd821b  push r9
00007accb5bd821d  push r10
00007accb5bd821f  push r11
00007accb5bd8221  sub rsp, 0xF0
00007accb5bd8228  vmovaps [rsp], xmm0
00007accb5bd822d  vmovaps [rsp+0x10], xmm1
00007accb5bd8233  vmovaps [rsp+0x20], xmm2
00007accb5bd8239  vmovaps [rsp+0x30], xmm3
00007accb5bd823f  vmovaps [rsp+0x40], xmm4
00007accb5bd8245  vmovaps [rsp+0x50], xmm6
00007accb5bd824b  vmovaps [rsp+0x60], xmm7
00007accb5bd8251  vmovaps [rsp+0x70], xmm8
00007accb5bd8257  vmovaps [rsp+0x80], xmm9
00007accb5bd8260  vmovaps [rsp+0x90], xmm10
00007accb5bd8269  vmovaps [rsp+0xA0], xmm11
00007accb5bd8272  vmovaps [rsp+0xB0], xmm12
00007accb5bd827b  vmovaps [rsp+0xC0], xmm13
00007accb5bd8284  vmovaps [rsp+0xD0], xmm14
00007accb5bd828d  vmovaps [rsp+0xE0], xmm15
00007accb5bd8296  sub rsp, 0x40
00007accb5bd829a  lea rdi, [rsp]
00007accb5bd829e  lea rsi, [rsp+0x10]
00007accb5bd82a3  lea rdx, [rsp+0x20]
00007accb5bd82a8  lea rcx, [rsp+0x30]
00007accb5bd82ad  mov r8d, 0x00
00007accb5bd82b3  lea r9, [r15+0x3A8]
00007accb5bd82ba  movaps [rdi], xmm5
00007accb5bd82bd  movaps [rsi], xmm14
00007accb5bd82c1  movaps [rdx], xmm8
00007accb5bd82c5  movaps [rcx], xmm1
00007accb5bd82c8  mov rax, 0x59156B40DA50
00007accb5bd82d2  call rax
00007accb5bd82d4  movaps xmm5, [rsp]
00007accb5bd82d8  add rsp, 0x40
00007accb5bd82dc  vmovaps xmm0, [rsp]
00007accb5bd82e1  vmovaps xmm1, [rsp+0x10]
00007accb5bd82e7  vmovaps xmm2, [rsp+0x20]
00007accb5bd82ed  vmovaps xmm3, [rsp+0x30]
00007accb5bd82f3  vmovaps xmm4, [rsp+0x40]
00007accb5bd82f9  vmovaps xmm6, [rsp+0x50]
00007accb5bd82ff  vmovaps xmm7, [rsp+0x60]
00007accb5bd8305  vmovaps xmm8, [rsp+0x70]
00007accb5bd830b  vmovaps xmm9, [rsp+0x80]
00007accb5bd8314  vmovaps xmm10, [rsp+0x90]
00007accb5bd831d  vmovaps xmm11, [rsp+0xA0]
00007accb5bd8326  vmovaps xmm12, [rsp+0xB0]
00007accb5bd832f  vmovaps xmm13, [rsp+0xC0]
00007accb5bd8338  vmovaps xmm14, [rsp+0xD0]
00007accb5bd8341  vmovaps xmm15, [rsp+0xE0]
00007accb5bd834a  add rsp, 0xF0
00007accb5bd8351  pop r11
00007accb5bd8353  pop r10
00007accb5bd8355  pop r9
00007accb5bd8357  pop r8
00007accb5bd8359  pop rsi
00007accb5bd835a  pop rdi
00007accb5bd835b  pop rdx
00007accb5bd835c  pop rcx
00007accb5bd835d  pop rax
00007accb5bd835e  add rsp, 0x08
00007accb5bd8362  jmp 0x00007ACCB5BD7034
00007accb5bd8367  sub rsp, 0x08
00007accb5bd836b  push rax
00007accb5bd836c  push rcx
00007accb5bd836d  push rdx
00007accb5bd836e  push rdi
00007accb5bd836f  push rsi
00007accb5bd8370  push r8
00007accb5bd8372  push r9
00007accb5bd8374  push r10
00007accb5bd8376  push r11
00007accb5bd8378  sub rsp, 0xF0
00007accb5bd837f  vmovaps [rsp], xmm0
00007accb5bd8384  vmovaps [rsp+0x10], xmm1
00007accb5bd838a  vmovaps [rsp+0x20], xmm2
00007accb5bd8390  vmovaps [rsp+0x30], xmm3
00007accb5bd8396  vmovaps [rsp+0x40], xmm4
00007accb5bd839c  vmovaps [rsp+0x50], xmm5
00007accb5bd83a2  vmovaps [rsp+0x60], xmm6
00007accb5bd83a8  vmovaps [rsp+0x70], xmm7
00007accb5bd83ae  vmovaps [rsp+0x80], xmm8
00007accb5bd83b7  vmovaps [rsp+0x90], xmm9
00007accb5bd83c0  vmovaps [rsp+0xA0], xmm10
00007accb5bd83c9  vmovaps [rsp+0xB0], xmm11
00007accb5bd83d2  vmovaps [rsp+0xC0], xmm12
00007accb5bd83db  vmovaps [rsp+0xD0], xmm13
00007accb5bd83e4  vmovaps [rsp+0xE0], xmm14
00007accb5bd83ed  sub rsp, 0x40
00007accb5bd83f1  lea rdi, [rsp]
00007accb5bd83f5  lea rsi, [rsp+0x10]
00007accb5bd83fa  lea rdx, [rsp+0x20]
00007accb5bd83ff  lea rcx, [rsp+0x30]
00007accb5bd8404  mov r8d, 0x00
00007accb5bd840a  lea r9, [r15+0x3A8]
00007accb5bd8411  movaps [rdi], xmm15
00007accb5bd8415  movaps [rsi], xmm13
00007accb5bd8419  movaps [rdx], xmm14
00007accb5bd841d  movaps [rcx], xmm1
00007accb5bd8420  mov rax, 0x59156B40DA50
00007accb5bd842a  call rax
00007accb5bd842c  movaps xmm15, [rsp]
00007accb5bd8431  add rsp, 0x40
00007accb5bd8435  vmovaps xmm0, [rsp]
00007accb5bd843a  vmovaps xmm1, [rsp+0x10]
00007accb5bd8440  vmovaps xmm2, [rsp+0x20]
00007accb5bd8446  vmovaps xmm3, [rsp+0x30]
00007accb5bd844c  vmovaps xmm4, [rsp+0x40]
00007accb5bd8452  vmovaps xmm5, [rsp+0x50]
00007accb5bd8458  vmovaps xmm6, [rsp+0x60]
00007accb5bd845e  vmovaps xmm7, [rsp+0x70]
00007accb5bd8464  vmovaps xmm8, [rsp+0x80]
00007accb5bd846d  vmovaps xmm9, [rsp+0x90]
00007accb5bd8476  vmovaps xmm10, [rsp+0xA0]
00007accb5bd847f  vmovaps xmm11, [rsp+0xB0]
00007accb5bd8488  vmovaps xmm12, [rsp+0xC0]
00007accb5bd8491  vmovaps xmm13, [rsp+0xD0]
00007accb5bd849a  vmovaps xmm14, [rsp+0xE0]
00007accb5bd84a3  add rsp, 0xF0
00007accb5bd84aa  pop r11
00007accb5bd84ac  pop r10
00007accb5bd84ae  pop r9
00007accb5bd84b0  pop r8
00007accb5bd84b2  pop rsi
00007accb5bd84b3  pop rdi
00007accb5bd84b4  pop rdx
00007accb5bd84b5  pop rcx
00007accb5bd84b6  pop rax
00007accb5bd84b7  add rsp, 0x08
00007accb5bd84bb  jmp 0x00007ACCB5BD7063
00007accb5bd84c0  sub rsp, 0x08
00007accb5bd84c4  push rax
00007accb5bd84c5  push rcx
00007accb5bd84c6  push rdx
00007accb5bd84c7  push rdi
00007accb5bd84c8  push rsi
00007accb5bd84c9  push r8
00007accb5bd84cb  push r9
00007accb5bd84cd  push r10
00007accb5bd84cf  push r11
00007accb5bd84d1  sub rsp, 0xF0
00007accb5bd84d8  vmovaps [rsp], xmm0
00007accb5bd84dd  vmovaps [rsp+0x10], xmm1
00007accb5bd84e3  vmovaps [rsp+0x20], xmm2
00007accb5bd84e9  vmovaps [rsp+0x30], xmm3
00007accb5bd84ef  vmovaps [rsp+0x40], xmm4
00007accb5bd84f5  vmovaps [rsp+0x50], xmm5
00007accb5bd84fb  vmovaps [rsp+0x60], xmm6
00007accb5bd8501  vmovaps [rsp+0x70], xmm7
00007accb5bd8507  vmovaps [rsp+0x80], xmm8
00007accb5bd8510  vmovaps [rsp+0x90], xmm9
00007accb5bd8519  vmovaps [rsp+0xA0], xmm10
00007accb5bd8522  vmovaps [rsp+0xB0], xmm11
00007accb5bd852b  vmovaps [rsp+0xC0], xmm12
00007accb5bd8534  vmovaps [rsp+0xD0], xmm14
00007accb5bd853d  vmovaps [rsp+0xE0], xmm15
00007accb5bd8546  sub rsp, 0x40
00007accb5bd854a  lea rdi, [rsp]
00007accb5bd854e  lea rsi, [rsp+0x10]
00007accb5bd8553  lea rdx, [rsp+0x20]
00007accb5bd8558  lea rcx, [rsp+0x30]
00007accb5bd855d  mov r8d, 0x00
00007accb5bd8563  lea r9, [r15+0x3A8]
00007accb5bd856a  movaps [rdi], xmm13
00007accb5bd856e  movaps [rsi], xmm12
00007accb5bd8572  movaps [rdx], xmm14
00007accb5bd8576  movaps [rcx], xmm1
00007accb5bd8579  mov rax, 0x59156B40DA50
00007accb5bd8583  call rax
00007accb5bd8585  movaps xmm13, [rsp]
00007accb5bd858a  add rsp, 0x40
00007accb5bd858e  vmovaps xmm0, [rsp]
00007accb5bd8593  vmovaps xmm1, [rsp+0x10]
00007accb5bd8599  vmovaps xmm2, [rsp+0x20]
00007accb5bd859f  vmovaps xmm3, [rsp+0x30]
00007accb5bd85a5  vmovaps xmm4, [rsp+0x40]
00007accb5bd85ab  vmovaps xmm5, [rsp+0x50]
00007accb5bd85b1  vmovaps xmm6, [rsp+0x60]
00007accb5bd85b7  vmovaps xmm7, [rsp+0x70]
00007accb5bd85bd  vmovaps xmm8, [rsp+0x80]
00007accb5bd85c6  vmovaps xmm9, [rsp+0x90]
00007accb5bd85cf  vmovaps xmm10, [rsp+0xA0]
00007accb5bd85d8  vmovaps xmm11, [rsp+0xB0]
00007accb5bd85e1  vmovaps xmm12, [rsp+0xC0]
00007accb5bd85ea  vmovaps xmm14, [rsp+0xD0]
00007accb5bd85f3  vmovaps xmm15, [rsp+0xE0]
00007accb5bd85fc  add rsp, 0xF0
00007accb5bd8603  pop r11
00007accb5bd8605  pop r10
00007accb5bd8607  pop r9
00007accb5bd8609  pop r8
00007accb5bd860b  pop rsi
00007accb5bd860c  pop rdi
00007accb5bd860d  pop rdx
00007accb5bd860e  pop rcx
00007accb5bd860f  pop rax
00007accb5bd8610  add rsp, 0x08
00007accb5bd8614  jmp 0x00007ACCB5BD7095
00007accb5bd8619  sub rsp, 0x08
00007accb5bd861d  push rax
00007accb5bd861e  push rcx
00007accb5bd861f  push rdx
00007accb5bd8620  push rdi
00007accb5bd8621  push rsi
00007accb5bd8622  push r8
00007accb5bd8624  push r9
00007accb5bd8626  push r10
00007accb5bd8628  push r11
00007accb5bd862a  sub rsp, 0xF0
00007accb5bd8631  vmovaps [rsp], xmm0
00007accb5bd8636  vmovaps [rsp+0x10], xmm1
00007accb5bd863c  vmovaps [rsp+0x20], xmm2
00007accb5bd8642  vmovaps [rsp+0x30], xmm3
00007accb5bd8648  vmovaps [rsp+0x40], xmm4
00007accb5bd864e  vmovaps [rsp+0x50], xmm5
00007accb5bd8654  vmovaps [rsp+0x60], xmm6
00007accb5bd865a  vmovaps [rsp+0x70], xmm7
00007accb5bd8660  vmovaps [rsp+0x80], xmm8
00007accb5bd8669  vmovaps [rsp+0x90], xmm9
00007accb5bd8672  vmovaps [rsp+0xA0], xmm10
00007accb5bd867b  vmovaps [rsp+0xB0], xmm11
00007accb5bd8684  vmovaps [rsp+0xC0], xmm13
00007accb5bd868d  vmovaps [rsp+0xD0], xmm14
00007accb5bd8696  vmovaps [rsp+0xE0], xmm15
00007accb5bd869f  sub rsp, 0x40
00007accb5bd86a3  lea rdi, [rsp]
00007accb5bd86a7  lea rsi, [rsp+0x10]
00007accb5bd86ac  lea rdx, [rsp+0x20]
00007accb5bd86b1  lea rcx, [rsp+0x30]
00007accb5bd86b6  mov r8d, 0x00
00007accb5bd86bc  lea r9, [r15+0x3A8]
00007accb5bd86c3  movaps [rdi], xmm12
00007accb5bd86c7  movaps [rsi], xmm5
00007accb5bd86ca  movaps [rdx], xmm14
00007accb5bd86ce  movaps [rcx], xmm4
00007accb5bd86d1  mov rax, 0x59156B40DA50
00007accb5bd86db  call rax
00007accb5bd86dd  movaps xmm12, [rsp]
00007accb5bd86e2  add rsp, 0x40
00007accb5bd86e6  vmovaps xmm0, [rsp]
00007accb5bd86eb  vmovaps xmm1, [rsp+0x10]
00007accb5bd86f1  vmovaps xmm2, [rsp+0x20]
00007accb5bd86f7  vmovaps xmm3, [rsp+0x30]
00007accb5bd86fd  vmovaps xmm4, [rsp+0x40]
00007accb5bd8703  vmovaps xmm5, [rsp+0x50]
00007accb5bd8709  vmovaps xmm6, [rsp+0x60]
00007accb5bd870f  vmovaps xmm7, [rsp+0x70]
00007accb5bd8715  vmovaps xmm8, [rsp+0x80]
00007accb5bd871e  vmovaps xmm9, [rsp+0x90]
00007accb5bd8727  vmovaps xmm10, [rsp+0xA0]
00007accb5bd8730  vmovaps xmm11, [rsp+0xB0]
00007accb5bd8739  vmovaps xmm13, [rsp+0xC0]
00007accb5bd8742  vmovaps xmm14, [rsp+0xD0]
00007accb5bd874b  vmovaps xmm15, [rsp+0xE0]
00007accb5bd8754  add rsp, 0xF0
00007accb5bd875b  pop r11
00007accb5bd875d  pop r10
00007accb5bd875f  pop r9
00007accb5bd8761  pop r8
00007accb5bd8763  pop rsi
00007accb5bd8764  pop rdi
00007accb5bd8765  pop rdx
00007accb5bd8766  pop rcx
00007accb5bd8767  pop rax
00007accb5bd8768  add rsp, 0x08
00007accb5bd876c  jmp 0x00007ACCB5BD710B
00007accb5bd8771  sub rsp, 0x08
00007accb5bd8775  push rax
00007accb5bd8776  push rcx
00007accb5bd8777  push rdx
00007accb5bd8778  push rdi
00007accb5bd8779  push rsi
00007accb5bd877a  push r8
00007accb5bd877c  push r9
00007accb5bd877e  push r10
00007accb5bd8780  push r11
00007accb5bd8782  sub rsp, 0xF0
00007accb5bd8789  vmovaps [rsp], xmm0
00007accb5bd878e  vmovaps [rsp+0x10], xmm1
00007accb5bd8794  vmovaps [rsp+0x20], xmm2
00007accb5bd879a  vmovaps [rsp+0x30], xmm3
00007accb5bd87a0  vmovaps [rsp+0x40], xmm4
00007accb5bd87a6  vmovaps [rsp+0x50], xmm5
00007accb5bd87ac  vmovaps [rsp+0x60], xmm6
00007accb5bd87b2  vmovaps [rsp+0x70], xmm7
00007accb5bd87b8  vmovaps [rsp+0x80], xmm8
00007accb5bd87c1  vmovaps [rsp+0x90], xmm9
00007accb5bd87ca  vmovaps [rsp+0xA0], xmm11
00007accb5bd87d3  vmovaps [rsp+0xB0], xmm12
00007accb5bd87dc  vmovaps [rsp+0xC0], xmm13
00007accb5bd87e5  vmovaps [rsp+0xD0], xmm14
00007accb5bd87ee  vmovaps [rsp+0xE0], xmm15
00007accb5bd87f7  sub rsp, 0x40
00007accb5bd87fb  lea rdi, [rsp]
00007accb5bd87ff  lea rsi, [rsp+0x10]
00007accb5bd8804  lea rdx, [rsp+0x20]
00007accb5bd8809  lea rcx, [rsp+0x30]
00007accb5bd880e  mov r8d, 0x00
00007accb5bd8814  lea r9, [r15+0x3A8]
00007accb5bd881b  movaps [rdi], xmm10
00007accb5bd881f  movaps [rsi], xmm2
00007accb5bd8822  movaps [rdx], xmm6
00007accb5bd8825  movaps [rcx], xmm14
00007accb5bd8829  mov rax, 0x59156B40DA50
00007accb5bd8833  call rax
00007accb5bd8835  movaps xmm10, [rsp]
00007accb5bd883a  add rsp, 0x40
00007accb5bd883e  vmovaps xmm0, [rsp]
00007accb5bd8843  vmovaps xmm1, [rsp+0x10]
00007accb5bd8849  vmovaps xmm2, [rsp+0x20]
00007accb5bd884f  vmovaps xmm3, [rsp+0x30]
00007accb5bd8855  vmovaps xmm4, [rsp+0x40]
00007accb5bd885b  vmovaps xmm5, [rsp+0x50]
00007accb5bd8861  vmovaps xmm6, [rsp+0x60]
00007accb5bd8867  vmovaps xmm7, [rsp+0x70]
00007accb5bd886d  vmovaps xmm8, [rsp+0x80]
00007accb5bd8876  vmovaps xmm9, [rsp+0x90]
00007accb5bd887f  vmovaps xmm11, [rsp+0xA0]
00007accb5bd8888  vmovaps xmm12, [rsp+0xB0]
00007accb5bd8891  vmovaps xmm13, [rsp+0xC0]
00007accb5bd889a  vmovaps xmm14, [rsp+0xD0]
00007accb5bd88a3  vmovaps xmm15, [rsp+0xE0]
00007accb5bd88ac  add rsp, 0xF0
00007accb5bd88b3  pop r11
00007accb5bd88b5  pop r10
00007accb5bd88b7  pop r9
00007accb5bd88b9  pop r8
00007accb5bd88bb  pop rsi
00007accb5bd88bc  pop rdi
00007accb5bd88bd  pop rdx
00007accb5bd88be  pop rcx
00007accb5bd88bf  pop rax
00007accb5bd88c0  add rsp, 0x08
00007accb5bd88c4  jmp 0x00007ACCB5BD7131
00007accb5bd88c9  call 0x00007ACCB5A0D4E0
00007accb5bd88ce  jmp 0x00007ACCB5BD713E
00007accb5bd88d3  sub rsp, 0x08
00007accb5bd88d7  push rax
00007accb5bd88d8  push rcx
00007accb5bd88d9  push rdx
00007accb5bd88da  push rdi
00007accb5bd88db  push rsi
00007accb5bd88dc  push r8
00007accb5bd88de  push r9
00007accb5bd88e0  push r10
00007accb5bd88e2  push r11
00007accb5bd88e4  sub rsp, 0xF0
00007accb5bd88eb  vmovaps [rsp], xmm0
00007accb5bd88f0  vmovaps [rsp+0x10], xmm1
00007accb5bd88f6  vmovaps [rsp+0x20], xmm2
00007accb5bd88fc  vmovaps [rsp+0x30], xmm3
00007accb5bd8902  vmovaps [rsp+0x40], xmm4
00007accb5bd8908  vmovaps [rsp+0x50], xmm6
00007accb5bd890e  vmovaps [rsp+0x60], xmm7
00007accb5bd8914  vmovaps [rsp+0x70], xmm8
00007accb5bd891a  vmovaps [rsp+0x80], xmm9
00007accb5bd8923  vmovaps [rsp+0x90], xmm10
00007accb5bd892c  vmovaps [rsp+0xA0], xmm11
00007accb5bd8935  vmovaps [rsp+0xB0], xmm12
00007accb5bd893e  vmovaps [rsp+0xC0], xmm13
00007accb5bd8947  vmovaps [rsp+0xD0], xmm14
00007accb5bd8950  vmovaps [rsp+0xE0], xmm15
00007accb5bd8959  sub rsp, 0x40
00007accb5bd895d  lea rdi, [rsp]
00007accb5bd8961  lea rsi, [rsp+0x10]
00007accb5bd8966  lea rdx, [rsp+0x20]
00007accb5bd896b  lea rcx, [rsp+0x30]
00007accb5bd8970  mov r8d, 0x00
00007accb5bd8976  lea r9, [r15+0x3A8]
00007accb5bd897d  movaps [rdi], xmm5
00007accb5bd8980  movaps [rsi], xmm15
00007accb5bd8984  movaps [rdx], xmm6
00007accb5bd8987  movaps [rcx], xmm8
00007accb5bd898b  mov rax, 0x59156B40DA50
00007accb5bd8995  call rax
00007accb5bd8997  movaps xmm5, [rsp]
00007accb5bd899b  add rsp, 0x40
00007accb5bd899f  vmovaps xmm0, [rsp]
00007accb5bd89a4  vmovaps xmm1, [rsp+0x10]
00007accb5bd89aa  vmovaps xmm2, [rsp+0x20]
00007accb5bd89b0  vmovaps xmm3, [rsp+0x30]
00007accb5bd89b6  vmovaps xmm4, [rsp+0x40]
00007accb5bd89bc  vmovaps xmm6, [rsp+0x50]
00007accb5bd89c2  vmovaps xmm7, [rsp+0x60]
00007accb5bd89c8  vmovaps xmm8, [rsp+0x70]
00007accb5bd89ce  vmovaps xmm9, [rsp+0x80]
00007accb5bd89d7  vmovaps xmm10, [rsp+0x90]
00007accb5bd89e0  vmovaps xmm11, [rsp+0xA0]
00007accb5bd89e9  vmovaps xmm12, [rsp+0xB0]
00007accb5bd89f2  vmovaps xmm13, [rsp+0xC0]
00007accb5bd89fb  vmovaps xmm14, [rsp+0xD0]
00007accb5bd8a04  vmovaps xmm15, [rsp+0xE0]
00007accb5bd8a0d  add rsp, 0xF0
00007accb5bd8a14  pop r11
00007accb5bd8a16  pop r10
00007accb5bd8a18  pop r9
00007accb5bd8a1a  pop r8
00007accb5bd8a1c  pop rsi
00007accb5bd8a1d  pop rdi
00007accb5bd8a1e  pop rdx
00007accb5bd8a1f  pop rcx
00007accb5bd8a20  pop rax
00007accb5bd8a21  add rsp, 0x08
00007accb5bd8a25  jmp 0x00007ACCB5BD7174
00007accb5bd8a2a  sub rsp, 0x08
00007accb5bd8a2e  push rax
00007accb5bd8a2f  push rcx
00007accb5bd8a30  push rdx
00007accb5bd8a31  push rdi
00007accb5bd8a32  push rsi
00007accb5bd8a33  push r8
00007accb5bd8a35  push r9
00007accb5bd8a37  push r10
00007accb5bd8a39  push r11
00007accb5bd8a3b  sub rsp, 0xF0
00007accb5bd8a42  vmovaps [rsp], xmm0
00007accb5bd8a47  vmovaps [rsp+0x10], xmm1
00007accb5bd8a4d  vmovaps [rsp+0x20], xmm2
00007accb5bd8a53  vmovaps [rsp+0x30], xmm3
00007accb5bd8a59  vmovaps [rsp+0x40], xmm4
00007accb5bd8a5f  vmovaps [rsp+0x50], xmm5
00007accb5bd8a65  vmovaps [rsp+0x60], xmm6
00007accb5bd8a6b  vmovaps [rsp+0x70], xmm7
00007accb5bd8a71  vmovaps [rsp+0x80], xmm9
00007accb5bd8a7a  vmovaps [rsp+0x90], xmm10
00007accb5bd8a83  vmovaps [rsp+0xA0], xmm11
00007accb5bd8a8c  vmovaps [rsp+0xB0], xmm12
00007accb5bd8a95  vmovaps [rsp+0xC0], xmm13
00007accb5bd8a9e  vmovaps [rsp+0xD0], xmm14
00007accb5bd8aa7  vmovaps [rsp+0xE0], xmm15
00007accb5bd8ab0  sub rsp, 0x40
00007accb5bd8ab4  lea rdi, [rsp]
00007accb5bd8ab8  lea rsi, [rsp+0x10]
00007accb5bd8abd  lea rdx, [rsp+0x20]
00007accb5bd8ac2  lea rcx, [rsp+0x30]
00007accb5bd8ac7  mov r8d, 0x00
00007accb5bd8acd  lea r9, [r15+0x3A8]
00007accb5bd8ad4  movaps [rdi], xmm8
00007accb5bd8ad8  movaps [rsi], xmm13
00007accb5bd8adc  movaps [rdx], xmm1
00007accb5bd8adf  movaps [rcx], xmm15
00007accb5bd8ae3  mov rax, 0x59156B40DA50
00007accb5bd8aed  call rax
00007accb5bd8aef  movaps xmm8, [rsp]
00007accb5bd8af4  add rsp, 0x40
00007accb5bd8af8  vmovaps xmm0, [rsp]
00007accb5bd8afd  vmovaps xmm1, [rsp+0x10]
00007accb5bd8b03  vmovaps xmm2, [rsp+0x20]
00007accb5bd8b09  vmovaps xmm3, [rsp+0x30]
00007accb5bd8b0f  vmovaps xmm4, [rsp+0x40]
00007accb5bd8b15  vmovaps xmm5, [rsp+0x50]
00007accb5bd8b1b  vmovaps xmm6, [rsp+0x60]
00007accb5bd8b21  vmovaps xmm7, [rsp+0x70]
00007accb5bd8b27  vmovaps xmm9, [rsp+0x80]
00007accb5bd8b30  vmovaps xmm10, [rsp+0x90]
00007accb5bd8b39  vmovaps xmm11, [rsp+0xA0]
00007accb5bd8b42  vmovaps xmm12, [rsp+0xB0]
00007accb5bd8b4b  vmovaps xmm13, [rsp+0xC0]
00007accb5bd8b54  vmovaps xmm14, [rsp+0xD0]
00007accb5bd8b5d  vmovaps xmm15, [rsp+0xE0]
00007accb5bd8b66  add rsp, 0xF0
00007accb5bd8b6d  pop r11
00007accb5bd8b6f  pop r10
00007accb5bd8b71  pop r9
00007accb5bd8b73  pop r8
00007accb5bd8b75  pop rsi
00007accb5bd8b76  pop rdi
00007accb5bd8b77  pop rdx
00007accb5bd8b78  pop rcx
00007accb5bd8b79  pop rax
00007accb5bd8b7a  add rsp, 0x08
00007accb5bd8b7e  jmp 0x00007ACCB5BD719A
00007accb5bd8b83  call 0x00007ACCB5A0E760
00007accb5bd8b88  jmp 0x00007ACCB5BD71BD
00007accb5bd8b8d  call 0x00007ACCB5A0C260
00007accb5bd8b92  jmp 0x00007ACCB5BD71C7
00007accb5bd8b97  sub rsp, 0x08
00007accb5bd8b9b  push rax
00007accb5bd8b9c  push rcx
00007accb5bd8b9d  push rdx
00007accb5bd8b9e  push rdi
00007accb5bd8b9f  push rsi
00007accb5bd8ba0  push r8
00007accb5bd8ba2  push r9
00007accb5bd8ba4  push r10
00007accb5bd8ba6  push r11
00007accb5bd8ba8  sub rsp, 0xF0
00007accb5bd8baf  vmovaps [rsp], xmm0
00007accb5bd8bb4  vmovaps [rsp+0x10], xmm1
00007accb5bd8bba  vmovaps [rsp+0x20], xmm2
00007accb5bd8bc0  vmovaps [rsp+0x30], xmm3
00007accb5bd8bc6  vmovaps [rsp+0x40], xmm5
00007accb5bd8bcc  vmovaps [rsp+0x50], xmm6
00007accb5bd8bd2  vmovaps [rsp+0x60], xmm7
00007accb5bd8bd8  vmovaps [rsp+0x70], xmm8
00007accb5bd8bde  vmovaps [rsp+0x80], xmm9
00007accb5bd8be7  vmovaps [rsp+0x90], xmm10
00007accb5bd8bf0  vmovaps [rsp+0xA0], xmm11
00007accb5bd8bf9  vmovaps [rsp+0xB0], xmm12
00007accb5bd8c02  vmovaps [rsp+0xC0], xmm13
00007accb5bd8c0b  vmovaps [rsp+0xD0], xmm14
00007accb5bd8c14  vmovaps [rsp+0xE0], xmm15
00007accb5bd8c1d  sub rsp, 0x40
00007accb5bd8c21  lea rdi, [rsp]
00007accb5bd8c25  lea rsi, [rsp+0x10]
00007accb5bd8c2a  lea rdx, [rsp+0x20]
00007accb5bd8c2f  lea rcx, [rsp+0x30]
00007accb5bd8c34  mov r8d, 0x00
00007accb5bd8c3a  lea r9, [r15+0x3A8]
00007accb5bd8c41  movaps [rdi], xmm4
00007accb5bd8c44  movaps [rsi], xmm12
00007accb5bd8c48  movaps [rdx], xmm9
00007accb5bd8c4c  movaps [rcx], xmm6
00007accb5bd8c4f  mov rax, 0x59156B40DA50
00007accb5bd8c59  call rax
00007accb5bd8c5b  movaps xmm4, [rsp]
00007accb5bd8c5f  add rsp, 0x40
00007accb5bd8c63  vmovaps xmm0, [rsp]
00007accb5bd8c68  vmovaps xmm1, [rsp+0x10]
00007accb5bd8c6e  vmovaps xmm2, [rsp+0x20]
00007accb5bd8c74  vmovaps xmm3, [rsp+0x30]
00007accb5bd8c7a  vmovaps xmm5, [rsp+0x40]
00007accb5bd8c80  vmovaps xmm6, [rsp+0x50]
00007accb5bd8c86  vmovaps xmm7, [rsp+0x60]
00007accb5bd8c8c  vmovaps xmm8, [rsp+0x70]
00007accb5bd8c92  vmovaps xmm9, [rsp+0x80]
00007accb5bd8c9b  vmovaps xmm10, [rsp+0x90]
00007accb5bd8ca4  vmovaps xmm11, [rsp+0xA0]
00007accb5bd8cad  vmovaps xmm12, [rsp+0xB0]
00007accb5bd8cb6  vmovaps xmm13, [rsp+0xC0]
00007accb5bd8cbf  vmovaps xmm14, [rsp+0xD0]
00007accb5bd8cc8  vmovaps xmm15, [rsp+0xE0]
00007accb5bd8cd1  add rsp, 0xF0
00007accb5bd8cd8  pop r11
00007accb5bd8cda  pop r10
00007accb5bd8cdc  pop r9
00007accb5bd8cde  pop r8
00007accb5bd8ce0  pop rsi
00007accb5bd8ce1  pop rdi
00007accb5bd8ce2  pop rdx
00007accb5bd8ce3  pop rcx
00007accb5bd8ce4  pop rax
00007accb5bd8ce5  add rsp, 0x08
00007accb5bd8ce9  jmp 0x00007ACCB5BD71FF
00007accb5bd8cee  sub rsp, 0x08
00007accb5bd8cf2  push rax
00007accb5bd8cf3  push rcx
00007accb5bd8cf4  push rdx
00007accb5bd8cf5  push rdi
00007accb5bd8cf6  push rsi
00007accb5bd8cf7  push r8
00007accb5bd8cf9  push r9
00007accb5bd8cfb  push r10
00007accb5bd8cfd  push r11
00007accb5bd8cff  sub rsp, 0xF0
00007accb5bd8d06  vmovaps [rsp], xmm0
00007accb5bd8d0b  vmovaps [rsp+0x10], xmm1
00007accb5bd8d11  vmovaps [rsp+0x20], xmm2
00007accb5bd8d17  vmovaps [rsp+0x30], xmm3
00007accb5bd8d1d  vmovaps [rsp+0x40], xmm4
00007accb5bd8d23  vmovaps [rsp+0x50], xmm5
00007accb5bd8d29  vmovaps [rsp+0x60], xmm6
00007accb5bd8d2f  vmovaps [rsp+0x70], xmm7
00007accb5bd8d35  vmovaps [rsp+0x80], xmm8
00007accb5bd8d3e  vmovaps [rsp+0x90], xmm10
00007accb5bd8d47  vmovaps [rsp+0xA0], xmm11
00007accb5bd8d50  vmovaps [rsp+0xB0], xmm12
00007accb5bd8d59  vmovaps [rsp+0xC0], xmm13
00007accb5bd8d62  vmovaps [rsp+0xD0], xmm14
00007accb5bd8d6b  vmovaps [rsp+0xE0], xmm15
00007accb5bd8d74  sub rsp, 0x40
00007accb5bd8d78  lea rdi, [rsp]
00007accb5bd8d7c  lea rsi, [rsp+0x10]
00007accb5bd8d81  lea rdx, [rsp+0x20]
00007accb5bd8d86  lea rcx, [rsp+0x30]
00007accb5bd8d8b  mov r8d, 0x00
00007accb5bd8d91  lea r9, [r15+0x3A8]
00007accb5bd8d98  movaps [rdi], xmm9
00007accb5bd8d9c  movaps [rsi], xmm10
00007accb5bd8da0  movaps [rdx], xmm1
00007accb5bd8da3  movaps [rcx], xmm12
00007accb5bd8da7  mov rax, 0x59156B40DA50
00007accb5bd8db1  call rax
00007accb5bd8db3  movaps xmm9, [rsp]
00007accb5bd8db8  add rsp, 0x40
00007accb5bd8dbc  vmovaps xmm0, [rsp]
00007accb5bd8dc1  vmovaps xmm1, [rsp+0x10]
00007accb5bd8dc7  vmovaps xmm2, [rsp+0x20]
00007accb5bd8dcd  vmovaps xmm3, [rsp+0x30]
00007accb5bd8dd3  vmovaps xmm4, [rsp+0x40]
00007accb5bd8dd9  vmovaps xmm5, [rsp+0x50]
00007accb5bd8ddf  vmovaps xmm6, [rsp+0x60]
00007accb5bd8de5  vmovaps xmm7, [rsp+0x70]
00007accb5bd8deb  vmovaps xmm8, [rsp+0x80]
00007accb5bd8df4  vmovaps xmm10, [rsp+0x90]
00007accb5bd8dfd  vmovaps xmm11, [rsp+0xA0]
00007accb5bd8e06  vmovaps xmm12, [rsp+0xB0]
00007accb5bd8e0f  vmovaps xmm13, [rsp+0xC0]
00007accb5bd8e18  vmovaps xmm14, [rsp+0xD0]
00007accb5bd8e21  vmovaps xmm15, [rsp+0xE0]
00007accb5bd8e2a  add rsp, 0xF0
00007accb5bd8e31  pop r11
00007accb5bd8e33  pop r10
00007accb5bd8e35  pop r9
00007accb5bd8e37  pop r8
00007accb5bd8e39  pop rsi
00007accb5bd8e3a  pop rdi
00007accb5bd8e3b  pop rdx
00007accb5bd8e3c  pop rcx
00007accb5bd8e3d  pop rax
00007accb5bd8e3e  add rsp, 0x08
00007accb5bd8e42  jmp 0x00007ACCB5BD7228
00007accb5bd8e47  sub rsp, 0x08
00007accb5bd8e4b  push rax
00007accb5bd8e4c  push rcx
00007accb5bd8e4d  push rdx
00007accb5bd8e4e  push rdi
00007accb5bd8e4f  push rsi
00007accb5bd8e50  push r8
00007accb5bd8e52  push r9
00007accb5bd8e54  push r10
00007accb5bd8e56  push r11
00007accb5bd8e58  sub rsp, 0xF0
00007accb5bd8e5f  vmovaps [rsp], xmm0
00007accb5bd8e64  vmovaps [rsp+0x10], xmm1
00007accb5bd8e6a  vmovaps [rsp+0x20], xmm2
00007accb5bd8e70  vmovaps [rsp+0x30], xmm3
00007accb5bd8e76  vmovaps [rsp+0x40], xmm4
00007accb5bd8e7c  vmovaps [rsp+0x50], xmm5
00007accb5bd8e82  vmovaps [rsp+0x60], xmm6
00007accb5bd8e88  vmovaps [rsp+0x70], xmm7
00007accb5bd8e8e  vmovaps [rsp+0x80], xmm8
00007accb5bd8e97  vmovaps [rsp+0x90], xmm9
00007accb5bd8ea0  vmovaps [rsp+0xA0], xmm11
00007accb5bd8ea9  vmovaps [rsp+0xB0], xmm12
00007accb5bd8eb2  vmovaps [rsp+0xC0], xmm13
00007accb5bd8ebb  vmovaps [rsp+0xD0], xmm14
00007accb5bd8ec4  vmovaps [rsp+0xE0], xmm15
00007accb5bd8ecd  sub rsp, 0x40
00007accb5bd8ed1  lea rdi, [rsp]
00007accb5bd8ed5  lea rsi, [rsp+0x10]
00007accb5bd8eda  lea rdx, [rsp+0x20]
00007accb5bd8edf  lea rcx, [rsp+0x30]
00007accb5bd8ee4  mov r8d, 0x00
00007accb5bd8eea  lea r9, [r15+0x3A8]
00007accb5bd8ef1  movaps [rdi], xmm10
00007accb5bd8ef5  movaps [rsi], xmm5
00007accb5bd8ef8  movaps [rdx], xmm12
00007accb5bd8efc  movaps [rcx], xmm1
00007accb5bd8eff  mov rax, 0x59156B40DA50
00007accb5bd8f09  call rax
00007accb5bd8f0b  movaps xmm10, [rsp]
00007accb5bd8f10  add rsp, 0x40
00007accb5bd8f14  vmovaps xmm0, [rsp]
00007accb5bd8f19  vmovaps xmm1, [rsp+0x10]
00007accb5bd8f1f  vmovaps xmm2, [rsp+0x20]
00007accb5bd8f25  vmovaps xmm3, [rsp+0x30]
00007accb5bd8f2b  vmovaps xmm4, [rsp+0x40]
00007accb5bd8f31  vmovaps xmm5, [rsp+0x50]
00007accb5bd8f37  vmovaps xmm6, [rsp+0x60]
00007accb5bd8f3d  vmovaps xmm7, [rsp+0x70]
00007accb5bd8f43  vmovaps xmm8, [rsp+0x80]
00007accb5bd8f4c  vmovaps xmm9, [rsp+0x90]
00007accb5bd8f55  vmovaps xmm11, [rsp+0xA0]
00007accb5bd8f5e  vmovaps xmm12, [rsp+0xB0]
00007accb5bd8f67  vmovaps xmm13, [rsp+0xC0]
00007accb5bd8f70  vmovaps xmm14, [rsp+0xD0]
00007accb5bd8f79  vmovaps xmm15, [rsp+0xE0]
00007accb5bd8f82  add rsp, 0xF0
00007accb5bd8f89  pop r11
00007accb5bd8f8b  pop r10
00007accb5bd8f8d  pop r9
00007accb5bd8f8f  pop r8
00007accb5bd8f91  pop rsi
00007accb5bd8f92  pop rdi
00007accb5bd8f93  pop rdx
00007accb5bd8f94  pop rcx
00007accb5bd8f95  pop rax
00007accb5bd8f96  add rsp, 0x08
00007accb5bd8f9a  jmp 0x00007ACCB5BD7257
00007accb5bd8f9f  sub rsp, 0x08
00007accb5bd8fa3  push rax
00007accb5bd8fa4  push rcx
00007accb5bd8fa5  push rdx
00007accb5bd8fa6  push rdi
00007accb5bd8fa7  push rsi
00007accb5bd8fa8  push r8
00007accb5bd8faa  push r9
00007accb5bd8fac  push r10
00007accb5bd8fae  push r11
00007accb5bd8fb0  sub rsp, 0xF0
00007accb5bd8fb7  vmovaps [rsp], xmm0
00007accb5bd8fbc  vmovaps [rsp+0x10], xmm1
00007accb5bd8fc2  vmovaps [rsp+0x20], xmm2
00007accb5bd8fc8  vmovaps [rsp+0x30], xmm3
00007accb5bd8fce  vmovaps [rsp+0x40], xmm4
00007accb5bd8fd4  vmovaps [rsp+0x50], xmm5
00007accb5bd8fda  vmovaps [rsp+0x60], xmm7
00007accb5bd8fe0  vmovaps [rsp+0x70], xmm8
00007accb5bd8fe6  vmovaps [rsp+0x80], xmm9
00007accb5bd8fef  vmovaps [rsp+0x90], xmm10
00007accb5bd8ff8  vmovaps [rsp+0xA0], xmm11
00007accb5bd9001  vmovaps [rsp+0xB0], xmm12
00007accb5bd900a  vmovaps [rsp+0xC0], xmm13
00007accb5bd9013  vmovaps [rsp+0xD0], xmm14
00007accb5bd901c  vmovaps [rsp+0xE0], xmm15
00007accb5bd9025  sub rsp, 0x40
00007accb5bd9029  lea rdi, [rsp]
00007accb5bd902d  lea rsi, [rsp+0x10]
00007accb5bd9032  lea rdx, [rsp+0x20]
00007accb5bd9037  lea rcx, [rsp+0x30]
00007accb5bd903c  mov r8d, 0x00
00007accb5bd9042  lea r9, [r15+0x3A8]
00007accb5bd9049  movaps [rdi], xmm6
00007accb5bd904c  movaps [rsi], xmm8
00007accb5bd9050  movaps [rdx], xmm12
00007accb5bd9054  movaps [rcx], xmm1
00007accb5bd9057  mov rax, 0x59156B40DA50
00007accb5bd9061  call rax
00007accb5bd9063  movaps xmm6, [rsp]
00007accb5bd9067  add rsp, 0x40
00007accb5bd906b  vmovaps xmm0, [rsp]
00007accb5bd9070  vmovaps xmm1, [rsp+0x10]
00007accb5bd9076  vmovaps xmm2, [rsp+0x20]
00007accb5bd907c  vmovaps xmm3, [rsp+0x30]
00007accb5bd9082  vmovaps xmm4, [rsp+0x40]
00007accb5bd9088  vmovaps xmm5, [rsp+0x50]
00007accb5bd908e  vmovaps xmm7, [rsp+0x60]
00007accb5bd9094  vmovaps xmm8, [rsp+0x70]
00007accb5bd909a  vmovaps xmm9, [rsp+0x80]
00007accb5bd90a3  vmovaps xmm10, [rsp+0x90]
00007accb5bd90ac  vmovaps xmm11, [rsp+0xA0]
00007accb5bd90b5  vmovaps xmm12, [rsp+0xB0]
00007accb5bd90be  vmovaps xmm13, [rsp+0xC0]
00007accb5bd90c7  vmovaps xmm14, [rsp+0xD0]
00007accb5bd90d0  vmovaps xmm15, [rsp+0xE0]
00007accb5bd90d9  add rsp, 0xF0
00007accb5bd90e0  pop r11
00007accb5bd90e2  pop r10
00007accb5bd90e4  pop r9
00007accb5bd90e6  pop r8
00007accb5bd90e8  pop rsi
00007accb5bd90e9  pop rdi
00007accb5bd90ea  pop rdx
00007accb5bd90eb  pop rcx
00007accb5bd90ec  pop rax
00007accb5bd90ed  add rsp, 0x08
00007accb5bd90f1  jmp 0x00007ACCB5BD7285
00007accb5bd90f6  call 0x00007ACCB59FF430
00007accb5bd90fb  jmp 0x00007ACCB5BD728F
00007accb5bd9100  call 0x00007ACCB5A0AFE0
00007accb5bd9105  jmp 0x00007ACCB5BD7299
00007accb5bd910a  sub rsp, 0x08
00007accb5bd910e  push rax
00007accb5bd910f  push rcx
00007accb5bd9110  push rdx
00007accb5bd9111  push rdi
00007accb5bd9112  push rsi
00007accb5bd9113  push r8
00007accb5bd9115  push r9
00007accb5bd9117  push r10
00007accb5bd9119  push r11
00007accb5bd911b  sub rsp, 0xF0
00007accb5bd9122  vmovaps [rsp], xmm0
00007accb5bd9127  vmovaps [rsp+0x10], xmm1
00007accb5bd912d  vmovaps [rsp+0x20], xmm2
00007accb5bd9133  vmovaps [rsp+0x30], xmm3
00007accb5bd9139  vmovaps [rsp+0x40], xmm4
00007accb5bd913f  vmovaps [rsp+0x50], xmm5
00007accb5bd9145  vmovaps [rsp+0x60], xmm6
00007accb5bd914b  vmovaps [rsp+0x70], xmm7
00007accb5bd9151  vmovaps [rsp+0x80], xmm9
00007accb5bd915a  vmovaps [rsp+0x90], xmm10
00007accb5bd9163  vmovaps [rsp+0xA0], xmm11
00007accb5bd916c  vmovaps [rsp+0xB0], xmm12
00007accb5bd9175  vmovaps [rsp+0xC0], xmm13
00007accb5bd917e  vmovaps [rsp+0xD0], xmm14
00007accb5bd9187  vmovaps [rsp+0xE0], xmm15
00007accb5bd9190  sub rsp, 0x40
00007accb5bd9194  lea rdi, [rsp]
00007accb5bd9198  lea rsi, [rsp+0x10]
00007accb5bd919d  lea rdx, [rsp+0x20]
00007accb5bd91a2  lea rcx, [rsp+0x30]
00007accb5bd91a7  mov r8d, 0x00
00007accb5bd91ad  lea r9, [r15+0x3A8]
00007accb5bd91b4  movaps [rdi], xmm8
00007accb5bd91b8  movaps [rsi], xmm4
00007accb5bd91bb  movaps [rdx], xmm13
00007accb5bd91bf  movaps [rcx], xmm11
00007accb5bd91c3  mov rax, 0x59156B40DA50
00007accb5bd91cd  call rax
00007accb5bd91cf  movaps xmm8, [rsp]
00007accb5bd91d4  add rsp, 0x40
00007accb5bd91d8  vmovaps xmm0, [rsp]
00007accb5bd91dd  vmovaps xmm1, [rsp+0x10]
00007accb5bd91e3  vmovaps xmm2, [rsp+0x20]
00007accb5bd91e9  vmovaps xmm3, [rsp+0x30]
00007accb5bd91ef  vmovaps xmm4, [rsp+0x40]
00007accb5bd91f5  vmovaps xmm5, [rsp+0x50]
00007accb5bd91fb  vmovaps xmm6, [rsp+0x60]
00007accb5bd9201  vmovaps xmm7, [rsp+0x70]
00007accb5bd9207  vmovaps xmm9, [rsp+0x80]
00007accb5bd9210  vmovaps xmm10, [rsp+0x90]
00007accb5bd9219  vmovaps xmm11, [rsp+0xA0]
00007accb5bd9222  vmovaps xmm12, [rsp+0xB0]
00007accb5bd922b  vmovaps xmm13, [rsp+0xC0]
00007accb5bd9234  vmovaps xmm14, [rsp+0xD0]
00007accb5bd923d  vmovaps xmm15, [rsp+0xE0]
00007accb5bd9246  add rsp, 0xF0
00007accb5bd924d  pop r11
00007accb5bd924f  pop r10
00007accb5bd9251  pop r9
00007accb5bd9253  pop r8
00007accb5bd9255  pop rsi
00007accb5bd9256  pop rdi
00007accb5bd9257  pop rdx
00007accb5bd9258  pop rcx
00007accb5bd9259  pop rax
00007accb5bd925a  add rsp, 0x08
00007accb5bd925e  jmp 0x00007ACCB5BD72CF
00007accb5bd9263  sub rsp, 0x08
00007accb5bd9267  push rax
00007accb5bd9268  push rcx
00007accb5bd9269  push rdx
00007accb5bd926a  push rdi
00007accb5bd926b  push rsi
00007accb5bd926c  push r8
00007accb5bd926e  push r9
00007accb5bd9270  push r10
00007accb5bd9272  push r11
00007accb5bd9274  sub rsp, 0xF0
00007accb5bd927b  vmovaps [rsp], xmm0
00007accb5bd9280  vmovaps [rsp+0x10], xmm1
00007accb5bd9286  vmovaps [rsp+0x20], xmm2
00007accb5bd928c  vmovaps [rsp+0x30], xmm3
00007accb5bd9292  vmovaps [rsp+0x40], xmm4
00007accb5bd9298  vmovaps [rsp+0x50], xmm5
00007accb5bd929e  vmovaps [rsp+0x60], xmm6
00007accb5bd92a4  vmovaps [rsp+0x70], xmm7
00007accb5bd92aa  vmovaps [rsp+0x80], xmm8
00007accb5bd92b3  vmovaps [rsp+0x90], xmm9
00007accb5bd92bc  vmovaps [rsp+0xA0], xmm10
00007accb5bd92c5  vmovaps [rsp+0xB0], xmm12
00007accb5bd92ce  vmovaps [rsp+0xC0], xmm13
00007accb5bd92d7  vmovaps [rsp+0xD0], xmm14
00007accb5bd92e0  vmovaps [rsp+0xE0], xmm15
00007accb5bd92e9  sub rsp, 0x40
00007accb5bd92ed  lea rdi, [rsp]
00007accb5bd92f1  lea rsi, [rsp+0x10]
00007accb5bd92f6  lea rdx, [rsp+0x20]
00007accb5bd92fb  lea rcx, [rsp+0x30]
00007accb5bd9300  mov r8d, 0x00
00007accb5bd9306  lea r9, [r15+0x3A8]
00007accb5bd930d  movaps [rdi], xmm11
00007accb5bd9311  movaps [rsi], xmm9
00007accb5bd9315  movaps [rdx], xmm1
00007accb5bd9318  movaps [rcx], xmm13
00007accb5bd931c  mov rax, 0x59156B40DA50
00007accb5bd9326  call rax
00007accb5bd9328  movaps xmm11, [rsp]
00007accb5bd932d  add rsp, 0x40
00007accb5bd9331  vmovaps xmm0, [rsp]
00007accb5bd9336  vmovaps xmm1, [rsp+0x10]
00007accb5bd933c  vmovaps xmm2, [rsp+0x20]
00007accb5bd9342  vmovaps xmm3, [rsp+0x30]
00007accb5bd9348  vmovaps xmm4, [rsp+0x40]
00007accb5bd934e  vmovaps xmm5, [rsp+0x50]
00007accb5bd9354  vmovaps xmm6, [rsp+0x60]
00007accb5bd935a  vmovaps xmm7, [rsp+0x70]
00007accb5bd9360  vmovaps xmm8, [rsp+0x80]
00007accb5bd9369  vmovaps xmm9, [rsp+0x90]
00007accb5bd9372  vmovaps xmm10, [rsp+0xA0]
00007accb5bd937b  vmovaps xmm12, [rsp+0xB0]
00007accb5bd9384  vmovaps xmm13, [rsp+0xC0]
00007accb5bd938d  vmovaps xmm14, [rsp+0xD0]
00007accb5bd9396  vmovaps xmm15, [rsp+0xE0]
00007accb5bd939f  add rsp, 0xF0
00007accb5bd93a6  pop r11
00007accb5bd93a8  pop r10
00007accb5bd93aa  pop r9
00007accb5bd93ac  pop r8
00007accb5bd93ae  pop rsi
00007accb5bd93af  pop rdi
00007accb5bd93b0  pop rdx
00007accb5bd93b1  pop rcx
00007accb5bd93b2  pop rax
00007accb5bd93b3  add rsp, 0x08
00007accb5bd93b7  jmp 0x00007ACCB5BD72F5
00007accb5bd93bc  sub rsp, 0x08
00007accb5bd93c0  push rax
00007accb5bd93c1  push rcx
00007accb5bd93c2  push rdx
00007accb5bd93c3  push rdi
00007accb5bd93c4  push rsi
00007accb5bd93c5  push r8
00007accb5bd93c7  push r9
00007accb5bd93c9  push r10
00007accb5bd93cb  push r11
00007accb5bd93cd  sub rsp, 0xF0
00007accb5bd93d4  vmovaps [rsp], xmm0
00007accb5bd93d9  vmovaps [rsp+0x10], xmm1
00007accb5bd93df  vmovaps [rsp+0x20], xmm2
00007accb5bd93e5  vmovaps [rsp+0x30], xmm3
00007accb5bd93eb  vmovaps [rsp+0x40], xmm4
00007accb5bd93f1  vmovaps [rsp+0x50], xmm5
00007accb5bd93f7  vmovaps [rsp+0x60], xmm6
00007accb5bd93fd  vmovaps [rsp+0x70], xmm7
00007accb5bd9403  vmovaps [rsp+0x80], xmm8
00007accb5bd940c  vmovaps [rsp+0x90], xmm9
00007accb5bd9415  vmovaps [rsp+0xA0], xmm10
00007accb5bd941e  vmovaps [rsp+0xB0], xmm11
00007accb5bd9427  vmovaps [rsp+0xC0], xmm12
00007accb5bd9430  vmovaps [rsp+0xD0], xmm14
00007accb5bd9439  vmovaps [rsp+0xE0], xmm15
00007accb5bd9442  sub rsp, 0x40
00007accb5bd9446  lea rdi, [rsp]
00007accb5bd944a  lea rsi, [rsp+0x10]
00007accb5bd944f  lea rdx, [rsp+0x20]
00007accb5bd9454  lea rcx, [rsp+0x30]
00007accb5bd9459  mov r8d, 0x00
00007accb5bd945f  lea r9, [r15+0x3A8]
00007accb5bd9466  movaps [rdi], xmm13
00007accb5bd946a  movaps [rsi], xmm10
00007accb5bd946e  movaps [rdx], xmm7
00007accb5bd9471  movaps [rcx], xmm1
00007accb5bd9474  mov rax, 0x59156B40DA50
00007accb5bd947e  call rax
00007accb5bd9480  movaps xmm13, [rsp]
00007accb5bd9485  add rsp, 0x40
00007accb5bd9489  vmovaps xmm0, [rsp]
00007accb5bd948e  vmovaps xmm1, [rsp+0x10]
00007accb5bd9494  vmovaps xmm2, [rsp+0x20]
00007accb5bd949a  vmovaps xmm3, [rsp+0x30]
00007accb5bd94a0  vmovaps xmm4, [rsp+0x40]
00007accb5bd94a6  vmovaps xmm5, [rsp+0x50]
00007accb5bd94ac  vmovaps xmm6, [rsp+0x60]
00007accb5bd94b2  vmovaps xmm7, [rsp+0x70]
00007accb5bd94b8  vmovaps xmm8, [rsp+0x80]
00007accb5bd94c1  vmovaps xmm9, [rsp+0x90]
00007accb5bd94ca  vmovaps xmm10, [rsp+0xA0]
00007accb5bd94d3  vmovaps xmm11, [rsp+0xB0]
00007accb5bd94dc  vmovaps xmm12, [rsp+0xC0]
00007accb5bd94e5  vmovaps xmm14, [rsp+0xD0]
00007accb5bd94ee  vmovaps xmm15, [rsp+0xE0]
00007accb5bd94f7  add rsp, 0xF0
00007accb5bd94fe  pop r11
00007accb5bd9500  pop r10
00007accb5bd9502  pop r9
00007accb5bd9504  pop r8
00007accb5bd9506  pop rsi
00007accb5bd9507  pop rdi
00007accb5bd9508  pop rdx
00007accb5bd9509  pop rcx
00007accb5bd950a  pop rax
00007accb5bd950b  add rsp, 0x08
00007accb5bd950f  jmp 0x00007ACCB5BD731B
00007accb5bd9514  sub rsp, 0x08
00007accb5bd9518  push rax
00007accb5bd9519  push rcx
00007accb5bd951a  push rdx
00007accb5bd951b  push rdi
00007accb5bd951c  push rsi
00007accb5bd951d  push r8
00007accb5bd951f  push r9
00007accb5bd9521  push r10
00007accb5bd9523  push r11
00007accb5bd9525  sub rsp, 0xF0
00007accb5bd952c  vmovaps [rsp], xmm0
00007accb5bd9531  vmovaps [rsp+0x10], xmm1
00007accb5bd9537  vmovaps [rsp+0x20], xmm2
00007accb5bd953d  vmovaps [rsp+0x30], xmm3
00007accb5bd9543  vmovaps [rsp+0x40], xmm4
00007accb5bd9549  vmovaps [rsp+0x50], xmm5
00007accb5bd954f  vmovaps [rsp+0x60], xmm6
00007accb5bd9555  vmovaps [rsp+0x70], xmm7
00007accb5bd955b  vmovaps [rsp+0x80], xmm8
00007accb5bd9564  vmovaps [rsp+0x90], xmm9
00007accb5bd956d  vmovaps [rsp+0xA0], xmm11
00007accb5bd9576  vmovaps [rsp+0xB0], xmm12
00007accb5bd957f  vmovaps [rsp+0xC0], xmm13
00007accb5bd9588  vmovaps [rsp+0xD0], xmm14
00007accb5bd9591  vmovaps [rsp+0xE0], xmm15
00007accb5bd959a  sub rsp, 0x40
00007accb5bd959e  lea rdi, [rsp]
00007accb5bd95a2  lea rsi, [rsp+0x10]
00007accb5bd95a7  lea rdx, [rsp+0x20]
00007accb5bd95ac  lea rcx, [rsp+0x30]
00007accb5bd95b1  mov r8d, 0x00
00007accb5bd95b7  lea r9, [r15+0x3A8]
00007accb5bd95be  movaps [rdi], xmm10
00007accb5bd95c2  movaps [rsi], xmm6
00007accb5bd95c5  movaps [rdx], xmm15
00007accb5bd95c9  movaps [rcx], xmm1
00007accb5bd95cc  mov rax, 0x59156B40DA50
00007accb5bd95d6  call rax
00007accb5bd95d8  movaps xmm10, [rsp]
00007accb5bd95dd  add rsp, 0x40
00007accb5bd95e1  vmovaps xmm0, [rsp]
00007accb5bd95e6  vmovaps xmm1, [rsp+0x10]
00007accb5bd95ec  vmovaps xmm2, [rsp+0x20]
00007accb5bd95f2  vmovaps xmm3, [rsp+0x30]
00007accb5bd95f8  vmovaps xmm4, [rsp+0x40]
00007accb5bd95fe  vmovaps xmm5, [rsp+0x50]
00007accb5bd9604  vmovaps xmm6, [rsp+0x60]
00007accb5bd960a  vmovaps xmm7, [rsp+0x70]
00007accb5bd9610  vmovaps xmm8, [rsp+0x80]
00007accb5bd9619  vmovaps xmm9, [rsp+0x90]
00007accb5bd9622  vmovaps xmm11, [rsp+0xA0]
00007accb5bd962b  vmovaps xmm12, [rsp+0xB0]
00007accb5bd9634  vmovaps xmm13, [rsp+0xC0]
00007accb5bd963d  vmovaps xmm14, [rsp+0xD0]
00007accb5bd9646  vmovaps xmm15, [rsp+0xE0]
00007accb5bd964f  add rsp, 0xF0
00007accb5bd9656  pop r11
00007accb5bd9658  pop r10
00007accb5bd965a  pop r9
00007accb5bd965c  pop r8
00007accb5bd965e  pop rsi
00007accb5bd965f  pop rdi
00007accb5bd9660  pop rdx
00007accb5bd9661  pop rcx
00007accb5bd9662  pop rax
00007accb5bd9663  add rsp, 0x08
00007accb5bd9667  jmp 0x00007ACCB5BD7341
00007accb5bd966c  call 0x00007ACCB59FF430
00007accb5bd9671  jmp 0x00007ACCB5BD734B
00007accb5bd9676  call 0x00007ACCB5A0E760
00007accb5bd967b  jmp 0x00007ACCB5BD7355
00007accb5bd9680  sub rsp, 0x08
00007accb5bd9684  push rax
00007accb5bd9685  push rcx
00007accb5bd9686  push rdx
00007accb5bd9687  push rdi
00007accb5bd9688  push rsi
00007accb5bd9689  push r8
00007accb5bd968b  push r9
00007accb5bd968d  push r10
00007accb5bd968f  push r11
00007accb5bd9691  sub rsp, 0xF0
00007accb5bd9698  vmovaps [rsp], xmm0
00007accb5bd969d  vmovaps [rsp+0x10], xmm1
00007accb5bd96a3  vmovaps [rsp+0x20], xmm2
00007accb5bd96a9  vmovaps [rsp+0x30], xmm3
00007accb5bd96af  vmovaps [rsp+0x40], xmm4
00007accb5bd96b5  vmovaps [rsp+0x50], xmm5
00007accb5bd96bb  vmovaps [rsp+0x60], xmm6
00007accb5bd96c1  vmovaps [rsp+0x70], xmm8
00007accb5bd96c7  vmovaps [rsp+0x80], xmm9
00007accb5bd96d0  vmovaps [rsp+0x90], xmm10
00007accb5bd96d9  vmovaps [rsp+0xA0], xmm11
00007accb5bd96e2  vmovaps [rsp+0xB0], xmm12
00007accb5bd96eb  vmovaps [rsp+0xC0], xmm13
00007accb5bd96f4  vmovaps [rsp+0xD0], xmm14
00007accb5bd96fd  vmovaps [rsp+0xE0], xmm15
00007accb5bd9706  sub rsp, 0x40
00007accb5bd970a  lea rdi, [rsp]
00007accb5bd970e  lea rsi, [rsp+0x10]
00007accb5bd9713  lea rdx, [rsp+0x20]
00007accb5bd9718  lea rcx, [rsp+0x30]
00007accb5bd971d  mov r8d, 0x00
00007accb5bd9723  lea r9, [r15+0x3A8]
00007accb5bd972a  movaps [rdi], xmm7
00007accb5bd972d  movaps [rsi], xmm8
00007accb5bd9731  movaps [rdx], xmm3
00007accb5bd9734  movaps [rcx], xmm9
00007accb5bd9738  mov rax, 0x59156B40DA50
00007accb5bd9742  call rax
00007accb5bd9744  movaps xmm7, [rsp]
00007accb5bd9748  add rsp, 0x40
00007accb5bd974c  vmovaps xmm0, [rsp]
00007accb5bd9751  vmovaps xmm1, [rsp+0x10]
00007accb5bd9757  vmovaps xmm2, [rsp+0x20]
00007accb5bd975d  vmovaps xmm3, [rsp+0x30]
00007accb5bd9763  vmovaps xmm4, [rsp+0x40]
00007accb5bd9769  vmovaps xmm5, [rsp+0x50]
00007accb5bd976f  vmovaps xmm6, [rsp+0x60]
00007accb5bd9775  vmovaps xmm8, [rsp+0x70]
00007accb5bd977b  vmovaps xmm9, [rsp+0x80]
00007accb5bd9784  vmovaps xmm10, [rsp+0x90]
00007accb5bd978d  vmovaps xmm11, [rsp+0xA0]
00007accb5bd9796  vmovaps xmm12, [rsp+0xB0]
00007accb5bd979f  vmovaps xmm13, [rsp+0xC0]
00007accb5bd97a8  vmovaps xmm14, [rsp+0xD0]
00007accb5bd97b1  vmovaps xmm15, [rsp+0xE0]
00007accb5bd97ba  add rsp, 0xF0
00007accb5bd97c1  pop r11
00007accb5bd97c3  pop r10
00007accb5bd97c5  pop r9
00007accb5bd97c7  pop r8
00007accb5bd97c9  pop rsi
00007accb5bd97ca  pop rdi
00007accb5bd97cb  pop rdx
00007accb5bd97cc  pop rcx
00007accb5bd97cd  pop rax
00007accb5bd97ce  add rsp, 0x08
00007accb5bd97d2  jmp 0x00007ACCB5BD737D
00007accb5bd97d7  sub rsp, 0x08
00007accb5bd97db  push rax
00007accb5bd97dc  push rcx
00007accb5bd97dd  push rdx
00007accb5bd97de  push rdi
00007accb5bd97df  push rsi
00007accb5bd97e0  push r8
00007accb5bd97e2  push r9
00007accb5bd97e4  push r10
00007accb5bd97e6  push r11
00007accb5bd97e8  sub rsp, 0xF0
00007accb5bd97ef  vmovaps [rsp], xmm0
00007accb5bd97f4  vmovaps [rsp+0x10], xmm1
00007accb5bd97fa  vmovaps [rsp+0x20], xmm2
00007accb5bd9800  vmovaps [rsp+0x30], xmm3
00007accb5bd9806  vmovaps [rsp+0x40], xmm4
00007accb5bd980c  vmovaps [rsp+0x50], xmm5
00007accb5bd9812  vmovaps [rsp+0x60], xmm6
00007accb5bd9818  vmovaps [rsp+0x70], xmm7
00007accb5bd981e  vmovaps [rsp+0x80], xmm9
00007accb5bd9827  vmovaps [rsp+0x90], xmm10
00007accb5bd9830  vmovaps [rsp+0xA0], xmm11
00007accb5bd9839  vmovaps [rsp+0xB0], xmm12
00007accb5bd9842  vmovaps [rsp+0xC0], xmm13
00007accb5bd984b  vmovaps [rsp+0xD0], xmm14
00007accb5bd9854  vmovaps [rsp+0xE0], xmm15
00007accb5bd985d  sub rsp, 0x40
00007accb5bd9861  lea rdi, [rsp]
00007accb5bd9865  lea rsi, [rsp+0x10]
00007accb5bd986a  lea rdx, [rsp+0x20]
00007accb5bd986f  lea rcx, [rsp+0x30]
00007accb5bd9874  mov r8d, 0x00
00007accb5bd987a  lea r9, [r15+0x3A8]
00007accb5bd9881  movaps [rdi], xmm8
00007accb5bd9885  movaps [rsi], xmm11
00007accb5bd9889  movaps [rdx], xmm14
00007accb5bd988d  movaps [rcx], xmm9
00007accb5bd9891  mov rax, 0x59156B40DA50
00007accb5bd989b  call rax
00007accb5bd989d  movaps xmm8, [rsp]
00007accb5bd98a2  add rsp, 0x40
00007accb5bd98a6  vmovaps xmm0, [rsp]
00007accb5bd98ab  vmovaps xmm1, [rsp+0x10]
00007accb5bd98b1  vmovaps xmm2, [rsp+0x20]
00007accb5bd98b7  vmovaps xmm3, [rsp+0x30]
00007accb5bd98bd  vmovaps xmm4, [rsp+0x40]
00007accb5bd98c3  vmovaps xmm5, [rsp+0x50]
00007accb5bd98c9  vmovaps xmm6, [rsp+0x60]
00007accb5bd98cf  vmovaps xmm7, [rsp+0x70]
00007accb5bd98d5  vmovaps xmm9, [rsp+0x80]
00007accb5bd98de  vmovaps xmm10, [rsp+0x90]
00007accb5bd98e7  vmovaps xmm11, [rsp+0xA0]
00007accb5bd98f0  vmovaps xmm12, [rsp+0xB0]
00007accb5bd98f9  vmovaps xmm13, [rsp+0xC0]
00007accb5bd9902  vmovaps xmm14, [rsp+0xD0]
00007accb5bd990b  vmovaps xmm15, [rsp+0xE0]
00007accb5bd9914  add rsp, 0xF0
00007accb5bd991b  pop r11
00007accb5bd991d  pop r10
00007accb5bd991f  pop r9
00007accb5bd9921  pop r8
00007accb5bd9923  pop rsi
00007accb5bd9924  pop rdi
00007accb5bd9925  pop rdx
00007accb5bd9926  pop rcx
00007accb5bd9927  pop rax
00007accb5bd9928  add rsp, 0x08
00007accb5bd992c  jmp 0x00007ACCB5BD73A6
00007accb5bd9931  sub rsp, 0x08
00007accb5bd9935  push rax
00007accb5bd9936  push rcx
00007accb5bd9937  push rdx
00007accb5bd9938  push rdi
00007accb5bd9939  push rsi
00007accb5bd993a  push r8
00007accb5bd993c  push r9
00007accb5bd993e  push r10
00007accb5bd9940  push r11
00007accb5bd9942  sub rsp, 0xF0
00007accb5bd9949  vmovaps [rsp], xmm0
00007accb5bd994e  vmovaps [rsp+0x10], xmm1
00007accb5bd9954  vmovaps [rsp+0x20], xmm2
00007accb5bd995a  vmovaps [rsp+0x30], xmm3
00007accb5bd9960  vmovaps [rsp+0x40], xmm4
00007accb5bd9966  vmovaps [rsp+0x50], xmm5
00007accb5bd996c  vmovaps [rsp+0x60], xmm6
00007accb5bd9972  vmovaps [rsp+0x70], xmm7
00007accb5bd9978  vmovaps [rsp+0x80], xmm8
00007accb5bd9981  vmovaps [rsp+0x90], xmm9
00007accb5bd998a  vmovaps [rsp+0xA0], xmm10
00007accb5bd9993  vmovaps [rsp+0xB0], xmm12
00007accb5bd999c  vmovaps [rsp+0xC0], xmm13
00007accb5bd99a5  vmovaps [rsp+0xD0], xmm14
00007accb5bd99ae  vmovaps [rsp+0xE0], xmm15
00007accb5bd99b7  sub rsp, 0x40
00007accb5bd99bb  lea rdi, [rsp]
00007accb5bd99bf  lea rsi, [rsp+0x10]
00007accb5bd99c4  lea rdx, [rsp+0x20]
00007accb5bd99c9  lea rcx, [rsp+0x30]
00007accb5bd99ce  mov r8d, 0x00
00007accb5bd99d4  lea r9, [r15+0x3A8]
00007accb5bd99db  movaps [rdi], xmm11
00007accb5bd99df  movaps [rsi], xmm13
00007accb5bd99e3  movaps [rdx], xmm12
00007accb5bd99e7  movaps [rcx], xmm14
00007accb5bd99eb  mov rax, 0x59156B40DA50
00007accb5bd99f5  call rax
00007accb5bd99f7  movaps xmm11, [rsp]
00007accb5bd99fc  add rsp, 0x40
00007accb5bd9a00  vmovaps xmm0, [rsp]
00007accb5bd9a05  vmovaps xmm1, [rsp+0x10]
00007accb5bd9a0b  vmovaps xmm2, [rsp+0x20]
00007accb5bd9a11  vmovaps xmm3, [rsp+0x30]
00007accb5bd9a17  vmovaps xmm4, [rsp+0x40]
00007accb5bd9a1d  vmovaps xmm5, [rsp+0x50]
00007accb5bd9a23  vmovaps xmm6, [rsp+0x60]
00007accb5bd9a29  vmovaps xmm7, [rsp+0x70]
00007accb5bd9a2f  vmovaps xmm8, [rsp+0x80]
00007accb5bd9a38  vmovaps xmm9, [rsp+0x90]
00007accb5bd9a41  vmovaps xmm10, [rsp+0xA0]
00007accb5bd9a4a  vmovaps xmm12, [rsp+0xB0]
00007accb5bd9a53  vmovaps xmm13, [rsp+0xC0]
00007accb5bd9a5c  vmovaps xmm14, [rsp+0xD0]
00007accb5bd9a65  vmovaps xmm15, [rsp+0xE0]
00007accb5bd9a6e  add rsp, 0xF0
00007accb5bd9a75  pop r11
00007accb5bd9a77  pop r10
00007accb5bd9a79  pop r9
00007accb5bd9a7b  pop r8
00007accb5bd9a7d  pop rsi
00007accb5bd9a7e  pop rdi
00007accb5bd9a7f  pop rdx
00007accb5bd9a80  pop rcx
00007accb5bd9a81  pop rax
00007accb5bd9a82  add rsp, 0x08
00007accb5bd9a86  jmp 0x00007ACCB5BD73CF
00007accb5bd9a8b  sub rsp, 0x08
00007accb5bd9a8f  push rax
00007accb5bd9a90  push rcx
00007accb5bd9a91  push rdx
00007accb5bd9a92  push rdi
00007accb5bd9a93  push rsi
00007accb5bd9a94  push r8
00007accb5bd9a96  push r9
00007accb5bd9a98  push r10
00007accb5bd9a9a  push r11
00007accb5bd9a9c  sub rsp, 0xF0
00007accb5bd9aa3  vmovaps [rsp], xmm0
00007accb5bd9aa8  vmovaps [rsp+0x10], xmm1
00007accb5bd9aae  vmovaps [rsp+0x20], xmm2
00007accb5bd9ab4  vmovaps [rsp+0x30], xmm3
00007accb5bd9aba  vmovaps [rsp+0x40], xmm4
00007accb5bd9ac0  vmovaps [rsp+0x50], xmm5
00007accb5bd9ac6  vmovaps [rsp+0x60], xmm6
00007accb5bd9acc  vmovaps [rsp+0x70], xmm7
00007accb5bd9ad2  vmovaps [rsp+0x80], xmm8
00007accb5bd9adb  vmovaps [rsp+0x90], xmm9
00007accb5bd9ae4  vmovaps [rsp+0xA0], xmm10
00007accb5bd9aed  vmovaps [rsp+0xB0], xmm11
00007accb5bd9af6  vmovaps [rsp+0xC0], xmm13
00007accb5bd9aff  vmovaps [rsp+0xD0], xmm14
00007accb5bd9b08  vmovaps [rsp+0xE0], xmm15
00007accb5bd9b11  sub rsp, 0x40
00007accb5bd9b15  lea rdi, [rsp]
00007accb5bd9b19  lea rsi, [rsp+0x10]
00007accb5bd9b1e  lea rdx, [rsp+0x20]
00007accb5bd9b23  lea rcx, [rsp+0x30]
00007accb5bd9b28  mov r8d, 0x00
00007accb5bd9b2e  lea r9, [r15+0x3A8]
00007accb5bd9b35  movaps [rdi], xmm12
00007accb5bd9b39  movaps [rsi], xmm10
00007accb5bd9b3d  movaps [rdx], xmm15
00007accb5bd9b41  movaps [rcx], xmm14
00007accb5bd9b45  mov rax, 0x59156B40DA50
00007accb5bd9b4f  call rax
00007accb5bd9b51  movaps xmm12, [rsp]
00007accb5bd9b56  add rsp, 0x40
00007accb5bd9b5a  vmovaps xmm0, [rsp]
00007accb5bd9b5f  vmovaps xmm1, [rsp+0x10]
00007accb5bd9b65  vmovaps xmm2, [rsp+0x20]
00007accb5bd9b6b  vmovaps xmm3, [rsp+0x30]
00007accb5bd9b71  vmovaps xmm4, [rsp+0x40]
00007accb5bd9b77  vmovaps xmm5, [rsp+0x50]
00007accb5bd9b7d  vmovaps xmm6, [rsp+0x60]
00007accb5bd9b83  vmovaps xmm7, [rsp+0x70]
00007accb5bd9b89  vmovaps xmm8, [rsp+0x80]
00007accb5bd9b92  vmovaps xmm9, [rsp+0x90]
00007accb5bd9b9b  vmovaps xmm10, [rsp+0xA0]
00007accb5bd9ba4  vmovaps xmm11, [rsp+0xB0]
00007accb5bd9bad  vmovaps xmm13, [rsp+0xC0]
00007accb5bd9bb6  vmovaps xmm14, [rsp+0xD0]
00007accb5bd9bbf  vmovaps xmm15, [rsp+0xE0]
00007accb5bd9bc8  add rsp, 0xF0
00007accb5bd9bcf  pop r11
00007accb5bd9bd1  pop r10
00007accb5bd9bd3  pop r9
00007accb5bd9bd5  pop r8
00007accb5bd9bd7  pop rsi
00007accb5bd9bd8  pop rdi
00007accb5bd9bd9  pop rdx
00007accb5bd9bda  pop rcx
00007accb5bd9bdb  pop rax
00007accb5bd9bdc  add rsp, 0x08
00007accb5bd9be0  jmp 0x00007ACCB5BD73F8
00007accb5bd9be5  call 0x00007ACCB5A0E760
00007accb5bd9bea  jmp 0x00007ACCB5BD7405
00007accb5bd9bef  call 0x00007ACCB5A0D4E0
00007accb5bd9bf4  jmp 0x00007ACCB5BD7412
00007accb5bd9bf9  sub rsp, 0x08
00007accb5bd9bfd  push rax
00007accb5bd9bfe  push rcx
00007accb5bd9bff  push rdx
00007accb5bd9c00  push rdi
00007accb5bd9c01  push rsi
00007accb5bd9c02  push r8
00007accb5bd9c04  push r9
00007accb5bd9c06  push r10
00007accb5bd9c08  push r11
00007accb5bd9c0a  sub rsp, 0xF0
00007accb5bd9c11  vmovaps [rsp], xmm0
00007accb5bd9c16  vmovaps [rsp+0x10], xmm1
00007accb5bd9c1c  vmovaps [rsp+0x20], xmm2
00007accb5bd9c22  vmovaps [rsp+0x30], xmm3
00007accb5bd9c28  vmovaps [rsp+0x40], xmm4
00007accb5bd9c2e  vmovaps [rsp+0x50], xmm5
00007accb5bd9c34  vmovaps [rsp+0x60], xmm6
00007accb5bd9c3a  vmovaps [rsp+0x70], xmm7
00007accb5bd9c40  vmovaps [rsp+0x80], xmm8
00007accb5bd9c49  vmovaps [rsp+0x90], xmm9
00007accb5bd9c52  vmovaps [rsp+0xA0], xmm11
00007accb5bd9c5b  vmovaps [rsp+0xB0], xmm12
00007accb5bd9c64  vmovaps [rsp+0xC0], xmm13
00007accb5bd9c6d  vmovaps [rsp+0xD0], xmm14
00007accb5bd9c76  vmovaps [rsp+0xE0], xmm15
00007accb5bd9c7f  sub rsp, 0x40
00007accb5bd9c83  lea rdi, [rsp]
00007accb5bd9c87  lea rsi, [rsp+0x10]
00007accb5bd9c8c  lea rdx, [rsp+0x20]
00007accb5bd9c91  lea rcx, [rsp+0x30]
00007accb5bd9c96  mov r8d, 0x00
00007accb5bd9c9c  lea r9, [r15+0x3A8]
00007accb5bd9ca3  movaps [rdi], xmm10
00007accb5bd9ca7  movaps [rsi], xmm7
00007accb5bd9caa  movaps [rdx], xmm1
00007accb5bd9cad  movaps [rcx], xmm13
00007accb5bd9cb1  mov rax, 0x59156B40DA50
00007accb5bd9cbb  call rax
00007accb5bd9cbd  movaps xmm10, [rsp]
00007accb5bd9cc2  add rsp, 0x40
00007accb5bd9cc6  vmovaps xmm0, [rsp]
00007accb5bd9ccb  vmovaps xmm1, [rsp+0x10]
00007accb5bd9cd1  vmovaps xmm2, [rsp+0x20]
00007accb5bd9cd7  vmovaps xmm3, [rsp+0x30]
00007accb5bd9cdd  vmovaps xmm4, [rsp+0x40]
00007accb5bd9ce3  vmovaps xmm5, [rsp+0x50]
00007accb5bd9ce9  vmovaps xmm6, [rsp+0x60]
00007accb5bd9cef  vmovaps xmm7, [rsp+0x70]
00007accb5bd9cf5  vmovaps xmm8, [rsp+0x80]
00007accb5bd9cfe  vmovaps xmm9, [rsp+0x90]
00007accb5bd9d07  vmovaps xmm11, [rsp+0xA0]
00007accb5bd9d10  vmovaps xmm12, [rsp+0xB0]
00007accb5bd9d19  vmovaps xmm13, [rsp+0xC0]
00007accb5bd9d22  vmovaps xmm14, [rsp+0xD0]
00007accb5bd9d2b  vmovaps xmm15, [rsp+0xE0]
00007accb5bd9d34  add rsp, 0xF0
00007accb5bd9d3b  pop r11
00007accb5bd9d3d  pop r10
00007accb5bd9d3f  pop r9
00007accb5bd9d41  pop r8
00007accb5bd9d43  pop rsi
00007accb5bd9d44  pop rdi
00007accb5bd9d45  pop rdx
00007accb5bd9d46  pop rcx
00007accb5bd9d47  pop rax
00007accb5bd9d48  add rsp, 0x08
00007accb5bd9d4c  jmp 0x00007ACCB5BD7448
00007accb5bd9d51  call 0x00007ACCB59FF430
00007accb5bd9d56  jmp 0x00007ACCB5BD745A
00007accb5bd9d5b  sub rsp, 0x08
00007accb5bd9d5f  push rax
00007accb5bd9d60  push rcx
00007accb5bd9d61  push rdx
00007accb5bd9d62  push rdi
00007accb5bd9d63  push rsi
00007accb5bd9d64  push r8
00007accb5bd9d66  push r9
00007accb5bd9d68  push r10
00007accb5bd9d6a  push r11
00007accb5bd9d6c  sub rsp, 0xF0
00007accb5bd9d73  vmovaps [rsp], xmm0
00007accb5bd9d78  vmovaps [rsp+0x10], xmm1
00007accb5bd9d7e  vmovaps [rsp+0x20], xmm2
00007accb5bd9d84  vmovaps [rsp+0x30], xmm3
00007accb5bd9d8a  vmovaps [rsp+0x40], xmm4
00007accb5bd9d90  vmovaps [rsp+0x50], xmm5
00007accb5bd9d96  vmovaps [rsp+0x60], xmm6
00007accb5bd9d9c  vmovaps [rsp+0x70], xmm7
00007accb5bd9da2  vmovaps [rsp+0x80], xmm8
00007accb5bd9dab  vmovaps [rsp+0x90], xmm10
00007accb5bd9db4  vmovaps [rsp+0xA0], xmm11
00007accb5bd9dbd  vmovaps [rsp+0xB0], xmm12
00007accb5bd9dc6  vmovaps [rsp+0xC0], xmm13
00007accb5bd9dcf  vmovaps [rsp+0xD0], xmm14
00007accb5bd9dd8  vmovaps [rsp+0xE0], xmm15
00007accb5bd9de1  sub rsp, 0x40
00007accb5bd9de5  lea rdi, [rsp]
00007accb5bd9de9  lea rsi, [rsp+0x10]
00007accb5bd9dee  lea rdx, [rsp+0x20]
00007accb5bd9df3  lea rcx, [rsp+0x30]
00007accb5bd9df8  mov r8d, 0x00
00007accb5bd9dfe  lea r9, [r15+0x3A8]
00007accb5bd9e05  movaps [rdi], xmm9
00007accb5bd9e09  movaps [rsi], xmm8
00007accb5bd9e0d  movaps [rdx], xmm14
00007accb5bd9e11  movaps [rcx], xmm13
00007accb5bd9e15  mov rax, 0x59156B40DA50
00007accb5bd9e1f  call rax
00007accb5bd9e21  movaps xmm9, [rsp]
00007accb5bd9e26  add rsp, 0x40
00007accb5bd9e2a  vmovaps xmm0, [rsp]
00007accb5bd9e2f  vmovaps xmm1, [rsp+0x10]
00007accb5bd9e35  vmovaps xmm2, [rsp+0x20]
00007accb5bd9e3b  vmovaps xmm3, [rsp+0x30]
00007accb5bd9e41  vmovaps xmm4, [rsp+0x40]
00007accb5bd9e47  vmovaps xmm5, [rsp+0x50]
00007accb5bd9e4d  vmovaps xmm6, [rsp+0x60]
00007accb5bd9e53  vmovaps xmm7, [rsp+0x70]
00007accb5bd9e59  vmovaps xmm8, [rsp+0x80]
00007accb5bd9e62  vmovaps xmm10, [rsp+0x90]
00007accb5bd9e6b  vmovaps xmm11, [rsp+0xA0]
00007accb5bd9e74  vmovaps xmm12, [rsp+0xB0]
00007accb5bd9e7d  vmovaps xmm13, [rsp+0xC0]
00007accb5bd9e86  vmovaps xmm14, [rsp+0xD0]
00007accb5bd9e8f  vmovaps xmm15, [rsp+0xE0]
00007accb5bd9e98  add rsp, 0xF0
00007accb5bd9e9f  pop r11
00007accb5bd9ea1  pop r10
00007accb5bd9ea3  pop r9
00007accb5bd9ea5  pop r8
00007accb5bd9ea7  pop rsi
00007accb5bd9ea8  pop rdi
00007accb5bd9ea9  pop rdx
00007accb5bd9eaa  pop rcx
00007accb5bd9eab  pop rax
00007accb5bd9eac  add rsp, 0x08
00007accb5bd9eb0  jmp 0x00007ACCB5BD7488
00007accb5bd9eb5  sub rsp, 0x08
00007accb5bd9eb9  push rax
00007accb5bd9eba  push rcx
00007accb5bd9ebb  push rdx
00007accb5bd9ebc  push rdi
00007accb5bd9ebd  push rsi
00007accb5bd9ebe  push r8
00007accb5bd9ec0  push r9
00007accb5bd9ec2  push r10
00007accb5bd9ec4  push r11
00007accb5bd9ec6  sub rsp, 0xF0
00007accb5bd9ecd  vmovaps [rsp], xmm0
00007accb5bd9ed2  vmovaps [rsp+0x10], xmm1
00007accb5bd9ed8  vmovaps [rsp+0x20], xmm2
00007accb5bd9ede  vmovaps [rsp+0x30], xmm3
00007accb5bd9ee4  vmovaps [rsp+0x40], xmm4
00007accb5bd9eea  vmovaps [rsp+0x50], xmm5
00007accb5bd9ef0  vmovaps [rsp+0x60], xmm6
00007accb5bd9ef6  vmovaps [rsp+0x70], xmm7
00007accb5bd9efc  vmovaps [rsp+0x80], xmm8
00007accb5bd9f05  vmovaps [rsp+0x90], xmm9
00007accb5bd9f0e  vmovaps [rsp+0xA0], xmm10
00007accb5bd9f17  vmovaps [rsp+0xB0], xmm11
00007accb5bd9f20  vmovaps [rsp+0xC0], xmm12
00007accb5bd9f29  vmovaps [rsp+0xD0], xmm14
00007accb5bd9f32  vmovaps [rsp+0xE0], xmm15
00007accb5bd9f3b  sub rsp, 0x40
00007accb5bd9f3f  lea rdi, [rsp]
00007accb5bd9f43  lea rsi, [rsp+0x10]
00007accb5bd9f48  lea rdx, [rsp+0x20]
00007accb5bd9f4d  lea rcx, [rsp+0x30]
00007accb5bd9f52  mov r8d, 0x00
00007accb5bd9f58  lea r9, [r15+0x3A8]
00007accb5bd9f5f  movaps [rdi], xmm13
00007accb5bd9f63  movaps [rsi], xmm11
00007accb5bd9f67  movaps [rdx], xmm15
00007accb5bd9f6b  movaps [rcx], xmm14
00007accb5bd9f6f  mov rax, 0x59156B40DA50
00007accb5bd9f79  call rax
00007accb5bd9f7b  movaps xmm13, [rsp]
00007accb5bd9f80  add rsp, 0x40
00007accb5bd9f84  vmovaps xmm0, [rsp]
00007accb5bd9f89  vmovaps xmm1, [rsp+0x10]
00007accb5bd9f8f  vmovaps xmm2, [rsp+0x20]
00007accb5bd9f95  vmovaps xmm3, [rsp+0x30]
00007accb5bd9f9b  vmovaps xmm4, [rsp+0x40]
00007accb5bd9fa1  vmovaps xmm5, [rsp+0x50]
00007accb5bd9fa7  vmovaps xmm6, [rsp+0x60]
00007accb5bd9fad  vmovaps xmm7, [rsp+0x70]
00007accb5bd9fb3  vmovaps xmm8, [rsp+0x80]
00007accb5bd9fbc  vmovaps xmm9, [rsp+0x90]
00007accb5bd9fc5  vmovaps xmm10, [rsp+0xA0]
00007accb5bd9fce  vmovaps xmm11, [rsp+0xB0]
00007accb5bd9fd7  vmovaps xmm12, [rsp+0xC0]
00007accb5bd9fe0  vmovaps xmm14, [rsp+0xD0]
00007accb5bd9fe9  vmovaps xmm15, [rsp+0xE0]
00007accb5bd9ff2  add rsp, 0xF0
00007accb5bd9ff9  pop r11
00007accb5bd9ffb  pop r10
00007accb5bd9ffd  pop r9
00007accb5bd9fff  pop r8
00007accb5bda001  pop rsi
00007accb5bda002  pop rdi
00007accb5bda003  pop rdx
00007accb5bda004  pop rcx
00007accb5bda005  pop rax
00007accb5bda006  add rsp, 0x08
00007accb5bda00a  jmp 0x00007ACCB5BD74B6
00007accb5bda00f  sub rsp, 0x08
00007accb5bda013  push rax
00007accb5bda014  push rcx
00007accb5bda015  push rdx
00007accb5bda016  push rdi
00007accb5bda017  push rsi
00007accb5bda018  push r8
00007accb5bda01a  push r9
00007accb5bda01c  push r10
00007accb5bda01e  push r11
00007accb5bda020  sub rsp, 0xF0
00007accb5bda027  vmovaps [rsp], xmm0
00007accb5bda02c  vmovaps [rsp+0x10], xmm1
00007accb5bda032  vmovaps [rsp+0x20], xmm2
00007accb5bda038  vmovaps [rsp+0x30], xmm3
00007accb5bda03e  vmovaps [rsp+0x40], xmm4
00007accb5bda044  vmovaps [rsp+0x50], xmm5
00007accb5bda04a  vmovaps [rsp+0x60], xmm6
00007accb5bda050  vmovaps [rsp+0x70], xmm7
00007accb5bda056  vmovaps [rsp+0x80], xmm8
00007accb5bda05f  vmovaps [rsp+0x90], xmm9
00007accb5bda068  vmovaps [rsp+0xA0], xmm10
00007accb5bda071  vmovaps [rsp+0xB0], xmm11
00007accb5bda07a  vmovaps [rsp+0xC0], xmm12
00007accb5bda083  vmovaps [rsp+0xD0], xmm13
00007accb5bda08c  vmovaps [rsp+0xE0], xmm15
00007accb5bda095  sub rsp, 0x40
00007accb5bda099  lea rdi, [rsp]
00007accb5bda09d  lea rsi, [rsp+0x10]
00007accb5bda0a2  lea rdx, [rsp+0x20]
00007accb5bda0a7  lea rcx, [rsp+0x30]
00007accb5bda0ac  mov r8d, 0x00
00007accb5bda0b2  lea r9, [r15+0x3A8]
00007accb5bda0b9  movaps [rdi], xmm14
00007accb5bda0bd  movaps [rsi], xmm12
00007accb5bda0c1  movaps [rdx], xmm1
00007accb5bda0c4  movaps [rcx], xmm15
00007accb5bda0c8  mov rax, 0x59156B40DA50
00007accb5bda0d2  call rax
00007accb5bda0d4  movaps xmm14, [rsp]
00007accb5bda0d9  add rsp, 0x40
00007accb5bda0dd  vmovaps xmm0, [rsp]
00007accb5bda0e2  vmovaps xmm1, [rsp+0x10]
00007accb5bda0e8  vmovaps xmm2, [rsp+0x20]
00007accb5bda0ee  vmovaps xmm3, [rsp+0x30]
00007accb5bda0f4  vmovaps xmm4, [rsp+0x40]
00007accb5bda0fa  vmovaps xmm5, [rsp+0x50]
00007accb5bda100  vmovaps xmm6, [rsp+0x60]
00007accb5bda106  vmovaps xmm7, [rsp+0x70]
00007accb5bda10c  vmovaps xmm8, [rsp+0x80]
00007accb5bda115  vmovaps xmm9, [rsp+0x90]
00007accb5bda11e  vmovaps xmm10, [rsp+0xA0]
00007accb5bda127  vmovaps xmm11, [rsp+0xB0]
00007accb5bda130  vmovaps xmm12, [rsp+0xC0]
00007accb5bda139  vmovaps xmm13, [rsp+0xD0]
00007accb5bda142  vmovaps xmm15, [rsp+0xE0]
00007accb5bda14b  add rsp, 0xF0
00007accb5bda152  pop r11
00007accb5bda154  pop r10
00007accb5bda156  pop r9
00007accb5bda158  pop r8
00007accb5bda15a  pop rsi
00007accb5bda15b  pop rdi
00007accb5bda15c  pop rdx
00007accb5bda15d  pop rcx
00007accb5bda15e  pop rax
00007accb5bda15f  add rsp, 0x08
00007accb5bda163  jmp 0x00007ACCB5BD74E4
00007accb5bda168  call 0x00007ACCB5A079B0
00007accb5bda16d  jmp 0x00007ACCB5BD74FA
00007accb5bda172  call 0x00007ACCB5AE3440
00007accb5bda177  jmp 0x00007ACCB5BD7504
00007accb5bda17c  call 0x00007ACCB5ADFCE0
00007accb5bda181  jmp 0x00007ACCB5BD750E
00007accb5bda186  call 0x00007ACCB5AE46C0
00007accb5bda18b  jmp 0x00007ACCB5BD7518
00007accb5bda190  int3
00007accb5bda191  nop [rax+rax*1], ax
00007accb5bda19a  nop [rax+rax*1], ax
00007accb5bda1a0  mov rax, [r15+0xF8]
00007accb5bda1a7  lea r14, [rax+0x110]
00007accb5bda1ae  mov r12, [r13+r14*1]
00007accb5bda1b3  mov [r15+0xE8], r12
00007accb5bda1ba  lea r14, [rax+0x100]
00007accb5bda1c1  mov r12, [r13+r14*1]
00007accb5bda1c6  lea r14, [rax+0x108]
00007accb5bda1cd  mov r11, [r13+r14*1]
00007accb5bda1d2  movq xmm1, r12
00007accb5bda1d7  movq xmm15, r11
00007accb5bda1dc  movq xmm1, xmm1
00007accb5bda1e0  movq xmm1, xmm1
00007accb5bda1e4  movaps [r15+0x1A0], xmm1
00007accb5bda1ec  movq xmm15, xmm15
00007accb5bda1f1  movq xmm15, xmm15
00007accb5bda1f6  movaps [r15+0x190], xmm15
00007accb5bda1fe  lea r14, [rax+0xF0]
00007accb5bda205  mov r12, [r13+r14*1]
00007accb5bda20a  lea r14, [rax+0xF8]
00007accb5bda211  mov r11, [r13+r14*1]
00007accb5bda216  movq xmm1, r12
00007accb5bda21b  movq xmm15, r11
00007accb5bda220  movq xmm1, xmm1
00007accb5bda224  movq xmm1, xmm1
00007accb5bda228  movaps [r15+0x1C0], xmm1
00007accb5bda230  movq xmm15, xmm15
00007accb5bda235  movq xmm15, xmm15
00007accb5bda23a  movaps [r15+0x1B0], xmm15
00007accb5bda242  lea r14, [rax+0xE0]
00007accb5bda249  mov r12, [r13+r14*1]
00007accb5bda24e  lea r14, [rax+0xE8]
00007accb5bda255  mov r11, [r13+r14*1]
00007accb5bda25a  movq xmm1, r12
00007accb5bda25f  movq xmm15, r11
00007accb5bda264  movq xmm1, xmm1
00007accb5bda268  movq xmm1, xmm1
00007accb5bda26c  movaps [r15+0x1E0], xmm1
00007accb5bda274  movq xmm15, xmm15
00007accb5bda279  movq xmm15, xmm15
00007accb5bda27e  movaps [r15+0x1D0], xmm15
00007accb5bda286  lea r14, [rax+0xD0]
00007accb5bda28d  mov r12, [r13+r14*1]
00007accb5bda292  lea r14, [rax+0xD8]
00007accb5bda299  mov r11, [r13+r14*1]
00007accb5bda29e  movq xmm1, r12
00007accb5bda2a3  movq xmm15, r11
00007accb5bda2a8  movq xmm1, xmm1
00007accb5bda2ac  movq xmm1, xmm1
00007accb5bda2b0  movaps [r15+0x200], xmm1
00007accb5bda2b8  movq xmm15, xmm15
00007accb5bda2bd  movq xmm15, xmm15
00007accb5bda2c2  movaps [r15+0x1F0], xmm15
00007accb5bda2ca  mov qword ptr [r15+0x40], 0x430000
00007accb5bda2d2  mov r14d, 0x4304C0
00007accb5bda2d8  mov r12, [r13+r14*1]
00007accb5bda2dd  movq xmm1, r12
00007accb5bda2e2  lea r14, [rax+0x120]
00007accb5bda2e9  mov [r15+0xF8], r14
00007accb5bda2f0  mov rax, [r15+0x50]
00007accb5bda2f4  movups xmm15, [r13+rax*1]
00007accb5bda2fa  movaps [r15+0x120], xmm15
00007accb5bda302  mov qword ptr [r15+0x48], 0x10
00007accb5bda30a  xor eax, eax
00007accb5bda30c  mov r14d, 0x10
00007accb5bda312  mov r12d, 0x200
00007accb5bda318  cmp r14, r12
00007accb5bda31b  cmc
00007accb5bda31c  lahf
00007accb5bda31d  seto al
00007accb5bda320  mov [r15+0x108], eax
00007accb5bda327  pextrq rax, xmm15, 0x01
00007accb5bda32e  movq xmm14, rax
00007accb5bda333  movaps [r15+0x130], xmm14
00007accb5bda33b  movq rax, xmm1
00007accb5bda340  movq r14, xmm15
00007accb5bda345  vmovq xmm1, rax
00007accb5bda34a  vmovq xmm15, r14
00007accb5bda34f  movaps xmm13, xmm1
00007accb5bda353  addsd xmm13, xmm15
00007accb5bda358  ucomisd xmm13, xmm13
00007accb5bda35d  jp 0x00007ACCB5BDA476
00007accb5bda363  movq xmm13, xmm13
00007accb5bda368  movq rax, xmm13
00007accb5bda36d  movq r14, xmm14
00007accb5bda372  vmovq xmm1, rax
00007accb5bda377  vmovq xmm15, r14
00007accb5bda37c  movaps xmm14, xmm1
00007accb5bda380  addsd xmm14, xmm15
00007accb5bda385  ucomisd xmm14, xmm14
00007accb5bda38a  jp 0x00007ACCB5BDA4BE
00007accb5bda390  movq xmm14, xmm14
00007accb5bda395  movaps [r15+0x110], xmm14
00007accb5bda39d  mov eax, [r15+0x108]
00007accb5bda3a4  sahf
00007accb5bda3a5  jnz 0x00007ACCB5BDA3D7
00007accb5bda3a7  cmp dword ptr [r15+0x318], 0x00
00007accb5bda3af  jz 0x00007ACCB5BDA6D0
00007accb5bda3b5  nop [rax+rax*1], ax
00007accb5bda3be  nop [rax+rax*1], eax
00007accb5bda3c6  mov eax, 0x41043C
00007accb5bda3cb  mov [r15+0x100], rax
00007accb5bda3d2  jmp 0x00007ACCB59FE110
00007accb5bda3d7  cmp dword ptr [r15+0x318], 0x00
00007accb5bda3df  jz 0x00007ACCB5BDA510
00007accb5bda3e5  nop [rax+rax*1], ax
00007accb5bda3ee  nop [rax+rax*1], eax
00007accb5bda3f6  mov eax, 0x410420
00007accb5bda3fb  mov [r15+0x100], rax
00007accb5bda402  jmp 0x00007ACCB59FE110
00007accb5bda407  int3
00007accb5bda408  call 0x00007ACCB5AE27E0
00007accb5bda40d  jmp 0x00007ACCB5BDA1B3
00007accb5bda412  call 0x00007ACCB5AE27E0
00007accb5bda417  jmp 0x00007ACCB5BDA1C6
00007accb5bda41c  call 0x00007ACCB5AE1570
00007accb5bda421  jmp 0x00007ACCB5BDA1D2
00007accb5bda426  call 0x00007ACCB5AE27E0
00007accb5bda42b  jmp 0x00007ACCB5BDA20A
00007accb5bda430  call 0x00007ACCB5AE1570
00007accb5bda435  jmp 0x00007ACCB5BDA216
00007accb5bda43a  call 0x00007ACCB5AE27E0
00007accb5bda43f  jmp 0x00007ACCB5BDA24E
00007accb5bda444  call 0x00007ACCB5AE1570
00007accb5bda449  jmp 0x00007ACCB5BDA25A
00007accb5bda44e  call 0x00007ACCB5AE27E0
00007accb5bda453  jmp 0x00007ACCB5BDA292
00007accb5bda458  call 0x00007ACCB5AE1570
00007accb5bda45d  jmp 0x00007ACCB5BDA29E
00007accb5bda462  call 0x00007ACCB5AE27E0
00007accb5bda467  jmp 0x00007ACCB5BDA2DD
00007accb5bda46c  call 0x00007ACCB5A0E760
00007accb5bda471  jmp 0x00007ACCB5BDA2FA
00007accb5bda476  ucomisd xmm1, xmm15
00007accb5bda47b  jp 0x00007ACCB5BDA48A
00007accb5bda47d  movaps xmm13, [0x00007ACCB57FE060]
00007accb5bda485  jmp 0x00007ACCB5BDA363
00007accb5bda48a  vxorps xmm0, xmm1, xmm15
00007accb5bda48f  pextrw eax, xmm0, 0x03
00007accb5bda494  and eax, 0x7FF8
00007accb5bda499  cmp eax, 0x08
00007accb5bda49c  jnz 0x00007ACCB5BDA363
00007accb5bda4a2  movq rax, xmm15
00007accb5bda4a7  shl rax, 0x0D
00007accb5bda4ab  jbe 0x00007ACCB5BDA363
00007accb5bda4b1  vorps xmm13, xmm15, [0x00007ACCB57FE070]
00007accb5bda4b9  jmp 0x00007ACCB5BDA363
00007accb5bda4be  ucomisd xmm1, xmm15
00007accb5bda4c3  jp 0x00007ACCB5BDA4D2
00007accb5bda4c5  movaps xmm14, [0x00007ACCB57FE060]
00007accb5bda4cd  jmp 0x00007ACCB5BDA390
00007accb5bda4d2  vxorps xmm0, xmm1, xmm15
00007accb5bda4d7  pextrw eax, xmm0, 0x03
00007accb5bda4dc  and eax, 0x7FF8
00007accb5bda4e1  cmp eax, 0x08
00007accb5bda4e4  jnz 0x00007ACCB5BDA390
00007accb5bda4ea  movq rax, xmm15
00007accb5bda4ef  shl rax, 0x0D
00007accb5bda4f3  jbe 0x00007ACCB5BDA390
00007accb5bda4f9  vorps xmm14, xmm15, [0x00007ACCB57FE070]
00007accb5bda501  jmp 0x00007ACCB5BDA390
00007accb5bda506  int3
00007accb5bda507  nop [rax+rax*1], ax
00007accb5bda510  mov rax, [r15+0x48]
00007accb5bda514  mov r14, [r15+0x50]
00007accb5bda518  lea r12, [r14+rax*1]
00007accb5bda51c  movups xmm1, [r13+r12*1]
00007accb5bda522  movaps [r15+0x120], xmm1
00007accb5bda52a  lea r14, [rax+0x10]
00007accb5bda52e  mov [r15+0x48], r14
00007accb5bda532  xor eax, eax
00007accb5bda534  mov r12d, 0x200
00007accb5bda53a  cmp r14, r12
00007accb5bda53d  cmc
00007accb5bda53e  lahf
00007accb5bda53f  seto al
00007accb5bda542  mov [r15+0x108], eax
00007accb5bda549  pextrq rax, xmm1, 0x01
00007accb5bda550  movq xmm15, rax
00007accb5bda555  movaps [r15+0x130], xmm15
00007accb5bda55d  movaps xmm14, [r15+0x110]
00007accb5bda565  movq rax, xmm14
00007accb5bda56a  movq r14, xmm1
00007accb5bda56f  vmovq xmm1, rax
00007accb5bda574  vmovq xmm14, r14
00007accb5bda579  movaps xmm13, xmm1
00007accb5bda57d  addsd xmm13, xmm14
00007accb5bda582  ucomisd xmm13, xmm13
00007accb5bda587  jp 0x00007ACCB5BDA63C
00007accb5bda58d  movq xmm13, xmm13
00007accb5bda592  movq rax, xmm13
00007accb5bda597  movq r14, xmm15
00007accb5bda59c  vmovq xmm1, rax
00007accb5bda5a1  vmovq xmm15, r14
00007accb5bda5a6  movaps xmm14, xmm1
00007accb5bda5aa  addsd xmm14, xmm15
00007accb5bda5af  ucomisd xmm14, xmm14
00007accb5bda5b4  jp 0x00007ACCB5BDA684
00007accb5bda5ba  movq xmm14, xmm14
00007accb5bda5bf  movaps [r15+0x110], xmm14
00007accb5bda5c7  mov eax, [r15+0x108]
00007accb5bda5ce  sahf
00007accb5bda5cf  jnz 0x00007ACCB5BDA601
00007accb5bda5d1  cmp dword ptr [r15+0x318], 0x00
00007accb5bda5d9  jz 0x00007ACCB5BDA6D0
00007accb5bda5df  nop [rax+rax*1], ax
00007accb5bda5e8  nop [rax+rax*1], eax
00007accb5bda5f0  mov eax, 0x41043C
00007accb5bda5f5  mov [r15+0x100], rax
00007accb5bda5fc  jmp 0x00007ACCB59FE110
00007accb5bda601  cmp dword ptr [r15+0x318], 0x00
00007accb5bda609  jz 0x00007ACCB5BDA510
00007accb5bda60f  nop [rax+rax*1], ax
00007accb5bda618  nop [rax+rax*1], eax
00007accb5bda620  mov eax, 0x410420
00007accb5bda625  mov [r15+0x100], rax
00007accb5bda62c  jmp 0x00007ACCB59FE110
00007accb5bda631  int3
00007accb5bda632  call 0x00007ACCB5AB52F0
00007accb5bda637  jmp 0x00007ACCB5BDA522
00007accb5bda63c  ucomisd xmm1, xmm14
00007accb5bda641  jp 0x00007ACCB5BDA650
00007accb5bda643  movaps xmm13, [0x00007ACCB57FE060]
00007accb5bda64b  jmp 0x00007ACCB5BDA58D
00007accb5bda650  vxorps xmm0, xmm1, xmm14
00007accb5bda655  pextrw eax, xmm0, 0x03
00007accb5bda65a  and eax, 0x7FF8
00007accb5bda65f  cmp eax, 0x08
00007accb5bda662  jnz 0x00007ACCB5BDA58D
00007accb5bda668  movq rax, xmm14
00007accb5bda66d  shl rax, 0x0D
00007accb5bda671  jbe 0x00007ACCB5BDA58D
00007accb5bda677  vorps xmm13, xmm14, [0x00007ACCB57FE070]
00007accb5bda67f  jmp 0x00007ACCB5BDA58D
00007accb5bda684  ucomisd xmm1, xmm15
00007accb5bda689  jp 0x00007ACCB5BDA698
00007accb5bda68b  movaps xmm14, [0x00007ACCB57FE060]
00007accb5bda693  jmp 0x00007ACCB5BDA5BA
00007accb5bda698  vxorps xmm0, xmm1, xmm15
00007accb5bda69d  pextrw eax, xmm0, 0x03
00007accb5bda6a2  and eax, 0x7FF8
00007accb5bda6a7  cmp eax, 0x08
00007accb5bda6aa  jnz 0x00007ACCB5BDA5BA
00007accb5bda6b0  movq rax, xmm15
00007accb5bda6b5  shl rax, 0x0D
00007accb5bda6b9  jbe 0x00007ACCB5BDA5BA
00007accb5bda6bf  vorps xmm14, xmm15, [0x00007ACCB57FE070]
00007accb5bda6c7  jmp 0x00007ACCB5BDA5BA
00007accb5bda6cc  int3
00007accb5bda6cd  nop [rax], eax
00007accb5bda6d0  mov rax, [r15+0x40]
00007accb5bda6d4  lea r14, [rax+0x4C0]
00007accb5bda6db  movaps xmm1, [r15+0x110]
00007accb5bda6e3  movq rax, xmm1
00007accb5bda6e8  mov [r13+r14*1], rax
00007accb5bda6ed  mov rax, [r15+0xF0]
00007accb5bda6f4  mov [r15+0x100], rax
00007accb5bda6fb  jmp 0x00007ACCB5BCE5C0
00007accb5bda700  int3
00007accb5bda701  call 0x00007ACCB5AD5EB0
00007accb5bda706  jmp 0x00007ACCB5BDA6ED
00007accb5bda70b  int3
00007accb5bda70c  nop [rax], eax
00007accb5bda710  mov qword ptr [r15+0x100], 0x04
00007accb5bda71b  mov esi, 0x00
00007accb5bda720  mov edx, 0x09
00007accb5bda725  mov rdi, 0x7FFD59661160
00007accb5bda72f  mov rax, 0x59156B2A0970
00007accb5bda739  call rax
00007accb5bda73b  cmp dword ptr [r15+0x318], 0x00
00007accb5bda743  jnz 0x00007ACCB59FE110
00007accb5bda749  jmp 0x00007ACCB59FE0A0
00007accb5bda74e  int3
00007accb5bda74f  int3
