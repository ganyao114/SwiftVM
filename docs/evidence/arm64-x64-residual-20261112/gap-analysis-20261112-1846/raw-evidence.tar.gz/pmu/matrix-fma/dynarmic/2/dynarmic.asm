00007026095ce69b  nop [rax+rax*1], eax
00007026095ce6a0  vmovaps xmm1, [0x00007026091FE010]
00007026095ce6a8  movq xmm1, xmm1
00007026095ce6ac  movaps [r15+0x110], xmm1
00007026095ce6b4  vmovaps xmm1, [0x00007026091FE020]
00007026095ce6bc  movq xmm1, xmm1
00007026095ce6c0  movaps [r15+0x120], xmm1
00007026095ce6c8  mov eax, 0x420470
00007026095ce6cd  mov r14, [r13+rax*1]
00007026095ce6d2  movq xmm1, r14
00007026095ce6d7  movaps [r15+0x130], xmm1
00007026095ce6df  vmovaps xmm1, [0x00007026091FE030]
00007026095ce6e7  vpbroadcastq xmm1, xmm1
00007026095ce6ec  movaps [r15+0x140], xmm1
00007026095ce6f4  mov qword ptr [r15+0x40], 0x02
00007026095ce6fc  vmovaps xmm15, [0x00007026091FE040]
00007026095ce704  movq xmm15, xmm15
00007026095ce709  movaps [r15+0x150], xmm15
00007026095ce711  mov qword ptr [r15+0x58], 0x420000
00007026095ce719  vmovaps xmm15, [0x00007026091FE050]
00007026095ce721  vpbroadcastq xmm15, xmm15
00007026095ce726  movaps [r15+0x160], xmm15
00007026095ce72e  mov rax, [r15+0x40]
00007026095ce732  vmovq xmm14, rax
00007026095ce737  vpbroadcastq xmm14, xmm14
00007026095ce73c  movaps [r15+0x170], xmm14
00007026095ce744  mov eax, 0x420480
00007026095ce749  movups xmm13, [r13+rax*1]
00007026095ce74f  mov qword ptr [r15+0x40], 0x4304C8
00007026095ce757  mov qword ptr [r15+0x50], 0x4306D0
00007026095ce75f  vpmovqd xmm12, xmm13
00007026095ce765  pxor xmm11, xmm11
00007026095ce76a  punpcklqdq xmm12, xmm11
00007026095ce76f  movaps [r15+0x210], xmm12
00007026095ce777  movq xmm12, qword ptr [r15+0x120]
00007026095ce780  movq xmm11, qword ptr [r15+0x130]
00007026095ce789  psubd xmm12, xmm11
00007026095ce78e  movq xmm12, xmm12
00007026095ce793  paddq xmm13, xmm14
00007026095ce798  movaps [r15+0x180], xmm13
00007026095ce7a0  movq xmm14, qword ptr [r15+0x150]
00007026095ce7a9  paddd xmm11, xmm14
00007026095ce7ae  movq xmm11, xmm11
00007026095ce7b3  movq xmm11, xmm11
00007026095ce7b8  movaps [r15+0x130], xmm11
00007026095ce7c0  pmovzxdq xmm12, xmm12
00007026095ce7c6  psllq xmm12, 0x00
00007026095ce7cc  movq xmm14, qword ptr [r15+0x210]
00007026095ce7d5  movq xmm13, qword ptr [r15+0x110]
00007026095ce7de  paddd xmm14, xmm13
00007026095ce7e3  movq xmm14, xmm14
00007026095ce7e8  vcvtuqq2pd xmm12, xmm12
00007026095ce7ee  pmovzxdq xmm14, xmm14
00007026095ce7f4  psllq xmm14, 0x00
00007026095ce7fa  vcvtuqq2pd xmm14, xmm14
00007026095ce800  movaps xmm13, xmm12
00007026095ce804  mulpd xmm13, xmm1
00007026095ce809  vcmppd xmm11, xmm13, xmm13, 0x03
00007026095ce80f  ptest xmm11, xmm11
00007026095ce815  jnz 0x00007026095CE8FF
00007026095ce81b  movaps [r15+0x220], xmm13
00007026095ce823  mov eax, 0x4306D0
00007026095ce828  movups [r13+rax*1], xmm13
00007026095ce82e  movaps xmm1, xmm14
00007026095ce832  mulpd xmm1, xmm15
00007026095ce837  vcmppd xmm13, xmm1, xmm1, 0x03
00007026095ce83c  ptest xmm13, xmm13
00007026095ce842  jnz 0x00007026095CEA4C
00007026095ce848  movaps [r15+0x210], xmm1
00007026095ce850  mov eax, 0x4304C8
00007026095ce855  movups [r13+rax*1], xmm1
00007026095ce85b  mov qword ptr [r15+0x48], 0x10
00007026095ce863  xor eax, eax
00007026095ce865  mov r14d, 0x10
00007026095ce86b  mov r12d, 0x200
00007026095ce871  cmp r14, r12
00007026095ce874  cmc
00007026095ce875  lahf
00007026095ce876  seto al
00007026095ce879  mov [r15+0x108], eax
00007026095ce880  mov eax, [r15+0x108]
00007026095ce887  sahf
00007026095ce888  jnz 0x00007026095CE8BA
00007026095ce88a  cmp dword ptr [r15+0x318], 0x00
00007026095ce892  jz 0x00007026095CEFF0
00007026095ce898  nop [rax+rax*1], ax
00007026095ce8a1  nop [rax+rax*1], eax
00007026095ce8a9  mov eax, 0x4101EC
00007026095ce8ae  mov [r15+0x100], rax
00007026095ce8b5  jmp 0x00007026093FE110
00007026095ce8ba  cmp dword ptr [r15+0x318], 0x00
00007026095ce8c2  jz 0x00007026095CEBA0
00007026095ce8c8  nop [rax+rax*1], ax
00007026095ce8d1  nop [rax+rax*1], eax
00007026095ce8d9  mov eax, 0x4101AC
00007026095ce8de  mov [r15+0x100], rax
00007026095ce8e5  jmp 0x00007026093FE110
00007026095ce8ea  int3
00007026095ce8eb  call 0x000070260940DC20
00007026095ce8f0  jmp 0x00007026095CE6D2
00007026095ce8f5  call 0x000070260940C260
00007026095ce8fa  jmp 0x00007026095CE74F
00007026095ce8ff  sub rsp, 0x08
00007026095ce903  push rax
00007026095ce904  push rcx
00007026095ce905  push rdx
00007026095ce906  push rdi
00007026095ce907  push rsi
00007026095ce908  push r8
00007026095ce90a  push r9
00007026095ce90c  push r10
00007026095ce90e  push r11
00007026095ce910  sub rsp, 0xF0
00007026095ce917  vmovaps [rsp], xmm0
00007026095ce91c  vmovaps [rsp+0x10], xmm1
00007026095ce922  vmovaps [rsp+0x20], xmm2
00007026095ce928  vmovaps [rsp+0x30], xmm3
00007026095ce92e  vmovaps [rsp+0x40], xmm4
00007026095ce934  vmovaps [rsp+0x50], xmm5
00007026095ce93a  vmovaps [rsp+0x60], xmm6
00007026095ce940  vmovaps [rsp+0x70], xmm7
00007026095ce946  vmovaps [rsp+0x80], xmm8
00007026095ce94f  vmovaps [rsp+0x90], xmm9
00007026095ce958  vmovaps [rsp+0xA0], xmm10
00007026095ce961  vmovaps [rsp+0xB0], xmm11
00007026095ce96a  vmovaps [rsp+0xC0], xmm12
00007026095ce973  vmovaps [rsp+0xD0], xmm14
00007026095ce97c  vmovaps [rsp+0xE0], xmm15
00007026095ce985  sub rsp, 0x30
00007026095ce989  movaps [rsp], xmm13
00007026095ce98e  movaps [rsp+0x10], xmm12
00007026095ce994  movaps [rsp+0x20], xmm1
00007026095ce999  lea rdi, [rsp]
00007026095ce99d  mov esi, 0x00
00007026095ce9a2  mov rax, 0x58A432239530
00007026095ce9ac  call rax
00007026095ce9ae  movaps xmm13, [rsp]
00007026095ce9b3  add rsp, 0x30
00007026095ce9b7  vmovaps xmm0, [rsp]
00007026095ce9bc  vmovaps xmm1, [rsp+0x10]
00007026095ce9c2  vmovaps xmm2, [rsp+0x20]
00007026095ce9c8  vmovaps xmm3, [rsp+0x30]
00007026095ce9ce  vmovaps xmm4, [rsp+0x40]
00007026095ce9d4  vmovaps xmm5, [rsp+0x50]
00007026095ce9da  vmovaps xmm6, [rsp+0x60]
00007026095ce9e0  vmovaps xmm7, [rsp+0x70]
00007026095ce9e6  vmovaps xmm8, [rsp+0x80]
00007026095ce9ef  vmovaps xmm9, [rsp+0x90]
00007026095ce9f8  vmovaps xmm10, [rsp+0xA0]
00007026095cea01  vmovaps xmm11, [rsp+0xB0]
00007026095cea0a  vmovaps xmm12, [rsp+0xC0]
00007026095cea13  vmovaps xmm14, [rsp+0xD0]
00007026095cea1c  vmovaps xmm15, [rsp+0xE0]
00007026095cea25  add rsp, 0xF0
00007026095cea2c  pop r11
00007026095cea2e  pop r10
00007026095cea30  pop r9
00007026095cea32  pop r8
00007026095cea34  pop rsi
00007026095cea35  pop rdi
00007026095cea36  pop rdx
00007026095cea37  pop rcx
00007026095cea38  pop rax
00007026095cea39  add rsp, 0x08
00007026095cea3d  jmp 0x00007026095CE81B
00007026095cea42  call 0x000070260940C380
00007026095cea47  jmp 0x00007026095CE82E
00007026095cea4c  sub rsp, 0x08
00007026095cea50  push rax
00007026095cea51  push rcx
00007026095cea52  push rdx
00007026095cea53  push rdi
00007026095cea54  push rsi
00007026095cea55  push r8
00007026095cea57  push r9
00007026095cea59  push r10
00007026095cea5b  push r11
00007026095cea5d  sub rsp, 0xF0
00007026095cea64  vmovaps [rsp], xmm0
00007026095cea69  vmovaps [rsp+0x10], xmm2
00007026095cea6f  vmovaps [rsp+0x20], xmm3
00007026095cea75  vmovaps [rsp+0x30], xmm4
00007026095cea7b  vmovaps [rsp+0x40], xmm5
00007026095cea81  vmovaps [rsp+0x50], xmm6
00007026095cea87  vmovaps [rsp+0x60], xmm7
00007026095cea8d  vmovaps [rsp+0x70], xmm8
00007026095cea93  vmovaps [rsp+0x80], xmm9
00007026095cea9c  vmovaps [rsp+0x90], xmm10
00007026095ceaa5  vmovaps [rsp+0xA0], xmm11
00007026095ceaae  vmovaps [rsp+0xB0], xmm12
00007026095ceab7  vmovaps [rsp+0xC0], xmm13
00007026095ceac0  vmovaps [rsp+0xD0], xmm14
00007026095ceac9  vmovaps [rsp+0xE0], xmm15
00007026095cead2  sub rsp, 0x30
00007026095cead6  movaps [rsp], xmm1
00007026095ceada  movaps [rsp+0x10], xmm14
00007026095ceae0  movaps [rsp+0x20], xmm15
00007026095ceae6  lea rdi, [rsp]
00007026095ceaea  mov esi, 0x00
00007026095ceaef  mov rax, 0x58A432239530
00007026095ceaf9  call rax
00007026095ceafb  movaps xmm1, [rsp]
00007026095ceaff  add rsp, 0x30
00007026095ceb03  vmovaps xmm0, [rsp]
00007026095ceb08  vmovaps xmm2, [rsp+0x10]
00007026095ceb0e  vmovaps xmm3, [rsp+0x20]
00007026095ceb14  vmovaps xmm4, [rsp+0x30]
00007026095ceb1a  vmovaps xmm5, [rsp+0x40]
00007026095ceb20  vmovaps xmm6, [rsp+0x50]
00007026095ceb26  vmovaps xmm7, [rsp+0x60]
00007026095ceb2c  vmovaps xmm8, [rsp+0x70]
00007026095ceb32  vmovaps xmm9, [rsp+0x80]
00007026095ceb3b  vmovaps xmm10, [rsp+0x90]
00007026095ceb44  vmovaps xmm11, [rsp+0xA0]
00007026095ceb4d  vmovaps xmm12, [rsp+0xB0]
00007026095ceb56  vmovaps xmm13, [rsp+0xC0]
00007026095ceb5f  vmovaps xmm14, [rsp+0xD0]
00007026095ceb68  vmovaps xmm15, [rsp+0xE0]
00007026095ceb71  add rsp, 0xF0
00007026095ceb78  pop r11
00007026095ceb7a  pop r10
00007026095ceb7c  pop r9
00007026095ceb7e  pop r8
00007026095ceb80  pop rsi
00007026095ceb81  pop rdi
00007026095ceb82  pop rdx
00007026095ceb83  pop rcx
00007026095ceb84  pop rax
00007026095ceb85  add rsp, 0x08
00007026095ceb89  jmp 0x00007026095CE848
00007026095ceb8e  call 0x00007026093FF540
00007026095ceb93  jmp 0x00007026095CE85B
00007026095ceb98  int3
00007026095ceb99  nop [rax], eax
00007026095ceba0  movaps xmm1, [r15+0x180]
00007026095ceba8  vpmovqd xmm15, xmm1
00007026095cebae  pxor xmm14, xmm14
00007026095cebb3  punpcklqdq xmm15, xmm14
00007026095cebb8  movaps [r15+0x210], xmm15
00007026095cebc0  movq xmm15, qword ptr [r15+0x120]
00007026095cebc9  movq xmm14, qword ptr [r15+0x130]
00007026095cebd2  psubd xmm15, xmm14
00007026095cebd7  movq xmm15, xmm15
00007026095cebdc  movaps xmm13, [r15+0x170]
00007026095cebe4  paddq xmm1, xmm13
00007026095cebe9  movaps [r15+0x180], xmm1
00007026095cebf1  movq xmm1, qword ptr [r15+0x150]
00007026095cebfa  paddd xmm14, xmm1
00007026095cebff  movq xmm14, xmm14
00007026095cec04  movq xmm14, xmm14
00007026095cec09  movaps [r15+0x130], xmm14
00007026095cec11  pmovzxdq xmm15, xmm15
00007026095cec17  psllq xmm15, 0x00
00007026095cec1d  movq xmm1, qword ptr [r15+0x210]
00007026095cec26  movq xmm14, qword ptr [r15+0x110]
00007026095cec2f  paddd xmm1, xmm14
00007026095cec34  movq xmm1, xmm1
00007026095cec38  vcvtuqq2pd xmm15, xmm15
00007026095cec3e  pmovzxdq xmm1, xmm1
00007026095cec43  psllq xmm1, 0x00
00007026095cec48  vcvtuqq2pd xmm1, xmm1
00007026095cec4e  movaps xmm14, [r15+0x140]
00007026095cec56  movaps xmm13, xmm15
00007026095cec5a  mulpd xmm13, xmm14
00007026095cec5f  vcmppd xmm12, xmm13, xmm13, 0x03
00007026095cec65  ptest xmm12, xmm12
00007026095cec6b  jnz 0x00007026095CED4E
00007026095cec71  movaps [r15+0x220], xmm13
00007026095cec79  mov rax, [r15+0x48]
00007026095cec7d  mov r14, [r15+0x50]
00007026095cec81  lea r12, [r14+rax*1]
00007026095cec85  movups [r13+r12*1], xmm13
00007026095cec8b  movaps xmm15, [r15+0x160]
00007026095cec93  movaps xmm14, xmm1
00007026095cec97  mulpd xmm14, xmm15
00007026095cec9c  vcmppd xmm13, xmm14, xmm14, 0x03
00007026095ceca2  ptest xmm13, xmm13
00007026095ceca8  jnz 0x00007026095CEE9C
00007026095cecae  movaps [r15+0x210], xmm14
00007026095cecb6  mov r14, [r15+0x40]
00007026095cecba  lea r12, [r14+rax*1]
00007026095cecbe  movups [r13+r12*1], xmm14
00007026095cecc4  lea r14, [rax+0x10]
00007026095cecc8  mov [r15+0x48], r14
00007026095ceccc  xor eax, eax
00007026095cecce  mov r12d, 0x200
00007026095cecd4  cmp r14, r12
00007026095cecd7  cmc
00007026095cecd8  lahf
00007026095cecd9  seto al
00007026095cecdc  mov [r15+0x108], eax
00007026095cece3  mov eax, [r15+0x108]
00007026095cecea  sahf
00007026095ceceb  jnz 0x00007026095CED1D
00007026095ceced  cmp dword ptr [r15+0x318], 0x00
00007026095cecf5  jz 0x00007026095CEFF0
00007026095cecfb  nop [rax+rax*1], ax
00007026095ced04  nop [rax+rax*1], eax
00007026095ced0c  mov eax, 0x4101EC
00007026095ced11  mov [r15+0x100], rax
00007026095ced18  jmp 0x00007026093FE110
00007026095ced1d  cmp dword ptr [r15+0x318], 0x00
00007026095ced25  jz 0x00007026095CEBA0
00007026095ced2b  nop [rax+rax*1], ax
00007026095ced34  nop [rax+rax*1], eax
00007026095ced3c  mov eax, 0x4101AC
00007026095ced41  mov [r15+0x100], rax
00007026095ced48  jmp 0x00007026093FE110
00007026095ced4d  int3
00007026095ced4e  sub rsp, 0x08
00007026095ced52  push rax
00007026095ced53  push rcx
00007026095ced54  push rdx
00007026095ced55  push rdi
00007026095ced56  push rsi
00007026095ced57  push r8
00007026095ced59  push r9
00007026095ced5b  push r10
00007026095ced5d  push r11
00007026095ced5f  sub rsp, 0xF0
00007026095ced66  vmovaps [rsp], xmm0
00007026095ced6b  vmovaps [rsp+0x10], xmm1
00007026095ced71  vmovaps [rsp+0x20], xmm2
00007026095ced77  vmovaps [rsp+0x30], xmm3
00007026095ced7d  vmovaps [rsp+0x40], xmm4
00007026095ced83  vmovaps [rsp+0x50], xmm5
00007026095ced89  vmovaps [rsp+0x60], xmm6
00007026095ced8f  vmovaps [rsp+0x70], xmm7
00007026095ced95  vmovaps [rsp+0x80], xmm8
00007026095ced9e  vmovaps [rsp+0x90], xmm9
00007026095ceda7  vmovaps [rsp+0xA0], xmm10
00007026095cedb0  vmovaps [rsp+0xB0], xmm11
00007026095cedb9  vmovaps [rsp+0xC0], xmm12
00007026095cedc2  vmovaps [rsp+0xD0], xmm14
00007026095cedcb  vmovaps [rsp+0xE0], xmm15
00007026095cedd4  sub rsp, 0x30
00007026095cedd8  movaps [rsp], xmm13
00007026095ceddd  movaps [rsp+0x10], xmm15
00007026095cede3  movaps [rsp+0x20], xmm14
00007026095cede9  lea rdi, [rsp]
00007026095ceded  mov esi, 0x00
00007026095cedf2  mov rax, 0x58A432239530
00007026095cedfc  call rax
00007026095cedfe  movaps xmm13, [rsp]
00007026095cee03  add rsp, 0x30
00007026095cee07  vmovaps xmm0, [rsp]
00007026095cee0c  vmovaps xmm1, [rsp+0x10]
00007026095cee12  vmovaps xmm2, [rsp+0x20]
00007026095cee18  vmovaps xmm3, [rsp+0x30]
00007026095cee1e  vmovaps xmm4, [rsp+0x40]
00007026095cee24  vmovaps xmm5, [rsp+0x50]
00007026095cee2a  vmovaps xmm6, [rsp+0x60]
00007026095cee30  vmovaps xmm7, [rsp+0x70]
00007026095cee36  vmovaps xmm8, [rsp+0x80]
00007026095cee3f  vmovaps xmm9, [rsp+0x90]
00007026095cee48  vmovaps xmm10, [rsp+0xA0]
00007026095cee51  vmovaps xmm11, [rsp+0xB0]
00007026095cee5a  vmovaps xmm12, [rsp+0xC0]
00007026095cee63  vmovaps xmm14, [rsp+0xD0]
00007026095cee6c  vmovaps xmm15, [rsp+0xE0]
00007026095cee75  add rsp, 0xF0
00007026095cee7c  pop r11
00007026095cee7e  pop r10
00007026095cee80  pop r9
00007026095cee82  pop r8
00007026095cee84  pop rsi
00007026095cee85  pop rdi
00007026095cee86  pop rdx
00007026095cee87  pop rcx
00007026095cee88  pop rax
00007026095cee89  add rsp, 0x08
00007026095cee8d  jmp 0x00007026095CEC71
00007026095cee92  call 0x00007026094C2240
00007026095cee97  jmp 0x00007026095CEC8B
00007026095cee9c  sub rsp, 0x08
00007026095ceea0  push rax
00007026095ceea1  push rcx
00007026095ceea2  push rdx
00007026095ceea3  push rdi
00007026095ceea4  push rsi
00007026095ceea5  push r8
00007026095ceea7  push r9
00007026095ceea9  push r10
00007026095ceeab  push r11
00007026095ceead  sub rsp, 0xF0
00007026095ceeb4  vmovaps [rsp], xmm0
00007026095ceeb9  vmovaps [rsp+0x10], xmm1
00007026095ceebf  vmovaps [rsp+0x20], xmm2
00007026095ceec5  vmovaps [rsp+0x30], xmm3
00007026095ceecb  vmovaps [rsp+0x40], xmm4
00007026095ceed1  vmovaps [rsp+0x50], xmm5
00007026095ceed7  vmovaps [rsp+0x60], xmm6
00007026095ceedd  vmovaps [rsp+0x70], xmm7
00007026095ceee3  vmovaps [rsp+0x80], xmm8
00007026095ceeec  vmovaps [rsp+0x90], xmm9
00007026095ceef5  vmovaps [rsp+0xA0], xmm10
00007026095ceefe  vmovaps [rsp+0xB0], xmm11
00007026095cef07  vmovaps [rsp+0xC0], xmm12
00007026095cef10  vmovaps [rsp+0xD0], xmm13
00007026095cef19  vmovaps [rsp+0xE0], xmm15
00007026095cef22  sub rsp, 0x30
00007026095cef26  movaps [rsp], xmm14
00007026095cef2b  movaps [rsp+0x10], xmm1
00007026095cef30  movaps [rsp+0x20], xmm15
00007026095cef36  lea rdi, [rsp]
00007026095cef3a  mov esi, 0x00
00007026095cef3f  mov rax, 0x58A432239530
00007026095cef49  call rax
00007026095cef4b  movaps xmm14, [rsp]
00007026095cef50  add rsp, 0x30
00007026095cef54  vmovaps xmm0, [rsp]
00007026095cef59  vmovaps xmm1, [rsp+0x10]
00007026095cef5f  vmovaps xmm2, [rsp+0x20]
00007026095cef65  vmovaps xmm3, [rsp+0x30]
00007026095cef6b  vmovaps xmm4, [rsp+0x40]
00007026095cef71  vmovaps xmm5, [rsp+0x50]
00007026095cef77  vmovaps xmm6, [rsp+0x60]
00007026095cef7d  vmovaps xmm7, [rsp+0x70]
00007026095cef83  vmovaps xmm8, [rsp+0x80]
00007026095cef8c  vmovaps xmm9, [rsp+0x90]
00007026095cef95  vmovaps xmm10, [rsp+0xA0]
00007026095cef9e  vmovaps xmm11, [rsp+0xB0]
00007026095cefa7  vmovaps xmm12, [rsp+0xC0]
00007026095cefb0  vmovaps xmm13, [rsp+0xD0]
00007026095cefb9  vmovaps xmm15, [rsp+0xE0]
00007026095cefc2  add rsp, 0xF0
00007026095cefc9  pop r11
00007026095cefcb  pop r10
00007026095cefcd  pop r9
00007026095cefcf  pop r8
00007026095cefd1  pop rsi
00007026095cefd2  pop rdi
00007026095cefd3  pop rdx
00007026095cefd4  pop rcx
00007026095cefd5  pop rax
00007026095cefd6  add rsp, 0x08
00007026095cefda  jmp 0x00007026095CECAE
00007026095cefdf  call 0x00007026094C34C0
00007026095cefe4  jmp 0x00007026095CECC4
00007026095cefe9  int3
00007026095cefea  nop [rax+rax*1], ax
00007026095ceff0  mov rax, [r15+0xF8]
00007026095ceff7  lea r14, [rax-0x120]
00007026095ceffe  mov [r15+0xF8], r14
00007026095cf005  mov rax, [r15+0x50]
00007026095cf009  movups xmm1, [r13+rax*1]
00007026095cf00f  lea r12, [rax+0x10]
00007026095cf013  movups xmm15, [r13+r12*1]
00007026095cf019  mov qword ptr [r15+0x48], 0x00
00007026095cf021  lea r12, [r14+0xD0]
00007026095cf028  movq xmm14, qword ptr [r15+0x200]
00007026095cf031  movq xmm13, qword ptr [r15+0x1F0]
00007026095cf03a  movq r11, xmm14
00007026095cf03f  movq r10, xmm13
00007026095cf044  mov [r13+r12*1], r11
00007026095cf049  lea r12, [r14+0xD8]
00007026095cf050  mov [r13+r12*1], r10
00007026095cf055  lea r12, [rax+0x80]
00007026095cf05c  movups xmm14, [r13+r12*1]
00007026095cf062  lea r12, [rax+0x90]
00007026095cf069  movups xmm13, [r13+r12*1]
00007026095cf06f  lea r12, [r14+0xE0]
00007026095cf076  movq xmm12, qword ptr [r15+0x1E0]
00007026095cf07f  movq xmm11, qword ptr [r15+0x1D0]
00007026095cf088  movq r11, xmm12
00007026095cf08d  movq r10, xmm11
00007026095cf092  mov [r13+r12*1], r11
00007026095cf097  lea r12, [r14+0xE8]
00007026095cf09e  mov [r13+r12*1], r10
00007026095cf0a3  lea r12, [rax+0xC0]
00007026095cf0aa  movups xmm12, [r13+r12*1]
00007026095cf0b0  lea r12, [rax+0xD0]
00007026095cf0b7  movups xmm11, [r13+r12*1]
00007026095cf0bd  movups [r13+r14*1], xmm1
00007026095cf0c3  lea r12, [rax+0x20]
00007026095cf0c7  movups xmm1, [r13+r12*1]
00007026095cf0cd  lea r12, [rax+0x30]
00007026095cf0d1  movups xmm10, [r13+r12*1]
00007026095cf0d7  lea r12, [r14+0xF0]
00007026095cf0de  movq xmm9, qword ptr [r15+0x1C0]
00007026095cf0e7  movq xmm8, qword ptr [r15+0x1B0]
00007026095cf0f0  movq r11, xmm9
00007026095cf0f5  movq r10, xmm8
00007026095cf0fa  mov [r13+r12*1], r11
00007026095cf0ff  lea r12, [r14+0xF8]
00007026095cf106  mov [r13+r12*1], r10
00007026095cf10b  lea r12, [rax+0x40]
00007026095cf10f  movups xmm9, [r13+r12*1]
00007026095cf115  lea r12, [rax+0x50]
00007026095cf119  movups xmm8, [r13+r12*1]
00007026095cf11f  lea r12, [r14+0x100]
00007026095cf126  movq xmm7, qword ptr [r15+0x1A0]
00007026095cf12f  movq xmm6, qword ptr [r15+0x190]
00007026095cf138  movq r11, xmm7
00007026095cf13d  movq r10, xmm6
00007026095cf142  mov [r13+r12*1], r11
00007026095cf147  lea r12, [r14+0x108]
00007026095cf14e  mov [r13+r12*1], r10
00007026095cf153  lea r12, [rax+0x100]
00007026095cf15a  movups xmm7, [r13+r12*1]
00007026095cf160  lea r12, [rax+0x110]
00007026095cf167  movups xmm6, [r13+r12*1]
00007026095cf16d  lea r12, [r14+0xB0]
00007026095cf174  movups [r13+r12*1], xmm10
00007026095cf17a  lea r12, [r14+0xC0]
00007026095cf181  movups [r13+r12*1], xmm1
00007026095cf187  lea r12, [rax+0x140]
00007026095cf18e  movups xmm1, [r13+r12*1]
00007026095cf194  lea r12, [rax+0x150]
00007026095cf19b  movups xmm10, [r13+r12*1]
00007026095cf1a1  lea r12, [r14+0x110]
00007026095cf1a8  mov r11, [r15+0xE8]
00007026095cf1af  mov [r13+r12*1], r11
00007026095cf1b4  lea r12, [rax+0x180]
00007026095cf1bb  movups xmm5, [r13+r12*1]
00007026095cf1c1  lea r12, [rax+0x190]
00007026095cf1c8  movups xmm4, [r13+r12*1]
00007026095cf1ce  lea r12, [rax+0x1C0]
00007026095cf1d5  movups xmm3, [r13+r12*1]
00007026095cf1db  lea r12, [rax+0x1D0]
00007026095cf1e2  movups xmm2, [r13+r12*1]
00007026095cf1e8  lea r12, [rax+0x60]
00007026095cf1ec  vmovaps [rsp+0x10], xmm1
00007026095cf1f2  movups xmm1, [r13+r12*1]
00007026095cf1f8  lea r12, [rax+0x70]
00007026095cf1fc  vmovaps [rsp+0x20], xmm1
00007026095cf202  movups xmm1, [r13+r12*1]
00007026095cf208  lea r12, [r14+0x70]
00007026095cf20c  movups [r13+r12*1], xmm4
00007026095cf212  lea r12, [r14+0x80]
00007026095cf219  movups [r13+r12*1], xmm5
00007026095cf21f  lea r12, [rax+0xA0]
00007026095cf226  movups xmm5, [r13+r12*1]
00007026095cf22c  lea r12, [rax+0xB0]
00007026095cf233  movups xmm4, [r13+r12*1]
00007026095cf239  lea r12, [r14+0x90]
00007026095cf240  movups [r13+r12*1], xmm2
00007026095cf246  lea r12, [r14+0xA0]
00007026095cf24d  movups [r13+r12*1], xmm3
00007026095cf253  lea r12, [rax+0xE0]
00007026095cf25a  movups xmm3, [r13+r12*1]
00007026095cf260  lea r12, [rax+0xF0]
00007026095cf267  movups xmm2, [r13+r12*1]
00007026095cf26d  lea r12, [rax+0x120]
00007026095cf274  vmovaps [rsp+0x30], xmm1
00007026095cf27a  movups xmm1, [r13+r12*1]
00007026095cf280  lea r12, [rax+0x130]
00007026095cf287  vmovaps [rsp+0x40], xmm1
00007026095cf28d  movups xmm1, [r13+r12*1]
00007026095cf293  lea r12, [rax+0x160]
00007026095cf29a  vmovaps [rsp+0x50], xmm1
00007026095cf2a0  movups xmm1, [r13+r12*1]
00007026095cf2a6  lea r12, [rax+0x170]
00007026095cf2ad  vmovaps [rsp+0x60], xmm1
00007026095cf2b3  movups xmm1, [r13+r12*1]
00007026095cf2b9  lea r12, [rax+0x1A0]
00007026095cf2c0  vmovaps [rsp+0x70], xmm1
00007026095cf2c6  movups xmm1, [r13+r12*1]
00007026095cf2cc  lea r12, [rax+0x1B0]
00007026095cf2d3  vmovaps [rsp+0x80], xmm1
00007026095cf2dc  movups xmm1, [r13+r12*1]
00007026095cf2e2  lea r12, [rax+0x1E0]
00007026095cf2e9  vmovaps [rsp+0x90], xmm1
00007026095cf2f2  movups xmm1, [r13+r12*1]
00007026095cf2f8  lea r12, [rax+0x1F0]
00007026095cf2ff  vmovaps [rsp+0xA0], xmm1
00007026095cf308  movups xmm1, [r13+r12*1]
00007026095cf30e  mov qword ptr [r15+0x50], 0x4308D0
00007026095cf316  lea rax, [r14+0x50]
00007026095cf31a  vmovaps [rsp+0xB0], xmm1
00007026095cf323  vmovaps xmm1, [rsp+0x60]
00007026095cf329  movups [r13+rax*1], xmm1
00007026095cf32f  lea rax, [r14+0x60]
00007026095cf333  vmovaps xmm1, [rsp+0x10]
00007026095cf339  movups [r13+rax*1], xmm1
00007026095cf33f  lea rax, [r14+0x40]
00007026095cf343  vmovaps xmm1, [rsp+0x70]
00007026095cf349  movups [r13+rax*1], xmm1
00007026095cf34f  lea rax, [r14+0x20]
00007026095cf353  vmovaps xmm1, [rsp+0xA0]
00007026095cf35c  movups [r13+rax*1], xmm1
00007026095cf362  lea rax, [r14+0x30]
00007026095cf366  vmovaps xmm1, [rsp+0x90]
00007026095cf36f  movups [r13+rax*1], xmm1
00007026095cf375  lea rax, [r14+0x10]
00007026095cf379  vmovaps xmm1, [rsp+0xB0]
00007026095cf382  movups [r13+rax*1], xmm1
00007026095cf388  mov rax, [r15+0x40]
00007026095cf38c  vxorps xmm1, xmm1, xmm1
00007026095cf390  vpbroadcastq xmm1, xmm1
00007026095cf395  vmovaps [rsp+0x10], xmm1
00007026095cf39b  vxorps xmm1, xmm1, xmm1
00007026095cf39f  vpbroadcastq xmm1, xmm1
00007026095cf3a4  lea r12, [rax+0x30]
00007026095cf3a8  mov r11, [r13+r12*1]
00007026095cf3ad  lea r12, [rax+0x38]
00007026095cf3b1  mov r10, [r13+r12*1]
00007026095cf3b6  vmovaps [rsp+0x60], xmm1
00007026095cf3bc  movq xmm1, r11
00007026095cf3c1  vmovaps [rsp+0x70], xmm1
00007026095cf3c7  movq xmm1, r10
00007026095cf3cc  vmovaps [rsp+0x90], xmm1
00007026095cf3d5  vmovaps xmm1, [rsp+0x70]
00007026095cf3db  movq xmm1, xmm1
00007026095cf3df  vmovaps [rsp+0x70], xmm1
00007026095cf3e5  vmovaps xmm1, [rsp+0x90]
00007026095cf3ee  movq xmm1, xmm1
00007026095cf3f2  vmovaps [rsp+0x90], xmm1
00007026095cf3fb  movq xmm1, xmm1
00007026095cf3ff  movaps [r15+0x270], xmm1
00007026095cf407  vmovaps [rsp+0xA0], xmm7
00007026095cf410  vmovaps xmm1, [rsp+0xA0]
00007026095cf419  por xmm7, xmm1
00007026095cf41d  lea r12, [rax+0x20]
00007026095cf421  mov r11, [r13+r12*1]
00007026095cf426  lea r12, [rax+0x28]
00007026095cf42a  mov r10, [r13+r12*1]
00007026095cf42f  movq xmm1, r11
00007026095cf434  vmovaps [rsp+0xA0], xmm1
00007026095cf43d  movq xmm1, r10
00007026095cf442  vmovaps [rsp+0xB0], xmm1
00007026095cf44b  vmovaps xmm1, [rsp+0xA0]
00007026095cf454  movq xmm1, xmm1
00007026095cf458  vmovaps [rsp+0xA0], xmm1
00007026095cf461  vmovaps xmm1, [rsp+0xB0]
00007026095cf46a  movq xmm1, xmm1
00007026095cf46e  vmovaps [rsp+0xB0], xmm2
00007026095cf477  vmovaps [rsp+0xC0], xmm1
00007026095cf480  vmovaps xmm1, [rsp+0xB0]
00007026095cf489  por xmm2, xmm1
00007026095cf48d  vmovaps xmm1, [rsp+0x40]
00007026095cf493  vmovaps [rsp+0xB0], xmm15
00007026095cf49c  vmovaps xmm15, [rsp+0x40]
00007026095cf4a2  por xmm1, xmm15
00007026095cf4a7  vmovaps [rsp+0x40], xmm3
00007026095cf4ad  vmovaps xmm15, [rsp+0x40]
00007026095cf4b3  por xmm3, xmm15
00007026095cf4b8  vmovaps [rsp+0x40], xmm10
00007026095cf4be  vmovaps xmm15, [rsp+0x40]
00007026095cf4c4  por xmm10, xmm15
00007026095cf4c9  vmovaps [rsp+0x40], xmm12
00007026095cf4cf  vmovaps xmm15, [rsp+0x40]
00007026095cf4d5  por xmm12, xmm15
00007026095cf4da  lea r12, [rax+0x10]
00007026095cf4de  mov r11, [r13+r12*1]
00007026095cf4e3  lea r12, [rax+0x18]
00007026095cf4e7  mov r10, [r13+r12*1]
00007026095cf4ec  movq xmm15, r11
00007026095cf4f1  vmovaps [rsp+0x40], xmm1
00007026095cf4f7  movq xmm1, r10
00007026095cf4fc  movq xmm15, xmm15
00007026095cf501  movq xmm1, xmm1
00007026095cf505  vmovaps [rsp+0xD0], xmm1
00007026095cf50e  vmovaps xmm1, [rsp+0x80]
00007026095cf517  vmovaps [rsp+0xE0], xmm15
00007026095cf520  vmovaps xmm15, [rsp+0x80]
00007026095cf529  por xmm1, xmm15
00007026095cf52e  vmovaps xmm15, [rsp+0x30]
00007026095cf534  vmovaps [rsp+0x80], xmm1
00007026095cf53d  vmovaps xmm1, [rsp+0x30]
00007026095cf543  por xmm15, xmm1
00007026095cf548  vmovaps xmm1, [rsp+0x20]
00007026095cf54e  vmovaps [rsp+0x30], xmm15
00007026095cf554  vmovaps xmm15, [rsp+0x20]
00007026095cf55a  por xmm1, xmm15
00007026095cf55f  vmovaps [rsp+0x20], xmm6
00007026095cf565  vmovaps xmm15, [rsp+0x20]
00007026095cf56b  por xmm6, xmm15
00007026095cf570  vmovaps [rsp+0x20], xmm13
00007026095cf576  vmovaps xmm15, [rsp+0x20]
00007026095cf57c  por xmm13, xmm15
00007026095cf581  vmovaps [rsp+0x20], xmm8
00007026095cf587  vmovaps xmm15, [rsp+0x20]
00007026095cf58d  por xmm8, xmm15
00007026095cf592  vmovaps [rsp+0x20], xmm9
00007026095cf598  vmovaps xmm15, [rsp+0x20]
00007026095cf59e  por xmm9, xmm15
00007026095cf5a3  mov r12, [r13+rax*1]
00007026095cf5a8  vmovq xmm15, r12
00007026095cf5ad  vpbroadcastq xmm15, xmm15
00007026095cf5b2  vmovaps [rsp+0x20], xmm1
00007026095cf5b8  vxorps xmm1, xmm1, xmm1
00007026095cf5bc  vpbroadcastq xmm1, xmm1
00007026095cf5c1  vmovaps [rsp+0xF0], xmm1
00007026095cf5ca  movups xmm1, [r13+r14*1]
00007026095cf5d0  vmovaps [rsp+0x100], xmm1
00007026095cf5d9  vxorps xmm1, xmm1, xmm1
00007026095cf5dd  vpbroadcastq xmm1, xmm1
00007026095cf5e2  lea r12, [rax+0x08]
00007026095cf5e6  mov rax, [r13+r12*1]
00007026095cf5eb  vmovaps [rsp+0x110], xmm1
00007026095cf5f4  movq xmm1, rax
00007026095cf5f9  movaps [r15+0x240], xmm1
00007026095cf601  mov qword ptr [r15+0x60], 0x4308D0
00007026095cf609  mov qword ptr [r15+0x58], 0x40
00007026095cf611  vmovaps xmm1, [rsp+0x10]
00007026095cf617  vmovaps [rsp+0x10], xmm15
00007026095cf61d  vmovaps xmm15, [rsp+0x100]
00007026095cf626  vmovaps [rsp+0x100], xmm14
00007026095cf62f  vmovaps xmm14, [rsp+0x10]
00007026095cf635  vmovaps [rsp+0x10], xmm13
00007026095cf63b  vmovaps [rsp+0x120], xmm12
00007026095cf644  movaps xmm13, xmm1
00007026095cf648  vfmadd231pd xmm13, xmm15, xmm14
00007026095cf64d  vcmppd xmm12, xmm13, xmm13, 0x03
00007026095cf653  vptest xmm12, xmm12
00007026095cf658  jnz 0x00007026095D0283
00007026095cf65e  vmovaps xmm1, [rsp+0x60]
00007026095cf664  vmovaps xmm15, [rsp+0xB0]
00007026095cf66d  vmovaps [rsp+0x60], xmm13
00007026095cf673  movaps xmm12, xmm1
00007026095cf677  vfmadd231pd xmm12, xmm15, xmm14
00007026095cf67c  vcmppd xmm13, xmm12, xmm12, 0x03
00007026095cf682  vptest xmm13, xmm13
00007026095cf687  jnz 0x00007026095D03DC
00007026095cf68d  vmovaps xmm1, [rsp+0x50]
00007026095cf693  vmovaps xmm13, [rsp+0x50]
00007026095cf699  por xmm1, xmm13
00007026095cf69e  vmovaps [rsp+0x50], xmm4
00007026095cf6a4  vmovaps xmm13, [rsp+0x50]
00007026095cf6aa  por xmm4, xmm13
00007026095cf6af  vmovaps [rsp+0x50], xmm5
00007026095cf6b5  vmovaps xmm13, [rsp+0x50]
00007026095cf6bb  por xmm5, xmm13
00007026095cf6c0  vmovaps [rsp+0x50], xmm11
00007026095cf6c6  vmovaps xmm13, [rsp+0x50]
00007026095cf6cc  por xmm11, xmm13
00007026095cf6d1  vmovaps xmm13, [rsp+0x100]
00007026095cf6da  vmovaps [rsp+0x50], xmm1
00007026095cf6e0  vmovaps xmm1, [rsp+0x100]
00007026095cf6e9  por xmm13, xmm1
00007026095cf6ee  vmovaps [rsp+0xB0], xmm15
00007026095cf6f7  vmovaps xmm1, [rsp+0xB0]
00007026095cf700  por xmm15, xmm1
00007026095cf705  lea rax, [r14+0xC0]
00007026095cf70c  movups xmm1, [r13+rax*1]
00007026095cf712  xor eax, eax
00007026095cf714  mov r12d, 0x40
00007026095cf71a  mov r11d, 0x200
00007026095cf720  cmp r12, r11
00007026095cf723  cmc
00007026095cf724  lahf
00007026095cf725  seto al
00007026095cf728  mov [r15+0x108], eax
00007026095cf72f  vmovaps [rsp+0xB0], xmm1
00007026095cf738  vmovaps xmm1, [rsp+0xF0]
00007026095cf741  vmovaps [rsp+0xF0], xmm15
00007026095cf74a  vmovaps xmm15, [rsp+0xB0]
00007026095cf753  vmovaps [rsp+0xB0], xmm13
00007026095cf75c  vmovaps [rsp+0x100], xmm12
00007026095cf765  movaps xmm13, xmm1
00007026095cf769  vfmadd231pd xmm13, xmm15, xmm14
00007026095cf76e  vcmppd xmm12, xmm13, xmm13, 0x03
00007026095cf774  vptest xmm12, xmm12
00007026095cf779  jnz 0x00007026095D053F
00007026095cf77f  lea rax, [r14+0xB0]
00007026095cf786  movups xmm1, [r13+rax*1]
00007026095cf78c  vmovaps xmm15, [rsp+0x110]
00007026095cf795  vmovaps [rsp+0x110], xmm13
00007026095cf79e  movaps xmm12, xmm15
00007026095cf7a2  vfmadd231pd xmm12, xmm1, xmm14
00007026095cf7a7  vcmppd xmm13, xmm12, xmm12, 0x03
00007026095cf7ad  vptest xmm13, xmm13
00007026095cf7b2  jnz 0x00007026095D06A2
00007026095cf7b8  vmovaps [rsp+0x130], xmm9
00007026095cf7c1  vmovaps xmm1, [rsp+0x130]
00007026095cf7ca  por xmm9, xmm1
00007026095cf7cf  movaps [r15+0x210], xmm9
00007026095cf7d7  vmovaps [rsp+0x130], xmm8
00007026095cf7e0  vmovaps xmm1, [rsp+0x130]
00007026095cf7e9  por xmm8, xmm1
00007026095cf7ee  movaps [r15+0x1C0], xmm8
00007026095cf7f6  vmovaps xmm1, [rsp+0x10]
00007026095cf7fc  vmovaps xmm15, [rsp+0x10]
00007026095cf802  por xmm1, xmm15
00007026095cf807  movaps [r15+0x280], xmm1
00007026095cf80f  vmovaps [rsp+0x10], xmm6
00007026095cf815  vmovaps xmm14, [rsp+0x10]
00007026095cf81b  por xmm6, xmm14
00007026095cf820  movaps [r15+0x2A0], xmm6
00007026095cf828  vmovaps xmm15, [rsp+0x20]
00007026095cf82e  vmovaps xmm14, [rsp+0x20]
00007026095cf834  por xmm15, xmm14
00007026095cf839  movaps [r15+0x2E0], xmm15
00007026095cf841  vmovaps xmm14, [rsp+0x30]
00007026095cf847  vmovaps xmm13, [rsp+0x30]
00007026095cf84d  por xmm14, xmm13
00007026095cf852  movaps [r15+0x1F0], xmm14
00007026095cf85a  vmovaps xmm13, [rsp+0xF0]
00007026095cf863  vmovaps [rsp+0x10], xmm1
00007026095cf869  vmovaps xmm1, [rsp+0xF0]
00007026095cf872  por xmm13, xmm1
00007026095cf877  movaps [r15+0x250], xmm13
00007026095cf87f  vmovaps xmm1, [rsp+0xB0]
00007026095cf888  vmovaps xmm13, [rsp+0xB0]
00007026095cf891  por xmm1, xmm13
00007026095cf896  movaps [r15+0x260], xmm1
00007026095cf89e  vmovaps [rsp+0x20], xmm11
00007026095cf8a4  vmovaps xmm13, [rsp+0x20]
00007026095cf8aa  por xmm11, xmm13
00007026095cf8af  movaps [r15+0x290], xmm11
00007026095cf8b7  vmovaps [rsp+0x20], xmm5
00007026095cf8bd  vmovaps xmm13, [rsp+0x20]
00007026095cf8c3  por xmm5, xmm13
00007026095cf8c8  movaps [r15+0x2C0], xmm5
00007026095cf8d0  movq xmm13, qword ptr [r15+0x240]
00007026095cf8d9  vmovaps [rsp+0x20], xmm13
00007026095cf8df  vpermilpd xmm13, xmm13, 0x00
00007026095cf8e5  vmovaps [rsp+0x30], xmm1
00007026095cf8eb  vmovaps xmm1, [rsp+0x60]
00007026095cf8f1  vmovaps [rsp+0x60], xmm15
00007026095cf8f7  vmovaps [rsp+0xB0], xmm14
00007026095cf900  movaps xmm15, xmm1
00007026095cf904  vfmadd231pd xmm15, xmm9, xmm13
00007026095cf909  vcmppd xmm14, xmm15, xmm15, 0x03
00007026095cf90f  vptest xmm14, xmm14
00007026095cf914  jnz 0x00007026095D07FB
00007026095cf91a  vmovaps xmm1, [rsp+0x20]
00007026095cf920  vpermilpd xmm1, xmm1, 0x00
00007026095cf926  vmovaps xmm14, [rsp+0x110]
00007026095cf92f  vmovaps xmm13, [rsp+0x60]
00007026095cf935  vmovaps [rsp+0x60], xmm15
00007026095cf93b  movaps xmm9, xmm14
00007026095cf93f  vfmadd231pd xmm9, xmm13, xmm1
00007026095cf944  vcmppd xmm15, xmm9, xmm9, 0x03
00007026095cf94a  vptest xmm15, xmm15
00007026095cf94f  jnz 0x00007026095D0954
00007026095cf955  vmovaps xmm1, [rsp+0x20]
00007026095cf95b  vpermilpd xmm1, xmm1, 0x00
00007026095cf961  vmovaps xmm15, [rsp+0x100]
00007026095cf96a  movaps xmm14, xmm15
00007026095cf96e  vfmadd231pd xmm14, xmm8, xmm1
00007026095cf973  vcmppd xmm13, xmm14, xmm14, 0x03
00007026095cf979  vptest xmm13, xmm13
00007026095cf97e  jnz 0x00007026095D0AAD
00007026095cf984  vmovaps [rsp+0xF0], xmm4
00007026095cf98d  vmovaps xmm1, [rsp+0xF0]
00007026095cf996  por xmm4, xmm1
00007026095cf99a  movaps [r15+0x1D0], xmm4
00007026095cf9a2  vmovaps xmm1, [rsp+0x20]
00007026095cf9a8  vpermilpd xmm1, xmm1, 0x00
00007026095cf9ae  vmovaps xmm13, [rsp+0xB0]
00007026095cf9b7  movaps xmm15, xmm12
00007026095cf9bb  vfmadd231pd xmm15, xmm13, xmm1
00007026095cf9c0  vcmppd xmm8, xmm15, xmm15, 0x03
00007026095cf9c6  vptest xmm8, xmm8
00007026095cf9cb  jnz 0x00007026095D0C06
00007026095cf9d1  vmovaps xmm1, [rsp+0x80]
00007026095cf9da  vmovaps xmm13, [rsp+0x80]
00007026095cf9e3  por xmm1, xmm13
00007026095cf9e8  movaps [r15+0x200], xmm1
00007026095cf9f0  vmovaps xmm13, [rsp+0x50]
00007026095cf9f6  vmovaps xmm12, [rsp+0x50]
00007026095cf9fc  por xmm13, xmm12
00007026095cfa01  movaps [r15+0x1E0], xmm13
00007026095cfa09  vmovaps [rsp+0x20], xmm10
00007026095cfa0f  vmovaps xmm13, [rsp+0x20]
00007026095cfa15  por xmm10, xmm13
00007026095cfa1a  movaps [r15+0x2B0], xmm10
00007026095cfa22  vmovaps [rsp+0x20], xmm3
00007026095cfa28  vmovaps xmm13, [rsp+0x20]
00007026095cfa2e  por xmm3, xmm13
00007026095cfa33  movaps [r15+0x300], xmm3
00007026095cfa3b  vmovaps xmm8, [rsp+0xE0]
00007026095cfa44  vpermilpd xmm8, xmm8, 0x00
00007026095cfa4a  vmovaps xmm3, [rsp+0x60]
00007026095cfa50  vmovaps [rsp+0x20], xmm1
00007026095cfa56  vmovaps xmm1, [rsp+0x30]
00007026095cfa5c  vmovaps [rsp+0x30], xmm15
00007026095cfa62  vmovaps [rsp+0x50], xmm14
00007026095cfa68  movaps xmm15, xmm3
00007026095cfa6c  vfmadd231pd xmm15, xmm1, xmm8
00007026095cfa71  vcmppd xmm14, xmm15, xmm15, 0x03
00007026095cfa77  vptest xmm14, xmm14
00007026095cfa7c  jnz 0x00007026095D0D5F
00007026095cfa82  vmovaps xmm1, [rsp+0xE0]
00007026095cfa8b  vpermilpd xmm1, xmm1, 0x00
00007026095cfa91  movaps xmm8, xmm9
00007026095cfa95  vfmadd231pd xmm8, xmm5, xmm1
00007026095cfa9a  vcmppd xmm14, xmm8, xmm8, 0x03
00007026095cfaa0  vptest xmm14, xmm14
00007026095cfaa5  jnz 0x00007026095D0EB7
00007026095cfaab  vmovaps xmm1, [rsp+0xE0]
00007026095cfab4  vpermilpd xmm1, xmm1, 0x00
00007026095cfaba  vmovaps xmm14, [rsp+0x50]
00007026095cfac0  vmovaps xmm9, [rsp+0x10]
00007026095cfac6  movaps xmm5, xmm14
00007026095cfaca  vfmadd231pd xmm5, xmm9, xmm1
00007026095cfacf  vcmppd xmm3, xmm5, xmm5, 0x03
00007026095cfad4  vptest xmm3, xmm3
00007026095cfad9  jnz 0x00007026095D100F
00007026095cfadf  vmovaps xmm1, [rsp+0xE0]
00007026095cfae8  vpermilpd xmm1, xmm1, 0x00
00007026095cfaee  vmovaps xmm14, [rsp+0x30]
00007026095cfaf4  movaps xmm9, xmm14
00007026095cfaf8  vfmadd231pd xmm9, xmm4, xmm1
00007026095cfafd  vcmppd xmm3, xmm9, xmm9, 0x03
00007026095cfb03  vptest xmm3, xmm3
00007026095cfb08  jnz 0x00007026095D1166
00007026095cfb0e  vmovaps xmm1, [rsp+0x120]
00007026095cfb17  vmovaps xmm14, [rsp+0x120]
00007026095cfb20  por xmm1, xmm14
00007026095cfb25  movaps [r15+0x180], xmm1
00007026095cfb2d  vmovaps xmm14, [rsp+0x40]
00007026095cfb33  vmovaps xmm4, [rsp+0x40]
00007026095cfb39  por xmm14, xmm4
00007026095cfb3e  movaps [r15+0x2D0], xmm14
00007026095cfb46  vmovaps [rsp+0x10], xmm2
00007026095cfb4c  vmovaps xmm4, [rsp+0x10]
00007026095cfb52  por xmm2, xmm4
00007026095cfb56  movaps [r15+0x2F0], xmm2
00007026095cfb5e  vmovaps xmm3, [rsp+0xD0]
00007026095cfb67  vpermilpd xmm3, xmm3, 0x00
00007026095cfb6d  vmovaps [rsp+0x10], xmm1
00007026095cfb73  movaps xmm2, xmm8
00007026095cfb77  vfmadd231pd xmm2, xmm13, xmm3
00007026095cfb7c  vcmppd xmm1, xmm2, xmm2, 0x03
00007026095cfb81  vptest xmm1, xmm1
00007026095cfb86  jnz 0x00007026095D12BE
00007026095cfb8c  vmovaps xmm1, [rsp+0xD0]
00007026095cfb95  vpermilpd xmm1, xmm1, 0x00
00007026095cfb9b  vmovaps xmm13, [rsp+0x10]
00007026095cfba1  movaps xmm8, xmm15
00007026095cfba5  vfmadd231pd xmm8, xmm13, xmm1
00007026095cfbaa  vcmppd xmm3, xmm8, xmm8, 0x03
00007026095cfbb0  vptest xmm3, xmm3
00007026095cfbb5  jnz 0x00007026095D1415
00007026095cfbbb  lea rax, [r14+0x80]
00007026095cfbc2  movups xmm1, [r13+rax*1]
00007026095cfbc8  movaps [r15+0x190], xmm1
00007026095cfbd0  vmovaps xmm15, [rsp+0xD0]
00007026095cfbd9  vpermilpd xmm15, xmm15, 0x00
00007026095cfbdf  movaps xmm13, xmm5
00007026095cfbe3  vfmadd231pd xmm13, xmm11, xmm15
00007026095cfbe8  vcmppd xmm3, xmm13, xmm13, 0x03
00007026095cfbee  vptest xmm3, xmm3
00007026095cfbf3  jnz 0x00007026095D1578
00007026095cfbf9  vmovaps xmm15, [rsp+0xD0]
00007026095cfc02  vpermilpd xmm15, xmm15, 0x00
00007026095cfc08  movaps xmm11, xmm9
00007026095cfc0c  vfmadd231pd xmm11, xmm4, xmm15
00007026095cfc11  vcmppd xmm5, xmm11, xmm11, 0x03
00007026095cfc17  vptest xmm5, xmm5
00007026095cfc1c  jnz 0x00007026095D16D1
00007026095cfc22  vmovaps [rsp+0x10], xmm7
00007026095cfc28  vmovaps xmm9, [rsp+0x10]
00007026095cfc2e  por xmm7, xmm9
00007026095cfc33  movaps [r15+0x160], xmm7
00007026095cfc3b  lea rax, [r14+0x40]
00007026095cfc3f  movups xmm15, [r13+rax*1]
00007026095cfc45  lea rax, [r14+0x50]
00007026095cfc49  movups xmm9, [r13+rax*1]
00007026095cfc4f  movaps [r15+0x1B0], xmm15
00007026095cfc57  movaps [r15+0x1A0], xmm9
00007026095cfc5f  vmovaps xmm5, [rsp+0xA0]
00007026095cfc68  vpermilpd xmm5, xmm5, 0x00
00007026095cfc6e  movaps xmm4, xmm2
00007026095cfc71  vfmadd231pd xmm4, xmm14, xmm5
00007026095cfc76  vcmppd xmm3, xmm4, xmm4, 0x03
00007026095cfc7b  vptest xmm3, xmm3
00007026095cfc80  jnz 0x00007026095D183E
00007026095cfc86  vmovaps xmm14, [rsp+0xA0]
00007026095cfc8f  vpermilpd xmm14, xmm14, 0x00
00007026095cfc95  movaps xmm5, xmm8
00007026095cfc99  vfmadd231pd xmm5, xmm7, xmm14
00007026095cfc9e  vcmppd xmm3, xmm5, xmm5, 0x03
00007026095cfca3  vptest xmm3, xmm3
00007026095cfca8  jnz 0x00007026095D1994
00007026095cfcae  vmovaps xmm14, [rsp+0xA0]
00007026095cfcb7  vpermilpd xmm14, xmm14, 0x00
00007026095cfcbd  movaps xmm8, xmm13
00007026095cfcc1  vfmadd231pd xmm8, xmm6, xmm14
00007026095cfcc6  vcmppd xmm7, xmm8, xmm8, 0x03
00007026095cfccc  vptest xmm7, xmm7
00007026095cfcd1  jnz 0x00007026095D1AEB
00007026095cfcd7  vmovaps xmm14, [rsp+0xA0]
00007026095cfce0  vpermilpd xmm14, xmm14, 0x00
00007026095cfce6  movaps xmm13, xmm11
00007026095cfcea  vfmadd231pd xmm13, xmm12, xmm14
00007026095cfcef  vcmppd xmm7, xmm13, xmm13, 0x03
00007026095cfcf5  vptest xmm7, xmm7
00007026095cfcfa  jnz 0x00007026095D1C44
00007026095cfd00  lea rax, [r14+0x60]
00007026095cfd04  movups xmm14, [r13+rax*1]
00007026095cfd0a  lea rax, [r14+0x70]
00007026095cfd0e  movups xmm12, [r13+rax*1]
00007026095cfd14  movaps [r15+0x150], xmm14
00007026095cfd1c  movaps [r15+0x120], xmm12
00007026095cfd24  vmovaps xmm11, [rsp+0xC0]
00007026095cfd2d  vpermilpd xmm11, xmm11, 0x00
00007026095cfd33  movaps xmm7, xmm4
00007026095cfd36  vfmadd231pd xmm7, xmm9, xmm11
00007026095cfd3b  vcmppd xmm6, xmm7, xmm7, 0x03
00007026095cfd40  vptest xmm6, xmm6
00007026095cfd45  jnz 0x00007026095D1DB2
00007026095cfd4b  vmovaps xmm11, [rsp+0xC0]
00007026095cfd54  vpermilpd xmm11, xmm11, 0x00
00007026095cfd5a  movaps xmm9, xmm5
00007026095cfd5e  vfmadd231pd xmm9, xmm14, xmm11
00007026095cfd63  vcmppd xmm6, xmm9, xmm9, 0x03
00007026095cfd69  vptest xmm6, xmm6
00007026095cfd6e  jnz 0x00007026095D1F09
00007026095cfd74  vmovaps xmm14, [rsp+0xC0]
00007026095cfd7d  vpermilpd xmm14, xmm14, 0x00
00007026095cfd83  movaps xmm11, xmm8
00007026095cfd87  vfmadd231pd xmm11, xmm10, xmm14
00007026095cfd8c  vcmppd xmm6, xmm11, xmm11, 0x03
00007026095cfd92  vptest xmm6, xmm6
00007026095cfd97  jnz 0x00007026095D2062
00007026095cfd9d  vmovaps xmm14, [rsp+0xC0]
00007026095cfda6  vpermilpd xmm14, xmm14, 0x00
00007026095cfdac  movaps xmm10, xmm13
00007026095cfdb0  vfmadd231pd xmm10, xmm15, xmm14
00007026095cfdb5  vcmppd xmm8, xmm10, xmm10, 0x03
00007026095cfdbb  vptest xmm8, xmm8
00007026095cfdc0  jnz 0x00007026095D21BC
00007026095cfdc6  lea rax, [r14+0x20]
00007026095cfdca  movups xmm15, [r13+rax*1]
00007026095cfdd0  lea rax, [r14+0x30]
00007026095cfdd4  movups xmm14, [r13+rax*1]
00007026095cfdda  vmovaps xmm13, [rsp+0x70]
00007026095cfde0  vpermilpd xmm13, xmm13, 0x00
00007026095cfde6  vmovaps xmm8, [rsp+0x20]
00007026095cfdec  movaps xmm6, xmm7
00007026095cfdef  vfmadd231pd xmm6, xmm8, xmm13
00007026095cfdf4  vcmppd xmm5, xmm6, xmm6, 0x03
00007026095cfdf9  vptest xmm5, xmm5
00007026095cfdfe  jnz 0x00007026095D232A
00007026095cfe04  vmovaps xmm13, [rsp+0x70]
00007026095cfe0a  vpermilpd xmm13, xmm13, 0x00
00007026095cfe10  movaps xmm8, xmm9
00007026095cfe14  vfmadd231pd xmm8, xmm1, xmm13
00007026095cfe19  vcmppd xmm7, xmm8, xmm8, 0x03
00007026095cfe1f  vptest xmm7, xmm7
00007026095cfe24  jnz 0x00007026095D2481
00007026095cfe2a  vmovaps xmm1, [rsp+0x70]
00007026095cfe30  vpermilpd xmm1, xmm1, 0x00
00007026095cfe36  movaps xmm13, xmm11
00007026095cfe3a  vfmadd231pd xmm13, xmm12, xmm1
00007026095cfe3f  vcmppd xmm9, xmm13, xmm13, 0x03
00007026095cfe45  vptest xmm9, xmm9
00007026095cfe4a  jnz 0x00007026095D25DA
00007026095cfe50  vmovaps xmm1, [rsp+0x70]
00007026095cfe56  vpermilpd xmm1, xmm1, 0x00
00007026095cfe5c  movaps xmm12, xmm10
00007026095cfe60  vfmadd231pd xmm12, xmm14, xmm1
00007026095cfe65  vcmppd xmm11, xmm12, xmm12, 0x03
00007026095cfe6b  vptest xmm11, xmm11
00007026095cfe70  jnz 0x00007026095D2733
00007026095cfe76  lea rax, [r14+0x90]
00007026095cfe7d  movups xmm1, [r13+rax*1]
00007026095cfe83  lea rax, [r14+0xA0]
00007026095cfe8a  movups xmm14, [r13+rax*1]
00007026095cfe90  movaps [r15+0x140], xmm1
00007026095cfe98  movaps [r15+0x130], xmm14
00007026095cfea0  vmovaps xmm11, [rsp+0x90]
00007026095cfea9  vpermilpd xmm11, xmm11, 0x00
00007026095cfeaf  movaps xmm10, xmm6
00007026095cfeb3  vfmadd231pd xmm10, xmm15, xmm11
00007026095cfeb8  vcmppd xmm9, xmm10, xmm10, 0x03
00007026095cfebe  vptest xmm9, xmm9
00007026095cfec3  jnz 0x00007026095D28A0
00007026095cfec9  movaps [r15+0x220], xmm10
00007026095cfed1  lea rax, [r14+0x10]
00007026095cfed5  movups xmm15, [r13+rax*1]
00007026095cfedb  movaps [r15+0x240], xmm15
00007026095cfee3  vmovaps xmm11, [rsp+0x90]
00007026095cfeec  vpermilpd xmm11, xmm11, 0x00
00007026095cfef2  movaps xmm9, xmm8
00007026095cfef6  vfmadd231pd xmm9, xmm14, xmm11
00007026095cfefb  vcmppd xmm7, xmm9, xmm9, 0x03
00007026095cff01  vptest xmm7, xmm7
00007026095cff06  jnz 0x00007026095D2A03
00007026095cff0c  movaps [r15+0x110], xmm9
00007026095cff14  vmovaps xmm14, [rsp+0x90]
00007026095cff1d  vpermilpd xmm14, xmm14, 0x00
00007026095cff23  movaps xmm11, xmm13
00007026095cff27  vfmadd231pd xmm11, xmm1, xmm14
00007026095cff2c  vcmppd xmm8, xmm11, xmm11, 0x03
00007026095cff32  vptest xmm8, xmm8
00007026095cff37  jnz 0x00007026095D2B5D
00007026095cff3d  movaps [r15+0x170], xmm11
00007026095cff45  vmovaps xmm1, [rsp+0x90]
00007026095cff4e  vpermilpd xmm1, xmm1, 0x00
00007026095cff54  movaps xmm14, xmm12
00007026095cff58  vfmadd231pd xmm14, xmm15, xmm1
00007026095cff5d  vcmppd xmm13, xmm14, xmm14, 0x03
00007026095cff63  vptest xmm13, xmm13
00007026095cff68  jnz 0x00007026095D2CB6
00007026095cff6e  movaps [r15+0x230], xmm14
00007026095cff76  mov eax, 0x4308D0
00007026095cff7b  movups [r13+rax*1], xmm9
00007026095cff81  mov eax, 0x4308E0
00007026095cff86  movups [r13+rax*1], xmm11
00007026095cff8c  mov eax, 0x4308F0
00007026095cff91  movups [r13+rax*1], xmm10
00007026095cff97  mov eax, 0x430900
00007026095cff9c  movups [r13+rax*1], xmm14
00007026095cffa2  mov eax, [r15+0x108]
00007026095cffa9  sahf
00007026095cffaa  jnz 0x00007026095CFFDC
00007026095cffac  cmp dword ptr [r15+0x318], 0x00
00007026095cffb4  jz 0x00007026095D67A0
00007026095cffba  nop [rax+rax*1], ax
00007026095cffc3  nop [rax+rax*1], eax
00007026095cffcb  mov eax, 0x4103F0
00007026095cffd0  mov [r15+0x100], rax
00007026095cffd7  jmp 0x00007026093FE110
00007026095cffdc  cmp dword ptr [r15+0x318], 0x00
00007026095cffe4  jz 0x00007026095D2E40
00007026095cffea  nop [rax+rax*1], ax
00007026095cfff3  nop [rax+rax*1], eax
00007026095cfffb  mov eax, 0x410274
00007026095d0000  mov [r15+0x100], rax
00007026095d0007  jmp 0x00007026093FE110
00007026095d000c  int3
00007026095d000d  call 0x00007026093FF430
00007026095d0012  jmp 0x00007026095CF00F
00007026095d0017  call 0x00007026094C4620
00007026095d001c  jmp 0x00007026095CF019
00007026095d0021  call 0x00007026094C0860
00007026095d0026  jmp 0x00007026095CF049
00007026095d002b  call 0x00007026094BF5F0
00007026095d0030  jmp 0x00007026095CF055
00007026095d0035  call 0x00007026094C33A0
00007026095d003a  jmp 0x00007026095CF062
00007026095d003f  call 0x00007026094C2120
00007026095d0044  jmp 0x00007026095CF06F
00007026095d0049  call 0x00007026094C0860
00007026095d004e  jmp 0x00007026095CF097
00007026095d0053  call 0x00007026094BF5F0
00007026095d0058  jmp 0x00007026095CF0A3
00007026095d005d  call 0x00007026094C0EA0
00007026095d0062  jmp 0x00007026095CF0B0
00007026095d0067  call 0x00007026094BFC30
00007026095d006c  jmp 0x00007026095CF0BD
00007026095d0071  call 0x00007026094D6600
00007026095d0076  jmp 0x00007026095CF0C3
00007026095d007b  call 0x00007026094B52F0
00007026095d0080  jmp 0x00007026095CF0CD
00007026095d0085  call 0x00007026094BE9C0
00007026095d008a  jmp 0x00007026095CF0D7
00007026095d008f  call 0x00007026094C0860
00007026095d0094  jmp 0x00007026095CF0FF
00007026095d0099  call 0x00007026094BF5F0
00007026095d009e  jmp 0x00007026095CF10B
00007026095d00a3  call 0x00007026094BD750
00007026095d00a8  jmp 0x00007026095CF115
00007026095d00ad  call 0x00007026094BC4E0
00007026095d00b2  jmp 0x00007026095CF11F
00007026095d00b7  call 0x00007026094C0860
00007026095d00bc  jmp 0x00007026095CF147
00007026095d00c1  call 0x00007026094BF5F0
00007026095d00c6  jmp 0x00007026095CF153
00007026095d00cb  call 0x00007026094BB270
00007026095d00d0  jmp 0x00007026095CF160
00007026095d00d5  call 0x00007026094BA000
00007026095d00da  jmp 0x00007026095CF16D
00007026095d00df  call 0x00007026094BEAE0
00007026095d00e4  jmp 0x00007026095CF17A
00007026095d00e9  call 0x00007026094B5400
00007026095d00ee  jmp 0x00007026095CF187
00007026095d00f3  call 0x00007026094B52F0
00007026095d00f8  jmp 0x00007026095CF194
00007026095d00fd  call 0x00007026094BE9C0
00007026095d0102  jmp 0x00007026095CF1A1
00007026095d0107  call 0x00007026094C0860
00007026095d010c  jmp 0x00007026095CF1B4
00007026095d0111  call 0x00007026094B8D90
00007026095d0116  jmp 0x00007026095CF1C1
00007026095d011b  call 0x00007026094B8A20
00007026095d0120  jmp 0x00007026095CF1CE
00007026095d0125  call 0x00007026094B77B0
00007026095d012a  jmp 0x00007026095CF1DB
00007026095d012f  call 0x00007026094B6550
00007026095d0134  jmp 0x00007026095CF1E8
00007026095d0139  call 0x00007026094B52F0
00007026095d013e  jmp 0x00007026095CF1F8
00007026095d0143  call 0x00007026094B52F0
00007026095d0148  jmp 0x00007026095CF208
00007026095d014d  call 0x00007026094B8B30
00007026095d0152  jmp 0x00007026095CF212
00007026095d0157  call 0x00007026094B8EA0
00007026095d015c  jmp 0x00007026095CF21F
00007026095d0161  call 0x00007026094B8D90
00007026095d0166  jmp 0x00007026095CF22C
00007026095d016b  call 0x00007026094B8A20
00007026095d0170  jmp 0x00007026095CF239
00007026095d0175  call 0x00007026094B6660
00007026095d017a  jmp 0x00007026095CF246
00007026095d017f  call 0x00007026094B78C0
00007026095d0184  jmp 0x00007026095CF253
00007026095d0189  call 0x00007026094B77B0
00007026095d018e  jmp 0x00007026095CF260
00007026095d0193  call 0x00007026094B6550
00007026095d0198  jmp 0x00007026095CF26D
00007026095d019d  call 0x00007026094B52F0
00007026095d01a2  jmp 0x00007026095CF280
00007026095d01a7  call 0x00007026094B52F0
00007026095d01ac  jmp 0x00007026095CF293
00007026095d01b1  call 0x00007026094B52F0
00007026095d01b6  jmp 0x00007026095CF2A6
00007026095d01bb  call 0x00007026094B52F0
00007026095d01c0  jmp 0x00007026095CF2B9
00007026095d01c5  call 0x00007026094B52F0
00007026095d01ca  jmp 0x00007026095CF2CC
00007026095d01cf  call 0x00007026094B52F0
00007026095d01d4  jmp 0x00007026095CF2E2
00007026095d01d9  call 0x00007026094B52F0
00007026095d01de  jmp 0x00007026095CF2F8
00007026095d01e3  call 0x00007026094B52F0
00007026095d01e8  jmp 0x00007026095CF30E
00007026095d01ed  call 0x00007026093FF540
00007026095d01f2  jmp 0x00007026095CF32F
00007026095d01f7  call 0x00007026093FF540
00007026095d01fc  jmp 0x00007026095CF33F
00007026095d0201  call 0x00007026093FF540
00007026095d0206  jmp 0x00007026095CF34F
00007026095d020b  call 0x00007026093FF540
00007026095d0210  jmp 0x00007026095CF362
00007026095d0215  call 0x00007026093FF540
00007026095d021a  jmp 0x00007026095CF375
00007026095d021f  call 0x00007026093FF540
00007026095d0224  jmp 0x00007026095CF388
00007026095d0229  call 0x00007026094C0370
00007026095d022e  jmp 0x00007026095CF3AD
00007026095d0233  call 0x00007026094BF100
00007026095d0238  jmp 0x00007026095CF3B6
00007026095d023d  call 0x00007026094C0370
00007026095d0242  jmp 0x00007026095CF426
00007026095d0247  call 0x00007026094BF100
00007026095d024c  jmp 0x00007026095CF42F
00007026095d0251  call 0x00007026094C0370
00007026095d0256  jmp 0x00007026095CF4E3
00007026095d025b  call 0x00007026094BF100
00007026095d0260  jmp 0x00007026095CF4EC
00007026095d0265  call 0x000070260940B720
00007026095d026a  jmp 0x00007026095CF5A8
00007026095d026f  call 0x00007026094D64F0
00007026095d0274  jmp 0x00007026095CF5D0
00007026095d0279  call 0x00007026094B47C0
00007026095d027e  jmp 0x00007026095CF5EB
00007026095d0283  sub rsp, 0x08
00007026095d0287  push rax
00007026095d0288  push rcx
00007026095d0289  push rdx
00007026095d028a  push rdi
00007026095d028b  push rsi
00007026095d028c  push r8
00007026095d028e  push r9
00007026095d0290  push r10
00007026095d0292  push r11
00007026095d0294  sub rsp, 0xF0
00007026095d029b  vmovaps [rsp], xmm0
00007026095d02a0  vmovaps [rsp+0x10], xmm1
00007026095d02a6  vmovaps [rsp+0x20], xmm2
00007026095d02ac  vmovaps [rsp+0x30], xmm3
00007026095d02b2  vmovaps [rsp+0x40], xmm4
00007026095d02b8  vmovaps [rsp+0x50], xmm5
00007026095d02be  vmovaps [rsp+0x60], xmm6
00007026095d02c4  vmovaps [rsp+0x70], xmm7
00007026095d02ca  vmovaps [rsp+0x80], xmm8
00007026095d02d3  vmovaps [rsp+0x90], xmm9
00007026095d02dc  vmovaps [rsp+0xA0], xmm10
00007026095d02e5  vmovaps [rsp+0xB0], xmm11
00007026095d02ee  vmovaps [rsp+0xC0], xmm12
00007026095d02f7  vmovaps [rsp+0xD0], xmm14
00007026095d0300  vmovaps [rsp+0xE0], xmm15
00007026095d0309  sub rsp, 0x40
00007026095d030d  lea rdi, [rsp]
00007026095d0311  lea rsi, [rsp+0x10]
00007026095d0316  lea rdx, [rsp+0x20]
00007026095d031b  lea rcx, [rsp+0x30]
00007026095d0320  mov r8d, 0x00
00007026095d0326  lea r9, [r15+0x3A8]
00007026095d032d  movaps [rdi], xmm13
00007026095d0331  movaps [rsi], xmm1
00007026095d0334  movaps [rdx], xmm15
00007026095d0338  movaps [rcx], xmm14
00007026095d033c  mov rax, 0x58A432239A50
00007026095d0346  call rax
00007026095d0348  movaps xmm13, [rsp]
00007026095d034d  add rsp, 0x40
00007026095d0351  vmovaps xmm0, [rsp]
00007026095d0356  vmovaps xmm1, [rsp+0x10]
00007026095d035c  vmovaps xmm2, [rsp+0x20]
00007026095d0362  vmovaps xmm3, [rsp+0x30]
00007026095d0368  vmovaps xmm4, [rsp+0x40]
00007026095d036e  vmovaps xmm5, [rsp+0x50]
00007026095d0374  vmovaps xmm6, [rsp+0x60]
00007026095d037a  vmovaps xmm7, [rsp+0x70]
00007026095d0380  vmovaps xmm8, [rsp+0x80]
00007026095d0389  vmovaps xmm9, [rsp+0x90]
00007026095d0392  vmovaps xmm10, [rsp+0xA0]
00007026095d039b  vmovaps xmm11, [rsp+0xB0]
00007026095d03a4  vmovaps xmm12, [rsp+0xC0]
00007026095d03ad  vmovaps xmm14, [rsp+0xD0]
00007026095d03b6  vmovaps xmm15, [rsp+0xE0]
00007026095d03bf  add rsp, 0xF0
00007026095d03c6  pop r11
00007026095d03c8  pop r10
00007026095d03ca  pop r9
00007026095d03cc  pop r8
00007026095d03ce  pop rsi
00007026095d03cf  pop rdi
00007026095d03d0  pop rdx
00007026095d03d1  pop rcx
00007026095d03d2  pop rax
00007026095d03d3  add rsp, 0x08
00007026095d03d7  jmp 0x00007026095CF65E
00007026095d03dc  sub rsp, 0x08
00007026095d03e0  push rax
00007026095d03e1  push rcx
00007026095d03e2  push rdx
00007026095d03e3  push rdi
00007026095d03e4  push rsi
00007026095d03e5  push r8
00007026095d03e7  push r9
00007026095d03e9  push r10
00007026095d03eb  push r11
00007026095d03ed  sub rsp, 0xF0
00007026095d03f4  vmovaps [rsp], xmm0
00007026095d03f9  vmovaps [rsp+0x10], xmm1
00007026095d03ff  vmovaps [rsp+0x20], xmm2
00007026095d0405  vmovaps [rsp+0x30], xmm3
00007026095d040b  vmovaps [rsp+0x40], xmm4
00007026095d0411  vmovaps [rsp+0x50], xmm5
00007026095d0417  vmovaps [rsp+0x60], xmm6
00007026095d041d  vmovaps [rsp+0x70], xmm7
00007026095d0423  vmovaps [rsp+0x80], xmm8
00007026095d042c  vmovaps [rsp+0x90], xmm9
00007026095d0435  vmovaps [rsp+0xA0], xmm10
00007026095d043e  vmovaps [rsp+0xB0], xmm11
00007026095d0447  vmovaps [rsp+0xC0], xmm13
00007026095d0450  vmovaps [rsp+0xD0], xmm14
00007026095d0459  vmovaps [rsp+0xE0], xmm15
00007026095d0462  sub rsp, 0x40
00007026095d0466  lea rdi, [rsp]
00007026095d046a  lea rsi, [rsp+0x10]
00007026095d046f  lea rdx, [rsp+0x20]
00007026095d0474  lea rcx, [rsp+0x30]
00007026095d0479  mov r8d, 0x00
00007026095d047f  lea r9, [r15+0x3A8]
00007026095d0486  movaps [rdi], xmm12
00007026095d048a  movaps [rsi], xmm1
00007026095d048d  movaps [rdx], xmm15
00007026095d0491  movaps [rcx], xmm14
00007026095d0495  mov rax, 0x58A432239A50
00007026095d049f  call rax
00007026095d04a1  movaps xmm12, [rsp]
00007026095d04a6  add rsp, 0x40
00007026095d04aa  vmovaps xmm0, [rsp]
00007026095d04af  vmovaps xmm1, [rsp+0x10]
00007026095d04b5  vmovaps xmm2, [rsp+0x20]
00007026095d04bb  vmovaps xmm3, [rsp+0x30]
00007026095d04c1  vmovaps xmm4, [rsp+0x40]
00007026095d04c7  vmovaps xmm5, [rsp+0x50]
00007026095d04cd  vmovaps xmm6, [rsp+0x60]
00007026095d04d3  vmovaps xmm7, [rsp+0x70]
00007026095d04d9  vmovaps xmm8, [rsp+0x80]
00007026095d04e2  vmovaps xmm9, [rsp+0x90]
00007026095d04eb  vmovaps xmm10, [rsp+0xA0]
00007026095d04f4  vmovaps xmm11, [rsp+0xB0]
00007026095d04fd  vmovaps xmm13, [rsp+0xC0]
00007026095d0506  vmovaps xmm14, [rsp+0xD0]
00007026095d050f  vmovaps xmm15, [rsp+0xE0]
00007026095d0518  add rsp, 0xF0
00007026095d051f  pop r11
00007026095d0521  pop r10
00007026095d0523  pop r9
00007026095d0525  pop r8
00007026095d0527  pop rsi
00007026095d0528  pop rdi
00007026095d0529  pop rdx
00007026095d052a  pop rcx
00007026095d052b  pop rax
00007026095d052c  add rsp, 0x08
00007026095d0530  jmp 0x00007026095CF68D
00007026095d0535  call 0x00007026093FF430
00007026095d053a  jmp 0x00007026095CF712
00007026095d053f  sub rsp, 0x08
00007026095d0543  push rax
00007026095d0544  push rcx
00007026095d0545  push rdx
00007026095d0546  push rdi
00007026095d0547  push rsi
00007026095d0548  push r8
00007026095d054a  push r9
00007026095d054c  push r10
00007026095d054e  push r11
00007026095d0550  sub rsp, 0xF0
00007026095d0557  vmovaps [rsp], xmm0
00007026095d055c  vmovaps [rsp+0x10], xmm1
00007026095d0562  vmovaps [rsp+0x20], xmm2
00007026095d0568  vmovaps [rsp+0x30], xmm3
00007026095d056e  vmovaps [rsp+0x40], xmm4
00007026095d0574  vmovaps [rsp+0x50], xmm5
00007026095d057a  vmovaps [rsp+0x60], xmm6
00007026095d0580  vmovaps [rsp+0x70], xmm7
00007026095d0586  vmovaps [rsp+0x80], xmm8
00007026095d058f  vmovaps [rsp+0x90], xmm9
00007026095d0598  vmovaps [rsp+0xA0], xmm10
00007026095d05a1  vmovaps [rsp+0xB0], xmm11
00007026095d05aa  vmovaps [rsp+0xC0], xmm12
00007026095d05b3  vmovaps [rsp+0xD0], xmm14
00007026095d05bc  vmovaps [rsp+0xE0], xmm15
00007026095d05c5  sub rsp, 0x40
00007026095d05c9  lea rdi, [rsp]
00007026095d05cd  lea rsi, [rsp+0x10]
00007026095d05d2  lea rdx, [rsp+0x20]
00007026095d05d7  lea rcx, [rsp+0x30]
00007026095d05dc  mov r8d, 0x00
00007026095d05e2  lea r9, [r15+0x3A8]
00007026095d05e9  movaps [rdi], xmm13
00007026095d05ed  movaps [rsi], xmm1
00007026095d05f0  movaps [rdx], xmm15
00007026095d05f4  movaps [rcx], xmm14
00007026095d05f8  mov rax, 0x58A432239A50
00007026095d0602  call rax
00007026095d0604  movaps xmm13, [rsp]
00007026095d0609  add rsp, 0x40
00007026095d060d  vmovaps xmm0, [rsp]
00007026095d0612  vmovaps xmm1, [rsp+0x10]
00007026095d0618  vmovaps xmm2, [rsp+0x20]
00007026095d061e  vmovaps xmm3, [rsp+0x30]
00007026095d0624  vmovaps xmm4, [rsp+0x40]
00007026095d062a  vmovaps xmm5, [rsp+0x50]
00007026095d0630  vmovaps xmm6, [rsp+0x60]
00007026095d0636  vmovaps xmm7, [rsp+0x70]
00007026095d063c  vmovaps xmm8, [rsp+0x80]
00007026095d0645  vmovaps xmm9, [rsp+0x90]
00007026095d064e  vmovaps xmm10, [rsp+0xA0]
00007026095d0657  vmovaps xmm11, [rsp+0xB0]
00007026095d0660  vmovaps xmm12, [rsp+0xC0]
00007026095d0669  vmovaps xmm14, [rsp+0xD0]
00007026095d0672  vmovaps xmm15, [rsp+0xE0]
00007026095d067b  add rsp, 0xF0
00007026095d0682  pop r11
00007026095d0684  pop r10
00007026095d0686  pop r9
00007026095d0688  pop r8
00007026095d068a  pop rsi
00007026095d068b  pop rdi
00007026095d068c  pop rdx
00007026095d068d  pop rcx
00007026095d068e  pop rax
00007026095d068f  add rsp, 0x08
00007026095d0693  jmp 0x00007026095CF77F
00007026095d0698  call 0x00007026093FF430
00007026095d069d  jmp 0x00007026095CF78C
00007026095d06a2  sub rsp, 0x08
00007026095d06a6  push rax
00007026095d06a7  push rcx
00007026095d06a8  push rdx
00007026095d06a9  push rdi
00007026095d06aa  push rsi
00007026095d06ab  push r8
00007026095d06ad  push r9
00007026095d06af  push r10
00007026095d06b1  push r11
00007026095d06b3  sub rsp, 0xF0
00007026095d06ba  vmovaps [rsp], xmm0
00007026095d06bf  vmovaps [rsp+0x10], xmm1
00007026095d06c5  vmovaps [rsp+0x20], xmm2
00007026095d06cb  vmovaps [rsp+0x30], xmm3
00007026095d06d1  vmovaps [rsp+0x40], xmm4
00007026095d06d7  vmovaps [rsp+0x50], xmm5
00007026095d06dd  vmovaps [rsp+0x60], xmm6
00007026095d06e3  vmovaps [rsp+0x70], xmm7
00007026095d06e9  vmovaps [rsp+0x80], xmm8
00007026095d06f2  vmovaps [rsp+0x90], xmm9
00007026095d06fb  vmovaps [rsp+0xA0], xmm10
00007026095d0704  vmovaps [rsp+0xB0], xmm11
00007026095d070d  vmovaps [rsp+0xC0], xmm13
00007026095d0716  vmovaps [rsp+0xD0], xmm14
00007026095d071f  vmovaps [rsp+0xE0], xmm15
00007026095d0728  sub rsp, 0x40
00007026095d072c  lea rdi, [rsp]
00007026095d0730  lea rsi, [rsp+0x10]
00007026095d0735  lea rdx, [rsp+0x20]
00007026095d073a  lea rcx, [rsp+0x30]
00007026095d073f  mov r8d, 0x00
00007026095d0745  lea r9, [r15+0x3A8]
00007026095d074c  movaps [rdi], xmm12
00007026095d0750  movaps [rsi], xmm15
00007026095d0754  movaps [rdx], xmm1
00007026095d0757  movaps [rcx], xmm14
00007026095d075b  mov rax, 0x58A432239A50
00007026095d0765  call rax
00007026095d0767  movaps xmm12, [rsp]
00007026095d076c  add rsp, 0x40
00007026095d0770  vmovaps xmm0, [rsp]
00007026095d0775  vmovaps xmm1, [rsp+0x10]
00007026095d077b  vmovaps xmm2, [rsp+0x20]
00007026095d0781  vmovaps xmm3, [rsp+0x30]
00007026095d0787  vmovaps xmm4, [rsp+0x40]
00007026095d078d  vmovaps xmm5, [rsp+0x50]
00007026095d0793  vmovaps xmm6, [rsp+0x60]
00007026095d0799  vmovaps xmm7, [rsp+0x70]
00007026095d079f  vmovaps xmm8, [rsp+0x80]
00007026095d07a8  vmovaps xmm9, [rsp+0x90]
00007026095d07b1  vmovaps xmm10, [rsp+0xA0]
00007026095d07ba  vmovaps xmm11, [rsp+0xB0]
00007026095d07c3  vmovaps xmm13, [rsp+0xC0]
00007026095d07cc  vmovaps xmm14, [rsp+0xD0]
00007026095d07d5  vmovaps xmm15, [rsp+0xE0]
00007026095d07de  add rsp, 0xF0
00007026095d07e5  pop r11
00007026095d07e7  pop r10
00007026095d07e9  pop r9
00007026095d07eb  pop r8
00007026095d07ed  pop rsi
00007026095d07ee  pop rdi
00007026095d07ef  pop rdx
00007026095d07f0  pop rcx
00007026095d07f1  pop rax
00007026095d07f2  add rsp, 0x08
00007026095d07f6  jmp 0x00007026095CF7B8
00007026095d07fb  sub rsp, 0x08
00007026095d07ff  push rax
00007026095d0800  push rcx
00007026095d0801  push rdx
00007026095d0802  push rdi
00007026095d0803  push rsi
00007026095d0804  push r8
00007026095d0806  push r9
00007026095d0808  push r10
00007026095d080a  push r11
00007026095d080c  sub rsp, 0xF0
00007026095d0813  vmovaps [rsp], xmm0
00007026095d0818  vmovaps [rsp+0x10], xmm1
00007026095d081e  vmovaps [rsp+0x20], xmm2
00007026095d0824  vmovaps [rsp+0x30], xmm3
00007026095d082a  vmovaps [rsp+0x40], xmm4
00007026095d0830  vmovaps [rsp+0x50], xmm5
00007026095d0836  vmovaps [rsp+0x60], xmm6
00007026095d083c  vmovaps [rsp+0x70], xmm7
00007026095d0842  vmovaps [rsp+0x80], xmm8
00007026095d084b  vmovaps [rsp+0x90], xmm9
00007026095d0854  vmovaps [rsp+0xA0], xmm10
00007026095d085d  vmovaps [rsp+0xB0], xmm11
00007026095d0866  vmovaps [rsp+0xC0], xmm12
00007026095d086f  vmovaps [rsp+0xD0], xmm13
00007026095d0878  vmovaps [rsp+0xE0], xmm14
00007026095d0881  sub rsp, 0x40
00007026095d0885  lea rdi, [rsp]
00007026095d0889  lea rsi, [rsp+0x10]
00007026095d088e  lea rdx, [rsp+0x20]
00007026095d0893  lea rcx, [rsp+0x30]
00007026095d0898  mov r8d, 0x00
00007026095d089e  lea r9, [r15+0x3A8]
00007026095d08a5  movaps [rdi], xmm15
00007026095d08a9  movaps [rsi], xmm1
00007026095d08ac  movaps [rdx], xmm9
00007026095d08b0  movaps [rcx], xmm13
00007026095d08b4  mov rax, 0x58A432239A50
00007026095d08be  call rax
00007026095d08c0  movaps xmm15, [rsp]
00007026095d08c5  add rsp, 0x40
00007026095d08c9  vmovaps xmm0, [rsp]
00007026095d08ce  vmovaps xmm1, [rsp+0x10]
00007026095d08d4  vmovaps xmm2, [rsp+0x20]
00007026095d08da  vmovaps xmm3, [rsp+0x30]
00007026095d08e0  vmovaps xmm4, [rsp+0x40]
00007026095d08e6  vmovaps xmm5, [rsp+0x50]
00007026095d08ec  vmovaps xmm6, [rsp+0x60]
00007026095d08f2  vmovaps xmm7, [rsp+0x70]
00007026095d08f8  vmovaps xmm8, [rsp+0x80]
00007026095d0901  vmovaps xmm9, [rsp+0x90]
00007026095d090a  vmovaps xmm10, [rsp+0xA0]
00007026095d0913  vmovaps xmm11, [rsp+0xB0]
00007026095d091c  vmovaps xmm12, [rsp+0xC0]
00007026095d0925  vmovaps xmm13, [rsp+0xD0]
00007026095d092e  vmovaps xmm14, [rsp+0xE0]
00007026095d0937  add rsp, 0xF0
00007026095d093e  pop r11
00007026095d0940  pop r10
00007026095d0942  pop r9
00007026095d0944  pop r8
00007026095d0946  pop rsi
00007026095d0947  pop rdi
00007026095d0948  pop rdx
00007026095d0949  pop rcx
00007026095d094a  pop rax
00007026095d094b  add rsp, 0x08
00007026095d094f  jmp 0x00007026095CF91A
00007026095d0954  sub rsp, 0x08
00007026095d0958  push rax
00007026095d0959  push rcx
00007026095d095a  push rdx
00007026095d095b  push rdi
00007026095d095c  push rsi
00007026095d095d  push r8
00007026095d095f  push r9
00007026095d0961  push r10
00007026095d0963  push r11
00007026095d0965  sub rsp, 0xF0
00007026095d096c  vmovaps [rsp], xmm0
00007026095d0971  vmovaps [rsp+0x10], xmm1
00007026095d0977  vmovaps [rsp+0x20], xmm2
00007026095d097d  vmovaps [rsp+0x30], xmm3
00007026095d0983  vmovaps [rsp+0x40], xmm4
00007026095d0989  vmovaps [rsp+0x50], xmm5
00007026095d098f  vmovaps [rsp+0x60], xmm6
00007026095d0995  vmovaps [rsp+0x70], xmm7
00007026095d099b  vmovaps [rsp+0x80], xmm8
00007026095d09a4  vmovaps [rsp+0x90], xmm10
00007026095d09ad  vmovaps [rsp+0xA0], xmm11
00007026095d09b6  vmovaps [rsp+0xB0], xmm12
00007026095d09bf  vmovaps [rsp+0xC0], xmm13
00007026095d09c8  vmovaps [rsp+0xD0], xmm14
00007026095d09d1  vmovaps [rsp+0xE0], xmm15
00007026095d09da  sub rsp, 0x40
00007026095d09de  lea rdi, [rsp]
00007026095d09e2  lea rsi, [rsp+0x10]
00007026095d09e7  lea rdx, [rsp+0x20]
00007026095d09ec  lea rcx, [rsp+0x30]
00007026095d09f1  mov r8d, 0x00
00007026095d09f7  lea r9, [r15+0x3A8]
00007026095d09fe  movaps [rdi], xmm9
00007026095d0a02  movaps [rsi], xmm14
00007026095d0a06  movaps [rdx], xmm13
00007026095d0a0a  movaps [rcx], xmm1
00007026095d0a0d  mov rax, 0x58A432239A50
00007026095d0a17  call rax
00007026095d0a19  movaps xmm9, [rsp]
00007026095d0a1e  add rsp, 0x40
00007026095d0a22  vmovaps xmm0, [rsp]
00007026095d0a27  vmovaps xmm1, [rsp+0x10]
00007026095d0a2d  vmovaps xmm2, [rsp+0x20]
00007026095d0a33  vmovaps xmm3, [rsp+0x30]
00007026095d0a39  vmovaps xmm4, [rsp+0x40]
00007026095d0a3f  vmovaps xmm5, [rsp+0x50]
00007026095d0a45  vmovaps xmm6, [rsp+0x60]
00007026095d0a4b  vmovaps xmm7, [rsp+0x70]
00007026095d0a51  vmovaps xmm8, [rsp+0x80]
00007026095d0a5a  vmovaps xmm10, [rsp+0x90]
00007026095d0a63  vmovaps xmm11, [rsp+0xA0]
00007026095d0a6c  vmovaps xmm12, [rsp+0xB0]
00007026095d0a75  vmovaps xmm13, [rsp+0xC0]
00007026095d0a7e  vmovaps xmm14, [rsp+0xD0]
00007026095d0a87  vmovaps xmm15, [rsp+0xE0]
00007026095d0a90  add rsp, 0xF0
00007026095d0a97  pop r11
00007026095d0a99  pop r10
00007026095d0a9b  pop r9
00007026095d0a9d  pop r8
00007026095d0a9f  pop rsi
00007026095d0aa0  pop rdi
00007026095d0aa1  pop rdx
00007026095d0aa2  pop rcx
00007026095d0aa3  pop rax
00007026095d0aa4  add rsp, 0x08
00007026095d0aa8  jmp 0x00007026095CF955
00007026095d0aad  sub rsp, 0x08
00007026095d0ab1  push rax
00007026095d0ab2  push rcx
00007026095d0ab3  push rdx
00007026095d0ab4  push rdi
00007026095d0ab5  push rsi
00007026095d0ab6  push r8
00007026095d0ab8  push r9
00007026095d0aba  push r10
00007026095d0abc  push r11
00007026095d0abe  sub rsp, 0xF0
00007026095d0ac5  vmovaps [rsp], xmm0
00007026095d0aca  vmovaps [rsp+0x10], xmm1
00007026095d0ad0  vmovaps [rsp+0x20], xmm2
00007026095d0ad6  vmovaps [rsp+0x30], xmm3
00007026095d0adc  vmovaps [rsp+0x40], xmm4
00007026095d0ae2  vmovaps [rsp+0x50], xmm5
00007026095d0ae8  vmovaps [rsp+0x60], xmm6
00007026095d0aee  vmovaps [rsp+0x70], xmm7
00007026095d0af4  vmovaps [rsp+0x80], xmm8
00007026095d0afd  vmovaps [rsp+0x90], xmm9
00007026095d0b06  vmovaps [rsp+0xA0], xmm10
00007026095d0b0f  vmovaps [rsp+0xB0], xmm11
00007026095d0b18  vmovaps [rsp+0xC0], xmm12
00007026095d0b21  vmovaps [rsp+0xD0], xmm13
00007026095d0b2a  vmovaps [rsp+0xE0], xmm15
00007026095d0b33  sub rsp, 0x40
00007026095d0b37  lea rdi, [rsp]
00007026095d0b3b  lea rsi, [rsp+0x10]
00007026095d0b40  lea rdx, [rsp+0x20]
00007026095d0b45  lea rcx, [rsp+0x30]
00007026095d0b4a  mov r8d, 0x00
00007026095d0b50  lea r9, [r15+0x3A8]
00007026095d0b57  movaps [rdi], xmm14
00007026095d0b5b  movaps [rsi], xmm15
00007026095d0b5f  movaps [rdx], xmm8
00007026095d0b63  movaps [rcx], xmm1
00007026095d0b66  mov rax, 0x58A432239A50
00007026095d0b70  call rax
00007026095d0b72  movaps xmm14, [rsp]
00007026095d0b77  add rsp, 0x40
00007026095d0b7b  vmovaps xmm0, [rsp]
00007026095d0b80  vmovaps xmm1, [rsp+0x10]
00007026095d0b86  vmovaps xmm2, [rsp+0x20]
00007026095d0b8c  vmovaps xmm3, [rsp+0x30]
00007026095d0b92  vmovaps xmm4, [rsp+0x40]
00007026095d0b98  vmovaps xmm5, [rsp+0x50]
00007026095d0b9e  vmovaps xmm6, [rsp+0x60]
00007026095d0ba4  vmovaps xmm7, [rsp+0x70]
00007026095d0baa  vmovaps xmm8, [rsp+0x80]
00007026095d0bb3  vmovaps xmm9, [rsp+0x90]
00007026095d0bbc  vmovaps xmm10, [rsp+0xA0]
00007026095d0bc5  vmovaps xmm11, [rsp+0xB0]
00007026095d0bce  vmovaps xmm12, [rsp+0xC0]
00007026095d0bd7  vmovaps xmm13, [rsp+0xD0]
00007026095d0be0  vmovaps xmm15, [rsp+0xE0]
00007026095d0be9  add rsp, 0xF0
00007026095d0bf0  pop r11
00007026095d0bf2  pop r10
00007026095d0bf4  pop r9
00007026095d0bf6  pop r8
00007026095d0bf8  pop rsi
00007026095d0bf9  pop rdi
00007026095d0bfa  pop rdx
00007026095d0bfb  pop rcx
00007026095d0bfc  pop rax
00007026095d0bfd  add rsp, 0x08
00007026095d0c01  jmp 0x00007026095CF984
00007026095d0c06  sub rsp, 0x08
00007026095d0c0a  push rax
00007026095d0c0b  push rcx
00007026095d0c0c  push rdx
00007026095d0c0d  push rdi
00007026095d0c0e  push rsi
00007026095d0c0f  push r8
00007026095d0c11  push r9
00007026095d0c13  push r10
00007026095d0c15  push r11
00007026095d0c17  sub rsp, 0xF0
00007026095d0c1e  vmovaps [rsp], xmm0
00007026095d0c23  vmovaps [rsp+0x10], xmm1
00007026095d0c29  vmovaps [rsp+0x20], xmm2
00007026095d0c2f  vmovaps [rsp+0x30], xmm3
00007026095d0c35  vmovaps [rsp+0x40], xmm4
00007026095d0c3b  vmovaps [rsp+0x50], xmm5
00007026095d0c41  vmovaps [rsp+0x60], xmm6
00007026095d0c47  vmovaps [rsp+0x70], xmm7
00007026095d0c4d  vmovaps [rsp+0x80], xmm8
00007026095d0c56  vmovaps [rsp+0x90], xmm9
00007026095d0c5f  vmovaps [rsp+0xA0], xmm10
00007026095d0c68  vmovaps [rsp+0xB0], xmm11
00007026095d0c71  vmovaps [rsp+0xC0], xmm12
00007026095d0c7a  vmovaps [rsp+0xD0], xmm13
00007026095d0c83  vmovaps [rsp+0xE0], xmm14
00007026095d0c8c  sub rsp, 0x40
00007026095d0c90  lea rdi, [rsp]
00007026095d0c94  lea rsi, [rsp+0x10]
00007026095d0c99  lea rdx, [rsp+0x20]
00007026095d0c9e  lea rcx, [rsp+0x30]
00007026095d0ca3  mov r8d, 0x00
00007026095d0ca9  lea r9, [r15+0x3A8]
00007026095d0cb0  movaps [rdi], xmm15
00007026095d0cb4  movaps [rsi], xmm12
00007026095d0cb8  movaps [rdx], xmm13
00007026095d0cbc  movaps [rcx], xmm1
00007026095d0cbf  mov rax, 0x58A432239A50
00007026095d0cc9  call rax
00007026095d0ccb  movaps xmm15, [rsp]
00007026095d0cd0  add rsp, 0x40
00007026095d0cd4  vmovaps xmm0, [rsp]
00007026095d0cd9  vmovaps xmm1, [rsp+0x10]
00007026095d0cdf  vmovaps xmm2, [rsp+0x20]
00007026095d0ce5  vmovaps xmm3, [rsp+0x30]
00007026095d0ceb  vmovaps xmm4, [rsp+0x40]
00007026095d0cf1  vmovaps xmm5, [rsp+0x50]
00007026095d0cf7  vmovaps xmm6, [rsp+0x60]
00007026095d0cfd  vmovaps xmm7, [rsp+0x70]
00007026095d0d03  vmovaps xmm8, [rsp+0x80]
00007026095d0d0c  vmovaps xmm9, [rsp+0x90]
00007026095d0d15  vmovaps xmm10, [rsp+0xA0]
00007026095d0d1e  vmovaps xmm11, [rsp+0xB0]
00007026095d0d27  vmovaps xmm12, [rsp+0xC0]
00007026095d0d30  vmovaps xmm13, [rsp+0xD0]
00007026095d0d39  vmovaps xmm14, [rsp+0xE0]
00007026095d0d42  add rsp, 0xF0
00007026095d0d49  pop r11
00007026095d0d4b  pop r10
00007026095d0d4d  pop r9
00007026095d0d4f  pop r8
00007026095d0d51  pop rsi
00007026095d0d52  pop rdi
00007026095d0d53  pop rdx
00007026095d0d54  pop rcx
00007026095d0d55  pop rax
00007026095d0d56  add rsp, 0x08
00007026095d0d5a  jmp 0x00007026095CF9D1
00007026095d0d5f  sub rsp, 0x08
00007026095d0d63  push rax
00007026095d0d64  push rcx
00007026095d0d65  push rdx
00007026095d0d66  push rdi
00007026095d0d67  push rsi
00007026095d0d68  push r8
00007026095d0d6a  push r9
00007026095d0d6c  push r10
00007026095d0d6e  push r11
00007026095d0d70  sub rsp, 0xF0
00007026095d0d77  vmovaps [rsp], xmm0
00007026095d0d7c  vmovaps [rsp+0x10], xmm1
00007026095d0d82  vmovaps [rsp+0x20], xmm2
00007026095d0d88  vmovaps [rsp+0x30], xmm3
00007026095d0d8e  vmovaps [rsp+0x40], xmm4
00007026095d0d94  vmovaps [rsp+0x50], xmm5
00007026095d0d9a  vmovaps [rsp+0x60], xmm6
00007026095d0da0  vmovaps [rsp+0x70], xmm7
00007026095d0da6  vmovaps [rsp+0x80], xmm8
00007026095d0daf  vmovaps [rsp+0x90], xmm9
00007026095d0db8  vmovaps [rsp+0xA0], xmm10
00007026095d0dc1  vmovaps [rsp+0xB0], xmm11
00007026095d0dca  vmovaps [rsp+0xC0], xmm12
00007026095d0dd3  vmovaps [rsp+0xD0], xmm13
00007026095d0ddc  vmovaps [rsp+0xE0], xmm14
00007026095d0de5  sub rsp, 0x40
00007026095d0de9  lea rdi, [rsp]
00007026095d0ded  lea rsi, [rsp+0x10]
00007026095d0df2  lea rdx, [rsp+0x20]
00007026095d0df7  lea rcx, [rsp+0x30]
00007026095d0dfc  mov r8d, 0x00
00007026095d0e02  lea r9, [r15+0x3A8]
00007026095d0e09  movaps [rdi], xmm15
00007026095d0e0d  movaps [rsi], xmm3
00007026095d0e10  movaps [rdx], xmm1
00007026095d0e13  movaps [rcx], xmm8
00007026095d0e17  mov rax, 0x58A432239A50
00007026095d0e21  call rax
00007026095d0e23  movaps xmm15, [rsp]
00007026095d0e28  add rsp, 0x40
00007026095d0e2c  vmovaps xmm0, [rsp]
00007026095d0e31  vmovaps xmm1, [rsp+0x10]
00007026095d0e37  vmovaps xmm2, [rsp+0x20]
00007026095d0e3d  vmovaps xmm3, [rsp+0x30]
00007026095d0e43  vmovaps xmm4, [rsp+0x40]
00007026095d0e49  vmovaps xmm5, [rsp+0x50]
00007026095d0e4f  vmovaps xmm6, [rsp+0x60]
00007026095d0e55  vmovaps xmm7, [rsp+0x70]
00007026095d0e5b  vmovaps xmm8, [rsp+0x80]
00007026095d0e64  vmovaps xmm9, [rsp+0x90]
00007026095d0e6d  vmovaps xmm10, [rsp+0xA0]
00007026095d0e76  vmovaps xmm11, [rsp+0xB0]
00007026095d0e7f  vmovaps xmm12, [rsp+0xC0]
00007026095d0e88  vmovaps xmm13, [rsp+0xD0]
00007026095d0e91  vmovaps xmm14, [rsp+0xE0]
00007026095d0e9a  add rsp, 0xF0
00007026095d0ea1  pop r11
00007026095d0ea3  pop r10
00007026095d0ea5  pop r9
00007026095d0ea7  pop r8
00007026095d0ea9  pop rsi
00007026095d0eaa  pop rdi
00007026095d0eab  pop rdx
00007026095d0eac  pop rcx
00007026095d0ead  pop rax
00007026095d0eae  add rsp, 0x08
00007026095d0eb2  jmp 0x00007026095CFA82
00007026095d0eb7  sub rsp, 0x08
00007026095d0ebb  push rax
00007026095d0ebc  push rcx
00007026095d0ebd  push rdx
00007026095d0ebe  push rdi
00007026095d0ebf  push rsi
00007026095d0ec0  push r8
00007026095d0ec2  push r9
00007026095d0ec4  push r10
00007026095d0ec6  push r11
00007026095d0ec8  sub rsp, 0xF0
00007026095d0ecf  vmovaps [rsp], xmm0
00007026095d0ed4  vmovaps [rsp+0x10], xmm1
00007026095d0eda  vmovaps [rsp+0x20], xmm2
00007026095d0ee0  vmovaps [rsp+0x30], xmm3
00007026095d0ee6  vmovaps [rsp+0x40], xmm4
00007026095d0eec  vmovaps [rsp+0x50], xmm5
00007026095d0ef2  vmovaps [rsp+0x60], xmm6
00007026095d0ef8  vmovaps [rsp+0x70], xmm7
00007026095d0efe  vmovaps [rsp+0x80], xmm9
00007026095d0f07  vmovaps [rsp+0x90], xmm10
00007026095d0f10  vmovaps [rsp+0xA0], xmm11
00007026095d0f19  vmovaps [rsp+0xB0], xmm12
00007026095d0f22  vmovaps [rsp+0xC0], xmm13
00007026095d0f2b  vmovaps [rsp+0xD0], xmm14
00007026095d0f34  vmovaps [rsp+0xE0], xmm15
00007026095d0f3d  sub rsp, 0x40
00007026095d0f41  lea rdi, [rsp]
00007026095d0f45  lea rsi, [rsp+0x10]
00007026095d0f4a  lea rdx, [rsp+0x20]
00007026095d0f4f  lea rcx, [rsp+0x30]
00007026095d0f54  mov r8d, 0x00
00007026095d0f5a  lea r9, [r15+0x3A8]
00007026095d0f61  movaps [rdi], xmm8
00007026095d0f65  movaps [rsi], xmm9
00007026095d0f69  movaps [rdx], xmm5
00007026095d0f6c  movaps [rcx], xmm1
00007026095d0f6f  mov rax, 0x58A432239A50
00007026095d0f79  call rax
00007026095d0f7b  movaps xmm8, [rsp]
00007026095d0f80  add rsp, 0x40
00007026095d0f84  vmovaps xmm0, [rsp]
00007026095d0f89  vmovaps xmm1, [rsp+0x10]
00007026095d0f8f  vmovaps xmm2, [rsp+0x20]
00007026095d0f95  vmovaps xmm3, [rsp+0x30]
00007026095d0f9b  vmovaps xmm4, [rsp+0x40]
00007026095d0fa1  vmovaps xmm5, [rsp+0x50]
00007026095d0fa7  vmovaps xmm6, [rsp+0x60]
00007026095d0fad  vmovaps xmm7, [rsp+0x70]
00007026095d0fb3  vmovaps xmm9, [rsp+0x80]
00007026095d0fbc  vmovaps xmm10, [rsp+0x90]
00007026095d0fc5  vmovaps xmm11, [rsp+0xA0]
00007026095d0fce  vmovaps xmm12, [rsp+0xB0]
00007026095d0fd7  vmovaps xmm13, [rsp+0xC0]
00007026095d0fe0  vmovaps xmm14, [rsp+0xD0]
00007026095d0fe9  vmovaps xmm15, [rsp+0xE0]
00007026095d0ff2  add rsp, 0xF0
00007026095d0ff9  pop r11
00007026095d0ffb  pop r10
00007026095d0ffd  pop r9
00007026095d0fff  pop r8
00007026095d1001  pop rsi
00007026095d1002  pop rdi
00007026095d1003  pop rdx
00007026095d1004  pop rcx
00007026095d1005  pop rax
00007026095d1006  add rsp, 0x08
00007026095d100a  jmp 0x00007026095CFAAB
00007026095d100f  sub rsp, 0x08
00007026095d1013  push rax
00007026095d1014  push rcx
00007026095d1015  push rdx
00007026095d1016  push rdi
00007026095d1017  push rsi
00007026095d1018  push r8
00007026095d101a  push r9
00007026095d101c  push r10
00007026095d101e  push r11
00007026095d1020  sub rsp, 0xF0
00007026095d1027  vmovaps [rsp], xmm0
00007026095d102c  vmovaps [rsp+0x10], xmm1
00007026095d1032  vmovaps [rsp+0x20], xmm2
00007026095d1038  vmovaps [rsp+0x30], xmm3
00007026095d103e  vmovaps [rsp+0x40], xmm4
00007026095d1044  vmovaps [rsp+0x50], xmm6
00007026095d104a  vmovaps [rsp+0x60], xmm7
00007026095d1050  vmovaps [rsp+0x70], xmm8
00007026095d1056  vmovaps [rsp+0x80], xmm9
00007026095d105f  vmovaps [rsp+0x90], xmm10
00007026095d1068  vmovaps [rsp+0xA0], xmm11
00007026095d1071  vmovaps [rsp+0xB0], xmm12
00007026095d107a  vmovaps [rsp+0xC0], xmm13
00007026095d1083  vmovaps [rsp+0xD0], xmm14
00007026095d108c  vmovaps [rsp+0xE0], xmm15
00007026095d1095  sub rsp, 0x40
00007026095d1099  lea rdi, [rsp]
00007026095d109d  lea rsi, [rsp+0x10]
00007026095d10a2  lea rdx, [rsp+0x20]
00007026095d10a7  lea rcx, [rsp+0x30]
00007026095d10ac  mov r8d, 0x00
00007026095d10b2  lea r9, [r15+0x3A8]
00007026095d10b9  movaps [rdi], xmm5
00007026095d10bc  movaps [rsi], xmm14
00007026095d10c0  movaps [rdx], xmm9
00007026095d10c4  movaps [rcx], xmm1
00007026095d10c7  mov rax, 0x58A432239A50
00007026095d10d1  call rax
00007026095d10d3  movaps xmm5, [rsp]
00007026095d10d7  add rsp, 0x40
00007026095d10db  vmovaps xmm0, [rsp]
00007026095d10e0  vmovaps xmm1, [rsp+0x10]
00007026095d10e6  vmovaps xmm2, [rsp+0x20]
00007026095d10ec  vmovaps xmm3, [rsp+0x30]
00007026095d10f2  vmovaps xmm4, [rsp+0x40]
00007026095d10f8  vmovaps xmm6, [rsp+0x50]
00007026095d10fe  vmovaps xmm7, [rsp+0x60]
00007026095d1104  vmovaps xmm8, [rsp+0x70]
00007026095d110a  vmovaps xmm9, [rsp+0x80]
00007026095d1113  vmovaps xmm10, [rsp+0x90]
00007026095d111c  vmovaps xmm11, [rsp+0xA0]
00007026095d1125  vmovaps xmm12, [rsp+0xB0]
00007026095d112e  vmovaps xmm13, [rsp+0xC0]
00007026095d1137  vmovaps xmm14, [rsp+0xD0]
00007026095d1140  vmovaps xmm15, [rsp+0xE0]
00007026095d1149  add rsp, 0xF0
00007026095d1150  pop r11
00007026095d1152  pop r10
00007026095d1154  pop r9
00007026095d1156  pop r8
00007026095d1158  pop rsi
00007026095d1159  pop rdi
00007026095d115a  pop rdx
00007026095d115b  pop rcx
00007026095d115c  pop rax
00007026095d115d  add rsp, 0x08
00007026095d1161  jmp 0x00007026095CFADF
00007026095d1166  sub rsp, 0x08
00007026095d116a  push rax
00007026095d116b  push rcx
00007026095d116c  push rdx
00007026095d116d  push rdi
00007026095d116e  push rsi
00007026095d116f  push r8
00007026095d1171  push r9
00007026095d1173  push r10
00007026095d1175  push r11
00007026095d1177  sub rsp, 0xF0
00007026095d117e  vmovaps [rsp], xmm0
00007026095d1183  vmovaps [rsp+0x10], xmm1
00007026095d1189  vmovaps [rsp+0x20], xmm2
00007026095d118f  vmovaps [rsp+0x30], xmm3
00007026095d1195  vmovaps [rsp+0x40], xmm4
00007026095d119b  vmovaps [rsp+0x50], xmm5
00007026095d11a1  vmovaps [rsp+0x60], xmm6
00007026095d11a7  vmovaps [rsp+0x70], xmm7
00007026095d11ad  vmovaps [rsp+0x80], xmm8
00007026095d11b6  vmovaps [rsp+0x90], xmm10
00007026095d11bf  vmovaps [rsp+0xA0], xmm11
00007026095d11c8  vmovaps [rsp+0xB0], xmm12
00007026095d11d1  vmovaps [rsp+0xC0], xmm13
00007026095d11da  vmovaps [rsp+0xD0], xmm14
00007026095d11e3  vmovaps [rsp+0xE0], xmm15
00007026095d11ec  sub rsp, 0x40
00007026095d11f0  lea rdi, [rsp]
00007026095d11f4  lea rsi, [rsp+0x10]
00007026095d11f9  lea rdx, [rsp+0x20]
00007026095d11fe  lea rcx, [rsp+0x30]
00007026095d1203  mov r8d, 0x00
00007026095d1209  lea r9, [r15+0x3A8]
00007026095d1210  movaps [rdi], xmm9
00007026095d1214  movaps [rsi], xmm14
00007026095d1218  movaps [rdx], xmm4
00007026095d121b  movaps [rcx], xmm1
00007026095d121e  mov rax, 0x58A432239A50
00007026095d1228  call rax
00007026095d122a  movaps xmm9, [rsp]
00007026095d122f  add rsp, 0x40
00007026095d1233  vmovaps xmm0, [rsp]
00007026095d1238  vmovaps xmm1, [rsp+0x10]
00007026095d123e  vmovaps xmm2, [rsp+0x20]
00007026095d1244  vmovaps xmm3, [rsp+0x30]
00007026095d124a  vmovaps xmm4, [rsp+0x40]
00007026095d1250  vmovaps xmm5, [rsp+0x50]
00007026095d1256  vmovaps xmm6, [rsp+0x60]
00007026095d125c  vmovaps xmm7, [rsp+0x70]
00007026095d1262  vmovaps xmm8, [rsp+0x80]
00007026095d126b  vmovaps xmm10, [rsp+0x90]
00007026095d1274  vmovaps xmm11, [rsp+0xA0]
00007026095d127d  vmovaps xmm12, [rsp+0xB0]
00007026095d1286  vmovaps xmm13, [rsp+0xC0]
00007026095d128f  vmovaps xmm14, [rsp+0xD0]
00007026095d1298  vmovaps xmm15, [rsp+0xE0]
00007026095d12a1  add rsp, 0xF0
00007026095d12a8  pop r11
00007026095d12aa  pop r10
00007026095d12ac  pop r9
00007026095d12ae  pop r8
00007026095d12b0  pop rsi
00007026095d12b1  pop rdi
00007026095d12b2  pop rdx
00007026095d12b3  pop rcx
00007026095d12b4  pop rax
00007026095d12b5  add rsp, 0x08
00007026095d12b9  jmp 0x00007026095CFB0E
00007026095d12be  sub rsp, 0x08
00007026095d12c2  push rax
00007026095d12c3  push rcx
00007026095d12c4  push rdx
00007026095d12c5  push rdi
00007026095d12c6  push rsi
00007026095d12c7  push r8
00007026095d12c9  push r9
00007026095d12cb  push r10
00007026095d12cd  push r11
00007026095d12cf  sub rsp, 0xF0
00007026095d12d6  vmovaps [rsp], xmm0
00007026095d12db  vmovaps [rsp+0x10], xmm1
00007026095d12e1  vmovaps [rsp+0x20], xmm3
00007026095d12e7  vmovaps [rsp+0x30], xmm4
00007026095d12ed  vmovaps [rsp+0x40], xmm5
00007026095d12f3  vmovaps [rsp+0x50], xmm6
00007026095d12f9  vmovaps [rsp+0x60], xmm7
00007026095d12ff  vmovaps [rsp+0x70], xmm8
00007026095d1305  vmovaps [rsp+0x80], xmm9
00007026095d130e  vmovaps [rsp+0x90], xmm10
00007026095d1317  vmovaps [rsp+0xA0], xmm11
00007026095d1320  vmovaps [rsp+0xB0], xmm12
00007026095d1329  vmovaps [rsp+0xC0], xmm13
00007026095d1332  vmovaps [rsp+0xD0], xmm14
00007026095d133b  vmovaps [rsp+0xE0], xmm15
00007026095d1344  sub rsp, 0x40
00007026095d1348  lea rdi, [rsp]
00007026095d134c  lea rsi, [rsp+0x10]
00007026095d1351  lea rdx, [rsp+0x20]
00007026095d1356  lea rcx, [rsp+0x30]
00007026095d135b  mov r8d, 0x00
00007026095d1361  lea r9, [r15+0x3A8]
00007026095d1368  movaps [rdi], xmm2
00007026095d136b  movaps [rsi], xmm8
00007026095d136f  movaps [rdx], xmm13
00007026095d1373  movaps [rcx], xmm3
00007026095d1376  mov rax, 0x58A432239A50
00007026095d1380  call rax
00007026095d1382  movaps xmm2, [rsp]
00007026095d1386  add rsp, 0x40
00007026095d138a  vmovaps xmm0, [rsp]
00007026095d138f  vmovaps xmm1, [rsp+0x10]
00007026095d1395  vmovaps xmm3, [rsp+0x20]
00007026095d139b  vmovaps xmm4, [rsp+0x30]
00007026095d13a1  vmovaps xmm5, [rsp+0x40]
00007026095d13a7  vmovaps xmm6, [rsp+0x50]
00007026095d13ad  vmovaps xmm7, [rsp+0x60]
00007026095d13b3  vmovaps xmm8, [rsp+0x70]
00007026095d13b9  vmovaps xmm9, [rsp+0x80]
00007026095d13c2  vmovaps xmm10, [rsp+0x90]
00007026095d13cb  vmovaps xmm11, [rsp+0xA0]
00007026095d13d4  vmovaps xmm12, [rsp+0xB0]
00007026095d13dd  vmovaps xmm13, [rsp+0xC0]
00007026095d13e6  vmovaps xmm14, [rsp+0xD0]
00007026095d13ef  vmovaps xmm15, [rsp+0xE0]
00007026095d13f8  add rsp, 0xF0
00007026095d13ff  pop r11
00007026095d1401  pop r10
00007026095d1403  pop r9
00007026095d1405  pop r8
00007026095d1407  pop rsi
00007026095d1408  pop rdi
00007026095d1409  pop rdx
00007026095d140a  pop rcx
00007026095d140b  pop rax
00007026095d140c  add rsp, 0x08
00007026095d1410  jmp 0x00007026095CFB8C
00007026095d1415  sub rsp, 0x08
00007026095d1419  push rax
00007026095d141a  push rcx
00007026095d141b  push rdx
00007026095d141c  push rdi
00007026095d141d  push rsi
00007026095d141e  push r8
00007026095d1420  push r9
00007026095d1422  push r10
00007026095d1424  push r11
00007026095d1426  sub rsp, 0xF0
00007026095d142d  vmovaps [rsp], xmm0
00007026095d1432  vmovaps [rsp+0x10], xmm1
00007026095d1438  vmovaps [rsp+0x20], xmm2
00007026095d143e  vmovaps [rsp+0x30], xmm3
00007026095d1444  vmovaps [rsp+0x40], xmm4
00007026095d144a  vmovaps [rsp+0x50], xmm5
00007026095d1450  vmovaps [rsp+0x60], xmm6
00007026095d1456  vmovaps [rsp+0x70], xmm7
00007026095d145c  vmovaps [rsp+0x80], xmm9
00007026095d1465  vmovaps [rsp+0x90], xmm10
00007026095d146e  vmovaps [rsp+0xA0], xmm11
00007026095d1477  vmovaps [rsp+0xB0], xmm12
00007026095d1480  vmovaps [rsp+0xC0], xmm13
00007026095d1489  vmovaps [rsp+0xD0], xmm14
00007026095d1492  vmovaps [rsp+0xE0], xmm15
00007026095d149b  sub rsp, 0x40
00007026095d149f  lea rdi, [rsp]
00007026095d14a3  lea rsi, [rsp+0x10]
00007026095d14a8  lea rdx, [rsp+0x20]
00007026095d14ad  lea rcx, [rsp+0x30]
00007026095d14b2  mov r8d, 0x00
00007026095d14b8  lea r9, [r15+0x3A8]
00007026095d14bf  movaps [rdi], xmm8
00007026095d14c3  movaps [rsi], xmm15
00007026095d14c7  movaps [rdx], xmm13
00007026095d14cb  movaps [rcx], xmm1
00007026095d14ce  mov rax, 0x58A432239A50
00007026095d14d8  call rax
00007026095d14da  movaps xmm8, [rsp]
00007026095d14df  add rsp, 0x40
00007026095d14e3  vmovaps xmm0, [rsp]
00007026095d14e8  vmovaps xmm1, [rsp+0x10]
00007026095d14ee  vmovaps xmm2, [rsp+0x20]
00007026095d14f4  vmovaps xmm3, [rsp+0x30]
00007026095d14fa  vmovaps xmm4, [rsp+0x40]
00007026095d1500  vmovaps xmm5, [rsp+0x50]
00007026095d1506  vmovaps xmm6, [rsp+0x60]
00007026095d150c  vmovaps xmm7, [rsp+0x70]
00007026095d1512  vmovaps xmm9, [rsp+0x80]
00007026095d151b  vmovaps xmm10, [rsp+0x90]
00007026095d1524  vmovaps xmm11, [rsp+0xA0]
00007026095d152d  vmovaps xmm12, [rsp+0xB0]
00007026095d1536  vmovaps xmm13, [rsp+0xC0]
00007026095d153f  vmovaps xmm14, [rsp+0xD0]
00007026095d1548  vmovaps xmm15, [rsp+0xE0]
00007026095d1551  add rsp, 0xF0
00007026095d1558  pop r11
00007026095d155a  pop r10
00007026095d155c  pop r9
00007026095d155e  pop r8
00007026095d1560  pop rsi
00007026095d1561  pop rdi
00007026095d1562  pop rdx
00007026095d1563  pop rcx
00007026095d1564  pop rax
00007026095d1565  add rsp, 0x08
00007026095d1569  jmp 0x00007026095CFBBB
00007026095d156e  call 0x00007026093FF430
00007026095d1573  jmp 0x00007026095CFBC8
00007026095d1578  sub rsp, 0x08
00007026095d157c  push rax
00007026095d157d  push rcx
00007026095d157e  push rdx
00007026095d157f  push rdi
00007026095d1580  push rsi
00007026095d1581  push r8
00007026095d1583  push r9
00007026095d1585  push r10
00007026095d1587  push r11
00007026095d1589  sub rsp, 0xF0
00007026095d1590  vmovaps [rsp], xmm0
00007026095d1595  vmovaps [rsp+0x10], xmm1
00007026095d159b  vmovaps [rsp+0x20], xmm2
00007026095d15a1  vmovaps [rsp+0x30], xmm3
00007026095d15a7  vmovaps [rsp+0x40], xmm4
00007026095d15ad  vmovaps [rsp+0x50], xmm5
00007026095d15b3  vmovaps [rsp+0x60], xmm6
00007026095d15b9  vmovaps [rsp+0x70], xmm7
00007026095d15bf  vmovaps [rsp+0x80], xmm8
00007026095d15c8  vmovaps [rsp+0x90], xmm9
00007026095d15d1  vmovaps [rsp+0xA0], xmm10
00007026095d15da  vmovaps [rsp+0xB0], xmm11
00007026095d15e3  vmovaps [rsp+0xC0], xmm12
00007026095d15ec  vmovaps [rsp+0xD0], xmm14
00007026095d15f5  vmovaps [rsp+0xE0], xmm15
00007026095d15fe  sub rsp, 0x40
00007026095d1602  lea rdi, [rsp]
00007026095d1606  lea rsi, [rsp+0x10]
00007026095d160b  lea rdx, [rsp+0x20]
00007026095d1610  lea rcx, [rsp+0x30]
00007026095d1615  mov r8d, 0x00
00007026095d161b  lea r9, [r15+0x3A8]
00007026095d1622  movaps [rdi], xmm13
00007026095d1626  movaps [rsi], xmm5
00007026095d1629  movaps [rdx], xmm11
00007026095d162d  movaps [rcx], xmm15
00007026095d1631  mov rax, 0x58A432239A50
00007026095d163b  call rax
00007026095d163d  movaps xmm13, [rsp]
00007026095d1642  add rsp, 0x40
00007026095d1646  vmovaps xmm0, [rsp]
00007026095d164b  vmovaps xmm1, [rsp+0x10]
00007026095d1651  vmovaps xmm2, [rsp+0x20]
00007026095d1657  vmovaps xmm3, [rsp+0x30]
00007026095d165d  vmovaps xmm4, [rsp+0x40]
00007026095d1663  vmovaps xmm5, [rsp+0x50]
00007026095d1669  vmovaps xmm6, [rsp+0x60]
00007026095d166f  vmovaps xmm7, [rsp+0x70]
00007026095d1675  vmovaps xmm8, [rsp+0x80]
00007026095d167e  vmovaps xmm9, [rsp+0x90]
00007026095d1687  vmovaps xmm10, [rsp+0xA0]
00007026095d1690  vmovaps xmm11, [rsp+0xB0]
00007026095d1699  vmovaps xmm12, [rsp+0xC0]
00007026095d16a2  vmovaps xmm14, [rsp+0xD0]
00007026095d16ab  vmovaps xmm15, [rsp+0xE0]
00007026095d16b4  add rsp, 0xF0
00007026095d16bb  pop r11
00007026095d16bd  pop r10
00007026095d16bf  pop r9
00007026095d16c1  pop r8
00007026095d16c3  pop rsi
00007026095d16c4  pop rdi
00007026095d16c5  pop rdx
00007026095d16c6  pop rcx
00007026095d16c7  pop rax
00007026095d16c8  add rsp, 0x08
00007026095d16cc  jmp 0x00007026095CFBF9
00007026095d16d1  sub rsp, 0x08
00007026095d16d5  push rax
00007026095d16d6  push rcx
00007026095d16d7  push rdx
00007026095d16d8  push rdi
00007026095d16d9  push rsi
00007026095d16da  push r8
00007026095d16dc  push r9
00007026095d16de  push r10
00007026095d16e0  push r11
00007026095d16e2  sub rsp, 0xF0
00007026095d16e9  vmovaps [rsp], xmm0
00007026095d16ee  vmovaps [rsp+0x10], xmm1
00007026095d16f4  vmovaps [rsp+0x20], xmm2
00007026095d16fa  vmovaps [rsp+0x30], xmm3
00007026095d1700  vmovaps [rsp+0x40], xmm4
00007026095d1706  vmovaps [rsp+0x50], xmm5
00007026095d170c  vmovaps [rsp+0x60], xmm6
00007026095d1712  vmovaps [rsp+0x70], xmm7
00007026095d1718  vmovaps [rsp+0x80], xmm8
00007026095d1721  vmovaps [rsp+0x90], xmm9
00007026095d172a  vmovaps [rsp+0xA0], xmm10
00007026095d1733  vmovaps [rsp+0xB0], xmm12
00007026095d173c  vmovaps [rsp+0xC0], xmm13
00007026095d1745  vmovaps [rsp+0xD0], xmm14
00007026095d174e  vmovaps [rsp+0xE0], xmm15
00007026095d1757  sub rsp, 0x40
00007026095d175b  lea rdi, [rsp]
00007026095d175f  lea rsi, [rsp+0x10]
00007026095d1764  lea rdx, [rsp+0x20]
00007026095d1769  lea rcx, [rsp+0x30]
00007026095d176e  mov r8d, 0x00
00007026095d1774  lea r9, [r15+0x3A8]
00007026095d177b  movaps [rdi], xmm11
00007026095d177f  movaps [rsi], xmm9
00007026095d1783  movaps [rdx], xmm4
00007026095d1786  movaps [rcx], xmm15
00007026095d178a  mov rax, 0x58A432239A50
00007026095d1794  call rax
00007026095d1796  movaps xmm11, [rsp]
00007026095d179b  add rsp, 0x40
00007026095d179f  vmovaps xmm0, [rsp]
00007026095d17a4  vmovaps xmm1, [rsp+0x10]
00007026095d17aa  vmovaps xmm2, [rsp+0x20]
00007026095d17b0  vmovaps xmm3, [rsp+0x30]
00007026095d17b6  vmovaps xmm4, [rsp+0x40]
00007026095d17bc  vmovaps xmm5, [rsp+0x50]
00007026095d17c2  vmovaps xmm6, [rsp+0x60]
00007026095d17c8  vmovaps xmm7, [rsp+0x70]
00007026095d17ce  vmovaps xmm8, [rsp+0x80]
00007026095d17d7  vmovaps xmm9, [rsp+0x90]
00007026095d17e0  vmovaps xmm10, [rsp+0xA0]
00007026095d17e9  vmovaps xmm12, [rsp+0xB0]
00007026095d17f2  vmovaps xmm13, [rsp+0xC0]
00007026095d17fb  vmovaps xmm14, [rsp+0xD0]
00007026095d1804  vmovaps xmm15, [rsp+0xE0]
00007026095d180d  add rsp, 0xF0
00007026095d1814  pop r11
00007026095d1816  pop r10
00007026095d1818  pop r9
00007026095d181a  pop r8
00007026095d181c  pop rsi
00007026095d181d  pop rdi
00007026095d181e  pop rdx
00007026095d181f  pop rcx
00007026095d1820  pop rax
00007026095d1821  add rsp, 0x08
00007026095d1825  jmp 0x00007026095CFC22
00007026095d182a  call 0x000070260940E760
00007026095d182f  jmp 0x00007026095CFC45
00007026095d1834  call 0x0000702609407890
00007026095d1839  jmp 0x00007026095CFC4F
00007026095d183e  sub rsp, 0x08
00007026095d1842  push rax
00007026095d1843  push rcx
00007026095d1844  push rdx
00007026095d1845  push rdi
00007026095d1846  push rsi
00007026095d1847  push r8
00007026095d1849  push r9
00007026095d184b  push r10
00007026095d184d  push r11
00007026095d184f  sub rsp, 0xF0
00007026095d1856  vmovaps [rsp], xmm0
00007026095d185b  vmovaps [rsp+0x10], xmm1
00007026095d1861  vmovaps [rsp+0x20], xmm2
00007026095d1867  vmovaps [rsp+0x30], xmm3
00007026095d186d  vmovaps [rsp+0x40], xmm5
00007026095d1873  vmovaps [rsp+0x50], xmm6
00007026095d1879  vmovaps [rsp+0x60], xmm7
00007026095d187f  vmovaps [rsp+0x70], xmm8
00007026095d1885  vmovaps [rsp+0x80], xmm9
00007026095d188e  vmovaps [rsp+0x90], xmm10
00007026095d1897  vmovaps [rsp+0xA0], xmm11
00007026095d18a0  vmovaps [rsp+0xB0], xmm12
00007026095d18a9  vmovaps [rsp+0xC0], xmm13
00007026095d18b2  vmovaps [rsp+0xD0], xmm14
00007026095d18bb  vmovaps [rsp+0xE0], xmm15
00007026095d18c4  sub rsp, 0x40
00007026095d18c8  lea rdi, [rsp]
00007026095d18cc  lea rsi, [rsp+0x10]
00007026095d18d1  lea rdx, [rsp+0x20]
00007026095d18d6  lea rcx, [rsp+0x30]
00007026095d18db  mov r8d, 0x00
00007026095d18e1  lea r9, [r15+0x3A8]
00007026095d18e8  movaps [rdi], xmm4
00007026095d18eb  movaps [rsi], xmm2
00007026095d18ee  movaps [rdx], xmm14
00007026095d18f2  movaps [rcx], xmm5
00007026095d18f5  mov rax, 0x58A432239A50
00007026095d18ff  call rax
00007026095d1901  movaps xmm4, [rsp]
00007026095d1905  add rsp, 0x40
00007026095d1909  vmovaps xmm0, [rsp]
00007026095d190e  vmovaps xmm1, [rsp+0x10]
00007026095d1914  vmovaps xmm2, [rsp+0x20]
00007026095d191a  vmovaps xmm3, [rsp+0x30]
00007026095d1920  vmovaps xmm5, [rsp+0x40]
00007026095d1926  vmovaps xmm6, [rsp+0x50]
00007026095d192c  vmovaps xmm7, [rsp+0x60]
00007026095d1932  vmovaps xmm8, [rsp+0x70]
00007026095d1938  vmovaps xmm9, [rsp+0x80]
00007026095d1941  vmovaps xmm10, [rsp+0x90]
00007026095d194a  vmovaps xmm11, [rsp+0xA0]
00007026095d1953  vmovaps xmm12, [rsp+0xB0]
00007026095d195c  vmovaps xmm13, [rsp+0xC0]
00007026095d1965  vmovaps xmm14, [rsp+0xD0]
00007026095d196e  vmovaps xmm15, [rsp+0xE0]
00007026095d1977  add rsp, 0xF0
00007026095d197e  pop r11
00007026095d1980  pop r10
00007026095d1982  pop r9
00007026095d1984  pop r8
00007026095d1986  pop rsi
00007026095d1987  pop rdi
00007026095d1988  pop rdx
00007026095d1989  pop rcx
00007026095d198a  pop rax
00007026095d198b  add rsp, 0x08
00007026095d198f  jmp 0x00007026095CFC86
00007026095d1994  sub rsp, 0x08
00007026095d1998  push rax
00007026095d1999  push rcx
00007026095d199a  push rdx
00007026095d199b  push rdi
00007026095d199c  push rsi
00007026095d199d  push r8
00007026095d199f  push r9
00007026095d19a1  push r10
00007026095d19a3  push r11
00007026095d19a5  sub rsp, 0xF0
00007026095d19ac  vmovaps [rsp], xmm0
00007026095d19b1  vmovaps [rsp+0x10], xmm1
00007026095d19b7  vmovaps [rsp+0x20], xmm2
00007026095d19bd  vmovaps [rsp+0x30], xmm3
00007026095d19c3  vmovaps [rsp+0x40], xmm4
00007026095d19c9  vmovaps [rsp+0x50], xmm6
00007026095d19cf  vmovaps [rsp+0x60], xmm7
00007026095d19d5  vmovaps [rsp+0x70], xmm8
00007026095d19db  vmovaps [rsp+0x80], xmm9
00007026095d19e4  vmovaps [rsp+0x90], xmm10
00007026095d19ed  vmovaps [rsp+0xA0], xmm11
00007026095d19f6  vmovaps [rsp+0xB0], xmm12
00007026095d19ff  vmovaps [rsp+0xC0], xmm13
00007026095d1a08  vmovaps [rsp+0xD0], xmm14
00007026095d1a11  vmovaps [rsp+0xE0], xmm15
00007026095d1a1a  sub rsp, 0x40
00007026095d1a1e  lea rdi, [rsp]
00007026095d1a22  lea rsi, [rsp+0x10]
00007026095d1a27  lea rdx, [rsp+0x20]
00007026095d1a2c  lea rcx, [rsp+0x30]
00007026095d1a31  mov r8d, 0x00
00007026095d1a37  lea r9, [r15+0x3A8]
00007026095d1a3e  movaps [rdi], xmm5
00007026095d1a41  movaps [rsi], xmm8
00007026095d1a45  movaps [rdx], xmm7
00007026095d1a48  movaps [rcx], xmm14
00007026095d1a4c  mov rax, 0x58A432239A50
00007026095d1a56  call rax
00007026095d1a58  movaps xmm5, [rsp]
00007026095d1a5c  add rsp, 0x40
00007026095d1a60  vmovaps xmm0, [rsp]
00007026095d1a65  vmovaps xmm1, [rsp+0x10]
00007026095d1a6b  vmovaps xmm2, [rsp+0x20]
00007026095d1a71  vmovaps xmm3, [rsp+0x30]
00007026095d1a77  vmovaps xmm4, [rsp+0x40]
00007026095d1a7d  vmovaps xmm6, [rsp+0x50]
00007026095d1a83  vmovaps xmm7, [rsp+0x60]
00007026095d1a89  vmovaps xmm8, [rsp+0x70]
00007026095d1a8f  vmovaps xmm9, [rsp+0x80]
00007026095d1a98  vmovaps xmm10, [rsp+0x90]
00007026095d1aa1  vmovaps xmm11, [rsp+0xA0]
00007026095d1aaa  vmovaps xmm12, [rsp+0xB0]
00007026095d1ab3  vmovaps xmm13, [rsp+0xC0]
00007026095d1abc  vmovaps xmm14, [rsp+0xD0]
00007026095d1ac5  vmovaps xmm15, [rsp+0xE0]
00007026095d1ace  add rsp, 0xF0
00007026095d1ad5  pop r11
00007026095d1ad7  pop r10
00007026095d1ad9  pop r9
00007026095d1adb  pop r8
00007026095d1add  pop rsi
00007026095d1ade  pop rdi
00007026095d1adf  pop rdx
00007026095d1ae0  pop rcx
00007026095d1ae1  pop rax
00007026095d1ae2  add rsp, 0x08
00007026095d1ae6  jmp 0x00007026095CFCAE
00007026095d1aeb  sub rsp, 0x08
00007026095d1aef  push rax
00007026095d1af0  push rcx
00007026095d1af1  push rdx
00007026095d1af2  push rdi
00007026095d1af3  push rsi
00007026095d1af4  push r8
00007026095d1af6  push r9
00007026095d1af8  push r10
00007026095d1afa  push r11
00007026095d1afc  sub rsp, 0xF0
00007026095d1b03  vmovaps [rsp], xmm0
00007026095d1b08  vmovaps [rsp+0x10], xmm1
00007026095d1b0e  vmovaps [rsp+0x20], xmm2
00007026095d1b14  vmovaps [rsp+0x30], xmm3
00007026095d1b1a  vmovaps [rsp+0x40], xmm4
00007026095d1b20  vmovaps [rsp+0x50], xmm5
00007026095d1b26  vmovaps [rsp+0x60], xmm6
00007026095d1b2c  vmovaps [rsp+0x70], xmm7
00007026095d1b32  vmovaps [rsp+0x80], xmm9
00007026095d1b3b  vmovaps [rsp+0x90], xmm10
00007026095d1b44  vmovaps [rsp+0xA0], xmm11
00007026095d1b4d  vmovaps [rsp+0xB0], xmm12
00007026095d1b56  vmovaps [rsp+0xC0], xmm13
00007026095d1b5f  vmovaps [rsp+0xD0], xmm14
00007026095d1b68  vmovaps [rsp+0xE0], xmm15
00007026095d1b71  sub rsp, 0x40
00007026095d1b75  lea rdi, [rsp]
00007026095d1b79  lea rsi, [rsp+0x10]
00007026095d1b7e  lea rdx, [rsp+0x20]
00007026095d1b83  lea rcx, [rsp+0x30]
00007026095d1b88  mov r8d, 0x00
00007026095d1b8e  lea r9, [r15+0x3A8]
00007026095d1b95  movaps [rdi], xmm8
00007026095d1b99  movaps [rsi], xmm13
00007026095d1b9d  movaps [rdx], xmm6
00007026095d1ba0  movaps [rcx], xmm14
00007026095d1ba4  mov rax, 0x58A432239A50
00007026095d1bae  call rax
00007026095d1bb0  movaps xmm8, [rsp]
00007026095d1bb5  add rsp, 0x40
00007026095d1bb9  vmovaps xmm0, [rsp]
00007026095d1bbe  vmovaps xmm1, [rsp+0x10]
00007026095d1bc4  vmovaps xmm2, [rsp+0x20]
00007026095d1bca  vmovaps xmm3, [rsp+0x30]
00007026095d1bd0  vmovaps xmm4, [rsp+0x40]
00007026095d1bd6  vmovaps xmm5, [rsp+0x50]
00007026095d1bdc  vmovaps xmm6, [rsp+0x60]
00007026095d1be2  vmovaps xmm7, [rsp+0x70]
00007026095d1be8  vmovaps xmm9, [rsp+0x80]
00007026095d1bf1  vmovaps xmm10, [rsp+0x90]
00007026095d1bfa  vmovaps xmm11, [rsp+0xA0]
00007026095d1c03  vmovaps xmm12, [rsp+0xB0]
00007026095d1c0c  vmovaps xmm13, [rsp+0xC0]
00007026095d1c15  vmovaps xmm14, [rsp+0xD0]
00007026095d1c1e  vmovaps xmm15, [rsp+0xE0]
00007026095d1c27  add rsp, 0xF0
00007026095d1c2e  pop r11
00007026095d1c30  pop r10
00007026095d1c32  pop r9
00007026095d1c34  pop r8
00007026095d1c36  pop rsi
00007026095d1c37  pop rdi
00007026095d1c38  pop rdx
00007026095d1c39  pop rcx
00007026095d1c3a  pop rax
00007026095d1c3b  add rsp, 0x08
00007026095d1c3f  jmp 0x00007026095CFCD7
00007026095d1c44  sub rsp, 0x08
00007026095d1c48  push rax
00007026095d1c49  push rcx
00007026095d1c4a  push rdx
00007026095d1c4b  push rdi
00007026095d1c4c  push rsi
00007026095d1c4d  push r8
00007026095d1c4f  push r9
00007026095d1c51  push r10
00007026095d1c53  push r11
00007026095d1c55  sub rsp, 0xF0
00007026095d1c5c  vmovaps [rsp], xmm0
00007026095d1c61  vmovaps [rsp+0x10], xmm1
00007026095d1c67  vmovaps [rsp+0x20], xmm2
00007026095d1c6d  vmovaps [rsp+0x30], xmm3
00007026095d1c73  vmovaps [rsp+0x40], xmm4
00007026095d1c79  vmovaps [rsp+0x50], xmm5
00007026095d1c7f  vmovaps [rsp+0x60], xmm6
00007026095d1c85  vmovaps [rsp+0x70], xmm7
00007026095d1c8b  vmovaps [rsp+0x80], xmm8
00007026095d1c94  vmovaps [rsp+0x90], xmm9
00007026095d1c9d  vmovaps [rsp+0xA0], xmm10
00007026095d1ca6  vmovaps [rsp+0xB0], xmm11
00007026095d1caf  vmovaps [rsp+0xC0], xmm12
00007026095d1cb8  vmovaps [rsp+0xD0], xmm14
00007026095d1cc1  vmovaps [rsp+0xE0], xmm15
00007026095d1cca  sub rsp, 0x40
00007026095d1cce  lea rdi, [rsp]
00007026095d1cd2  lea rsi, [rsp+0x10]
00007026095d1cd7  lea rdx, [rsp+0x20]
00007026095d1cdc  lea rcx, [rsp+0x30]
00007026095d1ce1  mov r8d, 0x00
00007026095d1ce7  lea r9, [r15+0x3A8]
00007026095d1cee  movaps [rdi], xmm13
00007026095d1cf2  movaps [rsi], xmm11
00007026095d1cf6  movaps [rdx], xmm12
00007026095d1cfa  movaps [rcx], xmm14
00007026095d1cfe  mov rax, 0x58A432239A50
00007026095d1d08  call rax
00007026095d1d0a  movaps xmm13, [rsp]
00007026095d1d0f  add rsp, 0x40
00007026095d1d13  vmovaps xmm0, [rsp]
00007026095d1d18  vmovaps xmm1, [rsp+0x10]
00007026095d1d1e  vmovaps xmm2, [rsp+0x20]
00007026095d1d24  vmovaps xmm3, [rsp+0x30]
00007026095d1d2a  vmovaps xmm4, [rsp+0x40]
00007026095d1d30  vmovaps xmm5, [rsp+0x50]
00007026095d1d36  vmovaps xmm6, [rsp+0x60]
00007026095d1d3c  vmovaps xmm7, [rsp+0x70]
00007026095d1d42  vmovaps xmm8, [rsp+0x80]
00007026095d1d4b  vmovaps xmm9, [rsp+0x90]
00007026095d1d54  vmovaps xmm10, [rsp+0xA0]
00007026095d1d5d  vmovaps xmm11, [rsp+0xB0]
00007026095d1d66  vmovaps xmm12, [rsp+0xC0]
00007026095d1d6f  vmovaps xmm14, [rsp+0xD0]
00007026095d1d78  vmovaps xmm15, [rsp+0xE0]
00007026095d1d81  add rsp, 0xF0
00007026095d1d88  pop r11
00007026095d1d8a  pop r10
00007026095d1d8c  pop r9
00007026095d1d8e  pop r8
00007026095d1d90  pop rsi
00007026095d1d91  pop rdi
00007026095d1d92  pop rdx
00007026095d1d93  pop rcx
00007026095d1d94  pop rax
00007026095d1d95  add rsp, 0x08
00007026095d1d99  jmp 0x00007026095CFD00
00007026095d1d9e  call 0x000070260940D4E0
00007026095d1da3  jmp 0x00007026095CFD0A
00007026095d1da8  call 0x000070260940AFE0
00007026095d1dad  jmp 0x00007026095CFD14
00007026095d1db2  sub rsp, 0x08
00007026095d1db6  push rax
00007026095d1db7  push rcx
00007026095d1db8  push rdx
00007026095d1db9  push rdi
00007026095d1dba  push rsi
00007026095d1dbb  push r8
00007026095d1dbd  push r9
00007026095d1dbf  push r10
00007026095d1dc1  push r11
00007026095d1dc3  sub rsp, 0xF0
00007026095d1dca  vmovaps [rsp], xmm0
00007026095d1dcf  vmovaps [rsp+0x10], xmm1
00007026095d1dd5  vmovaps [rsp+0x20], xmm2
00007026095d1ddb  vmovaps [rsp+0x30], xmm3
00007026095d1de1  vmovaps [rsp+0x40], xmm4
00007026095d1de7  vmovaps [rsp+0x50], xmm5
00007026095d1ded  vmovaps [rsp+0x60], xmm6
00007026095d1df3  vmovaps [rsp+0x70], xmm8
00007026095d1df9  vmovaps [rsp+0x80], xmm9
00007026095d1e02  vmovaps [rsp+0x90], xmm10
00007026095d1e0b  vmovaps [rsp+0xA0], xmm11
00007026095d1e14  vmovaps [rsp+0xB0], xmm12
00007026095d1e1d  vmovaps [rsp+0xC0], xmm13
00007026095d1e26  vmovaps [rsp+0xD0], xmm14
00007026095d1e2f  vmovaps [rsp+0xE0], xmm15
00007026095d1e38  sub rsp, 0x40
00007026095d1e3c  lea rdi, [rsp]
00007026095d1e40  lea rsi, [rsp+0x10]
00007026095d1e45  lea rdx, [rsp+0x20]
00007026095d1e4a  lea rcx, [rsp+0x30]
00007026095d1e4f  mov r8d, 0x00
00007026095d1e55  lea r9, [r15+0x3A8]
00007026095d1e5c  movaps [rdi], xmm7
00007026095d1e5f  movaps [rsi], xmm4
00007026095d1e62  movaps [rdx], xmm9
00007026095d1e66  movaps [rcx], xmm11
00007026095d1e6a  mov rax, 0x58A432239A50
00007026095d1e74  call rax
00007026095d1e76  movaps xmm7, [rsp]
00007026095d1e7a  add rsp, 0x40
00007026095d1e7e  vmovaps xmm0, [rsp]
00007026095d1e83  vmovaps xmm1, [rsp+0x10]
00007026095d1e89  vmovaps xmm2, [rsp+0x20]
00007026095d1e8f  vmovaps xmm3, [rsp+0x30]
00007026095d1e95  vmovaps xmm4, [rsp+0x40]
00007026095d1e9b  vmovaps xmm5, [rsp+0x50]
00007026095d1ea1  vmovaps xmm6, [rsp+0x60]
00007026095d1ea7  vmovaps xmm8, [rsp+0x70]
00007026095d1ead  vmovaps xmm9, [rsp+0x80]
00007026095d1eb6  vmovaps xmm10, [rsp+0x90]
00007026095d1ebf  vmovaps xmm11, [rsp+0xA0]
00007026095d1ec8  vmovaps xmm12, [rsp+0xB0]
00007026095d1ed1  vmovaps xmm13, [rsp+0xC0]
00007026095d1eda  vmovaps xmm14, [rsp+0xD0]
00007026095d1ee3  vmovaps xmm15, [rsp+0xE0]
00007026095d1eec  add rsp, 0xF0
00007026095d1ef3  pop r11
00007026095d1ef5  pop r10
00007026095d1ef7  pop r9
00007026095d1ef9  pop r8
00007026095d1efb  pop rsi
00007026095d1efc  pop rdi
00007026095d1efd  pop rdx
00007026095d1efe  pop rcx
00007026095d1eff  pop rax
00007026095d1f00  add rsp, 0x08
00007026095d1f04  jmp 0x00007026095CFD4B
00007026095d1f09  sub rsp, 0x08
00007026095d1f0d  push rax
00007026095d1f0e  push rcx
00007026095d1f0f  push rdx
00007026095d1f10  push rdi
00007026095d1f11  push rsi
00007026095d1f12  push r8
00007026095d1f14  push r9
00007026095d1f16  push r10
00007026095d1f18  push r11
00007026095d1f1a  sub rsp, 0xF0
00007026095d1f21  vmovaps [rsp], xmm0
00007026095d1f26  vmovaps [rsp+0x10], xmm1
00007026095d1f2c  vmovaps [rsp+0x20], xmm2
00007026095d1f32  vmovaps [rsp+0x30], xmm3
00007026095d1f38  vmovaps [rsp+0x40], xmm4
00007026095d1f3e  vmovaps [rsp+0x50], xmm5
00007026095d1f44  vmovaps [rsp+0x60], xmm6
00007026095d1f4a  vmovaps [rsp+0x70], xmm7
00007026095d1f50  vmovaps [rsp+0x80], xmm8
00007026095d1f59  vmovaps [rsp+0x90], xmm10
00007026095d1f62  vmovaps [rsp+0xA0], xmm11
00007026095d1f6b  vmovaps [rsp+0xB0], xmm12
00007026095d1f74  vmovaps [rsp+0xC0], xmm13
00007026095d1f7d  vmovaps [rsp+0xD0], xmm14
00007026095d1f86  vmovaps [rsp+0xE0], xmm15
00007026095d1f8f  sub rsp, 0x40
00007026095d1f93  lea rdi, [rsp]
00007026095d1f97  lea rsi, [rsp+0x10]
00007026095d1f9c  lea rdx, [rsp+0x20]
00007026095d1fa1  lea rcx, [rsp+0x30]
00007026095d1fa6  mov r8d, 0x00
00007026095d1fac  lea r9, [r15+0x3A8]
00007026095d1fb3  movaps [rdi], xmm9
00007026095d1fb7  movaps [rsi], xmm5
00007026095d1fba  movaps [rdx], xmm14
00007026095d1fbe  movaps [rcx], xmm11
00007026095d1fc2  mov rax, 0x58A432239A50
00007026095d1fcc  call rax
00007026095d1fce  movaps xmm9, [rsp]
00007026095d1fd3  add rsp, 0x40
00007026095d1fd7  vmovaps xmm0, [rsp]
00007026095d1fdc  vmovaps xmm1, [rsp+0x10]
00007026095d1fe2  vmovaps xmm2, [rsp+0x20]
00007026095d1fe8  vmovaps xmm3, [rsp+0x30]
00007026095d1fee  vmovaps xmm4, [rsp+0x40]
00007026095d1ff4  vmovaps xmm5, [rsp+0x50]
00007026095d1ffa  vmovaps xmm6, [rsp+0x60]
00007026095d2000  vmovaps xmm7, [rsp+0x70]
00007026095d2006  vmovaps xmm8, [rsp+0x80]
00007026095d200f  vmovaps xmm10, [rsp+0x90]
00007026095d2018  vmovaps xmm11, [rsp+0xA0]
00007026095d2021  vmovaps xmm12, [rsp+0xB0]
00007026095d202a  vmovaps xmm13, [rsp+0xC0]
00007026095d2033  vmovaps xmm14, [rsp+0xD0]
00007026095d203c  vmovaps xmm15, [rsp+0xE0]
00007026095d2045  add rsp, 0xF0
00007026095d204c  pop r11
00007026095d204e  pop r10
00007026095d2050  pop r9
00007026095d2052  pop r8
00007026095d2054  pop rsi
00007026095d2055  pop rdi
00007026095d2056  pop rdx
00007026095d2057  pop rcx
00007026095d2058  pop rax
00007026095d2059  add rsp, 0x08
00007026095d205d  jmp 0x00007026095CFD74
00007026095d2062  sub rsp, 0x08
00007026095d2066  push rax
00007026095d2067  push rcx
00007026095d2068  push rdx
00007026095d2069  push rdi
00007026095d206a  push rsi
00007026095d206b  push r8
00007026095d206d  push r9
00007026095d206f  push r10
00007026095d2071  push r11
00007026095d2073  sub rsp, 0xF0
00007026095d207a  vmovaps [rsp], xmm0
00007026095d207f  vmovaps [rsp+0x10], xmm1
00007026095d2085  vmovaps [rsp+0x20], xmm2
00007026095d208b  vmovaps [rsp+0x30], xmm3
00007026095d2091  vmovaps [rsp+0x40], xmm4
00007026095d2097  vmovaps [rsp+0x50], xmm5
00007026095d209d  vmovaps [rsp+0x60], xmm6
00007026095d20a3  vmovaps [rsp+0x70], xmm7
00007026095d20a9  vmovaps [rsp+0x80], xmm8
00007026095d20b2  vmovaps [rsp+0x90], xmm9
00007026095d20bb  vmovaps [rsp+0xA0], xmm10
00007026095d20c4  vmovaps [rsp+0xB0], xmm12
00007026095d20cd  vmovaps [rsp+0xC0], xmm13
00007026095d20d6  vmovaps [rsp+0xD0], xmm14
00007026095d20df  vmovaps [rsp+0xE0], xmm15
00007026095d20e8  sub rsp, 0x40
00007026095d20ec  lea rdi, [rsp]
00007026095d20f0  lea rsi, [rsp+0x10]
00007026095d20f5  lea rdx, [rsp+0x20]
00007026095d20fa  lea rcx, [rsp+0x30]
00007026095d20ff  mov r8d, 0x00
00007026095d2105  lea r9, [r15+0x3A8]
00007026095d210c  movaps [rdi], xmm11
00007026095d2110  movaps [rsi], xmm8
00007026095d2114  movaps [rdx], xmm10
00007026095d2118  movaps [rcx], xmm14
00007026095d211c  mov rax, 0x58A432239A50
00007026095d2126  call rax
00007026095d2128  movaps xmm11, [rsp]
00007026095d212d  add rsp, 0x40
00007026095d2131  vmovaps xmm0, [rsp]
00007026095d2136  vmovaps xmm1, [rsp+0x10]
00007026095d213c  vmovaps xmm2, [rsp+0x20]
00007026095d2142  vmovaps xmm3, [rsp+0x30]
00007026095d2148  vmovaps xmm4, [rsp+0x40]
00007026095d214e  vmovaps xmm5, [rsp+0x50]
00007026095d2154  vmovaps xmm6, [rsp+0x60]
00007026095d215a  vmovaps xmm7, [rsp+0x70]
00007026095d2160  vmovaps xmm8, [rsp+0x80]
00007026095d2169  vmovaps xmm9, [rsp+0x90]
00007026095d2172  vmovaps xmm10, [rsp+0xA0]
00007026095d217b  vmovaps xmm12, [rsp+0xB0]
00007026095d2184  vmovaps xmm13, [rsp+0xC0]
00007026095d218d  vmovaps xmm14, [rsp+0xD0]
00007026095d2196  vmovaps xmm15, [rsp+0xE0]
00007026095d219f  add rsp, 0xF0
00007026095d21a6  pop r11
00007026095d21a8  pop r10
00007026095d21aa  pop r9
00007026095d21ac  pop r8
00007026095d21ae  pop rsi
00007026095d21af  pop rdi
00007026095d21b0  pop rdx
00007026095d21b1  pop rcx
00007026095d21b2  pop rax
00007026095d21b3  add rsp, 0x08
00007026095d21b7  jmp 0x00007026095CFD9D
00007026095d21bc  sub rsp, 0x08
00007026095d21c0  push rax
00007026095d21c1  push rcx
00007026095d21c2  push rdx
00007026095d21c3  push rdi
00007026095d21c4  push rsi
00007026095d21c5  push r8
00007026095d21c7  push r9
00007026095d21c9  push r10
00007026095d21cb  push r11
00007026095d21cd  sub rsp, 0xF0
00007026095d21d4  vmovaps [rsp], xmm0
00007026095d21d9  vmovaps [rsp+0x10], xmm1
00007026095d21df  vmovaps [rsp+0x20], xmm2
00007026095d21e5  vmovaps [rsp+0x30], xmm3
00007026095d21eb  vmovaps [rsp+0x40], xmm4
00007026095d21f1  vmovaps [rsp+0x50], xmm5
00007026095d21f7  vmovaps [rsp+0x60], xmm6
00007026095d21fd  vmovaps [rsp+0x70], xmm7
00007026095d2203  vmovaps [rsp+0x80], xmm8
00007026095d220c  vmovaps [rsp+0x90], xmm9
00007026095d2215  vmovaps [rsp+0xA0], xmm11
00007026095d221e  vmovaps [rsp+0xB0], xmm12
00007026095d2227  vmovaps [rsp+0xC0], xmm13
00007026095d2230  vmovaps [rsp+0xD0], xmm14
00007026095d2239  vmovaps [rsp+0xE0], xmm15
00007026095d2242  sub rsp, 0x40
00007026095d2246  lea rdi, [rsp]
00007026095d224a  lea rsi, [rsp+0x10]
00007026095d224f  lea rdx, [rsp+0x20]
00007026095d2254  lea rcx, [rsp+0x30]
00007026095d2259  mov r8d, 0x00
00007026095d225f  lea r9, [r15+0x3A8]
00007026095d2266  movaps [rdi], xmm10
00007026095d226a  movaps [rsi], xmm13
00007026095d226e  movaps [rdx], xmm15
00007026095d2272  movaps [rcx], xmm14
00007026095d2276  mov rax, 0x58A432239A50
00007026095d2280  call rax
00007026095d2282  movaps xmm10, [rsp]
00007026095d2287  add rsp, 0x40
00007026095d228b  vmovaps xmm0, [rsp]
00007026095d2290  vmovaps xmm1, [rsp+0x10]
00007026095d2296  vmovaps xmm2, [rsp+0x20]
00007026095d229c  vmovaps xmm3, [rsp+0x30]
00007026095d22a2  vmovaps xmm4, [rsp+0x40]
00007026095d22a8  vmovaps xmm5, [rsp+0x50]
00007026095d22ae  vmovaps xmm6, [rsp+0x60]
00007026095d22b4  vmovaps xmm7, [rsp+0x70]
00007026095d22ba  vmovaps xmm8, [rsp+0x80]
00007026095d22c3  vmovaps xmm9, [rsp+0x90]
00007026095d22cc  vmovaps xmm11, [rsp+0xA0]
00007026095d22d5  vmovaps xmm12, [rsp+0xB0]
00007026095d22de  vmovaps xmm13, [rsp+0xC0]
00007026095d22e7  vmovaps xmm14, [rsp+0xD0]
00007026095d22f0  vmovaps xmm15, [rsp+0xE0]
00007026095d22f9  add rsp, 0xF0
00007026095d2300  pop r11
00007026095d2302  pop r10
00007026095d2304  pop r9
00007026095d2306  pop r8
00007026095d2308  pop rsi
00007026095d2309  pop rdi
00007026095d230a  pop rdx
00007026095d230b  pop rcx
00007026095d230c  pop rax
00007026095d230d  add rsp, 0x08
00007026095d2311  jmp 0x00007026095CFDC6
00007026095d2316  call 0x000070260940E760
00007026095d231b  jmp 0x00007026095CFDD0
00007026095d2320  call 0x000070260940D4E0
00007026095d2325  jmp 0x00007026095CFDDA
00007026095d232a  sub rsp, 0x08
00007026095d232e  push rax
00007026095d232f  push rcx
00007026095d2330  push rdx
00007026095d2331  push rdi
00007026095d2332  push rsi
00007026095d2333  push r8
00007026095d2335  push r9
00007026095d2337  push r10
00007026095d2339  push r11
00007026095d233b  sub rsp, 0xF0
00007026095d2342  vmovaps [rsp], xmm0
00007026095d2347  vmovaps [rsp+0x10], xmm1
00007026095d234d  vmovaps [rsp+0x20], xmm2
00007026095d2353  vmovaps [rsp+0x30], xmm3
00007026095d2359  vmovaps [rsp+0x40], xmm4
00007026095d235f  vmovaps [rsp+0x50], xmm5
00007026095d2365  vmovaps [rsp+0x60], xmm7
00007026095d236b  vmovaps [rsp+0x70], xmm8
00007026095d2371  vmovaps [rsp+0x80], xmm9
00007026095d237a  vmovaps [rsp+0x90], xmm10
00007026095d2383  vmovaps [rsp+0xA0], xmm11
00007026095d238c  vmovaps [rsp+0xB0], xmm12
00007026095d2395  vmovaps [rsp+0xC0], xmm13
00007026095d239e  vmovaps [rsp+0xD0], xmm14
00007026095d23a7  vmovaps [rsp+0xE0], xmm15
00007026095d23b0  sub rsp, 0x40
00007026095d23b4  lea rdi, [rsp]
00007026095d23b8  lea rsi, [rsp+0x10]
00007026095d23bd  lea rdx, [rsp+0x20]
00007026095d23c2  lea rcx, [rsp+0x30]
00007026095d23c7  mov r8d, 0x00
00007026095d23cd  lea r9, [r15+0x3A8]
00007026095d23d4  movaps [rdi], xmm6
00007026095d23d7  movaps [rsi], xmm7
00007026095d23da  movaps [rdx], xmm8
00007026095d23de  movaps [rcx], xmm13
00007026095d23e2  mov rax, 0x58A432239A50
00007026095d23ec  call rax
00007026095d23ee  movaps xmm6, [rsp]
00007026095d23f2  add rsp, 0x40
00007026095d23f6  vmovaps xmm0, [rsp]
00007026095d23fb  vmovaps xmm1, [rsp+0x10]
00007026095d2401  vmovaps xmm2, [rsp+0x20]
00007026095d2407  vmovaps xmm3, [rsp+0x30]
00007026095d240d  vmovaps xmm4, [rsp+0x40]
00007026095d2413  vmovaps xmm5, [rsp+0x50]
00007026095d2419  vmovaps xmm7, [rsp+0x60]
00007026095d241f  vmovaps xmm8, [rsp+0x70]
00007026095d2425  vmovaps xmm9, [rsp+0x80]
00007026095d242e  vmovaps xmm10, [rsp+0x90]
00007026095d2437  vmovaps xmm11, [rsp+0xA0]
00007026095d2440  vmovaps xmm12, [rsp+0xB0]
00007026095d2449  vmovaps xmm13, [rsp+0xC0]
00007026095d2452  vmovaps xmm14, [rsp+0xD0]
00007026095d245b  vmovaps xmm15, [rsp+0xE0]
00007026095d2464  add rsp, 0xF0
00007026095d246b  pop r11
00007026095d246d  pop r10
00007026095d246f  pop r9
00007026095d2471  pop r8
00007026095d2473  pop rsi
00007026095d2474  pop rdi
00007026095d2475  pop rdx
00007026095d2476  pop rcx
00007026095d2477  pop rax
00007026095d2478  add rsp, 0x08
00007026095d247c  jmp 0x00007026095CFE04
00007026095d2481  sub rsp, 0x08
00007026095d2485  push rax
00007026095d2486  push rcx
00007026095d2487  push rdx
00007026095d2488  push rdi
00007026095d2489  push rsi
00007026095d248a  push r8
00007026095d248c  push r9
00007026095d248e  push r10
00007026095d2490  push r11
00007026095d2492  sub rsp, 0xF0
00007026095d2499  vmovaps [rsp], xmm0
00007026095d249e  vmovaps [rsp+0x10], xmm1
00007026095d24a4  vmovaps [rsp+0x20], xmm2
00007026095d24aa  vmovaps [rsp+0x30], xmm3
00007026095d24b0  vmovaps [rsp+0x40], xmm4
00007026095d24b6  vmovaps [rsp+0x50], xmm5
00007026095d24bc  vmovaps [rsp+0x60], xmm6
00007026095d24c2  vmovaps [rsp+0x70], xmm7
00007026095d24c8  vmovaps [rsp+0x80], xmm9
00007026095d24d1  vmovaps [rsp+0x90], xmm10
00007026095d24da  vmovaps [rsp+0xA0], xmm11
00007026095d24e3  vmovaps [rsp+0xB0], xmm12
00007026095d24ec  vmovaps [rsp+0xC0], xmm13
00007026095d24f5  vmovaps [rsp+0xD0], xmm14
00007026095d24fe  vmovaps [rsp+0xE0], xmm15
00007026095d2507  sub rsp, 0x40
00007026095d250b  lea rdi, [rsp]
00007026095d250f  lea rsi, [rsp+0x10]
00007026095d2514  lea rdx, [rsp+0x20]
00007026095d2519  lea rcx, [rsp+0x30]
00007026095d251e  mov r8d, 0x00
00007026095d2524  lea r9, [r15+0x3A8]
00007026095d252b  movaps [rdi], xmm8
00007026095d252f  movaps [rsi], xmm9
00007026095d2533  movaps [rdx], xmm1
00007026095d2536  movaps [rcx], xmm13
00007026095d253a  mov rax, 0x58A432239A50
00007026095d2544  call rax
00007026095d2546  movaps xmm8, [rsp]
00007026095d254b  add rsp, 0x40
00007026095d254f  vmovaps xmm0, [rsp]
00007026095d2554  vmovaps xmm1, [rsp+0x10]
00007026095d255a  vmovaps xmm2, [rsp+0x20]
00007026095d2560  vmovaps xmm3, [rsp+0x30]
00007026095d2566  vmovaps xmm4, [rsp+0x40]
00007026095d256c  vmovaps xmm5, [rsp+0x50]
00007026095d2572  vmovaps xmm6, [rsp+0x60]
00007026095d2578  vmovaps xmm7, [rsp+0x70]
00007026095d257e  vmovaps xmm9, [rsp+0x80]
00007026095d2587  vmovaps xmm10, [rsp+0x90]
00007026095d2590  vmovaps xmm11, [rsp+0xA0]
00007026095d2599  vmovaps xmm12, [rsp+0xB0]
00007026095d25a2  vmovaps xmm13, [rsp+0xC0]
00007026095d25ab  vmovaps xmm14, [rsp+0xD0]
00007026095d25b4  vmovaps xmm15, [rsp+0xE0]
00007026095d25bd  add rsp, 0xF0
00007026095d25c4  pop r11
00007026095d25c6  pop r10
00007026095d25c8  pop r9
00007026095d25ca  pop r8
00007026095d25cc  pop rsi
00007026095d25cd  pop rdi
00007026095d25ce  pop rdx
00007026095d25cf  pop rcx
00007026095d25d0  pop rax
00007026095d25d1  add rsp, 0x08
00007026095d25d5  jmp 0x00007026095CFE2A
00007026095d25da  sub rsp, 0x08
00007026095d25de  push rax
00007026095d25df  push rcx
00007026095d25e0  push rdx
00007026095d25e1  push rdi
00007026095d25e2  push rsi
00007026095d25e3  push r8
00007026095d25e5  push r9
00007026095d25e7  push r10
00007026095d25e9  push r11
00007026095d25eb  sub rsp, 0xF0
00007026095d25f2  vmovaps [rsp], xmm0
00007026095d25f7  vmovaps [rsp+0x10], xmm1
00007026095d25fd  vmovaps [rsp+0x20], xmm2
00007026095d2603  vmovaps [rsp+0x30], xmm3
00007026095d2609  vmovaps [rsp+0x40], xmm4
00007026095d260f  vmovaps [rsp+0x50], xmm5
00007026095d2615  vmovaps [rsp+0x60], xmm6
00007026095d261b  vmovaps [rsp+0x70], xmm7
00007026095d2621  vmovaps [rsp+0x80], xmm8
00007026095d262a  vmovaps [rsp+0x90], xmm9
00007026095d2633  vmovaps [rsp+0xA0], xmm10
00007026095d263c  vmovaps [rsp+0xB0], xmm11
00007026095d2645  vmovaps [rsp+0xC0], xmm12
00007026095d264e  vmovaps [rsp+0xD0], xmm14
00007026095d2657  vmovaps [rsp+0xE0], xmm15
00007026095d2660  sub rsp, 0x40
00007026095d2664  lea rdi, [rsp]
00007026095d2668  lea rsi, [rsp+0x10]
00007026095d266d  lea rdx, [rsp+0x20]
00007026095d2672  lea rcx, [rsp+0x30]
00007026095d2677  mov r8d, 0x00
00007026095d267d  lea r9, [r15+0x3A8]
00007026095d2684  movaps [rdi], xmm13
00007026095d2688  movaps [rsi], xmm11
00007026095d268c  movaps [rdx], xmm12
00007026095d2690  movaps [rcx], xmm1
00007026095d2693  mov rax, 0x58A432239A50
00007026095d269d  call rax
00007026095d269f  movaps xmm13, [rsp]
00007026095d26a4  add rsp, 0x40
00007026095d26a8  vmovaps xmm0, [rsp]
00007026095d26ad  vmovaps xmm1, [rsp+0x10]
00007026095d26b3  vmovaps xmm2, [rsp+0x20]
00007026095d26b9  vmovaps xmm3, [rsp+0x30]
00007026095d26bf  vmovaps xmm4, [rsp+0x40]
00007026095d26c5  vmovaps xmm5, [rsp+0x50]
00007026095d26cb  vmovaps xmm6, [rsp+0x60]
00007026095d26d1  vmovaps xmm7, [rsp+0x70]
00007026095d26d7  vmovaps xmm8, [rsp+0x80]
00007026095d26e0  vmovaps xmm9, [rsp+0x90]
00007026095d26e9  vmovaps xmm10, [rsp+0xA0]
00007026095d26f2  vmovaps xmm11, [rsp+0xB0]
00007026095d26fb  vmovaps xmm12, [rsp+0xC0]
00007026095d2704  vmovaps xmm14, [rsp+0xD0]
00007026095d270d  vmovaps xmm15, [rsp+0xE0]
00007026095d2716  add rsp, 0xF0
00007026095d271d  pop r11
00007026095d271f  pop r10
00007026095d2721  pop r9
00007026095d2723  pop r8
00007026095d2725  pop rsi
00007026095d2726  pop rdi
00007026095d2727  pop rdx
00007026095d2728  pop rcx
00007026095d2729  pop rax
00007026095d272a  add rsp, 0x08
00007026095d272e  jmp 0x00007026095CFE50
00007026095d2733  sub rsp, 0x08
00007026095d2737  push rax
00007026095d2738  push rcx
00007026095d2739  push rdx
00007026095d273a  push rdi
00007026095d273b  push rsi
00007026095d273c  push r8
00007026095d273e  push r9
00007026095d2740  push r10
00007026095d2742  push r11
00007026095d2744  sub rsp, 0xF0
00007026095d274b  vmovaps [rsp], xmm0
00007026095d2750  vmovaps [rsp+0x10], xmm1
00007026095d2756  vmovaps [rsp+0x20], xmm2
00007026095d275c  vmovaps [rsp+0x30], xmm3
00007026095d2762  vmovaps [rsp+0x40], xmm4
00007026095d2768  vmovaps [rsp+0x50], xmm5
00007026095d276e  vmovaps [rsp+0x60], xmm6
00007026095d2774  vmovaps [rsp+0x70], xmm7
00007026095d277a  vmovaps [rsp+0x80], xmm8
00007026095d2783  vmovaps [rsp+0x90], xmm9
00007026095d278c  vmovaps [rsp+0xA0], xmm10
00007026095d2795  vmovaps [rsp+0xB0], xmm11
00007026095d279e  vmovaps [rsp+0xC0], xmm13
00007026095d27a7  vmovaps [rsp+0xD0], xmm14
00007026095d27b0  vmovaps [rsp+0xE0], xmm15
00007026095d27b9  sub rsp, 0x40
00007026095d27bd  lea rdi, [rsp]
00007026095d27c1  lea rsi, [rsp+0x10]
00007026095d27c6  lea rdx, [rsp+0x20]
00007026095d27cb  lea rcx, [rsp+0x30]
00007026095d27d0  mov r8d, 0x00
00007026095d27d6  lea r9, [r15+0x3A8]
00007026095d27dd  movaps [rdi], xmm12
00007026095d27e1  movaps [rsi], xmm10
00007026095d27e5  movaps [rdx], xmm14
00007026095d27e9  movaps [rcx], xmm1
00007026095d27ec  mov rax, 0x58A432239A50
00007026095d27f6  call rax
00007026095d27f8  movaps xmm12, [rsp]
00007026095d27fd  add rsp, 0x40
00007026095d2801  vmovaps xmm0, [rsp]
00007026095d2806  vmovaps xmm1, [rsp+0x10]
00007026095d280c  vmovaps xmm2, [rsp+0x20]
00007026095d2812  vmovaps xmm3, [rsp+0x30]
00007026095d2818  vmovaps xmm4, [rsp+0x40]
00007026095d281e  vmovaps xmm5, [rsp+0x50]
00007026095d2824  vmovaps xmm6, [rsp+0x60]
00007026095d282a  vmovaps xmm7, [rsp+0x70]
00007026095d2830  vmovaps xmm8, [rsp+0x80]
00007026095d2839  vmovaps xmm9, [rsp+0x90]
00007026095d2842  vmovaps xmm10, [rsp+0xA0]
00007026095d284b  vmovaps xmm11, [rsp+0xB0]
00007026095d2854  vmovaps xmm13, [rsp+0xC0]
00007026095d285d  vmovaps xmm14, [rsp+0xD0]
00007026095d2866  vmovaps xmm15, [rsp+0xE0]
00007026095d286f  add rsp, 0xF0
00007026095d2876  pop r11
00007026095d2878  pop r10
00007026095d287a  pop r9
00007026095d287c  pop r8
00007026095d287e  pop rsi
00007026095d287f  pop rdi
00007026095d2880  pop rdx
00007026095d2881  pop rcx
00007026095d2882  pop rax
00007026095d2883  add rsp, 0x08
00007026095d2887  jmp 0x00007026095CFE76
00007026095d288c  call 0x00007026093FF430
00007026095d2891  jmp 0x00007026095CFE83
00007026095d2896  call 0x000070260940D4E0
00007026095d289b  jmp 0x00007026095CFE90
00007026095d28a0  sub rsp, 0x08
00007026095d28a4  push rax
00007026095d28a5  push rcx
00007026095d28a6  push rdx
00007026095d28a7  push rdi
00007026095d28a8  push rsi
00007026095d28a9  push r8
00007026095d28ab  push r9
00007026095d28ad  push r10
00007026095d28af  push r11
00007026095d28b1  sub rsp, 0xF0
00007026095d28b8  vmovaps [rsp], xmm0
00007026095d28bd  vmovaps [rsp+0x10], xmm1
00007026095d28c3  vmovaps [rsp+0x20], xmm2
00007026095d28c9  vmovaps [rsp+0x30], xmm3
00007026095d28cf  vmovaps [rsp+0x40], xmm4
00007026095d28d5  vmovaps [rsp+0x50], xmm5
00007026095d28db  vmovaps [rsp+0x60], xmm6
00007026095d28e1  vmovaps [rsp+0x70], xmm7
00007026095d28e7  vmovaps [rsp+0x80], xmm8
00007026095d28f0  vmovaps [rsp+0x90], xmm9
00007026095d28f9  vmovaps [rsp+0xA0], xmm11
00007026095d2902  vmovaps [rsp+0xB0], xmm12
00007026095d290b  vmovaps [rsp+0xC0], xmm13
00007026095d2914  vmovaps [rsp+0xD0], xmm14
00007026095d291d  vmovaps [rsp+0xE0], xmm15
00007026095d2926  sub rsp, 0x40
00007026095d292a  lea rdi, [rsp]
00007026095d292e  lea rsi, [rsp+0x10]
00007026095d2933  lea rdx, [rsp+0x20]
00007026095d2938  lea rcx, [rsp+0x30]
00007026095d293d  mov r8d, 0x00
00007026095d2943  lea r9, [r15+0x3A8]
00007026095d294a  movaps [rdi], xmm10
00007026095d294e  movaps [rsi], xmm6
00007026095d2951  movaps [rdx], xmm15
00007026095d2955  movaps [rcx], xmm11
00007026095d2959  mov rax, 0x58A432239A50
00007026095d2963  call rax
00007026095d2965  movaps xmm10, [rsp]
00007026095d296a  add rsp, 0x40
00007026095d296e  vmovaps xmm0, [rsp]
00007026095d2973  vmovaps xmm1, [rsp+0x10]
00007026095d2979  vmovaps xmm2, [rsp+0x20]
00007026095d297f  vmovaps xmm3, [rsp+0x30]
00007026095d2985  vmovaps xmm4, [rsp+0x40]
00007026095d298b  vmovaps xmm5, [rsp+0x50]
00007026095d2991  vmovaps xmm6, [rsp+0x60]
00007026095d2997  vmovaps xmm7, [rsp+0x70]
00007026095d299d  vmovaps xmm8, [rsp+0x80]
00007026095d29a6  vmovaps xmm9, [rsp+0x90]
00007026095d29af  vmovaps xmm11, [rsp+0xA0]
00007026095d29b8  vmovaps xmm12, [rsp+0xB0]
00007026095d29c1  vmovaps xmm13, [rsp+0xC0]
00007026095d29ca  vmovaps xmm14, [rsp+0xD0]
00007026095d29d3  vmovaps xmm15, [rsp+0xE0]
00007026095d29dc  add rsp, 0xF0
00007026095d29e3  pop r11
00007026095d29e5  pop r10
00007026095d29e7  pop r9
00007026095d29e9  pop r8
00007026095d29eb  pop rsi
00007026095d29ec  pop rdi
00007026095d29ed  pop rdx
00007026095d29ee  pop rcx
00007026095d29ef  pop rax
00007026095d29f0  add rsp, 0x08
00007026095d29f4  jmp 0x00007026095CFEC9
00007026095d29f9  call 0x000070260940E760
00007026095d29fe  jmp 0x00007026095CFEDB
00007026095d2a03  sub rsp, 0x08
00007026095d2a07  push rax
00007026095d2a08  push rcx
00007026095d2a09  push rdx
00007026095d2a0a  push rdi
00007026095d2a0b  push rsi
00007026095d2a0c  push r8
00007026095d2a0e  push r9
00007026095d2a10  push r10
00007026095d2a12  push r11
00007026095d2a14  sub rsp, 0xF0
00007026095d2a1b  vmovaps [rsp], xmm0
00007026095d2a20  vmovaps [rsp+0x10], xmm1
00007026095d2a26  vmovaps [rsp+0x20], xmm2
00007026095d2a2c  vmovaps [rsp+0x30], xmm3
00007026095d2a32  vmovaps [rsp+0x40], xmm4
00007026095d2a38  vmovaps [rsp+0x50], xmm5
00007026095d2a3e  vmovaps [rsp+0x60], xmm6
00007026095d2a44  vmovaps [rsp+0x70], xmm7
00007026095d2a4a  vmovaps [rsp+0x80], xmm8
00007026095d2a53  vmovaps [rsp+0x90], xmm10
00007026095d2a5c  vmovaps [rsp+0xA0], xmm11
00007026095d2a65  vmovaps [rsp+0xB0], xmm12
00007026095d2a6e  vmovaps [rsp+0xC0], xmm13
00007026095d2a77  vmovaps [rsp+0xD0], xmm14
00007026095d2a80  vmovaps [rsp+0xE0], xmm15
00007026095d2a89  sub rsp, 0x40
00007026095d2a8d  lea rdi, [rsp]
00007026095d2a91  lea rsi, [rsp+0x10]
00007026095d2a96  lea rdx, [rsp+0x20]
00007026095d2a9b  lea rcx, [rsp+0x30]
00007026095d2aa0  mov r8d, 0x00
00007026095d2aa6  lea r9, [r15+0x3A8]
00007026095d2aad  movaps [rdi], xmm9
00007026095d2ab1  movaps [rsi], xmm8
00007026095d2ab5  movaps [rdx], xmm14
00007026095d2ab9  movaps [rcx], xmm11
00007026095d2abd  mov rax, 0x58A432239A50
00007026095d2ac7  call rax
00007026095d2ac9  movaps xmm9, [rsp]
00007026095d2ace  add rsp, 0x40
00007026095d2ad2  vmovaps xmm0, [rsp]
00007026095d2ad7  vmovaps xmm1, [rsp+0x10]
00007026095d2add  vmovaps xmm2, [rsp+0x20]
00007026095d2ae3  vmovaps xmm3, [rsp+0x30]
00007026095d2ae9  vmovaps xmm4, [rsp+0x40]
00007026095d2aef  vmovaps xmm5, [rsp+0x50]
00007026095d2af5  vmovaps xmm6, [rsp+0x60]
00007026095d2afb  vmovaps xmm7, [rsp+0x70]
00007026095d2b01  vmovaps xmm8, [rsp+0x80]
00007026095d2b0a  vmovaps xmm10, [rsp+0x90]
00007026095d2b13  vmovaps xmm11, [rsp+0xA0]
00007026095d2b1c  vmovaps xmm12, [rsp+0xB0]
00007026095d2b25  vmovaps xmm13, [rsp+0xC0]
00007026095d2b2e  vmovaps xmm14, [rsp+0xD0]
00007026095d2b37  vmovaps xmm15, [rsp+0xE0]
00007026095d2b40  add rsp, 0xF0
00007026095d2b47  pop r11
00007026095d2b49  pop r10
00007026095d2b4b  pop r9
00007026095d2b4d  pop r8
00007026095d2b4f  pop rsi
00007026095d2b50  pop rdi
00007026095d2b51  pop rdx
00007026095d2b52  pop rcx
00007026095d2b53  pop rax
00007026095d2b54  add rsp, 0x08
00007026095d2b58  jmp 0x00007026095CFF0C
00007026095d2b5d  sub rsp, 0x08
00007026095d2b61  push rax
00007026095d2b62  push rcx
00007026095d2b63  push rdx
00007026095d2b64  push rdi
00007026095d2b65  push rsi
00007026095d2b66  push r8
00007026095d2b68  push r9
00007026095d2b6a  push r10
00007026095d2b6c  push r11
00007026095d2b6e  sub rsp, 0xF0
00007026095d2b75  vmovaps [rsp], xmm0
00007026095d2b7a  vmovaps [rsp+0x10], xmm1
00007026095d2b80  vmovaps [rsp+0x20], xmm2
00007026095d2b86  vmovaps [rsp+0x30], xmm3
00007026095d2b8c  vmovaps [rsp+0x40], xmm4
00007026095d2b92  vmovaps [rsp+0x50], xmm5
00007026095d2b98  vmovaps [rsp+0x60], xmm6
00007026095d2b9e  vmovaps [rsp+0x70], xmm7
00007026095d2ba4  vmovaps [rsp+0x80], xmm8
00007026095d2bad  vmovaps [rsp+0x90], xmm9
00007026095d2bb6  vmovaps [rsp+0xA0], xmm10
00007026095d2bbf  vmovaps [rsp+0xB0], xmm12
00007026095d2bc8  vmovaps [rsp+0xC0], xmm13
00007026095d2bd1  vmovaps [rsp+0xD0], xmm14
00007026095d2bda  vmovaps [rsp+0xE0], xmm15
00007026095d2be3  sub rsp, 0x40
00007026095d2be7  lea rdi, [rsp]
00007026095d2beb  lea rsi, [rsp+0x10]
00007026095d2bf0  lea rdx, [rsp+0x20]
00007026095d2bf5  lea rcx, [rsp+0x30]
00007026095d2bfa  mov r8d, 0x00
00007026095d2c00  lea r9, [r15+0x3A8]
00007026095d2c07  movaps [rdi], xmm11
00007026095d2c0b  movaps [rsi], xmm13
00007026095d2c0f  movaps [rdx], xmm1
00007026095d2c12  movaps [rcx], xmm14
00007026095d2c16  mov rax, 0x58A432239A50
00007026095d2c20  call rax
00007026095d2c22  movaps xmm11, [rsp]
00007026095d2c27  add rsp, 0x40
00007026095d2c2b  vmovaps xmm0, [rsp]
00007026095d2c30  vmovaps xmm1, [rsp+0x10]
00007026095d2c36  vmovaps xmm2, [rsp+0x20]
00007026095d2c3c  vmovaps xmm3, [rsp+0x30]
00007026095d2c42  vmovaps xmm4, [rsp+0x40]
00007026095d2c48  vmovaps xmm5, [rsp+0x50]
00007026095d2c4e  vmovaps xmm6, [rsp+0x60]
00007026095d2c54  vmovaps xmm7, [rsp+0x70]
00007026095d2c5a  vmovaps xmm8, [rsp+0x80]
00007026095d2c63  vmovaps xmm9, [rsp+0x90]
00007026095d2c6c  vmovaps xmm10, [rsp+0xA0]
00007026095d2c75  vmovaps xmm12, [rsp+0xB0]
00007026095d2c7e  vmovaps xmm13, [rsp+0xC0]
00007026095d2c87  vmovaps xmm14, [rsp+0xD0]
00007026095d2c90  vmovaps xmm15, [rsp+0xE0]
00007026095d2c99  add rsp, 0xF0
00007026095d2ca0  pop r11
00007026095d2ca2  pop r10
00007026095d2ca4  pop r9
00007026095d2ca6  pop r8
00007026095d2ca8  pop rsi
00007026095d2ca9  pop rdi
00007026095d2caa  pop rdx
00007026095d2cab  pop rcx
00007026095d2cac  pop rax
00007026095d2cad  add rsp, 0x08
00007026095d2cb1  jmp 0x00007026095CFF3D
00007026095d2cb6  sub rsp, 0x08
00007026095d2cba  push rax
00007026095d2cbb  push rcx
00007026095d2cbc  push rdx
00007026095d2cbd  push rdi
00007026095d2cbe  push rsi
00007026095d2cbf  push r8
00007026095d2cc1  push r9
00007026095d2cc3  push r10
00007026095d2cc5  push r11
00007026095d2cc7  sub rsp, 0xF0
00007026095d2cce  vmovaps [rsp], xmm0
00007026095d2cd3  vmovaps [rsp+0x10], xmm1
00007026095d2cd9  vmovaps [rsp+0x20], xmm2
00007026095d2cdf  vmovaps [rsp+0x30], xmm3
00007026095d2ce5  vmovaps [rsp+0x40], xmm4
00007026095d2ceb  vmovaps [rsp+0x50], xmm5
00007026095d2cf1  vmovaps [rsp+0x60], xmm6
00007026095d2cf7  vmovaps [rsp+0x70], xmm7
00007026095d2cfd  vmovaps [rsp+0x80], xmm8
00007026095d2d06  vmovaps [rsp+0x90], xmm9
00007026095d2d0f  vmovaps [rsp+0xA0], xmm10
00007026095d2d18  vmovaps [rsp+0xB0], xmm11
00007026095d2d21  vmovaps [rsp+0xC0], xmm12
00007026095d2d2a  vmovaps [rsp+0xD0], xmm13
00007026095d2d33  vmovaps [rsp+0xE0], xmm15
00007026095d2d3c  sub rsp, 0x40
00007026095d2d40  lea rdi, [rsp]
00007026095d2d44  lea rsi, [rsp+0x10]
00007026095d2d49  lea rdx, [rsp+0x20]
00007026095d2d4e  lea rcx, [rsp+0x30]
00007026095d2d53  mov r8d, 0x00
00007026095d2d59  lea r9, [r15+0x3A8]
00007026095d2d60  movaps [rdi], xmm14
00007026095d2d64  movaps [rsi], xmm12
00007026095d2d68  movaps [rdx], xmm15
00007026095d2d6c  movaps [rcx], xmm1
00007026095d2d6f  mov rax, 0x58A432239A50
00007026095d2d79  call rax
00007026095d2d7b  movaps xmm14, [rsp]
00007026095d2d80  add rsp, 0x40
00007026095d2d84  vmovaps xmm0, [rsp]
00007026095d2d89  vmovaps xmm1, [rsp+0x10]
00007026095d2d8f  vmovaps xmm2, [rsp+0x20]
00007026095d2d95  vmovaps xmm3, [rsp+0x30]
00007026095d2d9b  vmovaps xmm4, [rsp+0x40]
00007026095d2da1  vmovaps xmm5, [rsp+0x50]
00007026095d2da7  vmovaps xmm6, [rsp+0x60]
00007026095d2dad  vmovaps xmm7, [rsp+0x70]
00007026095d2db3  vmovaps xmm8, [rsp+0x80]
00007026095d2dbc  vmovaps xmm9, [rsp+0x90]
00007026095d2dc5  vmovaps xmm10, [rsp+0xA0]
00007026095d2dce  vmovaps xmm11, [rsp+0xB0]
00007026095d2dd7  vmovaps xmm12, [rsp+0xC0]
00007026095d2de0  vmovaps xmm13, [rsp+0xD0]
00007026095d2de9  vmovaps xmm15, [rsp+0xE0]
00007026095d2df2  add rsp, 0xF0
00007026095d2df9  pop r11
00007026095d2dfb  pop r10
00007026095d2dfd  pop r9
00007026095d2dff  pop r8
00007026095d2e01  pop rsi
00007026095d2e02  pop rdi
00007026095d2e03  pop rdx
00007026095d2e04  pop rcx
00007026095d2e05  pop rax
00007026095d2e06  add rsp, 0x08
00007026095d2e0a  jmp 0x00007026095CFF6E
00007026095d2e0f  call 0x00007026094079B0
00007026095d2e14  jmp 0x00007026095CFF81
00007026095d2e19  call 0x0000702609409E90
00007026095d2e1e  jmp 0x00007026095CFF8C
00007026095d2e23  call 0x0000702609408C20
00007026095d2e28  jmp 0x00007026095CFF97
00007026095d2e2d  call 0x000070260940D600
00007026095d2e32  jmp 0x00007026095CFFA2
00007026095d2e37  int3
00007026095d2e38  nop [rax+rax*1], eax
00007026095d2e40  mov rax, [r15+0x40]
00007026095d2e44  mov r14, [r15+0x58]
00007026095d2e48  lea r12, [rax+r14*1]
00007026095d2e4c  vxorps xmm1, xmm1, xmm1
00007026095d2e50  vpbroadcastq xmm1, xmm1
00007026095d2e55  vxorps xmm15, xmm15, xmm15
00007026095d2e5a  vpbroadcastq xmm15, xmm15
00007026095d2e5f  lea rax, [r12+0x30]
00007026095d2e64  mov r11, [r13+rax*1]
00007026095d2e69  lea rax, [r12+0x38]
00007026095d2e6e  mov r10, [r13+rax*1]
00007026095d2e73  movq xmm14, r11
00007026095d2e78  movq xmm13, r10
00007026095d2e7d  movq xmm14, xmm14
00007026095d2e82  movq xmm13, xmm13
00007026095d2e87  vmovaps [rsp+0x10], xmm13
00007026095d2e8d  movq xmm13, xmm13
00007026095d2e92  movaps [r15+0x270], xmm13
00007026095d2e9a  movaps xmm13, [r15+0x160]
00007026095d2ea2  vmovaps [rsp+0x20], xmm13
00007026095d2ea8  vmovaps xmm12, [rsp+0x20]
00007026095d2eae  por xmm13, xmm12
00007026095d2eb3  lea rax, [r12+0x20]
00007026095d2eb8  mov r11, [r13+rax*1]
00007026095d2ebd  lea rax, [r12+0x28]
00007026095d2ec2  mov r10, [r13+rax*1]
00007026095d2ec7  movq xmm12, r11
00007026095d2ecc  movq xmm11, r10
00007026095d2ed1  movq xmm12, xmm12
00007026095d2ed6  movq xmm11, xmm11
00007026095d2edb  movaps xmm10, [r15+0x2F0]
00007026095d2ee3  vmovaps [rsp+0x20], xmm10
00007026095d2ee9  vmovaps xmm9, [rsp+0x20]
00007026095d2eef  por xmm10, xmm9
00007026095d2ef4  movaps xmm9, [r15+0x2D0]
00007026095d2efc  vmovaps [rsp+0x20], xmm9
00007026095d2f02  vmovaps xmm8, [rsp+0x20]
00007026095d2f08  por xmm9, xmm8
00007026095d2f0d  movaps xmm8, [r15+0x300]
00007026095d2f15  vmovaps [rsp+0x20], xmm8
00007026095d2f1b  vmovaps xmm7, [rsp+0x20]
00007026095d2f21  por xmm8, xmm7
00007026095d2f26  movaps xmm7, [r15+0x2B0]
00007026095d2f2e  vmovaps [rsp+0x20], xmm7
00007026095d2f34  vmovaps xmm6, [rsp+0x20]
00007026095d2f3a  por xmm7, xmm6
00007026095d2f3e  movaps xmm6, [r15+0x180]
00007026095d2f46  vmovaps [rsp+0x20], xmm6
00007026095d2f4c  vmovaps xmm5, [rsp+0x20]
00007026095d2f52  por xmm6, xmm5
00007026095d2f56  lea rax, [r12+0x10]
00007026095d2f5b  mov r11, [r13+rax*1]
00007026095d2f60  lea rax, [r12+0x18]
00007026095d2f65  mov r10, [r13+rax*1]
00007026095d2f6a  movq xmm5, r11
00007026095d2f6f  movq xmm4, r10
00007026095d2f74  movq xmm5, xmm5
00007026095d2f78  movq xmm4, xmm4
00007026095d2f7c  movaps xmm3, [r15+0x200]
00007026095d2f84  vmovaps [rsp+0x20], xmm3
00007026095d2f8a  vmovaps xmm2, [rsp+0x20]
00007026095d2f90  por xmm3, xmm2
00007026095d2f94  movaps xmm2, [r15+0x1F0]
00007026095d2f9c  vmovaps [rsp+0x20], xmm2
00007026095d2fa2  vmovaps [rsp+0x30], xmm1
00007026095d2fa8  vmovaps xmm1, [rsp+0x20]
00007026095d2fae  por xmm2, xmm1
00007026095d2fb2  movaps xmm1, [r15+0x2E0]
00007026095d2fba  vmovaps [rsp+0x20], xmm1
00007026095d2fc0  vmovaps [rsp+0x40], xmm15
00007026095d2fc6  vmovaps xmm15, [rsp+0x20]
00007026095d2fcc  por xmm1, xmm15
00007026095d2fd1  movaps xmm15, [r15+0x2A0]
00007026095d2fd9  vmovaps [rsp+0x20], xmm15
00007026095d2fdf  vmovaps [rsp+0x50], xmm1
00007026095d2fe5  vmovaps xmm1, [rsp+0x20]
00007026095d2feb  por xmm15, xmm1
00007026095d2ff0  movaps xmm1, [r15+0x280]
00007026095d2ff8  vmovaps [rsp+0x20], xmm1
00007026095d2ffe  vmovaps [rsp+0x60], xmm15
00007026095d3004  vmovaps xmm15, [rsp+0x20]
00007026095d300a  por xmm1, xmm15
00007026095d300f  movaps xmm15, [r15+0x1C0]
00007026095d3017  vmovaps [rsp+0x20], xmm15
00007026095d301d  vmovaps [rsp+0x70], xmm1
00007026095d3023  vmovaps xmm1, [rsp+0x20]
00007026095d3029  por xmm15, xmm1
00007026095d302e  movaps xmm1, [r15+0x210]
00007026095d3036  vmovaps [rsp+0x20], xmm1
00007026095d303c  vmovaps [rsp+0x80], xmm15
00007026095d3045  vmovaps xmm15, [rsp+0x20]
00007026095d304b  por xmm1, xmm15
00007026095d3050  mov rax, [r13+r12*1]
00007026095d3055  vmovq xmm15, rax
00007026095d305a  vpbroadcastq xmm15, xmm15
00007026095d305f  vmovaps [rsp+0x20], xmm1
00007026095d3065  vxorps xmm1, xmm1, xmm1
00007026095d3069  vpbroadcastq xmm1, xmm1
00007026095d306e  mov rax, [r15+0xF8]
00007026095d3075  vmovaps [rsp+0x90], xmm1
00007026095d307e  movups xmm1, [r13+rax*1]
00007026095d3084  vmovaps [rsp+0xA0], xmm1
00007026095d308d  vxorps xmm1, xmm1, xmm1
00007026095d3091  vpbroadcastq xmm1, xmm1
00007026095d3096  lea r11, [r12+0x08]
00007026095d309b  mov r12, [r13+r11*1]
00007026095d30a0  vmovaps [rsp+0xB0], xmm1
00007026095d30a9  movq xmm1, r12
00007026095d30ae  movaps [r15+0x240], xmm1
00007026095d30b6  mov r12, [r15+0x50]
00007026095d30ba  lea r11, [r12+r14*1]
00007026095d30be  mov [r15+0x60], r11
00007026095d30c2  lea r12, [r14+0x40]
00007026095d30c6  mov [r15+0x58], r12
00007026095d30ca  vmovaps xmm1, [rsp+0x30]
00007026095d30d0  vmovaps [rsp+0x30], xmm15
00007026095d30d6  vmovaps xmm15, [rsp+0xA0]
00007026095d30df  vmovaps [rsp+0xA0], xmm14
00007026095d30e8  vmovaps xmm14, [rsp+0x30]
00007026095d30ee  vmovaps [rsp+0x30], xmm13
00007026095d30f4  vmovaps [rsp+0xC0], xmm12
00007026095d30fd  movaps xmm13, xmm1
00007026095d3101  vfmadd231pd xmm13, xmm15, xmm14
00007026095d3106  vcmppd xmm12, xmm13, xmm13, 0x03
00007026095d310c  vptest xmm12, xmm12
00007026095d3111  jnz 0x00007026095D3BEA
00007026095d3117  movaps xmm1, [r15+0x250]
00007026095d311f  vmovaps xmm15, [rsp+0x40]
00007026095d3125  vmovaps [rsp+0x40], xmm13
00007026095d312b  movaps xmm12, xmm15
00007026095d312f  vfmadd231pd xmm12, xmm1, xmm14
00007026095d3134  vcmppd xmm13, xmm12, xmm12, 0x03
00007026095d313a  vptest xmm13, xmm13
00007026095d313f  jnz 0x00007026095D3D43
00007026095d3145  movaps xmm15, [r15+0x1E0]
00007026095d314d  vmovaps [rsp+0xD0], xmm15
00007026095d3156  vmovaps xmm13, [rsp+0xD0]
00007026095d315f  por xmm15, xmm13
00007026095d3164  movaps xmm13, [r15+0x1D0]
00007026095d316c  vmovaps [rsp+0xD0], xmm13
00007026095d3175  vmovaps [rsp+0xE0], xmm1
00007026095d317e  vmovaps xmm1, [rsp+0xD0]
00007026095d3187  por xmm13, xmm1
00007026095d318c  movaps xmm1, [r15+0x2C0]
00007026095d3194  vmovaps [rsp+0xD0], xmm1
00007026095d319d  vmovaps [rsp+0xF0], xmm15
00007026095d31a6  vmovaps xmm15, [rsp+0xD0]
00007026095d31af  por xmm1, xmm15
00007026095d31b4  movaps xmm15, [r15+0x290]
00007026095d31bc  vmovaps [rsp+0xD0], xmm15
00007026095d31c5  vmovaps [rsp+0x100], xmm1
00007026095d31ce  vmovaps xmm1, [rsp+0xD0]
00007026095d31d7  por xmm15, xmm1
00007026095d31dc  movaps xmm1, [r15+0x260]
00007026095d31e4  vmovaps [rsp+0xD0], xmm1
00007026095d31ed  vmovaps [rsp+0x110], xmm15
00007026095d31f6  vmovaps xmm15, [rsp+0xD0]
00007026095d31ff  por xmm1, xmm15
00007026095d3204  vmovaps xmm15, [rsp+0xE0]
00007026095d320d  vmovaps [rsp+0xD0], xmm1
00007026095d3216  vmovaps xmm1, [rsp+0xE0]
00007026095d321f  por xmm15, xmm1
00007026095d3224  lea r14, [rax+0xC0]
00007026095d322b  movups xmm1, [r13+r14*1]
00007026095d3231  mov [rsp+0xE0], rax
00007026095d3239  xor eax, eax
00007026095d323b  mov r14d, 0x200
00007026095d3241  cmp r12, r14
00007026095d3244  cmc
00007026095d3245  lahf
00007026095d3246  seto al
00007026095d3249  mov [r15+0x108], eax
00007026095d3250  vmovaps [rsp+0x120], xmm1
00007026095d3259  vmovaps xmm1, [rsp+0x90]
00007026095d3262  vmovaps [rsp+0x90], xmm15
00007026095d326b  vmovaps xmm15, [rsp+0x120]
00007026095d3274  vmovaps [rsp+0x120], xmm13
00007026095d327d  vmovaps [rsp+0x130], xmm12
00007026095d3286  movaps xmm13, xmm1
00007026095d328a  vfmadd231pd xmm13, xmm15, xmm14
00007026095d328f  vcmppd xmm12, xmm13, xmm13, 0x03
00007026095d3295  vptest xmm12, xmm12
00007026095d329a  jnz 0x00007026095D3EA6
00007026095d32a0  mov rax, [rsp+0xE0]
00007026095d32a8  lea r14, [rax+0xB0]
00007026095d32af  movups xmm1, [r13+r14*1]
00007026095d32b5  vmovaps xmm15, [rsp+0xB0]
00007026095d32be  vmovaps [rsp+0xB0], xmm13
00007026095d32c7  movaps xmm12, xmm15
00007026095d32cb  vfmadd231pd xmm12, xmm1, xmm14
00007026095d32d0  vcmppd xmm13, xmm12, xmm12, 0x03
00007026095d32d6  vptest xmm13, xmm13
00007026095d32db  jnz 0x00007026095D4009
00007026095d32e1  vmovaps xmm1, [rsp+0x20]
00007026095d32e7  vmovaps xmm15, [rsp+0x20]
00007026095d32ed  por xmm1, xmm15
00007026095d32f2  movaps [r15+0x210], xmm1
00007026095d32fa  vmovaps xmm15, [rsp+0x80]
00007026095d3303  vmovaps xmm14, [rsp+0x80]
00007026095d330c  por xmm15, xmm14
00007026095d3311  movaps [r15+0x1C0], xmm15
00007026095d3319  vmovaps xmm14, [rsp+0x70]
00007026095d331f  vmovaps xmm13, [rsp+0x70]
00007026095d3325  por xmm14, xmm13
00007026095d332a  movaps [r15+0x280], xmm14
00007026095d3332  vmovaps xmm13, [rsp+0x60]
00007026095d3338  vmovaps [rsp+0x20], xmm1
00007026095d333e  vmovaps xmm1, [rsp+0x60]
00007026095d3344  por xmm13, xmm1
00007026095d3349  movaps [r15+0x2A0], xmm13
00007026095d3351  vmovaps xmm1, [rsp+0x50]
00007026095d3357  vmovaps [rsp+0x60], xmm15
00007026095d335d  vmovaps xmm15, [rsp+0x50]
00007026095d3363  por xmm1, xmm15
00007026095d3368  movaps [r15+0x2E0], xmm1
00007026095d3370  vmovaps [rsp+0x50], xmm2
00007026095d3376  vmovaps xmm15, [rsp+0x50]
00007026095d337c  por xmm2, xmm15
00007026095d3381  movaps [r15+0x1F0], xmm2
00007026095d3389  vmovaps xmm15, [rsp+0x90]
00007026095d3392  vmovaps [rsp+0x50], xmm1
00007026095d3398  vmovaps xmm1, [rsp+0x90]
00007026095d33a1  por xmm15, xmm1
00007026095d33a6  movaps [r15+0x250], xmm15
00007026095d33ae  vmovaps xmm1, [rsp+0xD0]
00007026095d33b7  vmovaps xmm15, [rsp+0xD0]
00007026095d33c0  por xmm1, xmm15
00007026095d33c5  movaps [r15+0x260], xmm1
00007026095d33cd  vmovaps xmm15, [rsp+0x110]
00007026095d33d6  vmovaps [rsp+0x70], xmm1
00007026095d33dc  vmovaps xmm1, [rsp+0x110]
00007026095d33e5  por xmm15, xmm1
00007026095d33ea  movaps [r15+0x290], xmm15
00007026095d33f2  vmovaps xmm1, [rsp+0x100]
00007026095d33fb  vmovaps [rsp+0x80], xmm15
00007026095d3404  vmovaps xmm15, [rsp+0x100]
00007026095d340d  por xmm1, xmm15
00007026095d3412  movaps [r15+0x2C0], xmm1
00007026095d341a  movq xmm15, qword ptr [r15+0x240]
00007026095d3423  vmovaps [rsp+0x90], xmm15
00007026095d342c  vpermilpd xmm15, xmm15, 0x00
00007026095d3432  vmovaps [rsp+0xD0], xmm1
00007026095d343b  vmovaps xmm1, [rsp+0x40]
00007026095d3441  vmovaps [rsp+0x40], xmm15
00007026095d3447  vmovaps xmm15, [rsp+0x20]
00007026095d344d  vmovaps [rsp+0x20], xmm14
00007026095d3453  vmovaps xmm14, [rsp+0x40]
00007026095d3459  vmovaps [rsp+0x40], xmm13
00007026095d345f  vmovaps [rsp+0xE0], xmm12
00007026095d3468  movaps xmm13, xmm1
00007026095d346c  vfmadd231pd xmm13, xmm15, xmm14
00007026095d3471  vcmppd xmm12, xmm13, xmm13, 0x03
00007026095d3477  vptest xmm12, xmm12
00007026095d347c  jnz 0x00007026095D4162
00007026095d3482  vmovaps xmm1, [rsp+0x90]
00007026095d348b  vpermilpd xmm1, xmm1, 0x00
00007026095d3491  vmovaps xmm15, [rsp+0xB0]
00007026095d349a  vmovaps xmm14, [rsp+0x50]
00007026095d34a0  vmovaps [rsp+0x50], xmm13
00007026095d34a6  movaps xmm12, xmm15
00007026095d34aa  vfmadd231pd xmm12, xmm14, xmm1
00007026095d34af  vcmppd xmm13, xmm12, xmm12, 0x03
00007026095d34b5  vptest xmm13, xmm13
00007026095d34ba  jnz 0x00007026095D42BB
00007026095d34c0  vmovaps xmm1, [rsp+0x90]
00007026095d34c9  vpermilpd xmm1, xmm1, 0x00
00007026095d34cf  vmovaps xmm15, [rsp+0x130]
00007026095d34d8  vmovaps xmm14, [rsp+0x60]
00007026095d34de  vmovaps [rsp+0x60], xmm12
00007026095d34e4  movaps xmm13, xmm15
00007026095d34e8  vfmadd231pd xmm13, xmm14, xmm1
00007026095d34ed  vcmppd xmm12, xmm13, xmm13, 0x03
00007026095d34f3  vptest xmm12, xmm12
00007026095d34f8  jnz 0x00007026095D4414
00007026095d34fe  vmovaps xmm1, [rsp+0x120]
00007026095d3507  vmovaps xmm15, [rsp+0x120]
00007026095d3510  por xmm1, xmm15
00007026095d3515  movaps [r15+0x1D0], xmm1
00007026095d351d  vmovaps xmm15, [rsp+0x90]
00007026095d3526  vpermilpd xmm15, xmm15, 0x00
00007026095d352c  vmovaps xmm14, [rsp+0xE0]
00007026095d3535  vmovaps [rsp+0x90], xmm1
00007026095d353e  movaps xmm12, xmm14
00007026095d3542  vfmadd231pd xmm12, xmm2, xmm15
00007026095d3547  vcmppd xmm1, xmm12, xmm12, 0x03
00007026095d354d  vptest xmm1, xmm1
00007026095d3552  jnz 0x00007026095D456D
00007026095d3558  vmovaps [rsp+0xB0], xmm3
00007026095d3561  vmovaps xmm1, [rsp+0xB0]
00007026095d356a  por xmm3, xmm1
00007026095d356e  movaps [r15+0x200], xmm3
00007026095d3576  vmovaps xmm1, [rsp+0xF0]
00007026095d357f  vmovaps xmm15, [rsp+0xF0]
00007026095d3588  por xmm1, xmm15
00007026095d358d  movaps [r15+0x1E0], xmm1
00007026095d3595  vmovaps [rsp+0xB0], xmm7
00007026095d359e  vmovaps xmm1, [rsp+0xB0]
00007026095d35a7  por xmm7, xmm1
00007026095d35ab  movaps [r15+0x2B0], xmm7
00007026095d35b3  vmovaps [rsp+0xB0], xmm8
00007026095d35bc  vmovaps xmm1, [rsp+0xB0]
00007026095d35c5  por xmm8, xmm1
00007026095d35ca  movaps [r15+0x300], xmm8
00007026095d35d2  vmovaps [rsp+0xB0], xmm5
00007026095d35db  vpermilpd xmm5, xmm5, 0x00
00007026095d35e1  vmovaps xmm14, [rsp+0x50]
00007026095d35e7  vmovaps xmm8, [rsp+0x70]
00007026095d35ed  vmovaps [rsp+0x50], xmm1
00007026095d35f3  movaps xmm2, xmm14
00007026095d35f7  vfmadd231pd xmm2, xmm8, xmm5
00007026095d35fc  vcmppd xmm1, xmm2, xmm2, 0x03
00007026095d3601  vptest xmm1, xmm1
00007026095d3606  jnz 0x00007026095D46C6
00007026095d360c  vmovaps xmm1, [rsp+0xB0]
00007026095d3615  vpermilpd xmm1, xmm1, 0x00
00007026095d361b  vmovaps xmm14, [rsp+0x60]
00007026095d3621  vmovaps xmm8, [rsp+0xD0]
00007026095d362a  vmovaps [rsp+0x60], xmm15
00007026095d3630  movaps xmm5, xmm14
00007026095d3634  vfmadd231pd xmm5, xmm8, xmm1
00007026095d3639  vcmppd xmm15, xmm5, xmm5, 0x03
00007026095d363e  vptest xmm15, xmm15
00007026095d3643  jnz 0x00007026095D481D
00007026095d3649  vmovaps xmm1, [rsp+0xB0]
00007026095d3652  vpermilpd xmm1, xmm1, 0x00
00007026095d3658  vmovaps xmm14, [rsp+0x20]
00007026095d365e  movaps xmm15, xmm13
00007026095d3662  vfmadd231pd xmm15, xmm14, xmm1
00007026095d3667  vcmppd xmm8, xmm15, xmm15, 0x03
00007026095d366d  vptest xmm8, xmm8
00007026095d3672  jnz 0x00007026095D4974
00007026095d3678  vmovaps xmm1, [rsp+0xB0]
00007026095d3681  vpermilpd xmm1, xmm1, 0x00
00007026095d3687  vmovaps xmm14, [rsp+0x90]
00007026095d3690  movaps xmm13, xmm12
00007026095d3694  vfmadd231pd xmm13, xmm14, xmm1
00007026095d3699  vcmppd xmm8, xmm13, xmm13, 0x03
00007026095d369f  vptest xmm8, xmm8
00007026095d36a4  jnz 0x00007026095D4ACD
00007026095d36aa  vmovaps [rsp+0x20], xmm6
00007026095d36b0  vmovaps xmm1, [rsp+0x20]
00007026095d36b6  por xmm6, xmm1
00007026095d36ba  movaps [r15+0x180], xmm6
00007026095d36c2  vmovaps [rsp+0x20], xmm9
00007026095d36c8  vmovaps xmm1, [rsp+0x20]
00007026095d36ce  por xmm9, xmm1
00007026095d36d3  movaps [r15+0x2D0], xmm9
00007026095d36db  vmovaps [rsp+0x20], xmm10
00007026095d36e1  vmovaps xmm1, [rsp+0x20]
00007026095d36e7  por xmm10, xmm1
00007026095d36ec  movaps [r15+0x2F0], xmm10
00007026095d36f4  vmovaps [rsp+0x20], xmm4
00007026095d36fa  vpermilpd xmm4, xmm4, 0x00
00007026095d3700  vmovaps xmm14, [rsp+0x50]
00007026095d3706  movaps xmm12, xmm5
00007026095d370a  vfmadd231pd xmm12, xmm14, xmm4
00007026095d370f  vcmppd xmm10, xmm12, xmm12, 0x03
00007026095d3715  vptest xmm10, xmm10
00007026095d371a  jnz 0x00007026095D4C26
00007026095d3720  vmovaps xmm14, [rsp+0x20]
00007026095d3726  vpermilpd xmm14, xmm14, 0x00
00007026095d372c  movaps xmm10, xmm2
00007026095d3730  vfmadd231pd xmm10, xmm6, xmm14
00007026095d3735  vcmppd xmm8, xmm10, xmm10, 0x03
00007026095d373b  vptest xmm8, xmm8
00007026095d3740  jnz 0x00007026095D4D7E
00007026095d3746  lea r14, [rax+0x80]
00007026095d374d  movups xmm14, [r13+r14*1]
00007026095d3753  movaps [r15+0x190], xmm14
00007026095d375b  vmovaps xmm8, [rsp+0x20]
00007026095d3761  vpermilpd xmm8, xmm8, 0x00
00007026095d3767  vmovaps xmm6, [rsp+0x80]
00007026095d3770  movaps xmm5, xmm15
00007026095d3774  vfmadd231pd xmm5, xmm6, xmm8
00007026095d3779  vcmppd xmm4, xmm5, xmm5, 0x03
00007026095d377e  vptest xmm4, xmm4
00007026095d3783  jnz 0x00007026095D4EE0
00007026095d3789  vmovaps xmm15, [rsp+0x20]
00007026095d378f  vpermilpd xmm15, xmm15, 0x00
00007026095d3795  movaps xmm8, xmm13
00007026095d3799  vfmadd231pd xmm8, xmm1, xmm15
00007026095d379e  vcmppd xmm6, xmm8, xmm8, 0x03
00007026095d37a4  vptest xmm6, xmm6
00007026095d37a9  jnz 0x00007026095D5037
00007026095d37af  vmovaps xmm1, [rsp+0x30]
00007026095d37b5  vmovaps xmm15, [rsp+0x30]
00007026095d37bb  por xmm1, xmm15
00007026095d37c0  movaps [r15+0x160], xmm1
00007026095d37c8  lea r14, [rax+0x40]
00007026095d37cc  movups xmm15, [r13+r14*1]
00007026095d37d2  lea r14, [rax+0x50]
00007026095d37d6  movups xmm13, [r13+r14*1]
00007026095d37dc  movaps [r15+0x1B0], xmm15
00007026095d37e4  movaps [r15+0x1A0], xmm13
00007026095d37ec  vmovaps xmm6, [rsp+0xC0]
00007026095d37f5  vpermilpd xmm6, xmm6, 0x00
00007026095d37fb  movaps xmm4, xmm12
00007026095d37ff  vfmadd231pd xmm4, xmm9, xmm6
00007026095d3804  vcmppd xmm2, xmm4, xmm4, 0x03
00007026095d3809  vptest xmm2, xmm2
00007026095d380e  jnz 0x00007026095D51A4
00007026095d3814  vmovaps xmm12, [rsp+0xC0]
00007026095d381d  vpermilpd xmm12, xmm12, 0x00
00007026095d3823  movaps xmm9, xmm10
00007026095d3827  vfmadd231pd xmm9, xmm1, xmm12
00007026095d382c  vcmppd xmm6, xmm9, xmm9, 0x03
00007026095d3832  vptest xmm6, xmm6
00007026095d3837  jnz 0x00007026095D52FB
00007026095d383d  vmovaps xmm1, [rsp+0xC0]
00007026095d3846  vpermilpd xmm1, xmm1, 0x00
00007026095d384c  vmovaps xmm12, [rsp+0x40]
00007026095d3852  movaps xmm10, xmm5
00007026095d3856  vfmadd231pd xmm10, xmm12, xmm1
00007026095d385b  vcmppd xmm6, xmm10, xmm10, 0x03
00007026095d3861  vptest xmm6, xmm6
00007026095d3866  jnz 0x00007026095D5454
00007026095d386c  vmovaps xmm1, [rsp+0xC0]
00007026095d3875  vpermilpd xmm1, xmm1, 0x00
00007026095d387b  vmovaps xmm12, [rsp+0x60]
00007026095d3881  movaps xmm6, xmm8
00007026095d3885  vfmadd231pd xmm6, xmm12, xmm1
00007026095d388a  vcmppd xmm5, xmm6, xmm6, 0x03
00007026095d388f  vptest xmm5, xmm5
00007026095d3894  jnz 0x00007026095D55AC
00007026095d389a  lea r14, [rax+0x60]
00007026095d389e  movups xmm1, [r13+r14*1]
00007026095d38a4  lea r14, [rax+0x70]
00007026095d38a8  movups xmm12, [r13+r14*1]
00007026095d38ae  movaps [r15+0x150], xmm1
00007026095d38b6  movaps [r15+0x120], xmm12
00007026095d38be  vmovaps [rsp+0x20], xmm11
00007026095d38c4  vpermilpd xmm11, xmm11, 0x00
00007026095d38ca  movaps xmm8, xmm4
00007026095d38ce  vfmadd231pd xmm8, xmm13, xmm11
00007026095d38d3  vcmppd xmm5, xmm8, xmm8, 0x03
00007026095d38d9  vptest xmm5, xmm5
00007026095d38de  jnz 0x00007026095D5717
00007026095d38e4  vmovaps xmm13, [rsp+0x20]
00007026095d38ea  vpermilpd xmm13, xmm13, 0x00
00007026095d38f0  movaps xmm11, xmm9
00007026095d38f4  vfmadd231pd xmm11, xmm1, xmm13
00007026095d38f9  vcmppd xmm5, xmm11, xmm11, 0x03
00007026095d38ff  vptest xmm5, xmm5
00007026095d3904  jnz 0x00007026095D5870
00007026095d390a  vmovaps xmm1, [rsp+0x20]
00007026095d3910  vpermilpd xmm1, xmm1, 0x00
00007026095d3916  movaps xmm13, xmm10
00007026095d391a  vfmadd231pd xmm13, xmm7, xmm1
00007026095d391f  vcmppd xmm9, xmm13, xmm13, 0x03
00007026095d3925  vptest xmm9, xmm9
00007026095d392a  jnz 0x00007026095D59C9
00007026095d3930  vmovaps xmm1, [rsp+0x20]
00007026095d3936  vpermilpd xmm1, xmm1, 0x00
00007026095d393c  movaps xmm10, xmm6
00007026095d3940  vfmadd231pd xmm10, xmm15, xmm1
00007026095d3945  vcmppd xmm9, xmm10, xmm10, 0x03
00007026095d394b  vptest xmm9, xmm9
00007026095d3950  jnz 0x00007026095D5B21
00007026095d3956  lea r14, [rax+0x20]
00007026095d395a  movups xmm1, [r13+r14*1]
00007026095d3960  lea r14, [rax+0x30]
00007026095d3964  movups xmm15, [r13+r14*1]
00007026095d396a  vmovaps xmm9, [rsp+0xA0]
00007026095d3973  vpermilpd xmm9, xmm9, 0x00
00007026095d3979  movaps xmm7, xmm8
00007026095d397d  vfmadd231pd xmm7, xmm3, xmm9
00007026095d3982  vcmppd xmm6, xmm7, xmm7, 0x03
00007026095d3987  vptest xmm6, xmm6
00007026095d398c  jnz 0x00007026095D5C8D
00007026095d3992  vmovaps xmm9, [rsp+0xA0]
00007026095d399b  vpermilpd xmm9, xmm9, 0x00
00007026095d39a1  movaps xmm8, xmm11
00007026095d39a5  vfmadd231pd xmm8, xmm14, xmm9
00007026095d39aa  vcmppd xmm6, xmm8, xmm8, 0x03
00007026095d39b0  vptest xmm6, xmm6
00007026095d39b5  jnz 0x00007026095D5DE4
00007026095d39bb  vmovaps xmm14, [rsp+0xA0]
00007026095d39c4  vpermilpd xmm14, xmm14, 0x00
00007026095d39ca  movaps xmm11, xmm13
00007026095d39ce  vfmadd231pd xmm11, xmm12, xmm14
00007026095d39d3  vcmppd xmm9, xmm11, xmm11, 0x03
00007026095d39d9  vptest xmm9, xmm9
00007026095d39de  jnz 0x00007026095D5F3E
00007026095d39e4  vmovaps xmm14, [rsp+0xA0]
00007026095d39ed  vpermilpd xmm14, xmm14, 0x00
00007026095d39f3  movaps xmm12, xmm10
00007026095d39f7  vfmadd231pd xmm12, xmm15, xmm14
00007026095d39fc  vcmppd xmm13, xmm12, xmm12, 0x03
00007026095d3a02  vptest xmm13, xmm13
00007026095d3a07  jnz 0x00007026095D6098
00007026095d3a0d  lea r14, [rax+0x90]
00007026095d3a14  movups xmm15, [r13+r14*1]
00007026095d3a1a  lea r14, [rax+0xA0]
00007026095d3a21  movups xmm14, [r13+r14*1]
00007026095d3a27  movaps [r15+0x140], xmm15
00007026095d3a2f  movaps [r15+0x130], xmm14
00007026095d3a37  vmovaps xmm13, [rsp+0x10]
00007026095d3a3d  vpermilpd xmm13, xmm13, 0x00
00007026095d3a43  movaps xmm10, xmm7
00007026095d3a47  vfmadd231pd xmm10, xmm1, xmm13
00007026095d3a4c  vcmppd xmm9, xmm10, xmm10, 0x03
00007026095d3a52  vptest xmm9, xmm9
00007026095d3a57  jnz 0x00007026095D6206
00007026095d3a5d  movaps [r15+0x220], xmm10
00007026095d3a65  lea r14, [rax+0x10]
00007026095d3a69  movups xmm1, [r13+r14*1]
00007026095d3a6f  movaps [r15+0x240], xmm1
00007026095d3a77  vmovaps xmm13, [rsp+0x10]
00007026095d3a7d  vpermilpd xmm13, xmm13, 0x00
00007026095d3a83  movaps xmm9, xmm8
00007026095d3a87  vfmadd231pd xmm9, xmm14, xmm13
00007026095d3a8c  vcmppd xmm7, xmm9, xmm9, 0x03
00007026095d3a92  vptest xmm7, xmm7
00007026095d3a97  jnz 0x00007026095D6368
00007026095d3a9d  movaps [r15+0x110], xmm9
00007026095d3aa5  vmovaps xmm14, [rsp+0x10]
00007026095d3aab  vpermilpd xmm14, xmm14, 0x00
00007026095d3ab1  movaps xmm13, xmm11
00007026095d3ab5  vfmadd231pd xmm13, xmm15, xmm14
00007026095d3aba  vcmppd xmm8, xmm13, xmm13, 0x03
00007026095d3ac0  vptest xmm8, xmm8
00007026095d3ac5  jnz 0x00007026095D64C2
00007026095d3acb  movaps [r15+0x170], xmm13
00007026095d3ad3  vmovaps xmm15, [rsp+0x10]
00007026095d3ad9  vpermilpd xmm15, xmm15, 0x00
00007026095d3adf  movaps xmm14, xmm12
00007026095d3ae3  vfmadd231pd xmm14, xmm1, xmm15
00007026095d3ae8  vcmppd xmm11, xmm14, xmm14, 0x03
00007026095d3aee  vptest xmm11, xmm11
00007026095d3af3  jnz 0x00007026095D661C
00007026095d3af9  movaps [r15+0x230], xmm14
00007026095d3b01  movups [r13+r11*1], xmm9
00007026095d3b07  lea rax, [r11+0x10]
00007026095d3b0b  movups [r13+rax*1], xmm13
00007026095d3b11  lea rax, [r11+0x20]
00007026095d3b15  movups [r13+rax*1], xmm10
00007026095d3b1b  lea rax, [r11+0x30]
00007026095d3b1f  movups [r13+rax*1], xmm14
00007026095d3b25  mov eax, [r15+0x108]
00007026095d3b2c  sahf
00007026095d3b2d  jnz 0x00007026095D3B5F
00007026095d3b2f  cmp dword ptr [r15+0x318], 0x00
00007026095d3b37  jz 0x00007026095D67A0
00007026095d3b3d  nop [rax+rax*1], ax
00007026095d3b46  nop [rax+rax*1], eax
00007026095d3b4e  mov eax, 0x4103F0
00007026095d3b53  mov [r15+0x100], rax
00007026095d3b5a  jmp 0x00007026093FE110
00007026095d3b5f  cmp dword ptr [r15+0x318], 0x00
00007026095d3b67  jz 0x00007026095D2E40
00007026095d3b6d  nop [rax+rax*1], ax
00007026095d3b76  nop [rax+rax*1], eax
00007026095d3b7e  mov eax, 0x410274
00007026095d3b83  mov [r15+0x100], rax
00007026095d3b8a  jmp 0x00007026093FE110
00007026095d3b8f  int3
00007026095d3b90  call 0x000070260940A4B0
00007026095d3b95  jmp 0x00007026095D2E69
00007026095d3b9a  call 0x0000702609409240
00007026095d3b9f  jmp 0x00007026095D2E73
00007026095d3ba4  call 0x000070260940A4B0
00007026095d3ba9  jmp 0x00007026095D2EBD
00007026095d3bae  call 0x0000702609409240
00007026095d3bb3  jmp 0x00007026095D2EC7
00007026095d3bb8  call 0x000070260940A4B0
00007026095d3bbd  jmp 0x00007026095D2F60
00007026095d3bc2  call 0x0000702609409240
00007026095d3bc7  jmp 0x00007026095D2F6A
00007026095d3bcc  call 0x00007026094B47C0
00007026095d3bd1  jmp 0x00007026095D3055
00007026095d3bd6  call 0x00007026093FF430
00007026095d3bdb  jmp 0x00007026095D3084
00007026095d3be0  call 0x00007026094B0CE0
00007026095d3be5  jmp 0x00007026095D30A0
00007026095d3bea  sub rsp, 0x08
00007026095d3bee  push rax
00007026095d3bef  push rcx
00007026095d3bf0  push rdx
00007026095d3bf1  push rdi
00007026095d3bf2  push rsi
00007026095d3bf3  push r8
00007026095d3bf5  push r9
00007026095d3bf7  push r10
00007026095d3bf9  push r11
00007026095d3bfb  sub rsp, 0xF0
00007026095d3c02  vmovaps [rsp], xmm0
00007026095d3c07  vmovaps [rsp+0x10], xmm1
00007026095d3c0d  vmovaps [rsp+0x20], xmm2
00007026095d3c13  vmovaps [rsp+0x30], xmm3
00007026095d3c19  vmovaps [rsp+0x40], xmm4
00007026095d3c1f  vmovaps [rsp+0x50], xmm5
00007026095d3c25  vmovaps [rsp+0x60], xmm6
00007026095d3c2b  vmovaps [rsp+0x70], xmm7
00007026095d3c31  vmovaps [rsp+0x80], xmm8
00007026095d3c3a  vmovaps [rsp+0x90], xmm9
00007026095d3c43  vmovaps [rsp+0xA0], xmm10
00007026095d3c4c  vmovaps [rsp+0xB0], xmm11
00007026095d3c55  vmovaps [rsp+0xC0], xmm12
00007026095d3c5e  vmovaps [rsp+0xD0], xmm14
00007026095d3c67  vmovaps [rsp+0xE0], xmm15
00007026095d3c70  sub rsp, 0x40
00007026095d3c74  lea rdi, [rsp]
00007026095d3c78  lea rsi, [rsp+0x10]
00007026095d3c7d  lea rdx, [rsp+0x20]
00007026095d3c82  lea rcx, [rsp+0x30]
00007026095d3c87  mov r8d, 0x00
00007026095d3c8d  lea r9, [r15+0x3A8]
00007026095d3c94  movaps [rdi], xmm13
00007026095d3c98  movaps [rsi], xmm1
00007026095d3c9b  movaps [rdx], xmm15
00007026095d3c9f  movaps [rcx], xmm14
00007026095d3ca3  mov rax, 0x58A432239A50
00007026095d3cad  call rax
00007026095d3caf  movaps xmm13, [rsp]
00007026095d3cb4  add rsp, 0x40
00007026095d3cb8  vmovaps xmm0, [rsp]
00007026095d3cbd  vmovaps xmm1, [rsp+0x10]
00007026095d3cc3  vmovaps xmm2, [rsp+0x20]
00007026095d3cc9  vmovaps xmm3, [rsp+0x30]
00007026095d3ccf  vmovaps xmm4, [rsp+0x40]
00007026095d3cd5  vmovaps xmm5, [rsp+0x50]
00007026095d3cdb  vmovaps xmm6, [rsp+0x60]
00007026095d3ce1  vmovaps xmm7, [rsp+0x70]
00007026095d3ce7  vmovaps xmm8, [rsp+0x80]
00007026095d3cf0  vmovaps xmm9, [rsp+0x90]
00007026095d3cf9  vmovaps xmm10, [rsp+0xA0]
00007026095d3d02  vmovaps xmm11, [rsp+0xB0]
00007026095d3d0b  vmovaps xmm12, [rsp+0xC0]
00007026095d3d14  vmovaps xmm14, [rsp+0xD0]
00007026095d3d1d  vmovaps xmm15, [rsp+0xE0]
00007026095d3d26  add rsp, 0xF0
00007026095d3d2d  pop r11
00007026095d3d2f  pop r10
00007026095d3d31  pop r9
00007026095d3d33  pop r8
00007026095d3d35  pop rsi
00007026095d3d36  pop rdi
00007026095d3d37  pop rdx
00007026095d3d38  pop rcx
00007026095d3d39  pop rax
00007026095d3d3a  add rsp, 0x08
00007026095d3d3e  jmp 0x00007026095D3117
00007026095d3d43  sub rsp, 0x08
00007026095d3d47  push rax
00007026095d3d48  push rcx
00007026095d3d49  push rdx
00007026095d3d4a  push rdi
00007026095d3d4b  push rsi
00007026095d3d4c  push r8
00007026095d3d4e  push r9
00007026095d3d50  push r10
00007026095d3d52  push r11
00007026095d3d54  sub rsp, 0xF0
00007026095d3d5b  vmovaps [rsp], xmm0
00007026095d3d60  vmovaps [rsp+0x10], xmm1
00007026095d3d66  vmovaps [rsp+0x20], xmm2
00007026095d3d6c  vmovaps [rsp+0x30], xmm3
00007026095d3d72  vmovaps [rsp+0x40], xmm4
00007026095d3d78  vmovaps [rsp+0x50], xmm5
00007026095d3d7e  vmovaps [rsp+0x60], xmm6
00007026095d3d84  vmovaps [rsp+0x70], xmm7
00007026095d3d8a  vmovaps [rsp+0x80], xmm8
00007026095d3d93  vmovaps [rsp+0x90], xmm9
00007026095d3d9c  vmovaps [rsp+0xA0], xmm10
00007026095d3da5  vmovaps [rsp+0xB0], xmm11
00007026095d3dae  vmovaps [rsp+0xC0], xmm13
00007026095d3db7  vmovaps [rsp+0xD0], xmm14
00007026095d3dc0  vmovaps [rsp+0xE0], xmm15
00007026095d3dc9  sub rsp, 0x40
00007026095d3dcd  lea rdi, [rsp]
00007026095d3dd1  lea rsi, [rsp+0x10]
00007026095d3dd6  lea rdx, [rsp+0x20]
00007026095d3ddb  lea rcx, [rsp+0x30]
00007026095d3de0  mov r8d, 0x00
00007026095d3de6  lea r9, [r15+0x3A8]
00007026095d3ded  movaps [rdi], xmm12
00007026095d3df1  movaps [rsi], xmm15
00007026095d3df5  movaps [rdx], xmm1
00007026095d3df8  movaps [rcx], xmm14
00007026095d3dfc  mov rax, 0x58A432239A50
00007026095d3e06  call rax
00007026095d3e08  movaps xmm12, [rsp]
00007026095d3e0d  add rsp, 0x40
00007026095d3e11  vmovaps xmm0, [rsp]
00007026095d3e16  vmovaps xmm1, [rsp+0x10]
00007026095d3e1c  vmovaps xmm2, [rsp+0x20]
00007026095d3e22  vmovaps xmm3, [rsp+0x30]
00007026095d3e28  vmovaps xmm4, [rsp+0x40]
00007026095d3e2e  vmovaps xmm5, [rsp+0x50]
00007026095d3e34  vmovaps xmm6, [rsp+0x60]
00007026095d3e3a  vmovaps xmm7, [rsp+0x70]
00007026095d3e40  vmovaps xmm8, [rsp+0x80]
00007026095d3e49  vmovaps xmm9, [rsp+0x90]
00007026095d3e52  vmovaps xmm10, [rsp+0xA0]
00007026095d3e5b  vmovaps xmm11, [rsp+0xB0]
00007026095d3e64  vmovaps xmm13, [rsp+0xC0]
00007026095d3e6d  vmovaps xmm14, [rsp+0xD0]
00007026095d3e76  vmovaps xmm15, [rsp+0xE0]
00007026095d3e7f  add rsp, 0xF0
00007026095d3e86  pop r11
00007026095d3e88  pop r10
00007026095d3e8a  pop r9
00007026095d3e8c  pop r8
00007026095d3e8e  pop rsi
00007026095d3e8f  pop rdi
00007026095d3e90  pop rdx
00007026095d3e91  pop rcx
00007026095d3e92  pop rax
00007026095d3e93  add rsp, 0x08
00007026095d3e97  jmp 0x00007026095D3145
00007026095d3e9c  call 0x00007026094D64F0
00007026095d3ea1  jmp 0x00007026095D3231
00007026095d3ea6  sub rsp, 0x08
00007026095d3eaa  push rax
00007026095d3eab  push rcx
00007026095d3eac  push rdx
00007026095d3ead  push rdi
00007026095d3eae  push rsi
00007026095d3eaf  push r8
00007026095d3eb1  push r9
00007026095d3eb3  push r10
00007026095d3eb5  push r11
00007026095d3eb7  sub rsp, 0xF0
00007026095d3ebe  vmovaps [rsp], xmm0
00007026095d3ec3  vmovaps [rsp+0x10], xmm1
00007026095d3ec9  vmovaps [rsp+0x20], xmm2
00007026095d3ecf  vmovaps [rsp+0x30], xmm3
00007026095d3ed5  vmovaps [rsp+0x40], xmm4
00007026095d3edb  vmovaps [rsp+0x50], xmm5
00007026095d3ee1  vmovaps [rsp+0x60], xmm6
00007026095d3ee7  vmovaps [rsp+0x70], xmm7
00007026095d3eed  vmovaps [rsp+0x80], xmm8
00007026095d3ef6  vmovaps [rsp+0x90], xmm9
00007026095d3eff  vmovaps [rsp+0xA0], xmm10
00007026095d3f08  vmovaps [rsp+0xB0], xmm11
00007026095d3f11  vmovaps [rsp+0xC0], xmm12
00007026095d3f1a  vmovaps [rsp+0xD0], xmm14
00007026095d3f23  vmovaps [rsp+0xE0], xmm15
00007026095d3f2c  sub rsp, 0x40
00007026095d3f30  lea rdi, [rsp]
00007026095d3f34  lea rsi, [rsp+0x10]
00007026095d3f39  lea rdx, [rsp+0x20]
00007026095d3f3e  lea rcx, [rsp+0x30]
00007026095d3f43  mov r8d, 0x00
00007026095d3f49  lea r9, [r15+0x3A8]
00007026095d3f50  movaps [rdi], xmm13
00007026095d3f54  movaps [rsi], xmm1
00007026095d3f57  movaps [rdx], xmm15
00007026095d3f5b  movaps [rcx], xmm14
00007026095d3f5f  mov rax, 0x58A432239A50
00007026095d3f69  call rax
00007026095d3f6b  movaps xmm13, [rsp]
00007026095d3f70  add rsp, 0x40
00007026095d3f74  vmovaps xmm0, [rsp]
00007026095d3f79  vmovaps xmm1, [rsp+0x10]
00007026095d3f7f  vmovaps xmm2, [rsp+0x20]
00007026095d3f85  vmovaps xmm3, [rsp+0x30]
00007026095d3f8b  vmovaps xmm4, [rsp+0x40]
00007026095d3f91  vmovaps xmm5, [rsp+0x50]
00007026095d3f97  vmovaps xmm6, [rsp+0x60]
00007026095d3f9d  vmovaps xmm7, [rsp+0x70]
00007026095d3fa3  vmovaps xmm8, [rsp+0x80]
00007026095d3fac  vmovaps xmm9, [rsp+0x90]
00007026095d3fb5  vmovaps xmm10, [rsp+0xA0]
00007026095d3fbe  vmovaps xmm11, [rsp+0xB0]
00007026095d3fc7  vmovaps xmm12, [rsp+0xC0]
00007026095d3fd0  vmovaps xmm14, [rsp+0xD0]
00007026095d3fd9  vmovaps xmm15, [rsp+0xE0]
00007026095d3fe2  add rsp, 0xF0
00007026095d3fe9  pop r11
00007026095d3feb  pop r10
00007026095d3fed  pop r9
00007026095d3fef  pop r8
00007026095d3ff1  pop rsi
00007026095d3ff2  pop rdi
00007026095d3ff3  pop rdx
00007026095d3ff4  pop rcx
00007026095d3ff5  pop rax
00007026095d3ff6  add rsp, 0x08
00007026095d3ffa  jmp 0x00007026095D32A0
00007026095d3fff  call 0x00007026094D64F0
00007026095d4004  jmp 0x00007026095D32B5
00007026095d4009  sub rsp, 0x08
00007026095d400d  push rax
00007026095d400e  push rcx
00007026095d400f  push rdx
00007026095d4010  push rdi
00007026095d4011  push rsi
00007026095d4012  push r8
00007026095d4014  push r9
00007026095d4016  push r10
00007026095d4018  push r11
00007026095d401a  sub rsp, 0xF0
00007026095d4021  vmovaps [rsp], xmm0
00007026095d4026  vmovaps [rsp+0x10], xmm1
00007026095d402c  vmovaps [rsp+0x20], xmm2
00007026095d4032  vmovaps [rsp+0x30], xmm3
00007026095d4038  vmovaps [rsp+0x40], xmm4
00007026095d403e  vmovaps [rsp+0x50], xmm5
00007026095d4044  vmovaps [rsp+0x60], xmm6
00007026095d404a  vmovaps [rsp+0x70], xmm7
00007026095d4050  vmovaps [rsp+0x80], xmm8
00007026095d4059  vmovaps [rsp+0x90], xmm9
00007026095d4062  vmovaps [rsp+0xA0], xmm10
00007026095d406b  vmovaps [rsp+0xB0], xmm11
00007026095d4074  vmovaps [rsp+0xC0], xmm13
00007026095d407d  vmovaps [rsp+0xD0], xmm14
00007026095d4086  vmovaps [rsp+0xE0], xmm15
00007026095d408f  sub rsp, 0x40
00007026095d4093  lea rdi, [rsp]
00007026095d4097  lea rsi, [rsp+0x10]
00007026095d409c  lea rdx, [rsp+0x20]
00007026095d40a1  lea rcx, [rsp+0x30]
00007026095d40a6  mov r8d, 0x00
00007026095d40ac  lea r9, [r15+0x3A8]
00007026095d40b3  movaps [rdi], xmm12
00007026095d40b7  movaps [rsi], xmm15
00007026095d40bb  movaps [rdx], xmm1
00007026095d40be  movaps [rcx], xmm14
00007026095d40c2  mov rax, 0x58A432239A50
00007026095d40cc  call rax
00007026095d40ce  movaps xmm12, [rsp]
00007026095d40d3  add rsp, 0x40
00007026095d40d7  vmovaps xmm0, [rsp]
00007026095d40dc  vmovaps xmm1, [rsp+0x10]
00007026095d40e2  vmovaps xmm2, [rsp+0x20]
00007026095d40e8  vmovaps xmm3, [rsp+0x30]
00007026095d40ee  vmovaps xmm4, [rsp+0x40]
00007026095d40f4  vmovaps xmm5, [rsp+0x50]
00007026095d40fa  vmovaps xmm6, [rsp+0x60]
00007026095d4100  vmovaps xmm7, [rsp+0x70]
00007026095d4106  vmovaps xmm8, [rsp+0x80]
00007026095d410f  vmovaps xmm9, [rsp+0x90]
00007026095d4118  vmovaps xmm10, [rsp+0xA0]
00007026095d4121  vmovaps xmm11, [rsp+0xB0]
00007026095d412a  vmovaps xmm13, [rsp+0xC0]
00007026095d4133  vmovaps xmm14, [rsp+0xD0]
00007026095d413c  vmovaps xmm15, [rsp+0xE0]
00007026095d4145  add rsp, 0xF0
00007026095d414c  pop r11
00007026095d414e  pop r10
00007026095d4150  pop r9
00007026095d4152  pop r8
00007026095d4154  pop rsi
00007026095d4155  pop rdi
00007026095d4156  pop rdx
00007026095d4157  pop rcx
00007026095d4158  pop rax
00007026095d4159  add rsp, 0x08
00007026095d415d  jmp 0x00007026095D32E1
00007026095d4162  sub rsp, 0x08
00007026095d4166  push rax
00007026095d4167  push rcx
00007026095d4168  push rdx
00007026095d4169  push rdi
00007026095d416a  push rsi
00007026095d416b  push r8
00007026095d416d  push r9
00007026095d416f  push r10
00007026095d4171  push r11
00007026095d4173  sub rsp, 0xF0
00007026095d417a  vmovaps [rsp], xmm0
00007026095d417f  vmovaps [rsp+0x10], xmm1
00007026095d4185  vmovaps [rsp+0x20], xmm2
00007026095d418b  vmovaps [rsp+0x30], xmm3
00007026095d4191  vmovaps [rsp+0x40], xmm4
00007026095d4197  vmovaps [rsp+0x50], xmm5
00007026095d419d  vmovaps [rsp+0x60], xmm6
00007026095d41a3  vmovaps [rsp+0x70], xmm7
00007026095d41a9  vmovaps [rsp+0x80], xmm8
00007026095d41b2  vmovaps [rsp+0x90], xmm9
00007026095d41bb  vmovaps [rsp+0xA0], xmm10
00007026095d41c4  vmovaps [rsp+0xB0], xmm11
00007026095d41cd  vmovaps [rsp+0xC0], xmm12
00007026095d41d6  vmovaps [rsp+0xD0], xmm14
00007026095d41df  vmovaps [rsp+0xE0], xmm15
00007026095d41e8  sub rsp, 0x40
00007026095d41ec  lea rdi, [rsp]
00007026095d41f0  lea rsi, [rsp+0x10]
00007026095d41f5  lea rdx, [rsp+0x20]
00007026095d41fa  lea rcx, [rsp+0x30]
00007026095d41ff  mov r8d, 0x00
00007026095d4205  lea r9, [r15+0x3A8]
00007026095d420c  movaps [rdi], xmm13
00007026095d4210  movaps [rsi], xmm1
00007026095d4213  movaps [rdx], xmm15
00007026095d4217  movaps [rcx], xmm14
00007026095d421b  mov rax, 0x58A432239A50
00007026095d4225  call rax
00007026095d4227  movaps xmm13, [rsp]
00007026095d422c  add rsp, 0x40
00007026095d4230  vmovaps xmm0, [rsp]
00007026095d4235  vmovaps xmm1, [rsp+0x10]
00007026095d423b  vmovaps xmm2, [rsp+0x20]
00007026095d4241  vmovaps xmm3, [rsp+0x30]
00007026095d4247  vmovaps xmm4, [rsp+0x40]
00007026095d424d  vmovaps xmm5, [rsp+0x50]
00007026095d4253  vmovaps xmm6, [rsp+0x60]
00007026095d4259  vmovaps xmm7, [rsp+0x70]
00007026095d425f  vmovaps xmm8, [rsp+0x80]
00007026095d4268  vmovaps xmm9, [rsp+0x90]
00007026095d4271  vmovaps xmm10, [rsp+0xA0]
00007026095d427a  vmovaps xmm11, [rsp+0xB0]
00007026095d4283  vmovaps xmm12, [rsp+0xC0]
00007026095d428c  vmovaps xmm14, [rsp+0xD0]
00007026095d4295  vmovaps xmm15, [rsp+0xE0]
00007026095d429e  add rsp, 0xF0
00007026095d42a5  pop r11
00007026095d42a7  pop r10
00007026095d42a9  pop r9
00007026095d42ab  pop r8
00007026095d42ad  pop rsi
00007026095d42ae  pop rdi
00007026095d42af  pop rdx
00007026095d42b0  pop rcx
00007026095d42b1  pop rax
00007026095d42b2  add rsp, 0x08
00007026095d42b6  jmp 0x00007026095D3482
00007026095d42bb  sub rsp, 0x08
00007026095d42bf  push rax
00007026095d42c0  push rcx
00007026095d42c1  push rdx
00007026095d42c2  push rdi
00007026095d42c3  push rsi
00007026095d42c4  push r8
00007026095d42c6  push r9
00007026095d42c8  push r10
00007026095d42ca  push r11
00007026095d42cc  sub rsp, 0xF0
00007026095d42d3  vmovaps [rsp], xmm0
00007026095d42d8  vmovaps [rsp+0x10], xmm1
00007026095d42de  vmovaps [rsp+0x20], xmm2
00007026095d42e4  vmovaps [rsp+0x30], xmm3
00007026095d42ea  vmovaps [rsp+0x40], xmm4
00007026095d42f0  vmovaps [rsp+0x50], xmm5
00007026095d42f6  vmovaps [rsp+0x60], xmm6
00007026095d42fc  vmovaps [rsp+0x70], xmm7
00007026095d4302  vmovaps [rsp+0x80], xmm8
00007026095d430b  vmovaps [rsp+0x90], xmm9
00007026095d4314  vmovaps [rsp+0xA0], xmm10
00007026095d431d  vmovaps [rsp+0xB0], xmm11
00007026095d4326  vmovaps [rsp+0xC0], xmm13
00007026095d432f  vmovaps [rsp+0xD0], xmm14
00007026095d4338  vmovaps [rsp+0xE0], xmm15
00007026095d4341  sub rsp, 0x40
00007026095d4345  lea rdi, [rsp]
00007026095d4349  lea rsi, [rsp+0x10]
00007026095d434e  lea rdx, [rsp+0x20]
00007026095d4353  lea rcx, [rsp+0x30]
00007026095d4358  mov r8d, 0x00
00007026095d435e  lea r9, [r15+0x3A8]
00007026095d4365  movaps [rdi], xmm12
00007026095d4369  movaps [rsi], xmm15
00007026095d436d  movaps [rdx], xmm14
00007026095d4371  movaps [rcx], xmm1
00007026095d4374  mov rax, 0x58A432239A50
00007026095d437e  call rax
00007026095d4380  movaps xmm12, [rsp]
00007026095d4385  add rsp, 0x40
00007026095d4389  vmovaps xmm0, [rsp]
00007026095d438e  vmovaps xmm1, [rsp+0x10]
00007026095d4394  vmovaps xmm2, [rsp+0x20]
00007026095d439a  vmovaps xmm3, [rsp+0x30]
00007026095d43a0  vmovaps xmm4, [rsp+0x40]
00007026095d43a6  vmovaps xmm5, [rsp+0x50]
00007026095d43ac  vmovaps xmm6, [rsp+0x60]
00007026095d43b2  vmovaps xmm7, [rsp+0x70]
00007026095d43b8  vmovaps xmm8, [rsp+0x80]
00007026095d43c1  vmovaps xmm9, [rsp+0x90]
00007026095d43ca  vmovaps xmm10, [rsp+0xA0]
00007026095d43d3  vmovaps xmm11, [rsp+0xB0]
00007026095d43dc  vmovaps xmm13, [rsp+0xC0]
00007026095d43e5  vmovaps xmm14, [rsp+0xD0]
00007026095d43ee  vmovaps xmm15, [rsp+0xE0]
00007026095d43f7  add rsp, 0xF0
00007026095d43fe  pop r11
00007026095d4400  pop r10
00007026095d4402  pop r9
00007026095d4404  pop r8
00007026095d4406  pop rsi
00007026095d4407  pop rdi
00007026095d4408  pop rdx
00007026095d4409  pop rcx
00007026095d440a  pop rax
00007026095d440b  add rsp, 0x08
00007026095d440f  jmp 0x00007026095D34C0
00007026095d4414  sub rsp, 0x08
00007026095d4418  push rax
00007026095d4419  push rcx
00007026095d441a  push rdx
00007026095d441b  push rdi
00007026095d441c  push rsi
00007026095d441d  push r8
00007026095d441f  push r9
00007026095d4421  push r10
00007026095d4423  push r11
00007026095d4425  sub rsp, 0xF0
00007026095d442c  vmovaps [rsp], xmm0
00007026095d4431  vmovaps [rsp+0x10], xmm1
00007026095d4437  vmovaps [rsp+0x20], xmm2
00007026095d443d  vmovaps [rsp+0x30], xmm3
00007026095d4443  vmovaps [rsp+0x40], xmm4
00007026095d4449  vmovaps [rsp+0x50], xmm5
00007026095d444f  vmovaps [rsp+0x60], xmm6
00007026095d4455  vmovaps [rsp+0x70], xmm7
00007026095d445b  vmovaps [rsp+0x80], xmm8
00007026095d4464  vmovaps [rsp+0x90], xmm9
00007026095d446d  vmovaps [rsp+0xA0], xmm10
00007026095d4476  vmovaps [rsp+0xB0], xmm11
00007026095d447f  vmovaps [rsp+0xC0], xmm12
00007026095d4488  vmovaps [rsp+0xD0], xmm14
00007026095d4491  vmovaps [rsp+0xE0], xmm15
00007026095d449a  sub rsp, 0x40
00007026095d449e  lea rdi, [rsp]
00007026095d44a2  lea rsi, [rsp+0x10]
00007026095d44a7  lea rdx, [rsp+0x20]
00007026095d44ac  lea rcx, [rsp+0x30]
00007026095d44b1  mov r8d, 0x00
00007026095d44b7  lea r9, [r15+0x3A8]
00007026095d44be  movaps [rdi], xmm13
00007026095d44c2  movaps [rsi], xmm15
00007026095d44c6  movaps [rdx], xmm14
00007026095d44ca  movaps [rcx], xmm1
00007026095d44cd  mov rax, 0x58A432239A50
00007026095d44d7  call rax
00007026095d44d9  movaps xmm13, [rsp]
00007026095d44de  add rsp, 0x40
00007026095d44e2  vmovaps xmm0, [rsp]
00007026095d44e7  vmovaps xmm1, [rsp+0x10]
00007026095d44ed  vmovaps xmm2, [rsp+0x20]
00007026095d44f3  vmovaps xmm3, [rsp+0x30]
00007026095d44f9  vmovaps xmm4, [rsp+0x40]
00007026095d44ff  vmovaps xmm5, [rsp+0x50]
00007026095d4505  vmovaps xmm6, [rsp+0x60]
00007026095d450b  vmovaps xmm7, [rsp+0x70]
00007026095d4511  vmovaps xmm8, [rsp+0x80]
00007026095d451a  vmovaps xmm9, [rsp+0x90]
00007026095d4523  vmovaps xmm10, [rsp+0xA0]
00007026095d452c  vmovaps xmm11, [rsp+0xB0]
00007026095d4535  vmovaps xmm12, [rsp+0xC0]
00007026095d453e  vmovaps xmm14, [rsp+0xD0]
00007026095d4547  vmovaps xmm15, [rsp+0xE0]
00007026095d4550  add rsp, 0xF0
00007026095d4557  pop r11
00007026095d4559  pop r10
00007026095d455b  pop r9
00007026095d455d  pop r8
00007026095d455f  pop rsi
00007026095d4560  pop rdi
00007026095d4561  pop rdx
00007026095d4562  pop rcx
00007026095d4563  pop rax
00007026095d4564  add rsp, 0x08
00007026095d4568  jmp 0x00007026095D34FE
00007026095d456d  sub rsp, 0x08
00007026095d4571  push rax
00007026095d4572  push rcx
00007026095d4573  push rdx
00007026095d4574  push rdi
00007026095d4575  push rsi
00007026095d4576  push r8
00007026095d4578  push r9
00007026095d457a  push r10
00007026095d457c  push r11
00007026095d457e  sub rsp, 0xF0
00007026095d4585  vmovaps [rsp], xmm0
00007026095d458a  vmovaps [rsp+0x10], xmm1
00007026095d4590  vmovaps [rsp+0x20], xmm2
00007026095d4596  vmovaps [rsp+0x30], xmm3
00007026095d459c  vmovaps [rsp+0x40], xmm4
00007026095d45a2  vmovaps [rsp+0x50], xmm5
00007026095d45a8  vmovaps [rsp+0x60], xmm6
00007026095d45ae  vmovaps [rsp+0x70], xmm7
00007026095d45b4  vmovaps [rsp+0x80], xmm8
00007026095d45bd  vmovaps [rsp+0x90], xmm9
00007026095d45c6  vmovaps [rsp+0xA0], xmm10
00007026095d45cf  vmovaps [rsp+0xB0], xmm11
00007026095d45d8  vmovaps [rsp+0xC0], xmm13
00007026095d45e1  vmovaps [rsp+0xD0], xmm14
00007026095d45ea  vmovaps [rsp+0xE0], xmm15
00007026095d45f3  sub rsp, 0x40
00007026095d45f7  lea rdi, [rsp]
00007026095d45fb  lea rsi, [rsp+0x10]
00007026095d4600  lea rdx, [rsp+0x20]
00007026095d4605  lea rcx, [rsp+0x30]
00007026095d460a  mov r8d, 0x00
00007026095d4610  lea r9, [r15+0x3A8]
00007026095d4617  movaps [rdi], xmm12
00007026095d461b  movaps [rsi], xmm14
00007026095d461f  movaps [rdx], xmm2
00007026095d4622  movaps [rcx], xmm15
00007026095d4626  mov rax, 0x58A432239A50
00007026095d4630  call rax
00007026095d4632  movaps xmm12, [rsp]
00007026095d4637  add rsp, 0x40
00007026095d463b  vmovaps xmm0, [rsp]
00007026095d4640  vmovaps xmm1, [rsp+0x10]
00007026095d4646  vmovaps xmm2, [rsp+0x20]
00007026095d464c  vmovaps xmm3, [rsp+0x30]
00007026095d4652  vmovaps xmm4, [rsp+0x40]
00007026095d4658  vmovaps xmm5, [rsp+0x50]
00007026095d465e  vmovaps xmm6, [rsp+0x60]
00007026095d4664  vmovaps xmm7, [rsp+0x70]
00007026095d466a  vmovaps xmm8, [rsp+0x80]
00007026095d4673  vmovaps xmm9, [rsp+0x90]
00007026095d467c  vmovaps xmm10, [rsp+0xA0]
00007026095d4685  vmovaps xmm11, [rsp+0xB0]
00007026095d468e  vmovaps xmm13, [rsp+0xC0]
00007026095d4697  vmovaps xmm14, [rsp+0xD0]
00007026095d46a0  vmovaps xmm15, [rsp+0xE0]
00007026095d46a9  add rsp, 0xF0
00007026095d46b0  pop r11
00007026095d46b2  pop r10
00007026095d46b4  pop r9
00007026095d46b6  pop r8
00007026095d46b8  pop rsi
00007026095d46b9  pop rdi
00007026095d46ba  pop rdx
00007026095d46bb  pop rcx
00007026095d46bc  pop rax
00007026095d46bd  add rsp, 0x08
00007026095d46c1  jmp 0x00007026095D3558
00007026095d46c6  sub rsp, 0x08
00007026095d46ca  push rax
00007026095d46cb  push rcx
00007026095d46cc  push rdx
00007026095d46cd  push rdi
00007026095d46ce  push rsi
00007026095d46cf  push r8
00007026095d46d1  push r9
00007026095d46d3  push r10
00007026095d46d5  push r11
00007026095d46d7  sub rsp, 0xF0
00007026095d46de  vmovaps [rsp], xmm0
00007026095d46e3  vmovaps [rsp+0x10], xmm1
00007026095d46e9  vmovaps [rsp+0x20], xmm3
00007026095d46ef  vmovaps [rsp+0x30], xmm4
00007026095d46f5  vmovaps [rsp+0x40], xmm5
00007026095d46fb  vmovaps [rsp+0x50], xmm6
00007026095d4701  vmovaps [rsp+0x60], xmm7
00007026095d4707  vmovaps [rsp+0x70], xmm8
00007026095d470d  vmovaps [rsp+0x80], xmm9
00007026095d4716  vmovaps [rsp+0x90], xmm10
00007026095d471f  vmovaps [rsp+0xA0], xmm11
00007026095d4728  vmovaps [rsp+0xB0], xmm12
00007026095d4731  vmovaps [rsp+0xC0], xmm13
00007026095d473a  vmovaps [rsp+0xD0], xmm14
00007026095d4743  vmovaps [rsp+0xE0], xmm15
00007026095d474c  sub rsp, 0x40
00007026095d4750  lea rdi, [rsp]
00007026095d4754  lea rsi, [rsp+0x10]
00007026095d4759  lea rdx, [rsp+0x20]
00007026095d475e  lea rcx, [rsp+0x30]
00007026095d4763  mov r8d, 0x00
00007026095d4769  lea r9, [r15+0x3A8]
00007026095d4770  movaps [rdi], xmm2
00007026095d4773  movaps [rsi], xmm14
00007026095d4777  movaps [rdx], xmm8
00007026095d477b  movaps [rcx], xmm5
00007026095d477e  mov rax, 0x58A432239A50
00007026095d4788  call rax
00007026095d478a  movaps xmm2, [rsp]
00007026095d478e  add rsp, 0x40
00007026095d4792  vmovaps xmm0, [rsp]
00007026095d4797  vmovaps xmm1, [rsp+0x10]
00007026095d479d  vmovaps xmm3, [rsp+0x20]
00007026095d47a3  vmovaps xmm4, [rsp+0x30]
00007026095d47a9  vmovaps xmm5, [rsp+0x40]
00007026095d47af  vmovaps xmm6, [rsp+0x50]
00007026095d47b5  vmovaps xmm7, [rsp+0x60]
00007026095d47bb  vmovaps xmm8, [rsp+0x70]
00007026095d47c1  vmovaps xmm9, [rsp+0x80]
00007026095d47ca  vmovaps xmm10, [rsp+0x90]
00007026095d47d3  vmovaps xmm11, [rsp+0xA0]
00007026095d47dc  vmovaps xmm12, [rsp+0xB0]
00007026095d47e5  vmovaps xmm13, [rsp+0xC0]
00007026095d47ee  vmovaps xmm14, [rsp+0xD0]
00007026095d47f7  vmovaps xmm15, [rsp+0xE0]
00007026095d4800  add rsp, 0xF0
00007026095d4807  pop r11
00007026095d4809  pop r10
00007026095d480b  pop r9
00007026095d480d  pop r8
00007026095d480f  pop rsi
00007026095d4810  pop rdi
00007026095d4811  pop rdx
00007026095d4812  pop rcx
00007026095d4813  pop rax
00007026095d4814  add rsp, 0x08
00007026095d4818  jmp 0x00007026095D360C
00007026095d481d  sub rsp, 0x08
00007026095d4821  push rax
00007026095d4822  push rcx
00007026095d4823  push rdx
00007026095d4824  push rdi
00007026095d4825  push rsi
00007026095d4826  push r8
00007026095d4828  push r9
00007026095d482a  push r10
00007026095d482c  push r11
00007026095d482e  sub rsp, 0xF0
00007026095d4835  vmovaps [rsp], xmm0
00007026095d483a  vmovaps [rsp+0x10], xmm1
00007026095d4840  vmovaps [rsp+0x20], xmm2
00007026095d4846  vmovaps [rsp+0x30], xmm3
00007026095d484c  vmovaps [rsp+0x40], xmm4
00007026095d4852  vmovaps [rsp+0x50], xmm6
00007026095d4858  vmovaps [rsp+0x60], xmm7
00007026095d485e  vmovaps [rsp+0x70], xmm8
00007026095d4864  vmovaps [rsp+0x80], xmm9
00007026095d486d  vmovaps [rsp+0x90], xmm10
00007026095d4876  vmovaps [rsp+0xA0], xmm11
00007026095d487f  vmovaps [rsp+0xB0], xmm12
00007026095d4888  vmovaps [rsp+0xC0], xmm13
00007026095d4891  vmovaps [rsp+0xD0], xmm14
00007026095d489a  vmovaps [rsp+0xE0], xmm15
00007026095d48a3  sub rsp, 0x40
00007026095d48a7  lea rdi, [rsp]
00007026095d48ab  lea rsi, [rsp+0x10]
00007026095d48b0  lea rdx, [rsp+0x20]
00007026095d48b5  lea rcx, [rsp+0x30]
00007026095d48ba  mov r8d, 0x00
00007026095d48c0  lea r9, [r15+0x3A8]
00007026095d48c7  movaps [rdi], xmm5
00007026095d48ca  movaps [rsi], xmm14
00007026095d48ce  movaps [rdx], xmm8
00007026095d48d2  movaps [rcx], xmm1
00007026095d48d5  mov rax, 0x58A432239A50
00007026095d48df  call rax
00007026095d48e1  movaps xmm5, [rsp]
00007026095d48e5  add rsp, 0x40
00007026095d48e9  vmovaps xmm0, [rsp]
00007026095d48ee  vmovaps xmm1, [rsp+0x10]
00007026095d48f4  vmovaps xmm2, [rsp+0x20]
00007026095d48fa  vmovaps xmm3, [rsp+0x30]
00007026095d4900  vmovaps xmm4, [rsp+0x40]
00007026095d4906  vmovaps xmm6, [rsp+0x50]
00007026095d490c  vmovaps xmm7, [rsp+0x60]
00007026095d4912  vmovaps xmm8, [rsp+0x70]
00007026095d4918  vmovaps xmm9, [rsp+0x80]
00007026095d4921  vmovaps xmm10, [rsp+0x90]
00007026095d492a  vmovaps xmm11, [rsp+0xA0]
00007026095d4933  vmovaps xmm12, [rsp+0xB0]
00007026095d493c  vmovaps xmm13, [rsp+0xC0]
00007026095d4945  vmovaps xmm14, [rsp+0xD0]
00007026095d494e  vmovaps xmm15, [rsp+0xE0]
00007026095d4957  add rsp, 0xF0
00007026095d495e  pop r11
00007026095d4960  pop r10
00007026095d4962  pop r9
00007026095d4964  pop r8
00007026095d4966  pop rsi
00007026095d4967  pop rdi
00007026095d4968  pop rdx
00007026095d4969  pop rcx
00007026095d496a  pop rax
00007026095d496b  add rsp, 0x08
00007026095d496f  jmp 0x00007026095D3649
00007026095d4974  sub rsp, 0x08
00007026095d4978  push rax
00007026095d4979  push rcx
00007026095d497a  push rdx
00007026095d497b  push rdi
00007026095d497c  push rsi
00007026095d497d  push r8
00007026095d497f  push r9
00007026095d4981  push r10
00007026095d4983  push r11
00007026095d4985  sub rsp, 0xF0
00007026095d498c  vmovaps [rsp], xmm0
00007026095d4991  vmovaps [rsp+0x10], xmm1
00007026095d4997  vmovaps [rsp+0x20], xmm2
00007026095d499d  vmovaps [rsp+0x30], xmm3
00007026095d49a3  vmovaps [rsp+0x40], xmm4
00007026095d49a9  vmovaps [rsp+0x50], xmm5
00007026095d49af  vmovaps [rsp+0x60], xmm6
00007026095d49b5  vmovaps [rsp+0x70], xmm7
00007026095d49bb  vmovaps [rsp+0x80], xmm8
00007026095d49c4  vmovaps [rsp+0x90], xmm9
00007026095d49cd  vmovaps [rsp+0xA0], xmm10
00007026095d49d6  vmovaps [rsp+0xB0], xmm11
00007026095d49df  vmovaps [rsp+0xC0], xmm12
00007026095d49e8  vmovaps [rsp+0xD0], xmm13
00007026095d49f1  vmovaps [rsp+0xE0], xmm14
00007026095d49fa  sub rsp, 0x40
00007026095d49fe  lea rdi, [rsp]
00007026095d4a02  lea rsi, [rsp+0x10]
00007026095d4a07  lea rdx, [rsp+0x20]
00007026095d4a0c  lea rcx, [rsp+0x30]
00007026095d4a11  mov r8d, 0x00
00007026095d4a17  lea r9, [r15+0x3A8]
00007026095d4a1e  movaps [rdi], xmm15
00007026095d4a22  movaps [rsi], xmm13
00007026095d4a26  movaps [rdx], xmm14
00007026095d4a2a  movaps [rcx], xmm1
00007026095d4a2d  mov rax, 0x58A432239A50
00007026095d4a37  call rax
00007026095d4a39  movaps xmm15, [rsp]
00007026095d4a3e  add rsp, 0x40
00007026095d4a42  vmovaps xmm0, [rsp]
00007026095d4a47  vmovaps xmm1, [rsp+0x10]
00007026095d4a4d  vmovaps xmm2, [rsp+0x20]
00007026095d4a53  vmovaps xmm3, [rsp+0x30]
00007026095d4a59  vmovaps xmm4, [rsp+0x40]
00007026095d4a5f  vmovaps xmm5, [rsp+0x50]
00007026095d4a65  vmovaps xmm6, [rsp+0x60]
00007026095d4a6b  vmovaps xmm7, [rsp+0x70]
00007026095d4a71  vmovaps xmm8, [rsp+0x80]
00007026095d4a7a  vmovaps xmm9, [rsp+0x90]
00007026095d4a83  vmovaps xmm10, [rsp+0xA0]
00007026095d4a8c  vmovaps xmm11, [rsp+0xB0]
00007026095d4a95  vmovaps xmm12, [rsp+0xC0]
00007026095d4a9e  vmovaps xmm13, [rsp+0xD0]
00007026095d4aa7  vmovaps xmm14, [rsp+0xE0]
00007026095d4ab0  add rsp, 0xF0
00007026095d4ab7  pop r11
00007026095d4ab9  pop r10
00007026095d4abb  pop r9
00007026095d4abd  pop r8
00007026095d4abf  pop rsi
00007026095d4ac0  pop rdi
00007026095d4ac1  pop rdx
00007026095d4ac2  pop rcx
00007026095d4ac3  pop rax
00007026095d4ac4  add rsp, 0x08
00007026095d4ac8  jmp 0x00007026095D3678
00007026095d4acd  sub rsp, 0x08
00007026095d4ad1  push rax
00007026095d4ad2  push rcx
00007026095d4ad3  push rdx
00007026095d4ad4  push rdi
00007026095d4ad5  push rsi
00007026095d4ad6  push r8
00007026095d4ad8  push r9
00007026095d4ada  push r10
00007026095d4adc  push r11
00007026095d4ade  sub rsp, 0xF0
00007026095d4ae5  vmovaps [rsp], xmm0
00007026095d4aea  vmovaps [rsp+0x10], xmm1
00007026095d4af0  vmovaps [rsp+0x20], xmm2
00007026095d4af6  vmovaps [rsp+0x30], xmm3
00007026095d4afc  vmovaps [rsp+0x40], xmm4
00007026095d4b02  vmovaps [rsp+0x50], xmm5
00007026095d4b08  vmovaps [rsp+0x60], xmm6
00007026095d4b0e  vmovaps [rsp+0x70], xmm7
00007026095d4b14  vmovaps [rsp+0x80], xmm8
00007026095d4b1d  vmovaps [rsp+0x90], xmm9
00007026095d4b26  vmovaps [rsp+0xA0], xmm10
00007026095d4b2f  vmovaps [rsp+0xB0], xmm11
00007026095d4b38  vmovaps [rsp+0xC0], xmm12
00007026095d4b41  vmovaps [rsp+0xD0], xmm14
00007026095d4b4a  vmovaps [rsp+0xE0], xmm15
00007026095d4b53  sub rsp, 0x40
00007026095d4b57  lea rdi, [rsp]
00007026095d4b5b  lea rsi, [rsp+0x10]
00007026095d4b60  lea rdx, [rsp+0x20]
00007026095d4b65  lea rcx, [rsp+0x30]
00007026095d4b6a  mov r8d, 0x00
00007026095d4b70  lea r9, [r15+0x3A8]
00007026095d4b77  movaps [rdi], xmm13
00007026095d4b7b  movaps [rsi], xmm12
00007026095d4b7f  movaps [rdx], xmm14
00007026095d4b83  movaps [rcx], xmm1
00007026095d4b86  mov rax, 0x58A432239A50
00007026095d4b90  call rax
00007026095d4b92  movaps xmm13, [rsp]
00007026095d4b97  add rsp, 0x40
00007026095d4b9b  vmovaps xmm0, [rsp]
00007026095d4ba0  vmovaps xmm1, [rsp+0x10]
00007026095d4ba6  vmovaps xmm2, [rsp+0x20]
00007026095d4bac  vmovaps xmm3, [rsp+0x30]
00007026095d4bb2  vmovaps xmm4, [rsp+0x40]
00007026095d4bb8  vmovaps xmm5, [rsp+0x50]
00007026095d4bbe  vmovaps xmm6, [rsp+0x60]
00007026095d4bc4  vmovaps xmm7, [rsp+0x70]
00007026095d4bca  vmovaps xmm8, [rsp+0x80]
00007026095d4bd3  vmovaps xmm9, [rsp+0x90]
00007026095d4bdc  vmovaps xmm10, [rsp+0xA0]
00007026095d4be5  vmovaps xmm11, [rsp+0xB0]
00007026095d4bee  vmovaps xmm12, [rsp+0xC0]
00007026095d4bf7  vmovaps xmm14, [rsp+0xD0]
00007026095d4c00  vmovaps xmm15, [rsp+0xE0]
00007026095d4c09  add rsp, 0xF0
00007026095d4c10  pop r11
00007026095d4c12  pop r10
00007026095d4c14  pop r9
00007026095d4c16  pop r8
00007026095d4c18  pop rsi
00007026095d4c19  pop rdi
00007026095d4c1a  pop rdx
00007026095d4c1b  pop rcx
00007026095d4c1c  pop rax
00007026095d4c1d  add rsp, 0x08
00007026095d4c21  jmp 0x00007026095D36AA
00007026095d4c26  sub rsp, 0x08
00007026095d4c2a  push rax
00007026095d4c2b  push rcx
00007026095d4c2c  push rdx
00007026095d4c2d  push rdi
00007026095d4c2e  push rsi
00007026095d4c2f  push r8
00007026095d4c31  push r9
00007026095d4c33  push r10
00007026095d4c35  push r11
00007026095d4c37  sub rsp, 0xF0
00007026095d4c3e  vmovaps [rsp], xmm0
00007026095d4c43  vmovaps [rsp+0x10], xmm1
00007026095d4c49  vmovaps [rsp+0x20], xmm2
00007026095d4c4f  vmovaps [rsp+0x30], xmm3
00007026095d4c55  vmovaps [rsp+0x40], xmm4
00007026095d4c5b  vmovaps [rsp+0x50], xmm5
00007026095d4c61  vmovaps [rsp+0x60], xmm6
00007026095d4c67  vmovaps [rsp+0x70], xmm7
00007026095d4c6d  vmovaps [rsp+0x80], xmm8
00007026095d4c76  vmovaps [rsp+0x90], xmm9
00007026095d4c7f  vmovaps [rsp+0xA0], xmm10
00007026095d4c88  vmovaps [rsp+0xB0], xmm11
00007026095d4c91  vmovaps [rsp+0xC0], xmm13
00007026095d4c9a  vmovaps [rsp+0xD0], xmm14
00007026095d4ca3  vmovaps [rsp+0xE0], xmm15
00007026095d4cac  sub rsp, 0x40
00007026095d4cb0  lea rdi, [rsp]
00007026095d4cb4  lea rsi, [rsp+0x10]
00007026095d4cb9  lea rdx, [rsp+0x20]
00007026095d4cbe  lea rcx, [rsp+0x30]
00007026095d4cc3  mov r8d, 0x00
00007026095d4cc9  lea r9, [r15+0x3A8]
00007026095d4cd0  movaps [rdi], xmm12
00007026095d4cd4  movaps [rsi], xmm5
00007026095d4cd7  movaps [rdx], xmm14
00007026095d4cdb  movaps [rcx], xmm4
00007026095d4cde  mov rax, 0x58A432239A50
00007026095d4ce8  call rax
00007026095d4cea  movaps xmm12, [rsp]
00007026095d4cef  add rsp, 0x40
00007026095d4cf3  vmovaps xmm0, [rsp]
00007026095d4cf8  vmovaps xmm1, [rsp+0x10]
00007026095d4cfe  vmovaps xmm2, [rsp+0x20]
00007026095d4d04  vmovaps xmm3, [rsp+0x30]
00007026095d4d0a  vmovaps xmm4, [rsp+0x40]
00007026095d4d10  vmovaps xmm5, [rsp+0x50]
00007026095d4d16  vmovaps xmm6, [rsp+0x60]
00007026095d4d1c  vmovaps xmm7, [rsp+0x70]
00007026095d4d22  vmovaps xmm8, [rsp+0x80]
00007026095d4d2b  vmovaps xmm9, [rsp+0x90]
00007026095d4d34  vmovaps xmm10, [rsp+0xA0]
00007026095d4d3d  vmovaps xmm11, [rsp+0xB0]
00007026095d4d46  vmovaps xmm13, [rsp+0xC0]
00007026095d4d4f  vmovaps xmm14, [rsp+0xD0]
00007026095d4d58  vmovaps xmm15, [rsp+0xE0]
00007026095d4d61  add rsp, 0xF0
00007026095d4d68  pop r11
00007026095d4d6a  pop r10
00007026095d4d6c  pop r9
00007026095d4d6e  pop r8
00007026095d4d70  pop rsi
00007026095d4d71  pop rdi
00007026095d4d72  pop rdx
00007026095d4d73  pop rcx
00007026095d4d74  pop rax
00007026095d4d75  add rsp, 0x08
00007026095d4d79  jmp 0x00007026095D3720
00007026095d4d7e  sub rsp, 0x08
00007026095d4d82  push rax
00007026095d4d83  push rcx
00007026095d4d84  push rdx
00007026095d4d85  push rdi
00007026095d4d86  push rsi
00007026095d4d87  push r8
00007026095d4d89  push r9
00007026095d4d8b  push r10
00007026095d4d8d  push r11
00007026095d4d8f  sub rsp, 0xF0
00007026095d4d96  vmovaps [rsp], xmm0
00007026095d4d9b  vmovaps [rsp+0x10], xmm1
00007026095d4da1  vmovaps [rsp+0x20], xmm2
00007026095d4da7  vmovaps [rsp+0x30], xmm3
00007026095d4dad  vmovaps [rsp+0x40], xmm4
00007026095d4db3  vmovaps [rsp+0x50], xmm5
00007026095d4db9  vmovaps [rsp+0x60], xmm6
00007026095d4dbf  vmovaps [rsp+0x70], xmm7
00007026095d4dc5  vmovaps [rsp+0x80], xmm8
00007026095d4dce  vmovaps [rsp+0x90], xmm9
00007026095d4dd7  vmovaps [rsp+0xA0], xmm11
00007026095d4de0  vmovaps [rsp+0xB0], xmm12
00007026095d4de9  vmovaps [rsp+0xC0], xmm13
00007026095d4df2  vmovaps [rsp+0xD0], xmm14
00007026095d4dfb  vmovaps [rsp+0xE0], xmm15
00007026095d4e04  sub rsp, 0x40
00007026095d4e08  lea rdi, [rsp]
00007026095d4e0c  lea rsi, [rsp+0x10]
00007026095d4e11  lea rdx, [rsp+0x20]
00007026095d4e16  lea rcx, [rsp+0x30]
00007026095d4e1b  mov r8d, 0x00
00007026095d4e21  lea r9, [r15+0x3A8]
00007026095d4e28  movaps [rdi], xmm10
00007026095d4e2c  movaps [rsi], xmm2
00007026095d4e2f  movaps [rdx], xmm6
00007026095d4e32  movaps [rcx], xmm14
00007026095d4e36  mov rax, 0x58A432239A50
00007026095d4e40  call rax
00007026095d4e42  movaps xmm10, [rsp]
00007026095d4e47  add rsp, 0x40
00007026095d4e4b  vmovaps xmm0, [rsp]
00007026095d4e50  vmovaps xmm1, [rsp+0x10]
00007026095d4e56  vmovaps xmm2, [rsp+0x20]
00007026095d4e5c  vmovaps xmm3, [rsp+0x30]
00007026095d4e62  vmovaps xmm4, [rsp+0x40]
00007026095d4e68  vmovaps xmm5, [rsp+0x50]
00007026095d4e6e  vmovaps xmm6, [rsp+0x60]
00007026095d4e74  vmovaps xmm7, [rsp+0x70]
00007026095d4e7a  vmovaps xmm8, [rsp+0x80]
00007026095d4e83  vmovaps xmm9, [rsp+0x90]
00007026095d4e8c  vmovaps xmm11, [rsp+0xA0]
00007026095d4e95  vmovaps xmm12, [rsp+0xB0]
00007026095d4e9e  vmovaps xmm13, [rsp+0xC0]
00007026095d4ea7  vmovaps xmm14, [rsp+0xD0]
00007026095d4eb0  vmovaps xmm15, [rsp+0xE0]
00007026095d4eb9  add rsp, 0xF0
00007026095d4ec0  pop r11
00007026095d4ec2  pop r10
00007026095d4ec4  pop r9
00007026095d4ec6  pop r8
00007026095d4ec8  pop rsi
00007026095d4ec9  pop rdi
00007026095d4eca  pop rdx
00007026095d4ecb  pop rcx
00007026095d4ecc  pop rax
00007026095d4ecd  add rsp, 0x08
00007026095d4ed1  jmp 0x00007026095D3746
00007026095d4ed6  call 0x00007026094E45A0
00007026095d4edb  jmp 0x00007026095D3753
00007026095d4ee0  sub rsp, 0x08
00007026095d4ee4  push rax
00007026095d4ee5  push rcx
00007026095d4ee6  push rdx
00007026095d4ee7  push rdi
00007026095d4ee8  push rsi
00007026095d4ee9  push r8
00007026095d4eeb  push r9
00007026095d4eed  push r10
00007026095d4eef  push r11
00007026095d4ef1  sub rsp, 0xF0
00007026095d4ef8  vmovaps [rsp], xmm0
00007026095d4efd  vmovaps [rsp+0x10], xmm1
00007026095d4f03  vmovaps [rsp+0x20], xmm2
00007026095d4f09  vmovaps [rsp+0x30], xmm3
00007026095d4f0f  vmovaps [rsp+0x40], xmm4
00007026095d4f15  vmovaps [rsp+0x50], xmm6
00007026095d4f1b  vmovaps [rsp+0x60], xmm7
00007026095d4f21  vmovaps [rsp+0x70], xmm8
00007026095d4f27  vmovaps [rsp+0x80], xmm9
00007026095d4f30  vmovaps [rsp+0x90], xmm10
00007026095d4f39  vmovaps [rsp+0xA0], xmm11
00007026095d4f42  vmovaps [rsp+0xB0], xmm12
00007026095d4f4b  vmovaps [rsp+0xC0], xmm13
00007026095d4f54  vmovaps [rsp+0xD0], xmm14
00007026095d4f5d  vmovaps [rsp+0xE0], xmm15
00007026095d4f66  sub rsp, 0x40
00007026095d4f6a  lea rdi, [rsp]
00007026095d4f6e  lea rsi, [rsp+0x10]
00007026095d4f73  lea rdx, [rsp+0x20]
00007026095d4f78  lea rcx, [rsp+0x30]
00007026095d4f7d  mov r8d, 0x00
00007026095d4f83  lea r9, [r15+0x3A8]
00007026095d4f8a  movaps [rdi], xmm5
00007026095d4f8d  movaps [rsi], xmm15
00007026095d4f91  movaps [rdx], xmm6
00007026095d4f94  movaps [rcx], xmm8
00007026095d4f98  mov rax, 0x58A432239A50
00007026095d4fa2  call rax
00007026095d4fa4  movaps xmm5, [rsp]
00007026095d4fa8  add rsp, 0x40
00007026095d4fac  vmovaps xmm0, [rsp]
00007026095d4fb1  vmovaps xmm1, [rsp+0x10]
00007026095d4fb7  vmovaps xmm2, [rsp+0x20]
00007026095d4fbd  vmovaps xmm3, [rsp+0x30]
00007026095d4fc3  vmovaps xmm4, [rsp+0x40]
00007026095d4fc9  vmovaps xmm6, [rsp+0x50]
00007026095d4fcf  vmovaps xmm7, [rsp+0x60]
00007026095d4fd5  vmovaps xmm8, [rsp+0x70]
00007026095d4fdb  vmovaps xmm9, [rsp+0x80]
00007026095d4fe4  vmovaps xmm10, [rsp+0x90]
00007026095d4fed  vmovaps xmm11, [rsp+0xA0]
00007026095d4ff6  vmovaps xmm12, [rsp+0xB0]
00007026095d4fff  vmovaps xmm13, [rsp+0xC0]
00007026095d5008  vmovaps xmm14, [rsp+0xD0]
00007026095d5011  vmovaps xmm15, [rsp+0xE0]
00007026095d501a  add rsp, 0xF0
00007026095d5021  pop r11
00007026095d5023  pop r10
00007026095d5025  pop r9
00007026095d5027  pop r8
00007026095d5029  pop rsi
00007026095d502a  pop rdi
00007026095d502b  pop rdx
00007026095d502c  pop rcx
00007026095d502d  pop rax
00007026095d502e  add rsp, 0x08
00007026095d5032  jmp 0x00007026095D3789
00007026095d5037  sub rsp, 0x08
00007026095d503b  push rax
00007026095d503c  push rcx
00007026095d503d  push rdx
00007026095d503e  push rdi
00007026095d503f  push rsi
00007026095d5040  push r8
00007026095d5042  push r9
00007026095d5044  push r10
00007026095d5046  push r11
00007026095d5048  sub rsp, 0xF0
00007026095d504f  vmovaps [rsp], xmm0
00007026095d5054  vmovaps [rsp+0x10], xmm1
00007026095d505a  vmovaps [rsp+0x20], xmm2
00007026095d5060  vmovaps [rsp+0x30], xmm3
00007026095d5066  vmovaps [rsp+0x40], xmm4
00007026095d506c  vmovaps [rsp+0x50], xmm5
00007026095d5072  vmovaps [rsp+0x60], xmm6
00007026095d5078  vmovaps [rsp+0x70], xmm7
00007026095d507e  vmovaps [rsp+0x80], xmm9
00007026095d5087  vmovaps [rsp+0x90], xmm10
00007026095d5090  vmovaps [rsp+0xA0], xmm11
00007026095d5099  vmovaps [rsp+0xB0], xmm12
00007026095d50a2  vmovaps [rsp+0xC0], xmm13
00007026095d50ab  vmovaps [rsp+0xD0], xmm14
00007026095d50b4  vmovaps [rsp+0xE0], xmm15
00007026095d50bd  sub rsp, 0x40
00007026095d50c1  lea rdi, [rsp]
00007026095d50c5  lea rsi, [rsp+0x10]
00007026095d50ca  lea rdx, [rsp+0x20]
00007026095d50cf  lea rcx, [rsp+0x30]
00007026095d50d4  mov r8d, 0x00
00007026095d50da  lea r9, [r15+0x3A8]
00007026095d50e1  movaps [rdi], xmm8
00007026095d50e5  movaps [rsi], xmm13
00007026095d50e9  movaps [rdx], xmm1
00007026095d50ec  movaps [rcx], xmm15
00007026095d50f0  mov rax, 0x58A432239A50
00007026095d50fa  call rax
00007026095d50fc  movaps xmm8, [rsp]
00007026095d5101  add rsp, 0x40
00007026095d5105  vmovaps xmm0, [rsp]
00007026095d510a  vmovaps xmm1, [rsp+0x10]
00007026095d5110  vmovaps xmm2, [rsp+0x20]
00007026095d5116  vmovaps xmm3, [rsp+0x30]
00007026095d511c  vmovaps xmm4, [rsp+0x40]
00007026095d5122  vmovaps xmm5, [rsp+0x50]
00007026095d5128  vmovaps xmm6, [rsp+0x60]
00007026095d512e  vmovaps xmm7, [rsp+0x70]
00007026095d5134  vmovaps xmm9, [rsp+0x80]
00007026095d513d  vmovaps xmm10, [rsp+0x90]
00007026095d5146  vmovaps xmm11, [rsp+0xA0]
00007026095d514f  vmovaps xmm12, [rsp+0xB0]
00007026095d5158  vmovaps xmm13, [rsp+0xC0]
00007026095d5161  vmovaps xmm14, [rsp+0xD0]
00007026095d516a  vmovaps xmm15, [rsp+0xE0]
00007026095d5173  add rsp, 0xF0
00007026095d517a  pop r11
00007026095d517c  pop r10
00007026095d517e  pop r9
00007026095d5180  pop r8
00007026095d5182  pop rsi
00007026095d5183  pop rdi
00007026095d5184  pop rdx
00007026095d5185  pop rcx
00007026095d5186  pop rax
00007026095d5187  add rsp, 0x08
00007026095d518b  jmp 0x00007026095D37AF
00007026095d5190  call 0x00007026094E5820
00007026095d5195  jmp 0x00007026095D37D2
00007026095d519a  call 0x00007026094E3320
00007026095d519f  jmp 0x00007026095D37DC
00007026095d51a4  sub rsp, 0x08
00007026095d51a8  push rax
00007026095d51a9  push rcx
00007026095d51aa  push rdx
00007026095d51ab  push rdi
00007026095d51ac  push rsi
00007026095d51ad  push r8
00007026095d51af  push r9
00007026095d51b1  push r10
00007026095d51b3  push r11
00007026095d51b5  sub rsp, 0xF0
00007026095d51bc  vmovaps [rsp], xmm0
00007026095d51c1  vmovaps [rsp+0x10], xmm1
00007026095d51c7  vmovaps [rsp+0x20], xmm2
00007026095d51cd  vmovaps [rsp+0x30], xmm3
00007026095d51d3  vmovaps [rsp+0x40], xmm5
00007026095d51d9  vmovaps [rsp+0x50], xmm6
00007026095d51df  vmovaps [rsp+0x60], xmm7
00007026095d51e5  vmovaps [rsp+0x70], xmm8
00007026095d51eb  vmovaps [rsp+0x80], xmm9
00007026095d51f4  vmovaps [rsp+0x90], xmm10
00007026095d51fd  vmovaps [rsp+0xA0], xmm11
00007026095d5206  vmovaps [rsp+0xB0], xmm12
00007026095d520f  vmovaps [rsp+0xC0], xmm13
00007026095d5218  vmovaps [rsp+0xD0], xmm14
00007026095d5221  vmovaps [rsp+0xE0], xmm15
00007026095d522a  sub rsp, 0x40
00007026095d522e  lea rdi, [rsp]
00007026095d5232  lea rsi, [rsp+0x10]
00007026095d5237  lea rdx, [rsp+0x20]
00007026095d523c  lea rcx, [rsp+0x30]
00007026095d5241  mov r8d, 0x00
00007026095d5247  lea r9, [r15+0x3A8]
00007026095d524e  movaps [rdi], xmm4
00007026095d5251  movaps [rsi], xmm12
00007026095d5255  movaps [rdx], xmm9
00007026095d5259  movaps [rcx], xmm6
00007026095d525c  mov rax, 0x58A432239A50
00007026095d5266  call rax
00007026095d5268  movaps xmm4, [rsp]
00007026095d526c  add rsp, 0x40
00007026095d5270  vmovaps xmm0, [rsp]
00007026095d5275  vmovaps xmm1, [rsp+0x10]
00007026095d527b  vmovaps xmm2, [rsp+0x20]
00007026095d5281  vmovaps xmm3, [rsp+0x30]
00007026095d5287  vmovaps xmm5, [rsp+0x40]
00007026095d528d  vmovaps xmm6, [rsp+0x50]
00007026095d5293  vmovaps xmm7, [rsp+0x60]
00007026095d5299  vmovaps xmm8, [rsp+0x70]
00007026095d529f  vmovaps xmm9, [rsp+0x80]
00007026095d52a8  vmovaps xmm10, [rsp+0x90]
00007026095d52b1  vmovaps xmm11, [rsp+0xA0]
00007026095d52ba  vmovaps xmm12, [rsp+0xB0]
00007026095d52c3  vmovaps xmm13, [rsp+0xC0]
00007026095d52cc  vmovaps xmm14, [rsp+0xD0]
00007026095d52d5  vmovaps xmm15, [rsp+0xE0]
00007026095d52de  add rsp, 0xF0
00007026095d52e5  pop r11
00007026095d52e7  pop r10
00007026095d52e9  pop r9
00007026095d52eb  pop r8
00007026095d52ed  pop rsi
00007026095d52ee  pop rdi
00007026095d52ef  pop rdx
00007026095d52f0  pop rcx
00007026095d52f1  pop rax
00007026095d52f2  add rsp, 0x08
00007026095d52f6  jmp 0x00007026095D3814
00007026095d52fb  sub rsp, 0x08
00007026095d52ff  push rax
00007026095d5300  push rcx
00007026095d5301  push rdx
00007026095d5302  push rdi
00007026095d5303  push rsi
00007026095d5304  push r8
00007026095d5306  push r9
00007026095d5308  push r10
00007026095d530a  push r11
00007026095d530c  sub rsp, 0xF0
00007026095d5313  vmovaps [rsp], xmm0
00007026095d5318  vmovaps [rsp+0x10], xmm1
00007026095d531e  vmovaps [rsp+0x20], xmm2
00007026095d5324  vmovaps [rsp+0x30], xmm3
00007026095d532a  vmovaps [rsp+0x40], xmm4
00007026095d5330  vmovaps [rsp+0x50], xmm5
00007026095d5336  vmovaps [rsp+0x60], xmm6
00007026095d533c  vmovaps [rsp+0x70], xmm7
00007026095d5342  vmovaps [rsp+0x80], xmm8
00007026095d534b  vmovaps [rsp+0x90], xmm10
00007026095d5354  vmovaps [rsp+0xA0], xmm11
00007026095d535d  vmovaps [rsp+0xB0], xmm12
00007026095d5366  vmovaps [rsp+0xC0], xmm13
00007026095d536f  vmovaps [rsp+0xD0], xmm14
00007026095d5378  vmovaps [rsp+0xE0], xmm15
00007026095d5381  sub rsp, 0x40
00007026095d5385  lea rdi, [rsp]
00007026095d5389  lea rsi, [rsp+0x10]
00007026095d538e  lea rdx, [rsp+0x20]
00007026095d5393  lea rcx, [rsp+0x30]
00007026095d5398  mov r8d, 0x00
00007026095d539e  lea r9, [r15+0x3A8]
00007026095d53a5  movaps [rdi], xmm9
00007026095d53a9  movaps [rsi], xmm10
00007026095d53ad  movaps [rdx], xmm1
00007026095d53b0  movaps [rcx], xmm12
00007026095d53b4  mov rax, 0x58A432239A50
00007026095d53be  call rax
00007026095d53c0  movaps xmm9, [rsp]
00007026095d53c5  add rsp, 0x40
00007026095d53c9  vmovaps xmm0, [rsp]
00007026095d53ce  vmovaps xmm1, [rsp+0x10]
00007026095d53d4  vmovaps xmm2, [rsp+0x20]
00007026095d53da  vmovaps xmm3, [rsp+0x30]
00007026095d53e0  vmovaps xmm4, [rsp+0x40]
00007026095d53e6  vmovaps xmm5, [rsp+0x50]
00007026095d53ec  vmovaps xmm6, [rsp+0x60]
00007026095d53f2  vmovaps xmm7, [rsp+0x70]
00007026095d53f8  vmovaps xmm8, [rsp+0x80]
00007026095d5401  vmovaps xmm10, [rsp+0x90]
00007026095d540a  vmovaps xmm11, [rsp+0xA0]
00007026095d5413  vmovaps xmm12, [rsp+0xB0]
00007026095d541c  vmovaps xmm13, [rsp+0xC0]
00007026095d5425  vmovaps xmm14, [rsp+0xD0]
00007026095d542e  vmovaps xmm15, [rsp+0xE0]
00007026095d5437  add rsp, 0xF0
00007026095d543e  pop r11
00007026095d5440  pop r10
00007026095d5442  pop r9
00007026095d5444  pop r8
00007026095d5446  pop rsi
00007026095d5447  pop rdi
00007026095d5448  pop rdx
00007026095d5449  pop rcx
00007026095d544a  pop rax
00007026095d544b  add rsp, 0x08
00007026095d544f  jmp 0x00007026095D383D
00007026095d5454  sub rsp, 0x08
00007026095d5458  push rax
00007026095d5459  push rcx
00007026095d545a  push rdx
00007026095d545b  push rdi
00007026095d545c  push rsi
00007026095d545d  push r8
00007026095d545f  push r9
00007026095d5461  push r10
00007026095d5463  push r11
00007026095d5465  sub rsp, 0xF0
00007026095d546c  vmovaps [rsp], xmm0
00007026095d5471  vmovaps [rsp+0x10], xmm1
00007026095d5477  vmovaps [rsp+0x20], xmm2
00007026095d547d  vmovaps [rsp+0x30], xmm3
00007026095d5483  vmovaps [rsp+0x40], xmm4
00007026095d5489  vmovaps [rsp+0x50], xmm5
00007026095d548f  vmovaps [rsp+0x60], xmm6
00007026095d5495  vmovaps [rsp+0x70], xmm7
00007026095d549b  vmovaps [rsp+0x80], xmm8
00007026095d54a4  vmovaps [rsp+0x90], xmm9
00007026095d54ad  vmovaps [rsp+0xA0], xmm11
00007026095d54b6  vmovaps [rsp+0xB0], xmm12
00007026095d54bf  vmovaps [rsp+0xC0], xmm13
00007026095d54c8  vmovaps [rsp+0xD0], xmm14
00007026095d54d1  vmovaps [rsp+0xE0], xmm15
00007026095d54da  sub rsp, 0x40
00007026095d54de  lea rdi, [rsp]
00007026095d54e2  lea rsi, [rsp+0x10]
00007026095d54e7  lea rdx, [rsp+0x20]
00007026095d54ec  lea rcx, [rsp+0x30]
00007026095d54f1  mov r8d, 0x00
00007026095d54f7  lea r9, [r15+0x3A8]
00007026095d54fe  movaps [rdi], xmm10
00007026095d5502  movaps [rsi], xmm5
00007026095d5505  movaps [rdx], xmm12
00007026095d5509  movaps [rcx], xmm1
00007026095d550c  mov rax, 0x58A432239A50
00007026095d5516  call rax
00007026095d5518  movaps xmm10, [rsp]
00007026095d551d  add rsp, 0x40
00007026095d5521  vmovaps xmm0, [rsp]
00007026095d5526  vmovaps xmm1, [rsp+0x10]
00007026095d552c  vmovaps xmm2, [rsp+0x20]
00007026095d5532  vmovaps xmm3, [rsp+0x30]
00007026095d5538  vmovaps xmm4, [rsp+0x40]
00007026095d553e  vmovaps xmm5, [rsp+0x50]
00007026095d5544  vmovaps xmm6, [rsp+0x60]
00007026095d554a  vmovaps xmm7, [rsp+0x70]
00007026095d5550  vmovaps xmm8, [rsp+0x80]
00007026095d5559  vmovaps xmm9, [rsp+0x90]
00007026095d5562  vmovaps xmm11, [rsp+0xA0]
00007026095d556b  vmovaps xmm12, [rsp+0xB0]
00007026095d5574  vmovaps xmm13, [rsp+0xC0]
00007026095d557d  vmovaps xmm14, [rsp+0xD0]
00007026095d5586  vmovaps xmm15, [rsp+0xE0]
00007026095d558f  add rsp, 0xF0
00007026095d5596  pop r11
00007026095d5598  pop r10
00007026095d559a  pop r9
00007026095d559c  pop r8
00007026095d559e  pop rsi
00007026095d559f  pop rdi
00007026095d55a0  pop rdx
00007026095d55a1  pop rcx
00007026095d55a2  pop rax
00007026095d55a3  add rsp, 0x08
00007026095d55a7  jmp 0x00007026095D386C
00007026095d55ac  sub rsp, 0x08
00007026095d55b0  push rax
00007026095d55b1  push rcx
00007026095d55b2  push rdx
00007026095d55b3  push rdi
00007026095d55b4  push rsi
00007026095d55b5  push r8
00007026095d55b7  push r9
00007026095d55b9  push r10
00007026095d55bb  push r11
00007026095d55bd  sub rsp, 0xF0
00007026095d55c4  vmovaps [rsp], xmm0
00007026095d55c9  vmovaps [rsp+0x10], xmm1
00007026095d55cf  vmovaps [rsp+0x20], xmm2
00007026095d55d5  vmovaps [rsp+0x30], xmm3
00007026095d55db  vmovaps [rsp+0x40], xmm4
00007026095d55e1  vmovaps [rsp+0x50], xmm5
00007026095d55e7  vmovaps [rsp+0x60], xmm7
00007026095d55ed  vmovaps [rsp+0x70], xmm8
00007026095d55f3  vmovaps [rsp+0x80], xmm9
00007026095d55fc  vmovaps [rsp+0x90], xmm10
00007026095d5605  vmovaps [rsp+0xA0], xmm11
00007026095d560e  vmovaps [rsp+0xB0], xmm12
00007026095d5617  vmovaps [rsp+0xC0], xmm13
00007026095d5620  vmovaps [rsp+0xD0], xmm14
00007026095d5629  vmovaps [rsp+0xE0], xmm15
00007026095d5632  sub rsp, 0x40
00007026095d5636  lea rdi, [rsp]
00007026095d563a  lea rsi, [rsp+0x10]
00007026095d563f  lea rdx, [rsp+0x20]
00007026095d5644  lea rcx, [rsp+0x30]
00007026095d5649  mov r8d, 0x00
00007026095d564f  lea r9, [r15+0x3A8]
00007026095d5656  movaps [rdi], xmm6
00007026095d5659  movaps [rsi], xmm8
00007026095d565d  movaps [rdx], xmm12
00007026095d5661  movaps [rcx], xmm1
00007026095d5664  mov rax, 0x58A432239A50
00007026095d566e  call rax
00007026095d5670  movaps xmm6, [rsp]
00007026095d5674  add rsp, 0x40
00007026095d5678  vmovaps xmm0, [rsp]
00007026095d567d  vmovaps xmm1, [rsp+0x10]
00007026095d5683  vmovaps xmm2, [rsp+0x20]
00007026095d5689  vmovaps xmm3, [rsp+0x30]
00007026095d568f  vmovaps xmm4, [rsp+0x40]
00007026095d5695  vmovaps xmm5, [rsp+0x50]
00007026095d569b  vmovaps xmm7, [rsp+0x60]
00007026095d56a1  vmovaps xmm8, [rsp+0x70]
00007026095d56a7  vmovaps xmm9, [rsp+0x80]
00007026095d56b0  vmovaps xmm10, [rsp+0x90]
00007026095d56b9  vmovaps xmm11, [rsp+0xA0]
00007026095d56c2  vmovaps xmm12, [rsp+0xB0]
00007026095d56cb  vmovaps xmm13, [rsp+0xC0]
00007026095d56d4  vmovaps xmm14, [rsp+0xD0]
00007026095d56dd  vmovaps xmm15, [rsp+0xE0]
00007026095d56e6  add rsp, 0xF0
00007026095d56ed  pop r11
00007026095d56ef  pop r10
00007026095d56f1  pop r9
00007026095d56f3  pop r8
00007026095d56f5  pop rsi
00007026095d56f6  pop rdi
00007026095d56f7  pop rdx
00007026095d56f8  pop rcx
00007026095d56f9  pop rax
00007026095d56fa  add rsp, 0x08
00007026095d56fe  jmp 0x00007026095D389A
00007026095d5703  call 0x00007026094D64F0
00007026095d5708  jmp 0x00007026095D38A4
00007026095d570d  call 0x00007026094E20A0
00007026095d5712  jmp 0x00007026095D38AE
00007026095d5717  sub rsp, 0x08
00007026095d571b  push rax
00007026095d571c  push rcx
00007026095d571d  push rdx
00007026095d571e  push rdi
00007026095d571f  push rsi
00007026095d5720  push r8
00007026095d5722  push r9
00007026095d5724  push r10
00007026095d5726  push r11
00007026095d5728  sub rsp, 0xF0
00007026095d572f  vmovaps [rsp], xmm0
00007026095d5734  vmovaps [rsp+0x10], xmm1
00007026095d573a  vmovaps [rsp+0x20], xmm2
00007026095d5740  vmovaps [rsp+0x30], xmm3
00007026095d5746  vmovaps [rsp+0x40], xmm4
00007026095d574c  vmovaps [rsp+0x50], xmm5
00007026095d5752  vmovaps [rsp+0x60], xmm6
00007026095d5758  vmovaps [rsp+0x70], xmm7
00007026095d575e  vmovaps [rsp+0x80], xmm9
00007026095d5767  vmovaps [rsp+0x90], xmm10
00007026095d5770  vmovaps [rsp+0xA0], xmm11
00007026095d5779  vmovaps [rsp+0xB0], xmm12
00007026095d5782  vmovaps [rsp+0xC0], xmm13
00007026095d578b  vmovaps [rsp+0xD0], xmm14
00007026095d5794  vmovaps [rsp+0xE0], xmm15
00007026095d579d  sub rsp, 0x40
00007026095d57a1  lea rdi, [rsp]
00007026095d57a5  lea rsi, [rsp+0x10]
00007026095d57aa  lea rdx, [rsp+0x20]
00007026095d57af  lea rcx, [rsp+0x30]
00007026095d57b4  mov r8d, 0x00
00007026095d57ba  lea r9, [r15+0x3A8]
00007026095d57c1  movaps [rdi], xmm8
00007026095d57c5  movaps [rsi], xmm4
00007026095d57c8  movaps [rdx], xmm13
00007026095d57cc  movaps [rcx], xmm11
00007026095d57d0  mov rax, 0x58A432239A50
00007026095d57da  call rax
00007026095d57dc  movaps xmm8, [rsp]
00007026095d57e1  add rsp, 0x40
00007026095d57e5  vmovaps xmm0, [rsp]
00007026095d57ea  vmovaps xmm1, [rsp+0x10]
00007026095d57f0  vmovaps xmm2, [rsp+0x20]
00007026095d57f6  vmovaps xmm3, [rsp+0x30]
00007026095d57fc  vmovaps xmm4, [rsp+0x40]
00007026095d5802  vmovaps xmm5, [rsp+0x50]
00007026095d5808  vmovaps xmm6, [rsp+0x60]
00007026095d580e  vmovaps xmm7, [rsp+0x70]
00007026095d5814  vmovaps xmm9, [rsp+0x80]
00007026095d581d  vmovaps xmm10, [rsp+0x90]
00007026095d5826  vmovaps xmm11, [rsp+0xA0]
00007026095d582f  vmovaps xmm12, [rsp+0xB0]
00007026095d5838  vmovaps xmm13, [rsp+0xC0]
00007026095d5841  vmovaps xmm14, [rsp+0xD0]
00007026095d584a  vmovaps xmm15, [rsp+0xE0]
00007026095d5853  add rsp, 0xF0
00007026095d585a  pop r11
00007026095d585c  pop r10
00007026095d585e  pop r9
00007026095d5860  pop r8
00007026095d5862  pop rsi
00007026095d5863  pop rdi
00007026095d5864  pop rdx
00007026095d5865  pop rcx
00007026095d5866  pop rax
00007026095d5867  add rsp, 0x08
00007026095d586b  jmp 0x00007026095D38E4
00007026095d5870  sub rsp, 0x08
00007026095d5874  push rax
00007026095d5875  push rcx
00007026095d5876  push rdx
00007026095d5877  push rdi
00007026095d5878  push rsi
00007026095d5879  push r8
00007026095d587b  push r9
00007026095d587d  push r10
00007026095d587f  push r11
00007026095d5881  sub rsp, 0xF0
00007026095d5888  vmovaps [rsp], xmm0
00007026095d588d  vmovaps [rsp+0x10], xmm1
00007026095d5893  vmovaps [rsp+0x20], xmm2
00007026095d5899  vmovaps [rsp+0x30], xmm3
00007026095d589f  vmovaps [rsp+0x40], xmm4
00007026095d58a5  vmovaps [rsp+0x50], xmm5
00007026095d58ab  vmovaps [rsp+0x60], xmm6
00007026095d58b1  vmovaps [rsp+0x70], xmm7
00007026095d58b7  vmovaps [rsp+0x80], xmm8
00007026095d58c0  vmovaps [rsp+0x90], xmm9
00007026095d58c9  vmovaps [rsp+0xA0], xmm10
00007026095d58d2  vmovaps [rsp+0xB0], xmm12
00007026095d58db  vmovaps [rsp+0xC0], xmm13
00007026095d58e4  vmovaps [rsp+0xD0], xmm14
00007026095d58ed  vmovaps [rsp+0xE0], xmm15
00007026095d58f6  sub rsp, 0x40
00007026095d58fa  lea rdi, [rsp]
00007026095d58fe  lea rsi, [rsp+0x10]
00007026095d5903  lea rdx, [rsp+0x20]
00007026095d5908  lea rcx, [rsp+0x30]
00007026095d590d  mov r8d, 0x00
00007026095d5913  lea r9, [r15+0x3A8]
00007026095d591a  movaps [rdi], xmm11
00007026095d591e  movaps [rsi], xmm9
00007026095d5922  movaps [rdx], xmm1
00007026095d5925  movaps [rcx], xmm13
00007026095d5929  mov rax, 0x58A432239A50
00007026095d5933  call rax
00007026095d5935  movaps xmm11, [rsp]
00007026095d593a  add rsp, 0x40
00007026095d593e  vmovaps xmm0, [rsp]
00007026095d5943  vmovaps xmm1, [rsp+0x10]
00007026095d5949  vmovaps xmm2, [rsp+0x20]
00007026095d594f  vmovaps xmm3, [rsp+0x30]
00007026095d5955  vmovaps xmm4, [rsp+0x40]
00007026095d595b  vmovaps xmm5, [rsp+0x50]
00007026095d5961  vmovaps xmm6, [rsp+0x60]
00007026095d5967  vmovaps xmm7, [rsp+0x70]
00007026095d596d  vmovaps xmm8, [rsp+0x80]
00007026095d5976  vmovaps xmm9, [rsp+0x90]
00007026095d597f  vmovaps xmm10, [rsp+0xA0]
00007026095d5988  vmovaps xmm12, [rsp+0xB0]
00007026095d5991  vmovaps xmm13, [rsp+0xC0]
00007026095d599a  vmovaps xmm14, [rsp+0xD0]
00007026095d59a3  vmovaps xmm15, [rsp+0xE0]
00007026095d59ac  add rsp, 0xF0
00007026095d59b3  pop r11
00007026095d59b5  pop r10
00007026095d59b7  pop r9
00007026095d59b9  pop r8
00007026095d59bb  pop rsi
00007026095d59bc  pop rdi
00007026095d59bd  pop rdx
00007026095d59be  pop rcx
00007026095d59bf  pop rax
00007026095d59c0  add rsp, 0x08
00007026095d59c4  jmp 0x00007026095D390A
00007026095d59c9  sub rsp, 0x08
00007026095d59cd  push rax
00007026095d59ce  push rcx
00007026095d59cf  push rdx
00007026095d59d0  push rdi
00007026095d59d1  push rsi
00007026095d59d2  push r8
00007026095d59d4  push r9
00007026095d59d6  push r10
00007026095d59d8  push r11
00007026095d59da  sub rsp, 0xF0
00007026095d59e1  vmovaps [rsp], xmm0
00007026095d59e6  vmovaps [rsp+0x10], xmm1
00007026095d59ec  vmovaps [rsp+0x20], xmm2
00007026095d59f2  vmovaps [rsp+0x30], xmm3
00007026095d59f8  vmovaps [rsp+0x40], xmm4
00007026095d59fe  vmovaps [rsp+0x50], xmm5
00007026095d5a04  vmovaps [rsp+0x60], xmm6
00007026095d5a0a  vmovaps [rsp+0x70], xmm7
00007026095d5a10  vmovaps [rsp+0x80], xmm8
00007026095d5a19  vmovaps [rsp+0x90], xmm9
00007026095d5a22  vmovaps [rsp+0xA0], xmm10
00007026095d5a2b  vmovaps [rsp+0xB0], xmm11
00007026095d5a34  vmovaps [rsp+0xC0], xmm12
00007026095d5a3d  vmovaps [rsp+0xD0], xmm14
00007026095d5a46  vmovaps [rsp+0xE0], xmm15
00007026095d5a4f  sub rsp, 0x40
00007026095d5a53  lea rdi, [rsp]
00007026095d5a57  lea rsi, [rsp+0x10]
00007026095d5a5c  lea rdx, [rsp+0x20]
00007026095d5a61  lea rcx, [rsp+0x30]
00007026095d5a66  mov r8d, 0x00
00007026095d5a6c  lea r9, [r15+0x3A8]
00007026095d5a73  movaps [rdi], xmm13
00007026095d5a77  movaps [rsi], xmm10
00007026095d5a7b  movaps [rdx], xmm7
00007026095d5a7e  movaps [rcx], xmm1
00007026095d5a81  mov rax, 0x58A432239A50
00007026095d5a8b  call rax
00007026095d5a8d  movaps xmm13, [rsp]
00007026095d5a92  add rsp, 0x40
00007026095d5a96  vmovaps xmm0, [rsp]
00007026095d5a9b  vmovaps xmm1, [rsp+0x10]
00007026095d5aa1  vmovaps xmm2, [rsp+0x20]
00007026095d5aa7  vmovaps xmm3, [rsp+0x30]
00007026095d5aad  vmovaps xmm4, [rsp+0x40]
00007026095d5ab3  vmovaps xmm5, [rsp+0x50]
00007026095d5ab9  vmovaps xmm6, [rsp+0x60]
00007026095d5abf  vmovaps xmm7, [rsp+0x70]
00007026095d5ac5  vmovaps xmm8, [rsp+0x80]
00007026095d5ace  vmovaps xmm9, [rsp+0x90]
00007026095d5ad7  vmovaps xmm10, [rsp+0xA0]
00007026095d5ae0  vmovaps xmm11, [rsp+0xB0]
00007026095d5ae9  vmovaps xmm12, [rsp+0xC0]
00007026095d5af2  vmovaps xmm14, [rsp+0xD0]
00007026095d5afb  vmovaps xmm15, [rsp+0xE0]
00007026095d5b04  add rsp, 0xF0
00007026095d5b0b  pop r11
00007026095d5b0d  pop r10
00007026095d5b0f  pop r9
00007026095d5b11  pop r8
00007026095d5b13  pop rsi
00007026095d5b14  pop rdi
00007026095d5b15  pop rdx
00007026095d5b16  pop rcx
00007026095d5b17  pop rax
00007026095d5b18  add rsp, 0x08
00007026095d5b1c  jmp 0x00007026095D3930
00007026095d5b21  sub rsp, 0x08
00007026095d5b25  push rax
00007026095d5b26  push rcx
00007026095d5b27  push rdx
00007026095d5b28  push rdi
00007026095d5b29  push rsi
00007026095d5b2a  push r8
00007026095d5b2c  push r9
00007026095d5b2e  push r10
00007026095d5b30  push r11
00007026095d5b32  sub rsp, 0xF0
00007026095d5b39  vmovaps [rsp], xmm0
00007026095d5b3e  vmovaps [rsp+0x10], xmm1
00007026095d5b44  vmovaps [rsp+0x20], xmm2
00007026095d5b4a  vmovaps [rsp+0x30], xmm3
00007026095d5b50  vmovaps [rsp+0x40], xmm4
00007026095d5b56  vmovaps [rsp+0x50], xmm5
00007026095d5b5c  vmovaps [rsp+0x60], xmm6
00007026095d5b62  vmovaps [rsp+0x70], xmm7
00007026095d5b68  vmovaps [rsp+0x80], xmm8
00007026095d5b71  vmovaps [rsp+0x90], xmm9
00007026095d5b7a  vmovaps [rsp+0xA0], xmm11
00007026095d5b83  vmovaps [rsp+0xB0], xmm12
00007026095d5b8c  vmovaps [rsp+0xC0], xmm13
00007026095d5b95  vmovaps [rsp+0xD0], xmm14
00007026095d5b9e  vmovaps [rsp+0xE0], xmm15
00007026095d5ba7  sub rsp, 0x40
00007026095d5bab  lea rdi, [rsp]
00007026095d5baf  lea rsi, [rsp+0x10]
00007026095d5bb4  lea rdx, [rsp+0x20]
00007026095d5bb9  lea rcx, [rsp+0x30]
00007026095d5bbe  mov r8d, 0x00
00007026095d5bc4  lea r9, [r15+0x3A8]
00007026095d5bcb  movaps [rdi], xmm10
00007026095d5bcf  movaps [rsi], xmm6
00007026095d5bd2  movaps [rdx], xmm15
00007026095d5bd6  movaps [rcx], xmm1
00007026095d5bd9  mov rax, 0x58A432239A50
00007026095d5be3  call rax
00007026095d5be5  movaps xmm10, [rsp]
00007026095d5bea  add rsp, 0x40
00007026095d5bee  vmovaps xmm0, [rsp]
00007026095d5bf3  vmovaps xmm1, [rsp+0x10]
00007026095d5bf9  vmovaps xmm2, [rsp+0x20]
00007026095d5bff  vmovaps xmm3, [rsp+0x30]
00007026095d5c05  vmovaps xmm4, [rsp+0x40]
00007026095d5c0b  vmovaps xmm5, [rsp+0x50]
00007026095d5c11  vmovaps xmm6, [rsp+0x60]
00007026095d5c17  vmovaps xmm7, [rsp+0x70]
00007026095d5c1d  vmovaps xmm8, [rsp+0x80]
00007026095d5c26  vmovaps xmm9, [rsp+0x90]
00007026095d5c2f  vmovaps xmm11, [rsp+0xA0]
00007026095d5c38  vmovaps xmm12, [rsp+0xB0]
00007026095d5c41  vmovaps xmm13, [rsp+0xC0]
00007026095d5c4a  vmovaps xmm14, [rsp+0xD0]
00007026095d5c53  vmovaps xmm15, [rsp+0xE0]
00007026095d5c5c  add rsp, 0xF0
00007026095d5c63  pop r11
00007026095d5c65  pop r10
00007026095d5c67  pop r9
00007026095d5c69  pop r8
00007026095d5c6b  pop rsi
00007026095d5c6c  pop rdi
00007026095d5c6d  pop rdx
00007026095d5c6e  pop rcx
00007026095d5c6f  pop rax
00007026095d5c70  add rsp, 0x08
00007026095d5c74  jmp 0x00007026095D3956
00007026095d5c79  call 0x00007026094D64F0
00007026095d5c7e  jmp 0x00007026095D3960
00007026095d5c83  call 0x00007026094E5820
00007026095d5c88  jmp 0x00007026095D396A
00007026095d5c8d  sub rsp, 0x08
00007026095d5c91  push rax
00007026095d5c92  push rcx
00007026095d5c93  push rdx
00007026095d5c94  push rdi
00007026095d5c95  push rsi
00007026095d5c96  push r8
00007026095d5c98  push r9
00007026095d5c9a  push r10
00007026095d5c9c  push r11
00007026095d5c9e  sub rsp, 0xF0
00007026095d5ca5  vmovaps [rsp], xmm0
00007026095d5caa  vmovaps [rsp+0x10], xmm1
00007026095d5cb0  vmovaps [rsp+0x20], xmm2
00007026095d5cb6  vmovaps [rsp+0x30], xmm3
00007026095d5cbc  vmovaps [rsp+0x40], xmm4
00007026095d5cc2  vmovaps [rsp+0x50], xmm5
00007026095d5cc8  vmovaps [rsp+0x60], xmm6
00007026095d5cce  vmovaps [rsp+0x70], xmm8
00007026095d5cd4  vmovaps [rsp+0x80], xmm9
00007026095d5cdd  vmovaps [rsp+0x90], xmm10
00007026095d5ce6  vmovaps [rsp+0xA0], xmm11
00007026095d5cef  vmovaps [rsp+0xB0], xmm12
00007026095d5cf8  vmovaps [rsp+0xC0], xmm13
00007026095d5d01  vmovaps [rsp+0xD0], xmm14
00007026095d5d0a  vmovaps [rsp+0xE0], xmm15
00007026095d5d13  sub rsp, 0x40
00007026095d5d17  lea rdi, [rsp]
00007026095d5d1b  lea rsi, [rsp+0x10]
00007026095d5d20  lea rdx, [rsp+0x20]
00007026095d5d25  lea rcx, [rsp+0x30]
00007026095d5d2a  mov r8d, 0x00
00007026095d5d30  lea r9, [r15+0x3A8]
00007026095d5d37  movaps [rdi], xmm7
00007026095d5d3a  movaps [rsi], xmm8
00007026095d5d3e  movaps [rdx], xmm3
00007026095d5d41  movaps [rcx], xmm9
00007026095d5d45  mov rax, 0x58A432239A50
00007026095d5d4f  call rax
00007026095d5d51  movaps xmm7, [rsp]
00007026095d5d55  add rsp, 0x40
00007026095d5d59  vmovaps xmm0, [rsp]
00007026095d5d5e  vmovaps xmm1, [rsp+0x10]
00007026095d5d64  vmovaps xmm2, [rsp+0x20]
00007026095d5d6a  vmovaps xmm3, [rsp+0x30]
00007026095d5d70  vmovaps xmm4, [rsp+0x40]
00007026095d5d76  vmovaps xmm5, [rsp+0x50]
00007026095d5d7c  vmovaps xmm6, [rsp+0x60]
00007026095d5d82  vmovaps xmm8, [rsp+0x70]
00007026095d5d88  vmovaps xmm9, [rsp+0x80]
00007026095d5d91  vmovaps xmm10, [rsp+0x90]
00007026095d5d9a  vmovaps xmm11, [rsp+0xA0]
00007026095d5da3  vmovaps xmm12, [rsp+0xB0]
00007026095d5dac  vmovaps xmm13, [rsp+0xC0]
00007026095d5db5  vmovaps xmm14, [rsp+0xD0]
00007026095d5dbe  vmovaps xmm15, [rsp+0xE0]
00007026095d5dc7  add rsp, 0xF0
00007026095d5dce  pop r11
00007026095d5dd0  pop r10
00007026095d5dd2  pop r9
00007026095d5dd4  pop r8
00007026095d5dd6  pop rsi
00007026095d5dd7  pop rdi
00007026095d5dd8  pop rdx
00007026095d5dd9  pop rcx
00007026095d5dda  pop rax
00007026095d5ddb  add rsp, 0x08
00007026095d5ddf  jmp 0x00007026095D3992
00007026095d5de4  sub rsp, 0x08
00007026095d5de8  push rax
00007026095d5de9  push rcx
00007026095d5dea  push rdx
00007026095d5deb  push rdi
00007026095d5dec  push rsi
00007026095d5ded  push r8
00007026095d5def  push r9
00007026095d5df1  push r10
00007026095d5df3  push r11
00007026095d5df5  sub rsp, 0xF0
00007026095d5dfc  vmovaps [rsp], xmm0
00007026095d5e01  vmovaps [rsp+0x10], xmm1
00007026095d5e07  vmovaps [rsp+0x20], xmm2
00007026095d5e0d  vmovaps [rsp+0x30], xmm3
00007026095d5e13  vmovaps [rsp+0x40], xmm4
00007026095d5e19  vmovaps [rsp+0x50], xmm5
00007026095d5e1f  vmovaps [rsp+0x60], xmm6
00007026095d5e25  vmovaps [rsp+0x70], xmm7
00007026095d5e2b  vmovaps [rsp+0x80], xmm9
00007026095d5e34  vmovaps [rsp+0x90], xmm10
00007026095d5e3d  vmovaps [rsp+0xA0], xmm11
00007026095d5e46  vmovaps [rsp+0xB0], xmm12
00007026095d5e4f  vmovaps [rsp+0xC0], xmm13
00007026095d5e58  vmovaps [rsp+0xD0], xmm14
00007026095d5e61  vmovaps [rsp+0xE0], xmm15
00007026095d5e6a  sub rsp, 0x40
00007026095d5e6e  lea rdi, [rsp]
00007026095d5e72  lea rsi, [rsp+0x10]
00007026095d5e77  lea rdx, [rsp+0x20]
00007026095d5e7c  lea rcx, [rsp+0x30]
00007026095d5e81  mov r8d, 0x00
00007026095d5e87  lea r9, [r15+0x3A8]
00007026095d5e8e  movaps [rdi], xmm8
00007026095d5e92  movaps [rsi], xmm11
00007026095d5e96  movaps [rdx], xmm14
00007026095d5e9a  movaps [rcx], xmm9
00007026095d5e9e  mov rax, 0x58A432239A50
00007026095d5ea8  call rax
00007026095d5eaa  movaps xmm8, [rsp]
00007026095d5eaf  add rsp, 0x40
00007026095d5eb3  vmovaps xmm0, [rsp]
00007026095d5eb8  vmovaps xmm1, [rsp+0x10]
00007026095d5ebe  vmovaps xmm2, [rsp+0x20]
00007026095d5ec4  vmovaps xmm3, [rsp+0x30]
00007026095d5eca  vmovaps xmm4, [rsp+0x40]
00007026095d5ed0  vmovaps xmm5, [rsp+0x50]
00007026095d5ed6  vmovaps xmm6, [rsp+0x60]
00007026095d5edc  vmovaps xmm7, [rsp+0x70]
00007026095d5ee2  vmovaps xmm9, [rsp+0x80]
00007026095d5eeb  vmovaps xmm10, [rsp+0x90]
00007026095d5ef4  vmovaps xmm11, [rsp+0xA0]
00007026095d5efd  vmovaps xmm12, [rsp+0xB0]
00007026095d5f06  vmovaps xmm13, [rsp+0xC0]
00007026095d5f0f  vmovaps xmm14, [rsp+0xD0]
00007026095d5f18  vmovaps xmm15, [rsp+0xE0]
00007026095d5f21  add rsp, 0xF0
00007026095d5f28  pop r11
00007026095d5f2a  pop r10
00007026095d5f2c  pop r9
00007026095d5f2e  pop r8
00007026095d5f30  pop rsi
00007026095d5f31  pop rdi
00007026095d5f32  pop rdx
00007026095d5f33  pop rcx
00007026095d5f34  pop rax
00007026095d5f35  add rsp, 0x08
00007026095d5f39  jmp 0x00007026095D39BB
00007026095d5f3e  sub rsp, 0x08
00007026095d5f42  push rax
00007026095d5f43  push rcx
00007026095d5f44  push rdx
00007026095d5f45  push rdi
00007026095d5f46  push rsi
00007026095d5f47  push r8
00007026095d5f49  push r9
00007026095d5f4b  push r10
00007026095d5f4d  push r11
00007026095d5f4f  sub rsp, 0xF0
00007026095d5f56  vmovaps [rsp], xmm0
00007026095d5f5b  vmovaps [rsp+0x10], xmm1
00007026095d5f61  vmovaps [rsp+0x20], xmm2
00007026095d5f67  vmovaps [rsp+0x30], xmm3
00007026095d5f6d  vmovaps [rsp+0x40], xmm4
00007026095d5f73  vmovaps [rsp+0x50], xmm5
00007026095d5f79  vmovaps [rsp+0x60], xmm6
00007026095d5f7f  vmovaps [rsp+0x70], xmm7
00007026095d5f85  vmovaps [rsp+0x80], xmm8
00007026095d5f8e  vmovaps [rsp+0x90], xmm9
00007026095d5f97  vmovaps [rsp+0xA0], xmm10
00007026095d5fa0  vmovaps [rsp+0xB0], xmm12
00007026095d5fa9  vmovaps [rsp+0xC0], xmm13
00007026095d5fb2  vmovaps [rsp+0xD0], xmm14
00007026095d5fbb  vmovaps [rsp+0xE0], xmm15
00007026095d5fc4  sub rsp, 0x40
00007026095d5fc8  lea rdi, [rsp]
00007026095d5fcc  lea rsi, [rsp+0x10]
00007026095d5fd1  lea rdx, [rsp+0x20]
00007026095d5fd6  lea rcx, [rsp+0x30]
00007026095d5fdb  mov r8d, 0x00
00007026095d5fe1  lea r9, [r15+0x3A8]
00007026095d5fe8  movaps [rdi], xmm11
00007026095d5fec  movaps [rsi], xmm13
00007026095d5ff0  movaps [rdx], xmm12
00007026095d5ff4  movaps [rcx], xmm14
00007026095d5ff8  mov rax, 0x58A432239A50
00007026095d6002  call rax
00007026095d6004  movaps xmm11, [rsp]
00007026095d6009  add rsp, 0x40
00007026095d600d  vmovaps xmm0, [rsp]
00007026095d6012  vmovaps xmm1, [rsp+0x10]
00007026095d6018  vmovaps xmm2, [rsp+0x20]
00007026095d601e  vmovaps xmm3, [rsp+0x30]
00007026095d6024  vmovaps xmm4, [rsp+0x40]
00007026095d602a  vmovaps xmm5, [rsp+0x50]
00007026095d6030  vmovaps xmm6, [rsp+0x60]
00007026095d6036  vmovaps xmm7, [rsp+0x70]
00007026095d603c  vmovaps xmm8, [rsp+0x80]
00007026095d6045  vmovaps xmm9, [rsp+0x90]
00007026095d604e  vmovaps xmm10, [rsp+0xA0]
00007026095d6057  vmovaps xmm12, [rsp+0xB0]
00007026095d6060  vmovaps xmm13, [rsp+0xC0]
00007026095d6069  vmovaps xmm14, [rsp+0xD0]
00007026095d6072  vmovaps xmm15, [rsp+0xE0]
00007026095d607b  add rsp, 0xF0
00007026095d6082  pop r11
00007026095d6084  pop r10
00007026095d6086  pop r9
00007026095d6088  pop r8
00007026095d608a  pop rsi
00007026095d608b  pop rdi
00007026095d608c  pop rdx
00007026095d608d  pop rcx
00007026095d608e  pop rax
00007026095d608f  add rsp, 0x08
00007026095d6093  jmp 0x00007026095D39E4
00007026095d6098  sub rsp, 0x08
00007026095d609c  push rax
00007026095d609d  push rcx
00007026095d609e  push rdx
00007026095d609f  push rdi
00007026095d60a0  push rsi
00007026095d60a1  push r8
00007026095d60a3  push r9
00007026095d60a5  push r10
00007026095d60a7  push r11
00007026095d60a9  sub rsp, 0xF0
00007026095d60b0  vmovaps [rsp], xmm0
00007026095d60b5  vmovaps [rsp+0x10], xmm1
00007026095d60bb  vmovaps [rsp+0x20], xmm2
00007026095d60c1  vmovaps [rsp+0x30], xmm3
00007026095d60c7  vmovaps [rsp+0x40], xmm4
00007026095d60cd  vmovaps [rsp+0x50], xmm5
00007026095d60d3  vmovaps [rsp+0x60], xmm6
00007026095d60d9  vmovaps [rsp+0x70], xmm7
00007026095d60df  vmovaps [rsp+0x80], xmm8
00007026095d60e8  vmovaps [rsp+0x90], xmm9
00007026095d60f1  vmovaps [rsp+0xA0], xmm10
00007026095d60fa  vmovaps [rsp+0xB0], xmm11
00007026095d6103  vmovaps [rsp+0xC0], xmm13
00007026095d610c  vmovaps [rsp+0xD0], xmm14
00007026095d6115  vmovaps [rsp+0xE0], xmm15
00007026095d611e  sub rsp, 0x40
00007026095d6122  lea rdi, [rsp]
00007026095d6126  lea rsi, [rsp+0x10]
00007026095d612b  lea rdx, [rsp+0x20]
00007026095d6130  lea rcx, [rsp+0x30]
00007026095d6135  mov r8d, 0x00
00007026095d613b  lea r9, [r15+0x3A8]
00007026095d6142  movaps [rdi], xmm12
00007026095d6146  movaps [rsi], xmm10
00007026095d614a  movaps [rdx], xmm15
00007026095d614e  movaps [rcx], xmm14
00007026095d6152  mov rax, 0x58A432239A50
00007026095d615c  call rax
00007026095d615e  movaps xmm12, [rsp]
00007026095d6163  add rsp, 0x40
00007026095d6167  vmovaps xmm0, [rsp]
00007026095d616c  vmovaps xmm1, [rsp+0x10]
00007026095d6172  vmovaps xmm2, [rsp+0x20]
00007026095d6178  vmovaps xmm3, [rsp+0x30]
00007026095d617e  vmovaps xmm4, [rsp+0x40]
00007026095d6184  vmovaps xmm5, [rsp+0x50]
00007026095d618a  vmovaps xmm6, [rsp+0x60]
00007026095d6190  vmovaps xmm7, [rsp+0x70]
00007026095d6196  vmovaps xmm8, [rsp+0x80]
00007026095d619f  vmovaps xmm9, [rsp+0x90]
00007026095d61a8  vmovaps xmm10, [rsp+0xA0]
00007026095d61b1  vmovaps xmm11, [rsp+0xB0]
00007026095d61ba  vmovaps xmm13, [rsp+0xC0]
00007026095d61c3  vmovaps xmm14, [rsp+0xD0]
00007026095d61cc  vmovaps xmm15, [rsp+0xE0]
00007026095d61d5  add rsp, 0xF0
00007026095d61dc  pop r11
00007026095d61de  pop r10
00007026095d61e0  pop r9
00007026095d61e2  pop r8
00007026095d61e4  pop rsi
00007026095d61e5  pop rdi
00007026095d61e6  pop rdx
00007026095d61e7  pop rcx
00007026095d61e8  pop rax
00007026095d61e9  add rsp, 0x08
00007026095d61ed  jmp 0x00007026095D3A0D
00007026095d61f2  call 0x00007026094E5820
00007026095d61f7  jmp 0x00007026095D3A1A
00007026095d61fc  call 0x00007026094E45A0
00007026095d6201  jmp 0x00007026095D3A27
00007026095d6206  sub rsp, 0x08
00007026095d620a  push rax
00007026095d620b  push rcx
00007026095d620c  push rdx
00007026095d620d  push rdi
00007026095d620e  push rsi
00007026095d620f  push r8
00007026095d6211  push r9
00007026095d6213  push r10
00007026095d6215  push r11
00007026095d6217  sub rsp, 0xF0
00007026095d621e  vmovaps [rsp], xmm0
00007026095d6223  vmovaps [rsp+0x10], xmm1
00007026095d6229  vmovaps [rsp+0x20], xmm2
00007026095d622f  vmovaps [rsp+0x30], xmm3
00007026095d6235  vmovaps [rsp+0x40], xmm4
00007026095d623b  vmovaps [rsp+0x50], xmm5
00007026095d6241  vmovaps [rsp+0x60], xmm6
00007026095d6247  vmovaps [rsp+0x70], xmm7
00007026095d624d  vmovaps [rsp+0x80], xmm8
00007026095d6256  vmovaps [rsp+0x90], xmm9
00007026095d625f  vmovaps [rsp+0xA0], xmm11
00007026095d6268  vmovaps [rsp+0xB0], xmm12
00007026095d6271  vmovaps [rsp+0xC0], xmm13
00007026095d627a  vmovaps [rsp+0xD0], xmm14
00007026095d6283  vmovaps [rsp+0xE0], xmm15
00007026095d628c  sub rsp, 0x40
00007026095d6290  lea rdi, [rsp]
00007026095d6294  lea rsi, [rsp+0x10]
00007026095d6299  lea rdx, [rsp+0x20]
00007026095d629e  lea rcx, [rsp+0x30]
00007026095d62a3  mov r8d, 0x00
00007026095d62a9  lea r9, [r15+0x3A8]
00007026095d62b0  movaps [rdi], xmm10
00007026095d62b4  movaps [rsi], xmm7
00007026095d62b7  movaps [rdx], xmm1
00007026095d62ba  movaps [rcx], xmm13
00007026095d62be  mov rax, 0x58A432239A50
00007026095d62c8  call rax
00007026095d62ca  movaps xmm10, [rsp]
00007026095d62cf  add rsp, 0x40
00007026095d62d3  vmovaps xmm0, [rsp]
00007026095d62d8  vmovaps xmm1, [rsp+0x10]
00007026095d62de  vmovaps xmm2, [rsp+0x20]
00007026095d62e4  vmovaps xmm3, [rsp+0x30]
00007026095d62ea  vmovaps xmm4, [rsp+0x40]
00007026095d62f0  vmovaps xmm5, [rsp+0x50]
00007026095d62f6  vmovaps xmm6, [rsp+0x60]
00007026095d62fc  vmovaps xmm7, [rsp+0x70]
00007026095d6302  vmovaps xmm8, [rsp+0x80]
00007026095d630b  vmovaps xmm9, [rsp+0x90]
00007026095d6314  vmovaps xmm11, [rsp+0xA0]
00007026095d631d  vmovaps xmm12, [rsp+0xB0]
00007026095d6326  vmovaps xmm13, [rsp+0xC0]
00007026095d632f  vmovaps xmm14, [rsp+0xD0]
00007026095d6338  vmovaps xmm15, [rsp+0xE0]
00007026095d6341  add rsp, 0xF0
00007026095d6348  pop r11
00007026095d634a  pop r10
00007026095d634c  pop r9
00007026095d634e  pop r8
00007026095d6350  pop rsi
00007026095d6351  pop rdi
00007026095d6352  pop rdx
00007026095d6353  pop rcx
00007026095d6354  pop rax
00007026095d6355  add rsp, 0x08
00007026095d6359  jmp 0x00007026095D3A5D
00007026095d635e  call 0x00007026094D64F0
00007026095d6363  jmp 0x00007026095D3A6F
00007026095d6368  sub rsp, 0x08
00007026095d636c  push rax
00007026095d636d  push rcx
00007026095d636e  push rdx
00007026095d636f  push rdi
00007026095d6370  push rsi
00007026095d6371  push r8
00007026095d6373  push r9
00007026095d6375  push r10
00007026095d6377  push r11
00007026095d6379  sub rsp, 0xF0
00007026095d6380  vmovaps [rsp], xmm0
00007026095d6385  vmovaps [rsp+0x10], xmm1
00007026095d638b  vmovaps [rsp+0x20], xmm2
00007026095d6391  vmovaps [rsp+0x30], xmm3
00007026095d6397  vmovaps [rsp+0x40], xmm4
00007026095d639d  vmovaps [rsp+0x50], xmm5
00007026095d63a3  vmovaps [rsp+0x60], xmm6
00007026095d63a9  vmovaps [rsp+0x70], xmm7
00007026095d63af  vmovaps [rsp+0x80], xmm8
00007026095d63b8  vmovaps [rsp+0x90], xmm10
00007026095d63c1  vmovaps [rsp+0xA0], xmm11
00007026095d63ca  vmovaps [rsp+0xB0], xmm12
00007026095d63d3  vmovaps [rsp+0xC0], xmm13
00007026095d63dc  vmovaps [rsp+0xD0], xmm14
00007026095d63e5  vmovaps [rsp+0xE0], xmm15
00007026095d63ee  sub rsp, 0x40
00007026095d63f2  lea rdi, [rsp]
00007026095d63f6  lea rsi, [rsp+0x10]
00007026095d63fb  lea rdx, [rsp+0x20]
00007026095d6400  lea rcx, [rsp+0x30]
00007026095d6405  mov r8d, 0x00
00007026095d640b  lea r9, [r15+0x3A8]
00007026095d6412  movaps [rdi], xmm9
00007026095d6416  movaps [rsi], xmm8
00007026095d641a  movaps [rdx], xmm14
00007026095d641e  movaps [rcx], xmm13
00007026095d6422  mov rax, 0x58A432239A50
00007026095d642c  call rax
00007026095d642e  movaps xmm9, [rsp]
00007026095d6433  add rsp, 0x40
00007026095d6437  vmovaps xmm0, [rsp]
00007026095d643c  vmovaps xmm1, [rsp+0x10]
00007026095d6442  vmovaps xmm2, [rsp+0x20]
00007026095d6448  vmovaps xmm3, [rsp+0x30]
00007026095d644e  vmovaps xmm4, [rsp+0x40]
00007026095d6454  vmovaps xmm5, [rsp+0x50]
00007026095d645a  vmovaps xmm6, [rsp+0x60]
00007026095d6460  vmovaps xmm7, [rsp+0x70]
00007026095d6466  vmovaps xmm8, [rsp+0x80]
00007026095d646f  vmovaps xmm10, [rsp+0x90]
00007026095d6478  vmovaps xmm11, [rsp+0xA0]
00007026095d6481  vmovaps xmm12, [rsp+0xB0]
00007026095d648a  vmovaps xmm13, [rsp+0xC0]
00007026095d6493  vmovaps xmm14, [rsp+0xD0]
00007026095d649c  vmovaps xmm15, [rsp+0xE0]
00007026095d64a5  add rsp, 0xF0
00007026095d64ac  pop r11
00007026095d64ae  pop r10
00007026095d64b0  pop r9
00007026095d64b2  pop r8
00007026095d64b4  pop rsi
00007026095d64b5  pop rdi
00007026095d64b6  pop rdx
00007026095d64b7  pop rcx
00007026095d64b8  pop rax
00007026095d64b9  add rsp, 0x08
00007026095d64bd  jmp 0x00007026095D3A9D
00007026095d64c2  sub rsp, 0x08
00007026095d64c6  push rax
00007026095d64c7  push rcx
00007026095d64c8  push rdx
00007026095d64c9  push rdi
00007026095d64ca  push rsi
00007026095d64cb  push r8
00007026095d64cd  push r9
00007026095d64cf  push r10
00007026095d64d1  push r11
00007026095d64d3  sub rsp, 0xF0
00007026095d64da  vmovaps [rsp], xmm0
00007026095d64df  vmovaps [rsp+0x10], xmm1
00007026095d64e5  vmovaps [rsp+0x20], xmm2
00007026095d64eb  vmovaps [rsp+0x30], xmm3
00007026095d64f1  vmovaps [rsp+0x40], xmm4
00007026095d64f7  vmovaps [rsp+0x50], xmm5
00007026095d64fd  vmovaps [rsp+0x60], xmm6
00007026095d6503  vmovaps [rsp+0x70], xmm7
00007026095d6509  vmovaps [rsp+0x80], xmm8
00007026095d6512  vmovaps [rsp+0x90], xmm9
00007026095d651b  vmovaps [rsp+0xA0], xmm10
00007026095d6524  vmovaps [rsp+0xB0], xmm11
00007026095d652d  vmovaps [rsp+0xC0], xmm12
00007026095d6536  vmovaps [rsp+0xD0], xmm14
00007026095d653f  vmovaps [rsp+0xE0], xmm15
00007026095d6548  sub rsp, 0x40
00007026095d654c  lea rdi, [rsp]
00007026095d6550  lea rsi, [rsp+0x10]
00007026095d6555  lea rdx, [rsp+0x20]
00007026095d655a  lea rcx, [rsp+0x30]
00007026095d655f  mov r8d, 0x00
00007026095d6565  lea r9, [r15+0x3A8]
00007026095d656c  movaps [rdi], xmm13
00007026095d6570  movaps [rsi], xmm11
00007026095d6574  movaps [rdx], xmm15
00007026095d6578  movaps [rcx], xmm14
00007026095d657c  mov rax, 0x58A432239A50
00007026095d6586  call rax
00007026095d6588  movaps xmm13, [rsp]
00007026095d658d  add rsp, 0x40
00007026095d6591  vmovaps xmm0, [rsp]
00007026095d6596  vmovaps xmm1, [rsp+0x10]
00007026095d659c  vmovaps xmm2, [rsp+0x20]
00007026095d65a2  vmovaps xmm3, [rsp+0x30]
00007026095d65a8  vmovaps xmm4, [rsp+0x40]
00007026095d65ae  vmovaps xmm5, [rsp+0x50]
00007026095d65b4  vmovaps xmm6, [rsp+0x60]
00007026095d65ba  vmovaps xmm7, [rsp+0x70]
00007026095d65c0  vmovaps xmm8, [rsp+0x80]
00007026095d65c9  vmovaps xmm9, [rsp+0x90]
00007026095d65d2  vmovaps xmm10, [rsp+0xA0]
00007026095d65db  vmovaps xmm11, [rsp+0xB0]
00007026095d65e4  vmovaps xmm12, [rsp+0xC0]
00007026095d65ed  vmovaps xmm14, [rsp+0xD0]
00007026095d65f6  vmovaps xmm15, [rsp+0xE0]
00007026095d65ff  add rsp, 0xF0
00007026095d6606  pop r11
00007026095d6608  pop r10
00007026095d660a  pop r9
00007026095d660c  pop r8
00007026095d660e  pop rsi
00007026095d660f  pop rdi
00007026095d6610  pop rdx
00007026095d6611  pop rcx
00007026095d6612  pop rax
00007026095d6613  add rsp, 0x08
00007026095d6617  jmp 0x00007026095D3ACB
00007026095d661c  sub rsp, 0x08
00007026095d6620  push rax
00007026095d6621  push rcx
00007026095d6622  push rdx
00007026095d6623  push rdi
00007026095d6624  push rsi
00007026095d6625  push r8
00007026095d6627  push r9
00007026095d6629  push r10
00007026095d662b  push r11
00007026095d662d  sub rsp, 0xF0
00007026095d6634  vmovaps [rsp], xmm0
00007026095d6639  vmovaps [rsp+0x10], xmm1
00007026095d663f  vmovaps [rsp+0x20], xmm2
00007026095d6645  vmovaps [rsp+0x30], xmm3
00007026095d664b  vmovaps [rsp+0x40], xmm4
00007026095d6651  vmovaps [rsp+0x50], xmm5
00007026095d6657  vmovaps [rsp+0x60], xmm6
00007026095d665d  vmovaps [rsp+0x70], xmm7
00007026095d6663  vmovaps [rsp+0x80], xmm8
00007026095d666c  vmovaps [rsp+0x90], xmm9
00007026095d6675  vmovaps [rsp+0xA0], xmm10
00007026095d667e  vmovaps [rsp+0xB0], xmm11
00007026095d6687  vmovaps [rsp+0xC0], xmm12
00007026095d6690  vmovaps [rsp+0xD0], xmm13
00007026095d6699  vmovaps [rsp+0xE0], xmm15
00007026095d66a2  sub rsp, 0x40
00007026095d66a6  lea rdi, [rsp]
00007026095d66aa  lea rsi, [rsp+0x10]
00007026095d66af  lea rdx, [rsp+0x20]
00007026095d66b4  lea rcx, [rsp+0x30]
00007026095d66b9  mov r8d, 0x00
00007026095d66bf  lea r9, [r15+0x3A8]
00007026095d66c6  movaps [rdi], xmm14
00007026095d66ca  movaps [rsi], xmm12
00007026095d66ce  movaps [rdx], xmm1
00007026095d66d1  movaps [rcx], xmm15
00007026095d66d5  mov rax, 0x58A432239A50
00007026095d66df  call rax
00007026095d66e1  movaps xmm14, [rsp]
00007026095d66e6  add rsp, 0x40
00007026095d66ea  vmovaps xmm0, [rsp]
00007026095d66ef  vmovaps xmm1, [rsp+0x10]
00007026095d66f5  vmovaps xmm2, [rsp+0x20]
00007026095d66fb  vmovaps xmm3, [rsp+0x30]
00007026095d6701  vmovaps xmm4, [rsp+0x40]
00007026095d6707  vmovaps xmm5, [rsp+0x50]
00007026095d670d  vmovaps xmm6, [rsp+0x60]
00007026095d6713  vmovaps xmm7, [rsp+0x70]
00007026095d6719  vmovaps xmm8, [rsp+0x80]
00007026095d6722  vmovaps xmm9, [rsp+0x90]
00007026095d672b  vmovaps xmm10, [rsp+0xA0]
00007026095d6734  vmovaps xmm11, [rsp+0xB0]
00007026095d673d  vmovaps xmm12, [rsp+0xC0]
00007026095d6746  vmovaps xmm13, [rsp+0xD0]
00007026095d674f  vmovaps xmm15, [rsp+0xE0]
00007026095d6758  add rsp, 0xF0
00007026095d675f  pop r11
00007026095d6761  pop r10
00007026095d6763  pop r9
00007026095d6765  pop r8
00007026095d6767  pop rsi
00007026095d6768  pop rdi
00007026095d6769  pop rdx
00007026095d676a  pop rcx
00007026095d676b  pop rax
00007026095d676c  add rsp, 0x08
00007026095d6770  jmp 0x00007026095D3AF9
00007026095d6775  call 0x00007026094ACF70
00007026095d677a  jmp 0x00007026095D3B07
00007026095d677f  call 0x000070260940C380
00007026095d6784  jmp 0x00007026095D3B11
00007026095d6789  call 0x0000702609408C20
00007026095d678e  jmp 0x00007026095D3B1B
00007026095d6793  call 0x000070260940D600
00007026095d6798  jmp 0x00007026095D3B25
00007026095d679d  int3
00007026095d679e  nop
00007026095d67a0  mov eax, [r15+0x48]
00007026095d67a4  lea r14d, [eax+0x01]
00007026095d67a9  mov [rsp+0x10], r14d
00007026095d67ae  mov r14d, r14d
00007026095d67b1  mov [r15+0x48], r14
00007026095d67b5  xor eax, eax
00007026095d67b7  mov r14d, [rsp+0x10]
00007026095d67bc  cmp r14d, 0x1F4
00007026095d67c3  cmc
00007026095d67c4  lahf
00007026095d67c5  seto al
00007026095d67c8  mov [r15+0x108], eax
00007026095d67cf  mov eax, [r15+0x108]
00007026095d67d6  sahf
00007026095d67d7  jnz 0x00007026095D6809
00007026095d67d9  cmp dword ptr [r15+0x318], 0x00
00007026095d67e1  jz 0x00007026095DA1A0
00007026095d67e7  nop [rax+rax*1], ax
00007026095d67f0  nop [rax+rax*1], eax
00007026095d67f8  mov eax, 0x4103FC
00007026095d67fd  mov [r15+0x100], rax
00007026095d6804  jmp 0x00007026093FE110
00007026095d6809  cmp dword ptr [r15+0x318], 0x00
00007026095d6811  jz 0x00007026095D6840
00007026095d6817  nop [rax+rax*1], ax
00007026095d6820  nop [rax+rax*1], eax
00007026095d6828  mov eax, 0x410270
00007026095d682d  mov [r15+0x100], rax
00007026095d6834  jmp 0x00007026093FE110
00007026095d6839  int3
00007026095d683a  int3
00007026095d683b  nop [rax+rax*1], eax
00007026095d6840  mov rax, [r15+0x40]
00007026095d6844  vxorps xmm1, xmm1, xmm1
00007026095d6848  vpbroadcastq xmm1, xmm1
00007026095d684d  vxorps xmm15, xmm15, xmm15
00007026095d6852  vpbroadcastq xmm15, xmm15
00007026095d6857  lea r14, [rax+0x30]
00007026095d685b  mov r12, [r13+r14*1]
00007026095d6860  lea r14, [rax+0x38]
00007026095d6864  mov r11, [r13+r14*1]
00007026095d6869  movq xmm14, r12
00007026095d686e  movq xmm13, r11
00007026095d6873  movq xmm14, xmm14
00007026095d6878  movq xmm13, xmm13
00007026095d687d  vmovaps [rsp+0x10], xmm13
00007026095d6883  movq xmm13, xmm13
00007026095d6888  movaps [r15+0x270], xmm13
00007026095d6890  movaps xmm13, [r15+0x160]
00007026095d6898  vmovaps [rsp+0x20], xmm13
00007026095d689e  vmovaps xmm12, [rsp+0x20]
00007026095d68a4  por xmm13, xmm12
00007026095d68a9  lea r14, [rax+0x20]
00007026095d68ad  mov r12, [r13+r14*1]
00007026095d68b2  lea r14, [rax+0x28]
00007026095d68b6  mov r11, [r13+r14*1]
00007026095d68bb  movq xmm12, r12
00007026095d68c0  movq xmm11, r11
00007026095d68c5  movq xmm12, xmm12
00007026095d68ca  movq xmm11, xmm11
00007026095d68cf  movaps xmm10, [r15+0x2F0]
00007026095d68d7  vmovaps [rsp+0x20], xmm10
00007026095d68dd  vmovaps xmm9, [rsp+0x20]
00007026095d68e3  por xmm10, xmm9
00007026095d68e8  movaps xmm9, [r15+0x2D0]
00007026095d68f0  vmovaps [rsp+0x20], xmm9
00007026095d68f6  vmovaps xmm8, [rsp+0x20]
00007026095d68fc  por xmm9, xmm8
00007026095d6901  movaps xmm8, [r15+0x300]
00007026095d6909  vmovaps [rsp+0x20], xmm8
00007026095d690f  vmovaps xmm7, [rsp+0x20]
00007026095d6915  por xmm8, xmm7
00007026095d691a  movaps xmm7, [r15+0x2B0]
00007026095d6922  vmovaps [rsp+0x20], xmm7
00007026095d6928  vmovaps xmm6, [rsp+0x20]
00007026095d692e  por xmm7, xmm6
00007026095d6932  movaps xmm6, [r15+0x180]
00007026095d693a  vmovaps [rsp+0x20], xmm6
00007026095d6940  vmovaps xmm5, [rsp+0x20]
00007026095d6946  por xmm6, xmm5
00007026095d694a  lea r14, [rax+0x10]
00007026095d694e  mov r12, [r13+r14*1]
00007026095d6953  lea r14, [rax+0x18]
00007026095d6957  mov r11, [r13+r14*1]
00007026095d695c  movq xmm5, r12
00007026095d6961  movq xmm4, r11
00007026095d6966  movq xmm5, xmm5
00007026095d696a  movq xmm4, xmm4
00007026095d696e  movaps xmm3, [r15+0x200]
00007026095d6976  vmovaps [rsp+0x20], xmm3
00007026095d697c  vmovaps xmm2, [rsp+0x20]
00007026095d6982  por xmm3, xmm2
00007026095d6986  movaps xmm2, [r15+0x1F0]
00007026095d698e  vmovaps [rsp+0x20], xmm2
00007026095d6994  vmovaps [rsp+0x30], xmm1
00007026095d699a  vmovaps xmm1, [rsp+0x20]
00007026095d69a0  por xmm2, xmm1
00007026095d69a4  movaps xmm1, [r15+0x2E0]
00007026095d69ac  vmovaps [rsp+0x20], xmm1
00007026095d69b2  vmovaps [rsp+0x40], xmm15
00007026095d69b8  vmovaps xmm15, [rsp+0x20]
00007026095d69be  por xmm1, xmm15
00007026095d69c3  movaps xmm15, [r15+0x2A0]
00007026095d69cb  vmovaps [rsp+0x20], xmm15
00007026095d69d1  vmovaps [rsp+0x50], xmm1
00007026095d69d7  vmovaps xmm1, [rsp+0x20]
00007026095d69dd  por xmm15, xmm1
00007026095d69e2  movaps xmm1, [r15+0x280]
00007026095d69ea  vmovaps [rsp+0x20], xmm1
00007026095d69f0  vmovaps [rsp+0x60], xmm15
00007026095d69f6  vmovaps xmm15, [rsp+0x20]
00007026095d69fc  por xmm1, xmm15
00007026095d6a01  movaps xmm15, [r15+0x1C0]
00007026095d6a09  vmovaps [rsp+0x20], xmm15
00007026095d6a0f  vmovaps [rsp+0x70], xmm1
00007026095d6a15  vmovaps xmm1, [rsp+0x20]
00007026095d6a1b  por xmm15, xmm1
00007026095d6a20  movaps xmm1, [r15+0x210]
00007026095d6a28  vmovaps [rsp+0x20], xmm1
00007026095d6a2e  vmovaps [rsp+0x80], xmm15
00007026095d6a37  vmovaps xmm15, [rsp+0x20]
00007026095d6a3d  por xmm1, xmm15
00007026095d6a42  mov r14, [r13+rax*1]
00007026095d6a47  vmovq xmm15, r14
00007026095d6a4c  vpbroadcastq xmm15, xmm15
00007026095d6a51  vmovaps [rsp+0x20], xmm1
00007026095d6a57  vxorps xmm1, xmm1, xmm1
00007026095d6a5b  vpbroadcastq xmm1, xmm1
00007026095d6a60  mov r14, [r15+0xF8]
00007026095d6a67  vmovaps [rsp+0x90], xmm1
00007026095d6a70  movups xmm1, [r13+r14*1]
00007026095d6a76  vmovaps [rsp+0xA0], xmm1
00007026095d6a7f  vxorps xmm1, xmm1, xmm1
00007026095d6a83  vpbroadcastq xmm1, xmm1
00007026095d6a88  lea r12, [rax+0x08]
00007026095d6a8c  mov rax, [r13+r12*1]
00007026095d6a91  vmovaps [rsp+0xB0], xmm1
00007026095d6a9a  movq xmm1, rax
00007026095d6a9f  movaps [r15+0x240], xmm1
00007026095d6aa7  mov rax, [r15+0x50]
00007026095d6aab  mov [r15+0x60], rax
00007026095d6aaf  mov qword ptr [r15+0x58], 0x40
00007026095d6ab7  vmovaps xmm1, [rsp+0x30]
00007026095d6abd  vmovaps [rsp+0x30], xmm15
00007026095d6ac3  vmovaps xmm15, [rsp+0xA0]
00007026095d6acc  vmovaps [rsp+0xA0], xmm14
00007026095d6ad5  vmovaps xmm14, [rsp+0x30]
00007026095d6adb  vmovaps [rsp+0x30], xmm13
00007026095d6ae1  vmovaps [rsp+0xC0], xmm12
00007026095d6aea  movaps xmm13, xmm1
00007026095d6aee  vfmadd231pd xmm13, xmm15, xmm14
00007026095d6af3  vcmppd xmm12, xmm13, xmm13, 0x03
00007026095d6af9  vptest xmm12, xmm12
00007026095d6afe  jnz 0x00007026095D75DD
00007026095d6b04  movaps xmm1, [r15+0x250]
00007026095d6b0c  vmovaps xmm15, [rsp+0x40]
00007026095d6b12  vmovaps [rsp+0x40], xmm13
00007026095d6b18  movaps xmm12, xmm15
00007026095d6b1c  vfmadd231pd xmm12, xmm1, xmm14
00007026095d6b21  vcmppd xmm13, xmm12, xmm12, 0x03
00007026095d6b27  vptest xmm13, xmm13
00007026095d6b2c  jnz 0x00007026095D7736
00007026095d6b32  movaps xmm15, [r15+0x1E0]
00007026095d6b3a  vmovaps [rsp+0xD0], xmm15
00007026095d6b43  vmovaps xmm13, [rsp+0xD0]
00007026095d6b4c  por xmm15, xmm13
00007026095d6b51  movaps xmm13, [r15+0x1D0]
00007026095d6b59  vmovaps [rsp+0xD0], xmm13
00007026095d6b62  vmovaps [rsp+0xE0], xmm1
00007026095d6b6b  vmovaps xmm1, [rsp+0xD0]
00007026095d6b74  por xmm13, xmm1
00007026095d6b79  movaps xmm1, [r15+0x2C0]
00007026095d6b81  vmovaps [rsp+0xD0], xmm1
00007026095d6b8a  vmovaps [rsp+0xF0], xmm15
00007026095d6b93  vmovaps xmm15, [rsp+0xD0]
00007026095d6b9c  por xmm1, xmm15
00007026095d6ba1  movaps xmm15, [r15+0x290]
00007026095d6ba9  vmovaps [rsp+0xD0], xmm15
00007026095d6bb2  vmovaps [rsp+0x100], xmm1
00007026095d6bbb  vmovaps xmm1, [rsp+0xD0]
00007026095d6bc4  por xmm15, xmm1
00007026095d6bc9  movaps xmm1, [r15+0x260]
00007026095d6bd1  vmovaps [rsp+0xD0], xmm1
00007026095d6bda  vmovaps [rsp+0x110], xmm15
00007026095d6be3  vmovaps xmm15, [rsp+0xD0]
00007026095d6bec  por xmm1, xmm15
00007026095d6bf1  vmovaps xmm15, [rsp+0xE0]
00007026095d6bfa  vmovaps [rsp+0xD0], xmm1
00007026095d6c03  vmovaps xmm1, [rsp+0xE0]
00007026095d6c0c  por xmm15, xmm1
00007026095d6c11  lea r12, [r14+0xC0]
00007026095d6c18  movups xmm1, [r13+r12*1]
00007026095d6c1e  mov [rsp+0xE0], rax
00007026095d6c26  xor eax, eax
00007026095d6c28  mov r12d, 0x40
00007026095d6c2e  mov r11d, 0x200
00007026095d6c34  cmp r12, r11
00007026095d6c37  cmc
00007026095d6c38  lahf
00007026095d6c39  seto al
00007026095d6c3c  mov [r15+0x108], eax
00007026095d6c43  vmovaps [rsp+0x120], xmm1
00007026095d6c4c  vmovaps xmm1, [rsp+0x90]
00007026095d6c55  vmovaps [rsp+0x90], xmm15
00007026095d6c5e  vmovaps xmm15, [rsp+0x120]
00007026095d6c67  vmovaps [rsp+0x120], xmm13
00007026095d6c70  vmovaps [rsp+0x130], xmm12
00007026095d6c79  movaps xmm13, xmm1
00007026095d6c7d  vfmadd231pd xmm13, xmm15, xmm14
00007026095d6c82  vcmppd xmm12, xmm13, xmm13, 0x03
00007026095d6c88  vptest xmm12, xmm12
00007026095d6c8d  jnz 0x00007026095D7899
00007026095d6c93  lea rax, [r14+0xB0]
00007026095d6c9a  movups xmm1, [r13+rax*1]
00007026095d6ca0  vmovaps xmm15, [rsp+0xB0]
00007026095d6ca9  vmovaps [rsp+0xB0], xmm13
00007026095d6cb2  movaps xmm12, xmm15
00007026095d6cb6  vfmadd231pd xmm12, xmm1, xmm14
00007026095d6cbb  vcmppd xmm13, xmm12, xmm12, 0x03
00007026095d6cc1  vptest xmm13, xmm13
00007026095d6cc6  jnz 0x00007026095D79FC
00007026095d6ccc  vmovaps xmm1, [rsp+0x20]
00007026095d6cd2  vmovaps xmm15, [rsp+0x20]
00007026095d6cd8  por xmm1, xmm15
00007026095d6cdd  movaps [r15+0x210], xmm1
00007026095d6ce5  vmovaps xmm15, [rsp+0x80]
00007026095d6cee  vmovaps xmm14, [rsp+0x80]
00007026095d6cf7  por xmm15, xmm14
00007026095d6cfc  movaps [r15+0x1C0], xmm15
00007026095d6d04  vmovaps xmm14, [rsp+0x70]
00007026095d6d0a  vmovaps xmm13, [rsp+0x70]
00007026095d6d10  por xmm14, xmm13
00007026095d6d15  movaps [r15+0x280], xmm14
00007026095d6d1d  vmovaps xmm13, [rsp+0x60]
00007026095d6d23  vmovaps [rsp+0x20], xmm1
00007026095d6d29  vmovaps xmm1, [rsp+0x60]
00007026095d6d2f  por xmm13, xmm1
00007026095d6d34  movaps [r15+0x2A0], xmm13
00007026095d6d3c  vmovaps xmm1, [rsp+0x50]
00007026095d6d42  vmovaps [rsp+0x60], xmm15
00007026095d6d48  vmovaps xmm15, [rsp+0x50]
00007026095d6d4e  por xmm1, xmm15
00007026095d6d53  movaps [r15+0x2E0], xmm1
00007026095d6d5b  vmovaps [rsp+0x50], xmm2
00007026095d6d61  vmovaps xmm15, [rsp+0x50]
00007026095d6d67  por xmm2, xmm15
00007026095d6d6c  movaps [r15+0x1F0], xmm2
00007026095d6d74  vmovaps xmm15, [rsp+0x90]
00007026095d6d7d  vmovaps [rsp+0x50], xmm1
00007026095d6d83  vmovaps xmm1, [rsp+0x90]
00007026095d6d8c  por xmm15, xmm1
00007026095d6d91  movaps [r15+0x250], xmm15
00007026095d6d99  vmovaps xmm1, [rsp+0xD0]
00007026095d6da2  vmovaps xmm15, [rsp+0xD0]
00007026095d6dab  por xmm1, xmm15
00007026095d6db0  movaps [r15+0x260], xmm1
00007026095d6db8  vmovaps xmm15, [rsp+0x110]
00007026095d6dc1  vmovaps [rsp+0x70], xmm1
00007026095d6dc7  vmovaps xmm1, [rsp+0x110]
00007026095d6dd0  por xmm15, xmm1
00007026095d6dd5  movaps [r15+0x290], xmm15
00007026095d6ddd  vmovaps xmm1, [rsp+0x100]
00007026095d6de6  vmovaps [rsp+0x80], xmm15
00007026095d6def  vmovaps xmm15, [rsp+0x100]
00007026095d6df8  por xmm1, xmm15
00007026095d6dfd  movaps [r15+0x2C0], xmm1
00007026095d6e05  movq xmm15, qword ptr [r15+0x240]
00007026095d6e0e  vmovaps [rsp+0x90], xmm15
00007026095d6e17  vpermilpd xmm15, xmm15, 0x00
00007026095d6e1d  vmovaps [rsp+0xD0], xmm1
00007026095d6e26  vmovaps xmm1, [rsp+0x40]
00007026095d6e2c  vmovaps [rsp+0x40], xmm15
00007026095d6e32  vmovaps xmm15, [rsp+0x20]
00007026095d6e38  vmovaps [rsp+0x20], xmm14
00007026095d6e3e  vmovaps xmm14, [rsp+0x40]
00007026095d6e44  vmovaps [rsp+0x40], xmm13
00007026095d6e4a  vmovaps [rsp+0x100], xmm12
00007026095d6e53  movaps xmm13, xmm1
00007026095d6e57  vfmadd231pd xmm13, xmm15, xmm14
00007026095d6e5c  vcmppd xmm12, xmm13, xmm13, 0x03
00007026095d6e62  vptest xmm12, xmm12
00007026095d6e67  jnz 0x00007026095D7B55
00007026095d6e6d  vmovaps xmm1, [rsp+0x90]
00007026095d6e76  vpermilpd xmm1, xmm1, 0x00
00007026095d6e7c  vmovaps xmm15, [rsp+0xB0]
00007026095d6e85  vmovaps xmm14, [rsp+0x50]
00007026095d6e8b  vmovaps [rsp+0x50], xmm13
00007026095d6e91  movaps xmm12, xmm15
00007026095d6e95  vfmadd231pd xmm12, xmm14, xmm1
00007026095d6e9a  vcmppd xmm13, xmm12, xmm12, 0x03
00007026095d6ea0  vptest xmm13, xmm13
00007026095d6ea5  jnz 0x00007026095D7CAE
00007026095d6eab  vmovaps xmm1, [rsp+0x90]
00007026095d6eb4  vpermilpd xmm1, xmm1, 0x00
00007026095d6eba  vmovaps xmm15, [rsp+0x130]
00007026095d6ec3  vmovaps xmm14, [rsp+0x60]
00007026095d6ec9  vmovaps [rsp+0x60], xmm12
00007026095d6ecf  movaps xmm13, xmm15
00007026095d6ed3  vfmadd231pd xmm13, xmm14, xmm1
00007026095d6ed8  vcmppd xmm12, xmm13, xmm13, 0x03
00007026095d6ede  vptest xmm12, xmm12
00007026095d6ee3  jnz 0x00007026095D7E07
00007026095d6ee9  vmovaps xmm1, [rsp+0x120]
00007026095d6ef2  vmovaps xmm15, [rsp+0x120]
00007026095d6efb  por xmm1, xmm15
00007026095d6f00  movaps [r15+0x1D0], xmm1
00007026095d6f08  vmovaps xmm15, [rsp+0x90]
00007026095d6f11  vpermilpd xmm15, xmm15, 0x00
00007026095d6f17  vmovaps xmm14, [rsp+0x100]
00007026095d6f20  vmovaps [rsp+0x90], xmm1
00007026095d6f29  movaps xmm12, xmm14
00007026095d6f2d  vfmadd231pd xmm12, xmm2, xmm15
00007026095d6f32  vcmppd xmm1, xmm12, xmm12, 0x03
00007026095d6f38  vptest xmm1, xmm1
00007026095d6f3d  jnz 0x00007026095D7F60
00007026095d6f43  vmovaps [rsp+0xB0], xmm3
00007026095d6f4c  vmovaps xmm1, [rsp+0xB0]
00007026095d6f55  por xmm3, xmm1
00007026095d6f59  movaps [r15+0x200], xmm3
00007026095d6f61  vmovaps xmm1, [rsp+0xF0]
00007026095d6f6a  vmovaps xmm15, [rsp+0xF0]
00007026095d6f73  por xmm1, xmm15
00007026095d6f78  movaps [r15+0x1E0], xmm1
00007026095d6f80  vmovaps [rsp+0xB0], xmm7
00007026095d6f89  vmovaps xmm1, [rsp+0xB0]
00007026095d6f92  por xmm7, xmm1
00007026095d6f96  movaps [r15+0x2B0], xmm7
00007026095d6f9e  vmovaps [rsp+0xB0], xmm8
00007026095d6fa7  vmovaps xmm1, [rsp+0xB0]
00007026095d6fb0  por xmm8, xmm1
00007026095d6fb5  movaps [r15+0x300], xmm8
00007026095d6fbd  vmovaps [rsp+0xB0], xmm5
00007026095d6fc6  vpermilpd xmm5, xmm5, 0x00
00007026095d6fcc  vmovaps xmm14, [rsp+0x50]
00007026095d6fd2  vmovaps xmm8, [rsp+0x70]
00007026095d6fd8  vmovaps [rsp+0x50], xmm1
00007026095d6fde  movaps xmm2, xmm14
00007026095d6fe2  vfmadd231pd xmm2, xmm8, xmm5
00007026095d6fe7  vcmppd xmm1, xmm2, xmm2, 0x03
00007026095d6fec  vptest xmm1, xmm1
00007026095d6ff1  jnz 0x00007026095D80B9
00007026095d6ff7  vmovaps xmm1, [rsp+0xB0]
00007026095d7000  vpermilpd xmm1, xmm1, 0x00
00007026095d7006  vmovaps xmm14, [rsp+0x60]
00007026095d700c  vmovaps xmm8, [rsp+0xD0]
00007026095d7015  vmovaps [rsp+0x60], xmm15
00007026095d701b  movaps xmm5, xmm14
00007026095d701f  vfmadd231pd xmm5, xmm8, xmm1
00007026095d7024  vcmppd xmm15, xmm5, xmm5, 0x03
00007026095d7029  vptest xmm15, xmm15
00007026095d702e  jnz 0x00007026095D8210
00007026095d7034  vmovaps xmm1, [rsp+0xB0]
00007026095d703d  vpermilpd xmm1, xmm1, 0x00
00007026095d7043  vmovaps xmm14, [rsp+0x20]
00007026095d7049  movaps xmm15, xmm13
00007026095d704d  vfmadd231pd xmm15, xmm14, xmm1
00007026095d7052  vcmppd xmm8, xmm15, xmm15, 0x03
00007026095d7058  vptest xmm8, xmm8
00007026095d705d  jnz 0x00007026095D8367
00007026095d7063  vmovaps xmm1, [rsp+0xB0]
00007026095d706c  vpermilpd xmm1, xmm1, 0x00
00007026095d7072  vmovaps xmm14, [rsp+0x90]
00007026095d707b  movaps xmm13, xmm12
00007026095d707f  vfmadd231pd xmm13, xmm14, xmm1
00007026095d7084  vcmppd xmm8, xmm13, xmm13, 0x03
00007026095d708a  vptest xmm8, xmm8
00007026095d708f  jnz 0x00007026095D84C0
00007026095d7095  vmovaps [rsp+0x20], xmm6
00007026095d709b  vmovaps xmm1, [rsp+0x20]
00007026095d70a1  por xmm6, xmm1
00007026095d70a5  movaps [r15+0x180], xmm6
00007026095d70ad  vmovaps [rsp+0x20], xmm9
00007026095d70b3  vmovaps xmm1, [rsp+0x20]
00007026095d70b9  por xmm9, xmm1
00007026095d70be  movaps [r15+0x2D0], xmm9
00007026095d70c6  vmovaps [rsp+0x20], xmm10
00007026095d70cc  vmovaps xmm1, [rsp+0x20]
00007026095d70d2  por xmm10, xmm1
00007026095d70d7  movaps [r15+0x2F0], xmm10
00007026095d70df  vmovaps [rsp+0x20], xmm4
00007026095d70e5  vpermilpd xmm4, xmm4, 0x00
00007026095d70eb  vmovaps xmm14, [rsp+0x50]
00007026095d70f1  movaps xmm12, xmm5
00007026095d70f5  vfmadd231pd xmm12, xmm14, xmm4
00007026095d70fa  vcmppd xmm10, xmm12, xmm12, 0x03
00007026095d7100  vptest xmm10, xmm10
00007026095d7105  jnz 0x00007026095D8619
00007026095d710b  vmovaps xmm14, [rsp+0x20]
00007026095d7111  vpermilpd xmm14, xmm14, 0x00
00007026095d7117  movaps xmm10, xmm2
00007026095d711b  vfmadd231pd xmm10, xmm6, xmm14
00007026095d7120  vcmppd xmm8, xmm10, xmm10, 0x03
00007026095d7126  vptest xmm8, xmm8
00007026095d712b  jnz 0x00007026095D8771
00007026095d7131  lea rax, [r14+0x80]
00007026095d7138  movups xmm14, [r13+rax*1]
00007026095d713e  movaps [r15+0x190], xmm14
00007026095d7146  vmovaps xmm8, [rsp+0x20]
00007026095d714c  vpermilpd xmm8, xmm8, 0x00
00007026095d7152  vmovaps xmm6, [rsp+0x80]
00007026095d715b  movaps xmm5, xmm15
00007026095d715f  vfmadd231pd xmm5, xmm6, xmm8
00007026095d7164  vcmppd xmm4, xmm5, xmm5, 0x03
00007026095d7169  vptest xmm4, xmm4
00007026095d716e  jnz 0x00007026095D88D3
00007026095d7174  vmovaps xmm15, [rsp+0x20]
00007026095d717a  vpermilpd xmm15, xmm15, 0x00
00007026095d7180  movaps xmm8, xmm13
00007026095d7184  vfmadd231pd xmm8, xmm1, xmm15
00007026095d7189  vcmppd xmm6, xmm8, xmm8, 0x03
00007026095d718f  vptest xmm6, xmm6
00007026095d7194  jnz 0x00007026095D8A2A
00007026095d719a  vmovaps xmm1, [rsp+0x30]
00007026095d71a0  vmovaps xmm15, [rsp+0x30]
00007026095d71a6  por xmm1, xmm15
00007026095d71ab  movaps [r15+0x160], xmm1
00007026095d71b3  lea rax, [r14+0x40]
00007026095d71b7  movups xmm15, [r13+rax*1]
00007026095d71bd  lea rax, [r14+0x50]
00007026095d71c1  movups xmm13, [r13+rax*1]
00007026095d71c7  movaps [r15+0x1B0], xmm15
00007026095d71cf  movaps [r15+0x1A0], xmm13
00007026095d71d7  vmovaps xmm6, [rsp+0xC0]
00007026095d71e0  vpermilpd xmm6, xmm6, 0x00
00007026095d71e6  movaps xmm4, xmm12
00007026095d71ea  vfmadd231pd xmm4, xmm9, xmm6
00007026095d71ef  vcmppd xmm2, xmm4, xmm4, 0x03
00007026095d71f4  vptest xmm2, xmm2
00007026095d71f9  jnz 0x00007026095D8B97
00007026095d71ff  vmovaps xmm12, [rsp+0xC0]
00007026095d7208  vpermilpd xmm12, xmm12, 0x00
00007026095d720e  movaps xmm9, xmm10
00007026095d7212  vfmadd231pd xmm9, xmm1, xmm12
00007026095d7217  vcmppd xmm6, xmm9, xmm9, 0x03
00007026095d721d  vptest xmm6, xmm6
00007026095d7222  jnz 0x00007026095D8CEE
00007026095d7228  vmovaps xmm1, [rsp+0xC0]
00007026095d7231  vpermilpd xmm1, xmm1, 0x00
00007026095d7237  vmovaps xmm12, [rsp+0x40]
00007026095d723d  movaps xmm10, xmm5
00007026095d7241  vfmadd231pd xmm10, xmm12, xmm1
00007026095d7246  vcmppd xmm6, xmm10, xmm10, 0x03
00007026095d724c  vptest xmm6, xmm6
00007026095d7251  jnz 0x00007026095D8E47
00007026095d7257  vmovaps xmm1, [rsp+0xC0]
00007026095d7260  vpermilpd xmm1, xmm1, 0x00
00007026095d7266  vmovaps xmm12, [rsp+0x60]
00007026095d726c  movaps xmm6, xmm8
00007026095d7270  vfmadd231pd xmm6, xmm12, xmm1
00007026095d7275  vcmppd xmm5, xmm6, xmm6, 0x03
00007026095d727a  vptest xmm5, xmm5
00007026095d727f  jnz 0x00007026095D8F9F
00007026095d7285  lea rax, [r14+0x60]
00007026095d7289  movups xmm1, [r13+rax*1]
00007026095d728f  lea rax, [r14+0x70]
00007026095d7293  movups xmm12, [r13+rax*1]
00007026095d7299  movaps [r15+0x150], xmm1
00007026095d72a1  movaps [r15+0x120], xmm12
00007026095d72a9  vmovaps [rsp+0x20], xmm11
00007026095d72af  vpermilpd xmm11, xmm11, 0x00
00007026095d72b5  movaps xmm8, xmm4
00007026095d72b9  vfmadd231pd xmm8, xmm13, xmm11
00007026095d72be  vcmppd xmm5, xmm8, xmm8, 0x03
00007026095d72c4  vptest xmm5, xmm5
00007026095d72c9  jnz 0x00007026095D910A
00007026095d72cf  vmovaps xmm13, [rsp+0x20]
00007026095d72d5  vpermilpd xmm13, xmm13, 0x00
00007026095d72db  movaps xmm11, xmm9
00007026095d72df  vfmadd231pd xmm11, xmm1, xmm13
00007026095d72e4  vcmppd xmm5, xmm11, xmm11, 0x03
00007026095d72ea  vptest xmm5, xmm5
00007026095d72ef  jnz 0x00007026095D9263
00007026095d72f5  vmovaps xmm1, [rsp+0x20]
00007026095d72fb  vpermilpd xmm1, xmm1, 0x00
00007026095d7301  movaps xmm13, xmm10
00007026095d7305  vfmadd231pd xmm13, xmm7, xmm1
00007026095d730a  vcmppd xmm9, xmm13, xmm13, 0x03
00007026095d7310  vptest xmm9, xmm9
00007026095d7315  jnz 0x00007026095D93BC
00007026095d731b  vmovaps xmm1, [rsp+0x20]
00007026095d7321  vpermilpd xmm1, xmm1, 0x00
00007026095d7327  movaps xmm10, xmm6
00007026095d732b  vfmadd231pd xmm10, xmm15, xmm1
00007026095d7330  vcmppd xmm9, xmm10, xmm10, 0x03
00007026095d7336  vptest xmm9, xmm9
00007026095d733b  jnz 0x00007026095D9514
00007026095d7341  lea rax, [r14+0x20]
00007026095d7345  movups xmm1, [r13+rax*1]
00007026095d734b  lea rax, [r14+0x30]
00007026095d734f  movups xmm15, [r13+rax*1]
00007026095d7355  vmovaps xmm9, [rsp+0xA0]
00007026095d735e  vpermilpd xmm9, xmm9, 0x00
00007026095d7364  movaps xmm7, xmm8
00007026095d7368  vfmadd231pd xmm7, xmm3, xmm9
00007026095d736d  vcmppd xmm6, xmm7, xmm7, 0x03
00007026095d7372  vptest xmm6, xmm6
00007026095d7377  jnz 0x00007026095D9680
00007026095d737d  vmovaps xmm9, [rsp+0xA0]
00007026095d7386  vpermilpd xmm9, xmm9, 0x00
00007026095d738c  movaps xmm8, xmm11
00007026095d7390  vfmadd231pd xmm8, xmm14, xmm9
00007026095d7395  vcmppd xmm6, xmm8, xmm8, 0x03
00007026095d739b  vptest xmm6, xmm6
00007026095d73a0  jnz 0x00007026095D97D7
00007026095d73a6  vmovaps xmm14, [rsp+0xA0]
00007026095d73af  vpermilpd xmm14, xmm14, 0x00
00007026095d73b5  movaps xmm11, xmm13
00007026095d73b9  vfmadd231pd xmm11, xmm12, xmm14
00007026095d73be  vcmppd xmm9, xmm11, xmm11, 0x03
00007026095d73c4  vptest xmm9, xmm9
00007026095d73c9  jnz 0x00007026095D9931
00007026095d73cf  vmovaps xmm14, [rsp+0xA0]
00007026095d73d8  vpermilpd xmm14, xmm14, 0x00
00007026095d73de  movaps xmm12, xmm10
00007026095d73e2  vfmadd231pd xmm12, xmm15, xmm14
00007026095d73e7  vcmppd xmm13, xmm12, xmm12, 0x03
00007026095d73ed  vptest xmm13, xmm13
00007026095d73f2  jnz 0x00007026095D9A8B
00007026095d73f8  lea rax, [r14+0x90]
00007026095d73ff  movups xmm15, [r13+rax*1]
00007026095d7405  lea rax, [r14+0xA0]
00007026095d740c  movups xmm14, [r13+rax*1]
00007026095d7412  movaps [r15+0x140], xmm15
00007026095d741a  movaps [r15+0x130], xmm14
00007026095d7422  vmovaps xmm13, [rsp+0x10]
00007026095d7428  vpermilpd xmm13, xmm13, 0x00
00007026095d742e  movaps xmm10, xmm7
00007026095d7432  vfmadd231pd xmm10, xmm1, xmm13
00007026095d7437  vcmppd xmm9, xmm10, xmm10, 0x03
00007026095d743d  vptest xmm9, xmm9
00007026095d7442  jnz 0x00007026095D9BF9
00007026095d7448  movaps [r15+0x220], xmm10
00007026095d7450  lea rax, [r14+0x10]
00007026095d7454  movups xmm1, [r13+rax*1]
00007026095d745a  movaps [r15+0x240], xmm1
00007026095d7462  vmovaps xmm13, [rsp+0x10]
00007026095d7468  vpermilpd xmm13, xmm13, 0x00
00007026095d746e  movaps xmm9, xmm8
00007026095d7472  vfmadd231pd xmm9, xmm14, xmm13
00007026095d7477  vcmppd xmm7, xmm9, xmm9, 0x03
00007026095d747d  vptest xmm7, xmm7
00007026095d7482  jnz 0x00007026095D9D5B
00007026095d7488  movaps [r15+0x110], xmm9
00007026095d7490  vmovaps xmm14, [rsp+0x10]
00007026095d7496  vpermilpd xmm14, xmm14, 0x00
00007026095d749c  movaps xmm13, xmm11
00007026095d74a0  vfmadd231pd xmm13, xmm15, xmm14
00007026095d74a5  vcmppd xmm8, xmm13, xmm13, 0x03
00007026095d74ab  vptest xmm8, xmm8
00007026095d74b0  jnz 0x00007026095D9EB5
00007026095d74b6  movaps [r15+0x170], xmm13
00007026095d74be  vmovaps xmm15, [rsp+0x10]
00007026095d74c4  vpermilpd xmm15, xmm15, 0x00
00007026095d74ca  movaps xmm14, xmm12
00007026095d74ce  vfmadd231pd xmm14, xmm1, xmm15
00007026095d74d3  vcmppd xmm11, xmm14, xmm14, 0x03
00007026095d74d9  vptest xmm11, xmm11
00007026095d74de  jnz 0x00007026095DA00F
00007026095d74e4  movaps [r15+0x230], xmm14
00007026095d74ec  mov rax, [rsp+0xE0]
00007026095d74f4  movups [r13+rax*1], xmm9
00007026095d74fa  lea r14, [rax+0x10]
00007026095d74fe  movups [r13+r14*1], xmm13
00007026095d7504  lea r14, [rax+0x20]
00007026095d7508  movups [r13+r14*1], xmm10
00007026095d750e  lea r14, [rax+0x30]
00007026095d7512  movups [r13+r14*1], xmm14
00007026095d7518  mov eax, [r15+0x108]
00007026095d751f  sahf
00007026095d7520  jnz 0x00007026095D7552
00007026095d7522  cmp dword ptr [r15+0x318], 0x00
00007026095d752a  jz 0x00007026095D67A0
00007026095d7530  nop [rax+rax*1], ax
00007026095d7539  nop [rax+rax*1], eax
00007026095d7541  mov eax, 0x4103F0
00007026095d7546  mov [r15+0x100], rax
00007026095d754d  jmp 0x00007026093FE110
00007026095d7552  cmp dword ptr [r15+0x318], 0x00
00007026095d755a  jz 0x00007026095D2E40
00007026095d7560  nop [rax+rax*1], ax
00007026095d7569  nop [rax+rax*1], eax
00007026095d7571  mov eax, 0x410274
00007026095d7576  mov [r15+0x100], rax
00007026095d757d  jmp 0x00007026093FE110
00007026095d7582  int3
00007026095d7583  call 0x00007026094E27E0
00007026095d7588  jmp 0x00007026095D6860
00007026095d758d  call 0x00007026094E1570
00007026095d7592  jmp 0x00007026095D6869
00007026095d7597  call 0x00007026094E27E0
00007026095d759c  jmp 0x00007026095D68B2
00007026095d75a1  call 0x00007026094E1570
00007026095d75a6  jmp 0x00007026095D68BB
00007026095d75ab  call 0x00007026094E27E0
00007026095d75b0  jmp 0x00007026095D6953
00007026095d75b5  call 0x00007026094E1570
00007026095d75ba  jmp 0x00007026095D695C
00007026095d75bf  call 0x000070260940DC20
00007026095d75c4  jmp 0x00007026095D6A47
00007026095d75c9  call 0x00007026094D64F0
00007026095d75ce  jmp 0x00007026095D6A76
00007026095d75d3  call 0x00007026094B47C0
00007026095d75d8  jmp 0x00007026095D6A91
00007026095d75dd  sub rsp, 0x08
00007026095d75e1  push rax
00007026095d75e2  push rcx
00007026095d75e3  push rdx
00007026095d75e4  push rdi
00007026095d75e5  push rsi
00007026095d75e6  push r8
00007026095d75e8  push r9
00007026095d75ea  push r10
00007026095d75ec  push r11
00007026095d75ee  sub rsp, 0xF0
00007026095d75f5  vmovaps [rsp], xmm0
00007026095d75fa  vmovaps [rsp+0x10], xmm1
00007026095d7600  vmovaps [rsp+0x20], xmm2
00007026095d7606  vmovaps [rsp+0x30], xmm3
00007026095d760c  vmovaps [rsp+0x40], xmm4
00007026095d7612  vmovaps [rsp+0x50], xmm5
00007026095d7618  vmovaps [rsp+0x60], xmm6
00007026095d761e  vmovaps [rsp+0x70], xmm7
00007026095d7624  vmovaps [rsp+0x80], xmm8
00007026095d762d  vmovaps [rsp+0x90], xmm9
00007026095d7636  vmovaps [rsp+0xA0], xmm10
00007026095d763f  vmovaps [rsp+0xB0], xmm11
00007026095d7648  vmovaps [rsp+0xC0], xmm12
00007026095d7651  vmovaps [rsp+0xD0], xmm14
00007026095d765a  vmovaps [rsp+0xE0], xmm15
00007026095d7663  sub rsp, 0x40
00007026095d7667  lea rdi, [rsp]
00007026095d766b  lea rsi, [rsp+0x10]
00007026095d7670  lea rdx, [rsp+0x20]
00007026095d7675  lea rcx, [rsp+0x30]
00007026095d767a  mov r8d, 0x00
00007026095d7680  lea r9, [r15+0x3A8]
00007026095d7687  movaps [rdi], xmm13
00007026095d768b  movaps [rsi], xmm1
00007026095d768e  movaps [rdx], xmm15
00007026095d7692  movaps [rcx], xmm14
00007026095d7696  mov rax, 0x58A432239A50
00007026095d76a0  call rax
00007026095d76a2  movaps xmm13, [rsp]
00007026095d76a7  add rsp, 0x40
00007026095d76ab  vmovaps xmm0, [rsp]
00007026095d76b0  vmovaps xmm1, [rsp+0x10]
00007026095d76b6  vmovaps xmm2, [rsp+0x20]
00007026095d76bc  vmovaps xmm3, [rsp+0x30]
00007026095d76c2  vmovaps xmm4, [rsp+0x40]
00007026095d76c8  vmovaps xmm5, [rsp+0x50]
00007026095d76ce  vmovaps xmm6, [rsp+0x60]
00007026095d76d4  vmovaps xmm7, [rsp+0x70]
00007026095d76da  vmovaps xmm8, [rsp+0x80]
00007026095d76e3  vmovaps xmm9, [rsp+0x90]
00007026095d76ec  vmovaps xmm10, [rsp+0xA0]
00007026095d76f5  vmovaps xmm11, [rsp+0xB0]
00007026095d76fe  vmovaps xmm12, [rsp+0xC0]
00007026095d7707  vmovaps xmm14, [rsp+0xD0]
00007026095d7710  vmovaps xmm15, [rsp+0xE0]
00007026095d7719  add rsp, 0xF0
00007026095d7720  pop r11
00007026095d7722  pop r10
00007026095d7724  pop r9
00007026095d7726  pop r8
00007026095d7728  pop rsi
00007026095d7729  pop rdi
00007026095d772a  pop rdx
00007026095d772b  pop rcx
00007026095d772c  pop rax
00007026095d772d  add rsp, 0x08
00007026095d7731  jmp 0x00007026095D6B04
00007026095d7736  sub rsp, 0x08
00007026095d773a  push rax
00007026095d773b  push rcx
00007026095d773c  push rdx
00007026095d773d  push rdi
00007026095d773e  push rsi
00007026095d773f  push r8
00007026095d7741  push r9
00007026095d7743  push r10
00007026095d7745  push r11
00007026095d7747  sub rsp, 0xF0
00007026095d774e  vmovaps [rsp], xmm0
00007026095d7753  vmovaps [rsp+0x10], xmm1
00007026095d7759  vmovaps [rsp+0x20], xmm2
00007026095d775f  vmovaps [rsp+0x30], xmm3
00007026095d7765  vmovaps [rsp+0x40], xmm4
00007026095d776b  vmovaps [rsp+0x50], xmm5
00007026095d7771  vmovaps [rsp+0x60], xmm6
00007026095d7777  vmovaps [rsp+0x70], xmm7
00007026095d777d  vmovaps [rsp+0x80], xmm8
00007026095d7786  vmovaps [rsp+0x90], xmm9
00007026095d778f  vmovaps [rsp+0xA0], xmm10
00007026095d7798  vmovaps [rsp+0xB0], xmm11
00007026095d77a1  vmovaps [rsp+0xC0], xmm13
00007026095d77aa  vmovaps [rsp+0xD0], xmm14
00007026095d77b3  vmovaps [rsp+0xE0], xmm15
00007026095d77bc  sub rsp, 0x40
00007026095d77c0  lea rdi, [rsp]
00007026095d77c4  lea rsi, [rsp+0x10]
00007026095d77c9  lea rdx, [rsp+0x20]
00007026095d77ce  lea rcx, [rsp+0x30]
00007026095d77d3  mov r8d, 0x00
00007026095d77d9  lea r9, [r15+0x3A8]
00007026095d77e0  movaps [rdi], xmm12
00007026095d77e4  movaps [rsi], xmm15
00007026095d77e8  movaps [rdx], xmm1
00007026095d77eb  movaps [rcx], xmm14
00007026095d77ef  mov rax, 0x58A432239A50
00007026095d77f9  call rax
00007026095d77fb  movaps xmm12, [rsp]
00007026095d7800  add rsp, 0x40
00007026095d7804  vmovaps xmm0, [rsp]
00007026095d7809  vmovaps xmm1, [rsp+0x10]
00007026095d780f  vmovaps xmm2, [rsp+0x20]
00007026095d7815  vmovaps xmm3, [rsp+0x30]
00007026095d781b  vmovaps xmm4, [rsp+0x40]
00007026095d7821  vmovaps xmm5, [rsp+0x50]
00007026095d7827  vmovaps xmm6, [rsp+0x60]
00007026095d782d  vmovaps xmm7, [rsp+0x70]
00007026095d7833  vmovaps xmm8, [rsp+0x80]
00007026095d783c  vmovaps xmm9, [rsp+0x90]
00007026095d7845  vmovaps xmm10, [rsp+0xA0]
00007026095d784e  vmovaps xmm11, [rsp+0xB0]
00007026095d7857  vmovaps xmm13, [rsp+0xC0]
00007026095d7860  vmovaps xmm14, [rsp+0xD0]
00007026095d7869  vmovaps xmm15, [rsp+0xE0]
00007026095d7872  add rsp, 0xF0
00007026095d7879  pop r11
00007026095d787b  pop r10
00007026095d787d  pop r9
00007026095d787f  pop r8
00007026095d7881  pop rsi
00007026095d7882  pop rdi
00007026095d7883  pop rdx
00007026095d7884  pop rcx
00007026095d7885  pop rax
00007026095d7886  add rsp, 0x08
00007026095d788a  jmp 0x00007026095D6B32
00007026095d788f  call 0x00007026094B52F0
00007026095d7894  jmp 0x00007026095D6C1E
00007026095d7899  sub rsp, 0x08
00007026095d789d  push rax
00007026095d789e  push rcx
00007026095d789f  push rdx
00007026095d78a0  push rdi
00007026095d78a1  push rsi
00007026095d78a2  push r8
00007026095d78a4  push r9
00007026095d78a6  push r10
00007026095d78a8  push r11
00007026095d78aa  sub rsp, 0xF0
00007026095d78b1  vmovaps [rsp], xmm0
00007026095d78b6  vmovaps [rsp+0x10], xmm1
00007026095d78bc  vmovaps [rsp+0x20], xmm2
00007026095d78c2  vmovaps [rsp+0x30], xmm3
00007026095d78c8  vmovaps [rsp+0x40], xmm4
00007026095d78ce  vmovaps [rsp+0x50], xmm5
00007026095d78d4  vmovaps [rsp+0x60], xmm6
00007026095d78da  vmovaps [rsp+0x70], xmm7
00007026095d78e0  vmovaps [rsp+0x80], xmm8
00007026095d78e9  vmovaps [rsp+0x90], xmm9
00007026095d78f2  vmovaps [rsp+0xA0], xmm10
00007026095d78fb  vmovaps [rsp+0xB0], xmm11
00007026095d7904  vmovaps [rsp+0xC0], xmm12
00007026095d790d  vmovaps [rsp+0xD0], xmm14
00007026095d7916  vmovaps [rsp+0xE0], xmm15
00007026095d791f  sub rsp, 0x40
00007026095d7923  lea rdi, [rsp]
00007026095d7927  lea rsi, [rsp+0x10]
00007026095d792c  lea rdx, [rsp+0x20]
00007026095d7931  lea rcx, [rsp+0x30]
00007026095d7936  mov r8d, 0x00
00007026095d793c  lea r9, [r15+0x3A8]
00007026095d7943  movaps [rdi], xmm13
00007026095d7947  movaps [rsi], xmm1
00007026095d794a  movaps [rdx], xmm15
00007026095d794e  movaps [rcx], xmm14
00007026095d7952  mov rax, 0x58A432239A50
00007026095d795c  call rax
00007026095d795e  movaps xmm13, [rsp]
00007026095d7963  add rsp, 0x40
00007026095d7967  vmovaps xmm0, [rsp]
00007026095d796c  vmovaps xmm1, [rsp+0x10]
00007026095d7972  vmovaps xmm2, [rsp+0x20]
00007026095d7978  vmovaps xmm3, [rsp+0x30]
00007026095d797e  vmovaps xmm4, [rsp+0x40]
00007026095d7984  vmovaps xmm5, [rsp+0x50]
00007026095d798a  vmovaps xmm6, [rsp+0x60]
00007026095d7990  vmovaps xmm7, [rsp+0x70]
00007026095d7996  vmovaps xmm8, [rsp+0x80]
00007026095d799f  vmovaps xmm9, [rsp+0x90]
00007026095d79a8  vmovaps xmm10, [rsp+0xA0]
00007026095d79b1  vmovaps xmm11, [rsp+0xB0]
00007026095d79ba  vmovaps xmm12, [rsp+0xC0]
00007026095d79c3  vmovaps xmm14, [rsp+0xD0]
00007026095d79cc  vmovaps xmm15, [rsp+0xE0]
00007026095d79d5  add rsp, 0xF0
00007026095d79dc  pop r11
00007026095d79de  pop r10
00007026095d79e0  pop r9
00007026095d79e2  pop r8
00007026095d79e4  pop rsi
00007026095d79e5  pop rdi
00007026095d79e6  pop rdx
00007026095d79e7  pop rcx
00007026095d79e8  pop rax
00007026095d79e9  add rsp, 0x08
00007026095d79ed  jmp 0x00007026095D6C93
00007026095d79f2  call 0x00007026093FF430
00007026095d79f7  jmp 0x00007026095D6CA0
00007026095d79fc  sub rsp, 0x08
00007026095d7a00  push rax
00007026095d7a01  push rcx
00007026095d7a02  push rdx
00007026095d7a03  push rdi
00007026095d7a04  push rsi
00007026095d7a05  push r8
00007026095d7a07  push r9
00007026095d7a09  push r10
00007026095d7a0b  push r11
00007026095d7a0d  sub rsp, 0xF0
00007026095d7a14  vmovaps [rsp], xmm0
00007026095d7a19  vmovaps [rsp+0x10], xmm1
00007026095d7a1f  vmovaps [rsp+0x20], xmm2
00007026095d7a25  vmovaps [rsp+0x30], xmm3
00007026095d7a2b  vmovaps [rsp+0x40], xmm4
00007026095d7a31  vmovaps [rsp+0x50], xmm5
00007026095d7a37  vmovaps [rsp+0x60], xmm6
00007026095d7a3d  vmovaps [rsp+0x70], xmm7
00007026095d7a43  vmovaps [rsp+0x80], xmm8
00007026095d7a4c  vmovaps [rsp+0x90], xmm9
00007026095d7a55  vmovaps [rsp+0xA0], xmm10
00007026095d7a5e  vmovaps [rsp+0xB0], xmm11
00007026095d7a67  vmovaps [rsp+0xC0], xmm13
00007026095d7a70  vmovaps [rsp+0xD0], xmm14
00007026095d7a79  vmovaps [rsp+0xE0], xmm15
00007026095d7a82  sub rsp, 0x40
00007026095d7a86  lea rdi, [rsp]
00007026095d7a8a  lea rsi, [rsp+0x10]
00007026095d7a8f  lea rdx, [rsp+0x20]
00007026095d7a94  lea rcx, [rsp+0x30]
00007026095d7a99  mov r8d, 0x00
00007026095d7a9f  lea r9, [r15+0x3A8]
00007026095d7aa6  movaps [rdi], xmm12
00007026095d7aaa  movaps [rsi], xmm15
00007026095d7aae  movaps [rdx], xmm1
00007026095d7ab1  movaps [rcx], xmm14
00007026095d7ab5  mov rax, 0x58A432239A50
00007026095d7abf  call rax
00007026095d7ac1  movaps xmm12, [rsp]
00007026095d7ac6  add rsp, 0x40
00007026095d7aca  vmovaps xmm0, [rsp]
00007026095d7acf  vmovaps xmm1, [rsp+0x10]
00007026095d7ad5  vmovaps xmm2, [rsp+0x20]
00007026095d7adb  vmovaps xmm3, [rsp+0x30]
00007026095d7ae1  vmovaps xmm4, [rsp+0x40]
00007026095d7ae7  vmovaps xmm5, [rsp+0x50]
00007026095d7aed  vmovaps xmm6, [rsp+0x60]
00007026095d7af3  vmovaps xmm7, [rsp+0x70]
00007026095d7af9  vmovaps xmm8, [rsp+0x80]
00007026095d7b02  vmovaps xmm9, [rsp+0x90]
00007026095d7b0b  vmovaps xmm10, [rsp+0xA0]
00007026095d7b14  vmovaps xmm11, [rsp+0xB0]
00007026095d7b1d  vmovaps xmm13, [rsp+0xC0]
00007026095d7b26  vmovaps xmm14, [rsp+0xD0]
00007026095d7b2f  vmovaps xmm15, [rsp+0xE0]
00007026095d7b38  add rsp, 0xF0
00007026095d7b3f  pop r11
00007026095d7b41  pop r10
00007026095d7b43  pop r9
00007026095d7b45  pop r8
00007026095d7b47  pop rsi
00007026095d7b48  pop rdi
00007026095d7b49  pop rdx
00007026095d7b4a  pop rcx
00007026095d7b4b  pop rax
00007026095d7b4c  add rsp, 0x08
00007026095d7b50  jmp 0x00007026095D6CCC
00007026095d7b55  sub rsp, 0x08
00007026095d7b59  push rax
00007026095d7b5a  push rcx
00007026095d7b5b  push rdx
00007026095d7b5c  push rdi
00007026095d7b5d  push rsi
00007026095d7b5e  push r8
00007026095d7b60  push r9
00007026095d7b62  push r10
00007026095d7b64  push r11
00007026095d7b66  sub rsp, 0xF0
00007026095d7b6d  vmovaps [rsp], xmm0
00007026095d7b72  vmovaps [rsp+0x10], xmm1
00007026095d7b78  vmovaps [rsp+0x20], xmm2
00007026095d7b7e  vmovaps [rsp+0x30], xmm3
00007026095d7b84  vmovaps [rsp+0x40], xmm4
00007026095d7b8a  vmovaps [rsp+0x50], xmm5
00007026095d7b90  vmovaps [rsp+0x60], xmm6
00007026095d7b96  vmovaps [rsp+0x70], xmm7
00007026095d7b9c  vmovaps [rsp+0x80], xmm8
00007026095d7ba5  vmovaps [rsp+0x90], xmm9
00007026095d7bae  vmovaps [rsp+0xA0], xmm10
00007026095d7bb7  vmovaps [rsp+0xB0], xmm11
00007026095d7bc0  vmovaps [rsp+0xC0], xmm12
00007026095d7bc9  vmovaps [rsp+0xD0], xmm14
00007026095d7bd2  vmovaps [rsp+0xE0], xmm15
00007026095d7bdb  sub rsp, 0x40
00007026095d7bdf  lea rdi, [rsp]
00007026095d7be3  lea rsi, [rsp+0x10]
00007026095d7be8  lea rdx, [rsp+0x20]
00007026095d7bed  lea rcx, [rsp+0x30]
00007026095d7bf2  mov r8d, 0x00
00007026095d7bf8  lea r9, [r15+0x3A8]
00007026095d7bff  movaps [rdi], xmm13
00007026095d7c03  movaps [rsi], xmm1
00007026095d7c06  movaps [rdx], xmm15
00007026095d7c0a  movaps [rcx], xmm14
00007026095d7c0e  mov rax, 0x58A432239A50
00007026095d7c18  call rax
00007026095d7c1a  movaps xmm13, [rsp]
00007026095d7c1f  add rsp, 0x40
00007026095d7c23  vmovaps xmm0, [rsp]
00007026095d7c28  vmovaps xmm1, [rsp+0x10]
00007026095d7c2e  vmovaps xmm2, [rsp+0x20]
00007026095d7c34  vmovaps xmm3, [rsp+0x30]
00007026095d7c3a  vmovaps xmm4, [rsp+0x40]
00007026095d7c40  vmovaps xmm5, [rsp+0x50]
00007026095d7c46  vmovaps xmm6, [rsp+0x60]
00007026095d7c4c  vmovaps xmm7, [rsp+0x70]
00007026095d7c52  vmovaps xmm8, [rsp+0x80]
00007026095d7c5b  vmovaps xmm9, [rsp+0x90]
00007026095d7c64  vmovaps xmm10, [rsp+0xA0]
00007026095d7c6d  vmovaps xmm11, [rsp+0xB0]
00007026095d7c76  vmovaps xmm12, [rsp+0xC0]
00007026095d7c7f  vmovaps xmm14, [rsp+0xD0]
00007026095d7c88  vmovaps xmm15, [rsp+0xE0]
00007026095d7c91  add rsp, 0xF0
00007026095d7c98  pop r11
00007026095d7c9a  pop r10
00007026095d7c9c  pop r9
00007026095d7c9e  pop r8
00007026095d7ca0  pop rsi
00007026095d7ca1  pop rdi
00007026095d7ca2  pop rdx
00007026095d7ca3  pop rcx
00007026095d7ca4  pop rax
00007026095d7ca5  add rsp, 0x08
00007026095d7ca9  jmp 0x00007026095D6E6D
00007026095d7cae  sub rsp, 0x08
00007026095d7cb2  push rax
00007026095d7cb3  push rcx
00007026095d7cb4  push rdx
00007026095d7cb5  push rdi
00007026095d7cb6  push rsi
00007026095d7cb7  push r8
00007026095d7cb9  push r9
00007026095d7cbb  push r10
00007026095d7cbd  push r11
00007026095d7cbf  sub rsp, 0xF0
00007026095d7cc6  vmovaps [rsp], xmm0
00007026095d7ccb  vmovaps [rsp+0x10], xmm1
00007026095d7cd1  vmovaps [rsp+0x20], xmm2
00007026095d7cd7  vmovaps [rsp+0x30], xmm3
00007026095d7cdd  vmovaps [rsp+0x40], xmm4
00007026095d7ce3  vmovaps [rsp+0x50], xmm5
00007026095d7ce9  vmovaps [rsp+0x60], xmm6
00007026095d7cef  vmovaps [rsp+0x70], xmm7
00007026095d7cf5  vmovaps [rsp+0x80], xmm8
00007026095d7cfe  vmovaps [rsp+0x90], xmm9
00007026095d7d07  vmovaps [rsp+0xA0], xmm10
00007026095d7d10  vmovaps [rsp+0xB0], xmm11
00007026095d7d19  vmovaps [rsp+0xC0], xmm13
00007026095d7d22  vmovaps [rsp+0xD0], xmm14
00007026095d7d2b  vmovaps [rsp+0xE0], xmm15
00007026095d7d34  sub rsp, 0x40
00007026095d7d38  lea rdi, [rsp]
00007026095d7d3c  lea rsi, [rsp+0x10]
00007026095d7d41  lea rdx, [rsp+0x20]
00007026095d7d46  lea rcx, [rsp+0x30]
00007026095d7d4b  mov r8d, 0x00
00007026095d7d51  lea r9, [r15+0x3A8]
00007026095d7d58  movaps [rdi], xmm12
00007026095d7d5c  movaps [rsi], xmm15
00007026095d7d60  movaps [rdx], xmm14
00007026095d7d64  movaps [rcx], xmm1
00007026095d7d67  mov rax, 0x58A432239A50
00007026095d7d71  call rax
00007026095d7d73  movaps xmm12, [rsp]
00007026095d7d78  add rsp, 0x40
00007026095d7d7c  vmovaps xmm0, [rsp]
00007026095d7d81  vmovaps xmm1, [rsp+0x10]
00007026095d7d87  vmovaps xmm2, [rsp+0x20]
00007026095d7d8d  vmovaps xmm3, [rsp+0x30]
00007026095d7d93  vmovaps xmm4, [rsp+0x40]
00007026095d7d99  vmovaps xmm5, [rsp+0x50]
00007026095d7d9f  vmovaps xmm6, [rsp+0x60]
00007026095d7da5  vmovaps xmm7, [rsp+0x70]
00007026095d7dab  vmovaps xmm8, [rsp+0x80]
00007026095d7db4  vmovaps xmm9, [rsp+0x90]
00007026095d7dbd  vmovaps xmm10, [rsp+0xA0]
00007026095d7dc6  vmovaps xmm11, [rsp+0xB0]
00007026095d7dcf  vmovaps xmm13, [rsp+0xC0]
00007026095d7dd8  vmovaps xmm14, [rsp+0xD0]
00007026095d7de1  vmovaps xmm15, [rsp+0xE0]
00007026095d7dea  add rsp, 0xF0
00007026095d7df1  pop r11
00007026095d7df3  pop r10
00007026095d7df5  pop r9
00007026095d7df7  pop r8
00007026095d7df9  pop rsi
00007026095d7dfa  pop rdi
00007026095d7dfb  pop rdx
00007026095d7dfc  pop rcx
00007026095d7dfd  pop rax
00007026095d7dfe  add rsp, 0x08
00007026095d7e02  jmp 0x00007026095D6EAB
00007026095d7e07  sub rsp, 0x08
00007026095d7e0b  push rax
00007026095d7e0c  push rcx
00007026095d7e0d  push rdx
00007026095d7e0e  push rdi
00007026095d7e0f  push rsi
00007026095d7e10  push r8
00007026095d7e12  push r9
00007026095d7e14  push r10
00007026095d7e16  push r11
00007026095d7e18  sub rsp, 0xF0
00007026095d7e1f  vmovaps [rsp], xmm0
00007026095d7e24  vmovaps [rsp+0x10], xmm1
00007026095d7e2a  vmovaps [rsp+0x20], xmm2
00007026095d7e30  vmovaps [rsp+0x30], xmm3
00007026095d7e36  vmovaps [rsp+0x40], xmm4
00007026095d7e3c  vmovaps [rsp+0x50], xmm5
00007026095d7e42  vmovaps [rsp+0x60], xmm6
00007026095d7e48  vmovaps [rsp+0x70], xmm7
00007026095d7e4e  vmovaps [rsp+0x80], xmm8
00007026095d7e57  vmovaps [rsp+0x90], xmm9
00007026095d7e60  vmovaps [rsp+0xA0], xmm10
00007026095d7e69  vmovaps [rsp+0xB0], xmm11
00007026095d7e72  vmovaps [rsp+0xC0], xmm12
00007026095d7e7b  vmovaps [rsp+0xD0], xmm14
00007026095d7e84  vmovaps [rsp+0xE0], xmm15
00007026095d7e8d  sub rsp, 0x40
00007026095d7e91  lea rdi, [rsp]
00007026095d7e95  lea rsi, [rsp+0x10]
00007026095d7e9a  lea rdx, [rsp+0x20]
00007026095d7e9f  lea rcx, [rsp+0x30]
00007026095d7ea4  mov r8d, 0x00
00007026095d7eaa  lea r9, [r15+0x3A8]
00007026095d7eb1  movaps [rdi], xmm13
00007026095d7eb5  movaps [rsi], xmm15
00007026095d7eb9  movaps [rdx], xmm14
00007026095d7ebd  movaps [rcx], xmm1
00007026095d7ec0  mov rax, 0x58A432239A50
00007026095d7eca  call rax
00007026095d7ecc  movaps xmm13, [rsp]
00007026095d7ed1  add rsp, 0x40
00007026095d7ed5  vmovaps xmm0, [rsp]
00007026095d7eda  vmovaps xmm1, [rsp+0x10]
00007026095d7ee0  vmovaps xmm2, [rsp+0x20]
00007026095d7ee6  vmovaps xmm3, [rsp+0x30]
00007026095d7eec  vmovaps xmm4, [rsp+0x40]
00007026095d7ef2  vmovaps xmm5, [rsp+0x50]
00007026095d7ef8  vmovaps xmm6, [rsp+0x60]
00007026095d7efe  vmovaps xmm7, [rsp+0x70]
00007026095d7f04  vmovaps xmm8, [rsp+0x80]
00007026095d7f0d  vmovaps xmm9, [rsp+0x90]
00007026095d7f16  vmovaps xmm10, [rsp+0xA0]
00007026095d7f1f  vmovaps xmm11, [rsp+0xB0]
00007026095d7f28  vmovaps xmm12, [rsp+0xC0]
00007026095d7f31  vmovaps xmm14, [rsp+0xD0]
00007026095d7f3a  vmovaps xmm15, [rsp+0xE0]
00007026095d7f43  add rsp, 0xF0
00007026095d7f4a  pop r11
00007026095d7f4c  pop r10
00007026095d7f4e  pop r9
00007026095d7f50  pop r8
00007026095d7f52  pop rsi
00007026095d7f53  pop rdi
00007026095d7f54  pop rdx
00007026095d7f55  pop rcx
00007026095d7f56  pop rax
00007026095d7f57  add rsp, 0x08
00007026095d7f5b  jmp 0x00007026095D6EE9
00007026095d7f60  sub rsp, 0x08
00007026095d7f64  push rax
00007026095d7f65  push rcx
00007026095d7f66  push rdx
00007026095d7f67  push rdi
00007026095d7f68  push rsi
00007026095d7f69  push r8
00007026095d7f6b  push r9
00007026095d7f6d  push r10
00007026095d7f6f  push r11
00007026095d7f71  sub rsp, 0xF0
00007026095d7f78  vmovaps [rsp], xmm0
00007026095d7f7d  vmovaps [rsp+0x10], xmm1
00007026095d7f83  vmovaps [rsp+0x20], xmm2
00007026095d7f89  vmovaps [rsp+0x30], xmm3
00007026095d7f8f  vmovaps [rsp+0x40], xmm4
00007026095d7f95  vmovaps [rsp+0x50], xmm5
00007026095d7f9b  vmovaps [rsp+0x60], xmm6
00007026095d7fa1  vmovaps [rsp+0x70], xmm7
00007026095d7fa7  vmovaps [rsp+0x80], xmm8
00007026095d7fb0  vmovaps [rsp+0x90], xmm9
00007026095d7fb9  vmovaps [rsp+0xA0], xmm10
00007026095d7fc2  vmovaps [rsp+0xB0], xmm11
00007026095d7fcb  vmovaps [rsp+0xC0], xmm13
00007026095d7fd4  vmovaps [rsp+0xD0], xmm14
00007026095d7fdd  vmovaps [rsp+0xE0], xmm15
00007026095d7fe6  sub rsp, 0x40
00007026095d7fea  lea rdi, [rsp]
00007026095d7fee  lea rsi, [rsp+0x10]
00007026095d7ff3  lea rdx, [rsp+0x20]
00007026095d7ff8  lea rcx, [rsp+0x30]
00007026095d7ffd  mov r8d, 0x00
00007026095d8003  lea r9, [r15+0x3A8]
00007026095d800a  movaps [rdi], xmm12
00007026095d800e  movaps [rsi], xmm14
00007026095d8012  movaps [rdx], xmm2
00007026095d8015  movaps [rcx], xmm15
00007026095d8019  mov rax, 0x58A432239A50
00007026095d8023  call rax
00007026095d8025  movaps xmm12, [rsp]
00007026095d802a  add rsp, 0x40
00007026095d802e  vmovaps xmm0, [rsp]
00007026095d8033  vmovaps xmm1, [rsp+0x10]
00007026095d8039  vmovaps xmm2, [rsp+0x20]
00007026095d803f  vmovaps xmm3, [rsp+0x30]
00007026095d8045  vmovaps xmm4, [rsp+0x40]
00007026095d804b  vmovaps xmm5, [rsp+0x50]
00007026095d8051  vmovaps xmm6, [rsp+0x60]
00007026095d8057  vmovaps xmm7, [rsp+0x70]
00007026095d805d  vmovaps xmm8, [rsp+0x80]
00007026095d8066  vmovaps xmm9, [rsp+0x90]
00007026095d806f  vmovaps xmm10, [rsp+0xA0]
00007026095d8078  vmovaps xmm11, [rsp+0xB0]
00007026095d8081  vmovaps xmm13, [rsp+0xC0]
00007026095d808a  vmovaps xmm14, [rsp+0xD0]
00007026095d8093  vmovaps xmm15, [rsp+0xE0]
00007026095d809c  add rsp, 0xF0
00007026095d80a3  pop r11
00007026095d80a5  pop r10
00007026095d80a7  pop r9
00007026095d80a9  pop r8
00007026095d80ab  pop rsi
00007026095d80ac  pop rdi
00007026095d80ad  pop rdx
00007026095d80ae  pop rcx
00007026095d80af  pop rax
00007026095d80b0  add rsp, 0x08
00007026095d80b4  jmp 0x00007026095D6F43
00007026095d80b9  sub rsp, 0x08
00007026095d80bd  push rax
00007026095d80be  push rcx
00007026095d80bf  push rdx
00007026095d80c0  push rdi
00007026095d80c1  push rsi
00007026095d80c2  push r8
00007026095d80c4  push r9
00007026095d80c6  push r10
00007026095d80c8  push r11
00007026095d80ca  sub rsp, 0xF0
00007026095d80d1  vmovaps [rsp], xmm0
00007026095d80d6  vmovaps [rsp+0x10], xmm1
00007026095d80dc  vmovaps [rsp+0x20], xmm3
00007026095d80e2  vmovaps [rsp+0x30], xmm4
00007026095d80e8  vmovaps [rsp+0x40], xmm5
00007026095d80ee  vmovaps [rsp+0x50], xmm6
00007026095d80f4  vmovaps [rsp+0x60], xmm7
00007026095d80fa  vmovaps [rsp+0x70], xmm8
00007026095d8100  vmovaps [rsp+0x80], xmm9
00007026095d8109  vmovaps [rsp+0x90], xmm10
00007026095d8112  vmovaps [rsp+0xA0], xmm11
00007026095d811b  vmovaps [rsp+0xB0], xmm12
00007026095d8124  vmovaps [rsp+0xC0], xmm13
00007026095d812d  vmovaps [rsp+0xD0], xmm14
00007026095d8136  vmovaps [rsp+0xE0], xmm15
00007026095d813f  sub rsp, 0x40
00007026095d8143  lea rdi, [rsp]
00007026095d8147  lea rsi, [rsp+0x10]
00007026095d814c  lea rdx, [rsp+0x20]
00007026095d8151  lea rcx, [rsp+0x30]
00007026095d8156  mov r8d, 0x00
00007026095d815c  lea r9, [r15+0x3A8]
00007026095d8163  movaps [rdi], xmm2
00007026095d8166  movaps [rsi], xmm14
00007026095d816a  movaps [rdx], xmm8
00007026095d816e  movaps [rcx], xmm5
00007026095d8171  mov rax, 0x58A432239A50
00007026095d817b  call rax
00007026095d817d  movaps xmm2, [rsp]
00007026095d8181  add rsp, 0x40
00007026095d8185  vmovaps xmm0, [rsp]
00007026095d818a  vmovaps xmm1, [rsp+0x10]
00007026095d8190  vmovaps xmm3, [rsp+0x20]
00007026095d8196  vmovaps xmm4, [rsp+0x30]
00007026095d819c  vmovaps xmm5, [rsp+0x40]
00007026095d81a2  vmovaps xmm6, [rsp+0x50]
00007026095d81a8  vmovaps xmm7, [rsp+0x60]
00007026095d81ae  vmovaps xmm8, [rsp+0x70]
00007026095d81b4  vmovaps xmm9, [rsp+0x80]
00007026095d81bd  vmovaps xmm10, [rsp+0x90]
00007026095d81c6  vmovaps xmm11, [rsp+0xA0]
00007026095d81cf  vmovaps xmm12, [rsp+0xB0]
00007026095d81d8  vmovaps xmm13, [rsp+0xC0]
00007026095d81e1  vmovaps xmm14, [rsp+0xD0]
00007026095d81ea  vmovaps xmm15, [rsp+0xE0]
00007026095d81f3  add rsp, 0xF0
00007026095d81fa  pop r11
00007026095d81fc  pop r10
00007026095d81fe  pop r9
00007026095d8200  pop r8
00007026095d8202  pop rsi
00007026095d8203  pop rdi
00007026095d8204  pop rdx
00007026095d8205  pop rcx
00007026095d8206  pop rax
00007026095d8207  add rsp, 0x08
00007026095d820b  jmp 0x00007026095D6FF7
00007026095d8210  sub rsp, 0x08
00007026095d8214  push rax
00007026095d8215  push rcx
00007026095d8216  push rdx
00007026095d8217  push rdi
00007026095d8218  push rsi
00007026095d8219  push r8
00007026095d821b  push r9
00007026095d821d  push r10
00007026095d821f  push r11
00007026095d8221  sub rsp, 0xF0
00007026095d8228  vmovaps [rsp], xmm0
00007026095d822d  vmovaps [rsp+0x10], xmm1
00007026095d8233  vmovaps [rsp+0x20], xmm2
00007026095d8239  vmovaps [rsp+0x30], xmm3
00007026095d823f  vmovaps [rsp+0x40], xmm4
00007026095d8245  vmovaps [rsp+0x50], xmm6
00007026095d824b  vmovaps [rsp+0x60], xmm7
00007026095d8251  vmovaps [rsp+0x70], xmm8
00007026095d8257  vmovaps [rsp+0x80], xmm9
00007026095d8260  vmovaps [rsp+0x90], xmm10
00007026095d8269  vmovaps [rsp+0xA0], xmm11
00007026095d8272  vmovaps [rsp+0xB0], xmm12
00007026095d827b  vmovaps [rsp+0xC0], xmm13
00007026095d8284  vmovaps [rsp+0xD0], xmm14
00007026095d828d  vmovaps [rsp+0xE0], xmm15
00007026095d8296  sub rsp, 0x40
00007026095d829a  lea rdi, [rsp]
00007026095d829e  lea rsi, [rsp+0x10]
00007026095d82a3  lea rdx, [rsp+0x20]
00007026095d82a8  lea rcx, [rsp+0x30]
00007026095d82ad  mov r8d, 0x00
00007026095d82b3  lea r9, [r15+0x3A8]
00007026095d82ba  movaps [rdi], xmm5
00007026095d82bd  movaps [rsi], xmm14
00007026095d82c1  movaps [rdx], xmm8
00007026095d82c5  movaps [rcx], xmm1
00007026095d82c8  mov rax, 0x58A432239A50
00007026095d82d2  call rax
00007026095d82d4  movaps xmm5, [rsp]
00007026095d82d8  add rsp, 0x40
00007026095d82dc  vmovaps xmm0, [rsp]
00007026095d82e1  vmovaps xmm1, [rsp+0x10]
00007026095d82e7  vmovaps xmm2, [rsp+0x20]
00007026095d82ed  vmovaps xmm3, [rsp+0x30]
00007026095d82f3  vmovaps xmm4, [rsp+0x40]
00007026095d82f9  vmovaps xmm6, [rsp+0x50]
00007026095d82ff  vmovaps xmm7, [rsp+0x60]
00007026095d8305  vmovaps xmm8, [rsp+0x70]
00007026095d830b  vmovaps xmm9, [rsp+0x80]
00007026095d8314  vmovaps xmm10, [rsp+0x90]
00007026095d831d  vmovaps xmm11, [rsp+0xA0]
00007026095d8326  vmovaps xmm12, [rsp+0xB0]
00007026095d832f  vmovaps xmm13, [rsp+0xC0]
00007026095d8338  vmovaps xmm14, [rsp+0xD0]
00007026095d8341  vmovaps xmm15, [rsp+0xE0]
00007026095d834a  add rsp, 0xF0
00007026095d8351  pop r11
00007026095d8353  pop r10
00007026095d8355  pop r9
00007026095d8357  pop r8
00007026095d8359  pop rsi
00007026095d835a  pop rdi
00007026095d835b  pop rdx
00007026095d835c  pop rcx
00007026095d835d  pop rax
00007026095d835e  add rsp, 0x08
00007026095d8362  jmp 0x00007026095D7034
00007026095d8367  sub rsp, 0x08
00007026095d836b  push rax
00007026095d836c  push rcx
00007026095d836d  push rdx
00007026095d836e  push rdi
00007026095d836f  push rsi
00007026095d8370  push r8
00007026095d8372  push r9
00007026095d8374  push r10
00007026095d8376  push r11
00007026095d8378  sub rsp, 0xF0
00007026095d837f  vmovaps [rsp], xmm0
00007026095d8384  vmovaps [rsp+0x10], xmm1
00007026095d838a  vmovaps [rsp+0x20], xmm2
00007026095d8390  vmovaps [rsp+0x30], xmm3
00007026095d8396  vmovaps [rsp+0x40], xmm4
00007026095d839c  vmovaps [rsp+0x50], xmm5
00007026095d83a2  vmovaps [rsp+0x60], xmm6
00007026095d83a8  vmovaps [rsp+0x70], xmm7
00007026095d83ae  vmovaps [rsp+0x80], xmm8
00007026095d83b7  vmovaps [rsp+0x90], xmm9
00007026095d83c0  vmovaps [rsp+0xA0], xmm10
00007026095d83c9  vmovaps [rsp+0xB0], xmm11
00007026095d83d2  vmovaps [rsp+0xC0], xmm12
00007026095d83db  vmovaps [rsp+0xD0], xmm13
00007026095d83e4  vmovaps [rsp+0xE0], xmm14
00007026095d83ed  sub rsp, 0x40
00007026095d83f1  lea rdi, [rsp]
00007026095d83f5  lea rsi, [rsp+0x10]
00007026095d83fa  lea rdx, [rsp+0x20]
00007026095d83ff  lea rcx, [rsp+0x30]
00007026095d8404  mov r8d, 0x00
00007026095d840a  lea r9, [r15+0x3A8]
00007026095d8411  movaps [rdi], xmm15
00007026095d8415  movaps [rsi], xmm13
00007026095d8419  movaps [rdx], xmm14
00007026095d841d  movaps [rcx], xmm1
00007026095d8420  mov rax, 0x58A432239A50
00007026095d842a  call rax
00007026095d842c  movaps xmm15, [rsp]
00007026095d8431  add rsp, 0x40
00007026095d8435  vmovaps xmm0, [rsp]
00007026095d843a  vmovaps xmm1, [rsp+0x10]
00007026095d8440  vmovaps xmm2, [rsp+0x20]
00007026095d8446  vmovaps xmm3, [rsp+0x30]
00007026095d844c  vmovaps xmm4, [rsp+0x40]
00007026095d8452  vmovaps xmm5, [rsp+0x50]
00007026095d8458  vmovaps xmm6, [rsp+0x60]
00007026095d845e  vmovaps xmm7, [rsp+0x70]
00007026095d8464  vmovaps xmm8, [rsp+0x80]
00007026095d846d  vmovaps xmm9, [rsp+0x90]
00007026095d8476  vmovaps xmm10, [rsp+0xA0]
00007026095d847f  vmovaps xmm11, [rsp+0xB0]
00007026095d8488  vmovaps xmm12, [rsp+0xC0]
00007026095d8491  vmovaps xmm13, [rsp+0xD0]
00007026095d849a  vmovaps xmm14, [rsp+0xE0]
00007026095d84a3  add rsp, 0xF0
00007026095d84aa  pop r11
00007026095d84ac  pop r10
00007026095d84ae  pop r9
00007026095d84b0  pop r8
00007026095d84b2  pop rsi
00007026095d84b3  pop rdi
00007026095d84b4  pop rdx
00007026095d84b5  pop rcx
00007026095d84b6  pop rax
00007026095d84b7  add rsp, 0x08
00007026095d84bb  jmp 0x00007026095D7063
00007026095d84c0  sub rsp, 0x08
00007026095d84c4  push rax
00007026095d84c5  push rcx
00007026095d84c6  push rdx
00007026095d84c7  push rdi
00007026095d84c8  push rsi
00007026095d84c9  push r8
00007026095d84cb  push r9
00007026095d84cd  push r10
00007026095d84cf  push r11
00007026095d84d1  sub rsp, 0xF0
00007026095d84d8  vmovaps [rsp], xmm0
00007026095d84dd  vmovaps [rsp+0x10], xmm1
00007026095d84e3  vmovaps [rsp+0x20], xmm2
00007026095d84e9  vmovaps [rsp+0x30], xmm3
00007026095d84ef  vmovaps [rsp+0x40], xmm4
00007026095d84f5  vmovaps [rsp+0x50], xmm5
00007026095d84fb  vmovaps [rsp+0x60], xmm6
00007026095d8501  vmovaps [rsp+0x70], xmm7
00007026095d8507  vmovaps [rsp+0x80], xmm8
00007026095d8510  vmovaps [rsp+0x90], xmm9
00007026095d8519  vmovaps [rsp+0xA0], xmm10
00007026095d8522  vmovaps [rsp+0xB0], xmm11
00007026095d852b  vmovaps [rsp+0xC0], xmm12
00007026095d8534  vmovaps [rsp+0xD0], xmm14
00007026095d853d  vmovaps [rsp+0xE0], xmm15
00007026095d8546  sub rsp, 0x40
00007026095d854a  lea rdi, [rsp]
00007026095d854e  lea rsi, [rsp+0x10]
00007026095d8553  lea rdx, [rsp+0x20]
00007026095d8558  lea rcx, [rsp+0x30]
00007026095d855d  mov r8d, 0x00
00007026095d8563  lea r9, [r15+0x3A8]
00007026095d856a  movaps [rdi], xmm13
00007026095d856e  movaps [rsi], xmm12
00007026095d8572  movaps [rdx], xmm14
00007026095d8576  movaps [rcx], xmm1
00007026095d8579  mov rax, 0x58A432239A50
00007026095d8583  call rax
00007026095d8585  movaps xmm13, [rsp]
00007026095d858a  add rsp, 0x40
00007026095d858e  vmovaps xmm0, [rsp]
00007026095d8593  vmovaps xmm1, [rsp+0x10]
00007026095d8599  vmovaps xmm2, [rsp+0x20]
00007026095d859f  vmovaps xmm3, [rsp+0x30]
00007026095d85a5  vmovaps xmm4, [rsp+0x40]
00007026095d85ab  vmovaps xmm5, [rsp+0x50]
00007026095d85b1  vmovaps xmm6, [rsp+0x60]
00007026095d85b7  vmovaps xmm7, [rsp+0x70]
00007026095d85bd  vmovaps xmm8, [rsp+0x80]
00007026095d85c6  vmovaps xmm9, [rsp+0x90]
00007026095d85cf  vmovaps xmm10, [rsp+0xA0]
00007026095d85d8  vmovaps xmm11, [rsp+0xB0]
00007026095d85e1  vmovaps xmm12, [rsp+0xC0]
00007026095d85ea  vmovaps xmm14, [rsp+0xD0]
00007026095d85f3  vmovaps xmm15, [rsp+0xE0]
00007026095d85fc  add rsp, 0xF0
00007026095d8603  pop r11
00007026095d8605  pop r10
00007026095d8607  pop r9
00007026095d8609  pop r8
00007026095d860b  pop rsi
00007026095d860c  pop rdi
00007026095d860d  pop rdx
00007026095d860e  pop rcx
00007026095d860f  pop rax
00007026095d8610  add rsp, 0x08
00007026095d8614  jmp 0x00007026095D7095
00007026095d8619  sub rsp, 0x08
00007026095d861d  push rax
00007026095d861e  push rcx
00007026095d861f  push rdx
00007026095d8620  push rdi
00007026095d8621  push rsi
00007026095d8622  push r8
00007026095d8624  push r9
00007026095d8626  push r10
00007026095d8628  push r11
00007026095d862a  sub rsp, 0xF0
00007026095d8631  vmovaps [rsp], xmm0
00007026095d8636  vmovaps [rsp+0x10], xmm1
00007026095d863c  vmovaps [rsp+0x20], xmm2
00007026095d8642  vmovaps [rsp+0x30], xmm3
00007026095d8648  vmovaps [rsp+0x40], xmm4
00007026095d864e  vmovaps [rsp+0x50], xmm5
00007026095d8654  vmovaps [rsp+0x60], xmm6
00007026095d865a  vmovaps [rsp+0x70], xmm7
00007026095d8660  vmovaps [rsp+0x80], xmm8
00007026095d8669  vmovaps [rsp+0x90], xmm9
00007026095d8672  vmovaps [rsp+0xA0], xmm10
00007026095d867b  vmovaps [rsp+0xB0], xmm11
00007026095d8684  vmovaps [rsp+0xC0], xmm13
00007026095d868d  vmovaps [rsp+0xD0], xmm14
00007026095d8696  vmovaps [rsp+0xE0], xmm15
00007026095d869f  sub rsp, 0x40
00007026095d86a3  lea rdi, [rsp]
00007026095d86a7  lea rsi, [rsp+0x10]
00007026095d86ac  lea rdx, [rsp+0x20]
00007026095d86b1  lea rcx, [rsp+0x30]
00007026095d86b6  mov r8d, 0x00
00007026095d86bc  lea r9, [r15+0x3A8]
00007026095d86c3  movaps [rdi], xmm12
00007026095d86c7  movaps [rsi], xmm5
00007026095d86ca  movaps [rdx], xmm14
00007026095d86ce  movaps [rcx], xmm4
00007026095d86d1  mov rax, 0x58A432239A50
00007026095d86db  call rax
00007026095d86dd  movaps xmm12, [rsp]
00007026095d86e2  add rsp, 0x40
00007026095d86e6  vmovaps xmm0, [rsp]
00007026095d86eb  vmovaps xmm1, [rsp+0x10]
00007026095d86f1  vmovaps xmm2, [rsp+0x20]
00007026095d86f7  vmovaps xmm3, [rsp+0x30]
00007026095d86fd  vmovaps xmm4, [rsp+0x40]
00007026095d8703  vmovaps xmm5, [rsp+0x50]
00007026095d8709  vmovaps xmm6, [rsp+0x60]
00007026095d870f  vmovaps xmm7, [rsp+0x70]
00007026095d8715  vmovaps xmm8, [rsp+0x80]
00007026095d871e  vmovaps xmm9, [rsp+0x90]
00007026095d8727  vmovaps xmm10, [rsp+0xA0]
00007026095d8730  vmovaps xmm11, [rsp+0xB0]
00007026095d8739  vmovaps xmm13, [rsp+0xC0]
00007026095d8742  vmovaps xmm14, [rsp+0xD0]
00007026095d874b  vmovaps xmm15, [rsp+0xE0]
00007026095d8754  add rsp, 0xF0
00007026095d875b  pop r11
00007026095d875d  pop r10
00007026095d875f  pop r9
00007026095d8761  pop r8
00007026095d8763  pop rsi
00007026095d8764  pop rdi
00007026095d8765  pop rdx
00007026095d8766  pop rcx
00007026095d8767  pop rax
00007026095d8768  add rsp, 0x08
00007026095d876c  jmp 0x00007026095D710B
00007026095d8771  sub rsp, 0x08
00007026095d8775  push rax
00007026095d8776  push rcx
00007026095d8777  push rdx
00007026095d8778  push rdi
00007026095d8779  push rsi
00007026095d877a  push r8
00007026095d877c  push r9
00007026095d877e  push r10
00007026095d8780  push r11
00007026095d8782  sub rsp, 0xF0
00007026095d8789  vmovaps [rsp], xmm0
00007026095d878e  vmovaps [rsp+0x10], xmm1
00007026095d8794  vmovaps [rsp+0x20], xmm2
00007026095d879a  vmovaps [rsp+0x30], xmm3
00007026095d87a0  vmovaps [rsp+0x40], xmm4
00007026095d87a6  vmovaps [rsp+0x50], xmm5
00007026095d87ac  vmovaps [rsp+0x60], xmm6
00007026095d87b2  vmovaps [rsp+0x70], xmm7
00007026095d87b8  vmovaps [rsp+0x80], xmm8
00007026095d87c1  vmovaps [rsp+0x90], xmm9
00007026095d87ca  vmovaps [rsp+0xA0], xmm11
00007026095d87d3  vmovaps [rsp+0xB0], xmm12
00007026095d87dc  vmovaps [rsp+0xC0], xmm13
00007026095d87e5  vmovaps [rsp+0xD0], xmm14
00007026095d87ee  vmovaps [rsp+0xE0], xmm15
00007026095d87f7  sub rsp, 0x40
00007026095d87fb  lea rdi, [rsp]
00007026095d87ff  lea rsi, [rsp+0x10]
00007026095d8804  lea rdx, [rsp+0x20]
00007026095d8809  lea rcx, [rsp+0x30]
00007026095d880e  mov r8d, 0x00
00007026095d8814  lea r9, [r15+0x3A8]
00007026095d881b  movaps [rdi], xmm10
00007026095d881f  movaps [rsi], xmm2
00007026095d8822  movaps [rdx], xmm6
00007026095d8825  movaps [rcx], xmm14
00007026095d8829  mov rax, 0x58A432239A50
00007026095d8833  call rax
00007026095d8835  movaps xmm10, [rsp]
00007026095d883a  add rsp, 0x40
00007026095d883e  vmovaps xmm0, [rsp]
00007026095d8843  vmovaps xmm1, [rsp+0x10]
00007026095d8849  vmovaps xmm2, [rsp+0x20]
00007026095d884f  vmovaps xmm3, [rsp+0x30]
00007026095d8855  vmovaps xmm4, [rsp+0x40]
00007026095d885b  vmovaps xmm5, [rsp+0x50]
00007026095d8861  vmovaps xmm6, [rsp+0x60]
00007026095d8867  vmovaps xmm7, [rsp+0x70]
00007026095d886d  vmovaps xmm8, [rsp+0x80]
00007026095d8876  vmovaps xmm9, [rsp+0x90]
00007026095d887f  vmovaps xmm11, [rsp+0xA0]
00007026095d8888  vmovaps xmm12, [rsp+0xB0]
00007026095d8891  vmovaps xmm13, [rsp+0xC0]
00007026095d889a  vmovaps xmm14, [rsp+0xD0]
00007026095d88a3  vmovaps xmm15, [rsp+0xE0]
00007026095d88ac  add rsp, 0xF0
00007026095d88b3  pop r11
00007026095d88b5  pop r10
00007026095d88b7  pop r9
00007026095d88b9  pop r8
00007026095d88bb  pop rsi
00007026095d88bc  pop rdi
00007026095d88bd  pop rdx
00007026095d88be  pop rcx
00007026095d88bf  pop rax
00007026095d88c0  add rsp, 0x08
00007026095d88c4  jmp 0x00007026095D7131
00007026095d88c9  call 0x000070260940D4E0
00007026095d88ce  jmp 0x00007026095D713E
00007026095d88d3  sub rsp, 0x08
00007026095d88d7  push rax
00007026095d88d8  push rcx
00007026095d88d9  push rdx
00007026095d88da  push rdi
00007026095d88db  push rsi
00007026095d88dc  push r8
00007026095d88de  push r9
00007026095d88e0  push r10
00007026095d88e2  push r11
00007026095d88e4  sub rsp, 0xF0
00007026095d88eb  vmovaps [rsp], xmm0
00007026095d88f0  vmovaps [rsp+0x10], xmm1
00007026095d88f6  vmovaps [rsp+0x20], xmm2
00007026095d88fc  vmovaps [rsp+0x30], xmm3
00007026095d8902  vmovaps [rsp+0x40], xmm4
00007026095d8908  vmovaps [rsp+0x50], xmm6
00007026095d890e  vmovaps [rsp+0x60], xmm7
00007026095d8914  vmovaps [rsp+0x70], xmm8
00007026095d891a  vmovaps [rsp+0x80], xmm9
00007026095d8923  vmovaps [rsp+0x90], xmm10
00007026095d892c  vmovaps [rsp+0xA0], xmm11
00007026095d8935  vmovaps [rsp+0xB0], xmm12
00007026095d893e  vmovaps [rsp+0xC0], xmm13
00007026095d8947  vmovaps [rsp+0xD0], xmm14
00007026095d8950  vmovaps [rsp+0xE0], xmm15
00007026095d8959  sub rsp, 0x40
00007026095d895d  lea rdi, [rsp]
00007026095d8961  lea rsi, [rsp+0x10]
00007026095d8966  lea rdx, [rsp+0x20]
00007026095d896b  lea rcx, [rsp+0x30]
00007026095d8970  mov r8d, 0x00
00007026095d8976  lea r9, [r15+0x3A8]
00007026095d897d  movaps [rdi], xmm5
00007026095d8980  movaps [rsi], xmm15
00007026095d8984  movaps [rdx], xmm6
00007026095d8987  movaps [rcx], xmm8
00007026095d898b  mov rax, 0x58A432239A50
00007026095d8995  call rax
00007026095d8997  movaps xmm5, [rsp]
00007026095d899b  add rsp, 0x40
00007026095d899f  vmovaps xmm0, [rsp]
00007026095d89a4  vmovaps xmm1, [rsp+0x10]
00007026095d89aa  vmovaps xmm2, [rsp+0x20]
00007026095d89b0  vmovaps xmm3, [rsp+0x30]
00007026095d89b6  vmovaps xmm4, [rsp+0x40]
00007026095d89bc  vmovaps xmm6, [rsp+0x50]
00007026095d89c2  vmovaps xmm7, [rsp+0x60]
00007026095d89c8  vmovaps xmm8, [rsp+0x70]
00007026095d89ce  vmovaps xmm9, [rsp+0x80]
00007026095d89d7  vmovaps xmm10, [rsp+0x90]
00007026095d89e0  vmovaps xmm11, [rsp+0xA0]
00007026095d89e9  vmovaps xmm12, [rsp+0xB0]
00007026095d89f2  vmovaps xmm13, [rsp+0xC0]
00007026095d89fb  vmovaps xmm14, [rsp+0xD0]
00007026095d8a04  vmovaps xmm15, [rsp+0xE0]
00007026095d8a0d  add rsp, 0xF0
00007026095d8a14  pop r11
00007026095d8a16  pop r10
00007026095d8a18  pop r9
00007026095d8a1a  pop r8
00007026095d8a1c  pop rsi
00007026095d8a1d  pop rdi
00007026095d8a1e  pop rdx
00007026095d8a1f  pop rcx
00007026095d8a20  pop rax
00007026095d8a21  add rsp, 0x08
00007026095d8a25  jmp 0x00007026095D7174
00007026095d8a2a  sub rsp, 0x08
00007026095d8a2e  push rax
00007026095d8a2f  push rcx
00007026095d8a30  push rdx
00007026095d8a31  push rdi
00007026095d8a32  push rsi
00007026095d8a33  push r8
00007026095d8a35  push r9
00007026095d8a37  push r10
00007026095d8a39  push r11
00007026095d8a3b  sub rsp, 0xF0
00007026095d8a42  vmovaps [rsp], xmm0
00007026095d8a47  vmovaps [rsp+0x10], xmm1
00007026095d8a4d  vmovaps [rsp+0x20], xmm2
00007026095d8a53  vmovaps [rsp+0x30], xmm3
00007026095d8a59  vmovaps [rsp+0x40], xmm4
00007026095d8a5f  vmovaps [rsp+0x50], xmm5
00007026095d8a65  vmovaps [rsp+0x60], xmm6
00007026095d8a6b  vmovaps [rsp+0x70], xmm7
00007026095d8a71  vmovaps [rsp+0x80], xmm9
00007026095d8a7a  vmovaps [rsp+0x90], xmm10
00007026095d8a83  vmovaps [rsp+0xA0], xmm11
00007026095d8a8c  vmovaps [rsp+0xB0], xmm12
00007026095d8a95  vmovaps [rsp+0xC0], xmm13
00007026095d8a9e  vmovaps [rsp+0xD0], xmm14
00007026095d8aa7  vmovaps [rsp+0xE0], xmm15
00007026095d8ab0  sub rsp, 0x40
00007026095d8ab4  lea rdi, [rsp]
00007026095d8ab8  lea rsi, [rsp+0x10]
00007026095d8abd  lea rdx, [rsp+0x20]
00007026095d8ac2  lea rcx, [rsp+0x30]
00007026095d8ac7  mov r8d, 0x00
00007026095d8acd  lea r9, [r15+0x3A8]
00007026095d8ad4  movaps [rdi], xmm8
00007026095d8ad8  movaps [rsi], xmm13
00007026095d8adc  movaps [rdx], xmm1
00007026095d8adf  movaps [rcx], xmm15
00007026095d8ae3  mov rax, 0x58A432239A50
00007026095d8aed  call rax
00007026095d8aef  movaps xmm8, [rsp]
00007026095d8af4  add rsp, 0x40
00007026095d8af8  vmovaps xmm0, [rsp]
00007026095d8afd  vmovaps xmm1, [rsp+0x10]
00007026095d8b03  vmovaps xmm2, [rsp+0x20]
00007026095d8b09  vmovaps xmm3, [rsp+0x30]
00007026095d8b0f  vmovaps xmm4, [rsp+0x40]
00007026095d8b15  vmovaps xmm5, [rsp+0x50]
00007026095d8b1b  vmovaps xmm6, [rsp+0x60]
00007026095d8b21  vmovaps xmm7, [rsp+0x70]
00007026095d8b27  vmovaps xmm9, [rsp+0x80]
00007026095d8b30  vmovaps xmm10, [rsp+0x90]
00007026095d8b39  vmovaps xmm11, [rsp+0xA0]
00007026095d8b42  vmovaps xmm12, [rsp+0xB0]
00007026095d8b4b  vmovaps xmm13, [rsp+0xC0]
00007026095d8b54  vmovaps xmm14, [rsp+0xD0]
00007026095d8b5d  vmovaps xmm15, [rsp+0xE0]
00007026095d8b66  add rsp, 0xF0
00007026095d8b6d  pop r11
00007026095d8b6f  pop r10
00007026095d8b71  pop r9
00007026095d8b73  pop r8
00007026095d8b75  pop rsi
00007026095d8b76  pop rdi
00007026095d8b77  pop rdx
00007026095d8b78  pop rcx
00007026095d8b79  pop rax
00007026095d8b7a  add rsp, 0x08
00007026095d8b7e  jmp 0x00007026095D719A
00007026095d8b83  call 0x000070260940E760
00007026095d8b88  jmp 0x00007026095D71BD
00007026095d8b8d  call 0x000070260940C260
00007026095d8b92  jmp 0x00007026095D71C7
00007026095d8b97  sub rsp, 0x08
00007026095d8b9b  push rax
00007026095d8b9c  push rcx
00007026095d8b9d  push rdx
00007026095d8b9e  push rdi
00007026095d8b9f  push rsi
00007026095d8ba0  push r8
00007026095d8ba2  push r9
00007026095d8ba4  push r10
00007026095d8ba6  push r11
00007026095d8ba8  sub rsp, 0xF0
00007026095d8baf  vmovaps [rsp], xmm0
00007026095d8bb4  vmovaps [rsp+0x10], xmm1
00007026095d8bba  vmovaps [rsp+0x20], xmm2
00007026095d8bc0  vmovaps [rsp+0x30], xmm3
00007026095d8bc6  vmovaps [rsp+0x40], xmm5
00007026095d8bcc  vmovaps [rsp+0x50], xmm6
00007026095d8bd2  vmovaps [rsp+0x60], xmm7
00007026095d8bd8  vmovaps [rsp+0x70], xmm8
00007026095d8bde  vmovaps [rsp+0x80], xmm9
00007026095d8be7  vmovaps [rsp+0x90], xmm10
00007026095d8bf0  vmovaps [rsp+0xA0], xmm11
00007026095d8bf9  vmovaps [rsp+0xB0], xmm12
00007026095d8c02  vmovaps [rsp+0xC0], xmm13
00007026095d8c0b  vmovaps [rsp+0xD0], xmm14
00007026095d8c14  vmovaps [rsp+0xE0], xmm15
00007026095d8c1d  sub rsp, 0x40
00007026095d8c21  lea rdi, [rsp]
00007026095d8c25  lea rsi, [rsp+0x10]
00007026095d8c2a  lea rdx, [rsp+0x20]
00007026095d8c2f  lea rcx, [rsp+0x30]
00007026095d8c34  mov r8d, 0x00
00007026095d8c3a  lea r9, [r15+0x3A8]
00007026095d8c41  movaps [rdi], xmm4
00007026095d8c44  movaps [rsi], xmm12
00007026095d8c48  movaps [rdx], xmm9
00007026095d8c4c  movaps [rcx], xmm6
00007026095d8c4f  mov rax, 0x58A432239A50
00007026095d8c59  call rax
00007026095d8c5b  movaps xmm4, [rsp]
00007026095d8c5f  add rsp, 0x40
00007026095d8c63  vmovaps xmm0, [rsp]
00007026095d8c68  vmovaps xmm1, [rsp+0x10]
00007026095d8c6e  vmovaps xmm2, [rsp+0x20]
00007026095d8c74  vmovaps xmm3, [rsp+0x30]
00007026095d8c7a  vmovaps xmm5, [rsp+0x40]
00007026095d8c80  vmovaps xmm6, [rsp+0x50]
00007026095d8c86  vmovaps xmm7, [rsp+0x60]
00007026095d8c8c  vmovaps xmm8, [rsp+0x70]
00007026095d8c92  vmovaps xmm9, [rsp+0x80]
00007026095d8c9b  vmovaps xmm10, [rsp+0x90]
00007026095d8ca4  vmovaps xmm11, [rsp+0xA0]
00007026095d8cad  vmovaps xmm12, [rsp+0xB0]
00007026095d8cb6  vmovaps xmm13, [rsp+0xC0]
00007026095d8cbf  vmovaps xmm14, [rsp+0xD0]
00007026095d8cc8  vmovaps xmm15, [rsp+0xE0]
00007026095d8cd1  add rsp, 0xF0
00007026095d8cd8  pop r11
00007026095d8cda  pop r10
00007026095d8cdc  pop r9
00007026095d8cde  pop r8
00007026095d8ce0  pop rsi
00007026095d8ce1  pop rdi
00007026095d8ce2  pop rdx
00007026095d8ce3  pop rcx
00007026095d8ce4  pop rax
00007026095d8ce5  add rsp, 0x08
00007026095d8ce9  jmp 0x00007026095D71FF
00007026095d8cee  sub rsp, 0x08
00007026095d8cf2  push rax
00007026095d8cf3  push rcx
00007026095d8cf4  push rdx
00007026095d8cf5  push rdi
00007026095d8cf6  push rsi
00007026095d8cf7  push r8
00007026095d8cf9  push r9
00007026095d8cfb  push r10
00007026095d8cfd  push r11
00007026095d8cff  sub rsp, 0xF0
00007026095d8d06  vmovaps [rsp], xmm0
00007026095d8d0b  vmovaps [rsp+0x10], xmm1
00007026095d8d11  vmovaps [rsp+0x20], xmm2
00007026095d8d17  vmovaps [rsp+0x30], xmm3
00007026095d8d1d  vmovaps [rsp+0x40], xmm4
00007026095d8d23  vmovaps [rsp+0x50], xmm5
00007026095d8d29  vmovaps [rsp+0x60], xmm6
00007026095d8d2f  vmovaps [rsp+0x70], xmm7
00007026095d8d35  vmovaps [rsp+0x80], xmm8
00007026095d8d3e  vmovaps [rsp+0x90], xmm10
00007026095d8d47  vmovaps [rsp+0xA0], xmm11
00007026095d8d50  vmovaps [rsp+0xB0], xmm12
00007026095d8d59  vmovaps [rsp+0xC0], xmm13
00007026095d8d62  vmovaps [rsp+0xD0], xmm14
00007026095d8d6b  vmovaps [rsp+0xE0], xmm15
00007026095d8d74  sub rsp, 0x40
00007026095d8d78  lea rdi, [rsp]
00007026095d8d7c  lea rsi, [rsp+0x10]
00007026095d8d81  lea rdx, [rsp+0x20]
00007026095d8d86  lea rcx, [rsp+0x30]
00007026095d8d8b  mov r8d, 0x00
00007026095d8d91  lea r9, [r15+0x3A8]
00007026095d8d98  movaps [rdi], xmm9
00007026095d8d9c  movaps [rsi], xmm10
00007026095d8da0  movaps [rdx], xmm1
00007026095d8da3  movaps [rcx], xmm12
00007026095d8da7  mov rax, 0x58A432239A50
00007026095d8db1  call rax
00007026095d8db3  movaps xmm9, [rsp]
00007026095d8db8  add rsp, 0x40
00007026095d8dbc  vmovaps xmm0, [rsp]
00007026095d8dc1  vmovaps xmm1, [rsp+0x10]
00007026095d8dc7  vmovaps xmm2, [rsp+0x20]
00007026095d8dcd  vmovaps xmm3, [rsp+0x30]
00007026095d8dd3  vmovaps xmm4, [rsp+0x40]
00007026095d8dd9  vmovaps xmm5, [rsp+0x50]
00007026095d8ddf  vmovaps xmm6, [rsp+0x60]
00007026095d8de5  vmovaps xmm7, [rsp+0x70]
00007026095d8deb  vmovaps xmm8, [rsp+0x80]
00007026095d8df4  vmovaps xmm10, [rsp+0x90]
00007026095d8dfd  vmovaps xmm11, [rsp+0xA0]
00007026095d8e06  vmovaps xmm12, [rsp+0xB0]
00007026095d8e0f  vmovaps xmm13, [rsp+0xC0]
00007026095d8e18  vmovaps xmm14, [rsp+0xD0]
00007026095d8e21  vmovaps xmm15, [rsp+0xE0]
00007026095d8e2a  add rsp, 0xF0
00007026095d8e31  pop r11
00007026095d8e33  pop r10
00007026095d8e35  pop r9
00007026095d8e37  pop r8
00007026095d8e39  pop rsi
00007026095d8e3a  pop rdi
00007026095d8e3b  pop rdx
00007026095d8e3c  pop rcx
00007026095d8e3d  pop rax
00007026095d8e3e  add rsp, 0x08
00007026095d8e42  jmp 0x00007026095D7228
00007026095d8e47  sub rsp, 0x08
00007026095d8e4b  push rax
00007026095d8e4c  push rcx
00007026095d8e4d  push rdx
00007026095d8e4e  push rdi
00007026095d8e4f  push rsi
00007026095d8e50  push r8
00007026095d8e52  push r9
00007026095d8e54  push r10
00007026095d8e56  push r11
00007026095d8e58  sub rsp, 0xF0
00007026095d8e5f  vmovaps [rsp], xmm0
00007026095d8e64  vmovaps [rsp+0x10], xmm1
00007026095d8e6a  vmovaps [rsp+0x20], xmm2
00007026095d8e70  vmovaps [rsp+0x30], xmm3
00007026095d8e76  vmovaps [rsp+0x40], xmm4
00007026095d8e7c  vmovaps [rsp+0x50], xmm5
00007026095d8e82  vmovaps [rsp+0x60], xmm6
00007026095d8e88  vmovaps [rsp+0x70], xmm7
00007026095d8e8e  vmovaps [rsp+0x80], xmm8
00007026095d8e97  vmovaps [rsp+0x90], xmm9
00007026095d8ea0  vmovaps [rsp+0xA0], xmm11
00007026095d8ea9  vmovaps [rsp+0xB0], xmm12
00007026095d8eb2  vmovaps [rsp+0xC0], xmm13
00007026095d8ebb  vmovaps [rsp+0xD0], xmm14
00007026095d8ec4  vmovaps [rsp+0xE0], xmm15
00007026095d8ecd  sub rsp, 0x40
00007026095d8ed1  lea rdi, [rsp]
00007026095d8ed5  lea rsi, [rsp+0x10]
00007026095d8eda  lea rdx, [rsp+0x20]
00007026095d8edf  lea rcx, [rsp+0x30]
00007026095d8ee4  mov r8d, 0x00
00007026095d8eea  lea r9, [r15+0x3A8]
00007026095d8ef1  movaps [rdi], xmm10
00007026095d8ef5  movaps [rsi], xmm5
00007026095d8ef8  movaps [rdx], xmm12
00007026095d8efc  movaps [rcx], xmm1
00007026095d8eff  mov rax, 0x58A432239A50
00007026095d8f09  call rax
00007026095d8f0b  movaps xmm10, [rsp]
00007026095d8f10  add rsp, 0x40
00007026095d8f14  vmovaps xmm0, [rsp]
00007026095d8f19  vmovaps xmm1, [rsp+0x10]
00007026095d8f1f  vmovaps xmm2, [rsp+0x20]
00007026095d8f25  vmovaps xmm3, [rsp+0x30]
00007026095d8f2b  vmovaps xmm4, [rsp+0x40]
00007026095d8f31  vmovaps xmm5, [rsp+0x50]
00007026095d8f37  vmovaps xmm6, [rsp+0x60]
00007026095d8f3d  vmovaps xmm7, [rsp+0x70]
00007026095d8f43  vmovaps xmm8, [rsp+0x80]
00007026095d8f4c  vmovaps xmm9, [rsp+0x90]
00007026095d8f55  vmovaps xmm11, [rsp+0xA0]
00007026095d8f5e  vmovaps xmm12, [rsp+0xB0]
00007026095d8f67  vmovaps xmm13, [rsp+0xC0]
00007026095d8f70  vmovaps xmm14, [rsp+0xD0]
00007026095d8f79  vmovaps xmm15, [rsp+0xE0]
00007026095d8f82  add rsp, 0xF0
00007026095d8f89  pop r11
00007026095d8f8b  pop r10
00007026095d8f8d  pop r9
00007026095d8f8f  pop r8
00007026095d8f91  pop rsi
00007026095d8f92  pop rdi
00007026095d8f93  pop rdx
00007026095d8f94  pop rcx
00007026095d8f95  pop rax
00007026095d8f96  add rsp, 0x08
00007026095d8f9a  jmp 0x00007026095D7257
00007026095d8f9f  sub rsp, 0x08
00007026095d8fa3  push rax
00007026095d8fa4  push rcx
00007026095d8fa5  push rdx
00007026095d8fa6  push rdi
00007026095d8fa7  push rsi
00007026095d8fa8  push r8
00007026095d8faa  push r9
00007026095d8fac  push r10
00007026095d8fae  push r11
00007026095d8fb0  sub rsp, 0xF0
00007026095d8fb7  vmovaps [rsp], xmm0
00007026095d8fbc  vmovaps [rsp+0x10], xmm1
00007026095d8fc2  vmovaps [rsp+0x20], xmm2
00007026095d8fc8  vmovaps [rsp+0x30], xmm3
00007026095d8fce  vmovaps [rsp+0x40], xmm4
00007026095d8fd4  vmovaps [rsp+0x50], xmm5
00007026095d8fda  vmovaps [rsp+0x60], xmm7
00007026095d8fe0  vmovaps [rsp+0x70], xmm8
00007026095d8fe6  vmovaps [rsp+0x80], xmm9
00007026095d8fef  vmovaps [rsp+0x90], xmm10
00007026095d8ff8  vmovaps [rsp+0xA0], xmm11
00007026095d9001  vmovaps [rsp+0xB0], xmm12
00007026095d900a  vmovaps [rsp+0xC0], xmm13
00007026095d9013  vmovaps [rsp+0xD0], xmm14
00007026095d901c  vmovaps [rsp+0xE0], xmm15
00007026095d9025  sub rsp, 0x40
00007026095d9029  lea rdi, [rsp]
00007026095d902d  lea rsi, [rsp+0x10]
00007026095d9032  lea rdx, [rsp+0x20]
00007026095d9037  lea rcx, [rsp+0x30]
00007026095d903c  mov r8d, 0x00
00007026095d9042  lea r9, [r15+0x3A8]
00007026095d9049  movaps [rdi], xmm6
00007026095d904c  movaps [rsi], xmm8
00007026095d9050  movaps [rdx], xmm12
00007026095d9054  movaps [rcx], xmm1
00007026095d9057  mov rax, 0x58A432239A50
00007026095d9061  call rax
00007026095d9063  movaps xmm6, [rsp]
00007026095d9067  add rsp, 0x40
00007026095d906b  vmovaps xmm0, [rsp]
00007026095d9070  vmovaps xmm1, [rsp+0x10]
00007026095d9076  vmovaps xmm2, [rsp+0x20]
00007026095d907c  vmovaps xmm3, [rsp+0x30]
00007026095d9082  vmovaps xmm4, [rsp+0x40]
00007026095d9088  vmovaps xmm5, [rsp+0x50]
00007026095d908e  vmovaps xmm7, [rsp+0x60]
00007026095d9094  vmovaps xmm8, [rsp+0x70]
00007026095d909a  vmovaps xmm9, [rsp+0x80]
00007026095d90a3  vmovaps xmm10, [rsp+0x90]
00007026095d90ac  vmovaps xmm11, [rsp+0xA0]
00007026095d90b5  vmovaps xmm12, [rsp+0xB0]
00007026095d90be  vmovaps xmm13, [rsp+0xC0]
00007026095d90c7  vmovaps xmm14, [rsp+0xD0]
00007026095d90d0  vmovaps xmm15, [rsp+0xE0]
00007026095d90d9  add rsp, 0xF0
00007026095d90e0  pop r11
00007026095d90e2  pop r10
00007026095d90e4  pop r9
00007026095d90e6  pop r8
00007026095d90e8  pop rsi
00007026095d90e9  pop rdi
00007026095d90ea  pop rdx
00007026095d90eb  pop rcx
00007026095d90ec  pop rax
00007026095d90ed  add rsp, 0x08
00007026095d90f1  jmp 0x00007026095D7285
00007026095d90f6  call 0x00007026093FF430
00007026095d90fb  jmp 0x00007026095D728F
00007026095d9100  call 0x000070260940AFE0
00007026095d9105  jmp 0x00007026095D7299
00007026095d910a  sub rsp, 0x08
00007026095d910e  push rax
00007026095d910f  push rcx
00007026095d9110  push rdx
00007026095d9111  push rdi
00007026095d9112  push rsi
00007026095d9113  push r8
00007026095d9115  push r9
00007026095d9117  push r10
00007026095d9119  push r11
00007026095d911b  sub rsp, 0xF0
00007026095d9122  vmovaps [rsp], xmm0
00007026095d9127  vmovaps [rsp+0x10], xmm1
00007026095d912d  vmovaps [rsp+0x20], xmm2
00007026095d9133  vmovaps [rsp+0x30], xmm3
00007026095d9139  vmovaps [rsp+0x40], xmm4
00007026095d913f  vmovaps [rsp+0x50], xmm5
00007026095d9145  vmovaps [rsp+0x60], xmm6
00007026095d914b  vmovaps [rsp+0x70], xmm7
00007026095d9151  vmovaps [rsp+0x80], xmm9
00007026095d915a  vmovaps [rsp+0x90], xmm10
00007026095d9163  vmovaps [rsp+0xA0], xmm11
00007026095d916c  vmovaps [rsp+0xB0], xmm12
00007026095d9175  vmovaps [rsp+0xC0], xmm13
00007026095d917e  vmovaps [rsp+0xD0], xmm14
00007026095d9187  vmovaps [rsp+0xE0], xmm15
00007026095d9190  sub rsp, 0x40
00007026095d9194  lea rdi, [rsp]
00007026095d9198  lea rsi, [rsp+0x10]
00007026095d919d  lea rdx, [rsp+0x20]
00007026095d91a2  lea rcx, [rsp+0x30]
00007026095d91a7  mov r8d, 0x00
00007026095d91ad  lea r9, [r15+0x3A8]
00007026095d91b4  movaps [rdi], xmm8
00007026095d91b8  movaps [rsi], xmm4
00007026095d91bb  movaps [rdx], xmm13
00007026095d91bf  movaps [rcx], xmm11
00007026095d91c3  mov rax, 0x58A432239A50
00007026095d91cd  call rax
00007026095d91cf  movaps xmm8, [rsp]
00007026095d91d4  add rsp, 0x40
00007026095d91d8  vmovaps xmm0, [rsp]
00007026095d91dd  vmovaps xmm1, [rsp+0x10]
00007026095d91e3  vmovaps xmm2, [rsp+0x20]
00007026095d91e9  vmovaps xmm3, [rsp+0x30]
00007026095d91ef  vmovaps xmm4, [rsp+0x40]
00007026095d91f5  vmovaps xmm5, [rsp+0x50]
00007026095d91fb  vmovaps xmm6, [rsp+0x60]
00007026095d9201  vmovaps xmm7, [rsp+0x70]
00007026095d9207  vmovaps xmm9, [rsp+0x80]
00007026095d9210  vmovaps xmm10, [rsp+0x90]
00007026095d9219  vmovaps xmm11, [rsp+0xA0]
00007026095d9222  vmovaps xmm12, [rsp+0xB0]
00007026095d922b  vmovaps xmm13, [rsp+0xC0]
00007026095d9234  vmovaps xmm14, [rsp+0xD0]
00007026095d923d  vmovaps xmm15, [rsp+0xE0]
00007026095d9246  add rsp, 0xF0
00007026095d924d  pop r11
00007026095d924f  pop r10
00007026095d9251  pop r9
00007026095d9253  pop r8
00007026095d9255  pop rsi
00007026095d9256  pop rdi
00007026095d9257  pop rdx
00007026095d9258  pop rcx
00007026095d9259  pop rax
00007026095d925a  add rsp, 0x08
00007026095d925e  jmp 0x00007026095D72CF
00007026095d9263  sub rsp, 0x08
00007026095d9267  push rax
00007026095d9268  push rcx
00007026095d9269  push rdx
00007026095d926a  push rdi
00007026095d926b  push rsi
00007026095d926c  push r8
00007026095d926e  push r9
00007026095d9270  push r10
00007026095d9272  push r11
00007026095d9274  sub rsp, 0xF0
00007026095d927b  vmovaps [rsp], xmm0
00007026095d9280  vmovaps [rsp+0x10], xmm1
00007026095d9286  vmovaps [rsp+0x20], xmm2
00007026095d928c  vmovaps [rsp+0x30], xmm3
00007026095d9292  vmovaps [rsp+0x40], xmm4
00007026095d9298  vmovaps [rsp+0x50], xmm5
00007026095d929e  vmovaps [rsp+0x60], xmm6
00007026095d92a4  vmovaps [rsp+0x70], xmm7
00007026095d92aa  vmovaps [rsp+0x80], xmm8
00007026095d92b3  vmovaps [rsp+0x90], xmm9
00007026095d92bc  vmovaps [rsp+0xA0], xmm10
00007026095d92c5  vmovaps [rsp+0xB0], xmm12
00007026095d92ce  vmovaps [rsp+0xC0], xmm13
00007026095d92d7  vmovaps [rsp+0xD0], xmm14
00007026095d92e0  vmovaps [rsp+0xE0], xmm15
00007026095d92e9  sub rsp, 0x40
00007026095d92ed  lea rdi, [rsp]
00007026095d92f1  lea rsi, [rsp+0x10]
00007026095d92f6  lea rdx, [rsp+0x20]
00007026095d92fb  lea rcx, [rsp+0x30]
00007026095d9300  mov r8d, 0x00
00007026095d9306  lea r9, [r15+0x3A8]
00007026095d930d  movaps [rdi], xmm11
00007026095d9311  movaps [rsi], xmm9
00007026095d9315  movaps [rdx], xmm1
00007026095d9318  movaps [rcx], xmm13
00007026095d931c  mov rax, 0x58A432239A50
00007026095d9326  call rax
00007026095d9328  movaps xmm11, [rsp]
00007026095d932d  add rsp, 0x40
00007026095d9331  vmovaps xmm0, [rsp]
00007026095d9336  vmovaps xmm1, [rsp+0x10]
00007026095d933c  vmovaps xmm2, [rsp+0x20]
00007026095d9342  vmovaps xmm3, [rsp+0x30]
00007026095d9348  vmovaps xmm4, [rsp+0x40]
00007026095d934e  vmovaps xmm5, [rsp+0x50]
00007026095d9354  vmovaps xmm6, [rsp+0x60]
00007026095d935a  vmovaps xmm7, [rsp+0x70]
00007026095d9360  vmovaps xmm8, [rsp+0x80]
00007026095d9369  vmovaps xmm9, [rsp+0x90]
00007026095d9372  vmovaps xmm10, [rsp+0xA0]
00007026095d937b  vmovaps xmm12, [rsp+0xB0]
00007026095d9384  vmovaps xmm13, [rsp+0xC0]
00007026095d938d  vmovaps xmm14, [rsp+0xD0]
00007026095d9396  vmovaps xmm15, [rsp+0xE0]
00007026095d939f  add rsp, 0xF0
00007026095d93a6  pop r11
00007026095d93a8  pop r10
00007026095d93aa  pop r9
00007026095d93ac  pop r8
00007026095d93ae  pop rsi
00007026095d93af  pop rdi
00007026095d93b0  pop rdx
00007026095d93b1  pop rcx
00007026095d93b2  pop rax
00007026095d93b3  add rsp, 0x08
00007026095d93b7  jmp 0x00007026095D72F5
00007026095d93bc  sub rsp, 0x08
00007026095d93c0  push rax
00007026095d93c1  push rcx
00007026095d93c2  push rdx
00007026095d93c3  push rdi
00007026095d93c4  push rsi
00007026095d93c5  push r8
00007026095d93c7  push r9
00007026095d93c9  push r10
00007026095d93cb  push r11
00007026095d93cd  sub rsp, 0xF0
00007026095d93d4  vmovaps [rsp], xmm0
00007026095d93d9  vmovaps [rsp+0x10], xmm1
00007026095d93df  vmovaps [rsp+0x20], xmm2
00007026095d93e5  vmovaps [rsp+0x30], xmm3
00007026095d93eb  vmovaps [rsp+0x40], xmm4
00007026095d93f1  vmovaps [rsp+0x50], xmm5
00007026095d93f7  vmovaps [rsp+0x60], xmm6
00007026095d93fd  vmovaps [rsp+0x70], xmm7
00007026095d9403  vmovaps [rsp+0x80], xmm8
00007026095d940c  vmovaps [rsp+0x90], xmm9
00007026095d9415  vmovaps [rsp+0xA0], xmm10
00007026095d941e  vmovaps [rsp+0xB0], xmm11
00007026095d9427  vmovaps [rsp+0xC0], xmm12
00007026095d9430  vmovaps [rsp+0xD0], xmm14
00007026095d9439  vmovaps [rsp+0xE0], xmm15
00007026095d9442  sub rsp, 0x40
00007026095d9446  lea rdi, [rsp]
00007026095d944a  lea rsi, [rsp+0x10]
00007026095d944f  lea rdx, [rsp+0x20]
00007026095d9454  lea rcx, [rsp+0x30]
00007026095d9459  mov r8d, 0x00
00007026095d945f  lea r9, [r15+0x3A8]
00007026095d9466  movaps [rdi], xmm13
00007026095d946a  movaps [rsi], xmm10
00007026095d946e  movaps [rdx], xmm7
00007026095d9471  movaps [rcx], xmm1
00007026095d9474  mov rax, 0x58A432239A50
00007026095d947e  call rax
00007026095d9480  movaps xmm13, [rsp]
00007026095d9485  add rsp, 0x40
00007026095d9489  vmovaps xmm0, [rsp]
00007026095d948e  vmovaps xmm1, [rsp+0x10]
00007026095d9494  vmovaps xmm2, [rsp+0x20]
00007026095d949a  vmovaps xmm3, [rsp+0x30]
00007026095d94a0  vmovaps xmm4, [rsp+0x40]
00007026095d94a6  vmovaps xmm5, [rsp+0x50]
00007026095d94ac  vmovaps xmm6, [rsp+0x60]
00007026095d94b2  vmovaps xmm7, [rsp+0x70]
00007026095d94b8  vmovaps xmm8, [rsp+0x80]
00007026095d94c1  vmovaps xmm9, [rsp+0x90]
00007026095d94ca  vmovaps xmm10, [rsp+0xA0]
00007026095d94d3  vmovaps xmm11, [rsp+0xB0]
00007026095d94dc  vmovaps xmm12, [rsp+0xC0]
00007026095d94e5  vmovaps xmm14, [rsp+0xD0]
00007026095d94ee  vmovaps xmm15, [rsp+0xE0]
00007026095d94f7  add rsp, 0xF0
00007026095d94fe  pop r11
00007026095d9500  pop r10
00007026095d9502  pop r9
00007026095d9504  pop r8
00007026095d9506  pop rsi
00007026095d9507  pop rdi
00007026095d9508  pop rdx
00007026095d9509  pop rcx
00007026095d950a  pop rax
00007026095d950b  add rsp, 0x08
00007026095d950f  jmp 0x00007026095D731B
00007026095d9514  sub rsp, 0x08
00007026095d9518  push rax
00007026095d9519  push rcx
00007026095d951a  push rdx
00007026095d951b  push rdi
00007026095d951c  push rsi
00007026095d951d  push r8
00007026095d951f  push r9
00007026095d9521  push r10
00007026095d9523  push r11
00007026095d9525  sub rsp, 0xF0
00007026095d952c  vmovaps [rsp], xmm0
00007026095d9531  vmovaps [rsp+0x10], xmm1
00007026095d9537  vmovaps [rsp+0x20], xmm2
00007026095d953d  vmovaps [rsp+0x30], xmm3
00007026095d9543  vmovaps [rsp+0x40], xmm4
00007026095d9549  vmovaps [rsp+0x50], xmm5
00007026095d954f  vmovaps [rsp+0x60], xmm6
00007026095d9555  vmovaps [rsp+0x70], xmm7
00007026095d955b  vmovaps [rsp+0x80], xmm8
00007026095d9564  vmovaps [rsp+0x90], xmm9
00007026095d956d  vmovaps [rsp+0xA0], xmm11
00007026095d9576  vmovaps [rsp+0xB0], xmm12
00007026095d957f  vmovaps [rsp+0xC0], xmm13
00007026095d9588  vmovaps [rsp+0xD0], xmm14
00007026095d9591  vmovaps [rsp+0xE0], xmm15
00007026095d959a  sub rsp, 0x40
00007026095d959e  lea rdi, [rsp]
00007026095d95a2  lea rsi, [rsp+0x10]
00007026095d95a7  lea rdx, [rsp+0x20]
00007026095d95ac  lea rcx, [rsp+0x30]
00007026095d95b1  mov r8d, 0x00
00007026095d95b7  lea r9, [r15+0x3A8]
00007026095d95be  movaps [rdi], xmm10
00007026095d95c2  movaps [rsi], xmm6
00007026095d95c5  movaps [rdx], xmm15
00007026095d95c9  movaps [rcx], xmm1
00007026095d95cc  mov rax, 0x58A432239A50
00007026095d95d6  call rax
00007026095d95d8  movaps xmm10, [rsp]
00007026095d95dd  add rsp, 0x40
00007026095d95e1  vmovaps xmm0, [rsp]
00007026095d95e6  vmovaps xmm1, [rsp+0x10]
00007026095d95ec  vmovaps xmm2, [rsp+0x20]
00007026095d95f2  vmovaps xmm3, [rsp+0x30]
00007026095d95f8  vmovaps xmm4, [rsp+0x40]
00007026095d95fe  vmovaps xmm5, [rsp+0x50]
00007026095d9604  vmovaps xmm6, [rsp+0x60]
00007026095d960a  vmovaps xmm7, [rsp+0x70]
00007026095d9610  vmovaps xmm8, [rsp+0x80]
00007026095d9619  vmovaps xmm9, [rsp+0x90]
00007026095d9622  vmovaps xmm11, [rsp+0xA0]
00007026095d962b  vmovaps xmm12, [rsp+0xB0]
00007026095d9634  vmovaps xmm13, [rsp+0xC0]
00007026095d963d  vmovaps xmm14, [rsp+0xD0]
00007026095d9646  vmovaps xmm15, [rsp+0xE0]
00007026095d964f  add rsp, 0xF0
00007026095d9656  pop r11
00007026095d9658  pop r10
00007026095d965a  pop r9
00007026095d965c  pop r8
00007026095d965e  pop rsi
00007026095d965f  pop rdi
00007026095d9660  pop rdx
00007026095d9661  pop rcx
00007026095d9662  pop rax
00007026095d9663  add rsp, 0x08
00007026095d9667  jmp 0x00007026095D7341
00007026095d966c  call 0x00007026093FF430
00007026095d9671  jmp 0x00007026095D734B
00007026095d9676  call 0x000070260940E760
00007026095d967b  jmp 0x00007026095D7355
00007026095d9680  sub rsp, 0x08
00007026095d9684  push rax
00007026095d9685  push rcx
00007026095d9686  push rdx
00007026095d9687  push rdi
00007026095d9688  push rsi
00007026095d9689  push r8
00007026095d968b  push r9
00007026095d968d  push r10
00007026095d968f  push r11
00007026095d9691  sub rsp, 0xF0
00007026095d9698  vmovaps [rsp], xmm0
00007026095d969d  vmovaps [rsp+0x10], xmm1
00007026095d96a3  vmovaps [rsp+0x20], xmm2
00007026095d96a9  vmovaps [rsp+0x30], xmm3
00007026095d96af  vmovaps [rsp+0x40], xmm4
00007026095d96b5  vmovaps [rsp+0x50], xmm5
00007026095d96bb  vmovaps [rsp+0x60], xmm6
00007026095d96c1  vmovaps [rsp+0x70], xmm8
00007026095d96c7  vmovaps [rsp+0x80], xmm9
00007026095d96d0  vmovaps [rsp+0x90], xmm10
00007026095d96d9  vmovaps [rsp+0xA0], xmm11
00007026095d96e2  vmovaps [rsp+0xB0], xmm12
00007026095d96eb  vmovaps [rsp+0xC0], xmm13
00007026095d96f4  vmovaps [rsp+0xD0], xmm14
00007026095d96fd  vmovaps [rsp+0xE0], xmm15
00007026095d9706  sub rsp, 0x40
00007026095d970a  lea rdi, [rsp]
00007026095d970e  lea rsi, [rsp+0x10]
00007026095d9713  lea rdx, [rsp+0x20]
00007026095d9718  lea rcx, [rsp+0x30]
00007026095d971d  mov r8d, 0x00
00007026095d9723  lea r9, [r15+0x3A8]
00007026095d972a  movaps [rdi], xmm7
00007026095d972d  movaps [rsi], xmm8
00007026095d9731  movaps [rdx], xmm3
00007026095d9734  movaps [rcx], xmm9
00007026095d9738  mov rax, 0x58A432239A50
00007026095d9742  call rax
00007026095d9744  movaps xmm7, [rsp]
00007026095d9748  add rsp, 0x40
00007026095d974c  vmovaps xmm0, [rsp]
00007026095d9751  vmovaps xmm1, [rsp+0x10]
00007026095d9757  vmovaps xmm2, [rsp+0x20]
00007026095d975d  vmovaps xmm3, [rsp+0x30]
00007026095d9763  vmovaps xmm4, [rsp+0x40]
00007026095d9769  vmovaps xmm5, [rsp+0x50]
00007026095d976f  vmovaps xmm6, [rsp+0x60]
00007026095d9775  vmovaps xmm8, [rsp+0x70]
00007026095d977b  vmovaps xmm9, [rsp+0x80]
00007026095d9784  vmovaps xmm10, [rsp+0x90]
00007026095d978d  vmovaps xmm11, [rsp+0xA0]
00007026095d9796  vmovaps xmm12, [rsp+0xB0]
00007026095d979f  vmovaps xmm13, [rsp+0xC0]
00007026095d97a8  vmovaps xmm14, [rsp+0xD0]
00007026095d97b1  vmovaps xmm15, [rsp+0xE0]
00007026095d97ba  add rsp, 0xF0
00007026095d97c1  pop r11
00007026095d97c3  pop r10
00007026095d97c5  pop r9
00007026095d97c7  pop r8
00007026095d97c9  pop rsi
00007026095d97ca  pop rdi
00007026095d97cb  pop rdx
00007026095d97cc  pop rcx
00007026095d97cd  pop rax
00007026095d97ce  add rsp, 0x08
00007026095d97d2  jmp 0x00007026095D737D
00007026095d97d7  sub rsp, 0x08
00007026095d97db  push rax
00007026095d97dc  push rcx
00007026095d97dd  push rdx
00007026095d97de  push rdi
00007026095d97df  push rsi
00007026095d97e0  push r8
00007026095d97e2  push r9
00007026095d97e4  push r10
00007026095d97e6  push r11
00007026095d97e8  sub rsp, 0xF0
00007026095d97ef  vmovaps [rsp], xmm0
00007026095d97f4  vmovaps [rsp+0x10], xmm1
00007026095d97fa  vmovaps [rsp+0x20], xmm2
00007026095d9800  vmovaps [rsp+0x30], xmm3
00007026095d9806  vmovaps [rsp+0x40], xmm4
00007026095d980c  vmovaps [rsp+0x50], xmm5
00007026095d9812  vmovaps [rsp+0x60], xmm6
00007026095d9818  vmovaps [rsp+0x70], xmm7
00007026095d981e  vmovaps [rsp+0x80], xmm9
00007026095d9827  vmovaps [rsp+0x90], xmm10
00007026095d9830  vmovaps [rsp+0xA0], xmm11
00007026095d9839  vmovaps [rsp+0xB0], xmm12
00007026095d9842  vmovaps [rsp+0xC0], xmm13
00007026095d984b  vmovaps [rsp+0xD0], xmm14
00007026095d9854  vmovaps [rsp+0xE0], xmm15
00007026095d985d  sub rsp, 0x40
00007026095d9861  lea rdi, [rsp]
00007026095d9865  lea rsi, [rsp+0x10]
00007026095d986a  lea rdx, [rsp+0x20]
00007026095d986f  lea rcx, [rsp+0x30]
00007026095d9874  mov r8d, 0x00
00007026095d987a  lea r9, [r15+0x3A8]
00007026095d9881  movaps [rdi], xmm8
00007026095d9885  movaps [rsi], xmm11
00007026095d9889  movaps [rdx], xmm14
00007026095d988d  movaps [rcx], xmm9
00007026095d9891  mov rax, 0x58A432239A50
00007026095d989b  call rax
00007026095d989d  movaps xmm8, [rsp]
00007026095d98a2  add rsp, 0x40
00007026095d98a6  vmovaps xmm0, [rsp]
00007026095d98ab  vmovaps xmm1, [rsp+0x10]
00007026095d98b1  vmovaps xmm2, [rsp+0x20]
00007026095d98b7  vmovaps xmm3, [rsp+0x30]
00007026095d98bd  vmovaps xmm4, [rsp+0x40]
00007026095d98c3  vmovaps xmm5, [rsp+0x50]
00007026095d98c9  vmovaps xmm6, [rsp+0x60]
00007026095d98cf  vmovaps xmm7, [rsp+0x70]
00007026095d98d5  vmovaps xmm9, [rsp+0x80]
00007026095d98de  vmovaps xmm10, [rsp+0x90]
00007026095d98e7  vmovaps xmm11, [rsp+0xA0]
00007026095d98f0  vmovaps xmm12, [rsp+0xB0]
00007026095d98f9  vmovaps xmm13, [rsp+0xC0]
00007026095d9902  vmovaps xmm14, [rsp+0xD0]
00007026095d990b  vmovaps xmm15, [rsp+0xE0]
00007026095d9914  add rsp, 0xF0
00007026095d991b  pop r11
00007026095d991d  pop r10
00007026095d991f  pop r9
00007026095d9921  pop r8
00007026095d9923  pop rsi
00007026095d9924  pop rdi
00007026095d9925  pop rdx
00007026095d9926  pop rcx
00007026095d9927  pop rax
00007026095d9928  add rsp, 0x08
00007026095d992c  jmp 0x00007026095D73A6
00007026095d9931  sub rsp, 0x08
00007026095d9935  push rax
00007026095d9936  push rcx
00007026095d9937  push rdx
00007026095d9938  push rdi
00007026095d9939  push rsi
00007026095d993a  push r8
00007026095d993c  push r9
00007026095d993e  push r10
00007026095d9940  push r11
00007026095d9942  sub rsp, 0xF0
00007026095d9949  vmovaps [rsp], xmm0
00007026095d994e  vmovaps [rsp+0x10], xmm1
00007026095d9954  vmovaps [rsp+0x20], xmm2
00007026095d995a  vmovaps [rsp+0x30], xmm3
00007026095d9960  vmovaps [rsp+0x40], xmm4
00007026095d9966  vmovaps [rsp+0x50], xmm5
00007026095d996c  vmovaps [rsp+0x60], xmm6
00007026095d9972  vmovaps [rsp+0x70], xmm7
00007026095d9978  vmovaps [rsp+0x80], xmm8
00007026095d9981  vmovaps [rsp+0x90], xmm9
00007026095d998a  vmovaps [rsp+0xA0], xmm10
00007026095d9993  vmovaps [rsp+0xB0], xmm12
00007026095d999c  vmovaps [rsp+0xC0], xmm13
00007026095d99a5  vmovaps [rsp+0xD0], xmm14
00007026095d99ae  vmovaps [rsp+0xE0], xmm15
00007026095d99b7  sub rsp, 0x40
00007026095d99bb  lea rdi, [rsp]
00007026095d99bf  lea rsi, [rsp+0x10]
00007026095d99c4  lea rdx, [rsp+0x20]
00007026095d99c9  lea rcx, [rsp+0x30]
00007026095d99ce  mov r8d, 0x00
00007026095d99d4  lea r9, [r15+0x3A8]
00007026095d99db  movaps [rdi], xmm11
00007026095d99df  movaps [rsi], xmm13
00007026095d99e3  movaps [rdx], xmm12
00007026095d99e7  movaps [rcx], xmm14
00007026095d99eb  mov rax, 0x58A432239A50
00007026095d99f5  call rax
00007026095d99f7  movaps xmm11, [rsp]
00007026095d99fc  add rsp, 0x40
00007026095d9a00  vmovaps xmm0, [rsp]
00007026095d9a05  vmovaps xmm1, [rsp+0x10]
00007026095d9a0b  vmovaps xmm2, [rsp+0x20]
00007026095d9a11  vmovaps xmm3, [rsp+0x30]
00007026095d9a17  vmovaps xmm4, [rsp+0x40]
00007026095d9a1d  vmovaps xmm5, [rsp+0x50]
00007026095d9a23  vmovaps xmm6, [rsp+0x60]
00007026095d9a29  vmovaps xmm7, [rsp+0x70]
00007026095d9a2f  vmovaps xmm8, [rsp+0x80]
00007026095d9a38  vmovaps xmm9, [rsp+0x90]
00007026095d9a41  vmovaps xmm10, [rsp+0xA0]
00007026095d9a4a  vmovaps xmm12, [rsp+0xB0]
00007026095d9a53  vmovaps xmm13, [rsp+0xC0]
00007026095d9a5c  vmovaps xmm14, [rsp+0xD0]
00007026095d9a65  vmovaps xmm15, [rsp+0xE0]
00007026095d9a6e  add rsp, 0xF0
00007026095d9a75  pop r11
00007026095d9a77  pop r10
00007026095d9a79  pop r9
00007026095d9a7b  pop r8
00007026095d9a7d  pop rsi
00007026095d9a7e  pop rdi
00007026095d9a7f  pop rdx
00007026095d9a80  pop rcx
00007026095d9a81  pop rax
00007026095d9a82  add rsp, 0x08
00007026095d9a86  jmp 0x00007026095D73CF
00007026095d9a8b  sub rsp, 0x08
00007026095d9a8f  push rax
00007026095d9a90  push rcx
00007026095d9a91  push rdx
00007026095d9a92  push rdi
00007026095d9a93  push rsi
00007026095d9a94  push r8
00007026095d9a96  push r9
00007026095d9a98  push r10
00007026095d9a9a  push r11
00007026095d9a9c  sub rsp, 0xF0
00007026095d9aa3  vmovaps [rsp], xmm0
00007026095d9aa8  vmovaps [rsp+0x10], xmm1
00007026095d9aae  vmovaps [rsp+0x20], xmm2
00007026095d9ab4  vmovaps [rsp+0x30], xmm3
00007026095d9aba  vmovaps [rsp+0x40], xmm4
00007026095d9ac0  vmovaps [rsp+0x50], xmm5
00007026095d9ac6  vmovaps [rsp+0x60], xmm6
00007026095d9acc  vmovaps [rsp+0x70], xmm7
00007026095d9ad2  vmovaps [rsp+0x80], xmm8
00007026095d9adb  vmovaps [rsp+0x90], xmm9
00007026095d9ae4  vmovaps [rsp+0xA0], xmm10
00007026095d9aed  vmovaps [rsp+0xB0], xmm11
00007026095d9af6  vmovaps [rsp+0xC0], xmm13
00007026095d9aff  vmovaps [rsp+0xD0], xmm14
00007026095d9b08  vmovaps [rsp+0xE0], xmm15
00007026095d9b11  sub rsp, 0x40
00007026095d9b15  lea rdi, [rsp]
00007026095d9b19  lea rsi, [rsp+0x10]
00007026095d9b1e  lea rdx, [rsp+0x20]
00007026095d9b23  lea rcx, [rsp+0x30]
00007026095d9b28  mov r8d, 0x00
00007026095d9b2e  lea r9, [r15+0x3A8]
00007026095d9b35  movaps [rdi], xmm12
00007026095d9b39  movaps [rsi], xmm10
00007026095d9b3d  movaps [rdx], xmm15
00007026095d9b41  movaps [rcx], xmm14
00007026095d9b45  mov rax, 0x58A432239A50
00007026095d9b4f  call rax
00007026095d9b51  movaps xmm12, [rsp]
00007026095d9b56  add rsp, 0x40
00007026095d9b5a  vmovaps xmm0, [rsp]
00007026095d9b5f  vmovaps xmm1, [rsp+0x10]
00007026095d9b65  vmovaps xmm2, [rsp+0x20]
00007026095d9b6b  vmovaps xmm3, [rsp+0x30]
00007026095d9b71  vmovaps xmm4, [rsp+0x40]
00007026095d9b77  vmovaps xmm5, [rsp+0x50]
00007026095d9b7d  vmovaps xmm6, [rsp+0x60]
00007026095d9b83  vmovaps xmm7, [rsp+0x70]
00007026095d9b89  vmovaps xmm8, [rsp+0x80]
00007026095d9b92  vmovaps xmm9, [rsp+0x90]
00007026095d9b9b  vmovaps xmm10, [rsp+0xA0]
00007026095d9ba4  vmovaps xmm11, [rsp+0xB0]
00007026095d9bad  vmovaps xmm13, [rsp+0xC0]
00007026095d9bb6  vmovaps xmm14, [rsp+0xD0]
00007026095d9bbf  vmovaps xmm15, [rsp+0xE0]
00007026095d9bc8  add rsp, 0xF0
00007026095d9bcf  pop r11
00007026095d9bd1  pop r10
00007026095d9bd3  pop r9
00007026095d9bd5  pop r8
00007026095d9bd7  pop rsi
00007026095d9bd8  pop rdi
00007026095d9bd9  pop rdx
00007026095d9bda  pop rcx
00007026095d9bdb  pop rax
00007026095d9bdc  add rsp, 0x08
00007026095d9be0  jmp 0x00007026095D73F8
00007026095d9be5  call 0x000070260940E760
00007026095d9bea  jmp 0x00007026095D7405
00007026095d9bef  call 0x000070260940D4E0
00007026095d9bf4  jmp 0x00007026095D7412
00007026095d9bf9  sub rsp, 0x08
00007026095d9bfd  push rax
00007026095d9bfe  push rcx
00007026095d9bff  push rdx
00007026095d9c00  push rdi
00007026095d9c01  push rsi
00007026095d9c02  push r8
00007026095d9c04  push r9
00007026095d9c06  push r10
00007026095d9c08  push r11
00007026095d9c0a  sub rsp, 0xF0
00007026095d9c11  vmovaps [rsp], xmm0
00007026095d9c16  vmovaps [rsp+0x10], xmm1
00007026095d9c1c  vmovaps [rsp+0x20], xmm2
00007026095d9c22  vmovaps [rsp+0x30], xmm3
00007026095d9c28  vmovaps [rsp+0x40], xmm4
00007026095d9c2e  vmovaps [rsp+0x50], xmm5
00007026095d9c34  vmovaps [rsp+0x60], xmm6
00007026095d9c3a  vmovaps [rsp+0x70], xmm7
00007026095d9c40  vmovaps [rsp+0x80], xmm8
00007026095d9c49  vmovaps [rsp+0x90], xmm9
00007026095d9c52  vmovaps [rsp+0xA0], xmm11
00007026095d9c5b  vmovaps [rsp+0xB0], xmm12
00007026095d9c64  vmovaps [rsp+0xC0], xmm13
00007026095d9c6d  vmovaps [rsp+0xD0], xmm14
00007026095d9c76  vmovaps [rsp+0xE0], xmm15
00007026095d9c7f  sub rsp, 0x40
00007026095d9c83  lea rdi, [rsp]
00007026095d9c87  lea rsi, [rsp+0x10]
00007026095d9c8c  lea rdx, [rsp+0x20]
00007026095d9c91  lea rcx, [rsp+0x30]
00007026095d9c96  mov r8d, 0x00
00007026095d9c9c  lea r9, [r15+0x3A8]
00007026095d9ca3  movaps [rdi], xmm10
00007026095d9ca7  movaps [rsi], xmm7
00007026095d9caa  movaps [rdx], xmm1
00007026095d9cad  movaps [rcx], xmm13
00007026095d9cb1  mov rax, 0x58A432239A50
00007026095d9cbb  call rax
00007026095d9cbd  movaps xmm10, [rsp]
00007026095d9cc2  add rsp, 0x40
00007026095d9cc6  vmovaps xmm0, [rsp]
00007026095d9ccb  vmovaps xmm1, [rsp+0x10]
00007026095d9cd1  vmovaps xmm2, [rsp+0x20]
00007026095d9cd7  vmovaps xmm3, [rsp+0x30]
00007026095d9cdd  vmovaps xmm4, [rsp+0x40]
00007026095d9ce3  vmovaps xmm5, [rsp+0x50]
00007026095d9ce9  vmovaps xmm6, [rsp+0x60]
00007026095d9cef  vmovaps xmm7, [rsp+0x70]
00007026095d9cf5  vmovaps xmm8, [rsp+0x80]
00007026095d9cfe  vmovaps xmm9, [rsp+0x90]
00007026095d9d07  vmovaps xmm11, [rsp+0xA0]
00007026095d9d10  vmovaps xmm12, [rsp+0xB0]
00007026095d9d19  vmovaps xmm13, [rsp+0xC0]
00007026095d9d22  vmovaps xmm14, [rsp+0xD0]
00007026095d9d2b  vmovaps xmm15, [rsp+0xE0]
00007026095d9d34  add rsp, 0xF0
00007026095d9d3b  pop r11
00007026095d9d3d  pop r10
00007026095d9d3f  pop r9
00007026095d9d41  pop r8
00007026095d9d43  pop rsi
00007026095d9d44  pop rdi
00007026095d9d45  pop rdx
00007026095d9d46  pop rcx
00007026095d9d47  pop rax
00007026095d9d48  add rsp, 0x08
00007026095d9d4c  jmp 0x00007026095D7448
00007026095d9d51  call 0x00007026093FF430
00007026095d9d56  jmp 0x00007026095D745A
00007026095d9d5b  sub rsp, 0x08
00007026095d9d5f  push rax
00007026095d9d60  push rcx
00007026095d9d61  push rdx
00007026095d9d62  push rdi
00007026095d9d63  push rsi
00007026095d9d64  push r8
00007026095d9d66  push r9
00007026095d9d68  push r10
00007026095d9d6a  push r11
00007026095d9d6c  sub rsp, 0xF0
00007026095d9d73  vmovaps [rsp], xmm0
00007026095d9d78  vmovaps [rsp+0x10], xmm1
00007026095d9d7e  vmovaps [rsp+0x20], xmm2
00007026095d9d84  vmovaps [rsp+0x30], xmm3
00007026095d9d8a  vmovaps [rsp+0x40], xmm4
00007026095d9d90  vmovaps [rsp+0x50], xmm5
00007026095d9d96  vmovaps [rsp+0x60], xmm6
00007026095d9d9c  vmovaps [rsp+0x70], xmm7
00007026095d9da2  vmovaps [rsp+0x80], xmm8
00007026095d9dab  vmovaps [rsp+0x90], xmm10
00007026095d9db4  vmovaps [rsp+0xA0], xmm11
00007026095d9dbd  vmovaps [rsp+0xB0], xmm12
00007026095d9dc6  vmovaps [rsp+0xC0], xmm13
00007026095d9dcf  vmovaps [rsp+0xD0], xmm14
00007026095d9dd8  vmovaps [rsp+0xE0], xmm15
00007026095d9de1  sub rsp, 0x40
00007026095d9de5  lea rdi, [rsp]
00007026095d9de9  lea rsi, [rsp+0x10]
00007026095d9dee  lea rdx, [rsp+0x20]
00007026095d9df3  lea rcx, [rsp+0x30]
00007026095d9df8  mov r8d, 0x00
00007026095d9dfe  lea r9, [r15+0x3A8]
00007026095d9e05  movaps [rdi], xmm9
00007026095d9e09  movaps [rsi], xmm8
00007026095d9e0d  movaps [rdx], xmm14
00007026095d9e11  movaps [rcx], xmm13
00007026095d9e15  mov rax, 0x58A432239A50
00007026095d9e1f  call rax
00007026095d9e21  movaps xmm9, [rsp]
00007026095d9e26  add rsp, 0x40
00007026095d9e2a  vmovaps xmm0, [rsp]
00007026095d9e2f  vmovaps xmm1, [rsp+0x10]
00007026095d9e35  vmovaps xmm2, [rsp+0x20]
00007026095d9e3b  vmovaps xmm3, [rsp+0x30]
00007026095d9e41  vmovaps xmm4, [rsp+0x40]
00007026095d9e47  vmovaps xmm5, [rsp+0x50]
00007026095d9e4d  vmovaps xmm6, [rsp+0x60]
00007026095d9e53  vmovaps xmm7, [rsp+0x70]
00007026095d9e59  vmovaps xmm8, [rsp+0x80]
00007026095d9e62  vmovaps xmm10, [rsp+0x90]
00007026095d9e6b  vmovaps xmm11, [rsp+0xA0]
00007026095d9e74  vmovaps xmm12, [rsp+0xB0]
00007026095d9e7d  vmovaps xmm13, [rsp+0xC0]
00007026095d9e86  vmovaps xmm14, [rsp+0xD0]
00007026095d9e8f  vmovaps xmm15, [rsp+0xE0]
00007026095d9e98  add rsp, 0xF0
00007026095d9e9f  pop r11
00007026095d9ea1  pop r10
00007026095d9ea3  pop r9
00007026095d9ea5  pop r8
00007026095d9ea7  pop rsi
00007026095d9ea8  pop rdi
00007026095d9ea9  pop rdx
00007026095d9eaa  pop rcx
00007026095d9eab  pop rax
00007026095d9eac  add rsp, 0x08
00007026095d9eb0  jmp 0x00007026095D7488
00007026095d9eb5  sub rsp, 0x08
00007026095d9eb9  push rax
00007026095d9eba  push rcx
00007026095d9ebb  push rdx
00007026095d9ebc  push rdi
00007026095d9ebd  push rsi
00007026095d9ebe  push r8
00007026095d9ec0  push r9
00007026095d9ec2  push r10
00007026095d9ec4  push r11
00007026095d9ec6  sub rsp, 0xF0
00007026095d9ecd  vmovaps [rsp], xmm0
00007026095d9ed2  vmovaps [rsp+0x10], xmm1
00007026095d9ed8  vmovaps [rsp+0x20], xmm2
00007026095d9ede  vmovaps [rsp+0x30], xmm3
00007026095d9ee4  vmovaps [rsp+0x40], xmm4
00007026095d9eea  vmovaps [rsp+0x50], xmm5
00007026095d9ef0  vmovaps [rsp+0x60], xmm6
00007026095d9ef6  vmovaps [rsp+0x70], xmm7
00007026095d9efc  vmovaps [rsp+0x80], xmm8
00007026095d9f05  vmovaps [rsp+0x90], xmm9
00007026095d9f0e  vmovaps [rsp+0xA0], xmm10
00007026095d9f17  vmovaps [rsp+0xB0], xmm11
00007026095d9f20  vmovaps [rsp+0xC0], xmm12
00007026095d9f29  vmovaps [rsp+0xD0], xmm14
00007026095d9f32  vmovaps [rsp+0xE0], xmm15
00007026095d9f3b  sub rsp, 0x40
00007026095d9f3f  lea rdi, [rsp]
00007026095d9f43  lea rsi, [rsp+0x10]
00007026095d9f48  lea rdx, [rsp+0x20]
00007026095d9f4d  lea rcx, [rsp+0x30]
00007026095d9f52  mov r8d, 0x00
00007026095d9f58  lea r9, [r15+0x3A8]
00007026095d9f5f  movaps [rdi], xmm13
00007026095d9f63  movaps [rsi], xmm11
00007026095d9f67  movaps [rdx], xmm15
00007026095d9f6b  movaps [rcx], xmm14
00007026095d9f6f  mov rax, 0x58A432239A50
00007026095d9f79  call rax
00007026095d9f7b  movaps xmm13, [rsp]
00007026095d9f80  add rsp, 0x40
00007026095d9f84  vmovaps xmm0, [rsp]
00007026095d9f89  vmovaps xmm1, [rsp+0x10]
00007026095d9f8f  vmovaps xmm2, [rsp+0x20]
00007026095d9f95  vmovaps xmm3, [rsp+0x30]
00007026095d9f9b  vmovaps xmm4, [rsp+0x40]
00007026095d9fa1  vmovaps xmm5, [rsp+0x50]
00007026095d9fa7  vmovaps xmm6, [rsp+0x60]
00007026095d9fad  vmovaps xmm7, [rsp+0x70]
00007026095d9fb3  vmovaps xmm8, [rsp+0x80]
00007026095d9fbc  vmovaps xmm9, [rsp+0x90]
00007026095d9fc5  vmovaps xmm10, [rsp+0xA0]
00007026095d9fce  vmovaps xmm11, [rsp+0xB0]
00007026095d9fd7  vmovaps xmm12, [rsp+0xC0]
00007026095d9fe0  vmovaps xmm14, [rsp+0xD0]
00007026095d9fe9  vmovaps xmm15, [rsp+0xE0]
00007026095d9ff2  add rsp, 0xF0
00007026095d9ff9  pop r11
00007026095d9ffb  pop r10
00007026095d9ffd  pop r9
00007026095d9fff  pop r8
00007026095da001  pop rsi
00007026095da002  pop rdi
00007026095da003  pop rdx
00007026095da004  pop rcx
00007026095da005  pop rax
00007026095da006  add rsp, 0x08
00007026095da00a  jmp 0x00007026095D74B6
00007026095da00f  sub rsp, 0x08
00007026095da013  push rax
00007026095da014  push rcx
00007026095da015  push rdx
00007026095da016  push rdi
00007026095da017  push rsi
00007026095da018  push r8
00007026095da01a  push r9
00007026095da01c  push r10
00007026095da01e  push r11
00007026095da020  sub rsp, 0xF0
00007026095da027  vmovaps [rsp], xmm0
00007026095da02c  vmovaps [rsp+0x10], xmm1
00007026095da032  vmovaps [rsp+0x20], xmm2
00007026095da038  vmovaps [rsp+0x30], xmm3
00007026095da03e  vmovaps [rsp+0x40], xmm4
00007026095da044  vmovaps [rsp+0x50], xmm5
00007026095da04a  vmovaps [rsp+0x60], xmm6
00007026095da050  vmovaps [rsp+0x70], xmm7
00007026095da056  vmovaps [rsp+0x80], xmm8
00007026095da05f  vmovaps [rsp+0x90], xmm9
00007026095da068  vmovaps [rsp+0xA0], xmm10
00007026095da071  vmovaps [rsp+0xB0], xmm11
00007026095da07a  vmovaps [rsp+0xC0], xmm12
00007026095da083  vmovaps [rsp+0xD0], xmm13
00007026095da08c  vmovaps [rsp+0xE0], xmm15
00007026095da095  sub rsp, 0x40
00007026095da099  lea rdi, [rsp]
00007026095da09d  lea rsi, [rsp+0x10]
00007026095da0a2  lea rdx, [rsp+0x20]
00007026095da0a7  lea rcx, [rsp+0x30]
00007026095da0ac  mov r8d, 0x00
00007026095da0b2  lea r9, [r15+0x3A8]
00007026095da0b9  movaps [rdi], xmm14
00007026095da0bd  movaps [rsi], xmm12
00007026095da0c1  movaps [rdx], xmm1
00007026095da0c4  movaps [rcx], xmm15
00007026095da0c8  mov rax, 0x58A432239A50
00007026095da0d2  call rax
00007026095da0d4  movaps xmm14, [rsp]
00007026095da0d9  add rsp, 0x40
00007026095da0dd  vmovaps xmm0, [rsp]
00007026095da0e2  vmovaps xmm1, [rsp+0x10]
00007026095da0e8  vmovaps xmm2, [rsp+0x20]
00007026095da0ee  vmovaps xmm3, [rsp+0x30]
00007026095da0f4  vmovaps xmm4, [rsp+0x40]
00007026095da0fa  vmovaps xmm5, [rsp+0x50]
00007026095da100  vmovaps xmm6, [rsp+0x60]
00007026095da106  vmovaps xmm7, [rsp+0x70]
00007026095da10c  vmovaps xmm8, [rsp+0x80]
00007026095da115  vmovaps xmm9, [rsp+0x90]
00007026095da11e  vmovaps xmm10, [rsp+0xA0]
00007026095da127  vmovaps xmm11, [rsp+0xB0]
00007026095da130  vmovaps xmm12, [rsp+0xC0]
00007026095da139  vmovaps xmm13, [rsp+0xD0]
00007026095da142  vmovaps xmm15, [rsp+0xE0]
00007026095da14b  add rsp, 0xF0
00007026095da152  pop r11
00007026095da154  pop r10
00007026095da156  pop r9
00007026095da158  pop r8
00007026095da15a  pop rsi
00007026095da15b  pop rdi
00007026095da15c  pop rdx
00007026095da15d  pop rcx
00007026095da15e  pop rax
00007026095da15f  add rsp, 0x08
00007026095da163  jmp 0x00007026095D74E4
00007026095da168  call 0x00007026094079B0
00007026095da16d  jmp 0x00007026095D74FA
00007026095da172  call 0x00007026094E3440
00007026095da177  jmp 0x00007026095D7504
00007026095da17c  call 0x00007026094DFCE0
00007026095da181  jmp 0x00007026095D750E
00007026095da186  call 0x00007026094E46C0
00007026095da18b  jmp 0x00007026095D7518
00007026095da190  int3
00007026095da191  nop [rax+rax*1], ax
00007026095da19a  nop [rax+rax*1], ax
00007026095da1a0  mov rax, [r15+0xF8]
00007026095da1a7  lea r14, [rax+0x110]
00007026095da1ae  mov r12, [r13+r14*1]
00007026095da1b3  mov [r15+0xE8], r12
00007026095da1ba  lea r14, [rax+0x100]
00007026095da1c1  mov r12, [r13+r14*1]
00007026095da1c6  lea r14, [rax+0x108]
00007026095da1cd  mov r11, [r13+r14*1]
00007026095da1d2  movq xmm1, r12
00007026095da1d7  movq xmm15, r11
00007026095da1dc  movq xmm1, xmm1
00007026095da1e0  movq xmm1, xmm1
00007026095da1e4  movaps [r15+0x1A0], xmm1
00007026095da1ec  movq xmm15, xmm15
00007026095da1f1  movq xmm15, xmm15
00007026095da1f6  movaps [r15+0x190], xmm15
00007026095da1fe  lea r14, [rax+0xF0]
00007026095da205  mov r12, [r13+r14*1]
00007026095da20a  lea r14, [rax+0xF8]
00007026095da211  mov r11, [r13+r14*1]
00007026095da216  movq xmm1, r12
00007026095da21b  movq xmm15, r11
00007026095da220  movq xmm1, xmm1
00007026095da224  movq xmm1, xmm1
00007026095da228  movaps [r15+0x1C0], xmm1
00007026095da230  movq xmm15, xmm15
00007026095da235  movq xmm15, xmm15
00007026095da23a  movaps [r15+0x1B0], xmm15
00007026095da242  lea r14, [rax+0xE0]
00007026095da249  mov r12, [r13+r14*1]
00007026095da24e  lea r14, [rax+0xE8]
00007026095da255  mov r11, [r13+r14*1]
00007026095da25a  movq xmm1, r12
00007026095da25f  movq xmm15, r11
00007026095da264  movq xmm1, xmm1
00007026095da268  movq xmm1, xmm1
00007026095da26c  movaps [r15+0x1E0], xmm1
00007026095da274  movq xmm15, xmm15
00007026095da279  movq xmm15, xmm15
00007026095da27e  movaps [r15+0x1D0], xmm15
00007026095da286  lea r14, [rax+0xD0]
00007026095da28d  mov r12, [r13+r14*1]
00007026095da292  lea r14, [rax+0xD8]
00007026095da299  mov r11, [r13+r14*1]
00007026095da29e  movq xmm1, r12
00007026095da2a3  movq xmm15, r11
00007026095da2a8  movq xmm1, xmm1
00007026095da2ac  movq xmm1, xmm1
00007026095da2b0  movaps [r15+0x200], xmm1
00007026095da2b8  movq xmm15, xmm15
00007026095da2bd  movq xmm15, xmm15
00007026095da2c2  movaps [r15+0x1F0], xmm15
00007026095da2ca  mov qword ptr [r15+0x40], 0x430000
00007026095da2d2  mov r14d, 0x4304C0
00007026095da2d8  mov r12, [r13+r14*1]
00007026095da2dd  movq xmm1, r12
00007026095da2e2  lea r14, [rax+0x120]
00007026095da2e9  mov [r15+0xF8], r14
00007026095da2f0  mov rax, [r15+0x50]
00007026095da2f4  movups xmm15, [r13+rax*1]
00007026095da2fa  movaps [r15+0x120], xmm15
00007026095da302  mov qword ptr [r15+0x48], 0x10
00007026095da30a  xor eax, eax
00007026095da30c  mov r14d, 0x10
00007026095da312  mov r12d, 0x200
00007026095da318  cmp r14, r12
00007026095da31b  cmc
00007026095da31c  lahf
00007026095da31d  seto al
00007026095da320  mov [r15+0x108], eax
00007026095da327  pextrq rax, xmm15, 0x01
00007026095da32e  movq xmm14, rax
00007026095da333  movaps [r15+0x130], xmm14
00007026095da33b  movq rax, xmm1
00007026095da340  movq r14, xmm15
00007026095da345  vmovq xmm1, rax
00007026095da34a  vmovq xmm15, r14
00007026095da34f  movaps xmm13, xmm1
00007026095da353  addsd xmm13, xmm15
00007026095da358  ucomisd xmm13, xmm13
00007026095da35d  jp 0x00007026095DA476
00007026095da363  movq xmm13, xmm13
00007026095da368  movq rax, xmm13
00007026095da36d  movq r14, xmm14
00007026095da372  vmovq xmm1, rax
00007026095da377  vmovq xmm15, r14
00007026095da37c  movaps xmm14, xmm1
00007026095da380  addsd xmm14, xmm15
00007026095da385  ucomisd xmm14, xmm14
00007026095da38a  jp 0x00007026095DA4BE
00007026095da390  movq xmm14, xmm14
00007026095da395  movaps [r15+0x110], xmm14
00007026095da39d  mov eax, [r15+0x108]
00007026095da3a4  sahf
00007026095da3a5  jnz 0x00007026095DA3D7
00007026095da3a7  cmp dword ptr [r15+0x318], 0x00
00007026095da3af  jz 0x00007026095DA6D0
00007026095da3b5  nop [rax+rax*1], ax
00007026095da3be  nop [rax+rax*1], eax
00007026095da3c6  mov eax, 0x41043C
00007026095da3cb  mov [r15+0x100], rax
00007026095da3d2  jmp 0x00007026093FE110
00007026095da3d7  cmp dword ptr [r15+0x318], 0x00
00007026095da3df  jz 0x00007026095DA510
00007026095da3e5  nop [rax+rax*1], ax
00007026095da3ee  nop [rax+rax*1], eax
00007026095da3f6  mov eax, 0x410420
00007026095da3fb  mov [r15+0x100], rax
00007026095da402  jmp 0x00007026093FE110
00007026095da407  int3
00007026095da408  call 0x00007026094E27E0
00007026095da40d  jmp 0x00007026095DA1B3
00007026095da412  call 0x00007026094E27E0
00007026095da417  jmp 0x00007026095DA1C6
00007026095da41c  call 0x00007026094E1570
00007026095da421  jmp 0x00007026095DA1D2
00007026095da426  call 0x00007026094E27E0
00007026095da42b  jmp 0x00007026095DA20A
00007026095da430  call 0x00007026094E1570
00007026095da435  jmp 0x00007026095DA216
00007026095da43a  call 0x00007026094E27E0
00007026095da43f  jmp 0x00007026095DA24E
00007026095da444  call 0x00007026094E1570
00007026095da449  jmp 0x00007026095DA25A
00007026095da44e  call 0x00007026094E27E0
00007026095da453  jmp 0x00007026095DA292
00007026095da458  call 0x00007026094E1570
00007026095da45d  jmp 0x00007026095DA29E
00007026095da462  call 0x00007026094E27E0
00007026095da467  jmp 0x00007026095DA2DD
00007026095da46c  call 0x000070260940E760
00007026095da471  jmp 0x00007026095DA2FA
00007026095da476  ucomisd xmm1, xmm15
00007026095da47b  jp 0x00007026095DA48A
00007026095da47d  movaps xmm13, [0x00007026091FE060]
00007026095da485  jmp 0x00007026095DA363
00007026095da48a  vxorps xmm0, xmm1, xmm15
00007026095da48f  pextrw eax, xmm0, 0x03
00007026095da494  and eax, 0x7FF8
00007026095da499  cmp eax, 0x08
00007026095da49c  jnz 0x00007026095DA363
00007026095da4a2  movq rax, xmm15
00007026095da4a7  shl rax, 0x0D
00007026095da4ab  jbe 0x00007026095DA363
00007026095da4b1  vorps xmm13, xmm15, [0x00007026091FE070]
00007026095da4b9  jmp 0x00007026095DA363
00007026095da4be  ucomisd xmm1, xmm15
00007026095da4c3  jp 0x00007026095DA4D2
00007026095da4c5  movaps xmm14, [0x00007026091FE060]
00007026095da4cd  jmp 0x00007026095DA390
00007026095da4d2  vxorps xmm0, xmm1, xmm15
00007026095da4d7  pextrw eax, xmm0, 0x03
00007026095da4dc  and eax, 0x7FF8
00007026095da4e1  cmp eax, 0x08
00007026095da4e4  jnz 0x00007026095DA390
00007026095da4ea  movq rax, xmm15
00007026095da4ef  shl rax, 0x0D
00007026095da4f3  jbe 0x00007026095DA390
00007026095da4f9  vorps xmm14, xmm15, [0x00007026091FE070]
00007026095da501  jmp 0x00007026095DA390
00007026095da506  int3
00007026095da507  nop [rax+rax*1], ax
00007026095da510  mov rax, [r15+0x48]
00007026095da514  mov r14, [r15+0x50]
00007026095da518  lea r12, [r14+rax*1]
00007026095da51c  movups xmm1, [r13+r12*1]
00007026095da522  movaps [r15+0x120], xmm1
00007026095da52a  lea r14, [rax+0x10]
00007026095da52e  mov [r15+0x48], r14
00007026095da532  xor eax, eax
00007026095da534  mov r12d, 0x200
00007026095da53a  cmp r14, r12
00007026095da53d  cmc
00007026095da53e  lahf
00007026095da53f  seto al
00007026095da542  mov [r15+0x108], eax
00007026095da549  pextrq rax, xmm1, 0x01
00007026095da550  movq xmm15, rax
00007026095da555  movaps [r15+0x130], xmm15
00007026095da55d  movaps xmm14, [r15+0x110]
00007026095da565  movq rax, xmm14
00007026095da56a  movq r14, xmm1
00007026095da56f  vmovq xmm1, rax
00007026095da574  vmovq xmm14, r14
00007026095da579  movaps xmm13, xmm1
00007026095da57d  addsd xmm13, xmm14
00007026095da582  ucomisd xmm13, xmm13
00007026095da587  jp 0x00007026095DA63C
00007026095da58d  movq xmm13, xmm13
00007026095da592  movq rax, xmm13
00007026095da597  movq r14, xmm15
00007026095da59c  vmovq xmm1, rax
00007026095da5a1  vmovq xmm15, r14
00007026095da5a6  movaps xmm14, xmm1
00007026095da5aa  addsd xmm14, xmm15
00007026095da5af  ucomisd xmm14, xmm14
00007026095da5b4  jp 0x00007026095DA684
00007026095da5ba  movq xmm14, xmm14
00007026095da5bf  movaps [r15+0x110], xmm14
00007026095da5c7  mov eax, [r15+0x108]
00007026095da5ce  sahf
00007026095da5cf  jnz 0x00007026095DA601
00007026095da5d1  cmp dword ptr [r15+0x318], 0x00
00007026095da5d9  jz 0x00007026095DA6D0
00007026095da5df  nop [rax+rax*1], ax
00007026095da5e8  nop [rax+rax*1], eax
00007026095da5f0  mov eax, 0x41043C
00007026095da5f5  mov [r15+0x100], rax
00007026095da5fc  jmp 0x00007026093FE110
00007026095da601  cmp dword ptr [r15+0x318], 0x00
00007026095da609  jz 0x00007026095DA510
00007026095da60f  nop [rax+rax*1], ax
00007026095da618  nop [rax+rax*1], eax
00007026095da620  mov eax, 0x410420
00007026095da625  mov [r15+0x100], rax
00007026095da62c  jmp 0x00007026093FE110
00007026095da631  int3
00007026095da632  call 0x00007026094B52F0
00007026095da637  jmp 0x00007026095DA522
00007026095da63c  ucomisd xmm1, xmm14
00007026095da641  jp 0x00007026095DA650
00007026095da643  movaps xmm13, [0x00007026091FE060]
00007026095da64b  jmp 0x00007026095DA58D
00007026095da650  vxorps xmm0, xmm1, xmm14
00007026095da655  pextrw eax, xmm0, 0x03
00007026095da65a  and eax, 0x7FF8
00007026095da65f  cmp eax, 0x08
00007026095da662  jnz 0x00007026095DA58D
00007026095da668  movq rax, xmm14
00007026095da66d  shl rax, 0x0D
00007026095da671  jbe 0x00007026095DA58D
00007026095da677  vorps xmm13, xmm14, [0x00007026091FE070]
00007026095da67f  jmp 0x00007026095DA58D
00007026095da684  ucomisd xmm1, xmm15
00007026095da689  jp 0x00007026095DA698
00007026095da68b  movaps xmm14, [0x00007026091FE060]
00007026095da693  jmp 0x00007026095DA5BA
00007026095da698  vxorps xmm0, xmm1, xmm15
00007026095da69d  pextrw eax, xmm0, 0x03
00007026095da6a2  and eax, 0x7FF8
00007026095da6a7  cmp eax, 0x08
00007026095da6aa  jnz 0x00007026095DA5BA
00007026095da6b0  movq rax, xmm15
00007026095da6b5  shl rax, 0x0D
00007026095da6b9  jbe 0x00007026095DA5BA
00007026095da6bf  vorps xmm14, xmm15, [0x00007026091FE070]
00007026095da6c7  jmp 0x00007026095DA5BA
00007026095da6cc  int3
00007026095da6cd  nop [rax], eax
00007026095da6d0  mov rax, [r15+0x40]
00007026095da6d4  lea r14, [rax+0x4C0]
00007026095da6db  movaps xmm1, [r15+0x110]
00007026095da6e3  movq rax, xmm1
00007026095da6e8  mov [r13+r14*1], rax
00007026095da6ed  mov rax, [r15+0xF0]
00007026095da6f4  mov [r15+0x100], rax
00007026095da6fb  jmp 0x00007026095CE5C0
00007026095da700  int3
00007026095da701  call 0x00007026094D5EB0
00007026095da706  jmp 0x00007026095DA6ED
00007026095da70b  int3
00007026095da70c  nop [rax], eax
00007026095da710  mov qword ptr [r15+0x100], 0x04
00007026095da71b  mov esi, 0x00
00007026095da720  mov edx, 0x09
00007026095da725  mov rdi, 0x7FFD74186DB0
00007026095da72f  mov rax, 0x58A4320CC970
00007026095da739  call rax
00007026095da73b  cmp dword ptr [r15+0x318], 0x00
00007026095da743  jnz 0x00007026093FE110
00007026095da749  jmp 0x00007026093FE0A0
00007026095da74e  int3
00007026095da74f  int3
