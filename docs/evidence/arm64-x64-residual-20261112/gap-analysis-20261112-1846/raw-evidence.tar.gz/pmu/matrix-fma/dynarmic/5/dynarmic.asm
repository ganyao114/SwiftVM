00007895b19ce69b  nop [rax+rax*1], eax
00007895b19ce6a0  vmovaps xmm1, [0x00007895B15FE010]
00007895b19ce6a8  movq xmm1, xmm1
00007895b19ce6ac  movaps [r15+0x110], xmm1
00007895b19ce6b4  vmovaps xmm1, [0x00007895B15FE020]
00007895b19ce6bc  movq xmm1, xmm1
00007895b19ce6c0  movaps [r15+0x120], xmm1
00007895b19ce6c8  mov eax, 0x420470
00007895b19ce6cd  mov r14, [r13+rax*1]
00007895b19ce6d2  movq xmm1, r14
00007895b19ce6d7  movaps [r15+0x130], xmm1
00007895b19ce6df  vmovaps xmm1, [0x00007895B15FE030]
00007895b19ce6e7  vpbroadcastq xmm1, xmm1
00007895b19ce6ec  movaps [r15+0x140], xmm1
00007895b19ce6f4  mov qword ptr [r15+0x40], 0x02
00007895b19ce6fc  vmovaps xmm15, [0x00007895B15FE040]
00007895b19ce704  movq xmm15, xmm15
00007895b19ce709  movaps [r15+0x150], xmm15
00007895b19ce711  mov qword ptr [r15+0x58], 0x420000
00007895b19ce719  vmovaps xmm15, [0x00007895B15FE050]
00007895b19ce721  vpbroadcastq xmm15, xmm15
00007895b19ce726  movaps [r15+0x160], xmm15
00007895b19ce72e  mov rax, [r15+0x40]
00007895b19ce732  vmovq xmm14, rax
00007895b19ce737  vpbroadcastq xmm14, xmm14
00007895b19ce73c  movaps [r15+0x170], xmm14
00007895b19ce744  mov eax, 0x420480
00007895b19ce749  movups xmm13, [r13+rax*1]
00007895b19ce74f  mov qword ptr [r15+0x40], 0x4304C8
00007895b19ce757  mov qword ptr [r15+0x50], 0x4306D0
00007895b19ce75f  vpmovqd xmm12, xmm13
00007895b19ce765  pxor xmm11, xmm11
00007895b19ce76a  punpcklqdq xmm12, xmm11
00007895b19ce76f  movaps [r15+0x210], xmm12
00007895b19ce777  movq xmm12, qword ptr [r15+0x120]
00007895b19ce780  movq xmm11, qword ptr [r15+0x130]
00007895b19ce789  psubd xmm12, xmm11
00007895b19ce78e  movq xmm12, xmm12
00007895b19ce793  paddq xmm13, xmm14
00007895b19ce798  movaps [r15+0x180], xmm13
00007895b19ce7a0  movq xmm14, qword ptr [r15+0x150]
00007895b19ce7a9  paddd xmm11, xmm14
00007895b19ce7ae  movq xmm11, xmm11
00007895b19ce7b3  movq xmm11, xmm11
00007895b19ce7b8  movaps [r15+0x130], xmm11
00007895b19ce7c0  pmovzxdq xmm12, xmm12
00007895b19ce7c6  psllq xmm12, 0x00
00007895b19ce7cc  movq xmm14, qword ptr [r15+0x210]
00007895b19ce7d5  movq xmm13, qword ptr [r15+0x110]
00007895b19ce7de  paddd xmm14, xmm13
00007895b19ce7e3  movq xmm14, xmm14
00007895b19ce7e8  vcvtuqq2pd xmm12, xmm12
00007895b19ce7ee  pmovzxdq xmm14, xmm14
00007895b19ce7f4  psllq xmm14, 0x00
00007895b19ce7fa  vcvtuqq2pd xmm14, xmm14
00007895b19ce800  movaps xmm13, xmm12
00007895b19ce804  mulpd xmm13, xmm1
00007895b19ce809  vcmppd xmm11, xmm13, xmm13, 0x03
00007895b19ce80f  ptest xmm11, xmm11
00007895b19ce815  jnz 0x00007895B19CE8FF
00007895b19ce81b  movaps [r15+0x220], xmm13
00007895b19ce823  mov eax, 0x4306D0
00007895b19ce828  movups [r13+rax*1], xmm13
00007895b19ce82e  movaps xmm1, xmm14
00007895b19ce832  mulpd xmm1, xmm15
00007895b19ce837  vcmppd xmm13, xmm1, xmm1, 0x03
00007895b19ce83c  ptest xmm13, xmm13
00007895b19ce842  jnz 0x00007895B19CEA4C
00007895b19ce848  movaps [r15+0x210], xmm1
00007895b19ce850  mov eax, 0x4304C8
00007895b19ce855  movups [r13+rax*1], xmm1
00007895b19ce85b  mov qword ptr [r15+0x48], 0x10
00007895b19ce863  xor eax, eax
00007895b19ce865  mov r14d, 0x10
00007895b19ce86b  mov r12d, 0x200
00007895b19ce871  cmp r14, r12
00007895b19ce874  cmc
00007895b19ce875  lahf
00007895b19ce876  seto al
00007895b19ce879  mov [r15+0x108], eax
00007895b19ce880  mov eax, [r15+0x108]
00007895b19ce887  sahf
00007895b19ce888  jnz 0x00007895B19CE8BA
00007895b19ce88a  cmp dword ptr [r15+0x318], 0x00
00007895b19ce892  jz 0x00007895B19CEFF0
00007895b19ce898  nop [rax+rax*1], ax
00007895b19ce8a1  nop [rax+rax*1], eax
00007895b19ce8a9  mov eax, 0x4101EC
00007895b19ce8ae  mov [r15+0x100], rax
00007895b19ce8b5  jmp 0x00007895B17FE110
00007895b19ce8ba  cmp dword ptr [r15+0x318], 0x00
00007895b19ce8c2  jz 0x00007895B19CEBA0
00007895b19ce8c8  nop [rax+rax*1], ax
00007895b19ce8d1  nop [rax+rax*1], eax
00007895b19ce8d9  mov eax, 0x4101AC
00007895b19ce8de  mov [r15+0x100], rax
00007895b19ce8e5  jmp 0x00007895B17FE110
00007895b19ce8ea  int3
00007895b19ce8eb  call 0x00007895B180DC20
00007895b19ce8f0  jmp 0x00007895B19CE6D2
00007895b19ce8f5  call 0x00007895B180C260
00007895b19ce8fa  jmp 0x00007895B19CE74F
00007895b19ce8ff  sub rsp, 0x08
00007895b19ce903  push rax
00007895b19ce904  push rcx
00007895b19ce905  push rdx
00007895b19ce906  push rdi
00007895b19ce907  push rsi
00007895b19ce908  push r8
00007895b19ce90a  push r9
00007895b19ce90c  push r10
00007895b19ce90e  push r11
00007895b19ce910  sub rsp, 0xF0
00007895b19ce917  vmovaps [rsp], xmm0
00007895b19ce91c  vmovaps [rsp+0x10], xmm1
00007895b19ce922  vmovaps [rsp+0x20], xmm2
00007895b19ce928  vmovaps [rsp+0x30], xmm3
00007895b19ce92e  vmovaps [rsp+0x40], xmm4
00007895b19ce934  vmovaps [rsp+0x50], xmm5
00007895b19ce93a  vmovaps [rsp+0x60], xmm6
00007895b19ce940  vmovaps [rsp+0x70], xmm7
00007895b19ce946  vmovaps [rsp+0x80], xmm8
00007895b19ce94f  vmovaps [rsp+0x90], xmm9
00007895b19ce958  vmovaps [rsp+0xA0], xmm10
00007895b19ce961  vmovaps [rsp+0xB0], xmm11
00007895b19ce96a  vmovaps [rsp+0xC0], xmm12
00007895b19ce973  vmovaps [rsp+0xD0], xmm14
00007895b19ce97c  vmovaps [rsp+0xE0], xmm15
00007895b19ce985  sub rsp, 0x30
00007895b19ce989  movaps [rsp], xmm13
00007895b19ce98e  movaps [rsp+0x10], xmm12
00007895b19ce994  movaps [rsp+0x20], xmm1
00007895b19ce999  lea rdi, [rsp]
00007895b19ce99d  mov esi, 0x00
00007895b19ce9a2  mov rax, 0x59D4522A9530
00007895b19ce9ac  call rax
00007895b19ce9ae  movaps xmm13, [rsp]
00007895b19ce9b3  add rsp, 0x30
00007895b19ce9b7  vmovaps xmm0, [rsp]
00007895b19ce9bc  vmovaps xmm1, [rsp+0x10]
00007895b19ce9c2  vmovaps xmm2, [rsp+0x20]
00007895b19ce9c8  vmovaps xmm3, [rsp+0x30]
00007895b19ce9ce  vmovaps xmm4, [rsp+0x40]
00007895b19ce9d4  vmovaps xmm5, [rsp+0x50]
00007895b19ce9da  vmovaps xmm6, [rsp+0x60]
00007895b19ce9e0  vmovaps xmm7, [rsp+0x70]
00007895b19ce9e6  vmovaps xmm8, [rsp+0x80]
00007895b19ce9ef  vmovaps xmm9, [rsp+0x90]
00007895b19ce9f8  vmovaps xmm10, [rsp+0xA0]
00007895b19cea01  vmovaps xmm11, [rsp+0xB0]
00007895b19cea0a  vmovaps xmm12, [rsp+0xC0]
00007895b19cea13  vmovaps xmm14, [rsp+0xD0]
00007895b19cea1c  vmovaps xmm15, [rsp+0xE0]
00007895b19cea25  add rsp, 0xF0
00007895b19cea2c  pop r11
00007895b19cea2e  pop r10
00007895b19cea30  pop r9
00007895b19cea32  pop r8
00007895b19cea34  pop rsi
00007895b19cea35  pop rdi
00007895b19cea36  pop rdx
00007895b19cea37  pop rcx
00007895b19cea38  pop rax
00007895b19cea39  add rsp, 0x08
00007895b19cea3d  jmp 0x00007895B19CE81B
00007895b19cea42  call 0x00007895B180C380
00007895b19cea47  jmp 0x00007895B19CE82E
00007895b19cea4c  sub rsp, 0x08
00007895b19cea50  push rax
00007895b19cea51  push rcx
00007895b19cea52  push rdx
00007895b19cea53  push rdi
00007895b19cea54  push rsi
00007895b19cea55  push r8
00007895b19cea57  push r9
00007895b19cea59  push r10
00007895b19cea5b  push r11
00007895b19cea5d  sub rsp, 0xF0
00007895b19cea64  vmovaps [rsp], xmm0
00007895b19cea69  vmovaps [rsp+0x10], xmm2
00007895b19cea6f  vmovaps [rsp+0x20], xmm3
00007895b19cea75  vmovaps [rsp+0x30], xmm4
00007895b19cea7b  vmovaps [rsp+0x40], xmm5
00007895b19cea81  vmovaps [rsp+0x50], xmm6
00007895b19cea87  vmovaps [rsp+0x60], xmm7
00007895b19cea8d  vmovaps [rsp+0x70], xmm8
00007895b19cea93  vmovaps [rsp+0x80], xmm9
00007895b19cea9c  vmovaps [rsp+0x90], xmm10
00007895b19ceaa5  vmovaps [rsp+0xA0], xmm11
00007895b19ceaae  vmovaps [rsp+0xB0], xmm12
00007895b19ceab7  vmovaps [rsp+0xC0], xmm13
00007895b19ceac0  vmovaps [rsp+0xD0], xmm14
00007895b19ceac9  vmovaps [rsp+0xE0], xmm15
00007895b19cead2  sub rsp, 0x30
00007895b19cead6  movaps [rsp], xmm1
00007895b19ceada  movaps [rsp+0x10], xmm14
00007895b19ceae0  movaps [rsp+0x20], xmm15
00007895b19ceae6  lea rdi, [rsp]
00007895b19ceaea  mov esi, 0x00
00007895b19ceaef  mov rax, 0x59D4522A9530
00007895b19ceaf9  call rax
00007895b19ceafb  movaps xmm1, [rsp]
00007895b19ceaff  add rsp, 0x30
00007895b19ceb03  vmovaps xmm0, [rsp]
00007895b19ceb08  vmovaps xmm2, [rsp+0x10]
00007895b19ceb0e  vmovaps xmm3, [rsp+0x20]
00007895b19ceb14  vmovaps xmm4, [rsp+0x30]
00007895b19ceb1a  vmovaps xmm5, [rsp+0x40]
00007895b19ceb20  vmovaps xmm6, [rsp+0x50]
00007895b19ceb26  vmovaps xmm7, [rsp+0x60]
00007895b19ceb2c  vmovaps xmm8, [rsp+0x70]
00007895b19ceb32  vmovaps xmm9, [rsp+0x80]
00007895b19ceb3b  vmovaps xmm10, [rsp+0x90]
00007895b19ceb44  vmovaps xmm11, [rsp+0xA0]
00007895b19ceb4d  vmovaps xmm12, [rsp+0xB0]
00007895b19ceb56  vmovaps xmm13, [rsp+0xC0]
00007895b19ceb5f  vmovaps xmm14, [rsp+0xD0]
00007895b19ceb68  vmovaps xmm15, [rsp+0xE0]
00007895b19ceb71  add rsp, 0xF0
00007895b19ceb78  pop r11
00007895b19ceb7a  pop r10
00007895b19ceb7c  pop r9
00007895b19ceb7e  pop r8
00007895b19ceb80  pop rsi
00007895b19ceb81  pop rdi
00007895b19ceb82  pop rdx
00007895b19ceb83  pop rcx
00007895b19ceb84  pop rax
00007895b19ceb85  add rsp, 0x08
00007895b19ceb89  jmp 0x00007895B19CE848
00007895b19ceb8e  call 0x00007895B17FF540
00007895b19ceb93  jmp 0x00007895B19CE85B
00007895b19ceb98  int3
00007895b19ceb99  nop [rax], eax
00007895b19ceba0  movaps xmm1, [r15+0x180]
00007895b19ceba8  vpmovqd xmm15, xmm1
00007895b19cebae  pxor xmm14, xmm14
00007895b19cebb3  punpcklqdq xmm15, xmm14
00007895b19cebb8  movaps [r15+0x210], xmm15
00007895b19cebc0  movq xmm15, qword ptr [r15+0x120]
00007895b19cebc9  movq xmm14, qword ptr [r15+0x130]
00007895b19cebd2  psubd xmm15, xmm14
00007895b19cebd7  movq xmm15, xmm15
00007895b19cebdc  movaps xmm13, [r15+0x170]
00007895b19cebe4  paddq xmm1, xmm13
00007895b19cebe9  movaps [r15+0x180], xmm1
00007895b19cebf1  movq xmm1, qword ptr [r15+0x150]
00007895b19cebfa  paddd xmm14, xmm1
00007895b19cebff  movq xmm14, xmm14
00007895b19cec04  movq xmm14, xmm14
00007895b19cec09  movaps [r15+0x130], xmm14
00007895b19cec11  pmovzxdq xmm15, xmm15
00007895b19cec17  psllq xmm15, 0x00
00007895b19cec1d  movq xmm1, qword ptr [r15+0x210]
00007895b19cec26  movq xmm14, qword ptr [r15+0x110]
00007895b19cec2f  paddd xmm1, xmm14
00007895b19cec34  movq xmm1, xmm1
00007895b19cec38  vcvtuqq2pd xmm15, xmm15
00007895b19cec3e  pmovzxdq xmm1, xmm1
00007895b19cec43  psllq xmm1, 0x00
00007895b19cec48  vcvtuqq2pd xmm1, xmm1
00007895b19cec4e  movaps xmm14, [r15+0x140]
00007895b19cec56  movaps xmm13, xmm15
00007895b19cec5a  mulpd xmm13, xmm14
00007895b19cec5f  vcmppd xmm12, xmm13, xmm13, 0x03
00007895b19cec65  ptest xmm12, xmm12
00007895b19cec6b  jnz 0x00007895B19CED4E
00007895b19cec71  movaps [r15+0x220], xmm13
00007895b19cec79  mov rax, [r15+0x48]
00007895b19cec7d  mov r14, [r15+0x50]
00007895b19cec81  lea r12, [r14+rax*1]
00007895b19cec85  movups [r13+r12*1], xmm13
00007895b19cec8b  movaps xmm15, [r15+0x160]
00007895b19cec93  movaps xmm14, xmm1
00007895b19cec97  mulpd xmm14, xmm15
00007895b19cec9c  vcmppd xmm13, xmm14, xmm14, 0x03
00007895b19ceca2  ptest xmm13, xmm13
00007895b19ceca8  jnz 0x00007895B19CEE9C
00007895b19cecae  movaps [r15+0x210], xmm14
00007895b19cecb6  mov r14, [r15+0x40]
00007895b19cecba  lea r12, [r14+rax*1]
00007895b19cecbe  movups [r13+r12*1], xmm14
00007895b19cecc4  lea r14, [rax+0x10]
00007895b19cecc8  mov [r15+0x48], r14
00007895b19ceccc  xor eax, eax
00007895b19cecce  mov r12d, 0x200
00007895b19cecd4  cmp r14, r12
00007895b19cecd7  cmc
00007895b19cecd8  lahf
00007895b19cecd9  seto al
00007895b19cecdc  mov [r15+0x108], eax
00007895b19cece3  mov eax, [r15+0x108]
00007895b19cecea  sahf
00007895b19ceceb  jnz 0x00007895B19CED1D
00007895b19ceced  cmp dword ptr [r15+0x318], 0x00
00007895b19cecf5  jz 0x00007895B19CEFF0
00007895b19cecfb  nop [rax+rax*1], ax
00007895b19ced04  nop [rax+rax*1], eax
00007895b19ced0c  mov eax, 0x4101EC
00007895b19ced11  mov [r15+0x100], rax
00007895b19ced18  jmp 0x00007895B17FE110
00007895b19ced1d  cmp dword ptr [r15+0x318], 0x00
00007895b19ced25  jz 0x00007895B19CEBA0
00007895b19ced2b  nop [rax+rax*1], ax
00007895b19ced34  nop [rax+rax*1], eax
00007895b19ced3c  mov eax, 0x4101AC
00007895b19ced41  mov [r15+0x100], rax
00007895b19ced48  jmp 0x00007895B17FE110
00007895b19ced4d  int3
00007895b19ced4e  sub rsp, 0x08
00007895b19ced52  push rax
00007895b19ced53  push rcx
00007895b19ced54  push rdx
00007895b19ced55  push rdi
00007895b19ced56  push rsi
00007895b19ced57  push r8
00007895b19ced59  push r9
00007895b19ced5b  push r10
00007895b19ced5d  push r11
00007895b19ced5f  sub rsp, 0xF0
00007895b19ced66  vmovaps [rsp], xmm0
00007895b19ced6b  vmovaps [rsp+0x10], xmm1
00007895b19ced71  vmovaps [rsp+0x20], xmm2
00007895b19ced77  vmovaps [rsp+0x30], xmm3
00007895b19ced7d  vmovaps [rsp+0x40], xmm4
00007895b19ced83  vmovaps [rsp+0x50], xmm5
00007895b19ced89  vmovaps [rsp+0x60], xmm6
00007895b19ced8f  vmovaps [rsp+0x70], xmm7
00007895b19ced95  vmovaps [rsp+0x80], xmm8
00007895b19ced9e  vmovaps [rsp+0x90], xmm9
00007895b19ceda7  vmovaps [rsp+0xA0], xmm10
00007895b19cedb0  vmovaps [rsp+0xB0], xmm11
00007895b19cedb9  vmovaps [rsp+0xC0], xmm12
00007895b19cedc2  vmovaps [rsp+0xD0], xmm14
00007895b19cedcb  vmovaps [rsp+0xE0], xmm15
00007895b19cedd4  sub rsp, 0x30
00007895b19cedd8  movaps [rsp], xmm13
00007895b19ceddd  movaps [rsp+0x10], xmm15
00007895b19cede3  movaps [rsp+0x20], xmm14
00007895b19cede9  lea rdi, [rsp]
00007895b19ceded  mov esi, 0x00
00007895b19cedf2  mov rax, 0x59D4522A9530
00007895b19cedfc  call rax
00007895b19cedfe  movaps xmm13, [rsp]
00007895b19cee03  add rsp, 0x30
00007895b19cee07  vmovaps xmm0, [rsp]
00007895b19cee0c  vmovaps xmm1, [rsp+0x10]
00007895b19cee12  vmovaps xmm2, [rsp+0x20]
00007895b19cee18  vmovaps xmm3, [rsp+0x30]
00007895b19cee1e  vmovaps xmm4, [rsp+0x40]
00007895b19cee24  vmovaps xmm5, [rsp+0x50]
00007895b19cee2a  vmovaps xmm6, [rsp+0x60]
00007895b19cee30  vmovaps xmm7, [rsp+0x70]
00007895b19cee36  vmovaps xmm8, [rsp+0x80]
00007895b19cee3f  vmovaps xmm9, [rsp+0x90]
00007895b19cee48  vmovaps xmm10, [rsp+0xA0]
00007895b19cee51  vmovaps xmm11, [rsp+0xB0]
00007895b19cee5a  vmovaps xmm12, [rsp+0xC0]
00007895b19cee63  vmovaps xmm14, [rsp+0xD0]
00007895b19cee6c  vmovaps xmm15, [rsp+0xE0]
00007895b19cee75  add rsp, 0xF0
00007895b19cee7c  pop r11
00007895b19cee7e  pop r10
00007895b19cee80  pop r9
00007895b19cee82  pop r8
00007895b19cee84  pop rsi
00007895b19cee85  pop rdi
00007895b19cee86  pop rdx
00007895b19cee87  pop rcx
00007895b19cee88  pop rax
00007895b19cee89  add rsp, 0x08
00007895b19cee8d  jmp 0x00007895B19CEC71
00007895b19cee92  call 0x00007895B18C2240
00007895b19cee97  jmp 0x00007895B19CEC8B
00007895b19cee9c  sub rsp, 0x08
00007895b19ceea0  push rax
00007895b19ceea1  push rcx
00007895b19ceea2  push rdx
00007895b19ceea3  push rdi
00007895b19ceea4  push rsi
00007895b19ceea5  push r8
00007895b19ceea7  push r9
00007895b19ceea9  push r10
00007895b19ceeab  push r11
00007895b19ceead  sub rsp, 0xF0
00007895b19ceeb4  vmovaps [rsp], xmm0
00007895b19ceeb9  vmovaps [rsp+0x10], xmm1
00007895b19ceebf  vmovaps [rsp+0x20], xmm2
00007895b19ceec5  vmovaps [rsp+0x30], xmm3
00007895b19ceecb  vmovaps [rsp+0x40], xmm4
00007895b19ceed1  vmovaps [rsp+0x50], xmm5
00007895b19ceed7  vmovaps [rsp+0x60], xmm6
00007895b19ceedd  vmovaps [rsp+0x70], xmm7
00007895b19ceee3  vmovaps [rsp+0x80], xmm8
00007895b19ceeec  vmovaps [rsp+0x90], xmm9
00007895b19ceef5  vmovaps [rsp+0xA0], xmm10
00007895b19ceefe  vmovaps [rsp+0xB0], xmm11
00007895b19cef07  vmovaps [rsp+0xC0], xmm12
00007895b19cef10  vmovaps [rsp+0xD0], xmm13
00007895b19cef19  vmovaps [rsp+0xE0], xmm15
00007895b19cef22  sub rsp, 0x30
00007895b19cef26  movaps [rsp], xmm14
00007895b19cef2b  movaps [rsp+0x10], xmm1
00007895b19cef30  movaps [rsp+0x20], xmm15
00007895b19cef36  lea rdi, [rsp]
00007895b19cef3a  mov esi, 0x00
00007895b19cef3f  mov rax, 0x59D4522A9530
00007895b19cef49  call rax
00007895b19cef4b  movaps xmm14, [rsp]
00007895b19cef50  add rsp, 0x30
00007895b19cef54  vmovaps xmm0, [rsp]
00007895b19cef59  vmovaps xmm1, [rsp+0x10]
00007895b19cef5f  vmovaps xmm2, [rsp+0x20]
00007895b19cef65  vmovaps xmm3, [rsp+0x30]
00007895b19cef6b  vmovaps xmm4, [rsp+0x40]
00007895b19cef71  vmovaps xmm5, [rsp+0x50]
00007895b19cef77  vmovaps xmm6, [rsp+0x60]
00007895b19cef7d  vmovaps xmm7, [rsp+0x70]
00007895b19cef83  vmovaps xmm8, [rsp+0x80]
00007895b19cef8c  vmovaps xmm9, [rsp+0x90]
00007895b19cef95  vmovaps xmm10, [rsp+0xA0]
00007895b19cef9e  vmovaps xmm11, [rsp+0xB0]
00007895b19cefa7  vmovaps xmm12, [rsp+0xC0]
00007895b19cefb0  vmovaps xmm13, [rsp+0xD0]
00007895b19cefb9  vmovaps xmm15, [rsp+0xE0]
00007895b19cefc2  add rsp, 0xF0
00007895b19cefc9  pop r11
00007895b19cefcb  pop r10
00007895b19cefcd  pop r9
00007895b19cefcf  pop r8
00007895b19cefd1  pop rsi
00007895b19cefd2  pop rdi
00007895b19cefd3  pop rdx
00007895b19cefd4  pop rcx
00007895b19cefd5  pop rax
00007895b19cefd6  add rsp, 0x08
00007895b19cefda  jmp 0x00007895B19CECAE
00007895b19cefdf  call 0x00007895B18C34C0
00007895b19cefe4  jmp 0x00007895B19CECC4
00007895b19cefe9  int3
00007895b19cefea  nop [rax+rax*1], ax
00007895b19ceff0  mov rax, [r15+0xF8]
00007895b19ceff7  lea r14, [rax-0x120]
00007895b19ceffe  mov [r15+0xF8], r14
00007895b19cf005  mov rax, [r15+0x50]
00007895b19cf009  movups xmm1, [r13+rax*1]
00007895b19cf00f  lea r12, [rax+0x10]
00007895b19cf013  movups xmm15, [r13+r12*1]
00007895b19cf019  mov qword ptr [r15+0x48], 0x00
00007895b19cf021  lea r12, [r14+0xD0]
00007895b19cf028  movq xmm14, qword ptr [r15+0x200]
00007895b19cf031  movq xmm13, qword ptr [r15+0x1F0]
00007895b19cf03a  movq r11, xmm14
00007895b19cf03f  movq r10, xmm13
00007895b19cf044  mov [r13+r12*1], r11
00007895b19cf049  lea r12, [r14+0xD8]
00007895b19cf050  mov [r13+r12*1], r10
00007895b19cf055  lea r12, [rax+0x80]
00007895b19cf05c  movups xmm14, [r13+r12*1]
00007895b19cf062  lea r12, [rax+0x90]
00007895b19cf069  movups xmm13, [r13+r12*1]
00007895b19cf06f  lea r12, [r14+0xE0]
00007895b19cf076  movq xmm12, qword ptr [r15+0x1E0]
00007895b19cf07f  movq xmm11, qword ptr [r15+0x1D0]
00007895b19cf088  movq r11, xmm12
00007895b19cf08d  movq r10, xmm11
00007895b19cf092  mov [r13+r12*1], r11
00007895b19cf097  lea r12, [r14+0xE8]
00007895b19cf09e  mov [r13+r12*1], r10
00007895b19cf0a3  lea r12, [rax+0xC0]
00007895b19cf0aa  movups xmm12, [r13+r12*1]
00007895b19cf0b0  lea r12, [rax+0xD0]
00007895b19cf0b7  movups xmm11, [r13+r12*1]
00007895b19cf0bd  movups [r13+r14*1], xmm1
00007895b19cf0c3  lea r12, [rax+0x20]
00007895b19cf0c7  movups xmm1, [r13+r12*1]
00007895b19cf0cd  lea r12, [rax+0x30]
00007895b19cf0d1  movups xmm10, [r13+r12*1]
00007895b19cf0d7  lea r12, [r14+0xF0]
00007895b19cf0de  movq xmm9, qword ptr [r15+0x1C0]
00007895b19cf0e7  movq xmm8, qword ptr [r15+0x1B0]
00007895b19cf0f0  movq r11, xmm9
00007895b19cf0f5  movq r10, xmm8
00007895b19cf0fa  mov [r13+r12*1], r11
00007895b19cf0ff  lea r12, [r14+0xF8]
00007895b19cf106  mov [r13+r12*1], r10
00007895b19cf10b  lea r12, [rax+0x40]
00007895b19cf10f  movups xmm9, [r13+r12*1]
00007895b19cf115  lea r12, [rax+0x50]
00007895b19cf119  movups xmm8, [r13+r12*1]
00007895b19cf11f  lea r12, [r14+0x100]
00007895b19cf126  movq xmm7, qword ptr [r15+0x1A0]
00007895b19cf12f  movq xmm6, qword ptr [r15+0x190]
00007895b19cf138  movq r11, xmm7
00007895b19cf13d  movq r10, xmm6
00007895b19cf142  mov [r13+r12*1], r11
00007895b19cf147  lea r12, [r14+0x108]
00007895b19cf14e  mov [r13+r12*1], r10
00007895b19cf153  lea r12, [rax+0x100]
00007895b19cf15a  movups xmm7, [r13+r12*1]
00007895b19cf160  lea r12, [rax+0x110]
00007895b19cf167  movups xmm6, [r13+r12*1]
00007895b19cf16d  lea r12, [r14+0xB0]
00007895b19cf174  movups [r13+r12*1], xmm10
00007895b19cf17a  lea r12, [r14+0xC0]
00007895b19cf181  movups [r13+r12*1], xmm1
00007895b19cf187  lea r12, [rax+0x140]
00007895b19cf18e  movups xmm1, [r13+r12*1]
00007895b19cf194  lea r12, [rax+0x150]
00007895b19cf19b  movups xmm10, [r13+r12*1]
00007895b19cf1a1  lea r12, [r14+0x110]
00007895b19cf1a8  mov r11, [r15+0xE8]
00007895b19cf1af  mov [r13+r12*1], r11
00007895b19cf1b4  lea r12, [rax+0x180]
00007895b19cf1bb  movups xmm5, [r13+r12*1]
00007895b19cf1c1  lea r12, [rax+0x190]
00007895b19cf1c8  movups xmm4, [r13+r12*1]
00007895b19cf1ce  lea r12, [rax+0x1C0]
00007895b19cf1d5  movups xmm3, [r13+r12*1]
00007895b19cf1db  lea r12, [rax+0x1D0]
00007895b19cf1e2  movups xmm2, [r13+r12*1]
00007895b19cf1e8  lea r12, [rax+0x60]
00007895b19cf1ec  vmovaps [rsp+0x10], xmm1
00007895b19cf1f2  movups xmm1, [r13+r12*1]
00007895b19cf1f8  lea r12, [rax+0x70]
00007895b19cf1fc  vmovaps [rsp+0x20], xmm1
00007895b19cf202  movups xmm1, [r13+r12*1]
00007895b19cf208  lea r12, [r14+0x70]
00007895b19cf20c  movups [r13+r12*1], xmm4
00007895b19cf212  lea r12, [r14+0x80]
00007895b19cf219  movups [r13+r12*1], xmm5
00007895b19cf21f  lea r12, [rax+0xA0]
00007895b19cf226  movups xmm5, [r13+r12*1]
00007895b19cf22c  lea r12, [rax+0xB0]
00007895b19cf233  movups xmm4, [r13+r12*1]
00007895b19cf239  lea r12, [r14+0x90]
00007895b19cf240  movups [r13+r12*1], xmm2
00007895b19cf246  lea r12, [r14+0xA0]
00007895b19cf24d  movups [r13+r12*1], xmm3
00007895b19cf253  lea r12, [rax+0xE0]
00007895b19cf25a  movups xmm3, [r13+r12*1]
00007895b19cf260  lea r12, [rax+0xF0]
00007895b19cf267  movups xmm2, [r13+r12*1]
00007895b19cf26d  lea r12, [rax+0x120]
00007895b19cf274  vmovaps [rsp+0x30], xmm1
00007895b19cf27a  movups xmm1, [r13+r12*1]
00007895b19cf280  lea r12, [rax+0x130]
00007895b19cf287  vmovaps [rsp+0x40], xmm1
00007895b19cf28d  movups xmm1, [r13+r12*1]
00007895b19cf293  lea r12, [rax+0x160]
00007895b19cf29a  vmovaps [rsp+0x50], xmm1
00007895b19cf2a0  movups xmm1, [r13+r12*1]
00007895b19cf2a6  lea r12, [rax+0x170]
00007895b19cf2ad  vmovaps [rsp+0x60], xmm1
00007895b19cf2b3  movups xmm1, [r13+r12*1]
00007895b19cf2b9  lea r12, [rax+0x1A0]
00007895b19cf2c0  vmovaps [rsp+0x70], xmm1
00007895b19cf2c6  movups xmm1, [r13+r12*1]
00007895b19cf2cc  lea r12, [rax+0x1B0]
00007895b19cf2d3  vmovaps [rsp+0x80], xmm1
00007895b19cf2dc  movups xmm1, [r13+r12*1]
00007895b19cf2e2  lea r12, [rax+0x1E0]
00007895b19cf2e9  vmovaps [rsp+0x90], xmm1
00007895b19cf2f2  movups xmm1, [r13+r12*1]
00007895b19cf2f8  lea r12, [rax+0x1F0]
00007895b19cf2ff  vmovaps [rsp+0xA0], xmm1
00007895b19cf308  movups xmm1, [r13+r12*1]
00007895b19cf30e  mov qword ptr [r15+0x50], 0x4308D0
00007895b19cf316  lea rax, [r14+0x50]
00007895b19cf31a  vmovaps [rsp+0xB0], xmm1
00007895b19cf323  vmovaps xmm1, [rsp+0x60]
00007895b19cf329  movups [r13+rax*1], xmm1
00007895b19cf32f  lea rax, [r14+0x60]
00007895b19cf333  vmovaps xmm1, [rsp+0x10]
00007895b19cf339  movups [r13+rax*1], xmm1
00007895b19cf33f  lea rax, [r14+0x40]
00007895b19cf343  vmovaps xmm1, [rsp+0x70]
00007895b19cf349  movups [r13+rax*1], xmm1
00007895b19cf34f  lea rax, [r14+0x20]
00007895b19cf353  vmovaps xmm1, [rsp+0xA0]
00007895b19cf35c  movups [r13+rax*1], xmm1
00007895b19cf362  lea rax, [r14+0x30]
00007895b19cf366  vmovaps xmm1, [rsp+0x90]
00007895b19cf36f  movups [r13+rax*1], xmm1
00007895b19cf375  lea rax, [r14+0x10]
00007895b19cf379  vmovaps xmm1, [rsp+0xB0]
00007895b19cf382  movups [r13+rax*1], xmm1
00007895b19cf388  mov rax, [r15+0x40]
00007895b19cf38c  vxorps xmm1, xmm1, xmm1
00007895b19cf390  vpbroadcastq xmm1, xmm1
00007895b19cf395  vmovaps [rsp+0x10], xmm1
00007895b19cf39b  vxorps xmm1, xmm1, xmm1
00007895b19cf39f  vpbroadcastq xmm1, xmm1
00007895b19cf3a4  lea r12, [rax+0x30]
00007895b19cf3a8  mov r11, [r13+r12*1]
00007895b19cf3ad  lea r12, [rax+0x38]
00007895b19cf3b1  mov r10, [r13+r12*1]
00007895b19cf3b6  vmovaps [rsp+0x60], xmm1
00007895b19cf3bc  movq xmm1, r11
00007895b19cf3c1  vmovaps [rsp+0x70], xmm1
00007895b19cf3c7  movq xmm1, r10
00007895b19cf3cc  vmovaps [rsp+0x90], xmm1
00007895b19cf3d5  vmovaps xmm1, [rsp+0x70]
00007895b19cf3db  movq xmm1, xmm1
00007895b19cf3df  vmovaps [rsp+0x70], xmm1
00007895b19cf3e5  vmovaps xmm1, [rsp+0x90]
00007895b19cf3ee  movq xmm1, xmm1
00007895b19cf3f2  vmovaps [rsp+0x90], xmm1
00007895b19cf3fb  movq xmm1, xmm1
00007895b19cf3ff  movaps [r15+0x270], xmm1
00007895b19cf407  vmovaps [rsp+0xA0], xmm7
00007895b19cf410  vmovaps xmm1, [rsp+0xA0]
00007895b19cf419  por xmm7, xmm1
00007895b19cf41d  lea r12, [rax+0x20]
00007895b19cf421  mov r11, [r13+r12*1]
00007895b19cf426  lea r12, [rax+0x28]
00007895b19cf42a  mov r10, [r13+r12*1]
00007895b19cf42f  movq xmm1, r11
00007895b19cf434  vmovaps [rsp+0xA0], xmm1
00007895b19cf43d  movq xmm1, r10
00007895b19cf442  vmovaps [rsp+0xB0], xmm1
00007895b19cf44b  vmovaps xmm1, [rsp+0xA0]
00007895b19cf454  movq xmm1, xmm1
00007895b19cf458  vmovaps [rsp+0xA0], xmm1
00007895b19cf461  vmovaps xmm1, [rsp+0xB0]
00007895b19cf46a  movq xmm1, xmm1
00007895b19cf46e  vmovaps [rsp+0xB0], xmm2
00007895b19cf477  vmovaps [rsp+0xC0], xmm1
00007895b19cf480  vmovaps xmm1, [rsp+0xB0]
00007895b19cf489  por xmm2, xmm1
00007895b19cf48d  vmovaps xmm1, [rsp+0x40]
00007895b19cf493  vmovaps [rsp+0xB0], xmm15
00007895b19cf49c  vmovaps xmm15, [rsp+0x40]
00007895b19cf4a2  por xmm1, xmm15
00007895b19cf4a7  vmovaps [rsp+0x40], xmm3
00007895b19cf4ad  vmovaps xmm15, [rsp+0x40]
00007895b19cf4b3  por xmm3, xmm15
00007895b19cf4b8  vmovaps [rsp+0x40], xmm10
00007895b19cf4be  vmovaps xmm15, [rsp+0x40]
00007895b19cf4c4  por xmm10, xmm15
00007895b19cf4c9  vmovaps [rsp+0x40], xmm12
00007895b19cf4cf  vmovaps xmm15, [rsp+0x40]
00007895b19cf4d5  por xmm12, xmm15
00007895b19cf4da  lea r12, [rax+0x10]
00007895b19cf4de  mov r11, [r13+r12*1]
00007895b19cf4e3  lea r12, [rax+0x18]
00007895b19cf4e7  mov r10, [r13+r12*1]
00007895b19cf4ec  movq xmm15, r11
00007895b19cf4f1  vmovaps [rsp+0x40], xmm1
00007895b19cf4f7  movq xmm1, r10
00007895b19cf4fc  movq xmm15, xmm15
00007895b19cf501  movq xmm1, xmm1
00007895b19cf505  vmovaps [rsp+0xD0], xmm1
00007895b19cf50e  vmovaps xmm1, [rsp+0x80]
00007895b19cf517  vmovaps [rsp+0xE0], xmm15
00007895b19cf520  vmovaps xmm15, [rsp+0x80]
00007895b19cf529  por xmm1, xmm15
00007895b19cf52e  vmovaps xmm15, [rsp+0x30]
00007895b19cf534  vmovaps [rsp+0x80], xmm1
00007895b19cf53d  vmovaps xmm1, [rsp+0x30]
00007895b19cf543  por xmm15, xmm1
00007895b19cf548  vmovaps xmm1, [rsp+0x20]
00007895b19cf54e  vmovaps [rsp+0x30], xmm15
00007895b19cf554  vmovaps xmm15, [rsp+0x20]
00007895b19cf55a  por xmm1, xmm15
00007895b19cf55f  vmovaps [rsp+0x20], xmm6
00007895b19cf565  vmovaps xmm15, [rsp+0x20]
00007895b19cf56b  por xmm6, xmm15
00007895b19cf570  vmovaps [rsp+0x20], xmm13
00007895b19cf576  vmovaps xmm15, [rsp+0x20]
00007895b19cf57c  por xmm13, xmm15
00007895b19cf581  vmovaps [rsp+0x20], xmm8
00007895b19cf587  vmovaps xmm15, [rsp+0x20]
00007895b19cf58d  por xmm8, xmm15
00007895b19cf592  vmovaps [rsp+0x20], xmm9
00007895b19cf598  vmovaps xmm15, [rsp+0x20]
00007895b19cf59e  por xmm9, xmm15
00007895b19cf5a3  mov r12, [r13+rax*1]
00007895b19cf5a8  vmovq xmm15, r12
00007895b19cf5ad  vpbroadcastq xmm15, xmm15
00007895b19cf5b2  vmovaps [rsp+0x20], xmm1
00007895b19cf5b8  vxorps xmm1, xmm1, xmm1
00007895b19cf5bc  vpbroadcastq xmm1, xmm1
00007895b19cf5c1  vmovaps [rsp+0xF0], xmm1
00007895b19cf5ca  movups xmm1, [r13+r14*1]
00007895b19cf5d0  vmovaps [rsp+0x100], xmm1
00007895b19cf5d9  vxorps xmm1, xmm1, xmm1
00007895b19cf5dd  vpbroadcastq xmm1, xmm1
00007895b19cf5e2  lea r12, [rax+0x08]
00007895b19cf5e6  mov rax, [r13+r12*1]
00007895b19cf5eb  vmovaps [rsp+0x110], xmm1
00007895b19cf5f4  movq xmm1, rax
00007895b19cf5f9  movaps [r15+0x240], xmm1
00007895b19cf601  mov qword ptr [r15+0x60], 0x4308D0
00007895b19cf609  mov qword ptr [r15+0x58], 0x40
00007895b19cf611  vmovaps xmm1, [rsp+0x10]
00007895b19cf617  vmovaps [rsp+0x10], xmm15
00007895b19cf61d  vmovaps xmm15, [rsp+0x100]
00007895b19cf626  vmovaps [rsp+0x100], xmm14
00007895b19cf62f  vmovaps xmm14, [rsp+0x10]
00007895b19cf635  vmovaps [rsp+0x10], xmm13
00007895b19cf63b  vmovaps [rsp+0x120], xmm12
00007895b19cf644  movaps xmm13, xmm1
00007895b19cf648  vfmadd231pd xmm13, xmm15, xmm14
00007895b19cf64d  vcmppd xmm12, xmm13, xmm13, 0x03
00007895b19cf653  vptest xmm12, xmm12
00007895b19cf658  jnz 0x00007895B19D0283
00007895b19cf65e  vmovaps xmm1, [rsp+0x60]
00007895b19cf664  vmovaps xmm15, [rsp+0xB0]
00007895b19cf66d  vmovaps [rsp+0x60], xmm13
00007895b19cf673  movaps xmm12, xmm1
00007895b19cf677  vfmadd231pd xmm12, xmm15, xmm14
00007895b19cf67c  vcmppd xmm13, xmm12, xmm12, 0x03
00007895b19cf682  vptest xmm13, xmm13
00007895b19cf687  jnz 0x00007895B19D03DC
00007895b19cf68d  vmovaps xmm1, [rsp+0x50]
00007895b19cf693  vmovaps xmm13, [rsp+0x50]
00007895b19cf699  por xmm1, xmm13
00007895b19cf69e  vmovaps [rsp+0x50], xmm4
00007895b19cf6a4  vmovaps xmm13, [rsp+0x50]
00007895b19cf6aa  por xmm4, xmm13
00007895b19cf6af  vmovaps [rsp+0x50], xmm5
00007895b19cf6b5  vmovaps xmm13, [rsp+0x50]
00007895b19cf6bb  por xmm5, xmm13
00007895b19cf6c0  vmovaps [rsp+0x50], xmm11
00007895b19cf6c6  vmovaps xmm13, [rsp+0x50]
00007895b19cf6cc  por xmm11, xmm13
00007895b19cf6d1  vmovaps xmm13, [rsp+0x100]
00007895b19cf6da  vmovaps [rsp+0x50], xmm1
00007895b19cf6e0  vmovaps xmm1, [rsp+0x100]
00007895b19cf6e9  por xmm13, xmm1
00007895b19cf6ee  vmovaps [rsp+0xB0], xmm15
00007895b19cf6f7  vmovaps xmm1, [rsp+0xB0]
00007895b19cf700  por xmm15, xmm1
00007895b19cf705  lea rax, [r14+0xC0]
00007895b19cf70c  movups xmm1, [r13+rax*1]
00007895b19cf712  xor eax, eax
00007895b19cf714  mov r12d, 0x40
00007895b19cf71a  mov r11d, 0x200
00007895b19cf720  cmp r12, r11
00007895b19cf723  cmc
00007895b19cf724  lahf
00007895b19cf725  seto al
00007895b19cf728  mov [r15+0x108], eax
00007895b19cf72f  vmovaps [rsp+0xB0], xmm1
00007895b19cf738  vmovaps xmm1, [rsp+0xF0]
00007895b19cf741  vmovaps [rsp+0xF0], xmm15
00007895b19cf74a  vmovaps xmm15, [rsp+0xB0]
00007895b19cf753  vmovaps [rsp+0xB0], xmm13
00007895b19cf75c  vmovaps [rsp+0x100], xmm12
00007895b19cf765  movaps xmm13, xmm1
00007895b19cf769  vfmadd231pd xmm13, xmm15, xmm14
00007895b19cf76e  vcmppd xmm12, xmm13, xmm13, 0x03
00007895b19cf774  vptest xmm12, xmm12
00007895b19cf779  jnz 0x00007895B19D053F
00007895b19cf77f  lea rax, [r14+0xB0]
00007895b19cf786  movups xmm1, [r13+rax*1]
00007895b19cf78c  vmovaps xmm15, [rsp+0x110]
00007895b19cf795  vmovaps [rsp+0x110], xmm13
00007895b19cf79e  movaps xmm12, xmm15
00007895b19cf7a2  vfmadd231pd xmm12, xmm1, xmm14
00007895b19cf7a7  vcmppd xmm13, xmm12, xmm12, 0x03
00007895b19cf7ad  vptest xmm13, xmm13
00007895b19cf7b2  jnz 0x00007895B19D06A2
00007895b19cf7b8  vmovaps [rsp+0x130], xmm9
00007895b19cf7c1  vmovaps xmm1, [rsp+0x130]
00007895b19cf7ca  por xmm9, xmm1
00007895b19cf7cf  movaps [r15+0x210], xmm9
00007895b19cf7d7  vmovaps [rsp+0x130], xmm8
00007895b19cf7e0  vmovaps xmm1, [rsp+0x130]
00007895b19cf7e9  por xmm8, xmm1
00007895b19cf7ee  movaps [r15+0x1C0], xmm8
00007895b19cf7f6  vmovaps xmm1, [rsp+0x10]
00007895b19cf7fc  vmovaps xmm15, [rsp+0x10]
00007895b19cf802  por xmm1, xmm15
00007895b19cf807  movaps [r15+0x280], xmm1
00007895b19cf80f  vmovaps [rsp+0x10], xmm6
00007895b19cf815  vmovaps xmm14, [rsp+0x10]
00007895b19cf81b  por xmm6, xmm14
00007895b19cf820  movaps [r15+0x2A0], xmm6
00007895b19cf828  vmovaps xmm15, [rsp+0x20]
00007895b19cf82e  vmovaps xmm14, [rsp+0x20]
00007895b19cf834  por xmm15, xmm14
00007895b19cf839  movaps [r15+0x2E0], xmm15
00007895b19cf841  vmovaps xmm14, [rsp+0x30]
00007895b19cf847  vmovaps xmm13, [rsp+0x30]
00007895b19cf84d  por xmm14, xmm13
00007895b19cf852  movaps [r15+0x1F0], xmm14
00007895b19cf85a  vmovaps xmm13, [rsp+0xF0]
00007895b19cf863  vmovaps [rsp+0x10], xmm1
00007895b19cf869  vmovaps xmm1, [rsp+0xF0]
00007895b19cf872  por xmm13, xmm1
00007895b19cf877  movaps [r15+0x250], xmm13
00007895b19cf87f  vmovaps xmm1, [rsp+0xB0]
00007895b19cf888  vmovaps xmm13, [rsp+0xB0]
00007895b19cf891  por xmm1, xmm13
00007895b19cf896  movaps [r15+0x260], xmm1
00007895b19cf89e  vmovaps [rsp+0x20], xmm11
00007895b19cf8a4  vmovaps xmm13, [rsp+0x20]
00007895b19cf8aa  por xmm11, xmm13
00007895b19cf8af  movaps [r15+0x290], xmm11
00007895b19cf8b7  vmovaps [rsp+0x20], xmm5
00007895b19cf8bd  vmovaps xmm13, [rsp+0x20]
00007895b19cf8c3  por xmm5, xmm13
00007895b19cf8c8  movaps [r15+0x2C0], xmm5
00007895b19cf8d0  movq xmm13, qword ptr [r15+0x240]
00007895b19cf8d9  vmovaps [rsp+0x20], xmm13
00007895b19cf8df  vpermilpd xmm13, xmm13, 0x00
00007895b19cf8e5  vmovaps [rsp+0x30], xmm1
00007895b19cf8eb  vmovaps xmm1, [rsp+0x60]
00007895b19cf8f1  vmovaps [rsp+0x60], xmm15
00007895b19cf8f7  vmovaps [rsp+0xB0], xmm14
00007895b19cf900  movaps xmm15, xmm1
00007895b19cf904  vfmadd231pd xmm15, xmm9, xmm13
00007895b19cf909  vcmppd xmm14, xmm15, xmm15, 0x03
00007895b19cf90f  vptest xmm14, xmm14
00007895b19cf914  jnz 0x00007895B19D07FB
00007895b19cf91a  vmovaps xmm1, [rsp+0x20]
00007895b19cf920  vpermilpd xmm1, xmm1, 0x00
00007895b19cf926  vmovaps xmm14, [rsp+0x110]
00007895b19cf92f  vmovaps xmm13, [rsp+0x60]
00007895b19cf935  vmovaps [rsp+0x60], xmm15
00007895b19cf93b  movaps xmm9, xmm14
00007895b19cf93f  vfmadd231pd xmm9, xmm13, xmm1
00007895b19cf944  vcmppd xmm15, xmm9, xmm9, 0x03
00007895b19cf94a  vptest xmm15, xmm15
00007895b19cf94f  jnz 0x00007895B19D0954
00007895b19cf955  vmovaps xmm1, [rsp+0x20]
00007895b19cf95b  vpermilpd xmm1, xmm1, 0x00
00007895b19cf961  vmovaps xmm15, [rsp+0x100]
00007895b19cf96a  movaps xmm14, xmm15
00007895b19cf96e  vfmadd231pd xmm14, xmm8, xmm1
00007895b19cf973  vcmppd xmm13, xmm14, xmm14, 0x03
00007895b19cf979  vptest xmm13, xmm13
00007895b19cf97e  jnz 0x00007895B19D0AAD
00007895b19cf984  vmovaps [rsp+0xF0], xmm4
00007895b19cf98d  vmovaps xmm1, [rsp+0xF0]
00007895b19cf996  por xmm4, xmm1
00007895b19cf99a  movaps [r15+0x1D0], xmm4
00007895b19cf9a2  vmovaps xmm1, [rsp+0x20]
00007895b19cf9a8  vpermilpd xmm1, xmm1, 0x00
00007895b19cf9ae  vmovaps xmm13, [rsp+0xB0]
00007895b19cf9b7  movaps xmm15, xmm12
00007895b19cf9bb  vfmadd231pd xmm15, xmm13, xmm1
00007895b19cf9c0  vcmppd xmm8, xmm15, xmm15, 0x03
00007895b19cf9c6  vptest xmm8, xmm8
00007895b19cf9cb  jnz 0x00007895B19D0C06
00007895b19cf9d1  vmovaps xmm1, [rsp+0x80]
00007895b19cf9da  vmovaps xmm13, [rsp+0x80]
00007895b19cf9e3  por xmm1, xmm13
00007895b19cf9e8  movaps [r15+0x200], xmm1
00007895b19cf9f0  vmovaps xmm13, [rsp+0x50]
00007895b19cf9f6  vmovaps xmm12, [rsp+0x50]
00007895b19cf9fc  por xmm13, xmm12
00007895b19cfa01  movaps [r15+0x1E0], xmm13
00007895b19cfa09  vmovaps [rsp+0x20], xmm10
00007895b19cfa0f  vmovaps xmm13, [rsp+0x20]
00007895b19cfa15  por xmm10, xmm13
00007895b19cfa1a  movaps [r15+0x2B0], xmm10
00007895b19cfa22  vmovaps [rsp+0x20], xmm3
00007895b19cfa28  vmovaps xmm13, [rsp+0x20]
00007895b19cfa2e  por xmm3, xmm13
00007895b19cfa33  movaps [r15+0x300], xmm3
00007895b19cfa3b  vmovaps xmm8, [rsp+0xE0]
00007895b19cfa44  vpermilpd xmm8, xmm8, 0x00
00007895b19cfa4a  vmovaps xmm3, [rsp+0x60]
00007895b19cfa50  vmovaps [rsp+0x20], xmm1
00007895b19cfa56  vmovaps xmm1, [rsp+0x30]
00007895b19cfa5c  vmovaps [rsp+0x30], xmm15
00007895b19cfa62  vmovaps [rsp+0x50], xmm14
00007895b19cfa68  movaps xmm15, xmm3
00007895b19cfa6c  vfmadd231pd xmm15, xmm1, xmm8
00007895b19cfa71  vcmppd xmm14, xmm15, xmm15, 0x03
00007895b19cfa77  vptest xmm14, xmm14
00007895b19cfa7c  jnz 0x00007895B19D0D5F
00007895b19cfa82  vmovaps xmm1, [rsp+0xE0]
00007895b19cfa8b  vpermilpd xmm1, xmm1, 0x00
00007895b19cfa91  movaps xmm8, xmm9
00007895b19cfa95  vfmadd231pd xmm8, xmm5, xmm1
00007895b19cfa9a  vcmppd xmm14, xmm8, xmm8, 0x03
00007895b19cfaa0  vptest xmm14, xmm14
00007895b19cfaa5  jnz 0x00007895B19D0EB7
00007895b19cfaab  vmovaps xmm1, [rsp+0xE0]
00007895b19cfab4  vpermilpd xmm1, xmm1, 0x00
00007895b19cfaba  vmovaps xmm14, [rsp+0x50]
00007895b19cfac0  vmovaps xmm9, [rsp+0x10]
00007895b19cfac6  movaps xmm5, xmm14
00007895b19cfaca  vfmadd231pd xmm5, xmm9, xmm1
00007895b19cfacf  vcmppd xmm3, xmm5, xmm5, 0x03
00007895b19cfad4  vptest xmm3, xmm3
00007895b19cfad9  jnz 0x00007895B19D100F
00007895b19cfadf  vmovaps xmm1, [rsp+0xE0]
00007895b19cfae8  vpermilpd xmm1, xmm1, 0x00
00007895b19cfaee  vmovaps xmm14, [rsp+0x30]
00007895b19cfaf4  movaps xmm9, xmm14
00007895b19cfaf8  vfmadd231pd xmm9, xmm4, xmm1
00007895b19cfafd  vcmppd xmm3, xmm9, xmm9, 0x03
00007895b19cfb03  vptest xmm3, xmm3
00007895b19cfb08  jnz 0x00007895B19D1166
00007895b19cfb0e  vmovaps xmm1, [rsp+0x120]
00007895b19cfb17  vmovaps xmm14, [rsp+0x120]
00007895b19cfb20  por xmm1, xmm14
00007895b19cfb25  movaps [r15+0x180], xmm1
00007895b19cfb2d  vmovaps xmm14, [rsp+0x40]
00007895b19cfb33  vmovaps xmm4, [rsp+0x40]
00007895b19cfb39  por xmm14, xmm4
00007895b19cfb3e  movaps [r15+0x2D0], xmm14
00007895b19cfb46  vmovaps [rsp+0x10], xmm2
00007895b19cfb4c  vmovaps xmm4, [rsp+0x10]
00007895b19cfb52  por xmm2, xmm4
00007895b19cfb56  movaps [r15+0x2F0], xmm2
00007895b19cfb5e  vmovaps xmm3, [rsp+0xD0]
00007895b19cfb67  vpermilpd xmm3, xmm3, 0x00
00007895b19cfb6d  vmovaps [rsp+0x10], xmm1
00007895b19cfb73  movaps xmm2, xmm8
00007895b19cfb77  vfmadd231pd xmm2, xmm13, xmm3
00007895b19cfb7c  vcmppd xmm1, xmm2, xmm2, 0x03
00007895b19cfb81  vptest xmm1, xmm1
00007895b19cfb86  jnz 0x00007895B19D12BE
00007895b19cfb8c  vmovaps xmm1, [rsp+0xD0]
00007895b19cfb95  vpermilpd xmm1, xmm1, 0x00
00007895b19cfb9b  vmovaps xmm13, [rsp+0x10]
00007895b19cfba1  movaps xmm8, xmm15
00007895b19cfba5  vfmadd231pd xmm8, xmm13, xmm1
00007895b19cfbaa  vcmppd xmm3, xmm8, xmm8, 0x03
00007895b19cfbb0  vptest xmm3, xmm3
00007895b19cfbb5  jnz 0x00007895B19D1415
00007895b19cfbbb  lea rax, [r14+0x80]
00007895b19cfbc2  movups xmm1, [r13+rax*1]
00007895b19cfbc8  movaps [r15+0x190], xmm1
00007895b19cfbd0  vmovaps xmm15, [rsp+0xD0]
00007895b19cfbd9  vpermilpd xmm15, xmm15, 0x00
00007895b19cfbdf  movaps xmm13, xmm5
00007895b19cfbe3  vfmadd231pd xmm13, xmm11, xmm15
00007895b19cfbe8  vcmppd xmm3, xmm13, xmm13, 0x03
00007895b19cfbee  vptest xmm3, xmm3
00007895b19cfbf3  jnz 0x00007895B19D1578
00007895b19cfbf9  vmovaps xmm15, [rsp+0xD0]
00007895b19cfc02  vpermilpd xmm15, xmm15, 0x00
00007895b19cfc08  movaps xmm11, xmm9
00007895b19cfc0c  vfmadd231pd xmm11, xmm4, xmm15
00007895b19cfc11  vcmppd xmm5, xmm11, xmm11, 0x03
00007895b19cfc17  vptest xmm5, xmm5
00007895b19cfc1c  jnz 0x00007895B19D16D1
00007895b19cfc22  vmovaps [rsp+0x10], xmm7
00007895b19cfc28  vmovaps xmm9, [rsp+0x10]
00007895b19cfc2e  por xmm7, xmm9
00007895b19cfc33  movaps [r15+0x160], xmm7
00007895b19cfc3b  lea rax, [r14+0x40]
00007895b19cfc3f  movups xmm15, [r13+rax*1]
00007895b19cfc45  lea rax, [r14+0x50]
00007895b19cfc49  movups xmm9, [r13+rax*1]
00007895b19cfc4f  movaps [r15+0x1B0], xmm15
00007895b19cfc57  movaps [r15+0x1A0], xmm9
00007895b19cfc5f  vmovaps xmm5, [rsp+0xA0]
00007895b19cfc68  vpermilpd xmm5, xmm5, 0x00
00007895b19cfc6e  movaps xmm4, xmm2
00007895b19cfc71  vfmadd231pd xmm4, xmm14, xmm5
00007895b19cfc76  vcmppd xmm3, xmm4, xmm4, 0x03
00007895b19cfc7b  vptest xmm3, xmm3
00007895b19cfc80  jnz 0x00007895B19D183E
00007895b19cfc86  vmovaps xmm14, [rsp+0xA0]
00007895b19cfc8f  vpermilpd xmm14, xmm14, 0x00
00007895b19cfc95  movaps xmm5, xmm8
00007895b19cfc99  vfmadd231pd xmm5, xmm7, xmm14
00007895b19cfc9e  vcmppd xmm3, xmm5, xmm5, 0x03
00007895b19cfca3  vptest xmm3, xmm3
00007895b19cfca8  jnz 0x00007895B19D1994
00007895b19cfcae  vmovaps xmm14, [rsp+0xA0]
00007895b19cfcb7  vpermilpd xmm14, xmm14, 0x00
00007895b19cfcbd  movaps xmm8, xmm13
00007895b19cfcc1  vfmadd231pd xmm8, xmm6, xmm14
00007895b19cfcc6  vcmppd xmm7, xmm8, xmm8, 0x03
00007895b19cfccc  vptest xmm7, xmm7
00007895b19cfcd1  jnz 0x00007895B19D1AEB
00007895b19cfcd7  vmovaps xmm14, [rsp+0xA0]
00007895b19cfce0  vpermilpd xmm14, xmm14, 0x00
00007895b19cfce6  movaps xmm13, xmm11
00007895b19cfcea  vfmadd231pd xmm13, xmm12, xmm14
00007895b19cfcef  vcmppd xmm7, xmm13, xmm13, 0x03
00007895b19cfcf5  vptest xmm7, xmm7
00007895b19cfcfa  jnz 0x00007895B19D1C44
00007895b19cfd00  lea rax, [r14+0x60]
00007895b19cfd04  movups xmm14, [r13+rax*1]
00007895b19cfd0a  lea rax, [r14+0x70]
00007895b19cfd0e  movups xmm12, [r13+rax*1]
00007895b19cfd14  movaps [r15+0x150], xmm14
00007895b19cfd1c  movaps [r15+0x120], xmm12
00007895b19cfd24  vmovaps xmm11, [rsp+0xC0]
00007895b19cfd2d  vpermilpd xmm11, xmm11, 0x00
00007895b19cfd33  movaps xmm7, xmm4
00007895b19cfd36  vfmadd231pd xmm7, xmm9, xmm11
00007895b19cfd3b  vcmppd xmm6, xmm7, xmm7, 0x03
00007895b19cfd40  vptest xmm6, xmm6
00007895b19cfd45  jnz 0x00007895B19D1DB2
00007895b19cfd4b  vmovaps xmm11, [rsp+0xC0]
00007895b19cfd54  vpermilpd xmm11, xmm11, 0x00
00007895b19cfd5a  movaps xmm9, xmm5
00007895b19cfd5e  vfmadd231pd xmm9, xmm14, xmm11
00007895b19cfd63  vcmppd xmm6, xmm9, xmm9, 0x03
00007895b19cfd69  vptest xmm6, xmm6
00007895b19cfd6e  jnz 0x00007895B19D1F09
00007895b19cfd74  vmovaps xmm14, [rsp+0xC0]
00007895b19cfd7d  vpermilpd xmm14, xmm14, 0x00
00007895b19cfd83  movaps xmm11, xmm8
00007895b19cfd87  vfmadd231pd xmm11, xmm10, xmm14
00007895b19cfd8c  vcmppd xmm6, xmm11, xmm11, 0x03
00007895b19cfd92  vptest xmm6, xmm6
00007895b19cfd97  jnz 0x00007895B19D2062
00007895b19cfd9d  vmovaps xmm14, [rsp+0xC0]
00007895b19cfda6  vpermilpd xmm14, xmm14, 0x00
00007895b19cfdac  movaps xmm10, xmm13
00007895b19cfdb0  vfmadd231pd xmm10, xmm15, xmm14
00007895b19cfdb5  vcmppd xmm8, xmm10, xmm10, 0x03
00007895b19cfdbb  vptest xmm8, xmm8
00007895b19cfdc0  jnz 0x00007895B19D21BC
00007895b19cfdc6  lea rax, [r14+0x20]
00007895b19cfdca  movups xmm15, [r13+rax*1]
00007895b19cfdd0  lea rax, [r14+0x30]
00007895b19cfdd4  movups xmm14, [r13+rax*1]
00007895b19cfdda  vmovaps xmm13, [rsp+0x70]
00007895b19cfde0  vpermilpd xmm13, xmm13, 0x00
00007895b19cfde6  vmovaps xmm8, [rsp+0x20]
00007895b19cfdec  movaps xmm6, xmm7
00007895b19cfdef  vfmadd231pd xmm6, xmm8, xmm13
00007895b19cfdf4  vcmppd xmm5, xmm6, xmm6, 0x03
00007895b19cfdf9  vptest xmm5, xmm5
00007895b19cfdfe  jnz 0x00007895B19D232A
00007895b19cfe04  vmovaps xmm13, [rsp+0x70]
00007895b19cfe0a  vpermilpd xmm13, xmm13, 0x00
00007895b19cfe10  movaps xmm8, xmm9
00007895b19cfe14  vfmadd231pd xmm8, xmm1, xmm13
00007895b19cfe19  vcmppd xmm7, xmm8, xmm8, 0x03
00007895b19cfe1f  vptest xmm7, xmm7
00007895b19cfe24  jnz 0x00007895B19D2481
00007895b19cfe2a  vmovaps xmm1, [rsp+0x70]
00007895b19cfe30  vpermilpd xmm1, xmm1, 0x00
00007895b19cfe36  movaps xmm13, xmm11
00007895b19cfe3a  vfmadd231pd xmm13, xmm12, xmm1
00007895b19cfe3f  vcmppd xmm9, xmm13, xmm13, 0x03
00007895b19cfe45  vptest xmm9, xmm9
00007895b19cfe4a  jnz 0x00007895B19D25DA
00007895b19cfe50  vmovaps xmm1, [rsp+0x70]
00007895b19cfe56  vpermilpd xmm1, xmm1, 0x00
00007895b19cfe5c  movaps xmm12, xmm10
00007895b19cfe60  vfmadd231pd xmm12, xmm14, xmm1
00007895b19cfe65  vcmppd xmm11, xmm12, xmm12, 0x03
00007895b19cfe6b  vptest xmm11, xmm11
00007895b19cfe70  jnz 0x00007895B19D2733
00007895b19cfe76  lea rax, [r14+0x90]
00007895b19cfe7d  movups xmm1, [r13+rax*1]
00007895b19cfe83  lea rax, [r14+0xA0]
00007895b19cfe8a  movups xmm14, [r13+rax*1]
00007895b19cfe90  movaps [r15+0x140], xmm1
00007895b19cfe98  movaps [r15+0x130], xmm14
00007895b19cfea0  vmovaps xmm11, [rsp+0x90]
00007895b19cfea9  vpermilpd xmm11, xmm11, 0x00
00007895b19cfeaf  movaps xmm10, xmm6
00007895b19cfeb3  vfmadd231pd xmm10, xmm15, xmm11
00007895b19cfeb8  vcmppd xmm9, xmm10, xmm10, 0x03
00007895b19cfebe  vptest xmm9, xmm9
00007895b19cfec3  jnz 0x00007895B19D28A0
00007895b19cfec9  movaps [r15+0x220], xmm10
00007895b19cfed1  lea rax, [r14+0x10]
00007895b19cfed5  movups xmm15, [r13+rax*1]
00007895b19cfedb  movaps [r15+0x240], xmm15
00007895b19cfee3  vmovaps xmm11, [rsp+0x90]
00007895b19cfeec  vpermilpd xmm11, xmm11, 0x00
00007895b19cfef2  movaps xmm9, xmm8
00007895b19cfef6  vfmadd231pd xmm9, xmm14, xmm11
00007895b19cfefb  vcmppd xmm7, xmm9, xmm9, 0x03
00007895b19cff01  vptest xmm7, xmm7
00007895b19cff06  jnz 0x00007895B19D2A03
00007895b19cff0c  movaps [r15+0x110], xmm9
00007895b19cff14  vmovaps xmm14, [rsp+0x90]
00007895b19cff1d  vpermilpd xmm14, xmm14, 0x00
00007895b19cff23  movaps xmm11, xmm13
00007895b19cff27  vfmadd231pd xmm11, xmm1, xmm14
00007895b19cff2c  vcmppd xmm8, xmm11, xmm11, 0x03
00007895b19cff32  vptest xmm8, xmm8
00007895b19cff37  jnz 0x00007895B19D2B5D
00007895b19cff3d  movaps [r15+0x170], xmm11
00007895b19cff45  vmovaps xmm1, [rsp+0x90]
00007895b19cff4e  vpermilpd xmm1, xmm1, 0x00
00007895b19cff54  movaps xmm14, xmm12
00007895b19cff58  vfmadd231pd xmm14, xmm15, xmm1
00007895b19cff5d  vcmppd xmm13, xmm14, xmm14, 0x03
00007895b19cff63  vptest xmm13, xmm13
00007895b19cff68  jnz 0x00007895B19D2CB6
00007895b19cff6e  movaps [r15+0x230], xmm14
00007895b19cff76  mov eax, 0x4308D0
00007895b19cff7b  movups [r13+rax*1], xmm9
00007895b19cff81  mov eax, 0x4308E0
00007895b19cff86  movups [r13+rax*1], xmm11
00007895b19cff8c  mov eax, 0x4308F0
00007895b19cff91  movups [r13+rax*1], xmm10
00007895b19cff97  mov eax, 0x430900
00007895b19cff9c  movups [r13+rax*1], xmm14
00007895b19cffa2  mov eax, [r15+0x108]
00007895b19cffa9  sahf
00007895b19cffaa  jnz 0x00007895B19CFFDC
00007895b19cffac  cmp dword ptr [r15+0x318], 0x00
00007895b19cffb4  jz 0x00007895B19D67A0
00007895b19cffba  nop [rax+rax*1], ax
00007895b19cffc3  nop [rax+rax*1], eax
00007895b19cffcb  mov eax, 0x4103F0
00007895b19cffd0  mov [r15+0x100], rax
00007895b19cffd7  jmp 0x00007895B17FE110
00007895b19cffdc  cmp dword ptr [r15+0x318], 0x00
00007895b19cffe4  jz 0x00007895B19D2E40
00007895b19cffea  nop [rax+rax*1], ax
00007895b19cfff3  nop [rax+rax*1], eax
00007895b19cfffb  mov eax, 0x410274
00007895b19d0000  mov [r15+0x100], rax
00007895b19d0007  jmp 0x00007895B17FE110
00007895b19d000c  int3
00007895b19d000d  call 0x00007895B17FF430
00007895b19d0012  jmp 0x00007895B19CF00F
00007895b19d0017  call 0x00007895B18C4620
00007895b19d001c  jmp 0x00007895B19CF019
00007895b19d0021  call 0x00007895B18C0860
00007895b19d0026  jmp 0x00007895B19CF049
00007895b19d002b  call 0x00007895B18BF5F0
00007895b19d0030  jmp 0x00007895B19CF055
00007895b19d0035  call 0x00007895B18C33A0
00007895b19d003a  jmp 0x00007895B19CF062
00007895b19d003f  call 0x00007895B18C2120
00007895b19d0044  jmp 0x00007895B19CF06F
00007895b19d0049  call 0x00007895B18C0860
00007895b19d004e  jmp 0x00007895B19CF097
00007895b19d0053  call 0x00007895B18BF5F0
00007895b19d0058  jmp 0x00007895B19CF0A3
00007895b19d005d  call 0x00007895B18C0EA0
00007895b19d0062  jmp 0x00007895B19CF0B0
00007895b19d0067  call 0x00007895B18BFC30
00007895b19d006c  jmp 0x00007895B19CF0BD
00007895b19d0071  call 0x00007895B18D6600
00007895b19d0076  jmp 0x00007895B19CF0C3
00007895b19d007b  call 0x00007895B18B52F0
00007895b19d0080  jmp 0x00007895B19CF0CD
00007895b19d0085  call 0x00007895B18BE9C0
00007895b19d008a  jmp 0x00007895B19CF0D7
00007895b19d008f  call 0x00007895B18C0860
00007895b19d0094  jmp 0x00007895B19CF0FF
00007895b19d0099  call 0x00007895B18BF5F0
00007895b19d009e  jmp 0x00007895B19CF10B
00007895b19d00a3  call 0x00007895B18BD750
00007895b19d00a8  jmp 0x00007895B19CF115
00007895b19d00ad  call 0x00007895B18BC4E0
00007895b19d00b2  jmp 0x00007895B19CF11F
00007895b19d00b7  call 0x00007895B18C0860
00007895b19d00bc  jmp 0x00007895B19CF147
00007895b19d00c1  call 0x00007895B18BF5F0
00007895b19d00c6  jmp 0x00007895B19CF153
00007895b19d00cb  call 0x00007895B18BB270
00007895b19d00d0  jmp 0x00007895B19CF160
00007895b19d00d5  call 0x00007895B18BA000
00007895b19d00da  jmp 0x00007895B19CF16D
00007895b19d00df  call 0x00007895B18BEAE0
00007895b19d00e4  jmp 0x00007895B19CF17A
00007895b19d00e9  call 0x00007895B18B5400
00007895b19d00ee  jmp 0x00007895B19CF187
00007895b19d00f3  call 0x00007895B18B52F0
00007895b19d00f8  jmp 0x00007895B19CF194
00007895b19d00fd  call 0x00007895B18BE9C0
00007895b19d0102  jmp 0x00007895B19CF1A1
00007895b19d0107  call 0x00007895B18C0860
00007895b19d010c  jmp 0x00007895B19CF1B4
00007895b19d0111  call 0x00007895B18B8D90
00007895b19d0116  jmp 0x00007895B19CF1C1
00007895b19d011b  call 0x00007895B18B8A20
00007895b19d0120  jmp 0x00007895B19CF1CE
00007895b19d0125  call 0x00007895B18B77B0
00007895b19d012a  jmp 0x00007895B19CF1DB
00007895b19d012f  call 0x00007895B18B6550
00007895b19d0134  jmp 0x00007895B19CF1E8
00007895b19d0139  call 0x00007895B18B52F0
00007895b19d013e  jmp 0x00007895B19CF1F8
00007895b19d0143  call 0x00007895B18B52F0
00007895b19d0148  jmp 0x00007895B19CF208
00007895b19d014d  call 0x00007895B18B8B30
00007895b19d0152  jmp 0x00007895B19CF212
00007895b19d0157  call 0x00007895B18B8EA0
00007895b19d015c  jmp 0x00007895B19CF21F
00007895b19d0161  call 0x00007895B18B8D90
00007895b19d0166  jmp 0x00007895B19CF22C
00007895b19d016b  call 0x00007895B18B8A20
00007895b19d0170  jmp 0x00007895B19CF239
00007895b19d0175  call 0x00007895B18B6660
00007895b19d017a  jmp 0x00007895B19CF246
00007895b19d017f  call 0x00007895B18B78C0
00007895b19d0184  jmp 0x00007895B19CF253
00007895b19d0189  call 0x00007895B18B77B0
00007895b19d018e  jmp 0x00007895B19CF260
00007895b19d0193  call 0x00007895B18B6550
00007895b19d0198  jmp 0x00007895B19CF26D
00007895b19d019d  call 0x00007895B18B52F0
00007895b19d01a2  jmp 0x00007895B19CF280
00007895b19d01a7  call 0x00007895B18B52F0
00007895b19d01ac  jmp 0x00007895B19CF293
00007895b19d01b1  call 0x00007895B18B52F0
00007895b19d01b6  jmp 0x00007895B19CF2A6
00007895b19d01bb  call 0x00007895B18B52F0
00007895b19d01c0  jmp 0x00007895B19CF2B9
00007895b19d01c5  call 0x00007895B18B52F0
00007895b19d01ca  jmp 0x00007895B19CF2CC
00007895b19d01cf  call 0x00007895B18B52F0
00007895b19d01d4  jmp 0x00007895B19CF2E2
00007895b19d01d9  call 0x00007895B18B52F0
00007895b19d01de  jmp 0x00007895B19CF2F8
00007895b19d01e3  call 0x00007895B18B52F0
00007895b19d01e8  jmp 0x00007895B19CF30E
00007895b19d01ed  call 0x00007895B17FF540
00007895b19d01f2  jmp 0x00007895B19CF32F
00007895b19d01f7  call 0x00007895B17FF540
00007895b19d01fc  jmp 0x00007895B19CF33F
00007895b19d0201  call 0x00007895B17FF540
00007895b19d0206  jmp 0x00007895B19CF34F
00007895b19d020b  call 0x00007895B17FF540
00007895b19d0210  jmp 0x00007895B19CF362
00007895b19d0215  call 0x00007895B17FF540
00007895b19d021a  jmp 0x00007895B19CF375
00007895b19d021f  call 0x00007895B17FF540
00007895b19d0224  jmp 0x00007895B19CF388
00007895b19d0229  call 0x00007895B18C0370
00007895b19d022e  jmp 0x00007895B19CF3AD
00007895b19d0233  call 0x00007895B18BF100
00007895b19d0238  jmp 0x00007895B19CF3B6
00007895b19d023d  call 0x00007895B18C0370
00007895b19d0242  jmp 0x00007895B19CF426
00007895b19d0247  call 0x00007895B18BF100
00007895b19d024c  jmp 0x00007895B19CF42F
00007895b19d0251  call 0x00007895B18C0370
00007895b19d0256  jmp 0x00007895B19CF4E3
00007895b19d025b  call 0x00007895B18BF100
00007895b19d0260  jmp 0x00007895B19CF4EC
00007895b19d0265  call 0x00007895B180B720
00007895b19d026a  jmp 0x00007895B19CF5A8
00007895b19d026f  call 0x00007895B18D64F0
00007895b19d0274  jmp 0x00007895B19CF5D0
00007895b19d0279  call 0x00007895B18B47C0
00007895b19d027e  jmp 0x00007895B19CF5EB
00007895b19d0283  sub rsp, 0x08
00007895b19d0287  push rax
00007895b19d0288  push rcx
00007895b19d0289  push rdx
00007895b19d028a  push rdi
00007895b19d028b  push rsi
00007895b19d028c  push r8
00007895b19d028e  push r9
00007895b19d0290  push r10
00007895b19d0292  push r11
00007895b19d0294  sub rsp, 0xF0
00007895b19d029b  vmovaps [rsp], xmm0
00007895b19d02a0  vmovaps [rsp+0x10], xmm1
00007895b19d02a6  vmovaps [rsp+0x20], xmm2
00007895b19d02ac  vmovaps [rsp+0x30], xmm3
00007895b19d02b2  vmovaps [rsp+0x40], xmm4
00007895b19d02b8  vmovaps [rsp+0x50], xmm5
00007895b19d02be  vmovaps [rsp+0x60], xmm6
00007895b19d02c4  vmovaps [rsp+0x70], xmm7
00007895b19d02ca  vmovaps [rsp+0x80], xmm8
00007895b19d02d3  vmovaps [rsp+0x90], xmm9
00007895b19d02dc  vmovaps [rsp+0xA0], xmm10
00007895b19d02e5  vmovaps [rsp+0xB0], xmm11
00007895b19d02ee  vmovaps [rsp+0xC0], xmm12
00007895b19d02f7  vmovaps [rsp+0xD0], xmm14
00007895b19d0300  vmovaps [rsp+0xE0], xmm15
00007895b19d0309  sub rsp, 0x40
00007895b19d030d  lea rdi, [rsp]
00007895b19d0311  lea rsi, [rsp+0x10]
00007895b19d0316  lea rdx, [rsp+0x20]
00007895b19d031b  lea rcx, [rsp+0x30]
00007895b19d0320  mov r8d, 0x00
00007895b19d0326  lea r9, [r15+0x3A8]
00007895b19d032d  movaps [rdi], xmm13
00007895b19d0331  movaps [rsi], xmm1
00007895b19d0334  movaps [rdx], xmm15
00007895b19d0338  movaps [rcx], xmm14
00007895b19d033c  mov rax, 0x59D4522A9A50
00007895b19d0346  call rax
00007895b19d0348  movaps xmm13, [rsp]
00007895b19d034d  add rsp, 0x40
00007895b19d0351  vmovaps xmm0, [rsp]
00007895b19d0356  vmovaps xmm1, [rsp+0x10]
00007895b19d035c  vmovaps xmm2, [rsp+0x20]
00007895b19d0362  vmovaps xmm3, [rsp+0x30]
00007895b19d0368  vmovaps xmm4, [rsp+0x40]
00007895b19d036e  vmovaps xmm5, [rsp+0x50]
00007895b19d0374  vmovaps xmm6, [rsp+0x60]
00007895b19d037a  vmovaps xmm7, [rsp+0x70]
00007895b19d0380  vmovaps xmm8, [rsp+0x80]
00007895b19d0389  vmovaps xmm9, [rsp+0x90]
00007895b19d0392  vmovaps xmm10, [rsp+0xA0]
00007895b19d039b  vmovaps xmm11, [rsp+0xB0]
00007895b19d03a4  vmovaps xmm12, [rsp+0xC0]
00007895b19d03ad  vmovaps xmm14, [rsp+0xD0]
00007895b19d03b6  vmovaps xmm15, [rsp+0xE0]
00007895b19d03bf  add rsp, 0xF0
00007895b19d03c6  pop r11
00007895b19d03c8  pop r10
00007895b19d03ca  pop r9
00007895b19d03cc  pop r8
00007895b19d03ce  pop rsi
00007895b19d03cf  pop rdi
00007895b19d03d0  pop rdx
00007895b19d03d1  pop rcx
00007895b19d03d2  pop rax
00007895b19d03d3  add rsp, 0x08
00007895b19d03d7  jmp 0x00007895B19CF65E
00007895b19d03dc  sub rsp, 0x08
00007895b19d03e0  push rax
00007895b19d03e1  push rcx
00007895b19d03e2  push rdx
00007895b19d03e3  push rdi
00007895b19d03e4  push rsi
00007895b19d03e5  push r8
00007895b19d03e7  push r9
00007895b19d03e9  push r10
00007895b19d03eb  push r11
00007895b19d03ed  sub rsp, 0xF0
00007895b19d03f4  vmovaps [rsp], xmm0
00007895b19d03f9  vmovaps [rsp+0x10], xmm1
00007895b19d03ff  vmovaps [rsp+0x20], xmm2
00007895b19d0405  vmovaps [rsp+0x30], xmm3
00007895b19d040b  vmovaps [rsp+0x40], xmm4
00007895b19d0411  vmovaps [rsp+0x50], xmm5
00007895b19d0417  vmovaps [rsp+0x60], xmm6
00007895b19d041d  vmovaps [rsp+0x70], xmm7
00007895b19d0423  vmovaps [rsp+0x80], xmm8
00007895b19d042c  vmovaps [rsp+0x90], xmm9
00007895b19d0435  vmovaps [rsp+0xA0], xmm10
00007895b19d043e  vmovaps [rsp+0xB0], xmm11
00007895b19d0447  vmovaps [rsp+0xC0], xmm13
00007895b19d0450  vmovaps [rsp+0xD0], xmm14
00007895b19d0459  vmovaps [rsp+0xE0], xmm15
00007895b19d0462  sub rsp, 0x40
00007895b19d0466  lea rdi, [rsp]
00007895b19d046a  lea rsi, [rsp+0x10]
00007895b19d046f  lea rdx, [rsp+0x20]
00007895b19d0474  lea rcx, [rsp+0x30]
00007895b19d0479  mov r8d, 0x00
00007895b19d047f  lea r9, [r15+0x3A8]
00007895b19d0486  movaps [rdi], xmm12
00007895b19d048a  movaps [rsi], xmm1
00007895b19d048d  movaps [rdx], xmm15
00007895b19d0491  movaps [rcx], xmm14
00007895b19d0495  mov rax, 0x59D4522A9A50
00007895b19d049f  call rax
00007895b19d04a1  movaps xmm12, [rsp]
00007895b19d04a6  add rsp, 0x40
00007895b19d04aa  vmovaps xmm0, [rsp]
00007895b19d04af  vmovaps xmm1, [rsp+0x10]
00007895b19d04b5  vmovaps xmm2, [rsp+0x20]
00007895b19d04bb  vmovaps xmm3, [rsp+0x30]
00007895b19d04c1  vmovaps xmm4, [rsp+0x40]
00007895b19d04c7  vmovaps xmm5, [rsp+0x50]
00007895b19d04cd  vmovaps xmm6, [rsp+0x60]
00007895b19d04d3  vmovaps xmm7, [rsp+0x70]
00007895b19d04d9  vmovaps xmm8, [rsp+0x80]
00007895b19d04e2  vmovaps xmm9, [rsp+0x90]
00007895b19d04eb  vmovaps xmm10, [rsp+0xA0]
00007895b19d04f4  vmovaps xmm11, [rsp+0xB0]
00007895b19d04fd  vmovaps xmm13, [rsp+0xC0]
00007895b19d0506  vmovaps xmm14, [rsp+0xD0]
00007895b19d050f  vmovaps xmm15, [rsp+0xE0]
00007895b19d0518  add rsp, 0xF0
00007895b19d051f  pop r11
00007895b19d0521  pop r10
00007895b19d0523  pop r9
00007895b19d0525  pop r8
00007895b19d0527  pop rsi
00007895b19d0528  pop rdi
00007895b19d0529  pop rdx
00007895b19d052a  pop rcx
00007895b19d052b  pop rax
00007895b19d052c  add rsp, 0x08
00007895b19d0530  jmp 0x00007895B19CF68D
00007895b19d0535  call 0x00007895B17FF430
00007895b19d053a  jmp 0x00007895B19CF712
00007895b19d053f  sub rsp, 0x08
00007895b19d0543  push rax
00007895b19d0544  push rcx
00007895b19d0545  push rdx
00007895b19d0546  push rdi
00007895b19d0547  push rsi
00007895b19d0548  push r8
00007895b19d054a  push r9
00007895b19d054c  push r10
00007895b19d054e  push r11
00007895b19d0550  sub rsp, 0xF0
00007895b19d0557  vmovaps [rsp], xmm0
00007895b19d055c  vmovaps [rsp+0x10], xmm1
00007895b19d0562  vmovaps [rsp+0x20], xmm2
00007895b19d0568  vmovaps [rsp+0x30], xmm3
00007895b19d056e  vmovaps [rsp+0x40], xmm4
00007895b19d0574  vmovaps [rsp+0x50], xmm5
00007895b19d057a  vmovaps [rsp+0x60], xmm6
00007895b19d0580  vmovaps [rsp+0x70], xmm7
00007895b19d0586  vmovaps [rsp+0x80], xmm8
00007895b19d058f  vmovaps [rsp+0x90], xmm9
00007895b19d0598  vmovaps [rsp+0xA0], xmm10
00007895b19d05a1  vmovaps [rsp+0xB0], xmm11
00007895b19d05aa  vmovaps [rsp+0xC0], xmm12
00007895b19d05b3  vmovaps [rsp+0xD0], xmm14
00007895b19d05bc  vmovaps [rsp+0xE0], xmm15
00007895b19d05c5  sub rsp, 0x40
00007895b19d05c9  lea rdi, [rsp]
00007895b19d05cd  lea rsi, [rsp+0x10]
00007895b19d05d2  lea rdx, [rsp+0x20]
00007895b19d05d7  lea rcx, [rsp+0x30]
00007895b19d05dc  mov r8d, 0x00
00007895b19d05e2  lea r9, [r15+0x3A8]
00007895b19d05e9  movaps [rdi], xmm13
00007895b19d05ed  movaps [rsi], xmm1
00007895b19d05f0  movaps [rdx], xmm15
00007895b19d05f4  movaps [rcx], xmm14
00007895b19d05f8  mov rax, 0x59D4522A9A50
00007895b19d0602  call rax
00007895b19d0604  movaps xmm13, [rsp]
00007895b19d0609  add rsp, 0x40
00007895b19d060d  vmovaps xmm0, [rsp]
00007895b19d0612  vmovaps xmm1, [rsp+0x10]
00007895b19d0618  vmovaps xmm2, [rsp+0x20]
00007895b19d061e  vmovaps xmm3, [rsp+0x30]
00007895b19d0624  vmovaps xmm4, [rsp+0x40]
00007895b19d062a  vmovaps xmm5, [rsp+0x50]
00007895b19d0630  vmovaps xmm6, [rsp+0x60]
00007895b19d0636  vmovaps xmm7, [rsp+0x70]
00007895b19d063c  vmovaps xmm8, [rsp+0x80]
00007895b19d0645  vmovaps xmm9, [rsp+0x90]
00007895b19d064e  vmovaps xmm10, [rsp+0xA0]
00007895b19d0657  vmovaps xmm11, [rsp+0xB0]
00007895b19d0660  vmovaps xmm12, [rsp+0xC0]
00007895b19d0669  vmovaps xmm14, [rsp+0xD0]
00007895b19d0672  vmovaps xmm15, [rsp+0xE0]
00007895b19d067b  add rsp, 0xF0
00007895b19d0682  pop r11
00007895b19d0684  pop r10
00007895b19d0686  pop r9
00007895b19d0688  pop r8
00007895b19d068a  pop rsi
00007895b19d068b  pop rdi
00007895b19d068c  pop rdx
00007895b19d068d  pop rcx
00007895b19d068e  pop rax
00007895b19d068f  add rsp, 0x08
00007895b19d0693  jmp 0x00007895B19CF77F
00007895b19d0698  call 0x00007895B17FF430
00007895b19d069d  jmp 0x00007895B19CF78C
00007895b19d06a2  sub rsp, 0x08
00007895b19d06a6  push rax
00007895b19d06a7  push rcx
00007895b19d06a8  push rdx
00007895b19d06a9  push rdi
00007895b19d06aa  push rsi
00007895b19d06ab  push r8
00007895b19d06ad  push r9
00007895b19d06af  push r10
00007895b19d06b1  push r11
00007895b19d06b3  sub rsp, 0xF0
00007895b19d06ba  vmovaps [rsp], xmm0
00007895b19d06bf  vmovaps [rsp+0x10], xmm1
00007895b19d06c5  vmovaps [rsp+0x20], xmm2
00007895b19d06cb  vmovaps [rsp+0x30], xmm3
00007895b19d06d1  vmovaps [rsp+0x40], xmm4
00007895b19d06d7  vmovaps [rsp+0x50], xmm5
00007895b19d06dd  vmovaps [rsp+0x60], xmm6
00007895b19d06e3  vmovaps [rsp+0x70], xmm7
00007895b19d06e9  vmovaps [rsp+0x80], xmm8
00007895b19d06f2  vmovaps [rsp+0x90], xmm9
00007895b19d06fb  vmovaps [rsp+0xA0], xmm10
00007895b19d0704  vmovaps [rsp+0xB0], xmm11
00007895b19d070d  vmovaps [rsp+0xC0], xmm13
00007895b19d0716  vmovaps [rsp+0xD0], xmm14
00007895b19d071f  vmovaps [rsp+0xE0], xmm15
00007895b19d0728  sub rsp, 0x40
00007895b19d072c  lea rdi, [rsp]
00007895b19d0730  lea rsi, [rsp+0x10]
00007895b19d0735  lea rdx, [rsp+0x20]
00007895b19d073a  lea rcx, [rsp+0x30]
00007895b19d073f  mov r8d, 0x00
00007895b19d0745  lea r9, [r15+0x3A8]
00007895b19d074c  movaps [rdi], xmm12
00007895b19d0750  movaps [rsi], xmm15
00007895b19d0754  movaps [rdx], xmm1
00007895b19d0757  movaps [rcx], xmm14
00007895b19d075b  mov rax, 0x59D4522A9A50
00007895b19d0765  call rax
00007895b19d0767  movaps xmm12, [rsp]
00007895b19d076c  add rsp, 0x40
00007895b19d0770  vmovaps xmm0, [rsp]
00007895b19d0775  vmovaps xmm1, [rsp+0x10]
00007895b19d077b  vmovaps xmm2, [rsp+0x20]
00007895b19d0781  vmovaps xmm3, [rsp+0x30]
00007895b19d0787  vmovaps xmm4, [rsp+0x40]
00007895b19d078d  vmovaps xmm5, [rsp+0x50]
00007895b19d0793  vmovaps xmm6, [rsp+0x60]
00007895b19d0799  vmovaps xmm7, [rsp+0x70]
00007895b19d079f  vmovaps xmm8, [rsp+0x80]
00007895b19d07a8  vmovaps xmm9, [rsp+0x90]
00007895b19d07b1  vmovaps xmm10, [rsp+0xA0]
00007895b19d07ba  vmovaps xmm11, [rsp+0xB0]
00007895b19d07c3  vmovaps xmm13, [rsp+0xC0]
00007895b19d07cc  vmovaps xmm14, [rsp+0xD0]
00007895b19d07d5  vmovaps xmm15, [rsp+0xE0]
00007895b19d07de  add rsp, 0xF0
00007895b19d07e5  pop r11
00007895b19d07e7  pop r10
00007895b19d07e9  pop r9
00007895b19d07eb  pop r8
00007895b19d07ed  pop rsi
00007895b19d07ee  pop rdi
00007895b19d07ef  pop rdx
00007895b19d07f0  pop rcx
00007895b19d07f1  pop rax
00007895b19d07f2  add rsp, 0x08
00007895b19d07f6  jmp 0x00007895B19CF7B8
00007895b19d07fb  sub rsp, 0x08
00007895b19d07ff  push rax
00007895b19d0800  push rcx
00007895b19d0801  push rdx
00007895b19d0802  push rdi
00007895b19d0803  push rsi
00007895b19d0804  push r8
00007895b19d0806  push r9
00007895b19d0808  push r10
00007895b19d080a  push r11
00007895b19d080c  sub rsp, 0xF0
00007895b19d0813  vmovaps [rsp], xmm0
00007895b19d0818  vmovaps [rsp+0x10], xmm1
00007895b19d081e  vmovaps [rsp+0x20], xmm2
00007895b19d0824  vmovaps [rsp+0x30], xmm3
00007895b19d082a  vmovaps [rsp+0x40], xmm4
00007895b19d0830  vmovaps [rsp+0x50], xmm5
00007895b19d0836  vmovaps [rsp+0x60], xmm6
00007895b19d083c  vmovaps [rsp+0x70], xmm7
00007895b19d0842  vmovaps [rsp+0x80], xmm8
00007895b19d084b  vmovaps [rsp+0x90], xmm9
00007895b19d0854  vmovaps [rsp+0xA0], xmm10
00007895b19d085d  vmovaps [rsp+0xB0], xmm11
00007895b19d0866  vmovaps [rsp+0xC0], xmm12
00007895b19d086f  vmovaps [rsp+0xD0], xmm13
00007895b19d0878  vmovaps [rsp+0xE0], xmm14
00007895b19d0881  sub rsp, 0x40
00007895b19d0885  lea rdi, [rsp]
00007895b19d0889  lea rsi, [rsp+0x10]
00007895b19d088e  lea rdx, [rsp+0x20]
00007895b19d0893  lea rcx, [rsp+0x30]
00007895b19d0898  mov r8d, 0x00
00007895b19d089e  lea r9, [r15+0x3A8]
00007895b19d08a5  movaps [rdi], xmm15
00007895b19d08a9  movaps [rsi], xmm1
00007895b19d08ac  movaps [rdx], xmm9
00007895b19d08b0  movaps [rcx], xmm13
00007895b19d08b4  mov rax, 0x59D4522A9A50
00007895b19d08be  call rax
00007895b19d08c0  movaps xmm15, [rsp]
00007895b19d08c5  add rsp, 0x40
00007895b19d08c9  vmovaps xmm0, [rsp]
00007895b19d08ce  vmovaps xmm1, [rsp+0x10]
00007895b19d08d4  vmovaps xmm2, [rsp+0x20]
00007895b19d08da  vmovaps xmm3, [rsp+0x30]
00007895b19d08e0  vmovaps xmm4, [rsp+0x40]
00007895b19d08e6  vmovaps xmm5, [rsp+0x50]
00007895b19d08ec  vmovaps xmm6, [rsp+0x60]
00007895b19d08f2  vmovaps xmm7, [rsp+0x70]
00007895b19d08f8  vmovaps xmm8, [rsp+0x80]
00007895b19d0901  vmovaps xmm9, [rsp+0x90]
00007895b19d090a  vmovaps xmm10, [rsp+0xA0]
00007895b19d0913  vmovaps xmm11, [rsp+0xB0]
00007895b19d091c  vmovaps xmm12, [rsp+0xC0]
00007895b19d0925  vmovaps xmm13, [rsp+0xD0]
00007895b19d092e  vmovaps xmm14, [rsp+0xE0]
00007895b19d0937  add rsp, 0xF0
00007895b19d093e  pop r11
00007895b19d0940  pop r10
00007895b19d0942  pop r9
00007895b19d0944  pop r8
00007895b19d0946  pop rsi
00007895b19d0947  pop rdi
00007895b19d0948  pop rdx
00007895b19d0949  pop rcx
00007895b19d094a  pop rax
00007895b19d094b  add rsp, 0x08
00007895b19d094f  jmp 0x00007895B19CF91A
00007895b19d0954  sub rsp, 0x08
00007895b19d0958  push rax
00007895b19d0959  push rcx
00007895b19d095a  push rdx
00007895b19d095b  push rdi
00007895b19d095c  push rsi
00007895b19d095d  push r8
00007895b19d095f  push r9
00007895b19d0961  push r10
00007895b19d0963  push r11
00007895b19d0965  sub rsp, 0xF0
00007895b19d096c  vmovaps [rsp], xmm0
00007895b19d0971  vmovaps [rsp+0x10], xmm1
00007895b19d0977  vmovaps [rsp+0x20], xmm2
00007895b19d097d  vmovaps [rsp+0x30], xmm3
00007895b19d0983  vmovaps [rsp+0x40], xmm4
00007895b19d0989  vmovaps [rsp+0x50], xmm5
00007895b19d098f  vmovaps [rsp+0x60], xmm6
00007895b19d0995  vmovaps [rsp+0x70], xmm7
00007895b19d099b  vmovaps [rsp+0x80], xmm8
00007895b19d09a4  vmovaps [rsp+0x90], xmm10
00007895b19d09ad  vmovaps [rsp+0xA0], xmm11
00007895b19d09b6  vmovaps [rsp+0xB0], xmm12
00007895b19d09bf  vmovaps [rsp+0xC0], xmm13
00007895b19d09c8  vmovaps [rsp+0xD0], xmm14
00007895b19d09d1  vmovaps [rsp+0xE0], xmm15
00007895b19d09da  sub rsp, 0x40
00007895b19d09de  lea rdi, [rsp]
00007895b19d09e2  lea rsi, [rsp+0x10]
00007895b19d09e7  lea rdx, [rsp+0x20]
00007895b19d09ec  lea rcx, [rsp+0x30]
00007895b19d09f1  mov r8d, 0x00
00007895b19d09f7  lea r9, [r15+0x3A8]
00007895b19d09fe  movaps [rdi], xmm9
00007895b19d0a02  movaps [rsi], xmm14
00007895b19d0a06  movaps [rdx], xmm13
00007895b19d0a0a  movaps [rcx], xmm1
00007895b19d0a0d  mov rax, 0x59D4522A9A50
00007895b19d0a17  call rax
00007895b19d0a19  movaps xmm9, [rsp]
00007895b19d0a1e  add rsp, 0x40
00007895b19d0a22  vmovaps xmm0, [rsp]
00007895b19d0a27  vmovaps xmm1, [rsp+0x10]
00007895b19d0a2d  vmovaps xmm2, [rsp+0x20]
00007895b19d0a33  vmovaps xmm3, [rsp+0x30]
00007895b19d0a39  vmovaps xmm4, [rsp+0x40]
00007895b19d0a3f  vmovaps xmm5, [rsp+0x50]
00007895b19d0a45  vmovaps xmm6, [rsp+0x60]
00007895b19d0a4b  vmovaps xmm7, [rsp+0x70]
00007895b19d0a51  vmovaps xmm8, [rsp+0x80]
00007895b19d0a5a  vmovaps xmm10, [rsp+0x90]
00007895b19d0a63  vmovaps xmm11, [rsp+0xA0]
00007895b19d0a6c  vmovaps xmm12, [rsp+0xB0]
00007895b19d0a75  vmovaps xmm13, [rsp+0xC0]
00007895b19d0a7e  vmovaps xmm14, [rsp+0xD0]
00007895b19d0a87  vmovaps xmm15, [rsp+0xE0]
00007895b19d0a90  add rsp, 0xF0
00007895b19d0a97  pop r11
00007895b19d0a99  pop r10
00007895b19d0a9b  pop r9
00007895b19d0a9d  pop r8
00007895b19d0a9f  pop rsi
00007895b19d0aa0  pop rdi
00007895b19d0aa1  pop rdx
00007895b19d0aa2  pop rcx
00007895b19d0aa3  pop rax
00007895b19d0aa4  add rsp, 0x08
00007895b19d0aa8  jmp 0x00007895B19CF955
00007895b19d0aad  sub rsp, 0x08
00007895b19d0ab1  push rax
00007895b19d0ab2  push rcx
00007895b19d0ab3  push rdx
00007895b19d0ab4  push rdi
00007895b19d0ab5  push rsi
00007895b19d0ab6  push r8
00007895b19d0ab8  push r9
00007895b19d0aba  push r10
00007895b19d0abc  push r11
00007895b19d0abe  sub rsp, 0xF0
00007895b19d0ac5  vmovaps [rsp], xmm0
00007895b19d0aca  vmovaps [rsp+0x10], xmm1
00007895b19d0ad0  vmovaps [rsp+0x20], xmm2
00007895b19d0ad6  vmovaps [rsp+0x30], xmm3
00007895b19d0adc  vmovaps [rsp+0x40], xmm4
00007895b19d0ae2  vmovaps [rsp+0x50], xmm5
00007895b19d0ae8  vmovaps [rsp+0x60], xmm6
00007895b19d0aee  vmovaps [rsp+0x70], xmm7
00007895b19d0af4  vmovaps [rsp+0x80], xmm8
00007895b19d0afd  vmovaps [rsp+0x90], xmm9
00007895b19d0b06  vmovaps [rsp+0xA0], xmm10
00007895b19d0b0f  vmovaps [rsp+0xB0], xmm11
00007895b19d0b18  vmovaps [rsp+0xC0], xmm12
00007895b19d0b21  vmovaps [rsp+0xD0], xmm13
00007895b19d0b2a  vmovaps [rsp+0xE0], xmm15
00007895b19d0b33  sub rsp, 0x40
00007895b19d0b37  lea rdi, [rsp]
00007895b19d0b3b  lea rsi, [rsp+0x10]
00007895b19d0b40  lea rdx, [rsp+0x20]
00007895b19d0b45  lea rcx, [rsp+0x30]
00007895b19d0b4a  mov r8d, 0x00
00007895b19d0b50  lea r9, [r15+0x3A8]
00007895b19d0b57  movaps [rdi], xmm14
00007895b19d0b5b  movaps [rsi], xmm15
00007895b19d0b5f  movaps [rdx], xmm8
00007895b19d0b63  movaps [rcx], xmm1
00007895b19d0b66  mov rax, 0x59D4522A9A50
00007895b19d0b70  call rax
00007895b19d0b72  movaps xmm14, [rsp]
00007895b19d0b77  add rsp, 0x40
00007895b19d0b7b  vmovaps xmm0, [rsp]
00007895b19d0b80  vmovaps xmm1, [rsp+0x10]
00007895b19d0b86  vmovaps xmm2, [rsp+0x20]
00007895b19d0b8c  vmovaps xmm3, [rsp+0x30]
00007895b19d0b92  vmovaps xmm4, [rsp+0x40]
00007895b19d0b98  vmovaps xmm5, [rsp+0x50]
00007895b19d0b9e  vmovaps xmm6, [rsp+0x60]
00007895b19d0ba4  vmovaps xmm7, [rsp+0x70]
00007895b19d0baa  vmovaps xmm8, [rsp+0x80]
00007895b19d0bb3  vmovaps xmm9, [rsp+0x90]
00007895b19d0bbc  vmovaps xmm10, [rsp+0xA0]
00007895b19d0bc5  vmovaps xmm11, [rsp+0xB0]
00007895b19d0bce  vmovaps xmm12, [rsp+0xC0]
00007895b19d0bd7  vmovaps xmm13, [rsp+0xD0]
00007895b19d0be0  vmovaps xmm15, [rsp+0xE0]
00007895b19d0be9  add rsp, 0xF0
00007895b19d0bf0  pop r11
00007895b19d0bf2  pop r10
00007895b19d0bf4  pop r9
00007895b19d0bf6  pop r8
00007895b19d0bf8  pop rsi
00007895b19d0bf9  pop rdi
00007895b19d0bfa  pop rdx
00007895b19d0bfb  pop rcx
00007895b19d0bfc  pop rax
00007895b19d0bfd  add rsp, 0x08
00007895b19d0c01  jmp 0x00007895B19CF984
00007895b19d0c06  sub rsp, 0x08
00007895b19d0c0a  push rax
00007895b19d0c0b  push rcx
00007895b19d0c0c  push rdx
00007895b19d0c0d  push rdi
00007895b19d0c0e  push rsi
00007895b19d0c0f  push r8
00007895b19d0c11  push r9
00007895b19d0c13  push r10
00007895b19d0c15  push r11
00007895b19d0c17  sub rsp, 0xF0
00007895b19d0c1e  vmovaps [rsp], xmm0
00007895b19d0c23  vmovaps [rsp+0x10], xmm1
00007895b19d0c29  vmovaps [rsp+0x20], xmm2
00007895b19d0c2f  vmovaps [rsp+0x30], xmm3
00007895b19d0c35  vmovaps [rsp+0x40], xmm4
00007895b19d0c3b  vmovaps [rsp+0x50], xmm5
00007895b19d0c41  vmovaps [rsp+0x60], xmm6
00007895b19d0c47  vmovaps [rsp+0x70], xmm7
00007895b19d0c4d  vmovaps [rsp+0x80], xmm8
00007895b19d0c56  vmovaps [rsp+0x90], xmm9
00007895b19d0c5f  vmovaps [rsp+0xA0], xmm10
00007895b19d0c68  vmovaps [rsp+0xB0], xmm11
00007895b19d0c71  vmovaps [rsp+0xC0], xmm12
00007895b19d0c7a  vmovaps [rsp+0xD0], xmm13
00007895b19d0c83  vmovaps [rsp+0xE0], xmm14
00007895b19d0c8c  sub rsp, 0x40
00007895b19d0c90  lea rdi, [rsp]
00007895b19d0c94  lea rsi, [rsp+0x10]
00007895b19d0c99  lea rdx, [rsp+0x20]
00007895b19d0c9e  lea rcx, [rsp+0x30]
00007895b19d0ca3  mov r8d, 0x00
00007895b19d0ca9  lea r9, [r15+0x3A8]
00007895b19d0cb0  movaps [rdi], xmm15
00007895b19d0cb4  movaps [rsi], xmm12
00007895b19d0cb8  movaps [rdx], xmm13
00007895b19d0cbc  movaps [rcx], xmm1
00007895b19d0cbf  mov rax, 0x59D4522A9A50
00007895b19d0cc9  call rax
00007895b19d0ccb  movaps xmm15, [rsp]
00007895b19d0cd0  add rsp, 0x40
00007895b19d0cd4  vmovaps xmm0, [rsp]
00007895b19d0cd9  vmovaps xmm1, [rsp+0x10]
00007895b19d0cdf  vmovaps xmm2, [rsp+0x20]
00007895b19d0ce5  vmovaps xmm3, [rsp+0x30]
00007895b19d0ceb  vmovaps xmm4, [rsp+0x40]
00007895b19d0cf1  vmovaps xmm5, [rsp+0x50]
00007895b19d0cf7  vmovaps xmm6, [rsp+0x60]
00007895b19d0cfd  vmovaps xmm7, [rsp+0x70]
00007895b19d0d03  vmovaps xmm8, [rsp+0x80]
00007895b19d0d0c  vmovaps xmm9, [rsp+0x90]
00007895b19d0d15  vmovaps xmm10, [rsp+0xA0]
00007895b19d0d1e  vmovaps xmm11, [rsp+0xB0]
00007895b19d0d27  vmovaps xmm12, [rsp+0xC0]
00007895b19d0d30  vmovaps xmm13, [rsp+0xD0]
00007895b19d0d39  vmovaps xmm14, [rsp+0xE0]
00007895b19d0d42  add rsp, 0xF0
00007895b19d0d49  pop r11
00007895b19d0d4b  pop r10
00007895b19d0d4d  pop r9
00007895b19d0d4f  pop r8
00007895b19d0d51  pop rsi
00007895b19d0d52  pop rdi
00007895b19d0d53  pop rdx
00007895b19d0d54  pop rcx
00007895b19d0d55  pop rax
00007895b19d0d56  add rsp, 0x08
00007895b19d0d5a  jmp 0x00007895B19CF9D1
00007895b19d0d5f  sub rsp, 0x08
00007895b19d0d63  push rax
00007895b19d0d64  push rcx
00007895b19d0d65  push rdx
00007895b19d0d66  push rdi
00007895b19d0d67  push rsi
00007895b19d0d68  push r8
00007895b19d0d6a  push r9
00007895b19d0d6c  push r10
00007895b19d0d6e  push r11
00007895b19d0d70  sub rsp, 0xF0
00007895b19d0d77  vmovaps [rsp], xmm0
00007895b19d0d7c  vmovaps [rsp+0x10], xmm1
00007895b19d0d82  vmovaps [rsp+0x20], xmm2
00007895b19d0d88  vmovaps [rsp+0x30], xmm3
00007895b19d0d8e  vmovaps [rsp+0x40], xmm4
00007895b19d0d94  vmovaps [rsp+0x50], xmm5
00007895b19d0d9a  vmovaps [rsp+0x60], xmm6
00007895b19d0da0  vmovaps [rsp+0x70], xmm7
00007895b19d0da6  vmovaps [rsp+0x80], xmm8
00007895b19d0daf  vmovaps [rsp+0x90], xmm9
00007895b19d0db8  vmovaps [rsp+0xA0], xmm10
00007895b19d0dc1  vmovaps [rsp+0xB0], xmm11
00007895b19d0dca  vmovaps [rsp+0xC0], xmm12
00007895b19d0dd3  vmovaps [rsp+0xD0], xmm13
00007895b19d0ddc  vmovaps [rsp+0xE0], xmm14
00007895b19d0de5  sub rsp, 0x40
00007895b19d0de9  lea rdi, [rsp]
00007895b19d0ded  lea rsi, [rsp+0x10]
00007895b19d0df2  lea rdx, [rsp+0x20]
00007895b19d0df7  lea rcx, [rsp+0x30]
00007895b19d0dfc  mov r8d, 0x00
00007895b19d0e02  lea r9, [r15+0x3A8]
00007895b19d0e09  movaps [rdi], xmm15
00007895b19d0e0d  movaps [rsi], xmm3
00007895b19d0e10  movaps [rdx], xmm1
00007895b19d0e13  movaps [rcx], xmm8
00007895b19d0e17  mov rax, 0x59D4522A9A50
00007895b19d0e21  call rax
00007895b19d0e23  movaps xmm15, [rsp]
00007895b19d0e28  add rsp, 0x40
00007895b19d0e2c  vmovaps xmm0, [rsp]
00007895b19d0e31  vmovaps xmm1, [rsp+0x10]
00007895b19d0e37  vmovaps xmm2, [rsp+0x20]
00007895b19d0e3d  vmovaps xmm3, [rsp+0x30]
00007895b19d0e43  vmovaps xmm4, [rsp+0x40]
00007895b19d0e49  vmovaps xmm5, [rsp+0x50]
00007895b19d0e4f  vmovaps xmm6, [rsp+0x60]
00007895b19d0e55  vmovaps xmm7, [rsp+0x70]
00007895b19d0e5b  vmovaps xmm8, [rsp+0x80]
00007895b19d0e64  vmovaps xmm9, [rsp+0x90]
00007895b19d0e6d  vmovaps xmm10, [rsp+0xA0]
00007895b19d0e76  vmovaps xmm11, [rsp+0xB0]
00007895b19d0e7f  vmovaps xmm12, [rsp+0xC0]
00007895b19d0e88  vmovaps xmm13, [rsp+0xD0]
00007895b19d0e91  vmovaps xmm14, [rsp+0xE0]
00007895b19d0e9a  add rsp, 0xF0
00007895b19d0ea1  pop r11
00007895b19d0ea3  pop r10
00007895b19d0ea5  pop r9
00007895b19d0ea7  pop r8
00007895b19d0ea9  pop rsi
00007895b19d0eaa  pop rdi
00007895b19d0eab  pop rdx
00007895b19d0eac  pop rcx
00007895b19d0ead  pop rax
00007895b19d0eae  add rsp, 0x08
00007895b19d0eb2  jmp 0x00007895B19CFA82
00007895b19d0eb7  sub rsp, 0x08
00007895b19d0ebb  push rax
00007895b19d0ebc  push rcx
00007895b19d0ebd  push rdx
00007895b19d0ebe  push rdi
00007895b19d0ebf  push rsi
00007895b19d0ec0  push r8
00007895b19d0ec2  push r9
00007895b19d0ec4  push r10
00007895b19d0ec6  push r11
00007895b19d0ec8  sub rsp, 0xF0
00007895b19d0ecf  vmovaps [rsp], xmm0
00007895b19d0ed4  vmovaps [rsp+0x10], xmm1
00007895b19d0eda  vmovaps [rsp+0x20], xmm2
00007895b19d0ee0  vmovaps [rsp+0x30], xmm3
00007895b19d0ee6  vmovaps [rsp+0x40], xmm4
00007895b19d0eec  vmovaps [rsp+0x50], xmm5
00007895b19d0ef2  vmovaps [rsp+0x60], xmm6
00007895b19d0ef8  vmovaps [rsp+0x70], xmm7
00007895b19d0efe  vmovaps [rsp+0x80], xmm9
00007895b19d0f07  vmovaps [rsp+0x90], xmm10
00007895b19d0f10  vmovaps [rsp+0xA0], xmm11
00007895b19d0f19  vmovaps [rsp+0xB0], xmm12
00007895b19d0f22  vmovaps [rsp+0xC0], xmm13
00007895b19d0f2b  vmovaps [rsp+0xD0], xmm14
00007895b19d0f34  vmovaps [rsp+0xE0], xmm15
00007895b19d0f3d  sub rsp, 0x40
00007895b19d0f41  lea rdi, [rsp]
00007895b19d0f45  lea rsi, [rsp+0x10]
00007895b19d0f4a  lea rdx, [rsp+0x20]
00007895b19d0f4f  lea rcx, [rsp+0x30]
00007895b19d0f54  mov r8d, 0x00
00007895b19d0f5a  lea r9, [r15+0x3A8]
00007895b19d0f61  movaps [rdi], xmm8
00007895b19d0f65  movaps [rsi], xmm9
00007895b19d0f69  movaps [rdx], xmm5
00007895b19d0f6c  movaps [rcx], xmm1
00007895b19d0f6f  mov rax, 0x59D4522A9A50
00007895b19d0f79  call rax
00007895b19d0f7b  movaps xmm8, [rsp]
00007895b19d0f80  add rsp, 0x40
00007895b19d0f84  vmovaps xmm0, [rsp]
00007895b19d0f89  vmovaps xmm1, [rsp+0x10]
00007895b19d0f8f  vmovaps xmm2, [rsp+0x20]
00007895b19d0f95  vmovaps xmm3, [rsp+0x30]
00007895b19d0f9b  vmovaps xmm4, [rsp+0x40]
00007895b19d0fa1  vmovaps xmm5, [rsp+0x50]
00007895b19d0fa7  vmovaps xmm6, [rsp+0x60]
00007895b19d0fad  vmovaps xmm7, [rsp+0x70]
00007895b19d0fb3  vmovaps xmm9, [rsp+0x80]
00007895b19d0fbc  vmovaps xmm10, [rsp+0x90]
00007895b19d0fc5  vmovaps xmm11, [rsp+0xA0]
00007895b19d0fce  vmovaps xmm12, [rsp+0xB0]
00007895b19d0fd7  vmovaps xmm13, [rsp+0xC0]
00007895b19d0fe0  vmovaps xmm14, [rsp+0xD0]
00007895b19d0fe9  vmovaps xmm15, [rsp+0xE0]
00007895b19d0ff2  add rsp, 0xF0
00007895b19d0ff9  pop r11
00007895b19d0ffb  pop r10
00007895b19d0ffd  pop r9
00007895b19d0fff  pop r8
00007895b19d1001  pop rsi
00007895b19d1002  pop rdi
00007895b19d1003  pop rdx
00007895b19d1004  pop rcx
00007895b19d1005  pop rax
00007895b19d1006  add rsp, 0x08
00007895b19d100a  jmp 0x00007895B19CFAAB
00007895b19d100f  sub rsp, 0x08
00007895b19d1013  push rax
00007895b19d1014  push rcx
00007895b19d1015  push rdx
00007895b19d1016  push rdi
00007895b19d1017  push rsi
00007895b19d1018  push r8
00007895b19d101a  push r9
00007895b19d101c  push r10
00007895b19d101e  push r11
00007895b19d1020  sub rsp, 0xF0
00007895b19d1027  vmovaps [rsp], xmm0
00007895b19d102c  vmovaps [rsp+0x10], xmm1
00007895b19d1032  vmovaps [rsp+0x20], xmm2
00007895b19d1038  vmovaps [rsp+0x30], xmm3
00007895b19d103e  vmovaps [rsp+0x40], xmm4
00007895b19d1044  vmovaps [rsp+0x50], xmm6
00007895b19d104a  vmovaps [rsp+0x60], xmm7
00007895b19d1050  vmovaps [rsp+0x70], xmm8
00007895b19d1056  vmovaps [rsp+0x80], xmm9
00007895b19d105f  vmovaps [rsp+0x90], xmm10
00007895b19d1068  vmovaps [rsp+0xA0], xmm11
00007895b19d1071  vmovaps [rsp+0xB0], xmm12
00007895b19d107a  vmovaps [rsp+0xC0], xmm13
00007895b19d1083  vmovaps [rsp+0xD0], xmm14
00007895b19d108c  vmovaps [rsp+0xE0], xmm15
00007895b19d1095  sub rsp, 0x40
00007895b19d1099  lea rdi, [rsp]
00007895b19d109d  lea rsi, [rsp+0x10]
00007895b19d10a2  lea rdx, [rsp+0x20]
00007895b19d10a7  lea rcx, [rsp+0x30]
00007895b19d10ac  mov r8d, 0x00
00007895b19d10b2  lea r9, [r15+0x3A8]
00007895b19d10b9  movaps [rdi], xmm5
00007895b19d10bc  movaps [rsi], xmm14
00007895b19d10c0  movaps [rdx], xmm9
00007895b19d10c4  movaps [rcx], xmm1
00007895b19d10c7  mov rax, 0x59D4522A9A50
00007895b19d10d1  call rax
00007895b19d10d3  movaps xmm5, [rsp]
00007895b19d10d7  add rsp, 0x40
00007895b19d10db  vmovaps xmm0, [rsp]
00007895b19d10e0  vmovaps xmm1, [rsp+0x10]
00007895b19d10e6  vmovaps xmm2, [rsp+0x20]
00007895b19d10ec  vmovaps xmm3, [rsp+0x30]
00007895b19d10f2  vmovaps xmm4, [rsp+0x40]
00007895b19d10f8  vmovaps xmm6, [rsp+0x50]
00007895b19d10fe  vmovaps xmm7, [rsp+0x60]
00007895b19d1104  vmovaps xmm8, [rsp+0x70]
00007895b19d110a  vmovaps xmm9, [rsp+0x80]
00007895b19d1113  vmovaps xmm10, [rsp+0x90]
00007895b19d111c  vmovaps xmm11, [rsp+0xA0]
00007895b19d1125  vmovaps xmm12, [rsp+0xB0]
00007895b19d112e  vmovaps xmm13, [rsp+0xC0]
00007895b19d1137  vmovaps xmm14, [rsp+0xD0]
00007895b19d1140  vmovaps xmm15, [rsp+0xE0]
00007895b19d1149  add rsp, 0xF0
00007895b19d1150  pop r11
00007895b19d1152  pop r10
00007895b19d1154  pop r9
00007895b19d1156  pop r8
00007895b19d1158  pop rsi
00007895b19d1159  pop rdi
00007895b19d115a  pop rdx
00007895b19d115b  pop rcx
00007895b19d115c  pop rax
00007895b19d115d  add rsp, 0x08
00007895b19d1161  jmp 0x00007895B19CFADF
00007895b19d1166  sub rsp, 0x08
00007895b19d116a  push rax
00007895b19d116b  push rcx
00007895b19d116c  push rdx
00007895b19d116d  push rdi
00007895b19d116e  push rsi
00007895b19d116f  push r8
00007895b19d1171  push r9
00007895b19d1173  push r10
00007895b19d1175  push r11
00007895b19d1177  sub rsp, 0xF0
00007895b19d117e  vmovaps [rsp], xmm0
00007895b19d1183  vmovaps [rsp+0x10], xmm1
00007895b19d1189  vmovaps [rsp+0x20], xmm2
00007895b19d118f  vmovaps [rsp+0x30], xmm3
00007895b19d1195  vmovaps [rsp+0x40], xmm4
00007895b19d119b  vmovaps [rsp+0x50], xmm5
00007895b19d11a1  vmovaps [rsp+0x60], xmm6
00007895b19d11a7  vmovaps [rsp+0x70], xmm7
00007895b19d11ad  vmovaps [rsp+0x80], xmm8
00007895b19d11b6  vmovaps [rsp+0x90], xmm10
00007895b19d11bf  vmovaps [rsp+0xA0], xmm11
00007895b19d11c8  vmovaps [rsp+0xB0], xmm12
00007895b19d11d1  vmovaps [rsp+0xC0], xmm13
00007895b19d11da  vmovaps [rsp+0xD0], xmm14
00007895b19d11e3  vmovaps [rsp+0xE0], xmm15
00007895b19d11ec  sub rsp, 0x40
00007895b19d11f0  lea rdi, [rsp]
00007895b19d11f4  lea rsi, [rsp+0x10]
00007895b19d11f9  lea rdx, [rsp+0x20]
00007895b19d11fe  lea rcx, [rsp+0x30]
00007895b19d1203  mov r8d, 0x00
00007895b19d1209  lea r9, [r15+0x3A8]
00007895b19d1210  movaps [rdi], xmm9
00007895b19d1214  movaps [rsi], xmm14
00007895b19d1218  movaps [rdx], xmm4
00007895b19d121b  movaps [rcx], xmm1
00007895b19d121e  mov rax, 0x59D4522A9A50
00007895b19d1228  call rax
00007895b19d122a  movaps xmm9, [rsp]
00007895b19d122f  add rsp, 0x40
00007895b19d1233  vmovaps xmm0, [rsp]
00007895b19d1238  vmovaps xmm1, [rsp+0x10]
00007895b19d123e  vmovaps xmm2, [rsp+0x20]
00007895b19d1244  vmovaps xmm3, [rsp+0x30]
00007895b19d124a  vmovaps xmm4, [rsp+0x40]
00007895b19d1250  vmovaps xmm5, [rsp+0x50]
00007895b19d1256  vmovaps xmm6, [rsp+0x60]
00007895b19d125c  vmovaps xmm7, [rsp+0x70]
00007895b19d1262  vmovaps xmm8, [rsp+0x80]
00007895b19d126b  vmovaps xmm10, [rsp+0x90]
00007895b19d1274  vmovaps xmm11, [rsp+0xA0]
00007895b19d127d  vmovaps xmm12, [rsp+0xB0]
00007895b19d1286  vmovaps xmm13, [rsp+0xC0]
00007895b19d128f  vmovaps xmm14, [rsp+0xD0]
00007895b19d1298  vmovaps xmm15, [rsp+0xE0]
00007895b19d12a1  add rsp, 0xF0
00007895b19d12a8  pop r11
00007895b19d12aa  pop r10
00007895b19d12ac  pop r9
00007895b19d12ae  pop r8
00007895b19d12b0  pop rsi
00007895b19d12b1  pop rdi
00007895b19d12b2  pop rdx
00007895b19d12b3  pop rcx
00007895b19d12b4  pop rax
00007895b19d12b5  add rsp, 0x08
00007895b19d12b9  jmp 0x00007895B19CFB0E
00007895b19d12be  sub rsp, 0x08
00007895b19d12c2  push rax
00007895b19d12c3  push rcx
00007895b19d12c4  push rdx
00007895b19d12c5  push rdi
00007895b19d12c6  push rsi
00007895b19d12c7  push r8
00007895b19d12c9  push r9
00007895b19d12cb  push r10
00007895b19d12cd  push r11
00007895b19d12cf  sub rsp, 0xF0
00007895b19d12d6  vmovaps [rsp], xmm0
00007895b19d12db  vmovaps [rsp+0x10], xmm1
00007895b19d12e1  vmovaps [rsp+0x20], xmm3
00007895b19d12e7  vmovaps [rsp+0x30], xmm4
00007895b19d12ed  vmovaps [rsp+0x40], xmm5
00007895b19d12f3  vmovaps [rsp+0x50], xmm6
00007895b19d12f9  vmovaps [rsp+0x60], xmm7
00007895b19d12ff  vmovaps [rsp+0x70], xmm8
00007895b19d1305  vmovaps [rsp+0x80], xmm9
00007895b19d130e  vmovaps [rsp+0x90], xmm10
00007895b19d1317  vmovaps [rsp+0xA0], xmm11
00007895b19d1320  vmovaps [rsp+0xB0], xmm12
00007895b19d1329  vmovaps [rsp+0xC0], xmm13
00007895b19d1332  vmovaps [rsp+0xD0], xmm14
00007895b19d133b  vmovaps [rsp+0xE0], xmm15
00007895b19d1344  sub rsp, 0x40
00007895b19d1348  lea rdi, [rsp]
00007895b19d134c  lea rsi, [rsp+0x10]
00007895b19d1351  lea rdx, [rsp+0x20]
00007895b19d1356  lea rcx, [rsp+0x30]
00007895b19d135b  mov r8d, 0x00
00007895b19d1361  lea r9, [r15+0x3A8]
00007895b19d1368  movaps [rdi], xmm2
00007895b19d136b  movaps [rsi], xmm8
00007895b19d136f  movaps [rdx], xmm13
00007895b19d1373  movaps [rcx], xmm3
00007895b19d1376  mov rax, 0x59D4522A9A50
00007895b19d1380  call rax
00007895b19d1382  movaps xmm2, [rsp]
00007895b19d1386  add rsp, 0x40
00007895b19d138a  vmovaps xmm0, [rsp]
00007895b19d138f  vmovaps xmm1, [rsp+0x10]
00007895b19d1395  vmovaps xmm3, [rsp+0x20]
00007895b19d139b  vmovaps xmm4, [rsp+0x30]
00007895b19d13a1  vmovaps xmm5, [rsp+0x40]
00007895b19d13a7  vmovaps xmm6, [rsp+0x50]
00007895b19d13ad  vmovaps xmm7, [rsp+0x60]
00007895b19d13b3  vmovaps xmm8, [rsp+0x70]
00007895b19d13b9  vmovaps xmm9, [rsp+0x80]
00007895b19d13c2  vmovaps xmm10, [rsp+0x90]
00007895b19d13cb  vmovaps xmm11, [rsp+0xA0]
00007895b19d13d4  vmovaps xmm12, [rsp+0xB0]
00007895b19d13dd  vmovaps xmm13, [rsp+0xC0]
00007895b19d13e6  vmovaps xmm14, [rsp+0xD0]
00007895b19d13ef  vmovaps xmm15, [rsp+0xE0]
00007895b19d13f8  add rsp, 0xF0
00007895b19d13ff  pop r11
00007895b19d1401  pop r10
00007895b19d1403  pop r9
00007895b19d1405  pop r8
00007895b19d1407  pop rsi
00007895b19d1408  pop rdi
00007895b19d1409  pop rdx
00007895b19d140a  pop rcx
00007895b19d140b  pop rax
00007895b19d140c  add rsp, 0x08
00007895b19d1410  jmp 0x00007895B19CFB8C
00007895b19d1415  sub rsp, 0x08
00007895b19d1419  push rax
00007895b19d141a  push rcx
00007895b19d141b  push rdx
00007895b19d141c  push rdi
00007895b19d141d  push rsi
00007895b19d141e  push r8
00007895b19d1420  push r9
00007895b19d1422  push r10
00007895b19d1424  push r11
00007895b19d1426  sub rsp, 0xF0
00007895b19d142d  vmovaps [rsp], xmm0
00007895b19d1432  vmovaps [rsp+0x10], xmm1
00007895b19d1438  vmovaps [rsp+0x20], xmm2
00007895b19d143e  vmovaps [rsp+0x30], xmm3
00007895b19d1444  vmovaps [rsp+0x40], xmm4
00007895b19d144a  vmovaps [rsp+0x50], xmm5
00007895b19d1450  vmovaps [rsp+0x60], xmm6
00007895b19d1456  vmovaps [rsp+0x70], xmm7
00007895b19d145c  vmovaps [rsp+0x80], xmm9
00007895b19d1465  vmovaps [rsp+0x90], xmm10
00007895b19d146e  vmovaps [rsp+0xA0], xmm11
00007895b19d1477  vmovaps [rsp+0xB0], xmm12
00007895b19d1480  vmovaps [rsp+0xC0], xmm13
00007895b19d1489  vmovaps [rsp+0xD0], xmm14
00007895b19d1492  vmovaps [rsp+0xE0], xmm15
00007895b19d149b  sub rsp, 0x40
00007895b19d149f  lea rdi, [rsp]
00007895b19d14a3  lea rsi, [rsp+0x10]
00007895b19d14a8  lea rdx, [rsp+0x20]
00007895b19d14ad  lea rcx, [rsp+0x30]
00007895b19d14b2  mov r8d, 0x00
00007895b19d14b8  lea r9, [r15+0x3A8]
00007895b19d14bf  movaps [rdi], xmm8
00007895b19d14c3  movaps [rsi], xmm15
00007895b19d14c7  movaps [rdx], xmm13
00007895b19d14cb  movaps [rcx], xmm1
00007895b19d14ce  mov rax, 0x59D4522A9A50
00007895b19d14d8  call rax
00007895b19d14da  movaps xmm8, [rsp]
00007895b19d14df  add rsp, 0x40
00007895b19d14e3  vmovaps xmm0, [rsp]
00007895b19d14e8  vmovaps xmm1, [rsp+0x10]
00007895b19d14ee  vmovaps xmm2, [rsp+0x20]
00007895b19d14f4  vmovaps xmm3, [rsp+0x30]
00007895b19d14fa  vmovaps xmm4, [rsp+0x40]
00007895b19d1500  vmovaps xmm5, [rsp+0x50]
00007895b19d1506  vmovaps xmm6, [rsp+0x60]
00007895b19d150c  vmovaps xmm7, [rsp+0x70]
00007895b19d1512  vmovaps xmm9, [rsp+0x80]
00007895b19d151b  vmovaps xmm10, [rsp+0x90]
00007895b19d1524  vmovaps xmm11, [rsp+0xA0]
00007895b19d152d  vmovaps xmm12, [rsp+0xB0]
00007895b19d1536  vmovaps xmm13, [rsp+0xC0]
00007895b19d153f  vmovaps xmm14, [rsp+0xD0]
00007895b19d1548  vmovaps xmm15, [rsp+0xE0]
00007895b19d1551  add rsp, 0xF0
00007895b19d1558  pop r11
00007895b19d155a  pop r10
00007895b19d155c  pop r9
00007895b19d155e  pop r8
00007895b19d1560  pop rsi
00007895b19d1561  pop rdi
00007895b19d1562  pop rdx
00007895b19d1563  pop rcx
00007895b19d1564  pop rax
00007895b19d1565  add rsp, 0x08
00007895b19d1569  jmp 0x00007895B19CFBBB
00007895b19d156e  call 0x00007895B17FF430
00007895b19d1573  jmp 0x00007895B19CFBC8
00007895b19d1578  sub rsp, 0x08
00007895b19d157c  push rax
00007895b19d157d  push rcx
00007895b19d157e  push rdx
00007895b19d157f  push rdi
00007895b19d1580  push rsi
00007895b19d1581  push r8
00007895b19d1583  push r9
00007895b19d1585  push r10
00007895b19d1587  push r11
00007895b19d1589  sub rsp, 0xF0
00007895b19d1590  vmovaps [rsp], xmm0
00007895b19d1595  vmovaps [rsp+0x10], xmm1
00007895b19d159b  vmovaps [rsp+0x20], xmm2
00007895b19d15a1  vmovaps [rsp+0x30], xmm3
00007895b19d15a7  vmovaps [rsp+0x40], xmm4
00007895b19d15ad  vmovaps [rsp+0x50], xmm5
00007895b19d15b3  vmovaps [rsp+0x60], xmm6
00007895b19d15b9  vmovaps [rsp+0x70], xmm7
00007895b19d15bf  vmovaps [rsp+0x80], xmm8
00007895b19d15c8  vmovaps [rsp+0x90], xmm9
00007895b19d15d1  vmovaps [rsp+0xA0], xmm10
00007895b19d15da  vmovaps [rsp+0xB0], xmm11
00007895b19d15e3  vmovaps [rsp+0xC0], xmm12
00007895b19d15ec  vmovaps [rsp+0xD0], xmm14
00007895b19d15f5  vmovaps [rsp+0xE0], xmm15
00007895b19d15fe  sub rsp, 0x40
00007895b19d1602  lea rdi, [rsp]
00007895b19d1606  lea rsi, [rsp+0x10]
00007895b19d160b  lea rdx, [rsp+0x20]
00007895b19d1610  lea rcx, [rsp+0x30]
00007895b19d1615  mov r8d, 0x00
00007895b19d161b  lea r9, [r15+0x3A8]
00007895b19d1622  movaps [rdi], xmm13
00007895b19d1626  movaps [rsi], xmm5
00007895b19d1629  movaps [rdx], xmm11
00007895b19d162d  movaps [rcx], xmm15
00007895b19d1631  mov rax, 0x59D4522A9A50
00007895b19d163b  call rax
00007895b19d163d  movaps xmm13, [rsp]
00007895b19d1642  add rsp, 0x40
00007895b19d1646  vmovaps xmm0, [rsp]
00007895b19d164b  vmovaps xmm1, [rsp+0x10]
00007895b19d1651  vmovaps xmm2, [rsp+0x20]
00007895b19d1657  vmovaps xmm3, [rsp+0x30]
00007895b19d165d  vmovaps xmm4, [rsp+0x40]
00007895b19d1663  vmovaps xmm5, [rsp+0x50]
00007895b19d1669  vmovaps xmm6, [rsp+0x60]
00007895b19d166f  vmovaps xmm7, [rsp+0x70]
00007895b19d1675  vmovaps xmm8, [rsp+0x80]
00007895b19d167e  vmovaps xmm9, [rsp+0x90]
00007895b19d1687  vmovaps xmm10, [rsp+0xA0]
00007895b19d1690  vmovaps xmm11, [rsp+0xB0]
00007895b19d1699  vmovaps xmm12, [rsp+0xC0]
00007895b19d16a2  vmovaps xmm14, [rsp+0xD0]
00007895b19d16ab  vmovaps xmm15, [rsp+0xE0]
00007895b19d16b4  add rsp, 0xF0
00007895b19d16bb  pop r11
00007895b19d16bd  pop r10
00007895b19d16bf  pop r9
00007895b19d16c1  pop r8
00007895b19d16c3  pop rsi
00007895b19d16c4  pop rdi
00007895b19d16c5  pop rdx
00007895b19d16c6  pop rcx
00007895b19d16c7  pop rax
00007895b19d16c8  add rsp, 0x08
00007895b19d16cc  jmp 0x00007895B19CFBF9
00007895b19d16d1  sub rsp, 0x08
00007895b19d16d5  push rax
00007895b19d16d6  push rcx
00007895b19d16d7  push rdx
00007895b19d16d8  push rdi
00007895b19d16d9  push rsi
00007895b19d16da  push r8
00007895b19d16dc  push r9
00007895b19d16de  push r10
00007895b19d16e0  push r11
00007895b19d16e2  sub rsp, 0xF0
00007895b19d16e9  vmovaps [rsp], xmm0
00007895b19d16ee  vmovaps [rsp+0x10], xmm1
00007895b19d16f4  vmovaps [rsp+0x20], xmm2
00007895b19d16fa  vmovaps [rsp+0x30], xmm3
00007895b19d1700  vmovaps [rsp+0x40], xmm4
00007895b19d1706  vmovaps [rsp+0x50], xmm5
00007895b19d170c  vmovaps [rsp+0x60], xmm6
00007895b19d1712  vmovaps [rsp+0x70], xmm7
00007895b19d1718  vmovaps [rsp+0x80], xmm8
00007895b19d1721  vmovaps [rsp+0x90], xmm9
00007895b19d172a  vmovaps [rsp+0xA0], xmm10
00007895b19d1733  vmovaps [rsp+0xB0], xmm12
00007895b19d173c  vmovaps [rsp+0xC0], xmm13
00007895b19d1745  vmovaps [rsp+0xD0], xmm14
00007895b19d174e  vmovaps [rsp+0xE0], xmm15
00007895b19d1757  sub rsp, 0x40
00007895b19d175b  lea rdi, [rsp]
00007895b19d175f  lea rsi, [rsp+0x10]
00007895b19d1764  lea rdx, [rsp+0x20]
00007895b19d1769  lea rcx, [rsp+0x30]
00007895b19d176e  mov r8d, 0x00
00007895b19d1774  lea r9, [r15+0x3A8]
00007895b19d177b  movaps [rdi], xmm11
00007895b19d177f  movaps [rsi], xmm9
00007895b19d1783  movaps [rdx], xmm4
00007895b19d1786  movaps [rcx], xmm15
00007895b19d178a  mov rax, 0x59D4522A9A50
00007895b19d1794  call rax
00007895b19d1796  movaps xmm11, [rsp]
00007895b19d179b  add rsp, 0x40
00007895b19d179f  vmovaps xmm0, [rsp]
00007895b19d17a4  vmovaps xmm1, [rsp+0x10]
00007895b19d17aa  vmovaps xmm2, [rsp+0x20]
00007895b19d17b0  vmovaps xmm3, [rsp+0x30]
00007895b19d17b6  vmovaps xmm4, [rsp+0x40]
00007895b19d17bc  vmovaps xmm5, [rsp+0x50]
00007895b19d17c2  vmovaps xmm6, [rsp+0x60]
00007895b19d17c8  vmovaps xmm7, [rsp+0x70]
00007895b19d17ce  vmovaps xmm8, [rsp+0x80]
00007895b19d17d7  vmovaps xmm9, [rsp+0x90]
00007895b19d17e0  vmovaps xmm10, [rsp+0xA0]
00007895b19d17e9  vmovaps xmm12, [rsp+0xB0]
00007895b19d17f2  vmovaps xmm13, [rsp+0xC0]
00007895b19d17fb  vmovaps xmm14, [rsp+0xD0]
00007895b19d1804  vmovaps xmm15, [rsp+0xE0]
00007895b19d180d  add rsp, 0xF0
00007895b19d1814  pop r11
00007895b19d1816  pop r10
00007895b19d1818  pop r9
00007895b19d181a  pop r8
00007895b19d181c  pop rsi
00007895b19d181d  pop rdi
00007895b19d181e  pop rdx
00007895b19d181f  pop rcx
00007895b19d1820  pop rax
00007895b19d1821  add rsp, 0x08
00007895b19d1825  jmp 0x00007895B19CFC22
00007895b19d182a  call 0x00007895B180E760
00007895b19d182f  jmp 0x00007895B19CFC45
00007895b19d1834  call 0x00007895B1807890
00007895b19d1839  jmp 0x00007895B19CFC4F
00007895b19d183e  sub rsp, 0x08
00007895b19d1842  push rax
00007895b19d1843  push rcx
00007895b19d1844  push rdx
00007895b19d1845  push rdi
00007895b19d1846  push rsi
00007895b19d1847  push r8
00007895b19d1849  push r9
00007895b19d184b  push r10
00007895b19d184d  push r11
00007895b19d184f  sub rsp, 0xF0
00007895b19d1856  vmovaps [rsp], xmm0
00007895b19d185b  vmovaps [rsp+0x10], xmm1
00007895b19d1861  vmovaps [rsp+0x20], xmm2
00007895b19d1867  vmovaps [rsp+0x30], xmm3
00007895b19d186d  vmovaps [rsp+0x40], xmm5
00007895b19d1873  vmovaps [rsp+0x50], xmm6
00007895b19d1879  vmovaps [rsp+0x60], xmm7
00007895b19d187f  vmovaps [rsp+0x70], xmm8
00007895b19d1885  vmovaps [rsp+0x80], xmm9
00007895b19d188e  vmovaps [rsp+0x90], xmm10
00007895b19d1897  vmovaps [rsp+0xA0], xmm11
00007895b19d18a0  vmovaps [rsp+0xB0], xmm12
00007895b19d18a9  vmovaps [rsp+0xC0], xmm13
00007895b19d18b2  vmovaps [rsp+0xD0], xmm14
00007895b19d18bb  vmovaps [rsp+0xE0], xmm15
00007895b19d18c4  sub rsp, 0x40
00007895b19d18c8  lea rdi, [rsp]
00007895b19d18cc  lea rsi, [rsp+0x10]
00007895b19d18d1  lea rdx, [rsp+0x20]
00007895b19d18d6  lea rcx, [rsp+0x30]
00007895b19d18db  mov r8d, 0x00
00007895b19d18e1  lea r9, [r15+0x3A8]
00007895b19d18e8  movaps [rdi], xmm4
00007895b19d18eb  movaps [rsi], xmm2
00007895b19d18ee  movaps [rdx], xmm14
00007895b19d18f2  movaps [rcx], xmm5
00007895b19d18f5  mov rax, 0x59D4522A9A50
00007895b19d18ff  call rax
00007895b19d1901  movaps xmm4, [rsp]
00007895b19d1905  add rsp, 0x40
00007895b19d1909  vmovaps xmm0, [rsp]
00007895b19d190e  vmovaps xmm1, [rsp+0x10]
00007895b19d1914  vmovaps xmm2, [rsp+0x20]
00007895b19d191a  vmovaps xmm3, [rsp+0x30]
00007895b19d1920  vmovaps xmm5, [rsp+0x40]
00007895b19d1926  vmovaps xmm6, [rsp+0x50]
00007895b19d192c  vmovaps xmm7, [rsp+0x60]
00007895b19d1932  vmovaps xmm8, [rsp+0x70]
00007895b19d1938  vmovaps xmm9, [rsp+0x80]
00007895b19d1941  vmovaps xmm10, [rsp+0x90]
00007895b19d194a  vmovaps xmm11, [rsp+0xA0]
00007895b19d1953  vmovaps xmm12, [rsp+0xB0]
00007895b19d195c  vmovaps xmm13, [rsp+0xC0]
00007895b19d1965  vmovaps xmm14, [rsp+0xD0]
00007895b19d196e  vmovaps xmm15, [rsp+0xE0]
00007895b19d1977  add rsp, 0xF0
00007895b19d197e  pop r11
00007895b19d1980  pop r10
00007895b19d1982  pop r9
00007895b19d1984  pop r8
00007895b19d1986  pop rsi
00007895b19d1987  pop rdi
00007895b19d1988  pop rdx
00007895b19d1989  pop rcx
00007895b19d198a  pop rax
00007895b19d198b  add rsp, 0x08
00007895b19d198f  jmp 0x00007895B19CFC86
00007895b19d1994  sub rsp, 0x08
00007895b19d1998  push rax
00007895b19d1999  push rcx
00007895b19d199a  push rdx
00007895b19d199b  push rdi
00007895b19d199c  push rsi
00007895b19d199d  push r8
00007895b19d199f  push r9
00007895b19d19a1  push r10
00007895b19d19a3  push r11
00007895b19d19a5  sub rsp, 0xF0
00007895b19d19ac  vmovaps [rsp], xmm0
00007895b19d19b1  vmovaps [rsp+0x10], xmm1
00007895b19d19b7  vmovaps [rsp+0x20], xmm2
00007895b19d19bd  vmovaps [rsp+0x30], xmm3
00007895b19d19c3  vmovaps [rsp+0x40], xmm4
00007895b19d19c9  vmovaps [rsp+0x50], xmm6
00007895b19d19cf  vmovaps [rsp+0x60], xmm7
00007895b19d19d5  vmovaps [rsp+0x70], xmm8
00007895b19d19db  vmovaps [rsp+0x80], xmm9
00007895b19d19e4  vmovaps [rsp+0x90], xmm10
00007895b19d19ed  vmovaps [rsp+0xA0], xmm11
00007895b19d19f6  vmovaps [rsp+0xB0], xmm12
00007895b19d19ff  vmovaps [rsp+0xC0], xmm13
00007895b19d1a08  vmovaps [rsp+0xD0], xmm14
00007895b19d1a11  vmovaps [rsp+0xE0], xmm15
00007895b19d1a1a  sub rsp, 0x40
00007895b19d1a1e  lea rdi, [rsp]
00007895b19d1a22  lea rsi, [rsp+0x10]
00007895b19d1a27  lea rdx, [rsp+0x20]
00007895b19d1a2c  lea rcx, [rsp+0x30]
00007895b19d1a31  mov r8d, 0x00
00007895b19d1a37  lea r9, [r15+0x3A8]
00007895b19d1a3e  movaps [rdi], xmm5
00007895b19d1a41  movaps [rsi], xmm8
00007895b19d1a45  movaps [rdx], xmm7
00007895b19d1a48  movaps [rcx], xmm14
00007895b19d1a4c  mov rax, 0x59D4522A9A50
00007895b19d1a56  call rax
00007895b19d1a58  movaps xmm5, [rsp]
00007895b19d1a5c  add rsp, 0x40
00007895b19d1a60  vmovaps xmm0, [rsp]
00007895b19d1a65  vmovaps xmm1, [rsp+0x10]
00007895b19d1a6b  vmovaps xmm2, [rsp+0x20]
00007895b19d1a71  vmovaps xmm3, [rsp+0x30]
00007895b19d1a77  vmovaps xmm4, [rsp+0x40]
00007895b19d1a7d  vmovaps xmm6, [rsp+0x50]
00007895b19d1a83  vmovaps xmm7, [rsp+0x60]
00007895b19d1a89  vmovaps xmm8, [rsp+0x70]
00007895b19d1a8f  vmovaps xmm9, [rsp+0x80]
00007895b19d1a98  vmovaps xmm10, [rsp+0x90]
00007895b19d1aa1  vmovaps xmm11, [rsp+0xA0]
00007895b19d1aaa  vmovaps xmm12, [rsp+0xB0]
00007895b19d1ab3  vmovaps xmm13, [rsp+0xC0]
00007895b19d1abc  vmovaps xmm14, [rsp+0xD0]
00007895b19d1ac5  vmovaps xmm15, [rsp+0xE0]
00007895b19d1ace  add rsp, 0xF0
00007895b19d1ad5  pop r11
00007895b19d1ad7  pop r10
00007895b19d1ad9  pop r9
00007895b19d1adb  pop r8
00007895b19d1add  pop rsi
00007895b19d1ade  pop rdi
00007895b19d1adf  pop rdx
00007895b19d1ae0  pop rcx
00007895b19d1ae1  pop rax
00007895b19d1ae2  add rsp, 0x08
00007895b19d1ae6  jmp 0x00007895B19CFCAE
00007895b19d1aeb  sub rsp, 0x08
00007895b19d1aef  push rax
00007895b19d1af0  push rcx
00007895b19d1af1  push rdx
00007895b19d1af2  push rdi
00007895b19d1af3  push rsi
00007895b19d1af4  push r8
00007895b19d1af6  push r9
00007895b19d1af8  push r10
00007895b19d1afa  push r11
00007895b19d1afc  sub rsp, 0xF0
00007895b19d1b03  vmovaps [rsp], xmm0
00007895b19d1b08  vmovaps [rsp+0x10], xmm1
00007895b19d1b0e  vmovaps [rsp+0x20], xmm2
00007895b19d1b14  vmovaps [rsp+0x30], xmm3
00007895b19d1b1a  vmovaps [rsp+0x40], xmm4
00007895b19d1b20  vmovaps [rsp+0x50], xmm5
00007895b19d1b26  vmovaps [rsp+0x60], xmm6
00007895b19d1b2c  vmovaps [rsp+0x70], xmm7
00007895b19d1b32  vmovaps [rsp+0x80], xmm9
00007895b19d1b3b  vmovaps [rsp+0x90], xmm10
00007895b19d1b44  vmovaps [rsp+0xA0], xmm11
00007895b19d1b4d  vmovaps [rsp+0xB0], xmm12
00007895b19d1b56  vmovaps [rsp+0xC0], xmm13
00007895b19d1b5f  vmovaps [rsp+0xD0], xmm14
00007895b19d1b68  vmovaps [rsp+0xE0], xmm15
00007895b19d1b71  sub rsp, 0x40
00007895b19d1b75  lea rdi, [rsp]
00007895b19d1b79  lea rsi, [rsp+0x10]
00007895b19d1b7e  lea rdx, [rsp+0x20]
00007895b19d1b83  lea rcx, [rsp+0x30]
00007895b19d1b88  mov r8d, 0x00
00007895b19d1b8e  lea r9, [r15+0x3A8]
00007895b19d1b95  movaps [rdi], xmm8
00007895b19d1b99  movaps [rsi], xmm13
00007895b19d1b9d  movaps [rdx], xmm6
00007895b19d1ba0  movaps [rcx], xmm14
00007895b19d1ba4  mov rax, 0x59D4522A9A50
00007895b19d1bae  call rax
00007895b19d1bb0  movaps xmm8, [rsp]
00007895b19d1bb5  add rsp, 0x40
00007895b19d1bb9  vmovaps xmm0, [rsp]
00007895b19d1bbe  vmovaps xmm1, [rsp+0x10]
00007895b19d1bc4  vmovaps xmm2, [rsp+0x20]
00007895b19d1bca  vmovaps xmm3, [rsp+0x30]
00007895b19d1bd0  vmovaps xmm4, [rsp+0x40]
00007895b19d1bd6  vmovaps xmm5, [rsp+0x50]
00007895b19d1bdc  vmovaps xmm6, [rsp+0x60]
00007895b19d1be2  vmovaps xmm7, [rsp+0x70]
00007895b19d1be8  vmovaps xmm9, [rsp+0x80]
00007895b19d1bf1  vmovaps xmm10, [rsp+0x90]
00007895b19d1bfa  vmovaps xmm11, [rsp+0xA0]
00007895b19d1c03  vmovaps xmm12, [rsp+0xB0]
00007895b19d1c0c  vmovaps xmm13, [rsp+0xC0]
00007895b19d1c15  vmovaps xmm14, [rsp+0xD0]
00007895b19d1c1e  vmovaps xmm15, [rsp+0xE0]
00007895b19d1c27  add rsp, 0xF0
00007895b19d1c2e  pop r11
00007895b19d1c30  pop r10
00007895b19d1c32  pop r9
00007895b19d1c34  pop r8
00007895b19d1c36  pop rsi
00007895b19d1c37  pop rdi
00007895b19d1c38  pop rdx
00007895b19d1c39  pop rcx
00007895b19d1c3a  pop rax
00007895b19d1c3b  add rsp, 0x08
00007895b19d1c3f  jmp 0x00007895B19CFCD7
00007895b19d1c44  sub rsp, 0x08
00007895b19d1c48  push rax
00007895b19d1c49  push rcx
00007895b19d1c4a  push rdx
00007895b19d1c4b  push rdi
00007895b19d1c4c  push rsi
00007895b19d1c4d  push r8
00007895b19d1c4f  push r9
00007895b19d1c51  push r10
00007895b19d1c53  push r11
00007895b19d1c55  sub rsp, 0xF0
00007895b19d1c5c  vmovaps [rsp], xmm0
00007895b19d1c61  vmovaps [rsp+0x10], xmm1
00007895b19d1c67  vmovaps [rsp+0x20], xmm2
00007895b19d1c6d  vmovaps [rsp+0x30], xmm3
00007895b19d1c73  vmovaps [rsp+0x40], xmm4
00007895b19d1c79  vmovaps [rsp+0x50], xmm5
00007895b19d1c7f  vmovaps [rsp+0x60], xmm6
00007895b19d1c85  vmovaps [rsp+0x70], xmm7
00007895b19d1c8b  vmovaps [rsp+0x80], xmm8
00007895b19d1c94  vmovaps [rsp+0x90], xmm9
00007895b19d1c9d  vmovaps [rsp+0xA0], xmm10
00007895b19d1ca6  vmovaps [rsp+0xB0], xmm11
00007895b19d1caf  vmovaps [rsp+0xC0], xmm12
00007895b19d1cb8  vmovaps [rsp+0xD0], xmm14
00007895b19d1cc1  vmovaps [rsp+0xE0], xmm15
00007895b19d1cca  sub rsp, 0x40
00007895b19d1cce  lea rdi, [rsp]
00007895b19d1cd2  lea rsi, [rsp+0x10]
00007895b19d1cd7  lea rdx, [rsp+0x20]
00007895b19d1cdc  lea rcx, [rsp+0x30]
00007895b19d1ce1  mov r8d, 0x00
00007895b19d1ce7  lea r9, [r15+0x3A8]
00007895b19d1cee  movaps [rdi], xmm13
00007895b19d1cf2  movaps [rsi], xmm11
00007895b19d1cf6  movaps [rdx], xmm12
00007895b19d1cfa  movaps [rcx], xmm14
00007895b19d1cfe  mov rax, 0x59D4522A9A50
00007895b19d1d08  call rax
00007895b19d1d0a  movaps xmm13, [rsp]
00007895b19d1d0f  add rsp, 0x40
00007895b19d1d13  vmovaps xmm0, [rsp]
00007895b19d1d18  vmovaps xmm1, [rsp+0x10]
00007895b19d1d1e  vmovaps xmm2, [rsp+0x20]
00007895b19d1d24  vmovaps xmm3, [rsp+0x30]
00007895b19d1d2a  vmovaps xmm4, [rsp+0x40]
00007895b19d1d30  vmovaps xmm5, [rsp+0x50]
00007895b19d1d36  vmovaps xmm6, [rsp+0x60]
00007895b19d1d3c  vmovaps xmm7, [rsp+0x70]
00007895b19d1d42  vmovaps xmm8, [rsp+0x80]
00007895b19d1d4b  vmovaps xmm9, [rsp+0x90]
00007895b19d1d54  vmovaps xmm10, [rsp+0xA0]
00007895b19d1d5d  vmovaps xmm11, [rsp+0xB0]
00007895b19d1d66  vmovaps xmm12, [rsp+0xC0]
00007895b19d1d6f  vmovaps xmm14, [rsp+0xD0]
00007895b19d1d78  vmovaps xmm15, [rsp+0xE0]
00007895b19d1d81  add rsp, 0xF0
00007895b19d1d88  pop r11
00007895b19d1d8a  pop r10
00007895b19d1d8c  pop r9
00007895b19d1d8e  pop r8
00007895b19d1d90  pop rsi
00007895b19d1d91  pop rdi
00007895b19d1d92  pop rdx
00007895b19d1d93  pop rcx
00007895b19d1d94  pop rax
00007895b19d1d95  add rsp, 0x08
00007895b19d1d99  jmp 0x00007895B19CFD00
00007895b19d1d9e  call 0x00007895B180D4E0
00007895b19d1da3  jmp 0x00007895B19CFD0A
00007895b19d1da8  call 0x00007895B180AFE0
00007895b19d1dad  jmp 0x00007895B19CFD14
00007895b19d1db2  sub rsp, 0x08
00007895b19d1db6  push rax
00007895b19d1db7  push rcx
00007895b19d1db8  push rdx
00007895b19d1db9  push rdi
00007895b19d1dba  push rsi
00007895b19d1dbb  push r8
00007895b19d1dbd  push r9
00007895b19d1dbf  push r10
00007895b19d1dc1  push r11
00007895b19d1dc3  sub rsp, 0xF0
00007895b19d1dca  vmovaps [rsp], xmm0
00007895b19d1dcf  vmovaps [rsp+0x10], xmm1
00007895b19d1dd5  vmovaps [rsp+0x20], xmm2
00007895b19d1ddb  vmovaps [rsp+0x30], xmm3
00007895b19d1de1  vmovaps [rsp+0x40], xmm4
00007895b19d1de7  vmovaps [rsp+0x50], xmm5
00007895b19d1ded  vmovaps [rsp+0x60], xmm6
00007895b19d1df3  vmovaps [rsp+0x70], xmm8
00007895b19d1df9  vmovaps [rsp+0x80], xmm9
00007895b19d1e02  vmovaps [rsp+0x90], xmm10
00007895b19d1e0b  vmovaps [rsp+0xA0], xmm11
00007895b19d1e14  vmovaps [rsp+0xB0], xmm12
00007895b19d1e1d  vmovaps [rsp+0xC0], xmm13
00007895b19d1e26  vmovaps [rsp+0xD0], xmm14
00007895b19d1e2f  vmovaps [rsp+0xE0], xmm15
00007895b19d1e38  sub rsp, 0x40
00007895b19d1e3c  lea rdi, [rsp]
00007895b19d1e40  lea rsi, [rsp+0x10]
00007895b19d1e45  lea rdx, [rsp+0x20]
00007895b19d1e4a  lea rcx, [rsp+0x30]
00007895b19d1e4f  mov r8d, 0x00
00007895b19d1e55  lea r9, [r15+0x3A8]
00007895b19d1e5c  movaps [rdi], xmm7
00007895b19d1e5f  movaps [rsi], xmm4
00007895b19d1e62  movaps [rdx], xmm9
00007895b19d1e66  movaps [rcx], xmm11
00007895b19d1e6a  mov rax, 0x59D4522A9A50
00007895b19d1e74  call rax
00007895b19d1e76  movaps xmm7, [rsp]
00007895b19d1e7a  add rsp, 0x40
00007895b19d1e7e  vmovaps xmm0, [rsp]
00007895b19d1e83  vmovaps xmm1, [rsp+0x10]
00007895b19d1e89  vmovaps xmm2, [rsp+0x20]
00007895b19d1e8f  vmovaps xmm3, [rsp+0x30]
00007895b19d1e95  vmovaps xmm4, [rsp+0x40]
00007895b19d1e9b  vmovaps xmm5, [rsp+0x50]
00007895b19d1ea1  vmovaps xmm6, [rsp+0x60]
00007895b19d1ea7  vmovaps xmm8, [rsp+0x70]
00007895b19d1ead  vmovaps xmm9, [rsp+0x80]
00007895b19d1eb6  vmovaps xmm10, [rsp+0x90]
00007895b19d1ebf  vmovaps xmm11, [rsp+0xA0]
00007895b19d1ec8  vmovaps xmm12, [rsp+0xB0]
00007895b19d1ed1  vmovaps xmm13, [rsp+0xC0]
00007895b19d1eda  vmovaps xmm14, [rsp+0xD0]
00007895b19d1ee3  vmovaps xmm15, [rsp+0xE0]
00007895b19d1eec  add rsp, 0xF0
00007895b19d1ef3  pop r11
00007895b19d1ef5  pop r10
00007895b19d1ef7  pop r9
00007895b19d1ef9  pop r8
00007895b19d1efb  pop rsi
00007895b19d1efc  pop rdi
00007895b19d1efd  pop rdx
00007895b19d1efe  pop rcx
00007895b19d1eff  pop rax
00007895b19d1f00  add rsp, 0x08
00007895b19d1f04  jmp 0x00007895B19CFD4B
00007895b19d1f09  sub rsp, 0x08
00007895b19d1f0d  push rax
00007895b19d1f0e  push rcx
00007895b19d1f0f  push rdx
00007895b19d1f10  push rdi
00007895b19d1f11  push rsi
00007895b19d1f12  push r8
00007895b19d1f14  push r9
00007895b19d1f16  push r10
00007895b19d1f18  push r11
00007895b19d1f1a  sub rsp, 0xF0
00007895b19d1f21  vmovaps [rsp], xmm0
00007895b19d1f26  vmovaps [rsp+0x10], xmm1
00007895b19d1f2c  vmovaps [rsp+0x20], xmm2
00007895b19d1f32  vmovaps [rsp+0x30], xmm3
00007895b19d1f38  vmovaps [rsp+0x40], xmm4
00007895b19d1f3e  vmovaps [rsp+0x50], xmm5
00007895b19d1f44  vmovaps [rsp+0x60], xmm6
00007895b19d1f4a  vmovaps [rsp+0x70], xmm7
00007895b19d1f50  vmovaps [rsp+0x80], xmm8
00007895b19d1f59  vmovaps [rsp+0x90], xmm10
00007895b19d1f62  vmovaps [rsp+0xA0], xmm11
00007895b19d1f6b  vmovaps [rsp+0xB0], xmm12
00007895b19d1f74  vmovaps [rsp+0xC0], xmm13
00007895b19d1f7d  vmovaps [rsp+0xD0], xmm14
00007895b19d1f86  vmovaps [rsp+0xE0], xmm15
00007895b19d1f8f  sub rsp, 0x40
00007895b19d1f93  lea rdi, [rsp]
00007895b19d1f97  lea rsi, [rsp+0x10]
00007895b19d1f9c  lea rdx, [rsp+0x20]
00007895b19d1fa1  lea rcx, [rsp+0x30]
00007895b19d1fa6  mov r8d, 0x00
00007895b19d1fac  lea r9, [r15+0x3A8]
00007895b19d1fb3  movaps [rdi], xmm9
00007895b19d1fb7  movaps [rsi], xmm5
00007895b19d1fba  movaps [rdx], xmm14
00007895b19d1fbe  movaps [rcx], xmm11
00007895b19d1fc2  mov rax, 0x59D4522A9A50
00007895b19d1fcc  call rax
00007895b19d1fce  movaps xmm9, [rsp]
00007895b19d1fd3  add rsp, 0x40
00007895b19d1fd7  vmovaps xmm0, [rsp]
00007895b19d1fdc  vmovaps xmm1, [rsp+0x10]
00007895b19d1fe2  vmovaps xmm2, [rsp+0x20]
00007895b19d1fe8  vmovaps xmm3, [rsp+0x30]
00007895b19d1fee  vmovaps xmm4, [rsp+0x40]
00007895b19d1ff4  vmovaps xmm5, [rsp+0x50]
00007895b19d1ffa  vmovaps xmm6, [rsp+0x60]
00007895b19d2000  vmovaps xmm7, [rsp+0x70]
00007895b19d2006  vmovaps xmm8, [rsp+0x80]
00007895b19d200f  vmovaps xmm10, [rsp+0x90]
00007895b19d2018  vmovaps xmm11, [rsp+0xA0]
00007895b19d2021  vmovaps xmm12, [rsp+0xB0]
00007895b19d202a  vmovaps xmm13, [rsp+0xC0]
00007895b19d2033  vmovaps xmm14, [rsp+0xD0]
00007895b19d203c  vmovaps xmm15, [rsp+0xE0]
00007895b19d2045  add rsp, 0xF0
00007895b19d204c  pop r11
00007895b19d204e  pop r10
00007895b19d2050  pop r9
00007895b19d2052  pop r8
00007895b19d2054  pop rsi
00007895b19d2055  pop rdi
00007895b19d2056  pop rdx
00007895b19d2057  pop rcx
00007895b19d2058  pop rax
00007895b19d2059  add rsp, 0x08
00007895b19d205d  jmp 0x00007895B19CFD74
00007895b19d2062  sub rsp, 0x08
00007895b19d2066  push rax
00007895b19d2067  push rcx
00007895b19d2068  push rdx
00007895b19d2069  push rdi
00007895b19d206a  push rsi
00007895b19d206b  push r8
00007895b19d206d  push r9
00007895b19d206f  push r10
00007895b19d2071  push r11
00007895b19d2073  sub rsp, 0xF0
00007895b19d207a  vmovaps [rsp], xmm0
00007895b19d207f  vmovaps [rsp+0x10], xmm1
00007895b19d2085  vmovaps [rsp+0x20], xmm2
00007895b19d208b  vmovaps [rsp+0x30], xmm3
00007895b19d2091  vmovaps [rsp+0x40], xmm4
00007895b19d2097  vmovaps [rsp+0x50], xmm5
00007895b19d209d  vmovaps [rsp+0x60], xmm6
00007895b19d20a3  vmovaps [rsp+0x70], xmm7
00007895b19d20a9  vmovaps [rsp+0x80], xmm8
00007895b19d20b2  vmovaps [rsp+0x90], xmm9
00007895b19d20bb  vmovaps [rsp+0xA0], xmm10
00007895b19d20c4  vmovaps [rsp+0xB0], xmm12
00007895b19d20cd  vmovaps [rsp+0xC0], xmm13
00007895b19d20d6  vmovaps [rsp+0xD0], xmm14
00007895b19d20df  vmovaps [rsp+0xE0], xmm15
00007895b19d20e8  sub rsp, 0x40
00007895b19d20ec  lea rdi, [rsp]
00007895b19d20f0  lea rsi, [rsp+0x10]
00007895b19d20f5  lea rdx, [rsp+0x20]
00007895b19d20fa  lea rcx, [rsp+0x30]
00007895b19d20ff  mov r8d, 0x00
00007895b19d2105  lea r9, [r15+0x3A8]
00007895b19d210c  movaps [rdi], xmm11
00007895b19d2110  movaps [rsi], xmm8
00007895b19d2114  movaps [rdx], xmm10
00007895b19d2118  movaps [rcx], xmm14
00007895b19d211c  mov rax, 0x59D4522A9A50
00007895b19d2126  call rax
00007895b19d2128  movaps xmm11, [rsp]
00007895b19d212d  add rsp, 0x40
00007895b19d2131  vmovaps xmm0, [rsp]
00007895b19d2136  vmovaps xmm1, [rsp+0x10]
00007895b19d213c  vmovaps xmm2, [rsp+0x20]
00007895b19d2142  vmovaps xmm3, [rsp+0x30]
00007895b19d2148  vmovaps xmm4, [rsp+0x40]
00007895b19d214e  vmovaps xmm5, [rsp+0x50]
00007895b19d2154  vmovaps xmm6, [rsp+0x60]
00007895b19d215a  vmovaps xmm7, [rsp+0x70]
00007895b19d2160  vmovaps xmm8, [rsp+0x80]
00007895b19d2169  vmovaps xmm9, [rsp+0x90]
00007895b19d2172  vmovaps xmm10, [rsp+0xA0]
00007895b19d217b  vmovaps xmm12, [rsp+0xB0]
00007895b19d2184  vmovaps xmm13, [rsp+0xC0]
00007895b19d218d  vmovaps xmm14, [rsp+0xD0]
00007895b19d2196  vmovaps xmm15, [rsp+0xE0]
00007895b19d219f  add rsp, 0xF0
00007895b19d21a6  pop r11
00007895b19d21a8  pop r10
00007895b19d21aa  pop r9
00007895b19d21ac  pop r8
00007895b19d21ae  pop rsi
00007895b19d21af  pop rdi
00007895b19d21b0  pop rdx
00007895b19d21b1  pop rcx
00007895b19d21b2  pop rax
00007895b19d21b3  add rsp, 0x08
00007895b19d21b7  jmp 0x00007895B19CFD9D
00007895b19d21bc  sub rsp, 0x08
00007895b19d21c0  push rax
00007895b19d21c1  push rcx
00007895b19d21c2  push rdx
00007895b19d21c3  push rdi
00007895b19d21c4  push rsi
00007895b19d21c5  push r8
00007895b19d21c7  push r9
00007895b19d21c9  push r10
00007895b19d21cb  push r11
00007895b19d21cd  sub rsp, 0xF0
00007895b19d21d4  vmovaps [rsp], xmm0
00007895b19d21d9  vmovaps [rsp+0x10], xmm1
00007895b19d21df  vmovaps [rsp+0x20], xmm2
00007895b19d21e5  vmovaps [rsp+0x30], xmm3
00007895b19d21eb  vmovaps [rsp+0x40], xmm4
00007895b19d21f1  vmovaps [rsp+0x50], xmm5
00007895b19d21f7  vmovaps [rsp+0x60], xmm6
00007895b19d21fd  vmovaps [rsp+0x70], xmm7
00007895b19d2203  vmovaps [rsp+0x80], xmm8
00007895b19d220c  vmovaps [rsp+0x90], xmm9
00007895b19d2215  vmovaps [rsp+0xA0], xmm11
00007895b19d221e  vmovaps [rsp+0xB0], xmm12
00007895b19d2227  vmovaps [rsp+0xC0], xmm13
00007895b19d2230  vmovaps [rsp+0xD0], xmm14
00007895b19d2239  vmovaps [rsp+0xE0], xmm15
00007895b19d2242  sub rsp, 0x40
00007895b19d2246  lea rdi, [rsp]
00007895b19d224a  lea rsi, [rsp+0x10]
00007895b19d224f  lea rdx, [rsp+0x20]
00007895b19d2254  lea rcx, [rsp+0x30]
00007895b19d2259  mov r8d, 0x00
00007895b19d225f  lea r9, [r15+0x3A8]
00007895b19d2266  movaps [rdi], xmm10
00007895b19d226a  movaps [rsi], xmm13
00007895b19d226e  movaps [rdx], xmm15
00007895b19d2272  movaps [rcx], xmm14
00007895b19d2276  mov rax, 0x59D4522A9A50
00007895b19d2280  call rax
00007895b19d2282  movaps xmm10, [rsp]
00007895b19d2287  add rsp, 0x40
00007895b19d228b  vmovaps xmm0, [rsp]
00007895b19d2290  vmovaps xmm1, [rsp+0x10]
00007895b19d2296  vmovaps xmm2, [rsp+0x20]
00007895b19d229c  vmovaps xmm3, [rsp+0x30]
00007895b19d22a2  vmovaps xmm4, [rsp+0x40]
00007895b19d22a8  vmovaps xmm5, [rsp+0x50]
00007895b19d22ae  vmovaps xmm6, [rsp+0x60]
00007895b19d22b4  vmovaps xmm7, [rsp+0x70]
00007895b19d22ba  vmovaps xmm8, [rsp+0x80]
00007895b19d22c3  vmovaps xmm9, [rsp+0x90]
00007895b19d22cc  vmovaps xmm11, [rsp+0xA0]
00007895b19d22d5  vmovaps xmm12, [rsp+0xB0]
00007895b19d22de  vmovaps xmm13, [rsp+0xC0]
00007895b19d22e7  vmovaps xmm14, [rsp+0xD0]
00007895b19d22f0  vmovaps xmm15, [rsp+0xE0]
00007895b19d22f9  add rsp, 0xF0
00007895b19d2300  pop r11
00007895b19d2302  pop r10
00007895b19d2304  pop r9
00007895b19d2306  pop r8
00007895b19d2308  pop rsi
00007895b19d2309  pop rdi
00007895b19d230a  pop rdx
00007895b19d230b  pop rcx
00007895b19d230c  pop rax
00007895b19d230d  add rsp, 0x08
00007895b19d2311  jmp 0x00007895B19CFDC6
00007895b19d2316  call 0x00007895B180E760
00007895b19d231b  jmp 0x00007895B19CFDD0
00007895b19d2320  call 0x00007895B180D4E0
00007895b19d2325  jmp 0x00007895B19CFDDA
00007895b19d232a  sub rsp, 0x08
00007895b19d232e  push rax
00007895b19d232f  push rcx
00007895b19d2330  push rdx
00007895b19d2331  push rdi
00007895b19d2332  push rsi
00007895b19d2333  push r8
00007895b19d2335  push r9
00007895b19d2337  push r10
00007895b19d2339  push r11
00007895b19d233b  sub rsp, 0xF0
00007895b19d2342  vmovaps [rsp], xmm0
00007895b19d2347  vmovaps [rsp+0x10], xmm1
00007895b19d234d  vmovaps [rsp+0x20], xmm2
00007895b19d2353  vmovaps [rsp+0x30], xmm3
00007895b19d2359  vmovaps [rsp+0x40], xmm4
00007895b19d235f  vmovaps [rsp+0x50], xmm5
00007895b19d2365  vmovaps [rsp+0x60], xmm7
00007895b19d236b  vmovaps [rsp+0x70], xmm8
00007895b19d2371  vmovaps [rsp+0x80], xmm9
00007895b19d237a  vmovaps [rsp+0x90], xmm10
00007895b19d2383  vmovaps [rsp+0xA0], xmm11
00007895b19d238c  vmovaps [rsp+0xB0], xmm12
00007895b19d2395  vmovaps [rsp+0xC0], xmm13
00007895b19d239e  vmovaps [rsp+0xD0], xmm14
00007895b19d23a7  vmovaps [rsp+0xE0], xmm15
00007895b19d23b0  sub rsp, 0x40
00007895b19d23b4  lea rdi, [rsp]
00007895b19d23b8  lea rsi, [rsp+0x10]
00007895b19d23bd  lea rdx, [rsp+0x20]
00007895b19d23c2  lea rcx, [rsp+0x30]
00007895b19d23c7  mov r8d, 0x00
00007895b19d23cd  lea r9, [r15+0x3A8]
00007895b19d23d4  movaps [rdi], xmm6
00007895b19d23d7  movaps [rsi], xmm7
00007895b19d23da  movaps [rdx], xmm8
00007895b19d23de  movaps [rcx], xmm13
00007895b19d23e2  mov rax, 0x59D4522A9A50
00007895b19d23ec  call rax
00007895b19d23ee  movaps xmm6, [rsp]
00007895b19d23f2  add rsp, 0x40
00007895b19d23f6  vmovaps xmm0, [rsp]
00007895b19d23fb  vmovaps xmm1, [rsp+0x10]
00007895b19d2401  vmovaps xmm2, [rsp+0x20]
00007895b19d2407  vmovaps xmm3, [rsp+0x30]
00007895b19d240d  vmovaps xmm4, [rsp+0x40]
00007895b19d2413  vmovaps xmm5, [rsp+0x50]
00007895b19d2419  vmovaps xmm7, [rsp+0x60]
00007895b19d241f  vmovaps xmm8, [rsp+0x70]
00007895b19d2425  vmovaps xmm9, [rsp+0x80]
00007895b19d242e  vmovaps xmm10, [rsp+0x90]
00007895b19d2437  vmovaps xmm11, [rsp+0xA0]
00007895b19d2440  vmovaps xmm12, [rsp+0xB0]
00007895b19d2449  vmovaps xmm13, [rsp+0xC0]
00007895b19d2452  vmovaps xmm14, [rsp+0xD0]
00007895b19d245b  vmovaps xmm15, [rsp+0xE0]
00007895b19d2464  add rsp, 0xF0
00007895b19d246b  pop r11
00007895b19d246d  pop r10
00007895b19d246f  pop r9
00007895b19d2471  pop r8
00007895b19d2473  pop rsi
00007895b19d2474  pop rdi
00007895b19d2475  pop rdx
00007895b19d2476  pop rcx
00007895b19d2477  pop rax
00007895b19d2478  add rsp, 0x08
00007895b19d247c  jmp 0x00007895B19CFE04
00007895b19d2481  sub rsp, 0x08
00007895b19d2485  push rax
00007895b19d2486  push rcx
00007895b19d2487  push rdx
00007895b19d2488  push rdi
00007895b19d2489  push rsi
00007895b19d248a  push r8
00007895b19d248c  push r9
00007895b19d248e  push r10
00007895b19d2490  push r11
00007895b19d2492  sub rsp, 0xF0
00007895b19d2499  vmovaps [rsp], xmm0
00007895b19d249e  vmovaps [rsp+0x10], xmm1
00007895b19d24a4  vmovaps [rsp+0x20], xmm2
00007895b19d24aa  vmovaps [rsp+0x30], xmm3
00007895b19d24b0  vmovaps [rsp+0x40], xmm4
00007895b19d24b6  vmovaps [rsp+0x50], xmm5
00007895b19d24bc  vmovaps [rsp+0x60], xmm6
00007895b19d24c2  vmovaps [rsp+0x70], xmm7
00007895b19d24c8  vmovaps [rsp+0x80], xmm9
00007895b19d24d1  vmovaps [rsp+0x90], xmm10
00007895b19d24da  vmovaps [rsp+0xA0], xmm11
00007895b19d24e3  vmovaps [rsp+0xB0], xmm12
00007895b19d24ec  vmovaps [rsp+0xC0], xmm13
00007895b19d24f5  vmovaps [rsp+0xD0], xmm14
00007895b19d24fe  vmovaps [rsp+0xE0], xmm15
00007895b19d2507  sub rsp, 0x40
00007895b19d250b  lea rdi, [rsp]
00007895b19d250f  lea rsi, [rsp+0x10]
00007895b19d2514  lea rdx, [rsp+0x20]
00007895b19d2519  lea rcx, [rsp+0x30]
00007895b19d251e  mov r8d, 0x00
00007895b19d2524  lea r9, [r15+0x3A8]
00007895b19d252b  movaps [rdi], xmm8
00007895b19d252f  movaps [rsi], xmm9
00007895b19d2533  movaps [rdx], xmm1
00007895b19d2536  movaps [rcx], xmm13
00007895b19d253a  mov rax, 0x59D4522A9A50
00007895b19d2544  call rax
00007895b19d2546  movaps xmm8, [rsp]
00007895b19d254b  add rsp, 0x40
00007895b19d254f  vmovaps xmm0, [rsp]
00007895b19d2554  vmovaps xmm1, [rsp+0x10]
00007895b19d255a  vmovaps xmm2, [rsp+0x20]
00007895b19d2560  vmovaps xmm3, [rsp+0x30]
00007895b19d2566  vmovaps xmm4, [rsp+0x40]
00007895b19d256c  vmovaps xmm5, [rsp+0x50]
00007895b19d2572  vmovaps xmm6, [rsp+0x60]
00007895b19d2578  vmovaps xmm7, [rsp+0x70]
00007895b19d257e  vmovaps xmm9, [rsp+0x80]
00007895b19d2587  vmovaps xmm10, [rsp+0x90]
00007895b19d2590  vmovaps xmm11, [rsp+0xA0]
00007895b19d2599  vmovaps xmm12, [rsp+0xB0]
00007895b19d25a2  vmovaps xmm13, [rsp+0xC0]
00007895b19d25ab  vmovaps xmm14, [rsp+0xD0]
00007895b19d25b4  vmovaps xmm15, [rsp+0xE0]
00007895b19d25bd  add rsp, 0xF0
00007895b19d25c4  pop r11
00007895b19d25c6  pop r10
00007895b19d25c8  pop r9
00007895b19d25ca  pop r8
00007895b19d25cc  pop rsi
00007895b19d25cd  pop rdi
00007895b19d25ce  pop rdx
00007895b19d25cf  pop rcx
00007895b19d25d0  pop rax
00007895b19d25d1  add rsp, 0x08
00007895b19d25d5  jmp 0x00007895B19CFE2A
00007895b19d25da  sub rsp, 0x08
00007895b19d25de  push rax
00007895b19d25df  push rcx
00007895b19d25e0  push rdx
00007895b19d25e1  push rdi
00007895b19d25e2  push rsi
00007895b19d25e3  push r8
00007895b19d25e5  push r9
00007895b19d25e7  push r10
00007895b19d25e9  push r11
00007895b19d25eb  sub rsp, 0xF0
00007895b19d25f2  vmovaps [rsp], xmm0
00007895b19d25f7  vmovaps [rsp+0x10], xmm1
00007895b19d25fd  vmovaps [rsp+0x20], xmm2
00007895b19d2603  vmovaps [rsp+0x30], xmm3
00007895b19d2609  vmovaps [rsp+0x40], xmm4
00007895b19d260f  vmovaps [rsp+0x50], xmm5
00007895b19d2615  vmovaps [rsp+0x60], xmm6
00007895b19d261b  vmovaps [rsp+0x70], xmm7
00007895b19d2621  vmovaps [rsp+0x80], xmm8
00007895b19d262a  vmovaps [rsp+0x90], xmm9
00007895b19d2633  vmovaps [rsp+0xA0], xmm10
00007895b19d263c  vmovaps [rsp+0xB0], xmm11
00007895b19d2645  vmovaps [rsp+0xC0], xmm12
00007895b19d264e  vmovaps [rsp+0xD0], xmm14
00007895b19d2657  vmovaps [rsp+0xE0], xmm15
00007895b19d2660  sub rsp, 0x40
00007895b19d2664  lea rdi, [rsp]
00007895b19d2668  lea rsi, [rsp+0x10]
00007895b19d266d  lea rdx, [rsp+0x20]
00007895b19d2672  lea rcx, [rsp+0x30]
00007895b19d2677  mov r8d, 0x00
00007895b19d267d  lea r9, [r15+0x3A8]
00007895b19d2684  movaps [rdi], xmm13
00007895b19d2688  movaps [rsi], xmm11
00007895b19d268c  movaps [rdx], xmm12
00007895b19d2690  movaps [rcx], xmm1
00007895b19d2693  mov rax, 0x59D4522A9A50
00007895b19d269d  call rax
00007895b19d269f  movaps xmm13, [rsp]
00007895b19d26a4  add rsp, 0x40
00007895b19d26a8  vmovaps xmm0, [rsp]
00007895b19d26ad  vmovaps xmm1, [rsp+0x10]
00007895b19d26b3  vmovaps xmm2, [rsp+0x20]
00007895b19d26b9  vmovaps xmm3, [rsp+0x30]
00007895b19d26bf  vmovaps xmm4, [rsp+0x40]
00007895b19d26c5  vmovaps xmm5, [rsp+0x50]
00007895b19d26cb  vmovaps xmm6, [rsp+0x60]
00007895b19d26d1  vmovaps xmm7, [rsp+0x70]
00007895b19d26d7  vmovaps xmm8, [rsp+0x80]
00007895b19d26e0  vmovaps xmm9, [rsp+0x90]
00007895b19d26e9  vmovaps xmm10, [rsp+0xA0]
00007895b19d26f2  vmovaps xmm11, [rsp+0xB0]
00007895b19d26fb  vmovaps xmm12, [rsp+0xC0]
00007895b19d2704  vmovaps xmm14, [rsp+0xD0]
00007895b19d270d  vmovaps xmm15, [rsp+0xE0]
00007895b19d2716  add rsp, 0xF0
00007895b19d271d  pop r11
00007895b19d271f  pop r10
00007895b19d2721  pop r9
00007895b19d2723  pop r8
00007895b19d2725  pop rsi
00007895b19d2726  pop rdi
00007895b19d2727  pop rdx
00007895b19d2728  pop rcx
00007895b19d2729  pop rax
00007895b19d272a  add rsp, 0x08
00007895b19d272e  jmp 0x00007895B19CFE50
00007895b19d2733  sub rsp, 0x08
00007895b19d2737  push rax
00007895b19d2738  push rcx
00007895b19d2739  push rdx
00007895b19d273a  push rdi
00007895b19d273b  push rsi
00007895b19d273c  push r8
00007895b19d273e  push r9
00007895b19d2740  push r10
00007895b19d2742  push r11
00007895b19d2744  sub rsp, 0xF0
00007895b19d274b  vmovaps [rsp], xmm0
00007895b19d2750  vmovaps [rsp+0x10], xmm1
00007895b19d2756  vmovaps [rsp+0x20], xmm2
00007895b19d275c  vmovaps [rsp+0x30], xmm3
00007895b19d2762  vmovaps [rsp+0x40], xmm4
00007895b19d2768  vmovaps [rsp+0x50], xmm5
00007895b19d276e  vmovaps [rsp+0x60], xmm6
00007895b19d2774  vmovaps [rsp+0x70], xmm7
00007895b19d277a  vmovaps [rsp+0x80], xmm8
00007895b19d2783  vmovaps [rsp+0x90], xmm9
00007895b19d278c  vmovaps [rsp+0xA0], xmm10
00007895b19d2795  vmovaps [rsp+0xB0], xmm11
00007895b19d279e  vmovaps [rsp+0xC0], xmm13
00007895b19d27a7  vmovaps [rsp+0xD0], xmm14
00007895b19d27b0  vmovaps [rsp+0xE0], xmm15
00007895b19d27b9  sub rsp, 0x40
00007895b19d27bd  lea rdi, [rsp]
00007895b19d27c1  lea rsi, [rsp+0x10]
00007895b19d27c6  lea rdx, [rsp+0x20]
00007895b19d27cb  lea rcx, [rsp+0x30]
00007895b19d27d0  mov r8d, 0x00
00007895b19d27d6  lea r9, [r15+0x3A8]
00007895b19d27dd  movaps [rdi], xmm12
00007895b19d27e1  movaps [rsi], xmm10
00007895b19d27e5  movaps [rdx], xmm14
00007895b19d27e9  movaps [rcx], xmm1
00007895b19d27ec  mov rax, 0x59D4522A9A50
00007895b19d27f6  call rax
00007895b19d27f8  movaps xmm12, [rsp]
00007895b19d27fd  add rsp, 0x40
00007895b19d2801  vmovaps xmm0, [rsp]
00007895b19d2806  vmovaps xmm1, [rsp+0x10]
00007895b19d280c  vmovaps xmm2, [rsp+0x20]
00007895b19d2812  vmovaps xmm3, [rsp+0x30]
00007895b19d2818  vmovaps xmm4, [rsp+0x40]
00007895b19d281e  vmovaps xmm5, [rsp+0x50]
00007895b19d2824  vmovaps xmm6, [rsp+0x60]
00007895b19d282a  vmovaps xmm7, [rsp+0x70]
00007895b19d2830  vmovaps xmm8, [rsp+0x80]
00007895b19d2839  vmovaps xmm9, [rsp+0x90]
00007895b19d2842  vmovaps xmm10, [rsp+0xA0]
00007895b19d284b  vmovaps xmm11, [rsp+0xB0]
00007895b19d2854  vmovaps xmm13, [rsp+0xC0]
00007895b19d285d  vmovaps xmm14, [rsp+0xD0]
00007895b19d2866  vmovaps xmm15, [rsp+0xE0]
00007895b19d286f  add rsp, 0xF0
00007895b19d2876  pop r11
00007895b19d2878  pop r10
00007895b19d287a  pop r9
00007895b19d287c  pop r8
00007895b19d287e  pop rsi
00007895b19d287f  pop rdi
00007895b19d2880  pop rdx
00007895b19d2881  pop rcx
00007895b19d2882  pop rax
00007895b19d2883  add rsp, 0x08
00007895b19d2887  jmp 0x00007895B19CFE76
00007895b19d288c  call 0x00007895B17FF430
00007895b19d2891  jmp 0x00007895B19CFE83
00007895b19d2896  call 0x00007895B180D4E0
00007895b19d289b  jmp 0x00007895B19CFE90
00007895b19d28a0  sub rsp, 0x08
00007895b19d28a4  push rax
00007895b19d28a5  push rcx
00007895b19d28a6  push rdx
00007895b19d28a7  push rdi
00007895b19d28a8  push rsi
00007895b19d28a9  push r8
00007895b19d28ab  push r9
00007895b19d28ad  push r10
00007895b19d28af  push r11
00007895b19d28b1  sub rsp, 0xF0
00007895b19d28b8  vmovaps [rsp], xmm0
00007895b19d28bd  vmovaps [rsp+0x10], xmm1
00007895b19d28c3  vmovaps [rsp+0x20], xmm2
00007895b19d28c9  vmovaps [rsp+0x30], xmm3
00007895b19d28cf  vmovaps [rsp+0x40], xmm4
00007895b19d28d5  vmovaps [rsp+0x50], xmm5
00007895b19d28db  vmovaps [rsp+0x60], xmm6
00007895b19d28e1  vmovaps [rsp+0x70], xmm7
00007895b19d28e7  vmovaps [rsp+0x80], xmm8
00007895b19d28f0  vmovaps [rsp+0x90], xmm9
00007895b19d28f9  vmovaps [rsp+0xA0], xmm11
00007895b19d2902  vmovaps [rsp+0xB0], xmm12
00007895b19d290b  vmovaps [rsp+0xC0], xmm13
00007895b19d2914  vmovaps [rsp+0xD0], xmm14
00007895b19d291d  vmovaps [rsp+0xE0], xmm15
00007895b19d2926  sub rsp, 0x40
00007895b19d292a  lea rdi, [rsp]
00007895b19d292e  lea rsi, [rsp+0x10]
00007895b19d2933  lea rdx, [rsp+0x20]
00007895b19d2938  lea rcx, [rsp+0x30]
00007895b19d293d  mov r8d, 0x00
00007895b19d2943  lea r9, [r15+0x3A8]
00007895b19d294a  movaps [rdi], xmm10
00007895b19d294e  movaps [rsi], xmm6
00007895b19d2951  movaps [rdx], xmm15
00007895b19d2955  movaps [rcx], xmm11
00007895b19d2959  mov rax, 0x59D4522A9A50
00007895b19d2963  call rax
00007895b19d2965  movaps xmm10, [rsp]
00007895b19d296a  add rsp, 0x40
00007895b19d296e  vmovaps xmm0, [rsp]
00007895b19d2973  vmovaps xmm1, [rsp+0x10]
00007895b19d2979  vmovaps xmm2, [rsp+0x20]
00007895b19d297f  vmovaps xmm3, [rsp+0x30]
00007895b19d2985  vmovaps xmm4, [rsp+0x40]
00007895b19d298b  vmovaps xmm5, [rsp+0x50]
00007895b19d2991  vmovaps xmm6, [rsp+0x60]
00007895b19d2997  vmovaps xmm7, [rsp+0x70]
00007895b19d299d  vmovaps xmm8, [rsp+0x80]
00007895b19d29a6  vmovaps xmm9, [rsp+0x90]
00007895b19d29af  vmovaps xmm11, [rsp+0xA0]
00007895b19d29b8  vmovaps xmm12, [rsp+0xB0]
00007895b19d29c1  vmovaps xmm13, [rsp+0xC0]
00007895b19d29ca  vmovaps xmm14, [rsp+0xD0]
00007895b19d29d3  vmovaps xmm15, [rsp+0xE0]
00007895b19d29dc  add rsp, 0xF0
00007895b19d29e3  pop r11
00007895b19d29e5  pop r10
00007895b19d29e7  pop r9
00007895b19d29e9  pop r8
00007895b19d29eb  pop rsi
00007895b19d29ec  pop rdi
00007895b19d29ed  pop rdx
00007895b19d29ee  pop rcx
00007895b19d29ef  pop rax
00007895b19d29f0  add rsp, 0x08
00007895b19d29f4  jmp 0x00007895B19CFEC9
00007895b19d29f9  call 0x00007895B180E760
00007895b19d29fe  jmp 0x00007895B19CFEDB
00007895b19d2a03  sub rsp, 0x08
00007895b19d2a07  push rax
00007895b19d2a08  push rcx
00007895b19d2a09  push rdx
00007895b19d2a0a  push rdi
00007895b19d2a0b  push rsi
00007895b19d2a0c  push r8
00007895b19d2a0e  push r9
00007895b19d2a10  push r10
00007895b19d2a12  push r11
00007895b19d2a14  sub rsp, 0xF0
00007895b19d2a1b  vmovaps [rsp], xmm0
00007895b19d2a20  vmovaps [rsp+0x10], xmm1
00007895b19d2a26  vmovaps [rsp+0x20], xmm2
00007895b19d2a2c  vmovaps [rsp+0x30], xmm3
00007895b19d2a32  vmovaps [rsp+0x40], xmm4
00007895b19d2a38  vmovaps [rsp+0x50], xmm5
00007895b19d2a3e  vmovaps [rsp+0x60], xmm6
00007895b19d2a44  vmovaps [rsp+0x70], xmm7
00007895b19d2a4a  vmovaps [rsp+0x80], xmm8
00007895b19d2a53  vmovaps [rsp+0x90], xmm10
00007895b19d2a5c  vmovaps [rsp+0xA0], xmm11
00007895b19d2a65  vmovaps [rsp+0xB0], xmm12
00007895b19d2a6e  vmovaps [rsp+0xC0], xmm13
00007895b19d2a77  vmovaps [rsp+0xD0], xmm14
00007895b19d2a80  vmovaps [rsp+0xE0], xmm15
00007895b19d2a89  sub rsp, 0x40
00007895b19d2a8d  lea rdi, [rsp]
00007895b19d2a91  lea rsi, [rsp+0x10]
00007895b19d2a96  lea rdx, [rsp+0x20]
00007895b19d2a9b  lea rcx, [rsp+0x30]
00007895b19d2aa0  mov r8d, 0x00
00007895b19d2aa6  lea r9, [r15+0x3A8]
00007895b19d2aad  movaps [rdi], xmm9
00007895b19d2ab1  movaps [rsi], xmm8
00007895b19d2ab5  movaps [rdx], xmm14
00007895b19d2ab9  movaps [rcx], xmm11
00007895b19d2abd  mov rax, 0x59D4522A9A50
00007895b19d2ac7  call rax
00007895b19d2ac9  movaps xmm9, [rsp]
00007895b19d2ace  add rsp, 0x40
00007895b19d2ad2  vmovaps xmm0, [rsp]
00007895b19d2ad7  vmovaps xmm1, [rsp+0x10]
00007895b19d2add  vmovaps xmm2, [rsp+0x20]
00007895b19d2ae3  vmovaps xmm3, [rsp+0x30]
00007895b19d2ae9  vmovaps xmm4, [rsp+0x40]
00007895b19d2aef  vmovaps xmm5, [rsp+0x50]
00007895b19d2af5  vmovaps xmm6, [rsp+0x60]
00007895b19d2afb  vmovaps xmm7, [rsp+0x70]
00007895b19d2b01  vmovaps xmm8, [rsp+0x80]
00007895b19d2b0a  vmovaps xmm10, [rsp+0x90]
00007895b19d2b13  vmovaps xmm11, [rsp+0xA0]
00007895b19d2b1c  vmovaps xmm12, [rsp+0xB0]
00007895b19d2b25  vmovaps xmm13, [rsp+0xC0]
00007895b19d2b2e  vmovaps xmm14, [rsp+0xD0]
00007895b19d2b37  vmovaps xmm15, [rsp+0xE0]
00007895b19d2b40  add rsp, 0xF0
00007895b19d2b47  pop r11
00007895b19d2b49  pop r10
00007895b19d2b4b  pop r9
00007895b19d2b4d  pop r8
00007895b19d2b4f  pop rsi
00007895b19d2b50  pop rdi
00007895b19d2b51  pop rdx
00007895b19d2b52  pop rcx
00007895b19d2b53  pop rax
00007895b19d2b54  add rsp, 0x08
00007895b19d2b58  jmp 0x00007895B19CFF0C
00007895b19d2b5d  sub rsp, 0x08
00007895b19d2b61  push rax
00007895b19d2b62  push rcx
00007895b19d2b63  push rdx
00007895b19d2b64  push rdi
00007895b19d2b65  push rsi
00007895b19d2b66  push r8
00007895b19d2b68  push r9
00007895b19d2b6a  push r10
00007895b19d2b6c  push r11
00007895b19d2b6e  sub rsp, 0xF0
00007895b19d2b75  vmovaps [rsp], xmm0
00007895b19d2b7a  vmovaps [rsp+0x10], xmm1
00007895b19d2b80  vmovaps [rsp+0x20], xmm2
00007895b19d2b86  vmovaps [rsp+0x30], xmm3
00007895b19d2b8c  vmovaps [rsp+0x40], xmm4
00007895b19d2b92  vmovaps [rsp+0x50], xmm5
00007895b19d2b98  vmovaps [rsp+0x60], xmm6
00007895b19d2b9e  vmovaps [rsp+0x70], xmm7
00007895b19d2ba4  vmovaps [rsp+0x80], xmm8
00007895b19d2bad  vmovaps [rsp+0x90], xmm9
00007895b19d2bb6  vmovaps [rsp+0xA0], xmm10
00007895b19d2bbf  vmovaps [rsp+0xB0], xmm12
00007895b19d2bc8  vmovaps [rsp+0xC0], xmm13
00007895b19d2bd1  vmovaps [rsp+0xD0], xmm14
00007895b19d2bda  vmovaps [rsp+0xE0], xmm15
00007895b19d2be3  sub rsp, 0x40
00007895b19d2be7  lea rdi, [rsp]
00007895b19d2beb  lea rsi, [rsp+0x10]
00007895b19d2bf0  lea rdx, [rsp+0x20]
00007895b19d2bf5  lea rcx, [rsp+0x30]
00007895b19d2bfa  mov r8d, 0x00
00007895b19d2c00  lea r9, [r15+0x3A8]
00007895b19d2c07  movaps [rdi], xmm11
00007895b19d2c0b  movaps [rsi], xmm13
00007895b19d2c0f  movaps [rdx], xmm1
00007895b19d2c12  movaps [rcx], xmm14
00007895b19d2c16  mov rax, 0x59D4522A9A50
00007895b19d2c20  call rax
00007895b19d2c22  movaps xmm11, [rsp]
00007895b19d2c27  add rsp, 0x40
00007895b19d2c2b  vmovaps xmm0, [rsp]
00007895b19d2c30  vmovaps xmm1, [rsp+0x10]
00007895b19d2c36  vmovaps xmm2, [rsp+0x20]
00007895b19d2c3c  vmovaps xmm3, [rsp+0x30]
00007895b19d2c42  vmovaps xmm4, [rsp+0x40]
00007895b19d2c48  vmovaps xmm5, [rsp+0x50]
00007895b19d2c4e  vmovaps xmm6, [rsp+0x60]
00007895b19d2c54  vmovaps xmm7, [rsp+0x70]
00007895b19d2c5a  vmovaps xmm8, [rsp+0x80]
00007895b19d2c63  vmovaps xmm9, [rsp+0x90]
00007895b19d2c6c  vmovaps xmm10, [rsp+0xA0]
00007895b19d2c75  vmovaps xmm12, [rsp+0xB0]
00007895b19d2c7e  vmovaps xmm13, [rsp+0xC0]
00007895b19d2c87  vmovaps xmm14, [rsp+0xD0]
00007895b19d2c90  vmovaps xmm15, [rsp+0xE0]
00007895b19d2c99  add rsp, 0xF0
00007895b19d2ca0  pop r11
00007895b19d2ca2  pop r10
00007895b19d2ca4  pop r9
00007895b19d2ca6  pop r8
00007895b19d2ca8  pop rsi
00007895b19d2ca9  pop rdi
00007895b19d2caa  pop rdx
00007895b19d2cab  pop rcx
00007895b19d2cac  pop rax
00007895b19d2cad  add rsp, 0x08
00007895b19d2cb1  jmp 0x00007895B19CFF3D
00007895b19d2cb6  sub rsp, 0x08
00007895b19d2cba  push rax
00007895b19d2cbb  push rcx
00007895b19d2cbc  push rdx
00007895b19d2cbd  push rdi
00007895b19d2cbe  push rsi
00007895b19d2cbf  push r8
00007895b19d2cc1  push r9
00007895b19d2cc3  push r10
00007895b19d2cc5  push r11
00007895b19d2cc7  sub rsp, 0xF0
00007895b19d2cce  vmovaps [rsp], xmm0
00007895b19d2cd3  vmovaps [rsp+0x10], xmm1
00007895b19d2cd9  vmovaps [rsp+0x20], xmm2
00007895b19d2cdf  vmovaps [rsp+0x30], xmm3
00007895b19d2ce5  vmovaps [rsp+0x40], xmm4
00007895b19d2ceb  vmovaps [rsp+0x50], xmm5
00007895b19d2cf1  vmovaps [rsp+0x60], xmm6
00007895b19d2cf7  vmovaps [rsp+0x70], xmm7
00007895b19d2cfd  vmovaps [rsp+0x80], xmm8
00007895b19d2d06  vmovaps [rsp+0x90], xmm9
00007895b19d2d0f  vmovaps [rsp+0xA0], xmm10
00007895b19d2d18  vmovaps [rsp+0xB0], xmm11
00007895b19d2d21  vmovaps [rsp+0xC0], xmm12
00007895b19d2d2a  vmovaps [rsp+0xD0], xmm13
00007895b19d2d33  vmovaps [rsp+0xE0], xmm15
00007895b19d2d3c  sub rsp, 0x40
00007895b19d2d40  lea rdi, [rsp]
00007895b19d2d44  lea rsi, [rsp+0x10]
00007895b19d2d49  lea rdx, [rsp+0x20]
00007895b19d2d4e  lea rcx, [rsp+0x30]
00007895b19d2d53  mov r8d, 0x00
00007895b19d2d59  lea r9, [r15+0x3A8]
00007895b19d2d60  movaps [rdi], xmm14
00007895b19d2d64  movaps [rsi], xmm12
00007895b19d2d68  movaps [rdx], xmm15
00007895b19d2d6c  movaps [rcx], xmm1
00007895b19d2d6f  mov rax, 0x59D4522A9A50
00007895b19d2d79  call rax
00007895b19d2d7b  movaps xmm14, [rsp]
00007895b19d2d80  add rsp, 0x40
00007895b19d2d84  vmovaps xmm0, [rsp]
00007895b19d2d89  vmovaps xmm1, [rsp+0x10]
00007895b19d2d8f  vmovaps xmm2, [rsp+0x20]
00007895b19d2d95  vmovaps xmm3, [rsp+0x30]
00007895b19d2d9b  vmovaps xmm4, [rsp+0x40]
00007895b19d2da1  vmovaps xmm5, [rsp+0x50]
00007895b19d2da7  vmovaps xmm6, [rsp+0x60]
00007895b19d2dad  vmovaps xmm7, [rsp+0x70]
00007895b19d2db3  vmovaps xmm8, [rsp+0x80]
00007895b19d2dbc  vmovaps xmm9, [rsp+0x90]
00007895b19d2dc5  vmovaps xmm10, [rsp+0xA0]
00007895b19d2dce  vmovaps xmm11, [rsp+0xB0]
00007895b19d2dd7  vmovaps xmm12, [rsp+0xC0]
00007895b19d2de0  vmovaps xmm13, [rsp+0xD0]
00007895b19d2de9  vmovaps xmm15, [rsp+0xE0]
00007895b19d2df2  add rsp, 0xF0
00007895b19d2df9  pop r11
00007895b19d2dfb  pop r10
00007895b19d2dfd  pop r9
00007895b19d2dff  pop r8
00007895b19d2e01  pop rsi
00007895b19d2e02  pop rdi
00007895b19d2e03  pop rdx
00007895b19d2e04  pop rcx
00007895b19d2e05  pop rax
00007895b19d2e06  add rsp, 0x08
00007895b19d2e0a  jmp 0x00007895B19CFF6E
00007895b19d2e0f  call 0x00007895B18079B0
00007895b19d2e14  jmp 0x00007895B19CFF81
00007895b19d2e19  call 0x00007895B1809E90
00007895b19d2e1e  jmp 0x00007895B19CFF8C
00007895b19d2e23  call 0x00007895B1808C20
00007895b19d2e28  jmp 0x00007895B19CFF97
00007895b19d2e2d  call 0x00007895B180D600
00007895b19d2e32  jmp 0x00007895B19CFFA2
00007895b19d2e37  int3
00007895b19d2e38  nop [rax+rax*1], eax
00007895b19d2e40  mov rax, [r15+0x40]
00007895b19d2e44  mov r14, [r15+0x58]
00007895b19d2e48  lea r12, [rax+r14*1]
00007895b19d2e4c  vxorps xmm1, xmm1, xmm1
00007895b19d2e50  vpbroadcastq xmm1, xmm1
00007895b19d2e55  vxorps xmm15, xmm15, xmm15
00007895b19d2e5a  vpbroadcastq xmm15, xmm15
00007895b19d2e5f  lea rax, [r12+0x30]
00007895b19d2e64  mov r11, [r13+rax*1]
00007895b19d2e69  lea rax, [r12+0x38]
00007895b19d2e6e  mov r10, [r13+rax*1]
00007895b19d2e73  movq xmm14, r11
00007895b19d2e78  movq xmm13, r10
00007895b19d2e7d  movq xmm14, xmm14
00007895b19d2e82  movq xmm13, xmm13
00007895b19d2e87  vmovaps [rsp+0x10], xmm13
00007895b19d2e8d  movq xmm13, xmm13
00007895b19d2e92  movaps [r15+0x270], xmm13
00007895b19d2e9a  movaps xmm13, [r15+0x160]
00007895b19d2ea2  vmovaps [rsp+0x20], xmm13
00007895b19d2ea8  vmovaps xmm12, [rsp+0x20]
00007895b19d2eae  por xmm13, xmm12
00007895b19d2eb3  lea rax, [r12+0x20]
00007895b19d2eb8  mov r11, [r13+rax*1]
00007895b19d2ebd  lea rax, [r12+0x28]
00007895b19d2ec2  mov r10, [r13+rax*1]
00007895b19d2ec7  movq xmm12, r11
00007895b19d2ecc  movq xmm11, r10
00007895b19d2ed1  movq xmm12, xmm12
00007895b19d2ed6  movq xmm11, xmm11
00007895b19d2edb  movaps xmm10, [r15+0x2F0]
00007895b19d2ee3  vmovaps [rsp+0x20], xmm10
00007895b19d2ee9  vmovaps xmm9, [rsp+0x20]
00007895b19d2eef  por xmm10, xmm9
00007895b19d2ef4  movaps xmm9, [r15+0x2D0]
00007895b19d2efc  vmovaps [rsp+0x20], xmm9
00007895b19d2f02  vmovaps xmm8, [rsp+0x20]
00007895b19d2f08  por xmm9, xmm8
00007895b19d2f0d  movaps xmm8, [r15+0x300]
00007895b19d2f15  vmovaps [rsp+0x20], xmm8
00007895b19d2f1b  vmovaps xmm7, [rsp+0x20]
00007895b19d2f21  por xmm8, xmm7
00007895b19d2f26  movaps xmm7, [r15+0x2B0]
00007895b19d2f2e  vmovaps [rsp+0x20], xmm7
00007895b19d2f34  vmovaps xmm6, [rsp+0x20]
00007895b19d2f3a  por xmm7, xmm6
00007895b19d2f3e  movaps xmm6, [r15+0x180]
00007895b19d2f46  vmovaps [rsp+0x20], xmm6
00007895b19d2f4c  vmovaps xmm5, [rsp+0x20]
00007895b19d2f52  por xmm6, xmm5
00007895b19d2f56  lea rax, [r12+0x10]
00007895b19d2f5b  mov r11, [r13+rax*1]
00007895b19d2f60  lea rax, [r12+0x18]
00007895b19d2f65  mov r10, [r13+rax*1]
00007895b19d2f6a  movq xmm5, r11
00007895b19d2f6f  movq xmm4, r10
00007895b19d2f74  movq xmm5, xmm5
00007895b19d2f78  movq xmm4, xmm4
00007895b19d2f7c  movaps xmm3, [r15+0x200]
00007895b19d2f84  vmovaps [rsp+0x20], xmm3
00007895b19d2f8a  vmovaps xmm2, [rsp+0x20]
00007895b19d2f90  por xmm3, xmm2
00007895b19d2f94  movaps xmm2, [r15+0x1F0]
00007895b19d2f9c  vmovaps [rsp+0x20], xmm2
00007895b19d2fa2  vmovaps [rsp+0x30], xmm1
00007895b19d2fa8  vmovaps xmm1, [rsp+0x20]
00007895b19d2fae  por xmm2, xmm1
00007895b19d2fb2  movaps xmm1, [r15+0x2E0]
00007895b19d2fba  vmovaps [rsp+0x20], xmm1
00007895b19d2fc0  vmovaps [rsp+0x40], xmm15
00007895b19d2fc6  vmovaps xmm15, [rsp+0x20]
00007895b19d2fcc  por xmm1, xmm15
00007895b19d2fd1  movaps xmm15, [r15+0x2A0]
00007895b19d2fd9  vmovaps [rsp+0x20], xmm15
00007895b19d2fdf  vmovaps [rsp+0x50], xmm1
00007895b19d2fe5  vmovaps xmm1, [rsp+0x20]
00007895b19d2feb  por xmm15, xmm1
00007895b19d2ff0  movaps xmm1, [r15+0x280]
00007895b19d2ff8  vmovaps [rsp+0x20], xmm1
00007895b19d2ffe  vmovaps [rsp+0x60], xmm15
00007895b19d3004  vmovaps xmm15, [rsp+0x20]
00007895b19d300a  por xmm1, xmm15
00007895b19d300f  movaps xmm15, [r15+0x1C0]
00007895b19d3017  vmovaps [rsp+0x20], xmm15
00007895b19d301d  vmovaps [rsp+0x70], xmm1
00007895b19d3023  vmovaps xmm1, [rsp+0x20]
00007895b19d3029  por xmm15, xmm1
00007895b19d302e  movaps xmm1, [r15+0x210]
00007895b19d3036  vmovaps [rsp+0x20], xmm1
00007895b19d303c  vmovaps [rsp+0x80], xmm15
00007895b19d3045  vmovaps xmm15, [rsp+0x20]
00007895b19d304b  por xmm1, xmm15
00007895b19d3050  mov rax, [r13+r12*1]
00007895b19d3055  vmovq xmm15, rax
00007895b19d305a  vpbroadcastq xmm15, xmm15
00007895b19d305f  vmovaps [rsp+0x20], xmm1
00007895b19d3065  vxorps xmm1, xmm1, xmm1
00007895b19d3069  vpbroadcastq xmm1, xmm1
00007895b19d306e  mov rax, [r15+0xF8]
00007895b19d3075  vmovaps [rsp+0x90], xmm1
00007895b19d307e  movups xmm1, [r13+rax*1]
00007895b19d3084  vmovaps [rsp+0xA0], xmm1
00007895b19d308d  vxorps xmm1, xmm1, xmm1
00007895b19d3091  vpbroadcastq xmm1, xmm1
00007895b19d3096  lea r11, [r12+0x08]
00007895b19d309b  mov r12, [r13+r11*1]
00007895b19d30a0  vmovaps [rsp+0xB0], xmm1
00007895b19d30a9  movq xmm1, r12
00007895b19d30ae  movaps [r15+0x240], xmm1
00007895b19d30b6  mov r12, [r15+0x50]
00007895b19d30ba  lea r11, [r12+r14*1]
00007895b19d30be  mov [r15+0x60], r11
00007895b19d30c2  lea r12, [r14+0x40]
00007895b19d30c6  mov [r15+0x58], r12
00007895b19d30ca  vmovaps xmm1, [rsp+0x30]
00007895b19d30d0  vmovaps [rsp+0x30], xmm15
00007895b19d30d6  vmovaps xmm15, [rsp+0xA0]
00007895b19d30df  vmovaps [rsp+0xA0], xmm14
00007895b19d30e8  vmovaps xmm14, [rsp+0x30]
00007895b19d30ee  vmovaps [rsp+0x30], xmm13
00007895b19d30f4  vmovaps [rsp+0xC0], xmm12
00007895b19d30fd  movaps xmm13, xmm1
00007895b19d3101  vfmadd231pd xmm13, xmm15, xmm14
00007895b19d3106  vcmppd xmm12, xmm13, xmm13, 0x03
00007895b19d310c  vptest xmm12, xmm12
00007895b19d3111  jnz 0x00007895B19D3BEA
00007895b19d3117  movaps xmm1, [r15+0x250]
00007895b19d311f  vmovaps xmm15, [rsp+0x40]
00007895b19d3125  vmovaps [rsp+0x40], xmm13
00007895b19d312b  movaps xmm12, xmm15
00007895b19d312f  vfmadd231pd xmm12, xmm1, xmm14
00007895b19d3134  vcmppd xmm13, xmm12, xmm12, 0x03
00007895b19d313a  vptest xmm13, xmm13
00007895b19d313f  jnz 0x00007895B19D3D43
00007895b19d3145  movaps xmm15, [r15+0x1E0]
00007895b19d314d  vmovaps [rsp+0xD0], xmm15
00007895b19d3156  vmovaps xmm13, [rsp+0xD0]
00007895b19d315f  por xmm15, xmm13
00007895b19d3164  movaps xmm13, [r15+0x1D0]
00007895b19d316c  vmovaps [rsp+0xD0], xmm13
00007895b19d3175  vmovaps [rsp+0xE0], xmm1
00007895b19d317e  vmovaps xmm1, [rsp+0xD0]
00007895b19d3187  por xmm13, xmm1
00007895b19d318c  movaps xmm1, [r15+0x2C0]
00007895b19d3194  vmovaps [rsp+0xD0], xmm1
00007895b19d319d  vmovaps [rsp+0xF0], xmm15
00007895b19d31a6  vmovaps xmm15, [rsp+0xD0]
00007895b19d31af  por xmm1, xmm15
00007895b19d31b4  movaps xmm15, [r15+0x290]
00007895b19d31bc  vmovaps [rsp+0xD0], xmm15
00007895b19d31c5  vmovaps [rsp+0x100], xmm1
00007895b19d31ce  vmovaps xmm1, [rsp+0xD0]
00007895b19d31d7  por xmm15, xmm1
00007895b19d31dc  movaps xmm1, [r15+0x260]
00007895b19d31e4  vmovaps [rsp+0xD0], xmm1
00007895b19d31ed  vmovaps [rsp+0x110], xmm15
00007895b19d31f6  vmovaps xmm15, [rsp+0xD0]
00007895b19d31ff  por xmm1, xmm15
00007895b19d3204  vmovaps xmm15, [rsp+0xE0]
00007895b19d320d  vmovaps [rsp+0xD0], xmm1
00007895b19d3216  vmovaps xmm1, [rsp+0xE0]
00007895b19d321f  por xmm15, xmm1
00007895b19d3224  lea r14, [rax+0xC0]
00007895b19d322b  movups xmm1, [r13+r14*1]
00007895b19d3231  mov [rsp+0xE0], rax
00007895b19d3239  xor eax, eax
00007895b19d323b  mov r14d, 0x200
00007895b19d3241  cmp r12, r14
00007895b19d3244  cmc
00007895b19d3245  lahf
00007895b19d3246  seto al
00007895b19d3249  mov [r15+0x108], eax
00007895b19d3250  vmovaps [rsp+0x120], xmm1
00007895b19d3259  vmovaps xmm1, [rsp+0x90]
00007895b19d3262  vmovaps [rsp+0x90], xmm15
00007895b19d326b  vmovaps xmm15, [rsp+0x120]
00007895b19d3274  vmovaps [rsp+0x120], xmm13
00007895b19d327d  vmovaps [rsp+0x130], xmm12
00007895b19d3286  movaps xmm13, xmm1
00007895b19d328a  vfmadd231pd xmm13, xmm15, xmm14
00007895b19d328f  vcmppd xmm12, xmm13, xmm13, 0x03
00007895b19d3295  vptest xmm12, xmm12
00007895b19d329a  jnz 0x00007895B19D3EA6
00007895b19d32a0  mov rax, [rsp+0xE0]
00007895b19d32a8  lea r14, [rax+0xB0]
00007895b19d32af  movups xmm1, [r13+r14*1]
00007895b19d32b5  vmovaps xmm15, [rsp+0xB0]
00007895b19d32be  vmovaps [rsp+0xB0], xmm13
00007895b19d32c7  movaps xmm12, xmm15
00007895b19d32cb  vfmadd231pd xmm12, xmm1, xmm14
00007895b19d32d0  vcmppd xmm13, xmm12, xmm12, 0x03
00007895b19d32d6  vptest xmm13, xmm13
00007895b19d32db  jnz 0x00007895B19D4009
00007895b19d32e1  vmovaps xmm1, [rsp+0x20]
00007895b19d32e7  vmovaps xmm15, [rsp+0x20]
00007895b19d32ed  por xmm1, xmm15
00007895b19d32f2  movaps [r15+0x210], xmm1
00007895b19d32fa  vmovaps xmm15, [rsp+0x80]
00007895b19d3303  vmovaps xmm14, [rsp+0x80]
00007895b19d330c  por xmm15, xmm14
00007895b19d3311  movaps [r15+0x1C0], xmm15
00007895b19d3319  vmovaps xmm14, [rsp+0x70]
00007895b19d331f  vmovaps xmm13, [rsp+0x70]
00007895b19d3325  por xmm14, xmm13
00007895b19d332a  movaps [r15+0x280], xmm14
00007895b19d3332  vmovaps xmm13, [rsp+0x60]
00007895b19d3338  vmovaps [rsp+0x20], xmm1
00007895b19d333e  vmovaps xmm1, [rsp+0x60]
00007895b19d3344  por xmm13, xmm1
00007895b19d3349  movaps [r15+0x2A0], xmm13
00007895b19d3351  vmovaps xmm1, [rsp+0x50]
00007895b19d3357  vmovaps [rsp+0x60], xmm15
00007895b19d335d  vmovaps xmm15, [rsp+0x50]
00007895b19d3363  por xmm1, xmm15
00007895b19d3368  movaps [r15+0x2E0], xmm1
00007895b19d3370  vmovaps [rsp+0x50], xmm2
00007895b19d3376  vmovaps xmm15, [rsp+0x50]
00007895b19d337c  por xmm2, xmm15
00007895b19d3381  movaps [r15+0x1F0], xmm2
00007895b19d3389  vmovaps xmm15, [rsp+0x90]
00007895b19d3392  vmovaps [rsp+0x50], xmm1
00007895b19d3398  vmovaps xmm1, [rsp+0x90]
00007895b19d33a1  por xmm15, xmm1
00007895b19d33a6  movaps [r15+0x250], xmm15
00007895b19d33ae  vmovaps xmm1, [rsp+0xD0]
00007895b19d33b7  vmovaps xmm15, [rsp+0xD0]
00007895b19d33c0  por xmm1, xmm15
00007895b19d33c5  movaps [r15+0x260], xmm1
00007895b19d33cd  vmovaps xmm15, [rsp+0x110]
00007895b19d33d6  vmovaps [rsp+0x70], xmm1
00007895b19d33dc  vmovaps xmm1, [rsp+0x110]
00007895b19d33e5  por xmm15, xmm1
00007895b19d33ea  movaps [r15+0x290], xmm15
00007895b19d33f2  vmovaps xmm1, [rsp+0x100]
00007895b19d33fb  vmovaps [rsp+0x80], xmm15
00007895b19d3404  vmovaps xmm15, [rsp+0x100]
00007895b19d340d  por xmm1, xmm15
00007895b19d3412  movaps [r15+0x2C0], xmm1
00007895b19d341a  movq xmm15, qword ptr [r15+0x240]
00007895b19d3423  vmovaps [rsp+0x90], xmm15
00007895b19d342c  vpermilpd xmm15, xmm15, 0x00
00007895b19d3432  vmovaps [rsp+0xD0], xmm1
00007895b19d343b  vmovaps xmm1, [rsp+0x40]
00007895b19d3441  vmovaps [rsp+0x40], xmm15
00007895b19d3447  vmovaps xmm15, [rsp+0x20]
00007895b19d344d  vmovaps [rsp+0x20], xmm14
00007895b19d3453  vmovaps xmm14, [rsp+0x40]
00007895b19d3459  vmovaps [rsp+0x40], xmm13
00007895b19d345f  vmovaps [rsp+0xE0], xmm12
00007895b19d3468  movaps xmm13, xmm1
00007895b19d346c  vfmadd231pd xmm13, xmm15, xmm14
00007895b19d3471  vcmppd xmm12, xmm13, xmm13, 0x03
00007895b19d3477  vptest xmm12, xmm12
00007895b19d347c  jnz 0x00007895B19D4162
00007895b19d3482  vmovaps xmm1, [rsp+0x90]
00007895b19d348b  vpermilpd xmm1, xmm1, 0x00
00007895b19d3491  vmovaps xmm15, [rsp+0xB0]
00007895b19d349a  vmovaps xmm14, [rsp+0x50]
00007895b19d34a0  vmovaps [rsp+0x50], xmm13
00007895b19d34a6  movaps xmm12, xmm15
00007895b19d34aa  vfmadd231pd xmm12, xmm14, xmm1
00007895b19d34af  vcmppd xmm13, xmm12, xmm12, 0x03
00007895b19d34b5  vptest xmm13, xmm13
00007895b19d34ba  jnz 0x00007895B19D42BB
00007895b19d34c0  vmovaps xmm1, [rsp+0x90]
00007895b19d34c9  vpermilpd xmm1, xmm1, 0x00
00007895b19d34cf  vmovaps xmm15, [rsp+0x130]
00007895b19d34d8  vmovaps xmm14, [rsp+0x60]
00007895b19d34de  vmovaps [rsp+0x60], xmm12
00007895b19d34e4  movaps xmm13, xmm15
00007895b19d34e8  vfmadd231pd xmm13, xmm14, xmm1
00007895b19d34ed  vcmppd xmm12, xmm13, xmm13, 0x03
00007895b19d34f3  vptest xmm12, xmm12
00007895b19d34f8  jnz 0x00007895B19D4414
00007895b19d34fe  vmovaps xmm1, [rsp+0x120]
00007895b19d3507  vmovaps xmm15, [rsp+0x120]
00007895b19d3510  por xmm1, xmm15
00007895b19d3515  movaps [r15+0x1D0], xmm1
00007895b19d351d  vmovaps xmm15, [rsp+0x90]
00007895b19d3526  vpermilpd xmm15, xmm15, 0x00
00007895b19d352c  vmovaps xmm14, [rsp+0xE0]
00007895b19d3535  vmovaps [rsp+0x90], xmm1
00007895b19d353e  movaps xmm12, xmm14
00007895b19d3542  vfmadd231pd xmm12, xmm2, xmm15
00007895b19d3547  vcmppd xmm1, xmm12, xmm12, 0x03
00007895b19d354d  vptest xmm1, xmm1
00007895b19d3552  jnz 0x00007895B19D456D
00007895b19d3558  vmovaps [rsp+0xB0], xmm3
00007895b19d3561  vmovaps xmm1, [rsp+0xB0]
00007895b19d356a  por xmm3, xmm1
00007895b19d356e  movaps [r15+0x200], xmm3
00007895b19d3576  vmovaps xmm1, [rsp+0xF0]
00007895b19d357f  vmovaps xmm15, [rsp+0xF0]
00007895b19d3588  por xmm1, xmm15
00007895b19d358d  movaps [r15+0x1E0], xmm1
00007895b19d3595  vmovaps [rsp+0xB0], xmm7
00007895b19d359e  vmovaps xmm1, [rsp+0xB0]
00007895b19d35a7  por xmm7, xmm1
00007895b19d35ab  movaps [r15+0x2B0], xmm7
00007895b19d35b3  vmovaps [rsp+0xB0], xmm8
00007895b19d35bc  vmovaps xmm1, [rsp+0xB0]
00007895b19d35c5  por xmm8, xmm1
00007895b19d35ca  movaps [r15+0x300], xmm8
00007895b19d35d2  vmovaps [rsp+0xB0], xmm5
00007895b19d35db  vpermilpd xmm5, xmm5, 0x00
00007895b19d35e1  vmovaps xmm14, [rsp+0x50]
00007895b19d35e7  vmovaps xmm8, [rsp+0x70]
00007895b19d35ed  vmovaps [rsp+0x50], xmm1
00007895b19d35f3  movaps xmm2, xmm14
00007895b19d35f7  vfmadd231pd xmm2, xmm8, xmm5
00007895b19d35fc  vcmppd xmm1, xmm2, xmm2, 0x03
00007895b19d3601  vptest xmm1, xmm1
00007895b19d3606  jnz 0x00007895B19D46C6
00007895b19d360c  vmovaps xmm1, [rsp+0xB0]
00007895b19d3615  vpermilpd xmm1, xmm1, 0x00
00007895b19d361b  vmovaps xmm14, [rsp+0x60]
00007895b19d3621  vmovaps xmm8, [rsp+0xD0]
00007895b19d362a  vmovaps [rsp+0x60], xmm15
00007895b19d3630  movaps xmm5, xmm14
00007895b19d3634  vfmadd231pd xmm5, xmm8, xmm1
00007895b19d3639  vcmppd xmm15, xmm5, xmm5, 0x03
00007895b19d363e  vptest xmm15, xmm15
00007895b19d3643  jnz 0x00007895B19D481D
00007895b19d3649  vmovaps xmm1, [rsp+0xB0]
00007895b19d3652  vpermilpd xmm1, xmm1, 0x00
00007895b19d3658  vmovaps xmm14, [rsp+0x20]
00007895b19d365e  movaps xmm15, xmm13
00007895b19d3662  vfmadd231pd xmm15, xmm14, xmm1
00007895b19d3667  vcmppd xmm8, xmm15, xmm15, 0x03
00007895b19d366d  vptest xmm8, xmm8
00007895b19d3672  jnz 0x00007895B19D4974
00007895b19d3678  vmovaps xmm1, [rsp+0xB0]
00007895b19d3681  vpermilpd xmm1, xmm1, 0x00
00007895b19d3687  vmovaps xmm14, [rsp+0x90]
00007895b19d3690  movaps xmm13, xmm12
00007895b19d3694  vfmadd231pd xmm13, xmm14, xmm1
00007895b19d3699  vcmppd xmm8, xmm13, xmm13, 0x03
00007895b19d369f  vptest xmm8, xmm8
00007895b19d36a4  jnz 0x00007895B19D4ACD
00007895b19d36aa  vmovaps [rsp+0x20], xmm6
00007895b19d36b0  vmovaps xmm1, [rsp+0x20]
00007895b19d36b6  por xmm6, xmm1
00007895b19d36ba  movaps [r15+0x180], xmm6
00007895b19d36c2  vmovaps [rsp+0x20], xmm9
00007895b19d36c8  vmovaps xmm1, [rsp+0x20]
00007895b19d36ce  por xmm9, xmm1
00007895b19d36d3  movaps [r15+0x2D0], xmm9
00007895b19d36db  vmovaps [rsp+0x20], xmm10
00007895b19d36e1  vmovaps xmm1, [rsp+0x20]
00007895b19d36e7  por xmm10, xmm1
00007895b19d36ec  movaps [r15+0x2F0], xmm10
00007895b19d36f4  vmovaps [rsp+0x20], xmm4
00007895b19d36fa  vpermilpd xmm4, xmm4, 0x00
00007895b19d3700  vmovaps xmm14, [rsp+0x50]
00007895b19d3706  movaps xmm12, xmm5
00007895b19d370a  vfmadd231pd xmm12, xmm14, xmm4
00007895b19d370f  vcmppd xmm10, xmm12, xmm12, 0x03
00007895b19d3715  vptest xmm10, xmm10
00007895b19d371a  jnz 0x00007895B19D4C26
00007895b19d3720  vmovaps xmm14, [rsp+0x20]
00007895b19d3726  vpermilpd xmm14, xmm14, 0x00
00007895b19d372c  movaps xmm10, xmm2
00007895b19d3730  vfmadd231pd xmm10, xmm6, xmm14
00007895b19d3735  vcmppd xmm8, xmm10, xmm10, 0x03
00007895b19d373b  vptest xmm8, xmm8
00007895b19d3740  jnz 0x00007895B19D4D7E
00007895b19d3746  lea r14, [rax+0x80]
00007895b19d374d  movups xmm14, [r13+r14*1]
00007895b19d3753  movaps [r15+0x190], xmm14
00007895b19d375b  vmovaps xmm8, [rsp+0x20]
00007895b19d3761  vpermilpd xmm8, xmm8, 0x00
00007895b19d3767  vmovaps xmm6, [rsp+0x80]
00007895b19d3770  movaps xmm5, xmm15
00007895b19d3774  vfmadd231pd xmm5, xmm6, xmm8
00007895b19d3779  vcmppd xmm4, xmm5, xmm5, 0x03
00007895b19d377e  vptest xmm4, xmm4
00007895b19d3783  jnz 0x00007895B19D4EE0
00007895b19d3789  vmovaps xmm15, [rsp+0x20]
00007895b19d378f  vpermilpd xmm15, xmm15, 0x00
00007895b19d3795  movaps xmm8, xmm13
00007895b19d3799  vfmadd231pd xmm8, xmm1, xmm15
00007895b19d379e  vcmppd xmm6, xmm8, xmm8, 0x03
00007895b19d37a4  vptest xmm6, xmm6
00007895b19d37a9  jnz 0x00007895B19D5037
00007895b19d37af  vmovaps xmm1, [rsp+0x30]
00007895b19d37b5  vmovaps xmm15, [rsp+0x30]
00007895b19d37bb  por xmm1, xmm15
00007895b19d37c0  movaps [r15+0x160], xmm1
00007895b19d37c8  lea r14, [rax+0x40]
00007895b19d37cc  movups xmm15, [r13+r14*1]
00007895b19d37d2  lea r14, [rax+0x50]
00007895b19d37d6  movups xmm13, [r13+r14*1]
00007895b19d37dc  movaps [r15+0x1B0], xmm15
00007895b19d37e4  movaps [r15+0x1A0], xmm13
00007895b19d37ec  vmovaps xmm6, [rsp+0xC0]
00007895b19d37f5  vpermilpd xmm6, xmm6, 0x00
00007895b19d37fb  movaps xmm4, xmm12
00007895b19d37ff  vfmadd231pd xmm4, xmm9, xmm6
00007895b19d3804  vcmppd xmm2, xmm4, xmm4, 0x03
00007895b19d3809  vptest xmm2, xmm2
00007895b19d380e  jnz 0x00007895B19D51A4
00007895b19d3814  vmovaps xmm12, [rsp+0xC0]
00007895b19d381d  vpermilpd xmm12, xmm12, 0x00
00007895b19d3823  movaps xmm9, xmm10
00007895b19d3827  vfmadd231pd xmm9, xmm1, xmm12
00007895b19d382c  vcmppd xmm6, xmm9, xmm9, 0x03
00007895b19d3832  vptest xmm6, xmm6
00007895b19d3837  jnz 0x00007895B19D52FB
00007895b19d383d  vmovaps xmm1, [rsp+0xC0]
00007895b19d3846  vpermilpd xmm1, xmm1, 0x00
00007895b19d384c  vmovaps xmm12, [rsp+0x40]
00007895b19d3852  movaps xmm10, xmm5
00007895b19d3856  vfmadd231pd xmm10, xmm12, xmm1
00007895b19d385b  vcmppd xmm6, xmm10, xmm10, 0x03
00007895b19d3861  vptest xmm6, xmm6
00007895b19d3866  jnz 0x00007895B19D5454
00007895b19d386c  vmovaps xmm1, [rsp+0xC0]
00007895b19d3875  vpermilpd xmm1, xmm1, 0x00
00007895b19d387b  vmovaps xmm12, [rsp+0x60]
00007895b19d3881  movaps xmm6, xmm8
00007895b19d3885  vfmadd231pd xmm6, xmm12, xmm1
00007895b19d388a  vcmppd xmm5, xmm6, xmm6, 0x03
00007895b19d388f  vptest xmm5, xmm5
00007895b19d3894  jnz 0x00007895B19D55AC
00007895b19d389a  lea r14, [rax+0x60]
00007895b19d389e  movups xmm1, [r13+r14*1]
00007895b19d38a4  lea r14, [rax+0x70]
00007895b19d38a8  movups xmm12, [r13+r14*1]
00007895b19d38ae  movaps [r15+0x150], xmm1
00007895b19d38b6  movaps [r15+0x120], xmm12
00007895b19d38be  vmovaps [rsp+0x20], xmm11
00007895b19d38c4  vpermilpd xmm11, xmm11, 0x00
00007895b19d38ca  movaps xmm8, xmm4
00007895b19d38ce  vfmadd231pd xmm8, xmm13, xmm11
00007895b19d38d3  vcmppd xmm5, xmm8, xmm8, 0x03
00007895b19d38d9  vptest xmm5, xmm5
00007895b19d38de  jnz 0x00007895B19D5717
00007895b19d38e4  vmovaps xmm13, [rsp+0x20]
00007895b19d38ea  vpermilpd xmm13, xmm13, 0x00
00007895b19d38f0  movaps xmm11, xmm9
00007895b19d38f4  vfmadd231pd xmm11, xmm1, xmm13
00007895b19d38f9  vcmppd xmm5, xmm11, xmm11, 0x03
00007895b19d38ff  vptest xmm5, xmm5
00007895b19d3904  jnz 0x00007895B19D5870
00007895b19d390a  vmovaps xmm1, [rsp+0x20]
00007895b19d3910  vpermilpd xmm1, xmm1, 0x00
00007895b19d3916  movaps xmm13, xmm10
00007895b19d391a  vfmadd231pd xmm13, xmm7, xmm1
00007895b19d391f  vcmppd xmm9, xmm13, xmm13, 0x03
00007895b19d3925  vptest xmm9, xmm9
00007895b19d392a  jnz 0x00007895B19D59C9
00007895b19d3930  vmovaps xmm1, [rsp+0x20]
00007895b19d3936  vpermilpd xmm1, xmm1, 0x00
00007895b19d393c  movaps xmm10, xmm6
00007895b19d3940  vfmadd231pd xmm10, xmm15, xmm1
00007895b19d3945  vcmppd xmm9, xmm10, xmm10, 0x03
00007895b19d394b  vptest xmm9, xmm9
00007895b19d3950  jnz 0x00007895B19D5B21
00007895b19d3956  lea r14, [rax+0x20]
00007895b19d395a  movups xmm1, [r13+r14*1]
00007895b19d3960  lea r14, [rax+0x30]
00007895b19d3964  movups xmm15, [r13+r14*1]
00007895b19d396a  vmovaps xmm9, [rsp+0xA0]
00007895b19d3973  vpermilpd xmm9, xmm9, 0x00
00007895b19d3979  movaps xmm7, xmm8
00007895b19d397d  vfmadd231pd xmm7, xmm3, xmm9
00007895b19d3982  vcmppd xmm6, xmm7, xmm7, 0x03
00007895b19d3987  vptest xmm6, xmm6
00007895b19d398c  jnz 0x00007895B19D5C8D
00007895b19d3992  vmovaps xmm9, [rsp+0xA0]
00007895b19d399b  vpermilpd xmm9, xmm9, 0x00
00007895b19d39a1  movaps xmm8, xmm11
00007895b19d39a5  vfmadd231pd xmm8, xmm14, xmm9
00007895b19d39aa  vcmppd xmm6, xmm8, xmm8, 0x03
00007895b19d39b0  vptest xmm6, xmm6
00007895b19d39b5  jnz 0x00007895B19D5DE4
00007895b19d39bb  vmovaps xmm14, [rsp+0xA0]
00007895b19d39c4  vpermilpd xmm14, xmm14, 0x00
00007895b19d39ca  movaps xmm11, xmm13
00007895b19d39ce  vfmadd231pd xmm11, xmm12, xmm14
00007895b19d39d3  vcmppd xmm9, xmm11, xmm11, 0x03
00007895b19d39d9  vptest xmm9, xmm9
00007895b19d39de  jnz 0x00007895B19D5F3E
00007895b19d39e4  vmovaps xmm14, [rsp+0xA0]
00007895b19d39ed  vpermilpd xmm14, xmm14, 0x00
00007895b19d39f3  movaps xmm12, xmm10
00007895b19d39f7  vfmadd231pd xmm12, xmm15, xmm14
00007895b19d39fc  vcmppd xmm13, xmm12, xmm12, 0x03
00007895b19d3a02  vptest xmm13, xmm13
00007895b19d3a07  jnz 0x00007895B19D6098
00007895b19d3a0d  lea r14, [rax+0x90]
00007895b19d3a14  movups xmm15, [r13+r14*1]
00007895b19d3a1a  lea r14, [rax+0xA0]
00007895b19d3a21  movups xmm14, [r13+r14*1]
00007895b19d3a27  movaps [r15+0x140], xmm15
00007895b19d3a2f  movaps [r15+0x130], xmm14
00007895b19d3a37  vmovaps xmm13, [rsp+0x10]
00007895b19d3a3d  vpermilpd xmm13, xmm13, 0x00
00007895b19d3a43  movaps xmm10, xmm7
00007895b19d3a47  vfmadd231pd xmm10, xmm1, xmm13
00007895b19d3a4c  vcmppd xmm9, xmm10, xmm10, 0x03
00007895b19d3a52  vptest xmm9, xmm9
00007895b19d3a57  jnz 0x00007895B19D6206
00007895b19d3a5d  movaps [r15+0x220], xmm10
00007895b19d3a65  lea r14, [rax+0x10]
00007895b19d3a69  movups xmm1, [r13+r14*1]
00007895b19d3a6f  movaps [r15+0x240], xmm1
00007895b19d3a77  vmovaps xmm13, [rsp+0x10]
00007895b19d3a7d  vpermilpd xmm13, xmm13, 0x00
00007895b19d3a83  movaps xmm9, xmm8
00007895b19d3a87  vfmadd231pd xmm9, xmm14, xmm13
00007895b19d3a8c  vcmppd xmm7, xmm9, xmm9, 0x03
00007895b19d3a92  vptest xmm7, xmm7
00007895b19d3a97  jnz 0x00007895B19D6368
00007895b19d3a9d  movaps [r15+0x110], xmm9
00007895b19d3aa5  vmovaps xmm14, [rsp+0x10]
00007895b19d3aab  vpermilpd xmm14, xmm14, 0x00
00007895b19d3ab1  movaps xmm13, xmm11
00007895b19d3ab5  vfmadd231pd xmm13, xmm15, xmm14
00007895b19d3aba  vcmppd xmm8, xmm13, xmm13, 0x03
00007895b19d3ac0  vptest xmm8, xmm8
00007895b19d3ac5  jnz 0x00007895B19D64C2
00007895b19d3acb  movaps [r15+0x170], xmm13
00007895b19d3ad3  vmovaps xmm15, [rsp+0x10]
00007895b19d3ad9  vpermilpd xmm15, xmm15, 0x00
00007895b19d3adf  movaps xmm14, xmm12
00007895b19d3ae3  vfmadd231pd xmm14, xmm1, xmm15
00007895b19d3ae8  vcmppd xmm11, xmm14, xmm14, 0x03
00007895b19d3aee  vptest xmm11, xmm11
00007895b19d3af3  jnz 0x00007895B19D661C
00007895b19d3af9  movaps [r15+0x230], xmm14
00007895b19d3b01  movups [r13+r11*1], xmm9
00007895b19d3b07  lea rax, [r11+0x10]
00007895b19d3b0b  movups [r13+rax*1], xmm13
00007895b19d3b11  lea rax, [r11+0x20]
00007895b19d3b15  movups [r13+rax*1], xmm10
00007895b19d3b1b  lea rax, [r11+0x30]
00007895b19d3b1f  movups [r13+rax*1], xmm14
00007895b19d3b25  mov eax, [r15+0x108]
00007895b19d3b2c  sahf
00007895b19d3b2d  jnz 0x00007895B19D3B5F
00007895b19d3b2f  cmp dword ptr [r15+0x318], 0x00
00007895b19d3b37  jz 0x00007895B19D67A0
00007895b19d3b3d  nop [rax+rax*1], ax
00007895b19d3b46  nop [rax+rax*1], eax
00007895b19d3b4e  mov eax, 0x4103F0
00007895b19d3b53  mov [r15+0x100], rax
00007895b19d3b5a  jmp 0x00007895B17FE110
00007895b19d3b5f  cmp dword ptr [r15+0x318], 0x00
00007895b19d3b67  jz 0x00007895B19D2E40
00007895b19d3b6d  nop [rax+rax*1], ax
00007895b19d3b76  nop [rax+rax*1], eax
00007895b19d3b7e  mov eax, 0x410274
00007895b19d3b83  mov [r15+0x100], rax
00007895b19d3b8a  jmp 0x00007895B17FE110
00007895b19d3b8f  int3
00007895b19d3b90  call 0x00007895B180A4B0
00007895b19d3b95  jmp 0x00007895B19D2E69
00007895b19d3b9a  call 0x00007895B1809240
00007895b19d3b9f  jmp 0x00007895B19D2E73
00007895b19d3ba4  call 0x00007895B180A4B0
00007895b19d3ba9  jmp 0x00007895B19D2EBD
00007895b19d3bae  call 0x00007895B1809240
00007895b19d3bb3  jmp 0x00007895B19D2EC7
00007895b19d3bb8  call 0x00007895B180A4B0
00007895b19d3bbd  jmp 0x00007895B19D2F60
00007895b19d3bc2  call 0x00007895B1809240
00007895b19d3bc7  jmp 0x00007895B19D2F6A
00007895b19d3bcc  call 0x00007895B18B47C0
00007895b19d3bd1  jmp 0x00007895B19D3055
00007895b19d3bd6  call 0x00007895B17FF430
00007895b19d3bdb  jmp 0x00007895B19D3084
00007895b19d3be0  call 0x00007895B18B0CE0
00007895b19d3be5  jmp 0x00007895B19D30A0
00007895b19d3bea  sub rsp, 0x08
00007895b19d3bee  push rax
00007895b19d3bef  push rcx
00007895b19d3bf0  push rdx
00007895b19d3bf1  push rdi
00007895b19d3bf2  push rsi
00007895b19d3bf3  push r8
00007895b19d3bf5  push r9
00007895b19d3bf7  push r10
00007895b19d3bf9  push r11
00007895b19d3bfb  sub rsp, 0xF0
00007895b19d3c02  vmovaps [rsp], xmm0
00007895b19d3c07  vmovaps [rsp+0x10], xmm1
00007895b19d3c0d  vmovaps [rsp+0x20], xmm2
00007895b19d3c13  vmovaps [rsp+0x30], xmm3
00007895b19d3c19  vmovaps [rsp+0x40], xmm4
00007895b19d3c1f  vmovaps [rsp+0x50], xmm5
00007895b19d3c25  vmovaps [rsp+0x60], xmm6
00007895b19d3c2b  vmovaps [rsp+0x70], xmm7
00007895b19d3c31  vmovaps [rsp+0x80], xmm8
00007895b19d3c3a  vmovaps [rsp+0x90], xmm9
00007895b19d3c43  vmovaps [rsp+0xA0], xmm10
00007895b19d3c4c  vmovaps [rsp+0xB0], xmm11
00007895b19d3c55  vmovaps [rsp+0xC0], xmm12
00007895b19d3c5e  vmovaps [rsp+0xD0], xmm14
00007895b19d3c67  vmovaps [rsp+0xE0], xmm15
00007895b19d3c70  sub rsp, 0x40
00007895b19d3c74  lea rdi, [rsp]
00007895b19d3c78  lea rsi, [rsp+0x10]
00007895b19d3c7d  lea rdx, [rsp+0x20]
00007895b19d3c82  lea rcx, [rsp+0x30]
00007895b19d3c87  mov r8d, 0x00
00007895b19d3c8d  lea r9, [r15+0x3A8]
00007895b19d3c94  movaps [rdi], xmm13
00007895b19d3c98  movaps [rsi], xmm1
00007895b19d3c9b  movaps [rdx], xmm15
00007895b19d3c9f  movaps [rcx], xmm14
00007895b19d3ca3  mov rax, 0x59D4522A9A50
00007895b19d3cad  call rax
00007895b19d3caf  movaps xmm13, [rsp]
00007895b19d3cb4  add rsp, 0x40
00007895b19d3cb8  vmovaps xmm0, [rsp]
00007895b19d3cbd  vmovaps xmm1, [rsp+0x10]
00007895b19d3cc3  vmovaps xmm2, [rsp+0x20]
00007895b19d3cc9  vmovaps xmm3, [rsp+0x30]
00007895b19d3ccf  vmovaps xmm4, [rsp+0x40]
00007895b19d3cd5  vmovaps xmm5, [rsp+0x50]
00007895b19d3cdb  vmovaps xmm6, [rsp+0x60]
00007895b19d3ce1  vmovaps xmm7, [rsp+0x70]
00007895b19d3ce7  vmovaps xmm8, [rsp+0x80]
00007895b19d3cf0  vmovaps xmm9, [rsp+0x90]
00007895b19d3cf9  vmovaps xmm10, [rsp+0xA0]
00007895b19d3d02  vmovaps xmm11, [rsp+0xB0]
00007895b19d3d0b  vmovaps xmm12, [rsp+0xC0]
00007895b19d3d14  vmovaps xmm14, [rsp+0xD0]
00007895b19d3d1d  vmovaps xmm15, [rsp+0xE0]
00007895b19d3d26  add rsp, 0xF0
00007895b19d3d2d  pop r11
00007895b19d3d2f  pop r10
00007895b19d3d31  pop r9
00007895b19d3d33  pop r8
00007895b19d3d35  pop rsi
00007895b19d3d36  pop rdi
00007895b19d3d37  pop rdx
00007895b19d3d38  pop rcx
00007895b19d3d39  pop rax
00007895b19d3d3a  add rsp, 0x08
00007895b19d3d3e  jmp 0x00007895B19D3117
00007895b19d3d43  sub rsp, 0x08
00007895b19d3d47  push rax
00007895b19d3d48  push rcx
00007895b19d3d49  push rdx
00007895b19d3d4a  push rdi
00007895b19d3d4b  push rsi
00007895b19d3d4c  push r8
00007895b19d3d4e  push r9
00007895b19d3d50  push r10
00007895b19d3d52  push r11
00007895b19d3d54  sub rsp, 0xF0
00007895b19d3d5b  vmovaps [rsp], xmm0
00007895b19d3d60  vmovaps [rsp+0x10], xmm1
00007895b19d3d66  vmovaps [rsp+0x20], xmm2
00007895b19d3d6c  vmovaps [rsp+0x30], xmm3
00007895b19d3d72  vmovaps [rsp+0x40], xmm4
00007895b19d3d78  vmovaps [rsp+0x50], xmm5
00007895b19d3d7e  vmovaps [rsp+0x60], xmm6
00007895b19d3d84  vmovaps [rsp+0x70], xmm7
00007895b19d3d8a  vmovaps [rsp+0x80], xmm8
00007895b19d3d93  vmovaps [rsp+0x90], xmm9
00007895b19d3d9c  vmovaps [rsp+0xA0], xmm10
00007895b19d3da5  vmovaps [rsp+0xB0], xmm11
00007895b19d3dae  vmovaps [rsp+0xC0], xmm13
00007895b19d3db7  vmovaps [rsp+0xD0], xmm14
00007895b19d3dc0  vmovaps [rsp+0xE0], xmm15
00007895b19d3dc9  sub rsp, 0x40
00007895b19d3dcd  lea rdi, [rsp]
00007895b19d3dd1  lea rsi, [rsp+0x10]
00007895b19d3dd6  lea rdx, [rsp+0x20]
00007895b19d3ddb  lea rcx, [rsp+0x30]
00007895b19d3de0  mov r8d, 0x00
00007895b19d3de6  lea r9, [r15+0x3A8]
00007895b19d3ded  movaps [rdi], xmm12
00007895b19d3df1  movaps [rsi], xmm15
00007895b19d3df5  movaps [rdx], xmm1
00007895b19d3df8  movaps [rcx], xmm14
00007895b19d3dfc  mov rax, 0x59D4522A9A50
00007895b19d3e06  call rax
00007895b19d3e08  movaps xmm12, [rsp]
00007895b19d3e0d  add rsp, 0x40
00007895b19d3e11  vmovaps xmm0, [rsp]
00007895b19d3e16  vmovaps xmm1, [rsp+0x10]
00007895b19d3e1c  vmovaps xmm2, [rsp+0x20]
00007895b19d3e22  vmovaps xmm3, [rsp+0x30]
00007895b19d3e28  vmovaps xmm4, [rsp+0x40]
00007895b19d3e2e  vmovaps xmm5, [rsp+0x50]
00007895b19d3e34  vmovaps xmm6, [rsp+0x60]
00007895b19d3e3a  vmovaps xmm7, [rsp+0x70]
00007895b19d3e40  vmovaps xmm8, [rsp+0x80]
00007895b19d3e49  vmovaps xmm9, [rsp+0x90]
00007895b19d3e52  vmovaps xmm10, [rsp+0xA0]
00007895b19d3e5b  vmovaps xmm11, [rsp+0xB0]
00007895b19d3e64  vmovaps xmm13, [rsp+0xC0]
00007895b19d3e6d  vmovaps xmm14, [rsp+0xD0]
00007895b19d3e76  vmovaps xmm15, [rsp+0xE0]
00007895b19d3e7f  add rsp, 0xF0
00007895b19d3e86  pop r11
00007895b19d3e88  pop r10
00007895b19d3e8a  pop r9
00007895b19d3e8c  pop r8
00007895b19d3e8e  pop rsi
00007895b19d3e8f  pop rdi
00007895b19d3e90  pop rdx
00007895b19d3e91  pop rcx
00007895b19d3e92  pop rax
00007895b19d3e93  add rsp, 0x08
00007895b19d3e97  jmp 0x00007895B19D3145
00007895b19d3e9c  call 0x00007895B18D64F0
00007895b19d3ea1  jmp 0x00007895B19D3231
00007895b19d3ea6  sub rsp, 0x08
00007895b19d3eaa  push rax
00007895b19d3eab  push rcx
00007895b19d3eac  push rdx
00007895b19d3ead  push rdi
00007895b19d3eae  push rsi
00007895b19d3eaf  push r8
00007895b19d3eb1  push r9
00007895b19d3eb3  push r10
00007895b19d3eb5  push r11
00007895b19d3eb7  sub rsp, 0xF0
00007895b19d3ebe  vmovaps [rsp], xmm0
00007895b19d3ec3  vmovaps [rsp+0x10], xmm1
00007895b19d3ec9  vmovaps [rsp+0x20], xmm2
00007895b19d3ecf  vmovaps [rsp+0x30], xmm3
00007895b19d3ed5  vmovaps [rsp+0x40], xmm4
00007895b19d3edb  vmovaps [rsp+0x50], xmm5
00007895b19d3ee1  vmovaps [rsp+0x60], xmm6
00007895b19d3ee7  vmovaps [rsp+0x70], xmm7
00007895b19d3eed  vmovaps [rsp+0x80], xmm8
00007895b19d3ef6  vmovaps [rsp+0x90], xmm9
00007895b19d3eff  vmovaps [rsp+0xA0], xmm10
00007895b19d3f08  vmovaps [rsp+0xB0], xmm11
00007895b19d3f11  vmovaps [rsp+0xC0], xmm12
00007895b19d3f1a  vmovaps [rsp+0xD0], xmm14
00007895b19d3f23  vmovaps [rsp+0xE0], xmm15
00007895b19d3f2c  sub rsp, 0x40
00007895b19d3f30  lea rdi, [rsp]
00007895b19d3f34  lea rsi, [rsp+0x10]
00007895b19d3f39  lea rdx, [rsp+0x20]
00007895b19d3f3e  lea rcx, [rsp+0x30]
00007895b19d3f43  mov r8d, 0x00
00007895b19d3f49  lea r9, [r15+0x3A8]
00007895b19d3f50  movaps [rdi], xmm13
00007895b19d3f54  movaps [rsi], xmm1
00007895b19d3f57  movaps [rdx], xmm15
00007895b19d3f5b  movaps [rcx], xmm14
00007895b19d3f5f  mov rax, 0x59D4522A9A50
00007895b19d3f69  call rax
00007895b19d3f6b  movaps xmm13, [rsp]
00007895b19d3f70  add rsp, 0x40
00007895b19d3f74  vmovaps xmm0, [rsp]
00007895b19d3f79  vmovaps xmm1, [rsp+0x10]
00007895b19d3f7f  vmovaps xmm2, [rsp+0x20]
00007895b19d3f85  vmovaps xmm3, [rsp+0x30]
00007895b19d3f8b  vmovaps xmm4, [rsp+0x40]
00007895b19d3f91  vmovaps xmm5, [rsp+0x50]
00007895b19d3f97  vmovaps xmm6, [rsp+0x60]
00007895b19d3f9d  vmovaps xmm7, [rsp+0x70]
00007895b19d3fa3  vmovaps xmm8, [rsp+0x80]
00007895b19d3fac  vmovaps xmm9, [rsp+0x90]
00007895b19d3fb5  vmovaps xmm10, [rsp+0xA0]
00007895b19d3fbe  vmovaps xmm11, [rsp+0xB0]
00007895b19d3fc7  vmovaps xmm12, [rsp+0xC0]
00007895b19d3fd0  vmovaps xmm14, [rsp+0xD0]
00007895b19d3fd9  vmovaps xmm15, [rsp+0xE0]
00007895b19d3fe2  add rsp, 0xF0
00007895b19d3fe9  pop r11
00007895b19d3feb  pop r10
00007895b19d3fed  pop r9
00007895b19d3fef  pop r8
00007895b19d3ff1  pop rsi
00007895b19d3ff2  pop rdi
00007895b19d3ff3  pop rdx
00007895b19d3ff4  pop rcx
00007895b19d3ff5  pop rax
00007895b19d3ff6  add rsp, 0x08
00007895b19d3ffa  jmp 0x00007895B19D32A0
00007895b19d3fff  call 0x00007895B18D64F0
00007895b19d4004  jmp 0x00007895B19D32B5
00007895b19d4009  sub rsp, 0x08
00007895b19d400d  push rax
00007895b19d400e  push rcx
00007895b19d400f  push rdx
00007895b19d4010  push rdi
00007895b19d4011  push rsi
00007895b19d4012  push r8
00007895b19d4014  push r9
00007895b19d4016  push r10
00007895b19d4018  push r11
00007895b19d401a  sub rsp, 0xF0
00007895b19d4021  vmovaps [rsp], xmm0
00007895b19d4026  vmovaps [rsp+0x10], xmm1
00007895b19d402c  vmovaps [rsp+0x20], xmm2
00007895b19d4032  vmovaps [rsp+0x30], xmm3
00007895b19d4038  vmovaps [rsp+0x40], xmm4
00007895b19d403e  vmovaps [rsp+0x50], xmm5
00007895b19d4044  vmovaps [rsp+0x60], xmm6
00007895b19d404a  vmovaps [rsp+0x70], xmm7
00007895b19d4050  vmovaps [rsp+0x80], xmm8
00007895b19d4059  vmovaps [rsp+0x90], xmm9
00007895b19d4062  vmovaps [rsp+0xA0], xmm10
00007895b19d406b  vmovaps [rsp+0xB0], xmm11
00007895b19d4074  vmovaps [rsp+0xC0], xmm13
00007895b19d407d  vmovaps [rsp+0xD0], xmm14
00007895b19d4086  vmovaps [rsp+0xE0], xmm15
00007895b19d408f  sub rsp, 0x40
00007895b19d4093  lea rdi, [rsp]
00007895b19d4097  lea rsi, [rsp+0x10]
00007895b19d409c  lea rdx, [rsp+0x20]
00007895b19d40a1  lea rcx, [rsp+0x30]
00007895b19d40a6  mov r8d, 0x00
00007895b19d40ac  lea r9, [r15+0x3A8]
00007895b19d40b3  movaps [rdi], xmm12
00007895b19d40b7  movaps [rsi], xmm15
00007895b19d40bb  movaps [rdx], xmm1
00007895b19d40be  movaps [rcx], xmm14
00007895b19d40c2  mov rax, 0x59D4522A9A50
00007895b19d40cc  call rax
00007895b19d40ce  movaps xmm12, [rsp]
00007895b19d40d3  add rsp, 0x40
00007895b19d40d7  vmovaps xmm0, [rsp]
00007895b19d40dc  vmovaps xmm1, [rsp+0x10]
00007895b19d40e2  vmovaps xmm2, [rsp+0x20]
00007895b19d40e8  vmovaps xmm3, [rsp+0x30]
00007895b19d40ee  vmovaps xmm4, [rsp+0x40]
00007895b19d40f4  vmovaps xmm5, [rsp+0x50]
00007895b19d40fa  vmovaps xmm6, [rsp+0x60]
00007895b19d4100  vmovaps xmm7, [rsp+0x70]
00007895b19d4106  vmovaps xmm8, [rsp+0x80]
00007895b19d410f  vmovaps xmm9, [rsp+0x90]
00007895b19d4118  vmovaps xmm10, [rsp+0xA0]
00007895b19d4121  vmovaps xmm11, [rsp+0xB0]
00007895b19d412a  vmovaps xmm13, [rsp+0xC0]
00007895b19d4133  vmovaps xmm14, [rsp+0xD0]
00007895b19d413c  vmovaps xmm15, [rsp+0xE0]
00007895b19d4145  add rsp, 0xF0
00007895b19d414c  pop r11
00007895b19d414e  pop r10
00007895b19d4150  pop r9
00007895b19d4152  pop r8
00007895b19d4154  pop rsi
00007895b19d4155  pop rdi
00007895b19d4156  pop rdx
00007895b19d4157  pop rcx
00007895b19d4158  pop rax
00007895b19d4159  add rsp, 0x08
00007895b19d415d  jmp 0x00007895B19D32E1
00007895b19d4162  sub rsp, 0x08
00007895b19d4166  push rax
00007895b19d4167  push rcx
00007895b19d4168  push rdx
00007895b19d4169  push rdi
00007895b19d416a  push rsi
00007895b19d416b  push r8
00007895b19d416d  push r9
00007895b19d416f  push r10
00007895b19d4171  push r11
00007895b19d4173  sub rsp, 0xF0
00007895b19d417a  vmovaps [rsp], xmm0
00007895b19d417f  vmovaps [rsp+0x10], xmm1
00007895b19d4185  vmovaps [rsp+0x20], xmm2
00007895b19d418b  vmovaps [rsp+0x30], xmm3
00007895b19d4191  vmovaps [rsp+0x40], xmm4
00007895b19d4197  vmovaps [rsp+0x50], xmm5
00007895b19d419d  vmovaps [rsp+0x60], xmm6
00007895b19d41a3  vmovaps [rsp+0x70], xmm7
00007895b19d41a9  vmovaps [rsp+0x80], xmm8
00007895b19d41b2  vmovaps [rsp+0x90], xmm9
00007895b19d41bb  vmovaps [rsp+0xA0], xmm10
00007895b19d41c4  vmovaps [rsp+0xB0], xmm11
00007895b19d41cd  vmovaps [rsp+0xC0], xmm12
00007895b19d41d6  vmovaps [rsp+0xD0], xmm14
00007895b19d41df  vmovaps [rsp+0xE0], xmm15
00007895b19d41e8  sub rsp, 0x40
00007895b19d41ec  lea rdi, [rsp]
00007895b19d41f0  lea rsi, [rsp+0x10]
00007895b19d41f5  lea rdx, [rsp+0x20]
00007895b19d41fa  lea rcx, [rsp+0x30]
00007895b19d41ff  mov r8d, 0x00
00007895b19d4205  lea r9, [r15+0x3A8]
00007895b19d420c  movaps [rdi], xmm13
00007895b19d4210  movaps [rsi], xmm1
00007895b19d4213  movaps [rdx], xmm15
00007895b19d4217  movaps [rcx], xmm14
00007895b19d421b  mov rax, 0x59D4522A9A50
00007895b19d4225  call rax
00007895b19d4227  movaps xmm13, [rsp]
00007895b19d422c  add rsp, 0x40
00007895b19d4230  vmovaps xmm0, [rsp]
00007895b19d4235  vmovaps xmm1, [rsp+0x10]
00007895b19d423b  vmovaps xmm2, [rsp+0x20]
00007895b19d4241  vmovaps xmm3, [rsp+0x30]
00007895b19d4247  vmovaps xmm4, [rsp+0x40]
00007895b19d424d  vmovaps xmm5, [rsp+0x50]
00007895b19d4253  vmovaps xmm6, [rsp+0x60]
00007895b19d4259  vmovaps xmm7, [rsp+0x70]
00007895b19d425f  vmovaps xmm8, [rsp+0x80]
00007895b19d4268  vmovaps xmm9, [rsp+0x90]
00007895b19d4271  vmovaps xmm10, [rsp+0xA0]
00007895b19d427a  vmovaps xmm11, [rsp+0xB0]
00007895b19d4283  vmovaps xmm12, [rsp+0xC0]
00007895b19d428c  vmovaps xmm14, [rsp+0xD0]
00007895b19d4295  vmovaps xmm15, [rsp+0xE0]
00007895b19d429e  add rsp, 0xF0
00007895b19d42a5  pop r11
00007895b19d42a7  pop r10
00007895b19d42a9  pop r9
00007895b19d42ab  pop r8
00007895b19d42ad  pop rsi
00007895b19d42ae  pop rdi
00007895b19d42af  pop rdx
00007895b19d42b0  pop rcx
00007895b19d42b1  pop rax
00007895b19d42b2  add rsp, 0x08
00007895b19d42b6  jmp 0x00007895B19D3482
00007895b19d42bb  sub rsp, 0x08
00007895b19d42bf  push rax
00007895b19d42c0  push rcx
00007895b19d42c1  push rdx
00007895b19d42c2  push rdi
00007895b19d42c3  push rsi
00007895b19d42c4  push r8
00007895b19d42c6  push r9
00007895b19d42c8  push r10
00007895b19d42ca  push r11
00007895b19d42cc  sub rsp, 0xF0
00007895b19d42d3  vmovaps [rsp], xmm0
00007895b19d42d8  vmovaps [rsp+0x10], xmm1
00007895b19d42de  vmovaps [rsp+0x20], xmm2
00007895b19d42e4  vmovaps [rsp+0x30], xmm3
00007895b19d42ea  vmovaps [rsp+0x40], xmm4
00007895b19d42f0  vmovaps [rsp+0x50], xmm5
00007895b19d42f6  vmovaps [rsp+0x60], xmm6
00007895b19d42fc  vmovaps [rsp+0x70], xmm7
00007895b19d4302  vmovaps [rsp+0x80], xmm8
00007895b19d430b  vmovaps [rsp+0x90], xmm9
00007895b19d4314  vmovaps [rsp+0xA0], xmm10
00007895b19d431d  vmovaps [rsp+0xB0], xmm11
00007895b19d4326  vmovaps [rsp+0xC0], xmm13
00007895b19d432f  vmovaps [rsp+0xD0], xmm14
00007895b19d4338  vmovaps [rsp+0xE0], xmm15
00007895b19d4341  sub rsp, 0x40
00007895b19d4345  lea rdi, [rsp]
00007895b19d4349  lea rsi, [rsp+0x10]
00007895b19d434e  lea rdx, [rsp+0x20]
00007895b19d4353  lea rcx, [rsp+0x30]
00007895b19d4358  mov r8d, 0x00
00007895b19d435e  lea r9, [r15+0x3A8]
00007895b19d4365  movaps [rdi], xmm12
00007895b19d4369  movaps [rsi], xmm15
00007895b19d436d  movaps [rdx], xmm14
00007895b19d4371  movaps [rcx], xmm1
00007895b19d4374  mov rax, 0x59D4522A9A50
00007895b19d437e  call rax
00007895b19d4380  movaps xmm12, [rsp]
00007895b19d4385  add rsp, 0x40
00007895b19d4389  vmovaps xmm0, [rsp]
00007895b19d438e  vmovaps xmm1, [rsp+0x10]
00007895b19d4394  vmovaps xmm2, [rsp+0x20]
00007895b19d439a  vmovaps xmm3, [rsp+0x30]
00007895b19d43a0  vmovaps xmm4, [rsp+0x40]
00007895b19d43a6  vmovaps xmm5, [rsp+0x50]
00007895b19d43ac  vmovaps xmm6, [rsp+0x60]
00007895b19d43b2  vmovaps xmm7, [rsp+0x70]
00007895b19d43b8  vmovaps xmm8, [rsp+0x80]
00007895b19d43c1  vmovaps xmm9, [rsp+0x90]
00007895b19d43ca  vmovaps xmm10, [rsp+0xA0]
00007895b19d43d3  vmovaps xmm11, [rsp+0xB0]
00007895b19d43dc  vmovaps xmm13, [rsp+0xC0]
00007895b19d43e5  vmovaps xmm14, [rsp+0xD0]
00007895b19d43ee  vmovaps xmm15, [rsp+0xE0]
00007895b19d43f7  add rsp, 0xF0
00007895b19d43fe  pop r11
00007895b19d4400  pop r10
00007895b19d4402  pop r9
00007895b19d4404  pop r8
00007895b19d4406  pop rsi
00007895b19d4407  pop rdi
00007895b19d4408  pop rdx
00007895b19d4409  pop rcx
00007895b19d440a  pop rax
00007895b19d440b  add rsp, 0x08
00007895b19d440f  jmp 0x00007895B19D34C0
00007895b19d4414  sub rsp, 0x08
00007895b19d4418  push rax
00007895b19d4419  push rcx
00007895b19d441a  push rdx
00007895b19d441b  push rdi
00007895b19d441c  push rsi
00007895b19d441d  push r8
00007895b19d441f  push r9
00007895b19d4421  push r10
00007895b19d4423  push r11
00007895b19d4425  sub rsp, 0xF0
00007895b19d442c  vmovaps [rsp], xmm0
00007895b19d4431  vmovaps [rsp+0x10], xmm1
00007895b19d4437  vmovaps [rsp+0x20], xmm2
00007895b19d443d  vmovaps [rsp+0x30], xmm3
00007895b19d4443  vmovaps [rsp+0x40], xmm4
00007895b19d4449  vmovaps [rsp+0x50], xmm5
00007895b19d444f  vmovaps [rsp+0x60], xmm6
00007895b19d4455  vmovaps [rsp+0x70], xmm7
00007895b19d445b  vmovaps [rsp+0x80], xmm8
00007895b19d4464  vmovaps [rsp+0x90], xmm9
00007895b19d446d  vmovaps [rsp+0xA0], xmm10
00007895b19d4476  vmovaps [rsp+0xB0], xmm11
00007895b19d447f  vmovaps [rsp+0xC0], xmm12
00007895b19d4488  vmovaps [rsp+0xD0], xmm14
00007895b19d4491  vmovaps [rsp+0xE0], xmm15
00007895b19d449a  sub rsp, 0x40
00007895b19d449e  lea rdi, [rsp]
00007895b19d44a2  lea rsi, [rsp+0x10]
00007895b19d44a7  lea rdx, [rsp+0x20]
00007895b19d44ac  lea rcx, [rsp+0x30]
00007895b19d44b1  mov r8d, 0x00
00007895b19d44b7  lea r9, [r15+0x3A8]
00007895b19d44be  movaps [rdi], xmm13
00007895b19d44c2  movaps [rsi], xmm15
00007895b19d44c6  movaps [rdx], xmm14
00007895b19d44ca  movaps [rcx], xmm1
00007895b19d44cd  mov rax, 0x59D4522A9A50
00007895b19d44d7  call rax
00007895b19d44d9  movaps xmm13, [rsp]
00007895b19d44de  add rsp, 0x40
00007895b19d44e2  vmovaps xmm0, [rsp]
00007895b19d44e7  vmovaps xmm1, [rsp+0x10]
00007895b19d44ed  vmovaps xmm2, [rsp+0x20]
00007895b19d44f3  vmovaps xmm3, [rsp+0x30]
00007895b19d44f9  vmovaps xmm4, [rsp+0x40]
00007895b19d44ff  vmovaps xmm5, [rsp+0x50]
00007895b19d4505  vmovaps xmm6, [rsp+0x60]
00007895b19d450b  vmovaps xmm7, [rsp+0x70]
00007895b19d4511  vmovaps xmm8, [rsp+0x80]
00007895b19d451a  vmovaps xmm9, [rsp+0x90]
00007895b19d4523  vmovaps xmm10, [rsp+0xA0]
00007895b19d452c  vmovaps xmm11, [rsp+0xB0]
00007895b19d4535  vmovaps xmm12, [rsp+0xC0]
00007895b19d453e  vmovaps xmm14, [rsp+0xD0]
00007895b19d4547  vmovaps xmm15, [rsp+0xE0]
00007895b19d4550  add rsp, 0xF0
00007895b19d4557  pop r11
00007895b19d4559  pop r10
00007895b19d455b  pop r9
00007895b19d455d  pop r8
00007895b19d455f  pop rsi
00007895b19d4560  pop rdi
00007895b19d4561  pop rdx
00007895b19d4562  pop rcx
00007895b19d4563  pop rax
00007895b19d4564  add rsp, 0x08
00007895b19d4568  jmp 0x00007895B19D34FE
00007895b19d456d  sub rsp, 0x08
00007895b19d4571  push rax
00007895b19d4572  push rcx
00007895b19d4573  push rdx
00007895b19d4574  push rdi
00007895b19d4575  push rsi
00007895b19d4576  push r8
00007895b19d4578  push r9
00007895b19d457a  push r10
00007895b19d457c  push r11
00007895b19d457e  sub rsp, 0xF0
00007895b19d4585  vmovaps [rsp], xmm0
00007895b19d458a  vmovaps [rsp+0x10], xmm1
00007895b19d4590  vmovaps [rsp+0x20], xmm2
00007895b19d4596  vmovaps [rsp+0x30], xmm3
00007895b19d459c  vmovaps [rsp+0x40], xmm4
00007895b19d45a2  vmovaps [rsp+0x50], xmm5
00007895b19d45a8  vmovaps [rsp+0x60], xmm6
00007895b19d45ae  vmovaps [rsp+0x70], xmm7
00007895b19d45b4  vmovaps [rsp+0x80], xmm8
00007895b19d45bd  vmovaps [rsp+0x90], xmm9
00007895b19d45c6  vmovaps [rsp+0xA0], xmm10
00007895b19d45cf  vmovaps [rsp+0xB0], xmm11
00007895b19d45d8  vmovaps [rsp+0xC0], xmm13
00007895b19d45e1  vmovaps [rsp+0xD0], xmm14
00007895b19d45ea  vmovaps [rsp+0xE0], xmm15
00007895b19d45f3  sub rsp, 0x40
00007895b19d45f7  lea rdi, [rsp]
00007895b19d45fb  lea rsi, [rsp+0x10]
00007895b19d4600  lea rdx, [rsp+0x20]
00007895b19d4605  lea rcx, [rsp+0x30]
00007895b19d460a  mov r8d, 0x00
00007895b19d4610  lea r9, [r15+0x3A8]
00007895b19d4617  movaps [rdi], xmm12
00007895b19d461b  movaps [rsi], xmm14
00007895b19d461f  movaps [rdx], xmm2
00007895b19d4622  movaps [rcx], xmm15
00007895b19d4626  mov rax, 0x59D4522A9A50
00007895b19d4630  call rax
00007895b19d4632  movaps xmm12, [rsp]
00007895b19d4637  add rsp, 0x40
00007895b19d463b  vmovaps xmm0, [rsp]
00007895b19d4640  vmovaps xmm1, [rsp+0x10]
00007895b19d4646  vmovaps xmm2, [rsp+0x20]
00007895b19d464c  vmovaps xmm3, [rsp+0x30]
00007895b19d4652  vmovaps xmm4, [rsp+0x40]
00007895b19d4658  vmovaps xmm5, [rsp+0x50]
00007895b19d465e  vmovaps xmm6, [rsp+0x60]
00007895b19d4664  vmovaps xmm7, [rsp+0x70]
00007895b19d466a  vmovaps xmm8, [rsp+0x80]
00007895b19d4673  vmovaps xmm9, [rsp+0x90]
00007895b19d467c  vmovaps xmm10, [rsp+0xA0]
00007895b19d4685  vmovaps xmm11, [rsp+0xB0]
00007895b19d468e  vmovaps xmm13, [rsp+0xC0]
00007895b19d4697  vmovaps xmm14, [rsp+0xD0]
00007895b19d46a0  vmovaps xmm15, [rsp+0xE0]
00007895b19d46a9  add rsp, 0xF0
00007895b19d46b0  pop r11
00007895b19d46b2  pop r10
00007895b19d46b4  pop r9
00007895b19d46b6  pop r8
00007895b19d46b8  pop rsi
00007895b19d46b9  pop rdi
00007895b19d46ba  pop rdx
00007895b19d46bb  pop rcx
00007895b19d46bc  pop rax
00007895b19d46bd  add rsp, 0x08
00007895b19d46c1  jmp 0x00007895B19D3558
00007895b19d46c6  sub rsp, 0x08
00007895b19d46ca  push rax
00007895b19d46cb  push rcx
00007895b19d46cc  push rdx
00007895b19d46cd  push rdi
00007895b19d46ce  push rsi
00007895b19d46cf  push r8
00007895b19d46d1  push r9
00007895b19d46d3  push r10
00007895b19d46d5  push r11
00007895b19d46d7  sub rsp, 0xF0
00007895b19d46de  vmovaps [rsp], xmm0
00007895b19d46e3  vmovaps [rsp+0x10], xmm1
00007895b19d46e9  vmovaps [rsp+0x20], xmm3
00007895b19d46ef  vmovaps [rsp+0x30], xmm4
00007895b19d46f5  vmovaps [rsp+0x40], xmm5
00007895b19d46fb  vmovaps [rsp+0x50], xmm6
00007895b19d4701  vmovaps [rsp+0x60], xmm7
00007895b19d4707  vmovaps [rsp+0x70], xmm8
00007895b19d470d  vmovaps [rsp+0x80], xmm9
00007895b19d4716  vmovaps [rsp+0x90], xmm10
00007895b19d471f  vmovaps [rsp+0xA0], xmm11
00007895b19d4728  vmovaps [rsp+0xB0], xmm12
00007895b19d4731  vmovaps [rsp+0xC0], xmm13
00007895b19d473a  vmovaps [rsp+0xD0], xmm14
00007895b19d4743  vmovaps [rsp+0xE0], xmm15
00007895b19d474c  sub rsp, 0x40
00007895b19d4750  lea rdi, [rsp]
00007895b19d4754  lea rsi, [rsp+0x10]
00007895b19d4759  lea rdx, [rsp+0x20]
00007895b19d475e  lea rcx, [rsp+0x30]
00007895b19d4763  mov r8d, 0x00
00007895b19d4769  lea r9, [r15+0x3A8]
00007895b19d4770  movaps [rdi], xmm2
00007895b19d4773  movaps [rsi], xmm14
00007895b19d4777  movaps [rdx], xmm8
00007895b19d477b  movaps [rcx], xmm5
00007895b19d477e  mov rax, 0x59D4522A9A50
00007895b19d4788  call rax
00007895b19d478a  movaps xmm2, [rsp]
00007895b19d478e  add rsp, 0x40
00007895b19d4792  vmovaps xmm0, [rsp]
00007895b19d4797  vmovaps xmm1, [rsp+0x10]
00007895b19d479d  vmovaps xmm3, [rsp+0x20]
00007895b19d47a3  vmovaps xmm4, [rsp+0x30]
00007895b19d47a9  vmovaps xmm5, [rsp+0x40]
00007895b19d47af  vmovaps xmm6, [rsp+0x50]
00007895b19d47b5  vmovaps xmm7, [rsp+0x60]
00007895b19d47bb  vmovaps xmm8, [rsp+0x70]
00007895b19d47c1  vmovaps xmm9, [rsp+0x80]
00007895b19d47ca  vmovaps xmm10, [rsp+0x90]
00007895b19d47d3  vmovaps xmm11, [rsp+0xA0]
00007895b19d47dc  vmovaps xmm12, [rsp+0xB0]
00007895b19d47e5  vmovaps xmm13, [rsp+0xC0]
00007895b19d47ee  vmovaps xmm14, [rsp+0xD0]
00007895b19d47f7  vmovaps xmm15, [rsp+0xE0]
00007895b19d4800  add rsp, 0xF0
00007895b19d4807  pop r11
00007895b19d4809  pop r10
00007895b19d480b  pop r9
00007895b19d480d  pop r8
00007895b19d480f  pop rsi
00007895b19d4810  pop rdi
00007895b19d4811  pop rdx
00007895b19d4812  pop rcx
00007895b19d4813  pop rax
00007895b19d4814  add rsp, 0x08
00007895b19d4818  jmp 0x00007895B19D360C
00007895b19d481d  sub rsp, 0x08
00007895b19d4821  push rax
00007895b19d4822  push rcx
00007895b19d4823  push rdx
00007895b19d4824  push rdi
00007895b19d4825  push rsi
00007895b19d4826  push r8
00007895b19d4828  push r9
00007895b19d482a  push r10
00007895b19d482c  push r11
00007895b19d482e  sub rsp, 0xF0
00007895b19d4835  vmovaps [rsp], xmm0
00007895b19d483a  vmovaps [rsp+0x10], xmm1
00007895b19d4840  vmovaps [rsp+0x20], xmm2
00007895b19d4846  vmovaps [rsp+0x30], xmm3
00007895b19d484c  vmovaps [rsp+0x40], xmm4
00007895b19d4852  vmovaps [rsp+0x50], xmm6
00007895b19d4858  vmovaps [rsp+0x60], xmm7
00007895b19d485e  vmovaps [rsp+0x70], xmm8
00007895b19d4864  vmovaps [rsp+0x80], xmm9
00007895b19d486d  vmovaps [rsp+0x90], xmm10
00007895b19d4876  vmovaps [rsp+0xA0], xmm11
00007895b19d487f  vmovaps [rsp+0xB0], xmm12
00007895b19d4888  vmovaps [rsp+0xC0], xmm13
00007895b19d4891  vmovaps [rsp+0xD0], xmm14
00007895b19d489a  vmovaps [rsp+0xE0], xmm15
00007895b19d48a3  sub rsp, 0x40
00007895b19d48a7  lea rdi, [rsp]
00007895b19d48ab  lea rsi, [rsp+0x10]
00007895b19d48b0  lea rdx, [rsp+0x20]
00007895b19d48b5  lea rcx, [rsp+0x30]
00007895b19d48ba  mov r8d, 0x00
00007895b19d48c0  lea r9, [r15+0x3A8]
00007895b19d48c7  movaps [rdi], xmm5
00007895b19d48ca  movaps [rsi], xmm14
00007895b19d48ce  movaps [rdx], xmm8
00007895b19d48d2  movaps [rcx], xmm1
00007895b19d48d5  mov rax, 0x59D4522A9A50
00007895b19d48df  call rax
00007895b19d48e1  movaps xmm5, [rsp]
00007895b19d48e5  add rsp, 0x40
00007895b19d48e9  vmovaps xmm0, [rsp]
00007895b19d48ee  vmovaps xmm1, [rsp+0x10]
00007895b19d48f4  vmovaps xmm2, [rsp+0x20]
00007895b19d48fa  vmovaps xmm3, [rsp+0x30]
00007895b19d4900  vmovaps xmm4, [rsp+0x40]
00007895b19d4906  vmovaps xmm6, [rsp+0x50]
00007895b19d490c  vmovaps xmm7, [rsp+0x60]
00007895b19d4912  vmovaps xmm8, [rsp+0x70]
00007895b19d4918  vmovaps xmm9, [rsp+0x80]
00007895b19d4921  vmovaps xmm10, [rsp+0x90]
00007895b19d492a  vmovaps xmm11, [rsp+0xA0]
00007895b19d4933  vmovaps xmm12, [rsp+0xB0]
00007895b19d493c  vmovaps xmm13, [rsp+0xC0]
00007895b19d4945  vmovaps xmm14, [rsp+0xD0]
00007895b19d494e  vmovaps xmm15, [rsp+0xE0]
00007895b19d4957  add rsp, 0xF0
00007895b19d495e  pop r11
00007895b19d4960  pop r10
00007895b19d4962  pop r9
00007895b19d4964  pop r8
00007895b19d4966  pop rsi
00007895b19d4967  pop rdi
00007895b19d4968  pop rdx
00007895b19d4969  pop rcx
00007895b19d496a  pop rax
00007895b19d496b  add rsp, 0x08
00007895b19d496f  jmp 0x00007895B19D3649
00007895b19d4974  sub rsp, 0x08
00007895b19d4978  push rax
00007895b19d4979  push rcx
00007895b19d497a  push rdx
00007895b19d497b  push rdi
00007895b19d497c  push rsi
00007895b19d497d  push r8
00007895b19d497f  push r9
00007895b19d4981  push r10
00007895b19d4983  push r11
00007895b19d4985  sub rsp, 0xF0
00007895b19d498c  vmovaps [rsp], xmm0
00007895b19d4991  vmovaps [rsp+0x10], xmm1
00007895b19d4997  vmovaps [rsp+0x20], xmm2
00007895b19d499d  vmovaps [rsp+0x30], xmm3
00007895b19d49a3  vmovaps [rsp+0x40], xmm4
00007895b19d49a9  vmovaps [rsp+0x50], xmm5
00007895b19d49af  vmovaps [rsp+0x60], xmm6
00007895b19d49b5  vmovaps [rsp+0x70], xmm7
00007895b19d49bb  vmovaps [rsp+0x80], xmm8
00007895b19d49c4  vmovaps [rsp+0x90], xmm9
00007895b19d49cd  vmovaps [rsp+0xA0], xmm10
00007895b19d49d6  vmovaps [rsp+0xB0], xmm11
00007895b19d49df  vmovaps [rsp+0xC0], xmm12
00007895b19d49e8  vmovaps [rsp+0xD0], xmm13
00007895b19d49f1  vmovaps [rsp+0xE0], xmm14
00007895b19d49fa  sub rsp, 0x40
00007895b19d49fe  lea rdi, [rsp]
00007895b19d4a02  lea rsi, [rsp+0x10]
00007895b19d4a07  lea rdx, [rsp+0x20]
00007895b19d4a0c  lea rcx, [rsp+0x30]
00007895b19d4a11  mov r8d, 0x00
00007895b19d4a17  lea r9, [r15+0x3A8]
00007895b19d4a1e  movaps [rdi], xmm15
00007895b19d4a22  movaps [rsi], xmm13
00007895b19d4a26  movaps [rdx], xmm14
00007895b19d4a2a  movaps [rcx], xmm1
00007895b19d4a2d  mov rax, 0x59D4522A9A50
00007895b19d4a37  call rax
00007895b19d4a39  movaps xmm15, [rsp]
00007895b19d4a3e  add rsp, 0x40
00007895b19d4a42  vmovaps xmm0, [rsp]
00007895b19d4a47  vmovaps xmm1, [rsp+0x10]
00007895b19d4a4d  vmovaps xmm2, [rsp+0x20]
00007895b19d4a53  vmovaps xmm3, [rsp+0x30]
00007895b19d4a59  vmovaps xmm4, [rsp+0x40]
00007895b19d4a5f  vmovaps xmm5, [rsp+0x50]
00007895b19d4a65  vmovaps xmm6, [rsp+0x60]
00007895b19d4a6b  vmovaps xmm7, [rsp+0x70]
00007895b19d4a71  vmovaps xmm8, [rsp+0x80]
00007895b19d4a7a  vmovaps xmm9, [rsp+0x90]
00007895b19d4a83  vmovaps xmm10, [rsp+0xA0]
00007895b19d4a8c  vmovaps xmm11, [rsp+0xB0]
00007895b19d4a95  vmovaps xmm12, [rsp+0xC0]
00007895b19d4a9e  vmovaps xmm13, [rsp+0xD0]
00007895b19d4aa7  vmovaps xmm14, [rsp+0xE0]
00007895b19d4ab0  add rsp, 0xF0
00007895b19d4ab7  pop r11
00007895b19d4ab9  pop r10
00007895b19d4abb  pop r9
00007895b19d4abd  pop r8
00007895b19d4abf  pop rsi
00007895b19d4ac0  pop rdi
00007895b19d4ac1  pop rdx
00007895b19d4ac2  pop rcx
00007895b19d4ac3  pop rax
00007895b19d4ac4  add rsp, 0x08
00007895b19d4ac8  jmp 0x00007895B19D3678
00007895b19d4acd  sub rsp, 0x08
00007895b19d4ad1  push rax
00007895b19d4ad2  push rcx
00007895b19d4ad3  push rdx
00007895b19d4ad4  push rdi
00007895b19d4ad5  push rsi
00007895b19d4ad6  push r8
00007895b19d4ad8  push r9
00007895b19d4ada  push r10
00007895b19d4adc  push r11
00007895b19d4ade  sub rsp, 0xF0
00007895b19d4ae5  vmovaps [rsp], xmm0
00007895b19d4aea  vmovaps [rsp+0x10], xmm1
00007895b19d4af0  vmovaps [rsp+0x20], xmm2
00007895b19d4af6  vmovaps [rsp+0x30], xmm3
00007895b19d4afc  vmovaps [rsp+0x40], xmm4
00007895b19d4b02  vmovaps [rsp+0x50], xmm5
00007895b19d4b08  vmovaps [rsp+0x60], xmm6
00007895b19d4b0e  vmovaps [rsp+0x70], xmm7
00007895b19d4b14  vmovaps [rsp+0x80], xmm8
00007895b19d4b1d  vmovaps [rsp+0x90], xmm9
00007895b19d4b26  vmovaps [rsp+0xA0], xmm10
00007895b19d4b2f  vmovaps [rsp+0xB0], xmm11
00007895b19d4b38  vmovaps [rsp+0xC0], xmm12
00007895b19d4b41  vmovaps [rsp+0xD0], xmm14
00007895b19d4b4a  vmovaps [rsp+0xE0], xmm15
00007895b19d4b53  sub rsp, 0x40
00007895b19d4b57  lea rdi, [rsp]
00007895b19d4b5b  lea rsi, [rsp+0x10]
00007895b19d4b60  lea rdx, [rsp+0x20]
00007895b19d4b65  lea rcx, [rsp+0x30]
00007895b19d4b6a  mov r8d, 0x00
00007895b19d4b70  lea r9, [r15+0x3A8]
00007895b19d4b77  movaps [rdi], xmm13
00007895b19d4b7b  movaps [rsi], xmm12
00007895b19d4b7f  movaps [rdx], xmm14
00007895b19d4b83  movaps [rcx], xmm1
00007895b19d4b86  mov rax, 0x59D4522A9A50
00007895b19d4b90  call rax
00007895b19d4b92  movaps xmm13, [rsp]
00007895b19d4b97  add rsp, 0x40
00007895b19d4b9b  vmovaps xmm0, [rsp]
00007895b19d4ba0  vmovaps xmm1, [rsp+0x10]
00007895b19d4ba6  vmovaps xmm2, [rsp+0x20]
00007895b19d4bac  vmovaps xmm3, [rsp+0x30]
00007895b19d4bb2  vmovaps xmm4, [rsp+0x40]
00007895b19d4bb8  vmovaps xmm5, [rsp+0x50]
00007895b19d4bbe  vmovaps xmm6, [rsp+0x60]
00007895b19d4bc4  vmovaps xmm7, [rsp+0x70]
00007895b19d4bca  vmovaps xmm8, [rsp+0x80]
00007895b19d4bd3  vmovaps xmm9, [rsp+0x90]
00007895b19d4bdc  vmovaps xmm10, [rsp+0xA0]
00007895b19d4be5  vmovaps xmm11, [rsp+0xB0]
00007895b19d4bee  vmovaps xmm12, [rsp+0xC0]
00007895b19d4bf7  vmovaps xmm14, [rsp+0xD0]
00007895b19d4c00  vmovaps xmm15, [rsp+0xE0]
00007895b19d4c09  add rsp, 0xF0
00007895b19d4c10  pop r11
00007895b19d4c12  pop r10
00007895b19d4c14  pop r9
00007895b19d4c16  pop r8
00007895b19d4c18  pop rsi
00007895b19d4c19  pop rdi
00007895b19d4c1a  pop rdx
00007895b19d4c1b  pop rcx
00007895b19d4c1c  pop rax
00007895b19d4c1d  add rsp, 0x08
00007895b19d4c21  jmp 0x00007895B19D36AA
00007895b19d4c26  sub rsp, 0x08
00007895b19d4c2a  push rax
00007895b19d4c2b  push rcx
00007895b19d4c2c  push rdx
00007895b19d4c2d  push rdi
00007895b19d4c2e  push rsi
00007895b19d4c2f  push r8
00007895b19d4c31  push r9
00007895b19d4c33  push r10
00007895b19d4c35  push r11
00007895b19d4c37  sub rsp, 0xF0
00007895b19d4c3e  vmovaps [rsp], xmm0
00007895b19d4c43  vmovaps [rsp+0x10], xmm1
00007895b19d4c49  vmovaps [rsp+0x20], xmm2
00007895b19d4c4f  vmovaps [rsp+0x30], xmm3
00007895b19d4c55  vmovaps [rsp+0x40], xmm4
00007895b19d4c5b  vmovaps [rsp+0x50], xmm5
00007895b19d4c61  vmovaps [rsp+0x60], xmm6
00007895b19d4c67  vmovaps [rsp+0x70], xmm7
00007895b19d4c6d  vmovaps [rsp+0x80], xmm8
00007895b19d4c76  vmovaps [rsp+0x90], xmm9
00007895b19d4c7f  vmovaps [rsp+0xA0], xmm10
00007895b19d4c88  vmovaps [rsp+0xB0], xmm11
00007895b19d4c91  vmovaps [rsp+0xC0], xmm13
00007895b19d4c9a  vmovaps [rsp+0xD0], xmm14
00007895b19d4ca3  vmovaps [rsp+0xE0], xmm15
00007895b19d4cac  sub rsp, 0x40
00007895b19d4cb0  lea rdi, [rsp]
00007895b19d4cb4  lea rsi, [rsp+0x10]
00007895b19d4cb9  lea rdx, [rsp+0x20]
00007895b19d4cbe  lea rcx, [rsp+0x30]
00007895b19d4cc3  mov r8d, 0x00
00007895b19d4cc9  lea r9, [r15+0x3A8]
00007895b19d4cd0  movaps [rdi], xmm12
00007895b19d4cd4  movaps [rsi], xmm5
00007895b19d4cd7  movaps [rdx], xmm14
00007895b19d4cdb  movaps [rcx], xmm4
00007895b19d4cde  mov rax, 0x59D4522A9A50
00007895b19d4ce8  call rax
00007895b19d4cea  movaps xmm12, [rsp]
00007895b19d4cef  add rsp, 0x40
00007895b19d4cf3  vmovaps xmm0, [rsp]
00007895b19d4cf8  vmovaps xmm1, [rsp+0x10]
00007895b19d4cfe  vmovaps xmm2, [rsp+0x20]
00007895b19d4d04  vmovaps xmm3, [rsp+0x30]
00007895b19d4d0a  vmovaps xmm4, [rsp+0x40]
00007895b19d4d10  vmovaps xmm5, [rsp+0x50]
00007895b19d4d16  vmovaps xmm6, [rsp+0x60]
00007895b19d4d1c  vmovaps xmm7, [rsp+0x70]
00007895b19d4d22  vmovaps xmm8, [rsp+0x80]
00007895b19d4d2b  vmovaps xmm9, [rsp+0x90]
00007895b19d4d34  vmovaps xmm10, [rsp+0xA0]
00007895b19d4d3d  vmovaps xmm11, [rsp+0xB0]
00007895b19d4d46  vmovaps xmm13, [rsp+0xC0]
00007895b19d4d4f  vmovaps xmm14, [rsp+0xD0]
00007895b19d4d58  vmovaps xmm15, [rsp+0xE0]
00007895b19d4d61  add rsp, 0xF0
00007895b19d4d68  pop r11
00007895b19d4d6a  pop r10
00007895b19d4d6c  pop r9
00007895b19d4d6e  pop r8
00007895b19d4d70  pop rsi
00007895b19d4d71  pop rdi
00007895b19d4d72  pop rdx
00007895b19d4d73  pop rcx
00007895b19d4d74  pop rax
00007895b19d4d75  add rsp, 0x08
00007895b19d4d79  jmp 0x00007895B19D3720
00007895b19d4d7e  sub rsp, 0x08
00007895b19d4d82  push rax
00007895b19d4d83  push rcx
00007895b19d4d84  push rdx
00007895b19d4d85  push rdi
00007895b19d4d86  push rsi
00007895b19d4d87  push r8
00007895b19d4d89  push r9
00007895b19d4d8b  push r10
00007895b19d4d8d  push r11
00007895b19d4d8f  sub rsp, 0xF0
00007895b19d4d96  vmovaps [rsp], xmm0
00007895b19d4d9b  vmovaps [rsp+0x10], xmm1
00007895b19d4da1  vmovaps [rsp+0x20], xmm2
00007895b19d4da7  vmovaps [rsp+0x30], xmm3
00007895b19d4dad  vmovaps [rsp+0x40], xmm4
00007895b19d4db3  vmovaps [rsp+0x50], xmm5
00007895b19d4db9  vmovaps [rsp+0x60], xmm6
00007895b19d4dbf  vmovaps [rsp+0x70], xmm7
00007895b19d4dc5  vmovaps [rsp+0x80], xmm8
00007895b19d4dce  vmovaps [rsp+0x90], xmm9
00007895b19d4dd7  vmovaps [rsp+0xA0], xmm11
00007895b19d4de0  vmovaps [rsp+0xB0], xmm12
00007895b19d4de9  vmovaps [rsp+0xC0], xmm13
00007895b19d4df2  vmovaps [rsp+0xD0], xmm14
00007895b19d4dfb  vmovaps [rsp+0xE0], xmm15
00007895b19d4e04  sub rsp, 0x40
00007895b19d4e08  lea rdi, [rsp]
00007895b19d4e0c  lea rsi, [rsp+0x10]
00007895b19d4e11  lea rdx, [rsp+0x20]
00007895b19d4e16  lea rcx, [rsp+0x30]
00007895b19d4e1b  mov r8d, 0x00
00007895b19d4e21  lea r9, [r15+0x3A8]
00007895b19d4e28  movaps [rdi], xmm10
00007895b19d4e2c  movaps [rsi], xmm2
00007895b19d4e2f  movaps [rdx], xmm6
00007895b19d4e32  movaps [rcx], xmm14
00007895b19d4e36  mov rax, 0x59D4522A9A50
00007895b19d4e40  call rax
00007895b19d4e42  movaps xmm10, [rsp]
00007895b19d4e47  add rsp, 0x40
00007895b19d4e4b  vmovaps xmm0, [rsp]
00007895b19d4e50  vmovaps xmm1, [rsp+0x10]
00007895b19d4e56  vmovaps xmm2, [rsp+0x20]
00007895b19d4e5c  vmovaps xmm3, [rsp+0x30]
00007895b19d4e62  vmovaps xmm4, [rsp+0x40]
00007895b19d4e68  vmovaps xmm5, [rsp+0x50]
00007895b19d4e6e  vmovaps xmm6, [rsp+0x60]
00007895b19d4e74  vmovaps xmm7, [rsp+0x70]
00007895b19d4e7a  vmovaps xmm8, [rsp+0x80]
00007895b19d4e83  vmovaps xmm9, [rsp+0x90]
00007895b19d4e8c  vmovaps xmm11, [rsp+0xA0]
00007895b19d4e95  vmovaps xmm12, [rsp+0xB0]
00007895b19d4e9e  vmovaps xmm13, [rsp+0xC0]
00007895b19d4ea7  vmovaps xmm14, [rsp+0xD0]
00007895b19d4eb0  vmovaps xmm15, [rsp+0xE0]
00007895b19d4eb9  add rsp, 0xF0
00007895b19d4ec0  pop r11
00007895b19d4ec2  pop r10
00007895b19d4ec4  pop r9
00007895b19d4ec6  pop r8
00007895b19d4ec8  pop rsi
00007895b19d4ec9  pop rdi
00007895b19d4eca  pop rdx
00007895b19d4ecb  pop rcx
00007895b19d4ecc  pop rax
00007895b19d4ecd  add rsp, 0x08
00007895b19d4ed1  jmp 0x00007895B19D3746
00007895b19d4ed6  call 0x00007895B18E45A0
00007895b19d4edb  jmp 0x00007895B19D3753
00007895b19d4ee0  sub rsp, 0x08
00007895b19d4ee4  push rax
00007895b19d4ee5  push rcx
00007895b19d4ee6  push rdx
00007895b19d4ee7  push rdi
00007895b19d4ee8  push rsi
00007895b19d4ee9  push r8
00007895b19d4eeb  push r9
00007895b19d4eed  push r10
00007895b19d4eef  push r11
00007895b19d4ef1  sub rsp, 0xF0
00007895b19d4ef8  vmovaps [rsp], xmm0
00007895b19d4efd  vmovaps [rsp+0x10], xmm1
00007895b19d4f03  vmovaps [rsp+0x20], xmm2
00007895b19d4f09  vmovaps [rsp+0x30], xmm3
00007895b19d4f0f  vmovaps [rsp+0x40], xmm4
00007895b19d4f15  vmovaps [rsp+0x50], xmm6
00007895b19d4f1b  vmovaps [rsp+0x60], xmm7
00007895b19d4f21  vmovaps [rsp+0x70], xmm8
00007895b19d4f27  vmovaps [rsp+0x80], xmm9
00007895b19d4f30  vmovaps [rsp+0x90], xmm10
00007895b19d4f39  vmovaps [rsp+0xA0], xmm11
00007895b19d4f42  vmovaps [rsp+0xB0], xmm12
00007895b19d4f4b  vmovaps [rsp+0xC0], xmm13
00007895b19d4f54  vmovaps [rsp+0xD0], xmm14
00007895b19d4f5d  vmovaps [rsp+0xE0], xmm15
00007895b19d4f66  sub rsp, 0x40
00007895b19d4f6a  lea rdi, [rsp]
00007895b19d4f6e  lea rsi, [rsp+0x10]
00007895b19d4f73  lea rdx, [rsp+0x20]
00007895b19d4f78  lea rcx, [rsp+0x30]
00007895b19d4f7d  mov r8d, 0x00
00007895b19d4f83  lea r9, [r15+0x3A8]
00007895b19d4f8a  movaps [rdi], xmm5
00007895b19d4f8d  movaps [rsi], xmm15
00007895b19d4f91  movaps [rdx], xmm6
00007895b19d4f94  movaps [rcx], xmm8
00007895b19d4f98  mov rax, 0x59D4522A9A50
00007895b19d4fa2  call rax
00007895b19d4fa4  movaps xmm5, [rsp]
00007895b19d4fa8  add rsp, 0x40
00007895b19d4fac  vmovaps xmm0, [rsp]
00007895b19d4fb1  vmovaps xmm1, [rsp+0x10]
00007895b19d4fb7  vmovaps xmm2, [rsp+0x20]
00007895b19d4fbd  vmovaps xmm3, [rsp+0x30]
00007895b19d4fc3  vmovaps xmm4, [rsp+0x40]
00007895b19d4fc9  vmovaps xmm6, [rsp+0x50]
00007895b19d4fcf  vmovaps xmm7, [rsp+0x60]
00007895b19d4fd5  vmovaps xmm8, [rsp+0x70]
00007895b19d4fdb  vmovaps xmm9, [rsp+0x80]
00007895b19d4fe4  vmovaps xmm10, [rsp+0x90]
00007895b19d4fed  vmovaps xmm11, [rsp+0xA0]
00007895b19d4ff6  vmovaps xmm12, [rsp+0xB0]
00007895b19d4fff  vmovaps xmm13, [rsp+0xC0]
00007895b19d5008  vmovaps xmm14, [rsp+0xD0]
00007895b19d5011  vmovaps xmm15, [rsp+0xE0]
00007895b19d501a  add rsp, 0xF0
00007895b19d5021  pop r11
00007895b19d5023  pop r10
00007895b19d5025  pop r9
00007895b19d5027  pop r8
00007895b19d5029  pop rsi
00007895b19d502a  pop rdi
00007895b19d502b  pop rdx
00007895b19d502c  pop rcx
00007895b19d502d  pop rax
00007895b19d502e  add rsp, 0x08
00007895b19d5032  jmp 0x00007895B19D3789
00007895b19d5037  sub rsp, 0x08
00007895b19d503b  push rax
00007895b19d503c  push rcx
00007895b19d503d  push rdx
00007895b19d503e  push rdi
00007895b19d503f  push rsi
00007895b19d5040  push r8
00007895b19d5042  push r9
00007895b19d5044  push r10
00007895b19d5046  push r11
00007895b19d5048  sub rsp, 0xF0
00007895b19d504f  vmovaps [rsp], xmm0
00007895b19d5054  vmovaps [rsp+0x10], xmm1
00007895b19d505a  vmovaps [rsp+0x20], xmm2
00007895b19d5060  vmovaps [rsp+0x30], xmm3
00007895b19d5066  vmovaps [rsp+0x40], xmm4
00007895b19d506c  vmovaps [rsp+0x50], xmm5
00007895b19d5072  vmovaps [rsp+0x60], xmm6
00007895b19d5078  vmovaps [rsp+0x70], xmm7
00007895b19d507e  vmovaps [rsp+0x80], xmm9
00007895b19d5087  vmovaps [rsp+0x90], xmm10
00007895b19d5090  vmovaps [rsp+0xA0], xmm11
00007895b19d5099  vmovaps [rsp+0xB0], xmm12
00007895b19d50a2  vmovaps [rsp+0xC0], xmm13
00007895b19d50ab  vmovaps [rsp+0xD0], xmm14
00007895b19d50b4  vmovaps [rsp+0xE0], xmm15
00007895b19d50bd  sub rsp, 0x40
00007895b19d50c1  lea rdi, [rsp]
00007895b19d50c5  lea rsi, [rsp+0x10]
00007895b19d50ca  lea rdx, [rsp+0x20]
00007895b19d50cf  lea rcx, [rsp+0x30]
00007895b19d50d4  mov r8d, 0x00
00007895b19d50da  lea r9, [r15+0x3A8]
00007895b19d50e1  movaps [rdi], xmm8
00007895b19d50e5  movaps [rsi], xmm13
00007895b19d50e9  movaps [rdx], xmm1
00007895b19d50ec  movaps [rcx], xmm15
00007895b19d50f0  mov rax, 0x59D4522A9A50
00007895b19d50fa  call rax
00007895b19d50fc  movaps xmm8, [rsp]
00007895b19d5101  add rsp, 0x40
00007895b19d5105  vmovaps xmm0, [rsp]
00007895b19d510a  vmovaps xmm1, [rsp+0x10]
00007895b19d5110  vmovaps xmm2, [rsp+0x20]
00007895b19d5116  vmovaps xmm3, [rsp+0x30]
00007895b19d511c  vmovaps xmm4, [rsp+0x40]
00007895b19d5122  vmovaps xmm5, [rsp+0x50]
00007895b19d5128  vmovaps xmm6, [rsp+0x60]
00007895b19d512e  vmovaps xmm7, [rsp+0x70]
00007895b19d5134  vmovaps xmm9, [rsp+0x80]
00007895b19d513d  vmovaps xmm10, [rsp+0x90]
00007895b19d5146  vmovaps xmm11, [rsp+0xA0]
00007895b19d514f  vmovaps xmm12, [rsp+0xB0]
00007895b19d5158  vmovaps xmm13, [rsp+0xC0]
00007895b19d5161  vmovaps xmm14, [rsp+0xD0]
00007895b19d516a  vmovaps xmm15, [rsp+0xE0]
00007895b19d5173  add rsp, 0xF0
00007895b19d517a  pop r11
00007895b19d517c  pop r10
00007895b19d517e  pop r9
00007895b19d5180  pop r8
00007895b19d5182  pop rsi
00007895b19d5183  pop rdi
00007895b19d5184  pop rdx
00007895b19d5185  pop rcx
00007895b19d5186  pop rax
00007895b19d5187  add rsp, 0x08
00007895b19d518b  jmp 0x00007895B19D37AF
00007895b19d5190  call 0x00007895B18E5820
00007895b19d5195  jmp 0x00007895B19D37D2
00007895b19d519a  call 0x00007895B18E3320
00007895b19d519f  jmp 0x00007895B19D37DC
00007895b19d51a4  sub rsp, 0x08
00007895b19d51a8  push rax
00007895b19d51a9  push rcx
00007895b19d51aa  push rdx
00007895b19d51ab  push rdi
00007895b19d51ac  push rsi
00007895b19d51ad  push r8
00007895b19d51af  push r9
00007895b19d51b1  push r10
00007895b19d51b3  push r11
00007895b19d51b5  sub rsp, 0xF0
00007895b19d51bc  vmovaps [rsp], xmm0
00007895b19d51c1  vmovaps [rsp+0x10], xmm1
00007895b19d51c7  vmovaps [rsp+0x20], xmm2
00007895b19d51cd  vmovaps [rsp+0x30], xmm3
00007895b19d51d3  vmovaps [rsp+0x40], xmm5
00007895b19d51d9  vmovaps [rsp+0x50], xmm6
00007895b19d51df  vmovaps [rsp+0x60], xmm7
00007895b19d51e5  vmovaps [rsp+0x70], xmm8
00007895b19d51eb  vmovaps [rsp+0x80], xmm9
00007895b19d51f4  vmovaps [rsp+0x90], xmm10
00007895b19d51fd  vmovaps [rsp+0xA0], xmm11
00007895b19d5206  vmovaps [rsp+0xB0], xmm12
00007895b19d520f  vmovaps [rsp+0xC0], xmm13
00007895b19d5218  vmovaps [rsp+0xD0], xmm14
00007895b19d5221  vmovaps [rsp+0xE0], xmm15
00007895b19d522a  sub rsp, 0x40
00007895b19d522e  lea rdi, [rsp]
00007895b19d5232  lea rsi, [rsp+0x10]
00007895b19d5237  lea rdx, [rsp+0x20]
00007895b19d523c  lea rcx, [rsp+0x30]
00007895b19d5241  mov r8d, 0x00
00007895b19d5247  lea r9, [r15+0x3A8]
00007895b19d524e  movaps [rdi], xmm4
00007895b19d5251  movaps [rsi], xmm12
00007895b19d5255  movaps [rdx], xmm9
00007895b19d5259  movaps [rcx], xmm6
00007895b19d525c  mov rax, 0x59D4522A9A50
00007895b19d5266  call rax
00007895b19d5268  movaps xmm4, [rsp]
00007895b19d526c  add rsp, 0x40
00007895b19d5270  vmovaps xmm0, [rsp]
00007895b19d5275  vmovaps xmm1, [rsp+0x10]
00007895b19d527b  vmovaps xmm2, [rsp+0x20]
00007895b19d5281  vmovaps xmm3, [rsp+0x30]
00007895b19d5287  vmovaps xmm5, [rsp+0x40]
00007895b19d528d  vmovaps xmm6, [rsp+0x50]
00007895b19d5293  vmovaps xmm7, [rsp+0x60]
00007895b19d5299  vmovaps xmm8, [rsp+0x70]
00007895b19d529f  vmovaps xmm9, [rsp+0x80]
00007895b19d52a8  vmovaps xmm10, [rsp+0x90]
00007895b19d52b1  vmovaps xmm11, [rsp+0xA0]
00007895b19d52ba  vmovaps xmm12, [rsp+0xB0]
00007895b19d52c3  vmovaps xmm13, [rsp+0xC0]
00007895b19d52cc  vmovaps xmm14, [rsp+0xD0]
00007895b19d52d5  vmovaps xmm15, [rsp+0xE0]
00007895b19d52de  add rsp, 0xF0
00007895b19d52e5  pop r11
00007895b19d52e7  pop r10
00007895b19d52e9  pop r9
00007895b19d52eb  pop r8
00007895b19d52ed  pop rsi
00007895b19d52ee  pop rdi
00007895b19d52ef  pop rdx
00007895b19d52f0  pop rcx
00007895b19d52f1  pop rax
00007895b19d52f2  add rsp, 0x08
00007895b19d52f6  jmp 0x00007895B19D3814
00007895b19d52fb  sub rsp, 0x08
00007895b19d52ff  push rax
00007895b19d5300  push rcx
00007895b19d5301  push rdx
00007895b19d5302  push rdi
00007895b19d5303  push rsi
00007895b19d5304  push r8
00007895b19d5306  push r9
00007895b19d5308  push r10
00007895b19d530a  push r11
00007895b19d530c  sub rsp, 0xF0
00007895b19d5313  vmovaps [rsp], xmm0
00007895b19d5318  vmovaps [rsp+0x10], xmm1
00007895b19d531e  vmovaps [rsp+0x20], xmm2
00007895b19d5324  vmovaps [rsp+0x30], xmm3
00007895b19d532a  vmovaps [rsp+0x40], xmm4
00007895b19d5330  vmovaps [rsp+0x50], xmm5
00007895b19d5336  vmovaps [rsp+0x60], xmm6
00007895b19d533c  vmovaps [rsp+0x70], xmm7
00007895b19d5342  vmovaps [rsp+0x80], xmm8
00007895b19d534b  vmovaps [rsp+0x90], xmm10
00007895b19d5354  vmovaps [rsp+0xA0], xmm11
00007895b19d535d  vmovaps [rsp+0xB0], xmm12
00007895b19d5366  vmovaps [rsp+0xC0], xmm13
00007895b19d536f  vmovaps [rsp+0xD0], xmm14
00007895b19d5378  vmovaps [rsp+0xE0], xmm15
00007895b19d5381  sub rsp, 0x40
00007895b19d5385  lea rdi, [rsp]
00007895b19d5389  lea rsi, [rsp+0x10]
00007895b19d538e  lea rdx, [rsp+0x20]
00007895b19d5393  lea rcx, [rsp+0x30]
00007895b19d5398  mov r8d, 0x00
00007895b19d539e  lea r9, [r15+0x3A8]
00007895b19d53a5  movaps [rdi], xmm9
00007895b19d53a9  movaps [rsi], xmm10
00007895b19d53ad  movaps [rdx], xmm1
00007895b19d53b0  movaps [rcx], xmm12
00007895b19d53b4  mov rax, 0x59D4522A9A50
00007895b19d53be  call rax
00007895b19d53c0  movaps xmm9, [rsp]
00007895b19d53c5  add rsp, 0x40
00007895b19d53c9  vmovaps xmm0, [rsp]
00007895b19d53ce  vmovaps xmm1, [rsp+0x10]
00007895b19d53d4  vmovaps xmm2, [rsp+0x20]
00007895b19d53da  vmovaps xmm3, [rsp+0x30]
00007895b19d53e0  vmovaps xmm4, [rsp+0x40]
00007895b19d53e6  vmovaps xmm5, [rsp+0x50]
00007895b19d53ec  vmovaps xmm6, [rsp+0x60]
00007895b19d53f2  vmovaps xmm7, [rsp+0x70]
00007895b19d53f8  vmovaps xmm8, [rsp+0x80]
00007895b19d5401  vmovaps xmm10, [rsp+0x90]
00007895b19d540a  vmovaps xmm11, [rsp+0xA0]
00007895b19d5413  vmovaps xmm12, [rsp+0xB0]
00007895b19d541c  vmovaps xmm13, [rsp+0xC0]
00007895b19d5425  vmovaps xmm14, [rsp+0xD0]
00007895b19d542e  vmovaps xmm15, [rsp+0xE0]
00007895b19d5437  add rsp, 0xF0
00007895b19d543e  pop r11
00007895b19d5440  pop r10
00007895b19d5442  pop r9
00007895b19d5444  pop r8
00007895b19d5446  pop rsi
00007895b19d5447  pop rdi
00007895b19d5448  pop rdx
00007895b19d5449  pop rcx
00007895b19d544a  pop rax
00007895b19d544b  add rsp, 0x08
00007895b19d544f  jmp 0x00007895B19D383D
00007895b19d5454  sub rsp, 0x08
00007895b19d5458  push rax
00007895b19d5459  push rcx
00007895b19d545a  push rdx
00007895b19d545b  push rdi
00007895b19d545c  push rsi
00007895b19d545d  push r8
00007895b19d545f  push r9
00007895b19d5461  push r10
00007895b19d5463  push r11
00007895b19d5465  sub rsp, 0xF0
00007895b19d546c  vmovaps [rsp], xmm0
00007895b19d5471  vmovaps [rsp+0x10], xmm1
00007895b19d5477  vmovaps [rsp+0x20], xmm2
00007895b19d547d  vmovaps [rsp+0x30], xmm3
00007895b19d5483  vmovaps [rsp+0x40], xmm4
00007895b19d5489  vmovaps [rsp+0x50], xmm5
00007895b19d548f  vmovaps [rsp+0x60], xmm6
00007895b19d5495  vmovaps [rsp+0x70], xmm7
00007895b19d549b  vmovaps [rsp+0x80], xmm8
00007895b19d54a4  vmovaps [rsp+0x90], xmm9
00007895b19d54ad  vmovaps [rsp+0xA0], xmm11
00007895b19d54b6  vmovaps [rsp+0xB0], xmm12
00007895b19d54bf  vmovaps [rsp+0xC0], xmm13
00007895b19d54c8  vmovaps [rsp+0xD0], xmm14
00007895b19d54d1  vmovaps [rsp+0xE0], xmm15
00007895b19d54da  sub rsp, 0x40
00007895b19d54de  lea rdi, [rsp]
00007895b19d54e2  lea rsi, [rsp+0x10]
00007895b19d54e7  lea rdx, [rsp+0x20]
00007895b19d54ec  lea rcx, [rsp+0x30]
00007895b19d54f1  mov r8d, 0x00
00007895b19d54f7  lea r9, [r15+0x3A8]
00007895b19d54fe  movaps [rdi], xmm10
00007895b19d5502  movaps [rsi], xmm5
00007895b19d5505  movaps [rdx], xmm12
00007895b19d5509  movaps [rcx], xmm1
00007895b19d550c  mov rax, 0x59D4522A9A50
00007895b19d5516  call rax
00007895b19d5518  movaps xmm10, [rsp]
00007895b19d551d  add rsp, 0x40
00007895b19d5521  vmovaps xmm0, [rsp]
00007895b19d5526  vmovaps xmm1, [rsp+0x10]
00007895b19d552c  vmovaps xmm2, [rsp+0x20]
00007895b19d5532  vmovaps xmm3, [rsp+0x30]
00007895b19d5538  vmovaps xmm4, [rsp+0x40]
00007895b19d553e  vmovaps xmm5, [rsp+0x50]
00007895b19d5544  vmovaps xmm6, [rsp+0x60]
00007895b19d554a  vmovaps xmm7, [rsp+0x70]
00007895b19d5550  vmovaps xmm8, [rsp+0x80]
00007895b19d5559  vmovaps xmm9, [rsp+0x90]
00007895b19d5562  vmovaps xmm11, [rsp+0xA0]
00007895b19d556b  vmovaps xmm12, [rsp+0xB0]
00007895b19d5574  vmovaps xmm13, [rsp+0xC0]
00007895b19d557d  vmovaps xmm14, [rsp+0xD0]
00007895b19d5586  vmovaps xmm15, [rsp+0xE0]
00007895b19d558f  add rsp, 0xF0
00007895b19d5596  pop r11
00007895b19d5598  pop r10
00007895b19d559a  pop r9
00007895b19d559c  pop r8
00007895b19d559e  pop rsi
00007895b19d559f  pop rdi
00007895b19d55a0  pop rdx
00007895b19d55a1  pop rcx
00007895b19d55a2  pop rax
00007895b19d55a3  add rsp, 0x08
00007895b19d55a7  jmp 0x00007895B19D386C
00007895b19d55ac  sub rsp, 0x08
00007895b19d55b0  push rax
00007895b19d55b1  push rcx
00007895b19d55b2  push rdx
00007895b19d55b3  push rdi
00007895b19d55b4  push rsi
00007895b19d55b5  push r8
00007895b19d55b7  push r9
00007895b19d55b9  push r10
00007895b19d55bb  push r11
00007895b19d55bd  sub rsp, 0xF0
00007895b19d55c4  vmovaps [rsp], xmm0
00007895b19d55c9  vmovaps [rsp+0x10], xmm1
00007895b19d55cf  vmovaps [rsp+0x20], xmm2
00007895b19d55d5  vmovaps [rsp+0x30], xmm3
00007895b19d55db  vmovaps [rsp+0x40], xmm4
00007895b19d55e1  vmovaps [rsp+0x50], xmm5
00007895b19d55e7  vmovaps [rsp+0x60], xmm7
00007895b19d55ed  vmovaps [rsp+0x70], xmm8
00007895b19d55f3  vmovaps [rsp+0x80], xmm9
00007895b19d55fc  vmovaps [rsp+0x90], xmm10
00007895b19d5605  vmovaps [rsp+0xA0], xmm11
00007895b19d560e  vmovaps [rsp+0xB0], xmm12
00007895b19d5617  vmovaps [rsp+0xC0], xmm13
00007895b19d5620  vmovaps [rsp+0xD0], xmm14
00007895b19d5629  vmovaps [rsp+0xE0], xmm15
00007895b19d5632  sub rsp, 0x40
00007895b19d5636  lea rdi, [rsp]
00007895b19d563a  lea rsi, [rsp+0x10]
00007895b19d563f  lea rdx, [rsp+0x20]
00007895b19d5644  lea rcx, [rsp+0x30]
00007895b19d5649  mov r8d, 0x00
00007895b19d564f  lea r9, [r15+0x3A8]
00007895b19d5656  movaps [rdi], xmm6
00007895b19d5659  movaps [rsi], xmm8
00007895b19d565d  movaps [rdx], xmm12
00007895b19d5661  movaps [rcx], xmm1
00007895b19d5664  mov rax, 0x59D4522A9A50
00007895b19d566e  call rax
00007895b19d5670  movaps xmm6, [rsp]
00007895b19d5674  add rsp, 0x40
00007895b19d5678  vmovaps xmm0, [rsp]
00007895b19d567d  vmovaps xmm1, [rsp+0x10]
00007895b19d5683  vmovaps xmm2, [rsp+0x20]
00007895b19d5689  vmovaps xmm3, [rsp+0x30]
00007895b19d568f  vmovaps xmm4, [rsp+0x40]
00007895b19d5695  vmovaps xmm5, [rsp+0x50]
00007895b19d569b  vmovaps xmm7, [rsp+0x60]
00007895b19d56a1  vmovaps xmm8, [rsp+0x70]
00007895b19d56a7  vmovaps xmm9, [rsp+0x80]
00007895b19d56b0  vmovaps xmm10, [rsp+0x90]
00007895b19d56b9  vmovaps xmm11, [rsp+0xA0]
00007895b19d56c2  vmovaps xmm12, [rsp+0xB0]
00007895b19d56cb  vmovaps xmm13, [rsp+0xC0]
00007895b19d56d4  vmovaps xmm14, [rsp+0xD0]
00007895b19d56dd  vmovaps xmm15, [rsp+0xE0]
00007895b19d56e6  add rsp, 0xF0
00007895b19d56ed  pop r11
00007895b19d56ef  pop r10
00007895b19d56f1  pop r9
00007895b19d56f3  pop r8
00007895b19d56f5  pop rsi
00007895b19d56f6  pop rdi
00007895b19d56f7  pop rdx
00007895b19d56f8  pop rcx
00007895b19d56f9  pop rax
00007895b19d56fa  add rsp, 0x08
00007895b19d56fe  jmp 0x00007895B19D389A
00007895b19d5703  call 0x00007895B18D64F0
00007895b19d5708  jmp 0x00007895B19D38A4
00007895b19d570d  call 0x00007895B18E20A0
00007895b19d5712  jmp 0x00007895B19D38AE
00007895b19d5717  sub rsp, 0x08
00007895b19d571b  push rax
00007895b19d571c  push rcx
00007895b19d571d  push rdx
00007895b19d571e  push rdi
00007895b19d571f  push rsi
00007895b19d5720  push r8
00007895b19d5722  push r9
00007895b19d5724  push r10
00007895b19d5726  push r11
00007895b19d5728  sub rsp, 0xF0
00007895b19d572f  vmovaps [rsp], xmm0
00007895b19d5734  vmovaps [rsp+0x10], xmm1
00007895b19d573a  vmovaps [rsp+0x20], xmm2
00007895b19d5740  vmovaps [rsp+0x30], xmm3
00007895b19d5746  vmovaps [rsp+0x40], xmm4
00007895b19d574c  vmovaps [rsp+0x50], xmm5
00007895b19d5752  vmovaps [rsp+0x60], xmm6
00007895b19d5758  vmovaps [rsp+0x70], xmm7
00007895b19d575e  vmovaps [rsp+0x80], xmm9
00007895b19d5767  vmovaps [rsp+0x90], xmm10
00007895b19d5770  vmovaps [rsp+0xA0], xmm11
00007895b19d5779  vmovaps [rsp+0xB0], xmm12
00007895b19d5782  vmovaps [rsp+0xC0], xmm13
00007895b19d578b  vmovaps [rsp+0xD0], xmm14
00007895b19d5794  vmovaps [rsp+0xE0], xmm15
00007895b19d579d  sub rsp, 0x40
00007895b19d57a1  lea rdi, [rsp]
00007895b19d57a5  lea rsi, [rsp+0x10]
00007895b19d57aa  lea rdx, [rsp+0x20]
00007895b19d57af  lea rcx, [rsp+0x30]
00007895b19d57b4  mov r8d, 0x00
00007895b19d57ba  lea r9, [r15+0x3A8]
00007895b19d57c1  movaps [rdi], xmm8
00007895b19d57c5  movaps [rsi], xmm4
00007895b19d57c8  movaps [rdx], xmm13
00007895b19d57cc  movaps [rcx], xmm11
00007895b19d57d0  mov rax, 0x59D4522A9A50
00007895b19d57da  call rax
00007895b19d57dc  movaps xmm8, [rsp]
00007895b19d57e1  add rsp, 0x40
00007895b19d57e5  vmovaps xmm0, [rsp]
00007895b19d57ea  vmovaps xmm1, [rsp+0x10]
00007895b19d57f0  vmovaps xmm2, [rsp+0x20]
00007895b19d57f6  vmovaps xmm3, [rsp+0x30]
00007895b19d57fc  vmovaps xmm4, [rsp+0x40]
00007895b19d5802  vmovaps xmm5, [rsp+0x50]
00007895b19d5808  vmovaps xmm6, [rsp+0x60]
00007895b19d580e  vmovaps xmm7, [rsp+0x70]
00007895b19d5814  vmovaps xmm9, [rsp+0x80]
00007895b19d581d  vmovaps xmm10, [rsp+0x90]
00007895b19d5826  vmovaps xmm11, [rsp+0xA0]
00007895b19d582f  vmovaps xmm12, [rsp+0xB0]
00007895b19d5838  vmovaps xmm13, [rsp+0xC0]
00007895b19d5841  vmovaps xmm14, [rsp+0xD0]
00007895b19d584a  vmovaps xmm15, [rsp+0xE0]
00007895b19d5853  add rsp, 0xF0
00007895b19d585a  pop r11
00007895b19d585c  pop r10
00007895b19d585e  pop r9
00007895b19d5860  pop r8
00007895b19d5862  pop rsi
00007895b19d5863  pop rdi
00007895b19d5864  pop rdx
00007895b19d5865  pop rcx
00007895b19d5866  pop rax
00007895b19d5867  add rsp, 0x08
00007895b19d586b  jmp 0x00007895B19D38E4
00007895b19d5870  sub rsp, 0x08
00007895b19d5874  push rax
00007895b19d5875  push rcx
00007895b19d5876  push rdx
00007895b19d5877  push rdi
00007895b19d5878  push rsi
00007895b19d5879  push r8
00007895b19d587b  push r9
00007895b19d587d  push r10
00007895b19d587f  push r11
00007895b19d5881  sub rsp, 0xF0
00007895b19d5888  vmovaps [rsp], xmm0
00007895b19d588d  vmovaps [rsp+0x10], xmm1
00007895b19d5893  vmovaps [rsp+0x20], xmm2
00007895b19d5899  vmovaps [rsp+0x30], xmm3
00007895b19d589f  vmovaps [rsp+0x40], xmm4
00007895b19d58a5  vmovaps [rsp+0x50], xmm5
00007895b19d58ab  vmovaps [rsp+0x60], xmm6
00007895b19d58b1  vmovaps [rsp+0x70], xmm7
00007895b19d58b7  vmovaps [rsp+0x80], xmm8
00007895b19d58c0  vmovaps [rsp+0x90], xmm9
00007895b19d58c9  vmovaps [rsp+0xA0], xmm10
00007895b19d58d2  vmovaps [rsp+0xB0], xmm12
00007895b19d58db  vmovaps [rsp+0xC0], xmm13
00007895b19d58e4  vmovaps [rsp+0xD0], xmm14
00007895b19d58ed  vmovaps [rsp+0xE0], xmm15
00007895b19d58f6  sub rsp, 0x40
00007895b19d58fa  lea rdi, [rsp]
00007895b19d58fe  lea rsi, [rsp+0x10]
00007895b19d5903  lea rdx, [rsp+0x20]
00007895b19d5908  lea rcx, [rsp+0x30]
00007895b19d590d  mov r8d, 0x00
00007895b19d5913  lea r9, [r15+0x3A8]
00007895b19d591a  movaps [rdi], xmm11
00007895b19d591e  movaps [rsi], xmm9
00007895b19d5922  movaps [rdx], xmm1
00007895b19d5925  movaps [rcx], xmm13
00007895b19d5929  mov rax, 0x59D4522A9A50
00007895b19d5933  call rax
00007895b19d5935  movaps xmm11, [rsp]
00007895b19d593a  add rsp, 0x40
00007895b19d593e  vmovaps xmm0, [rsp]
00007895b19d5943  vmovaps xmm1, [rsp+0x10]
00007895b19d5949  vmovaps xmm2, [rsp+0x20]
00007895b19d594f  vmovaps xmm3, [rsp+0x30]
00007895b19d5955  vmovaps xmm4, [rsp+0x40]
00007895b19d595b  vmovaps xmm5, [rsp+0x50]
00007895b19d5961  vmovaps xmm6, [rsp+0x60]
00007895b19d5967  vmovaps xmm7, [rsp+0x70]
00007895b19d596d  vmovaps xmm8, [rsp+0x80]
00007895b19d5976  vmovaps xmm9, [rsp+0x90]
00007895b19d597f  vmovaps xmm10, [rsp+0xA0]
00007895b19d5988  vmovaps xmm12, [rsp+0xB0]
00007895b19d5991  vmovaps xmm13, [rsp+0xC0]
00007895b19d599a  vmovaps xmm14, [rsp+0xD0]
00007895b19d59a3  vmovaps xmm15, [rsp+0xE0]
00007895b19d59ac  add rsp, 0xF0
00007895b19d59b3  pop r11
00007895b19d59b5  pop r10
00007895b19d59b7  pop r9
00007895b19d59b9  pop r8
00007895b19d59bb  pop rsi
00007895b19d59bc  pop rdi
00007895b19d59bd  pop rdx
00007895b19d59be  pop rcx
00007895b19d59bf  pop rax
00007895b19d59c0  add rsp, 0x08
00007895b19d59c4  jmp 0x00007895B19D390A
00007895b19d59c9  sub rsp, 0x08
00007895b19d59cd  push rax
00007895b19d59ce  push rcx
00007895b19d59cf  push rdx
00007895b19d59d0  push rdi
00007895b19d59d1  push rsi
00007895b19d59d2  push r8
00007895b19d59d4  push r9
00007895b19d59d6  push r10
00007895b19d59d8  push r11
00007895b19d59da  sub rsp, 0xF0
00007895b19d59e1  vmovaps [rsp], xmm0
00007895b19d59e6  vmovaps [rsp+0x10], xmm1
00007895b19d59ec  vmovaps [rsp+0x20], xmm2
00007895b19d59f2  vmovaps [rsp+0x30], xmm3
00007895b19d59f8  vmovaps [rsp+0x40], xmm4
00007895b19d59fe  vmovaps [rsp+0x50], xmm5
00007895b19d5a04  vmovaps [rsp+0x60], xmm6
00007895b19d5a0a  vmovaps [rsp+0x70], xmm7
00007895b19d5a10  vmovaps [rsp+0x80], xmm8
00007895b19d5a19  vmovaps [rsp+0x90], xmm9
00007895b19d5a22  vmovaps [rsp+0xA0], xmm10
00007895b19d5a2b  vmovaps [rsp+0xB0], xmm11
00007895b19d5a34  vmovaps [rsp+0xC0], xmm12
00007895b19d5a3d  vmovaps [rsp+0xD0], xmm14
00007895b19d5a46  vmovaps [rsp+0xE0], xmm15
00007895b19d5a4f  sub rsp, 0x40
00007895b19d5a53  lea rdi, [rsp]
00007895b19d5a57  lea rsi, [rsp+0x10]
00007895b19d5a5c  lea rdx, [rsp+0x20]
00007895b19d5a61  lea rcx, [rsp+0x30]
00007895b19d5a66  mov r8d, 0x00
00007895b19d5a6c  lea r9, [r15+0x3A8]
00007895b19d5a73  movaps [rdi], xmm13
00007895b19d5a77  movaps [rsi], xmm10
00007895b19d5a7b  movaps [rdx], xmm7
00007895b19d5a7e  movaps [rcx], xmm1
00007895b19d5a81  mov rax, 0x59D4522A9A50
00007895b19d5a8b  call rax
00007895b19d5a8d  movaps xmm13, [rsp]
00007895b19d5a92  add rsp, 0x40
00007895b19d5a96  vmovaps xmm0, [rsp]
00007895b19d5a9b  vmovaps xmm1, [rsp+0x10]
00007895b19d5aa1  vmovaps xmm2, [rsp+0x20]
00007895b19d5aa7  vmovaps xmm3, [rsp+0x30]
00007895b19d5aad  vmovaps xmm4, [rsp+0x40]
00007895b19d5ab3  vmovaps xmm5, [rsp+0x50]
00007895b19d5ab9  vmovaps xmm6, [rsp+0x60]
00007895b19d5abf  vmovaps xmm7, [rsp+0x70]
00007895b19d5ac5  vmovaps xmm8, [rsp+0x80]
00007895b19d5ace  vmovaps xmm9, [rsp+0x90]
00007895b19d5ad7  vmovaps xmm10, [rsp+0xA0]
00007895b19d5ae0  vmovaps xmm11, [rsp+0xB0]
00007895b19d5ae9  vmovaps xmm12, [rsp+0xC0]
00007895b19d5af2  vmovaps xmm14, [rsp+0xD0]
00007895b19d5afb  vmovaps xmm15, [rsp+0xE0]
00007895b19d5b04  add rsp, 0xF0
00007895b19d5b0b  pop r11
00007895b19d5b0d  pop r10
00007895b19d5b0f  pop r9
00007895b19d5b11  pop r8
00007895b19d5b13  pop rsi
00007895b19d5b14  pop rdi
00007895b19d5b15  pop rdx
00007895b19d5b16  pop rcx
00007895b19d5b17  pop rax
00007895b19d5b18  add rsp, 0x08
00007895b19d5b1c  jmp 0x00007895B19D3930
00007895b19d5b21  sub rsp, 0x08
00007895b19d5b25  push rax
00007895b19d5b26  push rcx
00007895b19d5b27  push rdx
00007895b19d5b28  push rdi
00007895b19d5b29  push rsi
00007895b19d5b2a  push r8
00007895b19d5b2c  push r9
00007895b19d5b2e  push r10
00007895b19d5b30  push r11
00007895b19d5b32  sub rsp, 0xF0
00007895b19d5b39  vmovaps [rsp], xmm0
00007895b19d5b3e  vmovaps [rsp+0x10], xmm1
00007895b19d5b44  vmovaps [rsp+0x20], xmm2
00007895b19d5b4a  vmovaps [rsp+0x30], xmm3
00007895b19d5b50  vmovaps [rsp+0x40], xmm4
00007895b19d5b56  vmovaps [rsp+0x50], xmm5
00007895b19d5b5c  vmovaps [rsp+0x60], xmm6
00007895b19d5b62  vmovaps [rsp+0x70], xmm7
00007895b19d5b68  vmovaps [rsp+0x80], xmm8
00007895b19d5b71  vmovaps [rsp+0x90], xmm9
00007895b19d5b7a  vmovaps [rsp+0xA0], xmm11
00007895b19d5b83  vmovaps [rsp+0xB0], xmm12
00007895b19d5b8c  vmovaps [rsp+0xC0], xmm13
00007895b19d5b95  vmovaps [rsp+0xD0], xmm14
00007895b19d5b9e  vmovaps [rsp+0xE0], xmm15
00007895b19d5ba7  sub rsp, 0x40
00007895b19d5bab  lea rdi, [rsp]
00007895b19d5baf  lea rsi, [rsp+0x10]
00007895b19d5bb4  lea rdx, [rsp+0x20]
00007895b19d5bb9  lea rcx, [rsp+0x30]
00007895b19d5bbe  mov r8d, 0x00
00007895b19d5bc4  lea r9, [r15+0x3A8]
00007895b19d5bcb  movaps [rdi], xmm10
00007895b19d5bcf  movaps [rsi], xmm6
00007895b19d5bd2  movaps [rdx], xmm15
00007895b19d5bd6  movaps [rcx], xmm1
00007895b19d5bd9  mov rax, 0x59D4522A9A50
00007895b19d5be3  call rax
00007895b19d5be5  movaps xmm10, [rsp]
00007895b19d5bea  add rsp, 0x40
00007895b19d5bee  vmovaps xmm0, [rsp]
00007895b19d5bf3  vmovaps xmm1, [rsp+0x10]
00007895b19d5bf9  vmovaps xmm2, [rsp+0x20]
00007895b19d5bff  vmovaps xmm3, [rsp+0x30]
00007895b19d5c05  vmovaps xmm4, [rsp+0x40]
00007895b19d5c0b  vmovaps xmm5, [rsp+0x50]
00007895b19d5c11  vmovaps xmm6, [rsp+0x60]
00007895b19d5c17  vmovaps xmm7, [rsp+0x70]
00007895b19d5c1d  vmovaps xmm8, [rsp+0x80]
00007895b19d5c26  vmovaps xmm9, [rsp+0x90]
00007895b19d5c2f  vmovaps xmm11, [rsp+0xA0]
00007895b19d5c38  vmovaps xmm12, [rsp+0xB0]
00007895b19d5c41  vmovaps xmm13, [rsp+0xC0]
00007895b19d5c4a  vmovaps xmm14, [rsp+0xD0]
00007895b19d5c53  vmovaps xmm15, [rsp+0xE0]
00007895b19d5c5c  add rsp, 0xF0
00007895b19d5c63  pop r11
00007895b19d5c65  pop r10
00007895b19d5c67  pop r9
00007895b19d5c69  pop r8
00007895b19d5c6b  pop rsi
00007895b19d5c6c  pop rdi
00007895b19d5c6d  pop rdx
00007895b19d5c6e  pop rcx
00007895b19d5c6f  pop rax
00007895b19d5c70  add rsp, 0x08
00007895b19d5c74  jmp 0x00007895B19D3956
00007895b19d5c79  call 0x00007895B18D64F0
00007895b19d5c7e  jmp 0x00007895B19D3960
00007895b19d5c83  call 0x00007895B18E5820
00007895b19d5c88  jmp 0x00007895B19D396A
00007895b19d5c8d  sub rsp, 0x08
00007895b19d5c91  push rax
00007895b19d5c92  push rcx
00007895b19d5c93  push rdx
00007895b19d5c94  push rdi
00007895b19d5c95  push rsi
00007895b19d5c96  push r8
00007895b19d5c98  push r9
00007895b19d5c9a  push r10
00007895b19d5c9c  push r11
00007895b19d5c9e  sub rsp, 0xF0
00007895b19d5ca5  vmovaps [rsp], xmm0
00007895b19d5caa  vmovaps [rsp+0x10], xmm1
00007895b19d5cb0  vmovaps [rsp+0x20], xmm2
00007895b19d5cb6  vmovaps [rsp+0x30], xmm3
00007895b19d5cbc  vmovaps [rsp+0x40], xmm4
00007895b19d5cc2  vmovaps [rsp+0x50], xmm5
00007895b19d5cc8  vmovaps [rsp+0x60], xmm6
00007895b19d5cce  vmovaps [rsp+0x70], xmm8
00007895b19d5cd4  vmovaps [rsp+0x80], xmm9
00007895b19d5cdd  vmovaps [rsp+0x90], xmm10
00007895b19d5ce6  vmovaps [rsp+0xA0], xmm11
00007895b19d5cef  vmovaps [rsp+0xB0], xmm12
00007895b19d5cf8  vmovaps [rsp+0xC0], xmm13
00007895b19d5d01  vmovaps [rsp+0xD0], xmm14
00007895b19d5d0a  vmovaps [rsp+0xE0], xmm15
00007895b19d5d13  sub rsp, 0x40
00007895b19d5d17  lea rdi, [rsp]
00007895b19d5d1b  lea rsi, [rsp+0x10]
00007895b19d5d20  lea rdx, [rsp+0x20]
00007895b19d5d25  lea rcx, [rsp+0x30]
00007895b19d5d2a  mov r8d, 0x00
00007895b19d5d30  lea r9, [r15+0x3A8]
00007895b19d5d37  movaps [rdi], xmm7
00007895b19d5d3a  movaps [rsi], xmm8
00007895b19d5d3e  movaps [rdx], xmm3
00007895b19d5d41  movaps [rcx], xmm9
00007895b19d5d45  mov rax, 0x59D4522A9A50
00007895b19d5d4f  call rax
00007895b19d5d51  movaps xmm7, [rsp]
00007895b19d5d55  add rsp, 0x40
00007895b19d5d59  vmovaps xmm0, [rsp]
00007895b19d5d5e  vmovaps xmm1, [rsp+0x10]
00007895b19d5d64  vmovaps xmm2, [rsp+0x20]
00007895b19d5d6a  vmovaps xmm3, [rsp+0x30]
00007895b19d5d70  vmovaps xmm4, [rsp+0x40]
00007895b19d5d76  vmovaps xmm5, [rsp+0x50]
00007895b19d5d7c  vmovaps xmm6, [rsp+0x60]
00007895b19d5d82  vmovaps xmm8, [rsp+0x70]
00007895b19d5d88  vmovaps xmm9, [rsp+0x80]
00007895b19d5d91  vmovaps xmm10, [rsp+0x90]
00007895b19d5d9a  vmovaps xmm11, [rsp+0xA0]
00007895b19d5da3  vmovaps xmm12, [rsp+0xB0]
00007895b19d5dac  vmovaps xmm13, [rsp+0xC0]
00007895b19d5db5  vmovaps xmm14, [rsp+0xD0]
00007895b19d5dbe  vmovaps xmm15, [rsp+0xE0]
00007895b19d5dc7  add rsp, 0xF0
00007895b19d5dce  pop r11
00007895b19d5dd0  pop r10
00007895b19d5dd2  pop r9
00007895b19d5dd4  pop r8
00007895b19d5dd6  pop rsi
00007895b19d5dd7  pop rdi
00007895b19d5dd8  pop rdx
00007895b19d5dd9  pop rcx
00007895b19d5dda  pop rax
00007895b19d5ddb  add rsp, 0x08
00007895b19d5ddf  jmp 0x00007895B19D3992
00007895b19d5de4  sub rsp, 0x08
00007895b19d5de8  push rax
00007895b19d5de9  push rcx
00007895b19d5dea  push rdx
00007895b19d5deb  push rdi
00007895b19d5dec  push rsi
00007895b19d5ded  push r8
00007895b19d5def  push r9
00007895b19d5df1  push r10
00007895b19d5df3  push r11
00007895b19d5df5  sub rsp, 0xF0
00007895b19d5dfc  vmovaps [rsp], xmm0
00007895b19d5e01  vmovaps [rsp+0x10], xmm1
00007895b19d5e07  vmovaps [rsp+0x20], xmm2
00007895b19d5e0d  vmovaps [rsp+0x30], xmm3
00007895b19d5e13  vmovaps [rsp+0x40], xmm4
00007895b19d5e19  vmovaps [rsp+0x50], xmm5
00007895b19d5e1f  vmovaps [rsp+0x60], xmm6
00007895b19d5e25  vmovaps [rsp+0x70], xmm7
00007895b19d5e2b  vmovaps [rsp+0x80], xmm9
00007895b19d5e34  vmovaps [rsp+0x90], xmm10
00007895b19d5e3d  vmovaps [rsp+0xA0], xmm11
00007895b19d5e46  vmovaps [rsp+0xB0], xmm12
00007895b19d5e4f  vmovaps [rsp+0xC0], xmm13
00007895b19d5e58  vmovaps [rsp+0xD0], xmm14
00007895b19d5e61  vmovaps [rsp+0xE0], xmm15
00007895b19d5e6a  sub rsp, 0x40
00007895b19d5e6e  lea rdi, [rsp]
00007895b19d5e72  lea rsi, [rsp+0x10]
00007895b19d5e77  lea rdx, [rsp+0x20]
00007895b19d5e7c  lea rcx, [rsp+0x30]
00007895b19d5e81  mov r8d, 0x00
00007895b19d5e87  lea r9, [r15+0x3A8]
00007895b19d5e8e  movaps [rdi], xmm8
00007895b19d5e92  movaps [rsi], xmm11
00007895b19d5e96  movaps [rdx], xmm14
00007895b19d5e9a  movaps [rcx], xmm9
00007895b19d5e9e  mov rax, 0x59D4522A9A50
00007895b19d5ea8  call rax
00007895b19d5eaa  movaps xmm8, [rsp]
00007895b19d5eaf  add rsp, 0x40
00007895b19d5eb3  vmovaps xmm0, [rsp]
00007895b19d5eb8  vmovaps xmm1, [rsp+0x10]
00007895b19d5ebe  vmovaps xmm2, [rsp+0x20]
00007895b19d5ec4  vmovaps xmm3, [rsp+0x30]
00007895b19d5eca  vmovaps xmm4, [rsp+0x40]
00007895b19d5ed0  vmovaps xmm5, [rsp+0x50]
00007895b19d5ed6  vmovaps xmm6, [rsp+0x60]
00007895b19d5edc  vmovaps xmm7, [rsp+0x70]
00007895b19d5ee2  vmovaps xmm9, [rsp+0x80]
00007895b19d5eeb  vmovaps xmm10, [rsp+0x90]
00007895b19d5ef4  vmovaps xmm11, [rsp+0xA0]
00007895b19d5efd  vmovaps xmm12, [rsp+0xB0]
00007895b19d5f06  vmovaps xmm13, [rsp+0xC0]
00007895b19d5f0f  vmovaps xmm14, [rsp+0xD0]
00007895b19d5f18  vmovaps xmm15, [rsp+0xE0]
00007895b19d5f21  add rsp, 0xF0
00007895b19d5f28  pop r11
00007895b19d5f2a  pop r10
00007895b19d5f2c  pop r9
00007895b19d5f2e  pop r8
00007895b19d5f30  pop rsi
00007895b19d5f31  pop rdi
00007895b19d5f32  pop rdx
00007895b19d5f33  pop rcx
00007895b19d5f34  pop rax
00007895b19d5f35  add rsp, 0x08
00007895b19d5f39  jmp 0x00007895B19D39BB
00007895b19d5f3e  sub rsp, 0x08
00007895b19d5f42  push rax
00007895b19d5f43  push rcx
00007895b19d5f44  push rdx
00007895b19d5f45  push rdi
00007895b19d5f46  push rsi
00007895b19d5f47  push r8
00007895b19d5f49  push r9
00007895b19d5f4b  push r10
00007895b19d5f4d  push r11
00007895b19d5f4f  sub rsp, 0xF0
00007895b19d5f56  vmovaps [rsp], xmm0
00007895b19d5f5b  vmovaps [rsp+0x10], xmm1
00007895b19d5f61  vmovaps [rsp+0x20], xmm2
00007895b19d5f67  vmovaps [rsp+0x30], xmm3
00007895b19d5f6d  vmovaps [rsp+0x40], xmm4
00007895b19d5f73  vmovaps [rsp+0x50], xmm5
00007895b19d5f79  vmovaps [rsp+0x60], xmm6
00007895b19d5f7f  vmovaps [rsp+0x70], xmm7
00007895b19d5f85  vmovaps [rsp+0x80], xmm8
00007895b19d5f8e  vmovaps [rsp+0x90], xmm9
00007895b19d5f97  vmovaps [rsp+0xA0], xmm10
00007895b19d5fa0  vmovaps [rsp+0xB0], xmm12
00007895b19d5fa9  vmovaps [rsp+0xC0], xmm13
00007895b19d5fb2  vmovaps [rsp+0xD0], xmm14
00007895b19d5fbb  vmovaps [rsp+0xE0], xmm15
00007895b19d5fc4  sub rsp, 0x40
00007895b19d5fc8  lea rdi, [rsp]
00007895b19d5fcc  lea rsi, [rsp+0x10]
00007895b19d5fd1  lea rdx, [rsp+0x20]
00007895b19d5fd6  lea rcx, [rsp+0x30]
00007895b19d5fdb  mov r8d, 0x00
00007895b19d5fe1  lea r9, [r15+0x3A8]
00007895b19d5fe8  movaps [rdi], xmm11
00007895b19d5fec  movaps [rsi], xmm13
00007895b19d5ff0  movaps [rdx], xmm12
00007895b19d5ff4  movaps [rcx], xmm14
00007895b19d5ff8  mov rax, 0x59D4522A9A50
00007895b19d6002  call rax
00007895b19d6004  movaps xmm11, [rsp]
00007895b19d6009  add rsp, 0x40
00007895b19d600d  vmovaps xmm0, [rsp]
00007895b19d6012  vmovaps xmm1, [rsp+0x10]
00007895b19d6018  vmovaps xmm2, [rsp+0x20]
00007895b19d601e  vmovaps xmm3, [rsp+0x30]
00007895b19d6024  vmovaps xmm4, [rsp+0x40]
00007895b19d602a  vmovaps xmm5, [rsp+0x50]
00007895b19d6030  vmovaps xmm6, [rsp+0x60]
00007895b19d6036  vmovaps xmm7, [rsp+0x70]
00007895b19d603c  vmovaps xmm8, [rsp+0x80]
00007895b19d6045  vmovaps xmm9, [rsp+0x90]
00007895b19d604e  vmovaps xmm10, [rsp+0xA0]
00007895b19d6057  vmovaps xmm12, [rsp+0xB0]
00007895b19d6060  vmovaps xmm13, [rsp+0xC0]
00007895b19d6069  vmovaps xmm14, [rsp+0xD0]
00007895b19d6072  vmovaps xmm15, [rsp+0xE0]
00007895b19d607b  add rsp, 0xF0
00007895b19d6082  pop r11
00007895b19d6084  pop r10
00007895b19d6086  pop r9
00007895b19d6088  pop r8
00007895b19d608a  pop rsi
00007895b19d608b  pop rdi
00007895b19d608c  pop rdx
00007895b19d608d  pop rcx
00007895b19d608e  pop rax
00007895b19d608f  add rsp, 0x08
00007895b19d6093  jmp 0x00007895B19D39E4
00007895b19d6098  sub rsp, 0x08
00007895b19d609c  push rax
00007895b19d609d  push rcx
00007895b19d609e  push rdx
00007895b19d609f  push rdi
00007895b19d60a0  push rsi
00007895b19d60a1  push r8
00007895b19d60a3  push r9
00007895b19d60a5  push r10
00007895b19d60a7  push r11
00007895b19d60a9  sub rsp, 0xF0
00007895b19d60b0  vmovaps [rsp], xmm0
00007895b19d60b5  vmovaps [rsp+0x10], xmm1
00007895b19d60bb  vmovaps [rsp+0x20], xmm2
00007895b19d60c1  vmovaps [rsp+0x30], xmm3
00007895b19d60c7  vmovaps [rsp+0x40], xmm4
00007895b19d60cd  vmovaps [rsp+0x50], xmm5
00007895b19d60d3  vmovaps [rsp+0x60], xmm6
00007895b19d60d9  vmovaps [rsp+0x70], xmm7
00007895b19d60df  vmovaps [rsp+0x80], xmm8
00007895b19d60e8  vmovaps [rsp+0x90], xmm9
00007895b19d60f1  vmovaps [rsp+0xA0], xmm10
00007895b19d60fa  vmovaps [rsp+0xB0], xmm11
00007895b19d6103  vmovaps [rsp+0xC0], xmm13
00007895b19d610c  vmovaps [rsp+0xD0], xmm14
00007895b19d6115  vmovaps [rsp+0xE0], xmm15
00007895b19d611e  sub rsp, 0x40
00007895b19d6122  lea rdi, [rsp]
00007895b19d6126  lea rsi, [rsp+0x10]
00007895b19d612b  lea rdx, [rsp+0x20]
00007895b19d6130  lea rcx, [rsp+0x30]
00007895b19d6135  mov r8d, 0x00
00007895b19d613b  lea r9, [r15+0x3A8]
00007895b19d6142  movaps [rdi], xmm12
00007895b19d6146  movaps [rsi], xmm10
00007895b19d614a  movaps [rdx], xmm15
00007895b19d614e  movaps [rcx], xmm14
00007895b19d6152  mov rax, 0x59D4522A9A50
00007895b19d615c  call rax
00007895b19d615e  movaps xmm12, [rsp]
00007895b19d6163  add rsp, 0x40
00007895b19d6167  vmovaps xmm0, [rsp]
00007895b19d616c  vmovaps xmm1, [rsp+0x10]
00007895b19d6172  vmovaps xmm2, [rsp+0x20]
00007895b19d6178  vmovaps xmm3, [rsp+0x30]
00007895b19d617e  vmovaps xmm4, [rsp+0x40]
00007895b19d6184  vmovaps xmm5, [rsp+0x50]
00007895b19d618a  vmovaps xmm6, [rsp+0x60]
00007895b19d6190  vmovaps xmm7, [rsp+0x70]
00007895b19d6196  vmovaps xmm8, [rsp+0x80]
00007895b19d619f  vmovaps xmm9, [rsp+0x90]
00007895b19d61a8  vmovaps xmm10, [rsp+0xA0]
00007895b19d61b1  vmovaps xmm11, [rsp+0xB0]
00007895b19d61ba  vmovaps xmm13, [rsp+0xC0]
00007895b19d61c3  vmovaps xmm14, [rsp+0xD0]
00007895b19d61cc  vmovaps xmm15, [rsp+0xE0]
00007895b19d61d5  add rsp, 0xF0
00007895b19d61dc  pop r11
00007895b19d61de  pop r10
00007895b19d61e0  pop r9
00007895b19d61e2  pop r8
00007895b19d61e4  pop rsi
00007895b19d61e5  pop rdi
00007895b19d61e6  pop rdx
00007895b19d61e7  pop rcx
00007895b19d61e8  pop rax
00007895b19d61e9  add rsp, 0x08
00007895b19d61ed  jmp 0x00007895B19D3A0D
00007895b19d61f2  call 0x00007895B18E5820
00007895b19d61f7  jmp 0x00007895B19D3A1A
00007895b19d61fc  call 0x00007895B18E45A0
00007895b19d6201  jmp 0x00007895B19D3A27
00007895b19d6206  sub rsp, 0x08
00007895b19d620a  push rax
00007895b19d620b  push rcx
00007895b19d620c  push rdx
00007895b19d620d  push rdi
00007895b19d620e  push rsi
00007895b19d620f  push r8
00007895b19d6211  push r9
00007895b19d6213  push r10
00007895b19d6215  push r11
00007895b19d6217  sub rsp, 0xF0
00007895b19d621e  vmovaps [rsp], xmm0
00007895b19d6223  vmovaps [rsp+0x10], xmm1
00007895b19d6229  vmovaps [rsp+0x20], xmm2
00007895b19d622f  vmovaps [rsp+0x30], xmm3
00007895b19d6235  vmovaps [rsp+0x40], xmm4
00007895b19d623b  vmovaps [rsp+0x50], xmm5
00007895b19d6241  vmovaps [rsp+0x60], xmm6
00007895b19d6247  vmovaps [rsp+0x70], xmm7
00007895b19d624d  vmovaps [rsp+0x80], xmm8
00007895b19d6256  vmovaps [rsp+0x90], xmm9
00007895b19d625f  vmovaps [rsp+0xA0], xmm11
00007895b19d6268  vmovaps [rsp+0xB0], xmm12
00007895b19d6271  vmovaps [rsp+0xC0], xmm13
00007895b19d627a  vmovaps [rsp+0xD0], xmm14
00007895b19d6283  vmovaps [rsp+0xE0], xmm15
00007895b19d628c  sub rsp, 0x40
00007895b19d6290  lea rdi, [rsp]
00007895b19d6294  lea rsi, [rsp+0x10]
00007895b19d6299  lea rdx, [rsp+0x20]
00007895b19d629e  lea rcx, [rsp+0x30]
00007895b19d62a3  mov r8d, 0x00
00007895b19d62a9  lea r9, [r15+0x3A8]
00007895b19d62b0  movaps [rdi], xmm10
00007895b19d62b4  movaps [rsi], xmm7
00007895b19d62b7  movaps [rdx], xmm1
00007895b19d62ba  movaps [rcx], xmm13
00007895b19d62be  mov rax, 0x59D4522A9A50
00007895b19d62c8  call rax
00007895b19d62ca  movaps xmm10, [rsp]
00007895b19d62cf  add rsp, 0x40
00007895b19d62d3  vmovaps xmm0, [rsp]
00007895b19d62d8  vmovaps xmm1, [rsp+0x10]
00007895b19d62de  vmovaps xmm2, [rsp+0x20]
00007895b19d62e4  vmovaps xmm3, [rsp+0x30]
00007895b19d62ea  vmovaps xmm4, [rsp+0x40]
00007895b19d62f0  vmovaps xmm5, [rsp+0x50]
00007895b19d62f6  vmovaps xmm6, [rsp+0x60]
00007895b19d62fc  vmovaps xmm7, [rsp+0x70]
00007895b19d6302  vmovaps xmm8, [rsp+0x80]
00007895b19d630b  vmovaps xmm9, [rsp+0x90]
00007895b19d6314  vmovaps xmm11, [rsp+0xA0]
00007895b19d631d  vmovaps xmm12, [rsp+0xB0]
00007895b19d6326  vmovaps xmm13, [rsp+0xC0]
00007895b19d632f  vmovaps xmm14, [rsp+0xD0]
00007895b19d6338  vmovaps xmm15, [rsp+0xE0]
00007895b19d6341  add rsp, 0xF0
00007895b19d6348  pop r11
00007895b19d634a  pop r10
00007895b19d634c  pop r9
00007895b19d634e  pop r8
00007895b19d6350  pop rsi
00007895b19d6351  pop rdi
00007895b19d6352  pop rdx
00007895b19d6353  pop rcx
00007895b19d6354  pop rax
00007895b19d6355  add rsp, 0x08
00007895b19d6359  jmp 0x00007895B19D3A5D
00007895b19d635e  call 0x00007895B18D64F0
00007895b19d6363  jmp 0x00007895B19D3A6F
00007895b19d6368  sub rsp, 0x08
00007895b19d636c  push rax
00007895b19d636d  push rcx
00007895b19d636e  push rdx
00007895b19d636f  push rdi
00007895b19d6370  push rsi
00007895b19d6371  push r8
00007895b19d6373  push r9
00007895b19d6375  push r10
00007895b19d6377  push r11
00007895b19d6379  sub rsp, 0xF0
00007895b19d6380  vmovaps [rsp], xmm0
00007895b19d6385  vmovaps [rsp+0x10], xmm1
00007895b19d638b  vmovaps [rsp+0x20], xmm2
00007895b19d6391  vmovaps [rsp+0x30], xmm3
00007895b19d6397  vmovaps [rsp+0x40], xmm4
00007895b19d639d  vmovaps [rsp+0x50], xmm5
00007895b19d63a3  vmovaps [rsp+0x60], xmm6
00007895b19d63a9  vmovaps [rsp+0x70], xmm7
00007895b19d63af  vmovaps [rsp+0x80], xmm8
00007895b19d63b8  vmovaps [rsp+0x90], xmm10
00007895b19d63c1  vmovaps [rsp+0xA0], xmm11
00007895b19d63ca  vmovaps [rsp+0xB0], xmm12
00007895b19d63d3  vmovaps [rsp+0xC0], xmm13
00007895b19d63dc  vmovaps [rsp+0xD0], xmm14
00007895b19d63e5  vmovaps [rsp+0xE0], xmm15
00007895b19d63ee  sub rsp, 0x40
00007895b19d63f2  lea rdi, [rsp]
00007895b19d63f6  lea rsi, [rsp+0x10]
00007895b19d63fb  lea rdx, [rsp+0x20]
00007895b19d6400  lea rcx, [rsp+0x30]
00007895b19d6405  mov r8d, 0x00
00007895b19d640b  lea r9, [r15+0x3A8]
00007895b19d6412  movaps [rdi], xmm9
00007895b19d6416  movaps [rsi], xmm8
00007895b19d641a  movaps [rdx], xmm14
00007895b19d641e  movaps [rcx], xmm13
00007895b19d6422  mov rax, 0x59D4522A9A50
00007895b19d642c  call rax
00007895b19d642e  movaps xmm9, [rsp]
00007895b19d6433  add rsp, 0x40
00007895b19d6437  vmovaps xmm0, [rsp]
00007895b19d643c  vmovaps xmm1, [rsp+0x10]
00007895b19d6442  vmovaps xmm2, [rsp+0x20]
00007895b19d6448  vmovaps xmm3, [rsp+0x30]
00007895b19d644e  vmovaps xmm4, [rsp+0x40]
00007895b19d6454  vmovaps xmm5, [rsp+0x50]
00007895b19d645a  vmovaps xmm6, [rsp+0x60]
00007895b19d6460  vmovaps xmm7, [rsp+0x70]
00007895b19d6466  vmovaps xmm8, [rsp+0x80]
00007895b19d646f  vmovaps xmm10, [rsp+0x90]
00007895b19d6478  vmovaps xmm11, [rsp+0xA0]
00007895b19d6481  vmovaps xmm12, [rsp+0xB0]
00007895b19d648a  vmovaps xmm13, [rsp+0xC0]
00007895b19d6493  vmovaps xmm14, [rsp+0xD0]
00007895b19d649c  vmovaps xmm15, [rsp+0xE0]
00007895b19d64a5  add rsp, 0xF0
00007895b19d64ac  pop r11
00007895b19d64ae  pop r10
00007895b19d64b0  pop r9
00007895b19d64b2  pop r8
00007895b19d64b4  pop rsi
00007895b19d64b5  pop rdi
00007895b19d64b6  pop rdx
00007895b19d64b7  pop rcx
00007895b19d64b8  pop rax
00007895b19d64b9  add rsp, 0x08
00007895b19d64bd  jmp 0x00007895B19D3A9D
00007895b19d64c2  sub rsp, 0x08
00007895b19d64c6  push rax
00007895b19d64c7  push rcx
00007895b19d64c8  push rdx
00007895b19d64c9  push rdi
00007895b19d64ca  push rsi
00007895b19d64cb  push r8
00007895b19d64cd  push r9
00007895b19d64cf  push r10
00007895b19d64d1  push r11
00007895b19d64d3  sub rsp, 0xF0
00007895b19d64da  vmovaps [rsp], xmm0
00007895b19d64df  vmovaps [rsp+0x10], xmm1
00007895b19d64e5  vmovaps [rsp+0x20], xmm2
00007895b19d64eb  vmovaps [rsp+0x30], xmm3
00007895b19d64f1  vmovaps [rsp+0x40], xmm4
00007895b19d64f7  vmovaps [rsp+0x50], xmm5
00007895b19d64fd  vmovaps [rsp+0x60], xmm6
00007895b19d6503  vmovaps [rsp+0x70], xmm7
00007895b19d6509  vmovaps [rsp+0x80], xmm8
00007895b19d6512  vmovaps [rsp+0x90], xmm9
00007895b19d651b  vmovaps [rsp+0xA0], xmm10
00007895b19d6524  vmovaps [rsp+0xB0], xmm11
00007895b19d652d  vmovaps [rsp+0xC0], xmm12
00007895b19d6536  vmovaps [rsp+0xD0], xmm14
00007895b19d653f  vmovaps [rsp+0xE0], xmm15
00007895b19d6548  sub rsp, 0x40
00007895b19d654c  lea rdi, [rsp]
00007895b19d6550  lea rsi, [rsp+0x10]
00007895b19d6555  lea rdx, [rsp+0x20]
00007895b19d655a  lea rcx, [rsp+0x30]
00007895b19d655f  mov r8d, 0x00
00007895b19d6565  lea r9, [r15+0x3A8]
00007895b19d656c  movaps [rdi], xmm13
00007895b19d6570  movaps [rsi], xmm11
00007895b19d6574  movaps [rdx], xmm15
00007895b19d6578  movaps [rcx], xmm14
00007895b19d657c  mov rax, 0x59D4522A9A50
00007895b19d6586  call rax
00007895b19d6588  movaps xmm13, [rsp]
00007895b19d658d  add rsp, 0x40
00007895b19d6591  vmovaps xmm0, [rsp]
00007895b19d6596  vmovaps xmm1, [rsp+0x10]
00007895b19d659c  vmovaps xmm2, [rsp+0x20]
00007895b19d65a2  vmovaps xmm3, [rsp+0x30]
00007895b19d65a8  vmovaps xmm4, [rsp+0x40]
00007895b19d65ae  vmovaps xmm5, [rsp+0x50]
00007895b19d65b4  vmovaps xmm6, [rsp+0x60]
00007895b19d65ba  vmovaps xmm7, [rsp+0x70]
00007895b19d65c0  vmovaps xmm8, [rsp+0x80]
00007895b19d65c9  vmovaps xmm9, [rsp+0x90]
00007895b19d65d2  vmovaps xmm10, [rsp+0xA0]
00007895b19d65db  vmovaps xmm11, [rsp+0xB0]
00007895b19d65e4  vmovaps xmm12, [rsp+0xC0]
00007895b19d65ed  vmovaps xmm14, [rsp+0xD0]
00007895b19d65f6  vmovaps xmm15, [rsp+0xE0]
00007895b19d65ff  add rsp, 0xF0
00007895b19d6606  pop r11
00007895b19d6608  pop r10
00007895b19d660a  pop r9
00007895b19d660c  pop r8
00007895b19d660e  pop rsi
00007895b19d660f  pop rdi
00007895b19d6610  pop rdx
00007895b19d6611  pop rcx
00007895b19d6612  pop rax
00007895b19d6613  add rsp, 0x08
00007895b19d6617  jmp 0x00007895B19D3ACB
00007895b19d661c  sub rsp, 0x08
00007895b19d6620  push rax
00007895b19d6621  push rcx
00007895b19d6622  push rdx
00007895b19d6623  push rdi
00007895b19d6624  push rsi
00007895b19d6625  push r8
00007895b19d6627  push r9
00007895b19d6629  push r10
00007895b19d662b  push r11
00007895b19d662d  sub rsp, 0xF0
00007895b19d6634  vmovaps [rsp], xmm0
00007895b19d6639  vmovaps [rsp+0x10], xmm1
00007895b19d663f  vmovaps [rsp+0x20], xmm2
00007895b19d6645  vmovaps [rsp+0x30], xmm3
00007895b19d664b  vmovaps [rsp+0x40], xmm4
00007895b19d6651  vmovaps [rsp+0x50], xmm5
00007895b19d6657  vmovaps [rsp+0x60], xmm6
00007895b19d665d  vmovaps [rsp+0x70], xmm7
00007895b19d6663  vmovaps [rsp+0x80], xmm8
00007895b19d666c  vmovaps [rsp+0x90], xmm9
00007895b19d6675  vmovaps [rsp+0xA0], xmm10
00007895b19d667e  vmovaps [rsp+0xB0], xmm11
00007895b19d6687  vmovaps [rsp+0xC0], xmm12
00007895b19d6690  vmovaps [rsp+0xD0], xmm13
00007895b19d6699  vmovaps [rsp+0xE0], xmm15
00007895b19d66a2  sub rsp, 0x40
00007895b19d66a6  lea rdi, [rsp]
00007895b19d66aa  lea rsi, [rsp+0x10]
00007895b19d66af  lea rdx, [rsp+0x20]
00007895b19d66b4  lea rcx, [rsp+0x30]
00007895b19d66b9  mov r8d, 0x00
00007895b19d66bf  lea r9, [r15+0x3A8]
00007895b19d66c6  movaps [rdi], xmm14
00007895b19d66ca  movaps [rsi], xmm12
00007895b19d66ce  movaps [rdx], xmm1
00007895b19d66d1  movaps [rcx], xmm15
00007895b19d66d5  mov rax, 0x59D4522A9A50
00007895b19d66df  call rax
00007895b19d66e1  movaps xmm14, [rsp]
00007895b19d66e6  add rsp, 0x40
00007895b19d66ea  vmovaps xmm0, [rsp]
00007895b19d66ef  vmovaps xmm1, [rsp+0x10]
00007895b19d66f5  vmovaps xmm2, [rsp+0x20]
00007895b19d66fb  vmovaps xmm3, [rsp+0x30]
00007895b19d6701  vmovaps xmm4, [rsp+0x40]
00007895b19d6707  vmovaps xmm5, [rsp+0x50]
00007895b19d670d  vmovaps xmm6, [rsp+0x60]
00007895b19d6713  vmovaps xmm7, [rsp+0x70]
00007895b19d6719  vmovaps xmm8, [rsp+0x80]
00007895b19d6722  vmovaps xmm9, [rsp+0x90]
00007895b19d672b  vmovaps xmm10, [rsp+0xA0]
00007895b19d6734  vmovaps xmm11, [rsp+0xB0]
00007895b19d673d  vmovaps xmm12, [rsp+0xC0]
00007895b19d6746  vmovaps xmm13, [rsp+0xD0]
00007895b19d674f  vmovaps xmm15, [rsp+0xE0]
00007895b19d6758  add rsp, 0xF0
00007895b19d675f  pop r11
00007895b19d6761  pop r10
00007895b19d6763  pop r9
00007895b19d6765  pop r8
00007895b19d6767  pop rsi
00007895b19d6768  pop rdi
00007895b19d6769  pop rdx
00007895b19d676a  pop rcx
00007895b19d676b  pop rax
00007895b19d676c  add rsp, 0x08
00007895b19d6770  jmp 0x00007895B19D3AF9
00007895b19d6775  call 0x00007895B18ACF70
00007895b19d677a  jmp 0x00007895B19D3B07
00007895b19d677f  call 0x00007895B180C380
00007895b19d6784  jmp 0x00007895B19D3B11
00007895b19d6789  call 0x00007895B1808C20
00007895b19d678e  jmp 0x00007895B19D3B1B
00007895b19d6793  call 0x00007895B180D600
00007895b19d6798  jmp 0x00007895B19D3B25
00007895b19d679d  int3
00007895b19d679e  nop
00007895b19d67a0  mov eax, [r15+0x48]
00007895b19d67a4  lea r14d, [eax+0x01]
00007895b19d67a9  mov [rsp+0x10], r14d
00007895b19d67ae  mov r14d, r14d
00007895b19d67b1  mov [r15+0x48], r14
00007895b19d67b5  xor eax, eax
00007895b19d67b7  mov r14d, [rsp+0x10]
00007895b19d67bc  cmp r14d, 0x1F4
00007895b19d67c3  cmc
00007895b19d67c4  lahf
00007895b19d67c5  seto al
00007895b19d67c8  mov [r15+0x108], eax
00007895b19d67cf  mov eax, [r15+0x108]
00007895b19d67d6  sahf
00007895b19d67d7  jnz 0x00007895B19D6809
00007895b19d67d9  cmp dword ptr [r15+0x318], 0x00
00007895b19d67e1  jz 0x00007895B19DA1A0
00007895b19d67e7  nop [rax+rax*1], ax
00007895b19d67f0  nop [rax+rax*1], eax
00007895b19d67f8  mov eax, 0x4103FC
00007895b19d67fd  mov [r15+0x100], rax
00007895b19d6804  jmp 0x00007895B17FE110
00007895b19d6809  cmp dword ptr [r15+0x318], 0x00
00007895b19d6811  jz 0x00007895B19D6840
00007895b19d6817  nop [rax+rax*1], ax
00007895b19d6820  nop [rax+rax*1], eax
00007895b19d6828  mov eax, 0x410270
00007895b19d682d  mov [r15+0x100], rax
00007895b19d6834  jmp 0x00007895B17FE110
00007895b19d6839  int3
00007895b19d683a  int3
00007895b19d683b  nop [rax+rax*1], eax
00007895b19d6840  mov rax, [r15+0x40]
00007895b19d6844  vxorps xmm1, xmm1, xmm1
00007895b19d6848  vpbroadcastq xmm1, xmm1
00007895b19d684d  vxorps xmm15, xmm15, xmm15
00007895b19d6852  vpbroadcastq xmm15, xmm15
00007895b19d6857  lea r14, [rax+0x30]
00007895b19d685b  mov r12, [r13+r14*1]
00007895b19d6860  lea r14, [rax+0x38]
00007895b19d6864  mov r11, [r13+r14*1]
00007895b19d6869  movq xmm14, r12
00007895b19d686e  movq xmm13, r11
00007895b19d6873  movq xmm14, xmm14
00007895b19d6878  movq xmm13, xmm13
00007895b19d687d  vmovaps [rsp+0x10], xmm13
00007895b19d6883  movq xmm13, xmm13
00007895b19d6888  movaps [r15+0x270], xmm13
00007895b19d6890  movaps xmm13, [r15+0x160]
00007895b19d6898  vmovaps [rsp+0x20], xmm13
00007895b19d689e  vmovaps xmm12, [rsp+0x20]
00007895b19d68a4  por xmm13, xmm12
00007895b19d68a9  lea r14, [rax+0x20]
00007895b19d68ad  mov r12, [r13+r14*1]
00007895b19d68b2  lea r14, [rax+0x28]
00007895b19d68b6  mov r11, [r13+r14*1]
00007895b19d68bb  movq xmm12, r12
00007895b19d68c0  movq xmm11, r11
00007895b19d68c5  movq xmm12, xmm12
00007895b19d68ca  movq xmm11, xmm11
00007895b19d68cf  movaps xmm10, [r15+0x2F0]
00007895b19d68d7  vmovaps [rsp+0x20], xmm10
00007895b19d68dd  vmovaps xmm9, [rsp+0x20]
00007895b19d68e3  por xmm10, xmm9
00007895b19d68e8  movaps xmm9, [r15+0x2D0]
00007895b19d68f0  vmovaps [rsp+0x20], xmm9
00007895b19d68f6  vmovaps xmm8, [rsp+0x20]
00007895b19d68fc  por xmm9, xmm8
00007895b19d6901  movaps xmm8, [r15+0x300]
00007895b19d6909  vmovaps [rsp+0x20], xmm8
00007895b19d690f  vmovaps xmm7, [rsp+0x20]
00007895b19d6915  por xmm8, xmm7
00007895b19d691a  movaps xmm7, [r15+0x2B0]
00007895b19d6922  vmovaps [rsp+0x20], xmm7
00007895b19d6928  vmovaps xmm6, [rsp+0x20]
00007895b19d692e  por xmm7, xmm6
00007895b19d6932  movaps xmm6, [r15+0x180]
00007895b19d693a  vmovaps [rsp+0x20], xmm6
00007895b19d6940  vmovaps xmm5, [rsp+0x20]
00007895b19d6946  por xmm6, xmm5
00007895b19d694a  lea r14, [rax+0x10]
00007895b19d694e  mov r12, [r13+r14*1]
00007895b19d6953  lea r14, [rax+0x18]
00007895b19d6957  mov r11, [r13+r14*1]
00007895b19d695c  movq xmm5, r12
00007895b19d6961  movq xmm4, r11
00007895b19d6966  movq xmm5, xmm5
00007895b19d696a  movq xmm4, xmm4
00007895b19d696e  movaps xmm3, [r15+0x200]
00007895b19d6976  vmovaps [rsp+0x20], xmm3
00007895b19d697c  vmovaps xmm2, [rsp+0x20]
00007895b19d6982  por xmm3, xmm2
00007895b19d6986  movaps xmm2, [r15+0x1F0]
00007895b19d698e  vmovaps [rsp+0x20], xmm2
00007895b19d6994  vmovaps [rsp+0x30], xmm1
00007895b19d699a  vmovaps xmm1, [rsp+0x20]
00007895b19d69a0  por xmm2, xmm1
00007895b19d69a4  movaps xmm1, [r15+0x2E0]
00007895b19d69ac  vmovaps [rsp+0x20], xmm1
00007895b19d69b2  vmovaps [rsp+0x40], xmm15
00007895b19d69b8  vmovaps xmm15, [rsp+0x20]
00007895b19d69be  por xmm1, xmm15
00007895b19d69c3  movaps xmm15, [r15+0x2A0]
00007895b19d69cb  vmovaps [rsp+0x20], xmm15
00007895b19d69d1  vmovaps [rsp+0x50], xmm1
00007895b19d69d7  vmovaps xmm1, [rsp+0x20]
00007895b19d69dd  por xmm15, xmm1
00007895b19d69e2  movaps xmm1, [r15+0x280]
00007895b19d69ea  vmovaps [rsp+0x20], xmm1
00007895b19d69f0  vmovaps [rsp+0x60], xmm15
00007895b19d69f6  vmovaps xmm15, [rsp+0x20]
00007895b19d69fc  por xmm1, xmm15
00007895b19d6a01  movaps xmm15, [r15+0x1C0]
00007895b19d6a09  vmovaps [rsp+0x20], xmm15
00007895b19d6a0f  vmovaps [rsp+0x70], xmm1
00007895b19d6a15  vmovaps xmm1, [rsp+0x20]
00007895b19d6a1b  por xmm15, xmm1
00007895b19d6a20  movaps xmm1, [r15+0x210]
00007895b19d6a28  vmovaps [rsp+0x20], xmm1
00007895b19d6a2e  vmovaps [rsp+0x80], xmm15
00007895b19d6a37  vmovaps xmm15, [rsp+0x20]
00007895b19d6a3d  por xmm1, xmm15
00007895b19d6a42  mov r14, [r13+rax*1]
00007895b19d6a47  vmovq xmm15, r14
00007895b19d6a4c  vpbroadcastq xmm15, xmm15
00007895b19d6a51  vmovaps [rsp+0x20], xmm1
00007895b19d6a57  vxorps xmm1, xmm1, xmm1
00007895b19d6a5b  vpbroadcastq xmm1, xmm1
00007895b19d6a60  mov r14, [r15+0xF8]
00007895b19d6a67  vmovaps [rsp+0x90], xmm1
00007895b19d6a70  movups xmm1, [r13+r14*1]
00007895b19d6a76  vmovaps [rsp+0xA0], xmm1
00007895b19d6a7f  vxorps xmm1, xmm1, xmm1
00007895b19d6a83  vpbroadcastq xmm1, xmm1
00007895b19d6a88  lea r12, [rax+0x08]
00007895b19d6a8c  mov rax, [r13+r12*1]
00007895b19d6a91  vmovaps [rsp+0xB0], xmm1
00007895b19d6a9a  movq xmm1, rax
00007895b19d6a9f  movaps [r15+0x240], xmm1
00007895b19d6aa7  mov rax, [r15+0x50]
00007895b19d6aab  mov [r15+0x60], rax
00007895b19d6aaf  mov qword ptr [r15+0x58], 0x40
00007895b19d6ab7  vmovaps xmm1, [rsp+0x30]
00007895b19d6abd  vmovaps [rsp+0x30], xmm15
00007895b19d6ac3  vmovaps xmm15, [rsp+0xA0]
00007895b19d6acc  vmovaps [rsp+0xA0], xmm14
00007895b19d6ad5  vmovaps xmm14, [rsp+0x30]
00007895b19d6adb  vmovaps [rsp+0x30], xmm13
00007895b19d6ae1  vmovaps [rsp+0xC0], xmm12
00007895b19d6aea  movaps xmm13, xmm1
00007895b19d6aee  vfmadd231pd xmm13, xmm15, xmm14
00007895b19d6af3  vcmppd xmm12, xmm13, xmm13, 0x03
00007895b19d6af9  vptest xmm12, xmm12
00007895b19d6afe  jnz 0x00007895B19D75DD
00007895b19d6b04  movaps xmm1, [r15+0x250]
00007895b19d6b0c  vmovaps xmm15, [rsp+0x40]
00007895b19d6b12  vmovaps [rsp+0x40], xmm13
00007895b19d6b18  movaps xmm12, xmm15
00007895b19d6b1c  vfmadd231pd xmm12, xmm1, xmm14
00007895b19d6b21  vcmppd xmm13, xmm12, xmm12, 0x03
00007895b19d6b27  vptest xmm13, xmm13
00007895b19d6b2c  jnz 0x00007895B19D7736
00007895b19d6b32  movaps xmm15, [r15+0x1E0]
00007895b19d6b3a  vmovaps [rsp+0xD0], xmm15
00007895b19d6b43  vmovaps xmm13, [rsp+0xD0]
00007895b19d6b4c  por xmm15, xmm13
00007895b19d6b51  movaps xmm13, [r15+0x1D0]
00007895b19d6b59  vmovaps [rsp+0xD0], xmm13
00007895b19d6b62  vmovaps [rsp+0xE0], xmm1
00007895b19d6b6b  vmovaps xmm1, [rsp+0xD0]
00007895b19d6b74  por xmm13, xmm1
00007895b19d6b79  movaps xmm1, [r15+0x2C0]
00007895b19d6b81  vmovaps [rsp+0xD0], xmm1
00007895b19d6b8a  vmovaps [rsp+0xF0], xmm15
00007895b19d6b93  vmovaps xmm15, [rsp+0xD0]
00007895b19d6b9c  por xmm1, xmm15
00007895b19d6ba1  movaps xmm15, [r15+0x290]
00007895b19d6ba9  vmovaps [rsp+0xD0], xmm15
00007895b19d6bb2  vmovaps [rsp+0x100], xmm1
00007895b19d6bbb  vmovaps xmm1, [rsp+0xD0]
00007895b19d6bc4  por xmm15, xmm1
00007895b19d6bc9  movaps xmm1, [r15+0x260]
00007895b19d6bd1  vmovaps [rsp+0xD0], xmm1
00007895b19d6bda  vmovaps [rsp+0x110], xmm15
00007895b19d6be3  vmovaps xmm15, [rsp+0xD0]
00007895b19d6bec  por xmm1, xmm15
00007895b19d6bf1  vmovaps xmm15, [rsp+0xE0]
00007895b19d6bfa  vmovaps [rsp+0xD0], xmm1
00007895b19d6c03  vmovaps xmm1, [rsp+0xE0]
00007895b19d6c0c  por xmm15, xmm1
00007895b19d6c11  lea r12, [r14+0xC0]
00007895b19d6c18  movups xmm1, [r13+r12*1]
00007895b19d6c1e  mov [rsp+0xE0], rax
00007895b19d6c26  xor eax, eax
00007895b19d6c28  mov r12d, 0x40
00007895b19d6c2e  mov r11d, 0x200
00007895b19d6c34  cmp r12, r11
00007895b19d6c37  cmc
00007895b19d6c38  lahf
00007895b19d6c39  seto al
00007895b19d6c3c  mov [r15+0x108], eax
00007895b19d6c43  vmovaps [rsp+0x120], xmm1
00007895b19d6c4c  vmovaps xmm1, [rsp+0x90]
00007895b19d6c55  vmovaps [rsp+0x90], xmm15
00007895b19d6c5e  vmovaps xmm15, [rsp+0x120]
00007895b19d6c67  vmovaps [rsp+0x120], xmm13
00007895b19d6c70  vmovaps [rsp+0x130], xmm12
00007895b19d6c79  movaps xmm13, xmm1
00007895b19d6c7d  vfmadd231pd xmm13, xmm15, xmm14
00007895b19d6c82  vcmppd xmm12, xmm13, xmm13, 0x03
00007895b19d6c88  vptest xmm12, xmm12
00007895b19d6c8d  jnz 0x00007895B19D7899
00007895b19d6c93  lea rax, [r14+0xB0]
00007895b19d6c9a  movups xmm1, [r13+rax*1]
00007895b19d6ca0  vmovaps xmm15, [rsp+0xB0]
00007895b19d6ca9  vmovaps [rsp+0xB0], xmm13
00007895b19d6cb2  movaps xmm12, xmm15
00007895b19d6cb6  vfmadd231pd xmm12, xmm1, xmm14
00007895b19d6cbb  vcmppd xmm13, xmm12, xmm12, 0x03
00007895b19d6cc1  vptest xmm13, xmm13
00007895b19d6cc6  jnz 0x00007895B19D79FC
00007895b19d6ccc  vmovaps xmm1, [rsp+0x20]
00007895b19d6cd2  vmovaps xmm15, [rsp+0x20]
00007895b19d6cd8  por xmm1, xmm15
00007895b19d6cdd  movaps [r15+0x210], xmm1
00007895b19d6ce5  vmovaps xmm15, [rsp+0x80]
00007895b19d6cee  vmovaps xmm14, [rsp+0x80]
00007895b19d6cf7  por xmm15, xmm14
00007895b19d6cfc  movaps [r15+0x1C0], xmm15
00007895b19d6d04  vmovaps xmm14, [rsp+0x70]
00007895b19d6d0a  vmovaps xmm13, [rsp+0x70]
00007895b19d6d10  por xmm14, xmm13
00007895b19d6d15  movaps [r15+0x280], xmm14
00007895b19d6d1d  vmovaps xmm13, [rsp+0x60]
00007895b19d6d23  vmovaps [rsp+0x20], xmm1
00007895b19d6d29  vmovaps xmm1, [rsp+0x60]
00007895b19d6d2f  por xmm13, xmm1
00007895b19d6d34  movaps [r15+0x2A0], xmm13
00007895b19d6d3c  vmovaps xmm1, [rsp+0x50]
00007895b19d6d42  vmovaps [rsp+0x60], xmm15
00007895b19d6d48  vmovaps xmm15, [rsp+0x50]
00007895b19d6d4e  por xmm1, xmm15
00007895b19d6d53  movaps [r15+0x2E0], xmm1
00007895b19d6d5b  vmovaps [rsp+0x50], xmm2
00007895b19d6d61  vmovaps xmm15, [rsp+0x50]
00007895b19d6d67  por xmm2, xmm15
00007895b19d6d6c  movaps [r15+0x1F0], xmm2
00007895b19d6d74  vmovaps xmm15, [rsp+0x90]
00007895b19d6d7d  vmovaps [rsp+0x50], xmm1
00007895b19d6d83  vmovaps xmm1, [rsp+0x90]
00007895b19d6d8c  por xmm15, xmm1
00007895b19d6d91  movaps [r15+0x250], xmm15
00007895b19d6d99  vmovaps xmm1, [rsp+0xD0]
00007895b19d6da2  vmovaps xmm15, [rsp+0xD0]
00007895b19d6dab  por xmm1, xmm15
00007895b19d6db0  movaps [r15+0x260], xmm1
00007895b19d6db8  vmovaps xmm15, [rsp+0x110]
00007895b19d6dc1  vmovaps [rsp+0x70], xmm1
00007895b19d6dc7  vmovaps xmm1, [rsp+0x110]
00007895b19d6dd0  por xmm15, xmm1
00007895b19d6dd5  movaps [r15+0x290], xmm15
00007895b19d6ddd  vmovaps xmm1, [rsp+0x100]
00007895b19d6de6  vmovaps [rsp+0x80], xmm15
00007895b19d6def  vmovaps xmm15, [rsp+0x100]
00007895b19d6df8  por xmm1, xmm15
00007895b19d6dfd  movaps [r15+0x2C0], xmm1
00007895b19d6e05  movq xmm15, qword ptr [r15+0x240]
00007895b19d6e0e  vmovaps [rsp+0x90], xmm15
00007895b19d6e17  vpermilpd xmm15, xmm15, 0x00
00007895b19d6e1d  vmovaps [rsp+0xD0], xmm1
00007895b19d6e26  vmovaps xmm1, [rsp+0x40]
00007895b19d6e2c  vmovaps [rsp+0x40], xmm15
00007895b19d6e32  vmovaps xmm15, [rsp+0x20]
00007895b19d6e38  vmovaps [rsp+0x20], xmm14
00007895b19d6e3e  vmovaps xmm14, [rsp+0x40]
00007895b19d6e44  vmovaps [rsp+0x40], xmm13
00007895b19d6e4a  vmovaps [rsp+0x100], xmm12
00007895b19d6e53  movaps xmm13, xmm1
00007895b19d6e57  vfmadd231pd xmm13, xmm15, xmm14
00007895b19d6e5c  vcmppd xmm12, xmm13, xmm13, 0x03
00007895b19d6e62  vptest xmm12, xmm12
00007895b19d6e67  jnz 0x00007895B19D7B55
00007895b19d6e6d  vmovaps xmm1, [rsp+0x90]
00007895b19d6e76  vpermilpd xmm1, xmm1, 0x00
00007895b19d6e7c  vmovaps xmm15, [rsp+0xB0]
00007895b19d6e85  vmovaps xmm14, [rsp+0x50]
00007895b19d6e8b  vmovaps [rsp+0x50], xmm13
00007895b19d6e91  movaps xmm12, xmm15
00007895b19d6e95  vfmadd231pd xmm12, xmm14, xmm1
00007895b19d6e9a  vcmppd xmm13, xmm12, xmm12, 0x03
00007895b19d6ea0  vptest xmm13, xmm13
00007895b19d6ea5  jnz 0x00007895B19D7CAE
00007895b19d6eab  vmovaps xmm1, [rsp+0x90]
00007895b19d6eb4  vpermilpd xmm1, xmm1, 0x00
00007895b19d6eba  vmovaps xmm15, [rsp+0x130]
00007895b19d6ec3  vmovaps xmm14, [rsp+0x60]
00007895b19d6ec9  vmovaps [rsp+0x60], xmm12
00007895b19d6ecf  movaps xmm13, xmm15
00007895b19d6ed3  vfmadd231pd xmm13, xmm14, xmm1
00007895b19d6ed8  vcmppd xmm12, xmm13, xmm13, 0x03
00007895b19d6ede  vptest xmm12, xmm12
00007895b19d6ee3  jnz 0x00007895B19D7E07
00007895b19d6ee9  vmovaps xmm1, [rsp+0x120]
00007895b19d6ef2  vmovaps xmm15, [rsp+0x120]
00007895b19d6efb  por xmm1, xmm15
00007895b19d6f00  movaps [r15+0x1D0], xmm1
00007895b19d6f08  vmovaps xmm15, [rsp+0x90]
00007895b19d6f11  vpermilpd xmm15, xmm15, 0x00
00007895b19d6f17  vmovaps xmm14, [rsp+0x100]
00007895b19d6f20  vmovaps [rsp+0x90], xmm1
00007895b19d6f29  movaps xmm12, xmm14
00007895b19d6f2d  vfmadd231pd xmm12, xmm2, xmm15
00007895b19d6f32  vcmppd xmm1, xmm12, xmm12, 0x03
00007895b19d6f38  vptest xmm1, xmm1
00007895b19d6f3d  jnz 0x00007895B19D7F60
00007895b19d6f43  vmovaps [rsp+0xB0], xmm3
00007895b19d6f4c  vmovaps xmm1, [rsp+0xB0]
00007895b19d6f55  por xmm3, xmm1
00007895b19d6f59  movaps [r15+0x200], xmm3
00007895b19d6f61  vmovaps xmm1, [rsp+0xF0]
00007895b19d6f6a  vmovaps xmm15, [rsp+0xF0]
00007895b19d6f73  por xmm1, xmm15
00007895b19d6f78  movaps [r15+0x1E0], xmm1
00007895b19d6f80  vmovaps [rsp+0xB0], xmm7
00007895b19d6f89  vmovaps xmm1, [rsp+0xB0]
00007895b19d6f92  por xmm7, xmm1
00007895b19d6f96  movaps [r15+0x2B0], xmm7
00007895b19d6f9e  vmovaps [rsp+0xB0], xmm8
00007895b19d6fa7  vmovaps xmm1, [rsp+0xB0]
00007895b19d6fb0  por xmm8, xmm1
00007895b19d6fb5  movaps [r15+0x300], xmm8
00007895b19d6fbd  vmovaps [rsp+0xB0], xmm5
00007895b19d6fc6  vpermilpd xmm5, xmm5, 0x00
00007895b19d6fcc  vmovaps xmm14, [rsp+0x50]
00007895b19d6fd2  vmovaps xmm8, [rsp+0x70]
00007895b19d6fd8  vmovaps [rsp+0x50], xmm1
00007895b19d6fde  movaps xmm2, xmm14
00007895b19d6fe2  vfmadd231pd xmm2, xmm8, xmm5
00007895b19d6fe7  vcmppd xmm1, xmm2, xmm2, 0x03
00007895b19d6fec  vptest xmm1, xmm1
00007895b19d6ff1  jnz 0x00007895B19D80B9
00007895b19d6ff7  vmovaps xmm1, [rsp+0xB0]
00007895b19d7000  vpermilpd xmm1, xmm1, 0x00
00007895b19d7006  vmovaps xmm14, [rsp+0x60]
00007895b19d700c  vmovaps xmm8, [rsp+0xD0]
00007895b19d7015  vmovaps [rsp+0x60], xmm15
00007895b19d701b  movaps xmm5, xmm14
00007895b19d701f  vfmadd231pd xmm5, xmm8, xmm1
00007895b19d7024  vcmppd xmm15, xmm5, xmm5, 0x03
00007895b19d7029  vptest xmm15, xmm15
00007895b19d702e  jnz 0x00007895B19D8210
00007895b19d7034  vmovaps xmm1, [rsp+0xB0]
00007895b19d703d  vpermilpd xmm1, xmm1, 0x00
00007895b19d7043  vmovaps xmm14, [rsp+0x20]
00007895b19d7049  movaps xmm15, xmm13
00007895b19d704d  vfmadd231pd xmm15, xmm14, xmm1
00007895b19d7052  vcmppd xmm8, xmm15, xmm15, 0x03
00007895b19d7058  vptest xmm8, xmm8
00007895b19d705d  jnz 0x00007895B19D8367
00007895b19d7063  vmovaps xmm1, [rsp+0xB0]
00007895b19d706c  vpermilpd xmm1, xmm1, 0x00
00007895b19d7072  vmovaps xmm14, [rsp+0x90]
00007895b19d707b  movaps xmm13, xmm12
00007895b19d707f  vfmadd231pd xmm13, xmm14, xmm1
00007895b19d7084  vcmppd xmm8, xmm13, xmm13, 0x03
00007895b19d708a  vptest xmm8, xmm8
00007895b19d708f  jnz 0x00007895B19D84C0
00007895b19d7095  vmovaps [rsp+0x20], xmm6
00007895b19d709b  vmovaps xmm1, [rsp+0x20]
00007895b19d70a1  por xmm6, xmm1
00007895b19d70a5  movaps [r15+0x180], xmm6
00007895b19d70ad  vmovaps [rsp+0x20], xmm9
00007895b19d70b3  vmovaps xmm1, [rsp+0x20]
00007895b19d70b9  por xmm9, xmm1
00007895b19d70be  movaps [r15+0x2D0], xmm9
00007895b19d70c6  vmovaps [rsp+0x20], xmm10
00007895b19d70cc  vmovaps xmm1, [rsp+0x20]
00007895b19d70d2  por xmm10, xmm1
00007895b19d70d7  movaps [r15+0x2F0], xmm10
00007895b19d70df  vmovaps [rsp+0x20], xmm4
00007895b19d70e5  vpermilpd xmm4, xmm4, 0x00
00007895b19d70eb  vmovaps xmm14, [rsp+0x50]
00007895b19d70f1  movaps xmm12, xmm5
00007895b19d70f5  vfmadd231pd xmm12, xmm14, xmm4
00007895b19d70fa  vcmppd xmm10, xmm12, xmm12, 0x03
00007895b19d7100  vptest xmm10, xmm10
00007895b19d7105  jnz 0x00007895B19D8619
00007895b19d710b  vmovaps xmm14, [rsp+0x20]
00007895b19d7111  vpermilpd xmm14, xmm14, 0x00
00007895b19d7117  movaps xmm10, xmm2
00007895b19d711b  vfmadd231pd xmm10, xmm6, xmm14
00007895b19d7120  vcmppd xmm8, xmm10, xmm10, 0x03
00007895b19d7126  vptest xmm8, xmm8
00007895b19d712b  jnz 0x00007895B19D8771
00007895b19d7131  lea rax, [r14+0x80]
00007895b19d7138  movups xmm14, [r13+rax*1]
00007895b19d713e  movaps [r15+0x190], xmm14
00007895b19d7146  vmovaps xmm8, [rsp+0x20]
00007895b19d714c  vpermilpd xmm8, xmm8, 0x00
00007895b19d7152  vmovaps xmm6, [rsp+0x80]
00007895b19d715b  movaps xmm5, xmm15
00007895b19d715f  vfmadd231pd xmm5, xmm6, xmm8
00007895b19d7164  vcmppd xmm4, xmm5, xmm5, 0x03
00007895b19d7169  vptest xmm4, xmm4
00007895b19d716e  jnz 0x00007895B19D88D3
00007895b19d7174  vmovaps xmm15, [rsp+0x20]
00007895b19d717a  vpermilpd xmm15, xmm15, 0x00
00007895b19d7180  movaps xmm8, xmm13
00007895b19d7184  vfmadd231pd xmm8, xmm1, xmm15
00007895b19d7189  vcmppd xmm6, xmm8, xmm8, 0x03
00007895b19d718f  vptest xmm6, xmm6
00007895b19d7194  jnz 0x00007895B19D8A2A
00007895b19d719a  vmovaps xmm1, [rsp+0x30]
00007895b19d71a0  vmovaps xmm15, [rsp+0x30]
00007895b19d71a6  por xmm1, xmm15
00007895b19d71ab  movaps [r15+0x160], xmm1
00007895b19d71b3  lea rax, [r14+0x40]
00007895b19d71b7  movups xmm15, [r13+rax*1]
00007895b19d71bd  lea rax, [r14+0x50]
00007895b19d71c1  movups xmm13, [r13+rax*1]
00007895b19d71c7  movaps [r15+0x1B0], xmm15
00007895b19d71cf  movaps [r15+0x1A0], xmm13
00007895b19d71d7  vmovaps xmm6, [rsp+0xC0]
00007895b19d71e0  vpermilpd xmm6, xmm6, 0x00
00007895b19d71e6  movaps xmm4, xmm12
00007895b19d71ea  vfmadd231pd xmm4, xmm9, xmm6
00007895b19d71ef  vcmppd xmm2, xmm4, xmm4, 0x03
00007895b19d71f4  vptest xmm2, xmm2
00007895b19d71f9  jnz 0x00007895B19D8B97
00007895b19d71ff  vmovaps xmm12, [rsp+0xC0]
00007895b19d7208  vpermilpd xmm12, xmm12, 0x00
00007895b19d720e  movaps xmm9, xmm10
00007895b19d7212  vfmadd231pd xmm9, xmm1, xmm12
00007895b19d7217  vcmppd xmm6, xmm9, xmm9, 0x03
00007895b19d721d  vptest xmm6, xmm6
00007895b19d7222  jnz 0x00007895B19D8CEE
00007895b19d7228  vmovaps xmm1, [rsp+0xC0]
00007895b19d7231  vpermilpd xmm1, xmm1, 0x00
00007895b19d7237  vmovaps xmm12, [rsp+0x40]
00007895b19d723d  movaps xmm10, xmm5
00007895b19d7241  vfmadd231pd xmm10, xmm12, xmm1
00007895b19d7246  vcmppd xmm6, xmm10, xmm10, 0x03
00007895b19d724c  vptest xmm6, xmm6
00007895b19d7251  jnz 0x00007895B19D8E47
00007895b19d7257  vmovaps xmm1, [rsp+0xC0]
00007895b19d7260  vpermilpd xmm1, xmm1, 0x00
00007895b19d7266  vmovaps xmm12, [rsp+0x60]
00007895b19d726c  movaps xmm6, xmm8
00007895b19d7270  vfmadd231pd xmm6, xmm12, xmm1
00007895b19d7275  vcmppd xmm5, xmm6, xmm6, 0x03
00007895b19d727a  vptest xmm5, xmm5
00007895b19d727f  jnz 0x00007895B19D8F9F
00007895b19d7285  lea rax, [r14+0x60]
00007895b19d7289  movups xmm1, [r13+rax*1]
00007895b19d728f  lea rax, [r14+0x70]
00007895b19d7293  movups xmm12, [r13+rax*1]
00007895b19d7299  movaps [r15+0x150], xmm1
00007895b19d72a1  movaps [r15+0x120], xmm12
00007895b19d72a9  vmovaps [rsp+0x20], xmm11
00007895b19d72af  vpermilpd xmm11, xmm11, 0x00
00007895b19d72b5  movaps xmm8, xmm4
00007895b19d72b9  vfmadd231pd xmm8, xmm13, xmm11
00007895b19d72be  vcmppd xmm5, xmm8, xmm8, 0x03
00007895b19d72c4  vptest xmm5, xmm5
00007895b19d72c9  jnz 0x00007895B19D910A
00007895b19d72cf  vmovaps xmm13, [rsp+0x20]
00007895b19d72d5  vpermilpd xmm13, xmm13, 0x00
00007895b19d72db  movaps xmm11, xmm9
00007895b19d72df  vfmadd231pd xmm11, xmm1, xmm13
00007895b19d72e4  vcmppd xmm5, xmm11, xmm11, 0x03
00007895b19d72ea  vptest xmm5, xmm5
00007895b19d72ef  jnz 0x00007895B19D9263
00007895b19d72f5  vmovaps xmm1, [rsp+0x20]
00007895b19d72fb  vpermilpd xmm1, xmm1, 0x00
00007895b19d7301  movaps xmm13, xmm10
00007895b19d7305  vfmadd231pd xmm13, xmm7, xmm1
00007895b19d730a  vcmppd xmm9, xmm13, xmm13, 0x03
00007895b19d7310  vptest xmm9, xmm9
00007895b19d7315  jnz 0x00007895B19D93BC
00007895b19d731b  vmovaps xmm1, [rsp+0x20]
00007895b19d7321  vpermilpd xmm1, xmm1, 0x00
00007895b19d7327  movaps xmm10, xmm6
00007895b19d732b  vfmadd231pd xmm10, xmm15, xmm1
00007895b19d7330  vcmppd xmm9, xmm10, xmm10, 0x03
00007895b19d7336  vptest xmm9, xmm9
00007895b19d733b  jnz 0x00007895B19D9514
00007895b19d7341  lea rax, [r14+0x20]
00007895b19d7345  movups xmm1, [r13+rax*1]
00007895b19d734b  lea rax, [r14+0x30]
00007895b19d734f  movups xmm15, [r13+rax*1]
00007895b19d7355  vmovaps xmm9, [rsp+0xA0]
00007895b19d735e  vpermilpd xmm9, xmm9, 0x00
00007895b19d7364  movaps xmm7, xmm8
00007895b19d7368  vfmadd231pd xmm7, xmm3, xmm9
00007895b19d736d  vcmppd xmm6, xmm7, xmm7, 0x03
00007895b19d7372  vptest xmm6, xmm6
00007895b19d7377  jnz 0x00007895B19D9680
00007895b19d737d  vmovaps xmm9, [rsp+0xA0]
00007895b19d7386  vpermilpd xmm9, xmm9, 0x00
00007895b19d738c  movaps xmm8, xmm11
00007895b19d7390  vfmadd231pd xmm8, xmm14, xmm9
00007895b19d7395  vcmppd xmm6, xmm8, xmm8, 0x03
00007895b19d739b  vptest xmm6, xmm6
00007895b19d73a0  jnz 0x00007895B19D97D7
00007895b19d73a6  vmovaps xmm14, [rsp+0xA0]
00007895b19d73af  vpermilpd xmm14, xmm14, 0x00
00007895b19d73b5  movaps xmm11, xmm13
00007895b19d73b9  vfmadd231pd xmm11, xmm12, xmm14
00007895b19d73be  vcmppd xmm9, xmm11, xmm11, 0x03
00007895b19d73c4  vptest xmm9, xmm9
00007895b19d73c9  jnz 0x00007895B19D9931
00007895b19d73cf  vmovaps xmm14, [rsp+0xA0]
00007895b19d73d8  vpermilpd xmm14, xmm14, 0x00
00007895b19d73de  movaps xmm12, xmm10
00007895b19d73e2  vfmadd231pd xmm12, xmm15, xmm14
00007895b19d73e7  vcmppd xmm13, xmm12, xmm12, 0x03
00007895b19d73ed  vptest xmm13, xmm13
00007895b19d73f2  jnz 0x00007895B19D9A8B
00007895b19d73f8  lea rax, [r14+0x90]
00007895b19d73ff  movups xmm15, [r13+rax*1]
00007895b19d7405  lea rax, [r14+0xA0]
00007895b19d740c  movups xmm14, [r13+rax*1]
00007895b19d7412  movaps [r15+0x140], xmm15
00007895b19d741a  movaps [r15+0x130], xmm14
00007895b19d7422  vmovaps xmm13, [rsp+0x10]
00007895b19d7428  vpermilpd xmm13, xmm13, 0x00
00007895b19d742e  movaps xmm10, xmm7
00007895b19d7432  vfmadd231pd xmm10, xmm1, xmm13
00007895b19d7437  vcmppd xmm9, xmm10, xmm10, 0x03
00007895b19d743d  vptest xmm9, xmm9
00007895b19d7442  jnz 0x00007895B19D9BF9
00007895b19d7448  movaps [r15+0x220], xmm10
00007895b19d7450  lea rax, [r14+0x10]
00007895b19d7454  movups xmm1, [r13+rax*1]
00007895b19d745a  movaps [r15+0x240], xmm1
00007895b19d7462  vmovaps xmm13, [rsp+0x10]
00007895b19d7468  vpermilpd xmm13, xmm13, 0x00
00007895b19d746e  movaps xmm9, xmm8
00007895b19d7472  vfmadd231pd xmm9, xmm14, xmm13
00007895b19d7477  vcmppd xmm7, xmm9, xmm9, 0x03
00007895b19d747d  vptest xmm7, xmm7
00007895b19d7482  jnz 0x00007895B19D9D5B
00007895b19d7488  movaps [r15+0x110], xmm9
00007895b19d7490  vmovaps xmm14, [rsp+0x10]
00007895b19d7496  vpermilpd xmm14, xmm14, 0x00
00007895b19d749c  movaps xmm13, xmm11
00007895b19d74a0  vfmadd231pd xmm13, xmm15, xmm14
00007895b19d74a5  vcmppd xmm8, xmm13, xmm13, 0x03
00007895b19d74ab  vptest xmm8, xmm8
00007895b19d74b0  jnz 0x00007895B19D9EB5
00007895b19d74b6  movaps [r15+0x170], xmm13
00007895b19d74be  vmovaps xmm15, [rsp+0x10]
00007895b19d74c4  vpermilpd xmm15, xmm15, 0x00
00007895b19d74ca  movaps xmm14, xmm12
00007895b19d74ce  vfmadd231pd xmm14, xmm1, xmm15
00007895b19d74d3  vcmppd xmm11, xmm14, xmm14, 0x03
00007895b19d74d9  vptest xmm11, xmm11
00007895b19d74de  jnz 0x00007895B19DA00F
00007895b19d74e4  movaps [r15+0x230], xmm14
00007895b19d74ec  mov rax, [rsp+0xE0]
00007895b19d74f4  movups [r13+rax*1], xmm9
00007895b19d74fa  lea r14, [rax+0x10]
00007895b19d74fe  movups [r13+r14*1], xmm13
00007895b19d7504  lea r14, [rax+0x20]
00007895b19d7508  movups [r13+r14*1], xmm10
00007895b19d750e  lea r14, [rax+0x30]
00007895b19d7512  movups [r13+r14*1], xmm14
00007895b19d7518  mov eax, [r15+0x108]
00007895b19d751f  sahf
00007895b19d7520  jnz 0x00007895B19D7552
00007895b19d7522  cmp dword ptr [r15+0x318], 0x00
00007895b19d752a  jz 0x00007895B19D67A0
00007895b19d7530  nop [rax+rax*1], ax
00007895b19d7539  nop [rax+rax*1], eax
00007895b19d7541  mov eax, 0x4103F0
00007895b19d7546  mov [r15+0x100], rax
00007895b19d754d  jmp 0x00007895B17FE110
00007895b19d7552  cmp dword ptr [r15+0x318], 0x00
00007895b19d755a  jz 0x00007895B19D2E40
00007895b19d7560  nop [rax+rax*1], ax
00007895b19d7569  nop [rax+rax*1], eax
00007895b19d7571  mov eax, 0x410274
00007895b19d7576  mov [r15+0x100], rax
00007895b19d757d  jmp 0x00007895B17FE110
00007895b19d7582  int3
00007895b19d7583  call 0x00007895B18E27E0
00007895b19d7588  jmp 0x00007895B19D6860
00007895b19d758d  call 0x00007895B18E1570
00007895b19d7592  jmp 0x00007895B19D6869
00007895b19d7597  call 0x00007895B18E27E0
00007895b19d759c  jmp 0x00007895B19D68B2
00007895b19d75a1  call 0x00007895B18E1570
00007895b19d75a6  jmp 0x00007895B19D68BB
00007895b19d75ab  call 0x00007895B18E27E0
00007895b19d75b0  jmp 0x00007895B19D6953
00007895b19d75b5  call 0x00007895B18E1570
00007895b19d75ba  jmp 0x00007895B19D695C
00007895b19d75bf  call 0x00007895B180DC20
00007895b19d75c4  jmp 0x00007895B19D6A47
00007895b19d75c9  call 0x00007895B18D64F0
00007895b19d75ce  jmp 0x00007895B19D6A76
00007895b19d75d3  call 0x00007895B18B47C0
00007895b19d75d8  jmp 0x00007895B19D6A91
00007895b19d75dd  sub rsp, 0x08
00007895b19d75e1  push rax
00007895b19d75e2  push rcx
00007895b19d75e3  push rdx
00007895b19d75e4  push rdi
00007895b19d75e5  push rsi
00007895b19d75e6  push r8
00007895b19d75e8  push r9
00007895b19d75ea  push r10
00007895b19d75ec  push r11
00007895b19d75ee  sub rsp, 0xF0
00007895b19d75f5  vmovaps [rsp], xmm0
00007895b19d75fa  vmovaps [rsp+0x10], xmm1
00007895b19d7600  vmovaps [rsp+0x20], xmm2
00007895b19d7606  vmovaps [rsp+0x30], xmm3
00007895b19d760c  vmovaps [rsp+0x40], xmm4
00007895b19d7612  vmovaps [rsp+0x50], xmm5
00007895b19d7618  vmovaps [rsp+0x60], xmm6
00007895b19d761e  vmovaps [rsp+0x70], xmm7
00007895b19d7624  vmovaps [rsp+0x80], xmm8
00007895b19d762d  vmovaps [rsp+0x90], xmm9
00007895b19d7636  vmovaps [rsp+0xA0], xmm10
00007895b19d763f  vmovaps [rsp+0xB0], xmm11
00007895b19d7648  vmovaps [rsp+0xC0], xmm12
00007895b19d7651  vmovaps [rsp+0xD0], xmm14
00007895b19d765a  vmovaps [rsp+0xE0], xmm15
00007895b19d7663  sub rsp, 0x40
00007895b19d7667  lea rdi, [rsp]
00007895b19d766b  lea rsi, [rsp+0x10]
00007895b19d7670  lea rdx, [rsp+0x20]
00007895b19d7675  lea rcx, [rsp+0x30]
00007895b19d767a  mov r8d, 0x00
00007895b19d7680  lea r9, [r15+0x3A8]
00007895b19d7687  movaps [rdi], xmm13
00007895b19d768b  movaps [rsi], xmm1
00007895b19d768e  movaps [rdx], xmm15
00007895b19d7692  movaps [rcx], xmm14
00007895b19d7696  mov rax, 0x59D4522A9A50
00007895b19d76a0  call rax
00007895b19d76a2  movaps xmm13, [rsp]
00007895b19d76a7  add rsp, 0x40
00007895b19d76ab  vmovaps xmm0, [rsp]
00007895b19d76b0  vmovaps xmm1, [rsp+0x10]
00007895b19d76b6  vmovaps xmm2, [rsp+0x20]
00007895b19d76bc  vmovaps xmm3, [rsp+0x30]
00007895b19d76c2  vmovaps xmm4, [rsp+0x40]
00007895b19d76c8  vmovaps xmm5, [rsp+0x50]
00007895b19d76ce  vmovaps xmm6, [rsp+0x60]
00007895b19d76d4  vmovaps xmm7, [rsp+0x70]
00007895b19d76da  vmovaps xmm8, [rsp+0x80]
00007895b19d76e3  vmovaps xmm9, [rsp+0x90]
00007895b19d76ec  vmovaps xmm10, [rsp+0xA0]
00007895b19d76f5  vmovaps xmm11, [rsp+0xB0]
00007895b19d76fe  vmovaps xmm12, [rsp+0xC0]
00007895b19d7707  vmovaps xmm14, [rsp+0xD0]
00007895b19d7710  vmovaps xmm15, [rsp+0xE0]
00007895b19d7719  add rsp, 0xF0
00007895b19d7720  pop r11
00007895b19d7722  pop r10
00007895b19d7724  pop r9
00007895b19d7726  pop r8
00007895b19d7728  pop rsi
00007895b19d7729  pop rdi
00007895b19d772a  pop rdx
00007895b19d772b  pop rcx
00007895b19d772c  pop rax
00007895b19d772d  add rsp, 0x08
00007895b19d7731  jmp 0x00007895B19D6B04
00007895b19d7736  sub rsp, 0x08
00007895b19d773a  push rax
00007895b19d773b  push rcx
00007895b19d773c  push rdx
00007895b19d773d  push rdi
00007895b19d773e  push rsi
00007895b19d773f  push r8
00007895b19d7741  push r9
00007895b19d7743  push r10
00007895b19d7745  push r11
00007895b19d7747  sub rsp, 0xF0
00007895b19d774e  vmovaps [rsp], xmm0
00007895b19d7753  vmovaps [rsp+0x10], xmm1
00007895b19d7759  vmovaps [rsp+0x20], xmm2
00007895b19d775f  vmovaps [rsp+0x30], xmm3
00007895b19d7765  vmovaps [rsp+0x40], xmm4
00007895b19d776b  vmovaps [rsp+0x50], xmm5
00007895b19d7771  vmovaps [rsp+0x60], xmm6
00007895b19d7777  vmovaps [rsp+0x70], xmm7
00007895b19d777d  vmovaps [rsp+0x80], xmm8
00007895b19d7786  vmovaps [rsp+0x90], xmm9
00007895b19d778f  vmovaps [rsp+0xA0], xmm10
00007895b19d7798  vmovaps [rsp+0xB0], xmm11
00007895b19d77a1  vmovaps [rsp+0xC0], xmm13
00007895b19d77aa  vmovaps [rsp+0xD0], xmm14
00007895b19d77b3  vmovaps [rsp+0xE0], xmm15
00007895b19d77bc  sub rsp, 0x40
00007895b19d77c0  lea rdi, [rsp]
00007895b19d77c4  lea rsi, [rsp+0x10]
00007895b19d77c9  lea rdx, [rsp+0x20]
00007895b19d77ce  lea rcx, [rsp+0x30]
00007895b19d77d3  mov r8d, 0x00
00007895b19d77d9  lea r9, [r15+0x3A8]
00007895b19d77e0  movaps [rdi], xmm12
00007895b19d77e4  movaps [rsi], xmm15
00007895b19d77e8  movaps [rdx], xmm1
00007895b19d77eb  movaps [rcx], xmm14
00007895b19d77ef  mov rax, 0x59D4522A9A50
00007895b19d77f9  call rax
00007895b19d77fb  movaps xmm12, [rsp]
00007895b19d7800  add rsp, 0x40
00007895b19d7804  vmovaps xmm0, [rsp]
00007895b19d7809  vmovaps xmm1, [rsp+0x10]
00007895b19d780f  vmovaps xmm2, [rsp+0x20]
00007895b19d7815  vmovaps xmm3, [rsp+0x30]
00007895b19d781b  vmovaps xmm4, [rsp+0x40]
00007895b19d7821  vmovaps xmm5, [rsp+0x50]
00007895b19d7827  vmovaps xmm6, [rsp+0x60]
00007895b19d782d  vmovaps xmm7, [rsp+0x70]
00007895b19d7833  vmovaps xmm8, [rsp+0x80]
00007895b19d783c  vmovaps xmm9, [rsp+0x90]
00007895b19d7845  vmovaps xmm10, [rsp+0xA0]
00007895b19d784e  vmovaps xmm11, [rsp+0xB0]
00007895b19d7857  vmovaps xmm13, [rsp+0xC0]
00007895b19d7860  vmovaps xmm14, [rsp+0xD0]
00007895b19d7869  vmovaps xmm15, [rsp+0xE0]
00007895b19d7872  add rsp, 0xF0
00007895b19d7879  pop r11
00007895b19d787b  pop r10
00007895b19d787d  pop r9
00007895b19d787f  pop r8
00007895b19d7881  pop rsi
00007895b19d7882  pop rdi
00007895b19d7883  pop rdx
00007895b19d7884  pop rcx
00007895b19d7885  pop rax
00007895b19d7886  add rsp, 0x08
00007895b19d788a  jmp 0x00007895B19D6B32
00007895b19d788f  call 0x00007895B18B52F0
00007895b19d7894  jmp 0x00007895B19D6C1E
00007895b19d7899  sub rsp, 0x08
00007895b19d789d  push rax
00007895b19d789e  push rcx
00007895b19d789f  push rdx
00007895b19d78a0  push rdi
00007895b19d78a1  push rsi
00007895b19d78a2  push r8
00007895b19d78a4  push r9
00007895b19d78a6  push r10
00007895b19d78a8  push r11
00007895b19d78aa  sub rsp, 0xF0
00007895b19d78b1  vmovaps [rsp], xmm0
00007895b19d78b6  vmovaps [rsp+0x10], xmm1
00007895b19d78bc  vmovaps [rsp+0x20], xmm2
00007895b19d78c2  vmovaps [rsp+0x30], xmm3
00007895b19d78c8  vmovaps [rsp+0x40], xmm4
00007895b19d78ce  vmovaps [rsp+0x50], xmm5
00007895b19d78d4  vmovaps [rsp+0x60], xmm6
00007895b19d78da  vmovaps [rsp+0x70], xmm7
00007895b19d78e0  vmovaps [rsp+0x80], xmm8
00007895b19d78e9  vmovaps [rsp+0x90], xmm9
00007895b19d78f2  vmovaps [rsp+0xA0], xmm10
00007895b19d78fb  vmovaps [rsp+0xB0], xmm11
00007895b19d7904  vmovaps [rsp+0xC0], xmm12
00007895b19d790d  vmovaps [rsp+0xD0], xmm14
00007895b19d7916  vmovaps [rsp+0xE0], xmm15
00007895b19d791f  sub rsp, 0x40
00007895b19d7923  lea rdi, [rsp]
00007895b19d7927  lea rsi, [rsp+0x10]
00007895b19d792c  lea rdx, [rsp+0x20]
00007895b19d7931  lea rcx, [rsp+0x30]
00007895b19d7936  mov r8d, 0x00
00007895b19d793c  lea r9, [r15+0x3A8]
00007895b19d7943  movaps [rdi], xmm13
00007895b19d7947  movaps [rsi], xmm1
00007895b19d794a  movaps [rdx], xmm15
00007895b19d794e  movaps [rcx], xmm14
00007895b19d7952  mov rax, 0x59D4522A9A50
00007895b19d795c  call rax
00007895b19d795e  movaps xmm13, [rsp]
00007895b19d7963  add rsp, 0x40
00007895b19d7967  vmovaps xmm0, [rsp]
00007895b19d796c  vmovaps xmm1, [rsp+0x10]
00007895b19d7972  vmovaps xmm2, [rsp+0x20]
00007895b19d7978  vmovaps xmm3, [rsp+0x30]
00007895b19d797e  vmovaps xmm4, [rsp+0x40]
00007895b19d7984  vmovaps xmm5, [rsp+0x50]
00007895b19d798a  vmovaps xmm6, [rsp+0x60]
00007895b19d7990  vmovaps xmm7, [rsp+0x70]
00007895b19d7996  vmovaps xmm8, [rsp+0x80]
00007895b19d799f  vmovaps xmm9, [rsp+0x90]
00007895b19d79a8  vmovaps xmm10, [rsp+0xA0]
00007895b19d79b1  vmovaps xmm11, [rsp+0xB0]
00007895b19d79ba  vmovaps xmm12, [rsp+0xC0]
00007895b19d79c3  vmovaps xmm14, [rsp+0xD0]
00007895b19d79cc  vmovaps xmm15, [rsp+0xE0]
00007895b19d79d5  add rsp, 0xF0
00007895b19d79dc  pop r11
00007895b19d79de  pop r10
00007895b19d79e0  pop r9
00007895b19d79e2  pop r8
00007895b19d79e4  pop rsi
00007895b19d79e5  pop rdi
00007895b19d79e6  pop rdx
00007895b19d79e7  pop rcx
00007895b19d79e8  pop rax
00007895b19d79e9  add rsp, 0x08
00007895b19d79ed  jmp 0x00007895B19D6C93
00007895b19d79f2  call 0x00007895B17FF430
00007895b19d79f7  jmp 0x00007895B19D6CA0
00007895b19d79fc  sub rsp, 0x08
00007895b19d7a00  push rax
00007895b19d7a01  push rcx
00007895b19d7a02  push rdx
00007895b19d7a03  push rdi
00007895b19d7a04  push rsi
00007895b19d7a05  push r8
00007895b19d7a07  push r9
00007895b19d7a09  push r10
00007895b19d7a0b  push r11
00007895b19d7a0d  sub rsp, 0xF0
00007895b19d7a14  vmovaps [rsp], xmm0
00007895b19d7a19  vmovaps [rsp+0x10], xmm1
00007895b19d7a1f  vmovaps [rsp+0x20], xmm2
00007895b19d7a25  vmovaps [rsp+0x30], xmm3
00007895b19d7a2b  vmovaps [rsp+0x40], xmm4
00007895b19d7a31  vmovaps [rsp+0x50], xmm5
00007895b19d7a37  vmovaps [rsp+0x60], xmm6
00007895b19d7a3d  vmovaps [rsp+0x70], xmm7
00007895b19d7a43  vmovaps [rsp+0x80], xmm8
00007895b19d7a4c  vmovaps [rsp+0x90], xmm9
00007895b19d7a55  vmovaps [rsp+0xA0], xmm10
00007895b19d7a5e  vmovaps [rsp+0xB0], xmm11
00007895b19d7a67  vmovaps [rsp+0xC0], xmm13
00007895b19d7a70  vmovaps [rsp+0xD0], xmm14
00007895b19d7a79  vmovaps [rsp+0xE0], xmm15
00007895b19d7a82  sub rsp, 0x40
00007895b19d7a86  lea rdi, [rsp]
00007895b19d7a8a  lea rsi, [rsp+0x10]
00007895b19d7a8f  lea rdx, [rsp+0x20]
00007895b19d7a94  lea rcx, [rsp+0x30]
00007895b19d7a99  mov r8d, 0x00
00007895b19d7a9f  lea r9, [r15+0x3A8]
00007895b19d7aa6  movaps [rdi], xmm12
00007895b19d7aaa  movaps [rsi], xmm15
00007895b19d7aae  movaps [rdx], xmm1
00007895b19d7ab1  movaps [rcx], xmm14
00007895b19d7ab5  mov rax, 0x59D4522A9A50
00007895b19d7abf  call rax
00007895b19d7ac1  movaps xmm12, [rsp]
00007895b19d7ac6  add rsp, 0x40
00007895b19d7aca  vmovaps xmm0, [rsp]
00007895b19d7acf  vmovaps xmm1, [rsp+0x10]
00007895b19d7ad5  vmovaps xmm2, [rsp+0x20]
00007895b19d7adb  vmovaps xmm3, [rsp+0x30]
00007895b19d7ae1  vmovaps xmm4, [rsp+0x40]
00007895b19d7ae7  vmovaps xmm5, [rsp+0x50]
00007895b19d7aed  vmovaps xmm6, [rsp+0x60]
00007895b19d7af3  vmovaps xmm7, [rsp+0x70]
00007895b19d7af9  vmovaps xmm8, [rsp+0x80]
00007895b19d7b02  vmovaps xmm9, [rsp+0x90]
00007895b19d7b0b  vmovaps xmm10, [rsp+0xA0]
00007895b19d7b14  vmovaps xmm11, [rsp+0xB0]
00007895b19d7b1d  vmovaps xmm13, [rsp+0xC0]
00007895b19d7b26  vmovaps xmm14, [rsp+0xD0]
00007895b19d7b2f  vmovaps xmm15, [rsp+0xE0]
00007895b19d7b38  add rsp, 0xF0
00007895b19d7b3f  pop r11
00007895b19d7b41  pop r10
00007895b19d7b43  pop r9
00007895b19d7b45  pop r8
00007895b19d7b47  pop rsi
00007895b19d7b48  pop rdi
00007895b19d7b49  pop rdx
00007895b19d7b4a  pop rcx
00007895b19d7b4b  pop rax
00007895b19d7b4c  add rsp, 0x08
00007895b19d7b50  jmp 0x00007895B19D6CCC
00007895b19d7b55  sub rsp, 0x08
00007895b19d7b59  push rax
00007895b19d7b5a  push rcx
00007895b19d7b5b  push rdx
00007895b19d7b5c  push rdi
00007895b19d7b5d  push rsi
00007895b19d7b5e  push r8
00007895b19d7b60  push r9
00007895b19d7b62  push r10
00007895b19d7b64  push r11
00007895b19d7b66  sub rsp, 0xF0
00007895b19d7b6d  vmovaps [rsp], xmm0
00007895b19d7b72  vmovaps [rsp+0x10], xmm1
00007895b19d7b78  vmovaps [rsp+0x20], xmm2
00007895b19d7b7e  vmovaps [rsp+0x30], xmm3
00007895b19d7b84  vmovaps [rsp+0x40], xmm4
00007895b19d7b8a  vmovaps [rsp+0x50], xmm5
00007895b19d7b90  vmovaps [rsp+0x60], xmm6
00007895b19d7b96  vmovaps [rsp+0x70], xmm7
00007895b19d7b9c  vmovaps [rsp+0x80], xmm8
00007895b19d7ba5  vmovaps [rsp+0x90], xmm9
00007895b19d7bae  vmovaps [rsp+0xA0], xmm10
00007895b19d7bb7  vmovaps [rsp+0xB0], xmm11
00007895b19d7bc0  vmovaps [rsp+0xC0], xmm12
00007895b19d7bc9  vmovaps [rsp+0xD0], xmm14
00007895b19d7bd2  vmovaps [rsp+0xE0], xmm15
00007895b19d7bdb  sub rsp, 0x40
00007895b19d7bdf  lea rdi, [rsp]
00007895b19d7be3  lea rsi, [rsp+0x10]
00007895b19d7be8  lea rdx, [rsp+0x20]
00007895b19d7bed  lea rcx, [rsp+0x30]
00007895b19d7bf2  mov r8d, 0x00
00007895b19d7bf8  lea r9, [r15+0x3A8]
00007895b19d7bff  movaps [rdi], xmm13
00007895b19d7c03  movaps [rsi], xmm1
00007895b19d7c06  movaps [rdx], xmm15
00007895b19d7c0a  movaps [rcx], xmm14
00007895b19d7c0e  mov rax, 0x59D4522A9A50
00007895b19d7c18  call rax
00007895b19d7c1a  movaps xmm13, [rsp]
00007895b19d7c1f  add rsp, 0x40
00007895b19d7c23  vmovaps xmm0, [rsp]
00007895b19d7c28  vmovaps xmm1, [rsp+0x10]
00007895b19d7c2e  vmovaps xmm2, [rsp+0x20]
00007895b19d7c34  vmovaps xmm3, [rsp+0x30]
00007895b19d7c3a  vmovaps xmm4, [rsp+0x40]
00007895b19d7c40  vmovaps xmm5, [rsp+0x50]
00007895b19d7c46  vmovaps xmm6, [rsp+0x60]
00007895b19d7c4c  vmovaps xmm7, [rsp+0x70]
00007895b19d7c52  vmovaps xmm8, [rsp+0x80]
00007895b19d7c5b  vmovaps xmm9, [rsp+0x90]
00007895b19d7c64  vmovaps xmm10, [rsp+0xA0]
00007895b19d7c6d  vmovaps xmm11, [rsp+0xB0]
00007895b19d7c76  vmovaps xmm12, [rsp+0xC0]
00007895b19d7c7f  vmovaps xmm14, [rsp+0xD0]
00007895b19d7c88  vmovaps xmm15, [rsp+0xE0]
00007895b19d7c91  add rsp, 0xF0
00007895b19d7c98  pop r11
00007895b19d7c9a  pop r10
00007895b19d7c9c  pop r9
00007895b19d7c9e  pop r8
00007895b19d7ca0  pop rsi
00007895b19d7ca1  pop rdi
00007895b19d7ca2  pop rdx
00007895b19d7ca3  pop rcx
00007895b19d7ca4  pop rax
00007895b19d7ca5  add rsp, 0x08
00007895b19d7ca9  jmp 0x00007895B19D6E6D
00007895b19d7cae  sub rsp, 0x08
00007895b19d7cb2  push rax
00007895b19d7cb3  push rcx
00007895b19d7cb4  push rdx
00007895b19d7cb5  push rdi
00007895b19d7cb6  push rsi
00007895b19d7cb7  push r8
00007895b19d7cb9  push r9
00007895b19d7cbb  push r10
00007895b19d7cbd  push r11
00007895b19d7cbf  sub rsp, 0xF0
00007895b19d7cc6  vmovaps [rsp], xmm0
00007895b19d7ccb  vmovaps [rsp+0x10], xmm1
00007895b19d7cd1  vmovaps [rsp+0x20], xmm2
00007895b19d7cd7  vmovaps [rsp+0x30], xmm3
00007895b19d7cdd  vmovaps [rsp+0x40], xmm4
00007895b19d7ce3  vmovaps [rsp+0x50], xmm5
00007895b19d7ce9  vmovaps [rsp+0x60], xmm6
00007895b19d7cef  vmovaps [rsp+0x70], xmm7
00007895b19d7cf5  vmovaps [rsp+0x80], xmm8
00007895b19d7cfe  vmovaps [rsp+0x90], xmm9
00007895b19d7d07  vmovaps [rsp+0xA0], xmm10
00007895b19d7d10  vmovaps [rsp+0xB0], xmm11
00007895b19d7d19  vmovaps [rsp+0xC0], xmm13
00007895b19d7d22  vmovaps [rsp+0xD0], xmm14
00007895b19d7d2b  vmovaps [rsp+0xE0], xmm15
00007895b19d7d34  sub rsp, 0x40
00007895b19d7d38  lea rdi, [rsp]
00007895b19d7d3c  lea rsi, [rsp+0x10]
00007895b19d7d41  lea rdx, [rsp+0x20]
00007895b19d7d46  lea rcx, [rsp+0x30]
00007895b19d7d4b  mov r8d, 0x00
00007895b19d7d51  lea r9, [r15+0x3A8]
00007895b19d7d58  movaps [rdi], xmm12
00007895b19d7d5c  movaps [rsi], xmm15
00007895b19d7d60  movaps [rdx], xmm14
00007895b19d7d64  movaps [rcx], xmm1
00007895b19d7d67  mov rax, 0x59D4522A9A50
00007895b19d7d71  call rax
00007895b19d7d73  movaps xmm12, [rsp]
00007895b19d7d78  add rsp, 0x40
00007895b19d7d7c  vmovaps xmm0, [rsp]
00007895b19d7d81  vmovaps xmm1, [rsp+0x10]
00007895b19d7d87  vmovaps xmm2, [rsp+0x20]
00007895b19d7d8d  vmovaps xmm3, [rsp+0x30]
00007895b19d7d93  vmovaps xmm4, [rsp+0x40]
00007895b19d7d99  vmovaps xmm5, [rsp+0x50]
00007895b19d7d9f  vmovaps xmm6, [rsp+0x60]
00007895b19d7da5  vmovaps xmm7, [rsp+0x70]
00007895b19d7dab  vmovaps xmm8, [rsp+0x80]
00007895b19d7db4  vmovaps xmm9, [rsp+0x90]
00007895b19d7dbd  vmovaps xmm10, [rsp+0xA0]
00007895b19d7dc6  vmovaps xmm11, [rsp+0xB0]
00007895b19d7dcf  vmovaps xmm13, [rsp+0xC0]
00007895b19d7dd8  vmovaps xmm14, [rsp+0xD0]
00007895b19d7de1  vmovaps xmm15, [rsp+0xE0]
00007895b19d7dea  add rsp, 0xF0
00007895b19d7df1  pop r11
00007895b19d7df3  pop r10
00007895b19d7df5  pop r9
00007895b19d7df7  pop r8
00007895b19d7df9  pop rsi
00007895b19d7dfa  pop rdi
00007895b19d7dfb  pop rdx
00007895b19d7dfc  pop rcx
00007895b19d7dfd  pop rax
00007895b19d7dfe  add rsp, 0x08
00007895b19d7e02  jmp 0x00007895B19D6EAB
00007895b19d7e07  sub rsp, 0x08
00007895b19d7e0b  push rax
00007895b19d7e0c  push rcx
00007895b19d7e0d  push rdx
00007895b19d7e0e  push rdi
00007895b19d7e0f  push rsi
00007895b19d7e10  push r8
00007895b19d7e12  push r9
00007895b19d7e14  push r10
00007895b19d7e16  push r11
00007895b19d7e18  sub rsp, 0xF0
00007895b19d7e1f  vmovaps [rsp], xmm0
00007895b19d7e24  vmovaps [rsp+0x10], xmm1
00007895b19d7e2a  vmovaps [rsp+0x20], xmm2
00007895b19d7e30  vmovaps [rsp+0x30], xmm3
00007895b19d7e36  vmovaps [rsp+0x40], xmm4
00007895b19d7e3c  vmovaps [rsp+0x50], xmm5
00007895b19d7e42  vmovaps [rsp+0x60], xmm6
00007895b19d7e48  vmovaps [rsp+0x70], xmm7
00007895b19d7e4e  vmovaps [rsp+0x80], xmm8
00007895b19d7e57  vmovaps [rsp+0x90], xmm9
00007895b19d7e60  vmovaps [rsp+0xA0], xmm10
00007895b19d7e69  vmovaps [rsp+0xB0], xmm11
00007895b19d7e72  vmovaps [rsp+0xC0], xmm12
00007895b19d7e7b  vmovaps [rsp+0xD0], xmm14
00007895b19d7e84  vmovaps [rsp+0xE0], xmm15
00007895b19d7e8d  sub rsp, 0x40
00007895b19d7e91  lea rdi, [rsp]
00007895b19d7e95  lea rsi, [rsp+0x10]
00007895b19d7e9a  lea rdx, [rsp+0x20]
00007895b19d7e9f  lea rcx, [rsp+0x30]
00007895b19d7ea4  mov r8d, 0x00
00007895b19d7eaa  lea r9, [r15+0x3A8]
00007895b19d7eb1  movaps [rdi], xmm13
00007895b19d7eb5  movaps [rsi], xmm15
00007895b19d7eb9  movaps [rdx], xmm14
00007895b19d7ebd  movaps [rcx], xmm1
00007895b19d7ec0  mov rax, 0x59D4522A9A50
00007895b19d7eca  call rax
00007895b19d7ecc  movaps xmm13, [rsp]
00007895b19d7ed1  add rsp, 0x40
00007895b19d7ed5  vmovaps xmm0, [rsp]
00007895b19d7eda  vmovaps xmm1, [rsp+0x10]
00007895b19d7ee0  vmovaps xmm2, [rsp+0x20]
00007895b19d7ee6  vmovaps xmm3, [rsp+0x30]
00007895b19d7eec  vmovaps xmm4, [rsp+0x40]
00007895b19d7ef2  vmovaps xmm5, [rsp+0x50]
00007895b19d7ef8  vmovaps xmm6, [rsp+0x60]
00007895b19d7efe  vmovaps xmm7, [rsp+0x70]
00007895b19d7f04  vmovaps xmm8, [rsp+0x80]
00007895b19d7f0d  vmovaps xmm9, [rsp+0x90]
00007895b19d7f16  vmovaps xmm10, [rsp+0xA0]
00007895b19d7f1f  vmovaps xmm11, [rsp+0xB0]
00007895b19d7f28  vmovaps xmm12, [rsp+0xC0]
00007895b19d7f31  vmovaps xmm14, [rsp+0xD0]
00007895b19d7f3a  vmovaps xmm15, [rsp+0xE0]
00007895b19d7f43  add rsp, 0xF0
00007895b19d7f4a  pop r11
00007895b19d7f4c  pop r10
00007895b19d7f4e  pop r9
00007895b19d7f50  pop r8
00007895b19d7f52  pop rsi
00007895b19d7f53  pop rdi
00007895b19d7f54  pop rdx
00007895b19d7f55  pop rcx
00007895b19d7f56  pop rax
00007895b19d7f57  add rsp, 0x08
00007895b19d7f5b  jmp 0x00007895B19D6EE9
00007895b19d7f60  sub rsp, 0x08
00007895b19d7f64  push rax
00007895b19d7f65  push rcx
00007895b19d7f66  push rdx
00007895b19d7f67  push rdi
00007895b19d7f68  push rsi
00007895b19d7f69  push r8
00007895b19d7f6b  push r9
00007895b19d7f6d  push r10
00007895b19d7f6f  push r11
00007895b19d7f71  sub rsp, 0xF0
00007895b19d7f78  vmovaps [rsp], xmm0
00007895b19d7f7d  vmovaps [rsp+0x10], xmm1
00007895b19d7f83  vmovaps [rsp+0x20], xmm2
00007895b19d7f89  vmovaps [rsp+0x30], xmm3
00007895b19d7f8f  vmovaps [rsp+0x40], xmm4
00007895b19d7f95  vmovaps [rsp+0x50], xmm5
00007895b19d7f9b  vmovaps [rsp+0x60], xmm6
00007895b19d7fa1  vmovaps [rsp+0x70], xmm7
00007895b19d7fa7  vmovaps [rsp+0x80], xmm8
00007895b19d7fb0  vmovaps [rsp+0x90], xmm9
00007895b19d7fb9  vmovaps [rsp+0xA0], xmm10
00007895b19d7fc2  vmovaps [rsp+0xB0], xmm11
00007895b19d7fcb  vmovaps [rsp+0xC0], xmm13
00007895b19d7fd4  vmovaps [rsp+0xD0], xmm14
00007895b19d7fdd  vmovaps [rsp+0xE0], xmm15
00007895b19d7fe6  sub rsp, 0x40
00007895b19d7fea  lea rdi, [rsp]
00007895b19d7fee  lea rsi, [rsp+0x10]
00007895b19d7ff3  lea rdx, [rsp+0x20]
00007895b19d7ff8  lea rcx, [rsp+0x30]
00007895b19d7ffd  mov r8d, 0x00
00007895b19d8003  lea r9, [r15+0x3A8]
00007895b19d800a  movaps [rdi], xmm12
00007895b19d800e  movaps [rsi], xmm14
00007895b19d8012  movaps [rdx], xmm2
00007895b19d8015  movaps [rcx], xmm15
00007895b19d8019  mov rax, 0x59D4522A9A50
00007895b19d8023  call rax
00007895b19d8025  movaps xmm12, [rsp]
00007895b19d802a  add rsp, 0x40
00007895b19d802e  vmovaps xmm0, [rsp]
00007895b19d8033  vmovaps xmm1, [rsp+0x10]
00007895b19d8039  vmovaps xmm2, [rsp+0x20]
00007895b19d803f  vmovaps xmm3, [rsp+0x30]
00007895b19d8045  vmovaps xmm4, [rsp+0x40]
00007895b19d804b  vmovaps xmm5, [rsp+0x50]
00007895b19d8051  vmovaps xmm6, [rsp+0x60]
00007895b19d8057  vmovaps xmm7, [rsp+0x70]
00007895b19d805d  vmovaps xmm8, [rsp+0x80]
00007895b19d8066  vmovaps xmm9, [rsp+0x90]
00007895b19d806f  vmovaps xmm10, [rsp+0xA0]
00007895b19d8078  vmovaps xmm11, [rsp+0xB0]
00007895b19d8081  vmovaps xmm13, [rsp+0xC0]
00007895b19d808a  vmovaps xmm14, [rsp+0xD0]
00007895b19d8093  vmovaps xmm15, [rsp+0xE0]
00007895b19d809c  add rsp, 0xF0
00007895b19d80a3  pop r11
00007895b19d80a5  pop r10
00007895b19d80a7  pop r9
00007895b19d80a9  pop r8
00007895b19d80ab  pop rsi
00007895b19d80ac  pop rdi
00007895b19d80ad  pop rdx
00007895b19d80ae  pop rcx
00007895b19d80af  pop rax
00007895b19d80b0  add rsp, 0x08
00007895b19d80b4  jmp 0x00007895B19D6F43
00007895b19d80b9  sub rsp, 0x08
00007895b19d80bd  push rax
00007895b19d80be  push rcx
00007895b19d80bf  push rdx
00007895b19d80c0  push rdi
00007895b19d80c1  push rsi
00007895b19d80c2  push r8
00007895b19d80c4  push r9
00007895b19d80c6  push r10
00007895b19d80c8  push r11
00007895b19d80ca  sub rsp, 0xF0
00007895b19d80d1  vmovaps [rsp], xmm0
00007895b19d80d6  vmovaps [rsp+0x10], xmm1
00007895b19d80dc  vmovaps [rsp+0x20], xmm3
00007895b19d80e2  vmovaps [rsp+0x30], xmm4
00007895b19d80e8  vmovaps [rsp+0x40], xmm5
00007895b19d80ee  vmovaps [rsp+0x50], xmm6
00007895b19d80f4  vmovaps [rsp+0x60], xmm7
00007895b19d80fa  vmovaps [rsp+0x70], xmm8
00007895b19d8100  vmovaps [rsp+0x80], xmm9
00007895b19d8109  vmovaps [rsp+0x90], xmm10
00007895b19d8112  vmovaps [rsp+0xA0], xmm11
00007895b19d811b  vmovaps [rsp+0xB0], xmm12
00007895b19d8124  vmovaps [rsp+0xC0], xmm13
00007895b19d812d  vmovaps [rsp+0xD0], xmm14
00007895b19d8136  vmovaps [rsp+0xE0], xmm15
00007895b19d813f  sub rsp, 0x40
00007895b19d8143  lea rdi, [rsp]
00007895b19d8147  lea rsi, [rsp+0x10]
00007895b19d814c  lea rdx, [rsp+0x20]
00007895b19d8151  lea rcx, [rsp+0x30]
00007895b19d8156  mov r8d, 0x00
00007895b19d815c  lea r9, [r15+0x3A8]
00007895b19d8163  movaps [rdi], xmm2
00007895b19d8166  movaps [rsi], xmm14
00007895b19d816a  movaps [rdx], xmm8
00007895b19d816e  movaps [rcx], xmm5
00007895b19d8171  mov rax, 0x59D4522A9A50
00007895b19d817b  call rax
00007895b19d817d  movaps xmm2, [rsp]
00007895b19d8181  add rsp, 0x40
00007895b19d8185  vmovaps xmm0, [rsp]
00007895b19d818a  vmovaps xmm1, [rsp+0x10]
00007895b19d8190  vmovaps xmm3, [rsp+0x20]
00007895b19d8196  vmovaps xmm4, [rsp+0x30]
00007895b19d819c  vmovaps xmm5, [rsp+0x40]
00007895b19d81a2  vmovaps xmm6, [rsp+0x50]
00007895b19d81a8  vmovaps xmm7, [rsp+0x60]
00007895b19d81ae  vmovaps xmm8, [rsp+0x70]
00007895b19d81b4  vmovaps xmm9, [rsp+0x80]
00007895b19d81bd  vmovaps xmm10, [rsp+0x90]
00007895b19d81c6  vmovaps xmm11, [rsp+0xA0]
00007895b19d81cf  vmovaps xmm12, [rsp+0xB0]
00007895b19d81d8  vmovaps xmm13, [rsp+0xC0]
00007895b19d81e1  vmovaps xmm14, [rsp+0xD0]
00007895b19d81ea  vmovaps xmm15, [rsp+0xE0]
00007895b19d81f3  add rsp, 0xF0
00007895b19d81fa  pop r11
00007895b19d81fc  pop r10
00007895b19d81fe  pop r9
00007895b19d8200  pop r8
00007895b19d8202  pop rsi
00007895b19d8203  pop rdi
00007895b19d8204  pop rdx
00007895b19d8205  pop rcx
00007895b19d8206  pop rax
00007895b19d8207  add rsp, 0x08
00007895b19d820b  jmp 0x00007895B19D6FF7
00007895b19d8210  sub rsp, 0x08
00007895b19d8214  push rax
00007895b19d8215  push rcx
00007895b19d8216  push rdx
00007895b19d8217  push rdi
00007895b19d8218  push rsi
00007895b19d8219  push r8
00007895b19d821b  push r9
00007895b19d821d  push r10
00007895b19d821f  push r11
00007895b19d8221  sub rsp, 0xF0
00007895b19d8228  vmovaps [rsp], xmm0
00007895b19d822d  vmovaps [rsp+0x10], xmm1
00007895b19d8233  vmovaps [rsp+0x20], xmm2
00007895b19d8239  vmovaps [rsp+0x30], xmm3
00007895b19d823f  vmovaps [rsp+0x40], xmm4
00007895b19d8245  vmovaps [rsp+0x50], xmm6
00007895b19d824b  vmovaps [rsp+0x60], xmm7
00007895b19d8251  vmovaps [rsp+0x70], xmm8
00007895b19d8257  vmovaps [rsp+0x80], xmm9
00007895b19d8260  vmovaps [rsp+0x90], xmm10
00007895b19d8269  vmovaps [rsp+0xA0], xmm11
00007895b19d8272  vmovaps [rsp+0xB0], xmm12
00007895b19d827b  vmovaps [rsp+0xC0], xmm13
00007895b19d8284  vmovaps [rsp+0xD0], xmm14
00007895b19d828d  vmovaps [rsp+0xE0], xmm15
00007895b19d8296  sub rsp, 0x40
00007895b19d829a  lea rdi, [rsp]
00007895b19d829e  lea rsi, [rsp+0x10]
00007895b19d82a3  lea rdx, [rsp+0x20]
00007895b19d82a8  lea rcx, [rsp+0x30]
00007895b19d82ad  mov r8d, 0x00
00007895b19d82b3  lea r9, [r15+0x3A8]
00007895b19d82ba  movaps [rdi], xmm5
00007895b19d82bd  movaps [rsi], xmm14
00007895b19d82c1  movaps [rdx], xmm8
00007895b19d82c5  movaps [rcx], xmm1
00007895b19d82c8  mov rax, 0x59D4522A9A50
00007895b19d82d2  call rax
00007895b19d82d4  movaps xmm5, [rsp]
00007895b19d82d8  add rsp, 0x40
00007895b19d82dc  vmovaps xmm0, [rsp]
00007895b19d82e1  vmovaps xmm1, [rsp+0x10]
00007895b19d82e7  vmovaps xmm2, [rsp+0x20]
00007895b19d82ed  vmovaps xmm3, [rsp+0x30]
00007895b19d82f3  vmovaps xmm4, [rsp+0x40]
00007895b19d82f9  vmovaps xmm6, [rsp+0x50]
00007895b19d82ff  vmovaps xmm7, [rsp+0x60]
00007895b19d8305  vmovaps xmm8, [rsp+0x70]
00007895b19d830b  vmovaps xmm9, [rsp+0x80]
00007895b19d8314  vmovaps xmm10, [rsp+0x90]
00007895b19d831d  vmovaps xmm11, [rsp+0xA0]
00007895b19d8326  vmovaps xmm12, [rsp+0xB0]
00007895b19d832f  vmovaps xmm13, [rsp+0xC0]
00007895b19d8338  vmovaps xmm14, [rsp+0xD0]
00007895b19d8341  vmovaps xmm15, [rsp+0xE0]
00007895b19d834a  add rsp, 0xF0
00007895b19d8351  pop r11
00007895b19d8353  pop r10
00007895b19d8355  pop r9
00007895b19d8357  pop r8
00007895b19d8359  pop rsi
00007895b19d835a  pop rdi
00007895b19d835b  pop rdx
00007895b19d835c  pop rcx
00007895b19d835d  pop rax
00007895b19d835e  add rsp, 0x08
00007895b19d8362  jmp 0x00007895B19D7034
00007895b19d8367  sub rsp, 0x08
00007895b19d836b  push rax
00007895b19d836c  push rcx
00007895b19d836d  push rdx
00007895b19d836e  push rdi
00007895b19d836f  push rsi
00007895b19d8370  push r8
00007895b19d8372  push r9
00007895b19d8374  push r10
00007895b19d8376  push r11
00007895b19d8378  sub rsp, 0xF0
00007895b19d837f  vmovaps [rsp], xmm0
00007895b19d8384  vmovaps [rsp+0x10], xmm1
00007895b19d838a  vmovaps [rsp+0x20], xmm2
00007895b19d8390  vmovaps [rsp+0x30], xmm3
00007895b19d8396  vmovaps [rsp+0x40], xmm4
00007895b19d839c  vmovaps [rsp+0x50], xmm5
00007895b19d83a2  vmovaps [rsp+0x60], xmm6
00007895b19d83a8  vmovaps [rsp+0x70], xmm7
00007895b19d83ae  vmovaps [rsp+0x80], xmm8
00007895b19d83b7  vmovaps [rsp+0x90], xmm9
00007895b19d83c0  vmovaps [rsp+0xA0], xmm10
00007895b19d83c9  vmovaps [rsp+0xB0], xmm11
00007895b19d83d2  vmovaps [rsp+0xC0], xmm12
00007895b19d83db  vmovaps [rsp+0xD0], xmm13
00007895b19d83e4  vmovaps [rsp+0xE0], xmm14
00007895b19d83ed  sub rsp, 0x40
00007895b19d83f1  lea rdi, [rsp]
00007895b19d83f5  lea rsi, [rsp+0x10]
00007895b19d83fa  lea rdx, [rsp+0x20]
00007895b19d83ff  lea rcx, [rsp+0x30]
00007895b19d8404  mov r8d, 0x00
00007895b19d840a  lea r9, [r15+0x3A8]
00007895b19d8411  movaps [rdi], xmm15
00007895b19d8415  movaps [rsi], xmm13
00007895b19d8419  movaps [rdx], xmm14
00007895b19d841d  movaps [rcx], xmm1
00007895b19d8420  mov rax, 0x59D4522A9A50
00007895b19d842a  call rax
00007895b19d842c  movaps xmm15, [rsp]
00007895b19d8431  add rsp, 0x40
00007895b19d8435  vmovaps xmm0, [rsp]
00007895b19d843a  vmovaps xmm1, [rsp+0x10]
00007895b19d8440  vmovaps xmm2, [rsp+0x20]
00007895b19d8446  vmovaps xmm3, [rsp+0x30]
00007895b19d844c  vmovaps xmm4, [rsp+0x40]
00007895b19d8452  vmovaps xmm5, [rsp+0x50]
00007895b19d8458  vmovaps xmm6, [rsp+0x60]
00007895b19d845e  vmovaps xmm7, [rsp+0x70]
00007895b19d8464  vmovaps xmm8, [rsp+0x80]
00007895b19d846d  vmovaps xmm9, [rsp+0x90]
00007895b19d8476  vmovaps xmm10, [rsp+0xA0]
00007895b19d847f  vmovaps xmm11, [rsp+0xB0]
00007895b19d8488  vmovaps xmm12, [rsp+0xC0]
00007895b19d8491  vmovaps xmm13, [rsp+0xD0]
00007895b19d849a  vmovaps xmm14, [rsp+0xE0]
00007895b19d84a3  add rsp, 0xF0
00007895b19d84aa  pop r11
00007895b19d84ac  pop r10
00007895b19d84ae  pop r9
00007895b19d84b0  pop r8
00007895b19d84b2  pop rsi
00007895b19d84b3  pop rdi
00007895b19d84b4  pop rdx
00007895b19d84b5  pop rcx
00007895b19d84b6  pop rax
00007895b19d84b7  add rsp, 0x08
00007895b19d84bb  jmp 0x00007895B19D7063
00007895b19d84c0  sub rsp, 0x08
00007895b19d84c4  push rax
00007895b19d84c5  push rcx
00007895b19d84c6  push rdx
00007895b19d84c7  push rdi
00007895b19d84c8  push rsi
00007895b19d84c9  push r8
00007895b19d84cb  push r9
00007895b19d84cd  push r10
00007895b19d84cf  push r11
00007895b19d84d1  sub rsp, 0xF0
00007895b19d84d8  vmovaps [rsp], xmm0
00007895b19d84dd  vmovaps [rsp+0x10], xmm1
00007895b19d84e3  vmovaps [rsp+0x20], xmm2
00007895b19d84e9  vmovaps [rsp+0x30], xmm3
00007895b19d84ef  vmovaps [rsp+0x40], xmm4
00007895b19d84f5  vmovaps [rsp+0x50], xmm5
00007895b19d84fb  vmovaps [rsp+0x60], xmm6
00007895b19d8501  vmovaps [rsp+0x70], xmm7
00007895b19d8507  vmovaps [rsp+0x80], xmm8
00007895b19d8510  vmovaps [rsp+0x90], xmm9
00007895b19d8519  vmovaps [rsp+0xA0], xmm10
00007895b19d8522  vmovaps [rsp+0xB0], xmm11
00007895b19d852b  vmovaps [rsp+0xC0], xmm12
00007895b19d8534  vmovaps [rsp+0xD0], xmm14
00007895b19d853d  vmovaps [rsp+0xE0], xmm15
00007895b19d8546  sub rsp, 0x40
00007895b19d854a  lea rdi, [rsp]
00007895b19d854e  lea rsi, [rsp+0x10]
00007895b19d8553  lea rdx, [rsp+0x20]
00007895b19d8558  lea rcx, [rsp+0x30]
00007895b19d855d  mov r8d, 0x00
00007895b19d8563  lea r9, [r15+0x3A8]
00007895b19d856a  movaps [rdi], xmm13
00007895b19d856e  movaps [rsi], xmm12
00007895b19d8572  movaps [rdx], xmm14
00007895b19d8576  movaps [rcx], xmm1
00007895b19d8579  mov rax, 0x59D4522A9A50
00007895b19d8583  call rax
00007895b19d8585  movaps xmm13, [rsp]
00007895b19d858a  add rsp, 0x40
00007895b19d858e  vmovaps xmm0, [rsp]
00007895b19d8593  vmovaps xmm1, [rsp+0x10]
00007895b19d8599  vmovaps xmm2, [rsp+0x20]
00007895b19d859f  vmovaps xmm3, [rsp+0x30]
00007895b19d85a5  vmovaps xmm4, [rsp+0x40]
00007895b19d85ab  vmovaps xmm5, [rsp+0x50]
00007895b19d85b1  vmovaps xmm6, [rsp+0x60]
00007895b19d85b7  vmovaps xmm7, [rsp+0x70]
00007895b19d85bd  vmovaps xmm8, [rsp+0x80]
00007895b19d85c6  vmovaps xmm9, [rsp+0x90]
00007895b19d85cf  vmovaps xmm10, [rsp+0xA0]
00007895b19d85d8  vmovaps xmm11, [rsp+0xB0]
00007895b19d85e1  vmovaps xmm12, [rsp+0xC0]
00007895b19d85ea  vmovaps xmm14, [rsp+0xD0]
00007895b19d85f3  vmovaps xmm15, [rsp+0xE0]
00007895b19d85fc  add rsp, 0xF0
00007895b19d8603  pop r11
00007895b19d8605  pop r10
00007895b19d8607  pop r9
00007895b19d8609  pop r8
00007895b19d860b  pop rsi
00007895b19d860c  pop rdi
00007895b19d860d  pop rdx
00007895b19d860e  pop rcx
00007895b19d860f  pop rax
00007895b19d8610  add rsp, 0x08
00007895b19d8614  jmp 0x00007895B19D7095
00007895b19d8619  sub rsp, 0x08
00007895b19d861d  push rax
00007895b19d861e  push rcx
00007895b19d861f  push rdx
00007895b19d8620  push rdi
00007895b19d8621  push rsi
00007895b19d8622  push r8
00007895b19d8624  push r9
00007895b19d8626  push r10
00007895b19d8628  push r11
00007895b19d862a  sub rsp, 0xF0
00007895b19d8631  vmovaps [rsp], xmm0
00007895b19d8636  vmovaps [rsp+0x10], xmm1
00007895b19d863c  vmovaps [rsp+0x20], xmm2
00007895b19d8642  vmovaps [rsp+0x30], xmm3
00007895b19d8648  vmovaps [rsp+0x40], xmm4
00007895b19d864e  vmovaps [rsp+0x50], xmm5
00007895b19d8654  vmovaps [rsp+0x60], xmm6
00007895b19d865a  vmovaps [rsp+0x70], xmm7
00007895b19d8660  vmovaps [rsp+0x80], xmm8
00007895b19d8669  vmovaps [rsp+0x90], xmm9
00007895b19d8672  vmovaps [rsp+0xA0], xmm10
00007895b19d867b  vmovaps [rsp+0xB0], xmm11
00007895b19d8684  vmovaps [rsp+0xC0], xmm13
00007895b19d868d  vmovaps [rsp+0xD0], xmm14
00007895b19d8696  vmovaps [rsp+0xE0], xmm15
00007895b19d869f  sub rsp, 0x40
00007895b19d86a3  lea rdi, [rsp]
00007895b19d86a7  lea rsi, [rsp+0x10]
00007895b19d86ac  lea rdx, [rsp+0x20]
00007895b19d86b1  lea rcx, [rsp+0x30]
00007895b19d86b6  mov r8d, 0x00
00007895b19d86bc  lea r9, [r15+0x3A8]
00007895b19d86c3  movaps [rdi], xmm12
00007895b19d86c7  movaps [rsi], xmm5
00007895b19d86ca  movaps [rdx], xmm14
00007895b19d86ce  movaps [rcx], xmm4
00007895b19d86d1  mov rax, 0x59D4522A9A50
00007895b19d86db  call rax
00007895b19d86dd  movaps xmm12, [rsp]
00007895b19d86e2  add rsp, 0x40
00007895b19d86e6  vmovaps xmm0, [rsp]
00007895b19d86eb  vmovaps xmm1, [rsp+0x10]
00007895b19d86f1  vmovaps xmm2, [rsp+0x20]
00007895b19d86f7  vmovaps xmm3, [rsp+0x30]
00007895b19d86fd  vmovaps xmm4, [rsp+0x40]
00007895b19d8703  vmovaps xmm5, [rsp+0x50]
00007895b19d8709  vmovaps xmm6, [rsp+0x60]
00007895b19d870f  vmovaps xmm7, [rsp+0x70]
00007895b19d8715  vmovaps xmm8, [rsp+0x80]
00007895b19d871e  vmovaps xmm9, [rsp+0x90]
00007895b19d8727  vmovaps xmm10, [rsp+0xA0]
00007895b19d8730  vmovaps xmm11, [rsp+0xB0]
00007895b19d8739  vmovaps xmm13, [rsp+0xC0]
00007895b19d8742  vmovaps xmm14, [rsp+0xD0]
00007895b19d874b  vmovaps xmm15, [rsp+0xE0]
00007895b19d8754  add rsp, 0xF0
00007895b19d875b  pop r11
00007895b19d875d  pop r10
00007895b19d875f  pop r9
00007895b19d8761  pop r8
00007895b19d8763  pop rsi
00007895b19d8764  pop rdi
00007895b19d8765  pop rdx
00007895b19d8766  pop rcx
00007895b19d8767  pop rax
00007895b19d8768  add rsp, 0x08
00007895b19d876c  jmp 0x00007895B19D710B
00007895b19d8771  sub rsp, 0x08
00007895b19d8775  push rax
00007895b19d8776  push rcx
00007895b19d8777  push rdx
00007895b19d8778  push rdi
00007895b19d8779  push rsi
00007895b19d877a  push r8
00007895b19d877c  push r9
00007895b19d877e  push r10
00007895b19d8780  push r11
00007895b19d8782  sub rsp, 0xF0
00007895b19d8789  vmovaps [rsp], xmm0
00007895b19d878e  vmovaps [rsp+0x10], xmm1
00007895b19d8794  vmovaps [rsp+0x20], xmm2
00007895b19d879a  vmovaps [rsp+0x30], xmm3
00007895b19d87a0  vmovaps [rsp+0x40], xmm4
00007895b19d87a6  vmovaps [rsp+0x50], xmm5
00007895b19d87ac  vmovaps [rsp+0x60], xmm6
00007895b19d87b2  vmovaps [rsp+0x70], xmm7
00007895b19d87b8  vmovaps [rsp+0x80], xmm8
00007895b19d87c1  vmovaps [rsp+0x90], xmm9
00007895b19d87ca  vmovaps [rsp+0xA0], xmm11
00007895b19d87d3  vmovaps [rsp+0xB0], xmm12
00007895b19d87dc  vmovaps [rsp+0xC0], xmm13
00007895b19d87e5  vmovaps [rsp+0xD0], xmm14
00007895b19d87ee  vmovaps [rsp+0xE0], xmm15
00007895b19d87f7  sub rsp, 0x40
00007895b19d87fb  lea rdi, [rsp]
00007895b19d87ff  lea rsi, [rsp+0x10]
00007895b19d8804  lea rdx, [rsp+0x20]
00007895b19d8809  lea rcx, [rsp+0x30]
00007895b19d880e  mov r8d, 0x00
00007895b19d8814  lea r9, [r15+0x3A8]
00007895b19d881b  movaps [rdi], xmm10
00007895b19d881f  movaps [rsi], xmm2
00007895b19d8822  movaps [rdx], xmm6
00007895b19d8825  movaps [rcx], xmm14
00007895b19d8829  mov rax, 0x59D4522A9A50
00007895b19d8833  call rax
00007895b19d8835  movaps xmm10, [rsp]
00007895b19d883a  add rsp, 0x40
00007895b19d883e  vmovaps xmm0, [rsp]
00007895b19d8843  vmovaps xmm1, [rsp+0x10]
00007895b19d8849  vmovaps xmm2, [rsp+0x20]
00007895b19d884f  vmovaps xmm3, [rsp+0x30]
00007895b19d8855  vmovaps xmm4, [rsp+0x40]
00007895b19d885b  vmovaps xmm5, [rsp+0x50]
00007895b19d8861  vmovaps xmm6, [rsp+0x60]
00007895b19d8867  vmovaps xmm7, [rsp+0x70]
00007895b19d886d  vmovaps xmm8, [rsp+0x80]
00007895b19d8876  vmovaps xmm9, [rsp+0x90]
00007895b19d887f  vmovaps xmm11, [rsp+0xA0]
00007895b19d8888  vmovaps xmm12, [rsp+0xB0]
00007895b19d8891  vmovaps xmm13, [rsp+0xC0]
00007895b19d889a  vmovaps xmm14, [rsp+0xD0]
00007895b19d88a3  vmovaps xmm15, [rsp+0xE0]
00007895b19d88ac  add rsp, 0xF0
00007895b19d88b3  pop r11
00007895b19d88b5  pop r10
00007895b19d88b7  pop r9
00007895b19d88b9  pop r8
00007895b19d88bb  pop rsi
00007895b19d88bc  pop rdi
00007895b19d88bd  pop rdx
00007895b19d88be  pop rcx
00007895b19d88bf  pop rax
00007895b19d88c0  add rsp, 0x08
00007895b19d88c4  jmp 0x00007895B19D7131
00007895b19d88c9  call 0x00007895B180D4E0
00007895b19d88ce  jmp 0x00007895B19D713E
00007895b19d88d3  sub rsp, 0x08
00007895b19d88d7  push rax
00007895b19d88d8  push rcx
00007895b19d88d9  push rdx
00007895b19d88da  push rdi
00007895b19d88db  push rsi
00007895b19d88dc  push r8
00007895b19d88de  push r9
00007895b19d88e0  push r10
00007895b19d88e2  push r11
00007895b19d88e4  sub rsp, 0xF0
00007895b19d88eb  vmovaps [rsp], xmm0
00007895b19d88f0  vmovaps [rsp+0x10], xmm1
00007895b19d88f6  vmovaps [rsp+0x20], xmm2
00007895b19d88fc  vmovaps [rsp+0x30], xmm3
00007895b19d8902  vmovaps [rsp+0x40], xmm4
00007895b19d8908  vmovaps [rsp+0x50], xmm6
00007895b19d890e  vmovaps [rsp+0x60], xmm7
00007895b19d8914  vmovaps [rsp+0x70], xmm8
00007895b19d891a  vmovaps [rsp+0x80], xmm9
00007895b19d8923  vmovaps [rsp+0x90], xmm10
00007895b19d892c  vmovaps [rsp+0xA0], xmm11
00007895b19d8935  vmovaps [rsp+0xB0], xmm12
00007895b19d893e  vmovaps [rsp+0xC0], xmm13
00007895b19d8947  vmovaps [rsp+0xD0], xmm14
00007895b19d8950  vmovaps [rsp+0xE0], xmm15
00007895b19d8959  sub rsp, 0x40
00007895b19d895d  lea rdi, [rsp]
00007895b19d8961  lea rsi, [rsp+0x10]
00007895b19d8966  lea rdx, [rsp+0x20]
00007895b19d896b  lea rcx, [rsp+0x30]
00007895b19d8970  mov r8d, 0x00
00007895b19d8976  lea r9, [r15+0x3A8]
00007895b19d897d  movaps [rdi], xmm5
00007895b19d8980  movaps [rsi], xmm15
00007895b19d8984  movaps [rdx], xmm6
00007895b19d8987  movaps [rcx], xmm8
00007895b19d898b  mov rax, 0x59D4522A9A50
00007895b19d8995  call rax
00007895b19d8997  movaps xmm5, [rsp]
00007895b19d899b  add rsp, 0x40
00007895b19d899f  vmovaps xmm0, [rsp]
00007895b19d89a4  vmovaps xmm1, [rsp+0x10]
00007895b19d89aa  vmovaps xmm2, [rsp+0x20]
00007895b19d89b0  vmovaps xmm3, [rsp+0x30]
00007895b19d89b6  vmovaps xmm4, [rsp+0x40]
00007895b19d89bc  vmovaps xmm6, [rsp+0x50]
00007895b19d89c2  vmovaps xmm7, [rsp+0x60]
00007895b19d89c8  vmovaps xmm8, [rsp+0x70]
00007895b19d89ce  vmovaps xmm9, [rsp+0x80]
00007895b19d89d7  vmovaps xmm10, [rsp+0x90]
00007895b19d89e0  vmovaps xmm11, [rsp+0xA0]
00007895b19d89e9  vmovaps xmm12, [rsp+0xB0]
00007895b19d89f2  vmovaps xmm13, [rsp+0xC0]
00007895b19d89fb  vmovaps xmm14, [rsp+0xD0]
00007895b19d8a04  vmovaps xmm15, [rsp+0xE0]
00007895b19d8a0d  add rsp, 0xF0
00007895b19d8a14  pop r11
00007895b19d8a16  pop r10
00007895b19d8a18  pop r9
00007895b19d8a1a  pop r8
00007895b19d8a1c  pop rsi
00007895b19d8a1d  pop rdi
00007895b19d8a1e  pop rdx
00007895b19d8a1f  pop rcx
00007895b19d8a20  pop rax
00007895b19d8a21  add rsp, 0x08
00007895b19d8a25  jmp 0x00007895B19D7174
00007895b19d8a2a  sub rsp, 0x08
00007895b19d8a2e  push rax
00007895b19d8a2f  push rcx
00007895b19d8a30  push rdx
00007895b19d8a31  push rdi
00007895b19d8a32  push rsi
00007895b19d8a33  push r8
00007895b19d8a35  push r9
00007895b19d8a37  push r10
00007895b19d8a39  push r11
00007895b19d8a3b  sub rsp, 0xF0
00007895b19d8a42  vmovaps [rsp], xmm0
00007895b19d8a47  vmovaps [rsp+0x10], xmm1
00007895b19d8a4d  vmovaps [rsp+0x20], xmm2
00007895b19d8a53  vmovaps [rsp+0x30], xmm3
00007895b19d8a59  vmovaps [rsp+0x40], xmm4
00007895b19d8a5f  vmovaps [rsp+0x50], xmm5
00007895b19d8a65  vmovaps [rsp+0x60], xmm6
00007895b19d8a6b  vmovaps [rsp+0x70], xmm7
00007895b19d8a71  vmovaps [rsp+0x80], xmm9
00007895b19d8a7a  vmovaps [rsp+0x90], xmm10
00007895b19d8a83  vmovaps [rsp+0xA0], xmm11
00007895b19d8a8c  vmovaps [rsp+0xB0], xmm12
00007895b19d8a95  vmovaps [rsp+0xC0], xmm13
00007895b19d8a9e  vmovaps [rsp+0xD0], xmm14
00007895b19d8aa7  vmovaps [rsp+0xE0], xmm15
00007895b19d8ab0  sub rsp, 0x40
00007895b19d8ab4  lea rdi, [rsp]
00007895b19d8ab8  lea rsi, [rsp+0x10]
00007895b19d8abd  lea rdx, [rsp+0x20]
00007895b19d8ac2  lea rcx, [rsp+0x30]
00007895b19d8ac7  mov r8d, 0x00
00007895b19d8acd  lea r9, [r15+0x3A8]
00007895b19d8ad4  movaps [rdi], xmm8
00007895b19d8ad8  movaps [rsi], xmm13
00007895b19d8adc  movaps [rdx], xmm1
00007895b19d8adf  movaps [rcx], xmm15
00007895b19d8ae3  mov rax, 0x59D4522A9A50
00007895b19d8aed  call rax
00007895b19d8aef  movaps xmm8, [rsp]
00007895b19d8af4  add rsp, 0x40
00007895b19d8af8  vmovaps xmm0, [rsp]
00007895b19d8afd  vmovaps xmm1, [rsp+0x10]
00007895b19d8b03  vmovaps xmm2, [rsp+0x20]
00007895b19d8b09  vmovaps xmm3, [rsp+0x30]
00007895b19d8b0f  vmovaps xmm4, [rsp+0x40]
00007895b19d8b15  vmovaps xmm5, [rsp+0x50]
00007895b19d8b1b  vmovaps xmm6, [rsp+0x60]
00007895b19d8b21  vmovaps xmm7, [rsp+0x70]
00007895b19d8b27  vmovaps xmm9, [rsp+0x80]
00007895b19d8b30  vmovaps xmm10, [rsp+0x90]
00007895b19d8b39  vmovaps xmm11, [rsp+0xA0]
00007895b19d8b42  vmovaps xmm12, [rsp+0xB0]
00007895b19d8b4b  vmovaps xmm13, [rsp+0xC0]
00007895b19d8b54  vmovaps xmm14, [rsp+0xD0]
00007895b19d8b5d  vmovaps xmm15, [rsp+0xE0]
00007895b19d8b66  add rsp, 0xF0
00007895b19d8b6d  pop r11
00007895b19d8b6f  pop r10
00007895b19d8b71  pop r9
00007895b19d8b73  pop r8
00007895b19d8b75  pop rsi
00007895b19d8b76  pop rdi
00007895b19d8b77  pop rdx
00007895b19d8b78  pop rcx
00007895b19d8b79  pop rax
00007895b19d8b7a  add rsp, 0x08
00007895b19d8b7e  jmp 0x00007895B19D719A
00007895b19d8b83  call 0x00007895B180E760
00007895b19d8b88  jmp 0x00007895B19D71BD
00007895b19d8b8d  call 0x00007895B180C260
00007895b19d8b92  jmp 0x00007895B19D71C7
00007895b19d8b97  sub rsp, 0x08
00007895b19d8b9b  push rax
00007895b19d8b9c  push rcx
00007895b19d8b9d  push rdx
00007895b19d8b9e  push rdi
00007895b19d8b9f  push rsi
00007895b19d8ba0  push r8
00007895b19d8ba2  push r9
00007895b19d8ba4  push r10
00007895b19d8ba6  push r11
00007895b19d8ba8  sub rsp, 0xF0
00007895b19d8baf  vmovaps [rsp], xmm0
00007895b19d8bb4  vmovaps [rsp+0x10], xmm1
00007895b19d8bba  vmovaps [rsp+0x20], xmm2
00007895b19d8bc0  vmovaps [rsp+0x30], xmm3
00007895b19d8bc6  vmovaps [rsp+0x40], xmm5
00007895b19d8bcc  vmovaps [rsp+0x50], xmm6
00007895b19d8bd2  vmovaps [rsp+0x60], xmm7
00007895b19d8bd8  vmovaps [rsp+0x70], xmm8
00007895b19d8bde  vmovaps [rsp+0x80], xmm9
00007895b19d8be7  vmovaps [rsp+0x90], xmm10
00007895b19d8bf0  vmovaps [rsp+0xA0], xmm11
00007895b19d8bf9  vmovaps [rsp+0xB0], xmm12
00007895b19d8c02  vmovaps [rsp+0xC0], xmm13
00007895b19d8c0b  vmovaps [rsp+0xD0], xmm14
00007895b19d8c14  vmovaps [rsp+0xE0], xmm15
00007895b19d8c1d  sub rsp, 0x40
00007895b19d8c21  lea rdi, [rsp]
00007895b19d8c25  lea rsi, [rsp+0x10]
00007895b19d8c2a  lea rdx, [rsp+0x20]
00007895b19d8c2f  lea rcx, [rsp+0x30]
00007895b19d8c34  mov r8d, 0x00
00007895b19d8c3a  lea r9, [r15+0x3A8]
00007895b19d8c41  movaps [rdi], xmm4
00007895b19d8c44  movaps [rsi], xmm12
00007895b19d8c48  movaps [rdx], xmm9
00007895b19d8c4c  movaps [rcx], xmm6
00007895b19d8c4f  mov rax, 0x59D4522A9A50
00007895b19d8c59  call rax
00007895b19d8c5b  movaps xmm4, [rsp]
00007895b19d8c5f  add rsp, 0x40
00007895b19d8c63  vmovaps xmm0, [rsp]
00007895b19d8c68  vmovaps xmm1, [rsp+0x10]
00007895b19d8c6e  vmovaps xmm2, [rsp+0x20]
00007895b19d8c74  vmovaps xmm3, [rsp+0x30]
00007895b19d8c7a  vmovaps xmm5, [rsp+0x40]
00007895b19d8c80  vmovaps xmm6, [rsp+0x50]
00007895b19d8c86  vmovaps xmm7, [rsp+0x60]
00007895b19d8c8c  vmovaps xmm8, [rsp+0x70]
00007895b19d8c92  vmovaps xmm9, [rsp+0x80]
00007895b19d8c9b  vmovaps xmm10, [rsp+0x90]
00007895b19d8ca4  vmovaps xmm11, [rsp+0xA0]
00007895b19d8cad  vmovaps xmm12, [rsp+0xB0]
00007895b19d8cb6  vmovaps xmm13, [rsp+0xC0]
00007895b19d8cbf  vmovaps xmm14, [rsp+0xD0]
00007895b19d8cc8  vmovaps xmm15, [rsp+0xE0]
00007895b19d8cd1  add rsp, 0xF0
00007895b19d8cd8  pop r11
00007895b19d8cda  pop r10
00007895b19d8cdc  pop r9
00007895b19d8cde  pop r8
00007895b19d8ce0  pop rsi
00007895b19d8ce1  pop rdi
00007895b19d8ce2  pop rdx
00007895b19d8ce3  pop rcx
00007895b19d8ce4  pop rax
00007895b19d8ce5  add rsp, 0x08
00007895b19d8ce9  jmp 0x00007895B19D71FF
00007895b19d8cee  sub rsp, 0x08
00007895b19d8cf2  push rax
00007895b19d8cf3  push rcx
00007895b19d8cf4  push rdx
00007895b19d8cf5  push rdi
00007895b19d8cf6  push rsi
00007895b19d8cf7  push r8
00007895b19d8cf9  push r9
00007895b19d8cfb  push r10
00007895b19d8cfd  push r11
00007895b19d8cff  sub rsp, 0xF0
00007895b19d8d06  vmovaps [rsp], xmm0
00007895b19d8d0b  vmovaps [rsp+0x10], xmm1
00007895b19d8d11  vmovaps [rsp+0x20], xmm2
00007895b19d8d17  vmovaps [rsp+0x30], xmm3
00007895b19d8d1d  vmovaps [rsp+0x40], xmm4
00007895b19d8d23  vmovaps [rsp+0x50], xmm5
00007895b19d8d29  vmovaps [rsp+0x60], xmm6
00007895b19d8d2f  vmovaps [rsp+0x70], xmm7
00007895b19d8d35  vmovaps [rsp+0x80], xmm8
00007895b19d8d3e  vmovaps [rsp+0x90], xmm10
00007895b19d8d47  vmovaps [rsp+0xA0], xmm11
00007895b19d8d50  vmovaps [rsp+0xB0], xmm12
00007895b19d8d59  vmovaps [rsp+0xC0], xmm13
00007895b19d8d62  vmovaps [rsp+0xD0], xmm14
00007895b19d8d6b  vmovaps [rsp+0xE0], xmm15
00007895b19d8d74  sub rsp, 0x40
00007895b19d8d78  lea rdi, [rsp]
00007895b19d8d7c  lea rsi, [rsp+0x10]
00007895b19d8d81  lea rdx, [rsp+0x20]
00007895b19d8d86  lea rcx, [rsp+0x30]
00007895b19d8d8b  mov r8d, 0x00
00007895b19d8d91  lea r9, [r15+0x3A8]
00007895b19d8d98  movaps [rdi], xmm9
00007895b19d8d9c  movaps [rsi], xmm10
00007895b19d8da0  movaps [rdx], xmm1
00007895b19d8da3  movaps [rcx], xmm12
00007895b19d8da7  mov rax, 0x59D4522A9A50
00007895b19d8db1  call rax
00007895b19d8db3  movaps xmm9, [rsp]
00007895b19d8db8  add rsp, 0x40
00007895b19d8dbc  vmovaps xmm0, [rsp]
00007895b19d8dc1  vmovaps xmm1, [rsp+0x10]
00007895b19d8dc7  vmovaps xmm2, [rsp+0x20]
00007895b19d8dcd  vmovaps xmm3, [rsp+0x30]
00007895b19d8dd3  vmovaps xmm4, [rsp+0x40]
00007895b19d8dd9  vmovaps xmm5, [rsp+0x50]
00007895b19d8ddf  vmovaps xmm6, [rsp+0x60]
00007895b19d8de5  vmovaps xmm7, [rsp+0x70]
00007895b19d8deb  vmovaps xmm8, [rsp+0x80]
00007895b19d8df4  vmovaps xmm10, [rsp+0x90]
00007895b19d8dfd  vmovaps xmm11, [rsp+0xA0]
00007895b19d8e06  vmovaps xmm12, [rsp+0xB0]
00007895b19d8e0f  vmovaps xmm13, [rsp+0xC0]
00007895b19d8e18  vmovaps xmm14, [rsp+0xD0]
00007895b19d8e21  vmovaps xmm15, [rsp+0xE0]
00007895b19d8e2a  add rsp, 0xF0
00007895b19d8e31  pop r11
00007895b19d8e33  pop r10
00007895b19d8e35  pop r9
00007895b19d8e37  pop r8
00007895b19d8e39  pop rsi
00007895b19d8e3a  pop rdi
00007895b19d8e3b  pop rdx
00007895b19d8e3c  pop rcx
00007895b19d8e3d  pop rax
00007895b19d8e3e  add rsp, 0x08
00007895b19d8e42  jmp 0x00007895B19D7228
00007895b19d8e47  sub rsp, 0x08
00007895b19d8e4b  push rax
00007895b19d8e4c  push rcx
00007895b19d8e4d  push rdx
00007895b19d8e4e  push rdi
00007895b19d8e4f  push rsi
00007895b19d8e50  push r8
00007895b19d8e52  push r9
00007895b19d8e54  push r10
00007895b19d8e56  push r11
00007895b19d8e58  sub rsp, 0xF0
00007895b19d8e5f  vmovaps [rsp], xmm0
00007895b19d8e64  vmovaps [rsp+0x10], xmm1
00007895b19d8e6a  vmovaps [rsp+0x20], xmm2
00007895b19d8e70  vmovaps [rsp+0x30], xmm3
00007895b19d8e76  vmovaps [rsp+0x40], xmm4
00007895b19d8e7c  vmovaps [rsp+0x50], xmm5
00007895b19d8e82  vmovaps [rsp+0x60], xmm6
00007895b19d8e88  vmovaps [rsp+0x70], xmm7
00007895b19d8e8e  vmovaps [rsp+0x80], xmm8
00007895b19d8e97  vmovaps [rsp+0x90], xmm9
00007895b19d8ea0  vmovaps [rsp+0xA0], xmm11
00007895b19d8ea9  vmovaps [rsp+0xB0], xmm12
00007895b19d8eb2  vmovaps [rsp+0xC0], xmm13
00007895b19d8ebb  vmovaps [rsp+0xD0], xmm14
00007895b19d8ec4  vmovaps [rsp+0xE0], xmm15
00007895b19d8ecd  sub rsp, 0x40
00007895b19d8ed1  lea rdi, [rsp]
00007895b19d8ed5  lea rsi, [rsp+0x10]
00007895b19d8eda  lea rdx, [rsp+0x20]
00007895b19d8edf  lea rcx, [rsp+0x30]
00007895b19d8ee4  mov r8d, 0x00
00007895b19d8eea  lea r9, [r15+0x3A8]
00007895b19d8ef1  movaps [rdi], xmm10
00007895b19d8ef5  movaps [rsi], xmm5
00007895b19d8ef8  movaps [rdx], xmm12
00007895b19d8efc  movaps [rcx], xmm1
00007895b19d8eff  mov rax, 0x59D4522A9A50
00007895b19d8f09  call rax
00007895b19d8f0b  movaps xmm10, [rsp]
00007895b19d8f10  add rsp, 0x40
00007895b19d8f14  vmovaps xmm0, [rsp]
00007895b19d8f19  vmovaps xmm1, [rsp+0x10]
00007895b19d8f1f  vmovaps xmm2, [rsp+0x20]
00007895b19d8f25  vmovaps xmm3, [rsp+0x30]
00007895b19d8f2b  vmovaps xmm4, [rsp+0x40]
00007895b19d8f31  vmovaps xmm5, [rsp+0x50]
00007895b19d8f37  vmovaps xmm6, [rsp+0x60]
00007895b19d8f3d  vmovaps xmm7, [rsp+0x70]
00007895b19d8f43  vmovaps xmm8, [rsp+0x80]
00007895b19d8f4c  vmovaps xmm9, [rsp+0x90]
00007895b19d8f55  vmovaps xmm11, [rsp+0xA0]
00007895b19d8f5e  vmovaps xmm12, [rsp+0xB0]
00007895b19d8f67  vmovaps xmm13, [rsp+0xC0]
00007895b19d8f70  vmovaps xmm14, [rsp+0xD0]
00007895b19d8f79  vmovaps xmm15, [rsp+0xE0]
00007895b19d8f82  add rsp, 0xF0
00007895b19d8f89  pop r11
00007895b19d8f8b  pop r10
00007895b19d8f8d  pop r9
00007895b19d8f8f  pop r8
00007895b19d8f91  pop rsi
00007895b19d8f92  pop rdi
00007895b19d8f93  pop rdx
00007895b19d8f94  pop rcx
00007895b19d8f95  pop rax
00007895b19d8f96  add rsp, 0x08
00007895b19d8f9a  jmp 0x00007895B19D7257
00007895b19d8f9f  sub rsp, 0x08
00007895b19d8fa3  push rax
00007895b19d8fa4  push rcx
00007895b19d8fa5  push rdx
00007895b19d8fa6  push rdi
00007895b19d8fa7  push rsi
00007895b19d8fa8  push r8
00007895b19d8faa  push r9
00007895b19d8fac  push r10
00007895b19d8fae  push r11
00007895b19d8fb0  sub rsp, 0xF0
00007895b19d8fb7  vmovaps [rsp], xmm0
00007895b19d8fbc  vmovaps [rsp+0x10], xmm1
00007895b19d8fc2  vmovaps [rsp+0x20], xmm2
00007895b19d8fc8  vmovaps [rsp+0x30], xmm3
00007895b19d8fce  vmovaps [rsp+0x40], xmm4
00007895b19d8fd4  vmovaps [rsp+0x50], xmm5
00007895b19d8fda  vmovaps [rsp+0x60], xmm7
00007895b19d8fe0  vmovaps [rsp+0x70], xmm8
00007895b19d8fe6  vmovaps [rsp+0x80], xmm9
00007895b19d8fef  vmovaps [rsp+0x90], xmm10
00007895b19d8ff8  vmovaps [rsp+0xA0], xmm11
00007895b19d9001  vmovaps [rsp+0xB0], xmm12
00007895b19d900a  vmovaps [rsp+0xC0], xmm13
00007895b19d9013  vmovaps [rsp+0xD0], xmm14
00007895b19d901c  vmovaps [rsp+0xE0], xmm15
00007895b19d9025  sub rsp, 0x40
00007895b19d9029  lea rdi, [rsp]
00007895b19d902d  lea rsi, [rsp+0x10]
00007895b19d9032  lea rdx, [rsp+0x20]
00007895b19d9037  lea rcx, [rsp+0x30]
00007895b19d903c  mov r8d, 0x00
00007895b19d9042  lea r9, [r15+0x3A8]
00007895b19d9049  movaps [rdi], xmm6
00007895b19d904c  movaps [rsi], xmm8
00007895b19d9050  movaps [rdx], xmm12
00007895b19d9054  movaps [rcx], xmm1
00007895b19d9057  mov rax, 0x59D4522A9A50
00007895b19d9061  call rax
00007895b19d9063  movaps xmm6, [rsp]
00007895b19d9067  add rsp, 0x40
00007895b19d906b  vmovaps xmm0, [rsp]
00007895b19d9070  vmovaps xmm1, [rsp+0x10]
00007895b19d9076  vmovaps xmm2, [rsp+0x20]
00007895b19d907c  vmovaps xmm3, [rsp+0x30]
00007895b19d9082  vmovaps xmm4, [rsp+0x40]
00007895b19d9088  vmovaps xmm5, [rsp+0x50]
00007895b19d908e  vmovaps xmm7, [rsp+0x60]
00007895b19d9094  vmovaps xmm8, [rsp+0x70]
00007895b19d909a  vmovaps xmm9, [rsp+0x80]
00007895b19d90a3  vmovaps xmm10, [rsp+0x90]
00007895b19d90ac  vmovaps xmm11, [rsp+0xA0]
00007895b19d90b5  vmovaps xmm12, [rsp+0xB0]
00007895b19d90be  vmovaps xmm13, [rsp+0xC0]
00007895b19d90c7  vmovaps xmm14, [rsp+0xD0]
00007895b19d90d0  vmovaps xmm15, [rsp+0xE0]
00007895b19d90d9  add rsp, 0xF0
00007895b19d90e0  pop r11
00007895b19d90e2  pop r10
00007895b19d90e4  pop r9
00007895b19d90e6  pop r8
00007895b19d90e8  pop rsi
00007895b19d90e9  pop rdi
00007895b19d90ea  pop rdx
00007895b19d90eb  pop rcx
00007895b19d90ec  pop rax
00007895b19d90ed  add rsp, 0x08
00007895b19d90f1  jmp 0x00007895B19D7285
00007895b19d90f6  call 0x00007895B17FF430
00007895b19d90fb  jmp 0x00007895B19D728F
00007895b19d9100  call 0x00007895B180AFE0
00007895b19d9105  jmp 0x00007895B19D7299
00007895b19d910a  sub rsp, 0x08
00007895b19d910e  push rax
00007895b19d910f  push rcx
00007895b19d9110  push rdx
00007895b19d9111  push rdi
00007895b19d9112  push rsi
00007895b19d9113  push r8
00007895b19d9115  push r9
00007895b19d9117  push r10
00007895b19d9119  push r11
00007895b19d911b  sub rsp, 0xF0
00007895b19d9122  vmovaps [rsp], xmm0
00007895b19d9127  vmovaps [rsp+0x10], xmm1
00007895b19d912d  vmovaps [rsp+0x20], xmm2
00007895b19d9133  vmovaps [rsp+0x30], xmm3
00007895b19d9139  vmovaps [rsp+0x40], xmm4
00007895b19d913f  vmovaps [rsp+0x50], xmm5
00007895b19d9145  vmovaps [rsp+0x60], xmm6
00007895b19d914b  vmovaps [rsp+0x70], xmm7
00007895b19d9151  vmovaps [rsp+0x80], xmm9
00007895b19d915a  vmovaps [rsp+0x90], xmm10
00007895b19d9163  vmovaps [rsp+0xA0], xmm11
00007895b19d916c  vmovaps [rsp+0xB0], xmm12
00007895b19d9175  vmovaps [rsp+0xC0], xmm13
00007895b19d917e  vmovaps [rsp+0xD0], xmm14
00007895b19d9187  vmovaps [rsp+0xE0], xmm15
00007895b19d9190  sub rsp, 0x40
00007895b19d9194  lea rdi, [rsp]
00007895b19d9198  lea rsi, [rsp+0x10]
00007895b19d919d  lea rdx, [rsp+0x20]
00007895b19d91a2  lea rcx, [rsp+0x30]
00007895b19d91a7  mov r8d, 0x00
00007895b19d91ad  lea r9, [r15+0x3A8]
00007895b19d91b4  movaps [rdi], xmm8
00007895b19d91b8  movaps [rsi], xmm4
00007895b19d91bb  movaps [rdx], xmm13
00007895b19d91bf  movaps [rcx], xmm11
00007895b19d91c3  mov rax, 0x59D4522A9A50
00007895b19d91cd  call rax
00007895b19d91cf  movaps xmm8, [rsp]
00007895b19d91d4  add rsp, 0x40
00007895b19d91d8  vmovaps xmm0, [rsp]
00007895b19d91dd  vmovaps xmm1, [rsp+0x10]
00007895b19d91e3  vmovaps xmm2, [rsp+0x20]
00007895b19d91e9  vmovaps xmm3, [rsp+0x30]
00007895b19d91ef  vmovaps xmm4, [rsp+0x40]
00007895b19d91f5  vmovaps xmm5, [rsp+0x50]
00007895b19d91fb  vmovaps xmm6, [rsp+0x60]
00007895b19d9201  vmovaps xmm7, [rsp+0x70]
00007895b19d9207  vmovaps xmm9, [rsp+0x80]
00007895b19d9210  vmovaps xmm10, [rsp+0x90]
00007895b19d9219  vmovaps xmm11, [rsp+0xA0]
00007895b19d9222  vmovaps xmm12, [rsp+0xB0]
00007895b19d922b  vmovaps xmm13, [rsp+0xC0]
00007895b19d9234  vmovaps xmm14, [rsp+0xD0]
00007895b19d923d  vmovaps xmm15, [rsp+0xE0]
00007895b19d9246  add rsp, 0xF0
00007895b19d924d  pop r11
00007895b19d924f  pop r10
00007895b19d9251  pop r9
00007895b19d9253  pop r8
00007895b19d9255  pop rsi
00007895b19d9256  pop rdi
00007895b19d9257  pop rdx
00007895b19d9258  pop rcx
00007895b19d9259  pop rax
00007895b19d925a  add rsp, 0x08
00007895b19d925e  jmp 0x00007895B19D72CF
00007895b19d9263  sub rsp, 0x08
00007895b19d9267  push rax
00007895b19d9268  push rcx
00007895b19d9269  push rdx
00007895b19d926a  push rdi
00007895b19d926b  push rsi
00007895b19d926c  push r8
00007895b19d926e  push r9
00007895b19d9270  push r10
00007895b19d9272  push r11
00007895b19d9274  sub rsp, 0xF0
00007895b19d927b  vmovaps [rsp], xmm0
00007895b19d9280  vmovaps [rsp+0x10], xmm1
00007895b19d9286  vmovaps [rsp+0x20], xmm2
00007895b19d928c  vmovaps [rsp+0x30], xmm3
00007895b19d9292  vmovaps [rsp+0x40], xmm4
00007895b19d9298  vmovaps [rsp+0x50], xmm5
00007895b19d929e  vmovaps [rsp+0x60], xmm6
00007895b19d92a4  vmovaps [rsp+0x70], xmm7
00007895b19d92aa  vmovaps [rsp+0x80], xmm8
00007895b19d92b3  vmovaps [rsp+0x90], xmm9
00007895b19d92bc  vmovaps [rsp+0xA0], xmm10
00007895b19d92c5  vmovaps [rsp+0xB0], xmm12
00007895b19d92ce  vmovaps [rsp+0xC0], xmm13
00007895b19d92d7  vmovaps [rsp+0xD0], xmm14
00007895b19d92e0  vmovaps [rsp+0xE0], xmm15
00007895b19d92e9  sub rsp, 0x40
00007895b19d92ed  lea rdi, [rsp]
00007895b19d92f1  lea rsi, [rsp+0x10]
00007895b19d92f6  lea rdx, [rsp+0x20]
00007895b19d92fb  lea rcx, [rsp+0x30]
00007895b19d9300  mov r8d, 0x00
00007895b19d9306  lea r9, [r15+0x3A8]
00007895b19d930d  movaps [rdi], xmm11
00007895b19d9311  movaps [rsi], xmm9
00007895b19d9315  movaps [rdx], xmm1
00007895b19d9318  movaps [rcx], xmm13
00007895b19d931c  mov rax, 0x59D4522A9A50
00007895b19d9326  call rax
00007895b19d9328  movaps xmm11, [rsp]
00007895b19d932d  add rsp, 0x40
00007895b19d9331  vmovaps xmm0, [rsp]
00007895b19d9336  vmovaps xmm1, [rsp+0x10]
00007895b19d933c  vmovaps xmm2, [rsp+0x20]
00007895b19d9342  vmovaps xmm3, [rsp+0x30]
00007895b19d9348  vmovaps xmm4, [rsp+0x40]
00007895b19d934e  vmovaps xmm5, [rsp+0x50]
00007895b19d9354  vmovaps xmm6, [rsp+0x60]
00007895b19d935a  vmovaps xmm7, [rsp+0x70]
00007895b19d9360  vmovaps xmm8, [rsp+0x80]
00007895b19d9369  vmovaps xmm9, [rsp+0x90]
00007895b19d9372  vmovaps xmm10, [rsp+0xA0]
00007895b19d937b  vmovaps xmm12, [rsp+0xB0]
00007895b19d9384  vmovaps xmm13, [rsp+0xC0]
00007895b19d938d  vmovaps xmm14, [rsp+0xD0]
00007895b19d9396  vmovaps xmm15, [rsp+0xE0]
00007895b19d939f  add rsp, 0xF0
00007895b19d93a6  pop r11
00007895b19d93a8  pop r10
00007895b19d93aa  pop r9
00007895b19d93ac  pop r8
00007895b19d93ae  pop rsi
00007895b19d93af  pop rdi
00007895b19d93b0  pop rdx
00007895b19d93b1  pop rcx
00007895b19d93b2  pop rax
00007895b19d93b3  add rsp, 0x08
00007895b19d93b7  jmp 0x00007895B19D72F5
00007895b19d93bc  sub rsp, 0x08
00007895b19d93c0  push rax
00007895b19d93c1  push rcx
00007895b19d93c2  push rdx
00007895b19d93c3  push rdi
00007895b19d93c4  push rsi
00007895b19d93c5  push r8
00007895b19d93c7  push r9
00007895b19d93c9  push r10
00007895b19d93cb  push r11
00007895b19d93cd  sub rsp, 0xF0
00007895b19d93d4  vmovaps [rsp], xmm0
00007895b19d93d9  vmovaps [rsp+0x10], xmm1
00007895b19d93df  vmovaps [rsp+0x20], xmm2
00007895b19d93e5  vmovaps [rsp+0x30], xmm3
00007895b19d93eb  vmovaps [rsp+0x40], xmm4
00007895b19d93f1  vmovaps [rsp+0x50], xmm5
00007895b19d93f7  vmovaps [rsp+0x60], xmm6
00007895b19d93fd  vmovaps [rsp+0x70], xmm7
00007895b19d9403  vmovaps [rsp+0x80], xmm8
00007895b19d940c  vmovaps [rsp+0x90], xmm9
00007895b19d9415  vmovaps [rsp+0xA0], xmm10
00007895b19d941e  vmovaps [rsp+0xB0], xmm11
00007895b19d9427  vmovaps [rsp+0xC0], xmm12
00007895b19d9430  vmovaps [rsp+0xD0], xmm14
00007895b19d9439  vmovaps [rsp+0xE0], xmm15
00007895b19d9442  sub rsp, 0x40
00007895b19d9446  lea rdi, [rsp]
00007895b19d944a  lea rsi, [rsp+0x10]
00007895b19d944f  lea rdx, [rsp+0x20]
00007895b19d9454  lea rcx, [rsp+0x30]
00007895b19d9459  mov r8d, 0x00
00007895b19d945f  lea r9, [r15+0x3A8]
00007895b19d9466  movaps [rdi], xmm13
00007895b19d946a  movaps [rsi], xmm10
00007895b19d946e  movaps [rdx], xmm7
00007895b19d9471  movaps [rcx], xmm1
00007895b19d9474  mov rax, 0x59D4522A9A50
00007895b19d947e  call rax
00007895b19d9480  movaps xmm13, [rsp]
00007895b19d9485  add rsp, 0x40
00007895b19d9489  vmovaps xmm0, [rsp]
00007895b19d948e  vmovaps xmm1, [rsp+0x10]
00007895b19d9494  vmovaps xmm2, [rsp+0x20]
00007895b19d949a  vmovaps xmm3, [rsp+0x30]
00007895b19d94a0  vmovaps xmm4, [rsp+0x40]
00007895b19d94a6  vmovaps xmm5, [rsp+0x50]
00007895b19d94ac  vmovaps xmm6, [rsp+0x60]
00007895b19d94b2  vmovaps xmm7, [rsp+0x70]
00007895b19d94b8  vmovaps xmm8, [rsp+0x80]
00007895b19d94c1  vmovaps xmm9, [rsp+0x90]
00007895b19d94ca  vmovaps xmm10, [rsp+0xA0]
00007895b19d94d3  vmovaps xmm11, [rsp+0xB0]
00007895b19d94dc  vmovaps xmm12, [rsp+0xC0]
00007895b19d94e5  vmovaps xmm14, [rsp+0xD0]
00007895b19d94ee  vmovaps xmm15, [rsp+0xE0]
00007895b19d94f7  add rsp, 0xF0
00007895b19d94fe  pop r11
00007895b19d9500  pop r10
00007895b19d9502  pop r9
00007895b19d9504  pop r8
00007895b19d9506  pop rsi
00007895b19d9507  pop rdi
00007895b19d9508  pop rdx
00007895b19d9509  pop rcx
00007895b19d950a  pop rax
00007895b19d950b  add rsp, 0x08
00007895b19d950f  jmp 0x00007895B19D731B
00007895b19d9514  sub rsp, 0x08
00007895b19d9518  push rax
00007895b19d9519  push rcx
00007895b19d951a  push rdx
00007895b19d951b  push rdi
00007895b19d951c  push rsi
00007895b19d951d  push r8
00007895b19d951f  push r9
00007895b19d9521  push r10
00007895b19d9523  push r11
00007895b19d9525  sub rsp, 0xF0
00007895b19d952c  vmovaps [rsp], xmm0
00007895b19d9531  vmovaps [rsp+0x10], xmm1
00007895b19d9537  vmovaps [rsp+0x20], xmm2
00007895b19d953d  vmovaps [rsp+0x30], xmm3
00007895b19d9543  vmovaps [rsp+0x40], xmm4
00007895b19d9549  vmovaps [rsp+0x50], xmm5
00007895b19d954f  vmovaps [rsp+0x60], xmm6
00007895b19d9555  vmovaps [rsp+0x70], xmm7
00007895b19d955b  vmovaps [rsp+0x80], xmm8
00007895b19d9564  vmovaps [rsp+0x90], xmm9
00007895b19d956d  vmovaps [rsp+0xA0], xmm11
00007895b19d9576  vmovaps [rsp+0xB0], xmm12
00007895b19d957f  vmovaps [rsp+0xC0], xmm13
00007895b19d9588  vmovaps [rsp+0xD0], xmm14
00007895b19d9591  vmovaps [rsp+0xE0], xmm15
00007895b19d959a  sub rsp, 0x40
00007895b19d959e  lea rdi, [rsp]
00007895b19d95a2  lea rsi, [rsp+0x10]
00007895b19d95a7  lea rdx, [rsp+0x20]
00007895b19d95ac  lea rcx, [rsp+0x30]
00007895b19d95b1  mov r8d, 0x00
00007895b19d95b7  lea r9, [r15+0x3A8]
00007895b19d95be  movaps [rdi], xmm10
00007895b19d95c2  movaps [rsi], xmm6
00007895b19d95c5  movaps [rdx], xmm15
00007895b19d95c9  movaps [rcx], xmm1
00007895b19d95cc  mov rax, 0x59D4522A9A50
00007895b19d95d6  call rax
00007895b19d95d8  movaps xmm10, [rsp]
00007895b19d95dd  add rsp, 0x40
00007895b19d95e1  vmovaps xmm0, [rsp]
00007895b19d95e6  vmovaps xmm1, [rsp+0x10]
00007895b19d95ec  vmovaps xmm2, [rsp+0x20]
00007895b19d95f2  vmovaps xmm3, [rsp+0x30]
00007895b19d95f8  vmovaps xmm4, [rsp+0x40]
00007895b19d95fe  vmovaps xmm5, [rsp+0x50]
00007895b19d9604  vmovaps xmm6, [rsp+0x60]
00007895b19d960a  vmovaps xmm7, [rsp+0x70]
00007895b19d9610  vmovaps xmm8, [rsp+0x80]
00007895b19d9619  vmovaps xmm9, [rsp+0x90]
00007895b19d9622  vmovaps xmm11, [rsp+0xA0]
00007895b19d962b  vmovaps xmm12, [rsp+0xB0]
00007895b19d9634  vmovaps xmm13, [rsp+0xC0]
00007895b19d963d  vmovaps xmm14, [rsp+0xD0]
00007895b19d9646  vmovaps xmm15, [rsp+0xE0]
00007895b19d964f  add rsp, 0xF0
00007895b19d9656  pop r11
00007895b19d9658  pop r10
00007895b19d965a  pop r9
00007895b19d965c  pop r8
00007895b19d965e  pop rsi
00007895b19d965f  pop rdi
00007895b19d9660  pop rdx
00007895b19d9661  pop rcx
00007895b19d9662  pop rax
00007895b19d9663  add rsp, 0x08
00007895b19d9667  jmp 0x00007895B19D7341
00007895b19d966c  call 0x00007895B17FF430
00007895b19d9671  jmp 0x00007895B19D734B
00007895b19d9676  call 0x00007895B180E760
00007895b19d967b  jmp 0x00007895B19D7355
00007895b19d9680  sub rsp, 0x08
00007895b19d9684  push rax
00007895b19d9685  push rcx
00007895b19d9686  push rdx
00007895b19d9687  push rdi
00007895b19d9688  push rsi
00007895b19d9689  push r8
00007895b19d968b  push r9
00007895b19d968d  push r10
00007895b19d968f  push r11
00007895b19d9691  sub rsp, 0xF0
00007895b19d9698  vmovaps [rsp], xmm0
00007895b19d969d  vmovaps [rsp+0x10], xmm1
00007895b19d96a3  vmovaps [rsp+0x20], xmm2
00007895b19d96a9  vmovaps [rsp+0x30], xmm3
00007895b19d96af  vmovaps [rsp+0x40], xmm4
00007895b19d96b5  vmovaps [rsp+0x50], xmm5
00007895b19d96bb  vmovaps [rsp+0x60], xmm6
00007895b19d96c1  vmovaps [rsp+0x70], xmm8
00007895b19d96c7  vmovaps [rsp+0x80], xmm9
00007895b19d96d0  vmovaps [rsp+0x90], xmm10
00007895b19d96d9  vmovaps [rsp+0xA0], xmm11
00007895b19d96e2  vmovaps [rsp+0xB0], xmm12
00007895b19d96eb  vmovaps [rsp+0xC0], xmm13
00007895b19d96f4  vmovaps [rsp+0xD0], xmm14
00007895b19d96fd  vmovaps [rsp+0xE0], xmm15
00007895b19d9706  sub rsp, 0x40
00007895b19d970a  lea rdi, [rsp]
00007895b19d970e  lea rsi, [rsp+0x10]
00007895b19d9713  lea rdx, [rsp+0x20]
00007895b19d9718  lea rcx, [rsp+0x30]
00007895b19d971d  mov r8d, 0x00
00007895b19d9723  lea r9, [r15+0x3A8]
00007895b19d972a  movaps [rdi], xmm7
00007895b19d972d  movaps [rsi], xmm8
00007895b19d9731  movaps [rdx], xmm3
00007895b19d9734  movaps [rcx], xmm9
00007895b19d9738  mov rax, 0x59D4522A9A50
00007895b19d9742  call rax
00007895b19d9744  movaps xmm7, [rsp]
00007895b19d9748  add rsp, 0x40
00007895b19d974c  vmovaps xmm0, [rsp]
00007895b19d9751  vmovaps xmm1, [rsp+0x10]
00007895b19d9757  vmovaps xmm2, [rsp+0x20]
00007895b19d975d  vmovaps xmm3, [rsp+0x30]
00007895b19d9763  vmovaps xmm4, [rsp+0x40]
00007895b19d9769  vmovaps xmm5, [rsp+0x50]
00007895b19d976f  vmovaps xmm6, [rsp+0x60]
00007895b19d9775  vmovaps xmm8, [rsp+0x70]
00007895b19d977b  vmovaps xmm9, [rsp+0x80]
00007895b19d9784  vmovaps xmm10, [rsp+0x90]
00007895b19d978d  vmovaps xmm11, [rsp+0xA0]
00007895b19d9796  vmovaps xmm12, [rsp+0xB0]
00007895b19d979f  vmovaps xmm13, [rsp+0xC0]
00007895b19d97a8  vmovaps xmm14, [rsp+0xD0]
00007895b19d97b1  vmovaps xmm15, [rsp+0xE0]
00007895b19d97ba  add rsp, 0xF0
00007895b19d97c1  pop r11
00007895b19d97c3  pop r10
00007895b19d97c5  pop r9
00007895b19d97c7  pop r8
00007895b19d97c9  pop rsi
00007895b19d97ca  pop rdi
00007895b19d97cb  pop rdx
00007895b19d97cc  pop rcx
00007895b19d97cd  pop rax
00007895b19d97ce  add rsp, 0x08
00007895b19d97d2  jmp 0x00007895B19D737D
00007895b19d97d7  sub rsp, 0x08
00007895b19d97db  push rax
00007895b19d97dc  push rcx
00007895b19d97dd  push rdx
00007895b19d97de  push rdi
00007895b19d97df  push rsi
00007895b19d97e0  push r8
00007895b19d97e2  push r9
00007895b19d97e4  push r10
00007895b19d97e6  push r11
00007895b19d97e8  sub rsp, 0xF0
00007895b19d97ef  vmovaps [rsp], xmm0
00007895b19d97f4  vmovaps [rsp+0x10], xmm1
00007895b19d97fa  vmovaps [rsp+0x20], xmm2
00007895b19d9800  vmovaps [rsp+0x30], xmm3
00007895b19d9806  vmovaps [rsp+0x40], xmm4
00007895b19d980c  vmovaps [rsp+0x50], xmm5
00007895b19d9812  vmovaps [rsp+0x60], xmm6
00007895b19d9818  vmovaps [rsp+0x70], xmm7
00007895b19d981e  vmovaps [rsp+0x80], xmm9
00007895b19d9827  vmovaps [rsp+0x90], xmm10
00007895b19d9830  vmovaps [rsp+0xA0], xmm11
00007895b19d9839  vmovaps [rsp+0xB0], xmm12
00007895b19d9842  vmovaps [rsp+0xC0], xmm13
00007895b19d984b  vmovaps [rsp+0xD0], xmm14
00007895b19d9854  vmovaps [rsp+0xE0], xmm15
00007895b19d985d  sub rsp, 0x40
00007895b19d9861  lea rdi, [rsp]
00007895b19d9865  lea rsi, [rsp+0x10]
00007895b19d986a  lea rdx, [rsp+0x20]
00007895b19d986f  lea rcx, [rsp+0x30]
00007895b19d9874  mov r8d, 0x00
00007895b19d987a  lea r9, [r15+0x3A8]
00007895b19d9881  movaps [rdi], xmm8
00007895b19d9885  movaps [rsi], xmm11
00007895b19d9889  movaps [rdx], xmm14
00007895b19d988d  movaps [rcx], xmm9
00007895b19d9891  mov rax, 0x59D4522A9A50
00007895b19d989b  call rax
00007895b19d989d  movaps xmm8, [rsp]
00007895b19d98a2  add rsp, 0x40
00007895b19d98a6  vmovaps xmm0, [rsp]
00007895b19d98ab  vmovaps xmm1, [rsp+0x10]
00007895b19d98b1  vmovaps xmm2, [rsp+0x20]
00007895b19d98b7  vmovaps xmm3, [rsp+0x30]
00007895b19d98bd  vmovaps xmm4, [rsp+0x40]
00007895b19d98c3  vmovaps xmm5, [rsp+0x50]
00007895b19d98c9  vmovaps xmm6, [rsp+0x60]
00007895b19d98cf  vmovaps xmm7, [rsp+0x70]
00007895b19d98d5  vmovaps xmm9, [rsp+0x80]
00007895b19d98de  vmovaps xmm10, [rsp+0x90]
00007895b19d98e7  vmovaps xmm11, [rsp+0xA0]
00007895b19d98f0  vmovaps xmm12, [rsp+0xB0]
00007895b19d98f9  vmovaps xmm13, [rsp+0xC0]
00007895b19d9902  vmovaps xmm14, [rsp+0xD0]
00007895b19d990b  vmovaps xmm15, [rsp+0xE0]
00007895b19d9914  add rsp, 0xF0
00007895b19d991b  pop r11
00007895b19d991d  pop r10
00007895b19d991f  pop r9
00007895b19d9921  pop r8
00007895b19d9923  pop rsi
00007895b19d9924  pop rdi
00007895b19d9925  pop rdx
00007895b19d9926  pop rcx
00007895b19d9927  pop rax
00007895b19d9928  add rsp, 0x08
00007895b19d992c  jmp 0x00007895B19D73A6
00007895b19d9931  sub rsp, 0x08
00007895b19d9935  push rax
00007895b19d9936  push rcx
00007895b19d9937  push rdx
00007895b19d9938  push rdi
00007895b19d9939  push rsi
00007895b19d993a  push r8
00007895b19d993c  push r9
00007895b19d993e  push r10
00007895b19d9940  push r11
00007895b19d9942  sub rsp, 0xF0
00007895b19d9949  vmovaps [rsp], xmm0
00007895b19d994e  vmovaps [rsp+0x10], xmm1
00007895b19d9954  vmovaps [rsp+0x20], xmm2
00007895b19d995a  vmovaps [rsp+0x30], xmm3
00007895b19d9960  vmovaps [rsp+0x40], xmm4
00007895b19d9966  vmovaps [rsp+0x50], xmm5
00007895b19d996c  vmovaps [rsp+0x60], xmm6
00007895b19d9972  vmovaps [rsp+0x70], xmm7
00007895b19d9978  vmovaps [rsp+0x80], xmm8
00007895b19d9981  vmovaps [rsp+0x90], xmm9
00007895b19d998a  vmovaps [rsp+0xA0], xmm10
00007895b19d9993  vmovaps [rsp+0xB0], xmm12
00007895b19d999c  vmovaps [rsp+0xC0], xmm13
00007895b19d99a5  vmovaps [rsp+0xD0], xmm14
00007895b19d99ae  vmovaps [rsp+0xE0], xmm15
00007895b19d99b7  sub rsp, 0x40
00007895b19d99bb  lea rdi, [rsp]
00007895b19d99bf  lea rsi, [rsp+0x10]
00007895b19d99c4  lea rdx, [rsp+0x20]
00007895b19d99c9  lea rcx, [rsp+0x30]
00007895b19d99ce  mov r8d, 0x00
00007895b19d99d4  lea r9, [r15+0x3A8]
00007895b19d99db  movaps [rdi], xmm11
00007895b19d99df  movaps [rsi], xmm13
00007895b19d99e3  movaps [rdx], xmm12
00007895b19d99e7  movaps [rcx], xmm14
00007895b19d99eb  mov rax, 0x59D4522A9A50
00007895b19d99f5  call rax
00007895b19d99f7  movaps xmm11, [rsp]
00007895b19d99fc  add rsp, 0x40
00007895b19d9a00  vmovaps xmm0, [rsp]
00007895b19d9a05  vmovaps xmm1, [rsp+0x10]
00007895b19d9a0b  vmovaps xmm2, [rsp+0x20]
00007895b19d9a11  vmovaps xmm3, [rsp+0x30]
00007895b19d9a17  vmovaps xmm4, [rsp+0x40]
00007895b19d9a1d  vmovaps xmm5, [rsp+0x50]
00007895b19d9a23  vmovaps xmm6, [rsp+0x60]
00007895b19d9a29  vmovaps xmm7, [rsp+0x70]
00007895b19d9a2f  vmovaps xmm8, [rsp+0x80]
00007895b19d9a38  vmovaps xmm9, [rsp+0x90]
00007895b19d9a41  vmovaps xmm10, [rsp+0xA0]
00007895b19d9a4a  vmovaps xmm12, [rsp+0xB0]
00007895b19d9a53  vmovaps xmm13, [rsp+0xC0]
00007895b19d9a5c  vmovaps xmm14, [rsp+0xD0]
00007895b19d9a65  vmovaps xmm15, [rsp+0xE0]
00007895b19d9a6e  add rsp, 0xF0
00007895b19d9a75  pop r11
00007895b19d9a77  pop r10
00007895b19d9a79  pop r9
00007895b19d9a7b  pop r8
00007895b19d9a7d  pop rsi
00007895b19d9a7e  pop rdi
00007895b19d9a7f  pop rdx
00007895b19d9a80  pop rcx
00007895b19d9a81  pop rax
00007895b19d9a82  add rsp, 0x08
00007895b19d9a86  jmp 0x00007895B19D73CF
00007895b19d9a8b  sub rsp, 0x08
00007895b19d9a8f  push rax
00007895b19d9a90  push rcx
00007895b19d9a91  push rdx
00007895b19d9a92  push rdi
00007895b19d9a93  push rsi
00007895b19d9a94  push r8
00007895b19d9a96  push r9
00007895b19d9a98  push r10
00007895b19d9a9a  push r11
00007895b19d9a9c  sub rsp, 0xF0
00007895b19d9aa3  vmovaps [rsp], xmm0
00007895b19d9aa8  vmovaps [rsp+0x10], xmm1
00007895b19d9aae  vmovaps [rsp+0x20], xmm2
00007895b19d9ab4  vmovaps [rsp+0x30], xmm3
00007895b19d9aba  vmovaps [rsp+0x40], xmm4
00007895b19d9ac0  vmovaps [rsp+0x50], xmm5
00007895b19d9ac6  vmovaps [rsp+0x60], xmm6
00007895b19d9acc  vmovaps [rsp+0x70], xmm7
00007895b19d9ad2  vmovaps [rsp+0x80], xmm8
00007895b19d9adb  vmovaps [rsp+0x90], xmm9
00007895b19d9ae4  vmovaps [rsp+0xA0], xmm10
00007895b19d9aed  vmovaps [rsp+0xB0], xmm11
00007895b19d9af6  vmovaps [rsp+0xC0], xmm13
00007895b19d9aff  vmovaps [rsp+0xD0], xmm14
00007895b19d9b08  vmovaps [rsp+0xE0], xmm15
00007895b19d9b11  sub rsp, 0x40
00007895b19d9b15  lea rdi, [rsp]
00007895b19d9b19  lea rsi, [rsp+0x10]
00007895b19d9b1e  lea rdx, [rsp+0x20]
00007895b19d9b23  lea rcx, [rsp+0x30]
00007895b19d9b28  mov r8d, 0x00
00007895b19d9b2e  lea r9, [r15+0x3A8]
00007895b19d9b35  movaps [rdi], xmm12
00007895b19d9b39  movaps [rsi], xmm10
00007895b19d9b3d  movaps [rdx], xmm15
00007895b19d9b41  movaps [rcx], xmm14
00007895b19d9b45  mov rax, 0x59D4522A9A50
00007895b19d9b4f  call rax
00007895b19d9b51  movaps xmm12, [rsp]
00007895b19d9b56  add rsp, 0x40
00007895b19d9b5a  vmovaps xmm0, [rsp]
00007895b19d9b5f  vmovaps xmm1, [rsp+0x10]
00007895b19d9b65  vmovaps xmm2, [rsp+0x20]
00007895b19d9b6b  vmovaps xmm3, [rsp+0x30]
00007895b19d9b71  vmovaps xmm4, [rsp+0x40]
00007895b19d9b77  vmovaps xmm5, [rsp+0x50]
00007895b19d9b7d  vmovaps xmm6, [rsp+0x60]
00007895b19d9b83  vmovaps xmm7, [rsp+0x70]
00007895b19d9b89  vmovaps xmm8, [rsp+0x80]
00007895b19d9b92  vmovaps xmm9, [rsp+0x90]
00007895b19d9b9b  vmovaps xmm10, [rsp+0xA0]
00007895b19d9ba4  vmovaps xmm11, [rsp+0xB0]
00007895b19d9bad  vmovaps xmm13, [rsp+0xC0]
00007895b19d9bb6  vmovaps xmm14, [rsp+0xD0]
00007895b19d9bbf  vmovaps xmm15, [rsp+0xE0]
00007895b19d9bc8  add rsp, 0xF0
00007895b19d9bcf  pop r11
00007895b19d9bd1  pop r10
00007895b19d9bd3  pop r9
00007895b19d9bd5  pop r8
00007895b19d9bd7  pop rsi
00007895b19d9bd8  pop rdi
00007895b19d9bd9  pop rdx
00007895b19d9bda  pop rcx
00007895b19d9bdb  pop rax
00007895b19d9bdc  add rsp, 0x08
00007895b19d9be0  jmp 0x00007895B19D73F8
00007895b19d9be5  call 0x00007895B180E760
00007895b19d9bea  jmp 0x00007895B19D7405
00007895b19d9bef  call 0x00007895B180D4E0
00007895b19d9bf4  jmp 0x00007895B19D7412
00007895b19d9bf9  sub rsp, 0x08
00007895b19d9bfd  push rax
00007895b19d9bfe  push rcx
00007895b19d9bff  push rdx
00007895b19d9c00  push rdi
00007895b19d9c01  push rsi
00007895b19d9c02  push r8
00007895b19d9c04  push r9
00007895b19d9c06  push r10
00007895b19d9c08  push r11
00007895b19d9c0a  sub rsp, 0xF0
00007895b19d9c11  vmovaps [rsp], xmm0
00007895b19d9c16  vmovaps [rsp+0x10], xmm1
00007895b19d9c1c  vmovaps [rsp+0x20], xmm2
00007895b19d9c22  vmovaps [rsp+0x30], xmm3
00007895b19d9c28  vmovaps [rsp+0x40], xmm4
00007895b19d9c2e  vmovaps [rsp+0x50], xmm5
00007895b19d9c34  vmovaps [rsp+0x60], xmm6
00007895b19d9c3a  vmovaps [rsp+0x70], xmm7
00007895b19d9c40  vmovaps [rsp+0x80], xmm8
00007895b19d9c49  vmovaps [rsp+0x90], xmm9
00007895b19d9c52  vmovaps [rsp+0xA0], xmm11
00007895b19d9c5b  vmovaps [rsp+0xB0], xmm12
00007895b19d9c64  vmovaps [rsp+0xC0], xmm13
00007895b19d9c6d  vmovaps [rsp+0xD0], xmm14
00007895b19d9c76  vmovaps [rsp+0xE0], xmm15
00007895b19d9c7f  sub rsp, 0x40
00007895b19d9c83  lea rdi, [rsp]
00007895b19d9c87  lea rsi, [rsp+0x10]
00007895b19d9c8c  lea rdx, [rsp+0x20]
00007895b19d9c91  lea rcx, [rsp+0x30]
00007895b19d9c96  mov r8d, 0x00
00007895b19d9c9c  lea r9, [r15+0x3A8]
00007895b19d9ca3  movaps [rdi], xmm10
00007895b19d9ca7  movaps [rsi], xmm7
00007895b19d9caa  movaps [rdx], xmm1
00007895b19d9cad  movaps [rcx], xmm13
00007895b19d9cb1  mov rax, 0x59D4522A9A50
00007895b19d9cbb  call rax
00007895b19d9cbd  movaps xmm10, [rsp]
00007895b19d9cc2  add rsp, 0x40
00007895b19d9cc6  vmovaps xmm0, [rsp]
00007895b19d9ccb  vmovaps xmm1, [rsp+0x10]
00007895b19d9cd1  vmovaps xmm2, [rsp+0x20]
00007895b19d9cd7  vmovaps xmm3, [rsp+0x30]
00007895b19d9cdd  vmovaps xmm4, [rsp+0x40]
00007895b19d9ce3  vmovaps xmm5, [rsp+0x50]
00007895b19d9ce9  vmovaps xmm6, [rsp+0x60]
00007895b19d9cef  vmovaps xmm7, [rsp+0x70]
00007895b19d9cf5  vmovaps xmm8, [rsp+0x80]
00007895b19d9cfe  vmovaps xmm9, [rsp+0x90]
00007895b19d9d07  vmovaps xmm11, [rsp+0xA0]
00007895b19d9d10  vmovaps xmm12, [rsp+0xB0]
00007895b19d9d19  vmovaps xmm13, [rsp+0xC0]
00007895b19d9d22  vmovaps xmm14, [rsp+0xD0]
00007895b19d9d2b  vmovaps xmm15, [rsp+0xE0]
00007895b19d9d34  add rsp, 0xF0
00007895b19d9d3b  pop r11
00007895b19d9d3d  pop r10
00007895b19d9d3f  pop r9
00007895b19d9d41  pop r8
00007895b19d9d43  pop rsi
00007895b19d9d44  pop rdi
00007895b19d9d45  pop rdx
00007895b19d9d46  pop rcx
00007895b19d9d47  pop rax
00007895b19d9d48  add rsp, 0x08
00007895b19d9d4c  jmp 0x00007895B19D7448
00007895b19d9d51  call 0x00007895B17FF430
00007895b19d9d56  jmp 0x00007895B19D745A
00007895b19d9d5b  sub rsp, 0x08
00007895b19d9d5f  push rax
00007895b19d9d60  push rcx
00007895b19d9d61  push rdx
00007895b19d9d62  push rdi
00007895b19d9d63  push rsi
00007895b19d9d64  push r8
00007895b19d9d66  push r9
00007895b19d9d68  push r10
00007895b19d9d6a  push r11
00007895b19d9d6c  sub rsp, 0xF0
00007895b19d9d73  vmovaps [rsp], xmm0
00007895b19d9d78  vmovaps [rsp+0x10], xmm1
00007895b19d9d7e  vmovaps [rsp+0x20], xmm2
00007895b19d9d84  vmovaps [rsp+0x30], xmm3
00007895b19d9d8a  vmovaps [rsp+0x40], xmm4
00007895b19d9d90  vmovaps [rsp+0x50], xmm5
00007895b19d9d96  vmovaps [rsp+0x60], xmm6
00007895b19d9d9c  vmovaps [rsp+0x70], xmm7
00007895b19d9da2  vmovaps [rsp+0x80], xmm8
00007895b19d9dab  vmovaps [rsp+0x90], xmm10
00007895b19d9db4  vmovaps [rsp+0xA0], xmm11
00007895b19d9dbd  vmovaps [rsp+0xB0], xmm12
00007895b19d9dc6  vmovaps [rsp+0xC0], xmm13
00007895b19d9dcf  vmovaps [rsp+0xD0], xmm14
00007895b19d9dd8  vmovaps [rsp+0xE0], xmm15
00007895b19d9de1  sub rsp, 0x40
00007895b19d9de5  lea rdi, [rsp]
00007895b19d9de9  lea rsi, [rsp+0x10]
00007895b19d9dee  lea rdx, [rsp+0x20]
00007895b19d9df3  lea rcx, [rsp+0x30]
00007895b19d9df8  mov r8d, 0x00
00007895b19d9dfe  lea r9, [r15+0x3A8]
00007895b19d9e05  movaps [rdi], xmm9
00007895b19d9e09  movaps [rsi], xmm8
00007895b19d9e0d  movaps [rdx], xmm14
00007895b19d9e11  movaps [rcx], xmm13
00007895b19d9e15  mov rax, 0x59D4522A9A50
00007895b19d9e1f  call rax
00007895b19d9e21  movaps xmm9, [rsp]
00007895b19d9e26  add rsp, 0x40
00007895b19d9e2a  vmovaps xmm0, [rsp]
00007895b19d9e2f  vmovaps xmm1, [rsp+0x10]
00007895b19d9e35  vmovaps xmm2, [rsp+0x20]
00007895b19d9e3b  vmovaps xmm3, [rsp+0x30]
00007895b19d9e41  vmovaps xmm4, [rsp+0x40]
00007895b19d9e47  vmovaps xmm5, [rsp+0x50]
00007895b19d9e4d  vmovaps xmm6, [rsp+0x60]
00007895b19d9e53  vmovaps xmm7, [rsp+0x70]
00007895b19d9e59  vmovaps xmm8, [rsp+0x80]
00007895b19d9e62  vmovaps xmm10, [rsp+0x90]
00007895b19d9e6b  vmovaps xmm11, [rsp+0xA0]
00007895b19d9e74  vmovaps xmm12, [rsp+0xB0]
00007895b19d9e7d  vmovaps xmm13, [rsp+0xC0]
00007895b19d9e86  vmovaps xmm14, [rsp+0xD0]
00007895b19d9e8f  vmovaps xmm15, [rsp+0xE0]
00007895b19d9e98  add rsp, 0xF0
00007895b19d9e9f  pop r11
00007895b19d9ea1  pop r10
00007895b19d9ea3  pop r9
00007895b19d9ea5  pop r8
00007895b19d9ea7  pop rsi
00007895b19d9ea8  pop rdi
00007895b19d9ea9  pop rdx
00007895b19d9eaa  pop rcx
00007895b19d9eab  pop rax
00007895b19d9eac  add rsp, 0x08
00007895b19d9eb0  jmp 0x00007895B19D7488
00007895b19d9eb5  sub rsp, 0x08
00007895b19d9eb9  push rax
00007895b19d9eba  push rcx
00007895b19d9ebb  push rdx
00007895b19d9ebc  push rdi
00007895b19d9ebd  push rsi
00007895b19d9ebe  push r8
00007895b19d9ec0  push r9
00007895b19d9ec2  push r10
00007895b19d9ec4  push r11
00007895b19d9ec6  sub rsp, 0xF0
00007895b19d9ecd  vmovaps [rsp], xmm0
00007895b19d9ed2  vmovaps [rsp+0x10], xmm1
00007895b19d9ed8  vmovaps [rsp+0x20], xmm2
00007895b19d9ede  vmovaps [rsp+0x30], xmm3
00007895b19d9ee4  vmovaps [rsp+0x40], xmm4
00007895b19d9eea  vmovaps [rsp+0x50], xmm5
00007895b19d9ef0  vmovaps [rsp+0x60], xmm6
00007895b19d9ef6  vmovaps [rsp+0x70], xmm7
00007895b19d9efc  vmovaps [rsp+0x80], xmm8
00007895b19d9f05  vmovaps [rsp+0x90], xmm9
00007895b19d9f0e  vmovaps [rsp+0xA0], xmm10
00007895b19d9f17  vmovaps [rsp+0xB0], xmm11
00007895b19d9f20  vmovaps [rsp+0xC0], xmm12
00007895b19d9f29  vmovaps [rsp+0xD0], xmm14
00007895b19d9f32  vmovaps [rsp+0xE0], xmm15
00007895b19d9f3b  sub rsp, 0x40
00007895b19d9f3f  lea rdi, [rsp]
00007895b19d9f43  lea rsi, [rsp+0x10]
00007895b19d9f48  lea rdx, [rsp+0x20]
00007895b19d9f4d  lea rcx, [rsp+0x30]
00007895b19d9f52  mov r8d, 0x00
00007895b19d9f58  lea r9, [r15+0x3A8]
00007895b19d9f5f  movaps [rdi], xmm13
00007895b19d9f63  movaps [rsi], xmm11
00007895b19d9f67  movaps [rdx], xmm15
00007895b19d9f6b  movaps [rcx], xmm14
00007895b19d9f6f  mov rax, 0x59D4522A9A50
00007895b19d9f79  call rax
00007895b19d9f7b  movaps xmm13, [rsp]
00007895b19d9f80  add rsp, 0x40
00007895b19d9f84  vmovaps xmm0, [rsp]
00007895b19d9f89  vmovaps xmm1, [rsp+0x10]
00007895b19d9f8f  vmovaps xmm2, [rsp+0x20]
00007895b19d9f95  vmovaps xmm3, [rsp+0x30]
00007895b19d9f9b  vmovaps xmm4, [rsp+0x40]
00007895b19d9fa1  vmovaps xmm5, [rsp+0x50]
00007895b19d9fa7  vmovaps xmm6, [rsp+0x60]
00007895b19d9fad  vmovaps xmm7, [rsp+0x70]
00007895b19d9fb3  vmovaps xmm8, [rsp+0x80]
00007895b19d9fbc  vmovaps xmm9, [rsp+0x90]
00007895b19d9fc5  vmovaps xmm10, [rsp+0xA0]
00007895b19d9fce  vmovaps xmm11, [rsp+0xB0]
00007895b19d9fd7  vmovaps xmm12, [rsp+0xC0]
00007895b19d9fe0  vmovaps xmm14, [rsp+0xD0]
00007895b19d9fe9  vmovaps xmm15, [rsp+0xE0]
00007895b19d9ff2  add rsp, 0xF0
00007895b19d9ff9  pop r11
00007895b19d9ffb  pop r10
00007895b19d9ffd  pop r9
00007895b19d9fff  pop r8
00007895b19da001  pop rsi
00007895b19da002  pop rdi
00007895b19da003  pop rdx
00007895b19da004  pop rcx
00007895b19da005  pop rax
00007895b19da006  add rsp, 0x08
00007895b19da00a  jmp 0x00007895B19D74B6
00007895b19da00f  sub rsp, 0x08
00007895b19da013  push rax
00007895b19da014  push rcx
00007895b19da015  push rdx
00007895b19da016  push rdi
00007895b19da017  push rsi
00007895b19da018  push r8
00007895b19da01a  push r9
00007895b19da01c  push r10
00007895b19da01e  push r11
00007895b19da020  sub rsp, 0xF0
00007895b19da027  vmovaps [rsp], xmm0
00007895b19da02c  vmovaps [rsp+0x10], xmm1
00007895b19da032  vmovaps [rsp+0x20], xmm2
00007895b19da038  vmovaps [rsp+0x30], xmm3
00007895b19da03e  vmovaps [rsp+0x40], xmm4
00007895b19da044  vmovaps [rsp+0x50], xmm5
00007895b19da04a  vmovaps [rsp+0x60], xmm6
00007895b19da050  vmovaps [rsp+0x70], xmm7
00007895b19da056  vmovaps [rsp+0x80], xmm8
00007895b19da05f  vmovaps [rsp+0x90], xmm9
00007895b19da068  vmovaps [rsp+0xA0], xmm10
00007895b19da071  vmovaps [rsp+0xB0], xmm11
00007895b19da07a  vmovaps [rsp+0xC0], xmm12
00007895b19da083  vmovaps [rsp+0xD0], xmm13
00007895b19da08c  vmovaps [rsp+0xE0], xmm15
00007895b19da095  sub rsp, 0x40
00007895b19da099  lea rdi, [rsp]
00007895b19da09d  lea rsi, [rsp+0x10]
00007895b19da0a2  lea rdx, [rsp+0x20]
00007895b19da0a7  lea rcx, [rsp+0x30]
00007895b19da0ac  mov r8d, 0x00
00007895b19da0b2  lea r9, [r15+0x3A8]
00007895b19da0b9  movaps [rdi], xmm14
00007895b19da0bd  movaps [rsi], xmm12
00007895b19da0c1  movaps [rdx], xmm1
00007895b19da0c4  movaps [rcx], xmm15
00007895b19da0c8  mov rax, 0x59D4522A9A50
00007895b19da0d2  call rax
00007895b19da0d4  movaps xmm14, [rsp]
00007895b19da0d9  add rsp, 0x40
00007895b19da0dd  vmovaps xmm0, [rsp]
00007895b19da0e2  vmovaps xmm1, [rsp+0x10]
00007895b19da0e8  vmovaps xmm2, [rsp+0x20]
00007895b19da0ee  vmovaps xmm3, [rsp+0x30]
00007895b19da0f4  vmovaps xmm4, [rsp+0x40]
00007895b19da0fa  vmovaps xmm5, [rsp+0x50]
00007895b19da100  vmovaps xmm6, [rsp+0x60]
00007895b19da106  vmovaps xmm7, [rsp+0x70]
00007895b19da10c  vmovaps xmm8, [rsp+0x80]
00007895b19da115  vmovaps xmm9, [rsp+0x90]
00007895b19da11e  vmovaps xmm10, [rsp+0xA0]
00007895b19da127  vmovaps xmm11, [rsp+0xB0]
00007895b19da130  vmovaps xmm12, [rsp+0xC0]
00007895b19da139  vmovaps xmm13, [rsp+0xD0]
00007895b19da142  vmovaps xmm15, [rsp+0xE0]
00007895b19da14b  add rsp, 0xF0
00007895b19da152  pop r11
00007895b19da154  pop r10
00007895b19da156  pop r9
00007895b19da158  pop r8
00007895b19da15a  pop rsi
00007895b19da15b  pop rdi
00007895b19da15c  pop rdx
00007895b19da15d  pop rcx
00007895b19da15e  pop rax
00007895b19da15f  add rsp, 0x08
00007895b19da163  jmp 0x00007895B19D74E4
00007895b19da168  call 0x00007895B18079B0
00007895b19da16d  jmp 0x00007895B19D74FA
00007895b19da172  call 0x00007895B18E3440
00007895b19da177  jmp 0x00007895B19D7504
00007895b19da17c  call 0x00007895B18DFCE0
00007895b19da181  jmp 0x00007895B19D750E
00007895b19da186  call 0x00007895B18E46C0
00007895b19da18b  jmp 0x00007895B19D7518
00007895b19da190  int3
00007895b19da191  nop [rax+rax*1], ax
00007895b19da19a  nop [rax+rax*1], ax
00007895b19da1a0  mov rax, [r15+0xF8]
00007895b19da1a7  lea r14, [rax+0x110]
00007895b19da1ae  mov r12, [r13+r14*1]
00007895b19da1b3  mov [r15+0xE8], r12
00007895b19da1ba  lea r14, [rax+0x100]
00007895b19da1c1  mov r12, [r13+r14*1]
00007895b19da1c6  lea r14, [rax+0x108]
00007895b19da1cd  mov r11, [r13+r14*1]
00007895b19da1d2  movq xmm1, r12
00007895b19da1d7  movq xmm15, r11
00007895b19da1dc  movq xmm1, xmm1
00007895b19da1e0  movq xmm1, xmm1
00007895b19da1e4  movaps [r15+0x1A0], xmm1
00007895b19da1ec  movq xmm15, xmm15
00007895b19da1f1  movq xmm15, xmm15
00007895b19da1f6  movaps [r15+0x190], xmm15
00007895b19da1fe  lea r14, [rax+0xF0]
00007895b19da205  mov r12, [r13+r14*1]
00007895b19da20a  lea r14, [rax+0xF8]
00007895b19da211  mov r11, [r13+r14*1]
00007895b19da216  movq xmm1, r12
00007895b19da21b  movq xmm15, r11
00007895b19da220  movq xmm1, xmm1
00007895b19da224  movq xmm1, xmm1
00007895b19da228  movaps [r15+0x1C0], xmm1
00007895b19da230  movq xmm15, xmm15
00007895b19da235  movq xmm15, xmm15
00007895b19da23a  movaps [r15+0x1B0], xmm15
00007895b19da242  lea r14, [rax+0xE0]
00007895b19da249  mov r12, [r13+r14*1]
00007895b19da24e  lea r14, [rax+0xE8]
00007895b19da255  mov r11, [r13+r14*1]
00007895b19da25a  movq xmm1, r12
00007895b19da25f  movq xmm15, r11
00007895b19da264  movq xmm1, xmm1
00007895b19da268  movq xmm1, xmm1
00007895b19da26c  movaps [r15+0x1E0], xmm1
00007895b19da274  movq xmm15, xmm15
00007895b19da279  movq xmm15, xmm15
00007895b19da27e  movaps [r15+0x1D0], xmm15
00007895b19da286  lea r14, [rax+0xD0]
00007895b19da28d  mov r12, [r13+r14*1]
00007895b19da292  lea r14, [rax+0xD8]
00007895b19da299  mov r11, [r13+r14*1]
00007895b19da29e  movq xmm1, r12
00007895b19da2a3  movq xmm15, r11
00007895b19da2a8  movq xmm1, xmm1
00007895b19da2ac  movq xmm1, xmm1
00007895b19da2b0  movaps [r15+0x200], xmm1
00007895b19da2b8  movq xmm15, xmm15
00007895b19da2bd  movq xmm15, xmm15
00007895b19da2c2  movaps [r15+0x1F0], xmm15
00007895b19da2ca  mov qword ptr [r15+0x40], 0x430000
00007895b19da2d2  mov r14d, 0x4304C0
00007895b19da2d8  mov r12, [r13+r14*1]
00007895b19da2dd  movq xmm1, r12
00007895b19da2e2  lea r14, [rax+0x120]
00007895b19da2e9  mov [r15+0xF8], r14
00007895b19da2f0  mov rax, [r15+0x50]
00007895b19da2f4  movups xmm15, [r13+rax*1]
00007895b19da2fa  movaps [r15+0x120], xmm15
00007895b19da302  mov qword ptr [r15+0x48], 0x10
00007895b19da30a  xor eax, eax
00007895b19da30c  mov r14d, 0x10
00007895b19da312  mov r12d, 0x200
00007895b19da318  cmp r14, r12
00007895b19da31b  cmc
00007895b19da31c  lahf
00007895b19da31d  seto al
00007895b19da320  mov [r15+0x108], eax
00007895b19da327  pextrq rax, xmm15, 0x01
00007895b19da32e  movq xmm14, rax
00007895b19da333  movaps [r15+0x130], xmm14
00007895b19da33b  movq rax, xmm1
00007895b19da340  movq r14, xmm15
00007895b19da345  vmovq xmm1, rax
00007895b19da34a  vmovq xmm15, r14
00007895b19da34f  movaps xmm13, xmm1
00007895b19da353  addsd xmm13, xmm15
00007895b19da358  ucomisd xmm13, xmm13
00007895b19da35d  jp 0x00007895B19DA476
00007895b19da363  movq xmm13, xmm13
00007895b19da368  movq rax, xmm13
00007895b19da36d  movq r14, xmm14
00007895b19da372  vmovq xmm1, rax
00007895b19da377  vmovq xmm15, r14
00007895b19da37c  movaps xmm14, xmm1
00007895b19da380  addsd xmm14, xmm15
00007895b19da385  ucomisd xmm14, xmm14
00007895b19da38a  jp 0x00007895B19DA4BE
00007895b19da390  movq xmm14, xmm14
00007895b19da395  movaps [r15+0x110], xmm14
00007895b19da39d  mov eax, [r15+0x108]
00007895b19da3a4  sahf
00007895b19da3a5  jnz 0x00007895B19DA3D7
00007895b19da3a7  cmp dword ptr [r15+0x318], 0x00
00007895b19da3af  jz 0x00007895B19DA6D0
00007895b19da3b5  nop [rax+rax*1], ax
00007895b19da3be  nop [rax+rax*1], eax
00007895b19da3c6  mov eax, 0x41043C
00007895b19da3cb  mov [r15+0x100], rax
00007895b19da3d2  jmp 0x00007895B17FE110
00007895b19da3d7  cmp dword ptr [r15+0x318], 0x00
00007895b19da3df  jz 0x00007895B19DA510
00007895b19da3e5  nop [rax+rax*1], ax
00007895b19da3ee  nop [rax+rax*1], eax
00007895b19da3f6  mov eax, 0x410420
00007895b19da3fb  mov [r15+0x100], rax
00007895b19da402  jmp 0x00007895B17FE110
00007895b19da407  int3
00007895b19da408  call 0x00007895B18E27E0
00007895b19da40d  jmp 0x00007895B19DA1B3
00007895b19da412  call 0x00007895B18E27E0
00007895b19da417  jmp 0x00007895B19DA1C6
00007895b19da41c  call 0x00007895B18E1570
00007895b19da421  jmp 0x00007895B19DA1D2
00007895b19da426  call 0x00007895B18E27E0
00007895b19da42b  jmp 0x00007895B19DA20A
00007895b19da430  call 0x00007895B18E1570
00007895b19da435  jmp 0x00007895B19DA216
00007895b19da43a  call 0x00007895B18E27E0
00007895b19da43f  jmp 0x00007895B19DA24E
00007895b19da444  call 0x00007895B18E1570
00007895b19da449  jmp 0x00007895B19DA25A
00007895b19da44e  call 0x00007895B18E27E0
00007895b19da453  jmp 0x00007895B19DA292
00007895b19da458  call 0x00007895B18E1570
00007895b19da45d  jmp 0x00007895B19DA29E
00007895b19da462  call 0x00007895B18E27E0
00007895b19da467  jmp 0x00007895B19DA2DD
00007895b19da46c  call 0x00007895B180E760
00007895b19da471  jmp 0x00007895B19DA2FA
00007895b19da476  ucomisd xmm1, xmm15
00007895b19da47b  jp 0x00007895B19DA48A
00007895b19da47d  movaps xmm13, [0x00007895B15FE060]
00007895b19da485  jmp 0x00007895B19DA363
00007895b19da48a  vxorps xmm0, xmm1, xmm15
00007895b19da48f  pextrw eax, xmm0, 0x03
00007895b19da494  and eax, 0x7FF8
00007895b19da499  cmp eax, 0x08
00007895b19da49c  jnz 0x00007895B19DA363
00007895b19da4a2  movq rax, xmm15
00007895b19da4a7  shl rax, 0x0D
00007895b19da4ab  jbe 0x00007895B19DA363
00007895b19da4b1  vorps xmm13, xmm15, [0x00007895B15FE070]
00007895b19da4b9  jmp 0x00007895B19DA363
00007895b19da4be  ucomisd xmm1, xmm15
00007895b19da4c3  jp 0x00007895B19DA4D2
00007895b19da4c5  movaps xmm14, [0x00007895B15FE060]
00007895b19da4cd  jmp 0x00007895B19DA390
00007895b19da4d2  vxorps xmm0, xmm1, xmm15
00007895b19da4d7  pextrw eax, xmm0, 0x03
00007895b19da4dc  and eax, 0x7FF8
00007895b19da4e1  cmp eax, 0x08
00007895b19da4e4  jnz 0x00007895B19DA390
00007895b19da4ea  movq rax, xmm15
00007895b19da4ef  shl rax, 0x0D
00007895b19da4f3  jbe 0x00007895B19DA390
00007895b19da4f9  vorps xmm14, xmm15, [0x00007895B15FE070]
00007895b19da501  jmp 0x00007895B19DA390
00007895b19da506  int3
00007895b19da507  nop [rax+rax*1], ax
00007895b19da510  mov rax, [r15+0x48]
00007895b19da514  mov r14, [r15+0x50]
00007895b19da518  lea r12, [r14+rax*1]
00007895b19da51c  movups xmm1, [r13+r12*1]
00007895b19da522  movaps [r15+0x120], xmm1
00007895b19da52a  lea r14, [rax+0x10]
00007895b19da52e  mov [r15+0x48], r14
00007895b19da532  xor eax, eax
00007895b19da534  mov r12d, 0x200
00007895b19da53a  cmp r14, r12
00007895b19da53d  cmc
00007895b19da53e  lahf
00007895b19da53f  seto al
00007895b19da542  mov [r15+0x108], eax
00007895b19da549  pextrq rax, xmm1, 0x01
00007895b19da550  movq xmm15, rax
00007895b19da555  movaps [r15+0x130], xmm15
00007895b19da55d  movaps xmm14, [r15+0x110]
00007895b19da565  movq rax, xmm14
00007895b19da56a  movq r14, xmm1
00007895b19da56f  vmovq xmm1, rax
00007895b19da574  vmovq xmm14, r14
00007895b19da579  movaps xmm13, xmm1
00007895b19da57d  addsd xmm13, xmm14
00007895b19da582  ucomisd xmm13, xmm13
00007895b19da587  jp 0x00007895B19DA63C
00007895b19da58d  movq xmm13, xmm13
00007895b19da592  movq rax, xmm13
00007895b19da597  movq r14, xmm15
00007895b19da59c  vmovq xmm1, rax
00007895b19da5a1  vmovq xmm15, r14
00007895b19da5a6  movaps xmm14, xmm1
00007895b19da5aa  addsd xmm14, xmm15
00007895b19da5af  ucomisd xmm14, xmm14
00007895b19da5b4  jp 0x00007895B19DA684
00007895b19da5ba  movq xmm14, xmm14
00007895b19da5bf  movaps [r15+0x110], xmm14
00007895b19da5c7  mov eax, [r15+0x108]
00007895b19da5ce  sahf
00007895b19da5cf  jnz 0x00007895B19DA601
00007895b19da5d1  cmp dword ptr [r15+0x318], 0x00
00007895b19da5d9  jz 0x00007895B19DA6D0
00007895b19da5df  nop [rax+rax*1], ax
00007895b19da5e8  nop [rax+rax*1], eax
00007895b19da5f0  mov eax, 0x41043C
00007895b19da5f5  mov [r15+0x100], rax
00007895b19da5fc  jmp 0x00007895B17FE110
00007895b19da601  cmp dword ptr [r15+0x318], 0x00
00007895b19da609  jz 0x00007895B19DA510
00007895b19da60f  nop [rax+rax*1], ax
00007895b19da618  nop [rax+rax*1], eax
00007895b19da620  mov eax, 0x410420
00007895b19da625  mov [r15+0x100], rax
00007895b19da62c  jmp 0x00007895B17FE110
00007895b19da631  int3
00007895b19da632  call 0x00007895B18B52F0
00007895b19da637  jmp 0x00007895B19DA522
00007895b19da63c  ucomisd xmm1, xmm14
00007895b19da641  jp 0x00007895B19DA650
00007895b19da643  movaps xmm13, [0x00007895B15FE060]
00007895b19da64b  jmp 0x00007895B19DA58D
00007895b19da650  vxorps xmm0, xmm1, xmm14
00007895b19da655  pextrw eax, xmm0, 0x03
00007895b19da65a  and eax, 0x7FF8
00007895b19da65f  cmp eax, 0x08
00007895b19da662  jnz 0x00007895B19DA58D
00007895b19da668  movq rax, xmm14
00007895b19da66d  shl rax, 0x0D
00007895b19da671  jbe 0x00007895B19DA58D
00007895b19da677  vorps xmm13, xmm14, [0x00007895B15FE070]
00007895b19da67f  jmp 0x00007895B19DA58D
00007895b19da684  ucomisd xmm1, xmm15
00007895b19da689  jp 0x00007895B19DA698
00007895b19da68b  movaps xmm14, [0x00007895B15FE060]
00007895b19da693  jmp 0x00007895B19DA5BA
00007895b19da698  vxorps xmm0, xmm1, xmm15
00007895b19da69d  pextrw eax, xmm0, 0x03
00007895b19da6a2  and eax, 0x7FF8
00007895b19da6a7  cmp eax, 0x08
00007895b19da6aa  jnz 0x00007895B19DA5BA
00007895b19da6b0  movq rax, xmm15
00007895b19da6b5  shl rax, 0x0D
00007895b19da6b9  jbe 0x00007895B19DA5BA
00007895b19da6bf  vorps xmm14, xmm15, [0x00007895B15FE070]
00007895b19da6c7  jmp 0x00007895B19DA5BA
00007895b19da6cc  int3
00007895b19da6cd  nop [rax], eax
00007895b19da6d0  mov rax, [r15+0x40]
00007895b19da6d4  lea r14, [rax+0x4C0]
00007895b19da6db  movaps xmm1, [r15+0x110]
00007895b19da6e3  movq rax, xmm1
00007895b19da6e8  mov [r13+r14*1], rax
00007895b19da6ed  mov rax, [r15+0xF0]
00007895b19da6f4  mov [r15+0x100], rax
00007895b19da6fb  jmp 0x00007895B19CE5C0
00007895b19da700  int3
00007895b19da701  call 0x00007895B18D5EB0
00007895b19da706  jmp 0x00007895B19DA6ED
00007895b19da70b  int3
00007895b19da70c  nop [rax], eax
00007895b19da710  mov qword ptr [r15+0x100], 0x04
00007895b19da71b  mov esi, 0x00
00007895b19da720  mov edx, 0x09
00007895b19da725  mov rdi, 0x7FFCF1717580
00007895b19da72f  mov rax, 0x59D45213C970
00007895b19da739  call rax
00007895b19da73b  cmp dword ptr [r15+0x318], 0x00
00007895b19da743  jnz 0x00007895B17FE110
00007895b19da749  jmp 0x00007895B17FE0A0
00007895b19da74e  int3
00007895b19da74f  int3
