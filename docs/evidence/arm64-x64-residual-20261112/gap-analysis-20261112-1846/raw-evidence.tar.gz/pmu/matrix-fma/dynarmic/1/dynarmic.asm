0000774654fce69b  nop [rax+rax*1], eax
0000774654fce6a0  vmovaps xmm1, [0x0000774654BFE010]
0000774654fce6a8  movq xmm1, xmm1
0000774654fce6ac  movaps [r15+0x110], xmm1
0000774654fce6b4  vmovaps xmm1, [0x0000774654BFE020]
0000774654fce6bc  movq xmm1, xmm1
0000774654fce6c0  movaps [r15+0x120], xmm1
0000774654fce6c8  mov eax, 0x420470
0000774654fce6cd  mov r14, [r13+rax*1]
0000774654fce6d2  movq xmm1, r14
0000774654fce6d7  movaps [r15+0x130], xmm1
0000774654fce6df  vmovaps xmm1, [0x0000774654BFE030]
0000774654fce6e7  vpbroadcastq xmm1, xmm1
0000774654fce6ec  movaps [r15+0x140], xmm1
0000774654fce6f4  mov qword ptr [r15+0x40], 0x02
0000774654fce6fc  vmovaps xmm15, [0x0000774654BFE040]
0000774654fce704  movq xmm15, xmm15
0000774654fce709  movaps [r15+0x150], xmm15
0000774654fce711  mov qword ptr [r15+0x58], 0x420000
0000774654fce719  vmovaps xmm15, [0x0000774654BFE050]
0000774654fce721  vpbroadcastq xmm15, xmm15
0000774654fce726  movaps [r15+0x160], xmm15
0000774654fce72e  mov rax, [r15+0x40]
0000774654fce732  vmovq xmm14, rax
0000774654fce737  vpbroadcastq xmm14, xmm14
0000774654fce73c  movaps [r15+0x170], xmm14
0000774654fce744  mov eax, 0x420480
0000774654fce749  movups xmm13, [r13+rax*1]
0000774654fce74f  mov qword ptr [r15+0x40], 0x4304C8
0000774654fce757  mov qword ptr [r15+0x50], 0x4306D0
0000774654fce75f  vpmovqd xmm12, xmm13
0000774654fce765  pxor xmm11, xmm11
0000774654fce76a  punpcklqdq xmm12, xmm11
0000774654fce76f  movaps [r15+0x210], xmm12
0000774654fce777  movq xmm12, qword ptr [r15+0x120]
0000774654fce780  movq xmm11, qword ptr [r15+0x130]
0000774654fce789  psubd xmm12, xmm11
0000774654fce78e  movq xmm12, xmm12
0000774654fce793  paddq xmm13, xmm14
0000774654fce798  movaps [r15+0x180], xmm13
0000774654fce7a0  movq xmm14, qword ptr [r15+0x150]
0000774654fce7a9  paddd xmm11, xmm14
0000774654fce7ae  movq xmm11, xmm11
0000774654fce7b3  movq xmm11, xmm11
0000774654fce7b8  movaps [r15+0x130], xmm11
0000774654fce7c0  pmovzxdq xmm12, xmm12
0000774654fce7c6  psllq xmm12, 0x00
0000774654fce7cc  movq xmm14, qword ptr [r15+0x210]
0000774654fce7d5  movq xmm13, qword ptr [r15+0x110]
0000774654fce7de  paddd xmm14, xmm13
0000774654fce7e3  movq xmm14, xmm14
0000774654fce7e8  vcvtuqq2pd xmm12, xmm12
0000774654fce7ee  pmovzxdq xmm14, xmm14
0000774654fce7f4  psllq xmm14, 0x00
0000774654fce7fa  vcvtuqq2pd xmm14, xmm14
0000774654fce800  movaps xmm13, xmm12
0000774654fce804  mulpd xmm13, xmm1
0000774654fce809  vcmppd xmm11, xmm13, xmm13, 0x03
0000774654fce80f  ptest xmm11, xmm11
0000774654fce815  jnz 0x0000774654FCE8FF
0000774654fce81b  movaps [r15+0x220], xmm13
0000774654fce823  mov eax, 0x4306D0
0000774654fce828  movups [r13+rax*1], xmm13
0000774654fce82e  movaps xmm1, xmm14
0000774654fce832  mulpd xmm1, xmm15
0000774654fce837  vcmppd xmm13, xmm1, xmm1, 0x03
0000774654fce83c  ptest xmm13, xmm13
0000774654fce842  jnz 0x0000774654FCEA4C
0000774654fce848  movaps [r15+0x210], xmm1
0000774654fce850  mov eax, 0x4304C8
0000774654fce855  movups [r13+rax*1], xmm1
0000774654fce85b  mov qword ptr [r15+0x48], 0x10
0000774654fce863  xor eax, eax
0000774654fce865  mov r14d, 0x10
0000774654fce86b  mov r12d, 0x200
0000774654fce871  cmp r14, r12
0000774654fce874  cmc
0000774654fce875  lahf
0000774654fce876  seto al
0000774654fce879  mov [r15+0x108], eax
0000774654fce880  mov eax, [r15+0x108]
0000774654fce887  sahf
0000774654fce888  jnz 0x0000774654FCE8BA
0000774654fce88a  cmp dword ptr [r15+0x318], 0x00
0000774654fce892  jz 0x0000774654FCEFF0
0000774654fce898  nop [rax+rax*1], ax
0000774654fce8a1  nop [rax+rax*1], eax
0000774654fce8a9  mov eax, 0x4101EC
0000774654fce8ae  mov [r15+0x100], rax
0000774654fce8b5  jmp 0x0000774654DFE110
0000774654fce8ba  cmp dword ptr [r15+0x318], 0x00
0000774654fce8c2  jz 0x0000774654FCEBA0
0000774654fce8c8  nop [rax+rax*1], ax
0000774654fce8d1  nop [rax+rax*1], eax
0000774654fce8d9  mov eax, 0x4101AC
0000774654fce8de  mov [r15+0x100], rax
0000774654fce8e5  jmp 0x0000774654DFE110
0000774654fce8ea  int3
0000774654fce8eb  call 0x0000774654E0DC20
0000774654fce8f0  jmp 0x0000774654FCE6D2
0000774654fce8f5  call 0x0000774654E0C260
0000774654fce8fa  jmp 0x0000774654FCE74F
0000774654fce8ff  sub rsp, 0x08
0000774654fce903  push rax
0000774654fce904  push rcx
0000774654fce905  push rdx
0000774654fce906  push rdi
0000774654fce907  push rsi
0000774654fce908  push r8
0000774654fce90a  push r9
0000774654fce90c  push r10
0000774654fce90e  push r11
0000774654fce910  sub rsp, 0xF0
0000774654fce917  vmovaps [rsp], xmm0
0000774654fce91c  vmovaps [rsp+0x10], xmm1
0000774654fce922  vmovaps [rsp+0x20], xmm2
0000774654fce928  vmovaps [rsp+0x30], xmm3
0000774654fce92e  vmovaps [rsp+0x40], xmm4
0000774654fce934  vmovaps [rsp+0x50], xmm5
0000774654fce93a  vmovaps [rsp+0x60], xmm6
0000774654fce940  vmovaps [rsp+0x70], xmm7
0000774654fce946  vmovaps [rsp+0x80], xmm8
0000774654fce94f  vmovaps [rsp+0x90], xmm9
0000774654fce958  vmovaps [rsp+0xA0], xmm10
0000774654fce961  vmovaps [rsp+0xB0], xmm11
0000774654fce96a  vmovaps [rsp+0xC0], xmm12
0000774654fce973  vmovaps [rsp+0xD0], xmm14
0000774654fce97c  vmovaps [rsp+0xE0], xmm15
0000774654fce985  sub rsp, 0x30
0000774654fce989  movaps [rsp], xmm13
0000774654fce98e  movaps [rsp+0x10], xmm12
0000774654fce994  movaps [rsp+0x20], xmm1
0000774654fce999  lea rdi, [rsp]
0000774654fce99d  mov esi, 0x00
0000774654fce9a2  mov rax, 0x564E5D1DD530
0000774654fce9ac  call rax
0000774654fce9ae  movaps xmm13, [rsp]
0000774654fce9b3  add rsp, 0x30
0000774654fce9b7  vmovaps xmm0, [rsp]
0000774654fce9bc  vmovaps xmm1, [rsp+0x10]
0000774654fce9c2  vmovaps xmm2, [rsp+0x20]
0000774654fce9c8  vmovaps xmm3, [rsp+0x30]
0000774654fce9ce  vmovaps xmm4, [rsp+0x40]
0000774654fce9d4  vmovaps xmm5, [rsp+0x50]
0000774654fce9da  vmovaps xmm6, [rsp+0x60]
0000774654fce9e0  vmovaps xmm7, [rsp+0x70]
0000774654fce9e6  vmovaps xmm8, [rsp+0x80]
0000774654fce9ef  vmovaps xmm9, [rsp+0x90]
0000774654fce9f8  vmovaps xmm10, [rsp+0xA0]
0000774654fcea01  vmovaps xmm11, [rsp+0xB0]
0000774654fcea0a  vmovaps xmm12, [rsp+0xC0]
0000774654fcea13  vmovaps xmm14, [rsp+0xD0]
0000774654fcea1c  vmovaps xmm15, [rsp+0xE0]
0000774654fcea25  add rsp, 0xF0
0000774654fcea2c  pop r11
0000774654fcea2e  pop r10
0000774654fcea30  pop r9
0000774654fcea32  pop r8
0000774654fcea34  pop rsi
0000774654fcea35  pop rdi
0000774654fcea36  pop rdx
0000774654fcea37  pop rcx
0000774654fcea38  pop rax
0000774654fcea39  add rsp, 0x08
0000774654fcea3d  jmp 0x0000774654FCE81B
0000774654fcea42  call 0x0000774654E0C380
0000774654fcea47  jmp 0x0000774654FCE82E
0000774654fcea4c  sub rsp, 0x08
0000774654fcea50  push rax
0000774654fcea51  push rcx
0000774654fcea52  push rdx
0000774654fcea53  push rdi
0000774654fcea54  push rsi
0000774654fcea55  push r8
0000774654fcea57  push r9
0000774654fcea59  push r10
0000774654fcea5b  push r11
0000774654fcea5d  sub rsp, 0xF0
0000774654fcea64  vmovaps [rsp], xmm0
0000774654fcea69  vmovaps [rsp+0x10], xmm2
0000774654fcea6f  vmovaps [rsp+0x20], xmm3
0000774654fcea75  vmovaps [rsp+0x30], xmm4
0000774654fcea7b  vmovaps [rsp+0x40], xmm5
0000774654fcea81  vmovaps [rsp+0x50], xmm6
0000774654fcea87  vmovaps [rsp+0x60], xmm7
0000774654fcea8d  vmovaps [rsp+0x70], xmm8
0000774654fcea93  vmovaps [rsp+0x80], xmm9
0000774654fcea9c  vmovaps [rsp+0x90], xmm10
0000774654fceaa5  vmovaps [rsp+0xA0], xmm11
0000774654fceaae  vmovaps [rsp+0xB0], xmm12
0000774654fceab7  vmovaps [rsp+0xC0], xmm13
0000774654fceac0  vmovaps [rsp+0xD0], xmm14
0000774654fceac9  vmovaps [rsp+0xE0], xmm15
0000774654fcead2  sub rsp, 0x30
0000774654fcead6  movaps [rsp], xmm1
0000774654fceada  movaps [rsp+0x10], xmm14
0000774654fceae0  movaps [rsp+0x20], xmm15
0000774654fceae6  lea rdi, [rsp]
0000774654fceaea  mov esi, 0x00
0000774654fceaef  mov rax, 0x564E5D1DD530
0000774654fceaf9  call rax
0000774654fceafb  movaps xmm1, [rsp]
0000774654fceaff  add rsp, 0x30
0000774654fceb03  vmovaps xmm0, [rsp]
0000774654fceb08  vmovaps xmm2, [rsp+0x10]
0000774654fceb0e  vmovaps xmm3, [rsp+0x20]
0000774654fceb14  vmovaps xmm4, [rsp+0x30]
0000774654fceb1a  vmovaps xmm5, [rsp+0x40]
0000774654fceb20  vmovaps xmm6, [rsp+0x50]
0000774654fceb26  vmovaps xmm7, [rsp+0x60]
0000774654fceb2c  vmovaps xmm8, [rsp+0x70]
0000774654fceb32  vmovaps xmm9, [rsp+0x80]
0000774654fceb3b  vmovaps xmm10, [rsp+0x90]
0000774654fceb44  vmovaps xmm11, [rsp+0xA0]
0000774654fceb4d  vmovaps xmm12, [rsp+0xB0]
0000774654fceb56  vmovaps xmm13, [rsp+0xC0]
0000774654fceb5f  vmovaps xmm14, [rsp+0xD0]
0000774654fceb68  vmovaps xmm15, [rsp+0xE0]
0000774654fceb71  add rsp, 0xF0
0000774654fceb78  pop r11
0000774654fceb7a  pop r10
0000774654fceb7c  pop r9
0000774654fceb7e  pop r8
0000774654fceb80  pop rsi
0000774654fceb81  pop rdi
0000774654fceb82  pop rdx
0000774654fceb83  pop rcx
0000774654fceb84  pop rax
0000774654fceb85  add rsp, 0x08
0000774654fceb89  jmp 0x0000774654FCE848
0000774654fceb8e  call 0x0000774654DFF540
0000774654fceb93  jmp 0x0000774654FCE85B
0000774654fceb98  int3
0000774654fceb99  nop [rax], eax
0000774654fceba0  movaps xmm1, [r15+0x180]
0000774654fceba8  vpmovqd xmm15, xmm1
0000774654fcebae  pxor xmm14, xmm14
0000774654fcebb3  punpcklqdq xmm15, xmm14
0000774654fcebb8  movaps [r15+0x210], xmm15
0000774654fcebc0  movq xmm15, qword ptr [r15+0x120]
0000774654fcebc9  movq xmm14, qword ptr [r15+0x130]
0000774654fcebd2  psubd xmm15, xmm14
0000774654fcebd7  movq xmm15, xmm15
0000774654fcebdc  movaps xmm13, [r15+0x170]
0000774654fcebe4  paddq xmm1, xmm13
0000774654fcebe9  movaps [r15+0x180], xmm1
0000774654fcebf1  movq xmm1, qword ptr [r15+0x150]
0000774654fcebfa  paddd xmm14, xmm1
0000774654fcebff  movq xmm14, xmm14
0000774654fcec04  movq xmm14, xmm14
0000774654fcec09  movaps [r15+0x130], xmm14
0000774654fcec11  pmovzxdq xmm15, xmm15
0000774654fcec17  psllq xmm15, 0x00
0000774654fcec1d  movq xmm1, qword ptr [r15+0x210]
0000774654fcec26  movq xmm14, qword ptr [r15+0x110]
0000774654fcec2f  paddd xmm1, xmm14
0000774654fcec34  movq xmm1, xmm1
0000774654fcec38  vcvtuqq2pd xmm15, xmm15
0000774654fcec3e  pmovzxdq xmm1, xmm1
0000774654fcec43  psllq xmm1, 0x00
0000774654fcec48  vcvtuqq2pd xmm1, xmm1
0000774654fcec4e  movaps xmm14, [r15+0x140]
0000774654fcec56  movaps xmm13, xmm15
0000774654fcec5a  mulpd xmm13, xmm14
0000774654fcec5f  vcmppd xmm12, xmm13, xmm13, 0x03
0000774654fcec65  ptest xmm12, xmm12
0000774654fcec6b  jnz 0x0000774654FCED4E
0000774654fcec71  movaps [r15+0x220], xmm13
0000774654fcec79  mov rax, [r15+0x48]
0000774654fcec7d  mov r14, [r15+0x50]
0000774654fcec81  lea r12, [r14+rax*1]
0000774654fcec85  movups [r13+r12*1], xmm13
0000774654fcec8b  movaps xmm15, [r15+0x160]
0000774654fcec93  movaps xmm14, xmm1
0000774654fcec97  mulpd xmm14, xmm15
0000774654fcec9c  vcmppd xmm13, xmm14, xmm14, 0x03
0000774654fceca2  ptest xmm13, xmm13
0000774654fceca8  jnz 0x0000774654FCEE9C
0000774654fcecae  movaps [r15+0x210], xmm14
0000774654fcecb6  mov r14, [r15+0x40]
0000774654fcecba  lea r12, [r14+rax*1]
0000774654fcecbe  movups [r13+r12*1], xmm14
0000774654fcecc4  lea r14, [rax+0x10]
0000774654fcecc8  mov [r15+0x48], r14
0000774654fceccc  xor eax, eax
0000774654fcecce  mov r12d, 0x200
0000774654fcecd4  cmp r14, r12
0000774654fcecd7  cmc
0000774654fcecd8  lahf
0000774654fcecd9  seto al
0000774654fcecdc  mov [r15+0x108], eax
0000774654fcece3  mov eax, [r15+0x108]
0000774654fcecea  sahf
0000774654fceceb  jnz 0x0000774654FCED1D
0000774654fceced  cmp dword ptr [r15+0x318], 0x00
0000774654fcecf5  jz 0x0000774654FCEFF0
0000774654fcecfb  nop [rax+rax*1], ax
0000774654fced04  nop [rax+rax*1], eax
0000774654fced0c  mov eax, 0x4101EC
0000774654fced11  mov [r15+0x100], rax
0000774654fced18  jmp 0x0000774654DFE110
0000774654fced1d  cmp dword ptr [r15+0x318], 0x00
0000774654fced25  jz 0x0000774654FCEBA0
0000774654fced2b  nop [rax+rax*1], ax
0000774654fced34  nop [rax+rax*1], eax
0000774654fced3c  mov eax, 0x4101AC
0000774654fced41  mov [r15+0x100], rax
0000774654fced48  jmp 0x0000774654DFE110
0000774654fced4d  int3
0000774654fced4e  sub rsp, 0x08
0000774654fced52  push rax
0000774654fced53  push rcx
0000774654fced54  push rdx
0000774654fced55  push rdi
0000774654fced56  push rsi
0000774654fced57  push r8
0000774654fced59  push r9
0000774654fced5b  push r10
0000774654fced5d  push r11
0000774654fced5f  sub rsp, 0xF0
0000774654fced66  vmovaps [rsp], xmm0
0000774654fced6b  vmovaps [rsp+0x10], xmm1
0000774654fced71  vmovaps [rsp+0x20], xmm2
0000774654fced77  vmovaps [rsp+0x30], xmm3
0000774654fced7d  vmovaps [rsp+0x40], xmm4
0000774654fced83  vmovaps [rsp+0x50], xmm5
0000774654fced89  vmovaps [rsp+0x60], xmm6
0000774654fced8f  vmovaps [rsp+0x70], xmm7
0000774654fced95  vmovaps [rsp+0x80], xmm8
0000774654fced9e  vmovaps [rsp+0x90], xmm9
0000774654fceda7  vmovaps [rsp+0xA0], xmm10
0000774654fcedb0  vmovaps [rsp+0xB0], xmm11
0000774654fcedb9  vmovaps [rsp+0xC0], xmm12
0000774654fcedc2  vmovaps [rsp+0xD0], xmm14
0000774654fcedcb  vmovaps [rsp+0xE0], xmm15
0000774654fcedd4  sub rsp, 0x30
0000774654fcedd8  movaps [rsp], xmm13
0000774654fceddd  movaps [rsp+0x10], xmm15
0000774654fcede3  movaps [rsp+0x20], xmm14
0000774654fcede9  lea rdi, [rsp]
0000774654fceded  mov esi, 0x00
0000774654fcedf2  mov rax, 0x564E5D1DD530
0000774654fcedfc  call rax
0000774654fcedfe  movaps xmm13, [rsp]
0000774654fcee03  add rsp, 0x30
0000774654fcee07  vmovaps xmm0, [rsp]
0000774654fcee0c  vmovaps xmm1, [rsp+0x10]
0000774654fcee12  vmovaps xmm2, [rsp+0x20]
0000774654fcee18  vmovaps xmm3, [rsp+0x30]
0000774654fcee1e  vmovaps xmm4, [rsp+0x40]
0000774654fcee24  vmovaps xmm5, [rsp+0x50]
0000774654fcee2a  vmovaps xmm6, [rsp+0x60]
0000774654fcee30  vmovaps xmm7, [rsp+0x70]
0000774654fcee36  vmovaps xmm8, [rsp+0x80]
0000774654fcee3f  vmovaps xmm9, [rsp+0x90]
0000774654fcee48  vmovaps xmm10, [rsp+0xA0]
0000774654fcee51  vmovaps xmm11, [rsp+0xB0]
0000774654fcee5a  vmovaps xmm12, [rsp+0xC0]
0000774654fcee63  vmovaps xmm14, [rsp+0xD0]
0000774654fcee6c  vmovaps xmm15, [rsp+0xE0]
0000774654fcee75  add rsp, 0xF0
0000774654fcee7c  pop r11
0000774654fcee7e  pop r10
0000774654fcee80  pop r9
0000774654fcee82  pop r8
0000774654fcee84  pop rsi
0000774654fcee85  pop rdi
0000774654fcee86  pop rdx
0000774654fcee87  pop rcx
0000774654fcee88  pop rax
0000774654fcee89  add rsp, 0x08
0000774654fcee8d  jmp 0x0000774654FCEC71
0000774654fcee92  call 0x0000774654EC2240
0000774654fcee97  jmp 0x0000774654FCEC8B
0000774654fcee9c  sub rsp, 0x08
0000774654fceea0  push rax
0000774654fceea1  push rcx
0000774654fceea2  push rdx
0000774654fceea3  push rdi
0000774654fceea4  push rsi
0000774654fceea5  push r8
0000774654fceea7  push r9
0000774654fceea9  push r10
0000774654fceeab  push r11
0000774654fceead  sub rsp, 0xF0
0000774654fceeb4  vmovaps [rsp], xmm0
0000774654fceeb9  vmovaps [rsp+0x10], xmm1
0000774654fceebf  vmovaps [rsp+0x20], xmm2
0000774654fceec5  vmovaps [rsp+0x30], xmm3
0000774654fceecb  vmovaps [rsp+0x40], xmm4
0000774654fceed1  vmovaps [rsp+0x50], xmm5
0000774654fceed7  vmovaps [rsp+0x60], xmm6
0000774654fceedd  vmovaps [rsp+0x70], xmm7
0000774654fceee3  vmovaps [rsp+0x80], xmm8
0000774654fceeec  vmovaps [rsp+0x90], xmm9
0000774654fceef5  vmovaps [rsp+0xA0], xmm10
0000774654fceefe  vmovaps [rsp+0xB0], xmm11
0000774654fcef07  vmovaps [rsp+0xC0], xmm12
0000774654fcef10  vmovaps [rsp+0xD0], xmm13
0000774654fcef19  vmovaps [rsp+0xE0], xmm15
0000774654fcef22  sub rsp, 0x30
0000774654fcef26  movaps [rsp], xmm14
0000774654fcef2b  movaps [rsp+0x10], xmm1
0000774654fcef30  movaps [rsp+0x20], xmm15
0000774654fcef36  lea rdi, [rsp]
0000774654fcef3a  mov esi, 0x00
0000774654fcef3f  mov rax, 0x564E5D1DD530
0000774654fcef49  call rax
0000774654fcef4b  movaps xmm14, [rsp]
0000774654fcef50  add rsp, 0x30
0000774654fcef54  vmovaps xmm0, [rsp]
0000774654fcef59  vmovaps xmm1, [rsp+0x10]
0000774654fcef5f  vmovaps xmm2, [rsp+0x20]
0000774654fcef65  vmovaps xmm3, [rsp+0x30]
0000774654fcef6b  vmovaps xmm4, [rsp+0x40]
0000774654fcef71  vmovaps xmm5, [rsp+0x50]
0000774654fcef77  vmovaps xmm6, [rsp+0x60]
0000774654fcef7d  vmovaps xmm7, [rsp+0x70]
0000774654fcef83  vmovaps xmm8, [rsp+0x80]
0000774654fcef8c  vmovaps xmm9, [rsp+0x90]
0000774654fcef95  vmovaps xmm10, [rsp+0xA0]
0000774654fcef9e  vmovaps xmm11, [rsp+0xB0]
0000774654fcefa7  vmovaps xmm12, [rsp+0xC0]
0000774654fcefb0  vmovaps xmm13, [rsp+0xD0]
0000774654fcefb9  vmovaps xmm15, [rsp+0xE0]
0000774654fcefc2  add rsp, 0xF0
0000774654fcefc9  pop r11
0000774654fcefcb  pop r10
0000774654fcefcd  pop r9
0000774654fcefcf  pop r8
0000774654fcefd1  pop rsi
0000774654fcefd2  pop rdi
0000774654fcefd3  pop rdx
0000774654fcefd4  pop rcx
0000774654fcefd5  pop rax
0000774654fcefd6  add rsp, 0x08
0000774654fcefda  jmp 0x0000774654FCECAE
0000774654fcefdf  call 0x0000774654EC34C0
0000774654fcefe4  jmp 0x0000774654FCECC4
0000774654fcefe9  int3
0000774654fcefea  nop [rax+rax*1], ax
0000774654fceff0  mov rax, [r15+0xF8]
0000774654fceff7  lea r14, [rax-0x120]
0000774654fceffe  mov [r15+0xF8], r14
0000774654fcf005  mov rax, [r15+0x50]
0000774654fcf009  movups xmm1, [r13+rax*1]
0000774654fcf00f  lea r12, [rax+0x10]
0000774654fcf013  movups xmm15, [r13+r12*1]
0000774654fcf019  mov qword ptr [r15+0x48], 0x00
0000774654fcf021  lea r12, [r14+0xD0]
0000774654fcf028  movq xmm14, qword ptr [r15+0x200]
0000774654fcf031  movq xmm13, qword ptr [r15+0x1F0]
0000774654fcf03a  movq r11, xmm14
0000774654fcf03f  movq r10, xmm13
0000774654fcf044  mov [r13+r12*1], r11
0000774654fcf049  lea r12, [r14+0xD8]
0000774654fcf050  mov [r13+r12*1], r10
0000774654fcf055  lea r12, [rax+0x80]
0000774654fcf05c  movups xmm14, [r13+r12*1]
0000774654fcf062  lea r12, [rax+0x90]
0000774654fcf069  movups xmm13, [r13+r12*1]
0000774654fcf06f  lea r12, [r14+0xE0]
0000774654fcf076  movq xmm12, qword ptr [r15+0x1E0]
0000774654fcf07f  movq xmm11, qword ptr [r15+0x1D0]
0000774654fcf088  movq r11, xmm12
0000774654fcf08d  movq r10, xmm11
0000774654fcf092  mov [r13+r12*1], r11
0000774654fcf097  lea r12, [r14+0xE8]
0000774654fcf09e  mov [r13+r12*1], r10
0000774654fcf0a3  lea r12, [rax+0xC0]
0000774654fcf0aa  movups xmm12, [r13+r12*1]
0000774654fcf0b0  lea r12, [rax+0xD0]
0000774654fcf0b7  movups xmm11, [r13+r12*1]
0000774654fcf0bd  movups [r13+r14*1], xmm1
0000774654fcf0c3  lea r12, [rax+0x20]
0000774654fcf0c7  movups xmm1, [r13+r12*1]
0000774654fcf0cd  lea r12, [rax+0x30]
0000774654fcf0d1  movups xmm10, [r13+r12*1]
0000774654fcf0d7  lea r12, [r14+0xF0]
0000774654fcf0de  movq xmm9, qword ptr [r15+0x1C0]
0000774654fcf0e7  movq xmm8, qword ptr [r15+0x1B0]
0000774654fcf0f0  movq r11, xmm9
0000774654fcf0f5  movq r10, xmm8
0000774654fcf0fa  mov [r13+r12*1], r11
0000774654fcf0ff  lea r12, [r14+0xF8]
0000774654fcf106  mov [r13+r12*1], r10
0000774654fcf10b  lea r12, [rax+0x40]
0000774654fcf10f  movups xmm9, [r13+r12*1]
0000774654fcf115  lea r12, [rax+0x50]
0000774654fcf119  movups xmm8, [r13+r12*1]
0000774654fcf11f  lea r12, [r14+0x100]
0000774654fcf126  movq xmm7, qword ptr [r15+0x1A0]
0000774654fcf12f  movq xmm6, qword ptr [r15+0x190]
0000774654fcf138  movq r11, xmm7
0000774654fcf13d  movq r10, xmm6
0000774654fcf142  mov [r13+r12*1], r11
0000774654fcf147  lea r12, [r14+0x108]
0000774654fcf14e  mov [r13+r12*1], r10
0000774654fcf153  lea r12, [rax+0x100]
0000774654fcf15a  movups xmm7, [r13+r12*1]
0000774654fcf160  lea r12, [rax+0x110]
0000774654fcf167  movups xmm6, [r13+r12*1]
0000774654fcf16d  lea r12, [r14+0xB0]
0000774654fcf174  movups [r13+r12*1], xmm10
0000774654fcf17a  lea r12, [r14+0xC0]
0000774654fcf181  movups [r13+r12*1], xmm1
0000774654fcf187  lea r12, [rax+0x140]
0000774654fcf18e  movups xmm1, [r13+r12*1]
0000774654fcf194  lea r12, [rax+0x150]
0000774654fcf19b  movups xmm10, [r13+r12*1]
0000774654fcf1a1  lea r12, [r14+0x110]
0000774654fcf1a8  mov r11, [r15+0xE8]
0000774654fcf1af  mov [r13+r12*1], r11
0000774654fcf1b4  lea r12, [rax+0x180]
0000774654fcf1bb  movups xmm5, [r13+r12*1]
0000774654fcf1c1  lea r12, [rax+0x190]
0000774654fcf1c8  movups xmm4, [r13+r12*1]
0000774654fcf1ce  lea r12, [rax+0x1C0]
0000774654fcf1d5  movups xmm3, [r13+r12*1]
0000774654fcf1db  lea r12, [rax+0x1D0]
0000774654fcf1e2  movups xmm2, [r13+r12*1]
0000774654fcf1e8  lea r12, [rax+0x60]
0000774654fcf1ec  vmovaps [rsp+0x10], xmm1
0000774654fcf1f2  movups xmm1, [r13+r12*1]
0000774654fcf1f8  lea r12, [rax+0x70]
0000774654fcf1fc  vmovaps [rsp+0x20], xmm1
0000774654fcf202  movups xmm1, [r13+r12*1]
0000774654fcf208  lea r12, [r14+0x70]
0000774654fcf20c  movups [r13+r12*1], xmm4
0000774654fcf212  lea r12, [r14+0x80]
0000774654fcf219  movups [r13+r12*1], xmm5
0000774654fcf21f  lea r12, [rax+0xA0]
0000774654fcf226  movups xmm5, [r13+r12*1]
0000774654fcf22c  lea r12, [rax+0xB0]
0000774654fcf233  movups xmm4, [r13+r12*1]
0000774654fcf239  lea r12, [r14+0x90]
0000774654fcf240  movups [r13+r12*1], xmm2
0000774654fcf246  lea r12, [r14+0xA0]
0000774654fcf24d  movups [r13+r12*1], xmm3
0000774654fcf253  lea r12, [rax+0xE0]
0000774654fcf25a  movups xmm3, [r13+r12*1]
0000774654fcf260  lea r12, [rax+0xF0]
0000774654fcf267  movups xmm2, [r13+r12*1]
0000774654fcf26d  lea r12, [rax+0x120]
0000774654fcf274  vmovaps [rsp+0x30], xmm1
0000774654fcf27a  movups xmm1, [r13+r12*1]
0000774654fcf280  lea r12, [rax+0x130]
0000774654fcf287  vmovaps [rsp+0x40], xmm1
0000774654fcf28d  movups xmm1, [r13+r12*1]
0000774654fcf293  lea r12, [rax+0x160]
0000774654fcf29a  vmovaps [rsp+0x50], xmm1
0000774654fcf2a0  movups xmm1, [r13+r12*1]
0000774654fcf2a6  lea r12, [rax+0x170]
0000774654fcf2ad  vmovaps [rsp+0x60], xmm1
0000774654fcf2b3  movups xmm1, [r13+r12*1]
0000774654fcf2b9  lea r12, [rax+0x1A0]
0000774654fcf2c0  vmovaps [rsp+0x70], xmm1
0000774654fcf2c6  movups xmm1, [r13+r12*1]
0000774654fcf2cc  lea r12, [rax+0x1B0]
0000774654fcf2d3  vmovaps [rsp+0x80], xmm1
0000774654fcf2dc  movups xmm1, [r13+r12*1]
0000774654fcf2e2  lea r12, [rax+0x1E0]
0000774654fcf2e9  vmovaps [rsp+0x90], xmm1
0000774654fcf2f2  movups xmm1, [r13+r12*1]
0000774654fcf2f8  lea r12, [rax+0x1F0]
0000774654fcf2ff  vmovaps [rsp+0xA0], xmm1
0000774654fcf308  movups xmm1, [r13+r12*1]
0000774654fcf30e  mov qword ptr [r15+0x50], 0x4308D0
0000774654fcf316  lea rax, [r14+0x50]
0000774654fcf31a  vmovaps [rsp+0xB0], xmm1
0000774654fcf323  vmovaps xmm1, [rsp+0x60]
0000774654fcf329  movups [r13+rax*1], xmm1
0000774654fcf32f  lea rax, [r14+0x60]
0000774654fcf333  vmovaps xmm1, [rsp+0x10]
0000774654fcf339  movups [r13+rax*1], xmm1
0000774654fcf33f  lea rax, [r14+0x40]
0000774654fcf343  vmovaps xmm1, [rsp+0x70]
0000774654fcf349  movups [r13+rax*1], xmm1
0000774654fcf34f  lea rax, [r14+0x20]
0000774654fcf353  vmovaps xmm1, [rsp+0xA0]
0000774654fcf35c  movups [r13+rax*1], xmm1
0000774654fcf362  lea rax, [r14+0x30]
0000774654fcf366  vmovaps xmm1, [rsp+0x90]
0000774654fcf36f  movups [r13+rax*1], xmm1
0000774654fcf375  lea rax, [r14+0x10]
0000774654fcf379  vmovaps xmm1, [rsp+0xB0]
0000774654fcf382  movups [r13+rax*1], xmm1
0000774654fcf388  mov rax, [r15+0x40]
0000774654fcf38c  vxorps xmm1, xmm1, xmm1
0000774654fcf390  vpbroadcastq xmm1, xmm1
0000774654fcf395  vmovaps [rsp+0x10], xmm1
0000774654fcf39b  vxorps xmm1, xmm1, xmm1
0000774654fcf39f  vpbroadcastq xmm1, xmm1
0000774654fcf3a4  lea r12, [rax+0x30]
0000774654fcf3a8  mov r11, [r13+r12*1]
0000774654fcf3ad  lea r12, [rax+0x38]
0000774654fcf3b1  mov r10, [r13+r12*1]
0000774654fcf3b6  vmovaps [rsp+0x60], xmm1
0000774654fcf3bc  movq xmm1, r11
0000774654fcf3c1  vmovaps [rsp+0x70], xmm1
0000774654fcf3c7  movq xmm1, r10
0000774654fcf3cc  vmovaps [rsp+0x90], xmm1
0000774654fcf3d5  vmovaps xmm1, [rsp+0x70]
0000774654fcf3db  movq xmm1, xmm1
0000774654fcf3df  vmovaps [rsp+0x70], xmm1
0000774654fcf3e5  vmovaps xmm1, [rsp+0x90]
0000774654fcf3ee  movq xmm1, xmm1
0000774654fcf3f2  vmovaps [rsp+0x90], xmm1
0000774654fcf3fb  movq xmm1, xmm1
0000774654fcf3ff  movaps [r15+0x270], xmm1
0000774654fcf407  vmovaps [rsp+0xA0], xmm7
0000774654fcf410  vmovaps xmm1, [rsp+0xA0]
0000774654fcf419  por xmm7, xmm1
0000774654fcf41d  lea r12, [rax+0x20]
0000774654fcf421  mov r11, [r13+r12*1]
0000774654fcf426  lea r12, [rax+0x28]
0000774654fcf42a  mov r10, [r13+r12*1]
0000774654fcf42f  movq xmm1, r11
0000774654fcf434  vmovaps [rsp+0xA0], xmm1
0000774654fcf43d  movq xmm1, r10
0000774654fcf442  vmovaps [rsp+0xB0], xmm1
0000774654fcf44b  vmovaps xmm1, [rsp+0xA0]
0000774654fcf454  movq xmm1, xmm1
0000774654fcf458  vmovaps [rsp+0xA0], xmm1
0000774654fcf461  vmovaps xmm1, [rsp+0xB0]
0000774654fcf46a  movq xmm1, xmm1
0000774654fcf46e  vmovaps [rsp+0xB0], xmm2
0000774654fcf477  vmovaps [rsp+0xC0], xmm1
0000774654fcf480  vmovaps xmm1, [rsp+0xB0]
0000774654fcf489  por xmm2, xmm1
0000774654fcf48d  vmovaps xmm1, [rsp+0x40]
0000774654fcf493  vmovaps [rsp+0xB0], xmm15
0000774654fcf49c  vmovaps xmm15, [rsp+0x40]
0000774654fcf4a2  por xmm1, xmm15
0000774654fcf4a7  vmovaps [rsp+0x40], xmm3
0000774654fcf4ad  vmovaps xmm15, [rsp+0x40]
0000774654fcf4b3  por xmm3, xmm15
0000774654fcf4b8  vmovaps [rsp+0x40], xmm10
0000774654fcf4be  vmovaps xmm15, [rsp+0x40]
0000774654fcf4c4  por xmm10, xmm15
0000774654fcf4c9  vmovaps [rsp+0x40], xmm12
0000774654fcf4cf  vmovaps xmm15, [rsp+0x40]
0000774654fcf4d5  por xmm12, xmm15
0000774654fcf4da  lea r12, [rax+0x10]
0000774654fcf4de  mov r11, [r13+r12*1]
0000774654fcf4e3  lea r12, [rax+0x18]
0000774654fcf4e7  mov r10, [r13+r12*1]
0000774654fcf4ec  movq xmm15, r11
0000774654fcf4f1  vmovaps [rsp+0x40], xmm1
0000774654fcf4f7  movq xmm1, r10
0000774654fcf4fc  movq xmm15, xmm15
0000774654fcf501  movq xmm1, xmm1
0000774654fcf505  vmovaps [rsp+0xD0], xmm1
0000774654fcf50e  vmovaps xmm1, [rsp+0x80]
0000774654fcf517  vmovaps [rsp+0xE0], xmm15
0000774654fcf520  vmovaps xmm15, [rsp+0x80]
0000774654fcf529  por xmm1, xmm15
0000774654fcf52e  vmovaps xmm15, [rsp+0x30]
0000774654fcf534  vmovaps [rsp+0x80], xmm1
0000774654fcf53d  vmovaps xmm1, [rsp+0x30]
0000774654fcf543  por xmm15, xmm1
0000774654fcf548  vmovaps xmm1, [rsp+0x20]
0000774654fcf54e  vmovaps [rsp+0x30], xmm15
0000774654fcf554  vmovaps xmm15, [rsp+0x20]
0000774654fcf55a  por xmm1, xmm15
0000774654fcf55f  vmovaps [rsp+0x20], xmm6
0000774654fcf565  vmovaps xmm15, [rsp+0x20]
0000774654fcf56b  por xmm6, xmm15
0000774654fcf570  vmovaps [rsp+0x20], xmm13
0000774654fcf576  vmovaps xmm15, [rsp+0x20]
0000774654fcf57c  por xmm13, xmm15
0000774654fcf581  vmovaps [rsp+0x20], xmm8
0000774654fcf587  vmovaps xmm15, [rsp+0x20]
0000774654fcf58d  por xmm8, xmm15
0000774654fcf592  vmovaps [rsp+0x20], xmm9
0000774654fcf598  vmovaps xmm15, [rsp+0x20]
0000774654fcf59e  por xmm9, xmm15
0000774654fcf5a3  mov r12, [r13+rax*1]
0000774654fcf5a8  vmovq xmm15, r12
0000774654fcf5ad  vpbroadcastq xmm15, xmm15
0000774654fcf5b2  vmovaps [rsp+0x20], xmm1
0000774654fcf5b8  vxorps xmm1, xmm1, xmm1
0000774654fcf5bc  vpbroadcastq xmm1, xmm1
0000774654fcf5c1  vmovaps [rsp+0xF0], xmm1
0000774654fcf5ca  movups xmm1, [r13+r14*1]
0000774654fcf5d0  vmovaps [rsp+0x100], xmm1
0000774654fcf5d9  vxorps xmm1, xmm1, xmm1
0000774654fcf5dd  vpbroadcastq xmm1, xmm1
0000774654fcf5e2  lea r12, [rax+0x08]
0000774654fcf5e6  mov rax, [r13+r12*1]
0000774654fcf5eb  vmovaps [rsp+0x110], xmm1
0000774654fcf5f4  movq xmm1, rax
0000774654fcf5f9  movaps [r15+0x240], xmm1
0000774654fcf601  mov qword ptr [r15+0x60], 0x4308D0
0000774654fcf609  mov qword ptr [r15+0x58], 0x40
0000774654fcf611  vmovaps xmm1, [rsp+0x10]
0000774654fcf617  vmovaps [rsp+0x10], xmm15
0000774654fcf61d  vmovaps xmm15, [rsp+0x100]
0000774654fcf626  vmovaps [rsp+0x100], xmm14
0000774654fcf62f  vmovaps xmm14, [rsp+0x10]
0000774654fcf635  vmovaps [rsp+0x10], xmm13
0000774654fcf63b  vmovaps [rsp+0x120], xmm12
0000774654fcf644  movaps xmm13, xmm1
0000774654fcf648  vfmadd231pd xmm13, xmm15, xmm14
0000774654fcf64d  vcmppd xmm12, xmm13, xmm13, 0x03
0000774654fcf653  vptest xmm12, xmm12
0000774654fcf658  jnz 0x0000774654FD0283
0000774654fcf65e  vmovaps xmm1, [rsp+0x60]
0000774654fcf664  vmovaps xmm15, [rsp+0xB0]
0000774654fcf66d  vmovaps [rsp+0x60], xmm13
0000774654fcf673  movaps xmm12, xmm1
0000774654fcf677  vfmadd231pd xmm12, xmm15, xmm14
0000774654fcf67c  vcmppd xmm13, xmm12, xmm12, 0x03
0000774654fcf682  vptest xmm13, xmm13
0000774654fcf687  jnz 0x0000774654FD03DC
0000774654fcf68d  vmovaps xmm1, [rsp+0x50]
0000774654fcf693  vmovaps xmm13, [rsp+0x50]
0000774654fcf699  por xmm1, xmm13
0000774654fcf69e  vmovaps [rsp+0x50], xmm4
0000774654fcf6a4  vmovaps xmm13, [rsp+0x50]
0000774654fcf6aa  por xmm4, xmm13
0000774654fcf6af  vmovaps [rsp+0x50], xmm5
0000774654fcf6b5  vmovaps xmm13, [rsp+0x50]
0000774654fcf6bb  por xmm5, xmm13
0000774654fcf6c0  vmovaps [rsp+0x50], xmm11
0000774654fcf6c6  vmovaps xmm13, [rsp+0x50]
0000774654fcf6cc  por xmm11, xmm13
0000774654fcf6d1  vmovaps xmm13, [rsp+0x100]
0000774654fcf6da  vmovaps [rsp+0x50], xmm1
0000774654fcf6e0  vmovaps xmm1, [rsp+0x100]
0000774654fcf6e9  por xmm13, xmm1
0000774654fcf6ee  vmovaps [rsp+0xB0], xmm15
0000774654fcf6f7  vmovaps xmm1, [rsp+0xB0]
0000774654fcf700  por xmm15, xmm1
0000774654fcf705  lea rax, [r14+0xC0]
0000774654fcf70c  movups xmm1, [r13+rax*1]
0000774654fcf712  xor eax, eax
0000774654fcf714  mov r12d, 0x40
0000774654fcf71a  mov r11d, 0x200
0000774654fcf720  cmp r12, r11
0000774654fcf723  cmc
0000774654fcf724  lahf
0000774654fcf725  seto al
0000774654fcf728  mov [r15+0x108], eax
0000774654fcf72f  vmovaps [rsp+0xB0], xmm1
0000774654fcf738  vmovaps xmm1, [rsp+0xF0]
0000774654fcf741  vmovaps [rsp+0xF0], xmm15
0000774654fcf74a  vmovaps xmm15, [rsp+0xB0]
0000774654fcf753  vmovaps [rsp+0xB0], xmm13
0000774654fcf75c  vmovaps [rsp+0x100], xmm12
0000774654fcf765  movaps xmm13, xmm1
0000774654fcf769  vfmadd231pd xmm13, xmm15, xmm14
0000774654fcf76e  vcmppd xmm12, xmm13, xmm13, 0x03
0000774654fcf774  vptest xmm12, xmm12
0000774654fcf779  jnz 0x0000774654FD053F
0000774654fcf77f  lea rax, [r14+0xB0]
0000774654fcf786  movups xmm1, [r13+rax*1]
0000774654fcf78c  vmovaps xmm15, [rsp+0x110]
0000774654fcf795  vmovaps [rsp+0x110], xmm13
0000774654fcf79e  movaps xmm12, xmm15
0000774654fcf7a2  vfmadd231pd xmm12, xmm1, xmm14
0000774654fcf7a7  vcmppd xmm13, xmm12, xmm12, 0x03
0000774654fcf7ad  vptest xmm13, xmm13
0000774654fcf7b2  jnz 0x0000774654FD06A2
0000774654fcf7b8  vmovaps [rsp+0x130], xmm9
0000774654fcf7c1  vmovaps xmm1, [rsp+0x130]
0000774654fcf7ca  por xmm9, xmm1
0000774654fcf7cf  movaps [r15+0x210], xmm9
0000774654fcf7d7  vmovaps [rsp+0x130], xmm8
0000774654fcf7e0  vmovaps xmm1, [rsp+0x130]
0000774654fcf7e9  por xmm8, xmm1
0000774654fcf7ee  movaps [r15+0x1C0], xmm8
0000774654fcf7f6  vmovaps xmm1, [rsp+0x10]
0000774654fcf7fc  vmovaps xmm15, [rsp+0x10]
0000774654fcf802  por xmm1, xmm15
0000774654fcf807  movaps [r15+0x280], xmm1
0000774654fcf80f  vmovaps [rsp+0x10], xmm6
0000774654fcf815  vmovaps xmm14, [rsp+0x10]
0000774654fcf81b  por xmm6, xmm14
0000774654fcf820  movaps [r15+0x2A0], xmm6
0000774654fcf828  vmovaps xmm15, [rsp+0x20]
0000774654fcf82e  vmovaps xmm14, [rsp+0x20]
0000774654fcf834  por xmm15, xmm14
0000774654fcf839  movaps [r15+0x2E0], xmm15
0000774654fcf841  vmovaps xmm14, [rsp+0x30]
0000774654fcf847  vmovaps xmm13, [rsp+0x30]
0000774654fcf84d  por xmm14, xmm13
0000774654fcf852  movaps [r15+0x1F0], xmm14
0000774654fcf85a  vmovaps xmm13, [rsp+0xF0]
0000774654fcf863  vmovaps [rsp+0x10], xmm1
0000774654fcf869  vmovaps xmm1, [rsp+0xF0]
0000774654fcf872  por xmm13, xmm1
0000774654fcf877  movaps [r15+0x250], xmm13
0000774654fcf87f  vmovaps xmm1, [rsp+0xB0]
0000774654fcf888  vmovaps xmm13, [rsp+0xB0]
0000774654fcf891  por xmm1, xmm13
0000774654fcf896  movaps [r15+0x260], xmm1
0000774654fcf89e  vmovaps [rsp+0x20], xmm11
0000774654fcf8a4  vmovaps xmm13, [rsp+0x20]
0000774654fcf8aa  por xmm11, xmm13
0000774654fcf8af  movaps [r15+0x290], xmm11
0000774654fcf8b7  vmovaps [rsp+0x20], xmm5
0000774654fcf8bd  vmovaps xmm13, [rsp+0x20]
0000774654fcf8c3  por xmm5, xmm13
0000774654fcf8c8  movaps [r15+0x2C0], xmm5
0000774654fcf8d0  movq xmm13, qword ptr [r15+0x240]
0000774654fcf8d9  vmovaps [rsp+0x20], xmm13
0000774654fcf8df  vpermilpd xmm13, xmm13, 0x00
0000774654fcf8e5  vmovaps [rsp+0x30], xmm1
0000774654fcf8eb  vmovaps xmm1, [rsp+0x60]
0000774654fcf8f1  vmovaps [rsp+0x60], xmm15
0000774654fcf8f7  vmovaps [rsp+0xB0], xmm14
0000774654fcf900  movaps xmm15, xmm1
0000774654fcf904  vfmadd231pd xmm15, xmm9, xmm13
0000774654fcf909  vcmppd xmm14, xmm15, xmm15, 0x03
0000774654fcf90f  vptest xmm14, xmm14
0000774654fcf914  jnz 0x0000774654FD07FB
0000774654fcf91a  vmovaps xmm1, [rsp+0x20]
0000774654fcf920  vpermilpd xmm1, xmm1, 0x00
0000774654fcf926  vmovaps xmm14, [rsp+0x110]
0000774654fcf92f  vmovaps xmm13, [rsp+0x60]
0000774654fcf935  vmovaps [rsp+0x60], xmm15
0000774654fcf93b  movaps xmm9, xmm14
0000774654fcf93f  vfmadd231pd xmm9, xmm13, xmm1
0000774654fcf944  vcmppd xmm15, xmm9, xmm9, 0x03
0000774654fcf94a  vptest xmm15, xmm15
0000774654fcf94f  jnz 0x0000774654FD0954
0000774654fcf955  vmovaps xmm1, [rsp+0x20]
0000774654fcf95b  vpermilpd xmm1, xmm1, 0x00
0000774654fcf961  vmovaps xmm15, [rsp+0x100]
0000774654fcf96a  movaps xmm14, xmm15
0000774654fcf96e  vfmadd231pd xmm14, xmm8, xmm1
0000774654fcf973  vcmppd xmm13, xmm14, xmm14, 0x03
0000774654fcf979  vptest xmm13, xmm13
0000774654fcf97e  jnz 0x0000774654FD0AAD
0000774654fcf984  vmovaps [rsp+0xF0], xmm4
0000774654fcf98d  vmovaps xmm1, [rsp+0xF0]
0000774654fcf996  por xmm4, xmm1
0000774654fcf99a  movaps [r15+0x1D0], xmm4
0000774654fcf9a2  vmovaps xmm1, [rsp+0x20]
0000774654fcf9a8  vpermilpd xmm1, xmm1, 0x00
0000774654fcf9ae  vmovaps xmm13, [rsp+0xB0]
0000774654fcf9b7  movaps xmm15, xmm12
0000774654fcf9bb  vfmadd231pd xmm15, xmm13, xmm1
0000774654fcf9c0  vcmppd xmm8, xmm15, xmm15, 0x03
0000774654fcf9c6  vptest xmm8, xmm8
0000774654fcf9cb  jnz 0x0000774654FD0C06
0000774654fcf9d1  vmovaps xmm1, [rsp+0x80]
0000774654fcf9da  vmovaps xmm13, [rsp+0x80]
0000774654fcf9e3  por xmm1, xmm13
0000774654fcf9e8  movaps [r15+0x200], xmm1
0000774654fcf9f0  vmovaps xmm13, [rsp+0x50]
0000774654fcf9f6  vmovaps xmm12, [rsp+0x50]
0000774654fcf9fc  por xmm13, xmm12
0000774654fcfa01  movaps [r15+0x1E0], xmm13
0000774654fcfa09  vmovaps [rsp+0x20], xmm10
0000774654fcfa0f  vmovaps xmm13, [rsp+0x20]
0000774654fcfa15  por xmm10, xmm13
0000774654fcfa1a  movaps [r15+0x2B0], xmm10
0000774654fcfa22  vmovaps [rsp+0x20], xmm3
0000774654fcfa28  vmovaps xmm13, [rsp+0x20]
0000774654fcfa2e  por xmm3, xmm13
0000774654fcfa33  movaps [r15+0x300], xmm3
0000774654fcfa3b  vmovaps xmm8, [rsp+0xE0]
0000774654fcfa44  vpermilpd xmm8, xmm8, 0x00
0000774654fcfa4a  vmovaps xmm3, [rsp+0x60]
0000774654fcfa50  vmovaps [rsp+0x20], xmm1
0000774654fcfa56  vmovaps xmm1, [rsp+0x30]
0000774654fcfa5c  vmovaps [rsp+0x30], xmm15
0000774654fcfa62  vmovaps [rsp+0x50], xmm14
0000774654fcfa68  movaps xmm15, xmm3
0000774654fcfa6c  vfmadd231pd xmm15, xmm1, xmm8
0000774654fcfa71  vcmppd xmm14, xmm15, xmm15, 0x03
0000774654fcfa77  vptest xmm14, xmm14
0000774654fcfa7c  jnz 0x0000774654FD0D5F
0000774654fcfa82  vmovaps xmm1, [rsp+0xE0]
0000774654fcfa8b  vpermilpd xmm1, xmm1, 0x00
0000774654fcfa91  movaps xmm8, xmm9
0000774654fcfa95  vfmadd231pd xmm8, xmm5, xmm1
0000774654fcfa9a  vcmppd xmm14, xmm8, xmm8, 0x03
0000774654fcfaa0  vptest xmm14, xmm14
0000774654fcfaa5  jnz 0x0000774654FD0EB7
0000774654fcfaab  vmovaps xmm1, [rsp+0xE0]
0000774654fcfab4  vpermilpd xmm1, xmm1, 0x00
0000774654fcfaba  vmovaps xmm14, [rsp+0x50]
0000774654fcfac0  vmovaps xmm9, [rsp+0x10]
0000774654fcfac6  movaps xmm5, xmm14
0000774654fcfaca  vfmadd231pd xmm5, xmm9, xmm1
0000774654fcfacf  vcmppd xmm3, xmm5, xmm5, 0x03
0000774654fcfad4  vptest xmm3, xmm3
0000774654fcfad9  jnz 0x0000774654FD100F
0000774654fcfadf  vmovaps xmm1, [rsp+0xE0]
0000774654fcfae8  vpermilpd xmm1, xmm1, 0x00
0000774654fcfaee  vmovaps xmm14, [rsp+0x30]
0000774654fcfaf4  movaps xmm9, xmm14
0000774654fcfaf8  vfmadd231pd xmm9, xmm4, xmm1
0000774654fcfafd  vcmppd xmm3, xmm9, xmm9, 0x03
0000774654fcfb03  vptest xmm3, xmm3
0000774654fcfb08  jnz 0x0000774654FD1166
0000774654fcfb0e  vmovaps xmm1, [rsp+0x120]
0000774654fcfb17  vmovaps xmm14, [rsp+0x120]
0000774654fcfb20  por xmm1, xmm14
0000774654fcfb25  movaps [r15+0x180], xmm1
0000774654fcfb2d  vmovaps xmm14, [rsp+0x40]
0000774654fcfb33  vmovaps xmm4, [rsp+0x40]
0000774654fcfb39  por xmm14, xmm4
0000774654fcfb3e  movaps [r15+0x2D0], xmm14
0000774654fcfb46  vmovaps [rsp+0x10], xmm2
0000774654fcfb4c  vmovaps xmm4, [rsp+0x10]
0000774654fcfb52  por xmm2, xmm4
0000774654fcfb56  movaps [r15+0x2F0], xmm2
0000774654fcfb5e  vmovaps xmm3, [rsp+0xD0]
0000774654fcfb67  vpermilpd xmm3, xmm3, 0x00
0000774654fcfb6d  vmovaps [rsp+0x10], xmm1
0000774654fcfb73  movaps xmm2, xmm8
0000774654fcfb77  vfmadd231pd xmm2, xmm13, xmm3
0000774654fcfb7c  vcmppd xmm1, xmm2, xmm2, 0x03
0000774654fcfb81  vptest xmm1, xmm1
0000774654fcfb86  jnz 0x0000774654FD12BE
0000774654fcfb8c  vmovaps xmm1, [rsp+0xD0]
0000774654fcfb95  vpermilpd xmm1, xmm1, 0x00
0000774654fcfb9b  vmovaps xmm13, [rsp+0x10]
0000774654fcfba1  movaps xmm8, xmm15
0000774654fcfba5  vfmadd231pd xmm8, xmm13, xmm1
0000774654fcfbaa  vcmppd xmm3, xmm8, xmm8, 0x03
0000774654fcfbb0  vptest xmm3, xmm3
0000774654fcfbb5  jnz 0x0000774654FD1415
0000774654fcfbbb  lea rax, [r14+0x80]
0000774654fcfbc2  movups xmm1, [r13+rax*1]
0000774654fcfbc8  movaps [r15+0x190], xmm1
0000774654fcfbd0  vmovaps xmm15, [rsp+0xD0]
0000774654fcfbd9  vpermilpd xmm15, xmm15, 0x00
0000774654fcfbdf  movaps xmm13, xmm5
0000774654fcfbe3  vfmadd231pd xmm13, xmm11, xmm15
0000774654fcfbe8  vcmppd xmm3, xmm13, xmm13, 0x03
0000774654fcfbee  vptest xmm3, xmm3
0000774654fcfbf3  jnz 0x0000774654FD1578
0000774654fcfbf9  vmovaps xmm15, [rsp+0xD0]
0000774654fcfc02  vpermilpd xmm15, xmm15, 0x00
0000774654fcfc08  movaps xmm11, xmm9
0000774654fcfc0c  vfmadd231pd xmm11, xmm4, xmm15
0000774654fcfc11  vcmppd xmm5, xmm11, xmm11, 0x03
0000774654fcfc17  vptest xmm5, xmm5
0000774654fcfc1c  jnz 0x0000774654FD16D1
0000774654fcfc22  vmovaps [rsp+0x10], xmm7
0000774654fcfc28  vmovaps xmm9, [rsp+0x10]
0000774654fcfc2e  por xmm7, xmm9
0000774654fcfc33  movaps [r15+0x160], xmm7
0000774654fcfc3b  lea rax, [r14+0x40]
0000774654fcfc3f  movups xmm15, [r13+rax*1]
0000774654fcfc45  lea rax, [r14+0x50]
0000774654fcfc49  movups xmm9, [r13+rax*1]
0000774654fcfc4f  movaps [r15+0x1B0], xmm15
0000774654fcfc57  movaps [r15+0x1A0], xmm9
0000774654fcfc5f  vmovaps xmm5, [rsp+0xA0]
0000774654fcfc68  vpermilpd xmm5, xmm5, 0x00
0000774654fcfc6e  movaps xmm4, xmm2
0000774654fcfc71  vfmadd231pd xmm4, xmm14, xmm5
0000774654fcfc76  vcmppd xmm3, xmm4, xmm4, 0x03
0000774654fcfc7b  vptest xmm3, xmm3
0000774654fcfc80  jnz 0x0000774654FD183E
0000774654fcfc86  vmovaps xmm14, [rsp+0xA0]
0000774654fcfc8f  vpermilpd xmm14, xmm14, 0x00
0000774654fcfc95  movaps xmm5, xmm8
0000774654fcfc99  vfmadd231pd xmm5, xmm7, xmm14
0000774654fcfc9e  vcmppd xmm3, xmm5, xmm5, 0x03
0000774654fcfca3  vptest xmm3, xmm3
0000774654fcfca8  jnz 0x0000774654FD1994
0000774654fcfcae  vmovaps xmm14, [rsp+0xA0]
0000774654fcfcb7  vpermilpd xmm14, xmm14, 0x00
0000774654fcfcbd  movaps xmm8, xmm13
0000774654fcfcc1  vfmadd231pd xmm8, xmm6, xmm14
0000774654fcfcc6  vcmppd xmm7, xmm8, xmm8, 0x03
0000774654fcfccc  vptest xmm7, xmm7
0000774654fcfcd1  jnz 0x0000774654FD1AEB
0000774654fcfcd7  vmovaps xmm14, [rsp+0xA0]
0000774654fcfce0  vpermilpd xmm14, xmm14, 0x00
0000774654fcfce6  movaps xmm13, xmm11
0000774654fcfcea  vfmadd231pd xmm13, xmm12, xmm14
0000774654fcfcef  vcmppd xmm7, xmm13, xmm13, 0x03
0000774654fcfcf5  vptest xmm7, xmm7
0000774654fcfcfa  jnz 0x0000774654FD1C44
0000774654fcfd00  lea rax, [r14+0x60]
0000774654fcfd04  movups xmm14, [r13+rax*1]
0000774654fcfd0a  lea rax, [r14+0x70]
0000774654fcfd0e  movups xmm12, [r13+rax*1]
0000774654fcfd14  movaps [r15+0x150], xmm14
0000774654fcfd1c  movaps [r15+0x120], xmm12
0000774654fcfd24  vmovaps xmm11, [rsp+0xC0]
0000774654fcfd2d  vpermilpd xmm11, xmm11, 0x00
0000774654fcfd33  movaps xmm7, xmm4
0000774654fcfd36  vfmadd231pd xmm7, xmm9, xmm11
0000774654fcfd3b  vcmppd xmm6, xmm7, xmm7, 0x03
0000774654fcfd40  vptest xmm6, xmm6
0000774654fcfd45  jnz 0x0000774654FD1DB2
0000774654fcfd4b  vmovaps xmm11, [rsp+0xC0]
0000774654fcfd54  vpermilpd xmm11, xmm11, 0x00
0000774654fcfd5a  movaps xmm9, xmm5
0000774654fcfd5e  vfmadd231pd xmm9, xmm14, xmm11
0000774654fcfd63  vcmppd xmm6, xmm9, xmm9, 0x03
0000774654fcfd69  vptest xmm6, xmm6
0000774654fcfd6e  jnz 0x0000774654FD1F09
0000774654fcfd74  vmovaps xmm14, [rsp+0xC0]
0000774654fcfd7d  vpermilpd xmm14, xmm14, 0x00
0000774654fcfd83  movaps xmm11, xmm8
0000774654fcfd87  vfmadd231pd xmm11, xmm10, xmm14
0000774654fcfd8c  vcmppd xmm6, xmm11, xmm11, 0x03
0000774654fcfd92  vptest xmm6, xmm6
0000774654fcfd97  jnz 0x0000774654FD2062
0000774654fcfd9d  vmovaps xmm14, [rsp+0xC0]
0000774654fcfda6  vpermilpd xmm14, xmm14, 0x00
0000774654fcfdac  movaps xmm10, xmm13
0000774654fcfdb0  vfmadd231pd xmm10, xmm15, xmm14
0000774654fcfdb5  vcmppd xmm8, xmm10, xmm10, 0x03
0000774654fcfdbb  vptest xmm8, xmm8
0000774654fcfdc0  jnz 0x0000774654FD21BC
0000774654fcfdc6  lea rax, [r14+0x20]
0000774654fcfdca  movups xmm15, [r13+rax*1]
0000774654fcfdd0  lea rax, [r14+0x30]
0000774654fcfdd4  movups xmm14, [r13+rax*1]
0000774654fcfdda  vmovaps xmm13, [rsp+0x70]
0000774654fcfde0  vpermilpd xmm13, xmm13, 0x00
0000774654fcfde6  vmovaps xmm8, [rsp+0x20]
0000774654fcfdec  movaps xmm6, xmm7
0000774654fcfdef  vfmadd231pd xmm6, xmm8, xmm13
0000774654fcfdf4  vcmppd xmm5, xmm6, xmm6, 0x03
0000774654fcfdf9  vptest xmm5, xmm5
0000774654fcfdfe  jnz 0x0000774654FD232A
0000774654fcfe04  vmovaps xmm13, [rsp+0x70]
0000774654fcfe0a  vpermilpd xmm13, xmm13, 0x00
0000774654fcfe10  movaps xmm8, xmm9
0000774654fcfe14  vfmadd231pd xmm8, xmm1, xmm13
0000774654fcfe19  vcmppd xmm7, xmm8, xmm8, 0x03
0000774654fcfe1f  vptest xmm7, xmm7
0000774654fcfe24  jnz 0x0000774654FD2481
0000774654fcfe2a  vmovaps xmm1, [rsp+0x70]
0000774654fcfe30  vpermilpd xmm1, xmm1, 0x00
0000774654fcfe36  movaps xmm13, xmm11
0000774654fcfe3a  vfmadd231pd xmm13, xmm12, xmm1
0000774654fcfe3f  vcmppd xmm9, xmm13, xmm13, 0x03
0000774654fcfe45  vptest xmm9, xmm9
0000774654fcfe4a  jnz 0x0000774654FD25DA
0000774654fcfe50  vmovaps xmm1, [rsp+0x70]
0000774654fcfe56  vpermilpd xmm1, xmm1, 0x00
0000774654fcfe5c  movaps xmm12, xmm10
0000774654fcfe60  vfmadd231pd xmm12, xmm14, xmm1
0000774654fcfe65  vcmppd xmm11, xmm12, xmm12, 0x03
0000774654fcfe6b  vptest xmm11, xmm11
0000774654fcfe70  jnz 0x0000774654FD2733
0000774654fcfe76  lea rax, [r14+0x90]
0000774654fcfe7d  movups xmm1, [r13+rax*1]
0000774654fcfe83  lea rax, [r14+0xA0]
0000774654fcfe8a  movups xmm14, [r13+rax*1]
0000774654fcfe90  movaps [r15+0x140], xmm1
0000774654fcfe98  movaps [r15+0x130], xmm14
0000774654fcfea0  vmovaps xmm11, [rsp+0x90]
0000774654fcfea9  vpermilpd xmm11, xmm11, 0x00
0000774654fcfeaf  movaps xmm10, xmm6
0000774654fcfeb3  vfmadd231pd xmm10, xmm15, xmm11
0000774654fcfeb8  vcmppd xmm9, xmm10, xmm10, 0x03
0000774654fcfebe  vptest xmm9, xmm9
0000774654fcfec3  jnz 0x0000774654FD28A0
0000774654fcfec9  movaps [r15+0x220], xmm10
0000774654fcfed1  lea rax, [r14+0x10]
0000774654fcfed5  movups xmm15, [r13+rax*1]
0000774654fcfedb  movaps [r15+0x240], xmm15
0000774654fcfee3  vmovaps xmm11, [rsp+0x90]
0000774654fcfeec  vpermilpd xmm11, xmm11, 0x00
0000774654fcfef2  movaps xmm9, xmm8
0000774654fcfef6  vfmadd231pd xmm9, xmm14, xmm11
0000774654fcfefb  vcmppd xmm7, xmm9, xmm9, 0x03
0000774654fcff01  vptest xmm7, xmm7
0000774654fcff06  jnz 0x0000774654FD2A03
0000774654fcff0c  movaps [r15+0x110], xmm9
0000774654fcff14  vmovaps xmm14, [rsp+0x90]
0000774654fcff1d  vpermilpd xmm14, xmm14, 0x00
0000774654fcff23  movaps xmm11, xmm13
0000774654fcff27  vfmadd231pd xmm11, xmm1, xmm14
0000774654fcff2c  vcmppd xmm8, xmm11, xmm11, 0x03
0000774654fcff32  vptest xmm8, xmm8
0000774654fcff37  jnz 0x0000774654FD2B5D
0000774654fcff3d  movaps [r15+0x170], xmm11
0000774654fcff45  vmovaps xmm1, [rsp+0x90]
0000774654fcff4e  vpermilpd xmm1, xmm1, 0x00
0000774654fcff54  movaps xmm14, xmm12
0000774654fcff58  vfmadd231pd xmm14, xmm15, xmm1
0000774654fcff5d  vcmppd xmm13, xmm14, xmm14, 0x03
0000774654fcff63  vptest xmm13, xmm13
0000774654fcff68  jnz 0x0000774654FD2CB6
0000774654fcff6e  movaps [r15+0x230], xmm14
0000774654fcff76  mov eax, 0x4308D0
0000774654fcff7b  movups [r13+rax*1], xmm9
0000774654fcff81  mov eax, 0x4308E0
0000774654fcff86  movups [r13+rax*1], xmm11
0000774654fcff8c  mov eax, 0x4308F0
0000774654fcff91  movups [r13+rax*1], xmm10
0000774654fcff97  mov eax, 0x430900
0000774654fcff9c  movups [r13+rax*1], xmm14
0000774654fcffa2  mov eax, [r15+0x108]
0000774654fcffa9  sahf
0000774654fcffaa  jnz 0x0000774654FCFFDC
0000774654fcffac  cmp dword ptr [r15+0x318], 0x00
0000774654fcffb4  jz 0x0000774654FD67A0
0000774654fcffba  nop [rax+rax*1], ax
0000774654fcffc3  nop [rax+rax*1], eax
0000774654fcffcb  mov eax, 0x4103F0
0000774654fcffd0  mov [r15+0x100], rax
0000774654fcffd7  jmp 0x0000774654DFE110
0000774654fcffdc  cmp dword ptr [r15+0x318], 0x00
0000774654fcffe4  jz 0x0000774654FD2E40
0000774654fcffea  nop [rax+rax*1], ax
0000774654fcfff3  nop [rax+rax*1], eax
0000774654fcfffb  mov eax, 0x410274
0000774654fd0000  mov [r15+0x100], rax
0000774654fd0007  jmp 0x0000774654DFE110
0000774654fd000c  int3
0000774654fd000d  call 0x0000774654DFF430
0000774654fd0012  jmp 0x0000774654FCF00F
0000774654fd0017  call 0x0000774654EC4620
0000774654fd001c  jmp 0x0000774654FCF019
0000774654fd0021  call 0x0000774654EC0860
0000774654fd0026  jmp 0x0000774654FCF049
0000774654fd002b  call 0x0000774654EBF5F0
0000774654fd0030  jmp 0x0000774654FCF055
0000774654fd0035  call 0x0000774654EC33A0
0000774654fd003a  jmp 0x0000774654FCF062
0000774654fd003f  call 0x0000774654EC2120
0000774654fd0044  jmp 0x0000774654FCF06F
0000774654fd0049  call 0x0000774654EC0860
0000774654fd004e  jmp 0x0000774654FCF097
0000774654fd0053  call 0x0000774654EBF5F0
0000774654fd0058  jmp 0x0000774654FCF0A3
0000774654fd005d  call 0x0000774654EC0EA0
0000774654fd0062  jmp 0x0000774654FCF0B0
0000774654fd0067  call 0x0000774654EBFC30
0000774654fd006c  jmp 0x0000774654FCF0BD
0000774654fd0071  call 0x0000774654ED6600
0000774654fd0076  jmp 0x0000774654FCF0C3
0000774654fd007b  call 0x0000774654EB52F0
0000774654fd0080  jmp 0x0000774654FCF0CD
0000774654fd0085  call 0x0000774654EBE9C0
0000774654fd008a  jmp 0x0000774654FCF0D7
0000774654fd008f  call 0x0000774654EC0860
0000774654fd0094  jmp 0x0000774654FCF0FF
0000774654fd0099  call 0x0000774654EBF5F0
0000774654fd009e  jmp 0x0000774654FCF10B
0000774654fd00a3  call 0x0000774654EBD750
0000774654fd00a8  jmp 0x0000774654FCF115
0000774654fd00ad  call 0x0000774654EBC4E0
0000774654fd00b2  jmp 0x0000774654FCF11F
0000774654fd00b7  call 0x0000774654EC0860
0000774654fd00bc  jmp 0x0000774654FCF147
0000774654fd00c1  call 0x0000774654EBF5F0
0000774654fd00c6  jmp 0x0000774654FCF153
0000774654fd00cb  call 0x0000774654EBB270
0000774654fd00d0  jmp 0x0000774654FCF160
0000774654fd00d5  call 0x0000774654EBA000
0000774654fd00da  jmp 0x0000774654FCF16D
0000774654fd00df  call 0x0000774654EBEAE0
0000774654fd00e4  jmp 0x0000774654FCF17A
0000774654fd00e9  call 0x0000774654EB5400
0000774654fd00ee  jmp 0x0000774654FCF187
0000774654fd00f3  call 0x0000774654EB52F0
0000774654fd00f8  jmp 0x0000774654FCF194
0000774654fd00fd  call 0x0000774654EBE9C0
0000774654fd0102  jmp 0x0000774654FCF1A1
0000774654fd0107  call 0x0000774654EC0860
0000774654fd010c  jmp 0x0000774654FCF1B4
0000774654fd0111  call 0x0000774654EB8D90
0000774654fd0116  jmp 0x0000774654FCF1C1
0000774654fd011b  call 0x0000774654EB8A20
0000774654fd0120  jmp 0x0000774654FCF1CE
0000774654fd0125  call 0x0000774654EB77B0
0000774654fd012a  jmp 0x0000774654FCF1DB
0000774654fd012f  call 0x0000774654EB6550
0000774654fd0134  jmp 0x0000774654FCF1E8
0000774654fd0139  call 0x0000774654EB52F0
0000774654fd013e  jmp 0x0000774654FCF1F8
0000774654fd0143  call 0x0000774654EB52F0
0000774654fd0148  jmp 0x0000774654FCF208
0000774654fd014d  call 0x0000774654EB8B30
0000774654fd0152  jmp 0x0000774654FCF212
0000774654fd0157  call 0x0000774654EB8EA0
0000774654fd015c  jmp 0x0000774654FCF21F
0000774654fd0161  call 0x0000774654EB8D90
0000774654fd0166  jmp 0x0000774654FCF22C
0000774654fd016b  call 0x0000774654EB8A20
0000774654fd0170  jmp 0x0000774654FCF239
0000774654fd0175  call 0x0000774654EB6660
0000774654fd017a  jmp 0x0000774654FCF246
0000774654fd017f  call 0x0000774654EB78C0
0000774654fd0184  jmp 0x0000774654FCF253
0000774654fd0189  call 0x0000774654EB77B0
0000774654fd018e  jmp 0x0000774654FCF260
0000774654fd0193  call 0x0000774654EB6550
0000774654fd0198  jmp 0x0000774654FCF26D
0000774654fd019d  call 0x0000774654EB52F0
0000774654fd01a2  jmp 0x0000774654FCF280
0000774654fd01a7  call 0x0000774654EB52F0
0000774654fd01ac  jmp 0x0000774654FCF293
0000774654fd01b1  call 0x0000774654EB52F0
0000774654fd01b6  jmp 0x0000774654FCF2A6
0000774654fd01bb  call 0x0000774654EB52F0
0000774654fd01c0  jmp 0x0000774654FCF2B9
0000774654fd01c5  call 0x0000774654EB52F0
0000774654fd01ca  jmp 0x0000774654FCF2CC
0000774654fd01cf  call 0x0000774654EB52F0
0000774654fd01d4  jmp 0x0000774654FCF2E2
0000774654fd01d9  call 0x0000774654EB52F0
0000774654fd01de  jmp 0x0000774654FCF2F8
0000774654fd01e3  call 0x0000774654EB52F0
0000774654fd01e8  jmp 0x0000774654FCF30E
0000774654fd01ed  call 0x0000774654DFF540
0000774654fd01f2  jmp 0x0000774654FCF32F
0000774654fd01f7  call 0x0000774654DFF540
0000774654fd01fc  jmp 0x0000774654FCF33F
0000774654fd0201  call 0x0000774654DFF540
0000774654fd0206  jmp 0x0000774654FCF34F
0000774654fd020b  call 0x0000774654DFF540
0000774654fd0210  jmp 0x0000774654FCF362
0000774654fd0215  call 0x0000774654DFF540
0000774654fd021a  jmp 0x0000774654FCF375
0000774654fd021f  call 0x0000774654DFF540
0000774654fd0224  jmp 0x0000774654FCF388
0000774654fd0229  call 0x0000774654EC0370
0000774654fd022e  jmp 0x0000774654FCF3AD
0000774654fd0233  call 0x0000774654EBF100
0000774654fd0238  jmp 0x0000774654FCF3B6
0000774654fd023d  call 0x0000774654EC0370
0000774654fd0242  jmp 0x0000774654FCF426
0000774654fd0247  call 0x0000774654EBF100
0000774654fd024c  jmp 0x0000774654FCF42F
0000774654fd0251  call 0x0000774654EC0370
0000774654fd0256  jmp 0x0000774654FCF4E3
0000774654fd025b  call 0x0000774654EBF100
0000774654fd0260  jmp 0x0000774654FCF4EC
0000774654fd0265  call 0x0000774654E0B720
0000774654fd026a  jmp 0x0000774654FCF5A8
0000774654fd026f  call 0x0000774654ED64F0
0000774654fd0274  jmp 0x0000774654FCF5D0
0000774654fd0279  call 0x0000774654EB47C0
0000774654fd027e  jmp 0x0000774654FCF5EB
0000774654fd0283  sub rsp, 0x08
0000774654fd0287  push rax
0000774654fd0288  push rcx
0000774654fd0289  push rdx
0000774654fd028a  push rdi
0000774654fd028b  push rsi
0000774654fd028c  push r8
0000774654fd028e  push r9
0000774654fd0290  push r10
0000774654fd0292  push r11
0000774654fd0294  sub rsp, 0xF0
0000774654fd029b  vmovaps [rsp], xmm0
0000774654fd02a0  vmovaps [rsp+0x10], xmm1
0000774654fd02a6  vmovaps [rsp+0x20], xmm2
0000774654fd02ac  vmovaps [rsp+0x30], xmm3
0000774654fd02b2  vmovaps [rsp+0x40], xmm4
0000774654fd02b8  vmovaps [rsp+0x50], xmm5
0000774654fd02be  vmovaps [rsp+0x60], xmm6
0000774654fd02c4  vmovaps [rsp+0x70], xmm7
0000774654fd02ca  vmovaps [rsp+0x80], xmm8
0000774654fd02d3  vmovaps [rsp+0x90], xmm9
0000774654fd02dc  vmovaps [rsp+0xA0], xmm10
0000774654fd02e5  vmovaps [rsp+0xB0], xmm11
0000774654fd02ee  vmovaps [rsp+0xC0], xmm12
0000774654fd02f7  vmovaps [rsp+0xD0], xmm14
0000774654fd0300  vmovaps [rsp+0xE0], xmm15
0000774654fd0309  sub rsp, 0x40
0000774654fd030d  lea rdi, [rsp]
0000774654fd0311  lea rsi, [rsp+0x10]
0000774654fd0316  lea rdx, [rsp+0x20]
0000774654fd031b  lea rcx, [rsp+0x30]
0000774654fd0320  mov r8d, 0x00
0000774654fd0326  lea r9, [r15+0x3A8]
0000774654fd032d  movaps [rdi], xmm13
0000774654fd0331  movaps [rsi], xmm1
0000774654fd0334  movaps [rdx], xmm15
0000774654fd0338  movaps [rcx], xmm14
0000774654fd033c  mov rax, 0x564E5D1DDA50
0000774654fd0346  call rax
0000774654fd0348  movaps xmm13, [rsp]
0000774654fd034d  add rsp, 0x40
0000774654fd0351  vmovaps xmm0, [rsp]
0000774654fd0356  vmovaps xmm1, [rsp+0x10]
0000774654fd035c  vmovaps xmm2, [rsp+0x20]
0000774654fd0362  vmovaps xmm3, [rsp+0x30]
0000774654fd0368  vmovaps xmm4, [rsp+0x40]
0000774654fd036e  vmovaps xmm5, [rsp+0x50]
0000774654fd0374  vmovaps xmm6, [rsp+0x60]
0000774654fd037a  vmovaps xmm7, [rsp+0x70]
0000774654fd0380  vmovaps xmm8, [rsp+0x80]
0000774654fd0389  vmovaps xmm9, [rsp+0x90]
0000774654fd0392  vmovaps xmm10, [rsp+0xA0]
0000774654fd039b  vmovaps xmm11, [rsp+0xB0]
0000774654fd03a4  vmovaps xmm12, [rsp+0xC0]
0000774654fd03ad  vmovaps xmm14, [rsp+0xD0]
0000774654fd03b6  vmovaps xmm15, [rsp+0xE0]
0000774654fd03bf  add rsp, 0xF0
0000774654fd03c6  pop r11
0000774654fd03c8  pop r10
0000774654fd03ca  pop r9
0000774654fd03cc  pop r8
0000774654fd03ce  pop rsi
0000774654fd03cf  pop rdi
0000774654fd03d0  pop rdx
0000774654fd03d1  pop rcx
0000774654fd03d2  pop rax
0000774654fd03d3  add rsp, 0x08
0000774654fd03d7  jmp 0x0000774654FCF65E
0000774654fd03dc  sub rsp, 0x08
0000774654fd03e0  push rax
0000774654fd03e1  push rcx
0000774654fd03e2  push rdx
0000774654fd03e3  push rdi
0000774654fd03e4  push rsi
0000774654fd03e5  push r8
0000774654fd03e7  push r9
0000774654fd03e9  push r10
0000774654fd03eb  push r11
0000774654fd03ed  sub rsp, 0xF0
0000774654fd03f4  vmovaps [rsp], xmm0
0000774654fd03f9  vmovaps [rsp+0x10], xmm1
0000774654fd03ff  vmovaps [rsp+0x20], xmm2
0000774654fd0405  vmovaps [rsp+0x30], xmm3
0000774654fd040b  vmovaps [rsp+0x40], xmm4
0000774654fd0411  vmovaps [rsp+0x50], xmm5
0000774654fd0417  vmovaps [rsp+0x60], xmm6
0000774654fd041d  vmovaps [rsp+0x70], xmm7
0000774654fd0423  vmovaps [rsp+0x80], xmm8
0000774654fd042c  vmovaps [rsp+0x90], xmm9
0000774654fd0435  vmovaps [rsp+0xA0], xmm10
0000774654fd043e  vmovaps [rsp+0xB0], xmm11
0000774654fd0447  vmovaps [rsp+0xC0], xmm13
0000774654fd0450  vmovaps [rsp+0xD0], xmm14
0000774654fd0459  vmovaps [rsp+0xE0], xmm15
0000774654fd0462  sub rsp, 0x40
0000774654fd0466  lea rdi, [rsp]
0000774654fd046a  lea rsi, [rsp+0x10]
0000774654fd046f  lea rdx, [rsp+0x20]
0000774654fd0474  lea rcx, [rsp+0x30]
0000774654fd0479  mov r8d, 0x00
0000774654fd047f  lea r9, [r15+0x3A8]
0000774654fd0486  movaps [rdi], xmm12
0000774654fd048a  movaps [rsi], xmm1
0000774654fd048d  movaps [rdx], xmm15
0000774654fd0491  movaps [rcx], xmm14
0000774654fd0495  mov rax, 0x564E5D1DDA50
0000774654fd049f  call rax
0000774654fd04a1  movaps xmm12, [rsp]
0000774654fd04a6  add rsp, 0x40
0000774654fd04aa  vmovaps xmm0, [rsp]
0000774654fd04af  vmovaps xmm1, [rsp+0x10]
0000774654fd04b5  vmovaps xmm2, [rsp+0x20]
0000774654fd04bb  vmovaps xmm3, [rsp+0x30]
0000774654fd04c1  vmovaps xmm4, [rsp+0x40]
0000774654fd04c7  vmovaps xmm5, [rsp+0x50]
0000774654fd04cd  vmovaps xmm6, [rsp+0x60]
0000774654fd04d3  vmovaps xmm7, [rsp+0x70]
0000774654fd04d9  vmovaps xmm8, [rsp+0x80]
0000774654fd04e2  vmovaps xmm9, [rsp+0x90]
0000774654fd04eb  vmovaps xmm10, [rsp+0xA0]
0000774654fd04f4  vmovaps xmm11, [rsp+0xB0]
0000774654fd04fd  vmovaps xmm13, [rsp+0xC0]
0000774654fd0506  vmovaps xmm14, [rsp+0xD0]
0000774654fd050f  vmovaps xmm15, [rsp+0xE0]
0000774654fd0518  add rsp, 0xF0
0000774654fd051f  pop r11
0000774654fd0521  pop r10
0000774654fd0523  pop r9
0000774654fd0525  pop r8
0000774654fd0527  pop rsi
0000774654fd0528  pop rdi
0000774654fd0529  pop rdx
0000774654fd052a  pop rcx
0000774654fd052b  pop rax
0000774654fd052c  add rsp, 0x08
0000774654fd0530  jmp 0x0000774654FCF68D
0000774654fd0535  call 0x0000774654DFF430
0000774654fd053a  jmp 0x0000774654FCF712
0000774654fd053f  sub rsp, 0x08
0000774654fd0543  push rax
0000774654fd0544  push rcx
0000774654fd0545  push rdx
0000774654fd0546  push rdi
0000774654fd0547  push rsi
0000774654fd0548  push r8
0000774654fd054a  push r9
0000774654fd054c  push r10
0000774654fd054e  push r11
0000774654fd0550  sub rsp, 0xF0
0000774654fd0557  vmovaps [rsp], xmm0
0000774654fd055c  vmovaps [rsp+0x10], xmm1
0000774654fd0562  vmovaps [rsp+0x20], xmm2
0000774654fd0568  vmovaps [rsp+0x30], xmm3
0000774654fd056e  vmovaps [rsp+0x40], xmm4
0000774654fd0574  vmovaps [rsp+0x50], xmm5
0000774654fd057a  vmovaps [rsp+0x60], xmm6
0000774654fd0580  vmovaps [rsp+0x70], xmm7
0000774654fd0586  vmovaps [rsp+0x80], xmm8
0000774654fd058f  vmovaps [rsp+0x90], xmm9
0000774654fd0598  vmovaps [rsp+0xA0], xmm10
0000774654fd05a1  vmovaps [rsp+0xB0], xmm11
0000774654fd05aa  vmovaps [rsp+0xC0], xmm12
0000774654fd05b3  vmovaps [rsp+0xD0], xmm14
0000774654fd05bc  vmovaps [rsp+0xE0], xmm15
0000774654fd05c5  sub rsp, 0x40
0000774654fd05c9  lea rdi, [rsp]
0000774654fd05cd  lea rsi, [rsp+0x10]
0000774654fd05d2  lea rdx, [rsp+0x20]
0000774654fd05d7  lea rcx, [rsp+0x30]
0000774654fd05dc  mov r8d, 0x00
0000774654fd05e2  lea r9, [r15+0x3A8]
0000774654fd05e9  movaps [rdi], xmm13
0000774654fd05ed  movaps [rsi], xmm1
0000774654fd05f0  movaps [rdx], xmm15
0000774654fd05f4  movaps [rcx], xmm14
0000774654fd05f8  mov rax, 0x564E5D1DDA50
0000774654fd0602  call rax
0000774654fd0604  movaps xmm13, [rsp]
0000774654fd0609  add rsp, 0x40
0000774654fd060d  vmovaps xmm0, [rsp]
0000774654fd0612  vmovaps xmm1, [rsp+0x10]
0000774654fd0618  vmovaps xmm2, [rsp+0x20]
0000774654fd061e  vmovaps xmm3, [rsp+0x30]
0000774654fd0624  vmovaps xmm4, [rsp+0x40]
0000774654fd062a  vmovaps xmm5, [rsp+0x50]
0000774654fd0630  vmovaps xmm6, [rsp+0x60]
0000774654fd0636  vmovaps xmm7, [rsp+0x70]
0000774654fd063c  vmovaps xmm8, [rsp+0x80]
0000774654fd0645  vmovaps xmm9, [rsp+0x90]
0000774654fd064e  vmovaps xmm10, [rsp+0xA0]
0000774654fd0657  vmovaps xmm11, [rsp+0xB0]
0000774654fd0660  vmovaps xmm12, [rsp+0xC0]
0000774654fd0669  vmovaps xmm14, [rsp+0xD0]
0000774654fd0672  vmovaps xmm15, [rsp+0xE0]
0000774654fd067b  add rsp, 0xF0
0000774654fd0682  pop r11
0000774654fd0684  pop r10
0000774654fd0686  pop r9
0000774654fd0688  pop r8
0000774654fd068a  pop rsi
0000774654fd068b  pop rdi
0000774654fd068c  pop rdx
0000774654fd068d  pop rcx
0000774654fd068e  pop rax
0000774654fd068f  add rsp, 0x08
0000774654fd0693  jmp 0x0000774654FCF77F
0000774654fd0698  call 0x0000774654DFF430
0000774654fd069d  jmp 0x0000774654FCF78C
0000774654fd06a2  sub rsp, 0x08
0000774654fd06a6  push rax
0000774654fd06a7  push rcx
0000774654fd06a8  push rdx
0000774654fd06a9  push rdi
0000774654fd06aa  push rsi
0000774654fd06ab  push r8
0000774654fd06ad  push r9
0000774654fd06af  push r10
0000774654fd06b1  push r11
0000774654fd06b3  sub rsp, 0xF0
0000774654fd06ba  vmovaps [rsp], xmm0
0000774654fd06bf  vmovaps [rsp+0x10], xmm1
0000774654fd06c5  vmovaps [rsp+0x20], xmm2
0000774654fd06cb  vmovaps [rsp+0x30], xmm3
0000774654fd06d1  vmovaps [rsp+0x40], xmm4
0000774654fd06d7  vmovaps [rsp+0x50], xmm5
0000774654fd06dd  vmovaps [rsp+0x60], xmm6
0000774654fd06e3  vmovaps [rsp+0x70], xmm7
0000774654fd06e9  vmovaps [rsp+0x80], xmm8
0000774654fd06f2  vmovaps [rsp+0x90], xmm9
0000774654fd06fb  vmovaps [rsp+0xA0], xmm10
0000774654fd0704  vmovaps [rsp+0xB0], xmm11
0000774654fd070d  vmovaps [rsp+0xC0], xmm13
0000774654fd0716  vmovaps [rsp+0xD0], xmm14
0000774654fd071f  vmovaps [rsp+0xE0], xmm15
0000774654fd0728  sub rsp, 0x40
0000774654fd072c  lea rdi, [rsp]
0000774654fd0730  lea rsi, [rsp+0x10]
0000774654fd0735  lea rdx, [rsp+0x20]
0000774654fd073a  lea rcx, [rsp+0x30]
0000774654fd073f  mov r8d, 0x00
0000774654fd0745  lea r9, [r15+0x3A8]
0000774654fd074c  movaps [rdi], xmm12
0000774654fd0750  movaps [rsi], xmm15
0000774654fd0754  movaps [rdx], xmm1
0000774654fd0757  movaps [rcx], xmm14
0000774654fd075b  mov rax, 0x564E5D1DDA50
0000774654fd0765  call rax
0000774654fd0767  movaps xmm12, [rsp]
0000774654fd076c  add rsp, 0x40
0000774654fd0770  vmovaps xmm0, [rsp]
0000774654fd0775  vmovaps xmm1, [rsp+0x10]
0000774654fd077b  vmovaps xmm2, [rsp+0x20]
0000774654fd0781  vmovaps xmm3, [rsp+0x30]
0000774654fd0787  vmovaps xmm4, [rsp+0x40]
0000774654fd078d  vmovaps xmm5, [rsp+0x50]
0000774654fd0793  vmovaps xmm6, [rsp+0x60]
0000774654fd0799  vmovaps xmm7, [rsp+0x70]
0000774654fd079f  vmovaps xmm8, [rsp+0x80]
0000774654fd07a8  vmovaps xmm9, [rsp+0x90]
0000774654fd07b1  vmovaps xmm10, [rsp+0xA0]
0000774654fd07ba  vmovaps xmm11, [rsp+0xB0]
0000774654fd07c3  vmovaps xmm13, [rsp+0xC0]
0000774654fd07cc  vmovaps xmm14, [rsp+0xD0]
0000774654fd07d5  vmovaps xmm15, [rsp+0xE0]
0000774654fd07de  add rsp, 0xF0
0000774654fd07e5  pop r11
0000774654fd07e7  pop r10
0000774654fd07e9  pop r9
0000774654fd07eb  pop r8
0000774654fd07ed  pop rsi
0000774654fd07ee  pop rdi
0000774654fd07ef  pop rdx
0000774654fd07f0  pop rcx
0000774654fd07f1  pop rax
0000774654fd07f2  add rsp, 0x08
0000774654fd07f6  jmp 0x0000774654FCF7B8
0000774654fd07fb  sub rsp, 0x08
0000774654fd07ff  push rax
0000774654fd0800  push rcx
0000774654fd0801  push rdx
0000774654fd0802  push rdi
0000774654fd0803  push rsi
0000774654fd0804  push r8
0000774654fd0806  push r9
0000774654fd0808  push r10
0000774654fd080a  push r11
0000774654fd080c  sub rsp, 0xF0
0000774654fd0813  vmovaps [rsp], xmm0
0000774654fd0818  vmovaps [rsp+0x10], xmm1
0000774654fd081e  vmovaps [rsp+0x20], xmm2
0000774654fd0824  vmovaps [rsp+0x30], xmm3
0000774654fd082a  vmovaps [rsp+0x40], xmm4
0000774654fd0830  vmovaps [rsp+0x50], xmm5
0000774654fd0836  vmovaps [rsp+0x60], xmm6
0000774654fd083c  vmovaps [rsp+0x70], xmm7
0000774654fd0842  vmovaps [rsp+0x80], xmm8
0000774654fd084b  vmovaps [rsp+0x90], xmm9
0000774654fd0854  vmovaps [rsp+0xA0], xmm10
0000774654fd085d  vmovaps [rsp+0xB0], xmm11
0000774654fd0866  vmovaps [rsp+0xC0], xmm12
0000774654fd086f  vmovaps [rsp+0xD0], xmm13
0000774654fd0878  vmovaps [rsp+0xE0], xmm14
0000774654fd0881  sub rsp, 0x40
0000774654fd0885  lea rdi, [rsp]
0000774654fd0889  lea rsi, [rsp+0x10]
0000774654fd088e  lea rdx, [rsp+0x20]
0000774654fd0893  lea rcx, [rsp+0x30]
0000774654fd0898  mov r8d, 0x00
0000774654fd089e  lea r9, [r15+0x3A8]
0000774654fd08a5  movaps [rdi], xmm15
0000774654fd08a9  movaps [rsi], xmm1
0000774654fd08ac  movaps [rdx], xmm9
0000774654fd08b0  movaps [rcx], xmm13
0000774654fd08b4  mov rax, 0x564E5D1DDA50
0000774654fd08be  call rax
0000774654fd08c0  movaps xmm15, [rsp]
0000774654fd08c5  add rsp, 0x40
0000774654fd08c9  vmovaps xmm0, [rsp]
0000774654fd08ce  vmovaps xmm1, [rsp+0x10]
0000774654fd08d4  vmovaps xmm2, [rsp+0x20]
0000774654fd08da  vmovaps xmm3, [rsp+0x30]
0000774654fd08e0  vmovaps xmm4, [rsp+0x40]
0000774654fd08e6  vmovaps xmm5, [rsp+0x50]
0000774654fd08ec  vmovaps xmm6, [rsp+0x60]
0000774654fd08f2  vmovaps xmm7, [rsp+0x70]
0000774654fd08f8  vmovaps xmm8, [rsp+0x80]
0000774654fd0901  vmovaps xmm9, [rsp+0x90]
0000774654fd090a  vmovaps xmm10, [rsp+0xA0]
0000774654fd0913  vmovaps xmm11, [rsp+0xB0]
0000774654fd091c  vmovaps xmm12, [rsp+0xC0]
0000774654fd0925  vmovaps xmm13, [rsp+0xD0]
0000774654fd092e  vmovaps xmm14, [rsp+0xE0]
0000774654fd0937  add rsp, 0xF0
0000774654fd093e  pop r11
0000774654fd0940  pop r10
0000774654fd0942  pop r9
0000774654fd0944  pop r8
0000774654fd0946  pop rsi
0000774654fd0947  pop rdi
0000774654fd0948  pop rdx
0000774654fd0949  pop rcx
0000774654fd094a  pop rax
0000774654fd094b  add rsp, 0x08
0000774654fd094f  jmp 0x0000774654FCF91A
0000774654fd0954  sub rsp, 0x08
0000774654fd0958  push rax
0000774654fd0959  push rcx
0000774654fd095a  push rdx
0000774654fd095b  push rdi
0000774654fd095c  push rsi
0000774654fd095d  push r8
0000774654fd095f  push r9
0000774654fd0961  push r10
0000774654fd0963  push r11
0000774654fd0965  sub rsp, 0xF0
0000774654fd096c  vmovaps [rsp], xmm0
0000774654fd0971  vmovaps [rsp+0x10], xmm1
0000774654fd0977  vmovaps [rsp+0x20], xmm2
0000774654fd097d  vmovaps [rsp+0x30], xmm3
0000774654fd0983  vmovaps [rsp+0x40], xmm4
0000774654fd0989  vmovaps [rsp+0x50], xmm5
0000774654fd098f  vmovaps [rsp+0x60], xmm6
0000774654fd0995  vmovaps [rsp+0x70], xmm7
0000774654fd099b  vmovaps [rsp+0x80], xmm8
0000774654fd09a4  vmovaps [rsp+0x90], xmm10
0000774654fd09ad  vmovaps [rsp+0xA0], xmm11
0000774654fd09b6  vmovaps [rsp+0xB0], xmm12
0000774654fd09bf  vmovaps [rsp+0xC0], xmm13
0000774654fd09c8  vmovaps [rsp+0xD0], xmm14
0000774654fd09d1  vmovaps [rsp+0xE0], xmm15
0000774654fd09da  sub rsp, 0x40
0000774654fd09de  lea rdi, [rsp]
0000774654fd09e2  lea rsi, [rsp+0x10]
0000774654fd09e7  lea rdx, [rsp+0x20]
0000774654fd09ec  lea rcx, [rsp+0x30]
0000774654fd09f1  mov r8d, 0x00
0000774654fd09f7  lea r9, [r15+0x3A8]
0000774654fd09fe  movaps [rdi], xmm9
0000774654fd0a02  movaps [rsi], xmm14
0000774654fd0a06  movaps [rdx], xmm13
0000774654fd0a0a  movaps [rcx], xmm1
0000774654fd0a0d  mov rax, 0x564E5D1DDA50
0000774654fd0a17  call rax
0000774654fd0a19  movaps xmm9, [rsp]
0000774654fd0a1e  add rsp, 0x40
0000774654fd0a22  vmovaps xmm0, [rsp]
0000774654fd0a27  vmovaps xmm1, [rsp+0x10]
0000774654fd0a2d  vmovaps xmm2, [rsp+0x20]
0000774654fd0a33  vmovaps xmm3, [rsp+0x30]
0000774654fd0a39  vmovaps xmm4, [rsp+0x40]
0000774654fd0a3f  vmovaps xmm5, [rsp+0x50]
0000774654fd0a45  vmovaps xmm6, [rsp+0x60]
0000774654fd0a4b  vmovaps xmm7, [rsp+0x70]
0000774654fd0a51  vmovaps xmm8, [rsp+0x80]
0000774654fd0a5a  vmovaps xmm10, [rsp+0x90]
0000774654fd0a63  vmovaps xmm11, [rsp+0xA0]
0000774654fd0a6c  vmovaps xmm12, [rsp+0xB0]
0000774654fd0a75  vmovaps xmm13, [rsp+0xC0]
0000774654fd0a7e  vmovaps xmm14, [rsp+0xD0]
0000774654fd0a87  vmovaps xmm15, [rsp+0xE0]
0000774654fd0a90  add rsp, 0xF0
0000774654fd0a97  pop r11
0000774654fd0a99  pop r10
0000774654fd0a9b  pop r9
0000774654fd0a9d  pop r8
0000774654fd0a9f  pop rsi
0000774654fd0aa0  pop rdi
0000774654fd0aa1  pop rdx
0000774654fd0aa2  pop rcx
0000774654fd0aa3  pop rax
0000774654fd0aa4  add rsp, 0x08
0000774654fd0aa8  jmp 0x0000774654FCF955
0000774654fd0aad  sub rsp, 0x08
0000774654fd0ab1  push rax
0000774654fd0ab2  push rcx
0000774654fd0ab3  push rdx
0000774654fd0ab4  push rdi
0000774654fd0ab5  push rsi
0000774654fd0ab6  push r8
0000774654fd0ab8  push r9
0000774654fd0aba  push r10
0000774654fd0abc  push r11
0000774654fd0abe  sub rsp, 0xF0
0000774654fd0ac5  vmovaps [rsp], xmm0
0000774654fd0aca  vmovaps [rsp+0x10], xmm1
0000774654fd0ad0  vmovaps [rsp+0x20], xmm2
0000774654fd0ad6  vmovaps [rsp+0x30], xmm3
0000774654fd0adc  vmovaps [rsp+0x40], xmm4
0000774654fd0ae2  vmovaps [rsp+0x50], xmm5
0000774654fd0ae8  vmovaps [rsp+0x60], xmm6
0000774654fd0aee  vmovaps [rsp+0x70], xmm7
0000774654fd0af4  vmovaps [rsp+0x80], xmm8
0000774654fd0afd  vmovaps [rsp+0x90], xmm9
0000774654fd0b06  vmovaps [rsp+0xA0], xmm10
0000774654fd0b0f  vmovaps [rsp+0xB0], xmm11
0000774654fd0b18  vmovaps [rsp+0xC0], xmm12
0000774654fd0b21  vmovaps [rsp+0xD0], xmm13
0000774654fd0b2a  vmovaps [rsp+0xE0], xmm15
0000774654fd0b33  sub rsp, 0x40
0000774654fd0b37  lea rdi, [rsp]
0000774654fd0b3b  lea rsi, [rsp+0x10]
0000774654fd0b40  lea rdx, [rsp+0x20]
0000774654fd0b45  lea rcx, [rsp+0x30]
0000774654fd0b4a  mov r8d, 0x00
0000774654fd0b50  lea r9, [r15+0x3A8]
0000774654fd0b57  movaps [rdi], xmm14
0000774654fd0b5b  movaps [rsi], xmm15
0000774654fd0b5f  movaps [rdx], xmm8
0000774654fd0b63  movaps [rcx], xmm1
0000774654fd0b66  mov rax, 0x564E5D1DDA50
0000774654fd0b70  call rax
0000774654fd0b72  movaps xmm14, [rsp]
0000774654fd0b77  add rsp, 0x40
0000774654fd0b7b  vmovaps xmm0, [rsp]
0000774654fd0b80  vmovaps xmm1, [rsp+0x10]
0000774654fd0b86  vmovaps xmm2, [rsp+0x20]
0000774654fd0b8c  vmovaps xmm3, [rsp+0x30]
0000774654fd0b92  vmovaps xmm4, [rsp+0x40]
0000774654fd0b98  vmovaps xmm5, [rsp+0x50]
0000774654fd0b9e  vmovaps xmm6, [rsp+0x60]
0000774654fd0ba4  vmovaps xmm7, [rsp+0x70]
0000774654fd0baa  vmovaps xmm8, [rsp+0x80]
0000774654fd0bb3  vmovaps xmm9, [rsp+0x90]
0000774654fd0bbc  vmovaps xmm10, [rsp+0xA0]
0000774654fd0bc5  vmovaps xmm11, [rsp+0xB0]
0000774654fd0bce  vmovaps xmm12, [rsp+0xC0]
0000774654fd0bd7  vmovaps xmm13, [rsp+0xD0]
0000774654fd0be0  vmovaps xmm15, [rsp+0xE0]
0000774654fd0be9  add rsp, 0xF0
0000774654fd0bf0  pop r11
0000774654fd0bf2  pop r10
0000774654fd0bf4  pop r9
0000774654fd0bf6  pop r8
0000774654fd0bf8  pop rsi
0000774654fd0bf9  pop rdi
0000774654fd0bfa  pop rdx
0000774654fd0bfb  pop rcx
0000774654fd0bfc  pop rax
0000774654fd0bfd  add rsp, 0x08
0000774654fd0c01  jmp 0x0000774654FCF984
0000774654fd0c06  sub rsp, 0x08
0000774654fd0c0a  push rax
0000774654fd0c0b  push rcx
0000774654fd0c0c  push rdx
0000774654fd0c0d  push rdi
0000774654fd0c0e  push rsi
0000774654fd0c0f  push r8
0000774654fd0c11  push r9
0000774654fd0c13  push r10
0000774654fd0c15  push r11
0000774654fd0c17  sub rsp, 0xF0
0000774654fd0c1e  vmovaps [rsp], xmm0
0000774654fd0c23  vmovaps [rsp+0x10], xmm1
0000774654fd0c29  vmovaps [rsp+0x20], xmm2
0000774654fd0c2f  vmovaps [rsp+0x30], xmm3
0000774654fd0c35  vmovaps [rsp+0x40], xmm4
0000774654fd0c3b  vmovaps [rsp+0x50], xmm5
0000774654fd0c41  vmovaps [rsp+0x60], xmm6
0000774654fd0c47  vmovaps [rsp+0x70], xmm7
0000774654fd0c4d  vmovaps [rsp+0x80], xmm8
0000774654fd0c56  vmovaps [rsp+0x90], xmm9
0000774654fd0c5f  vmovaps [rsp+0xA0], xmm10
0000774654fd0c68  vmovaps [rsp+0xB0], xmm11
0000774654fd0c71  vmovaps [rsp+0xC0], xmm12
0000774654fd0c7a  vmovaps [rsp+0xD0], xmm13
0000774654fd0c83  vmovaps [rsp+0xE0], xmm14
0000774654fd0c8c  sub rsp, 0x40
0000774654fd0c90  lea rdi, [rsp]
0000774654fd0c94  lea rsi, [rsp+0x10]
0000774654fd0c99  lea rdx, [rsp+0x20]
0000774654fd0c9e  lea rcx, [rsp+0x30]
0000774654fd0ca3  mov r8d, 0x00
0000774654fd0ca9  lea r9, [r15+0x3A8]
0000774654fd0cb0  movaps [rdi], xmm15
0000774654fd0cb4  movaps [rsi], xmm12
0000774654fd0cb8  movaps [rdx], xmm13
0000774654fd0cbc  movaps [rcx], xmm1
0000774654fd0cbf  mov rax, 0x564E5D1DDA50
0000774654fd0cc9  call rax
0000774654fd0ccb  movaps xmm15, [rsp]
0000774654fd0cd0  add rsp, 0x40
0000774654fd0cd4  vmovaps xmm0, [rsp]
0000774654fd0cd9  vmovaps xmm1, [rsp+0x10]
0000774654fd0cdf  vmovaps xmm2, [rsp+0x20]
0000774654fd0ce5  vmovaps xmm3, [rsp+0x30]
0000774654fd0ceb  vmovaps xmm4, [rsp+0x40]
0000774654fd0cf1  vmovaps xmm5, [rsp+0x50]
0000774654fd0cf7  vmovaps xmm6, [rsp+0x60]
0000774654fd0cfd  vmovaps xmm7, [rsp+0x70]
0000774654fd0d03  vmovaps xmm8, [rsp+0x80]
0000774654fd0d0c  vmovaps xmm9, [rsp+0x90]
0000774654fd0d15  vmovaps xmm10, [rsp+0xA0]
0000774654fd0d1e  vmovaps xmm11, [rsp+0xB0]
0000774654fd0d27  vmovaps xmm12, [rsp+0xC0]
0000774654fd0d30  vmovaps xmm13, [rsp+0xD0]
0000774654fd0d39  vmovaps xmm14, [rsp+0xE0]
0000774654fd0d42  add rsp, 0xF0
0000774654fd0d49  pop r11
0000774654fd0d4b  pop r10
0000774654fd0d4d  pop r9
0000774654fd0d4f  pop r8
0000774654fd0d51  pop rsi
0000774654fd0d52  pop rdi
0000774654fd0d53  pop rdx
0000774654fd0d54  pop rcx
0000774654fd0d55  pop rax
0000774654fd0d56  add rsp, 0x08
0000774654fd0d5a  jmp 0x0000774654FCF9D1
0000774654fd0d5f  sub rsp, 0x08
0000774654fd0d63  push rax
0000774654fd0d64  push rcx
0000774654fd0d65  push rdx
0000774654fd0d66  push rdi
0000774654fd0d67  push rsi
0000774654fd0d68  push r8
0000774654fd0d6a  push r9
0000774654fd0d6c  push r10
0000774654fd0d6e  push r11
0000774654fd0d70  sub rsp, 0xF0
0000774654fd0d77  vmovaps [rsp], xmm0
0000774654fd0d7c  vmovaps [rsp+0x10], xmm1
0000774654fd0d82  vmovaps [rsp+0x20], xmm2
0000774654fd0d88  vmovaps [rsp+0x30], xmm3
0000774654fd0d8e  vmovaps [rsp+0x40], xmm4
0000774654fd0d94  vmovaps [rsp+0x50], xmm5
0000774654fd0d9a  vmovaps [rsp+0x60], xmm6
0000774654fd0da0  vmovaps [rsp+0x70], xmm7
0000774654fd0da6  vmovaps [rsp+0x80], xmm8
0000774654fd0daf  vmovaps [rsp+0x90], xmm9
0000774654fd0db8  vmovaps [rsp+0xA0], xmm10
0000774654fd0dc1  vmovaps [rsp+0xB0], xmm11
0000774654fd0dca  vmovaps [rsp+0xC0], xmm12
0000774654fd0dd3  vmovaps [rsp+0xD0], xmm13
0000774654fd0ddc  vmovaps [rsp+0xE0], xmm14
0000774654fd0de5  sub rsp, 0x40
0000774654fd0de9  lea rdi, [rsp]
0000774654fd0ded  lea rsi, [rsp+0x10]
0000774654fd0df2  lea rdx, [rsp+0x20]
0000774654fd0df7  lea rcx, [rsp+0x30]
0000774654fd0dfc  mov r8d, 0x00
0000774654fd0e02  lea r9, [r15+0x3A8]
0000774654fd0e09  movaps [rdi], xmm15
0000774654fd0e0d  movaps [rsi], xmm3
0000774654fd0e10  movaps [rdx], xmm1
0000774654fd0e13  movaps [rcx], xmm8
0000774654fd0e17  mov rax, 0x564E5D1DDA50
0000774654fd0e21  call rax
0000774654fd0e23  movaps xmm15, [rsp]
0000774654fd0e28  add rsp, 0x40
0000774654fd0e2c  vmovaps xmm0, [rsp]
0000774654fd0e31  vmovaps xmm1, [rsp+0x10]
0000774654fd0e37  vmovaps xmm2, [rsp+0x20]
0000774654fd0e3d  vmovaps xmm3, [rsp+0x30]
0000774654fd0e43  vmovaps xmm4, [rsp+0x40]
0000774654fd0e49  vmovaps xmm5, [rsp+0x50]
0000774654fd0e4f  vmovaps xmm6, [rsp+0x60]
0000774654fd0e55  vmovaps xmm7, [rsp+0x70]
0000774654fd0e5b  vmovaps xmm8, [rsp+0x80]
0000774654fd0e64  vmovaps xmm9, [rsp+0x90]
0000774654fd0e6d  vmovaps xmm10, [rsp+0xA0]
0000774654fd0e76  vmovaps xmm11, [rsp+0xB0]
0000774654fd0e7f  vmovaps xmm12, [rsp+0xC0]
0000774654fd0e88  vmovaps xmm13, [rsp+0xD0]
0000774654fd0e91  vmovaps xmm14, [rsp+0xE0]
0000774654fd0e9a  add rsp, 0xF0
0000774654fd0ea1  pop r11
0000774654fd0ea3  pop r10
0000774654fd0ea5  pop r9
0000774654fd0ea7  pop r8
0000774654fd0ea9  pop rsi
0000774654fd0eaa  pop rdi
0000774654fd0eab  pop rdx
0000774654fd0eac  pop rcx
0000774654fd0ead  pop rax
0000774654fd0eae  add rsp, 0x08
0000774654fd0eb2  jmp 0x0000774654FCFA82
0000774654fd0eb7  sub rsp, 0x08
0000774654fd0ebb  push rax
0000774654fd0ebc  push rcx
0000774654fd0ebd  push rdx
0000774654fd0ebe  push rdi
0000774654fd0ebf  push rsi
0000774654fd0ec0  push r8
0000774654fd0ec2  push r9
0000774654fd0ec4  push r10
0000774654fd0ec6  push r11
0000774654fd0ec8  sub rsp, 0xF0
0000774654fd0ecf  vmovaps [rsp], xmm0
0000774654fd0ed4  vmovaps [rsp+0x10], xmm1
0000774654fd0eda  vmovaps [rsp+0x20], xmm2
0000774654fd0ee0  vmovaps [rsp+0x30], xmm3
0000774654fd0ee6  vmovaps [rsp+0x40], xmm4
0000774654fd0eec  vmovaps [rsp+0x50], xmm5
0000774654fd0ef2  vmovaps [rsp+0x60], xmm6
0000774654fd0ef8  vmovaps [rsp+0x70], xmm7
0000774654fd0efe  vmovaps [rsp+0x80], xmm9
0000774654fd0f07  vmovaps [rsp+0x90], xmm10
0000774654fd0f10  vmovaps [rsp+0xA0], xmm11
0000774654fd0f19  vmovaps [rsp+0xB0], xmm12
0000774654fd0f22  vmovaps [rsp+0xC0], xmm13
0000774654fd0f2b  vmovaps [rsp+0xD0], xmm14
0000774654fd0f34  vmovaps [rsp+0xE0], xmm15
0000774654fd0f3d  sub rsp, 0x40
0000774654fd0f41  lea rdi, [rsp]
0000774654fd0f45  lea rsi, [rsp+0x10]
0000774654fd0f4a  lea rdx, [rsp+0x20]
0000774654fd0f4f  lea rcx, [rsp+0x30]
0000774654fd0f54  mov r8d, 0x00
0000774654fd0f5a  lea r9, [r15+0x3A8]
0000774654fd0f61  movaps [rdi], xmm8
0000774654fd0f65  movaps [rsi], xmm9
0000774654fd0f69  movaps [rdx], xmm5
0000774654fd0f6c  movaps [rcx], xmm1
0000774654fd0f6f  mov rax, 0x564E5D1DDA50
0000774654fd0f79  call rax
0000774654fd0f7b  movaps xmm8, [rsp]
0000774654fd0f80  add rsp, 0x40
0000774654fd0f84  vmovaps xmm0, [rsp]
0000774654fd0f89  vmovaps xmm1, [rsp+0x10]
0000774654fd0f8f  vmovaps xmm2, [rsp+0x20]
0000774654fd0f95  vmovaps xmm3, [rsp+0x30]
0000774654fd0f9b  vmovaps xmm4, [rsp+0x40]
0000774654fd0fa1  vmovaps xmm5, [rsp+0x50]
0000774654fd0fa7  vmovaps xmm6, [rsp+0x60]
0000774654fd0fad  vmovaps xmm7, [rsp+0x70]
0000774654fd0fb3  vmovaps xmm9, [rsp+0x80]
0000774654fd0fbc  vmovaps xmm10, [rsp+0x90]
0000774654fd0fc5  vmovaps xmm11, [rsp+0xA0]
0000774654fd0fce  vmovaps xmm12, [rsp+0xB0]
0000774654fd0fd7  vmovaps xmm13, [rsp+0xC0]
0000774654fd0fe0  vmovaps xmm14, [rsp+0xD0]
0000774654fd0fe9  vmovaps xmm15, [rsp+0xE0]
0000774654fd0ff2  add rsp, 0xF0
0000774654fd0ff9  pop r11
0000774654fd0ffb  pop r10
0000774654fd0ffd  pop r9
0000774654fd0fff  pop r8
0000774654fd1001  pop rsi
0000774654fd1002  pop rdi
0000774654fd1003  pop rdx
0000774654fd1004  pop rcx
0000774654fd1005  pop rax
0000774654fd1006  add rsp, 0x08
0000774654fd100a  jmp 0x0000774654FCFAAB
0000774654fd100f  sub rsp, 0x08
0000774654fd1013  push rax
0000774654fd1014  push rcx
0000774654fd1015  push rdx
0000774654fd1016  push rdi
0000774654fd1017  push rsi
0000774654fd1018  push r8
0000774654fd101a  push r9
0000774654fd101c  push r10
0000774654fd101e  push r11
0000774654fd1020  sub rsp, 0xF0
0000774654fd1027  vmovaps [rsp], xmm0
0000774654fd102c  vmovaps [rsp+0x10], xmm1
0000774654fd1032  vmovaps [rsp+0x20], xmm2
0000774654fd1038  vmovaps [rsp+0x30], xmm3
0000774654fd103e  vmovaps [rsp+0x40], xmm4
0000774654fd1044  vmovaps [rsp+0x50], xmm6
0000774654fd104a  vmovaps [rsp+0x60], xmm7
0000774654fd1050  vmovaps [rsp+0x70], xmm8
0000774654fd1056  vmovaps [rsp+0x80], xmm9
0000774654fd105f  vmovaps [rsp+0x90], xmm10
0000774654fd1068  vmovaps [rsp+0xA0], xmm11
0000774654fd1071  vmovaps [rsp+0xB0], xmm12
0000774654fd107a  vmovaps [rsp+0xC0], xmm13
0000774654fd1083  vmovaps [rsp+0xD0], xmm14
0000774654fd108c  vmovaps [rsp+0xE0], xmm15
0000774654fd1095  sub rsp, 0x40
0000774654fd1099  lea rdi, [rsp]
0000774654fd109d  lea rsi, [rsp+0x10]
0000774654fd10a2  lea rdx, [rsp+0x20]
0000774654fd10a7  lea rcx, [rsp+0x30]
0000774654fd10ac  mov r8d, 0x00
0000774654fd10b2  lea r9, [r15+0x3A8]
0000774654fd10b9  movaps [rdi], xmm5
0000774654fd10bc  movaps [rsi], xmm14
0000774654fd10c0  movaps [rdx], xmm9
0000774654fd10c4  movaps [rcx], xmm1
0000774654fd10c7  mov rax, 0x564E5D1DDA50
0000774654fd10d1  call rax
0000774654fd10d3  movaps xmm5, [rsp]
0000774654fd10d7  add rsp, 0x40
0000774654fd10db  vmovaps xmm0, [rsp]
0000774654fd10e0  vmovaps xmm1, [rsp+0x10]
0000774654fd10e6  vmovaps xmm2, [rsp+0x20]
0000774654fd10ec  vmovaps xmm3, [rsp+0x30]
0000774654fd10f2  vmovaps xmm4, [rsp+0x40]
0000774654fd10f8  vmovaps xmm6, [rsp+0x50]
0000774654fd10fe  vmovaps xmm7, [rsp+0x60]
0000774654fd1104  vmovaps xmm8, [rsp+0x70]
0000774654fd110a  vmovaps xmm9, [rsp+0x80]
0000774654fd1113  vmovaps xmm10, [rsp+0x90]
0000774654fd111c  vmovaps xmm11, [rsp+0xA0]
0000774654fd1125  vmovaps xmm12, [rsp+0xB0]
0000774654fd112e  vmovaps xmm13, [rsp+0xC0]
0000774654fd1137  vmovaps xmm14, [rsp+0xD0]
0000774654fd1140  vmovaps xmm15, [rsp+0xE0]
0000774654fd1149  add rsp, 0xF0
0000774654fd1150  pop r11
0000774654fd1152  pop r10
0000774654fd1154  pop r9
0000774654fd1156  pop r8
0000774654fd1158  pop rsi
0000774654fd1159  pop rdi
0000774654fd115a  pop rdx
0000774654fd115b  pop rcx
0000774654fd115c  pop rax
0000774654fd115d  add rsp, 0x08
0000774654fd1161  jmp 0x0000774654FCFADF
0000774654fd1166  sub rsp, 0x08
0000774654fd116a  push rax
0000774654fd116b  push rcx
0000774654fd116c  push rdx
0000774654fd116d  push rdi
0000774654fd116e  push rsi
0000774654fd116f  push r8
0000774654fd1171  push r9
0000774654fd1173  push r10
0000774654fd1175  push r11
0000774654fd1177  sub rsp, 0xF0
0000774654fd117e  vmovaps [rsp], xmm0
0000774654fd1183  vmovaps [rsp+0x10], xmm1
0000774654fd1189  vmovaps [rsp+0x20], xmm2
0000774654fd118f  vmovaps [rsp+0x30], xmm3
0000774654fd1195  vmovaps [rsp+0x40], xmm4
0000774654fd119b  vmovaps [rsp+0x50], xmm5
0000774654fd11a1  vmovaps [rsp+0x60], xmm6
0000774654fd11a7  vmovaps [rsp+0x70], xmm7
0000774654fd11ad  vmovaps [rsp+0x80], xmm8
0000774654fd11b6  vmovaps [rsp+0x90], xmm10
0000774654fd11bf  vmovaps [rsp+0xA0], xmm11
0000774654fd11c8  vmovaps [rsp+0xB0], xmm12
0000774654fd11d1  vmovaps [rsp+0xC0], xmm13
0000774654fd11da  vmovaps [rsp+0xD0], xmm14
0000774654fd11e3  vmovaps [rsp+0xE0], xmm15
0000774654fd11ec  sub rsp, 0x40
0000774654fd11f0  lea rdi, [rsp]
0000774654fd11f4  lea rsi, [rsp+0x10]
0000774654fd11f9  lea rdx, [rsp+0x20]
0000774654fd11fe  lea rcx, [rsp+0x30]
0000774654fd1203  mov r8d, 0x00
0000774654fd1209  lea r9, [r15+0x3A8]
0000774654fd1210  movaps [rdi], xmm9
0000774654fd1214  movaps [rsi], xmm14
0000774654fd1218  movaps [rdx], xmm4
0000774654fd121b  movaps [rcx], xmm1
0000774654fd121e  mov rax, 0x564E5D1DDA50
0000774654fd1228  call rax
0000774654fd122a  movaps xmm9, [rsp]
0000774654fd122f  add rsp, 0x40
0000774654fd1233  vmovaps xmm0, [rsp]
0000774654fd1238  vmovaps xmm1, [rsp+0x10]
0000774654fd123e  vmovaps xmm2, [rsp+0x20]
0000774654fd1244  vmovaps xmm3, [rsp+0x30]
0000774654fd124a  vmovaps xmm4, [rsp+0x40]
0000774654fd1250  vmovaps xmm5, [rsp+0x50]
0000774654fd1256  vmovaps xmm6, [rsp+0x60]
0000774654fd125c  vmovaps xmm7, [rsp+0x70]
0000774654fd1262  vmovaps xmm8, [rsp+0x80]
0000774654fd126b  vmovaps xmm10, [rsp+0x90]
0000774654fd1274  vmovaps xmm11, [rsp+0xA0]
0000774654fd127d  vmovaps xmm12, [rsp+0xB0]
0000774654fd1286  vmovaps xmm13, [rsp+0xC0]
0000774654fd128f  vmovaps xmm14, [rsp+0xD0]
0000774654fd1298  vmovaps xmm15, [rsp+0xE0]
0000774654fd12a1  add rsp, 0xF0
0000774654fd12a8  pop r11
0000774654fd12aa  pop r10
0000774654fd12ac  pop r9
0000774654fd12ae  pop r8
0000774654fd12b0  pop rsi
0000774654fd12b1  pop rdi
0000774654fd12b2  pop rdx
0000774654fd12b3  pop rcx
0000774654fd12b4  pop rax
0000774654fd12b5  add rsp, 0x08
0000774654fd12b9  jmp 0x0000774654FCFB0E
0000774654fd12be  sub rsp, 0x08
0000774654fd12c2  push rax
0000774654fd12c3  push rcx
0000774654fd12c4  push rdx
0000774654fd12c5  push rdi
0000774654fd12c6  push rsi
0000774654fd12c7  push r8
0000774654fd12c9  push r9
0000774654fd12cb  push r10
0000774654fd12cd  push r11
0000774654fd12cf  sub rsp, 0xF0
0000774654fd12d6  vmovaps [rsp], xmm0
0000774654fd12db  vmovaps [rsp+0x10], xmm1
0000774654fd12e1  vmovaps [rsp+0x20], xmm3
0000774654fd12e7  vmovaps [rsp+0x30], xmm4
0000774654fd12ed  vmovaps [rsp+0x40], xmm5
0000774654fd12f3  vmovaps [rsp+0x50], xmm6
0000774654fd12f9  vmovaps [rsp+0x60], xmm7
0000774654fd12ff  vmovaps [rsp+0x70], xmm8
0000774654fd1305  vmovaps [rsp+0x80], xmm9
0000774654fd130e  vmovaps [rsp+0x90], xmm10
0000774654fd1317  vmovaps [rsp+0xA0], xmm11
0000774654fd1320  vmovaps [rsp+0xB0], xmm12
0000774654fd1329  vmovaps [rsp+0xC0], xmm13
0000774654fd1332  vmovaps [rsp+0xD0], xmm14
0000774654fd133b  vmovaps [rsp+0xE0], xmm15
0000774654fd1344  sub rsp, 0x40
0000774654fd1348  lea rdi, [rsp]
0000774654fd134c  lea rsi, [rsp+0x10]
0000774654fd1351  lea rdx, [rsp+0x20]
0000774654fd1356  lea rcx, [rsp+0x30]
0000774654fd135b  mov r8d, 0x00
0000774654fd1361  lea r9, [r15+0x3A8]
0000774654fd1368  movaps [rdi], xmm2
0000774654fd136b  movaps [rsi], xmm8
0000774654fd136f  movaps [rdx], xmm13
0000774654fd1373  movaps [rcx], xmm3
0000774654fd1376  mov rax, 0x564E5D1DDA50
0000774654fd1380  call rax
0000774654fd1382  movaps xmm2, [rsp]
0000774654fd1386  add rsp, 0x40
0000774654fd138a  vmovaps xmm0, [rsp]
0000774654fd138f  vmovaps xmm1, [rsp+0x10]
0000774654fd1395  vmovaps xmm3, [rsp+0x20]
0000774654fd139b  vmovaps xmm4, [rsp+0x30]
0000774654fd13a1  vmovaps xmm5, [rsp+0x40]
0000774654fd13a7  vmovaps xmm6, [rsp+0x50]
0000774654fd13ad  vmovaps xmm7, [rsp+0x60]
0000774654fd13b3  vmovaps xmm8, [rsp+0x70]
0000774654fd13b9  vmovaps xmm9, [rsp+0x80]
0000774654fd13c2  vmovaps xmm10, [rsp+0x90]
0000774654fd13cb  vmovaps xmm11, [rsp+0xA0]
0000774654fd13d4  vmovaps xmm12, [rsp+0xB0]
0000774654fd13dd  vmovaps xmm13, [rsp+0xC0]
0000774654fd13e6  vmovaps xmm14, [rsp+0xD0]
0000774654fd13ef  vmovaps xmm15, [rsp+0xE0]
0000774654fd13f8  add rsp, 0xF0
0000774654fd13ff  pop r11
0000774654fd1401  pop r10
0000774654fd1403  pop r9
0000774654fd1405  pop r8
0000774654fd1407  pop rsi
0000774654fd1408  pop rdi
0000774654fd1409  pop rdx
0000774654fd140a  pop rcx
0000774654fd140b  pop rax
0000774654fd140c  add rsp, 0x08
0000774654fd1410  jmp 0x0000774654FCFB8C
0000774654fd1415  sub rsp, 0x08
0000774654fd1419  push rax
0000774654fd141a  push rcx
0000774654fd141b  push rdx
0000774654fd141c  push rdi
0000774654fd141d  push rsi
0000774654fd141e  push r8
0000774654fd1420  push r9
0000774654fd1422  push r10
0000774654fd1424  push r11
0000774654fd1426  sub rsp, 0xF0
0000774654fd142d  vmovaps [rsp], xmm0
0000774654fd1432  vmovaps [rsp+0x10], xmm1
0000774654fd1438  vmovaps [rsp+0x20], xmm2
0000774654fd143e  vmovaps [rsp+0x30], xmm3
0000774654fd1444  vmovaps [rsp+0x40], xmm4
0000774654fd144a  vmovaps [rsp+0x50], xmm5
0000774654fd1450  vmovaps [rsp+0x60], xmm6
0000774654fd1456  vmovaps [rsp+0x70], xmm7
0000774654fd145c  vmovaps [rsp+0x80], xmm9
0000774654fd1465  vmovaps [rsp+0x90], xmm10
0000774654fd146e  vmovaps [rsp+0xA0], xmm11
0000774654fd1477  vmovaps [rsp+0xB0], xmm12
0000774654fd1480  vmovaps [rsp+0xC0], xmm13
0000774654fd1489  vmovaps [rsp+0xD0], xmm14
0000774654fd1492  vmovaps [rsp+0xE0], xmm15
0000774654fd149b  sub rsp, 0x40
0000774654fd149f  lea rdi, [rsp]
0000774654fd14a3  lea rsi, [rsp+0x10]
0000774654fd14a8  lea rdx, [rsp+0x20]
0000774654fd14ad  lea rcx, [rsp+0x30]
0000774654fd14b2  mov r8d, 0x00
0000774654fd14b8  lea r9, [r15+0x3A8]
0000774654fd14bf  movaps [rdi], xmm8
0000774654fd14c3  movaps [rsi], xmm15
0000774654fd14c7  movaps [rdx], xmm13
0000774654fd14cb  movaps [rcx], xmm1
0000774654fd14ce  mov rax, 0x564E5D1DDA50
0000774654fd14d8  call rax
0000774654fd14da  movaps xmm8, [rsp]
0000774654fd14df  add rsp, 0x40
0000774654fd14e3  vmovaps xmm0, [rsp]
0000774654fd14e8  vmovaps xmm1, [rsp+0x10]
0000774654fd14ee  vmovaps xmm2, [rsp+0x20]
0000774654fd14f4  vmovaps xmm3, [rsp+0x30]
0000774654fd14fa  vmovaps xmm4, [rsp+0x40]
0000774654fd1500  vmovaps xmm5, [rsp+0x50]
0000774654fd1506  vmovaps xmm6, [rsp+0x60]
0000774654fd150c  vmovaps xmm7, [rsp+0x70]
0000774654fd1512  vmovaps xmm9, [rsp+0x80]
0000774654fd151b  vmovaps xmm10, [rsp+0x90]
0000774654fd1524  vmovaps xmm11, [rsp+0xA0]
0000774654fd152d  vmovaps xmm12, [rsp+0xB0]
0000774654fd1536  vmovaps xmm13, [rsp+0xC0]
0000774654fd153f  vmovaps xmm14, [rsp+0xD0]
0000774654fd1548  vmovaps xmm15, [rsp+0xE0]
0000774654fd1551  add rsp, 0xF0
0000774654fd1558  pop r11
0000774654fd155a  pop r10
0000774654fd155c  pop r9
0000774654fd155e  pop r8
0000774654fd1560  pop rsi
0000774654fd1561  pop rdi
0000774654fd1562  pop rdx
0000774654fd1563  pop rcx
0000774654fd1564  pop rax
0000774654fd1565  add rsp, 0x08
0000774654fd1569  jmp 0x0000774654FCFBBB
0000774654fd156e  call 0x0000774654DFF430
0000774654fd1573  jmp 0x0000774654FCFBC8
0000774654fd1578  sub rsp, 0x08
0000774654fd157c  push rax
0000774654fd157d  push rcx
0000774654fd157e  push rdx
0000774654fd157f  push rdi
0000774654fd1580  push rsi
0000774654fd1581  push r8
0000774654fd1583  push r9
0000774654fd1585  push r10
0000774654fd1587  push r11
0000774654fd1589  sub rsp, 0xF0
0000774654fd1590  vmovaps [rsp], xmm0
0000774654fd1595  vmovaps [rsp+0x10], xmm1
0000774654fd159b  vmovaps [rsp+0x20], xmm2
0000774654fd15a1  vmovaps [rsp+0x30], xmm3
0000774654fd15a7  vmovaps [rsp+0x40], xmm4
0000774654fd15ad  vmovaps [rsp+0x50], xmm5
0000774654fd15b3  vmovaps [rsp+0x60], xmm6
0000774654fd15b9  vmovaps [rsp+0x70], xmm7
0000774654fd15bf  vmovaps [rsp+0x80], xmm8
0000774654fd15c8  vmovaps [rsp+0x90], xmm9
0000774654fd15d1  vmovaps [rsp+0xA0], xmm10
0000774654fd15da  vmovaps [rsp+0xB0], xmm11
0000774654fd15e3  vmovaps [rsp+0xC0], xmm12
0000774654fd15ec  vmovaps [rsp+0xD0], xmm14
0000774654fd15f5  vmovaps [rsp+0xE0], xmm15
0000774654fd15fe  sub rsp, 0x40
0000774654fd1602  lea rdi, [rsp]
0000774654fd1606  lea rsi, [rsp+0x10]
0000774654fd160b  lea rdx, [rsp+0x20]
0000774654fd1610  lea rcx, [rsp+0x30]
0000774654fd1615  mov r8d, 0x00
0000774654fd161b  lea r9, [r15+0x3A8]
0000774654fd1622  movaps [rdi], xmm13
0000774654fd1626  movaps [rsi], xmm5
0000774654fd1629  movaps [rdx], xmm11
0000774654fd162d  movaps [rcx], xmm15
0000774654fd1631  mov rax, 0x564E5D1DDA50
0000774654fd163b  call rax
0000774654fd163d  movaps xmm13, [rsp]
0000774654fd1642  add rsp, 0x40
0000774654fd1646  vmovaps xmm0, [rsp]
0000774654fd164b  vmovaps xmm1, [rsp+0x10]
0000774654fd1651  vmovaps xmm2, [rsp+0x20]
0000774654fd1657  vmovaps xmm3, [rsp+0x30]
0000774654fd165d  vmovaps xmm4, [rsp+0x40]
0000774654fd1663  vmovaps xmm5, [rsp+0x50]
0000774654fd1669  vmovaps xmm6, [rsp+0x60]
0000774654fd166f  vmovaps xmm7, [rsp+0x70]
0000774654fd1675  vmovaps xmm8, [rsp+0x80]
0000774654fd167e  vmovaps xmm9, [rsp+0x90]
0000774654fd1687  vmovaps xmm10, [rsp+0xA0]
0000774654fd1690  vmovaps xmm11, [rsp+0xB0]
0000774654fd1699  vmovaps xmm12, [rsp+0xC0]
0000774654fd16a2  vmovaps xmm14, [rsp+0xD0]
0000774654fd16ab  vmovaps xmm15, [rsp+0xE0]
0000774654fd16b4  add rsp, 0xF0
0000774654fd16bb  pop r11
0000774654fd16bd  pop r10
0000774654fd16bf  pop r9
0000774654fd16c1  pop r8
0000774654fd16c3  pop rsi
0000774654fd16c4  pop rdi
0000774654fd16c5  pop rdx
0000774654fd16c6  pop rcx
0000774654fd16c7  pop rax
0000774654fd16c8  add rsp, 0x08
0000774654fd16cc  jmp 0x0000774654FCFBF9
0000774654fd16d1  sub rsp, 0x08
0000774654fd16d5  push rax
0000774654fd16d6  push rcx
0000774654fd16d7  push rdx
0000774654fd16d8  push rdi
0000774654fd16d9  push rsi
0000774654fd16da  push r8
0000774654fd16dc  push r9
0000774654fd16de  push r10
0000774654fd16e0  push r11
0000774654fd16e2  sub rsp, 0xF0
0000774654fd16e9  vmovaps [rsp], xmm0
0000774654fd16ee  vmovaps [rsp+0x10], xmm1
0000774654fd16f4  vmovaps [rsp+0x20], xmm2
0000774654fd16fa  vmovaps [rsp+0x30], xmm3
0000774654fd1700  vmovaps [rsp+0x40], xmm4
0000774654fd1706  vmovaps [rsp+0x50], xmm5
0000774654fd170c  vmovaps [rsp+0x60], xmm6
0000774654fd1712  vmovaps [rsp+0x70], xmm7
0000774654fd1718  vmovaps [rsp+0x80], xmm8
0000774654fd1721  vmovaps [rsp+0x90], xmm9
0000774654fd172a  vmovaps [rsp+0xA0], xmm10
0000774654fd1733  vmovaps [rsp+0xB0], xmm12
0000774654fd173c  vmovaps [rsp+0xC0], xmm13
0000774654fd1745  vmovaps [rsp+0xD0], xmm14
0000774654fd174e  vmovaps [rsp+0xE0], xmm15
0000774654fd1757  sub rsp, 0x40
0000774654fd175b  lea rdi, [rsp]
0000774654fd175f  lea rsi, [rsp+0x10]
0000774654fd1764  lea rdx, [rsp+0x20]
0000774654fd1769  lea rcx, [rsp+0x30]
0000774654fd176e  mov r8d, 0x00
0000774654fd1774  lea r9, [r15+0x3A8]
0000774654fd177b  movaps [rdi], xmm11
0000774654fd177f  movaps [rsi], xmm9
0000774654fd1783  movaps [rdx], xmm4
0000774654fd1786  movaps [rcx], xmm15
0000774654fd178a  mov rax, 0x564E5D1DDA50
0000774654fd1794  call rax
0000774654fd1796  movaps xmm11, [rsp]
0000774654fd179b  add rsp, 0x40
0000774654fd179f  vmovaps xmm0, [rsp]
0000774654fd17a4  vmovaps xmm1, [rsp+0x10]
0000774654fd17aa  vmovaps xmm2, [rsp+0x20]
0000774654fd17b0  vmovaps xmm3, [rsp+0x30]
0000774654fd17b6  vmovaps xmm4, [rsp+0x40]
0000774654fd17bc  vmovaps xmm5, [rsp+0x50]
0000774654fd17c2  vmovaps xmm6, [rsp+0x60]
0000774654fd17c8  vmovaps xmm7, [rsp+0x70]
0000774654fd17ce  vmovaps xmm8, [rsp+0x80]
0000774654fd17d7  vmovaps xmm9, [rsp+0x90]
0000774654fd17e0  vmovaps xmm10, [rsp+0xA0]
0000774654fd17e9  vmovaps xmm12, [rsp+0xB0]
0000774654fd17f2  vmovaps xmm13, [rsp+0xC0]
0000774654fd17fb  vmovaps xmm14, [rsp+0xD0]
0000774654fd1804  vmovaps xmm15, [rsp+0xE0]
0000774654fd180d  add rsp, 0xF0
0000774654fd1814  pop r11
0000774654fd1816  pop r10
0000774654fd1818  pop r9
0000774654fd181a  pop r8
0000774654fd181c  pop rsi
0000774654fd181d  pop rdi
0000774654fd181e  pop rdx
0000774654fd181f  pop rcx
0000774654fd1820  pop rax
0000774654fd1821  add rsp, 0x08
0000774654fd1825  jmp 0x0000774654FCFC22
0000774654fd182a  call 0x0000774654E0E760
0000774654fd182f  jmp 0x0000774654FCFC45
0000774654fd1834  call 0x0000774654E07890
0000774654fd1839  jmp 0x0000774654FCFC4F
0000774654fd183e  sub rsp, 0x08
0000774654fd1842  push rax
0000774654fd1843  push rcx
0000774654fd1844  push rdx
0000774654fd1845  push rdi
0000774654fd1846  push rsi
0000774654fd1847  push r8
0000774654fd1849  push r9
0000774654fd184b  push r10
0000774654fd184d  push r11
0000774654fd184f  sub rsp, 0xF0
0000774654fd1856  vmovaps [rsp], xmm0
0000774654fd185b  vmovaps [rsp+0x10], xmm1
0000774654fd1861  vmovaps [rsp+0x20], xmm2
0000774654fd1867  vmovaps [rsp+0x30], xmm3
0000774654fd186d  vmovaps [rsp+0x40], xmm5
0000774654fd1873  vmovaps [rsp+0x50], xmm6
0000774654fd1879  vmovaps [rsp+0x60], xmm7
0000774654fd187f  vmovaps [rsp+0x70], xmm8
0000774654fd1885  vmovaps [rsp+0x80], xmm9
0000774654fd188e  vmovaps [rsp+0x90], xmm10
0000774654fd1897  vmovaps [rsp+0xA0], xmm11
0000774654fd18a0  vmovaps [rsp+0xB0], xmm12
0000774654fd18a9  vmovaps [rsp+0xC0], xmm13
0000774654fd18b2  vmovaps [rsp+0xD0], xmm14
0000774654fd18bb  vmovaps [rsp+0xE0], xmm15
0000774654fd18c4  sub rsp, 0x40
0000774654fd18c8  lea rdi, [rsp]
0000774654fd18cc  lea rsi, [rsp+0x10]
0000774654fd18d1  lea rdx, [rsp+0x20]
0000774654fd18d6  lea rcx, [rsp+0x30]
0000774654fd18db  mov r8d, 0x00
0000774654fd18e1  lea r9, [r15+0x3A8]
0000774654fd18e8  movaps [rdi], xmm4
0000774654fd18eb  movaps [rsi], xmm2
0000774654fd18ee  movaps [rdx], xmm14
0000774654fd18f2  movaps [rcx], xmm5
0000774654fd18f5  mov rax, 0x564E5D1DDA50
0000774654fd18ff  call rax
0000774654fd1901  movaps xmm4, [rsp]
0000774654fd1905  add rsp, 0x40
0000774654fd1909  vmovaps xmm0, [rsp]
0000774654fd190e  vmovaps xmm1, [rsp+0x10]
0000774654fd1914  vmovaps xmm2, [rsp+0x20]
0000774654fd191a  vmovaps xmm3, [rsp+0x30]
0000774654fd1920  vmovaps xmm5, [rsp+0x40]
0000774654fd1926  vmovaps xmm6, [rsp+0x50]
0000774654fd192c  vmovaps xmm7, [rsp+0x60]
0000774654fd1932  vmovaps xmm8, [rsp+0x70]
0000774654fd1938  vmovaps xmm9, [rsp+0x80]
0000774654fd1941  vmovaps xmm10, [rsp+0x90]
0000774654fd194a  vmovaps xmm11, [rsp+0xA0]
0000774654fd1953  vmovaps xmm12, [rsp+0xB0]
0000774654fd195c  vmovaps xmm13, [rsp+0xC0]
0000774654fd1965  vmovaps xmm14, [rsp+0xD0]
0000774654fd196e  vmovaps xmm15, [rsp+0xE0]
0000774654fd1977  add rsp, 0xF0
0000774654fd197e  pop r11
0000774654fd1980  pop r10
0000774654fd1982  pop r9
0000774654fd1984  pop r8
0000774654fd1986  pop rsi
0000774654fd1987  pop rdi
0000774654fd1988  pop rdx
0000774654fd1989  pop rcx
0000774654fd198a  pop rax
0000774654fd198b  add rsp, 0x08
0000774654fd198f  jmp 0x0000774654FCFC86
0000774654fd1994  sub rsp, 0x08
0000774654fd1998  push rax
0000774654fd1999  push rcx
0000774654fd199a  push rdx
0000774654fd199b  push rdi
0000774654fd199c  push rsi
0000774654fd199d  push r8
0000774654fd199f  push r9
0000774654fd19a1  push r10
0000774654fd19a3  push r11
0000774654fd19a5  sub rsp, 0xF0
0000774654fd19ac  vmovaps [rsp], xmm0
0000774654fd19b1  vmovaps [rsp+0x10], xmm1
0000774654fd19b7  vmovaps [rsp+0x20], xmm2
0000774654fd19bd  vmovaps [rsp+0x30], xmm3
0000774654fd19c3  vmovaps [rsp+0x40], xmm4
0000774654fd19c9  vmovaps [rsp+0x50], xmm6
0000774654fd19cf  vmovaps [rsp+0x60], xmm7
0000774654fd19d5  vmovaps [rsp+0x70], xmm8
0000774654fd19db  vmovaps [rsp+0x80], xmm9
0000774654fd19e4  vmovaps [rsp+0x90], xmm10
0000774654fd19ed  vmovaps [rsp+0xA0], xmm11
0000774654fd19f6  vmovaps [rsp+0xB0], xmm12
0000774654fd19ff  vmovaps [rsp+0xC0], xmm13
0000774654fd1a08  vmovaps [rsp+0xD0], xmm14
0000774654fd1a11  vmovaps [rsp+0xE0], xmm15
0000774654fd1a1a  sub rsp, 0x40
0000774654fd1a1e  lea rdi, [rsp]
0000774654fd1a22  lea rsi, [rsp+0x10]
0000774654fd1a27  lea rdx, [rsp+0x20]
0000774654fd1a2c  lea rcx, [rsp+0x30]
0000774654fd1a31  mov r8d, 0x00
0000774654fd1a37  lea r9, [r15+0x3A8]
0000774654fd1a3e  movaps [rdi], xmm5
0000774654fd1a41  movaps [rsi], xmm8
0000774654fd1a45  movaps [rdx], xmm7
0000774654fd1a48  movaps [rcx], xmm14
0000774654fd1a4c  mov rax, 0x564E5D1DDA50
0000774654fd1a56  call rax
0000774654fd1a58  movaps xmm5, [rsp]
0000774654fd1a5c  add rsp, 0x40
0000774654fd1a60  vmovaps xmm0, [rsp]
0000774654fd1a65  vmovaps xmm1, [rsp+0x10]
0000774654fd1a6b  vmovaps xmm2, [rsp+0x20]
0000774654fd1a71  vmovaps xmm3, [rsp+0x30]
0000774654fd1a77  vmovaps xmm4, [rsp+0x40]
0000774654fd1a7d  vmovaps xmm6, [rsp+0x50]
0000774654fd1a83  vmovaps xmm7, [rsp+0x60]
0000774654fd1a89  vmovaps xmm8, [rsp+0x70]
0000774654fd1a8f  vmovaps xmm9, [rsp+0x80]
0000774654fd1a98  vmovaps xmm10, [rsp+0x90]
0000774654fd1aa1  vmovaps xmm11, [rsp+0xA0]
0000774654fd1aaa  vmovaps xmm12, [rsp+0xB0]
0000774654fd1ab3  vmovaps xmm13, [rsp+0xC0]
0000774654fd1abc  vmovaps xmm14, [rsp+0xD0]
0000774654fd1ac5  vmovaps xmm15, [rsp+0xE0]
0000774654fd1ace  add rsp, 0xF0
0000774654fd1ad5  pop r11
0000774654fd1ad7  pop r10
0000774654fd1ad9  pop r9
0000774654fd1adb  pop r8
0000774654fd1add  pop rsi
0000774654fd1ade  pop rdi
0000774654fd1adf  pop rdx
0000774654fd1ae0  pop rcx
0000774654fd1ae1  pop rax
0000774654fd1ae2  add rsp, 0x08
0000774654fd1ae6  jmp 0x0000774654FCFCAE
0000774654fd1aeb  sub rsp, 0x08
0000774654fd1aef  push rax
0000774654fd1af0  push rcx
0000774654fd1af1  push rdx
0000774654fd1af2  push rdi
0000774654fd1af3  push rsi
0000774654fd1af4  push r8
0000774654fd1af6  push r9
0000774654fd1af8  push r10
0000774654fd1afa  push r11
0000774654fd1afc  sub rsp, 0xF0
0000774654fd1b03  vmovaps [rsp], xmm0
0000774654fd1b08  vmovaps [rsp+0x10], xmm1
0000774654fd1b0e  vmovaps [rsp+0x20], xmm2
0000774654fd1b14  vmovaps [rsp+0x30], xmm3
0000774654fd1b1a  vmovaps [rsp+0x40], xmm4
0000774654fd1b20  vmovaps [rsp+0x50], xmm5
0000774654fd1b26  vmovaps [rsp+0x60], xmm6
0000774654fd1b2c  vmovaps [rsp+0x70], xmm7
0000774654fd1b32  vmovaps [rsp+0x80], xmm9
0000774654fd1b3b  vmovaps [rsp+0x90], xmm10
0000774654fd1b44  vmovaps [rsp+0xA0], xmm11
0000774654fd1b4d  vmovaps [rsp+0xB0], xmm12
0000774654fd1b56  vmovaps [rsp+0xC0], xmm13
0000774654fd1b5f  vmovaps [rsp+0xD0], xmm14
0000774654fd1b68  vmovaps [rsp+0xE0], xmm15
0000774654fd1b71  sub rsp, 0x40
0000774654fd1b75  lea rdi, [rsp]
0000774654fd1b79  lea rsi, [rsp+0x10]
0000774654fd1b7e  lea rdx, [rsp+0x20]
0000774654fd1b83  lea rcx, [rsp+0x30]
0000774654fd1b88  mov r8d, 0x00
0000774654fd1b8e  lea r9, [r15+0x3A8]
0000774654fd1b95  movaps [rdi], xmm8
0000774654fd1b99  movaps [rsi], xmm13
0000774654fd1b9d  movaps [rdx], xmm6
0000774654fd1ba0  movaps [rcx], xmm14
0000774654fd1ba4  mov rax, 0x564E5D1DDA50
0000774654fd1bae  call rax
0000774654fd1bb0  movaps xmm8, [rsp]
0000774654fd1bb5  add rsp, 0x40
0000774654fd1bb9  vmovaps xmm0, [rsp]
0000774654fd1bbe  vmovaps xmm1, [rsp+0x10]
0000774654fd1bc4  vmovaps xmm2, [rsp+0x20]
0000774654fd1bca  vmovaps xmm3, [rsp+0x30]
0000774654fd1bd0  vmovaps xmm4, [rsp+0x40]
0000774654fd1bd6  vmovaps xmm5, [rsp+0x50]
0000774654fd1bdc  vmovaps xmm6, [rsp+0x60]
0000774654fd1be2  vmovaps xmm7, [rsp+0x70]
0000774654fd1be8  vmovaps xmm9, [rsp+0x80]
0000774654fd1bf1  vmovaps xmm10, [rsp+0x90]
0000774654fd1bfa  vmovaps xmm11, [rsp+0xA0]
0000774654fd1c03  vmovaps xmm12, [rsp+0xB0]
0000774654fd1c0c  vmovaps xmm13, [rsp+0xC0]
0000774654fd1c15  vmovaps xmm14, [rsp+0xD0]
0000774654fd1c1e  vmovaps xmm15, [rsp+0xE0]
0000774654fd1c27  add rsp, 0xF0
0000774654fd1c2e  pop r11
0000774654fd1c30  pop r10
0000774654fd1c32  pop r9
0000774654fd1c34  pop r8
0000774654fd1c36  pop rsi
0000774654fd1c37  pop rdi
0000774654fd1c38  pop rdx
0000774654fd1c39  pop rcx
0000774654fd1c3a  pop rax
0000774654fd1c3b  add rsp, 0x08
0000774654fd1c3f  jmp 0x0000774654FCFCD7
0000774654fd1c44  sub rsp, 0x08
0000774654fd1c48  push rax
0000774654fd1c49  push rcx
0000774654fd1c4a  push rdx
0000774654fd1c4b  push rdi
0000774654fd1c4c  push rsi
0000774654fd1c4d  push r8
0000774654fd1c4f  push r9
0000774654fd1c51  push r10
0000774654fd1c53  push r11
0000774654fd1c55  sub rsp, 0xF0
0000774654fd1c5c  vmovaps [rsp], xmm0
0000774654fd1c61  vmovaps [rsp+0x10], xmm1
0000774654fd1c67  vmovaps [rsp+0x20], xmm2
0000774654fd1c6d  vmovaps [rsp+0x30], xmm3
0000774654fd1c73  vmovaps [rsp+0x40], xmm4
0000774654fd1c79  vmovaps [rsp+0x50], xmm5
0000774654fd1c7f  vmovaps [rsp+0x60], xmm6
0000774654fd1c85  vmovaps [rsp+0x70], xmm7
0000774654fd1c8b  vmovaps [rsp+0x80], xmm8
0000774654fd1c94  vmovaps [rsp+0x90], xmm9
0000774654fd1c9d  vmovaps [rsp+0xA0], xmm10
0000774654fd1ca6  vmovaps [rsp+0xB0], xmm11
0000774654fd1caf  vmovaps [rsp+0xC0], xmm12
0000774654fd1cb8  vmovaps [rsp+0xD0], xmm14
0000774654fd1cc1  vmovaps [rsp+0xE0], xmm15
0000774654fd1cca  sub rsp, 0x40
0000774654fd1cce  lea rdi, [rsp]
0000774654fd1cd2  lea rsi, [rsp+0x10]
0000774654fd1cd7  lea rdx, [rsp+0x20]
0000774654fd1cdc  lea rcx, [rsp+0x30]
0000774654fd1ce1  mov r8d, 0x00
0000774654fd1ce7  lea r9, [r15+0x3A8]
0000774654fd1cee  movaps [rdi], xmm13
0000774654fd1cf2  movaps [rsi], xmm11
0000774654fd1cf6  movaps [rdx], xmm12
0000774654fd1cfa  movaps [rcx], xmm14
0000774654fd1cfe  mov rax, 0x564E5D1DDA50
0000774654fd1d08  call rax
0000774654fd1d0a  movaps xmm13, [rsp]
0000774654fd1d0f  add rsp, 0x40
0000774654fd1d13  vmovaps xmm0, [rsp]
0000774654fd1d18  vmovaps xmm1, [rsp+0x10]
0000774654fd1d1e  vmovaps xmm2, [rsp+0x20]
0000774654fd1d24  vmovaps xmm3, [rsp+0x30]
0000774654fd1d2a  vmovaps xmm4, [rsp+0x40]
0000774654fd1d30  vmovaps xmm5, [rsp+0x50]
0000774654fd1d36  vmovaps xmm6, [rsp+0x60]
0000774654fd1d3c  vmovaps xmm7, [rsp+0x70]
0000774654fd1d42  vmovaps xmm8, [rsp+0x80]
0000774654fd1d4b  vmovaps xmm9, [rsp+0x90]
0000774654fd1d54  vmovaps xmm10, [rsp+0xA0]
0000774654fd1d5d  vmovaps xmm11, [rsp+0xB0]
0000774654fd1d66  vmovaps xmm12, [rsp+0xC0]
0000774654fd1d6f  vmovaps xmm14, [rsp+0xD0]
0000774654fd1d78  vmovaps xmm15, [rsp+0xE0]
0000774654fd1d81  add rsp, 0xF0
0000774654fd1d88  pop r11
0000774654fd1d8a  pop r10
0000774654fd1d8c  pop r9
0000774654fd1d8e  pop r8
0000774654fd1d90  pop rsi
0000774654fd1d91  pop rdi
0000774654fd1d92  pop rdx
0000774654fd1d93  pop rcx
0000774654fd1d94  pop rax
0000774654fd1d95  add rsp, 0x08
0000774654fd1d99  jmp 0x0000774654FCFD00
0000774654fd1d9e  call 0x0000774654E0D4E0
0000774654fd1da3  jmp 0x0000774654FCFD0A
0000774654fd1da8  call 0x0000774654E0AFE0
0000774654fd1dad  jmp 0x0000774654FCFD14
0000774654fd1db2  sub rsp, 0x08
0000774654fd1db6  push rax
0000774654fd1db7  push rcx
0000774654fd1db8  push rdx
0000774654fd1db9  push rdi
0000774654fd1dba  push rsi
0000774654fd1dbb  push r8
0000774654fd1dbd  push r9
0000774654fd1dbf  push r10
0000774654fd1dc1  push r11
0000774654fd1dc3  sub rsp, 0xF0
0000774654fd1dca  vmovaps [rsp], xmm0
0000774654fd1dcf  vmovaps [rsp+0x10], xmm1
0000774654fd1dd5  vmovaps [rsp+0x20], xmm2
0000774654fd1ddb  vmovaps [rsp+0x30], xmm3
0000774654fd1de1  vmovaps [rsp+0x40], xmm4
0000774654fd1de7  vmovaps [rsp+0x50], xmm5
0000774654fd1ded  vmovaps [rsp+0x60], xmm6
0000774654fd1df3  vmovaps [rsp+0x70], xmm8
0000774654fd1df9  vmovaps [rsp+0x80], xmm9
0000774654fd1e02  vmovaps [rsp+0x90], xmm10
0000774654fd1e0b  vmovaps [rsp+0xA0], xmm11
0000774654fd1e14  vmovaps [rsp+0xB0], xmm12
0000774654fd1e1d  vmovaps [rsp+0xC0], xmm13
0000774654fd1e26  vmovaps [rsp+0xD0], xmm14
0000774654fd1e2f  vmovaps [rsp+0xE0], xmm15
0000774654fd1e38  sub rsp, 0x40
0000774654fd1e3c  lea rdi, [rsp]
0000774654fd1e40  lea rsi, [rsp+0x10]
0000774654fd1e45  lea rdx, [rsp+0x20]
0000774654fd1e4a  lea rcx, [rsp+0x30]
0000774654fd1e4f  mov r8d, 0x00
0000774654fd1e55  lea r9, [r15+0x3A8]
0000774654fd1e5c  movaps [rdi], xmm7
0000774654fd1e5f  movaps [rsi], xmm4
0000774654fd1e62  movaps [rdx], xmm9
0000774654fd1e66  movaps [rcx], xmm11
0000774654fd1e6a  mov rax, 0x564E5D1DDA50
0000774654fd1e74  call rax
0000774654fd1e76  movaps xmm7, [rsp]
0000774654fd1e7a  add rsp, 0x40
0000774654fd1e7e  vmovaps xmm0, [rsp]
0000774654fd1e83  vmovaps xmm1, [rsp+0x10]
0000774654fd1e89  vmovaps xmm2, [rsp+0x20]
0000774654fd1e8f  vmovaps xmm3, [rsp+0x30]
0000774654fd1e95  vmovaps xmm4, [rsp+0x40]
0000774654fd1e9b  vmovaps xmm5, [rsp+0x50]
0000774654fd1ea1  vmovaps xmm6, [rsp+0x60]
0000774654fd1ea7  vmovaps xmm8, [rsp+0x70]
0000774654fd1ead  vmovaps xmm9, [rsp+0x80]
0000774654fd1eb6  vmovaps xmm10, [rsp+0x90]
0000774654fd1ebf  vmovaps xmm11, [rsp+0xA0]
0000774654fd1ec8  vmovaps xmm12, [rsp+0xB0]
0000774654fd1ed1  vmovaps xmm13, [rsp+0xC0]
0000774654fd1eda  vmovaps xmm14, [rsp+0xD0]
0000774654fd1ee3  vmovaps xmm15, [rsp+0xE0]
0000774654fd1eec  add rsp, 0xF0
0000774654fd1ef3  pop r11
0000774654fd1ef5  pop r10
0000774654fd1ef7  pop r9
0000774654fd1ef9  pop r8
0000774654fd1efb  pop rsi
0000774654fd1efc  pop rdi
0000774654fd1efd  pop rdx
0000774654fd1efe  pop rcx
0000774654fd1eff  pop rax
0000774654fd1f00  add rsp, 0x08
0000774654fd1f04  jmp 0x0000774654FCFD4B
0000774654fd1f09  sub rsp, 0x08
0000774654fd1f0d  push rax
0000774654fd1f0e  push rcx
0000774654fd1f0f  push rdx
0000774654fd1f10  push rdi
0000774654fd1f11  push rsi
0000774654fd1f12  push r8
0000774654fd1f14  push r9
0000774654fd1f16  push r10
0000774654fd1f18  push r11
0000774654fd1f1a  sub rsp, 0xF0
0000774654fd1f21  vmovaps [rsp], xmm0
0000774654fd1f26  vmovaps [rsp+0x10], xmm1
0000774654fd1f2c  vmovaps [rsp+0x20], xmm2
0000774654fd1f32  vmovaps [rsp+0x30], xmm3
0000774654fd1f38  vmovaps [rsp+0x40], xmm4
0000774654fd1f3e  vmovaps [rsp+0x50], xmm5
0000774654fd1f44  vmovaps [rsp+0x60], xmm6
0000774654fd1f4a  vmovaps [rsp+0x70], xmm7
0000774654fd1f50  vmovaps [rsp+0x80], xmm8
0000774654fd1f59  vmovaps [rsp+0x90], xmm10
0000774654fd1f62  vmovaps [rsp+0xA0], xmm11
0000774654fd1f6b  vmovaps [rsp+0xB0], xmm12
0000774654fd1f74  vmovaps [rsp+0xC0], xmm13
0000774654fd1f7d  vmovaps [rsp+0xD0], xmm14
0000774654fd1f86  vmovaps [rsp+0xE0], xmm15
0000774654fd1f8f  sub rsp, 0x40
0000774654fd1f93  lea rdi, [rsp]
0000774654fd1f97  lea rsi, [rsp+0x10]
0000774654fd1f9c  lea rdx, [rsp+0x20]
0000774654fd1fa1  lea rcx, [rsp+0x30]
0000774654fd1fa6  mov r8d, 0x00
0000774654fd1fac  lea r9, [r15+0x3A8]
0000774654fd1fb3  movaps [rdi], xmm9
0000774654fd1fb7  movaps [rsi], xmm5
0000774654fd1fba  movaps [rdx], xmm14
0000774654fd1fbe  movaps [rcx], xmm11
0000774654fd1fc2  mov rax, 0x564E5D1DDA50
0000774654fd1fcc  call rax
0000774654fd1fce  movaps xmm9, [rsp]
0000774654fd1fd3  add rsp, 0x40
0000774654fd1fd7  vmovaps xmm0, [rsp]
0000774654fd1fdc  vmovaps xmm1, [rsp+0x10]
0000774654fd1fe2  vmovaps xmm2, [rsp+0x20]
0000774654fd1fe8  vmovaps xmm3, [rsp+0x30]
0000774654fd1fee  vmovaps xmm4, [rsp+0x40]
0000774654fd1ff4  vmovaps xmm5, [rsp+0x50]
0000774654fd1ffa  vmovaps xmm6, [rsp+0x60]
0000774654fd2000  vmovaps xmm7, [rsp+0x70]
0000774654fd2006  vmovaps xmm8, [rsp+0x80]
0000774654fd200f  vmovaps xmm10, [rsp+0x90]
0000774654fd2018  vmovaps xmm11, [rsp+0xA0]
0000774654fd2021  vmovaps xmm12, [rsp+0xB0]
0000774654fd202a  vmovaps xmm13, [rsp+0xC0]
0000774654fd2033  vmovaps xmm14, [rsp+0xD0]
0000774654fd203c  vmovaps xmm15, [rsp+0xE0]
0000774654fd2045  add rsp, 0xF0
0000774654fd204c  pop r11
0000774654fd204e  pop r10
0000774654fd2050  pop r9
0000774654fd2052  pop r8
0000774654fd2054  pop rsi
0000774654fd2055  pop rdi
0000774654fd2056  pop rdx
0000774654fd2057  pop rcx
0000774654fd2058  pop rax
0000774654fd2059  add rsp, 0x08
0000774654fd205d  jmp 0x0000774654FCFD74
0000774654fd2062  sub rsp, 0x08
0000774654fd2066  push rax
0000774654fd2067  push rcx
0000774654fd2068  push rdx
0000774654fd2069  push rdi
0000774654fd206a  push rsi
0000774654fd206b  push r8
0000774654fd206d  push r9
0000774654fd206f  push r10
0000774654fd2071  push r11
0000774654fd2073  sub rsp, 0xF0
0000774654fd207a  vmovaps [rsp], xmm0
0000774654fd207f  vmovaps [rsp+0x10], xmm1
0000774654fd2085  vmovaps [rsp+0x20], xmm2
0000774654fd208b  vmovaps [rsp+0x30], xmm3
0000774654fd2091  vmovaps [rsp+0x40], xmm4
0000774654fd2097  vmovaps [rsp+0x50], xmm5
0000774654fd209d  vmovaps [rsp+0x60], xmm6
0000774654fd20a3  vmovaps [rsp+0x70], xmm7
0000774654fd20a9  vmovaps [rsp+0x80], xmm8
0000774654fd20b2  vmovaps [rsp+0x90], xmm9
0000774654fd20bb  vmovaps [rsp+0xA0], xmm10
0000774654fd20c4  vmovaps [rsp+0xB0], xmm12
0000774654fd20cd  vmovaps [rsp+0xC0], xmm13
0000774654fd20d6  vmovaps [rsp+0xD0], xmm14
0000774654fd20df  vmovaps [rsp+0xE0], xmm15
0000774654fd20e8  sub rsp, 0x40
0000774654fd20ec  lea rdi, [rsp]
0000774654fd20f0  lea rsi, [rsp+0x10]
0000774654fd20f5  lea rdx, [rsp+0x20]
0000774654fd20fa  lea rcx, [rsp+0x30]
0000774654fd20ff  mov r8d, 0x00
0000774654fd2105  lea r9, [r15+0x3A8]
0000774654fd210c  movaps [rdi], xmm11
0000774654fd2110  movaps [rsi], xmm8
0000774654fd2114  movaps [rdx], xmm10
0000774654fd2118  movaps [rcx], xmm14
0000774654fd211c  mov rax, 0x564E5D1DDA50
0000774654fd2126  call rax
0000774654fd2128  movaps xmm11, [rsp]
0000774654fd212d  add rsp, 0x40
0000774654fd2131  vmovaps xmm0, [rsp]
0000774654fd2136  vmovaps xmm1, [rsp+0x10]
0000774654fd213c  vmovaps xmm2, [rsp+0x20]
0000774654fd2142  vmovaps xmm3, [rsp+0x30]
0000774654fd2148  vmovaps xmm4, [rsp+0x40]
0000774654fd214e  vmovaps xmm5, [rsp+0x50]
0000774654fd2154  vmovaps xmm6, [rsp+0x60]
0000774654fd215a  vmovaps xmm7, [rsp+0x70]
0000774654fd2160  vmovaps xmm8, [rsp+0x80]
0000774654fd2169  vmovaps xmm9, [rsp+0x90]
0000774654fd2172  vmovaps xmm10, [rsp+0xA0]
0000774654fd217b  vmovaps xmm12, [rsp+0xB0]
0000774654fd2184  vmovaps xmm13, [rsp+0xC0]
0000774654fd218d  vmovaps xmm14, [rsp+0xD0]
0000774654fd2196  vmovaps xmm15, [rsp+0xE0]
0000774654fd219f  add rsp, 0xF0
0000774654fd21a6  pop r11
0000774654fd21a8  pop r10
0000774654fd21aa  pop r9
0000774654fd21ac  pop r8
0000774654fd21ae  pop rsi
0000774654fd21af  pop rdi
0000774654fd21b0  pop rdx
0000774654fd21b1  pop rcx
0000774654fd21b2  pop rax
0000774654fd21b3  add rsp, 0x08
0000774654fd21b7  jmp 0x0000774654FCFD9D
0000774654fd21bc  sub rsp, 0x08
0000774654fd21c0  push rax
0000774654fd21c1  push rcx
0000774654fd21c2  push rdx
0000774654fd21c3  push rdi
0000774654fd21c4  push rsi
0000774654fd21c5  push r8
0000774654fd21c7  push r9
0000774654fd21c9  push r10
0000774654fd21cb  push r11
0000774654fd21cd  sub rsp, 0xF0
0000774654fd21d4  vmovaps [rsp], xmm0
0000774654fd21d9  vmovaps [rsp+0x10], xmm1
0000774654fd21df  vmovaps [rsp+0x20], xmm2
0000774654fd21e5  vmovaps [rsp+0x30], xmm3
0000774654fd21eb  vmovaps [rsp+0x40], xmm4
0000774654fd21f1  vmovaps [rsp+0x50], xmm5
0000774654fd21f7  vmovaps [rsp+0x60], xmm6
0000774654fd21fd  vmovaps [rsp+0x70], xmm7
0000774654fd2203  vmovaps [rsp+0x80], xmm8
0000774654fd220c  vmovaps [rsp+0x90], xmm9
0000774654fd2215  vmovaps [rsp+0xA0], xmm11
0000774654fd221e  vmovaps [rsp+0xB0], xmm12
0000774654fd2227  vmovaps [rsp+0xC0], xmm13
0000774654fd2230  vmovaps [rsp+0xD0], xmm14
0000774654fd2239  vmovaps [rsp+0xE0], xmm15
0000774654fd2242  sub rsp, 0x40
0000774654fd2246  lea rdi, [rsp]
0000774654fd224a  lea rsi, [rsp+0x10]
0000774654fd224f  lea rdx, [rsp+0x20]
0000774654fd2254  lea rcx, [rsp+0x30]
0000774654fd2259  mov r8d, 0x00
0000774654fd225f  lea r9, [r15+0x3A8]
0000774654fd2266  movaps [rdi], xmm10
0000774654fd226a  movaps [rsi], xmm13
0000774654fd226e  movaps [rdx], xmm15
0000774654fd2272  movaps [rcx], xmm14
0000774654fd2276  mov rax, 0x564E5D1DDA50
0000774654fd2280  call rax
0000774654fd2282  movaps xmm10, [rsp]
0000774654fd2287  add rsp, 0x40
0000774654fd228b  vmovaps xmm0, [rsp]
0000774654fd2290  vmovaps xmm1, [rsp+0x10]
0000774654fd2296  vmovaps xmm2, [rsp+0x20]
0000774654fd229c  vmovaps xmm3, [rsp+0x30]
0000774654fd22a2  vmovaps xmm4, [rsp+0x40]
0000774654fd22a8  vmovaps xmm5, [rsp+0x50]
0000774654fd22ae  vmovaps xmm6, [rsp+0x60]
0000774654fd22b4  vmovaps xmm7, [rsp+0x70]
0000774654fd22ba  vmovaps xmm8, [rsp+0x80]
0000774654fd22c3  vmovaps xmm9, [rsp+0x90]
0000774654fd22cc  vmovaps xmm11, [rsp+0xA0]
0000774654fd22d5  vmovaps xmm12, [rsp+0xB0]
0000774654fd22de  vmovaps xmm13, [rsp+0xC0]
0000774654fd22e7  vmovaps xmm14, [rsp+0xD0]
0000774654fd22f0  vmovaps xmm15, [rsp+0xE0]
0000774654fd22f9  add rsp, 0xF0
0000774654fd2300  pop r11
0000774654fd2302  pop r10
0000774654fd2304  pop r9
0000774654fd2306  pop r8
0000774654fd2308  pop rsi
0000774654fd2309  pop rdi
0000774654fd230a  pop rdx
0000774654fd230b  pop rcx
0000774654fd230c  pop rax
0000774654fd230d  add rsp, 0x08
0000774654fd2311  jmp 0x0000774654FCFDC6
0000774654fd2316  call 0x0000774654E0E760
0000774654fd231b  jmp 0x0000774654FCFDD0
0000774654fd2320  call 0x0000774654E0D4E0
0000774654fd2325  jmp 0x0000774654FCFDDA
0000774654fd232a  sub rsp, 0x08
0000774654fd232e  push rax
0000774654fd232f  push rcx
0000774654fd2330  push rdx
0000774654fd2331  push rdi
0000774654fd2332  push rsi
0000774654fd2333  push r8
0000774654fd2335  push r9
0000774654fd2337  push r10
0000774654fd2339  push r11
0000774654fd233b  sub rsp, 0xF0
0000774654fd2342  vmovaps [rsp], xmm0
0000774654fd2347  vmovaps [rsp+0x10], xmm1
0000774654fd234d  vmovaps [rsp+0x20], xmm2
0000774654fd2353  vmovaps [rsp+0x30], xmm3
0000774654fd2359  vmovaps [rsp+0x40], xmm4
0000774654fd235f  vmovaps [rsp+0x50], xmm5
0000774654fd2365  vmovaps [rsp+0x60], xmm7
0000774654fd236b  vmovaps [rsp+0x70], xmm8
0000774654fd2371  vmovaps [rsp+0x80], xmm9
0000774654fd237a  vmovaps [rsp+0x90], xmm10
0000774654fd2383  vmovaps [rsp+0xA0], xmm11
0000774654fd238c  vmovaps [rsp+0xB0], xmm12
0000774654fd2395  vmovaps [rsp+0xC0], xmm13
0000774654fd239e  vmovaps [rsp+0xD0], xmm14
0000774654fd23a7  vmovaps [rsp+0xE0], xmm15
0000774654fd23b0  sub rsp, 0x40
0000774654fd23b4  lea rdi, [rsp]
0000774654fd23b8  lea rsi, [rsp+0x10]
0000774654fd23bd  lea rdx, [rsp+0x20]
0000774654fd23c2  lea rcx, [rsp+0x30]
0000774654fd23c7  mov r8d, 0x00
0000774654fd23cd  lea r9, [r15+0x3A8]
0000774654fd23d4  movaps [rdi], xmm6
0000774654fd23d7  movaps [rsi], xmm7
0000774654fd23da  movaps [rdx], xmm8
0000774654fd23de  movaps [rcx], xmm13
0000774654fd23e2  mov rax, 0x564E5D1DDA50
0000774654fd23ec  call rax
0000774654fd23ee  movaps xmm6, [rsp]
0000774654fd23f2  add rsp, 0x40
0000774654fd23f6  vmovaps xmm0, [rsp]
0000774654fd23fb  vmovaps xmm1, [rsp+0x10]
0000774654fd2401  vmovaps xmm2, [rsp+0x20]
0000774654fd2407  vmovaps xmm3, [rsp+0x30]
0000774654fd240d  vmovaps xmm4, [rsp+0x40]
0000774654fd2413  vmovaps xmm5, [rsp+0x50]
0000774654fd2419  vmovaps xmm7, [rsp+0x60]
0000774654fd241f  vmovaps xmm8, [rsp+0x70]
0000774654fd2425  vmovaps xmm9, [rsp+0x80]
0000774654fd242e  vmovaps xmm10, [rsp+0x90]
0000774654fd2437  vmovaps xmm11, [rsp+0xA0]
0000774654fd2440  vmovaps xmm12, [rsp+0xB0]
0000774654fd2449  vmovaps xmm13, [rsp+0xC0]
0000774654fd2452  vmovaps xmm14, [rsp+0xD0]
0000774654fd245b  vmovaps xmm15, [rsp+0xE0]
0000774654fd2464  add rsp, 0xF0
0000774654fd246b  pop r11
0000774654fd246d  pop r10
0000774654fd246f  pop r9
0000774654fd2471  pop r8
0000774654fd2473  pop rsi
0000774654fd2474  pop rdi
0000774654fd2475  pop rdx
0000774654fd2476  pop rcx
0000774654fd2477  pop rax
0000774654fd2478  add rsp, 0x08
0000774654fd247c  jmp 0x0000774654FCFE04
0000774654fd2481  sub rsp, 0x08
0000774654fd2485  push rax
0000774654fd2486  push rcx
0000774654fd2487  push rdx
0000774654fd2488  push rdi
0000774654fd2489  push rsi
0000774654fd248a  push r8
0000774654fd248c  push r9
0000774654fd248e  push r10
0000774654fd2490  push r11
0000774654fd2492  sub rsp, 0xF0
0000774654fd2499  vmovaps [rsp], xmm0
0000774654fd249e  vmovaps [rsp+0x10], xmm1
0000774654fd24a4  vmovaps [rsp+0x20], xmm2
0000774654fd24aa  vmovaps [rsp+0x30], xmm3
0000774654fd24b0  vmovaps [rsp+0x40], xmm4
0000774654fd24b6  vmovaps [rsp+0x50], xmm5
0000774654fd24bc  vmovaps [rsp+0x60], xmm6
0000774654fd24c2  vmovaps [rsp+0x70], xmm7
0000774654fd24c8  vmovaps [rsp+0x80], xmm9
0000774654fd24d1  vmovaps [rsp+0x90], xmm10
0000774654fd24da  vmovaps [rsp+0xA0], xmm11
0000774654fd24e3  vmovaps [rsp+0xB0], xmm12
0000774654fd24ec  vmovaps [rsp+0xC0], xmm13
0000774654fd24f5  vmovaps [rsp+0xD0], xmm14
0000774654fd24fe  vmovaps [rsp+0xE0], xmm15
0000774654fd2507  sub rsp, 0x40
0000774654fd250b  lea rdi, [rsp]
0000774654fd250f  lea rsi, [rsp+0x10]
0000774654fd2514  lea rdx, [rsp+0x20]
0000774654fd2519  lea rcx, [rsp+0x30]
0000774654fd251e  mov r8d, 0x00
0000774654fd2524  lea r9, [r15+0x3A8]
0000774654fd252b  movaps [rdi], xmm8
0000774654fd252f  movaps [rsi], xmm9
0000774654fd2533  movaps [rdx], xmm1
0000774654fd2536  movaps [rcx], xmm13
0000774654fd253a  mov rax, 0x564E5D1DDA50
0000774654fd2544  call rax
0000774654fd2546  movaps xmm8, [rsp]
0000774654fd254b  add rsp, 0x40
0000774654fd254f  vmovaps xmm0, [rsp]
0000774654fd2554  vmovaps xmm1, [rsp+0x10]
0000774654fd255a  vmovaps xmm2, [rsp+0x20]
0000774654fd2560  vmovaps xmm3, [rsp+0x30]
0000774654fd2566  vmovaps xmm4, [rsp+0x40]
0000774654fd256c  vmovaps xmm5, [rsp+0x50]
0000774654fd2572  vmovaps xmm6, [rsp+0x60]
0000774654fd2578  vmovaps xmm7, [rsp+0x70]
0000774654fd257e  vmovaps xmm9, [rsp+0x80]
0000774654fd2587  vmovaps xmm10, [rsp+0x90]
0000774654fd2590  vmovaps xmm11, [rsp+0xA0]
0000774654fd2599  vmovaps xmm12, [rsp+0xB0]
0000774654fd25a2  vmovaps xmm13, [rsp+0xC0]
0000774654fd25ab  vmovaps xmm14, [rsp+0xD0]
0000774654fd25b4  vmovaps xmm15, [rsp+0xE0]
0000774654fd25bd  add rsp, 0xF0
0000774654fd25c4  pop r11
0000774654fd25c6  pop r10
0000774654fd25c8  pop r9
0000774654fd25ca  pop r8
0000774654fd25cc  pop rsi
0000774654fd25cd  pop rdi
0000774654fd25ce  pop rdx
0000774654fd25cf  pop rcx
0000774654fd25d0  pop rax
0000774654fd25d1  add rsp, 0x08
0000774654fd25d5  jmp 0x0000774654FCFE2A
0000774654fd25da  sub rsp, 0x08
0000774654fd25de  push rax
0000774654fd25df  push rcx
0000774654fd25e0  push rdx
0000774654fd25e1  push rdi
0000774654fd25e2  push rsi
0000774654fd25e3  push r8
0000774654fd25e5  push r9
0000774654fd25e7  push r10
0000774654fd25e9  push r11
0000774654fd25eb  sub rsp, 0xF0
0000774654fd25f2  vmovaps [rsp], xmm0
0000774654fd25f7  vmovaps [rsp+0x10], xmm1
0000774654fd25fd  vmovaps [rsp+0x20], xmm2
0000774654fd2603  vmovaps [rsp+0x30], xmm3
0000774654fd2609  vmovaps [rsp+0x40], xmm4
0000774654fd260f  vmovaps [rsp+0x50], xmm5
0000774654fd2615  vmovaps [rsp+0x60], xmm6
0000774654fd261b  vmovaps [rsp+0x70], xmm7
0000774654fd2621  vmovaps [rsp+0x80], xmm8
0000774654fd262a  vmovaps [rsp+0x90], xmm9
0000774654fd2633  vmovaps [rsp+0xA0], xmm10
0000774654fd263c  vmovaps [rsp+0xB0], xmm11
0000774654fd2645  vmovaps [rsp+0xC0], xmm12
0000774654fd264e  vmovaps [rsp+0xD0], xmm14
0000774654fd2657  vmovaps [rsp+0xE0], xmm15
0000774654fd2660  sub rsp, 0x40
0000774654fd2664  lea rdi, [rsp]
0000774654fd2668  lea rsi, [rsp+0x10]
0000774654fd266d  lea rdx, [rsp+0x20]
0000774654fd2672  lea rcx, [rsp+0x30]
0000774654fd2677  mov r8d, 0x00
0000774654fd267d  lea r9, [r15+0x3A8]
0000774654fd2684  movaps [rdi], xmm13
0000774654fd2688  movaps [rsi], xmm11
0000774654fd268c  movaps [rdx], xmm12
0000774654fd2690  movaps [rcx], xmm1
0000774654fd2693  mov rax, 0x564E5D1DDA50
0000774654fd269d  call rax
0000774654fd269f  movaps xmm13, [rsp]
0000774654fd26a4  add rsp, 0x40
0000774654fd26a8  vmovaps xmm0, [rsp]
0000774654fd26ad  vmovaps xmm1, [rsp+0x10]
0000774654fd26b3  vmovaps xmm2, [rsp+0x20]
0000774654fd26b9  vmovaps xmm3, [rsp+0x30]
0000774654fd26bf  vmovaps xmm4, [rsp+0x40]
0000774654fd26c5  vmovaps xmm5, [rsp+0x50]
0000774654fd26cb  vmovaps xmm6, [rsp+0x60]
0000774654fd26d1  vmovaps xmm7, [rsp+0x70]
0000774654fd26d7  vmovaps xmm8, [rsp+0x80]
0000774654fd26e0  vmovaps xmm9, [rsp+0x90]
0000774654fd26e9  vmovaps xmm10, [rsp+0xA0]
0000774654fd26f2  vmovaps xmm11, [rsp+0xB0]
0000774654fd26fb  vmovaps xmm12, [rsp+0xC0]
0000774654fd2704  vmovaps xmm14, [rsp+0xD0]
0000774654fd270d  vmovaps xmm15, [rsp+0xE0]
0000774654fd2716  add rsp, 0xF0
0000774654fd271d  pop r11
0000774654fd271f  pop r10
0000774654fd2721  pop r9
0000774654fd2723  pop r8
0000774654fd2725  pop rsi
0000774654fd2726  pop rdi
0000774654fd2727  pop rdx
0000774654fd2728  pop rcx
0000774654fd2729  pop rax
0000774654fd272a  add rsp, 0x08
0000774654fd272e  jmp 0x0000774654FCFE50
0000774654fd2733  sub rsp, 0x08
0000774654fd2737  push rax
0000774654fd2738  push rcx
0000774654fd2739  push rdx
0000774654fd273a  push rdi
0000774654fd273b  push rsi
0000774654fd273c  push r8
0000774654fd273e  push r9
0000774654fd2740  push r10
0000774654fd2742  push r11
0000774654fd2744  sub rsp, 0xF0
0000774654fd274b  vmovaps [rsp], xmm0
0000774654fd2750  vmovaps [rsp+0x10], xmm1
0000774654fd2756  vmovaps [rsp+0x20], xmm2
0000774654fd275c  vmovaps [rsp+0x30], xmm3
0000774654fd2762  vmovaps [rsp+0x40], xmm4
0000774654fd2768  vmovaps [rsp+0x50], xmm5
0000774654fd276e  vmovaps [rsp+0x60], xmm6
0000774654fd2774  vmovaps [rsp+0x70], xmm7
0000774654fd277a  vmovaps [rsp+0x80], xmm8
0000774654fd2783  vmovaps [rsp+0x90], xmm9
0000774654fd278c  vmovaps [rsp+0xA0], xmm10
0000774654fd2795  vmovaps [rsp+0xB0], xmm11
0000774654fd279e  vmovaps [rsp+0xC0], xmm13
0000774654fd27a7  vmovaps [rsp+0xD0], xmm14
0000774654fd27b0  vmovaps [rsp+0xE0], xmm15
0000774654fd27b9  sub rsp, 0x40
0000774654fd27bd  lea rdi, [rsp]
0000774654fd27c1  lea rsi, [rsp+0x10]
0000774654fd27c6  lea rdx, [rsp+0x20]
0000774654fd27cb  lea rcx, [rsp+0x30]
0000774654fd27d0  mov r8d, 0x00
0000774654fd27d6  lea r9, [r15+0x3A8]
0000774654fd27dd  movaps [rdi], xmm12
0000774654fd27e1  movaps [rsi], xmm10
0000774654fd27e5  movaps [rdx], xmm14
0000774654fd27e9  movaps [rcx], xmm1
0000774654fd27ec  mov rax, 0x564E5D1DDA50
0000774654fd27f6  call rax
0000774654fd27f8  movaps xmm12, [rsp]
0000774654fd27fd  add rsp, 0x40
0000774654fd2801  vmovaps xmm0, [rsp]
0000774654fd2806  vmovaps xmm1, [rsp+0x10]
0000774654fd280c  vmovaps xmm2, [rsp+0x20]
0000774654fd2812  vmovaps xmm3, [rsp+0x30]
0000774654fd2818  vmovaps xmm4, [rsp+0x40]
0000774654fd281e  vmovaps xmm5, [rsp+0x50]
0000774654fd2824  vmovaps xmm6, [rsp+0x60]
0000774654fd282a  vmovaps xmm7, [rsp+0x70]
0000774654fd2830  vmovaps xmm8, [rsp+0x80]
0000774654fd2839  vmovaps xmm9, [rsp+0x90]
0000774654fd2842  vmovaps xmm10, [rsp+0xA0]
0000774654fd284b  vmovaps xmm11, [rsp+0xB0]
0000774654fd2854  vmovaps xmm13, [rsp+0xC0]
0000774654fd285d  vmovaps xmm14, [rsp+0xD0]
0000774654fd2866  vmovaps xmm15, [rsp+0xE0]
0000774654fd286f  add rsp, 0xF0
0000774654fd2876  pop r11
0000774654fd2878  pop r10
0000774654fd287a  pop r9
0000774654fd287c  pop r8
0000774654fd287e  pop rsi
0000774654fd287f  pop rdi
0000774654fd2880  pop rdx
0000774654fd2881  pop rcx
0000774654fd2882  pop rax
0000774654fd2883  add rsp, 0x08
0000774654fd2887  jmp 0x0000774654FCFE76
0000774654fd288c  call 0x0000774654DFF430
0000774654fd2891  jmp 0x0000774654FCFE83
0000774654fd2896  call 0x0000774654E0D4E0
0000774654fd289b  jmp 0x0000774654FCFE90
0000774654fd28a0  sub rsp, 0x08
0000774654fd28a4  push rax
0000774654fd28a5  push rcx
0000774654fd28a6  push rdx
0000774654fd28a7  push rdi
0000774654fd28a8  push rsi
0000774654fd28a9  push r8
0000774654fd28ab  push r9
0000774654fd28ad  push r10
0000774654fd28af  push r11
0000774654fd28b1  sub rsp, 0xF0
0000774654fd28b8  vmovaps [rsp], xmm0
0000774654fd28bd  vmovaps [rsp+0x10], xmm1
0000774654fd28c3  vmovaps [rsp+0x20], xmm2
0000774654fd28c9  vmovaps [rsp+0x30], xmm3
0000774654fd28cf  vmovaps [rsp+0x40], xmm4
0000774654fd28d5  vmovaps [rsp+0x50], xmm5
0000774654fd28db  vmovaps [rsp+0x60], xmm6
0000774654fd28e1  vmovaps [rsp+0x70], xmm7
0000774654fd28e7  vmovaps [rsp+0x80], xmm8
0000774654fd28f0  vmovaps [rsp+0x90], xmm9
0000774654fd28f9  vmovaps [rsp+0xA0], xmm11
0000774654fd2902  vmovaps [rsp+0xB0], xmm12
0000774654fd290b  vmovaps [rsp+0xC0], xmm13
0000774654fd2914  vmovaps [rsp+0xD0], xmm14
0000774654fd291d  vmovaps [rsp+0xE0], xmm15
0000774654fd2926  sub rsp, 0x40
0000774654fd292a  lea rdi, [rsp]
0000774654fd292e  lea rsi, [rsp+0x10]
0000774654fd2933  lea rdx, [rsp+0x20]
0000774654fd2938  lea rcx, [rsp+0x30]
0000774654fd293d  mov r8d, 0x00
0000774654fd2943  lea r9, [r15+0x3A8]
0000774654fd294a  movaps [rdi], xmm10
0000774654fd294e  movaps [rsi], xmm6
0000774654fd2951  movaps [rdx], xmm15
0000774654fd2955  movaps [rcx], xmm11
0000774654fd2959  mov rax, 0x564E5D1DDA50
0000774654fd2963  call rax
0000774654fd2965  movaps xmm10, [rsp]
0000774654fd296a  add rsp, 0x40
0000774654fd296e  vmovaps xmm0, [rsp]
0000774654fd2973  vmovaps xmm1, [rsp+0x10]
0000774654fd2979  vmovaps xmm2, [rsp+0x20]
0000774654fd297f  vmovaps xmm3, [rsp+0x30]
0000774654fd2985  vmovaps xmm4, [rsp+0x40]
0000774654fd298b  vmovaps xmm5, [rsp+0x50]
0000774654fd2991  vmovaps xmm6, [rsp+0x60]
0000774654fd2997  vmovaps xmm7, [rsp+0x70]
0000774654fd299d  vmovaps xmm8, [rsp+0x80]
0000774654fd29a6  vmovaps xmm9, [rsp+0x90]
0000774654fd29af  vmovaps xmm11, [rsp+0xA0]
0000774654fd29b8  vmovaps xmm12, [rsp+0xB0]
0000774654fd29c1  vmovaps xmm13, [rsp+0xC0]
0000774654fd29ca  vmovaps xmm14, [rsp+0xD0]
0000774654fd29d3  vmovaps xmm15, [rsp+0xE0]
0000774654fd29dc  add rsp, 0xF0
0000774654fd29e3  pop r11
0000774654fd29e5  pop r10
0000774654fd29e7  pop r9
0000774654fd29e9  pop r8
0000774654fd29eb  pop rsi
0000774654fd29ec  pop rdi
0000774654fd29ed  pop rdx
0000774654fd29ee  pop rcx
0000774654fd29ef  pop rax
0000774654fd29f0  add rsp, 0x08
0000774654fd29f4  jmp 0x0000774654FCFEC9
0000774654fd29f9  call 0x0000774654E0E760
0000774654fd29fe  jmp 0x0000774654FCFEDB
0000774654fd2a03  sub rsp, 0x08
0000774654fd2a07  push rax
0000774654fd2a08  push rcx
0000774654fd2a09  push rdx
0000774654fd2a0a  push rdi
0000774654fd2a0b  push rsi
0000774654fd2a0c  push r8
0000774654fd2a0e  push r9
0000774654fd2a10  push r10
0000774654fd2a12  push r11
0000774654fd2a14  sub rsp, 0xF0
0000774654fd2a1b  vmovaps [rsp], xmm0
0000774654fd2a20  vmovaps [rsp+0x10], xmm1
0000774654fd2a26  vmovaps [rsp+0x20], xmm2
0000774654fd2a2c  vmovaps [rsp+0x30], xmm3
0000774654fd2a32  vmovaps [rsp+0x40], xmm4
0000774654fd2a38  vmovaps [rsp+0x50], xmm5
0000774654fd2a3e  vmovaps [rsp+0x60], xmm6
0000774654fd2a44  vmovaps [rsp+0x70], xmm7
0000774654fd2a4a  vmovaps [rsp+0x80], xmm8
0000774654fd2a53  vmovaps [rsp+0x90], xmm10
0000774654fd2a5c  vmovaps [rsp+0xA0], xmm11
0000774654fd2a65  vmovaps [rsp+0xB0], xmm12
0000774654fd2a6e  vmovaps [rsp+0xC0], xmm13
0000774654fd2a77  vmovaps [rsp+0xD0], xmm14
0000774654fd2a80  vmovaps [rsp+0xE0], xmm15
0000774654fd2a89  sub rsp, 0x40
0000774654fd2a8d  lea rdi, [rsp]
0000774654fd2a91  lea rsi, [rsp+0x10]
0000774654fd2a96  lea rdx, [rsp+0x20]
0000774654fd2a9b  lea rcx, [rsp+0x30]
0000774654fd2aa0  mov r8d, 0x00
0000774654fd2aa6  lea r9, [r15+0x3A8]
0000774654fd2aad  movaps [rdi], xmm9
0000774654fd2ab1  movaps [rsi], xmm8
0000774654fd2ab5  movaps [rdx], xmm14
0000774654fd2ab9  movaps [rcx], xmm11
0000774654fd2abd  mov rax, 0x564E5D1DDA50
0000774654fd2ac7  call rax
0000774654fd2ac9  movaps xmm9, [rsp]
0000774654fd2ace  add rsp, 0x40
0000774654fd2ad2  vmovaps xmm0, [rsp]
0000774654fd2ad7  vmovaps xmm1, [rsp+0x10]
0000774654fd2add  vmovaps xmm2, [rsp+0x20]
0000774654fd2ae3  vmovaps xmm3, [rsp+0x30]
0000774654fd2ae9  vmovaps xmm4, [rsp+0x40]
0000774654fd2aef  vmovaps xmm5, [rsp+0x50]
0000774654fd2af5  vmovaps xmm6, [rsp+0x60]
0000774654fd2afb  vmovaps xmm7, [rsp+0x70]
0000774654fd2b01  vmovaps xmm8, [rsp+0x80]
0000774654fd2b0a  vmovaps xmm10, [rsp+0x90]
0000774654fd2b13  vmovaps xmm11, [rsp+0xA0]
0000774654fd2b1c  vmovaps xmm12, [rsp+0xB0]
0000774654fd2b25  vmovaps xmm13, [rsp+0xC0]
0000774654fd2b2e  vmovaps xmm14, [rsp+0xD0]
0000774654fd2b37  vmovaps xmm15, [rsp+0xE0]
0000774654fd2b40  add rsp, 0xF0
0000774654fd2b47  pop r11
0000774654fd2b49  pop r10
0000774654fd2b4b  pop r9
0000774654fd2b4d  pop r8
0000774654fd2b4f  pop rsi
0000774654fd2b50  pop rdi
0000774654fd2b51  pop rdx
0000774654fd2b52  pop rcx
0000774654fd2b53  pop rax
0000774654fd2b54  add rsp, 0x08
0000774654fd2b58  jmp 0x0000774654FCFF0C
0000774654fd2b5d  sub rsp, 0x08
0000774654fd2b61  push rax
0000774654fd2b62  push rcx
0000774654fd2b63  push rdx
0000774654fd2b64  push rdi
0000774654fd2b65  push rsi
0000774654fd2b66  push r8
0000774654fd2b68  push r9
0000774654fd2b6a  push r10
0000774654fd2b6c  push r11
0000774654fd2b6e  sub rsp, 0xF0
0000774654fd2b75  vmovaps [rsp], xmm0
0000774654fd2b7a  vmovaps [rsp+0x10], xmm1
0000774654fd2b80  vmovaps [rsp+0x20], xmm2
0000774654fd2b86  vmovaps [rsp+0x30], xmm3
0000774654fd2b8c  vmovaps [rsp+0x40], xmm4
0000774654fd2b92  vmovaps [rsp+0x50], xmm5
0000774654fd2b98  vmovaps [rsp+0x60], xmm6
0000774654fd2b9e  vmovaps [rsp+0x70], xmm7
0000774654fd2ba4  vmovaps [rsp+0x80], xmm8
0000774654fd2bad  vmovaps [rsp+0x90], xmm9
0000774654fd2bb6  vmovaps [rsp+0xA0], xmm10
0000774654fd2bbf  vmovaps [rsp+0xB0], xmm12
0000774654fd2bc8  vmovaps [rsp+0xC0], xmm13
0000774654fd2bd1  vmovaps [rsp+0xD0], xmm14
0000774654fd2bda  vmovaps [rsp+0xE0], xmm15
0000774654fd2be3  sub rsp, 0x40
0000774654fd2be7  lea rdi, [rsp]
0000774654fd2beb  lea rsi, [rsp+0x10]
0000774654fd2bf0  lea rdx, [rsp+0x20]
0000774654fd2bf5  lea rcx, [rsp+0x30]
0000774654fd2bfa  mov r8d, 0x00
0000774654fd2c00  lea r9, [r15+0x3A8]
0000774654fd2c07  movaps [rdi], xmm11
0000774654fd2c0b  movaps [rsi], xmm13
0000774654fd2c0f  movaps [rdx], xmm1
0000774654fd2c12  movaps [rcx], xmm14
0000774654fd2c16  mov rax, 0x564E5D1DDA50
0000774654fd2c20  call rax
0000774654fd2c22  movaps xmm11, [rsp]
0000774654fd2c27  add rsp, 0x40
0000774654fd2c2b  vmovaps xmm0, [rsp]
0000774654fd2c30  vmovaps xmm1, [rsp+0x10]
0000774654fd2c36  vmovaps xmm2, [rsp+0x20]
0000774654fd2c3c  vmovaps xmm3, [rsp+0x30]
0000774654fd2c42  vmovaps xmm4, [rsp+0x40]
0000774654fd2c48  vmovaps xmm5, [rsp+0x50]
0000774654fd2c4e  vmovaps xmm6, [rsp+0x60]
0000774654fd2c54  vmovaps xmm7, [rsp+0x70]
0000774654fd2c5a  vmovaps xmm8, [rsp+0x80]
0000774654fd2c63  vmovaps xmm9, [rsp+0x90]
0000774654fd2c6c  vmovaps xmm10, [rsp+0xA0]
0000774654fd2c75  vmovaps xmm12, [rsp+0xB0]
0000774654fd2c7e  vmovaps xmm13, [rsp+0xC0]
0000774654fd2c87  vmovaps xmm14, [rsp+0xD0]
0000774654fd2c90  vmovaps xmm15, [rsp+0xE0]
0000774654fd2c99  add rsp, 0xF0
0000774654fd2ca0  pop r11
0000774654fd2ca2  pop r10
0000774654fd2ca4  pop r9
0000774654fd2ca6  pop r8
0000774654fd2ca8  pop rsi
0000774654fd2ca9  pop rdi
0000774654fd2caa  pop rdx
0000774654fd2cab  pop rcx
0000774654fd2cac  pop rax
0000774654fd2cad  add rsp, 0x08
0000774654fd2cb1  jmp 0x0000774654FCFF3D
0000774654fd2cb6  sub rsp, 0x08
0000774654fd2cba  push rax
0000774654fd2cbb  push rcx
0000774654fd2cbc  push rdx
0000774654fd2cbd  push rdi
0000774654fd2cbe  push rsi
0000774654fd2cbf  push r8
0000774654fd2cc1  push r9
0000774654fd2cc3  push r10
0000774654fd2cc5  push r11
0000774654fd2cc7  sub rsp, 0xF0
0000774654fd2cce  vmovaps [rsp], xmm0
0000774654fd2cd3  vmovaps [rsp+0x10], xmm1
0000774654fd2cd9  vmovaps [rsp+0x20], xmm2
0000774654fd2cdf  vmovaps [rsp+0x30], xmm3
0000774654fd2ce5  vmovaps [rsp+0x40], xmm4
0000774654fd2ceb  vmovaps [rsp+0x50], xmm5
0000774654fd2cf1  vmovaps [rsp+0x60], xmm6
0000774654fd2cf7  vmovaps [rsp+0x70], xmm7
0000774654fd2cfd  vmovaps [rsp+0x80], xmm8
0000774654fd2d06  vmovaps [rsp+0x90], xmm9
0000774654fd2d0f  vmovaps [rsp+0xA0], xmm10
0000774654fd2d18  vmovaps [rsp+0xB0], xmm11
0000774654fd2d21  vmovaps [rsp+0xC0], xmm12
0000774654fd2d2a  vmovaps [rsp+0xD0], xmm13
0000774654fd2d33  vmovaps [rsp+0xE0], xmm15
0000774654fd2d3c  sub rsp, 0x40
0000774654fd2d40  lea rdi, [rsp]
0000774654fd2d44  lea rsi, [rsp+0x10]
0000774654fd2d49  lea rdx, [rsp+0x20]
0000774654fd2d4e  lea rcx, [rsp+0x30]
0000774654fd2d53  mov r8d, 0x00
0000774654fd2d59  lea r9, [r15+0x3A8]
0000774654fd2d60  movaps [rdi], xmm14
0000774654fd2d64  movaps [rsi], xmm12
0000774654fd2d68  movaps [rdx], xmm15
0000774654fd2d6c  movaps [rcx], xmm1
0000774654fd2d6f  mov rax, 0x564E5D1DDA50
0000774654fd2d79  call rax
0000774654fd2d7b  movaps xmm14, [rsp]
0000774654fd2d80  add rsp, 0x40
0000774654fd2d84  vmovaps xmm0, [rsp]
0000774654fd2d89  vmovaps xmm1, [rsp+0x10]
0000774654fd2d8f  vmovaps xmm2, [rsp+0x20]
0000774654fd2d95  vmovaps xmm3, [rsp+0x30]
0000774654fd2d9b  vmovaps xmm4, [rsp+0x40]
0000774654fd2da1  vmovaps xmm5, [rsp+0x50]
0000774654fd2da7  vmovaps xmm6, [rsp+0x60]
0000774654fd2dad  vmovaps xmm7, [rsp+0x70]
0000774654fd2db3  vmovaps xmm8, [rsp+0x80]
0000774654fd2dbc  vmovaps xmm9, [rsp+0x90]
0000774654fd2dc5  vmovaps xmm10, [rsp+0xA0]
0000774654fd2dce  vmovaps xmm11, [rsp+0xB0]
0000774654fd2dd7  vmovaps xmm12, [rsp+0xC0]
0000774654fd2de0  vmovaps xmm13, [rsp+0xD0]
0000774654fd2de9  vmovaps xmm15, [rsp+0xE0]
0000774654fd2df2  add rsp, 0xF0
0000774654fd2df9  pop r11
0000774654fd2dfb  pop r10
0000774654fd2dfd  pop r9
0000774654fd2dff  pop r8
0000774654fd2e01  pop rsi
0000774654fd2e02  pop rdi
0000774654fd2e03  pop rdx
0000774654fd2e04  pop rcx
0000774654fd2e05  pop rax
0000774654fd2e06  add rsp, 0x08
0000774654fd2e0a  jmp 0x0000774654FCFF6E
0000774654fd2e0f  call 0x0000774654E079B0
0000774654fd2e14  jmp 0x0000774654FCFF81
0000774654fd2e19  call 0x0000774654E09E90
0000774654fd2e1e  jmp 0x0000774654FCFF8C
0000774654fd2e23  call 0x0000774654E08C20
0000774654fd2e28  jmp 0x0000774654FCFF97
0000774654fd2e2d  call 0x0000774654E0D600
0000774654fd2e32  jmp 0x0000774654FCFFA2
0000774654fd2e37  int3
0000774654fd2e38  nop [rax+rax*1], eax
0000774654fd2e40  mov rax, [r15+0x40]
0000774654fd2e44  mov r14, [r15+0x58]
0000774654fd2e48  lea r12, [rax+r14*1]
0000774654fd2e4c  vxorps xmm1, xmm1, xmm1
0000774654fd2e50  vpbroadcastq xmm1, xmm1
0000774654fd2e55  vxorps xmm15, xmm15, xmm15
0000774654fd2e5a  vpbroadcastq xmm15, xmm15
0000774654fd2e5f  lea rax, [r12+0x30]
0000774654fd2e64  mov r11, [r13+rax*1]
0000774654fd2e69  lea rax, [r12+0x38]
0000774654fd2e6e  mov r10, [r13+rax*1]
0000774654fd2e73  movq xmm14, r11
0000774654fd2e78  movq xmm13, r10
0000774654fd2e7d  movq xmm14, xmm14
0000774654fd2e82  movq xmm13, xmm13
0000774654fd2e87  vmovaps [rsp+0x10], xmm13
0000774654fd2e8d  movq xmm13, xmm13
0000774654fd2e92  movaps [r15+0x270], xmm13
0000774654fd2e9a  movaps xmm13, [r15+0x160]
0000774654fd2ea2  vmovaps [rsp+0x20], xmm13
0000774654fd2ea8  vmovaps xmm12, [rsp+0x20]
0000774654fd2eae  por xmm13, xmm12
0000774654fd2eb3  lea rax, [r12+0x20]
0000774654fd2eb8  mov r11, [r13+rax*1]
0000774654fd2ebd  lea rax, [r12+0x28]
0000774654fd2ec2  mov r10, [r13+rax*1]
0000774654fd2ec7  movq xmm12, r11
0000774654fd2ecc  movq xmm11, r10
0000774654fd2ed1  movq xmm12, xmm12
0000774654fd2ed6  movq xmm11, xmm11
0000774654fd2edb  movaps xmm10, [r15+0x2F0]
0000774654fd2ee3  vmovaps [rsp+0x20], xmm10
0000774654fd2ee9  vmovaps xmm9, [rsp+0x20]
0000774654fd2eef  por xmm10, xmm9
0000774654fd2ef4  movaps xmm9, [r15+0x2D0]
0000774654fd2efc  vmovaps [rsp+0x20], xmm9
0000774654fd2f02  vmovaps xmm8, [rsp+0x20]
0000774654fd2f08  por xmm9, xmm8
0000774654fd2f0d  movaps xmm8, [r15+0x300]
0000774654fd2f15  vmovaps [rsp+0x20], xmm8
0000774654fd2f1b  vmovaps xmm7, [rsp+0x20]
0000774654fd2f21  por xmm8, xmm7
0000774654fd2f26  movaps xmm7, [r15+0x2B0]
0000774654fd2f2e  vmovaps [rsp+0x20], xmm7
0000774654fd2f34  vmovaps xmm6, [rsp+0x20]
0000774654fd2f3a  por xmm7, xmm6
0000774654fd2f3e  movaps xmm6, [r15+0x180]
0000774654fd2f46  vmovaps [rsp+0x20], xmm6
0000774654fd2f4c  vmovaps xmm5, [rsp+0x20]
0000774654fd2f52  por xmm6, xmm5
0000774654fd2f56  lea rax, [r12+0x10]
0000774654fd2f5b  mov r11, [r13+rax*1]
0000774654fd2f60  lea rax, [r12+0x18]
0000774654fd2f65  mov r10, [r13+rax*1]
0000774654fd2f6a  movq xmm5, r11
0000774654fd2f6f  movq xmm4, r10
0000774654fd2f74  movq xmm5, xmm5
0000774654fd2f78  movq xmm4, xmm4
0000774654fd2f7c  movaps xmm3, [r15+0x200]
0000774654fd2f84  vmovaps [rsp+0x20], xmm3
0000774654fd2f8a  vmovaps xmm2, [rsp+0x20]
0000774654fd2f90  por xmm3, xmm2
0000774654fd2f94  movaps xmm2, [r15+0x1F0]
0000774654fd2f9c  vmovaps [rsp+0x20], xmm2
0000774654fd2fa2  vmovaps [rsp+0x30], xmm1
0000774654fd2fa8  vmovaps xmm1, [rsp+0x20]
0000774654fd2fae  por xmm2, xmm1
0000774654fd2fb2  movaps xmm1, [r15+0x2E0]
0000774654fd2fba  vmovaps [rsp+0x20], xmm1
0000774654fd2fc0  vmovaps [rsp+0x40], xmm15
0000774654fd2fc6  vmovaps xmm15, [rsp+0x20]
0000774654fd2fcc  por xmm1, xmm15
0000774654fd2fd1  movaps xmm15, [r15+0x2A0]
0000774654fd2fd9  vmovaps [rsp+0x20], xmm15
0000774654fd2fdf  vmovaps [rsp+0x50], xmm1
0000774654fd2fe5  vmovaps xmm1, [rsp+0x20]
0000774654fd2feb  por xmm15, xmm1
0000774654fd2ff0  movaps xmm1, [r15+0x280]
0000774654fd2ff8  vmovaps [rsp+0x20], xmm1
0000774654fd2ffe  vmovaps [rsp+0x60], xmm15
0000774654fd3004  vmovaps xmm15, [rsp+0x20]
0000774654fd300a  por xmm1, xmm15
0000774654fd300f  movaps xmm15, [r15+0x1C0]
0000774654fd3017  vmovaps [rsp+0x20], xmm15
0000774654fd301d  vmovaps [rsp+0x70], xmm1
0000774654fd3023  vmovaps xmm1, [rsp+0x20]
0000774654fd3029  por xmm15, xmm1
0000774654fd302e  movaps xmm1, [r15+0x210]
0000774654fd3036  vmovaps [rsp+0x20], xmm1
0000774654fd303c  vmovaps [rsp+0x80], xmm15
0000774654fd3045  vmovaps xmm15, [rsp+0x20]
0000774654fd304b  por xmm1, xmm15
0000774654fd3050  mov rax, [r13+r12*1]
0000774654fd3055  vmovq xmm15, rax
0000774654fd305a  vpbroadcastq xmm15, xmm15
0000774654fd305f  vmovaps [rsp+0x20], xmm1
0000774654fd3065  vxorps xmm1, xmm1, xmm1
0000774654fd3069  vpbroadcastq xmm1, xmm1
0000774654fd306e  mov rax, [r15+0xF8]
0000774654fd3075  vmovaps [rsp+0x90], xmm1
0000774654fd307e  movups xmm1, [r13+rax*1]
0000774654fd3084  vmovaps [rsp+0xA0], xmm1
0000774654fd308d  vxorps xmm1, xmm1, xmm1
0000774654fd3091  vpbroadcastq xmm1, xmm1
0000774654fd3096  lea r11, [r12+0x08]
0000774654fd309b  mov r12, [r13+r11*1]
0000774654fd30a0  vmovaps [rsp+0xB0], xmm1
0000774654fd30a9  movq xmm1, r12
0000774654fd30ae  movaps [r15+0x240], xmm1
0000774654fd30b6  mov r12, [r15+0x50]
0000774654fd30ba  lea r11, [r12+r14*1]
0000774654fd30be  mov [r15+0x60], r11
0000774654fd30c2  lea r12, [r14+0x40]
0000774654fd30c6  mov [r15+0x58], r12
0000774654fd30ca  vmovaps xmm1, [rsp+0x30]
0000774654fd30d0  vmovaps [rsp+0x30], xmm15
0000774654fd30d6  vmovaps xmm15, [rsp+0xA0]
0000774654fd30df  vmovaps [rsp+0xA0], xmm14
0000774654fd30e8  vmovaps xmm14, [rsp+0x30]
0000774654fd30ee  vmovaps [rsp+0x30], xmm13
0000774654fd30f4  vmovaps [rsp+0xC0], xmm12
0000774654fd30fd  movaps xmm13, xmm1
0000774654fd3101  vfmadd231pd xmm13, xmm15, xmm14
0000774654fd3106  vcmppd xmm12, xmm13, xmm13, 0x03
0000774654fd310c  vptest xmm12, xmm12
0000774654fd3111  jnz 0x0000774654FD3BEA
0000774654fd3117  movaps xmm1, [r15+0x250]
0000774654fd311f  vmovaps xmm15, [rsp+0x40]
0000774654fd3125  vmovaps [rsp+0x40], xmm13
0000774654fd312b  movaps xmm12, xmm15
0000774654fd312f  vfmadd231pd xmm12, xmm1, xmm14
0000774654fd3134  vcmppd xmm13, xmm12, xmm12, 0x03
0000774654fd313a  vptest xmm13, xmm13
0000774654fd313f  jnz 0x0000774654FD3D43
0000774654fd3145  movaps xmm15, [r15+0x1E0]
0000774654fd314d  vmovaps [rsp+0xD0], xmm15
0000774654fd3156  vmovaps xmm13, [rsp+0xD0]
0000774654fd315f  por xmm15, xmm13
0000774654fd3164  movaps xmm13, [r15+0x1D0]
0000774654fd316c  vmovaps [rsp+0xD0], xmm13
0000774654fd3175  vmovaps [rsp+0xE0], xmm1
0000774654fd317e  vmovaps xmm1, [rsp+0xD0]
0000774654fd3187  por xmm13, xmm1
0000774654fd318c  movaps xmm1, [r15+0x2C0]
0000774654fd3194  vmovaps [rsp+0xD0], xmm1
0000774654fd319d  vmovaps [rsp+0xF0], xmm15
0000774654fd31a6  vmovaps xmm15, [rsp+0xD0]
0000774654fd31af  por xmm1, xmm15
0000774654fd31b4  movaps xmm15, [r15+0x290]
0000774654fd31bc  vmovaps [rsp+0xD0], xmm15
0000774654fd31c5  vmovaps [rsp+0x100], xmm1
0000774654fd31ce  vmovaps xmm1, [rsp+0xD0]
0000774654fd31d7  por xmm15, xmm1
0000774654fd31dc  movaps xmm1, [r15+0x260]
0000774654fd31e4  vmovaps [rsp+0xD0], xmm1
0000774654fd31ed  vmovaps [rsp+0x110], xmm15
0000774654fd31f6  vmovaps xmm15, [rsp+0xD0]
0000774654fd31ff  por xmm1, xmm15
0000774654fd3204  vmovaps xmm15, [rsp+0xE0]
0000774654fd320d  vmovaps [rsp+0xD0], xmm1
0000774654fd3216  vmovaps xmm1, [rsp+0xE0]
0000774654fd321f  por xmm15, xmm1
0000774654fd3224  lea r14, [rax+0xC0]
0000774654fd322b  movups xmm1, [r13+r14*1]
0000774654fd3231  mov [rsp+0xE0], rax
0000774654fd3239  xor eax, eax
0000774654fd323b  mov r14d, 0x200
0000774654fd3241  cmp r12, r14
0000774654fd3244  cmc
0000774654fd3245  lahf
0000774654fd3246  seto al
0000774654fd3249  mov [r15+0x108], eax
0000774654fd3250  vmovaps [rsp+0x120], xmm1
0000774654fd3259  vmovaps xmm1, [rsp+0x90]
0000774654fd3262  vmovaps [rsp+0x90], xmm15
0000774654fd326b  vmovaps xmm15, [rsp+0x120]
0000774654fd3274  vmovaps [rsp+0x120], xmm13
0000774654fd327d  vmovaps [rsp+0x130], xmm12
0000774654fd3286  movaps xmm13, xmm1
0000774654fd328a  vfmadd231pd xmm13, xmm15, xmm14
0000774654fd328f  vcmppd xmm12, xmm13, xmm13, 0x03
0000774654fd3295  vptest xmm12, xmm12
0000774654fd329a  jnz 0x0000774654FD3EA6
0000774654fd32a0  mov rax, [rsp+0xE0]
0000774654fd32a8  lea r14, [rax+0xB0]
0000774654fd32af  movups xmm1, [r13+r14*1]
0000774654fd32b5  vmovaps xmm15, [rsp+0xB0]
0000774654fd32be  vmovaps [rsp+0xB0], xmm13
0000774654fd32c7  movaps xmm12, xmm15
0000774654fd32cb  vfmadd231pd xmm12, xmm1, xmm14
0000774654fd32d0  vcmppd xmm13, xmm12, xmm12, 0x03
0000774654fd32d6  vptest xmm13, xmm13
0000774654fd32db  jnz 0x0000774654FD4009
0000774654fd32e1  vmovaps xmm1, [rsp+0x20]
0000774654fd32e7  vmovaps xmm15, [rsp+0x20]
0000774654fd32ed  por xmm1, xmm15
0000774654fd32f2  movaps [r15+0x210], xmm1
0000774654fd32fa  vmovaps xmm15, [rsp+0x80]
0000774654fd3303  vmovaps xmm14, [rsp+0x80]
0000774654fd330c  por xmm15, xmm14
0000774654fd3311  movaps [r15+0x1C0], xmm15
0000774654fd3319  vmovaps xmm14, [rsp+0x70]
0000774654fd331f  vmovaps xmm13, [rsp+0x70]
0000774654fd3325  por xmm14, xmm13
0000774654fd332a  movaps [r15+0x280], xmm14
0000774654fd3332  vmovaps xmm13, [rsp+0x60]
0000774654fd3338  vmovaps [rsp+0x20], xmm1
0000774654fd333e  vmovaps xmm1, [rsp+0x60]
0000774654fd3344  por xmm13, xmm1
0000774654fd3349  movaps [r15+0x2A0], xmm13
0000774654fd3351  vmovaps xmm1, [rsp+0x50]
0000774654fd3357  vmovaps [rsp+0x60], xmm15
0000774654fd335d  vmovaps xmm15, [rsp+0x50]
0000774654fd3363  por xmm1, xmm15
0000774654fd3368  movaps [r15+0x2E0], xmm1
0000774654fd3370  vmovaps [rsp+0x50], xmm2
0000774654fd3376  vmovaps xmm15, [rsp+0x50]
0000774654fd337c  por xmm2, xmm15
0000774654fd3381  movaps [r15+0x1F0], xmm2
0000774654fd3389  vmovaps xmm15, [rsp+0x90]
0000774654fd3392  vmovaps [rsp+0x50], xmm1
0000774654fd3398  vmovaps xmm1, [rsp+0x90]
0000774654fd33a1  por xmm15, xmm1
0000774654fd33a6  movaps [r15+0x250], xmm15
0000774654fd33ae  vmovaps xmm1, [rsp+0xD0]
0000774654fd33b7  vmovaps xmm15, [rsp+0xD0]
0000774654fd33c0  por xmm1, xmm15
0000774654fd33c5  movaps [r15+0x260], xmm1
0000774654fd33cd  vmovaps xmm15, [rsp+0x110]
0000774654fd33d6  vmovaps [rsp+0x70], xmm1
0000774654fd33dc  vmovaps xmm1, [rsp+0x110]
0000774654fd33e5  por xmm15, xmm1
0000774654fd33ea  movaps [r15+0x290], xmm15
0000774654fd33f2  vmovaps xmm1, [rsp+0x100]
0000774654fd33fb  vmovaps [rsp+0x80], xmm15
0000774654fd3404  vmovaps xmm15, [rsp+0x100]
0000774654fd340d  por xmm1, xmm15
0000774654fd3412  movaps [r15+0x2C0], xmm1
0000774654fd341a  movq xmm15, qword ptr [r15+0x240]
0000774654fd3423  vmovaps [rsp+0x90], xmm15
0000774654fd342c  vpermilpd xmm15, xmm15, 0x00
0000774654fd3432  vmovaps [rsp+0xD0], xmm1
0000774654fd343b  vmovaps xmm1, [rsp+0x40]
0000774654fd3441  vmovaps [rsp+0x40], xmm15
0000774654fd3447  vmovaps xmm15, [rsp+0x20]
0000774654fd344d  vmovaps [rsp+0x20], xmm14
0000774654fd3453  vmovaps xmm14, [rsp+0x40]
0000774654fd3459  vmovaps [rsp+0x40], xmm13
0000774654fd345f  vmovaps [rsp+0xE0], xmm12
0000774654fd3468  movaps xmm13, xmm1
0000774654fd346c  vfmadd231pd xmm13, xmm15, xmm14
0000774654fd3471  vcmppd xmm12, xmm13, xmm13, 0x03
0000774654fd3477  vptest xmm12, xmm12
0000774654fd347c  jnz 0x0000774654FD4162
0000774654fd3482  vmovaps xmm1, [rsp+0x90]
0000774654fd348b  vpermilpd xmm1, xmm1, 0x00
0000774654fd3491  vmovaps xmm15, [rsp+0xB0]
0000774654fd349a  vmovaps xmm14, [rsp+0x50]
0000774654fd34a0  vmovaps [rsp+0x50], xmm13
0000774654fd34a6  movaps xmm12, xmm15
0000774654fd34aa  vfmadd231pd xmm12, xmm14, xmm1
0000774654fd34af  vcmppd xmm13, xmm12, xmm12, 0x03
0000774654fd34b5  vptest xmm13, xmm13
0000774654fd34ba  jnz 0x0000774654FD42BB
0000774654fd34c0  vmovaps xmm1, [rsp+0x90]
0000774654fd34c9  vpermilpd xmm1, xmm1, 0x00
0000774654fd34cf  vmovaps xmm15, [rsp+0x130]
0000774654fd34d8  vmovaps xmm14, [rsp+0x60]
0000774654fd34de  vmovaps [rsp+0x60], xmm12
0000774654fd34e4  movaps xmm13, xmm15
0000774654fd34e8  vfmadd231pd xmm13, xmm14, xmm1
0000774654fd34ed  vcmppd xmm12, xmm13, xmm13, 0x03
0000774654fd34f3  vptest xmm12, xmm12
0000774654fd34f8  jnz 0x0000774654FD4414
0000774654fd34fe  vmovaps xmm1, [rsp+0x120]
0000774654fd3507  vmovaps xmm15, [rsp+0x120]
0000774654fd3510  por xmm1, xmm15
0000774654fd3515  movaps [r15+0x1D0], xmm1
0000774654fd351d  vmovaps xmm15, [rsp+0x90]
0000774654fd3526  vpermilpd xmm15, xmm15, 0x00
0000774654fd352c  vmovaps xmm14, [rsp+0xE0]
0000774654fd3535  vmovaps [rsp+0x90], xmm1
0000774654fd353e  movaps xmm12, xmm14
0000774654fd3542  vfmadd231pd xmm12, xmm2, xmm15
0000774654fd3547  vcmppd xmm1, xmm12, xmm12, 0x03
0000774654fd354d  vptest xmm1, xmm1
0000774654fd3552  jnz 0x0000774654FD456D
0000774654fd3558  vmovaps [rsp+0xB0], xmm3
0000774654fd3561  vmovaps xmm1, [rsp+0xB0]
0000774654fd356a  por xmm3, xmm1
0000774654fd356e  movaps [r15+0x200], xmm3
0000774654fd3576  vmovaps xmm1, [rsp+0xF0]
0000774654fd357f  vmovaps xmm15, [rsp+0xF0]
0000774654fd3588  por xmm1, xmm15
0000774654fd358d  movaps [r15+0x1E0], xmm1
0000774654fd3595  vmovaps [rsp+0xB0], xmm7
0000774654fd359e  vmovaps xmm1, [rsp+0xB0]
0000774654fd35a7  por xmm7, xmm1
0000774654fd35ab  movaps [r15+0x2B0], xmm7
0000774654fd35b3  vmovaps [rsp+0xB0], xmm8
0000774654fd35bc  vmovaps xmm1, [rsp+0xB0]
0000774654fd35c5  por xmm8, xmm1
0000774654fd35ca  movaps [r15+0x300], xmm8
0000774654fd35d2  vmovaps [rsp+0xB0], xmm5
0000774654fd35db  vpermilpd xmm5, xmm5, 0x00
0000774654fd35e1  vmovaps xmm14, [rsp+0x50]
0000774654fd35e7  vmovaps xmm8, [rsp+0x70]
0000774654fd35ed  vmovaps [rsp+0x50], xmm1
0000774654fd35f3  movaps xmm2, xmm14
0000774654fd35f7  vfmadd231pd xmm2, xmm8, xmm5
0000774654fd35fc  vcmppd xmm1, xmm2, xmm2, 0x03
0000774654fd3601  vptest xmm1, xmm1
0000774654fd3606  jnz 0x0000774654FD46C6
0000774654fd360c  vmovaps xmm1, [rsp+0xB0]
0000774654fd3615  vpermilpd xmm1, xmm1, 0x00
0000774654fd361b  vmovaps xmm14, [rsp+0x60]
0000774654fd3621  vmovaps xmm8, [rsp+0xD0]
0000774654fd362a  vmovaps [rsp+0x60], xmm15
0000774654fd3630  movaps xmm5, xmm14
0000774654fd3634  vfmadd231pd xmm5, xmm8, xmm1
0000774654fd3639  vcmppd xmm15, xmm5, xmm5, 0x03
0000774654fd363e  vptest xmm15, xmm15
0000774654fd3643  jnz 0x0000774654FD481D
0000774654fd3649  vmovaps xmm1, [rsp+0xB0]
0000774654fd3652  vpermilpd xmm1, xmm1, 0x00
0000774654fd3658  vmovaps xmm14, [rsp+0x20]
0000774654fd365e  movaps xmm15, xmm13
0000774654fd3662  vfmadd231pd xmm15, xmm14, xmm1
0000774654fd3667  vcmppd xmm8, xmm15, xmm15, 0x03
0000774654fd366d  vptest xmm8, xmm8
0000774654fd3672  jnz 0x0000774654FD4974
0000774654fd3678  vmovaps xmm1, [rsp+0xB0]
0000774654fd3681  vpermilpd xmm1, xmm1, 0x00
0000774654fd3687  vmovaps xmm14, [rsp+0x90]
0000774654fd3690  movaps xmm13, xmm12
0000774654fd3694  vfmadd231pd xmm13, xmm14, xmm1
0000774654fd3699  vcmppd xmm8, xmm13, xmm13, 0x03
0000774654fd369f  vptest xmm8, xmm8
0000774654fd36a4  jnz 0x0000774654FD4ACD
0000774654fd36aa  vmovaps [rsp+0x20], xmm6
0000774654fd36b0  vmovaps xmm1, [rsp+0x20]
0000774654fd36b6  por xmm6, xmm1
0000774654fd36ba  movaps [r15+0x180], xmm6
0000774654fd36c2  vmovaps [rsp+0x20], xmm9
0000774654fd36c8  vmovaps xmm1, [rsp+0x20]
0000774654fd36ce  por xmm9, xmm1
0000774654fd36d3  movaps [r15+0x2D0], xmm9
0000774654fd36db  vmovaps [rsp+0x20], xmm10
0000774654fd36e1  vmovaps xmm1, [rsp+0x20]
0000774654fd36e7  por xmm10, xmm1
0000774654fd36ec  movaps [r15+0x2F0], xmm10
0000774654fd36f4  vmovaps [rsp+0x20], xmm4
0000774654fd36fa  vpermilpd xmm4, xmm4, 0x00
0000774654fd3700  vmovaps xmm14, [rsp+0x50]
0000774654fd3706  movaps xmm12, xmm5
0000774654fd370a  vfmadd231pd xmm12, xmm14, xmm4
0000774654fd370f  vcmppd xmm10, xmm12, xmm12, 0x03
0000774654fd3715  vptest xmm10, xmm10
0000774654fd371a  jnz 0x0000774654FD4C26
0000774654fd3720  vmovaps xmm14, [rsp+0x20]
0000774654fd3726  vpermilpd xmm14, xmm14, 0x00
0000774654fd372c  movaps xmm10, xmm2
0000774654fd3730  vfmadd231pd xmm10, xmm6, xmm14
0000774654fd3735  vcmppd xmm8, xmm10, xmm10, 0x03
0000774654fd373b  vptest xmm8, xmm8
0000774654fd3740  jnz 0x0000774654FD4D7E
0000774654fd3746  lea r14, [rax+0x80]
0000774654fd374d  movups xmm14, [r13+r14*1]
0000774654fd3753  movaps [r15+0x190], xmm14
0000774654fd375b  vmovaps xmm8, [rsp+0x20]
0000774654fd3761  vpermilpd xmm8, xmm8, 0x00
0000774654fd3767  vmovaps xmm6, [rsp+0x80]
0000774654fd3770  movaps xmm5, xmm15
0000774654fd3774  vfmadd231pd xmm5, xmm6, xmm8
0000774654fd3779  vcmppd xmm4, xmm5, xmm5, 0x03
0000774654fd377e  vptest xmm4, xmm4
0000774654fd3783  jnz 0x0000774654FD4EE0
0000774654fd3789  vmovaps xmm15, [rsp+0x20]
0000774654fd378f  vpermilpd xmm15, xmm15, 0x00
0000774654fd3795  movaps xmm8, xmm13
0000774654fd3799  vfmadd231pd xmm8, xmm1, xmm15
0000774654fd379e  vcmppd xmm6, xmm8, xmm8, 0x03
0000774654fd37a4  vptest xmm6, xmm6
0000774654fd37a9  jnz 0x0000774654FD5037
0000774654fd37af  vmovaps xmm1, [rsp+0x30]
0000774654fd37b5  vmovaps xmm15, [rsp+0x30]
0000774654fd37bb  por xmm1, xmm15
0000774654fd37c0  movaps [r15+0x160], xmm1
0000774654fd37c8  lea r14, [rax+0x40]
0000774654fd37cc  movups xmm15, [r13+r14*1]
0000774654fd37d2  lea r14, [rax+0x50]
0000774654fd37d6  movups xmm13, [r13+r14*1]
0000774654fd37dc  movaps [r15+0x1B0], xmm15
0000774654fd37e4  movaps [r15+0x1A0], xmm13
0000774654fd37ec  vmovaps xmm6, [rsp+0xC0]
0000774654fd37f5  vpermilpd xmm6, xmm6, 0x00
0000774654fd37fb  movaps xmm4, xmm12
0000774654fd37ff  vfmadd231pd xmm4, xmm9, xmm6
0000774654fd3804  vcmppd xmm2, xmm4, xmm4, 0x03
0000774654fd3809  vptest xmm2, xmm2
0000774654fd380e  jnz 0x0000774654FD51A4
0000774654fd3814  vmovaps xmm12, [rsp+0xC0]
0000774654fd381d  vpermilpd xmm12, xmm12, 0x00
0000774654fd3823  movaps xmm9, xmm10
0000774654fd3827  vfmadd231pd xmm9, xmm1, xmm12
0000774654fd382c  vcmppd xmm6, xmm9, xmm9, 0x03
0000774654fd3832  vptest xmm6, xmm6
0000774654fd3837  jnz 0x0000774654FD52FB
0000774654fd383d  vmovaps xmm1, [rsp+0xC0]
0000774654fd3846  vpermilpd xmm1, xmm1, 0x00
0000774654fd384c  vmovaps xmm12, [rsp+0x40]
0000774654fd3852  movaps xmm10, xmm5
0000774654fd3856  vfmadd231pd xmm10, xmm12, xmm1
0000774654fd385b  vcmppd xmm6, xmm10, xmm10, 0x03
0000774654fd3861  vptest xmm6, xmm6
0000774654fd3866  jnz 0x0000774654FD5454
0000774654fd386c  vmovaps xmm1, [rsp+0xC0]
0000774654fd3875  vpermilpd xmm1, xmm1, 0x00
0000774654fd387b  vmovaps xmm12, [rsp+0x60]
0000774654fd3881  movaps xmm6, xmm8
0000774654fd3885  vfmadd231pd xmm6, xmm12, xmm1
0000774654fd388a  vcmppd xmm5, xmm6, xmm6, 0x03
0000774654fd388f  vptest xmm5, xmm5
0000774654fd3894  jnz 0x0000774654FD55AC
0000774654fd389a  lea r14, [rax+0x60]
0000774654fd389e  movups xmm1, [r13+r14*1]
0000774654fd38a4  lea r14, [rax+0x70]
0000774654fd38a8  movups xmm12, [r13+r14*1]
0000774654fd38ae  movaps [r15+0x150], xmm1
0000774654fd38b6  movaps [r15+0x120], xmm12
0000774654fd38be  vmovaps [rsp+0x20], xmm11
0000774654fd38c4  vpermilpd xmm11, xmm11, 0x00
0000774654fd38ca  movaps xmm8, xmm4
0000774654fd38ce  vfmadd231pd xmm8, xmm13, xmm11
0000774654fd38d3  vcmppd xmm5, xmm8, xmm8, 0x03
0000774654fd38d9  vptest xmm5, xmm5
0000774654fd38de  jnz 0x0000774654FD5717
0000774654fd38e4  vmovaps xmm13, [rsp+0x20]
0000774654fd38ea  vpermilpd xmm13, xmm13, 0x00
0000774654fd38f0  movaps xmm11, xmm9
0000774654fd38f4  vfmadd231pd xmm11, xmm1, xmm13
0000774654fd38f9  vcmppd xmm5, xmm11, xmm11, 0x03
0000774654fd38ff  vptest xmm5, xmm5
0000774654fd3904  jnz 0x0000774654FD5870
0000774654fd390a  vmovaps xmm1, [rsp+0x20]
0000774654fd3910  vpermilpd xmm1, xmm1, 0x00
0000774654fd3916  movaps xmm13, xmm10
0000774654fd391a  vfmadd231pd xmm13, xmm7, xmm1
0000774654fd391f  vcmppd xmm9, xmm13, xmm13, 0x03
0000774654fd3925  vptest xmm9, xmm9
0000774654fd392a  jnz 0x0000774654FD59C9
0000774654fd3930  vmovaps xmm1, [rsp+0x20]
0000774654fd3936  vpermilpd xmm1, xmm1, 0x00
0000774654fd393c  movaps xmm10, xmm6
0000774654fd3940  vfmadd231pd xmm10, xmm15, xmm1
0000774654fd3945  vcmppd xmm9, xmm10, xmm10, 0x03
0000774654fd394b  vptest xmm9, xmm9
0000774654fd3950  jnz 0x0000774654FD5B21
0000774654fd3956  lea r14, [rax+0x20]
0000774654fd395a  movups xmm1, [r13+r14*1]
0000774654fd3960  lea r14, [rax+0x30]
0000774654fd3964  movups xmm15, [r13+r14*1]
0000774654fd396a  vmovaps xmm9, [rsp+0xA0]
0000774654fd3973  vpermilpd xmm9, xmm9, 0x00
0000774654fd3979  movaps xmm7, xmm8
0000774654fd397d  vfmadd231pd xmm7, xmm3, xmm9
0000774654fd3982  vcmppd xmm6, xmm7, xmm7, 0x03
0000774654fd3987  vptest xmm6, xmm6
0000774654fd398c  jnz 0x0000774654FD5C8D
0000774654fd3992  vmovaps xmm9, [rsp+0xA0]
0000774654fd399b  vpermilpd xmm9, xmm9, 0x00
0000774654fd39a1  movaps xmm8, xmm11
0000774654fd39a5  vfmadd231pd xmm8, xmm14, xmm9
0000774654fd39aa  vcmppd xmm6, xmm8, xmm8, 0x03
0000774654fd39b0  vptest xmm6, xmm6
0000774654fd39b5  jnz 0x0000774654FD5DE4
0000774654fd39bb  vmovaps xmm14, [rsp+0xA0]
0000774654fd39c4  vpermilpd xmm14, xmm14, 0x00
0000774654fd39ca  movaps xmm11, xmm13
0000774654fd39ce  vfmadd231pd xmm11, xmm12, xmm14
0000774654fd39d3  vcmppd xmm9, xmm11, xmm11, 0x03
0000774654fd39d9  vptest xmm9, xmm9
0000774654fd39de  jnz 0x0000774654FD5F3E
0000774654fd39e4  vmovaps xmm14, [rsp+0xA0]
0000774654fd39ed  vpermilpd xmm14, xmm14, 0x00
0000774654fd39f3  movaps xmm12, xmm10
0000774654fd39f7  vfmadd231pd xmm12, xmm15, xmm14
0000774654fd39fc  vcmppd xmm13, xmm12, xmm12, 0x03
0000774654fd3a02  vptest xmm13, xmm13
0000774654fd3a07  jnz 0x0000774654FD6098
0000774654fd3a0d  lea r14, [rax+0x90]
0000774654fd3a14  movups xmm15, [r13+r14*1]
0000774654fd3a1a  lea r14, [rax+0xA0]
0000774654fd3a21  movups xmm14, [r13+r14*1]
0000774654fd3a27  movaps [r15+0x140], xmm15
0000774654fd3a2f  movaps [r15+0x130], xmm14
0000774654fd3a37  vmovaps xmm13, [rsp+0x10]
0000774654fd3a3d  vpermilpd xmm13, xmm13, 0x00
0000774654fd3a43  movaps xmm10, xmm7
0000774654fd3a47  vfmadd231pd xmm10, xmm1, xmm13
0000774654fd3a4c  vcmppd xmm9, xmm10, xmm10, 0x03
0000774654fd3a52  vptest xmm9, xmm9
0000774654fd3a57  jnz 0x0000774654FD6206
0000774654fd3a5d  movaps [r15+0x220], xmm10
0000774654fd3a65  lea r14, [rax+0x10]
0000774654fd3a69  movups xmm1, [r13+r14*1]
0000774654fd3a6f  movaps [r15+0x240], xmm1
0000774654fd3a77  vmovaps xmm13, [rsp+0x10]
0000774654fd3a7d  vpermilpd xmm13, xmm13, 0x00
0000774654fd3a83  movaps xmm9, xmm8
0000774654fd3a87  vfmadd231pd xmm9, xmm14, xmm13
0000774654fd3a8c  vcmppd xmm7, xmm9, xmm9, 0x03
0000774654fd3a92  vptest xmm7, xmm7
0000774654fd3a97  jnz 0x0000774654FD6368
0000774654fd3a9d  movaps [r15+0x110], xmm9
0000774654fd3aa5  vmovaps xmm14, [rsp+0x10]
0000774654fd3aab  vpermilpd xmm14, xmm14, 0x00
0000774654fd3ab1  movaps xmm13, xmm11
0000774654fd3ab5  vfmadd231pd xmm13, xmm15, xmm14
0000774654fd3aba  vcmppd xmm8, xmm13, xmm13, 0x03
0000774654fd3ac0  vptest xmm8, xmm8
0000774654fd3ac5  jnz 0x0000774654FD64C2
0000774654fd3acb  movaps [r15+0x170], xmm13
0000774654fd3ad3  vmovaps xmm15, [rsp+0x10]
0000774654fd3ad9  vpermilpd xmm15, xmm15, 0x00
0000774654fd3adf  movaps xmm14, xmm12
0000774654fd3ae3  vfmadd231pd xmm14, xmm1, xmm15
0000774654fd3ae8  vcmppd xmm11, xmm14, xmm14, 0x03
0000774654fd3aee  vptest xmm11, xmm11
0000774654fd3af3  jnz 0x0000774654FD661C
0000774654fd3af9  movaps [r15+0x230], xmm14
0000774654fd3b01  movups [r13+r11*1], xmm9
0000774654fd3b07  lea rax, [r11+0x10]
0000774654fd3b0b  movups [r13+rax*1], xmm13
0000774654fd3b11  lea rax, [r11+0x20]
0000774654fd3b15  movups [r13+rax*1], xmm10
0000774654fd3b1b  lea rax, [r11+0x30]
0000774654fd3b1f  movups [r13+rax*1], xmm14
0000774654fd3b25  mov eax, [r15+0x108]
0000774654fd3b2c  sahf
0000774654fd3b2d  jnz 0x0000774654FD3B5F
0000774654fd3b2f  cmp dword ptr [r15+0x318], 0x00
0000774654fd3b37  jz 0x0000774654FD67A0
0000774654fd3b3d  nop [rax+rax*1], ax
0000774654fd3b46  nop [rax+rax*1], eax
0000774654fd3b4e  mov eax, 0x4103F0
0000774654fd3b53  mov [r15+0x100], rax
0000774654fd3b5a  jmp 0x0000774654DFE110
0000774654fd3b5f  cmp dword ptr [r15+0x318], 0x00
0000774654fd3b67  jz 0x0000774654FD2E40
0000774654fd3b6d  nop [rax+rax*1], ax
0000774654fd3b76  nop [rax+rax*1], eax
0000774654fd3b7e  mov eax, 0x410274
0000774654fd3b83  mov [r15+0x100], rax
0000774654fd3b8a  jmp 0x0000774654DFE110
0000774654fd3b8f  int3
0000774654fd3b90  call 0x0000774654E0A4B0
0000774654fd3b95  jmp 0x0000774654FD2E69
0000774654fd3b9a  call 0x0000774654E09240
0000774654fd3b9f  jmp 0x0000774654FD2E73
0000774654fd3ba4  call 0x0000774654E0A4B0
0000774654fd3ba9  jmp 0x0000774654FD2EBD
0000774654fd3bae  call 0x0000774654E09240
0000774654fd3bb3  jmp 0x0000774654FD2EC7
0000774654fd3bb8  call 0x0000774654E0A4B0
0000774654fd3bbd  jmp 0x0000774654FD2F60
0000774654fd3bc2  call 0x0000774654E09240
0000774654fd3bc7  jmp 0x0000774654FD2F6A
0000774654fd3bcc  call 0x0000774654EB47C0
0000774654fd3bd1  jmp 0x0000774654FD3055
0000774654fd3bd6  call 0x0000774654DFF430
0000774654fd3bdb  jmp 0x0000774654FD3084
0000774654fd3be0  call 0x0000774654EB0CE0
0000774654fd3be5  jmp 0x0000774654FD30A0
0000774654fd3bea  sub rsp, 0x08
0000774654fd3bee  push rax
0000774654fd3bef  push rcx
0000774654fd3bf0  push rdx
0000774654fd3bf1  push rdi
0000774654fd3bf2  push rsi
0000774654fd3bf3  push r8
0000774654fd3bf5  push r9
0000774654fd3bf7  push r10
0000774654fd3bf9  push r11
0000774654fd3bfb  sub rsp, 0xF0
0000774654fd3c02  vmovaps [rsp], xmm0
0000774654fd3c07  vmovaps [rsp+0x10], xmm1
0000774654fd3c0d  vmovaps [rsp+0x20], xmm2
0000774654fd3c13  vmovaps [rsp+0x30], xmm3
0000774654fd3c19  vmovaps [rsp+0x40], xmm4
0000774654fd3c1f  vmovaps [rsp+0x50], xmm5
0000774654fd3c25  vmovaps [rsp+0x60], xmm6
0000774654fd3c2b  vmovaps [rsp+0x70], xmm7
0000774654fd3c31  vmovaps [rsp+0x80], xmm8
0000774654fd3c3a  vmovaps [rsp+0x90], xmm9
0000774654fd3c43  vmovaps [rsp+0xA0], xmm10
0000774654fd3c4c  vmovaps [rsp+0xB0], xmm11
0000774654fd3c55  vmovaps [rsp+0xC0], xmm12
0000774654fd3c5e  vmovaps [rsp+0xD0], xmm14
0000774654fd3c67  vmovaps [rsp+0xE0], xmm15
0000774654fd3c70  sub rsp, 0x40
0000774654fd3c74  lea rdi, [rsp]
0000774654fd3c78  lea rsi, [rsp+0x10]
0000774654fd3c7d  lea rdx, [rsp+0x20]
0000774654fd3c82  lea rcx, [rsp+0x30]
0000774654fd3c87  mov r8d, 0x00
0000774654fd3c8d  lea r9, [r15+0x3A8]
0000774654fd3c94  movaps [rdi], xmm13
0000774654fd3c98  movaps [rsi], xmm1
0000774654fd3c9b  movaps [rdx], xmm15
0000774654fd3c9f  movaps [rcx], xmm14
0000774654fd3ca3  mov rax, 0x564E5D1DDA50
0000774654fd3cad  call rax
0000774654fd3caf  movaps xmm13, [rsp]
0000774654fd3cb4  add rsp, 0x40
0000774654fd3cb8  vmovaps xmm0, [rsp]
0000774654fd3cbd  vmovaps xmm1, [rsp+0x10]
0000774654fd3cc3  vmovaps xmm2, [rsp+0x20]
0000774654fd3cc9  vmovaps xmm3, [rsp+0x30]
0000774654fd3ccf  vmovaps xmm4, [rsp+0x40]
0000774654fd3cd5  vmovaps xmm5, [rsp+0x50]
0000774654fd3cdb  vmovaps xmm6, [rsp+0x60]
0000774654fd3ce1  vmovaps xmm7, [rsp+0x70]
0000774654fd3ce7  vmovaps xmm8, [rsp+0x80]
0000774654fd3cf0  vmovaps xmm9, [rsp+0x90]
0000774654fd3cf9  vmovaps xmm10, [rsp+0xA0]
0000774654fd3d02  vmovaps xmm11, [rsp+0xB0]
0000774654fd3d0b  vmovaps xmm12, [rsp+0xC0]
0000774654fd3d14  vmovaps xmm14, [rsp+0xD0]
0000774654fd3d1d  vmovaps xmm15, [rsp+0xE0]
0000774654fd3d26  add rsp, 0xF0
0000774654fd3d2d  pop r11
0000774654fd3d2f  pop r10
0000774654fd3d31  pop r9
0000774654fd3d33  pop r8
0000774654fd3d35  pop rsi
0000774654fd3d36  pop rdi
0000774654fd3d37  pop rdx
0000774654fd3d38  pop rcx
0000774654fd3d39  pop rax
0000774654fd3d3a  add rsp, 0x08
0000774654fd3d3e  jmp 0x0000774654FD3117
0000774654fd3d43  sub rsp, 0x08
0000774654fd3d47  push rax
0000774654fd3d48  push rcx
0000774654fd3d49  push rdx
0000774654fd3d4a  push rdi
0000774654fd3d4b  push rsi
0000774654fd3d4c  push r8
0000774654fd3d4e  push r9
0000774654fd3d50  push r10
0000774654fd3d52  push r11
0000774654fd3d54  sub rsp, 0xF0
0000774654fd3d5b  vmovaps [rsp], xmm0
0000774654fd3d60  vmovaps [rsp+0x10], xmm1
0000774654fd3d66  vmovaps [rsp+0x20], xmm2
0000774654fd3d6c  vmovaps [rsp+0x30], xmm3
0000774654fd3d72  vmovaps [rsp+0x40], xmm4
0000774654fd3d78  vmovaps [rsp+0x50], xmm5
0000774654fd3d7e  vmovaps [rsp+0x60], xmm6
0000774654fd3d84  vmovaps [rsp+0x70], xmm7
0000774654fd3d8a  vmovaps [rsp+0x80], xmm8
0000774654fd3d93  vmovaps [rsp+0x90], xmm9
0000774654fd3d9c  vmovaps [rsp+0xA0], xmm10
0000774654fd3da5  vmovaps [rsp+0xB0], xmm11
0000774654fd3dae  vmovaps [rsp+0xC0], xmm13
0000774654fd3db7  vmovaps [rsp+0xD0], xmm14
0000774654fd3dc0  vmovaps [rsp+0xE0], xmm15
0000774654fd3dc9  sub rsp, 0x40
0000774654fd3dcd  lea rdi, [rsp]
0000774654fd3dd1  lea rsi, [rsp+0x10]
0000774654fd3dd6  lea rdx, [rsp+0x20]
0000774654fd3ddb  lea rcx, [rsp+0x30]
0000774654fd3de0  mov r8d, 0x00
0000774654fd3de6  lea r9, [r15+0x3A8]
0000774654fd3ded  movaps [rdi], xmm12
0000774654fd3df1  movaps [rsi], xmm15
0000774654fd3df5  movaps [rdx], xmm1
0000774654fd3df8  movaps [rcx], xmm14
0000774654fd3dfc  mov rax, 0x564E5D1DDA50
0000774654fd3e06  call rax
0000774654fd3e08  movaps xmm12, [rsp]
0000774654fd3e0d  add rsp, 0x40
0000774654fd3e11  vmovaps xmm0, [rsp]
0000774654fd3e16  vmovaps xmm1, [rsp+0x10]
0000774654fd3e1c  vmovaps xmm2, [rsp+0x20]
0000774654fd3e22  vmovaps xmm3, [rsp+0x30]
0000774654fd3e28  vmovaps xmm4, [rsp+0x40]
0000774654fd3e2e  vmovaps xmm5, [rsp+0x50]
0000774654fd3e34  vmovaps xmm6, [rsp+0x60]
0000774654fd3e3a  vmovaps xmm7, [rsp+0x70]
0000774654fd3e40  vmovaps xmm8, [rsp+0x80]
0000774654fd3e49  vmovaps xmm9, [rsp+0x90]
0000774654fd3e52  vmovaps xmm10, [rsp+0xA0]
0000774654fd3e5b  vmovaps xmm11, [rsp+0xB0]
0000774654fd3e64  vmovaps xmm13, [rsp+0xC0]
0000774654fd3e6d  vmovaps xmm14, [rsp+0xD0]
0000774654fd3e76  vmovaps xmm15, [rsp+0xE0]
0000774654fd3e7f  add rsp, 0xF0
0000774654fd3e86  pop r11
0000774654fd3e88  pop r10
0000774654fd3e8a  pop r9
0000774654fd3e8c  pop r8
0000774654fd3e8e  pop rsi
0000774654fd3e8f  pop rdi
0000774654fd3e90  pop rdx
0000774654fd3e91  pop rcx
0000774654fd3e92  pop rax
0000774654fd3e93  add rsp, 0x08
0000774654fd3e97  jmp 0x0000774654FD3145
0000774654fd3e9c  call 0x0000774654ED64F0
0000774654fd3ea1  jmp 0x0000774654FD3231
0000774654fd3ea6  sub rsp, 0x08
0000774654fd3eaa  push rax
0000774654fd3eab  push rcx
0000774654fd3eac  push rdx
0000774654fd3ead  push rdi
0000774654fd3eae  push rsi
0000774654fd3eaf  push r8
0000774654fd3eb1  push r9
0000774654fd3eb3  push r10
0000774654fd3eb5  push r11
0000774654fd3eb7  sub rsp, 0xF0
0000774654fd3ebe  vmovaps [rsp], xmm0
0000774654fd3ec3  vmovaps [rsp+0x10], xmm1
0000774654fd3ec9  vmovaps [rsp+0x20], xmm2
0000774654fd3ecf  vmovaps [rsp+0x30], xmm3
0000774654fd3ed5  vmovaps [rsp+0x40], xmm4
0000774654fd3edb  vmovaps [rsp+0x50], xmm5
0000774654fd3ee1  vmovaps [rsp+0x60], xmm6
0000774654fd3ee7  vmovaps [rsp+0x70], xmm7
0000774654fd3eed  vmovaps [rsp+0x80], xmm8
0000774654fd3ef6  vmovaps [rsp+0x90], xmm9
0000774654fd3eff  vmovaps [rsp+0xA0], xmm10
0000774654fd3f08  vmovaps [rsp+0xB0], xmm11
0000774654fd3f11  vmovaps [rsp+0xC0], xmm12
0000774654fd3f1a  vmovaps [rsp+0xD0], xmm14
0000774654fd3f23  vmovaps [rsp+0xE0], xmm15
0000774654fd3f2c  sub rsp, 0x40
0000774654fd3f30  lea rdi, [rsp]
0000774654fd3f34  lea rsi, [rsp+0x10]
0000774654fd3f39  lea rdx, [rsp+0x20]
0000774654fd3f3e  lea rcx, [rsp+0x30]
0000774654fd3f43  mov r8d, 0x00
0000774654fd3f49  lea r9, [r15+0x3A8]
0000774654fd3f50  movaps [rdi], xmm13
0000774654fd3f54  movaps [rsi], xmm1
0000774654fd3f57  movaps [rdx], xmm15
0000774654fd3f5b  movaps [rcx], xmm14
0000774654fd3f5f  mov rax, 0x564E5D1DDA50
0000774654fd3f69  call rax
0000774654fd3f6b  movaps xmm13, [rsp]
0000774654fd3f70  add rsp, 0x40
0000774654fd3f74  vmovaps xmm0, [rsp]
0000774654fd3f79  vmovaps xmm1, [rsp+0x10]
0000774654fd3f7f  vmovaps xmm2, [rsp+0x20]
0000774654fd3f85  vmovaps xmm3, [rsp+0x30]
0000774654fd3f8b  vmovaps xmm4, [rsp+0x40]
0000774654fd3f91  vmovaps xmm5, [rsp+0x50]
0000774654fd3f97  vmovaps xmm6, [rsp+0x60]
0000774654fd3f9d  vmovaps xmm7, [rsp+0x70]
0000774654fd3fa3  vmovaps xmm8, [rsp+0x80]
0000774654fd3fac  vmovaps xmm9, [rsp+0x90]
0000774654fd3fb5  vmovaps xmm10, [rsp+0xA0]
0000774654fd3fbe  vmovaps xmm11, [rsp+0xB0]
0000774654fd3fc7  vmovaps xmm12, [rsp+0xC0]
0000774654fd3fd0  vmovaps xmm14, [rsp+0xD0]
0000774654fd3fd9  vmovaps xmm15, [rsp+0xE0]
0000774654fd3fe2  add rsp, 0xF0
0000774654fd3fe9  pop r11
0000774654fd3feb  pop r10
0000774654fd3fed  pop r9
0000774654fd3fef  pop r8
0000774654fd3ff1  pop rsi
0000774654fd3ff2  pop rdi
0000774654fd3ff3  pop rdx
0000774654fd3ff4  pop rcx
0000774654fd3ff5  pop rax
0000774654fd3ff6  add rsp, 0x08
0000774654fd3ffa  jmp 0x0000774654FD32A0
0000774654fd3fff  call 0x0000774654ED64F0
0000774654fd4004  jmp 0x0000774654FD32B5
0000774654fd4009  sub rsp, 0x08
0000774654fd400d  push rax
0000774654fd400e  push rcx
0000774654fd400f  push rdx
0000774654fd4010  push rdi
0000774654fd4011  push rsi
0000774654fd4012  push r8
0000774654fd4014  push r9
0000774654fd4016  push r10
0000774654fd4018  push r11
0000774654fd401a  sub rsp, 0xF0
0000774654fd4021  vmovaps [rsp], xmm0
0000774654fd4026  vmovaps [rsp+0x10], xmm1
0000774654fd402c  vmovaps [rsp+0x20], xmm2
0000774654fd4032  vmovaps [rsp+0x30], xmm3
0000774654fd4038  vmovaps [rsp+0x40], xmm4
0000774654fd403e  vmovaps [rsp+0x50], xmm5
0000774654fd4044  vmovaps [rsp+0x60], xmm6
0000774654fd404a  vmovaps [rsp+0x70], xmm7
0000774654fd4050  vmovaps [rsp+0x80], xmm8
0000774654fd4059  vmovaps [rsp+0x90], xmm9
0000774654fd4062  vmovaps [rsp+0xA0], xmm10
0000774654fd406b  vmovaps [rsp+0xB0], xmm11
0000774654fd4074  vmovaps [rsp+0xC0], xmm13
0000774654fd407d  vmovaps [rsp+0xD0], xmm14
0000774654fd4086  vmovaps [rsp+0xE0], xmm15
0000774654fd408f  sub rsp, 0x40
0000774654fd4093  lea rdi, [rsp]
0000774654fd4097  lea rsi, [rsp+0x10]
0000774654fd409c  lea rdx, [rsp+0x20]
0000774654fd40a1  lea rcx, [rsp+0x30]
0000774654fd40a6  mov r8d, 0x00
0000774654fd40ac  lea r9, [r15+0x3A8]
0000774654fd40b3  movaps [rdi], xmm12
0000774654fd40b7  movaps [rsi], xmm15
0000774654fd40bb  movaps [rdx], xmm1
0000774654fd40be  movaps [rcx], xmm14
0000774654fd40c2  mov rax, 0x564E5D1DDA50
0000774654fd40cc  call rax
0000774654fd40ce  movaps xmm12, [rsp]
0000774654fd40d3  add rsp, 0x40
0000774654fd40d7  vmovaps xmm0, [rsp]
0000774654fd40dc  vmovaps xmm1, [rsp+0x10]
0000774654fd40e2  vmovaps xmm2, [rsp+0x20]
0000774654fd40e8  vmovaps xmm3, [rsp+0x30]
0000774654fd40ee  vmovaps xmm4, [rsp+0x40]
0000774654fd40f4  vmovaps xmm5, [rsp+0x50]
0000774654fd40fa  vmovaps xmm6, [rsp+0x60]
0000774654fd4100  vmovaps xmm7, [rsp+0x70]
0000774654fd4106  vmovaps xmm8, [rsp+0x80]
0000774654fd410f  vmovaps xmm9, [rsp+0x90]
0000774654fd4118  vmovaps xmm10, [rsp+0xA0]
0000774654fd4121  vmovaps xmm11, [rsp+0xB0]
0000774654fd412a  vmovaps xmm13, [rsp+0xC0]
0000774654fd4133  vmovaps xmm14, [rsp+0xD0]
0000774654fd413c  vmovaps xmm15, [rsp+0xE0]
0000774654fd4145  add rsp, 0xF0
0000774654fd414c  pop r11
0000774654fd414e  pop r10
0000774654fd4150  pop r9
0000774654fd4152  pop r8
0000774654fd4154  pop rsi
0000774654fd4155  pop rdi
0000774654fd4156  pop rdx
0000774654fd4157  pop rcx
0000774654fd4158  pop rax
0000774654fd4159  add rsp, 0x08
0000774654fd415d  jmp 0x0000774654FD32E1
0000774654fd4162  sub rsp, 0x08
0000774654fd4166  push rax
0000774654fd4167  push rcx
0000774654fd4168  push rdx
0000774654fd4169  push rdi
0000774654fd416a  push rsi
0000774654fd416b  push r8
0000774654fd416d  push r9
0000774654fd416f  push r10
0000774654fd4171  push r11
0000774654fd4173  sub rsp, 0xF0
0000774654fd417a  vmovaps [rsp], xmm0
0000774654fd417f  vmovaps [rsp+0x10], xmm1
0000774654fd4185  vmovaps [rsp+0x20], xmm2
0000774654fd418b  vmovaps [rsp+0x30], xmm3
0000774654fd4191  vmovaps [rsp+0x40], xmm4
0000774654fd4197  vmovaps [rsp+0x50], xmm5
0000774654fd419d  vmovaps [rsp+0x60], xmm6
0000774654fd41a3  vmovaps [rsp+0x70], xmm7
0000774654fd41a9  vmovaps [rsp+0x80], xmm8
0000774654fd41b2  vmovaps [rsp+0x90], xmm9
0000774654fd41bb  vmovaps [rsp+0xA0], xmm10
0000774654fd41c4  vmovaps [rsp+0xB0], xmm11
0000774654fd41cd  vmovaps [rsp+0xC0], xmm12
0000774654fd41d6  vmovaps [rsp+0xD0], xmm14
0000774654fd41df  vmovaps [rsp+0xE0], xmm15
0000774654fd41e8  sub rsp, 0x40
0000774654fd41ec  lea rdi, [rsp]
0000774654fd41f0  lea rsi, [rsp+0x10]
0000774654fd41f5  lea rdx, [rsp+0x20]
0000774654fd41fa  lea rcx, [rsp+0x30]
0000774654fd41ff  mov r8d, 0x00
0000774654fd4205  lea r9, [r15+0x3A8]
0000774654fd420c  movaps [rdi], xmm13
0000774654fd4210  movaps [rsi], xmm1
0000774654fd4213  movaps [rdx], xmm15
0000774654fd4217  movaps [rcx], xmm14
0000774654fd421b  mov rax, 0x564E5D1DDA50
0000774654fd4225  call rax
0000774654fd4227  movaps xmm13, [rsp]
0000774654fd422c  add rsp, 0x40
0000774654fd4230  vmovaps xmm0, [rsp]
0000774654fd4235  vmovaps xmm1, [rsp+0x10]
0000774654fd423b  vmovaps xmm2, [rsp+0x20]
0000774654fd4241  vmovaps xmm3, [rsp+0x30]
0000774654fd4247  vmovaps xmm4, [rsp+0x40]
0000774654fd424d  vmovaps xmm5, [rsp+0x50]
0000774654fd4253  vmovaps xmm6, [rsp+0x60]
0000774654fd4259  vmovaps xmm7, [rsp+0x70]
0000774654fd425f  vmovaps xmm8, [rsp+0x80]
0000774654fd4268  vmovaps xmm9, [rsp+0x90]
0000774654fd4271  vmovaps xmm10, [rsp+0xA0]
0000774654fd427a  vmovaps xmm11, [rsp+0xB0]
0000774654fd4283  vmovaps xmm12, [rsp+0xC0]
0000774654fd428c  vmovaps xmm14, [rsp+0xD0]
0000774654fd4295  vmovaps xmm15, [rsp+0xE0]
0000774654fd429e  add rsp, 0xF0
0000774654fd42a5  pop r11
0000774654fd42a7  pop r10
0000774654fd42a9  pop r9
0000774654fd42ab  pop r8
0000774654fd42ad  pop rsi
0000774654fd42ae  pop rdi
0000774654fd42af  pop rdx
0000774654fd42b0  pop rcx
0000774654fd42b1  pop rax
0000774654fd42b2  add rsp, 0x08
0000774654fd42b6  jmp 0x0000774654FD3482
0000774654fd42bb  sub rsp, 0x08
0000774654fd42bf  push rax
0000774654fd42c0  push rcx
0000774654fd42c1  push rdx
0000774654fd42c2  push rdi
0000774654fd42c3  push rsi
0000774654fd42c4  push r8
0000774654fd42c6  push r9
0000774654fd42c8  push r10
0000774654fd42ca  push r11
0000774654fd42cc  sub rsp, 0xF0
0000774654fd42d3  vmovaps [rsp], xmm0
0000774654fd42d8  vmovaps [rsp+0x10], xmm1
0000774654fd42de  vmovaps [rsp+0x20], xmm2
0000774654fd42e4  vmovaps [rsp+0x30], xmm3
0000774654fd42ea  vmovaps [rsp+0x40], xmm4
0000774654fd42f0  vmovaps [rsp+0x50], xmm5
0000774654fd42f6  vmovaps [rsp+0x60], xmm6
0000774654fd42fc  vmovaps [rsp+0x70], xmm7
0000774654fd4302  vmovaps [rsp+0x80], xmm8
0000774654fd430b  vmovaps [rsp+0x90], xmm9
0000774654fd4314  vmovaps [rsp+0xA0], xmm10
0000774654fd431d  vmovaps [rsp+0xB0], xmm11
0000774654fd4326  vmovaps [rsp+0xC0], xmm13
0000774654fd432f  vmovaps [rsp+0xD0], xmm14
0000774654fd4338  vmovaps [rsp+0xE0], xmm15
0000774654fd4341  sub rsp, 0x40
0000774654fd4345  lea rdi, [rsp]
0000774654fd4349  lea rsi, [rsp+0x10]
0000774654fd434e  lea rdx, [rsp+0x20]
0000774654fd4353  lea rcx, [rsp+0x30]
0000774654fd4358  mov r8d, 0x00
0000774654fd435e  lea r9, [r15+0x3A8]
0000774654fd4365  movaps [rdi], xmm12
0000774654fd4369  movaps [rsi], xmm15
0000774654fd436d  movaps [rdx], xmm14
0000774654fd4371  movaps [rcx], xmm1
0000774654fd4374  mov rax, 0x564E5D1DDA50
0000774654fd437e  call rax
0000774654fd4380  movaps xmm12, [rsp]
0000774654fd4385  add rsp, 0x40
0000774654fd4389  vmovaps xmm0, [rsp]
0000774654fd438e  vmovaps xmm1, [rsp+0x10]
0000774654fd4394  vmovaps xmm2, [rsp+0x20]
0000774654fd439a  vmovaps xmm3, [rsp+0x30]
0000774654fd43a0  vmovaps xmm4, [rsp+0x40]
0000774654fd43a6  vmovaps xmm5, [rsp+0x50]
0000774654fd43ac  vmovaps xmm6, [rsp+0x60]
0000774654fd43b2  vmovaps xmm7, [rsp+0x70]
0000774654fd43b8  vmovaps xmm8, [rsp+0x80]
0000774654fd43c1  vmovaps xmm9, [rsp+0x90]
0000774654fd43ca  vmovaps xmm10, [rsp+0xA0]
0000774654fd43d3  vmovaps xmm11, [rsp+0xB0]
0000774654fd43dc  vmovaps xmm13, [rsp+0xC0]
0000774654fd43e5  vmovaps xmm14, [rsp+0xD0]
0000774654fd43ee  vmovaps xmm15, [rsp+0xE0]
0000774654fd43f7  add rsp, 0xF0
0000774654fd43fe  pop r11
0000774654fd4400  pop r10
0000774654fd4402  pop r9
0000774654fd4404  pop r8
0000774654fd4406  pop rsi
0000774654fd4407  pop rdi
0000774654fd4408  pop rdx
0000774654fd4409  pop rcx
0000774654fd440a  pop rax
0000774654fd440b  add rsp, 0x08
0000774654fd440f  jmp 0x0000774654FD34C0
0000774654fd4414  sub rsp, 0x08
0000774654fd4418  push rax
0000774654fd4419  push rcx
0000774654fd441a  push rdx
0000774654fd441b  push rdi
0000774654fd441c  push rsi
0000774654fd441d  push r8
0000774654fd441f  push r9
0000774654fd4421  push r10
0000774654fd4423  push r11
0000774654fd4425  sub rsp, 0xF0
0000774654fd442c  vmovaps [rsp], xmm0
0000774654fd4431  vmovaps [rsp+0x10], xmm1
0000774654fd4437  vmovaps [rsp+0x20], xmm2
0000774654fd443d  vmovaps [rsp+0x30], xmm3
0000774654fd4443  vmovaps [rsp+0x40], xmm4
0000774654fd4449  vmovaps [rsp+0x50], xmm5
0000774654fd444f  vmovaps [rsp+0x60], xmm6
0000774654fd4455  vmovaps [rsp+0x70], xmm7
0000774654fd445b  vmovaps [rsp+0x80], xmm8
0000774654fd4464  vmovaps [rsp+0x90], xmm9
0000774654fd446d  vmovaps [rsp+0xA0], xmm10
0000774654fd4476  vmovaps [rsp+0xB0], xmm11
0000774654fd447f  vmovaps [rsp+0xC0], xmm12
0000774654fd4488  vmovaps [rsp+0xD0], xmm14
0000774654fd4491  vmovaps [rsp+0xE0], xmm15
0000774654fd449a  sub rsp, 0x40
0000774654fd449e  lea rdi, [rsp]
0000774654fd44a2  lea rsi, [rsp+0x10]
0000774654fd44a7  lea rdx, [rsp+0x20]
0000774654fd44ac  lea rcx, [rsp+0x30]
0000774654fd44b1  mov r8d, 0x00
0000774654fd44b7  lea r9, [r15+0x3A8]
0000774654fd44be  movaps [rdi], xmm13
0000774654fd44c2  movaps [rsi], xmm15
0000774654fd44c6  movaps [rdx], xmm14
0000774654fd44ca  movaps [rcx], xmm1
0000774654fd44cd  mov rax, 0x564E5D1DDA50
0000774654fd44d7  call rax
0000774654fd44d9  movaps xmm13, [rsp]
0000774654fd44de  add rsp, 0x40
0000774654fd44e2  vmovaps xmm0, [rsp]
0000774654fd44e7  vmovaps xmm1, [rsp+0x10]
0000774654fd44ed  vmovaps xmm2, [rsp+0x20]
0000774654fd44f3  vmovaps xmm3, [rsp+0x30]
0000774654fd44f9  vmovaps xmm4, [rsp+0x40]
0000774654fd44ff  vmovaps xmm5, [rsp+0x50]
0000774654fd4505  vmovaps xmm6, [rsp+0x60]
0000774654fd450b  vmovaps xmm7, [rsp+0x70]
0000774654fd4511  vmovaps xmm8, [rsp+0x80]
0000774654fd451a  vmovaps xmm9, [rsp+0x90]
0000774654fd4523  vmovaps xmm10, [rsp+0xA0]
0000774654fd452c  vmovaps xmm11, [rsp+0xB0]
0000774654fd4535  vmovaps xmm12, [rsp+0xC0]
0000774654fd453e  vmovaps xmm14, [rsp+0xD0]
0000774654fd4547  vmovaps xmm15, [rsp+0xE0]
0000774654fd4550  add rsp, 0xF0
0000774654fd4557  pop r11
0000774654fd4559  pop r10
0000774654fd455b  pop r9
0000774654fd455d  pop r8
0000774654fd455f  pop rsi
0000774654fd4560  pop rdi
0000774654fd4561  pop rdx
0000774654fd4562  pop rcx
0000774654fd4563  pop rax
0000774654fd4564  add rsp, 0x08
0000774654fd4568  jmp 0x0000774654FD34FE
0000774654fd456d  sub rsp, 0x08
0000774654fd4571  push rax
0000774654fd4572  push rcx
0000774654fd4573  push rdx
0000774654fd4574  push rdi
0000774654fd4575  push rsi
0000774654fd4576  push r8
0000774654fd4578  push r9
0000774654fd457a  push r10
0000774654fd457c  push r11
0000774654fd457e  sub rsp, 0xF0
0000774654fd4585  vmovaps [rsp], xmm0
0000774654fd458a  vmovaps [rsp+0x10], xmm1
0000774654fd4590  vmovaps [rsp+0x20], xmm2
0000774654fd4596  vmovaps [rsp+0x30], xmm3
0000774654fd459c  vmovaps [rsp+0x40], xmm4
0000774654fd45a2  vmovaps [rsp+0x50], xmm5
0000774654fd45a8  vmovaps [rsp+0x60], xmm6
0000774654fd45ae  vmovaps [rsp+0x70], xmm7
0000774654fd45b4  vmovaps [rsp+0x80], xmm8
0000774654fd45bd  vmovaps [rsp+0x90], xmm9
0000774654fd45c6  vmovaps [rsp+0xA0], xmm10
0000774654fd45cf  vmovaps [rsp+0xB0], xmm11
0000774654fd45d8  vmovaps [rsp+0xC0], xmm13
0000774654fd45e1  vmovaps [rsp+0xD0], xmm14
0000774654fd45ea  vmovaps [rsp+0xE0], xmm15
0000774654fd45f3  sub rsp, 0x40
0000774654fd45f7  lea rdi, [rsp]
0000774654fd45fb  lea rsi, [rsp+0x10]
0000774654fd4600  lea rdx, [rsp+0x20]
0000774654fd4605  lea rcx, [rsp+0x30]
0000774654fd460a  mov r8d, 0x00
0000774654fd4610  lea r9, [r15+0x3A8]
0000774654fd4617  movaps [rdi], xmm12
0000774654fd461b  movaps [rsi], xmm14
0000774654fd461f  movaps [rdx], xmm2
0000774654fd4622  movaps [rcx], xmm15
0000774654fd4626  mov rax, 0x564E5D1DDA50
0000774654fd4630  call rax
0000774654fd4632  movaps xmm12, [rsp]
0000774654fd4637  add rsp, 0x40
0000774654fd463b  vmovaps xmm0, [rsp]
0000774654fd4640  vmovaps xmm1, [rsp+0x10]
0000774654fd4646  vmovaps xmm2, [rsp+0x20]
0000774654fd464c  vmovaps xmm3, [rsp+0x30]
0000774654fd4652  vmovaps xmm4, [rsp+0x40]
0000774654fd4658  vmovaps xmm5, [rsp+0x50]
0000774654fd465e  vmovaps xmm6, [rsp+0x60]
0000774654fd4664  vmovaps xmm7, [rsp+0x70]
0000774654fd466a  vmovaps xmm8, [rsp+0x80]
0000774654fd4673  vmovaps xmm9, [rsp+0x90]
0000774654fd467c  vmovaps xmm10, [rsp+0xA0]
0000774654fd4685  vmovaps xmm11, [rsp+0xB0]
0000774654fd468e  vmovaps xmm13, [rsp+0xC0]
0000774654fd4697  vmovaps xmm14, [rsp+0xD0]
0000774654fd46a0  vmovaps xmm15, [rsp+0xE0]
0000774654fd46a9  add rsp, 0xF0
0000774654fd46b0  pop r11
0000774654fd46b2  pop r10
0000774654fd46b4  pop r9
0000774654fd46b6  pop r8
0000774654fd46b8  pop rsi
0000774654fd46b9  pop rdi
0000774654fd46ba  pop rdx
0000774654fd46bb  pop rcx
0000774654fd46bc  pop rax
0000774654fd46bd  add rsp, 0x08
0000774654fd46c1  jmp 0x0000774654FD3558
0000774654fd46c6  sub rsp, 0x08
0000774654fd46ca  push rax
0000774654fd46cb  push rcx
0000774654fd46cc  push rdx
0000774654fd46cd  push rdi
0000774654fd46ce  push rsi
0000774654fd46cf  push r8
0000774654fd46d1  push r9
0000774654fd46d3  push r10
0000774654fd46d5  push r11
0000774654fd46d7  sub rsp, 0xF0
0000774654fd46de  vmovaps [rsp], xmm0
0000774654fd46e3  vmovaps [rsp+0x10], xmm1
0000774654fd46e9  vmovaps [rsp+0x20], xmm3
0000774654fd46ef  vmovaps [rsp+0x30], xmm4
0000774654fd46f5  vmovaps [rsp+0x40], xmm5
0000774654fd46fb  vmovaps [rsp+0x50], xmm6
0000774654fd4701  vmovaps [rsp+0x60], xmm7
0000774654fd4707  vmovaps [rsp+0x70], xmm8
0000774654fd470d  vmovaps [rsp+0x80], xmm9
0000774654fd4716  vmovaps [rsp+0x90], xmm10
0000774654fd471f  vmovaps [rsp+0xA0], xmm11
0000774654fd4728  vmovaps [rsp+0xB0], xmm12
0000774654fd4731  vmovaps [rsp+0xC0], xmm13
0000774654fd473a  vmovaps [rsp+0xD0], xmm14
0000774654fd4743  vmovaps [rsp+0xE0], xmm15
0000774654fd474c  sub rsp, 0x40
0000774654fd4750  lea rdi, [rsp]
0000774654fd4754  lea rsi, [rsp+0x10]
0000774654fd4759  lea rdx, [rsp+0x20]
0000774654fd475e  lea rcx, [rsp+0x30]
0000774654fd4763  mov r8d, 0x00
0000774654fd4769  lea r9, [r15+0x3A8]
0000774654fd4770  movaps [rdi], xmm2
0000774654fd4773  movaps [rsi], xmm14
0000774654fd4777  movaps [rdx], xmm8
0000774654fd477b  movaps [rcx], xmm5
0000774654fd477e  mov rax, 0x564E5D1DDA50
0000774654fd4788  call rax
0000774654fd478a  movaps xmm2, [rsp]
0000774654fd478e  add rsp, 0x40
0000774654fd4792  vmovaps xmm0, [rsp]
0000774654fd4797  vmovaps xmm1, [rsp+0x10]
0000774654fd479d  vmovaps xmm3, [rsp+0x20]
0000774654fd47a3  vmovaps xmm4, [rsp+0x30]
0000774654fd47a9  vmovaps xmm5, [rsp+0x40]
0000774654fd47af  vmovaps xmm6, [rsp+0x50]
0000774654fd47b5  vmovaps xmm7, [rsp+0x60]
0000774654fd47bb  vmovaps xmm8, [rsp+0x70]
0000774654fd47c1  vmovaps xmm9, [rsp+0x80]
0000774654fd47ca  vmovaps xmm10, [rsp+0x90]
0000774654fd47d3  vmovaps xmm11, [rsp+0xA0]
0000774654fd47dc  vmovaps xmm12, [rsp+0xB0]
0000774654fd47e5  vmovaps xmm13, [rsp+0xC0]
0000774654fd47ee  vmovaps xmm14, [rsp+0xD0]
0000774654fd47f7  vmovaps xmm15, [rsp+0xE0]
0000774654fd4800  add rsp, 0xF0
0000774654fd4807  pop r11
0000774654fd4809  pop r10
0000774654fd480b  pop r9
0000774654fd480d  pop r8
0000774654fd480f  pop rsi
0000774654fd4810  pop rdi
0000774654fd4811  pop rdx
0000774654fd4812  pop rcx
0000774654fd4813  pop rax
0000774654fd4814  add rsp, 0x08
0000774654fd4818  jmp 0x0000774654FD360C
0000774654fd481d  sub rsp, 0x08
0000774654fd4821  push rax
0000774654fd4822  push rcx
0000774654fd4823  push rdx
0000774654fd4824  push rdi
0000774654fd4825  push rsi
0000774654fd4826  push r8
0000774654fd4828  push r9
0000774654fd482a  push r10
0000774654fd482c  push r11
0000774654fd482e  sub rsp, 0xF0
0000774654fd4835  vmovaps [rsp], xmm0
0000774654fd483a  vmovaps [rsp+0x10], xmm1
0000774654fd4840  vmovaps [rsp+0x20], xmm2
0000774654fd4846  vmovaps [rsp+0x30], xmm3
0000774654fd484c  vmovaps [rsp+0x40], xmm4
0000774654fd4852  vmovaps [rsp+0x50], xmm6
0000774654fd4858  vmovaps [rsp+0x60], xmm7
0000774654fd485e  vmovaps [rsp+0x70], xmm8
0000774654fd4864  vmovaps [rsp+0x80], xmm9
0000774654fd486d  vmovaps [rsp+0x90], xmm10
0000774654fd4876  vmovaps [rsp+0xA0], xmm11
0000774654fd487f  vmovaps [rsp+0xB0], xmm12
0000774654fd4888  vmovaps [rsp+0xC0], xmm13
0000774654fd4891  vmovaps [rsp+0xD0], xmm14
0000774654fd489a  vmovaps [rsp+0xE0], xmm15
0000774654fd48a3  sub rsp, 0x40
0000774654fd48a7  lea rdi, [rsp]
0000774654fd48ab  lea rsi, [rsp+0x10]
0000774654fd48b0  lea rdx, [rsp+0x20]
0000774654fd48b5  lea rcx, [rsp+0x30]
0000774654fd48ba  mov r8d, 0x00
0000774654fd48c0  lea r9, [r15+0x3A8]
0000774654fd48c7  movaps [rdi], xmm5
0000774654fd48ca  movaps [rsi], xmm14
0000774654fd48ce  movaps [rdx], xmm8
0000774654fd48d2  movaps [rcx], xmm1
0000774654fd48d5  mov rax, 0x564E5D1DDA50
0000774654fd48df  call rax
0000774654fd48e1  movaps xmm5, [rsp]
0000774654fd48e5  add rsp, 0x40
0000774654fd48e9  vmovaps xmm0, [rsp]
0000774654fd48ee  vmovaps xmm1, [rsp+0x10]
0000774654fd48f4  vmovaps xmm2, [rsp+0x20]
0000774654fd48fa  vmovaps xmm3, [rsp+0x30]
0000774654fd4900  vmovaps xmm4, [rsp+0x40]
0000774654fd4906  vmovaps xmm6, [rsp+0x50]
0000774654fd490c  vmovaps xmm7, [rsp+0x60]
0000774654fd4912  vmovaps xmm8, [rsp+0x70]
0000774654fd4918  vmovaps xmm9, [rsp+0x80]
0000774654fd4921  vmovaps xmm10, [rsp+0x90]
0000774654fd492a  vmovaps xmm11, [rsp+0xA0]
0000774654fd4933  vmovaps xmm12, [rsp+0xB0]
0000774654fd493c  vmovaps xmm13, [rsp+0xC0]
0000774654fd4945  vmovaps xmm14, [rsp+0xD0]
0000774654fd494e  vmovaps xmm15, [rsp+0xE0]
0000774654fd4957  add rsp, 0xF0
0000774654fd495e  pop r11
0000774654fd4960  pop r10
0000774654fd4962  pop r9
0000774654fd4964  pop r8
0000774654fd4966  pop rsi
0000774654fd4967  pop rdi
0000774654fd4968  pop rdx
0000774654fd4969  pop rcx
0000774654fd496a  pop rax
0000774654fd496b  add rsp, 0x08
0000774654fd496f  jmp 0x0000774654FD3649
0000774654fd4974  sub rsp, 0x08
0000774654fd4978  push rax
0000774654fd4979  push rcx
0000774654fd497a  push rdx
0000774654fd497b  push rdi
0000774654fd497c  push rsi
0000774654fd497d  push r8
0000774654fd497f  push r9
0000774654fd4981  push r10
0000774654fd4983  push r11
0000774654fd4985  sub rsp, 0xF0
0000774654fd498c  vmovaps [rsp], xmm0
0000774654fd4991  vmovaps [rsp+0x10], xmm1
0000774654fd4997  vmovaps [rsp+0x20], xmm2
0000774654fd499d  vmovaps [rsp+0x30], xmm3
0000774654fd49a3  vmovaps [rsp+0x40], xmm4
0000774654fd49a9  vmovaps [rsp+0x50], xmm5
0000774654fd49af  vmovaps [rsp+0x60], xmm6
0000774654fd49b5  vmovaps [rsp+0x70], xmm7
0000774654fd49bb  vmovaps [rsp+0x80], xmm8
0000774654fd49c4  vmovaps [rsp+0x90], xmm9
0000774654fd49cd  vmovaps [rsp+0xA0], xmm10
0000774654fd49d6  vmovaps [rsp+0xB0], xmm11
0000774654fd49df  vmovaps [rsp+0xC0], xmm12
0000774654fd49e8  vmovaps [rsp+0xD0], xmm13
0000774654fd49f1  vmovaps [rsp+0xE0], xmm14
0000774654fd49fa  sub rsp, 0x40
0000774654fd49fe  lea rdi, [rsp]
0000774654fd4a02  lea rsi, [rsp+0x10]
0000774654fd4a07  lea rdx, [rsp+0x20]
0000774654fd4a0c  lea rcx, [rsp+0x30]
0000774654fd4a11  mov r8d, 0x00
0000774654fd4a17  lea r9, [r15+0x3A8]
0000774654fd4a1e  movaps [rdi], xmm15
0000774654fd4a22  movaps [rsi], xmm13
0000774654fd4a26  movaps [rdx], xmm14
0000774654fd4a2a  movaps [rcx], xmm1
0000774654fd4a2d  mov rax, 0x564E5D1DDA50
0000774654fd4a37  call rax
0000774654fd4a39  movaps xmm15, [rsp]
0000774654fd4a3e  add rsp, 0x40
0000774654fd4a42  vmovaps xmm0, [rsp]
0000774654fd4a47  vmovaps xmm1, [rsp+0x10]
0000774654fd4a4d  vmovaps xmm2, [rsp+0x20]
0000774654fd4a53  vmovaps xmm3, [rsp+0x30]
0000774654fd4a59  vmovaps xmm4, [rsp+0x40]
0000774654fd4a5f  vmovaps xmm5, [rsp+0x50]
0000774654fd4a65  vmovaps xmm6, [rsp+0x60]
0000774654fd4a6b  vmovaps xmm7, [rsp+0x70]
0000774654fd4a71  vmovaps xmm8, [rsp+0x80]
0000774654fd4a7a  vmovaps xmm9, [rsp+0x90]
0000774654fd4a83  vmovaps xmm10, [rsp+0xA0]
0000774654fd4a8c  vmovaps xmm11, [rsp+0xB0]
0000774654fd4a95  vmovaps xmm12, [rsp+0xC0]
0000774654fd4a9e  vmovaps xmm13, [rsp+0xD0]
0000774654fd4aa7  vmovaps xmm14, [rsp+0xE0]
0000774654fd4ab0  add rsp, 0xF0
0000774654fd4ab7  pop r11
0000774654fd4ab9  pop r10
0000774654fd4abb  pop r9
0000774654fd4abd  pop r8
0000774654fd4abf  pop rsi
0000774654fd4ac0  pop rdi
0000774654fd4ac1  pop rdx
0000774654fd4ac2  pop rcx
0000774654fd4ac3  pop rax
0000774654fd4ac4  add rsp, 0x08
0000774654fd4ac8  jmp 0x0000774654FD3678
0000774654fd4acd  sub rsp, 0x08
0000774654fd4ad1  push rax
0000774654fd4ad2  push rcx
0000774654fd4ad3  push rdx
0000774654fd4ad4  push rdi
0000774654fd4ad5  push rsi
0000774654fd4ad6  push r8
0000774654fd4ad8  push r9
0000774654fd4ada  push r10
0000774654fd4adc  push r11
0000774654fd4ade  sub rsp, 0xF0
0000774654fd4ae5  vmovaps [rsp], xmm0
0000774654fd4aea  vmovaps [rsp+0x10], xmm1
0000774654fd4af0  vmovaps [rsp+0x20], xmm2
0000774654fd4af6  vmovaps [rsp+0x30], xmm3
0000774654fd4afc  vmovaps [rsp+0x40], xmm4
0000774654fd4b02  vmovaps [rsp+0x50], xmm5
0000774654fd4b08  vmovaps [rsp+0x60], xmm6
0000774654fd4b0e  vmovaps [rsp+0x70], xmm7
0000774654fd4b14  vmovaps [rsp+0x80], xmm8
0000774654fd4b1d  vmovaps [rsp+0x90], xmm9
0000774654fd4b26  vmovaps [rsp+0xA0], xmm10
0000774654fd4b2f  vmovaps [rsp+0xB0], xmm11
0000774654fd4b38  vmovaps [rsp+0xC0], xmm12
0000774654fd4b41  vmovaps [rsp+0xD0], xmm14
0000774654fd4b4a  vmovaps [rsp+0xE0], xmm15
0000774654fd4b53  sub rsp, 0x40
0000774654fd4b57  lea rdi, [rsp]
0000774654fd4b5b  lea rsi, [rsp+0x10]
0000774654fd4b60  lea rdx, [rsp+0x20]
0000774654fd4b65  lea rcx, [rsp+0x30]
0000774654fd4b6a  mov r8d, 0x00
0000774654fd4b70  lea r9, [r15+0x3A8]
0000774654fd4b77  movaps [rdi], xmm13
0000774654fd4b7b  movaps [rsi], xmm12
0000774654fd4b7f  movaps [rdx], xmm14
0000774654fd4b83  movaps [rcx], xmm1
0000774654fd4b86  mov rax, 0x564E5D1DDA50
0000774654fd4b90  call rax
0000774654fd4b92  movaps xmm13, [rsp]
0000774654fd4b97  add rsp, 0x40
0000774654fd4b9b  vmovaps xmm0, [rsp]
0000774654fd4ba0  vmovaps xmm1, [rsp+0x10]
0000774654fd4ba6  vmovaps xmm2, [rsp+0x20]
0000774654fd4bac  vmovaps xmm3, [rsp+0x30]
0000774654fd4bb2  vmovaps xmm4, [rsp+0x40]
0000774654fd4bb8  vmovaps xmm5, [rsp+0x50]
0000774654fd4bbe  vmovaps xmm6, [rsp+0x60]
0000774654fd4bc4  vmovaps xmm7, [rsp+0x70]
0000774654fd4bca  vmovaps xmm8, [rsp+0x80]
0000774654fd4bd3  vmovaps xmm9, [rsp+0x90]
0000774654fd4bdc  vmovaps xmm10, [rsp+0xA0]
0000774654fd4be5  vmovaps xmm11, [rsp+0xB0]
0000774654fd4bee  vmovaps xmm12, [rsp+0xC0]
0000774654fd4bf7  vmovaps xmm14, [rsp+0xD0]
0000774654fd4c00  vmovaps xmm15, [rsp+0xE0]
0000774654fd4c09  add rsp, 0xF0
0000774654fd4c10  pop r11
0000774654fd4c12  pop r10
0000774654fd4c14  pop r9
0000774654fd4c16  pop r8
0000774654fd4c18  pop rsi
0000774654fd4c19  pop rdi
0000774654fd4c1a  pop rdx
0000774654fd4c1b  pop rcx
0000774654fd4c1c  pop rax
0000774654fd4c1d  add rsp, 0x08
0000774654fd4c21  jmp 0x0000774654FD36AA
0000774654fd4c26  sub rsp, 0x08
0000774654fd4c2a  push rax
0000774654fd4c2b  push rcx
0000774654fd4c2c  push rdx
0000774654fd4c2d  push rdi
0000774654fd4c2e  push rsi
0000774654fd4c2f  push r8
0000774654fd4c31  push r9
0000774654fd4c33  push r10
0000774654fd4c35  push r11
0000774654fd4c37  sub rsp, 0xF0
0000774654fd4c3e  vmovaps [rsp], xmm0
0000774654fd4c43  vmovaps [rsp+0x10], xmm1
0000774654fd4c49  vmovaps [rsp+0x20], xmm2
0000774654fd4c4f  vmovaps [rsp+0x30], xmm3
0000774654fd4c55  vmovaps [rsp+0x40], xmm4
0000774654fd4c5b  vmovaps [rsp+0x50], xmm5
0000774654fd4c61  vmovaps [rsp+0x60], xmm6
0000774654fd4c67  vmovaps [rsp+0x70], xmm7
0000774654fd4c6d  vmovaps [rsp+0x80], xmm8
0000774654fd4c76  vmovaps [rsp+0x90], xmm9
0000774654fd4c7f  vmovaps [rsp+0xA0], xmm10
0000774654fd4c88  vmovaps [rsp+0xB0], xmm11
0000774654fd4c91  vmovaps [rsp+0xC0], xmm13
0000774654fd4c9a  vmovaps [rsp+0xD0], xmm14
0000774654fd4ca3  vmovaps [rsp+0xE0], xmm15
0000774654fd4cac  sub rsp, 0x40
0000774654fd4cb0  lea rdi, [rsp]
0000774654fd4cb4  lea rsi, [rsp+0x10]
0000774654fd4cb9  lea rdx, [rsp+0x20]
0000774654fd4cbe  lea rcx, [rsp+0x30]
0000774654fd4cc3  mov r8d, 0x00
0000774654fd4cc9  lea r9, [r15+0x3A8]
0000774654fd4cd0  movaps [rdi], xmm12
0000774654fd4cd4  movaps [rsi], xmm5
0000774654fd4cd7  movaps [rdx], xmm14
0000774654fd4cdb  movaps [rcx], xmm4
0000774654fd4cde  mov rax, 0x564E5D1DDA50
0000774654fd4ce8  call rax
0000774654fd4cea  movaps xmm12, [rsp]
0000774654fd4cef  add rsp, 0x40
0000774654fd4cf3  vmovaps xmm0, [rsp]
0000774654fd4cf8  vmovaps xmm1, [rsp+0x10]
0000774654fd4cfe  vmovaps xmm2, [rsp+0x20]
0000774654fd4d04  vmovaps xmm3, [rsp+0x30]
0000774654fd4d0a  vmovaps xmm4, [rsp+0x40]
0000774654fd4d10  vmovaps xmm5, [rsp+0x50]
0000774654fd4d16  vmovaps xmm6, [rsp+0x60]
0000774654fd4d1c  vmovaps xmm7, [rsp+0x70]
0000774654fd4d22  vmovaps xmm8, [rsp+0x80]
0000774654fd4d2b  vmovaps xmm9, [rsp+0x90]
0000774654fd4d34  vmovaps xmm10, [rsp+0xA0]
0000774654fd4d3d  vmovaps xmm11, [rsp+0xB0]
0000774654fd4d46  vmovaps xmm13, [rsp+0xC0]
0000774654fd4d4f  vmovaps xmm14, [rsp+0xD0]
0000774654fd4d58  vmovaps xmm15, [rsp+0xE0]
0000774654fd4d61  add rsp, 0xF0
0000774654fd4d68  pop r11
0000774654fd4d6a  pop r10
0000774654fd4d6c  pop r9
0000774654fd4d6e  pop r8
0000774654fd4d70  pop rsi
0000774654fd4d71  pop rdi
0000774654fd4d72  pop rdx
0000774654fd4d73  pop rcx
0000774654fd4d74  pop rax
0000774654fd4d75  add rsp, 0x08
0000774654fd4d79  jmp 0x0000774654FD3720
0000774654fd4d7e  sub rsp, 0x08
0000774654fd4d82  push rax
0000774654fd4d83  push rcx
0000774654fd4d84  push rdx
0000774654fd4d85  push rdi
0000774654fd4d86  push rsi
0000774654fd4d87  push r8
0000774654fd4d89  push r9
0000774654fd4d8b  push r10
0000774654fd4d8d  push r11
0000774654fd4d8f  sub rsp, 0xF0
0000774654fd4d96  vmovaps [rsp], xmm0
0000774654fd4d9b  vmovaps [rsp+0x10], xmm1
0000774654fd4da1  vmovaps [rsp+0x20], xmm2
0000774654fd4da7  vmovaps [rsp+0x30], xmm3
0000774654fd4dad  vmovaps [rsp+0x40], xmm4
0000774654fd4db3  vmovaps [rsp+0x50], xmm5
0000774654fd4db9  vmovaps [rsp+0x60], xmm6
0000774654fd4dbf  vmovaps [rsp+0x70], xmm7
0000774654fd4dc5  vmovaps [rsp+0x80], xmm8
0000774654fd4dce  vmovaps [rsp+0x90], xmm9
0000774654fd4dd7  vmovaps [rsp+0xA0], xmm11
0000774654fd4de0  vmovaps [rsp+0xB0], xmm12
0000774654fd4de9  vmovaps [rsp+0xC0], xmm13
0000774654fd4df2  vmovaps [rsp+0xD0], xmm14
0000774654fd4dfb  vmovaps [rsp+0xE0], xmm15
0000774654fd4e04  sub rsp, 0x40
0000774654fd4e08  lea rdi, [rsp]
0000774654fd4e0c  lea rsi, [rsp+0x10]
0000774654fd4e11  lea rdx, [rsp+0x20]
0000774654fd4e16  lea rcx, [rsp+0x30]
0000774654fd4e1b  mov r8d, 0x00
0000774654fd4e21  lea r9, [r15+0x3A8]
0000774654fd4e28  movaps [rdi], xmm10
0000774654fd4e2c  movaps [rsi], xmm2
0000774654fd4e2f  movaps [rdx], xmm6
0000774654fd4e32  movaps [rcx], xmm14
0000774654fd4e36  mov rax, 0x564E5D1DDA50
0000774654fd4e40  call rax
0000774654fd4e42  movaps xmm10, [rsp]
0000774654fd4e47  add rsp, 0x40
0000774654fd4e4b  vmovaps xmm0, [rsp]
0000774654fd4e50  vmovaps xmm1, [rsp+0x10]
0000774654fd4e56  vmovaps xmm2, [rsp+0x20]
0000774654fd4e5c  vmovaps xmm3, [rsp+0x30]
0000774654fd4e62  vmovaps xmm4, [rsp+0x40]
0000774654fd4e68  vmovaps xmm5, [rsp+0x50]
0000774654fd4e6e  vmovaps xmm6, [rsp+0x60]
0000774654fd4e74  vmovaps xmm7, [rsp+0x70]
0000774654fd4e7a  vmovaps xmm8, [rsp+0x80]
0000774654fd4e83  vmovaps xmm9, [rsp+0x90]
0000774654fd4e8c  vmovaps xmm11, [rsp+0xA0]
0000774654fd4e95  vmovaps xmm12, [rsp+0xB0]
0000774654fd4e9e  vmovaps xmm13, [rsp+0xC0]
0000774654fd4ea7  vmovaps xmm14, [rsp+0xD0]
0000774654fd4eb0  vmovaps xmm15, [rsp+0xE0]
0000774654fd4eb9  add rsp, 0xF0
0000774654fd4ec0  pop r11
0000774654fd4ec2  pop r10
0000774654fd4ec4  pop r9
0000774654fd4ec6  pop r8
0000774654fd4ec8  pop rsi
0000774654fd4ec9  pop rdi
0000774654fd4eca  pop rdx
0000774654fd4ecb  pop rcx
0000774654fd4ecc  pop rax
0000774654fd4ecd  add rsp, 0x08
0000774654fd4ed1  jmp 0x0000774654FD3746
0000774654fd4ed6  call 0x0000774654EE45A0
0000774654fd4edb  jmp 0x0000774654FD3753
0000774654fd4ee0  sub rsp, 0x08
0000774654fd4ee4  push rax
0000774654fd4ee5  push rcx
0000774654fd4ee6  push rdx
0000774654fd4ee7  push rdi
0000774654fd4ee8  push rsi
0000774654fd4ee9  push r8
0000774654fd4eeb  push r9
0000774654fd4eed  push r10
0000774654fd4eef  push r11
0000774654fd4ef1  sub rsp, 0xF0
0000774654fd4ef8  vmovaps [rsp], xmm0
0000774654fd4efd  vmovaps [rsp+0x10], xmm1
0000774654fd4f03  vmovaps [rsp+0x20], xmm2
0000774654fd4f09  vmovaps [rsp+0x30], xmm3
0000774654fd4f0f  vmovaps [rsp+0x40], xmm4
0000774654fd4f15  vmovaps [rsp+0x50], xmm6
0000774654fd4f1b  vmovaps [rsp+0x60], xmm7
0000774654fd4f21  vmovaps [rsp+0x70], xmm8
0000774654fd4f27  vmovaps [rsp+0x80], xmm9
0000774654fd4f30  vmovaps [rsp+0x90], xmm10
0000774654fd4f39  vmovaps [rsp+0xA0], xmm11
0000774654fd4f42  vmovaps [rsp+0xB0], xmm12
0000774654fd4f4b  vmovaps [rsp+0xC0], xmm13
0000774654fd4f54  vmovaps [rsp+0xD0], xmm14
0000774654fd4f5d  vmovaps [rsp+0xE0], xmm15
0000774654fd4f66  sub rsp, 0x40
0000774654fd4f6a  lea rdi, [rsp]
0000774654fd4f6e  lea rsi, [rsp+0x10]
0000774654fd4f73  lea rdx, [rsp+0x20]
0000774654fd4f78  lea rcx, [rsp+0x30]
0000774654fd4f7d  mov r8d, 0x00
0000774654fd4f83  lea r9, [r15+0x3A8]
0000774654fd4f8a  movaps [rdi], xmm5
0000774654fd4f8d  movaps [rsi], xmm15
0000774654fd4f91  movaps [rdx], xmm6
0000774654fd4f94  movaps [rcx], xmm8
0000774654fd4f98  mov rax, 0x564E5D1DDA50
0000774654fd4fa2  call rax
0000774654fd4fa4  movaps xmm5, [rsp]
0000774654fd4fa8  add rsp, 0x40
0000774654fd4fac  vmovaps xmm0, [rsp]
0000774654fd4fb1  vmovaps xmm1, [rsp+0x10]
0000774654fd4fb7  vmovaps xmm2, [rsp+0x20]
0000774654fd4fbd  vmovaps xmm3, [rsp+0x30]
0000774654fd4fc3  vmovaps xmm4, [rsp+0x40]
0000774654fd4fc9  vmovaps xmm6, [rsp+0x50]
0000774654fd4fcf  vmovaps xmm7, [rsp+0x60]
0000774654fd4fd5  vmovaps xmm8, [rsp+0x70]
0000774654fd4fdb  vmovaps xmm9, [rsp+0x80]
0000774654fd4fe4  vmovaps xmm10, [rsp+0x90]
0000774654fd4fed  vmovaps xmm11, [rsp+0xA0]
0000774654fd4ff6  vmovaps xmm12, [rsp+0xB0]
0000774654fd4fff  vmovaps xmm13, [rsp+0xC0]
0000774654fd5008  vmovaps xmm14, [rsp+0xD0]
0000774654fd5011  vmovaps xmm15, [rsp+0xE0]
0000774654fd501a  add rsp, 0xF0
0000774654fd5021  pop r11
0000774654fd5023  pop r10
0000774654fd5025  pop r9
0000774654fd5027  pop r8
0000774654fd5029  pop rsi
0000774654fd502a  pop rdi
0000774654fd502b  pop rdx
0000774654fd502c  pop rcx
0000774654fd502d  pop rax
0000774654fd502e  add rsp, 0x08
0000774654fd5032  jmp 0x0000774654FD3789
0000774654fd5037  sub rsp, 0x08
0000774654fd503b  push rax
0000774654fd503c  push rcx
0000774654fd503d  push rdx
0000774654fd503e  push rdi
0000774654fd503f  push rsi
0000774654fd5040  push r8
0000774654fd5042  push r9
0000774654fd5044  push r10
0000774654fd5046  push r11
0000774654fd5048  sub rsp, 0xF0
0000774654fd504f  vmovaps [rsp], xmm0
0000774654fd5054  vmovaps [rsp+0x10], xmm1
0000774654fd505a  vmovaps [rsp+0x20], xmm2
0000774654fd5060  vmovaps [rsp+0x30], xmm3
0000774654fd5066  vmovaps [rsp+0x40], xmm4
0000774654fd506c  vmovaps [rsp+0x50], xmm5
0000774654fd5072  vmovaps [rsp+0x60], xmm6
0000774654fd5078  vmovaps [rsp+0x70], xmm7
0000774654fd507e  vmovaps [rsp+0x80], xmm9
0000774654fd5087  vmovaps [rsp+0x90], xmm10
0000774654fd5090  vmovaps [rsp+0xA0], xmm11
0000774654fd5099  vmovaps [rsp+0xB0], xmm12
0000774654fd50a2  vmovaps [rsp+0xC0], xmm13
0000774654fd50ab  vmovaps [rsp+0xD0], xmm14
0000774654fd50b4  vmovaps [rsp+0xE0], xmm15
0000774654fd50bd  sub rsp, 0x40
0000774654fd50c1  lea rdi, [rsp]
0000774654fd50c5  lea rsi, [rsp+0x10]
0000774654fd50ca  lea rdx, [rsp+0x20]
0000774654fd50cf  lea rcx, [rsp+0x30]
0000774654fd50d4  mov r8d, 0x00
0000774654fd50da  lea r9, [r15+0x3A8]
0000774654fd50e1  movaps [rdi], xmm8
0000774654fd50e5  movaps [rsi], xmm13
0000774654fd50e9  movaps [rdx], xmm1
0000774654fd50ec  movaps [rcx], xmm15
0000774654fd50f0  mov rax, 0x564E5D1DDA50
0000774654fd50fa  call rax
0000774654fd50fc  movaps xmm8, [rsp]
0000774654fd5101  add rsp, 0x40
0000774654fd5105  vmovaps xmm0, [rsp]
0000774654fd510a  vmovaps xmm1, [rsp+0x10]
0000774654fd5110  vmovaps xmm2, [rsp+0x20]
0000774654fd5116  vmovaps xmm3, [rsp+0x30]
0000774654fd511c  vmovaps xmm4, [rsp+0x40]
0000774654fd5122  vmovaps xmm5, [rsp+0x50]
0000774654fd5128  vmovaps xmm6, [rsp+0x60]
0000774654fd512e  vmovaps xmm7, [rsp+0x70]
0000774654fd5134  vmovaps xmm9, [rsp+0x80]
0000774654fd513d  vmovaps xmm10, [rsp+0x90]
0000774654fd5146  vmovaps xmm11, [rsp+0xA0]
0000774654fd514f  vmovaps xmm12, [rsp+0xB0]
0000774654fd5158  vmovaps xmm13, [rsp+0xC0]
0000774654fd5161  vmovaps xmm14, [rsp+0xD0]
0000774654fd516a  vmovaps xmm15, [rsp+0xE0]
0000774654fd5173  add rsp, 0xF0
0000774654fd517a  pop r11
0000774654fd517c  pop r10
0000774654fd517e  pop r9
0000774654fd5180  pop r8
0000774654fd5182  pop rsi
0000774654fd5183  pop rdi
0000774654fd5184  pop rdx
0000774654fd5185  pop rcx
0000774654fd5186  pop rax
0000774654fd5187  add rsp, 0x08
0000774654fd518b  jmp 0x0000774654FD37AF
0000774654fd5190  call 0x0000774654EE5820
0000774654fd5195  jmp 0x0000774654FD37D2
0000774654fd519a  call 0x0000774654EE3320
0000774654fd519f  jmp 0x0000774654FD37DC
0000774654fd51a4  sub rsp, 0x08
0000774654fd51a8  push rax
0000774654fd51a9  push rcx
0000774654fd51aa  push rdx
0000774654fd51ab  push rdi
0000774654fd51ac  push rsi
0000774654fd51ad  push r8
0000774654fd51af  push r9
0000774654fd51b1  push r10
0000774654fd51b3  push r11
0000774654fd51b5  sub rsp, 0xF0
0000774654fd51bc  vmovaps [rsp], xmm0
0000774654fd51c1  vmovaps [rsp+0x10], xmm1
0000774654fd51c7  vmovaps [rsp+0x20], xmm2
0000774654fd51cd  vmovaps [rsp+0x30], xmm3
0000774654fd51d3  vmovaps [rsp+0x40], xmm5
0000774654fd51d9  vmovaps [rsp+0x50], xmm6
0000774654fd51df  vmovaps [rsp+0x60], xmm7
0000774654fd51e5  vmovaps [rsp+0x70], xmm8
0000774654fd51eb  vmovaps [rsp+0x80], xmm9
0000774654fd51f4  vmovaps [rsp+0x90], xmm10
0000774654fd51fd  vmovaps [rsp+0xA0], xmm11
0000774654fd5206  vmovaps [rsp+0xB0], xmm12
0000774654fd520f  vmovaps [rsp+0xC0], xmm13
0000774654fd5218  vmovaps [rsp+0xD0], xmm14
0000774654fd5221  vmovaps [rsp+0xE0], xmm15
0000774654fd522a  sub rsp, 0x40
0000774654fd522e  lea rdi, [rsp]
0000774654fd5232  lea rsi, [rsp+0x10]
0000774654fd5237  lea rdx, [rsp+0x20]
0000774654fd523c  lea rcx, [rsp+0x30]
0000774654fd5241  mov r8d, 0x00
0000774654fd5247  lea r9, [r15+0x3A8]
0000774654fd524e  movaps [rdi], xmm4
0000774654fd5251  movaps [rsi], xmm12
0000774654fd5255  movaps [rdx], xmm9
0000774654fd5259  movaps [rcx], xmm6
0000774654fd525c  mov rax, 0x564E5D1DDA50
0000774654fd5266  call rax
0000774654fd5268  movaps xmm4, [rsp]
0000774654fd526c  add rsp, 0x40
0000774654fd5270  vmovaps xmm0, [rsp]
0000774654fd5275  vmovaps xmm1, [rsp+0x10]
0000774654fd527b  vmovaps xmm2, [rsp+0x20]
0000774654fd5281  vmovaps xmm3, [rsp+0x30]
0000774654fd5287  vmovaps xmm5, [rsp+0x40]
0000774654fd528d  vmovaps xmm6, [rsp+0x50]
0000774654fd5293  vmovaps xmm7, [rsp+0x60]
0000774654fd5299  vmovaps xmm8, [rsp+0x70]
0000774654fd529f  vmovaps xmm9, [rsp+0x80]
0000774654fd52a8  vmovaps xmm10, [rsp+0x90]
0000774654fd52b1  vmovaps xmm11, [rsp+0xA0]
0000774654fd52ba  vmovaps xmm12, [rsp+0xB0]
0000774654fd52c3  vmovaps xmm13, [rsp+0xC0]
0000774654fd52cc  vmovaps xmm14, [rsp+0xD0]
0000774654fd52d5  vmovaps xmm15, [rsp+0xE0]
0000774654fd52de  add rsp, 0xF0
0000774654fd52e5  pop r11
0000774654fd52e7  pop r10
0000774654fd52e9  pop r9
0000774654fd52eb  pop r8
0000774654fd52ed  pop rsi
0000774654fd52ee  pop rdi
0000774654fd52ef  pop rdx
0000774654fd52f0  pop rcx
0000774654fd52f1  pop rax
0000774654fd52f2  add rsp, 0x08
0000774654fd52f6  jmp 0x0000774654FD3814
0000774654fd52fb  sub rsp, 0x08
0000774654fd52ff  push rax
0000774654fd5300  push rcx
0000774654fd5301  push rdx
0000774654fd5302  push rdi
0000774654fd5303  push rsi
0000774654fd5304  push r8
0000774654fd5306  push r9
0000774654fd5308  push r10
0000774654fd530a  push r11
0000774654fd530c  sub rsp, 0xF0
0000774654fd5313  vmovaps [rsp], xmm0
0000774654fd5318  vmovaps [rsp+0x10], xmm1
0000774654fd531e  vmovaps [rsp+0x20], xmm2
0000774654fd5324  vmovaps [rsp+0x30], xmm3
0000774654fd532a  vmovaps [rsp+0x40], xmm4
0000774654fd5330  vmovaps [rsp+0x50], xmm5
0000774654fd5336  vmovaps [rsp+0x60], xmm6
0000774654fd533c  vmovaps [rsp+0x70], xmm7
0000774654fd5342  vmovaps [rsp+0x80], xmm8
0000774654fd534b  vmovaps [rsp+0x90], xmm10
0000774654fd5354  vmovaps [rsp+0xA0], xmm11
0000774654fd535d  vmovaps [rsp+0xB0], xmm12
0000774654fd5366  vmovaps [rsp+0xC0], xmm13
0000774654fd536f  vmovaps [rsp+0xD0], xmm14
0000774654fd5378  vmovaps [rsp+0xE0], xmm15
0000774654fd5381  sub rsp, 0x40
0000774654fd5385  lea rdi, [rsp]
0000774654fd5389  lea rsi, [rsp+0x10]
0000774654fd538e  lea rdx, [rsp+0x20]
0000774654fd5393  lea rcx, [rsp+0x30]
0000774654fd5398  mov r8d, 0x00
0000774654fd539e  lea r9, [r15+0x3A8]
0000774654fd53a5  movaps [rdi], xmm9
0000774654fd53a9  movaps [rsi], xmm10
0000774654fd53ad  movaps [rdx], xmm1
0000774654fd53b0  movaps [rcx], xmm12
0000774654fd53b4  mov rax, 0x564E5D1DDA50
0000774654fd53be  call rax
0000774654fd53c0  movaps xmm9, [rsp]
0000774654fd53c5  add rsp, 0x40
0000774654fd53c9  vmovaps xmm0, [rsp]
0000774654fd53ce  vmovaps xmm1, [rsp+0x10]
0000774654fd53d4  vmovaps xmm2, [rsp+0x20]
0000774654fd53da  vmovaps xmm3, [rsp+0x30]
0000774654fd53e0  vmovaps xmm4, [rsp+0x40]
0000774654fd53e6  vmovaps xmm5, [rsp+0x50]
0000774654fd53ec  vmovaps xmm6, [rsp+0x60]
0000774654fd53f2  vmovaps xmm7, [rsp+0x70]
0000774654fd53f8  vmovaps xmm8, [rsp+0x80]
0000774654fd5401  vmovaps xmm10, [rsp+0x90]
0000774654fd540a  vmovaps xmm11, [rsp+0xA0]
0000774654fd5413  vmovaps xmm12, [rsp+0xB0]
0000774654fd541c  vmovaps xmm13, [rsp+0xC0]
0000774654fd5425  vmovaps xmm14, [rsp+0xD0]
0000774654fd542e  vmovaps xmm15, [rsp+0xE0]
0000774654fd5437  add rsp, 0xF0
0000774654fd543e  pop r11
0000774654fd5440  pop r10
0000774654fd5442  pop r9
0000774654fd5444  pop r8
0000774654fd5446  pop rsi
0000774654fd5447  pop rdi
0000774654fd5448  pop rdx
0000774654fd5449  pop rcx
0000774654fd544a  pop rax
0000774654fd544b  add rsp, 0x08
0000774654fd544f  jmp 0x0000774654FD383D
0000774654fd5454  sub rsp, 0x08
0000774654fd5458  push rax
0000774654fd5459  push rcx
0000774654fd545a  push rdx
0000774654fd545b  push rdi
0000774654fd545c  push rsi
0000774654fd545d  push r8
0000774654fd545f  push r9
0000774654fd5461  push r10
0000774654fd5463  push r11
0000774654fd5465  sub rsp, 0xF0
0000774654fd546c  vmovaps [rsp], xmm0
0000774654fd5471  vmovaps [rsp+0x10], xmm1
0000774654fd5477  vmovaps [rsp+0x20], xmm2
0000774654fd547d  vmovaps [rsp+0x30], xmm3
0000774654fd5483  vmovaps [rsp+0x40], xmm4
0000774654fd5489  vmovaps [rsp+0x50], xmm5
0000774654fd548f  vmovaps [rsp+0x60], xmm6
0000774654fd5495  vmovaps [rsp+0x70], xmm7
0000774654fd549b  vmovaps [rsp+0x80], xmm8
0000774654fd54a4  vmovaps [rsp+0x90], xmm9
0000774654fd54ad  vmovaps [rsp+0xA0], xmm11
0000774654fd54b6  vmovaps [rsp+0xB0], xmm12
0000774654fd54bf  vmovaps [rsp+0xC0], xmm13
0000774654fd54c8  vmovaps [rsp+0xD0], xmm14
0000774654fd54d1  vmovaps [rsp+0xE0], xmm15
0000774654fd54da  sub rsp, 0x40
0000774654fd54de  lea rdi, [rsp]
0000774654fd54e2  lea rsi, [rsp+0x10]
0000774654fd54e7  lea rdx, [rsp+0x20]
0000774654fd54ec  lea rcx, [rsp+0x30]
0000774654fd54f1  mov r8d, 0x00
0000774654fd54f7  lea r9, [r15+0x3A8]
0000774654fd54fe  movaps [rdi], xmm10
0000774654fd5502  movaps [rsi], xmm5
0000774654fd5505  movaps [rdx], xmm12
0000774654fd5509  movaps [rcx], xmm1
0000774654fd550c  mov rax, 0x564E5D1DDA50
0000774654fd5516  call rax
0000774654fd5518  movaps xmm10, [rsp]
0000774654fd551d  add rsp, 0x40
0000774654fd5521  vmovaps xmm0, [rsp]
0000774654fd5526  vmovaps xmm1, [rsp+0x10]
0000774654fd552c  vmovaps xmm2, [rsp+0x20]
0000774654fd5532  vmovaps xmm3, [rsp+0x30]
0000774654fd5538  vmovaps xmm4, [rsp+0x40]
0000774654fd553e  vmovaps xmm5, [rsp+0x50]
0000774654fd5544  vmovaps xmm6, [rsp+0x60]
0000774654fd554a  vmovaps xmm7, [rsp+0x70]
0000774654fd5550  vmovaps xmm8, [rsp+0x80]
0000774654fd5559  vmovaps xmm9, [rsp+0x90]
0000774654fd5562  vmovaps xmm11, [rsp+0xA0]
0000774654fd556b  vmovaps xmm12, [rsp+0xB0]
0000774654fd5574  vmovaps xmm13, [rsp+0xC0]
0000774654fd557d  vmovaps xmm14, [rsp+0xD0]
0000774654fd5586  vmovaps xmm15, [rsp+0xE0]
0000774654fd558f  add rsp, 0xF0
0000774654fd5596  pop r11
0000774654fd5598  pop r10
0000774654fd559a  pop r9
0000774654fd559c  pop r8
0000774654fd559e  pop rsi
0000774654fd559f  pop rdi
0000774654fd55a0  pop rdx
0000774654fd55a1  pop rcx
0000774654fd55a2  pop rax
0000774654fd55a3  add rsp, 0x08
0000774654fd55a7  jmp 0x0000774654FD386C
0000774654fd55ac  sub rsp, 0x08
0000774654fd55b0  push rax
0000774654fd55b1  push rcx
0000774654fd55b2  push rdx
0000774654fd55b3  push rdi
0000774654fd55b4  push rsi
0000774654fd55b5  push r8
0000774654fd55b7  push r9
0000774654fd55b9  push r10
0000774654fd55bb  push r11
0000774654fd55bd  sub rsp, 0xF0
0000774654fd55c4  vmovaps [rsp], xmm0
0000774654fd55c9  vmovaps [rsp+0x10], xmm1
0000774654fd55cf  vmovaps [rsp+0x20], xmm2
0000774654fd55d5  vmovaps [rsp+0x30], xmm3
0000774654fd55db  vmovaps [rsp+0x40], xmm4
0000774654fd55e1  vmovaps [rsp+0x50], xmm5
0000774654fd55e7  vmovaps [rsp+0x60], xmm7
0000774654fd55ed  vmovaps [rsp+0x70], xmm8
0000774654fd55f3  vmovaps [rsp+0x80], xmm9
0000774654fd55fc  vmovaps [rsp+0x90], xmm10
0000774654fd5605  vmovaps [rsp+0xA0], xmm11
0000774654fd560e  vmovaps [rsp+0xB0], xmm12
0000774654fd5617  vmovaps [rsp+0xC0], xmm13
0000774654fd5620  vmovaps [rsp+0xD0], xmm14
0000774654fd5629  vmovaps [rsp+0xE0], xmm15
0000774654fd5632  sub rsp, 0x40
0000774654fd5636  lea rdi, [rsp]
0000774654fd563a  lea rsi, [rsp+0x10]
0000774654fd563f  lea rdx, [rsp+0x20]
0000774654fd5644  lea rcx, [rsp+0x30]
0000774654fd5649  mov r8d, 0x00
0000774654fd564f  lea r9, [r15+0x3A8]
0000774654fd5656  movaps [rdi], xmm6
0000774654fd5659  movaps [rsi], xmm8
0000774654fd565d  movaps [rdx], xmm12
0000774654fd5661  movaps [rcx], xmm1
0000774654fd5664  mov rax, 0x564E5D1DDA50
0000774654fd566e  call rax
0000774654fd5670  movaps xmm6, [rsp]
0000774654fd5674  add rsp, 0x40
0000774654fd5678  vmovaps xmm0, [rsp]
0000774654fd567d  vmovaps xmm1, [rsp+0x10]
0000774654fd5683  vmovaps xmm2, [rsp+0x20]
0000774654fd5689  vmovaps xmm3, [rsp+0x30]
0000774654fd568f  vmovaps xmm4, [rsp+0x40]
0000774654fd5695  vmovaps xmm5, [rsp+0x50]
0000774654fd569b  vmovaps xmm7, [rsp+0x60]
0000774654fd56a1  vmovaps xmm8, [rsp+0x70]
0000774654fd56a7  vmovaps xmm9, [rsp+0x80]
0000774654fd56b0  vmovaps xmm10, [rsp+0x90]
0000774654fd56b9  vmovaps xmm11, [rsp+0xA0]
0000774654fd56c2  vmovaps xmm12, [rsp+0xB0]
0000774654fd56cb  vmovaps xmm13, [rsp+0xC0]
0000774654fd56d4  vmovaps xmm14, [rsp+0xD0]
0000774654fd56dd  vmovaps xmm15, [rsp+0xE0]
0000774654fd56e6  add rsp, 0xF0
0000774654fd56ed  pop r11
0000774654fd56ef  pop r10
0000774654fd56f1  pop r9
0000774654fd56f3  pop r8
0000774654fd56f5  pop rsi
0000774654fd56f6  pop rdi
0000774654fd56f7  pop rdx
0000774654fd56f8  pop rcx
0000774654fd56f9  pop rax
0000774654fd56fa  add rsp, 0x08
0000774654fd56fe  jmp 0x0000774654FD389A
0000774654fd5703  call 0x0000774654ED64F0
0000774654fd5708  jmp 0x0000774654FD38A4
0000774654fd570d  call 0x0000774654EE20A0
0000774654fd5712  jmp 0x0000774654FD38AE
0000774654fd5717  sub rsp, 0x08
0000774654fd571b  push rax
0000774654fd571c  push rcx
0000774654fd571d  push rdx
0000774654fd571e  push rdi
0000774654fd571f  push rsi
0000774654fd5720  push r8
0000774654fd5722  push r9
0000774654fd5724  push r10
0000774654fd5726  push r11
0000774654fd5728  sub rsp, 0xF0
0000774654fd572f  vmovaps [rsp], xmm0
0000774654fd5734  vmovaps [rsp+0x10], xmm1
0000774654fd573a  vmovaps [rsp+0x20], xmm2
0000774654fd5740  vmovaps [rsp+0x30], xmm3
0000774654fd5746  vmovaps [rsp+0x40], xmm4
0000774654fd574c  vmovaps [rsp+0x50], xmm5
0000774654fd5752  vmovaps [rsp+0x60], xmm6
0000774654fd5758  vmovaps [rsp+0x70], xmm7
0000774654fd575e  vmovaps [rsp+0x80], xmm9
0000774654fd5767  vmovaps [rsp+0x90], xmm10
0000774654fd5770  vmovaps [rsp+0xA0], xmm11
0000774654fd5779  vmovaps [rsp+0xB0], xmm12
0000774654fd5782  vmovaps [rsp+0xC0], xmm13
0000774654fd578b  vmovaps [rsp+0xD0], xmm14
0000774654fd5794  vmovaps [rsp+0xE0], xmm15
0000774654fd579d  sub rsp, 0x40
0000774654fd57a1  lea rdi, [rsp]
0000774654fd57a5  lea rsi, [rsp+0x10]
0000774654fd57aa  lea rdx, [rsp+0x20]
0000774654fd57af  lea rcx, [rsp+0x30]
0000774654fd57b4  mov r8d, 0x00
0000774654fd57ba  lea r9, [r15+0x3A8]
0000774654fd57c1  movaps [rdi], xmm8
0000774654fd57c5  movaps [rsi], xmm4
0000774654fd57c8  movaps [rdx], xmm13
0000774654fd57cc  movaps [rcx], xmm11
0000774654fd57d0  mov rax, 0x564E5D1DDA50
0000774654fd57da  call rax
0000774654fd57dc  movaps xmm8, [rsp]
0000774654fd57e1  add rsp, 0x40
0000774654fd57e5  vmovaps xmm0, [rsp]
0000774654fd57ea  vmovaps xmm1, [rsp+0x10]
0000774654fd57f0  vmovaps xmm2, [rsp+0x20]
0000774654fd57f6  vmovaps xmm3, [rsp+0x30]
0000774654fd57fc  vmovaps xmm4, [rsp+0x40]
0000774654fd5802  vmovaps xmm5, [rsp+0x50]
0000774654fd5808  vmovaps xmm6, [rsp+0x60]
0000774654fd580e  vmovaps xmm7, [rsp+0x70]
0000774654fd5814  vmovaps xmm9, [rsp+0x80]
0000774654fd581d  vmovaps xmm10, [rsp+0x90]
0000774654fd5826  vmovaps xmm11, [rsp+0xA0]
0000774654fd582f  vmovaps xmm12, [rsp+0xB0]
0000774654fd5838  vmovaps xmm13, [rsp+0xC0]
0000774654fd5841  vmovaps xmm14, [rsp+0xD0]
0000774654fd584a  vmovaps xmm15, [rsp+0xE0]
0000774654fd5853  add rsp, 0xF0
0000774654fd585a  pop r11
0000774654fd585c  pop r10
0000774654fd585e  pop r9
0000774654fd5860  pop r8
0000774654fd5862  pop rsi
0000774654fd5863  pop rdi
0000774654fd5864  pop rdx
0000774654fd5865  pop rcx
0000774654fd5866  pop rax
0000774654fd5867  add rsp, 0x08
0000774654fd586b  jmp 0x0000774654FD38E4
0000774654fd5870  sub rsp, 0x08
0000774654fd5874  push rax
0000774654fd5875  push rcx
0000774654fd5876  push rdx
0000774654fd5877  push rdi
0000774654fd5878  push rsi
0000774654fd5879  push r8
0000774654fd587b  push r9
0000774654fd587d  push r10
0000774654fd587f  push r11
0000774654fd5881  sub rsp, 0xF0
0000774654fd5888  vmovaps [rsp], xmm0
0000774654fd588d  vmovaps [rsp+0x10], xmm1
0000774654fd5893  vmovaps [rsp+0x20], xmm2
0000774654fd5899  vmovaps [rsp+0x30], xmm3
0000774654fd589f  vmovaps [rsp+0x40], xmm4
0000774654fd58a5  vmovaps [rsp+0x50], xmm5
0000774654fd58ab  vmovaps [rsp+0x60], xmm6
0000774654fd58b1  vmovaps [rsp+0x70], xmm7
0000774654fd58b7  vmovaps [rsp+0x80], xmm8
0000774654fd58c0  vmovaps [rsp+0x90], xmm9
0000774654fd58c9  vmovaps [rsp+0xA0], xmm10
0000774654fd58d2  vmovaps [rsp+0xB0], xmm12
0000774654fd58db  vmovaps [rsp+0xC0], xmm13
0000774654fd58e4  vmovaps [rsp+0xD0], xmm14
0000774654fd58ed  vmovaps [rsp+0xE0], xmm15
0000774654fd58f6  sub rsp, 0x40
0000774654fd58fa  lea rdi, [rsp]
0000774654fd58fe  lea rsi, [rsp+0x10]
0000774654fd5903  lea rdx, [rsp+0x20]
0000774654fd5908  lea rcx, [rsp+0x30]
0000774654fd590d  mov r8d, 0x00
0000774654fd5913  lea r9, [r15+0x3A8]
0000774654fd591a  movaps [rdi], xmm11
0000774654fd591e  movaps [rsi], xmm9
0000774654fd5922  movaps [rdx], xmm1
0000774654fd5925  movaps [rcx], xmm13
0000774654fd5929  mov rax, 0x564E5D1DDA50
0000774654fd5933  call rax
0000774654fd5935  movaps xmm11, [rsp]
0000774654fd593a  add rsp, 0x40
0000774654fd593e  vmovaps xmm0, [rsp]
0000774654fd5943  vmovaps xmm1, [rsp+0x10]
0000774654fd5949  vmovaps xmm2, [rsp+0x20]
0000774654fd594f  vmovaps xmm3, [rsp+0x30]
0000774654fd5955  vmovaps xmm4, [rsp+0x40]
0000774654fd595b  vmovaps xmm5, [rsp+0x50]
0000774654fd5961  vmovaps xmm6, [rsp+0x60]
0000774654fd5967  vmovaps xmm7, [rsp+0x70]
0000774654fd596d  vmovaps xmm8, [rsp+0x80]
0000774654fd5976  vmovaps xmm9, [rsp+0x90]
0000774654fd597f  vmovaps xmm10, [rsp+0xA0]
0000774654fd5988  vmovaps xmm12, [rsp+0xB0]
0000774654fd5991  vmovaps xmm13, [rsp+0xC0]
0000774654fd599a  vmovaps xmm14, [rsp+0xD0]
0000774654fd59a3  vmovaps xmm15, [rsp+0xE0]
0000774654fd59ac  add rsp, 0xF0
0000774654fd59b3  pop r11
0000774654fd59b5  pop r10
0000774654fd59b7  pop r9
0000774654fd59b9  pop r8
0000774654fd59bb  pop rsi
0000774654fd59bc  pop rdi
0000774654fd59bd  pop rdx
0000774654fd59be  pop rcx
0000774654fd59bf  pop rax
0000774654fd59c0  add rsp, 0x08
0000774654fd59c4  jmp 0x0000774654FD390A
0000774654fd59c9  sub rsp, 0x08
0000774654fd59cd  push rax
0000774654fd59ce  push rcx
0000774654fd59cf  push rdx
0000774654fd59d0  push rdi
0000774654fd59d1  push rsi
0000774654fd59d2  push r8
0000774654fd59d4  push r9
0000774654fd59d6  push r10
0000774654fd59d8  push r11
0000774654fd59da  sub rsp, 0xF0
0000774654fd59e1  vmovaps [rsp], xmm0
0000774654fd59e6  vmovaps [rsp+0x10], xmm1
0000774654fd59ec  vmovaps [rsp+0x20], xmm2
0000774654fd59f2  vmovaps [rsp+0x30], xmm3
0000774654fd59f8  vmovaps [rsp+0x40], xmm4
0000774654fd59fe  vmovaps [rsp+0x50], xmm5
0000774654fd5a04  vmovaps [rsp+0x60], xmm6
0000774654fd5a0a  vmovaps [rsp+0x70], xmm7
0000774654fd5a10  vmovaps [rsp+0x80], xmm8
0000774654fd5a19  vmovaps [rsp+0x90], xmm9
0000774654fd5a22  vmovaps [rsp+0xA0], xmm10
0000774654fd5a2b  vmovaps [rsp+0xB0], xmm11
0000774654fd5a34  vmovaps [rsp+0xC0], xmm12
0000774654fd5a3d  vmovaps [rsp+0xD0], xmm14
0000774654fd5a46  vmovaps [rsp+0xE0], xmm15
0000774654fd5a4f  sub rsp, 0x40
0000774654fd5a53  lea rdi, [rsp]
0000774654fd5a57  lea rsi, [rsp+0x10]
0000774654fd5a5c  lea rdx, [rsp+0x20]
0000774654fd5a61  lea rcx, [rsp+0x30]
0000774654fd5a66  mov r8d, 0x00
0000774654fd5a6c  lea r9, [r15+0x3A8]
0000774654fd5a73  movaps [rdi], xmm13
0000774654fd5a77  movaps [rsi], xmm10
0000774654fd5a7b  movaps [rdx], xmm7
0000774654fd5a7e  movaps [rcx], xmm1
0000774654fd5a81  mov rax, 0x564E5D1DDA50
0000774654fd5a8b  call rax
0000774654fd5a8d  movaps xmm13, [rsp]
0000774654fd5a92  add rsp, 0x40
0000774654fd5a96  vmovaps xmm0, [rsp]
0000774654fd5a9b  vmovaps xmm1, [rsp+0x10]
0000774654fd5aa1  vmovaps xmm2, [rsp+0x20]
0000774654fd5aa7  vmovaps xmm3, [rsp+0x30]
0000774654fd5aad  vmovaps xmm4, [rsp+0x40]
0000774654fd5ab3  vmovaps xmm5, [rsp+0x50]
0000774654fd5ab9  vmovaps xmm6, [rsp+0x60]
0000774654fd5abf  vmovaps xmm7, [rsp+0x70]
0000774654fd5ac5  vmovaps xmm8, [rsp+0x80]
0000774654fd5ace  vmovaps xmm9, [rsp+0x90]
0000774654fd5ad7  vmovaps xmm10, [rsp+0xA0]
0000774654fd5ae0  vmovaps xmm11, [rsp+0xB0]
0000774654fd5ae9  vmovaps xmm12, [rsp+0xC0]
0000774654fd5af2  vmovaps xmm14, [rsp+0xD0]
0000774654fd5afb  vmovaps xmm15, [rsp+0xE0]
0000774654fd5b04  add rsp, 0xF0
0000774654fd5b0b  pop r11
0000774654fd5b0d  pop r10
0000774654fd5b0f  pop r9
0000774654fd5b11  pop r8
0000774654fd5b13  pop rsi
0000774654fd5b14  pop rdi
0000774654fd5b15  pop rdx
0000774654fd5b16  pop rcx
0000774654fd5b17  pop rax
0000774654fd5b18  add rsp, 0x08
0000774654fd5b1c  jmp 0x0000774654FD3930
0000774654fd5b21  sub rsp, 0x08
0000774654fd5b25  push rax
0000774654fd5b26  push rcx
0000774654fd5b27  push rdx
0000774654fd5b28  push rdi
0000774654fd5b29  push rsi
0000774654fd5b2a  push r8
0000774654fd5b2c  push r9
0000774654fd5b2e  push r10
0000774654fd5b30  push r11
0000774654fd5b32  sub rsp, 0xF0
0000774654fd5b39  vmovaps [rsp], xmm0
0000774654fd5b3e  vmovaps [rsp+0x10], xmm1
0000774654fd5b44  vmovaps [rsp+0x20], xmm2
0000774654fd5b4a  vmovaps [rsp+0x30], xmm3
0000774654fd5b50  vmovaps [rsp+0x40], xmm4
0000774654fd5b56  vmovaps [rsp+0x50], xmm5
0000774654fd5b5c  vmovaps [rsp+0x60], xmm6
0000774654fd5b62  vmovaps [rsp+0x70], xmm7
0000774654fd5b68  vmovaps [rsp+0x80], xmm8
0000774654fd5b71  vmovaps [rsp+0x90], xmm9
0000774654fd5b7a  vmovaps [rsp+0xA0], xmm11
0000774654fd5b83  vmovaps [rsp+0xB0], xmm12
0000774654fd5b8c  vmovaps [rsp+0xC0], xmm13
0000774654fd5b95  vmovaps [rsp+0xD0], xmm14
0000774654fd5b9e  vmovaps [rsp+0xE0], xmm15
0000774654fd5ba7  sub rsp, 0x40
0000774654fd5bab  lea rdi, [rsp]
0000774654fd5baf  lea rsi, [rsp+0x10]
0000774654fd5bb4  lea rdx, [rsp+0x20]
0000774654fd5bb9  lea rcx, [rsp+0x30]
0000774654fd5bbe  mov r8d, 0x00
0000774654fd5bc4  lea r9, [r15+0x3A8]
0000774654fd5bcb  movaps [rdi], xmm10
0000774654fd5bcf  movaps [rsi], xmm6
0000774654fd5bd2  movaps [rdx], xmm15
0000774654fd5bd6  movaps [rcx], xmm1
0000774654fd5bd9  mov rax, 0x564E5D1DDA50
0000774654fd5be3  call rax
0000774654fd5be5  movaps xmm10, [rsp]
0000774654fd5bea  add rsp, 0x40
0000774654fd5bee  vmovaps xmm0, [rsp]
0000774654fd5bf3  vmovaps xmm1, [rsp+0x10]
0000774654fd5bf9  vmovaps xmm2, [rsp+0x20]
0000774654fd5bff  vmovaps xmm3, [rsp+0x30]
0000774654fd5c05  vmovaps xmm4, [rsp+0x40]
0000774654fd5c0b  vmovaps xmm5, [rsp+0x50]
0000774654fd5c11  vmovaps xmm6, [rsp+0x60]
0000774654fd5c17  vmovaps xmm7, [rsp+0x70]
0000774654fd5c1d  vmovaps xmm8, [rsp+0x80]
0000774654fd5c26  vmovaps xmm9, [rsp+0x90]
0000774654fd5c2f  vmovaps xmm11, [rsp+0xA0]
0000774654fd5c38  vmovaps xmm12, [rsp+0xB0]
0000774654fd5c41  vmovaps xmm13, [rsp+0xC0]
0000774654fd5c4a  vmovaps xmm14, [rsp+0xD0]
0000774654fd5c53  vmovaps xmm15, [rsp+0xE0]
0000774654fd5c5c  add rsp, 0xF0
0000774654fd5c63  pop r11
0000774654fd5c65  pop r10
0000774654fd5c67  pop r9
0000774654fd5c69  pop r8
0000774654fd5c6b  pop rsi
0000774654fd5c6c  pop rdi
0000774654fd5c6d  pop rdx
0000774654fd5c6e  pop rcx
0000774654fd5c6f  pop rax
0000774654fd5c70  add rsp, 0x08
0000774654fd5c74  jmp 0x0000774654FD3956
0000774654fd5c79  call 0x0000774654ED64F0
0000774654fd5c7e  jmp 0x0000774654FD3960
0000774654fd5c83  call 0x0000774654EE5820
0000774654fd5c88  jmp 0x0000774654FD396A
0000774654fd5c8d  sub rsp, 0x08
0000774654fd5c91  push rax
0000774654fd5c92  push rcx
0000774654fd5c93  push rdx
0000774654fd5c94  push rdi
0000774654fd5c95  push rsi
0000774654fd5c96  push r8
0000774654fd5c98  push r9
0000774654fd5c9a  push r10
0000774654fd5c9c  push r11
0000774654fd5c9e  sub rsp, 0xF0
0000774654fd5ca5  vmovaps [rsp], xmm0
0000774654fd5caa  vmovaps [rsp+0x10], xmm1
0000774654fd5cb0  vmovaps [rsp+0x20], xmm2
0000774654fd5cb6  vmovaps [rsp+0x30], xmm3
0000774654fd5cbc  vmovaps [rsp+0x40], xmm4
0000774654fd5cc2  vmovaps [rsp+0x50], xmm5
0000774654fd5cc8  vmovaps [rsp+0x60], xmm6
0000774654fd5cce  vmovaps [rsp+0x70], xmm8
0000774654fd5cd4  vmovaps [rsp+0x80], xmm9
0000774654fd5cdd  vmovaps [rsp+0x90], xmm10
0000774654fd5ce6  vmovaps [rsp+0xA0], xmm11
0000774654fd5cef  vmovaps [rsp+0xB0], xmm12
0000774654fd5cf8  vmovaps [rsp+0xC0], xmm13
0000774654fd5d01  vmovaps [rsp+0xD0], xmm14
0000774654fd5d0a  vmovaps [rsp+0xE0], xmm15
0000774654fd5d13  sub rsp, 0x40
0000774654fd5d17  lea rdi, [rsp]
0000774654fd5d1b  lea rsi, [rsp+0x10]
0000774654fd5d20  lea rdx, [rsp+0x20]
0000774654fd5d25  lea rcx, [rsp+0x30]
0000774654fd5d2a  mov r8d, 0x00
0000774654fd5d30  lea r9, [r15+0x3A8]
0000774654fd5d37  movaps [rdi], xmm7
0000774654fd5d3a  movaps [rsi], xmm8
0000774654fd5d3e  movaps [rdx], xmm3
0000774654fd5d41  movaps [rcx], xmm9
0000774654fd5d45  mov rax, 0x564E5D1DDA50
0000774654fd5d4f  call rax
0000774654fd5d51  movaps xmm7, [rsp]
0000774654fd5d55  add rsp, 0x40
0000774654fd5d59  vmovaps xmm0, [rsp]
0000774654fd5d5e  vmovaps xmm1, [rsp+0x10]
0000774654fd5d64  vmovaps xmm2, [rsp+0x20]
0000774654fd5d6a  vmovaps xmm3, [rsp+0x30]
0000774654fd5d70  vmovaps xmm4, [rsp+0x40]
0000774654fd5d76  vmovaps xmm5, [rsp+0x50]
0000774654fd5d7c  vmovaps xmm6, [rsp+0x60]
0000774654fd5d82  vmovaps xmm8, [rsp+0x70]
0000774654fd5d88  vmovaps xmm9, [rsp+0x80]
0000774654fd5d91  vmovaps xmm10, [rsp+0x90]
0000774654fd5d9a  vmovaps xmm11, [rsp+0xA0]
0000774654fd5da3  vmovaps xmm12, [rsp+0xB0]
0000774654fd5dac  vmovaps xmm13, [rsp+0xC0]
0000774654fd5db5  vmovaps xmm14, [rsp+0xD0]
0000774654fd5dbe  vmovaps xmm15, [rsp+0xE0]
0000774654fd5dc7  add rsp, 0xF0
0000774654fd5dce  pop r11
0000774654fd5dd0  pop r10
0000774654fd5dd2  pop r9
0000774654fd5dd4  pop r8
0000774654fd5dd6  pop rsi
0000774654fd5dd7  pop rdi
0000774654fd5dd8  pop rdx
0000774654fd5dd9  pop rcx
0000774654fd5dda  pop rax
0000774654fd5ddb  add rsp, 0x08
0000774654fd5ddf  jmp 0x0000774654FD3992
0000774654fd5de4  sub rsp, 0x08
0000774654fd5de8  push rax
0000774654fd5de9  push rcx
0000774654fd5dea  push rdx
0000774654fd5deb  push rdi
0000774654fd5dec  push rsi
0000774654fd5ded  push r8
0000774654fd5def  push r9
0000774654fd5df1  push r10
0000774654fd5df3  push r11
0000774654fd5df5  sub rsp, 0xF0
0000774654fd5dfc  vmovaps [rsp], xmm0
0000774654fd5e01  vmovaps [rsp+0x10], xmm1
0000774654fd5e07  vmovaps [rsp+0x20], xmm2
0000774654fd5e0d  vmovaps [rsp+0x30], xmm3
0000774654fd5e13  vmovaps [rsp+0x40], xmm4
0000774654fd5e19  vmovaps [rsp+0x50], xmm5
0000774654fd5e1f  vmovaps [rsp+0x60], xmm6
0000774654fd5e25  vmovaps [rsp+0x70], xmm7
0000774654fd5e2b  vmovaps [rsp+0x80], xmm9
0000774654fd5e34  vmovaps [rsp+0x90], xmm10
0000774654fd5e3d  vmovaps [rsp+0xA0], xmm11
0000774654fd5e46  vmovaps [rsp+0xB0], xmm12
0000774654fd5e4f  vmovaps [rsp+0xC0], xmm13
0000774654fd5e58  vmovaps [rsp+0xD0], xmm14
0000774654fd5e61  vmovaps [rsp+0xE0], xmm15
0000774654fd5e6a  sub rsp, 0x40
0000774654fd5e6e  lea rdi, [rsp]
0000774654fd5e72  lea rsi, [rsp+0x10]
0000774654fd5e77  lea rdx, [rsp+0x20]
0000774654fd5e7c  lea rcx, [rsp+0x30]
0000774654fd5e81  mov r8d, 0x00
0000774654fd5e87  lea r9, [r15+0x3A8]
0000774654fd5e8e  movaps [rdi], xmm8
0000774654fd5e92  movaps [rsi], xmm11
0000774654fd5e96  movaps [rdx], xmm14
0000774654fd5e9a  movaps [rcx], xmm9
0000774654fd5e9e  mov rax, 0x564E5D1DDA50
0000774654fd5ea8  call rax
0000774654fd5eaa  movaps xmm8, [rsp]
0000774654fd5eaf  add rsp, 0x40
0000774654fd5eb3  vmovaps xmm0, [rsp]
0000774654fd5eb8  vmovaps xmm1, [rsp+0x10]
0000774654fd5ebe  vmovaps xmm2, [rsp+0x20]
0000774654fd5ec4  vmovaps xmm3, [rsp+0x30]
0000774654fd5eca  vmovaps xmm4, [rsp+0x40]
0000774654fd5ed0  vmovaps xmm5, [rsp+0x50]
0000774654fd5ed6  vmovaps xmm6, [rsp+0x60]
0000774654fd5edc  vmovaps xmm7, [rsp+0x70]
0000774654fd5ee2  vmovaps xmm9, [rsp+0x80]
0000774654fd5eeb  vmovaps xmm10, [rsp+0x90]
0000774654fd5ef4  vmovaps xmm11, [rsp+0xA0]
0000774654fd5efd  vmovaps xmm12, [rsp+0xB0]
0000774654fd5f06  vmovaps xmm13, [rsp+0xC0]
0000774654fd5f0f  vmovaps xmm14, [rsp+0xD0]
0000774654fd5f18  vmovaps xmm15, [rsp+0xE0]
0000774654fd5f21  add rsp, 0xF0
0000774654fd5f28  pop r11
0000774654fd5f2a  pop r10
0000774654fd5f2c  pop r9
0000774654fd5f2e  pop r8
0000774654fd5f30  pop rsi
0000774654fd5f31  pop rdi
0000774654fd5f32  pop rdx
0000774654fd5f33  pop rcx
0000774654fd5f34  pop rax
0000774654fd5f35  add rsp, 0x08
0000774654fd5f39  jmp 0x0000774654FD39BB
0000774654fd5f3e  sub rsp, 0x08
0000774654fd5f42  push rax
0000774654fd5f43  push rcx
0000774654fd5f44  push rdx
0000774654fd5f45  push rdi
0000774654fd5f46  push rsi
0000774654fd5f47  push r8
0000774654fd5f49  push r9
0000774654fd5f4b  push r10
0000774654fd5f4d  push r11
0000774654fd5f4f  sub rsp, 0xF0
0000774654fd5f56  vmovaps [rsp], xmm0
0000774654fd5f5b  vmovaps [rsp+0x10], xmm1
0000774654fd5f61  vmovaps [rsp+0x20], xmm2
0000774654fd5f67  vmovaps [rsp+0x30], xmm3
0000774654fd5f6d  vmovaps [rsp+0x40], xmm4
0000774654fd5f73  vmovaps [rsp+0x50], xmm5
0000774654fd5f79  vmovaps [rsp+0x60], xmm6
0000774654fd5f7f  vmovaps [rsp+0x70], xmm7
0000774654fd5f85  vmovaps [rsp+0x80], xmm8
0000774654fd5f8e  vmovaps [rsp+0x90], xmm9
0000774654fd5f97  vmovaps [rsp+0xA0], xmm10
0000774654fd5fa0  vmovaps [rsp+0xB0], xmm12
0000774654fd5fa9  vmovaps [rsp+0xC0], xmm13
0000774654fd5fb2  vmovaps [rsp+0xD0], xmm14
0000774654fd5fbb  vmovaps [rsp+0xE0], xmm15
0000774654fd5fc4  sub rsp, 0x40
0000774654fd5fc8  lea rdi, [rsp]
0000774654fd5fcc  lea rsi, [rsp+0x10]
0000774654fd5fd1  lea rdx, [rsp+0x20]
0000774654fd5fd6  lea rcx, [rsp+0x30]
0000774654fd5fdb  mov r8d, 0x00
0000774654fd5fe1  lea r9, [r15+0x3A8]
0000774654fd5fe8  movaps [rdi], xmm11
0000774654fd5fec  movaps [rsi], xmm13
0000774654fd5ff0  movaps [rdx], xmm12
0000774654fd5ff4  movaps [rcx], xmm14
0000774654fd5ff8  mov rax, 0x564E5D1DDA50
0000774654fd6002  call rax
0000774654fd6004  movaps xmm11, [rsp]
0000774654fd6009  add rsp, 0x40
0000774654fd600d  vmovaps xmm0, [rsp]
0000774654fd6012  vmovaps xmm1, [rsp+0x10]
0000774654fd6018  vmovaps xmm2, [rsp+0x20]
0000774654fd601e  vmovaps xmm3, [rsp+0x30]
0000774654fd6024  vmovaps xmm4, [rsp+0x40]
0000774654fd602a  vmovaps xmm5, [rsp+0x50]
0000774654fd6030  vmovaps xmm6, [rsp+0x60]
0000774654fd6036  vmovaps xmm7, [rsp+0x70]
0000774654fd603c  vmovaps xmm8, [rsp+0x80]
0000774654fd6045  vmovaps xmm9, [rsp+0x90]
0000774654fd604e  vmovaps xmm10, [rsp+0xA0]
0000774654fd6057  vmovaps xmm12, [rsp+0xB0]
0000774654fd6060  vmovaps xmm13, [rsp+0xC0]
0000774654fd6069  vmovaps xmm14, [rsp+0xD0]
0000774654fd6072  vmovaps xmm15, [rsp+0xE0]
0000774654fd607b  add rsp, 0xF0
0000774654fd6082  pop r11
0000774654fd6084  pop r10
0000774654fd6086  pop r9
0000774654fd6088  pop r8
0000774654fd608a  pop rsi
0000774654fd608b  pop rdi
0000774654fd608c  pop rdx
0000774654fd608d  pop rcx
0000774654fd608e  pop rax
0000774654fd608f  add rsp, 0x08
0000774654fd6093  jmp 0x0000774654FD39E4
0000774654fd6098  sub rsp, 0x08
0000774654fd609c  push rax
0000774654fd609d  push rcx
0000774654fd609e  push rdx
0000774654fd609f  push rdi
0000774654fd60a0  push rsi
0000774654fd60a1  push r8
0000774654fd60a3  push r9
0000774654fd60a5  push r10
0000774654fd60a7  push r11
0000774654fd60a9  sub rsp, 0xF0
0000774654fd60b0  vmovaps [rsp], xmm0
0000774654fd60b5  vmovaps [rsp+0x10], xmm1
0000774654fd60bb  vmovaps [rsp+0x20], xmm2
0000774654fd60c1  vmovaps [rsp+0x30], xmm3
0000774654fd60c7  vmovaps [rsp+0x40], xmm4
0000774654fd60cd  vmovaps [rsp+0x50], xmm5
0000774654fd60d3  vmovaps [rsp+0x60], xmm6
0000774654fd60d9  vmovaps [rsp+0x70], xmm7
0000774654fd60df  vmovaps [rsp+0x80], xmm8
0000774654fd60e8  vmovaps [rsp+0x90], xmm9
0000774654fd60f1  vmovaps [rsp+0xA0], xmm10
0000774654fd60fa  vmovaps [rsp+0xB0], xmm11
0000774654fd6103  vmovaps [rsp+0xC0], xmm13
0000774654fd610c  vmovaps [rsp+0xD0], xmm14
0000774654fd6115  vmovaps [rsp+0xE0], xmm15
0000774654fd611e  sub rsp, 0x40
0000774654fd6122  lea rdi, [rsp]
0000774654fd6126  lea rsi, [rsp+0x10]
0000774654fd612b  lea rdx, [rsp+0x20]
0000774654fd6130  lea rcx, [rsp+0x30]
0000774654fd6135  mov r8d, 0x00
0000774654fd613b  lea r9, [r15+0x3A8]
0000774654fd6142  movaps [rdi], xmm12
0000774654fd6146  movaps [rsi], xmm10
0000774654fd614a  movaps [rdx], xmm15
0000774654fd614e  movaps [rcx], xmm14
0000774654fd6152  mov rax, 0x564E5D1DDA50
0000774654fd615c  call rax
0000774654fd615e  movaps xmm12, [rsp]
0000774654fd6163  add rsp, 0x40
0000774654fd6167  vmovaps xmm0, [rsp]
0000774654fd616c  vmovaps xmm1, [rsp+0x10]
0000774654fd6172  vmovaps xmm2, [rsp+0x20]
0000774654fd6178  vmovaps xmm3, [rsp+0x30]
0000774654fd617e  vmovaps xmm4, [rsp+0x40]
0000774654fd6184  vmovaps xmm5, [rsp+0x50]
0000774654fd618a  vmovaps xmm6, [rsp+0x60]
0000774654fd6190  vmovaps xmm7, [rsp+0x70]
0000774654fd6196  vmovaps xmm8, [rsp+0x80]
0000774654fd619f  vmovaps xmm9, [rsp+0x90]
0000774654fd61a8  vmovaps xmm10, [rsp+0xA0]
0000774654fd61b1  vmovaps xmm11, [rsp+0xB0]
0000774654fd61ba  vmovaps xmm13, [rsp+0xC0]
0000774654fd61c3  vmovaps xmm14, [rsp+0xD0]
0000774654fd61cc  vmovaps xmm15, [rsp+0xE0]
0000774654fd61d5  add rsp, 0xF0
0000774654fd61dc  pop r11
0000774654fd61de  pop r10
0000774654fd61e0  pop r9
0000774654fd61e2  pop r8
0000774654fd61e4  pop rsi
0000774654fd61e5  pop rdi
0000774654fd61e6  pop rdx
0000774654fd61e7  pop rcx
0000774654fd61e8  pop rax
0000774654fd61e9  add rsp, 0x08
0000774654fd61ed  jmp 0x0000774654FD3A0D
0000774654fd61f2  call 0x0000774654EE5820
0000774654fd61f7  jmp 0x0000774654FD3A1A
0000774654fd61fc  call 0x0000774654EE45A0
0000774654fd6201  jmp 0x0000774654FD3A27
0000774654fd6206  sub rsp, 0x08
0000774654fd620a  push rax
0000774654fd620b  push rcx
0000774654fd620c  push rdx
0000774654fd620d  push rdi
0000774654fd620e  push rsi
0000774654fd620f  push r8
0000774654fd6211  push r9
0000774654fd6213  push r10
0000774654fd6215  push r11
0000774654fd6217  sub rsp, 0xF0
0000774654fd621e  vmovaps [rsp], xmm0
0000774654fd6223  vmovaps [rsp+0x10], xmm1
0000774654fd6229  vmovaps [rsp+0x20], xmm2
0000774654fd622f  vmovaps [rsp+0x30], xmm3
0000774654fd6235  vmovaps [rsp+0x40], xmm4
0000774654fd623b  vmovaps [rsp+0x50], xmm5
0000774654fd6241  vmovaps [rsp+0x60], xmm6
0000774654fd6247  vmovaps [rsp+0x70], xmm7
0000774654fd624d  vmovaps [rsp+0x80], xmm8
0000774654fd6256  vmovaps [rsp+0x90], xmm9
0000774654fd625f  vmovaps [rsp+0xA0], xmm11
0000774654fd6268  vmovaps [rsp+0xB0], xmm12
0000774654fd6271  vmovaps [rsp+0xC0], xmm13
0000774654fd627a  vmovaps [rsp+0xD0], xmm14
0000774654fd6283  vmovaps [rsp+0xE0], xmm15
0000774654fd628c  sub rsp, 0x40
0000774654fd6290  lea rdi, [rsp]
0000774654fd6294  lea rsi, [rsp+0x10]
0000774654fd6299  lea rdx, [rsp+0x20]
0000774654fd629e  lea rcx, [rsp+0x30]
0000774654fd62a3  mov r8d, 0x00
0000774654fd62a9  lea r9, [r15+0x3A8]
0000774654fd62b0  movaps [rdi], xmm10
0000774654fd62b4  movaps [rsi], xmm7
0000774654fd62b7  movaps [rdx], xmm1
0000774654fd62ba  movaps [rcx], xmm13
0000774654fd62be  mov rax, 0x564E5D1DDA50
0000774654fd62c8  call rax
0000774654fd62ca  movaps xmm10, [rsp]
0000774654fd62cf  add rsp, 0x40
0000774654fd62d3  vmovaps xmm0, [rsp]
0000774654fd62d8  vmovaps xmm1, [rsp+0x10]
0000774654fd62de  vmovaps xmm2, [rsp+0x20]
0000774654fd62e4  vmovaps xmm3, [rsp+0x30]
0000774654fd62ea  vmovaps xmm4, [rsp+0x40]
0000774654fd62f0  vmovaps xmm5, [rsp+0x50]
0000774654fd62f6  vmovaps xmm6, [rsp+0x60]
0000774654fd62fc  vmovaps xmm7, [rsp+0x70]
0000774654fd6302  vmovaps xmm8, [rsp+0x80]
0000774654fd630b  vmovaps xmm9, [rsp+0x90]
0000774654fd6314  vmovaps xmm11, [rsp+0xA0]
0000774654fd631d  vmovaps xmm12, [rsp+0xB0]
0000774654fd6326  vmovaps xmm13, [rsp+0xC0]
0000774654fd632f  vmovaps xmm14, [rsp+0xD0]
0000774654fd6338  vmovaps xmm15, [rsp+0xE0]
0000774654fd6341  add rsp, 0xF0
0000774654fd6348  pop r11
0000774654fd634a  pop r10
0000774654fd634c  pop r9
0000774654fd634e  pop r8
0000774654fd6350  pop rsi
0000774654fd6351  pop rdi
0000774654fd6352  pop rdx
0000774654fd6353  pop rcx
0000774654fd6354  pop rax
0000774654fd6355  add rsp, 0x08
0000774654fd6359  jmp 0x0000774654FD3A5D
0000774654fd635e  call 0x0000774654ED64F0
0000774654fd6363  jmp 0x0000774654FD3A6F
0000774654fd6368  sub rsp, 0x08
0000774654fd636c  push rax
0000774654fd636d  push rcx
0000774654fd636e  push rdx
0000774654fd636f  push rdi
0000774654fd6370  push rsi
0000774654fd6371  push r8
0000774654fd6373  push r9
0000774654fd6375  push r10
0000774654fd6377  push r11
0000774654fd6379  sub rsp, 0xF0
0000774654fd6380  vmovaps [rsp], xmm0
0000774654fd6385  vmovaps [rsp+0x10], xmm1
0000774654fd638b  vmovaps [rsp+0x20], xmm2
0000774654fd6391  vmovaps [rsp+0x30], xmm3
0000774654fd6397  vmovaps [rsp+0x40], xmm4
0000774654fd639d  vmovaps [rsp+0x50], xmm5
0000774654fd63a3  vmovaps [rsp+0x60], xmm6
0000774654fd63a9  vmovaps [rsp+0x70], xmm7
0000774654fd63af  vmovaps [rsp+0x80], xmm8
0000774654fd63b8  vmovaps [rsp+0x90], xmm10
0000774654fd63c1  vmovaps [rsp+0xA0], xmm11
0000774654fd63ca  vmovaps [rsp+0xB0], xmm12
0000774654fd63d3  vmovaps [rsp+0xC0], xmm13
0000774654fd63dc  vmovaps [rsp+0xD0], xmm14
0000774654fd63e5  vmovaps [rsp+0xE0], xmm15
0000774654fd63ee  sub rsp, 0x40
0000774654fd63f2  lea rdi, [rsp]
0000774654fd63f6  lea rsi, [rsp+0x10]
0000774654fd63fb  lea rdx, [rsp+0x20]
0000774654fd6400  lea rcx, [rsp+0x30]
0000774654fd6405  mov r8d, 0x00
0000774654fd640b  lea r9, [r15+0x3A8]
0000774654fd6412  movaps [rdi], xmm9
0000774654fd6416  movaps [rsi], xmm8
0000774654fd641a  movaps [rdx], xmm14
0000774654fd641e  movaps [rcx], xmm13
0000774654fd6422  mov rax, 0x564E5D1DDA50
0000774654fd642c  call rax
0000774654fd642e  movaps xmm9, [rsp]
0000774654fd6433  add rsp, 0x40
0000774654fd6437  vmovaps xmm0, [rsp]
0000774654fd643c  vmovaps xmm1, [rsp+0x10]
0000774654fd6442  vmovaps xmm2, [rsp+0x20]
0000774654fd6448  vmovaps xmm3, [rsp+0x30]
0000774654fd644e  vmovaps xmm4, [rsp+0x40]
0000774654fd6454  vmovaps xmm5, [rsp+0x50]
0000774654fd645a  vmovaps xmm6, [rsp+0x60]
0000774654fd6460  vmovaps xmm7, [rsp+0x70]
0000774654fd6466  vmovaps xmm8, [rsp+0x80]
0000774654fd646f  vmovaps xmm10, [rsp+0x90]
0000774654fd6478  vmovaps xmm11, [rsp+0xA0]
0000774654fd6481  vmovaps xmm12, [rsp+0xB0]
0000774654fd648a  vmovaps xmm13, [rsp+0xC0]
0000774654fd6493  vmovaps xmm14, [rsp+0xD0]
0000774654fd649c  vmovaps xmm15, [rsp+0xE0]
0000774654fd64a5  add rsp, 0xF0
0000774654fd64ac  pop r11
0000774654fd64ae  pop r10
0000774654fd64b0  pop r9
0000774654fd64b2  pop r8
0000774654fd64b4  pop rsi
0000774654fd64b5  pop rdi
0000774654fd64b6  pop rdx
0000774654fd64b7  pop rcx
0000774654fd64b8  pop rax
0000774654fd64b9  add rsp, 0x08
0000774654fd64bd  jmp 0x0000774654FD3A9D
0000774654fd64c2  sub rsp, 0x08
0000774654fd64c6  push rax
0000774654fd64c7  push rcx
0000774654fd64c8  push rdx
0000774654fd64c9  push rdi
0000774654fd64ca  push rsi
0000774654fd64cb  push r8
0000774654fd64cd  push r9
0000774654fd64cf  push r10
0000774654fd64d1  push r11
0000774654fd64d3  sub rsp, 0xF0
0000774654fd64da  vmovaps [rsp], xmm0
0000774654fd64df  vmovaps [rsp+0x10], xmm1
0000774654fd64e5  vmovaps [rsp+0x20], xmm2
0000774654fd64eb  vmovaps [rsp+0x30], xmm3
0000774654fd64f1  vmovaps [rsp+0x40], xmm4
0000774654fd64f7  vmovaps [rsp+0x50], xmm5
0000774654fd64fd  vmovaps [rsp+0x60], xmm6
0000774654fd6503  vmovaps [rsp+0x70], xmm7
0000774654fd6509  vmovaps [rsp+0x80], xmm8
0000774654fd6512  vmovaps [rsp+0x90], xmm9
0000774654fd651b  vmovaps [rsp+0xA0], xmm10
0000774654fd6524  vmovaps [rsp+0xB0], xmm11
0000774654fd652d  vmovaps [rsp+0xC0], xmm12
0000774654fd6536  vmovaps [rsp+0xD0], xmm14
0000774654fd653f  vmovaps [rsp+0xE0], xmm15
0000774654fd6548  sub rsp, 0x40
0000774654fd654c  lea rdi, [rsp]
0000774654fd6550  lea rsi, [rsp+0x10]
0000774654fd6555  lea rdx, [rsp+0x20]
0000774654fd655a  lea rcx, [rsp+0x30]
0000774654fd655f  mov r8d, 0x00
0000774654fd6565  lea r9, [r15+0x3A8]
0000774654fd656c  movaps [rdi], xmm13
0000774654fd6570  movaps [rsi], xmm11
0000774654fd6574  movaps [rdx], xmm15
0000774654fd6578  movaps [rcx], xmm14
0000774654fd657c  mov rax, 0x564E5D1DDA50
0000774654fd6586  call rax
0000774654fd6588  movaps xmm13, [rsp]
0000774654fd658d  add rsp, 0x40
0000774654fd6591  vmovaps xmm0, [rsp]
0000774654fd6596  vmovaps xmm1, [rsp+0x10]
0000774654fd659c  vmovaps xmm2, [rsp+0x20]
0000774654fd65a2  vmovaps xmm3, [rsp+0x30]
0000774654fd65a8  vmovaps xmm4, [rsp+0x40]
0000774654fd65ae  vmovaps xmm5, [rsp+0x50]
0000774654fd65b4  vmovaps xmm6, [rsp+0x60]
0000774654fd65ba  vmovaps xmm7, [rsp+0x70]
0000774654fd65c0  vmovaps xmm8, [rsp+0x80]
0000774654fd65c9  vmovaps xmm9, [rsp+0x90]
0000774654fd65d2  vmovaps xmm10, [rsp+0xA0]
0000774654fd65db  vmovaps xmm11, [rsp+0xB0]
0000774654fd65e4  vmovaps xmm12, [rsp+0xC0]
0000774654fd65ed  vmovaps xmm14, [rsp+0xD0]
0000774654fd65f6  vmovaps xmm15, [rsp+0xE0]
0000774654fd65ff  add rsp, 0xF0
0000774654fd6606  pop r11
0000774654fd6608  pop r10
0000774654fd660a  pop r9
0000774654fd660c  pop r8
0000774654fd660e  pop rsi
0000774654fd660f  pop rdi
0000774654fd6610  pop rdx
0000774654fd6611  pop rcx
0000774654fd6612  pop rax
0000774654fd6613  add rsp, 0x08
0000774654fd6617  jmp 0x0000774654FD3ACB
0000774654fd661c  sub rsp, 0x08
0000774654fd6620  push rax
0000774654fd6621  push rcx
0000774654fd6622  push rdx
0000774654fd6623  push rdi
0000774654fd6624  push rsi
0000774654fd6625  push r8
0000774654fd6627  push r9
0000774654fd6629  push r10
0000774654fd662b  push r11
0000774654fd662d  sub rsp, 0xF0
0000774654fd6634  vmovaps [rsp], xmm0
0000774654fd6639  vmovaps [rsp+0x10], xmm1
0000774654fd663f  vmovaps [rsp+0x20], xmm2
0000774654fd6645  vmovaps [rsp+0x30], xmm3
0000774654fd664b  vmovaps [rsp+0x40], xmm4
0000774654fd6651  vmovaps [rsp+0x50], xmm5
0000774654fd6657  vmovaps [rsp+0x60], xmm6
0000774654fd665d  vmovaps [rsp+0x70], xmm7
0000774654fd6663  vmovaps [rsp+0x80], xmm8
0000774654fd666c  vmovaps [rsp+0x90], xmm9
0000774654fd6675  vmovaps [rsp+0xA0], xmm10
0000774654fd667e  vmovaps [rsp+0xB0], xmm11
0000774654fd6687  vmovaps [rsp+0xC0], xmm12
0000774654fd6690  vmovaps [rsp+0xD0], xmm13
0000774654fd6699  vmovaps [rsp+0xE0], xmm15
0000774654fd66a2  sub rsp, 0x40
0000774654fd66a6  lea rdi, [rsp]
0000774654fd66aa  lea rsi, [rsp+0x10]
0000774654fd66af  lea rdx, [rsp+0x20]
0000774654fd66b4  lea rcx, [rsp+0x30]
0000774654fd66b9  mov r8d, 0x00
0000774654fd66bf  lea r9, [r15+0x3A8]
0000774654fd66c6  movaps [rdi], xmm14
0000774654fd66ca  movaps [rsi], xmm12
0000774654fd66ce  movaps [rdx], xmm1
0000774654fd66d1  movaps [rcx], xmm15
0000774654fd66d5  mov rax, 0x564E5D1DDA50
0000774654fd66df  call rax
0000774654fd66e1  movaps xmm14, [rsp]
0000774654fd66e6  add rsp, 0x40
0000774654fd66ea  vmovaps xmm0, [rsp]
0000774654fd66ef  vmovaps xmm1, [rsp+0x10]
0000774654fd66f5  vmovaps xmm2, [rsp+0x20]
0000774654fd66fb  vmovaps xmm3, [rsp+0x30]
0000774654fd6701  vmovaps xmm4, [rsp+0x40]
0000774654fd6707  vmovaps xmm5, [rsp+0x50]
0000774654fd670d  vmovaps xmm6, [rsp+0x60]
0000774654fd6713  vmovaps xmm7, [rsp+0x70]
0000774654fd6719  vmovaps xmm8, [rsp+0x80]
0000774654fd6722  vmovaps xmm9, [rsp+0x90]
0000774654fd672b  vmovaps xmm10, [rsp+0xA0]
0000774654fd6734  vmovaps xmm11, [rsp+0xB0]
0000774654fd673d  vmovaps xmm12, [rsp+0xC0]
0000774654fd6746  vmovaps xmm13, [rsp+0xD0]
0000774654fd674f  vmovaps xmm15, [rsp+0xE0]
0000774654fd6758  add rsp, 0xF0
0000774654fd675f  pop r11
0000774654fd6761  pop r10
0000774654fd6763  pop r9
0000774654fd6765  pop r8
0000774654fd6767  pop rsi
0000774654fd6768  pop rdi
0000774654fd6769  pop rdx
0000774654fd676a  pop rcx
0000774654fd676b  pop rax
0000774654fd676c  add rsp, 0x08
0000774654fd6770  jmp 0x0000774654FD3AF9
0000774654fd6775  call 0x0000774654EACF70
0000774654fd677a  jmp 0x0000774654FD3B07
0000774654fd677f  call 0x0000774654E0C380
0000774654fd6784  jmp 0x0000774654FD3B11
0000774654fd6789  call 0x0000774654E08C20
0000774654fd678e  jmp 0x0000774654FD3B1B
0000774654fd6793  call 0x0000774654E0D600
0000774654fd6798  jmp 0x0000774654FD3B25
0000774654fd679d  int3
0000774654fd679e  nop
0000774654fd67a0  mov eax, [r15+0x48]
0000774654fd67a4  lea r14d, [eax+0x01]
0000774654fd67a9  mov [rsp+0x10], r14d
0000774654fd67ae  mov r14d, r14d
0000774654fd67b1  mov [r15+0x48], r14
0000774654fd67b5  xor eax, eax
0000774654fd67b7  mov r14d, [rsp+0x10]
0000774654fd67bc  cmp r14d, 0x1F4
0000774654fd67c3  cmc
0000774654fd67c4  lahf
0000774654fd67c5  seto al
0000774654fd67c8  mov [r15+0x108], eax
0000774654fd67cf  mov eax, [r15+0x108]
0000774654fd67d6  sahf
0000774654fd67d7  jnz 0x0000774654FD6809
0000774654fd67d9  cmp dword ptr [r15+0x318], 0x00
0000774654fd67e1  jz 0x0000774654FDA1A0
0000774654fd67e7  nop [rax+rax*1], ax
0000774654fd67f0  nop [rax+rax*1], eax
0000774654fd67f8  mov eax, 0x4103FC
0000774654fd67fd  mov [r15+0x100], rax
0000774654fd6804  jmp 0x0000774654DFE110
0000774654fd6809  cmp dword ptr [r15+0x318], 0x00
0000774654fd6811  jz 0x0000774654FD6840
0000774654fd6817  nop [rax+rax*1], ax
0000774654fd6820  nop [rax+rax*1], eax
0000774654fd6828  mov eax, 0x410270
0000774654fd682d  mov [r15+0x100], rax
0000774654fd6834  jmp 0x0000774654DFE110
0000774654fd6839  int3
0000774654fd683a  int3
0000774654fd683b  nop [rax+rax*1], eax
0000774654fd6840  mov rax, [r15+0x40]
0000774654fd6844  vxorps xmm1, xmm1, xmm1
0000774654fd6848  vpbroadcastq xmm1, xmm1
0000774654fd684d  vxorps xmm15, xmm15, xmm15
0000774654fd6852  vpbroadcastq xmm15, xmm15
0000774654fd6857  lea r14, [rax+0x30]
0000774654fd685b  mov r12, [r13+r14*1]
0000774654fd6860  lea r14, [rax+0x38]
0000774654fd6864  mov r11, [r13+r14*1]
0000774654fd6869  movq xmm14, r12
0000774654fd686e  movq xmm13, r11
0000774654fd6873  movq xmm14, xmm14
0000774654fd6878  movq xmm13, xmm13
0000774654fd687d  vmovaps [rsp+0x10], xmm13
0000774654fd6883  movq xmm13, xmm13
0000774654fd6888  movaps [r15+0x270], xmm13
0000774654fd6890  movaps xmm13, [r15+0x160]
0000774654fd6898  vmovaps [rsp+0x20], xmm13
0000774654fd689e  vmovaps xmm12, [rsp+0x20]
0000774654fd68a4  por xmm13, xmm12
0000774654fd68a9  lea r14, [rax+0x20]
0000774654fd68ad  mov r12, [r13+r14*1]
0000774654fd68b2  lea r14, [rax+0x28]
0000774654fd68b6  mov r11, [r13+r14*1]
0000774654fd68bb  movq xmm12, r12
0000774654fd68c0  movq xmm11, r11
0000774654fd68c5  movq xmm12, xmm12
0000774654fd68ca  movq xmm11, xmm11
0000774654fd68cf  movaps xmm10, [r15+0x2F0]
0000774654fd68d7  vmovaps [rsp+0x20], xmm10
0000774654fd68dd  vmovaps xmm9, [rsp+0x20]
0000774654fd68e3  por xmm10, xmm9
0000774654fd68e8  movaps xmm9, [r15+0x2D0]
0000774654fd68f0  vmovaps [rsp+0x20], xmm9
0000774654fd68f6  vmovaps xmm8, [rsp+0x20]
0000774654fd68fc  por xmm9, xmm8
0000774654fd6901  movaps xmm8, [r15+0x300]
0000774654fd6909  vmovaps [rsp+0x20], xmm8
0000774654fd690f  vmovaps xmm7, [rsp+0x20]
0000774654fd6915  por xmm8, xmm7
0000774654fd691a  movaps xmm7, [r15+0x2B0]
0000774654fd6922  vmovaps [rsp+0x20], xmm7
0000774654fd6928  vmovaps xmm6, [rsp+0x20]
0000774654fd692e  por xmm7, xmm6
0000774654fd6932  movaps xmm6, [r15+0x180]
0000774654fd693a  vmovaps [rsp+0x20], xmm6
0000774654fd6940  vmovaps xmm5, [rsp+0x20]
0000774654fd6946  por xmm6, xmm5
0000774654fd694a  lea r14, [rax+0x10]
0000774654fd694e  mov r12, [r13+r14*1]
0000774654fd6953  lea r14, [rax+0x18]
0000774654fd6957  mov r11, [r13+r14*1]
0000774654fd695c  movq xmm5, r12
0000774654fd6961  movq xmm4, r11
0000774654fd6966  movq xmm5, xmm5
0000774654fd696a  movq xmm4, xmm4
0000774654fd696e  movaps xmm3, [r15+0x200]
0000774654fd6976  vmovaps [rsp+0x20], xmm3
0000774654fd697c  vmovaps xmm2, [rsp+0x20]
0000774654fd6982  por xmm3, xmm2
0000774654fd6986  movaps xmm2, [r15+0x1F0]
0000774654fd698e  vmovaps [rsp+0x20], xmm2
0000774654fd6994  vmovaps [rsp+0x30], xmm1
0000774654fd699a  vmovaps xmm1, [rsp+0x20]
0000774654fd69a0  por xmm2, xmm1
0000774654fd69a4  movaps xmm1, [r15+0x2E0]
0000774654fd69ac  vmovaps [rsp+0x20], xmm1
0000774654fd69b2  vmovaps [rsp+0x40], xmm15
0000774654fd69b8  vmovaps xmm15, [rsp+0x20]
0000774654fd69be  por xmm1, xmm15
0000774654fd69c3  movaps xmm15, [r15+0x2A0]
0000774654fd69cb  vmovaps [rsp+0x20], xmm15
0000774654fd69d1  vmovaps [rsp+0x50], xmm1
0000774654fd69d7  vmovaps xmm1, [rsp+0x20]
0000774654fd69dd  por xmm15, xmm1
0000774654fd69e2  movaps xmm1, [r15+0x280]
0000774654fd69ea  vmovaps [rsp+0x20], xmm1
0000774654fd69f0  vmovaps [rsp+0x60], xmm15
0000774654fd69f6  vmovaps xmm15, [rsp+0x20]
0000774654fd69fc  por xmm1, xmm15
0000774654fd6a01  movaps xmm15, [r15+0x1C0]
0000774654fd6a09  vmovaps [rsp+0x20], xmm15
0000774654fd6a0f  vmovaps [rsp+0x70], xmm1
0000774654fd6a15  vmovaps xmm1, [rsp+0x20]
0000774654fd6a1b  por xmm15, xmm1
0000774654fd6a20  movaps xmm1, [r15+0x210]
0000774654fd6a28  vmovaps [rsp+0x20], xmm1
0000774654fd6a2e  vmovaps [rsp+0x80], xmm15
0000774654fd6a37  vmovaps xmm15, [rsp+0x20]
0000774654fd6a3d  por xmm1, xmm15
0000774654fd6a42  mov r14, [r13+rax*1]
0000774654fd6a47  vmovq xmm15, r14
0000774654fd6a4c  vpbroadcastq xmm15, xmm15
0000774654fd6a51  vmovaps [rsp+0x20], xmm1
0000774654fd6a57  vxorps xmm1, xmm1, xmm1
0000774654fd6a5b  vpbroadcastq xmm1, xmm1
0000774654fd6a60  mov r14, [r15+0xF8]
0000774654fd6a67  vmovaps [rsp+0x90], xmm1
0000774654fd6a70  movups xmm1, [r13+r14*1]
0000774654fd6a76  vmovaps [rsp+0xA0], xmm1
0000774654fd6a7f  vxorps xmm1, xmm1, xmm1
0000774654fd6a83  vpbroadcastq xmm1, xmm1
0000774654fd6a88  lea r12, [rax+0x08]
0000774654fd6a8c  mov rax, [r13+r12*1]
0000774654fd6a91  vmovaps [rsp+0xB0], xmm1
0000774654fd6a9a  movq xmm1, rax
0000774654fd6a9f  movaps [r15+0x240], xmm1
0000774654fd6aa7  mov rax, [r15+0x50]
0000774654fd6aab  mov [r15+0x60], rax
0000774654fd6aaf  mov qword ptr [r15+0x58], 0x40
0000774654fd6ab7  vmovaps xmm1, [rsp+0x30]
0000774654fd6abd  vmovaps [rsp+0x30], xmm15
0000774654fd6ac3  vmovaps xmm15, [rsp+0xA0]
0000774654fd6acc  vmovaps [rsp+0xA0], xmm14
0000774654fd6ad5  vmovaps xmm14, [rsp+0x30]
0000774654fd6adb  vmovaps [rsp+0x30], xmm13
0000774654fd6ae1  vmovaps [rsp+0xC0], xmm12
0000774654fd6aea  movaps xmm13, xmm1
0000774654fd6aee  vfmadd231pd xmm13, xmm15, xmm14
0000774654fd6af3  vcmppd xmm12, xmm13, xmm13, 0x03
0000774654fd6af9  vptest xmm12, xmm12
0000774654fd6afe  jnz 0x0000774654FD75DD
0000774654fd6b04  movaps xmm1, [r15+0x250]
0000774654fd6b0c  vmovaps xmm15, [rsp+0x40]
0000774654fd6b12  vmovaps [rsp+0x40], xmm13
0000774654fd6b18  movaps xmm12, xmm15
0000774654fd6b1c  vfmadd231pd xmm12, xmm1, xmm14
0000774654fd6b21  vcmppd xmm13, xmm12, xmm12, 0x03
0000774654fd6b27  vptest xmm13, xmm13
0000774654fd6b2c  jnz 0x0000774654FD7736
0000774654fd6b32  movaps xmm15, [r15+0x1E0]
0000774654fd6b3a  vmovaps [rsp+0xD0], xmm15
0000774654fd6b43  vmovaps xmm13, [rsp+0xD0]
0000774654fd6b4c  por xmm15, xmm13
0000774654fd6b51  movaps xmm13, [r15+0x1D0]
0000774654fd6b59  vmovaps [rsp+0xD0], xmm13
0000774654fd6b62  vmovaps [rsp+0xE0], xmm1
0000774654fd6b6b  vmovaps xmm1, [rsp+0xD0]
0000774654fd6b74  por xmm13, xmm1
0000774654fd6b79  movaps xmm1, [r15+0x2C0]
0000774654fd6b81  vmovaps [rsp+0xD0], xmm1
0000774654fd6b8a  vmovaps [rsp+0xF0], xmm15
0000774654fd6b93  vmovaps xmm15, [rsp+0xD0]
0000774654fd6b9c  por xmm1, xmm15
0000774654fd6ba1  movaps xmm15, [r15+0x290]
0000774654fd6ba9  vmovaps [rsp+0xD0], xmm15
0000774654fd6bb2  vmovaps [rsp+0x100], xmm1
0000774654fd6bbb  vmovaps xmm1, [rsp+0xD0]
0000774654fd6bc4  por xmm15, xmm1
0000774654fd6bc9  movaps xmm1, [r15+0x260]
0000774654fd6bd1  vmovaps [rsp+0xD0], xmm1
0000774654fd6bda  vmovaps [rsp+0x110], xmm15
0000774654fd6be3  vmovaps xmm15, [rsp+0xD0]
0000774654fd6bec  por xmm1, xmm15
0000774654fd6bf1  vmovaps xmm15, [rsp+0xE0]
0000774654fd6bfa  vmovaps [rsp+0xD0], xmm1
0000774654fd6c03  vmovaps xmm1, [rsp+0xE0]
0000774654fd6c0c  por xmm15, xmm1
0000774654fd6c11  lea r12, [r14+0xC0]
0000774654fd6c18  movups xmm1, [r13+r12*1]
0000774654fd6c1e  mov [rsp+0xE0], rax
0000774654fd6c26  xor eax, eax
0000774654fd6c28  mov r12d, 0x40
0000774654fd6c2e  mov r11d, 0x200
0000774654fd6c34  cmp r12, r11
0000774654fd6c37  cmc
0000774654fd6c38  lahf
0000774654fd6c39  seto al
0000774654fd6c3c  mov [r15+0x108], eax
0000774654fd6c43  vmovaps [rsp+0x120], xmm1
0000774654fd6c4c  vmovaps xmm1, [rsp+0x90]
0000774654fd6c55  vmovaps [rsp+0x90], xmm15
0000774654fd6c5e  vmovaps xmm15, [rsp+0x120]
0000774654fd6c67  vmovaps [rsp+0x120], xmm13
0000774654fd6c70  vmovaps [rsp+0x130], xmm12
0000774654fd6c79  movaps xmm13, xmm1
0000774654fd6c7d  vfmadd231pd xmm13, xmm15, xmm14
0000774654fd6c82  vcmppd xmm12, xmm13, xmm13, 0x03
0000774654fd6c88  vptest xmm12, xmm12
0000774654fd6c8d  jnz 0x0000774654FD7899
0000774654fd6c93  lea rax, [r14+0xB0]
0000774654fd6c9a  movups xmm1, [r13+rax*1]
0000774654fd6ca0  vmovaps xmm15, [rsp+0xB0]
0000774654fd6ca9  vmovaps [rsp+0xB0], xmm13
0000774654fd6cb2  movaps xmm12, xmm15
0000774654fd6cb6  vfmadd231pd xmm12, xmm1, xmm14
0000774654fd6cbb  vcmppd xmm13, xmm12, xmm12, 0x03
0000774654fd6cc1  vptest xmm13, xmm13
0000774654fd6cc6  jnz 0x0000774654FD79FC
0000774654fd6ccc  vmovaps xmm1, [rsp+0x20]
0000774654fd6cd2  vmovaps xmm15, [rsp+0x20]
0000774654fd6cd8  por xmm1, xmm15
0000774654fd6cdd  movaps [r15+0x210], xmm1
0000774654fd6ce5  vmovaps xmm15, [rsp+0x80]
0000774654fd6cee  vmovaps xmm14, [rsp+0x80]
0000774654fd6cf7  por xmm15, xmm14
0000774654fd6cfc  movaps [r15+0x1C0], xmm15
0000774654fd6d04  vmovaps xmm14, [rsp+0x70]
0000774654fd6d0a  vmovaps xmm13, [rsp+0x70]
0000774654fd6d10  por xmm14, xmm13
0000774654fd6d15  movaps [r15+0x280], xmm14
0000774654fd6d1d  vmovaps xmm13, [rsp+0x60]
0000774654fd6d23  vmovaps [rsp+0x20], xmm1
0000774654fd6d29  vmovaps xmm1, [rsp+0x60]
0000774654fd6d2f  por xmm13, xmm1
0000774654fd6d34  movaps [r15+0x2A0], xmm13
0000774654fd6d3c  vmovaps xmm1, [rsp+0x50]
0000774654fd6d42  vmovaps [rsp+0x60], xmm15
0000774654fd6d48  vmovaps xmm15, [rsp+0x50]
0000774654fd6d4e  por xmm1, xmm15
0000774654fd6d53  movaps [r15+0x2E0], xmm1
0000774654fd6d5b  vmovaps [rsp+0x50], xmm2
0000774654fd6d61  vmovaps xmm15, [rsp+0x50]
0000774654fd6d67  por xmm2, xmm15
0000774654fd6d6c  movaps [r15+0x1F0], xmm2
0000774654fd6d74  vmovaps xmm15, [rsp+0x90]
0000774654fd6d7d  vmovaps [rsp+0x50], xmm1
0000774654fd6d83  vmovaps xmm1, [rsp+0x90]
0000774654fd6d8c  por xmm15, xmm1
0000774654fd6d91  movaps [r15+0x250], xmm15
0000774654fd6d99  vmovaps xmm1, [rsp+0xD0]
0000774654fd6da2  vmovaps xmm15, [rsp+0xD0]
0000774654fd6dab  por xmm1, xmm15
0000774654fd6db0  movaps [r15+0x260], xmm1
0000774654fd6db8  vmovaps xmm15, [rsp+0x110]
0000774654fd6dc1  vmovaps [rsp+0x70], xmm1
0000774654fd6dc7  vmovaps xmm1, [rsp+0x110]
0000774654fd6dd0  por xmm15, xmm1
0000774654fd6dd5  movaps [r15+0x290], xmm15
0000774654fd6ddd  vmovaps xmm1, [rsp+0x100]
0000774654fd6de6  vmovaps [rsp+0x80], xmm15
0000774654fd6def  vmovaps xmm15, [rsp+0x100]
0000774654fd6df8  por xmm1, xmm15
0000774654fd6dfd  movaps [r15+0x2C0], xmm1
0000774654fd6e05  movq xmm15, qword ptr [r15+0x240]
0000774654fd6e0e  vmovaps [rsp+0x90], xmm15
0000774654fd6e17  vpermilpd xmm15, xmm15, 0x00
0000774654fd6e1d  vmovaps [rsp+0xD0], xmm1
0000774654fd6e26  vmovaps xmm1, [rsp+0x40]
0000774654fd6e2c  vmovaps [rsp+0x40], xmm15
0000774654fd6e32  vmovaps xmm15, [rsp+0x20]
0000774654fd6e38  vmovaps [rsp+0x20], xmm14
0000774654fd6e3e  vmovaps xmm14, [rsp+0x40]
0000774654fd6e44  vmovaps [rsp+0x40], xmm13
0000774654fd6e4a  vmovaps [rsp+0x100], xmm12
0000774654fd6e53  movaps xmm13, xmm1
0000774654fd6e57  vfmadd231pd xmm13, xmm15, xmm14
0000774654fd6e5c  vcmppd xmm12, xmm13, xmm13, 0x03
0000774654fd6e62  vptest xmm12, xmm12
0000774654fd6e67  jnz 0x0000774654FD7B55
0000774654fd6e6d  vmovaps xmm1, [rsp+0x90]
0000774654fd6e76  vpermilpd xmm1, xmm1, 0x00
0000774654fd6e7c  vmovaps xmm15, [rsp+0xB0]
0000774654fd6e85  vmovaps xmm14, [rsp+0x50]
0000774654fd6e8b  vmovaps [rsp+0x50], xmm13
0000774654fd6e91  movaps xmm12, xmm15
0000774654fd6e95  vfmadd231pd xmm12, xmm14, xmm1
0000774654fd6e9a  vcmppd xmm13, xmm12, xmm12, 0x03
0000774654fd6ea0  vptest xmm13, xmm13
0000774654fd6ea5  jnz 0x0000774654FD7CAE
0000774654fd6eab  vmovaps xmm1, [rsp+0x90]
0000774654fd6eb4  vpermilpd xmm1, xmm1, 0x00
0000774654fd6eba  vmovaps xmm15, [rsp+0x130]
0000774654fd6ec3  vmovaps xmm14, [rsp+0x60]
0000774654fd6ec9  vmovaps [rsp+0x60], xmm12
0000774654fd6ecf  movaps xmm13, xmm15
0000774654fd6ed3  vfmadd231pd xmm13, xmm14, xmm1
0000774654fd6ed8  vcmppd xmm12, xmm13, xmm13, 0x03
0000774654fd6ede  vptest xmm12, xmm12
0000774654fd6ee3  jnz 0x0000774654FD7E07
0000774654fd6ee9  vmovaps xmm1, [rsp+0x120]
0000774654fd6ef2  vmovaps xmm15, [rsp+0x120]
0000774654fd6efb  por xmm1, xmm15
0000774654fd6f00  movaps [r15+0x1D0], xmm1
0000774654fd6f08  vmovaps xmm15, [rsp+0x90]
0000774654fd6f11  vpermilpd xmm15, xmm15, 0x00
0000774654fd6f17  vmovaps xmm14, [rsp+0x100]
0000774654fd6f20  vmovaps [rsp+0x90], xmm1
0000774654fd6f29  movaps xmm12, xmm14
0000774654fd6f2d  vfmadd231pd xmm12, xmm2, xmm15
0000774654fd6f32  vcmppd xmm1, xmm12, xmm12, 0x03
0000774654fd6f38  vptest xmm1, xmm1
0000774654fd6f3d  jnz 0x0000774654FD7F60
0000774654fd6f43  vmovaps [rsp+0xB0], xmm3
0000774654fd6f4c  vmovaps xmm1, [rsp+0xB0]
0000774654fd6f55  por xmm3, xmm1
0000774654fd6f59  movaps [r15+0x200], xmm3
0000774654fd6f61  vmovaps xmm1, [rsp+0xF0]
0000774654fd6f6a  vmovaps xmm15, [rsp+0xF0]
0000774654fd6f73  por xmm1, xmm15
0000774654fd6f78  movaps [r15+0x1E0], xmm1
0000774654fd6f80  vmovaps [rsp+0xB0], xmm7
0000774654fd6f89  vmovaps xmm1, [rsp+0xB0]
0000774654fd6f92  por xmm7, xmm1
0000774654fd6f96  movaps [r15+0x2B0], xmm7
0000774654fd6f9e  vmovaps [rsp+0xB0], xmm8
0000774654fd6fa7  vmovaps xmm1, [rsp+0xB0]
0000774654fd6fb0  por xmm8, xmm1
0000774654fd6fb5  movaps [r15+0x300], xmm8
0000774654fd6fbd  vmovaps [rsp+0xB0], xmm5
0000774654fd6fc6  vpermilpd xmm5, xmm5, 0x00
0000774654fd6fcc  vmovaps xmm14, [rsp+0x50]
0000774654fd6fd2  vmovaps xmm8, [rsp+0x70]
0000774654fd6fd8  vmovaps [rsp+0x50], xmm1
0000774654fd6fde  movaps xmm2, xmm14
0000774654fd6fe2  vfmadd231pd xmm2, xmm8, xmm5
0000774654fd6fe7  vcmppd xmm1, xmm2, xmm2, 0x03
0000774654fd6fec  vptest xmm1, xmm1
0000774654fd6ff1  jnz 0x0000774654FD80B9
0000774654fd6ff7  vmovaps xmm1, [rsp+0xB0]
0000774654fd7000  vpermilpd xmm1, xmm1, 0x00
0000774654fd7006  vmovaps xmm14, [rsp+0x60]
0000774654fd700c  vmovaps xmm8, [rsp+0xD0]
0000774654fd7015  vmovaps [rsp+0x60], xmm15
0000774654fd701b  movaps xmm5, xmm14
0000774654fd701f  vfmadd231pd xmm5, xmm8, xmm1
0000774654fd7024  vcmppd xmm15, xmm5, xmm5, 0x03
0000774654fd7029  vptest xmm15, xmm15
0000774654fd702e  jnz 0x0000774654FD8210
0000774654fd7034  vmovaps xmm1, [rsp+0xB0]
0000774654fd703d  vpermilpd xmm1, xmm1, 0x00
0000774654fd7043  vmovaps xmm14, [rsp+0x20]
0000774654fd7049  movaps xmm15, xmm13
0000774654fd704d  vfmadd231pd xmm15, xmm14, xmm1
0000774654fd7052  vcmppd xmm8, xmm15, xmm15, 0x03
0000774654fd7058  vptest xmm8, xmm8
0000774654fd705d  jnz 0x0000774654FD8367
0000774654fd7063  vmovaps xmm1, [rsp+0xB0]
0000774654fd706c  vpermilpd xmm1, xmm1, 0x00
0000774654fd7072  vmovaps xmm14, [rsp+0x90]
0000774654fd707b  movaps xmm13, xmm12
0000774654fd707f  vfmadd231pd xmm13, xmm14, xmm1
0000774654fd7084  vcmppd xmm8, xmm13, xmm13, 0x03
0000774654fd708a  vptest xmm8, xmm8
0000774654fd708f  jnz 0x0000774654FD84C0
0000774654fd7095  vmovaps [rsp+0x20], xmm6
0000774654fd709b  vmovaps xmm1, [rsp+0x20]
0000774654fd70a1  por xmm6, xmm1
0000774654fd70a5  movaps [r15+0x180], xmm6
0000774654fd70ad  vmovaps [rsp+0x20], xmm9
0000774654fd70b3  vmovaps xmm1, [rsp+0x20]
0000774654fd70b9  por xmm9, xmm1
0000774654fd70be  movaps [r15+0x2D0], xmm9
0000774654fd70c6  vmovaps [rsp+0x20], xmm10
0000774654fd70cc  vmovaps xmm1, [rsp+0x20]
0000774654fd70d2  por xmm10, xmm1
0000774654fd70d7  movaps [r15+0x2F0], xmm10
0000774654fd70df  vmovaps [rsp+0x20], xmm4
0000774654fd70e5  vpermilpd xmm4, xmm4, 0x00
0000774654fd70eb  vmovaps xmm14, [rsp+0x50]
0000774654fd70f1  movaps xmm12, xmm5
0000774654fd70f5  vfmadd231pd xmm12, xmm14, xmm4
0000774654fd70fa  vcmppd xmm10, xmm12, xmm12, 0x03
0000774654fd7100  vptest xmm10, xmm10
0000774654fd7105  jnz 0x0000774654FD8619
0000774654fd710b  vmovaps xmm14, [rsp+0x20]
0000774654fd7111  vpermilpd xmm14, xmm14, 0x00
0000774654fd7117  movaps xmm10, xmm2
0000774654fd711b  vfmadd231pd xmm10, xmm6, xmm14
0000774654fd7120  vcmppd xmm8, xmm10, xmm10, 0x03
0000774654fd7126  vptest xmm8, xmm8
0000774654fd712b  jnz 0x0000774654FD8771
0000774654fd7131  lea rax, [r14+0x80]
0000774654fd7138  movups xmm14, [r13+rax*1]
0000774654fd713e  movaps [r15+0x190], xmm14
0000774654fd7146  vmovaps xmm8, [rsp+0x20]
0000774654fd714c  vpermilpd xmm8, xmm8, 0x00
0000774654fd7152  vmovaps xmm6, [rsp+0x80]
0000774654fd715b  movaps xmm5, xmm15
0000774654fd715f  vfmadd231pd xmm5, xmm6, xmm8
0000774654fd7164  vcmppd xmm4, xmm5, xmm5, 0x03
0000774654fd7169  vptest xmm4, xmm4
0000774654fd716e  jnz 0x0000774654FD88D3
0000774654fd7174  vmovaps xmm15, [rsp+0x20]
0000774654fd717a  vpermilpd xmm15, xmm15, 0x00
0000774654fd7180  movaps xmm8, xmm13
0000774654fd7184  vfmadd231pd xmm8, xmm1, xmm15
0000774654fd7189  vcmppd xmm6, xmm8, xmm8, 0x03
0000774654fd718f  vptest xmm6, xmm6
0000774654fd7194  jnz 0x0000774654FD8A2A
0000774654fd719a  vmovaps xmm1, [rsp+0x30]
0000774654fd71a0  vmovaps xmm15, [rsp+0x30]
0000774654fd71a6  por xmm1, xmm15
0000774654fd71ab  movaps [r15+0x160], xmm1
0000774654fd71b3  lea rax, [r14+0x40]
0000774654fd71b7  movups xmm15, [r13+rax*1]
0000774654fd71bd  lea rax, [r14+0x50]
0000774654fd71c1  movups xmm13, [r13+rax*1]
0000774654fd71c7  movaps [r15+0x1B0], xmm15
0000774654fd71cf  movaps [r15+0x1A0], xmm13
0000774654fd71d7  vmovaps xmm6, [rsp+0xC0]
0000774654fd71e0  vpermilpd xmm6, xmm6, 0x00
0000774654fd71e6  movaps xmm4, xmm12
0000774654fd71ea  vfmadd231pd xmm4, xmm9, xmm6
0000774654fd71ef  vcmppd xmm2, xmm4, xmm4, 0x03
0000774654fd71f4  vptest xmm2, xmm2
0000774654fd71f9  jnz 0x0000774654FD8B97
0000774654fd71ff  vmovaps xmm12, [rsp+0xC0]
0000774654fd7208  vpermilpd xmm12, xmm12, 0x00
0000774654fd720e  movaps xmm9, xmm10
0000774654fd7212  vfmadd231pd xmm9, xmm1, xmm12
0000774654fd7217  vcmppd xmm6, xmm9, xmm9, 0x03
0000774654fd721d  vptest xmm6, xmm6
0000774654fd7222  jnz 0x0000774654FD8CEE
0000774654fd7228  vmovaps xmm1, [rsp+0xC0]
0000774654fd7231  vpermilpd xmm1, xmm1, 0x00
0000774654fd7237  vmovaps xmm12, [rsp+0x40]
0000774654fd723d  movaps xmm10, xmm5
0000774654fd7241  vfmadd231pd xmm10, xmm12, xmm1
0000774654fd7246  vcmppd xmm6, xmm10, xmm10, 0x03
0000774654fd724c  vptest xmm6, xmm6
0000774654fd7251  jnz 0x0000774654FD8E47
0000774654fd7257  vmovaps xmm1, [rsp+0xC0]
0000774654fd7260  vpermilpd xmm1, xmm1, 0x00
0000774654fd7266  vmovaps xmm12, [rsp+0x60]
0000774654fd726c  movaps xmm6, xmm8
0000774654fd7270  vfmadd231pd xmm6, xmm12, xmm1
0000774654fd7275  vcmppd xmm5, xmm6, xmm6, 0x03
0000774654fd727a  vptest xmm5, xmm5
0000774654fd727f  jnz 0x0000774654FD8F9F
0000774654fd7285  lea rax, [r14+0x60]
0000774654fd7289  movups xmm1, [r13+rax*1]
0000774654fd728f  lea rax, [r14+0x70]
0000774654fd7293  movups xmm12, [r13+rax*1]
0000774654fd7299  movaps [r15+0x150], xmm1
0000774654fd72a1  movaps [r15+0x120], xmm12
0000774654fd72a9  vmovaps [rsp+0x20], xmm11
0000774654fd72af  vpermilpd xmm11, xmm11, 0x00
0000774654fd72b5  movaps xmm8, xmm4
0000774654fd72b9  vfmadd231pd xmm8, xmm13, xmm11
0000774654fd72be  vcmppd xmm5, xmm8, xmm8, 0x03
0000774654fd72c4  vptest xmm5, xmm5
0000774654fd72c9  jnz 0x0000774654FD910A
0000774654fd72cf  vmovaps xmm13, [rsp+0x20]
0000774654fd72d5  vpermilpd xmm13, xmm13, 0x00
0000774654fd72db  movaps xmm11, xmm9
0000774654fd72df  vfmadd231pd xmm11, xmm1, xmm13
0000774654fd72e4  vcmppd xmm5, xmm11, xmm11, 0x03
0000774654fd72ea  vptest xmm5, xmm5
0000774654fd72ef  jnz 0x0000774654FD9263
0000774654fd72f5  vmovaps xmm1, [rsp+0x20]
0000774654fd72fb  vpermilpd xmm1, xmm1, 0x00
0000774654fd7301  movaps xmm13, xmm10
0000774654fd7305  vfmadd231pd xmm13, xmm7, xmm1
0000774654fd730a  vcmppd xmm9, xmm13, xmm13, 0x03
0000774654fd7310  vptest xmm9, xmm9
0000774654fd7315  jnz 0x0000774654FD93BC
0000774654fd731b  vmovaps xmm1, [rsp+0x20]
0000774654fd7321  vpermilpd xmm1, xmm1, 0x00
0000774654fd7327  movaps xmm10, xmm6
0000774654fd732b  vfmadd231pd xmm10, xmm15, xmm1
0000774654fd7330  vcmppd xmm9, xmm10, xmm10, 0x03
0000774654fd7336  vptest xmm9, xmm9
0000774654fd733b  jnz 0x0000774654FD9514
0000774654fd7341  lea rax, [r14+0x20]
0000774654fd7345  movups xmm1, [r13+rax*1]
0000774654fd734b  lea rax, [r14+0x30]
0000774654fd734f  movups xmm15, [r13+rax*1]
0000774654fd7355  vmovaps xmm9, [rsp+0xA0]
0000774654fd735e  vpermilpd xmm9, xmm9, 0x00
0000774654fd7364  movaps xmm7, xmm8
0000774654fd7368  vfmadd231pd xmm7, xmm3, xmm9
0000774654fd736d  vcmppd xmm6, xmm7, xmm7, 0x03
0000774654fd7372  vptest xmm6, xmm6
0000774654fd7377  jnz 0x0000774654FD9680
0000774654fd737d  vmovaps xmm9, [rsp+0xA0]
0000774654fd7386  vpermilpd xmm9, xmm9, 0x00
0000774654fd738c  movaps xmm8, xmm11
0000774654fd7390  vfmadd231pd xmm8, xmm14, xmm9
0000774654fd7395  vcmppd xmm6, xmm8, xmm8, 0x03
0000774654fd739b  vptest xmm6, xmm6
0000774654fd73a0  jnz 0x0000774654FD97D7
0000774654fd73a6  vmovaps xmm14, [rsp+0xA0]
0000774654fd73af  vpermilpd xmm14, xmm14, 0x00
0000774654fd73b5  movaps xmm11, xmm13
0000774654fd73b9  vfmadd231pd xmm11, xmm12, xmm14
0000774654fd73be  vcmppd xmm9, xmm11, xmm11, 0x03
0000774654fd73c4  vptest xmm9, xmm9
0000774654fd73c9  jnz 0x0000774654FD9931
0000774654fd73cf  vmovaps xmm14, [rsp+0xA0]
0000774654fd73d8  vpermilpd xmm14, xmm14, 0x00
0000774654fd73de  movaps xmm12, xmm10
0000774654fd73e2  vfmadd231pd xmm12, xmm15, xmm14
0000774654fd73e7  vcmppd xmm13, xmm12, xmm12, 0x03
0000774654fd73ed  vptest xmm13, xmm13
0000774654fd73f2  jnz 0x0000774654FD9A8B
0000774654fd73f8  lea rax, [r14+0x90]
0000774654fd73ff  movups xmm15, [r13+rax*1]
0000774654fd7405  lea rax, [r14+0xA0]
0000774654fd740c  movups xmm14, [r13+rax*1]
0000774654fd7412  movaps [r15+0x140], xmm15
0000774654fd741a  movaps [r15+0x130], xmm14
0000774654fd7422  vmovaps xmm13, [rsp+0x10]
0000774654fd7428  vpermilpd xmm13, xmm13, 0x00
0000774654fd742e  movaps xmm10, xmm7
0000774654fd7432  vfmadd231pd xmm10, xmm1, xmm13
0000774654fd7437  vcmppd xmm9, xmm10, xmm10, 0x03
0000774654fd743d  vptest xmm9, xmm9
0000774654fd7442  jnz 0x0000774654FD9BF9
0000774654fd7448  movaps [r15+0x220], xmm10
0000774654fd7450  lea rax, [r14+0x10]
0000774654fd7454  movups xmm1, [r13+rax*1]
0000774654fd745a  movaps [r15+0x240], xmm1
0000774654fd7462  vmovaps xmm13, [rsp+0x10]
0000774654fd7468  vpermilpd xmm13, xmm13, 0x00
0000774654fd746e  movaps xmm9, xmm8
0000774654fd7472  vfmadd231pd xmm9, xmm14, xmm13
0000774654fd7477  vcmppd xmm7, xmm9, xmm9, 0x03
0000774654fd747d  vptest xmm7, xmm7
0000774654fd7482  jnz 0x0000774654FD9D5B
0000774654fd7488  movaps [r15+0x110], xmm9
0000774654fd7490  vmovaps xmm14, [rsp+0x10]
0000774654fd7496  vpermilpd xmm14, xmm14, 0x00
0000774654fd749c  movaps xmm13, xmm11
0000774654fd74a0  vfmadd231pd xmm13, xmm15, xmm14
0000774654fd74a5  vcmppd xmm8, xmm13, xmm13, 0x03
0000774654fd74ab  vptest xmm8, xmm8
0000774654fd74b0  jnz 0x0000774654FD9EB5
0000774654fd74b6  movaps [r15+0x170], xmm13
0000774654fd74be  vmovaps xmm15, [rsp+0x10]
0000774654fd74c4  vpermilpd xmm15, xmm15, 0x00
0000774654fd74ca  movaps xmm14, xmm12
0000774654fd74ce  vfmadd231pd xmm14, xmm1, xmm15
0000774654fd74d3  vcmppd xmm11, xmm14, xmm14, 0x03
0000774654fd74d9  vptest xmm11, xmm11
0000774654fd74de  jnz 0x0000774654FDA00F
0000774654fd74e4  movaps [r15+0x230], xmm14
0000774654fd74ec  mov rax, [rsp+0xE0]
0000774654fd74f4  movups [r13+rax*1], xmm9
0000774654fd74fa  lea r14, [rax+0x10]
0000774654fd74fe  movups [r13+r14*1], xmm13
0000774654fd7504  lea r14, [rax+0x20]
0000774654fd7508  movups [r13+r14*1], xmm10
0000774654fd750e  lea r14, [rax+0x30]
0000774654fd7512  movups [r13+r14*1], xmm14
0000774654fd7518  mov eax, [r15+0x108]
0000774654fd751f  sahf
0000774654fd7520  jnz 0x0000774654FD7552
0000774654fd7522  cmp dword ptr [r15+0x318], 0x00
0000774654fd752a  jz 0x0000774654FD67A0
0000774654fd7530  nop [rax+rax*1], ax
0000774654fd7539  nop [rax+rax*1], eax
0000774654fd7541  mov eax, 0x4103F0
0000774654fd7546  mov [r15+0x100], rax
0000774654fd754d  jmp 0x0000774654DFE110
0000774654fd7552  cmp dword ptr [r15+0x318], 0x00
0000774654fd755a  jz 0x0000774654FD2E40
0000774654fd7560  nop [rax+rax*1], ax
0000774654fd7569  nop [rax+rax*1], eax
0000774654fd7571  mov eax, 0x410274
0000774654fd7576  mov [r15+0x100], rax
0000774654fd757d  jmp 0x0000774654DFE110
0000774654fd7582  int3
0000774654fd7583  call 0x0000774654EE27E0
0000774654fd7588  jmp 0x0000774654FD6860
0000774654fd758d  call 0x0000774654EE1570
0000774654fd7592  jmp 0x0000774654FD6869
0000774654fd7597  call 0x0000774654EE27E0
0000774654fd759c  jmp 0x0000774654FD68B2
0000774654fd75a1  call 0x0000774654EE1570
0000774654fd75a6  jmp 0x0000774654FD68BB
0000774654fd75ab  call 0x0000774654EE27E0
0000774654fd75b0  jmp 0x0000774654FD6953
0000774654fd75b5  call 0x0000774654EE1570
0000774654fd75ba  jmp 0x0000774654FD695C
0000774654fd75bf  call 0x0000774654E0DC20
0000774654fd75c4  jmp 0x0000774654FD6A47
0000774654fd75c9  call 0x0000774654ED64F0
0000774654fd75ce  jmp 0x0000774654FD6A76
0000774654fd75d3  call 0x0000774654EB47C0
0000774654fd75d8  jmp 0x0000774654FD6A91
0000774654fd75dd  sub rsp, 0x08
0000774654fd75e1  push rax
0000774654fd75e2  push rcx
0000774654fd75e3  push rdx
0000774654fd75e4  push rdi
0000774654fd75e5  push rsi
0000774654fd75e6  push r8
0000774654fd75e8  push r9
0000774654fd75ea  push r10
0000774654fd75ec  push r11
0000774654fd75ee  sub rsp, 0xF0
0000774654fd75f5  vmovaps [rsp], xmm0
0000774654fd75fa  vmovaps [rsp+0x10], xmm1
0000774654fd7600  vmovaps [rsp+0x20], xmm2
0000774654fd7606  vmovaps [rsp+0x30], xmm3
0000774654fd760c  vmovaps [rsp+0x40], xmm4
0000774654fd7612  vmovaps [rsp+0x50], xmm5
0000774654fd7618  vmovaps [rsp+0x60], xmm6
0000774654fd761e  vmovaps [rsp+0x70], xmm7
0000774654fd7624  vmovaps [rsp+0x80], xmm8
0000774654fd762d  vmovaps [rsp+0x90], xmm9
0000774654fd7636  vmovaps [rsp+0xA0], xmm10
0000774654fd763f  vmovaps [rsp+0xB0], xmm11
0000774654fd7648  vmovaps [rsp+0xC0], xmm12
0000774654fd7651  vmovaps [rsp+0xD0], xmm14
0000774654fd765a  vmovaps [rsp+0xE0], xmm15
0000774654fd7663  sub rsp, 0x40
0000774654fd7667  lea rdi, [rsp]
0000774654fd766b  lea rsi, [rsp+0x10]
0000774654fd7670  lea rdx, [rsp+0x20]
0000774654fd7675  lea rcx, [rsp+0x30]
0000774654fd767a  mov r8d, 0x00
0000774654fd7680  lea r9, [r15+0x3A8]
0000774654fd7687  movaps [rdi], xmm13
0000774654fd768b  movaps [rsi], xmm1
0000774654fd768e  movaps [rdx], xmm15
0000774654fd7692  movaps [rcx], xmm14
0000774654fd7696  mov rax, 0x564E5D1DDA50
0000774654fd76a0  call rax
0000774654fd76a2  movaps xmm13, [rsp]
0000774654fd76a7  add rsp, 0x40
0000774654fd76ab  vmovaps xmm0, [rsp]
0000774654fd76b0  vmovaps xmm1, [rsp+0x10]
0000774654fd76b6  vmovaps xmm2, [rsp+0x20]
0000774654fd76bc  vmovaps xmm3, [rsp+0x30]
0000774654fd76c2  vmovaps xmm4, [rsp+0x40]
0000774654fd76c8  vmovaps xmm5, [rsp+0x50]
0000774654fd76ce  vmovaps xmm6, [rsp+0x60]
0000774654fd76d4  vmovaps xmm7, [rsp+0x70]
0000774654fd76da  vmovaps xmm8, [rsp+0x80]
0000774654fd76e3  vmovaps xmm9, [rsp+0x90]
0000774654fd76ec  vmovaps xmm10, [rsp+0xA0]
0000774654fd76f5  vmovaps xmm11, [rsp+0xB0]
0000774654fd76fe  vmovaps xmm12, [rsp+0xC0]
0000774654fd7707  vmovaps xmm14, [rsp+0xD0]
0000774654fd7710  vmovaps xmm15, [rsp+0xE0]
0000774654fd7719  add rsp, 0xF0
0000774654fd7720  pop r11
0000774654fd7722  pop r10
0000774654fd7724  pop r9
0000774654fd7726  pop r8
0000774654fd7728  pop rsi
0000774654fd7729  pop rdi
0000774654fd772a  pop rdx
0000774654fd772b  pop rcx
0000774654fd772c  pop rax
0000774654fd772d  add rsp, 0x08
0000774654fd7731  jmp 0x0000774654FD6B04
0000774654fd7736  sub rsp, 0x08
0000774654fd773a  push rax
0000774654fd773b  push rcx
0000774654fd773c  push rdx
0000774654fd773d  push rdi
0000774654fd773e  push rsi
0000774654fd773f  push r8
0000774654fd7741  push r9
0000774654fd7743  push r10
0000774654fd7745  push r11
0000774654fd7747  sub rsp, 0xF0
0000774654fd774e  vmovaps [rsp], xmm0
0000774654fd7753  vmovaps [rsp+0x10], xmm1
0000774654fd7759  vmovaps [rsp+0x20], xmm2
0000774654fd775f  vmovaps [rsp+0x30], xmm3
0000774654fd7765  vmovaps [rsp+0x40], xmm4
0000774654fd776b  vmovaps [rsp+0x50], xmm5
0000774654fd7771  vmovaps [rsp+0x60], xmm6
0000774654fd7777  vmovaps [rsp+0x70], xmm7
0000774654fd777d  vmovaps [rsp+0x80], xmm8
0000774654fd7786  vmovaps [rsp+0x90], xmm9
0000774654fd778f  vmovaps [rsp+0xA0], xmm10
0000774654fd7798  vmovaps [rsp+0xB0], xmm11
0000774654fd77a1  vmovaps [rsp+0xC0], xmm13
0000774654fd77aa  vmovaps [rsp+0xD0], xmm14
0000774654fd77b3  vmovaps [rsp+0xE0], xmm15
0000774654fd77bc  sub rsp, 0x40
0000774654fd77c0  lea rdi, [rsp]
0000774654fd77c4  lea rsi, [rsp+0x10]
0000774654fd77c9  lea rdx, [rsp+0x20]
0000774654fd77ce  lea rcx, [rsp+0x30]
0000774654fd77d3  mov r8d, 0x00
0000774654fd77d9  lea r9, [r15+0x3A8]
0000774654fd77e0  movaps [rdi], xmm12
0000774654fd77e4  movaps [rsi], xmm15
0000774654fd77e8  movaps [rdx], xmm1
0000774654fd77eb  movaps [rcx], xmm14
0000774654fd77ef  mov rax, 0x564E5D1DDA50
0000774654fd77f9  call rax
0000774654fd77fb  movaps xmm12, [rsp]
0000774654fd7800  add rsp, 0x40
0000774654fd7804  vmovaps xmm0, [rsp]
0000774654fd7809  vmovaps xmm1, [rsp+0x10]
0000774654fd780f  vmovaps xmm2, [rsp+0x20]
0000774654fd7815  vmovaps xmm3, [rsp+0x30]
0000774654fd781b  vmovaps xmm4, [rsp+0x40]
0000774654fd7821  vmovaps xmm5, [rsp+0x50]
0000774654fd7827  vmovaps xmm6, [rsp+0x60]
0000774654fd782d  vmovaps xmm7, [rsp+0x70]
0000774654fd7833  vmovaps xmm8, [rsp+0x80]
0000774654fd783c  vmovaps xmm9, [rsp+0x90]
0000774654fd7845  vmovaps xmm10, [rsp+0xA0]
0000774654fd784e  vmovaps xmm11, [rsp+0xB0]
0000774654fd7857  vmovaps xmm13, [rsp+0xC0]
0000774654fd7860  vmovaps xmm14, [rsp+0xD0]
0000774654fd7869  vmovaps xmm15, [rsp+0xE0]
0000774654fd7872  add rsp, 0xF0
0000774654fd7879  pop r11
0000774654fd787b  pop r10
0000774654fd787d  pop r9
0000774654fd787f  pop r8
0000774654fd7881  pop rsi
0000774654fd7882  pop rdi
0000774654fd7883  pop rdx
0000774654fd7884  pop rcx
0000774654fd7885  pop rax
0000774654fd7886  add rsp, 0x08
0000774654fd788a  jmp 0x0000774654FD6B32
0000774654fd788f  call 0x0000774654EB52F0
0000774654fd7894  jmp 0x0000774654FD6C1E
0000774654fd7899  sub rsp, 0x08
0000774654fd789d  push rax
0000774654fd789e  push rcx
0000774654fd789f  push rdx
0000774654fd78a0  push rdi
0000774654fd78a1  push rsi
0000774654fd78a2  push r8
0000774654fd78a4  push r9
0000774654fd78a6  push r10
0000774654fd78a8  push r11
0000774654fd78aa  sub rsp, 0xF0
0000774654fd78b1  vmovaps [rsp], xmm0
0000774654fd78b6  vmovaps [rsp+0x10], xmm1
0000774654fd78bc  vmovaps [rsp+0x20], xmm2
0000774654fd78c2  vmovaps [rsp+0x30], xmm3
0000774654fd78c8  vmovaps [rsp+0x40], xmm4
0000774654fd78ce  vmovaps [rsp+0x50], xmm5
0000774654fd78d4  vmovaps [rsp+0x60], xmm6
0000774654fd78da  vmovaps [rsp+0x70], xmm7
0000774654fd78e0  vmovaps [rsp+0x80], xmm8
0000774654fd78e9  vmovaps [rsp+0x90], xmm9
0000774654fd78f2  vmovaps [rsp+0xA0], xmm10
0000774654fd78fb  vmovaps [rsp+0xB0], xmm11
0000774654fd7904  vmovaps [rsp+0xC0], xmm12
0000774654fd790d  vmovaps [rsp+0xD0], xmm14
0000774654fd7916  vmovaps [rsp+0xE0], xmm15
0000774654fd791f  sub rsp, 0x40
0000774654fd7923  lea rdi, [rsp]
0000774654fd7927  lea rsi, [rsp+0x10]
0000774654fd792c  lea rdx, [rsp+0x20]
0000774654fd7931  lea rcx, [rsp+0x30]
0000774654fd7936  mov r8d, 0x00
0000774654fd793c  lea r9, [r15+0x3A8]
0000774654fd7943  movaps [rdi], xmm13
0000774654fd7947  movaps [rsi], xmm1
0000774654fd794a  movaps [rdx], xmm15
0000774654fd794e  movaps [rcx], xmm14
0000774654fd7952  mov rax, 0x564E5D1DDA50
0000774654fd795c  call rax
0000774654fd795e  movaps xmm13, [rsp]
0000774654fd7963  add rsp, 0x40
0000774654fd7967  vmovaps xmm0, [rsp]
0000774654fd796c  vmovaps xmm1, [rsp+0x10]
0000774654fd7972  vmovaps xmm2, [rsp+0x20]
0000774654fd7978  vmovaps xmm3, [rsp+0x30]
0000774654fd797e  vmovaps xmm4, [rsp+0x40]
0000774654fd7984  vmovaps xmm5, [rsp+0x50]
0000774654fd798a  vmovaps xmm6, [rsp+0x60]
0000774654fd7990  vmovaps xmm7, [rsp+0x70]
0000774654fd7996  vmovaps xmm8, [rsp+0x80]
0000774654fd799f  vmovaps xmm9, [rsp+0x90]
0000774654fd79a8  vmovaps xmm10, [rsp+0xA0]
0000774654fd79b1  vmovaps xmm11, [rsp+0xB0]
0000774654fd79ba  vmovaps xmm12, [rsp+0xC0]
0000774654fd79c3  vmovaps xmm14, [rsp+0xD0]
0000774654fd79cc  vmovaps xmm15, [rsp+0xE0]
0000774654fd79d5  add rsp, 0xF0
0000774654fd79dc  pop r11
0000774654fd79de  pop r10
0000774654fd79e0  pop r9
0000774654fd79e2  pop r8
0000774654fd79e4  pop rsi
0000774654fd79e5  pop rdi
0000774654fd79e6  pop rdx
0000774654fd79e7  pop rcx
0000774654fd79e8  pop rax
0000774654fd79e9  add rsp, 0x08
0000774654fd79ed  jmp 0x0000774654FD6C93
0000774654fd79f2  call 0x0000774654DFF430
0000774654fd79f7  jmp 0x0000774654FD6CA0
0000774654fd79fc  sub rsp, 0x08
0000774654fd7a00  push rax
0000774654fd7a01  push rcx
0000774654fd7a02  push rdx
0000774654fd7a03  push rdi
0000774654fd7a04  push rsi
0000774654fd7a05  push r8
0000774654fd7a07  push r9
0000774654fd7a09  push r10
0000774654fd7a0b  push r11
0000774654fd7a0d  sub rsp, 0xF0
0000774654fd7a14  vmovaps [rsp], xmm0
0000774654fd7a19  vmovaps [rsp+0x10], xmm1
0000774654fd7a1f  vmovaps [rsp+0x20], xmm2
0000774654fd7a25  vmovaps [rsp+0x30], xmm3
0000774654fd7a2b  vmovaps [rsp+0x40], xmm4
0000774654fd7a31  vmovaps [rsp+0x50], xmm5
0000774654fd7a37  vmovaps [rsp+0x60], xmm6
0000774654fd7a3d  vmovaps [rsp+0x70], xmm7
0000774654fd7a43  vmovaps [rsp+0x80], xmm8
0000774654fd7a4c  vmovaps [rsp+0x90], xmm9
0000774654fd7a55  vmovaps [rsp+0xA0], xmm10
0000774654fd7a5e  vmovaps [rsp+0xB0], xmm11
0000774654fd7a67  vmovaps [rsp+0xC0], xmm13
0000774654fd7a70  vmovaps [rsp+0xD0], xmm14
0000774654fd7a79  vmovaps [rsp+0xE0], xmm15
0000774654fd7a82  sub rsp, 0x40
0000774654fd7a86  lea rdi, [rsp]
0000774654fd7a8a  lea rsi, [rsp+0x10]
0000774654fd7a8f  lea rdx, [rsp+0x20]
0000774654fd7a94  lea rcx, [rsp+0x30]
0000774654fd7a99  mov r8d, 0x00
0000774654fd7a9f  lea r9, [r15+0x3A8]
0000774654fd7aa6  movaps [rdi], xmm12
0000774654fd7aaa  movaps [rsi], xmm15
0000774654fd7aae  movaps [rdx], xmm1
0000774654fd7ab1  movaps [rcx], xmm14
0000774654fd7ab5  mov rax, 0x564E5D1DDA50
0000774654fd7abf  call rax
0000774654fd7ac1  movaps xmm12, [rsp]
0000774654fd7ac6  add rsp, 0x40
0000774654fd7aca  vmovaps xmm0, [rsp]
0000774654fd7acf  vmovaps xmm1, [rsp+0x10]
0000774654fd7ad5  vmovaps xmm2, [rsp+0x20]
0000774654fd7adb  vmovaps xmm3, [rsp+0x30]
0000774654fd7ae1  vmovaps xmm4, [rsp+0x40]
0000774654fd7ae7  vmovaps xmm5, [rsp+0x50]
0000774654fd7aed  vmovaps xmm6, [rsp+0x60]
0000774654fd7af3  vmovaps xmm7, [rsp+0x70]
0000774654fd7af9  vmovaps xmm8, [rsp+0x80]
0000774654fd7b02  vmovaps xmm9, [rsp+0x90]
0000774654fd7b0b  vmovaps xmm10, [rsp+0xA0]
0000774654fd7b14  vmovaps xmm11, [rsp+0xB0]
0000774654fd7b1d  vmovaps xmm13, [rsp+0xC0]
0000774654fd7b26  vmovaps xmm14, [rsp+0xD0]
0000774654fd7b2f  vmovaps xmm15, [rsp+0xE0]
0000774654fd7b38  add rsp, 0xF0
0000774654fd7b3f  pop r11
0000774654fd7b41  pop r10
0000774654fd7b43  pop r9
0000774654fd7b45  pop r8
0000774654fd7b47  pop rsi
0000774654fd7b48  pop rdi
0000774654fd7b49  pop rdx
0000774654fd7b4a  pop rcx
0000774654fd7b4b  pop rax
0000774654fd7b4c  add rsp, 0x08
0000774654fd7b50  jmp 0x0000774654FD6CCC
0000774654fd7b55  sub rsp, 0x08
0000774654fd7b59  push rax
0000774654fd7b5a  push rcx
0000774654fd7b5b  push rdx
0000774654fd7b5c  push rdi
0000774654fd7b5d  push rsi
0000774654fd7b5e  push r8
0000774654fd7b60  push r9
0000774654fd7b62  push r10
0000774654fd7b64  push r11
0000774654fd7b66  sub rsp, 0xF0
0000774654fd7b6d  vmovaps [rsp], xmm0
0000774654fd7b72  vmovaps [rsp+0x10], xmm1
0000774654fd7b78  vmovaps [rsp+0x20], xmm2
0000774654fd7b7e  vmovaps [rsp+0x30], xmm3
0000774654fd7b84  vmovaps [rsp+0x40], xmm4
0000774654fd7b8a  vmovaps [rsp+0x50], xmm5
0000774654fd7b90  vmovaps [rsp+0x60], xmm6
0000774654fd7b96  vmovaps [rsp+0x70], xmm7
0000774654fd7b9c  vmovaps [rsp+0x80], xmm8
0000774654fd7ba5  vmovaps [rsp+0x90], xmm9
0000774654fd7bae  vmovaps [rsp+0xA0], xmm10
0000774654fd7bb7  vmovaps [rsp+0xB0], xmm11
0000774654fd7bc0  vmovaps [rsp+0xC0], xmm12
0000774654fd7bc9  vmovaps [rsp+0xD0], xmm14
0000774654fd7bd2  vmovaps [rsp+0xE0], xmm15
0000774654fd7bdb  sub rsp, 0x40
0000774654fd7bdf  lea rdi, [rsp]
0000774654fd7be3  lea rsi, [rsp+0x10]
0000774654fd7be8  lea rdx, [rsp+0x20]
0000774654fd7bed  lea rcx, [rsp+0x30]
0000774654fd7bf2  mov r8d, 0x00
0000774654fd7bf8  lea r9, [r15+0x3A8]
0000774654fd7bff  movaps [rdi], xmm13
0000774654fd7c03  movaps [rsi], xmm1
0000774654fd7c06  movaps [rdx], xmm15
0000774654fd7c0a  movaps [rcx], xmm14
0000774654fd7c0e  mov rax, 0x564E5D1DDA50
0000774654fd7c18  call rax
0000774654fd7c1a  movaps xmm13, [rsp]
0000774654fd7c1f  add rsp, 0x40
0000774654fd7c23  vmovaps xmm0, [rsp]
0000774654fd7c28  vmovaps xmm1, [rsp+0x10]
0000774654fd7c2e  vmovaps xmm2, [rsp+0x20]
0000774654fd7c34  vmovaps xmm3, [rsp+0x30]
0000774654fd7c3a  vmovaps xmm4, [rsp+0x40]
0000774654fd7c40  vmovaps xmm5, [rsp+0x50]
0000774654fd7c46  vmovaps xmm6, [rsp+0x60]
0000774654fd7c4c  vmovaps xmm7, [rsp+0x70]
0000774654fd7c52  vmovaps xmm8, [rsp+0x80]
0000774654fd7c5b  vmovaps xmm9, [rsp+0x90]
0000774654fd7c64  vmovaps xmm10, [rsp+0xA0]
0000774654fd7c6d  vmovaps xmm11, [rsp+0xB0]
0000774654fd7c76  vmovaps xmm12, [rsp+0xC0]
0000774654fd7c7f  vmovaps xmm14, [rsp+0xD0]
0000774654fd7c88  vmovaps xmm15, [rsp+0xE0]
0000774654fd7c91  add rsp, 0xF0
0000774654fd7c98  pop r11
0000774654fd7c9a  pop r10
0000774654fd7c9c  pop r9
0000774654fd7c9e  pop r8
0000774654fd7ca0  pop rsi
0000774654fd7ca1  pop rdi
0000774654fd7ca2  pop rdx
0000774654fd7ca3  pop rcx
0000774654fd7ca4  pop rax
0000774654fd7ca5  add rsp, 0x08
0000774654fd7ca9  jmp 0x0000774654FD6E6D
0000774654fd7cae  sub rsp, 0x08
0000774654fd7cb2  push rax
0000774654fd7cb3  push rcx
0000774654fd7cb4  push rdx
0000774654fd7cb5  push rdi
0000774654fd7cb6  push rsi
0000774654fd7cb7  push r8
0000774654fd7cb9  push r9
0000774654fd7cbb  push r10
0000774654fd7cbd  push r11
0000774654fd7cbf  sub rsp, 0xF0
0000774654fd7cc6  vmovaps [rsp], xmm0
0000774654fd7ccb  vmovaps [rsp+0x10], xmm1
0000774654fd7cd1  vmovaps [rsp+0x20], xmm2
0000774654fd7cd7  vmovaps [rsp+0x30], xmm3
0000774654fd7cdd  vmovaps [rsp+0x40], xmm4
0000774654fd7ce3  vmovaps [rsp+0x50], xmm5
0000774654fd7ce9  vmovaps [rsp+0x60], xmm6
0000774654fd7cef  vmovaps [rsp+0x70], xmm7
0000774654fd7cf5  vmovaps [rsp+0x80], xmm8
0000774654fd7cfe  vmovaps [rsp+0x90], xmm9
0000774654fd7d07  vmovaps [rsp+0xA0], xmm10
0000774654fd7d10  vmovaps [rsp+0xB0], xmm11
0000774654fd7d19  vmovaps [rsp+0xC0], xmm13
0000774654fd7d22  vmovaps [rsp+0xD0], xmm14
0000774654fd7d2b  vmovaps [rsp+0xE0], xmm15
0000774654fd7d34  sub rsp, 0x40
0000774654fd7d38  lea rdi, [rsp]
0000774654fd7d3c  lea rsi, [rsp+0x10]
0000774654fd7d41  lea rdx, [rsp+0x20]
0000774654fd7d46  lea rcx, [rsp+0x30]
0000774654fd7d4b  mov r8d, 0x00
0000774654fd7d51  lea r9, [r15+0x3A8]
0000774654fd7d58  movaps [rdi], xmm12
0000774654fd7d5c  movaps [rsi], xmm15
0000774654fd7d60  movaps [rdx], xmm14
0000774654fd7d64  movaps [rcx], xmm1
0000774654fd7d67  mov rax, 0x564E5D1DDA50
0000774654fd7d71  call rax
0000774654fd7d73  movaps xmm12, [rsp]
0000774654fd7d78  add rsp, 0x40
0000774654fd7d7c  vmovaps xmm0, [rsp]
0000774654fd7d81  vmovaps xmm1, [rsp+0x10]
0000774654fd7d87  vmovaps xmm2, [rsp+0x20]
0000774654fd7d8d  vmovaps xmm3, [rsp+0x30]
0000774654fd7d93  vmovaps xmm4, [rsp+0x40]
0000774654fd7d99  vmovaps xmm5, [rsp+0x50]
0000774654fd7d9f  vmovaps xmm6, [rsp+0x60]
0000774654fd7da5  vmovaps xmm7, [rsp+0x70]
0000774654fd7dab  vmovaps xmm8, [rsp+0x80]
0000774654fd7db4  vmovaps xmm9, [rsp+0x90]
0000774654fd7dbd  vmovaps xmm10, [rsp+0xA0]
0000774654fd7dc6  vmovaps xmm11, [rsp+0xB0]
0000774654fd7dcf  vmovaps xmm13, [rsp+0xC0]
0000774654fd7dd8  vmovaps xmm14, [rsp+0xD0]
0000774654fd7de1  vmovaps xmm15, [rsp+0xE0]
0000774654fd7dea  add rsp, 0xF0
0000774654fd7df1  pop r11
0000774654fd7df3  pop r10
0000774654fd7df5  pop r9
0000774654fd7df7  pop r8
0000774654fd7df9  pop rsi
0000774654fd7dfa  pop rdi
0000774654fd7dfb  pop rdx
0000774654fd7dfc  pop rcx
0000774654fd7dfd  pop rax
0000774654fd7dfe  add rsp, 0x08
0000774654fd7e02  jmp 0x0000774654FD6EAB
0000774654fd7e07  sub rsp, 0x08
0000774654fd7e0b  push rax
0000774654fd7e0c  push rcx
0000774654fd7e0d  push rdx
0000774654fd7e0e  push rdi
0000774654fd7e0f  push rsi
0000774654fd7e10  push r8
0000774654fd7e12  push r9
0000774654fd7e14  push r10
0000774654fd7e16  push r11
0000774654fd7e18  sub rsp, 0xF0
0000774654fd7e1f  vmovaps [rsp], xmm0
0000774654fd7e24  vmovaps [rsp+0x10], xmm1
0000774654fd7e2a  vmovaps [rsp+0x20], xmm2
0000774654fd7e30  vmovaps [rsp+0x30], xmm3
0000774654fd7e36  vmovaps [rsp+0x40], xmm4
0000774654fd7e3c  vmovaps [rsp+0x50], xmm5
0000774654fd7e42  vmovaps [rsp+0x60], xmm6
0000774654fd7e48  vmovaps [rsp+0x70], xmm7
0000774654fd7e4e  vmovaps [rsp+0x80], xmm8
0000774654fd7e57  vmovaps [rsp+0x90], xmm9
0000774654fd7e60  vmovaps [rsp+0xA0], xmm10
0000774654fd7e69  vmovaps [rsp+0xB0], xmm11
0000774654fd7e72  vmovaps [rsp+0xC0], xmm12
0000774654fd7e7b  vmovaps [rsp+0xD0], xmm14
0000774654fd7e84  vmovaps [rsp+0xE0], xmm15
0000774654fd7e8d  sub rsp, 0x40
0000774654fd7e91  lea rdi, [rsp]
0000774654fd7e95  lea rsi, [rsp+0x10]
0000774654fd7e9a  lea rdx, [rsp+0x20]
0000774654fd7e9f  lea rcx, [rsp+0x30]
0000774654fd7ea4  mov r8d, 0x00
0000774654fd7eaa  lea r9, [r15+0x3A8]
0000774654fd7eb1  movaps [rdi], xmm13
0000774654fd7eb5  movaps [rsi], xmm15
0000774654fd7eb9  movaps [rdx], xmm14
0000774654fd7ebd  movaps [rcx], xmm1
0000774654fd7ec0  mov rax, 0x564E5D1DDA50
0000774654fd7eca  call rax
0000774654fd7ecc  movaps xmm13, [rsp]
0000774654fd7ed1  add rsp, 0x40
0000774654fd7ed5  vmovaps xmm0, [rsp]
0000774654fd7eda  vmovaps xmm1, [rsp+0x10]
0000774654fd7ee0  vmovaps xmm2, [rsp+0x20]
0000774654fd7ee6  vmovaps xmm3, [rsp+0x30]
0000774654fd7eec  vmovaps xmm4, [rsp+0x40]
0000774654fd7ef2  vmovaps xmm5, [rsp+0x50]
0000774654fd7ef8  vmovaps xmm6, [rsp+0x60]
0000774654fd7efe  vmovaps xmm7, [rsp+0x70]
0000774654fd7f04  vmovaps xmm8, [rsp+0x80]
0000774654fd7f0d  vmovaps xmm9, [rsp+0x90]
0000774654fd7f16  vmovaps xmm10, [rsp+0xA0]
0000774654fd7f1f  vmovaps xmm11, [rsp+0xB0]
0000774654fd7f28  vmovaps xmm12, [rsp+0xC0]
0000774654fd7f31  vmovaps xmm14, [rsp+0xD0]
0000774654fd7f3a  vmovaps xmm15, [rsp+0xE0]
0000774654fd7f43  add rsp, 0xF0
0000774654fd7f4a  pop r11
0000774654fd7f4c  pop r10
0000774654fd7f4e  pop r9
0000774654fd7f50  pop r8
0000774654fd7f52  pop rsi
0000774654fd7f53  pop rdi
0000774654fd7f54  pop rdx
0000774654fd7f55  pop rcx
0000774654fd7f56  pop rax
0000774654fd7f57  add rsp, 0x08
0000774654fd7f5b  jmp 0x0000774654FD6EE9
0000774654fd7f60  sub rsp, 0x08
0000774654fd7f64  push rax
0000774654fd7f65  push rcx
0000774654fd7f66  push rdx
0000774654fd7f67  push rdi
0000774654fd7f68  push rsi
0000774654fd7f69  push r8
0000774654fd7f6b  push r9
0000774654fd7f6d  push r10
0000774654fd7f6f  push r11
0000774654fd7f71  sub rsp, 0xF0
0000774654fd7f78  vmovaps [rsp], xmm0
0000774654fd7f7d  vmovaps [rsp+0x10], xmm1
0000774654fd7f83  vmovaps [rsp+0x20], xmm2
0000774654fd7f89  vmovaps [rsp+0x30], xmm3
0000774654fd7f8f  vmovaps [rsp+0x40], xmm4
0000774654fd7f95  vmovaps [rsp+0x50], xmm5
0000774654fd7f9b  vmovaps [rsp+0x60], xmm6
0000774654fd7fa1  vmovaps [rsp+0x70], xmm7
0000774654fd7fa7  vmovaps [rsp+0x80], xmm8
0000774654fd7fb0  vmovaps [rsp+0x90], xmm9
0000774654fd7fb9  vmovaps [rsp+0xA0], xmm10
0000774654fd7fc2  vmovaps [rsp+0xB0], xmm11
0000774654fd7fcb  vmovaps [rsp+0xC0], xmm13
0000774654fd7fd4  vmovaps [rsp+0xD0], xmm14
0000774654fd7fdd  vmovaps [rsp+0xE0], xmm15
0000774654fd7fe6  sub rsp, 0x40
0000774654fd7fea  lea rdi, [rsp]
0000774654fd7fee  lea rsi, [rsp+0x10]
0000774654fd7ff3  lea rdx, [rsp+0x20]
0000774654fd7ff8  lea rcx, [rsp+0x30]
0000774654fd7ffd  mov r8d, 0x00
0000774654fd8003  lea r9, [r15+0x3A8]
0000774654fd800a  movaps [rdi], xmm12
0000774654fd800e  movaps [rsi], xmm14
0000774654fd8012  movaps [rdx], xmm2
0000774654fd8015  movaps [rcx], xmm15
0000774654fd8019  mov rax, 0x564E5D1DDA50
0000774654fd8023  call rax
0000774654fd8025  movaps xmm12, [rsp]
0000774654fd802a  add rsp, 0x40
0000774654fd802e  vmovaps xmm0, [rsp]
0000774654fd8033  vmovaps xmm1, [rsp+0x10]
0000774654fd8039  vmovaps xmm2, [rsp+0x20]
0000774654fd803f  vmovaps xmm3, [rsp+0x30]
0000774654fd8045  vmovaps xmm4, [rsp+0x40]
0000774654fd804b  vmovaps xmm5, [rsp+0x50]
0000774654fd8051  vmovaps xmm6, [rsp+0x60]
0000774654fd8057  vmovaps xmm7, [rsp+0x70]
0000774654fd805d  vmovaps xmm8, [rsp+0x80]
0000774654fd8066  vmovaps xmm9, [rsp+0x90]
0000774654fd806f  vmovaps xmm10, [rsp+0xA0]
0000774654fd8078  vmovaps xmm11, [rsp+0xB0]
0000774654fd8081  vmovaps xmm13, [rsp+0xC0]
0000774654fd808a  vmovaps xmm14, [rsp+0xD0]
0000774654fd8093  vmovaps xmm15, [rsp+0xE0]
0000774654fd809c  add rsp, 0xF0
0000774654fd80a3  pop r11
0000774654fd80a5  pop r10
0000774654fd80a7  pop r9
0000774654fd80a9  pop r8
0000774654fd80ab  pop rsi
0000774654fd80ac  pop rdi
0000774654fd80ad  pop rdx
0000774654fd80ae  pop rcx
0000774654fd80af  pop rax
0000774654fd80b0  add rsp, 0x08
0000774654fd80b4  jmp 0x0000774654FD6F43
0000774654fd80b9  sub rsp, 0x08
0000774654fd80bd  push rax
0000774654fd80be  push rcx
0000774654fd80bf  push rdx
0000774654fd80c0  push rdi
0000774654fd80c1  push rsi
0000774654fd80c2  push r8
0000774654fd80c4  push r9
0000774654fd80c6  push r10
0000774654fd80c8  push r11
0000774654fd80ca  sub rsp, 0xF0
0000774654fd80d1  vmovaps [rsp], xmm0
0000774654fd80d6  vmovaps [rsp+0x10], xmm1
0000774654fd80dc  vmovaps [rsp+0x20], xmm3
0000774654fd80e2  vmovaps [rsp+0x30], xmm4
0000774654fd80e8  vmovaps [rsp+0x40], xmm5
0000774654fd80ee  vmovaps [rsp+0x50], xmm6
0000774654fd80f4  vmovaps [rsp+0x60], xmm7
0000774654fd80fa  vmovaps [rsp+0x70], xmm8
0000774654fd8100  vmovaps [rsp+0x80], xmm9
0000774654fd8109  vmovaps [rsp+0x90], xmm10
0000774654fd8112  vmovaps [rsp+0xA0], xmm11
0000774654fd811b  vmovaps [rsp+0xB0], xmm12
0000774654fd8124  vmovaps [rsp+0xC0], xmm13
0000774654fd812d  vmovaps [rsp+0xD0], xmm14
0000774654fd8136  vmovaps [rsp+0xE0], xmm15
0000774654fd813f  sub rsp, 0x40
0000774654fd8143  lea rdi, [rsp]
0000774654fd8147  lea rsi, [rsp+0x10]
0000774654fd814c  lea rdx, [rsp+0x20]
0000774654fd8151  lea rcx, [rsp+0x30]
0000774654fd8156  mov r8d, 0x00
0000774654fd815c  lea r9, [r15+0x3A8]
0000774654fd8163  movaps [rdi], xmm2
0000774654fd8166  movaps [rsi], xmm14
0000774654fd816a  movaps [rdx], xmm8
0000774654fd816e  movaps [rcx], xmm5
0000774654fd8171  mov rax, 0x564E5D1DDA50
0000774654fd817b  call rax
0000774654fd817d  movaps xmm2, [rsp]
0000774654fd8181  add rsp, 0x40
0000774654fd8185  vmovaps xmm0, [rsp]
0000774654fd818a  vmovaps xmm1, [rsp+0x10]
0000774654fd8190  vmovaps xmm3, [rsp+0x20]
0000774654fd8196  vmovaps xmm4, [rsp+0x30]
0000774654fd819c  vmovaps xmm5, [rsp+0x40]
0000774654fd81a2  vmovaps xmm6, [rsp+0x50]
0000774654fd81a8  vmovaps xmm7, [rsp+0x60]
0000774654fd81ae  vmovaps xmm8, [rsp+0x70]
0000774654fd81b4  vmovaps xmm9, [rsp+0x80]
0000774654fd81bd  vmovaps xmm10, [rsp+0x90]
0000774654fd81c6  vmovaps xmm11, [rsp+0xA0]
0000774654fd81cf  vmovaps xmm12, [rsp+0xB0]
0000774654fd81d8  vmovaps xmm13, [rsp+0xC0]
0000774654fd81e1  vmovaps xmm14, [rsp+0xD0]
0000774654fd81ea  vmovaps xmm15, [rsp+0xE0]
0000774654fd81f3  add rsp, 0xF0
0000774654fd81fa  pop r11
0000774654fd81fc  pop r10
0000774654fd81fe  pop r9
0000774654fd8200  pop r8
0000774654fd8202  pop rsi
0000774654fd8203  pop rdi
0000774654fd8204  pop rdx
0000774654fd8205  pop rcx
0000774654fd8206  pop rax
0000774654fd8207  add rsp, 0x08
0000774654fd820b  jmp 0x0000774654FD6FF7
0000774654fd8210  sub rsp, 0x08
0000774654fd8214  push rax
0000774654fd8215  push rcx
0000774654fd8216  push rdx
0000774654fd8217  push rdi
0000774654fd8218  push rsi
0000774654fd8219  push r8
0000774654fd821b  push r9
0000774654fd821d  push r10
0000774654fd821f  push r11
0000774654fd8221  sub rsp, 0xF0
0000774654fd8228  vmovaps [rsp], xmm0
0000774654fd822d  vmovaps [rsp+0x10], xmm1
0000774654fd8233  vmovaps [rsp+0x20], xmm2
0000774654fd8239  vmovaps [rsp+0x30], xmm3
0000774654fd823f  vmovaps [rsp+0x40], xmm4
0000774654fd8245  vmovaps [rsp+0x50], xmm6
0000774654fd824b  vmovaps [rsp+0x60], xmm7
0000774654fd8251  vmovaps [rsp+0x70], xmm8
0000774654fd8257  vmovaps [rsp+0x80], xmm9
0000774654fd8260  vmovaps [rsp+0x90], xmm10
0000774654fd8269  vmovaps [rsp+0xA0], xmm11
0000774654fd8272  vmovaps [rsp+0xB0], xmm12
0000774654fd827b  vmovaps [rsp+0xC0], xmm13
0000774654fd8284  vmovaps [rsp+0xD0], xmm14
0000774654fd828d  vmovaps [rsp+0xE0], xmm15
0000774654fd8296  sub rsp, 0x40
0000774654fd829a  lea rdi, [rsp]
0000774654fd829e  lea rsi, [rsp+0x10]
0000774654fd82a3  lea rdx, [rsp+0x20]
0000774654fd82a8  lea rcx, [rsp+0x30]
0000774654fd82ad  mov r8d, 0x00
0000774654fd82b3  lea r9, [r15+0x3A8]
0000774654fd82ba  movaps [rdi], xmm5
0000774654fd82bd  movaps [rsi], xmm14
0000774654fd82c1  movaps [rdx], xmm8
0000774654fd82c5  movaps [rcx], xmm1
0000774654fd82c8  mov rax, 0x564E5D1DDA50
0000774654fd82d2  call rax
0000774654fd82d4  movaps xmm5, [rsp]
0000774654fd82d8  add rsp, 0x40
0000774654fd82dc  vmovaps xmm0, [rsp]
0000774654fd82e1  vmovaps xmm1, [rsp+0x10]
0000774654fd82e7  vmovaps xmm2, [rsp+0x20]
0000774654fd82ed  vmovaps xmm3, [rsp+0x30]
0000774654fd82f3  vmovaps xmm4, [rsp+0x40]
0000774654fd82f9  vmovaps xmm6, [rsp+0x50]
0000774654fd82ff  vmovaps xmm7, [rsp+0x60]
0000774654fd8305  vmovaps xmm8, [rsp+0x70]
0000774654fd830b  vmovaps xmm9, [rsp+0x80]
0000774654fd8314  vmovaps xmm10, [rsp+0x90]
0000774654fd831d  vmovaps xmm11, [rsp+0xA0]
0000774654fd8326  vmovaps xmm12, [rsp+0xB0]
0000774654fd832f  vmovaps xmm13, [rsp+0xC0]
0000774654fd8338  vmovaps xmm14, [rsp+0xD0]
0000774654fd8341  vmovaps xmm15, [rsp+0xE0]
0000774654fd834a  add rsp, 0xF0
0000774654fd8351  pop r11
0000774654fd8353  pop r10
0000774654fd8355  pop r9
0000774654fd8357  pop r8
0000774654fd8359  pop rsi
0000774654fd835a  pop rdi
0000774654fd835b  pop rdx
0000774654fd835c  pop rcx
0000774654fd835d  pop rax
0000774654fd835e  add rsp, 0x08
0000774654fd8362  jmp 0x0000774654FD7034
0000774654fd8367  sub rsp, 0x08
0000774654fd836b  push rax
0000774654fd836c  push rcx
0000774654fd836d  push rdx
0000774654fd836e  push rdi
0000774654fd836f  push rsi
0000774654fd8370  push r8
0000774654fd8372  push r9
0000774654fd8374  push r10
0000774654fd8376  push r11
0000774654fd8378  sub rsp, 0xF0
0000774654fd837f  vmovaps [rsp], xmm0
0000774654fd8384  vmovaps [rsp+0x10], xmm1
0000774654fd838a  vmovaps [rsp+0x20], xmm2
0000774654fd8390  vmovaps [rsp+0x30], xmm3
0000774654fd8396  vmovaps [rsp+0x40], xmm4
0000774654fd839c  vmovaps [rsp+0x50], xmm5
0000774654fd83a2  vmovaps [rsp+0x60], xmm6
0000774654fd83a8  vmovaps [rsp+0x70], xmm7
0000774654fd83ae  vmovaps [rsp+0x80], xmm8
0000774654fd83b7  vmovaps [rsp+0x90], xmm9
0000774654fd83c0  vmovaps [rsp+0xA0], xmm10
0000774654fd83c9  vmovaps [rsp+0xB0], xmm11
0000774654fd83d2  vmovaps [rsp+0xC0], xmm12
0000774654fd83db  vmovaps [rsp+0xD0], xmm13
0000774654fd83e4  vmovaps [rsp+0xE0], xmm14
0000774654fd83ed  sub rsp, 0x40
0000774654fd83f1  lea rdi, [rsp]
0000774654fd83f5  lea rsi, [rsp+0x10]
0000774654fd83fa  lea rdx, [rsp+0x20]
0000774654fd83ff  lea rcx, [rsp+0x30]
0000774654fd8404  mov r8d, 0x00
0000774654fd840a  lea r9, [r15+0x3A8]
0000774654fd8411  movaps [rdi], xmm15
0000774654fd8415  movaps [rsi], xmm13
0000774654fd8419  movaps [rdx], xmm14
0000774654fd841d  movaps [rcx], xmm1
0000774654fd8420  mov rax, 0x564E5D1DDA50
0000774654fd842a  call rax
0000774654fd842c  movaps xmm15, [rsp]
0000774654fd8431  add rsp, 0x40
0000774654fd8435  vmovaps xmm0, [rsp]
0000774654fd843a  vmovaps xmm1, [rsp+0x10]
0000774654fd8440  vmovaps xmm2, [rsp+0x20]
0000774654fd8446  vmovaps xmm3, [rsp+0x30]
0000774654fd844c  vmovaps xmm4, [rsp+0x40]
0000774654fd8452  vmovaps xmm5, [rsp+0x50]
0000774654fd8458  vmovaps xmm6, [rsp+0x60]
0000774654fd845e  vmovaps xmm7, [rsp+0x70]
0000774654fd8464  vmovaps xmm8, [rsp+0x80]
0000774654fd846d  vmovaps xmm9, [rsp+0x90]
0000774654fd8476  vmovaps xmm10, [rsp+0xA0]
0000774654fd847f  vmovaps xmm11, [rsp+0xB0]
0000774654fd8488  vmovaps xmm12, [rsp+0xC0]
0000774654fd8491  vmovaps xmm13, [rsp+0xD0]
0000774654fd849a  vmovaps xmm14, [rsp+0xE0]
0000774654fd84a3  add rsp, 0xF0
0000774654fd84aa  pop r11
0000774654fd84ac  pop r10
0000774654fd84ae  pop r9
0000774654fd84b0  pop r8
0000774654fd84b2  pop rsi
0000774654fd84b3  pop rdi
0000774654fd84b4  pop rdx
0000774654fd84b5  pop rcx
0000774654fd84b6  pop rax
0000774654fd84b7  add rsp, 0x08
0000774654fd84bb  jmp 0x0000774654FD7063
0000774654fd84c0  sub rsp, 0x08
0000774654fd84c4  push rax
0000774654fd84c5  push rcx
0000774654fd84c6  push rdx
0000774654fd84c7  push rdi
0000774654fd84c8  push rsi
0000774654fd84c9  push r8
0000774654fd84cb  push r9
0000774654fd84cd  push r10
0000774654fd84cf  push r11
0000774654fd84d1  sub rsp, 0xF0
0000774654fd84d8  vmovaps [rsp], xmm0
0000774654fd84dd  vmovaps [rsp+0x10], xmm1
0000774654fd84e3  vmovaps [rsp+0x20], xmm2
0000774654fd84e9  vmovaps [rsp+0x30], xmm3
0000774654fd84ef  vmovaps [rsp+0x40], xmm4
0000774654fd84f5  vmovaps [rsp+0x50], xmm5
0000774654fd84fb  vmovaps [rsp+0x60], xmm6
0000774654fd8501  vmovaps [rsp+0x70], xmm7
0000774654fd8507  vmovaps [rsp+0x80], xmm8
0000774654fd8510  vmovaps [rsp+0x90], xmm9
0000774654fd8519  vmovaps [rsp+0xA0], xmm10
0000774654fd8522  vmovaps [rsp+0xB0], xmm11
0000774654fd852b  vmovaps [rsp+0xC0], xmm12
0000774654fd8534  vmovaps [rsp+0xD0], xmm14
0000774654fd853d  vmovaps [rsp+0xE0], xmm15
0000774654fd8546  sub rsp, 0x40
0000774654fd854a  lea rdi, [rsp]
0000774654fd854e  lea rsi, [rsp+0x10]
0000774654fd8553  lea rdx, [rsp+0x20]
0000774654fd8558  lea rcx, [rsp+0x30]
0000774654fd855d  mov r8d, 0x00
0000774654fd8563  lea r9, [r15+0x3A8]
0000774654fd856a  movaps [rdi], xmm13
0000774654fd856e  movaps [rsi], xmm12
0000774654fd8572  movaps [rdx], xmm14
0000774654fd8576  movaps [rcx], xmm1
0000774654fd8579  mov rax, 0x564E5D1DDA50
0000774654fd8583  call rax
0000774654fd8585  movaps xmm13, [rsp]
0000774654fd858a  add rsp, 0x40
0000774654fd858e  vmovaps xmm0, [rsp]
0000774654fd8593  vmovaps xmm1, [rsp+0x10]
0000774654fd8599  vmovaps xmm2, [rsp+0x20]
0000774654fd859f  vmovaps xmm3, [rsp+0x30]
0000774654fd85a5  vmovaps xmm4, [rsp+0x40]
0000774654fd85ab  vmovaps xmm5, [rsp+0x50]
0000774654fd85b1  vmovaps xmm6, [rsp+0x60]
0000774654fd85b7  vmovaps xmm7, [rsp+0x70]
0000774654fd85bd  vmovaps xmm8, [rsp+0x80]
0000774654fd85c6  vmovaps xmm9, [rsp+0x90]
0000774654fd85cf  vmovaps xmm10, [rsp+0xA0]
0000774654fd85d8  vmovaps xmm11, [rsp+0xB0]
0000774654fd85e1  vmovaps xmm12, [rsp+0xC0]
0000774654fd85ea  vmovaps xmm14, [rsp+0xD0]
0000774654fd85f3  vmovaps xmm15, [rsp+0xE0]
0000774654fd85fc  add rsp, 0xF0
0000774654fd8603  pop r11
0000774654fd8605  pop r10
0000774654fd8607  pop r9
0000774654fd8609  pop r8
0000774654fd860b  pop rsi
0000774654fd860c  pop rdi
0000774654fd860d  pop rdx
0000774654fd860e  pop rcx
0000774654fd860f  pop rax
0000774654fd8610  add rsp, 0x08
0000774654fd8614  jmp 0x0000774654FD7095
0000774654fd8619  sub rsp, 0x08
0000774654fd861d  push rax
0000774654fd861e  push rcx
0000774654fd861f  push rdx
0000774654fd8620  push rdi
0000774654fd8621  push rsi
0000774654fd8622  push r8
0000774654fd8624  push r9
0000774654fd8626  push r10
0000774654fd8628  push r11
0000774654fd862a  sub rsp, 0xF0
0000774654fd8631  vmovaps [rsp], xmm0
0000774654fd8636  vmovaps [rsp+0x10], xmm1
0000774654fd863c  vmovaps [rsp+0x20], xmm2
0000774654fd8642  vmovaps [rsp+0x30], xmm3
0000774654fd8648  vmovaps [rsp+0x40], xmm4
0000774654fd864e  vmovaps [rsp+0x50], xmm5
0000774654fd8654  vmovaps [rsp+0x60], xmm6
0000774654fd865a  vmovaps [rsp+0x70], xmm7
0000774654fd8660  vmovaps [rsp+0x80], xmm8
0000774654fd8669  vmovaps [rsp+0x90], xmm9
0000774654fd8672  vmovaps [rsp+0xA0], xmm10
0000774654fd867b  vmovaps [rsp+0xB0], xmm11
0000774654fd8684  vmovaps [rsp+0xC0], xmm13
0000774654fd868d  vmovaps [rsp+0xD0], xmm14
0000774654fd8696  vmovaps [rsp+0xE0], xmm15
0000774654fd869f  sub rsp, 0x40
0000774654fd86a3  lea rdi, [rsp]
0000774654fd86a7  lea rsi, [rsp+0x10]
0000774654fd86ac  lea rdx, [rsp+0x20]
0000774654fd86b1  lea rcx, [rsp+0x30]
0000774654fd86b6  mov r8d, 0x00
0000774654fd86bc  lea r9, [r15+0x3A8]
0000774654fd86c3  movaps [rdi], xmm12
0000774654fd86c7  movaps [rsi], xmm5
0000774654fd86ca  movaps [rdx], xmm14
0000774654fd86ce  movaps [rcx], xmm4
0000774654fd86d1  mov rax, 0x564E5D1DDA50
0000774654fd86db  call rax
0000774654fd86dd  movaps xmm12, [rsp]
0000774654fd86e2  add rsp, 0x40
0000774654fd86e6  vmovaps xmm0, [rsp]
0000774654fd86eb  vmovaps xmm1, [rsp+0x10]
0000774654fd86f1  vmovaps xmm2, [rsp+0x20]
0000774654fd86f7  vmovaps xmm3, [rsp+0x30]
0000774654fd86fd  vmovaps xmm4, [rsp+0x40]
0000774654fd8703  vmovaps xmm5, [rsp+0x50]
0000774654fd8709  vmovaps xmm6, [rsp+0x60]
0000774654fd870f  vmovaps xmm7, [rsp+0x70]
0000774654fd8715  vmovaps xmm8, [rsp+0x80]
0000774654fd871e  vmovaps xmm9, [rsp+0x90]
0000774654fd8727  vmovaps xmm10, [rsp+0xA0]
0000774654fd8730  vmovaps xmm11, [rsp+0xB0]
0000774654fd8739  vmovaps xmm13, [rsp+0xC0]
0000774654fd8742  vmovaps xmm14, [rsp+0xD0]
0000774654fd874b  vmovaps xmm15, [rsp+0xE0]
0000774654fd8754  add rsp, 0xF0
0000774654fd875b  pop r11
0000774654fd875d  pop r10
0000774654fd875f  pop r9
0000774654fd8761  pop r8
0000774654fd8763  pop rsi
0000774654fd8764  pop rdi
0000774654fd8765  pop rdx
0000774654fd8766  pop rcx
0000774654fd8767  pop rax
0000774654fd8768  add rsp, 0x08
0000774654fd876c  jmp 0x0000774654FD710B
0000774654fd8771  sub rsp, 0x08
0000774654fd8775  push rax
0000774654fd8776  push rcx
0000774654fd8777  push rdx
0000774654fd8778  push rdi
0000774654fd8779  push rsi
0000774654fd877a  push r8
0000774654fd877c  push r9
0000774654fd877e  push r10
0000774654fd8780  push r11
0000774654fd8782  sub rsp, 0xF0
0000774654fd8789  vmovaps [rsp], xmm0
0000774654fd878e  vmovaps [rsp+0x10], xmm1
0000774654fd8794  vmovaps [rsp+0x20], xmm2
0000774654fd879a  vmovaps [rsp+0x30], xmm3
0000774654fd87a0  vmovaps [rsp+0x40], xmm4
0000774654fd87a6  vmovaps [rsp+0x50], xmm5
0000774654fd87ac  vmovaps [rsp+0x60], xmm6
0000774654fd87b2  vmovaps [rsp+0x70], xmm7
0000774654fd87b8  vmovaps [rsp+0x80], xmm8
0000774654fd87c1  vmovaps [rsp+0x90], xmm9
0000774654fd87ca  vmovaps [rsp+0xA0], xmm11
0000774654fd87d3  vmovaps [rsp+0xB0], xmm12
0000774654fd87dc  vmovaps [rsp+0xC0], xmm13
0000774654fd87e5  vmovaps [rsp+0xD0], xmm14
0000774654fd87ee  vmovaps [rsp+0xE0], xmm15
0000774654fd87f7  sub rsp, 0x40
0000774654fd87fb  lea rdi, [rsp]
0000774654fd87ff  lea rsi, [rsp+0x10]
0000774654fd8804  lea rdx, [rsp+0x20]
0000774654fd8809  lea rcx, [rsp+0x30]
0000774654fd880e  mov r8d, 0x00
0000774654fd8814  lea r9, [r15+0x3A8]
0000774654fd881b  movaps [rdi], xmm10
0000774654fd881f  movaps [rsi], xmm2
0000774654fd8822  movaps [rdx], xmm6
0000774654fd8825  movaps [rcx], xmm14
0000774654fd8829  mov rax, 0x564E5D1DDA50
0000774654fd8833  call rax
0000774654fd8835  movaps xmm10, [rsp]
0000774654fd883a  add rsp, 0x40
0000774654fd883e  vmovaps xmm0, [rsp]
0000774654fd8843  vmovaps xmm1, [rsp+0x10]
0000774654fd8849  vmovaps xmm2, [rsp+0x20]
0000774654fd884f  vmovaps xmm3, [rsp+0x30]
0000774654fd8855  vmovaps xmm4, [rsp+0x40]
0000774654fd885b  vmovaps xmm5, [rsp+0x50]
0000774654fd8861  vmovaps xmm6, [rsp+0x60]
0000774654fd8867  vmovaps xmm7, [rsp+0x70]
0000774654fd886d  vmovaps xmm8, [rsp+0x80]
0000774654fd8876  vmovaps xmm9, [rsp+0x90]
0000774654fd887f  vmovaps xmm11, [rsp+0xA0]
0000774654fd8888  vmovaps xmm12, [rsp+0xB0]
0000774654fd8891  vmovaps xmm13, [rsp+0xC0]
0000774654fd889a  vmovaps xmm14, [rsp+0xD0]
0000774654fd88a3  vmovaps xmm15, [rsp+0xE0]
0000774654fd88ac  add rsp, 0xF0
0000774654fd88b3  pop r11
0000774654fd88b5  pop r10
0000774654fd88b7  pop r9
0000774654fd88b9  pop r8
0000774654fd88bb  pop rsi
0000774654fd88bc  pop rdi
0000774654fd88bd  pop rdx
0000774654fd88be  pop rcx
0000774654fd88bf  pop rax
0000774654fd88c0  add rsp, 0x08
0000774654fd88c4  jmp 0x0000774654FD7131
0000774654fd88c9  call 0x0000774654E0D4E0
0000774654fd88ce  jmp 0x0000774654FD713E
0000774654fd88d3  sub rsp, 0x08
0000774654fd88d7  push rax
0000774654fd88d8  push rcx
0000774654fd88d9  push rdx
0000774654fd88da  push rdi
0000774654fd88db  push rsi
0000774654fd88dc  push r8
0000774654fd88de  push r9
0000774654fd88e0  push r10
0000774654fd88e2  push r11
0000774654fd88e4  sub rsp, 0xF0
0000774654fd88eb  vmovaps [rsp], xmm0
0000774654fd88f0  vmovaps [rsp+0x10], xmm1
0000774654fd88f6  vmovaps [rsp+0x20], xmm2
0000774654fd88fc  vmovaps [rsp+0x30], xmm3
0000774654fd8902  vmovaps [rsp+0x40], xmm4
0000774654fd8908  vmovaps [rsp+0x50], xmm6
0000774654fd890e  vmovaps [rsp+0x60], xmm7
0000774654fd8914  vmovaps [rsp+0x70], xmm8
0000774654fd891a  vmovaps [rsp+0x80], xmm9
0000774654fd8923  vmovaps [rsp+0x90], xmm10
0000774654fd892c  vmovaps [rsp+0xA0], xmm11
0000774654fd8935  vmovaps [rsp+0xB0], xmm12
0000774654fd893e  vmovaps [rsp+0xC0], xmm13
0000774654fd8947  vmovaps [rsp+0xD0], xmm14
0000774654fd8950  vmovaps [rsp+0xE0], xmm15
0000774654fd8959  sub rsp, 0x40
0000774654fd895d  lea rdi, [rsp]
0000774654fd8961  lea rsi, [rsp+0x10]
0000774654fd8966  lea rdx, [rsp+0x20]
0000774654fd896b  lea rcx, [rsp+0x30]
0000774654fd8970  mov r8d, 0x00
0000774654fd8976  lea r9, [r15+0x3A8]
0000774654fd897d  movaps [rdi], xmm5
0000774654fd8980  movaps [rsi], xmm15
0000774654fd8984  movaps [rdx], xmm6
0000774654fd8987  movaps [rcx], xmm8
0000774654fd898b  mov rax, 0x564E5D1DDA50
0000774654fd8995  call rax
0000774654fd8997  movaps xmm5, [rsp]
0000774654fd899b  add rsp, 0x40
0000774654fd899f  vmovaps xmm0, [rsp]
0000774654fd89a4  vmovaps xmm1, [rsp+0x10]
0000774654fd89aa  vmovaps xmm2, [rsp+0x20]
0000774654fd89b0  vmovaps xmm3, [rsp+0x30]
0000774654fd89b6  vmovaps xmm4, [rsp+0x40]
0000774654fd89bc  vmovaps xmm6, [rsp+0x50]
0000774654fd89c2  vmovaps xmm7, [rsp+0x60]
0000774654fd89c8  vmovaps xmm8, [rsp+0x70]
0000774654fd89ce  vmovaps xmm9, [rsp+0x80]
0000774654fd89d7  vmovaps xmm10, [rsp+0x90]
0000774654fd89e0  vmovaps xmm11, [rsp+0xA0]
0000774654fd89e9  vmovaps xmm12, [rsp+0xB0]
0000774654fd89f2  vmovaps xmm13, [rsp+0xC0]
0000774654fd89fb  vmovaps xmm14, [rsp+0xD0]
0000774654fd8a04  vmovaps xmm15, [rsp+0xE0]
0000774654fd8a0d  add rsp, 0xF0
0000774654fd8a14  pop r11
0000774654fd8a16  pop r10
0000774654fd8a18  pop r9
0000774654fd8a1a  pop r8
0000774654fd8a1c  pop rsi
0000774654fd8a1d  pop rdi
0000774654fd8a1e  pop rdx
0000774654fd8a1f  pop rcx
0000774654fd8a20  pop rax
0000774654fd8a21  add rsp, 0x08
0000774654fd8a25  jmp 0x0000774654FD7174
0000774654fd8a2a  sub rsp, 0x08
0000774654fd8a2e  push rax
0000774654fd8a2f  push rcx
0000774654fd8a30  push rdx
0000774654fd8a31  push rdi
0000774654fd8a32  push rsi
0000774654fd8a33  push r8
0000774654fd8a35  push r9
0000774654fd8a37  push r10
0000774654fd8a39  push r11
0000774654fd8a3b  sub rsp, 0xF0
0000774654fd8a42  vmovaps [rsp], xmm0
0000774654fd8a47  vmovaps [rsp+0x10], xmm1
0000774654fd8a4d  vmovaps [rsp+0x20], xmm2
0000774654fd8a53  vmovaps [rsp+0x30], xmm3
0000774654fd8a59  vmovaps [rsp+0x40], xmm4
0000774654fd8a5f  vmovaps [rsp+0x50], xmm5
0000774654fd8a65  vmovaps [rsp+0x60], xmm6
0000774654fd8a6b  vmovaps [rsp+0x70], xmm7
0000774654fd8a71  vmovaps [rsp+0x80], xmm9
0000774654fd8a7a  vmovaps [rsp+0x90], xmm10
0000774654fd8a83  vmovaps [rsp+0xA0], xmm11
0000774654fd8a8c  vmovaps [rsp+0xB0], xmm12
0000774654fd8a95  vmovaps [rsp+0xC0], xmm13
0000774654fd8a9e  vmovaps [rsp+0xD0], xmm14
0000774654fd8aa7  vmovaps [rsp+0xE0], xmm15
0000774654fd8ab0  sub rsp, 0x40
0000774654fd8ab4  lea rdi, [rsp]
0000774654fd8ab8  lea rsi, [rsp+0x10]
0000774654fd8abd  lea rdx, [rsp+0x20]
0000774654fd8ac2  lea rcx, [rsp+0x30]
0000774654fd8ac7  mov r8d, 0x00
0000774654fd8acd  lea r9, [r15+0x3A8]
0000774654fd8ad4  movaps [rdi], xmm8
0000774654fd8ad8  movaps [rsi], xmm13
0000774654fd8adc  movaps [rdx], xmm1
0000774654fd8adf  movaps [rcx], xmm15
0000774654fd8ae3  mov rax, 0x564E5D1DDA50
0000774654fd8aed  call rax
0000774654fd8aef  movaps xmm8, [rsp]
0000774654fd8af4  add rsp, 0x40
0000774654fd8af8  vmovaps xmm0, [rsp]
0000774654fd8afd  vmovaps xmm1, [rsp+0x10]
0000774654fd8b03  vmovaps xmm2, [rsp+0x20]
0000774654fd8b09  vmovaps xmm3, [rsp+0x30]
0000774654fd8b0f  vmovaps xmm4, [rsp+0x40]
0000774654fd8b15  vmovaps xmm5, [rsp+0x50]
0000774654fd8b1b  vmovaps xmm6, [rsp+0x60]
0000774654fd8b21  vmovaps xmm7, [rsp+0x70]
0000774654fd8b27  vmovaps xmm9, [rsp+0x80]
0000774654fd8b30  vmovaps xmm10, [rsp+0x90]
0000774654fd8b39  vmovaps xmm11, [rsp+0xA0]
0000774654fd8b42  vmovaps xmm12, [rsp+0xB0]
0000774654fd8b4b  vmovaps xmm13, [rsp+0xC0]
0000774654fd8b54  vmovaps xmm14, [rsp+0xD0]
0000774654fd8b5d  vmovaps xmm15, [rsp+0xE0]
0000774654fd8b66  add rsp, 0xF0
0000774654fd8b6d  pop r11
0000774654fd8b6f  pop r10
0000774654fd8b71  pop r9
0000774654fd8b73  pop r8
0000774654fd8b75  pop rsi
0000774654fd8b76  pop rdi
0000774654fd8b77  pop rdx
0000774654fd8b78  pop rcx
0000774654fd8b79  pop rax
0000774654fd8b7a  add rsp, 0x08
0000774654fd8b7e  jmp 0x0000774654FD719A
0000774654fd8b83  call 0x0000774654E0E760
0000774654fd8b88  jmp 0x0000774654FD71BD
0000774654fd8b8d  call 0x0000774654E0C260
0000774654fd8b92  jmp 0x0000774654FD71C7
0000774654fd8b97  sub rsp, 0x08
0000774654fd8b9b  push rax
0000774654fd8b9c  push rcx
0000774654fd8b9d  push rdx
0000774654fd8b9e  push rdi
0000774654fd8b9f  push rsi
0000774654fd8ba0  push r8
0000774654fd8ba2  push r9
0000774654fd8ba4  push r10
0000774654fd8ba6  push r11
0000774654fd8ba8  sub rsp, 0xF0
0000774654fd8baf  vmovaps [rsp], xmm0
0000774654fd8bb4  vmovaps [rsp+0x10], xmm1
0000774654fd8bba  vmovaps [rsp+0x20], xmm2
0000774654fd8bc0  vmovaps [rsp+0x30], xmm3
0000774654fd8bc6  vmovaps [rsp+0x40], xmm5
0000774654fd8bcc  vmovaps [rsp+0x50], xmm6
0000774654fd8bd2  vmovaps [rsp+0x60], xmm7
0000774654fd8bd8  vmovaps [rsp+0x70], xmm8
0000774654fd8bde  vmovaps [rsp+0x80], xmm9
0000774654fd8be7  vmovaps [rsp+0x90], xmm10
0000774654fd8bf0  vmovaps [rsp+0xA0], xmm11
0000774654fd8bf9  vmovaps [rsp+0xB0], xmm12
0000774654fd8c02  vmovaps [rsp+0xC0], xmm13
0000774654fd8c0b  vmovaps [rsp+0xD0], xmm14
0000774654fd8c14  vmovaps [rsp+0xE0], xmm15
0000774654fd8c1d  sub rsp, 0x40
0000774654fd8c21  lea rdi, [rsp]
0000774654fd8c25  lea rsi, [rsp+0x10]
0000774654fd8c2a  lea rdx, [rsp+0x20]
0000774654fd8c2f  lea rcx, [rsp+0x30]
0000774654fd8c34  mov r8d, 0x00
0000774654fd8c3a  lea r9, [r15+0x3A8]
0000774654fd8c41  movaps [rdi], xmm4
0000774654fd8c44  movaps [rsi], xmm12
0000774654fd8c48  movaps [rdx], xmm9
0000774654fd8c4c  movaps [rcx], xmm6
0000774654fd8c4f  mov rax, 0x564E5D1DDA50
0000774654fd8c59  call rax
0000774654fd8c5b  movaps xmm4, [rsp]
0000774654fd8c5f  add rsp, 0x40
0000774654fd8c63  vmovaps xmm0, [rsp]
0000774654fd8c68  vmovaps xmm1, [rsp+0x10]
0000774654fd8c6e  vmovaps xmm2, [rsp+0x20]
0000774654fd8c74  vmovaps xmm3, [rsp+0x30]
0000774654fd8c7a  vmovaps xmm5, [rsp+0x40]
0000774654fd8c80  vmovaps xmm6, [rsp+0x50]
0000774654fd8c86  vmovaps xmm7, [rsp+0x60]
0000774654fd8c8c  vmovaps xmm8, [rsp+0x70]
0000774654fd8c92  vmovaps xmm9, [rsp+0x80]
0000774654fd8c9b  vmovaps xmm10, [rsp+0x90]
0000774654fd8ca4  vmovaps xmm11, [rsp+0xA0]
0000774654fd8cad  vmovaps xmm12, [rsp+0xB0]
0000774654fd8cb6  vmovaps xmm13, [rsp+0xC0]
0000774654fd8cbf  vmovaps xmm14, [rsp+0xD0]
0000774654fd8cc8  vmovaps xmm15, [rsp+0xE0]
0000774654fd8cd1  add rsp, 0xF0
0000774654fd8cd8  pop r11
0000774654fd8cda  pop r10
0000774654fd8cdc  pop r9
0000774654fd8cde  pop r8
0000774654fd8ce0  pop rsi
0000774654fd8ce1  pop rdi
0000774654fd8ce2  pop rdx
0000774654fd8ce3  pop rcx
0000774654fd8ce4  pop rax
0000774654fd8ce5  add rsp, 0x08
0000774654fd8ce9  jmp 0x0000774654FD71FF
0000774654fd8cee  sub rsp, 0x08
0000774654fd8cf2  push rax
0000774654fd8cf3  push rcx
0000774654fd8cf4  push rdx
0000774654fd8cf5  push rdi
0000774654fd8cf6  push rsi
0000774654fd8cf7  push r8
0000774654fd8cf9  push r9
0000774654fd8cfb  push r10
0000774654fd8cfd  push r11
0000774654fd8cff  sub rsp, 0xF0
0000774654fd8d06  vmovaps [rsp], xmm0
0000774654fd8d0b  vmovaps [rsp+0x10], xmm1
0000774654fd8d11  vmovaps [rsp+0x20], xmm2
0000774654fd8d17  vmovaps [rsp+0x30], xmm3
0000774654fd8d1d  vmovaps [rsp+0x40], xmm4
0000774654fd8d23  vmovaps [rsp+0x50], xmm5
0000774654fd8d29  vmovaps [rsp+0x60], xmm6
0000774654fd8d2f  vmovaps [rsp+0x70], xmm7
0000774654fd8d35  vmovaps [rsp+0x80], xmm8
0000774654fd8d3e  vmovaps [rsp+0x90], xmm10
0000774654fd8d47  vmovaps [rsp+0xA0], xmm11
0000774654fd8d50  vmovaps [rsp+0xB0], xmm12
0000774654fd8d59  vmovaps [rsp+0xC0], xmm13
0000774654fd8d62  vmovaps [rsp+0xD0], xmm14
0000774654fd8d6b  vmovaps [rsp+0xE0], xmm15
0000774654fd8d74  sub rsp, 0x40
0000774654fd8d78  lea rdi, [rsp]
0000774654fd8d7c  lea rsi, [rsp+0x10]
0000774654fd8d81  lea rdx, [rsp+0x20]
0000774654fd8d86  lea rcx, [rsp+0x30]
0000774654fd8d8b  mov r8d, 0x00
0000774654fd8d91  lea r9, [r15+0x3A8]
0000774654fd8d98  movaps [rdi], xmm9
0000774654fd8d9c  movaps [rsi], xmm10
0000774654fd8da0  movaps [rdx], xmm1
0000774654fd8da3  movaps [rcx], xmm12
0000774654fd8da7  mov rax, 0x564E5D1DDA50
0000774654fd8db1  call rax
0000774654fd8db3  movaps xmm9, [rsp]
0000774654fd8db8  add rsp, 0x40
0000774654fd8dbc  vmovaps xmm0, [rsp]
0000774654fd8dc1  vmovaps xmm1, [rsp+0x10]
0000774654fd8dc7  vmovaps xmm2, [rsp+0x20]
0000774654fd8dcd  vmovaps xmm3, [rsp+0x30]
0000774654fd8dd3  vmovaps xmm4, [rsp+0x40]
0000774654fd8dd9  vmovaps xmm5, [rsp+0x50]
0000774654fd8ddf  vmovaps xmm6, [rsp+0x60]
0000774654fd8de5  vmovaps xmm7, [rsp+0x70]
0000774654fd8deb  vmovaps xmm8, [rsp+0x80]
0000774654fd8df4  vmovaps xmm10, [rsp+0x90]
0000774654fd8dfd  vmovaps xmm11, [rsp+0xA0]
0000774654fd8e06  vmovaps xmm12, [rsp+0xB0]
0000774654fd8e0f  vmovaps xmm13, [rsp+0xC0]
0000774654fd8e18  vmovaps xmm14, [rsp+0xD0]
0000774654fd8e21  vmovaps xmm15, [rsp+0xE0]
0000774654fd8e2a  add rsp, 0xF0
0000774654fd8e31  pop r11
0000774654fd8e33  pop r10
0000774654fd8e35  pop r9
0000774654fd8e37  pop r8
0000774654fd8e39  pop rsi
0000774654fd8e3a  pop rdi
0000774654fd8e3b  pop rdx
0000774654fd8e3c  pop rcx
0000774654fd8e3d  pop rax
0000774654fd8e3e  add rsp, 0x08
0000774654fd8e42  jmp 0x0000774654FD7228
0000774654fd8e47  sub rsp, 0x08
0000774654fd8e4b  push rax
0000774654fd8e4c  push rcx
0000774654fd8e4d  push rdx
0000774654fd8e4e  push rdi
0000774654fd8e4f  push rsi
0000774654fd8e50  push r8
0000774654fd8e52  push r9
0000774654fd8e54  push r10
0000774654fd8e56  push r11
0000774654fd8e58  sub rsp, 0xF0
0000774654fd8e5f  vmovaps [rsp], xmm0
0000774654fd8e64  vmovaps [rsp+0x10], xmm1
0000774654fd8e6a  vmovaps [rsp+0x20], xmm2
0000774654fd8e70  vmovaps [rsp+0x30], xmm3
0000774654fd8e76  vmovaps [rsp+0x40], xmm4
0000774654fd8e7c  vmovaps [rsp+0x50], xmm5
0000774654fd8e82  vmovaps [rsp+0x60], xmm6
0000774654fd8e88  vmovaps [rsp+0x70], xmm7
0000774654fd8e8e  vmovaps [rsp+0x80], xmm8
0000774654fd8e97  vmovaps [rsp+0x90], xmm9
0000774654fd8ea0  vmovaps [rsp+0xA0], xmm11
0000774654fd8ea9  vmovaps [rsp+0xB0], xmm12
0000774654fd8eb2  vmovaps [rsp+0xC0], xmm13
0000774654fd8ebb  vmovaps [rsp+0xD0], xmm14
0000774654fd8ec4  vmovaps [rsp+0xE0], xmm15
0000774654fd8ecd  sub rsp, 0x40
0000774654fd8ed1  lea rdi, [rsp]
0000774654fd8ed5  lea rsi, [rsp+0x10]
0000774654fd8eda  lea rdx, [rsp+0x20]
0000774654fd8edf  lea rcx, [rsp+0x30]
0000774654fd8ee4  mov r8d, 0x00
0000774654fd8eea  lea r9, [r15+0x3A8]
0000774654fd8ef1  movaps [rdi], xmm10
0000774654fd8ef5  movaps [rsi], xmm5
0000774654fd8ef8  movaps [rdx], xmm12
0000774654fd8efc  movaps [rcx], xmm1
0000774654fd8eff  mov rax, 0x564E5D1DDA50
0000774654fd8f09  call rax
0000774654fd8f0b  movaps xmm10, [rsp]
0000774654fd8f10  add rsp, 0x40
0000774654fd8f14  vmovaps xmm0, [rsp]
0000774654fd8f19  vmovaps xmm1, [rsp+0x10]
0000774654fd8f1f  vmovaps xmm2, [rsp+0x20]
0000774654fd8f25  vmovaps xmm3, [rsp+0x30]
0000774654fd8f2b  vmovaps xmm4, [rsp+0x40]
0000774654fd8f31  vmovaps xmm5, [rsp+0x50]
0000774654fd8f37  vmovaps xmm6, [rsp+0x60]
0000774654fd8f3d  vmovaps xmm7, [rsp+0x70]
0000774654fd8f43  vmovaps xmm8, [rsp+0x80]
0000774654fd8f4c  vmovaps xmm9, [rsp+0x90]
0000774654fd8f55  vmovaps xmm11, [rsp+0xA0]
0000774654fd8f5e  vmovaps xmm12, [rsp+0xB0]
0000774654fd8f67  vmovaps xmm13, [rsp+0xC0]
0000774654fd8f70  vmovaps xmm14, [rsp+0xD0]
0000774654fd8f79  vmovaps xmm15, [rsp+0xE0]
0000774654fd8f82  add rsp, 0xF0
0000774654fd8f89  pop r11
0000774654fd8f8b  pop r10
0000774654fd8f8d  pop r9
0000774654fd8f8f  pop r8
0000774654fd8f91  pop rsi
0000774654fd8f92  pop rdi
0000774654fd8f93  pop rdx
0000774654fd8f94  pop rcx
0000774654fd8f95  pop rax
0000774654fd8f96  add rsp, 0x08
0000774654fd8f9a  jmp 0x0000774654FD7257
0000774654fd8f9f  sub rsp, 0x08
0000774654fd8fa3  push rax
0000774654fd8fa4  push rcx
0000774654fd8fa5  push rdx
0000774654fd8fa6  push rdi
0000774654fd8fa7  push rsi
0000774654fd8fa8  push r8
0000774654fd8faa  push r9
0000774654fd8fac  push r10
0000774654fd8fae  push r11
0000774654fd8fb0  sub rsp, 0xF0
0000774654fd8fb7  vmovaps [rsp], xmm0
0000774654fd8fbc  vmovaps [rsp+0x10], xmm1
0000774654fd8fc2  vmovaps [rsp+0x20], xmm2
0000774654fd8fc8  vmovaps [rsp+0x30], xmm3
0000774654fd8fce  vmovaps [rsp+0x40], xmm4
0000774654fd8fd4  vmovaps [rsp+0x50], xmm5
0000774654fd8fda  vmovaps [rsp+0x60], xmm7
0000774654fd8fe0  vmovaps [rsp+0x70], xmm8
0000774654fd8fe6  vmovaps [rsp+0x80], xmm9
0000774654fd8fef  vmovaps [rsp+0x90], xmm10
0000774654fd8ff8  vmovaps [rsp+0xA0], xmm11
0000774654fd9001  vmovaps [rsp+0xB0], xmm12
0000774654fd900a  vmovaps [rsp+0xC0], xmm13
0000774654fd9013  vmovaps [rsp+0xD0], xmm14
0000774654fd901c  vmovaps [rsp+0xE0], xmm15
0000774654fd9025  sub rsp, 0x40
0000774654fd9029  lea rdi, [rsp]
0000774654fd902d  lea rsi, [rsp+0x10]
0000774654fd9032  lea rdx, [rsp+0x20]
0000774654fd9037  lea rcx, [rsp+0x30]
0000774654fd903c  mov r8d, 0x00
0000774654fd9042  lea r9, [r15+0x3A8]
0000774654fd9049  movaps [rdi], xmm6
0000774654fd904c  movaps [rsi], xmm8
0000774654fd9050  movaps [rdx], xmm12
0000774654fd9054  movaps [rcx], xmm1
0000774654fd9057  mov rax, 0x564E5D1DDA50
0000774654fd9061  call rax
0000774654fd9063  movaps xmm6, [rsp]
0000774654fd9067  add rsp, 0x40
0000774654fd906b  vmovaps xmm0, [rsp]
0000774654fd9070  vmovaps xmm1, [rsp+0x10]
0000774654fd9076  vmovaps xmm2, [rsp+0x20]
0000774654fd907c  vmovaps xmm3, [rsp+0x30]
0000774654fd9082  vmovaps xmm4, [rsp+0x40]
0000774654fd9088  vmovaps xmm5, [rsp+0x50]
0000774654fd908e  vmovaps xmm7, [rsp+0x60]
0000774654fd9094  vmovaps xmm8, [rsp+0x70]
0000774654fd909a  vmovaps xmm9, [rsp+0x80]
0000774654fd90a3  vmovaps xmm10, [rsp+0x90]
0000774654fd90ac  vmovaps xmm11, [rsp+0xA0]
0000774654fd90b5  vmovaps xmm12, [rsp+0xB0]
0000774654fd90be  vmovaps xmm13, [rsp+0xC0]
0000774654fd90c7  vmovaps xmm14, [rsp+0xD0]
0000774654fd90d0  vmovaps xmm15, [rsp+0xE0]
0000774654fd90d9  add rsp, 0xF0
0000774654fd90e0  pop r11
0000774654fd90e2  pop r10
0000774654fd90e4  pop r9
0000774654fd90e6  pop r8
0000774654fd90e8  pop rsi
0000774654fd90e9  pop rdi
0000774654fd90ea  pop rdx
0000774654fd90eb  pop rcx
0000774654fd90ec  pop rax
0000774654fd90ed  add rsp, 0x08
0000774654fd90f1  jmp 0x0000774654FD7285
0000774654fd90f6  call 0x0000774654DFF430
0000774654fd90fb  jmp 0x0000774654FD728F
0000774654fd9100  call 0x0000774654E0AFE0
0000774654fd9105  jmp 0x0000774654FD7299
0000774654fd910a  sub rsp, 0x08
0000774654fd910e  push rax
0000774654fd910f  push rcx
0000774654fd9110  push rdx
0000774654fd9111  push rdi
0000774654fd9112  push rsi
0000774654fd9113  push r8
0000774654fd9115  push r9
0000774654fd9117  push r10
0000774654fd9119  push r11
0000774654fd911b  sub rsp, 0xF0
0000774654fd9122  vmovaps [rsp], xmm0
0000774654fd9127  vmovaps [rsp+0x10], xmm1
0000774654fd912d  vmovaps [rsp+0x20], xmm2
0000774654fd9133  vmovaps [rsp+0x30], xmm3
0000774654fd9139  vmovaps [rsp+0x40], xmm4
0000774654fd913f  vmovaps [rsp+0x50], xmm5
0000774654fd9145  vmovaps [rsp+0x60], xmm6
0000774654fd914b  vmovaps [rsp+0x70], xmm7
0000774654fd9151  vmovaps [rsp+0x80], xmm9
0000774654fd915a  vmovaps [rsp+0x90], xmm10
0000774654fd9163  vmovaps [rsp+0xA0], xmm11
0000774654fd916c  vmovaps [rsp+0xB0], xmm12
0000774654fd9175  vmovaps [rsp+0xC0], xmm13
0000774654fd917e  vmovaps [rsp+0xD0], xmm14
0000774654fd9187  vmovaps [rsp+0xE0], xmm15
0000774654fd9190  sub rsp, 0x40
0000774654fd9194  lea rdi, [rsp]
0000774654fd9198  lea rsi, [rsp+0x10]
0000774654fd919d  lea rdx, [rsp+0x20]
0000774654fd91a2  lea rcx, [rsp+0x30]
0000774654fd91a7  mov r8d, 0x00
0000774654fd91ad  lea r9, [r15+0x3A8]
0000774654fd91b4  movaps [rdi], xmm8
0000774654fd91b8  movaps [rsi], xmm4
0000774654fd91bb  movaps [rdx], xmm13
0000774654fd91bf  movaps [rcx], xmm11
0000774654fd91c3  mov rax, 0x564E5D1DDA50
0000774654fd91cd  call rax
0000774654fd91cf  movaps xmm8, [rsp]
0000774654fd91d4  add rsp, 0x40
0000774654fd91d8  vmovaps xmm0, [rsp]
0000774654fd91dd  vmovaps xmm1, [rsp+0x10]
0000774654fd91e3  vmovaps xmm2, [rsp+0x20]
0000774654fd91e9  vmovaps xmm3, [rsp+0x30]
0000774654fd91ef  vmovaps xmm4, [rsp+0x40]
0000774654fd91f5  vmovaps xmm5, [rsp+0x50]
0000774654fd91fb  vmovaps xmm6, [rsp+0x60]
0000774654fd9201  vmovaps xmm7, [rsp+0x70]
0000774654fd9207  vmovaps xmm9, [rsp+0x80]
0000774654fd9210  vmovaps xmm10, [rsp+0x90]
0000774654fd9219  vmovaps xmm11, [rsp+0xA0]
0000774654fd9222  vmovaps xmm12, [rsp+0xB0]
0000774654fd922b  vmovaps xmm13, [rsp+0xC0]
0000774654fd9234  vmovaps xmm14, [rsp+0xD0]
0000774654fd923d  vmovaps xmm15, [rsp+0xE0]
0000774654fd9246  add rsp, 0xF0
0000774654fd924d  pop r11
0000774654fd924f  pop r10
0000774654fd9251  pop r9
0000774654fd9253  pop r8
0000774654fd9255  pop rsi
0000774654fd9256  pop rdi
0000774654fd9257  pop rdx
0000774654fd9258  pop rcx
0000774654fd9259  pop rax
0000774654fd925a  add rsp, 0x08
0000774654fd925e  jmp 0x0000774654FD72CF
0000774654fd9263  sub rsp, 0x08
0000774654fd9267  push rax
0000774654fd9268  push rcx
0000774654fd9269  push rdx
0000774654fd926a  push rdi
0000774654fd926b  push rsi
0000774654fd926c  push r8
0000774654fd926e  push r9
0000774654fd9270  push r10
0000774654fd9272  push r11
0000774654fd9274  sub rsp, 0xF0
0000774654fd927b  vmovaps [rsp], xmm0
0000774654fd9280  vmovaps [rsp+0x10], xmm1
0000774654fd9286  vmovaps [rsp+0x20], xmm2
0000774654fd928c  vmovaps [rsp+0x30], xmm3
0000774654fd9292  vmovaps [rsp+0x40], xmm4
0000774654fd9298  vmovaps [rsp+0x50], xmm5
0000774654fd929e  vmovaps [rsp+0x60], xmm6
0000774654fd92a4  vmovaps [rsp+0x70], xmm7
0000774654fd92aa  vmovaps [rsp+0x80], xmm8
0000774654fd92b3  vmovaps [rsp+0x90], xmm9
0000774654fd92bc  vmovaps [rsp+0xA0], xmm10
0000774654fd92c5  vmovaps [rsp+0xB0], xmm12
0000774654fd92ce  vmovaps [rsp+0xC0], xmm13
0000774654fd92d7  vmovaps [rsp+0xD0], xmm14
0000774654fd92e0  vmovaps [rsp+0xE0], xmm15
0000774654fd92e9  sub rsp, 0x40
0000774654fd92ed  lea rdi, [rsp]
0000774654fd92f1  lea rsi, [rsp+0x10]
0000774654fd92f6  lea rdx, [rsp+0x20]
0000774654fd92fb  lea rcx, [rsp+0x30]
0000774654fd9300  mov r8d, 0x00
0000774654fd9306  lea r9, [r15+0x3A8]
0000774654fd930d  movaps [rdi], xmm11
0000774654fd9311  movaps [rsi], xmm9
0000774654fd9315  movaps [rdx], xmm1
0000774654fd9318  movaps [rcx], xmm13
0000774654fd931c  mov rax, 0x564E5D1DDA50
0000774654fd9326  call rax
0000774654fd9328  movaps xmm11, [rsp]
0000774654fd932d  add rsp, 0x40
0000774654fd9331  vmovaps xmm0, [rsp]
0000774654fd9336  vmovaps xmm1, [rsp+0x10]
0000774654fd933c  vmovaps xmm2, [rsp+0x20]
0000774654fd9342  vmovaps xmm3, [rsp+0x30]
0000774654fd9348  vmovaps xmm4, [rsp+0x40]
0000774654fd934e  vmovaps xmm5, [rsp+0x50]
0000774654fd9354  vmovaps xmm6, [rsp+0x60]
0000774654fd935a  vmovaps xmm7, [rsp+0x70]
0000774654fd9360  vmovaps xmm8, [rsp+0x80]
0000774654fd9369  vmovaps xmm9, [rsp+0x90]
0000774654fd9372  vmovaps xmm10, [rsp+0xA0]
0000774654fd937b  vmovaps xmm12, [rsp+0xB0]
0000774654fd9384  vmovaps xmm13, [rsp+0xC0]
0000774654fd938d  vmovaps xmm14, [rsp+0xD0]
0000774654fd9396  vmovaps xmm15, [rsp+0xE0]
0000774654fd939f  add rsp, 0xF0
0000774654fd93a6  pop r11
0000774654fd93a8  pop r10
0000774654fd93aa  pop r9
0000774654fd93ac  pop r8
0000774654fd93ae  pop rsi
0000774654fd93af  pop rdi
0000774654fd93b0  pop rdx
0000774654fd93b1  pop rcx
0000774654fd93b2  pop rax
0000774654fd93b3  add rsp, 0x08
0000774654fd93b7  jmp 0x0000774654FD72F5
0000774654fd93bc  sub rsp, 0x08
0000774654fd93c0  push rax
0000774654fd93c1  push rcx
0000774654fd93c2  push rdx
0000774654fd93c3  push rdi
0000774654fd93c4  push rsi
0000774654fd93c5  push r8
0000774654fd93c7  push r9
0000774654fd93c9  push r10
0000774654fd93cb  push r11
0000774654fd93cd  sub rsp, 0xF0
0000774654fd93d4  vmovaps [rsp], xmm0
0000774654fd93d9  vmovaps [rsp+0x10], xmm1
0000774654fd93df  vmovaps [rsp+0x20], xmm2
0000774654fd93e5  vmovaps [rsp+0x30], xmm3
0000774654fd93eb  vmovaps [rsp+0x40], xmm4
0000774654fd93f1  vmovaps [rsp+0x50], xmm5
0000774654fd93f7  vmovaps [rsp+0x60], xmm6
0000774654fd93fd  vmovaps [rsp+0x70], xmm7
0000774654fd9403  vmovaps [rsp+0x80], xmm8
0000774654fd940c  vmovaps [rsp+0x90], xmm9
0000774654fd9415  vmovaps [rsp+0xA0], xmm10
0000774654fd941e  vmovaps [rsp+0xB0], xmm11
0000774654fd9427  vmovaps [rsp+0xC0], xmm12
0000774654fd9430  vmovaps [rsp+0xD0], xmm14
0000774654fd9439  vmovaps [rsp+0xE0], xmm15
0000774654fd9442  sub rsp, 0x40
0000774654fd9446  lea rdi, [rsp]
0000774654fd944a  lea rsi, [rsp+0x10]
0000774654fd944f  lea rdx, [rsp+0x20]
0000774654fd9454  lea rcx, [rsp+0x30]
0000774654fd9459  mov r8d, 0x00
0000774654fd945f  lea r9, [r15+0x3A8]
0000774654fd9466  movaps [rdi], xmm13
0000774654fd946a  movaps [rsi], xmm10
0000774654fd946e  movaps [rdx], xmm7
0000774654fd9471  movaps [rcx], xmm1
0000774654fd9474  mov rax, 0x564E5D1DDA50
0000774654fd947e  call rax
0000774654fd9480  movaps xmm13, [rsp]
0000774654fd9485  add rsp, 0x40
0000774654fd9489  vmovaps xmm0, [rsp]
0000774654fd948e  vmovaps xmm1, [rsp+0x10]
0000774654fd9494  vmovaps xmm2, [rsp+0x20]
0000774654fd949a  vmovaps xmm3, [rsp+0x30]
0000774654fd94a0  vmovaps xmm4, [rsp+0x40]
0000774654fd94a6  vmovaps xmm5, [rsp+0x50]
0000774654fd94ac  vmovaps xmm6, [rsp+0x60]
0000774654fd94b2  vmovaps xmm7, [rsp+0x70]
0000774654fd94b8  vmovaps xmm8, [rsp+0x80]
0000774654fd94c1  vmovaps xmm9, [rsp+0x90]
0000774654fd94ca  vmovaps xmm10, [rsp+0xA0]
0000774654fd94d3  vmovaps xmm11, [rsp+0xB0]
0000774654fd94dc  vmovaps xmm12, [rsp+0xC0]
0000774654fd94e5  vmovaps xmm14, [rsp+0xD0]
0000774654fd94ee  vmovaps xmm15, [rsp+0xE0]
0000774654fd94f7  add rsp, 0xF0
0000774654fd94fe  pop r11
0000774654fd9500  pop r10
0000774654fd9502  pop r9
0000774654fd9504  pop r8
0000774654fd9506  pop rsi
0000774654fd9507  pop rdi
0000774654fd9508  pop rdx
0000774654fd9509  pop rcx
0000774654fd950a  pop rax
0000774654fd950b  add rsp, 0x08
0000774654fd950f  jmp 0x0000774654FD731B
0000774654fd9514  sub rsp, 0x08
0000774654fd9518  push rax
0000774654fd9519  push rcx
0000774654fd951a  push rdx
0000774654fd951b  push rdi
0000774654fd951c  push rsi
0000774654fd951d  push r8
0000774654fd951f  push r9
0000774654fd9521  push r10
0000774654fd9523  push r11
0000774654fd9525  sub rsp, 0xF0
0000774654fd952c  vmovaps [rsp], xmm0
0000774654fd9531  vmovaps [rsp+0x10], xmm1
0000774654fd9537  vmovaps [rsp+0x20], xmm2
0000774654fd953d  vmovaps [rsp+0x30], xmm3
0000774654fd9543  vmovaps [rsp+0x40], xmm4
0000774654fd9549  vmovaps [rsp+0x50], xmm5
0000774654fd954f  vmovaps [rsp+0x60], xmm6
0000774654fd9555  vmovaps [rsp+0x70], xmm7
0000774654fd955b  vmovaps [rsp+0x80], xmm8
0000774654fd9564  vmovaps [rsp+0x90], xmm9
0000774654fd956d  vmovaps [rsp+0xA0], xmm11
0000774654fd9576  vmovaps [rsp+0xB0], xmm12
0000774654fd957f  vmovaps [rsp+0xC0], xmm13
0000774654fd9588  vmovaps [rsp+0xD0], xmm14
0000774654fd9591  vmovaps [rsp+0xE0], xmm15
0000774654fd959a  sub rsp, 0x40
0000774654fd959e  lea rdi, [rsp]
0000774654fd95a2  lea rsi, [rsp+0x10]
0000774654fd95a7  lea rdx, [rsp+0x20]
0000774654fd95ac  lea rcx, [rsp+0x30]
0000774654fd95b1  mov r8d, 0x00
0000774654fd95b7  lea r9, [r15+0x3A8]
0000774654fd95be  movaps [rdi], xmm10
0000774654fd95c2  movaps [rsi], xmm6
0000774654fd95c5  movaps [rdx], xmm15
0000774654fd95c9  movaps [rcx], xmm1
0000774654fd95cc  mov rax, 0x564E5D1DDA50
0000774654fd95d6  call rax
0000774654fd95d8  movaps xmm10, [rsp]
0000774654fd95dd  add rsp, 0x40
0000774654fd95e1  vmovaps xmm0, [rsp]
0000774654fd95e6  vmovaps xmm1, [rsp+0x10]
0000774654fd95ec  vmovaps xmm2, [rsp+0x20]
0000774654fd95f2  vmovaps xmm3, [rsp+0x30]
0000774654fd95f8  vmovaps xmm4, [rsp+0x40]
0000774654fd95fe  vmovaps xmm5, [rsp+0x50]
0000774654fd9604  vmovaps xmm6, [rsp+0x60]
0000774654fd960a  vmovaps xmm7, [rsp+0x70]
0000774654fd9610  vmovaps xmm8, [rsp+0x80]
0000774654fd9619  vmovaps xmm9, [rsp+0x90]
0000774654fd9622  vmovaps xmm11, [rsp+0xA0]
0000774654fd962b  vmovaps xmm12, [rsp+0xB0]
0000774654fd9634  vmovaps xmm13, [rsp+0xC0]
0000774654fd963d  vmovaps xmm14, [rsp+0xD0]
0000774654fd9646  vmovaps xmm15, [rsp+0xE0]
0000774654fd964f  add rsp, 0xF0
0000774654fd9656  pop r11
0000774654fd9658  pop r10
0000774654fd965a  pop r9
0000774654fd965c  pop r8
0000774654fd965e  pop rsi
0000774654fd965f  pop rdi
0000774654fd9660  pop rdx
0000774654fd9661  pop rcx
0000774654fd9662  pop rax
0000774654fd9663  add rsp, 0x08
0000774654fd9667  jmp 0x0000774654FD7341
0000774654fd966c  call 0x0000774654DFF430
0000774654fd9671  jmp 0x0000774654FD734B
0000774654fd9676  call 0x0000774654E0E760
0000774654fd967b  jmp 0x0000774654FD7355
0000774654fd9680  sub rsp, 0x08
0000774654fd9684  push rax
0000774654fd9685  push rcx
0000774654fd9686  push rdx
0000774654fd9687  push rdi
0000774654fd9688  push rsi
0000774654fd9689  push r8
0000774654fd968b  push r9
0000774654fd968d  push r10
0000774654fd968f  push r11
0000774654fd9691  sub rsp, 0xF0
0000774654fd9698  vmovaps [rsp], xmm0
0000774654fd969d  vmovaps [rsp+0x10], xmm1
0000774654fd96a3  vmovaps [rsp+0x20], xmm2
0000774654fd96a9  vmovaps [rsp+0x30], xmm3
0000774654fd96af  vmovaps [rsp+0x40], xmm4
0000774654fd96b5  vmovaps [rsp+0x50], xmm5
0000774654fd96bb  vmovaps [rsp+0x60], xmm6
0000774654fd96c1  vmovaps [rsp+0x70], xmm8
0000774654fd96c7  vmovaps [rsp+0x80], xmm9
0000774654fd96d0  vmovaps [rsp+0x90], xmm10
0000774654fd96d9  vmovaps [rsp+0xA0], xmm11
0000774654fd96e2  vmovaps [rsp+0xB0], xmm12
0000774654fd96eb  vmovaps [rsp+0xC0], xmm13
0000774654fd96f4  vmovaps [rsp+0xD0], xmm14
0000774654fd96fd  vmovaps [rsp+0xE0], xmm15
0000774654fd9706  sub rsp, 0x40
0000774654fd970a  lea rdi, [rsp]
0000774654fd970e  lea rsi, [rsp+0x10]
0000774654fd9713  lea rdx, [rsp+0x20]
0000774654fd9718  lea rcx, [rsp+0x30]
0000774654fd971d  mov r8d, 0x00
0000774654fd9723  lea r9, [r15+0x3A8]
0000774654fd972a  movaps [rdi], xmm7
0000774654fd972d  movaps [rsi], xmm8
0000774654fd9731  movaps [rdx], xmm3
0000774654fd9734  movaps [rcx], xmm9
0000774654fd9738  mov rax, 0x564E5D1DDA50
0000774654fd9742  call rax
0000774654fd9744  movaps xmm7, [rsp]
0000774654fd9748  add rsp, 0x40
0000774654fd974c  vmovaps xmm0, [rsp]
0000774654fd9751  vmovaps xmm1, [rsp+0x10]
0000774654fd9757  vmovaps xmm2, [rsp+0x20]
0000774654fd975d  vmovaps xmm3, [rsp+0x30]
0000774654fd9763  vmovaps xmm4, [rsp+0x40]
0000774654fd9769  vmovaps xmm5, [rsp+0x50]
0000774654fd976f  vmovaps xmm6, [rsp+0x60]
0000774654fd9775  vmovaps xmm8, [rsp+0x70]
0000774654fd977b  vmovaps xmm9, [rsp+0x80]
0000774654fd9784  vmovaps xmm10, [rsp+0x90]
0000774654fd978d  vmovaps xmm11, [rsp+0xA0]
0000774654fd9796  vmovaps xmm12, [rsp+0xB0]
0000774654fd979f  vmovaps xmm13, [rsp+0xC0]
0000774654fd97a8  vmovaps xmm14, [rsp+0xD0]
0000774654fd97b1  vmovaps xmm15, [rsp+0xE0]
0000774654fd97ba  add rsp, 0xF0
0000774654fd97c1  pop r11
0000774654fd97c3  pop r10
0000774654fd97c5  pop r9
0000774654fd97c7  pop r8
0000774654fd97c9  pop rsi
0000774654fd97ca  pop rdi
0000774654fd97cb  pop rdx
0000774654fd97cc  pop rcx
0000774654fd97cd  pop rax
0000774654fd97ce  add rsp, 0x08
0000774654fd97d2  jmp 0x0000774654FD737D
0000774654fd97d7  sub rsp, 0x08
0000774654fd97db  push rax
0000774654fd97dc  push rcx
0000774654fd97dd  push rdx
0000774654fd97de  push rdi
0000774654fd97df  push rsi
0000774654fd97e0  push r8
0000774654fd97e2  push r9
0000774654fd97e4  push r10
0000774654fd97e6  push r11
0000774654fd97e8  sub rsp, 0xF0
0000774654fd97ef  vmovaps [rsp], xmm0
0000774654fd97f4  vmovaps [rsp+0x10], xmm1
0000774654fd97fa  vmovaps [rsp+0x20], xmm2
0000774654fd9800  vmovaps [rsp+0x30], xmm3
0000774654fd9806  vmovaps [rsp+0x40], xmm4
0000774654fd980c  vmovaps [rsp+0x50], xmm5
0000774654fd9812  vmovaps [rsp+0x60], xmm6
0000774654fd9818  vmovaps [rsp+0x70], xmm7
0000774654fd981e  vmovaps [rsp+0x80], xmm9
0000774654fd9827  vmovaps [rsp+0x90], xmm10
0000774654fd9830  vmovaps [rsp+0xA0], xmm11
0000774654fd9839  vmovaps [rsp+0xB0], xmm12
0000774654fd9842  vmovaps [rsp+0xC0], xmm13
0000774654fd984b  vmovaps [rsp+0xD0], xmm14
0000774654fd9854  vmovaps [rsp+0xE0], xmm15
0000774654fd985d  sub rsp, 0x40
0000774654fd9861  lea rdi, [rsp]
0000774654fd9865  lea rsi, [rsp+0x10]
0000774654fd986a  lea rdx, [rsp+0x20]
0000774654fd986f  lea rcx, [rsp+0x30]
0000774654fd9874  mov r8d, 0x00
0000774654fd987a  lea r9, [r15+0x3A8]
0000774654fd9881  movaps [rdi], xmm8
0000774654fd9885  movaps [rsi], xmm11
0000774654fd9889  movaps [rdx], xmm14
0000774654fd988d  movaps [rcx], xmm9
0000774654fd9891  mov rax, 0x564E5D1DDA50
0000774654fd989b  call rax
0000774654fd989d  movaps xmm8, [rsp]
0000774654fd98a2  add rsp, 0x40
0000774654fd98a6  vmovaps xmm0, [rsp]
0000774654fd98ab  vmovaps xmm1, [rsp+0x10]
0000774654fd98b1  vmovaps xmm2, [rsp+0x20]
0000774654fd98b7  vmovaps xmm3, [rsp+0x30]
0000774654fd98bd  vmovaps xmm4, [rsp+0x40]
0000774654fd98c3  vmovaps xmm5, [rsp+0x50]
0000774654fd98c9  vmovaps xmm6, [rsp+0x60]
0000774654fd98cf  vmovaps xmm7, [rsp+0x70]
0000774654fd98d5  vmovaps xmm9, [rsp+0x80]
0000774654fd98de  vmovaps xmm10, [rsp+0x90]
0000774654fd98e7  vmovaps xmm11, [rsp+0xA0]
0000774654fd98f0  vmovaps xmm12, [rsp+0xB0]
0000774654fd98f9  vmovaps xmm13, [rsp+0xC0]
0000774654fd9902  vmovaps xmm14, [rsp+0xD0]
0000774654fd990b  vmovaps xmm15, [rsp+0xE0]
0000774654fd9914  add rsp, 0xF0
0000774654fd991b  pop r11
0000774654fd991d  pop r10
0000774654fd991f  pop r9
0000774654fd9921  pop r8
0000774654fd9923  pop rsi
0000774654fd9924  pop rdi
0000774654fd9925  pop rdx
0000774654fd9926  pop rcx
0000774654fd9927  pop rax
0000774654fd9928  add rsp, 0x08
0000774654fd992c  jmp 0x0000774654FD73A6
0000774654fd9931  sub rsp, 0x08
0000774654fd9935  push rax
0000774654fd9936  push rcx
0000774654fd9937  push rdx
0000774654fd9938  push rdi
0000774654fd9939  push rsi
0000774654fd993a  push r8
0000774654fd993c  push r9
0000774654fd993e  push r10
0000774654fd9940  push r11
0000774654fd9942  sub rsp, 0xF0
0000774654fd9949  vmovaps [rsp], xmm0
0000774654fd994e  vmovaps [rsp+0x10], xmm1
0000774654fd9954  vmovaps [rsp+0x20], xmm2
0000774654fd995a  vmovaps [rsp+0x30], xmm3
0000774654fd9960  vmovaps [rsp+0x40], xmm4
0000774654fd9966  vmovaps [rsp+0x50], xmm5
0000774654fd996c  vmovaps [rsp+0x60], xmm6
0000774654fd9972  vmovaps [rsp+0x70], xmm7
0000774654fd9978  vmovaps [rsp+0x80], xmm8
0000774654fd9981  vmovaps [rsp+0x90], xmm9
0000774654fd998a  vmovaps [rsp+0xA0], xmm10
0000774654fd9993  vmovaps [rsp+0xB0], xmm12
0000774654fd999c  vmovaps [rsp+0xC0], xmm13
0000774654fd99a5  vmovaps [rsp+0xD0], xmm14
0000774654fd99ae  vmovaps [rsp+0xE0], xmm15
0000774654fd99b7  sub rsp, 0x40
0000774654fd99bb  lea rdi, [rsp]
0000774654fd99bf  lea rsi, [rsp+0x10]
0000774654fd99c4  lea rdx, [rsp+0x20]
0000774654fd99c9  lea rcx, [rsp+0x30]
0000774654fd99ce  mov r8d, 0x00
0000774654fd99d4  lea r9, [r15+0x3A8]
0000774654fd99db  movaps [rdi], xmm11
0000774654fd99df  movaps [rsi], xmm13
0000774654fd99e3  movaps [rdx], xmm12
0000774654fd99e7  movaps [rcx], xmm14
0000774654fd99eb  mov rax, 0x564E5D1DDA50
0000774654fd99f5  call rax
0000774654fd99f7  movaps xmm11, [rsp]
0000774654fd99fc  add rsp, 0x40
0000774654fd9a00  vmovaps xmm0, [rsp]
0000774654fd9a05  vmovaps xmm1, [rsp+0x10]
0000774654fd9a0b  vmovaps xmm2, [rsp+0x20]
0000774654fd9a11  vmovaps xmm3, [rsp+0x30]
0000774654fd9a17  vmovaps xmm4, [rsp+0x40]
0000774654fd9a1d  vmovaps xmm5, [rsp+0x50]
0000774654fd9a23  vmovaps xmm6, [rsp+0x60]
0000774654fd9a29  vmovaps xmm7, [rsp+0x70]
0000774654fd9a2f  vmovaps xmm8, [rsp+0x80]
0000774654fd9a38  vmovaps xmm9, [rsp+0x90]
0000774654fd9a41  vmovaps xmm10, [rsp+0xA0]
0000774654fd9a4a  vmovaps xmm12, [rsp+0xB0]
0000774654fd9a53  vmovaps xmm13, [rsp+0xC0]
0000774654fd9a5c  vmovaps xmm14, [rsp+0xD0]
0000774654fd9a65  vmovaps xmm15, [rsp+0xE0]
0000774654fd9a6e  add rsp, 0xF0
0000774654fd9a75  pop r11
0000774654fd9a77  pop r10
0000774654fd9a79  pop r9
0000774654fd9a7b  pop r8
0000774654fd9a7d  pop rsi
0000774654fd9a7e  pop rdi
0000774654fd9a7f  pop rdx
0000774654fd9a80  pop rcx
0000774654fd9a81  pop rax
0000774654fd9a82  add rsp, 0x08
0000774654fd9a86  jmp 0x0000774654FD73CF
0000774654fd9a8b  sub rsp, 0x08
0000774654fd9a8f  push rax
0000774654fd9a90  push rcx
0000774654fd9a91  push rdx
0000774654fd9a92  push rdi
0000774654fd9a93  push rsi
0000774654fd9a94  push r8
0000774654fd9a96  push r9
0000774654fd9a98  push r10
0000774654fd9a9a  push r11
0000774654fd9a9c  sub rsp, 0xF0
0000774654fd9aa3  vmovaps [rsp], xmm0
0000774654fd9aa8  vmovaps [rsp+0x10], xmm1
0000774654fd9aae  vmovaps [rsp+0x20], xmm2
0000774654fd9ab4  vmovaps [rsp+0x30], xmm3
0000774654fd9aba  vmovaps [rsp+0x40], xmm4
0000774654fd9ac0  vmovaps [rsp+0x50], xmm5
0000774654fd9ac6  vmovaps [rsp+0x60], xmm6
0000774654fd9acc  vmovaps [rsp+0x70], xmm7
0000774654fd9ad2  vmovaps [rsp+0x80], xmm8
0000774654fd9adb  vmovaps [rsp+0x90], xmm9
0000774654fd9ae4  vmovaps [rsp+0xA0], xmm10
0000774654fd9aed  vmovaps [rsp+0xB0], xmm11
0000774654fd9af6  vmovaps [rsp+0xC0], xmm13
0000774654fd9aff  vmovaps [rsp+0xD0], xmm14
0000774654fd9b08  vmovaps [rsp+0xE0], xmm15
0000774654fd9b11  sub rsp, 0x40
0000774654fd9b15  lea rdi, [rsp]
0000774654fd9b19  lea rsi, [rsp+0x10]
0000774654fd9b1e  lea rdx, [rsp+0x20]
0000774654fd9b23  lea rcx, [rsp+0x30]
0000774654fd9b28  mov r8d, 0x00
0000774654fd9b2e  lea r9, [r15+0x3A8]
0000774654fd9b35  movaps [rdi], xmm12
0000774654fd9b39  movaps [rsi], xmm10
0000774654fd9b3d  movaps [rdx], xmm15
0000774654fd9b41  movaps [rcx], xmm14
0000774654fd9b45  mov rax, 0x564E5D1DDA50
0000774654fd9b4f  call rax
0000774654fd9b51  movaps xmm12, [rsp]
0000774654fd9b56  add rsp, 0x40
0000774654fd9b5a  vmovaps xmm0, [rsp]
0000774654fd9b5f  vmovaps xmm1, [rsp+0x10]
0000774654fd9b65  vmovaps xmm2, [rsp+0x20]
0000774654fd9b6b  vmovaps xmm3, [rsp+0x30]
0000774654fd9b71  vmovaps xmm4, [rsp+0x40]
0000774654fd9b77  vmovaps xmm5, [rsp+0x50]
0000774654fd9b7d  vmovaps xmm6, [rsp+0x60]
0000774654fd9b83  vmovaps xmm7, [rsp+0x70]
0000774654fd9b89  vmovaps xmm8, [rsp+0x80]
0000774654fd9b92  vmovaps xmm9, [rsp+0x90]
0000774654fd9b9b  vmovaps xmm10, [rsp+0xA0]
0000774654fd9ba4  vmovaps xmm11, [rsp+0xB0]
0000774654fd9bad  vmovaps xmm13, [rsp+0xC0]
0000774654fd9bb6  vmovaps xmm14, [rsp+0xD0]
0000774654fd9bbf  vmovaps xmm15, [rsp+0xE0]
0000774654fd9bc8  add rsp, 0xF0
0000774654fd9bcf  pop r11
0000774654fd9bd1  pop r10
0000774654fd9bd3  pop r9
0000774654fd9bd5  pop r8
0000774654fd9bd7  pop rsi
0000774654fd9bd8  pop rdi
0000774654fd9bd9  pop rdx
0000774654fd9bda  pop rcx
0000774654fd9bdb  pop rax
0000774654fd9bdc  add rsp, 0x08
0000774654fd9be0  jmp 0x0000774654FD73F8
0000774654fd9be5  call 0x0000774654E0E760
0000774654fd9bea  jmp 0x0000774654FD7405
0000774654fd9bef  call 0x0000774654E0D4E0
0000774654fd9bf4  jmp 0x0000774654FD7412
0000774654fd9bf9  sub rsp, 0x08
0000774654fd9bfd  push rax
0000774654fd9bfe  push rcx
0000774654fd9bff  push rdx
0000774654fd9c00  push rdi
0000774654fd9c01  push rsi
0000774654fd9c02  push r8
0000774654fd9c04  push r9
0000774654fd9c06  push r10
0000774654fd9c08  push r11
0000774654fd9c0a  sub rsp, 0xF0
0000774654fd9c11  vmovaps [rsp], xmm0
0000774654fd9c16  vmovaps [rsp+0x10], xmm1
0000774654fd9c1c  vmovaps [rsp+0x20], xmm2
0000774654fd9c22  vmovaps [rsp+0x30], xmm3
0000774654fd9c28  vmovaps [rsp+0x40], xmm4
0000774654fd9c2e  vmovaps [rsp+0x50], xmm5
0000774654fd9c34  vmovaps [rsp+0x60], xmm6
0000774654fd9c3a  vmovaps [rsp+0x70], xmm7
0000774654fd9c40  vmovaps [rsp+0x80], xmm8
0000774654fd9c49  vmovaps [rsp+0x90], xmm9
0000774654fd9c52  vmovaps [rsp+0xA0], xmm11
0000774654fd9c5b  vmovaps [rsp+0xB0], xmm12
0000774654fd9c64  vmovaps [rsp+0xC0], xmm13
0000774654fd9c6d  vmovaps [rsp+0xD0], xmm14
0000774654fd9c76  vmovaps [rsp+0xE0], xmm15
0000774654fd9c7f  sub rsp, 0x40
0000774654fd9c83  lea rdi, [rsp]
0000774654fd9c87  lea rsi, [rsp+0x10]
0000774654fd9c8c  lea rdx, [rsp+0x20]
0000774654fd9c91  lea rcx, [rsp+0x30]
0000774654fd9c96  mov r8d, 0x00
0000774654fd9c9c  lea r9, [r15+0x3A8]
0000774654fd9ca3  movaps [rdi], xmm10
0000774654fd9ca7  movaps [rsi], xmm7
0000774654fd9caa  movaps [rdx], xmm1
0000774654fd9cad  movaps [rcx], xmm13
0000774654fd9cb1  mov rax, 0x564E5D1DDA50
0000774654fd9cbb  call rax
0000774654fd9cbd  movaps xmm10, [rsp]
0000774654fd9cc2  add rsp, 0x40
0000774654fd9cc6  vmovaps xmm0, [rsp]
0000774654fd9ccb  vmovaps xmm1, [rsp+0x10]
0000774654fd9cd1  vmovaps xmm2, [rsp+0x20]
0000774654fd9cd7  vmovaps xmm3, [rsp+0x30]
0000774654fd9cdd  vmovaps xmm4, [rsp+0x40]
0000774654fd9ce3  vmovaps xmm5, [rsp+0x50]
0000774654fd9ce9  vmovaps xmm6, [rsp+0x60]
0000774654fd9cef  vmovaps xmm7, [rsp+0x70]
0000774654fd9cf5  vmovaps xmm8, [rsp+0x80]
0000774654fd9cfe  vmovaps xmm9, [rsp+0x90]
0000774654fd9d07  vmovaps xmm11, [rsp+0xA0]
0000774654fd9d10  vmovaps xmm12, [rsp+0xB0]
0000774654fd9d19  vmovaps xmm13, [rsp+0xC0]
0000774654fd9d22  vmovaps xmm14, [rsp+0xD0]
0000774654fd9d2b  vmovaps xmm15, [rsp+0xE0]
0000774654fd9d34  add rsp, 0xF0
0000774654fd9d3b  pop r11
0000774654fd9d3d  pop r10
0000774654fd9d3f  pop r9
0000774654fd9d41  pop r8
0000774654fd9d43  pop rsi
0000774654fd9d44  pop rdi
0000774654fd9d45  pop rdx
0000774654fd9d46  pop rcx
0000774654fd9d47  pop rax
0000774654fd9d48  add rsp, 0x08
0000774654fd9d4c  jmp 0x0000774654FD7448
0000774654fd9d51  call 0x0000774654DFF430
0000774654fd9d56  jmp 0x0000774654FD745A
0000774654fd9d5b  sub rsp, 0x08
0000774654fd9d5f  push rax
0000774654fd9d60  push rcx
0000774654fd9d61  push rdx
0000774654fd9d62  push rdi
0000774654fd9d63  push rsi
0000774654fd9d64  push r8
0000774654fd9d66  push r9
0000774654fd9d68  push r10
0000774654fd9d6a  push r11
0000774654fd9d6c  sub rsp, 0xF0
0000774654fd9d73  vmovaps [rsp], xmm0
0000774654fd9d78  vmovaps [rsp+0x10], xmm1
0000774654fd9d7e  vmovaps [rsp+0x20], xmm2
0000774654fd9d84  vmovaps [rsp+0x30], xmm3
0000774654fd9d8a  vmovaps [rsp+0x40], xmm4
0000774654fd9d90  vmovaps [rsp+0x50], xmm5
0000774654fd9d96  vmovaps [rsp+0x60], xmm6
0000774654fd9d9c  vmovaps [rsp+0x70], xmm7
0000774654fd9da2  vmovaps [rsp+0x80], xmm8
0000774654fd9dab  vmovaps [rsp+0x90], xmm10
0000774654fd9db4  vmovaps [rsp+0xA0], xmm11
0000774654fd9dbd  vmovaps [rsp+0xB0], xmm12
0000774654fd9dc6  vmovaps [rsp+0xC0], xmm13
0000774654fd9dcf  vmovaps [rsp+0xD0], xmm14
0000774654fd9dd8  vmovaps [rsp+0xE0], xmm15
0000774654fd9de1  sub rsp, 0x40
0000774654fd9de5  lea rdi, [rsp]
0000774654fd9de9  lea rsi, [rsp+0x10]
0000774654fd9dee  lea rdx, [rsp+0x20]
0000774654fd9df3  lea rcx, [rsp+0x30]
0000774654fd9df8  mov r8d, 0x00
0000774654fd9dfe  lea r9, [r15+0x3A8]
0000774654fd9e05  movaps [rdi], xmm9
0000774654fd9e09  movaps [rsi], xmm8
0000774654fd9e0d  movaps [rdx], xmm14
0000774654fd9e11  movaps [rcx], xmm13
0000774654fd9e15  mov rax, 0x564E5D1DDA50
0000774654fd9e1f  call rax
0000774654fd9e21  movaps xmm9, [rsp]
0000774654fd9e26  add rsp, 0x40
0000774654fd9e2a  vmovaps xmm0, [rsp]
0000774654fd9e2f  vmovaps xmm1, [rsp+0x10]
0000774654fd9e35  vmovaps xmm2, [rsp+0x20]
0000774654fd9e3b  vmovaps xmm3, [rsp+0x30]
0000774654fd9e41  vmovaps xmm4, [rsp+0x40]
0000774654fd9e47  vmovaps xmm5, [rsp+0x50]
0000774654fd9e4d  vmovaps xmm6, [rsp+0x60]
0000774654fd9e53  vmovaps xmm7, [rsp+0x70]
0000774654fd9e59  vmovaps xmm8, [rsp+0x80]
0000774654fd9e62  vmovaps xmm10, [rsp+0x90]
0000774654fd9e6b  vmovaps xmm11, [rsp+0xA0]
0000774654fd9e74  vmovaps xmm12, [rsp+0xB0]
0000774654fd9e7d  vmovaps xmm13, [rsp+0xC0]
0000774654fd9e86  vmovaps xmm14, [rsp+0xD0]
0000774654fd9e8f  vmovaps xmm15, [rsp+0xE0]
0000774654fd9e98  add rsp, 0xF0
0000774654fd9e9f  pop r11
0000774654fd9ea1  pop r10
0000774654fd9ea3  pop r9
0000774654fd9ea5  pop r8
0000774654fd9ea7  pop rsi
0000774654fd9ea8  pop rdi
0000774654fd9ea9  pop rdx
0000774654fd9eaa  pop rcx
0000774654fd9eab  pop rax
0000774654fd9eac  add rsp, 0x08
0000774654fd9eb0  jmp 0x0000774654FD7488
0000774654fd9eb5  sub rsp, 0x08
0000774654fd9eb9  push rax
0000774654fd9eba  push rcx
0000774654fd9ebb  push rdx
0000774654fd9ebc  push rdi
0000774654fd9ebd  push rsi
0000774654fd9ebe  push r8
0000774654fd9ec0  push r9
0000774654fd9ec2  push r10
0000774654fd9ec4  push r11
0000774654fd9ec6  sub rsp, 0xF0
0000774654fd9ecd  vmovaps [rsp], xmm0
0000774654fd9ed2  vmovaps [rsp+0x10], xmm1
0000774654fd9ed8  vmovaps [rsp+0x20], xmm2
0000774654fd9ede  vmovaps [rsp+0x30], xmm3
0000774654fd9ee4  vmovaps [rsp+0x40], xmm4
0000774654fd9eea  vmovaps [rsp+0x50], xmm5
0000774654fd9ef0  vmovaps [rsp+0x60], xmm6
0000774654fd9ef6  vmovaps [rsp+0x70], xmm7
0000774654fd9efc  vmovaps [rsp+0x80], xmm8
0000774654fd9f05  vmovaps [rsp+0x90], xmm9
0000774654fd9f0e  vmovaps [rsp+0xA0], xmm10
0000774654fd9f17  vmovaps [rsp+0xB0], xmm11
0000774654fd9f20  vmovaps [rsp+0xC0], xmm12
0000774654fd9f29  vmovaps [rsp+0xD0], xmm14
0000774654fd9f32  vmovaps [rsp+0xE0], xmm15
0000774654fd9f3b  sub rsp, 0x40
0000774654fd9f3f  lea rdi, [rsp]
0000774654fd9f43  lea rsi, [rsp+0x10]
0000774654fd9f48  lea rdx, [rsp+0x20]
0000774654fd9f4d  lea rcx, [rsp+0x30]
0000774654fd9f52  mov r8d, 0x00
0000774654fd9f58  lea r9, [r15+0x3A8]
0000774654fd9f5f  movaps [rdi], xmm13
0000774654fd9f63  movaps [rsi], xmm11
0000774654fd9f67  movaps [rdx], xmm15
0000774654fd9f6b  movaps [rcx], xmm14
0000774654fd9f6f  mov rax, 0x564E5D1DDA50
0000774654fd9f79  call rax
0000774654fd9f7b  movaps xmm13, [rsp]
0000774654fd9f80  add rsp, 0x40
0000774654fd9f84  vmovaps xmm0, [rsp]
0000774654fd9f89  vmovaps xmm1, [rsp+0x10]
0000774654fd9f8f  vmovaps xmm2, [rsp+0x20]
0000774654fd9f95  vmovaps xmm3, [rsp+0x30]
0000774654fd9f9b  vmovaps xmm4, [rsp+0x40]
0000774654fd9fa1  vmovaps xmm5, [rsp+0x50]
0000774654fd9fa7  vmovaps xmm6, [rsp+0x60]
0000774654fd9fad  vmovaps xmm7, [rsp+0x70]
0000774654fd9fb3  vmovaps xmm8, [rsp+0x80]
0000774654fd9fbc  vmovaps xmm9, [rsp+0x90]
0000774654fd9fc5  vmovaps xmm10, [rsp+0xA0]
0000774654fd9fce  vmovaps xmm11, [rsp+0xB0]
0000774654fd9fd7  vmovaps xmm12, [rsp+0xC0]
0000774654fd9fe0  vmovaps xmm14, [rsp+0xD0]
0000774654fd9fe9  vmovaps xmm15, [rsp+0xE0]
0000774654fd9ff2  add rsp, 0xF0
0000774654fd9ff9  pop r11
0000774654fd9ffb  pop r10
0000774654fd9ffd  pop r9
0000774654fd9fff  pop r8
0000774654fda001  pop rsi
0000774654fda002  pop rdi
0000774654fda003  pop rdx
0000774654fda004  pop rcx
0000774654fda005  pop rax
0000774654fda006  add rsp, 0x08
0000774654fda00a  jmp 0x0000774654FD74B6
0000774654fda00f  sub rsp, 0x08
0000774654fda013  push rax
0000774654fda014  push rcx
0000774654fda015  push rdx
0000774654fda016  push rdi
0000774654fda017  push rsi
0000774654fda018  push r8
0000774654fda01a  push r9
0000774654fda01c  push r10
0000774654fda01e  push r11
0000774654fda020  sub rsp, 0xF0
0000774654fda027  vmovaps [rsp], xmm0
0000774654fda02c  vmovaps [rsp+0x10], xmm1
0000774654fda032  vmovaps [rsp+0x20], xmm2
0000774654fda038  vmovaps [rsp+0x30], xmm3
0000774654fda03e  vmovaps [rsp+0x40], xmm4
0000774654fda044  vmovaps [rsp+0x50], xmm5
0000774654fda04a  vmovaps [rsp+0x60], xmm6
0000774654fda050  vmovaps [rsp+0x70], xmm7
0000774654fda056  vmovaps [rsp+0x80], xmm8
0000774654fda05f  vmovaps [rsp+0x90], xmm9
0000774654fda068  vmovaps [rsp+0xA0], xmm10
0000774654fda071  vmovaps [rsp+0xB0], xmm11
0000774654fda07a  vmovaps [rsp+0xC0], xmm12
0000774654fda083  vmovaps [rsp+0xD0], xmm13
0000774654fda08c  vmovaps [rsp+0xE0], xmm15
0000774654fda095  sub rsp, 0x40
0000774654fda099  lea rdi, [rsp]
0000774654fda09d  lea rsi, [rsp+0x10]
0000774654fda0a2  lea rdx, [rsp+0x20]
0000774654fda0a7  lea rcx, [rsp+0x30]
0000774654fda0ac  mov r8d, 0x00
0000774654fda0b2  lea r9, [r15+0x3A8]
0000774654fda0b9  movaps [rdi], xmm14
0000774654fda0bd  movaps [rsi], xmm12
0000774654fda0c1  movaps [rdx], xmm1
0000774654fda0c4  movaps [rcx], xmm15
0000774654fda0c8  mov rax, 0x564E5D1DDA50
0000774654fda0d2  call rax
0000774654fda0d4  movaps xmm14, [rsp]
0000774654fda0d9  add rsp, 0x40
0000774654fda0dd  vmovaps xmm0, [rsp]
0000774654fda0e2  vmovaps xmm1, [rsp+0x10]
0000774654fda0e8  vmovaps xmm2, [rsp+0x20]
0000774654fda0ee  vmovaps xmm3, [rsp+0x30]
0000774654fda0f4  vmovaps xmm4, [rsp+0x40]
0000774654fda0fa  vmovaps xmm5, [rsp+0x50]
0000774654fda100  vmovaps xmm6, [rsp+0x60]
0000774654fda106  vmovaps xmm7, [rsp+0x70]
0000774654fda10c  vmovaps xmm8, [rsp+0x80]
0000774654fda115  vmovaps xmm9, [rsp+0x90]
0000774654fda11e  vmovaps xmm10, [rsp+0xA0]
0000774654fda127  vmovaps xmm11, [rsp+0xB0]
0000774654fda130  vmovaps xmm12, [rsp+0xC0]
0000774654fda139  vmovaps xmm13, [rsp+0xD0]
0000774654fda142  vmovaps xmm15, [rsp+0xE0]
0000774654fda14b  add rsp, 0xF0
0000774654fda152  pop r11
0000774654fda154  pop r10
0000774654fda156  pop r9
0000774654fda158  pop r8
0000774654fda15a  pop rsi
0000774654fda15b  pop rdi
0000774654fda15c  pop rdx
0000774654fda15d  pop rcx
0000774654fda15e  pop rax
0000774654fda15f  add rsp, 0x08
0000774654fda163  jmp 0x0000774654FD74E4
0000774654fda168  call 0x0000774654E079B0
0000774654fda16d  jmp 0x0000774654FD74FA
0000774654fda172  call 0x0000774654EE3440
0000774654fda177  jmp 0x0000774654FD7504
0000774654fda17c  call 0x0000774654EDFCE0
0000774654fda181  jmp 0x0000774654FD750E
0000774654fda186  call 0x0000774654EE46C0
0000774654fda18b  jmp 0x0000774654FD7518
0000774654fda190  int3
0000774654fda191  nop [rax+rax*1], ax
0000774654fda19a  nop [rax+rax*1], ax
0000774654fda1a0  mov rax, [r15+0xF8]
0000774654fda1a7  lea r14, [rax+0x110]
0000774654fda1ae  mov r12, [r13+r14*1]
0000774654fda1b3  mov [r15+0xE8], r12
0000774654fda1ba  lea r14, [rax+0x100]
0000774654fda1c1  mov r12, [r13+r14*1]
0000774654fda1c6  lea r14, [rax+0x108]
0000774654fda1cd  mov r11, [r13+r14*1]
0000774654fda1d2  movq xmm1, r12
0000774654fda1d7  movq xmm15, r11
0000774654fda1dc  movq xmm1, xmm1
0000774654fda1e0  movq xmm1, xmm1
0000774654fda1e4  movaps [r15+0x1A0], xmm1
0000774654fda1ec  movq xmm15, xmm15
0000774654fda1f1  movq xmm15, xmm15
0000774654fda1f6  movaps [r15+0x190], xmm15
0000774654fda1fe  lea r14, [rax+0xF0]
0000774654fda205  mov r12, [r13+r14*1]
0000774654fda20a  lea r14, [rax+0xF8]
0000774654fda211  mov r11, [r13+r14*1]
0000774654fda216  movq xmm1, r12
0000774654fda21b  movq xmm15, r11
0000774654fda220  movq xmm1, xmm1
0000774654fda224  movq xmm1, xmm1
0000774654fda228  movaps [r15+0x1C0], xmm1
0000774654fda230  movq xmm15, xmm15
0000774654fda235  movq xmm15, xmm15
0000774654fda23a  movaps [r15+0x1B0], xmm15
0000774654fda242  lea r14, [rax+0xE0]
0000774654fda249  mov r12, [r13+r14*1]
0000774654fda24e  lea r14, [rax+0xE8]
0000774654fda255  mov r11, [r13+r14*1]
0000774654fda25a  movq xmm1, r12
0000774654fda25f  movq xmm15, r11
0000774654fda264  movq xmm1, xmm1
0000774654fda268  movq xmm1, xmm1
0000774654fda26c  movaps [r15+0x1E0], xmm1
0000774654fda274  movq xmm15, xmm15
0000774654fda279  movq xmm15, xmm15
0000774654fda27e  movaps [r15+0x1D0], xmm15
0000774654fda286  lea r14, [rax+0xD0]
0000774654fda28d  mov r12, [r13+r14*1]
0000774654fda292  lea r14, [rax+0xD8]
0000774654fda299  mov r11, [r13+r14*1]
0000774654fda29e  movq xmm1, r12
0000774654fda2a3  movq xmm15, r11
0000774654fda2a8  movq xmm1, xmm1
0000774654fda2ac  movq xmm1, xmm1
0000774654fda2b0  movaps [r15+0x200], xmm1
0000774654fda2b8  movq xmm15, xmm15
0000774654fda2bd  movq xmm15, xmm15
0000774654fda2c2  movaps [r15+0x1F0], xmm15
0000774654fda2ca  mov qword ptr [r15+0x40], 0x430000
0000774654fda2d2  mov r14d, 0x4304C0
0000774654fda2d8  mov r12, [r13+r14*1]
0000774654fda2dd  movq xmm1, r12
0000774654fda2e2  lea r14, [rax+0x120]
0000774654fda2e9  mov [r15+0xF8], r14
0000774654fda2f0  mov rax, [r15+0x50]
0000774654fda2f4  movups xmm15, [r13+rax*1]
0000774654fda2fa  movaps [r15+0x120], xmm15
0000774654fda302  mov qword ptr [r15+0x48], 0x10
0000774654fda30a  xor eax, eax
0000774654fda30c  mov r14d, 0x10
0000774654fda312  mov r12d, 0x200
0000774654fda318  cmp r14, r12
0000774654fda31b  cmc
0000774654fda31c  lahf
0000774654fda31d  seto al
0000774654fda320  mov [r15+0x108], eax
0000774654fda327  pextrq rax, xmm15, 0x01
0000774654fda32e  movq xmm14, rax
0000774654fda333  movaps [r15+0x130], xmm14
0000774654fda33b  movq rax, xmm1
0000774654fda340  movq r14, xmm15
0000774654fda345  vmovq xmm1, rax
0000774654fda34a  vmovq xmm15, r14
0000774654fda34f  movaps xmm13, xmm1
0000774654fda353  addsd xmm13, xmm15
0000774654fda358  ucomisd xmm13, xmm13
0000774654fda35d  jp 0x0000774654FDA476
0000774654fda363  movq xmm13, xmm13
0000774654fda368  movq rax, xmm13
0000774654fda36d  movq r14, xmm14
0000774654fda372  vmovq xmm1, rax
0000774654fda377  vmovq xmm15, r14
0000774654fda37c  movaps xmm14, xmm1
0000774654fda380  addsd xmm14, xmm15
0000774654fda385  ucomisd xmm14, xmm14
0000774654fda38a  jp 0x0000774654FDA4BE
0000774654fda390  movq xmm14, xmm14
0000774654fda395  movaps [r15+0x110], xmm14
0000774654fda39d  mov eax, [r15+0x108]
0000774654fda3a4  sahf
0000774654fda3a5  jnz 0x0000774654FDA3D7
0000774654fda3a7  cmp dword ptr [r15+0x318], 0x00
0000774654fda3af  jz 0x0000774654FDA6D0
0000774654fda3b5  nop [rax+rax*1], ax
0000774654fda3be  nop [rax+rax*1], eax
0000774654fda3c6  mov eax, 0x41043C
0000774654fda3cb  mov [r15+0x100], rax
0000774654fda3d2  jmp 0x0000774654DFE110
0000774654fda3d7  cmp dword ptr [r15+0x318], 0x00
0000774654fda3df  jz 0x0000774654FDA510
0000774654fda3e5  nop [rax+rax*1], ax
0000774654fda3ee  nop [rax+rax*1], eax
0000774654fda3f6  mov eax, 0x410420
0000774654fda3fb  mov [r15+0x100], rax
0000774654fda402  jmp 0x0000774654DFE110
0000774654fda407  int3
0000774654fda408  call 0x0000774654EE27E0
0000774654fda40d  jmp 0x0000774654FDA1B3
0000774654fda412  call 0x0000774654EE27E0
0000774654fda417  jmp 0x0000774654FDA1C6
0000774654fda41c  call 0x0000774654EE1570
0000774654fda421  jmp 0x0000774654FDA1D2
0000774654fda426  call 0x0000774654EE27E0
0000774654fda42b  jmp 0x0000774654FDA20A
0000774654fda430  call 0x0000774654EE1570
0000774654fda435  jmp 0x0000774654FDA216
0000774654fda43a  call 0x0000774654EE27E0
0000774654fda43f  jmp 0x0000774654FDA24E
0000774654fda444  call 0x0000774654EE1570
0000774654fda449  jmp 0x0000774654FDA25A
0000774654fda44e  call 0x0000774654EE27E0
0000774654fda453  jmp 0x0000774654FDA292
0000774654fda458  call 0x0000774654EE1570
0000774654fda45d  jmp 0x0000774654FDA29E
0000774654fda462  call 0x0000774654EE27E0
0000774654fda467  jmp 0x0000774654FDA2DD
0000774654fda46c  call 0x0000774654E0E760
0000774654fda471  jmp 0x0000774654FDA2FA
0000774654fda476  ucomisd xmm1, xmm15
0000774654fda47b  jp 0x0000774654FDA48A
0000774654fda47d  movaps xmm13, [0x0000774654BFE060]
0000774654fda485  jmp 0x0000774654FDA363
0000774654fda48a  vxorps xmm0, xmm1, xmm15
0000774654fda48f  pextrw eax, xmm0, 0x03
0000774654fda494  and eax, 0x7FF8
0000774654fda499  cmp eax, 0x08
0000774654fda49c  jnz 0x0000774654FDA363
0000774654fda4a2  movq rax, xmm15
0000774654fda4a7  shl rax, 0x0D
0000774654fda4ab  jbe 0x0000774654FDA363
0000774654fda4b1  vorps xmm13, xmm15, [0x0000774654BFE070]
0000774654fda4b9  jmp 0x0000774654FDA363
0000774654fda4be  ucomisd xmm1, xmm15
0000774654fda4c3  jp 0x0000774654FDA4D2
0000774654fda4c5  movaps xmm14, [0x0000774654BFE060]
0000774654fda4cd  jmp 0x0000774654FDA390
0000774654fda4d2  vxorps xmm0, xmm1, xmm15
0000774654fda4d7  pextrw eax, xmm0, 0x03
0000774654fda4dc  and eax, 0x7FF8
0000774654fda4e1  cmp eax, 0x08
0000774654fda4e4  jnz 0x0000774654FDA390
0000774654fda4ea  movq rax, xmm15
0000774654fda4ef  shl rax, 0x0D
0000774654fda4f3  jbe 0x0000774654FDA390
0000774654fda4f9  vorps xmm14, xmm15, [0x0000774654BFE070]
0000774654fda501  jmp 0x0000774654FDA390
0000774654fda506  int3
0000774654fda507  nop [rax+rax*1], ax
0000774654fda510  mov rax, [r15+0x48]
0000774654fda514  mov r14, [r15+0x50]
0000774654fda518  lea r12, [r14+rax*1]
0000774654fda51c  movups xmm1, [r13+r12*1]
0000774654fda522  movaps [r15+0x120], xmm1
0000774654fda52a  lea r14, [rax+0x10]
0000774654fda52e  mov [r15+0x48], r14
0000774654fda532  xor eax, eax
0000774654fda534  mov r12d, 0x200
0000774654fda53a  cmp r14, r12
0000774654fda53d  cmc
0000774654fda53e  lahf
0000774654fda53f  seto al
0000774654fda542  mov [r15+0x108], eax
0000774654fda549  pextrq rax, xmm1, 0x01
0000774654fda550  movq xmm15, rax
0000774654fda555  movaps [r15+0x130], xmm15
0000774654fda55d  movaps xmm14, [r15+0x110]
0000774654fda565  movq rax, xmm14
0000774654fda56a  movq r14, xmm1
0000774654fda56f  vmovq xmm1, rax
0000774654fda574  vmovq xmm14, r14
0000774654fda579  movaps xmm13, xmm1
0000774654fda57d  addsd xmm13, xmm14
0000774654fda582  ucomisd xmm13, xmm13
0000774654fda587  jp 0x0000774654FDA63C
0000774654fda58d  movq xmm13, xmm13
0000774654fda592  movq rax, xmm13
0000774654fda597  movq r14, xmm15
0000774654fda59c  vmovq xmm1, rax
0000774654fda5a1  vmovq xmm15, r14
0000774654fda5a6  movaps xmm14, xmm1
0000774654fda5aa  addsd xmm14, xmm15
0000774654fda5af  ucomisd xmm14, xmm14
0000774654fda5b4  jp 0x0000774654FDA684
0000774654fda5ba  movq xmm14, xmm14
0000774654fda5bf  movaps [r15+0x110], xmm14
0000774654fda5c7  mov eax, [r15+0x108]
0000774654fda5ce  sahf
0000774654fda5cf  jnz 0x0000774654FDA601
0000774654fda5d1  cmp dword ptr [r15+0x318], 0x00
0000774654fda5d9  jz 0x0000774654FDA6D0
0000774654fda5df  nop [rax+rax*1], ax
0000774654fda5e8  nop [rax+rax*1], eax
0000774654fda5f0  mov eax, 0x41043C
0000774654fda5f5  mov [r15+0x100], rax
0000774654fda5fc  jmp 0x0000774654DFE110
0000774654fda601  cmp dword ptr [r15+0x318], 0x00
0000774654fda609  jz 0x0000774654FDA510
0000774654fda60f  nop [rax+rax*1], ax
0000774654fda618  nop [rax+rax*1], eax
0000774654fda620  mov eax, 0x410420
0000774654fda625  mov [r15+0x100], rax
0000774654fda62c  jmp 0x0000774654DFE110
0000774654fda631  int3
0000774654fda632  call 0x0000774654EB52F0
0000774654fda637  jmp 0x0000774654FDA522
0000774654fda63c  ucomisd xmm1, xmm14
0000774654fda641  jp 0x0000774654FDA650
0000774654fda643  movaps xmm13, [0x0000774654BFE060]
0000774654fda64b  jmp 0x0000774654FDA58D
0000774654fda650  vxorps xmm0, xmm1, xmm14
0000774654fda655  pextrw eax, xmm0, 0x03
0000774654fda65a  and eax, 0x7FF8
0000774654fda65f  cmp eax, 0x08
0000774654fda662  jnz 0x0000774654FDA58D
0000774654fda668  movq rax, xmm14
0000774654fda66d  shl rax, 0x0D
0000774654fda671  jbe 0x0000774654FDA58D
0000774654fda677  vorps xmm13, xmm14, [0x0000774654BFE070]
0000774654fda67f  jmp 0x0000774654FDA58D
0000774654fda684  ucomisd xmm1, xmm15
0000774654fda689  jp 0x0000774654FDA698
0000774654fda68b  movaps xmm14, [0x0000774654BFE060]
0000774654fda693  jmp 0x0000774654FDA5BA
0000774654fda698  vxorps xmm0, xmm1, xmm15
0000774654fda69d  pextrw eax, xmm0, 0x03
0000774654fda6a2  and eax, 0x7FF8
0000774654fda6a7  cmp eax, 0x08
0000774654fda6aa  jnz 0x0000774654FDA5BA
0000774654fda6b0  movq rax, xmm15
0000774654fda6b5  shl rax, 0x0D
0000774654fda6b9  jbe 0x0000774654FDA5BA
0000774654fda6bf  vorps xmm14, xmm15, [0x0000774654BFE070]
0000774654fda6c7  jmp 0x0000774654FDA5BA
0000774654fda6cc  int3
0000774654fda6cd  nop [rax], eax
0000774654fda6d0  mov rax, [r15+0x40]
0000774654fda6d4  lea r14, [rax+0x4C0]
0000774654fda6db  movaps xmm1, [r15+0x110]
0000774654fda6e3  movq rax, xmm1
0000774654fda6e8  mov [r13+r14*1], rax
0000774654fda6ed  mov rax, [r15+0xF0]
0000774654fda6f4  mov [r15+0x100], rax
0000774654fda6fb  jmp 0x0000774654FCE5C0
0000774654fda700  int3
0000774654fda701  call 0x0000774654ED5EB0
0000774654fda706  jmp 0x0000774654FDA6ED
0000774654fda70b  int3
0000774654fda70c  nop [rax], eax
0000774654fda710  mov qword ptr [r15+0x100], 0x04
0000774654fda71b  mov esi, 0x00
0000774654fda720  mov edx, 0x09
0000774654fda725  mov rdi, 0x7FFE573E1C80
0000774654fda72f  mov rax, 0x564E5D070970
0000774654fda739  call rax
0000774654fda73b  cmp dword ptr [r15+0x318], 0x00
0000774654fda743  jnz 0x0000774654DFE110
0000774654fda749  jmp 0x0000774654DFE0A0
0000774654fda74e  int3
0000774654fda74f  int3
