00007cbcc2dce69b  nop [rax+rax*1], eax
00007cbcc2dce6a0  vmovaps xmm1, [0x00007CBCC29FE010]
00007cbcc2dce6a8  movq xmm1, xmm1
00007cbcc2dce6ac  movaps [r15+0x110], xmm1
00007cbcc2dce6b4  vmovaps xmm1, [0x00007CBCC29FE020]
00007cbcc2dce6bc  movq xmm1, xmm1
00007cbcc2dce6c0  movaps [r15+0x120], xmm1
00007cbcc2dce6c8  mov eax, 0x420470
00007cbcc2dce6cd  mov r14, [r13+rax*1]
00007cbcc2dce6d2  movq xmm1, r14
00007cbcc2dce6d7  movaps [r15+0x130], xmm1
00007cbcc2dce6df  vmovaps xmm1, [0x00007CBCC29FE030]
00007cbcc2dce6e7  vpbroadcastq xmm1, xmm1
00007cbcc2dce6ec  movaps [r15+0x140], xmm1
00007cbcc2dce6f4  mov qword ptr [r15+0x40], 0x02
00007cbcc2dce6fc  vmovaps xmm15, [0x00007CBCC29FE040]
00007cbcc2dce704  movq xmm15, xmm15
00007cbcc2dce709  movaps [r15+0x150], xmm15
00007cbcc2dce711  mov qword ptr [r15+0x58], 0x420000
00007cbcc2dce719  vmovaps xmm15, [0x00007CBCC29FE050]
00007cbcc2dce721  vpbroadcastq xmm15, xmm15
00007cbcc2dce726  movaps [r15+0x160], xmm15
00007cbcc2dce72e  mov rax, [r15+0x40]
00007cbcc2dce732  vmovq xmm14, rax
00007cbcc2dce737  vpbroadcastq xmm14, xmm14
00007cbcc2dce73c  movaps [r15+0x170], xmm14
00007cbcc2dce744  mov eax, 0x420480
00007cbcc2dce749  movups xmm13, [r13+rax*1]
00007cbcc2dce74f  mov qword ptr [r15+0x40], 0x4304C8
00007cbcc2dce757  mov qword ptr [r15+0x50], 0x4306D0
00007cbcc2dce75f  vpmovqd xmm12, xmm13
00007cbcc2dce765  pxor xmm11, xmm11
00007cbcc2dce76a  punpcklqdq xmm12, xmm11
00007cbcc2dce76f  movaps [r15+0x210], xmm12
00007cbcc2dce777  movq xmm12, qword ptr [r15+0x120]
00007cbcc2dce780  movq xmm11, qword ptr [r15+0x130]
00007cbcc2dce789  psubd xmm12, xmm11
00007cbcc2dce78e  movq xmm12, xmm12
00007cbcc2dce793  paddq xmm13, xmm14
00007cbcc2dce798  movaps [r15+0x180], xmm13
00007cbcc2dce7a0  movq xmm14, qword ptr [r15+0x150]
00007cbcc2dce7a9  paddd xmm11, xmm14
00007cbcc2dce7ae  movq xmm11, xmm11
00007cbcc2dce7b3  movq xmm11, xmm11
00007cbcc2dce7b8  movaps [r15+0x130], xmm11
00007cbcc2dce7c0  pmovzxdq xmm12, xmm12
00007cbcc2dce7c6  psllq xmm12, 0x00
00007cbcc2dce7cc  movq xmm14, qword ptr [r15+0x210]
00007cbcc2dce7d5  movq xmm13, qword ptr [r15+0x110]
00007cbcc2dce7de  paddd xmm14, xmm13
00007cbcc2dce7e3  movq xmm14, xmm14
00007cbcc2dce7e8  vcvtuqq2pd xmm12, xmm12
00007cbcc2dce7ee  pmovzxdq xmm14, xmm14
00007cbcc2dce7f4  psllq xmm14, 0x00
00007cbcc2dce7fa  vcvtuqq2pd xmm14, xmm14
00007cbcc2dce800  movaps xmm13, xmm12
00007cbcc2dce804  mulpd xmm13, xmm1
00007cbcc2dce809  vcmppd xmm11, xmm13, xmm13, 0x03
00007cbcc2dce80f  ptest xmm11, xmm11
00007cbcc2dce815  jnz 0x00007CBCC2DCE8FF
00007cbcc2dce81b  movaps [r15+0x220], xmm13
00007cbcc2dce823  mov eax, 0x4306D0
00007cbcc2dce828  movups [r13+rax*1], xmm13
00007cbcc2dce82e  movaps xmm1, xmm14
00007cbcc2dce832  mulpd xmm1, xmm15
00007cbcc2dce837  vcmppd xmm13, xmm1, xmm1, 0x03
00007cbcc2dce83c  ptest xmm13, xmm13
00007cbcc2dce842  jnz 0x00007CBCC2DCEA4C
00007cbcc2dce848  movaps [r15+0x210], xmm1
00007cbcc2dce850  mov eax, 0x4304C8
00007cbcc2dce855  movups [r13+rax*1], xmm1
00007cbcc2dce85b  mov qword ptr [r15+0x48], 0x10
00007cbcc2dce863  xor eax, eax
00007cbcc2dce865  mov r14d, 0x10
00007cbcc2dce86b  mov r12d, 0x200
00007cbcc2dce871  cmp r14, r12
00007cbcc2dce874  cmc
00007cbcc2dce875  lahf
00007cbcc2dce876  seto al
00007cbcc2dce879  mov [r15+0x108], eax
00007cbcc2dce880  mov eax, [r15+0x108]
00007cbcc2dce887  sahf
00007cbcc2dce888  jnz 0x00007CBCC2DCE8BA
00007cbcc2dce88a  cmp dword ptr [r15+0x318], 0x00
00007cbcc2dce892  jz 0x00007CBCC2DCEFF0
00007cbcc2dce898  nop [rax+rax*1], ax
00007cbcc2dce8a1  nop [rax+rax*1], eax
00007cbcc2dce8a9  mov eax, 0x4101EC
00007cbcc2dce8ae  mov [r15+0x100], rax
00007cbcc2dce8b5  jmp 0x00007CBCC2BFE110
00007cbcc2dce8ba  cmp dword ptr [r15+0x318], 0x00
00007cbcc2dce8c2  jz 0x00007CBCC2DCEBA0
00007cbcc2dce8c8  nop [rax+rax*1], ax
00007cbcc2dce8d1  nop [rax+rax*1], eax
00007cbcc2dce8d9  mov eax, 0x4101AC
00007cbcc2dce8de  mov [r15+0x100], rax
00007cbcc2dce8e5  jmp 0x00007CBCC2BFE110
00007cbcc2dce8ea  int3
00007cbcc2dce8eb  call 0x00007CBCC2C0DC20
00007cbcc2dce8f0  jmp 0x00007CBCC2DCE6D2
00007cbcc2dce8f5  call 0x00007CBCC2C0C260
00007cbcc2dce8fa  jmp 0x00007CBCC2DCE74F
00007cbcc2dce8ff  sub rsp, 0x08
00007cbcc2dce903  push rax
00007cbcc2dce904  push rcx
00007cbcc2dce905  push rdx
00007cbcc2dce906  push rdi
00007cbcc2dce907  push rsi
00007cbcc2dce908  push r8
00007cbcc2dce90a  push r9
00007cbcc2dce90c  push r10
00007cbcc2dce90e  push r11
00007cbcc2dce910  sub rsp, 0xF0
00007cbcc2dce917  vmovaps [rsp], xmm0
00007cbcc2dce91c  vmovaps [rsp+0x10], xmm1
00007cbcc2dce922  vmovaps [rsp+0x20], xmm2
00007cbcc2dce928  vmovaps [rsp+0x30], xmm3
00007cbcc2dce92e  vmovaps [rsp+0x40], xmm4
00007cbcc2dce934  vmovaps [rsp+0x50], xmm5
00007cbcc2dce93a  vmovaps [rsp+0x60], xmm6
00007cbcc2dce940  vmovaps [rsp+0x70], xmm7
00007cbcc2dce946  vmovaps [rsp+0x80], xmm8
00007cbcc2dce94f  vmovaps [rsp+0x90], xmm9
00007cbcc2dce958  vmovaps [rsp+0xA0], xmm10
00007cbcc2dce961  vmovaps [rsp+0xB0], xmm11
00007cbcc2dce96a  vmovaps [rsp+0xC0], xmm12
00007cbcc2dce973  vmovaps [rsp+0xD0], xmm14
00007cbcc2dce97c  vmovaps [rsp+0xE0], xmm15
00007cbcc2dce985  sub rsp, 0x30
00007cbcc2dce989  movaps [rsp], xmm13
00007cbcc2dce98e  movaps [rsp+0x10], xmm12
00007cbcc2dce994  movaps [rsp+0x20], xmm1
00007cbcc2dce999  lea rdi, [rsp]
00007cbcc2dce99d  mov esi, 0x00
00007cbcc2dce9a2  mov rax, 0x5BFE0F0EE530
00007cbcc2dce9ac  call rax
00007cbcc2dce9ae  movaps xmm13, [rsp]
00007cbcc2dce9b3  add rsp, 0x30
00007cbcc2dce9b7  vmovaps xmm0, [rsp]
00007cbcc2dce9bc  vmovaps xmm1, [rsp+0x10]
00007cbcc2dce9c2  vmovaps xmm2, [rsp+0x20]
00007cbcc2dce9c8  vmovaps xmm3, [rsp+0x30]
00007cbcc2dce9ce  vmovaps xmm4, [rsp+0x40]
00007cbcc2dce9d4  vmovaps xmm5, [rsp+0x50]
00007cbcc2dce9da  vmovaps xmm6, [rsp+0x60]
00007cbcc2dce9e0  vmovaps xmm7, [rsp+0x70]
00007cbcc2dce9e6  vmovaps xmm8, [rsp+0x80]
00007cbcc2dce9ef  vmovaps xmm9, [rsp+0x90]
00007cbcc2dce9f8  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dcea01  vmovaps xmm11, [rsp+0xB0]
00007cbcc2dcea0a  vmovaps xmm12, [rsp+0xC0]
00007cbcc2dcea13  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dcea1c  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dcea25  add rsp, 0xF0
00007cbcc2dcea2c  pop r11
00007cbcc2dcea2e  pop r10
00007cbcc2dcea30  pop r9
00007cbcc2dcea32  pop r8
00007cbcc2dcea34  pop rsi
00007cbcc2dcea35  pop rdi
00007cbcc2dcea36  pop rdx
00007cbcc2dcea37  pop rcx
00007cbcc2dcea38  pop rax
00007cbcc2dcea39  add rsp, 0x08
00007cbcc2dcea3d  jmp 0x00007CBCC2DCE81B
00007cbcc2dcea42  call 0x00007CBCC2C0C380
00007cbcc2dcea47  jmp 0x00007CBCC2DCE82E
00007cbcc2dcea4c  sub rsp, 0x08
00007cbcc2dcea50  push rax
00007cbcc2dcea51  push rcx
00007cbcc2dcea52  push rdx
00007cbcc2dcea53  push rdi
00007cbcc2dcea54  push rsi
00007cbcc2dcea55  push r8
00007cbcc2dcea57  push r9
00007cbcc2dcea59  push r10
00007cbcc2dcea5b  push r11
00007cbcc2dcea5d  sub rsp, 0xF0
00007cbcc2dcea64  vmovaps [rsp], xmm0
00007cbcc2dcea69  vmovaps [rsp+0x10], xmm2
00007cbcc2dcea6f  vmovaps [rsp+0x20], xmm3
00007cbcc2dcea75  vmovaps [rsp+0x30], xmm4
00007cbcc2dcea7b  vmovaps [rsp+0x40], xmm5
00007cbcc2dcea81  vmovaps [rsp+0x50], xmm6
00007cbcc2dcea87  vmovaps [rsp+0x60], xmm7
00007cbcc2dcea8d  vmovaps [rsp+0x70], xmm8
00007cbcc2dcea93  vmovaps [rsp+0x80], xmm9
00007cbcc2dcea9c  vmovaps [rsp+0x90], xmm10
00007cbcc2dceaa5  vmovaps [rsp+0xA0], xmm11
00007cbcc2dceaae  vmovaps [rsp+0xB0], xmm12
00007cbcc2dceab7  vmovaps [rsp+0xC0], xmm13
00007cbcc2dceac0  vmovaps [rsp+0xD0], xmm14
00007cbcc2dceac9  vmovaps [rsp+0xE0], xmm15
00007cbcc2dcead2  sub rsp, 0x30
00007cbcc2dcead6  movaps [rsp], xmm1
00007cbcc2dceada  movaps [rsp+0x10], xmm14
00007cbcc2dceae0  movaps [rsp+0x20], xmm15
00007cbcc2dceae6  lea rdi, [rsp]
00007cbcc2dceaea  mov esi, 0x00
00007cbcc2dceaef  mov rax, 0x5BFE0F0EE530
00007cbcc2dceaf9  call rax
00007cbcc2dceafb  movaps xmm1, [rsp]
00007cbcc2dceaff  add rsp, 0x30
00007cbcc2dceb03  vmovaps xmm0, [rsp]
00007cbcc2dceb08  vmovaps xmm2, [rsp+0x10]
00007cbcc2dceb0e  vmovaps xmm3, [rsp+0x20]
00007cbcc2dceb14  vmovaps xmm4, [rsp+0x30]
00007cbcc2dceb1a  vmovaps xmm5, [rsp+0x40]
00007cbcc2dceb20  vmovaps xmm6, [rsp+0x50]
00007cbcc2dceb26  vmovaps xmm7, [rsp+0x60]
00007cbcc2dceb2c  vmovaps xmm8, [rsp+0x70]
00007cbcc2dceb32  vmovaps xmm9, [rsp+0x80]
00007cbcc2dceb3b  vmovaps xmm10, [rsp+0x90]
00007cbcc2dceb44  vmovaps xmm11, [rsp+0xA0]
00007cbcc2dceb4d  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dceb56  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dceb5f  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dceb68  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dceb71  add rsp, 0xF0
00007cbcc2dceb78  pop r11
00007cbcc2dceb7a  pop r10
00007cbcc2dceb7c  pop r9
00007cbcc2dceb7e  pop r8
00007cbcc2dceb80  pop rsi
00007cbcc2dceb81  pop rdi
00007cbcc2dceb82  pop rdx
00007cbcc2dceb83  pop rcx
00007cbcc2dceb84  pop rax
00007cbcc2dceb85  add rsp, 0x08
00007cbcc2dceb89  jmp 0x00007CBCC2DCE848
00007cbcc2dceb8e  call 0x00007CBCC2BFF540
00007cbcc2dceb93  jmp 0x00007CBCC2DCE85B
00007cbcc2dceb98  int3
00007cbcc2dceb99  nop [rax], eax
00007cbcc2dceba0  movaps xmm1, [r15+0x180]
00007cbcc2dceba8  vpmovqd xmm15, xmm1
00007cbcc2dcebae  pxor xmm14, xmm14
00007cbcc2dcebb3  punpcklqdq xmm15, xmm14
00007cbcc2dcebb8  movaps [r15+0x210], xmm15
00007cbcc2dcebc0  movq xmm15, qword ptr [r15+0x120]
00007cbcc2dcebc9  movq xmm14, qword ptr [r15+0x130]
00007cbcc2dcebd2  psubd xmm15, xmm14
00007cbcc2dcebd7  movq xmm15, xmm15
00007cbcc2dcebdc  movaps xmm13, [r15+0x170]
00007cbcc2dcebe4  paddq xmm1, xmm13
00007cbcc2dcebe9  movaps [r15+0x180], xmm1
00007cbcc2dcebf1  movq xmm1, qword ptr [r15+0x150]
00007cbcc2dcebfa  paddd xmm14, xmm1
00007cbcc2dcebff  movq xmm14, xmm14
00007cbcc2dcec04  movq xmm14, xmm14
00007cbcc2dcec09  movaps [r15+0x130], xmm14
00007cbcc2dcec11  pmovzxdq xmm15, xmm15
00007cbcc2dcec17  psllq xmm15, 0x00
00007cbcc2dcec1d  movq xmm1, qword ptr [r15+0x210]
00007cbcc2dcec26  movq xmm14, qword ptr [r15+0x110]
00007cbcc2dcec2f  paddd xmm1, xmm14
00007cbcc2dcec34  movq xmm1, xmm1
00007cbcc2dcec38  vcvtuqq2pd xmm15, xmm15
00007cbcc2dcec3e  pmovzxdq xmm1, xmm1
00007cbcc2dcec43  psllq xmm1, 0x00
00007cbcc2dcec48  vcvtuqq2pd xmm1, xmm1
00007cbcc2dcec4e  movaps xmm14, [r15+0x140]
00007cbcc2dcec56  movaps xmm13, xmm15
00007cbcc2dcec5a  mulpd xmm13, xmm14
00007cbcc2dcec5f  vcmppd xmm12, xmm13, xmm13, 0x03
00007cbcc2dcec65  ptest xmm12, xmm12
00007cbcc2dcec6b  jnz 0x00007CBCC2DCED4E
00007cbcc2dcec71  movaps [r15+0x220], xmm13
00007cbcc2dcec79  mov rax, [r15+0x48]
00007cbcc2dcec7d  mov r14, [r15+0x50]
00007cbcc2dcec81  lea r12, [r14+rax*1]
00007cbcc2dcec85  movups [r13+r12*1], xmm13
00007cbcc2dcec8b  movaps xmm15, [r15+0x160]
00007cbcc2dcec93  movaps xmm14, xmm1
00007cbcc2dcec97  mulpd xmm14, xmm15
00007cbcc2dcec9c  vcmppd xmm13, xmm14, xmm14, 0x03
00007cbcc2dceca2  ptest xmm13, xmm13
00007cbcc2dceca8  jnz 0x00007CBCC2DCEE9C
00007cbcc2dcecae  movaps [r15+0x210], xmm14
00007cbcc2dcecb6  mov r14, [r15+0x40]
00007cbcc2dcecba  lea r12, [r14+rax*1]
00007cbcc2dcecbe  movups [r13+r12*1], xmm14
00007cbcc2dcecc4  lea r14, [rax+0x10]
00007cbcc2dcecc8  mov [r15+0x48], r14
00007cbcc2dceccc  xor eax, eax
00007cbcc2dcecce  mov r12d, 0x200
00007cbcc2dcecd4  cmp r14, r12
00007cbcc2dcecd7  cmc
00007cbcc2dcecd8  lahf
00007cbcc2dcecd9  seto al
00007cbcc2dcecdc  mov [r15+0x108], eax
00007cbcc2dcece3  mov eax, [r15+0x108]
00007cbcc2dcecea  sahf
00007cbcc2dceceb  jnz 0x00007CBCC2DCED1D
00007cbcc2dceced  cmp dword ptr [r15+0x318], 0x00
00007cbcc2dcecf5  jz 0x00007CBCC2DCEFF0
00007cbcc2dcecfb  nop [rax+rax*1], ax
00007cbcc2dced04  nop [rax+rax*1], eax
00007cbcc2dced0c  mov eax, 0x4101EC
00007cbcc2dced11  mov [r15+0x100], rax
00007cbcc2dced18  jmp 0x00007CBCC2BFE110
00007cbcc2dced1d  cmp dword ptr [r15+0x318], 0x00
00007cbcc2dced25  jz 0x00007CBCC2DCEBA0
00007cbcc2dced2b  nop [rax+rax*1], ax
00007cbcc2dced34  nop [rax+rax*1], eax
00007cbcc2dced3c  mov eax, 0x4101AC
00007cbcc2dced41  mov [r15+0x100], rax
00007cbcc2dced48  jmp 0x00007CBCC2BFE110
00007cbcc2dced4d  int3
00007cbcc2dced4e  sub rsp, 0x08
00007cbcc2dced52  push rax
00007cbcc2dced53  push rcx
00007cbcc2dced54  push rdx
00007cbcc2dced55  push rdi
00007cbcc2dced56  push rsi
00007cbcc2dced57  push r8
00007cbcc2dced59  push r9
00007cbcc2dced5b  push r10
00007cbcc2dced5d  push r11
00007cbcc2dced5f  sub rsp, 0xF0
00007cbcc2dced66  vmovaps [rsp], xmm0
00007cbcc2dced6b  vmovaps [rsp+0x10], xmm1
00007cbcc2dced71  vmovaps [rsp+0x20], xmm2
00007cbcc2dced77  vmovaps [rsp+0x30], xmm3
00007cbcc2dced7d  vmovaps [rsp+0x40], xmm4
00007cbcc2dced83  vmovaps [rsp+0x50], xmm5
00007cbcc2dced89  vmovaps [rsp+0x60], xmm6
00007cbcc2dced8f  vmovaps [rsp+0x70], xmm7
00007cbcc2dced95  vmovaps [rsp+0x80], xmm8
00007cbcc2dced9e  vmovaps [rsp+0x90], xmm9
00007cbcc2dceda7  vmovaps [rsp+0xA0], xmm10
00007cbcc2dcedb0  vmovaps [rsp+0xB0], xmm11
00007cbcc2dcedb9  vmovaps [rsp+0xC0], xmm12
00007cbcc2dcedc2  vmovaps [rsp+0xD0], xmm14
00007cbcc2dcedcb  vmovaps [rsp+0xE0], xmm15
00007cbcc2dcedd4  sub rsp, 0x30
00007cbcc2dcedd8  movaps [rsp], xmm13
00007cbcc2dceddd  movaps [rsp+0x10], xmm15
00007cbcc2dcede3  movaps [rsp+0x20], xmm14
00007cbcc2dcede9  lea rdi, [rsp]
00007cbcc2dceded  mov esi, 0x00
00007cbcc2dcedf2  mov rax, 0x5BFE0F0EE530
00007cbcc2dcedfc  call rax
00007cbcc2dcedfe  movaps xmm13, [rsp]
00007cbcc2dcee03  add rsp, 0x30
00007cbcc2dcee07  vmovaps xmm0, [rsp]
00007cbcc2dcee0c  vmovaps xmm1, [rsp+0x10]
00007cbcc2dcee12  vmovaps xmm2, [rsp+0x20]
00007cbcc2dcee18  vmovaps xmm3, [rsp+0x30]
00007cbcc2dcee1e  vmovaps xmm4, [rsp+0x40]
00007cbcc2dcee24  vmovaps xmm5, [rsp+0x50]
00007cbcc2dcee2a  vmovaps xmm6, [rsp+0x60]
00007cbcc2dcee30  vmovaps xmm7, [rsp+0x70]
00007cbcc2dcee36  vmovaps xmm8, [rsp+0x80]
00007cbcc2dcee3f  vmovaps xmm9, [rsp+0x90]
00007cbcc2dcee48  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dcee51  vmovaps xmm11, [rsp+0xB0]
00007cbcc2dcee5a  vmovaps xmm12, [rsp+0xC0]
00007cbcc2dcee63  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dcee6c  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dcee75  add rsp, 0xF0
00007cbcc2dcee7c  pop r11
00007cbcc2dcee7e  pop r10
00007cbcc2dcee80  pop r9
00007cbcc2dcee82  pop r8
00007cbcc2dcee84  pop rsi
00007cbcc2dcee85  pop rdi
00007cbcc2dcee86  pop rdx
00007cbcc2dcee87  pop rcx
00007cbcc2dcee88  pop rax
00007cbcc2dcee89  add rsp, 0x08
00007cbcc2dcee8d  jmp 0x00007CBCC2DCEC71
00007cbcc2dcee92  call 0x00007CBCC2CC2240
00007cbcc2dcee97  jmp 0x00007CBCC2DCEC8B
00007cbcc2dcee9c  sub rsp, 0x08
00007cbcc2dceea0  push rax
00007cbcc2dceea1  push rcx
00007cbcc2dceea2  push rdx
00007cbcc2dceea3  push rdi
00007cbcc2dceea4  push rsi
00007cbcc2dceea5  push r8
00007cbcc2dceea7  push r9
00007cbcc2dceea9  push r10
00007cbcc2dceeab  push r11
00007cbcc2dceead  sub rsp, 0xF0
00007cbcc2dceeb4  vmovaps [rsp], xmm0
00007cbcc2dceeb9  vmovaps [rsp+0x10], xmm1
00007cbcc2dceebf  vmovaps [rsp+0x20], xmm2
00007cbcc2dceec5  vmovaps [rsp+0x30], xmm3
00007cbcc2dceecb  vmovaps [rsp+0x40], xmm4
00007cbcc2dceed1  vmovaps [rsp+0x50], xmm5
00007cbcc2dceed7  vmovaps [rsp+0x60], xmm6
00007cbcc2dceedd  vmovaps [rsp+0x70], xmm7
00007cbcc2dceee3  vmovaps [rsp+0x80], xmm8
00007cbcc2dceeec  vmovaps [rsp+0x90], xmm9
00007cbcc2dceef5  vmovaps [rsp+0xA0], xmm10
00007cbcc2dceefe  vmovaps [rsp+0xB0], xmm11
00007cbcc2dcef07  vmovaps [rsp+0xC0], xmm12
00007cbcc2dcef10  vmovaps [rsp+0xD0], xmm13
00007cbcc2dcef19  vmovaps [rsp+0xE0], xmm15
00007cbcc2dcef22  sub rsp, 0x30
00007cbcc2dcef26  movaps [rsp], xmm14
00007cbcc2dcef2b  movaps [rsp+0x10], xmm1
00007cbcc2dcef30  movaps [rsp+0x20], xmm15
00007cbcc2dcef36  lea rdi, [rsp]
00007cbcc2dcef3a  mov esi, 0x00
00007cbcc2dcef3f  mov rax, 0x5BFE0F0EE530
00007cbcc2dcef49  call rax
00007cbcc2dcef4b  movaps xmm14, [rsp]
00007cbcc2dcef50  add rsp, 0x30
00007cbcc2dcef54  vmovaps xmm0, [rsp]
00007cbcc2dcef59  vmovaps xmm1, [rsp+0x10]
00007cbcc2dcef5f  vmovaps xmm2, [rsp+0x20]
00007cbcc2dcef65  vmovaps xmm3, [rsp+0x30]
00007cbcc2dcef6b  vmovaps xmm4, [rsp+0x40]
00007cbcc2dcef71  vmovaps xmm5, [rsp+0x50]
00007cbcc2dcef77  vmovaps xmm6, [rsp+0x60]
00007cbcc2dcef7d  vmovaps xmm7, [rsp+0x70]
00007cbcc2dcef83  vmovaps xmm8, [rsp+0x80]
00007cbcc2dcef8c  vmovaps xmm9, [rsp+0x90]
00007cbcc2dcef95  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dcef9e  vmovaps xmm11, [rsp+0xB0]
00007cbcc2dcefa7  vmovaps xmm12, [rsp+0xC0]
00007cbcc2dcefb0  vmovaps xmm13, [rsp+0xD0]
00007cbcc2dcefb9  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dcefc2  add rsp, 0xF0
00007cbcc2dcefc9  pop r11
00007cbcc2dcefcb  pop r10
00007cbcc2dcefcd  pop r9
00007cbcc2dcefcf  pop r8
00007cbcc2dcefd1  pop rsi
00007cbcc2dcefd2  pop rdi
00007cbcc2dcefd3  pop rdx
00007cbcc2dcefd4  pop rcx
00007cbcc2dcefd5  pop rax
00007cbcc2dcefd6  add rsp, 0x08
00007cbcc2dcefda  jmp 0x00007CBCC2DCECAE
00007cbcc2dcefdf  call 0x00007CBCC2CC34C0
00007cbcc2dcefe4  jmp 0x00007CBCC2DCECC4
00007cbcc2dcefe9  int3
00007cbcc2dcefea  nop [rax+rax*1], ax
00007cbcc2dceff0  mov rax, [r15+0xF8]
00007cbcc2dceff7  lea r14, [rax-0x120]
00007cbcc2dceffe  mov [r15+0xF8], r14
00007cbcc2dcf005  mov rax, [r15+0x50]
00007cbcc2dcf009  movups xmm1, [r13+rax*1]
00007cbcc2dcf00f  lea r12, [rax+0x10]
00007cbcc2dcf013  movups xmm15, [r13+r12*1]
00007cbcc2dcf019  mov qword ptr [r15+0x48], 0x00
00007cbcc2dcf021  lea r12, [r14+0xD0]
00007cbcc2dcf028  movq xmm14, qword ptr [r15+0x200]
00007cbcc2dcf031  movq xmm13, qword ptr [r15+0x1F0]
00007cbcc2dcf03a  movq r11, xmm14
00007cbcc2dcf03f  movq r10, xmm13
00007cbcc2dcf044  mov [r13+r12*1], r11
00007cbcc2dcf049  lea r12, [r14+0xD8]
00007cbcc2dcf050  mov [r13+r12*1], r10
00007cbcc2dcf055  lea r12, [rax+0x80]
00007cbcc2dcf05c  movups xmm14, [r13+r12*1]
00007cbcc2dcf062  lea r12, [rax+0x90]
00007cbcc2dcf069  movups xmm13, [r13+r12*1]
00007cbcc2dcf06f  lea r12, [r14+0xE0]
00007cbcc2dcf076  movq xmm12, qword ptr [r15+0x1E0]
00007cbcc2dcf07f  movq xmm11, qword ptr [r15+0x1D0]
00007cbcc2dcf088  movq r11, xmm12
00007cbcc2dcf08d  movq r10, xmm11
00007cbcc2dcf092  mov [r13+r12*1], r11
00007cbcc2dcf097  lea r12, [r14+0xE8]
00007cbcc2dcf09e  mov [r13+r12*1], r10
00007cbcc2dcf0a3  lea r12, [rax+0xC0]
00007cbcc2dcf0aa  movups xmm12, [r13+r12*1]
00007cbcc2dcf0b0  lea r12, [rax+0xD0]
00007cbcc2dcf0b7  movups xmm11, [r13+r12*1]
00007cbcc2dcf0bd  movups [r13+r14*1], xmm1
00007cbcc2dcf0c3  lea r12, [rax+0x20]
00007cbcc2dcf0c7  movups xmm1, [r13+r12*1]
00007cbcc2dcf0cd  lea r12, [rax+0x30]
00007cbcc2dcf0d1  movups xmm10, [r13+r12*1]
00007cbcc2dcf0d7  lea r12, [r14+0xF0]
00007cbcc2dcf0de  movq xmm9, qword ptr [r15+0x1C0]
00007cbcc2dcf0e7  movq xmm8, qword ptr [r15+0x1B0]
00007cbcc2dcf0f0  movq r11, xmm9
00007cbcc2dcf0f5  movq r10, xmm8
00007cbcc2dcf0fa  mov [r13+r12*1], r11
00007cbcc2dcf0ff  lea r12, [r14+0xF8]
00007cbcc2dcf106  mov [r13+r12*1], r10
00007cbcc2dcf10b  lea r12, [rax+0x40]
00007cbcc2dcf10f  movups xmm9, [r13+r12*1]
00007cbcc2dcf115  lea r12, [rax+0x50]
00007cbcc2dcf119  movups xmm8, [r13+r12*1]
00007cbcc2dcf11f  lea r12, [r14+0x100]
00007cbcc2dcf126  movq xmm7, qword ptr [r15+0x1A0]
00007cbcc2dcf12f  movq xmm6, qword ptr [r15+0x190]
00007cbcc2dcf138  movq r11, xmm7
00007cbcc2dcf13d  movq r10, xmm6
00007cbcc2dcf142  mov [r13+r12*1], r11
00007cbcc2dcf147  lea r12, [r14+0x108]
00007cbcc2dcf14e  mov [r13+r12*1], r10
00007cbcc2dcf153  lea r12, [rax+0x100]
00007cbcc2dcf15a  movups xmm7, [r13+r12*1]
00007cbcc2dcf160  lea r12, [rax+0x110]
00007cbcc2dcf167  movups xmm6, [r13+r12*1]
00007cbcc2dcf16d  lea r12, [r14+0xB0]
00007cbcc2dcf174  movups [r13+r12*1], xmm10
00007cbcc2dcf17a  lea r12, [r14+0xC0]
00007cbcc2dcf181  movups [r13+r12*1], xmm1
00007cbcc2dcf187  lea r12, [rax+0x140]
00007cbcc2dcf18e  movups xmm1, [r13+r12*1]
00007cbcc2dcf194  lea r12, [rax+0x150]
00007cbcc2dcf19b  movups xmm10, [r13+r12*1]
00007cbcc2dcf1a1  lea r12, [r14+0x110]
00007cbcc2dcf1a8  mov r11, [r15+0xE8]
00007cbcc2dcf1af  mov [r13+r12*1], r11
00007cbcc2dcf1b4  lea r12, [rax+0x180]
00007cbcc2dcf1bb  movups xmm5, [r13+r12*1]
00007cbcc2dcf1c1  lea r12, [rax+0x190]
00007cbcc2dcf1c8  movups xmm4, [r13+r12*1]
00007cbcc2dcf1ce  lea r12, [rax+0x1C0]
00007cbcc2dcf1d5  movups xmm3, [r13+r12*1]
00007cbcc2dcf1db  lea r12, [rax+0x1D0]
00007cbcc2dcf1e2  movups xmm2, [r13+r12*1]
00007cbcc2dcf1e8  lea r12, [rax+0x60]
00007cbcc2dcf1ec  vmovaps [rsp+0x10], xmm1
00007cbcc2dcf1f2  movups xmm1, [r13+r12*1]
00007cbcc2dcf1f8  lea r12, [rax+0x70]
00007cbcc2dcf1fc  vmovaps [rsp+0x20], xmm1
00007cbcc2dcf202  movups xmm1, [r13+r12*1]
00007cbcc2dcf208  lea r12, [r14+0x70]
00007cbcc2dcf20c  movups [r13+r12*1], xmm4
00007cbcc2dcf212  lea r12, [r14+0x80]
00007cbcc2dcf219  movups [r13+r12*1], xmm5
00007cbcc2dcf21f  lea r12, [rax+0xA0]
00007cbcc2dcf226  movups xmm5, [r13+r12*1]
00007cbcc2dcf22c  lea r12, [rax+0xB0]
00007cbcc2dcf233  movups xmm4, [r13+r12*1]
00007cbcc2dcf239  lea r12, [r14+0x90]
00007cbcc2dcf240  movups [r13+r12*1], xmm2
00007cbcc2dcf246  lea r12, [r14+0xA0]
00007cbcc2dcf24d  movups [r13+r12*1], xmm3
00007cbcc2dcf253  lea r12, [rax+0xE0]
00007cbcc2dcf25a  movups xmm3, [r13+r12*1]
00007cbcc2dcf260  lea r12, [rax+0xF0]
00007cbcc2dcf267  movups xmm2, [r13+r12*1]
00007cbcc2dcf26d  lea r12, [rax+0x120]
00007cbcc2dcf274  vmovaps [rsp+0x30], xmm1
00007cbcc2dcf27a  movups xmm1, [r13+r12*1]
00007cbcc2dcf280  lea r12, [rax+0x130]
00007cbcc2dcf287  vmovaps [rsp+0x40], xmm1
00007cbcc2dcf28d  movups xmm1, [r13+r12*1]
00007cbcc2dcf293  lea r12, [rax+0x160]
00007cbcc2dcf29a  vmovaps [rsp+0x50], xmm1
00007cbcc2dcf2a0  movups xmm1, [r13+r12*1]
00007cbcc2dcf2a6  lea r12, [rax+0x170]
00007cbcc2dcf2ad  vmovaps [rsp+0x60], xmm1
00007cbcc2dcf2b3  movups xmm1, [r13+r12*1]
00007cbcc2dcf2b9  lea r12, [rax+0x1A0]
00007cbcc2dcf2c0  vmovaps [rsp+0x70], xmm1
00007cbcc2dcf2c6  movups xmm1, [r13+r12*1]
00007cbcc2dcf2cc  lea r12, [rax+0x1B0]
00007cbcc2dcf2d3  vmovaps [rsp+0x80], xmm1
00007cbcc2dcf2dc  movups xmm1, [r13+r12*1]
00007cbcc2dcf2e2  lea r12, [rax+0x1E0]
00007cbcc2dcf2e9  vmovaps [rsp+0x90], xmm1
00007cbcc2dcf2f2  movups xmm1, [r13+r12*1]
00007cbcc2dcf2f8  lea r12, [rax+0x1F0]
00007cbcc2dcf2ff  vmovaps [rsp+0xA0], xmm1
00007cbcc2dcf308  movups xmm1, [r13+r12*1]
00007cbcc2dcf30e  mov qword ptr [r15+0x50], 0x4308D0
00007cbcc2dcf316  lea rax, [r14+0x50]
00007cbcc2dcf31a  vmovaps [rsp+0xB0], xmm1
00007cbcc2dcf323  vmovaps xmm1, [rsp+0x60]
00007cbcc2dcf329  movups [r13+rax*1], xmm1
00007cbcc2dcf32f  lea rax, [r14+0x60]
00007cbcc2dcf333  vmovaps xmm1, [rsp+0x10]
00007cbcc2dcf339  movups [r13+rax*1], xmm1
00007cbcc2dcf33f  lea rax, [r14+0x40]
00007cbcc2dcf343  vmovaps xmm1, [rsp+0x70]
00007cbcc2dcf349  movups [r13+rax*1], xmm1
00007cbcc2dcf34f  lea rax, [r14+0x20]
00007cbcc2dcf353  vmovaps xmm1, [rsp+0xA0]
00007cbcc2dcf35c  movups [r13+rax*1], xmm1
00007cbcc2dcf362  lea rax, [r14+0x30]
00007cbcc2dcf366  vmovaps xmm1, [rsp+0x90]
00007cbcc2dcf36f  movups [r13+rax*1], xmm1
00007cbcc2dcf375  lea rax, [r14+0x10]
00007cbcc2dcf379  vmovaps xmm1, [rsp+0xB0]
00007cbcc2dcf382  movups [r13+rax*1], xmm1
00007cbcc2dcf388  mov rax, [r15+0x40]
00007cbcc2dcf38c  vxorps xmm1, xmm1, xmm1
00007cbcc2dcf390  vpbroadcastq xmm1, xmm1
00007cbcc2dcf395  vmovaps [rsp+0x10], xmm1
00007cbcc2dcf39b  vxorps xmm1, xmm1, xmm1
00007cbcc2dcf39f  vpbroadcastq xmm1, xmm1
00007cbcc2dcf3a4  lea r12, [rax+0x30]
00007cbcc2dcf3a8  mov r11, [r13+r12*1]
00007cbcc2dcf3ad  lea r12, [rax+0x38]
00007cbcc2dcf3b1  mov r10, [r13+r12*1]
00007cbcc2dcf3b6  vmovaps [rsp+0x60], xmm1
00007cbcc2dcf3bc  movq xmm1, r11
00007cbcc2dcf3c1  vmovaps [rsp+0x70], xmm1
00007cbcc2dcf3c7  movq xmm1, r10
00007cbcc2dcf3cc  vmovaps [rsp+0x90], xmm1
00007cbcc2dcf3d5  vmovaps xmm1, [rsp+0x70]
00007cbcc2dcf3db  movq xmm1, xmm1
00007cbcc2dcf3df  vmovaps [rsp+0x70], xmm1
00007cbcc2dcf3e5  vmovaps xmm1, [rsp+0x90]
00007cbcc2dcf3ee  movq xmm1, xmm1
00007cbcc2dcf3f2  vmovaps [rsp+0x90], xmm1
00007cbcc2dcf3fb  movq xmm1, xmm1
00007cbcc2dcf3ff  movaps [r15+0x270], xmm1
00007cbcc2dcf407  vmovaps [rsp+0xA0], xmm7
00007cbcc2dcf410  vmovaps xmm1, [rsp+0xA0]
00007cbcc2dcf419  por xmm7, xmm1
00007cbcc2dcf41d  lea r12, [rax+0x20]
00007cbcc2dcf421  mov r11, [r13+r12*1]
00007cbcc2dcf426  lea r12, [rax+0x28]
00007cbcc2dcf42a  mov r10, [r13+r12*1]
00007cbcc2dcf42f  movq xmm1, r11
00007cbcc2dcf434  vmovaps [rsp+0xA0], xmm1
00007cbcc2dcf43d  movq xmm1, r10
00007cbcc2dcf442  vmovaps [rsp+0xB0], xmm1
00007cbcc2dcf44b  vmovaps xmm1, [rsp+0xA0]
00007cbcc2dcf454  movq xmm1, xmm1
00007cbcc2dcf458  vmovaps [rsp+0xA0], xmm1
00007cbcc2dcf461  vmovaps xmm1, [rsp+0xB0]
00007cbcc2dcf46a  movq xmm1, xmm1
00007cbcc2dcf46e  vmovaps [rsp+0xB0], xmm2
00007cbcc2dcf477  vmovaps [rsp+0xC0], xmm1
00007cbcc2dcf480  vmovaps xmm1, [rsp+0xB0]
00007cbcc2dcf489  por xmm2, xmm1
00007cbcc2dcf48d  vmovaps xmm1, [rsp+0x40]
00007cbcc2dcf493  vmovaps [rsp+0xB0], xmm15
00007cbcc2dcf49c  vmovaps xmm15, [rsp+0x40]
00007cbcc2dcf4a2  por xmm1, xmm15
00007cbcc2dcf4a7  vmovaps [rsp+0x40], xmm3
00007cbcc2dcf4ad  vmovaps xmm15, [rsp+0x40]
00007cbcc2dcf4b3  por xmm3, xmm15
00007cbcc2dcf4b8  vmovaps [rsp+0x40], xmm10
00007cbcc2dcf4be  vmovaps xmm15, [rsp+0x40]
00007cbcc2dcf4c4  por xmm10, xmm15
00007cbcc2dcf4c9  vmovaps [rsp+0x40], xmm12
00007cbcc2dcf4cf  vmovaps xmm15, [rsp+0x40]
00007cbcc2dcf4d5  por xmm12, xmm15
00007cbcc2dcf4da  lea r12, [rax+0x10]
00007cbcc2dcf4de  mov r11, [r13+r12*1]
00007cbcc2dcf4e3  lea r12, [rax+0x18]
00007cbcc2dcf4e7  mov r10, [r13+r12*1]
00007cbcc2dcf4ec  movq xmm15, r11
00007cbcc2dcf4f1  vmovaps [rsp+0x40], xmm1
00007cbcc2dcf4f7  movq xmm1, r10
00007cbcc2dcf4fc  movq xmm15, xmm15
00007cbcc2dcf501  movq xmm1, xmm1
00007cbcc2dcf505  vmovaps [rsp+0xD0], xmm1
00007cbcc2dcf50e  vmovaps xmm1, [rsp+0x80]
00007cbcc2dcf517  vmovaps [rsp+0xE0], xmm15
00007cbcc2dcf520  vmovaps xmm15, [rsp+0x80]
00007cbcc2dcf529  por xmm1, xmm15
00007cbcc2dcf52e  vmovaps xmm15, [rsp+0x30]
00007cbcc2dcf534  vmovaps [rsp+0x80], xmm1
00007cbcc2dcf53d  vmovaps xmm1, [rsp+0x30]
00007cbcc2dcf543  por xmm15, xmm1
00007cbcc2dcf548  vmovaps xmm1, [rsp+0x20]
00007cbcc2dcf54e  vmovaps [rsp+0x30], xmm15
00007cbcc2dcf554  vmovaps xmm15, [rsp+0x20]
00007cbcc2dcf55a  por xmm1, xmm15
00007cbcc2dcf55f  vmovaps [rsp+0x20], xmm6
00007cbcc2dcf565  vmovaps xmm15, [rsp+0x20]
00007cbcc2dcf56b  por xmm6, xmm15
00007cbcc2dcf570  vmovaps [rsp+0x20], xmm13
00007cbcc2dcf576  vmovaps xmm15, [rsp+0x20]
00007cbcc2dcf57c  por xmm13, xmm15
00007cbcc2dcf581  vmovaps [rsp+0x20], xmm8
00007cbcc2dcf587  vmovaps xmm15, [rsp+0x20]
00007cbcc2dcf58d  por xmm8, xmm15
00007cbcc2dcf592  vmovaps [rsp+0x20], xmm9
00007cbcc2dcf598  vmovaps xmm15, [rsp+0x20]
00007cbcc2dcf59e  por xmm9, xmm15
00007cbcc2dcf5a3  mov r12, [r13+rax*1]
00007cbcc2dcf5a8  vmovq xmm15, r12
00007cbcc2dcf5ad  vpbroadcastq xmm15, xmm15
00007cbcc2dcf5b2  vmovaps [rsp+0x20], xmm1
00007cbcc2dcf5b8  vxorps xmm1, xmm1, xmm1
00007cbcc2dcf5bc  vpbroadcastq xmm1, xmm1
00007cbcc2dcf5c1  vmovaps [rsp+0xF0], xmm1
00007cbcc2dcf5ca  movups xmm1, [r13+r14*1]
00007cbcc2dcf5d0  vmovaps [rsp+0x100], xmm1
00007cbcc2dcf5d9  vxorps xmm1, xmm1, xmm1
00007cbcc2dcf5dd  vpbroadcastq xmm1, xmm1
00007cbcc2dcf5e2  lea r12, [rax+0x08]
00007cbcc2dcf5e6  mov rax, [r13+r12*1]
00007cbcc2dcf5eb  vmovaps [rsp+0x110], xmm1
00007cbcc2dcf5f4  movq xmm1, rax
00007cbcc2dcf5f9  movaps [r15+0x240], xmm1
00007cbcc2dcf601  mov qword ptr [r15+0x60], 0x4308D0
00007cbcc2dcf609  mov qword ptr [r15+0x58], 0x40
00007cbcc2dcf611  vmovaps xmm1, [rsp+0x10]
00007cbcc2dcf617  vmovaps [rsp+0x10], xmm15
00007cbcc2dcf61d  vmovaps xmm15, [rsp+0x100]
00007cbcc2dcf626  vmovaps [rsp+0x100], xmm14
00007cbcc2dcf62f  vmovaps xmm14, [rsp+0x10]
00007cbcc2dcf635  vmovaps [rsp+0x10], xmm13
00007cbcc2dcf63b  vmovaps [rsp+0x120], xmm12
00007cbcc2dcf644  movaps xmm13, xmm1
00007cbcc2dcf648  vfmadd231pd xmm13, xmm15, xmm14
00007cbcc2dcf64d  vcmppd xmm12, xmm13, xmm13, 0x03
00007cbcc2dcf653  vptest xmm12, xmm12
00007cbcc2dcf658  jnz 0x00007CBCC2DD0283
00007cbcc2dcf65e  vmovaps xmm1, [rsp+0x60]
00007cbcc2dcf664  vmovaps xmm15, [rsp+0xB0]
00007cbcc2dcf66d  vmovaps [rsp+0x60], xmm13
00007cbcc2dcf673  movaps xmm12, xmm1
00007cbcc2dcf677  vfmadd231pd xmm12, xmm15, xmm14
00007cbcc2dcf67c  vcmppd xmm13, xmm12, xmm12, 0x03
00007cbcc2dcf682  vptest xmm13, xmm13
00007cbcc2dcf687  jnz 0x00007CBCC2DD03DC
00007cbcc2dcf68d  vmovaps xmm1, [rsp+0x50]
00007cbcc2dcf693  vmovaps xmm13, [rsp+0x50]
00007cbcc2dcf699  por xmm1, xmm13
00007cbcc2dcf69e  vmovaps [rsp+0x50], xmm4
00007cbcc2dcf6a4  vmovaps xmm13, [rsp+0x50]
00007cbcc2dcf6aa  por xmm4, xmm13
00007cbcc2dcf6af  vmovaps [rsp+0x50], xmm5
00007cbcc2dcf6b5  vmovaps xmm13, [rsp+0x50]
00007cbcc2dcf6bb  por xmm5, xmm13
00007cbcc2dcf6c0  vmovaps [rsp+0x50], xmm11
00007cbcc2dcf6c6  vmovaps xmm13, [rsp+0x50]
00007cbcc2dcf6cc  por xmm11, xmm13
00007cbcc2dcf6d1  vmovaps xmm13, [rsp+0x100]
00007cbcc2dcf6da  vmovaps [rsp+0x50], xmm1
00007cbcc2dcf6e0  vmovaps xmm1, [rsp+0x100]
00007cbcc2dcf6e9  por xmm13, xmm1
00007cbcc2dcf6ee  vmovaps [rsp+0xB0], xmm15
00007cbcc2dcf6f7  vmovaps xmm1, [rsp+0xB0]
00007cbcc2dcf700  por xmm15, xmm1
00007cbcc2dcf705  lea rax, [r14+0xC0]
00007cbcc2dcf70c  movups xmm1, [r13+rax*1]
00007cbcc2dcf712  xor eax, eax
00007cbcc2dcf714  mov r12d, 0x40
00007cbcc2dcf71a  mov r11d, 0x200
00007cbcc2dcf720  cmp r12, r11
00007cbcc2dcf723  cmc
00007cbcc2dcf724  lahf
00007cbcc2dcf725  seto al
00007cbcc2dcf728  mov [r15+0x108], eax
00007cbcc2dcf72f  vmovaps [rsp+0xB0], xmm1
00007cbcc2dcf738  vmovaps xmm1, [rsp+0xF0]
00007cbcc2dcf741  vmovaps [rsp+0xF0], xmm15
00007cbcc2dcf74a  vmovaps xmm15, [rsp+0xB0]
00007cbcc2dcf753  vmovaps [rsp+0xB0], xmm13
00007cbcc2dcf75c  vmovaps [rsp+0x100], xmm12
00007cbcc2dcf765  movaps xmm13, xmm1
00007cbcc2dcf769  vfmadd231pd xmm13, xmm15, xmm14
00007cbcc2dcf76e  vcmppd xmm12, xmm13, xmm13, 0x03
00007cbcc2dcf774  vptest xmm12, xmm12
00007cbcc2dcf779  jnz 0x00007CBCC2DD053F
00007cbcc2dcf77f  lea rax, [r14+0xB0]
00007cbcc2dcf786  movups xmm1, [r13+rax*1]
00007cbcc2dcf78c  vmovaps xmm15, [rsp+0x110]
00007cbcc2dcf795  vmovaps [rsp+0x110], xmm13
00007cbcc2dcf79e  movaps xmm12, xmm15
00007cbcc2dcf7a2  vfmadd231pd xmm12, xmm1, xmm14
00007cbcc2dcf7a7  vcmppd xmm13, xmm12, xmm12, 0x03
00007cbcc2dcf7ad  vptest xmm13, xmm13
00007cbcc2dcf7b2  jnz 0x00007CBCC2DD06A2
00007cbcc2dcf7b8  vmovaps [rsp+0x130], xmm9
00007cbcc2dcf7c1  vmovaps xmm1, [rsp+0x130]
00007cbcc2dcf7ca  por xmm9, xmm1
00007cbcc2dcf7cf  movaps [r15+0x210], xmm9
00007cbcc2dcf7d7  vmovaps [rsp+0x130], xmm8
00007cbcc2dcf7e0  vmovaps xmm1, [rsp+0x130]
00007cbcc2dcf7e9  por xmm8, xmm1
00007cbcc2dcf7ee  movaps [r15+0x1C0], xmm8
00007cbcc2dcf7f6  vmovaps xmm1, [rsp+0x10]
00007cbcc2dcf7fc  vmovaps xmm15, [rsp+0x10]
00007cbcc2dcf802  por xmm1, xmm15
00007cbcc2dcf807  movaps [r15+0x280], xmm1
00007cbcc2dcf80f  vmovaps [rsp+0x10], xmm6
00007cbcc2dcf815  vmovaps xmm14, [rsp+0x10]
00007cbcc2dcf81b  por xmm6, xmm14
00007cbcc2dcf820  movaps [r15+0x2A0], xmm6
00007cbcc2dcf828  vmovaps xmm15, [rsp+0x20]
00007cbcc2dcf82e  vmovaps xmm14, [rsp+0x20]
00007cbcc2dcf834  por xmm15, xmm14
00007cbcc2dcf839  movaps [r15+0x2E0], xmm15
00007cbcc2dcf841  vmovaps xmm14, [rsp+0x30]
00007cbcc2dcf847  vmovaps xmm13, [rsp+0x30]
00007cbcc2dcf84d  por xmm14, xmm13
00007cbcc2dcf852  movaps [r15+0x1F0], xmm14
00007cbcc2dcf85a  vmovaps xmm13, [rsp+0xF0]
00007cbcc2dcf863  vmovaps [rsp+0x10], xmm1
00007cbcc2dcf869  vmovaps xmm1, [rsp+0xF0]
00007cbcc2dcf872  por xmm13, xmm1
00007cbcc2dcf877  movaps [r15+0x250], xmm13
00007cbcc2dcf87f  vmovaps xmm1, [rsp+0xB0]
00007cbcc2dcf888  vmovaps xmm13, [rsp+0xB0]
00007cbcc2dcf891  por xmm1, xmm13
00007cbcc2dcf896  movaps [r15+0x260], xmm1
00007cbcc2dcf89e  vmovaps [rsp+0x20], xmm11
00007cbcc2dcf8a4  vmovaps xmm13, [rsp+0x20]
00007cbcc2dcf8aa  por xmm11, xmm13
00007cbcc2dcf8af  movaps [r15+0x290], xmm11
00007cbcc2dcf8b7  vmovaps [rsp+0x20], xmm5
00007cbcc2dcf8bd  vmovaps xmm13, [rsp+0x20]
00007cbcc2dcf8c3  por xmm5, xmm13
00007cbcc2dcf8c8  movaps [r15+0x2C0], xmm5
00007cbcc2dcf8d0  movq xmm13, qword ptr [r15+0x240]
00007cbcc2dcf8d9  vmovaps [rsp+0x20], xmm13
00007cbcc2dcf8df  vpermilpd xmm13, xmm13, 0x00
00007cbcc2dcf8e5  vmovaps [rsp+0x30], xmm1
00007cbcc2dcf8eb  vmovaps xmm1, [rsp+0x60]
00007cbcc2dcf8f1  vmovaps [rsp+0x60], xmm15
00007cbcc2dcf8f7  vmovaps [rsp+0xB0], xmm14
00007cbcc2dcf900  movaps xmm15, xmm1
00007cbcc2dcf904  vfmadd231pd xmm15, xmm9, xmm13
00007cbcc2dcf909  vcmppd xmm14, xmm15, xmm15, 0x03
00007cbcc2dcf90f  vptest xmm14, xmm14
00007cbcc2dcf914  jnz 0x00007CBCC2DD07FB
00007cbcc2dcf91a  vmovaps xmm1, [rsp+0x20]
00007cbcc2dcf920  vpermilpd xmm1, xmm1, 0x00
00007cbcc2dcf926  vmovaps xmm14, [rsp+0x110]
00007cbcc2dcf92f  vmovaps xmm13, [rsp+0x60]
00007cbcc2dcf935  vmovaps [rsp+0x60], xmm15
00007cbcc2dcf93b  movaps xmm9, xmm14
00007cbcc2dcf93f  vfmadd231pd xmm9, xmm13, xmm1
00007cbcc2dcf944  vcmppd xmm15, xmm9, xmm9, 0x03
00007cbcc2dcf94a  vptest xmm15, xmm15
00007cbcc2dcf94f  jnz 0x00007CBCC2DD0954
00007cbcc2dcf955  vmovaps xmm1, [rsp+0x20]
00007cbcc2dcf95b  vpermilpd xmm1, xmm1, 0x00
00007cbcc2dcf961  vmovaps xmm15, [rsp+0x100]
00007cbcc2dcf96a  movaps xmm14, xmm15
00007cbcc2dcf96e  vfmadd231pd xmm14, xmm8, xmm1
00007cbcc2dcf973  vcmppd xmm13, xmm14, xmm14, 0x03
00007cbcc2dcf979  vptest xmm13, xmm13
00007cbcc2dcf97e  jnz 0x00007CBCC2DD0AAD
00007cbcc2dcf984  vmovaps [rsp+0xF0], xmm4
00007cbcc2dcf98d  vmovaps xmm1, [rsp+0xF0]
00007cbcc2dcf996  por xmm4, xmm1
00007cbcc2dcf99a  movaps [r15+0x1D0], xmm4
00007cbcc2dcf9a2  vmovaps xmm1, [rsp+0x20]
00007cbcc2dcf9a8  vpermilpd xmm1, xmm1, 0x00
00007cbcc2dcf9ae  vmovaps xmm13, [rsp+0xB0]
00007cbcc2dcf9b7  movaps xmm15, xmm12
00007cbcc2dcf9bb  vfmadd231pd xmm15, xmm13, xmm1
00007cbcc2dcf9c0  vcmppd xmm8, xmm15, xmm15, 0x03
00007cbcc2dcf9c6  vptest xmm8, xmm8
00007cbcc2dcf9cb  jnz 0x00007CBCC2DD0C06
00007cbcc2dcf9d1  vmovaps xmm1, [rsp+0x80]
00007cbcc2dcf9da  vmovaps xmm13, [rsp+0x80]
00007cbcc2dcf9e3  por xmm1, xmm13
00007cbcc2dcf9e8  movaps [r15+0x200], xmm1
00007cbcc2dcf9f0  vmovaps xmm13, [rsp+0x50]
00007cbcc2dcf9f6  vmovaps xmm12, [rsp+0x50]
00007cbcc2dcf9fc  por xmm13, xmm12
00007cbcc2dcfa01  movaps [r15+0x1E0], xmm13
00007cbcc2dcfa09  vmovaps [rsp+0x20], xmm10
00007cbcc2dcfa0f  vmovaps xmm13, [rsp+0x20]
00007cbcc2dcfa15  por xmm10, xmm13
00007cbcc2dcfa1a  movaps [r15+0x2B0], xmm10
00007cbcc2dcfa22  vmovaps [rsp+0x20], xmm3
00007cbcc2dcfa28  vmovaps xmm13, [rsp+0x20]
00007cbcc2dcfa2e  por xmm3, xmm13
00007cbcc2dcfa33  movaps [r15+0x300], xmm3
00007cbcc2dcfa3b  vmovaps xmm8, [rsp+0xE0]
00007cbcc2dcfa44  vpermilpd xmm8, xmm8, 0x00
00007cbcc2dcfa4a  vmovaps xmm3, [rsp+0x60]
00007cbcc2dcfa50  vmovaps [rsp+0x20], xmm1
00007cbcc2dcfa56  vmovaps xmm1, [rsp+0x30]
00007cbcc2dcfa5c  vmovaps [rsp+0x30], xmm15
00007cbcc2dcfa62  vmovaps [rsp+0x50], xmm14
00007cbcc2dcfa68  movaps xmm15, xmm3
00007cbcc2dcfa6c  vfmadd231pd xmm15, xmm1, xmm8
00007cbcc2dcfa71  vcmppd xmm14, xmm15, xmm15, 0x03
00007cbcc2dcfa77  vptest xmm14, xmm14
00007cbcc2dcfa7c  jnz 0x00007CBCC2DD0D5F
00007cbcc2dcfa82  vmovaps xmm1, [rsp+0xE0]
00007cbcc2dcfa8b  vpermilpd xmm1, xmm1, 0x00
00007cbcc2dcfa91  movaps xmm8, xmm9
00007cbcc2dcfa95  vfmadd231pd xmm8, xmm5, xmm1
00007cbcc2dcfa9a  vcmppd xmm14, xmm8, xmm8, 0x03
00007cbcc2dcfaa0  vptest xmm14, xmm14
00007cbcc2dcfaa5  jnz 0x00007CBCC2DD0EB7
00007cbcc2dcfaab  vmovaps xmm1, [rsp+0xE0]
00007cbcc2dcfab4  vpermilpd xmm1, xmm1, 0x00
00007cbcc2dcfaba  vmovaps xmm14, [rsp+0x50]
00007cbcc2dcfac0  vmovaps xmm9, [rsp+0x10]
00007cbcc2dcfac6  movaps xmm5, xmm14
00007cbcc2dcfaca  vfmadd231pd xmm5, xmm9, xmm1
00007cbcc2dcfacf  vcmppd xmm3, xmm5, xmm5, 0x03
00007cbcc2dcfad4  vptest xmm3, xmm3
00007cbcc2dcfad9  jnz 0x00007CBCC2DD100F
00007cbcc2dcfadf  vmovaps xmm1, [rsp+0xE0]
00007cbcc2dcfae8  vpermilpd xmm1, xmm1, 0x00
00007cbcc2dcfaee  vmovaps xmm14, [rsp+0x30]
00007cbcc2dcfaf4  movaps xmm9, xmm14
00007cbcc2dcfaf8  vfmadd231pd xmm9, xmm4, xmm1
00007cbcc2dcfafd  vcmppd xmm3, xmm9, xmm9, 0x03
00007cbcc2dcfb03  vptest xmm3, xmm3
00007cbcc2dcfb08  jnz 0x00007CBCC2DD1166
00007cbcc2dcfb0e  vmovaps xmm1, [rsp+0x120]
00007cbcc2dcfb17  vmovaps xmm14, [rsp+0x120]
00007cbcc2dcfb20  por xmm1, xmm14
00007cbcc2dcfb25  movaps [r15+0x180], xmm1
00007cbcc2dcfb2d  vmovaps xmm14, [rsp+0x40]
00007cbcc2dcfb33  vmovaps xmm4, [rsp+0x40]
00007cbcc2dcfb39  por xmm14, xmm4
00007cbcc2dcfb3e  movaps [r15+0x2D0], xmm14
00007cbcc2dcfb46  vmovaps [rsp+0x10], xmm2
00007cbcc2dcfb4c  vmovaps xmm4, [rsp+0x10]
00007cbcc2dcfb52  por xmm2, xmm4
00007cbcc2dcfb56  movaps [r15+0x2F0], xmm2
00007cbcc2dcfb5e  vmovaps xmm3, [rsp+0xD0]
00007cbcc2dcfb67  vpermilpd xmm3, xmm3, 0x00
00007cbcc2dcfb6d  vmovaps [rsp+0x10], xmm1
00007cbcc2dcfb73  movaps xmm2, xmm8
00007cbcc2dcfb77  vfmadd231pd xmm2, xmm13, xmm3
00007cbcc2dcfb7c  vcmppd xmm1, xmm2, xmm2, 0x03
00007cbcc2dcfb81  vptest xmm1, xmm1
00007cbcc2dcfb86  jnz 0x00007CBCC2DD12BE
00007cbcc2dcfb8c  vmovaps xmm1, [rsp+0xD0]
00007cbcc2dcfb95  vpermilpd xmm1, xmm1, 0x00
00007cbcc2dcfb9b  vmovaps xmm13, [rsp+0x10]
00007cbcc2dcfba1  movaps xmm8, xmm15
00007cbcc2dcfba5  vfmadd231pd xmm8, xmm13, xmm1
00007cbcc2dcfbaa  vcmppd xmm3, xmm8, xmm8, 0x03
00007cbcc2dcfbb0  vptest xmm3, xmm3
00007cbcc2dcfbb5  jnz 0x00007CBCC2DD1415
00007cbcc2dcfbbb  lea rax, [r14+0x80]
00007cbcc2dcfbc2  movups xmm1, [r13+rax*1]
00007cbcc2dcfbc8  movaps [r15+0x190], xmm1
00007cbcc2dcfbd0  vmovaps xmm15, [rsp+0xD0]
00007cbcc2dcfbd9  vpermilpd xmm15, xmm15, 0x00
00007cbcc2dcfbdf  movaps xmm13, xmm5
00007cbcc2dcfbe3  vfmadd231pd xmm13, xmm11, xmm15
00007cbcc2dcfbe8  vcmppd xmm3, xmm13, xmm13, 0x03
00007cbcc2dcfbee  vptest xmm3, xmm3
00007cbcc2dcfbf3  jnz 0x00007CBCC2DD1578
00007cbcc2dcfbf9  vmovaps xmm15, [rsp+0xD0]
00007cbcc2dcfc02  vpermilpd xmm15, xmm15, 0x00
00007cbcc2dcfc08  movaps xmm11, xmm9
00007cbcc2dcfc0c  vfmadd231pd xmm11, xmm4, xmm15
00007cbcc2dcfc11  vcmppd xmm5, xmm11, xmm11, 0x03
00007cbcc2dcfc17  vptest xmm5, xmm5
00007cbcc2dcfc1c  jnz 0x00007CBCC2DD16D1
00007cbcc2dcfc22  vmovaps [rsp+0x10], xmm7
00007cbcc2dcfc28  vmovaps xmm9, [rsp+0x10]
00007cbcc2dcfc2e  por xmm7, xmm9
00007cbcc2dcfc33  movaps [r15+0x160], xmm7
00007cbcc2dcfc3b  lea rax, [r14+0x40]
00007cbcc2dcfc3f  movups xmm15, [r13+rax*1]
00007cbcc2dcfc45  lea rax, [r14+0x50]
00007cbcc2dcfc49  movups xmm9, [r13+rax*1]
00007cbcc2dcfc4f  movaps [r15+0x1B0], xmm15
00007cbcc2dcfc57  movaps [r15+0x1A0], xmm9
00007cbcc2dcfc5f  vmovaps xmm5, [rsp+0xA0]
00007cbcc2dcfc68  vpermilpd xmm5, xmm5, 0x00
00007cbcc2dcfc6e  movaps xmm4, xmm2
00007cbcc2dcfc71  vfmadd231pd xmm4, xmm14, xmm5
00007cbcc2dcfc76  vcmppd xmm3, xmm4, xmm4, 0x03
00007cbcc2dcfc7b  vptest xmm3, xmm3
00007cbcc2dcfc80  jnz 0x00007CBCC2DD183E
00007cbcc2dcfc86  vmovaps xmm14, [rsp+0xA0]
00007cbcc2dcfc8f  vpermilpd xmm14, xmm14, 0x00
00007cbcc2dcfc95  movaps xmm5, xmm8
00007cbcc2dcfc99  vfmadd231pd xmm5, xmm7, xmm14
00007cbcc2dcfc9e  vcmppd xmm3, xmm5, xmm5, 0x03
00007cbcc2dcfca3  vptest xmm3, xmm3
00007cbcc2dcfca8  jnz 0x00007CBCC2DD1994
00007cbcc2dcfcae  vmovaps xmm14, [rsp+0xA0]
00007cbcc2dcfcb7  vpermilpd xmm14, xmm14, 0x00
00007cbcc2dcfcbd  movaps xmm8, xmm13
00007cbcc2dcfcc1  vfmadd231pd xmm8, xmm6, xmm14
00007cbcc2dcfcc6  vcmppd xmm7, xmm8, xmm8, 0x03
00007cbcc2dcfccc  vptest xmm7, xmm7
00007cbcc2dcfcd1  jnz 0x00007CBCC2DD1AEB
00007cbcc2dcfcd7  vmovaps xmm14, [rsp+0xA0]
00007cbcc2dcfce0  vpermilpd xmm14, xmm14, 0x00
00007cbcc2dcfce6  movaps xmm13, xmm11
00007cbcc2dcfcea  vfmadd231pd xmm13, xmm12, xmm14
00007cbcc2dcfcef  vcmppd xmm7, xmm13, xmm13, 0x03
00007cbcc2dcfcf5  vptest xmm7, xmm7
00007cbcc2dcfcfa  jnz 0x00007CBCC2DD1C44
00007cbcc2dcfd00  lea rax, [r14+0x60]
00007cbcc2dcfd04  movups xmm14, [r13+rax*1]
00007cbcc2dcfd0a  lea rax, [r14+0x70]
00007cbcc2dcfd0e  movups xmm12, [r13+rax*1]
00007cbcc2dcfd14  movaps [r15+0x150], xmm14
00007cbcc2dcfd1c  movaps [r15+0x120], xmm12
00007cbcc2dcfd24  vmovaps xmm11, [rsp+0xC0]
00007cbcc2dcfd2d  vpermilpd xmm11, xmm11, 0x00
00007cbcc2dcfd33  movaps xmm7, xmm4
00007cbcc2dcfd36  vfmadd231pd xmm7, xmm9, xmm11
00007cbcc2dcfd3b  vcmppd xmm6, xmm7, xmm7, 0x03
00007cbcc2dcfd40  vptest xmm6, xmm6
00007cbcc2dcfd45  jnz 0x00007CBCC2DD1DB2
00007cbcc2dcfd4b  vmovaps xmm11, [rsp+0xC0]
00007cbcc2dcfd54  vpermilpd xmm11, xmm11, 0x00
00007cbcc2dcfd5a  movaps xmm9, xmm5
00007cbcc2dcfd5e  vfmadd231pd xmm9, xmm14, xmm11
00007cbcc2dcfd63  vcmppd xmm6, xmm9, xmm9, 0x03
00007cbcc2dcfd69  vptest xmm6, xmm6
00007cbcc2dcfd6e  jnz 0x00007CBCC2DD1F09
00007cbcc2dcfd74  vmovaps xmm14, [rsp+0xC0]
00007cbcc2dcfd7d  vpermilpd xmm14, xmm14, 0x00
00007cbcc2dcfd83  movaps xmm11, xmm8
00007cbcc2dcfd87  vfmadd231pd xmm11, xmm10, xmm14
00007cbcc2dcfd8c  vcmppd xmm6, xmm11, xmm11, 0x03
00007cbcc2dcfd92  vptest xmm6, xmm6
00007cbcc2dcfd97  jnz 0x00007CBCC2DD2062
00007cbcc2dcfd9d  vmovaps xmm14, [rsp+0xC0]
00007cbcc2dcfda6  vpermilpd xmm14, xmm14, 0x00
00007cbcc2dcfdac  movaps xmm10, xmm13
00007cbcc2dcfdb0  vfmadd231pd xmm10, xmm15, xmm14
00007cbcc2dcfdb5  vcmppd xmm8, xmm10, xmm10, 0x03
00007cbcc2dcfdbb  vptest xmm8, xmm8
00007cbcc2dcfdc0  jnz 0x00007CBCC2DD21BC
00007cbcc2dcfdc6  lea rax, [r14+0x20]
00007cbcc2dcfdca  movups xmm15, [r13+rax*1]
00007cbcc2dcfdd0  lea rax, [r14+0x30]
00007cbcc2dcfdd4  movups xmm14, [r13+rax*1]
00007cbcc2dcfdda  vmovaps xmm13, [rsp+0x70]
00007cbcc2dcfde0  vpermilpd xmm13, xmm13, 0x00
00007cbcc2dcfde6  vmovaps xmm8, [rsp+0x20]
00007cbcc2dcfdec  movaps xmm6, xmm7
00007cbcc2dcfdef  vfmadd231pd xmm6, xmm8, xmm13
00007cbcc2dcfdf4  vcmppd xmm5, xmm6, xmm6, 0x03
00007cbcc2dcfdf9  vptest xmm5, xmm5
00007cbcc2dcfdfe  jnz 0x00007CBCC2DD232A
00007cbcc2dcfe04  vmovaps xmm13, [rsp+0x70]
00007cbcc2dcfe0a  vpermilpd xmm13, xmm13, 0x00
00007cbcc2dcfe10  movaps xmm8, xmm9
00007cbcc2dcfe14  vfmadd231pd xmm8, xmm1, xmm13
00007cbcc2dcfe19  vcmppd xmm7, xmm8, xmm8, 0x03
00007cbcc2dcfe1f  vptest xmm7, xmm7
00007cbcc2dcfe24  jnz 0x00007CBCC2DD2481
00007cbcc2dcfe2a  vmovaps xmm1, [rsp+0x70]
00007cbcc2dcfe30  vpermilpd xmm1, xmm1, 0x00
00007cbcc2dcfe36  movaps xmm13, xmm11
00007cbcc2dcfe3a  vfmadd231pd xmm13, xmm12, xmm1
00007cbcc2dcfe3f  vcmppd xmm9, xmm13, xmm13, 0x03
00007cbcc2dcfe45  vptest xmm9, xmm9
00007cbcc2dcfe4a  jnz 0x00007CBCC2DD25DA
00007cbcc2dcfe50  vmovaps xmm1, [rsp+0x70]
00007cbcc2dcfe56  vpermilpd xmm1, xmm1, 0x00
00007cbcc2dcfe5c  movaps xmm12, xmm10
00007cbcc2dcfe60  vfmadd231pd xmm12, xmm14, xmm1
00007cbcc2dcfe65  vcmppd xmm11, xmm12, xmm12, 0x03
00007cbcc2dcfe6b  vptest xmm11, xmm11
00007cbcc2dcfe70  jnz 0x00007CBCC2DD2733
00007cbcc2dcfe76  lea rax, [r14+0x90]
00007cbcc2dcfe7d  movups xmm1, [r13+rax*1]
00007cbcc2dcfe83  lea rax, [r14+0xA0]
00007cbcc2dcfe8a  movups xmm14, [r13+rax*1]
00007cbcc2dcfe90  movaps [r15+0x140], xmm1
00007cbcc2dcfe98  movaps [r15+0x130], xmm14
00007cbcc2dcfea0  vmovaps xmm11, [rsp+0x90]
00007cbcc2dcfea9  vpermilpd xmm11, xmm11, 0x00
00007cbcc2dcfeaf  movaps xmm10, xmm6
00007cbcc2dcfeb3  vfmadd231pd xmm10, xmm15, xmm11
00007cbcc2dcfeb8  vcmppd xmm9, xmm10, xmm10, 0x03
00007cbcc2dcfebe  vptest xmm9, xmm9
00007cbcc2dcfec3  jnz 0x00007CBCC2DD28A0
00007cbcc2dcfec9  movaps [r15+0x220], xmm10
00007cbcc2dcfed1  lea rax, [r14+0x10]
00007cbcc2dcfed5  movups xmm15, [r13+rax*1]
00007cbcc2dcfedb  movaps [r15+0x240], xmm15
00007cbcc2dcfee3  vmovaps xmm11, [rsp+0x90]
00007cbcc2dcfeec  vpermilpd xmm11, xmm11, 0x00
00007cbcc2dcfef2  movaps xmm9, xmm8
00007cbcc2dcfef6  vfmadd231pd xmm9, xmm14, xmm11
00007cbcc2dcfefb  vcmppd xmm7, xmm9, xmm9, 0x03
00007cbcc2dcff01  vptest xmm7, xmm7
00007cbcc2dcff06  jnz 0x00007CBCC2DD2A03
00007cbcc2dcff0c  movaps [r15+0x110], xmm9
00007cbcc2dcff14  vmovaps xmm14, [rsp+0x90]
00007cbcc2dcff1d  vpermilpd xmm14, xmm14, 0x00
00007cbcc2dcff23  movaps xmm11, xmm13
00007cbcc2dcff27  vfmadd231pd xmm11, xmm1, xmm14
00007cbcc2dcff2c  vcmppd xmm8, xmm11, xmm11, 0x03
00007cbcc2dcff32  vptest xmm8, xmm8
00007cbcc2dcff37  jnz 0x00007CBCC2DD2B5D
00007cbcc2dcff3d  movaps [r15+0x170], xmm11
00007cbcc2dcff45  vmovaps xmm1, [rsp+0x90]
00007cbcc2dcff4e  vpermilpd xmm1, xmm1, 0x00
00007cbcc2dcff54  movaps xmm14, xmm12
00007cbcc2dcff58  vfmadd231pd xmm14, xmm15, xmm1
00007cbcc2dcff5d  vcmppd xmm13, xmm14, xmm14, 0x03
00007cbcc2dcff63  vptest xmm13, xmm13
00007cbcc2dcff68  jnz 0x00007CBCC2DD2CB6
00007cbcc2dcff6e  movaps [r15+0x230], xmm14
00007cbcc2dcff76  mov eax, 0x4308D0
00007cbcc2dcff7b  movups [r13+rax*1], xmm9
00007cbcc2dcff81  mov eax, 0x4308E0
00007cbcc2dcff86  movups [r13+rax*1], xmm11
00007cbcc2dcff8c  mov eax, 0x4308F0
00007cbcc2dcff91  movups [r13+rax*1], xmm10
00007cbcc2dcff97  mov eax, 0x430900
00007cbcc2dcff9c  movups [r13+rax*1], xmm14
00007cbcc2dcffa2  mov eax, [r15+0x108]
00007cbcc2dcffa9  sahf
00007cbcc2dcffaa  jnz 0x00007CBCC2DCFFDC
00007cbcc2dcffac  cmp dword ptr [r15+0x318], 0x00
00007cbcc2dcffb4  jz 0x00007CBCC2DD67A0
00007cbcc2dcffba  nop [rax+rax*1], ax
00007cbcc2dcffc3  nop [rax+rax*1], eax
00007cbcc2dcffcb  mov eax, 0x4103F0
00007cbcc2dcffd0  mov [r15+0x100], rax
00007cbcc2dcffd7  jmp 0x00007CBCC2BFE110
00007cbcc2dcffdc  cmp dword ptr [r15+0x318], 0x00
00007cbcc2dcffe4  jz 0x00007CBCC2DD2E40
00007cbcc2dcffea  nop [rax+rax*1], ax
00007cbcc2dcfff3  nop [rax+rax*1], eax
00007cbcc2dcfffb  mov eax, 0x410274
00007cbcc2dd0000  mov [r15+0x100], rax
00007cbcc2dd0007  jmp 0x00007CBCC2BFE110
00007cbcc2dd000c  int3
00007cbcc2dd000d  call 0x00007CBCC2BFF430
00007cbcc2dd0012  jmp 0x00007CBCC2DCF00F
00007cbcc2dd0017  call 0x00007CBCC2CC4620
00007cbcc2dd001c  jmp 0x00007CBCC2DCF019
00007cbcc2dd0021  call 0x00007CBCC2CC0860
00007cbcc2dd0026  jmp 0x00007CBCC2DCF049
00007cbcc2dd002b  call 0x00007CBCC2CBF5F0
00007cbcc2dd0030  jmp 0x00007CBCC2DCF055
00007cbcc2dd0035  call 0x00007CBCC2CC33A0
00007cbcc2dd003a  jmp 0x00007CBCC2DCF062
00007cbcc2dd003f  call 0x00007CBCC2CC2120
00007cbcc2dd0044  jmp 0x00007CBCC2DCF06F
00007cbcc2dd0049  call 0x00007CBCC2CC0860
00007cbcc2dd004e  jmp 0x00007CBCC2DCF097
00007cbcc2dd0053  call 0x00007CBCC2CBF5F0
00007cbcc2dd0058  jmp 0x00007CBCC2DCF0A3
00007cbcc2dd005d  call 0x00007CBCC2CC0EA0
00007cbcc2dd0062  jmp 0x00007CBCC2DCF0B0
00007cbcc2dd0067  call 0x00007CBCC2CBFC30
00007cbcc2dd006c  jmp 0x00007CBCC2DCF0BD
00007cbcc2dd0071  call 0x00007CBCC2CD6600
00007cbcc2dd0076  jmp 0x00007CBCC2DCF0C3
00007cbcc2dd007b  call 0x00007CBCC2CB52F0
00007cbcc2dd0080  jmp 0x00007CBCC2DCF0CD
00007cbcc2dd0085  call 0x00007CBCC2CBE9C0
00007cbcc2dd008a  jmp 0x00007CBCC2DCF0D7
00007cbcc2dd008f  call 0x00007CBCC2CC0860
00007cbcc2dd0094  jmp 0x00007CBCC2DCF0FF
00007cbcc2dd0099  call 0x00007CBCC2CBF5F0
00007cbcc2dd009e  jmp 0x00007CBCC2DCF10B
00007cbcc2dd00a3  call 0x00007CBCC2CBD750
00007cbcc2dd00a8  jmp 0x00007CBCC2DCF115
00007cbcc2dd00ad  call 0x00007CBCC2CBC4E0
00007cbcc2dd00b2  jmp 0x00007CBCC2DCF11F
00007cbcc2dd00b7  call 0x00007CBCC2CC0860
00007cbcc2dd00bc  jmp 0x00007CBCC2DCF147
00007cbcc2dd00c1  call 0x00007CBCC2CBF5F0
00007cbcc2dd00c6  jmp 0x00007CBCC2DCF153
00007cbcc2dd00cb  call 0x00007CBCC2CBB270
00007cbcc2dd00d0  jmp 0x00007CBCC2DCF160
00007cbcc2dd00d5  call 0x00007CBCC2CBA000
00007cbcc2dd00da  jmp 0x00007CBCC2DCF16D
00007cbcc2dd00df  call 0x00007CBCC2CBEAE0
00007cbcc2dd00e4  jmp 0x00007CBCC2DCF17A
00007cbcc2dd00e9  call 0x00007CBCC2CB5400
00007cbcc2dd00ee  jmp 0x00007CBCC2DCF187
00007cbcc2dd00f3  call 0x00007CBCC2CB52F0
00007cbcc2dd00f8  jmp 0x00007CBCC2DCF194
00007cbcc2dd00fd  call 0x00007CBCC2CBE9C0
00007cbcc2dd0102  jmp 0x00007CBCC2DCF1A1
00007cbcc2dd0107  call 0x00007CBCC2CC0860
00007cbcc2dd010c  jmp 0x00007CBCC2DCF1B4
00007cbcc2dd0111  call 0x00007CBCC2CB8D90
00007cbcc2dd0116  jmp 0x00007CBCC2DCF1C1
00007cbcc2dd011b  call 0x00007CBCC2CB8A20
00007cbcc2dd0120  jmp 0x00007CBCC2DCF1CE
00007cbcc2dd0125  call 0x00007CBCC2CB77B0
00007cbcc2dd012a  jmp 0x00007CBCC2DCF1DB
00007cbcc2dd012f  call 0x00007CBCC2CB6550
00007cbcc2dd0134  jmp 0x00007CBCC2DCF1E8
00007cbcc2dd0139  call 0x00007CBCC2CB52F0
00007cbcc2dd013e  jmp 0x00007CBCC2DCF1F8
00007cbcc2dd0143  call 0x00007CBCC2CB52F0
00007cbcc2dd0148  jmp 0x00007CBCC2DCF208
00007cbcc2dd014d  call 0x00007CBCC2CB8B30
00007cbcc2dd0152  jmp 0x00007CBCC2DCF212
00007cbcc2dd0157  call 0x00007CBCC2CB8EA0
00007cbcc2dd015c  jmp 0x00007CBCC2DCF21F
00007cbcc2dd0161  call 0x00007CBCC2CB8D90
00007cbcc2dd0166  jmp 0x00007CBCC2DCF22C
00007cbcc2dd016b  call 0x00007CBCC2CB8A20
00007cbcc2dd0170  jmp 0x00007CBCC2DCF239
00007cbcc2dd0175  call 0x00007CBCC2CB6660
00007cbcc2dd017a  jmp 0x00007CBCC2DCF246
00007cbcc2dd017f  call 0x00007CBCC2CB78C0
00007cbcc2dd0184  jmp 0x00007CBCC2DCF253
00007cbcc2dd0189  call 0x00007CBCC2CB77B0
00007cbcc2dd018e  jmp 0x00007CBCC2DCF260
00007cbcc2dd0193  call 0x00007CBCC2CB6550
00007cbcc2dd0198  jmp 0x00007CBCC2DCF26D
00007cbcc2dd019d  call 0x00007CBCC2CB52F0
00007cbcc2dd01a2  jmp 0x00007CBCC2DCF280
00007cbcc2dd01a7  call 0x00007CBCC2CB52F0
00007cbcc2dd01ac  jmp 0x00007CBCC2DCF293
00007cbcc2dd01b1  call 0x00007CBCC2CB52F0
00007cbcc2dd01b6  jmp 0x00007CBCC2DCF2A6
00007cbcc2dd01bb  call 0x00007CBCC2CB52F0
00007cbcc2dd01c0  jmp 0x00007CBCC2DCF2B9
00007cbcc2dd01c5  call 0x00007CBCC2CB52F0
00007cbcc2dd01ca  jmp 0x00007CBCC2DCF2CC
00007cbcc2dd01cf  call 0x00007CBCC2CB52F0
00007cbcc2dd01d4  jmp 0x00007CBCC2DCF2E2
00007cbcc2dd01d9  call 0x00007CBCC2CB52F0
00007cbcc2dd01de  jmp 0x00007CBCC2DCF2F8
00007cbcc2dd01e3  call 0x00007CBCC2CB52F0
00007cbcc2dd01e8  jmp 0x00007CBCC2DCF30E
00007cbcc2dd01ed  call 0x00007CBCC2BFF540
00007cbcc2dd01f2  jmp 0x00007CBCC2DCF32F
00007cbcc2dd01f7  call 0x00007CBCC2BFF540
00007cbcc2dd01fc  jmp 0x00007CBCC2DCF33F
00007cbcc2dd0201  call 0x00007CBCC2BFF540
00007cbcc2dd0206  jmp 0x00007CBCC2DCF34F
00007cbcc2dd020b  call 0x00007CBCC2BFF540
00007cbcc2dd0210  jmp 0x00007CBCC2DCF362
00007cbcc2dd0215  call 0x00007CBCC2BFF540
00007cbcc2dd021a  jmp 0x00007CBCC2DCF375
00007cbcc2dd021f  call 0x00007CBCC2BFF540
00007cbcc2dd0224  jmp 0x00007CBCC2DCF388
00007cbcc2dd0229  call 0x00007CBCC2CC0370
00007cbcc2dd022e  jmp 0x00007CBCC2DCF3AD
00007cbcc2dd0233  call 0x00007CBCC2CBF100
00007cbcc2dd0238  jmp 0x00007CBCC2DCF3B6
00007cbcc2dd023d  call 0x00007CBCC2CC0370
00007cbcc2dd0242  jmp 0x00007CBCC2DCF426
00007cbcc2dd0247  call 0x00007CBCC2CBF100
00007cbcc2dd024c  jmp 0x00007CBCC2DCF42F
00007cbcc2dd0251  call 0x00007CBCC2CC0370
00007cbcc2dd0256  jmp 0x00007CBCC2DCF4E3
00007cbcc2dd025b  call 0x00007CBCC2CBF100
00007cbcc2dd0260  jmp 0x00007CBCC2DCF4EC
00007cbcc2dd0265  call 0x00007CBCC2C0B720
00007cbcc2dd026a  jmp 0x00007CBCC2DCF5A8
00007cbcc2dd026f  call 0x00007CBCC2CD64F0
00007cbcc2dd0274  jmp 0x00007CBCC2DCF5D0
00007cbcc2dd0279  call 0x00007CBCC2CB47C0
00007cbcc2dd027e  jmp 0x00007CBCC2DCF5EB
00007cbcc2dd0283  sub rsp, 0x08
00007cbcc2dd0287  push rax
00007cbcc2dd0288  push rcx
00007cbcc2dd0289  push rdx
00007cbcc2dd028a  push rdi
00007cbcc2dd028b  push rsi
00007cbcc2dd028c  push r8
00007cbcc2dd028e  push r9
00007cbcc2dd0290  push r10
00007cbcc2dd0292  push r11
00007cbcc2dd0294  sub rsp, 0xF0
00007cbcc2dd029b  vmovaps [rsp], xmm0
00007cbcc2dd02a0  vmovaps [rsp+0x10], xmm1
00007cbcc2dd02a6  vmovaps [rsp+0x20], xmm2
00007cbcc2dd02ac  vmovaps [rsp+0x30], xmm3
00007cbcc2dd02b2  vmovaps [rsp+0x40], xmm4
00007cbcc2dd02b8  vmovaps [rsp+0x50], xmm5
00007cbcc2dd02be  vmovaps [rsp+0x60], xmm6
00007cbcc2dd02c4  vmovaps [rsp+0x70], xmm7
00007cbcc2dd02ca  vmovaps [rsp+0x80], xmm8
00007cbcc2dd02d3  vmovaps [rsp+0x90], xmm9
00007cbcc2dd02dc  vmovaps [rsp+0xA0], xmm10
00007cbcc2dd02e5  vmovaps [rsp+0xB0], xmm11
00007cbcc2dd02ee  vmovaps [rsp+0xC0], xmm12
00007cbcc2dd02f7  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd0300  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd0309  sub rsp, 0x40
00007cbcc2dd030d  lea rdi, [rsp]
00007cbcc2dd0311  lea rsi, [rsp+0x10]
00007cbcc2dd0316  lea rdx, [rsp+0x20]
00007cbcc2dd031b  lea rcx, [rsp+0x30]
00007cbcc2dd0320  mov r8d, 0x00
00007cbcc2dd0326  lea r9, [r15+0x3A8]
00007cbcc2dd032d  movaps [rdi], xmm13
00007cbcc2dd0331  movaps [rsi], xmm1
00007cbcc2dd0334  movaps [rdx], xmm15
00007cbcc2dd0338  movaps [rcx], xmm14
00007cbcc2dd033c  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd0346  call rax
00007cbcc2dd0348  movaps xmm13, [rsp]
00007cbcc2dd034d  add rsp, 0x40
00007cbcc2dd0351  vmovaps xmm0, [rsp]
00007cbcc2dd0356  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd035c  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd0362  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd0368  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd036e  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd0374  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd037a  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd0380  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd0389  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd0392  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dd039b  vmovaps xmm11, [rsp+0xB0]
00007cbcc2dd03a4  vmovaps xmm12, [rsp+0xC0]
00007cbcc2dd03ad  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd03b6  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd03bf  add rsp, 0xF0
00007cbcc2dd03c6  pop r11
00007cbcc2dd03c8  pop r10
00007cbcc2dd03ca  pop r9
00007cbcc2dd03cc  pop r8
00007cbcc2dd03ce  pop rsi
00007cbcc2dd03cf  pop rdi
00007cbcc2dd03d0  pop rdx
00007cbcc2dd03d1  pop rcx
00007cbcc2dd03d2  pop rax
00007cbcc2dd03d3  add rsp, 0x08
00007cbcc2dd03d7  jmp 0x00007CBCC2DCF65E
00007cbcc2dd03dc  sub rsp, 0x08
00007cbcc2dd03e0  push rax
00007cbcc2dd03e1  push rcx
00007cbcc2dd03e2  push rdx
00007cbcc2dd03e3  push rdi
00007cbcc2dd03e4  push rsi
00007cbcc2dd03e5  push r8
00007cbcc2dd03e7  push r9
00007cbcc2dd03e9  push r10
00007cbcc2dd03eb  push r11
00007cbcc2dd03ed  sub rsp, 0xF0
00007cbcc2dd03f4  vmovaps [rsp], xmm0
00007cbcc2dd03f9  vmovaps [rsp+0x10], xmm1
00007cbcc2dd03ff  vmovaps [rsp+0x20], xmm2
00007cbcc2dd0405  vmovaps [rsp+0x30], xmm3
00007cbcc2dd040b  vmovaps [rsp+0x40], xmm4
00007cbcc2dd0411  vmovaps [rsp+0x50], xmm5
00007cbcc2dd0417  vmovaps [rsp+0x60], xmm6
00007cbcc2dd041d  vmovaps [rsp+0x70], xmm7
00007cbcc2dd0423  vmovaps [rsp+0x80], xmm8
00007cbcc2dd042c  vmovaps [rsp+0x90], xmm9
00007cbcc2dd0435  vmovaps [rsp+0xA0], xmm10
00007cbcc2dd043e  vmovaps [rsp+0xB0], xmm11
00007cbcc2dd0447  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd0450  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd0459  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd0462  sub rsp, 0x40
00007cbcc2dd0466  lea rdi, [rsp]
00007cbcc2dd046a  lea rsi, [rsp+0x10]
00007cbcc2dd046f  lea rdx, [rsp+0x20]
00007cbcc2dd0474  lea rcx, [rsp+0x30]
00007cbcc2dd0479  mov r8d, 0x00
00007cbcc2dd047f  lea r9, [r15+0x3A8]
00007cbcc2dd0486  movaps [rdi], xmm12
00007cbcc2dd048a  movaps [rsi], xmm1
00007cbcc2dd048d  movaps [rdx], xmm15
00007cbcc2dd0491  movaps [rcx], xmm14
00007cbcc2dd0495  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd049f  call rax
00007cbcc2dd04a1  movaps xmm12, [rsp]
00007cbcc2dd04a6  add rsp, 0x40
00007cbcc2dd04aa  vmovaps xmm0, [rsp]
00007cbcc2dd04af  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd04b5  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd04bb  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd04c1  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd04c7  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd04cd  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd04d3  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd04d9  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd04e2  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd04eb  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dd04f4  vmovaps xmm11, [rsp+0xB0]
00007cbcc2dd04fd  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd0506  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd050f  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd0518  add rsp, 0xF0
00007cbcc2dd051f  pop r11
00007cbcc2dd0521  pop r10
00007cbcc2dd0523  pop r9
00007cbcc2dd0525  pop r8
00007cbcc2dd0527  pop rsi
00007cbcc2dd0528  pop rdi
00007cbcc2dd0529  pop rdx
00007cbcc2dd052a  pop rcx
00007cbcc2dd052b  pop rax
00007cbcc2dd052c  add rsp, 0x08
00007cbcc2dd0530  jmp 0x00007CBCC2DCF68D
00007cbcc2dd0535  call 0x00007CBCC2BFF430
00007cbcc2dd053a  jmp 0x00007CBCC2DCF712
00007cbcc2dd053f  sub rsp, 0x08
00007cbcc2dd0543  push rax
00007cbcc2dd0544  push rcx
00007cbcc2dd0545  push rdx
00007cbcc2dd0546  push rdi
00007cbcc2dd0547  push rsi
00007cbcc2dd0548  push r8
00007cbcc2dd054a  push r9
00007cbcc2dd054c  push r10
00007cbcc2dd054e  push r11
00007cbcc2dd0550  sub rsp, 0xF0
00007cbcc2dd0557  vmovaps [rsp], xmm0
00007cbcc2dd055c  vmovaps [rsp+0x10], xmm1
00007cbcc2dd0562  vmovaps [rsp+0x20], xmm2
00007cbcc2dd0568  vmovaps [rsp+0x30], xmm3
00007cbcc2dd056e  vmovaps [rsp+0x40], xmm4
00007cbcc2dd0574  vmovaps [rsp+0x50], xmm5
00007cbcc2dd057a  vmovaps [rsp+0x60], xmm6
00007cbcc2dd0580  vmovaps [rsp+0x70], xmm7
00007cbcc2dd0586  vmovaps [rsp+0x80], xmm8
00007cbcc2dd058f  vmovaps [rsp+0x90], xmm9
00007cbcc2dd0598  vmovaps [rsp+0xA0], xmm10
00007cbcc2dd05a1  vmovaps [rsp+0xB0], xmm11
00007cbcc2dd05aa  vmovaps [rsp+0xC0], xmm12
00007cbcc2dd05b3  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd05bc  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd05c5  sub rsp, 0x40
00007cbcc2dd05c9  lea rdi, [rsp]
00007cbcc2dd05cd  lea rsi, [rsp+0x10]
00007cbcc2dd05d2  lea rdx, [rsp+0x20]
00007cbcc2dd05d7  lea rcx, [rsp+0x30]
00007cbcc2dd05dc  mov r8d, 0x00
00007cbcc2dd05e2  lea r9, [r15+0x3A8]
00007cbcc2dd05e9  movaps [rdi], xmm13
00007cbcc2dd05ed  movaps [rsi], xmm1
00007cbcc2dd05f0  movaps [rdx], xmm15
00007cbcc2dd05f4  movaps [rcx], xmm14
00007cbcc2dd05f8  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd0602  call rax
00007cbcc2dd0604  movaps xmm13, [rsp]
00007cbcc2dd0609  add rsp, 0x40
00007cbcc2dd060d  vmovaps xmm0, [rsp]
00007cbcc2dd0612  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd0618  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd061e  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd0624  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd062a  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd0630  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd0636  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd063c  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd0645  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd064e  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dd0657  vmovaps xmm11, [rsp+0xB0]
00007cbcc2dd0660  vmovaps xmm12, [rsp+0xC0]
00007cbcc2dd0669  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd0672  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd067b  add rsp, 0xF0
00007cbcc2dd0682  pop r11
00007cbcc2dd0684  pop r10
00007cbcc2dd0686  pop r9
00007cbcc2dd0688  pop r8
00007cbcc2dd068a  pop rsi
00007cbcc2dd068b  pop rdi
00007cbcc2dd068c  pop rdx
00007cbcc2dd068d  pop rcx
00007cbcc2dd068e  pop rax
00007cbcc2dd068f  add rsp, 0x08
00007cbcc2dd0693  jmp 0x00007CBCC2DCF77F
00007cbcc2dd0698  call 0x00007CBCC2BFF430
00007cbcc2dd069d  jmp 0x00007CBCC2DCF78C
00007cbcc2dd06a2  sub rsp, 0x08
00007cbcc2dd06a6  push rax
00007cbcc2dd06a7  push rcx
00007cbcc2dd06a8  push rdx
00007cbcc2dd06a9  push rdi
00007cbcc2dd06aa  push rsi
00007cbcc2dd06ab  push r8
00007cbcc2dd06ad  push r9
00007cbcc2dd06af  push r10
00007cbcc2dd06b1  push r11
00007cbcc2dd06b3  sub rsp, 0xF0
00007cbcc2dd06ba  vmovaps [rsp], xmm0
00007cbcc2dd06bf  vmovaps [rsp+0x10], xmm1
00007cbcc2dd06c5  vmovaps [rsp+0x20], xmm2
00007cbcc2dd06cb  vmovaps [rsp+0x30], xmm3
00007cbcc2dd06d1  vmovaps [rsp+0x40], xmm4
00007cbcc2dd06d7  vmovaps [rsp+0x50], xmm5
00007cbcc2dd06dd  vmovaps [rsp+0x60], xmm6
00007cbcc2dd06e3  vmovaps [rsp+0x70], xmm7
00007cbcc2dd06e9  vmovaps [rsp+0x80], xmm8
00007cbcc2dd06f2  vmovaps [rsp+0x90], xmm9
00007cbcc2dd06fb  vmovaps [rsp+0xA0], xmm10
00007cbcc2dd0704  vmovaps [rsp+0xB0], xmm11
00007cbcc2dd070d  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd0716  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd071f  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd0728  sub rsp, 0x40
00007cbcc2dd072c  lea rdi, [rsp]
00007cbcc2dd0730  lea rsi, [rsp+0x10]
00007cbcc2dd0735  lea rdx, [rsp+0x20]
00007cbcc2dd073a  lea rcx, [rsp+0x30]
00007cbcc2dd073f  mov r8d, 0x00
00007cbcc2dd0745  lea r9, [r15+0x3A8]
00007cbcc2dd074c  movaps [rdi], xmm12
00007cbcc2dd0750  movaps [rsi], xmm15
00007cbcc2dd0754  movaps [rdx], xmm1
00007cbcc2dd0757  movaps [rcx], xmm14
00007cbcc2dd075b  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd0765  call rax
00007cbcc2dd0767  movaps xmm12, [rsp]
00007cbcc2dd076c  add rsp, 0x40
00007cbcc2dd0770  vmovaps xmm0, [rsp]
00007cbcc2dd0775  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd077b  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd0781  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd0787  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd078d  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd0793  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd0799  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd079f  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd07a8  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd07b1  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dd07ba  vmovaps xmm11, [rsp+0xB0]
00007cbcc2dd07c3  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd07cc  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd07d5  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd07de  add rsp, 0xF0
00007cbcc2dd07e5  pop r11
00007cbcc2dd07e7  pop r10
00007cbcc2dd07e9  pop r9
00007cbcc2dd07eb  pop r8
00007cbcc2dd07ed  pop rsi
00007cbcc2dd07ee  pop rdi
00007cbcc2dd07ef  pop rdx
00007cbcc2dd07f0  pop rcx
00007cbcc2dd07f1  pop rax
00007cbcc2dd07f2  add rsp, 0x08
00007cbcc2dd07f6  jmp 0x00007CBCC2DCF7B8
00007cbcc2dd07fb  sub rsp, 0x08
00007cbcc2dd07ff  push rax
00007cbcc2dd0800  push rcx
00007cbcc2dd0801  push rdx
00007cbcc2dd0802  push rdi
00007cbcc2dd0803  push rsi
00007cbcc2dd0804  push r8
00007cbcc2dd0806  push r9
00007cbcc2dd0808  push r10
00007cbcc2dd080a  push r11
00007cbcc2dd080c  sub rsp, 0xF0
00007cbcc2dd0813  vmovaps [rsp], xmm0
00007cbcc2dd0818  vmovaps [rsp+0x10], xmm1
00007cbcc2dd081e  vmovaps [rsp+0x20], xmm2
00007cbcc2dd0824  vmovaps [rsp+0x30], xmm3
00007cbcc2dd082a  vmovaps [rsp+0x40], xmm4
00007cbcc2dd0830  vmovaps [rsp+0x50], xmm5
00007cbcc2dd0836  vmovaps [rsp+0x60], xmm6
00007cbcc2dd083c  vmovaps [rsp+0x70], xmm7
00007cbcc2dd0842  vmovaps [rsp+0x80], xmm8
00007cbcc2dd084b  vmovaps [rsp+0x90], xmm9
00007cbcc2dd0854  vmovaps [rsp+0xA0], xmm10
00007cbcc2dd085d  vmovaps [rsp+0xB0], xmm11
00007cbcc2dd0866  vmovaps [rsp+0xC0], xmm12
00007cbcc2dd086f  vmovaps [rsp+0xD0], xmm13
00007cbcc2dd0878  vmovaps [rsp+0xE0], xmm14
00007cbcc2dd0881  sub rsp, 0x40
00007cbcc2dd0885  lea rdi, [rsp]
00007cbcc2dd0889  lea rsi, [rsp+0x10]
00007cbcc2dd088e  lea rdx, [rsp+0x20]
00007cbcc2dd0893  lea rcx, [rsp+0x30]
00007cbcc2dd0898  mov r8d, 0x00
00007cbcc2dd089e  lea r9, [r15+0x3A8]
00007cbcc2dd08a5  movaps [rdi], xmm15
00007cbcc2dd08a9  movaps [rsi], xmm1
00007cbcc2dd08ac  movaps [rdx], xmm9
00007cbcc2dd08b0  movaps [rcx], xmm13
00007cbcc2dd08b4  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd08be  call rax
00007cbcc2dd08c0  movaps xmm15, [rsp]
00007cbcc2dd08c5  add rsp, 0x40
00007cbcc2dd08c9  vmovaps xmm0, [rsp]
00007cbcc2dd08ce  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd08d4  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd08da  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd08e0  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd08e6  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd08ec  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd08f2  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd08f8  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd0901  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd090a  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dd0913  vmovaps xmm11, [rsp+0xB0]
00007cbcc2dd091c  vmovaps xmm12, [rsp+0xC0]
00007cbcc2dd0925  vmovaps xmm13, [rsp+0xD0]
00007cbcc2dd092e  vmovaps xmm14, [rsp+0xE0]
00007cbcc2dd0937  add rsp, 0xF0
00007cbcc2dd093e  pop r11
00007cbcc2dd0940  pop r10
00007cbcc2dd0942  pop r9
00007cbcc2dd0944  pop r8
00007cbcc2dd0946  pop rsi
00007cbcc2dd0947  pop rdi
00007cbcc2dd0948  pop rdx
00007cbcc2dd0949  pop rcx
00007cbcc2dd094a  pop rax
00007cbcc2dd094b  add rsp, 0x08
00007cbcc2dd094f  jmp 0x00007CBCC2DCF91A
00007cbcc2dd0954  sub rsp, 0x08
00007cbcc2dd0958  push rax
00007cbcc2dd0959  push rcx
00007cbcc2dd095a  push rdx
00007cbcc2dd095b  push rdi
00007cbcc2dd095c  push rsi
00007cbcc2dd095d  push r8
00007cbcc2dd095f  push r9
00007cbcc2dd0961  push r10
00007cbcc2dd0963  push r11
00007cbcc2dd0965  sub rsp, 0xF0
00007cbcc2dd096c  vmovaps [rsp], xmm0
00007cbcc2dd0971  vmovaps [rsp+0x10], xmm1
00007cbcc2dd0977  vmovaps [rsp+0x20], xmm2
00007cbcc2dd097d  vmovaps [rsp+0x30], xmm3
00007cbcc2dd0983  vmovaps [rsp+0x40], xmm4
00007cbcc2dd0989  vmovaps [rsp+0x50], xmm5
00007cbcc2dd098f  vmovaps [rsp+0x60], xmm6
00007cbcc2dd0995  vmovaps [rsp+0x70], xmm7
00007cbcc2dd099b  vmovaps [rsp+0x80], xmm8
00007cbcc2dd09a4  vmovaps [rsp+0x90], xmm10
00007cbcc2dd09ad  vmovaps [rsp+0xA0], xmm11
00007cbcc2dd09b6  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd09bf  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd09c8  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd09d1  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd09da  sub rsp, 0x40
00007cbcc2dd09de  lea rdi, [rsp]
00007cbcc2dd09e2  lea rsi, [rsp+0x10]
00007cbcc2dd09e7  lea rdx, [rsp+0x20]
00007cbcc2dd09ec  lea rcx, [rsp+0x30]
00007cbcc2dd09f1  mov r8d, 0x00
00007cbcc2dd09f7  lea r9, [r15+0x3A8]
00007cbcc2dd09fe  movaps [rdi], xmm9
00007cbcc2dd0a02  movaps [rsi], xmm14
00007cbcc2dd0a06  movaps [rdx], xmm13
00007cbcc2dd0a0a  movaps [rcx], xmm1
00007cbcc2dd0a0d  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd0a17  call rax
00007cbcc2dd0a19  movaps xmm9, [rsp]
00007cbcc2dd0a1e  add rsp, 0x40
00007cbcc2dd0a22  vmovaps xmm0, [rsp]
00007cbcc2dd0a27  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd0a2d  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd0a33  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd0a39  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd0a3f  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd0a45  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd0a4b  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd0a51  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd0a5a  vmovaps xmm10, [rsp+0x90]
00007cbcc2dd0a63  vmovaps xmm11, [rsp+0xA0]
00007cbcc2dd0a6c  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd0a75  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd0a7e  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd0a87  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd0a90  add rsp, 0xF0
00007cbcc2dd0a97  pop r11
00007cbcc2dd0a99  pop r10
00007cbcc2dd0a9b  pop r9
00007cbcc2dd0a9d  pop r8
00007cbcc2dd0a9f  pop rsi
00007cbcc2dd0aa0  pop rdi
00007cbcc2dd0aa1  pop rdx
00007cbcc2dd0aa2  pop rcx
00007cbcc2dd0aa3  pop rax
00007cbcc2dd0aa4  add rsp, 0x08
00007cbcc2dd0aa8  jmp 0x00007CBCC2DCF955
00007cbcc2dd0aad  sub rsp, 0x08
00007cbcc2dd0ab1  push rax
00007cbcc2dd0ab2  push rcx
00007cbcc2dd0ab3  push rdx
00007cbcc2dd0ab4  push rdi
00007cbcc2dd0ab5  push rsi
00007cbcc2dd0ab6  push r8
00007cbcc2dd0ab8  push r9
00007cbcc2dd0aba  push r10
00007cbcc2dd0abc  push r11
00007cbcc2dd0abe  sub rsp, 0xF0
00007cbcc2dd0ac5  vmovaps [rsp], xmm0
00007cbcc2dd0aca  vmovaps [rsp+0x10], xmm1
00007cbcc2dd0ad0  vmovaps [rsp+0x20], xmm2
00007cbcc2dd0ad6  vmovaps [rsp+0x30], xmm3
00007cbcc2dd0adc  vmovaps [rsp+0x40], xmm4
00007cbcc2dd0ae2  vmovaps [rsp+0x50], xmm5
00007cbcc2dd0ae8  vmovaps [rsp+0x60], xmm6
00007cbcc2dd0aee  vmovaps [rsp+0x70], xmm7
00007cbcc2dd0af4  vmovaps [rsp+0x80], xmm8
00007cbcc2dd0afd  vmovaps [rsp+0x90], xmm9
00007cbcc2dd0b06  vmovaps [rsp+0xA0], xmm10
00007cbcc2dd0b0f  vmovaps [rsp+0xB0], xmm11
00007cbcc2dd0b18  vmovaps [rsp+0xC0], xmm12
00007cbcc2dd0b21  vmovaps [rsp+0xD0], xmm13
00007cbcc2dd0b2a  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd0b33  sub rsp, 0x40
00007cbcc2dd0b37  lea rdi, [rsp]
00007cbcc2dd0b3b  lea rsi, [rsp+0x10]
00007cbcc2dd0b40  lea rdx, [rsp+0x20]
00007cbcc2dd0b45  lea rcx, [rsp+0x30]
00007cbcc2dd0b4a  mov r8d, 0x00
00007cbcc2dd0b50  lea r9, [r15+0x3A8]
00007cbcc2dd0b57  movaps [rdi], xmm14
00007cbcc2dd0b5b  movaps [rsi], xmm15
00007cbcc2dd0b5f  movaps [rdx], xmm8
00007cbcc2dd0b63  movaps [rcx], xmm1
00007cbcc2dd0b66  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd0b70  call rax
00007cbcc2dd0b72  movaps xmm14, [rsp]
00007cbcc2dd0b77  add rsp, 0x40
00007cbcc2dd0b7b  vmovaps xmm0, [rsp]
00007cbcc2dd0b80  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd0b86  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd0b8c  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd0b92  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd0b98  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd0b9e  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd0ba4  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd0baa  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd0bb3  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd0bbc  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dd0bc5  vmovaps xmm11, [rsp+0xB0]
00007cbcc2dd0bce  vmovaps xmm12, [rsp+0xC0]
00007cbcc2dd0bd7  vmovaps xmm13, [rsp+0xD0]
00007cbcc2dd0be0  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd0be9  add rsp, 0xF0
00007cbcc2dd0bf0  pop r11
00007cbcc2dd0bf2  pop r10
00007cbcc2dd0bf4  pop r9
00007cbcc2dd0bf6  pop r8
00007cbcc2dd0bf8  pop rsi
00007cbcc2dd0bf9  pop rdi
00007cbcc2dd0bfa  pop rdx
00007cbcc2dd0bfb  pop rcx
00007cbcc2dd0bfc  pop rax
00007cbcc2dd0bfd  add rsp, 0x08
00007cbcc2dd0c01  jmp 0x00007CBCC2DCF984
00007cbcc2dd0c06  sub rsp, 0x08
00007cbcc2dd0c0a  push rax
00007cbcc2dd0c0b  push rcx
00007cbcc2dd0c0c  push rdx
00007cbcc2dd0c0d  push rdi
00007cbcc2dd0c0e  push rsi
00007cbcc2dd0c0f  push r8
00007cbcc2dd0c11  push r9
00007cbcc2dd0c13  push r10
00007cbcc2dd0c15  push r11
00007cbcc2dd0c17  sub rsp, 0xF0
00007cbcc2dd0c1e  vmovaps [rsp], xmm0
00007cbcc2dd0c23  vmovaps [rsp+0x10], xmm1
00007cbcc2dd0c29  vmovaps [rsp+0x20], xmm2
00007cbcc2dd0c2f  vmovaps [rsp+0x30], xmm3
00007cbcc2dd0c35  vmovaps [rsp+0x40], xmm4
00007cbcc2dd0c3b  vmovaps [rsp+0x50], xmm5
00007cbcc2dd0c41  vmovaps [rsp+0x60], xmm6
00007cbcc2dd0c47  vmovaps [rsp+0x70], xmm7
00007cbcc2dd0c4d  vmovaps [rsp+0x80], xmm8
00007cbcc2dd0c56  vmovaps [rsp+0x90], xmm9
00007cbcc2dd0c5f  vmovaps [rsp+0xA0], xmm10
00007cbcc2dd0c68  vmovaps [rsp+0xB0], xmm11
00007cbcc2dd0c71  vmovaps [rsp+0xC0], xmm12
00007cbcc2dd0c7a  vmovaps [rsp+0xD0], xmm13
00007cbcc2dd0c83  vmovaps [rsp+0xE0], xmm14
00007cbcc2dd0c8c  sub rsp, 0x40
00007cbcc2dd0c90  lea rdi, [rsp]
00007cbcc2dd0c94  lea rsi, [rsp+0x10]
00007cbcc2dd0c99  lea rdx, [rsp+0x20]
00007cbcc2dd0c9e  lea rcx, [rsp+0x30]
00007cbcc2dd0ca3  mov r8d, 0x00
00007cbcc2dd0ca9  lea r9, [r15+0x3A8]
00007cbcc2dd0cb0  movaps [rdi], xmm15
00007cbcc2dd0cb4  movaps [rsi], xmm12
00007cbcc2dd0cb8  movaps [rdx], xmm13
00007cbcc2dd0cbc  movaps [rcx], xmm1
00007cbcc2dd0cbf  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd0cc9  call rax
00007cbcc2dd0ccb  movaps xmm15, [rsp]
00007cbcc2dd0cd0  add rsp, 0x40
00007cbcc2dd0cd4  vmovaps xmm0, [rsp]
00007cbcc2dd0cd9  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd0cdf  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd0ce5  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd0ceb  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd0cf1  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd0cf7  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd0cfd  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd0d03  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd0d0c  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd0d15  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dd0d1e  vmovaps xmm11, [rsp+0xB0]
00007cbcc2dd0d27  vmovaps xmm12, [rsp+0xC0]
00007cbcc2dd0d30  vmovaps xmm13, [rsp+0xD0]
00007cbcc2dd0d39  vmovaps xmm14, [rsp+0xE0]
00007cbcc2dd0d42  add rsp, 0xF0
00007cbcc2dd0d49  pop r11
00007cbcc2dd0d4b  pop r10
00007cbcc2dd0d4d  pop r9
00007cbcc2dd0d4f  pop r8
00007cbcc2dd0d51  pop rsi
00007cbcc2dd0d52  pop rdi
00007cbcc2dd0d53  pop rdx
00007cbcc2dd0d54  pop rcx
00007cbcc2dd0d55  pop rax
00007cbcc2dd0d56  add rsp, 0x08
00007cbcc2dd0d5a  jmp 0x00007CBCC2DCF9D1
00007cbcc2dd0d5f  sub rsp, 0x08
00007cbcc2dd0d63  push rax
00007cbcc2dd0d64  push rcx
00007cbcc2dd0d65  push rdx
00007cbcc2dd0d66  push rdi
00007cbcc2dd0d67  push rsi
00007cbcc2dd0d68  push r8
00007cbcc2dd0d6a  push r9
00007cbcc2dd0d6c  push r10
00007cbcc2dd0d6e  push r11
00007cbcc2dd0d70  sub rsp, 0xF0
00007cbcc2dd0d77  vmovaps [rsp], xmm0
00007cbcc2dd0d7c  vmovaps [rsp+0x10], xmm1
00007cbcc2dd0d82  vmovaps [rsp+0x20], xmm2
00007cbcc2dd0d88  vmovaps [rsp+0x30], xmm3
00007cbcc2dd0d8e  vmovaps [rsp+0x40], xmm4
00007cbcc2dd0d94  vmovaps [rsp+0x50], xmm5
00007cbcc2dd0d9a  vmovaps [rsp+0x60], xmm6
00007cbcc2dd0da0  vmovaps [rsp+0x70], xmm7
00007cbcc2dd0da6  vmovaps [rsp+0x80], xmm8
00007cbcc2dd0daf  vmovaps [rsp+0x90], xmm9
00007cbcc2dd0db8  vmovaps [rsp+0xA0], xmm10
00007cbcc2dd0dc1  vmovaps [rsp+0xB0], xmm11
00007cbcc2dd0dca  vmovaps [rsp+0xC0], xmm12
00007cbcc2dd0dd3  vmovaps [rsp+0xD0], xmm13
00007cbcc2dd0ddc  vmovaps [rsp+0xE0], xmm14
00007cbcc2dd0de5  sub rsp, 0x40
00007cbcc2dd0de9  lea rdi, [rsp]
00007cbcc2dd0ded  lea rsi, [rsp+0x10]
00007cbcc2dd0df2  lea rdx, [rsp+0x20]
00007cbcc2dd0df7  lea rcx, [rsp+0x30]
00007cbcc2dd0dfc  mov r8d, 0x00
00007cbcc2dd0e02  lea r9, [r15+0x3A8]
00007cbcc2dd0e09  movaps [rdi], xmm15
00007cbcc2dd0e0d  movaps [rsi], xmm3
00007cbcc2dd0e10  movaps [rdx], xmm1
00007cbcc2dd0e13  movaps [rcx], xmm8
00007cbcc2dd0e17  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd0e21  call rax
00007cbcc2dd0e23  movaps xmm15, [rsp]
00007cbcc2dd0e28  add rsp, 0x40
00007cbcc2dd0e2c  vmovaps xmm0, [rsp]
00007cbcc2dd0e31  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd0e37  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd0e3d  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd0e43  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd0e49  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd0e4f  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd0e55  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd0e5b  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd0e64  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd0e6d  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dd0e76  vmovaps xmm11, [rsp+0xB0]
00007cbcc2dd0e7f  vmovaps xmm12, [rsp+0xC0]
00007cbcc2dd0e88  vmovaps xmm13, [rsp+0xD0]
00007cbcc2dd0e91  vmovaps xmm14, [rsp+0xE0]
00007cbcc2dd0e9a  add rsp, 0xF0
00007cbcc2dd0ea1  pop r11
00007cbcc2dd0ea3  pop r10
00007cbcc2dd0ea5  pop r9
00007cbcc2dd0ea7  pop r8
00007cbcc2dd0ea9  pop rsi
00007cbcc2dd0eaa  pop rdi
00007cbcc2dd0eab  pop rdx
00007cbcc2dd0eac  pop rcx
00007cbcc2dd0ead  pop rax
00007cbcc2dd0eae  add rsp, 0x08
00007cbcc2dd0eb2  jmp 0x00007CBCC2DCFA82
00007cbcc2dd0eb7  sub rsp, 0x08
00007cbcc2dd0ebb  push rax
00007cbcc2dd0ebc  push rcx
00007cbcc2dd0ebd  push rdx
00007cbcc2dd0ebe  push rdi
00007cbcc2dd0ebf  push rsi
00007cbcc2dd0ec0  push r8
00007cbcc2dd0ec2  push r9
00007cbcc2dd0ec4  push r10
00007cbcc2dd0ec6  push r11
00007cbcc2dd0ec8  sub rsp, 0xF0
00007cbcc2dd0ecf  vmovaps [rsp], xmm0
00007cbcc2dd0ed4  vmovaps [rsp+0x10], xmm1
00007cbcc2dd0eda  vmovaps [rsp+0x20], xmm2
00007cbcc2dd0ee0  vmovaps [rsp+0x30], xmm3
00007cbcc2dd0ee6  vmovaps [rsp+0x40], xmm4
00007cbcc2dd0eec  vmovaps [rsp+0x50], xmm5
00007cbcc2dd0ef2  vmovaps [rsp+0x60], xmm6
00007cbcc2dd0ef8  vmovaps [rsp+0x70], xmm7
00007cbcc2dd0efe  vmovaps [rsp+0x80], xmm9
00007cbcc2dd0f07  vmovaps [rsp+0x90], xmm10
00007cbcc2dd0f10  vmovaps [rsp+0xA0], xmm11
00007cbcc2dd0f19  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd0f22  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd0f2b  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd0f34  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd0f3d  sub rsp, 0x40
00007cbcc2dd0f41  lea rdi, [rsp]
00007cbcc2dd0f45  lea rsi, [rsp+0x10]
00007cbcc2dd0f4a  lea rdx, [rsp+0x20]
00007cbcc2dd0f4f  lea rcx, [rsp+0x30]
00007cbcc2dd0f54  mov r8d, 0x00
00007cbcc2dd0f5a  lea r9, [r15+0x3A8]
00007cbcc2dd0f61  movaps [rdi], xmm8
00007cbcc2dd0f65  movaps [rsi], xmm9
00007cbcc2dd0f69  movaps [rdx], xmm5
00007cbcc2dd0f6c  movaps [rcx], xmm1
00007cbcc2dd0f6f  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd0f79  call rax
00007cbcc2dd0f7b  movaps xmm8, [rsp]
00007cbcc2dd0f80  add rsp, 0x40
00007cbcc2dd0f84  vmovaps xmm0, [rsp]
00007cbcc2dd0f89  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd0f8f  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd0f95  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd0f9b  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd0fa1  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd0fa7  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd0fad  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd0fb3  vmovaps xmm9, [rsp+0x80]
00007cbcc2dd0fbc  vmovaps xmm10, [rsp+0x90]
00007cbcc2dd0fc5  vmovaps xmm11, [rsp+0xA0]
00007cbcc2dd0fce  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd0fd7  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd0fe0  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd0fe9  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd0ff2  add rsp, 0xF0
00007cbcc2dd0ff9  pop r11
00007cbcc2dd0ffb  pop r10
00007cbcc2dd0ffd  pop r9
00007cbcc2dd0fff  pop r8
00007cbcc2dd1001  pop rsi
00007cbcc2dd1002  pop rdi
00007cbcc2dd1003  pop rdx
00007cbcc2dd1004  pop rcx
00007cbcc2dd1005  pop rax
00007cbcc2dd1006  add rsp, 0x08
00007cbcc2dd100a  jmp 0x00007CBCC2DCFAAB
00007cbcc2dd100f  sub rsp, 0x08
00007cbcc2dd1013  push rax
00007cbcc2dd1014  push rcx
00007cbcc2dd1015  push rdx
00007cbcc2dd1016  push rdi
00007cbcc2dd1017  push rsi
00007cbcc2dd1018  push r8
00007cbcc2dd101a  push r9
00007cbcc2dd101c  push r10
00007cbcc2dd101e  push r11
00007cbcc2dd1020  sub rsp, 0xF0
00007cbcc2dd1027  vmovaps [rsp], xmm0
00007cbcc2dd102c  vmovaps [rsp+0x10], xmm1
00007cbcc2dd1032  vmovaps [rsp+0x20], xmm2
00007cbcc2dd1038  vmovaps [rsp+0x30], xmm3
00007cbcc2dd103e  vmovaps [rsp+0x40], xmm4
00007cbcc2dd1044  vmovaps [rsp+0x50], xmm6
00007cbcc2dd104a  vmovaps [rsp+0x60], xmm7
00007cbcc2dd1050  vmovaps [rsp+0x70], xmm8
00007cbcc2dd1056  vmovaps [rsp+0x80], xmm9
00007cbcc2dd105f  vmovaps [rsp+0x90], xmm10
00007cbcc2dd1068  vmovaps [rsp+0xA0], xmm11
00007cbcc2dd1071  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd107a  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd1083  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd108c  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd1095  sub rsp, 0x40
00007cbcc2dd1099  lea rdi, [rsp]
00007cbcc2dd109d  lea rsi, [rsp+0x10]
00007cbcc2dd10a2  lea rdx, [rsp+0x20]
00007cbcc2dd10a7  lea rcx, [rsp+0x30]
00007cbcc2dd10ac  mov r8d, 0x00
00007cbcc2dd10b2  lea r9, [r15+0x3A8]
00007cbcc2dd10b9  movaps [rdi], xmm5
00007cbcc2dd10bc  movaps [rsi], xmm14
00007cbcc2dd10c0  movaps [rdx], xmm9
00007cbcc2dd10c4  movaps [rcx], xmm1
00007cbcc2dd10c7  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd10d1  call rax
00007cbcc2dd10d3  movaps xmm5, [rsp]
00007cbcc2dd10d7  add rsp, 0x40
00007cbcc2dd10db  vmovaps xmm0, [rsp]
00007cbcc2dd10e0  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd10e6  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd10ec  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd10f2  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd10f8  vmovaps xmm6, [rsp+0x50]
00007cbcc2dd10fe  vmovaps xmm7, [rsp+0x60]
00007cbcc2dd1104  vmovaps xmm8, [rsp+0x70]
00007cbcc2dd110a  vmovaps xmm9, [rsp+0x80]
00007cbcc2dd1113  vmovaps xmm10, [rsp+0x90]
00007cbcc2dd111c  vmovaps xmm11, [rsp+0xA0]
00007cbcc2dd1125  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd112e  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd1137  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd1140  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd1149  add rsp, 0xF0
00007cbcc2dd1150  pop r11
00007cbcc2dd1152  pop r10
00007cbcc2dd1154  pop r9
00007cbcc2dd1156  pop r8
00007cbcc2dd1158  pop rsi
00007cbcc2dd1159  pop rdi
00007cbcc2dd115a  pop rdx
00007cbcc2dd115b  pop rcx
00007cbcc2dd115c  pop rax
00007cbcc2dd115d  add rsp, 0x08
00007cbcc2dd1161  jmp 0x00007CBCC2DCFADF
00007cbcc2dd1166  sub rsp, 0x08
00007cbcc2dd116a  push rax
00007cbcc2dd116b  push rcx
00007cbcc2dd116c  push rdx
00007cbcc2dd116d  push rdi
00007cbcc2dd116e  push rsi
00007cbcc2dd116f  push r8
00007cbcc2dd1171  push r9
00007cbcc2dd1173  push r10
00007cbcc2dd1175  push r11
00007cbcc2dd1177  sub rsp, 0xF0
00007cbcc2dd117e  vmovaps [rsp], xmm0
00007cbcc2dd1183  vmovaps [rsp+0x10], xmm1
00007cbcc2dd1189  vmovaps [rsp+0x20], xmm2
00007cbcc2dd118f  vmovaps [rsp+0x30], xmm3
00007cbcc2dd1195  vmovaps [rsp+0x40], xmm4
00007cbcc2dd119b  vmovaps [rsp+0x50], xmm5
00007cbcc2dd11a1  vmovaps [rsp+0x60], xmm6
00007cbcc2dd11a7  vmovaps [rsp+0x70], xmm7
00007cbcc2dd11ad  vmovaps [rsp+0x80], xmm8
00007cbcc2dd11b6  vmovaps [rsp+0x90], xmm10
00007cbcc2dd11bf  vmovaps [rsp+0xA0], xmm11
00007cbcc2dd11c8  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd11d1  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd11da  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd11e3  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd11ec  sub rsp, 0x40
00007cbcc2dd11f0  lea rdi, [rsp]
00007cbcc2dd11f4  lea rsi, [rsp+0x10]
00007cbcc2dd11f9  lea rdx, [rsp+0x20]
00007cbcc2dd11fe  lea rcx, [rsp+0x30]
00007cbcc2dd1203  mov r8d, 0x00
00007cbcc2dd1209  lea r9, [r15+0x3A8]
00007cbcc2dd1210  movaps [rdi], xmm9
00007cbcc2dd1214  movaps [rsi], xmm14
00007cbcc2dd1218  movaps [rdx], xmm4
00007cbcc2dd121b  movaps [rcx], xmm1
00007cbcc2dd121e  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd1228  call rax
00007cbcc2dd122a  movaps xmm9, [rsp]
00007cbcc2dd122f  add rsp, 0x40
00007cbcc2dd1233  vmovaps xmm0, [rsp]
00007cbcc2dd1238  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd123e  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd1244  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd124a  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd1250  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd1256  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd125c  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd1262  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd126b  vmovaps xmm10, [rsp+0x90]
00007cbcc2dd1274  vmovaps xmm11, [rsp+0xA0]
00007cbcc2dd127d  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd1286  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd128f  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd1298  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd12a1  add rsp, 0xF0
00007cbcc2dd12a8  pop r11
00007cbcc2dd12aa  pop r10
00007cbcc2dd12ac  pop r9
00007cbcc2dd12ae  pop r8
00007cbcc2dd12b0  pop rsi
00007cbcc2dd12b1  pop rdi
00007cbcc2dd12b2  pop rdx
00007cbcc2dd12b3  pop rcx
00007cbcc2dd12b4  pop rax
00007cbcc2dd12b5  add rsp, 0x08
00007cbcc2dd12b9  jmp 0x00007CBCC2DCFB0E
00007cbcc2dd12be  sub rsp, 0x08
00007cbcc2dd12c2  push rax
00007cbcc2dd12c3  push rcx
00007cbcc2dd12c4  push rdx
00007cbcc2dd12c5  push rdi
00007cbcc2dd12c6  push rsi
00007cbcc2dd12c7  push r8
00007cbcc2dd12c9  push r9
00007cbcc2dd12cb  push r10
00007cbcc2dd12cd  push r11
00007cbcc2dd12cf  sub rsp, 0xF0
00007cbcc2dd12d6  vmovaps [rsp], xmm0
00007cbcc2dd12db  vmovaps [rsp+0x10], xmm1
00007cbcc2dd12e1  vmovaps [rsp+0x20], xmm3
00007cbcc2dd12e7  vmovaps [rsp+0x30], xmm4
00007cbcc2dd12ed  vmovaps [rsp+0x40], xmm5
00007cbcc2dd12f3  vmovaps [rsp+0x50], xmm6
00007cbcc2dd12f9  vmovaps [rsp+0x60], xmm7
00007cbcc2dd12ff  vmovaps [rsp+0x70], xmm8
00007cbcc2dd1305  vmovaps [rsp+0x80], xmm9
00007cbcc2dd130e  vmovaps [rsp+0x90], xmm10
00007cbcc2dd1317  vmovaps [rsp+0xA0], xmm11
00007cbcc2dd1320  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd1329  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd1332  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd133b  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd1344  sub rsp, 0x40
00007cbcc2dd1348  lea rdi, [rsp]
00007cbcc2dd134c  lea rsi, [rsp+0x10]
00007cbcc2dd1351  lea rdx, [rsp+0x20]
00007cbcc2dd1356  lea rcx, [rsp+0x30]
00007cbcc2dd135b  mov r8d, 0x00
00007cbcc2dd1361  lea r9, [r15+0x3A8]
00007cbcc2dd1368  movaps [rdi], xmm2
00007cbcc2dd136b  movaps [rsi], xmm8
00007cbcc2dd136f  movaps [rdx], xmm13
00007cbcc2dd1373  movaps [rcx], xmm3
00007cbcc2dd1376  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd1380  call rax
00007cbcc2dd1382  movaps xmm2, [rsp]
00007cbcc2dd1386  add rsp, 0x40
00007cbcc2dd138a  vmovaps xmm0, [rsp]
00007cbcc2dd138f  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd1395  vmovaps xmm3, [rsp+0x20]
00007cbcc2dd139b  vmovaps xmm4, [rsp+0x30]
00007cbcc2dd13a1  vmovaps xmm5, [rsp+0x40]
00007cbcc2dd13a7  vmovaps xmm6, [rsp+0x50]
00007cbcc2dd13ad  vmovaps xmm7, [rsp+0x60]
00007cbcc2dd13b3  vmovaps xmm8, [rsp+0x70]
00007cbcc2dd13b9  vmovaps xmm9, [rsp+0x80]
00007cbcc2dd13c2  vmovaps xmm10, [rsp+0x90]
00007cbcc2dd13cb  vmovaps xmm11, [rsp+0xA0]
00007cbcc2dd13d4  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd13dd  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd13e6  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd13ef  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd13f8  add rsp, 0xF0
00007cbcc2dd13ff  pop r11
00007cbcc2dd1401  pop r10
00007cbcc2dd1403  pop r9
00007cbcc2dd1405  pop r8
00007cbcc2dd1407  pop rsi
00007cbcc2dd1408  pop rdi
00007cbcc2dd1409  pop rdx
00007cbcc2dd140a  pop rcx
00007cbcc2dd140b  pop rax
00007cbcc2dd140c  add rsp, 0x08
00007cbcc2dd1410  jmp 0x00007CBCC2DCFB8C
00007cbcc2dd1415  sub rsp, 0x08
00007cbcc2dd1419  push rax
00007cbcc2dd141a  push rcx
00007cbcc2dd141b  push rdx
00007cbcc2dd141c  push rdi
00007cbcc2dd141d  push rsi
00007cbcc2dd141e  push r8
00007cbcc2dd1420  push r9
00007cbcc2dd1422  push r10
00007cbcc2dd1424  push r11
00007cbcc2dd1426  sub rsp, 0xF0
00007cbcc2dd142d  vmovaps [rsp], xmm0
00007cbcc2dd1432  vmovaps [rsp+0x10], xmm1
00007cbcc2dd1438  vmovaps [rsp+0x20], xmm2
00007cbcc2dd143e  vmovaps [rsp+0x30], xmm3
00007cbcc2dd1444  vmovaps [rsp+0x40], xmm4
00007cbcc2dd144a  vmovaps [rsp+0x50], xmm5
00007cbcc2dd1450  vmovaps [rsp+0x60], xmm6
00007cbcc2dd1456  vmovaps [rsp+0x70], xmm7
00007cbcc2dd145c  vmovaps [rsp+0x80], xmm9
00007cbcc2dd1465  vmovaps [rsp+0x90], xmm10
00007cbcc2dd146e  vmovaps [rsp+0xA0], xmm11
00007cbcc2dd1477  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd1480  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd1489  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd1492  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd149b  sub rsp, 0x40
00007cbcc2dd149f  lea rdi, [rsp]
00007cbcc2dd14a3  lea rsi, [rsp+0x10]
00007cbcc2dd14a8  lea rdx, [rsp+0x20]
00007cbcc2dd14ad  lea rcx, [rsp+0x30]
00007cbcc2dd14b2  mov r8d, 0x00
00007cbcc2dd14b8  lea r9, [r15+0x3A8]
00007cbcc2dd14bf  movaps [rdi], xmm8
00007cbcc2dd14c3  movaps [rsi], xmm15
00007cbcc2dd14c7  movaps [rdx], xmm13
00007cbcc2dd14cb  movaps [rcx], xmm1
00007cbcc2dd14ce  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd14d8  call rax
00007cbcc2dd14da  movaps xmm8, [rsp]
00007cbcc2dd14df  add rsp, 0x40
00007cbcc2dd14e3  vmovaps xmm0, [rsp]
00007cbcc2dd14e8  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd14ee  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd14f4  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd14fa  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd1500  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd1506  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd150c  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd1512  vmovaps xmm9, [rsp+0x80]
00007cbcc2dd151b  vmovaps xmm10, [rsp+0x90]
00007cbcc2dd1524  vmovaps xmm11, [rsp+0xA0]
00007cbcc2dd152d  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd1536  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd153f  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd1548  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd1551  add rsp, 0xF0
00007cbcc2dd1558  pop r11
00007cbcc2dd155a  pop r10
00007cbcc2dd155c  pop r9
00007cbcc2dd155e  pop r8
00007cbcc2dd1560  pop rsi
00007cbcc2dd1561  pop rdi
00007cbcc2dd1562  pop rdx
00007cbcc2dd1563  pop rcx
00007cbcc2dd1564  pop rax
00007cbcc2dd1565  add rsp, 0x08
00007cbcc2dd1569  jmp 0x00007CBCC2DCFBBB
00007cbcc2dd156e  call 0x00007CBCC2BFF430
00007cbcc2dd1573  jmp 0x00007CBCC2DCFBC8
00007cbcc2dd1578  sub rsp, 0x08
00007cbcc2dd157c  push rax
00007cbcc2dd157d  push rcx
00007cbcc2dd157e  push rdx
00007cbcc2dd157f  push rdi
00007cbcc2dd1580  push rsi
00007cbcc2dd1581  push r8
00007cbcc2dd1583  push r9
00007cbcc2dd1585  push r10
00007cbcc2dd1587  push r11
00007cbcc2dd1589  sub rsp, 0xF0
00007cbcc2dd1590  vmovaps [rsp], xmm0
00007cbcc2dd1595  vmovaps [rsp+0x10], xmm1
00007cbcc2dd159b  vmovaps [rsp+0x20], xmm2
00007cbcc2dd15a1  vmovaps [rsp+0x30], xmm3
00007cbcc2dd15a7  vmovaps [rsp+0x40], xmm4
00007cbcc2dd15ad  vmovaps [rsp+0x50], xmm5
00007cbcc2dd15b3  vmovaps [rsp+0x60], xmm6
00007cbcc2dd15b9  vmovaps [rsp+0x70], xmm7
00007cbcc2dd15bf  vmovaps [rsp+0x80], xmm8
00007cbcc2dd15c8  vmovaps [rsp+0x90], xmm9
00007cbcc2dd15d1  vmovaps [rsp+0xA0], xmm10
00007cbcc2dd15da  vmovaps [rsp+0xB0], xmm11
00007cbcc2dd15e3  vmovaps [rsp+0xC0], xmm12
00007cbcc2dd15ec  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd15f5  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd15fe  sub rsp, 0x40
00007cbcc2dd1602  lea rdi, [rsp]
00007cbcc2dd1606  lea rsi, [rsp+0x10]
00007cbcc2dd160b  lea rdx, [rsp+0x20]
00007cbcc2dd1610  lea rcx, [rsp+0x30]
00007cbcc2dd1615  mov r8d, 0x00
00007cbcc2dd161b  lea r9, [r15+0x3A8]
00007cbcc2dd1622  movaps [rdi], xmm13
00007cbcc2dd1626  movaps [rsi], xmm5
00007cbcc2dd1629  movaps [rdx], xmm11
00007cbcc2dd162d  movaps [rcx], xmm15
00007cbcc2dd1631  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd163b  call rax
00007cbcc2dd163d  movaps xmm13, [rsp]
00007cbcc2dd1642  add rsp, 0x40
00007cbcc2dd1646  vmovaps xmm0, [rsp]
00007cbcc2dd164b  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd1651  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd1657  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd165d  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd1663  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd1669  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd166f  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd1675  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd167e  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd1687  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dd1690  vmovaps xmm11, [rsp+0xB0]
00007cbcc2dd1699  vmovaps xmm12, [rsp+0xC0]
00007cbcc2dd16a2  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd16ab  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd16b4  add rsp, 0xF0
00007cbcc2dd16bb  pop r11
00007cbcc2dd16bd  pop r10
00007cbcc2dd16bf  pop r9
00007cbcc2dd16c1  pop r8
00007cbcc2dd16c3  pop rsi
00007cbcc2dd16c4  pop rdi
00007cbcc2dd16c5  pop rdx
00007cbcc2dd16c6  pop rcx
00007cbcc2dd16c7  pop rax
00007cbcc2dd16c8  add rsp, 0x08
00007cbcc2dd16cc  jmp 0x00007CBCC2DCFBF9
00007cbcc2dd16d1  sub rsp, 0x08
00007cbcc2dd16d5  push rax
00007cbcc2dd16d6  push rcx
00007cbcc2dd16d7  push rdx
00007cbcc2dd16d8  push rdi
00007cbcc2dd16d9  push rsi
00007cbcc2dd16da  push r8
00007cbcc2dd16dc  push r9
00007cbcc2dd16de  push r10
00007cbcc2dd16e0  push r11
00007cbcc2dd16e2  sub rsp, 0xF0
00007cbcc2dd16e9  vmovaps [rsp], xmm0
00007cbcc2dd16ee  vmovaps [rsp+0x10], xmm1
00007cbcc2dd16f4  vmovaps [rsp+0x20], xmm2
00007cbcc2dd16fa  vmovaps [rsp+0x30], xmm3
00007cbcc2dd1700  vmovaps [rsp+0x40], xmm4
00007cbcc2dd1706  vmovaps [rsp+0x50], xmm5
00007cbcc2dd170c  vmovaps [rsp+0x60], xmm6
00007cbcc2dd1712  vmovaps [rsp+0x70], xmm7
00007cbcc2dd1718  vmovaps [rsp+0x80], xmm8
00007cbcc2dd1721  vmovaps [rsp+0x90], xmm9
00007cbcc2dd172a  vmovaps [rsp+0xA0], xmm10
00007cbcc2dd1733  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd173c  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd1745  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd174e  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd1757  sub rsp, 0x40
00007cbcc2dd175b  lea rdi, [rsp]
00007cbcc2dd175f  lea rsi, [rsp+0x10]
00007cbcc2dd1764  lea rdx, [rsp+0x20]
00007cbcc2dd1769  lea rcx, [rsp+0x30]
00007cbcc2dd176e  mov r8d, 0x00
00007cbcc2dd1774  lea r9, [r15+0x3A8]
00007cbcc2dd177b  movaps [rdi], xmm11
00007cbcc2dd177f  movaps [rsi], xmm9
00007cbcc2dd1783  movaps [rdx], xmm4
00007cbcc2dd1786  movaps [rcx], xmm15
00007cbcc2dd178a  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd1794  call rax
00007cbcc2dd1796  movaps xmm11, [rsp]
00007cbcc2dd179b  add rsp, 0x40
00007cbcc2dd179f  vmovaps xmm0, [rsp]
00007cbcc2dd17a4  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd17aa  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd17b0  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd17b6  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd17bc  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd17c2  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd17c8  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd17ce  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd17d7  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd17e0  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dd17e9  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd17f2  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd17fb  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd1804  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd180d  add rsp, 0xF0
00007cbcc2dd1814  pop r11
00007cbcc2dd1816  pop r10
00007cbcc2dd1818  pop r9
00007cbcc2dd181a  pop r8
00007cbcc2dd181c  pop rsi
00007cbcc2dd181d  pop rdi
00007cbcc2dd181e  pop rdx
00007cbcc2dd181f  pop rcx
00007cbcc2dd1820  pop rax
00007cbcc2dd1821  add rsp, 0x08
00007cbcc2dd1825  jmp 0x00007CBCC2DCFC22
00007cbcc2dd182a  call 0x00007CBCC2C0E760
00007cbcc2dd182f  jmp 0x00007CBCC2DCFC45
00007cbcc2dd1834  call 0x00007CBCC2C07890
00007cbcc2dd1839  jmp 0x00007CBCC2DCFC4F
00007cbcc2dd183e  sub rsp, 0x08
00007cbcc2dd1842  push rax
00007cbcc2dd1843  push rcx
00007cbcc2dd1844  push rdx
00007cbcc2dd1845  push rdi
00007cbcc2dd1846  push rsi
00007cbcc2dd1847  push r8
00007cbcc2dd1849  push r9
00007cbcc2dd184b  push r10
00007cbcc2dd184d  push r11
00007cbcc2dd184f  sub rsp, 0xF0
00007cbcc2dd1856  vmovaps [rsp], xmm0
00007cbcc2dd185b  vmovaps [rsp+0x10], xmm1
00007cbcc2dd1861  vmovaps [rsp+0x20], xmm2
00007cbcc2dd1867  vmovaps [rsp+0x30], xmm3
00007cbcc2dd186d  vmovaps [rsp+0x40], xmm5
00007cbcc2dd1873  vmovaps [rsp+0x50], xmm6
00007cbcc2dd1879  vmovaps [rsp+0x60], xmm7
00007cbcc2dd187f  vmovaps [rsp+0x70], xmm8
00007cbcc2dd1885  vmovaps [rsp+0x80], xmm9
00007cbcc2dd188e  vmovaps [rsp+0x90], xmm10
00007cbcc2dd1897  vmovaps [rsp+0xA0], xmm11
00007cbcc2dd18a0  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd18a9  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd18b2  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd18bb  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd18c4  sub rsp, 0x40
00007cbcc2dd18c8  lea rdi, [rsp]
00007cbcc2dd18cc  lea rsi, [rsp+0x10]
00007cbcc2dd18d1  lea rdx, [rsp+0x20]
00007cbcc2dd18d6  lea rcx, [rsp+0x30]
00007cbcc2dd18db  mov r8d, 0x00
00007cbcc2dd18e1  lea r9, [r15+0x3A8]
00007cbcc2dd18e8  movaps [rdi], xmm4
00007cbcc2dd18eb  movaps [rsi], xmm2
00007cbcc2dd18ee  movaps [rdx], xmm14
00007cbcc2dd18f2  movaps [rcx], xmm5
00007cbcc2dd18f5  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd18ff  call rax
00007cbcc2dd1901  movaps xmm4, [rsp]
00007cbcc2dd1905  add rsp, 0x40
00007cbcc2dd1909  vmovaps xmm0, [rsp]
00007cbcc2dd190e  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd1914  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd191a  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd1920  vmovaps xmm5, [rsp+0x40]
00007cbcc2dd1926  vmovaps xmm6, [rsp+0x50]
00007cbcc2dd192c  vmovaps xmm7, [rsp+0x60]
00007cbcc2dd1932  vmovaps xmm8, [rsp+0x70]
00007cbcc2dd1938  vmovaps xmm9, [rsp+0x80]
00007cbcc2dd1941  vmovaps xmm10, [rsp+0x90]
00007cbcc2dd194a  vmovaps xmm11, [rsp+0xA0]
00007cbcc2dd1953  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd195c  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd1965  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd196e  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd1977  add rsp, 0xF0
00007cbcc2dd197e  pop r11
00007cbcc2dd1980  pop r10
00007cbcc2dd1982  pop r9
00007cbcc2dd1984  pop r8
00007cbcc2dd1986  pop rsi
00007cbcc2dd1987  pop rdi
00007cbcc2dd1988  pop rdx
00007cbcc2dd1989  pop rcx
00007cbcc2dd198a  pop rax
00007cbcc2dd198b  add rsp, 0x08
00007cbcc2dd198f  jmp 0x00007CBCC2DCFC86
00007cbcc2dd1994  sub rsp, 0x08
00007cbcc2dd1998  push rax
00007cbcc2dd1999  push rcx
00007cbcc2dd199a  push rdx
00007cbcc2dd199b  push rdi
00007cbcc2dd199c  push rsi
00007cbcc2dd199d  push r8
00007cbcc2dd199f  push r9
00007cbcc2dd19a1  push r10
00007cbcc2dd19a3  push r11
00007cbcc2dd19a5  sub rsp, 0xF0
00007cbcc2dd19ac  vmovaps [rsp], xmm0
00007cbcc2dd19b1  vmovaps [rsp+0x10], xmm1
00007cbcc2dd19b7  vmovaps [rsp+0x20], xmm2
00007cbcc2dd19bd  vmovaps [rsp+0x30], xmm3
00007cbcc2dd19c3  vmovaps [rsp+0x40], xmm4
00007cbcc2dd19c9  vmovaps [rsp+0x50], xmm6
00007cbcc2dd19cf  vmovaps [rsp+0x60], xmm7
00007cbcc2dd19d5  vmovaps [rsp+0x70], xmm8
00007cbcc2dd19db  vmovaps [rsp+0x80], xmm9
00007cbcc2dd19e4  vmovaps [rsp+0x90], xmm10
00007cbcc2dd19ed  vmovaps [rsp+0xA0], xmm11
00007cbcc2dd19f6  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd19ff  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd1a08  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd1a11  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd1a1a  sub rsp, 0x40
00007cbcc2dd1a1e  lea rdi, [rsp]
00007cbcc2dd1a22  lea rsi, [rsp+0x10]
00007cbcc2dd1a27  lea rdx, [rsp+0x20]
00007cbcc2dd1a2c  lea rcx, [rsp+0x30]
00007cbcc2dd1a31  mov r8d, 0x00
00007cbcc2dd1a37  lea r9, [r15+0x3A8]
00007cbcc2dd1a3e  movaps [rdi], xmm5
00007cbcc2dd1a41  movaps [rsi], xmm8
00007cbcc2dd1a45  movaps [rdx], xmm7
00007cbcc2dd1a48  movaps [rcx], xmm14
00007cbcc2dd1a4c  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd1a56  call rax
00007cbcc2dd1a58  movaps xmm5, [rsp]
00007cbcc2dd1a5c  add rsp, 0x40
00007cbcc2dd1a60  vmovaps xmm0, [rsp]
00007cbcc2dd1a65  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd1a6b  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd1a71  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd1a77  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd1a7d  vmovaps xmm6, [rsp+0x50]
00007cbcc2dd1a83  vmovaps xmm7, [rsp+0x60]
00007cbcc2dd1a89  vmovaps xmm8, [rsp+0x70]
00007cbcc2dd1a8f  vmovaps xmm9, [rsp+0x80]
00007cbcc2dd1a98  vmovaps xmm10, [rsp+0x90]
00007cbcc2dd1aa1  vmovaps xmm11, [rsp+0xA0]
00007cbcc2dd1aaa  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd1ab3  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd1abc  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd1ac5  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd1ace  add rsp, 0xF0
00007cbcc2dd1ad5  pop r11
00007cbcc2dd1ad7  pop r10
00007cbcc2dd1ad9  pop r9
00007cbcc2dd1adb  pop r8
00007cbcc2dd1add  pop rsi
00007cbcc2dd1ade  pop rdi
00007cbcc2dd1adf  pop rdx
00007cbcc2dd1ae0  pop rcx
00007cbcc2dd1ae1  pop rax
00007cbcc2dd1ae2  add rsp, 0x08
00007cbcc2dd1ae6  jmp 0x00007CBCC2DCFCAE
00007cbcc2dd1aeb  sub rsp, 0x08
00007cbcc2dd1aef  push rax
00007cbcc2dd1af0  push rcx
00007cbcc2dd1af1  push rdx
00007cbcc2dd1af2  push rdi
00007cbcc2dd1af3  push rsi
00007cbcc2dd1af4  push r8
00007cbcc2dd1af6  push r9
00007cbcc2dd1af8  push r10
00007cbcc2dd1afa  push r11
00007cbcc2dd1afc  sub rsp, 0xF0
00007cbcc2dd1b03  vmovaps [rsp], xmm0
00007cbcc2dd1b08  vmovaps [rsp+0x10], xmm1
00007cbcc2dd1b0e  vmovaps [rsp+0x20], xmm2
00007cbcc2dd1b14  vmovaps [rsp+0x30], xmm3
00007cbcc2dd1b1a  vmovaps [rsp+0x40], xmm4
00007cbcc2dd1b20  vmovaps [rsp+0x50], xmm5
00007cbcc2dd1b26  vmovaps [rsp+0x60], xmm6
00007cbcc2dd1b2c  vmovaps [rsp+0x70], xmm7
00007cbcc2dd1b32  vmovaps [rsp+0x80], xmm9
00007cbcc2dd1b3b  vmovaps [rsp+0x90], xmm10
00007cbcc2dd1b44  vmovaps [rsp+0xA0], xmm11
00007cbcc2dd1b4d  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd1b56  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd1b5f  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd1b68  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd1b71  sub rsp, 0x40
00007cbcc2dd1b75  lea rdi, [rsp]
00007cbcc2dd1b79  lea rsi, [rsp+0x10]
00007cbcc2dd1b7e  lea rdx, [rsp+0x20]
00007cbcc2dd1b83  lea rcx, [rsp+0x30]
00007cbcc2dd1b88  mov r8d, 0x00
00007cbcc2dd1b8e  lea r9, [r15+0x3A8]
00007cbcc2dd1b95  movaps [rdi], xmm8
00007cbcc2dd1b99  movaps [rsi], xmm13
00007cbcc2dd1b9d  movaps [rdx], xmm6
00007cbcc2dd1ba0  movaps [rcx], xmm14
00007cbcc2dd1ba4  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd1bae  call rax
00007cbcc2dd1bb0  movaps xmm8, [rsp]
00007cbcc2dd1bb5  add rsp, 0x40
00007cbcc2dd1bb9  vmovaps xmm0, [rsp]
00007cbcc2dd1bbe  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd1bc4  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd1bca  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd1bd0  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd1bd6  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd1bdc  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd1be2  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd1be8  vmovaps xmm9, [rsp+0x80]
00007cbcc2dd1bf1  vmovaps xmm10, [rsp+0x90]
00007cbcc2dd1bfa  vmovaps xmm11, [rsp+0xA0]
00007cbcc2dd1c03  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd1c0c  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd1c15  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd1c1e  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd1c27  add rsp, 0xF0
00007cbcc2dd1c2e  pop r11
00007cbcc2dd1c30  pop r10
00007cbcc2dd1c32  pop r9
00007cbcc2dd1c34  pop r8
00007cbcc2dd1c36  pop rsi
00007cbcc2dd1c37  pop rdi
00007cbcc2dd1c38  pop rdx
00007cbcc2dd1c39  pop rcx
00007cbcc2dd1c3a  pop rax
00007cbcc2dd1c3b  add rsp, 0x08
00007cbcc2dd1c3f  jmp 0x00007CBCC2DCFCD7
00007cbcc2dd1c44  sub rsp, 0x08
00007cbcc2dd1c48  push rax
00007cbcc2dd1c49  push rcx
00007cbcc2dd1c4a  push rdx
00007cbcc2dd1c4b  push rdi
00007cbcc2dd1c4c  push rsi
00007cbcc2dd1c4d  push r8
00007cbcc2dd1c4f  push r9
00007cbcc2dd1c51  push r10
00007cbcc2dd1c53  push r11
00007cbcc2dd1c55  sub rsp, 0xF0
00007cbcc2dd1c5c  vmovaps [rsp], xmm0
00007cbcc2dd1c61  vmovaps [rsp+0x10], xmm1
00007cbcc2dd1c67  vmovaps [rsp+0x20], xmm2
00007cbcc2dd1c6d  vmovaps [rsp+0x30], xmm3
00007cbcc2dd1c73  vmovaps [rsp+0x40], xmm4
00007cbcc2dd1c79  vmovaps [rsp+0x50], xmm5
00007cbcc2dd1c7f  vmovaps [rsp+0x60], xmm6
00007cbcc2dd1c85  vmovaps [rsp+0x70], xmm7
00007cbcc2dd1c8b  vmovaps [rsp+0x80], xmm8
00007cbcc2dd1c94  vmovaps [rsp+0x90], xmm9
00007cbcc2dd1c9d  vmovaps [rsp+0xA0], xmm10
00007cbcc2dd1ca6  vmovaps [rsp+0xB0], xmm11
00007cbcc2dd1caf  vmovaps [rsp+0xC0], xmm12
00007cbcc2dd1cb8  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd1cc1  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd1cca  sub rsp, 0x40
00007cbcc2dd1cce  lea rdi, [rsp]
00007cbcc2dd1cd2  lea rsi, [rsp+0x10]
00007cbcc2dd1cd7  lea rdx, [rsp+0x20]
00007cbcc2dd1cdc  lea rcx, [rsp+0x30]
00007cbcc2dd1ce1  mov r8d, 0x00
00007cbcc2dd1ce7  lea r9, [r15+0x3A8]
00007cbcc2dd1cee  movaps [rdi], xmm13
00007cbcc2dd1cf2  movaps [rsi], xmm11
00007cbcc2dd1cf6  movaps [rdx], xmm12
00007cbcc2dd1cfa  movaps [rcx], xmm14
00007cbcc2dd1cfe  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd1d08  call rax
00007cbcc2dd1d0a  movaps xmm13, [rsp]
00007cbcc2dd1d0f  add rsp, 0x40
00007cbcc2dd1d13  vmovaps xmm0, [rsp]
00007cbcc2dd1d18  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd1d1e  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd1d24  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd1d2a  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd1d30  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd1d36  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd1d3c  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd1d42  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd1d4b  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd1d54  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dd1d5d  vmovaps xmm11, [rsp+0xB0]
00007cbcc2dd1d66  vmovaps xmm12, [rsp+0xC0]
00007cbcc2dd1d6f  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd1d78  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd1d81  add rsp, 0xF0
00007cbcc2dd1d88  pop r11
00007cbcc2dd1d8a  pop r10
00007cbcc2dd1d8c  pop r9
00007cbcc2dd1d8e  pop r8
00007cbcc2dd1d90  pop rsi
00007cbcc2dd1d91  pop rdi
00007cbcc2dd1d92  pop rdx
00007cbcc2dd1d93  pop rcx
00007cbcc2dd1d94  pop rax
00007cbcc2dd1d95  add rsp, 0x08
00007cbcc2dd1d99  jmp 0x00007CBCC2DCFD00
00007cbcc2dd1d9e  call 0x00007CBCC2C0D4E0
00007cbcc2dd1da3  jmp 0x00007CBCC2DCFD0A
00007cbcc2dd1da8  call 0x00007CBCC2C0AFE0
00007cbcc2dd1dad  jmp 0x00007CBCC2DCFD14
00007cbcc2dd1db2  sub rsp, 0x08
00007cbcc2dd1db6  push rax
00007cbcc2dd1db7  push rcx
00007cbcc2dd1db8  push rdx
00007cbcc2dd1db9  push rdi
00007cbcc2dd1dba  push rsi
00007cbcc2dd1dbb  push r8
00007cbcc2dd1dbd  push r9
00007cbcc2dd1dbf  push r10
00007cbcc2dd1dc1  push r11
00007cbcc2dd1dc3  sub rsp, 0xF0
00007cbcc2dd1dca  vmovaps [rsp], xmm0
00007cbcc2dd1dcf  vmovaps [rsp+0x10], xmm1
00007cbcc2dd1dd5  vmovaps [rsp+0x20], xmm2
00007cbcc2dd1ddb  vmovaps [rsp+0x30], xmm3
00007cbcc2dd1de1  vmovaps [rsp+0x40], xmm4
00007cbcc2dd1de7  vmovaps [rsp+0x50], xmm5
00007cbcc2dd1ded  vmovaps [rsp+0x60], xmm6
00007cbcc2dd1df3  vmovaps [rsp+0x70], xmm8
00007cbcc2dd1df9  vmovaps [rsp+0x80], xmm9
00007cbcc2dd1e02  vmovaps [rsp+0x90], xmm10
00007cbcc2dd1e0b  vmovaps [rsp+0xA0], xmm11
00007cbcc2dd1e14  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd1e1d  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd1e26  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd1e2f  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd1e38  sub rsp, 0x40
00007cbcc2dd1e3c  lea rdi, [rsp]
00007cbcc2dd1e40  lea rsi, [rsp+0x10]
00007cbcc2dd1e45  lea rdx, [rsp+0x20]
00007cbcc2dd1e4a  lea rcx, [rsp+0x30]
00007cbcc2dd1e4f  mov r8d, 0x00
00007cbcc2dd1e55  lea r9, [r15+0x3A8]
00007cbcc2dd1e5c  movaps [rdi], xmm7
00007cbcc2dd1e5f  movaps [rsi], xmm4
00007cbcc2dd1e62  movaps [rdx], xmm9
00007cbcc2dd1e66  movaps [rcx], xmm11
00007cbcc2dd1e6a  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd1e74  call rax
00007cbcc2dd1e76  movaps xmm7, [rsp]
00007cbcc2dd1e7a  add rsp, 0x40
00007cbcc2dd1e7e  vmovaps xmm0, [rsp]
00007cbcc2dd1e83  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd1e89  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd1e8f  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd1e95  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd1e9b  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd1ea1  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd1ea7  vmovaps xmm8, [rsp+0x70]
00007cbcc2dd1ead  vmovaps xmm9, [rsp+0x80]
00007cbcc2dd1eb6  vmovaps xmm10, [rsp+0x90]
00007cbcc2dd1ebf  vmovaps xmm11, [rsp+0xA0]
00007cbcc2dd1ec8  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd1ed1  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd1eda  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd1ee3  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd1eec  add rsp, 0xF0
00007cbcc2dd1ef3  pop r11
00007cbcc2dd1ef5  pop r10
00007cbcc2dd1ef7  pop r9
00007cbcc2dd1ef9  pop r8
00007cbcc2dd1efb  pop rsi
00007cbcc2dd1efc  pop rdi
00007cbcc2dd1efd  pop rdx
00007cbcc2dd1efe  pop rcx
00007cbcc2dd1eff  pop rax
00007cbcc2dd1f00  add rsp, 0x08
00007cbcc2dd1f04  jmp 0x00007CBCC2DCFD4B
00007cbcc2dd1f09  sub rsp, 0x08
00007cbcc2dd1f0d  push rax
00007cbcc2dd1f0e  push rcx
00007cbcc2dd1f0f  push rdx
00007cbcc2dd1f10  push rdi
00007cbcc2dd1f11  push rsi
00007cbcc2dd1f12  push r8
00007cbcc2dd1f14  push r9
00007cbcc2dd1f16  push r10
00007cbcc2dd1f18  push r11
00007cbcc2dd1f1a  sub rsp, 0xF0
00007cbcc2dd1f21  vmovaps [rsp], xmm0
00007cbcc2dd1f26  vmovaps [rsp+0x10], xmm1
00007cbcc2dd1f2c  vmovaps [rsp+0x20], xmm2
00007cbcc2dd1f32  vmovaps [rsp+0x30], xmm3
00007cbcc2dd1f38  vmovaps [rsp+0x40], xmm4
00007cbcc2dd1f3e  vmovaps [rsp+0x50], xmm5
00007cbcc2dd1f44  vmovaps [rsp+0x60], xmm6
00007cbcc2dd1f4a  vmovaps [rsp+0x70], xmm7
00007cbcc2dd1f50  vmovaps [rsp+0x80], xmm8
00007cbcc2dd1f59  vmovaps [rsp+0x90], xmm10
00007cbcc2dd1f62  vmovaps [rsp+0xA0], xmm11
00007cbcc2dd1f6b  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd1f74  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd1f7d  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd1f86  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd1f8f  sub rsp, 0x40
00007cbcc2dd1f93  lea rdi, [rsp]
00007cbcc2dd1f97  lea rsi, [rsp+0x10]
00007cbcc2dd1f9c  lea rdx, [rsp+0x20]
00007cbcc2dd1fa1  lea rcx, [rsp+0x30]
00007cbcc2dd1fa6  mov r8d, 0x00
00007cbcc2dd1fac  lea r9, [r15+0x3A8]
00007cbcc2dd1fb3  movaps [rdi], xmm9
00007cbcc2dd1fb7  movaps [rsi], xmm5
00007cbcc2dd1fba  movaps [rdx], xmm14
00007cbcc2dd1fbe  movaps [rcx], xmm11
00007cbcc2dd1fc2  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd1fcc  call rax
00007cbcc2dd1fce  movaps xmm9, [rsp]
00007cbcc2dd1fd3  add rsp, 0x40
00007cbcc2dd1fd7  vmovaps xmm0, [rsp]
00007cbcc2dd1fdc  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd1fe2  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd1fe8  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd1fee  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd1ff4  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd1ffa  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd2000  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd2006  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd200f  vmovaps xmm10, [rsp+0x90]
00007cbcc2dd2018  vmovaps xmm11, [rsp+0xA0]
00007cbcc2dd2021  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd202a  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd2033  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd203c  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd2045  add rsp, 0xF0
00007cbcc2dd204c  pop r11
00007cbcc2dd204e  pop r10
00007cbcc2dd2050  pop r9
00007cbcc2dd2052  pop r8
00007cbcc2dd2054  pop rsi
00007cbcc2dd2055  pop rdi
00007cbcc2dd2056  pop rdx
00007cbcc2dd2057  pop rcx
00007cbcc2dd2058  pop rax
00007cbcc2dd2059  add rsp, 0x08
00007cbcc2dd205d  jmp 0x00007CBCC2DCFD74
00007cbcc2dd2062  sub rsp, 0x08
00007cbcc2dd2066  push rax
00007cbcc2dd2067  push rcx
00007cbcc2dd2068  push rdx
00007cbcc2dd2069  push rdi
00007cbcc2dd206a  push rsi
00007cbcc2dd206b  push r8
00007cbcc2dd206d  push r9
00007cbcc2dd206f  push r10
00007cbcc2dd2071  push r11
00007cbcc2dd2073  sub rsp, 0xF0
00007cbcc2dd207a  vmovaps [rsp], xmm0
00007cbcc2dd207f  vmovaps [rsp+0x10], xmm1
00007cbcc2dd2085  vmovaps [rsp+0x20], xmm2
00007cbcc2dd208b  vmovaps [rsp+0x30], xmm3
00007cbcc2dd2091  vmovaps [rsp+0x40], xmm4
00007cbcc2dd2097  vmovaps [rsp+0x50], xmm5
00007cbcc2dd209d  vmovaps [rsp+0x60], xmm6
00007cbcc2dd20a3  vmovaps [rsp+0x70], xmm7
00007cbcc2dd20a9  vmovaps [rsp+0x80], xmm8
00007cbcc2dd20b2  vmovaps [rsp+0x90], xmm9
00007cbcc2dd20bb  vmovaps [rsp+0xA0], xmm10
00007cbcc2dd20c4  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd20cd  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd20d6  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd20df  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd20e8  sub rsp, 0x40
00007cbcc2dd20ec  lea rdi, [rsp]
00007cbcc2dd20f0  lea rsi, [rsp+0x10]
00007cbcc2dd20f5  lea rdx, [rsp+0x20]
00007cbcc2dd20fa  lea rcx, [rsp+0x30]
00007cbcc2dd20ff  mov r8d, 0x00
00007cbcc2dd2105  lea r9, [r15+0x3A8]
00007cbcc2dd210c  movaps [rdi], xmm11
00007cbcc2dd2110  movaps [rsi], xmm8
00007cbcc2dd2114  movaps [rdx], xmm10
00007cbcc2dd2118  movaps [rcx], xmm14
00007cbcc2dd211c  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd2126  call rax
00007cbcc2dd2128  movaps xmm11, [rsp]
00007cbcc2dd212d  add rsp, 0x40
00007cbcc2dd2131  vmovaps xmm0, [rsp]
00007cbcc2dd2136  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd213c  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd2142  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd2148  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd214e  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd2154  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd215a  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd2160  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd2169  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd2172  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dd217b  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd2184  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd218d  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd2196  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd219f  add rsp, 0xF0
00007cbcc2dd21a6  pop r11
00007cbcc2dd21a8  pop r10
00007cbcc2dd21aa  pop r9
00007cbcc2dd21ac  pop r8
00007cbcc2dd21ae  pop rsi
00007cbcc2dd21af  pop rdi
00007cbcc2dd21b0  pop rdx
00007cbcc2dd21b1  pop rcx
00007cbcc2dd21b2  pop rax
00007cbcc2dd21b3  add rsp, 0x08
00007cbcc2dd21b7  jmp 0x00007CBCC2DCFD9D
00007cbcc2dd21bc  sub rsp, 0x08
00007cbcc2dd21c0  push rax
00007cbcc2dd21c1  push rcx
00007cbcc2dd21c2  push rdx
00007cbcc2dd21c3  push rdi
00007cbcc2dd21c4  push rsi
00007cbcc2dd21c5  push r8
00007cbcc2dd21c7  push r9
00007cbcc2dd21c9  push r10
00007cbcc2dd21cb  push r11
00007cbcc2dd21cd  sub rsp, 0xF0
00007cbcc2dd21d4  vmovaps [rsp], xmm0
00007cbcc2dd21d9  vmovaps [rsp+0x10], xmm1
00007cbcc2dd21df  vmovaps [rsp+0x20], xmm2
00007cbcc2dd21e5  vmovaps [rsp+0x30], xmm3
00007cbcc2dd21eb  vmovaps [rsp+0x40], xmm4
00007cbcc2dd21f1  vmovaps [rsp+0x50], xmm5
00007cbcc2dd21f7  vmovaps [rsp+0x60], xmm6
00007cbcc2dd21fd  vmovaps [rsp+0x70], xmm7
00007cbcc2dd2203  vmovaps [rsp+0x80], xmm8
00007cbcc2dd220c  vmovaps [rsp+0x90], xmm9
00007cbcc2dd2215  vmovaps [rsp+0xA0], xmm11
00007cbcc2dd221e  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd2227  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd2230  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd2239  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd2242  sub rsp, 0x40
00007cbcc2dd2246  lea rdi, [rsp]
00007cbcc2dd224a  lea rsi, [rsp+0x10]
00007cbcc2dd224f  lea rdx, [rsp+0x20]
00007cbcc2dd2254  lea rcx, [rsp+0x30]
00007cbcc2dd2259  mov r8d, 0x00
00007cbcc2dd225f  lea r9, [r15+0x3A8]
00007cbcc2dd2266  movaps [rdi], xmm10
00007cbcc2dd226a  movaps [rsi], xmm13
00007cbcc2dd226e  movaps [rdx], xmm15
00007cbcc2dd2272  movaps [rcx], xmm14
00007cbcc2dd2276  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd2280  call rax
00007cbcc2dd2282  movaps xmm10, [rsp]
00007cbcc2dd2287  add rsp, 0x40
00007cbcc2dd228b  vmovaps xmm0, [rsp]
00007cbcc2dd2290  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd2296  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd229c  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd22a2  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd22a8  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd22ae  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd22b4  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd22ba  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd22c3  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd22cc  vmovaps xmm11, [rsp+0xA0]
00007cbcc2dd22d5  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd22de  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd22e7  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd22f0  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd22f9  add rsp, 0xF0
00007cbcc2dd2300  pop r11
00007cbcc2dd2302  pop r10
00007cbcc2dd2304  pop r9
00007cbcc2dd2306  pop r8
00007cbcc2dd2308  pop rsi
00007cbcc2dd2309  pop rdi
00007cbcc2dd230a  pop rdx
00007cbcc2dd230b  pop rcx
00007cbcc2dd230c  pop rax
00007cbcc2dd230d  add rsp, 0x08
00007cbcc2dd2311  jmp 0x00007CBCC2DCFDC6
00007cbcc2dd2316  call 0x00007CBCC2C0E760
00007cbcc2dd231b  jmp 0x00007CBCC2DCFDD0
00007cbcc2dd2320  call 0x00007CBCC2C0D4E0
00007cbcc2dd2325  jmp 0x00007CBCC2DCFDDA
00007cbcc2dd232a  sub rsp, 0x08
00007cbcc2dd232e  push rax
00007cbcc2dd232f  push rcx
00007cbcc2dd2330  push rdx
00007cbcc2dd2331  push rdi
00007cbcc2dd2332  push rsi
00007cbcc2dd2333  push r8
00007cbcc2dd2335  push r9
00007cbcc2dd2337  push r10
00007cbcc2dd2339  push r11
00007cbcc2dd233b  sub rsp, 0xF0
00007cbcc2dd2342  vmovaps [rsp], xmm0
00007cbcc2dd2347  vmovaps [rsp+0x10], xmm1
00007cbcc2dd234d  vmovaps [rsp+0x20], xmm2
00007cbcc2dd2353  vmovaps [rsp+0x30], xmm3
00007cbcc2dd2359  vmovaps [rsp+0x40], xmm4
00007cbcc2dd235f  vmovaps [rsp+0x50], xmm5
00007cbcc2dd2365  vmovaps [rsp+0x60], xmm7
00007cbcc2dd236b  vmovaps [rsp+0x70], xmm8
00007cbcc2dd2371  vmovaps [rsp+0x80], xmm9
00007cbcc2dd237a  vmovaps [rsp+0x90], xmm10
00007cbcc2dd2383  vmovaps [rsp+0xA0], xmm11
00007cbcc2dd238c  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd2395  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd239e  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd23a7  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd23b0  sub rsp, 0x40
00007cbcc2dd23b4  lea rdi, [rsp]
00007cbcc2dd23b8  lea rsi, [rsp+0x10]
00007cbcc2dd23bd  lea rdx, [rsp+0x20]
00007cbcc2dd23c2  lea rcx, [rsp+0x30]
00007cbcc2dd23c7  mov r8d, 0x00
00007cbcc2dd23cd  lea r9, [r15+0x3A8]
00007cbcc2dd23d4  movaps [rdi], xmm6
00007cbcc2dd23d7  movaps [rsi], xmm7
00007cbcc2dd23da  movaps [rdx], xmm8
00007cbcc2dd23de  movaps [rcx], xmm13
00007cbcc2dd23e2  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd23ec  call rax
00007cbcc2dd23ee  movaps xmm6, [rsp]
00007cbcc2dd23f2  add rsp, 0x40
00007cbcc2dd23f6  vmovaps xmm0, [rsp]
00007cbcc2dd23fb  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd2401  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd2407  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd240d  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd2413  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd2419  vmovaps xmm7, [rsp+0x60]
00007cbcc2dd241f  vmovaps xmm8, [rsp+0x70]
00007cbcc2dd2425  vmovaps xmm9, [rsp+0x80]
00007cbcc2dd242e  vmovaps xmm10, [rsp+0x90]
00007cbcc2dd2437  vmovaps xmm11, [rsp+0xA0]
00007cbcc2dd2440  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd2449  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd2452  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd245b  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd2464  add rsp, 0xF0
00007cbcc2dd246b  pop r11
00007cbcc2dd246d  pop r10
00007cbcc2dd246f  pop r9
00007cbcc2dd2471  pop r8
00007cbcc2dd2473  pop rsi
00007cbcc2dd2474  pop rdi
00007cbcc2dd2475  pop rdx
00007cbcc2dd2476  pop rcx
00007cbcc2dd2477  pop rax
00007cbcc2dd2478  add rsp, 0x08
00007cbcc2dd247c  jmp 0x00007CBCC2DCFE04
00007cbcc2dd2481  sub rsp, 0x08
00007cbcc2dd2485  push rax
00007cbcc2dd2486  push rcx
00007cbcc2dd2487  push rdx
00007cbcc2dd2488  push rdi
00007cbcc2dd2489  push rsi
00007cbcc2dd248a  push r8
00007cbcc2dd248c  push r9
00007cbcc2dd248e  push r10
00007cbcc2dd2490  push r11
00007cbcc2dd2492  sub rsp, 0xF0
00007cbcc2dd2499  vmovaps [rsp], xmm0
00007cbcc2dd249e  vmovaps [rsp+0x10], xmm1
00007cbcc2dd24a4  vmovaps [rsp+0x20], xmm2
00007cbcc2dd24aa  vmovaps [rsp+0x30], xmm3
00007cbcc2dd24b0  vmovaps [rsp+0x40], xmm4
00007cbcc2dd24b6  vmovaps [rsp+0x50], xmm5
00007cbcc2dd24bc  vmovaps [rsp+0x60], xmm6
00007cbcc2dd24c2  vmovaps [rsp+0x70], xmm7
00007cbcc2dd24c8  vmovaps [rsp+0x80], xmm9
00007cbcc2dd24d1  vmovaps [rsp+0x90], xmm10
00007cbcc2dd24da  vmovaps [rsp+0xA0], xmm11
00007cbcc2dd24e3  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd24ec  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd24f5  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd24fe  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd2507  sub rsp, 0x40
00007cbcc2dd250b  lea rdi, [rsp]
00007cbcc2dd250f  lea rsi, [rsp+0x10]
00007cbcc2dd2514  lea rdx, [rsp+0x20]
00007cbcc2dd2519  lea rcx, [rsp+0x30]
00007cbcc2dd251e  mov r8d, 0x00
00007cbcc2dd2524  lea r9, [r15+0x3A8]
00007cbcc2dd252b  movaps [rdi], xmm8
00007cbcc2dd252f  movaps [rsi], xmm9
00007cbcc2dd2533  movaps [rdx], xmm1
00007cbcc2dd2536  movaps [rcx], xmm13
00007cbcc2dd253a  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd2544  call rax
00007cbcc2dd2546  movaps xmm8, [rsp]
00007cbcc2dd254b  add rsp, 0x40
00007cbcc2dd254f  vmovaps xmm0, [rsp]
00007cbcc2dd2554  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd255a  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd2560  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd2566  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd256c  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd2572  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd2578  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd257e  vmovaps xmm9, [rsp+0x80]
00007cbcc2dd2587  vmovaps xmm10, [rsp+0x90]
00007cbcc2dd2590  vmovaps xmm11, [rsp+0xA0]
00007cbcc2dd2599  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd25a2  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd25ab  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd25b4  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd25bd  add rsp, 0xF0
00007cbcc2dd25c4  pop r11
00007cbcc2dd25c6  pop r10
00007cbcc2dd25c8  pop r9
00007cbcc2dd25ca  pop r8
00007cbcc2dd25cc  pop rsi
00007cbcc2dd25cd  pop rdi
00007cbcc2dd25ce  pop rdx
00007cbcc2dd25cf  pop rcx
00007cbcc2dd25d0  pop rax
00007cbcc2dd25d1  add rsp, 0x08
00007cbcc2dd25d5  jmp 0x00007CBCC2DCFE2A
00007cbcc2dd25da  sub rsp, 0x08
00007cbcc2dd25de  push rax
00007cbcc2dd25df  push rcx
00007cbcc2dd25e0  push rdx
00007cbcc2dd25e1  push rdi
00007cbcc2dd25e2  push rsi
00007cbcc2dd25e3  push r8
00007cbcc2dd25e5  push r9
00007cbcc2dd25e7  push r10
00007cbcc2dd25e9  push r11
00007cbcc2dd25eb  sub rsp, 0xF0
00007cbcc2dd25f2  vmovaps [rsp], xmm0
00007cbcc2dd25f7  vmovaps [rsp+0x10], xmm1
00007cbcc2dd25fd  vmovaps [rsp+0x20], xmm2
00007cbcc2dd2603  vmovaps [rsp+0x30], xmm3
00007cbcc2dd2609  vmovaps [rsp+0x40], xmm4
00007cbcc2dd260f  vmovaps [rsp+0x50], xmm5
00007cbcc2dd2615  vmovaps [rsp+0x60], xmm6
00007cbcc2dd261b  vmovaps [rsp+0x70], xmm7
00007cbcc2dd2621  vmovaps [rsp+0x80], xmm8
00007cbcc2dd262a  vmovaps [rsp+0x90], xmm9
00007cbcc2dd2633  vmovaps [rsp+0xA0], xmm10
00007cbcc2dd263c  vmovaps [rsp+0xB0], xmm11
00007cbcc2dd2645  vmovaps [rsp+0xC0], xmm12
00007cbcc2dd264e  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd2657  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd2660  sub rsp, 0x40
00007cbcc2dd2664  lea rdi, [rsp]
00007cbcc2dd2668  lea rsi, [rsp+0x10]
00007cbcc2dd266d  lea rdx, [rsp+0x20]
00007cbcc2dd2672  lea rcx, [rsp+0x30]
00007cbcc2dd2677  mov r8d, 0x00
00007cbcc2dd267d  lea r9, [r15+0x3A8]
00007cbcc2dd2684  movaps [rdi], xmm13
00007cbcc2dd2688  movaps [rsi], xmm11
00007cbcc2dd268c  movaps [rdx], xmm12
00007cbcc2dd2690  movaps [rcx], xmm1
00007cbcc2dd2693  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd269d  call rax
00007cbcc2dd269f  movaps xmm13, [rsp]
00007cbcc2dd26a4  add rsp, 0x40
00007cbcc2dd26a8  vmovaps xmm0, [rsp]
00007cbcc2dd26ad  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd26b3  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd26b9  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd26bf  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd26c5  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd26cb  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd26d1  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd26d7  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd26e0  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd26e9  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dd26f2  vmovaps xmm11, [rsp+0xB0]
00007cbcc2dd26fb  vmovaps xmm12, [rsp+0xC0]
00007cbcc2dd2704  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd270d  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd2716  add rsp, 0xF0
00007cbcc2dd271d  pop r11
00007cbcc2dd271f  pop r10
00007cbcc2dd2721  pop r9
00007cbcc2dd2723  pop r8
00007cbcc2dd2725  pop rsi
00007cbcc2dd2726  pop rdi
00007cbcc2dd2727  pop rdx
00007cbcc2dd2728  pop rcx
00007cbcc2dd2729  pop rax
00007cbcc2dd272a  add rsp, 0x08
00007cbcc2dd272e  jmp 0x00007CBCC2DCFE50
00007cbcc2dd2733  sub rsp, 0x08
00007cbcc2dd2737  push rax
00007cbcc2dd2738  push rcx
00007cbcc2dd2739  push rdx
00007cbcc2dd273a  push rdi
00007cbcc2dd273b  push rsi
00007cbcc2dd273c  push r8
00007cbcc2dd273e  push r9
00007cbcc2dd2740  push r10
00007cbcc2dd2742  push r11
00007cbcc2dd2744  sub rsp, 0xF0
00007cbcc2dd274b  vmovaps [rsp], xmm0
00007cbcc2dd2750  vmovaps [rsp+0x10], xmm1
00007cbcc2dd2756  vmovaps [rsp+0x20], xmm2
00007cbcc2dd275c  vmovaps [rsp+0x30], xmm3
00007cbcc2dd2762  vmovaps [rsp+0x40], xmm4
00007cbcc2dd2768  vmovaps [rsp+0x50], xmm5
00007cbcc2dd276e  vmovaps [rsp+0x60], xmm6
00007cbcc2dd2774  vmovaps [rsp+0x70], xmm7
00007cbcc2dd277a  vmovaps [rsp+0x80], xmm8
00007cbcc2dd2783  vmovaps [rsp+0x90], xmm9
00007cbcc2dd278c  vmovaps [rsp+0xA0], xmm10
00007cbcc2dd2795  vmovaps [rsp+0xB0], xmm11
00007cbcc2dd279e  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd27a7  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd27b0  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd27b9  sub rsp, 0x40
00007cbcc2dd27bd  lea rdi, [rsp]
00007cbcc2dd27c1  lea rsi, [rsp+0x10]
00007cbcc2dd27c6  lea rdx, [rsp+0x20]
00007cbcc2dd27cb  lea rcx, [rsp+0x30]
00007cbcc2dd27d0  mov r8d, 0x00
00007cbcc2dd27d6  lea r9, [r15+0x3A8]
00007cbcc2dd27dd  movaps [rdi], xmm12
00007cbcc2dd27e1  movaps [rsi], xmm10
00007cbcc2dd27e5  movaps [rdx], xmm14
00007cbcc2dd27e9  movaps [rcx], xmm1
00007cbcc2dd27ec  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd27f6  call rax
00007cbcc2dd27f8  movaps xmm12, [rsp]
00007cbcc2dd27fd  add rsp, 0x40
00007cbcc2dd2801  vmovaps xmm0, [rsp]
00007cbcc2dd2806  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd280c  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd2812  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd2818  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd281e  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd2824  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd282a  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd2830  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd2839  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd2842  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dd284b  vmovaps xmm11, [rsp+0xB0]
00007cbcc2dd2854  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd285d  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd2866  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd286f  add rsp, 0xF0
00007cbcc2dd2876  pop r11
00007cbcc2dd2878  pop r10
00007cbcc2dd287a  pop r9
00007cbcc2dd287c  pop r8
00007cbcc2dd287e  pop rsi
00007cbcc2dd287f  pop rdi
00007cbcc2dd2880  pop rdx
00007cbcc2dd2881  pop rcx
00007cbcc2dd2882  pop rax
00007cbcc2dd2883  add rsp, 0x08
00007cbcc2dd2887  jmp 0x00007CBCC2DCFE76
00007cbcc2dd288c  call 0x00007CBCC2BFF430
00007cbcc2dd2891  jmp 0x00007CBCC2DCFE83
00007cbcc2dd2896  call 0x00007CBCC2C0D4E0
00007cbcc2dd289b  jmp 0x00007CBCC2DCFE90
00007cbcc2dd28a0  sub rsp, 0x08
00007cbcc2dd28a4  push rax
00007cbcc2dd28a5  push rcx
00007cbcc2dd28a6  push rdx
00007cbcc2dd28a7  push rdi
00007cbcc2dd28a8  push rsi
00007cbcc2dd28a9  push r8
00007cbcc2dd28ab  push r9
00007cbcc2dd28ad  push r10
00007cbcc2dd28af  push r11
00007cbcc2dd28b1  sub rsp, 0xF0
00007cbcc2dd28b8  vmovaps [rsp], xmm0
00007cbcc2dd28bd  vmovaps [rsp+0x10], xmm1
00007cbcc2dd28c3  vmovaps [rsp+0x20], xmm2
00007cbcc2dd28c9  vmovaps [rsp+0x30], xmm3
00007cbcc2dd28cf  vmovaps [rsp+0x40], xmm4
00007cbcc2dd28d5  vmovaps [rsp+0x50], xmm5
00007cbcc2dd28db  vmovaps [rsp+0x60], xmm6
00007cbcc2dd28e1  vmovaps [rsp+0x70], xmm7
00007cbcc2dd28e7  vmovaps [rsp+0x80], xmm8
00007cbcc2dd28f0  vmovaps [rsp+0x90], xmm9
00007cbcc2dd28f9  vmovaps [rsp+0xA0], xmm11
00007cbcc2dd2902  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd290b  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd2914  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd291d  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd2926  sub rsp, 0x40
00007cbcc2dd292a  lea rdi, [rsp]
00007cbcc2dd292e  lea rsi, [rsp+0x10]
00007cbcc2dd2933  lea rdx, [rsp+0x20]
00007cbcc2dd2938  lea rcx, [rsp+0x30]
00007cbcc2dd293d  mov r8d, 0x00
00007cbcc2dd2943  lea r9, [r15+0x3A8]
00007cbcc2dd294a  movaps [rdi], xmm10
00007cbcc2dd294e  movaps [rsi], xmm6
00007cbcc2dd2951  movaps [rdx], xmm15
00007cbcc2dd2955  movaps [rcx], xmm11
00007cbcc2dd2959  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd2963  call rax
00007cbcc2dd2965  movaps xmm10, [rsp]
00007cbcc2dd296a  add rsp, 0x40
00007cbcc2dd296e  vmovaps xmm0, [rsp]
00007cbcc2dd2973  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd2979  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd297f  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd2985  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd298b  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd2991  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd2997  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd299d  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd29a6  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd29af  vmovaps xmm11, [rsp+0xA0]
00007cbcc2dd29b8  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd29c1  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd29ca  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd29d3  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd29dc  add rsp, 0xF0
00007cbcc2dd29e3  pop r11
00007cbcc2dd29e5  pop r10
00007cbcc2dd29e7  pop r9
00007cbcc2dd29e9  pop r8
00007cbcc2dd29eb  pop rsi
00007cbcc2dd29ec  pop rdi
00007cbcc2dd29ed  pop rdx
00007cbcc2dd29ee  pop rcx
00007cbcc2dd29ef  pop rax
00007cbcc2dd29f0  add rsp, 0x08
00007cbcc2dd29f4  jmp 0x00007CBCC2DCFEC9
00007cbcc2dd29f9  call 0x00007CBCC2C0E760
00007cbcc2dd29fe  jmp 0x00007CBCC2DCFEDB
00007cbcc2dd2a03  sub rsp, 0x08
00007cbcc2dd2a07  push rax
00007cbcc2dd2a08  push rcx
00007cbcc2dd2a09  push rdx
00007cbcc2dd2a0a  push rdi
00007cbcc2dd2a0b  push rsi
00007cbcc2dd2a0c  push r8
00007cbcc2dd2a0e  push r9
00007cbcc2dd2a10  push r10
00007cbcc2dd2a12  push r11
00007cbcc2dd2a14  sub rsp, 0xF0
00007cbcc2dd2a1b  vmovaps [rsp], xmm0
00007cbcc2dd2a20  vmovaps [rsp+0x10], xmm1
00007cbcc2dd2a26  vmovaps [rsp+0x20], xmm2
00007cbcc2dd2a2c  vmovaps [rsp+0x30], xmm3
00007cbcc2dd2a32  vmovaps [rsp+0x40], xmm4
00007cbcc2dd2a38  vmovaps [rsp+0x50], xmm5
00007cbcc2dd2a3e  vmovaps [rsp+0x60], xmm6
00007cbcc2dd2a44  vmovaps [rsp+0x70], xmm7
00007cbcc2dd2a4a  vmovaps [rsp+0x80], xmm8
00007cbcc2dd2a53  vmovaps [rsp+0x90], xmm10
00007cbcc2dd2a5c  vmovaps [rsp+0xA0], xmm11
00007cbcc2dd2a65  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd2a6e  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd2a77  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd2a80  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd2a89  sub rsp, 0x40
00007cbcc2dd2a8d  lea rdi, [rsp]
00007cbcc2dd2a91  lea rsi, [rsp+0x10]
00007cbcc2dd2a96  lea rdx, [rsp+0x20]
00007cbcc2dd2a9b  lea rcx, [rsp+0x30]
00007cbcc2dd2aa0  mov r8d, 0x00
00007cbcc2dd2aa6  lea r9, [r15+0x3A8]
00007cbcc2dd2aad  movaps [rdi], xmm9
00007cbcc2dd2ab1  movaps [rsi], xmm8
00007cbcc2dd2ab5  movaps [rdx], xmm14
00007cbcc2dd2ab9  movaps [rcx], xmm11
00007cbcc2dd2abd  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd2ac7  call rax
00007cbcc2dd2ac9  movaps xmm9, [rsp]
00007cbcc2dd2ace  add rsp, 0x40
00007cbcc2dd2ad2  vmovaps xmm0, [rsp]
00007cbcc2dd2ad7  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd2add  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd2ae3  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd2ae9  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd2aef  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd2af5  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd2afb  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd2b01  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd2b0a  vmovaps xmm10, [rsp+0x90]
00007cbcc2dd2b13  vmovaps xmm11, [rsp+0xA0]
00007cbcc2dd2b1c  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd2b25  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd2b2e  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd2b37  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd2b40  add rsp, 0xF0
00007cbcc2dd2b47  pop r11
00007cbcc2dd2b49  pop r10
00007cbcc2dd2b4b  pop r9
00007cbcc2dd2b4d  pop r8
00007cbcc2dd2b4f  pop rsi
00007cbcc2dd2b50  pop rdi
00007cbcc2dd2b51  pop rdx
00007cbcc2dd2b52  pop rcx
00007cbcc2dd2b53  pop rax
00007cbcc2dd2b54  add rsp, 0x08
00007cbcc2dd2b58  jmp 0x00007CBCC2DCFF0C
00007cbcc2dd2b5d  sub rsp, 0x08
00007cbcc2dd2b61  push rax
00007cbcc2dd2b62  push rcx
00007cbcc2dd2b63  push rdx
00007cbcc2dd2b64  push rdi
00007cbcc2dd2b65  push rsi
00007cbcc2dd2b66  push r8
00007cbcc2dd2b68  push r9
00007cbcc2dd2b6a  push r10
00007cbcc2dd2b6c  push r11
00007cbcc2dd2b6e  sub rsp, 0xF0
00007cbcc2dd2b75  vmovaps [rsp], xmm0
00007cbcc2dd2b7a  vmovaps [rsp+0x10], xmm1
00007cbcc2dd2b80  vmovaps [rsp+0x20], xmm2
00007cbcc2dd2b86  vmovaps [rsp+0x30], xmm3
00007cbcc2dd2b8c  vmovaps [rsp+0x40], xmm4
00007cbcc2dd2b92  vmovaps [rsp+0x50], xmm5
00007cbcc2dd2b98  vmovaps [rsp+0x60], xmm6
00007cbcc2dd2b9e  vmovaps [rsp+0x70], xmm7
00007cbcc2dd2ba4  vmovaps [rsp+0x80], xmm8
00007cbcc2dd2bad  vmovaps [rsp+0x90], xmm9
00007cbcc2dd2bb6  vmovaps [rsp+0xA0], xmm10
00007cbcc2dd2bbf  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd2bc8  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd2bd1  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd2bda  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd2be3  sub rsp, 0x40
00007cbcc2dd2be7  lea rdi, [rsp]
00007cbcc2dd2beb  lea rsi, [rsp+0x10]
00007cbcc2dd2bf0  lea rdx, [rsp+0x20]
00007cbcc2dd2bf5  lea rcx, [rsp+0x30]
00007cbcc2dd2bfa  mov r8d, 0x00
00007cbcc2dd2c00  lea r9, [r15+0x3A8]
00007cbcc2dd2c07  movaps [rdi], xmm11
00007cbcc2dd2c0b  movaps [rsi], xmm13
00007cbcc2dd2c0f  movaps [rdx], xmm1
00007cbcc2dd2c12  movaps [rcx], xmm14
00007cbcc2dd2c16  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd2c20  call rax
00007cbcc2dd2c22  movaps xmm11, [rsp]
00007cbcc2dd2c27  add rsp, 0x40
00007cbcc2dd2c2b  vmovaps xmm0, [rsp]
00007cbcc2dd2c30  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd2c36  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd2c3c  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd2c42  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd2c48  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd2c4e  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd2c54  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd2c5a  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd2c63  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd2c6c  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dd2c75  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd2c7e  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd2c87  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd2c90  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd2c99  add rsp, 0xF0
00007cbcc2dd2ca0  pop r11
00007cbcc2dd2ca2  pop r10
00007cbcc2dd2ca4  pop r9
00007cbcc2dd2ca6  pop r8
00007cbcc2dd2ca8  pop rsi
00007cbcc2dd2ca9  pop rdi
00007cbcc2dd2caa  pop rdx
00007cbcc2dd2cab  pop rcx
00007cbcc2dd2cac  pop rax
00007cbcc2dd2cad  add rsp, 0x08
00007cbcc2dd2cb1  jmp 0x00007CBCC2DCFF3D
00007cbcc2dd2cb6  sub rsp, 0x08
00007cbcc2dd2cba  push rax
00007cbcc2dd2cbb  push rcx
00007cbcc2dd2cbc  push rdx
00007cbcc2dd2cbd  push rdi
00007cbcc2dd2cbe  push rsi
00007cbcc2dd2cbf  push r8
00007cbcc2dd2cc1  push r9
00007cbcc2dd2cc3  push r10
00007cbcc2dd2cc5  push r11
00007cbcc2dd2cc7  sub rsp, 0xF0
00007cbcc2dd2cce  vmovaps [rsp], xmm0
00007cbcc2dd2cd3  vmovaps [rsp+0x10], xmm1
00007cbcc2dd2cd9  vmovaps [rsp+0x20], xmm2
00007cbcc2dd2cdf  vmovaps [rsp+0x30], xmm3
00007cbcc2dd2ce5  vmovaps [rsp+0x40], xmm4
00007cbcc2dd2ceb  vmovaps [rsp+0x50], xmm5
00007cbcc2dd2cf1  vmovaps [rsp+0x60], xmm6
00007cbcc2dd2cf7  vmovaps [rsp+0x70], xmm7
00007cbcc2dd2cfd  vmovaps [rsp+0x80], xmm8
00007cbcc2dd2d06  vmovaps [rsp+0x90], xmm9
00007cbcc2dd2d0f  vmovaps [rsp+0xA0], xmm10
00007cbcc2dd2d18  vmovaps [rsp+0xB0], xmm11
00007cbcc2dd2d21  vmovaps [rsp+0xC0], xmm12
00007cbcc2dd2d2a  vmovaps [rsp+0xD0], xmm13
00007cbcc2dd2d33  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd2d3c  sub rsp, 0x40
00007cbcc2dd2d40  lea rdi, [rsp]
00007cbcc2dd2d44  lea rsi, [rsp+0x10]
00007cbcc2dd2d49  lea rdx, [rsp+0x20]
00007cbcc2dd2d4e  lea rcx, [rsp+0x30]
00007cbcc2dd2d53  mov r8d, 0x00
00007cbcc2dd2d59  lea r9, [r15+0x3A8]
00007cbcc2dd2d60  movaps [rdi], xmm14
00007cbcc2dd2d64  movaps [rsi], xmm12
00007cbcc2dd2d68  movaps [rdx], xmm15
00007cbcc2dd2d6c  movaps [rcx], xmm1
00007cbcc2dd2d6f  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd2d79  call rax
00007cbcc2dd2d7b  movaps xmm14, [rsp]
00007cbcc2dd2d80  add rsp, 0x40
00007cbcc2dd2d84  vmovaps xmm0, [rsp]
00007cbcc2dd2d89  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd2d8f  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd2d95  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd2d9b  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd2da1  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd2da7  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd2dad  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd2db3  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd2dbc  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd2dc5  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dd2dce  vmovaps xmm11, [rsp+0xB0]
00007cbcc2dd2dd7  vmovaps xmm12, [rsp+0xC0]
00007cbcc2dd2de0  vmovaps xmm13, [rsp+0xD0]
00007cbcc2dd2de9  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd2df2  add rsp, 0xF0
00007cbcc2dd2df9  pop r11
00007cbcc2dd2dfb  pop r10
00007cbcc2dd2dfd  pop r9
00007cbcc2dd2dff  pop r8
00007cbcc2dd2e01  pop rsi
00007cbcc2dd2e02  pop rdi
00007cbcc2dd2e03  pop rdx
00007cbcc2dd2e04  pop rcx
00007cbcc2dd2e05  pop rax
00007cbcc2dd2e06  add rsp, 0x08
00007cbcc2dd2e0a  jmp 0x00007CBCC2DCFF6E
00007cbcc2dd2e0f  call 0x00007CBCC2C079B0
00007cbcc2dd2e14  jmp 0x00007CBCC2DCFF81
00007cbcc2dd2e19  call 0x00007CBCC2C09E90
00007cbcc2dd2e1e  jmp 0x00007CBCC2DCFF8C
00007cbcc2dd2e23  call 0x00007CBCC2C08C20
00007cbcc2dd2e28  jmp 0x00007CBCC2DCFF97
00007cbcc2dd2e2d  call 0x00007CBCC2C0D600
00007cbcc2dd2e32  jmp 0x00007CBCC2DCFFA2
00007cbcc2dd2e37  int3
00007cbcc2dd2e38  nop [rax+rax*1], eax
00007cbcc2dd2e40  mov rax, [r15+0x40]
00007cbcc2dd2e44  mov r14, [r15+0x58]
00007cbcc2dd2e48  lea r12, [rax+r14*1]
00007cbcc2dd2e4c  vxorps xmm1, xmm1, xmm1
00007cbcc2dd2e50  vpbroadcastq xmm1, xmm1
00007cbcc2dd2e55  vxorps xmm15, xmm15, xmm15
00007cbcc2dd2e5a  vpbroadcastq xmm15, xmm15
00007cbcc2dd2e5f  lea rax, [r12+0x30]
00007cbcc2dd2e64  mov r11, [r13+rax*1]
00007cbcc2dd2e69  lea rax, [r12+0x38]
00007cbcc2dd2e6e  mov r10, [r13+rax*1]
00007cbcc2dd2e73  movq xmm14, r11
00007cbcc2dd2e78  movq xmm13, r10
00007cbcc2dd2e7d  movq xmm14, xmm14
00007cbcc2dd2e82  movq xmm13, xmm13
00007cbcc2dd2e87  vmovaps [rsp+0x10], xmm13
00007cbcc2dd2e8d  movq xmm13, xmm13
00007cbcc2dd2e92  movaps [r15+0x270], xmm13
00007cbcc2dd2e9a  movaps xmm13, [r15+0x160]
00007cbcc2dd2ea2  vmovaps [rsp+0x20], xmm13
00007cbcc2dd2ea8  vmovaps xmm12, [rsp+0x20]
00007cbcc2dd2eae  por xmm13, xmm12
00007cbcc2dd2eb3  lea rax, [r12+0x20]
00007cbcc2dd2eb8  mov r11, [r13+rax*1]
00007cbcc2dd2ebd  lea rax, [r12+0x28]
00007cbcc2dd2ec2  mov r10, [r13+rax*1]
00007cbcc2dd2ec7  movq xmm12, r11
00007cbcc2dd2ecc  movq xmm11, r10
00007cbcc2dd2ed1  movq xmm12, xmm12
00007cbcc2dd2ed6  movq xmm11, xmm11
00007cbcc2dd2edb  movaps xmm10, [r15+0x2F0]
00007cbcc2dd2ee3  vmovaps [rsp+0x20], xmm10
00007cbcc2dd2ee9  vmovaps xmm9, [rsp+0x20]
00007cbcc2dd2eef  por xmm10, xmm9
00007cbcc2dd2ef4  movaps xmm9, [r15+0x2D0]
00007cbcc2dd2efc  vmovaps [rsp+0x20], xmm9
00007cbcc2dd2f02  vmovaps xmm8, [rsp+0x20]
00007cbcc2dd2f08  por xmm9, xmm8
00007cbcc2dd2f0d  movaps xmm8, [r15+0x300]
00007cbcc2dd2f15  vmovaps [rsp+0x20], xmm8
00007cbcc2dd2f1b  vmovaps xmm7, [rsp+0x20]
00007cbcc2dd2f21  por xmm8, xmm7
00007cbcc2dd2f26  movaps xmm7, [r15+0x2B0]
00007cbcc2dd2f2e  vmovaps [rsp+0x20], xmm7
00007cbcc2dd2f34  vmovaps xmm6, [rsp+0x20]
00007cbcc2dd2f3a  por xmm7, xmm6
00007cbcc2dd2f3e  movaps xmm6, [r15+0x180]
00007cbcc2dd2f46  vmovaps [rsp+0x20], xmm6
00007cbcc2dd2f4c  vmovaps xmm5, [rsp+0x20]
00007cbcc2dd2f52  por xmm6, xmm5
00007cbcc2dd2f56  lea rax, [r12+0x10]
00007cbcc2dd2f5b  mov r11, [r13+rax*1]
00007cbcc2dd2f60  lea rax, [r12+0x18]
00007cbcc2dd2f65  mov r10, [r13+rax*1]
00007cbcc2dd2f6a  movq xmm5, r11
00007cbcc2dd2f6f  movq xmm4, r10
00007cbcc2dd2f74  movq xmm5, xmm5
00007cbcc2dd2f78  movq xmm4, xmm4
00007cbcc2dd2f7c  movaps xmm3, [r15+0x200]
00007cbcc2dd2f84  vmovaps [rsp+0x20], xmm3
00007cbcc2dd2f8a  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd2f90  por xmm3, xmm2
00007cbcc2dd2f94  movaps xmm2, [r15+0x1F0]
00007cbcc2dd2f9c  vmovaps [rsp+0x20], xmm2
00007cbcc2dd2fa2  vmovaps [rsp+0x30], xmm1
00007cbcc2dd2fa8  vmovaps xmm1, [rsp+0x20]
00007cbcc2dd2fae  por xmm2, xmm1
00007cbcc2dd2fb2  movaps xmm1, [r15+0x2E0]
00007cbcc2dd2fba  vmovaps [rsp+0x20], xmm1
00007cbcc2dd2fc0  vmovaps [rsp+0x40], xmm15
00007cbcc2dd2fc6  vmovaps xmm15, [rsp+0x20]
00007cbcc2dd2fcc  por xmm1, xmm15
00007cbcc2dd2fd1  movaps xmm15, [r15+0x2A0]
00007cbcc2dd2fd9  vmovaps [rsp+0x20], xmm15
00007cbcc2dd2fdf  vmovaps [rsp+0x50], xmm1
00007cbcc2dd2fe5  vmovaps xmm1, [rsp+0x20]
00007cbcc2dd2feb  por xmm15, xmm1
00007cbcc2dd2ff0  movaps xmm1, [r15+0x280]
00007cbcc2dd2ff8  vmovaps [rsp+0x20], xmm1
00007cbcc2dd2ffe  vmovaps [rsp+0x60], xmm15
00007cbcc2dd3004  vmovaps xmm15, [rsp+0x20]
00007cbcc2dd300a  por xmm1, xmm15
00007cbcc2dd300f  movaps xmm15, [r15+0x1C0]
00007cbcc2dd3017  vmovaps [rsp+0x20], xmm15
00007cbcc2dd301d  vmovaps [rsp+0x70], xmm1
00007cbcc2dd3023  vmovaps xmm1, [rsp+0x20]
00007cbcc2dd3029  por xmm15, xmm1
00007cbcc2dd302e  movaps xmm1, [r15+0x210]
00007cbcc2dd3036  vmovaps [rsp+0x20], xmm1
00007cbcc2dd303c  vmovaps [rsp+0x80], xmm15
00007cbcc2dd3045  vmovaps xmm15, [rsp+0x20]
00007cbcc2dd304b  por xmm1, xmm15
00007cbcc2dd3050  mov rax, [r13+r12*1]
00007cbcc2dd3055  vmovq xmm15, rax
00007cbcc2dd305a  vpbroadcastq xmm15, xmm15
00007cbcc2dd305f  vmovaps [rsp+0x20], xmm1
00007cbcc2dd3065  vxorps xmm1, xmm1, xmm1
00007cbcc2dd3069  vpbroadcastq xmm1, xmm1
00007cbcc2dd306e  mov rax, [r15+0xF8]
00007cbcc2dd3075  vmovaps [rsp+0x90], xmm1
00007cbcc2dd307e  movups xmm1, [r13+rax*1]
00007cbcc2dd3084  vmovaps [rsp+0xA0], xmm1
00007cbcc2dd308d  vxorps xmm1, xmm1, xmm1
00007cbcc2dd3091  vpbroadcastq xmm1, xmm1
00007cbcc2dd3096  lea r11, [r12+0x08]
00007cbcc2dd309b  mov r12, [r13+r11*1]
00007cbcc2dd30a0  vmovaps [rsp+0xB0], xmm1
00007cbcc2dd30a9  movq xmm1, r12
00007cbcc2dd30ae  movaps [r15+0x240], xmm1
00007cbcc2dd30b6  mov r12, [r15+0x50]
00007cbcc2dd30ba  lea r11, [r12+r14*1]
00007cbcc2dd30be  mov [r15+0x60], r11
00007cbcc2dd30c2  lea r12, [r14+0x40]
00007cbcc2dd30c6  mov [r15+0x58], r12
00007cbcc2dd30ca  vmovaps xmm1, [rsp+0x30]
00007cbcc2dd30d0  vmovaps [rsp+0x30], xmm15
00007cbcc2dd30d6  vmovaps xmm15, [rsp+0xA0]
00007cbcc2dd30df  vmovaps [rsp+0xA0], xmm14
00007cbcc2dd30e8  vmovaps xmm14, [rsp+0x30]
00007cbcc2dd30ee  vmovaps [rsp+0x30], xmm13
00007cbcc2dd30f4  vmovaps [rsp+0xC0], xmm12
00007cbcc2dd30fd  movaps xmm13, xmm1
00007cbcc2dd3101  vfmadd231pd xmm13, xmm15, xmm14
00007cbcc2dd3106  vcmppd xmm12, xmm13, xmm13, 0x03
00007cbcc2dd310c  vptest xmm12, xmm12
00007cbcc2dd3111  jnz 0x00007CBCC2DD3BEA
00007cbcc2dd3117  movaps xmm1, [r15+0x250]
00007cbcc2dd311f  vmovaps xmm15, [rsp+0x40]
00007cbcc2dd3125  vmovaps [rsp+0x40], xmm13
00007cbcc2dd312b  movaps xmm12, xmm15
00007cbcc2dd312f  vfmadd231pd xmm12, xmm1, xmm14
00007cbcc2dd3134  vcmppd xmm13, xmm12, xmm12, 0x03
00007cbcc2dd313a  vptest xmm13, xmm13
00007cbcc2dd313f  jnz 0x00007CBCC2DD3D43
00007cbcc2dd3145  movaps xmm15, [r15+0x1E0]
00007cbcc2dd314d  vmovaps [rsp+0xD0], xmm15
00007cbcc2dd3156  vmovaps xmm13, [rsp+0xD0]
00007cbcc2dd315f  por xmm15, xmm13
00007cbcc2dd3164  movaps xmm13, [r15+0x1D0]
00007cbcc2dd316c  vmovaps [rsp+0xD0], xmm13
00007cbcc2dd3175  vmovaps [rsp+0xE0], xmm1
00007cbcc2dd317e  vmovaps xmm1, [rsp+0xD0]
00007cbcc2dd3187  por xmm13, xmm1
00007cbcc2dd318c  movaps xmm1, [r15+0x2C0]
00007cbcc2dd3194  vmovaps [rsp+0xD0], xmm1
00007cbcc2dd319d  vmovaps [rsp+0xF0], xmm15
00007cbcc2dd31a6  vmovaps xmm15, [rsp+0xD0]
00007cbcc2dd31af  por xmm1, xmm15
00007cbcc2dd31b4  movaps xmm15, [r15+0x290]
00007cbcc2dd31bc  vmovaps [rsp+0xD0], xmm15
00007cbcc2dd31c5  vmovaps [rsp+0x100], xmm1
00007cbcc2dd31ce  vmovaps xmm1, [rsp+0xD0]
00007cbcc2dd31d7  por xmm15, xmm1
00007cbcc2dd31dc  movaps xmm1, [r15+0x260]
00007cbcc2dd31e4  vmovaps [rsp+0xD0], xmm1
00007cbcc2dd31ed  vmovaps [rsp+0x110], xmm15
00007cbcc2dd31f6  vmovaps xmm15, [rsp+0xD0]
00007cbcc2dd31ff  por xmm1, xmm15
00007cbcc2dd3204  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd320d  vmovaps [rsp+0xD0], xmm1
00007cbcc2dd3216  vmovaps xmm1, [rsp+0xE0]
00007cbcc2dd321f  por xmm15, xmm1
00007cbcc2dd3224  lea r14, [rax+0xC0]
00007cbcc2dd322b  movups xmm1, [r13+r14*1]
00007cbcc2dd3231  mov [rsp+0xE0], rax
00007cbcc2dd3239  xor eax, eax
00007cbcc2dd323b  mov r14d, 0x200
00007cbcc2dd3241  cmp r12, r14
00007cbcc2dd3244  cmc
00007cbcc2dd3245  lahf
00007cbcc2dd3246  seto al
00007cbcc2dd3249  mov [r15+0x108], eax
00007cbcc2dd3250  vmovaps [rsp+0x120], xmm1
00007cbcc2dd3259  vmovaps xmm1, [rsp+0x90]
00007cbcc2dd3262  vmovaps [rsp+0x90], xmm15
00007cbcc2dd326b  vmovaps xmm15, [rsp+0x120]
00007cbcc2dd3274  vmovaps [rsp+0x120], xmm13
00007cbcc2dd327d  vmovaps [rsp+0x130], xmm12
00007cbcc2dd3286  movaps xmm13, xmm1
00007cbcc2dd328a  vfmadd231pd xmm13, xmm15, xmm14
00007cbcc2dd328f  vcmppd xmm12, xmm13, xmm13, 0x03
00007cbcc2dd3295  vptest xmm12, xmm12
00007cbcc2dd329a  jnz 0x00007CBCC2DD3EA6
00007cbcc2dd32a0  mov rax, [rsp+0xE0]
00007cbcc2dd32a8  lea r14, [rax+0xB0]
00007cbcc2dd32af  movups xmm1, [r13+r14*1]
00007cbcc2dd32b5  vmovaps xmm15, [rsp+0xB0]
00007cbcc2dd32be  vmovaps [rsp+0xB0], xmm13
00007cbcc2dd32c7  movaps xmm12, xmm15
00007cbcc2dd32cb  vfmadd231pd xmm12, xmm1, xmm14
00007cbcc2dd32d0  vcmppd xmm13, xmm12, xmm12, 0x03
00007cbcc2dd32d6  vptest xmm13, xmm13
00007cbcc2dd32db  jnz 0x00007CBCC2DD4009
00007cbcc2dd32e1  vmovaps xmm1, [rsp+0x20]
00007cbcc2dd32e7  vmovaps xmm15, [rsp+0x20]
00007cbcc2dd32ed  por xmm1, xmm15
00007cbcc2dd32f2  movaps [r15+0x210], xmm1
00007cbcc2dd32fa  vmovaps xmm15, [rsp+0x80]
00007cbcc2dd3303  vmovaps xmm14, [rsp+0x80]
00007cbcc2dd330c  por xmm15, xmm14
00007cbcc2dd3311  movaps [r15+0x1C0], xmm15
00007cbcc2dd3319  vmovaps xmm14, [rsp+0x70]
00007cbcc2dd331f  vmovaps xmm13, [rsp+0x70]
00007cbcc2dd3325  por xmm14, xmm13
00007cbcc2dd332a  movaps [r15+0x280], xmm14
00007cbcc2dd3332  vmovaps xmm13, [rsp+0x60]
00007cbcc2dd3338  vmovaps [rsp+0x20], xmm1
00007cbcc2dd333e  vmovaps xmm1, [rsp+0x60]
00007cbcc2dd3344  por xmm13, xmm1
00007cbcc2dd3349  movaps [r15+0x2A0], xmm13
00007cbcc2dd3351  vmovaps xmm1, [rsp+0x50]
00007cbcc2dd3357  vmovaps [rsp+0x60], xmm15
00007cbcc2dd335d  vmovaps xmm15, [rsp+0x50]
00007cbcc2dd3363  por xmm1, xmm15
00007cbcc2dd3368  movaps [r15+0x2E0], xmm1
00007cbcc2dd3370  vmovaps [rsp+0x50], xmm2
00007cbcc2dd3376  vmovaps xmm15, [rsp+0x50]
00007cbcc2dd337c  por xmm2, xmm15
00007cbcc2dd3381  movaps [r15+0x1F0], xmm2
00007cbcc2dd3389  vmovaps xmm15, [rsp+0x90]
00007cbcc2dd3392  vmovaps [rsp+0x50], xmm1
00007cbcc2dd3398  vmovaps xmm1, [rsp+0x90]
00007cbcc2dd33a1  por xmm15, xmm1
00007cbcc2dd33a6  movaps [r15+0x250], xmm15
00007cbcc2dd33ae  vmovaps xmm1, [rsp+0xD0]
00007cbcc2dd33b7  vmovaps xmm15, [rsp+0xD0]
00007cbcc2dd33c0  por xmm1, xmm15
00007cbcc2dd33c5  movaps [r15+0x260], xmm1
00007cbcc2dd33cd  vmovaps xmm15, [rsp+0x110]
00007cbcc2dd33d6  vmovaps [rsp+0x70], xmm1
00007cbcc2dd33dc  vmovaps xmm1, [rsp+0x110]
00007cbcc2dd33e5  por xmm15, xmm1
00007cbcc2dd33ea  movaps [r15+0x290], xmm15
00007cbcc2dd33f2  vmovaps xmm1, [rsp+0x100]
00007cbcc2dd33fb  vmovaps [rsp+0x80], xmm15
00007cbcc2dd3404  vmovaps xmm15, [rsp+0x100]
00007cbcc2dd340d  por xmm1, xmm15
00007cbcc2dd3412  movaps [r15+0x2C0], xmm1
00007cbcc2dd341a  movq xmm15, qword ptr [r15+0x240]
00007cbcc2dd3423  vmovaps [rsp+0x90], xmm15
00007cbcc2dd342c  vpermilpd xmm15, xmm15, 0x00
00007cbcc2dd3432  vmovaps [rsp+0xD0], xmm1
00007cbcc2dd343b  vmovaps xmm1, [rsp+0x40]
00007cbcc2dd3441  vmovaps [rsp+0x40], xmm15
00007cbcc2dd3447  vmovaps xmm15, [rsp+0x20]
00007cbcc2dd344d  vmovaps [rsp+0x20], xmm14
00007cbcc2dd3453  vmovaps xmm14, [rsp+0x40]
00007cbcc2dd3459  vmovaps [rsp+0x40], xmm13
00007cbcc2dd345f  vmovaps [rsp+0xE0], xmm12
00007cbcc2dd3468  movaps xmm13, xmm1
00007cbcc2dd346c  vfmadd231pd xmm13, xmm15, xmm14
00007cbcc2dd3471  vcmppd xmm12, xmm13, xmm13, 0x03
00007cbcc2dd3477  vptest xmm12, xmm12
00007cbcc2dd347c  jnz 0x00007CBCC2DD4162
00007cbcc2dd3482  vmovaps xmm1, [rsp+0x90]
00007cbcc2dd348b  vpermilpd xmm1, xmm1, 0x00
00007cbcc2dd3491  vmovaps xmm15, [rsp+0xB0]
00007cbcc2dd349a  vmovaps xmm14, [rsp+0x50]
00007cbcc2dd34a0  vmovaps [rsp+0x50], xmm13
00007cbcc2dd34a6  movaps xmm12, xmm15
00007cbcc2dd34aa  vfmadd231pd xmm12, xmm14, xmm1
00007cbcc2dd34af  vcmppd xmm13, xmm12, xmm12, 0x03
00007cbcc2dd34b5  vptest xmm13, xmm13
00007cbcc2dd34ba  jnz 0x00007CBCC2DD42BB
00007cbcc2dd34c0  vmovaps xmm1, [rsp+0x90]
00007cbcc2dd34c9  vpermilpd xmm1, xmm1, 0x00
00007cbcc2dd34cf  vmovaps xmm15, [rsp+0x130]
00007cbcc2dd34d8  vmovaps xmm14, [rsp+0x60]
00007cbcc2dd34de  vmovaps [rsp+0x60], xmm12
00007cbcc2dd34e4  movaps xmm13, xmm15
00007cbcc2dd34e8  vfmadd231pd xmm13, xmm14, xmm1
00007cbcc2dd34ed  vcmppd xmm12, xmm13, xmm13, 0x03
00007cbcc2dd34f3  vptest xmm12, xmm12
00007cbcc2dd34f8  jnz 0x00007CBCC2DD4414
00007cbcc2dd34fe  vmovaps xmm1, [rsp+0x120]
00007cbcc2dd3507  vmovaps xmm15, [rsp+0x120]
00007cbcc2dd3510  por xmm1, xmm15
00007cbcc2dd3515  movaps [r15+0x1D0], xmm1
00007cbcc2dd351d  vmovaps xmm15, [rsp+0x90]
00007cbcc2dd3526  vpermilpd xmm15, xmm15, 0x00
00007cbcc2dd352c  vmovaps xmm14, [rsp+0xE0]
00007cbcc2dd3535  vmovaps [rsp+0x90], xmm1
00007cbcc2dd353e  movaps xmm12, xmm14
00007cbcc2dd3542  vfmadd231pd xmm12, xmm2, xmm15
00007cbcc2dd3547  vcmppd xmm1, xmm12, xmm12, 0x03
00007cbcc2dd354d  vptest xmm1, xmm1
00007cbcc2dd3552  jnz 0x00007CBCC2DD456D
00007cbcc2dd3558  vmovaps [rsp+0xB0], xmm3
00007cbcc2dd3561  vmovaps xmm1, [rsp+0xB0]
00007cbcc2dd356a  por xmm3, xmm1
00007cbcc2dd356e  movaps [r15+0x200], xmm3
00007cbcc2dd3576  vmovaps xmm1, [rsp+0xF0]
00007cbcc2dd357f  vmovaps xmm15, [rsp+0xF0]
00007cbcc2dd3588  por xmm1, xmm15
00007cbcc2dd358d  movaps [r15+0x1E0], xmm1
00007cbcc2dd3595  vmovaps [rsp+0xB0], xmm7
00007cbcc2dd359e  vmovaps xmm1, [rsp+0xB0]
00007cbcc2dd35a7  por xmm7, xmm1
00007cbcc2dd35ab  movaps [r15+0x2B0], xmm7
00007cbcc2dd35b3  vmovaps [rsp+0xB0], xmm8
00007cbcc2dd35bc  vmovaps xmm1, [rsp+0xB0]
00007cbcc2dd35c5  por xmm8, xmm1
00007cbcc2dd35ca  movaps [r15+0x300], xmm8
00007cbcc2dd35d2  vmovaps [rsp+0xB0], xmm5
00007cbcc2dd35db  vpermilpd xmm5, xmm5, 0x00
00007cbcc2dd35e1  vmovaps xmm14, [rsp+0x50]
00007cbcc2dd35e7  vmovaps xmm8, [rsp+0x70]
00007cbcc2dd35ed  vmovaps [rsp+0x50], xmm1
00007cbcc2dd35f3  movaps xmm2, xmm14
00007cbcc2dd35f7  vfmadd231pd xmm2, xmm8, xmm5
00007cbcc2dd35fc  vcmppd xmm1, xmm2, xmm2, 0x03
00007cbcc2dd3601  vptest xmm1, xmm1
00007cbcc2dd3606  jnz 0x00007CBCC2DD46C6
00007cbcc2dd360c  vmovaps xmm1, [rsp+0xB0]
00007cbcc2dd3615  vpermilpd xmm1, xmm1, 0x00
00007cbcc2dd361b  vmovaps xmm14, [rsp+0x60]
00007cbcc2dd3621  vmovaps xmm8, [rsp+0xD0]
00007cbcc2dd362a  vmovaps [rsp+0x60], xmm15
00007cbcc2dd3630  movaps xmm5, xmm14
00007cbcc2dd3634  vfmadd231pd xmm5, xmm8, xmm1
00007cbcc2dd3639  vcmppd xmm15, xmm5, xmm5, 0x03
00007cbcc2dd363e  vptest xmm15, xmm15
00007cbcc2dd3643  jnz 0x00007CBCC2DD481D
00007cbcc2dd3649  vmovaps xmm1, [rsp+0xB0]
00007cbcc2dd3652  vpermilpd xmm1, xmm1, 0x00
00007cbcc2dd3658  vmovaps xmm14, [rsp+0x20]
00007cbcc2dd365e  movaps xmm15, xmm13
00007cbcc2dd3662  vfmadd231pd xmm15, xmm14, xmm1
00007cbcc2dd3667  vcmppd xmm8, xmm15, xmm15, 0x03
00007cbcc2dd366d  vptest xmm8, xmm8
00007cbcc2dd3672  jnz 0x00007CBCC2DD4974
00007cbcc2dd3678  vmovaps xmm1, [rsp+0xB0]
00007cbcc2dd3681  vpermilpd xmm1, xmm1, 0x00
00007cbcc2dd3687  vmovaps xmm14, [rsp+0x90]
00007cbcc2dd3690  movaps xmm13, xmm12
00007cbcc2dd3694  vfmadd231pd xmm13, xmm14, xmm1
00007cbcc2dd3699  vcmppd xmm8, xmm13, xmm13, 0x03
00007cbcc2dd369f  vptest xmm8, xmm8
00007cbcc2dd36a4  jnz 0x00007CBCC2DD4ACD
00007cbcc2dd36aa  vmovaps [rsp+0x20], xmm6
00007cbcc2dd36b0  vmovaps xmm1, [rsp+0x20]
00007cbcc2dd36b6  por xmm6, xmm1
00007cbcc2dd36ba  movaps [r15+0x180], xmm6
00007cbcc2dd36c2  vmovaps [rsp+0x20], xmm9
00007cbcc2dd36c8  vmovaps xmm1, [rsp+0x20]
00007cbcc2dd36ce  por xmm9, xmm1
00007cbcc2dd36d3  movaps [r15+0x2D0], xmm9
00007cbcc2dd36db  vmovaps [rsp+0x20], xmm10
00007cbcc2dd36e1  vmovaps xmm1, [rsp+0x20]
00007cbcc2dd36e7  por xmm10, xmm1
00007cbcc2dd36ec  movaps [r15+0x2F0], xmm10
00007cbcc2dd36f4  vmovaps [rsp+0x20], xmm4
00007cbcc2dd36fa  vpermilpd xmm4, xmm4, 0x00
00007cbcc2dd3700  vmovaps xmm14, [rsp+0x50]
00007cbcc2dd3706  movaps xmm12, xmm5
00007cbcc2dd370a  vfmadd231pd xmm12, xmm14, xmm4
00007cbcc2dd370f  vcmppd xmm10, xmm12, xmm12, 0x03
00007cbcc2dd3715  vptest xmm10, xmm10
00007cbcc2dd371a  jnz 0x00007CBCC2DD4C26
00007cbcc2dd3720  vmovaps xmm14, [rsp+0x20]
00007cbcc2dd3726  vpermilpd xmm14, xmm14, 0x00
00007cbcc2dd372c  movaps xmm10, xmm2
00007cbcc2dd3730  vfmadd231pd xmm10, xmm6, xmm14
00007cbcc2dd3735  vcmppd xmm8, xmm10, xmm10, 0x03
00007cbcc2dd373b  vptest xmm8, xmm8
00007cbcc2dd3740  jnz 0x00007CBCC2DD4D7E
00007cbcc2dd3746  lea r14, [rax+0x80]
00007cbcc2dd374d  movups xmm14, [r13+r14*1]
00007cbcc2dd3753  movaps [r15+0x190], xmm14
00007cbcc2dd375b  vmovaps xmm8, [rsp+0x20]
00007cbcc2dd3761  vpermilpd xmm8, xmm8, 0x00
00007cbcc2dd3767  vmovaps xmm6, [rsp+0x80]
00007cbcc2dd3770  movaps xmm5, xmm15
00007cbcc2dd3774  vfmadd231pd xmm5, xmm6, xmm8
00007cbcc2dd3779  vcmppd xmm4, xmm5, xmm5, 0x03
00007cbcc2dd377e  vptest xmm4, xmm4
00007cbcc2dd3783  jnz 0x00007CBCC2DD4EE0
00007cbcc2dd3789  vmovaps xmm15, [rsp+0x20]
00007cbcc2dd378f  vpermilpd xmm15, xmm15, 0x00
00007cbcc2dd3795  movaps xmm8, xmm13
00007cbcc2dd3799  vfmadd231pd xmm8, xmm1, xmm15
00007cbcc2dd379e  vcmppd xmm6, xmm8, xmm8, 0x03
00007cbcc2dd37a4  vptest xmm6, xmm6
00007cbcc2dd37a9  jnz 0x00007CBCC2DD5037
00007cbcc2dd37af  vmovaps xmm1, [rsp+0x30]
00007cbcc2dd37b5  vmovaps xmm15, [rsp+0x30]
00007cbcc2dd37bb  por xmm1, xmm15
00007cbcc2dd37c0  movaps [r15+0x160], xmm1
00007cbcc2dd37c8  lea r14, [rax+0x40]
00007cbcc2dd37cc  movups xmm15, [r13+r14*1]
00007cbcc2dd37d2  lea r14, [rax+0x50]
00007cbcc2dd37d6  movups xmm13, [r13+r14*1]
00007cbcc2dd37dc  movaps [r15+0x1B0], xmm15
00007cbcc2dd37e4  movaps [r15+0x1A0], xmm13
00007cbcc2dd37ec  vmovaps xmm6, [rsp+0xC0]
00007cbcc2dd37f5  vpermilpd xmm6, xmm6, 0x00
00007cbcc2dd37fb  movaps xmm4, xmm12
00007cbcc2dd37ff  vfmadd231pd xmm4, xmm9, xmm6
00007cbcc2dd3804  vcmppd xmm2, xmm4, xmm4, 0x03
00007cbcc2dd3809  vptest xmm2, xmm2
00007cbcc2dd380e  jnz 0x00007CBCC2DD51A4
00007cbcc2dd3814  vmovaps xmm12, [rsp+0xC0]
00007cbcc2dd381d  vpermilpd xmm12, xmm12, 0x00
00007cbcc2dd3823  movaps xmm9, xmm10
00007cbcc2dd3827  vfmadd231pd xmm9, xmm1, xmm12
00007cbcc2dd382c  vcmppd xmm6, xmm9, xmm9, 0x03
00007cbcc2dd3832  vptest xmm6, xmm6
00007cbcc2dd3837  jnz 0x00007CBCC2DD52FB
00007cbcc2dd383d  vmovaps xmm1, [rsp+0xC0]
00007cbcc2dd3846  vpermilpd xmm1, xmm1, 0x00
00007cbcc2dd384c  vmovaps xmm12, [rsp+0x40]
00007cbcc2dd3852  movaps xmm10, xmm5
00007cbcc2dd3856  vfmadd231pd xmm10, xmm12, xmm1
00007cbcc2dd385b  vcmppd xmm6, xmm10, xmm10, 0x03
00007cbcc2dd3861  vptest xmm6, xmm6
00007cbcc2dd3866  jnz 0x00007CBCC2DD5454
00007cbcc2dd386c  vmovaps xmm1, [rsp+0xC0]
00007cbcc2dd3875  vpermilpd xmm1, xmm1, 0x00
00007cbcc2dd387b  vmovaps xmm12, [rsp+0x60]
00007cbcc2dd3881  movaps xmm6, xmm8
00007cbcc2dd3885  vfmadd231pd xmm6, xmm12, xmm1
00007cbcc2dd388a  vcmppd xmm5, xmm6, xmm6, 0x03
00007cbcc2dd388f  vptest xmm5, xmm5
00007cbcc2dd3894  jnz 0x00007CBCC2DD55AC
00007cbcc2dd389a  lea r14, [rax+0x60]
00007cbcc2dd389e  movups xmm1, [r13+r14*1]
00007cbcc2dd38a4  lea r14, [rax+0x70]
00007cbcc2dd38a8  movups xmm12, [r13+r14*1]
00007cbcc2dd38ae  movaps [r15+0x150], xmm1
00007cbcc2dd38b6  movaps [r15+0x120], xmm12
00007cbcc2dd38be  vmovaps [rsp+0x20], xmm11
00007cbcc2dd38c4  vpermilpd xmm11, xmm11, 0x00
00007cbcc2dd38ca  movaps xmm8, xmm4
00007cbcc2dd38ce  vfmadd231pd xmm8, xmm13, xmm11
00007cbcc2dd38d3  vcmppd xmm5, xmm8, xmm8, 0x03
00007cbcc2dd38d9  vptest xmm5, xmm5
00007cbcc2dd38de  jnz 0x00007CBCC2DD5717
00007cbcc2dd38e4  vmovaps xmm13, [rsp+0x20]
00007cbcc2dd38ea  vpermilpd xmm13, xmm13, 0x00
00007cbcc2dd38f0  movaps xmm11, xmm9
00007cbcc2dd38f4  vfmadd231pd xmm11, xmm1, xmm13
00007cbcc2dd38f9  vcmppd xmm5, xmm11, xmm11, 0x03
00007cbcc2dd38ff  vptest xmm5, xmm5
00007cbcc2dd3904  jnz 0x00007CBCC2DD5870
00007cbcc2dd390a  vmovaps xmm1, [rsp+0x20]
00007cbcc2dd3910  vpermilpd xmm1, xmm1, 0x00
00007cbcc2dd3916  movaps xmm13, xmm10
00007cbcc2dd391a  vfmadd231pd xmm13, xmm7, xmm1
00007cbcc2dd391f  vcmppd xmm9, xmm13, xmm13, 0x03
00007cbcc2dd3925  vptest xmm9, xmm9
00007cbcc2dd392a  jnz 0x00007CBCC2DD59C9
00007cbcc2dd3930  vmovaps xmm1, [rsp+0x20]
00007cbcc2dd3936  vpermilpd xmm1, xmm1, 0x00
00007cbcc2dd393c  movaps xmm10, xmm6
00007cbcc2dd3940  vfmadd231pd xmm10, xmm15, xmm1
00007cbcc2dd3945  vcmppd xmm9, xmm10, xmm10, 0x03
00007cbcc2dd394b  vptest xmm9, xmm9
00007cbcc2dd3950  jnz 0x00007CBCC2DD5B21
00007cbcc2dd3956  lea r14, [rax+0x20]
00007cbcc2dd395a  movups xmm1, [r13+r14*1]
00007cbcc2dd3960  lea r14, [rax+0x30]
00007cbcc2dd3964  movups xmm15, [r13+r14*1]
00007cbcc2dd396a  vmovaps xmm9, [rsp+0xA0]
00007cbcc2dd3973  vpermilpd xmm9, xmm9, 0x00
00007cbcc2dd3979  movaps xmm7, xmm8
00007cbcc2dd397d  vfmadd231pd xmm7, xmm3, xmm9
00007cbcc2dd3982  vcmppd xmm6, xmm7, xmm7, 0x03
00007cbcc2dd3987  vptest xmm6, xmm6
00007cbcc2dd398c  jnz 0x00007CBCC2DD5C8D
00007cbcc2dd3992  vmovaps xmm9, [rsp+0xA0]
00007cbcc2dd399b  vpermilpd xmm9, xmm9, 0x00
00007cbcc2dd39a1  movaps xmm8, xmm11
00007cbcc2dd39a5  vfmadd231pd xmm8, xmm14, xmm9
00007cbcc2dd39aa  vcmppd xmm6, xmm8, xmm8, 0x03
00007cbcc2dd39b0  vptest xmm6, xmm6
00007cbcc2dd39b5  jnz 0x00007CBCC2DD5DE4
00007cbcc2dd39bb  vmovaps xmm14, [rsp+0xA0]
00007cbcc2dd39c4  vpermilpd xmm14, xmm14, 0x00
00007cbcc2dd39ca  movaps xmm11, xmm13
00007cbcc2dd39ce  vfmadd231pd xmm11, xmm12, xmm14
00007cbcc2dd39d3  vcmppd xmm9, xmm11, xmm11, 0x03
00007cbcc2dd39d9  vptest xmm9, xmm9
00007cbcc2dd39de  jnz 0x00007CBCC2DD5F3E
00007cbcc2dd39e4  vmovaps xmm14, [rsp+0xA0]
00007cbcc2dd39ed  vpermilpd xmm14, xmm14, 0x00
00007cbcc2dd39f3  movaps xmm12, xmm10
00007cbcc2dd39f7  vfmadd231pd xmm12, xmm15, xmm14
00007cbcc2dd39fc  vcmppd xmm13, xmm12, xmm12, 0x03
00007cbcc2dd3a02  vptest xmm13, xmm13
00007cbcc2dd3a07  jnz 0x00007CBCC2DD6098
00007cbcc2dd3a0d  lea r14, [rax+0x90]
00007cbcc2dd3a14  movups xmm15, [r13+r14*1]
00007cbcc2dd3a1a  lea r14, [rax+0xA0]
00007cbcc2dd3a21  movups xmm14, [r13+r14*1]
00007cbcc2dd3a27  movaps [r15+0x140], xmm15
00007cbcc2dd3a2f  movaps [r15+0x130], xmm14
00007cbcc2dd3a37  vmovaps xmm13, [rsp+0x10]
00007cbcc2dd3a3d  vpermilpd xmm13, xmm13, 0x00
00007cbcc2dd3a43  movaps xmm10, xmm7
00007cbcc2dd3a47  vfmadd231pd xmm10, xmm1, xmm13
00007cbcc2dd3a4c  vcmppd xmm9, xmm10, xmm10, 0x03
00007cbcc2dd3a52  vptest xmm9, xmm9
00007cbcc2dd3a57  jnz 0x00007CBCC2DD6206
00007cbcc2dd3a5d  movaps [r15+0x220], xmm10
00007cbcc2dd3a65  lea r14, [rax+0x10]
00007cbcc2dd3a69  movups xmm1, [r13+r14*1]
00007cbcc2dd3a6f  movaps [r15+0x240], xmm1
00007cbcc2dd3a77  vmovaps xmm13, [rsp+0x10]
00007cbcc2dd3a7d  vpermilpd xmm13, xmm13, 0x00
00007cbcc2dd3a83  movaps xmm9, xmm8
00007cbcc2dd3a87  vfmadd231pd xmm9, xmm14, xmm13
00007cbcc2dd3a8c  vcmppd xmm7, xmm9, xmm9, 0x03
00007cbcc2dd3a92  vptest xmm7, xmm7
00007cbcc2dd3a97  jnz 0x00007CBCC2DD6368
00007cbcc2dd3a9d  movaps [r15+0x110], xmm9
00007cbcc2dd3aa5  vmovaps xmm14, [rsp+0x10]
00007cbcc2dd3aab  vpermilpd xmm14, xmm14, 0x00
00007cbcc2dd3ab1  movaps xmm13, xmm11
00007cbcc2dd3ab5  vfmadd231pd xmm13, xmm15, xmm14
00007cbcc2dd3aba  vcmppd xmm8, xmm13, xmm13, 0x03
00007cbcc2dd3ac0  vptest xmm8, xmm8
00007cbcc2dd3ac5  jnz 0x00007CBCC2DD64C2
00007cbcc2dd3acb  movaps [r15+0x170], xmm13
00007cbcc2dd3ad3  vmovaps xmm15, [rsp+0x10]
00007cbcc2dd3ad9  vpermilpd xmm15, xmm15, 0x00
00007cbcc2dd3adf  movaps xmm14, xmm12
00007cbcc2dd3ae3  vfmadd231pd xmm14, xmm1, xmm15
00007cbcc2dd3ae8  vcmppd xmm11, xmm14, xmm14, 0x03
00007cbcc2dd3aee  vptest xmm11, xmm11
00007cbcc2dd3af3  jnz 0x00007CBCC2DD661C
00007cbcc2dd3af9  movaps [r15+0x230], xmm14
00007cbcc2dd3b01  movups [r13+r11*1], xmm9
00007cbcc2dd3b07  lea rax, [r11+0x10]
00007cbcc2dd3b0b  movups [r13+rax*1], xmm13
00007cbcc2dd3b11  lea rax, [r11+0x20]
00007cbcc2dd3b15  movups [r13+rax*1], xmm10
00007cbcc2dd3b1b  lea rax, [r11+0x30]
00007cbcc2dd3b1f  movups [r13+rax*1], xmm14
00007cbcc2dd3b25  mov eax, [r15+0x108]
00007cbcc2dd3b2c  sahf
00007cbcc2dd3b2d  jnz 0x00007CBCC2DD3B5F
00007cbcc2dd3b2f  cmp dword ptr [r15+0x318], 0x00
00007cbcc2dd3b37  jz 0x00007CBCC2DD67A0
00007cbcc2dd3b3d  nop [rax+rax*1], ax
00007cbcc2dd3b46  nop [rax+rax*1], eax
00007cbcc2dd3b4e  mov eax, 0x4103F0
00007cbcc2dd3b53  mov [r15+0x100], rax
00007cbcc2dd3b5a  jmp 0x00007CBCC2BFE110
00007cbcc2dd3b5f  cmp dword ptr [r15+0x318], 0x00
00007cbcc2dd3b67  jz 0x00007CBCC2DD2E40
00007cbcc2dd3b6d  nop [rax+rax*1], ax
00007cbcc2dd3b76  nop [rax+rax*1], eax
00007cbcc2dd3b7e  mov eax, 0x410274
00007cbcc2dd3b83  mov [r15+0x100], rax
00007cbcc2dd3b8a  jmp 0x00007CBCC2BFE110
00007cbcc2dd3b8f  int3
00007cbcc2dd3b90  call 0x00007CBCC2C0A4B0
00007cbcc2dd3b95  jmp 0x00007CBCC2DD2E69
00007cbcc2dd3b9a  call 0x00007CBCC2C09240
00007cbcc2dd3b9f  jmp 0x00007CBCC2DD2E73
00007cbcc2dd3ba4  call 0x00007CBCC2C0A4B0
00007cbcc2dd3ba9  jmp 0x00007CBCC2DD2EBD
00007cbcc2dd3bae  call 0x00007CBCC2C09240
00007cbcc2dd3bb3  jmp 0x00007CBCC2DD2EC7
00007cbcc2dd3bb8  call 0x00007CBCC2C0A4B0
00007cbcc2dd3bbd  jmp 0x00007CBCC2DD2F60
00007cbcc2dd3bc2  call 0x00007CBCC2C09240
00007cbcc2dd3bc7  jmp 0x00007CBCC2DD2F6A
00007cbcc2dd3bcc  call 0x00007CBCC2CB47C0
00007cbcc2dd3bd1  jmp 0x00007CBCC2DD3055
00007cbcc2dd3bd6  call 0x00007CBCC2BFF430
00007cbcc2dd3bdb  jmp 0x00007CBCC2DD3084
00007cbcc2dd3be0  call 0x00007CBCC2CB0CE0
00007cbcc2dd3be5  jmp 0x00007CBCC2DD30A0
00007cbcc2dd3bea  sub rsp, 0x08
00007cbcc2dd3bee  push rax
00007cbcc2dd3bef  push rcx
00007cbcc2dd3bf0  push rdx
00007cbcc2dd3bf1  push rdi
00007cbcc2dd3bf2  push rsi
00007cbcc2dd3bf3  push r8
00007cbcc2dd3bf5  push r9
00007cbcc2dd3bf7  push r10
00007cbcc2dd3bf9  push r11
00007cbcc2dd3bfb  sub rsp, 0xF0
00007cbcc2dd3c02  vmovaps [rsp], xmm0
00007cbcc2dd3c07  vmovaps [rsp+0x10], xmm1
00007cbcc2dd3c0d  vmovaps [rsp+0x20], xmm2
00007cbcc2dd3c13  vmovaps [rsp+0x30], xmm3
00007cbcc2dd3c19  vmovaps [rsp+0x40], xmm4
00007cbcc2dd3c1f  vmovaps [rsp+0x50], xmm5
00007cbcc2dd3c25  vmovaps [rsp+0x60], xmm6
00007cbcc2dd3c2b  vmovaps [rsp+0x70], xmm7
00007cbcc2dd3c31  vmovaps [rsp+0x80], xmm8
00007cbcc2dd3c3a  vmovaps [rsp+0x90], xmm9
00007cbcc2dd3c43  vmovaps [rsp+0xA0], xmm10
00007cbcc2dd3c4c  vmovaps [rsp+0xB0], xmm11
00007cbcc2dd3c55  vmovaps [rsp+0xC0], xmm12
00007cbcc2dd3c5e  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd3c67  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd3c70  sub rsp, 0x40
00007cbcc2dd3c74  lea rdi, [rsp]
00007cbcc2dd3c78  lea rsi, [rsp+0x10]
00007cbcc2dd3c7d  lea rdx, [rsp+0x20]
00007cbcc2dd3c82  lea rcx, [rsp+0x30]
00007cbcc2dd3c87  mov r8d, 0x00
00007cbcc2dd3c8d  lea r9, [r15+0x3A8]
00007cbcc2dd3c94  movaps [rdi], xmm13
00007cbcc2dd3c98  movaps [rsi], xmm1
00007cbcc2dd3c9b  movaps [rdx], xmm15
00007cbcc2dd3c9f  movaps [rcx], xmm14
00007cbcc2dd3ca3  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd3cad  call rax
00007cbcc2dd3caf  movaps xmm13, [rsp]
00007cbcc2dd3cb4  add rsp, 0x40
00007cbcc2dd3cb8  vmovaps xmm0, [rsp]
00007cbcc2dd3cbd  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd3cc3  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd3cc9  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd3ccf  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd3cd5  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd3cdb  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd3ce1  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd3ce7  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd3cf0  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd3cf9  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dd3d02  vmovaps xmm11, [rsp+0xB0]
00007cbcc2dd3d0b  vmovaps xmm12, [rsp+0xC0]
00007cbcc2dd3d14  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd3d1d  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd3d26  add rsp, 0xF0
00007cbcc2dd3d2d  pop r11
00007cbcc2dd3d2f  pop r10
00007cbcc2dd3d31  pop r9
00007cbcc2dd3d33  pop r8
00007cbcc2dd3d35  pop rsi
00007cbcc2dd3d36  pop rdi
00007cbcc2dd3d37  pop rdx
00007cbcc2dd3d38  pop rcx
00007cbcc2dd3d39  pop rax
00007cbcc2dd3d3a  add rsp, 0x08
00007cbcc2dd3d3e  jmp 0x00007CBCC2DD3117
00007cbcc2dd3d43  sub rsp, 0x08
00007cbcc2dd3d47  push rax
00007cbcc2dd3d48  push rcx
00007cbcc2dd3d49  push rdx
00007cbcc2dd3d4a  push rdi
00007cbcc2dd3d4b  push rsi
00007cbcc2dd3d4c  push r8
00007cbcc2dd3d4e  push r9
00007cbcc2dd3d50  push r10
00007cbcc2dd3d52  push r11
00007cbcc2dd3d54  sub rsp, 0xF0
00007cbcc2dd3d5b  vmovaps [rsp], xmm0
00007cbcc2dd3d60  vmovaps [rsp+0x10], xmm1
00007cbcc2dd3d66  vmovaps [rsp+0x20], xmm2
00007cbcc2dd3d6c  vmovaps [rsp+0x30], xmm3
00007cbcc2dd3d72  vmovaps [rsp+0x40], xmm4
00007cbcc2dd3d78  vmovaps [rsp+0x50], xmm5
00007cbcc2dd3d7e  vmovaps [rsp+0x60], xmm6
00007cbcc2dd3d84  vmovaps [rsp+0x70], xmm7
00007cbcc2dd3d8a  vmovaps [rsp+0x80], xmm8
00007cbcc2dd3d93  vmovaps [rsp+0x90], xmm9
00007cbcc2dd3d9c  vmovaps [rsp+0xA0], xmm10
00007cbcc2dd3da5  vmovaps [rsp+0xB0], xmm11
00007cbcc2dd3dae  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd3db7  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd3dc0  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd3dc9  sub rsp, 0x40
00007cbcc2dd3dcd  lea rdi, [rsp]
00007cbcc2dd3dd1  lea rsi, [rsp+0x10]
00007cbcc2dd3dd6  lea rdx, [rsp+0x20]
00007cbcc2dd3ddb  lea rcx, [rsp+0x30]
00007cbcc2dd3de0  mov r8d, 0x00
00007cbcc2dd3de6  lea r9, [r15+0x3A8]
00007cbcc2dd3ded  movaps [rdi], xmm12
00007cbcc2dd3df1  movaps [rsi], xmm15
00007cbcc2dd3df5  movaps [rdx], xmm1
00007cbcc2dd3df8  movaps [rcx], xmm14
00007cbcc2dd3dfc  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd3e06  call rax
00007cbcc2dd3e08  movaps xmm12, [rsp]
00007cbcc2dd3e0d  add rsp, 0x40
00007cbcc2dd3e11  vmovaps xmm0, [rsp]
00007cbcc2dd3e16  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd3e1c  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd3e22  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd3e28  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd3e2e  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd3e34  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd3e3a  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd3e40  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd3e49  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd3e52  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dd3e5b  vmovaps xmm11, [rsp+0xB0]
00007cbcc2dd3e64  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd3e6d  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd3e76  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd3e7f  add rsp, 0xF0
00007cbcc2dd3e86  pop r11
00007cbcc2dd3e88  pop r10
00007cbcc2dd3e8a  pop r9
00007cbcc2dd3e8c  pop r8
00007cbcc2dd3e8e  pop rsi
00007cbcc2dd3e8f  pop rdi
00007cbcc2dd3e90  pop rdx
00007cbcc2dd3e91  pop rcx
00007cbcc2dd3e92  pop rax
00007cbcc2dd3e93  add rsp, 0x08
00007cbcc2dd3e97  jmp 0x00007CBCC2DD3145
00007cbcc2dd3e9c  call 0x00007CBCC2CD64F0
00007cbcc2dd3ea1  jmp 0x00007CBCC2DD3231
00007cbcc2dd3ea6  sub rsp, 0x08
00007cbcc2dd3eaa  push rax
00007cbcc2dd3eab  push rcx
00007cbcc2dd3eac  push rdx
00007cbcc2dd3ead  push rdi
00007cbcc2dd3eae  push rsi
00007cbcc2dd3eaf  push r8
00007cbcc2dd3eb1  push r9
00007cbcc2dd3eb3  push r10
00007cbcc2dd3eb5  push r11
00007cbcc2dd3eb7  sub rsp, 0xF0
00007cbcc2dd3ebe  vmovaps [rsp], xmm0
00007cbcc2dd3ec3  vmovaps [rsp+0x10], xmm1
00007cbcc2dd3ec9  vmovaps [rsp+0x20], xmm2
00007cbcc2dd3ecf  vmovaps [rsp+0x30], xmm3
00007cbcc2dd3ed5  vmovaps [rsp+0x40], xmm4
00007cbcc2dd3edb  vmovaps [rsp+0x50], xmm5
00007cbcc2dd3ee1  vmovaps [rsp+0x60], xmm6
00007cbcc2dd3ee7  vmovaps [rsp+0x70], xmm7
00007cbcc2dd3eed  vmovaps [rsp+0x80], xmm8
00007cbcc2dd3ef6  vmovaps [rsp+0x90], xmm9
00007cbcc2dd3eff  vmovaps [rsp+0xA0], xmm10
00007cbcc2dd3f08  vmovaps [rsp+0xB0], xmm11
00007cbcc2dd3f11  vmovaps [rsp+0xC0], xmm12
00007cbcc2dd3f1a  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd3f23  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd3f2c  sub rsp, 0x40
00007cbcc2dd3f30  lea rdi, [rsp]
00007cbcc2dd3f34  lea rsi, [rsp+0x10]
00007cbcc2dd3f39  lea rdx, [rsp+0x20]
00007cbcc2dd3f3e  lea rcx, [rsp+0x30]
00007cbcc2dd3f43  mov r8d, 0x00
00007cbcc2dd3f49  lea r9, [r15+0x3A8]
00007cbcc2dd3f50  movaps [rdi], xmm13
00007cbcc2dd3f54  movaps [rsi], xmm1
00007cbcc2dd3f57  movaps [rdx], xmm15
00007cbcc2dd3f5b  movaps [rcx], xmm14
00007cbcc2dd3f5f  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd3f69  call rax
00007cbcc2dd3f6b  movaps xmm13, [rsp]
00007cbcc2dd3f70  add rsp, 0x40
00007cbcc2dd3f74  vmovaps xmm0, [rsp]
00007cbcc2dd3f79  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd3f7f  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd3f85  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd3f8b  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd3f91  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd3f97  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd3f9d  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd3fa3  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd3fac  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd3fb5  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dd3fbe  vmovaps xmm11, [rsp+0xB0]
00007cbcc2dd3fc7  vmovaps xmm12, [rsp+0xC0]
00007cbcc2dd3fd0  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd3fd9  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd3fe2  add rsp, 0xF0
00007cbcc2dd3fe9  pop r11
00007cbcc2dd3feb  pop r10
00007cbcc2dd3fed  pop r9
00007cbcc2dd3fef  pop r8
00007cbcc2dd3ff1  pop rsi
00007cbcc2dd3ff2  pop rdi
00007cbcc2dd3ff3  pop rdx
00007cbcc2dd3ff4  pop rcx
00007cbcc2dd3ff5  pop rax
00007cbcc2dd3ff6  add rsp, 0x08
00007cbcc2dd3ffa  jmp 0x00007CBCC2DD32A0
00007cbcc2dd3fff  call 0x00007CBCC2CD64F0
00007cbcc2dd4004  jmp 0x00007CBCC2DD32B5
00007cbcc2dd4009  sub rsp, 0x08
00007cbcc2dd400d  push rax
00007cbcc2dd400e  push rcx
00007cbcc2dd400f  push rdx
00007cbcc2dd4010  push rdi
00007cbcc2dd4011  push rsi
00007cbcc2dd4012  push r8
00007cbcc2dd4014  push r9
00007cbcc2dd4016  push r10
00007cbcc2dd4018  push r11
00007cbcc2dd401a  sub rsp, 0xF0
00007cbcc2dd4021  vmovaps [rsp], xmm0
00007cbcc2dd4026  vmovaps [rsp+0x10], xmm1
00007cbcc2dd402c  vmovaps [rsp+0x20], xmm2
00007cbcc2dd4032  vmovaps [rsp+0x30], xmm3
00007cbcc2dd4038  vmovaps [rsp+0x40], xmm4
00007cbcc2dd403e  vmovaps [rsp+0x50], xmm5
00007cbcc2dd4044  vmovaps [rsp+0x60], xmm6
00007cbcc2dd404a  vmovaps [rsp+0x70], xmm7
00007cbcc2dd4050  vmovaps [rsp+0x80], xmm8
00007cbcc2dd4059  vmovaps [rsp+0x90], xmm9
00007cbcc2dd4062  vmovaps [rsp+0xA0], xmm10
00007cbcc2dd406b  vmovaps [rsp+0xB0], xmm11
00007cbcc2dd4074  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd407d  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd4086  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd408f  sub rsp, 0x40
00007cbcc2dd4093  lea rdi, [rsp]
00007cbcc2dd4097  lea rsi, [rsp+0x10]
00007cbcc2dd409c  lea rdx, [rsp+0x20]
00007cbcc2dd40a1  lea rcx, [rsp+0x30]
00007cbcc2dd40a6  mov r8d, 0x00
00007cbcc2dd40ac  lea r9, [r15+0x3A8]
00007cbcc2dd40b3  movaps [rdi], xmm12
00007cbcc2dd40b7  movaps [rsi], xmm15
00007cbcc2dd40bb  movaps [rdx], xmm1
00007cbcc2dd40be  movaps [rcx], xmm14
00007cbcc2dd40c2  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd40cc  call rax
00007cbcc2dd40ce  movaps xmm12, [rsp]
00007cbcc2dd40d3  add rsp, 0x40
00007cbcc2dd40d7  vmovaps xmm0, [rsp]
00007cbcc2dd40dc  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd40e2  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd40e8  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd40ee  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd40f4  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd40fa  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd4100  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd4106  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd410f  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd4118  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dd4121  vmovaps xmm11, [rsp+0xB0]
00007cbcc2dd412a  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd4133  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd413c  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd4145  add rsp, 0xF0
00007cbcc2dd414c  pop r11
00007cbcc2dd414e  pop r10
00007cbcc2dd4150  pop r9
00007cbcc2dd4152  pop r8
00007cbcc2dd4154  pop rsi
00007cbcc2dd4155  pop rdi
00007cbcc2dd4156  pop rdx
00007cbcc2dd4157  pop rcx
00007cbcc2dd4158  pop rax
00007cbcc2dd4159  add rsp, 0x08
00007cbcc2dd415d  jmp 0x00007CBCC2DD32E1
00007cbcc2dd4162  sub rsp, 0x08
00007cbcc2dd4166  push rax
00007cbcc2dd4167  push rcx
00007cbcc2dd4168  push rdx
00007cbcc2dd4169  push rdi
00007cbcc2dd416a  push rsi
00007cbcc2dd416b  push r8
00007cbcc2dd416d  push r9
00007cbcc2dd416f  push r10
00007cbcc2dd4171  push r11
00007cbcc2dd4173  sub rsp, 0xF0
00007cbcc2dd417a  vmovaps [rsp], xmm0
00007cbcc2dd417f  vmovaps [rsp+0x10], xmm1
00007cbcc2dd4185  vmovaps [rsp+0x20], xmm2
00007cbcc2dd418b  vmovaps [rsp+0x30], xmm3
00007cbcc2dd4191  vmovaps [rsp+0x40], xmm4
00007cbcc2dd4197  vmovaps [rsp+0x50], xmm5
00007cbcc2dd419d  vmovaps [rsp+0x60], xmm6
00007cbcc2dd41a3  vmovaps [rsp+0x70], xmm7
00007cbcc2dd41a9  vmovaps [rsp+0x80], xmm8
00007cbcc2dd41b2  vmovaps [rsp+0x90], xmm9
00007cbcc2dd41bb  vmovaps [rsp+0xA0], xmm10
00007cbcc2dd41c4  vmovaps [rsp+0xB0], xmm11
00007cbcc2dd41cd  vmovaps [rsp+0xC0], xmm12
00007cbcc2dd41d6  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd41df  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd41e8  sub rsp, 0x40
00007cbcc2dd41ec  lea rdi, [rsp]
00007cbcc2dd41f0  lea rsi, [rsp+0x10]
00007cbcc2dd41f5  lea rdx, [rsp+0x20]
00007cbcc2dd41fa  lea rcx, [rsp+0x30]
00007cbcc2dd41ff  mov r8d, 0x00
00007cbcc2dd4205  lea r9, [r15+0x3A8]
00007cbcc2dd420c  movaps [rdi], xmm13
00007cbcc2dd4210  movaps [rsi], xmm1
00007cbcc2dd4213  movaps [rdx], xmm15
00007cbcc2dd4217  movaps [rcx], xmm14
00007cbcc2dd421b  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd4225  call rax
00007cbcc2dd4227  movaps xmm13, [rsp]
00007cbcc2dd422c  add rsp, 0x40
00007cbcc2dd4230  vmovaps xmm0, [rsp]
00007cbcc2dd4235  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd423b  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd4241  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd4247  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd424d  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd4253  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd4259  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd425f  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd4268  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd4271  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dd427a  vmovaps xmm11, [rsp+0xB0]
00007cbcc2dd4283  vmovaps xmm12, [rsp+0xC0]
00007cbcc2dd428c  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd4295  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd429e  add rsp, 0xF0
00007cbcc2dd42a5  pop r11
00007cbcc2dd42a7  pop r10
00007cbcc2dd42a9  pop r9
00007cbcc2dd42ab  pop r8
00007cbcc2dd42ad  pop rsi
00007cbcc2dd42ae  pop rdi
00007cbcc2dd42af  pop rdx
00007cbcc2dd42b0  pop rcx
00007cbcc2dd42b1  pop rax
00007cbcc2dd42b2  add rsp, 0x08
00007cbcc2dd42b6  jmp 0x00007CBCC2DD3482
00007cbcc2dd42bb  sub rsp, 0x08
00007cbcc2dd42bf  push rax
00007cbcc2dd42c0  push rcx
00007cbcc2dd42c1  push rdx
00007cbcc2dd42c2  push rdi
00007cbcc2dd42c3  push rsi
00007cbcc2dd42c4  push r8
00007cbcc2dd42c6  push r9
00007cbcc2dd42c8  push r10
00007cbcc2dd42ca  push r11
00007cbcc2dd42cc  sub rsp, 0xF0
00007cbcc2dd42d3  vmovaps [rsp], xmm0
00007cbcc2dd42d8  vmovaps [rsp+0x10], xmm1
00007cbcc2dd42de  vmovaps [rsp+0x20], xmm2
00007cbcc2dd42e4  vmovaps [rsp+0x30], xmm3
00007cbcc2dd42ea  vmovaps [rsp+0x40], xmm4
00007cbcc2dd42f0  vmovaps [rsp+0x50], xmm5
00007cbcc2dd42f6  vmovaps [rsp+0x60], xmm6
00007cbcc2dd42fc  vmovaps [rsp+0x70], xmm7
00007cbcc2dd4302  vmovaps [rsp+0x80], xmm8
00007cbcc2dd430b  vmovaps [rsp+0x90], xmm9
00007cbcc2dd4314  vmovaps [rsp+0xA0], xmm10
00007cbcc2dd431d  vmovaps [rsp+0xB0], xmm11
00007cbcc2dd4326  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd432f  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd4338  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd4341  sub rsp, 0x40
00007cbcc2dd4345  lea rdi, [rsp]
00007cbcc2dd4349  lea rsi, [rsp+0x10]
00007cbcc2dd434e  lea rdx, [rsp+0x20]
00007cbcc2dd4353  lea rcx, [rsp+0x30]
00007cbcc2dd4358  mov r8d, 0x00
00007cbcc2dd435e  lea r9, [r15+0x3A8]
00007cbcc2dd4365  movaps [rdi], xmm12
00007cbcc2dd4369  movaps [rsi], xmm15
00007cbcc2dd436d  movaps [rdx], xmm14
00007cbcc2dd4371  movaps [rcx], xmm1
00007cbcc2dd4374  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd437e  call rax
00007cbcc2dd4380  movaps xmm12, [rsp]
00007cbcc2dd4385  add rsp, 0x40
00007cbcc2dd4389  vmovaps xmm0, [rsp]
00007cbcc2dd438e  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd4394  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd439a  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd43a0  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd43a6  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd43ac  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd43b2  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd43b8  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd43c1  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd43ca  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dd43d3  vmovaps xmm11, [rsp+0xB0]
00007cbcc2dd43dc  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd43e5  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd43ee  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd43f7  add rsp, 0xF0
00007cbcc2dd43fe  pop r11
00007cbcc2dd4400  pop r10
00007cbcc2dd4402  pop r9
00007cbcc2dd4404  pop r8
00007cbcc2dd4406  pop rsi
00007cbcc2dd4407  pop rdi
00007cbcc2dd4408  pop rdx
00007cbcc2dd4409  pop rcx
00007cbcc2dd440a  pop rax
00007cbcc2dd440b  add rsp, 0x08
00007cbcc2dd440f  jmp 0x00007CBCC2DD34C0
00007cbcc2dd4414  sub rsp, 0x08
00007cbcc2dd4418  push rax
00007cbcc2dd4419  push rcx
00007cbcc2dd441a  push rdx
00007cbcc2dd441b  push rdi
00007cbcc2dd441c  push rsi
00007cbcc2dd441d  push r8
00007cbcc2dd441f  push r9
00007cbcc2dd4421  push r10
00007cbcc2dd4423  push r11
00007cbcc2dd4425  sub rsp, 0xF0
00007cbcc2dd442c  vmovaps [rsp], xmm0
00007cbcc2dd4431  vmovaps [rsp+0x10], xmm1
00007cbcc2dd4437  vmovaps [rsp+0x20], xmm2
00007cbcc2dd443d  vmovaps [rsp+0x30], xmm3
00007cbcc2dd4443  vmovaps [rsp+0x40], xmm4
00007cbcc2dd4449  vmovaps [rsp+0x50], xmm5
00007cbcc2dd444f  vmovaps [rsp+0x60], xmm6
00007cbcc2dd4455  vmovaps [rsp+0x70], xmm7
00007cbcc2dd445b  vmovaps [rsp+0x80], xmm8
00007cbcc2dd4464  vmovaps [rsp+0x90], xmm9
00007cbcc2dd446d  vmovaps [rsp+0xA0], xmm10
00007cbcc2dd4476  vmovaps [rsp+0xB0], xmm11
00007cbcc2dd447f  vmovaps [rsp+0xC0], xmm12
00007cbcc2dd4488  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd4491  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd449a  sub rsp, 0x40
00007cbcc2dd449e  lea rdi, [rsp]
00007cbcc2dd44a2  lea rsi, [rsp+0x10]
00007cbcc2dd44a7  lea rdx, [rsp+0x20]
00007cbcc2dd44ac  lea rcx, [rsp+0x30]
00007cbcc2dd44b1  mov r8d, 0x00
00007cbcc2dd44b7  lea r9, [r15+0x3A8]
00007cbcc2dd44be  movaps [rdi], xmm13
00007cbcc2dd44c2  movaps [rsi], xmm15
00007cbcc2dd44c6  movaps [rdx], xmm14
00007cbcc2dd44ca  movaps [rcx], xmm1
00007cbcc2dd44cd  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd44d7  call rax
00007cbcc2dd44d9  movaps xmm13, [rsp]
00007cbcc2dd44de  add rsp, 0x40
00007cbcc2dd44e2  vmovaps xmm0, [rsp]
00007cbcc2dd44e7  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd44ed  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd44f3  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd44f9  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd44ff  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd4505  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd450b  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd4511  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd451a  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd4523  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dd452c  vmovaps xmm11, [rsp+0xB0]
00007cbcc2dd4535  vmovaps xmm12, [rsp+0xC0]
00007cbcc2dd453e  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd4547  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd4550  add rsp, 0xF0
00007cbcc2dd4557  pop r11
00007cbcc2dd4559  pop r10
00007cbcc2dd455b  pop r9
00007cbcc2dd455d  pop r8
00007cbcc2dd455f  pop rsi
00007cbcc2dd4560  pop rdi
00007cbcc2dd4561  pop rdx
00007cbcc2dd4562  pop rcx
00007cbcc2dd4563  pop rax
00007cbcc2dd4564  add rsp, 0x08
00007cbcc2dd4568  jmp 0x00007CBCC2DD34FE
00007cbcc2dd456d  sub rsp, 0x08
00007cbcc2dd4571  push rax
00007cbcc2dd4572  push rcx
00007cbcc2dd4573  push rdx
00007cbcc2dd4574  push rdi
00007cbcc2dd4575  push rsi
00007cbcc2dd4576  push r8
00007cbcc2dd4578  push r9
00007cbcc2dd457a  push r10
00007cbcc2dd457c  push r11
00007cbcc2dd457e  sub rsp, 0xF0
00007cbcc2dd4585  vmovaps [rsp], xmm0
00007cbcc2dd458a  vmovaps [rsp+0x10], xmm1
00007cbcc2dd4590  vmovaps [rsp+0x20], xmm2
00007cbcc2dd4596  vmovaps [rsp+0x30], xmm3
00007cbcc2dd459c  vmovaps [rsp+0x40], xmm4
00007cbcc2dd45a2  vmovaps [rsp+0x50], xmm5
00007cbcc2dd45a8  vmovaps [rsp+0x60], xmm6
00007cbcc2dd45ae  vmovaps [rsp+0x70], xmm7
00007cbcc2dd45b4  vmovaps [rsp+0x80], xmm8
00007cbcc2dd45bd  vmovaps [rsp+0x90], xmm9
00007cbcc2dd45c6  vmovaps [rsp+0xA0], xmm10
00007cbcc2dd45cf  vmovaps [rsp+0xB0], xmm11
00007cbcc2dd45d8  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd45e1  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd45ea  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd45f3  sub rsp, 0x40
00007cbcc2dd45f7  lea rdi, [rsp]
00007cbcc2dd45fb  lea rsi, [rsp+0x10]
00007cbcc2dd4600  lea rdx, [rsp+0x20]
00007cbcc2dd4605  lea rcx, [rsp+0x30]
00007cbcc2dd460a  mov r8d, 0x00
00007cbcc2dd4610  lea r9, [r15+0x3A8]
00007cbcc2dd4617  movaps [rdi], xmm12
00007cbcc2dd461b  movaps [rsi], xmm14
00007cbcc2dd461f  movaps [rdx], xmm2
00007cbcc2dd4622  movaps [rcx], xmm15
00007cbcc2dd4626  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd4630  call rax
00007cbcc2dd4632  movaps xmm12, [rsp]
00007cbcc2dd4637  add rsp, 0x40
00007cbcc2dd463b  vmovaps xmm0, [rsp]
00007cbcc2dd4640  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd4646  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd464c  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd4652  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd4658  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd465e  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd4664  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd466a  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd4673  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd467c  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dd4685  vmovaps xmm11, [rsp+0xB0]
00007cbcc2dd468e  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd4697  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd46a0  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd46a9  add rsp, 0xF0
00007cbcc2dd46b0  pop r11
00007cbcc2dd46b2  pop r10
00007cbcc2dd46b4  pop r9
00007cbcc2dd46b6  pop r8
00007cbcc2dd46b8  pop rsi
00007cbcc2dd46b9  pop rdi
00007cbcc2dd46ba  pop rdx
00007cbcc2dd46bb  pop rcx
00007cbcc2dd46bc  pop rax
00007cbcc2dd46bd  add rsp, 0x08
00007cbcc2dd46c1  jmp 0x00007CBCC2DD3558
00007cbcc2dd46c6  sub rsp, 0x08
00007cbcc2dd46ca  push rax
00007cbcc2dd46cb  push rcx
00007cbcc2dd46cc  push rdx
00007cbcc2dd46cd  push rdi
00007cbcc2dd46ce  push rsi
00007cbcc2dd46cf  push r8
00007cbcc2dd46d1  push r9
00007cbcc2dd46d3  push r10
00007cbcc2dd46d5  push r11
00007cbcc2dd46d7  sub rsp, 0xF0
00007cbcc2dd46de  vmovaps [rsp], xmm0
00007cbcc2dd46e3  vmovaps [rsp+0x10], xmm1
00007cbcc2dd46e9  vmovaps [rsp+0x20], xmm3
00007cbcc2dd46ef  vmovaps [rsp+0x30], xmm4
00007cbcc2dd46f5  vmovaps [rsp+0x40], xmm5
00007cbcc2dd46fb  vmovaps [rsp+0x50], xmm6
00007cbcc2dd4701  vmovaps [rsp+0x60], xmm7
00007cbcc2dd4707  vmovaps [rsp+0x70], xmm8
00007cbcc2dd470d  vmovaps [rsp+0x80], xmm9
00007cbcc2dd4716  vmovaps [rsp+0x90], xmm10
00007cbcc2dd471f  vmovaps [rsp+0xA0], xmm11
00007cbcc2dd4728  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd4731  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd473a  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd4743  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd474c  sub rsp, 0x40
00007cbcc2dd4750  lea rdi, [rsp]
00007cbcc2dd4754  lea rsi, [rsp+0x10]
00007cbcc2dd4759  lea rdx, [rsp+0x20]
00007cbcc2dd475e  lea rcx, [rsp+0x30]
00007cbcc2dd4763  mov r8d, 0x00
00007cbcc2dd4769  lea r9, [r15+0x3A8]
00007cbcc2dd4770  movaps [rdi], xmm2
00007cbcc2dd4773  movaps [rsi], xmm14
00007cbcc2dd4777  movaps [rdx], xmm8
00007cbcc2dd477b  movaps [rcx], xmm5
00007cbcc2dd477e  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd4788  call rax
00007cbcc2dd478a  movaps xmm2, [rsp]
00007cbcc2dd478e  add rsp, 0x40
00007cbcc2dd4792  vmovaps xmm0, [rsp]
00007cbcc2dd4797  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd479d  vmovaps xmm3, [rsp+0x20]
00007cbcc2dd47a3  vmovaps xmm4, [rsp+0x30]
00007cbcc2dd47a9  vmovaps xmm5, [rsp+0x40]
00007cbcc2dd47af  vmovaps xmm6, [rsp+0x50]
00007cbcc2dd47b5  vmovaps xmm7, [rsp+0x60]
00007cbcc2dd47bb  vmovaps xmm8, [rsp+0x70]
00007cbcc2dd47c1  vmovaps xmm9, [rsp+0x80]
00007cbcc2dd47ca  vmovaps xmm10, [rsp+0x90]
00007cbcc2dd47d3  vmovaps xmm11, [rsp+0xA0]
00007cbcc2dd47dc  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd47e5  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd47ee  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd47f7  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd4800  add rsp, 0xF0
00007cbcc2dd4807  pop r11
00007cbcc2dd4809  pop r10
00007cbcc2dd480b  pop r9
00007cbcc2dd480d  pop r8
00007cbcc2dd480f  pop rsi
00007cbcc2dd4810  pop rdi
00007cbcc2dd4811  pop rdx
00007cbcc2dd4812  pop rcx
00007cbcc2dd4813  pop rax
00007cbcc2dd4814  add rsp, 0x08
00007cbcc2dd4818  jmp 0x00007CBCC2DD360C
00007cbcc2dd481d  sub rsp, 0x08
00007cbcc2dd4821  push rax
00007cbcc2dd4822  push rcx
00007cbcc2dd4823  push rdx
00007cbcc2dd4824  push rdi
00007cbcc2dd4825  push rsi
00007cbcc2dd4826  push r8
00007cbcc2dd4828  push r9
00007cbcc2dd482a  push r10
00007cbcc2dd482c  push r11
00007cbcc2dd482e  sub rsp, 0xF0
00007cbcc2dd4835  vmovaps [rsp], xmm0
00007cbcc2dd483a  vmovaps [rsp+0x10], xmm1
00007cbcc2dd4840  vmovaps [rsp+0x20], xmm2
00007cbcc2dd4846  vmovaps [rsp+0x30], xmm3
00007cbcc2dd484c  vmovaps [rsp+0x40], xmm4
00007cbcc2dd4852  vmovaps [rsp+0x50], xmm6
00007cbcc2dd4858  vmovaps [rsp+0x60], xmm7
00007cbcc2dd485e  vmovaps [rsp+0x70], xmm8
00007cbcc2dd4864  vmovaps [rsp+0x80], xmm9
00007cbcc2dd486d  vmovaps [rsp+0x90], xmm10
00007cbcc2dd4876  vmovaps [rsp+0xA0], xmm11
00007cbcc2dd487f  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd4888  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd4891  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd489a  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd48a3  sub rsp, 0x40
00007cbcc2dd48a7  lea rdi, [rsp]
00007cbcc2dd48ab  lea rsi, [rsp+0x10]
00007cbcc2dd48b0  lea rdx, [rsp+0x20]
00007cbcc2dd48b5  lea rcx, [rsp+0x30]
00007cbcc2dd48ba  mov r8d, 0x00
00007cbcc2dd48c0  lea r9, [r15+0x3A8]
00007cbcc2dd48c7  movaps [rdi], xmm5
00007cbcc2dd48ca  movaps [rsi], xmm14
00007cbcc2dd48ce  movaps [rdx], xmm8
00007cbcc2dd48d2  movaps [rcx], xmm1
00007cbcc2dd48d5  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd48df  call rax
00007cbcc2dd48e1  movaps xmm5, [rsp]
00007cbcc2dd48e5  add rsp, 0x40
00007cbcc2dd48e9  vmovaps xmm0, [rsp]
00007cbcc2dd48ee  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd48f4  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd48fa  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd4900  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd4906  vmovaps xmm6, [rsp+0x50]
00007cbcc2dd490c  vmovaps xmm7, [rsp+0x60]
00007cbcc2dd4912  vmovaps xmm8, [rsp+0x70]
00007cbcc2dd4918  vmovaps xmm9, [rsp+0x80]
00007cbcc2dd4921  vmovaps xmm10, [rsp+0x90]
00007cbcc2dd492a  vmovaps xmm11, [rsp+0xA0]
00007cbcc2dd4933  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd493c  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd4945  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd494e  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd4957  add rsp, 0xF0
00007cbcc2dd495e  pop r11
00007cbcc2dd4960  pop r10
00007cbcc2dd4962  pop r9
00007cbcc2dd4964  pop r8
00007cbcc2dd4966  pop rsi
00007cbcc2dd4967  pop rdi
00007cbcc2dd4968  pop rdx
00007cbcc2dd4969  pop rcx
00007cbcc2dd496a  pop rax
00007cbcc2dd496b  add rsp, 0x08
00007cbcc2dd496f  jmp 0x00007CBCC2DD3649
00007cbcc2dd4974  sub rsp, 0x08
00007cbcc2dd4978  push rax
00007cbcc2dd4979  push rcx
00007cbcc2dd497a  push rdx
00007cbcc2dd497b  push rdi
00007cbcc2dd497c  push rsi
00007cbcc2dd497d  push r8
00007cbcc2dd497f  push r9
00007cbcc2dd4981  push r10
00007cbcc2dd4983  push r11
00007cbcc2dd4985  sub rsp, 0xF0
00007cbcc2dd498c  vmovaps [rsp], xmm0
00007cbcc2dd4991  vmovaps [rsp+0x10], xmm1
00007cbcc2dd4997  vmovaps [rsp+0x20], xmm2
00007cbcc2dd499d  vmovaps [rsp+0x30], xmm3
00007cbcc2dd49a3  vmovaps [rsp+0x40], xmm4
00007cbcc2dd49a9  vmovaps [rsp+0x50], xmm5
00007cbcc2dd49af  vmovaps [rsp+0x60], xmm6
00007cbcc2dd49b5  vmovaps [rsp+0x70], xmm7
00007cbcc2dd49bb  vmovaps [rsp+0x80], xmm8
00007cbcc2dd49c4  vmovaps [rsp+0x90], xmm9
00007cbcc2dd49cd  vmovaps [rsp+0xA0], xmm10
00007cbcc2dd49d6  vmovaps [rsp+0xB0], xmm11
00007cbcc2dd49df  vmovaps [rsp+0xC0], xmm12
00007cbcc2dd49e8  vmovaps [rsp+0xD0], xmm13
00007cbcc2dd49f1  vmovaps [rsp+0xE0], xmm14
00007cbcc2dd49fa  sub rsp, 0x40
00007cbcc2dd49fe  lea rdi, [rsp]
00007cbcc2dd4a02  lea rsi, [rsp+0x10]
00007cbcc2dd4a07  lea rdx, [rsp+0x20]
00007cbcc2dd4a0c  lea rcx, [rsp+0x30]
00007cbcc2dd4a11  mov r8d, 0x00
00007cbcc2dd4a17  lea r9, [r15+0x3A8]
00007cbcc2dd4a1e  movaps [rdi], xmm15
00007cbcc2dd4a22  movaps [rsi], xmm13
00007cbcc2dd4a26  movaps [rdx], xmm14
00007cbcc2dd4a2a  movaps [rcx], xmm1
00007cbcc2dd4a2d  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd4a37  call rax
00007cbcc2dd4a39  movaps xmm15, [rsp]
00007cbcc2dd4a3e  add rsp, 0x40
00007cbcc2dd4a42  vmovaps xmm0, [rsp]
00007cbcc2dd4a47  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd4a4d  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd4a53  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd4a59  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd4a5f  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd4a65  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd4a6b  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd4a71  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd4a7a  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd4a83  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dd4a8c  vmovaps xmm11, [rsp+0xB0]
00007cbcc2dd4a95  vmovaps xmm12, [rsp+0xC0]
00007cbcc2dd4a9e  vmovaps xmm13, [rsp+0xD0]
00007cbcc2dd4aa7  vmovaps xmm14, [rsp+0xE0]
00007cbcc2dd4ab0  add rsp, 0xF0
00007cbcc2dd4ab7  pop r11
00007cbcc2dd4ab9  pop r10
00007cbcc2dd4abb  pop r9
00007cbcc2dd4abd  pop r8
00007cbcc2dd4abf  pop rsi
00007cbcc2dd4ac0  pop rdi
00007cbcc2dd4ac1  pop rdx
00007cbcc2dd4ac2  pop rcx
00007cbcc2dd4ac3  pop rax
00007cbcc2dd4ac4  add rsp, 0x08
00007cbcc2dd4ac8  jmp 0x00007CBCC2DD3678
00007cbcc2dd4acd  sub rsp, 0x08
00007cbcc2dd4ad1  push rax
00007cbcc2dd4ad2  push rcx
00007cbcc2dd4ad3  push rdx
00007cbcc2dd4ad4  push rdi
00007cbcc2dd4ad5  push rsi
00007cbcc2dd4ad6  push r8
00007cbcc2dd4ad8  push r9
00007cbcc2dd4ada  push r10
00007cbcc2dd4adc  push r11
00007cbcc2dd4ade  sub rsp, 0xF0
00007cbcc2dd4ae5  vmovaps [rsp], xmm0
00007cbcc2dd4aea  vmovaps [rsp+0x10], xmm1
00007cbcc2dd4af0  vmovaps [rsp+0x20], xmm2
00007cbcc2dd4af6  vmovaps [rsp+0x30], xmm3
00007cbcc2dd4afc  vmovaps [rsp+0x40], xmm4
00007cbcc2dd4b02  vmovaps [rsp+0x50], xmm5
00007cbcc2dd4b08  vmovaps [rsp+0x60], xmm6
00007cbcc2dd4b0e  vmovaps [rsp+0x70], xmm7
00007cbcc2dd4b14  vmovaps [rsp+0x80], xmm8
00007cbcc2dd4b1d  vmovaps [rsp+0x90], xmm9
00007cbcc2dd4b26  vmovaps [rsp+0xA0], xmm10
00007cbcc2dd4b2f  vmovaps [rsp+0xB0], xmm11
00007cbcc2dd4b38  vmovaps [rsp+0xC0], xmm12
00007cbcc2dd4b41  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd4b4a  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd4b53  sub rsp, 0x40
00007cbcc2dd4b57  lea rdi, [rsp]
00007cbcc2dd4b5b  lea rsi, [rsp+0x10]
00007cbcc2dd4b60  lea rdx, [rsp+0x20]
00007cbcc2dd4b65  lea rcx, [rsp+0x30]
00007cbcc2dd4b6a  mov r8d, 0x00
00007cbcc2dd4b70  lea r9, [r15+0x3A8]
00007cbcc2dd4b77  movaps [rdi], xmm13
00007cbcc2dd4b7b  movaps [rsi], xmm12
00007cbcc2dd4b7f  movaps [rdx], xmm14
00007cbcc2dd4b83  movaps [rcx], xmm1
00007cbcc2dd4b86  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd4b90  call rax
00007cbcc2dd4b92  movaps xmm13, [rsp]
00007cbcc2dd4b97  add rsp, 0x40
00007cbcc2dd4b9b  vmovaps xmm0, [rsp]
00007cbcc2dd4ba0  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd4ba6  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd4bac  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd4bb2  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd4bb8  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd4bbe  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd4bc4  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd4bca  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd4bd3  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd4bdc  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dd4be5  vmovaps xmm11, [rsp+0xB0]
00007cbcc2dd4bee  vmovaps xmm12, [rsp+0xC0]
00007cbcc2dd4bf7  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd4c00  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd4c09  add rsp, 0xF0
00007cbcc2dd4c10  pop r11
00007cbcc2dd4c12  pop r10
00007cbcc2dd4c14  pop r9
00007cbcc2dd4c16  pop r8
00007cbcc2dd4c18  pop rsi
00007cbcc2dd4c19  pop rdi
00007cbcc2dd4c1a  pop rdx
00007cbcc2dd4c1b  pop rcx
00007cbcc2dd4c1c  pop rax
00007cbcc2dd4c1d  add rsp, 0x08
00007cbcc2dd4c21  jmp 0x00007CBCC2DD36AA
00007cbcc2dd4c26  sub rsp, 0x08
00007cbcc2dd4c2a  push rax
00007cbcc2dd4c2b  push rcx
00007cbcc2dd4c2c  push rdx
00007cbcc2dd4c2d  push rdi
00007cbcc2dd4c2e  push rsi
00007cbcc2dd4c2f  push r8
00007cbcc2dd4c31  push r9
00007cbcc2dd4c33  push r10
00007cbcc2dd4c35  push r11
00007cbcc2dd4c37  sub rsp, 0xF0
00007cbcc2dd4c3e  vmovaps [rsp], xmm0
00007cbcc2dd4c43  vmovaps [rsp+0x10], xmm1
00007cbcc2dd4c49  vmovaps [rsp+0x20], xmm2
00007cbcc2dd4c4f  vmovaps [rsp+0x30], xmm3
00007cbcc2dd4c55  vmovaps [rsp+0x40], xmm4
00007cbcc2dd4c5b  vmovaps [rsp+0x50], xmm5
00007cbcc2dd4c61  vmovaps [rsp+0x60], xmm6
00007cbcc2dd4c67  vmovaps [rsp+0x70], xmm7
00007cbcc2dd4c6d  vmovaps [rsp+0x80], xmm8
00007cbcc2dd4c76  vmovaps [rsp+0x90], xmm9
00007cbcc2dd4c7f  vmovaps [rsp+0xA0], xmm10
00007cbcc2dd4c88  vmovaps [rsp+0xB0], xmm11
00007cbcc2dd4c91  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd4c9a  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd4ca3  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd4cac  sub rsp, 0x40
00007cbcc2dd4cb0  lea rdi, [rsp]
00007cbcc2dd4cb4  lea rsi, [rsp+0x10]
00007cbcc2dd4cb9  lea rdx, [rsp+0x20]
00007cbcc2dd4cbe  lea rcx, [rsp+0x30]
00007cbcc2dd4cc3  mov r8d, 0x00
00007cbcc2dd4cc9  lea r9, [r15+0x3A8]
00007cbcc2dd4cd0  movaps [rdi], xmm12
00007cbcc2dd4cd4  movaps [rsi], xmm5
00007cbcc2dd4cd7  movaps [rdx], xmm14
00007cbcc2dd4cdb  movaps [rcx], xmm4
00007cbcc2dd4cde  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd4ce8  call rax
00007cbcc2dd4cea  movaps xmm12, [rsp]
00007cbcc2dd4cef  add rsp, 0x40
00007cbcc2dd4cf3  vmovaps xmm0, [rsp]
00007cbcc2dd4cf8  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd4cfe  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd4d04  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd4d0a  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd4d10  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd4d16  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd4d1c  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd4d22  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd4d2b  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd4d34  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dd4d3d  vmovaps xmm11, [rsp+0xB0]
00007cbcc2dd4d46  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd4d4f  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd4d58  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd4d61  add rsp, 0xF0
00007cbcc2dd4d68  pop r11
00007cbcc2dd4d6a  pop r10
00007cbcc2dd4d6c  pop r9
00007cbcc2dd4d6e  pop r8
00007cbcc2dd4d70  pop rsi
00007cbcc2dd4d71  pop rdi
00007cbcc2dd4d72  pop rdx
00007cbcc2dd4d73  pop rcx
00007cbcc2dd4d74  pop rax
00007cbcc2dd4d75  add rsp, 0x08
00007cbcc2dd4d79  jmp 0x00007CBCC2DD3720
00007cbcc2dd4d7e  sub rsp, 0x08
00007cbcc2dd4d82  push rax
00007cbcc2dd4d83  push rcx
00007cbcc2dd4d84  push rdx
00007cbcc2dd4d85  push rdi
00007cbcc2dd4d86  push rsi
00007cbcc2dd4d87  push r8
00007cbcc2dd4d89  push r9
00007cbcc2dd4d8b  push r10
00007cbcc2dd4d8d  push r11
00007cbcc2dd4d8f  sub rsp, 0xF0
00007cbcc2dd4d96  vmovaps [rsp], xmm0
00007cbcc2dd4d9b  vmovaps [rsp+0x10], xmm1
00007cbcc2dd4da1  vmovaps [rsp+0x20], xmm2
00007cbcc2dd4da7  vmovaps [rsp+0x30], xmm3
00007cbcc2dd4dad  vmovaps [rsp+0x40], xmm4
00007cbcc2dd4db3  vmovaps [rsp+0x50], xmm5
00007cbcc2dd4db9  vmovaps [rsp+0x60], xmm6
00007cbcc2dd4dbf  vmovaps [rsp+0x70], xmm7
00007cbcc2dd4dc5  vmovaps [rsp+0x80], xmm8
00007cbcc2dd4dce  vmovaps [rsp+0x90], xmm9
00007cbcc2dd4dd7  vmovaps [rsp+0xA0], xmm11
00007cbcc2dd4de0  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd4de9  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd4df2  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd4dfb  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd4e04  sub rsp, 0x40
00007cbcc2dd4e08  lea rdi, [rsp]
00007cbcc2dd4e0c  lea rsi, [rsp+0x10]
00007cbcc2dd4e11  lea rdx, [rsp+0x20]
00007cbcc2dd4e16  lea rcx, [rsp+0x30]
00007cbcc2dd4e1b  mov r8d, 0x00
00007cbcc2dd4e21  lea r9, [r15+0x3A8]
00007cbcc2dd4e28  movaps [rdi], xmm10
00007cbcc2dd4e2c  movaps [rsi], xmm2
00007cbcc2dd4e2f  movaps [rdx], xmm6
00007cbcc2dd4e32  movaps [rcx], xmm14
00007cbcc2dd4e36  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd4e40  call rax
00007cbcc2dd4e42  movaps xmm10, [rsp]
00007cbcc2dd4e47  add rsp, 0x40
00007cbcc2dd4e4b  vmovaps xmm0, [rsp]
00007cbcc2dd4e50  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd4e56  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd4e5c  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd4e62  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd4e68  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd4e6e  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd4e74  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd4e7a  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd4e83  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd4e8c  vmovaps xmm11, [rsp+0xA0]
00007cbcc2dd4e95  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd4e9e  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd4ea7  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd4eb0  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd4eb9  add rsp, 0xF0
00007cbcc2dd4ec0  pop r11
00007cbcc2dd4ec2  pop r10
00007cbcc2dd4ec4  pop r9
00007cbcc2dd4ec6  pop r8
00007cbcc2dd4ec8  pop rsi
00007cbcc2dd4ec9  pop rdi
00007cbcc2dd4eca  pop rdx
00007cbcc2dd4ecb  pop rcx
00007cbcc2dd4ecc  pop rax
00007cbcc2dd4ecd  add rsp, 0x08
00007cbcc2dd4ed1  jmp 0x00007CBCC2DD3746
00007cbcc2dd4ed6  call 0x00007CBCC2CE45A0
00007cbcc2dd4edb  jmp 0x00007CBCC2DD3753
00007cbcc2dd4ee0  sub rsp, 0x08
00007cbcc2dd4ee4  push rax
00007cbcc2dd4ee5  push rcx
00007cbcc2dd4ee6  push rdx
00007cbcc2dd4ee7  push rdi
00007cbcc2dd4ee8  push rsi
00007cbcc2dd4ee9  push r8
00007cbcc2dd4eeb  push r9
00007cbcc2dd4eed  push r10
00007cbcc2dd4eef  push r11
00007cbcc2dd4ef1  sub rsp, 0xF0
00007cbcc2dd4ef8  vmovaps [rsp], xmm0
00007cbcc2dd4efd  vmovaps [rsp+0x10], xmm1
00007cbcc2dd4f03  vmovaps [rsp+0x20], xmm2
00007cbcc2dd4f09  vmovaps [rsp+0x30], xmm3
00007cbcc2dd4f0f  vmovaps [rsp+0x40], xmm4
00007cbcc2dd4f15  vmovaps [rsp+0x50], xmm6
00007cbcc2dd4f1b  vmovaps [rsp+0x60], xmm7
00007cbcc2dd4f21  vmovaps [rsp+0x70], xmm8
00007cbcc2dd4f27  vmovaps [rsp+0x80], xmm9
00007cbcc2dd4f30  vmovaps [rsp+0x90], xmm10
00007cbcc2dd4f39  vmovaps [rsp+0xA0], xmm11
00007cbcc2dd4f42  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd4f4b  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd4f54  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd4f5d  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd4f66  sub rsp, 0x40
00007cbcc2dd4f6a  lea rdi, [rsp]
00007cbcc2dd4f6e  lea rsi, [rsp+0x10]
00007cbcc2dd4f73  lea rdx, [rsp+0x20]
00007cbcc2dd4f78  lea rcx, [rsp+0x30]
00007cbcc2dd4f7d  mov r8d, 0x00
00007cbcc2dd4f83  lea r9, [r15+0x3A8]
00007cbcc2dd4f8a  movaps [rdi], xmm5
00007cbcc2dd4f8d  movaps [rsi], xmm15
00007cbcc2dd4f91  movaps [rdx], xmm6
00007cbcc2dd4f94  movaps [rcx], xmm8
00007cbcc2dd4f98  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd4fa2  call rax
00007cbcc2dd4fa4  movaps xmm5, [rsp]
00007cbcc2dd4fa8  add rsp, 0x40
00007cbcc2dd4fac  vmovaps xmm0, [rsp]
00007cbcc2dd4fb1  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd4fb7  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd4fbd  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd4fc3  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd4fc9  vmovaps xmm6, [rsp+0x50]
00007cbcc2dd4fcf  vmovaps xmm7, [rsp+0x60]
00007cbcc2dd4fd5  vmovaps xmm8, [rsp+0x70]
00007cbcc2dd4fdb  vmovaps xmm9, [rsp+0x80]
00007cbcc2dd4fe4  vmovaps xmm10, [rsp+0x90]
00007cbcc2dd4fed  vmovaps xmm11, [rsp+0xA0]
00007cbcc2dd4ff6  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd4fff  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd5008  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd5011  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd501a  add rsp, 0xF0
00007cbcc2dd5021  pop r11
00007cbcc2dd5023  pop r10
00007cbcc2dd5025  pop r9
00007cbcc2dd5027  pop r8
00007cbcc2dd5029  pop rsi
00007cbcc2dd502a  pop rdi
00007cbcc2dd502b  pop rdx
00007cbcc2dd502c  pop rcx
00007cbcc2dd502d  pop rax
00007cbcc2dd502e  add rsp, 0x08
00007cbcc2dd5032  jmp 0x00007CBCC2DD3789
00007cbcc2dd5037  sub rsp, 0x08
00007cbcc2dd503b  push rax
00007cbcc2dd503c  push rcx
00007cbcc2dd503d  push rdx
00007cbcc2dd503e  push rdi
00007cbcc2dd503f  push rsi
00007cbcc2dd5040  push r8
00007cbcc2dd5042  push r9
00007cbcc2dd5044  push r10
00007cbcc2dd5046  push r11
00007cbcc2dd5048  sub rsp, 0xF0
00007cbcc2dd504f  vmovaps [rsp], xmm0
00007cbcc2dd5054  vmovaps [rsp+0x10], xmm1
00007cbcc2dd505a  vmovaps [rsp+0x20], xmm2
00007cbcc2dd5060  vmovaps [rsp+0x30], xmm3
00007cbcc2dd5066  vmovaps [rsp+0x40], xmm4
00007cbcc2dd506c  vmovaps [rsp+0x50], xmm5
00007cbcc2dd5072  vmovaps [rsp+0x60], xmm6
00007cbcc2dd5078  vmovaps [rsp+0x70], xmm7
00007cbcc2dd507e  vmovaps [rsp+0x80], xmm9
00007cbcc2dd5087  vmovaps [rsp+0x90], xmm10
00007cbcc2dd5090  vmovaps [rsp+0xA0], xmm11
00007cbcc2dd5099  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd50a2  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd50ab  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd50b4  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd50bd  sub rsp, 0x40
00007cbcc2dd50c1  lea rdi, [rsp]
00007cbcc2dd50c5  lea rsi, [rsp+0x10]
00007cbcc2dd50ca  lea rdx, [rsp+0x20]
00007cbcc2dd50cf  lea rcx, [rsp+0x30]
00007cbcc2dd50d4  mov r8d, 0x00
00007cbcc2dd50da  lea r9, [r15+0x3A8]
00007cbcc2dd50e1  movaps [rdi], xmm8
00007cbcc2dd50e5  movaps [rsi], xmm13
00007cbcc2dd50e9  movaps [rdx], xmm1
00007cbcc2dd50ec  movaps [rcx], xmm15
00007cbcc2dd50f0  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd50fa  call rax
00007cbcc2dd50fc  movaps xmm8, [rsp]
00007cbcc2dd5101  add rsp, 0x40
00007cbcc2dd5105  vmovaps xmm0, [rsp]
00007cbcc2dd510a  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd5110  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd5116  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd511c  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd5122  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd5128  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd512e  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd5134  vmovaps xmm9, [rsp+0x80]
00007cbcc2dd513d  vmovaps xmm10, [rsp+0x90]
00007cbcc2dd5146  vmovaps xmm11, [rsp+0xA0]
00007cbcc2dd514f  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd5158  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd5161  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd516a  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd5173  add rsp, 0xF0
00007cbcc2dd517a  pop r11
00007cbcc2dd517c  pop r10
00007cbcc2dd517e  pop r9
00007cbcc2dd5180  pop r8
00007cbcc2dd5182  pop rsi
00007cbcc2dd5183  pop rdi
00007cbcc2dd5184  pop rdx
00007cbcc2dd5185  pop rcx
00007cbcc2dd5186  pop rax
00007cbcc2dd5187  add rsp, 0x08
00007cbcc2dd518b  jmp 0x00007CBCC2DD37AF
00007cbcc2dd5190  call 0x00007CBCC2CE5820
00007cbcc2dd5195  jmp 0x00007CBCC2DD37D2
00007cbcc2dd519a  call 0x00007CBCC2CE3320
00007cbcc2dd519f  jmp 0x00007CBCC2DD37DC
00007cbcc2dd51a4  sub rsp, 0x08
00007cbcc2dd51a8  push rax
00007cbcc2dd51a9  push rcx
00007cbcc2dd51aa  push rdx
00007cbcc2dd51ab  push rdi
00007cbcc2dd51ac  push rsi
00007cbcc2dd51ad  push r8
00007cbcc2dd51af  push r9
00007cbcc2dd51b1  push r10
00007cbcc2dd51b3  push r11
00007cbcc2dd51b5  sub rsp, 0xF0
00007cbcc2dd51bc  vmovaps [rsp], xmm0
00007cbcc2dd51c1  vmovaps [rsp+0x10], xmm1
00007cbcc2dd51c7  vmovaps [rsp+0x20], xmm2
00007cbcc2dd51cd  vmovaps [rsp+0x30], xmm3
00007cbcc2dd51d3  vmovaps [rsp+0x40], xmm5
00007cbcc2dd51d9  vmovaps [rsp+0x50], xmm6
00007cbcc2dd51df  vmovaps [rsp+0x60], xmm7
00007cbcc2dd51e5  vmovaps [rsp+0x70], xmm8
00007cbcc2dd51eb  vmovaps [rsp+0x80], xmm9
00007cbcc2dd51f4  vmovaps [rsp+0x90], xmm10
00007cbcc2dd51fd  vmovaps [rsp+0xA0], xmm11
00007cbcc2dd5206  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd520f  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd5218  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd5221  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd522a  sub rsp, 0x40
00007cbcc2dd522e  lea rdi, [rsp]
00007cbcc2dd5232  lea rsi, [rsp+0x10]
00007cbcc2dd5237  lea rdx, [rsp+0x20]
00007cbcc2dd523c  lea rcx, [rsp+0x30]
00007cbcc2dd5241  mov r8d, 0x00
00007cbcc2dd5247  lea r9, [r15+0x3A8]
00007cbcc2dd524e  movaps [rdi], xmm4
00007cbcc2dd5251  movaps [rsi], xmm12
00007cbcc2dd5255  movaps [rdx], xmm9
00007cbcc2dd5259  movaps [rcx], xmm6
00007cbcc2dd525c  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd5266  call rax
00007cbcc2dd5268  movaps xmm4, [rsp]
00007cbcc2dd526c  add rsp, 0x40
00007cbcc2dd5270  vmovaps xmm0, [rsp]
00007cbcc2dd5275  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd527b  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd5281  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd5287  vmovaps xmm5, [rsp+0x40]
00007cbcc2dd528d  vmovaps xmm6, [rsp+0x50]
00007cbcc2dd5293  vmovaps xmm7, [rsp+0x60]
00007cbcc2dd5299  vmovaps xmm8, [rsp+0x70]
00007cbcc2dd529f  vmovaps xmm9, [rsp+0x80]
00007cbcc2dd52a8  vmovaps xmm10, [rsp+0x90]
00007cbcc2dd52b1  vmovaps xmm11, [rsp+0xA0]
00007cbcc2dd52ba  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd52c3  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd52cc  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd52d5  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd52de  add rsp, 0xF0
00007cbcc2dd52e5  pop r11
00007cbcc2dd52e7  pop r10
00007cbcc2dd52e9  pop r9
00007cbcc2dd52eb  pop r8
00007cbcc2dd52ed  pop rsi
00007cbcc2dd52ee  pop rdi
00007cbcc2dd52ef  pop rdx
00007cbcc2dd52f0  pop rcx
00007cbcc2dd52f1  pop rax
00007cbcc2dd52f2  add rsp, 0x08
00007cbcc2dd52f6  jmp 0x00007CBCC2DD3814
00007cbcc2dd52fb  sub rsp, 0x08
00007cbcc2dd52ff  push rax
00007cbcc2dd5300  push rcx
00007cbcc2dd5301  push rdx
00007cbcc2dd5302  push rdi
00007cbcc2dd5303  push rsi
00007cbcc2dd5304  push r8
00007cbcc2dd5306  push r9
00007cbcc2dd5308  push r10
00007cbcc2dd530a  push r11
00007cbcc2dd530c  sub rsp, 0xF0
00007cbcc2dd5313  vmovaps [rsp], xmm0
00007cbcc2dd5318  vmovaps [rsp+0x10], xmm1
00007cbcc2dd531e  vmovaps [rsp+0x20], xmm2
00007cbcc2dd5324  vmovaps [rsp+0x30], xmm3
00007cbcc2dd532a  vmovaps [rsp+0x40], xmm4
00007cbcc2dd5330  vmovaps [rsp+0x50], xmm5
00007cbcc2dd5336  vmovaps [rsp+0x60], xmm6
00007cbcc2dd533c  vmovaps [rsp+0x70], xmm7
00007cbcc2dd5342  vmovaps [rsp+0x80], xmm8
00007cbcc2dd534b  vmovaps [rsp+0x90], xmm10
00007cbcc2dd5354  vmovaps [rsp+0xA0], xmm11
00007cbcc2dd535d  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd5366  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd536f  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd5378  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd5381  sub rsp, 0x40
00007cbcc2dd5385  lea rdi, [rsp]
00007cbcc2dd5389  lea rsi, [rsp+0x10]
00007cbcc2dd538e  lea rdx, [rsp+0x20]
00007cbcc2dd5393  lea rcx, [rsp+0x30]
00007cbcc2dd5398  mov r8d, 0x00
00007cbcc2dd539e  lea r9, [r15+0x3A8]
00007cbcc2dd53a5  movaps [rdi], xmm9
00007cbcc2dd53a9  movaps [rsi], xmm10
00007cbcc2dd53ad  movaps [rdx], xmm1
00007cbcc2dd53b0  movaps [rcx], xmm12
00007cbcc2dd53b4  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd53be  call rax
00007cbcc2dd53c0  movaps xmm9, [rsp]
00007cbcc2dd53c5  add rsp, 0x40
00007cbcc2dd53c9  vmovaps xmm0, [rsp]
00007cbcc2dd53ce  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd53d4  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd53da  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd53e0  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd53e6  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd53ec  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd53f2  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd53f8  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd5401  vmovaps xmm10, [rsp+0x90]
00007cbcc2dd540a  vmovaps xmm11, [rsp+0xA0]
00007cbcc2dd5413  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd541c  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd5425  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd542e  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd5437  add rsp, 0xF0
00007cbcc2dd543e  pop r11
00007cbcc2dd5440  pop r10
00007cbcc2dd5442  pop r9
00007cbcc2dd5444  pop r8
00007cbcc2dd5446  pop rsi
00007cbcc2dd5447  pop rdi
00007cbcc2dd5448  pop rdx
00007cbcc2dd5449  pop rcx
00007cbcc2dd544a  pop rax
00007cbcc2dd544b  add rsp, 0x08
00007cbcc2dd544f  jmp 0x00007CBCC2DD383D
00007cbcc2dd5454  sub rsp, 0x08
00007cbcc2dd5458  push rax
00007cbcc2dd5459  push rcx
00007cbcc2dd545a  push rdx
00007cbcc2dd545b  push rdi
00007cbcc2dd545c  push rsi
00007cbcc2dd545d  push r8
00007cbcc2dd545f  push r9
00007cbcc2dd5461  push r10
00007cbcc2dd5463  push r11
00007cbcc2dd5465  sub rsp, 0xF0
00007cbcc2dd546c  vmovaps [rsp], xmm0
00007cbcc2dd5471  vmovaps [rsp+0x10], xmm1
00007cbcc2dd5477  vmovaps [rsp+0x20], xmm2
00007cbcc2dd547d  vmovaps [rsp+0x30], xmm3
00007cbcc2dd5483  vmovaps [rsp+0x40], xmm4
00007cbcc2dd5489  vmovaps [rsp+0x50], xmm5
00007cbcc2dd548f  vmovaps [rsp+0x60], xmm6
00007cbcc2dd5495  vmovaps [rsp+0x70], xmm7
00007cbcc2dd549b  vmovaps [rsp+0x80], xmm8
00007cbcc2dd54a4  vmovaps [rsp+0x90], xmm9
00007cbcc2dd54ad  vmovaps [rsp+0xA0], xmm11
00007cbcc2dd54b6  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd54bf  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd54c8  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd54d1  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd54da  sub rsp, 0x40
00007cbcc2dd54de  lea rdi, [rsp]
00007cbcc2dd54e2  lea rsi, [rsp+0x10]
00007cbcc2dd54e7  lea rdx, [rsp+0x20]
00007cbcc2dd54ec  lea rcx, [rsp+0x30]
00007cbcc2dd54f1  mov r8d, 0x00
00007cbcc2dd54f7  lea r9, [r15+0x3A8]
00007cbcc2dd54fe  movaps [rdi], xmm10
00007cbcc2dd5502  movaps [rsi], xmm5
00007cbcc2dd5505  movaps [rdx], xmm12
00007cbcc2dd5509  movaps [rcx], xmm1
00007cbcc2dd550c  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd5516  call rax
00007cbcc2dd5518  movaps xmm10, [rsp]
00007cbcc2dd551d  add rsp, 0x40
00007cbcc2dd5521  vmovaps xmm0, [rsp]
00007cbcc2dd5526  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd552c  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd5532  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd5538  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd553e  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd5544  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd554a  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd5550  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd5559  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd5562  vmovaps xmm11, [rsp+0xA0]
00007cbcc2dd556b  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd5574  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd557d  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd5586  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd558f  add rsp, 0xF0
00007cbcc2dd5596  pop r11
00007cbcc2dd5598  pop r10
00007cbcc2dd559a  pop r9
00007cbcc2dd559c  pop r8
00007cbcc2dd559e  pop rsi
00007cbcc2dd559f  pop rdi
00007cbcc2dd55a0  pop rdx
00007cbcc2dd55a1  pop rcx
00007cbcc2dd55a2  pop rax
00007cbcc2dd55a3  add rsp, 0x08
00007cbcc2dd55a7  jmp 0x00007CBCC2DD386C
00007cbcc2dd55ac  sub rsp, 0x08
00007cbcc2dd55b0  push rax
00007cbcc2dd55b1  push rcx
00007cbcc2dd55b2  push rdx
00007cbcc2dd55b3  push rdi
00007cbcc2dd55b4  push rsi
00007cbcc2dd55b5  push r8
00007cbcc2dd55b7  push r9
00007cbcc2dd55b9  push r10
00007cbcc2dd55bb  push r11
00007cbcc2dd55bd  sub rsp, 0xF0
00007cbcc2dd55c4  vmovaps [rsp], xmm0
00007cbcc2dd55c9  vmovaps [rsp+0x10], xmm1
00007cbcc2dd55cf  vmovaps [rsp+0x20], xmm2
00007cbcc2dd55d5  vmovaps [rsp+0x30], xmm3
00007cbcc2dd55db  vmovaps [rsp+0x40], xmm4
00007cbcc2dd55e1  vmovaps [rsp+0x50], xmm5
00007cbcc2dd55e7  vmovaps [rsp+0x60], xmm7
00007cbcc2dd55ed  vmovaps [rsp+0x70], xmm8
00007cbcc2dd55f3  vmovaps [rsp+0x80], xmm9
00007cbcc2dd55fc  vmovaps [rsp+0x90], xmm10
00007cbcc2dd5605  vmovaps [rsp+0xA0], xmm11
00007cbcc2dd560e  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd5617  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd5620  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd5629  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd5632  sub rsp, 0x40
00007cbcc2dd5636  lea rdi, [rsp]
00007cbcc2dd563a  lea rsi, [rsp+0x10]
00007cbcc2dd563f  lea rdx, [rsp+0x20]
00007cbcc2dd5644  lea rcx, [rsp+0x30]
00007cbcc2dd5649  mov r8d, 0x00
00007cbcc2dd564f  lea r9, [r15+0x3A8]
00007cbcc2dd5656  movaps [rdi], xmm6
00007cbcc2dd5659  movaps [rsi], xmm8
00007cbcc2dd565d  movaps [rdx], xmm12
00007cbcc2dd5661  movaps [rcx], xmm1
00007cbcc2dd5664  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd566e  call rax
00007cbcc2dd5670  movaps xmm6, [rsp]
00007cbcc2dd5674  add rsp, 0x40
00007cbcc2dd5678  vmovaps xmm0, [rsp]
00007cbcc2dd567d  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd5683  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd5689  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd568f  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd5695  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd569b  vmovaps xmm7, [rsp+0x60]
00007cbcc2dd56a1  vmovaps xmm8, [rsp+0x70]
00007cbcc2dd56a7  vmovaps xmm9, [rsp+0x80]
00007cbcc2dd56b0  vmovaps xmm10, [rsp+0x90]
00007cbcc2dd56b9  vmovaps xmm11, [rsp+0xA0]
00007cbcc2dd56c2  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd56cb  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd56d4  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd56dd  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd56e6  add rsp, 0xF0
00007cbcc2dd56ed  pop r11
00007cbcc2dd56ef  pop r10
00007cbcc2dd56f1  pop r9
00007cbcc2dd56f3  pop r8
00007cbcc2dd56f5  pop rsi
00007cbcc2dd56f6  pop rdi
00007cbcc2dd56f7  pop rdx
00007cbcc2dd56f8  pop rcx
00007cbcc2dd56f9  pop rax
00007cbcc2dd56fa  add rsp, 0x08
00007cbcc2dd56fe  jmp 0x00007CBCC2DD389A
00007cbcc2dd5703  call 0x00007CBCC2CD64F0
00007cbcc2dd5708  jmp 0x00007CBCC2DD38A4
00007cbcc2dd570d  call 0x00007CBCC2CE20A0
00007cbcc2dd5712  jmp 0x00007CBCC2DD38AE
00007cbcc2dd5717  sub rsp, 0x08
00007cbcc2dd571b  push rax
00007cbcc2dd571c  push rcx
00007cbcc2dd571d  push rdx
00007cbcc2dd571e  push rdi
00007cbcc2dd571f  push rsi
00007cbcc2dd5720  push r8
00007cbcc2dd5722  push r9
00007cbcc2dd5724  push r10
00007cbcc2dd5726  push r11
00007cbcc2dd5728  sub rsp, 0xF0
00007cbcc2dd572f  vmovaps [rsp], xmm0
00007cbcc2dd5734  vmovaps [rsp+0x10], xmm1
00007cbcc2dd573a  vmovaps [rsp+0x20], xmm2
00007cbcc2dd5740  vmovaps [rsp+0x30], xmm3
00007cbcc2dd5746  vmovaps [rsp+0x40], xmm4
00007cbcc2dd574c  vmovaps [rsp+0x50], xmm5
00007cbcc2dd5752  vmovaps [rsp+0x60], xmm6
00007cbcc2dd5758  vmovaps [rsp+0x70], xmm7
00007cbcc2dd575e  vmovaps [rsp+0x80], xmm9
00007cbcc2dd5767  vmovaps [rsp+0x90], xmm10
00007cbcc2dd5770  vmovaps [rsp+0xA0], xmm11
00007cbcc2dd5779  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd5782  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd578b  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd5794  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd579d  sub rsp, 0x40
00007cbcc2dd57a1  lea rdi, [rsp]
00007cbcc2dd57a5  lea rsi, [rsp+0x10]
00007cbcc2dd57aa  lea rdx, [rsp+0x20]
00007cbcc2dd57af  lea rcx, [rsp+0x30]
00007cbcc2dd57b4  mov r8d, 0x00
00007cbcc2dd57ba  lea r9, [r15+0x3A8]
00007cbcc2dd57c1  movaps [rdi], xmm8
00007cbcc2dd57c5  movaps [rsi], xmm4
00007cbcc2dd57c8  movaps [rdx], xmm13
00007cbcc2dd57cc  movaps [rcx], xmm11
00007cbcc2dd57d0  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd57da  call rax
00007cbcc2dd57dc  movaps xmm8, [rsp]
00007cbcc2dd57e1  add rsp, 0x40
00007cbcc2dd57e5  vmovaps xmm0, [rsp]
00007cbcc2dd57ea  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd57f0  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd57f6  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd57fc  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd5802  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd5808  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd580e  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd5814  vmovaps xmm9, [rsp+0x80]
00007cbcc2dd581d  vmovaps xmm10, [rsp+0x90]
00007cbcc2dd5826  vmovaps xmm11, [rsp+0xA0]
00007cbcc2dd582f  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd5838  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd5841  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd584a  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd5853  add rsp, 0xF0
00007cbcc2dd585a  pop r11
00007cbcc2dd585c  pop r10
00007cbcc2dd585e  pop r9
00007cbcc2dd5860  pop r8
00007cbcc2dd5862  pop rsi
00007cbcc2dd5863  pop rdi
00007cbcc2dd5864  pop rdx
00007cbcc2dd5865  pop rcx
00007cbcc2dd5866  pop rax
00007cbcc2dd5867  add rsp, 0x08
00007cbcc2dd586b  jmp 0x00007CBCC2DD38E4
00007cbcc2dd5870  sub rsp, 0x08
00007cbcc2dd5874  push rax
00007cbcc2dd5875  push rcx
00007cbcc2dd5876  push rdx
00007cbcc2dd5877  push rdi
00007cbcc2dd5878  push rsi
00007cbcc2dd5879  push r8
00007cbcc2dd587b  push r9
00007cbcc2dd587d  push r10
00007cbcc2dd587f  push r11
00007cbcc2dd5881  sub rsp, 0xF0
00007cbcc2dd5888  vmovaps [rsp], xmm0
00007cbcc2dd588d  vmovaps [rsp+0x10], xmm1
00007cbcc2dd5893  vmovaps [rsp+0x20], xmm2
00007cbcc2dd5899  vmovaps [rsp+0x30], xmm3
00007cbcc2dd589f  vmovaps [rsp+0x40], xmm4
00007cbcc2dd58a5  vmovaps [rsp+0x50], xmm5
00007cbcc2dd58ab  vmovaps [rsp+0x60], xmm6
00007cbcc2dd58b1  vmovaps [rsp+0x70], xmm7
00007cbcc2dd58b7  vmovaps [rsp+0x80], xmm8
00007cbcc2dd58c0  vmovaps [rsp+0x90], xmm9
00007cbcc2dd58c9  vmovaps [rsp+0xA0], xmm10
00007cbcc2dd58d2  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd58db  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd58e4  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd58ed  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd58f6  sub rsp, 0x40
00007cbcc2dd58fa  lea rdi, [rsp]
00007cbcc2dd58fe  lea rsi, [rsp+0x10]
00007cbcc2dd5903  lea rdx, [rsp+0x20]
00007cbcc2dd5908  lea rcx, [rsp+0x30]
00007cbcc2dd590d  mov r8d, 0x00
00007cbcc2dd5913  lea r9, [r15+0x3A8]
00007cbcc2dd591a  movaps [rdi], xmm11
00007cbcc2dd591e  movaps [rsi], xmm9
00007cbcc2dd5922  movaps [rdx], xmm1
00007cbcc2dd5925  movaps [rcx], xmm13
00007cbcc2dd5929  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd5933  call rax
00007cbcc2dd5935  movaps xmm11, [rsp]
00007cbcc2dd593a  add rsp, 0x40
00007cbcc2dd593e  vmovaps xmm0, [rsp]
00007cbcc2dd5943  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd5949  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd594f  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd5955  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd595b  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd5961  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd5967  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd596d  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd5976  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd597f  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dd5988  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd5991  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd599a  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd59a3  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd59ac  add rsp, 0xF0
00007cbcc2dd59b3  pop r11
00007cbcc2dd59b5  pop r10
00007cbcc2dd59b7  pop r9
00007cbcc2dd59b9  pop r8
00007cbcc2dd59bb  pop rsi
00007cbcc2dd59bc  pop rdi
00007cbcc2dd59bd  pop rdx
00007cbcc2dd59be  pop rcx
00007cbcc2dd59bf  pop rax
00007cbcc2dd59c0  add rsp, 0x08
00007cbcc2dd59c4  jmp 0x00007CBCC2DD390A
00007cbcc2dd59c9  sub rsp, 0x08
00007cbcc2dd59cd  push rax
00007cbcc2dd59ce  push rcx
00007cbcc2dd59cf  push rdx
00007cbcc2dd59d0  push rdi
00007cbcc2dd59d1  push rsi
00007cbcc2dd59d2  push r8
00007cbcc2dd59d4  push r9
00007cbcc2dd59d6  push r10
00007cbcc2dd59d8  push r11
00007cbcc2dd59da  sub rsp, 0xF0
00007cbcc2dd59e1  vmovaps [rsp], xmm0
00007cbcc2dd59e6  vmovaps [rsp+0x10], xmm1
00007cbcc2dd59ec  vmovaps [rsp+0x20], xmm2
00007cbcc2dd59f2  vmovaps [rsp+0x30], xmm3
00007cbcc2dd59f8  vmovaps [rsp+0x40], xmm4
00007cbcc2dd59fe  vmovaps [rsp+0x50], xmm5
00007cbcc2dd5a04  vmovaps [rsp+0x60], xmm6
00007cbcc2dd5a0a  vmovaps [rsp+0x70], xmm7
00007cbcc2dd5a10  vmovaps [rsp+0x80], xmm8
00007cbcc2dd5a19  vmovaps [rsp+0x90], xmm9
00007cbcc2dd5a22  vmovaps [rsp+0xA0], xmm10
00007cbcc2dd5a2b  vmovaps [rsp+0xB0], xmm11
00007cbcc2dd5a34  vmovaps [rsp+0xC0], xmm12
00007cbcc2dd5a3d  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd5a46  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd5a4f  sub rsp, 0x40
00007cbcc2dd5a53  lea rdi, [rsp]
00007cbcc2dd5a57  lea rsi, [rsp+0x10]
00007cbcc2dd5a5c  lea rdx, [rsp+0x20]
00007cbcc2dd5a61  lea rcx, [rsp+0x30]
00007cbcc2dd5a66  mov r8d, 0x00
00007cbcc2dd5a6c  lea r9, [r15+0x3A8]
00007cbcc2dd5a73  movaps [rdi], xmm13
00007cbcc2dd5a77  movaps [rsi], xmm10
00007cbcc2dd5a7b  movaps [rdx], xmm7
00007cbcc2dd5a7e  movaps [rcx], xmm1
00007cbcc2dd5a81  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd5a8b  call rax
00007cbcc2dd5a8d  movaps xmm13, [rsp]
00007cbcc2dd5a92  add rsp, 0x40
00007cbcc2dd5a96  vmovaps xmm0, [rsp]
00007cbcc2dd5a9b  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd5aa1  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd5aa7  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd5aad  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd5ab3  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd5ab9  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd5abf  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd5ac5  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd5ace  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd5ad7  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dd5ae0  vmovaps xmm11, [rsp+0xB0]
00007cbcc2dd5ae9  vmovaps xmm12, [rsp+0xC0]
00007cbcc2dd5af2  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd5afb  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd5b04  add rsp, 0xF0
00007cbcc2dd5b0b  pop r11
00007cbcc2dd5b0d  pop r10
00007cbcc2dd5b0f  pop r9
00007cbcc2dd5b11  pop r8
00007cbcc2dd5b13  pop rsi
00007cbcc2dd5b14  pop rdi
00007cbcc2dd5b15  pop rdx
00007cbcc2dd5b16  pop rcx
00007cbcc2dd5b17  pop rax
00007cbcc2dd5b18  add rsp, 0x08
00007cbcc2dd5b1c  jmp 0x00007CBCC2DD3930
00007cbcc2dd5b21  sub rsp, 0x08
00007cbcc2dd5b25  push rax
00007cbcc2dd5b26  push rcx
00007cbcc2dd5b27  push rdx
00007cbcc2dd5b28  push rdi
00007cbcc2dd5b29  push rsi
00007cbcc2dd5b2a  push r8
00007cbcc2dd5b2c  push r9
00007cbcc2dd5b2e  push r10
00007cbcc2dd5b30  push r11
00007cbcc2dd5b32  sub rsp, 0xF0
00007cbcc2dd5b39  vmovaps [rsp], xmm0
00007cbcc2dd5b3e  vmovaps [rsp+0x10], xmm1
00007cbcc2dd5b44  vmovaps [rsp+0x20], xmm2
00007cbcc2dd5b4a  vmovaps [rsp+0x30], xmm3
00007cbcc2dd5b50  vmovaps [rsp+0x40], xmm4
00007cbcc2dd5b56  vmovaps [rsp+0x50], xmm5
00007cbcc2dd5b5c  vmovaps [rsp+0x60], xmm6
00007cbcc2dd5b62  vmovaps [rsp+0x70], xmm7
00007cbcc2dd5b68  vmovaps [rsp+0x80], xmm8
00007cbcc2dd5b71  vmovaps [rsp+0x90], xmm9
00007cbcc2dd5b7a  vmovaps [rsp+0xA0], xmm11
00007cbcc2dd5b83  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd5b8c  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd5b95  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd5b9e  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd5ba7  sub rsp, 0x40
00007cbcc2dd5bab  lea rdi, [rsp]
00007cbcc2dd5baf  lea rsi, [rsp+0x10]
00007cbcc2dd5bb4  lea rdx, [rsp+0x20]
00007cbcc2dd5bb9  lea rcx, [rsp+0x30]
00007cbcc2dd5bbe  mov r8d, 0x00
00007cbcc2dd5bc4  lea r9, [r15+0x3A8]
00007cbcc2dd5bcb  movaps [rdi], xmm10
00007cbcc2dd5bcf  movaps [rsi], xmm6
00007cbcc2dd5bd2  movaps [rdx], xmm15
00007cbcc2dd5bd6  movaps [rcx], xmm1
00007cbcc2dd5bd9  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd5be3  call rax
00007cbcc2dd5be5  movaps xmm10, [rsp]
00007cbcc2dd5bea  add rsp, 0x40
00007cbcc2dd5bee  vmovaps xmm0, [rsp]
00007cbcc2dd5bf3  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd5bf9  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd5bff  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd5c05  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd5c0b  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd5c11  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd5c17  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd5c1d  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd5c26  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd5c2f  vmovaps xmm11, [rsp+0xA0]
00007cbcc2dd5c38  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd5c41  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd5c4a  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd5c53  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd5c5c  add rsp, 0xF0
00007cbcc2dd5c63  pop r11
00007cbcc2dd5c65  pop r10
00007cbcc2dd5c67  pop r9
00007cbcc2dd5c69  pop r8
00007cbcc2dd5c6b  pop rsi
00007cbcc2dd5c6c  pop rdi
00007cbcc2dd5c6d  pop rdx
00007cbcc2dd5c6e  pop rcx
00007cbcc2dd5c6f  pop rax
00007cbcc2dd5c70  add rsp, 0x08
00007cbcc2dd5c74  jmp 0x00007CBCC2DD3956
00007cbcc2dd5c79  call 0x00007CBCC2CD64F0
00007cbcc2dd5c7e  jmp 0x00007CBCC2DD3960
00007cbcc2dd5c83  call 0x00007CBCC2CE5820
00007cbcc2dd5c88  jmp 0x00007CBCC2DD396A
00007cbcc2dd5c8d  sub rsp, 0x08
00007cbcc2dd5c91  push rax
00007cbcc2dd5c92  push rcx
00007cbcc2dd5c93  push rdx
00007cbcc2dd5c94  push rdi
00007cbcc2dd5c95  push rsi
00007cbcc2dd5c96  push r8
00007cbcc2dd5c98  push r9
00007cbcc2dd5c9a  push r10
00007cbcc2dd5c9c  push r11
00007cbcc2dd5c9e  sub rsp, 0xF0
00007cbcc2dd5ca5  vmovaps [rsp], xmm0
00007cbcc2dd5caa  vmovaps [rsp+0x10], xmm1
00007cbcc2dd5cb0  vmovaps [rsp+0x20], xmm2
00007cbcc2dd5cb6  vmovaps [rsp+0x30], xmm3
00007cbcc2dd5cbc  vmovaps [rsp+0x40], xmm4
00007cbcc2dd5cc2  vmovaps [rsp+0x50], xmm5
00007cbcc2dd5cc8  vmovaps [rsp+0x60], xmm6
00007cbcc2dd5cce  vmovaps [rsp+0x70], xmm8
00007cbcc2dd5cd4  vmovaps [rsp+0x80], xmm9
00007cbcc2dd5cdd  vmovaps [rsp+0x90], xmm10
00007cbcc2dd5ce6  vmovaps [rsp+0xA0], xmm11
00007cbcc2dd5cef  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd5cf8  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd5d01  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd5d0a  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd5d13  sub rsp, 0x40
00007cbcc2dd5d17  lea rdi, [rsp]
00007cbcc2dd5d1b  lea rsi, [rsp+0x10]
00007cbcc2dd5d20  lea rdx, [rsp+0x20]
00007cbcc2dd5d25  lea rcx, [rsp+0x30]
00007cbcc2dd5d2a  mov r8d, 0x00
00007cbcc2dd5d30  lea r9, [r15+0x3A8]
00007cbcc2dd5d37  movaps [rdi], xmm7
00007cbcc2dd5d3a  movaps [rsi], xmm8
00007cbcc2dd5d3e  movaps [rdx], xmm3
00007cbcc2dd5d41  movaps [rcx], xmm9
00007cbcc2dd5d45  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd5d4f  call rax
00007cbcc2dd5d51  movaps xmm7, [rsp]
00007cbcc2dd5d55  add rsp, 0x40
00007cbcc2dd5d59  vmovaps xmm0, [rsp]
00007cbcc2dd5d5e  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd5d64  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd5d6a  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd5d70  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd5d76  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd5d7c  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd5d82  vmovaps xmm8, [rsp+0x70]
00007cbcc2dd5d88  vmovaps xmm9, [rsp+0x80]
00007cbcc2dd5d91  vmovaps xmm10, [rsp+0x90]
00007cbcc2dd5d9a  vmovaps xmm11, [rsp+0xA0]
00007cbcc2dd5da3  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd5dac  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd5db5  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd5dbe  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd5dc7  add rsp, 0xF0
00007cbcc2dd5dce  pop r11
00007cbcc2dd5dd0  pop r10
00007cbcc2dd5dd2  pop r9
00007cbcc2dd5dd4  pop r8
00007cbcc2dd5dd6  pop rsi
00007cbcc2dd5dd7  pop rdi
00007cbcc2dd5dd8  pop rdx
00007cbcc2dd5dd9  pop rcx
00007cbcc2dd5dda  pop rax
00007cbcc2dd5ddb  add rsp, 0x08
00007cbcc2dd5ddf  jmp 0x00007CBCC2DD3992
00007cbcc2dd5de4  sub rsp, 0x08
00007cbcc2dd5de8  push rax
00007cbcc2dd5de9  push rcx
00007cbcc2dd5dea  push rdx
00007cbcc2dd5deb  push rdi
00007cbcc2dd5dec  push rsi
00007cbcc2dd5ded  push r8
00007cbcc2dd5def  push r9
00007cbcc2dd5df1  push r10
00007cbcc2dd5df3  push r11
00007cbcc2dd5df5  sub rsp, 0xF0
00007cbcc2dd5dfc  vmovaps [rsp], xmm0
00007cbcc2dd5e01  vmovaps [rsp+0x10], xmm1
00007cbcc2dd5e07  vmovaps [rsp+0x20], xmm2
00007cbcc2dd5e0d  vmovaps [rsp+0x30], xmm3
00007cbcc2dd5e13  vmovaps [rsp+0x40], xmm4
00007cbcc2dd5e19  vmovaps [rsp+0x50], xmm5
00007cbcc2dd5e1f  vmovaps [rsp+0x60], xmm6
00007cbcc2dd5e25  vmovaps [rsp+0x70], xmm7
00007cbcc2dd5e2b  vmovaps [rsp+0x80], xmm9
00007cbcc2dd5e34  vmovaps [rsp+0x90], xmm10
00007cbcc2dd5e3d  vmovaps [rsp+0xA0], xmm11
00007cbcc2dd5e46  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd5e4f  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd5e58  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd5e61  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd5e6a  sub rsp, 0x40
00007cbcc2dd5e6e  lea rdi, [rsp]
00007cbcc2dd5e72  lea rsi, [rsp+0x10]
00007cbcc2dd5e77  lea rdx, [rsp+0x20]
00007cbcc2dd5e7c  lea rcx, [rsp+0x30]
00007cbcc2dd5e81  mov r8d, 0x00
00007cbcc2dd5e87  lea r9, [r15+0x3A8]
00007cbcc2dd5e8e  movaps [rdi], xmm8
00007cbcc2dd5e92  movaps [rsi], xmm11
00007cbcc2dd5e96  movaps [rdx], xmm14
00007cbcc2dd5e9a  movaps [rcx], xmm9
00007cbcc2dd5e9e  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd5ea8  call rax
00007cbcc2dd5eaa  movaps xmm8, [rsp]
00007cbcc2dd5eaf  add rsp, 0x40
00007cbcc2dd5eb3  vmovaps xmm0, [rsp]
00007cbcc2dd5eb8  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd5ebe  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd5ec4  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd5eca  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd5ed0  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd5ed6  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd5edc  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd5ee2  vmovaps xmm9, [rsp+0x80]
00007cbcc2dd5eeb  vmovaps xmm10, [rsp+0x90]
00007cbcc2dd5ef4  vmovaps xmm11, [rsp+0xA0]
00007cbcc2dd5efd  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd5f06  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd5f0f  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd5f18  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd5f21  add rsp, 0xF0
00007cbcc2dd5f28  pop r11
00007cbcc2dd5f2a  pop r10
00007cbcc2dd5f2c  pop r9
00007cbcc2dd5f2e  pop r8
00007cbcc2dd5f30  pop rsi
00007cbcc2dd5f31  pop rdi
00007cbcc2dd5f32  pop rdx
00007cbcc2dd5f33  pop rcx
00007cbcc2dd5f34  pop rax
00007cbcc2dd5f35  add rsp, 0x08
00007cbcc2dd5f39  jmp 0x00007CBCC2DD39BB
00007cbcc2dd5f3e  sub rsp, 0x08
00007cbcc2dd5f42  push rax
00007cbcc2dd5f43  push rcx
00007cbcc2dd5f44  push rdx
00007cbcc2dd5f45  push rdi
00007cbcc2dd5f46  push rsi
00007cbcc2dd5f47  push r8
00007cbcc2dd5f49  push r9
00007cbcc2dd5f4b  push r10
00007cbcc2dd5f4d  push r11
00007cbcc2dd5f4f  sub rsp, 0xF0
00007cbcc2dd5f56  vmovaps [rsp], xmm0
00007cbcc2dd5f5b  vmovaps [rsp+0x10], xmm1
00007cbcc2dd5f61  vmovaps [rsp+0x20], xmm2
00007cbcc2dd5f67  vmovaps [rsp+0x30], xmm3
00007cbcc2dd5f6d  vmovaps [rsp+0x40], xmm4
00007cbcc2dd5f73  vmovaps [rsp+0x50], xmm5
00007cbcc2dd5f79  vmovaps [rsp+0x60], xmm6
00007cbcc2dd5f7f  vmovaps [rsp+0x70], xmm7
00007cbcc2dd5f85  vmovaps [rsp+0x80], xmm8
00007cbcc2dd5f8e  vmovaps [rsp+0x90], xmm9
00007cbcc2dd5f97  vmovaps [rsp+0xA0], xmm10
00007cbcc2dd5fa0  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd5fa9  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd5fb2  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd5fbb  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd5fc4  sub rsp, 0x40
00007cbcc2dd5fc8  lea rdi, [rsp]
00007cbcc2dd5fcc  lea rsi, [rsp+0x10]
00007cbcc2dd5fd1  lea rdx, [rsp+0x20]
00007cbcc2dd5fd6  lea rcx, [rsp+0x30]
00007cbcc2dd5fdb  mov r8d, 0x00
00007cbcc2dd5fe1  lea r9, [r15+0x3A8]
00007cbcc2dd5fe8  movaps [rdi], xmm11
00007cbcc2dd5fec  movaps [rsi], xmm13
00007cbcc2dd5ff0  movaps [rdx], xmm12
00007cbcc2dd5ff4  movaps [rcx], xmm14
00007cbcc2dd5ff8  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd6002  call rax
00007cbcc2dd6004  movaps xmm11, [rsp]
00007cbcc2dd6009  add rsp, 0x40
00007cbcc2dd600d  vmovaps xmm0, [rsp]
00007cbcc2dd6012  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd6018  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd601e  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd6024  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd602a  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd6030  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd6036  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd603c  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd6045  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd604e  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dd6057  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd6060  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd6069  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd6072  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd607b  add rsp, 0xF0
00007cbcc2dd6082  pop r11
00007cbcc2dd6084  pop r10
00007cbcc2dd6086  pop r9
00007cbcc2dd6088  pop r8
00007cbcc2dd608a  pop rsi
00007cbcc2dd608b  pop rdi
00007cbcc2dd608c  pop rdx
00007cbcc2dd608d  pop rcx
00007cbcc2dd608e  pop rax
00007cbcc2dd608f  add rsp, 0x08
00007cbcc2dd6093  jmp 0x00007CBCC2DD39E4
00007cbcc2dd6098  sub rsp, 0x08
00007cbcc2dd609c  push rax
00007cbcc2dd609d  push rcx
00007cbcc2dd609e  push rdx
00007cbcc2dd609f  push rdi
00007cbcc2dd60a0  push rsi
00007cbcc2dd60a1  push r8
00007cbcc2dd60a3  push r9
00007cbcc2dd60a5  push r10
00007cbcc2dd60a7  push r11
00007cbcc2dd60a9  sub rsp, 0xF0
00007cbcc2dd60b0  vmovaps [rsp], xmm0
00007cbcc2dd60b5  vmovaps [rsp+0x10], xmm1
00007cbcc2dd60bb  vmovaps [rsp+0x20], xmm2
00007cbcc2dd60c1  vmovaps [rsp+0x30], xmm3
00007cbcc2dd60c7  vmovaps [rsp+0x40], xmm4
00007cbcc2dd60cd  vmovaps [rsp+0x50], xmm5
00007cbcc2dd60d3  vmovaps [rsp+0x60], xmm6
00007cbcc2dd60d9  vmovaps [rsp+0x70], xmm7
00007cbcc2dd60df  vmovaps [rsp+0x80], xmm8
00007cbcc2dd60e8  vmovaps [rsp+0x90], xmm9
00007cbcc2dd60f1  vmovaps [rsp+0xA0], xmm10
00007cbcc2dd60fa  vmovaps [rsp+0xB0], xmm11
00007cbcc2dd6103  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd610c  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd6115  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd611e  sub rsp, 0x40
00007cbcc2dd6122  lea rdi, [rsp]
00007cbcc2dd6126  lea rsi, [rsp+0x10]
00007cbcc2dd612b  lea rdx, [rsp+0x20]
00007cbcc2dd6130  lea rcx, [rsp+0x30]
00007cbcc2dd6135  mov r8d, 0x00
00007cbcc2dd613b  lea r9, [r15+0x3A8]
00007cbcc2dd6142  movaps [rdi], xmm12
00007cbcc2dd6146  movaps [rsi], xmm10
00007cbcc2dd614a  movaps [rdx], xmm15
00007cbcc2dd614e  movaps [rcx], xmm14
00007cbcc2dd6152  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd615c  call rax
00007cbcc2dd615e  movaps xmm12, [rsp]
00007cbcc2dd6163  add rsp, 0x40
00007cbcc2dd6167  vmovaps xmm0, [rsp]
00007cbcc2dd616c  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd6172  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd6178  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd617e  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd6184  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd618a  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd6190  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd6196  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd619f  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd61a8  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dd61b1  vmovaps xmm11, [rsp+0xB0]
00007cbcc2dd61ba  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd61c3  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd61cc  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd61d5  add rsp, 0xF0
00007cbcc2dd61dc  pop r11
00007cbcc2dd61de  pop r10
00007cbcc2dd61e0  pop r9
00007cbcc2dd61e2  pop r8
00007cbcc2dd61e4  pop rsi
00007cbcc2dd61e5  pop rdi
00007cbcc2dd61e6  pop rdx
00007cbcc2dd61e7  pop rcx
00007cbcc2dd61e8  pop rax
00007cbcc2dd61e9  add rsp, 0x08
00007cbcc2dd61ed  jmp 0x00007CBCC2DD3A0D
00007cbcc2dd61f2  call 0x00007CBCC2CE5820
00007cbcc2dd61f7  jmp 0x00007CBCC2DD3A1A
00007cbcc2dd61fc  call 0x00007CBCC2CE45A0
00007cbcc2dd6201  jmp 0x00007CBCC2DD3A27
00007cbcc2dd6206  sub rsp, 0x08
00007cbcc2dd620a  push rax
00007cbcc2dd620b  push rcx
00007cbcc2dd620c  push rdx
00007cbcc2dd620d  push rdi
00007cbcc2dd620e  push rsi
00007cbcc2dd620f  push r8
00007cbcc2dd6211  push r9
00007cbcc2dd6213  push r10
00007cbcc2dd6215  push r11
00007cbcc2dd6217  sub rsp, 0xF0
00007cbcc2dd621e  vmovaps [rsp], xmm0
00007cbcc2dd6223  vmovaps [rsp+0x10], xmm1
00007cbcc2dd6229  vmovaps [rsp+0x20], xmm2
00007cbcc2dd622f  vmovaps [rsp+0x30], xmm3
00007cbcc2dd6235  vmovaps [rsp+0x40], xmm4
00007cbcc2dd623b  vmovaps [rsp+0x50], xmm5
00007cbcc2dd6241  vmovaps [rsp+0x60], xmm6
00007cbcc2dd6247  vmovaps [rsp+0x70], xmm7
00007cbcc2dd624d  vmovaps [rsp+0x80], xmm8
00007cbcc2dd6256  vmovaps [rsp+0x90], xmm9
00007cbcc2dd625f  vmovaps [rsp+0xA0], xmm11
00007cbcc2dd6268  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd6271  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd627a  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd6283  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd628c  sub rsp, 0x40
00007cbcc2dd6290  lea rdi, [rsp]
00007cbcc2dd6294  lea rsi, [rsp+0x10]
00007cbcc2dd6299  lea rdx, [rsp+0x20]
00007cbcc2dd629e  lea rcx, [rsp+0x30]
00007cbcc2dd62a3  mov r8d, 0x00
00007cbcc2dd62a9  lea r9, [r15+0x3A8]
00007cbcc2dd62b0  movaps [rdi], xmm10
00007cbcc2dd62b4  movaps [rsi], xmm7
00007cbcc2dd62b7  movaps [rdx], xmm1
00007cbcc2dd62ba  movaps [rcx], xmm13
00007cbcc2dd62be  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd62c8  call rax
00007cbcc2dd62ca  movaps xmm10, [rsp]
00007cbcc2dd62cf  add rsp, 0x40
00007cbcc2dd62d3  vmovaps xmm0, [rsp]
00007cbcc2dd62d8  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd62de  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd62e4  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd62ea  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd62f0  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd62f6  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd62fc  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd6302  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd630b  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd6314  vmovaps xmm11, [rsp+0xA0]
00007cbcc2dd631d  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd6326  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd632f  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd6338  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd6341  add rsp, 0xF0
00007cbcc2dd6348  pop r11
00007cbcc2dd634a  pop r10
00007cbcc2dd634c  pop r9
00007cbcc2dd634e  pop r8
00007cbcc2dd6350  pop rsi
00007cbcc2dd6351  pop rdi
00007cbcc2dd6352  pop rdx
00007cbcc2dd6353  pop rcx
00007cbcc2dd6354  pop rax
00007cbcc2dd6355  add rsp, 0x08
00007cbcc2dd6359  jmp 0x00007CBCC2DD3A5D
00007cbcc2dd635e  call 0x00007CBCC2CD64F0
00007cbcc2dd6363  jmp 0x00007CBCC2DD3A6F
00007cbcc2dd6368  sub rsp, 0x08
00007cbcc2dd636c  push rax
00007cbcc2dd636d  push rcx
00007cbcc2dd636e  push rdx
00007cbcc2dd636f  push rdi
00007cbcc2dd6370  push rsi
00007cbcc2dd6371  push r8
00007cbcc2dd6373  push r9
00007cbcc2dd6375  push r10
00007cbcc2dd6377  push r11
00007cbcc2dd6379  sub rsp, 0xF0
00007cbcc2dd6380  vmovaps [rsp], xmm0
00007cbcc2dd6385  vmovaps [rsp+0x10], xmm1
00007cbcc2dd638b  vmovaps [rsp+0x20], xmm2
00007cbcc2dd6391  vmovaps [rsp+0x30], xmm3
00007cbcc2dd6397  vmovaps [rsp+0x40], xmm4
00007cbcc2dd639d  vmovaps [rsp+0x50], xmm5
00007cbcc2dd63a3  vmovaps [rsp+0x60], xmm6
00007cbcc2dd63a9  vmovaps [rsp+0x70], xmm7
00007cbcc2dd63af  vmovaps [rsp+0x80], xmm8
00007cbcc2dd63b8  vmovaps [rsp+0x90], xmm10
00007cbcc2dd63c1  vmovaps [rsp+0xA0], xmm11
00007cbcc2dd63ca  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd63d3  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd63dc  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd63e5  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd63ee  sub rsp, 0x40
00007cbcc2dd63f2  lea rdi, [rsp]
00007cbcc2dd63f6  lea rsi, [rsp+0x10]
00007cbcc2dd63fb  lea rdx, [rsp+0x20]
00007cbcc2dd6400  lea rcx, [rsp+0x30]
00007cbcc2dd6405  mov r8d, 0x00
00007cbcc2dd640b  lea r9, [r15+0x3A8]
00007cbcc2dd6412  movaps [rdi], xmm9
00007cbcc2dd6416  movaps [rsi], xmm8
00007cbcc2dd641a  movaps [rdx], xmm14
00007cbcc2dd641e  movaps [rcx], xmm13
00007cbcc2dd6422  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd642c  call rax
00007cbcc2dd642e  movaps xmm9, [rsp]
00007cbcc2dd6433  add rsp, 0x40
00007cbcc2dd6437  vmovaps xmm0, [rsp]
00007cbcc2dd643c  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd6442  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd6448  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd644e  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd6454  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd645a  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd6460  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd6466  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd646f  vmovaps xmm10, [rsp+0x90]
00007cbcc2dd6478  vmovaps xmm11, [rsp+0xA0]
00007cbcc2dd6481  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd648a  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd6493  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd649c  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd64a5  add rsp, 0xF0
00007cbcc2dd64ac  pop r11
00007cbcc2dd64ae  pop r10
00007cbcc2dd64b0  pop r9
00007cbcc2dd64b2  pop r8
00007cbcc2dd64b4  pop rsi
00007cbcc2dd64b5  pop rdi
00007cbcc2dd64b6  pop rdx
00007cbcc2dd64b7  pop rcx
00007cbcc2dd64b8  pop rax
00007cbcc2dd64b9  add rsp, 0x08
00007cbcc2dd64bd  jmp 0x00007CBCC2DD3A9D
00007cbcc2dd64c2  sub rsp, 0x08
00007cbcc2dd64c6  push rax
00007cbcc2dd64c7  push rcx
00007cbcc2dd64c8  push rdx
00007cbcc2dd64c9  push rdi
00007cbcc2dd64ca  push rsi
00007cbcc2dd64cb  push r8
00007cbcc2dd64cd  push r9
00007cbcc2dd64cf  push r10
00007cbcc2dd64d1  push r11
00007cbcc2dd64d3  sub rsp, 0xF0
00007cbcc2dd64da  vmovaps [rsp], xmm0
00007cbcc2dd64df  vmovaps [rsp+0x10], xmm1
00007cbcc2dd64e5  vmovaps [rsp+0x20], xmm2
00007cbcc2dd64eb  vmovaps [rsp+0x30], xmm3
00007cbcc2dd64f1  vmovaps [rsp+0x40], xmm4
00007cbcc2dd64f7  vmovaps [rsp+0x50], xmm5
00007cbcc2dd64fd  vmovaps [rsp+0x60], xmm6
00007cbcc2dd6503  vmovaps [rsp+0x70], xmm7
00007cbcc2dd6509  vmovaps [rsp+0x80], xmm8
00007cbcc2dd6512  vmovaps [rsp+0x90], xmm9
00007cbcc2dd651b  vmovaps [rsp+0xA0], xmm10
00007cbcc2dd6524  vmovaps [rsp+0xB0], xmm11
00007cbcc2dd652d  vmovaps [rsp+0xC0], xmm12
00007cbcc2dd6536  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd653f  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd6548  sub rsp, 0x40
00007cbcc2dd654c  lea rdi, [rsp]
00007cbcc2dd6550  lea rsi, [rsp+0x10]
00007cbcc2dd6555  lea rdx, [rsp+0x20]
00007cbcc2dd655a  lea rcx, [rsp+0x30]
00007cbcc2dd655f  mov r8d, 0x00
00007cbcc2dd6565  lea r9, [r15+0x3A8]
00007cbcc2dd656c  movaps [rdi], xmm13
00007cbcc2dd6570  movaps [rsi], xmm11
00007cbcc2dd6574  movaps [rdx], xmm15
00007cbcc2dd6578  movaps [rcx], xmm14
00007cbcc2dd657c  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd6586  call rax
00007cbcc2dd6588  movaps xmm13, [rsp]
00007cbcc2dd658d  add rsp, 0x40
00007cbcc2dd6591  vmovaps xmm0, [rsp]
00007cbcc2dd6596  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd659c  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd65a2  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd65a8  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd65ae  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd65b4  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd65ba  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd65c0  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd65c9  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd65d2  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dd65db  vmovaps xmm11, [rsp+0xB0]
00007cbcc2dd65e4  vmovaps xmm12, [rsp+0xC0]
00007cbcc2dd65ed  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd65f6  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd65ff  add rsp, 0xF0
00007cbcc2dd6606  pop r11
00007cbcc2dd6608  pop r10
00007cbcc2dd660a  pop r9
00007cbcc2dd660c  pop r8
00007cbcc2dd660e  pop rsi
00007cbcc2dd660f  pop rdi
00007cbcc2dd6610  pop rdx
00007cbcc2dd6611  pop rcx
00007cbcc2dd6612  pop rax
00007cbcc2dd6613  add rsp, 0x08
00007cbcc2dd6617  jmp 0x00007CBCC2DD3ACB
00007cbcc2dd661c  sub rsp, 0x08
00007cbcc2dd6620  push rax
00007cbcc2dd6621  push rcx
00007cbcc2dd6622  push rdx
00007cbcc2dd6623  push rdi
00007cbcc2dd6624  push rsi
00007cbcc2dd6625  push r8
00007cbcc2dd6627  push r9
00007cbcc2dd6629  push r10
00007cbcc2dd662b  push r11
00007cbcc2dd662d  sub rsp, 0xF0
00007cbcc2dd6634  vmovaps [rsp], xmm0
00007cbcc2dd6639  vmovaps [rsp+0x10], xmm1
00007cbcc2dd663f  vmovaps [rsp+0x20], xmm2
00007cbcc2dd6645  vmovaps [rsp+0x30], xmm3
00007cbcc2dd664b  vmovaps [rsp+0x40], xmm4
00007cbcc2dd6651  vmovaps [rsp+0x50], xmm5
00007cbcc2dd6657  vmovaps [rsp+0x60], xmm6
00007cbcc2dd665d  vmovaps [rsp+0x70], xmm7
00007cbcc2dd6663  vmovaps [rsp+0x80], xmm8
00007cbcc2dd666c  vmovaps [rsp+0x90], xmm9
00007cbcc2dd6675  vmovaps [rsp+0xA0], xmm10
00007cbcc2dd667e  vmovaps [rsp+0xB0], xmm11
00007cbcc2dd6687  vmovaps [rsp+0xC0], xmm12
00007cbcc2dd6690  vmovaps [rsp+0xD0], xmm13
00007cbcc2dd6699  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd66a2  sub rsp, 0x40
00007cbcc2dd66a6  lea rdi, [rsp]
00007cbcc2dd66aa  lea rsi, [rsp+0x10]
00007cbcc2dd66af  lea rdx, [rsp+0x20]
00007cbcc2dd66b4  lea rcx, [rsp+0x30]
00007cbcc2dd66b9  mov r8d, 0x00
00007cbcc2dd66bf  lea r9, [r15+0x3A8]
00007cbcc2dd66c6  movaps [rdi], xmm14
00007cbcc2dd66ca  movaps [rsi], xmm12
00007cbcc2dd66ce  movaps [rdx], xmm1
00007cbcc2dd66d1  movaps [rcx], xmm15
00007cbcc2dd66d5  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd66df  call rax
00007cbcc2dd66e1  movaps xmm14, [rsp]
00007cbcc2dd66e6  add rsp, 0x40
00007cbcc2dd66ea  vmovaps xmm0, [rsp]
00007cbcc2dd66ef  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd66f5  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd66fb  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd6701  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd6707  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd670d  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd6713  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd6719  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd6722  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd672b  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dd6734  vmovaps xmm11, [rsp+0xB0]
00007cbcc2dd673d  vmovaps xmm12, [rsp+0xC0]
00007cbcc2dd6746  vmovaps xmm13, [rsp+0xD0]
00007cbcc2dd674f  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd6758  add rsp, 0xF0
00007cbcc2dd675f  pop r11
00007cbcc2dd6761  pop r10
00007cbcc2dd6763  pop r9
00007cbcc2dd6765  pop r8
00007cbcc2dd6767  pop rsi
00007cbcc2dd6768  pop rdi
00007cbcc2dd6769  pop rdx
00007cbcc2dd676a  pop rcx
00007cbcc2dd676b  pop rax
00007cbcc2dd676c  add rsp, 0x08
00007cbcc2dd6770  jmp 0x00007CBCC2DD3AF9
00007cbcc2dd6775  call 0x00007CBCC2CACF70
00007cbcc2dd677a  jmp 0x00007CBCC2DD3B07
00007cbcc2dd677f  call 0x00007CBCC2C0C380
00007cbcc2dd6784  jmp 0x00007CBCC2DD3B11
00007cbcc2dd6789  call 0x00007CBCC2C08C20
00007cbcc2dd678e  jmp 0x00007CBCC2DD3B1B
00007cbcc2dd6793  call 0x00007CBCC2C0D600
00007cbcc2dd6798  jmp 0x00007CBCC2DD3B25
00007cbcc2dd679d  int3
00007cbcc2dd679e  nop
00007cbcc2dd67a0  mov eax, [r15+0x48]
00007cbcc2dd67a4  lea r14d, [eax+0x01]
00007cbcc2dd67a9  mov [rsp+0x10], r14d
00007cbcc2dd67ae  mov r14d, r14d
00007cbcc2dd67b1  mov [r15+0x48], r14
00007cbcc2dd67b5  xor eax, eax
00007cbcc2dd67b7  mov r14d, [rsp+0x10]
00007cbcc2dd67bc  cmp r14d, 0x1F4
00007cbcc2dd67c3  cmc
00007cbcc2dd67c4  lahf
00007cbcc2dd67c5  seto al
00007cbcc2dd67c8  mov [r15+0x108], eax
00007cbcc2dd67cf  mov eax, [r15+0x108]
00007cbcc2dd67d6  sahf
00007cbcc2dd67d7  jnz 0x00007CBCC2DD6809
00007cbcc2dd67d9  cmp dword ptr [r15+0x318], 0x00
00007cbcc2dd67e1  jz 0x00007CBCC2DDA1A0
00007cbcc2dd67e7  nop [rax+rax*1], ax
00007cbcc2dd67f0  nop [rax+rax*1], eax
00007cbcc2dd67f8  mov eax, 0x4103FC
00007cbcc2dd67fd  mov [r15+0x100], rax
00007cbcc2dd6804  jmp 0x00007CBCC2BFE110
00007cbcc2dd6809  cmp dword ptr [r15+0x318], 0x00
00007cbcc2dd6811  jz 0x00007CBCC2DD6840
00007cbcc2dd6817  nop [rax+rax*1], ax
00007cbcc2dd6820  nop [rax+rax*1], eax
00007cbcc2dd6828  mov eax, 0x410270
00007cbcc2dd682d  mov [r15+0x100], rax
00007cbcc2dd6834  jmp 0x00007CBCC2BFE110
00007cbcc2dd6839  int3
00007cbcc2dd683a  int3
00007cbcc2dd683b  nop [rax+rax*1], eax
00007cbcc2dd6840  mov rax, [r15+0x40]
00007cbcc2dd6844  vxorps xmm1, xmm1, xmm1
00007cbcc2dd6848  vpbroadcastq xmm1, xmm1
00007cbcc2dd684d  vxorps xmm15, xmm15, xmm15
00007cbcc2dd6852  vpbroadcastq xmm15, xmm15
00007cbcc2dd6857  lea r14, [rax+0x30]
00007cbcc2dd685b  mov r12, [r13+r14*1]
00007cbcc2dd6860  lea r14, [rax+0x38]
00007cbcc2dd6864  mov r11, [r13+r14*1]
00007cbcc2dd6869  movq xmm14, r12
00007cbcc2dd686e  movq xmm13, r11
00007cbcc2dd6873  movq xmm14, xmm14
00007cbcc2dd6878  movq xmm13, xmm13
00007cbcc2dd687d  vmovaps [rsp+0x10], xmm13
00007cbcc2dd6883  movq xmm13, xmm13
00007cbcc2dd6888  movaps [r15+0x270], xmm13
00007cbcc2dd6890  movaps xmm13, [r15+0x160]
00007cbcc2dd6898  vmovaps [rsp+0x20], xmm13
00007cbcc2dd689e  vmovaps xmm12, [rsp+0x20]
00007cbcc2dd68a4  por xmm13, xmm12
00007cbcc2dd68a9  lea r14, [rax+0x20]
00007cbcc2dd68ad  mov r12, [r13+r14*1]
00007cbcc2dd68b2  lea r14, [rax+0x28]
00007cbcc2dd68b6  mov r11, [r13+r14*1]
00007cbcc2dd68bb  movq xmm12, r12
00007cbcc2dd68c0  movq xmm11, r11
00007cbcc2dd68c5  movq xmm12, xmm12
00007cbcc2dd68ca  movq xmm11, xmm11
00007cbcc2dd68cf  movaps xmm10, [r15+0x2F0]
00007cbcc2dd68d7  vmovaps [rsp+0x20], xmm10
00007cbcc2dd68dd  vmovaps xmm9, [rsp+0x20]
00007cbcc2dd68e3  por xmm10, xmm9
00007cbcc2dd68e8  movaps xmm9, [r15+0x2D0]
00007cbcc2dd68f0  vmovaps [rsp+0x20], xmm9
00007cbcc2dd68f6  vmovaps xmm8, [rsp+0x20]
00007cbcc2dd68fc  por xmm9, xmm8
00007cbcc2dd6901  movaps xmm8, [r15+0x300]
00007cbcc2dd6909  vmovaps [rsp+0x20], xmm8
00007cbcc2dd690f  vmovaps xmm7, [rsp+0x20]
00007cbcc2dd6915  por xmm8, xmm7
00007cbcc2dd691a  movaps xmm7, [r15+0x2B0]
00007cbcc2dd6922  vmovaps [rsp+0x20], xmm7
00007cbcc2dd6928  vmovaps xmm6, [rsp+0x20]
00007cbcc2dd692e  por xmm7, xmm6
00007cbcc2dd6932  movaps xmm6, [r15+0x180]
00007cbcc2dd693a  vmovaps [rsp+0x20], xmm6
00007cbcc2dd6940  vmovaps xmm5, [rsp+0x20]
00007cbcc2dd6946  por xmm6, xmm5
00007cbcc2dd694a  lea r14, [rax+0x10]
00007cbcc2dd694e  mov r12, [r13+r14*1]
00007cbcc2dd6953  lea r14, [rax+0x18]
00007cbcc2dd6957  mov r11, [r13+r14*1]
00007cbcc2dd695c  movq xmm5, r12
00007cbcc2dd6961  movq xmm4, r11
00007cbcc2dd6966  movq xmm5, xmm5
00007cbcc2dd696a  movq xmm4, xmm4
00007cbcc2dd696e  movaps xmm3, [r15+0x200]
00007cbcc2dd6976  vmovaps [rsp+0x20], xmm3
00007cbcc2dd697c  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd6982  por xmm3, xmm2
00007cbcc2dd6986  movaps xmm2, [r15+0x1F0]
00007cbcc2dd698e  vmovaps [rsp+0x20], xmm2
00007cbcc2dd6994  vmovaps [rsp+0x30], xmm1
00007cbcc2dd699a  vmovaps xmm1, [rsp+0x20]
00007cbcc2dd69a0  por xmm2, xmm1
00007cbcc2dd69a4  movaps xmm1, [r15+0x2E0]
00007cbcc2dd69ac  vmovaps [rsp+0x20], xmm1
00007cbcc2dd69b2  vmovaps [rsp+0x40], xmm15
00007cbcc2dd69b8  vmovaps xmm15, [rsp+0x20]
00007cbcc2dd69be  por xmm1, xmm15
00007cbcc2dd69c3  movaps xmm15, [r15+0x2A0]
00007cbcc2dd69cb  vmovaps [rsp+0x20], xmm15
00007cbcc2dd69d1  vmovaps [rsp+0x50], xmm1
00007cbcc2dd69d7  vmovaps xmm1, [rsp+0x20]
00007cbcc2dd69dd  por xmm15, xmm1
00007cbcc2dd69e2  movaps xmm1, [r15+0x280]
00007cbcc2dd69ea  vmovaps [rsp+0x20], xmm1
00007cbcc2dd69f0  vmovaps [rsp+0x60], xmm15
00007cbcc2dd69f6  vmovaps xmm15, [rsp+0x20]
00007cbcc2dd69fc  por xmm1, xmm15
00007cbcc2dd6a01  movaps xmm15, [r15+0x1C0]
00007cbcc2dd6a09  vmovaps [rsp+0x20], xmm15
00007cbcc2dd6a0f  vmovaps [rsp+0x70], xmm1
00007cbcc2dd6a15  vmovaps xmm1, [rsp+0x20]
00007cbcc2dd6a1b  por xmm15, xmm1
00007cbcc2dd6a20  movaps xmm1, [r15+0x210]
00007cbcc2dd6a28  vmovaps [rsp+0x20], xmm1
00007cbcc2dd6a2e  vmovaps [rsp+0x80], xmm15
00007cbcc2dd6a37  vmovaps xmm15, [rsp+0x20]
00007cbcc2dd6a3d  por xmm1, xmm15
00007cbcc2dd6a42  mov r14, [r13+rax*1]
00007cbcc2dd6a47  vmovq xmm15, r14
00007cbcc2dd6a4c  vpbroadcastq xmm15, xmm15
00007cbcc2dd6a51  vmovaps [rsp+0x20], xmm1
00007cbcc2dd6a57  vxorps xmm1, xmm1, xmm1
00007cbcc2dd6a5b  vpbroadcastq xmm1, xmm1
00007cbcc2dd6a60  mov r14, [r15+0xF8]
00007cbcc2dd6a67  vmovaps [rsp+0x90], xmm1
00007cbcc2dd6a70  movups xmm1, [r13+r14*1]
00007cbcc2dd6a76  vmovaps [rsp+0xA0], xmm1
00007cbcc2dd6a7f  vxorps xmm1, xmm1, xmm1
00007cbcc2dd6a83  vpbroadcastq xmm1, xmm1
00007cbcc2dd6a88  lea r12, [rax+0x08]
00007cbcc2dd6a8c  mov rax, [r13+r12*1]
00007cbcc2dd6a91  vmovaps [rsp+0xB0], xmm1
00007cbcc2dd6a9a  movq xmm1, rax
00007cbcc2dd6a9f  movaps [r15+0x240], xmm1
00007cbcc2dd6aa7  mov rax, [r15+0x50]
00007cbcc2dd6aab  mov [r15+0x60], rax
00007cbcc2dd6aaf  mov qword ptr [r15+0x58], 0x40
00007cbcc2dd6ab7  vmovaps xmm1, [rsp+0x30]
00007cbcc2dd6abd  vmovaps [rsp+0x30], xmm15
00007cbcc2dd6ac3  vmovaps xmm15, [rsp+0xA0]
00007cbcc2dd6acc  vmovaps [rsp+0xA0], xmm14
00007cbcc2dd6ad5  vmovaps xmm14, [rsp+0x30]
00007cbcc2dd6adb  vmovaps [rsp+0x30], xmm13
00007cbcc2dd6ae1  vmovaps [rsp+0xC0], xmm12
00007cbcc2dd6aea  movaps xmm13, xmm1
00007cbcc2dd6aee  vfmadd231pd xmm13, xmm15, xmm14
00007cbcc2dd6af3  vcmppd xmm12, xmm13, xmm13, 0x03
00007cbcc2dd6af9  vptest xmm12, xmm12
00007cbcc2dd6afe  jnz 0x00007CBCC2DD75DD
00007cbcc2dd6b04  movaps xmm1, [r15+0x250]
00007cbcc2dd6b0c  vmovaps xmm15, [rsp+0x40]
00007cbcc2dd6b12  vmovaps [rsp+0x40], xmm13
00007cbcc2dd6b18  movaps xmm12, xmm15
00007cbcc2dd6b1c  vfmadd231pd xmm12, xmm1, xmm14
00007cbcc2dd6b21  vcmppd xmm13, xmm12, xmm12, 0x03
00007cbcc2dd6b27  vptest xmm13, xmm13
00007cbcc2dd6b2c  jnz 0x00007CBCC2DD7736
00007cbcc2dd6b32  movaps xmm15, [r15+0x1E0]
00007cbcc2dd6b3a  vmovaps [rsp+0xD0], xmm15
00007cbcc2dd6b43  vmovaps xmm13, [rsp+0xD0]
00007cbcc2dd6b4c  por xmm15, xmm13
00007cbcc2dd6b51  movaps xmm13, [r15+0x1D0]
00007cbcc2dd6b59  vmovaps [rsp+0xD0], xmm13
00007cbcc2dd6b62  vmovaps [rsp+0xE0], xmm1
00007cbcc2dd6b6b  vmovaps xmm1, [rsp+0xD0]
00007cbcc2dd6b74  por xmm13, xmm1
00007cbcc2dd6b79  movaps xmm1, [r15+0x2C0]
00007cbcc2dd6b81  vmovaps [rsp+0xD0], xmm1
00007cbcc2dd6b8a  vmovaps [rsp+0xF0], xmm15
00007cbcc2dd6b93  vmovaps xmm15, [rsp+0xD0]
00007cbcc2dd6b9c  por xmm1, xmm15
00007cbcc2dd6ba1  movaps xmm15, [r15+0x290]
00007cbcc2dd6ba9  vmovaps [rsp+0xD0], xmm15
00007cbcc2dd6bb2  vmovaps [rsp+0x100], xmm1
00007cbcc2dd6bbb  vmovaps xmm1, [rsp+0xD0]
00007cbcc2dd6bc4  por xmm15, xmm1
00007cbcc2dd6bc9  movaps xmm1, [r15+0x260]
00007cbcc2dd6bd1  vmovaps [rsp+0xD0], xmm1
00007cbcc2dd6bda  vmovaps [rsp+0x110], xmm15
00007cbcc2dd6be3  vmovaps xmm15, [rsp+0xD0]
00007cbcc2dd6bec  por xmm1, xmm15
00007cbcc2dd6bf1  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd6bfa  vmovaps [rsp+0xD0], xmm1
00007cbcc2dd6c03  vmovaps xmm1, [rsp+0xE0]
00007cbcc2dd6c0c  por xmm15, xmm1
00007cbcc2dd6c11  lea r12, [r14+0xC0]
00007cbcc2dd6c18  movups xmm1, [r13+r12*1]
00007cbcc2dd6c1e  mov [rsp+0xE0], rax
00007cbcc2dd6c26  xor eax, eax
00007cbcc2dd6c28  mov r12d, 0x40
00007cbcc2dd6c2e  mov r11d, 0x200
00007cbcc2dd6c34  cmp r12, r11
00007cbcc2dd6c37  cmc
00007cbcc2dd6c38  lahf
00007cbcc2dd6c39  seto al
00007cbcc2dd6c3c  mov [r15+0x108], eax
00007cbcc2dd6c43  vmovaps [rsp+0x120], xmm1
00007cbcc2dd6c4c  vmovaps xmm1, [rsp+0x90]
00007cbcc2dd6c55  vmovaps [rsp+0x90], xmm15
00007cbcc2dd6c5e  vmovaps xmm15, [rsp+0x120]
00007cbcc2dd6c67  vmovaps [rsp+0x120], xmm13
00007cbcc2dd6c70  vmovaps [rsp+0x130], xmm12
00007cbcc2dd6c79  movaps xmm13, xmm1
00007cbcc2dd6c7d  vfmadd231pd xmm13, xmm15, xmm14
00007cbcc2dd6c82  vcmppd xmm12, xmm13, xmm13, 0x03
00007cbcc2dd6c88  vptest xmm12, xmm12
00007cbcc2dd6c8d  jnz 0x00007CBCC2DD7899
00007cbcc2dd6c93  lea rax, [r14+0xB0]
00007cbcc2dd6c9a  movups xmm1, [r13+rax*1]
00007cbcc2dd6ca0  vmovaps xmm15, [rsp+0xB0]
00007cbcc2dd6ca9  vmovaps [rsp+0xB0], xmm13
00007cbcc2dd6cb2  movaps xmm12, xmm15
00007cbcc2dd6cb6  vfmadd231pd xmm12, xmm1, xmm14
00007cbcc2dd6cbb  vcmppd xmm13, xmm12, xmm12, 0x03
00007cbcc2dd6cc1  vptest xmm13, xmm13
00007cbcc2dd6cc6  jnz 0x00007CBCC2DD79FC
00007cbcc2dd6ccc  vmovaps xmm1, [rsp+0x20]
00007cbcc2dd6cd2  vmovaps xmm15, [rsp+0x20]
00007cbcc2dd6cd8  por xmm1, xmm15
00007cbcc2dd6cdd  movaps [r15+0x210], xmm1
00007cbcc2dd6ce5  vmovaps xmm15, [rsp+0x80]
00007cbcc2dd6cee  vmovaps xmm14, [rsp+0x80]
00007cbcc2dd6cf7  por xmm15, xmm14
00007cbcc2dd6cfc  movaps [r15+0x1C0], xmm15
00007cbcc2dd6d04  vmovaps xmm14, [rsp+0x70]
00007cbcc2dd6d0a  vmovaps xmm13, [rsp+0x70]
00007cbcc2dd6d10  por xmm14, xmm13
00007cbcc2dd6d15  movaps [r15+0x280], xmm14
00007cbcc2dd6d1d  vmovaps xmm13, [rsp+0x60]
00007cbcc2dd6d23  vmovaps [rsp+0x20], xmm1
00007cbcc2dd6d29  vmovaps xmm1, [rsp+0x60]
00007cbcc2dd6d2f  por xmm13, xmm1
00007cbcc2dd6d34  movaps [r15+0x2A0], xmm13
00007cbcc2dd6d3c  vmovaps xmm1, [rsp+0x50]
00007cbcc2dd6d42  vmovaps [rsp+0x60], xmm15
00007cbcc2dd6d48  vmovaps xmm15, [rsp+0x50]
00007cbcc2dd6d4e  por xmm1, xmm15
00007cbcc2dd6d53  movaps [r15+0x2E0], xmm1
00007cbcc2dd6d5b  vmovaps [rsp+0x50], xmm2
00007cbcc2dd6d61  vmovaps xmm15, [rsp+0x50]
00007cbcc2dd6d67  por xmm2, xmm15
00007cbcc2dd6d6c  movaps [r15+0x1F0], xmm2
00007cbcc2dd6d74  vmovaps xmm15, [rsp+0x90]
00007cbcc2dd6d7d  vmovaps [rsp+0x50], xmm1
00007cbcc2dd6d83  vmovaps xmm1, [rsp+0x90]
00007cbcc2dd6d8c  por xmm15, xmm1
00007cbcc2dd6d91  movaps [r15+0x250], xmm15
00007cbcc2dd6d99  vmovaps xmm1, [rsp+0xD0]
00007cbcc2dd6da2  vmovaps xmm15, [rsp+0xD0]
00007cbcc2dd6dab  por xmm1, xmm15
00007cbcc2dd6db0  movaps [r15+0x260], xmm1
00007cbcc2dd6db8  vmovaps xmm15, [rsp+0x110]
00007cbcc2dd6dc1  vmovaps [rsp+0x70], xmm1
00007cbcc2dd6dc7  vmovaps xmm1, [rsp+0x110]
00007cbcc2dd6dd0  por xmm15, xmm1
00007cbcc2dd6dd5  movaps [r15+0x290], xmm15
00007cbcc2dd6ddd  vmovaps xmm1, [rsp+0x100]
00007cbcc2dd6de6  vmovaps [rsp+0x80], xmm15
00007cbcc2dd6def  vmovaps xmm15, [rsp+0x100]
00007cbcc2dd6df8  por xmm1, xmm15
00007cbcc2dd6dfd  movaps [r15+0x2C0], xmm1
00007cbcc2dd6e05  movq xmm15, qword ptr [r15+0x240]
00007cbcc2dd6e0e  vmovaps [rsp+0x90], xmm15
00007cbcc2dd6e17  vpermilpd xmm15, xmm15, 0x00
00007cbcc2dd6e1d  vmovaps [rsp+0xD0], xmm1
00007cbcc2dd6e26  vmovaps xmm1, [rsp+0x40]
00007cbcc2dd6e2c  vmovaps [rsp+0x40], xmm15
00007cbcc2dd6e32  vmovaps xmm15, [rsp+0x20]
00007cbcc2dd6e38  vmovaps [rsp+0x20], xmm14
00007cbcc2dd6e3e  vmovaps xmm14, [rsp+0x40]
00007cbcc2dd6e44  vmovaps [rsp+0x40], xmm13
00007cbcc2dd6e4a  vmovaps [rsp+0x100], xmm12
00007cbcc2dd6e53  movaps xmm13, xmm1
00007cbcc2dd6e57  vfmadd231pd xmm13, xmm15, xmm14
00007cbcc2dd6e5c  vcmppd xmm12, xmm13, xmm13, 0x03
00007cbcc2dd6e62  vptest xmm12, xmm12
00007cbcc2dd6e67  jnz 0x00007CBCC2DD7B55
00007cbcc2dd6e6d  vmovaps xmm1, [rsp+0x90]
00007cbcc2dd6e76  vpermilpd xmm1, xmm1, 0x00
00007cbcc2dd6e7c  vmovaps xmm15, [rsp+0xB0]
00007cbcc2dd6e85  vmovaps xmm14, [rsp+0x50]
00007cbcc2dd6e8b  vmovaps [rsp+0x50], xmm13
00007cbcc2dd6e91  movaps xmm12, xmm15
00007cbcc2dd6e95  vfmadd231pd xmm12, xmm14, xmm1
00007cbcc2dd6e9a  vcmppd xmm13, xmm12, xmm12, 0x03
00007cbcc2dd6ea0  vptest xmm13, xmm13
00007cbcc2dd6ea5  jnz 0x00007CBCC2DD7CAE
00007cbcc2dd6eab  vmovaps xmm1, [rsp+0x90]
00007cbcc2dd6eb4  vpermilpd xmm1, xmm1, 0x00
00007cbcc2dd6eba  vmovaps xmm15, [rsp+0x130]
00007cbcc2dd6ec3  vmovaps xmm14, [rsp+0x60]
00007cbcc2dd6ec9  vmovaps [rsp+0x60], xmm12
00007cbcc2dd6ecf  movaps xmm13, xmm15
00007cbcc2dd6ed3  vfmadd231pd xmm13, xmm14, xmm1
00007cbcc2dd6ed8  vcmppd xmm12, xmm13, xmm13, 0x03
00007cbcc2dd6ede  vptest xmm12, xmm12
00007cbcc2dd6ee3  jnz 0x00007CBCC2DD7E07
00007cbcc2dd6ee9  vmovaps xmm1, [rsp+0x120]
00007cbcc2dd6ef2  vmovaps xmm15, [rsp+0x120]
00007cbcc2dd6efb  por xmm1, xmm15
00007cbcc2dd6f00  movaps [r15+0x1D0], xmm1
00007cbcc2dd6f08  vmovaps xmm15, [rsp+0x90]
00007cbcc2dd6f11  vpermilpd xmm15, xmm15, 0x00
00007cbcc2dd6f17  vmovaps xmm14, [rsp+0x100]
00007cbcc2dd6f20  vmovaps [rsp+0x90], xmm1
00007cbcc2dd6f29  movaps xmm12, xmm14
00007cbcc2dd6f2d  vfmadd231pd xmm12, xmm2, xmm15
00007cbcc2dd6f32  vcmppd xmm1, xmm12, xmm12, 0x03
00007cbcc2dd6f38  vptest xmm1, xmm1
00007cbcc2dd6f3d  jnz 0x00007CBCC2DD7F60
00007cbcc2dd6f43  vmovaps [rsp+0xB0], xmm3
00007cbcc2dd6f4c  vmovaps xmm1, [rsp+0xB0]
00007cbcc2dd6f55  por xmm3, xmm1
00007cbcc2dd6f59  movaps [r15+0x200], xmm3
00007cbcc2dd6f61  vmovaps xmm1, [rsp+0xF0]
00007cbcc2dd6f6a  vmovaps xmm15, [rsp+0xF0]
00007cbcc2dd6f73  por xmm1, xmm15
00007cbcc2dd6f78  movaps [r15+0x1E0], xmm1
00007cbcc2dd6f80  vmovaps [rsp+0xB0], xmm7
00007cbcc2dd6f89  vmovaps xmm1, [rsp+0xB0]
00007cbcc2dd6f92  por xmm7, xmm1
00007cbcc2dd6f96  movaps [r15+0x2B0], xmm7
00007cbcc2dd6f9e  vmovaps [rsp+0xB0], xmm8
00007cbcc2dd6fa7  vmovaps xmm1, [rsp+0xB0]
00007cbcc2dd6fb0  por xmm8, xmm1
00007cbcc2dd6fb5  movaps [r15+0x300], xmm8
00007cbcc2dd6fbd  vmovaps [rsp+0xB0], xmm5
00007cbcc2dd6fc6  vpermilpd xmm5, xmm5, 0x00
00007cbcc2dd6fcc  vmovaps xmm14, [rsp+0x50]
00007cbcc2dd6fd2  vmovaps xmm8, [rsp+0x70]
00007cbcc2dd6fd8  vmovaps [rsp+0x50], xmm1
00007cbcc2dd6fde  movaps xmm2, xmm14
00007cbcc2dd6fe2  vfmadd231pd xmm2, xmm8, xmm5
00007cbcc2dd6fe7  vcmppd xmm1, xmm2, xmm2, 0x03
00007cbcc2dd6fec  vptest xmm1, xmm1
00007cbcc2dd6ff1  jnz 0x00007CBCC2DD80B9
00007cbcc2dd6ff7  vmovaps xmm1, [rsp+0xB0]
00007cbcc2dd7000  vpermilpd xmm1, xmm1, 0x00
00007cbcc2dd7006  vmovaps xmm14, [rsp+0x60]
00007cbcc2dd700c  vmovaps xmm8, [rsp+0xD0]
00007cbcc2dd7015  vmovaps [rsp+0x60], xmm15
00007cbcc2dd701b  movaps xmm5, xmm14
00007cbcc2dd701f  vfmadd231pd xmm5, xmm8, xmm1
00007cbcc2dd7024  vcmppd xmm15, xmm5, xmm5, 0x03
00007cbcc2dd7029  vptest xmm15, xmm15
00007cbcc2dd702e  jnz 0x00007CBCC2DD8210
00007cbcc2dd7034  vmovaps xmm1, [rsp+0xB0]
00007cbcc2dd703d  vpermilpd xmm1, xmm1, 0x00
00007cbcc2dd7043  vmovaps xmm14, [rsp+0x20]
00007cbcc2dd7049  movaps xmm15, xmm13
00007cbcc2dd704d  vfmadd231pd xmm15, xmm14, xmm1
00007cbcc2dd7052  vcmppd xmm8, xmm15, xmm15, 0x03
00007cbcc2dd7058  vptest xmm8, xmm8
00007cbcc2dd705d  jnz 0x00007CBCC2DD8367
00007cbcc2dd7063  vmovaps xmm1, [rsp+0xB0]
00007cbcc2dd706c  vpermilpd xmm1, xmm1, 0x00
00007cbcc2dd7072  vmovaps xmm14, [rsp+0x90]
00007cbcc2dd707b  movaps xmm13, xmm12
00007cbcc2dd707f  vfmadd231pd xmm13, xmm14, xmm1
00007cbcc2dd7084  vcmppd xmm8, xmm13, xmm13, 0x03
00007cbcc2dd708a  vptest xmm8, xmm8
00007cbcc2dd708f  jnz 0x00007CBCC2DD84C0
00007cbcc2dd7095  vmovaps [rsp+0x20], xmm6
00007cbcc2dd709b  vmovaps xmm1, [rsp+0x20]
00007cbcc2dd70a1  por xmm6, xmm1
00007cbcc2dd70a5  movaps [r15+0x180], xmm6
00007cbcc2dd70ad  vmovaps [rsp+0x20], xmm9
00007cbcc2dd70b3  vmovaps xmm1, [rsp+0x20]
00007cbcc2dd70b9  por xmm9, xmm1
00007cbcc2dd70be  movaps [r15+0x2D0], xmm9
00007cbcc2dd70c6  vmovaps [rsp+0x20], xmm10
00007cbcc2dd70cc  vmovaps xmm1, [rsp+0x20]
00007cbcc2dd70d2  por xmm10, xmm1
00007cbcc2dd70d7  movaps [r15+0x2F0], xmm10
00007cbcc2dd70df  vmovaps [rsp+0x20], xmm4
00007cbcc2dd70e5  vpermilpd xmm4, xmm4, 0x00
00007cbcc2dd70eb  vmovaps xmm14, [rsp+0x50]
00007cbcc2dd70f1  movaps xmm12, xmm5
00007cbcc2dd70f5  vfmadd231pd xmm12, xmm14, xmm4
00007cbcc2dd70fa  vcmppd xmm10, xmm12, xmm12, 0x03
00007cbcc2dd7100  vptest xmm10, xmm10
00007cbcc2dd7105  jnz 0x00007CBCC2DD8619
00007cbcc2dd710b  vmovaps xmm14, [rsp+0x20]
00007cbcc2dd7111  vpermilpd xmm14, xmm14, 0x00
00007cbcc2dd7117  movaps xmm10, xmm2
00007cbcc2dd711b  vfmadd231pd xmm10, xmm6, xmm14
00007cbcc2dd7120  vcmppd xmm8, xmm10, xmm10, 0x03
00007cbcc2dd7126  vptest xmm8, xmm8
00007cbcc2dd712b  jnz 0x00007CBCC2DD8771
00007cbcc2dd7131  lea rax, [r14+0x80]
00007cbcc2dd7138  movups xmm14, [r13+rax*1]
00007cbcc2dd713e  movaps [r15+0x190], xmm14
00007cbcc2dd7146  vmovaps xmm8, [rsp+0x20]
00007cbcc2dd714c  vpermilpd xmm8, xmm8, 0x00
00007cbcc2dd7152  vmovaps xmm6, [rsp+0x80]
00007cbcc2dd715b  movaps xmm5, xmm15
00007cbcc2dd715f  vfmadd231pd xmm5, xmm6, xmm8
00007cbcc2dd7164  vcmppd xmm4, xmm5, xmm5, 0x03
00007cbcc2dd7169  vptest xmm4, xmm4
00007cbcc2dd716e  jnz 0x00007CBCC2DD88D3
00007cbcc2dd7174  vmovaps xmm15, [rsp+0x20]
00007cbcc2dd717a  vpermilpd xmm15, xmm15, 0x00
00007cbcc2dd7180  movaps xmm8, xmm13
00007cbcc2dd7184  vfmadd231pd xmm8, xmm1, xmm15
00007cbcc2dd7189  vcmppd xmm6, xmm8, xmm8, 0x03
00007cbcc2dd718f  vptest xmm6, xmm6
00007cbcc2dd7194  jnz 0x00007CBCC2DD8A2A
00007cbcc2dd719a  vmovaps xmm1, [rsp+0x30]
00007cbcc2dd71a0  vmovaps xmm15, [rsp+0x30]
00007cbcc2dd71a6  por xmm1, xmm15
00007cbcc2dd71ab  movaps [r15+0x160], xmm1
00007cbcc2dd71b3  lea rax, [r14+0x40]
00007cbcc2dd71b7  movups xmm15, [r13+rax*1]
00007cbcc2dd71bd  lea rax, [r14+0x50]
00007cbcc2dd71c1  movups xmm13, [r13+rax*1]
00007cbcc2dd71c7  movaps [r15+0x1B0], xmm15
00007cbcc2dd71cf  movaps [r15+0x1A0], xmm13
00007cbcc2dd71d7  vmovaps xmm6, [rsp+0xC0]
00007cbcc2dd71e0  vpermilpd xmm6, xmm6, 0x00
00007cbcc2dd71e6  movaps xmm4, xmm12
00007cbcc2dd71ea  vfmadd231pd xmm4, xmm9, xmm6
00007cbcc2dd71ef  vcmppd xmm2, xmm4, xmm4, 0x03
00007cbcc2dd71f4  vptest xmm2, xmm2
00007cbcc2dd71f9  jnz 0x00007CBCC2DD8B97
00007cbcc2dd71ff  vmovaps xmm12, [rsp+0xC0]
00007cbcc2dd7208  vpermilpd xmm12, xmm12, 0x00
00007cbcc2dd720e  movaps xmm9, xmm10
00007cbcc2dd7212  vfmadd231pd xmm9, xmm1, xmm12
00007cbcc2dd7217  vcmppd xmm6, xmm9, xmm9, 0x03
00007cbcc2dd721d  vptest xmm6, xmm6
00007cbcc2dd7222  jnz 0x00007CBCC2DD8CEE
00007cbcc2dd7228  vmovaps xmm1, [rsp+0xC0]
00007cbcc2dd7231  vpermilpd xmm1, xmm1, 0x00
00007cbcc2dd7237  vmovaps xmm12, [rsp+0x40]
00007cbcc2dd723d  movaps xmm10, xmm5
00007cbcc2dd7241  vfmadd231pd xmm10, xmm12, xmm1
00007cbcc2dd7246  vcmppd xmm6, xmm10, xmm10, 0x03
00007cbcc2dd724c  vptest xmm6, xmm6
00007cbcc2dd7251  jnz 0x00007CBCC2DD8E47
00007cbcc2dd7257  vmovaps xmm1, [rsp+0xC0]
00007cbcc2dd7260  vpermilpd xmm1, xmm1, 0x00
00007cbcc2dd7266  vmovaps xmm12, [rsp+0x60]
00007cbcc2dd726c  movaps xmm6, xmm8
00007cbcc2dd7270  vfmadd231pd xmm6, xmm12, xmm1
00007cbcc2dd7275  vcmppd xmm5, xmm6, xmm6, 0x03
00007cbcc2dd727a  vptest xmm5, xmm5
00007cbcc2dd727f  jnz 0x00007CBCC2DD8F9F
00007cbcc2dd7285  lea rax, [r14+0x60]
00007cbcc2dd7289  movups xmm1, [r13+rax*1]
00007cbcc2dd728f  lea rax, [r14+0x70]
00007cbcc2dd7293  movups xmm12, [r13+rax*1]
00007cbcc2dd7299  movaps [r15+0x150], xmm1
00007cbcc2dd72a1  movaps [r15+0x120], xmm12
00007cbcc2dd72a9  vmovaps [rsp+0x20], xmm11
00007cbcc2dd72af  vpermilpd xmm11, xmm11, 0x00
00007cbcc2dd72b5  movaps xmm8, xmm4
00007cbcc2dd72b9  vfmadd231pd xmm8, xmm13, xmm11
00007cbcc2dd72be  vcmppd xmm5, xmm8, xmm8, 0x03
00007cbcc2dd72c4  vptest xmm5, xmm5
00007cbcc2dd72c9  jnz 0x00007CBCC2DD910A
00007cbcc2dd72cf  vmovaps xmm13, [rsp+0x20]
00007cbcc2dd72d5  vpermilpd xmm13, xmm13, 0x00
00007cbcc2dd72db  movaps xmm11, xmm9
00007cbcc2dd72df  vfmadd231pd xmm11, xmm1, xmm13
00007cbcc2dd72e4  vcmppd xmm5, xmm11, xmm11, 0x03
00007cbcc2dd72ea  vptest xmm5, xmm5
00007cbcc2dd72ef  jnz 0x00007CBCC2DD9263
00007cbcc2dd72f5  vmovaps xmm1, [rsp+0x20]
00007cbcc2dd72fb  vpermilpd xmm1, xmm1, 0x00
00007cbcc2dd7301  movaps xmm13, xmm10
00007cbcc2dd7305  vfmadd231pd xmm13, xmm7, xmm1
00007cbcc2dd730a  vcmppd xmm9, xmm13, xmm13, 0x03
00007cbcc2dd7310  vptest xmm9, xmm9
00007cbcc2dd7315  jnz 0x00007CBCC2DD93BC
00007cbcc2dd731b  vmovaps xmm1, [rsp+0x20]
00007cbcc2dd7321  vpermilpd xmm1, xmm1, 0x00
00007cbcc2dd7327  movaps xmm10, xmm6
00007cbcc2dd732b  vfmadd231pd xmm10, xmm15, xmm1
00007cbcc2dd7330  vcmppd xmm9, xmm10, xmm10, 0x03
00007cbcc2dd7336  vptest xmm9, xmm9
00007cbcc2dd733b  jnz 0x00007CBCC2DD9514
00007cbcc2dd7341  lea rax, [r14+0x20]
00007cbcc2dd7345  movups xmm1, [r13+rax*1]
00007cbcc2dd734b  lea rax, [r14+0x30]
00007cbcc2dd734f  movups xmm15, [r13+rax*1]
00007cbcc2dd7355  vmovaps xmm9, [rsp+0xA0]
00007cbcc2dd735e  vpermilpd xmm9, xmm9, 0x00
00007cbcc2dd7364  movaps xmm7, xmm8
00007cbcc2dd7368  vfmadd231pd xmm7, xmm3, xmm9
00007cbcc2dd736d  vcmppd xmm6, xmm7, xmm7, 0x03
00007cbcc2dd7372  vptest xmm6, xmm6
00007cbcc2dd7377  jnz 0x00007CBCC2DD9680
00007cbcc2dd737d  vmovaps xmm9, [rsp+0xA0]
00007cbcc2dd7386  vpermilpd xmm9, xmm9, 0x00
00007cbcc2dd738c  movaps xmm8, xmm11
00007cbcc2dd7390  vfmadd231pd xmm8, xmm14, xmm9
00007cbcc2dd7395  vcmppd xmm6, xmm8, xmm8, 0x03
00007cbcc2dd739b  vptest xmm6, xmm6
00007cbcc2dd73a0  jnz 0x00007CBCC2DD97D7
00007cbcc2dd73a6  vmovaps xmm14, [rsp+0xA0]
00007cbcc2dd73af  vpermilpd xmm14, xmm14, 0x00
00007cbcc2dd73b5  movaps xmm11, xmm13
00007cbcc2dd73b9  vfmadd231pd xmm11, xmm12, xmm14
00007cbcc2dd73be  vcmppd xmm9, xmm11, xmm11, 0x03
00007cbcc2dd73c4  vptest xmm9, xmm9
00007cbcc2dd73c9  jnz 0x00007CBCC2DD9931
00007cbcc2dd73cf  vmovaps xmm14, [rsp+0xA0]
00007cbcc2dd73d8  vpermilpd xmm14, xmm14, 0x00
00007cbcc2dd73de  movaps xmm12, xmm10
00007cbcc2dd73e2  vfmadd231pd xmm12, xmm15, xmm14
00007cbcc2dd73e7  vcmppd xmm13, xmm12, xmm12, 0x03
00007cbcc2dd73ed  vptest xmm13, xmm13
00007cbcc2dd73f2  jnz 0x00007CBCC2DD9A8B
00007cbcc2dd73f8  lea rax, [r14+0x90]
00007cbcc2dd73ff  movups xmm15, [r13+rax*1]
00007cbcc2dd7405  lea rax, [r14+0xA0]
00007cbcc2dd740c  movups xmm14, [r13+rax*1]
00007cbcc2dd7412  movaps [r15+0x140], xmm15
00007cbcc2dd741a  movaps [r15+0x130], xmm14
00007cbcc2dd7422  vmovaps xmm13, [rsp+0x10]
00007cbcc2dd7428  vpermilpd xmm13, xmm13, 0x00
00007cbcc2dd742e  movaps xmm10, xmm7
00007cbcc2dd7432  vfmadd231pd xmm10, xmm1, xmm13
00007cbcc2dd7437  vcmppd xmm9, xmm10, xmm10, 0x03
00007cbcc2dd743d  vptest xmm9, xmm9
00007cbcc2dd7442  jnz 0x00007CBCC2DD9BF9
00007cbcc2dd7448  movaps [r15+0x220], xmm10
00007cbcc2dd7450  lea rax, [r14+0x10]
00007cbcc2dd7454  movups xmm1, [r13+rax*1]
00007cbcc2dd745a  movaps [r15+0x240], xmm1
00007cbcc2dd7462  vmovaps xmm13, [rsp+0x10]
00007cbcc2dd7468  vpermilpd xmm13, xmm13, 0x00
00007cbcc2dd746e  movaps xmm9, xmm8
00007cbcc2dd7472  vfmadd231pd xmm9, xmm14, xmm13
00007cbcc2dd7477  vcmppd xmm7, xmm9, xmm9, 0x03
00007cbcc2dd747d  vptest xmm7, xmm7
00007cbcc2dd7482  jnz 0x00007CBCC2DD9D5B
00007cbcc2dd7488  movaps [r15+0x110], xmm9
00007cbcc2dd7490  vmovaps xmm14, [rsp+0x10]
00007cbcc2dd7496  vpermilpd xmm14, xmm14, 0x00
00007cbcc2dd749c  movaps xmm13, xmm11
00007cbcc2dd74a0  vfmadd231pd xmm13, xmm15, xmm14
00007cbcc2dd74a5  vcmppd xmm8, xmm13, xmm13, 0x03
00007cbcc2dd74ab  vptest xmm8, xmm8
00007cbcc2dd74b0  jnz 0x00007CBCC2DD9EB5
00007cbcc2dd74b6  movaps [r15+0x170], xmm13
00007cbcc2dd74be  vmovaps xmm15, [rsp+0x10]
00007cbcc2dd74c4  vpermilpd xmm15, xmm15, 0x00
00007cbcc2dd74ca  movaps xmm14, xmm12
00007cbcc2dd74ce  vfmadd231pd xmm14, xmm1, xmm15
00007cbcc2dd74d3  vcmppd xmm11, xmm14, xmm14, 0x03
00007cbcc2dd74d9  vptest xmm11, xmm11
00007cbcc2dd74de  jnz 0x00007CBCC2DDA00F
00007cbcc2dd74e4  movaps [r15+0x230], xmm14
00007cbcc2dd74ec  mov rax, [rsp+0xE0]
00007cbcc2dd74f4  movups [r13+rax*1], xmm9
00007cbcc2dd74fa  lea r14, [rax+0x10]
00007cbcc2dd74fe  movups [r13+r14*1], xmm13
00007cbcc2dd7504  lea r14, [rax+0x20]
00007cbcc2dd7508  movups [r13+r14*1], xmm10
00007cbcc2dd750e  lea r14, [rax+0x30]
00007cbcc2dd7512  movups [r13+r14*1], xmm14
00007cbcc2dd7518  mov eax, [r15+0x108]
00007cbcc2dd751f  sahf
00007cbcc2dd7520  jnz 0x00007CBCC2DD7552
00007cbcc2dd7522  cmp dword ptr [r15+0x318], 0x00
00007cbcc2dd752a  jz 0x00007CBCC2DD67A0
00007cbcc2dd7530  nop [rax+rax*1], ax
00007cbcc2dd7539  nop [rax+rax*1], eax
00007cbcc2dd7541  mov eax, 0x4103F0
00007cbcc2dd7546  mov [r15+0x100], rax
00007cbcc2dd754d  jmp 0x00007CBCC2BFE110
00007cbcc2dd7552  cmp dword ptr [r15+0x318], 0x00
00007cbcc2dd755a  jz 0x00007CBCC2DD2E40
00007cbcc2dd7560  nop [rax+rax*1], ax
00007cbcc2dd7569  nop [rax+rax*1], eax
00007cbcc2dd7571  mov eax, 0x410274
00007cbcc2dd7576  mov [r15+0x100], rax
00007cbcc2dd757d  jmp 0x00007CBCC2BFE110
00007cbcc2dd7582  int3
00007cbcc2dd7583  call 0x00007CBCC2CE27E0
00007cbcc2dd7588  jmp 0x00007CBCC2DD6860
00007cbcc2dd758d  call 0x00007CBCC2CE1570
00007cbcc2dd7592  jmp 0x00007CBCC2DD6869
00007cbcc2dd7597  call 0x00007CBCC2CE27E0
00007cbcc2dd759c  jmp 0x00007CBCC2DD68B2
00007cbcc2dd75a1  call 0x00007CBCC2CE1570
00007cbcc2dd75a6  jmp 0x00007CBCC2DD68BB
00007cbcc2dd75ab  call 0x00007CBCC2CE27E0
00007cbcc2dd75b0  jmp 0x00007CBCC2DD6953
00007cbcc2dd75b5  call 0x00007CBCC2CE1570
00007cbcc2dd75ba  jmp 0x00007CBCC2DD695C
00007cbcc2dd75bf  call 0x00007CBCC2C0DC20
00007cbcc2dd75c4  jmp 0x00007CBCC2DD6A47
00007cbcc2dd75c9  call 0x00007CBCC2CD64F0
00007cbcc2dd75ce  jmp 0x00007CBCC2DD6A76
00007cbcc2dd75d3  call 0x00007CBCC2CB47C0
00007cbcc2dd75d8  jmp 0x00007CBCC2DD6A91
00007cbcc2dd75dd  sub rsp, 0x08
00007cbcc2dd75e1  push rax
00007cbcc2dd75e2  push rcx
00007cbcc2dd75e3  push rdx
00007cbcc2dd75e4  push rdi
00007cbcc2dd75e5  push rsi
00007cbcc2dd75e6  push r8
00007cbcc2dd75e8  push r9
00007cbcc2dd75ea  push r10
00007cbcc2dd75ec  push r11
00007cbcc2dd75ee  sub rsp, 0xF0
00007cbcc2dd75f5  vmovaps [rsp], xmm0
00007cbcc2dd75fa  vmovaps [rsp+0x10], xmm1
00007cbcc2dd7600  vmovaps [rsp+0x20], xmm2
00007cbcc2dd7606  vmovaps [rsp+0x30], xmm3
00007cbcc2dd760c  vmovaps [rsp+0x40], xmm4
00007cbcc2dd7612  vmovaps [rsp+0x50], xmm5
00007cbcc2dd7618  vmovaps [rsp+0x60], xmm6
00007cbcc2dd761e  vmovaps [rsp+0x70], xmm7
00007cbcc2dd7624  vmovaps [rsp+0x80], xmm8
00007cbcc2dd762d  vmovaps [rsp+0x90], xmm9
00007cbcc2dd7636  vmovaps [rsp+0xA0], xmm10
00007cbcc2dd763f  vmovaps [rsp+0xB0], xmm11
00007cbcc2dd7648  vmovaps [rsp+0xC0], xmm12
00007cbcc2dd7651  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd765a  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd7663  sub rsp, 0x40
00007cbcc2dd7667  lea rdi, [rsp]
00007cbcc2dd766b  lea rsi, [rsp+0x10]
00007cbcc2dd7670  lea rdx, [rsp+0x20]
00007cbcc2dd7675  lea rcx, [rsp+0x30]
00007cbcc2dd767a  mov r8d, 0x00
00007cbcc2dd7680  lea r9, [r15+0x3A8]
00007cbcc2dd7687  movaps [rdi], xmm13
00007cbcc2dd768b  movaps [rsi], xmm1
00007cbcc2dd768e  movaps [rdx], xmm15
00007cbcc2dd7692  movaps [rcx], xmm14
00007cbcc2dd7696  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd76a0  call rax
00007cbcc2dd76a2  movaps xmm13, [rsp]
00007cbcc2dd76a7  add rsp, 0x40
00007cbcc2dd76ab  vmovaps xmm0, [rsp]
00007cbcc2dd76b0  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd76b6  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd76bc  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd76c2  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd76c8  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd76ce  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd76d4  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd76da  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd76e3  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd76ec  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dd76f5  vmovaps xmm11, [rsp+0xB0]
00007cbcc2dd76fe  vmovaps xmm12, [rsp+0xC0]
00007cbcc2dd7707  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd7710  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd7719  add rsp, 0xF0
00007cbcc2dd7720  pop r11
00007cbcc2dd7722  pop r10
00007cbcc2dd7724  pop r9
00007cbcc2dd7726  pop r8
00007cbcc2dd7728  pop rsi
00007cbcc2dd7729  pop rdi
00007cbcc2dd772a  pop rdx
00007cbcc2dd772b  pop rcx
00007cbcc2dd772c  pop rax
00007cbcc2dd772d  add rsp, 0x08
00007cbcc2dd7731  jmp 0x00007CBCC2DD6B04
00007cbcc2dd7736  sub rsp, 0x08
00007cbcc2dd773a  push rax
00007cbcc2dd773b  push rcx
00007cbcc2dd773c  push rdx
00007cbcc2dd773d  push rdi
00007cbcc2dd773e  push rsi
00007cbcc2dd773f  push r8
00007cbcc2dd7741  push r9
00007cbcc2dd7743  push r10
00007cbcc2dd7745  push r11
00007cbcc2dd7747  sub rsp, 0xF0
00007cbcc2dd774e  vmovaps [rsp], xmm0
00007cbcc2dd7753  vmovaps [rsp+0x10], xmm1
00007cbcc2dd7759  vmovaps [rsp+0x20], xmm2
00007cbcc2dd775f  vmovaps [rsp+0x30], xmm3
00007cbcc2dd7765  vmovaps [rsp+0x40], xmm4
00007cbcc2dd776b  vmovaps [rsp+0x50], xmm5
00007cbcc2dd7771  vmovaps [rsp+0x60], xmm6
00007cbcc2dd7777  vmovaps [rsp+0x70], xmm7
00007cbcc2dd777d  vmovaps [rsp+0x80], xmm8
00007cbcc2dd7786  vmovaps [rsp+0x90], xmm9
00007cbcc2dd778f  vmovaps [rsp+0xA0], xmm10
00007cbcc2dd7798  vmovaps [rsp+0xB0], xmm11
00007cbcc2dd77a1  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd77aa  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd77b3  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd77bc  sub rsp, 0x40
00007cbcc2dd77c0  lea rdi, [rsp]
00007cbcc2dd77c4  lea rsi, [rsp+0x10]
00007cbcc2dd77c9  lea rdx, [rsp+0x20]
00007cbcc2dd77ce  lea rcx, [rsp+0x30]
00007cbcc2dd77d3  mov r8d, 0x00
00007cbcc2dd77d9  lea r9, [r15+0x3A8]
00007cbcc2dd77e0  movaps [rdi], xmm12
00007cbcc2dd77e4  movaps [rsi], xmm15
00007cbcc2dd77e8  movaps [rdx], xmm1
00007cbcc2dd77eb  movaps [rcx], xmm14
00007cbcc2dd77ef  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd77f9  call rax
00007cbcc2dd77fb  movaps xmm12, [rsp]
00007cbcc2dd7800  add rsp, 0x40
00007cbcc2dd7804  vmovaps xmm0, [rsp]
00007cbcc2dd7809  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd780f  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd7815  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd781b  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd7821  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd7827  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd782d  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd7833  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd783c  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd7845  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dd784e  vmovaps xmm11, [rsp+0xB0]
00007cbcc2dd7857  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd7860  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd7869  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd7872  add rsp, 0xF0
00007cbcc2dd7879  pop r11
00007cbcc2dd787b  pop r10
00007cbcc2dd787d  pop r9
00007cbcc2dd787f  pop r8
00007cbcc2dd7881  pop rsi
00007cbcc2dd7882  pop rdi
00007cbcc2dd7883  pop rdx
00007cbcc2dd7884  pop rcx
00007cbcc2dd7885  pop rax
00007cbcc2dd7886  add rsp, 0x08
00007cbcc2dd788a  jmp 0x00007CBCC2DD6B32
00007cbcc2dd788f  call 0x00007CBCC2CB52F0
00007cbcc2dd7894  jmp 0x00007CBCC2DD6C1E
00007cbcc2dd7899  sub rsp, 0x08
00007cbcc2dd789d  push rax
00007cbcc2dd789e  push rcx
00007cbcc2dd789f  push rdx
00007cbcc2dd78a0  push rdi
00007cbcc2dd78a1  push rsi
00007cbcc2dd78a2  push r8
00007cbcc2dd78a4  push r9
00007cbcc2dd78a6  push r10
00007cbcc2dd78a8  push r11
00007cbcc2dd78aa  sub rsp, 0xF0
00007cbcc2dd78b1  vmovaps [rsp], xmm0
00007cbcc2dd78b6  vmovaps [rsp+0x10], xmm1
00007cbcc2dd78bc  vmovaps [rsp+0x20], xmm2
00007cbcc2dd78c2  vmovaps [rsp+0x30], xmm3
00007cbcc2dd78c8  vmovaps [rsp+0x40], xmm4
00007cbcc2dd78ce  vmovaps [rsp+0x50], xmm5
00007cbcc2dd78d4  vmovaps [rsp+0x60], xmm6
00007cbcc2dd78da  vmovaps [rsp+0x70], xmm7
00007cbcc2dd78e0  vmovaps [rsp+0x80], xmm8
00007cbcc2dd78e9  vmovaps [rsp+0x90], xmm9
00007cbcc2dd78f2  vmovaps [rsp+0xA0], xmm10
00007cbcc2dd78fb  vmovaps [rsp+0xB0], xmm11
00007cbcc2dd7904  vmovaps [rsp+0xC0], xmm12
00007cbcc2dd790d  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd7916  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd791f  sub rsp, 0x40
00007cbcc2dd7923  lea rdi, [rsp]
00007cbcc2dd7927  lea rsi, [rsp+0x10]
00007cbcc2dd792c  lea rdx, [rsp+0x20]
00007cbcc2dd7931  lea rcx, [rsp+0x30]
00007cbcc2dd7936  mov r8d, 0x00
00007cbcc2dd793c  lea r9, [r15+0x3A8]
00007cbcc2dd7943  movaps [rdi], xmm13
00007cbcc2dd7947  movaps [rsi], xmm1
00007cbcc2dd794a  movaps [rdx], xmm15
00007cbcc2dd794e  movaps [rcx], xmm14
00007cbcc2dd7952  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd795c  call rax
00007cbcc2dd795e  movaps xmm13, [rsp]
00007cbcc2dd7963  add rsp, 0x40
00007cbcc2dd7967  vmovaps xmm0, [rsp]
00007cbcc2dd796c  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd7972  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd7978  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd797e  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd7984  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd798a  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd7990  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd7996  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd799f  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd79a8  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dd79b1  vmovaps xmm11, [rsp+0xB0]
00007cbcc2dd79ba  vmovaps xmm12, [rsp+0xC0]
00007cbcc2dd79c3  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd79cc  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd79d5  add rsp, 0xF0
00007cbcc2dd79dc  pop r11
00007cbcc2dd79de  pop r10
00007cbcc2dd79e0  pop r9
00007cbcc2dd79e2  pop r8
00007cbcc2dd79e4  pop rsi
00007cbcc2dd79e5  pop rdi
00007cbcc2dd79e6  pop rdx
00007cbcc2dd79e7  pop rcx
00007cbcc2dd79e8  pop rax
00007cbcc2dd79e9  add rsp, 0x08
00007cbcc2dd79ed  jmp 0x00007CBCC2DD6C93
00007cbcc2dd79f2  call 0x00007CBCC2BFF430
00007cbcc2dd79f7  jmp 0x00007CBCC2DD6CA0
00007cbcc2dd79fc  sub rsp, 0x08
00007cbcc2dd7a00  push rax
00007cbcc2dd7a01  push rcx
00007cbcc2dd7a02  push rdx
00007cbcc2dd7a03  push rdi
00007cbcc2dd7a04  push rsi
00007cbcc2dd7a05  push r8
00007cbcc2dd7a07  push r9
00007cbcc2dd7a09  push r10
00007cbcc2dd7a0b  push r11
00007cbcc2dd7a0d  sub rsp, 0xF0
00007cbcc2dd7a14  vmovaps [rsp], xmm0
00007cbcc2dd7a19  vmovaps [rsp+0x10], xmm1
00007cbcc2dd7a1f  vmovaps [rsp+0x20], xmm2
00007cbcc2dd7a25  vmovaps [rsp+0x30], xmm3
00007cbcc2dd7a2b  vmovaps [rsp+0x40], xmm4
00007cbcc2dd7a31  vmovaps [rsp+0x50], xmm5
00007cbcc2dd7a37  vmovaps [rsp+0x60], xmm6
00007cbcc2dd7a3d  vmovaps [rsp+0x70], xmm7
00007cbcc2dd7a43  vmovaps [rsp+0x80], xmm8
00007cbcc2dd7a4c  vmovaps [rsp+0x90], xmm9
00007cbcc2dd7a55  vmovaps [rsp+0xA0], xmm10
00007cbcc2dd7a5e  vmovaps [rsp+0xB0], xmm11
00007cbcc2dd7a67  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd7a70  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd7a79  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd7a82  sub rsp, 0x40
00007cbcc2dd7a86  lea rdi, [rsp]
00007cbcc2dd7a8a  lea rsi, [rsp+0x10]
00007cbcc2dd7a8f  lea rdx, [rsp+0x20]
00007cbcc2dd7a94  lea rcx, [rsp+0x30]
00007cbcc2dd7a99  mov r8d, 0x00
00007cbcc2dd7a9f  lea r9, [r15+0x3A8]
00007cbcc2dd7aa6  movaps [rdi], xmm12
00007cbcc2dd7aaa  movaps [rsi], xmm15
00007cbcc2dd7aae  movaps [rdx], xmm1
00007cbcc2dd7ab1  movaps [rcx], xmm14
00007cbcc2dd7ab5  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd7abf  call rax
00007cbcc2dd7ac1  movaps xmm12, [rsp]
00007cbcc2dd7ac6  add rsp, 0x40
00007cbcc2dd7aca  vmovaps xmm0, [rsp]
00007cbcc2dd7acf  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd7ad5  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd7adb  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd7ae1  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd7ae7  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd7aed  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd7af3  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd7af9  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd7b02  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd7b0b  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dd7b14  vmovaps xmm11, [rsp+0xB0]
00007cbcc2dd7b1d  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd7b26  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd7b2f  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd7b38  add rsp, 0xF0
00007cbcc2dd7b3f  pop r11
00007cbcc2dd7b41  pop r10
00007cbcc2dd7b43  pop r9
00007cbcc2dd7b45  pop r8
00007cbcc2dd7b47  pop rsi
00007cbcc2dd7b48  pop rdi
00007cbcc2dd7b49  pop rdx
00007cbcc2dd7b4a  pop rcx
00007cbcc2dd7b4b  pop rax
00007cbcc2dd7b4c  add rsp, 0x08
00007cbcc2dd7b50  jmp 0x00007CBCC2DD6CCC
00007cbcc2dd7b55  sub rsp, 0x08
00007cbcc2dd7b59  push rax
00007cbcc2dd7b5a  push rcx
00007cbcc2dd7b5b  push rdx
00007cbcc2dd7b5c  push rdi
00007cbcc2dd7b5d  push rsi
00007cbcc2dd7b5e  push r8
00007cbcc2dd7b60  push r9
00007cbcc2dd7b62  push r10
00007cbcc2dd7b64  push r11
00007cbcc2dd7b66  sub rsp, 0xF0
00007cbcc2dd7b6d  vmovaps [rsp], xmm0
00007cbcc2dd7b72  vmovaps [rsp+0x10], xmm1
00007cbcc2dd7b78  vmovaps [rsp+0x20], xmm2
00007cbcc2dd7b7e  vmovaps [rsp+0x30], xmm3
00007cbcc2dd7b84  vmovaps [rsp+0x40], xmm4
00007cbcc2dd7b8a  vmovaps [rsp+0x50], xmm5
00007cbcc2dd7b90  vmovaps [rsp+0x60], xmm6
00007cbcc2dd7b96  vmovaps [rsp+0x70], xmm7
00007cbcc2dd7b9c  vmovaps [rsp+0x80], xmm8
00007cbcc2dd7ba5  vmovaps [rsp+0x90], xmm9
00007cbcc2dd7bae  vmovaps [rsp+0xA0], xmm10
00007cbcc2dd7bb7  vmovaps [rsp+0xB0], xmm11
00007cbcc2dd7bc0  vmovaps [rsp+0xC0], xmm12
00007cbcc2dd7bc9  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd7bd2  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd7bdb  sub rsp, 0x40
00007cbcc2dd7bdf  lea rdi, [rsp]
00007cbcc2dd7be3  lea rsi, [rsp+0x10]
00007cbcc2dd7be8  lea rdx, [rsp+0x20]
00007cbcc2dd7bed  lea rcx, [rsp+0x30]
00007cbcc2dd7bf2  mov r8d, 0x00
00007cbcc2dd7bf8  lea r9, [r15+0x3A8]
00007cbcc2dd7bff  movaps [rdi], xmm13
00007cbcc2dd7c03  movaps [rsi], xmm1
00007cbcc2dd7c06  movaps [rdx], xmm15
00007cbcc2dd7c0a  movaps [rcx], xmm14
00007cbcc2dd7c0e  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd7c18  call rax
00007cbcc2dd7c1a  movaps xmm13, [rsp]
00007cbcc2dd7c1f  add rsp, 0x40
00007cbcc2dd7c23  vmovaps xmm0, [rsp]
00007cbcc2dd7c28  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd7c2e  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd7c34  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd7c3a  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd7c40  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd7c46  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd7c4c  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd7c52  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd7c5b  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd7c64  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dd7c6d  vmovaps xmm11, [rsp+0xB0]
00007cbcc2dd7c76  vmovaps xmm12, [rsp+0xC0]
00007cbcc2dd7c7f  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd7c88  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd7c91  add rsp, 0xF0
00007cbcc2dd7c98  pop r11
00007cbcc2dd7c9a  pop r10
00007cbcc2dd7c9c  pop r9
00007cbcc2dd7c9e  pop r8
00007cbcc2dd7ca0  pop rsi
00007cbcc2dd7ca1  pop rdi
00007cbcc2dd7ca2  pop rdx
00007cbcc2dd7ca3  pop rcx
00007cbcc2dd7ca4  pop rax
00007cbcc2dd7ca5  add rsp, 0x08
00007cbcc2dd7ca9  jmp 0x00007CBCC2DD6E6D
00007cbcc2dd7cae  sub rsp, 0x08
00007cbcc2dd7cb2  push rax
00007cbcc2dd7cb3  push rcx
00007cbcc2dd7cb4  push rdx
00007cbcc2dd7cb5  push rdi
00007cbcc2dd7cb6  push rsi
00007cbcc2dd7cb7  push r8
00007cbcc2dd7cb9  push r9
00007cbcc2dd7cbb  push r10
00007cbcc2dd7cbd  push r11
00007cbcc2dd7cbf  sub rsp, 0xF0
00007cbcc2dd7cc6  vmovaps [rsp], xmm0
00007cbcc2dd7ccb  vmovaps [rsp+0x10], xmm1
00007cbcc2dd7cd1  vmovaps [rsp+0x20], xmm2
00007cbcc2dd7cd7  vmovaps [rsp+0x30], xmm3
00007cbcc2dd7cdd  vmovaps [rsp+0x40], xmm4
00007cbcc2dd7ce3  vmovaps [rsp+0x50], xmm5
00007cbcc2dd7ce9  vmovaps [rsp+0x60], xmm6
00007cbcc2dd7cef  vmovaps [rsp+0x70], xmm7
00007cbcc2dd7cf5  vmovaps [rsp+0x80], xmm8
00007cbcc2dd7cfe  vmovaps [rsp+0x90], xmm9
00007cbcc2dd7d07  vmovaps [rsp+0xA0], xmm10
00007cbcc2dd7d10  vmovaps [rsp+0xB0], xmm11
00007cbcc2dd7d19  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd7d22  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd7d2b  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd7d34  sub rsp, 0x40
00007cbcc2dd7d38  lea rdi, [rsp]
00007cbcc2dd7d3c  lea rsi, [rsp+0x10]
00007cbcc2dd7d41  lea rdx, [rsp+0x20]
00007cbcc2dd7d46  lea rcx, [rsp+0x30]
00007cbcc2dd7d4b  mov r8d, 0x00
00007cbcc2dd7d51  lea r9, [r15+0x3A8]
00007cbcc2dd7d58  movaps [rdi], xmm12
00007cbcc2dd7d5c  movaps [rsi], xmm15
00007cbcc2dd7d60  movaps [rdx], xmm14
00007cbcc2dd7d64  movaps [rcx], xmm1
00007cbcc2dd7d67  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd7d71  call rax
00007cbcc2dd7d73  movaps xmm12, [rsp]
00007cbcc2dd7d78  add rsp, 0x40
00007cbcc2dd7d7c  vmovaps xmm0, [rsp]
00007cbcc2dd7d81  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd7d87  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd7d8d  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd7d93  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd7d99  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd7d9f  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd7da5  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd7dab  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd7db4  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd7dbd  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dd7dc6  vmovaps xmm11, [rsp+0xB0]
00007cbcc2dd7dcf  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd7dd8  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd7de1  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd7dea  add rsp, 0xF0
00007cbcc2dd7df1  pop r11
00007cbcc2dd7df3  pop r10
00007cbcc2dd7df5  pop r9
00007cbcc2dd7df7  pop r8
00007cbcc2dd7df9  pop rsi
00007cbcc2dd7dfa  pop rdi
00007cbcc2dd7dfb  pop rdx
00007cbcc2dd7dfc  pop rcx
00007cbcc2dd7dfd  pop rax
00007cbcc2dd7dfe  add rsp, 0x08
00007cbcc2dd7e02  jmp 0x00007CBCC2DD6EAB
00007cbcc2dd7e07  sub rsp, 0x08
00007cbcc2dd7e0b  push rax
00007cbcc2dd7e0c  push rcx
00007cbcc2dd7e0d  push rdx
00007cbcc2dd7e0e  push rdi
00007cbcc2dd7e0f  push rsi
00007cbcc2dd7e10  push r8
00007cbcc2dd7e12  push r9
00007cbcc2dd7e14  push r10
00007cbcc2dd7e16  push r11
00007cbcc2dd7e18  sub rsp, 0xF0
00007cbcc2dd7e1f  vmovaps [rsp], xmm0
00007cbcc2dd7e24  vmovaps [rsp+0x10], xmm1
00007cbcc2dd7e2a  vmovaps [rsp+0x20], xmm2
00007cbcc2dd7e30  vmovaps [rsp+0x30], xmm3
00007cbcc2dd7e36  vmovaps [rsp+0x40], xmm4
00007cbcc2dd7e3c  vmovaps [rsp+0x50], xmm5
00007cbcc2dd7e42  vmovaps [rsp+0x60], xmm6
00007cbcc2dd7e48  vmovaps [rsp+0x70], xmm7
00007cbcc2dd7e4e  vmovaps [rsp+0x80], xmm8
00007cbcc2dd7e57  vmovaps [rsp+0x90], xmm9
00007cbcc2dd7e60  vmovaps [rsp+0xA0], xmm10
00007cbcc2dd7e69  vmovaps [rsp+0xB0], xmm11
00007cbcc2dd7e72  vmovaps [rsp+0xC0], xmm12
00007cbcc2dd7e7b  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd7e84  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd7e8d  sub rsp, 0x40
00007cbcc2dd7e91  lea rdi, [rsp]
00007cbcc2dd7e95  lea rsi, [rsp+0x10]
00007cbcc2dd7e9a  lea rdx, [rsp+0x20]
00007cbcc2dd7e9f  lea rcx, [rsp+0x30]
00007cbcc2dd7ea4  mov r8d, 0x00
00007cbcc2dd7eaa  lea r9, [r15+0x3A8]
00007cbcc2dd7eb1  movaps [rdi], xmm13
00007cbcc2dd7eb5  movaps [rsi], xmm15
00007cbcc2dd7eb9  movaps [rdx], xmm14
00007cbcc2dd7ebd  movaps [rcx], xmm1
00007cbcc2dd7ec0  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd7eca  call rax
00007cbcc2dd7ecc  movaps xmm13, [rsp]
00007cbcc2dd7ed1  add rsp, 0x40
00007cbcc2dd7ed5  vmovaps xmm0, [rsp]
00007cbcc2dd7eda  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd7ee0  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd7ee6  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd7eec  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd7ef2  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd7ef8  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd7efe  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd7f04  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd7f0d  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd7f16  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dd7f1f  vmovaps xmm11, [rsp+0xB0]
00007cbcc2dd7f28  vmovaps xmm12, [rsp+0xC0]
00007cbcc2dd7f31  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd7f3a  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd7f43  add rsp, 0xF0
00007cbcc2dd7f4a  pop r11
00007cbcc2dd7f4c  pop r10
00007cbcc2dd7f4e  pop r9
00007cbcc2dd7f50  pop r8
00007cbcc2dd7f52  pop rsi
00007cbcc2dd7f53  pop rdi
00007cbcc2dd7f54  pop rdx
00007cbcc2dd7f55  pop rcx
00007cbcc2dd7f56  pop rax
00007cbcc2dd7f57  add rsp, 0x08
00007cbcc2dd7f5b  jmp 0x00007CBCC2DD6EE9
00007cbcc2dd7f60  sub rsp, 0x08
00007cbcc2dd7f64  push rax
00007cbcc2dd7f65  push rcx
00007cbcc2dd7f66  push rdx
00007cbcc2dd7f67  push rdi
00007cbcc2dd7f68  push rsi
00007cbcc2dd7f69  push r8
00007cbcc2dd7f6b  push r9
00007cbcc2dd7f6d  push r10
00007cbcc2dd7f6f  push r11
00007cbcc2dd7f71  sub rsp, 0xF0
00007cbcc2dd7f78  vmovaps [rsp], xmm0
00007cbcc2dd7f7d  vmovaps [rsp+0x10], xmm1
00007cbcc2dd7f83  vmovaps [rsp+0x20], xmm2
00007cbcc2dd7f89  vmovaps [rsp+0x30], xmm3
00007cbcc2dd7f8f  vmovaps [rsp+0x40], xmm4
00007cbcc2dd7f95  vmovaps [rsp+0x50], xmm5
00007cbcc2dd7f9b  vmovaps [rsp+0x60], xmm6
00007cbcc2dd7fa1  vmovaps [rsp+0x70], xmm7
00007cbcc2dd7fa7  vmovaps [rsp+0x80], xmm8
00007cbcc2dd7fb0  vmovaps [rsp+0x90], xmm9
00007cbcc2dd7fb9  vmovaps [rsp+0xA0], xmm10
00007cbcc2dd7fc2  vmovaps [rsp+0xB0], xmm11
00007cbcc2dd7fcb  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd7fd4  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd7fdd  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd7fe6  sub rsp, 0x40
00007cbcc2dd7fea  lea rdi, [rsp]
00007cbcc2dd7fee  lea rsi, [rsp+0x10]
00007cbcc2dd7ff3  lea rdx, [rsp+0x20]
00007cbcc2dd7ff8  lea rcx, [rsp+0x30]
00007cbcc2dd7ffd  mov r8d, 0x00
00007cbcc2dd8003  lea r9, [r15+0x3A8]
00007cbcc2dd800a  movaps [rdi], xmm12
00007cbcc2dd800e  movaps [rsi], xmm14
00007cbcc2dd8012  movaps [rdx], xmm2
00007cbcc2dd8015  movaps [rcx], xmm15
00007cbcc2dd8019  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd8023  call rax
00007cbcc2dd8025  movaps xmm12, [rsp]
00007cbcc2dd802a  add rsp, 0x40
00007cbcc2dd802e  vmovaps xmm0, [rsp]
00007cbcc2dd8033  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd8039  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd803f  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd8045  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd804b  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd8051  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd8057  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd805d  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd8066  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd806f  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dd8078  vmovaps xmm11, [rsp+0xB0]
00007cbcc2dd8081  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd808a  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd8093  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd809c  add rsp, 0xF0
00007cbcc2dd80a3  pop r11
00007cbcc2dd80a5  pop r10
00007cbcc2dd80a7  pop r9
00007cbcc2dd80a9  pop r8
00007cbcc2dd80ab  pop rsi
00007cbcc2dd80ac  pop rdi
00007cbcc2dd80ad  pop rdx
00007cbcc2dd80ae  pop rcx
00007cbcc2dd80af  pop rax
00007cbcc2dd80b0  add rsp, 0x08
00007cbcc2dd80b4  jmp 0x00007CBCC2DD6F43
00007cbcc2dd80b9  sub rsp, 0x08
00007cbcc2dd80bd  push rax
00007cbcc2dd80be  push rcx
00007cbcc2dd80bf  push rdx
00007cbcc2dd80c0  push rdi
00007cbcc2dd80c1  push rsi
00007cbcc2dd80c2  push r8
00007cbcc2dd80c4  push r9
00007cbcc2dd80c6  push r10
00007cbcc2dd80c8  push r11
00007cbcc2dd80ca  sub rsp, 0xF0
00007cbcc2dd80d1  vmovaps [rsp], xmm0
00007cbcc2dd80d6  vmovaps [rsp+0x10], xmm1
00007cbcc2dd80dc  vmovaps [rsp+0x20], xmm3
00007cbcc2dd80e2  vmovaps [rsp+0x30], xmm4
00007cbcc2dd80e8  vmovaps [rsp+0x40], xmm5
00007cbcc2dd80ee  vmovaps [rsp+0x50], xmm6
00007cbcc2dd80f4  vmovaps [rsp+0x60], xmm7
00007cbcc2dd80fa  vmovaps [rsp+0x70], xmm8
00007cbcc2dd8100  vmovaps [rsp+0x80], xmm9
00007cbcc2dd8109  vmovaps [rsp+0x90], xmm10
00007cbcc2dd8112  vmovaps [rsp+0xA0], xmm11
00007cbcc2dd811b  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd8124  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd812d  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd8136  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd813f  sub rsp, 0x40
00007cbcc2dd8143  lea rdi, [rsp]
00007cbcc2dd8147  lea rsi, [rsp+0x10]
00007cbcc2dd814c  lea rdx, [rsp+0x20]
00007cbcc2dd8151  lea rcx, [rsp+0x30]
00007cbcc2dd8156  mov r8d, 0x00
00007cbcc2dd815c  lea r9, [r15+0x3A8]
00007cbcc2dd8163  movaps [rdi], xmm2
00007cbcc2dd8166  movaps [rsi], xmm14
00007cbcc2dd816a  movaps [rdx], xmm8
00007cbcc2dd816e  movaps [rcx], xmm5
00007cbcc2dd8171  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd817b  call rax
00007cbcc2dd817d  movaps xmm2, [rsp]
00007cbcc2dd8181  add rsp, 0x40
00007cbcc2dd8185  vmovaps xmm0, [rsp]
00007cbcc2dd818a  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd8190  vmovaps xmm3, [rsp+0x20]
00007cbcc2dd8196  vmovaps xmm4, [rsp+0x30]
00007cbcc2dd819c  vmovaps xmm5, [rsp+0x40]
00007cbcc2dd81a2  vmovaps xmm6, [rsp+0x50]
00007cbcc2dd81a8  vmovaps xmm7, [rsp+0x60]
00007cbcc2dd81ae  vmovaps xmm8, [rsp+0x70]
00007cbcc2dd81b4  vmovaps xmm9, [rsp+0x80]
00007cbcc2dd81bd  vmovaps xmm10, [rsp+0x90]
00007cbcc2dd81c6  vmovaps xmm11, [rsp+0xA0]
00007cbcc2dd81cf  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd81d8  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd81e1  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd81ea  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd81f3  add rsp, 0xF0
00007cbcc2dd81fa  pop r11
00007cbcc2dd81fc  pop r10
00007cbcc2dd81fe  pop r9
00007cbcc2dd8200  pop r8
00007cbcc2dd8202  pop rsi
00007cbcc2dd8203  pop rdi
00007cbcc2dd8204  pop rdx
00007cbcc2dd8205  pop rcx
00007cbcc2dd8206  pop rax
00007cbcc2dd8207  add rsp, 0x08
00007cbcc2dd820b  jmp 0x00007CBCC2DD6FF7
00007cbcc2dd8210  sub rsp, 0x08
00007cbcc2dd8214  push rax
00007cbcc2dd8215  push rcx
00007cbcc2dd8216  push rdx
00007cbcc2dd8217  push rdi
00007cbcc2dd8218  push rsi
00007cbcc2dd8219  push r8
00007cbcc2dd821b  push r9
00007cbcc2dd821d  push r10
00007cbcc2dd821f  push r11
00007cbcc2dd8221  sub rsp, 0xF0
00007cbcc2dd8228  vmovaps [rsp], xmm0
00007cbcc2dd822d  vmovaps [rsp+0x10], xmm1
00007cbcc2dd8233  vmovaps [rsp+0x20], xmm2
00007cbcc2dd8239  vmovaps [rsp+0x30], xmm3
00007cbcc2dd823f  vmovaps [rsp+0x40], xmm4
00007cbcc2dd8245  vmovaps [rsp+0x50], xmm6
00007cbcc2dd824b  vmovaps [rsp+0x60], xmm7
00007cbcc2dd8251  vmovaps [rsp+0x70], xmm8
00007cbcc2dd8257  vmovaps [rsp+0x80], xmm9
00007cbcc2dd8260  vmovaps [rsp+0x90], xmm10
00007cbcc2dd8269  vmovaps [rsp+0xA0], xmm11
00007cbcc2dd8272  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd827b  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd8284  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd828d  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd8296  sub rsp, 0x40
00007cbcc2dd829a  lea rdi, [rsp]
00007cbcc2dd829e  lea rsi, [rsp+0x10]
00007cbcc2dd82a3  lea rdx, [rsp+0x20]
00007cbcc2dd82a8  lea rcx, [rsp+0x30]
00007cbcc2dd82ad  mov r8d, 0x00
00007cbcc2dd82b3  lea r9, [r15+0x3A8]
00007cbcc2dd82ba  movaps [rdi], xmm5
00007cbcc2dd82bd  movaps [rsi], xmm14
00007cbcc2dd82c1  movaps [rdx], xmm8
00007cbcc2dd82c5  movaps [rcx], xmm1
00007cbcc2dd82c8  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd82d2  call rax
00007cbcc2dd82d4  movaps xmm5, [rsp]
00007cbcc2dd82d8  add rsp, 0x40
00007cbcc2dd82dc  vmovaps xmm0, [rsp]
00007cbcc2dd82e1  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd82e7  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd82ed  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd82f3  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd82f9  vmovaps xmm6, [rsp+0x50]
00007cbcc2dd82ff  vmovaps xmm7, [rsp+0x60]
00007cbcc2dd8305  vmovaps xmm8, [rsp+0x70]
00007cbcc2dd830b  vmovaps xmm9, [rsp+0x80]
00007cbcc2dd8314  vmovaps xmm10, [rsp+0x90]
00007cbcc2dd831d  vmovaps xmm11, [rsp+0xA0]
00007cbcc2dd8326  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd832f  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd8338  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd8341  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd834a  add rsp, 0xF0
00007cbcc2dd8351  pop r11
00007cbcc2dd8353  pop r10
00007cbcc2dd8355  pop r9
00007cbcc2dd8357  pop r8
00007cbcc2dd8359  pop rsi
00007cbcc2dd835a  pop rdi
00007cbcc2dd835b  pop rdx
00007cbcc2dd835c  pop rcx
00007cbcc2dd835d  pop rax
00007cbcc2dd835e  add rsp, 0x08
00007cbcc2dd8362  jmp 0x00007CBCC2DD7034
00007cbcc2dd8367  sub rsp, 0x08
00007cbcc2dd836b  push rax
00007cbcc2dd836c  push rcx
00007cbcc2dd836d  push rdx
00007cbcc2dd836e  push rdi
00007cbcc2dd836f  push rsi
00007cbcc2dd8370  push r8
00007cbcc2dd8372  push r9
00007cbcc2dd8374  push r10
00007cbcc2dd8376  push r11
00007cbcc2dd8378  sub rsp, 0xF0
00007cbcc2dd837f  vmovaps [rsp], xmm0
00007cbcc2dd8384  vmovaps [rsp+0x10], xmm1
00007cbcc2dd838a  vmovaps [rsp+0x20], xmm2
00007cbcc2dd8390  vmovaps [rsp+0x30], xmm3
00007cbcc2dd8396  vmovaps [rsp+0x40], xmm4
00007cbcc2dd839c  vmovaps [rsp+0x50], xmm5
00007cbcc2dd83a2  vmovaps [rsp+0x60], xmm6
00007cbcc2dd83a8  vmovaps [rsp+0x70], xmm7
00007cbcc2dd83ae  vmovaps [rsp+0x80], xmm8
00007cbcc2dd83b7  vmovaps [rsp+0x90], xmm9
00007cbcc2dd83c0  vmovaps [rsp+0xA0], xmm10
00007cbcc2dd83c9  vmovaps [rsp+0xB0], xmm11
00007cbcc2dd83d2  vmovaps [rsp+0xC0], xmm12
00007cbcc2dd83db  vmovaps [rsp+0xD0], xmm13
00007cbcc2dd83e4  vmovaps [rsp+0xE0], xmm14
00007cbcc2dd83ed  sub rsp, 0x40
00007cbcc2dd83f1  lea rdi, [rsp]
00007cbcc2dd83f5  lea rsi, [rsp+0x10]
00007cbcc2dd83fa  lea rdx, [rsp+0x20]
00007cbcc2dd83ff  lea rcx, [rsp+0x30]
00007cbcc2dd8404  mov r8d, 0x00
00007cbcc2dd840a  lea r9, [r15+0x3A8]
00007cbcc2dd8411  movaps [rdi], xmm15
00007cbcc2dd8415  movaps [rsi], xmm13
00007cbcc2dd8419  movaps [rdx], xmm14
00007cbcc2dd841d  movaps [rcx], xmm1
00007cbcc2dd8420  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd842a  call rax
00007cbcc2dd842c  movaps xmm15, [rsp]
00007cbcc2dd8431  add rsp, 0x40
00007cbcc2dd8435  vmovaps xmm0, [rsp]
00007cbcc2dd843a  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd8440  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd8446  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd844c  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd8452  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd8458  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd845e  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd8464  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd846d  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd8476  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dd847f  vmovaps xmm11, [rsp+0xB0]
00007cbcc2dd8488  vmovaps xmm12, [rsp+0xC0]
00007cbcc2dd8491  vmovaps xmm13, [rsp+0xD0]
00007cbcc2dd849a  vmovaps xmm14, [rsp+0xE0]
00007cbcc2dd84a3  add rsp, 0xF0
00007cbcc2dd84aa  pop r11
00007cbcc2dd84ac  pop r10
00007cbcc2dd84ae  pop r9
00007cbcc2dd84b0  pop r8
00007cbcc2dd84b2  pop rsi
00007cbcc2dd84b3  pop rdi
00007cbcc2dd84b4  pop rdx
00007cbcc2dd84b5  pop rcx
00007cbcc2dd84b6  pop rax
00007cbcc2dd84b7  add rsp, 0x08
00007cbcc2dd84bb  jmp 0x00007CBCC2DD7063
00007cbcc2dd84c0  sub rsp, 0x08
00007cbcc2dd84c4  push rax
00007cbcc2dd84c5  push rcx
00007cbcc2dd84c6  push rdx
00007cbcc2dd84c7  push rdi
00007cbcc2dd84c8  push rsi
00007cbcc2dd84c9  push r8
00007cbcc2dd84cb  push r9
00007cbcc2dd84cd  push r10
00007cbcc2dd84cf  push r11
00007cbcc2dd84d1  sub rsp, 0xF0
00007cbcc2dd84d8  vmovaps [rsp], xmm0
00007cbcc2dd84dd  vmovaps [rsp+0x10], xmm1
00007cbcc2dd84e3  vmovaps [rsp+0x20], xmm2
00007cbcc2dd84e9  vmovaps [rsp+0x30], xmm3
00007cbcc2dd84ef  vmovaps [rsp+0x40], xmm4
00007cbcc2dd84f5  vmovaps [rsp+0x50], xmm5
00007cbcc2dd84fb  vmovaps [rsp+0x60], xmm6
00007cbcc2dd8501  vmovaps [rsp+0x70], xmm7
00007cbcc2dd8507  vmovaps [rsp+0x80], xmm8
00007cbcc2dd8510  vmovaps [rsp+0x90], xmm9
00007cbcc2dd8519  vmovaps [rsp+0xA0], xmm10
00007cbcc2dd8522  vmovaps [rsp+0xB0], xmm11
00007cbcc2dd852b  vmovaps [rsp+0xC0], xmm12
00007cbcc2dd8534  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd853d  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd8546  sub rsp, 0x40
00007cbcc2dd854a  lea rdi, [rsp]
00007cbcc2dd854e  lea rsi, [rsp+0x10]
00007cbcc2dd8553  lea rdx, [rsp+0x20]
00007cbcc2dd8558  lea rcx, [rsp+0x30]
00007cbcc2dd855d  mov r8d, 0x00
00007cbcc2dd8563  lea r9, [r15+0x3A8]
00007cbcc2dd856a  movaps [rdi], xmm13
00007cbcc2dd856e  movaps [rsi], xmm12
00007cbcc2dd8572  movaps [rdx], xmm14
00007cbcc2dd8576  movaps [rcx], xmm1
00007cbcc2dd8579  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd8583  call rax
00007cbcc2dd8585  movaps xmm13, [rsp]
00007cbcc2dd858a  add rsp, 0x40
00007cbcc2dd858e  vmovaps xmm0, [rsp]
00007cbcc2dd8593  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd8599  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd859f  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd85a5  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd85ab  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd85b1  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd85b7  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd85bd  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd85c6  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd85cf  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dd85d8  vmovaps xmm11, [rsp+0xB0]
00007cbcc2dd85e1  vmovaps xmm12, [rsp+0xC0]
00007cbcc2dd85ea  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd85f3  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd85fc  add rsp, 0xF0
00007cbcc2dd8603  pop r11
00007cbcc2dd8605  pop r10
00007cbcc2dd8607  pop r9
00007cbcc2dd8609  pop r8
00007cbcc2dd860b  pop rsi
00007cbcc2dd860c  pop rdi
00007cbcc2dd860d  pop rdx
00007cbcc2dd860e  pop rcx
00007cbcc2dd860f  pop rax
00007cbcc2dd8610  add rsp, 0x08
00007cbcc2dd8614  jmp 0x00007CBCC2DD7095
00007cbcc2dd8619  sub rsp, 0x08
00007cbcc2dd861d  push rax
00007cbcc2dd861e  push rcx
00007cbcc2dd861f  push rdx
00007cbcc2dd8620  push rdi
00007cbcc2dd8621  push rsi
00007cbcc2dd8622  push r8
00007cbcc2dd8624  push r9
00007cbcc2dd8626  push r10
00007cbcc2dd8628  push r11
00007cbcc2dd862a  sub rsp, 0xF0
00007cbcc2dd8631  vmovaps [rsp], xmm0
00007cbcc2dd8636  vmovaps [rsp+0x10], xmm1
00007cbcc2dd863c  vmovaps [rsp+0x20], xmm2
00007cbcc2dd8642  vmovaps [rsp+0x30], xmm3
00007cbcc2dd8648  vmovaps [rsp+0x40], xmm4
00007cbcc2dd864e  vmovaps [rsp+0x50], xmm5
00007cbcc2dd8654  vmovaps [rsp+0x60], xmm6
00007cbcc2dd865a  vmovaps [rsp+0x70], xmm7
00007cbcc2dd8660  vmovaps [rsp+0x80], xmm8
00007cbcc2dd8669  vmovaps [rsp+0x90], xmm9
00007cbcc2dd8672  vmovaps [rsp+0xA0], xmm10
00007cbcc2dd867b  vmovaps [rsp+0xB0], xmm11
00007cbcc2dd8684  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd868d  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd8696  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd869f  sub rsp, 0x40
00007cbcc2dd86a3  lea rdi, [rsp]
00007cbcc2dd86a7  lea rsi, [rsp+0x10]
00007cbcc2dd86ac  lea rdx, [rsp+0x20]
00007cbcc2dd86b1  lea rcx, [rsp+0x30]
00007cbcc2dd86b6  mov r8d, 0x00
00007cbcc2dd86bc  lea r9, [r15+0x3A8]
00007cbcc2dd86c3  movaps [rdi], xmm12
00007cbcc2dd86c7  movaps [rsi], xmm5
00007cbcc2dd86ca  movaps [rdx], xmm14
00007cbcc2dd86ce  movaps [rcx], xmm4
00007cbcc2dd86d1  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd86db  call rax
00007cbcc2dd86dd  movaps xmm12, [rsp]
00007cbcc2dd86e2  add rsp, 0x40
00007cbcc2dd86e6  vmovaps xmm0, [rsp]
00007cbcc2dd86eb  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd86f1  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd86f7  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd86fd  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd8703  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd8709  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd870f  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd8715  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd871e  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd8727  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dd8730  vmovaps xmm11, [rsp+0xB0]
00007cbcc2dd8739  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd8742  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd874b  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd8754  add rsp, 0xF0
00007cbcc2dd875b  pop r11
00007cbcc2dd875d  pop r10
00007cbcc2dd875f  pop r9
00007cbcc2dd8761  pop r8
00007cbcc2dd8763  pop rsi
00007cbcc2dd8764  pop rdi
00007cbcc2dd8765  pop rdx
00007cbcc2dd8766  pop rcx
00007cbcc2dd8767  pop rax
00007cbcc2dd8768  add rsp, 0x08
00007cbcc2dd876c  jmp 0x00007CBCC2DD710B
00007cbcc2dd8771  sub rsp, 0x08
00007cbcc2dd8775  push rax
00007cbcc2dd8776  push rcx
00007cbcc2dd8777  push rdx
00007cbcc2dd8778  push rdi
00007cbcc2dd8779  push rsi
00007cbcc2dd877a  push r8
00007cbcc2dd877c  push r9
00007cbcc2dd877e  push r10
00007cbcc2dd8780  push r11
00007cbcc2dd8782  sub rsp, 0xF0
00007cbcc2dd8789  vmovaps [rsp], xmm0
00007cbcc2dd878e  vmovaps [rsp+0x10], xmm1
00007cbcc2dd8794  vmovaps [rsp+0x20], xmm2
00007cbcc2dd879a  vmovaps [rsp+0x30], xmm3
00007cbcc2dd87a0  vmovaps [rsp+0x40], xmm4
00007cbcc2dd87a6  vmovaps [rsp+0x50], xmm5
00007cbcc2dd87ac  vmovaps [rsp+0x60], xmm6
00007cbcc2dd87b2  vmovaps [rsp+0x70], xmm7
00007cbcc2dd87b8  vmovaps [rsp+0x80], xmm8
00007cbcc2dd87c1  vmovaps [rsp+0x90], xmm9
00007cbcc2dd87ca  vmovaps [rsp+0xA0], xmm11
00007cbcc2dd87d3  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd87dc  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd87e5  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd87ee  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd87f7  sub rsp, 0x40
00007cbcc2dd87fb  lea rdi, [rsp]
00007cbcc2dd87ff  lea rsi, [rsp+0x10]
00007cbcc2dd8804  lea rdx, [rsp+0x20]
00007cbcc2dd8809  lea rcx, [rsp+0x30]
00007cbcc2dd880e  mov r8d, 0x00
00007cbcc2dd8814  lea r9, [r15+0x3A8]
00007cbcc2dd881b  movaps [rdi], xmm10
00007cbcc2dd881f  movaps [rsi], xmm2
00007cbcc2dd8822  movaps [rdx], xmm6
00007cbcc2dd8825  movaps [rcx], xmm14
00007cbcc2dd8829  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd8833  call rax
00007cbcc2dd8835  movaps xmm10, [rsp]
00007cbcc2dd883a  add rsp, 0x40
00007cbcc2dd883e  vmovaps xmm0, [rsp]
00007cbcc2dd8843  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd8849  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd884f  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd8855  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd885b  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd8861  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd8867  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd886d  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd8876  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd887f  vmovaps xmm11, [rsp+0xA0]
00007cbcc2dd8888  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd8891  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd889a  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd88a3  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd88ac  add rsp, 0xF0
00007cbcc2dd88b3  pop r11
00007cbcc2dd88b5  pop r10
00007cbcc2dd88b7  pop r9
00007cbcc2dd88b9  pop r8
00007cbcc2dd88bb  pop rsi
00007cbcc2dd88bc  pop rdi
00007cbcc2dd88bd  pop rdx
00007cbcc2dd88be  pop rcx
00007cbcc2dd88bf  pop rax
00007cbcc2dd88c0  add rsp, 0x08
00007cbcc2dd88c4  jmp 0x00007CBCC2DD7131
00007cbcc2dd88c9  call 0x00007CBCC2C0D4E0
00007cbcc2dd88ce  jmp 0x00007CBCC2DD713E
00007cbcc2dd88d3  sub rsp, 0x08
00007cbcc2dd88d7  push rax
00007cbcc2dd88d8  push rcx
00007cbcc2dd88d9  push rdx
00007cbcc2dd88da  push rdi
00007cbcc2dd88db  push rsi
00007cbcc2dd88dc  push r8
00007cbcc2dd88de  push r9
00007cbcc2dd88e0  push r10
00007cbcc2dd88e2  push r11
00007cbcc2dd88e4  sub rsp, 0xF0
00007cbcc2dd88eb  vmovaps [rsp], xmm0
00007cbcc2dd88f0  vmovaps [rsp+0x10], xmm1
00007cbcc2dd88f6  vmovaps [rsp+0x20], xmm2
00007cbcc2dd88fc  vmovaps [rsp+0x30], xmm3
00007cbcc2dd8902  vmovaps [rsp+0x40], xmm4
00007cbcc2dd8908  vmovaps [rsp+0x50], xmm6
00007cbcc2dd890e  vmovaps [rsp+0x60], xmm7
00007cbcc2dd8914  vmovaps [rsp+0x70], xmm8
00007cbcc2dd891a  vmovaps [rsp+0x80], xmm9
00007cbcc2dd8923  vmovaps [rsp+0x90], xmm10
00007cbcc2dd892c  vmovaps [rsp+0xA0], xmm11
00007cbcc2dd8935  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd893e  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd8947  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd8950  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd8959  sub rsp, 0x40
00007cbcc2dd895d  lea rdi, [rsp]
00007cbcc2dd8961  lea rsi, [rsp+0x10]
00007cbcc2dd8966  lea rdx, [rsp+0x20]
00007cbcc2dd896b  lea rcx, [rsp+0x30]
00007cbcc2dd8970  mov r8d, 0x00
00007cbcc2dd8976  lea r9, [r15+0x3A8]
00007cbcc2dd897d  movaps [rdi], xmm5
00007cbcc2dd8980  movaps [rsi], xmm15
00007cbcc2dd8984  movaps [rdx], xmm6
00007cbcc2dd8987  movaps [rcx], xmm8
00007cbcc2dd898b  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd8995  call rax
00007cbcc2dd8997  movaps xmm5, [rsp]
00007cbcc2dd899b  add rsp, 0x40
00007cbcc2dd899f  vmovaps xmm0, [rsp]
00007cbcc2dd89a4  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd89aa  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd89b0  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd89b6  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd89bc  vmovaps xmm6, [rsp+0x50]
00007cbcc2dd89c2  vmovaps xmm7, [rsp+0x60]
00007cbcc2dd89c8  vmovaps xmm8, [rsp+0x70]
00007cbcc2dd89ce  vmovaps xmm9, [rsp+0x80]
00007cbcc2dd89d7  vmovaps xmm10, [rsp+0x90]
00007cbcc2dd89e0  vmovaps xmm11, [rsp+0xA0]
00007cbcc2dd89e9  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd89f2  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd89fb  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd8a04  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd8a0d  add rsp, 0xF0
00007cbcc2dd8a14  pop r11
00007cbcc2dd8a16  pop r10
00007cbcc2dd8a18  pop r9
00007cbcc2dd8a1a  pop r8
00007cbcc2dd8a1c  pop rsi
00007cbcc2dd8a1d  pop rdi
00007cbcc2dd8a1e  pop rdx
00007cbcc2dd8a1f  pop rcx
00007cbcc2dd8a20  pop rax
00007cbcc2dd8a21  add rsp, 0x08
00007cbcc2dd8a25  jmp 0x00007CBCC2DD7174
00007cbcc2dd8a2a  sub rsp, 0x08
00007cbcc2dd8a2e  push rax
00007cbcc2dd8a2f  push rcx
00007cbcc2dd8a30  push rdx
00007cbcc2dd8a31  push rdi
00007cbcc2dd8a32  push rsi
00007cbcc2dd8a33  push r8
00007cbcc2dd8a35  push r9
00007cbcc2dd8a37  push r10
00007cbcc2dd8a39  push r11
00007cbcc2dd8a3b  sub rsp, 0xF0
00007cbcc2dd8a42  vmovaps [rsp], xmm0
00007cbcc2dd8a47  vmovaps [rsp+0x10], xmm1
00007cbcc2dd8a4d  vmovaps [rsp+0x20], xmm2
00007cbcc2dd8a53  vmovaps [rsp+0x30], xmm3
00007cbcc2dd8a59  vmovaps [rsp+0x40], xmm4
00007cbcc2dd8a5f  vmovaps [rsp+0x50], xmm5
00007cbcc2dd8a65  vmovaps [rsp+0x60], xmm6
00007cbcc2dd8a6b  vmovaps [rsp+0x70], xmm7
00007cbcc2dd8a71  vmovaps [rsp+0x80], xmm9
00007cbcc2dd8a7a  vmovaps [rsp+0x90], xmm10
00007cbcc2dd8a83  vmovaps [rsp+0xA0], xmm11
00007cbcc2dd8a8c  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd8a95  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd8a9e  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd8aa7  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd8ab0  sub rsp, 0x40
00007cbcc2dd8ab4  lea rdi, [rsp]
00007cbcc2dd8ab8  lea rsi, [rsp+0x10]
00007cbcc2dd8abd  lea rdx, [rsp+0x20]
00007cbcc2dd8ac2  lea rcx, [rsp+0x30]
00007cbcc2dd8ac7  mov r8d, 0x00
00007cbcc2dd8acd  lea r9, [r15+0x3A8]
00007cbcc2dd8ad4  movaps [rdi], xmm8
00007cbcc2dd8ad8  movaps [rsi], xmm13
00007cbcc2dd8adc  movaps [rdx], xmm1
00007cbcc2dd8adf  movaps [rcx], xmm15
00007cbcc2dd8ae3  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd8aed  call rax
00007cbcc2dd8aef  movaps xmm8, [rsp]
00007cbcc2dd8af4  add rsp, 0x40
00007cbcc2dd8af8  vmovaps xmm0, [rsp]
00007cbcc2dd8afd  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd8b03  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd8b09  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd8b0f  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd8b15  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd8b1b  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd8b21  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd8b27  vmovaps xmm9, [rsp+0x80]
00007cbcc2dd8b30  vmovaps xmm10, [rsp+0x90]
00007cbcc2dd8b39  vmovaps xmm11, [rsp+0xA0]
00007cbcc2dd8b42  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd8b4b  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd8b54  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd8b5d  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd8b66  add rsp, 0xF0
00007cbcc2dd8b6d  pop r11
00007cbcc2dd8b6f  pop r10
00007cbcc2dd8b71  pop r9
00007cbcc2dd8b73  pop r8
00007cbcc2dd8b75  pop rsi
00007cbcc2dd8b76  pop rdi
00007cbcc2dd8b77  pop rdx
00007cbcc2dd8b78  pop rcx
00007cbcc2dd8b79  pop rax
00007cbcc2dd8b7a  add rsp, 0x08
00007cbcc2dd8b7e  jmp 0x00007CBCC2DD719A
00007cbcc2dd8b83  call 0x00007CBCC2C0E760
00007cbcc2dd8b88  jmp 0x00007CBCC2DD71BD
00007cbcc2dd8b8d  call 0x00007CBCC2C0C260
00007cbcc2dd8b92  jmp 0x00007CBCC2DD71C7
00007cbcc2dd8b97  sub rsp, 0x08
00007cbcc2dd8b9b  push rax
00007cbcc2dd8b9c  push rcx
00007cbcc2dd8b9d  push rdx
00007cbcc2dd8b9e  push rdi
00007cbcc2dd8b9f  push rsi
00007cbcc2dd8ba0  push r8
00007cbcc2dd8ba2  push r9
00007cbcc2dd8ba4  push r10
00007cbcc2dd8ba6  push r11
00007cbcc2dd8ba8  sub rsp, 0xF0
00007cbcc2dd8baf  vmovaps [rsp], xmm0
00007cbcc2dd8bb4  vmovaps [rsp+0x10], xmm1
00007cbcc2dd8bba  vmovaps [rsp+0x20], xmm2
00007cbcc2dd8bc0  vmovaps [rsp+0x30], xmm3
00007cbcc2dd8bc6  vmovaps [rsp+0x40], xmm5
00007cbcc2dd8bcc  vmovaps [rsp+0x50], xmm6
00007cbcc2dd8bd2  vmovaps [rsp+0x60], xmm7
00007cbcc2dd8bd8  vmovaps [rsp+0x70], xmm8
00007cbcc2dd8bde  vmovaps [rsp+0x80], xmm9
00007cbcc2dd8be7  vmovaps [rsp+0x90], xmm10
00007cbcc2dd8bf0  vmovaps [rsp+0xA0], xmm11
00007cbcc2dd8bf9  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd8c02  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd8c0b  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd8c14  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd8c1d  sub rsp, 0x40
00007cbcc2dd8c21  lea rdi, [rsp]
00007cbcc2dd8c25  lea rsi, [rsp+0x10]
00007cbcc2dd8c2a  lea rdx, [rsp+0x20]
00007cbcc2dd8c2f  lea rcx, [rsp+0x30]
00007cbcc2dd8c34  mov r8d, 0x00
00007cbcc2dd8c3a  lea r9, [r15+0x3A8]
00007cbcc2dd8c41  movaps [rdi], xmm4
00007cbcc2dd8c44  movaps [rsi], xmm12
00007cbcc2dd8c48  movaps [rdx], xmm9
00007cbcc2dd8c4c  movaps [rcx], xmm6
00007cbcc2dd8c4f  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd8c59  call rax
00007cbcc2dd8c5b  movaps xmm4, [rsp]
00007cbcc2dd8c5f  add rsp, 0x40
00007cbcc2dd8c63  vmovaps xmm0, [rsp]
00007cbcc2dd8c68  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd8c6e  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd8c74  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd8c7a  vmovaps xmm5, [rsp+0x40]
00007cbcc2dd8c80  vmovaps xmm6, [rsp+0x50]
00007cbcc2dd8c86  vmovaps xmm7, [rsp+0x60]
00007cbcc2dd8c8c  vmovaps xmm8, [rsp+0x70]
00007cbcc2dd8c92  vmovaps xmm9, [rsp+0x80]
00007cbcc2dd8c9b  vmovaps xmm10, [rsp+0x90]
00007cbcc2dd8ca4  vmovaps xmm11, [rsp+0xA0]
00007cbcc2dd8cad  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd8cb6  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd8cbf  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd8cc8  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd8cd1  add rsp, 0xF0
00007cbcc2dd8cd8  pop r11
00007cbcc2dd8cda  pop r10
00007cbcc2dd8cdc  pop r9
00007cbcc2dd8cde  pop r8
00007cbcc2dd8ce0  pop rsi
00007cbcc2dd8ce1  pop rdi
00007cbcc2dd8ce2  pop rdx
00007cbcc2dd8ce3  pop rcx
00007cbcc2dd8ce4  pop rax
00007cbcc2dd8ce5  add rsp, 0x08
00007cbcc2dd8ce9  jmp 0x00007CBCC2DD71FF
00007cbcc2dd8cee  sub rsp, 0x08
00007cbcc2dd8cf2  push rax
00007cbcc2dd8cf3  push rcx
00007cbcc2dd8cf4  push rdx
00007cbcc2dd8cf5  push rdi
00007cbcc2dd8cf6  push rsi
00007cbcc2dd8cf7  push r8
00007cbcc2dd8cf9  push r9
00007cbcc2dd8cfb  push r10
00007cbcc2dd8cfd  push r11
00007cbcc2dd8cff  sub rsp, 0xF0
00007cbcc2dd8d06  vmovaps [rsp], xmm0
00007cbcc2dd8d0b  vmovaps [rsp+0x10], xmm1
00007cbcc2dd8d11  vmovaps [rsp+0x20], xmm2
00007cbcc2dd8d17  vmovaps [rsp+0x30], xmm3
00007cbcc2dd8d1d  vmovaps [rsp+0x40], xmm4
00007cbcc2dd8d23  vmovaps [rsp+0x50], xmm5
00007cbcc2dd8d29  vmovaps [rsp+0x60], xmm6
00007cbcc2dd8d2f  vmovaps [rsp+0x70], xmm7
00007cbcc2dd8d35  vmovaps [rsp+0x80], xmm8
00007cbcc2dd8d3e  vmovaps [rsp+0x90], xmm10
00007cbcc2dd8d47  vmovaps [rsp+0xA0], xmm11
00007cbcc2dd8d50  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd8d59  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd8d62  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd8d6b  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd8d74  sub rsp, 0x40
00007cbcc2dd8d78  lea rdi, [rsp]
00007cbcc2dd8d7c  lea rsi, [rsp+0x10]
00007cbcc2dd8d81  lea rdx, [rsp+0x20]
00007cbcc2dd8d86  lea rcx, [rsp+0x30]
00007cbcc2dd8d8b  mov r8d, 0x00
00007cbcc2dd8d91  lea r9, [r15+0x3A8]
00007cbcc2dd8d98  movaps [rdi], xmm9
00007cbcc2dd8d9c  movaps [rsi], xmm10
00007cbcc2dd8da0  movaps [rdx], xmm1
00007cbcc2dd8da3  movaps [rcx], xmm12
00007cbcc2dd8da7  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd8db1  call rax
00007cbcc2dd8db3  movaps xmm9, [rsp]
00007cbcc2dd8db8  add rsp, 0x40
00007cbcc2dd8dbc  vmovaps xmm0, [rsp]
00007cbcc2dd8dc1  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd8dc7  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd8dcd  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd8dd3  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd8dd9  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd8ddf  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd8de5  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd8deb  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd8df4  vmovaps xmm10, [rsp+0x90]
00007cbcc2dd8dfd  vmovaps xmm11, [rsp+0xA0]
00007cbcc2dd8e06  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd8e0f  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd8e18  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd8e21  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd8e2a  add rsp, 0xF0
00007cbcc2dd8e31  pop r11
00007cbcc2dd8e33  pop r10
00007cbcc2dd8e35  pop r9
00007cbcc2dd8e37  pop r8
00007cbcc2dd8e39  pop rsi
00007cbcc2dd8e3a  pop rdi
00007cbcc2dd8e3b  pop rdx
00007cbcc2dd8e3c  pop rcx
00007cbcc2dd8e3d  pop rax
00007cbcc2dd8e3e  add rsp, 0x08
00007cbcc2dd8e42  jmp 0x00007CBCC2DD7228
00007cbcc2dd8e47  sub rsp, 0x08
00007cbcc2dd8e4b  push rax
00007cbcc2dd8e4c  push rcx
00007cbcc2dd8e4d  push rdx
00007cbcc2dd8e4e  push rdi
00007cbcc2dd8e4f  push rsi
00007cbcc2dd8e50  push r8
00007cbcc2dd8e52  push r9
00007cbcc2dd8e54  push r10
00007cbcc2dd8e56  push r11
00007cbcc2dd8e58  sub rsp, 0xF0
00007cbcc2dd8e5f  vmovaps [rsp], xmm0
00007cbcc2dd8e64  vmovaps [rsp+0x10], xmm1
00007cbcc2dd8e6a  vmovaps [rsp+0x20], xmm2
00007cbcc2dd8e70  vmovaps [rsp+0x30], xmm3
00007cbcc2dd8e76  vmovaps [rsp+0x40], xmm4
00007cbcc2dd8e7c  vmovaps [rsp+0x50], xmm5
00007cbcc2dd8e82  vmovaps [rsp+0x60], xmm6
00007cbcc2dd8e88  vmovaps [rsp+0x70], xmm7
00007cbcc2dd8e8e  vmovaps [rsp+0x80], xmm8
00007cbcc2dd8e97  vmovaps [rsp+0x90], xmm9
00007cbcc2dd8ea0  vmovaps [rsp+0xA0], xmm11
00007cbcc2dd8ea9  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd8eb2  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd8ebb  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd8ec4  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd8ecd  sub rsp, 0x40
00007cbcc2dd8ed1  lea rdi, [rsp]
00007cbcc2dd8ed5  lea rsi, [rsp+0x10]
00007cbcc2dd8eda  lea rdx, [rsp+0x20]
00007cbcc2dd8edf  lea rcx, [rsp+0x30]
00007cbcc2dd8ee4  mov r8d, 0x00
00007cbcc2dd8eea  lea r9, [r15+0x3A8]
00007cbcc2dd8ef1  movaps [rdi], xmm10
00007cbcc2dd8ef5  movaps [rsi], xmm5
00007cbcc2dd8ef8  movaps [rdx], xmm12
00007cbcc2dd8efc  movaps [rcx], xmm1
00007cbcc2dd8eff  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd8f09  call rax
00007cbcc2dd8f0b  movaps xmm10, [rsp]
00007cbcc2dd8f10  add rsp, 0x40
00007cbcc2dd8f14  vmovaps xmm0, [rsp]
00007cbcc2dd8f19  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd8f1f  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd8f25  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd8f2b  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd8f31  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd8f37  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd8f3d  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd8f43  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd8f4c  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd8f55  vmovaps xmm11, [rsp+0xA0]
00007cbcc2dd8f5e  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd8f67  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd8f70  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd8f79  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd8f82  add rsp, 0xF0
00007cbcc2dd8f89  pop r11
00007cbcc2dd8f8b  pop r10
00007cbcc2dd8f8d  pop r9
00007cbcc2dd8f8f  pop r8
00007cbcc2dd8f91  pop rsi
00007cbcc2dd8f92  pop rdi
00007cbcc2dd8f93  pop rdx
00007cbcc2dd8f94  pop rcx
00007cbcc2dd8f95  pop rax
00007cbcc2dd8f96  add rsp, 0x08
00007cbcc2dd8f9a  jmp 0x00007CBCC2DD7257
00007cbcc2dd8f9f  sub rsp, 0x08
00007cbcc2dd8fa3  push rax
00007cbcc2dd8fa4  push rcx
00007cbcc2dd8fa5  push rdx
00007cbcc2dd8fa6  push rdi
00007cbcc2dd8fa7  push rsi
00007cbcc2dd8fa8  push r8
00007cbcc2dd8faa  push r9
00007cbcc2dd8fac  push r10
00007cbcc2dd8fae  push r11
00007cbcc2dd8fb0  sub rsp, 0xF0
00007cbcc2dd8fb7  vmovaps [rsp], xmm0
00007cbcc2dd8fbc  vmovaps [rsp+0x10], xmm1
00007cbcc2dd8fc2  vmovaps [rsp+0x20], xmm2
00007cbcc2dd8fc8  vmovaps [rsp+0x30], xmm3
00007cbcc2dd8fce  vmovaps [rsp+0x40], xmm4
00007cbcc2dd8fd4  vmovaps [rsp+0x50], xmm5
00007cbcc2dd8fda  vmovaps [rsp+0x60], xmm7
00007cbcc2dd8fe0  vmovaps [rsp+0x70], xmm8
00007cbcc2dd8fe6  vmovaps [rsp+0x80], xmm9
00007cbcc2dd8fef  vmovaps [rsp+0x90], xmm10
00007cbcc2dd8ff8  vmovaps [rsp+0xA0], xmm11
00007cbcc2dd9001  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd900a  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd9013  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd901c  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd9025  sub rsp, 0x40
00007cbcc2dd9029  lea rdi, [rsp]
00007cbcc2dd902d  lea rsi, [rsp+0x10]
00007cbcc2dd9032  lea rdx, [rsp+0x20]
00007cbcc2dd9037  lea rcx, [rsp+0x30]
00007cbcc2dd903c  mov r8d, 0x00
00007cbcc2dd9042  lea r9, [r15+0x3A8]
00007cbcc2dd9049  movaps [rdi], xmm6
00007cbcc2dd904c  movaps [rsi], xmm8
00007cbcc2dd9050  movaps [rdx], xmm12
00007cbcc2dd9054  movaps [rcx], xmm1
00007cbcc2dd9057  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd9061  call rax
00007cbcc2dd9063  movaps xmm6, [rsp]
00007cbcc2dd9067  add rsp, 0x40
00007cbcc2dd906b  vmovaps xmm0, [rsp]
00007cbcc2dd9070  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd9076  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd907c  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd9082  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd9088  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd908e  vmovaps xmm7, [rsp+0x60]
00007cbcc2dd9094  vmovaps xmm8, [rsp+0x70]
00007cbcc2dd909a  vmovaps xmm9, [rsp+0x80]
00007cbcc2dd90a3  vmovaps xmm10, [rsp+0x90]
00007cbcc2dd90ac  vmovaps xmm11, [rsp+0xA0]
00007cbcc2dd90b5  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd90be  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd90c7  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd90d0  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd90d9  add rsp, 0xF0
00007cbcc2dd90e0  pop r11
00007cbcc2dd90e2  pop r10
00007cbcc2dd90e4  pop r9
00007cbcc2dd90e6  pop r8
00007cbcc2dd90e8  pop rsi
00007cbcc2dd90e9  pop rdi
00007cbcc2dd90ea  pop rdx
00007cbcc2dd90eb  pop rcx
00007cbcc2dd90ec  pop rax
00007cbcc2dd90ed  add rsp, 0x08
00007cbcc2dd90f1  jmp 0x00007CBCC2DD7285
00007cbcc2dd90f6  call 0x00007CBCC2BFF430
00007cbcc2dd90fb  jmp 0x00007CBCC2DD728F
00007cbcc2dd9100  call 0x00007CBCC2C0AFE0
00007cbcc2dd9105  jmp 0x00007CBCC2DD7299
00007cbcc2dd910a  sub rsp, 0x08
00007cbcc2dd910e  push rax
00007cbcc2dd910f  push rcx
00007cbcc2dd9110  push rdx
00007cbcc2dd9111  push rdi
00007cbcc2dd9112  push rsi
00007cbcc2dd9113  push r8
00007cbcc2dd9115  push r9
00007cbcc2dd9117  push r10
00007cbcc2dd9119  push r11
00007cbcc2dd911b  sub rsp, 0xF0
00007cbcc2dd9122  vmovaps [rsp], xmm0
00007cbcc2dd9127  vmovaps [rsp+0x10], xmm1
00007cbcc2dd912d  vmovaps [rsp+0x20], xmm2
00007cbcc2dd9133  vmovaps [rsp+0x30], xmm3
00007cbcc2dd9139  vmovaps [rsp+0x40], xmm4
00007cbcc2dd913f  vmovaps [rsp+0x50], xmm5
00007cbcc2dd9145  vmovaps [rsp+0x60], xmm6
00007cbcc2dd914b  vmovaps [rsp+0x70], xmm7
00007cbcc2dd9151  vmovaps [rsp+0x80], xmm9
00007cbcc2dd915a  vmovaps [rsp+0x90], xmm10
00007cbcc2dd9163  vmovaps [rsp+0xA0], xmm11
00007cbcc2dd916c  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd9175  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd917e  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd9187  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd9190  sub rsp, 0x40
00007cbcc2dd9194  lea rdi, [rsp]
00007cbcc2dd9198  lea rsi, [rsp+0x10]
00007cbcc2dd919d  lea rdx, [rsp+0x20]
00007cbcc2dd91a2  lea rcx, [rsp+0x30]
00007cbcc2dd91a7  mov r8d, 0x00
00007cbcc2dd91ad  lea r9, [r15+0x3A8]
00007cbcc2dd91b4  movaps [rdi], xmm8
00007cbcc2dd91b8  movaps [rsi], xmm4
00007cbcc2dd91bb  movaps [rdx], xmm13
00007cbcc2dd91bf  movaps [rcx], xmm11
00007cbcc2dd91c3  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd91cd  call rax
00007cbcc2dd91cf  movaps xmm8, [rsp]
00007cbcc2dd91d4  add rsp, 0x40
00007cbcc2dd91d8  vmovaps xmm0, [rsp]
00007cbcc2dd91dd  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd91e3  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd91e9  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd91ef  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd91f5  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd91fb  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd9201  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd9207  vmovaps xmm9, [rsp+0x80]
00007cbcc2dd9210  vmovaps xmm10, [rsp+0x90]
00007cbcc2dd9219  vmovaps xmm11, [rsp+0xA0]
00007cbcc2dd9222  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd922b  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd9234  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd923d  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd9246  add rsp, 0xF0
00007cbcc2dd924d  pop r11
00007cbcc2dd924f  pop r10
00007cbcc2dd9251  pop r9
00007cbcc2dd9253  pop r8
00007cbcc2dd9255  pop rsi
00007cbcc2dd9256  pop rdi
00007cbcc2dd9257  pop rdx
00007cbcc2dd9258  pop rcx
00007cbcc2dd9259  pop rax
00007cbcc2dd925a  add rsp, 0x08
00007cbcc2dd925e  jmp 0x00007CBCC2DD72CF
00007cbcc2dd9263  sub rsp, 0x08
00007cbcc2dd9267  push rax
00007cbcc2dd9268  push rcx
00007cbcc2dd9269  push rdx
00007cbcc2dd926a  push rdi
00007cbcc2dd926b  push rsi
00007cbcc2dd926c  push r8
00007cbcc2dd926e  push r9
00007cbcc2dd9270  push r10
00007cbcc2dd9272  push r11
00007cbcc2dd9274  sub rsp, 0xF0
00007cbcc2dd927b  vmovaps [rsp], xmm0
00007cbcc2dd9280  vmovaps [rsp+0x10], xmm1
00007cbcc2dd9286  vmovaps [rsp+0x20], xmm2
00007cbcc2dd928c  vmovaps [rsp+0x30], xmm3
00007cbcc2dd9292  vmovaps [rsp+0x40], xmm4
00007cbcc2dd9298  vmovaps [rsp+0x50], xmm5
00007cbcc2dd929e  vmovaps [rsp+0x60], xmm6
00007cbcc2dd92a4  vmovaps [rsp+0x70], xmm7
00007cbcc2dd92aa  vmovaps [rsp+0x80], xmm8
00007cbcc2dd92b3  vmovaps [rsp+0x90], xmm9
00007cbcc2dd92bc  vmovaps [rsp+0xA0], xmm10
00007cbcc2dd92c5  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd92ce  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd92d7  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd92e0  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd92e9  sub rsp, 0x40
00007cbcc2dd92ed  lea rdi, [rsp]
00007cbcc2dd92f1  lea rsi, [rsp+0x10]
00007cbcc2dd92f6  lea rdx, [rsp+0x20]
00007cbcc2dd92fb  lea rcx, [rsp+0x30]
00007cbcc2dd9300  mov r8d, 0x00
00007cbcc2dd9306  lea r9, [r15+0x3A8]
00007cbcc2dd930d  movaps [rdi], xmm11
00007cbcc2dd9311  movaps [rsi], xmm9
00007cbcc2dd9315  movaps [rdx], xmm1
00007cbcc2dd9318  movaps [rcx], xmm13
00007cbcc2dd931c  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd9326  call rax
00007cbcc2dd9328  movaps xmm11, [rsp]
00007cbcc2dd932d  add rsp, 0x40
00007cbcc2dd9331  vmovaps xmm0, [rsp]
00007cbcc2dd9336  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd933c  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd9342  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd9348  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd934e  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd9354  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd935a  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd9360  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd9369  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd9372  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dd937b  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd9384  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd938d  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd9396  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd939f  add rsp, 0xF0
00007cbcc2dd93a6  pop r11
00007cbcc2dd93a8  pop r10
00007cbcc2dd93aa  pop r9
00007cbcc2dd93ac  pop r8
00007cbcc2dd93ae  pop rsi
00007cbcc2dd93af  pop rdi
00007cbcc2dd93b0  pop rdx
00007cbcc2dd93b1  pop rcx
00007cbcc2dd93b2  pop rax
00007cbcc2dd93b3  add rsp, 0x08
00007cbcc2dd93b7  jmp 0x00007CBCC2DD72F5
00007cbcc2dd93bc  sub rsp, 0x08
00007cbcc2dd93c0  push rax
00007cbcc2dd93c1  push rcx
00007cbcc2dd93c2  push rdx
00007cbcc2dd93c3  push rdi
00007cbcc2dd93c4  push rsi
00007cbcc2dd93c5  push r8
00007cbcc2dd93c7  push r9
00007cbcc2dd93c9  push r10
00007cbcc2dd93cb  push r11
00007cbcc2dd93cd  sub rsp, 0xF0
00007cbcc2dd93d4  vmovaps [rsp], xmm0
00007cbcc2dd93d9  vmovaps [rsp+0x10], xmm1
00007cbcc2dd93df  vmovaps [rsp+0x20], xmm2
00007cbcc2dd93e5  vmovaps [rsp+0x30], xmm3
00007cbcc2dd93eb  vmovaps [rsp+0x40], xmm4
00007cbcc2dd93f1  vmovaps [rsp+0x50], xmm5
00007cbcc2dd93f7  vmovaps [rsp+0x60], xmm6
00007cbcc2dd93fd  vmovaps [rsp+0x70], xmm7
00007cbcc2dd9403  vmovaps [rsp+0x80], xmm8
00007cbcc2dd940c  vmovaps [rsp+0x90], xmm9
00007cbcc2dd9415  vmovaps [rsp+0xA0], xmm10
00007cbcc2dd941e  vmovaps [rsp+0xB0], xmm11
00007cbcc2dd9427  vmovaps [rsp+0xC0], xmm12
00007cbcc2dd9430  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd9439  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd9442  sub rsp, 0x40
00007cbcc2dd9446  lea rdi, [rsp]
00007cbcc2dd944a  lea rsi, [rsp+0x10]
00007cbcc2dd944f  lea rdx, [rsp+0x20]
00007cbcc2dd9454  lea rcx, [rsp+0x30]
00007cbcc2dd9459  mov r8d, 0x00
00007cbcc2dd945f  lea r9, [r15+0x3A8]
00007cbcc2dd9466  movaps [rdi], xmm13
00007cbcc2dd946a  movaps [rsi], xmm10
00007cbcc2dd946e  movaps [rdx], xmm7
00007cbcc2dd9471  movaps [rcx], xmm1
00007cbcc2dd9474  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd947e  call rax
00007cbcc2dd9480  movaps xmm13, [rsp]
00007cbcc2dd9485  add rsp, 0x40
00007cbcc2dd9489  vmovaps xmm0, [rsp]
00007cbcc2dd948e  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd9494  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd949a  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd94a0  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd94a6  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd94ac  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd94b2  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd94b8  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd94c1  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd94ca  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dd94d3  vmovaps xmm11, [rsp+0xB0]
00007cbcc2dd94dc  vmovaps xmm12, [rsp+0xC0]
00007cbcc2dd94e5  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd94ee  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd94f7  add rsp, 0xF0
00007cbcc2dd94fe  pop r11
00007cbcc2dd9500  pop r10
00007cbcc2dd9502  pop r9
00007cbcc2dd9504  pop r8
00007cbcc2dd9506  pop rsi
00007cbcc2dd9507  pop rdi
00007cbcc2dd9508  pop rdx
00007cbcc2dd9509  pop rcx
00007cbcc2dd950a  pop rax
00007cbcc2dd950b  add rsp, 0x08
00007cbcc2dd950f  jmp 0x00007CBCC2DD731B
00007cbcc2dd9514  sub rsp, 0x08
00007cbcc2dd9518  push rax
00007cbcc2dd9519  push rcx
00007cbcc2dd951a  push rdx
00007cbcc2dd951b  push rdi
00007cbcc2dd951c  push rsi
00007cbcc2dd951d  push r8
00007cbcc2dd951f  push r9
00007cbcc2dd9521  push r10
00007cbcc2dd9523  push r11
00007cbcc2dd9525  sub rsp, 0xF0
00007cbcc2dd952c  vmovaps [rsp], xmm0
00007cbcc2dd9531  vmovaps [rsp+0x10], xmm1
00007cbcc2dd9537  vmovaps [rsp+0x20], xmm2
00007cbcc2dd953d  vmovaps [rsp+0x30], xmm3
00007cbcc2dd9543  vmovaps [rsp+0x40], xmm4
00007cbcc2dd9549  vmovaps [rsp+0x50], xmm5
00007cbcc2dd954f  vmovaps [rsp+0x60], xmm6
00007cbcc2dd9555  vmovaps [rsp+0x70], xmm7
00007cbcc2dd955b  vmovaps [rsp+0x80], xmm8
00007cbcc2dd9564  vmovaps [rsp+0x90], xmm9
00007cbcc2dd956d  vmovaps [rsp+0xA0], xmm11
00007cbcc2dd9576  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd957f  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd9588  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd9591  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd959a  sub rsp, 0x40
00007cbcc2dd959e  lea rdi, [rsp]
00007cbcc2dd95a2  lea rsi, [rsp+0x10]
00007cbcc2dd95a7  lea rdx, [rsp+0x20]
00007cbcc2dd95ac  lea rcx, [rsp+0x30]
00007cbcc2dd95b1  mov r8d, 0x00
00007cbcc2dd95b7  lea r9, [r15+0x3A8]
00007cbcc2dd95be  movaps [rdi], xmm10
00007cbcc2dd95c2  movaps [rsi], xmm6
00007cbcc2dd95c5  movaps [rdx], xmm15
00007cbcc2dd95c9  movaps [rcx], xmm1
00007cbcc2dd95cc  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd95d6  call rax
00007cbcc2dd95d8  movaps xmm10, [rsp]
00007cbcc2dd95dd  add rsp, 0x40
00007cbcc2dd95e1  vmovaps xmm0, [rsp]
00007cbcc2dd95e6  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd95ec  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd95f2  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd95f8  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd95fe  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd9604  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd960a  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd9610  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd9619  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd9622  vmovaps xmm11, [rsp+0xA0]
00007cbcc2dd962b  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd9634  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd963d  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd9646  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd964f  add rsp, 0xF0
00007cbcc2dd9656  pop r11
00007cbcc2dd9658  pop r10
00007cbcc2dd965a  pop r9
00007cbcc2dd965c  pop r8
00007cbcc2dd965e  pop rsi
00007cbcc2dd965f  pop rdi
00007cbcc2dd9660  pop rdx
00007cbcc2dd9661  pop rcx
00007cbcc2dd9662  pop rax
00007cbcc2dd9663  add rsp, 0x08
00007cbcc2dd9667  jmp 0x00007CBCC2DD7341
00007cbcc2dd966c  call 0x00007CBCC2BFF430
00007cbcc2dd9671  jmp 0x00007CBCC2DD734B
00007cbcc2dd9676  call 0x00007CBCC2C0E760
00007cbcc2dd967b  jmp 0x00007CBCC2DD7355
00007cbcc2dd9680  sub rsp, 0x08
00007cbcc2dd9684  push rax
00007cbcc2dd9685  push rcx
00007cbcc2dd9686  push rdx
00007cbcc2dd9687  push rdi
00007cbcc2dd9688  push rsi
00007cbcc2dd9689  push r8
00007cbcc2dd968b  push r9
00007cbcc2dd968d  push r10
00007cbcc2dd968f  push r11
00007cbcc2dd9691  sub rsp, 0xF0
00007cbcc2dd9698  vmovaps [rsp], xmm0
00007cbcc2dd969d  vmovaps [rsp+0x10], xmm1
00007cbcc2dd96a3  vmovaps [rsp+0x20], xmm2
00007cbcc2dd96a9  vmovaps [rsp+0x30], xmm3
00007cbcc2dd96af  vmovaps [rsp+0x40], xmm4
00007cbcc2dd96b5  vmovaps [rsp+0x50], xmm5
00007cbcc2dd96bb  vmovaps [rsp+0x60], xmm6
00007cbcc2dd96c1  vmovaps [rsp+0x70], xmm8
00007cbcc2dd96c7  vmovaps [rsp+0x80], xmm9
00007cbcc2dd96d0  vmovaps [rsp+0x90], xmm10
00007cbcc2dd96d9  vmovaps [rsp+0xA0], xmm11
00007cbcc2dd96e2  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd96eb  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd96f4  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd96fd  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd9706  sub rsp, 0x40
00007cbcc2dd970a  lea rdi, [rsp]
00007cbcc2dd970e  lea rsi, [rsp+0x10]
00007cbcc2dd9713  lea rdx, [rsp+0x20]
00007cbcc2dd9718  lea rcx, [rsp+0x30]
00007cbcc2dd971d  mov r8d, 0x00
00007cbcc2dd9723  lea r9, [r15+0x3A8]
00007cbcc2dd972a  movaps [rdi], xmm7
00007cbcc2dd972d  movaps [rsi], xmm8
00007cbcc2dd9731  movaps [rdx], xmm3
00007cbcc2dd9734  movaps [rcx], xmm9
00007cbcc2dd9738  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd9742  call rax
00007cbcc2dd9744  movaps xmm7, [rsp]
00007cbcc2dd9748  add rsp, 0x40
00007cbcc2dd974c  vmovaps xmm0, [rsp]
00007cbcc2dd9751  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd9757  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd975d  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd9763  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd9769  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd976f  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd9775  vmovaps xmm8, [rsp+0x70]
00007cbcc2dd977b  vmovaps xmm9, [rsp+0x80]
00007cbcc2dd9784  vmovaps xmm10, [rsp+0x90]
00007cbcc2dd978d  vmovaps xmm11, [rsp+0xA0]
00007cbcc2dd9796  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd979f  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd97a8  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd97b1  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd97ba  add rsp, 0xF0
00007cbcc2dd97c1  pop r11
00007cbcc2dd97c3  pop r10
00007cbcc2dd97c5  pop r9
00007cbcc2dd97c7  pop r8
00007cbcc2dd97c9  pop rsi
00007cbcc2dd97ca  pop rdi
00007cbcc2dd97cb  pop rdx
00007cbcc2dd97cc  pop rcx
00007cbcc2dd97cd  pop rax
00007cbcc2dd97ce  add rsp, 0x08
00007cbcc2dd97d2  jmp 0x00007CBCC2DD737D
00007cbcc2dd97d7  sub rsp, 0x08
00007cbcc2dd97db  push rax
00007cbcc2dd97dc  push rcx
00007cbcc2dd97dd  push rdx
00007cbcc2dd97de  push rdi
00007cbcc2dd97df  push rsi
00007cbcc2dd97e0  push r8
00007cbcc2dd97e2  push r9
00007cbcc2dd97e4  push r10
00007cbcc2dd97e6  push r11
00007cbcc2dd97e8  sub rsp, 0xF0
00007cbcc2dd97ef  vmovaps [rsp], xmm0
00007cbcc2dd97f4  vmovaps [rsp+0x10], xmm1
00007cbcc2dd97fa  vmovaps [rsp+0x20], xmm2
00007cbcc2dd9800  vmovaps [rsp+0x30], xmm3
00007cbcc2dd9806  vmovaps [rsp+0x40], xmm4
00007cbcc2dd980c  vmovaps [rsp+0x50], xmm5
00007cbcc2dd9812  vmovaps [rsp+0x60], xmm6
00007cbcc2dd9818  vmovaps [rsp+0x70], xmm7
00007cbcc2dd981e  vmovaps [rsp+0x80], xmm9
00007cbcc2dd9827  vmovaps [rsp+0x90], xmm10
00007cbcc2dd9830  vmovaps [rsp+0xA0], xmm11
00007cbcc2dd9839  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd9842  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd984b  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd9854  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd985d  sub rsp, 0x40
00007cbcc2dd9861  lea rdi, [rsp]
00007cbcc2dd9865  lea rsi, [rsp+0x10]
00007cbcc2dd986a  lea rdx, [rsp+0x20]
00007cbcc2dd986f  lea rcx, [rsp+0x30]
00007cbcc2dd9874  mov r8d, 0x00
00007cbcc2dd987a  lea r9, [r15+0x3A8]
00007cbcc2dd9881  movaps [rdi], xmm8
00007cbcc2dd9885  movaps [rsi], xmm11
00007cbcc2dd9889  movaps [rdx], xmm14
00007cbcc2dd988d  movaps [rcx], xmm9
00007cbcc2dd9891  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd989b  call rax
00007cbcc2dd989d  movaps xmm8, [rsp]
00007cbcc2dd98a2  add rsp, 0x40
00007cbcc2dd98a6  vmovaps xmm0, [rsp]
00007cbcc2dd98ab  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd98b1  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd98b7  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd98bd  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd98c3  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd98c9  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd98cf  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd98d5  vmovaps xmm9, [rsp+0x80]
00007cbcc2dd98de  vmovaps xmm10, [rsp+0x90]
00007cbcc2dd98e7  vmovaps xmm11, [rsp+0xA0]
00007cbcc2dd98f0  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd98f9  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd9902  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd990b  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd9914  add rsp, 0xF0
00007cbcc2dd991b  pop r11
00007cbcc2dd991d  pop r10
00007cbcc2dd991f  pop r9
00007cbcc2dd9921  pop r8
00007cbcc2dd9923  pop rsi
00007cbcc2dd9924  pop rdi
00007cbcc2dd9925  pop rdx
00007cbcc2dd9926  pop rcx
00007cbcc2dd9927  pop rax
00007cbcc2dd9928  add rsp, 0x08
00007cbcc2dd992c  jmp 0x00007CBCC2DD73A6
00007cbcc2dd9931  sub rsp, 0x08
00007cbcc2dd9935  push rax
00007cbcc2dd9936  push rcx
00007cbcc2dd9937  push rdx
00007cbcc2dd9938  push rdi
00007cbcc2dd9939  push rsi
00007cbcc2dd993a  push r8
00007cbcc2dd993c  push r9
00007cbcc2dd993e  push r10
00007cbcc2dd9940  push r11
00007cbcc2dd9942  sub rsp, 0xF0
00007cbcc2dd9949  vmovaps [rsp], xmm0
00007cbcc2dd994e  vmovaps [rsp+0x10], xmm1
00007cbcc2dd9954  vmovaps [rsp+0x20], xmm2
00007cbcc2dd995a  vmovaps [rsp+0x30], xmm3
00007cbcc2dd9960  vmovaps [rsp+0x40], xmm4
00007cbcc2dd9966  vmovaps [rsp+0x50], xmm5
00007cbcc2dd996c  vmovaps [rsp+0x60], xmm6
00007cbcc2dd9972  vmovaps [rsp+0x70], xmm7
00007cbcc2dd9978  vmovaps [rsp+0x80], xmm8
00007cbcc2dd9981  vmovaps [rsp+0x90], xmm9
00007cbcc2dd998a  vmovaps [rsp+0xA0], xmm10
00007cbcc2dd9993  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd999c  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd99a5  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd99ae  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd99b7  sub rsp, 0x40
00007cbcc2dd99bb  lea rdi, [rsp]
00007cbcc2dd99bf  lea rsi, [rsp+0x10]
00007cbcc2dd99c4  lea rdx, [rsp+0x20]
00007cbcc2dd99c9  lea rcx, [rsp+0x30]
00007cbcc2dd99ce  mov r8d, 0x00
00007cbcc2dd99d4  lea r9, [r15+0x3A8]
00007cbcc2dd99db  movaps [rdi], xmm11
00007cbcc2dd99df  movaps [rsi], xmm13
00007cbcc2dd99e3  movaps [rdx], xmm12
00007cbcc2dd99e7  movaps [rcx], xmm14
00007cbcc2dd99eb  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd99f5  call rax
00007cbcc2dd99f7  movaps xmm11, [rsp]
00007cbcc2dd99fc  add rsp, 0x40
00007cbcc2dd9a00  vmovaps xmm0, [rsp]
00007cbcc2dd9a05  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd9a0b  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd9a11  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd9a17  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd9a1d  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd9a23  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd9a29  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd9a2f  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd9a38  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd9a41  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dd9a4a  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd9a53  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd9a5c  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd9a65  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd9a6e  add rsp, 0xF0
00007cbcc2dd9a75  pop r11
00007cbcc2dd9a77  pop r10
00007cbcc2dd9a79  pop r9
00007cbcc2dd9a7b  pop r8
00007cbcc2dd9a7d  pop rsi
00007cbcc2dd9a7e  pop rdi
00007cbcc2dd9a7f  pop rdx
00007cbcc2dd9a80  pop rcx
00007cbcc2dd9a81  pop rax
00007cbcc2dd9a82  add rsp, 0x08
00007cbcc2dd9a86  jmp 0x00007CBCC2DD73CF
00007cbcc2dd9a8b  sub rsp, 0x08
00007cbcc2dd9a8f  push rax
00007cbcc2dd9a90  push rcx
00007cbcc2dd9a91  push rdx
00007cbcc2dd9a92  push rdi
00007cbcc2dd9a93  push rsi
00007cbcc2dd9a94  push r8
00007cbcc2dd9a96  push r9
00007cbcc2dd9a98  push r10
00007cbcc2dd9a9a  push r11
00007cbcc2dd9a9c  sub rsp, 0xF0
00007cbcc2dd9aa3  vmovaps [rsp], xmm0
00007cbcc2dd9aa8  vmovaps [rsp+0x10], xmm1
00007cbcc2dd9aae  vmovaps [rsp+0x20], xmm2
00007cbcc2dd9ab4  vmovaps [rsp+0x30], xmm3
00007cbcc2dd9aba  vmovaps [rsp+0x40], xmm4
00007cbcc2dd9ac0  vmovaps [rsp+0x50], xmm5
00007cbcc2dd9ac6  vmovaps [rsp+0x60], xmm6
00007cbcc2dd9acc  vmovaps [rsp+0x70], xmm7
00007cbcc2dd9ad2  vmovaps [rsp+0x80], xmm8
00007cbcc2dd9adb  vmovaps [rsp+0x90], xmm9
00007cbcc2dd9ae4  vmovaps [rsp+0xA0], xmm10
00007cbcc2dd9aed  vmovaps [rsp+0xB0], xmm11
00007cbcc2dd9af6  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd9aff  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd9b08  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd9b11  sub rsp, 0x40
00007cbcc2dd9b15  lea rdi, [rsp]
00007cbcc2dd9b19  lea rsi, [rsp+0x10]
00007cbcc2dd9b1e  lea rdx, [rsp+0x20]
00007cbcc2dd9b23  lea rcx, [rsp+0x30]
00007cbcc2dd9b28  mov r8d, 0x00
00007cbcc2dd9b2e  lea r9, [r15+0x3A8]
00007cbcc2dd9b35  movaps [rdi], xmm12
00007cbcc2dd9b39  movaps [rsi], xmm10
00007cbcc2dd9b3d  movaps [rdx], xmm15
00007cbcc2dd9b41  movaps [rcx], xmm14
00007cbcc2dd9b45  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd9b4f  call rax
00007cbcc2dd9b51  movaps xmm12, [rsp]
00007cbcc2dd9b56  add rsp, 0x40
00007cbcc2dd9b5a  vmovaps xmm0, [rsp]
00007cbcc2dd9b5f  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd9b65  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd9b6b  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd9b71  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd9b77  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd9b7d  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd9b83  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd9b89  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd9b92  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd9b9b  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dd9ba4  vmovaps xmm11, [rsp+0xB0]
00007cbcc2dd9bad  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd9bb6  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd9bbf  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd9bc8  add rsp, 0xF0
00007cbcc2dd9bcf  pop r11
00007cbcc2dd9bd1  pop r10
00007cbcc2dd9bd3  pop r9
00007cbcc2dd9bd5  pop r8
00007cbcc2dd9bd7  pop rsi
00007cbcc2dd9bd8  pop rdi
00007cbcc2dd9bd9  pop rdx
00007cbcc2dd9bda  pop rcx
00007cbcc2dd9bdb  pop rax
00007cbcc2dd9bdc  add rsp, 0x08
00007cbcc2dd9be0  jmp 0x00007CBCC2DD73F8
00007cbcc2dd9be5  call 0x00007CBCC2C0E760
00007cbcc2dd9bea  jmp 0x00007CBCC2DD7405
00007cbcc2dd9bef  call 0x00007CBCC2C0D4E0
00007cbcc2dd9bf4  jmp 0x00007CBCC2DD7412
00007cbcc2dd9bf9  sub rsp, 0x08
00007cbcc2dd9bfd  push rax
00007cbcc2dd9bfe  push rcx
00007cbcc2dd9bff  push rdx
00007cbcc2dd9c00  push rdi
00007cbcc2dd9c01  push rsi
00007cbcc2dd9c02  push r8
00007cbcc2dd9c04  push r9
00007cbcc2dd9c06  push r10
00007cbcc2dd9c08  push r11
00007cbcc2dd9c0a  sub rsp, 0xF0
00007cbcc2dd9c11  vmovaps [rsp], xmm0
00007cbcc2dd9c16  vmovaps [rsp+0x10], xmm1
00007cbcc2dd9c1c  vmovaps [rsp+0x20], xmm2
00007cbcc2dd9c22  vmovaps [rsp+0x30], xmm3
00007cbcc2dd9c28  vmovaps [rsp+0x40], xmm4
00007cbcc2dd9c2e  vmovaps [rsp+0x50], xmm5
00007cbcc2dd9c34  vmovaps [rsp+0x60], xmm6
00007cbcc2dd9c3a  vmovaps [rsp+0x70], xmm7
00007cbcc2dd9c40  vmovaps [rsp+0x80], xmm8
00007cbcc2dd9c49  vmovaps [rsp+0x90], xmm9
00007cbcc2dd9c52  vmovaps [rsp+0xA0], xmm11
00007cbcc2dd9c5b  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd9c64  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd9c6d  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd9c76  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd9c7f  sub rsp, 0x40
00007cbcc2dd9c83  lea rdi, [rsp]
00007cbcc2dd9c87  lea rsi, [rsp+0x10]
00007cbcc2dd9c8c  lea rdx, [rsp+0x20]
00007cbcc2dd9c91  lea rcx, [rsp+0x30]
00007cbcc2dd9c96  mov r8d, 0x00
00007cbcc2dd9c9c  lea r9, [r15+0x3A8]
00007cbcc2dd9ca3  movaps [rdi], xmm10
00007cbcc2dd9ca7  movaps [rsi], xmm7
00007cbcc2dd9caa  movaps [rdx], xmm1
00007cbcc2dd9cad  movaps [rcx], xmm13
00007cbcc2dd9cb1  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd9cbb  call rax
00007cbcc2dd9cbd  movaps xmm10, [rsp]
00007cbcc2dd9cc2  add rsp, 0x40
00007cbcc2dd9cc6  vmovaps xmm0, [rsp]
00007cbcc2dd9ccb  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd9cd1  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd9cd7  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd9cdd  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd9ce3  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd9ce9  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd9cef  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd9cf5  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd9cfe  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd9d07  vmovaps xmm11, [rsp+0xA0]
00007cbcc2dd9d10  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd9d19  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd9d22  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd9d2b  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd9d34  add rsp, 0xF0
00007cbcc2dd9d3b  pop r11
00007cbcc2dd9d3d  pop r10
00007cbcc2dd9d3f  pop r9
00007cbcc2dd9d41  pop r8
00007cbcc2dd9d43  pop rsi
00007cbcc2dd9d44  pop rdi
00007cbcc2dd9d45  pop rdx
00007cbcc2dd9d46  pop rcx
00007cbcc2dd9d47  pop rax
00007cbcc2dd9d48  add rsp, 0x08
00007cbcc2dd9d4c  jmp 0x00007CBCC2DD7448
00007cbcc2dd9d51  call 0x00007CBCC2BFF430
00007cbcc2dd9d56  jmp 0x00007CBCC2DD745A
00007cbcc2dd9d5b  sub rsp, 0x08
00007cbcc2dd9d5f  push rax
00007cbcc2dd9d60  push rcx
00007cbcc2dd9d61  push rdx
00007cbcc2dd9d62  push rdi
00007cbcc2dd9d63  push rsi
00007cbcc2dd9d64  push r8
00007cbcc2dd9d66  push r9
00007cbcc2dd9d68  push r10
00007cbcc2dd9d6a  push r11
00007cbcc2dd9d6c  sub rsp, 0xF0
00007cbcc2dd9d73  vmovaps [rsp], xmm0
00007cbcc2dd9d78  vmovaps [rsp+0x10], xmm1
00007cbcc2dd9d7e  vmovaps [rsp+0x20], xmm2
00007cbcc2dd9d84  vmovaps [rsp+0x30], xmm3
00007cbcc2dd9d8a  vmovaps [rsp+0x40], xmm4
00007cbcc2dd9d90  vmovaps [rsp+0x50], xmm5
00007cbcc2dd9d96  vmovaps [rsp+0x60], xmm6
00007cbcc2dd9d9c  vmovaps [rsp+0x70], xmm7
00007cbcc2dd9da2  vmovaps [rsp+0x80], xmm8
00007cbcc2dd9dab  vmovaps [rsp+0x90], xmm10
00007cbcc2dd9db4  vmovaps [rsp+0xA0], xmm11
00007cbcc2dd9dbd  vmovaps [rsp+0xB0], xmm12
00007cbcc2dd9dc6  vmovaps [rsp+0xC0], xmm13
00007cbcc2dd9dcf  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd9dd8  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd9de1  sub rsp, 0x40
00007cbcc2dd9de5  lea rdi, [rsp]
00007cbcc2dd9de9  lea rsi, [rsp+0x10]
00007cbcc2dd9dee  lea rdx, [rsp+0x20]
00007cbcc2dd9df3  lea rcx, [rsp+0x30]
00007cbcc2dd9df8  mov r8d, 0x00
00007cbcc2dd9dfe  lea r9, [r15+0x3A8]
00007cbcc2dd9e05  movaps [rdi], xmm9
00007cbcc2dd9e09  movaps [rsi], xmm8
00007cbcc2dd9e0d  movaps [rdx], xmm14
00007cbcc2dd9e11  movaps [rcx], xmm13
00007cbcc2dd9e15  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd9e1f  call rax
00007cbcc2dd9e21  movaps xmm9, [rsp]
00007cbcc2dd9e26  add rsp, 0x40
00007cbcc2dd9e2a  vmovaps xmm0, [rsp]
00007cbcc2dd9e2f  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd9e35  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd9e3b  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd9e41  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd9e47  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd9e4d  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd9e53  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd9e59  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd9e62  vmovaps xmm10, [rsp+0x90]
00007cbcc2dd9e6b  vmovaps xmm11, [rsp+0xA0]
00007cbcc2dd9e74  vmovaps xmm12, [rsp+0xB0]
00007cbcc2dd9e7d  vmovaps xmm13, [rsp+0xC0]
00007cbcc2dd9e86  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd9e8f  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd9e98  add rsp, 0xF0
00007cbcc2dd9e9f  pop r11
00007cbcc2dd9ea1  pop r10
00007cbcc2dd9ea3  pop r9
00007cbcc2dd9ea5  pop r8
00007cbcc2dd9ea7  pop rsi
00007cbcc2dd9ea8  pop rdi
00007cbcc2dd9ea9  pop rdx
00007cbcc2dd9eaa  pop rcx
00007cbcc2dd9eab  pop rax
00007cbcc2dd9eac  add rsp, 0x08
00007cbcc2dd9eb0  jmp 0x00007CBCC2DD7488
00007cbcc2dd9eb5  sub rsp, 0x08
00007cbcc2dd9eb9  push rax
00007cbcc2dd9eba  push rcx
00007cbcc2dd9ebb  push rdx
00007cbcc2dd9ebc  push rdi
00007cbcc2dd9ebd  push rsi
00007cbcc2dd9ebe  push r8
00007cbcc2dd9ec0  push r9
00007cbcc2dd9ec2  push r10
00007cbcc2dd9ec4  push r11
00007cbcc2dd9ec6  sub rsp, 0xF0
00007cbcc2dd9ecd  vmovaps [rsp], xmm0
00007cbcc2dd9ed2  vmovaps [rsp+0x10], xmm1
00007cbcc2dd9ed8  vmovaps [rsp+0x20], xmm2
00007cbcc2dd9ede  vmovaps [rsp+0x30], xmm3
00007cbcc2dd9ee4  vmovaps [rsp+0x40], xmm4
00007cbcc2dd9eea  vmovaps [rsp+0x50], xmm5
00007cbcc2dd9ef0  vmovaps [rsp+0x60], xmm6
00007cbcc2dd9ef6  vmovaps [rsp+0x70], xmm7
00007cbcc2dd9efc  vmovaps [rsp+0x80], xmm8
00007cbcc2dd9f05  vmovaps [rsp+0x90], xmm9
00007cbcc2dd9f0e  vmovaps [rsp+0xA0], xmm10
00007cbcc2dd9f17  vmovaps [rsp+0xB0], xmm11
00007cbcc2dd9f20  vmovaps [rsp+0xC0], xmm12
00007cbcc2dd9f29  vmovaps [rsp+0xD0], xmm14
00007cbcc2dd9f32  vmovaps [rsp+0xE0], xmm15
00007cbcc2dd9f3b  sub rsp, 0x40
00007cbcc2dd9f3f  lea rdi, [rsp]
00007cbcc2dd9f43  lea rsi, [rsp+0x10]
00007cbcc2dd9f48  lea rdx, [rsp+0x20]
00007cbcc2dd9f4d  lea rcx, [rsp+0x30]
00007cbcc2dd9f52  mov r8d, 0x00
00007cbcc2dd9f58  lea r9, [r15+0x3A8]
00007cbcc2dd9f5f  movaps [rdi], xmm13
00007cbcc2dd9f63  movaps [rsi], xmm11
00007cbcc2dd9f67  movaps [rdx], xmm15
00007cbcc2dd9f6b  movaps [rcx], xmm14
00007cbcc2dd9f6f  mov rax, 0x5BFE0F0EEA50
00007cbcc2dd9f79  call rax
00007cbcc2dd9f7b  movaps xmm13, [rsp]
00007cbcc2dd9f80  add rsp, 0x40
00007cbcc2dd9f84  vmovaps xmm0, [rsp]
00007cbcc2dd9f89  vmovaps xmm1, [rsp+0x10]
00007cbcc2dd9f8f  vmovaps xmm2, [rsp+0x20]
00007cbcc2dd9f95  vmovaps xmm3, [rsp+0x30]
00007cbcc2dd9f9b  vmovaps xmm4, [rsp+0x40]
00007cbcc2dd9fa1  vmovaps xmm5, [rsp+0x50]
00007cbcc2dd9fa7  vmovaps xmm6, [rsp+0x60]
00007cbcc2dd9fad  vmovaps xmm7, [rsp+0x70]
00007cbcc2dd9fb3  vmovaps xmm8, [rsp+0x80]
00007cbcc2dd9fbc  vmovaps xmm9, [rsp+0x90]
00007cbcc2dd9fc5  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dd9fce  vmovaps xmm11, [rsp+0xB0]
00007cbcc2dd9fd7  vmovaps xmm12, [rsp+0xC0]
00007cbcc2dd9fe0  vmovaps xmm14, [rsp+0xD0]
00007cbcc2dd9fe9  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dd9ff2  add rsp, 0xF0
00007cbcc2dd9ff9  pop r11
00007cbcc2dd9ffb  pop r10
00007cbcc2dd9ffd  pop r9
00007cbcc2dd9fff  pop r8
00007cbcc2dda001  pop rsi
00007cbcc2dda002  pop rdi
00007cbcc2dda003  pop rdx
00007cbcc2dda004  pop rcx
00007cbcc2dda005  pop rax
00007cbcc2dda006  add rsp, 0x08
00007cbcc2dda00a  jmp 0x00007CBCC2DD74B6
00007cbcc2dda00f  sub rsp, 0x08
00007cbcc2dda013  push rax
00007cbcc2dda014  push rcx
00007cbcc2dda015  push rdx
00007cbcc2dda016  push rdi
00007cbcc2dda017  push rsi
00007cbcc2dda018  push r8
00007cbcc2dda01a  push r9
00007cbcc2dda01c  push r10
00007cbcc2dda01e  push r11
00007cbcc2dda020  sub rsp, 0xF0
00007cbcc2dda027  vmovaps [rsp], xmm0
00007cbcc2dda02c  vmovaps [rsp+0x10], xmm1
00007cbcc2dda032  vmovaps [rsp+0x20], xmm2
00007cbcc2dda038  vmovaps [rsp+0x30], xmm3
00007cbcc2dda03e  vmovaps [rsp+0x40], xmm4
00007cbcc2dda044  vmovaps [rsp+0x50], xmm5
00007cbcc2dda04a  vmovaps [rsp+0x60], xmm6
00007cbcc2dda050  vmovaps [rsp+0x70], xmm7
00007cbcc2dda056  vmovaps [rsp+0x80], xmm8
00007cbcc2dda05f  vmovaps [rsp+0x90], xmm9
00007cbcc2dda068  vmovaps [rsp+0xA0], xmm10
00007cbcc2dda071  vmovaps [rsp+0xB0], xmm11
00007cbcc2dda07a  vmovaps [rsp+0xC0], xmm12
00007cbcc2dda083  vmovaps [rsp+0xD0], xmm13
00007cbcc2dda08c  vmovaps [rsp+0xE0], xmm15
00007cbcc2dda095  sub rsp, 0x40
00007cbcc2dda099  lea rdi, [rsp]
00007cbcc2dda09d  lea rsi, [rsp+0x10]
00007cbcc2dda0a2  lea rdx, [rsp+0x20]
00007cbcc2dda0a7  lea rcx, [rsp+0x30]
00007cbcc2dda0ac  mov r8d, 0x00
00007cbcc2dda0b2  lea r9, [r15+0x3A8]
00007cbcc2dda0b9  movaps [rdi], xmm14
00007cbcc2dda0bd  movaps [rsi], xmm12
00007cbcc2dda0c1  movaps [rdx], xmm1
00007cbcc2dda0c4  movaps [rcx], xmm15
00007cbcc2dda0c8  mov rax, 0x5BFE0F0EEA50
00007cbcc2dda0d2  call rax
00007cbcc2dda0d4  movaps xmm14, [rsp]
00007cbcc2dda0d9  add rsp, 0x40
00007cbcc2dda0dd  vmovaps xmm0, [rsp]
00007cbcc2dda0e2  vmovaps xmm1, [rsp+0x10]
00007cbcc2dda0e8  vmovaps xmm2, [rsp+0x20]
00007cbcc2dda0ee  vmovaps xmm3, [rsp+0x30]
00007cbcc2dda0f4  vmovaps xmm4, [rsp+0x40]
00007cbcc2dda0fa  vmovaps xmm5, [rsp+0x50]
00007cbcc2dda100  vmovaps xmm6, [rsp+0x60]
00007cbcc2dda106  vmovaps xmm7, [rsp+0x70]
00007cbcc2dda10c  vmovaps xmm8, [rsp+0x80]
00007cbcc2dda115  vmovaps xmm9, [rsp+0x90]
00007cbcc2dda11e  vmovaps xmm10, [rsp+0xA0]
00007cbcc2dda127  vmovaps xmm11, [rsp+0xB0]
00007cbcc2dda130  vmovaps xmm12, [rsp+0xC0]
00007cbcc2dda139  vmovaps xmm13, [rsp+0xD0]
00007cbcc2dda142  vmovaps xmm15, [rsp+0xE0]
00007cbcc2dda14b  add rsp, 0xF0
00007cbcc2dda152  pop r11
00007cbcc2dda154  pop r10
00007cbcc2dda156  pop r9
00007cbcc2dda158  pop r8
00007cbcc2dda15a  pop rsi
00007cbcc2dda15b  pop rdi
00007cbcc2dda15c  pop rdx
00007cbcc2dda15d  pop rcx
00007cbcc2dda15e  pop rax
00007cbcc2dda15f  add rsp, 0x08
00007cbcc2dda163  jmp 0x00007CBCC2DD74E4
00007cbcc2dda168  call 0x00007CBCC2C079B0
00007cbcc2dda16d  jmp 0x00007CBCC2DD74FA
00007cbcc2dda172  call 0x00007CBCC2CE3440
00007cbcc2dda177  jmp 0x00007CBCC2DD7504
00007cbcc2dda17c  call 0x00007CBCC2CDFCE0
00007cbcc2dda181  jmp 0x00007CBCC2DD750E
00007cbcc2dda186  call 0x00007CBCC2CE46C0
00007cbcc2dda18b  jmp 0x00007CBCC2DD7518
00007cbcc2dda190  int3
00007cbcc2dda191  nop [rax+rax*1], ax
00007cbcc2dda19a  nop [rax+rax*1], ax
00007cbcc2dda1a0  mov rax, [r15+0xF8]
00007cbcc2dda1a7  lea r14, [rax+0x110]
00007cbcc2dda1ae  mov r12, [r13+r14*1]
00007cbcc2dda1b3  mov [r15+0xE8], r12
00007cbcc2dda1ba  lea r14, [rax+0x100]
00007cbcc2dda1c1  mov r12, [r13+r14*1]
00007cbcc2dda1c6  lea r14, [rax+0x108]
00007cbcc2dda1cd  mov r11, [r13+r14*1]
00007cbcc2dda1d2  movq xmm1, r12
00007cbcc2dda1d7  movq xmm15, r11
00007cbcc2dda1dc  movq xmm1, xmm1
00007cbcc2dda1e0  movq xmm1, xmm1
00007cbcc2dda1e4  movaps [r15+0x1A0], xmm1
00007cbcc2dda1ec  movq xmm15, xmm15
00007cbcc2dda1f1  movq xmm15, xmm15
00007cbcc2dda1f6  movaps [r15+0x190], xmm15
00007cbcc2dda1fe  lea r14, [rax+0xF0]
00007cbcc2dda205  mov r12, [r13+r14*1]
00007cbcc2dda20a  lea r14, [rax+0xF8]
00007cbcc2dda211  mov r11, [r13+r14*1]
00007cbcc2dda216  movq xmm1, r12
00007cbcc2dda21b  movq xmm15, r11
00007cbcc2dda220  movq xmm1, xmm1
00007cbcc2dda224  movq xmm1, xmm1
00007cbcc2dda228  movaps [r15+0x1C0], xmm1
00007cbcc2dda230  movq xmm15, xmm15
00007cbcc2dda235  movq xmm15, xmm15
00007cbcc2dda23a  movaps [r15+0x1B0], xmm15
00007cbcc2dda242  lea r14, [rax+0xE0]
00007cbcc2dda249  mov r12, [r13+r14*1]
00007cbcc2dda24e  lea r14, [rax+0xE8]
00007cbcc2dda255  mov r11, [r13+r14*1]
00007cbcc2dda25a  movq xmm1, r12
00007cbcc2dda25f  movq xmm15, r11
00007cbcc2dda264  movq xmm1, xmm1
00007cbcc2dda268  movq xmm1, xmm1
00007cbcc2dda26c  movaps [r15+0x1E0], xmm1
00007cbcc2dda274  movq xmm15, xmm15
00007cbcc2dda279  movq xmm15, xmm15
00007cbcc2dda27e  movaps [r15+0x1D0], xmm15
00007cbcc2dda286  lea r14, [rax+0xD0]
00007cbcc2dda28d  mov r12, [r13+r14*1]
00007cbcc2dda292  lea r14, [rax+0xD8]
00007cbcc2dda299  mov r11, [r13+r14*1]
00007cbcc2dda29e  movq xmm1, r12
00007cbcc2dda2a3  movq xmm15, r11
00007cbcc2dda2a8  movq xmm1, xmm1
00007cbcc2dda2ac  movq xmm1, xmm1
00007cbcc2dda2b0  movaps [r15+0x200], xmm1
00007cbcc2dda2b8  movq xmm15, xmm15
00007cbcc2dda2bd  movq xmm15, xmm15
00007cbcc2dda2c2  movaps [r15+0x1F0], xmm15
00007cbcc2dda2ca  mov qword ptr [r15+0x40], 0x430000
00007cbcc2dda2d2  mov r14d, 0x4304C0
00007cbcc2dda2d8  mov r12, [r13+r14*1]
00007cbcc2dda2dd  movq xmm1, r12
00007cbcc2dda2e2  lea r14, [rax+0x120]
00007cbcc2dda2e9  mov [r15+0xF8], r14
00007cbcc2dda2f0  mov rax, [r15+0x50]
00007cbcc2dda2f4  movups xmm15, [r13+rax*1]
00007cbcc2dda2fa  movaps [r15+0x120], xmm15
00007cbcc2dda302  mov qword ptr [r15+0x48], 0x10
00007cbcc2dda30a  xor eax, eax
00007cbcc2dda30c  mov r14d, 0x10
00007cbcc2dda312  mov r12d, 0x200
00007cbcc2dda318  cmp r14, r12
00007cbcc2dda31b  cmc
00007cbcc2dda31c  lahf
00007cbcc2dda31d  seto al
00007cbcc2dda320  mov [r15+0x108], eax
00007cbcc2dda327  pextrq rax, xmm15, 0x01
00007cbcc2dda32e  movq xmm14, rax
00007cbcc2dda333  movaps [r15+0x130], xmm14
00007cbcc2dda33b  movq rax, xmm1
00007cbcc2dda340  movq r14, xmm15
00007cbcc2dda345  vmovq xmm1, rax
00007cbcc2dda34a  vmovq xmm15, r14
00007cbcc2dda34f  movaps xmm13, xmm1
00007cbcc2dda353  addsd xmm13, xmm15
00007cbcc2dda358  ucomisd xmm13, xmm13
00007cbcc2dda35d  jp 0x00007CBCC2DDA476
00007cbcc2dda363  movq xmm13, xmm13
00007cbcc2dda368  movq rax, xmm13
00007cbcc2dda36d  movq r14, xmm14
00007cbcc2dda372  vmovq xmm1, rax
00007cbcc2dda377  vmovq xmm15, r14
00007cbcc2dda37c  movaps xmm14, xmm1
00007cbcc2dda380  addsd xmm14, xmm15
00007cbcc2dda385  ucomisd xmm14, xmm14
00007cbcc2dda38a  jp 0x00007CBCC2DDA4BE
00007cbcc2dda390  movq xmm14, xmm14
00007cbcc2dda395  movaps [r15+0x110], xmm14
00007cbcc2dda39d  mov eax, [r15+0x108]
00007cbcc2dda3a4  sahf
00007cbcc2dda3a5  jnz 0x00007CBCC2DDA3D7
00007cbcc2dda3a7  cmp dword ptr [r15+0x318], 0x00
00007cbcc2dda3af  jz 0x00007CBCC2DDA6D0
00007cbcc2dda3b5  nop [rax+rax*1], ax
00007cbcc2dda3be  nop [rax+rax*1], eax
00007cbcc2dda3c6  mov eax, 0x41043C
00007cbcc2dda3cb  mov [r15+0x100], rax
00007cbcc2dda3d2  jmp 0x00007CBCC2BFE110
00007cbcc2dda3d7  cmp dword ptr [r15+0x318], 0x00
00007cbcc2dda3df  jz 0x00007CBCC2DDA510
00007cbcc2dda3e5  nop [rax+rax*1], ax
00007cbcc2dda3ee  nop [rax+rax*1], eax
00007cbcc2dda3f6  mov eax, 0x410420
00007cbcc2dda3fb  mov [r15+0x100], rax
00007cbcc2dda402  jmp 0x00007CBCC2BFE110
00007cbcc2dda407  int3
00007cbcc2dda408  call 0x00007CBCC2CE27E0
00007cbcc2dda40d  jmp 0x00007CBCC2DDA1B3
00007cbcc2dda412  call 0x00007CBCC2CE27E0
00007cbcc2dda417  jmp 0x00007CBCC2DDA1C6
00007cbcc2dda41c  call 0x00007CBCC2CE1570
00007cbcc2dda421  jmp 0x00007CBCC2DDA1D2
00007cbcc2dda426  call 0x00007CBCC2CE27E0
00007cbcc2dda42b  jmp 0x00007CBCC2DDA20A
00007cbcc2dda430  call 0x00007CBCC2CE1570
00007cbcc2dda435  jmp 0x00007CBCC2DDA216
00007cbcc2dda43a  call 0x00007CBCC2CE27E0
00007cbcc2dda43f  jmp 0x00007CBCC2DDA24E
00007cbcc2dda444  call 0x00007CBCC2CE1570
00007cbcc2dda449  jmp 0x00007CBCC2DDA25A
00007cbcc2dda44e  call 0x00007CBCC2CE27E0
00007cbcc2dda453  jmp 0x00007CBCC2DDA292
00007cbcc2dda458  call 0x00007CBCC2CE1570
00007cbcc2dda45d  jmp 0x00007CBCC2DDA29E
00007cbcc2dda462  call 0x00007CBCC2CE27E0
00007cbcc2dda467  jmp 0x00007CBCC2DDA2DD
00007cbcc2dda46c  call 0x00007CBCC2C0E760
00007cbcc2dda471  jmp 0x00007CBCC2DDA2FA
00007cbcc2dda476  ucomisd xmm1, xmm15
00007cbcc2dda47b  jp 0x00007CBCC2DDA48A
00007cbcc2dda47d  movaps xmm13, [0x00007CBCC29FE060]
00007cbcc2dda485  jmp 0x00007CBCC2DDA363
00007cbcc2dda48a  vxorps xmm0, xmm1, xmm15
00007cbcc2dda48f  pextrw eax, xmm0, 0x03
00007cbcc2dda494  and eax, 0x7FF8
00007cbcc2dda499  cmp eax, 0x08
00007cbcc2dda49c  jnz 0x00007CBCC2DDA363
00007cbcc2dda4a2  movq rax, xmm15
00007cbcc2dda4a7  shl rax, 0x0D
00007cbcc2dda4ab  jbe 0x00007CBCC2DDA363
00007cbcc2dda4b1  vorps xmm13, xmm15, [0x00007CBCC29FE070]
00007cbcc2dda4b9  jmp 0x00007CBCC2DDA363
00007cbcc2dda4be  ucomisd xmm1, xmm15
00007cbcc2dda4c3  jp 0x00007CBCC2DDA4D2
00007cbcc2dda4c5  movaps xmm14, [0x00007CBCC29FE060]
00007cbcc2dda4cd  jmp 0x00007CBCC2DDA390
00007cbcc2dda4d2  vxorps xmm0, xmm1, xmm15
00007cbcc2dda4d7  pextrw eax, xmm0, 0x03
00007cbcc2dda4dc  and eax, 0x7FF8
00007cbcc2dda4e1  cmp eax, 0x08
00007cbcc2dda4e4  jnz 0x00007CBCC2DDA390
00007cbcc2dda4ea  movq rax, xmm15
00007cbcc2dda4ef  shl rax, 0x0D
00007cbcc2dda4f3  jbe 0x00007CBCC2DDA390
00007cbcc2dda4f9  vorps xmm14, xmm15, [0x00007CBCC29FE070]
00007cbcc2dda501  jmp 0x00007CBCC2DDA390
00007cbcc2dda506  int3
00007cbcc2dda507  nop [rax+rax*1], ax
00007cbcc2dda510  mov rax, [r15+0x48]
00007cbcc2dda514  mov r14, [r15+0x50]
00007cbcc2dda518  lea r12, [r14+rax*1]
00007cbcc2dda51c  movups xmm1, [r13+r12*1]
00007cbcc2dda522  movaps [r15+0x120], xmm1
00007cbcc2dda52a  lea r14, [rax+0x10]
00007cbcc2dda52e  mov [r15+0x48], r14
00007cbcc2dda532  xor eax, eax
00007cbcc2dda534  mov r12d, 0x200
00007cbcc2dda53a  cmp r14, r12
00007cbcc2dda53d  cmc
00007cbcc2dda53e  lahf
00007cbcc2dda53f  seto al
00007cbcc2dda542  mov [r15+0x108], eax
00007cbcc2dda549  pextrq rax, xmm1, 0x01
00007cbcc2dda550  movq xmm15, rax
00007cbcc2dda555  movaps [r15+0x130], xmm15
00007cbcc2dda55d  movaps xmm14, [r15+0x110]
00007cbcc2dda565  movq rax, xmm14
00007cbcc2dda56a  movq r14, xmm1
00007cbcc2dda56f  vmovq xmm1, rax
00007cbcc2dda574  vmovq xmm14, r14
00007cbcc2dda579  movaps xmm13, xmm1
00007cbcc2dda57d  addsd xmm13, xmm14
00007cbcc2dda582  ucomisd xmm13, xmm13
00007cbcc2dda587  jp 0x00007CBCC2DDA63C
00007cbcc2dda58d  movq xmm13, xmm13
00007cbcc2dda592  movq rax, xmm13
00007cbcc2dda597  movq r14, xmm15
00007cbcc2dda59c  vmovq xmm1, rax
00007cbcc2dda5a1  vmovq xmm15, r14
00007cbcc2dda5a6  movaps xmm14, xmm1
00007cbcc2dda5aa  addsd xmm14, xmm15
00007cbcc2dda5af  ucomisd xmm14, xmm14
00007cbcc2dda5b4  jp 0x00007CBCC2DDA684
00007cbcc2dda5ba  movq xmm14, xmm14
00007cbcc2dda5bf  movaps [r15+0x110], xmm14
00007cbcc2dda5c7  mov eax, [r15+0x108]
00007cbcc2dda5ce  sahf
00007cbcc2dda5cf  jnz 0x00007CBCC2DDA601
00007cbcc2dda5d1  cmp dword ptr [r15+0x318], 0x00
00007cbcc2dda5d9  jz 0x00007CBCC2DDA6D0
00007cbcc2dda5df  nop [rax+rax*1], ax
00007cbcc2dda5e8  nop [rax+rax*1], eax
00007cbcc2dda5f0  mov eax, 0x41043C
00007cbcc2dda5f5  mov [r15+0x100], rax
00007cbcc2dda5fc  jmp 0x00007CBCC2BFE110
00007cbcc2dda601  cmp dword ptr [r15+0x318], 0x00
00007cbcc2dda609  jz 0x00007CBCC2DDA510
00007cbcc2dda60f  nop [rax+rax*1], ax
00007cbcc2dda618  nop [rax+rax*1], eax
00007cbcc2dda620  mov eax, 0x410420
00007cbcc2dda625  mov [r15+0x100], rax
00007cbcc2dda62c  jmp 0x00007CBCC2BFE110
00007cbcc2dda631  int3
00007cbcc2dda632  call 0x00007CBCC2CB52F0
00007cbcc2dda637  jmp 0x00007CBCC2DDA522
00007cbcc2dda63c  ucomisd xmm1, xmm14
00007cbcc2dda641  jp 0x00007CBCC2DDA650
00007cbcc2dda643  movaps xmm13, [0x00007CBCC29FE060]
00007cbcc2dda64b  jmp 0x00007CBCC2DDA58D
00007cbcc2dda650  vxorps xmm0, xmm1, xmm14
00007cbcc2dda655  pextrw eax, xmm0, 0x03
00007cbcc2dda65a  and eax, 0x7FF8
00007cbcc2dda65f  cmp eax, 0x08
00007cbcc2dda662  jnz 0x00007CBCC2DDA58D
00007cbcc2dda668  movq rax, xmm14
00007cbcc2dda66d  shl rax, 0x0D
00007cbcc2dda671  jbe 0x00007CBCC2DDA58D
00007cbcc2dda677  vorps xmm13, xmm14, [0x00007CBCC29FE070]
00007cbcc2dda67f  jmp 0x00007CBCC2DDA58D
00007cbcc2dda684  ucomisd xmm1, xmm15
00007cbcc2dda689  jp 0x00007CBCC2DDA698
00007cbcc2dda68b  movaps xmm14, [0x00007CBCC29FE060]
00007cbcc2dda693  jmp 0x00007CBCC2DDA5BA
00007cbcc2dda698  vxorps xmm0, xmm1, xmm15
00007cbcc2dda69d  pextrw eax, xmm0, 0x03
00007cbcc2dda6a2  and eax, 0x7FF8
00007cbcc2dda6a7  cmp eax, 0x08
00007cbcc2dda6aa  jnz 0x00007CBCC2DDA5BA
00007cbcc2dda6b0  movq rax, xmm15
00007cbcc2dda6b5  shl rax, 0x0D
00007cbcc2dda6b9  jbe 0x00007CBCC2DDA5BA
00007cbcc2dda6bf  vorps xmm14, xmm15, [0x00007CBCC29FE070]
00007cbcc2dda6c7  jmp 0x00007CBCC2DDA5BA
00007cbcc2dda6cc  int3
00007cbcc2dda6cd  nop [rax], eax
00007cbcc2dda6d0  mov rax, [r15+0x40]
00007cbcc2dda6d4  lea r14, [rax+0x4C0]
00007cbcc2dda6db  movaps xmm1, [r15+0x110]
00007cbcc2dda6e3  movq rax, xmm1
00007cbcc2dda6e8  mov [r13+r14*1], rax
00007cbcc2dda6ed  mov rax, [r15+0xF0]
00007cbcc2dda6f4  mov [r15+0x100], rax
00007cbcc2dda6fb  jmp 0x00007CBCC2DCE5C0
00007cbcc2dda700  int3
00007cbcc2dda701  call 0x00007CBCC2CD5EB0
00007cbcc2dda706  jmp 0x00007CBCC2DDA6ED
00007cbcc2dda70b  int3
00007cbcc2dda70c  nop [rax], eax
00007cbcc2dda710  mov qword ptr [r15+0x100], 0x04
00007cbcc2dda71b  mov esi, 0x00
00007cbcc2dda720  mov edx, 0x09
00007cbcc2dda725  mov rdi, 0x7FFD8B4E56E0
00007cbcc2dda72f  mov rax, 0x5BFE0EF81970
00007cbcc2dda739  call rax
00007cbcc2dda73b  cmp dword ptr [r15+0x318], 0x00
00007cbcc2dda743  jnz 0x00007CBCC2BFE110
00007cbcc2dda749  jmp 0x00007CBCC2BFE0A0
00007cbcc2dda74e  int3
00007cbcc2dda74f  int3
