000074113b7ce69b  nop [rax+rax*1], eax
000074113b7ce6a0  vmovaps xmm1, [0x000074113B3FE010]
000074113b7ce6a8  movq xmm1, xmm1
000074113b7ce6ac  movaps [r15+0x110], xmm1
000074113b7ce6b4  vmovaps xmm1, [0x000074113B3FE020]
000074113b7ce6bc  movq xmm1, xmm1
000074113b7ce6c0  movaps [r15+0x120], xmm1
000074113b7ce6c8  mov eax, 0x420470
000074113b7ce6cd  mov r14, [r13+rax*1]
000074113b7ce6d2  movq xmm1, r14
000074113b7ce6d7  movaps [r15+0x130], xmm1
000074113b7ce6df  vmovaps xmm1, [0x000074113B3FE030]
000074113b7ce6e7  vpbroadcastq xmm1, xmm1
000074113b7ce6ec  movaps [r15+0x140], xmm1
000074113b7ce6f4  mov qword ptr [r15+0x40], 0x02
000074113b7ce6fc  vmovaps xmm15, [0x000074113B3FE040]
000074113b7ce704  movq xmm15, xmm15
000074113b7ce709  movaps [r15+0x150], xmm15
000074113b7ce711  mov qword ptr [r15+0x58], 0x420000
000074113b7ce719  vmovaps xmm15, [0x000074113B3FE050]
000074113b7ce721  vpbroadcastq xmm15, xmm15
000074113b7ce726  movaps [r15+0x160], xmm15
000074113b7ce72e  mov rax, [r15+0x40]
000074113b7ce732  vmovq xmm14, rax
000074113b7ce737  vpbroadcastq xmm14, xmm14
000074113b7ce73c  movaps [r15+0x170], xmm14
000074113b7ce744  mov eax, 0x420480
000074113b7ce749  movups xmm13, [r13+rax*1]
000074113b7ce74f  mov qword ptr [r15+0x40], 0x4304C8
000074113b7ce757  mov qword ptr [r15+0x50], 0x4306D0
000074113b7ce75f  vpmovqd xmm12, xmm13
000074113b7ce765  pxor xmm11, xmm11
000074113b7ce76a  punpcklqdq xmm12, xmm11
000074113b7ce76f  movaps [r15+0x210], xmm12
000074113b7ce777  movq xmm12, qword ptr [r15+0x120]
000074113b7ce780  movq xmm11, qword ptr [r15+0x130]
000074113b7ce789  psubd xmm12, xmm11
000074113b7ce78e  movq xmm12, xmm12
000074113b7ce793  paddq xmm13, xmm14
000074113b7ce798  movaps [r15+0x180], xmm13
000074113b7ce7a0  movq xmm14, qword ptr [r15+0x150]
000074113b7ce7a9  paddd xmm11, xmm14
000074113b7ce7ae  movq xmm11, xmm11
000074113b7ce7b3  movq xmm11, xmm11
000074113b7ce7b8  movaps [r15+0x130], xmm11
000074113b7ce7c0  pmovzxdq xmm12, xmm12
000074113b7ce7c6  psllq xmm12, 0x00
000074113b7ce7cc  movq xmm14, qword ptr [r15+0x210]
000074113b7ce7d5  movq xmm13, qword ptr [r15+0x110]
000074113b7ce7de  paddd xmm14, xmm13
000074113b7ce7e3  movq xmm14, xmm14
000074113b7ce7e8  vcvtuqq2pd xmm12, xmm12
000074113b7ce7ee  pmovzxdq xmm14, xmm14
000074113b7ce7f4  psllq xmm14, 0x00
000074113b7ce7fa  vcvtuqq2pd xmm14, xmm14
000074113b7ce800  movaps xmm13, xmm12
000074113b7ce804  mulpd xmm13, xmm1
000074113b7ce809  vcmppd xmm11, xmm13, xmm13, 0x03
000074113b7ce80f  ptest xmm11, xmm11
000074113b7ce815  jnz 0x000074113B7CE8FF
000074113b7ce81b  movaps [r15+0x220], xmm13
000074113b7ce823  mov eax, 0x4306D0
000074113b7ce828  movups [r13+rax*1], xmm13
000074113b7ce82e  movaps xmm1, xmm14
000074113b7ce832  mulpd xmm1, xmm15
000074113b7ce837  vcmppd xmm13, xmm1, xmm1, 0x03
000074113b7ce83c  ptest xmm13, xmm13
000074113b7ce842  jnz 0x000074113B7CEA4C
000074113b7ce848  movaps [r15+0x210], xmm1
000074113b7ce850  mov eax, 0x4304C8
000074113b7ce855  movups [r13+rax*1], xmm1
000074113b7ce85b  mov qword ptr [r15+0x48], 0x10
000074113b7ce863  xor eax, eax
000074113b7ce865  mov r14d, 0x10
000074113b7ce86b  mov r12d, 0x200
000074113b7ce871  cmp r14, r12
000074113b7ce874  cmc
000074113b7ce875  lahf
000074113b7ce876  seto al
000074113b7ce879  mov [r15+0x108], eax
000074113b7ce880  mov eax, [r15+0x108]
000074113b7ce887  sahf
000074113b7ce888  jnz 0x000074113B7CE8BA
000074113b7ce88a  cmp dword ptr [r15+0x318], 0x00
000074113b7ce892  jz 0x000074113B7CEFF0
000074113b7ce898  nop [rax+rax*1], ax
000074113b7ce8a1  nop [rax+rax*1], eax
000074113b7ce8a9  mov eax, 0x4101EC
000074113b7ce8ae  mov [r15+0x100], rax
000074113b7ce8b5  jmp 0x000074113B5FE110
000074113b7ce8ba  cmp dword ptr [r15+0x318], 0x00
000074113b7ce8c2  jz 0x000074113B7CEBA0
000074113b7ce8c8  nop [rax+rax*1], ax
000074113b7ce8d1  nop [rax+rax*1], eax
000074113b7ce8d9  mov eax, 0x4101AC
000074113b7ce8de  mov [r15+0x100], rax
000074113b7ce8e5  jmp 0x000074113B5FE110
000074113b7ce8ea  int3
000074113b7ce8eb  call 0x000074113B60DC20
000074113b7ce8f0  jmp 0x000074113B7CE6D2
000074113b7ce8f5  call 0x000074113B60C260
000074113b7ce8fa  jmp 0x000074113B7CE74F
000074113b7ce8ff  sub rsp, 0x08
000074113b7ce903  push rax
000074113b7ce904  push rcx
000074113b7ce905  push rdx
000074113b7ce906  push rdi
000074113b7ce907  push rsi
000074113b7ce908  push r8
000074113b7ce90a  push r9
000074113b7ce90c  push r10
000074113b7ce90e  push r11
000074113b7ce910  sub rsp, 0xF0
000074113b7ce917  vmovaps [rsp], xmm0
000074113b7ce91c  vmovaps [rsp+0x10], xmm1
000074113b7ce922  vmovaps [rsp+0x20], xmm2
000074113b7ce928  vmovaps [rsp+0x30], xmm3
000074113b7ce92e  vmovaps [rsp+0x40], xmm4
000074113b7ce934  vmovaps [rsp+0x50], xmm5
000074113b7ce93a  vmovaps [rsp+0x60], xmm6
000074113b7ce940  vmovaps [rsp+0x70], xmm7
000074113b7ce946  vmovaps [rsp+0x80], xmm8
000074113b7ce94f  vmovaps [rsp+0x90], xmm9
000074113b7ce958  vmovaps [rsp+0xA0], xmm10
000074113b7ce961  vmovaps [rsp+0xB0], xmm11
000074113b7ce96a  vmovaps [rsp+0xC0], xmm12
000074113b7ce973  vmovaps [rsp+0xD0], xmm14
000074113b7ce97c  vmovaps [rsp+0xE0], xmm15
000074113b7ce985  sub rsp, 0x30
000074113b7ce989  movaps [rsp], xmm13
000074113b7ce98e  movaps [rsp+0x10], xmm12
000074113b7ce994  movaps [rsp+0x20], xmm1
000074113b7ce999  lea rdi, [rsp]
000074113b7ce99d  mov esi, 0x00
000074113b7ce9a2  mov rax, 0x629073062530
000074113b7ce9ac  call rax
000074113b7ce9ae  movaps xmm13, [rsp]
000074113b7ce9b3  add rsp, 0x30
000074113b7ce9b7  vmovaps xmm0, [rsp]
000074113b7ce9bc  vmovaps xmm1, [rsp+0x10]
000074113b7ce9c2  vmovaps xmm2, [rsp+0x20]
000074113b7ce9c8  vmovaps xmm3, [rsp+0x30]
000074113b7ce9ce  vmovaps xmm4, [rsp+0x40]
000074113b7ce9d4  vmovaps xmm5, [rsp+0x50]
000074113b7ce9da  vmovaps xmm6, [rsp+0x60]
000074113b7ce9e0  vmovaps xmm7, [rsp+0x70]
000074113b7ce9e6  vmovaps xmm8, [rsp+0x80]
000074113b7ce9ef  vmovaps xmm9, [rsp+0x90]
000074113b7ce9f8  vmovaps xmm10, [rsp+0xA0]
000074113b7cea01  vmovaps xmm11, [rsp+0xB0]
000074113b7cea0a  vmovaps xmm12, [rsp+0xC0]
000074113b7cea13  vmovaps xmm14, [rsp+0xD0]
000074113b7cea1c  vmovaps xmm15, [rsp+0xE0]
000074113b7cea25  add rsp, 0xF0
000074113b7cea2c  pop r11
000074113b7cea2e  pop r10
000074113b7cea30  pop r9
000074113b7cea32  pop r8
000074113b7cea34  pop rsi
000074113b7cea35  pop rdi
000074113b7cea36  pop rdx
000074113b7cea37  pop rcx
000074113b7cea38  pop rax
000074113b7cea39  add rsp, 0x08
000074113b7cea3d  jmp 0x000074113B7CE81B
000074113b7cea42  call 0x000074113B60C380
000074113b7cea47  jmp 0x000074113B7CE82E
000074113b7cea4c  sub rsp, 0x08
000074113b7cea50  push rax
000074113b7cea51  push rcx
000074113b7cea52  push rdx
000074113b7cea53  push rdi
000074113b7cea54  push rsi
000074113b7cea55  push r8
000074113b7cea57  push r9
000074113b7cea59  push r10
000074113b7cea5b  push r11
000074113b7cea5d  sub rsp, 0xF0
000074113b7cea64  vmovaps [rsp], xmm0
000074113b7cea69  vmovaps [rsp+0x10], xmm2
000074113b7cea6f  vmovaps [rsp+0x20], xmm3
000074113b7cea75  vmovaps [rsp+0x30], xmm4
000074113b7cea7b  vmovaps [rsp+0x40], xmm5
000074113b7cea81  vmovaps [rsp+0x50], xmm6
000074113b7cea87  vmovaps [rsp+0x60], xmm7
000074113b7cea8d  vmovaps [rsp+0x70], xmm8
000074113b7cea93  vmovaps [rsp+0x80], xmm9
000074113b7cea9c  vmovaps [rsp+0x90], xmm10
000074113b7ceaa5  vmovaps [rsp+0xA0], xmm11
000074113b7ceaae  vmovaps [rsp+0xB0], xmm12
000074113b7ceab7  vmovaps [rsp+0xC0], xmm13
000074113b7ceac0  vmovaps [rsp+0xD0], xmm14
000074113b7ceac9  vmovaps [rsp+0xE0], xmm15
000074113b7cead2  sub rsp, 0x30
000074113b7cead6  movaps [rsp], xmm1
000074113b7ceada  movaps [rsp+0x10], xmm14
000074113b7ceae0  movaps [rsp+0x20], xmm15
000074113b7ceae6  lea rdi, [rsp]
000074113b7ceaea  mov esi, 0x00
000074113b7ceaef  mov rax, 0x629073062530
000074113b7ceaf9  call rax
000074113b7ceafb  movaps xmm1, [rsp]
000074113b7ceaff  add rsp, 0x30
000074113b7ceb03  vmovaps xmm0, [rsp]
000074113b7ceb08  vmovaps xmm2, [rsp+0x10]
000074113b7ceb0e  vmovaps xmm3, [rsp+0x20]
000074113b7ceb14  vmovaps xmm4, [rsp+0x30]
000074113b7ceb1a  vmovaps xmm5, [rsp+0x40]
000074113b7ceb20  vmovaps xmm6, [rsp+0x50]
000074113b7ceb26  vmovaps xmm7, [rsp+0x60]
000074113b7ceb2c  vmovaps xmm8, [rsp+0x70]
000074113b7ceb32  vmovaps xmm9, [rsp+0x80]
000074113b7ceb3b  vmovaps xmm10, [rsp+0x90]
000074113b7ceb44  vmovaps xmm11, [rsp+0xA0]
000074113b7ceb4d  vmovaps xmm12, [rsp+0xB0]
000074113b7ceb56  vmovaps xmm13, [rsp+0xC0]
000074113b7ceb5f  vmovaps xmm14, [rsp+0xD0]
000074113b7ceb68  vmovaps xmm15, [rsp+0xE0]
000074113b7ceb71  add rsp, 0xF0
000074113b7ceb78  pop r11
000074113b7ceb7a  pop r10
000074113b7ceb7c  pop r9
000074113b7ceb7e  pop r8
000074113b7ceb80  pop rsi
000074113b7ceb81  pop rdi
000074113b7ceb82  pop rdx
000074113b7ceb83  pop rcx
000074113b7ceb84  pop rax
000074113b7ceb85  add rsp, 0x08
000074113b7ceb89  jmp 0x000074113B7CE848
000074113b7ceb8e  call 0x000074113B5FF540
000074113b7ceb93  jmp 0x000074113B7CE85B
000074113b7ceb98  int3
000074113b7ceb99  nop [rax], eax
000074113b7ceba0  movaps xmm1, [r15+0x180]
000074113b7ceba8  vpmovqd xmm15, xmm1
000074113b7cebae  pxor xmm14, xmm14
000074113b7cebb3  punpcklqdq xmm15, xmm14
000074113b7cebb8  movaps [r15+0x210], xmm15
000074113b7cebc0  movq xmm15, qword ptr [r15+0x120]
000074113b7cebc9  movq xmm14, qword ptr [r15+0x130]
000074113b7cebd2  psubd xmm15, xmm14
000074113b7cebd7  movq xmm15, xmm15
000074113b7cebdc  movaps xmm13, [r15+0x170]
000074113b7cebe4  paddq xmm1, xmm13
000074113b7cebe9  movaps [r15+0x180], xmm1
000074113b7cebf1  movq xmm1, qword ptr [r15+0x150]
000074113b7cebfa  paddd xmm14, xmm1
000074113b7cebff  movq xmm14, xmm14
000074113b7cec04  movq xmm14, xmm14
000074113b7cec09  movaps [r15+0x130], xmm14
000074113b7cec11  pmovzxdq xmm15, xmm15
000074113b7cec17  psllq xmm15, 0x00
000074113b7cec1d  movq xmm1, qword ptr [r15+0x210]
000074113b7cec26  movq xmm14, qword ptr [r15+0x110]
000074113b7cec2f  paddd xmm1, xmm14
000074113b7cec34  movq xmm1, xmm1
000074113b7cec38  vcvtuqq2pd xmm15, xmm15
000074113b7cec3e  pmovzxdq xmm1, xmm1
000074113b7cec43  psllq xmm1, 0x00
000074113b7cec48  vcvtuqq2pd xmm1, xmm1
000074113b7cec4e  movaps xmm14, [r15+0x140]
000074113b7cec56  movaps xmm13, xmm15
000074113b7cec5a  mulpd xmm13, xmm14
000074113b7cec5f  vcmppd xmm12, xmm13, xmm13, 0x03
000074113b7cec65  ptest xmm12, xmm12
000074113b7cec6b  jnz 0x000074113B7CED4E
000074113b7cec71  movaps [r15+0x220], xmm13
000074113b7cec79  mov rax, [r15+0x48]
000074113b7cec7d  mov r14, [r15+0x50]
000074113b7cec81  lea r12, [r14+rax*1]
000074113b7cec85  movups [r13+r12*1], xmm13
000074113b7cec8b  movaps xmm15, [r15+0x160]
000074113b7cec93  movaps xmm14, xmm1
000074113b7cec97  mulpd xmm14, xmm15
000074113b7cec9c  vcmppd xmm13, xmm14, xmm14, 0x03
000074113b7ceca2  ptest xmm13, xmm13
000074113b7ceca8  jnz 0x000074113B7CEE9C
000074113b7cecae  movaps [r15+0x210], xmm14
000074113b7cecb6  mov r14, [r15+0x40]
000074113b7cecba  lea r12, [r14+rax*1]
000074113b7cecbe  movups [r13+r12*1], xmm14
000074113b7cecc4  lea r14, [rax+0x10]
000074113b7cecc8  mov [r15+0x48], r14
000074113b7ceccc  xor eax, eax
000074113b7cecce  mov r12d, 0x200
000074113b7cecd4  cmp r14, r12
000074113b7cecd7  cmc
000074113b7cecd8  lahf
000074113b7cecd9  seto al
000074113b7cecdc  mov [r15+0x108], eax
000074113b7cece3  mov eax, [r15+0x108]
000074113b7cecea  sahf
000074113b7ceceb  jnz 0x000074113B7CED1D
000074113b7ceced  cmp dword ptr [r15+0x318], 0x00
000074113b7cecf5  jz 0x000074113B7CEFF0
000074113b7cecfb  nop [rax+rax*1], ax
000074113b7ced04  nop [rax+rax*1], eax
000074113b7ced0c  mov eax, 0x4101EC
000074113b7ced11  mov [r15+0x100], rax
000074113b7ced18  jmp 0x000074113B5FE110
000074113b7ced1d  cmp dword ptr [r15+0x318], 0x00
000074113b7ced25  jz 0x000074113B7CEBA0
000074113b7ced2b  nop [rax+rax*1], ax
000074113b7ced34  nop [rax+rax*1], eax
000074113b7ced3c  mov eax, 0x4101AC
000074113b7ced41  mov [r15+0x100], rax
000074113b7ced48  jmp 0x000074113B5FE110
000074113b7ced4d  int3
000074113b7ced4e  sub rsp, 0x08
000074113b7ced52  push rax
000074113b7ced53  push rcx
000074113b7ced54  push rdx
000074113b7ced55  push rdi
000074113b7ced56  push rsi
000074113b7ced57  push r8
000074113b7ced59  push r9
000074113b7ced5b  push r10
000074113b7ced5d  push r11
000074113b7ced5f  sub rsp, 0xF0
000074113b7ced66  vmovaps [rsp], xmm0
000074113b7ced6b  vmovaps [rsp+0x10], xmm1
000074113b7ced71  vmovaps [rsp+0x20], xmm2
000074113b7ced77  vmovaps [rsp+0x30], xmm3
000074113b7ced7d  vmovaps [rsp+0x40], xmm4
000074113b7ced83  vmovaps [rsp+0x50], xmm5
000074113b7ced89  vmovaps [rsp+0x60], xmm6
000074113b7ced8f  vmovaps [rsp+0x70], xmm7
000074113b7ced95  vmovaps [rsp+0x80], xmm8
000074113b7ced9e  vmovaps [rsp+0x90], xmm9
000074113b7ceda7  vmovaps [rsp+0xA0], xmm10
000074113b7cedb0  vmovaps [rsp+0xB0], xmm11
000074113b7cedb9  vmovaps [rsp+0xC0], xmm12
000074113b7cedc2  vmovaps [rsp+0xD0], xmm14
000074113b7cedcb  vmovaps [rsp+0xE0], xmm15
000074113b7cedd4  sub rsp, 0x30
000074113b7cedd8  movaps [rsp], xmm13
000074113b7ceddd  movaps [rsp+0x10], xmm15
000074113b7cede3  movaps [rsp+0x20], xmm14
000074113b7cede9  lea rdi, [rsp]
000074113b7ceded  mov esi, 0x00
000074113b7cedf2  mov rax, 0x629073062530
000074113b7cedfc  call rax
000074113b7cedfe  movaps xmm13, [rsp]
000074113b7cee03  add rsp, 0x30
000074113b7cee07  vmovaps xmm0, [rsp]
000074113b7cee0c  vmovaps xmm1, [rsp+0x10]
000074113b7cee12  vmovaps xmm2, [rsp+0x20]
000074113b7cee18  vmovaps xmm3, [rsp+0x30]
000074113b7cee1e  vmovaps xmm4, [rsp+0x40]
000074113b7cee24  vmovaps xmm5, [rsp+0x50]
000074113b7cee2a  vmovaps xmm6, [rsp+0x60]
000074113b7cee30  vmovaps xmm7, [rsp+0x70]
000074113b7cee36  vmovaps xmm8, [rsp+0x80]
000074113b7cee3f  vmovaps xmm9, [rsp+0x90]
000074113b7cee48  vmovaps xmm10, [rsp+0xA0]
000074113b7cee51  vmovaps xmm11, [rsp+0xB0]
000074113b7cee5a  vmovaps xmm12, [rsp+0xC0]
000074113b7cee63  vmovaps xmm14, [rsp+0xD0]
000074113b7cee6c  vmovaps xmm15, [rsp+0xE0]
000074113b7cee75  add rsp, 0xF0
000074113b7cee7c  pop r11
000074113b7cee7e  pop r10
000074113b7cee80  pop r9
000074113b7cee82  pop r8
000074113b7cee84  pop rsi
000074113b7cee85  pop rdi
000074113b7cee86  pop rdx
000074113b7cee87  pop rcx
000074113b7cee88  pop rax
000074113b7cee89  add rsp, 0x08
000074113b7cee8d  jmp 0x000074113B7CEC71
000074113b7cee92  call 0x000074113B6C2240
000074113b7cee97  jmp 0x000074113B7CEC8B
000074113b7cee9c  sub rsp, 0x08
000074113b7ceea0  push rax
000074113b7ceea1  push rcx
000074113b7ceea2  push rdx
000074113b7ceea3  push rdi
000074113b7ceea4  push rsi
000074113b7ceea5  push r8
000074113b7ceea7  push r9
000074113b7ceea9  push r10
000074113b7ceeab  push r11
000074113b7ceead  sub rsp, 0xF0
000074113b7ceeb4  vmovaps [rsp], xmm0
000074113b7ceeb9  vmovaps [rsp+0x10], xmm1
000074113b7ceebf  vmovaps [rsp+0x20], xmm2
000074113b7ceec5  vmovaps [rsp+0x30], xmm3
000074113b7ceecb  vmovaps [rsp+0x40], xmm4
000074113b7ceed1  vmovaps [rsp+0x50], xmm5
000074113b7ceed7  vmovaps [rsp+0x60], xmm6
000074113b7ceedd  vmovaps [rsp+0x70], xmm7
000074113b7ceee3  vmovaps [rsp+0x80], xmm8
000074113b7ceeec  vmovaps [rsp+0x90], xmm9
000074113b7ceef5  vmovaps [rsp+0xA0], xmm10
000074113b7ceefe  vmovaps [rsp+0xB0], xmm11
000074113b7cef07  vmovaps [rsp+0xC0], xmm12
000074113b7cef10  vmovaps [rsp+0xD0], xmm13
000074113b7cef19  vmovaps [rsp+0xE0], xmm15
000074113b7cef22  sub rsp, 0x30
000074113b7cef26  movaps [rsp], xmm14
000074113b7cef2b  movaps [rsp+0x10], xmm1
000074113b7cef30  movaps [rsp+0x20], xmm15
000074113b7cef36  lea rdi, [rsp]
000074113b7cef3a  mov esi, 0x00
000074113b7cef3f  mov rax, 0x629073062530
000074113b7cef49  call rax
000074113b7cef4b  movaps xmm14, [rsp]
000074113b7cef50  add rsp, 0x30
000074113b7cef54  vmovaps xmm0, [rsp]
000074113b7cef59  vmovaps xmm1, [rsp+0x10]
000074113b7cef5f  vmovaps xmm2, [rsp+0x20]
000074113b7cef65  vmovaps xmm3, [rsp+0x30]
000074113b7cef6b  vmovaps xmm4, [rsp+0x40]
000074113b7cef71  vmovaps xmm5, [rsp+0x50]
000074113b7cef77  vmovaps xmm6, [rsp+0x60]
000074113b7cef7d  vmovaps xmm7, [rsp+0x70]
000074113b7cef83  vmovaps xmm8, [rsp+0x80]
000074113b7cef8c  vmovaps xmm9, [rsp+0x90]
000074113b7cef95  vmovaps xmm10, [rsp+0xA0]
000074113b7cef9e  vmovaps xmm11, [rsp+0xB0]
000074113b7cefa7  vmovaps xmm12, [rsp+0xC0]
000074113b7cefb0  vmovaps xmm13, [rsp+0xD0]
000074113b7cefb9  vmovaps xmm15, [rsp+0xE0]
000074113b7cefc2  add rsp, 0xF0
000074113b7cefc9  pop r11
000074113b7cefcb  pop r10
000074113b7cefcd  pop r9
000074113b7cefcf  pop r8
000074113b7cefd1  pop rsi
000074113b7cefd2  pop rdi
000074113b7cefd3  pop rdx
000074113b7cefd4  pop rcx
000074113b7cefd5  pop rax
000074113b7cefd6  add rsp, 0x08
000074113b7cefda  jmp 0x000074113B7CECAE
000074113b7cefdf  call 0x000074113B6C34C0
000074113b7cefe4  jmp 0x000074113B7CECC4
000074113b7cefe9  int3
000074113b7cefea  nop [rax+rax*1], ax
000074113b7ceff0  mov rax, [r15+0xF8]
000074113b7ceff7  lea r14, [rax-0x120]
000074113b7ceffe  mov [r15+0xF8], r14
000074113b7cf005  mov rax, [r15+0x50]
000074113b7cf009  movups xmm1, [r13+rax*1]
000074113b7cf00f  lea r12, [rax+0x10]
000074113b7cf013  movups xmm15, [r13+r12*1]
000074113b7cf019  mov qword ptr [r15+0x48], 0x00
000074113b7cf021  lea r12, [r14+0xD0]
000074113b7cf028  movq xmm14, qword ptr [r15+0x200]
000074113b7cf031  movq xmm13, qword ptr [r15+0x1F0]
000074113b7cf03a  movq r11, xmm14
000074113b7cf03f  movq r10, xmm13
000074113b7cf044  mov [r13+r12*1], r11
000074113b7cf049  lea r12, [r14+0xD8]
000074113b7cf050  mov [r13+r12*1], r10
000074113b7cf055  lea r12, [rax+0x80]
000074113b7cf05c  movups xmm14, [r13+r12*1]
000074113b7cf062  lea r12, [rax+0x90]
000074113b7cf069  movups xmm13, [r13+r12*1]
000074113b7cf06f  lea r12, [r14+0xE0]
000074113b7cf076  movq xmm12, qword ptr [r15+0x1E0]
000074113b7cf07f  movq xmm11, qword ptr [r15+0x1D0]
000074113b7cf088  movq r11, xmm12
000074113b7cf08d  movq r10, xmm11
000074113b7cf092  mov [r13+r12*1], r11
000074113b7cf097  lea r12, [r14+0xE8]
000074113b7cf09e  mov [r13+r12*1], r10
000074113b7cf0a3  lea r12, [rax+0xC0]
000074113b7cf0aa  movups xmm12, [r13+r12*1]
000074113b7cf0b0  lea r12, [rax+0xD0]
000074113b7cf0b7  movups xmm11, [r13+r12*1]
000074113b7cf0bd  movups [r13+r14*1], xmm1
000074113b7cf0c3  lea r12, [rax+0x20]
000074113b7cf0c7  movups xmm1, [r13+r12*1]
000074113b7cf0cd  lea r12, [rax+0x30]
000074113b7cf0d1  movups xmm10, [r13+r12*1]
000074113b7cf0d7  lea r12, [r14+0xF0]
000074113b7cf0de  movq xmm9, qword ptr [r15+0x1C0]
000074113b7cf0e7  movq xmm8, qword ptr [r15+0x1B0]
000074113b7cf0f0  movq r11, xmm9
000074113b7cf0f5  movq r10, xmm8
000074113b7cf0fa  mov [r13+r12*1], r11
000074113b7cf0ff  lea r12, [r14+0xF8]
000074113b7cf106  mov [r13+r12*1], r10
000074113b7cf10b  lea r12, [rax+0x40]
000074113b7cf10f  movups xmm9, [r13+r12*1]
000074113b7cf115  lea r12, [rax+0x50]
000074113b7cf119  movups xmm8, [r13+r12*1]
000074113b7cf11f  lea r12, [r14+0x100]
000074113b7cf126  movq xmm7, qword ptr [r15+0x1A0]
000074113b7cf12f  movq xmm6, qword ptr [r15+0x190]
000074113b7cf138  movq r11, xmm7
000074113b7cf13d  movq r10, xmm6
000074113b7cf142  mov [r13+r12*1], r11
000074113b7cf147  lea r12, [r14+0x108]
000074113b7cf14e  mov [r13+r12*1], r10
000074113b7cf153  lea r12, [rax+0x100]
000074113b7cf15a  movups xmm7, [r13+r12*1]
000074113b7cf160  lea r12, [rax+0x110]
000074113b7cf167  movups xmm6, [r13+r12*1]
000074113b7cf16d  lea r12, [r14+0xB0]
000074113b7cf174  movups [r13+r12*1], xmm10
000074113b7cf17a  lea r12, [r14+0xC0]
000074113b7cf181  movups [r13+r12*1], xmm1
000074113b7cf187  lea r12, [rax+0x140]
000074113b7cf18e  movups xmm1, [r13+r12*1]
000074113b7cf194  lea r12, [rax+0x150]
000074113b7cf19b  movups xmm10, [r13+r12*1]
000074113b7cf1a1  lea r12, [r14+0x110]
000074113b7cf1a8  mov r11, [r15+0xE8]
000074113b7cf1af  mov [r13+r12*1], r11
000074113b7cf1b4  lea r12, [rax+0x180]
000074113b7cf1bb  movups xmm5, [r13+r12*1]
000074113b7cf1c1  lea r12, [rax+0x190]
000074113b7cf1c8  movups xmm4, [r13+r12*1]
000074113b7cf1ce  lea r12, [rax+0x1C0]
000074113b7cf1d5  movups xmm3, [r13+r12*1]
000074113b7cf1db  lea r12, [rax+0x1D0]
000074113b7cf1e2  movups xmm2, [r13+r12*1]
000074113b7cf1e8  lea r12, [rax+0x60]
000074113b7cf1ec  vmovaps [rsp+0x10], xmm1
000074113b7cf1f2  movups xmm1, [r13+r12*1]
000074113b7cf1f8  lea r12, [rax+0x70]
000074113b7cf1fc  vmovaps [rsp+0x20], xmm1
000074113b7cf202  movups xmm1, [r13+r12*1]
000074113b7cf208  lea r12, [r14+0x70]
000074113b7cf20c  movups [r13+r12*1], xmm4
000074113b7cf212  lea r12, [r14+0x80]
000074113b7cf219  movups [r13+r12*1], xmm5
000074113b7cf21f  lea r12, [rax+0xA0]
000074113b7cf226  movups xmm5, [r13+r12*1]
000074113b7cf22c  lea r12, [rax+0xB0]
000074113b7cf233  movups xmm4, [r13+r12*1]
000074113b7cf239  lea r12, [r14+0x90]
000074113b7cf240  movups [r13+r12*1], xmm2
000074113b7cf246  lea r12, [r14+0xA0]
000074113b7cf24d  movups [r13+r12*1], xmm3
000074113b7cf253  lea r12, [rax+0xE0]
000074113b7cf25a  movups xmm3, [r13+r12*1]
000074113b7cf260  lea r12, [rax+0xF0]
000074113b7cf267  movups xmm2, [r13+r12*1]
000074113b7cf26d  lea r12, [rax+0x120]
000074113b7cf274  vmovaps [rsp+0x30], xmm1
000074113b7cf27a  movups xmm1, [r13+r12*1]
000074113b7cf280  lea r12, [rax+0x130]
000074113b7cf287  vmovaps [rsp+0x40], xmm1
000074113b7cf28d  movups xmm1, [r13+r12*1]
000074113b7cf293  lea r12, [rax+0x160]
000074113b7cf29a  vmovaps [rsp+0x50], xmm1
000074113b7cf2a0  movups xmm1, [r13+r12*1]
000074113b7cf2a6  lea r12, [rax+0x170]
000074113b7cf2ad  vmovaps [rsp+0x60], xmm1
000074113b7cf2b3  movups xmm1, [r13+r12*1]
000074113b7cf2b9  lea r12, [rax+0x1A0]
000074113b7cf2c0  vmovaps [rsp+0x70], xmm1
000074113b7cf2c6  movups xmm1, [r13+r12*1]
000074113b7cf2cc  lea r12, [rax+0x1B0]
000074113b7cf2d3  vmovaps [rsp+0x80], xmm1
000074113b7cf2dc  movups xmm1, [r13+r12*1]
000074113b7cf2e2  lea r12, [rax+0x1E0]
000074113b7cf2e9  vmovaps [rsp+0x90], xmm1
000074113b7cf2f2  movups xmm1, [r13+r12*1]
000074113b7cf2f8  lea r12, [rax+0x1F0]
000074113b7cf2ff  vmovaps [rsp+0xA0], xmm1
000074113b7cf308  movups xmm1, [r13+r12*1]
000074113b7cf30e  mov qword ptr [r15+0x50], 0x4308D0
000074113b7cf316  lea rax, [r14+0x50]
000074113b7cf31a  vmovaps [rsp+0xB0], xmm1
000074113b7cf323  vmovaps xmm1, [rsp+0x60]
000074113b7cf329  movups [r13+rax*1], xmm1
000074113b7cf32f  lea rax, [r14+0x60]
000074113b7cf333  vmovaps xmm1, [rsp+0x10]
000074113b7cf339  movups [r13+rax*1], xmm1
000074113b7cf33f  lea rax, [r14+0x40]
000074113b7cf343  vmovaps xmm1, [rsp+0x70]
000074113b7cf349  movups [r13+rax*1], xmm1
000074113b7cf34f  lea rax, [r14+0x20]
000074113b7cf353  vmovaps xmm1, [rsp+0xA0]
000074113b7cf35c  movups [r13+rax*1], xmm1
000074113b7cf362  lea rax, [r14+0x30]
000074113b7cf366  vmovaps xmm1, [rsp+0x90]
000074113b7cf36f  movups [r13+rax*1], xmm1
000074113b7cf375  lea rax, [r14+0x10]
000074113b7cf379  vmovaps xmm1, [rsp+0xB0]
000074113b7cf382  movups [r13+rax*1], xmm1
000074113b7cf388  mov rax, [r15+0x40]
000074113b7cf38c  vxorps xmm1, xmm1, xmm1
000074113b7cf390  vpbroadcastq xmm1, xmm1
000074113b7cf395  vmovaps [rsp+0x10], xmm1
000074113b7cf39b  vxorps xmm1, xmm1, xmm1
000074113b7cf39f  vpbroadcastq xmm1, xmm1
000074113b7cf3a4  lea r12, [rax+0x30]
000074113b7cf3a8  mov r11, [r13+r12*1]
000074113b7cf3ad  lea r12, [rax+0x38]
000074113b7cf3b1  mov r10, [r13+r12*1]
000074113b7cf3b6  vmovaps [rsp+0x60], xmm1
000074113b7cf3bc  movq xmm1, r11
000074113b7cf3c1  vmovaps [rsp+0x70], xmm1
000074113b7cf3c7  movq xmm1, r10
000074113b7cf3cc  vmovaps [rsp+0x90], xmm1
000074113b7cf3d5  vmovaps xmm1, [rsp+0x70]
000074113b7cf3db  movq xmm1, xmm1
000074113b7cf3df  vmovaps [rsp+0x70], xmm1
000074113b7cf3e5  vmovaps xmm1, [rsp+0x90]
000074113b7cf3ee  movq xmm1, xmm1
000074113b7cf3f2  vmovaps [rsp+0x90], xmm1
000074113b7cf3fb  movq xmm1, xmm1
000074113b7cf3ff  movaps [r15+0x270], xmm1
000074113b7cf407  vmovaps [rsp+0xA0], xmm7
000074113b7cf410  vmovaps xmm1, [rsp+0xA0]
000074113b7cf419  por xmm7, xmm1
000074113b7cf41d  lea r12, [rax+0x20]
000074113b7cf421  mov r11, [r13+r12*1]
000074113b7cf426  lea r12, [rax+0x28]
000074113b7cf42a  mov r10, [r13+r12*1]
000074113b7cf42f  movq xmm1, r11
000074113b7cf434  vmovaps [rsp+0xA0], xmm1
000074113b7cf43d  movq xmm1, r10
000074113b7cf442  vmovaps [rsp+0xB0], xmm1
000074113b7cf44b  vmovaps xmm1, [rsp+0xA0]
000074113b7cf454  movq xmm1, xmm1
000074113b7cf458  vmovaps [rsp+0xA0], xmm1
000074113b7cf461  vmovaps xmm1, [rsp+0xB0]
000074113b7cf46a  movq xmm1, xmm1
000074113b7cf46e  vmovaps [rsp+0xB0], xmm2
000074113b7cf477  vmovaps [rsp+0xC0], xmm1
000074113b7cf480  vmovaps xmm1, [rsp+0xB0]
000074113b7cf489  por xmm2, xmm1
000074113b7cf48d  vmovaps xmm1, [rsp+0x40]
000074113b7cf493  vmovaps [rsp+0xB0], xmm15
000074113b7cf49c  vmovaps xmm15, [rsp+0x40]
000074113b7cf4a2  por xmm1, xmm15
000074113b7cf4a7  vmovaps [rsp+0x40], xmm3
000074113b7cf4ad  vmovaps xmm15, [rsp+0x40]
000074113b7cf4b3  por xmm3, xmm15
000074113b7cf4b8  vmovaps [rsp+0x40], xmm10
000074113b7cf4be  vmovaps xmm15, [rsp+0x40]
000074113b7cf4c4  por xmm10, xmm15
000074113b7cf4c9  vmovaps [rsp+0x40], xmm12
000074113b7cf4cf  vmovaps xmm15, [rsp+0x40]
000074113b7cf4d5  por xmm12, xmm15
000074113b7cf4da  lea r12, [rax+0x10]
000074113b7cf4de  mov r11, [r13+r12*1]
000074113b7cf4e3  lea r12, [rax+0x18]
000074113b7cf4e7  mov r10, [r13+r12*1]
000074113b7cf4ec  movq xmm15, r11
000074113b7cf4f1  vmovaps [rsp+0x40], xmm1
000074113b7cf4f7  movq xmm1, r10
000074113b7cf4fc  movq xmm15, xmm15
000074113b7cf501  movq xmm1, xmm1
000074113b7cf505  vmovaps [rsp+0xD0], xmm1
000074113b7cf50e  vmovaps xmm1, [rsp+0x80]
000074113b7cf517  vmovaps [rsp+0xE0], xmm15
000074113b7cf520  vmovaps xmm15, [rsp+0x80]
000074113b7cf529  por xmm1, xmm15
000074113b7cf52e  vmovaps xmm15, [rsp+0x30]
000074113b7cf534  vmovaps [rsp+0x80], xmm1
000074113b7cf53d  vmovaps xmm1, [rsp+0x30]
000074113b7cf543  por xmm15, xmm1
000074113b7cf548  vmovaps xmm1, [rsp+0x20]
000074113b7cf54e  vmovaps [rsp+0x30], xmm15
000074113b7cf554  vmovaps xmm15, [rsp+0x20]
000074113b7cf55a  por xmm1, xmm15
000074113b7cf55f  vmovaps [rsp+0x20], xmm6
000074113b7cf565  vmovaps xmm15, [rsp+0x20]
000074113b7cf56b  por xmm6, xmm15
000074113b7cf570  vmovaps [rsp+0x20], xmm13
000074113b7cf576  vmovaps xmm15, [rsp+0x20]
000074113b7cf57c  por xmm13, xmm15
000074113b7cf581  vmovaps [rsp+0x20], xmm8
000074113b7cf587  vmovaps xmm15, [rsp+0x20]
000074113b7cf58d  por xmm8, xmm15
000074113b7cf592  vmovaps [rsp+0x20], xmm9
000074113b7cf598  vmovaps xmm15, [rsp+0x20]
000074113b7cf59e  por xmm9, xmm15
000074113b7cf5a3  mov r12, [r13+rax*1]
000074113b7cf5a8  vmovq xmm15, r12
000074113b7cf5ad  vpbroadcastq xmm15, xmm15
000074113b7cf5b2  vmovaps [rsp+0x20], xmm1
000074113b7cf5b8  vxorps xmm1, xmm1, xmm1
000074113b7cf5bc  vpbroadcastq xmm1, xmm1
000074113b7cf5c1  vmovaps [rsp+0xF0], xmm1
000074113b7cf5ca  movups xmm1, [r13+r14*1]
000074113b7cf5d0  vmovaps [rsp+0x100], xmm1
000074113b7cf5d9  vxorps xmm1, xmm1, xmm1
000074113b7cf5dd  vpbroadcastq xmm1, xmm1
000074113b7cf5e2  lea r12, [rax+0x08]
000074113b7cf5e6  mov rax, [r13+r12*1]
000074113b7cf5eb  vmovaps [rsp+0x110], xmm1
000074113b7cf5f4  movq xmm1, rax
000074113b7cf5f9  movaps [r15+0x240], xmm1
000074113b7cf601  mov qword ptr [r15+0x60], 0x4308D0
000074113b7cf609  mov qword ptr [r15+0x58], 0x40
000074113b7cf611  vmovaps xmm1, [rsp+0x10]
000074113b7cf617  vmovaps [rsp+0x10], xmm15
000074113b7cf61d  vmovaps xmm15, [rsp+0x100]
000074113b7cf626  vmovaps [rsp+0x100], xmm14
000074113b7cf62f  vmovaps xmm14, [rsp+0x10]
000074113b7cf635  vmovaps [rsp+0x10], xmm13
000074113b7cf63b  vmovaps [rsp+0x120], xmm12
000074113b7cf644  movaps xmm13, xmm1
000074113b7cf648  vfmadd231pd xmm13, xmm15, xmm14
000074113b7cf64d  vcmppd xmm12, xmm13, xmm13, 0x03
000074113b7cf653  vptest xmm12, xmm12
000074113b7cf658  jnz 0x000074113B7D0283
000074113b7cf65e  vmovaps xmm1, [rsp+0x60]
000074113b7cf664  vmovaps xmm15, [rsp+0xB0]
000074113b7cf66d  vmovaps [rsp+0x60], xmm13
000074113b7cf673  movaps xmm12, xmm1
000074113b7cf677  vfmadd231pd xmm12, xmm15, xmm14
000074113b7cf67c  vcmppd xmm13, xmm12, xmm12, 0x03
000074113b7cf682  vptest xmm13, xmm13
000074113b7cf687  jnz 0x000074113B7D03DC
000074113b7cf68d  vmovaps xmm1, [rsp+0x50]
000074113b7cf693  vmovaps xmm13, [rsp+0x50]
000074113b7cf699  por xmm1, xmm13
000074113b7cf69e  vmovaps [rsp+0x50], xmm4
000074113b7cf6a4  vmovaps xmm13, [rsp+0x50]
000074113b7cf6aa  por xmm4, xmm13
000074113b7cf6af  vmovaps [rsp+0x50], xmm5
000074113b7cf6b5  vmovaps xmm13, [rsp+0x50]
000074113b7cf6bb  por xmm5, xmm13
000074113b7cf6c0  vmovaps [rsp+0x50], xmm11
000074113b7cf6c6  vmovaps xmm13, [rsp+0x50]
000074113b7cf6cc  por xmm11, xmm13
000074113b7cf6d1  vmovaps xmm13, [rsp+0x100]
000074113b7cf6da  vmovaps [rsp+0x50], xmm1
000074113b7cf6e0  vmovaps xmm1, [rsp+0x100]
000074113b7cf6e9  por xmm13, xmm1
000074113b7cf6ee  vmovaps [rsp+0xB0], xmm15
000074113b7cf6f7  vmovaps xmm1, [rsp+0xB0]
000074113b7cf700  por xmm15, xmm1
000074113b7cf705  lea rax, [r14+0xC0]
000074113b7cf70c  movups xmm1, [r13+rax*1]
000074113b7cf712  xor eax, eax
000074113b7cf714  mov r12d, 0x40
000074113b7cf71a  mov r11d, 0x200
000074113b7cf720  cmp r12, r11
000074113b7cf723  cmc
000074113b7cf724  lahf
000074113b7cf725  seto al
000074113b7cf728  mov [r15+0x108], eax
000074113b7cf72f  vmovaps [rsp+0xB0], xmm1
000074113b7cf738  vmovaps xmm1, [rsp+0xF0]
000074113b7cf741  vmovaps [rsp+0xF0], xmm15
000074113b7cf74a  vmovaps xmm15, [rsp+0xB0]
000074113b7cf753  vmovaps [rsp+0xB0], xmm13
000074113b7cf75c  vmovaps [rsp+0x100], xmm12
000074113b7cf765  movaps xmm13, xmm1
000074113b7cf769  vfmadd231pd xmm13, xmm15, xmm14
000074113b7cf76e  vcmppd xmm12, xmm13, xmm13, 0x03
000074113b7cf774  vptest xmm12, xmm12
000074113b7cf779  jnz 0x000074113B7D053F
000074113b7cf77f  lea rax, [r14+0xB0]
000074113b7cf786  movups xmm1, [r13+rax*1]
000074113b7cf78c  vmovaps xmm15, [rsp+0x110]
000074113b7cf795  vmovaps [rsp+0x110], xmm13
000074113b7cf79e  movaps xmm12, xmm15
000074113b7cf7a2  vfmadd231pd xmm12, xmm1, xmm14
000074113b7cf7a7  vcmppd xmm13, xmm12, xmm12, 0x03
000074113b7cf7ad  vptest xmm13, xmm13
000074113b7cf7b2  jnz 0x000074113B7D06A2
000074113b7cf7b8  vmovaps [rsp+0x130], xmm9
000074113b7cf7c1  vmovaps xmm1, [rsp+0x130]
000074113b7cf7ca  por xmm9, xmm1
000074113b7cf7cf  movaps [r15+0x210], xmm9
000074113b7cf7d7  vmovaps [rsp+0x130], xmm8
000074113b7cf7e0  vmovaps xmm1, [rsp+0x130]
000074113b7cf7e9  por xmm8, xmm1
000074113b7cf7ee  movaps [r15+0x1C0], xmm8
000074113b7cf7f6  vmovaps xmm1, [rsp+0x10]
000074113b7cf7fc  vmovaps xmm15, [rsp+0x10]
000074113b7cf802  por xmm1, xmm15
000074113b7cf807  movaps [r15+0x280], xmm1
000074113b7cf80f  vmovaps [rsp+0x10], xmm6
000074113b7cf815  vmovaps xmm14, [rsp+0x10]
000074113b7cf81b  por xmm6, xmm14
000074113b7cf820  movaps [r15+0x2A0], xmm6
000074113b7cf828  vmovaps xmm15, [rsp+0x20]
000074113b7cf82e  vmovaps xmm14, [rsp+0x20]
000074113b7cf834  por xmm15, xmm14
000074113b7cf839  movaps [r15+0x2E0], xmm15
000074113b7cf841  vmovaps xmm14, [rsp+0x30]
000074113b7cf847  vmovaps xmm13, [rsp+0x30]
000074113b7cf84d  por xmm14, xmm13
000074113b7cf852  movaps [r15+0x1F0], xmm14
000074113b7cf85a  vmovaps xmm13, [rsp+0xF0]
000074113b7cf863  vmovaps [rsp+0x10], xmm1
000074113b7cf869  vmovaps xmm1, [rsp+0xF0]
000074113b7cf872  por xmm13, xmm1
000074113b7cf877  movaps [r15+0x250], xmm13
000074113b7cf87f  vmovaps xmm1, [rsp+0xB0]
000074113b7cf888  vmovaps xmm13, [rsp+0xB0]
000074113b7cf891  por xmm1, xmm13
000074113b7cf896  movaps [r15+0x260], xmm1
000074113b7cf89e  vmovaps [rsp+0x20], xmm11
000074113b7cf8a4  vmovaps xmm13, [rsp+0x20]
000074113b7cf8aa  por xmm11, xmm13
000074113b7cf8af  movaps [r15+0x290], xmm11
000074113b7cf8b7  vmovaps [rsp+0x20], xmm5
000074113b7cf8bd  vmovaps xmm13, [rsp+0x20]
000074113b7cf8c3  por xmm5, xmm13
000074113b7cf8c8  movaps [r15+0x2C0], xmm5
000074113b7cf8d0  movq xmm13, qword ptr [r15+0x240]
000074113b7cf8d9  vmovaps [rsp+0x20], xmm13
000074113b7cf8df  vpermilpd xmm13, xmm13, 0x00
000074113b7cf8e5  vmovaps [rsp+0x30], xmm1
000074113b7cf8eb  vmovaps xmm1, [rsp+0x60]
000074113b7cf8f1  vmovaps [rsp+0x60], xmm15
000074113b7cf8f7  vmovaps [rsp+0xB0], xmm14
000074113b7cf900  movaps xmm15, xmm1
000074113b7cf904  vfmadd231pd xmm15, xmm9, xmm13
000074113b7cf909  vcmppd xmm14, xmm15, xmm15, 0x03
000074113b7cf90f  vptest xmm14, xmm14
000074113b7cf914  jnz 0x000074113B7D07FB
000074113b7cf91a  vmovaps xmm1, [rsp+0x20]
000074113b7cf920  vpermilpd xmm1, xmm1, 0x00
000074113b7cf926  vmovaps xmm14, [rsp+0x110]
000074113b7cf92f  vmovaps xmm13, [rsp+0x60]
000074113b7cf935  vmovaps [rsp+0x60], xmm15
000074113b7cf93b  movaps xmm9, xmm14
000074113b7cf93f  vfmadd231pd xmm9, xmm13, xmm1
000074113b7cf944  vcmppd xmm15, xmm9, xmm9, 0x03
000074113b7cf94a  vptest xmm15, xmm15
000074113b7cf94f  jnz 0x000074113B7D0954
000074113b7cf955  vmovaps xmm1, [rsp+0x20]
000074113b7cf95b  vpermilpd xmm1, xmm1, 0x00
000074113b7cf961  vmovaps xmm15, [rsp+0x100]
000074113b7cf96a  movaps xmm14, xmm15
000074113b7cf96e  vfmadd231pd xmm14, xmm8, xmm1
000074113b7cf973  vcmppd xmm13, xmm14, xmm14, 0x03
000074113b7cf979  vptest xmm13, xmm13
000074113b7cf97e  jnz 0x000074113B7D0AAD
000074113b7cf984  vmovaps [rsp+0xF0], xmm4
000074113b7cf98d  vmovaps xmm1, [rsp+0xF0]
000074113b7cf996  por xmm4, xmm1
000074113b7cf99a  movaps [r15+0x1D0], xmm4
000074113b7cf9a2  vmovaps xmm1, [rsp+0x20]
000074113b7cf9a8  vpermilpd xmm1, xmm1, 0x00
000074113b7cf9ae  vmovaps xmm13, [rsp+0xB0]
000074113b7cf9b7  movaps xmm15, xmm12
000074113b7cf9bb  vfmadd231pd xmm15, xmm13, xmm1
000074113b7cf9c0  vcmppd xmm8, xmm15, xmm15, 0x03
000074113b7cf9c6  vptest xmm8, xmm8
000074113b7cf9cb  jnz 0x000074113B7D0C06
000074113b7cf9d1  vmovaps xmm1, [rsp+0x80]
000074113b7cf9da  vmovaps xmm13, [rsp+0x80]
000074113b7cf9e3  por xmm1, xmm13
000074113b7cf9e8  movaps [r15+0x200], xmm1
000074113b7cf9f0  vmovaps xmm13, [rsp+0x50]
000074113b7cf9f6  vmovaps xmm12, [rsp+0x50]
000074113b7cf9fc  por xmm13, xmm12
000074113b7cfa01  movaps [r15+0x1E0], xmm13
000074113b7cfa09  vmovaps [rsp+0x20], xmm10
000074113b7cfa0f  vmovaps xmm13, [rsp+0x20]
000074113b7cfa15  por xmm10, xmm13
000074113b7cfa1a  movaps [r15+0x2B0], xmm10
000074113b7cfa22  vmovaps [rsp+0x20], xmm3
000074113b7cfa28  vmovaps xmm13, [rsp+0x20]
000074113b7cfa2e  por xmm3, xmm13
000074113b7cfa33  movaps [r15+0x300], xmm3
000074113b7cfa3b  vmovaps xmm8, [rsp+0xE0]
000074113b7cfa44  vpermilpd xmm8, xmm8, 0x00
000074113b7cfa4a  vmovaps xmm3, [rsp+0x60]
000074113b7cfa50  vmovaps [rsp+0x20], xmm1
000074113b7cfa56  vmovaps xmm1, [rsp+0x30]
000074113b7cfa5c  vmovaps [rsp+0x30], xmm15
000074113b7cfa62  vmovaps [rsp+0x50], xmm14
000074113b7cfa68  movaps xmm15, xmm3
000074113b7cfa6c  vfmadd231pd xmm15, xmm1, xmm8
000074113b7cfa71  vcmppd xmm14, xmm15, xmm15, 0x03
000074113b7cfa77  vptest xmm14, xmm14
000074113b7cfa7c  jnz 0x000074113B7D0D5F
000074113b7cfa82  vmovaps xmm1, [rsp+0xE0]
000074113b7cfa8b  vpermilpd xmm1, xmm1, 0x00
000074113b7cfa91  movaps xmm8, xmm9
000074113b7cfa95  vfmadd231pd xmm8, xmm5, xmm1
000074113b7cfa9a  vcmppd xmm14, xmm8, xmm8, 0x03
000074113b7cfaa0  vptest xmm14, xmm14
000074113b7cfaa5  jnz 0x000074113B7D0EB7
000074113b7cfaab  vmovaps xmm1, [rsp+0xE0]
000074113b7cfab4  vpermilpd xmm1, xmm1, 0x00
000074113b7cfaba  vmovaps xmm14, [rsp+0x50]
000074113b7cfac0  vmovaps xmm9, [rsp+0x10]
000074113b7cfac6  movaps xmm5, xmm14
000074113b7cfaca  vfmadd231pd xmm5, xmm9, xmm1
000074113b7cfacf  vcmppd xmm3, xmm5, xmm5, 0x03
000074113b7cfad4  vptest xmm3, xmm3
000074113b7cfad9  jnz 0x000074113B7D100F
000074113b7cfadf  vmovaps xmm1, [rsp+0xE0]
000074113b7cfae8  vpermilpd xmm1, xmm1, 0x00
000074113b7cfaee  vmovaps xmm14, [rsp+0x30]
000074113b7cfaf4  movaps xmm9, xmm14
000074113b7cfaf8  vfmadd231pd xmm9, xmm4, xmm1
000074113b7cfafd  vcmppd xmm3, xmm9, xmm9, 0x03
000074113b7cfb03  vptest xmm3, xmm3
000074113b7cfb08  jnz 0x000074113B7D1166
000074113b7cfb0e  vmovaps xmm1, [rsp+0x120]
000074113b7cfb17  vmovaps xmm14, [rsp+0x120]
000074113b7cfb20  por xmm1, xmm14
000074113b7cfb25  movaps [r15+0x180], xmm1
000074113b7cfb2d  vmovaps xmm14, [rsp+0x40]
000074113b7cfb33  vmovaps xmm4, [rsp+0x40]
000074113b7cfb39  por xmm14, xmm4
000074113b7cfb3e  movaps [r15+0x2D0], xmm14
000074113b7cfb46  vmovaps [rsp+0x10], xmm2
000074113b7cfb4c  vmovaps xmm4, [rsp+0x10]
000074113b7cfb52  por xmm2, xmm4
000074113b7cfb56  movaps [r15+0x2F0], xmm2
000074113b7cfb5e  vmovaps xmm3, [rsp+0xD0]
000074113b7cfb67  vpermilpd xmm3, xmm3, 0x00
000074113b7cfb6d  vmovaps [rsp+0x10], xmm1
000074113b7cfb73  movaps xmm2, xmm8
000074113b7cfb77  vfmadd231pd xmm2, xmm13, xmm3
000074113b7cfb7c  vcmppd xmm1, xmm2, xmm2, 0x03
000074113b7cfb81  vptest xmm1, xmm1
000074113b7cfb86  jnz 0x000074113B7D12BE
000074113b7cfb8c  vmovaps xmm1, [rsp+0xD0]
000074113b7cfb95  vpermilpd xmm1, xmm1, 0x00
000074113b7cfb9b  vmovaps xmm13, [rsp+0x10]
000074113b7cfba1  movaps xmm8, xmm15
000074113b7cfba5  vfmadd231pd xmm8, xmm13, xmm1
000074113b7cfbaa  vcmppd xmm3, xmm8, xmm8, 0x03
000074113b7cfbb0  vptest xmm3, xmm3
000074113b7cfbb5  jnz 0x000074113B7D1415
000074113b7cfbbb  lea rax, [r14+0x80]
000074113b7cfbc2  movups xmm1, [r13+rax*1]
000074113b7cfbc8  movaps [r15+0x190], xmm1
000074113b7cfbd0  vmovaps xmm15, [rsp+0xD0]
000074113b7cfbd9  vpermilpd xmm15, xmm15, 0x00
000074113b7cfbdf  movaps xmm13, xmm5
000074113b7cfbe3  vfmadd231pd xmm13, xmm11, xmm15
000074113b7cfbe8  vcmppd xmm3, xmm13, xmm13, 0x03
000074113b7cfbee  vptest xmm3, xmm3
000074113b7cfbf3  jnz 0x000074113B7D1578
000074113b7cfbf9  vmovaps xmm15, [rsp+0xD0]
000074113b7cfc02  vpermilpd xmm15, xmm15, 0x00
000074113b7cfc08  movaps xmm11, xmm9
000074113b7cfc0c  vfmadd231pd xmm11, xmm4, xmm15
000074113b7cfc11  vcmppd xmm5, xmm11, xmm11, 0x03
000074113b7cfc17  vptest xmm5, xmm5
000074113b7cfc1c  jnz 0x000074113B7D16D1
000074113b7cfc22  vmovaps [rsp+0x10], xmm7
000074113b7cfc28  vmovaps xmm9, [rsp+0x10]
000074113b7cfc2e  por xmm7, xmm9
000074113b7cfc33  movaps [r15+0x160], xmm7
000074113b7cfc3b  lea rax, [r14+0x40]
000074113b7cfc3f  movups xmm15, [r13+rax*1]
000074113b7cfc45  lea rax, [r14+0x50]
000074113b7cfc49  movups xmm9, [r13+rax*1]
000074113b7cfc4f  movaps [r15+0x1B0], xmm15
000074113b7cfc57  movaps [r15+0x1A0], xmm9
000074113b7cfc5f  vmovaps xmm5, [rsp+0xA0]
000074113b7cfc68  vpermilpd xmm5, xmm5, 0x00
000074113b7cfc6e  movaps xmm4, xmm2
000074113b7cfc71  vfmadd231pd xmm4, xmm14, xmm5
000074113b7cfc76  vcmppd xmm3, xmm4, xmm4, 0x03
000074113b7cfc7b  vptest xmm3, xmm3
000074113b7cfc80  jnz 0x000074113B7D183E
000074113b7cfc86  vmovaps xmm14, [rsp+0xA0]
000074113b7cfc8f  vpermilpd xmm14, xmm14, 0x00
000074113b7cfc95  movaps xmm5, xmm8
000074113b7cfc99  vfmadd231pd xmm5, xmm7, xmm14
000074113b7cfc9e  vcmppd xmm3, xmm5, xmm5, 0x03
000074113b7cfca3  vptest xmm3, xmm3
000074113b7cfca8  jnz 0x000074113B7D1994
000074113b7cfcae  vmovaps xmm14, [rsp+0xA0]
000074113b7cfcb7  vpermilpd xmm14, xmm14, 0x00
000074113b7cfcbd  movaps xmm8, xmm13
000074113b7cfcc1  vfmadd231pd xmm8, xmm6, xmm14
000074113b7cfcc6  vcmppd xmm7, xmm8, xmm8, 0x03
000074113b7cfccc  vptest xmm7, xmm7
000074113b7cfcd1  jnz 0x000074113B7D1AEB
000074113b7cfcd7  vmovaps xmm14, [rsp+0xA0]
000074113b7cfce0  vpermilpd xmm14, xmm14, 0x00
000074113b7cfce6  movaps xmm13, xmm11
000074113b7cfcea  vfmadd231pd xmm13, xmm12, xmm14
000074113b7cfcef  vcmppd xmm7, xmm13, xmm13, 0x03
000074113b7cfcf5  vptest xmm7, xmm7
000074113b7cfcfa  jnz 0x000074113B7D1C44
000074113b7cfd00  lea rax, [r14+0x60]
000074113b7cfd04  movups xmm14, [r13+rax*1]
000074113b7cfd0a  lea rax, [r14+0x70]
000074113b7cfd0e  movups xmm12, [r13+rax*1]
000074113b7cfd14  movaps [r15+0x150], xmm14
000074113b7cfd1c  movaps [r15+0x120], xmm12
000074113b7cfd24  vmovaps xmm11, [rsp+0xC0]
000074113b7cfd2d  vpermilpd xmm11, xmm11, 0x00
000074113b7cfd33  movaps xmm7, xmm4
000074113b7cfd36  vfmadd231pd xmm7, xmm9, xmm11
000074113b7cfd3b  vcmppd xmm6, xmm7, xmm7, 0x03
000074113b7cfd40  vptest xmm6, xmm6
000074113b7cfd45  jnz 0x000074113B7D1DB2
000074113b7cfd4b  vmovaps xmm11, [rsp+0xC0]
000074113b7cfd54  vpermilpd xmm11, xmm11, 0x00
000074113b7cfd5a  movaps xmm9, xmm5
000074113b7cfd5e  vfmadd231pd xmm9, xmm14, xmm11
000074113b7cfd63  vcmppd xmm6, xmm9, xmm9, 0x03
000074113b7cfd69  vptest xmm6, xmm6
000074113b7cfd6e  jnz 0x000074113B7D1F09
000074113b7cfd74  vmovaps xmm14, [rsp+0xC0]
000074113b7cfd7d  vpermilpd xmm14, xmm14, 0x00
000074113b7cfd83  movaps xmm11, xmm8
000074113b7cfd87  vfmadd231pd xmm11, xmm10, xmm14
000074113b7cfd8c  vcmppd xmm6, xmm11, xmm11, 0x03
000074113b7cfd92  vptest xmm6, xmm6
000074113b7cfd97  jnz 0x000074113B7D2062
000074113b7cfd9d  vmovaps xmm14, [rsp+0xC0]
000074113b7cfda6  vpermilpd xmm14, xmm14, 0x00
000074113b7cfdac  movaps xmm10, xmm13
000074113b7cfdb0  vfmadd231pd xmm10, xmm15, xmm14
000074113b7cfdb5  vcmppd xmm8, xmm10, xmm10, 0x03
000074113b7cfdbb  vptest xmm8, xmm8
000074113b7cfdc0  jnz 0x000074113B7D21BC
000074113b7cfdc6  lea rax, [r14+0x20]
000074113b7cfdca  movups xmm15, [r13+rax*1]
000074113b7cfdd0  lea rax, [r14+0x30]
000074113b7cfdd4  movups xmm14, [r13+rax*1]
000074113b7cfdda  vmovaps xmm13, [rsp+0x70]
000074113b7cfde0  vpermilpd xmm13, xmm13, 0x00
000074113b7cfde6  vmovaps xmm8, [rsp+0x20]
000074113b7cfdec  movaps xmm6, xmm7
000074113b7cfdef  vfmadd231pd xmm6, xmm8, xmm13
000074113b7cfdf4  vcmppd xmm5, xmm6, xmm6, 0x03
000074113b7cfdf9  vptest xmm5, xmm5
000074113b7cfdfe  jnz 0x000074113B7D232A
000074113b7cfe04  vmovaps xmm13, [rsp+0x70]
000074113b7cfe0a  vpermilpd xmm13, xmm13, 0x00
000074113b7cfe10  movaps xmm8, xmm9
000074113b7cfe14  vfmadd231pd xmm8, xmm1, xmm13
000074113b7cfe19  vcmppd xmm7, xmm8, xmm8, 0x03
000074113b7cfe1f  vptest xmm7, xmm7
000074113b7cfe24  jnz 0x000074113B7D2481
000074113b7cfe2a  vmovaps xmm1, [rsp+0x70]
000074113b7cfe30  vpermilpd xmm1, xmm1, 0x00
000074113b7cfe36  movaps xmm13, xmm11
000074113b7cfe3a  vfmadd231pd xmm13, xmm12, xmm1
000074113b7cfe3f  vcmppd xmm9, xmm13, xmm13, 0x03
000074113b7cfe45  vptest xmm9, xmm9
000074113b7cfe4a  jnz 0x000074113B7D25DA
000074113b7cfe50  vmovaps xmm1, [rsp+0x70]
000074113b7cfe56  vpermilpd xmm1, xmm1, 0x00
000074113b7cfe5c  movaps xmm12, xmm10
000074113b7cfe60  vfmadd231pd xmm12, xmm14, xmm1
000074113b7cfe65  vcmppd xmm11, xmm12, xmm12, 0x03
000074113b7cfe6b  vptest xmm11, xmm11
000074113b7cfe70  jnz 0x000074113B7D2733
000074113b7cfe76  lea rax, [r14+0x90]
000074113b7cfe7d  movups xmm1, [r13+rax*1]
000074113b7cfe83  lea rax, [r14+0xA0]
000074113b7cfe8a  movups xmm14, [r13+rax*1]
000074113b7cfe90  movaps [r15+0x140], xmm1
000074113b7cfe98  movaps [r15+0x130], xmm14
000074113b7cfea0  vmovaps xmm11, [rsp+0x90]
000074113b7cfea9  vpermilpd xmm11, xmm11, 0x00
000074113b7cfeaf  movaps xmm10, xmm6
000074113b7cfeb3  vfmadd231pd xmm10, xmm15, xmm11
000074113b7cfeb8  vcmppd xmm9, xmm10, xmm10, 0x03
000074113b7cfebe  vptest xmm9, xmm9
000074113b7cfec3  jnz 0x000074113B7D28A0
000074113b7cfec9  movaps [r15+0x220], xmm10
000074113b7cfed1  lea rax, [r14+0x10]
000074113b7cfed5  movups xmm15, [r13+rax*1]
000074113b7cfedb  movaps [r15+0x240], xmm15
000074113b7cfee3  vmovaps xmm11, [rsp+0x90]
000074113b7cfeec  vpermilpd xmm11, xmm11, 0x00
000074113b7cfef2  movaps xmm9, xmm8
000074113b7cfef6  vfmadd231pd xmm9, xmm14, xmm11
000074113b7cfefb  vcmppd xmm7, xmm9, xmm9, 0x03
000074113b7cff01  vptest xmm7, xmm7
000074113b7cff06  jnz 0x000074113B7D2A03
000074113b7cff0c  movaps [r15+0x110], xmm9
000074113b7cff14  vmovaps xmm14, [rsp+0x90]
000074113b7cff1d  vpermilpd xmm14, xmm14, 0x00
000074113b7cff23  movaps xmm11, xmm13
000074113b7cff27  vfmadd231pd xmm11, xmm1, xmm14
000074113b7cff2c  vcmppd xmm8, xmm11, xmm11, 0x03
000074113b7cff32  vptest xmm8, xmm8
000074113b7cff37  jnz 0x000074113B7D2B5D
000074113b7cff3d  movaps [r15+0x170], xmm11
000074113b7cff45  vmovaps xmm1, [rsp+0x90]
000074113b7cff4e  vpermilpd xmm1, xmm1, 0x00
000074113b7cff54  movaps xmm14, xmm12
000074113b7cff58  vfmadd231pd xmm14, xmm15, xmm1
000074113b7cff5d  vcmppd xmm13, xmm14, xmm14, 0x03
000074113b7cff63  vptest xmm13, xmm13
000074113b7cff68  jnz 0x000074113B7D2CB6
000074113b7cff6e  movaps [r15+0x230], xmm14
000074113b7cff76  mov eax, 0x4308D0
000074113b7cff7b  movups [r13+rax*1], xmm9
000074113b7cff81  mov eax, 0x4308E0
000074113b7cff86  movups [r13+rax*1], xmm11
000074113b7cff8c  mov eax, 0x4308F0
000074113b7cff91  movups [r13+rax*1], xmm10
000074113b7cff97  mov eax, 0x430900
000074113b7cff9c  movups [r13+rax*1], xmm14
000074113b7cffa2  mov eax, [r15+0x108]
000074113b7cffa9  sahf
000074113b7cffaa  jnz 0x000074113B7CFFDC
000074113b7cffac  cmp dword ptr [r15+0x318], 0x00
000074113b7cffb4  jz 0x000074113B7D67A0
000074113b7cffba  nop [rax+rax*1], ax
000074113b7cffc3  nop [rax+rax*1], eax
000074113b7cffcb  mov eax, 0x4103F0
000074113b7cffd0  mov [r15+0x100], rax
000074113b7cffd7  jmp 0x000074113B5FE110
000074113b7cffdc  cmp dword ptr [r15+0x318], 0x00
000074113b7cffe4  jz 0x000074113B7D2E40
000074113b7cffea  nop [rax+rax*1], ax
000074113b7cfff3  nop [rax+rax*1], eax
000074113b7cfffb  mov eax, 0x410274
000074113b7d0000  mov [r15+0x100], rax
000074113b7d0007  jmp 0x000074113B5FE110
000074113b7d000c  int3
000074113b7d000d  call 0x000074113B5FF430
000074113b7d0012  jmp 0x000074113B7CF00F
000074113b7d0017  call 0x000074113B6C4620
000074113b7d001c  jmp 0x000074113B7CF019
000074113b7d0021  call 0x000074113B6C0860
000074113b7d0026  jmp 0x000074113B7CF049
000074113b7d002b  call 0x000074113B6BF5F0
000074113b7d0030  jmp 0x000074113B7CF055
000074113b7d0035  call 0x000074113B6C33A0
000074113b7d003a  jmp 0x000074113B7CF062
000074113b7d003f  call 0x000074113B6C2120
000074113b7d0044  jmp 0x000074113B7CF06F
000074113b7d0049  call 0x000074113B6C0860
000074113b7d004e  jmp 0x000074113B7CF097
000074113b7d0053  call 0x000074113B6BF5F0
000074113b7d0058  jmp 0x000074113B7CF0A3
000074113b7d005d  call 0x000074113B6C0EA0
000074113b7d0062  jmp 0x000074113B7CF0B0
000074113b7d0067  call 0x000074113B6BFC30
000074113b7d006c  jmp 0x000074113B7CF0BD
000074113b7d0071  call 0x000074113B6D6600
000074113b7d0076  jmp 0x000074113B7CF0C3
000074113b7d007b  call 0x000074113B6B52F0
000074113b7d0080  jmp 0x000074113B7CF0CD
000074113b7d0085  call 0x000074113B6BE9C0
000074113b7d008a  jmp 0x000074113B7CF0D7
000074113b7d008f  call 0x000074113B6C0860
000074113b7d0094  jmp 0x000074113B7CF0FF
000074113b7d0099  call 0x000074113B6BF5F0
000074113b7d009e  jmp 0x000074113B7CF10B
000074113b7d00a3  call 0x000074113B6BD750
000074113b7d00a8  jmp 0x000074113B7CF115
000074113b7d00ad  call 0x000074113B6BC4E0
000074113b7d00b2  jmp 0x000074113B7CF11F
000074113b7d00b7  call 0x000074113B6C0860
000074113b7d00bc  jmp 0x000074113B7CF147
000074113b7d00c1  call 0x000074113B6BF5F0
000074113b7d00c6  jmp 0x000074113B7CF153
000074113b7d00cb  call 0x000074113B6BB270
000074113b7d00d0  jmp 0x000074113B7CF160
000074113b7d00d5  call 0x000074113B6BA000
000074113b7d00da  jmp 0x000074113B7CF16D
000074113b7d00df  call 0x000074113B6BEAE0
000074113b7d00e4  jmp 0x000074113B7CF17A
000074113b7d00e9  call 0x000074113B6B5400
000074113b7d00ee  jmp 0x000074113B7CF187
000074113b7d00f3  call 0x000074113B6B52F0
000074113b7d00f8  jmp 0x000074113B7CF194
000074113b7d00fd  call 0x000074113B6BE9C0
000074113b7d0102  jmp 0x000074113B7CF1A1
000074113b7d0107  call 0x000074113B6C0860
000074113b7d010c  jmp 0x000074113B7CF1B4
000074113b7d0111  call 0x000074113B6B8D90
000074113b7d0116  jmp 0x000074113B7CF1C1
000074113b7d011b  call 0x000074113B6B8A20
000074113b7d0120  jmp 0x000074113B7CF1CE
000074113b7d0125  call 0x000074113B6B77B0
000074113b7d012a  jmp 0x000074113B7CF1DB
000074113b7d012f  call 0x000074113B6B6550
000074113b7d0134  jmp 0x000074113B7CF1E8
000074113b7d0139  call 0x000074113B6B52F0
000074113b7d013e  jmp 0x000074113B7CF1F8
000074113b7d0143  call 0x000074113B6B52F0
000074113b7d0148  jmp 0x000074113B7CF208
000074113b7d014d  call 0x000074113B6B8B30
000074113b7d0152  jmp 0x000074113B7CF212
000074113b7d0157  call 0x000074113B6B8EA0
000074113b7d015c  jmp 0x000074113B7CF21F
000074113b7d0161  call 0x000074113B6B8D90
000074113b7d0166  jmp 0x000074113B7CF22C
000074113b7d016b  call 0x000074113B6B8A20
000074113b7d0170  jmp 0x000074113B7CF239
000074113b7d0175  call 0x000074113B6B6660
000074113b7d017a  jmp 0x000074113B7CF246
000074113b7d017f  call 0x000074113B6B78C0
000074113b7d0184  jmp 0x000074113B7CF253
000074113b7d0189  call 0x000074113B6B77B0
000074113b7d018e  jmp 0x000074113B7CF260
000074113b7d0193  call 0x000074113B6B6550
000074113b7d0198  jmp 0x000074113B7CF26D
000074113b7d019d  call 0x000074113B6B52F0
000074113b7d01a2  jmp 0x000074113B7CF280
000074113b7d01a7  call 0x000074113B6B52F0
000074113b7d01ac  jmp 0x000074113B7CF293
000074113b7d01b1  call 0x000074113B6B52F0
000074113b7d01b6  jmp 0x000074113B7CF2A6
000074113b7d01bb  call 0x000074113B6B52F0
000074113b7d01c0  jmp 0x000074113B7CF2B9
000074113b7d01c5  call 0x000074113B6B52F0
000074113b7d01ca  jmp 0x000074113B7CF2CC
000074113b7d01cf  call 0x000074113B6B52F0
000074113b7d01d4  jmp 0x000074113B7CF2E2
000074113b7d01d9  call 0x000074113B6B52F0
000074113b7d01de  jmp 0x000074113B7CF2F8
000074113b7d01e3  call 0x000074113B6B52F0
000074113b7d01e8  jmp 0x000074113B7CF30E
000074113b7d01ed  call 0x000074113B5FF540
000074113b7d01f2  jmp 0x000074113B7CF32F
000074113b7d01f7  call 0x000074113B5FF540
000074113b7d01fc  jmp 0x000074113B7CF33F
000074113b7d0201  call 0x000074113B5FF540
000074113b7d0206  jmp 0x000074113B7CF34F
000074113b7d020b  call 0x000074113B5FF540
000074113b7d0210  jmp 0x000074113B7CF362
000074113b7d0215  call 0x000074113B5FF540
000074113b7d021a  jmp 0x000074113B7CF375
000074113b7d021f  call 0x000074113B5FF540
000074113b7d0224  jmp 0x000074113B7CF388
000074113b7d0229  call 0x000074113B6C0370
000074113b7d022e  jmp 0x000074113B7CF3AD
000074113b7d0233  call 0x000074113B6BF100
000074113b7d0238  jmp 0x000074113B7CF3B6
000074113b7d023d  call 0x000074113B6C0370
000074113b7d0242  jmp 0x000074113B7CF426
000074113b7d0247  call 0x000074113B6BF100
000074113b7d024c  jmp 0x000074113B7CF42F
000074113b7d0251  call 0x000074113B6C0370
000074113b7d0256  jmp 0x000074113B7CF4E3
000074113b7d025b  call 0x000074113B6BF100
000074113b7d0260  jmp 0x000074113B7CF4EC
000074113b7d0265  call 0x000074113B60B720
000074113b7d026a  jmp 0x000074113B7CF5A8
000074113b7d026f  call 0x000074113B6D64F0
000074113b7d0274  jmp 0x000074113B7CF5D0
000074113b7d0279  call 0x000074113B6B47C0
000074113b7d027e  jmp 0x000074113B7CF5EB
000074113b7d0283  sub rsp, 0x08
000074113b7d0287  push rax
000074113b7d0288  push rcx
000074113b7d0289  push rdx
000074113b7d028a  push rdi
000074113b7d028b  push rsi
000074113b7d028c  push r8
000074113b7d028e  push r9
000074113b7d0290  push r10
000074113b7d0292  push r11
000074113b7d0294  sub rsp, 0xF0
000074113b7d029b  vmovaps [rsp], xmm0
000074113b7d02a0  vmovaps [rsp+0x10], xmm1
000074113b7d02a6  vmovaps [rsp+0x20], xmm2
000074113b7d02ac  vmovaps [rsp+0x30], xmm3
000074113b7d02b2  vmovaps [rsp+0x40], xmm4
000074113b7d02b8  vmovaps [rsp+0x50], xmm5
000074113b7d02be  vmovaps [rsp+0x60], xmm6
000074113b7d02c4  vmovaps [rsp+0x70], xmm7
000074113b7d02ca  vmovaps [rsp+0x80], xmm8
000074113b7d02d3  vmovaps [rsp+0x90], xmm9
000074113b7d02dc  vmovaps [rsp+0xA0], xmm10
000074113b7d02e5  vmovaps [rsp+0xB0], xmm11
000074113b7d02ee  vmovaps [rsp+0xC0], xmm12
000074113b7d02f7  vmovaps [rsp+0xD0], xmm14
000074113b7d0300  vmovaps [rsp+0xE0], xmm15
000074113b7d0309  sub rsp, 0x40
000074113b7d030d  lea rdi, [rsp]
000074113b7d0311  lea rsi, [rsp+0x10]
000074113b7d0316  lea rdx, [rsp+0x20]
000074113b7d031b  lea rcx, [rsp+0x30]
000074113b7d0320  mov r8d, 0x00
000074113b7d0326  lea r9, [r15+0x3A8]
000074113b7d032d  movaps [rdi], xmm13
000074113b7d0331  movaps [rsi], xmm1
000074113b7d0334  movaps [rdx], xmm15
000074113b7d0338  movaps [rcx], xmm14
000074113b7d033c  mov rax, 0x629073062A50
000074113b7d0346  call rax
000074113b7d0348  movaps xmm13, [rsp]
000074113b7d034d  add rsp, 0x40
000074113b7d0351  vmovaps xmm0, [rsp]
000074113b7d0356  vmovaps xmm1, [rsp+0x10]
000074113b7d035c  vmovaps xmm2, [rsp+0x20]
000074113b7d0362  vmovaps xmm3, [rsp+0x30]
000074113b7d0368  vmovaps xmm4, [rsp+0x40]
000074113b7d036e  vmovaps xmm5, [rsp+0x50]
000074113b7d0374  vmovaps xmm6, [rsp+0x60]
000074113b7d037a  vmovaps xmm7, [rsp+0x70]
000074113b7d0380  vmovaps xmm8, [rsp+0x80]
000074113b7d0389  vmovaps xmm9, [rsp+0x90]
000074113b7d0392  vmovaps xmm10, [rsp+0xA0]
000074113b7d039b  vmovaps xmm11, [rsp+0xB0]
000074113b7d03a4  vmovaps xmm12, [rsp+0xC0]
000074113b7d03ad  vmovaps xmm14, [rsp+0xD0]
000074113b7d03b6  vmovaps xmm15, [rsp+0xE0]
000074113b7d03bf  add rsp, 0xF0
000074113b7d03c6  pop r11
000074113b7d03c8  pop r10
000074113b7d03ca  pop r9
000074113b7d03cc  pop r8
000074113b7d03ce  pop rsi
000074113b7d03cf  pop rdi
000074113b7d03d0  pop rdx
000074113b7d03d1  pop rcx
000074113b7d03d2  pop rax
000074113b7d03d3  add rsp, 0x08
000074113b7d03d7  jmp 0x000074113B7CF65E
000074113b7d03dc  sub rsp, 0x08
000074113b7d03e0  push rax
000074113b7d03e1  push rcx
000074113b7d03e2  push rdx
000074113b7d03e3  push rdi
000074113b7d03e4  push rsi
000074113b7d03e5  push r8
000074113b7d03e7  push r9
000074113b7d03e9  push r10
000074113b7d03eb  push r11
000074113b7d03ed  sub rsp, 0xF0
000074113b7d03f4  vmovaps [rsp], xmm0
000074113b7d03f9  vmovaps [rsp+0x10], xmm1
000074113b7d03ff  vmovaps [rsp+0x20], xmm2
000074113b7d0405  vmovaps [rsp+0x30], xmm3
000074113b7d040b  vmovaps [rsp+0x40], xmm4
000074113b7d0411  vmovaps [rsp+0x50], xmm5
000074113b7d0417  vmovaps [rsp+0x60], xmm6
000074113b7d041d  vmovaps [rsp+0x70], xmm7
000074113b7d0423  vmovaps [rsp+0x80], xmm8
000074113b7d042c  vmovaps [rsp+0x90], xmm9
000074113b7d0435  vmovaps [rsp+0xA0], xmm10
000074113b7d043e  vmovaps [rsp+0xB0], xmm11
000074113b7d0447  vmovaps [rsp+0xC0], xmm13
000074113b7d0450  vmovaps [rsp+0xD0], xmm14
000074113b7d0459  vmovaps [rsp+0xE0], xmm15
000074113b7d0462  sub rsp, 0x40
000074113b7d0466  lea rdi, [rsp]
000074113b7d046a  lea rsi, [rsp+0x10]
000074113b7d046f  lea rdx, [rsp+0x20]
000074113b7d0474  lea rcx, [rsp+0x30]
000074113b7d0479  mov r8d, 0x00
000074113b7d047f  lea r9, [r15+0x3A8]
000074113b7d0486  movaps [rdi], xmm12
000074113b7d048a  movaps [rsi], xmm1
000074113b7d048d  movaps [rdx], xmm15
000074113b7d0491  movaps [rcx], xmm14
000074113b7d0495  mov rax, 0x629073062A50
000074113b7d049f  call rax
000074113b7d04a1  movaps xmm12, [rsp]
000074113b7d04a6  add rsp, 0x40
000074113b7d04aa  vmovaps xmm0, [rsp]
000074113b7d04af  vmovaps xmm1, [rsp+0x10]
000074113b7d04b5  vmovaps xmm2, [rsp+0x20]
000074113b7d04bb  vmovaps xmm3, [rsp+0x30]
000074113b7d04c1  vmovaps xmm4, [rsp+0x40]
000074113b7d04c7  vmovaps xmm5, [rsp+0x50]
000074113b7d04cd  vmovaps xmm6, [rsp+0x60]
000074113b7d04d3  vmovaps xmm7, [rsp+0x70]
000074113b7d04d9  vmovaps xmm8, [rsp+0x80]
000074113b7d04e2  vmovaps xmm9, [rsp+0x90]
000074113b7d04eb  vmovaps xmm10, [rsp+0xA0]
000074113b7d04f4  vmovaps xmm11, [rsp+0xB0]
000074113b7d04fd  vmovaps xmm13, [rsp+0xC0]
000074113b7d0506  vmovaps xmm14, [rsp+0xD0]
000074113b7d050f  vmovaps xmm15, [rsp+0xE0]
000074113b7d0518  add rsp, 0xF0
000074113b7d051f  pop r11
000074113b7d0521  pop r10
000074113b7d0523  pop r9
000074113b7d0525  pop r8
000074113b7d0527  pop rsi
000074113b7d0528  pop rdi
000074113b7d0529  pop rdx
000074113b7d052a  pop rcx
000074113b7d052b  pop rax
000074113b7d052c  add rsp, 0x08
000074113b7d0530  jmp 0x000074113B7CF68D
000074113b7d0535  call 0x000074113B5FF430
000074113b7d053a  jmp 0x000074113B7CF712
000074113b7d053f  sub rsp, 0x08
000074113b7d0543  push rax
000074113b7d0544  push rcx
000074113b7d0545  push rdx
000074113b7d0546  push rdi
000074113b7d0547  push rsi
000074113b7d0548  push r8
000074113b7d054a  push r9
000074113b7d054c  push r10
000074113b7d054e  push r11
000074113b7d0550  sub rsp, 0xF0
000074113b7d0557  vmovaps [rsp], xmm0
000074113b7d055c  vmovaps [rsp+0x10], xmm1
000074113b7d0562  vmovaps [rsp+0x20], xmm2
000074113b7d0568  vmovaps [rsp+0x30], xmm3
000074113b7d056e  vmovaps [rsp+0x40], xmm4
000074113b7d0574  vmovaps [rsp+0x50], xmm5
000074113b7d057a  vmovaps [rsp+0x60], xmm6
000074113b7d0580  vmovaps [rsp+0x70], xmm7
000074113b7d0586  vmovaps [rsp+0x80], xmm8
000074113b7d058f  vmovaps [rsp+0x90], xmm9
000074113b7d0598  vmovaps [rsp+0xA0], xmm10
000074113b7d05a1  vmovaps [rsp+0xB0], xmm11
000074113b7d05aa  vmovaps [rsp+0xC0], xmm12
000074113b7d05b3  vmovaps [rsp+0xD0], xmm14
000074113b7d05bc  vmovaps [rsp+0xE0], xmm15
000074113b7d05c5  sub rsp, 0x40
000074113b7d05c9  lea rdi, [rsp]
000074113b7d05cd  lea rsi, [rsp+0x10]
000074113b7d05d2  lea rdx, [rsp+0x20]
000074113b7d05d7  lea rcx, [rsp+0x30]
000074113b7d05dc  mov r8d, 0x00
000074113b7d05e2  lea r9, [r15+0x3A8]
000074113b7d05e9  movaps [rdi], xmm13
000074113b7d05ed  movaps [rsi], xmm1
000074113b7d05f0  movaps [rdx], xmm15
000074113b7d05f4  movaps [rcx], xmm14
000074113b7d05f8  mov rax, 0x629073062A50
000074113b7d0602  call rax
000074113b7d0604  movaps xmm13, [rsp]
000074113b7d0609  add rsp, 0x40
000074113b7d060d  vmovaps xmm0, [rsp]
000074113b7d0612  vmovaps xmm1, [rsp+0x10]
000074113b7d0618  vmovaps xmm2, [rsp+0x20]
000074113b7d061e  vmovaps xmm3, [rsp+0x30]
000074113b7d0624  vmovaps xmm4, [rsp+0x40]
000074113b7d062a  vmovaps xmm5, [rsp+0x50]
000074113b7d0630  vmovaps xmm6, [rsp+0x60]
000074113b7d0636  vmovaps xmm7, [rsp+0x70]
000074113b7d063c  vmovaps xmm8, [rsp+0x80]
000074113b7d0645  vmovaps xmm9, [rsp+0x90]
000074113b7d064e  vmovaps xmm10, [rsp+0xA0]
000074113b7d0657  vmovaps xmm11, [rsp+0xB0]
000074113b7d0660  vmovaps xmm12, [rsp+0xC0]
000074113b7d0669  vmovaps xmm14, [rsp+0xD0]
000074113b7d0672  vmovaps xmm15, [rsp+0xE0]
000074113b7d067b  add rsp, 0xF0
000074113b7d0682  pop r11
000074113b7d0684  pop r10
000074113b7d0686  pop r9
000074113b7d0688  pop r8
000074113b7d068a  pop rsi
000074113b7d068b  pop rdi
000074113b7d068c  pop rdx
000074113b7d068d  pop rcx
000074113b7d068e  pop rax
000074113b7d068f  add rsp, 0x08
000074113b7d0693  jmp 0x000074113B7CF77F
000074113b7d0698  call 0x000074113B5FF430
000074113b7d069d  jmp 0x000074113B7CF78C
000074113b7d06a2  sub rsp, 0x08
000074113b7d06a6  push rax
000074113b7d06a7  push rcx
000074113b7d06a8  push rdx
000074113b7d06a9  push rdi
000074113b7d06aa  push rsi
000074113b7d06ab  push r8
000074113b7d06ad  push r9
000074113b7d06af  push r10
000074113b7d06b1  push r11
000074113b7d06b3  sub rsp, 0xF0
000074113b7d06ba  vmovaps [rsp], xmm0
000074113b7d06bf  vmovaps [rsp+0x10], xmm1
000074113b7d06c5  vmovaps [rsp+0x20], xmm2
000074113b7d06cb  vmovaps [rsp+0x30], xmm3
000074113b7d06d1  vmovaps [rsp+0x40], xmm4
000074113b7d06d7  vmovaps [rsp+0x50], xmm5
000074113b7d06dd  vmovaps [rsp+0x60], xmm6
000074113b7d06e3  vmovaps [rsp+0x70], xmm7
000074113b7d06e9  vmovaps [rsp+0x80], xmm8
000074113b7d06f2  vmovaps [rsp+0x90], xmm9
000074113b7d06fb  vmovaps [rsp+0xA0], xmm10
000074113b7d0704  vmovaps [rsp+0xB0], xmm11
000074113b7d070d  vmovaps [rsp+0xC0], xmm13
000074113b7d0716  vmovaps [rsp+0xD0], xmm14
000074113b7d071f  vmovaps [rsp+0xE0], xmm15
000074113b7d0728  sub rsp, 0x40
000074113b7d072c  lea rdi, [rsp]
000074113b7d0730  lea rsi, [rsp+0x10]
000074113b7d0735  lea rdx, [rsp+0x20]
000074113b7d073a  lea rcx, [rsp+0x30]
000074113b7d073f  mov r8d, 0x00
000074113b7d0745  lea r9, [r15+0x3A8]
000074113b7d074c  movaps [rdi], xmm12
000074113b7d0750  movaps [rsi], xmm15
000074113b7d0754  movaps [rdx], xmm1
000074113b7d0757  movaps [rcx], xmm14
000074113b7d075b  mov rax, 0x629073062A50
000074113b7d0765  call rax
000074113b7d0767  movaps xmm12, [rsp]
000074113b7d076c  add rsp, 0x40
000074113b7d0770  vmovaps xmm0, [rsp]
000074113b7d0775  vmovaps xmm1, [rsp+0x10]
000074113b7d077b  vmovaps xmm2, [rsp+0x20]
000074113b7d0781  vmovaps xmm3, [rsp+0x30]
000074113b7d0787  vmovaps xmm4, [rsp+0x40]
000074113b7d078d  vmovaps xmm5, [rsp+0x50]
000074113b7d0793  vmovaps xmm6, [rsp+0x60]
000074113b7d0799  vmovaps xmm7, [rsp+0x70]
000074113b7d079f  vmovaps xmm8, [rsp+0x80]
000074113b7d07a8  vmovaps xmm9, [rsp+0x90]
000074113b7d07b1  vmovaps xmm10, [rsp+0xA0]
000074113b7d07ba  vmovaps xmm11, [rsp+0xB0]
000074113b7d07c3  vmovaps xmm13, [rsp+0xC0]
000074113b7d07cc  vmovaps xmm14, [rsp+0xD0]
000074113b7d07d5  vmovaps xmm15, [rsp+0xE0]
000074113b7d07de  add rsp, 0xF0
000074113b7d07e5  pop r11
000074113b7d07e7  pop r10
000074113b7d07e9  pop r9
000074113b7d07eb  pop r8
000074113b7d07ed  pop rsi
000074113b7d07ee  pop rdi
000074113b7d07ef  pop rdx
000074113b7d07f0  pop rcx
000074113b7d07f1  pop rax
000074113b7d07f2  add rsp, 0x08
000074113b7d07f6  jmp 0x000074113B7CF7B8
000074113b7d07fb  sub rsp, 0x08
000074113b7d07ff  push rax
000074113b7d0800  push rcx
000074113b7d0801  push rdx
000074113b7d0802  push rdi
000074113b7d0803  push rsi
000074113b7d0804  push r8
000074113b7d0806  push r9
000074113b7d0808  push r10
000074113b7d080a  push r11
000074113b7d080c  sub rsp, 0xF0
000074113b7d0813  vmovaps [rsp], xmm0
000074113b7d0818  vmovaps [rsp+0x10], xmm1
000074113b7d081e  vmovaps [rsp+0x20], xmm2
000074113b7d0824  vmovaps [rsp+0x30], xmm3
000074113b7d082a  vmovaps [rsp+0x40], xmm4
000074113b7d0830  vmovaps [rsp+0x50], xmm5
000074113b7d0836  vmovaps [rsp+0x60], xmm6
000074113b7d083c  vmovaps [rsp+0x70], xmm7
000074113b7d0842  vmovaps [rsp+0x80], xmm8
000074113b7d084b  vmovaps [rsp+0x90], xmm9
000074113b7d0854  vmovaps [rsp+0xA0], xmm10
000074113b7d085d  vmovaps [rsp+0xB0], xmm11
000074113b7d0866  vmovaps [rsp+0xC0], xmm12
000074113b7d086f  vmovaps [rsp+0xD0], xmm13
000074113b7d0878  vmovaps [rsp+0xE0], xmm14
000074113b7d0881  sub rsp, 0x40
000074113b7d0885  lea rdi, [rsp]
000074113b7d0889  lea rsi, [rsp+0x10]
000074113b7d088e  lea rdx, [rsp+0x20]
000074113b7d0893  lea rcx, [rsp+0x30]
000074113b7d0898  mov r8d, 0x00
000074113b7d089e  lea r9, [r15+0x3A8]
000074113b7d08a5  movaps [rdi], xmm15
000074113b7d08a9  movaps [rsi], xmm1
000074113b7d08ac  movaps [rdx], xmm9
000074113b7d08b0  movaps [rcx], xmm13
000074113b7d08b4  mov rax, 0x629073062A50
000074113b7d08be  call rax
000074113b7d08c0  movaps xmm15, [rsp]
000074113b7d08c5  add rsp, 0x40
000074113b7d08c9  vmovaps xmm0, [rsp]
000074113b7d08ce  vmovaps xmm1, [rsp+0x10]
000074113b7d08d4  vmovaps xmm2, [rsp+0x20]
000074113b7d08da  vmovaps xmm3, [rsp+0x30]
000074113b7d08e0  vmovaps xmm4, [rsp+0x40]
000074113b7d08e6  vmovaps xmm5, [rsp+0x50]
000074113b7d08ec  vmovaps xmm6, [rsp+0x60]
000074113b7d08f2  vmovaps xmm7, [rsp+0x70]
000074113b7d08f8  vmovaps xmm8, [rsp+0x80]
000074113b7d0901  vmovaps xmm9, [rsp+0x90]
000074113b7d090a  vmovaps xmm10, [rsp+0xA0]
000074113b7d0913  vmovaps xmm11, [rsp+0xB0]
000074113b7d091c  vmovaps xmm12, [rsp+0xC0]
000074113b7d0925  vmovaps xmm13, [rsp+0xD0]
000074113b7d092e  vmovaps xmm14, [rsp+0xE0]
000074113b7d0937  add rsp, 0xF0
000074113b7d093e  pop r11
000074113b7d0940  pop r10
000074113b7d0942  pop r9
000074113b7d0944  pop r8
000074113b7d0946  pop rsi
000074113b7d0947  pop rdi
000074113b7d0948  pop rdx
000074113b7d0949  pop rcx
000074113b7d094a  pop rax
000074113b7d094b  add rsp, 0x08
000074113b7d094f  jmp 0x000074113B7CF91A
000074113b7d0954  sub rsp, 0x08
000074113b7d0958  push rax
000074113b7d0959  push rcx
000074113b7d095a  push rdx
000074113b7d095b  push rdi
000074113b7d095c  push rsi
000074113b7d095d  push r8
000074113b7d095f  push r9
000074113b7d0961  push r10
000074113b7d0963  push r11
000074113b7d0965  sub rsp, 0xF0
000074113b7d096c  vmovaps [rsp], xmm0
000074113b7d0971  vmovaps [rsp+0x10], xmm1
000074113b7d0977  vmovaps [rsp+0x20], xmm2
000074113b7d097d  vmovaps [rsp+0x30], xmm3
000074113b7d0983  vmovaps [rsp+0x40], xmm4
000074113b7d0989  vmovaps [rsp+0x50], xmm5
000074113b7d098f  vmovaps [rsp+0x60], xmm6
000074113b7d0995  vmovaps [rsp+0x70], xmm7
000074113b7d099b  vmovaps [rsp+0x80], xmm8
000074113b7d09a4  vmovaps [rsp+0x90], xmm10
000074113b7d09ad  vmovaps [rsp+0xA0], xmm11
000074113b7d09b6  vmovaps [rsp+0xB0], xmm12
000074113b7d09bf  vmovaps [rsp+0xC0], xmm13
000074113b7d09c8  vmovaps [rsp+0xD0], xmm14
000074113b7d09d1  vmovaps [rsp+0xE0], xmm15
000074113b7d09da  sub rsp, 0x40
000074113b7d09de  lea rdi, [rsp]
000074113b7d09e2  lea rsi, [rsp+0x10]
000074113b7d09e7  lea rdx, [rsp+0x20]
000074113b7d09ec  lea rcx, [rsp+0x30]
000074113b7d09f1  mov r8d, 0x00
000074113b7d09f7  lea r9, [r15+0x3A8]
000074113b7d09fe  movaps [rdi], xmm9
000074113b7d0a02  movaps [rsi], xmm14
000074113b7d0a06  movaps [rdx], xmm13
000074113b7d0a0a  movaps [rcx], xmm1
000074113b7d0a0d  mov rax, 0x629073062A50
000074113b7d0a17  call rax
000074113b7d0a19  movaps xmm9, [rsp]
000074113b7d0a1e  add rsp, 0x40
000074113b7d0a22  vmovaps xmm0, [rsp]
000074113b7d0a27  vmovaps xmm1, [rsp+0x10]
000074113b7d0a2d  vmovaps xmm2, [rsp+0x20]
000074113b7d0a33  vmovaps xmm3, [rsp+0x30]
000074113b7d0a39  vmovaps xmm4, [rsp+0x40]
000074113b7d0a3f  vmovaps xmm5, [rsp+0x50]
000074113b7d0a45  vmovaps xmm6, [rsp+0x60]
000074113b7d0a4b  vmovaps xmm7, [rsp+0x70]
000074113b7d0a51  vmovaps xmm8, [rsp+0x80]
000074113b7d0a5a  vmovaps xmm10, [rsp+0x90]
000074113b7d0a63  vmovaps xmm11, [rsp+0xA0]
000074113b7d0a6c  vmovaps xmm12, [rsp+0xB0]
000074113b7d0a75  vmovaps xmm13, [rsp+0xC0]
000074113b7d0a7e  vmovaps xmm14, [rsp+0xD0]
000074113b7d0a87  vmovaps xmm15, [rsp+0xE0]
000074113b7d0a90  add rsp, 0xF0
000074113b7d0a97  pop r11
000074113b7d0a99  pop r10
000074113b7d0a9b  pop r9
000074113b7d0a9d  pop r8
000074113b7d0a9f  pop rsi
000074113b7d0aa0  pop rdi
000074113b7d0aa1  pop rdx
000074113b7d0aa2  pop rcx
000074113b7d0aa3  pop rax
000074113b7d0aa4  add rsp, 0x08
000074113b7d0aa8  jmp 0x000074113B7CF955
000074113b7d0aad  sub rsp, 0x08
000074113b7d0ab1  push rax
000074113b7d0ab2  push rcx
000074113b7d0ab3  push rdx
000074113b7d0ab4  push rdi
000074113b7d0ab5  push rsi
000074113b7d0ab6  push r8
000074113b7d0ab8  push r9
000074113b7d0aba  push r10
000074113b7d0abc  push r11
000074113b7d0abe  sub rsp, 0xF0
000074113b7d0ac5  vmovaps [rsp], xmm0
000074113b7d0aca  vmovaps [rsp+0x10], xmm1
000074113b7d0ad0  vmovaps [rsp+0x20], xmm2
000074113b7d0ad6  vmovaps [rsp+0x30], xmm3
000074113b7d0adc  vmovaps [rsp+0x40], xmm4
000074113b7d0ae2  vmovaps [rsp+0x50], xmm5
000074113b7d0ae8  vmovaps [rsp+0x60], xmm6
000074113b7d0aee  vmovaps [rsp+0x70], xmm7
000074113b7d0af4  vmovaps [rsp+0x80], xmm8
000074113b7d0afd  vmovaps [rsp+0x90], xmm9
000074113b7d0b06  vmovaps [rsp+0xA0], xmm10
000074113b7d0b0f  vmovaps [rsp+0xB0], xmm11
000074113b7d0b18  vmovaps [rsp+0xC0], xmm12
000074113b7d0b21  vmovaps [rsp+0xD0], xmm13
000074113b7d0b2a  vmovaps [rsp+0xE0], xmm15
000074113b7d0b33  sub rsp, 0x40
000074113b7d0b37  lea rdi, [rsp]
000074113b7d0b3b  lea rsi, [rsp+0x10]
000074113b7d0b40  lea rdx, [rsp+0x20]
000074113b7d0b45  lea rcx, [rsp+0x30]
000074113b7d0b4a  mov r8d, 0x00
000074113b7d0b50  lea r9, [r15+0x3A8]
000074113b7d0b57  movaps [rdi], xmm14
000074113b7d0b5b  movaps [rsi], xmm15
000074113b7d0b5f  movaps [rdx], xmm8
000074113b7d0b63  movaps [rcx], xmm1
000074113b7d0b66  mov rax, 0x629073062A50
000074113b7d0b70  call rax
000074113b7d0b72  movaps xmm14, [rsp]
000074113b7d0b77  add rsp, 0x40
000074113b7d0b7b  vmovaps xmm0, [rsp]
000074113b7d0b80  vmovaps xmm1, [rsp+0x10]
000074113b7d0b86  vmovaps xmm2, [rsp+0x20]
000074113b7d0b8c  vmovaps xmm3, [rsp+0x30]
000074113b7d0b92  vmovaps xmm4, [rsp+0x40]
000074113b7d0b98  vmovaps xmm5, [rsp+0x50]
000074113b7d0b9e  vmovaps xmm6, [rsp+0x60]
000074113b7d0ba4  vmovaps xmm7, [rsp+0x70]
000074113b7d0baa  vmovaps xmm8, [rsp+0x80]
000074113b7d0bb3  vmovaps xmm9, [rsp+0x90]
000074113b7d0bbc  vmovaps xmm10, [rsp+0xA0]
000074113b7d0bc5  vmovaps xmm11, [rsp+0xB0]
000074113b7d0bce  vmovaps xmm12, [rsp+0xC0]
000074113b7d0bd7  vmovaps xmm13, [rsp+0xD0]
000074113b7d0be0  vmovaps xmm15, [rsp+0xE0]
000074113b7d0be9  add rsp, 0xF0
000074113b7d0bf0  pop r11
000074113b7d0bf2  pop r10
000074113b7d0bf4  pop r9
000074113b7d0bf6  pop r8
000074113b7d0bf8  pop rsi
000074113b7d0bf9  pop rdi
000074113b7d0bfa  pop rdx
000074113b7d0bfb  pop rcx
000074113b7d0bfc  pop rax
000074113b7d0bfd  add rsp, 0x08
000074113b7d0c01  jmp 0x000074113B7CF984
000074113b7d0c06  sub rsp, 0x08
000074113b7d0c0a  push rax
000074113b7d0c0b  push rcx
000074113b7d0c0c  push rdx
000074113b7d0c0d  push rdi
000074113b7d0c0e  push rsi
000074113b7d0c0f  push r8
000074113b7d0c11  push r9
000074113b7d0c13  push r10
000074113b7d0c15  push r11
000074113b7d0c17  sub rsp, 0xF0
000074113b7d0c1e  vmovaps [rsp], xmm0
000074113b7d0c23  vmovaps [rsp+0x10], xmm1
000074113b7d0c29  vmovaps [rsp+0x20], xmm2
000074113b7d0c2f  vmovaps [rsp+0x30], xmm3
000074113b7d0c35  vmovaps [rsp+0x40], xmm4
000074113b7d0c3b  vmovaps [rsp+0x50], xmm5
000074113b7d0c41  vmovaps [rsp+0x60], xmm6
000074113b7d0c47  vmovaps [rsp+0x70], xmm7
000074113b7d0c4d  vmovaps [rsp+0x80], xmm8
000074113b7d0c56  vmovaps [rsp+0x90], xmm9
000074113b7d0c5f  vmovaps [rsp+0xA0], xmm10
000074113b7d0c68  vmovaps [rsp+0xB0], xmm11
000074113b7d0c71  vmovaps [rsp+0xC0], xmm12
000074113b7d0c7a  vmovaps [rsp+0xD0], xmm13
000074113b7d0c83  vmovaps [rsp+0xE0], xmm14
000074113b7d0c8c  sub rsp, 0x40
000074113b7d0c90  lea rdi, [rsp]
000074113b7d0c94  lea rsi, [rsp+0x10]
000074113b7d0c99  lea rdx, [rsp+0x20]
000074113b7d0c9e  lea rcx, [rsp+0x30]
000074113b7d0ca3  mov r8d, 0x00
000074113b7d0ca9  lea r9, [r15+0x3A8]
000074113b7d0cb0  movaps [rdi], xmm15
000074113b7d0cb4  movaps [rsi], xmm12
000074113b7d0cb8  movaps [rdx], xmm13
000074113b7d0cbc  movaps [rcx], xmm1
000074113b7d0cbf  mov rax, 0x629073062A50
000074113b7d0cc9  call rax
000074113b7d0ccb  movaps xmm15, [rsp]
000074113b7d0cd0  add rsp, 0x40
000074113b7d0cd4  vmovaps xmm0, [rsp]
000074113b7d0cd9  vmovaps xmm1, [rsp+0x10]
000074113b7d0cdf  vmovaps xmm2, [rsp+0x20]
000074113b7d0ce5  vmovaps xmm3, [rsp+0x30]
000074113b7d0ceb  vmovaps xmm4, [rsp+0x40]
000074113b7d0cf1  vmovaps xmm5, [rsp+0x50]
000074113b7d0cf7  vmovaps xmm6, [rsp+0x60]
000074113b7d0cfd  vmovaps xmm7, [rsp+0x70]
000074113b7d0d03  vmovaps xmm8, [rsp+0x80]
000074113b7d0d0c  vmovaps xmm9, [rsp+0x90]
000074113b7d0d15  vmovaps xmm10, [rsp+0xA0]
000074113b7d0d1e  vmovaps xmm11, [rsp+0xB0]
000074113b7d0d27  vmovaps xmm12, [rsp+0xC0]
000074113b7d0d30  vmovaps xmm13, [rsp+0xD0]
000074113b7d0d39  vmovaps xmm14, [rsp+0xE0]
000074113b7d0d42  add rsp, 0xF0
000074113b7d0d49  pop r11
000074113b7d0d4b  pop r10
000074113b7d0d4d  pop r9
000074113b7d0d4f  pop r8
000074113b7d0d51  pop rsi
000074113b7d0d52  pop rdi
000074113b7d0d53  pop rdx
000074113b7d0d54  pop rcx
000074113b7d0d55  pop rax
000074113b7d0d56  add rsp, 0x08
000074113b7d0d5a  jmp 0x000074113B7CF9D1
000074113b7d0d5f  sub rsp, 0x08
000074113b7d0d63  push rax
000074113b7d0d64  push rcx
000074113b7d0d65  push rdx
000074113b7d0d66  push rdi
000074113b7d0d67  push rsi
000074113b7d0d68  push r8
000074113b7d0d6a  push r9
000074113b7d0d6c  push r10
000074113b7d0d6e  push r11
000074113b7d0d70  sub rsp, 0xF0
000074113b7d0d77  vmovaps [rsp], xmm0
000074113b7d0d7c  vmovaps [rsp+0x10], xmm1
000074113b7d0d82  vmovaps [rsp+0x20], xmm2
000074113b7d0d88  vmovaps [rsp+0x30], xmm3
000074113b7d0d8e  vmovaps [rsp+0x40], xmm4
000074113b7d0d94  vmovaps [rsp+0x50], xmm5
000074113b7d0d9a  vmovaps [rsp+0x60], xmm6
000074113b7d0da0  vmovaps [rsp+0x70], xmm7
000074113b7d0da6  vmovaps [rsp+0x80], xmm8
000074113b7d0daf  vmovaps [rsp+0x90], xmm9
000074113b7d0db8  vmovaps [rsp+0xA0], xmm10
000074113b7d0dc1  vmovaps [rsp+0xB0], xmm11
000074113b7d0dca  vmovaps [rsp+0xC0], xmm12
000074113b7d0dd3  vmovaps [rsp+0xD0], xmm13
000074113b7d0ddc  vmovaps [rsp+0xE0], xmm14
000074113b7d0de5  sub rsp, 0x40
000074113b7d0de9  lea rdi, [rsp]
000074113b7d0ded  lea rsi, [rsp+0x10]
000074113b7d0df2  lea rdx, [rsp+0x20]
000074113b7d0df7  lea rcx, [rsp+0x30]
000074113b7d0dfc  mov r8d, 0x00
000074113b7d0e02  lea r9, [r15+0x3A8]
000074113b7d0e09  movaps [rdi], xmm15
000074113b7d0e0d  movaps [rsi], xmm3
000074113b7d0e10  movaps [rdx], xmm1
000074113b7d0e13  movaps [rcx], xmm8
000074113b7d0e17  mov rax, 0x629073062A50
000074113b7d0e21  call rax
000074113b7d0e23  movaps xmm15, [rsp]
000074113b7d0e28  add rsp, 0x40
000074113b7d0e2c  vmovaps xmm0, [rsp]
000074113b7d0e31  vmovaps xmm1, [rsp+0x10]
000074113b7d0e37  vmovaps xmm2, [rsp+0x20]
000074113b7d0e3d  vmovaps xmm3, [rsp+0x30]
000074113b7d0e43  vmovaps xmm4, [rsp+0x40]
000074113b7d0e49  vmovaps xmm5, [rsp+0x50]
000074113b7d0e4f  vmovaps xmm6, [rsp+0x60]
000074113b7d0e55  vmovaps xmm7, [rsp+0x70]
000074113b7d0e5b  vmovaps xmm8, [rsp+0x80]
000074113b7d0e64  vmovaps xmm9, [rsp+0x90]
000074113b7d0e6d  vmovaps xmm10, [rsp+0xA0]
000074113b7d0e76  vmovaps xmm11, [rsp+0xB0]
000074113b7d0e7f  vmovaps xmm12, [rsp+0xC0]
000074113b7d0e88  vmovaps xmm13, [rsp+0xD0]
000074113b7d0e91  vmovaps xmm14, [rsp+0xE0]
000074113b7d0e9a  add rsp, 0xF0
000074113b7d0ea1  pop r11
000074113b7d0ea3  pop r10
000074113b7d0ea5  pop r9
000074113b7d0ea7  pop r8
000074113b7d0ea9  pop rsi
000074113b7d0eaa  pop rdi
000074113b7d0eab  pop rdx
000074113b7d0eac  pop rcx
000074113b7d0ead  pop rax
000074113b7d0eae  add rsp, 0x08
000074113b7d0eb2  jmp 0x000074113B7CFA82
000074113b7d0eb7  sub rsp, 0x08
000074113b7d0ebb  push rax
000074113b7d0ebc  push rcx
000074113b7d0ebd  push rdx
000074113b7d0ebe  push rdi
000074113b7d0ebf  push rsi
000074113b7d0ec0  push r8
000074113b7d0ec2  push r9
000074113b7d0ec4  push r10
000074113b7d0ec6  push r11
000074113b7d0ec8  sub rsp, 0xF0
000074113b7d0ecf  vmovaps [rsp], xmm0
000074113b7d0ed4  vmovaps [rsp+0x10], xmm1
000074113b7d0eda  vmovaps [rsp+0x20], xmm2
000074113b7d0ee0  vmovaps [rsp+0x30], xmm3
000074113b7d0ee6  vmovaps [rsp+0x40], xmm4
000074113b7d0eec  vmovaps [rsp+0x50], xmm5
000074113b7d0ef2  vmovaps [rsp+0x60], xmm6
000074113b7d0ef8  vmovaps [rsp+0x70], xmm7
000074113b7d0efe  vmovaps [rsp+0x80], xmm9
000074113b7d0f07  vmovaps [rsp+0x90], xmm10
000074113b7d0f10  vmovaps [rsp+0xA0], xmm11
000074113b7d0f19  vmovaps [rsp+0xB0], xmm12
000074113b7d0f22  vmovaps [rsp+0xC0], xmm13
000074113b7d0f2b  vmovaps [rsp+0xD0], xmm14
000074113b7d0f34  vmovaps [rsp+0xE0], xmm15
000074113b7d0f3d  sub rsp, 0x40
000074113b7d0f41  lea rdi, [rsp]
000074113b7d0f45  lea rsi, [rsp+0x10]
000074113b7d0f4a  lea rdx, [rsp+0x20]
000074113b7d0f4f  lea rcx, [rsp+0x30]
000074113b7d0f54  mov r8d, 0x00
000074113b7d0f5a  lea r9, [r15+0x3A8]
000074113b7d0f61  movaps [rdi], xmm8
000074113b7d0f65  movaps [rsi], xmm9
000074113b7d0f69  movaps [rdx], xmm5
000074113b7d0f6c  movaps [rcx], xmm1
000074113b7d0f6f  mov rax, 0x629073062A50
000074113b7d0f79  call rax
000074113b7d0f7b  movaps xmm8, [rsp]
000074113b7d0f80  add rsp, 0x40
000074113b7d0f84  vmovaps xmm0, [rsp]
000074113b7d0f89  vmovaps xmm1, [rsp+0x10]
000074113b7d0f8f  vmovaps xmm2, [rsp+0x20]
000074113b7d0f95  vmovaps xmm3, [rsp+0x30]
000074113b7d0f9b  vmovaps xmm4, [rsp+0x40]
000074113b7d0fa1  vmovaps xmm5, [rsp+0x50]
000074113b7d0fa7  vmovaps xmm6, [rsp+0x60]
000074113b7d0fad  vmovaps xmm7, [rsp+0x70]
000074113b7d0fb3  vmovaps xmm9, [rsp+0x80]
000074113b7d0fbc  vmovaps xmm10, [rsp+0x90]
000074113b7d0fc5  vmovaps xmm11, [rsp+0xA0]
000074113b7d0fce  vmovaps xmm12, [rsp+0xB0]
000074113b7d0fd7  vmovaps xmm13, [rsp+0xC0]
000074113b7d0fe0  vmovaps xmm14, [rsp+0xD0]
000074113b7d0fe9  vmovaps xmm15, [rsp+0xE0]
000074113b7d0ff2  add rsp, 0xF0
000074113b7d0ff9  pop r11
000074113b7d0ffb  pop r10
000074113b7d0ffd  pop r9
000074113b7d0fff  pop r8
000074113b7d1001  pop rsi
000074113b7d1002  pop rdi
000074113b7d1003  pop rdx
000074113b7d1004  pop rcx
000074113b7d1005  pop rax
000074113b7d1006  add rsp, 0x08
000074113b7d100a  jmp 0x000074113B7CFAAB
000074113b7d100f  sub rsp, 0x08
000074113b7d1013  push rax
000074113b7d1014  push rcx
000074113b7d1015  push rdx
000074113b7d1016  push rdi
000074113b7d1017  push rsi
000074113b7d1018  push r8
000074113b7d101a  push r9
000074113b7d101c  push r10
000074113b7d101e  push r11
000074113b7d1020  sub rsp, 0xF0
000074113b7d1027  vmovaps [rsp], xmm0
000074113b7d102c  vmovaps [rsp+0x10], xmm1
000074113b7d1032  vmovaps [rsp+0x20], xmm2
000074113b7d1038  vmovaps [rsp+0x30], xmm3
000074113b7d103e  vmovaps [rsp+0x40], xmm4
000074113b7d1044  vmovaps [rsp+0x50], xmm6
000074113b7d104a  vmovaps [rsp+0x60], xmm7
000074113b7d1050  vmovaps [rsp+0x70], xmm8
000074113b7d1056  vmovaps [rsp+0x80], xmm9
000074113b7d105f  vmovaps [rsp+0x90], xmm10
000074113b7d1068  vmovaps [rsp+0xA0], xmm11
000074113b7d1071  vmovaps [rsp+0xB0], xmm12
000074113b7d107a  vmovaps [rsp+0xC0], xmm13
000074113b7d1083  vmovaps [rsp+0xD0], xmm14
000074113b7d108c  vmovaps [rsp+0xE0], xmm15
000074113b7d1095  sub rsp, 0x40
000074113b7d1099  lea rdi, [rsp]
000074113b7d109d  lea rsi, [rsp+0x10]
000074113b7d10a2  lea rdx, [rsp+0x20]
000074113b7d10a7  lea rcx, [rsp+0x30]
000074113b7d10ac  mov r8d, 0x00
000074113b7d10b2  lea r9, [r15+0x3A8]
000074113b7d10b9  movaps [rdi], xmm5
000074113b7d10bc  movaps [rsi], xmm14
000074113b7d10c0  movaps [rdx], xmm9
000074113b7d10c4  movaps [rcx], xmm1
000074113b7d10c7  mov rax, 0x629073062A50
000074113b7d10d1  call rax
000074113b7d10d3  movaps xmm5, [rsp]
000074113b7d10d7  add rsp, 0x40
000074113b7d10db  vmovaps xmm0, [rsp]
000074113b7d10e0  vmovaps xmm1, [rsp+0x10]
000074113b7d10e6  vmovaps xmm2, [rsp+0x20]
000074113b7d10ec  vmovaps xmm3, [rsp+0x30]
000074113b7d10f2  vmovaps xmm4, [rsp+0x40]
000074113b7d10f8  vmovaps xmm6, [rsp+0x50]
000074113b7d10fe  vmovaps xmm7, [rsp+0x60]
000074113b7d1104  vmovaps xmm8, [rsp+0x70]
000074113b7d110a  vmovaps xmm9, [rsp+0x80]
000074113b7d1113  vmovaps xmm10, [rsp+0x90]
000074113b7d111c  vmovaps xmm11, [rsp+0xA0]
000074113b7d1125  vmovaps xmm12, [rsp+0xB0]
000074113b7d112e  vmovaps xmm13, [rsp+0xC0]
000074113b7d1137  vmovaps xmm14, [rsp+0xD0]
000074113b7d1140  vmovaps xmm15, [rsp+0xE0]
000074113b7d1149  add rsp, 0xF0
000074113b7d1150  pop r11
000074113b7d1152  pop r10
000074113b7d1154  pop r9
000074113b7d1156  pop r8
000074113b7d1158  pop rsi
000074113b7d1159  pop rdi
000074113b7d115a  pop rdx
000074113b7d115b  pop rcx
000074113b7d115c  pop rax
000074113b7d115d  add rsp, 0x08
000074113b7d1161  jmp 0x000074113B7CFADF
000074113b7d1166  sub rsp, 0x08
000074113b7d116a  push rax
000074113b7d116b  push rcx
000074113b7d116c  push rdx
000074113b7d116d  push rdi
000074113b7d116e  push rsi
000074113b7d116f  push r8
000074113b7d1171  push r9
000074113b7d1173  push r10
000074113b7d1175  push r11
000074113b7d1177  sub rsp, 0xF0
000074113b7d117e  vmovaps [rsp], xmm0
000074113b7d1183  vmovaps [rsp+0x10], xmm1
000074113b7d1189  vmovaps [rsp+0x20], xmm2
000074113b7d118f  vmovaps [rsp+0x30], xmm3
000074113b7d1195  vmovaps [rsp+0x40], xmm4
000074113b7d119b  vmovaps [rsp+0x50], xmm5
000074113b7d11a1  vmovaps [rsp+0x60], xmm6
000074113b7d11a7  vmovaps [rsp+0x70], xmm7
000074113b7d11ad  vmovaps [rsp+0x80], xmm8
000074113b7d11b6  vmovaps [rsp+0x90], xmm10
000074113b7d11bf  vmovaps [rsp+0xA0], xmm11
000074113b7d11c8  vmovaps [rsp+0xB0], xmm12
000074113b7d11d1  vmovaps [rsp+0xC0], xmm13
000074113b7d11da  vmovaps [rsp+0xD0], xmm14
000074113b7d11e3  vmovaps [rsp+0xE0], xmm15
000074113b7d11ec  sub rsp, 0x40
000074113b7d11f0  lea rdi, [rsp]
000074113b7d11f4  lea rsi, [rsp+0x10]
000074113b7d11f9  lea rdx, [rsp+0x20]
000074113b7d11fe  lea rcx, [rsp+0x30]
000074113b7d1203  mov r8d, 0x00
000074113b7d1209  lea r9, [r15+0x3A8]
000074113b7d1210  movaps [rdi], xmm9
000074113b7d1214  movaps [rsi], xmm14
000074113b7d1218  movaps [rdx], xmm4
000074113b7d121b  movaps [rcx], xmm1
000074113b7d121e  mov rax, 0x629073062A50
000074113b7d1228  call rax
000074113b7d122a  movaps xmm9, [rsp]
000074113b7d122f  add rsp, 0x40
000074113b7d1233  vmovaps xmm0, [rsp]
000074113b7d1238  vmovaps xmm1, [rsp+0x10]
000074113b7d123e  vmovaps xmm2, [rsp+0x20]
000074113b7d1244  vmovaps xmm3, [rsp+0x30]
000074113b7d124a  vmovaps xmm4, [rsp+0x40]
000074113b7d1250  vmovaps xmm5, [rsp+0x50]
000074113b7d1256  vmovaps xmm6, [rsp+0x60]
000074113b7d125c  vmovaps xmm7, [rsp+0x70]
000074113b7d1262  vmovaps xmm8, [rsp+0x80]
000074113b7d126b  vmovaps xmm10, [rsp+0x90]
000074113b7d1274  vmovaps xmm11, [rsp+0xA0]
000074113b7d127d  vmovaps xmm12, [rsp+0xB0]
000074113b7d1286  vmovaps xmm13, [rsp+0xC0]
000074113b7d128f  vmovaps xmm14, [rsp+0xD0]
000074113b7d1298  vmovaps xmm15, [rsp+0xE0]
000074113b7d12a1  add rsp, 0xF0
000074113b7d12a8  pop r11
000074113b7d12aa  pop r10
000074113b7d12ac  pop r9
000074113b7d12ae  pop r8
000074113b7d12b0  pop rsi
000074113b7d12b1  pop rdi
000074113b7d12b2  pop rdx
000074113b7d12b3  pop rcx
000074113b7d12b4  pop rax
000074113b7d12b5  add rsp, 0x08
000074113b7d12b9  jmp 0x000074113B7CFB0E
000074113b7d12be  sub rsp, 0x08
000074113b7d12c2  push rax
000074113b7d12c3  push rcx
000074113b7d12c4  push rdx
000074113b7d12c5  push rdi
000074113b7d12c6  push rsi
000074113b7d12c7  push r8
000074113b7d12c9  push r9
000074113b7d12cb  push r10
000074113b7d12cd  push r11
000074113b7d12cf  sub rsp, 0xF0
000074113b7d12d6  vmovaps [rsp], xmm0
000074113b7d12db  vmovaps [rsp+0x10], xmm1
000074113b7d12e1  vmovaps [rsp+0x20], xmm3
000074113b7d12e7  vmovaps [rsp+0x30], xmm4
000074113b7d12ed  vmovaps [rsp+0x40], xmm5
000074113b7d12f3  vmovaps [rsp+0x50], xmm6
000074113b7d12f9  vmovaps [rsp+0x60], xmm7
000074113b7d12ff  vmovaps [rsp+0x70], xmm8
000074113b7d1305  vmovaps [rsp+0x80], xmm9
000074113b7d130e  vmovaps [rsp+0x90], xmm10
000074113b7d1317  vmovaps [rsp+0xA0], xmm11
000074113b7d1320  vmovaps [rsp+0xB0], xmm12
000074113b7d1329  vmovaps [rsp+0xC0], xmm13
000074113b7d1332  vmovaps [rsp+0xD0], xmm14
000074113b7d133b  vmovaps [rsp+0xE0], xmm15
000074113b7d1344  sub rsp, 0x40
000074113b7d1348  lea rdi, [rsp]
000074113b7d134c  lea rsi, [rsp+0x10]
000074113b7d1351  lea rdx, [rsp+0x20]
000074113b7d1356  lea rcx, [rsp+0x30]
000074113b7d135b  mov r8d, 0x00
000074113b7d1361  lea r9, [r15+0x3A8]
000074113b7d1368  movaps [rdi], xmm2
000074113b7d136b  movaps [rsi], xmm8
000074113b7d136f  movaps [rdx], xmm13
000074113b7d1373  movaps [rcx], xmm3
000074113b7d1376  mov rax, 0x629073062A50
000074113b7d1380  call rax
000074113b7d1382  movaps xmm2, [rsp]
000074113b7d1386  add rsp, 0x40
000074113b7d138a  vmovaps xmm0, [rsp]
000074113b7d138f  vmovaps xmm1, [rsp+0x10]
000074113b7d1395  vmovaps xmm3, [rsp+0x20]
000074113b7d139b  vmovaps xmm4, [rsp+0x30]
000074113b7d13a1  vmovaps xmm5, [rsp+0x40]
000074113b7d13a7  vmovaps xmm6, [rsp+0x50]
000074113b7d13ad  vmovaps xmm7, [rsp+0x60]
000074113b7d13b3  vmovaps xmm8, [rsp+0x70]
000074113b7d13b9  vmovaps xmm9, [rsp+0x80]
000074113b7d13c2  vmovaps xmm10, [rsp+0x90]
000074113b7d13cb  vmovaps xmm11, [rsp+0xA0]
000074113b7d13d4  vmovaps xmm12, [rsp+0xB0]
000074113b7d13dd  vmovaps xmm13, [rsp+0xC0]
000074113b7d13e6  vmovaps xmm14, [rsp+0xD0]
000074113b7d13ef  vmovaps xmm15, [rsp+0xE0]
000074113b7d13f8  add rsp, 0xF0
000074113b7d13ff  pop r11
000074113b7d1401  pop r10
000074113b7d1403  pop r9
000074113b7d1405  pop r8
000074113b7d1407  pop rsi
000074113b7d1408  pop rdi
000074113b7d1409  pop rdx
000074113b7d140a  pop rcx
000074113b7d140b  pop rax
000074113b7d140c  add rsp, 0x08
000074113b7d1410  jmp 0x000074113B7CFB8C
000074113b7d1415  sub rsp, 0x08
000074113b7d1419  push rax
000074113b7d141a  push rcx
000074113b7d141b  push rdx
000074113b7d141c  push rdi
000074113b7d141d  push rsi
000074113b7d141e  push r8
000074113b7d1420  push r9
000074113b7d1422  push r10
000074113b7d1424  push r11
000074113b7d1426  sub rsp, 0xF0
000074113b7d142d  vmovaps [rsp], xmm0
000074113b7d1432  vmovaps [rsp+0x10], xmm1
000074113b7d1438  vmovaps [rsp+0x20], xmm2
000074113b7d143e  vmovaps [rsp+0x30], xmm3
000074113b7d1444  vmovaps [rsp+0x40], xmm4
000074113b7d144a  vmovaps [rsp+0x50], xmm5
000074113b7d1450  vmovaps [rsp+0x60], xmm6
000074113b7d1456  vmovaps [rsp+0x70], xmm7
000074113b7d145c  vmovaps [rsp+0x80], xmm9
000074113b7d1465  vmovaps [rsp+0x90], xmm10
000074113b7d146e  vmovaps [rsp+0xA0], xmm11
000074113b7d1477  vmovaps [rsp+0xB0], xmm12
000074113b7d1480  vmovaps [rsp+0xC0], xmm13
000074113b7d1489  vmovaps [rsp+0xD0], xmm14
000074113b7d1492  vmovaps [rsp+0xE0], xmm15
000074113b7d149b  sub rsp, 0x40
000074113b7d149f  lea rdi, [rsp]
000074113b7d14a3  lea rsi, [rsp+0x10]
000074113b7d14a8  lea rdx, [rsp+0x20]
000074113b7d14ad  lea rcx, [rsp+0x30]
000074113b7d14b2  mov r8d, 0x00
000074113b7d14b8  lea r9, [r15+0x3A8]
000074113b7d14bf  movaps [rdi], xmm8
000074113b7d14c3  movaps [rsi], xmm15
000074113b7d14c7  movaps [rdx], xmm13
000074113b7d14cb  movaps [rcx], xmm1
000074113b7d14ce  mov rax, 0x629073062A50
000074113b7d14d8  call rax
000074113b7d14da  movaps xmm8, [rsp]
000074113b7d14df  add rsp, 0x40
000074113b7d14e3  vmovaps xmm0, [rsp]
000074113b7d14e8  vmovaps xmm1, [rsp+0x10]
000074113b7d14ee  vmovaps xmm2, [rsp+0x20]
000074113b7d14f4  vmovaps xmm3, [rsp+0x30]
000074113b7d14fa  vmovaps xmm4, [rsp+0x40]
000074113b7d1500  vmovaps xmm5, [rsp+0x50]
000074113b7d1506  vmovaps xmm6, [rsp+0x60]
000074113b7d150c  vmovaps xmm7, [rsp+0x70]
000074113b7d1512  vmovaps xmm9, [rsp+0x80]
000074113b7d151b  vmovaps xmm10, [rsp+0x90]
000074113b7d1524  vmovaps xmm11, [rsp+0xA0]
000074113b7d152d  vmovaps xmm12, [rsp+0xB0]
000074113b7d1536  vmovaps xmm13, [rsp+0xC0]
000074113b7d153f  vmovaps xmm14, [rsp+0xD0]
000074113b7d1548  vmovaps xmm15, [rsp+0xE0]
000074113b7d1551  add rsp, 0xF0
000074113b7d1558  pop r11
000074113b7d155a  pop r10
000074113b7d155c  pop r9
000074113b7d155e  pop r8
000074113b7d1560  pop rsi
000074113b7d1561  pop rdi
000074113b7d1562  pop rdx
000074113b7d1563  pop rcx
000074113b7d1564  pop rax
000074113b7d1565  add rsp, 0x08
000074113b7d1569  jmp 0x000074113B7CFBBB
000074113b7d156e  call 0x000074113B5FF430
000074113b7d1573  jmp 0x000074113B7CFBC8
000074113b7d1578  sub rsp, 0x08
000074113b7d157c  push rax
000074113b7d157d  push rcx
000074113b7d157e  push rdx
000074113b7d157f  push rdi
000074113b7d1580  push rsi
000074113b7d1581  push r8
000074113b7d1583  push r9
000074113b7d1585  push r10
000074113b7d1587  push r11
000074113b7d1589  sub rsp, 0xF0
000074113b7d1590  vmovaps [rsp], xmm0
000074113b7d1595  vmovaps [rsp+0x10], xmm1
000074113b7d159b  vmovaps [rsp+0x20], xmm2
000074113b7d15a1  vmovaps [rsp+0x30], xmm3
000074113b7d15a7  vmovaps [rsp+0x40], xmm4
000074113b7d15ad  vmovaps [rsp+0x50], xmm5
000074113b7d15b3  vmovaps [rsp+0x60], xmm6
000074113b7d15b9  vmovaps [rsp+0x70], xmm7
000074113b7d15bf  vmovaps [rsp+0x80], xmm8
000074113b7d15c8  vmovaps [rsp+0x90], xmm9
000074113b7d15d1  vmovaps [rsp+0xA0], xmm10
000074113b7d15da  vmovaps [rsp+0xB0], xmm11
000074113b7d15e3  vmovaps [rsp+0xC0], xmm12
000074113b7d15ec  vmovaps [rsp+0xD0], xmm14
000074113b7d15f5  vmovaps [rsp+0xE0], xmm15
000074113b7d15fe  sub rsp, 0x40
000074113b7d1602  lea rdi, [rsp]
000074113b7d1606  lea rsi, [rsp+0x10]
000074113b7d160b  lea rdx, [rsp+0x20]
000074113b7d1610  lea rcx, [rsp+0x30]
000074113b7d1615  mov r8d, 0x00
000074113b7d161b  lea r9, [r15+0x3A8]
000074113b7d1622  movaps [rdi], xmm13
000074113b7d1626  movaps [rsi], xmm5
000074113b7d1629  movaps [rdx], xmm11
000074113b7d162d  movaps [rcx], xmm15
000074113b7d1631  mov rax, 0x629073062A50
000074113b7d163b  call rax
000074113b7d163d  movaps xmm13, [rsp]
000074113b7d1642  add rsp, 0x40
000074113b7d1646  vmovaps xmm0, [rsp]
000074113b7d164b  vmovaps xmm1, [rsp+0x10]
000074113b7d1651  vmovaps xmm2, [rsp+0x20]
000074113b7d1657  vmovaps xmm3, [rsp+0x30]
000074113b7d165d  vmovaps xmm4, [rsp+0x40]
000074113b7d1663  vmovaps xmm5, [rsp+0x50]
000074113b7d1669  vmovaps xmm6, [rsp+0x60]
000074113b7d166f  vmovaps xmm7, [rsp+0x70]
000074113b7d1675  vmovaps xmm8, [rsp+0x80]
000074113b7d167e  vmovaps xmm9, [rsp+0x90]
000074113b7d1687  vmovaps xmm10, [rsp+0xA0]
000074113b7d1690  vmovaps xmm11, [rsp+0xB0]
000074113b7d1699  vmovaps xmm12, [rsp+0xC0]
000074113b7d16a2  vmovaps xmm14, [rsp+0xD0]
000074113b7d16ab  vmovaps xmm15, [rsp+0xE0]
000074113b7d16b4  add rsp, 0xF0
000074113b7d16bb  pop r11
000074113b7d16bd  pop r10
000074113b7d16bf  pop r9
000074113b7d16c1  pop r8
000074113b7d16c3  pop rsi
000074113b7d16c4  pop rdi
000074113b7d16c5  pop rdx
000074113b7d16c6  pop rcx
000074113b7d16c7  pop rax
000074113b7d16c8  add rsp, 0x08
000074113b7d16cc  jmp 0x000074113B7CFBF9
000074113b7d16d1  sub rsp, 0x08
000074113b7d16d5  push rax
000074113b7d16d6  push rcx
000074113b7d16d7  push rdx
000074113b7d16d8  push rdi
000074113b7d16d9  push rsi
000074113b7d16da  push r8
000074113b7d16dc  push r9
000074113b7d16de  push r10
000074113b7d16e0  push r11
000074113b7d16e2  sub rsp, 0xF0
000074113b7d16e9  vmovaps [rsp], xmm0
000074113b7d16ee  vmovaps [rsp+0x10], xmm1
000074113b7d16f4  vmovaps [rsp+0x20], xmm2
000074113b7d16fa  vmovaps [rsp+0x30], xmm3
000074113b7d1700  vmovaps [rsp+0x40], xmm4
000074113b7d1706  vmovaps [rsp+0x50], xmm5
000074113b7d170c  vmovaps [rsp+0x60], xmm6
000074113b7d1712  vmovaps [rsp+0x70], xmm7
000074113b7d1718  vmovaps [rsp+0x80], xmm8
000074113b7d1721  vmovaps [rsp+0x90], xmm9
000074113b7d172a  vmovaps [rsp+0xA0], xmm10
000074113b7d1733  vmovaps [rsp+0xB0], xmm12
000074113b7d173c  vmovaps [rsp+0xC0], xmm13
000074113b7d1745  vmovaps [rsp+0xD0], xmm14
000074113b7d174e  vmovaps [rsp+0xE0], xmm15
000074113b7d1757  sub rsp, 0x40
000074113b7d175b  lea rdi, [rsp]
000074113b7d175f  lea rsi, [rsp+0x10]
000074113b7d1764  lea rdx, [rsp+0x20]
000074113b7d1769  lea rcx, [rsp+0x30]
000074113b7d176e  mov r8d, 0x00
000074113b7d1774  lea r9, [r15+0x3A8]
000074113b7d177b  movaps [rdi], xmm11
000074113b7d177f  movaps [rsi], xmm9
000074113b7d1783  movaps [rdx], xmm4
000074113b7d1786  movaps [rcx], xmm15
000074113b7d178a  mov rax, 0x629073062A50
000074113b7d1794  call rax
000074113b7d1796  movaps xmm11, [rsp]
000074113b7d179b  add rsp, 0x40
000074113b7d179f  vmovaps xmm0, [rsp]
000074113b7d17a4  vmovaps xmm1, [rsp+0x10]
000074113b7d17aa  vmovaps xmm2, [rsp+0x20]
000074113b7d17b0  vmovaps xmm3, [rsp+0x30]
000074113b7d17b6  vmovaps xmm4, [rsp+0x40]
000074113b7d17bc  vmovaps xmm5, [rsp+0x50]
000074113b7d17c2  vmovaps xmm6, [rsp+0x60]
000074113b7d17c8  vmovaps xmm7, [rsp+0x70]
000074113b7d17ce  vmovaps xmm8, [rsp+0x80]
000074113b7d17d7  vmovaps xmm9, [rsp+0x90]
000074113b7d17e0  vmovaps xmm10, [rsp+0xA0]
000074113b7d17e9  vmovaps xmm12, [rsp+0xB0]
000074113b7d17f2  vmovaps xmm13, [rsp+0xC0]
000074113b7d17fb  vmovaps xmm14, [rsp+0xD0]
000074113b7d1804  vmovaps xmm15, [rsp+0xE0]
000074113b7d180d  add rsp, 0xF0
000074113b7d1814  pop r11
000074113b7d1816  pop r10
000074113b7d1818  pop r9
000074113b7d181a  pop r8
000074113b7d181c  pop rsi
000074113b7d181d  pop rdi
000074113b7d181e  pop rdx
000074113b7d181f  pop rcx
000074113b7d1820  pop rax
000074113b7d1821  add rsp, 0x08
000074113b7d1825  jmp 0x000074113B7CFC22
000074113b7d182a  call 0x000074113B60E760
000074113b7d182f  jmp 0x000074113B7CFC45
000074113b7d1834  call 0x000074113B607890
000074113b7d1839  jmp 0x000074113B7CFC4F
000074113b7d183e  sub rsp, 0x08
000074113b7d1842  push rax
000074113b7d1843  push rcx
000074113b7d1844  push rdx
000074113b7d1845  push rdi
000074113b7d1846  push rsi
000074113b7d1847  push r8
000074113b7d1849  push r9
000074113b7d184b  push r10
000074113b7d184d  push r11
000074113b7d184f  sub rsp, 0xF0
000074113b7d1856  vmovaps [rsp], xmm0
000074113b7d185b  vmovaps [rsp+0x10], xmm1
000074113b7d1861  vmovaps [rsp+0x20], xmm2
000074113b7d1867  vmovaps [rsp+0x30], xmm3
000074113b7d186d  vmovaps [rsp+0x40], xmm5
000074113b7d1873  vmovaps [rsp+0x50], xmm6
000074113b7d1879  vmovaps [rsp+0x60], xmm7
000074113b7d187f  vmovaps [rsp+0x70], xmm8
000074113b7d1885  vmovaps [rsp+0x80], xmm9
000074113b7d188e  vmovaps [rsp+0x90], xmm10
000074113b7d1897  vmovaps [rsp+0xA0], xmm11
000074113b7d18a0  vmovaps [rsp+0xB0], xmm12
000074113b7d18a9  vmovaps [rsp+0xC0], xmm13
000074113b7d18b2  vmovaps [rsp+0xD0], xmm14
000074113b7d18bb  vmovaps [rsp+0xE0], xmm15
000074113b7d18c4  sub rsp, 0x40
000074113b7d18c8  lea rdi, [rsp]
000074113b7d18cc  lea rsi, [rsp+0x10]
000074113b7d18d1  lea rdx, [rsp+0x20]
000074113b7d18d6  lea rcx, [rsp+0x30]
000074113b7d18db  mov r8d, 0x00
000074113b7d18e1  lea r9, [r15+0x3A8]
000074113b7d18e8  movaps [rdi], xmm4
000074113b7d18eb  movaps [rsi], xmm2
000074113b7d18ee  movaps [rdx], xmm14
000074113b7d18f2  movaps [rcx], xmm5
000074113b7d18f5  mov rax, 0x629073062A50
000074113b7d18ff  call rax
000074113b7d1901  movaps xmm4, [rsp]
000074113b7d1905  add rsp, 0x40
000074113b7d1909  vmovaps xmm0, [rsp]
000074113b7d190e  vmovaps xmm1, [rsp+0x10]
000074113b7d1914  vmovaps xmm2, [rsp+0x20]
000074113b7d191a  vmovaps xmm3, [rsp+0x30]
000074113b7d1920  vmovaps xmm5, [rsp+0x40]
000074113b7d1926  vmovaps xmm6, [rsp+0x50]
000074113b7d192c  vmovaps xmm7, [rsp+0x60]
000074113b7d1932  vmovaps xmm8, [rsp+0x70]
000074113b7d1938  vmovaps xmm9, [rsp+0x80]
000074113b7d1941  vmovaps xmm10, [rsp+0x90]
000074113b7d194a  vmovaps xmm11, [rsp+0xA0]
000074113b7d1953  vmovaps xmm12, [rsp+0xB0]
000074113b7d195c  vmovaps xmm13, [rsp+0xC0]
000074113b7d1965  vmovaps xmm14, [rsp+0xD0]
000074113b7d196e  vmovaps xmm15, [rsp+0xE0]
000074113b7d1977  add rsp, 0xF0
000074113b7d197e  pop r11
000074113b7d1980  pop r10
000074113b7d1982  pop r9
000074113b7d1984  pop r8
000074113b7d1986  pop rsi
000074113b7d1987  pop rdi
000074113b7d1988  pop rdx
000074113b7d1989  pop rcx
000074113b7d198a  pop rax
000074113b7d198b  add rsp, 0x08
000074113b7d198f  jmp 0x000074113B7CFC86
000074113b7d1994  sub rsp, 0x08
000074113b7d1998  push rax
000074113b7d1999  push rcx
000074113b7d199a  push rdx
000074113b7d199b  push rdi
000074113b7d199c  push rsi
000074113b7d199d  push r8
000074113b7d199f  push r9
000074113b7d19a1  push r10
000074113b7d19a3  push r11
000074113b7d19a5  sub rsp, 0xF0
000074113b7d19ac  vmovaps [rsp], xmm0
000074113b7d19b1  vmovaps [rsp+0x10], xmm1
000074113b7d19b7  vmovaps [rsp+0x20], xmm2
000074113b7d19bd  vmovaps [rsp+0x30], xmm3
000074113b7d19c3  vmovaps [rsp+0x40], xmm4
000074113b7d19c9  vmovaps [rsp+0x50], xmm6
000074113b7d19cf  vmovaps [rsp+0x60], xmm7
000074113b7d19d5  vmovaps [rsp+0x70], xmm8
000074113b7d19db  vmovaps [rsp+0x80], xmm9
000074113b7d19e4  vmovaps [rsp+0x90], xmm10
000074113b7d19ed  vmovaps [rsp+0xA0], xmm11
000074113b7d19f6  vmovaps [rsp+0xB0], xmm12
000074113b7d19ff  vmovaps [rsp+0xC0], xmm13
000074113b7d1a08  vmovaps [rsp+0xD0], xmm14
000074113b7d1a11  vmovaps [rsp+0xE0], xmm15
000074113b7d1a1a  sub rsp, 0x40
000074113b7d1a1e  lea rdi, [rsp]
000074113b7d1a22  lea rsi, [rsp+0x10]
000074113b7d1a27  lea rdx, [rsp+0x20]
000074113b7d1a2c  lea rcx, [rsp+0x30]
000074113b7d1a31  mov r8d, 0x00
000074113b7d1a37  lea r9, [r15+0x3A8]
000074113b7d1a3e  movaps [rdi], xmm5
000074113b7d1a41  movaps [rsi], xmm8
000074113b7d1a45  movaps [rdx], xmm7
000074113b7d1a48  movaps [rcx], xmm14
000074113b7d1a4c  mov rax, 0x629073062A50
000074113b7d1a56  call rax
000074113b7d1a58  movaps xmm5, [rsp]
000074113b7d1a5c  add rsp, 0x40
000074113b7d1a60  vmovaps xmm0, [rsp]
000074113b7d1a65  vmovaps xmm1, [rsp+0x10]
000074113b7d1a6b  vmovaps xmm2, [rsp+0x20]
000074113b7d1a71  vmovaps xmm3, [rsp+0x30]
000074113b7d1a77  vmovaps xmm4, [rsp+0x40]
000074113b7d1a7d  vmovaps xmm6, [rsp+0x50]
000074113b7d1a83  vmovaps xmm7, [rsp+0x60]
000074113b7d1a89  vmovaps xmm8, [rsp+0x70]
000074113b7d1a8f  vmovaps xmm9, [rsp+0x80]
000074113b7d1a98  vmovaps xmm10, [rsp+0x90]
000074113b7d1aa1  vmovaps xmm11, [rsp+0xA0]
000074113b7d1aaa  vmovaps xmm12, [rsp+0xB0]
000074113b7d1ab3  vmovaps xmm13, [rsp+0xC0]
000074113b7d1abc  vmovaps xmm14, [rsp+0xD0]
000074113b7d1ac5  vmovaps xmm15, [rsp+0xE0]
000074113b7d1ace  add rsp, 0xF0
000074113b7d1ad5  pop r11
000074113b7d1ad7  pop r10
000074113b7d1ad9  pop r9
000074113b7d1adb  pop r8
000074113b7d1add  pop rsi
000074113b7d1ade  pop rdi
000074113b7d1adf  pop rdx
000074113b7d1ae0  pop rcx
000074113b7d1ae1  pop rax
000074113b7d1ae2  add rsp, 0x08
000074113b7d1ae6  jmp 0x000074113B7CFCAE
000074113b7d1aeb  sub rsp, 0x08
000074113b7d1aef  push rax
000074113b7d1af0  push rcx
000074113b7d1af1  push rdx
000074113b7d1af2  push rdi
000074113b7d1af3  push rsi
000074113b7d1af4  push r8
000074113b7d1af6  push r9
000074113b7d1af8  push r10
000074113b7d1afa  push r11
000074113b7d1afc  sub rsp, 0xF0
000074113b7d1b03  vmovaps [rsp], xmm0
000074113b7d1b08  vmovaps [rsp+0x10], xmm1
000074113b7d1b0e  vmovaps [rsp+0x20], xmm2
000074113b7d1b14  vmovaps [rsp+0x30], xmm3
000074113b7d1b1a  vmovaps [rsp+0x40], xmm4
000074113b7d1b20  vmovaps [rsp+0x50], xmm5
000074113b7d1b26  vmovaps [rsp+0x60], xmm6
000074113b7d1b2c  vmovaps [rsp+0x70], xmm7
000074113b7d1b32  vmovaps [rsp+0x80], xmm9
000074113b7d1b3b  vmovaps [rsp+0x90], xmm10
000074113b7d1b44  vmovaps [rsp+0xA0], xmm11
000074113b7d1b4d  vmovaps [rsp+0xB0], xmm12
000074113b7d1b56  vmovaps [rsp+0xC0], xmm13
000074113b7d1b5f  vmovaps [rsp+0xD0], xmm14
000074113b7d1b68  vmovaps [rsp+0xE0], xmm15
000074113b7d1b71  sub rsp, 0x40
000074113b7d1b75  lea rdi, [rsp]
000074113b7d1b79  lea rsi, [rsp+0x10]
000074113b7d1b7e  lea rdx, [rsp+0x20]
000074113b7d1b83  lea rcx, [rsp+0x30]
000074113b7d1b88  mov r8d, 0x00
000074113b7d1b8e  lea r9, [r15+0x3A8]
000074113b7d1b95  movaps [rdi], xmm8
000074113b7d1b99  movaps [rsi], xmm13
000074113b7d1b9d  movaps [rdx], xmm6
000074113b7d1ba0  movaps [rcx], xmm14
000074113b7d1ba4  mov rax, 0x629073062A50
000074113b7d1bae  call rax
000074113b7d1bb0  movaps xmm8, [rsp]
000074113b7d1bb5  add rsp, 0x40
000074113b7d1bb9  vmovaps xmm0, [rsp]
000074113b7d1bbe  vmovaps xmm1, [rsp+0x10]
000074113b7d1bc4  vmovaps xmm2, [rsp+0x20]
000074113b7d1bca  vmovaps xmm3, [rsp+0x30]
000074113b7d1bd0  vmovaps xmm4, [rsp+0x40]
000074113b7d1bd6  vmovaps xmm5, [rsp+0x50]
000074113b7d1bdc  vmovaps xmm6, [rsp+0x60]
000074113b7d1be2  vmovaps xmm7, [rsp+0x70]
000074113b7d1be8  vmovaps xmm9, [rsp+0x80]
000074113b7d1bf1  vmovaps xmm10, [rsp+0x90]
000074113b7d1bfa  vmovaps xmm11, [rsp+0xA0]
000074113b7d1c03  vmovaps xmm12, [rsp+0xB0]
000074113b7d1c0c  vmovaps xmm13, [rsp+0xC0]
000074113b7d1c15  vmovaps xmm14, [rsp+0xD0]
000074113b7d1c1e  vmovaps xmm15, [rsp+0xE0]
000074113b7d1c27  add rsp, 0xF0
000074113b7d1c2e  pop r11
000074113b7d1c30  pop r10
000074113b7d1c32  pop r9
000074113b7d1c34  pop r8
000074113b7d1c36  pop rsi
000074113b7d1c37  pop rdi
000074113b7d1c38  pop rdx
000074113b7d1c39  pop rcx
000074113b7d1c3a  pop rax
000074113b7d1c3b  add rsp, 0x08
000074113b7d1c3f  jmp 0x000074113B7CFCD7
000074113b7d1c44  sub rsp, 0x08
000074113b7d1c48  push rax
000074113b7d1c49  push rcx
000074113b7d1c4a  push rdx
000074113b7d1c4b  push rdi
000074113b7d1c4c  push rsi
000074113b7d1c4d  push r8
000074113b7d1c4f  push r9
000074113b7d1c51  push r10
000074113b7d1c53  push r11
000074113b7d1c55  sub rsp, 0xF0
000074113b7d1c5c  vmovaps [rsp], xmm0
000074113b7d1c61  vmovaps [rsp+0x10], xmm1
000074113b7d1c67  vmovaps [rsp+0x20], xmm2
000074113b7d1c6d  vmovaps [rsp+0x30], xmm3
000074113b7d1c73  vmovaps [rsp+0x40], xmm4
000074113b7d1c79  vmovaps [rsp+0x50], xmm5
000074113b7d1c7f  vmovaps [rsp+0x60], xmm6
000074113b7d1c85  vmovaps [rsp+0x70], xmm7
000074113b7d1c8b  vmovaps [rsp+0x80], xmm8
000074113b7d1c94  vmovaps [rsp+0x90], xmm9
000074113b7d1c9d  vmovaps [rsp+0xA0], xmm10
000074113b7d1ca6  vmovaps [rsp+0xB0], xmm11
000074113b7d1caf  vmovaps [rsp+0xC0], xmm12
000074113b7d1cb8  vmovaps [rsp+0xD0], xmm14
000074113b7d1cc1  vmovaps [rsp+0xE0], xmm15
000074113b7d1cca  sub rsp, 0x40
000074113b7d1cce  lea rdi, [rsp]
000074113b7d1cd2  lea rsi, [rsp+0x10]
000074113b7d1cd7  lea rdx, [rsp+0x20]
000074113b7d1cdc  lea rcx, [rsp+0x30]
000074113b7d1ce1  mov r8d, 0x00
000074113b7d1ce7  lea r9, [r15+0x3A8]
000074113b7d1cee  movaps [rdi], xmm13
000074113b7d1cf2  movaps [rsi], xmm11
000074113b7d1cf6  movaps [rdx], xmm12
000074113b7d1cfa  movaps [rcx], xmm14
000074113b7d1cfe  mov rax, 0x629073062A50
000074113b7d1d08  call rax
000074113b7d1d0a  movaps xmm13, [rsp]
000074113b7d1d0f  add rsp, 0x40
000074113b7d1d13  vmovaps xmm0, [rsp]
000074113b7d1d18  vmovaps xmm1, [rsp+0x10]
000074113b7d1d1e  vmovaps xmm2, [rsp+0x20]
000074113b7d1d24  vmovaps xmm3, [rsp+0x30]
000074113b7d1d2a  vmovaps xmm4, [rsp+0x40]
000074113b7d1d30  vmovaps xmm5, [rsp+0x50]
000074113b7d1d36  vmovaps xmm6, [rsp+0x60]
000074113b7d1d3c  vmovaps xmm7, [rsp+0x70]
000074113b7d1d42  vmovaps xmm8, [rsp+0x80]
000074113b7d1d4b  vmovaps xmm9, [rsp+0x90]
000074113b7d1d54  vmovaps xmm10, [rsp+0xA0]
000074113b7d1d5d  vmovaps xmm11, [rsp+0xB0]
000074113b7d1d66  vmovaps xmm12, [rsp+0xC0]
000074113b7d1d6f  vmovaps xmm14, [rsp+0xD0]
000074113b7d1d78  vmovaps xmm15, [rsp+0xE0]
000074113b7d1d81  add rsp, 0xF0
000074113b7d1d88  pop r11
000074113b7d1d8a  pop r10
000074113b7d1d8c  pop r9
000074113b7d1d8e  pop r8
000074113b7d1d90  pop rsi
000074113b7d1d91  pop rdi
000074113b7d1d92  pop rdx
000074113b7d1d93  pop rcx
000074113b7d1d94  pop rax
000074113b7d1d95  add rsp, 0x08
000074113b7d1d99  jmp 0x000074113B7CFD00
000074113b7d1d9e  call 0x000074113B60D4E0
000074113b7d1da3  jmp 0x000074113B7CFD0A
000074113b7d1da8  call 0x000074113B60AFE0
000074113b7d1dad  jmp 0x000074113B7CFD14
000074113b7d1db2  sub rsp, 0x08
000074113b7d1db6  push rax
000074113b7d1db7  push rcx
000074113b7d1db8  push rdx
000074113b7d1db9  push rdi
000074113b7d1dba  push rsi
000074113b7d1dbb  push r8
000074113b7d1dbd  push r9
000074113b7d1dbf  push r10
000074113b7d1dc1  push r11
000074113b7d1dc3  sub rsp, 0xF0
000074113b7d1dca  vmovaps [rsp], xmm0
000074113b7d1dcf  vmovaps [rsp+0x10], xmm1
000074113b7d1dd5  vmovaps [rsp+0x20], xmm2
000074113b7d1ddb  vmovaps [rsp+0x30], xmm3
000074113b7d1de1  vmovaps [rsp+0x40], xmm4
000074113b7d1de7  vmovaps [rsp+0x50], xmm5
000074113b7d1ded  vmovaps [rsp+0x60], xmm6
000074113b7d1df3  vmovaps [rsp+0x70], xmm8
000074113b7d1df9  vmovaps [rsp+0x80], xmm9
000074113b7d1e02  vmovaps [rsp+0x90], xmm10
000074113b7d1e0b  vmovaps [rsp+0xA0], xmm11
000074113b7d1e14  vmovaps [rsp+0xB0], xmm12
000074113b7d1e1d  vmovaps [rsp+0xC0], xmm13
000074113b7d1e26  vmovaps [rsp+0xD0], xmm14
000074113b7d1e2f  vmovaps [rsp+0xE0], xmm15
000074113b7d1e38  sub rsp, 0x40
000074113b7d1e3c  lea rdi, [rsp]
000074113b7d1e40  lea rsi, [rsp+0x10]
000074113b7d1e45  lea rdx, [rsp+0x20]
000074113b7d1e4a  lea rcx, [rsp+0x30]
000074113b7d1e4f  mov r8d, 0x00
000074113b7d1e55  lea r9, [r15+0x3A8]
000074113b7d1e5c  movaps [rdi], xmm7
000074113b7d1e5f  movaps [rsi], xmm4
000074113b7d1e62  movaps [rdx], xmm9
000074113b7d1e66  movaps [rcx], xmm11
000074113b7d1e6a  mov rax, 0x629073062A50
000074113b7d1e74  call rax
000074113b7d1e76  movaps xmm7, [rsp]
000074113b7d1e7a  add rsp, 0x40
000074113b7d1e7e  vmovaps xmm0, [rsp]
000074113b7d1e83  vmovaps xmm1, [rsp+0x10]
000074113b7d1e89  vmovaps xmm2, [rsp+0x20]
000074113b7d1e8f  vmovaps xmm3, [rsp+0x30]
000074113b7d1e95  vmovaps xmm4, [rsp+0x40]
000074113b7d1e9b  vmovaps xmm5, [rsp+0x50]
000074113b7d1ea1  vmovaps xmm6, [rsp+0x60]
000074113b7d1ea7  vmovaps xmm8, [rsp+0x70]
000074113b7d1ead  vmovaps xmm9, [rsp+0x80]
000074113b7d1eb6  vmovaps xmm10, [rsp+0x90]
000074113b7d1ebf  vmovaps xmm11, [rsp+0xA0]
000074113b7d1ec8  vmovaps xmm12, [rsp+0xB0]
000074113b7d1ed1  vmovaps xmm13, [rsp+0xC0]
000074113b7d1eda  vmovaps xmm14, [rsp+0xD0]
000074113b7d1ee3  vmovaps xmm15, [rsp+0xE0]
000074113b7d1eec  add rsp, 0xF0
000074113b7d1ef3  pop r11
000074113b7d1ef5  pop r10
000074113b7d1ef7  pop r9
000074113b7d1ef9  pop r8
000074113b7d1efb  pop rsi
000074113b7d1efc  pop rdi
000074113b7d1efd  pop rdx
000074113b7d1efe  pop rcx
000074113b7d1eff  pop rax
000074113b7d1f00  add rsp, 0x08
000074113b7d1f04  jmp 0x000074113B7CFD4B
000074113b7d1f09  sub rsp, 0x08
000074113b7d1f0d  push rax
000074113b7d1f0e  push rcx
000074113b7d1f0f  push rdx
000074113b7d1f10  push rdi
000074113b7d1f11  push rsi
000074113b7d1f12  push r8
000074113b7d1f14  push r9
000074113b7d1f16  push r10
000074113b7d1f18  push r11
000074113b7d1f1a  sub rsp, 0xF0
000074113b7d1f21  vmovaps [rsp], xmm0
000074113b7d1f26  vmovaps [rsp+0x10], xmm1
000074113b7d1f2c  vmovaps [rsp+0x20], xmm2
000074113b7d1f32  vmovaps [rsp+0x30], xmm3
000074113b7d1f38  vmovaps [rsp+0x40], xmm4
000074113b7d1f3e  vmovaps [rsp+0x50], xmm5
000074113b7d1f44  vmovaps [rsp+0x60], xmm6
000074113b7d1f4a  vmovaps [rsp+0x70], xmm7
000074113b7d1f50  vmovaps [rsp+0x80], xmm8
000074113b7d1f59  vmovaps [rsp+0x90], xmm10
000074113b7d1f62  vmovaps [rsp+0xA0], xmm11
000074113b7d1f6b  vmovaps [rsp+0xB0], xmm12
000074113b7d1f74  vmovaps [rsp+0xC0], xmm13
000074113b7d1f7d  vmovaps [rsp+0xD0], xmm14
000074113b7d1f86  vmovaps [rsp+0xE0], xmm15
000074113b7d1f8f  sub rsp, 0x40
000074113b7d1f93  lea rdi, [rsp]
000074113b7d1f97  lea rsi, [rsp+0x10]
000074113b7d1f9c  lea rdx, [rsp+0x20]
000074113b7d1fa1  lea rcx, [rsp+0x30]
000074113b7d1fa6  mov r8d, 0x00
000074113b7d1fac  lea r9, [r15+0x3A8]
000074113b7d1fb3  movaps [rdi], xmm9
000074113b7d1fb7  movaps [rsi], xmm5
000074113b7d1fba  movaps [rdx], xmm14
000074113b7d1fbe  movaps [rcx], xmm11
000074113b7d1fc2  mov rax, 0x629073062A50
000074113b7d1fcc  call rax
000074113b7d1fce  movaps xmm9, [rsp]
000074113b7d1fd3  add rsp, 0x40
000074113b7d1fd7  vmovaps xmm0, [rsp]
000074113b7d1fdc  vmovaps xmm1, [rsp+0x10]
000074113b7d1fe2  vmovaps xmm2, [rsp+0x20]
000074113b7d1fe8  vmovaps xmm3, [rsp+0x30]
000074113b7d1fee  vmovaps xmm4, [rsp+0x40]
000074113b7d1ff4  vmovaps xmm5, [rsp+0x50]
000074113b7d1ffa  vmovaps xmm6, [rsp+0x60]
000074113b7d2000  vmovaps xmm7, [rsp+0x70]
000074113b7d2006  vmovaps xmm8, [rsp+0x80]
000074113b7d200f  vmovaps xmm10, [rsp+0x90]
000074113b7d2018  vmovaps xmm11, [rsp+0xA0]
000074113b7d2021  vmovaps xmm12, [rsp+0xB0]
000074113b7d202a  vmovaps xmm13, [rsp+0xC0]
000074113b7d2033  vmovaps xmm14, [rsp+0xD0]
000074113b7d203c  vmovaps xmm15, [rsp+0xE0]
000074113b7d2045  add rsp, 0xF0
000074113b7d204c  pop r11
000074113b7d204e  pop r10
000074113b7d2050  pop r9
000074113b7d2052  pop r8
000074113b7d2054  pop rsi
000074113b7d2055  pop rdi
000074113b7d2056  pop rdx
000074113b7d2057  pop rcx
000074113b7d2058  pop rax
000074113b7d2059  add rsp, 0x08
000074113b7d205d  jmp 0x000074113B7CFD74
000074113b7d2062  sub rsp, 0x08
000074113b7d2066  push rax
000074113b7d2067  push rcx
000074113b7d2068  push rdx
000074113b7d2069  push rdi
000074113b7d206a  push rsi
000074113b7d206b  push r8
000074113b7d206d  push r9
000074113b7d206f  push r10
000074113b7d2071  push r11
000074113b7d2073  sub rsp, 0xF0
000074113b7d207a  vmovaps [rsp], xmm0
000074113b7d207f  vmovaps [rsp+0x10], xmm1
000074113b7d2085  vmovaps [rsp+0x20], xmm2
000074113b7d208b  vmovaps [rsp+0x30], xmm3
000074113b7d2091  vmovaps [rsp+0x40], xmm4
000074113b7d2097  vmovaps [rsp+0x50], xmm5
000074113b7d209d  vmovaps [rsp+0x60], xmm6
000074113b7d20a3  vmovaps [rsp+0x70], xmm7
000074113b7d20a9  vmovaps [rsp+0x80], xmm8
000074113b7d20b2  vmovaps [rsp+0x90], xmm9
000074113b7d20bb  vmovaps [rsp+0xA0], xmm10
000074113b7d20c4  vmovaps [rsp+0xB0], xmm12
000074113b7d20cd  vmovaps [rsp+0xC0], xmm13
000074113b7d20d6  vmovaps [rsp+0xD0], xmm14
000074113b7d20df  vmovaps [rsp+0xE0], xmm15
000074113b7d20e8  sub rsp, 0x40
000074113b7d20ec  lea rdi, [rsp]
000074113b7d20f0  lea rsi, [rsp+0x10]
000074113b7d20f5  lea rdx, [rsp+0x20]
000074113b7d20fa  lea rcx, [rsp+0x30]
000074113b7d20ff  mov r8d, 0x00
000074113b7d2105  lea r9, [r15+0x3A8]
000074113b7d210c  movaps [rdi], xmm11
000074113b7d2110  movaps [rsi], xmm8
000074113b7d2114  movaps [rdx], xmm10
000074113b7d2118  movaps [rcx], xmm14
000074113b7d211c  mov rax, 0x629073062A50
000074113b7d2126  call rax
000074113b7d2128  movaps xmm11, [rsp]
000074113b7d212d  add rsp, 0x40
000074113b7d2131  vmovaps xmm0, [rsp]
000074113b7d2136  vmovaps xmm1, [rsp+0x10]
000074113b7d213c  vmovaps xmm2, [rsp+0x20]
000074113b7d2142  vmovaps xmm3, [rsp+0x30]
000074113b7d2148  vmovaps xmm4, [rsp+0x40]
000074113b7d214e  vmovaps xmm5, [rsp+0x50]
000074113b7d2154  vmovaps xmm6, [rsp+0x60]
000074113b7d215a  vmovaps xmm7, [rsp+0x70]
000074113b7d2160  vmovaps xmm8, [rsp+0x80]
000074113b7d2169  vmovaps xmm9, [rsp+0x90]
000074113b7d2172  vmovaps xmm10, [rsp+0xA0]
000074113b7d217b  vmovaps xmm12, [rsp+0xB0]
000074113b7d2184  vmovaps xmm13, [rsp+0xC0]
000074113b7d218d  vmovaps xmm14, [rsp+0xD0]
000074113b7d2196  vmovaps xmm15, [rsp+0xE0]
000074113b7d219f  add rsp, 0xF0
000074113b7d21a6  pop r11
000074113b7d21a8  pop r10
000074113b7d21aa  pop r9
000074113b7d21ac  pop r8
000074113b7d21ae  pop rsi
000074113b7d21af  pop rdi
000074113b7d21b0  pop rdx
000074113b7d21b1  pop rcx
000074113b7d21b2  pop rax
000074113b7d21b3  add rsp, 0x08
000074113b7d21b7  jmp 0x000074113B7CFD9D
000074113b7d21bc  sub rsp, 0x08
000074113b7d21c0  push rax
000074113b7d21c1  push rcx
000074113b7d21c2  push rdx
000074113b7d21c3  push rdi
000074113b7d21c4  push rsi
000074113b7d21c5  push r8
000074113b7d21c7  push r9
000074113b7d21c9  push r10
000074113b7d21cb  push r11
000074113b7d21cd  sub rsp, 0xF0
000074113b7d21d4  vmovaps [rsp], xmm0
000074113b7d21d9  vmovaps [rsp+0x10], xmm1
000074113b7d21df  vmovaps [rsp+0x20], xmm2
000074113b7d21e5  vmovaps [rsp+0x30], xmm3
000074113b7d21eb  vmovaps [rsp+0x40], xmm4
000074113b7d21f1  vmovaps [rsp+0x50], xmm5
000074113b7d21f7  vmovaps [rsp+0x60], xmm6
000074113b7d21fd  vmovaps [rsp+0x70], xmm7
000074113b7d2203  vmovaps [rsp+0x80], xmm8
000074113b7d220c  vmovaps [rsp+0x90], xmm9
000074113b7d2215  vmovaps [rsp+0xA0], xmm11
000074113b7d221e  vmovaps [rsp+0xB0], xmm12
000074113b7d2227  vmovaps [rsp+0xC0], xmm13
000074113b7d2230  vmovaps [rsp+0xD0], xmm14
000074113b7d2239  vmovaps [rsp+0xE0], xmm15
000074113b7d2242  sub rsp, 0x40
000074113b7d2246  lea rdi, [rsp]
000074113b7d224a  lea rsi, [rsp+0x10]
000074113b7d224f  lea rdx, [rsp+0x20]
000074113b7d2254  lea rcx, [rsp+0x30]
000074113b7d2259  mov r8d, 0x00
000074113b7d225f  lea r9, [r15+0x3A8]
000074113b7d2266  movaps [rdi], xmm10
000074113b7d226a  movaps [rsi], xmm13
000074113b7d226e  movaps [rdx], xmm15
000074113b7d2272  movaps [rcx], xmm14
000074113b7d2276  mov rax, 0x629073062A50
000074113b7d2280  call rax
000074113b7d2282  movaps xmm10, [rsp]
000074113b7d2287  add rsp, 0x40
000074113b7d228b  vmovaps xmm0, [rsp]
000074113b7d2290  vmovaps xmm1, [rsp+0x10]
000074113b7d2296  vmovaps xmm2, [rsp+0x20]
000074113b7d229c  vmovaps xmm3, [rsp+0x30]
000074113b7d22a2  vmovaps xmm4, [rsp+0x40]
000074113b7d22a8  vmovaps xmm5, [rsp+0x50]
000074113b7d22ae  vmovaps xmm6, [rsp+0x60]
000074113b7d22b4  vmovaps xmm7, [rsp+0x70]
000074113b7d22ba  vmovaps xmm8, [rsp+0x80]
000074113b7d22c3  vmovaps xmm9, [rsp+0x90]
000074113b7d22cc  vmovaps xmm11, [rsp+0xA0]
000074113b7d22d5  vmovaps xmm12, [rsp+0xB0]
000074113b7d22de  vmovaps xmm13, [rsp+0xC0]
000074113b7d22e7  vmovaps xmm14, [rsp+0xD0]
000074113b7d22f0  vmovaps xmm15, [rsp+0xE0]
000074113b7d22f9  add rsp, 0xF0
000074113b7d2300  pop r11
000074113b7d2302  pop r10
000074113b7d2304  pop r9
000074113b7d2306  pop r8
000074113b7d2308  pop rsi
000074113b7d2309  pop rdi
000074113b7d230a  pop rdx
000074113b7d230b  pop rcx
000074113b7d230c  pop rax
000074113b7d230d  add rsp, 0x08
000074113b7d2311  jmp 0x000074113B7CFDC6
000074113b7d2316  call 0x000074113B60E760
000074113b7d231b  jmp 0x000074113B7CFDD0
000074113b7d2320  call 0x000074113B60D4E0
000074113b7d2325  jmp 0x000074113B7CFDDA
000074113b7d232a  sub rsp, 0x08
000074113b7d232e  push rax
000074113b7d232f  push rcx
000074113b7d2330  push rdx
000074113b7d2331  push rdi
000074113b7d2332  push rsi
000074113b7d2333  push r8
000074113b7d2335  push r9
000074113b7d2337  push r10
000074113b7d2339  push r11
000074113b7d233b  sub rsp, 0xF0
000074113b7d2342  vmovaps [rsp], xmm0
000074113b7d2347  vmovaps [rsp+0x10], xmm1
000074113b7d234d  vmovaps [rsp+0x20], xmm2
000074113b7d2353  vmovaps [rsp+0x30], xmm3
000074113b7d2359  vmovaps [rsp+0x40], xmm4
000074113b7d235f  vmovaps [rsp+0x50], xmm5
000074113b7d2365  vmovaps [rsp+0x60], xmm7
000074113b7d236b  vmovaps [rsp+0x70], xmm8
000074113b7d2371  vmovaps [rsp+0x80], xmm9
000074113b7d237a  vmovaps [rsp+0x90], xmm10
000074113b7d2383  vmovaps [rsp+0xA0], xmm11
000074113b7d238c  vmovaps [rsp+0xB0], xmm12
000074113b7d2395  vmovaps [rsp+0xC0], xmm13
000074113b7d239e  vmovaps [rsp+0xD0], xmm14
000074113b7d23a7  vmovaps [rsp+0xE0], xmm15
000074113b7d23b0  sub rsp, 0x40
000074113b7d23b4  lea rdi, [rsp]
000074113b7d23b8  lea rsi, [rsp+0x10]
000074113b7d23bd  lea rdx, [rsp+0x20]
000074113b7d23c2  lea rcx, [rsp+0x30]
000074113b7d23c7  mov r8d, 0x00
000074113b7d23cd  lea r9, [r15+0x3A8]
000074113b7d23d4  movaps [rdi], xmm6
000074113b7d23d7  movaps [rsi], xmm7
000074113b7d23da  movaps [rdx], xmm8
000074113b7d23de  movaps [rcx], xmm13
000074113b7d23e2  mov rax, 0x629073062A50
000074113b7d23ec  call rax
000074113b7d23ee  movaps xmm6, [rsp]
000074113b7d23f2  add rsp, 0x40
000074113b7d23f6  vmovaps xmm0, [rsp]
000074113b7d23fb  vmovaps xmm1, [rsp+0x10]
000074113b7d2401  vmovaps xmm2, [rsp+0x20]
000074113b7d2407  vmovaps xmm3, [rsp+0x30]
000074113b7d240d  vmovaps xmm4, [rsp+0x40]
000074113b7d2413  vmovaps xmm5, [rsp+0x50]
000074113b7d2419  vmovaps xmm7, [rsp+0x60]
000074113b7d241f  vmovaps xmm8, [rsp+0x70]
000074113b7d2425  vmovaps xmm9, [rsp+0x80]
000074113b7d242e  vmovaps xmm10, [rsp+0x90]
000074113b7d2437  vmovaps xmm11, [rsp+0xA0]
000074113b7d2440  vmovaps xmm12, [rsp+0xB0]
000074113b7d2449  vmovaps xmm13, [rsp+0xC0]
000074113b7d2452  vmovaps xmm14, [rsp+0xD0]
000074113b7d245b  vmovaps xmm15, [rsp+0xE0]
000074113b7d2464  add rsp, 0xF0
000074113b7d246b  pop r11
000074113b7d246d  pop r10
000074113b7d246f  pop r9
000074113b7d2471  pop r8
000074113b7d2473  pop rsi
000074113b7d2474  pop rdi
000074113b7d2475  pop rdx
000074113b7d2476  pop rcx
000074113b7d2477  pop rax
000074113b7d2478  add rsp, 0x08
000074113b7d247c  jmp 0x000074113B7CFE04
000074113b7d2481  sub rsp, 0x08
000074113b7d2485  push rax
000074113b7d2486  push rcx
000074113b7d2487  push rdx
000074113b7d2488  push rdi
000074113b7d2489  push rsi
000074113b7d248a  push r8
000074113b7d248c  push r9
000074113b7d248e  push r10
000074113b7d2490  push r11
000074113b7d2492  sub rsp, 0xF0
000074113b7d2499  vmovaps [rsp], xmm0
000074113b7d249e  vmovaps [rsp+0x10], xmm1
000074113b7d24a4  vmovaps [rsp+0x20], xmm2
000074113b7d24aa  vmovaps [rsp+0x30], xmm3
000074113b7d24b0  vmovaps [rsp+0x40], xmm4
000074113b7d24b6  vmovaps [rsp+0x50], xmm5
000074113b7d24bc  vmovaps [rsp+0x60], xmm6
000074113b7d24c2  vmovaps [rsp+0x70], xmm7
000074113b7d24c8  vmovaps [rsp+0x80], xmm9
000074113b7d24d1  vmovaps [rsp+0x90], xmm10
000074113b7d24da  vmovaps [rsp+0xA0], xmm11
000074113b7d24e3  vmovaps [rsp+0xB0], xmm12
000074113b7d24ec  vmovaps [rsp+0xC0], xmm13
000074113b7d24f5  vmovaps [rsp+0xD0], xmm14
000074113b7d24fe  vmovaps [rsp+0xE0], xmm15
000074113b7d2507  sub rsp, 0x40
000074113b7d250b  lea rdi, [rsp]
000074113b7d250f  lea rsi, [rsp+0x10]
000074113b7d2514  lea rdx, [rsp+0x20]
000074113b7d2519  lea rcx, [rsp+0x30]
000074113b7d251e  mov r8d, 0x00
000074113b7d2524  lea r9, [r15+0x3A8]
000074113b7d252b  movaps [rdi], xmm8
000074113b7d252f  movaps [rsi], xmm9
000074113b7d2533  movaps [rdx], xmm1
000074113b7d2536  movaps [rcx], xmm13
000074113b7d253a  mov rax, 0x629073062A50
000074113b7d2544  call rax
000074113b7d2546  movaps xmm8, [rsp]
000074113b7d254b  add rsp, 0x40
000074113b7d254f  vmovaps xmm0, [rsp]
000074113b7d2554  vmovaps xmm1, [rsp+0x10]
000074113b7d255a  vmovaps xmm2, [rsp+0x20]
000074113b7d2560  vmovaps xmm3, [rsp+0x30]
000074113b7d2566  vmovaps xmm4, [rsp+0x40]
000074113b7d256c  vmovaps xmm5, [rsp+0x50]
000074113b7d2572  vmovaps xmm6, [rsp+0x60]
000074113b7d2578  vmovaps xmm7, [rsp+0x70]
000074113b7d257e  vmovaps xmm9, [rsp+0x80]
000074113b7d2587  vmovaps xmm10, [rsp+0x90]
000074113b7d2590  vmovaps xmm11, [rsp+0xA0]
000074113b7d2599  vmovaps xmm12, [rsp+0xB0]
000074113b7d25a2  vmovaps xmm13, [rsp+0xC0]
000074113b7d25ab  vmovaps xmm14, [rsp+0xD0]
000074113b7d25b4  vmovaps xmm15, [rsp+0xE0]
000074113b7d25bd  add rsp, 0xF0
000074113b7d25c4  pop r11
000074113b7d25c6  pop r10
000074113b7d25c8  pop r9
000074113b7d25ca  pop r8
000074113b7d25cc  pop rsi
000074113b7d25cd  pop rdi
000074113b7d25ce  pop rdx
000074113b7d25cf  pop rcx
000074113b7d25d0  pop rax
000074113b7d25d1  add rsp, 0x08
000074113b7d25d5  jmp 0x000074113B7CFE2A
000074113b7d25da  sub rsp, 0x08
000074113b7d25de  push rax
000074113b7d25df  push rcx
000074113b7d25e0  push rdx
000074113b7d25e1  push rdi
000074113b7d25e2  push rsi
000074113b7d25e3  push r8
000074113b7d25e5  push r9
000074113b7d25e7  push r10
000074113b7d25e9  push r11
000074113b7d25eb  sub rsp, 0xF0
000074113b7d25f2  vmovaps [rsp], xmm0
000074113b7d25f7  vmovaps [rsp+0x10], xmm1
000074113b7d25fd  vmovaps [rsp+0x20], xmm2
000074113b7d2603  vmovaps [rsp+0x30], xmm3
000074113b7d2609  vmovaps [rsp+0x40], xmm4
000074113b7d260f  vmovaps [rsp+0x50], xmm5
000074113b7d2615  vmovaps [rsp+0x60], xmm6
000074113b7d261b  vmovaps [rsp+0x70], xmm7
000074113b7d2621  vmovaps [rsp+0x80], xmm8
000074113b7d262a  vmovaps [rsp+0x90], xmm9
000074113b7d2633  vmovaps [rsp+0xA0], xmm10
000074113b7d263c  vmovaps [rsp+0xB0], xmm11
000074113b7d2645  vmovaps [rsp+0xC0], xmm12
000074113b7d264e  vmovaps [rsp+0xD0], xmm14
000074113b7d2657  vmovaps [rsp+0xE0], xmm15
000074113b7d2660  sub rsp, 0x40
000074113b7d2664  lea rdi, [rsp]
000074113b7d2668  lea rsi, [rsp+0x10]
000074113b7d266d  lea rdx, [rsp+0x20]
000074113b7d2672  lea rcx, [rsp+0x30]
000074113b7d2677  mov r8d, 0x00
000074113b7d267d  lea r9, [r15+0x3A8]
000074113b7d2684  movaps [rdi], xmm13
000074113b7d2688  movaps [rsi], xmm11
000074113b7d268c  movaps [rdx], xmm12
000074113b7d2690  movaps [rcx], xmm1
000074113b7d2693  mov rax, 0x629073062A50
000074113b7d269d  call rax
000074113b7d269f  movaps xmm13, [rsp]
000074113b7d26a4  add rsp, 0x40
000074113b7d26a8  vmovaps xmm0, [rsp]
000074113b7d26ad  vmovaps xmm1, [rsp+0x10]
000074113b7d26b3  vmovaps xmm2, [rsp+0x20]
000074113b7d26b9  vmovaps xmm3, [rsp+0x30]
000074113b7d26bf  vmovaps xmm4, [rsp+0x40]
000074113b7d26c5  vmovaps xmm5, [rsp+0x50]
000074113b7d26cb  vmovaps xmm6, [rsp+0x60]
000074113b7d26d1  vmovaps xmm7, [rsp+0x70]
000074113b7d26d7  vmovaps xmm8, [rsp+0x80]
000074113b7d26e0  vmovaps xmm9, [rsp+0x90]
000074113b7d26e9  vmovaps xmm10, [rsp+0xA0]
000074113b7d26f2  vmovaps xmm11, [rsp+0xB0]
000074113b7d26fb  vmovaps xmm12, [rsp+0xC0]
000074113b7d2704  vmovaps xmm14, [rsp+0xD0]
000074113b7d270d  vmovaps xmm15, [rsp+0xE0]
000074113b7d2716  add rsp, 0xF0
000074113b7d271d  pop r11
000074113b7d271f  pop r10
000074113b7d2721  pop r9
000074113b7d2723  pop r8
000074113b7d2725  pop rsi
000074113b7d2726  pop rdi
000074113b7d2727  pop rdx
000074113b7d2728  pop rcx
000074113b7d2729  pop rax
000074113b7d272a  add rsp, 0x08
000074113b7d272e  jmp 0x000074113B7CFE50
000074113b7d2733  sub rsp, 0x08
000074113b7d2737  push rax
000074113b7d2738  push rcx
000074113b7d2739  push rdx
000074113b7d273a  push rdi
000074113b7d273b  push rsi
000074113b7d273c  push r8
000074113b7d273e  push r9
000074113b7d2740  push r10
000074113b7d2742  push r11
000074113b7d2744  sub rsp, 0xF0
000074113b7d274b  vmovaps [rsp], xmm0
000074113b7d2750  vmovaps [rsp+0x10], xmm1
000074113b7d2756  vmovaps [rsp+0x20], xmm2
000074113b7d275c  vmovaps [rsp+0x30], xmm3
000074113b7d2762  vmovaps [rsp+0x40], xmm4
000074113b7d2768  vmovaps [rsp+0x50], xmm5
000074113b7d276e  vmovaps [rsp+0x60], xmm6
000074113b7d2774  vmovaps [rsp+0x70], xmm7
000074113b7d277a  vmovaps [rsp+0x80], xmm8
000074113b7d2783  vmovaps [rsp+0x90], xmm9
000074113b7d278c  vmovaps [rsp+0xA0], xmm10
000074113b7d2795  vmovaps [rsp+0xB0], xmm11
000074113b7d279e  vmovaps [rsp+0xC0], xmm13
000074113b7d27a7  vmovaps [rsp+0xD0], xmm14
000074113b7d27b0  vmovaps [rsp+0xE0], xmm15
000074113b7d27b9  sub rsp, 0x40
000074113b7d27bd  lea rdi, [rsp]
000074113b7d27c1  lea rsi, [rsp+0x10]
000074113b7d27c6  lea rdx, [rsp+0x20]
000074113b7d27cb  lea rcx, [rsp+0x30]
000074113b7d27d0  mov r8d, 0x00
000074113b7d27d6  lea r9, [r15+0x3A8]
000074113b7d27dd  movaps [rdi], xmm12
000074113b7d27e1  movaps [rsi], xmm10
000074113b7d27e5  movaps [rdx], xmm14
000074113b7d27e9  movaps [rcx], xmm1
000074113b7d27ec  mov rax, 0x629073062A50
000074113b7d27f6  call rax
000074113b7d27f8  movaps xmm12, [rsp]
000074113b7d27fd  add rsp, 0x40
000074113b7d2801  vmovaps xmm0, [rsp]
000074113b7d2806  vmovaps xmm1, [rsp+0x10]
000074113b7d280c  vmovaps xmm2, [rsp+0x20]
000074113b7d2812  vmovaps xmm3, [rsp+0x30]
000074113b7d2818  vmovaps xmm4, [rsp+0x40]
000074113b7d281e  vmovaps xmm5, [rsp+0x50]
000074113b7d2824  vmovaps xmm6, [rsp+0x60]
000074113b7d282a  vmovaps xmm7, [rsp+0x70]
000074113b7d2830  vmovaps xmm8, [rsp+0x80]
000074113b7d2839  vmovaps xmm9, [rsp+0x90]
000074113b7d2842  vmovaps xmm10, [rsp+0xA0]
000074113b7d284b  vmovaps xmm11, [rsp+0xB0]
000074113b7d2854  vmovaps xmm13, [rsp+0xC0]
000074113b7d285d  vmovaps xmm14, [rsp+0xD0]
000074113b7d2866  vmovaps xmm15, [rsp+0xE0]
000074113b7d286f  add rsp, 0xF0
000074113b7d2876  pop r11
000074113b7d2878  pop r10
000074113b7d287a  pop r9
000074113b7d287c  pop r8
000074113b7d287e  pop rsi
000074113b7d287f  pop rdi
000074113b7d2880  pop rdx
000074113b7d2881  pop rcx
000074113b7d2882  pop rax
000074113b7d2883  add rsp, 0x08
000074113b7d2887  jmp 0x000074113B7CFE76
000074113b7d288c  call 0x000074113B5FF430
000074113b7d2891  jmp 0x000074113B7CFE83
000074113b7d2896  call 0x000074113B60D4E0
000074113b7d289b  jmp 0x000074113B7CFE90
000074113b7d28a0  sub rsp, 0x08
000074113b7d28a4  push rax
000074113b7d28a5  push rcx
000074113b7d28a6  push rdx
000074113b7d28a7  push rdi
000074113b7d28a8  push rsi
000074113b7d28a9  push r8
000074113b7d28ab  push r9
000074113b7d28ad  push r10
000074113b7d28af  push r11
000074113b7d28b1  sub rsp, 0xF0
000074113b7d28b8  vmovaps [rsp], xmm0
000074113b7d28bd  vmovaps [rsp+0x10], xmm1
000074113b7d28c3  vmovaps [rsp+0x20], xmm2
000074113b7d28c9  vmovaps [rsp+0x30], xmm3
000074113b7d28cf  vmovaps [rsp+0x40], xmm4
000074113b7d28d5  vmovaps [rsp+0x50], xmm5
000074113b7d28db  vmovaps [rsp+0x60], xmm6
000074113b7d28e1  vmovaps [rsp+0x70], xmm7
000074113b7d28e7  vmovaps [rsp+0x80], xmm8
000074113b7d28f0  vmovaps [rsp+0x90], xmm9
000074113b7d28f9  vmovaps [rsp+0xA0], xmm11
000074113b7d2902  vmovaps [rsp+0xB0], xmm12
000074113b7d290b  vmovaps [rsp+0xC0], xmm13
000074113b7d2914  vmovaps [rsp+0xD0], xmm14
000074113b7d291d  vmovaps [rsp+0xE0], xmm15
000074113b7d2926  sub rsp, 0x40
000074113b7d292a  lea rdi, [rsp]
000074113b7d292e  lea rsi, [rsp+0x10]
000074113b7d2933  lea rdx, [rsp+0x20]
000074113b7d2938  lea rcx, [rsp+0x30]
000074113b7d293d  mov r8d, 0x00
000074113b7d2943  lea r9, [r15+0x3A8]
000074113b7d294a  movaps [rdi], xmm10
000074113b7d294e  movaps [rsi], xmm6
000074113b7d2951  movaps [rdx], xmm15
000074113b7d2955  movaps [rcx], xmm11
000074113b7d2959  mov rax, 0x629073062A50
000074113b7d2963  call rax
000074113b7d2965  movaps xmm10, [rsp]
000074113b7d296a  add rsp, 0x40
000074113b7d296e  vmovaps xmm0, [rsp]
000074113b7d2973  vmovaps xmm1, [rsp+0x10]
000074113b7d2979  vmovaps xmm2, [rsp+0x20]
000074113b7d297f  vmovaps xmm3, [rsp+0x30]
000074113b7d2985  vmovaps xmm4, [rsp+0x40]
000074113b7d298b  vmovaps xmm5, [rsp+0x50]
000074113b7d2991  vmovaps xmm6, [rsp+0x60]
000074113b7d2997  vmovaps xmm7, [rsp+0x70]
000074113b7d299d  vmovaps xmm8, [rsp+0x80]
000074113b7d29a6  vmovaps xmm9, [rsp+0x90]
000074113b7d29af  vmovaps xmm11, [rsp+0xA0]
000074113b7d29b8  vmovaps xmm12, [rsp+0xB0]
000074113b7d29c1  vmovaps xmm13, [rsp+0xC0]
000074113b7d29ca  vmovaps xmm14, [rsp+0xD0]
000074113b7d29d3  vmovaps xmm15, [rsp+0xE0]
000074113b7d29dc  add rsp, 0xF0
000074113b7d29e3  pop r11
000074113b7d29e5  pop r10
000074113b7d29e7  pop r9
000074113b7d29e9  pop r8
000074113b7d29eb  pop rsi
000074113b7d29ec  pop rdi
000074113b7d29ed  pop rdx
000074113b7d29ee  pop rcx
000074113b7d29ef  pop rax
000074113b7d29f0  add rsp, 0x08
000074113b7d29f4  jmp 0x000074113B7CFEC9
000074113b7d29f9  call 0x000074113B60E760
000074113b7d29fe  jmp 0x000074113B7CFEDB
000074113b7d2a03  sub rsp, 0x08
000074113b7d2a07  push rax
000074113b7d2a08  push rcx
000074113b7d2a09  push rdx
000074113b7d2a0a  push rdi
000074113b7d2a0b  push rsi
000074113b7d2a0c  push r8
000074113b7d2a0e  push r9
000074113b7d2a10  push r10
000074113b7d2a12  push r11
000074113b7d2a14  sub rsp, 0xF0
000074113b7d2a1b  vmovaps [rsp], xmm0
000074113b7d2a20  vmovaps [rsp+0x10], xmm1
000074113b7d2a26  vmovaps [rsp+0x20], xmm2
000074113b7d2a2c  vmovaps [rsp+0x30], xmm3
000074113b7d2a32  vmovaps [rsp+0x40], xmm4
000074113b7d2a38  vmovaps [rsp+0x50], xmm5
000074113b7d2a3e  vmovaps [rsp+0x60], xmm6
000074113b7d2a44  vmovaps [rsp+0x70], xmm7
000074113b7d2a4a  vmovaps [rsp+0x80], xmm8
000074113b7d2a53  vmovaps [rsp+0x90], xmm10
000074113b7d2a5c  vmovaps [rsp+0xA0], xmm11
000074113b7d2a65  vmovaps [rsp+0xB0], xmm12
000074113b7d2a6e  vmovaps [rsp+0xC0], xmm13
000074113b7d2a77  vmovaps [rsp+0xD0], xmm14
000074113b7d2a80  vmovaps [rsp+0xE0], xmm15
000074113b7d2a89  sub rsp, 0x40
000074113b7d2a8d  lea rdi, [rsp]
000074113b7d2a91  lea rsi, [rsp+0x10]
000074113b7d2a96  lea rdx, [rsp+0x20]
000074113b7d2a9b  lea rcx, [rsp+0x30]
000074113b7d2aa0  mov r8d, 0x00
000074113b7d2aa6  lea r9, [r15+0x3A8]
000074113b7d2aad  movaps [rdi], xmm9
000074113b7d2ab1  movaps [rsi], xmm8
000074113b7d2ab5  movaps [rdx], xmm14
000074113b7d2ab9  movaps [rcx], xmm11
000074113b7d2abd  mov rax, 0x629073062A50
000074113b7d2ac7  call rax
000074113b7d2ac9  movaps xmm9, [rsp]
000074113b7d2ace  add rsp, 0x40
000074113b7d2ad2  vmovaps xmm0, [rsp]
000074113b7d2ad7  vmovaps xmm1, [rsp+0x10]
000074113b7d2add  vmovaps xmm2, [rsp+0x20]
000074113b7d2ae3  vmovaps xmm3, [rsp+0x30]
000074113b7d2ae9  vmovaps xmm4, [rsp+0x40]
000074113b7d2aef  vmovaps xmm5, [rsp+0x50]
000074113b7d2af5  vmovaps xmm6, [rsp+0x60]
000074113b7d2afb  vmovaps xmm7, [rsp+0x70]
000074113b7d2b01  vmovaps xmm8, [rsp+0x80]
000074113b7d2b0a  vmovaps xmm10, [rsp+0x90]
000074113b7d2b13  vmovaps xmm11, [rsp+0xA0]
000074113b7d2b1c  vmovaps xmm12, [rsp+0xB0]
000074113b7d2b25  vmovaps xmm13, [rsp+0xC0]
000074113b7d2b2e  vmovaps xmm14, [rsp+0xD0]
000074113b7d2b37  vmovaps xmm15, [rsp+0xE0]
000074113b7d2b40  add rsp, 0xF0
000074113b7d2b47  pop r11
000074113b7d2b49  pop r10
000074113b7d2b4b  pop r9
000074113b7d2b4d  pop r8
000074113b7d2b4f  pop rsi
000074113b7d2b50  pop rdi
000074113b7d2b51  pop rdx
000074113b7d2b52  pop rcx
000074113b7d2b53  pop rax
000074113b7d2b54  add rsp, 0x08
000074113b7d2b58  jmp 0x000074113B7CFF0C
000074113b7d2b5d  sub rsp, 0x08
000074113b7d2b61  push rax
000074113b7d2b62  push rcx
000074113b7d2b63  push rdx
000074113b7d2b64  push rdi
000074113b7d2b65  push rsi
000074113b7d2b66  push r8
000074113b7d2b68  push r9
000074113b7d2b6a  push r10
000074113b7d2b6c  push r11
000074113b7d2b6e  sub rsp, 0xF0
000074113b7d2b75  vmovaps [rsp], xmm0
000074113b7d2b7a  vmovaps [rsp+0x10], xmm1
000074113b7d2b80  vmovaps [rsp+0x20], xmm2
000074113b7d2b86  vmovaps [rsp+0x30], xmm3
000074113b7d2b8c  vmovaps [rsp+0x40], xmm4
000074113b7d2b92  vmovaps [rsp+0x50], xmm5
000074113b7d2b98  vmovaps [rsp+0x60], xmm6
000074113b7d2b9e  vmovaps [rsp+0x70], xmm7
000074113b7d2ba4  vmovaps [rsp+0x80], xmm8
000074113b7d2bad  vmovaps [rsp+0x90], xmm9
000074113b7d2bb6  vmovaps [rsp+0xA0], xmm10
000074113b7d2bbf  vmovaps [rsp+0xB0], xmm12
000074113b7d2bc8  vmovaps [rsp+0xC0], xmm13
000074113b7d2bd1  vmovaps [rsp+0xD0], xmm14
000074113b7d2bda  vmovaps [rsp+0xE0], xmm15
000074113b7d2be3  sub rsp, 0x40
000074113b7d2be7  lea rdi, [rsp]
000074113b7d2beb  lea rsi, [rsp+0x10]
000074113b7d2bf0  lea rdx, [rsp+0x20]
000074113b7d2bf5  lea rcx, [rsp+0x30]
000074113b7d2bfa  mov r8d, 0x00
000074113b7d2c00  lea r9, [r15+0x3A8]
000074113b7d2c07  movaps [rdi], xmm11
000074113b7d2c0b  movaps [rsi], xmm13
000074113b7d2c0f  movaps [rdx], xmm1
000074113b7d2c12  movaps [rcx], xmm14
000074113b7d2c16  mov rax, 0x629073062A50
000074113b7d2c20  call rax
000074113b7d2c22  movaps xmm11, [rsp]
000074113b7d2c27  add rsp, 0x40
000074113b7d2c2b  vmovaps xmm0, [rsp]
000074113b7d2c30  vmovaps xmm1, [rsp+0x10]
000074113b7d2c36  vmovaps xmm2, [rsp+0x20]
000074113b7d2c3c  vmovaps xmm3, [rsp+0x30]
000074113b7d2c42  vmovaps xmm4, [rsp+0x40]
000074113b7d2c48  vmovaps xmm5, [rsp+0x50]
000074113b7d2c4e  vmovaps xmm6, [rsp+0x60]
000074113b7d2c54  vmovaps xmm7, [rsp+0x70]
000074113b7d2c5a  vmovaps xmm8, [rsp+0x80]
000074113b7d2c63  vmovaps xmm9, [rsp+0x90]
000074113b7d2c6c  vmovaps xmm10, [rsp+0xA0]
000074113b7d2c75  vmovaps xmm12, [rsp+0xB0]
000074113b7d2c7e  vmovaps xmm13, [rsp+0xC0]
000074113b7d2c87  vmovaps xmm14, [rsp+0xD0]
000074113b7d2c90  vmovaps xmm15, [rsp+0xE0]
000074113b7d2c99  add rsp, 0xF0
000074113b7d2ca0  pop r11
000074113b7d2ca2  pop r10
000074113b7d2ca4  pop r9
000074113b7d2ca6  pop r8
000074113b7d2ca8  pop rsi
000074113b7d2ca9  pop rdi
000074113b7d2caa  pop rdx
000074113b7d2cab  pop rcx
000074113b7d2cac  pop rax
000074113b7d2cad  add rsp, 0x08
000074113b7d2cb1  jmp 0x000074113B7CFF3D
000074113b7d2cb6  sub rsp, 0x08
000074113b7d2cba  push rax
000074113b7d2cbb  push rcx
000074113b7d2cbc  push rdx
000074113b7d2cbd  push rdi
000074113b7d2cbe  push rsi
000074113b7d2cbf  push r8
000074113b7d2cc1  push r9
000074113b7d2cc3  push r10
000074113b7d2cc5  push r11
000074113b7d2cc7  sub rsp, 0xF0
000074113b7d2cce  vmovaps [rsp], xmm0
000074113b7d2cd3  vmovaps [rsp+0x10], xmm1
000074113b7d2cd9  vmovaps [rsp+0x20], xmm2
000074113b7d2cdf  vmovaps [rsp+0x30], xmm3
000074113b7d2ce5  vmovaps [rsp+0x40], xmm4
000074113b7d2ceb  vmovaps [rsp+0x50], xmm5
000074113b7d2cf1  vmovaps [rsp+0x60], xmm6
000074113b7d2cf7  vmovaps [rsp+0x70], xmm7
000074113b7d2cfd  vmovaps [rsp+0x80], xmm8
000074113b7d2d06  vmovaps [rsp+0x90], xmm9
000074113b7d2d0f  vmovaps [rsp+0xA0], xmm10
000074113b7d2d18  vmovaps [rsp+0xB0], xmm11
000074113b7d2d21  vmovaps [rsp+0xC0], xmm12
000074113b7d2d2a  vmovaps [rsp+0xD0], xmm13
000074113b7d2d33  vmovaps [rsp+0xE0], xmm15
000074113b7d2d3c  sub rsp, 0x40
000074113b7d2d40  lea rdi, [rsp]
000074113b7d2d44  lea rsi, [rsp+0x10]
000074113b7d2d49  lea rdx, [rsp+0x20]
000074113b7d2d4e  lea rcx, [rsp+0x30]
000074113b7d2d53  mov r8d, 0x00
000074113b7d2d59  lea r9, [r15+0x3A8]
000074113b7d2d60  movaps [rdi], xmm14
000074113b7d2d64  movaps [rsi], xmm12
000074113b7d2d68  movaps [rdx], xmm15
000074113b7d2d6c  movaps [rcx], xmm1
000074113b7d2d6f  mov rax, 0x629073062A50
000074113b7d2d79  call rax
000074113b7d2d7b  movaps xmm14, [rsp]
000074113b7d2d80  add rsp, 0x40
000074113b7d2d84  vmovaps xmm0, [rsp]
000074113b7d2d89  vmovaps xmm1, [rsp+0x10]
000074113b7d2d8f  vmovaps xmm2, [rsp+0x20]
000074113b7d2d95  vmovaps xmm3, [rsp+0x30]
000074113b7d2d9b  vmovaps xmm4, [rsp+0x40]
000074113b7d2da1  vmovaps xmm5, [rsp+0x50]
000074113b7d2da7  vmovaps xmm6, [rsp+0x60]
000074113b7d2dad  vmovaps xmm7, [rsp+0x70]
000074113b7d2db3  vmovaps xmm8, [rsp+0x80]
000074113b7d2dbc  vmovaps xmm9, [rsp+0x90]
000074113b7d2dc5  vmovaps xmm10, [rsp+0xA0]
000074113b7d2dce  vmovaps xmm11, [rsp+0xB0]
000074113b7d2dd7  vmovaps xmm12, [rsp+0xC0]
000074113b7d2de0  vmovaps xmm13, [rsp+0xD0]
000074113b7d2de9  vmovaps xmm15, [rsp+0xE0]
000074113b7d2df2  add rsp, 0xF0
000074113b7d2df9  pop r11
000074113b7d2dfb  pop r10
000074113b7d2dfd  pop r9
000074113b7d2dff  pop r8
000074113b7d2e01  pop rsi
000074113b7d2e02  pop rdi
000074113b7d2e03  pop rdx
000074113b7d2e04  pop rcx
000074113b7d2e05  pop rax
000074113b7d2e06  add rsp, 0x08
000074113b7d2e0a  jmp 0x000074113B7CFF6E
000074113b7d2e0f  call 0x000074113B6079B0
000074113b7d2e14  jmp 0x000074113B7CFF81
000074113b7d2e19  call 0x000074113B609E90
000074113b7d2e1e  jmp 0x000074113B7CFF8C
000074113b7d2e23  call 0x000074113B608C20
000074113b7d2e28  jmp 0x000074113B7CFF97
000074113b7d2e2d  call 0x000074113B60D600
000074113b7d2e32  jmp 0x000074113B7CFFA2
000074113b7d2e37  int3
000074113b7d2e38  nop [rax+rax*1], eax
000074113b7d2e40  mov rax, [r15+0x40]
000074113b7d2e44  mov r14, [r15+0x58]
000074113b7d2e48  lea r12, [rax+r14*1]
000074113b7d2e4c  vxorps xmm1, xmm1, xmm1
000074113b7d2e50  vpbroadcastq xmm1, xmm1
000074113b7d2e55  vxorps xmm15, xmm15, xmm15
000074113b7d2e5a  vpbroadcastq xmm15, xmm15
000074113b7d2e5f  lea rax, [r12+0x30]
000074113b7d2e64  mov r11, [r13+rax*1]
000074113b7d2e69  lea rax, [r12+0x38]
000074113b7d2e6e  mov r10, [r13+rax*1]
000074113b7d2e73  movq xmm14, r11
000074113b7d2e78  movq xmm13, r10
000074113b7d2e7d  movq xmm14, xmm14
000074113b7d2e82  movq xmm13, xmm13
000074113b7d2e87  vmovaps [rsp+0x10], xmm13
000074113b7d2e8d  movq xmm13, xmm13
000074113b7d2e92  movaps [r15+0x270], xmm13
000074113b7d2e9a  movaps xmm13, [r15+0x160]
000074113b7d2ea2  vmovaps [rsp+0x20], xmm13
000074113b7d2ea8  vmovaps xmm12, [rsp+0x20]
000074113b7d2eae  por xmm13, xmm12
000074113b7d2eb3  lea rax, [r12+0x20]
000074113b7d2eb8  mov r11, [r13+rax*1]
000074113b7d2ebd  lea rax, [r12+0x28]
000074113b7d2ec2  mov r10, [r13+rax*1]
000074113b7d2ec7  movq xmm12, r11
000074113b7d2ecc  movq xmm11, r10
000074113b7d2ed1  movq xmm12, xmm12
000074113b7d2ed6  movq xmm11, xmm11
000074113b7d2edb  movaps xmm10, [r15+0x2F0]
000074113b7d2ee3  vmovaps [rsp+0x20], xmm10
000074113b7d2ee9  vmovaps xmm9, [rsp+0x20]
000074113b7d2eef  por xmm10, xmm9
000074113b7d2ef4  movaps xmm9, [r15+0x2D0]
000074113b7d2efc  vmovaps [rsp+0x20], xmm9
000074113b7d2f02  vmovaps xmm8, [rsp+0x20]
000074113b7d2f08  por xmm9, xmm8
000074113b7d2f0d  movaps xmm8, [r15+0x300]
000074113b7d2f15  vmovaps [rsp+0x20], xmm8
000074113b7d2f1b  vmovaps xmm7, [rsp+0x20]
000074113b7d2f21  por xmm8, xmm7
000074113b7d2f26  movaps xmm7, [r15+0x2B0]
000074113b7d2f2e  vmovaps [rsp+0x20], xmm7
000074113b7d2f34  vmovaps xmm6, [rsp+0x20]
000074113b7d2f3a  por xmm7, xmm6
000074113b7d2f3e  movaps xmm6, [r15+0x180]
000074113b7d2f46  vmovaps [rsp+0x20], xmm6
000074113b7d2f4c  vmovaps xmm5, [rsp+0x20]
000074113b7d2f52  por xmm6, xmm5
000074113b7d2f56  lea rax, [r12+0x10]
000074113b7d2f5b  mov r11, [r13+rax*1]
000074113b7d2f60  lea rax, [r12+0x18]
000074113b7d2f65  mov r10, [r13+rax*1]
000074113b7d2f6a  movq xmm5, r11
000074113b7d2f6f  movq xmm4, r10
000074113b7d2f74  movq xmm5, xmm5
000074113b7d2f78  movq xmm4, xmm4
000074113b7d2f7c  movaps xmm3, [r15+0x200]
000074113b7d2f84  vmovaps [rsp+0x20], xmm3
000074113b7d2f8a  vmovaps xmm2, [rsp+0x20]
000074113b7d2f90  por xmm3, xmm2
000074113b7d2f94  movaps xmm2, [r15+0x1F0]
000074113b7d2f9c  vmovaps [rsp+0x20], xmm2
000074113b7d2fa2  vmovaps [rsp+0x30], xmm1
000074113b7d2fa8  vmovaps xmm1, [rsp+0x20]
000074113b7d2fae  por xmm2, xmm1
000074113b7d2fb2  movaps xmm1, [r15+0x2E0]
000074113b7d2fba  vmovaps [rsp+0x20], xmm1
000074113b7d2fc0  vmovaps [rsp+0x40], xmm15
000074113b7d2fc6  vmovaps xmm15, [rsp+0x20]
000074113b7d2fcc  por xmm1, xmm15
000074113b7d2fd1  movaps xmm15, [r15+0x2A0]
000074113b7d2fd9  vmovaps [rsp+0x20], xmm15
000074113b7d2fdf  vmovaps [rsp+0x50], xmm1
000074113b7d2fe5  vmovaps xmm1, [rsp+0x20]
000074113b7d2feb  por xmm15, xmm1
000074113b7d2ff0  movaps xmm1, [r15+0x280]
000074113b7d2ff8  vmovaps [rsp+0x20], xmm1
000074113b7d2ffe  vmovaps [rsp+0x60], xmm15
000074113b7d3004  vmovaps xmm15, [rsp+0x20]
000074113b7d300a  por xmm1, xmm15
000074113b7d300f  movaps xmm15, [r15+0x1C0]
000074113b7d3017  vmovaps [rsp+0x20], xmm15
000074113b7d301d  vmovaps [rsp+0x70], xmm1
000074113b7d3023  vmovaps xmm1, [rsp+0x20]
000074113b7d3029  por xmm15, xmm1
000074113b7d302e  movaps xmm1, [r15+0x210]
000074113b7d3036  vmovaps [rsp+0x20], xmm1
000074113b7d303c  vmovaps [rsp+0x80], xmm15
000074113b7d3045  vmovaps xmm15, [rsp+0x20]
000074113b7d304b  por xmm1, xmm15
000074113b7d3050  mov rax, [r13+r12*1]
000074113b7d3055  vmovq xmm15, rax
000074113b7d305a  vpbroadcastq xmm15, xmm15
000074113b7d305f  vmovaps [rsp+0x20], xmm1
000074113b7d3065  vxorps xmm1, xmm1, xmm1
000074113b7d3069  vpbroadcastq xmm1, xmm1
000074113b7d306e  mov rax, [r15+0xF8]
000074113b7d3075  vmovaps [rsp+0x90], xmm1
000074113b7d307e  movups xmm1, [r13+rax*1]
000074113b7d3084  vmovaps [rsp+0xA0], xmm1
000074113b7d308d  vxorps xmm1, xmm1, xmm1
000074113b7d3091  vpbroadcastq xmm1, xmm1
000074113b7d3096  lea r11, [r12+0x08]
000074113b7d309b  mov r12, [r13+r11*1]
000074113b7d30a0  vmovaps [rsp+0xB0], xmm1
000074113b7d30a9  movq xmm1, r12
000074113b7d30ae  movaps [r15+0x240], xmm1
000074113b7d30b6  mov r12, [r15+0x50]
000074113b7d30ba  lea r11, [r12+r14*1]
000074113b7d30be  mov [r15+0x60], r11
000074113b7d30c2  lea r12, [r14+0x40]
000074113b7d30c6  mov [r15+0x58], r12
000074113b7d30ca  vmovaps xmm1, [rsp+0x30]
000074113b7d30d0  vmovaps [rsp+0x30], xmm15
000074113b7d30d6  vmovaps xmm15, [rsp+0xA0]
000074113b7d30df  vmovaps [rsp+0xA0], xmm14
000074113b7d30e8  vmovaps xmm14, [rsp+0x30]
000074113b7d30ee  vmovaps [rsp+0x30], xmm13
000074113b7d30f4  vmovaps [rsp+0xC0], xmm12
000074113b7d30fd  movaps xmm13, xmm1
000074113b7d3101  vfmadd231pd xmm13, xmm15, xmm14
000074113b7d3106  vcmppd xmm12, xmm13, xmm13, 0x03
000074113b7d310c  vptest xmm12, xmm12
000074113b7d3111  jnz 0x000074113B7D3BEA
000074113b7d3117  movaps xmm1, [r15+0x250]
000074113b7d311f  vmovaps xmm15, [rsp+0x40]
000074113b7d3125  vmovaps [rsp+0x40], xmm13
000074113b7d312b  movaps xmm12, xmm15
000074113b7d312f  vfmadd231pd xmm12, xmm1, xmm14
000074113b7d3134  vcmppd xmm13, xmm12, xmm12, 0x03
000074113b7d313a  vptest xmm13, xmm13
000074113b7d313f  jnz 0x000074113B7D3D43
000074113b7d3145  movaps xmm15, [r15+0x1E0]
000074113b7d314d  vmovaps [rsp+0xD0], xmm15
000074113b7d3156  vmovaps xmm13, [rsp+0xD0]
000074113b7d315f  por xmm15, xmm13
000074113b7d3164  movaps xmm13, [r15+0x1D0]
000074113b7d316c  vmovaps [rsp+0xD0], xmm13
000074113b7d3175  vmovaps [rsp+0xE0], xmm1
000074113b7d317e  vmovaps xmm1, [rsp+0xD0]
000074113b7d3187  por xmm13, xmm1
000074113b7d318c  movaps xmm1, [r15+0x2C0]
000074113b7d3194  vmovaps [rsp+0xD0], xmm1
000074113b7d319d  vmovaps [rsp+0xF0], xmm15
000074113b7d31a6  vmovaps xmm15, [rsp+0xD0]
000074113b7d31af  por xmm1, xmm15
000074113b7d31b4  movaps xmm15, [r15+0x290]
000074113b7d31bc  vmovaps [rsp+0xD0], xmm15
000074113b7d31c5  vmovaps [rsp+0x100], xmm1
000074113b7d31ce  vmovaps xmm1, [rsp+0xD0]
000074113b7d31d7  por xmm15, xmm1
000074113b7d31dc  movaps xmm1, [r15+0x260]
000074113b7d31e4  vmovaps [rsp+0xD0], xmm1
000074113b7d31ed  vmovaps [rsp+0x110], xmm15
000074113b7d31f6  vmovaps xmm15, [rsp+0xD0]
000074113b7d31ff  por xmm1, xmm15
000074113b7d3204  vmovaps xmm15, [rsp+0xE0]
000074113b7d320d  vmovaps [rsp+0xD0], xmm1
000074113b7d3216  vmovaps xmm1, [rsp+0xE0]
000074113b7d321f  por xmm15, xmm1
000074113b7d3224  lea r14, [rax+0xC0]
000074113b7d322b  movups xmm1, [r13+r14*1]
000074113b7d3231  mov [rsp+0xE0], rax
000074113b7d3239  xor eax, eax
000074113b7d323b  mov r14d, 0x200
000074113b7d3241  cmp r12, r14
000074113b7d3244  cmc
000074113b7d3245  lahf
000074113b7d3246  seto al
000074113b7d3249  mov [r15+0x108], eax
000074113b7d3250  vmovaps [rsp+0x120], xmm1
000074113b7d3259  vmovaps xmm1, [rsp+0x90]
000074113b7d3262  vmovaps [rsp+0x90], xmm15
000074113b7d326b  vmovaps xmm15, [rsp+0x120]
000074113b7d3274  vmovaps [rsp+0x120], xmm13
000074113b7d327d  vmovaps [rsp+0x130], xmm12
000074113b7d3286  movaps xmm13, xmm1
000074113b7d328a  vfmadd231pd xmm13, xmm15, xmm14
000074113b7d328f  vcmppd xmm12, xmm13, xmm13, 0x03
000074113b7d3295  vptest xmm12, xmm12
000074113b7d329a  jnz 0x000074113B7D3EA6
000074113b7d32a0  mov rax, [rsp+0xE0]
000074113b7d32a8  lea r14, [rax+0xB0]
000074113b7d32af  movups xmm1, [r13+r14*1]
000074113b7d32b5  vmovaps xmm15, [rsp+0xB0]
000074113b7d32be  vmovaps [rsp+0xB0], xmm13
000074113b7d32c7  movaps xmm12, xmm15
000074113b7d32cb  vfmadd231pd xmm12, xmm1, xmm14
000074113b7d32d0  vcmppd xmm13, xmm12, xmm12, 0x03
000074113b7d32d6  vptest xmm13, xmm13
000074113b7d32db  jnz 0x000074113B7D4009
000074113b7d32e1  vmovaps xmm1, [rsp+0x20]
000074113b7d32e7  vmovaps xmm15, [rsp+0x20]
000074113b7d32ed  por xmm1, xmm15
000074113b7d32f2  movaps [r15+0x210], xmm1
000074113b7d32fa  vmovaps xmm15, [rsp+0x80]
000074113b7d3303  vmovaps xmm14, [rsp+0x80]
000074113b7d330c  por xmm15, xmm14
000074113b7d3311  movaps [r15+0x1C0], xmm15
000074113b7d3319  vmovaps xmm14, [rsp+0x70]
000074113b7d331f  vmovaps xmm13, [rsp+0x70]
000074113b7d3325  por xmm14, xmm13
000074113b7d332a  movaps [r15+0x280], xmm14
000074113b7d3332  vmovaps xmm13, [rsp+0x60]
000074113b7d3338  vmovaps [rsp+0x20], xmm1
000074113b7d333e  vmovaps xmm1, [rsp+0x60]
000074113b7d3344  por xmm13, xmm1
000074113b7d3349  movaps [r15+0x2A0], xmm13
000074113b7d3351  vmovaps xmm1, [rsp+0x50]
000074113b7d3357  vmovaps [rsp+0x60], xmm15
000074113b7d335d  vmovaps xmm15, [rsp+0x50]
000074113b7d3363  por xmm1, xmm15
000074113b7d3368  movaps [r15+0x2E0], xmm1
000074113b7d3370  vmovaps [rsp+0x50], xmm2
000074113b7d3376  vmovaps xmm15, [rsp+0x50]
000074113b7d337c  por xmm2, xmm15
000074113b7d3381  movaps [r15+0x1F0], xmm2
000074113b7d3389  vmovaps xmm15, [rsp+0x90]
000074113b7d3392  vmovaps [rsp+0x50], xmm1
000074113b7d3398  vmovaps xmm1, [rsp+0x90]
000074113b7d33a1  por xmm15, xmm1
000074113b7d33a6  movaps [r15+0x250], xmm15
000074113b7d33ae  vmovaps xmm1, [rsp+0xD0]
000074113b7d33b7  vmovaps xmm15, [rsp+0xD0]
000074113b7d33c0  por xmm1, xmm15
000074113b7d33c5  movaps [r15+0x260], xmm1
000074113b7d33cd  vmovaps xmm15, [rsp+0x110]
000074113b7d33d6  vmovaps [rsp+0x70], xmm1
000074113b7d33dc  vmovaps xmm1, [rsp+0x110]
000074113b7d33e5  por xmm15, xmm1
000074113b7d33ea  movaps [r15+0x290], xmm15
000074113b7d33f2  vmovaps xmm1, [rsp+0x100]
000074113b7d33fb  vmovaps [rsp+0x80], xmm15
000074113b7d3404  vmovaps xmm15, [rsp+0x100]
000074113b7d340d  por xmm1, xmm15
000074113b7d3412  movaps [r15+0x2C0], xmm1
000074113b7d341a  movq xmm15, qword ptr [r15+0x240]
000074113b7d3423  vmovaps [rsp+0x90], xmm15
000074113b7d342c  vpermilpd xmm15, xmm15, 0x00
000074113b7d3432  vmovaps [rsp+0xD0], xmm1
000074113b7d343b  vmovaps xmm1, [rsp+0x40]
000074113b7d3441  vmovaps [rsp+0x40], xmm15
000074113b7d3447  vmovaps xmm15, [rsp+0x20]
000074113b7d344d  vmovaps [rsp+0x20], xmm14
000074113b7d3453  vmovaps xmm14, [rsp+0x40]
000074113b7d3459  vmovaps [rsp+0x40], xmm13
000074113b7d345f  vmovaps [rsp+0xE0], xmm12
000074113b7d3468  movaps xmm13, xmm1
000074113b7d346c  vfmadd231pd xmm13, xmm15, xmm14
000074113b7d3471  vcmppd xmm12, xmm13, xmm13, 0x03
000074113b7d3477  vptest xmm12, xmm12
000074113b7d347c  jnz 0x000074113B7D4162
000074113b7d3482  vmovaps xmm1, [rsp+0x90]
000074113b7d348b  vpermilpd xmm1, xmm1, 0x00
000074113b7d3491  vmovaps xmm15, [rsp+0xB0]
000074113b7d349a  vmovaps xmm14, [rsp+0x50]
000074113b7d34a0  vmovaps [rsp+0x50], xmm13
000074113b7d34a6  movaps xmm12, xmm15
000074113b7d34aa  vfmadd231pd xmm12, xmm14, xmm1
000074113b7d34af  vcmppd xmm13, xmm12, xmm12, 0x03
000074113b7d34b5  vptest xmm13, xmm13
000074113b7d34ba  jnz 0x000074113B7D42BB
000074113b7d34c0  vmovaps xmm1, [rsp+0x90]
000074113b7d34c9  vpermilpd xmm1, xmm1, 0x00
000074113b7d34cf  vmovaps xmm15, [rsp+0x130]
000074113b7d34d8  vmovaps xmm14, [rsp+0x60]
000074113b7d34de  vmovaps [rsp+0x60], xmm12
000074113b7d34e4  movaps xmm13, xmm15
000074113b7d34e8  vfmadd231pd xmm13, xmm14, xmm1
000074113b7d34ed  vcmppd xmm12, xmm13, xmm13, 0x03
000074113b7d34f3  vptest xmm12, xmm12
000074113b7d34f8  jnz 0x000074113B7D4414
000074113b7d34fe  vmovaps xmm1, [rsp+0x120]
000074113b7d3507  vmovaps xmm15, [rsp+0x120]
000074113b7d3510  por xmm1, xmm15
000074113b7d3515  movaps [r15+0x1D0], xmm1
000074113b7d351d  vmovaps xmm15, [rsp+0x90]
000074113b7d3526  vpermilpd xmm15, xmm15, 0x00
000074113b7d352c  vmovaps xmm14, [rsp+0xE0]
000074113b7d3535  vmovaps [rsp+0x90], xmm1
000074113b7d353e  movaps xmm12, xmm14
000074113b7d3542  vfmadd231pd xmm12, xmm2, xmm15
000074113b7d3547  vcmppd xmm1, xmm12, xmm12, 0x03
000074113b7d354d  vptest xmm1, xmm1
000074113b7d3552  jnz 0x000074113B7D456D
000074113b7d3558  vmovaps [rsp+0xB0], xmm3
000074113b7d3561  vmovaps xmm1, [rsp+0xB0]
000074113b7d356a  por xmm3, xmm1
000074113b7d356e  movaps [r15+0x200], xmm3
000074113b7d3576  vmovaps xmm1, [rsp+0xF0]
000074113b7d357f  vmovaps xmm15, [rsp+0xF0]
000074113b7d3588  por xmm1, xmm15
000074113b7d358d  movaps [r15+0x1E0], xmm1
000074113b7d3595  vmovaps [rsp+0xB0], xmm7
000074113b7d359e  vmovaps xmm1, [rsp+0xB0]
000074113b7d35a7  por xmm7, xmm1
000074113b7d35ab  movaps [r15+0x2B0], xmm7
000074113b7d35b3  vmovaps [rsp+0xB0], xmm8
000074113b7d35bc  vmovaps xmm1, [rsp+0xB0]
000074113b7d35c5  por xmm8, xmm1
000074113b7d35ca  movaps [r15+0x300], xmm8
000074113b7d35d2  vmovaps [rsp+0xB0], xmm5
000074113b7d35db  vpermilpd xmm5, xmm5, 0x00
000074113b7d35e1  vmovaps xmm14, [rsp+0x50]
000074113b7d35e7  vmovaps xmm8, [rsp+0x70]
000074113b7d35ed  vmovaps [rsp+0x50], xmm1
000074113b7d35f3  movaps xmm2, xmm14
000074113b7d35f7  vfmadd231pd xmm2, xmm8, xmm5
000074113b7d35fc  vcmppd xmm1, xmm2, xmm2, 0x03
000074113b7d3601  vptest xmm1, xmm1
000074113b7d3606  jnz 0x000074113B7D46C6
000074113b7d360c  vmovaps xmm1, [rsp+0xB0]
000074113b7d3615  vpermilpd xmm1, xmm1, 0x00
000074113b7d361b  vmovaps xmm14, [rsp+0x60]
000074113b7d3621  vmovaps xmm8, [rsp+0xD0]
000074113b7d362a  vmovaps [rsp+0x60], xmm15
000074113b7d3630  movaps xmm5, xmm14
000074113b7d3634  vfmadd231pd xmm5, xmm8, xmm1
000074113b7d3639  vcmppd xmm15, xmm5, xmm5, 0x03
000074113b7d363e  vptest xmm15, xmm15
000074113b7d3643  jnz 0x000074113B7D481D
000074113b7d3649  vmovaps xmm1, [rsp+0xB0]
000074113b7d3652  vpermilpd xmm1, xmm1, 0x00
000074113b7d3658  vmovaps xmm14, [rsp+0x20]
000074113b7d365e  movaps xmm15, xmm13
000074113b7d3662  vfmadd231pd xmm15, xmm14, xmm1
000074113b7d3667  vcmppd xmm8, xmm15, xmm15, 0x03
000074113b7d366d  vptest xmm8, xmm8
000074113b7d3672  jnz 0x000074113B7D4974
000074113b7d3678  vmovaps xmm1, [rsp+0xB0]
000074113b7d3681  vpermilpd xmm1, xmm1, 0x00
000074113b7d3687  vmovaps xmm14, [rsp+0x90]
000074113b7d3690  movaps xmm13, xmm12
000074113b7d3694  vfmadd231pd xmm13, xmm14, xmm1
000074113b7d3699  vcmppd xmm8, xmm13, xmm13, 0x03
000074113b7d369f  vptest xmm8, xmm8
000074113b7d36a4  jnz 0x000074113B7D4ACD
000074113b7d36aa  vmovaps [rsp+0x20], xmm6
000074113b7d36b0  vmovaps xmm1, [rsp+0x20]
000074113b7d36b6  por xmm6, xmm1
000074113b7d36ba  movaps [r15+0x180], xmm6
000074113b7d36c2  vmovaps [rsp+0x20], xmm9
000074113b7d36c8  vmovaps xmm1, [rsp+0x20]
000074113b7d36ce  por xmm9, xmm1
000074113b7d36d3  movaps [r15+0x2D0], xmm9
000074113b7d36db  vmovaps [rsp+0x20], xmm10
000074113b7d36e1  vmovaps xmm1, [rsp+0x20]
000074113b7d36e7  por xmm10, xmm1
000074113b7d36ec  movaps [r15+0x2F0], xmm10
000074113b7d36f4  vmovaps [rsp+0x20], xmm4
000074113b7d36fa  vpermilpd xmm4, xmm4, 0x00
000074113b7d3700  vmovaps xmm14, [rsp+0x50]
000074113b7d3706  movaps xmm12, xmm5
000074113b7d370a  vfmadd231pd xmm12, xmm14, xmm4
000074113b7d370f  vcmppd xmm10, xmm12, xmm12, 0x03
000074113b7d3715  vptest xmm10, xmm10
000074113b7d371a  jnz 0x000074113B7D4C26
000074113b7d3720  vmovaps xmm14, [rsp+0x20]
000074113b7d3726  vpermilpd xmm14, xmm14, 0x00
000074113b7d372c  movaps xmm10, xmm2
000074113b7d3730  vfmadd231pd xmm10, xmm6, xmm14
000074113b7d3735  vcmppd xmm8, xmm10, xmm10, 0x03
000074113b7d373b  vptest xmm8, xmm8
000074113b7d3740  jnz 0x000074113B7D4D7E
000074113b7d3746  lea r14, [rax+0x80]
000074113b7d374d  movups xmm14, [r13+r14*1]
000074113b7d3753  movaps [r15+0x190], xmm14
000074113b7d375b  vmovaps xmm8, [rsp+0x20]
000074113b7d3761  vpermilpd xmm8, xmm8, 0x00
000074113b7d3767  vmovaps xmm6, [rsp+0x80]
000074113b7d3770  movaps xmm5, xmm15
000074113b7d3774  vfmadd231pd xmm5, xmm6, xmm8
000074113b7d3779  vcmppd xmm4, xmm5, xmm5, 0x03
000074113b7d377e  vptest xmm4, xmm4
000074113b7d3783  jnz 0x000074113B7D4EE0
000074113b7d3789  vmovaps xmm15, [rsp+0x20]
000074113b7d378f  vpermilpd xmm15, xmm15, 0x00
000074113b7d3795  movaps xmm8, xmm13
000074113b7d3799  vfmadd231pd xmm8, xmm1, xmm15
000074113b7d379e  vcmppd xmm6, xmm8, xmm8, 0x03
000074113b7d37a4  vptest xmm6, xmm6
000074113b7d37a9  jnz 0x000074113B7D5037
000074113b7d37af  vmovaps xmm1, [rsp+0x30]
000074113b7d37b5  vmovaps xmm15, [rsp+0x30]
000074113b7d37bb  por xmm1, xmm15
000074113b7d37c0  movaps [r15+0x160], xmm1
000074113b7d37c8  lea r14, [rax+0x40]
000074113b7d37cc  movups xmm15, [r13+r14*1]
000074113b7d37d2  lea r14, [rax+0x50]
000074113b7d37d6  movups xmm13, [r13+r14*1]
000074113b7d37dc  movaps [r15+0x1B0], xmm15
000074113b7d37e4  movaps [r15+0x1A0], xmm13
000074113b7d37ec  vmovaps xmm6, [rsp+0xC0]
000074113b7d37f5  vpermilpd xmm6, xmm6, 0x00
000074113b7d37fb  movaps xmm4, xmm12
000074113b7d37ff  vfmadd231pd xmm4, xmm9, xmm6
000074113b7d3804  vcmppd xmm2, xmm4, xmm4, 0x03
000074113b7d3809  vptest xmm2, xmm2
000074113b7d380e  jnz 0x000074113B7D51A4
000074113b7d3814  vmovaps xmm12, [rsp+0xC0]
000074113b7d381d  vpermilpd xmm12, xmm12, 0x00
000074113b7d3823  movaps xmm9, xmm10
000074113b7d3827  vfmadd231pd xmm9, xmm1, xmm12
000074113b7d382c  vcmppd xmm6, xmm9, xmm9, 0x03
000074113b7d3832  vptest xmm6, xmm6
000074113b7d3837  jnz 0x000074113B7D52FB
000074113b7d383d  vmovaps xmm1, [rsp+0xC0]
000074113b7d3846  vpermilpd xmm1, xmm1, 0x00
000074113b7d384c  vmovaps xmm12, [rsp+0x40]
000074113b7d3852  movaps xmm10, xmm5
000074113b7d3856  vfmadd231pd xmm10, xmm12, xmm1
000074113b7d385b  vcmppd xmm6, xmm10, xmm10, 0x03
000074113b7d3861  vptest xmm6, xmm6
000074113b7d3866  jnz 0x000074113B7D5454
000074113b7d386c  vmovaps xmm1, [rsp+0xC0]
000074113b7d3875  vpermilpd xmm1, xmm1, 0x00
000074113b7d387b  vmovaps xmm12, [rsp+0x60]
000074113b7d3881  movaps xmm6, xmm8
000074113b7d3885  vfmadd231pd xmm6, xmm12, xmm1
000074113b7d388a  vcmppd xmm5, xmm6, xmm6, 0x03
000074113b7d388f  vptest xmm5, xmm5
000074113b7d3894  jnz 0x000074113B7D55AC
000074113b7d389a  lea r14, [rax+0x60]
000074113b7d389e  movups xmm1, [r13+r14*1]
000074113b7d38a4  lea r14, [rax+0x70]
000074113b7d38a8  movups xmm12, [r13+r14*1]
000074113b7d38ae  movaps [r15+0x150], xmm1
000074113b7d38b6  movaps [r15+0x120], xmm12
000074113b7d38be  vmovaps [rsp+0x20], xmm11
000074113b7d38c4  vpermilpd xmm11, xmm11, 0x00
000074113b7d38ca  movaps xmm8, xmm4
000074113b7d38ce  vfmadd231pd xmm8, xmm13, xmm11
000074113b7d38d3  vcmppd xmm5, xmm8, xmm8, 0x03
000074113b7d38d9  vptest xmm5, xmm5
000074113b7d38de  jnz 0x000074113B7D5717
000074113b7d38e4  vmovaps xmm13, [rsp+0x20]
000074113b7d38ea  vpermilpd xmm13, xmm13, 0x00
000074113b7d38f0  movaps xmm11, xmm9
000074113b7d38f4  vfmadd231pd xmm11, xmm1, xmm13
000074113b7d38f9  vcmppd xmm5, xmm11, xmm11, 0x03
000074113b7d38ff  vptest xmm5, xmm5
000074113b7d3904  jnz 0x000074113B7D5870
000074113b7d390a  vmovaps xmm1, [rsp+0x20]
000074113b7d3910  vpermilpd xmm1, xmm1, 0x00
000074113b7d3916  movaps xmm13, xmm10
000074113b7d391a  vfmadd231pd xmm13, xmm7, xmm1
000074113b7d391f  vcmppd xmm9, xmm13, xmm13, 0x03
000074113b7d3925  vptest xmm9, xmm9
000074113b7d392a  jnz 0x000074113B7D59C9
000074113b7d3930  vmovaps xmm1, [rsp+0x20]
000074113b7d3936  vpermilpd xmm1, xmm1, 0x00
000074113b7d393c  movaps xmm10, xmm6
000074113b7d3940  vfmadd231pd xmm10, xmm15, xmm1
000074113b7d3945  vcmppd xmm9, xmm10, xmm10, 0x03
000074113b7d394b  vptest xmm9, xmm9
000074113b7d3950  jnz 0x000074113B7D5B21
000074113b7d3956  lea r14, [rax+0x20]
000074113b7d395a  movups xmm1, [r13+r14*1]
000074113b7d3960  lea r14, [rax+0x30]
000074113b7d3964  movups xmm15, [r13+r14*1]
000074113b7d396a  vmovaps xmm9, [rsp+0xA0]
000074113b7d3973  vpermilpd xmm9, xmm9, 0x00
000074113b7d3979  movaps xmm7, xmm8
000074113b7d397d  vfmadd231pd xmm7, xmm3, xmm9
000074113b7d3982  vcmppd xmm6, xmm7, xmm7, 0x03
000074113b7d3987  vptest xmm6, xmm6
000074113b7d398c  jnz 0x000074113B7D5C8D
000074113b7d3992  vmovaps xmm9, [rsp+0xA0]
000074113b7d399b  vpermilpd xmm9, xmm9, 0x00
000074113b7d39a1  movaps xmm8, xmm11
000074113b7d39a5  vfmadd231pd xmm8, xmm14, xmm9
000074113b7d39aa  vcmppd xmm6, xmm8, xmm8, 0x03
000074113b7d39b0  vptest xmm6, xmm6
000074113b7d39b5  jnz 0x000074113B7D5DE4
000074113b7d39bb  vmovaps xmm14, [rsp+0xA0]
000074113b7d39c4  vpermilpd xmm14, xmm14, 0x00
000074113b7d39ca  movaps xmm11, xmm13
000074113b7d39ce  vfmadd231pd xmm11, xmm12, xmm14
000074113b7d39d3  vcmppd xmm9, xmm11, xmm11, 0x03
000074113b7d39d9  vptest xmm9, xmm9
000074113b7d39de  jnz 0x000074113B7D5F3E
000074113b7d39e4  vmovaps xmm14, [rsp+0xA0]
000074113b7d39ed  vpermilpd xmm14, xmm14, 0x00
000074113b7d39f3  movaps xmm12, xmm10
000074113b7d39f7  vfmadd231pd xmm12, xmm15, xmm14
000074113b7d39fc  vcmppd xmm13, xmm12, xmm12, 0x03
000074113b7d3a02  vptest xmm13, xmm13
000074113b7d3a07  jnz 0x000074113B7D6098
000074113b7d3a0d  lea r14, [rax+0x90]
000074113b7d3a14  movups xmm15, [r13+r14*1]
000074113b7d3a1a  lea r14, [rax+0xA0]
000074113b7d3a21  movups xmm14, [r13+r14*1]
000074113b7d3a27  movaps [r15+0x140], xmm15
000074113b7d3a2f  movaps [r15+0x130], xmm14
000074113b7d3a37  vmovaps xmm13, [rsp+0x10]
000074113b7d3a3d  vpermilpd xmm13, xmm13, 0x00
000074113b7d3a43  movaps xmm10, xmm7
000074113b7d3a47  vfmadd231pd xmm10, xmm1, xmm13
000074113b7d3a4c  vcmppd xmm9, xmm10, xmm10, 0x03
000074113b7d3a52  vptest xmm9, xmm9
000074113b7d3a57  jnz 0x000074113B7D6206
000074113b7d3a5d  movaps [r15+0x220], xmm10
000074113b7d3a65  lea r14, [rax+0x10]
000074113b7d3a69  movups xmm1, [r13+r14*1]
000074113b7d3a6f  movaps [r15+0x240], xmm1
000074113b7d3a77  vmovaps xmm13, [rsp+0x10]
000074113b7d3a7d  vpermilpd xmm13, xmm13, 0x00
000074113b7d3a83  movaps xmm9, xmm8
000074113b7d3a87  vfmadd231pd xmm9, xmm14, xmm13
000074113b7d3a8c  vcmppd xmm7, xmm9, xmm9, 0x03
000074113b7d3a92  vptest xmm7, xmm7
000074113b7d3a97  jnz 0x000074113B7D6368
000074113b7d3a9d  movaps [r15+0x110], xmm9
000074113b7d3aa5  vmovaps xmm14, [rsp+0x10]
000074113b7d3aab  vpermilpd xmm14, xmm14, 0x00
000074113b7d3ab1  movaps xmm13, xmm11
000074113b7d3ab5  vfmadd231pd xmm13, xmm15, xmm14
000074113b7d3aba  vcmppd xmm8, xmm13, xmm13, 0x03
000074113b7d3ac0  vptest xmm8, xmm8
000074113b7d3ac5  jnz 0x000074113B7D64C2
000074113b7d3acb  movaps [r15+0x170], xmm13
000074113b7d3ad3  vmovaps xmm15, [rsp+0x10]
000074113b7d3ad9  vpermilpd xmm15, xmm15, 0x00
000074113b7d3adf  movaps xmm14, xmm12
000074113b7d3ae3  vfmadd231pd xmm14, xmm1, xmm15
000074113b7d3ae8  vcmppd xmm11, xmm14, xmm14, 0x03
000074113b7d3aee  vptest xmm11, xmm11
000074113b7d3af3  jnz 0x000074113B7D661C
000074113b7d3af9  movaps [r15+0x230], xmm14
000074113b7d3b01  movups [r13+r11*1], xmm9
000074113b7d3b07  lea rax, [r11+0x10]
000074113b7d3b0b  movups [r13+rax*1], xmm13
000074113b7d3b11  lea rax, [r11+0x20]
000074113b7d3b15  movups [r13+rax*1], xmm10
000074113b7d3b1b  lea rax, [r11+0x30]
000074113b7d3b1f  movups [r13+rax*1], xmm14
000074113b7d3b25  mov eax, [r15+0x108]
000074113b7d3b2c  sahf
000074113b7d3b2d  jnz 0x000074113B7D3B5F
000074113b7d3b2f  cmp dword ptr [r15+0x318], 0x00
000074113b7d3b37  jz 0x000074113B7D67A0
000074113b7d3b3d  nop [rax+rax*1], ax
000074113b7d3b46  nop [rax+rax*1], eax
000074113b7d3b4e  mov eax, 0x4103F0
000074113b7d3b53  mov [r15+0x100], rax
000074113b7d3b5a  jmp 0x000074113B5FE110
000074113b7d3b5f  cmp dword ptr [r15+0x318], 0x00
000074113b7d3b67  jz 0x000074113B7D2E40
000074113b7d3b6d  nop [rax+rax*1], ax
000074113b7d3b76  nop [rax+rax*1], eax
000074113b7d3b7e  mov eax, 0x410274
000074113b7d3b83  mov [r15+0x100], rax
000074113b7d3b8a  jmp 0x000074113B5FE110
000074113b7d3b8f  int3
000074113b7d3b90  call 0x000074113B60A4B0
000074113b7d3b95  jmp 0x000074113B7D2E69
000074113b7d3b9a  call 0x000074113B609240
000074113b7d3b9f  jmp 0x000074113B7D2E73
000074113b7d3ba4  call 0x000074113B60A4B0
000074113b7d3ba9  jmp 0x000074113B7D2EBD
000074113b7d3bae  call 0x000074113B609240
000074113b7d3bb3  jmp 0x000074113B7D2EC7
000074113b7d3bb8  call 0x000074113B60A4B0
000074113b7d3bbd  jmp 0x000074113B7D2F60
000074113b7d3bc2  call 0x000074113B609240
000074113b7d3bc7  jmp 0x000074113B7D2F6A
000074113b7d3bcc  call 0x000074113B6B47C0
000074113b7d3bd1  jmp 0x000074113B7D3055
000074113b7d3bd6  call 0x000074113B5FF430
000074113b7d3bdb  jmp 0x000074113B7D3084
000074113b7d3be0  call 0x000074113B6B0CE0
000074113b7d3be5  jmp 0x000074113B7D30A0
000074113b7d3bea  sub rsp, 0x08
000074113b7d3bee  push rax
000074113b7d3bef  push rcx
000074113b7d3bf0  push rdx
000074113b7d3bf1  push rdi
000074113b7d3bf2  push rsi
000074113b7d3bf3  push r8
000074113b7d3bf5  push r9
000074113b7d3bf7  push r10
000074113b7d3bf9  push r11
000074113b7d3bfb  sub rsp, 0xF0
000074113b7d3c02  vmovaps [rsp], xmm0
000074113b7d3c07  vmovaps [rsp+0x10], xmm1
000074113b7d3c0d  vmovaps [rsp+0x20], xmm2
000074113b7d3c13  vmovaps [rsp+0x30], xmm3
000074113b7d3c19  vmovaps [rsp+0x40], xmm4
000074113b7d3c1f  vmovaps [rsp+0x50], xmm5
000074113b7d3c25  vmovaps [rsp+0x60], xmm6
000074113b7d3c2b  vmovaps [rsp+0x70], xmm7
000074113b7d3c31  vmovaps [rsp+0x80], xmm8
000074113b7d3c3a  vmovaps [rsp+0x90], xmm9
000074113b7d3c43  vmovaps [rsp+0xA0], xmm10
000074113b7d3c4c  vmovaps [rsp+0xB0], xmm11
000074113b7d3c55  vmovaps [rsp+0xC0], xmm12
000074113b7d3c5e  vmovaps [rsp+0xD0], xmm14
000074113b7d3c67  vmovaps [rsp+0xE0], xmm15
000074113b7d3c70  sub rsp, 0x40
000074113b7d3c74  lea rdi, [rsp]
000074113b7d3c78  lea rsi, [rsp+0x10]
000074113b7d3c7d  lea rdx, [rsp+0x20]
000074113b7d3c82  lea rcx, [rsp+0x30]
000074113b7d3c87  mov r8d, 0x00
000074113b7d3c8d  lea r9, [r15+0x3A8]
000074113b7d3c94  movaps [rdi], xmm13
000074113b7d3c98  movaps [rsi], xmm1
000074113b7d3c9b  movaps [rdx], xmm15
000074113b7d3c9f  movaps [rcx], xmm14
000074113b7d3ca3  mov rax, 0x629073062A50
000074113b7d3cad  call rax
000074113b7d3caf  movaps xmm13, [rsp]
000074113b7d3cb4  add rsp, 0x40
000074113b7d3cb8  vmovaps xmm0, [rsp]
000074113b7d3cbd  vmovaps xmm1, [rsp+0x10]
000074113b7d3cc3  vmovaps xmm2, [rsp+0x20]
000074113b7d3cc9  vmovaps xmm3, [rsp+0x30]
000074113b7d3ccf  vmovaps xmm4, [rsp+0x40]
000074113b7d3cd5  vmovaps xmm5, [rsp+0x50]
000074113b7d3cdb  vmovaps xmm6, [rsp+0x60]
000074113b7d3ce1  vmovaps xmm7, [rsp+0x70]
000074113b7d3ce7  vmovaps xmm8, [rsp+0x80]
000074113b7d3cf0  vmovaps xmm9, [rsp+0x90]
000074113b7d3cf9  vmovaps xmm10, [rsp+0xA0]
000074113b7d3d02  vmovaps xmm11, [rsp+0xB0]
000074113b7d3d0b  vmovaps xmm12, [rsp+0xC0]
000074113b7d3d14  vmovaps xmm14, [rsp+0xD0]
000074113b7d3d1d  vmovaps xmm15, [rsp+0xE0]
000074113b7d3d26  add rsp, 0xF0
000074113b7d3d2d  pop r11
000074113b7d3d2f  pop r10
000074113b7d3d31  pop r9
000074113b7d3d33  pop r8
000074113b7d3d35  pop rsi
000074113b7d3d36  pop rdi
000074113b7d3d37  pop rdx
000074113b7d3d38  pop rcx
000074113b7d3d39  pop rax
000074113b7d3d3a  add rsp, 0x08
000074113b7d3d3e  jmp 0x000074113B7D3117
000074113b7d3d43  sub rsp, 0x08
000074113b7d3d47  push rax
000074113b7d3d48  push rcx
000074113b7d3d49  push rdx
000074113b7d3d4a  push rdi
000074113b7d3d4b  push rsi
000074113b7d3d4c  push r8
000074113b7d3d4e  push r9
000074113b7d3d50  push r10
000074113b7d3d52  push r11
000074113b7d3d54  sub rsp, 0xF0
000074113b7d3d5b  vmovaps [rsp], xmm0
000074113b7d3d60  vmovaps [rsp+0x10], xmm1
000074113b7d3d66  vmovaps [rsp+0x20], xmm2
000074113b7d3d6c  vmovaps [rsp+0x30], xmm3
000074113b7d3d72  vmovaps [rsp+0x40], xmm4
000074113b7d3d78  vmovaps [rsp+0x50], xmm5
000074113b7d3d7e  vmovaps [rsp+0x60], xmm6
000074113b7d3d84  vmovaps [rsp+0x70], xmm7
000074113b7d3d8a  vmovaps [rsp+0x80], xmm8
000074113b7d3d93  vmovaps [rsp+0x90], xmm9
000074113b7d3d9c  vmovaps [rsp+0xA0], xmm10
000074113b7d3da5  vmovaps [rsp+0xB0], xmm11
000074113b7d3dae  vmovaps [rsp+0xC0], xmm13
000074113b7d3db7  vmovaps [rsp+0xD0], xmm14
000074113b7d3dc0  vmovaps [rsp+0xE0], xmm15
000074113b7d3dc9  sub rsp, 0x40
000074113b7d3dcd  lea rdi, [rsp]
000074113b7d3dd1  lea rsi, [rsp+0x10]
000074113b7d3dd6  lea rdx, [rsp+0x20]
000074113b7d3ddb  lea rcx, [rsp+0x30]
000074113b7d3de0  mov r8d, 0x00
000074113b7d3de6  lea r9, [r15+0x3A8]
000074113b7d3ded  movaps [rdi], xmm12
000074113b7d3df1  movaps [rsi], xmm15
000074113b7d3df5  movaps [rdx], xmm1
000074113b7d3df8  movaps [rcx], xmm14
000074113b7d3dfc  mov rax, 0x629073062A50
000074113b7d3e06  call rax
000074113b7d3e08  movaps xmm12, [rsp]
000074113b7d3e0d  add rsp, 0x40
000074113b7d3e11  vmovaps xmm0, [rsp]
000074113b7d3e16  vmovaps xmm1, [rsp+0x10]
000074113b7d3e1c  vmovaps xmm2, [rsp+0x20]
000074113b7d3e22  vmovaps xmm3, [rsp+0x30]
000074113b7d3e28  vmovaps xmm4, [rsp+0x40]
000074113b7d3e2e  vmovaps xmm5, [rsp+0x50]
000074113b7d3e34  vmovaps xmm6, [rsp+0x60]
000074113b7d3e3a  vmovaps xmm7, [rsp+0x70]
000074113b7d3e40  vmovaps xmm8, [rsp+0x80]
000074113b7d3e49  vmovaps xmm9, [rsp+0x90]
000074113b7d3e52  vmovaps xmm10, [rsp+0xA0]
000074113b7d3e5b  vmovaps xmm11, [rsp+0xB0]
000074113b7d3e64  vmovaps xmm13, [rsp+0xC0]
000074113b7d3e6d  vmovaps xmm14, [rsp+0xD0]
000074113b7d3e76  vmovaps xmm15, [rsp+0xE0]
000074113b7d3e7f  add rsp, 0xF0
000074113b7d3e86  pop r11
000074113b7d3e88  pop r10
000074113b7d3e8a  pop r9
000074113b7d3e8c  pop r8
000074113b7d3e8e  pop rsi
000074113b7d3e8f  pop rdi
000074113b7d3e90  pop rdx
000074113b7d3e91  pop rcx
000074113b7d3e92  pop rax
000074113b7d3e93  add rsp, 0x08
000074113b7d3e97  jmp 0x000074113B7D3145
000074113b7d3e9c  call 0x000074113B6D64F0
000074113b7d3ea1  jmp 0x000074113B7D3231
000074113b7d3ea6  sub rsp, 0x08
000074113b7d3eaa  push rax
000074113b7d3eab  push rcx
000074113b7d3eac  push rdx
000074113b7d3ead  push rdi
000074113b7d3eae  push rsi
000074113b7d3eaf  push r8
000074113b7d3eb1  push r9
000074113b7d3eb3  push r10
000074113b7d3eb5  push r11
000074113b7d3eb7  sub rsp, 0xF0
000074113b7d3ebe  vmovaps [rsp], xmm0
000074113b7d3ec3  vmovaps [rsp+0x10], xmm1
000074113b7d3ec9  vmovaps [rsp+0x20], xmm2
000074113b7d3ecf  vmovaps [rsp+0x30], xmm3
000074113b7d3ed5  vmovaps [rsp+0x40], xmm4
000074113b7d3edb  vmovaps [rsp+0x50], xmm5
000074113b7d3ee1  vmovaps [rsp+0x60], xmm6
000074113b7d3ee7  vmovaps [rsp+0x70], xmm7
000074113b7d3eed  vmovaps [rsp+0x80], xmm8
000074113b7d3ef6  vmovaps [rsp+0x90], xmm9
000074113b7d3eff  vmovaps [rsp+0xA0], xmm10
000074113b7d3f08  vmovaps [rsp+0xB0], xmm11
000074113b7d3f11  vmovaps [rsp+0xC0], xmm12
000074113b7d3f1a  vmovaps [rsp+0xD0], xmm14
000074113b7d3f23  vmovaps [rsp+0xE0], xmm15
000074113b7d3f2c  sub rsp, 0x40
000074113b7d3f30  lea rdi, [rsp]
000074113b7d3f34  lea rsi, [rsp+0x10]
000074113b7d3f39  lea rdx, [rsp+0x20]
000074113b7d3f3e  lea rcx, [rsp+0x30]
000074113b7d3f43  mov r8d, 0x00
000074113b7d3f49  lea r9, [r15+0x3A8]
000074113b7d3f50  movaps [rdi], xmm13
000074113b7d3f54  movaps [rsi], xmm1
000074113b7d3f57  movaps [rdx], xmm15
000074113b7d3f5b  movaps [rcx], xmm14
000074113b7d3f5f  mov rax, 0x629073062A50
000074113b7d3f69  call rax
000074113b7d3f6b  movaps xmm13, [rsp]
000074113b7d3f70  add rsp, 0x40
000074113b7d3f74  vmovaps xmm0, [rsp]
000074113b7d3f79  vmovaps xmm1, [rsp+0x10]
000074113b7d3f7f  vmovaps xmm2, [rsp+0x20]
000074113b7d3f85  vmovaps xmm3, [rsp+0x30]
000074113b7d3f8b  vmovaps xmm4, [rsp+0x40]
000074113b7d3f91  vmovaps xmm5, [rsp+0x50]
000074113b7d3f97  vmovaps xmm6, [rsp+0x60]
000074113b7d3f9d  vmovaps xmm7, [rsp+0x70]
000074113b7d3fa3  vmovaps xmm8, [rsp+0x80]
000074113b7d3fac  vmovaps xmm9, [rsp+0x90]
000074113b7d3fb5  vmovaps xmm10, [rsp+0xA0]
000074113b7d3fbe  vmovaps xmm11, [rsp+0xB0]
000074113b7d3fc7  vmovaps xmm12, [rsp+0xC0]
000074113b7d3fd0  vmovaps xmm14, [rsp+0xD0]
000074113b7d3fd9  vmovaps xmm15, [rsp+0xE0]
000074113b7d3fe2  add rsp, 0xF0
000074113b7d3fe9  pop r11
000074113b7d3feb  pop r10
000074113b7d3fed  pop r9
000074113b7d3fef  pop r8
000074113b7d3ff1  pop rsi
000074113b7d3ff2  pop rdi
000074113b7d3ff3  pop rdx
000074113b7d3ff4  pop rcx
000074113b7d3ff5  pop rax
000074113b7d3ff6  add rsp, 0x08
000074113b7d3ffa  jmp 0x000074113B7D32A0
000074113b7d3fff  call 0x000074113B6D64F0
000074113b7d4004  jmp 0x000074113B7D32B5
000074113b7d4009  sub rsp, 0x08
000074113b7d400d  push rax
000074113b7d400e  push rcx
000074113b7d400f  push rdx
000074113b7d4010  push rdi
000074113b7d4011  push rsi
000074113b7d4012  push r8
000074113b7d4014  push r9
000074113b7d4016  push r10
000074113b7d4018  push r11
000074113b7d401a  sub rsp, 0xF0
000074113b7d4021  vmovaps [rsp], xmm0
000074113b7d4026  vmovaps [rsp+0x10], xmm1
000074113b7d402c  vmovaps [rsp+0x20], xmm2
000074113b7d4032  vmovaps [rsp+0x30], xmm3
000074113b7d4038  vmovaps [rsp+0x40], xmm4
000074113b7d403e  vmovaps [rsp+0x50], xmm5
000074113b7d4044  vmovaps [rsp+0x60], xmm6
000074113b7d404a  vmovaps [rsp+0x70], xmm7
000074113b7d4050  vmovaps [rsp+0x80], xmm8
000074113b7d4059  vmovaps [rsp+0x90], xmm9
000074113b7d4062  vmovaps [rsp+0xA0], xmm10
000074113b7d406b  vmovaps [rsp+0xB0], xmm11
000074113b7d4074  vmovaps [rsp+0xC0], xmm13
000074113b7d407d  vmovaps [rsp+0xD0], xmm14
000074113b7d4086  vmovaps [rsp+0xE0], xmm15
000074113b7d408f  sub rsp, 0x40
000074113b7d4093  lea rdi, [rsp]
000074113b7d4097  lea rsi, [rsp+0x10]
000074113b7d409c  lea rdx, [rsp+0x20]
000074113b7d40a1  lea rcx, [rsp+0x30]
000074113b7d40a6  mov r8d, 0x00
000074113b7d40ac  lea r9, [r15+0x3A8]
000074113b7d40b3  movaps [rdi], xmm12
000074113b7d40b7  movaps [rsi], xmm15
000074113b7d40bb  movaps [rdx], xmm1
000074113b7d40be  movaps [rcx], xmm14
000074113b7d40c2  mov rax, 0x629073062A50
000074113b7d40cc  call rax
000074113b7d40ce  movaps xmm12, [rsp]
000074113b7d40d3  add rsp, 0x40
000074113b7d40d7  vmovaps xmm0, [rsp]
000074113b7d40dc  vmovaps xmm1, [rsp+0x10]
000074113b7d40e2  vmovaps xmm2, [rsp+0x20]
000074113b7d40e8  vmovaps xmm3, [rsp+0x30]
000074113b7d40ee  vmovaps xmm4, [rsp+0x40]
000074113b7d40f4  vmovaps xmm5, [rsp+0x50]
000074113b7d40fa  vmovaps xmm6, [rsp+0x60]
000074113b7d4100  vmovaps xmm7, [rsp+0x70]
000074113b7d4106  vmovaps xmm8, [rsp+0x80]
000074113b7d410f  vmovaps xmm9, [rsp+0x90]
000074113b7d4118  vmovaps xmm10, [rsp+0xA0]
000074113b7d4121  vmovaps xmm11, [rsp+0xB0]
000074113b7d412a  vmovaps xmm13, [rsp+0xC0]
000074113b7d4133  vmovaps xmm14, [rsp+0xD0]
000074113b7d413c  vmovaps xmm15, [rsp+0xE0]
000074113b7d4145  add rsp, 0xF0
000074113b7d414c  pop r11
000074113b7d414e  pop r10
000074113b7d4150  pop r9
000074113b7d4152  pop r8
000074113b7d4154  pop rsi
000074113b7d4155  pop rdi
000074113b7d4156  pop rdx
000074113b7d4157  pop rcx
000074113b7d4158  pop rax
000074113b7d4159  add rsp, 0x08
000074113b7d415d  jmp 0x000074113B7D32E1
000074113b7d4162  sub rsp, 0x08
000074113b7d4166  push rax
000074113b7d4167  push rcx
000074113b7d4168  push rdx
000074113b7d4169  push rdi
000074113b7d416a  push rsi
000074113b7d416b  push r8
000074113b7d416d  push r9
000074113b7d416f  push r10
000074113b7d4171  push r11
000074113b7d4173  sub rsp, 0xF0
000074113b7d417a  vmovaps [rsp], xmm0
000074113b7d417f  vmovaps [rsp+0x10], xmm1
000074113b7d4185  vmovaps [rsp+0x20], xmm2
000074113b7d418b  vmovaps [rsp+0x30], xmm3
000074113b7d4191  vmovaps [rsp+0x40], xmm4
000074113b7d4197  vmovaps [rsp+0x50], xmm5
000074113b7d419d  vmovaps [rsp+0x60], xmm6
000074113b7d41a3  vmovaps [rsp+0x70], xmm7
000074113b7d41a9  vmovaps [rsp+0x80], xmm8
000074113b7d41b2  vmovaps [rsp+0x90], xmm9
000074113b7d41bb  vmovaps [rsp+0xA0], xmm10
000074113b7d41c4  vmovaps [rsp+0xB0], xmm11
000074113b7d41cd  vmovaps [rsp+0xC0], xmm12
000074113b7d41d6  vmovaps [rsp+0xD0], xmm14
000074113b7d41df  vmovaps [rsp+0xE0], xmm15
000074113b7d41e8  sub rsp, 0x40
000074113b7d41ec  lea rdi, [rsp]
000074113b7d41f0  lea rsi, [rsp+0x10]
000074113b7d41f5  lea rdx, [rsp+0x20]
000074113b7d41fa  lea rcx, [rsp+0x30]
000074113b7d41ff  mov r8d, 0x00
000074113b7d4205  lea r9, [r15+0x3A8]
000074113b7d420c  movaps [rdi], xmm13
000074113b7d4210  movaps [rsi], xmm1
000074113b7d4213  movaps [rdx], xmm15
000074113b7d4217  movaps [rcx], xmm14
000074113b7d421b  mov rax, 0x629073062A50
000074113b7d4225  call rax
000074113b7d4227  movaps xmm13, [rsp]
000074113b7d422c  add rsp, 0x40
000074113b7d4230  vmovaps xmm0, [rsp]
000074113b7d4235  vmovaps xmm1, [rsp+0x10]
000074113b7d423b  vmovaps xmm2, [rsp+0x20]
000074113b7d4241  vmovaps xmm3, [rsp+0x30]
000074113b7d4247  vmovaps xmm4, [rsp+0x40]
000074113b7d424d  vmovaps xmm5, [rsp+0x50]
000074113b7d4253  vmovaps xmm6, [rsp+0x60]
000074113b7d4259  vmovaps xmm7, [rsp+0x70]
000074113b7d425f  vmovaps xmm8, [rsp+0x80]
000074113b7d4268  vmovaps xmm9, [rsp+0x90]
000074113b7d4271  vmovaps xmm10, [rsp+0xA0]
000074113b7d427a  vmovaps xmm11, [rsp+0xB0]
000074113b7d4283  vmovaps xmm12, [rsp+0xC0]
000074113b7d428c  vmovaps xmm14, [rsp+0xD0]
000074113b7d4295  vmovaps xmm15, [rsp+0xE0]
000074113b7d429e  add rsp, 0xF0
000074113b7d42a5  pop r11
000074113b7d42a7  pop r10
000074113b7d42a9  pop r9
000074113b7d42ab  pop r8
000074113b7d42ad  pop rsi
000074113b7d42ae  pop rdi
000074113b7d42af  pop rdx
000074113b7d42b0  pop rcx
000074113b7d42b1  pop rax
000074113b7d42b2  add rsp, 0x08
000074113b7d42b6  jmp 0x000074113B7D3482
000074113b7d42bb  sub rsp, 0x08
000074113b7d42bf  push rax
000074113b7d42c0  push rcx
000074113b7d42c1  push rdx
000074113b7d42c2  push rdi
000074113b7d42c3  push rsi
000074113b7d42c4  push r8
000074113b7d42c6  push r9
000074113b7d42c8  push r10
000074113b7d42ca  push r11
000074113b7d42cc  sub rsp, 0xF0
000074113b7d42d3  vmovaps [rsp], xmm0
000074113b7d42d8  vmovaps [rsp+0x10], xmm1
000074113b7d42de  vmovaps [rsp+0x20], xmm2
000074113b7d42e4  vmovaps [rsp+0x30], xmm3
000074113b7d42ea  vmovaps [rsp+0x40], xmm4
000074113b7d42f0  vmovaps [rsp+0x50], xmm5
000074113b7d42f6  vmovaps [rsp+0x60], xmm6
000074113b7d42fc  vmovaps [rsp+0x70], xmm7
000074113b7d4302  vmovaps [rsp+0x80], xmm8
000074113b7d430b  vmovaps [rsp+0x90], xmm9
000074113b7d4314  vmovaps [rsp+0xA0], xmm10
000074113b7d431d  vmovaps [rsp+0xB0], xmm11
000074113b7d4326  vmovaps [rsp+0xC0], xmm13
000074113b7d432f  vmovaps [rsp+0xD0], xmm14
000074113b7d4338  vmovaps [rsp+0xE0], xmm15
000074113b7d4341  sub rsp, 0x40
000074113b7d4345  lea rdi, [rsp]
000074113b7d4349  lea rsi, [rsp+0x10]
000074113b7d434e  lea rdx, [rsp+0x20]
000074113b7d4353  lea rcx, [rsp+0x30]
000074113b7d4358  mov r8d, 0x00
000074113b7d435e  lea r9, [r15+0x3A8]
000074113b7d4365  movaps [rdi], xmm12
000074113b7d4369  movaps [rsi], xmm15
000074113b7d436d  movaps [rdx], xmm14
000074113b7d4371  movaps [rcx], xmm1
000074113b7d4374  mov rax, 0x629073062A50
000074113b7d437e  call rax
000074113b7d4380  movaps xmm12, [rsp]
000074113b7d4385  add rsp, 0x40
000074113b7d4389  vmovaps xmm0, [rsp]
000074113b7d438e  vmovaps xmm1, [rsp+0x10]
000074113b7d4394  vmovaps xmm2, [rsp+0x20]
000074113b7d439a  vmovaps xmm3, [rsp+0x30]
000074113b7d43a0  vmovaps xmm4, [rsp+0x40]
000074113b7d43a6  vmovaps xmm5, [rsp+0x50]
000074113b7d43ac  vmovaps xmm6, [rsp+0x60]
000074113b7d43b2  vmovaps xmm7, [rsp+0x70]
000074113b7d43b8  vmovaps xmm8, [rsp+0x80]
000074113b7d43c1  vmovaps xmm9, [rsp+0x90]
000074113b7d43ca  vmovaps xmm10, [rsp+0xA0]
000074113b7d43d3  vmovaps xmm11, [rsp+0xB0]
000074113b7d43dc  vmovaps xmm13, [rsp+0xC0]
000074113b7d43e5  vmovaps xmm14, [rsp+0xD0]
000074113b7d43ee  vmovaps xmm15, [rsp+0xE0]
000074113b7d43f7  add rsp, 0xF0
000074113b7d43fe  pop r11
000074113b7d4400  pop r10
000074113b7d4402  pop r9
000074113b7d4404  pop r8
000074113b7d4406  pop rsi
000074113b7d4407  pop rdi
000074113b7d4408  pop rdx
000074113b7d4409  pop rcx
000074113b7d440a  pop rax
000074113b7d440b  add rsp, 0x08
000074113b7d440f  jmp 0x000074113B7D34C0
000074113b7d4414  sub rsp, 0x08
000074113b7d4418  push rax
000074113b7d4419  push rcx
000074113b7d441a  push rdx
000074113b7d441b  push rdi
000074113b7d441c  push rsi
000074113b7d441d  push r8
000074113b7d441f  push r9
000074113b7d4421  push r10
000074113b7d4423  push r11
000074113b7d4425  sub rsp, 0xF0
000074113b7d442c  vmovaps [rsp], xmm0
000074113b7d4431  vmovaps [rsp+0x10], xmm1
000074113b7d4437  vmovaps [rsp+0x20], xmm2
000074113b7d443d  vmovaps [rsp+0x30], xmm3
000074113b7d4443  vmovaps [rsp+0x40], xmm4
000074113b7d4449  vmovaps [rsp+0x50], xmm5
000074113b7d444f  vmovaps [rsp+0x60], xmm6
000074113b7d4455  vmovaps [rsp+0x70], xmm7
000074113b7d445b  vmovaps [rsp+0x80], xmm8
000074113b7d4464  vmovaps [rsp+0x90], xmm9
000074113b7d446d  vmovaps [rsp+0xA0], xmm10
000074113b7d4476  vmovaps [rsp+0xB0], xmm11
000074113b7d447f  vmovaps [rsp+0xC0], xmm12
000074113b7d4488  vmovaps [rsp+0xD0], xmm14
000074113b7d4491  vmovaps [rsp+0xE0], xmm15
000074113b7d449a  sub rsp, 0x40
000074113b7d449e  lea rdi, [rsp]
000074113b7d44a2  lea rsi, [rsp+0x10]
000074113b7d44a7  lea rdx, [rsp+0x20]
000074113b7d44ac  lea rcx, [rsp+0x30]
000074113b7d44b1  mov r8d, 0x00
000074113b7d44b7  lea r9, [r15+0x3A8]
000074113b7d44be  movaps [rdi], xmm13
000074113b7d44c2  movaps [rsi], xmm15
000074113b7d44c6  movaps [rdx], xmm14
000074113b7d44ca  movaps [rcx], xmm1
000074113b7d44cd  mov rax, 0x629073062A50
000074113b7d44d7  call rax
000074113b7d44d9  movaps xmm13, [rsp]
000074113b7d44de  add rsp, 0x40
000074113b7d44e2  vmovaps xmm0, [rsp]
000074113b7d44e7  vmovaps xmm1, [rsp+0x10]
000074113b7d44ed  vmovaps xmm2, [rsp+0x20]
000074113b7d44f3  vmovaps xmm3, [rsp+0x30]
000074113b7d44f9  vmovaps xmm4, [rsp+0x40]
000074113b7d44ff  vmovaps xmm5, [rsp+0x50]
000074113b7d4505  vmovaps xmm6, [rsp+0x60]
000074113b7d450b  vmovaps xmm7, [rsp+0x70]
000074113b7d4511  vmovaps xmm8, [rsp+0x80]
000074113b7d451a  vmovaps xmm9, [rsp+0x90]
000074113b7d4523  vmovaps xmm10, [rsp+0xA0]
000074113b7d452c  vmovaps xmm11, [rsp+0xB0]
000074113b7d4535  vmovaps xmm12, [rsp+0xC0]
000074113b7d453e  vmovaps xmm14, [rsp+0xD0]
000074113b7d4547  vmovaps xmm15, [rsp+0xE0]
000074113b7d4550  add rsp, 0xF0
000074113b7d4557  pop r11
000074113b7d4559  pop r10
000074113b7d455b  pop r9
000074113b7d455d  pop r8
000074113b7d455f  pop rsi
000074113b7d4560  pop rdi
000074113b7d4561  pop rdx
000074113b7d4562  pop rcx
000074113b7d4563  pop rax
000074113b7d4564  add rsp, 0x08
000074113b7d4568  jmp 0x000074113B7D34FE
000074113b7d456d  sub rsp, 0x08
000074113b7d4571  push rax
000074113b7d4572  push rcx
000074113b7d4573  push rdx
000074113b7d4574  push rdi
000074113b7d4575  push rsi
000074113b7d4576  push r8
000074113b7d4578  push r9
000074113b7d457a  push r10
000074113b7d457c  push r11
000074113b7d457e  sub rsp, 0xF0
000074113b7d4585  vmovaps [rsp], xmm0
000074113b7d458a  vmovaps [rsp+0x10], xmm1
000074113b7d4590  vmovaps [rsp+0x20], xmm2
000074113b7d4596  vmovaps [rsp+0x30], xmm3
000074113b7d459c  vmovaps [rsp+0x40], xmm4
000074113b7d45a2  vmovaps [rsp+0x50], xmm5
000074113b7d45a8  vmovaps [rsp+0x60], xmm6
000074113b7d45ae  vmovaps [rsp+0x70], xmm7
000074113b7d45b4  vmovaps [rsp+0x80], xmm8
000074113b7d45bd  vmovaps [rsp+0x90], xmm9
000074113b7d45c6  vmovaps [rsp+0xA0], xmm10
000074113b7d45cf  vmovaps [rsp+0xB0], xmm11
000074113b7d45d8  vmovaps [rsp+0xC0], xmm13
000074113b7d45e1  vmovaps [rsp+0xD0], xmm14
000074113b7d45ea  vmovaps [rsp+0xE0], xmm15
000074113b7d45f3  sub rsp, 0x40
000074113b7d45f7  lea rdi, [rsp]
000074113b7d45fb  lea rsi, [rsp+0x10]
000074113b7d4600  lea rdx, [rsp+0x20]
000074113b7d4605  lea rcx, [rsp+0x30]
000074113b7d460a  mov r8d, 0x00
000074113b7d4610  lea r9, [r15+0x3A8]
000074113b7d4617  movaps [rdi], xmm12
000074113b7d461b  movaps [rsi], xmm14
000074113b7d461f  movaps [rdx], xmm2
000074113b7d4622  movaps [rcx], xmm15
000074113b7d4626  mov rax, 0x629073062A50
000074113b7d4630  call rax
000074113b7d4632  movaps xmm12, [rsp]
000074113b7d4637  add rsp, 0x40
000074113b7d463b  vmovaps xmm0, [rsp]
000074113b7d4640  vmovaps xmm1, [rsp+0x10]
000074113b7d4646  vmovaps xmm2, [rsp+0x20]
000074113b7d464c  vmovaps xmm3, [rsp+0x30]
000074113b7d4652  vmovaps xmm4, [rsp+0x40]
000074113b7d4658  vmovaps xmm5, [rsp+0x50]
000074113b7d465e  vmovaps xmm6, [rsp+0x60]
000074113b7d4664  vmovaps xmm7, [rsp+0x70]
000074113b7d466a  vmovaps xmm8, [rsp+0x80]
000074113b7d4673  vmovaps xmm9, [rsp+0x90]
000074113b7d467c  vmovaps xmm10, [rsp+0xA0]
000074113b7d4685  vmovaps xmm11, [rsp+0xB0]
000074113b7d468e  vmovaps xmm13, [rsp+0xC0]
000074113b7d4697  vmovaps xmm14, [rsp+0xD0]
000074113b7d46a0  vmovaps xmm15, [rsp+0xE0]
000074113b7d46a9  add rsp, 0xF0
000074113b7d46b0  pop r11
000074113b7d46b2  pop r10
000074113b7d46b4  pop r9
000074113b7d46b6  pop r8
000074113b7d46b8  pop rsi
000074113b7d46b9  pop rdi
000074113b7d46ba  pop rdx
000074113b7d46bb  pop rcx
000074113b7d46bc  pop rax
000074113b7d46bd  add rsp, 0x08
000074113b7d46c1  jmp 0x000074113B7D3558
000074113b7d46c6  sub rsp, 0x08
000074113b7d46ca  push rax
000074113b7d46cb  push rcx
000074113b7d46cc  push rdx
000074113b7d46cd  push rdi
000074113b7d46ce  push rsi
000074113b7d46cf  push r8
000074113b7d46d1  push r9
000074113b7d46d3  push r10
000074113b7d46d5  push r11
000074113b7d46d7  sub rsp, 0xF0
000074113b7d46de  vmovaps [rsp], xmm0
000074113b7d46e3  vmovaps [rsp+0x10], xmm1
000074113b7d46e9  vmovaps [rsp+0x20], xmm3
000074113b7d46ef  vmovaps [rsp+0x30], xmm4
000074113b7d46f5  vmovaps [rsp+0x40], xmm5
000074113b7d46fb  vmovaps [rsp+0x50], xmm6
000074113b7d4701  vmovaps [rsp+0x60], xmm7
000074113b7d4707  vmovaps [rsp+0x70], xmm8
000074113b7d470d  vmovaps [rsp+0x80], xmm9
000074113b7d4716  vmovaps [rsp+0x90], xmm10
000074113b7d471f  vmovaps [rsp+0xA0], xmm11
000074113b7d4728  vmovaps [rsp+0xB0], xmm12
000074113b7d4731  vmovaps [rsp+0xC0], xmm13
000074113b7d473a  vmovaps [rsp+0xD0], xmm14
000074113b7d4743  vmovaps [rsp+0xE0], xmm15
000074113b7d474c  sub rsp, 0x40
000074113b7d4750  lea rdi, [rsp]
000074113b7d4754  lea rsi, [rsp+0x10]
000074113b7d4759  lea rdx, [rsp+0x20]
000074113b7d475e  lea rcx, [rsp+0x30]
000074113b7d4763  mov r8d, 0x00
000074113b7d4769  lea r9, [r15+0x3A8]
000074113b7d4770  movaps [rdi], xmm2
000074113b7d4773  movaps [rsi], xmm14
000074113b7d4777  movaps [rdx], xmm8
000074113b7d477b  movaps [rcx], xmm5
000074113b7d477e  mov rax, 0x629073062A50
000074113b7d4788  call rax
000074113b7d478a  movaps xmm2, [rsp]
000074113b7d478e  add rsp, 0x40
000074113b7d4792  vmovaps xmm0, [rsp]
000074113b7d4797  vmovaps xmm1, [rsp+0x10]
000074113b7d479d  vmovaps xmm3, [rsp+0x20]
000074113b7d47a3  vmovaps xmm4, [rsp+0x30]
000074113b7d47a9  vmovaps xmm5, [rsp+0x40]
000074113b7d47af  vmovaps xmm6, [rsp+0x50]
000074113b7d47b5  vmovaps xmm7, [rsp+0x60]
000074113b7d47bb  vmovaps xmm8, [rsp+0x70]
000074113b7d47c1  vmovaps xmm9, [rsp+0x80]
000074113b7d47ca  vmovaps xmm10, [rsp+0x90]
000074113b7d47d3  vmovaps xmm11, [rsp+0xA0]
000074113b7d47dc  vmovaps xmm12, [rsp+0xB0]
000074113b7d47e5  vmovaps xmm13, [rsp+0xC0]
000074113b7d47ee  vmovaps xmm14, [rsp+0xD0]
000074113b7d47f7  vmovaps xmm15, [rsp+0xE0]
000074113b7d4800  add rsp, 0xF0
000074113b7d4807  pop r11
000074113b7d4809  pop r10
000074113b7d480b  pop r9
000074113b7d480d  pop r8
000074113b7d480f  pop rsi
000074113b7d4810  pop rdi
000074113b7d4811  pop rdx
000074113b7d4812  pop rcx
000074113b7d4813  pop rax
000074113b7d4814  add rsp, 0x08
000074113b7d4818  jmp 0x000074113B7D360C
000074113b7d481d  sub rsp, 0x08
000074113b7d4821  push rax
000074113b7d4822  push rcx
000074113b7d4823  push rdx
000074113b7d4824  push rdi
000074113b7d4825  push rsi
000074113b7d4826  push r8
000074113b7d4828  push r9
000074113b7d482a  push r10
000074113b7d482c  push r11
000074113b7d482e  sub rsp, 0xF0
000074113b7d4835  vmovaps [rsp], xmm0
000074113b7d483a  vmovaps [rsp+0x10], xmm1
000074113b7d4840  vmovaps [rsp+0x20], xmm2
000074113b7d4846  vmovaps [rsp+0x30], xmm3
000074113b7d484c  vmovaps [rsp+0x40], xmm4
000074113b7d4852  vmovaps [rsp+0x50], xmm6
000074113b7d4858  vmovaps [rsp+0x60], xmm7
000074113b7d485e  vmovaps [rsp+0x70], xmm8
000074113b7d4864  vmovaps [rsp+0x80], xmm9
000074113b7d486d  vmovaps [rsp+0x90], xmm10
000074113b7d4876  vmovaps [rsp+0xA0], xmm11
000074113b7d487f  vmovaps [rsp+0xB0], xmm12
000074113b7d4888  vmovaps [rsp+0xC0], xmm13
000074113b7d4891  vmovaps [rsp+0xD0], xmm14
000074113b7d489a  vmovaps [rsp+0xE0], xmm15
000074113b7d48a3  sub rsp, 0x40
000074113b7d48a7  lea rdi, [rsp]
000074113b7d48ab  lea rsi, [rsp+0x10]
000074113b7d48b0  lea rdx, [rsp+0x20]
000074113b7d48b5  lea rcx, [rsp+0x30]
000074113b7d48ba  mov r8d, 0x00
000074113b7d48c0  lea r9, [r15+0x3A8]
000074113b7d48c7  movaps [rdi], xmm5
000074113b7d48ca  movaps [rsi], xmm14
000074113b7d48ce  movaps [rdx], xmm8
000074113b7d48d2  movaps [rcx], xmm1
000074113b7d48d5  mov rax, 0x629073062A50
000074113b7d48df  call rax
000074113b7d48e1  movaps xmm5, [rsp]
000074113b7d48e5  add rsp, 0x40
000074113b7d48e9  vmovaps xmm0, [rsp]
000074113b7d48ee  vmovaps xmm1, [rsp+0x10]
000074113b7d48f4  vmovaps xmm2, [rsp+0x20]
000074113b7d48fa  vmovaps xmm3, [rsp+0x30]
000074113b7d4900  vmovaps xmm4, [rsp+0x40]
000074113b7d4906  vmovaps xmm6, [rsp+0x50]
000074113b7d490c  vmovaps xmm7, [rsp+0x60]
000074113b7d4912  vmovaps xmm8, [rsp+0x70]
000074113b7d4918  vmovaps xmm9, [rsp+0x80]
000074113b7d4921  vmovaps xmm10, [rsp+0x90]
000074113b7d492a  vmovaps xmm11, [rsp+0xA0]
000074113b7d4933  vmovaps xmm12, [rsp+0xB0]
000074113b7d493c  vmovaps xmm13, [rsp+0xC0]
000074113b7d4945  vmovaps xmm14, [rsp+0xD0]
000074113b7d494e  vmovaps xmm15, [rsp+0xE0]
000074113b7d4957  add rsp, 0xF0
000074113b7d495e  pop r11
000074113b7d4960  pop r10
000074113b7d4962  pop r9
000074113b7d4964  pop r8
000074113b7d4966  pop rsi
000074113b7d4967  pop rdi
000074113b7d4968  pop rdx
000074113b7d4969  pop rcx
000074113b7d496a  pop rax
000074113b7d496b  add rsp, 0x08
000074113b7d496f  jmp 0x000074113B7D3649
000074113b7d4974  sub rsp, 0x08
000074113b7d4978  push rax
000074113b7d4979  push rcx
000074113b7d497a  push rdx
000074113b7d497b  push rdi
000074113b7d497c  push rsi
000074113b7d497d  push r8
000074113b7d497f  push r9
000074113b7d4981  push r10
000074113b7d4983  push r11
000074113b7d4985  sub rsp, 0xF0
000074113b7d498c  vmovaps [rsp], xmm0
000074113b7d4991  vmovaps [rsp+0x10], xmm1
000074113b7d4997  vmovaps [rsp+0x20], xmm2
000074113b7d499d  vmovaps [rsp+0x30], xmm3
000074113b7d49a3  vmovaps [rsp+0x40], xmm4
000074113b7d49a9  vmovaps [rsp+0x50], xmm5
000074113b7d49af  vmovaps [rsp+0x60], xmm6
000074113b7d49b5  vmovaps [rsp+0x70], xmm7
000074113b7d49bb  vmovaps [rsp+0x80], xmm8
000074113b7d49c4  vmovaps [rsp+0x90], xmm9
000074113b7d49cd  vmovaps [rsp+0xA0], xmm10
000074113b7d49d6  vmovaps [rsp+0xB0], xmm11
000074113b7d49df  vmovaps [rsp+0xC0], xmm12
000074113b7d49e8  vmovaps [rsp+0xD0], xmm13
000074113b7d49f1  vmovaps [rsp+0xE0], xmm14
000074113b7d49fa  sub rsp, 0x40
000074113b7d49fe  lea rdi, [rsp]
000074113b7d4a02  lea rsi, [rsp+0x10]
000074113b7d4a07  lea rdx, [rsp+0x20]
000074113b7d4a0c  lea rcx, [rsp+0x30]
000074113b7d4a11  mov r8d, 0x00
000074113b7d4a17  lea r9, [r15+0x3A8]
000074113b7d4a1e  movaps [rdi], xmm15
000074113b7d4a22  movaps [rsi], xmm13
000074113b7d4a26  movaps [rdx], xmm14
000074113b7d4a2a  movaps [rcx], xmm1
000074113b7d4a2d  mov rax, 0x629073062A50
000074113b7d4a37  call rax
000074113b7d4a39  movaps xmm15, [rsp]
000074113b7d4a3e  add rsp, 0x40
000074113b7d4a42  vmovaps xmm0, [rsp]
000074113b7d4a47  vmovaps xmm1, [rsp+0x10]
000074113b7d4a4d  vmovaps xmm2, [rsp+0x20]
000074113b7d4a53  vmovaps xmm3, [rsp+0x30]
000074113b7d4a59  vmovaps xmm4, [rsp+0x40]
000074113b7d4a5f  vmovaps xmm5, [rsp+0x50]
000074113b7d4a65  vmovaps xmm6, [rsp+0x60]
000074113b7d4a6b  vmovaps xmm7, [rsp+0x70]
000074113b7d4a71  vmovaps xmm8, [rsp+0x80]
000074113b7d4a7a  vmovaps xmm9, [rsp+0x90]
000074113b7d4a83  vmovaps xmm10, [rsp+0xA0]
000074113b7d4a8c  vmovaps xmm11, [rsp+0xB0]
000074113b7d4a95  vmovaps xmm12, [rsp+0xC0]
000074113b7d4a9e  vmovaps xmm13, [rsp+0xD0]
000074113b7d4aa7  vmovaps xmm14, [rsp+0xE0]
000074113b7d4ab0  add rsp, 0xF0
000074113b7d4ab7  pop r11
000074113b7d4ab9  pop r10
000074113b7d4abb  pop r9
000074113b7d4abd  pop r8
000074113b7d4abf  pop rsi
000074113b7d4ac0  pop rdi
000074113b7d4ac1  pop rdx
000074113b7d4ac2  pop rcx
000074113b7d4ac3  pop rax
000074113b7d4ac4  add rsp, 0x08
000074113b7d4ac8  jmp 0x000074113B7D3678
000074113b7d4acd  sub rsp, 0x08
000074113b7d4ad1  push rax
000074113b7d4ad2  push rcx
000074113b7d4ad3  push rdx
000074113b7d4ad4  push rdi
000074113b7d4ad5  push rsi
000074113b7d4ad6  push r8
000074113b7d4ad8  push r9
000074113b7d4ada  push r10
000074113b7d4adc  push r11
000074113b7d4ade  sub rsp, 0xF0
000074113b7d4ae5  vmovaps [rsp], xmm0
000074113b7d4aea  vmovaps [rsp+0x10], xmm1
000074113b7d4af0  vmovaps [rsp+0x20], xmm2
000074113b7d4af6  vmovaps [rsp+0x30], xmm3
000074113b7d4afc  vmovaps [rsp+0x40], xmm4
000074113b7d4b02  vmovaps [rsp+0x50], xmm5
000074113b7d4b08  vmovaps [rsp+0x60], xmm6
000074113b7d4b0e  vmovaps [rsp+0x70], xmm7
000074113b7d4b14  vmovaps [rsp+0x80], xmm8
000074113b7d4b1d  vmovaps [rsp+0x90], xmm9
000074113b7d4b26  vmovaps [rsp+0xA0], xmm10
000074113b7d4b2f  vmovaps [rsp+0xB0], xmm11
000074113b7d4b38  vmovaps [rsp+0xC0], xmm12
000074113b7d4b41  vmovaps [rsp+0xD0], xmm14
000074113b7d4b4a  vmovaps [rsp+0xE0], xmm15
000074113b7d4b53  sub rsp, 0x40
000074113b7d4b57  lea rdi, [rsp]
000074113b7d4b5b  lea rsi, [rsp+0x10]
000074113b7d4b60  lea rdx, [rsp+0x20]
000074113b7d4b65  lea rcx, [rsp+0x30]
000074113b7d4b6a  mov r8d, 0x00
000074113b7d4b70  lea r9, [r15+0x3A8]
000074113b7d4b77  movaps [rdi], xmm13
000074113b7d4b7b  movaps [rsi], xmm12
000074113b7d4b7f  movaps [rdx], xmm14
000074113b7d4b83  movaps [rcx], xmm1
000074113b7d4b86  mov rax, 0x629073062A50
000074113b7d4b90  call rax
000074113b7d4b92  movaps xmm13, [rsp]
000074113b7d4b97  add rsp, 0x40
000074113b7d4b9b  vmovaps xmm0, [rsp]
000074113b7d4ba0  vmovaps xmm1, [rsp+0x10]
000074113b7d4ba6  vmovaps xmm2, [rsp+0x20]
000074113b7d4bac  vmovaps xmm3, [rsp+0x30]
000074113b7d4bb2  vmovaps xmm4, [rsp+0x40]
000074113b7d4bb8  vmovaps xmm5, [rsp+0x50]
000074113b7d4bbe  vmovaps xmm6, [rsp+0x60]
000074113b7d4bc4  vmovaps xmm7, [rsp+0x70]
000074113b7d4bca  vmovaps xmm8, [rsp+0x80]
000074113b7d4bd3  vmovaps xmm9, [rsp+0x90]
000074113b7d4bdc  vmovaps xmm10, [rsp+0xA0]
000074113b7d4be5  vmovaps xmm11, [rsp+0xB0]
000074113b7d4bee  vmovaps xmm12, [rsp+0xC0]
000074113b7d4bf7  vmovaps xmm14, [rsp+0xD0]
000074113b7d4c00  vmovaps xmm15, [rsp+0xE0]
000074113b7d4c09  add rsp, 0xF0
000074113b7d4c10  pop r11
000074113b7d4c12  pop r10
000074113b7d4c14  pop r9
000074113b7d4c16  pop r8
000074113b7d4c18  pop rsi
000074113b7d4c19  pop rdi
000074113b7d4c1a  pop rdx
000074113b7d4c1b  pop rcx
000074113b7d4c1c  pop rax
000074113b7d4c1d  add rsp, 0x08
000074113b7d4c21  jmp 0x000074113B7D36AA
000074113b7d4c26  sub rsp, 0x08
000074113b7d4c2a  push rax
000074113b7d4c2b  push rcx
000074113b7d4c2c  push rdx
000074113b7d4c2d  push rdi
000074113b7d4c2e  push rsi
000074113b7d4c2f  push r8
000074113b7d4c31  push r9
000074113b7d4c33  push r10
000074113b7d4c35  push r11
000074113b7d4c37  sub rsp, 0xF0
000074113b7d4c3e  vmovaps [rsp], xmm0
000074113b7d4c43  vmovaps [rsp+0x10], xmm1
000074113b7d4c49  vmovaps [rsp+0x20], xmm2
000074113b7d4c4f  vmovaps [rsp+0x30], xmm3
000074113b7d4c55  vmovaps [rsp+0x40], xmm4
000074113b7d4c5b  vmovaps [rsp+0x50], xmm5
000074113b7d4c61  vmovaps [rsp+0x60], xmm6
000074113b7d4c67  vmovaps [rsp+0x70], xmm7
000074113b7d4c6d  vmovaps [rsp+0x80], xmm8
000074113b7d4c76  vmovaps [rsp+0x90], xmm9
000074113b7d4c7f  vmovaps [rsp+0xA0], xmm10
000074113b7d4c88  vmovaps [rsp+0xB0], xmm11
000074113b7d4c91  vmovaps [rsp+0xC0], xmm13
000074113b7d4c9a  vmovaps [rsp+0xD0], xmm14
000074113b7d4ca3  vmovaps [rsp+0xE0], xmm15
000074113b7d4cac  sub rsp, 0x40
000074113b7d4cb0  lea rdi, [rsp]
000074113b7d4cb4  lea rsi, [rsp+0x10]
000074113b7d4cb9  lea rdx, [rsp+0x20]
000074113b7d4cbe  lea rcx, [rsp+0x30]
000074113b7d4cc3  mov r8d, 0x00
000074113b7d4cc9  lea r9, [r15+0x3A8]
000074113b7d4cd0  movaps [rdi], xmm12
000074113b7d4cd4  movaps [rsi], xmm5
000074113b7d4cd7  movaps [rdx], xmm14
000074113b7d4cdb  movaps [rcx], xmm4
000074113b7d4cde  mov rax, 0x629073062A50
000074113b7d4ce8  call rax
000074113b7d4cea  movaps xmm12, [rsp]
000074113b7d4cef  add rsp, 0x40
000074113b7d4cf3  vmovaps xmm0, [rsp]
000074113b7d4cf8  vmovaps xmm1, [rsp+0x10]
000074113b7d4cfe  vmovaps xmm2, [rsp+0x20]
000074113b7d4d04  vmovaps xmm3, [rsp+0x30]
000074113b7d4d0a  vmovaps xmm4, [rsp+0x40]
000074113b7d4d10  vmovaps xmm5, [rsp+0x50]
000074113b7d4d16  vmovaps xmm6, [rsp+0x60]
000074113b7d4d1c  vmovaps xmm7, [rsp+0x70]
000074113b7d4d22  vmovaps xmm8, [rsp+0x80]
000074113b7d4d2b  vmovaps xmm9, [rsp+0x90]
000074113b7d4d34  vmovaps xmm10, [rsp+0xA0]
000074113b7d4d3d  vmovaps xmm11, [rsp+0xB0]
000074113b7d4d46  vmovaps xmm13, [rsp+0xC0]
000074113b7d4d4f  vmovaps xmm14, [rsp+0xD0]
000074113b7d4d58  vmovaps xmm15, [rsp+0xE0]
000074113b7d4d61  add rsp, 0xF0
000074113b7d4d68  pop r11
000074113b7d4d6a  pop r10
000074113b7d4d6c  pop r9
000074113b7d4d6e  pop r8
000074113b7d4d70  pop rsi
000074113b7d4d71  pop rdi
000074113b7d4d72  pop rdx
000074113b7d4d73  pop rcx
000074113b7d4d74  pop rax
000074113b7d4d75  add rsp, 0x08
000074113b7d4d79  jmp 0x000074113B7D3720
000074113b7d4d7e  sub rsp, 0x08
000074113b7d4d82  push rax
000074113b7d4d83  push rcx
000074113b7d4d84  push rdx
000074113b7d4d85  push rdi
000074113b7d4d86  push rsi
000074113b7d4d87  push r8
000074113b7d4d89  push r9
000074113b7d4d8b  push r10
000074113b7d4d8d  push r11
000074113b7d4d8f  sub rsp, 0xF0
000074113b7d4d96  vmovaps [rsp], xmm0
000074113b7d4d9b  vmovaps [rsp+0x10], xmm1
000074113b7d4da1  vmovaps [rsp+0x20], xmm2
000074113b7d4da7  vmovaps [rsp+0x30], xmm3
000074113b7d4dad  vmovaps [rsp+0x40], xmm4
000074113b7d4db3  vmovaps [rsp+0x50], xmm5
000074113b7d4db9  vmovaps [rsp+0x60], xmm6
000074113b7d4dbf  vmovaps [rsp+0x70], xmm7
000074113b7d4dc5  vmovaps [rsp+0x80], xmm8
000074113b7d4dce  vmovaps [rsp+0x90], xmm9
000074113b7d4dd7  vmovaps [rsp+0xA0], xmm11
000074113b7d4de0  vmovaps [rsp+0xB0], xmm12
000074113b7d4de9  vmovaps [rsp+0xC0], xmm13
000074113b7d4df2  vmovaps [rsp+0xD0], xmm14
000074113b7d4dfb  vmovaps [rsp+0xE0], xmm15
000074113b7d4e04  sub rsp, 0x40
000074113b7d4e08  lea rdi, [rsp]
000074113b7d4e0c  lea rsi, [rsp+0x10]
000074113b7d4e11  lea rdx, [rsp+0x20]
000074113b7d4e16  lea rcx, [rsp+0x30]
000074113b7d4e1b  mov r8d, 0x00
000074113b7d4e21  lea r9, [r15+0x3A8]
000074113b7d4e28  movaps [rdi], xmm10
000074113b7d4e2c  movaps [rsi], xmm2
000074113b7d4e2f  movaps [rdx], xmm6
000074113b7d4e32  movaps [rcx], xmm14
000074113b7d4e36  mov rax, 0x629073062A50
000074113b7d4e40  call rax
000074113b7d4e42  movaps xmm10, [rsp]
000074113b7d4e47  add rsp, 0x40
000074113b7d4e4b  vmovaps xmm0, [rsp]
000074113b7d4e50  vmovaps xmm1, [rsp+0x10]
000074113b7d4e56  vmovaps xmm2, [rsp+0x20]
000074113b7d4e5c  vmovaps xmm3, [rsp+0x30]
000074113b7d4e62  vmovaps xmm4, [rsp+0x40]
000074113b7d4e68  vmovaps xmm5, [rsp+0x50]
000074113b7d4e6e  vmovaps xmm6, [rsp+0x60]
000074113b7d4e74  vmovaps xmm7, [rsp+0x70]
000074113b7d4e7a  vmovaps xmm8, [rsp+0x80]
000074113b7d4e83  vmovaps xmm9, [rsp+0x90]
000074113b7d4e8c  vmovaps xmm11, [rsp+0xA0]
000074113b7d4e95  vmovaps xmm12, [rsp+0xB0]
000074113b7d4e9e  vmovaps xmm13, [rsp+0xC0]
000074113b7d4ea7  vmovaps xmm14, [rsp+0xD0]
000074113b7d4eb0  vmovaps xmm15, [rsp+0xE0]
000074113b7d4eb9  add rsp, 0xF0
000074113b7d4ec0  pop r11
000074113b7d4ec2  pop r10
000074113b7d4ec4  pop r9
000074113b7d4ec6  pop r8
000074113b7d4ec8  pop rsi
000074113b7d4ec9  pop rdi
000074113b7d4eca  pop rdx
000074113b7d4ecb  pop rcx
000074113b7d4ecc  pop rax
000074113b7d4ecd  add rsp, 0x08
000074113b7d4ed1  jmp 0x000074113B7D3746
000074113b7d4ed6  call 0x000074113B6E45A0
000074113b7d4edb  jmp 0x000074113B7D3753
000074113b7d4ee0  sub rsp, 0x08
000074113b7d4ee4  push rax
000074113b7d4ee5  push rcx
000074113b7d4ee6  push rdx
000074113b7d4ee7  push rdi
000074113b7d4ee8  push rsi
000074113b7d4ee9  push r8
000074113b7d4eeb  push r9
000074113b7d4eed  push r10
000074113b7d4eef  push r11
000074113b7d4ef1  sub rsp, 0xF0
000074113b7d4ef8  vmovaps [rsp], xmm0
000074113b7d4efd  vmovaps [rsp+0x10], xmm1
000074113b7d4f03  vmovaps [rsp+0x20], xmm2
000074113b7d4f09  vmovaps [rsp+0x30], xmm3
000074113b7d4f0f  vmovaps [rsp+0x40], xmm4
000074113b7d4f15  vmovaps [rsp+0x50], xmm6
000074113b7d4f1b  vmovaps [rsp+0x60], xmm7
000074113b7d4f21  vmovaps [rsp+0x70], xmm8
000074113b7d4f27  vmovaps [rsp+0x80], xmm9
000074113b7d4f30  vmovaps [rsp+0x90], xmm10
000074113b7d4f39  vmovaps [rsp+0xA0], xmm11
000074113b7d4f42  vmovaps [rsp+0xB0], xmm12
000074113b7d4f4b  vmovaps [rsp+0xC0], xmm13
000074113b7d4f54  vmovaps [rsp+0xD0], xmm14
000074113b7d4f5d  vmovaps [rsp+0xE0], xmm15
000074113b7d4f66  sub rsp, 0x40
000074113b7d4f6a  lea rdi, [rsp]
000074113b7d4f6e  lea rsi, [rsp+0x10]
000074113b7d4f73  lea rdx, [rsp+0x20]
000074113b7d4f78  lea rcx, [rsp+0x30]
000074113b7d4f7d  mov r8d, 0x00
000074113b7d4f83  lea r9, [r15+0x3A8]
000074113b7d4f8a  movaps [rdi], xmm5
000074113b7d4f8d  movaps [rsi], xmm15
000074113b7d4f91  movaps [rdx], xmm6
000074113b7d4f94  movaps [rcx], xmm8
000074113b7d4f98  mov rax, 0x629073062A50
000074113b7d4fa2  call rax
000074113b7d4fa4  movaps xmm5, [rsp]
000074113b7d4fa8  add rsp, 0x40
000074113b7d4fac  vmovaps xmm0, [rsp]
000074113b7d4fb1  vmovaps xmm1, [rsp+0x10]
000074113b7d4fb7  vmovaps xmm2, [rsp+0x20]
000074113b7d4fbd  vmovaps xmm3, [rsp+0x30]
000074113b7d4fc3  vmovaps xmm4, [rsp+0x40]
000074113b7d4fc9  vmovaps xmm6, [rsp+0x50]
000074113b7d4fcf  vmovaps xmm7, [rsp+0x60]
000074113b7d4fd5  vmovaps xmm8, [rsp+0x70]
000074113b7d4fdb  vmovaps xmm9, [rsp+0x80]
000074113b7d4fe4  vmovaps xmm10, [rsp+0x90]
000074113b7d4fed  vmovaps xmm11, [rsp+0xA0]
000074113b7d4ff6  vmovaps xmm12, [rsp+0xB0]
000074113b7d4fff  vmovaps xmm13, [rsp+0xC0]
000074113b7d5008  vmovaps xmm14, [rsp+0xD0]
000074113b7d5011  vmovaps xmm15, [rsp+0xE0]
000074113b7d501a  add rsp, 0xF0
000074113b7d5021  pop r11
000074113b7d5023  pop r10
000074113b7d5025  pop r9
000074113b7d5027  pop r8
000074113b7d5029  pop rsi
000074113b7d502a  pop rdi
000074113b7d502b  pop rdx
000074113b7d502c  pop rcx
000074113b7d502d  pop rax
000074113b7d502e  add rsp, 0x08
000074113b7d5032  jmp 0x000074113B7D3789
000074113b7d5037  sub rsp, 0x08
000074113b7d503b  push rax
000074113b7d503c  push rcx
000074113b7d503d  push rdx
000074113b7d503e  push rdi
000074113b7d503f  push rsi
000074113b7d5040  push r8
000074113b7d5042  push r9
000074113b7d5044  push r10
000074113b7d5046  push r11
000074113b7d5048  sub rsp, 0xF0
000074113b7d504f  vmovaps [rsp], xmm0
000074113b7d5054  vmovaps [rsp+0x10], xmm1
000074113b7d505a  vmovaps [rsp+0x20], xmm2
000074113b7d5060  vmovaps [rsp+0x30], xmm3
000074113b7d5066  vmovaps [rsp+0x40], xmm4
000074113b7d506c  vmovaps [rsp+0x50], xmm5
000074113b7d5072  vmovaps [rsp+0x60], xmm6
000074113b7d5078  vmovaps [rsp+0x70], xmm7
000074113b7d507e  vmovaps [rsp+0x80], xmm9
000074113b7d5087  vmovaps [rsp+0x90], xmm10
000074113b7d5090  vmovaps [rsp+0xA0], xmm11
000074113b7d5099  vmovaps [rsp+0xB0], xmm12
000074113b7d50a2  vmovaps [rsp+0xC0], xmm13
000074113b7d50ab  vmovaps [rsp+0xD0], xmm14
000074113b7d50b4  vmovaps [rsp+0xE0], xmm15
000074113b7d50bd  sub rsp, 0x40
000074113b7d50c1  lea rdi, [rsp]
000074113b7d50c5  lea rsi, [rsp+0x10]
000074113b7d50ca  lea rdx, [rsp+0x20]
000074113b7d50cf  lea rcx, [rsp+0x30]
000074113b7d50d4  mov r8d, 0x00
000074113b7d50da  lea r9, [r15+0x3A8]
000074113b7d50e1  movaps [rdi], xmm8
000074113b7d50e5  movaps [rsi], xmm13
000074113b7d50e9  movaps [rdx], xmm1
000074113b7d50ec  movaps [rcx], xmm15
000074113b7d50f0  mov rax, 0x629073062A50
000074113b7d50fa  call rax
000074113b7d50fc  movaps xmm8, [rsp]
000074113b7d5101  add rsp, 0x40
000074113b7d5105  vmovaps xmm0, [rsp]
000074113b7d510a  vmovaps xmm1, [rsp+0x10]
000074113b7d5110  vmovaps xmm2, [rsp+0x20]
000074113b7d5116  vmovaps xmm3, [rsp+0x30]
000074113b7d511c  vmovaps xmm4, [rsp+0x40]
000074113b7d5122  vmovaps xmm5, [rsp+0x50]
000074113b7d5128  vmovaps xmm6, [rsp+0x60]
000074113b7d512e  vmovaps xmm7, [rsp+0x70]
000074113b7d5134  vmovaps xmm9, [rsp+0x80]
000074113b7d513d  vmovaps xmm10, [rsp+0x90]
000074113b7d5146  vmovaps xmm11, [rsp+0xA0]
000074113b7d514f  vmovaps xmm12, [rsp+0xB0]
000074113b7d5158  vmovaps xmm13, [rsp+0xC0]
000074113b7d5161  vmovaps xmm14, [rsp+0xD0]
000074113b7d516a  vmovaps xmm15, [rsp+0xE0]
000074113b7d5173  add rsp, 0xF0
000074113b7d517a  pop r11
000074113b7d517c  pop r10
000074113b7d517e  pop r9
000074113b7d5180  pop r8
000074113b7d5182  pop rsi
000074113b7d5183  pop rdi
000074113b7d5184  pop rdx
000074113b7d5185  pop rcx
000074113b7d5186  pop rax
000074113b7d5187  add rsp, 0x08
000074113b7d518b  jmp 0x000074113B7D37AF
000074113b7d5190  call 0x000074113B6E5820
000074113b7d5195  jmp 0x000074113B7D37D2
000074113b7d519a  call 0x000074113B6E3320
000074113b7d519f  jmp 0x000074113B7D37DC
000074113b7d51a4  sub rsp, 0x08
000074113b7d51a8  push rax
000074113b7d51a9  push rcx
000074113b7d51aa  push rdx
000074113b7d51ab  push rdi
000074113b7d51ac  push rsi
000074113b7d51ad  push r8
000074113b7d51af  push r9
000074113b7d51b1  push r10
000074113b7d51b3  push r11
000074113b7d51b5  sub rsp, 0xF0
000074113b7d51bc  vmovaps [rsp], xmm0
000074113b7d51c1  vmovaps [rsp+0x10], xmm1
000074113b7d51c7  vmovaps [rsp+0x20], xmm2
000074113b7d51cd  vmovaps [rsp+0x30], xmm3
000074113b7d51d3  vmovaps [rsp+0x40], xmm5
000074113b7d51d9  vmovaps [rsp+0x50], xmm6
000074113b7d51df  vmovaps [rsp+0x60], xmm7
000074113b7d51e5  vmovaps [rsp+0x70], xmm8
000074113b7d51eb  vmovaps [rsp+0x80], xmm9
000074113b7d51f4  vmovaps [rsp+0x90], xmm10
000074113b7d51fd  vmovaps [rsp+0xA0], xmm11
000074113b7d5206  vmovaps [rsp+0xB0], xmm12
000074113b7d520f  vmovaps [rsp+0xC0], xmm13
000074113b7d5218  vmovaps [rsp+0xD0], xmm14
000074113b7d5221  vmovaps [rsp+0xE0], xmm15
000074113b7d522a  sub rsp, 0x40
000074113b7d522e  lea rdi, [rsp]
000074113b7d5232  lea rsi, [rsp+0x10]
000074113b7d5237  lea rdx, [rsp+0x20]
000074113b7d523c  lea rcx, [rsp+0x30]
000074113b7d5241  mov r8d, 0x00
000074113b7d5247  lea r9, [r15+0x3A8]
000074113b7d524e  movaps [rdi], xmm4
000074113b7d5251  movaps [rsi], xmm12
000074113b7d5255  movaps [rdx], xmm9
000074113b7d5259  movaps [rcx], xmm6
000074113b7d525c  mov rax, 0x629073062A50
000074113b7d5266  call rax
000074113b7d5268  movaps xmm4, [rsp]
000074113b7d526c  add rsp, 0x40
000074113b7d5270  vmovaps xmm0, [rsp]
000074113b7d5275  vmovaps xmm1, [rsp+0x10]
000074113b7d527b  vmovaps xmm2, [rsp+0x20]
000074113b7d5281  vmovaps xmm3, [rsp+0x30]
000074113b7d5287  vmovaps xmm5, [rsp+0x40]
000074113b7d528d  vmovaps xmm6, [rsp+0x50]
000074113b7d5293  vmovaps xmm7, [rsp+0x60]
000074113b7d5299  vmovaps xmm8, [rsp+0x70]
000074113b7d529f  vmovaps xmm9, [rsp+0x80]
000074113b7d52a8  vmovaps xmm10, [rsp+0x90]
000074113b7d52b1  vmovaps xmm11, [rsp+0xA0]
000074113b7d52ba  vmovaps xmm12, [rsp+0xB0]
000074113b7d52c3  vmovaps xmm13, [rsp+0xC0]
000074113b7d52cc  vmovaps xmm14, [rsp+0xD0]
000074113b7d52d5  vmovaps xmm15, [rsp+0xE0]
000074113b7d52de  add rsp, 0xF0
000074113b7d52e5  pop r11
000074113b7d52e7  pop r10
000074113b7d52e9  pop r9
000074113b7d52eb  pop r8
000074113b7d52ed  pop rsi
000074113b7d52ee  pop rdi
000074113b7d52ef  pop rdx
000074113b7d52f0  pop rcx
000074113b7d52f1  pop rax
000074113b7d52f2  add rsp, 0x08
000074113b7d52f6  jmp 0x000074113B7D3814
000074113b7d52fb  sub rsp, 0x08
000074113b7d52ff  push rax
000074113b7d5300  push rcx
000074113b7d5301  push rdx
000074113b7d5302  push rdi
000074113b7d5303  push rsi
000074113b7d5304  push r8
000074113b7d5306  push r9
000074113b7d5308  push r10
000074113b7d530a  push r11
000074113b7d530c  sub rsp, 0xF0
000074113b7d5313  vmovaps [rsp], xmm0
000074113b7d5318  vmovaps [rsp+0x10], xmm1
000074113b7d531e  vmovaps [rsp+0x20], xmm2
000074113b7d5324  vmovaps [rsp+0x30], xmm3
000074113b7d532a  vmovaps [rsp+0x40], xmm4
000074113b7d5330  vmovaps [rsp+0x50], xmm5
000074113b7d5336  vmovaps [rsp+0x60], xmm6
000074113b7d533c  vmovaps [rsp+0x70], xmm7
000074113b7d5342  vmovaps [rsp+0x80], xmm8
000074113b7d534b  vmovaps [rsp+0x90], xmm10
000074113b7d5354  vmovaps [rsp+0xA0], xmm11
000074113b7d535d  vmovaps [rsp+0xB0], xmm12
000074113b7d5366  vmovaps [rsp+0xC0], xmm13
000074113b7d536f  vmovaps [rsp+0xD0], xmm14
000074113b7d5378  vmovaps [rsp+0xE0], xmm15
000074113b7d5381  sub rsp, 0x40
000074113b7d5385  lea rdi, [rsp]
000074113b7d5389  lea rsi, [rsp+0x10]
000074113b7d538e  lea rdx, [rsp+0x20]
000074113b7d5393  lea rcx, [rsp+0x30]
000074113b7d5398  mov r8d, 0x00
000074113b7d539e  lea r9, [r15+0x3A8]
000074113b7d53a5  movaps [rdi], xmm9
000074113b7d53a9  movaps [rsi], xmm10
000074113b7d53ad  movaps [rdx], xmm1
000074113b7d53b0  movaps [rcx], xmm12
000074113b7d53b4  mov rax, 0x629073062A50
000074113b7d53be  call rax
000074113b7d53c0  movaps xmm9, [rsp]
000074113b7d53c5  add rsp, 0x40
000074113b7d53c9  vmovaps xmm0, [rsp]
000074113b7d53ce  vmovaps xmm1, [rsp+0x10]
000074113b7d53d4  vmovaps xmm2, [rsp+0x20]
000074113b7d53da  vmovaps xmm3, [rsp+0x30]
000074113b7d53e0  vmovaps xmm4, [rsp+0x40]
000074113b7d53e6  vmovaps xmm5, [rsp+0x50]
000074113b7d53ec  vmovaps xmm6, [rsp+0x60]
000074113b7d53f2  vmovaps xmm7, [rsp+0x70]
000074113b7d53f8  vmovaps xmm8, [rsp+0x80]
000074113b7d5401  vmovaps xmm10, [rsp+0x90]
000074113b7d540a  vmovaps xmm11, [rsp+0xA0]
000074113b7d5413  vmovaps xmm12, [rsp+0xB0]
000074113b7d541c  vmovaps xmm13, [rsp+0xC0]
000074113b7d5425  vmovaps xmm14, [rsp+0xD0]
000074113b7d542e  vmovaps xmm15, [rsp+0xE0]
000074113b7d5437  add rsp, 0xF0
000074113b7d543e  pop r11
000074113b7d5440  pop r10
000074113b7d5442  pop r9
000074113b7d5444  pop r8
000074113b7d5446  pop rsi
000074113b7d5447  pop rdi
000074113b7d5448  pop rdx
000074113b7d5449  pop rcx
000074113b7d544a  pop rax
000074113b7d544b  add rsp, 0x08
000074113b7d544f  jmp 0x000074113B7D383D
000074113b7d5454  sub rsp, 0x08
000074113b7d5458  push rax
000074113b7d5459  push rcx
000074113b7d545a  push rdx
000074113b7d545b  push rdi
000074113b7d545c  push rsi
000074113b7d545d  push r8
000074113b7d545f  push r9
000074113b7d5461  push r10
000074113b7d5463  push r11
000074113b7d5465  sub rsp, 0xF0
000074113b7d546c  vmovaps [rsp], xmm0
000074113b7d5471  vmovaps [rsp+0x10], xmm1
000074113b7d5477  vmovaps [rsp+0x20], xmm2
000074113b7d547d  vmovaps [rsp+0x30], xmm3
000074113b7d5483  vmovaps [rsp+0x40], xmm4
000074113b7d5489  vmovaps [rsp+0x50], xmm5
000074113b7d548f  vmovaps [rsp+0x60], xmm6
000074113b7d5495  vmovaps [rsp+0x70], xmm7
000074113b7d549b  vmovaps [rsp+0x80], xmm8
000074113b7d54a4  vmovaps [rsp+0x90], xmm9
000074113b7d54ad  vmovaps [rsp+0xA0], xmm11
000074113b7d54b6  vmovaps [rsp+0xB0], xmm12
000074113b7d54bf  vmovaps [rsp+0xC0], xmm13
000074113b7d54c8  vmovaps [rsp+0xD0], xmm14
000074113b7d54d1  vmovaps [rsp+0xE0], xmm15
000074113b7d54da  sub rsp, 0x40
000074113b7d54de  lea rdi, [rsp]
000074113b7d54e2  lea rsi, [rsp+0x10]
000074113b7d54e7  lea rdx, [rsp+0x20]
000074113b7d54ec  lea rcx, [rsp+0x30]
000074113b7d54f1  mov r8d, 0x00
000074113b7d54f7  lea r9, [r15+0x3A8]
000074113b7d54fe  movaps [rdi], xmm10
000074113b7d5502  movaps [rsi], xmm5
000074113b7d5505  movaps [rdx], xmm12
000074113b7d5509  movaps [rcx], xmm1
000074113b7d550c  mov rax, 0x629073062A50
000074113b7d5516  call rax
000074113b7d5518  movaps xmm10, [rsp]
000074113b7d551d  add rsp, 0x40
000074113b7d5521  vmovaps xmm0, [rsp]
000074113b7d5526  vmovaps xmm1, [rsp+0x10]
000074113b7d552c  vmovaps xmm2, [rsp+0x20]
000074113b7d5532  vmovaps xmm3, [rsp+0x30]
000074113b7d5538  vmovaps xmm4, [rsp+0x40]
000074113b7d553e  vmovaps xmm5, [rsp+0x50]
000074113b7d5544  vmovaps xmm6, [rsp+0x60]
000074113b7d554a  vmovaps xmm7, [rsp+0x70]
000074113b7d5550  vmovaps xmm8, [rsp+0x80]
000074113b7d5559  vmovaps xmm9, [rsp+0x90]
000074113b7d5562  vmovaps xmm11, [rsp+0xA0]
000074113b7d556b  vmovaps xmm12, [rsp+0xB0]
000074113b7d5574  vmovaps xmm13, [rsp+0xC0]
000074113b7d557d  vmovaps xmm14, [rsp+0xD0]
000074113b7d5586  vmovaps xmm15, [rsp+0xE0]
000074113b7d558f  add rsp, 0xF0
000074113b7d5596  pop r11
000074113b7d5598  pop r10
000074113b7d559a  pop r9
000074113b7d559c  pop r8
000074113b7d559e  pop rsi
000074113b7d559f  pop rdi
000074113b7d55a0  pop rdx
000074113b7d55a1  pop rcx
000074113b7d55a2  pop rax
000074113b7d55a3  add rsp, 0x08
000074113b7d55a7  jmp 0x000074113B7D386C
000074113b7d55ac  sub rsp, 0x08
000074113b7d55b0  push rax
000074113b7d55b1  push rcx
000074113b7d55b2  push rdx
000074113b7d55b3  push rdi
000074113b7d55b4  push rsi
000074113b7d55b5  push r8
000074113b7d55b7  push r9
000074113b7d55b9  push r10
000074113b7d55bb  push r11
000074113b7d55bd  sub rsp, 0xF0
000074113b7d55c4  vmovaps [rsp], xmm0
000074113b7d55c9  vmovaps [rsp+0x10], xmm1
000074113b7d55cf  vmovaps [rsp+0x20], xmm2
000074113b7d55d5  vmovaps [rsp+0x30], xmm3
000074113b7d55db  vmovaps [rsp+0x40], xmm4
000074113b7d55e1  vmovaps [rsp+0x50], xmm5
000074113b7d55e7  vmovaps [rsp+0x60], xmm7
000074113b7d55ed  vmovaps [rsp+0x70], xmm8
000074113b7d55f3  vmovaps [rsp+0x80], xmm9
000074113b7d55fc  vmovaps [rsp+0x90], xmm10
000074113b7d5605  vmovaps [rsp+0xA0], xmm11
000074113b7d560e  vmovaps [rsp+0xB0], xmm12
000074113b7d5617  vmovaps [rsp+0xC0], xmm13
000074113b7d5620  vmovaps [rsp+0xD0], xmm14
000074113b7d5629  vmovaps [rsp+0xE0], xmm15
000074113b7d5632  sub rsp, 0x40
000074113b7d5636  lea rdi, [rsp]
000074113b7d563a  lea rsi, [rsp+0x10]
000074113b7d563f  lea rdx, [rsp+0x20]
000074113b7d5644  lea rcx, [rsp+0x30]
000074113b7d5649  mov r8d, 0x00
000074113b7d564f  lea r9, [r15+0x3A8]
000074113b7d5656  movaps [rdi], xmm6
000074113b7d5659  movaps [rsi], xmm8
000074113b7d565d  movaps [rdx], xmm12
000074113b7d5661  movaps [rcx], xmm1
000074113b7d5664  mov rax, 0x629073062A50
000074113b7d566e  call rax
000074113b7d5670  movaps xmm6, [rsp]
000074113b7d5674  add rsp, 0x40
000074113b7d5678  vmovaps xmm0, [rsp]
000074113b7d567d  vmovaps xmm1, [rsp+0x10]
000074113b7d5683  vmovaps xmm2, [rsp+0x20]
000074113b7d5689  vmovaps xmm3, [rsp+0x30]
000074113b7d568f  vmovaps xmm4, [rsp+0x40]
000074113b7d5695  vmovaps xmm5, [rsp+0x50]
000074113b7d569b  vmovaps xmm7, [rsp+0x60]
000074113b7d56a1  vmovaps xmm8, [rsp+0x70]
000074113b7d56a7  vmovaps xmm9, [rsp+0x80]
000074113b7d56b0  vmovaps xmm10, [rsp+0x90]
000074113b7d56b9  vmovaps xmm11, [rsp+0xA0]
000074113b7d56c2  vmovaps xmm12, [rsp+0xB0]
000074113b7d56cb  vmovaps xmm13, [rsp+0xC0]
000074113b7d56d4  vmovaps xmm14, [rsp+0xD0]
000074113b7d56dd  vmovaps xmm15, [rsp+0xE0]
000074113b7d56e6  add rsp, 0xF0
000074113b7d56ed  pop r11
000074113b7d56ef  pop r10
000074113b7d56f1  pop r9
000074113b7d56f3  pop r8
000074113b7d56f5  pop rsi
000074113b7d56f6  pop rdi
000074113b7d56f7  pop rdx
000074113b7d56f8  pop rcx
000074113b7d56f9  pop rax
000074113b7d56fa  add rsp, 0x08
000074113b7d56fe  jmp 0x000074113B7D389A
000074113b7d5703  call 0x000074113B6D64F0
000074113b7d5708  jmp 0x000074113B7D38A4
000074113b7d570d  call 0x000074113B6E20A0
000074113b7d5712  jmp 0x000074113B7D38AE
000074113b7d5717  sub rsp, 0x08
000074113b7d571b  push rax
000074113b7d571c  push rcx
000074113b7d571d  push rdx
000074113b7d571e  push rdi
000074113b7d571f  push rsi
000074113b7d5720  push r8
000074113b7d5722  push r9
000074113b7d5724  push r10
000074113b7d5726  push r11
000074113b7d5728  sub rsp, 0xF0
000074113b7d572f  vmovaps [rsp], xmm0
000074113b7d5734  vmovaps [rsp+0x10], xmm1
000074113b7d573a  vmovaps [rsp+0x20], xmm2
000074113b7d5740  vmovaps [rsp+0x30], xmm3
000074113b7d5746  vmovaps [rsp+0x40], xmm4
000074113b7d574c  vmovaps [rsp+0x50], xmm5
000074113b7d5752  vmovaps [rsp+0x60], xmm6
000074113b7d5758  vmovaps [rsp+0x70], xmm7
000074113b7d575e  vmovaps [rsp+0x80], xmm9
000074113b7d5767  vmovaps [rsp+0x90], xmm10
000074113b7d5770  vmovaps [rsp+0xA0], xmm11
000074113b7d5779  vmovaps [rsp+0xB0], xmm12
000074113b7d5782  vmovaps [rsp+0xC0], xmm13
000074113b7d578b  vmovaps [rsp+0xD0], xmm14
000074113b7d5794  vmovaps [rsp+0xE0], xmm15
000074113b7d579d  sub rsp, 0x40
000074113b7d57a1  lea rdi, [rsp]
000074113b7d57a5  lea rsi, [rsp+0x10]
000074113b7d57aa  lea rdx, [rsp+0x20]
000074113b7d57af  lea rcx, [rsp+0x30]
000074113b7d57b4  mov r8d, 0x00
000074113b7d57ba  lea r9, [r15+0x3A8]
000074113b7d57c1  movaps [rdi], xmm8
000074113b7d57c5  movaps [rsi], xmm4
000074113b7d57c8  movaps [rdx], xmm13
000074113b7d57cc  movaps [rcx], xmm11
000074113b7d57d0  mov rax, 0x629073062A50
000074113b7d57da  call rax
000074113b7d57dc  movaps xmm8, [rsp]
000074113b7d57e1  add rsp, 0x40
000074113b7d57e5  vmovaps xmm0, [rsp]
000074113b7d57ea  vmovaps xmm1, [rsp+0x10]
000074113b7d57f0  vmovaps xmm2, [rsp+0x20]
000074113b7d57f6  vmovaps xmm3, [rsp+0x30]
000074113b7d57fc  vmovaps xmm4, [rsp+0x40]
000074113b7d5802  vmovaps xmm5, [rsp+0x50]
000074113b7d5808  vmovaps xmm6, [rsp+0x60]
000074113b7d580e  vmovaps xmm7, [rsp+0x70]
000074113b7d5814  vmovaps xmm9, [rsp+0x80]
000074113b7d581d  vmovaps xmm10, [rsp+0x90]
000074113b7d5826  vmovaps xmm11, [rsp+0xA0]
000074113b7d582f  vmovaps xmm12, [rsp+0xB0]
000074113b7d5838  vmovaps xmm13, [rsp+0xC0]
000074113b7d5841  vmovaps xmm14, [rsp+0xD0]
000074113b7d584a  vmovaps xmm15, [rsp+0xE0]
000074113b7d5853  add rsp, 0xF0
000074113b7d585a  pop r11
000074113b7d585c  pop r10
000074113b7d585e  pop r9
000074113b7d5860  pop r8
000074113b7d5862  pop rsi
000074113b7d5863  pop rdi
000074113b7d5864  pop rdx
000074113b7d5865  pop rcx
000074113b7d5866  pop rax
000074113b7d5867  add rsp, 0x08
000074113b7d586b  jmp 0x000074113B7D38E4
000074113b7d5870  sub rsp, 0x08
000074113b7d5874  push rax
000074113b7d5875  push rcx
000074113b7d5876  push rdx
000074113b7d5877  push rdi
000074113b7d5878  push rsi
000074113b7d5879  push r8
000074113b7d587b  push r9
000074113b7d587d  push r10
000074113b7d587f  push r11
000074113b7d5881  sub rsp, 0xF0
000074113b7d5888  vmovaps [rsp], xmm0
000074113b7d588d  vmovaps [rsp+0x10], xmm1
000074113b7d5893  vmovaps [rsp+0x20], xmm2
000074113b7d5899  vmovaps [rsp+0x30], xmm3
000074113b7d589f  vmovaps [rsp+0x40], xmm4
000074113b7d58a5  vmovaps [rsp+0x50], xmm5
000074113b7d58ab  vmovaps [rsp+0x60], xmm6
000074113b7d58b1  vmovaps [rsp+0x70], xmm7
000074113b7d58b7  vmovaps [rsp+0x80], xmm8
000074113b7d58c0  vmovaps [rsp+0x90], xmm9
000074113b7d58c9  vmovaps [rsp+0xA0], xmm10
000074113b7d58d2  vmovaps [rsp+0xB0], xmm12
000074113b7d58db  vmovaps [rsp+0xC0], xmm13
000074113b7d58e4  vmovaps [rsp+0xD0], xmm14
000074113b7d58ed  vmovaps [rsp+0xE0], xmm15
000074113b7d58f6  sub rsp, 0x40
000074113b7d58fa  lea rdi, [rsp]
000074113b7d58fe  lea rsi, [rsp+0x10]
000074113b7d5903  lea rdx, [rsp+0x20]
000074113b7d5908  lea rcx, [rsp+0x30]
000074113b7d590d  mov r8d, 0x00
000074113b7d5913  lea r9, [r15+0x3A8]
000074113b7d591a  movaps [rdi], xmm11
000074113b7d591e  movaps [rsi], xmm9
000074113b7d5922  movaps [rdx], xmm1
000074113b7d5925  movaps [rcx], xmm13
000074113b7d5929  mov rax, 0x629073062A50
000074113b7d5933  call rax
000074113b7d5935  movaps xmm11, [rsp]
000074113b7d593a  add rsp, 0x40
000074113b7d593e  vmovaps xmm0, [rsp]
000074113b7d5943  vmovaps xmm1, [rsp+0x10]
000074113b7d5949  vmovaps xmm2, [rsp+0x20]
000074113b7d594f  vmovaps xmm3, [rsp+0x30]
000074113b7d5955  vmovaps xmm4, [rsp+0x40]
000074113b7d595b  vmovaps xmm5, [rsp+0x50]
000074113b7d5961  vmovaps xmm6, [rsp+0x60]
000074113b7d5967  vmovaps xmm7, [rsp+0x70]
000074113b7d596d  vmovaps xmm8, [rsp+0x80]
000074113b7d5976  vmovaps xmm9, [rsp+0x90]
000074113b7d597f  vmovaps xmm10, [rsp+0xA0]
000074113b7d5988  vmovaps xmm12, [rsp+0xB0]
000074113b7d5991  vmovaps xmm13, [rsp+0xC0]
000074113b7d599a  vmovaps xmm14, [rsp+0xD0]
000074113b7d59a3  vmovaps xmm15, [rsp+0xE0]
000074113b7d59ac  add rsp, 0xF0
000074113b7d59b3  pop r11
000074113b7d59b5  pop r10
000074113b7d59b7  pop r9
000074113b7d59b9  pop r8
000074113b7d59bb  pop rsi
000074113b7d59bc  pop rdi
000074113b7d59bd  pop rdx
000074113b7d59be  pop rcx
000074113b7d59bf  pop rax
000074113b7d59c0  add rsp, 0x08
000074113b7d59c4  jmp 0x000074113B7D390A
000074113b7d59c9  sub rsp, 0x08
000074113b7d59cd  push rax
000074113b7d59ce  push rcx
000074113b7d59cf  push rdx
000074113b7d59d0  push rdi
000074113b7d59d1  push rsi
000074113b7d59d2  push r8
000074113b7d59d4  push r9
000074113b7d59d6  push r10
000074113b7d59d8  push r11
000074113b7d59da  sub rsp, 0xF0
000074113b7d59e1  vmovaps [rsp], xmm0
000074113b7d59e6  vmovaps [rsp+0x10], xmm1
000074113b7d59ec  vmovaps [rsp+0x20], xmm2
000074113b7d59f2  vmovaps [rsp+0x30], xmm3
000074113b7d59f8  vmovaps [rsp+0x40], xmm4
000074113b7d59fe  vmovaps [rsp+0x50], xmm5
000074113b7d5a04  vmovaps [rsp+0x60], xmm6
000074113b7d5a0a  vmovaps [rsp+0x70], xmm7
000074113b7d5a10  vmovaps [rsp+0x80], xmm8
000074113b7d5a19  vmovaps [rsp+0x90], xmm9
000074113b7d5a22  vmovaps [rsp+0xA0], xmm10
000074113b7d5a2b  vmovaps [rsp+0xB0], xmm11
000074113b7d5a34  vmovaps [rsp+0xC0], xmm12
000074113b7d5a3d  vmovaps [rsp+0xD0], xmm14
000074113b7d5a46  vmovaps [rsp+0xE0], xmm15
000074113b7d5a4f  sub rsp, 0x40
000074113b7d5a53  lea rdi, [rsp]
000074113b7d5a57  lea rsi, [rsp+0x10]
000074113b7d5a5c  lea rdx, [rsp+0x20]
000074113b7d5a61  lea rcx, [rsp+0x30]
000074113b7d5a66  mov r8d, 0x00
000074113b7d5a6c  lea r9, [r15+0x3A8]
000074113b7d5a73  movaps [rdi], xmm13
000074113b7d5a77  movaps [rsi], xmm10
000074113b7d5a7b  movaps [rdx], xmm7
000074113b7d5a7e  movaps [rcx], xmm1
000074113b7d5a81  mov rax, 0x629073062A50
000074113b7d5a8b  call rax
000074113b7d5a8d  movaps xmm13, [rsp]
000074113b7d5a92  add rsp, 0x40
000074113b7d5a96  vmovaps xmm0, [rsp]
000074113b7d5a9b  vmovaps xmm1, [rsp+0x10]
000074113b7d5aa1  vmovaps xmm2, [rsp+0x20]
000074113b7d5aa7  vmovaps xmm3, [rsp+0x30]
000074113b7d5aad  vmovaps xmm4, [rsp+0x40]
000074113b7d5ab3  vmovaps xmm5, [rsp+0x50]
000074113b7d5ab9  vmovaps xmm6, [rsp+0x60]
000074113b7d5abf  vmovaps xmm7, [rsp+0x70]
000074113b7d5ac5  vmovaps xmm8, [rsp+0x80]
000074113b7d5ace  vmovaps xmm9, [rsp+0x90]
000074113b7d5ad7  vmovaps xmm10, [rsp+0xA0]
000074113b7d5ae0  vmovaps xmm11, [rsp+0xB0]
000074113b7d5ae9  vmovaps xmm12, [rsp+0xC0]
000074113b7d5af2  vmovaps xmm14, [rsp+0xD0]
000074113b7d5afb  vmovaps xmm15, [rsp+0xE0]
000074113b7d5b04  add rsp, 0xF0
000074113b7d5b0b  pop r11
000074113b7d5b0d  pop r10
000074113b7d5b0f  pop r9
000074113b7d5b11  pop r8
000074113b7d5b13  pop rsi
000074113b7d5b14  pop rdi
000074113b7d5b15  pop rdx
000074113b7d5b16  pop rcx
000074113b7d5b17  pop rax
000074113b7d5b18  add rsp, 0x08
000074113b7d5b1c  jmp 0x000074113B7D3930
000074113b7d5b21  sub rsp, 0x08
000074113b7d5b25  push rax
000074113b7d5b26  push rcx
000074113b7d5b27  push rdx
000074113b7d5b28  push rdi
000074113b7d5b29  push rsi
000074113b7d5b2a  push r8
000074113b7d5b2c  push r9
000074113b7d5b2e  push r10
000074113b7d5b30  push r11
000074113b7d5b32  sub rsp, 0xF0
000074113b7d5b39  vmovaps [rsp], xmm0
000074113b7d5b3e  vmovaps [rsp+0x10], xmm1
000074113b7d5b44  vmovaps [rsp+0x20], xmm2
000074113b7d5b4a  vmovaps [rsp+0x30], xmm3
000074113b7d5b50  vmovaps [rsp+0x40], xmm4
000074113b7d5b56  vmovaps [rsp+0x50], xmm5
000074113b7d5b5c  vmovaps [rsp+0x60], xmm6
000074113b7d5b62  vmovaps [rsp+0x70], xmm7
000074113b7d5b68  vmovaps [rsp+0x80], xmm8
000074113b7d5b71  vmovaps [rsp+0x90], xmm9
000074113b7d5b7a  vmovaps [rsp+0xA0], xmm11
000074113b7d5b83  vmovaps [rsp+0xB0], xmm12
000074113b7d5b8c  vmovaps [rsp+0xC0], xmm13
000074113b7d5b95  vmovaps [rsp+0xD0], xmm14
000074113b7d5b9e  vmovaps [rsp+0xE0], xmm15
000074113b7d5ba7  sub rsp, 0x40
000074113b7d5bab  lea rdi, [rsp]
000074113b7d5baf  lea rsi, [rsp+0x10]
000074113b7d5bb4  lea rdx, [rsp+0x20]
000074113b7d5bb9  lea rcx, [rsp+0x30]
000074113b7d5bbe  mov r8d, 0x00
000074113b7d5bc4  lea r9, [r15+0x3A8]
000074113b7d5bcb  movaps [rdi], xmm10
000074113b7d5bcf  movaps [rsi], xmm6
000074113b7d5bd2  movaps [rdx], xmm15
000074113b7d5bd6  movaps [rcx], xmm1
000074113b7d5bd9  mov rax, 0x629073062A50
000074113b7d5be3  call rax
000074113b7d5be5  movaps xmm10, [rsp]
000074113b7d5bea  add rsp, 0x40
000074113b7d5bee  vmovaps xmm0, [rsp]
000074113b7d5bf3  vmovaps xmm1, [rsp+0x10]
000074113b7d5bf9  vmovaps xmm2, [rsp+0x20]
000074113b7d5bff  vmovaps xmm3, [rsp+0x30]
000074113b7d5c05  vmovaps xmm4, [rsp+0x40]
000074113b7d5c0b  vmovaps xmm5, [rsp+0x50]
000074113b7d5c11  vmovaps xmm6, [rsp+0x60]
000074113b7d5c17  vmovaps xmm7, [rsp+0x70]
000074113b7d5c1d  vmovaps xmm8, [rsp+0x80]
000074113b7d5c26  vmovaps xmm9, [rsp+0x90]
000074113b7d5c2f  vmovaps xmm11, [rsp+0xA0]
000074113b7d5c38  vmovaps xmm12, [rsp+0xB0]
000074113b7d5c41  vmovaps xmm13, [rsp+0xC0]
000074113b7d5c4a  vmovaps xmm14, [rsp+0xD0]
000074113b7d5c53  vmovaps xmm15, [rsp+0xE0]
000074113b7d5c5c  add rsp, 0xF0
000074113b7d5c63  pop r11
000074113b7d5c65  pop r10
000074113b7d5c67  pop r9
000074113b7d5c69  pop r8
000074113b7d5c6b  pop rsi
000074113b7d5c6c  pop rdi
000074113b7d5c6d  pop rdx
000074113b7d5c6e  pop rcx
000074113b7d5c6f  pop rax
000074113b7d5c70  add rsp, 0x08
000074113b7d5c74  jmp 0x000074113B7D3956
000074113b7d5c79  call 0x000074113B6D64F0
000074113b7d5c7e  jmp 0x000074113B7D3960
000074113b7d5c83  call 0x000074113B6E5820
000074113b7d5c88  jmp 0x000074113B7D396A
000074113b7d5c8d  sub rsp, 0x08
000074113b7d5c91  push rax
000074113b7d5c92  push rcx
000074113b7d5c93  push rdx
000074113b7d5c94  push rdi
000074113b7d5c95  push rsi
000074113b7d5c96  push r8
000074113b7d5c98  push r9
000074113b7d5c9a  push r10
000074113b7d5c9c  push r11
000074113b7d5c9e  sub rsp, 0xF0
000074113b7d5ca5  vmovaps [rsp], xmm0
000074113b7d5caa  vmovaps [rsp+0x10], xmm1
000074113b7d5cb0  vmovaps [rsp+0x20], xmm2
000074113b7d5cb6  vmovaps [rsp+0x30], xmm3
000074113b7d5cbc  vmovaps [rsp+0x40], xmm4
000074113b7d5cc2  vmovaps [rsp+0x50], xmm5
000074113b7d5cc8  vmovaps [rsp+0x60], xmm6
000074113b7d5cce  vmovaps [rsp+0x70], xmm8
000074113b7d5cd4  vmovaps [rsp+0x80], xmm9
000074113b7d5cdd  vmovaps [rsp+0x90], xmm10
000074113b7d5ce6  vmovaps [rsp+0xA0], xmm11
000074113b7d5cef  vmovaps [rsp+0xB0], xmm12
000074113b7d5cf8  vmovaps [rsp+0xC0], xmm13
000074113b7d5d01  vmovaps [rsp+0xD0], xmm14
000074113b7d5d0a  vmovaps [rsp+0xE0], xmm15
000074113b7d5d13  sub rsp, 0x40
000074113b7d5d17  lea rdi, [rsp]
000074113b7d5d1b  lea rsi, [rsp+0x10]
000074113b7d5d20  lea rdx, [rsp+0x20]
000074113b7d5d25  lea rcx, [rsp+0x30]
000074113b7d5d2a  mov r8d, 0x00
000074113b7d5d30  lea r9, [r15+0x3A8]
000074113b7d5d37  movaps [rdi], xmm7
000074113b7d5d3a  movaps [rsi], xmm8
000074113b7d5d3e  movaps [rdx], xmm3
000074113b7d5d41  movaps [rcx], xmm9
000074113b7d5d45  mov rax, 0x629073062A50
000074113b7d5d4f  call rax
000074113b7d5d51  movaps xmm7, [rsp]
000074113b7d5d55  add rsp, 0x40
000074113b7d5d59  vmovaps xmm0, [rsp]
000074113b7d5d5e  vmovaps xmm1, [rsp+0x10]
000074113b7d5d64  vmovaps xmm2, [rsp+0x20]
000074113b7d5d6a  vmovaps xmm3, [rsp+0x30]
000074113b7d5d70  vmovaps xmm4, [rsp+0x40]
000074113b7d5d76  vmovaps xmm5, [rsp+0x50]
000074113b7d5d7c  vmovaps xmm6, [rsp+0x60]
000074113b7d5d82  vmovaps xmm8, [rsp+0x70]
000074113b7d5d88  vmovaps xmm9, [rsp+0x80]
000074113b7d5d91  vmovaps xmm10, [rsp+0x90]
000074113b7d5d9a  vmovaps xmm11, [rsp+0xA0]
000074113b7d5da3  vmovaps xmm12, [rsp+0xB0]
000074113b7d5dac  vmovaps xmm13, [rsp+0xC0]
000074113b7d5db5  vmovaps xmm14, [rsp+0xD0]
000074113b7d5dbe  vmovaps xmm15, [rsp+0xE0]
000074113b7d5dc7  add rsp, 0xF0
000074113b7d5dce  pop r11
000074113b7d5dd0  pop r10
000074113b7d5dd2  pop r9
000074113b7d5dd4  pop r8
000074113b7d5dd6  pop rsi
000074113b7d5dd7  pop rdi
000074113b7d5dd8  pop rdx
000074113b7d5dd9  pop rcx
000074113b7d5dda  pop rax
000074113b7d5ddb  add rsp, 0x08
000074113b7d5ddf  jmp 0x000074113B7D3992
000074113b7d5de4  sub rsp, 0x08
000074113b7d5de8  push rax
000074113b7d5de9  push rcx
000074113b7d5dea  push rdx
000074113b7d5deb  push rdi
000074113b7d5dec  push rsi
000074113b7d5ded  push r8
000074113b7d5def  push r9
000074113b7d5df1  push r10
000074113b7d5df3  push r11
000074113b7d5df5  sub rsp, 0xF0
000074113b7d5dfc  vmovaps [rsp], xmm0
000074113b7d5e01  vmovaps [rsp+0x10], xmm1
000074113b7d5e07  vmovaps [rsp+0x20], xmm2
000074113b7d5e0d  vmovaps [rsp+0x30], xmm3
000074113b7d5e13  vmovaps [rsp+0x40], xmm4
000074113b7d5e19  vmovaps [rsp+0x50], xmm5
000074113b7d5e1f  vmovaps [rsp+0x60], xmm6
000074113b7d5e25  vmovaps [rsp+0x70], xmm7
000074113b7d5e2b  vmovaps [rsp+0x80], xmm9
000074113b7d5e34  vmovaps [rsp+0x90], xmm10
000074113b7d5e3d  vmovaps [rsp+0xA0], xmm11
000074113b7d5e46  vmovaps [rsp+0xB0], xmm12
000074113b7d5e4f  vmovaps [rsp+0xC0], xmm13
000074113b7d5e58  vmovaps [rsp+0xD0], xmm14
000074113b7d5e61  vmovaps [rsp+0xE0], xmm15
000074113b7d5e6a  sub rsp, 0x40
000074113b7d5e6e  lea rdi, [rsp]
000074113b7d5e72  lea rsi, [rsp+0x10]
000074113b7d5e77  lea rdx, [rsp+0x20]
000074113b7d5e7c  lea rcx, [rsp+0x30]
000074113b7d5e81  mov r8d, 0x00
000074113b7d5e87  lea r9, [r15+0x3A8]
000074113b7d5e8e  movaps [rdi], xmm8
000074113b7d5e92  movaps [rsi], xmm11
000074113b7d5e96  movaps [rdx], xmm14
000074113b7d5e9a  movaps [rcx], xmm9
000074113b7d5e9e  mov rax, 0x629073062A50
000074113b7d5ea8  call rax
000074113b7d5eaa  movaps xmm8, [rsp]
000074113b7d5eaf  add rsp, 0x40
000074113b7d5eb3  vmovaps xmm0, [rsp]
000074113b7d5eb8  vmovaps xmm1, [rsp+0x10]
000074113b7d5ebe  vmovaps xmm2, [rsp+0x20]
000074113b7d5ec4  vmovaps xmm3, [rsp+0x30]
000074113b7d5eca  vmovaps xmm4, [rsp+0x40]
000074113b7d5ed0  vmovaps xmm5, [rsp+0x50]
000074113b7d5ed6  vmovaps xmm6, [rsp+0x60]
000074113b7d5edc  vmovaps xmm7, [rsp+0x70]
000074113b7d5ee2  vmovaps xmm9, [rsp+0x80]
000074113b7d5eeb  vmovaps xmm10, [rsp+0x90]
000074113b7d5ef4  vmovaps xmm11, [rsp+0xA0]
000074113b7d5efd  vmovaps xmm12, [rsp+0xB0]
000074113b7d5f06  vmovaps xmm13, [rsp+0xC0]
000074113b7d5f0f  vmovaps xmm14, [rsp+0xD0]
000074113b7d5f18  vmovaps xmm15, [rsp+0xE0]
000074113b7d5f21  add rsp, 0xF0
000074113b7d5f28  pop r11
000074113b7d5f2a  pop r10
000074113b7d5f2c  pop r9
000074113b7d5f2e  pop r8
000074113b7d5f30  pop rsi
000074113b7d5f31  pop rdi
000074113b7d5f32  pop rdx
000074113b7d5f33  pop rcx
000074113b7d5f34  pop rax
000074113b7d5f35  add rsp, 0x08
000074113b7d5f39  jmp 0x000074113B7D39BB
000074113b7d5f3e  sub rsp, 0x08
000074113b7d5f42  push rax
000074113b7d5f43  push rcx
000074113b7d5f44  push rdx
000074113b7d5f45  push rdi
000074113b7d5f46  push rsi
000074113b7d5f47  push r8
000074113b7d5f49  push r9
000074113b7d5f4b  push r10
000074113b7d5f4d  push r11
000074113b7d5f4f  sub rsp, 0xF0
000074113b7d5f56  vmovaps [rsp], xmm0
000074113b7d5f5b  vmovaps [rsp+0x10], xmm1
000074113b7d5f61  vmovaps [rsp+0x20], xmm2
000074113b7d5f67  vmovaps [rsp+0x30], xmm3
000074113b7d5f6d  vmovaps [rsp+0x40], xmm4
000074113b7d5f73  vmovaps [rsp+0x50], xmm5
000074113b7d5f79  vmovaps [rsp+0x60], xmm6
000074113b7d5f7f  vmovaps [rsp+0x70], xmm7
000074113b7d5f85  vmovaps [rsp+0x80], xmm8
000074113b7d5f8e  vmovaps [rsp+0x90], xmm9
000074113b7d5f97  vmovaps [rsp+0xA0], xmm10
000074113b7d5fa0  vmovaps [rsp+0xB0], xmm12
000074113b7d5fa9  vmovaps [rsp+0xC0], xmm13
000074113b7d5fb2  vmovaps [rsp+0xD0], xmm14
000074113b7d5fbb  vmovaps [rsp+0xE0], xmm15
000074113b7d5fc4  sub rsp, 0x40
000074113b7d5fc8  lea rdi, [rsp]
000074113b7d5fcc  lea rsi, [rsp+0x10]
000074113b7d5fd1  lea rdx, [rsp+0x20]
000074113b7d5fd6  lea rcx, [rsp+0x30]
000074113b7d5fdb  mov r8d, 0x00
000074113b7d5fe1  lea r9, [r15+0x3A8]
000074113b7d5fe8  movaps [rdi], xmm11
000074113b7d5fec  movaps [rsi], xmm13
000074113b7d5ff0  movaps [rdx], xmm12
000074113b7d5ff4  movaps [rcx], xmm14
000074113b7d5ff8  mov rax, 0x629073062A50
000074113b7d6002  call rax
000074113b7d6004  movaps xmm11, [rsp]
000074113b7d6009  add rsp, 0x40
000074113b7d600d  vmovaps xmm0, [rsp]
000074113b7d6012  vmovaps xmm1, [rsp+0x10]
000074113b7d6018  vmovaps xmm2, [rsp+0x20]
000074113b7d601e  vmovaps xmm3, [rsp+0x30]
000074113b7d6024  vmovaps xmm4, [rsp+0x40]
000074113b7d602a  vmovaps xmm5, [rsp+0x50]
000074113b7d6030  vmovaps xmm6, [rsp+0x60]
000074113b7d6036  vmovaps xmm7, [rsp+0x70]
000074113b7d603c  vmovaps xmm8, [rsp+0x80]
000074113b7d6045  vmovaps xmm9, [rsp+0x90]
000074113b7d604e  vmovaps xmm10, [rsp+0xA0]
000074113b7d6057  vmovaps xmm12, [rsp+0xB0]
000074113b7d6060  vmovaps xmm13, [rsp+0xC0]
000074113b7d6069  vmovaps xmm14, [rsp+0xD0]
000074113b7d6072  vmovaps xmm15, [rsp+0xE0]
000074113b7d607b  add rsp, 0xF0
000074113b7d6082  pop r11
000074113b7d6084  pop r10
000074113b7d6086  pop r9
000074113b7d6088  pop r8
000074113b7d608a  pop rsi
000074113b7d608b  pop rdi
000074113b7d608c  pop rdx
000074113b7d608d  pop rcx
000074113b7d608e  pop rax
000074113b7d608f  add rsp, 0x08
000074113b7d6093  jmp 0x000074113B7D39E4
000074113b7d6098  sub rsp, 0x08
000074113b7d609c  push rax
000074113b7d609d  push rcx
000074113b7d609e  push rdx
000074113b7d609f  push rdi
000074113b7d60a0  push rsi
000074113b7d60a1  push r8
000074113b7d60a3  push r9
000074113b7d60a5  push r10
000074113b7d60a7  push r11
000074113b7d60a9  sub rsp, 0xF0
000074113b7d60b0  vmovaps [rsp], xmm0
000074113b7d60b5  vmovaps [rsp+0x10], xmm1
000074113b7d60bb  vmovaps [rsp+0x20], xmm2
000074113b7d60c1  vmovaps [rsp+0x30], xmm3
000074113b7d60c7  vmovaps [rsp+0x40], xmm4
000074113b7d60cd  vmovaps [rsp+0x50], xmm5
000074113b7d60d3  vmovaps [rsp+0x60], xmm6
000074113b7d60d9  vmovaps [rsp+0x70], xmm7
000074113b7d60df  vmovaps [rsp+0x80], xmm8
000074113b7d60e8  vmovaps [rsp+0x90], xmm9
000074113b7d60f1  vmovaps [rsp+0xA0], xmm10
000074113b7d60fa  vmovaps [rsp+0xB0], xmm11
000074113b7d6103  vmovaps [rsp+0xC0], xmm13
000074113b7d610c  vmovaps [rsp+0xD0], xmm14
000074113b7d6115  vmovaps [rsp+0xE0], xmm15
000074113b7d611e  sub rsp, 0x40
000074113b7d6122  lea rdi, [rsp]
000074113b7d6126  lea rsi, [rsp+0x10]
000074113b7d612b  lea rdx, [rsp+0x20]
000074113b7d6130  lea rcx, [rsp+0x30]
000074113b7d6135  mov r8d, 0x00
000074113b7d613b  lea r9, [r15+0x3A8]
000074113b7d6142  movaps [rdi], xmm12
000074113b7d6146  movaps [rsi], xmm10
000074113b7d614a  movaps [rdx], xmm15
000074113b7d614e  movaps [rcx], xmm14
000074113b7d6152  mov rax, 0x629073062A50
000074113b7d615c  call rax
000074113b7d615e  movaps xmm12, [rsp]
000074113b7d6163  add rsp, 0x40
000074113b7d6167  vmovaps xmm0, [rsp]
000074113b7d616c  vmovaps xmm1, [rsp+0x10]
000074113b7d6172  vmovaps xmm2, [rsp+0x20]
000074113b7d6178  vmovaps xmm3, [rsp+0x30]
000074113b7d617e  vmovaps xmm4, [rsp+0x40]
000074113b7d6184  vmovaps xmm5, [rsp+0x50]
000074113b7d618a  vmovaps xmm6, [rsp+0x60]
000074113b7d6190  vmovaps xmm7, [rsp+0x70]
000074113b7d6196  vmovaps xmm8, [rsp+0x80]
000074113b7d619f  vmovaps xmm9, [rsp+0x90]
000074113b7d61a8  vmovaps xmm10, [rsp+0xA0]
000074113b7d61b1  vmovaps xmm11, [rsp+0xB0]
000074113b7d61ba  vmovaps xmm13, [rsp+0xC0]
000074113b7d61c3  vmovaps xmm14, [rsp+0xD0]
000074113b7d61cc  vmovaps xmm15, [rsp+0xE0]
000074113b7d61d5  add rsp, 0xF0
000074113b7d61dc  pop r11
000074113b7d61de  pop r10
000074113b7d61e0  pop r9
000074113b7d61e2  pop r8
000074113b7d61e4  pop rsi
000074113b7d61e5  pop rdi
000074113b7d61e6  pop rdx
000074113b7d61e7  pop rcx
000074113b7d61e8  pop rax
000074113b7d61e9  add rsp, 0x08
000074113b7d61ed  jmp 0x000074113B7D3A0D
000074113b7d61f2  call 0x000074113B6E5820
000074113b7d61f7  jmp 0x000074113B7D3A1A
000074113b7d61fc  call 0x000074113B6E45A0
000074113b7d6201  jmp 0x000074113B7D3A27
000074113b7d6206  sub rsp, 0x08
000074113b7d620a  push rax
000074113b7d620b  push rcx
000074113b7d620c  push rdx
000074113b7d620d  push rdi
000074113b7d620e  push rsi
000074113b7d620f  push r8
000074113b7d6211  push r9
000074113b7d6213  push r10
000074113b7d6215  push r11
000074113b7d6217  sub rsp, 0xF0
000074113b7d621e  vmovaps [rsp], xmm0
000074113b7d6223  vmovaps [rsp+0x10], xmm1
000074113b7d6229  vmovaps [rsp+0x20], xmm2
000074113b7d622f  vmovaps [rsp+0x30], xmm3
000074113b7d6235  vmovaps [rsp+0x40], xmm4
000074113b7d623b  vmovaps [rsp+0x50], xmm5
000074113b7d6241  vmovaps [rsp+0x60], xmm6
000074113b7d6247  vmovaps [rsp+0x70], xmm7
000074113b7d624d  vmovaps [rsp+0x80], xmm8
000074113b7d6256  vmovaps [rsp+0x90], xmm9
000074113b7d625f  vmovaps [rsp+0xA0], xmm11
000074113b7d6268  vmovaps [rsp+0xB0], xmm12
000074113b7d6271  vmovaps [rsp+0xC0], xmm13
000074113b7d627a  vmovaps [rsp+0xD0], xmm14
000074113b7d6283  vmovaps [rsp+0xE0], xmm15
000074113b7d628c  sub rsp, 0x40
000074113b7d6290  lea rdi, [rsp]
000074113b7d6294  lea rsi, [rsp+0x10]
000074113b7d6299  lea rdx, [rsp+0x20]
000074113b7d629e  lea rcx, [rsp+0x30]
000074113b7d62a3  mov r8d, 0x00
000074113b7d62a9  lea r9, [r15+0x3A8]
000074113b7d62b0  movaps [rdi], xmm10
000074113b7d62b4  movaps [rsi], xmm7
000074113b7d62b7  movaps [rdx], xmm1
000074113b7d62ba  movaps [rcx], xmm13
000074113b7d62be  mov rax, 0x629073062A50
000074113b7d62c8  call rax
000074113b7d62ca  movaps xmm10, [rsp]
000074113b7d62cf  add rsp, 0x40
000074113b7d62d3  vmovaps xmm0, [rsp]
000074113b7d62d8  vmovaps xmm1, [rsp+0x10]
000074113b7d62de  vmovaps xmm2, [rsp+0x20]
000074113b7d62e4  vmovaps xmm3, [rsp+0x30]
000074113b7d62ea  vmovaps xmm4, [rsp+0x40]
000074113b7d62f0  vmovaps xmm5, [rsp+0x50]
000074113b7d62f6  vmovaps xmm6, [rsp+0x60]
000074113b7d62fc  vmovaps xmm7, [rsp+0x70]
000074113b7d6302  vmovaps xmm8, [rsp+0x80]
000074113b7d630b  vmovaps xmm9, [rsp+0x90]
000074113b7d6314  vmovaps xmm11, [rsp+0xA0]
000074113b7d631d  vmovaps xmm12, [rsp+0xB0]
000074113b7d6326  vmovaps xmm13, [rsp+0xC0]
000074113b7d632f  vmovaps xmm14, [rsp+0xD0]
000074113b7d6338  vmovaps xmm15, [rsp+0xE0]
000074113b7d6341  add rsp, 0xF0
000074113b7d6348  pop r11
000074113b7d634a  pop r10
000074113b7d634c  pop r9
000074113b7d634e  pop r8
000074113b7d6350  pop rsi
000074113b7d6351  pop rdi
000074113b7d6352  pop rdx
000074113b7d6353  pop rcx
000074113b7d6354  pop rax
000074113b7d6355  add rsp, 0x08
000074113b7d6359  jmp 0x000074113B7D3A5D
000074113b7d635e  call 0x000074113B6D64F0
000074113b7d6363  jmp 0x000074113B7D3A6F
000074113b7d6368  sub rsp, 0x08
000074113b7d636c  push rax
000074113b7d636d  push rcx
000074113b7d636e  push rdx
000074113b7d636f  push rdi
000074113b7d6370  push rsi
000074113b7d6371  push r8
000074113b7d6373  push r9
000074113b7d6375  push r10
000074113b7d6377  push r11
000074113b7d6379  sub rsp, 0xF0
000074113b7d6380  vmovaps [rsp], xmm0
000074113b7d6385  vmovaps [rsp+0x10], xmm1
000074113b7d638b  vmovaps [rsp+0x20], xmm2
000074113b7d6391  vmovaps [rsp+0x30], xmm3
000074113b7d6397  vmovaps [rsp+0x40], xmm4
000074113b7d639d  vmovaps [rsp+0x50], xmm5
000074113b7d63a3  vmovaps [rsp+0x60], xmm6
000074113b7d63a9  vmovaps [rsp+0x70], xmm7
000074113b7d63af  vmovaps [rsp+0x80], xmm8
000074113b7d63b8  vmovaps [rsp+0x90], xmm10
000074113b7d63c1  vmovaps [rsp+0xA0], xmm11
000074113b7d63ca  vmovaps [rsp+0xB0], xmm12
000074113b7d63d3  vmovaps [rsp+0xC0], xmm13
000074113b7d63dc  vmovaps [rsp+0xD0], xmm14
000074113b7d63e5  vmovaps [rsp+0xE0], xmm15
000074113b7d63ee  sub rsp, 0x40
000074113b7d63f2  lea rdi, [rsp]
000074113b7d63f6  lea rsi, [rsp+0x10]
000074113b7d63fb  lea rdx, [rsp+0x20]
000074113b7d6400  lea rcx, [rsp+0x30]
000074113b7d6405  mov r8d, 0x00
000074113b7d640b  lea r9, [r15+0x3A8]
000074113b7d6412  movaps [rdi], xmm9
000074113b7d6416  movaps [rsi], xmm8
000074113b7d641a  movaps [rdx], xmm14
000074113b7d641e  movaps [rcx], xmm13
000074113b7d6422  mov rax, 0x629073062A50
000074113b7d642c  call rax
000074113b7d642e  movaps xmm9, [rsp]
000074113b7d6433  add rsp, 0x40
000074113b7d6437  vmovaps xmm0, [rsp]
000074113b7d643c  vmovaps xmm1, [rsp+0x10]
000074113b7d6442  vmovaps xmm2, [rsp+0x20]
000074113b7d6448  vmovaps xmm3, [rsp+0x30]
000074113b7d644e  vmovaps xmm4, [rsp+0x40]
000074113b7d6454  vmovaps xmm5, [rsp+0x50]
000074113b7d645a  vmovaps xmm6, [rsp+0x60]
000074113b7d6460  vmovaps xmm7, [rsp+0x70]
000074113b7d6466  vmovaps xmm8, [rsp+0x80]
000074113b7d646f  vmovaps xmm10, [rsp+0x90]
000074113b7d6478  vmovaps xmm11, [rsp+0xA0]
000074113b7d6481  vmovaps xmm12, [rsp+0xB0]
000074113b7d648a  vmovaps xmm13, [rsp+0xC0]
000074113b7d6493  vmovaps xmm14, [rsp+0xD0]
000074113b7d649c  vmovaps xmm15, [rsp+0xE0]
000074113b7d64a5  add rsp, 0xF0
000074113b7d64ac  pop r11
000074113b7d64ae  pop r10
000074113b7d64b0  pop r9
000074113b7d64b2  pop r8
000074113b7d64b4  pop rsi
000074113b7d64b5  pop rdi
000074113b7d64b6  pop rdx
000074113b7d64b7  pop rcx
000074113b7d64b8  pop rax
000074113b7d64b9  add rsp, 0x08
000074113b7d64bd  jmp 0x000074113B7D3A9D
000074113b7d64c2  sub rsp, 0x08
000074113b7d64c6  push rax
000074113b7d64c7  push rcx
000074113b7d64c8  push rdx
000074113b7d64c9  push rdi
000074113b7d64ca  push rsi
000074113b7d64cb  push r8
000074113b7d64cd  push r9
000074113b7d64cf  push r10
000074113b7d64d1  push r11
000074113b7d64d3  sub rsp, 0xF0
000074113b7d64da  vmovaps [rsp], xmm0
000074113b7d64df  vmovaps [rsp+0x10], xmm1
000074113b7d64e5  vmovaps [rsp+0x20], xmm2
000074113b7d64eb  vmovaps [rsp+0x30], xmm3
000074113b7d64f1  vmovaps [rsp+0x40], xmm4
000074113b7d64f7  vmovaps [rsp+0x50], xmm5
000074113b7d64fd  vmovaps [rsp+0x60], xmm6
000074113b7d6503  vmovaps [rsp+0x70], xmm7
000074113b7d6509  vmovaps [rsp+0x80], xmm8
000074113b7d6512  vmovaps [rsp+0x90], xmm9
000074113b7d651b  vmovaps [rsp+0xA0], xmm10
000074113b7d6524  vmovaps [rsp+0xB0], xmm11
000074113b7d652d  vmovaps [rsp+0xC0], xmm12
000074113b7d6536  vmovaps [rsp+0xD0], xmm14
000074113b7d653f  vmovaps [rsp+0xE0], xmm15
000074113b7d6548  sub rsp, 0x40
000074113b7d654c  lea rdi, [rsp]
000074113b7d6550  lea rsi, [rsp+0x10]
000074113b7d6555  lea rdx, [rsp+0x20]
000074113b7d655a  lea rcx, [rsp+0x30]
000074113b7d655f  mov r8d, 0x00
000074113b7d6565  lea r9, [r15+0x3A8]
000074113b7d656c  movaps [rdi], xmm13
000074113b7d6570  movaps [rsi], xmm11
000074113b7d6574  movaps [rdx], xmm15
000074113b7d6578  movaps [rcx], xmm14
000074113b7d657c  mov rax, 0x629073062A50
000074113b7d6586  call rax
000074113b7d6588  movaps xmm13, [rsp]
000074113b7d658d  add rsp, 0x40
000074113b7d6591  vmovaps xmm0, [rsp]
000074113b7d6596  vmovaps xmm1, [rsp+0x10]
000074113b7d659c  vmovaps xmm2, [rsp+0x20]
000074113b7d65a2  vmovaps xmm3, [rsp+0x30]
000074113b7d65a8  vmovaps xmm4, [rsp+0x40]
000074113b7d65ae  vmovaps xmm5, [rsp+0x50]
000074113b7d65b4  vmovaps xmm6, [rsp+0x60]
000074113b7d65ba  vmovaps xmm7, [rsp+0x70]
000074113b7d65c0  vmovaps xmm8, [rsp+0x80]
000074113b7d65c9  vmovaps xmm9, [rsp+0x90]
000074113b7d65d2  vmovaps xmm10, [rsp+0xA0]
000074113b7d65db  vmovaps xmm11, [rsp+0xB0]
000074113b7d65e4  vmovaps xmm12, [rsp+0xC0]
000074113b7d65ed  vmovaps xmm14, [rsp+0xD0]
000074113b7d65f6  vmovaps xmm15, [rsp+0xE0]
000074113b7d65ff  add rsp, 0xF0
000074113b7d6606  pop r11
000074113b7d6608  pop r10
000074113b7d660a  pop r9
000074113b7d660c  pop r8
000074113b7d660e  pop rsi
000074113b7d660f  pop rdi
000074113b7d6610  pop rdx
000074113b7d6611  pop rcx
000074113b7d6612  pop rax
000074113b7d6613  add rsp, 0x08
000074113b7d6617  jmp 0x000074113B7D3ACB
000074113b7d661c  sub rsp, 0x08
000074113b7d6620  push rax
000074113b7d6621  push rcx
000074113b7d6622  push rdx
000074113b7d6623  push rdi
000074113b7d6624  push rsi
000074113b7d6625  push r8
000074113b7d6627  push r9
000074113b7d6629  push r10
000074113b7d662b  push r11
000074113b7d662d  sub rsp, 0xF0
000074113b7d6634  vmovaps [rsp], xmm0
000074113b7d6639  vmovaps [rsp+0x10], xmm1
000074113b7d663f  vmovaps [rsp+0x20], xmm2
000074113b7d6645  vmovaps [rsp+0x30], xmm3
000074113b7d664b  vmovaps [rsp+0x40], xmm4
000074113b7d6651  vmovaps [rsp+0x50], xmm5
000074113b7d6657  vmovaps [rsp+0x60], xmm6
000074113b7d665d  vmovaps [rsp+0x70], xmm7
000074113b7d6663  vmovaps [rsp+0x80], xmm8
000074113b7d666c  vmovaps [rsp+0x90], xmm9
000074113b7d6675  vmovaps [rsp+0xA0], xmm10
000074113b7d667e  vmovaps [rsp+0xB0], xmm11
000074113b7d6687  vmovaps [rsp+0xC0], xmm12
000074113b7d6690  vmovaps [rsp+0xD0], xmm13
000074113b7d6699  vmovaps [rsp+0xE0], xmm15
000074113b7d66a2  sub rsp, 0x40
000074113b7d66a6  lea rdi, [rsp]
000074113b7d66aa  lea rsi, [rsp+0x10]
000074113b7d66af  lea rdx, [rsp+0x20]
000074113b7d66b4  lea rcx, [rsp+0x30]
000074113b7d66b9  mov r8d, 0x00
000074113b7d66bf  lea r9, [r15+0x3A8]
000074113b7d66c6  movaps [rdi], xmm14
000074113b7d66ca  movaps [rsi], xmm12
000074113b7d66ce  movaps [rdx], xmm1
000074113b7d66d1  movaps [rcx], xmm15
000074113b7d66d5  mov rax, 0x629073062A50
000074113b7d66df  call rax
000074113b7d66e1  movaps xmm14, [rsp]
000074113b7d66e6  add rsp, 0x40
000074113b7d66ea  vmovaps xmm0, [rsp]
000074113b7d66ef  vmovaps xmm1, [rsp+0x10]
000074113b7d66f5  vmovaps xmm2, [rsp+0x20]
000074113b7d66fb  vmovaps xmm3, [rsp+0x30]
000074113b7d6701  vmovaps xmm4, [rsp+0x40]
000074113b7d6707  vmovaps xmm5, [rsp+0x50]
000074113b7d670d  vmovaps xmm6, [rsp+0x60]
000074113b7d6713  vmovaps xmm7, [rsp+0x70]
000074113b7d6719  vmovaps xmm8, [rsp+0x80]
000074113b7d6722  vmovaps xmm9, [rsp+0x90]
000074113b7d672b  vmovaps xmm10, [rsp+0xA0]
000074113b7d6734  vmovaps xmm11, [rsp+0xB0]
000074113b7d673d  vmovaps xmm12, [rsp+0xC0]
000074113b7d6746  vmovaps xmm13, [rsp+0xD0]
000074113b7d674f  vmovaps xmm15, [rsp+0xE0]
000074113b7d6758  add rsp, 0xF0
000074113b7d675f  pop r11
000074113b7d6761  pop r10
000074113b7d6763  pop r9
000074113b7d6765  pop r8
000074113b7d6767  pop rsi
000074113b7d6768  pop rdi
000074113b7d6769  pop rdx
000074113b7d676a  pop rcx
000074113b7d676b  pop rax
000074113b7d676c  add rsp, 0x08
000074113b7d6770  jmp 0x000074113B7D3AF9
000074113b7d6775  call 0x000074113B6ACF70
000074113b7d677a  jmp 0x000074113B7D3B07
000074113b7d677f  call 0x000074113B60C380
000074113b7d6784  jmp 0x000074113B7D3B11
000074113b7d6789  call 0x000074113B608C20
000074113b7d678e  jmp 0x000074113B7D3B1B
000074113b7d6793  call 0x000074113B60D600
000074113b7d6798  jmp 0x000074113B7D3B25
000074113b7d679d  int3
000074113b7d679e  nop
000074113b7d67a0  mov eax, [r15+0x48]
000074113b7d67a4  lea r14d, [eax+0x01]
000074113b7d67a9  mov [rsp+0x10], r14d
000074113b7d67ae  mov r14d, r14d
000074113b7d67b1  mov [r15+0x48], r14
000074113b7d67b5  xor eax, eax
000074113b7d67b7  mov r14d, [rsp+0x10]
000074113b7d67bc  cmp r14d, 0x1F4
000074113b7d67c3  cmc
000074113b7d67c4  lahf
000074113b7d67c5  seto al
000074113b7d67c8  mov [r15+0x108], eax
000074113b7d67cf  mov eax, [r15+0x108]
000074113b7d67d6  sahf
000074113b7d67d7  jnz 0x000074113B7D6809
000074113b7d67d9  cmp dword ptr [r15+0x318], 0x00
000074113b7d67e1  jz 0x000074113B7DA1A0
000074113b7d67e7  nop [rax+rax*1], ax
000074113b7d67f0  nop [rax+rax*1], eax
000074113b7d67f8  mov eax, 0x4103FC
000074113b7d67fd  mov [r15+0x100], rax
000074113b7d6804  jmp 0x000074113B5FE110
000074113b7d6809  cmp dword ptr [r15+0x318], 0x00
000074113b7d6811  jz 0x000074113B7D6840
000074113b7d6817  nop [rax+rax*1], ax
000074113b7d6820  nop [rax+rax*1], eax
000074113b7d6828  mov eax, 0x410270
000074113b7d682d  mov [r15+0x100], rax
000074113b7d6834  jmp 0x000074113B5FE110
000074113b7d6839  int3
000074113b7d683a  int3
000074113b7d683b  nop [rax+rax*1], eax
000074113b7d6840  mov rax, [r15+0x40]
000074113b7d6844  vxorps xmm1, xmm1, xmm1
000074113b7d6848  vpbroadcastq xmm1, xmm1
000074113b7d684d  vxorps xmm15, xmm15, xmm15
000074113b7d6852  vpbroadcastq xmm15, xmm15
000074113b7d6857  lea r14, [rax+0x30]
000074113b7d685b  mov r12, [r13+r14*1]
000074113b7d6860  lea r14, [rax+0x38]
000074113b7d6864  mov r11, [r13+r14*1]
000074113b7d6869  movq xmm14, r12
000074113b7d686e  movq xmm13, r11
000074113b7d6873  movq xmm14, xmm14
000074113b7d6878  movq xmm13, xmm13
000074113b7d687d  vmovaps [rsp+0x10], xmm13
000074113b7d6883  movq xmm13, xmm13
000074113b7d6888  movaps [r15+0x270], xmm13
000074113b7d6890  movaps xmm13, [r15+0x160]
000074113b7d6898  vmovaps [rsp+0x20], xmm13
000074113b7d689e  vmovaps xmm12, [rsp+0x20]
000074113b7d68a4  por xmm13, xmm12
000074113b7d68a9  lea r14, [rax+0x20]
000074113b7d68ad  mov r12, [r13+r14*1]
000074113b7d68b2  lea r14, [rax+0x28]
000074113b7d68b6  mov r11, [r13+r14*1]
000074113b7d68bb  movq xmm12, r12
000074113b7d68c0  movq xmm11, r11
000074113b7d68c5  movq xmm12, xmm12
000074113b7d68ca  movq xmm11, xmm11
000074113b7d68cf  movaps xmm10, [r15+0x2F0]
000074113b7d68d7  vmovaps [rsp+0x20], xmm10
000074113b7d68dd  vmovaps xmm9, [rsp+0x20]
000074113b7d68e3  por xmm10, xmm9
000074113b7d68e8  movaps xmm9, [r15+0x2D0]
000074113b7d68f0  vmovaps [rsp+0x20], xmm9
000074113b7d68f6  vmovaps xmm8, [rsp+0x20]
000074113b7d68fc  por xmm9, xmm8
000074113b7d6901  movaps xmm8, [r15+0x300]
000074113b7d6909  vmovaps [rsp+0x20], xmm8
000074113b7d690f  vmovaps xmm7, [rsp+0x20]
000074113b7d6915  por xmm8, xmm7
000074113b7d691a  movaps xmm7, [r15+0x2B0]
000074113b7d6922  vmovaps [rsp+0x20], xmm7
000074113b7d6928  vmovaps xmm6, [rsp+0x20]
000074113b7d692e  por xmm7, xmm6
000074113b7d6932  movaps xmm6, [r15+0x180]
000074113b7d693a  vmovaps [rsp+0x20], xmm6
000074113b7d6940  vmovaps xmm5, [rsp+0x20]
000074113b7d6946  por xmm6, xmm5
000074113b7d694a  lea r14, [rax+0x10]
000074113b7d694e  mov r12, [r13+r14*1]
000074113b7d6953  lea r14, [rax+0x18]
000074113b7d6957  mov r11, [r13+r14*1]
000074113b7d695c  movq xmm5, r12
000074113b7d6961  movq xmm4, r11
000074113b7d6966  movq xmm5, xmm5
000074113b7d696a  movq xmm4, xmm4
000074113b7d696e  movaps xmm3, [r15+0x200]
000074113b7d6976  vmovaps [rsp+0x20], xmm3
000074113b7d697c  vmovaps xmm2, [rsp+0x20]
000074113b7d6982  por xmm3, xmm2
000074113b7d6986  movaps xmm2, [r15+0x1F0]
000074113b7d698e  vmovaps [rsp+0x20], xmm2
000074113b7d6994  vmovaps [rsp+0x30], xmm1
000074113b7d699a  vmovaps xmm1, [rsp+0x20]
000074113b7d69a0  por xmm2, xmm1
000074113b7d69a4  movaps xmm1, [r15+0x2E0]
000074113b7d69ac  vmovaps [rsp+0x20], xmm1
000074113b7d69b2  vmovaps [rsp+0x40], xmm15
000074113b7d69b8  vmovaps xmm15, [rsp+0x20]
000074113b7d69be  por xmm1, xmm15
000074113b7d69c3  movaps xmm15, [r15+0x2A0]
000074113b7d69cb  vmovaps [rsp+0x20], xmm15
000074113b7d69d1  vmovaps [rsp+0x50], xmm1
000074113b7d69d7  vmovaps xmm1, [rsp+0x20]
000074113b7d69dd  por xmm15, xmm1
000074113b7d69e2  movaps xmm1, [r15+0x280]
000074113b7d69ea  vmovaps [rsp+0x20], xmm1
000074113b7d69f0  vmovaps [rsp+0x60], xmm15
000074113b7d69f6  vmovaps xmm15, [rsp+0x20]
000074113b7d69fc  por xmm1, xmm15
000074113b7d6a01  movaps xmm15, [r15+0x1C0]
000074113b7d6a09  vmovaps [rsp+0x20], xmm15
000074113b7d6a0f  vmovaps [rsp+0x70], xmm1
000074113b7d6a15  vmovaps xmm1, [rsp+0x20]
000074113b7d6a1b  por xmm15, xmm1
000074113b7d6a20  movaps xmm1, [r15+0x210]
000074113b7d6a28  vmovaps [rsp+0x20], xmm1
000074113b7d6a2e  vmovaps [rsp+0x80], xmm15
000074113b7d6a37  vmovaps xmm15, [rsp+0x20]
000074113b7d6a3d  por xmm1, xmm15
000074113b7d6a42  mov r14, [r13+rax*1]
000074113b7d6a47  vmovq xmm15, r14
000074113b7d6a4c  vpbroadcastq xmm15, xmm15
000074113b7d6a51  vmovaps [rsp+0x20], xmm1
000074113b7d6a57  vxorps xmm1, xmm1, xmm1
000074113b7d6a5b  vpbroadcastq xmm1, xmm1
000074113b7d6a60  mov r14, [r15+0xF8]
000074113b7d6a67  vmovaps [rsp+0x90], xmm1
000074113b7d6a70  movups xmm1, [r13+r14*1]
000074113b7d6a76  vmovaps [rsp+0xA0], xmm1
000074113b7d6a7f  vxorps xmm1, xmm1, xmm1
000074113b7d6a83  vpbroadcastq xmm1, xmm1
000074113b7d6a88  lea r12, [rax+0x08]
000074113b7d6a8c  mov rax, [r13+r12*1]
000074113b7d6a91  vmovaps [rsp+0xB0], xmm1
000074113b7d6a9a  movq xmm1, rax
000074113b7d6a9f  movaps [r15+0x240], xmm1
000074113b7d6aa7  mov rax, [r15+0x50]
000074113b7d6aab  mov [r15+0x60], rax
000074113b7d6aaf  mov qword ptr [r15+0x58], 0x40
000074113b7d6ab7  vmovaps xmm1, [rsp+0x30]
000074113b7d6abd  vmovaps [rsp+0x30], xmm15
000074113b7d6ac3  vmovaps xmm15, [rsp+0xA0]
000074113b7d6acc  vmovaps [rsp+0xA0], xmm14
000074113b7d6ad5  vmovaps xmm14, [rsp+0x30]
000074113b7d6adb  vmovaps [rsp+0x30], xmm13
000074113b7d6ae1  vmovaps [rsp+0xC0], xmm12
000074113b7d6aea  movaps xmm13, xmm1
000074113b7d6aee  vfmadd231pd xmm13, xmm15, xmm14
000074113b7d6af3  vcmppd xmm12, xmm13, xmm13, 0x03
000074113b7d6af9  vptest xmm12, xmm12
000074113b7d6afe  jnz 0x000074113B7D75DD
000074113b7d6b04  movaps xmm1, [r15+0x250]
000074113b7d6b0c  vmovaps xmm15, [rsp+0x40]
000074113b7d6b12  vmovaps [rsp+0x40], xmm13
000074113b7d6b18  movaps xmm12, xmm15
000074113b7d6b1c  vfmadd231pd xmm12, xmm1, xmm14
000074113b7d6b21  vcmppd xmm13, xmm12, xmm12, 0x03
000074113b7d6b27  vptest xmm13, xmm13
000074113b7d6b2c  jnz 0x000074113B7D7736
000074113b7d6b32  movaps xmm15, [r15+0x1E0]
000074113b7d6b3a  vmovaps [rsp+0xD0], xmm15
000074113b7d6b43  vmovaps xmm13, [rsp+0xD0]
000074113b7d6b4c  por xmm15, xmm13
000074113b7d6b51  movaps xmm13, [r15+0x1D0]
000074113b7d6b59  vmovaps [rsp+0xD0], xmm13
000074113b7d6b62  vmovaps [rsp+0xE0], xmm1
000074113b7d6b6b  vmovaps xmm1, [rsp+0xD0]
000074113b7d6b74  por xmm13, xmm1
000074113b7d6b79  movaps xmm1, [r15+0x2C0]
000074113b7d6b81  vmovaps [rsp+0xD0], xmm1
000074113b7d6b8a  vmovaps [rsp+0xF0], xmm15
000074113b7d6b93  vmovaps xmm15, [rsp+0xD0]
000074113b7d6b9c  por xmm1, xmm15
000074113b7d6ba1  movaps xmm15, [r15+0x290]
000074113b7d6ba9  vmovaps [rsp+0xD0], xmm15
000074113b7d6bb2  vmovaps [rsp+0x100], xmm1
000074113b7d6bbb  vmovaps xmm1, [rsp+0xD0]
000074113b7d6bc4  por xmm15, xmm1
000074113b7d6bc9  movaps xmm1, [r15+0x260]
000074113b7d6bd1  vmovaps [rsp+0xD0], xmm1
000074113b7d6bda  vmovaps [rsp+0x110], xmm15
000074113b7d6be3  vmovaps xmm15, [rsp+0xD0]
000074113b7d6bec  por xmm1, xmm15
000074113b7d6bf1  vmovaps xmm15, [rsp+0xE0]
000074113b7d6bfa  vmovaps [rsp+0xD0], xmm1
000074113b7d6c03  vmovaps xmm1, [rsp+0xE0]
000074113b7d6c0c  por xmm15, xmm1
000074113b7d6c11  lea r12, [r14+0xC0]
000074113b7d6c18  movups xmm1, [r13+r12*1]
000074113b7d6c1e  mov [rsp+0xE0], rax
000074113b7d6c26  xor eax, eax
000074113b7d6c28  mov r12d, 0x40
000074113b7d6c2e  mov r11d, 0x200
000074113b7d6c34  cmp r12, r11
000074113b7d6c37  cmc
000074113b7d6c38  lahf
000074113b7d6c39  seto al
000074113b7d6c3c  mov [r15+0x108], eax
000074113b7d6c43  vmovaps [rsp+0x120], xmm1
000074113b7d6c4c  vmovaps xmm1, [rsp+0x90]
000074113b7d6c55  vmovaps [rsp+0x90], xmm15
000074113b7d6c5e  vmovaps xmm15, [rsp+0x120]
000074113b7d6c67  vmovaps [rsp+0x120], xmm13
000074113b7d6c70  vmovaps [rsp+0x130], xmm12
000074113b7d6c79  movaps xmm13, xmm1
000074113b7d6c7d  vfmadd231pd xmm13, xmm15, xmm14
000074113b7d6c82  vcmppd xmm12, xmm13, xmm13, 0x03
000074113b7d6c88  vptest xmm12, xmm12
000074113b7d6c8d  jnz 0x000074113B7D7899
000074113b7d6c93  lea rax, [r14+0xB0]
000074113b7d6c9a  movups xmm1, [r13+rax*1]
000074113b7d6ca0  vmovaps xmm15, [rsp+0xB0]
000074113b7d6ca9  vmovaps [rsp+0xB0], xmm13
000074113b7d6cb2  movaps xmm12, xmm15
000074113b7d6cb6  vfmadd231pd xmm12, xmm1, xmm14
000074113b7d6cbb  vcmppd xmm13, xmm12, xmm12, 0x03
000074113b7d6cc1  vptest xmm13, xmm13
000074113b7d6cc6  jnz 0x000074113B7D79FC
000074113b7d6ccc  vmovaps xmm1, [rsp+0x20]
000074113b7d6cd2  vmovaps xmm15, [rsp+0x20]
000074113b7d6cd8  por xmm1, xmm15
000074113b7d6cdd  movaps [r15+0x210], xmm1
000074113b7d6ce5  vmovaps xmm15, [rsp+0x80]
000074113b7d6cee  vmovaps xmm14, [rsp+0x80]
000074113b7d6cf7  por xmm15, xmm14
000074113b7d6cfc  movaps [r15+0x1C0], xmm15
000074113b7d6d04  vmovaps xmm14, [rsp+0x70]
000074113b7d6d0a  vmovaps xmm13, [rsp+0x70]
000074113b7d6d10  por xmm14, xmm13
000074113b7d6d15  movaps [r15+0x280], xmm14
000074113b7d6d1d  vmovaps xmm13, [rsp+0x60]
000074113b7d6d23  vmovaps [rsp+0x20], xmm1
000074113b7d6d29  vmovaps xmm1, [rsp+0x60]
000074113b7d6d2f  por xmm13, xmm1
000074113b7d6d34  movaps [r15+0x2A0], xmm13
000074113b7d6d3c  vmovaps xmm1, [rsp+0x50]
000074113b7d6d42  vmovaps [rsp+0x60], xmm15
000074113b7d6d48  vmovaps xmm15, [rsp+0x50]
000074113b7d6d4e  por xmm1, xmm15
000074113b7d6d53  movaps [r15+0x2E0], xmm1
000074113b7d6d5b  vmovaps [rsp+0x50], xmm2
000074113b7d6d61  vmovaps xmm15, [rsp+0x50]
000074113b7d6d67  por xmm2, xmm15
000074113b7d6d6c  movaps [r15+0x1F0], xmm2
000074113b7d6d74  vmovaps xmm15, [rsp+0x90]
000074113b7d6d7d  vmovaps [rsp+0x50], xmm1
000074113b7d6d83  vmovaps xmm1, [rsp+0x90]
000074113b7d6d8c  por xmm15, xmm1
000074113b7d6d91  movaps [r15+0x250], xmm15
000074113b7d6d99  vmovaps xmm1, [rsp+0xD0]
000074113b7d6da2  vmovaps xmm15, [rsp+0xD0]
000074113b7d6dab  por xmm1, xmm15
000074113b7d6db0  movaps [r15+0x260], xmm1
000074113b7d6db8  vmovaps xmm15, [rsp+0x110]
000074113b7d6dc1  vmovaps [rsp+0x70], xmm1
000074113b7d6dc7  vmovaps xmm1, [rsp+0x110]
000074113b7d6dd0  por xmm15, xmm1
000074113b7d6dd5  movaps [r15+0x290], xmm15
000074113b7d6ddd  vmovaps xmm1, [rsp+0x100]
000074113b7d6de6  vmovaps [rsp+0x80], xmm15
000074113b7d6def  vmovaps xmm15, [rsp+0x100]
000074113b7d6df8  por xmm1, xmm15
000074113b7d6dfd  movaps [r15+0x2C0], xmm1
000074113b7d6e05  movq xmm15, qword ptr [r15+0x240]
000074113b7d6e0e  vmovaps [rsp+0x90], xmm15
000074113b7d6e17  vpermilpd xmm15, xmm15, 0x00
000074113b7d6e1d  vmovaps [rsp+0xD0], xmm1
000074113b7d6e26  vmovaps xmm1, [rsp+0x40]
000074113b7d6e2c  vmovaps [rsp+0x40], xmm15
000074113b7d6e32  vmovaps xmm15, [rsp+0x20]
000074113b7d6e38  vmovaps [rsp+0x20], xmm14
000074113b7d6e3e  vmovaps xmm14, [rsp+0x40]
000074113b7d6e44  vmovaps [rsp+0x40], xmm13
000074113b7d6e4a  vmovaps [rsp+0x100], xmm12
000074113b7d6e53  movaps xmm13, xmm1
000074113b7d6e57  vfmadd231pd xmm13, xmm15, xmm14
000074113b7d6e5c  vcmppd xmm12, xmm13, xmm13, 0x03
000074113b7d6e62  vptest xmm12, xmm12
000074113b7d6e67  jnz 0x000074113B7D7B55
000074113b7d6e6d  vmovaps xmm1, [rsp+0x90]
000074113b7d6e76  vpermilpd xmm1, xmm1, 0x00
000074113b7d6e7c  vmovaps xmm15, [rsp+0xB0]
000074113b7d6e85  vmovaps xmm14, [rsp+0x50]
000074113b7d6e8b  vmovaps [rsp+0x50], xmm13
000074113b7d6e91  movaps xmm12, xmm15
000074113b7d6e95  vfmadd231pd xmm12, xmm14, xmm1
000074113b7d6e9a  vcmppd xmm13, xmm12, xmm12, 0x03
000074113b7d6ea0  vptest xmm13, xmm13
000074113b7d6ea5  jnz 0x000074113B7D7CAE
000074113b7d6eab  vmovaps xmm1, [rsp+0x90]
000074113b7d6eb4  vpermilpd xmm1, xmm1, 0x00
000074113b7d6eba  vmovaps xmm15, [rsp+0x130]
000074113b7d6ec3  vmovaps xmm14, [rsp+0x60]
000074113b7d6ec9  vmovaps [rsp+0x60], xmm12
000074113b7d6ecf  movaps xmm13, xmm15
000074113b7d6ed3  vfmadd231pd xmm13, xmm14, xmm1
000074113b7d6ed8  vcmppd xmm12, xmm13, xmm13, 0x03
000074113b7d6ede  vptest xmm12, xmm12
000074113b7d6ee3  jnz 0x000074113B7D7E07
000074113b7d6ee9  vmovaps xmm1, [rsp+0x120]
000074113b7d6ef2  vmovaps xmm15, [rsp+0x120]
000074113b7d6efb  por xmm1, xmm15
000074113b7d6f00  movaps [r15+0x1D0], xmm1
000074113b7d6f08  vmovaps xmm15, [rsp+0x90]
000074113b7d6f11  vpermilpd xmm15, xmm15, 0x00
000074113b7d6f17  vmovaps xmm14, [rsp+0x100]
000074113b7d6f20  vmovaps [rsp+0x90], xmm1
000074113b7d6f29  movaps xmm12, xmm14
000074113b7d6f2d  vfmadd231pd xmm12, xmm2, xmm15
000074113b7d6f32  vcmppd xmm1, xmm12, xmm12, 0x03
000074113b7d6f38  vptest xmm1, xmm1
000074113b7d6f3d  jnz 0x000074113B7D7F60
000074113b7d6f43  vmovaps [rsp+0xB0], xmm3
000074113b7d6f4c  vmovaps xmm1, [rsp+0xB0]
000074113b7d6f55  por xmm3, xmm1
000074113b7d6f59  movaps [r15+0x200], xmm3
000074113b7d6f61  vmovaps xmm1, [rsp+0xF0]
000074113b7d6f6a  vmovaps xmm15, [rsp+0xF0]
000074113b7d6f73  por xmm1, xmm15
000074113b7d6f78  movaps [r15+0x1E0], xmm1
000074113b7d6f80  vmovaps [rsp+0xB0], xmm7
000074113b7d6f89  vmovaps xmm1, [rsp+0xB0]
000074113b7d6f92  por xmm7, xmm1
000074113b7d6f96  movaps [r15+0x2B0], xmm7
000074113b7d6f9e  vmovaps [rsp+0xB0], xmm8
000074113b7d6fa7  vmovaps xmm1, [rsp+0xB0]
000074113b7d6fb0  por xmm8, xmm1
000074113b7d6fb5  movaps [r15+0x300], xmm8
000074113b7d6fbd  vmovaps [rsp+0xB0], xmm5
000074113b7d6fc6  vpermilpd xmm5, xmm5, 0x00
000074113b7d6fcc  vmovaps xmm14, [rsp+0x50]
000074113b7d6fd2  vmovaps xmm8, [rsp+0x70]
000074113b7d6fd8  vmovaps [rsp+0x50], xmm1
000074113b7d6fde  movaps xmm2, xmm14
000074113b7d6fe2  vfmadd231pd xmm2, xmm8, xmm5
000074113b7d6fe7  vcmppd xmm1, xmm2, xmm2, 0x03
000074113b7d6fec  vptest xmm1, xmm1
000074113b7d6ff1  jnz 0x000074113B7D80B9
000074113b7d6ff7  vmovaps xmm1, [rsp+0xB0]
000074113b7d7000  vpermilpd xmm1, xmm1, 0x00
000074113b7d7006  vmovaps xmm14, [rsp+0x60]
000074113b7d700c  vmovaps xmm8, [rsp+0xD0]
000074113b7d7015  vmovaps [rsp+0x60], xmm15
000074113b7d701b  movaps xmm5, xmm14
000074113b7d701f  vfmadd231pd xmm5, xmm8, xmm1
000074113b7d7024  vcmppd xmm15, xmm5, xmm5, 0x03
000074113b7d7029  vptest xmm15, xmm15
000074113b7d702e  jnz 0x000074113B7D8210
000074113b7d7034  vmovaps xmm1, [rsp+0xB0]
000074113b7d703d  vpermilpd xmm1, xmm1, 0x00
000074113b7d7043  vmovaps xmm14, [rsp+0x20]
000074113b7d7049  movaps xmm15, xmm13
000074113b7d704d  vfmadd231pd xmm15, xmm14, xmm1
000074113b7d7052  vcmppd xmm8, xmm15, xmm15, 0x03
000074113b7d7058  vptest xmm8, xmm8
000074113b7d705d  jnz 0x000074113B7D8367
000074113b7d7063  vmovaps xmm1, [rsp+0xB0]
000074113b7d706c  vpermilpd xmm1, xmm1, 0x00
000074113b7d7072  vmovaps xmm14, [rsp+0x90]
000074113b7d707b  movaps xmm13, xmm12
000074113b7d707f  vfmadd231pd xmm13, xmm14, xmm1
000074113b7d7084  vcmppd xmm8, xmm13, xmm13, 0x03
000074113b7d708a  vptest xmm8, xmm8
000074113b7d708f  jnz 0x000074113B7D84C0
000074113b7d7095  vmovaps [rsp+0x20], xmm6
000074113b7d709b  vmovaps xmm1, [rsp+0x20]
000074113b7d70a1  por xmm6, xmm1
000074113b7d70a5  movaps [r15+0x180], xmm6
000074113b7d70ad  vmovaps [rsp+0x20], xmm9
000074113b7d70b3  vmovaps xmm1, [rsp+0x20]
000074113b7d70b9  por xmm9, xmm1
000074113b7d70be  movaps [r15+0x2D0], xmm9
000074113b7d70c6  vmovaps [rsp+0x20], xmm10
000074113b7d70cc  vmovaps xmm1, [rsp+0x20]
000074113b7d70d2  por xmm10, xmm1
000074113b7d70d7  movaps [r15+0x2F0], xmm10
000074113b7d70df  vmovaps [rsp+0x20], xmm4
000074113b7d70e5  vpermilpd xmm4, xmm4, 0x00
000074113b7d70eb  vmovaps xmm14, [rsp+0x50]
000074113b7d70f1  movaps xmm12, xmm5
000074113b7d70f5  vfmadd231pd xmm12, xmm14, xmm4
000074113b7d70fa  vcmppd xmm10, xmm12, xmm12, 0x03
000074113b7d7100  vptest xmm10, xmm10
000074113b7d7105  jnz 0x000074113B7D8619
000074113b7d710b  vmovaps xmm14, [rsp+0x20]
000074113b7d7111  vpermilpd xmm14, xmm14, 0x00
000074113b7d7117  movaps xmm10, xmm2
000074113b7d711b  vfmadd231pd xmm10, xmm6, xmm14
000074113b7d7120  vcmppd xmm8, xmm10, xmm10, 0x03
000074113b7d7126  vptest xmm8, xmm8
000074113b7d712b  jnz 0x000074113B7D8771
000074113b7d7131  lea rax, [r14+0x80]
000074113b7d7138  movups xmm14, [r13+rax*1]
000074113b7d713e  movaps [r15+0x190], xmm14
000074113b7d7146  vmovaps xmm8, [rsp+0x20]
000074113b7d714c  vpermilpd xmm8, xmm8, 0x00
000074113b7d7152  vmovaps xmm6, [rsp+0x80]
000074113b7d715b  movaps xmm5, xmm15
000074113b7d715f  vfmadd231pd xmm5, xmm6, xmm8
000074113b7d7164  vcmppd xmm4, xmm5, xmm5, 0x03
000074113b7d7169  vptest xmm4, xmm4
000074113b7d716e  jnz 0x000074113B7D88D3
000074113b7d7174  vmovaps xmm15, [rsp+0x20]
000074113b7d717a  vpermilpd xmm15, xmm15, 0x00
000074113b7d7180  movaps xmm8, xmm13
000074113b7d7184  vfmadd231pd xmm8, xmm1, xmm15
000074113b7d7189  vcmppd xmm6, xmm8, xmm8, 0x03
000074113b7d718f  vptest xmm6, xmm6
000074113b7d7194  jnz 0x000074113B7D8A2A
000074113b7d719a  vmovaps xmm1, [rsp+0x30]
000074113b7d71a0  vmovaps xmm15, [rsp+0x30]
000074113b7d71a6  por xmm1, xmm15
000074113b7d71ab  movaps [r15+0x160], xmm1
000074113b7d71b3  lea rax, [r14+0x40]
000074113b7d71b7  movups xmm15, [r13+rax*1]
000074113b7d71bd  lea rax, [r14+0x50]
000074113b7d71c1  movups xmm13, [r13+rax*1]
000074113b7d71c7  movaps [r15+0x1B0], xmm15
000074113b7d71cf  movaps [r15+0x1A0], xmm13
000074113b7d71d7  vmovaps xmm6, [rsp+0xC0]
000074113b7d71e0  vpermilpd xmm6, xmm6, 0x00
000074113b7d71e6  movaps xmm4, xmm12
000074113b7d71ea  vfmadd231pd xmm4, xmm9, xmm6
000074113b7d71ef  vcmppd xmm2, xmm4, xmm4, 0x03
000074113b7d71f4  vptest xmm2, xmm2
000074113b7d71f9  jnz 0x000074113B7D8B97
000074113b7d71ff  vmovaps xmm12, [rsp+0xC0]
000074113b7d7208  vpermilpd xmm12, xmm12, 0x00
000074113b7d720e  movaps xmm9, xmm10
000074113b7d7212  vfmadd231pd xmm9, xmm1, xmm12
000074113b7d7217  vcmppd xmm6, xmm9, xmm9, 0x03
000074113b7d721d  vptest xmm6, xmm6
000074113b7d7222  jnz 0x000074113B7D8CEE
000074113b7d7228  vmovaps xmm1, [rsp+0xC0]
000074113b7d7231  vpermilpd xmm1, xmm1, 0x00
000074113b7d7237  vmovaps xmm12, [rsp+0x40]
000074113b7d723d  movaps xmm10, xmm5
000074113b7d7241  vfmadd231pd xmm10, xmm12, xmm1
000074113b7d7246  vcmppd xmm6, xmm10, xmm10, 0x03
000074113b7d724c  vptest xmm6, xmm6
000074113b7d7251  jnz 0x000074113B7D8E47
000074113b7d7257  vmovaps xmm1, [rsp+0xC0]
000074113b7d7260  vpermilpd xmm1, xmm1, 0x00
000074113b7d7266  vmovaps xmm12, [rsp+0x60]
000074113b7d726c  movaps xmm6, xmm8
000074113b7d7270  vfmadd231pd xmm6, xmm12, xmm1
000074113b7d7275  vcmppd xmm5, xmm6, xmm6, 0x03
000074113b7d727a  vptest xmm5, xmm5
000074113b7d727f  jnz 0x000074113B7D8F9F
000074113b7d7285  lea rax, [r14+0x60]
000074113b7d7289  movups xmm1, [r13+rax*1]
000074113b7d728f  lea rax, [r14+0x70]
000074113b7d7293  movups xmm12, [r13+rax*1]
000074113b7d7299  movaps [r15+0x150], xmm1
000074113b7d72a1  movaps [r15+0x120], xmm12
000074113b7d72a9  vmovaps [rsp+0x20], xmm11
000074113b7d72af  vpermilpd xmm11, xmm11, 0x00
000074113b7d72b5  movaps xmm8, xmm4
000074113b7d72b9  vfmadd231pd xmm8, xmm13, xmm11
000074113b7d72be  vcmppd xmm5, xmm8, xmm8, 0x03
000074113b7d72c4  vptest xmm5, xmm5
000074113b7d72c9  jnz 0x000074113B7D910A
000074113b7d72cf  vmovaps xmm13, [rsp+0x20]
000074113b7d72d5  vpermilpd xmm13, xmm13, 0x00
000074113b7d72db  movaps xmm11, xmm9
000074113b7d72df  vfmadd231pd xmm11, xmm1, xmm13
000074113b7d72e4  vcmppd xmm5, xmm11, xmm11, 0x03
000074113b7d72ea  vptest xmm5, xmm5
000074113b7d72ef  jnz 0x000074113B7D9263
000074113b7d72f5  vmovaps xmm1, [rsp+0x20]
000074113b7d72fb  vpermilpd xmm1, xmm1, 0x00
000074113b7d7301  movaps xmm13, xmm10
000074113b7d7305  vfmadd231pd xmm13, xmm7, xmm1
000074113b7d730a  vcmppd xmm9, xmm13, xmm13, 0x03
000074113b7d7310  vptest xmm9, xmm9
000074113b7d7315  jnz 0x000074113B7D93BC
000074113b7d731b  vmovaps xmm1, [rsp+0x20]
000074113b7d7321  vpermilpd xmm1, xmm1, 0x00
000074113b7d7327  movaps xmm10, xmm6
000074113b7d732b  vfmadd231pd xmm10, xmm15, xmm1
000074113b7d7330  vcmppd xmm9, xmm10, xmm10, 0x03
000074113b7d7336  vptest xmm9, xmm9
000074113b7d733b  jnz 0x000074113B7D9514
000074113b7d7341  lea rax, [r14+0x20]
000074113b7d7345  movups xmm1, [r13+rax*1]
000074113b7d734b  lea rax, [r14+0x30]
000074113b7d734f  movups xmm15, [r13+rax*1]
000074113b7d7355  vmovaps xmm9, [rsp+0xA0]
000074113b7d735e  vpermilpd xmm9, xmm9, 0x00
000074113b7d7364  movaps xmm7, xmm8
000074113b7d7368  vfmadd231pd xmm7, xmm3, xmm9
000074113b7d736d  vcmppd xmm6, xmm7, xmm7, 0x03
000074113b7d7372  vptest xmm6, xmm6
000074113b7d7377  jnz 0x000074113B7D9680
000074113b7d737d  vmovaps xmm9, [rsp+0xA0]
000074113b7d7386  vpermilpd xmm9, xmm9, 0x00
000074113b7d738c  movaps xmm8, xmm11
000074113b7d7390  vfmadd231pd xmm8, xmm14, xmm9
000074113b7d7395  vcmppd xmm6, xmm8, xmm8, 0x03
000074113b7d739b  vptest xmm6, xmm6
000074113b7d73a0  jnz 0x000074113B7D97D7
000074113b7d73a6  vmovaps xmm14, [rsp+0xA0]
000074113b7d73af  vpermilpd xmm14, xmm14, 0x00
000074113b7d73b5  movaps xmm11, xmm13
000074113b7d73b9  vfmadd231pd xmm11, xmm12, xmm14
000074113b7d73be  vcmppd xmm9, xmm11, xmm11, 0x03
000074113b7d73c4  vptest xmm9, xmm9
000074113b7d73c9  jnz 0x000074113B7D9931
000074113b7d73cf  vmovaps xmm14, [rsp+0xA0]
000074113b7d73d8  vpermilpd xmm14, xmm14, 0x00
000074113b7d73de  movaps xmm12, xmm10
000074113b7d73e2  vfmadd231pd xmm12, xmm15, xmm14
000074113b7d73e7  vcmppd xmm13, xmm12, xmm12, 0x03
000074113b7d73ed  vptest xmm13, xmm13
000074113b7d73f2  jnz 0x000074113B7D9A8B
000074113b7d73f8  lea rax, [r14+0x90]
000074113b7d73ff  movups xmm15, [r13+rax*1]
000074113b7d7405  lea rax, [r14+0xA0]
000074113b7d740c  movups xmm14, [r13+rax*1]
000074113b7d7412  movaps [r15+0x140], xmm15
000074113b7d741a  movaps [r15+0x130], xmm14
000074113b7d7422  vmovaps xmm13, [rsp+0x10]
000074113b7d7428  vpermilpd xmm13, xmm13, 0x00
000074113b7d742e  movaps xmm10, xmm7
000074113b7d7432  vfmadd231pd xmm10, xmm1, xmm13
000074113b7d7437  vcmppd xmm9, xmm10, xmm10, 0x03
000074113b7d743d  vptest xmm9, xmm9
000074113b7d7442  jnz 0x000074113B7D9BF9
000074113b7d7448  movaps [r15+0x220], xmm10
000074113b7d7450  lea rax, [r14+0x10]
000074113b7d7454  movups xmm1, [r13+rax*1]
000074113b7d745a  movaps [r15+0x240], xmm1
000074113b7d7462  vmovaps xmm13, [rsp+0x10]
000074113b7d7468  vpermilpd xmm13, xmm13, 0x00
000074113b7d746e  movaps xmm9, xmm8
000074113b7d7472  vfmadd231pd xmm9, xmm14, xmm13
000074113b7d7477  vcmppd xmm7, xmm9, xmm9, 0x03
000074113b7d747d  vptest xmm7, xmm7
000074113b7d7482  jnz 0x000074113B7D9D5B
000074113b7d7488  movaps [r15+0x110], xmm9
000074113b7d7490  vmovaps xmm14, [rsp+0x10]
000074113b7d7496  vpermilpd xmm14, xmm14, 0x00
000074113b7d749c  movaps xmm13, xmm11
000074113b7d74a0  vfmadd231pd xmm13, xmm15, xmm14
000074113b7d74a5  vcmppd xmm8, xmm13, xmm13, 0x03
000074113b7d74ab  vptest xmm8, xmm8
000074113b7d74b0  jnz 0x000074113B7D9EB5
000074113b7d74b6  movaps [r15+0x170], xmm13
000074113b7d74be  vmovaps xmm15, [rsp+0x10]
000074113b7d74c4  vpermilpd xmm15, xmm15, 0x00
000074113b7d74ca  movaps xmm14, xmm12
000074113b7d74ce  vfmadd231pd xmm14, xmm1, xmm15
000074113b7d74d3  vcmppd xmm11, xmm14, xmm14, 0x03
000074113b7d74d9  vptest xmm11, xmm11
000074113b7d74de  jnz 0x000074113B7DA00F
000074113b7d74e4  movaps [r15+0x230], xmm14
000074113b7d74ec  mov rax, [rsp+0xE0]
000074113b7d74f4  movups [r13+rax*1], xmm9
000074113b7d74fa  lea r14, [rax+0x10]
000074113b7d74fe  movups [r13+r14*1], xmm13
000074113b7d7504  lea r14, [rax+0x20]
000074113b7d7508  movups [r13+r14*1], xmm10
000074113b7d750e  lea r14, [rax+0x30]
000074113b7d7512  movups [r13+r14*1], xmm14
000074113b7d7518  mov eax, [r15+0x108]
000074113b7d751f  sahf
000074113b7d7520  jnz 0x000074113B7D7552
000074113b7d7522  cmp dword ptr [r15+0x318], 0x00
000074113b7d752a  jz 0x000074113B7D67A0
000074113b7d7530  nop [rax+rax*1], ax
000074113b7d7539  nop [rax+rax*1], eax
000074113b7d7541  mov eax, 0x4103F0
000074113b7d7546  mov [r15+0x100], rax
000074113b7d754d  jmp 0x000074113B5FE110
000074113b7d7552  cmp dword ptr [r15+0x318], 0x00
000074113b7d755a  jz 0x000074113B7D2E40
000074113b7d7560  nop [rax+rax*1], ax
000074113b7d7569  nop [rax+rax*1], eax
000074113b7d7571  mov eax, 0x410274
000074113b7d7576  mov [r15+0x100], rax
000074113b7d757d  jmp 0x000074113B5FE110
000074113b7d7582  int3
000074113b7d7583  call 0x000074113B6E27E0
000074113b7d7588  jmp 0x000074113B7D6860
000074113b7d758d  call 0x000074113B6E1570
000074113b7d7592  jmp 0x000074113B7D6869
000074113b7d7597  call 0x000074113B6E27E0
000074113b7d759c  jmp 0x000074113B7D68B2
000074113b7d75a1  call 0x000074113B6E1570
000074113b7d75a6  jmp 0x000074113B7D68BB
000074113b7d75ab  call 0x000074113B6E27E0
000074113b7d75b0  jmp 0x000074113B7D6953
000074113b7d75b5  call 0x000074113B6E1570
000074113b7d75ba  jmp 0x000074113B7D695C
000074113b7d75bf  call 0x000074113B60DC20
000074113b7d75c4  jmp 0x000074113B7D6A47
000074113b7d75c9  call 0x000074113B6D64F0
000074113b7d75ce  jmp 0x000074113B7D6A76
000074113b7d75d3  call 0x000074113B6B47C0
000074113b7d75d8  jmp 0x000074113B7D6A91
000074113b7d75dd  sub rsp, 0x08
000074113b7d75e1  push rax
000074113b7d75e2  push rcx
000074113b7d75e3  push rdx
000074113b7d75e4  push rdi
000074113b7d75e5  push rsi
000074113b7d75e6  push r8
000074113b7d75e8  push r9
000074113b7d75ea  push r10
000074113b7d75ec  push r11
000074113b7d75ee  sub rsp, 0xF0
000074113b7d75f5  vmovaps [rsp], xmm0
000074113b7d75fa  vmovaps [rsp+0x10], xmm1
000074113b7d7600  vmovaps [rsp+0x20], xmm2
000074113b7d7606  vmovaps [rsp+0x30], xmm3
000074113b7d760c  vmovaps [rsp+0x40], xmm4
000074113b7d7612  vmovaps [rsp+0x50], xmm5
000074113b7d7618  vmovaps [rsp+0x60], xmm6
000074113b7d761e  vmovaps [rsp+0x70], xmm7
000074113b7d7624  vmovaps [rsp+0x80], xmm8
000074113b7d762d  vmovaps [rsp+0x90], xmm9
000074113b7d7636  vmovaps [rsp+0xA0], xmm10
000074113b7d763f  vmovaps [rsp+0xB0], xmm11
000074113b7d7648  vmovaps [rsp+0xC0], xmm12
000074113b7d7651  vmovaps [rsp+0xD0], xmm14
000074113b7d765a  vmovaps [rsp+0xE0], xmm15
000074113b7d7663  sub rsp, 0x40
000074113b7d7667  lea rdi, [rsp]
000074113b7d766b  lea rsi, [rsp+0x10]
000074113b7d7670  lea rdx, [rsp+0x20]
000074113b7d7675  lea rcx, [rsp+0x30]
000074113b7d767a  mov r8d, 0x00
000074113b7d7680  lea r9, [r15+0x3A8]
000074113b7d7687  movaps [rdi], xmm13
000074113b7d768b  movaps [rsi], xmm1
000074113b7d768e  movaps [rdx], xmm15
000074113b7d7692  movaps [rcx], xmm14
000074113b7d7696  mov rax, 0x629073062A50
000074113b7d76a0  call rax
000074113b7d76a2  movaps xmm13, [rsp]
000074113b7d76a7  add rsp, 0x40
000074113b7d76ab  vmovaps xmm0, [rsp]
000074113b7d76b0  vmovaps xmm1, [rsp+0x10]
000074113b7d76b6  vmovaps xmm2, [rsp+0x20]
000074113b7d76bc  vmovaps xmm3, [rsp+0x30]
000074113b7d76c2  vmovaps xmm4, [rsp+0x40]
000074113b7d76c8  vmovaps xmm5, [rsp+0x50]
000074113b7d76ce  vmovaps xmm6, [rsp+0x60]
000074113b7d76d4  vmovaps xmm7, [rsp+0x70]
000074113b7d76da  vmovaps xmm8, [rsp+0x80]
000074113b7d76e3  vmovaps xmm9, [rsp+0x90]
000074113b7d76ec  vmovaps xmm10, [rsp+0xA0]
000074113b7d76f5  vmovaps xmm11, [rsp+0xB0]
000074113b7d76fe  vmovaps xmm12, [rsp+0xC0]
000074113b7d7707  vmovaps xmm14, [rsp+0xD0]
000074113b7d7710  vmovaps xmm15, [rsp+0xE0]
000074113b7d7719  add rsp, 0xF0
000074113b7d7720  pop r11
000074113b7d7722  pop r10
000074113b7d7724  pop r9
000074113b7d7726  pop r8
000074113b7d7728  pop rsi
000074113b7d7729  pop rdi
000074113b7d772a  pop rdx
000074113b7d772b  pop rcx
000074113b7d772c  pop rax
000074113b7d772d  add rsp, 0x08
000074113b7d7731  jmp 0x000074113B7D6B04
000074113b7d7736  sub rsp, 0x08
000074113b7d773a  push rax
000074113b7d773b  push rcx
000074113b7d773c  push rdx
000074113b7d773d  push rdi
000074113b7d773e  push rsi
000074113b7d773f  push r8
000074113b7d7741  push r9
000074113b7d7743  push r10
000074113b7d7745  push r11
000074113b7d7747  sub rsp, 0xF0
000074113b7d774e  vmovaps [rsp], xmm0
000074113b7d7753  vmovaps [rsp+0x10], xmm1
000074113b7d7759  vmovaps [rsp+0x20], xmm2
000074113b7d775f  vmovaps [rsp+0x30], xmm3
000074113b7d7765  vmovaps [rsp+0x40], xmm4
000074113b7d776b  vmovaps [rsp+0x50], xmm5
000074113b7d7771  vmovaps [rsp+0x60], xmm6
000074113b7d7777  vmovaps [rsp+0x70], xmm7
000074113b7d777d  vmovaps [rsp+0x80], xmm8
000074113b7d7786  vmovaps [rsp+0x90], xmm9
000074113b7d778f  vmovaps [rsp+0xA0], xmm10
000074113b7d7798  vmovaps [rsp+0xB0], xmm11
000074113b7d77a1  vmovaps [rsp+0xC0], xmm13
000074113b7d77aa  vmovaps [rsp+0xD0], xmm14
000074113b7d77b3  vmovaps [rsp+0xE0], xmm15
000074113b7d77bc  sub rsp, 0x40
000074113b7d77c0  lea rdi, [rsp]
000074113b7d77c4  lea rsi, [rsp+0x10]
000074113b7d77c9  lea rdx, [rsp+0x20]
000074113b7d77ce  lea rcx, [rsp+0x30]
000074113b7d77d3  mov r8d, 0x00
000074113b7d77d9  lea r9, [r15+0x3A8]
000074113b7d77e0  movaps [rdi], xmm12
000074113b7d77e4  movaps [rsi], xmm15
000074113b7d77e8  movaps [rdx], xmm1
000074113b7d77eb  movaps [rcx], xmm14
000074113b7d77ef  mov rax, 0x629073062A50
000074113b7d77f9  call rax
000074113b7d77fb  movaps xmm12, [rsp]
000074113b7d7800  add rsp, 0x40
000074113b7d7804  vmovaps xmm0, [rsp]
000074113b7d7809  vmovaps xmm1, [rsp+0x10]
000074113b7d780f  vmovaps xmm2, [rsp+0x20]
000074113b7d7815  vmovaps xmm3, [rsp+0x30]
000074113b7d781b  vmovaps xmm4, [rsp+0x40]
000074113b7d7821  vmovaps xmm5, [rsp+0x50]
000074113b7d7827  vmovaps xmm6, [rsp+0x60]
000074113b7d782d  vmovaps xmm7, [rsp+0x70]
000074113b7d7833  vmovaps xmm8, [rsp+0x80]
000074113b7d783c  vmovaps xmm9, [rsp+0x90]
000074113b7d7845  vmovaps xmm10, [rsp+0xA0]
000074113b7d784e  vmovaps xmm11, [rsp+0xB0]
000074113b7d7857  vmovaps xmm13, [rsp+0xC0]
000074113b7d7860  vmovaps xmm14, [rsp+0xD0]
000074113b7d7869  vmovaps xmm15, [rsp+0xE0]
000074113b7d7872  add rsp, 0xF0
000074113b7d7879  pop r11
000074113b7d787b  pop r10
000074113b7d787d  pop r9
000074113b7d787f  pop r8
000074113b7d7881  pop rsi
000074113b7d7882  pop rdi
000074113b7d7883  pop rdx
000074113b7d7884  pop rcx
000074113b7d7885  pop rax
000074113b7d7886  add rsp, 0x08
000074113b7d788a  jmp 0x000074113B7D6B32
000074113b7d788f  call 0x000074113B6B52F0
000074113b7d7894  jmp 0x000074113B7D6C1E
000074113b7d7899  sub rsp, 0x08
000074113b7d789d  push rax
000074113b7d789e  push rcx
000074113b7d789f  push rdx
000074113b7d78a0  push rdi
000074113b7d78a1  push rsi
000074113b7d78a2  push r8
000074113b7d78a4  push r9
000074113b7d78a6  push r10
000074113b7d78a8  push r11
000074113b7d78aa  sub rsp, 0xF0
000074113b7d78b1  vmovaps [rsp], xmm0
000074113b7d78b6  vmovaps [rsp+0x10], xmm1
000074113b7d78bc  vmovaps [rsp+0x20], xmm2
000074113b7d78c2  vmovaps [rsp+0x30], xmm3
000074113b7d78c8  vmovaps [rsp+0x40], xmm4
000074113b7d78ce  vmovaps [rsp+0x50], xmm5
000074113b7d78d4  vmovaps [rsp+0x60], xmm6
000074113b7d78da  vmovaps [rsp+0x70], xmm7
000074113b7d78e0  vmovaps [rsp+0x80], xmm8
000074113b7d78e9  vmovaps [rsp+0x90], xmm9
000074113b7d78f2  vmovaps [rsp+0xA0], xmm10
000074113b7d78fb  vmovaps [rsp+0xB0], xmm11
000074113b7d7904  vmovaps [rsp+0xC0], xmm12
000074113b7d790d  vmovaps [rsp+0xD0], xmm14
000074113b7d7916  vmovaps [rsp+0xE0], xmm15
000074113b7d791f  sub rsp, 0x40
000074113b7d7923  lea rdi, [rsp]
000074113b7d7927  lea rsi, [rsp+0x10]
000074113b7d792c  lea rdx, [rsp+0x20]
000074113b7d7931  lea rcx, [rsp+0x30]
000074113b7d7936  mov r8d, 0x00
000074113b7d793c  lea r9, [r15+0x3A8]
000074113b7d7943  movaps [rdi], xmm13
000074113b7d7947  movaps [rsi], xmm1
000074113b7d794a  movaps [rdx], xmm15
000074113b7d794e  movaps [rcx], xmm14
000074113b7d7952  mov rax, 0x629073062A50
000074113b7d795c  call rax
000074113b7d795e  movaps xmm13, [rsp]
000074113b7d7963  add rsp, 0x40
000074113b7d7967  vmovaps xmm0, [rsp]
000074113b7d796c  vmovaps xmm1, [rsp+0x10]
000074113b7d7972  vmovaps xmm2, [rsp+0x20]
000074113b7d7978  vmovaps xmm3, [rsp+0x30]
000074113b7d797e  vmovaps xmm4, [rsp+0x40]
000074113b7d7984  vmovaps xmm5, [rsp+0x50]
000074113b7d798a  vmovaps xmm6, [rsp+0x60]
000074113b7d7990  vmovaps xmm7, [rsp+0x70]
000074113b7d7996  vmovaps xmm8, [rsp+0x80]
000074113b7d799f  vmovaps xmm9, [rsp+0x90]
000074113b7d79a8  vmovaps xmm10, [rsp+0xA0]
000074113b7d79b1  vmovaps xmm11, [rsp+0xB0]
000074113b7d79ba  vmovaps xmm12, [rsp+0xC0]
000074113b7d79c3  vmovaps xmm14, [rsp+0xD0]
000074113b7d79cc  vmovaps xmm15, [rsp+0xE0]
000074113b7d79d5  add rsp, 0xF0
000074113b7d79dc  pop r11
000074113b7d79de  pop r10
000074113b7d79e0  pop r9
000074113b7d79e2  pop r8
000074113b7d79e4  pop rsi
000074113b7d79e5  pop rdi
000074113b7d79e6  pop rdx
000074113b7d79e7  pop rcx
000074113b7d79e8  pop rax
000074113b7d79e9  add rsp, 0x08
000074113b7d79ed  jmp 0x000074113B7D6C93
000074113b7d79f2  call 0x000074113B5FF430
000074113b7d79f7  jmp 0x000074113B7D6CA0
000074113b7d79fc  sub rsp, 0x08
000074113b7d7a00  push rax
000074113b7d7a01  push rcx
000074113b7d7a02  push rdx
000074113b7d7a03  push rdi
000074113b7d7a04  push rsi
000074113b7d7a05  push r8
000074113b7d7a07  push r9
000074113b7d7a09  push r10
000074113b7d7a0b  push r11
000074113b7d7a0d  sub rsp, 0xF0
000074113b7d7a14  vmovaps [rsp], xmm0
000074113b7d7a19  vmovaps [rsp+0x10], xmm1
000074113b7d7a1f  vmovaps [rsp+0x20], xmm2
000074113b7d7a25  vmovaps [rsp+0x30], xmm3
000074113b7d7a2b  vmovaps [rsp+0x40], xmm4
000074113b7d7a31  vmovaps [rsp+0x50], xmm5
000074113b7d7a37  vmovaps [rsp+0x60], xmm6
000074113b7d7a3d  vmovaps [rsp+0x70], xmm7
000074113b7d7a43  vmovaps [rsp+0x80], xmm8
000074113b7d7a4c  vmovaps [rsp+0x90], xmm9
000074113b7d7a55  vmovaps [rsp+0xA0], xmm10
000074113b7d7a5e  vmovaps [rsp+0xB0], xmm11
000074113b7d7a67  vmovaps [rsp+0xC0], xmm13
000074113b7d7a70  vmovaps [rsp+0xD0], xmm14
000074113b7d7a79  vmovaps [rsp+0xE0], xmm15
000074113b7d7a82  sub rsp, 0x40
000074113b7d7a86  lea rdi, [rsp]
000074113b7d7a8a  lea rsi, [rsp+0x10]
000074113b7d7a8f  lea rdx, [rsp+0x20]
000074113b7d7a94  lea rcx, [rsp+0x30]
000074113b7d7a99  mov r8d, 0x00
000074113b7d7a9f  lea r9, [r15+0x3A8]
000074113b7d7aa6  movaps [rdi], xmm12
000074113b7d7aaa  movaps [rsi], xmm15
000074113b7d7aae  movaps [rdx], xmm1
000074113b7d7ab1  movaps [rcx], xmm14
000074113b7d7ab5  mov rax, 0x629073062A50
000074113b7d7abf  call rax
000074113b7d7ac1  movaps xmm12, [rsp]
000074113b7d7ac6  add rsp, 0x40
000074113b7d7aca  vmovaps xmm0, [rsp]
000074113b7d7acf  vmovaps xmm1, [rsp+0x10]
000074113b7d7ad5  vmovaps xmm2, [rsp+0x20]
000074113b7d7adb  vmovaps xmm3, [rsp+0x30]
000074113b7d7ae1  vmovaps xmm4, [rsp+0x40]
000074113b7d7ae7  vmovaps xmm5, [rsp+0x50]
000074113b7d7aed  vmovaps xmm6, [rsp+0x60]
000074113b7d7af3  vmovaps xmm7, [rsp+0x70]
000074113b7d7af9  vmovaps xmm8, [rsp+0x80]
000074113b7d7b02  vmovaps xmm9, [rsp+0x90]
000074113b7d7b0b  vmovaps xmm10, [rsp+0xA0]
000074113b7d7b14  vmovaps xmm11, [rsp+0xB0]
000074113b7d7b1d  vmovaps xmm13, [rsp+0xC0]
000074113b7d7b26  vmovaps xmm14, [rsp+0xD0]
000074113b7d7b2f  vmovaps xmm15, [rsp+0xE0]
000074113b7d7b38  add rsp, 0xF0
000074113b7d7b3f  pop r11
000074113b7d7b41  pop r10
000074113b7d7b43  pop r9
000074113b7d7b45  pop r8
000074113b7d7b47  pop rsi
000074113b7d7b48  pop rdi
000074113b7d7b49  pop rdx
000074113b7d7b4a  pop rcx
000074113b7d7b4b  pop rax
000074113b7d7b4c  add rsp, 0x08
000074113b7d7b50  jmp 0x000074113B7D6CCC
000074113b7d7b55  sub rsp, 0x08
000074113b7d7b59  push rax
000074113b7d7b5a  push rcx
000074113b7d7b5b  push rdx
000074113b7d7b5c  push rdi
000074113b7d7b5d  push rsi
000074113b7d7b5e  push r8
000074113b7d7b60  push r9
000074113b7d7b62  push r10
000074113b7d7b64  push r11
000074113b7d7b66  sub rsp, 0xF0
000074113b7d7b6d  vmovaps [rsp], xmm0
000074113b7d7b72  vmovaps [rsp+0x10], xmm1
000074113b7d7b78  vmovaps [rsp+0x20], xmm2
000074113b7d7b7e  vmovaps [rsp+0x30], xmm3
000074113b7d7b84  vmovaps [rsp+0x40], xmm4
000074113b7d7b8a  vmovaps [rsp+0x50], xmm5
000074113b7d7b90  vmovaps [rsp+0x60], xmm6
000074113b7d7b96  vmovaps [rsp+0x70], xmm7
000074113b7d7b9c  vmovaps [rsp+0x80], xmm8
000074113b7d7ba5  vmovaps [rsp+0x90], xmm9
000074113b7d7bae  vmovaps [rsp+0xA0], xmm10
000074113b7d7bb7  vmovaps [rsp+0xB0], xmm11
000074113b7d7bc0  vmovaps [rsp+0xC0], xmm12
000074113b7d7bc9  vmovaps [rsp+0xD0], xmm14
000074113b7d7bd2  vmovaps [rsp+0xE0], xmm15
000074113b7d7bdb  sub rsp, 0x40
000074113b7d7bdf  lea rdi, [rsp]
000074113b7d7be3  lea rsi, [rsp+0x10]
000074113b7d7be8  lea rdx, [rsp+0x20]
000074113b7d7bed  lea rcx, [rsp+0x30]
000074113b7d7bf2  mov r8d, 0x00
000074113b7d7bf8  lea r9, [r15+0x3A8]
000074113b7d7bff  movaps [rdi], xmm13
000074113b7d7c03  movaps [rsi], xmm1
000074113b7d7c06  movaps [rdx], xmm15
000074113b7d7c0a  movaps [rcx], xmm14
000074113b7d7c0e  mov rax, 0x629073062A50
000074113b7d7c18  call rax
000074113b7d7c1a  movaps xmm13, [rsp]
000074113b7d7c1f  add rsp, 0x40
000074113b7d7c23  vmovaps xmm0, [rsp]
000074113b7d7c28  vmovaps xmm1, [rsp+0x10]
000074113b7d7c2e  vmovaps xmm2, [rsp+0x20]
000074113b7d7c34  vmovaps xmm3, [rsp+0x30]
000074113b7d7c3a  vmovaps xmm4, [rsp+0x40]
000074113b7d7c40  vmovaps xmm5, [rsp+0x50]
000074113b7d7c46  vmovaps xmm6, [rsp+0x60]
000074113b7d7c4c  vmovaps xmm7, [rsp+0x70]
000074113b7d7c52  vmovaps xmm8, [rsp+0x80]
000074113b7d7c5b  vmovaps xmm9, [rsp+0x90]
000074113b7d7c64  vmovaps xmm10, [rsp+0xA0]
000074113b7d7c6d  vmovaps xmm11, [rsp+0xB0]
000074113b7d7c76  vmovaps xmm12, [rsp+0xC0]
000074113b7d7c7f  vmovaps xmm14, [rsp+0xD0]
000074113b7d7c88  vmovaps xmm15, [rsp+0xE0]
000074113b7d7c91  add rsp, 0xF0
000074113b7d7c98  pop r11
000074113b7d7c9a  pop r10
000074113b7d7c9c  pop r9
000074113b7d7c9e  pop r8
000074113b7d7ca0  pop rsi
000074113b7d7ca1  pop rdi
000074113b7d7ca2  pop rdx
000074113b7d7ca3  pop rcx
000074113b7d7ca4  pop rax
000074113b7d7ca5  add rsp, 0x08
000074113b7d7ca9  jmp 0x000074113B7D6E6D
000074113b7d7cae  sub rsp, 0x08
000074113b7d7cb2  push rax
000074113b7d7cb3  push rcx
000074113b7d7cb4  push rdx
000074113b7d7cb5  push rdi
000074113b7d7cb6  push rsi
000074113b7d7cb7  push r8
000074113b7d7cb9  push r9
000074113b7d7cbb  push r10
000074113b7d7cbd  push r11
000074113b7d7cbf  sub rsp, 0xF0
000074113b7d7cc6  vmovaps [rsp], xmm0
000074113b7d7ccb  vmovaps [rsp+0x10], xmm1
000074113b7d7cd1  vmovaps [rsp+0x20], xmm2
000074113b7d7cd7  vmovaps [rsp+0x30], xmm3
000074113b7d7cdd  vmovaps [rsp+0x40], xmm4
000074113b7d7ce3  vmovaps [rsp+0x50], xmm5
000074113b7d7ce9  vmovaps [rsp+0x60], xmm6
000074113b7d7cef  vmovaps [rsp+0x70], xmm7
000074113b7d7cf5  vmovaps [rsp+0x80], xmm8
000074113b7d7cfe  vmovaps [rsp+0x90], xmm9
000074113b7d7d07  vmovaps [rsp+0xA0], xmm10
000074113b7d7d10  vmovaps [rsp+0xB0], xmm11
000074113b7d7d19  vmovaps [rsp+0xC0], xmm13
000074113b7d7d22  vmovaps [rsp+0xD0], xmm14
000074113b7d7d2b  vmovaps [rsp+0xE0], xmm15
000074113b7d7d34  sub rsp, 0x40
000074113b7d7d38  lea rdi, [rsp]
000074113b7d7d3c  lea rsi, [rsp+0x10]
000074113b7d7d41  lea rdx, [rsp+0x20]
000074113b7d7d46  lea rcx, [rsp+0x30]
000074113b7d7d4b  mov r8d, 0x00
000074113b7d7d51  lea r9, [r15+0x3A8]
000074113b7d7d58  movaps [rdi], xmm12
000074113b7d7d5c  movaps [rsi], xmm15
000074113b7d7d60  movaps [rdx], xmm14
000074113b7d7d64  movaps [rcx], xmm1
000074113b7d7d67  mov rax, 0x629073062A50
000074113b7d7d71  call rax
000074113b7d7d73  movaps xmm12, [rsp]
000074113b7d7d78  add rsp, 0x40
000074113b7d7d7c  vmovaps xmm0, [rsp]
000074113b7d7d81  vmovaps xmm1, [rsp+0x10]
000074113b7d7d87  vmovaps xmm2, [rsp+0x20]
000074113b7d7d8d  vmovaps xmm3, [rsp+0x30]
000074113b7d7d93  vmovaps xmm4, [rsp+0x40]
000074113b7d7d99  vmovaps xmm5, [rsp+0x50]
000074113b7d7d9f  vmovaps xmm6, [rsp+0x60]
000074113b7d7da5  vmovaps xmm7, [rsp+0x70]
000074113b7d7dab  vmovaps xmm8, [rsp+0x80]
000074113b7d7db4  vmovaps xmm9, [rsp+0x90]
000074113b7d7dbd  vmovaps xmm10, [rsp+0xA0]
000074113b7d7dc6  vmovaps xmm11, [rsp+0xB0]
000074113b7d7dcf  vmovaps xmm13, [rsp+0xC0]
000074113b7d7dd8  vmovaps xmm14, [rsp+0xD0]
000074113b7d7de1  vmovaps xmm15, [rsp+0xE0]
000074113b7d7dea  add rsp, 0xF0
000074113b7d7df1  pop r11
000074113b7d7df3  pop r10
000074113b7d7df5  pop r9
000074113b7d7df7  pop r8
000074113b7d7df9  pop rsi
000074113b7d7dfa  pop rdi
000074113b7d7dfb  pop rdx
000074113b7d7dfc  pop rcx
000074113b7d7dfd  pop rax
000074113b7d7dfe  add rsp, 0x08
000074113b7d7e02  jmp 0x000074113B7D6EAB
000074113b7d7e07  sub rsp, 0x08
000074113b7d7e0b  push rax
000074113b7d7e0c  push rcx
000074113b7d7e0d  push rdx
000074113b7d7e0e  push rdi
000074113b7d7e0f  push rsi
000074113b7d7e10  push r8
000074113b7d7e12  push r9
000074113b7d7e14  push r10
000074113b7d7e16  push r11
000074113b7d7e18  sub rsp, 0xF0
000074113b7d7e1f  vmovaps [rsp], xmm0
000074113b7d7e24  vmovaps [rsp+0x10], xmm1
000074113b7d7e2a  vmovaps [rsp+0x20], xmm2
000074113b7d7e30  vmovaps [rsp+0x30], xmm3
000074113b7d7e36  vmovaps [rsp+0x40], xmm4
000074113b7d7e3c  vmovaps [rsp+0x50], xmm5
000074113b7d7e42  vmovaps [rsp+0x60], xmm6
000074113b7d7e48  vmovaps [rsp+0x70], xmm7
000074113b7d7e4e  vmovaps [rsp+0x80], xmm8
000074113b7d7e57  vmovaps [rsp+0x90], xmm9
000074113b7d7e60  vmovaps [rsp+0xA0], xmm10
000074113b7d7e69  vmovaps [rsp+0xB0], xmm11
000074113b7d7e72  vmovaps [rsp+0xC0], xmm12
000074113b7d7e7b  vmovaps [rsp+0xD0], xmm14
000074113b7d7e84  vmovaps [rsp+0xE0], xmm15
000074113b7d7e8d  sub rsp, 0x40
000074113b7d7e91  lea rdi, [rsp]
000074113b7d7e95  lea rsi, [rsp+0x10]
000074113b7d7e9a  lea rdx, [rsp+0x20]
000074113b7d7e9f  lea rcx, [rsp+0x30]
000074113b7d7ea4  mov r8d, 0x00
000074113b7d7eaa  lea r9, [r15+0x3A8]
000074113b7d7eb1  movaps [rdi], xmm13
000074113b7d7eb5  movaps [rsi], xmm15
000074113b7d7eb9  movaps [rdx], xmm14
000074113b7d7ebd  movaps [rcx], xmm1
000074113b7d7ec0  mov rax, 0x629073062A50
000074113b7d7eca  call rax
000074113b7d7ecc  movaps xmm13, [rsp]
000074113b7d7ed1  add rsp, 0x40
000074113b7d7ed5  vmovaps xmm0, [rsp]
000074113b7d7eda  vmovaps xmm1, [rsp+0x10]
000074113b7d7ee0  vmovaps xmm2, [rsp+0x20]
000074113b7d7ee6  vmovaps xmm3, [rsp+0x30]
000074113b7d7eec  vmovaps xmm4, [rsp+0x40]
000074113b7d7ef2  vmovaps xmm5, [rsp+0x50]
000074113b7d7ef8  vmovaps xmm6, [rsp+0x60]
000074113b7d7efe  vmovaps xmm7, [rsp+0x70]
000074113b7d7f04  vmovaps xmm8, [rsp+0x80]
000074113b7d7f0d  vmovaps xmm9, [rsp+0x90]
000074113b7d7f16  vmovaps xmm10, [rsp+0xA0]
000074113b7d7f1f  vmovaps xmm11, [rsp+0xB0]
000074113b7d7f28  vmovaps xmm12, [rsp+0xC0]
000074113b7d7f31  vmovaps xmm14, [rsp+0xD0]
000074113b7d7f3a  vmovaps xmm15, [rsp+0xE0]
000074113b7d7f43  add rsp, 0xF0
000074113b7d7f4a  pop r11
000074113b7d7f4c  pop r10
000074113b7d7f4e  pop r9
000074113b7d7f50  pop r8
000074113b7d7f52  pop rsi
000074113b7d7f53  pop rdi
000074113b7d7f54  pop rdx
000074113b7d7f55  pop rcx
000074113b7d7f56  pop rax
000074113b7d7f57  add rsp, 0x08
000074113b7d7f5b  jmp 0x000074113B7D6EE9
000074113b7d7f60  sub rsp, 0x08
000074113b7d7f64  push rax
000074113b7d7f65  push rcx
000074113b7d7f66  push rdx
000074113b7d7f67  push rdi
000074113b7d7f68  push rsi
000074113b7d7f69  push r8
000074113b7d7f6b  push r9
000074113b7d7f6d  push r10
000074113b7d7f6f  push r11
000074113b7d7f71  sub rsp, 0xF0
000074113b7d7f78  vmovaps [rsp], xmm0
000074113b7d7f7d  vmovaps [rsp+0x10], xmm1
000074113b7d7f83  vmovaps [rsp+0x20], xmm2
000074113b7d7f89  vmovaps [rsp+0x30], xmm3
000074113b7d7f8f  vmovaps [rsp+0x40], xmm4
000074113b7d7f95  vmovaps [rsp+0x50], xmm5
000074113b7d7f9b  vmovaps [rsp+0x60], xmm6
000074113b7d7fa1  vmovaps [rsp+0x70], xmm7
000074113b7d7fa7  vmovaps [rsp+0x80], xmm8
000074113b7d7fb0  vmovaps [rsp+0x90], xmm9
000074113b7d7fb9  vmovaps [rsp+0xA0], xmm10
000074113b7d7fc2  vmovaps [rsp+0xB0], xmm11
000074113b7d7fcb  vmovaps [rsp+0xC0], xmm13
000074113b7d7fd4  vmovaps [rsp+0xD0], xmm14
000074113b7d7fdd  vmovaps [rsp+0xE0], xmm15
000074113b7d7fe6  sub rsp, 0x40
000074113b7d7fea  lea rdi, [rsp]
000074113b7d7fee  lea rsi, [rsp+0x10]
000074113b7d7ff3  lea rdx, [rsp+0x20]
000074113b7d7ff8  lea rcx, [rsp+0x30]
000074113b7d7ffd  mov r8d, 0x00
000074113b7d8003  lea r9, [r15+0x3A8]
000074113b7d800a  movaps [rdi], xmm12
000074113b7d800e  movaps [rsi], xmm14
000074113b7d8012  movaps [rdx], xmm2
000074113b7d8015  movaps [rcx], xmm15
000074113b7d8019  mov rax, 0x629073062A50
000074113b7d8023  call rax
000074113b7d8025  movaps xmm12, [rsp]
000074113b7d802a  add rsp, 0x40
000074113b7d802e  vmovaps xmm0, [rsp]
000074113b7d8033  vmovaps xmm1, [rsp+0x10]
000074113b7d8039  vmovaps xmm2, [rsp+0x20]
000074113b7d803f  vmovaps xmm3, [rsp+0x30]
000074113b7d8045  vmovaps xmm4, [rsp+0x40]
000074113b7d804b  vmovaps xmm5, [rsp+0x50]
000074113b7d8051  vmovaps xmm6, [rsp+0x60]
000074113b7d8057  vmovaps xmm7, [rsp+0x70]
000074113b7d805d  vmovaps xmm8, [rsp+0x80]
000074113b7d8066  vmovaps xmm9, [rsp+0x90]
000074113b7d806f  vmovaps xmm10, [rsp+0xA0]
000074113b7d8078  vmovaps xmm11, [rsp+0xB0]
000074113b7d8081  vmovaps xmm13, [rsp+0xC0]
000074113b7d808a  vmovaps xmm14, [rsp+0xD0]
000074113b7d8093  vmovaps xmm15, [rsp+0xE0]
000074113b7d809c  add rsp, 0xF0
000074113b7d80a3  pop r11
000074113b7d80a5  pop r10
000074113b7d80a7  pop r9
000074113b7d80a9  pop r8
000074113b7d80ab  pop rsi
000074113b7d80ac  pop rdi
000074113b7d80ad  pop rdx
000074113b7d80ae  pop rcx
000074113b7d80af  pop rax
000074113b7d80b0  add rsp, 0x08
000074113b7d80b4  jmp 0x000074113B7D6F43
000074113b7d80b9  sub rsp, 0x08
000074113b7d80bd  push rax
000074113b7d80be  push rcx
000074113b7d80bf  push rdx
000074113b7d80c0  push rdi
000074113b7d80c1  push rsi
000074113b7d80c2  push r8
000074113b7d80c4  push r9
000074113b7d80c6  push r10
000074113b7d80c8  push r11
000074113b7d80ca  sub rsp, 0xF0
000074113b7d80d1  vmovaps [rsp], xmm0
000074113b7d80d6  vmovaps [rsp+0x10], xmm1
000074113b7d80dc  vmovaps [rsp+0x20], xmm3
000074113b7d80e2  vmovaps [rsp+0x30], xmm4
000074113b7d80e8  vmovaps [rsp+0x40], xmm5
000074113b7d80ee  vmovaps [rsp+0x50], xmm6
000074113b7d80f4  vmovaps [rsp+0x60], xmm7
000074113b7d80fa  vmovaps [rsp+0x70], xmm8
000074113b7d8100  vmovaps [rsp+0x80], xmm9
000074113b7d8109  vmovaps [rsp+0x90], xmm10
000074113b7d8112  vmovaps [rsp+0xA0], xmm11
000074113b7d811b  vmovaps [rsp+0xB0], xmm12
000074113b7d8124  vmovaps [rsp+0xC0], xmm13
000074113b7d812d  vmovaps [rsp+0xD0], xmm14
000074113b7d8136  vmovaps [rsp+0xE0], xmm15
000074113b7d813f  sub rsp, 0x40
000074113b7d8143  lea rdi, [rsp]
000074113b7d8147  lea rsi, [rsp+0x10]
000074113b7d814c  lea rdx, [rsp+0x20]
000074113b7d8151  lea rcx, [rsp+0x30]
000074113b7d8156  mov r8d, 0x00
000074113b7d815c  lea r9, [r15+0x3A8]
000074113b7d8163  movaps [rdi], xmm2
000074113b7d8166  movaps [rsi], xmm14
000074113b7d816a  movaps [rdx], xmm8
000074113b7d816e  movaps [rcx], xmm5
000074113b7d8171  mov rax, 0x629073062A50
000074113b7d817b  call rax
000074113b7d817d  movaps xmm2, [rsp]
000074113b7d8181  add rsp, 0x40
000074113b7d8185  vmovaps xmm0, [rsp]
000074113b7d818a  vmovaps xmm1, [rsp+0x10]
000074113b7d8190  vmovaps xmm3, [rsp+0x20]
000074113b7d8196  vmovaps xmm4, [rsp+0x30]
000074113b7d819c  vmovaps xmm5, [rsp+0x40]
000074113b7d81a2  vmovaps xmm6, [rsp+0x50]
000074113b7d81a8  vmovaps xmm7, [rsp+0x60]
000074113b7d81ae  vmovaps xmm8, [rsp+0x70]
000074113b7d81b4  vmovaps xmm9, [rsp+0x80]
000074113b7d81bd  vmovaps xmm10, [rsp+0x90]
000074113b7d81c6  vmovaps xmm11, [rsp+0xA0]
000074113b7d81cf  vmovaps xmm12, [rsp+0xB0]
000074113b7d81d8  vmovaps xmm13, [rsp+0xC0]
000074113b7d81e1  vmovaps xmm14, [rsp+0xD0]
000074113b7d81ea  vmovaps xmm15, [rsp+0xE0]
000074113b7d81f3  add rsp, 0xF0
000074113b7d81fa  pop r11
000074113b7d81fc  pop r10
000074113b7d81fe  pop r9
000074113b7d8200  pop r8
000074113b7d8202  pop rsi
000074113b7d8203  pop rdi
000074113b7d8204  pop rdx
000074113b7d8205  pop rcx
000074113b7d8206  pop rax
000074113b7d8207  add rsp, 0x08
000074113b7d820b  jmp 0x000074113B7D6FF7
000074113b7d8210  sub rsp, 0x08
000074113b7d8214  push rax
000074113b7d8215  push rcx
000074113b7d8216  push rdx
000074113b7d8217  push rdi
000074113b7d8218  push rsi
000074113b7d8219  push r8
000074113b7d821b  push r9
000074113b7d821d  push r10
000074113b7d821f  push r11
000074113b7d8221  sub rsp, 0xF0
000074113b7d8228  vmovaps [rsp], xmm0
000074113b7d822d  vmovaps [rsp+0x10], xmm1
000074113b7d8233  vmovaps [rsp+0x20], xmm2
000074113b7d8239  vmovaps [rsp+0x30], xmm3
000074113b7d823f  vmovaps [rsp+0x40], xmm4
000074113b7d8245  vmovaps [rsp+0x50], xmm6
000074113b7d824b  vmovaps [rsp+0x60], xmm7
000074113b7d8251  vmovaps [rsp+0x70], xmm8
000074113b7d8257  vmovaps [rsp+0x80], xmm9
000074113b7d8260  vmovaps [rsp+0x90], xmm10
000074113b7d8269  vmovaps [rsp+0xA0], xmm11
000074113b7d8272  vmovaps [rsp+0xB0], xmm12
000074113b7d827b  vmovaps [rsp+0xC0], xmm13
000074113b7d8284  vmovaps [rsp+0xD0], xmm14
000074113b7d828d  vmovaps [rsp+0xE0], xmm15
000074113b7d8296  sub rsp, 0x40
000074113b7d829a  lea rdi, [rsp]
000074113b7d829e  lea rsi, [rsp+0x10]
000074113b7d82a3  lea rdx, [rsp+0x20]
000074113b7d82a8  lea rcx, [rsp+0x30]
000074113b7d82ad  mov r8d, 0x00
000074113b7d82b3  lea r9, [r15+0x3A8]
000074113b7d82ba  movaps [rdi], xmm5
000074113b7d82bd  movaps [rsi], xmm14
000074113b7d82c1  movaps [rdx], xmm8
000074113b7d82c5  movaps [rcx], xmm1
000074113b7d82c8  mov rax, 0x629073062A50
000074113b7d82d2  call rax
000074113b7d82d4  movaps xmm5, [rsp]
000074113b7d82d8  add rsp, 0x40
000074113b7d82dc  vmovaps xmm0, [rsp]
000074113b7d82e1  vmovaps xmm1, [rsp+0x10]
000074113b7d82e7  vmovaps xmm2, [rsp+0x20]
000074113b7d82ed  vmovaps xmm3, [rsp+0x30]
000074113b7d82f3  vmovaps xmm4, [rsp+0x40]
000074113b7d82f9  vmovaps xmm6, [rsp+0x50]
000074113b7d82ff  vmovaps xmm7, [rsp+0x60]
000074113b7d8305  vmovaps xmm8, [rsp+0x70]
000074113b7d830b  vmovaps xmm9, [rsp+0x80]
000074113b7d8314  vmovaps xmm10, [rsp+0x90]
000074113b7d831d  vmovaps xmm11, [rsp+0xA0]
000074113b7d8326  vmovaps xmm12, [rsp+0xB0]
000074113b7d832f  vmovaps xmm13, [rsp+0xC0]
000074113b7d8338  vmovaps xmm14, [rsp+0xD0]
000074113b7d8341  vmovaps xmm15, [rsp+0xE0]
000074113b7d834a  add rsp, 0xF0
000074113b7d8351  pop r11
000074113b7d8353  pop r10
000074113b7d8355  pop r9
000074113b7d8357  pop r8
000074113b7d8359  pop rsi
000074113b7d835a  pop rdi
000074113b7d835b  pop rdx
000074113b7d835c  pop rcx
000074113b7d835d  pop rax
000074113b7d835e  add rsp, 0x08
000074113b7d8362  jmp 0x000074113B7D7034
000074113b7d8367  sub rsp, 0x08
000074113b7d836b  push rax
000074113b7d836c  push rcx
000074113b7d836d  push rdx
000074113b7d836e  push rdi
000074113b7d836f  push rsi
000074113b7d8370  push r8
000074113b7d8372  push r9
000074113b7d8374  push r10
000074113b7d8376  push r11
000074113b7d8378  sub rsp, 0xF0
000074113b7d837f  vmovaps [rsp], xmm0
000074113b7d8384  vmovaps [rsp+0x10], xmm1
000074113b7d838a  vmovaps [rsp+0x20], xmm2
000074113b7d8390  vmovaps [rsp+0x30], xmm3
000074113b7d8396  vmovaps [rsp+0x40], xmm4
000074113b7d839c  vmovaps [rsp+0x50], xmm5
000074113b7d83a2  vmovaps [rsp+0x60], xmm6
000074113b7d83a8  vmovaps [rsp+0x70], xmm7
000074113b7d83ae  vmovaps [rsp+0x80], xmm8
000074113b7d83b7  vmovaps [rsp+0x90], xmm9
000074113b7d83c0  vmovaps [rsp+0xA0], xmm10
000074113b7d83c9  vmovaps [rsp+0xB0], xmm11
000074113b7d83d2  vmovaps [rsp+0xC0], xmm12
000074113b7d83db  vmovaps [rsp+0xD0], xmm13
000074113b7d83e4  vmovaps [rsp+0xE0], xmm14
000074113b7d83ed  sub rsp, 0x40
000074113b7d83f1  lea rdi, [rsp]
000074113b7d83f5  lea rsi, [rsp+0x10]
000074113b7d83fa  lea rdx, [rsp+0x20]
000074113b7d83ff  lea rcx, [rsp+0x30]
000074113b7d8404  mov r8d, 0x00
000074113b7d840a  lea r9, [r15+0x3A8]
000074113b7d8411  movaps [rdi], xmm15
000074113b7d8415  movaps [rsi], xmm13
000074113b7d8419  movaps [rdx], xmm14
000074113b7d841d  movaps [rcx], xmm1
000074113b7d8420  mov rax, 0x629073062A50
000074113b7d842a  call rax
000074113b7d842c  movaps xmm15, [rsp]
000074113b7d8431  add rsp, 0x40
000074113b7d8435  vmovaps xmm0, [rsp]
000074113b7d843a  vmovaps xmm1, [rsp+0x10]
000074113b7d8440  vmovaps xmm2, [rsp+0x20]
000074113b7d8446  vmovaps xmm3, [rsp+0x30]
000074113b7d844c  vmovaps xmm4, [rsp+0x40]
000074113b7d8452  vmovaps xmm5, [rsp+0x50]
000074113b7d8458  vmovaps xmm6, [rsp+0x60]
000074113b7d845e  vmovaps xmm7, [rsp+0x70]
000074113b7d8464  vmovaps xmm8, [rsp+0x80]
000074113b7d846d  vmovaps xmm9, [rsp+0x90]
000074113b7d8476  vmovaps xmm10, [rsp+0xA0]
000074113b7d847f  vmovaps xmm11, [rsp+0xB0]
000074113b7d8488  vmovaps xmm12, [rsp+0xC0]
000074113b7d8491  vmovaps xmm13, [rsp+0xD0]
000074113b7d849a  vmovaps xmm14, [rsp+0xE0]
000074113b7d84a3  add rsp, 0xF0
000074113b7d84aa  pop r11
000074113b7d84ac  pop r10
000074113b7d84ae  pop r9
000074113b7d84b0  pop r8
000074113b7d84b2  pop rsi
000074113b7d84b3  pop rdi
000074113b7d84b4  pop rdx
000074113b7d84b5  pop rcx
000074113b7d84b6  pop rax
000074113b7d84b7  add rsp, 0x08
000074113b7d84bb  jmp 0x000074113B7D7063
000074113b7d84c0  sub rsp, 0x08
000074113b7d84c4  push rax
000074113b7d84c5  push rcx
000074113b7d84c6  push rdx
000074113b7d84c7  push rdi
000074113b7d84c8  push rsi
000074113b7d84c9  push r8
000074113b7d84cb  push r9
000074113b7d84cd  push r10
000074113b7d84cf  push r11
000074113b7d84d1  sub rsp, 0xF0
000074113b7d84d8  vmovaps [rsp], xmm0
000074113b7d84dd  vmovaps [rsp+0x10], xmm1
000074113b7d84e3  vmovaps [rsp+0x20], xmm2
000074113b7d84e9  vmovaps [rsp+0x30], xmm3
000074113b7d84ef  vmovaps [rsp+0x40], xmm4
000074113b7d84f5  vmovaps [rsp+0x50], xmm5
000074113b7d84fb  vmovaps [rsp+0x60], xmm6
000074113b7d8501  vmovaps [rsp+0x70], xmm7
000074113b7d8507  vmovaps [rsp+0x80], xmm8
000074113b7d8510  vmovaps [rsp+0x90], xmm9
000074113b7d8519  vmovaps [rsp+0xA0], xmm10
000074113b7d8522  vmovaps [rsp+0xB0], xmm11
000074113b7d852b  vmovaps [rsp+0xC0], xmm12
000074113b7d8534  vmovaps [rsp+0xD0], xmm14
000074113b7d853d  vmovaps [rsp+0xE0], xmm15
000074113b7d8546  sub rsp, 0x40
000074113b7d854a  lea rdi, [rsp]
000074113b7d854e  lea rsi, [rsp+0x10]
000074113b7d8553  lea rdx, [rsp+0x20]
000074113b7d8558  lea rcx, [rsp+0x30]
000074113b7d855d  mov r8d, 0x00
000074113b7d8563  lea r9, [r15+0x3A8]
000074113b7d856a  movaps [rdi], xmm13
000074113b7d856e  movaps [rsi], xmm12
000074113b7d8572  movaps [rdx], xmm14
000074113b7d8576  movaps [rcx], xmm1
000074113b7d8579  mov rax, 0x629073062A50
000074113b7d8583  call rax
000074113b7d8585  movaps xmm13, [rsp]
000074113b7d858a  add rsp, 0x40
000074113b7d858e  vmovaps xmm0, [rsp]
000074113b7d8593  vmovaps xmm1, [rsp+0x10]
000074113b7d8599  vmovaps xmm2, [rsp+0x20]
000074113b7d859f  vmovaps xmm3, [rsp+0x30]
000074113b7d85a5  vmovaps xmm4, [rsp+0x40]
000074113b7d85ab  vmovaps xmm5, [rsp+0x50]
000074113b7d85b1  vmovaps xmm6, [rsp+0x60]
000074113b7d85b7  vmovaps xmm7, [rsp+0x70]
000074113b7d85bd  vmovaps xmm8, [rsp+0x80]
000074113b7d85c6  vmovaps xmm9, [rsp+0x90]
000074113b7d85cf  vmovaps xmm10, [rsp+0xA0]
000074113b7d85d8  vmovaps xmm11, [rsp+0xB0]
000074113b7d85e1  vmovaps xmm12, [rsp+0xC0]
000074113b7d85ea  vmovaps xmm14, [rsp+0xD0]
000074113b7d85f3  vmovaps xmm15, [rsp+0xE0]
000074113b7d85fc  add rsp, 0xF0
000074113b7d8603  pop r11
000074113b7d8605  pop r10
000074113b7d8607  pop r9
000074113b7d8609  pop r8
000074113b7d860b  pop rsi
000074113b7d860c  pop rdi
000074113b7d860d  pop rdx
000074113b7d860e  pop rcx
000074113b7d860f  pop rax
000074113b7d8610  add rsp, 0x08
000074113b7d8614  jmp 0x000074113B7D7095
000074113b7d8619  sub rsp, 0x08
000074113b7d861d  push rax
000074113b7d861e  push rcx
000074113b7d861f  push rdx
000074113b7d8620  push rdi
000074113b7d8621  push rsi
000074113b7d8622  push r8
000074113b7d8624  push r9
000074113b7d8626  push r10
000074113b7d8628  push r11
000074113b7d862a  sub rsp, 0xF0
000074113b7d8631  vmovaps [rsp], xmm0
000074113b7d8636  vmovaps [rsp+0x10], xmm1
000074113b7d863c  vmovaps [rsp+0x20], xmm2
000074113b7d8642  vmovaps [rsp+0x30], xmm3
000074113b7d8648  vmovaps [rsp+0x40], xmm4
000074113b7d864e  vmovaps [rsp+0x50], xmm5
000074113b7d8654  vmovaps [rsp+0x60], xmm6
000074113b7d865a  vmovaps [rsp+0x70], xmm7
000074113b7d8660  vmovaps [rsp+0x80], xmm8
000074113b7d8669  vmovaps [rsp+0x90], xmm9
000074113b7d8672  vmovaps [rsp+0xA0], xmm10
000074113b7d867b  vmovaps [rsp+0xB0], xmm11
000074113b7d8684  vmovaps [rsp+0xC0], xmm13
000074113b7d868d  vmovaps [rsp+0xD0], xmm14
000074113b7d8696  vmovaps [rsp+0xE0], xmm15
000074113b7d869f  sub rsp, 0x40
000074113b7d86a3  lea rdi, [rsp]
000074113b7d86a7  lea rsi, [rsp+0x10]
000074113b7d86ac  lea rdx, [rsp+0x20]
000074113b7d86b1  lea rcx, [rsp+0x30]
000074113b7d86b6  mov r8d, 0x00
000074113b7d86bc  lea r9, [r15+0x3A8]
000074113b7d86c3  movaps [rdi], xmm12
000074113b7d86c7  movaps [rsi], xmm5
000074113b7d86ca  movaps [rdx], xmm14
000074113b7d86ce  movaps [rcx], xmm4
000074113b7d86d1  mov rax, 0x629073062A50
000074113b7d86db  call rax
000074113b7d86dd  movaps xmm12, [rsp]
000074113b7d86e2  add rsp, 0x40
000074113b7d86e6  vmovaps xmm0, [rsp]
000074113b7d86eb  vmovaps xmm1, [rsp+0x10]
000074113b7d86f1  vmovaps xmm2, [rsp+0x20]
000074113b7d86f7  vmovaps xmm3, [rsp+0x30]
000074113b7d86fd  vmovaps xmm4, [rsp+0x40]
000074113b7d8703  vmovaps xmm5, [rsp+0x50]
000074113b7d8709  vmovaps xmm6, [rsp+0x60]
000074113b7d870f  vmovaps xmm7, [rsp+0x70]
000074113b7d8715  vmovaps xmm8, [rsp+0x80]
000074113b7d871e  vmovaps xmm9, [rsp+0x90]
000074113b7d8727  vmovaps xmm10, [rsp+0xA0]
000074113b7d8730  vmovaps xmm11, [rsp+0xB0]
000074113b7d8739  vmovaps xmm13, [rsp+0xC0]
000074113b7d8742  vmovaps xmm14, [rsp+0xD0]
000074113b7d874b  vmovaps xmm15, [rsp+0xE0]
000074113b7d8754  add rsp, 0xF0
000074113b7d875b  pop r11
000074113b7d875d  pop r10
000074113b7d875f  pop r9
000074113b7d8761  pop r8
000074113b7d8763  pop rsi
000074113b7d8764  pop rdi
000074113b7d8765  pop rdx
000074113b7d8766  pop rcx
000074113b7d8767  pop rax
000074113b7d8768  add rsp, 0x08
000074113b7d876c  jmp 0x000074113B7D710B
000074113b7d8771  sub rsp, 0x08
000074113b7d8775  push rax
000074113b7d8776  push rcx
000074113b7d8777  push rdx
000074113b7d8778  push rdi
000074113b7d8779  push rsi
000074113b7d877a  push r8
000074113b7d877c  push r9
000074113b7d877e  push r10
000074113b7d8780  push r11
000074113b7d8782  sub rsp, 0xF0
000074113b7d8789  vmovaps [rsp], xmm0
000074113b7d878e  vmovaps [rsp+0x10], xmm1
000074113b7d8794  vmovaps [rsp+0x20], xmm2
000074113b7d879a  vmovaps [rsp+0x30], xmm3
000074113b7d87a0  vmovaps [rsp+0x40], xmm4
000074113b7d87a6  vmovaps [rsp+0x50], xmm5
000074113b7d87ac  vmovaps [rsp+0x60], xmm6
000074113b7d87b2  vmovaps [rsp+0x70], xmm7
000074113b7d87b8  vmovaps [rsp+0x80], xmm8
000074113b7d87c1  vmovaps [rsp+0x90], xmm9
000074113b7d87ca  vmovaps [rsp+0xA0], xmm11
000074113b7d87d3  vmovaps [rsp+0xB0], xmm12
000074113b7d87dc  vmovaps [rsp+0xC0], xmm13
000074113b7d87e5  vmovaps [rsp+0xD0], xmm14
000074113b7d87ee  vmovaps [rsp+0xE0], xmm15
000074113b7d87f7  sub rsp, 0x40
000074113b7d87fb  lea rdi, [rsp]
000074113b7d87ff  lea rsi, [rsp+0x10]
000074113b7d8804  lea rdx, [rsp+0x20]
000074113b7d8809  lea rcx, [rsp+0x30]
000074113b7d880e  mov r8d, 0x00
000074113b7d8814  lea r9, [r15+0x3A8]
000074113b7d881b  movaps [rdi], xmm10
000074113b7d881f  movaps [rsi], xmm2
000074113b7d8822  movaps [rdx], xmm6
000074113b7d8825  movaps [rcx], xmm14
000074113b7d8829  mov rax, 0x629073062A50
000074113b7d8833  call rax
000074113b7d8835  movaps xmm10, [rsp]
000074113b7d883a  add rsp, 0x40
000074113b7d883e  vmovaps xmm0, [rsp]
000074113b7d8843  vmovaps xmm1, [rsp+0x10]
000074113b7d8849  vmovaps xmm2, [rsp+0x20]
000074113b7d884f  vmovaps xmm3, [rsp+0x30]
000074113b7d8855  vmovaps xmm4, [rsp+0x40]
000074113b7d885b  vmovaps xmm5, [rsp+0x50]
000074113b7d8861  vmovaps xmm6, [rsp+0x60]
000074113b7d8867  vmovaps xmm7, [rsp+0x70]
000074113b7d886d  vmovaps xmm8, [rsp+0x80]
000074113b7d8876  vmovaps xmm9, [rsp+0x90]
000074113b7d887f  vmovaps xmm11, [rsp+0xA0]
000074113b7d8888  vmovaps xmm12, [rsp+0xB0]
000074113b7d8891  vmovaps xmm13, [rsp+0xC0]
000074113b7d889a  vmovaps xmm14, [rsp+0xD0]
000074113b7d88a3  vmovaps xmm15, [rsp+0xE0]
000074113b7d88ac  add rsp, 0xF0
000074113b7d88b3  pop r11
000074113b7d88b5  pop r10
000074113b7d88b7  pop r9
000074113b7d88b9  pop r8
000074113b7d88bb  pop rsi
000074113b7d88bc  pop rdi
000074113b7d88bd  pop rdx
000074113b7d88be  pop rcx
000074113b7d88bf  pop rax
000074113b7d88c0  add rsp, 0x08
000074113b7d88c4  jmp 0x000074113B7D7131
000074113b7d88c9  call 0x000074113B60D4E0
000074113b7d88ce  jmp 0x000074113B7D713E
000074113b7d88d3  sub rsp, 0x08
000074113b7d88d7  push rax
000074113b7d88d8  push rcx
000074113b7d88d9  push rdx
000074113b7d88da  push rdi
000074113b7d88db  push rsi
000074113b7d88dc  push r8
000074113b7d88de  push r9
000074113b7d88e0  push r10
000074113b7d88e2  push r11
000074113b7d88e4  sub rsp, 0xF0
000074113b7d88eb  vmovaps [rsp], xmm0
000074113b7d88f0  vmovaps [rsp+0x10], xmm1
000074113b7d88f6  vmovaps [rsp+0x20], xmm2
000074113b7d88fc  vmovaps [rsp+0x30], xmm3
000074113b7d8902  vmovaps [rsp+0x40], xmm4
000074113b7d8908  vmovaps [rsp+0x50], xmm6
000074113b7d890e  vmovaps [rsp+0x60], xmm7
000074113b7d8914  vmovaps [rsp+0x70], xmm8
000074113b7d891a  vmovaps [rsp+0x80], xmm9
000074113b7d8923  vmovaps [rsp+0x90], xmm10
000074113b7d892c  vmovaps [rsp+0xA0], xmm11
000074113b7d8935  vmovaps [rsp+0xB0], xmm12
000074113b7d893e  vmovaps [rsp+0xC0], xmm13
000074113b7d8947  vmovaps [rsp+0xD0], xmm14
000074113b7d8950  vmovaps [rsp+0xE0], xmm15
000074113b7d8959  sub rsp, 0x40
000074113b7d895d  lea rdi, [rsp]
000074113b7d8961  lea rsi, [rsp+0x10]
000074113b7d8966  lea rdx, [rsp+0x20]
000074113b7d896b  lea rcx, [rsp+0x30]
000074113b7d8970  mov r8d, 0x00
000074113b7d8976  lea r9, [r15+0x3A8]
000074113b7d897d  movaps [rdi], xmm5
000074113b7d8980  movaps [rsi], xmm15
000074113b7d8984  movaps [rdx], xmm6
000074113b7d8987  movaps [rcx], xmm8
000074113b7d898b  mov rax, 0x629073062A50
000074113b7d8995  call rax
000074113b7d8997  movaps xmm5, [rsp]
000074113b7d899b  add rsp, 0x40
000074113b7d899f  vmovaps xmm0, [rsp]
000074113b7d89a4  vmovaps xmm1, [rsp+0x10]
000074113b7d89aa  vmovaps xmm2, [rsp+0x20]
000074113b7d89b0  vmovaps xmm3, [rsp+0x30]
000074113b7d89b6  vmovaps xmm4, [rsp+0x40]
000074113b7d89bc  vmovaps xmm6, [rsp+0x50]
000074113b7d89c2  vmovaps xmm7, [rsp+0x60]
000074113b7d89c8  vmovaps xmm8, [rsp+0x70]
000074113b7d89ce  vmovaps xmm9, [rsp+0x80]
000074113b7d89d7  vmovaps xmm10, [rsp+0x90]
000074113b7d89e0  vmovaps xmm11, [rsp+0xA0]
000074113b7d89e9  vmovaps xmm12, [rsp+0xB0]
000074113b7d89f2  vmovaps xmm13, [rsp+0xC0]
000074113b7d89fb  vmovaps xmm14, [rsp+0xD0]
000074113b7d8a04  vmovaps xmm15, [rsp+0xE0]
000074113b7d8a0d  add rsp, 0xF0
000074113b7d8a14  pop r11
000074113b7d8a16  pop r10
000074113b7d8a18  pop r9
000074113b7d8a1a  pop r8
000074113b7d8a1c  pop rsi
000074113b7d8a1d  pop rdi
000074113b7d8a1e  pop rdx
000074113b7d8a1f  pop rcx
000074113b7d8a20  pop rax
000074113b7d8a21  add rsp, 0x08
000074113b7d8a25  jmp 0x000074113B7D7174
000074113b7d8a2a  sub rsp, 0x08
000074113b7d8a2e  push rax
000074113b7d8a2f  push rcx
000074113b7d8a30  push rdx
000074113b7d8a31  push rdi
000074113b7d8a32  push rsi
000074113b7d8a33  push r8
000074113b7d8a35  push r9
000074113b7d8a37  push r10
000074113b7d8a39  push r11
000074113b7d8a3b  sub rsp, 0xF0
000074113b7d8a42  vmovaps [rsp], xmm0
000074113b7d8a47  vmovaps [rsp+0x10], xmm1
000074113b7d8a4d  vmovaps [rsp+0x20], xmm2
000074113b7d8a53  vmovaps [rsp+0x30], xmm3
000074113b7d8a59  vmovaps [rsp+0x40], xmm4
000074113b7d8a5f  vmovaps [rsp+0x50], xmm5
000074113b7d8a65  vmovaps [rsp+0x60], xmm6
000074113b7d8a6b  vmovaps [rsp+0x70], xmm7
000074113b7d8a71  vmovaps [rsp+0x80], xmm9
000074113b7d8a7a  vmovaps [rsp+0x90], xmm10
000074113b7d8a83  vmovaps [rsp+0xA0], xmm11
000074113b7d8a8c  vmovaps [rsp+0xB0], xmm12
000074113b7d8a95  vmovaps [rsp+0xC0], xmm13
000074113b7d8a9e  vmovaps [rsp+0xD0], xmm14
000074113b7d8aa7  vmovaps [rsp+0xE0], xmm15
000074113b7d8ab0  sub rsp, 0x40
000074113b7d8ab4  lea rdi, [rsp]
000074113b7d8ab8  lea rsi, [rsp+0x10]
000074113b7d8abd  lea rdx, [rsp+0x20]
000074113b7d8ac2  lea rcx, [rsp+0x30]
000074113b7d8ac7  mov r8d, 0x00
000074113b7d8acd  lea r9, [r15+0x3A8]
000074113b7d8ad4  movaps [rdi], xmm8
000074113b7d8ad8  movaps [rsi], xmm13
000074113b7d8adc  movaps [rdx], xmm1
000074113b7d8adf  movaps [rcx], xmm15
000074113b7d8ae3  mov rax, 0x629073062A50
000074113b7d8aed  call rax
000074113b7d8aef  movaps xmm8, [rsp]
000074113b7d8af4  add rsp, 0x40
000074113b7d8af8  vmovaps xmm0, [rsp]
000074113b7d8afd  vmovaps xmm1, [rsp+0x10]
000074113b7d8b03  vmovaps xmm2, [rsp+0x20]
000074113b7d8b09  vmovaps xmm3, [rsp+0x30]
000074113b7d8b0f  vmovaps xmm4, [rsp+0x40]
000074113b7d8b15  vmovaps xmm5, [rsp+0x50]
000074113b7d8b1b  vmovaps xmm6, [rsp+0x60]
000074113b7d8b21  vmovaps xmm7, [rsp+0x70]
000074113b7d8b27  vmovaps xmm9, [rsp+0x80]
000074113b7d8b30  vmovaps xmm10, [rsp+0x90]
000074113b7d8b39  vmovaps xmm11, [rsp+0xA0]
000074113b7d8b42  vmovaps xmm12, [rsp+0xB0]
000074113b7d8b4b  vmovaps xmm13, [rsp+0xC0]
000074113b7d8b54  vmovaps xmm14, [rsp+0xD0]
000074113b7d8b5d  vmovaps xmm15, [rsp+0xE0]
000074113b7d8b66  add rsp, 0xF0
000074113b7d8b6d  pop r11
000074113b7d8b6f  pop r10
000074113b7d8b71  pop r9
000074113b7d8b73  pop r8
000074113b7d8b75  pop rsi
000074113b7d8b76  pop rdi
000074113b7d8b77  pop rdx
000074113b7d8b78  pop rcx
000074113b7d8b79  pop rax
000074113b7d8b7a  add rsp, 0x08
000074113b7d8b7e  jmp 0x000074113B7D719A
000074113b7d8b83  call 0x000074113B60E760
000074113b7d8b88  jmp 0x000074113B7D71BD
000074113b7d8b8d  call 0x000074113B60C260
000074113b7d8b92  jmp 0x000074113B7D71C7
000074113b7d8b97  sub rsp, 0x08
000074113b7d8b9b  push rax
000074113b7d8b9c  push rcx
000074113b7d8b9d  push rdx
000074113b7d8b9e  push rdi
000074113b7d8b9f  push rsi
000074113b7d8ba0  push r8
000074113b7d8ba2  push r9
000074113b7d8ba4  push r10
000074113b7d8ba6  push r11
000074113b7d8ba8  sub rsp, 0xF0
000074113b7d8baf  vmovaps [rsp], xmm0
000074113b7d8bb4  vmovaps [rsp+0x10], xmm1
000074113b7d8bba  vmovaps [rsp+0x20], xmm2
000074113b7d8bc0  vmovaps [rsp+0x30], xmm3
000074113b7d8bc6  vmovaps [rsp+0x40], xmm5
000074113b7d8bcc  vmovaps [rsp+0x50], xmm6
000074113b7d8bd2  vmovaps [rsp+0x60], xmm7
000074113b7d8bd8  vmovaps [rsp+0x70], xmm8
000074113b7d8bde  vmovaps [rsp+0x80], xmm9
000074113b7d8be7  vmovaps [rsp+0x90], xmm10
000074113b7d8bf0  vmovaps [rsp+0xA0], xmm11
000074113b7d8bf9  vmovaps [rsp+0xB0], xmm12
000074113b7d8c02  vmovaps [rsp+0xC0], xmm13
000074113b7d8c0b  vmovaps [rsp+0xD0], xmm14
000074113b7d8c14  vmovaps [rsp+0xE0], xmm15
000074113b7d8c1d  sub rsp, 0x40
000074113b7d8c21  lea rdi, [rsp]
000074113b7d8c25  lea rsi, [rsp+0x10]
000074113b7d8c2a  lea rdx, [rsp+0x20]
000074113b7d8c2f  lea rcx, [rsp+0x30]
000074113b7d8c34  mov r8d, 0x00
000074113b7d8c3a  lea r9, [r15+0x3A8]
000074113b7d8c41  movaps [rdi], xmm4
000074113b7d8c44  movaps [rsi], xmm12
000074113b7d8c48  movaps [rdx], xmm9
000074113b7d8c4c  movaps [rcx], xmm6
000074113b7d8c4f  mov rax, 0x629073062A50
000074113b7d8c59  call rax
000074113b7d8c5b  movaps xmm4, [rsp]
000074113b7d8c5f  add rsp, 0x40
000074113b7d8c63  vmovaps xmm0, [rsp]
000074113b7d8c68  vmovaps xmm1, [rsp+0x10]
000074113b7d8c6e  vmovaps xmm2, [rsp+0x20]
000074113b7d8c74  vmovaps xmm3, [rsp+0x30]
000074113b7d8c7a  vmovaps xmm5, [rsp+0x40]
000074113b7d8c80  vmovaps xmm6, [rsp+0x50]
000074113b7d8c86  vmovaps xmm7, [rsp+0x60]
000074113b7d8c8c  vmovaps xmm8, [rsp+0x70]
000074113b7d8c92  vmovaps xmm9, [rsp+0x80]
000074113b7d8c9b  vmovaps xmm10, [rsp+0x90]
000074113b7d8ca4  vmovaps xmm11, [rsp+0xA0]
000074113b7d8cad  vmovaps xmm12, [rsp+0xB0]
000074113b7d8cb6  vmovaps xmm13, [rsp+0xC0]
000074113b7d8cbf  vmovaps xmm14, [rsp+0xD0]
000074113b7d8cc8  vmovaps xmm15, [rsp+0xE0]
000074113b7d8cd1  add rsp, 0xF0
000074113b7d8cd8  pop r11
000074113b7d8cda  pop r10
000074113b7d8cdc  pop r9
000074113b7d8cde  pop r8
000074113b7d8ce0  pop rsi
000074113b7d8ce1  pop rdi
000074113b7d8ce2  pop rdx
000074113b7d8ce3  pop rcx
000074113b7d8ce4  pop rax
000074113b7d8ce5  add rsp, 0x08
000074113b7d8ce9  jmp 0x000074113B7D71FF
000074113b7d8cee  sub rsp, 0x08
000074113b7d8cf2  push rax
000074113b7d8cf3  push rcx
000074113b7d8cf4  push rdx
000074113b7d8cf5  push rdi
000074113b7d8cf6  push rsi
000074113b7d8cf7  push r8
000074113b7d8cf9  push r9
000074113b7d8cfb  push r10
000074113b7d8cfd  push r11
000074113b7d8cff  sub rsp, 0xF0
000074113b7d8d06  vmovaps [rsp], xmm0
000074113b7d8d0b  vmovaps [rsp+0x10], xmm1
000074113b7d8d11  vmovaps [rsp+0x20], xmm2
000074113b7d8d17  vmovaps [rsp+0x30], xmm3
000074113b7d8d1d  vmovaps [rsp+0x40], xmm4
000074113b7d8d23  vmovaps [rsp+0x50], xmm5
000074113b7d8d29  vmovaps [rsp+0x60], xmm6
000074113b7d8d2f  vmovaps [rsp+0x70], xmm7
000074113b7d8d35  vmovaps [rsp+0x80], xmm8
000074113b7d8d3e  vmovaps [rsp+0x90], xmm10
000074113b7d8d47  vmovaps [rsp+0xA0], xmm11
000074113b7d8d50  vmovaps [rsp+0xB0], xmm12
000074113b7d8d59  vmovaps [rsp+0xC0], xmm13
000074113b7d8d62  vmovaps [rsp+0xD0], xmm14
000074113b7d8d6b  vmovaps [rsp+0xE0], xmm15
000074113b7d8d74  sub rsp, 0x40
000074113b7d8d78  lea rdi, [rsp]
000074113b7d8d7c  lea rsi, [rsp+0x10]
000074113b7d8d81  lea rdx, [rsp+0x20]
000074113b7d8d86  lea rcx, [rsp+0x30]
000074113b7d8d8b  mov r8d, 0x00
000074113b7d8d91  lea r9, [r15+0x3A8]
000074113b7d8d98  movaps [rdi], xmm9
000074113b7d8d9c  movaps [rsi], xmm10
000074113b7d8da0  movaps [rdx], xmm1
000074113b7d8da3  movaps [rcx], xmm12
000074113b7d8da7  mov rax, 0x629073062A50
000074113b7d8db1  call rax
000074113b7d8db3  movaps xmm9, [rsp]
000074113b7d8db8  add rsp, 0x40
000074113b7d8dbc  vmovaps xmm0, [rsp]
000074113b7d8dc1  vmovaps xmm1, [rsp+0x10]
000074113b7d8dc7  vmovaps xmm2, [rsp+0x20]
000074113b7d8dcd  vmovaps xmm3, [rsp+0x30]
000074113b7d8dd3  vmovaps xmm4, [rsp+0x40]
000074113b7d8dd9  vmovaps xmm5, [rsp+0x50]
000074113b7d8ddf  vmovaps xmm6, [rsp+0x60]
000074113b7d8de5  vmovaps xmm7, [rsp+0x70]
000074113b7d8deb  vmovaps xmm8, [rsp+0x80]
000074113b7d8df4  vmovaps xmm10, [rsp+0x90]
000074113b7d8dfd  vmovaps xmm11, [rsp+0xA0]
000074113b7d8e06  vmovaps xmm12, [rsp+0xB0]
000074113b7d8e0f  vmovaps xmm13, [rsp+0xC0]
000074113b7d8e18  vmovaps xmm14, [rsp+0xD0]
000074113b7d8e21  vmovaps xmm15, [rsp+0xE0]
000074113b7d8e2a  add rsp, 0xF0
000074113b7d8e31  pop r11
000074113b7d8e33  pop r10
000074113b7d8e35  pop r9
000074113b7d8e37  pop r8
000074113b7d8e39  pop rsi
000074113b7d8e3a  pop rdi
000074113b7d8e3b  pop rdx
000074113b7d8e3c  pop rcx
000074113b7d8e3d  pop rax
000074113b7d8e3e  add rsp, 0x08
000074113b7d8e42  jmp 0x000074113B7D7228
000074113b7d8e47  sub rsp, 0x08
000074113b7d8e4b  push rax
000074113b7d8e4c  push rcx
000074113b7d8e4d  push rdx
000074113b7d8e4e  push rdi
000074113b7d8e4f  push rsi
000074113b7d8e50  push r8
000074113b7d8e52  push r9
000074113b7d8e54  push r10
000074113b7d8e56  push r11
000074113b7d8e58  sub rsp, 0xF0
000074113b7d8e5f  vmovaps [rsp], xmm0
000074113b7d8e64  vmovaps [rsp+0x10], xmm1
000074113b7d8e6a  vmovaps [rsp+0x20], xmm2
000074113b7d8e70  vmovaps [rsp+0x30], xmm3
000074113b7d8e76  vmovaps [rsp+0x40], xmm4
000074113b7d8e7c  vmovaps [rsp+0x50], xmm5
000074113b7d8e82  vmovaps [rsp+0x60], xmm6
000074113b7d8e88  vmovaps [rsp+0x70], xmm7
000074113b7d8e8e  vmovaps [rsp+0x80], xmm8
000074113b7d8e97  vmovaps [rsp+0x90], xmm9
000074113b7d8ea0  vmovaps [rsp+0xA0], xmm11
000074113b7d8ea9  vmovaps [rsp+0xB0], xmm12
000074113b7d8eb2  vmovaps [rsp+0xC0], xmm13
000074113b7d8ebb  vmovaps [rsp+0xD0], xmm14
000074113b7d8ec4  vmovaps [rsp+0xE0], xmm15
000074113b7d8ecd  sub rsp, 0x40
000074113b7d8ed1  lea rdi, [rsp]
000074113b7d8ed5  lea rsi, [rsp+0x10]
000074113b7d8eda  lea rdx, [rsp+0x20]
000074113b7d8edf  lea rcx, [rsp+0x30]
000074113b7d8ee4  mov r8d, 0x00
000074113b7d8eea  lea r9, [r15+0x3A8]
000074113b7d8ef1  movaps [rdi], xmm10
000074113b7d8ef5  movaps [rsi], xmm5
000074113b7d8ef8  movaps [rdx], xmm12
000074113b7d8efc  movaps [rcx], xmm1
000074113b7d8eff  mov rax, 0x629073062A50
000074113b7d8f09  call rax
000074113b7d8f0b  movaps xmm10, [rsp]
000074113b7d8f10  add rsp, 0x40
000074113b7d8f14  vmovaps xmm0, [rsp]
000074113b7d8f19  vmovaps xmm1, [rsp+0x10]
000074113b7d8f1f  vmovaps xmm2, [rsp+0x20]
000074113b7d8f25  vmovaps xmm3, [rsp+0x30]
000074113b7d8f2b  vmovaps xmm4, [rsp+0x40]
000074113b7d8f31  vmovaps xmm5, [rsp+0x50]
000074113b7d8f37  vmovaps xmm6, [rsp+0x60]
000074113b7d8f3d  vmovaps xmm7, [rsp+0x70]
000074113b7d8f43  vmovaps xmm8, [rsp+0x80]
000074113b7d8f4c  vmovaps xmm9, [rsp+0x90]
000074113b7d8f55  vmovaps xmm11, [rsp+0xA0]
000074113b7d8f5e  vmovaps xmm12, [rsp+0xB0]
000074113b7d8f67  vmovaps xmm13, [rsp+0xC0]
000074113b7d8f70  vmovaps xmm14, [rsp+0xD0]
000074113b7d8f79  vmovaps xmm15, [rsp+0xE0]
000074113b7d8f82  add rsp, 0xF0
000074113b7d8f89  pop r11
000074113b7d8f8b  pop r10
000074113b7d8f8d  pop r9
000074113b7d8f8f  pop r8
000074113b7d8f91  pop rsi
000074113b7d8f92  pop rdi
000074113b7d8f93  pop rdx
000074113b7d8f94  pop rcx
000074113b7d8f95  pop rax
000074113b7d8f96  add rsp, 0x08
000074113b7d8f9a  jmp 0x000074113B7D7257
000074113b7d8f9f  sub rsp, 0x08
000074113b7d8fa3  push rax
000074113b7d8fa4  push rcx
000074113b7d8fa5  push rdx
000074113b7d8fa6  push rdi
000074113b7d8fa7  push rsi
000074113b7d8fa8  push r8
000074113b7d8faa  push r9
000074113b7d8fac  push r10
000074113b7d8fae  push r11
000074113b7d8fb0  sub rsp, 0xF0
000074113b7d8fb7  vmovaps [rsp], xmm0
000074113b7d8fbc  vmovaps [rsp+0x10], xmm1
000074113b7d8fc2  vmovaps [rsp+0x20], xmm2
000074113b7d8fc8  vmovaps [rsp+0x30], xmm3
000074113b7d8fce  vmovaps [rsp+0x40], xmm4
000074113b7d8fd4  vmovaps [rsp+0x50], xmm5
000074113b7d8fda  vmovaps [rsp+0x60], xmm7
000074113b7d8fe0  vmovaps [rsp+0x70], xmm8
000074113b7d8fe6  vmovaps [rsp+0x80], xmm9
000074113b7d8fef  vmovaps [rsp+0x90], xmm10
000074113b7d8ff8  vmovaps [rsp+0xA0], xmm11
000074113b7d9001  vmovaps [rsp+0xB0], xmm12
000074113b7d900a  vmovaps [rsp+0xC0], xmm13
000074113b7d9013  vmovaps [rsp+0xD0], xmm14
000074113b7d901c  vmovaps [rsp+0xE0], xmm15
000074113b7d9025  sub rsp, 0x40
000074113b7d9029  lea rdi, [rsp]
000074113b7d902d  lea rsi, [rsp+0x10]
000074113b7d9032  lea rdx, [rsp+0x20]
000074113b7d9037  lea rcx, [rsp+0x30]
000074113b7d903c  mov r8d, 0x00
000074113b7d9042  lea r9, [r15+0x3A8]
000074113b7d9049  movaps [rdi], xmm6
000074113b7d904c  movaps [rsi], xmm8
000074113b7d9050  movaps [rdx], xmm12
000074113b7d9054  movaps [rcx], xmm1
000074113b7d9057  mov rax, 0x629073062A50
000074113b7d9061  call rax
000074113b7d9063  movaps xmm6, [rsp]
000074113b7d9067  add rsp, 0x40
000074113b7d906b  vmovaps xmm0, [rsp]
000074113b7d9070  vmovaps xmm1, [rsp+0x10]
000074113b7d9076  vmovaps xmm2, [rsp+0x20]
000074113b7d907c  vmovaps xmm3, [rsp+0x30]
000074113b7d9082  vmovaps xmm4, [rsp+0x40]
000074113b7d9088  vmovaps xmm5, [rsp+0x50]
000074113b7d908e  vmovaps xmm7, [rsp+0x60]
000074113b7d9094  vmovaps xmm8, [rsp+0x70]
000074113b7d909a  vmovaps xmm9, [rsp+0x80]
000074113b7d90a3  vmovaps xmm10, [rsp+0x90]
000074113b7d90ac  vmovaps xmm11, [rsp+0xA0]
000074113b7d90b5  vmovaps xmm12, [rsp+0xB0]
000074113b7d90be  vmovaps xmm13, [rsp+0xC0]
000074113b7d90c7  vmovaps xmm14, [rsp+0xD0]
000074113b7d90d0  vmovaps xmm15, [rsp+0xE0]
000074113b7d90d9  add rsp, 0xF0
000074113b7d90e0  pop r11
000074113b7d90e2  pop r10
000074113b7d90e4  pop r9
000074113b7d90e6  pop r8
000074113b7d90e8  pop rsi
000074113b7d90e9  pop rdi
000074113b7d90ea  pop rdx
000074113b7d90eb  pop rcx
000074113b7d90ec  pop rax
000074113b7d90ed  add rsp, 0x08
000074113b7d90f1  jmp 0x000074113B7D7285
000074113b7d90f6  call 0x000074113B5FF430
000074113b7d90fb  jmp 0x000074113B7D728F
000074113b7d9100  call 0x000074113B60AFE0
000074113b7d9105  jmp 0x000074113B7D7299
000074113b7d910a  sub rsp, 0x08
000074113b7d910e  push rax
000074113b7d910f  push rcx
000074113b7d9110  push rdx
000074113b7d9111  push rdi
000074113b7d9112  push rsi
000074113b7d9113  push r8
000074113b7d9115  push r9
000074113b7d9117  push r10
000074113b7d9119  push r11
000074113b7d911b  sub rsp, 0xF0
000074113b7d9122  vmovaps [rsp], xmm0
000074113b7d9127  vmovaps [rsp+0x10], xmm1
000074113b7d912d  vmovaps [rsp+0x20], xmm2
000074113b7d9133  vmovaps [rsp+0x30], xmm3
000074113b7d9139  vmovaps [rsp+0x40], xmm4
000074113b7d913f  vmovaps [rsp+0x50], xmm5
000074113b7d9145  vmovaps [rsp+0x60], xmm6
000074113b7d914b  vmovaps [rsp+0x70], xmm7
000074113b7d9151  vmovaps [rsp+0x80], xmm9
000074113b7d915a  vmovaps [rsp+0x90], xmm10
000074113b7d9163  vmovaps [rsp+0xA0], xmm11
000074113b7d916c  vmovaps [rsp+0xB0], xmm12
000074113b7d9175  vmovaps [rsp+0xC0], xmm13
000074113b7d917e  vmovaps [rsp+0xD0], xmm14
000074113b7d9187  vmovaps [rsp+0xE0], xmm15
000074113b7d9190  sub rsp, 0x40
000074113b7d9194  lea rdi, [rsp]
000074113b7d9198  lea rsi, [rsp+0x10]
000074113b7d919d  lea rdx, [rsp+0x20]
000074113b7d91a2  lea rcx, [rsp+0x30]
000074113b7d91a7  mov r8d, 0x00
000074113b7d91ad  lea r9, [r15+0x3A8]
000074113b7d91b4  movaps [rdi], xmm8
000074113b7d91b8  movaps [rsi], xmm4
000074113b7d91bb  movaps [rdx], xmm13
000074113b7d91bf  movaps [rcx], xmm11
000074113b7d91c3  mov rax, 0x629073062A50
000074113b7d91cd  call rax
000074113b7d91cf  movaps xmm8, [rsp]
000074113b7d91d4  add rsp, 0x40
000074113b7d91d8  vmovaps xmm0, [rsp]
000074113b7d91dd  vmovaps xmm1, [rsp+0x10]
000074113b7d91e3  vmovaps xmm2, [rsp+0x20]
000074113b7d91e9  vmovaps xmm3, [rsp+0x30]
000074113b7d91ef  vmovaps xmm4, [rsp+0x40]
000074113b7d91f5  vmovaps xmm5, [rsp+0x50]
000074113b7d91fb  vmovaps xmm6, [rsp+0x60]
000074113b7d9201  vmovaps xmm7, [rsp+0x70]
000074113b7d9207  vmovaps xmm9, [rsp+0x80]
000074113b7d9210  vmovaps xmm10, [rsp+0x90]
000074113b7d9219  vmovaps xmm11, [rsp+0xA0]
000074113b7d9222  vmovaps xmm12, [rsp+0xB0]
000074113b7d922b  vmovaps xmm13, [rsp+0xC0]
000074113b7d9234  vmovaps xmm14, [rsp+0xD0]
000074113b7d923d  vmovaps xmm15, [rsp+0xE0]
000074113b7d9246  add rsp, 0xF0
000074113b7d924d  pop r11
000074113b7d924f  pop r10
000074113b7d9251  pop r9
000074113b7d9253  pop r8
000074113b7d9255  pop rsi
000074113b7d9256  pop rdi
000074113b7d9257  pop rdx
000074113b7d9258  pop rcx
000074113b7d9259  pop rax
000074113b7d925a  add rsp, 0x08
000074113b7d925e  jmp 0x000074113B7D72CF
000074113b7d9263  sub rsp, 0x08
000074113b7d9267  push rax
000074113b7d9268  push rcx
000074113b7d9269  push rdx
000074113b7d926a  push rdi
000074113b7d926b  push rsi
000074113b7d926c  push r8
000074113b7d926e  push r9
000074113b7d9270  push r10
000074113b7d9272  push r11
000074113b7d9274  sub rsp, 0xF0
000074113b7d927b  vmovaps [rsp], xmm0
000074113b7d9280  vmovaps [rsp+0x10], xmm1
000074113b7d9286  vmovaps [rsp+0x20], xmm2
000074113b7d928c  vmovaps [rsp+0x30], xmm3
000074113b7d9292  vmovaps [rsp+0x40], xmm4
000074113b7d9298  vmovaps [rsp+0x50], xmm5
000074113b7d929e  vmovaps [rsp+0x60], xmm6
000074113b7d92a4  vmovaps [rsp+0x70], xmm7
000074113b7d92aa  vmovaps [rsp+0x80], xmm8
000074113b7d92b3  vmovaps [rsp+0x90], xmm9
000074113b7d92bc  vmovaps [rsp+0xA0], xmm10
000074113b7d92c5  vmovaps [rsp+0xB0], xmm12
000074113b7d92ce  vmovaps [rsp+0xC0], xmm13
000074113b7d92d7  vmovaps [rsp+0xD0], xmm14
000074113b7d92e0  vmovaps [rsp+0xE0], xmm15
000074113b7d92e9  sub rsp, 0x40
000074113b7d92ed  lea rdi, [rsp]
000074113b7d92f1  lea rsi, [rsp+0x10]
000074113b7d92f6  lea rdx, [rsp+0x20]
000074113b7d92fb  lea rcx, [rsp+0x30]
000074113b7d9300  mov r8d, 0x00
000074113b7d9306  lea r9, [r15+0x3A8]
000074113b7d930d  movaps [rdi], xmm11
000074113b7d9311  movaps [rsi], xmm9
000074113b7d9315  movaps [rdx], xmm1
000074113b7d9318  movaps [rcx], xmm13
000074113b7d931c  mov rax, 0x629073062A50
000074113b7d9326  call rax
000074113b7d9328  movaps xmm11, [rsp]
000074113b7d932d  add rsp, 0x40
000074113b7d9331  vmovaps xmm0, [rsp]
000074113b7d9336  vmovaps xmm1, [rsp+0x10]
000074113b7d933c  vmovaps xmm2, [rsp+0x20]
000074113b7d9342  vmovaps xmm3, [rsp+0x30]
000074113b7d9348  vmovaps xmm4, [rsp+0x40]
000074113b7d934e  vmovaps xmm5, [rsp+0x50]
000074113b7d9354  vmovaps xmm6, [rsp+0x60]
000074113b7d935a  vmovaps xmm7, [rsp+0x70]
000074113b7d9360  vmovaps xmm8, [rsp+0x80]
000074113b7d9369  vmovaps xmm9, [rsp+0x90]
000074113b7d9372  vmovaps xmm10, [rsp+0xA0]
000074113b7d937b  vmovaps xmm12, [rsp+0xB0]
000074113b7d9384  vmovaps xmm13, [rsp+0xC0]
000074113b7d938d  vmovaps xmm14, [rsp+0xD0]
000074113b7d9396  vmovaps xmm15, [rsp+0xE0]
000074113b7d939f  add rsp, 0xF0
000074113b7d93a6  pop r11
000074113b7d93a8  pop r10
000074113b7d93aa  pop r9
000074113b7d93ac  pop r8
000074113b7d93ae  pop rsi
000074113b7d93af  pop rdi
000074113b7d93b0  pop rdx
000074113b7d93b1  pop rcx
000074113b7d93b2  pop rax
000074113b7d93b3  add rsp, 0x08
000074113b7d93b7  jmp 0x000074113B7D72F5
000074113b7d93bc  sub rsp, 0x08
000074113b7d93c0  push rax
000074113b7d93c1  push rcx
000074113b7d93c2  push rdx
000074113b7d93c3  push rdi
000074113b7d93c4  push rsi
000074113b7d93c5  push r8
000074113b7d93c7  push r9
000074113b7d93c9  push r10
000074113b7d93cb  push r11
000074113b7d93cd  sub rsp, 0xF0
000074113b7d93d4  vmovaps [rsp], xmm0
000074113b7d93d9  vmovaps [rsp+0x10], xmm1
000074113b7d93df  vmovaps [rsp+0x20], xmm2
000074113b7d93e5  vmovaps [rsp+0x30], xmm3
000074113b7d93eb  vmovaps [rsp+0x40], xmm4
000074113b7d93f1  vmovaps [rsp+0x50], xmm5
000074113b7d93f7  vmovaps [rsp+0x60], xmm6
000074113b7d93fd  vmovaps [rsp+0x70], xmm7
000074113b7d9403  vmovaps [rsp+0x80], xmm8
000074113b7d940c  vmovaps [rsp+0x90], xmm9
000074113b7d9415  vmovaps [rsp+0xA0], xmm10
000074113b7d941e  vmovaps [rsp+0xB0], xmm11
000074113b7d9427  vmovaps [rsp+0xC0], xmm12
000074113b7d9430  vmovaps [rsp+0xD0], xmm14
000074113b7d9439  vmovaps [rsp+0xE0], xmm15
000074113b7d9442  sub rsp, 0x40
000074113b7d9446  lea rdi, [rsp]
000074113b7d944a  lea rsi, [rsp+0x10]
000074113b7d944f  lea rdx, [rsp+0x20]
000074113b7d9454  lea rcx, [rsp+0x30]
000074113b7d9459  mov r8d, 0x00
000074113b7d945f  lea r9, [r15+0x3A8]
000074113b7d9466  movaps [rdi], xmm13
000074113b7d946a  movaps [rsi], xmm10
000074113b7d946e  movaps [rdx], xmm7
000074113b7d9471  movaps [rcx], xmm1
000074113b7d9474  mov rax, 0x629073062A50
000074113b7d947e  call rax
000074113b7d9480  movaps xmm13, [rsp]
000074113b7d9485  add rsp, 0x40
000074113b7d9489  vmovaps xmm0, [rsp]
000074113b7d948e  vmovaps xmm1, [rsp+0x10]
000074113b7d9494  vmovaps xmm2, [rsp+0x20]
000074113b7d949a  vmovaps xmm3, [rsp+0x30]
000074113b7d94a0  vmovaps xmm4, [rsp+0x40]
000074113b7d94a6  vmovaps xmm5, [rsp+0x50]
000074113b7d94ac  vmovaps xmm6, [rsp+0x60]
000074113b7d94b2  vmovaps xmm7, [rsp+0x70]
000074113b7d94b8  vmovaps xmm8, [rsp+0x80]
000074113b7d94c1  vmovaps xmm9, [rsp+0x90]
000074113b7d94ca  vmovaps xmm10, [rsp+0xA0]
000074113b7d94d3  vmovaps xmm11, [rsp+0xB0]
000074113b7d94dc  vmovaps xmm12, [rsp+0xC0]
000074113b7d94e5  vmovaps xmm14, [rsp+0xD0]
000074113b7d94ee  vmovaps xmm15, [rsp+0xE0]
000074113b7d94f7  add rsp, 0xF0
000074113b7d94fe  pop r11
000074113b7d9500  pop r10
000074113b7d9502  pop r9
000074113b7d9504  pop r8
000074113b7d9506  pop rsi
000074113b7d9507  pop rdi
000074113b7d9508  pop rdx
000074113b7d9509  pop rcx
000074113b7d950a  pop rax
000074113b7d950b  add rsp, 0x08
000074113b7d950f  jmp 0x000074113B7D731B
000074113b7d9514  sub rsp, 0x08
000074113b7d9518  push rax
000074113b7d9519  push rcx
000074113b7d951a  push rdx
000074113b7d951b  push rdi
000074113b7d951c  push rsi
000074113b7d951d  push r8
000074113b7d951f  push r9
000074113b7d9521  push r10
000074113b7d9523  push r11
000074113b7d9525  sub rsp, 0xF0
000074113b7d952c  vmovaps [rsp], xmm0
000074113b7d9531  vmovaps [rsp+0x10], xmm1
000074113b7d9537  vmovaps [rsp+0x20], xmm2
000074113b7d953d  vmovaps [rsp+0x30], xmm3
000074113b7d9543  vmovaps [rsp+0x40], xmm4
000074113b7d9549  vmovaps [rsp+0x50], xmm5
000074113b7d954f  vmovaps [rsp+0x60], xmm6
000074113b7d9555  vmovaps [rsp+0x70], xmm7
000074113b7d955b  vmovaps [rsp+0x80], xmm8
000074113b7d9564  vmovaps [rsp+0x90], xmm9
000074113b7d956d  vmovaps [rsp+0xA0], xmm11
000074113b7d9576  vmovaps [rsp+0xB0], xmm12
000074113b7d957f  vmovaps [rsp+0xC0], xmm13
000074113b7d9588  vmovaps [rsp+0xD0], xmm14
000074113b7d9591  vmovaps [rsp+0xE0], xmm15
000074113b7d959a  sub rsp, 0x40
000074113b7d959e  lea rdi, [rsp]
000074113b7d95a2  lea rsi, [rsp+0x10]
000074113b7d95a7  lea rdx, [rsp+0x20]
000074113b7d95ac  lea rcx, [rsp+0x30]
000074113b7d95b1  mov r8d, 0x00
000074113b7d95b7  lea r9, [r15+0x3A8]
000074113b7d95be  movaps [rdi], xmm10
000074113b7d95c2  movaps [rsi], xmm6
000074113b7d95c5  movaps [rdx], xmm15
000074113b7d95c9  movaps [rcx], xmm1
000074113b7d95cc  mov rax, 0x629073062A50
000074113b7d95d6  call rax
000074113b7d95d8  movaps xmm10, [rsp]
000074113b7d95dd  add rsp, 0x40
000074113b7d95e1  vmovaps xmm0, [rsp]
000074113b7d95e6  vmovaps xmm1, [rsp+0x10]
000074113b7d95ec  vmovaps xmm2, [rsp+0x20]
000074113b7d95f2  vmovaps xmm3, [rsp+0x30]
000074113b7d95f8  vmovaps xmm4, [rsp+0x40]
000074113b7d95fe  vmovaps xmm5, [rsp+0x50]
000074113b7d9604  vmovaps xmm6, [rsp+0x60]
000074113b7d960a  vmovaps xmm7, [rsp+0x70]
000074113b7d9610  vmovaps xmm8, [rsp+0x80]
000074113b7d9619  vmovaps xmm9, [rsp+0x90]
000074113b7d9622  vmovaps xmm11, [rsp+0xA0]
000074113b7d962b  vmovaps xmm12, [rsp+0xB0]
000074113b7d9634  vmovaps xmm13, [rsp+0xC0]
000074113b7d963d  vmovaps xmm14, [rsp+0xD0]
000074113b7d9646  vmovaps xmm15, [rsp+0xE0]
000074113b7d964f  add rsp, 0xF0
000074113b7d9656  pop r11
000074113b7d9658  pop r10
000074113b7d965a  pop r9
000074113b7d965c  pop r8
000074113b7d965e  pop rsi
000074113b7d965f  pop rdi
000074113b7d9660  pop rdx
000074113b7d9661  pop rcx
000074113b7d9662  pop rax
000074113b7d9663  add rsp, 0x08
000074113b7d9667  jmp 0x000074113B7D7341
000074113b7d966c  call 0x000074113B5FF430
000074113b7d9671  jmp 0x000074113B7D734B
000074113b7d9676  call 0x000074113B60E760
000074113b7d967b  jmp 0x000074113B7D7355
000074113b7d9680  sub rsp, 0x08
000074113b7d9684  push rax
000074113b7d9685  push rcx
000074113b7d9686  push rdx
000074113b7d9687  push rdi
000074113b7d9688  push rsi
000074113b7d9689  push r8
000074113b7d968b  push r9
000074113b7d968d  push r10
000074113b7d968f  push r11
000074113b7d9691  sub rsp, 0xF0
000074113b7d9698  vmovaps [rsp], xmm0
000074113b7d969d  vmovaps [rsp+0x10], xmm1
000074113b7d96a3  vmovaps [rsp+0x20], xmm2
000074113b7d96a9  vmovaps [rsp+0x30], xmm3
000074113b7d96af  vmovaps [rsp+0x40], xmm4
000074113b7d96b5  vmovaps [rsp+0x50], xmm5
000074113b7d96bb  vmovaps [rsp+0x60], xmm6
000074113b7d96c1  vmovaps [rsp+0x70], xmm8
000074113b7d96c7  vmovaps [rsp+0x80], xmm9
000074113b7d96d0  vmovaps [rsp+0x90], xmm10
000074113b7d96d9  vmovaps [rsp+0xA0], xmm11
000074113b7d96e2  vmovaps [rsp+0xB0], xmm12
000074113b7d96eb  vmovaps [rsp+0xC0], xmm13
000074113b7d96f4  vmovaps [rsp+0xD0], xmm14
000074113b7d96fd  vmovaps [rsp+0xE0], xmm15
000074113b7d9706  sub rsp, 0x40
000074113b7d970a  lea rdi, [rsp]
000074113b7d970e  lea rsi, [rsp+0x10]
000074113b7d9713  lea rdx, [rsp+0x20]
000074113b7d9718  lea rcx, [rsp+0x30]
000074113b7d971d  mov r8d, 0x00
000074113b7d9723  lea r9, [r15+0x3A8]
000074113b7d972a  movaps [rdi], xmm7
000074113b7d972d  movaps [rsi], xmm8
000074113b7d9731  movaps [rdx], xmm3
000074113b7d9734  movaps [rcx], xmm9
000074113b7d9738  mov rax, 0x629073062A50
000074113b7d9742  call rax
000074113b7d9744  movaps xmm7, [rsp]
000074113b7d9748  add rsp, 0x40
000074113b7d974c  vmovaps xmm0, [rsp]
000074113b7d9751  vmovaps xmm1, [rsp+0x10]
000074113b7d9757  vmovaps xmm2, [rsp+0x20]
000074113b7d975d  vmovaps xmm3, [rsp+0x30]
000074113b7d9763  vmovaps xmm4, [rsp+0x40]
000074113b7d9769  vmovaps xmm5, [rsp+0x50]
000074113b7d976f  vmovaps xmm6, [rsp+0x60]
000074113b7d9775  vmovaps xmm8, [rsp+0x70]
000074113b7d977b  vmovaps xmm9, [rsp+0x80]
000074113b7d9784  vmovaps xmm10, [rsp+0x90]
000074113b7d978d  vmovaps xmm11, [rsp+0xA0]
000074113b7d9796  vmovaps xmm12, [rsp+0xB0]
000074113b7d979f  vmovaps xmm13, [rsp+0xC0]
000074113b7d97a8  vmovaps xmm14, [rsp+0xD0]
000074113b7d97b1  vmovaps xmm15, [rsp+0xE0]
000074113b7d97ba  add rsp, 0xF0
000074113b7d97c1  pop r11
000074113b7d97c3  pop r10
000074113b7d97c5  pop r9
000074113b7d97c7  pop r8
000074113b7d97c9  pop rsi
000074113b7d97ca  pop rdi
000074113b7d97cb  pop rdx
000074113b7d97cc  pop rcx
000074113b7d97cd  pop rax
000074113b7d97ce  add rsp, 0x08
000074113b7d97d2  jmp 0x000074113B7D737D
000074113b7d97d7  sub rsp, 0x08
000074113b7d97db  push rax
000074113b7d97dc  push rcx
000074113b7d97dd  push rdx
000074113b7d97de  push rdi
000074113b7d97df  push rsi
000074113b7d97e0  push r8
000074113b7d97e2  push r9
000074113b7d97e4  push r10
000074113b7d97e6  push r11
000074113b7d97e8  sub rsp, 0xF0
000074113b7d97ef  vmovaps [rsp], xmm0
000074113b7d97f4  vmovaps [rsp+0x10], xmm1
000074113b7d97fa  vmovaps [rsp+0x20], xmm2
000074113b7d9800  vmovaps [rsp+0x30], xmm3
000074113b7d9806  vmovaps [rsp+0x40], xmm4
000074113b7d980c  vmovaps [rsp+0x50], xmm5
000074113b7d9812  vmovaps [rsp+0x60], xmm6
000074113b7d9818  vmovaps [rsp+0x70], xmm7
000074113b7d981e  vmovaps [rsp+0x80], xmm9
000074113b7d9827  vmovaps [rsp+0x90], xmm10
000074113b7d9830  vmovaps [rsp+0xA0], xmm11
000074113b7d9839  vmovaps [rsp+0xB0], xmm12
000074113b7d9842  vmovaps [rsp+0xC0], xmm13
000074113b7d984b  vmovaps [rsp+0xD0], xmm14
000074113b7d9854  vmovaps [rsp+0xE0], xmm15
000074113b7d985d  sub rsp, 0x40
000074113b7d9861  lea rdi, [rsp]
000074113b7d9865  lea rsi, [rsp+0x10]
000074113b7d986a  lea rdx, [rsp+0x20]
000074113b7d986f  lea rcx, [rsp+0x30]
000074113b7d9874  mov r8d, 0x00
000074113b7d987a  lea r9, [r15+0x3A8]
000074113b7d9881  movaps [rdi], xmm8
000074113b7d9885  movaps [rsi], xmm11
000074113b7d9889  movaps [rdx], xmm14
000074113b7d988d  movaps [rcx], xmm9
000074113b7d9891  mov rax, 0x629073062A50
000074113b7d989b  call rax
000074113b7d989d  movaps xmm8, [rsp]
000074113b7d98a2  add rsp, 0x40
000074113b7d98a6  vmovaps xmm0, [rsp]
000074113b7d98ab  vmovaps xmm1, [rsp+0x10]
000074113b7d98b1  vmovaps xmm2, [rsp+0x20]
000074113b7d98b7  vmovaps xmm3, [rsp+0x30]
000074113b7d98bd  vmovaps xmm4, [rsp+0x40]
000074113b7d98c3  vmovaps xmm5, [rsp+0x50]
000074113b7d98c9  vmovaps xmm6, [rsp+0x60]
000074113b7d98cf  vmovaps xmm7, [rsp+0x70]
000074113b7d98d5  vmovaps xmm9, [rsp+0x80]
000074113b7d98de  vmovaps xmm10, [rsp+0x90]
000074113b7d98e7  vmovaps xmm11, [rsp+0xA0]
000074113b7d98f0  vmovaps xmm12, [rsp+0xB0]
000074113b7d98f9  vmovaps xmm13, [rsp+0xC0]
000074113b7d9902  vmovaps xmm14, [rsp+0xD0]
000074113b7d990b  vmovaps xmm15, [rsp+0xE0]
000074113b7d9914  add rsp, 0xF0
000074113b7d991b  pop r11
000074113b7d991d  pop r10
000074113b7d991f  pop r9
000074113b7d9921  pop r8
000074113b7d9923  pop rsi
000074113b7d9924  pop rdi
000074113b7d9925  pop rdx
000074113b7d9926  pop rcx
000074113b7d9927  pop rax
000074113b7d9928  add rsp, 0x08
000074113b7d992c  jmp 0x000074113B7D73A6
000074113b7d9931  sub rsp, 0x08
000074113b7d9935  push rax
000074113b7d9936  push rcx
000074113b7d9937  push rdx
000074113b7d9938  push rdi
000074113b7d9939  push rsi
000074113b7d993a  push r8
000074113b7d993c  push r9
000074113b7d993e  push r10
000074113b7d9940  push r11
000074113b7d9942  sub rsp, 0xF0
000074113b7d9949  vmovaps [rsp], xmm0
000074113b7d994e  vmovaps [rsp+0x10], xmm1
000074113b7d9954  vmovaps [rsp+0x20], xmm2
000074113b7d995a  vmovaps [rsp+0x30], xmm3
000074113b7d9960  vmovaps [rsp+0x40], xmm4
000074113b7d9966  vmovaps [rsp+0x50], xmm5
000074113b7d996c  vmovaps [rsp+0x60], xmm6
000074113b7d9972  vmovaps [rsp+0x70], xmm7
000074113b7d9978  vmovaps [rsp+0x80], xmm8
000074113b7d9981  vmovaps [rsp+0x90], xmm9
000074113b7d998a  vmovaps [rsp+0xA0], xmm10
000074113b7d9993  vmovaps [rsp+0xB0], xmm12
000074113b7d999c  vmovaps [rsp+0xC0], xmm13
000074113b7d99a5  vmovaps [rsp+0xD0], xmm14
000074113b7d99ae  vmovaps [rsp+0xE0], xmm15
000074113b7d99b7  sub rsp, 0x40
000074113b7d99bb  lea rdi, [rsp]
000074113b7d99bf  lea rsi, [rsp+0x10]
000074113b7d99c4  lea rdx, [rsp+0x20]
000074113b7d99c9  lea rcx, [rsp+0x30]
000074113b7d99ce  mov r8d, 0x00
000074113b7d99d4  lea r9, [r15+0x3A8]
000074113b7d99db  movaps [rdi], xmm11
000074113b7d99df  movaps [rsi], xmm13
000074113b7d99e3  movaps [rdx], xmm12
000074113b7d99e7  movaps [rcx], xmm14
000074113b7d99eb  mov rax, 0x629073062A50
000074113b7d99f5  call rax
000074113b7d99f7  movaps xmm11, [rsp]
000074113b7d99fc  add rsp, 0x40
000074113b7d9a00  vmovaps xmm0, [rsp]
000074113b7d9a05  vmovaps xmm1, [rsp+0x10]
000074113b7d9a0b  vmovaps xmm2, [rsp+0x20]
000074113b7d9a11  vmovaps xmm3, [rsp+0x30]
000074113b7d9a17  vmovaps xmm4, [rsp+0x40]
000074113b7d9a1d  vmovaps xmm5, [rsp+0x50]
000074113b7d9a23  vmovaps xmm6, [rsp+0x60]
000074113b7d9a29  vmovaps xmm7, [rsp+0x70]
000074113b7d9a2f  vmovaps xmm8, [rsp+0x80]
000074113b7d9a38  vmovaps xmm9, [rsp+0x90]
000074113b7d9a41  vmovaps xmm10, [rsp+0xA0]
000074113b7d9a4a  vmovaps xmm12, [rsp+0xB0]
000074113b7d9a53  vmovaps xmm13, [rsp+0xC0]
000074113b7d9a5c  vmovaps xmm14, [rsp+0xD0]
000074113b7d9a65  vmovaps xmm15, [rsp+0xE0]
000074113b7d9a6e  add rsp, 0xF0
000074113b7d9a75  pop r11
000074113b7d9a77  pop r10
000074113b7d9a79  pop r9
000074113b7d9a7b  pop r8
000074113b7d9a7d  pop rsi
000074113b7d9a7e  pop rdi
000074113b7d9a7f  pop rdx
000074113b7d9a80  pop rcx
000074113b7d9a81  pop rax
000074113b7d9a82  add rsp, 0x08
000074113b7d9a86  jmp 0x000074113B7D73CF
000074113b7d9a8b  sub rsp, 0x08
000074113b7d9a8f  push rax
000074113b7d9a90  push rcx
000074113b7d9a91  push rdx
000074113b7d9a92  push rdi
000074113b7d9a93  push rsi
000074113b7d9a94  push r8
000074113b7d9a96  push r9
000074113b7d9a98  push r10
000074113b7d9a9a  push r11
000074113b7d9a9c  sub rsp, 0xF0
000074113b7d9aa3  vmovaps [rsp], xmm0
000074113b7d9aa8  vmovaps [rsp+0x10], xmm1
000074113b7d9aae  vmovaps [rsp+0x20], xmm2
000074113b7d9ab4  vmovaps [rsp+0x30], xmm3
000074113b7d9aba  vmovaps [rsp+0x40], xmm4
000074113b7d9ac0  vmovaps [rsp+0x50], xmm5
000074113b7d9ac6  vmovaps [rsp+0x60], xmm6
000074113b7d9acc  vmovaps [rsp+0x70], xmm7
000074113b7d9ad2  vmovaps [rsp+0x80], xmm8
000074113b7d9adb  vmovaps [rsp+0x90], xmm9
000074113b7d9ae4  vmovaps [rsp+0xA0], xmm10
000074113b7d9aed  vmovaps [rsp+0xB0], xmm11
000074113b7d9af6  vmovaps [rsp+0xC0], xmm13
000074113b7d9aff  vmovaps [rsp+0xD0], xmm14
000074113b7d9b08  vmovaps [rsp+0xE0], xmm15
000074113b7d9b11  sub rsp, 0x40
000074113b7d9b15  lea rdi, [rsp]
000074113b7d9b19  lea rsi, [rsp+0x10]
000074113b7d9b1e  lea rdx, [rsp+0x20]
000074113b7d9b23  lea rcx, [rsp+0x30]
000074113b7d9b28  mov r8d, 0x00
000074113b7d9b2e  lea r9, [r15+0x3A8]
000074113b7d9b35  movaps [rdi], xmm12
000074113b7d9b39  movaps [rsi], xmm10
000074113b7d9b3d  movaps [rdx], xmm15
000074113b7d9b41  movaps [rcx], xmm14
000074113b7d9b45  mov rax, 0x629073062A50
000074113b7d9b4f  call rax
000074113b7d9b51  movaps xmm12, [rsp]
000074113b7d9b56  add rsp, 0x40
000074113b7d9b5a  vmovaps xmm0, [rsp]
000074113b7d9b5f  vmovaps xmm1, [rsp+0x10]
000074113b7d9b65  vmovaps xmm2, [rsp+0x20]
000074113b7d9b6b  vmovaps xmm3, [rsp+0x30]
000074113b7d9b71  vmovaps xmm4, [rsp+0x40]
000074113b7d9b77  vmovaps xmm5, [rsp+0x50]
000074113b7d9b7d  vmovaps xmm6, [rsp+0x60]
000074113b7d9b83  vmovaps xmm7, [rsp+0x70]
000074113b7d9b89  vmovaps xmm8, [rsp+0x80]
000074113b7d9b92  vmovaps xmm9, [rsp+0x90]
000074113b7d9b9b  vmovaps xmm10, [rsp+0xA0]
000074113b7d9ba4  vmovaps xmm11, [rsp+0xB0]
000074113b7d9bad  vmovaps xmm13, [rsp+0xC0]
000074113b7d9bb6  vmovaps xmm14, [rsp+0xD0]
000074113b7d9bbf  vmovaps xmm15, [rsp+0xE0]
000074113b7d9bc8  add rsp, 0xF0
000074113b7d9bcf  pop r11
000074113b7d9bd1  pop r10
000074113b7d9bd3  pop r9
000074113b7d9bd5  pop r8
000074113b7d9bd7  pop rsi
000074113b7d9bd8  pop rdi
000074113b7d9bd9  pop rdx
000074113b7d9bda  pop rcx
000074113b7d9bdb  pop rax
000074113b7d9bdc  add rsp, 0x08
000074113b7d9be0  jmp 0x000074113B7D73F8
000074113b7d9be5  call 0x000074113B60E760
000074113b7d9bea  jmp 0x000074113B7D7405
000074113b7d9bef  call 0x000074113B60D4E0
000074113b7d9bf4  jmp 0x000074113B7D7412
000074113b7d9bf9  sub rsp, 0x08
000074113b7d9bfd  push rax
000074113b7d9bfe  push rcx
000074113b7d9bff  push rdx
000074113b7d9c00  push rdi
000074113b7d9c01  push rsi
000074113b7d9c02  push r8
000074113b7d9c04  push r9
000074113b7d9c06  push r10
000074113b7d9c08  push r11
000074113b7d9c0a  sub rsp, 0xF0
000074113b7d9c11  vmovaps [rsp], xmm0
000074113b7d9c16  vmovaps [rsp+0x10], xmm1
000074113b7d9c1c  vmovaps [rsp+0x20], xmm2
000074113b7d9c22  vmovaps [rsp+0x30], xmm3
000074113b7d9c28  vmovaps [rsp+0x40], xmm4
000074113b7d9c2e  vmovaps [rsp+0x50], xmm5
000074113b7d9c34  vmovaps [rsp+0x60], xmm6
000074113b7d9c3a  vmovaps [rsp+0x70], xmm7
000074113b7d9c40  vmovaps [rsp+0x80], xmm8
000074113b7d9c49  vmovaps [rsp+0x90], xmm9
000074113b7d9c52  vmovaps [rsp+0xA0], xmm11
000074113b7d9c5b  vmovaps [rsp+0xB0], xmm12
000074113b7d9c64  vmovaps [rsp+0xC0], xmm13
000074113b7d9c6d  vmovaps [rsp+0xD0], xmm14
000074113b7d9c76  vmovaps [rsp+0xE0], xmm15
000074113b7d9c7f  sub rsp, 0x40
000074113b7d9c83  lea rdi, [rsp]
000074113b7d9c87  lea rsi, [rsp+0x10]
000074113b7d9c8c  lea rdx, [rsp+0x20]
000074113b7d9c91  lea rcx, [rsp+0x30]
000074113b7d9c96  mov r8d, 0x00
000074113b7d9c9c  lea r9, [r15+0x3A8]
000074113b7d9ca3  movaps [rdi], xmm10
000074113b7d9ca7  movaps [rsi], xmm7
000074113b7d9caa  movaps [rdx], xmm1
000074113b7d9cad  movaps [rcx], xmm13
000074113b7d9cb1  mov rax, 0x629073062A50
000074113b7d9cbb  call rax
000074113b7d9cbd  movaps xmm10, [rsp]
000074113b7d9cc2  add rsp, 0x40
000074113b7d9cc6  vmovaps xmm0, [rsp]
000074113b7d9ccb  vmovaps xmm1, [rsp+0x10]
000074113b7d9cd1  vmovaps xmm2, [rsp+0x20]
000074113b7d9cd7  vmovaps xmm3, [rsp+0x30]
000074113b7d9cdd  vmovaps xmm4, [rsp+0x40]
000074113b7d9ce3  vmovaps xmm5, [rsp+0x50]
000074113b7d9ce9  vmovaps xmm6, [rsp+0x60]
000074113b7d9cef  vmovaps xmm7, [rsp+0x70]
000074113b7d9cf5  vmovaps xmm8, [rsp+0x80]
000074113b7d9cfe  vmovaps xmm9, [rsp+0x90]
000074113b7d9d07  vmovaps xmm11, [rsp+0xA0]
000074113b7d9d10  vmovaps xmm12, [rsp+0xB0]
000074113b7d9d19  vmovaps xmm13, [rsp+0xC0]
000074113b7d9d22  vmovaps xmm14, [rsp+0xD0]
000074113b7d9d2b  vmovaps xmm15, [rsp+0xE0]
000074113b7d9d34  add rsp, 0xF0
000074113b7d9d3b  pop r11
000074113b7d9d3d  pop r10
000074113b7d9d3f  pop r9
000074113b7d9d41  pop r8
000074113b7d9d43  pop rsi
000074113b7d9d44  pop rdi
000074113b7d9d45  pop rdx
000074113b7d9d46  pop rcx
000074113b7d9d47  pop rax
000074113b7d9d48  add rsp, 0x08
000074113b7d9d4c  jmp 0x000074113B7D7448
000074113b7d9d51  call 0x000074113B5FF430
000074113b7d9d56  jmp 0x000074113B7D745A
000074113b7d9d5b  sub rsp, 0x08
000074113b7d9d5f  push rax
000074113b7d9d60  push rcx
000074113b7d9d61  push rdx
000074113b7d9d62  push rdi
000074113b7d9d63  push rsi
000074113b7d9d64  push r8
000074113b7d9d66  push r9
000074113b7d9d68  push r10
000074113b7d9d6a  push r11
000074113b7d9d6c  sub rsp, 0xF0
000074113b7d9d73  vmovaps [rsp], xmm0
000074113b7d9d78  vmovaps [rsp+0x10], xmm1
000074113b7d9d7e  vmovaps [rsp+0x20], xmm2
000074113b7d9d84  vmovaps [rsp+0x30], xmm3
000074113b7d9d8a  vmovaps [rsp+0x40], xmm4
000074113b7d9d90  vmovaps [rsp+0x50], xmm5
000074113b7d9d96  vmovaps [rsp+0x60], xmm6
000074113b7d9d9c  vmovaps [rsp+0x70], xmm7
000074113b7d9da2  vmovaps [rsp+0x80], xmm8
000074113b7d9dab  vmovaps [rsp+0x90], xmm10
000074113b7d9db4  vmovaps [rsp+0xA0], xmm11
000074113b7d9dbd  vmovaps [rsp+0xB0], xmm12
000074113b7d9dc6  vmovaps [rsp+0xC0], xmm13
000074113b7d9dcf  vmovaps [rsp+0xD0], xmm14
000074113b7d9dd8  vmovaps [rsp+0xE0], xmm15
000074113b7d9de1  sub rsp, 0x40
000074113b7d9de5  lea rdi, [rsp]
000074113b7d9de9  lea rsi, [rsp+0x10]
000074113b7d9dee  lea rdx, [rsp+0x20]
000074113b7d9df3  lea rcx, [rsp+0x30]
000074113b7d9df8  mov r8d, 0x00
000074113b7d9dfe  lea r9, [r15+0x3A8]
000074113b7d9e05  movaps [rdi], xmm9
000074113b7d9e09  movaps [rsi], xmm8
000074113b7d9e0d  movaps [rdx], xmm14
000074113b7d9e11  movaps [rcx], xmm13
000074113b7d9e15  mov rax, 0x629073062A50
000074113b7d9e1f  call rax
000074113b7d9e21  movaps xmm9, [rsp]
000074113b7d9e26  add rsp, 0x40
000074113b7d9e2a  vmovaps xmm0, [rsp]
000074113b7d9e2f  vmovaps xmm1, [rsp+0x10]
000074113b7d9e35  vmovaps xmm2, [rsp+0x20]
000074113b7d9e3b  vmovaps xmm3, [rsp+0x30]
000074113b7d9e41  vmovaps xmm4, [rsp+0x40]
000074113b7d9e47  vmovaps xmm5, [rsp+0x50]
000074113b7d9e4d  vmovaps xmm6, [rsp+0x60]
000074113b7d9e53  vmovaps xmm7, [rsp+0x70]
000074113b7d9e59  vmovaps xmm8, [rsp+0x80]
000074113b7d9e62  vmovaps xmm10, [rsp+0x90]
000074113b7d9e6b  vmovaps xmm11, [rsp+0xA0]
000074113b7d9e74  vmovaps xmm12, [rsp+0xB0]
000074113b7d9e7d  vmovaps xmm13, [rsp+0xC0]
000074113b7d9e86  vmovaps xmm14, [rsp+0xD0]
000074113b7d9e8f  vmovaps xmm15, [rsp+0xE0]
000074113b7d9e98  add rsp, 0xF0
000074113b7d9e9f  pop r11
000074113b7d9ea1  pop r10
000074113b7d9ea3  pop r9
000074113b7d9ea5  pop r8
000074113b7d9ea7  pop rsi
000074113b7d9ea8  pop rdi
000074113b7d9ea9  pop rdx
000074113b7d9eaa  pop rcx
000074113b7d9eab  pop rax
000074113b7d9eac  add rsp, 0x08
000074113b7d9eb0  jmp 0x000074113B7D7488
000074113b7d9eb5  sub rsp, 0x08
000074113b7d9eb9  push rax
000074113b7d9eba  push rcx
000074113b7d9ebb  push rdx
000074113b7d9ebc  push rdi
000074113b7d9ebd  push rsi
000074113b7d9ebe  push r8
000074113b7d9ec0  push r9
000074113b7d9ec2  push r10
000074113b7d9ec4  push r11
000074113b7d9ec6  sub rsp, 0xF0
000074113b7d9ecd  vmovaps [rsp], xmm0
000074113b7d9ed2  vmovaps [rsp+0x10], xmm1
000074113b7d9ed8  vmovaps [rsp+0x20], xmm2
000074113b7d9ede  vmovaps [rsp+0x30], xmm3
000074113b7d9ee4  vmovaps [rsp+0x40], xmm4
000074113b7d9eea  vmovaps [rsp+0x50], xmm5
000074113b7d9ef0  vmovaps [rsp+0x60], xmm6
000074113b7d9ef6  vmovaps [rsp+0x70], xmm7
000074113b7d9efc  vmovaps [rsp+0x80], xmm8
000074113b7d9f05  vmovaps [rsp+0x90], xmm9
000074113b7d9f0e  vmovaps [rsp+0xA0], xmm10
000074113b7d9f17  vmovaps [rsp+0xB0], xmm11
000074113b7d9f20  vmovaps [rsp+0xC0], xmm12
000074113b7d9f29  vmovaps [rsp+0xD0], xmm14
000074113b7d9f32  vmovaps [rsp+0xE0], xmm15
000074113b7d9f3b  sub rsp, 0x40
000074113b7d9f3f  lea rdi, [rsp]
000074113b7d9f43  lea rsi, [rsp+0x10]
000074113b7d9f48  lea rdx, [rsp+0x20]
000074113b7d9f4d  lea rcx, [rsp+0x30]
000074113b7d9f52  mov r8d, 0x00
000074113b7d9f58  lea r9, [r15+0x3A8]
000074113b7d9f5f  movaps [rdi], xmm13
000074113b7d9f63  movaps [rsi], xmm11
000074113b7d9f67  movaps [rdx], xmm15
000074113b7d9f6b  movaps [rcx], xmm14
000074113b7d9f6f  mov rax, 0x629073062A50
000074113b7d9f79  call rax
000074113b7d9f7b  movaps xmm13, [rsp]
000074113b7d9f80  add rsp, 0x40
000074113b7d9f84  vmovaps xmm0, [rsp]
000074113b7d9f89  vmovaps xmm1, [rsp+0x10]
000074113b7d9f8f  vmovaps xmm2, [rsp+0x20]
000074113b7d9f95  vmovaps xmm3, [rsp+0x30]
000074113b7d9f9b  vmovaps xmm4, [rsp+0x40]
000074113b7d9fa1  vmovaps xmm5, [rsp+0x50]
000074113b7d9fa7  vmovaps xmm6, [rsp+0x60]
000074113b7d9fad  vmovaps xmm7, [rsp+0x70]
000074113b7d9fb3  vmovaps xmm8, [rsp+0x80]
000074113b7d9fbc  vmovaps xmm9, [rsp+0x90]
000074113b7d9fc5  vmovaps xmm10, [rsp+0xA0]
000074113b7d9fce  vmovaps xmm11, [rsp+0xB0]
000074113b7d9fd7  vmovaps xmm12, [rsp+0xC0]
000074113b7d9fe0  vmovaps xmm14, [rsp+0xD0]
000074113b7d9fe9  vmovaps xmm15, [rsp+0xE0]
000074113b7d9ff2  add rsp, 0xF0
000074113b7d9ff9  pop r11
000074113b7d9ffb  pop r10
000074113b7d9ffd  pop r9
000074113b7d9fff  pop r8
000074113b7da001  pop rsi
000074113b7da002  pop rdi
000074113b7da003  pop rdx
000074113b7da004  pop rcx
000074113b7da005  pop rax
000074113b7da006  add rsp, 0x08
000074113b7da00a  jmp 0x000074113B7D74B6
000074113b7da00f  sub rsp, 0x08
000074113b7da013  push rax
000074113b7da014  push rcx
000074113b7da015  push rdx
000074113b7da016  push rdi
000074113b7da017  push rsi
000074113b7da018  push r8
000074113b7da01a  push r9
000074113b7da01c  push r10
000074113b7da01e  push r11
000074113b7da020  sub rsp, 0xF0
000074113b7da027  vmovaps [rsp], xmm0
000074113b7da02c  vmovaps [rsp+0x10], xmm1
000074113b7da032  vmovaps [rsp+0x20], xmm2
000074113b7da038  vmovaps [rsp+0x30], xmm3
000074113b7da03e  vmovaps [rsp+0x40], xmm4
000074113b7da044  vmovaps [rsp+0x50], xmm5
000074113b7da04a  vmovaps [rsp+0x60], xmm6
000074113b7da050  vmovaps [rsp+0x70], xmm7
000074113b7da056  vmovaps [rsp+0x80], xmm8
000074113b7da05f  vmovaps [rsp+0x90], xmm9
000074113b7da068  vmovaps [rsp+0xA0], xmm10
000074113b7da071  vmovaps [rsp+0xB0], xmm11
000074113b7da07a  vmovaps [rsp+0xC0], xmm12
000074113b7da083  vmovaps [rsp+0xD0], xmm13
000074113b7da08c  vmovaps [rsp+0xE0], xmm15
000074113b7da095  sub rsp, 0x40
000074113b7da099  lea rdi, [rsp]
000074113b7da09d  lea rsi, [rsp+0x10]
000074113b7da0a2  lea rdx, [rsp+0x20]
000074113b7da0a7  lea rcx, [rsp+0x30]
000074113b7da0ac  mov r8d, 0x00
000074113b7da0b2  lea r9, [r15+0x3A8]
000074113b7da0b9  movaps [rdi], xmm14
000074113b7da0bd  movaps [rsi], xmm12
000074113b7da0c1  movaps [rdx], xmm1
000074113b7da0c4  movaps [rcx], xmm15
000074113b7da0c8  mov rax, 0x629073062A50
000074113b7da0d2  call rax
000074113b7da0d4  movaps xmm14, [rsp]
000074113b7da0d9  add rsp, 0x40
000074113b7da0dd  vmovaps xmm0, [rsp]
000074113b7da0e2  vmovaps xmm1, [rsp+0x10]
000074113b7da0e8  vmovaps xmm2, [rsp+0x20]
000074113b7da0ee  vmovaps xmm3, [rsp+0x30]
000074113b7da0f4  vmovaps xmm4, [rsp+0x40]
000074113b7da0fa  vmovaps xmm5, [rsp+0x50]
000074113b7da100  vmovaps xmm6, [rsp+0x60]
000074113b7da106  vmovaps xmm7, [rsp+0x70]
000074113b7da10c  vmovaps xmm8, [rsp+0x80]
000074113b7da115  vmovaps xmm9, [rsp+0x90]
000074113b7da11e  vmovaps xmm10, [rsp+0xA0]
000074113b7da127  vmovaps xmm11, [rsp+0xB0]
000074113b7da130  vmovaps xmm12, [rsp+0xC0]
000074113b7da139  vmovaps xmm13, [rsp+0xD0]
000074113b7da142  vmovaps xmm15, [rsp+0xE0]
000074113b7da14b  add rsp, 0xF0
000074113b7da152  pop r11
000074113b7da154  pop r10
000074113b7da156  pop r9
000074113b7da158  pop r8
000074113b7da15a  pop rsi
000074113b7da15b  pop rdi
000074113b7da15c  pop rdx
000074113b7da15d  pop rcx
000074113b7da15e  pop rax
000074113b7da15f  add rsp, 0x08
000074113b7da163  jmp 0x000074113B7D74E4
000074113b7da168  call 0x000074113B6079B0
000074113b7da16d  jmp 0x000074113B7D74FA
000074113b7da172  call 0x000074113B6E3440
000074113b7da177  jmp 0x000074113B7D7504
000074113b7da17c  call 0x000074113B6DFCE0
000074113b7da181  jmp 0x000074113B7D750E
000074113b7da186  call 0x000074113B6E46C0
000074113b7da18b  jmp 0x000074113B7D7518
000074113b7da190  int3
000074113b7da191  nop [rax+rax*1], ax
000074113b7da19a  nop [rax+rax*1], ax
000074113b7da1a0  mov rax, [r15+0xF8]
000074113b7da1a7  lea r14, [rax+0x110]
000074113b7da1ae  mov r12, [r13+r14*1]
000074113b7da1b3  mov [r15+0xE8], r12
000074113b7da1ba  lea r14, [rax+0x100]
000074113b7da1c1  mov r12, [r13+r14*1]
000074113b7da1c6  lea r14, [rax+0x108]
000074113b7da1cd  mov r11, [r13+r14*1]
000074113b7da1d2  movq xmm1, r12
000074113b7da1d7  movq xmm15, r11
000074113b7da1dc  movq xmm1, xmm1
000074113b7da1e0  movq xmm1, xmm1
000074113b7da1e4  movaps [r15+0x1A0], xmm1
000074113b7da1ec  movq xmm15, xmm15
000074113b7da1f1  movq xmm15, xmm15
000074113b7da1f6  movaps [r15+0x190], xmm15
000074113b7da1fe  lea r14, [rax+0xF0]
000074113b7da205  mov r12, [r13+r14*1]
000074113b7da20a  lea r14, [rax+0xF8]
000074113b7da211  mov r11, [r13+r14*1]
000074113b7da216  movq xmm1, r12
000074113b7da21b  movq xmm15, r11
000074113b7da220  movq xmm1, xmm1
000074113b7da224  movq xmm1, xmm1
000074113b7da228  movaps [r15+0x1C0], xmm1
000074113b7da230  movq xmm15, xmm15
000074113b7da235  movq xmm15, xmm15
000074113b7da23a  movaps [r15+0x1B0], xmm15
000074113b7da242  lea r14, [rax+0xE0]
000074113b7da249  mov r12, [r13+r14*1]
000074113b7da24e  lea r14, [rax+0xE8]
000074113b7da255  mov r11, [r13+r14*1]
000074113b7da25a  movq xmm1, r12
000074113b7da25f  movq xmm15, r11
000074113b7da264  movq xmm1, xmm1
000074113b7da268  movq xmm1, xmm1
000074113b7da26c  movaps [r15+0x1E0], xmm1
000074113b7da274  movq xmm15, xmm15
000074113b7da279  movq xmm15, xmm15
000074113b7da27e  movaps [r15+0x1D0], xmm15
000074113b7da286  lea r14, [rax+0xD0]
000074113b7da28d  mov r12, [r13+r14*1]
000074113b7da292  lea r14, [rax+0xD8]
000074113b7da299  mov r11, [r13+r14*1]
000074113b7da29e  movq xmm1, r12
000074113b7da2a3  movq xmm15, r11
000074113b7da2a8  movq xmm1, xmm1
000074113b7da2ac  movq xmm1, xmm1
000074113b7da2b0  movaps [r15+0x200], xmm1
000074113b7da2b8  movq xmm15, xmm15
000074113b7da2bd  movq xmm15, xmm15
000074113b7da2c2  movaps [r15+0x1F0], xmm15
000074113b7da2ca  mov qword ptr [r15+0x40], 0x430000
000074113b7da2d2  mov r14d, 0x4304C0
000074113b7da2d8  mov r12, [r13+r14*1]
000074113b7da2dd  movq xmm1, r12
000074113b7da2e2  lea r14, [rax+0x120]
000074113b7da2e9  mov [r15+0xF8], r14
000074113b7da2f0  mov rax, [r15+0x50]
000074113b7da2f4  movups xmm15, [r13+rax*1]
000074113b7da2fa  movaps [r15+0x120], xmm15
000074113b7da302  mov qword ptr [r15+0x48], 0x10
000074113b7da30a  xor eax, eax
000074113b7da30c  mov r14d, 0x10
000074113b7da312  mov r12d, 0x200
000074113b7da318  cmp r14, r12
000074113b7da31b  cmc
000074113b7da31c  lahf
000074113b7da31d  seto al
000074113b7da320  mov [r15+0x108], eax
000074113b7da327  pextrq rax, xmm15, 0x01
000074113b7da32e  movq xmm14, rax
000074113b7da333  movaps [r15+0x130], xmm14
000074113b7da33b  movq rax, xmm1
000074113b7da340  movq r14, xmm15
000074113b7da345  vmovq xmm1, rax
000074113b7da34a  vmovq xmm15, r14
000074113b7da34f  movaps xmm13, xmm1
000074113b7da353  addsd xmm13, xmm15
000074113b7da358  ucomisd xmm13, xmm13
000074113b7da35d  jp 0x000074113B7DA476
000074113b7da363  movq xmm13, xmm13
000074113b7da368  movq rax, xmm13
000074113b7da36d  movq r14, xmm14
000074113b7da372  vmovq xmm1, rax
000074113b7da377  vmovq xmm15, r14
000074113b7da37c  movaps xmm14, xmm1
000074113b7da380  addsd xmm14, xmm15
000074113b7da385  ucomisd xmm14, xmm14
000074113b7da38a  jp 0x000074113B7DA4BE
000074113b7da390  movq xmm14, xmm14
000074113b7da395  movaps [r15+0x110], xmm14
000074113b7da39d  mov eax, [r15+0x108]
000074113b7da3a4  sahf
000074113b7da3a5  jnz 0x000074113B7DA3D7
000074113b7da3a7  cmp dword ptr [r15+0x318], 0x00
000074113b7da3af  jz 0x000074113B7DA6D0
000074113b7da3b5  nop [rax+rax*1], ax
000074113b7da3be  nop [rax+rax*1], eax
000074113b7da3c6  mov eax, 0x41043C
000074113b7da3cb  mov [r15+0x100], rax
000074113b7da3d2  jmp 0x000074113B5FE110
000074113b7da3d7  cmp dword ptr [r15+0x318], 0x00
000074113b7da3df  jz 0x000074113B7DA510
000074113b7da3e5  nop [rax+rax*1], ax
000074113b7da3ee  nop [rax+rax*1], eax
000074113b7da3f6  mov eax, 0x410420
000074113b7da3fb  mov [r15+0x100], rax
000074113b7da402  jmp 0x000074113B5FE110
000074113b7da407  int3
000074113b7da408  call 0x000074113B6E27E0
000074113b7da40d  jmp 0x000074113B7DA1B3
000074113b7da412  call 0x000074113B6E27E0
000074113b7da417  jmp 0x000074113B7DA1C6
000074113b7da41c  call 0x000074113B6E1570
000074113b7da421  jmp 0x000074113B7DA1D2
000074113b7da426  call 0x000074113B6E27E0
000074113b7da42b  jmp 0x000074113B7DA20A
000074113b7da430  call 0x000074113B6E1570
000074113b7da435  jmp 0x000074113B7DA216
000074113b7da43a  call 0x000074113B6E27E0
000074113b7da43f  jmp 0x000074113B7DA24E
000074113b7da444  call 0x000074113B6E1570
000074113b7da449  jmp 0x000074113B7DA25A
000074113b7da44e  call 0x000074113B6E27E0
000074113b7da453  jmp 0x000074113B7DA292
000074113b7da458  call 0x000074113B6E1570
000074113b7da45d  jmp 0x000074113B7DA29E
000074113b7da462  call 0x000074113B6E27E0
000074113b7da467  jmp 0x000074113B7DA2DD
000074113b7da46c  call 0x000074113B60E760
000074113b7da471  jmp 0x000074113B7DA2FA
000074113b7da476  ucomisd xmm1, xmm15
000074113b7da47b  jp 0x000074113B7DA48A
000074113b7da47d  movaps xmm13, [0x000074113B3FE060]
000074113b7da485  jmp 0x000074113B7DA363
000074113b7da48a  vxorps xmm0, xmm1, xmm15
000074113b7da48f  pextrw eax, xmm0, 0x03
000074113b7da494  and eax, 0x7FF8
000074113b7da499  cmp eax, 0x08
000074113b7da49c  jnz 0x000074113B7DA363
000074113b7da4a2  movq rax, xmm15
000074113b7da4a7  shl rax, 0x0D
000074113b7da4ab  jbe 0x000074113B7DA363
000074113b7da4b1  vorps xmm13, xmm15, [0x000074113B3FE070]
000074113b7da4b9  jmp 0x000074113B7DA363
000074113b7da4be  ucomisd xmm1, xmm15
000074113b7da4c3  jp 0x000074113B7DA4D2
000074113b7da4c5  movaps xmm14, [0x000074113B3FE060]
000074113b7da4cd  jmp 0x000074113B7DA390
000074113b7da4d2  vxorps xmm0, xmm1, xmm15
000074113b7da4d7  pextrw eax, xmm0, 0x03
000074113b7da4dc  and eax, 0x7FF8
000074113b7da4e1  cmp eax, 0x08
000074113b7da4e4  jnz 0x000074113B7DA390
000074113b7da4ea  movq rax, xmm15
000074113b7da4ef  shl rax, 0x0D
000074113b7da4f3  jbe 0x000074113B7DA390
000074113b7da4f9  vorps xmm14, xmm15, [0x000074113B3FE070]
000074113b7da501  jmp 0x000074113B7DA390
000074113b7da506  int3
000074113b7da507  nop [rax+rax*1], ax
000074113b7da510  mov rax, [r15+0x48]
000074113b7da514  mov r14, [r15+0x50]
000074113b7da518  lea r12, [r14+rax*1]
000074113b7da51c  movups xmm1, [r13+r12*1]
000074113b7da522  movaps [r15+0x120], xmm1
000074113b7da52a  lea r14, [rax+0x10]
000074113b7da52e  mov [r15+0x48], r14
000074113b7da532  xor eax, eax
000074113b7da534  mov r12d, 0x200
000074113b7da53a  cmp r14, r12
000074113b7da53d  cmc
000074113b7da53e  lahf
000074113b7da53f  seto al
000074113b7da542  mov [r15+0x108], eax
000074113b7da549  pextrq rax, xmm1, 0x01
000074113b7da550  movq xmm15, rax
000074113b7da555  movaps [r15+0x130], xmm15
000074113b7da55d  movaps xmm14, [r15+0x110]
000074113b7da565  movq rax, xmm14
000074113b7da56a  movq r14, xmm1
000074113b7da56f  vmovq xmm1, rax
000074113b7da574  vmovq xmm14, r14
000074113b7da579  movaps xmm13, xmm1
000074113b7da57d  addsd xmm13, xmm14
000074113b7da582  ucomisd xmm13, xmm13
000074113b7da587  jp 0x000074113B7DA63C
000074113b7da58d  movq xmm13, xmm13
000074113b7da592  movq rax, xmm13
000074113b7da597  movq r14, xmm15
000074113b7da59c  vmovq xmm1, rax
000074113b7da5a1  vmovq xmm15, r14
000074113b7da5a6  movaps xmm14, xmm1
000074113b7da5aa  addsd xmm14, xmm15
000074113b7da5af  ucomisd xmm14, xmm14
000074113b7da5b4  jp 0x000074113B7DA684
000074113b7da5ba  movq xmm14, xmm14
000074113b7da5bf  movaps [r15+0x110], xmm14
000074113b7da5c7  mov eax, [r15+0x108]
000074113b7da5ce  sahf
000074113b7da5cf  jnz 0x000074113B7DA601
000074113b7da5d1  cmp dword ptr [r15+0x318], 0x00
000074113b7da5d9  jz 0x000074113B7DA6D0
000074113b7da5df  nop [rax+rax*1], ax
000074113b7da5e8  nop [rax+rax*1], eax
000074113b7da5f0  mov eax, 0x41043C
000074113b7da5f5  mov [r15+0x100], rax
000074113b7da5fc  jmp 0x000074113B5FE110
000074113b7da601  cmp dword ptr [r15+0x318], 0x00
000074113b7da609  jz 0x000074113B7DA510
000074113b7da60f  nop [rax+rax*1], ax
000074113b7da618  nop [rax+rax*1], eax
000074113b7da620  mov eax, 0x410420
000074113b7da625  mov [r15+0x100], rax
000074113b7da62c  jmp 0x000074113B5FE110
000074113b7da631  int3
000074113b7da632  call 0x000074113B6B52F0
000074113b7da637  jmp 0x000074113B7DA522
000074113b7da63c  ucomisd xmm1, xmm14
000074113b7da641  jp 0x000074113B7DA650
000074113b7da643  movaps xmm13, [0x000074113B3FE060]
000074113b7da64b  jmp 0x000074113B7DA58D
000074113b7da650  vxorps xmm0, xmm1, xmm14
000074113b7da655  pextrw eax, xmm0, 0x03
000074113b7da65a  and eax, 0x7FF8
000074113b7da65f  cmp eax, 0x08
000074113b7da662  jnz 0x000074113B7DA58D
000074113b7da668  movq rax, xmm14
000074113b7da66d  shl rax, 0x0D
000074113b7da671  jbe 0x000074113B7DA58D
000074113b7da677  vorps xmm13, xmm14, [0x000074113B3FE070]
000074113b7da67f  jmp 0x000074113B7DA58D
000074113b7da684  ucomisd xmm1, xmm15
000074113b7da689  jp 0x000074113B7DA698
000074113b7da68b  movaps xmm14, [0x000074113B3FE060]
000074113b7da693  jmp 0x000074113B7DA5BA
000074113b7da698  vxorps xmm0, xmm1, xmm15
000074113b7da69d  pextrw eax, xmm0, 0x03
000074113b7da6a2  and eax, 0x7FF8
000074113b7da6a7  cmp eax, 0x08
000074113b7da6aa  jnz 0x000074113B7DA5BA
000074113b7da6b0  movq rax, xmm15
000074113b7da6b5  shl rax, 0x0D
000074113b7da6b9  jbe 0x000074113B7DA5BA
000074113b7da6bf  vorps xmm14, xmm15, [0x000074113B3FE070]
000074113b7da6c7  jmp 0x000074113B7DA5BA
000074113b7da6cc  int3
000074113b7da6cd  nop [rax], eax
000074113b7da6d0  mov rax, [r15+0x40]
000074113b7da6d4  lea r14, [rax+0x4C0]
000074113b7da6db  movaps xmm1, [r15+0x110]
000074113b7da6e3  movq rax, xmm1
000074113b7da6e8  mov [r13+r14*1], rax
000074113b7da6ed  mov rax, [r15+0xF0]
000074113b7da6f4  mov [r15+0x100], rax
000074113b7da6fb  jmp 0x000074113B7CE5C0
000074113b7da700  int3
000074113b7da701  call 0x000074113B6D5EB0
000074113b7da706  jmp 0x000074113B7DA6ED
000074113b7da70b  int3
000074113b7da70c  nop [rax], eax
000074113b7da710  mov qword ptr [r15+0x100], 0x04
000074113b7da71b  mov esi, 0x00
000074113b7da720  mov edx, 0x09
000074113b7da725  mov rdi, 0x7FFFE887D8A0
000074113b7da72f  mov rax, 0x629072EF5970
000074113b7da739  call rax
000074113b7da73b  cmp dword ptr [r15+0x318], 0x00
000074113b7da743  jnz 0x000074113B5FE110
000074113b7da749  jmp 0x000074113B5FE0A0
000074113b7da74e  int3
000074113b7da74f  int3
